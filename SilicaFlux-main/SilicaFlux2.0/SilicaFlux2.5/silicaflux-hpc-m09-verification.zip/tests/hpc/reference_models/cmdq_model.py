"""Command-queue semantics: what exists today, and the executable contract a tile
command processor with FENCE (a future "Module 06") must meet.

1. Existing queues (verified now)
   * hpc_vector_array command queue (Module 03): a command is accepted when
     cmd_ready; up to CMD_DEPTH commands wait ahead of the one being issued, so
     with the operand stream blocked exactly CMD_DEPTH + 1 commands are
     accepted; completions in acceptance order; illegal commands complete in
     order with illegal = 1.
   * hpc_dma_adapter descriptor queue (Module 05): cmd_ready = queue not full
     (CMD_DEPTH = 0: only when idle); a descriptor starts only with a free
     completion slot, so with the completion consumer blocked exactly
     CPL_DEPTH + CMD_DEPTH descriptors are accepted (CPL_DEPTH when
     CMD_DEPTH = 0); completions in acceptance order.

2. FENCE / dependencies (BLOCKED: no RTL implements them; see docs/KNOWN_GAPS.md)
   ``check_trace`` verifies a trace of a command processor against:
   F1  a command after a FENCE does not START before every command before the
       FENCE has COMPLETED (completion includes every write acknowledgement);
   F2  the FENCE itself completes only when F1's condition holds, and after
       every earlier completion;
   F3  every accepted command completes exactly once (no loss / duplication);
   F4  completion order: in acceptance order per queue unless the processor
       declares out-of-order completion with tags;
   D1  a command that reads a memory range written by an earlier command does
       not start before that writer completed (RAW), unless a FENCE already
       orders them; WAR and WAW likewise.
   An event is (cycle, kind, cmd_id) with kind in {"accept", "start",
   "complete"}; commands are dicts: id, op ("FENCE" or other), reads [(lo, hi)],
   writes [(lo, hi)].
"""
from __future__ import annotations


def varray_queue_full_accepts(cmd_depth: int) -> int:
    return cmd_depth + 1


def dma_queue_full_accepts(cmd_depth: int, cpl_depth: int) -> int:
    return cpl_depth + cmd_depth if cmd_depth > 0 else cpl_depth


def _overlap(a, b):
    return a[0] < b[1] and b[0] < a[1]


def check_trace(cmds: list[dict], events: list[tuple], in_order_completion=True) -> list[str]:
    errs = []
    by_id = {c["id"]: c for c in cmds}
    t = {}
    for cyc, kind, cid in events:
        if cid not in by_id:
            errs.append(f"event for unknown command {cid}")
            continue
        if kind in t.setdefault(cid, {}):
            errs.append(f"command {cid}: duplicate '{kind}' (F3)")
        t[cid][kind] = cyc
    order = [c["id"] for c in cmds]
    for cid in order:
        ev = t.get(cid, {})
        for k in ("accept", "complete"):
            if k not in ev:
                errs.append(f"command {cid}: no '{k}' event (F3)")
        if "start" in ev and "accept" in ev and ev["start"] < ev["accept"]:
            errs.append(f"command {cid}: started before accepted")
    for i, cid in enumerate(order):
        c = by_id[cid]
        if c["op"] != "FENCE":
            continue
        before, after = order[:i], order[i + 1:]
        done = max((t.get(b, {}).get("complete", 1 << 60) for b in before), default=-1)
        fc = t.get(cid, {}).get("complete")
        if fc is not None and fc < done:
            errs.append(f"FENCE {cid} completed at {fc} before an earlier command completed at {done} (F2)")
        for a in after:
            st = t.get(a, {}).get("start")
            if st is not None and st <= done:
                errs.append(f"command {a} started at {st} before FENCE {cid}'s predecessors completed at {done} (F1)")
    for i, cid in enumerate(order):
        c = by_id[cid]
        for j in range(i):
            p = by_id[order[j]]
            if p["op"] == "FENCE" or c["op"] == "FENCE":
                continue
            raw = any(_overlap(r, w) for r in c.get("reads", []) for w in p.get("writes", []))
            war = any(_overlap(w, r) for w in c.get("writes", []) for r in p.get("reads", []))
            waw = any(_overlap(w, w2) for w in c.get("writes", []) for w2 in p.get("writes", []))
            if raw or war or waw:
                st, pc = t.get(cid, {}).get("start"), t.get(p["id"], {}).get("complete")
                if st is not None and pc is not None and st <= pc:
                    kind = "RAW" if raw else ("WAR" if war else "WAW")
                    errs.append(f"command {cid} started at {st} before {kind} predecessor {p['id']} completed at {pc} (D1)")
    if in_order_completion:
        last = -1
        for cid in order:
            cc = t.get(cid, {}).get("complete")
            if cc is not None:
                if cc < last:
                    errs.append(f"command {cid} completed out of order (F4)")
                last = max(last, cc)
    return errs


def self_test() -> list[str]:
    """the checker must accept a legal trace and reject each kind of violation (non-vacuity)."""
    cmds = [{"id": 0, "op": "DMA_IN", "writes": [(0, 64)]},
            {"id": 1, "op": "COMPUTE", "reads": [(0, 64)], "writes": [(64, 128)]},
            {"id": 2, "op": "FENCE"},
            {"id": 3, "op": "DMA_OUT", "reads": [(64, 128)]}]
    good = [(0, "accept", 0), (1, "accept", 1), (2, "accept", 2), (3, "accept", 3), (1, "start", 0),
            (10, "complete", 0), (11, "start", 1), (20, "complete", 1), (21, "complete", 2), (22, "start", 3),
            (30, "complete", 3)]
    out = []
    if check_trace(cmds, good):
        out.append(f"legal trace rejected: {check_trace(cmds, good)}")
    bad_cases = {
        "F1": [e if e != (22, "start", 3) else (15, "start", 3) for e in good],
        "D1": [e if e != (11, "start", 1) else (5, "start", 1) for e in good],
        "F3": [e for e in good if e != (30, "complete", 3)],
        "F2": [e if e != (21, "complete", 2) else (12, "complete", 2) for e in good],
    }
    for rule, tr in bad_cases.items():
        if not any(f"({rule})" in m for m in check_trace(cmds, tr)):
            out.append(f"violation {rule} not detected")
    return out
