"""Reference model of hpc_vector_array (Module 03) commands, written from the
specification (docs/ARRAY_INTERFACE.md §3-§9, docs/REDUCTION.md §1-§2), not
from the RTL.  Element arithmetic and every reduction add use Berkeley
SoftFloat-3e through fp32_softfloat.

A command is a dict: op, rm, vl, vm, bcast (bit0 a, bit1 b, bit2 c), scalar,
red, tid, plus per-element operand lists a, b, c and mask (len >= vl).
``expect(cmd, N)`` returns (result_beats, completion):
  result beat  = (tid, beat, last, data[N], flags[N], mask[N])
  completion   = (tid, flags, illegal, count, red, result)
"""
from __future__ import annotations

from . import fp32_softfloat as SF

FCMP = {0x08, 0x09, 0x0A, 0x0B, 0x0C}
INT = {0x10, 0x11}


def legal(cmd, *, red_en=True, en_fcmp=True, en_int=True) -> bool:
    op, rm, red = cmd["op"], cmd["rm"], cmd["red"]
    if op not in SF.LEGAL_OPS:
        return False
    if op in FCMP and not en_fcmp:
        return False
    if op in INT and not en_int:
        return False
    if 0x01 <= op <= 0x07 and rm > 4:
        return False
    if red:
        if not red_en or not (0x00 <= op <= 0x07) or rm > 4 or cmd["bcast"] != 0:
            return False
    return True


def beats(vl: int, n: int) -> int:
    return (vl + n - 1) // n


def _element(cmd, e):
    a = cmd["scalar"] if cmd["bcast"] & 1 else cmd["a"][e]
    b = cmd["scalar"] if cmd["bcast"] & 2 else cmd["b"][e]
    c = cmd["scalar"] if cmd["bcast"] & 4 else cmd["c"][e]
    r, f, il = SF.op(cmd["op"], cmd["rm"], a, b, c)
    assert not il
    return r, f


def _add(x, y, rm):
    r, f, _ = SF.op(SF.FADD, rm, x, y, 0)
    return r, f


def _tree(leaves, rm):
    """pairwise tree over lane index; None = absent.  Returns (value|None, flags)."""
    fl = 0
    lvl = list(leaves)
    while len(lvl) > 1:
        nxt = []
        for i in range(0, len(lvl), 2):
            l, r = lvl[i], lvl[i + 1]
            if l is not None and r is not None:
                v, f = _add(l, r, rm)
                fl |= f
                nxt.append(v)
            else:
                nxt.append(l if l is not None else r)
        lvl = nxt
    return lvl[0], fl


def expect(cmd, n, *, red_en=True, en_fcmp=True, en_int=True):
    ok = legal(cmd, red_en=red_en, en_fcmp=en_fcmp, en_int=en_int)
    vl = cmd["vl"]
    nb = beats(vl, n)
    tid = cmd["tid"]
    out_beats = []
    cflags = 0
    count = 0
    acc = cmd["scalar"]
    for g in range(nb):
        data, flags, mask, leaves = [0] * n, [0] * n, [0] * n, [None] * n
        for l in range(n):
            e = g * n + l
            active = ok and e < vl and (not cmd["vm"] or cmd["mask"][e])
            if not active:
                continue
            r, f = _element(cmd, e)
            count += 1
            cflags |= f
            leaves[l] = r
            data[l], flags[l], mask[l] = r, f, 1
        if cmd["red"] and ok:
            s, f = _tree(leaves, cmd["rm"])
            cflags |= f
            if s is not None:
                acc, f2 = _add(acc, s, cmd["rm"])
                cflags |= f2
        elif not cmd["red"]:
            out_beats.append((tid, g, int(g == nb - 1), tuple(data), tuple(flags), tuple(mask)))
    if not ok:
        return out_beats, (tid, 0, 1, 0, cmd["red"], 0)
    return out_beats, (tid, cflags, 0, count, cmd["red"], acc if cmd["red"] else 0)


def operand_beats(cmd, n):
    """the operand beats a producer must send for ``cmd`` (framing rule: ceil(vl/N), whatever the command)."""
    out = []
    for g in range(beats(cmd["vl"], n)):
        a, b, c, m = [], [], [], 0
        for l in range(n):
            e = g * n + l
            a.append(cmd["a"][e])
            b.append(cmd["b"][e])
            c.append(cmd["c"][e])
            m |= (cmd["mask"][e] & 1) << l
        out.append({"a": sum(v << (32 * i) for i, v in enumerate(a)),
                    "b": sum(v << (32 * i) for i, v in enumerate(b)),
                    "c": sum(v << (32 * i) for i, v in enumerate(c)), "mask": m})
    return out
