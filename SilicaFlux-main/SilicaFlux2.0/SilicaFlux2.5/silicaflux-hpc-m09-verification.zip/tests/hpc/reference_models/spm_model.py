"""Byte-accurate reference model of hpc_scratchpad (Module 04).

Written from docs/01 (interface, commit semantics) and docs/02 (address map),
independently of the RTL decoder: arithmetic division / modulo, not bit
slicing.

* ``decode(addr)``  -> (code, bank, row, word): code 0 OK, 1 RANGE, 2 ALIGN,
  3 STROBE (priority RANGE > ALIGN > STROBE); every ADDR_WIDTH bit compared.
* ``Memory``: little-endian byte array with a per-byte "known" mask (the SRAM
  arrays are not reset; bytes never written have no defined value).
* ``issue_edge(reqs)``: applies all requests issued at one clock edge and
  returns the expected responses; checks the collision rule (no read+write or
  write+write of the same bank row at the same edge) and the bank port-model
  limit (1RW: 1 access, 1R1W: 1 read + 1 write, 2RW: 2 accesses per bank).
"""
from __future__ import annotations

PM_1RW, PM_1R1W, PM_2RW = 0, 1, 2
MAP_LOW, MAP_XOR, MAP_HIGH = 0, 1, 2
OK, RANGE, ALIGN, STROBE, PARITY = 0, 1, 2, 3, 4


class SpmConfig:
    def __init__(self, cap=65536, banks=2, dw=32, aw=32, base=0, byte_we=1, pmode=0, mapping=0, write_ack=1):
        self.cap, self.banks, self.dw, self.aw, self.base = cap, banks, dw, aw, base
        self.wb = dw // 8
        self.words = cap // self.wb
        self.depth = self.words // banks
        self.byte_we, self.pmode, self.map, self.write_ack = byte_we, pmode, mapping, write_ack


def decode(c: SpmConfig, addr: int, we: int = 0, wstrb: int = 0):
    addr &= (1 << c.aw) - 1
    if not (c.base <= addr < c.base + c.cap):
        return RANGE, None, None, None
    if addr % c.wb:
        return ALIGN, None, None, None
    full = (1 << c.wb) - 1
    if we and not c.byte_we and wstrb != full:
        return STROBE, None, None, None
    w = (addr - c.base) // c.wb
    if c.map == MAP_LOW:
        bank, row = w % c.banks, w // c.banks
    elif c.map == MAP_XOR:
        bank, row = (w % c.banks) ^ ((w // c.banks) % c.banks), w // c.banks
    else:
        bank, row = w // c.depth, w % c.depth
    return OK, bank, row, w


class Memory:
    def __init__(self, c: SpmConfig):
        self.c = c
        self.data = bytearray(c.cap)
        self.known = bytearray(c.cap)

    def write(self, w, wdata, wstrb):
        base = w * self.c.wb
        for k in range(self.c.wb):
            if (wstrb >> k) & 1:
                self.data[base + k] = (wdata >> (8 * k)) & 0xFF
                self.known[base + k] = 1

    def read(self, w):
        """returns (value, known_mask_bits) for the word."""
        base = w * self.c.wb
        v = m = 0
        for k in range(self.c.wb):
            v |= self.data[base + k] << (8 * k)
            if self.known[base + k]:
                m |= 0xFF << (8 * k)
        return v, m


def issue_edge(c: SpmConfig, mem: Memory, reqs):
    """reqs: list of (port, req) issued at this edge; req = dict(we, addr, wdata, wstrb, tag).
    Returns (responses: list of (port, expected dict | None), violations: list of str)."""
    viol = []
    dec = []
    for p, r in reqs:
        code, bank, row, w = decode(c, r["addr"], r["we"], r["wstrb"])
        dec.append((p, r, code, bank, row, w))
    # collision rule + port-model limit
    per_bank = {}
    rows = {}
    for p, r, code, bank, row, w in dec:
        if code:
            continue
        per_bank.setdefault(bank, []).append(r["we"])
        rows.setdefault((bank, row), []).append(r["we"])
    for b, wes in per_bank.items():
        nr, nw = wes.count(0), wes.count(1)
        if c.pmode == PM_1RW and len(wes) > 1:
            viol.append(f"bank {b}: {len(wes)} accesses at one edge (1RW allows 1)")
        if c.pmode == PM_1R1W and (nr > 1 or nw > 1):
            viol.append(f"bank {b}: {nr} reads + {nw} writes at one edge (1R1W allows 1 + 1)")
        if c.pmode == PM_2RW and len(wes) > 2:
            viol.append(f"bank {b}: {len(wes)} accesses at one edge (2RW allows 2)")
    for (b, row), wes in rows.items():
        if len(wes) > 1 and any(wes):
            viol.append(f"bank {b} row {row}: {len(wes)} same-row accesses incl. a write at one edge")
    out = []
    # reads see the array before this edge's writes (never the same row, see above)
    for p, r, code, bank, row, w in dec:
        if code:
            out.append((p, {"rdata": 0, "mask": (1 << c.dw) - 1, "err": 1, "code": code, "we": r["we"],
                            "tag": r["tag"]}))
        elif not r["we"]:
            v, m = mem.read(w)
            out.append((p, {"rdata": v, "mask": m, "err": 0, "code": 0, "we": 0, "tag": r["tag"]}))
    for p, r, code, bank, row, w in dec:
        if not code and r["we"]:
            mem.write(w, r["wdata"], r["wstrb"])
            if c.write_ack:
                out.append((p, {"rdata": 0, "mask": (1 << c.dw) - 1, "err": 0, "code": 0, "we": 1, "tag": r["tag"]}))
    # keep per-port order: responses are produced in issue order per port (one issue per port per edge)
    return out, viol
