"""Primary FP32 oracle: Berkeley SoftFloat-3e (RISCV specialisation) through ctypes.

Host-language float arithmetic is never used: Python's ``a*b+c`` rounds twice,
and neither the host's rounding mode nor its exception flags are controllable.
Every result here comes from SoftFloat's integer-only implementation.
"""
from __future__ import annotations

import ctypes
import os
import subprocess
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
BUILD = Path(os.environ.get("HPC_BUILD", HPC / "build")).resolve()
LIB = BUILD / "ref/libhpcsf.so"

# hpc_vector_pkg opcodes (Module 02)
FMV, FADD, FSUB, FMUL, FMADD, FMSUB, FNMSUB, FNMADD = range(8)
FMIN, FMAX, FEQ, FLT, FLE = 0x08, 0x09, 0x0A, 0x0B, 0x0C
IADD, IMUL = 0x10, 0x11
LEGAL_OPS = [FMV, FADD, FSUB, FMUL, FMADD, FMSUB, FNMSUB, FNMADD, FMIN, FMAX, FEQ, FLT, FLE, IADD, IMUL]
ROUNDING_OPS = [FADD, FSUB, FMUL, FMADD, FMSUB, FNMSUB, FNMADD]
OP_NAMES = {FMV: "FMV", FADD: "FADD", FSUB: "FSUB", FMUL: "FMUL", FMADD: "FMADD", FMSUB: "FMSUB",
            FNMSUB: "FNMSUB", FNMADD: "FNMADD", FMIN: "FMIN", FMAX: "FMAX", FEQ: "FEQ", FLT: "FLT",
            FLE: "FLE", IADD: "IADD", IMUL: "IMUL"}
RNE, RTZ, RDN, RUP, RMM = range(5)
RM_NAMES = {0: "RNE", 1: "RTZ", 2: "RDN", 3: "RUP", 4: "RMM"}
NV, DZ, OF, UF, NX = 16, 8, 4, 2, 1
CNAN = 0x7FC00000

_lib = None


def _load():
    global _lib
    if _lib is None:
        if not LIB.exists():
            subprocess.run(["bash", str(HPC / "reference_models/softfloat/build_ref.sh")], check=True,
                           stdout=subprocess.DEVNULL)
        lib = ctypes.CDLL(str(LIB))
        lib.hpcsf_op.restype = ctypes.c_uint32
        lib.hpcsf_op.argtypes = [ctypes.c_uint, ctypes.c_uint, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32,
                                 ctypes.c_uint, ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(ctypes.c_uint)]
        lib.hpcsf_version.restype = ctypes.c_char_p
        _lib = lib
    return _lib


def op(opc: int, rm: int, a: int, b: int = 0, c: int = 0, tininess_after: bool = True):
    """Execute one lane operation. Returns (result, flags, illegal)."""
    lib = _load()
    f = ctypes.c_uint(0)
    il = ctypes.c_uint(0)
    r = lib.hpcsf_op(opc & 0xFF, rm & 7, a & 0xFFFFFFFF, b & 0xFFFFFFFF, c & 0xFFFFFFFF,
                     1 if tininess_after else 0, ctypes.byref(f), ctypes.byref(il))
    return int(r), int(f.value), int(il.value)


def add(a, b, rm=RNE):
    r, f, _ = op(FADD, rm, a, b)
    return r, f


def mul(a, b, rm=RNE):
    r, f, _ = op(FMUL, rm, a, b)
    return r, f


def fma(a, b, c, rm=RNE):
    r, f, _ = op(FMADD, rm, a, b, c)
    return r, f


def version() -> str:
    return _load().hpcsf_version().decode()


# ----------------------------------------------------------------- classification helpers
def is_nan(x):  return (x & 0x7F800000) == 0x7F800000 and (x & 0x7FFFFF) != 0
def is_snan(x): return is_nan(x) and not (x & 0x400000)
def is_inf(x):  return (x & 0x7FFFFFFF) == 0x7F800000
def is_zero(x): return (x & 0x7FFFFFFF) == 0
def is_sub(x):  return (x & 0x7F800000) == 0 and (x & 0x7FFFFF) != 0


def fclass(x: int) -> str:
    s = "-" if x >> 31 else "+"
    if is_snan(x):
        return "snan"
    if is_nan(x):
        return "qnan"
    if is_inf(x):
        return s + "inf"
    if is_zero(x):
        return s + "zero"
    if is_sub(x):
        return s + "sub"
    return s + "norm"


FCLASSES = ["+zero", "-zero", "+sub", "-sub", "+norm", "-norm", "+inf", "-inf", "qnan", "snan"]
