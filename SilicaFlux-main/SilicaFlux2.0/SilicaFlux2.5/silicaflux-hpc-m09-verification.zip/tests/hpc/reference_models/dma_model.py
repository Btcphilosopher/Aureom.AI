"""Reference model of hpc_dma_adapter (Module 05) transfers, written from
docs/01 §5 (completion codes), docs/02 (address spaces, region rule, tails) and
docs/03 (completion and error semantics).

Codes: 0 NONE, 1 ZERO_LENGTH, 2 LENGTH, 3 SRC_ALIGN, 4 DST_ALIGN, 5 SRC_OVERFLOW,
6 DST_OVERFLOW, 7 OVERLAP, 8 READ_BUS, 9 WRITE_BUS, 10 ABORTED, 11 REGION.
Rules 1-7 are checked first, in that order, then REGION.
"""
from __future__ import annotations

NONE, ZERO_LENGTH, LENGTH, SRC_ALIGN, DST_ALIGN, SRC_OVERFLOW, DST_OVERFLOW, OVERLAP = range(8)
READ_BUS, WRITE_BUS, ABORTED, REGION = 8, 9, 10, 11
NAMES = ["NONE", "ZERO_LENGTH", "LENGTH", "SRC_ALIGN", "DST_ALIGN", "SRC_OVERFLOW", "DST_OVERFLOW", "OVERLAP",
         "READ_BUS", "WRITE_BUS", "ABORTED", "REGION"]


def validate(src, dst, length, *, wb=4, max_len_log2=24, spm_base=0x20000000, spm_bytes=65536):
    """-> (code, err_addr) for the checks performed before any bus access."""
    if length == 0:
        return ZERO_LENGTH, 0
    if length > (1 << max_len_log2):
        return LENGTH, 0
    if src % wb:
        return SRC_ALIGN, 0
    if dst % wb:
        return DST_ALIGN, 0
    if src + length > 1 << 32:
        return SRC_OVERFLOW, 0
    if dst + length > 1 << 32:
        return DST_OVERFLOW, 0
    if src < dst + length and dst < src + length:
        return OVERLAP, 0
    lo, hi = spm_base, spm_base + spm_bytes
    for a in (src, dst):
        e = a + length                         # exclusive end
        inside_start = lo <= a < hi
        inside_end = lo < e <= hi
        if inside_start and not inside_end:
            return REGION, hi                  # leaves the window
        if not inside_start and (a < lo < e):
            return REGION, lo                  # enters the window from below
    return NONE, 0


def in_spm(a, spm_base=0x20000000, spm_bytes=65536):
    return spm_base <= a < spm_base + spm_bytes


def beats(length, wb=4):
    return (length + wb - 1) // wb


def copy(mem_read, mem_write, src, dst, length, wb=4, upto_beats=None):
    """byte-accurate copy of [src, src+len) to [dst, dst+len) (last word: only bytes < len)."""
    nb = beats(length, wb)
    if upto_beats is not None:
        nb = min(nb, upto_beats)
    for k in range(nb):
        for j in range(wb):
            off = k * wb + j
            if off >= length:
                break
            mem_write(dst + off, mem_read(src + off))
    return min(length, nb * wb)
