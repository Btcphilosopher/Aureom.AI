#!/usr/bin/env python3
"""Validate the golden FP32 model before any RTL is compared against it.

Three implementations must agree bit-exactly (result, 5 flags, illegal) on every
vector, for every lane operation and every rounding mode:

  1. Berkeley SoftFloat-3e, RISCV specialisation  (primary oracle, C)
  2. exact integer arithmetic + GNU MPFR rounding  (this framework, independent)
  3. Module 02's exact rational model ref/fp32_ref.py (RTL author's executable spec)

It also proves that the directed ``fma_single_rounding`` vectors discriminate:
the fused result must differ from the double-rounded (FMUL then FADD) result
on at least one vector per FMA form and rounding mode family.

usage: fp32_crosscheck.py [--n N] [--seed S] [--out reports/fp32/oracle_crosscheck.json]
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import sys
import time
from collections import Counter
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(HPC), str(HPC / "lib")]
from reference_models import fp32_mpfr as MP  # noqa: E402
from reference_models import fp32_softfloat as SF  # noqa: E402
from hpcv import fpgen  # noqa: E402


def load_m02_model():
    sys.path.insert(0, str(HPC / "common"))
    import filelists as FL
    p = FL.M02 / "ref/fp32_ref.py"
    spec = importlib.util.spec_from_file_location("m02_fp32_ref", p)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m, p


def m02_exec(m, op, rm, a, b, c):
    r = m.execute(op, rm, a, b, c)
    # execute() returns (result, flags, illegal) in Module 02
    if isinstance(r, tuple) and len(r) >= 3:
        return int(r[0]), int(r[1]), int(r[2])
    raise RuntimeError(f"unexpected M02 model return: {r!r}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=60000, help="random vectors (spread over ops and modes)")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", default=str(HPC / "reports/fp32/oracle_crosscheck.json"))
    a = ap.parse_args()
    m02, m02p = load_m02_model()
    vecs = fpgen.directed() + fpgen.random_vectors(a.n, a.seed, SF.LEGAL_OPS)
    t0 = time.time()
    mism = []
    per_op = Counter()
    per_cat = Counter()
    for (op, rm, x, y, z, cat) in vecs:
        s = SF.op(op, rm, x, y, z)
        m = MP.execute(op, rm, x, y, z)
        e = m02_exec(m02, op, rm, x, y, z)
        per_op[SF.OP_NAMES.get(op, hex(op))] += 1
        per_cat[cat] += 1
        if not (s == m == e):
            mism.append({"op": op, "rm": rm, "a": f"{x:08x}", "b": f"{y:08x}", "c": f"{z:08x}", "cat": cat,
                         "softfloat": [f"{v:x}" for v in s], "mpfr": [f"{v:x}" for v in m],
                         "m02_model": [f"{v:x}" for v in e]})
    # discrimination of the FMA single-rounding vectors
    disc = Counter()
    for (op, rm, x, y, z, cat) in vecs:
        if cat != "fma_single_rounding":
            continue
        fused = SF.op(op, rm, x, y, z)[0]
        pa = x ^ (0x80000000 if op in (6, 7) else 0)
        pc = z ^ (0x80000000 if op in (5, 7) else 0)
        p, _, _ = SF.op(SF.FMUL, rm, pa, y, 0)
        two = SF.op(SF.FADD, rm, p, pc, 0)[0]
        if fused != two:
            disc[f"{SF.OP_NAMES[op]}/{SF.RM_NAMES[rm]}"] += 1
    need = [f"{SF.OP_NAMES[o]}/{SF.RM_NAMES[r]}" for o in (4, 5, 6, 7) for r in range(5)]
    missing = [k for k in need if disc[k] == 0]
    res = {"vectors": len(vecs), "random": a.n, "seed": a.seed, "directed": len(vecs) - a.n,
           "mismatches": len(mism), "first_mismatches": mism[:20], "per_op": dict(per_op),
           "per_category": dict(per_cat), "fma_discriminating": dict(disc),
           "fma_discrimination_missing": missing,
           "oracles": [SF.version(), MP.version(), f"Module 02 exact model {m02p.name}"],
           "seconds": round(time.time() - t0, 1)}
    ok = not mism and not missing
    res["status"] = "PASS" if ok else "FAIL"
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(res, indent=2) + "\n")
    print(f"oracle cross-check: {len(vecs)} vectors, {len(mism)} mismatches, "
          f"FMA single-rounding discriminating in {len(need) - len(missing)}/{len(need)} op/mode pairs "
          f"-> {res['status']} ({res['seconds']} s)")
    for x in mism[:5]:
        print("  MISMATCH", x)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
