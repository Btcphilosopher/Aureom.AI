#!/usr/bin/env python3
"""SilicaFlux-HPC regression runner.

Runs the selected suites for one matrix, then merges coverage and writes the
verification report.  Exit status 1 if any test FAILED (BLOCKED and SKIP do
not fail a regression; they are reported).

  ci       small mandatory matrix (every push / pull request)
  nightly  extended matrix: all parameter configurations, more seeds, stall
           patterns, Icarus 4-state runs, TestFloat level 2, full module
           regressions, the complete mutation campaign

usage: run_regression.py [--matrix ci|nightly] [--suites a,b,...] [--seed N] [--keep-results] [--no-report]
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import results as R, sim  # noqa: E402

SUITES = {
    "fp32": ["fp32/run_fp32.py"],
    "vector_lane": ["vector_lane/run_vector_lane.py"],
    "vector_array": ["vector_array/run_vector_array.py"],
    "scratchpad": ["scratchpad/run_scratchpad.py"],
    "dma": ["dma/run_dma.py"],
    "command_queue": ["command_queue/run_command_queue.py"],
    "perf_counters": ["perf_counters/run_perf_counters.py"],
    "tile_integration": ["tile_integration/run_tile_integration.py"],
    "formal": ["formal/run_formal.py"],
    "legacy": ["regression/legacy.py"],
    "mutation": ["regression/mutants.py"],
}
GROUPS = {
    "all": list(SUITES),
    "sim": ["fp32", "vector_lane", "vector_array", "scratchpad", "dma", "command_queue", "perf_counters",
            "tile_integration"],
    "test": ["fp32", "vector_lane", "vector_array", "scratchpad", "dma", "command_queue", "perf_counters",
             "tile_integration", "formal"],
    "fp32": ["fp32"], "vector": ["vector_lane", "vector_array", "command_queue"], "memory": ["scratchpad"],
    "dma": ["dma"], "integration": ["tile_integration", "perf_counters"], "formal": ["formal"],
    "cmdq": ["command_queue"], "perf": ["perf_counters"], "legacy": ["legacy"], "mutation": ["mutation"],
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default=os.environ.get("HPC_MATRIX", "ci"), choices=["ci", "nightly"])
    ap.add_argument("--suites", default="all", help="comma list of suites or groups: " + ", ".join(GROUPS))
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    ap.add_argument("--keep-results", action="store_true", help="do not clear earlier result records")
    ap.add_argument("--no-report", action="store_true")
    a = ap.parse_args()
    sel = []
    for s in a.suites.split(","):
        for x in GROUPS.get(s, [s]):
            if x not in SUITES:
                sys.exit(f"unknown suite {x}")
            if x not in sel:
                sel.append(x)
    rc = subprocess.run([sys.executable, str(HPC / "common/fetch_rtl.py")]).returncode
    if rc:
        sys.exit(f"RTL fetch / provenance check failed (exit {rc})")
    sim.ensure_ref()
    if not a.keep_results:
        for s in sel:
            shutil.rmtree(R.RESULTS / s, ignore_errors=True)
    meta = {"matrix": a.matrix, "suites": sel, "seed": a.seed, "started": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "tools": sim.tool_versions(), "argv": sys.argv}
    env = dict(os.environ, HPC_SEED=str(a.seed))
    timings = {}
    for s in sel:
        t0 = time.time()
        print(f"\n######## suite {s} ({a.matrix})", flush=True)
        cmd = [sys.executable, str(HPC / SUITES[s][0]), "--matrix", a.matrix]
        if s not in ("legacy", "mutation", "formal"):
            cmd += ["--seed", str(a.seed)] if s not in ("fp32",) else ["--seed-base", str(a.seed)]
        r = subprocess.run(cmd, cwd=HPC, env=env)
        timings[s] = {"seconds": round(time.time() - t0, 1), "exit": r.returncode}
        if r.returncode != 0:
            R.record("runner", f"{s}_exit", "FAIL", reason=f"suite runner exited {r.returncode}",
                     repro=R.repro_cmd(cmd, cwd="tests/hpc"))
    meta["finished"] = time.strftime("%Y-%m-%dT%H:%M:%S%z")
    meta["timings"] = timings
    (sim.BUILD / "regression_meta.json").write_text(json.dumps(meta, indent=1))
    if not a.no_report:
        subprocess.run([sys.executable, str(HPC / "regression/coverage.py")], cwd=HPC)
        subprocess.run([sys.executable, str(HPC / "regression/make_report.py")], cwd=HPC)
    recs = [r for r in R.load_all() if r["suite"] in sel or r["suite"] == "runner"]
    fails = [r for r in recs if r["status"] == "FAIL" and not (r.get("metrics") or {}).get("known_survivor")]
    known = [r for r in recs if r["status"] == "FAIL" and (r.get("metrics") or {}).get("known_survivor")]
    n = {k: sum(1 for r in recs if r["status"] == k) for k in ("PASS", "FAIL", "BLOCKED", "SKIP")}
    print(f"\n== regression {a.matrix}: {len(recs)} records  PASS {n['PASS']}  FAIL {n['FAIL']}  "
          f"BLOCKED {n['BLOCKED']}  SKIP {n['SKIP']}"
          + (f"  (of the FAILs, {len(known)} documented surviving mutant(s): framework gaps, not RTL failures)"
             if known else ""))
    for f in fails[:20]:
        print(f"   FAIL {f['suite']}/{f['name']}: {(f.get('reason') or '')[:120]}")
        if f.get("repro"):
            print(f"        repro: {f['repro']}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
