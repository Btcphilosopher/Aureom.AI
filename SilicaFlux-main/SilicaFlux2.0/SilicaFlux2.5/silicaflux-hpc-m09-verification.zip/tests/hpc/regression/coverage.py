#!/usr/bin/env python3
"""Coverage from collected data only (brief §11).

1. RTL line coverage: every coverage.dat written by the Verilator cocotb runs
   (HPC_COVERAGE=1) is merged with verilator_coverage and converted to lcov;
   lines found / hit are summed per RTL file and per module.  Only DUT RTL is
   counted (framework testbench files are excluded).  The FP32 C++ harness is
   not instrumented; its evidence is the vector counts and the functional bins.
2. Functional coverage: goal bins defined below, hit counts taken from the
   per-test records (metrics.json / FP32 coverage.json).  Bins that are
   infeasible by construction are excluded with the reason stated.

Writes build/coverage/coverage.json (consumed by make_report.py).
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
from collections import defaultdict
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import results as R, sim  # noqa: E402

OUT = sim.BUILD / "coverage"
MODULE_OF = [("silicaflux-hpc-m02-vector-lane/rtl", "M02 vector lane (+FP32 units)"),
             ("m03_obs", "M03 vector array (M07 obs. variant)"),
             ("silicaflux-hpc-m03-vector-array/rtl", "M03 vector array"),
             ("silicaflux-hpc-m04-scratchpad/rtl", "M04 scratchpad"),
             ("silicaflux-hpc-m05-dma-adapter/rtl", "M05 DMA adapter + tile sequencer"),
             ("silicaflux-sramlib", "SRAM wrapper library (vendored)"),
             ("silicaflux-datafabric/rtl", "DataFabric DMA engines (vendored)"),
             ("silicaflux-hpc-m07-perf-counters/rtl", "M07 performance counters"),
             ("silicaflux-hpc-fp32-fma/rtl", "M01 fp32_fma")]


def line_coverage():
    dats = sorted(sim.BUILD.glob("runs/**/coverage.dat"))
    res = {"files": {}, "modules": {}, "dat_files": len(dats)}
    if not dats or not shutil.which("verilator_coverage"):
        res["note"] = "no coverage.dat collected" if not dats else "verilator_coverage not installed"
        return res
    OUT.mkdir(parents=True, exist_ok=True)
    merged = OUT / "merged.dat"
    info = OUT / "merged.info"
    subprocess.run(["verilator_coverage", "--write", str(merged)] + [str(d) for d in dats], check=True,
                   capture_output=True)
    subprocess.run(["verilator_coverage", "--write-info", str(info), str(merged)], check=True, capture_output=True)
    cur = None
    files = defaultdict(lambda: {"found": 0, "hit": 0, "lines": {}})
    for line in info.read_text().splitlines():
        if line.startswith("SF:"):
            cur = line[3:]
        elif line.startswith("DA:") and cur:
            ln, cnt = line[3:].split(",")[:2]
            prev = files[cur]["lines"].get(ln, 0)
            files[cur]["lines"][ln] = max(prev, int(cnt))
    mods = defaultdict(lambda: {"found": 0, "hit": 0, "files": 0})
    for f, d in files.items():
        if "/tests/hpc/" in f and "/build/src/" not in f:
            continue                                   # framework testbench / checker files
        if "/tb/" in f:
            continue
        found = len(d["lines"])
        hit = sum(1 for c in d["lines"].values() if c > 0)
        rel = f.split("/build/src/")[-1]
        res["files"][rel] = {"found": found, "hit": hit, "pct": round(100.0 * hit / found, 1) if found else None}
        for key, name in MODULE_OF:
            if key in f:
                mods[name]["found"] += found
                mods[name]["hit"] += hit
                mods[name]["files"] += 1
                break
    for name, d in mods.items():
        d["pct"] = round(100.0 * d["hit"] / d["found"], 1) if d["found"] else None
    res["modules"] = dict(sorted(mods.items()))
    tf = sum(d["found"] for d in mods.values())
    th = sum(d["hit"] for d in mods.values())
    res["total"] = {"found": tf, "hit": th, "pct": round(100.0 * th / tf, 1) if tf else None}
    return res


# ------------------------------------------------------------------ functional coverage
ROUND = {1: "FADD", 2: "FSUB", 3: "FMUL", 4: "FMADD", 5: "FMSUB", 6: "FNMSUB", 7: "FNMADD"}
NONROUND = {0: "FMV", 8: "FMIN", 9: "FMAX", 10: "FEQ", 11: "FLT", 12: "FLE", 16: "IADD", 17: "IMUL"}
CLS = ["+zero", "-zero", "+sub", "-sub", "+norm", "-norm", "+inf", "-inf", "qnan", "snan"]
FLAGS = ["NX", "UF", "OF", "DZ", "NV", "exact"]


def fp32_functional():
    agg = {"op_rm": defaultdict(lambda: [0] * 8), "op_flag": defaultdict(lambda: [0] * 6),
           "op_cls": defaultdict(lambda: [[0] * 10 for _ in range(3)]), "op_res": defaultdict(lambda: [0] * 10)}
    n = 0
    for f in sim.BUILD.glob("runs/fp32/**/coverage.json"):
        d = json.loads(f.read_text())
        n += 1
        for op, v in d.get("op_rm", {}).items():
            agg["op_rm"][int(op)] = [a + b for a, b in zip(agg["op_rm"][int(op)], v)]
        for op, v in d.get("op_flag", {}).items():
            agg["op_flag"][int(op)] = [a + b for a, b in zip(agg["op_flag"][int(op)], v)]
        for op, v in d.get("op_cls", {}).items():
            agg["op_cls"][int(op)] = [[a + b for a, b in zip(x, y)] for x, y in zip(agg["op_cls"][int(op)], v)]
        for op, v in d.get("op_res", {}).items():
            agg["op_res"][int(op)] = [a + b for a, b in zip(agg["op_res"][int(op)], v)]
    groups = {}
    # op x rounding mode (rounding operations)
    bins = {f"{ROUND[o]}/rm{r}": agg["op_rm"][o][r] for o in ROUND for r in range(5)}
    groups["fp32: operation x rounding mode"] = (bins, {})
    # op x exception flag (DZ never: no division; FADD/FSUB UF infeasible: a sum/difference whose
    # result is tiny is always exact (Hauser), so UF (tiny AND inexact) cannot occur)
    bins, excl = {}, {}
    for o in ROUND:
        for k, fl in enumerate(FLAGS):
            key = f"{ROUND[o]}/{fl}"
            if fl == "DZ":
                excl[key] = "no division in the tile: DZ is never raised"
            elif fl == "UF" and o in (1, 2):
                excl[key] = "infeasible: a tiny sum or difference is always exact"
            else:
                bins[key] = agg["op_flag"][o][k]
    for o in (8, 9, 10, 11, 12):
        bins[f"{NONROUND[o]}/NV"] = agg["op_flag"][o][4]
        bins[f"{NONROUND[o]}/no-flag"] = agg["op_flag"][o][5]
    groups["fp32: operation x exception flag"] = (bins, excl)
    # operand classes per operand position actually read by the operation
    bins = {}
    pos = {1: 2, 2: 2, 3: 2, 4: 3, 5: 3, 6: 3, 7: 3, 8: 2, 9: 2, 10: 2, 11: 2, 12: 2}
    names = {**ROUND, **NONROUND}
    for o, npos in pos.items():
        for p in range(npos):
            for c, cn in enumerate(CLS):
                bins[f"{names[o]}/{'abc'[p]}={cn}"] = agg["op_cls"][o][p][c]
    groups["fp32: operand class x position"] = (bins, {})
    # result classes of the arithmetic operations (sNaN never produced: canonical quiet NaN)
    bins, excl = {}, {}
    for o in ROUND:
        for c, cn in enumerate(CLS):
            key = f"{ROUND[o]}/result={cn}"
            if cn == "snan":
                excl[key] = "canonical NaN policy: arithmetic never returns a signalling NaN"
            else:
                bins[key] = agg["op_res"][o][c]
    groups["fp32: result class"] = (bins, excl)
    return groups, n


def record_bins():
    """functional bins from the per-test metrics of the cocotb suites."""
    recs = [r for r in R.load_all() if r["status"] in ("PASS", "FAIL")]
    g = {}

    def hit(group, key, cond):
        g.setdefault(group, ({}, {}))[0][key] = g.get(group, ({}, {}))[0].get(key, 0) + (1 if cond else 0)

    lane_ops = defaultdict(int)
    for r in recs:
        m = r.get("metrics") or {}
        if r["suite"] == "vector_lane":
            for k, v in (m.get("coverage_ops") or {}).items():
                lane_ops[k] += v
            ev = m.get("events") or {}
            for e in ("pipe_stall", "bp", "masked", "illegal"):
                hit("lane: events observed", e, ev.get(e, 0) > 0)
    for op in ["FMV", "FADD", "FSUB", "FMUL", "FMADD", "FMSUB", "FNMSUB", "FNMADD", "FMIN", "FMAX", "FEQ", "FLT",
               "FLE", "IADD", "IMUL", "illegal"]:
        hit("lane: operations retired", op, lane_ops.get(op, 0) > 0)
    va = defaultdict(int)
    for r in recs:
        if r["suite"] in ("vector_array", "command_queue"):
            cov = (r.get("metrics") or {}).get("coverage") or {}
            for k, v in (cov.get("ops") or {}).items():
                va[k] += v
            for k in ("vl0", "masked", "bcast", "red", "illegal"):
                va["#" + k] += cov.get(k, 0)
    for op in ["FADD", "FMUL", "FMADD", "FSUB", "FMV", "FMIN", "FMAX", "FEQ", "FLT", "FLE", "IADD", "IMUL",
               "FMSUB", "FNMSUB", "FNMADD"]:
        hit("array: elementwise operations", op, va.get(op, 0) > 0)
    for op in ["FMV/red", "FMUL/red", "FADD/red", "FMADD/red"]:
        hit("array: reductions (sum, dot, others)", op, va.get(op, 0) > 0)
    for k in ("vl0", "masked", "bcast", "illegal"):
        hit("array: command features", k, va.get("#" + k, 0) > 0)
    cfgs = {(r["config"] or {}).get("NUM_LANES", (r["config"] or {}).get("N")) for r in recs
            if r["suite"] in ("vector_array", "command_queue", "tile_integration")}
    for n in (1, 2, 4, 8):
        hit("array: lane counts exercised", f"N={n}", n in cfgs)
    sp_codes, sp_stats, sp_banks, sp_modes = defaultdict(int), defaultdict(int), set(), set()
    for r in recs:
        if r["suite"] != "scratchpad":
            continue
        m = r.get("metrics") or {}
        for k, v in (m.get("codes") or {}).items():
            sp_codes[k] += v
        for k, v in (m.get("stats") or {}).items():
            if isinstance(v, int):
                sp_stats[k] += v
        c = r.get("config") or {}
        sp_banks.add(c.get("NUM_BANKS"))
        sp_modes.add(c.get("PORT_MODE"))
    for k in ("ok", "range", "align", "strobe"):
        hit("scratchpad: response codes", k, sp_codes.get(k, 0) > 0)
    for k in ("conflicts", "credit_stalls", "rsp_bp_cycles", "writes", "reads"):
        hit("scratchpad: behaviours observed", k, sp_stats.get(k, 0) > 0)
    for b in (1, 2, 4, 8):
        hit("scratchpad: bank counts exercised", f"banks={b}", b in sp_banks)
    for pm, nm in ((0, "1RW"), (1, "1R1W"), (2, "2RW")):
        hit("scratchpad: port models exercised", nm, pm in sp_modes)
    dcodes, ddirs = defaultdict(int), defaultdict(int)
    for r in recs:
        if r["suite"] not in ("dma", "command_queue", "tile_integration"):
            continue
        m = r.get("metrics") or {}
        for k, v in (m.get("codes") or m.get("dma_codes") or {}).items():
            dcodes[k] += v
        for k, v in (m.get("directions") or {}).items():
            ddirs[k] += v
    for k in ["NONE", "ZERO_LENGTH", "LENGTH", "SRC_ALIGN", "DST_ALIGN", "SRC_OVERFLOW", "DST_OVERFLOW", "OVERLAP",
              "READ_BUS", "WRITE_BUS", "ABORTED", "REGION"]:
        hit("dma: completion codes", k, dcodes.get(k, 0) > 0)
    for k in ("ext->spm", "spm->ext", "spm->spm", "ext->ext"):
        hit("dma: directions", k, ddirs.get(k, 0) > 0)
    kern = {r["name"].split("/")[2] for r in recs if r["suite"] == "tile_integration" and r["status"] == "PASS"
            and r["name"].count("/") >= 3}
    for k in ("test_A_vector_add", "test_B_vector_mul", "test_C_vector_fma", "test_E_dma_assisted_axpy",
              "test_F_multi_command_sequence"):
        hit("tile: kernels passing", k, k in kern)
    return g


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    lc = line_coverage()
    fg, nfp = fp32_functional()
    rg = record_bins()
    groups = {}
    for name, (bins, excl) in list(fg.items()) + list(rg.items()):
        hitn = sum(1 for v in bins.values() if v)
        groups[name] = {"bins": len(bins), "hit": hitn, "pct": round(100.0 * hitn / len(bins), 1) if bins else None,
                        "missed": sorted(k for k, v in bins.items() if not v), "excluded": excl}
    out = {"line": lc, "functional": groups, "fp32_coverage_files": nfp}
    (OUT / "coverage.json").write_text(json.dumps(out, indent=1))
    t = lc.get("total") or {}
    print(f"line coverage: {t.get('hit')}/{t.get('found')} = {t.get('pct')}% over {lc.get('dat_files')} runs")
    for k, v in groups.items():
        print(f"  {k}: {v['hit']}/{v['bins']} = {v['pct']}%  missed {v['missed'][:6]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
