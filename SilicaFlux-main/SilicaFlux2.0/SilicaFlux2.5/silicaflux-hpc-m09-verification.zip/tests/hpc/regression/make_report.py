#!/usr/bin/env python3
"""Generate the verification report from result records (brief §11).

Inputs (all written by actual runs): build/results/**.json, build/rtl_revision.json,
build/regression_meta.json, build/coverage/coverage.json, build/runs/mutation_summary.json.
Outputs: reports/VERIFICATION_REPORT.md, reports/results.json, reports/junit.xml.
Nothing in the report is typed by hand: counts, percentages, seeds, versions and
revisions are read from those files.
"""
from __future__ import annotations

import json
import os
import sys
import time
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import results as R, sim  # noqa: E402

REPORTS = Path(os.environ.get("HPC_REPORTS", HPC / "reports"))
ORDER = ["fp32", "vector_lane", "vector_array", "scratchpad", "dma", "command_queue", "perf_counters",
         "tile_integration", "formal", "legacy", "mutation", "runner"]


def rel(p):
    if not p:
        return ""
    s = str(p)
    for root in (str(HPC.parent.parent) + "/", str(HPC) + "/"):
        if s.startswith(root):
            return s[len(root):]
    return s


def load(p, default=None):
    try:
        return json.loads(Path(p).read_text())
    except Exception:
        return default if default is not None else {}


def main():
    recs = R.load_all()
    REPORTS.mkdir(parents=True, exist_ok=True)
    rev = load(sim.BUILD / "rtl_revision.json")
    meta = load(sim.BUILD / "regression_meta.json")
    cov = load(sim.BUILD / "coverage/coverage.json")
    mut = load(sim.BUILD / "runs/mutation_summary.json")
    tools = meta.get("tools") or sim.tool_versions()
    by = defaultdict(list)
    for r in recs:
        by[r["suite"]].append(r)
    suites = [s for s in ORDER if s in by] + sorted(s for s in by if s not in ORDER)
    tot = Counter(r["status"] for r in recs)
    L = []
    w = L.append
    w("# SilicaFlux-HPC compute tile — verification report")
    w("")
    w(f"Generated {time.strftime('%Y-%m-%d %H:%M %Z')} by `tests/hpc/regression/make_report.py` from the result records "
      f"of the last run (matrix **{meta.get('matrix', 'n/a')}**, base seed {meta.get('seed', 'n/a')}). "
      "Every figure below is read from files written by that run.")
    w("")
    w("## 1. Summary")
    w("")
    w(f"| Test cases | Passed | Failed | Blocked | Skipped / not applicable |")
    w("|---|---|---|---|---|")
    w(f"| **{len(recs)}** | **{tot['PASS']}** | **{tot['FAIL']}** | **{tot['BLOCKED']}** | {tot['SKIP']} |")
    w("")
    ks = [r for r in recs if r["status"] == "FAIL" and (r.get("metrics") or {}).get("known_survivor")]
    rtl_fail = [r for r in recs if r["status"] == "FAIL" and r["suite"] not in ("mutation",)]
    w(f"Design-test failures (every suite except `mutation`): **{len(rtl_fail)}**. Failed `mutation` records are "
      f"defects the framework did not detect ({len(ks)} of them analysed and documented as known gaps in "
      "`docs/KNOWN_GAPS.md`); they measure the framework, not the RTL. Blocked = the RTL feature does not exist.")
    w("")
    w("| Suite | Cases | Pass | Fail | Blocked | Skip | Simulators | Wall time (s) |")
    w("|---|---|---|---|---|---|---|---|")
    for s in suites:
        c = Counter(r["status"] for r in by[s])
        sims = sorted({r.get("simulator") or "" for r in by[s]} - {""})
        secs = sum(r.get("duration_s") or 0 for r in by[s])
        w(f"| {s} | {len(by[s])} | {c['PASS']} | {c['FAIL']} | {c['BLOCKED']} | {c['SKIP']} | {', '.join(sims)} | "
          f"{secs:.0f} |")
    w("")
    # ----------------------------------------------------------------- provenance
    w("## 2. RTL revision and tools")
    w("")
    rp = rev.get("repository", {})
    w(f"* Repository commit `{rp.get('commit', 'unknown')}` ({rp.get('branch', '')}, {rp.get('date', '')}); "
      f"uncommitted changes to the module archives: {'none' if not rp.get('dirty_archives') else rp.get('dirty_archives')}.")
    w(f"* RTL digest (SHA-256 over every compiled RTL file): `{rev.get('rtl_digest', 'n/a')}` "
      f"({len(rev.get('rtl_files', {}))} files with their SHA-256 in `reports/rtl_revision.json`).")
    ic = rev.get("identity_checks", {})
    w(f"* Vendored RTL copies byte-identical to their canonical source: {ic.get('identical', '?')}/{ic.get('pairs', '?')}"
      f" (+{len(ic.get('allowed_differences', []))} documented difference(s): the Module 07 observation-port patch).")
    w("")
    w("| Archive | SHA-256 |")
    w("|---|---|")
    for k, a in (rev.get("archives") or {}).items():
        w(f"| {a.get('module', k)} — `{a.get('path')}` | `{a.get('sha256', '')[:16]}…` |")
    w("")
    w("| Tool | Version |")
    w("|---|---|")
    for k, v in tools.items():
        w(f"| {k} | {v} |")
    w("")
    # ----------------------------------------------------------------- failures
    fails = [r for r in recs if r["status"] == "FAIL"]
    w("## 3. Failed tests")
    w("")
    if not fails:
        w("None.")
    else:
        w("| Test | Seed | Reason | Waveform | Reproduce |")
        w("|---|---|---|---|---|")
        for r in fails:
            w(f"| {r['suite']}/{r['name']} | {r.get('seed')} | {(r.get('reason') or '')[:160].replace('|', '\\|')} | "
              f"{rel(r.get('waves'))} | `{(r.get('repro') or '')}` |")
    w("")
    # ----------------------------------------------------------------- blocked
    w("## 4. Blocked tests (not counted as passed)")
    w("")
    bl = [r for r in recs if r["status"] == "BLOCKED"]
    if not bl:
        w("None.")
    for r in bl:
        w(f"* **{r['suite']}/{r['name']}** — {r.get('reason')}")
    w("")
    # ----------------------------------------------------------------- per-area evidence
    w("## 5. Evidence by area")
    w("")
    fp = by.get("fp32", [])
    if fp:
        nvec = sum((r.get("metrics") or {}).get("vectors") or 0 for r in fp if r["name"] != "oracle_crosscheck")
        cc = next((r for r in fp if r["name"] == "oracle_crosscheck"), None)
        w("### 5.1 FP32 arithmetic")
        w("")
        if cc:
            m = cc.get("metrics") or {}
            w(f"* Golden-model validation: {m.get('vectors')} vectors, {m.get('mismatches')} mismatch(es) between "
              f"{'; '.join(m.get('oracles') or [])}.")
        w(f"* {nvec:,} operations compared bit-exactly (result incl. NaN encoding, 5 flags, id/tag) against "
          "SoftFloat-3e across the FP32 suite; TestFloat-3e streams additionally checked by `testfloat_ver` on the "
          "DUT outputs.")
        tf = [r for r in fp if "/testfloat/" in r["name"]]
        if tf:
            w(f"* TestFloat runs: {len(tf)} ({sum(1 for r in tf if r['status'] == 'PASS')} passed): "
              + ", ".join(sorted({r['name'].split('/testfloat/')[1] for r in tf}))[:900] + ".")
        w("")
    fo = by.get("formal", [])
    if fo:
        w("### 5.2 Formal verification (bounds and assumptions as run)")
        w("")
        w("| Property set | Result | Kind | Covers | Assumptions |")
        w("|---|---|---|---|---|")
        for r in sorted(fo, key=lambda x: x["name"]):
            m = r.get("metrics") or {}
            if r["name"].startswith("neg/"):
                w(f"| {r['name']} (negative control: mutated RTL) | {'refuted (as required)' if r['status'] == 'PASS' else 'NOT refuted'} "
                  f"| — | — | {str(m.get('mutation', ''))[:90].replace('|', '\\|')} |")
            else:
                w(f"| {r['name']} | {r['status']} (BMC {m.get('bmc')}, induction: {m.get('induction')}) | "
                  f"{m.get('result_kind')} | {m.get('covers_reached')} | {m.get('assumptions')} |")
        w("")
        w("A bounded result means no counterexample exists within the stated number of cycles from reset; it is "
          "not a proof for longer traces. Only k-induction successes and the combinational address-map checks are "
          "unbounded proofs.")
        w("")
    if mut:
        s = mut.get("summary", {})
        w("### 5.3 Mutation testing of the framework")
        w("")
        w(f"Mutants killed {s.get('KILLED', 0)}, survived {s.get('SURVIVED', 0)}, not applicable "
          f"{s.get('NOT_APPLICABLE', 0)} (matrix of the run). Per module:")
        w("")
        per = defaultdict(Counter)
        for m in mut.get("mutants", []):
            per[m["module"]][m["status"]] += 1
        w("| Module | Killed | Survived | Not applicable |")
        w("|---|---|---|---|")
        for k in sorted(per):
            w(f"| {k} | {per[k]['KILLED']} | {per[k]['SURVIVED']} | {per[k]['NOT_APPLICABLE']} |")
        sv = [m for m in mut.get("mutants", []) if m["status"] == "SURVIVED"]
        if sv:
            w("")
            w("Survivors (verification gaps, see `docs/KNOWN_GAPS.md`):")
            for m in sv:
                w(f"* {m['id']} ({m['file']}): {m['desc']}")
        w("")
    lg = by.get("legacy", [])
    if lg:
        w("### 5.4 Module regressions re-run unchanged")
        w("")
        w("| Module regression | Result | Time (s) |")
        w("|---|---|---|")
        for r in lg:
            w(f"| {r['name']} | {r['status']} | {r.get('duration_s', 0):.0f} |")
        w("")
    # ----------------------------------------------------------------- coverage
    w("## 6. Coverage (derived from collected data)")
    w("")
    lc = cov.get("line") or {}
    if lc.get("modules"):
        t = lc.get("total", {})
        w(f"RTL line coverage, Verilator `--coverage-line`, merged over {lc.get('dat_files')} instrumented runs: "
          f"**{t.get('hit')}/{t.get('found')} lines = {t.get('pct')} %**. The FP32 C++ harness and Icarus runs are "
          "not instrumented.")
        w("")
        w("| RTL module | Lines hit / found | % |")
        w("|---|---|---|")
        for k, v in lc["modules"].items():
            w(f"| {k} | {v['hit']} / {v['found']} | {v['pct']} |")
        w("")
    else:
        w(f"No line coverage collected ({lc.get('note', 'no data')}).")
        w("")
    fg = cov.get("functional") or {}
    if fg:
        w("Functional coverage (goal bins defined in `regression/coverage.py`; infeasible bins excluded with the "
          "reason stated there):")
        w("")
        w("| Group | Bins hit / goal | % | Missed |")
        w("|---|---|---|---|")
        for k, v in fg.items():
            w(f"| {k} | {v['hit']} / {v['bins']} | {v['pct']} | {', '.join(v['missed'][:8]) or '—'} |")
        w("")
    # ----------------------------------------------------------------- seeds and reproduction
    w("## 7. Seeds, waveforms, reproduction")
    w("")
    seeds = sorted({r.get("seed") for r in recs if r.get("seed") is not None})
    w(f"* Seeds used: {', '.join(map(str, seeds)) or 'n/a'}. Every random stream is derived from (test name, seed); "
      "re-running a test with the same seed reproduces it cycle for cycle.")
    w("* Every record carries an exact reproduction command (`reports/results.json`, field `repro`).")
    w("* Waveforms are produced automatically for failing tests (re-run with tracing); the path is listed in §3.")
    w("")
    w("## 8. Deviations and known gaps")
    w("")
    w("See `docs/DEVIATIONS.md` (supported IEEE 754 deviations and implementation choices) and "
      "`docs/KNOWN_GAPS.md` (what is not verified, blocked tests, observations).")
    (REPORTS / "VERIFICATION_REPORT.md").write_text("\n".join(L) + "\n")
    (REPORTS / "rtl_revision.json").write_text(json.dumps(rev, indent=1) + "\n")
    (REPORTS / "coverage.json").write_text(json.dumps(cov, indent=1) + "\n")
    slim = [{k: r.get(k) for k in ("suite", "name", "status", "seed", "config", "duration_s", "metrics", "reason",
                                    "repro", "waves", "log", "simulator")} for r in recs]
    for r in slim:
        r["log"], r["waves"] = rel(r["log"]), rel(r["waves"])
    (REPORTS / "results.json").write_text(json.dumps({"meta": meta, "rtl_revision": {k: v for k, v in rev.items()
                                                                                     if k != "rtl_files"},
                                                      "counts": dict(tot), "records": slim}, indent=1, default=str))
    ts = ET.Element("testsuites", tests=str(len(recs)), failures=str(tot["FAIL"]))
    for s in suites:
        e = ET.SubElement(ts, "testsuite", name=s, tests=str(len(by[s])),
                          failures=str(sum(1 for r in by[s] if r["status"] == "FAIL")),
                          skipped=str(sum(1 for r in by[s] if r["status"] in ("BLOCKED", "SKIP"))))
        for r in by[s]:
            tc = ET.SubElement(e, "testcase", classname=s, name=r["name"], time=str(r.get("duration_s") or 0))
            if r["status"] == "FAIL":
                ET.SubElement(tc, "failure", message=(r.get("reason") or "")[:500]).text = r.get("repro") or ""
            elif r["status"] in ("BLOCKED", "SKIP"):
                ET.SubElement(tc, "skipped", message=f"{r['status']}: {(r.get('reason') or '')[:300]}")
    ET.ElementTree(ts).write(REPORTS / "junit.xml", encoding="utf-8", xml_declaration=True)
    print(f"report: {REPORTS / 'VERIFICATION_REPORT.md'}  ({len(recs)} records: {dict(tot)})")
    return 0


if __name__ == "__main__":
    sys.exit(main())
