#!/usr/bin/env python3
"""Package the framework as a zip whose paths are relative to the repository root:
tests/hpc/** (sources, docs, generated reports; never build/), the root Makefile delegator and the CI workflow.
Unzip at the repository root, then run `make hpc-setup`.

usage: package.py OUT.zip
"""
from __future__ import annotations

import hashlib
import sys
import zipfile
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
ROOT = HPC.parent.parent
SKIP_DIRS = {"build", "__pycache__", ".pytest_cache"}


def files():
    for p in sorted(HPC.rglob("*")):
        if p.is_file() and not (set(p.relative_to(HPC).parts) & SKIP_DIRS):
            yield p, p.relative_to(ROOT)
    for extra in ("Makefile", ".github/workflows/hpc-verification.yml"):
        q = ROOT / extra
        if q.is_file():
            yield q, Path(extra)


def main():
    out = Path(sys.argv[1])
    out.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for src, arc in files():
            data = src.read_bytes()
            info = zipfile.ZipInfo(str(arc), date_time=(2026, 11, 7, 0, 0, 0))
            info.external_attr = (0o755 if src.stat().st_mode & 0o111 else 0o644) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
            lines.append(f"{hashlib.sha256(data).hexdigest()}  {arc}")
        z.writestr("tests/hpc/SHA256SUMS", "\n".join(lines) + "\n")
    print(f"{out}: {len(lines)} files")


if __name__ == "__main__":
    main()
