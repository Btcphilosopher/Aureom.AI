#!/usr/bin/env python3
"""Mutation campaign: can the framework detect real design defects?

Mutant sources
  * the modules' OWN mutant tables (Module 02 scripts/mutate.py, Module 03
    scripts/mutate.py, Module 04 / 05 / 07 scripts/run_mutants.py), parsed
    with ``ast`` (never executed): each injects one deliberate bug that the
    module's own testbench is known to detect.  Re-using them measures the
    framework's detection power independently of the original benches;
  * framework mutants (FRAMEWORK below) for defect classes the module tables do
    not cover (Module 01 fp32_fma, DMA completion timing, tile-level wiring).

Each mutant is applied to a private copy of the affected module tree
(build/mutants/<id>/src, other modules symlinked), and the framework suites
that cover that module are run against it in order, stopping at the first
failing test.  A mutant is KILLED if any framework test fails, SURVIVED
otherwise (a survivor is a reported verification gap, not hidden).
The SV assertions inside the RTL stay enabled exactly as in normal runs.

usage: mutants.py [--matrix ci|nightly] [--only ID] [--jobs N] [--max N]
"""
from __future__ import annotations

import argparse
import ast
import concurrent.futures as cf
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import results as R, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "mutation"
PY = sys.executable

# which framework suites detect defects in which module (fast detectors first)
DETECT = {
    "m01": [["fp32/run_fp32.py", "--only", "directed"], ["fp32/run_fp32.py", "--only", "random/s1"],
            ["fp32/run_fp32.py", "--only", "fma_stress"]],
    "m02": [["fp32/run_fp32.py", "--only", "directed"], ["vector_lane/run_vector_lane.py", "--sim", "verilator",
                                                          "--config", "default"],
            ["fp32/run_fp32.py", "--only", "random/s1"], ["vector_lane/run_vector_lane.py", "--sim", "verilator",
                                                          "--config", "minlat_rob2"]],
    "m03": [["vector_array/run_vector_array.py", "--sim", "verilator", "--config", "n4"],
            ["vector_array/run_vector_array.py", "--sim", "verilator", "--config", "n1"],
            ["vector_array/run_vector_array.py", "--sim", "verilator", "--config", "n4_shallow"],
            ["command_queue/run_command_queue.py"]],
    "m04": [["scratchpad/run_scratchpad.py", "--sim", "verilator", "--config", c] for c in
            ("b2_p2", "b4_p3_xor_q2_rl2", "b8_p4_high_1r1w", "b4_p4_2rw_fixed", "b2_p2_wordwe_posted",
             "b1_p2", "b8_p2_q4_rl3")] + [["dma/run_dma.py", "--sim", "verilator", "--config", "simple"]],
    "m05": [["dma/run_dma.py", "--sim", "verilator", "--config", c] for c in
            ("simple", "buffered_sp", "buffered_dp_slice")] + [["command_queue/run_command_queue.py"],
                                                               ["tile_integration/run_tile_integration.py",
                                                               "--sim", "verilator", "--config", "n4_simple"]],
    "m07": [["perf_counters/run_perf_counters.py", "--sim", "verilator"],  # counter bank + mixed-stream counters
            ["tile_integration/run_tile_integration.py", "--sim", "verilator", "--config", "n4_simple"]],
}
TABLES = {"m02": FL.M02 / "scripts/mutate.py", "m03": FL.M03 / "scripts/mutate.py",
          "m04": FL.M04 / "scripts/run_mutants.py", "m05": FL.M05 / "scripts/run_mutants.py",
          "m07": FL.M07 / "scripts/run_mutants.py"}
MODDIR = {"m01": FL.M01, "m02": FL.M02, "m03": FL.M03, "m04": FL.M04, "m05": FL.M05, "m07": FL.M07}

FRAMEWORK = [
    # (id, module, file, old, new, description) -- defect classes the module tables do not cover
    ("F01", "m01", "fp32_fma_pkg.sv", "default: round_up = rnd & (stk | lsb);   // RNE",
     "default: round_up = rnd;   // RNE", "fp32_fma: RNE ties rounded away from zero"),
    ("F02", "m01", "fp32_fma_prep.sv", "assign any_snan  = a_snan | b_snan | c_snan;",
     "assign any_snan  = a_snan | b_snan;", "fp32_fma: signalling-NaN addend does not raise NV"),
    ("F03", "m05", "dma_transfer_engine.sv", "            req_valid <= 1'b0;\n            st_q      <= `DMA_ST_WAIT_WRITE;",
     "            req_valid <= 1'b0;\n            st_q      <= last_beat ? `DMA_ST_COMPLETE : `DMA_ST_WAIT_WRITE;",
     "DMA: transfer completes when the last write is ISSUED, before its acknowledgement"),
]


# survivors analysed and documented in docs/KNOWN_GAPS.md: still reported as FAIL records of this suite, but
# flagged so the regression exit status only fails on a NEW survivor
KNOWN_SURVIVORS = {
    "M04-M14": "G4: the parity path needs SRAM fault injection, which the framework does not perform",
}

M07_VARS = {"C": "hpc_perf_counters.sv", "E": "hpc_perf_events.sv", "W": "hpc_perf_wtrack.sv",
            "X": "hpc_perf_cdc_count.sv"}


def strings(node):
    return [n.value for n in node.elts if isinstance(n, ast.Constant) and isinstance(n.value, str)]


def load_table(mod: str, path: Path):
    tree = ast.parse(path.read_text())
    out = []
    for n in ast.walk(tree):
        if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "MUTANTS" for t in n.targets):
            for e in n.value.elts:
                if not isinstance(e, ast.Tuple):
                    continue
                s = strings(e)
                fi = next((i for i, x in enumerate(s) if x.endswith((".sv", ".svh"))), None)
                if fi is None:
                    # Module 07 style: (id, FILE_VAR, description, old, new) with FILE_VAR a Path variable
                    var = next((n.id for n in e.elts if isinstance(n, ast.Name) and n.id in M07_VARS), None)
                    if var and len(s) >= 4:
                        out.append(dict(id=f"{mod.upper()}-{s[0]}", module=mod, file=M07_VARS[var], old=s[2],
                                        new=s[3], desc=s[1], origin=f"{path.parent.parent.name}/scripts/{path.name}"))
                    continue
                if len(s) < fi + 3:
                    continue
                mid, fname, old, new = s[0], s[fi], s[fi + 1], s[fi + 2]
                desc = next((x for i, x in enumerate(s) if i not in (0, fi, fi + 1, fi + 2)), "")
                out.append(dict(id=f"{mod.upper()}-{mid}", module=mod, file=fname, old=old, new=new, desc=desc,
                                origin=f"{path.parent.parent.name}/{path.relative_to(path.parent.parent)}"))
    return out


def canonical_paths(fname: str):
    """every file the framework compiles with this name (canonical copies only)."""
    seen = []
    for name in ["fp32_fma", "lane", "varray", "varray_obs", "scratchpad", "dma", "tile", "perf_core", "df_checker"]:
        for p in FL.files(name):
            if p.name == fname and p not in seen:
                seen.append(p)
    return seen


def make_tree(mid: str, paths):
    root = sim.BUILD / "mutants" / mid
    if root.exists():
        shutil.rmtree(root)
    src = root / "src"
    src.mkdir(parents=True)
    tops = {p.relative_to(FL.SRC).parts[0] for p in paths}
    for d in FL.SRC.iterdir():
        if d.name in tops:
            shutil.copytree(d, src / d.name, symlinks=True, ignore=shutil.ignore_patterns("build", "reports"))
        else:
            (src / d.name).symlink_to(d)
    (root / "ref").symlink_to(sim.BUILD / "ref")
    shutil.copy(sim.BUILD / "rtl_revision.json", root / "rtl_revision.json")
    (root / "vl").mkdir()
    return root


def run_one(m):
    t0 = time.time()
    paths = canonical_paths(m["file"])
    if not paths:
        return dict(m, status="NOT_APPLICABLE", reason=f"{m['file']} is not compiled by any framework suite")
    root = make_tree(m["id"], paths)
    hits = 0
    for p in paths:
        q = root / "src" / p.relative_to(FL.SRC)
        txt = q.read_text()
        c = txt.count(m["old"])
        if c == 1:
            q.write_text(txt.replace(m["old"], m["new"]))
            hits += 1
    if hits == 0:
        shutil.rmtree(root, ignore_errors=True)
        return dict(m, status="NOT_APPLICABLE", reason="mutation site not found exactly once in the canonical copy")
    env = dict(os.environ, HPC_BUILD=str(root), HPC_COVERAGE="0", HPC_WAVES_ON_FAIL="0", HPC_JOBS="2")
    killer = None
    for cmd in DETECT[m["module"]]:
        log = root / f"detect_{len(list(root.glob('detect_*.log')))}.log"
        with open(log, "w") as f:
            subprocess.run([PY, str(HPC / cmd[0]), *cmd[1:]], cwd=HPC, env=env, stdout=f, stderr=subprocess.STDOUT,
                           timeout=3600)
        fails = []
        for rec in R.load_all(root / "results"):
            if rec["status"] == "FAIL":
                fails.append(f"{rec['suite']}/{rec['name']}")
        if fails:
            killer = {"suite_cmd": " ".join(cmd), "failed_tests": fails[:5], "n_failed": len(fails)}
            break
    st = "KILLED" if killer else "SURVIVED"
    out = dict(m, status=st, killer=killer, seconds=round(time.time() - t0, 1))
    shutil.rmtree(root / "vl", ignore_errors=True)
    if st == "KILLED":
        shutil.rmtree(root, ignore_errors=True)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=["ci", "nightly"])
    ap.add_argument("--only", default="")
    ap.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2) // 2))
    ap.add_argument("--max", type=int, default=0, help="limit the number of mutants (0: matrix default)")
    a = ap.parse_args()
    sim.ensure_rtl()
    sim.ensure_ref()
    allm = []
    for mod, p in TABLES.items():
        allm += load_table(mod, p)
    allm += [dict(id=f"FW-{i}", module=m, file=f, old=o, new=n, desc=d, origin="tests/hpc/regression/mutants.py")
             for (i, m, f, o, n, d) in FRAMEWORK]
    if a.matrix == "ci" and not a.only:
        # mandatory CI sample: every 4th mutant of every module table (deterministic)
        allm = [m for i, m in enumerate(allm) if i % 4 == 0 or m["id"].startswith("FW-")]
    if a.only:
        keys = [k for k in a.only.split(",") if k]
        allm = [m for m in allm if any(k in m["id"] for k in keys)]
    if a.max:
        allm = allm[:a.max]
    print(f"== mutation campaign, matrix {a.matrix}: {len(allm)} mutant(s), {a.jobs} parallel", flush=True)
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for r in ex.map(run_one, allm):
            res.append(r)
            st = {"KILLED": "PASS", "SURVIVED": "FAIL", "NOT_APPLICABLE": "SKIP"}[r["status"]]
            known = KNOWN_SURVIVORS.get(r["id"]) if r["status"] == "SURVIVED" else None
            R.record(SUITE, r["id"], st, duration=r.get("seconds"), simulator="framework suites",
                     metrics={"module": r["module"], "file": r["file"], "description": r["desc"],
                              "mutation": {"old": r["old"], "new": r["new"]}, "origin": r.get("origin"),
                              "outcome": r["status"], "killer": r.get("killer"), "known_survivor": bool(known)},
                     reason=r.get("reason") or (None if st == "PASS" else
                                                (f"known framework gap {known} (docs/KNOWN_GAPS.md)" if known else
                                                 "mutant not detected by any framework test")),
                     repro=f"python3 tests/hpc/regression/mutants.py --only {r['id']}")
            k = r.get("killer") or {}
            print(f"  [{r['status']}] {r['id']:10s} {r['desc'][:60]:60s} "
                  f"{(k.get('failed_tests') or [''])[0][:70] if k else r.get('reason', '')}", flush=True)
    summ = {s: sum(1 for r in res if r["status"] == s) for s in ("KILLED", "SURVIVED", "NOT_APPLICABLE")}
    (sim.BUILD / "runs").mkdir(exist_ok=True)
    sp = sim.BUILD / "runs/mutation_summary.json"
    if a.only and sp.exists():          # partial re-run: merge into the existing campaign summary
        old = json.loads(sp.read_text()).get("mutants", [])
        ids = {r["id"] for r in res}
        res = [r for r in old if r["id"] not in ids] + res
        summ = {s: sum(1 for r in res if r["status"] == s) for s in ("KILLED", "SURVIVED", "NOT_APPLICABLE")}
    sp.write_text(json.dumps({"summary": summ, "mutants": res}, indent=1, default=str))
    print(f"== mutation: {summ}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
