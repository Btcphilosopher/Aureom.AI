#!/usr/bin/env python3
"""Re-run the proven per-module regressions, unchanged (brief §1: reuse, do not replace).

Every SilicaFlux-HPC module archive ships its own regression (Module 01 cocotb +
Verilator/TestFloat + formal; Modules 02-07 self-checking SystemVerilog benches,
mutation scripts, formal).  They are executed here exactly as their READMEs
document, inside the extracted archive (tests/hpc/build/src/<module>), and each
becomes one result record.  The framework's own suites are additional,
independent checks; neither replaces the other.

usage: legacy.py [--matrix ci|nightly] [--only m01|m02|...] [--jobs N]
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import results as R, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "legacy"
J = os.environ.get("HPC_JOBS", str(os.cpu_count() or 2))
CMDS = {
    "ci": {
        "m01_fp32_fma_quick": (FL.M01, ["bash", "-c", "QUICK=1 bash scripts/regress.sh"], 3600),
        "m02_vector_lane_quick": (FL.M02, ["bash", "-c", "make vectors >/dev/null && python3 -I scripts/regress.py "
                                                         f"--sim verilator --quick --jobs {J}"], 3600),
        "m03_vector_array_quick": (FL.M03, ["make", "quick"], 3600),
        "m04_scratchpad_quick": (FL.M04, ["make", "spm-quick", f"JOBS={J}"], 3600),
        "m05_dma_adapter_quick": (FL.M05, ["make", "dma-quick", f"JOBS={J}"], 3600),
        "m07_perf_counters_lint_unit": (FL.M07, ["make", "lint", "unit", f"JOBS={J}"], 3600),
    },
    "nightly": {
        "m01_fp32_fma_full": (FL.M01, ["bash", "scripts/regress.sh"], 6 * 3600),
        "m02_vector_lane_full": (FL.M02, ["bash", "-c", "make vectors crosscheck >/dev/null && "
                                                        "python3 -I scripts/regress.py --sim both"], 4 * 3600),
        "m03_vector_array_regress": (FL.M03, ["make", "regress"], 6 * 3600),
        "m04_scratchpad_full": (FL.M04, ["make", "spm-test", "spm-mutants", f"JOBS={J}"], 4 * 3600),
        "m05_dma_adapter_full": (FL.M05, ["make", "dma-test", "dma-mutants", "dma-integ", f"JOBS={J}"], 4 * 3600),
        "m07_perf_counters_full": (FL.M07, ["make", "lint", "unit", "integ", "cdc", "formal", f"JOBS={J}"], 4 * 3600),
    },
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(CMDS))
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    sim.ensure_rtl()
    sim.ensure_ref()
    env = dict(os.environ)
    vb = str(Path(sys.executable).parent)          # cocotb 1.9.2 / z3-solver of the framework venv first
    env["PATH"] = vb + os.pathsep + env.get("PATH", "")
    print(f"== legacy module regressions, matrix {a.matrix}")
    for name, (cwd, cmd, to) in CMDS[a.matrix].items():
        if a.only not in name:
            continue
        log = sim.BUILD / "runs/legacy" / f"{name}.log"
        t0 = time.time()
        rc = sim.run(cmd, log=log, cwd=cwd, timeout=to, env=env)
        dt = time.time() - t0
        tail = log.read_text(errors="replace").strip().splitlines()[-12:]
        st = "PASS" if rc == 0 else "FAIL"
        R.record(SUITE, name, st, duration=dt, log=log, metrics={"exit_code": rc, "tail": tail, "cwd": str(cwd)},
                 repro=R.repro_cmd(cmd, cwd=cwd), reason=None if rc == 0 else f"exit code {rc}",
                 simulator="module scripts")
        print(f"  [{st}] legacy/{name} ({dt:.0f}s) rc={rc}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
