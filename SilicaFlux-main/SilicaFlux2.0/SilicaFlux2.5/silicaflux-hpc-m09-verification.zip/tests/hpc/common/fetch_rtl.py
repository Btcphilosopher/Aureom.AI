#!/usr/bin/env python3
"""SilicaFlux-HPC verification framework -- RTL provenance and extraction.

The Aureom.AI repository stores every SilicaFlux-HPC module as a zip archive
(``SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-*.zip``).  The
verification framework never copies RTL into ``tests/hpc``; it extracts the
archives that are in the repository into ``tests/hpc/build/src`` and checks:

1. every archive's SHA-256 against the pinned value in ``rtl_manifest.json``
   (an RTL change is therefore always visible: re-pin with ``--update-pins``);
2. that every RTL file vendored into more than one archive is byte-identical
   to its canonical copy (Modules 03/05/07 vendor copies of 02/03/04/05 and of
   the DataFabric / SRAM library); the only allowed differences are listed in
   the manifest with the document that justifies them;
3. writes ``build/rtl_revision.json``: repository commit, archive hashes and
   per-file hashes of every RTL source the framework compiles.

usage: fetch_rtl.py [--update-pins] [--force] [--quiet]
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent                                   # tests/hpc
MANIFEST = HERE / "rtl_manifest.json"


def repo_root() -> Path:
    env = os.environ.get("HPC_REPO_ROOT")
    if env:
        return Path(env).resolve()
    return HPC.parent.parent                         # <repo>/tests/hpc -> <repo>


def build_dir() -> Path:
    return Path(os.environ.get("HPC_BUILD", HPC / "build")).resolve()


def sha256(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for blk in iter(lambda: f.read(1 << 20), b""):
            h.update(blk)
    return h.hexdigest()


def git_rev(root: Path) -> dict:
    def q(*a):
        try:
            return subprocess.run(["git", "-C", str(root), *a], capture_output=True, text=True,
                                  check=True).stdout.strip()
        except Exception:
            return "unknown"
    return {"commit": q("rev-parse", "HEAD"), "branch": q("rev-parse", "--abbrev-ref", "HEAD"),
            "date": q("log", "-1", "--format=%cI"),
            "dirty_archives": q("status", "--porcelain", "--", "SilicaFlux-main")}


SKIP_PREFIXES = ("reports/logs", "reports/logs_gate", "build/")


def extract(zpath: Path, dest: Path, top: str) -> int:
    """Extract archive ``zpath`` (top directory ``top``) into ``dest/top``; skip bulky logs."""
    n = 0
    with zipfile.ZipFile(zpath) as z:
        for info in z.infolist():
            name = info.filename
            if not name.startswith(top + "/"):
                continue
            rel = name[len(top) + 1:]
            if any(rel.startswith(p) for p in SKIP_PREFIXES) or "/__pycache__/" in name:
                continue
            target = dest / top / rel
            if not str(target.resolve()).startswith(str(dest.resolve())):
                raise SystemExit(f"refusing unsafe path in archive: {name}")
            if name.endswith("/"):
                target.mkdir(parents=True, exist_ok=True)
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with z.open(info) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            mode = (info.external_attr >> 16) & 0o777
            if mode:
                os.chmod(target, mode)
            n += 1
    return n


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--update-pins", action="store_true", help="accept the archives' current SHA-256 as the new pins")
    ap.add_argument("--force", action="store_true", help="re-extract even if the stamp matches")
    ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()

    man = json.loads(MANIFEST.read_text())
    root = repo_root()
    bld = build_dir()
    src = bld / "src"
    src.mkdir(parents=True, exist_ok=True)
    stamp = bld / "fetch.stamp"
    problems: list[str] = []
    archives = {}

    for key, ent in man["archives"].items():
        zp = root / ent["path"]
        if not zp.is_file():
            problems.append(f"{key}: archive missing: {zp}")
            continue
        h = sha256(zp)
        archives[key] = {"path": ent["path"], "sha256": h, "top": ent["top"], "module": ent["module"]}
        if h != ent["sha256"]:
            if a.update_pins:
                ent["sha256"] = h
            else:
                problems.append(f"{key}: SHA-256 mismatch for {ent['path']}\n      pinned {ent['sha256']}\n"
                                f"      actual {h}\n      (RTL changed: review, then run fetch_rtl.py --update-pins)")
    if a.update_pins:
        MANIFEST.write_text(json.dumps(man, indent=2) + "\n")
    if problems:
        for p in problems:
            print("FETCH ERROR:", p, file=sys.stderr)
        return 2

    want = json.dumps(archives, sort_keys=True)
    if a.force or not stamp.exists() or stamp.read_text() != want:
        for key, ent in archives.items():
            d = src / ent["top"]
            if d.exists():
                shutil.rmtree(d)
            n = extract(root / ent["path"], src, ent["top"])
            if not a.quiet:
                print(f"extracted {key:4s} {ent['top']:36s} {n:5d} files  sha256 {ent['sha256'][:16]}")
        stamp.write_text(want)
    elif not a.quiet:
        print("archives unchanged; extraction up to date")

    # ------------------------------------------------ cross-copy identity of vendored RTL
    ident = []
    allowed = {(d["canonical"], d["copy"]): d["reason"] for d in man.get("allowed_differences", [])}
    for pair in man["identity"]:
        cdir = src / pair["canonical"]
        for cp in pair["copies"]:
            kdir = src / cp
            if not cdir.is_dir() or not kdir.is_dir():
                problems.append(f"identity: missing directory {cdir} or {kdir}")
                continue
            for f in sorted(kdir.rglob("*")):
                if not f.is_file() or f.suffix not in (".sv", ".svh", ".v", ".vh"):
                    continue
                rel = f.relative_to(kdir)
                c = cdir / rel
                if not c.is_file():
                    continue                       # subset copies may hold files the canonical tree lacks
                same = sha256(c) == sha256(f)
                key = (str(Path(pair["canonical"]) / rel), str(Path(cp) / rel))
                ident.append({"canonical": key[0], "copy": key[1], "identical": same})
                if not same and key not in allowed:
                    problems.append(f"identity: {key[1]} differs from canonical {key[0]}")
    for (c, k), why in allowed.items():
        if not (src / c).is_file() or not (src / k).is_file():
            problems.append(f"allowed difference refers to a missing file: {c} / {k}")

    # ------------------------------------------------ RTL revision record
    sys.path.insert(0, str(HERE))
    import filelists as FL  # noqa: E402
    files = {}
    for name in FL.ALL_RTL_SETS:
        for p in FL.files(name):
            if not p.is_file():
                problems.append(f"filelist {name}: missing {p}")
                continue
            files[str(p.relative_to(src))] = sha256(p)
    first = next(iter(archives.values()))["path"]
    rev = {"repository": git_rev((root / first).resolve().parent), "archives": archives,
           "rtl_files": dict(sorted(files.items())),
           "rtl_digest": hashlib.sha256(json.dumps(files, sort_keys=True).encode()).hexdigest(),
           "identity_checks": {"pairs": len(ident), "identical": sum(i["identical"] for i in ident),
                               "allowed_differences": [{"canonical": c, "copy": k, "reason": r}
                                                       for (c, k), r in allowed.items()]}}
    (bld / "rtl_revision.json").write_text(json.dumps(rev, indent=2) + "\n")
    if problems:
        for p in problems:
            print("FETCH ERROR:", p, file=sys.stderr)
        return 3
    if not a.quiet:
        print(f"identity: {rev['identity_checks']['identical']}/{len(ident)} vendored RTL copies byte-identical "
              f"(+{len(allowed)} documented difference(s))")
        print(f"rtl digest {rev['rtl_digest'][:16]} over {len(files)} files -> {bld / 'rtl_revision.json'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
