"""Single source of RTL file lists for every SilicaFlux-HPC verification build.

All paths point into ``tests/hpc/build/src`` (populated by ``fetch_rtl.py`` from the
module archives in the repository).  Canonical copies are used: each module's own
archive for its RTL, Module 04's vendored SRAM Wrapper Library and Module 05's
vendored DataFabric subset (``fetch_rtl.py`` proves the other copies identical).
"""
from __future__ import annotations

import os
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
BUILD = Path(os.environ.get("HPC_BUILD", HPC / "build")).resolve()
SRC = BUILD / "src"
COMMON = HPC / "common"

M01 = SRC / "silicaflux-hpc-fp32-fma"
M02 = SRC / "silicaflux-hpc-m02-vector-lane"
M03 = SRC / "silicaflux-hpc-m03-vector-array"
M04 = SRC / "silicaflux-hpc-m04-scratchpad"
M05 = SRC / "silicaflux-hpc-m05-dma-adapter"
M07 = SRC / "silicaflux-hpc-m07-perf-counters"
DF = M05 / "third_party/silicaflux-datafabric"
SL = M05 / "third_party/silicaflux-sramlib/rtl/mem"
SOFTFLOAT = M01 / "third_party/berkeley-softfloat-3"
TESTFLOAT = M01 / "third_party/berkeley-testfloat-3"

_SETS: dict[str, list[Path]] = {}

# ------------------------------------------------------------------ Module 01
_SETS["fp32_fma"] = [M01 / "rtl" / l.strip() for l in
                     ["fp32_fma_pkg.sv", "fp32_fma_lzc.sv", "fp32_fma_stage.sv", "fp32_fma_unpack.sv",
                      "fp32_fma_prep.sv", "fp32_fma_mul.sv", "fp32_fma_align.sv", "fp32_fma_add.sv",
                      "fp32_fma_norm.sv", "fp32_fma_round.sv", "fp32_fma_except.sv", "fp32_fma_pack.sv",
                      "fp32_fma.sv"]]
# ------------------------------------------------------------------ Module 02
_SETS["lane"] = [M02 / "rtl" / f for f in
                 ["hpc_vector_pkg.sv", "hpc_pipe.sv", "hpc_lzc.sv", "hpc_fp32_round.sv", "hpc_fp32_add.sv",
                  "hpc_fp32_mul.sv", "hpc_fp32_fma.sv", "hpc_fp32_misc.sv", "hpc_int32_mul.sv",
                  "hpc_vector_lane.sv"]]
# ------------------------------------------------------------------ Module 03
_VA = ["hpc_varray_pkg.sv", "hpc_varray_fifo.sv", "hpc_varray_issue.sv", "hpc_varray_collect.sv",
       "hpc_varray_reduce.sv", "hpc_varray_perf.sv", "hpc_vector_array.sv"]
_SETS["varray"] = _SETS["lane"][:1] + [M03 / "rtl" / _VA[0]] + _SETS["lane"][1:] + [M03 / "rtl" / f for f in _VA[1:]]
_SETS["varray_fifo"] = [M03 / "rtl/hpc_varray_fifo.sv"]
# Module 03 with the Module 07 observation port (two files replaced)
_SETS["varray_obs"] = [p if p.name not in ("hpc_varray_issue.sv", "hpc_vector_array.sv")
                       else M07 / "rtl/m03_obs" / p.name for p in _SETS["varray"]]
# ------------------------------------------------------------------ SRAM library + DataFabric
_SETS["sramlib"] = [SL / f for f in [
    "sram_rsp_path.sv", "sram_backend_1rw.sv", "sram_backend_1r1w.sv", "sram_backend_2rw.sv", "sram_sp.sv",
    "backends/generic/sram_generic_1rw.sv", "backends/generic/sram_generic_1r1w.sv",
    "backends/generic/sram_generic_2rw.sv", "backends/fpga/sram_fpga_1rw.sv", "backends/fpga/sram_fpga_1r1w.sv",
    "backends/fpga/sram_fpga_2rw.sv", "backends/asic/sram_asic_array.sv", "backends/asic/sram_leaf_sky130.sv",
    "backends/asic/sram_leaf_gf180.sv", "backends/asic/sram_leaf_ihp1p.sv", "backends/asic/sram_leaf_ihp2p.sv",
    "backends/asic/stubs/sram_macro_blackboxes.sv"]]
_SETS["df_dma"] = [DF / "rtl/dma" / f for f in ["dma_fifo.sv", "dma_validate.sv", "dma_transfer_engine.sv",
                                               "dma_burst_engine.sv"]]
_SETS["df_xbar"] = [DF / "rtl/interconnect" / f for f in [
    "sfb_addr_decoder.sv", "sfb_arbiter.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
    "sfb_crossbar.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv"]]
_SETS["df_mem"] = [DF / "rtl/mem/sfb_sram_slave.sv"]
_SETS["df_checker"] = [DF / "tb/common/sfb_protocol_checker.sv"]
# ------------------------------------------------------------------ Module 04
_SETS["spm_core"] = [M04 / "rtl" / f for f in ["hpc_spm_addr_map.sv", "hpc_spm_bank_arb.sv", "hpc_spm_bank.sv",
                                              "hpc_spm_perf.sv", "hpc_scratchpad.sv"]]
_SETS["scratchpad"] = _SETS["sramlib"] + [DF / "rtl/dma/dma_fifo.sv"] + _SETS["spm_core"]
_SETS["spm_addr_map"] = [M04 / "rtl/hpc_spm_addr_map.sv"]
_SETS["spm_bank_arb"] = [M04 / "rtl/hpc_spm_bank_arb.sv"]
# ------------------------------------------------------------------ Module 05
_SETS["dma_adapter_core"] = [M05 / "rtl" / f for f in ["hpc_dma_perf.sv", "hpc_dma_spm_port.sv", "hpc_dma_route.sv",
                                                      "hpc_dma_adapter.sv"]]
_SETS["dma"] = (_SETS["sramlib"] + _SETS["df_dma"] + [DF / "rtl/interconnect/sfb_skid_buffer.sv",
                DF / "rtl/interconnect/sfb_reg_slice.sv"] + _SETS["spm_core"] + _SETS["dma_adapter_core"])
_SETS["dma_route"] = [M05 / "rtl/hpc_dma_route.sv"]
_SETS["vseq"] = [M05 / "rtl/hpc_tile_vseq.sv"]
# ------------------------------------------------------------------ Module 07
_SETS["perf_core"] = [M07 / "rtl/hpc_perf_counters.sv"]
_SETS["perf_tile"] = [M07 / "rtl" / f for f in ["hpc_perf_wtrack.sv", "hpc_perf_events.sv", "hpc_perf_counters.sv",
                                               "hpc_perf_tile.sv"]]
# ------------------------------------------------------------------ whole tile
_SETS["tile"] = (_SETS["sramlib"] + _SETS["df_dma"] + _SETS["df_xbar"] + _SETS["df_mem"] + _SETS["spm_core"] +
                 _SETS["varray_obs"] + _SETS["dma_adapter_core"] + _SETS["vseq"] + _SETS["perf_tile"])

ALL_RTL_SETS = ["fp32_fma", "lane", "varray", "varray_obs", "scratchpad", "dma", "tile", "df_checker"]

INCDIRS = {
    "scratchpad": [M04 / "rtl", SL, SL / "backends/asic"],
    "dma": [M05 / "rtl", DF / "rtl/dma", SL, SL / "backends/asic", M04 / "rtl"],
    "tile": [M07 / "rtl", M05 / "rtl", DF / "rtl/dma", SL, SL / "backends/asic", M04 / "rtl"],
}
SIM_DEFINES = {
    "lane": [], "varray": [], "fp32_fma": ["FP32_FMA_ASSERT"],
    "scratchpad": ["HPC_SPM_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"],
    "dma": ["HPC_DMA_ASSERT", "HPC_SPM_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"],
    "tile": ["HPC_DMA_ASSERT", "HPC_SPM_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"],
}


def files(name: str) -> list[Path]:
    return list(_SETS[name])


def checker_files() -> list[Path]:
    """Framework protocol checkers (SystemVerilog, simulation + formal)."""
    return [COMMON / "sv/hpc_rv_checker.sv", COMMON / "sv/hpc_txn_conservation.sv"]
