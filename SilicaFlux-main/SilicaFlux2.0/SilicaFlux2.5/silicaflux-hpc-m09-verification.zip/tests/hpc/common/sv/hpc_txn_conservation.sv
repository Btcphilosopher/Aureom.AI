// =============================================================================
// SilicaFlux-HPC verification :: hpc_txn_conservation -- request conservation
//
// Counts requests that must each produce exactly one completion (acc pulses)
// and completions (cpl pulses).  Checks every cycle out of reset:
//   C1 NO_UNSOLICITED  completions never exceed acceptances (no duplicate or
//                      unsolicited completion)
//   C2 BOUND           outstanding = acc - cpl never exceeds MAX_OUT
//                      (FIFO / ROB / credit overflow)
//   C3 DRAIN           exported: outstanding count, so a testbench can require
//                      outstanding == 0 when the design reports idle
// Reset clears the outstanding count (architectural state discarded).
// ACC_W / CPL_W allow several acceptances / completions per cycle.
// =============================================================================
`default_nettype none

module hpc_txn_conservation #(
  parameter string NAME    = "txn",
  parameter int    ACC_W   = 1,
  parameter int    CPL_W   = 1,
  parameter int    MAX_OUT = 1 << 30,
  parameter int    MAX_MSG = 10
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [ACC_W-1:0] acc,
  input  wire logic [CPL_W-1:0] cpl,
  output logic [31:0]           outstanding,
  output logic [31:0]           err_cnt,
  output logic [31:0]           acc_total,
  output logic [31:0]           cpl_total
);
  int msgs = 0;
  int     na, nc;
  longint nxt;
  function automatic int popc_a(input logic [ACC_W-1:0] v);
    int n = 0; for (int i = 0; i < ACC_W; i++) n += int'(v[i]); return n;
  endfunction
  function automatic int popc_c(input logic [CPL_W-1:0] v);
    int n = 0; for (int i = 0; i < CPL_W; i++) n += int'(v[i]); return n;
  endfunction
  initial begin outstanding = '0; err_cnt = '0; acc_total = '0; cpl_total = '0; end

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      outstanding <= '0;
    end else begin
      na  = popc_a(acc);
      nc  = popc_c(cpl);
      nxt = longint'(outstanding) + na - nc;
      if (nxt < 0) begin
        if (msgs < MAX_MSG) $display("HPC_TXN_CHECK %s C1_NO_UNSOLICITED violated at %0t (outstanding %0d, +%0d -%0d)",
                                     NAME, $time, outstanding, na, nc);
        msgs++; err_cnt <= err_cnt + 1; outstanding <= '0;
      end else begin
        if (nxt > MAX_OUT) begin
          if (msgs < MAX_MSG) $display("HPC_TXN_CHECK %s C2_BOUND violated at %0t (outstanding %0d > %0d)",
                                       NAME, $time, nxt, MAX_OUT);
          msgs++; err_cnt <= err_cnt + 1;
        end
        outstanding <= 32'(nxt);
      end
      acc_total <= acc_total + 32'(na);
      cpl_total <= cpl_total + 32'(nc);
    end
  end
endmodule
`default_nettype wire
