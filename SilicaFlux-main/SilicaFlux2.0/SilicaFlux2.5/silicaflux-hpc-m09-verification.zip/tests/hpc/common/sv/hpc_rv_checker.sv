// =============================================================================
// SilicaFlux-HPC verification :: hpc_rv_checker -- ready/valid contract checker
//
// Passive checker for one valid/ready channel.  Instantiate it next to (or
// bind it to) any interface; it never drives the design.  Checks, every cycle
// out of reset:
//   R1 STABLE   valid && !ready at edge t  ->  at edge t+1 valid is still 1 and
//               every payload bit is unchanged (enabled with STABLE=1; Module 02
//               inputs do not require it, every SilicaFlux output does)
//   R2 XFREE    valid and ready are never X/Z; payload bits selected by XCHK_MASK are
//               not X/Z while valid (4-state simulators only; Verilator is 2-state).
//               Clear the mask bits of fields that may legally carry X, e.g. read data
//               of never-written SRAM words (the arrays are not reset).
//   R3 RESET    valid is 0 while reset is asserted (RESET_LOW=1) and, with
//               INIT_CYCLE=1, also in the first cycle after reset release
//   R4 NOREADY  optional: ready may not depend on valid -- not checkable here
//               structurally; see formal/ for the structural proofs
// Reports: err_cnt (saturating) and xfer_cnt (handshakes), plus one
// "HPC_RV_CHECK <NAME> <rule>" line per violation (first MAX_MSG).
// =============================================================================
`default_nettype none

module hpc_rv_checker #(
  parameter string NAME       = "rv",
  parameter int    W          = 1,
  parameter bit    STABLE     = 1'b1,
  parameter bit    RESET_LOW  = 1'b1,
  parameter bit    INIT_CYCLE = 1'b0,
  parameter int    MAX_MSG    = 10,
  parameter logic [W-1:0] XCHK_MASK = '1
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         valid,
  input  wire logic         ready,
  input  wire logic [W-1:0] payload,
  output logic [31:0]       err_cnt,
  output logic [31:0]       xfer_cnt
);
  logic         stalled_q;
  logic [W-1:0] payload_q;
  logic         first_q;
  logic [31:0]  clk_err, rst_err;
  int           msgs = 0;

  task automatic fail(input string rule);
    if (msgs < MAX_MSG) $display("HPC_RV_CHECK %s %s violated at time %0t", NAME, rule, $time);
    msgs++;
    if (clk_err != 32'hFFFF_FFFF) clk_err <= clk_err + 1;
  endtask

  initial begin clk_err = '0; rst_err = '0; xfer_cnt = '0; end
  assign err_cnt = clk_err + rst_err;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      stalled_q <= 1'b0;
      first_q   <= 1'b1;
    end else begin
      first_q   <= 1'b0;
      if ((^{valid, ready}) === 1'bx) fail("R2_XFREE(handshake)");
      else if (valid && ((^(payload & XCHK_MASK)) === 1'bx)) fail("R2_XFREE(payload)");
      if (INIT_CYCLE && first_q && valid) fail("R3_RESET(init cycle)");
      if (STABLE && stalled_q) begin
        if (valid !== 1'b1) fail("R1_STABLE(valid dropped without handshake)");
        else if (payload !== payload_q) fail("R1_STABLE(payload changed while stalled)");
      end
      if (valid && ready) xfer_cnt <= xfer_cnt + 1;
      stalled_q <= valid && !ready;
      payload_q <= payload;
    end
  end
  // R3: valid must be low while reset is asserted
  always @(negedge clk)
    if (RESET_LOW && !rst_n && valid === 1'b1) begin
      if (msgs < MAX_MSG) $display("HPC_RV_CHECK %s R3_RESET(valid in reset) violated at time %0t", NAME, $time);
      msgs++;
      rst_err <= rst_err + 1;
    end
endmodule
`default_nettype wire
