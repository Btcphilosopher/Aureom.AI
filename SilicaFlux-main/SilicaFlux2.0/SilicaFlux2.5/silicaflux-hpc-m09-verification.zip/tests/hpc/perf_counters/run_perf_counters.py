#!/usr/bin/env python3
"""Performance-counter suite (hpc_perf_counters, Module 07).

* independent per-cycle model test of the counter bank (this directory);
* the counters' agreement with what the scoreboards observed on real tile
  traffic is checked by tile_integration (counter cross-check of every kernel).
usage: run_perf_counters.py [--matrix ci|nightly] [--sim verilator|icarus] [--seed N]
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import cocorun, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "perf_counters"
CONFIGS = {
    "c4_w12_i8": dict(NUM_CNT=4, CNT_W=12, INC_W=8, NUM_ERR=2),
    "c3_w40_i4": dict(NUM_CNT=3, CNT_W=40, INC_W=4, NUM_ERR=1),
    "c8_w16_i16": dict(NUM_CNT=8, CNT_W=16, INC_W=16, NUM_ERR=4),
    "c2_w64_i32": dict(NUM_CNT=2, CNT_W=64, INC_W=32, NUM_ERR=1),
}
MATRIX = {"ci": dict(configs=["c4_w12_i8", "c3_w40_i4"], seeds=1, ncyc=6000, icarus=["c4_w12_i8"]),
          "nightly": dict(configs=list(CONFIGS), seeds=3, ncyc=40000, icarus=["c4_w12_i8", "c3_w40_i4"])}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--sim", default=None, choices=["verilator", "icarus"])
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    sim.ensure_rtl()
    print(f"== perf_counters suite, matrix {a.matrix}")
    runs = []
    if a.sim in (None, "verilator"):
        runs += [(c, "verilator") for c in mx["configs"]]
    if a.sim in (None, "icarus"):
        runs += [(c, "icarus") for c in mx["icarus"]]
    # vector counters on mixed command streams (array + telemetry)
    va_src = FL.files("varray_obs") + FL.files("perf_tile") + FL.checker_files() + [HERE / "tb_varray_perf_top.sv"]
    for vcfg, n in (("va_n2", 2), ("va_n4", 4)) if a.matrix == "ci" else (("va_n1", 1), ("va_n2", 2), ("va_n4", 4),
                                                                         ("va_n8", 8)):
        if a.sim == "icarus":
            break
        P = dict(NUM_LANES=n, VL_W=16, TID_W=8, CMD_DEPTH=4, TRK_DEPTH=8, CPL_DEPTH=4, RED_EN=1, RED_LAT=3,
                 LANE_ROB_DEPTH=8, LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, EN_FCMP=1, EN_INT=1)
        for si in range(mx["seeds"]):
            cocorun.run_suite(SUITE, vcfg, toplevel="tb_varray_perf_top", sources=va_src, test_module="test_perf_varray",
                              test_dir=HERE, testcases=["test_counters_mixed_stream"], parameters=P,
                              includes=[FL.M07 / "rtl"], seed=a.seed + si, env={**P, "HPC_NCMD": 150},
                              repro_hint=f"python3 tests/hpc/perf_counters/run_perf_counters.py --sim verilator "
                                         f"--seed {{seed}}  # config {vcfg}")
    for cfg, s in runs:
        P = CONFIGS[cfg]
        for si in range(mx["seeds"] if s == "verilator" else 1):
            cocorun.run_suite(SUITE, cfg, toplevel="hpc_perf_counters", sources=FL.files("perf_core"),
                              test_module="test_perf_counters", test_dir=HERE, testcases=["test_counter_bank_model"],
                              parameters=P, includes=[FL.M07 / "rtl"], sim=s, seed=a.seed + si,
                              env={**P, "HPC_NCYC": mx["ncyc"] if s == "verilator" else 3000},
                              repro_hint=f"python3 tests/hpc/perf_counters/run_perf_counters.py --sim {{sim}} "
                                         f"--seed {{seed}}  # config {cfg}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
