"""Module 07 vector counters cross-checked on mixed command streams (tb_varray_perf_top).

Several operation types are in flight in the same lane (FADD / FMUL / FMA / compares / moves,
elementwise and reductions back to back), which the tile's serial reference sequencer can never
produce.  At the end every vector counter is compared with what the scoreboards observed:
VEC_ISSUED = VEC_RETIRED = active elements (sum of completion counts, themselves checked against
the model), FLOPS_RETIRED = sum of per-element FLOP weights (FADD/FSUB/FMUL 1, FMA family 2,
others 0) + one addition per active element of every reduction, RED_ADDS, VEC_CMD_COMPLETED,
CMD_ACCEPTED / CMD_COMPLETED, VEC_BUSY (cycles busy_o was high).
"""
from __future__ import annotations

import cocotb
from cocotb.triggers import ClockCycles

from hpcv.cycle import val
from hpcv.tbutil import env_int, finish, rng
from hpcv.varray_env import CHK, VArrayEnv, gen_cmd, setup, stalls_from_env
from reference_models import fp32_softfloat as SF

W = {SF.FADD: 1, SF.FSUB: 1, SF.FMUL: 1, SF.FMADD: 2, SF.FMSUB: 2, SF.FNMSUB: 2, SF.FNMADD: 2}
IDX = dict(CMD_ACCEPTED=1, CMD_COMPLETED=2, VEC_ISSUED=3, VEC_RETIRED=4, FLOPS_RETIRED=5, VEC_BUSY=16, RED_ADDS=21,
           VEC_CMD_COMPLETED=22)


@cocotb.test()
async def test_counters_mixed_stream(dut):
    env = VArrayEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("perfmix")
    truth = dict(elems=0, flops=0, red_adds=0, cmds=0, busy=0)
    cmds = []
    for t in range(env_int("HPC_NCMD", 150)):
        # short vectors of alternating operation types keep different ops in flight per lane
        c = gen_cmd(r, env.n, t & 0xFF, red_p=0.25, max_vl=3 * env.n, illegal_p=0.05,
                    ops=[SF.FADD, SF.FMADD, SF.FMUL, SF.FMV, SF.FMIN, SF.FNMSUB, SF.FSUB, SF.IADD])
        cmds.append(c)
        env.send(c)
    orig = env.cpl.on_item

    def on_cpl(it, cyc):
        orig(it, cyc)
        c = cmds[truth["cmds"]]
        truth["cmds"] += 1
        if it["illegal"]:
            return
        truth["elems"] += it["count"]
        truth["flops"] += it["count"] * W.get(c["op"], 0)
        if c["red"]:
            truth["flops"] += it["count"]
            truth["red_adds"] += it["count"]
    env.cpl.on_item = on_cpl
    env.eng.hooks_sample.append(lambda cyc: truth.__setitem__("busy", truth["busy"] + (0 if env.eng.in_reset
                                                                                       else val(dut.busy))))
    await env.drain()
    await ClockCycles(dut.clk, 4)
    v = int(dut.perf_cnt.value)
    cnt = {k: (v >> (64 * i)) & ((1 << 64) - 1) for k, i in IDX.items()}
    want = dict(CMD_ACCEPTED=truth["cmds"], CMD_COMPLETED=truth["cmds"], VEC_ISSUED=truth["elems"],
                VEC_RETIRED=truth["elems"], FLOPS_RETIRED=truth["flops"], RED_ADDS=truth["red_adds"],
                VEC_CMD_COMPLETED=truth["cmds"], VEC_BUSY=truth["busy"])
    for k, w in want.items():
        if cnt[k] != w:
            env.eng.error(f"Module 07 counter {k} = {cnt[k]}, scoreboards observed {w}")
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra={"counters": cnt, "truth": truth})
