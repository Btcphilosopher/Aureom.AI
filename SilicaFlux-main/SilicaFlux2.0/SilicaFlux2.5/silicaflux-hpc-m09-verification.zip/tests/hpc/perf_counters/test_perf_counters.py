"""cocotb test of hpc_perf_counters (Module 07 counter bank), independent of Module 07's
own reference model: a per-cycle model written from docs/02_register_map.md.

Every cycle: random multi-event increments (biased to overflow a narrow counter),
random hardware freeze, and at most one register access (CTRL incl. CLEAR /
SNAPSHOT / SAMPLE, CNT_EN, SAT, OVF W1C, CLR, PRE_LO/HI/LOAD, SNAP / LIVE reads,
reads and writes of unmapped and read-only offsets).  Checked every cycle:
cnt_o (all live counters), rb_rdata and rb_err of every access, irq_o and
frozen_o; the LIVE_LO -> LIVE_HI pair must return a coherent value.
"""
from __future__ import annotations

import cocotb
from cocotb.triggers import ReadOnly, RisingEdge

from hpcv.tbutil import env_int, publish, rng, start_clock

CTRL, STATUS, CNT_EN, SAT, OVF, OVF_IE, CLR, SNAP_OVF = 0x20, 0x24, 0x28, 0x2C, 0x30, 0x34, 0x38, 0x3C
PRE_LO, PRE_HI, PRE_LOAD, ERR_SRC, LATCH = 0x40, 0x44, 0x48, 0x4C, 0x50
RO = {0x000, 0x004, 0x008, 0x00C, 0x010, 0x014, SNAP_OVF, LATCH}


class Model:
    def __init__(self, n, w, inc_w):
        self.n, self.w, self.iw = n, w, inc_w
        self.mx = (1 << w) - 1
        self.cnt = [0] * n
        self.ovf = [0] * n
        self.snp = [0] * n
        self.snp_ovf = [0] * n
        self.sat = [0] * n
        self.cen = [1] * n
        self.ovf_ie = [0] * n
        self.en, self.frz, self.fov = 1, 0, 0
        self.pre = 0
        self.lat = None                      # (idx, hi word)

    def frozen(self, freeze_i):
        return self.frz or freeze_i or (self.fov and any(self.ovf))

    def access(self, we, addr, wdata):
        """combinational answer of the register bus in the strobe cycle -> (rdata, err)"""
        page, idx, hi = addr >> 8, (addr >> 3) & 31, (addr >> 2) & 1
        if page in (1, 2):
            if addr & 3 or idx >= self.n or we:
                return 0, 1
            v = (self.snp if page == 1 else self.cnt)[idx]
            if page == 2 and hi and self.lat and self.lat[0] == idx:
                return self.lat[1], 0
            return ((v >> 32) & 0xFFFFFFFF) if hi else (v & 0xFFFFFFFF), 0
        if addr in RO:
            if we:
                return 0, 1
            return None, 0                   # value not modelled (ID/INFO/... constants)
        known = {CTRL, STATUS, CNT_EN, SAT, OVF, OVF_IE, CLR, PRE_LO, PRE_HI, PRE_LOAD, ERR_SRC}
        if addr not in known:
            return 0, 1
        if we:
            return None, 0
        bits = lambda v: sum(b << i for i, b in enumerate(v))
        rd = {CTRL: self.en | self.frz << 1 | self.fov << 2, CNT_EN: bits(self.cen), SAT: bits(self.sat),
              OVF: bits(self.ovf), OVF_IE: bits(self.ovf_ie), CLR: 0, PRE_LOAD: 0,
              PRE_LO: self.pre & 0xFFFFFFFF, PRE_HI: (self.pre >> 32) & 0xFFFFFFFF}
        return rd.get(addr), 0

    def step(self, inc, freeze_i, op):
        we, addr, wdata = op if op else (0, None, 0)
        err = op is not None and self.access(we, addr, wdata)[1]
        wr = op is not None and we and not err
        rd = op is not None and not we and not err
        mask = [(wdata >> i) & 1 for i in range(self.n)]
        clear = wr and addr == CTRL and (wdata >> 8) & 1
        sample = wr and addr == CTRL and (wdata >> 10) & 1
        snap = wr and addr == CTRL and ((wdata >> 9) & 1 or sample)
        clr = [1 if clear else 0] * self.n
        if wr and addr == CLR:
            clr = [c | m for c, m in zip(clr, mask)]
        pre = mask if (wr and addr == PRE_LOAD) else [0] * self.n
        w1c = mask if (wr and addr == OVF) else [0] * self.n
        fz = self.frozen(freeze_i)
        new_snp = (list(self.cnt), list(self.ovf)) if snap else None
        for i in range(self.n):
            go = self.en and not fz and self.cen[i]
            d = inc[i] if go else 0
            s = self.cnt[i] + d
            carry = s > self.mx
            nxt = self.mx if (carry and self.sat[i]) else s & self.mx
            if clr[i]:
                self.cnt[i], self.ovf[i] = 0, 0
            elif pre[i]:
                self.cnt[i] = self.pre & self.mx
            elif sample:
                self.cnt[i], self.ovf[i] = d, 0
            else:
                self.cnt[i] = nxt
                self.ovf[i] = (self.ovf[i] & (1 - w1c[i])) | int(carry)
        if new_snp:
            self.snp, self.snp_ovf = new_snp
        if wr and addr == CTRL:
            self.en, self.frz, self.fov = wdata & 1, (wdata >> 1) & 1, (wdata >> 2) & 1
        if wr and addr == CNT_EN:
            self.cen = mask
        if wr and addr == SAT:
            self.sat = mask
        if wr and addr == OVF_IE:
            self.ovf_ie = mask
        if wr and addr == PRE_LO:
            self.pre = (self.pre & ~0xFFFFFFFF) | wdata
        if wr and addr == PRE_HI:
            self.pre = (self.pre & 0xFFFFFFFF) | (wdata << 32)
        if rd and addr is not None and addr >> 8 == 2:
            idx, hi = (addr >> 3) & 31, (addr >> 2) & 1
            if not hi:
                self.lat = (idx, None)     # filled with the value of the strobe cycle by the caller
            else:
                self.lat = None


@cocotb.test()
async def test_counter_bank_model(dut):
    """random events, freezes and register traffic; every cycle compared with the independent model"""
    n, w, iw = env_int("NUM_CNT", 4), env_int("CNT_W", 12), env_int("INC_W", 8)
    m = Model(n, w, iw)
    r = rng("perf")
    start_clock(dut)
    for s, v in (("rst_n", 0), ("rb_sel", 0), ("rb_we", 0), ("rb_addr", 0), ("rb_wdata", 0), ("inc_i", 0),
                 ("freeze_i", 0), ("snap_i", 0), ("err_i", 0)):
        getattr(dut, s).value = v
    for _ in range(3):
        await RisingEdge(dut.clk)
    dut.rst_n.value = 1
    errors = []
    stats = dict(cycles=0, overflows=0, sat_hits=0, reads=0, writes=0, err_accesses=0, pairs=0, snapshots=0)
    ncyc = env_int("HPC_NCYC", 6000)
    for cyc in range(ncyc):
        await RisingEdge(dut.clk)
        inc = [r.choice([0, 0, 1, r.randrange(1 << iw), (1 << iw) - 1]) for _ in range(n)]
        frz = 1 if r.random() < 0.05 else 0
        op = None
        x = r.random()
        if x < 0.30:
            kind = r.random()
            if kind < 0.35:
                addr = 0x200 + 8 * r.randrange(n) + 4 * r.randrange(2)
                op = (0, addr, 0)
            elif kind < 0.45:
                op = (0, 0x100 + 8 * r.randrange(n) + 4 * r.randrange(2), 0)
            elif kind < 0.55:
                op = (1, CTRL, r.choice([1, 1, 1, 0, 3, 5, 1 | 0x100, 1 | 0x200, 1 | 0x400]))
            elif kind < 0.62:
                op = (1, SAT, r.getrandbits(n))
            elif kind < 0.68:
                op = (1, OVF, r.getrandbits(n))
            elif kind < 0.72:
                op = (1, CLR, r.getrandbits(n))
            elif kind < 0.76:
                op = (1, CNT_EN, r.getrandbits(n) | 1)
            elif kind < 0.80:
                reg = r.choice([PRE_LO, PRE_HI])        # biased to the top of the range: wide overflows
                op = (1, reg, r.choice([r.getrandbits(32), 0xFFFFFFFF, 0xFFFFFFF0 if reg == PRE_LO else 0xFF]))
            elif kind < 0.84:
                op = (1, PRE_LOAD, r.getrandbits(n))
            elif kind < 0.92:
                op = (0, r.choice([CTRL, CNT_EN, SAT, OVF, PRE_LO, PRE_HI]), 0)
            else:                                                     # illegal accesses
                op = r.choice([(1, 0x000, 1), (1, 0x200, 5), (0, 0x200 + 8 * n, 0), (0, 0x0F0, 0), (1, 0x104, 0),
                               (0, 0x201, 0), (1, LATCH, 0)])
        dut.inc_i.value = sum(v << (iw * i) for i, v in enumerate(inc))
        dut.freeze_i.value = frz
        if op:
            dut.rb_sel.value, dut.rb_we.value, dut.rb_addr.value, dut.rb_wdata.value = 1, op[0], op[1], op[2]
        else:
            dut.rb_sel.value = 0
        await ReadOnly()
        cnt_o = int(dut.cnt_o.value)
        got = [(cnt_o >> (w * i)) & ((1 << w) - 1) for i in range(n)]
        if got != m.cnt:
            errors.append(f"cycle {cyc}: cnt_o {got} != model {m.cnt}")
        if int(dut.frozen_o.value) != int(bool(m.frozen(frz))):
            errors.append(f"cycle {cyc}: frozen_o {int(dut.frozen_o.value)} != model")
        irq = int(any(o and e for o, e in zip(m.ovf, m.ovf_ie)))
        if int(dut.irq_o.value) != irq:
            errors.append(f"cycle {cyc}: irq_o {int(dut.irq_o.value)} != model {irq}")
        if op:
            exp, eerr = m.access(*op)
            rerr, rdat = int(dut.rb_err.value), int(dut.rb_rdata.value)
            stats["writes" if op[0] else "reads"] += 1
            stats["err_accesses"] += eerr
            if rerr != eerr:
                errors.append(f"cycle {cyc}: access {op}: rb_err {rerr}, model {eerr}")
            elif exp is not None and not op[0] and rdat != exp:
                errors.append(f"cycle {cyc}: read {op[1]:#x}: {rdat:#x}, model {exp:#x}")
            if not op[0] and not eerr and op[1] >> 8 == 2:
                idx, hi = (op[1] >> 3) & 31, (op[1] >> 2) & 1
                if hi and m.lat and m.lat[0] == idx:
                    stats["pairs"] += 1
        stats["overflows"] += sum(1 for i in range(n) if m.cnt[i] + inc[i] > m.mx)
        stats["snapshots"] += int(bool(op and op[0] and op[1] == CTRL and op[2] & 0x600))
        hi_latch = None
        if op and not op[0] and op[1] >> 8 == 2 and not (op[1] >> 2) & 1 and not m.access(*op)[1]:
            idx = (op[1] >> 3) & 31
            hi_latch = (idx, (m.cnt[idx] >> 32) & 0xFFFFFFFF)
        m.step(inc, frz, op)
        if hi_latch:
            m.lat = hi_latch
        stats["cycles"] += 1
        if len(errors) > 20:
            break
    for e in errors[:10]:
        dut._log.error(e)
    publish({"errors": len(errors), "stats": stats, "first_errors": errors[:5]})
    assert not errors, f"{len(errors)} mismatch(es); first: {errors[0]}"
