# SilicaFlux-HPC · Module 09 — Compute-tile hardware verification framework

`tests/hpc/` · Aureom.AI | SilicaFlux-HPC

A reusable, automated verification framework for the whole SilicaFlux-HPC compute tile: FP32 arithmetic (Modules
01/02), vector lane (02), vector array (03), scratchpad (04), DMA adapter (05), command queues, performance counters
(07) and the integrated tile. It is built to find arithmetic, protocol, memory, DMA, scheduling and integration
defects before FPGA implementation or tapeout, and to report only what was actually run.

**Results of the last run:** `reports/VERIFICATION_REPORT.md` (generated; every number comes from result records).
**What is not verified:** `docs/KNOWN_GAPS.md`. **IEEE 754 / design choices the models encode:** `docs/DEVIATIONS.md`.
**Requirement → test map:** `docs/VERIFICATION_PLAN.md`. **What existed before:** `docs/AUDIT.md`.

## Quick start

```bash
make hpc-setup
```

```bash
make hpc-test
```

```bash
make hpc-regression MATRIX=nightly
```

`make hpc-setup` checks / installs the SilicaFlux tool baseline (Verilator 5.020, Icarus Verilog 12, Yosys 0.33 with
yosys-smtbmc — the Ubuntu 24.04 packages), creates `build/venv` (Python 3.12, cocotb 1.9.2, gmpy2/MPFR, z3-solver),
extracts and pins the RTL and builds the SoftFloat reference. All targets also work from the repository root.

| Target | Runs |
|---|---|
| `make hpc-test` | every simulation suite + formal (CI matrix) |
| `make hpc-test-fp32` | FP32 arithmetic: oracle cross-check, directed categories, random, FMA stress, TestFloat |
| `make hpc-test-vector` | vector lane, vector array, command queues |
| `make hpc-test-memory` | scratchpad |
| `make hpc-test-dma` | DMA adapter with the real scratchpad |
| `make hpc-test-integration` | integrated tile kernels + performance counters |
| `make hpc-test-cmdq`, `make hpc-test-perf` | command queues / performance counters alone |
| `make hpc-formal` | formal properties (BMC, k-induction, cover, negative controls) |
| `make hpc-legacy` | every module's own regression, re-run unchanged |
| `make hpc-mutation` | mutation campaign: can the framework detect real defects? |
| `make hpc-regression` | all of the above; `MATRIX=nightly` for the extended matrix |
| `make hpc-report` | regenerate coverage + report from the records |

Variables: `MATRIX=ci|nightly`, `SEED=<n>` (base seed), `HPC_JOBS`, `HPC_COVERAGE=0|1` (Verilator line coverage,
default 1), `HPC_WAVES_ON_FAIL=0|1` (re-run failing tests with waveforms, default 1).

## How it works

```
common/fetch_rtl.py      extract the module archives from the repository (SHA-256 pinned in rtl_manifest.json),
                         check every vendored RTL copy is byte-identical, write build/rtl_revision.json
common/filelists.py      single source of RTL file lists (canonical copies)
common/sv/               hpc_rv_checker (ready/valid rules R1-R3), hpc_txn_conservation (C1-C2)
reference_models/        fp32_softfloat (SoftFloat-3e shim, primary oracle), fp32_mpfr (independent MPFR model),
                         fp32_crosscheck, varray_model, spm_model, dma_model, cmdq_model (+ FENCE trace checker)
lib/hpcv/                cocotb components: cycle engine, ready/valid Source/Sink/Monitor, stall patterns,
                         scoreboards, SFB2 slave + byte memory, array / DMA environments, cocotb runner, results
fp32/                    fp32_units_top.sv (all M02 units + M01 fp32_fma) + Verilator C++ harness (SoftFloat linked)
vector_lane/  vector_array/  scratchpad/  dma/  command_queue/  perf_counters/  tile_integration/
                         one testbench wrapper (DUT unmodified + SV checkers), cocotb tests, a run_<suite>.py with
                         its CI and nightly matrices
formal/                  harnesses + run_formal.py (Yosys -> SMT2 -> yosys-smtbmc + z3)
regression/              run_regression.py, legacy.py, mutants.py, coverage.py, make_report.py
env/                     setup.sh, requirements.txt (exact versions)
reports/                 VERIFICATION_REPORT.md, results.json, junit.xml (generated)
```

* **RTL is never copied into `tests/hpc`.** The repository stores each module as a zip; the framework extracts the
  archives that are in the repository and refuses to run on a changed archive until it is re-pinned
  (`python3 common/fetch_rtl.py --update-pins`), so every report names the RTL it verified.
* **Golden models are validated before use**: SoftFloat-3e (TestFloat-validated, C, integer-only) is the primary
  FP32 oracle; it is cross-checked against an MPFR model written here and against Module 02's exact model on every
  run (`fp32/oracle_crosscheck`), and that check is shown able to fail. Python floats are never an oracle.
* **Every test case writes one record** (`build/results/<suite>/<test>.json`: status, seed, configuration,
  metrics, log, waveform, exact reproduction command). Reports and CI read only those records. Status is PASS,
  FAIL, BLOCKED (the RTL feature does not exist; never counted as passed) or SKIP.
* **Reproduce a test**: copy its `repro` command from `reports/results.json` or the report (each suite runner takes
  `--config`, `--only <test>` and `--seed`). Failing tests are automatically re-run with waveforms; the dump path
  is recorded.
* **Coverage figures are computed from collected data**: merged Verilator line coverage of every instrumented run
  and functional bins hit by the recorded tests (`regression/coverage.py`).

## Adding a test

1. Put the cocotb test in the suite directory (use `hpcv.cycle.Engine` + `Source`/`Sink`, a scoreboard, and
   `hpcv.tbutil.finish` / `publish` so the record carries metrics).
2. Add its name to the suite's `TESTS` list and, if it needs a new parameter set, to `CONFIGS` and the `MATRIX`.
3. New design defect classes: add a mutant to `regression/mutants.py` (`FRAMEWORK`) and check it is killed.

## Continuous integration

`.github/workflows/hpc-verification.yml`: the mandatory CI matrix on every push / pull request touching the HPC
archives or the framework; the nightly matrix (one job per suite group, then one merged report) on a schedule.
