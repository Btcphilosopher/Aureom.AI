// =============================================================================
// SilicaFlux-HPC verification :: tb_varray_top -- cocotb wrapper for hpc_vector_array
// DUT: Module 03 hpc_vector_array (unmodified) + framework checkers:
//   chk_cmd / chk_opnd   producer contract of the testbench (stable while stalled)
//   chk_res  / chk_cpl   DUT outputs: stable while stalled, low in reset
//   cons_cmd             exactly one completion per accepted command
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_varray_top #(
  parameter int NUM_LANES      = 2,
  parameter int VL_W           = 16,
  parameter int TID_W          = 8,
  parameter int CMD_DEPTH      = 4,
  parameter int TRK_DEPTH      = 8,
  parameter int CPL_DEPTH      = 4,
  parameter bit RED_EN         = 1'b1,
  parameter int RED_LAT        = 3,
  parameter int LANE_ROB_DEPTH = 8,
  parameter int LAT_FADD       = 3,
  parameter int LAT_FMUL       = 3,
  parameter int LAT_FMA        = 4,
  parameter int LAT_MISC       = 1,
  parameter int LAT_IMUL       = 2,
  parameter bit EN_FCMP        = 1'b1,
  parameter bit EN_INT         = 1'b1,
  localparam int N = NUM_LANES
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              cmd_valid,
  output logic                   cmd_ready,
  input  wire logic [4:0]        cmd_op,
  input  wire logic [2:0]        cmd_rm,
  input  wire logic [VL_W-1:0]   cmd_vl,
  input  wire logic              cmd_vm,
  input  wire logic [2:0]        cmd_bcast,
  input  wire logic [31:0]       cmd_scalar,
  input  wire logic              cmd_red,
  input  wire logic [TID_W-1:0]  cmd_tid,
  input  wire logic              opnd_valid,
  output logic                   opnd_ready,
  input  wire logic [N*32-1:0]   opnd_a, opnd_b, opnd_c,
  input  wire logic [N-1:0]      opnd_mask,
  output logic                   res_valid,
  input  wire logic              res_ready,
  output logic [N*32-1:0]        res_data,
  output logic [N*5-1:0]         res_flags,
  output logic [N-1:0]           res_mask,
  output logic [TID_W-1:0]       res_tid,
  output logic [VL_W-1:0]        res_beat,
  output logic                   res_last,
  output logic                   cpl_valid,
  input  wire logic              cpl_ready,
  output logic [TID_W-1:0]       cpl_tid,
  output logic [4:0]             cpl_flags,
  output logic                   cpl_illegal,
  output logic [VL_W-1:0]        cpl_count,
  output logic                   cpl_red,
  output logic [31:0]            cpl_result,
  input  wire logic [N-1:0]      lane_hold,
  output logic                   busy,
  output logic [31:0]            chk_cmd_err, chk_opnd_err, chk_res_err, chk_cpl_err, cons_err, cons_outstanding
);
  logic [hpc_varray_pkg::PC_N*32-1:0] perf;
  hpc_vector_array #(.NUM_LANES(N), .VL_W(VL_W), .TID_W(TID_W), .CMD_DEPTH(CMD_DEPTH), .TRK_DEPTH(TRK_DEPTH),
                     .CPL_DEPTH(CPL_DEPTH), .RED_EN(RED_EN), .RED_LAT(RED_LAT), .PERF_EN(1'b1), .PERF_CW(32),
                     .LANE_ROB_DEPTH(LANE_ROB_DEPTH), .LAT_FADD(LAT_FADD), .LAT_FMUL(LAT_FMUL), .LAT_FMA(LAT_FMA),
                     .LAT_MISC(LAT_MISC), .LAT_IMUL(LAT_IMUL), .EN_FCMP(EN_FCMP), .EN_INT(EN_INT)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_op_i(cmd_op), .cmd_rm_i(cmd_rm), .cmd_vl_i(cmd_vl),
    .cmd_vm_i(cmd_vm), .cmd_bcast_i(cmd_bcast), .cmd_scalar_i(cmd_scalar), .cmd_red_i(cmd_red), .cmd_tid_i(cmd_tid),
    .opnd_valid_i(opnd_valid), .opnd_ready_o(opnd_ready), .opnd_a_i(opnd_a), .opnd_b_i(opnd_b), .opnd_c_i(opnd_c),
    .opnd_mask_i(opnd_mask),
    .res_valid_o(res_valid), .res_ready_i(res_ready), .res_data_o(res_data), .res_flags_o(res_flags),
    .res_mask_o(res_mask), .res_tid_o(res_tid), .res_beat_o(res_beat), .res_last_o(res_last),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_tid_o(cpl_tid), .cpl_flags_o(cpl_flags),
    .cpl_illegal_o(cpl_illegal), .cpl_count_o(cpl_count), .cpl_red_o(cpl_red), .cpl_result_o(cpl_result),
    .lane_hold_i(lane_hold), .busy_o(busy), .perf_clear_i(1'b0), .perf_cnt_o(perf));

  logic [31:0] x0, x1, x2, x3, x4, x5, x6;
  hpc_rv_checker #(.NAME("cmd"), .W(5 + 3 + VL_W + 1 + 3 + 32 + 1 + TID_W), .RESET_LOW(1'b0)) chk_cmd (
    .clk, .rst_n, .valid(cmd_valid), .ready(cmd_ready),
    .payload({cmd_op, cmd_rm, cmd_vl, cmd_vm, cmd_bcast, cmd_scalar, cmd_red, cmd_tid}), .err_cnt(chk_cmd_err), .xfer_cnt(x0));
  hpc_rv_checker #(.NAME("opnd"), .W(3 * N * 32 + N), .RESET_LOW(1'b0)) chk_opnd (
    .clk, .rst_n, .valid(opnd_valid), .ready(opnd_ready), .payload({opnd_a, opnd_b, opnd_c, opnd_mask}),
    .err_cnt(chk_opnd_err), .xfer_cnt(x1));
  hpc_rv_checker #(.NAME("res"), .W(N * 32 + N * 5 + N + TID_W + VL_W + 1), .RESET_LOW(1'b1)) chk_res (
    .clk, .rst_n, .valid(res_valid), .ready(res_ready),
    .payload({res_data, res_flags, res_mask, res_tid, res_beat, res_last}), .err_cnt(chk_res_err), .xfer_cnt(x2));
  hpc_rv_checker #(.NAME("cpl"), .W(TID_W + 5 + 1 + VL_W + 1 + 32), .RESET_LOW(1'b1)) chk_cpl (
    .clk, .rst_n, .valid(cpl_valid), .ready(cpl_ready),
    .payload({cpl_tid, cpl_flags, cpl_illegal, cpl_count, cpl_red, cpl_result}), .err_cnt(chk_cpl_err), .xfer_cnt(x3));
  hpc_txn_conservation #(.NAME("varray_cmd")) cons (
    .clk, .rst_n, .acc(cmd_valid && cmd_ready), .cpl(cpl_valid && cpl_ready), .outstanding(cons_outstanding),
    .err_cnt(cons_err), .acc_total(x4), .cpl_total(x5));
endmodule
`default_nettype wire
