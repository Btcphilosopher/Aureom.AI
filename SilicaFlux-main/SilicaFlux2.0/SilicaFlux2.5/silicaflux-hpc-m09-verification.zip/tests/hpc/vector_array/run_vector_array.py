#!/usr/bin/env python3
"""Vector-array suite (hpc_vector_array, Module 03).

Parameterised over NUM_LANES 1/2/4/8 (brief §9) and queue depths; CI runs a
small mandatory subset, nightly the extended matrix.
usage: run_vector_array.py [--matrix ci|nightly] [--sim verilator|icarus] [--config NAME] [--only SUBSTR] [--seed N]
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import cocorun, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "vector_array"
BASE = dict(VL_W=16, TID_W=8, CMD_DEPTH=4, TRK_DEPTH=8, CPL_DEPTH=4, RED_EN=1, RED_LAT=3, LANE_ROB_DEPTH=8,
            LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, EN_FCMP=1, EN_INT=1)
CONFIGS = {
    "n1": dict(BASE, NUM_LANES=1),
    "n2": dict(BASE, NUM_LANES=2),
    "n4": dict(BASE, NUM_LANES=4),
    "n8": dict(BASE, NUM_LANES=8),
    "n4_shallow": dict(BASE, NUM_LANES=4, CMD_DEPTH=1, TRK_DEPTH=2, CPL_DEPTH=1, LANE_ROB_DEPTH=2),
    "n2_deep": dict(BASE, NUM_LANES=2, CMD_DEPTH=8, TRK_DEPTH=12, CPL_DEPTH=8, RED_LAT=4, LAT_FMA=6, LAT_FADD=4),
    "n4_nored": dict(BASE, NUM_LANES=4, RED_EN=0, EN_FCMP=0),
}
TESTS = ["test_elementwise", "test_reduction", "test_mixed", "test_long_vector", "test_reset", "test_throughput"]
MATRIX = {
    "ci": dict(configs=["n1", "n4_shallow", "n8"], seeds=1, ncmd=120, long_vl=1024, icarus=["test_mixed"],
               icarus_cfg=["n2"]),
    "nightly": dict(configs=list(CONFIGS), seeds=3, ncmd=500, long_vl=65535, icarus=["test_mixed", "test_reset"],
                    icarus_cfg=["n2", "n4"]),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--sim", default=None, choices=["verilator", "icarus"])
    ap.add_argument("--only", default="")
    ap.add_argument("--config", action="append")
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    sim.ensure_rtl()
    sim.ensure_ref()
    srcs = FL.files("varray") + FL.checker_files() + [HERE / "tb_varray_top.sv"]
    print(f"== vector_array suite, matrix {a.matrix}")
    runs = []
    if a.sim in (None, "verilator"):
        runs += [(c, "verilator", [t for t in TESTS if a.only in t]) for c in (a.config or mx["configs"])]
    if a.sim in (None, "icarus"):
        runs += [(c, "icarus", [t for t in mx["icarus"] if a.only in t]) for c in (a.config or mx["icarus_cfg"])]
    for cfg, s, tests in runs:
        P = CONFIGS[cfg]
        for si in range(mx["seeds"] if s == "verilator" else 1):
            seed = a.seed + si
            env = {**P, "HPC_NCMD": mx["ncmd"] if s == "verilator" else 40,
                   "HPC_LONG_VL": mx["long_vl"] if s == "verilator" else 256}
            if not tests:
                continue
            cocorun.run_suite(SUITE, cfg, toplevel="tb_varray_top", sources=srcs, test_module="test_vector_array",
                              test_dir=HERE, testcases=tests, parameters=P, sim=s, seed=seed, env=env,
                              repro_hint=f"python3 tests/hpc/vector_array/run_vector_array.py --sim {{sim}} "
                                         f"--config {cfg} --only {{tc}} --seed {{seed}}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
