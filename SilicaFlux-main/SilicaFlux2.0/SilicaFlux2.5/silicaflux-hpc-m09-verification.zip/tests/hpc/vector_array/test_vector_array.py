"""cocotb tests for hpc_vector_array (Module 03) through tb_varray_top.

Expected result beats and completion records come from
reference_models/varray_model.py (written from the interface and reduction
specifications; element arithmetic and every reduction add by SoftFloat-3e).
"""
from __future__ import annotations

import cocotb
from cocotb.triggers import ClockCycles, FallingEdge, ReadOnly

from hpcv.cycle import val
from hpcv.tbutil import env_int, finish, rng, start_clock
from hpcv.varray_env import CHK, VArrayEnv, gen_cmd, setup, stalls_from_env
from reference_models import fp32_softfloat as SF


def _extra(env, **kw):
    d = {"commands": env.cmd_accepted, "coverage": env.cov, "res_bp_cycles": env.res.bp_cycles,
         "hold_contract_checks": env.hold_checks,
         "cpl_bp_cycles": env.cpl.bp_cycles, "cmd_stall_cycles": env.cmd.stall_cycles,
         "opnd_stall_cycles": env.opnd.stall_cycles}
    d.update(kw)
    return d


@cocotb.test()
async def test_elementwise(dut):
    """random elementwise commands: all ops, masks, broadcast, tails, illegal; stalls + lane holds"""
    env = VArrayEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("elem")
    for t in range(env_int("HPC_NCMD", 150)):
        env.send(gen_cmd(r, env.n, t & 0xFF, red_p=0.0, max_vl=env_int("HPC_MAXVL", 40)))
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra=_extra(env))


@cocotb.test()
async def test_reduction(dut):
    """sum (FMV), dot product (FMUL) and FMA-family reductions: defined tree + beat order, all rounding modes"""
    env = VArrayEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("red")
    for t in range(env_int("HPC_NCMD", 150)):
        env.send(gen_cmd(r, env.n, t & 0xFF, red=1, max_vl=env_int("HPC_MAXVL", 40), illegal_p=0.03))
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra=_extra(env))


@cocotb.test()
async def test_mixed(dut):
    """elementwise and reduction commands interleaved; completions in command order"""
    env = VArrayEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("mixed")
    for t in range(env_int("HPC_NCMD", 150)):
        env.send(gen_cmd(r, env.n, t & 0xFF, red_p=0.3, max_vl=env_int("HPC_MAXVL", 40)))
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra=_extra(env))


@cocotb.test()
async def test_long_vector(dut):
    """vectors far longer than N (nothing truncated): FMADD and a dot product"""
    env = VArrayEnv(dut, cmd_stall="none", opnd_stall="random:0.9", res_stall="random:0.8", cpl_stall="none")
    await setup(dut, env)
    r = rng("long")
    vl = env_int("HPC_LONG_VL", 2048)
    env.send(gen_cmd(r, env.n, 1, ops=[SF.FMADD], vl=vl, red=0, vm_p=0.0, bcast_p=0.0))
    env.send(gen_cmd(r, env.n, 2, ops=[SF.FMUL], vl=vl, red=1, vm_p=0.0, bcast_p=0.0))
    env.send(gen_cmd(r, env.n, 3, ops=[SF.FADD], vl=vl // 3 + 1, red=0, vm_p=1.0, bcast_p=0.0))
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra=_extra(env, vl=vl))


@cocotb.test()
async def test_reset(dut):
    """asynchronous resets mid-stream: everything in flight discarded, no stale beat or completion"""
    env = VArrayEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("reset")
    tid = 0
    discarded = 0
    for k in range(env_int("HPC_RESETS", 6)):
        for _ in range(r.randint(3, 20)):
            env.send(gen_cmd(r, env.n, tid & 0xFF, red_p=0.3))
            tid += 1
        await ClockCycles(dut.clk, r.randint(5, 120))
        await FallingEdge(dut.clk)
        env.eng.in_reset = True
        dut.rst_n.value = 0
        await ReadOnly()
        for s in ("cmd_ready", "opnd_ready", "res_valid", "cpl_valid", "busy"):
            if val(getattr(dut, s)):
                env.eng.error(f"{s} high immediately after asynchronous reset assertion")
        await FallingEdge(dut.clk)
        discarded += env.flush_for_reset()
        env.eng.reset_agents()
        await ClockCycles(dut.clk, r.randint(1, 3))
        await FallingEdge(dut.clk)
        dut.rst_n.value = 1
        env.eng.in_reset = False
    for _ in range(10):
        env.send(gen_cmd(r, env.n, tid & 0xFF, red_p=0.3))
        tid += 1
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra=_extra(env, discarded=discarded))


@cocotb.test()
async def test_throughput(dut):
    """no stalls: back-to-back elementwise commands take ceil(vl/N) cycles each (Module 03 claim)"""
    env = VArrayEnv(dut)
    await setup(dut, env)
    r = rng("thr")
    k, per = 24, 8
    for t in range(k):
        env.send(gen_cmd(r, env.n, t, ops=[SF.FMADD], vl=env.n * per, red=0, vm_p=0.0, bcast_p=0.0))
    await env.drain()
    span = env.last_res - env.first_opnd + 1
    beats = k * per
    # specification (Module 03 MICROARCHITECTURE §6): one beat / cycle provided LANE_ROB_DEPTH >= LAT + 2
    # and TRK_DEPTH >= LAT + 2; otherwise each resource bounds the rate to depth / (LAT + 2)
    C = env.C
    spec = min(1.0, C["LANE_ROB_DEPTH"] / (C["LAT_FMA"] + 2), C["TRK_DEPTH"] / (C["LAT_FMA"] + 2))
    eff = beats / max(1, span - 12)          # pipeline fill / drain allowance
    if eff < 0.97 * spec:
        env.eng.error(f"streaming efficiency {eff:.3f} beats/cycle < specified {spec:.3f} "
                      f"(span {span} cycles for {beats} beats)")
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK,
           extra=_extra(env, beats=beats, span_cycles=span, beats_per_cycle=round(beats / span, 4),
                                  spec_beats_per_cycle=round(spec, 4)))
