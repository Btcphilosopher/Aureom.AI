# SilicaFlux-HPC compute tile — verification report

Generated 2026-11-07 16:13 UTC by `tests/hpc/regression/make_report.py` from the result records of the last run (matrix **ci**, base seed 1). Every figure below is read from files written by that run.

## 1. Summary

| Test cases | Passed | Failed | Blocked | Skipped / not applicable |
|---|---|---|---|---|
| **255** | **248** | **1** | **5** | 1 |

Design-test failures (every suite except `mutation`): **0**. Failed `mutation` records are defects the framework did not detect (1 of them analysed and documented as known gaps in `docs/KNOWN_GAPS.md`); they measure the framework, not the RTL. Blocked = the RTL feature does not exist.

| Suite | Cases | Pass | Fail | Blocked | Skip | Simulators | Wall time (s) |
|---|---|---|---|---|---|---|---|
| fp32 | 43 | 43 | 0 | 0 | 0 | python, verilator | 100 |
| vector_lane | 11 | 11 | 0 | 0 | 0 | icarus, verilator | 6 |
| vector_array | 19 | 19 | 0 | 0 | 0 | icarus, verilator | 8 |
| scratchpad | 33 | 33 | 0 | 0 | 0 | icarus, verilator | 11 |
| dma | 25 | 25 | 0 | 0 | 0 | icarus, verilator | 25 |
| command_queue | 21 | 17 | 0 | 4 | 0 | python, verilator | 5 |
| perf_counters | 5 | 5 | 0 | 0 | 0 | icarus, verilator | 3 |
| tile_integration | 12 | 11 | 0 | 1 | 0 | icarus, verilator | 55 |
| formal | 38 | 38 | 0 | 0 | 0 | yosys-smtbmc | 181 |
| legacy | 6 | 6 | 0 | 0 | 0 | module scripts | 906 |
| mutation | 42 | 40 | 1 | 0 | 1 | framework suites | 2951 |

## 2. RTL revision and tools

* Repository commit `ba7a6c0491c7b1ba54e4978f7b2444797384b59f` (claude/vigilant-brahmagupta-c14chv, 2026-11-07T13:34:31+00:00); uncommitted changes to the module archives: none.
* RTL digest (SHA-256 over every compiled RTL file): `603bdc38d46e4f94e59a992698f39be561698accad4a10288249a2483b83e6d6` (77 files with their SHA-256 in `reports/rtl_revision.json`).
* Vendored RTL copies byte-identical to their canonical source: 118/120 (+2 documented difference(s): the Module 07 observation-port patch).

| Archive | SHA-256 |
|---|---|
| Module 01 FP32 FMA (fp32_fma) — `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-fp32-fma.zip` | `8ca1a6d8c8046663…` |
| Module 02 vector lane (hpc_vector_lane) — `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m02-vector-lane.zip` | `e76a238e143113e1…` |
| Module 03 vector array (hpc_vector_array) — `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m03-vector-array.zip` | `c1b6d2946c5bb56b…` |
| Module 04 scratchpad (hpc_scratchpad) — `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m04-scratchpad.zip` | `1457466c57542c8c…` |
| Module 05 DMA adapter (hpc_dma_adapter) — `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m05-dma-adapter.zip` | `655b668494942bae…` |
| Module 07 performance counters (hpc_perf_counters) — `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m07-perf-counters.zip` | `26b44b250ac12b26…` |

| Tool | Version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| python | 3.12.3 |
| gcc | gcc (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0 |
| cocotb | 1.9.2 |
| mpfr | MPFR 4.2.2 |
| gmpy2 | 2.3.2 |
| z3 | 5.3.3 |
| softfloat | Berkeley SoftFloat Release 3e (vendored in Module 01, git f74b1e4) |
| testfloat | Berkeley TestFloat Release 3e (vendored in Module 01, git 06b2007) |

## 3. Failed tests

| Test | Seed | Reason | Waveform | Reproduce |
|---|---|---|---|---|
| mutation/M04-M14 | None | known framework gap G4: the parity path needs SRAM fault injection, which the framework does not perform (docs/KNOWN_GAPS.md) |  | `python3 tests/hpc/regression/mutants.py --only M04-M14` |

## 4. Blocked tests (not counted as passed)

* **command_queue/dependencies/D1_raw_war_waw_between_commands** — No RTL tracks dependencies between tile commands: hpc_vector_array is a streaming unit without addresses; hpc_tile_vseq (M05) runs one job at a time and has no command set.
* **command_queue/dependencies/cross_unit_dma_compute_overlap** — No hardware scheduler overlaps DMA and compute commands; ordering between them is the host's job today (exercised by tile_integration kernel F, sequenced by the testbench).
* **command_queue/fence/F1_no_start_before_predecessors_complete** — No RTL implements FENCE: there is no tile command processor (no Module 06 archive in the repository).
* **command_queue/fence/F2_fence_completion_ordering** — No RTL implements FENCE (see F1).
* **tile_integration/kernel/D_dot_product_tile_level** — The dot product (FMUL + sum reduction) is implemented in hpc_vector_array and verified there (vector_array test_reduction, FMUL/red), but no tile RTL can launch it from the scratchpad: hpc_tile_vseq drives cmd_red_i = 1'b0 and has no reduction result path.

## 5. Evidence by area

### 5.1 FP32 arithmetic

* Golden-model validation: 201175 vectors, 0 mismatch(es) between Berkeley SoftFloat Release 3e, RISCV specialisation; GNU MPFR 4.2.2 via gmpy2 2.3.2; Module 02 exact model fp32_ref.py.
* 35,002,592 operations compared bit-exactly (result incl. NaN encoding, 5 flags, id/tag) against SoftFloat-3e across the FP32 suite; TestFloat-3e streams additionally checked by `testfloat_ver` on the DUT outputs.
* TestFloat runs: 23 (23 passed): L1/add/RDN, L1/add/RMM, L1/add/RNE, L1/add/RTZ, L1/add/RUP, L1/eq/RNE, L1/le/RNE, L1/lt/RNE, L1/mul/RDN, L1/mul/RMM, L1/mul/RNE, L1/mul/RTZ, L1/mul/RUP, L1/mulAdd/RDN, L1/mulAdd/RMM, L1/mulAdd/RNE, L1/mulAdd/RTZ, L1/mulAdd/RUP, L1/sub/RDN, L1/sub/RMM, L1/sub/RNE, L1/sub/RTZ, L1/sub/RUP.

### 5.2 Formal verification (bounds and assumptions as run)

| Property set | Result | Kind | Covers | Assumptions |
|---|---|---|---|---|
| address_bounds/hpc_spm_addr_map/B16_HIGH_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B16_LOW_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B16_XOR_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B1_LOW_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B2_HIGH_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B2_LOW_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B2_XOR_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B4_HIGH_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B4_LOW_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B4_XOR_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B8_HIGH_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B8_LOW_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| address_bounds/hpc_spm_addr_map/B8_XOR_base20000000_bwe1 | PASS (BMC PASS, induction: PROVEN (combinational: depth 1 covers every input)) | unbounded proof | 1 | none (combinational; every 32-bit address pair) |
| arbitration/hpc_spm_bank_arb/P2_1R1W_FIXED | PASS (BMC PASS, induction: PROVEN (k-induction, k=5)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P2_1R1W_RR | PASS (BMC PASS, induction: PROVEN (k-induction, k=5)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P2_1RW_FIXED | PASS (BMC PASS, induction: PROVEN (k-induction, k=5)) | unbounded proof | 2 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P2_1RW_RR | PASS (BMC PASS, induction: PROVEN (k-induction, k=5)) | unbounded proof | 2 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P2_2RW_FIXED | PASS (BMC PASS, induction: PROVEN (k-induction, k=5)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P2_2RW_RR | PASS (BMC PASS, induction: PROVEN (k-induction, k=5)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P3_1R1W_FIXED | PASS (BMC PASS, induction: PROVEN (k-induction, k=6)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P3_1R1W_RR | PASS (BMC PASS, induction: PROVEN (k-induction, k=6)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P3_1RW_FIXED | PASS (BMC PASS, induction: PROVEN (k-induction, k=6)) | unbounded proof | 2 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P3_1RW_RR | PASS (BMC PASS, induction: PROVEN (k-induction, k=6)) | unbounded proof | 2 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P3_2RW_FIXED | PASS (BMC PASS, induction: PROVEN (k-induction, k=6)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| arbitration/hpc_spm_bank_arb/P3_2RW_RR | PASS (BMC PASS, induction: PROVEN (k-induction, k=6)) | unbounded proof | 3 | reset in cycle 0; a request is held until granted (A8 only) |
| fifo/dma_fifo/D2 | PASS (BMC PASS, induction: not closed at k=8 (counterexample to induction; bounded result only)) | bounded proof to depth 12 | 1 | caller contract: no push while full unless popping, no pop while empty; clr and reset at any time |
| fifo/dma_fifo/D4 | PASS (BMC PASS, induction: not closed at k=12 (counterexample to induction; bounded result only)) | bounded proof to depth 12 | 1 | caller contract: no push while full unless popping, no pop while empty; clr and reset at any time |
| fifo/hpc_varray_fifo/D1 | PASS (BMC PASS, induction: PROVEN (k-induction, k=6)) | unbounded proof | 2 | caller contract: no push while full unless popping, no pop while empty; reset in cycle 0, asynchronous re-assertion allowed |
| fifo/hpc_varray_fifo/D2 | PASS (BMC PASS, induction: not closed at k=8 (counterexample to induction; bounded result only)) | bounded proof to depth 12 | 2 | caller contract: no push while full unless popping, no pop while empty; reset in cycle 0, asynchronous re-assertion allowed |
| fifo/hpc_varray_fifo/D4 | PASS (BMC PASS, induction: not closed at k=12 (counterexample to induction; bounded result only)) | bounded proof to depth 12 | 2 | caller contract: no push while full unless popping, no pop while empty; reset in cycle 0, asynchronous re-assertion allowed |
| neg/addr_map_xor_bank_wrong (negative control: mutated RTL) | refuted (as required) | — | — | hpc_spm_addr_map.sv: 'assign bank = word[BW-1:0] ^ word[2*BW-1:BW];' -> 'assign bank = wor |
| neg/arb_1r1w_write_read_hazard_dropped (negative control: mutated RTL) | refuted (as required) | — | — | hpc_spm_bank_arb.sv: 'if (we[idx]) g_a = !any_a && !(any_b && b_row == r);' -> 'if (we[idx |
| neg/arb_2rw_same_row_hazard_dropped (negative control: mutated RTL) | refuted (as required) | — | — | hpc_spm_bank_arb.sv: 'else         g_b = !any_b && !(a_row == r && (a_we \|\| we[idx]));' -> |
| neg/dma_fifo_count_wrong (negative control: mutated RTL) | refuted (as required) | — | — | dma_fifo.sv: 'assign count = wp - rp;' -> 'assign count = wp - rp - (AW+1)'(wp[0] & rp[0]) |
| neg/fifo_full_off_by_one (negative control: mutated RTL) | refuted (as required) | — | — | hpc_varray_fifo.sv: 'assign full_o  = (cnt_q == CW'(DEPTH));' -> 'assign full_o  = (cnt_q  |
| neg/fifo_read_pointer_not_advanced_on_push_pop (negative control: mutated RTL) | refuted (as required) | — | — | hpc_varray_fifo.sv: 'if (pop_i)  rd_q <= ptr_inc(rd_q);' -> 'if (pop_i && !push_i)  rd_q < |
| neg/lane_rob_head_skips_on_alloc (negative control: mutated RTL) | refuted (as required) | — | — | hpc_vector_lane.sv: 'if (retire) head_q <= ptr_inc(head_q);' -> 'if (retire) head_q <= all |
| request_conservation_ordering/hpc_vector_lane/ROB3 | PASS (BMC PASS, induction: not attempted) | bounded proof to depth 14 | 2 | tag of each accepted enabled op = its sequence number mod 16 (labelling only); reset in cycle 0, re-assertion allowed; EN_FCMP = EN_INT = 0, minimum latencies |

A bounded result means no counterexample exists within the stated number of cycles from reset; it is not a proof for longer traces. Only k-induction successes and the combinational address-map checks are unbounded proofs.

### 5.3 Mutation testing of the framework

Mutants killed 40, survived 1, not applicable 1 (matrix of the run). Per module:

| Module | Killed | Survived | Not applicable |
|---|---|---|---|
| m01 | 2 | 0 | 0 |
| m02 | 7 | 0 | 0 |
| m03 | 8 | 0 | 0 |
| m04 | 6 | 1 | 0 |
| m05 | 7 | 0 | 0 |
| m07 | 10 | 0 | 1 |

Survivors (verification gaps, see `docs/KNOWN_GAPS.md`):
* M04-M14 (hpc_scratchpad.sv): parity check disabled (no syndrome)

### 5.4 Module regressions re-run unchanged

| Module regression | Result | Time (s) |
|---|---|---|
| m01_fp32_fma_quick | PASS | 311 |
| m02_vector_lane_quick | PASS | 59 |
| m03_vector_array_quick | PASS | 33 |
| m04_scratchpad_quick | PASS | 197 |
| m05_dma_adapter_quick | PASS | 224 |
| m07_perf_counters_lint_unit | PASS | 83 |

## 6. Coverage (derived from collected data)

RTL line coverage, Verilator `--coverage-line`, merged over 114 instrumented runs: **1186/1373 lines = 86.4 %**. The FP32 C++ harness and Icarus runs are not instrumented.

| RTL module | Lines hit / found | % |
|---|---|---|
| DataFabric DMA engines (vendored) | 171 / 216 | 79.2 |
| M02 vector lane (+FP32 units) | 220 / 251 | 87.6 |
| M03 vector array | 244 / 244 | 100.0 |
| M03 vector array (M07 obs. variant) | 51 / 51 | 100.0 |
| M04 scratchpad | 101 / 127 | 79.5 |
| M05 DMA adapter + tile sequencer | 151 / 161 | 93.8 |
| M07 performance counters | 124 / 180 | 68.9 |
| SRAM wrapper library (vendored) | 124 / 143 | 86.7 |

Functional coverage (goal bins defined in `regression/coverage.py`; infeasible bins excluded with the reason stated there):

| Group | Bins hit / goal | % | Missed |
|---|---|---|---|
| fp32: operation x rounding mode | 35 / 35 | 100.0 | — |
| fp32: operation x exception flag | 43 / 43 | 100.0 | — |
| fp32: operand class x position | 280 / 280 | 100.0 | — |
| fp32: result class | 63 / 63 | 100.0 | — |
| lane: events observed | 4 / 4 | 100.0 | — |
| lane: operations retired | 16 / 16 | 100.0 | — |
| array: elementwise operations | 15 / 15 | 100.0 | — |
| array: reductions (sum, dot, others) | 4 / 4 | 100.0 | — |
| array: command features | 4 / 4 | 100.0 | — |
| array: lane counts exercised | 4 / 4 | 100.0 | — |
| scratchpad: response codes | 4 / 4 | 100.0 | — |
| scratchpad: behaviours observed | 5 / 5 | 100.0 | — |
| scratchpad: bank counts exercised | 4 / 4 | 100.0 | — |
| scratchpad: port models exercised | 3 / 3 | 100.0 | — |
| dma: completion codes | 12 / 12 | 100.0 | — |
| dma: directions | 4 / 4 | 100.0 | — |
| tile: kernels passing | 5 / 5 | 100.0 | — |

## 7. Seeds, waveforms, reproduction

* Seeds used: 1, 2, 3, 101. Every random stream is derived from (test name, seed); re-running a test with the same seed reproduces it cycle for cycle.
* Every record carries an exact reproduction command (`reports/results.json`, field `repro`).
* Waveforms are produced automatically for failing tests (re-run with tracing); the path is listed in §3.

## 8. Deviations and known gaps

See `docs/DEVIATIONS.md` (supported IEEE 754 deviations and implementation choices) and `docs/KNOWN_GAPS.md` (what is not verified, blocked tests, observations).
