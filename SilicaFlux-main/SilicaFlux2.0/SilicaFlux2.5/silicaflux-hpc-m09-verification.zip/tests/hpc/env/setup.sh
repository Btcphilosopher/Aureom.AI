#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC verification framework -- environment setup (idempotent)
#   * system tools (Ubuntu 24.04 packages = the SilicaFlux tool baseline):
#       Verilator 5.020, Icarus Verilog 12, Yosys 0.33 (+ yosys-smtbmc), gcc, make
#     installed with apt when missing and sudo/root is available
#   * Python venv tests/hpc/build/venv (Python 3.12 preferred: cocotb 1.9.2)
#   * RTL extraction / pinning (common/fetch_rtl.py) and the SoftFloat reference build
# =============================================================================
set -euo pipefail
HPC="$(cd "$(dirname "$0")/.." && pwd)"
BLD="${HPC_BUILD:-$HPC/build}"
need=()
for t in verilator iverilog yosys yosys-smtbmc gcc make; do command -v "$t" >/dev/null || need+=("$t"); done
if [ ${#need[@]} -gt 0 ]; then
  echo "missing tools: ${need[*]} -> installing Ubuntu packages"
  SUDO=""; [ "$(id -u)" -ne 0 ] && SUDO="sudo"
  $SUDO apt-get update -qq
  DEBIAN_FRONTEND=noninteractive $SUDO apt-get install -y -qq verilator iverilog yosys build-essential python3-venv
fi
PYBIN="${HPC_PYTHON_BASE:-$(command -v python3.12 || command -v python3)}"
if [ ! -x "$BLD/venv/bin/python" ]; then
  mkdir -p "$BLD"
  "$PYBIN" -m venv "$BLD/venv"
fi
"$BLD/venv/bin/pip" install -q --upgrade pip >/dev/null
"$BLD/venv/bin/pip" install -q -r "$HPC/env/requirements.txt"
"$BLD/venv/bin/python" "$HPC/common/fetch_rtl.py"
bash "$HPC/reference_models/softfloat/build_ref.sh"
"$BLD/venv/bin/python" - <<'PY'
import cocotb, gmpy2, z3
print(f"python env OK: cocotb {cocotb.__version__}, gmpy2 {gmpy2.version()} ({gmpy2.mpfr_version()}), z3 {z3.get_version_string()}")
PY
verilator --version; iverilog -V 2>&1 | head -1; yosys -V
