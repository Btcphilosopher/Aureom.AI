"""Reusable cocotb environment for hpc_dma_adapter (tb_dma_top).

* descriptors are predicted by reference_models/dma_model.py against golden
  memory images (external memory and scratchpad), applied in completion order
  (the adapter has one channel; descriptors execute in acceptance order);
* the fabric is the SfbSlave model (late write commit, errors, latency);
* the scratchpad is the real Module 04 RTL, initialised and read back through a
  dedicated testbench port (which also creates bank contention);
* per descriptor the environment counts the adapter's bus requests and
  error-free write acknowledgements between consecutive completion records:
  a rejected descriptor must make no bus access, a successful one must have
  every write acknowledged BEFORE its completion record is produced.
"""
from __future__ import annotations

from collections import deque

from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge

from reference_models import dma_model as DM

from .cycle import Engine, Sink, Source, val
from .scoreboard import InOrderScoreboard
from .sfb_slave import ByteMemory, SfbSlave
from .stall import Stall
from .tbutil import env_int, env_str, seed, start_clock

EXT_BASE = 0x10000000
EXT_BYTES = 0x10000
ERR_BASE = 0x10010000        # fabric error window (decode-error-like)
ERR_BYTES = 0x10000
SPM_BASE = 0x20000000


def cfg():
    return dict(ENGINE=env_int("ENGINE", 0), DUAL_PORT=env_int("DUAL_PORT", 0), MAX_OUT=env_int("MAX_OUT", 2),
                FIFO_DEPTH=env_int("FIFO_DEPTH", 8), BURST=env_int("BURST", 8), CMD_DEPTH=env_int("CMD_DEPTH", 2),
                CPL_DEPTH=env_int("CPL_DEPTH", 2), SPM_BYTES=env_int("SPM_BYTES", 65536), SPM_RL=env_int("SPM_RL", 1),
                FAB_SLICE=env_int("FAB_SLICE", 0))


class DmaEnv:
    def __init__(self, dut, *, fab_stall="random:0.7", fab_lat=(1, 6), cpl_stall="random:0.7",
                 cmd_stall="random:0.8", tb_spm_stall="none"):
        self.dut = dut
        self.C = cfg()
        self.np = 2 if (self.C["ENGINE"] and self.C["DUAL_PORT"]) else 1
        self.spm_bytes = self.C["SPM_BYTES"]
        s = seed()
        self.eng = Engine(dut)
        self.ext = ByteMemory(s)                              # actual external memory (fabric model)
        self.ext_exp = self.ext.copy()                         # golden image
        self.spm_exp = bytearray(self.spm_bytes)               # golden scratchpad image
        self.spm_known = bytearray(self.spm_bytes)
        self.fab = self.eng.add(SfbSlave(dut, self.ext, self.np, stall=fab_stall, lat=fab_lat,
                                         max_out=max(1, self.C["MAX_OUT"]), seed=s,
                                         error_windows=[(ERR_BASE, ERR_BASE + ERR_BYTES)]))
        self.cmd = self.eng.add(Source(dut, "cmd_valid", "cmd_ready",
                                       {"src": "cmd_src", "dst": "cmd_dst", "len": "cmd_len", "tag": "cmd_tag"},
                                       stall=Stall(cmd_stall, s + 1), on_accept=self._acc, name="dma_cmd"))
        self.cpl = self.eng.add(Sink(dut, "cpl_valid", "cpl_ready",
                                     {"tag": "cpl_tag", "err": "cpl_err", "code": "cpl_code", "addr": "cpl_err_addr",
                                      "bytes": "cpl_bytes"}, stall=Stall(cpl_stall, s + 2), on_item=self._cpl,
                                     name="dma_cpl"))
        self.tbq = deque()
        self.tbsrc = self.eng.add(Source(dut, "tb_req_valid", "tb_req_ready",
                                         {"we": "tb_req_we", "addr": "tb_req_addr", "wdata": "tb_req_wdata",
                                          "wstrb": "tb_req_wstrb", "tag": "tb_req_tag"},
                                         stall=Stall(tb_spm_stall, s + 3), on_accept=self._tb_acc, name="tb_spm_req"))
        self.tbsnk = self.eng.add(Sink(dut, "tb_rsp_valid", "tb_rsp_ready",
                                       {"rdata": "tb_rsp_rdata", "err": "tb_rsp_err", "we": "tb_rsp_we",
                                        "tag": "tb_rsp_tag"}, on_item=self._tb_rsp, name="tb_spm_rsp",
                                       raw_fields=("rdata",)))
        self.tb_pending = deque()
        self.tb_read_cb = {}
        self.pending = deque()             # accepted descriptors awaiting completion
        self.counts = deque()              # per completion record: (bus requests, write acks)
        self.spm_wr_acks = 0
        self.spm_reqs = 0
        self._mon = (0, 0)
        self.snap = (0, 0)
        self.max_outstanding = 0
        self.max_fifo = 0
        self.results = []
        self.codes = {}
        self.dirs = {}
        self.abort_tolerant = set()
        self.reset_tolerant = False
        self.cpl_sb = InOrderScoreboard("dma_cpl_order", self.eng)
        self.eng.hooks_sample.append(self._sample)
        self.eng.hooks_edge.append(self._edge)
        self.has_pc = hasattr(dut, "dma_perf_cnt")
        self.reset_truth()
        if self.has_pc:
            self.eng.hooks_sample.append(self._truth_sample)
        dut.cmd_abort.value = 0

    # ------------------------------------------------------------ monitors
    def _sample(self, cyc):
        if self.eng.in_reset:
            self._mon = (0, 0, 0)
            return
        d = self.dut
        self._mon = (val(d.mon_spm_rsp_fire) & val(d.mon_spm_rsp_we), val(d.mon_spm_req_fire), val(d.ev_cpl))
        self.max_outstanding = max(self.max_outstanding, val(d.ev_outstanding))
        self.max_fifo = max(self.max_fifo, val(d.fifo_level))
        if self._mon[2]:
            # completion record produced at the coming edge: every write must already be acknowledged
            reqs = self.fab.stats["reads"] + self.fab.stats["writes"] + self.spm_reqs
            acks = self.fab.write_ack_count + self.spm_wr_acks
            self.counts.append((reqs - self.snap[0], acks - self.snap[1]))
            self.snap = (reqs, acks)

    # ------------------------------------------------------------ counter truth (bus-observed)
    def reset_truth(self):
        self.t = dict(ev_rd=0, ev_wr=0, spm_rd_ok=0, spm_wr_bytes=0, spm_rd_req=0, spm_wr_req=0, spm_err=0)
        self.spm_wq = [[] for _ in range(self.np)]
        self.fab.truth = dict(rd_ok=0, wr_bytes=0, err_rsp=0, reqs=0, rd_req=0, wr_req=0)
        self.cpl_ok = self.cpl_err = 0

    def _truth_sample(self, cyc):
        if self.eng.in_reset:
            return
        d = self.dut
        self.t["ev_rd"] += val(d.ev_bytes_rd)
        self.t["ev_wr"] += val(d.ev_bytes_wr)
        rf, rwe, rerr = val(d.mon_spm_rsp_fire), val(d.mon_spm_rsp_we), val(d.mon_spm_rsp_err)
        qf, qwe, qs = val(d.mon_spm_req_fire), val(d.mon_spm_req_we), val(d.mon_spm_req_wstrb)
        for p in range(self.np):
            if (qf >> p) & 1:
                if (qwe >> p) & 1:
                    self.t["spm_wr_req"] += 1
                    self.spm_wq[p].append((qs >> (4 * p)) & 0xF)
                else:
                    self.t["spm_rd_req"] += 1
            if (rf >> p) & 1:
                if (rwe >> p) & 1:
                    st = self.spm_wq[p].pop(0) if self.spm_wq[p] else 0
                    if not (rerr >> p) & 1:
                        self.t["spm_wr_bytes"] += bin(st).count("1")
                elif not (rerr >> p) & 1:
                    self.t["spm_rd_ok"] += 1
                if (rerr >> p) & 1:
                    self.t["spm_err"] += 1

    def check_counters(self):
        """Module 05 counters and per-cycle byte events vs what the buses actually carried."""
        if not self.has_pc:
            return {}
        v = val(self.dut.dma_perf_cnt)
        pc = [(v >> (32 * i)) & 0xFFFFFFFF for i in range(16)]
        f = self.fab.truth
        rd = 4 * (f["rd_ok"] + self.t["spm_rd_ok"])
        wr = f["wr_bytes"] + self.t["spm_wr_bytes"]
        want = {"ev_bytes_rd (sum)": (self.t["ev_rd"], rd), "ev_bytes_wr (sum)": (self.t["ev_wr"], wr),
                "BYTES_RD": (pc[2], rd), "BYTES_WR": (pc[3], wr),
                "READS": (pc[4], f["rd_req"] + self.t["spm_rd_req"]),
                "WRITES": (pc[5], f["wr_req"] + self.t["spm_wr_req"]),
                "CPL_OK": (pc[10], self.cpl_ok), "CPL_ERR": (pc[11], self.cpl_err),
                "BUS_ERR": (pc[12], f["err_rsp"] + self.t["spm_err"]),
                "SPM_REQ": (pc[14], self.t["spm_rd_req"] + self.t["spm_wr_req"]),
                "FAB_REQ": (pc[15], f["rd_req"] + f["wr_req"])}
        for k, (got, exp) in want.items():
            if got != exp:
                self.eng.error(f"DMA counter {k} = {got}, buses observed {exp}")
        return {k: v[0] for k, v in want.items()}

    def _edge(self, cyc):
        if self.eng.in_reset or len(self._mon) < 3:
            return
        self.spm_wr_acks += bin(self._mon[0]).count("1")
        self.spm_reqs += bin(self._mon[1]).count("1")

    # ------------------------------------------------------------ descriptors
    def desc(self, src, dst, length, tag):
        self.cmd.send({"src": src & 0xFFFFFFFF, "dst": dst & 0xFFFFFFFF, "len": length & 0xFFFFFFFF, "tag": tag & 0xFF})

    def _acc(self, it, cyc):
        self.pending.append(it)

    def _rd(self, a):
        if DM.in_spm(a, SPM_BASE, self.spm_bytes):
            return self.spm_exp[a - SPM_BASE]
        return self.ext_exp.rb(a)

    def _wr(self, a, v):
        if DM.in_spm(a, SPM_BASE, self.spm_bytes):
            self.spm_exp[a - SPM_BASE] = v
            self.spm_known[a - SPM_BASE] = 1
        else:
            self.ext_exp.wb(a, v)

    def _err_beat(self, base, length):
        """first beat whose word lies in the fabric error window, or None"""
        for k in range(DM.beats(length)):
            a = base + 4 * k
            if not DM.in_spm(a, SPM_BASE, self.spm_bytes) and ERR_BASE <= a < ERR_BASE + ERR_BYTES:
                return k
        return None

    def _cpl(self, it, cyc):
        if not self.pending:
            self.eng.error(f"completion without an accepted descriptor: {it}")
            return
        d = self.pending.popleft()
        reqs, acks = self.counts.popleft() if self.counts else (None, None)
        code, eaddr = DM.validate(d["src"], d["dst"], d["len"], max_len_log2=16, spm_base=SPM_BASE,
                                  spm_bytes=self.spm_bytes)
        nb, wbytes = DM.beats(d["len"]), d["len"]
        if code == DM.NONE:
            kr, kw = self._err_beat(d["src"], d["len"]), self._err_beat(d["dst"], d["len"])
            if kr is not None:
                code, eaddr, nb = DM.READ_BUS, d["src"] + 4 * kr, kr
            elif kw is not None:
                code, eaddr, nb = DM.WRITE_BUS, d["dst"] + 4 * kw, kw
            wbytes = min(d["len"], 4 * nb)
        tol = d["tag"] in self.abort_tolerant or self.reset_tolerant
        got = (it["tag"], it["code"], it["err"], it["addr"], it["bytes"])
        if tol and it["code"] == DM.ABORTED and code == DM.NONE:
            # aborted: an acknowledged contiguous prefix of whole beats
            nb, wbytes, code, eaddr = it["bytes"] // 4, it["bytes"], DM.ABORTED, it["addr"]
            if it["bytes"] % 4 or it["bytes"] >= d["len"]:
                self.eng.error(f"ABORTED with a non-prefix byte count {it['bytes']} of {d['len']}")
        exp = (d["tag"], code, int(code != 0), eaddr, wbytes if code in (0, 8, 9, 10) else 0)
        self.codes[DM.NAMES[code]] = self.codes.get(DM.NAMES[code], 0) + 1
        if it["code"] == 0:
            self.cpl_ok += 1
        else:
            self.cpl_err += 1
        if got != exp:
            self.eng.error(f"completion mismatch for {d}: expected tag/code/err/err_addr/bytes={exp}, got {got}")
        if code in (0, 8, 9, 10):
            DM.copy(self._rd, self._wr, d["src"], d["dst"], d["len"], upto_beats=nb)
        if acks is not None:
            want = DM.beats(wbytes) if code in (0, 8, 9, 10) else 0
            if acks != want:
                self.eng.error(f"descriptor {d['tag']} ({DM.NAMES[code]}): {acks} error-free write acknowledgement(s) "
                               f"before its completion record, {want} expected (completion must follow every "
                               f"write acknowledgement, and a failed / rejected transfer writes nothing more)")
        if reqs is not None and code not in (0, 8, 9, 10) and reqs:
            self.eng.error(f"rejected descriptor {d} (code {DM.NAMES[code]}) made {reqs} bus request(s)")
        # external destination: the performed writes must already be in memory now
        if code in (0, 8, 9, 10) and not DM.in_spm(d["dst"], SPM_BASE, self.spm_bytes):
            for off in range(0, min(d["len"] + 4, 4 * (nb + 1))):
                a = d["dst"] + off
                if ERR_BASE <= a < ERR_BASE + ERR_BYTES:
                    continue
                if self.ext.rb(a) != self.ext_exp.rb(a):
                    self.eng.error(f"descriptor {d['tag']}: external byte {a:#x} = {self.ext.rb(a):#x}, expected "
                                   f"{self.ext_exp.rb(a):#x} at completion time")
                    break
        k = ("spm" if DM.in_spm(d["src"], SPM_BASE, self.spm_bytes) else "ext") + "->" + \
            ("spm" if DM.in_spm(d["dst"], SPM_BASE, self.spm_bytes) else "ext")
        self.dirs[k] = self.dirs.get(k, 0) + 1
        self.results.append((d, it))

    # ------------------------------------------------------------ scratchpad front door
    def _tb_acc(self, it, cyc):
        self.tb_pending.append(it)

    def _tb_rsp(self, it, cyc):
        if not self.tb_pending:
            self.eng.error("unsolicited TB-port scratchpad response")
            return
        rq = self.tb_pending.popleft()
        if it["err"] or it["tag"] != rq["tag"] or it["we"] != rq["we"]:
            self.eng.error(f"TB-port scratchpad response {it} for {rq}")
        if not rq["we"]:
            off = rq["addr"] - SPM_BASE
            bs = it["rdata"].rjust(32, "0")
            for i in range(4):
                if not self.spm_known[off + i]:
                    continue                      # never-written byte: any value (X in 4-state simulation)
                byte = bs[32 - 8 * (i + 1): 32 - 8 * i]
                if any(ch not in "01" for ch in byte) or int(byte, 2) != self.spm_exp[off + i]:
                    self.eng.error(f"scratchpad byte {rq['addr'] + i:#x} = {byte}, expected {self.spm_exp[off + i]:#04x}")
                    break

    def spm_write(self, off, word):
        self.tbsrc.send({"we": 1, "addr": SPM_BASE + off, "wdata": word, "wstrb": 0xF, "tag": len(self.tb_pending) & 0xFF})
        for i in range(4):
            self.spm_exp[off + i] = (word >> (8 * i)) & 0xFF
            self.spm_known[off + i] = 1

    def spm_read(self, off, tag=0):
        self.tbsrc.send({"we": 0, "addr": SPM_BASE + off, "wdata": 0, "wstrb": 0, "tag": tag & 0xFF})

    def spm_fill(self, r, off, nbytes):
        for o in range(off, off + nbytes, 4):
            self.spm_write(o, r.getrandbits(32))

    def spm_check(self, off, nbytes):
        for o in range(off & ~3, off + nbytes, 4):
            if o < self.spm_bytes:
                self.spm_read(o)

    # ------------------------------------------------------------ helpers
    def idle(self):
        return (self.cmd.idle() and not self.pending and self.cpl.pending is None and self.fab.idle() and
                self.tbsrc.idle() and not self.tb_pending)

    async def drain(self, limit=400000):
        for _ in range(limit):
            await RisingEdge(self.dut.clk)
            if self.idle() and not val(self.dut.busy):
                break
        await ClockCycles(self.dut.clk, 6)
        if not self.idle():
            self.eng.error(f"DMA not drained: {len(self.pending)} descriptor(s) without completion")

    def check_ext_full(self):
        bad = 0
        for a in range(EXT_BASE, EXT_BASE + EXT_BYTES):
            if self.ext.rb(a) != self.ext_exp.rb(a):
                bad += 1
                if bad <= 3:
                    self.eng.error(f"final external byte {a:#x}: {self.ext.rb(a):#x} expected {self.ext_exp.rb(a):#x}")
        return bad


async def setup(dut, env):
    start_clock(dut)
    dut.rst_n.value = 0
    env.eng.start()
    env.eng.in_reset = True
    await ClockCycles(dut.clk, 3)
    await FallingEdge(dut.clk)
    dut.rst_n.value = 1
    env.eng.in_reset = False
    await ClockCycles(dut.clk, 2)


def stalls_from_env():
    return dict(fab_stall=env_str("HPC_FAB_STALL", "random:0.7"), cpl_stall=env_str("HPC_CPL_STALL", "random:0.7"),
                cmd_stall=env_str("HPC_CMD_STALL", "random:0.8"),
                fab_lat=(1, env_int("HPC_FAB_LAT", 6)))
