"""Reusable cocotb environment for hpc_vector_array (tb_varray_top).

Agents: cmd + opnd sources, res + cpl sinks (stall patterns), per-lane hold
driver.  Scoreboards: result beats in order, completions in order, plus the
ordering rule "completion k only after the last result beat of command k".
Expected values come from reference_models/varray_model.py (SoftFloat-3e).
"""
from __future__ import annotations

from collections import deque

from cocotb.triggers import ClockCycles, FallingEdge, RisingEdge

from reference_models import fp32_softfloat as SF
from reference_models import varray_model as VM

from . import fpgen
from .cycle import Engine, Sink, Source, val
from .scoreboard import InOrderScoreboard
from .stall import Stall
from .tbutil import env_int, env_str, seed, start_clock

CHK = ["chk_cmd_err", "chk_opnd_err", "chk_res_err", "chk_cpl_err", "cons_err"]
GARBAGE = [0x7FC00000, 0xFFC00001, 0x7FA00001, 0xFF800001, 0x7F800001]


def cfg():
    return dict(N=env_int("NUM_LANES", 2), CMD_DEPTH=env_int("CMD_DEPTH", 4), TRK_DEPTH=env_int("TRK_DEPTH", 8),
                CPL_DEPTH=env_int("CPL_DEPTH", 4), RED_EN=env_int("RED_EN", 1), EN_FCMP=env_int("EN_FCMP", 1),
                EN_INT=env_int("EN_INT", 1), VL_W=env_int("VL_W", 16),
                LANE_ROB_DEPTH=env_int("LANE_ROB_DEPTH", 8), LAT_FMA=env_int("LAT_FMA", 4),
                RED_LAT=env_int("RED_LAT", 3))


def gen_cmd(r, n, tid, *, max_vl=40, red_p=0.15, vm_p=0.3, bcast_p=0.15, illegal_p=0.05, ops=None, vl=None,
            red=None):
    if ops is None:
        x = r.random()
        if x < 0.55:
            op = r.choice([SF.FADD, SF.FMUL, SF.FMADD])
        elif x < 1 - illegal_p:
            op = r.choice(SF.LEGAL_OPS)
        else:
            op = r.choice([0x0D, 0x0E, 0x12, 0x1F])
    else:
        op = r.choice(ops)
    rm = r.randrange(5) if r.random() > 0.03 else r.randrange(5, 8)
    if vl is None:
        vl = r.choice([0, 1, n - 1 if n > 1 else 1, n, n + 1, 2 * n, 3 * n + 1, r.randint(1, max_vl),
                       r.randint(1, max_vl)])
    if red is None:
        red = 1 if r.random() < red_p else 0
    if red and ops is None and r.random() < 0.85:
        op = r.choice([SF.FMV, SF.FMUL, SF.FMUL, SF.FMADD, SF.FADD])
    vm = 1 if r.random() < vm_p else 0
    bcast = r.randrange(1, 8) if (r.random() < bcast_p and not (red and r.random() < 0.9)) else 0
    nb = VM.beats(vl, n)
    tot = max(nb * n, 1)
    mask = [1 if r.random() < 0.7 else 0 for _ in range(tot)]
    a, b, c = [], [], []
    for e in range(tot):
        act = e < vl and (not vm or mask[e])
        a.append(fpgen.operand(r) if act else r.choice(GARBAGE))
        b.append(fpgen.operand(r) if act else r.choice(GARBAGE))
        c.append(fpgen.operand(r) if act else r.choice(GARBAGE))
    if red and op == SF.FMUL and r.random() < 0.5:          # well-scaled dot products as well
        for e in range(tot):
            a[e] = (r.getrandbits(1) << 31) | (r.randint(110, 140) << 23) | r.getrandbits(23)
            b[e] = (r.getrandbits(1) << 31) | (r.randint(110, 140) << 23) | r.getrandbits(23)
    return {"op": op, "rm": rm, "vl": vl, "vm": vm, "bcast": bcast, "scalar": fpgen.operand(r) if not red else
            (0 if r.random() < 0.5 else fpgen.operand(r)), "red": red, "tid": tid, "a": a, "b": b, "c": c,
            "mask": mask}


class VArrayEnv:
    def __init__(self, dut, *, cmd_stall="none", opnd_stall="none", res_stall="none", cpl_stall="none",
                 hold="none"):
        self.dut = dut
        self.C = cfg()
        n = self.C["N"]
        self.n = n
        self.eng = Engine(dut)
        s = seed()
        fmt_res = lambda x: f"tid={x[0]} beat={x[1]} last={x[2]} data={[hex(v) for v in x[3]]} fl={x[4]} m={x[5]}"
        self.res_sb = InOrderScoreboard("res", self.eng, fmt=fmt_res)
        self.cpl_sb = InOrderScoreboard("cpl", self.eng, fmt=lambda x: "tid=%d flags=%02x ill=%d count=%d red=%d "
                                                                      "result=%08x" % x)
        self.cmd = self.eng.add(Source(dut, "cmd_valid", "cmd_ready",
                                       {k: f"cmd_{k}" for k in ("op", "rm", "vl", "vm", "bcast", "scalar", "red", "tid")},
                                       stall=Stall(cmd_stall, s), on_accept=self._cmd_acc, name="cmd"))
        self.opnd = self.eng.add(Source(dut, "opnd_valid", "opnd_ready",
                                        {"a": "opnd_a", "b": "opnd_b", "c": "opnd_c", "mask": "opnd_mask"},
                                        stall=Stall(opnd_stall, s + 1), on_accept=self._opnd_acc, name="opnd"))
        self.res = self.eng.add(Sink(dut, "res_valid", "res_ready",
                                     {k: f"res_{k}" for k in ("data", "flags", "mask", "tid", "beat", "last")},
                                     stall=Stall(res_stall, s + 2), on_item=self._res, name="res"))
        self.cpl = self.eng.add(Sink(dut, "cpl_valid", "cpl_ready",
                                     {k: f"cpl_{k}" for k in ("tid", "flags", "illegal", "count", "red", "result")},
                                     stall=Stall(cpl_stall, s + 3), on_item=self._cpl, name="cpl"))
        self.hold = Stall(hold, s + 4) if hold != "none" else None
        self.hold_lane = [Stall(hold, s + 10 + i) for i in range(n)] if hold != "none" else None
        self.beats_left: deque = deque()     # per accepted command: result beats still to come
        self.cmd_accepted = 0
        self.cmd_cycle = {}
        self.cpl_cycle = []
        self.first_opnd = None
        self.last_res = None
        self.cov = {"ops": {}, "red": 0, "illegal": 0, "vl0": 0, "masked": 0, "bcast": 0}
        self.pending_exp: deque = deque()
        self.eng.hooks_edge.append(self._drive_hold)
        self.eng.hooks_sample.append(self._check_hold)
        self.hold_prev = 0          # value on lane_hold_i during the cycle that just ended (= the array's hold_q)
        self.hold_cur = 0
        self.hold_checks = 0
        try:
            self._ln_valid = dut.dut.ln_valid          # array -> lane issue valids (ARRAY_INTERFACE §12 contract)
        except AttributeError:
            self._ln_valid = None
        dut.lane_hold.value = 0

    # ------------------------------------------------------------ stimulus
    def send(self, cmd):
        """queue a command and its operand beats; expectations are registered at command acceptance."""
        rb, cp = VM.expect(cmd, self.n, red_en=bool(self.C["RED_EN"]), en_fcmp=bool(self.C["EN_FCMP"]),
                           en_int=bool(self.C["EN_INT"]))
        self.pending_exp.append((rb, cp, cmd))
        self.cmd.send({k: cmd[k] for k in ("op", "rm", "vl", "vm", "bcast", "scalar", "red", "tid")})
        for bt in VM.operand_beats(cmd, self.n):
            self.opnd.send(bt)

    def _cmd_acc(self, it, cyc):
        rb, cp, cmd = self.pending_exp.popleft()
        for b in rb:
            self.res_sb.expect(b)
        self.cpl_sb.expect(cp)
        self.beats_left.append(len(rb))
        self.cmd_accepted += 1
        k = "illegal" if cp[2] else SF.OP_NAMES.get(cmd["op"], "?") + ("/red" if cmd["red"] else "")
        self.cov["ops"][k] = self.cov["ops"].get(k, 0) + 1
        self.cov["red"] += cmd["red"]
        self.cov["illegal"] += cp[2]
        self.cov["vl0"] += cmd["vl"] == 0
        self.cov["masked"] += cmd["vm"]
        self.cov["bcast"] += cmd["bcast"] != 0

    def _opnd_acc(self, it, cyc):
        if self.first_opnd is None:
            self.first_opnd = cyc

    def _split(self, v, w):
        return tuple((v >> (w * i)) & ((1 << w) - 1) for i in range(self.n))

    def _res(self, it, cyc):
        self.last_res = cyc
        item = (it["tid"], it["beat"], it["last"], self._split(it["data"], 32), self._split(it["flags"], 5),
                tuple((it["mask"] >> i) & 1 for i in range(self.n)))
        self.res_sb.got(item)
        # attribute to the oldest command still owing beats
        for i in range(len(self.beats_left)):
            if self.beats_left[i] > 0:
                self.beats_left[i] -= 1
                break

    def _cpl(self, it, cyc):
        self.cpl_cycle.append(cyc)
        self.cpl_sb.got((it["tid"], it["flags"], it["illegal"], it["count"], it["red"], it["result"]))
        if self.beats_left:
            left = self.beats_left.popleft()
            if left:
                self.eng.error(f"completion tid={it['tid']} handed over before its last result beat "
                               f"({left} beat(s) outstanding): ordering rule 2 violated")

    def _drive_hold(self, cyc):
        self.hold_prev = self.hold_cur
        if self.hold_lane is None or self.eng.in_reset:
            self.hold_cur = 0 if self.hold_lane is None else self.hold_cur
            return
        v = 0
        for i, s in enumerate(self.hold_lane):
            if not s():
                v |= 1 << i
        self.dut.lane_hold.value = v
        self.hold_cur = v

    def _check_hold(self, cyc):
        """ARRAY_INTERFACE §12: while the registered hold bit of lane l is set, lane l is offered no new element"""
        if self._ln_valid is None or self.eng.in_reset:
            return
        lv = val(self._ln_valid)
        if lv < 0:
            return
        self.hold_checks += 1
        if lv & self.hold_prev:
            self.eng.error(f"element offered to held lane(s) {lv & self.hold_prev:#x} (lane_hold contract)")

    # ------------------------------------------------------------ helpers
    def idle(self):
        return (self.cmd.idle() and self.opnd.idle() and self.res_sb.outstanding() == 0 and
                self.cpl_sb.outstanding() == 0 and self.res.pending is None and self.cpl.pending is None)

    async def drain(self, limit=200000):
        for _ in range(limit):
            await RisingEdge(self.dut.clk)
            if self.idle():
                break
        self.dut.lane_hold.value = 0
        self.hold_lane = None
        self.hold_cur = 0
        await ClockCycles(self.dut.clk, 8)
        if val(self.dut.busy):
            self.eng.error("busy_o still high after every completion was handed over")

    def flush_for_reset(self):
        n = self.res_sb.flush() + self.cpl_sb.flush()
        self.beats_left.clear()
        self.pending_exp.clear()
        return n


async def setup(dut, env):
    start_clock(dut)
    dut.rst_n.value = 0
    for s in ("cmd_valid", "opnd_valid", "res_ready", "cpl_ready"):
        getattr(dut, s).value = 0
    env.eng.start()
    env.eng.in_reset = True
    await ClockCycles(dut.clk, 3)
    await FallingEdge(dut.clk)
    dut.rst_n.value = 1
    env.eng.in_reset = False


def stalls_from_env():
    return dict(cmd_stall=env_str("HPC_CMD_STALL", "random:0.6"), opnd_stall=env_str("HPC_OPND_STALL", "random:0.7"),
                res_stall=env_str("HPC_RES_STALL", "random:0.6"), cpl_stall=env_str("HPC_CPL_STALL", "random:0.5"),
                hold=env_str("HPC_HOLD", "random:0.9"))
