"""Build and run cocotb testbenches (cocotb 1.9 runner) and record results.

* builds are content-addressed (sources, parameters, defines, simulator, flags);
* every cocotb testcase becomes one result record (PASS/FAIL), with seed,
  configuration, metrics published by the test, log path and an exact
  reproduction command;
* a failing testcase is re-run once with waveforms (Verilator VCD / Icarus FST)
  and the dump path is recorded;
* Verilator line coverage (``coverage.dat``) is collected per run when
  HPC_COVERAGE=1 (default) and merged by regression/coverage.py.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from . import results as R

HPC = Path(__file__).resolve().parents[2]
BUILD = Path(os.environ.get("HPC_BUILD", HPC / "build")).resolve()


def _digest(parts) -> str:
    h = hashlib.sha256()
    for p in parts:
        p2 = Path(p) if isinstance(p, (str, Path)) and os.path.sep in str(p) else None
        if p2 is not None and p2.is_file():
            h.update(p2.name.encode())
            h.update(p2.read_bytes())
        else:
            h.update(repr(p).encode())
    return h.hexdigest()[:16]


def coverage_enabled(sim: str) -> bool:
    return sim == "verilator" and os.environ.get("HPC_COVERAGE", "1") == "1"


def build(name, toplevel, sources, *, parameters=None, defines=None, includes=None, sim="verilator",
          waves=False, coverage=None):
    import warnings
    warnings.filterwarnings("ignore", message="Python runners")
    from cocotb.runner import get_runner
    parameters = parameters or {}
    defines = defines or {}
    includes = includes or []
    coverage = coverage_enabled(sim) if coverage is None else coverage
    if sim == "verilator":
        bargs = ["-Wno-fatal", "-Wno-lint", "-Wno-style", "--assert", "-Wno-TIMESCALEMOD",
                 "--x-assign", "unique", "--x-initial", "unique", "-O3", "-j", str(os.cpu_count() or 2)]
        if coverage:
            bargs += ["--coverage-line", "--coverage-user"]
    else:
        bargs = ["-g2012"]
    key = _digest([str(s) for s in sources] + [toplevel, sorted(parameters.items()), sorted(defines.items()),
                                              [str(i) for i in includes], sim, waves, coverage, bargs])
    bdir = BUILD / "cocotb" / f"{name}-{sim}{'-w' if waves else ''}-{key}"
    runner = get_runner(sim)
    bdir.mkdir(parents=True, exist_ok=True)
    if True:   # cocotb's build() is incremental (always=False) and must run to initialise the runner
        runner.build(verilog_sources=[str(s) for s in sources], hdl_toplevel=toplevel, includes=[str(i) for i in includes],
                     defines=defines, parameters=parameters, build_args=bargs, build_dir=str(bdir), waves=waves,
                     timescale=("1ns", "1ps"), log_file=str(bdir / "build.log"))
    return runner, bdir


def run_suite(suite, cfg_name, *, toplevel, sources, test_module, test_dir, testcases, parameters=None,
              defines=None, includes=None, sim="verilator", seed=1, env=None, config=None, timeout=3600,
              repro_hint=None):
    """Run ``testcases`` (list of names) of ``test_module``; one record per testcase."""
    env = dict(env or {})
    try:
        runner, bdir = build(f"{suite}_{cfg_name}", toplevel, sources, parameters=parameters, defines=defines,
                             includes=includes, sim=sim)
    except BaseException as ex:  # noqa: BLE001  a build failure fails every testcase of the configuration
        logs = sorted((BUILD / "cocotb").glob(f"{suite}_{cfg_name}-{sim}-*/build.log"))
        for tc in testcases:
            R.record(suite, f"{cfg_name}/{sim}/{tc}/s{seed}", "FAIL", seed=seed,
                     config={"config": cfg_name, "simulator": sim, **(parameters or {})},
                     reason=f"build failed: {ex!r}", log=logs[-1] if logs else None, simulator=sim,
                     repro=(repro_hint or "").format(tc=tc, seed=seed, cfg=cfg_name, sim=sim))
            print(f"  [FAIL] {suite}/{cfg_name}/{sim}/{tc}/s{seed}  build failed: {ex!r}"[:300], flush=True)
        return ["FAIL"] * len(testcases)
    out = []
    for tc in testcases:
        rdir = BUILD / "runs" / suite / cfg_name / sim / f"{tc}_s{seed}"
        if rdir.exists():
            shutil.rmtree(rdir)
        rdir.mkdir(parents=True)
        mfile = rdir / "metrics.json"
        e = {"HPC_METRICS": str(mfile), "HPC_SEED": str(seed), "HPC_CFG": cfg_name,
             "PYTHONPATH": os.pathsep.join([str(test_dir), str(HPC / "lib"), str(HPC)] +
                                           os.environ.get("PYTHONPATH", "").split(os.pathsep)),
             **{k: str(v) for k, v in env.items()}}
        plus = []          # Verilator 5.020 writes coverage.dat into the run directory (test_dir)
        t0 = time.time()
        xml = rdir / "results.xml"
        status, msg = "FAIL", ""
        try:
            runner.test(test_module=test_module, hdl_toplevel=toplevel, testcase=tc, seed=seed, extra_env=e,
                        plusargs=plus, build_dir=str(bdir), test_dir=str(rdir), results_xml=str(xml),
                        log_file=str(rdir / "sim.log"))
            status, msg = _parse(xml, tc)
        except BaseException as ex:  # noqa: BLE001  simulator crash / SystemExit
            msg = f"runner exception: {ex!r}"
        dt = time.time() - t0
        metrics = json.loads(mfile.read_text()) if mfile.exists() else {}
        waves = None
        if status != "PASS" and os.environ.get("HPC_WAVES_ON_FAIL", "1") == "1":
            waves = _rerun_with_waves(suite, cfg_name, toplevel, sources, test_module, tc, seed, e, parameters,
                                      defines, includes, sim, rdir)
        repro = (repro_hint or "").format(tc=tc, seed=seed, cfg=cfg_name, sim=sim)
        R.record(suite, f"{cfg_name}/{sim}/{tc}/s{seed}", status, seed=seed,
                 config={"config": cfg_name, "simulator": sim, **(config or {}), **(parameters or {})},
                 duration=dt, metrics=metrics, log=rdir / "sim.log", waves=waves, repro=repro,
                 reason=msg if status != "PASS" else None, simulator=sim)
        print(f"  [{status}] {suite}/{cfg_name}/{sim}/{tc}/s{seed} ({dt:.1f}s){'  ' + msg[:200] if msg else ''}",
              flush=True)
        out.append(status)
    return out


def _parse(xml: Path, tc: str):
    if not xml.exists():
        return "FAIL", "no results.xml (simulator crashed?)"
    root = ET.parse(xml).getroot()
    found = False
    for case in root.iter("testcase"):
        if case.get("name") != tc:
            continue
        found = True
        f = case.find("failure")
        if f is None:
            f = case.find("error")
        if f is not None:
            return "FAIL", (f.get("message") or "failure")[:500]
    return ("PASS", "") if found else ("FAIL", f"testcase {tc} not found in results")


def _rerun_with_waves(suite, cfg_name, toplevel, sources, test_module, tc, seed, env, parameters, defines,
                      includes, sim, rdir):
    try:
        runner, bdir = build(f"{suite}_{cfg_name}", toplevel, sources, parameters=parameters, defines=defines,
                             includes=includes, sim=sim, waves=True, coverage=False)
        wdir = rdir / "waves"
        wdir.mkdir(exist_ok=True)
        e = dict(env)
        e["HPC_METRICS"] = str(wdir / "metrics.json")
        runner.test(test_module=test_module, hdl_toplevel=toplevel, testcase=tc, seed=seed, extra_env=e,
                    build_dir=str(bdir), test_dir=str(wdir), results_xml=str(wdir / "results.xml"), waves=True,
                    log_file=str(wdir / "sim.log"))
        dumps = sorted(list(wdir.glob("*.vcd")) + list(wdir.glob("*.fst")) + list(bdir.glob("*.fst")))
        return str(dumps[0]) if dumps else "waveform run produced no dump"
    except BaseException as ex:  # noqa: BLE001
        return f"waveform re-run failed: {ex!r}"
