"""Uniform test-result records for every suite of the framework.

Each executed (or blocked) test case becomes one JSON record in
``build/results/<suite>/<name>.json``.  The regression runner and the report
generator read only these records, so every number in the verification report
is traceable to a record written by an actual run.

Status values:
  PASS     the test ran and every check passed
  FAIL     the test ran and at least one check failed (or the run crashed)
  BLOCKED  the test cannot run: the RTL feature it verifies does not exist
           (reason recorded); never counted as passed
  SKIP     deliberately not run in this matrix (e.g. nightly-only)
"""
from __future__ import annotations

import json
import os
import platform
import re
import shlex
import time
from pathlib import Path

HPC = Path(__file__).resolve().parents[2]
BUILD = Path(os.environ.get("HPC_BUILD", HPC / "build")).resolve()
RESULTS = BUILD / "results"


def _safe(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.+=-]+", "_", s)[:150]


def record(suite: str, name: str, status: str, *, seed=None, config=None, duration=None, metrics=None,
           log=None, waves=None, repro=None, reason=None, checks=None, simulator=None) -> dict:
    assert status in ("PASS", "FAIL", "BLOCKED", "SKIP"), status
    rec = {"suite": suite, "name": name, "status": status, "seed": seed, "config": config or {},
           "duration_s": round(duration, 3) if duration is not None else None, "metrics": metrics or {},
           "checks": checks, "log": str(log) if log else None, "waves": str(waves) if waves else None,
           "repro": repro, "reason": reason, "simulator": simulator, "host": platform.node(),
           "time": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    d = RESULTS / _safe(suite)
    d.mkdir(parents=True, exist_ok=True)
    (d / (_safe(name) + ".json")).write_text(json.dumps(rec, indent=1) + "\n")
    return rec


def blocked(suite: str, name: str, reason: str, plan: str | None = None) -> dict:
    return record(suite, name, "BLOCKED", reason=reason, metrics={"plan": plan} if plan else None)


def repro_cmd(argv: list[str], env: dict | None = None, cwd: str | Path | None = None) -> str:
    pre = f"cd {shlex.quote(str(cwd))} && " if cwd else ""
    e = " ".join(f"{k}={shlex.quote(str(v))}" for k, v in (env or {}).items())
    return pre + (e + " " if e else "") + " ".join(shlex.quote(str(a)) for a in argv)


def load_all(root: Path | None = None) -> list[dict]:
    root = root or RESULTS
    out = []
    for p in sorted(root.rglob("*.json")):
        try:
            out.append(json.loads(p.read_text()))
        except json.JSONDecodeError:
            out.append({"suite": p.parent.name, "name": p.stem, "status": "FAIL", "reason": "corrupt record"})
    return out


class Timer:
    def __enter__(self):
        self.t0 = time.time()
        return self

    def __exit__(self, *a):
        self.dt = time.time() - self.t0
