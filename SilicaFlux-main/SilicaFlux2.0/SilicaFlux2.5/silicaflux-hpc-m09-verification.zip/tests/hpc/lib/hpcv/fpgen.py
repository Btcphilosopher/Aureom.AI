"""FP32 stimulus: corner-biased random operands and named directed categories.

Every generator is deterministic for a given seed (``random.Random``).  The
directed categories are the ones the verification plan requires (brief §3):
exact results, FMA single rounding, NaNs, infinities, signed zeros, subnormals,
overflow, underflow, rounding (ties, halfway, sticky) and exception flags.
"""
from __future__ import annotations

import random

SIGN = 0x80000000
SPECIALS = [0x00000000, 0x80000000, 0x3F800000, 0xBF800000, 0x7F800000, 0xFF800000, 0x7FC00000, 0xFFC00000,
            0x7FC00001, 0x7FA00000, 0xFF800001, 0x7F800001, 0x7FBFFFFF, 0x7F7FFFFF, 0xFF7FFFFF, 0x00800000,
            0x80800000, 0x007FFFFF, 0x807FFFFF, 0x00000001, 0x80000001, 0x00400000, 0x3F7FFFFF, 0x3F800001,
            0x7F000000, 0x01000000, 0x00800001, 0x7EFFFFFF, 0x33800000, 0x34000000, 0x4B000000, 0x4B800000]
EXPS = [1, 2, 3, 23, 24, 25, 26, 100, 126, 127, 128, 150, 228, 252, 253, 254]

QNAN_POS, QNAN_NEG, SNAN_POS, SNAN_NEG = 0x7FC00000, 0xFFC00000, 0x7FA00000, 0xFF800001
PINF, NINF, PZERO, NZERO = 0x7F800000, 0xFF800000, 0x00000000, 0x80000000
MAXF, MINN, MAXSUB, MINSUB = 0x7F7FFFFF, 0x00800000, 0x007FFFFF, 0x00000001
ONE, TWO, HALF = 0x3F800000, 0x40000000, 0x3F000000


def operand(r: random.Random) -> int:
    p = r.random()
    s = SIGN if r.random() < 0.5 else 0
    if p < 0.10:
        return r.choice(SPECIALS)
    if p < 0.22:
        return s | r.randrange(1, 1 << 23)                                  # subnormal
    if p < 0.40:
        return s | (r.choice(EXPS) << 23) | r.getrandbits(23)               # boundary exponents
    if p < 0.52:                                                            # long 0/1 runs in the fraction
        k = r.randrange(24)
        frac = ((1 << k) - 1) if r.random() < 0.5 else (((1 << 23) - 1) ^ ((1 << k) - 1))
        return s | (r.randrange(1, 255) << 23) | (frac & 0x7FFFFF)
    if p < 0.60:                                                            # NaN payloads
        return s | 0x7F800000 | r.randrange(1, 1 << 23)
    return r.getrandbits(32)


def related_triple(r: random.Random):
    """operands chosen so that a*b and c nearly cancel or straddle rounding boundaries."""
    a, b = operand(r), operand(r)
    ea, eb = (a >> 23) & 0xFF, (b >> 23) & 0xFF
    if 0 < ea < 255 and 0 < eb < 255:
        e = ea + eb - 127 + r.choice([-25, -24, -1, 0, 1, 24])
        if 1 <= e <= 254:
            c = (SIGN if r.random() < 0.5 else 0) | (e << 23) | r.getrandbits(23)
            return a, b, c
    return a, b, operand(r)


def random_vectors(n: int, seed: int, ops, rms=(0, 1, 2, 3, 4)):
    r = random.Random(seed)
    out = []
    for i in range(n):
        op = ops[i % len(ops)]
        if op in (4, 5, 6, 7) and r.random() < 0.4:
            a, b, c = related_triple(r)
        else:
            a, b, c = operand(r), operand(r), operand(r)
        out.append((op, rms[(i // len(ops)) % len(rms)], a, b, c, "random"))
    return out


# ----------------------------------------------------------------- directed categories
def directed() -> list[tuple]:
    """(op, rm, a, b, c, category) tuples; expectations come from the oracles."""
    V = []
    add = lambda op, a, b=0, c=0, cat="", rms=(0, 1, 2, 3, 4): V.extend((op, rm, a, b, c, cat) for rm in rms)
    # exact results (no flags at all)
    add(1, ONE, ONE, cat="exact")                     # 1 + 1 = 2
    add(3, 0x40400000, 0x40800000, cat="exact")      # 3 * 4 = 12
    add(4, TWO, 0x40400000, ONE, cat="exact")        # 2*3+1 = 7
    add(1, MINSUB, MINSUB, cat="exact")              # subnormal + subnormal exact
    add(3, MAXSUB, ONE, cat="exact")
    add(2, 0x4B000001, 0x4B000000, cat="exact")      # 2^23+1 - 2^23
    # FMA single rounding: results that differ from the double-rounded (mul then add) value
    for a, b, c in [(0x3F800001, 0x3F800001, 0xBF800002), (0x3F800001, 0x3F800001, 0xBF800000),
                    (0x3FFFFFFF, 0x3FFFFFFF, 0xC0800000), (0x3DCCCCCD, 0x41200000, 0xBF800000),
                    (0x4B7FFFFF, 0x3F000001, 0xCAFFFFFF), (0x3F7FFFFF, 0x3F7FFFFF, 0xBF7FFFFE)]:
        for op in (4, 5, 6, 7):
            add(op, a, b, c, cat="fma_single_rounding")
    # near-cancellation: c = -/+ round(a*b) + d.  The double-rounded result (FMUL then FADD) is a
    # small multiple of an ulp of the product, the fused result is the exact residual: they differ
    # in every rounding mode (fp32_crosscheck.py proves it for every op/mode pair).
    for a, b, p in [(0xBFA9735A, 0x3FF953A6, 0xC0250891), (0x3FB9E792, 0x3FEED0A4, 0x402D6CCD),
                    (0xBFC7A69F, 0x3FEDADAF, 0xC0395CB5), (0x05764C88, 0x3FE3FEF4, 0x05DB5B27)]:
        for d in (-1, 0, 1):
            add(4, a, b, (p ^ SIGN) + d, cat="fma_single_rounding")      # a*b + c
            add(5, a, b, p + d, cat="fma_single_rounding")               # a*b - c
            add(6, a, b, p + d, cat="fma_single_rounding")               # -(a*b) + c
            add(7, a, b, (p ^ SIGN) + d, cat="fma_single_rounding")      # -(a*b) - c
    # NaNs: quiet / signalling, payload, sign; every rounding op
    nans = [QNAN_POS, QNAN_NEG, SNAN_POS, SNAN_NEG, 0x7FC12345, 0x7F800001, 0xFFFFFFFF]
    for n in nans:
        for op in (1, 2, 3):
            add(op, n, ONE, cat="nan", rms=(0,))
            add(op, ONE, n, cat="nan", rms=(0,))
        for op in (4, 5, 6, 7):
            add(op, n, ONE, ONE, cat="nan", rms=(0,))
            add(op, ONE, ONE, n, cat="nan", rms=(0,))
        for op in (8, 9, 10, 11, 12):
            add(op, n, ONE, cat="nan", rms=(0,))
            add(op, n, n, cat="nan", rms=(0,))
        add(0, n, cat="nan", rms=(0,))                 # FMV keeps payload
    add(4, PINF, PZERO, QNAN_POS, cat="nan_inf_times_zero")   # NV even with quiet-NaN addend
    add(4, PZERO, NINF, SNAN_POS, cat="nan_inf_times_zero")
    add(3, PINF, PZERO, cat="nan_inf_times_zero")
    # infinities
    for x in (PINF, NINF):
        for y in (PINF, NINF, ONE, MAXF, PZERO):
            add(1, x, y, cat="inf", rms=(0, 2))
            add(2, x, y, cat="inf", rms=(0, 2))
            add(3, x, y, cat="inf", rms=(0, 2))
        add(4, ONE, x, NINF, cat="inf")
        add(4, ONE, x, PINF, cat="inf")
        add(4, MAXF, MAXF, x, cat="inf")
    # signed zeros
    for x in (PZERO, NZERO):
        for y in (PZERO, NZERO):
            add(1, x, y, cat="signed_zero")
            add(2, x, y, cat="signed_zero")
            add(3, x, y, cat="signed_zero")
            add(4, x, ONE, y, cat="signed_zero")
            add(4, ONE, x, y, cat="signed_zero")
            add(8, x, y, cat="signed_zero", rms=(0,))
            add(9, x, y, cat="signed_zero", rms=(0,))
            add(10, x, y, cat="signed_zero", rms=(0,))
    add(1, ONE, 0xBF800000, cat="signed_zero")        # exact cancellation: +0, RDN -0
    add(4, ONE, ONE, 0xBF800000, cat="signed_zero")
    add(3, MINSUB, MINSUB, cat="signed_zero")         # underflow to zero keeps the sign
    add(3, MINSUB, 0x80000001, cat="signed_zero")
    # subnormals in and out
    for x in (MINSUB, MAXSUB, 0x00400000, 0x80000003, 0x00000155):
        add(1, x, MINN, cat="subnormal")
        add(3, x, 0x4B000000, cat="subnormal")       # scale up into normal
        add(3, MINN, x, cat="subnormal")             # deep underflow
        add(4, x, TWO, 0x80800000, cat="subnormal")
    add(2, 0x00800001, MINN, cat="subnormal")         # normal - normal = subnormal (exact)
    add(3, MINN, HALF, cat="subnormal")
    # overflow (all rounding modes, both signs)
    for s in (0, SIGN):
        add(1, MAXF | s, 0x73800000 | s, cat="overflow")   # maxf + ulp/2
        add(1, MAXF | s, MAXF | s, cat="overflow")
        add(3, 0x7F000000 | s, TWO, cat="overflow")
        add(4, MAXF | s, TWO, 0xFF7FFFFF ^ s, cat="overflow")
        add(3, MAXF | s, 0x3F800001, cat="overflow")
    # underflow: tiny before / after rounding, exact tiny, boundary 0x00800000
    add(3, 0x00FFFFFF, HALF, cat="underflow")          # (2^24-1)*2^-150 -> min normal, tiny after rounding
    add(3, 0x01FFFFFF, 0x3E800000, cat="underflow")    # exact, no flags
    add(3, 0x00800001, HALF, cat="underflow")
    add(3, 0x00800003, 0x3F7FFFFF, cat="underflow")
    add(4, MINN, HALF, MINSUB, cat="underflow")
    add(4, 0x00FFFFFF, HALF, 0x80000000, cat="underflow")
    add(1, 0x00800000, 0x80000001, cat="underflow")    # exact subnormal: no UF
    # rounding: ties to even / away, halfway, sticky
    for a, b in [(0x4B800000, 0x3F800000), (0x4B800000, 0x40400000), (0x4B800001, 0x3F800000),
                 (0x3F800000, 0x33800000), (0x3F800000, 0x33800001), (0x3F800001, 0x33800000),
                 (0x3F800000, 0xB3800000), (0x3F800000, 0x337FFFFF)]:
        add(1, a, b, cat="rounding")
        add(1, a | SIGN, b | SIGN, cat="rounding")
    for a, b in [(0x3FC00001, 0x3FC00001), (0x3F800001, 0x3F7FFFFF), (0x45800001, 0x45800001)]:
        add(3, a, b, cat="rounding")
    # flags: one directed case per flag combination that can occur
    add(1, ONE, 0x33800001, cat="flags")               # NX
    add(3, 0x00000003, HALF, cat="flags")              # UF NX
    add(3, MAXF, TWO, cat="flags")                     # OF NX
    add(1, PINF, NINF, cat="flags")                    # NV
    add(11, QNAN_POS, ONE, cat="flags", rms=(0,))      # FLT NV on quiet NaN
    add(10, QNAN_POS, ONE, cat="flags", rms=(0,))      # FEQ quiet: no NV
    add(10, SNAN_POS, ONE, cat="flags", rms=(0,))      # FEQ sNaN: NV
    add(12, ONE, ONE, cat="flags", rms=(0,))
    # comparisons and min/max ordering
    for a, b in [(ONE, TWO), (TWO, ONE), (ONE, ONE), (NZERO, PZERO), (NINF, PINF), (MINSUB, 0x80000001),
                 (MAXF, PINF), (0xBF800000, ONE)]:
        for op in (8, 9, 10, 11, 12):
            add(op, a, b, cat="compare_minmax", rms=(0,))
    # rounding mode codes 5..7 on rounding ops are illegal in the lane contract
    for rm in (5, 6, 7):
        for op in (1, 3, 4):
            V.append((op, rm, ONE, ONE, ONE, "illegal_rm"))
    # integer ops
    for a, b in [(0xFFFFFFFF, 1), (0x7FFFFFFF, 1), (0x80000000, 0x80000000), (0x12345678, 0x9ABCDEF0),
                 (0xFFFFFFFF, 0xFFFFFFFF)]:
        add(0x10, a, b, cat="integer", rms=(0,))
        add(0x11, a, b, cat="integer", rms=(0,))
    return V


CATEGORIES = ["exact", "fma_single_rounding", "nan", "nan_inf_times_zero", "inf", "signed_zero", "subnormal",
              "overflow", "underflow", "rounding", "flags", "compare_minmax", "illegal_rm", "integer"]
