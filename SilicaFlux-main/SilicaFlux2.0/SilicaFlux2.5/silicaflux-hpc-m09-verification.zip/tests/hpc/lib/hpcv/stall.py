"""Deterministic stall / back-pressure pattern generators.

A pattern is a callable returning True when the agent may assert valid (source)
or ready (sink) in the coming cycle.  Every pattern is seeded, so a failing run
is reproduced exactly by its (pattern, seed).

Patterns (brief §9 "different stall patterns"):
  none        always allowed (full rate)
  random:P    allowed with probability P per cycle (e.g. random:0.5)
  bursty      alternating on/off bursts of random length 1..16
  periodic:N  allowed one cycle in N
  starve      allowed rarely (probability 0.08): long idle gaps
  hold:N      blocked for N cycles at start, then full rate (fill to full)
"""
from __future__ import annotations

import random


class Stall:
    def __init__(self, spec: str = "none", seed: int = 1):
        self.spec = spec
        self.r = random.Random(f"{spec}:{seed}")
        kind, _, arg = spec.partition(":")
        self.kind = kind
        self.arg = arg
        self.n = 0
        self.burst_on = True
        self.burst_left = 0

    def __call__(self) -> bool:
        self.n += 1
        k = self.kind
        if k == "none":
            return True
        if k == "random":
            return self.r.random() < float(self.arg or 0.5)
        if k == "starve":
            return self.r.random() < 0.08
        if k == "periodic":
            return (self.n % int(self.arg or 4)) == 0
        if k == "hold":
            return self.n > int(self.arg or 64)
        if k == "bursty":
            if self.burst_left <= 0:
                self.burst_on = not self.burst_on
                self.burst_left = self.r.randint(1, 16)
            self.burst_left -= 1
            return self.burst_on
        raise ValueError(f"unknown stall pattern {self.spec}")

    def __repr__(self):
        return f"Stall({self.spec})"


PATTERNS_CI = ["none", "random:0.5", "bursty"]
PATTERNS_NIGHTLY = ["none", "random:0.5", "random:0.15", "bursty", "periodic:3", "starve"]
