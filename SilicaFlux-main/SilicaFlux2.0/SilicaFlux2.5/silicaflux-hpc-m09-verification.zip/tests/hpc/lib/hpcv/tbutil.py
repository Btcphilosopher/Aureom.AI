"""Helpers used inside cocotb testbenches."""
from __future__ import annotations

import json
import os
import random

import cocotb
from cocotb.clock import Clock


def seed() -> int:
    return int(os.environ.get("HPC_SEED", cocotb.RANDOM_SEED))


def rng(tag: str = "") -> random.Random:
    return random.Random(f"{seed()}:{tag}")


def env_int(name, default):
    return int(os.environ.get(name, default))


def env_str(name, default):
    return os.environ.get(name, default)


def start_clock(dut, name="clk", period_ns=10):
    cocotb.start_soon(Clock(getattr(dut, name), period_ns, units="ns").start())


def publish(metrics: dict):
    """Write per-test metrics (counts, coverage bins) for the result record."""
    p = os.environ.get("HPC_METRICS")
    if not p:
        return
    old = {}
    if os.path.exists(p):
        try:
            old = json.load(open(p))
        except Exception:
            old = {}
    old.update(metrics)
    with open(p, "w") as f:
        json.dump(old, f, indent=1, default=str)


def checker_errors(dut, names):
    """Sum the err_cnt outputs of the SV protocol checkers instantiated in the TB wrapper."""
    tot = {}
    for n in names:
        h = getattr(dut, n, None)
        tot[n] = int(h.value) if h is not None else None
    return tot


def finish(engine, scoreboards, dut=None, checker_sigs=(), extra=None):
    """Common end-of-test: scoreboards drained, no protocol errors; publish metrics; raise on failure."""
    ok = True
    for sb in scoreboards:
        ok = sb.final_check() and ok
    chk = checker_errors(dut, checker_sigs) if dut is not None else {}
    for k, v in chk.items():
        if v:
            engine.error(f"SV checker {k}: {v} violation(s)")
            ok = False
    m = {"cycles": engine.cycle, "errors": len(engine.errors),
         "scoreboards": {sb.name: sb.stats() for sb in scoreboards}, "sv_checkers": chk}
    m.update(extra or {})
    publish(m)
    if engine.errors:
        raise AssertionError(f"{len(engine.errors)} error(s); first: {engine.errors[0]}")
    assert ok, "scoreboard / checker failure"
