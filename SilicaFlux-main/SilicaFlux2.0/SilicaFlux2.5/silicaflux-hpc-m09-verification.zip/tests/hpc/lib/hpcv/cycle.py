"""Cycle-based cocotb verification components for valid/ready interfaces.

One ``Engine`` coroutine owns the clock edge; every agent is called twice per
cycle, in a fixed order, which keeps runs deterministic and fast:

  RisingEdge(clk)  -> agent.on_edge(cycle):  the handshakes sampled before this
                      edge have happened: commit them, then drive the next values
  ReadOnly()       -> agent.sample(cycle):   all signals settled for the coming
                      edge: determine which handshakes will fire

``Source`` drives valid + payload and obeys the producer contract (once valid is
asserted the payload is held until accepted: AXI-style).  ``Sink`` drives ready
from a stall pattern, captures every transfer and checks the consumer-side
contract of the DUT output (payload stable while stalled, valid never dropped
without a handshake).  Violations are collected in ``Engine.errors``.
"""
from __future__ import annotations

from collections import deque
from typing import Callable

import cocotb
from cocotb.triggers import ReadOnly, RisingEdge

from .stall import Stall


def sig(dut, name):
    return getattr(dut, name)


def val(h) -> int:
    v = h.value
    try:
        return int(v)
    except ValueError:            # X/Z in a 4-state simulator
        return -1


def bstr(h) -> str:
    """the value as an MSB-first bit string ('x'/'z' preserved) for per-field slicing of flat vectors."""
    v = h.value
    try:
        return v.binstr
    except AttributeError:
        return format(int(v), "b")


def field(bs: str, lsb: int, width: int) -> int:
    """bits [lsb +: width] of an MSB-first bit string; -1 if any of them is X/Z."""
    n = len(bs)
    seg = bs[max(0, n - lsb - width): n - lsb] if lsb < n else ""
    seg = seg.rjust(width, "0")
    try:
        return int(seg, 2)
    except ValueError:
        return -1


def field_str(bs: str, lsb: int, width: int) -> str:
    """bits [lsb +: width] as an MSB-first string (X/Z kept)."""
    n = len(bs)
    return (bs[max(0, n - lsb - width): n - lsb] if lsb < n else "").rjust(width, "0")


def masked_equal(got: str, exp: int, mask: int) -> bool:
    """got (MSB-first bit string) equals exp on every bit set in mask; those bits must not be X/Z.
    Bits outside mask are unconstrained (e.g. never-written SRAM bytes may read as X)."""
    w = len(got)
    for i, ch in enumerate(got):
        bit = w - 1 - i
        if not (mask >> bit) & 1:
            continue
        if ch not in "01" or int(ch) != (exp >> bit) & 1:
            return False
    return True


class Engine:
    def __init__(self, dut, clk="clk", max_errors=20):
        self.dut = dut
        self.clk = sig(dut, clk)
        self.agents = []
        self.cycle = 0
        self.errors: list[str] = []
        self.max_errors = max_errors
        self.in_reset = False
        self.hooks_edge: list[Callable[[int], None]] = []
        self.hooks_sample: list[Callable[[int], None]] = []
        self._task = None

    def error(self, msg: str):
        self.errors.append(f"cycle {self.cycle}: {msg}")
        if len(self.errors) <= self.max_errors:
            self.dut._log.error(msg)

    def add(self, agent):
        agent.engine = self
        self.agents.append(agent)
        return agent

    def start(self):
        self._task = cocotb.start_soon(self._run())

    async def _run(self):
        while True:
            await RisingEdge(self.clk)
            self.cycle += 1
            for a in self.agents:
                a.on_edge(self.cycle)
            for h in self.hooks_edge:
                h(self.cycle)
            await ReadOnly()
            for a in self.agents:
                a.sample(self.cycle)
            for h in self.hooks_sample:
                h(self.cycle)

    def reset_agents(self):
        for a in self.agents:
            a.reset()

    async def cycles(self, n):
        for _ in range(n):
            await RisingEdge(self.clk)


class Source:
    """Drives ``valid`` and payload fields; items are dicts {field: int}."""

    def __init__(self, dut, valid, ready, fields: dict[str, str], stall: Stall | None = None,
                 on_accept: Callable | None = None, name="src"):
        self.dut = dut
        self.v = sig(dut, valid)
        self.r = sig(dut, ready)
        self.fields = {k: sig(dut, s) for k, s in fields.items()}
        self.stall = stall or Stall("none")
        self.on_accept = on_accept
        self.name = name
        self.q: deque = deque()
        self.cur = None
        self.fire = False
        self.accepted = 0
        self.stall_cycles = 0       # valid && !ready
        self.enabled = True
        self.v.value = 0

    def send(self, item: dict):
        self.q.append(item)

    def idle(self) -> bool:
        return self.cur is None and not self.q

    def reset(self):
        self.q.clear()
        self.cur = None
        self.fire = False
        self.v.value = 0

    def drop_current_on_reset(self):
        c = self.cur
        self.cur = None
        self.fire = False
        self.v.value = 0
        return c

    def on_edge(self, cyc):
        if self.engine.in_reset:
            self.v.value = 0
            return
        if self.fire:
            item = self.cur
            self.cur = None
            self.accepted += 1
            if self.on_accept:
                self.on_accept(item, cyc)
        if self.cur is None and self.q and self.enabled and self.stall():
            self.cur = self.q.popleft()
            for k, h in self.fields.items():
                h.value = self.cur.get(k, 0)
        self.v.value = 1 if self.cur is not None else 0

    def sample(self, cyc):
        rdy = val(self.r)
        self.fire = self.cur is not None and rdy == 1 and not self.engine.in_reset
        if self.cur is not None and rdy != 1:
            self.stall_cycles += 1


class Sink:
    """Drives ``ready`` from a stall pattern; captures transfers; checks output stability."""

    def __init__(self, dut, valid, ready, fields: dict[str, str], stall: Stall | None = None,
                 on_item: Callable | None = None, name="sink", check_stable=True, raw_fields=()):
        self.raw = set(raw_fields)        # captured as MSB-first bit strings (X/Z allowed, checked by the user)
        self.dut = dut
        self.v = sig(dut, valid)
        self.r = sig(dut, ready)
        self.fields = {k: sig(dut, s) for k, s in fields.items()}
        self.stall = stall or Stall("none")
        self.on_item = on_item
        self.name = name
        self.check_stable = check_stable
        self.pending = None
        self.prev_stalled = None
        self.received = 0
        self.bp_cycles = 0
        self.r.value = 0
        self.force_ready = None

    def reset(self):
        self.pending = None
        self.prev_stalled = None

    def on_edge(self, cyc):
        if self.pending is not None:
            item = self.pending
            self.pending = None
            self.received += 1
            if self.on_item:
                self.on_item(item, cyc)
        rdy = self.force_ready if self.force_ready is not None else (1 if self.stall() else 0)
        self.r.value = rdy

    def sample(self, cyc):
        if self.engine.in_reset:
            self.prev_stalled = None
            return
        v = val(self.v)
        rdy = val(self.r)
        if v not in (0, 1):
            self.engine.error(f"{self.name}: valid is X/Z")
            return
        cur = {k: (bstr(h) if k in self.raw else val(h)) for k, h in self.fields.items()} if v == 1 else None
        if self.check_stable and self.prev_stalled is not None:
            if v != 1:
                self.engine.error(f"{self.name}: valid dropped without handshake (payload {self.prev_stalled})")
            elif cur != self.prev_stalled:
                self.engine.error(f"{self.name}: payload changed while stalled: {self.prev_stalled} -> {cur}")
        if v == 1 and any(x < 0 for k, x in cur.items() if k not in self.raw):
            self.engine.error(f"{self.name}: payload X/Z while valid: {cur}")
        if v == 1 and rdy == 1:
            self.pending = cur
            self.prev_stalled = None
        elif v == 1:
            self.prev_stalled = cur
            self.bp_cycles += 1
        else:
            self.prev_stalled = None


class Monitor:
    """Passive: captures valid&&ready transfers of a channel driven by others."""

    def __init__(self, dut, valid, ready, fields: dict[str, str], on_item: Callable, name="mon"):
        self.v = sig(dut, valid)
        self.r = sig(dut, ready) if ready else None
        self.fields = {k: sig(dut, s) for k, s in fields.items()}
        self.on_item = on_item
        self.name = name
        self.pending = None

    def reset(self):
        self.pending = None

    def on_edge(self, cyc):
        if self.pending is not None:
            self.on_item(self.pending, cyc)
            self.pending = None

    def sample(self, cyc):
        if self.engine.in_reset:
            return
        if val(self.v) == 1 and (self.r is None or val(self.r) == 1):
            self.pending = {k: val(h) for k, h in self.fields.items()}


async def reset_dut(engine: Engine, rst, cycles=3, active_low=True):
    """Assert reset (asynchronously, mid-cycle) for ``cycles`` clock cycles."""
    from cocotb.triggers import Timer, FallingEdge
    h = sig(engine.dut, rst)
    await FallingEdge(engine.clk)
    engine.in_reset = True
    engine.reset_agents()
    h.value = 0 if active_low else 1
    for _ in range(cycles):
        await RisingEdge(engine.clk)
    await FallingEdge(engine.clk)
    h.value = 1 if active_low else 0
    engine.in_reset = False
