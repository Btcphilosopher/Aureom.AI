"""SFB2 (DataFabric) slave model and byte-addressable external memory.

The slave obeys the DataFabric SFB2 rules from the slave side:
R4 response held stable while rsp_ready is low, R5 exactly one response per
accepted request, in order, at least one cycle later, R7 a write is PERFORMED
only when its response is handed over (deliberately the latest legal point, so a
master that reports completion before its last write acknowledgement is caught
by a memory compare), R8 error responses carry rdata 0 and have no side effect.
Request back-pressure and response latency are drawn from seeded generators.
"""
from __future__ import annotations

import random
from collections import deque

from .cycle import val
from .stall import Stall


class ByteMemory:
    """sparse byte memory; never-written bytes read as a deterministic address hash."""

    def __init__(self, seed=1):
        self.m: dict[int, int] = {}
        self.salt = seed * 0x9E3779B1

    @staticmethod
    def _h(a, salt):
        x = (a * 2654435761 + salt) & 0xFFFFFFFF
        x ^= x >> 15
        return (x * 0x2C1B3C6D >> 7) & 0xFF

    def rb(self, a):
        return self.m.get(a, self._h(a, self.salt))

    def wb(self, a, v):
        self.m[a] = v & 0xFF

    def rword(self, a, n=4):
        return sum(self.rb(a + i) << (8 * i) for i in range(n))

    def wword(self, a, v, strb, n=4):
        for i in range(n):
            if (strb >> i) & 1:
                self.wb(a + i, (v >> (8 * i)) & 0xFF)

    def copy(self):
        c = ByteMemory()
        c.m = dict(self.m)
        c.salt = self.salt
        return c


class SfbSlave:
    """one SFB2 slave per fabric port of a flat (NP-wide) master bus."""

    def __init__(self, dut, mem: ByteMemory, np_=1, *, prefix="fab", stall="random:0.7", lat=(1, 6), max_out=4,
                 error_windows=(), seed=1):
        self.dut = dut
        self.mem = mem
        self.np = np_
        self.pre = prefix
        self.st = [Stall(stall, seed + 50 + p) for p in range(np_)]
        self.r = random.Random(f"sfb:{seed}")
        self.lat = lat
        self.max_out = max_out
        self.errw = list(error_windows)
        self.pend = [deque() for _ in range(np_)]
        self.acc = 0
        self.rfire = 0
        self.req_cap = [None] * np_
        self.stats = dict(reads=0, writes=0, errors=0, write_acks=0, max_pending=0)
        self.write_ack_count = 0          # error-free write responses handed over
        self.truth = dict(rd_ok=0, wr_bytes=0, err_rsp=0, reqs=0, rd_req=0, wr_req=0)   # bus-observed truth
        self.in_reset = False
        self.g = lambda s: getattr(dut, f"{prefix}_{s}")
        self.g("req_ready").value = 0
        self.g("rsp_valid").value = 0
        self.g("rsp_rdata").value = 0
        self.g("rsp_error").value = 0

    def is_err(self, a):
        return any(lo <= a < hi for lo, hi in self.errw)

    def reset(self):
        for q in self.pend:
            q.clear()
        self.acc = self.rfire = 0
        self.g("req_ready").value = 0
        self.g("rsp_valid").value = 0

    def on_edge(self, cyc):
        if self.engine.in_reset:
            self.g("req_ready").value = 0
            self.g("rsp_valid").value = 0
            return
        for p in range(self.np):
            if (self.rfire >> p) & 1:                       # response handed over at this edge
                it = self.pend[p].popleft()
                if it["err"]:
                    self.truth["err_rsp"] += 1
                elif it["write"]:
                    self.truth["wr_bytes"] += bin(it["wstrb"]).count("1")
                else:
                    self.truth["rd_ok"] += 1
                if it["write"] and not it["err"]:
                    self.mem.wword(it["addr"], it["wdata"], it["wstrb"])   # R7: performed now
                    self.write_ack_count += 1
                    self.stats["write_acks"] += 1
            if (self.acc >> p) & 1:                          # request accepted at this edge
                rq = self.req_cap[p]
                err = self.is_err(rq["addr"])
                self.pend[p].append({**rq, "err": err, "due": cyc + self.r.randint(*self.lat) - 1})
                self.stats["writes" if rq["write"] else "reads"] += 1
                self.truth["wr_req" if rq["write"] else "rd_req"] += 1
                self.stats["errors"] += err
                self.stats["max_pending"] = max(self.stats["max_pending"], len(self.pend[p]))
        rv = rd = re = rr = 0
        for p in range(self.np):
            q = self.pend[p]
            if q and q[0]["due"] <= cyc:
                it = q[0]
                rv |= 1 << p
                re |= int(it["err"]) << p
                if not it["write"] and not it["err"]:
                    if "rdata" not in it:
                        it["rdata"] = self.mem.rword(it["addr"])
                    rd |= it["rdata"] << (32 * p)
            if len(q) < self.max_out and self.st[p]():
                rr |= 1 << p
        self.g("rsp_valid").value = rv
        self.g("rsp_rdata").value = rd
        self.g("rsp_error").value = re
        self.g("req_ready").value = rr

    def sample(self, cyc):
        if self.engine.in_reset:
            self.acc = self.rfire = 0
            return
        v, r = val(self.g("req_valid")), val(self.g("req_ready"))
        self.acc = v & r
        if self.acc:
            w, a, d, s = val(self.g("req_write")), val(self.g("req_addr")), val(self.g("req_wdata")), \
                val(self.g("req_wstrb"))
            for p in range(self.np):
                if (self.acc >> p) & 1:
                    self.req_cap[p] = {"write": (w >> p) & 1, "addr": (a >> (32 * p)) & 0xFFFFFFFF,
                                       "wdata": (d >> (32 * p)) & 0xFFFFFFFF, "wstrb": (s >> (4 * p)) & 0xF}
        self.rfire = val(self.g("rsp_valid")) & val(self.g("rsp_ready"))

    def idle(self):
        return all(not q for q in self.pend)
