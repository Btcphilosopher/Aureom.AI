"""Transaction scoreboards.

InOrderScoreboard  expected items arrive in order (lane, array, per-port SPM,
                   DMA completions).  Detects: mismatch, unexpected (unsolicited
                   or duplicate) item, missing items at the end.
TaggedScoreboard   items matched by tag, any order; detects duplicate tags in
                   flight, unknown tags, duplicates, missing.
Both keep counts used by the reports (checked, errors, max outstanding).
"""
from __future__ import annotations

from collections import deque


class InOrderScoreboard:
    def __init__(self, name, engine, compare=None, fmt=None):
        self.name = name
        self.engine = engine
        self.exp: deque = deque()
        self.checked = 0
        self.mismatches = 0
        self.unexpected = 0
        self.compare = compare or (lambda e, a: e == a)
        self.fmt = fmt or (lambda x: str(x))
        self.max_outstanding = 0

    def expect(self, item):
        self.exp.append(item)
        self.max_outstanding = max(self.max_outstanding, len(self.exp))

    def flush(self):
        """reset: everything outstanding is architecturally discarded."""
        n = len(self.exp)
        self.exp.clear()
        return n

    def got(self, item, cyc=None):
        if not self.exp:
            self.unexpected += 1
            self.engine.error(f"{self.name}: unexpected/duplicate item {self.fmt(item)}")
            return
        e = self.exp.popleft()
        self.checked += 1
        if not self.compare(e, item):
            self.mismatches += 1
            self.engine.error(f"{self.name}: mismatch\n    expected {self.fmt(e)}\n    actual   {self.fmt(item)}")

    def outstanding(self):
        return len(self.exp)

    def final_check(self):
        if self.exp:
            self.engine.error(f"{self.name}: {len(self.exp)} expected item(s) never arrived, first "
                              f"{self.fmt(self.exp[0])}")
        return not self.exp and self.mismatches == 0 and self.unexpected == 0

    def stats(self):
        return {"checked": self.checked, "mismatches": self.mismatches, "unexpected": self.unexpected,
                "missing": len(self.exp), "max_outstanding": self.max_outstanding}


class TaggedScoreboard:
    def __init__(self, name, engine, compare=None, fmt=None):
        self.name = name
        self.engine = engine
        self.exp: dict = {}
        self.checked = 0
        self.mismatches = 0
        self.unexpected = 0
        self.compare = compare or (lambda e, a: e == a)
        self.fmt = fmt or str

    def expect(self, tag, item):
        if tag in self.exp:
            self.engine.error(f"{self.name}: tag {tag} reused while outstanding (testbench)")
        self.exp[tag] = item

    def got(self, tag, item, cyc=None):
        if tag not in self.exp:
            self.unexpected += 1
            self.engine.error(f"{self.name}: unknown or duplicate tag {tag}: {self.fmt(item)}")
            return
        e = self.exp.pop(tag)
        self.checked += 1
        if not self.compare(e, item):
            self.mismatches += 1
            self.engine.error(f"{self.name}: tag {tag} mismatch: expected {self.fmt(e)} actual {self.fmt(item)}")

    def flush(self):
        n = len(self.exp)
        self.exp.clear()
        return n

    def final_check(self):
        if self.exp:
            self.engine.error(f"{self.name}: {len(self.exp)} tag(s) never completed: {list(self.exp)[:8]}")
        return not self.exp and self.mismatches == 0 and self.unexpected == 0

    def stats(self):
        return {"checked": self.checked, "mismatches": self.mismatches, "unexpected": self.unexpected,
                "missing": len(self.exp)}
