"""Simulator build helpers (Verilator C++ harnesses, Icarus) shared by every suite.

Builds are content-addressed: the build directory name is a hash of the file
list, file contents, defines, parameters and flags, so a changed RTL file always
triggers a rebuild and an unchanged one is reused across suites and seeds.
"""
from __future__ import annotations

import hashlib
import os
import shutil
import subprocess
import sys
from pathlib import Path

HPC = Path(__file__).resolve().parents[2]
BUILD = Path(os.environ.get("HPC_BUILD", HPC / "build")).resolve()
sys.path.insert(0, str(HPC / "common"))
import filelists as FL  # noqa: E402

JOBS = int(os.environ.get("HPC_JOBS", os.cpu_count() or 2))


def ensure_rtl():
    if not (BUILD / "rtl_revision.json").exists():
        subprocess.run([sys.executable, str(HPC / "common/fetch_rtl.py"), "--quiet"], check=True)


def ensure_ref():
    if not (BUILD / "ref/libhpcsf.so").exists() or not (BUILD / "ref/hpcsf_shim.o").exists():
        subprocess.run(["bash", str(HPC / "reference_models/softfloat/build_ref.sh")], check=True,
                       stdout=subprocess.DEVNULL)


def _digest(parts) -> str:
    h = hashlib.sha256()
    for p in parts:
        if isinstance(p, Path) and p.is_file():
            h.update(str(p.name).encode())
            h.update(p.read_bytes())
        else:
            h.update(repr(p).encode())
    return h.hexdigest()[:16]


def tool_versions() -> dict:
    def v(cmd):
        try:
            return subprocess.run(cmd, capture_output=True, text=True, timeout=20).stdout.strip().splitlines()[0]
        except Exception:
            return "not installed"
    out = {"verilator": v(["verilator", "--version"]), "iverilog": v(["iverilog", "-V"]),
           "yosys": v(["yosys", "-V"]), "python": sys.version.split()[0], "gcc": v(["gcc", "--version"])}
    try:
        import cocotb
        out["cocotb"] = cocotb.__version__
    except Exception:
        out["cocotb"] = "not installed"
    try:
        import gmpy2
        out["mpfr"] = gmpy2.mpfr_version()
        out["gmpy2"] = gmpy2.version()
    except Exception:
        pass
    try:
        import z3
        out["z3"] = z3.get_version_string()
    except Exception:
        out["z3"] = v(["z3", "--version"])
    out["softfloat"] = "Berkeley SoftFloat Release 3e (vendored in Module 01, git f74b1e4)"
    out["testfloat"] = "Berkeley TestFloat Release 3e (vendored in Module 01, git 06b2007)"
    return out


def verilator_cpp(name: str, top: str, sources: list[Path], cpp: list[Path], *, params: dict | None = None,
                  defines: list[str] | None = None, cflags: str = "", ldflags: str = "",
                  incdirs: list[Path] | None = None, trace: bool = False, coverage: bool = False,
                  extra: list[str] | None = None) -> Path:
    """Build a Verilator C++ harness; returns the executable path."""
    params = params or {}
    defines = defines or []
    incdirs = incdirs or []
    key = _digest(list(sources) + list(cpp) + [top, sorted(params.items()), defines, cflags, ldflags,
                                               [str(i) for i in incdirs], trace, coverage, extra or []])
    out = BUILD / "vl" / f"{name}-{key}"
    exe = out / f"V{top}"
    if exe.exists():
        return exe
    if out.exists():
        shutil.rmtree(out)
    out.mkdir(parents=True)
    args = ["verilator", "--cc", "--exe", "--build", "-j", str(JOBS), "-O3", "--x-assign", "fast",
            "--x-initial", "unique", "--assert", "-Wno-fatal", "-Wno-lint", "-Wno-style",
            "--top-module", top, "-Mdir", str(out / "obj"), "-o", str(exe)]
    if trace:
        args += ["--trace-fst", "--trace-structs"]
    if coverage:
        args += ["--coverage-line", "--coverage-toggle", "--coverage-user"]
    for k, v in params.items():
        args.append(f"-G{k}={v}")
    for d in defines:
        args.append(f"+define+{d}")
    for i in incdirs:
        args.append(f"+incdir+{i}")
    cf = cflags + (" -DHPC_TRACE=1" if trace else "") + " -Wno-format-security"
    args += ["-CFLAGS", cf.strip()]
    if ldflags:
        args += ["-LDFLAGS", ldflags]
    args += extra or []
    args += [str(s) for s in sources] + [str(c) for c in cpp]
    log = out / "build.log"
    with open(log, "w") as f:
        f.write(" ".join(args) + "\n")
        r = subprocess.run(args, stdout=f, stderr=subprocess.STDOUT)
    if r.returncode != 0 or not exe.exists():
        raise RuntimeError(f"Verilator build failed: {log}\n" + log.read_text()[-3000:])
    return exe


def run(cmd, *, log: Path, cwd: Path | None = None, timeout: int = 7200, stdin=None, env=None) -> int:
    log.parent.mkdir(parents=True, exist_ok=True)
    with open(log, "w") as f:
        f.write("$ " + " ".join(str(c) for c in cmd) + "\n")
        f.flush()
        try:
            r = subprocess.run([str(c) for c in cmd], stdout=f, stderr=subprocess.STDOUT, cwd=cwd,
                               timeout=timeout, stdin=stdin, env=env)
            return r.returncode
        except subprocess.TimeoutExpired:
            f.write(f"\nTIMEOUT after {timeout} s\n")
            return 124
