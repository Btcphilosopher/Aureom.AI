// =============================================================================
// SilicaFlux-HPC verification :: tb_dma_top -- cocotb wrapper for hpc_dma_adapter
//
//   cocotb descriptor / completion  -> hpc_dma_adapter (Module 05, unmodified)
//   adapter scratchpad port(s) 0..NP-1 -> hpc_scratchpad (Module 04, unmodified)
//   scratchpad port NP              <- cocotb (initialise / check SPM, create bank contention)
//   adapter fabric port(s)          <-> cocotb SFB2 slave model (latency, back-pressure,
//                                       late write commit, error injection)
// Checkers: DataFabric sfb_protocol_checker (reused, unmodified) on every fabric link;
// hpc_rv_checker on descriptor and completion; one completion per descriptor.
// The adapter <-> scratchpad link is exported (mon_*) so the testbench can count
// acknowledged writes per transfer.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_dma_top #(
  parameter int ENGINE      = 0,
  parameter int FIFO_DEPTH  = 8,
  parameter int BURST       = 8,
  parameter int DUAL_PORT   = 0,
  parameter int MAX_OUT     = 2,
  parameter int CMD_DEPTH   = 2,
  parameter int CPL_DEPTH   = 2,
  parameter int FAB_SLICE   = 0,
  parameter int SPM_BANKS   = 4,
  parameter int SPM_RL      = 1,
  parameter int SPM_QD      = 0,
  parameter int SPM_BYTES   = 65536,
  parameter logic [31:0] SPM_BASE = 32'h2000_0000,
  localparam int NP  = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1,
  localparam int NSP = NP + 1,
  localparam int TW  = 8
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [31:0]      cmd_src, cmd_dst, cmd_len,
  input  wire logic [7:0]       cmd_tag,
  input  wire logic             cmd_abort,
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [7:0]            cpl_tag,
  output logic                  cpl_err,
  output logic [3:0]            cpl_code,
  output logic [31:0]           cpl_err_addr, cpl_bytes,
  output logic                  busy, active,
  // fabric (SFB2 master side of the adapter)
  output logic [NP-1:0]         fab_req_valid,
  input  wire logic [NP-1:0]    fab_req_ready,
  output logic [NP-1:0]         fab_req_write,
  output logic [NP*32-1:0]      fab_req_addr,
  output logic [NP*32-1:0]      fab_req_wdata,
  output logic [NP*4-1:0]       fab_req_wstrb,
  input  wire logic [NP-1:0]    fab_rsp_valid,
  output logic [NP-1:0]         fab_rsp_ready,
  input  wire logic [NP*32-1:0] fab_rsp_rdata,
  input  wire logic [NP-1:0]    fab_rsp_error,
  // testbench scratchpad port
  input  wire logic             tb_req_valid,
  output logic                  tb_req_ready,
  input  wire logic             tb_req_we,
  input  wire logic [31:0]      tb_req_addr, tb_req_wdata,
  input  wire logic [3:0]       tb_req_wstrb,
  input  wire logic [TW-1:0]    tb_req_tag,
  output logic                  tb_rsp_valid,
  input  wire logic             tb_rsp_ready,
  output logic [31:0]           tb_rsp_rdata,
  output logic                  tb_rsp_err,
  output logic                  tb_rsp_we,
  output logic [TW-1:0]         tb_rsp_tag,
  // monitors
  output logic [NP-1:0]         mon_spm_rsp_fire, mon_spm_rsp_we, mon_spm_req_fire, mon_spm_req_we, mon_spm_rsp_err,
  output logic [NP*4-1:0]       mon_spm_req_wstrb,
  output logic [16*32-1:0]      dma_perf_cnt,
  output logic                  ev_cpl, ev_start,
  output logic [7:0]            ev_outstanding, ev_bytes_wr, ev_bytes_rd,
  output logic                  ev_bus_err, ev_tag_err,
  output logic [7:0]            fifo_level,
  output logic [31:0]           chk_err
);
  // ------------------------------------------------------------- adapter <-> scratchpad
  logic [NP-1:0]      a_req_valid, a_req_ready, a_req_we, a_rsp_valid, a_rsp_ready, a_rsp_err, a_rsp_we;
  logic [NP*32-1:0]   a_req_addr, a_req_wdata, a_rsp_rdata;
  logic [NP*4-1:0]    a_req_wstrb;
  logic [NP*TW-1:0]   a_req_tag, a_rsp_tag;
  logic [NP*3-1:0]    a_rsp_code;
  logic [TW-1:0]      cur_tag;
  logic [1:0]         ctl_state;
  logic [2:0]         eng_state;
  logic [31:0]        eng_bytes;
  logic               ev_cmd_accept, ev_cpl_err, ev_req_stall;
  logic [16*32-1:0]   pc;

  hpc_dma_adapter #(.DW(32), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .BURST(BURST), .DUAL_PORT(DUAL_PORT),
                    .MAX_OUT(MAX_OUT), .MAX_LEN_LOG2(16), .SPM_BASE(SPM_BASE), .SPM_BYTES(SPM_BYTES),
                    .SPM_TAG_W(TW), .CMD_DEPTH(CMD_DEPTH), .CPL_DEPTH(CPL_DEPTH), .TAG_W(8),
                    .FAB_SLICE(FAB_SLICE), .PERF_EN(1), .CNT_W(32)) dut (
    .clk, .rst_n,
    .cmd_valid, .cmd_ready, .cmd_src, .cmd_dst, .cmd_len, .cmd_tag, .cmd_abort,
    .cpl_valid, .cpl_ready, .cpl_tag, .cpl_err, .cpl_code, .cpl_err_addr, .cpl_bytes,
    .busy, .active, .cur_tag, .ctl_state, .eng_state, .eng_bytes_done(eng_bytes), .fifo_level,
    .spm_req_valid(a_req_valid), .spm_req_ready(a_req_ready), .spm_req_we(a_req_we), .spm_req_addr(a_req_addr),
    .spm_req_wdata(a_req_wdata), .spm_req_wstrb(a_req_wstrb), .spm_req_tag(a_req_tag),
    .spm_rsp_valid(a_rsp_valid), .spm_rsp_ready(a_rsp_ready), .spm_rsp_rdata(a_rsp_rdata), .spm_rsp_err(a_rsp_err),
    .spm_rsp_err_code(a_rsp_code), .spm_rsp_we(a_rsp_we), .spm_rsp_tag(a_rsp_tag),
    .fab_req_valid, .fab_req_ready, .fab_req_write, .fab_req_addr, .fab_req_wdata, .fab_req_wstrb,
    .fab_rsp_valid, .fab_rsp_ready, .fab_rsp_rdata, .fab_rsp_error,
    .ev_cmd_accept, .ev_start, .ev_cpl, .ev_cpl_err, .ev_bytes_rd, .ev_bytes_wr, .ev_req_stall, .ev_outstanding,
    .ev_bus_err, .ev_tag_err, .perf_clear(1'b0), .perf_cnt(pc));

  // ------------------------------------------------------------- scratchpad (adapter ports + TB port)
  logic [NSP-1:0]      s_rsp_valid, s_rsp_err, s_rsp_we;
  logic [NSP*32-1:0]   s_rsp_rdata;
  logic [NSP*3-1:0]    s_rsp_code;
  logic [NSP*TW-1:0]   s_rsp_tag;
  logic [NSP-1:0]      s_req_ready;
  logic [NSP*4-1:0]    s_syn;
  logic [NSP-1:0]      e0, e1, e2, e3, e4, e5;
  logic [SPM_BANKS*2-1:0] eb;
  logic [SPM_BANKS-1:0]   ec;
  logic [31:0]         p0, p9;
  logic [NSP*32-1:0]   p1, p2, p3, p4, p5, p6;
  logic [SPM_BANKS*32-1:0] p7;
  logic                sbusy;
  hpc_scratchpad #(.NUM_PORTS(NSP), .CAPACITY_BYTES(SPM_BYTES), .NUM_BANKS(SPM_BANKS), .DATA_WIDTH(32),
                   .ADDR_WIDTH(32), .BASE_ADDR({32'h0, SPM_BASE}), .READ_LATENCY(SPM_RL), .BYTE_WE(1),
                   .PORT_MODE(0), .MAP(0), .ARB(0), .QUEUE_DEPTH(SPM_QD), .RSP_FIFO_DEPTH(SPM_RL + 1),
                   .WRITE_ACK(1), .TAG_W(TW), .ECC_MODE(0), .BACKEND(0), .MACRO(0), .PERF_EN(1), .CNT_W(32)) u_spm (
    .clk, .rst_n,
    .req_valid({tb_req_valid, a_req_valid}), .req_ready(s_req_ready), .req_we({tb_req_we, a_req_we}),
    .req_addr({tb_req_addr, a_req_addr}), .req_wdata({tb_req_wdata, a_req_wdata}),
    .req_wstrb({tb_req_wstrb, a_req_wstrb}), .req_tag({tb_req_tag, a_req_tag}),
    .rsp_valid(s_rsp_valid), .rsp_ready({tb_rsp_ready, a_rsp_ready}), .rsp_rdata(s_rsp_rdata), .rsp_err(s_rsp_err),
    .rsp_err_code(s_rsp_code), .rsp_we(s_rsp_we), .rsp_tag(s_rsp_tag), .rsp_ecc_syn(s_syn),
    .ev_accept(e0), .ev_issue(e1), .ev_conflict(e2), .ev_credit_stall(e3), .ev_error(e4), .ev_ecc_err(e5),
    .ev_bank_ops(eb), .ev_bank_conflict(ec), .perf_clear(1'b0), .perf_cycles(p0), .perf_accept(p1),
    .perf_issue(p2), .perf_complete(p3), .perf_conflict(p4), .perf_wait(p5), .perf_error(p6), .perf_bank_ops(p7),
    .perf_ecc_err(p9), .busy(sbusy));
  assign a_req_ready  = s_req_ready[NP-1:0];
  assign tb_req_ready = s_req_ready[NP];
  assign a_rsp_valid  = s_rsp_valid[NP-1:0];
  assign a_rsp_rdata  = s_rsp_rdata[NP*32-1:0];
  assign a_rsp_err    = s_rsp_err[NP-1:0];
  assign a_rsp_code   = s_rsp_code[NP*3-1:0];
  assign a_rsp_we     = s_rsp_we[NP-1:0];
  assign a_rsp_tag    = s_rsp_tag[NP*TW-1:0];
  assign tb_rsp_valid = s_rsp_valid[NP];
  assign tb_rsp_rdata = s_rsp_rdata[NP*32 +: 32];
  assign tb_rsp_err   = s_rsp_err[NP];
  assign tb_rsp_we    = s_rsp_we[NP];
  assign tb_rsp_tag   = s_rsp_tag[NP*TW +: TW];
  assign mon_spm_rsp_fire = a_rsp_valid & a_rsp_ready;
  assign mon_spm_rsp_we   = a_rsp_we;
  assign mon_spm_req_fire = a_req_valid & a_req_ready;
  assign mon_spm_req_we   = a_req_we;
  assign mon_spm_req_wstrb = a_req_wstrb;
  assign mon_spm_rsp_err  = a_rsp_err;
  assign dma_perf_cnt     = pc;

  // ------------------------------------------------------------- checkers
  logic [31:0] v_fab [NP];
  for (genvar p = 0; p < NP; p++) begin : g_fchk
    logic [31:0] nq, nr, no;
    sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(MAX_OUT), .ALLOW_REQ_CHANGE(0), .CHECK_RDATA_ZERO(1),
                           .NAME("tb_dma_fab")) u_chk (
      .clk, .rst_n, .req_valid(fab_req_valid[p]), .req_ready(fab_req_ready[p]), .req_write(fab_req_write[p]),
      .req_addr(fab_req_addr[p*32 +: 32]), .req_wdata(fab_req_wdata[p*32 +: 32]), .req_wstrb(fab_req_wstrb[p*4 +: 4]),
      .rsp_valid(fab_rsp_valid[p]), .rsp_ready(fab_rsp_ready[p]), .rsp_rdata(fab_rsp_rdata[p*32 +: 32]),
      .rsp_error(fab_rsp_error[p]), .violations(v_fab[p]), .n_req(nq), .n_rsp(nr), .outstanding(no));
  end
  logic [31:0] e_cmd, e_cpl, e_cons, e_tbr, x0, x1, x2, x3, x4, x5;
  hpc_rv_checker #(.NAME("dma_cmd"), .W(32 * 3 + 8), .RESET_LOW(1'b0)) chk_cmd (
    .clk, .rst_n, .valid(cmd_valid), .ready(cmd_ready), .payload({cmd_src, cmd_dst, cmd_len, cmd_tag}),
    .err_cnt(e_cmd), .xfer_cnt(x0));
  hpc_rv_checker #(.NAME("dma_cpl"), .W(8 + 1 + 4 + 64), .RESET_LOW(1'b1)) chk_cpl (
    .clk, .rst_n, .valid(cpl_valid), .ready(cpl_ready), .payload({cpl_tag, cpl_err, cpl_code, cpl_err_addr, cpl_bytes}),
    .err_cnt(e_cpl), .xfer_cnt(x1));
  hpc_rv_checker #(.NAME("tb_spm_rsp"), .W(32 + 1 + 1 + TW), .RESET_LOW(1'b1),
                   .XCHK_MASK({32'h0, {(2 + TW){1'b1}}})) chk_tbr (
    .clk, .rst_n, .valid(tb_rsp_valid), .ready(tb_rsp_ready), .payload({tb_rsp_rdata, tb_rsp_err, tb_rsp_we, tb_rsp_tag}),
    .err_cnt(e_tbr), .xfer_cnt(x5));
  hpc_txn_conservation #(.NAME("dma_desc"), .MAX_OUT(CMD_DEPTH + CPL_DEPTH + 2)) cons (
    .clk, .rst_n, .acc(cmd_valid && cmd_ready), .cpl(cpl_valid && cpl_ready), .outstanding(x2), .err_cnt(e_cons),
    .acc_total(x3), .cpl_total(x4));
  always_comb begin
    chk_err = e_cmd + e_cpl + e_cons + e_tbr;
    for (int p = 0; p < NP; p++) chk_err = chk_err + v_fab[p];
  end
endmodule
`default_nettype wire
