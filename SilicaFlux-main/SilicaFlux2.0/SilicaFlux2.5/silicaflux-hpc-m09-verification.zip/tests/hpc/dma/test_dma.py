"""cocotb tests for hpc_dma_adapter (Module 05) + hpc_scratchpad (Module 04) through tb_dma_top."""
from __future__ import annotations

import cocotb
from cocotb.triggers import ClockCycles, FallingEdge, ReadOnly, RisingEdge

from hpcv.cycle import val
from hpcv.dma_env import EXT_BASE, ERR_BASE, SPM_BASE, DmaEnv, setup, stalls_from_env
from hpcv.tbutil import env_int, publish, rng
from reference_models import dma_model as DM

A_EXT, B_EXT = EXT_BASE, EXT_BASE + 0x8000          # two external regions
A_SPM, B_SPM = 0x0000, 0x8000                         # two scratchpad regions (offsets)


def end(env, **extra):
    chk = val(env.dut.chk_err)
    if chk:
        env.eng.error(f"protocol checkers (sfb_protocol_checker / hpc_rv_checker): {chk} violation(s)")
    bad = env.check_ext_full()
    counters = env.check_counters()
    publish({"dma_counters": counters, "cycles": env.eng.cycle, "errors": len(env.eng.errors), "descriptors": len(env.results),
             "codes": env.codes, "directions": env.dirs, "fabric": env.fab.stats, "max_outstanding": env.max_outstanding,
             "max_fifo_level": env.max_fifo, "ext_bytes_wrong": bad, "sv_checker_errors": chk,
             "cpl_bp_cycles": env.cpl.bp_cycles, **extra})
    if env.eng.errors:
        raise AssertionError(f"{len(env.eng.errors)} error(s); first: {env.eng.errors[0]}")


def addr(space, off):
    return (SPM_BASE + off) if space == "spm" else (EXT_BASE + off)


@cocotb.test()
async def test_lengths_all_directions(dut):
    """every length 1 .. 3*DW/8+1 (+16, 17) in every direction: exact bytes, tails untouched"""
    env = DmaEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("len")
    env.spm_fill(r, A_SPM, 0x400)
    await env.drain()
    tag = 0
    lengths = list(range(1, 14)) + [16, 17, 31]
    for sd in ("ext", "spm"):
        for dd in ("ext", "spm"):
            for i, ln in enumerate(lengths):
                so = (A_SPM if sd == "spm" else 0x0000) + 0x40 * i
                do = (B_SPM if dd == "spm" else 0x8000) + 0x40 * i + (0x400 if sd == dd else 0)
                env.desc(addr(sd, so), addr(dd, do), ln, tag)
                tag += 1
    await env.drain()
    env.spm_check(B_SPM, 0x800)
    await env.drain()
    end(env)


@cocotb.test()
async def test_long_transfers(dut):
    """long transfers in three directions (nothing truncated, last word partial)"""
    env = DmaEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("long")
    ln = env_int("HPC_LONG_LEN", 4096)
    env.spm_fill(r, A_SPM, min(ln + 4, 0x8000))
    await env.drain()
    env.desc(A_EXT, SPM_BASE + B_SPM, min(ln, 0x8000) - 1, 1)                    # ext -> spm, partial last word
    env.desc(SPM_BASE + A_SPM, B_EXT, min(ln, 0x8000) - 2, 2)                    # spm -> ext
    env.desc(SPM_BASE + B_SPM, SPM_BASE + A_SPM, min(ln, 0x8000) - 3, 3)         # spm -> spm
    await env.drain()
    env.spm_check(A_SPM, min(ln, 0x8000))
    env.spm_check(B_SPM, min(ln, 0x8000))
    await env.drain()
    end(env, length=ln)


@cocotb.test()
async def test_random_traffic(dut):
    """random descriptors (directions, lengths, a few invalid) with fabric back-pressure,
    scratchpad bank contention from the testbench port and completion back-pressure"""
    env = DmaEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("rand")
    env.spm_fill(r, 0, 0x2000)
    await env.drain()
    n = env_int("HPC_NDESC", 60)
    for t in range(n):
        sd, dd = r.choice(["ext", "spm"]), r.choice(["ext", "spm"])
        ln = r.choice([1, 2, 3, 4, 5, 7, 8, 63, 64, 65, r.randint(1, 600)])
        so = r.randrange(0, 0x1000, 4)
        do = r.randrange(0x1000, 0x2000 - 640, 4) if dd == "spm" else r.randrange(0x4000, 0x7000, 4)
        if sd == "ext":
            so = r.randrange(0x0000, 0x3000, 4)
        x = r.random()
        if x < 0.04:
            ln = 0
        elif x < 0.08:
            so += 2
        env.desc(addr(sd, so), addr(dd, do), ln, t)
        if r.random() < 0.5:                         # contention: random reads of known scratchpad words
            for _ in range(r.randint(1, 8)):
                env.spm_read(r.randrange(0, 0x1000, 4))
    await env.drain()
    env.spm_check(0x1000, 0x1000)
    await env.drain()
    end(env)


@cocotb.test()
async def test_invalid_descriptors(dut):
    """codes 1-7 and REGION, with err_addr; no bus access for any of them"""
    env = DmaEnv(dut, **stalls_from_env())
    await setup(dut, env)
    sb = env.spm_bytes
    cases = [(A_EXT, B_EXT, 0), (A_EXT, B_EXT, (1 << 16) + 1), (A_EXT + 1, B_EXT, 8), (A_EXT, B_EXT + 2, 8),
             (0xFFFFFFF0, B_EXT, 0x20), (A_EXT, 0xFFFFFFF8, 0x10), (A_EXT, A_EXT, 8), (A_EXT, A_EXT + 4, 8),
             (A_EXT + 8, A_EXT, 16), (A_EXT, SPM_BASE - 8, 16), (SPM_BASE + sb - 8, B_EXT, 16),
             (SPM_BASE - 4, SPM_BASE + 0x100, 8), (A_EXT, SPM_BASE + sb - 4, 8)]
    for t, (s, d, ln) in enumerate(cases):
        env.desc(s, d, ln, t)
    env.desc(A_EXT, B_EXT, 12, 99)                  # a valid one after the rejected ones
    await env.drain()
    want = {"ZERO_LENGTH", "LENGTH", "SRC_ALIGN", "DST_ALIGN", "SRC_OVERFLOW", "DST_OVERFLOW", "OVERLAP", "REGION"}
    missing = want - set(env.codes)
    if missing:
        env.eng.error(f"codes never produced: {missing}")
    end(env)


@cocotb.test()
async def test_bus_errors(dut):
    """read / write bus errors: code, failing address, acknowledged prefix, no side effect, nothing after"""
    env = DmaEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("buserr")
    env.spm_fill(r, A_SPM, 0x400)
    await env.drain()
    env.desc(ERR_BASE - 0x40, SPM_BASE + B_SPM, 0x80, 1)          # READ_BUS after 16 beats
    env.desc(SPM_BASE + A_SPM, ERR_BASE - 0x20, 0x60, 2)           # WRITE_BUS after 8 beats
    env.desc(SPM_BASE + A_SPM, ERR_BASE + 0x100, 0x10, 3)          # WRITE_BUS on the first beat
    env.desc(ERR_BASE, SPM_BASE + B_SPM + 0x200, 0x10, 4)          # READ_BUS on the first beat
    env.desc(A_EXT, SPM_BASE + B_SPM + 0x300, 0x40, 5)             # a good one afterwards
    await env.drain()
    env.spm_check(B_SPM, 0x400)
    await env.drain()
    end(env)


@cocotb.test()
async def test_abort(dut):
    """cmd_abort during long transfers: ABORTED with an acknowledged whole-beat prefix (or NONE if it raced the end)"""
    env = DmaEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("abort")
    env.spm_fill(r, A_SPM, 0x1000)
    await env.drain()
    aborted = 0
    for k in range(env_int("HPC_ABORTS", 6)):
        t = 10 + k
        env.abort_tolerant.add(t)
        sd = k % 2
        env.desc(SPM_BASE + A_SPM if sd else A_EXT + 0x100 * k, B_EXT + 0x1000 * (k % 4) if sd else SPM_BASE + B_SPM,
                 0x800, t)
        for _ in range(2000):
            await RisingEdge(dut.clk)
            if val(dut.active):
                break
        await ClockCycles(dut.clk, r.randint(5, 300))
        dut.cmd_abort.value = 1
        await RisingEdge(dut.clk)
        dut.cmd_abort.value = 0
        await env.drain()
        aborted += env.codes.get("ABORTED", 0)
    if env.codes.get("ABORTED", 0) == 0:
        env.eng.error("no transfer was ever aborted")
    env.spm_check(B_SPM, 0x800)
    await env.drain()
    end(env, aborted=env.codes.get("ABORTED", 0))


@cocotb.test()
async def test_reset(dut):
    """asynchronous reset during transfers: queued/active descriptors discarded, no stale completion,
    no request until a new descriptor; the next transfers are exact"""
    env = DmaEnv(dut, **stalls_from_env())
    await setup(dut, env)
    r = rng("reset")
    env.spm_fill(r, A_SPM, 0x800)
    await env.drain()
    for k in range(env_int("HPC_RESETS", 4)):
        for t in range(3):
            env.desc(SPM_BASE + A_SPM, B_EXT + 0x800 * t, 0x400, 30 + t)
        await ClockCycles(dut.clk, r.randint(20, 400))
        await FallingEdge(dut.clk)
        env.eng.in_reset = True
        dut.rst_n.value = 0
        await ReadOnly()
        if val(dut.cpl_valid) or val(dut.fab_req_valid) or val(dut.busy):
            env.eng.error("cpl_valid / fab_req_valid / busy high right after reset assertion")
        await FallingEdge(dut.clk)
        env.eng.reset_agents()
        env.pending.clear()
        env.counts.clear()
        env.reset_truth()                            # the adapter's counters are reset with it
        env.ext_exp = env.ext.copy()                 # interrupted writes may or may not have landed
        await ClockCycles(dut.clk, 2)
        await FallingEdge(dut.clk)
        dut.rst_n.value = 1
        env.eng.in_reset = False
        for _ in range(50):                           # A6: no request without a descriptor
            await RisingEdge(dut.clk)
            await ReadOnly()
            if val(dut.fab_req_valid) or val(dut.mon_spm_req_fire) or val(dut.cpl_valid):
                env.eng.error("request or completion after reset without a new descriptor")
                break
        await RisingEdge(dut.clk)
        env.snap = (env.fab.stats["reads"] + env.fab.stats["writes"] + env.spm_reqs,
                    env.fab.write_ack_count + env.spm_wr_acks)
    env.desc(SPM_BASE + A_SPM, B_EXT, 0x100, 77)
    env.desc(A_EXT, SPM_BASE + B_SPM, 0x101, 78)
    await env.drain()
    env.spm_check(B_SPM, 0x104)
    await env.drain()
    end(env)


@cocotb.test()
async def test_outstanding(dut):
    """slow fabric: multiple outstanding requests (buffered engine), FIFO never above FIFO_DEPTH"""
    env = DmaEnv(dut, fab_stall="random:0.5", fab_lat=(3, 12), cpl_stall="random:0.3", cmd_stall="none")
    await setup(dut, env)
    r = rng("out")
    env.spm_fill(r, A_SPM, 0x800)
    await env.drain()
    for t in range(4):
        env.desc(A_EXT + 0x400 * t, SPM_BASE + B_SPM + 0x200 * t, 0x200, t)
        env.desc(SPM_BASE + A_SPM + 0x200 * t, B_EXT + 0x400 * t, 0x1FD, 10 + t)
    await env.drain()
    C = env.C
    if C["ENGINE"] and C["MAX_OUT"] >= 2 and env.max_outstanding < 2:
        env.eng.error(f"buffered engine with MAX_OUT={C['MAX_OUT']} never had 2 requests outstanding")
    if C["ENGINE"] and env.max_fifo > C["FIFO_DEPTH"]:
        env.eng.error(f"FIFO level {env.max_fifo} > FIFO_DEPTH {C['FIFO_DEPTH']}")
    env.spm_check(B_SPM, 0x800)
    await env.drain()
    end(env)
