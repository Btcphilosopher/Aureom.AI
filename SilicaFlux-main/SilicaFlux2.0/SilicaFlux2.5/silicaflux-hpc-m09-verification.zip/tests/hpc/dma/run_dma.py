#!/usr/bin/env python3
"""DMA suite (hpc_dma_adapter, Module 05, with the real Module 04 scratchpad).
usage: run_dma.py [--matrix ci|nightly] [--sim verilator|icarus] [--config NAME] [--only SUBSTR] [--seed N]
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import cocorun, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "dma"
B = dict(ENGINE=0, FIFO_DEPTH=8, BURST=8, DUAL_PORT=0, MAX_OUT=2, CMD_DEPTH=2, CPL_DEPTH=2, FAB_SLICE=0,
         SPM_BANKS=4, SPM_RL=1, SPM_QD=0, SPM_BYTES=65536)
CONFIGS = {
    "simple": dict(B),
    "buffered_sp": dict(B, ENGINE=1, MAX_OUT=2),
    "buffered_dp_slice": dict(B, ENGINE=1, DUAL_PORT=1, MAX_OUT=4, FAB_SLICE=1, CMD_DEPTH=4, CPL_DEPTH=4),
    "buffered_sp_f2_b1": dict(B, ENGINE=1, FIFO_DEPTH=2, BURST=1, MAX_OUT=1, SPM_RL=2, SPM_QD=2),
    "buffered_dp_f16": dict(B, ENGINE=1, DUAL_PORT=1, FIFO_DEPTH=16, BURST=16, MAX_OUT=8, SPM_BANKS=2,
                            CMD_DEPTH=0, CPL_DEPTH=2),
    "simple_spm8_rl3": dict(B, SPM_BANKS=8, SPM_RL=3, CMD_DEPTH=8, CPL_DEPTH=8),
}
TESTS = ["test_lengths_all_directions", "test_long_transfers", "test_random_traffic", "test_invalid_descriptors",
         "test_bus_errors", "test_abort", "test_reset", "test_outstanding"]
MATRIX = {
    "ci": dict(configs=["simple", "buffered_sp", "buffered_dp_slice"], seeds=1, ndesc=50, long=4096,
               icarus_cfg=["simple"], icarus=["test_lengths_all_directions"]),
    "nightly": dict(configs=list(CONFIGS), seeds=3, ndesc=250, long=32768,
                    icarus_cfg=["simple", "buffered_dp_slice"], icarus=TESTS),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--sim", default=None, choices=["verilator", "icarus"])
    ap.add_argument("--only", default="")
    ap.add_argument("--config", action="append")
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    sim.ensure_rtl()
    srcs = FL.files("dma") + FL.files("df_checker") + FL.checker_files() + [HERE / "tb_dma_top.sv"]
    inc = FL.INCDIRS["dma"]
    defs = {d: 1 for d in FL.SIM_DEFINES["dma"]}
    print(f"== dma suite, matrix {a.matrix}")
    runs = []
    if a.sim in (None, "verilator"):
        runs += [(c, "verilator", [t for t in TESTS if a.only in t]) for c in (a.config or mx["configs"])]
    if a.sim in (None, "icarus"):
        runs += [(c, "icarus", [t for t in mx["icarus"] if a.only in t]) for c in (a.config or mx["icarus_cfg"])]
    for cfg, s, tests in runs:
        P = CONFIGS[cfg]
        if not tests:
            continue
        for si in range(mx["seeds"] if s == "verilator" else 1):
            seed = a.seed + si
            cocorun.run_suite(SUITE, cfg, toplevel="tb_dma_top", sources=srcs, test_module="test_dma", test_dir=HERE,
                              testcases=tests, parameters=P, defines=defs, includes=inc, sim=s, seed=seed,
                              env={**P, "HPC_NDESC": mx["ndesc"] if s == "verilator" else 15,
                                   "HPC_LONG_LEN": mx["long"] if s == "verilator" else 1024},
                              repro_hint=f"python3 tests/hpc/dma/run_dma.py --sim {{sim}} --config {cfg} "
                                         f"--only {{tc}} --seed {{seed}}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
