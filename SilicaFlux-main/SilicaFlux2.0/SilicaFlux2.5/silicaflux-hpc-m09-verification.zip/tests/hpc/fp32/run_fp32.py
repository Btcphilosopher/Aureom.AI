#!/usr/bin/env python3
"""FP32 arithmetic verification suite (brief §3).

DUTs: every Module 02 arithmetic unit used by the tile's lanes (hpc_fp32_add,
hpc_fp32_mul, hpc_fp32_fma, hpc_fp32_misc, hpc_int32_mul) and the Module 01
stand-alone FMA (fp32_fma), through fp32/rtl/fp32_units_top.sv.

Golden model: Berkeley SoftFloat-3e (RISCV) in-process, itself validated first
against an independent MPFR model and Module 02's exact model
(reference_models/fp32_crosscheck.py).  TestFloat-3e supplies case-generator
streams and, through testfloat_ver, a second, independent result checker.

Tests (one result record each):
  oracle_crosscheck              SoftFloat == MPFR == M02 model
  directed/<category>            exact, fma_single_rounding, nan, inf, signed_zero, subnormal,
                                 overflow, underflow, rounding, flags, compare_minmax, integer
  random/s<seed>                 corner-biased random, all ops, all modes, resets, M01 back-pressure
  fma_stress/s<seed>             FMA family only through M01 with heavy back-pressure and resets
  testfloat/<op>/<mode>          testfloat_gen stream -> DUT -> SoftFloat + TestFloat expectation
                                 + testfloat_ver on the DUT output
usage: run_fp32.py [--matrix ci|nightly] [--config NAME] [--only SUBSTR] [--seed-base N]
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

HPC = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import fpgen, results as R, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "fp32"
CONFIGS = {
    # LAT_* are Module 02 lane latency parameters, M01_PIPE the Module 01 PIPE_CFG
    "default": dict(LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, M01_PIPE="11110"),
    "minlat":  dict(LAT_FADD=2, LAT_FMUL=2, LAT_FMA=3, LAT_MISC=1, LAT_IMUL=1, M01_PIPE="00000"),
    "deep":    dict(LAT_FADD=5, LAT_FMUL=5, LAT_FMA=6, LAT_MISC=3, LAT_IMUL=3, M01_PIPE="11111"),
}
MATRIX = {
    "ci": dict(configs=["default"], crosscheck_n=200_000, random_seeds=3, random_n=1_000_000,
               fma_seeds=1, fma_n=500_000, tf_level=1, tf_ops2=["add", "sub", "mul"], tf_rms=[0, 1, 2, 3, 4],
               tf_fma_rms=[0, 1, 2, 3, 4], tf_cmp=["eq", "lt", "le"]),
    "nightly": dict(configs=["default", "minlat", "deep"], crosscheck_n=2_000_000, random_seeds=10,
                    random_n=10_000_000, fma_seeds=4, fma_n=5_000_000, tf_level=2,
                    tf_ops2=["add", "sub", "mul"], tf_rms=[0, 1, 2, 3, 4], tf_fma_rms=[0, 1, 2, 3, 4],
                    tf_cmp=["eq", "lt", "le"]),
}
TF_RM = {0: "-rnear_even", 1: "-rminMag", 2: "-rmin", 3: "-rmax", 4: "-rnear_maxMag"}
RMN = {0: "RNE", 1: "RTZ", 2: "RDN", 3: "RUP", 4: "RMM"}
OPCODE = {"add": 1, "sub": 2, "mul": 3, "mulAdd": 4, "eq": 10, "lt": 11, "le": 12}


def build(cfg: str, trace=False) -> Path:
    c = CONFIGS[cfg]
    sim.ensure_rtl()
    sim.ensure_ref()
    ref = sim.BUILD / "ref"
    defs = " ".join(f"-D{k}={v}" for k, v in c.items() if k.startswith("LAT"))
    return sim.verilator_cpp(
        f"fp32_units_{cfg}", "fp32_units_top",
        FL.files("lane") + FL.files("fp32_fma") + [HPC / "fp32/rtl/fp32_units_top.sv"],
        [HPC / "fp32/tb/tb_fp32_units.cpp"],
        params={**{k: v for k, v in c.items() if k.startswith("LAT")}, "M01_PIPE": f"5'b{c['M01_PIPE']}"},
        defines=["FP32_FMA_ASSERT"], cflags=f"-O2 {defs}",
        ldflags=f"{ref / 'hpcsf_shim.o'} {ref / 'softfloat_riscv.a'}", trace=trace)


def out_dir(cfg, name):
    d = sim.BUILD / "runs" / SUITE / cfg / name.replace("/", "_")
    d.mkdir(parents=True, exist_ok=True)
    return d


def run_harness(cfg, name, args, *, stdin_cmd=None, seed=None, extra_metrics=None, tfver=None):
    """Run the harness once; returns (rc, summary json)."""
    exe = build(cfg)
    d = out_dir(cfg, name)
    js = d / "summary.json"
    log = d / "run.log"
    argv = [exe] + args + ["--json", js]
    t0 = time.time()
    if stdin_cmd:
        with open(log, "w") as lf:
            lf.write("$ " + " ".join(map(str, stdin_cmd)) + " | " + " ".join(map(str, argv)) + "\n")
            lf.flush()
            g = subprocess.Popen([str(x) for x in stdin_cmd], stdout=subprocess.PIPE)
            r = subprocess.run([str(x) for x in argv], stdin=g.stdout, stdout=lf, stderr=subprocess.STDOUT)
            g.stdout.close()
            g.wait()
            rc = r.returncode
    else:
        rc = sim.run(argv, log=log)
    dt = time.time() - t0
    summ = json.loads(js.read_text()) if js.exists() else {}
    return rc, summ, dt, log, argv


def finish(cfg, name, rc, summ, dt, log, argv, *, seed=None, stdin_cmd=None, extra=None, checks=None):
    status = "PASS" if rc == 0 and summ.get("errors", 1) == 0 else "FAIL"
    waves = None
    repro = R.repro_cmd(([*map(str, stdin_cmd), "|"] if stdin_cmd else []) + [str(a) for a in argv
                                                                               if not str(a).endswith("summary.json")])
    if status == "FAIL" and not stdin_cmd:
        try:      # re-run the failing case with waveforms for debug
            exe_t = build(cfg, trace=True)
            waves = out_dir(cfg, name) / "waves.fst"
            targs = [a for a in argv[1:] if not str(a).endswith("summary.json")]
            targs = [a for i, a in enumerate(targs) if not (str(a) == "--json" or (i and str(targs[i - 1]) == "--json"))]
            sim.run([exe_t] + targs + ["--trace", waves, "--max-errors", "5"], log=out_dir(cfg, name) / "trace.log")
        except Exception as e:  # noqa: BLE001
            waves = f"waveform capture failed: {e}"
    m = {k: summ.get(k) for k in ("vectors", "errors", "resets", "discarded", "cycles", "tf_expect_checked",
                                  "skipped_illegal")}
    m["units"] = summ.get("units")
    m.update(extra or {})
    R.record(SUITE, f"{cfg}/{name}", status, seed=seed, config={"config": cfg, **CONFIGS[cfg]}, duration=dt,
             metrics=m, log=log, waves=waves, repro=repro, checks=checks, simulator="verilator")
    cov = out_dir(cfg, name) / "coverage.json"
    if summ.get("coverage"):
        cov.write_text(json.dumps(summ["coverage"]))
    print(f"  [{status}] {SUITE}/{cfg}/{name}  vectors={summ.get('vectors')} errors={summ.get('errors')} ({dt:.1f}s)")
    return status


def t_crosscheck(mx, base_seed):
    out = sim.BUILD / "runs/fp32/oracle_crosscheck.json"
    argv = [sys.executable, HPC / "reference_models/fp32_crosscheck.py", "--n", str(mx["crosscheck_n"]),
            "--seed", str(base_seed), "--out", out]
    t0 = time.time()
    rc = sim.run(argv, log=out.with_suffix(".log"))
    d = json.loads(out.read_text()) if out.exists() else {}
    st = "PASS" if rc == 0 and d.get("status") == "PASS" else "FAIL"
    R.record(SUITE, "oracle_crosscheck", st, seed=base_seed, duration=time.time() - t0,
             metrics={k: d.get(k) for k in ("vectors", "mismatches", "oracles", "fma_discriminating",
                                            "fma_discrimination_missing")},
             log=out.with_suffix(".log"), repro=R.repro_cmd(argv), simulator="python")
    print(f"  [{st}] fp32/oracle_crosscheck vectors={d.get('vectors')} mismatches={d.get('mismatches')}")


def t_directed(cfg):
    d = out_dir(cfg, "directed")
    vf = d / "directed.vec"
    vecs = fpgen.directed()
    with open(vf, "w") as f:
        f.write("# op rm a b c category  (generated by lib/hpcv/fpgen.py directed())\n")
        for (op, rm, a, b, c, cat) in vecs:
            f.write(f"{op:x} {rm} {a:08x} {b:08x} {c:08x} {cat}\n")
    rc, summ, dt, log, argv = run_harness(cfg, "directed", ["--src", "file", "--vec", vf, "--m01"])
    cats = summ.get("categories", {})
    for cat in fpgen.CATEGORIES:
        n_m02, e_m02 = cats.get(cat, [0, 0])
        n_m01, e_m01 = cats.get("m01:" + cat, [0, 0])
        if cat == "illegal_rm":
            # unit level: rm 5..7 is a lane-level illegal case (verified in vector_lane); M01 maps it to RNE
            st = "PASS" if (e_m01 == 0 and n_m01 > 0) else "FAIL"
        else:
            st = "PASS" if (e_m02 == 0 and e_m01 == 0 and n_m02 > 0) else "FAIL"
        R.record(SUITE, f"{cfg}/directed/{cat}", st, config={"config": cfg}, duration=dt,
                 metrics={"m02_checked": n_m02, "m02_errors": e_m02, "m01_checked": n_m01, "m01_errors": e_m01},
                 log=log, repro=R.repro_cmd([str(a) for a in argv]), simulator="verilator")
        print(f"  [{st}] fp32/{cfg}/directed/{cat}  m02={n_m02}/{e_m02} m01={n_m01}/{e_m01}")
    # errors not attributable to a category (latency, spurious / lost results, protocol, reset)
    cat_err = sum(v[1] for v in cats.values())
    other = (summ.get("errors", 1) if summ else 1) - cat_err
    st = "PASS" if summ and other == 0 else "FAIL"      # rc != 0 is expected when a category failed
    R.record(SUITE, f"{cfg}/directed/harness_checks", st, config={"config": cfg}, duration=dt,
             metrics={"non_category_errors": other, "units": summ.get("units")}, log=log,
             repro=R.repro_cmd([str(a) for a in argv]), simulator="verilator",
             reason=None if st == "PASS" else "latency / ordering / protocol / reset error in the directed run")
    print(f"  [{st}] fp32/{cfg}/directed/harness_checks  other errors={other}")
    cov = d / "coverage.json"
    if summ.get("coverage"):
        cov.write_text(json.dumps(summ["coverage"]))


def t_testfloat(cfg, op, rm, level):
    gen = [sim.BUILD / "ref/testfloat_gen", "-level", str(level), TF_RM[rm], "-tininessafter", f"f32_{op}"]
    name = f"testfloat/L{level}/{op}/{RMN[rm]}"
    d = out_dir(cfg, name)
    tfv = d / "dut_results.txt"
    args = ["--src", "tf", "--tf-op", op, "--rm", str(rm), "--tfver-out", tfv]
    if op == "mulAdd":
        args.append("--m01")
    rc, summ, dt, log, argv = run_harness(cfg, name, args, stdin_cmd=gen)
    # independent checker: testfloat_ver over the DUT's own outputs
    ver = [sim.BUILD / "ref/testfloat_ver", TF_RM[rm], "-tininessafter", "-checkNaNs", "-errors", "20", f"f32_{op}"]
    vlog = d / "testfloat_ver.log"
    with open(tfv, "rb") as fin:
        sim.run(ver, log=vlog, stdin=fin)
    vtxt = vlog.read_text()
    ver_ok = "no errors found" in vtxt.lower() or "0 errors found" in vtxt.lower()
    if not ver_ok and "errors found" not in vtxt.lower():
        ver_ok = False
    lines = sum(1 for _ in open(tfv))
    status = finish(cfg, name, rc if ver_ok else 1, summ, dt, log, argv, stdin_cmd=gen,
                    extra={"testfloat_ver": vtxt.strip().splitlines()[-1] if vtxt.strip() else "",
                           "testfloat_ver_lines": lines},
                    checks=["DUT vs SoftFloat shim", "TestFloat expectation vs shim", "testfloat_ver on DUT output"])
    return status


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--config", action="append", help="override the matrix configurations")
    ap.add_argument("--only", default="", help="run only tests whose name contains this")
    ap.add_argument("--seed-base", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    cfgs = a.config or mx["configs"]
    want = lambda n: a.only in n
    print(f"== FP32 suite, matrix {a.matrix}, configs {cfgs}")
    if want("oracle"):
        t_crosscheck(mx, a.seed_base)
    for cfg in cfgs:
        build(cfg)
        if want("directed"):
            t_directed(cfg)
        for i in range(mx["random_seeds"]):
            s = a.seed_base + i
            n = f"random/s{s}"
            if want(n):
                r = run_harness(cfg, n, ["--src", "random", "--n", str(mx["random_n"]), "--seed", str(s), "--m01",
                                         "--pout", "0.6", "--reset-every", "20000"])
                finish(cfg, n, *r, seed=s)
        for i in range(mx["fma_seeds"]):
            s = a.seed_base + 100 + i
            n = f"fma_stress/s{s}"
            if want(n):
                r = run_harness(cfg, n, ["--src", "random", "--n", str(mx["fma_n"]), "--seed", str(s), "--ops",
                                         "4,5,6,7", "--m01", "--pout", "0.35", "--reset-every", "3000"])
                finish(cfg, n, *r, seed=s)
        if cfg == cfgs[0] or a.matrix == "nightly":
            for op in mx["tf_ops2"]:
                for rm in mx["tf_rms"]:
                    if want(f"testfloat/L{mx['tf_level']}/{op}/{RMN[rm]}"):
                        t_testfloat(cfg, op, rm, mx["tf_level"])
            for rm in mx["tf_fma_rms"]:
                if want(f"testfloat/L1/mulAdd/{RMN[rm]}"):
                    t_testfloat(cfg, "mulAdd", rm, 1)
            for op in mx["tf_cmp"]:
                if want(f"testfloat/L{mx['tf_level']}/{op}"):
                    t_testfloat(cfg, op, 0, mx["tf_level"])
    return 0


if __name__ == "__main__":
    sys.exit(main())
