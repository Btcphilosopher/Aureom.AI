// =============================================================================
// SilicaFlux-HPC verification :: tb_fp32_units -- FP32 differential harness
//
// Drives fp32_units_top (all Module 02 FP/INT units + Module 01 fp32_fma) and
// compares every result bit-exactly (32 result bits incl. NaN encodings, the
// 5 IEEE flags, the transaction id) against Berkeley SoftFloat-3e linked
// in-process (reference_models/softfloat/hpcsf_shim.c, RISCV specialisation).
//
// Stimulus (--src):
//   random  --n N --seed S [--ops 1,2,3,...]  corner-biased random operands
//   file    --vec PATH                        "op rm a b c category" (hex op/a/b/c)
//   tf      --tf-op add|sub|mul|mulAdd|eq|lt|le --rm R   testfloat_gen lines on
//           stdin; the TestFloat-generated expected result/flags are checked too
// Options:
//   --m01            also run the FMA-family vectors through Module 01 fp32_fma
//   --m01-only       FMA-family vectors only to fp32_fma (TestFloat mulAdd runs)
//   --pout P         probability fp32_fma out_ready=1 per cycle (back-pressure)
//   --reset-every N  asynchronous reset at random points (mean N cycles);
//                    in-flight operations must be discarded, nothing stale emerges
//   --tfver-out F    write DUT results as testfloat_ver input (tf source only)
//   --json F         summary + functional-coverage counts
//   --trace F        FST waveform (binary built with HPC_TRACE=1)
// Checks:
//   * result / flags / id bit-exact vs SoftFloat (and vs TestFloat's own expectation)
//   * Module 02 units: exact fixed latency LAT, in-order, no spurious or lost result
//   * fp32_fma: valid/ready contract (payload stable while stalled, no valid drop),
//     in-order, tag match, no loss / duplication
//   * reset discards everything in flight; outputs low while in reset
// Exit 0 only if every check passed.  Last line of stdout: "TB_FP32_UNITS PASS|FAIL".
// =============================================================================
#include <cinttypes>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include "Vfp32_units_top.h"
#include "verilated.h"
#if VM_TRACE
#include "verilated_fst_c.h"
#endif

#ifndef LAT_FADD
#define LAT_FADD 3
#endif
#ifndef LAT_FMUL
#define LAT_FMUL 3
#endif
#ifndef LAT_FMA
#define LAT_FMA 4
#endif
#ifndef LAT_MISC
#define LAT_MISC 1
#endif
#ifndef LAT_IMUL
#define LAT_IMUL 2
#endif

extern "C" uint32_t hpcsf_op(unsigned op, unsigned rm, uint32_t a, uint32_t b, uint32_t c,
                             unsigned tininess_after, unsigned *flags, unsigned *illegal);

static const int UNIT_LAT[5] = {LAT_FADD, LAT_FMUL, LAT_FMA, LAT_MISC, LAT_IMUL};
static const char *UNIT_NAME[5] = {"hpc_fp32_add", "hpc_fp32_mul", "hpc_fp32_fma", "hpc_fp32_misc", "hpc_int32_mul"};

struct Rng {
  uint64_t s;
  explicit Rng(uint64_t seed) : s(seed * 0x9E3779B97F4A7C15ull + 1) {}
  uint64_t next() {
    uint64_t z = (s += 0x9E3779B97F4A7C15ull);
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
    return z ^ (z >> 31);
  }
  uint32_t u32() { return (uint32_t)next(); }
  uint32_t range(uint32_t n) { return (uint32_t)(next() % n); }
  double uni() { return (next() >> 11) * (1.0 / 9007199254740992.0); }
};

static const uint32_t SPECIALS[] = {
  0x00000000, 0x80000000, 0x3F800000, 0xBF800000, 0x7F800000, 0xFF800000, 0x7FC00000, 0xFFC00001,
  0x7FA00000, 0xFF800001, 0x7F7FFFFF, 0xFF7FFFFF, 0x00800000, 0x80800000, 0x007FFFFF, 0x00000001,
  0x80000001, 0x00400000, 0x3F7FFFFF, 0x3F800001, 0x7F000000, 0x01000000, 0x00800001, 0x7EFFFFFF};
static const int EXPS[] = {1, 2, 3, 23, 24, 25, 26, 100, 126, 127, 128, 150, 228, 252, 253, 254};

static uint32_t rand_operand(Rng &r) {
  double p = r.uni();
  uint32_t s = r.u32() & 0x80000000u;
  if (p < 0.10) return SPECIALS[r.range(sizeof(SPECIALS) / 4)];
  if (p < 0.22) return s | (1 + r.range((1u << 23) - 1));
  if (p < 0.40) return s | ((uint32_t)EXPS[r.range(16)] << 23) | (r.u32() & 0x7FFFFF);
  if (p < 0.52) {
    uint32_t k = r.range(24), frac = (r.uni() < 0.5) ? ((1u << k) - 1) : (0x7FFFFFu ^ ((1u << k) - 1));
    return s | ((1 + r.range(254)) << 23) | (frac & 0x7FFFFF);
  }
  if (p < 0.58) return s | 0x7F800000u | (1 + r.range((1u << 23) - 1));
  return r.u32();
}

// ------------------------------------------------------------- classification / coverage
static int fclass(uint32_t x) {  // 0 +zero 1 -zero 2 +sub 3 -sub 4 +norm 5 -norm 6 +inf 7 -inf 8 qnan 9 snan
  uint32_t e = (x >> 23) & 0xFF, f = x & 0x7FFFFF, s = x >> 31;
  if (e == 0xFF) return f ? ((f & 0x400000) ? 8 : 9) : 6 + s;
  if (e == 0) return f ? 2 + s : s;
  return 4 + s;
}
static const char *CLS[10] = {"+zero", "-zero", "+sub", "-sub", "+norm", "-norm", "+inf", "-inf", "qnan", "snan"};

struct Cov {
  uint64_t op_rm[32][8] = {};
  uint64_t op_flag[32][6] = {};    // NX UF OF DZ NV exact
  uint64_t op_cls[32][3][10] = {};
  uint64_t op_res[32][10] = {};
  void hit(unsigned op, unsigned rm, uint32_t a, uint32_t b, uint32_t c, uint32_t res, unsigned fl) {
    op &= 31;
    op_rm[op][rm & 7]++;
    if (!fl) op_flag[op][5]++;
    for (int i = 0; i < 5; i++) if (fl & (1u << i)) op_flag[op][i]++;
    op_cls[op][0][fclass(a)]++; op_cls[op][1][fclass(b)]++; op_cls[op][2][fclass(c)]++;
    op_res[op][fclass(res)]++;
  }
};

struct Vec { unsigned op, rm; uint32_t a, b, c; std::string cat; uint32_t tf_res; unsigned tf_fl; bool has_tf; };
struct Pend { Vec v; uint32_t exp; unsigned efl; uint64_t cyc; uint32_t id; };

static int unit_of(unsigned op) {
  if (op == 1 || op == 2) return 0;
  if (op == 3) return 1;
  if (op >= 4 && op <= 7) return 2;
  if (op == 0 || (op >= 8 && op <= 12) || op == 0x10) return 3;
  if (op == 0x11) return 4;
  return -1;
}

struct Stats { uint64_t checked = 0, errors = 0; };

template <typename W> static uint32_t bits(const W &w, int lsb, int width) {  // VlWide slice
  uint64_t lo = w[lsb / 32], hi = (lsb / 32 + 1 < (int)(sizeof(w) / 4)) ? w[lsb / 32 + 1] : 0;
  uint64_t v = ((hi << 32) | lo) >> (lsb % 32);
  return (uint32_t)(v & ((width >= 32) ? 0xFFFFFFFFull : ((1ull << width) - 1)));
}

int main(int argc, char **argv) {
  std::string src = "random", vecpath, tfop, tfver_out, json, trace;
  uint64_t n = 100000, seed = 1, reset_every = 0, max_err = 25;
  int tf_rm = 0;
  bool m01 = false, m01_only = false;
  double pout = 1.0;
  std::vector<unsigned> ops = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 0x10, 0x11};
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    auto nx = [&]() -> std::string { if (i + 1 >= argc) { fprintf(stderr, "missing value for %s\n", a.c_str()); exit(2); } return argv[++i]; };
    if (a == "--src") src = nx();
    else if (a == "--n") n = strtoull(nx().c_str(), 0, 0);
    else if (a == "--seed") seed = strtoull(nx().c_str(), 0, 0);
    else if (a == "--vec") vecpath = nx();
    else if (a == "--tf-op") tfop = nx();
    else if (a == "--rm") tf_rm = atoi(nx().c_str());
    else if (a == "--m01") m01 = true;
    else if (a == "--m01-only") { m01 = true; m01_only = true; }
    else if (a == "--pout") pout = atof(nx().c_str());
    else if (a == "--reset-every") reset_every = strtoull(nx().c_str(), 0, 0);
    else if (a == "--tfver-out") tfver_out = nx();
    else if (a == "--json") json = nx();
    else if (a == "--trace") trace = nx();
    else if (a == "--max-errors") max_err = strtoull(nx().c_str(), 0, 0);
    else if (a == "--ops") {
      ops.clear(); std::string s = nx(); size_t p = 0;
      while (p < s.size()) { size_t q = s.find(',', p); if (q == std::string::npos) q = s.size();
        ops.push_back((unsigned)strtoul(s.substr(p, q - p).c_str(), 0, 0)); p = q + 1; }
    } else if (a[0] == '+') { /* verilator plusargs */ }
    else { fprintf(stderr, "unknown option %s\n", a.c_str()); return 2; }
  }

  // ------------------------------------------------------------- stimulus
  Rng rng(seed);
  FILE *vf = nullptr;
  if (src == "file") { vf = fopen(vecpath.c_str(), "r"); if (!vf) { perror(vecpath.c_str()); return 2; } }
  unsigned tf_op = 0, tf_nops = 2;
  if (src == "tf") {
    if (tfop == "add") tf_op = 1; else if (tfop == "sub") tf_op = 2; else if (tfop == "mul") tf_op = 3;
    else if (tfop == "mulAdd") { tf_op = 4; tf_nops = 3; }
    else if (tfop == "eq") tf_op = 10; else if (tfop == "lt") tf_op = 11; else if (tfop == "le") tf_op = 12;
    else { fprintf(stderr, "bad --tf-op\n"); return 2; }
  }
  FILE *tfv = tfver_out.empty() ? nullptr : fopen(tfver_out.c_str(), "w");
  uint64_t produced = 0;
  auto next_vec = [&](Vec &v) -> bool {
    v.has_tf = false; v.cat = src;
    if (src == "random") {
      if (produced >= n) return false;
      v.op = ops[produced % ops.size()];
      v.rm = (unsigned)((produced / ops.size()) % 5);
      v.a = rand_operand(rng); v.b = rand_operand(rng); v.c = rand_operand(rng);
      produced++;
      return true;
    }
    char line[512];
    if (src == "file") {
      while (fgets(line, sizeof line, vf)) {
        char cat[128] = "file";
        unsigned op, rm, a, b, c;
        if (line[0] == '#') continue;
        if (sscanf(line, "%x %u %x %x %x %127s", &op, &rm, &a, &b, &c, cat) >= 5) {
          v.op = op; v.rm = rm; v.a = a; v.b = b; v.c = c; v.cat = cat; produced++; return true;
        }
      }
      return false;
    }
    while (fgets(line, sizeof line, stdin)) {  // testfloat_gen: A B [C] Z F
      unsigned x[5]; int k = sscanf(line, "%x %x %x %x %x", &x[0], &x[1], &x[2], &x[3], &x[4]);
      if (k < (int)tf_nops + 2) continue;
      v.op = tf_op; v.rm = (unsigned)tf_rm; v.a = x[0]; v.b = x[1];
      v.c = (tf_nops == 3) ? x[2] : 0;
      v.tf_res = x[tf_nops]; v.tf_fl = x[tf_nops + 1]; v.has_tf = true; v.cat = "testfloat_" + tfop;
      produced++;
      return true;
    }
    return false;
  };

  // ------------------------------------------------------------- DUT
  auto ctx = std::make_unique<VerilatedContext>();
  ctx->commandArgs(argc, argv);
  auto top = std::make_unique<Vfp32_units_top>(ctx.get());
#if VM_TRACE
  std::unique_ptr<VerilatedFstC> tfp;
  if (!trace.empty()) { ctx->traceEverOn(true); tfp = std::make_unique<VerilatedFstC>(); top->trace(tfp.get(), 99); tfp->open(trace.c_str()); }
#endif
  uint64_t cyc = 0;
  auto tick = [&]() {
    top->clk = 1; top->eval(); ctx->timeInc(5);
#if VM_TRACE
    if (tfp) tfp->dump(ctx->time());
#endif
    top->clk = 0; top->eval(); ctx->timeInc(5);
#if VM_TRACE
    if (tfp) tfp->dump(ctx->time());
#endif
    cyc++;
  };

  std::deque<Pend> pend[5], m01q, m01_inflight;
  std::map<std::string, Stats> per_cat;
  Stats st_unit[5], st_m01, st_tf;
  Cov cov;
  uint64_t errors = 0, resets = 0, discarded = 0, skipped_illegal = 0, lat_bad = 0, m01_stall_cycles = 0;
  int lat_min[5], lat_max[5];
  for (int u = 0; u < 5; u++) { lat_min[u] = 1 << 30; lat_max[u] = -1; }
  uint32_t seq = 0, m01seq = 0;
  auto err = [&](const char *fmt, auto... args) {
    errors++;
    if (errors <= max_err) { printf("ERROR cyc=%" PRIu64 ": ", cyc); printf(fmt, args...); printf("\n"); }
  };

  top->rst_n = 0; top->u_valid = 0; top->m_in_valid = 0; top->m_out_ready = 1; top->clk = 0;
  top->eval();
  for (int i = 0; i < 3; i++) tick();
  top->rst_n = 1; top->eval();
  tick();

  bool done = false, have_m01_hold = false;
  Pend m01_hold{};
  bool prev_mov = false; uint32_t prev_mres = 0; unsigned prev_mfl = 0, prev_mtag = 0;
  uint64_t next_reset = reset_every ? 1 + rng.range((uint32_t)(2 * reset_every)) : 0;

  while (true) {
    // ---------------------------------------------- optional reset injection
    if (reset_every && cyc >= next_reset) {
      top->rst_n = 0; top->u_valid = 0; top->m_in_valid = 0; top->eval();
      if (top->o_valid || top->m_out_valid) err("outputs not cleared by asynchronous reset");
      int k = 1 + (int)rng.range(3);
      for (int i = 0; i < k; i++) { tick(); if (top->o_valid || top->m_out_valid) err("output valid during reset"); }
      for (int u = 0; u < 5; u++) { discarded += pend[u].size(); pend[u].clear(); }
      discarded += m01_inflight.size(); m01_inflight.clear();
      if (have_m01_hold) { m01q.push_front(m01_hold); have_m01_hold = false; }  // not accepted: re-offer later
      prev_mov = false;
      top->rst_n = 1; top->eval();
      resets++;
      next_reset = cyc + 1 + rng.range((uint32_t)(2 * reset_every));
    }
    // ---------------------------------------------- drive the M02 unit stream
    top->u_valid = 0;
    bool backlog = m01q.size() > 64;
    if (!done && !backlog) {
      Vec v;
      if (!next_vec(v)) done = true;
      else {
        unsigned fl = 0, il = 0;
        uint32_t exp = hpcsf_op(v.op, v.rm, v.a, v.b, v.c, 1, &fl, &il);
        int u = unit_of(v.op);
        if (v.has_tf) {  // TestFloat's own expectation (its SoftFloat build) must equal the shim's
          st_tf.checked++;
          if (v.tf_res != exp || v.tf_fl != fl)
            err("oracle disagreement testfloat %08x/%02x shim %08x/%02x for %08x %08x %08x", v.tf_res, v.tf_fl, exp, fl, v.a, v.b, v.c);
        }
        bool fma_family = v.op >= 4 && v.op <= 7;
        if (m01 && fma_family) {  // M01 contract: rm 5..7 -> RNE; negated forms via negated inputs
          unsigned rm01 = v.rm > 4 ? 0 : v.rm, fl1 = 0, il1 = 0;
          uint32_t e1 = hpcsf_op(v.op, rm01, v.a, v.b, v.c, 1, &fl1, &il1);
          Pend p{v, e1, fl1, 0, (m01seq++) & 0xFFFF};
          m01q.push_back(p);
        }
        if (il || u < 0) skipped_illegal++;            // lane-level contract (illegal), not a unit operation
        else if (!m01_only || !fma_family) {
          top->u_valid = 1; top->u_op = v.op; top->u_rm = v.rm; top->u_a = v.a; top->u_b = v.b; top->u_c = v.c;
          top->u_id = seq & 0xFFFF;
          pend[u].push_back(Pend{v, exp, fl, cyc, seq & 0xFFFF});
          seq++;
          cov.hit(v.op, v.rm, v.a, v.b, v.c, exp, fl);
        }
      }
    }
    // ---------------------------------------------- drive the M01 stream
    if (!have_m01_hold && !m01q.empty()) { m01_hold = m01q.front(); m01q.pop_front(); have_m01_hold = true; }
    top->m_in_valid = have_m01_hold;
    if (have_m01_hold) {
      uint32_t a = m01_hold.v.a, c = m01_hold.v.c;
      if (m01_hold.v.op == 6 || m01_hold.v.op == 7) a ^= 0x80000000u;
      if (m01_hold.v.op == 5 || m01_hold.v.op == 7) c ^= 0x80000000u;
      top->m_in_a = a; top->m_in_b = m01_hold.v.b; top->m_in_c = c; top->m_in_rm = m01_hold.v.rm;
      top->m_in_tag = m01_hold.id;
    }
    top->m_out_ready = (pout >= 1.0 || rng.uni() < pout) ? 1 : 0;
    top->clk = 0; top->eval();
    // ---------------------------------------------- observe M02 outputs (pre-edge values)
    for (int u = 0; u < 5; u++) {
      if (!((top->o_valid >> u) & 1)) continue;
      uint32_t id = bits(top->o_id, 16 * u, 16);
      uint32_t res = (uint32_t)(top->o_res[u]);
      unsigned fl = (unsigned)((top->o_flags >> (5 * u)) & 0x1F);
      if (pend[u].empty()) { err("%s: spurious result id=%u", UNIT_NAME[u], id); continue; }
      Pend p = pend[u].front(); pend[u].pop_front();
      int lat = (int)(cyc - p.cyc);
      if (lat < lat_min[u]) lat_min[u] = lat;
      if (lat > lat_max[u]) lat_max[u] = lat;
      // Module 02 counts LAT from the lane's issue register (docs/MICROARCHITECTURE.md §4,
      // hpc_fp32_misc.sv "LAT-1 output registers"): the unit boundary delay is LAT-1 cycles.
      if (lat != UNIT_LAT[u] - 1) { lat_bad++; err("%s: unit delay %d, expected LAT-1=%d", UNIT_NAME[u], lat, UNIT_LAT[u] - 1); }
      st_unit[u].checked++;
      Stats &sc = per_cat[p.v.cat]; sc.checked++;
      if (id != p.id || res != p.exp || fl != p.efl) {
        st_unit[u].errors++; sc.errors++;
        err("%s op=%02x rm=%u a=%08x b=%08x c=%08x: dut %08x/%02x id %u, softfloat %08x/%02x id %u [%s]",
            UNIT_NAME[u], p.v.op, p.v.rm, p.v.a, p.v.b, p.v.c, res, fl, id, p.exp, p.efl, p.id, p.v.cat.c_str());
      }
      if (tfv && p.v.has_tf) {
        if (tf_nops == 3) fprintf(tfv, "%08X %08X %08X %08X %02X\n", p.v.a, p.v.b, p.v.c, res, fl);
        else fprintf(tfv, "%08X %08X %0*X %02X\n", p.v.a, p.v.b, (p.v.op >= 10) ? 1 : 8, res, fl);
      }
    }
    // ---------------------------------------------- M01 handshake (pre-edge)
    bool acc_in = top->m_in_valid && top->m_in_ready;
    bool mov = top->m_out_valid, acc_out = mov && top->m_out_ready;
    if (prev_mov) {  // previous cycle presented without handshake: must still be presented, unchanged
      if (!mov) err("fp32_fma: out_valid dropped without handshake");
      else if (top->m_out_result != prev_mres || top->m_out_flags != prev_mfl || top->m_out_tag != prev_mtag)
        err("fp32_fma: payload changed while stalled");
    }
    if (top->m_in_valid && !top->m_in_ready) m01_stall_cycles++;
    if (acc_out) {
      if (m01_inflight.empty()) err("fp32_fma: unsolicited result tag=%u", (unsigned)top->m_out_tag);
      else {
        Pend p = m01_inflight.front(); m01_inflight.pop_front();
        st_m01.checked++;
        Stats &sc = per_cat["m01:" + p.v.cat]; sc.checked++;
        if (top->m_out_tag != p.id || top->m_out_result != p.exp || top->m_out_flags != p.efl) {
          st_m01.errors++; sc.errors++;
          err("fp32_fma op=%02x rm=%u a=%08x b=%08x c=%08x: dut %08x/%02x tag %u, softfloat %08x/%02x tag %u [%s]",
              p.v.op, p.v.rm, p.v.a, p.v.b, p.v.c, (unsigned)top->m_out_result, (unsigned)top->m_out_flags,
              (unsigned)top->m_out_tag, p.exp, p.efl, p.id, p.v.cat.c_str());
        }
        if (tfv && m01_only && p.v.has_tf)
          fprintf(tfv, "%08X %08X %08X %08X %02X\n", p.v.a, p.v.b, p.v.c, (unsigned)top->m_out_result,
                  (unsigned)top->m_out_flags);
      }
    }
    prev_mov = mov && !acc_out;
    prev_mres = top->m_out_result; prev_mfl = top->m_out_flags; prev_mtag = top->m_out_tag;
    if (acc_in) { m01_inflight.push_back(m01_hold); have_m01_hold = false; }
    tick();
    bool idle = done && !have_m01_hold && m01q.empty() && m01_inflight.empty();
    for (int u = 0; u < 5; u++) idle = idle && pend[u].empty();
    if (idle) break;
    if (done && cyc > produced * 4 + 100000) { err("timeout: results lost (pending results never delivered)"); break; }
  }
  for (int i = 0; i < 16; i++) {  // nothing may appear after the drain
    top->clk = 0; top->eval();
    if (top->o_valid || top->m_out_valid) err("spurious output after drain");
    tick();
  }
#if VM_TRACE
  if (tfp) tfp->close();
#endif
  if (tfv) fclose(tfv);

  uint64_t checked = 0;
  for (int u = 0; u < 5; u++) checked += st_unit[u].checked;
  printf("vectors=%" PRIu64 " checked_m02=%" PRIu64 " checked_m01=%" PRIu64 " tf_expect_checked=%" PRIu64
         " skipped_illegal=%" PRIu64 " resets=%" PRIu64 " discarded=%" PRIu64 " cycles=%" PRIu64 " errors=%" PRIu64 "\n",
         produced, checked, st_m01.checked, st_tf.checked, skipped_illegal, resets, discarded, cyc, errors);
  for (int u = 0; u < 5; u++)
    if (st_unit[u].checked)
      printf("  %-14s checked=%" PRIu64 " errors=%" PRIu64 " unit_delay=%d..%d (LAT=%d)\n", UNIT_NAME[u],
             st_unit[u].checked, st_unit[u].errors, lat_min[u], lat_max[u], UNIT_LAT[u]);
  if (st_m01.checked) printf("  %-14s checked=%" PRIu64 " errors=%" PRIu64 " in_stall_cycles=%" PRIu64 "\n", "fp32_fma(M01)",
                             st_m01.checked, st_m01.errors, m01_stall_cycles);
  if (!json.empty()) {
    FILE *j = fopen(json.c_str(), "w");
    fprintf(j, "{\n \"src\": \"%s\", \"seed\": %" PRIu64 ", \"vectors\": %" PRIu64 ", \"errors\": %" PRIu64
            ", \"resets\": %" PRIu64 ", \"discarded\": %" PRIu64 ", \"cycles\": %" PRIu64 ", \"skipped_illegal\": %" PRIu64
            ", \"tf_expect_checked\": %" PRIu64 ",\n", src.c_str(), seed, produced, errors, resets, discarded, cyc,
            skipped_illegal, st_tf.checked);
    fprintf(j, " \"units\": {");
    bool first = true;
    for (int u = 0; u < 5; u++) {
      if (!st_unit[u].checked) continue;
      fprintf(j, "%s\"%s\": {\"checked\": %" PRIu64 ", \"errors\": %" PRIu64 ", \"lat_min\": %d, \"lat_max\": %d, \"lat_param\": %d}",
              first ? "" : ", ", UNIT_NAME[u], st_unit[u].checked, st_unit[u].errors, lat_min[u], lat_max[u], UNIT_LAT[u]);
      first = false;
    }
    if (st_m01.checked) fprintf(j, "%s\"fp32_fma\": {\"checked\": %" PRIu64 ", \"errors\": %" PRIu64 "}", first ? "" : ", ", st_m01.checked, st_m01.errors);
    fprintf(j, "},\n \"categories\": {");
    first = true;
    for (auto &kv : per_cat) { fprintf(j, "%s\"%s\": [%" PRIu64 ", %" PRIu64 "]", first ? "" : ", ", kv.first.c_str(), kv.second.checked, kv.second.errors); first = false; }
    fprintf(j, "},\n \"coverage\": {\"op_rm\": {");
    first = true;
    for (int op = 0; op < 32; op++) {
      uint64_t t = 0; for (int r = 0; r < 8; r++) t += cov.op_rm[op][r];
      if (!t) continue;
      fprintf(j, "%s\"%d\": [", first ? "" : ", ", op); first = false;
      for (int r = 0; r < 8; r++) fprintf(j, "%s%" PRIu64, r ? ", " : "", cov.op_rm[op][r]);
      fprintf(j, "]");
    }
    fprintf(j, "}, \"op_flag\": {");
    first = true;
    for (int op = 0; op < 32; op++) {
      uint64_t t = 0; for (int r = 0; r < 8; r++) t += cov.op_rm[op][r];
      if (!t) continue;
      fprintf(j, "%s\"%d\": [", first ? "" : ", ", op); first = false;
      for (int k = 0; k < 6; k++) fprintf(j, "%s%" PRIu64, k ? ", " : "", cov.op_flag[op][k]);
      fprintf(j, "]");
    }
    fprintf(j, "}, \"op_cls\": {");
    first = true;
    for (int op = 0; op < 32; op++) {
      uint64_t t = 0; for (int r = 0; r < 8; r++) t += cov.op_rm[op][r];
      if (!t) continue;
      fprintf(j, "%s\"%d\": [", first ? "" : ", ", op); first = false;
      for (int p = 0; p < 3; p++) { fprintf(j, "%s[", p ? ", " : ""); for (int k = 0; k < 10; k++) fprintf(j, "%s%" PRIu64, k ? ", " : "", cov.op_cls[op][p][k]); fprintf(j, "]"); }
      fprintf(j, "]");
    }
    fprintf(j, "}, \"op_res\": {");
    first = true;
    for (int op = 0; op < 32; op++) {
      uint64_t t = 0; for (int r = 0; r < 8; r++) t += cov.op_rm[op][r];
      if (!t) continue;
      fprintf(j, "%s\"%d\": [", first ? "" : ", ", op); first = false;
      for (int k = 0; k < 10; k++) fprintf(j, "%s%" PRIu64, k ? ", " : "", cov.op_res[op][k]);
      fprintf(j, "]");
    }
    fprintf(j, "}, \"classes\": [");
    for (int k = 0; k < 10; k++) fprintf(j, "%s\"%s\"", k ? ", " : "", CLS[k]);
    fprintf(j, "]}\n}\n");
    fclose(j);
  }
  bool pass = errors == 0 && produced > 0;
  printf("TB_FP32_UNITS %s\n", pass ? "PASS" : "FAIL");
  top->final();
  return pass ? 0 : 1;
}
