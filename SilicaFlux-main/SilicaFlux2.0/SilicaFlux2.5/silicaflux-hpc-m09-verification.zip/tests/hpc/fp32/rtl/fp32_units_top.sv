// =============================================================================
// SilicaFlux-HPC verification :: fp32_units_top -- FP32 unit-level DUT wrapper
//
// Instantiates, unmodified, every FP32/INT32 arithmetic unit of the compute
// tile so one high-volume C++ harness (fp32/tb/tb_fp32_units.cpp) can compare
// each of them against Berkeley SoftFloat-3e:
//   Module 02 (used by every lane of the tile):
//     hpc_fp32_add  (FADD/FSUB)        hpc_fp32_mul (FMUL)
//     hpc_fp32_fma  (FMADD/FMSUB/FNMSUB/FNMADD)
//     hpc_fp32_misc (FMV/FMIN/FMAX/FEQ/FLT/FLE/IADD)   hpc_int32_mul (IMUL)
//   Module 01 (stand-alone FMA engine, independent implementation):
//     fp32_fma (a*b+c; the negated forms are formed by negating the inputs,
//               exactly as the RISC-V definition and the lane do)
// The Module 02 units are non-stallable fixed-latency pipelines (valid only);
// fp32_fma has a valid/ready interface and is driven on its own stream.
// Nothing here alters any unit; this file is verification glue only.
// =============================================================================
`default_nettype none

module fp32_units_top #(
  parameter int       LAT_FADD = 3,
  parameter int       LAT_FMUL = 3,
  parameter int       LAT_FMA  = 4,
  parameter int       LAT_MISC = 1,
  parameter int       LAT_IMUL = 2,
  parameter bit [4:0] M01_PIPE = 5'b11110,
  parameter int       IDW      = 16
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // ---------------------------------------------- Module 02 unit stream
  input  wire logic            u_valid,
  input  wire logic [4:0]      u_op,
  input  wire logic [2:0]      u_rm,
  input  wire logic [31:0]     u_a, u_b, u_c,
  input  wire logic [IDW-1:0]  u_id,
  output logic [4:0]           o_valid,            // {imul, misc, fma, mul, add}
  output logic [5*IDW-1:0]     o_id,
  output logic [5*32-1:0]      o_res,
  output logic [5*5-1:0]       o_flags,
  // ---------------------------------------------- Module 01 fp32_fma stream
  input  wire logic            m_in_valid,
  output logic                 m_in_ready,
  input  wire logic [31:0]     m_in_a, m_in_b, m_in_c,
  input  wire logic [2:0]      m_in_rm,
  input  wire logic [IDW-1:0]  m_in_tag,
  output logic                 m_out_valid,
  input  wire logic            m_out_ready,
  output logic [31:0]          m_out_result,
  output logic [4:0]           m_out_flags,
  output logic [IDW-1:0]       m_out_tag
);
  import hpc_vector_pkg::*;

  wire logic v_add  = u_valid && (u_op == OP_FADD || u_op == OP_FSUB);
  wire logic v_mul  = u_valid && (u_op == OP_FMUL);
  wire logic v_fma  = u_valid && (u_op >= OP_FMADD && u_op <= OP_FNMADD);
  wire logic v_imul = u_valid && (u_op == OP_IMUL);
  logic            v_misc;
  logic [MOP_W-1:0] mop;
  always_comb begin
    v_misc = u_valid;
    unique case (u_op)
      OP_FMV:  mop = MOP_FMV;
      OP_FMIN: mop = MOP_FMIN;
      OP_FMAX: mop = MOP_FMAX;
      OP_FEQ:  mop = MOP_FEQ;
      OP_FLT:  mop = MOP_FLT;
      OP_FLE:  mop = MOP_FLE;
      OP_IADD: mop = MOP_IADD;
      default: begin mop = MOP_FMV; v_misc = 1'b0; end
    endcase
  end

  hpc_fp32_add #(.LAT(LAT_FADD), .IDW(IDW)) u_add (
    .clk_i(clk), .rst_ni(rst_n), .valid_i(v_add), .id_i(u_id), .a_i(u_a), .b_i(u_b),
    .sub_i(u_op == OP_FSUB), .rm_i(u_rm),
    .valid_o(o_valid[0]), .id_o(o_id[0*IDW +: IDW]), .res_o(o_res[0*32 +: 32]), .flags_o(o_flags[0*5 +: 5]));
  hpc_fp32_mul #(.LAT(LAT_FMUL), .IDW(IDW)) u_mul (
    .clk_i(clk), .rst_ni(rst_n), .valid_i(v_mul), .id_i(u_id), .a_i(u_a), .b_i(u_b), .rm_i(u_rm),
    .valid_o(o_valid[1]), .id_o(o_id[1*IDW +: IDW]), .res_o(o_res[1*32 +: 32]), .flags_o(o_flags[1*5 +: 5]));
  hpc_fp32_fma #(.LAT(LAT_FMA), .IDW(IDW)) u_fma (
    .clk_i(clk), .rst_ni(rst_n), .valid_i(v_fma), .id_i(u_id), .a_i(u_a), .b_i(u_b), .c_i(u_c),
    .neg_prod_i(u_op == OP_FNMSUB || u_op == OP_FNMADD), .neg_add_i(u_op == OP_FMSUB || u_op == OP_FNMADD),
    .rm_i(u_rm),
    .valid_o(o_valid[2]), .id_o(o_id[2*IDW +: IDW]), .res_o(o_res[2*32 +: 32]), .flags_o(o_flags[2*5 +: 5]));
  hpc_fp32_misc #(.LAT(LAT_MISC), .IDW(IDW), .EN_FCMP(1'b1), .EN_INT(1'b1)) u_misc (
    .clk_i(clk), .rst_ni(rst_n), .valid_i(v_misc), .id_i(u_id), .mop_i(mop), .a_i(u_a), .b_i(u_b),
    .valid_o(o_valid[3]), .id_o(o_id[3*IDW +: IDW]), .res_o(o_res[3*32 +: 32]), .flags_o(o_flags[3*5 +: 5]));
  hpc_int32_mul #(.LAT(LAT_IMUL), .IDW(IDW)) u_imul (
    .clk_i(clk), .rst_ni(rst_n), .valid_i(v_imul), .id_i(u_id), .a_i(u_a), .b_i(u_b),
    .valid_o(o_valid[4]), .id_o(o_id[4*IDW +: IDW]), .res_o(o_res[4*32 +: 32]), .flags_o(o_flags[4*5 +: 5]));

  fp32_fma #(.TAG_W(IDW), .PIPE_CFG(M01_PIPE), .NAN_PROPAGATE(1'b0), .TININESS_AFTER_ROUNDING(1'b1)) u_m01 (
    .clk, .rst_n,
    .in_valid(m_in_valid), .in_ready(m_in_ready), .in_a(m_in_a), .in_b(m_in_b), .in_c(m_in_c),
    .in_rm(m_in_rm), .in_tag(m_in_tag),
    .out_valid(m_out_valid), .out_ready(m_out_ready), .out_result(m_out_result), .out_flags(m_out_flags),
    .out_tag(m_out_tag));
endmodule
`default_nettype wire
