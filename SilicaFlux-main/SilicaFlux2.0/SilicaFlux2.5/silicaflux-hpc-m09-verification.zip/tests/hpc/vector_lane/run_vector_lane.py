#!/usr/bin/env python3
"""Vector-lane suite (hpc_vector_lane, Module 02): protocol + arithmetic in context.

usage: run_vector_lane.py [--matrix ci|nightly] [--sim verilator|icarus] [--only SUBSTR] [--seed N]
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import cocorun, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "vector_lane"
CONFIGS = {
    "default": dict(ROB_DEPTH=8, LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, EN_FCMP=1, EN_INT=1),
    "minlat_rob2": dict(ROB_DEPTH=2, LAT_FADD=2, LAT_FMUL=2, LAT_FMA=3, LAT_MISC=1, LAT_IMUL=1, EN_FCMP=1, EN_INT=1),
    "rob1": dict(ROB_DEPTH=1, LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, EN_FCMP=1, EN_INT=1),
    "deep_lean": dict(ROB_DEPTH=12, LAT_FADD=5, LAT_FMUL=5, LAT_FMA=7, LAT_MISC=3, LAT_IMUL=4, EN_FCMP=0, EN_INT=0),
}
TESTS = ["test_stream", "test_rob_full", "test_reset_midstream", "test_illegal_space", "test_latency_throughput"]
MATRIX = {
    "ci": dict(configs=["default", "minlat_rob2"], seeds=1, n=2500,
               stalls=[("random:0.7", "random:0.6")], icarus=["test_stream"]),
    "nightly": dict(configs=list(CONFIGS), seeds=3, n=8000,
                    stalls=[("none", "none"), ("random:0.7", "random:0.6"), ("bursty", "bursty"),
                            ("starve", "random:0.9"), ("random:0.9", "random:0.15")],
                    icarus=TESTS),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--sim", default=None, choices=["verilator", "icarus"])
    ap.add_argument("--only", default="")
    ap.add_argument("--config", action="append")
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    sim.ensure_rtl()
    sim.ensure_ref()
    srcs = FL.files("lane") + FL.checker_files() + [HERE / "tb_lane_top.sv"]
    sims = [a.sim] if a.sim else ["verilator", "icarus"]
    print(f"== vector_lane suite, matrix {a.matrix}")
    for cfg in (a.config or mx["configs"]):
        P = CONFIGS[cfg]
        for s in sims:
            tests = [t for t in TESTS if a.only in t]
            if s == "icarus":
                tests = [t for t in tests if t in mx["icarus"]]
                if cfg != mx["configs"][0] and a.matrix == "ci":
                    continue
            for si in range(mx["seeds"]):
                seed = a.seed + si
                for k, (ins, outs) in enumerate(mx["stalls"]):
                    tl = tests if k == 0 else [t for t in tests if t in ("test_stream", "test_reset_midstream")]
                    if not tl:
                        continue
                    name = cfg if k == 0 else f"{cfg}+{ins}/{outs}".replace(":", "")
                    cocorun.run_suite(
                        SUITE, name, toplevel="tb_lane_top", sources=srcs, test_module="test_vector_lane",
                        test_dir=HERE, testcases=tl, parameters=P, sim=s, seed=seed,
                        env={**{k2: v for k2, v in P.items()}, "HPC_N": mx["n"] if s == "verilator" else mx["n"] // 4,
                             "HPC_IN_STALL": ins, "HPC_OUT_STALL": outs},
                        config={"in_stall": ins, "out_stall": outs},
                        repro_hint=f"python3 tests/hpc/vector_lane/run_vector_lane.py --sim {{sim}} --config {cfg} "
                                   f"--only {{tc}} --seed {{seed}}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
