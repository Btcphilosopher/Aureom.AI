// =============================================================================
// SilicaFlux-HPC verification :: tb_lane_top -- cocotb wrapper for hpc_vector_lane
// The DUT (Module 02, unmodified) plus the framework's protocol checkers:
//   chk_in   input channel  (checks the testbench's own producer contract)
//   chk_out  result channel (DUT obligation: stable while stalled, low in reset)
//   cons     every accepted ENABLED operation produces exactly one result;
//            outstanding never exceeds ROB_DEPTH
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
module tb_lane_top #(
  parameter int ROB_DEPTH = 8,
  parameter int LAT_FADD  = 3,
  parameter int LAT_FMUL  = 3,
  parameter int LAT_FMA   = 4,
  parameter int LAT_MISC  = 1,
  parameter int LAT_IMUL  = 2,
  parameter bit EN_FCMP   = 1'b1,
  parameter bit EN_INT    = 1'b1,
  parameter int TAG_W     = 8
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             in_valid,
  output logic                  in_ready,
  input  wire logic [4:0]       in_op,
  input  wire logic [31:0]      in_a, in_b, in_c,
  input  wire logic [2:0]       in_rm,
  input  wire logic [TAG_W-1:0] in_tag,
  input  wire logic             lane_en,
  output logic                  out_valid,
  input  wire logic             out_ready,
  output logic [31:0]           out_result,
  output logic [4:0]            out_flags,
  output logic [TAG_W-1:0]      out_tag,
  output logic                  out_illegal,
  output logic                  busy,
  output logic                  ev_accept, ev_retire, ev_pipe_stall, ev_backpressure, ev_illegal, ev_masked,
  output logic [31:0]           chk_in_err, chk_out_err, cons_err, cons_outstanding
);
  hpc_vector_lane #(.DATA_W(32), .TAG_W(TAG_W), .ROB_DEPTH(ROB_DEPTH), .LAT_FADD(LAT_FADD), .LAT_FMUL(LAT_FMUL),
                    .LAT_FMA(LAT_FMA), .LAT_MISC(LAT_MISC), .LAT_IMUL(LAT_IMUL), .EN_FCMP(EN_FCMP),
                    .EN_INT(EN_INT)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .in_valid_i(in_valid), .in_ready_o(in_ready), .in_op_i(in_op), .in_a_i(in_a), .in_b_i(in_b), .in_c_i(in_c),
    .in_rm_i(in_rm), .in_tag_i(in_tag), .lane_en_i(lane_en),
    .out_valid_o(out_valid), .out_ready_i(out_ready), .out_result_o(out_result), .out_flags_o(out_flags),
    .out_tag_o(out_tag), .out_illegal_o(out_illegal), .busy_o(busy),
    .ev_accept_o(ev_accept), .ev_retire_o(ev_retire), .ev_pipe_stall_o(ev_pipe_stall),
    .ev_backpressure_o(ev_backpressure), .ev_illegal_o(ev_illegal), .ev_masked_o(ev_masked));

  logic [31:0] x0, x1, x2, x3, x4;
  hpc_rv_checker #(.NAME("lane_in"), .W(5 + 96 + 3 + TAG_W + 1), .STABLE(1'b1), .RESET_LOW(1'b0)) chk_in (
    .clk, .rst_n, .valid(in_valid), .ready(in_ready), .payload({in_op, in_a, in_b, in_c, in_rm, in_tag, lane_en}),
    .err_cnt(chk_in_err), .xfer_cnt(x0));
  hpc_rv_checker #(.NAME("lane_out"), .W(32 + 5 + TAG_W + 1), .STABLE(1'b1), .RESET_LOW(1'b1), .INIT_CYCLE(1'b1)) chk_out (
    .clk, .rst_n, .valid(out_valid), .ready(out_ready), .payload({out_result, out_flags, out_tag, out_illegal}),
    .err_cnt(chk_out_err), .xfer_cnt(x1));
  hpc_txn_conservation #(.NAME("lane"), .MAX_OUT(ROB_DEPTH)) cons (
    .clk, .rst_n, .acc(in_valid && in_ready && lane_en), .cpl(out_valid && out_ready),
    .outstanding(cons_outstanding), .err_cnt(cons_err), .acc_total(x2), .cpl_total(x3));
endmodule
`default_nettype wire
