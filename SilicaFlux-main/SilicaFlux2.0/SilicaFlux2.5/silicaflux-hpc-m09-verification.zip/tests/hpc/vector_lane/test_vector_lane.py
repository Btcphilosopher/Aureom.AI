"""cocotb tests for hpc_vector_lane (Module 02) through tb_lane_top.

Every enabled operation accepted by the lane is predicted by Berkeley
SoftFloat-3e (reference_models/fp32_softfloat.py); the in-order scoreboard
compares result, flags, tag and illegal for every retirement.  The six event
pulses are checked against their documented definitions every cycle, busy_o
against the scoreboard, and the payload-zero rule while out_valid is low.

Environment (set by run_vector_lane.py): HPC_SEED, HPC_N, HPC_IN_STALL,
HPC_OUT_STALL, HPC_EN_P (lane_en probability), LAT_* / ROB_DEPTH / EN_FCMP /
EN_INT (DUT parameters, for the model).
"""
from __future__ import annotations

import cocotb
from cocotb.triggers import ClockCycles, FallingEdge, ReadOnly, RisingEdge

from hpcv import fpgen
from hpcv.cycle import Engine, Sink, Source, reset_dut, val
from hpcv.scoreboard import InOrderScoreboard
from hpcv.stall import Stall
from hpcv.tbutil import env_int, env_str, finish, publish, rng, seed, start_clock
from reference_models import fp32_softfloat as SF

FCMP = {0x08, 0x09, 0x0A, 0x0B, 0x0C}
INT = {0x10, 0x11}
CHK = ["chk_in_err", "chk_out_err", "cons_err"]


def cfg():
    return dict(ROB=env_int("ROB_DEPTH", 8), LAT_FADD=env_int("LAT_FADD", 3), LAT_FMUL=env_int("LAT_FMUL", 3),
                LAT_FMA=env_int("LAT_FMA", 4), LAT_MISC=env_int("LAT_MISC", 1), LAT_IMUL=env_int("LAT_IMUL", 2),
                EN_FCMP=env_int("EN_FCMP", 1), EN_INT=env_int("EN_INT", 1))


def model(op, rm, a, b, c, C):
    """expected (result, flags, illegal) of one ENABLED operation."""
    if (op in FCMP and not C["EN_FCMP"]) or (op in INT and not C["EN_INT"]):
        return 0, 0, 1
    r, f, il = SF.op(op, rm, a, b, c)
    return (0, 0, 1) if il else (r, f, 0)


def unit_lat(op, C):
    if op in (1, 2):
        return C["LAT_FADD"]
    if op == 3:
        return C["LAT_FMUL"]
    if 4 <= op <= 7:
        return C["LAT_FMA"]
    if op == 0x11:
        return C["LAT_IMUL"]
    return C["LAT_MISC"]


def rand_op(r, illegal_p=0.04):
    if r.random() < illegal_p:
        return r.choice([0x0D, 0x0E, 0x0F, 0x12, 0x13, 0x1F, 0x15])
    return r.choice(SF.LEGAL_OPS)


class LaneEnv:
    def __init__(self, dut, in_stall="none", out_stall="none", tag_w=8):
        self.dut = dut
        self.C = cfg()
        self.eng = Engine(dut)
        self.sb = InOrderScoreboard("lane", self.eng, fmt=lambda x: "res=%08x fl=%02x tag=%d ill=%d" % x)
        self.src = self.eng.add(Source(dut, "in_valid", "in_ready",
                                       {"op": "in_op", "a": "in_a", "b": "in_b", "c": "in_c", "rm": "in_rm",
                                        "tag": "in_tag", "en": "lane_en"},
                                       stall=Stall(in_stall, seed()), on_accept=self.accepted, name="lane_in"))
        self.snk = self.eng.add(Sink(dut, "out_valid", "out_ready",
                                     {"res": "out_result", "fl": "out_flags", "tag": "out_tag", "ill": "out_illegal"},
                                     stall=Stall(out_stall, seed() + 1), on_item=self.retired, name="lane_out"))
        self.counts = dict(accept=0, masked=0, illegal=0, retire=0, bp=0, pipe_stall=0)
        self.ev = dict(accept=0, masked=0, illegal=0, retire=0, bp=0, pipe_stall=0)
        self.lat = {}
        self.accept_cyc = {}
        self.tag_w = tag_w
        self.init_seen = False
        self.cov_ops = {}
        self.eng.hooks_sample.append(self.check_cycle)

    def accepted(self, it, cyc):
        if it["en"]:
            exp = model(it["op"], it["rm"], it["a"], it["b"], it["c"], self.C)
            self.sb.expect((exp[0], exp[1], it["tag"], exp[2]))
            self.accept_cyc.setdefault(it["tag"], []).append((cyc, it["op"], exp[2]))
            k = SF.OP_NAMES.get(it["op"], "illegal") if not exp[2] else "illegal"
            self.cov_ops[k] = self.cov_ops.get(k, 0) + 1

    def retired(self, it, cyc):
        self.sb.got((it["res"], it["fl"], it["tag"], it["ill"]))
        lst = self.accept_cyc.get(it["tag"])
        if lst:
            c0, op, ill = lst.pop(0)
            key = "illegal" if ill else SF.OP_NAMES.get(op, "?")
            self.lat.setdefault(key, set()).add(cyc - c0)

    def check_cycle(self, cyc):
        """event pulses vs their exact definitions (sampled settled, before the edge)."""
        d = self.dut
        if self.eng.in_reset:
            return
        iv, ir, en = val(d.in_valid), val(d.in_ready), val(d.lane_en)
        ov, orr = val(d.out_valid), val(d.out_ready)
        op, rm = val(d.in_op), val(d.in_rm)
        ill = 0
        if iv and ir and en:
            ill = model(op, rm, val(d.in_a), val(d.in_b), val(d.in_c), self.C)[2]
        expect = {"ev_accept": iv & ir & en, "ev_retire": ov & orr, "ev_masked": iv & ir & (1 - en),
                  "ev_backpressure": ov & (1 - orr), "ev_illegal": iv & ir & en & ill}
        for k, e in expect.items():
            got = val(getattr(d, k))
            if got != e:
                self.eng.error(f"{k}={got}, definition gives {e}")
        ps = val(d.ev_pipe_stall)
        if ps and not (iv and not ir):
            self.eng.error("ev_pipe_stall without an offered, not-accepted operation")
        if ps and not self.init_seen:
            # definition: in_valid & ~in_ready & init_done -- never in the initialisation cycle
            self.eng.error("ev_pipe_stall pulsed in the initialisation cycle after reset")
        if iv and not ir and self.init_seen and not ps:
            # outside the initialisation cycle every refused offer is a pipe stall
            self.eng.error("offer refused without ev_pipe_stall (after initialisation)")
        for k, s in [("accept", "ev_accept"), ("retire", "ev_retire"), ("masked", "ev_masked"),
                     ("bp", "ev_backpressure"), ("illegal", "ev_illegal"), ("pipe_stall", "ev_pipe_stall")]:
            self.ev[k] += val(getattr(d, s))
        if ir:
            self.init_seen = True
        if not ov:
            for s in ("out_result", "out_flags", "out_tag", "out_illegal"):
                if val(getattr(d, s)) != 0:
                    self.eng.error(f"{s} != 0 while out_valid = 0 (interface rule: payload driven to 0)")
        busy = val(d.busy)
        # busy_o: at least one accepted operation not yet retired (pending handover counts)
        exp_busy = 1 if (self.sb.outstanding() > 0) else 0
        if busy != exp_busy:
            self.eng.error(f"busy_o={busy} but {self.sb.outstanding()} accepted operation(s) outstanding")


async def setup(dut, env):
    start_clock(dut)
    dut.rst_n.value = 0
    dut.in_valid.value = 0
    dut.out_ready.value = 0
    dut.lane_en.value = 1
    env.eng.start()
    env.eng.in_reset = True
    await ClockCycles(dut.clk, 3)
    await FallingEdge(dut.clk)
    dut.rst_n.value = 1
    env.eng.in_reset = False
    env.init_seen = False


def make_item(r, tag, en_p=0.9, illegal_p=0.04):
    op = rand_op(r, illegal_p)
    rm = r.randrange(5) if r.random() > 0.03 else r.randrange(5, 8)
    a, b, c = fpgen.operand(r), fpgen.operand(r), fpgen.operand(r)
    return {"op": op, "rm": rm, "a": a, "b": b, "c": c, "tag": tag, "en": 1 if r.random() < en_p else 0}


async def drain(env, limit=20000):
    for _ in range(limit):
        await RisingEdge(env.dut.clk)
        if env.src.idle() and env.sb.outstanding() == 0 and env.snk.pending is None:
            break
    await ClockCycles(env.dut.clk, 4)


@cocotb.test()
async def test_stream(dut):
    """random operation stream (all ops, all rounding modes, masks, illegal) under stall patterns"""
    env = LaneEnv(dut, env_str("HPC_IN_STALL", "random:0.7"), env_str("HPC_OUT_STALL", "random:0.6"))
    await setup(dut, env)
    r = rng("stream")
    n = env_int("HPC_N", 3000)
    en_p = float(env_str("HPC_EN_P", "0.9"))
    for i in range(n):
        env.src.send(make_item(r, i & 0xFF, en_p))
    await drain(env, 40 * n + 1000)
    tot_acc = env.src.accepted
    finish(env.eng, [env.sb], dut, CHK, extra={
        "ops_issued": tot_acc, "events": env.ev, "latency": {k: sorted(v) for k, v in env.lat.items()},
        "coverage_ops": env.cov_ops, "in_stall_cycles": env.src.stall_cycles, "out_bp_cycles": env.snk.bp_cycles,
        "invariant_accept_eq_retire": env.ev["accept"] == env.ev["retire"]})
    assert env.ev["accept"] == env.ev["retire"], "sum(ev_accept) != sum(ev_retire) once idle"
    assert env.ev["masked"] + env.ev["accept"] == tot_acc, "accept + masked != handshakes"


@cocotb.test()
async def test_rob_full(dut):
    """result channel held: exactly ROB_DEPTH operations accepted, then in_ready low; drains in order"""
    env = LaneEnv(dut, "none", "none")
    await setup(dut, env)
    env.snk.force_ready = 0
    r = rng("rob")
    C = env.C
    for i in range(C["ROB"] * 3):
        it = make_item(r, i, en_p=1.0, illegal_p=0.0)
        env.src.send(it)
    await ClockCycles(dut.clk, 60 + 4 * C["ROB"])
    acc = env.src.accepted
    if acc != C["ROB"]:
        env.eng.error(f"accepted {acc} operations with the result channel blocked; ROB_DEPTH={C['ROB']}")
    if env.ev["pipe_stall"] == 0:
        env.eng.error("ev_pipe_stall never pulsed while the ROB was full")
    # masked operations take no slot, but cannot be accepted while in_ready is low either
    env.snk.force_ready = None
    await drain(env)
    finish(env.eng, [env.sb], dut, CHK, extra={"accepted_while_blocked": acc, "rob_depth": C["ROB"],
                                               "events": env.ev})


@cocotb.test()
async def test_reset_midstream(dut):
    """asynchronous resets at random points: in-flight operations discarded, nothing stale emerges"""
    env = LaneEnv(dut, env_str("HPC_IN_STALL", "random:0.8"), env_str("HPC_OUT_STALL", "random:0.5"))
    await setup(dut, env)
    r = rng("reset")
    discarded = 0
    nres = env_int("HPC_RESETS", 12)
    tag = 0
    for k in range(nres):
        for _ in range(r.randint(5, 60)):
            env.src.send(make_item(r, tag & 0xFF))
            tag += 1
        await ClockCycles(dut.clk, r.randint(1, 40))
        # mid-cycle asynchronous assertion
        await FallingEdge(dut.clk)
        env.eng.in_reset = True
        dut.rst_n.value = 0
        await ReadOnly()
        if val(dut.out_valid) or val(dut.in_ready) or val(dut.busy):
            env.eng.error("reset assertion did not immediately clear out_valid / in_ready / busy")
        await FallingEdge(dut.clk)
        discarded += env.sb.flush()
        env.accept_cyc.clear()
        env.eng.reset_agents()
        await ClockCycles(dut.clk, r.randint(1, 3))
        # offer an operation across reset release: the initialisation cycle must refuse it, and
        # ev_pipe_stall (= in_valid & ~in_ready & init_done) must NOT pulse for that refusal
        # (a real operation, held by the source agent until accepted: the producer contract is kept)
        # (set at the falling edge of the release, after the agents' reset handling of the last edge)
        it = make_item(r, tag & 0xFF, en_p=1.0, illegal_p=0.0)
        tag += 1
        await FallingEdge(dut.clk)
        for k, h in env.src.fields.items():
            h.value = it[k]
        env.src.cur = it
        dut.in_valid.value = 1
        dut.rst_n.value = 1
        env.eng.in_reset = False
        env.init_seen = False
        await ReadOnly()
        if val(dut.in_ready):
            env.eng.error("in_ready high in the first cycle after reset release (initialisation cycle)")
        if not val(dut.in_valid):
            env.eng.error("testbench: the operation offered across reset release is not presented")
        if val(dut.ev_pipe_stall):
            env.eng.error("ev_pipe_stall pulsed in the initialisation cycle after reset")
        env.init_offers = getattr(env, "init_offers", 0) + 1
    await drain(env)
    finish(env.eng, [env.sb], dut, CHK, extra={"resets": nres, "discarded": discarded,
                                               "offers_across_reset_release": getattr(env, "init_offers", 0)})


@cocotb.test()
async def test_illegal_space(dut):
    """every opcode 0..31 x every rm 0..7, enabled and disabled: illegal completes in order, masked is silent"""
    env = LaneEnv(dut, "random:0.8", "random:0.8")
    await setup(dut, env)
    r = rng("illegal")
    tag = 0
    for op in range(32):
        for rm in range(8):
            for en in (1, 0):
                env.src.send({"op": op, "rm": rm, "a": fpgen.operand(r), "b": fpgen.operand(r),
                              "c": fpgen.operand(r), "tag": tag & 0xFF, "en": en})
                tag += 1
    await drain(env)
    finish(env.eng, [env.sb], dut, CHK, extra={"events": env.ev})
    assert env.ev["masked"] == 32 * 8, "every disabled operation must pulse ev_masked"


@cocotb.test()
async def test_latency_throughput(dut):
    """isolated op per unit: latency = LAT + 1 (illegal: 1); back-to-back stream: 1 op / cycle"""
    env = LaneEnv(dut, "none", "none")
    await setup(dut, env)
    r = rng("lat")
    C = env.C
    ops = [0x00, 0x01, 0x03, 0x04, 0x11, 0x0D]
    for i, op in enumerate(ops):
        env.src.send({"op": op, "rm": 0, "a": 0x3F800000, "b": 0x40000000, "c": 0, "tag": i, "en": 1})
        await drain(env)
    for name, lats in env.lat.items():
        op = {"FMV": 0, "FADD": 1, "FMUL": 3, "FMADD": 4, "IMUL": 0x11}.get(name)
        want = 1 if name == "illegal" else unit_lat(op, C) + 1
        if lats != {want}:
            env.eng.error(f"{name}: latency {sorted(lats)}, specification LAT+1 = {want}")
    # throughput: a stream of N FMADDs, no stalls
    n = 200
    t0 = None
    first = {}
    env.snk.on_item = lambda it, cyc: (first.setdefault("t", cyc), first.__setitem__("last", cyc),
                                       env.retired(it, cyc))
    for i in range(n):
        env.src.send({"op": 4, "rm": 0, "a": fpgen.operand(r), "b": fpgen.operand(r), "c": fpgen.operand(r),
                      "tag": i & 0xFF, "en": 1})
    await drain(env)
    span = first["last"] - first["t"] + 1
    thr = n / span
    need = min(1.0, C["ROB"] / (C["LAT_FMA"] + 2))
    if thr + 1e-9 < need * 0.98:
        env.eng.error(f"throughput {thr:.3f} op/cycle < specification min(1, ROB/(LAT+2)) = {need:.3f}")
    finish(env.eng, [env.sb], dut, CHK, extra={"latency": {k: sorted(v) for k, v in env.lat.items()},
                                               "throughput_fma": round(thr, 4), "throughput_spec": round(need, 4)})
