# Verification plan — requirement → test traceability

Status of every row is produced by the last regression (`reports/VERIFICATION_REPORT.md`); this table states
*where* each requirement is checked. "BLOCKED" rows have no RTL to test and are recorded as blocked results.

## 3. Floating-point (suite `fp32`, plus lane / array / tile in context)

| Requirement | Test(s) | Oracle / check |
|---|---|---|
| independently validated IEEE 754 reference | `fp32/oracle_crosscheck` | SoftFloat-3e ≡ MPFR model (written here) ≡ Module 02 exact model, bit-exact incl. flags, every op × 5 modes; injected-bug control proves the check can fail |
| exact binary32 results | `fp32/<cfg>/directed/exact`, `random/s*`, `testfloat/*` | SoftFloat in-process + TestFloat's own expectations + `testfloat_ver` on DUT output |
| FMA single rounding | `directed/fma_single_rounding` (all 4 forms × 5 modes; the crosscheck proves every op/mode pair has a vector where fused ≠ FMUL-then-FADD), `testfloat/L1/mulAdd/*` (6.1 M per mode) | idem |
| NaNs, infinities, signed zeros, subnormals | `directed/nan`, `nan_inf_times_zero`, `inf`, `signed_zero`, `subnormal` | idem |
| overflow, underflow, rounding | `directed/overflow`, `underflow`, `rounding` (ties, halfway, sticky) | idem |
| exception flags | every vector compares all 5 flags; `directed/flags` | idem |
| deviations recorded | `docs/DEVIATIONS.md` | every row has a named test |
| not only Python floats | no host float is used anywhere as an oracle | SoftFloat (C, integer-only), MPFR, exact rationals |

## 4. Protocol (all suites; `common/sv/hpc_rv_checker.sv`, `hpc_txn_conservation.sv`, `lib/hpcv/cycle.py`)

| Requirement | Where |
|---|---|
| payload stable while stalled | SV checker R1 on every DUT output channel (lane, array res/cpl, scratchpad rsp, DMA cpl, tile internal channels) + Python `Sink` check; formal L3 (lane) |
| accepted requests not lost | scoreboards (`missing` at end), `hpc_txn_conservation`, formal L1 / F3 |
| responses correctly tagged | in-order / tagged scoreboards compare tag, tid, beat, last; formal L2 |
| no duplicate completions | scoreboards (`unexpected`), conservation C1 |
| no invalid memory writes | byte-accurate scratchpad model (errors leave memory unchanged), DMA tails / bus errors / rejected descriptors (no bus access, compared memory images) |
| no FIFO overflow / underflow | formal F1–F3 (`hpc_varray_fifo`, `dma_fifo`), conservation C2 bounds, queue-full tests, RTL simulation assertions kept enabled |
| reset clears architectural state | `test_reset*` in lane / array / scratchpad / DMA (asynchronous mid-stream resets; nothing stale emerges; ready / valid low in the initialisation cycle); formal F4, L6 |
| transaction scoreboards | `lib/hpcv/scoreboard.py` (in-order and tagged) |

## 5. Scratchpad (suite `scratchpad`, `reference_models/spm_model.py`)

every bank (`test_all_banks_boundaries`), bank conflicts (`test_bank_conflicts`, ev_conflict + per-edge port-model
limit), concurrent requests (all tests, up to 4 ports), read/write collision rules (`test_rw_collision`, per-edge
same-row rule, formal A4), byte enables (`test_byte_enables`, word-write configs → STROBE), address boundaries
(first / last word of every bank and of the window; out-of-range aliases; formal B1–B4), request ordering and
back-pressure (`test_backpressure_ordering`), errors without side effect (`test_errors_no_side_effect`), reset.

## 6. DMA (suite `dma`, `reference_models/dma_model.py`, `lib/hpcv/sfb_slave.py`)

exact byte copying in all four directions, short (1…31 B) and long (4 KiB CI, 32 KiB nightly) transfers, partial
final words (tail bytes beyond `len` untouched), back-pressure (fabric stalls, completion stalls, bank contention
from a second scratchpad port), outstanding transactions (`test_outstanding`, buffered engine), **completion only
after the last write acknowledgement** (fabric model commits writes at the response handshake; acknowledged-write
count per descriptor checked when the record is produced), reset (`test_reset`, no request until a new
descriptor), error propagation (codes 1–11 incl. REGION, READ_BUS / WRITE_BUS with failing address and
acknowledged prefix, ABORTED).

## 7. Command queue (suite `command_queue`)

queue full (exact accept counts CMD_DEPTH+1 / CPL_DEPTH+CMD_DEPTH), queue empty, mixed sequences, invalid opcodes /
descriptors, completion ordering under back-pressure — for both existing queues. FENCE semantics, dependencies:
**BLOCKED** (no RTL), executable checker self-tested.

## 8. Integrated kernels (suite `tile_integration`)

A vector add, B vector multiply, C vector FMA, E DMA-assisted double-buffered AXPY (DMA overlapping compute),
F dependent multi-command chain (RAW through the scratchpad, every rounding mode, integer op, illegal job, partial
final words). Final host memory and scratchpad compared byte by byte; job and DMA status compared; Module 07
counters cross-checked against scoreboard truth. D dot product: **BLOCKED** at tile level.

## 9. Parameterised regression

| Parameter | CI (mandatory) | Nightly (extended) |
|---|---|---|
| vector lanes | array 1 / 4 / 8 (+2 Icarus), tile 2 / 4 | array 1 / 2 / 4 / 8 + shallow / deep / no-reduction variants; tile 1 / 2 / 4 / 8 |
| memory banks | scratchpad 1 / 2 / 4 / 8 | + 16-port-model / map / queue / latency / data-width variants |
| queue depths | array CMD 1 / 4, DMA CMD 0 / 2 | array 1 / 2 / 4 / 8, DMA 0 / 2 / 8 |
| vector lengths | 0 … 3N+2, random ≤ 40, 1024 | + 65 535 |
| stall patterns | random | none, random (several densities), bursty, periodic, starve |
| seeds | 1 per test | 3 per test (2 for tile) |
| FP | TestFloat L1, 3 × 1 M random | TestFloat L2 (add / sub / mul), 3 latency configs, 10 × 10 M random |

## 10. Formal (suite `formal`) — FIFO safety, request conservation, completion ordering, arbitration safety,
address bounds, reset behaviour; BMC bounds, induction results, assumptions and negative controls are recorded per
job in the report.

## 11. Reporting — `reports/VERIFICATION_REPORT.md`, `reports/results.json`, `reports/junit.xml`.
