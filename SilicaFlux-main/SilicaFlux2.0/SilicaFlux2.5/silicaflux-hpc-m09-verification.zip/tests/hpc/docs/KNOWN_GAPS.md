# Known gaps, blocked tests and observations

Nothing in this list is counted as passed. Blocked tests appear in every report as BLOCKED.

## 1. Blocked: the RTL does not exist

| ID | Item | Why blocked | Ready when the RTL exists |
|---|---|---|---|
| B1 | FENCE semantics (F1, F2) | no tile command processor anywhere in the repository (no Module 06 archive) | `reference_models/cmdq_model.check_trace` (self-tested, rules F1–F4, D1): bind it to the processor's accept / start / complete events |
| B2 | Dependencies between tile commands (RAW / WAR / WAW, DMA ↔ compute overlap) | no hardware dependency tracking; ordering is done by the host / testbench today (kernel F exercises a RAW chain sequenced by the testbench) | same checker, rule D1 |
| B3 | Tile-level dot product (kernel D) | the reduction exists inside `hpc_vector_array` and is verified there (`vector_array/test_reduction`, FMUL + sum), but `hpc_tile_vseq` ties `cmd_red_i` to 0 and has no path for the reduction result | add a kernel D to `tile_integration/test_tile_kernels.py` with `reference_models/varray_model` |

## 2. Not verified by this framework (scope limits)

| ID | Gap | Mitigation / where else covered |
|---|---|---|
| G1 | DataFabric `sfb_crossbar` is not instanced in the tile harness; host memory is the framework's SFB2 slave model (checked on every link by the DataFabric `sfb_protocol_checker`) | crossbar verified by DataFabric and by Module 05's own integration test (re-run by `legacy.py`) |
| G2 | Gate-level simulation, timing, FPGA / ASIC runs, power | Modules 02 / 03 have gate-level runs of their own; no timing is claimed anywhere |
| G3 | Clock-domain crossing (Module 07 `hpc_perf_cdc_count`) | Module 07 simulation with a metastability model (nightly `legacy.py`); no structural CDC tool |
| G4 | Scratchpad byte parity (`ECC_MODE = BYTE_PARITY`) and the DMA scratchpad-tag error path are not stimulated by the framework (no fault injection into the arrays / tags) | Module 04 / 05 own fault-injection tests (re-run by `legacy.py`); see the mutation survivors below |
| G5 | Formal results are bounded for the FIFOs with depth ≥ 2 (BMC depth 12, induction not closed) and for the lane control (BMC depth 14 in CI, 18 nightly; configuration EN_FCMP = EN_INT = 0, minimum latencies, ROB_DEPTH 3). No formal on the array collector / reduction, DMA router / adapter, scratchpad response path or sequencer | simulation + mutation; induction strengthening (internal invariants) is the next step |
| G6 | TestFloat level 2 for `f32_mulAdd` (≥ 14.5·10⁹ cases) is infeasible; level 1 (6.1 M per mode) runs in CI for all five modes, level 2 for add / sub / mul / compare nightly | biased random (10 × 10 M nightly) + directed categories |
| G7 | Line coverage only from Verilator `--coverage-line` on the cocotb runs; no toggle, branch, expression or FSM coverage; the FP32 C++ harness and Icarus runs are not instrumented | FP32 functional bins (operation × mode × flag × operand class × result class) |
| G8 | Module 01 options `NAN_PROPAGATE = 1`, `TININESS_AFTER_ROUNDING = 0` and its elastic-stage back-pressure corner cases are only verified by Module 01's own regression | `legacy.py` (CI quick, nightly full) |
| G9 | `hpc_tile_vseq` is a serial reference sequencer: tile kernels do not exercise full-rate array streaming from memory (the array alone is streamed at full rate in `vector_array/test_throughput`) | a streaming load / store unit would need its own suite |
| G10 | Multiple scratchpad requesters beyond 4 ports, 16 banks, data width > 64 bit, ASIC / FPGA memory backends are outside the CI / nightly matrices | Module 04's own staged regression covers them (`legacy.py` nightly) |

## 3. Observations made while building the framework

| ID | Observation | Effect |
|---|---|---|
| O-1 | Module 02 unit latency convention: `LAT` counts from the lane's issue register, so the delay at the unit boundary is `LAT − 1` cycles (stated in MICROARCHITECTURE.md / `hpc_fp32_misc.sv`, not in the unit port descriptions) | the FP32 harness checks `LAT − 1` exactly; integrators instantiating a unit directly should note it |
| O-2 | The two FMA implementations differ on `rm` 5–7: Module 01 executes RNE, the lane reports an illegal operation | both behaviours verified; consolidating the FMAs (Module 03 audit recommendation) should pick one |
| O-3 | The SRAM-library assertion in `sram_rsp_path` (`SRAMLIB_ASSERT`, "response payload changed while rsp_valid && !rsp_ready") uses `==` on read data: in 4-state simulation, a back-pressured response carrying X data from a never-written SRAM word makes it fire although the payload is stable | not a datapath defect; framework tests initialise the words they read in Icarus runs; an X-tolerant `!==` would remove the false positive |

## 4. Mutation campaign: gaps found in the framework and closed

The CI sample (every 4th mutant of every module table + the framework's own mutants) initially left 10 mutants
alive. Each survivor was analysed; eight were real framework gaps and were closed by new checks, then re-run:

| Mutant | Defect | Why it first survived | Check added |
|---|---|---|---|
| M02-M21 | lane stall event pulses in the post-reset initialisation cycle | no test offered an operation across reset release, and the `init_done` term of `ev_pipe_stall_o` was not enforced | `vector_lane/test_reset_midstream` offers a held operation across every reset release; init-cycle stall check |
| M03-M10 | element offered to a held lane | results stay correct; the hold contract (ARRAY_INTERFACE §12) was not checked | per-cycle hold-contract check on the array → lane issue valids (`lib/hpcv/varray_env.py`) |
| M05-M08 | DMA bytes-read counter includes failed reads | the adapter's own counters were not checked | Module 05 counters and byte events vs bus-observed truth in every DMA test |
| M05-M10 | no completion-slot reservation | the queue-full test lived in the command-queue suite, not among the Module 05 detectors | detector list fixed (the test kills it) |
| M07-E06, E10, E14 | VEC_STALL / OUT_BP / HW_ERRORS event definitions | only 8 of 23 tile counters were cross-checked | 16 tile counters cross-checked against handshake truth |
| M07-E02, W01 | FLOP crediting with mixed operations in flight | the tile's serial sequencer never has two operation types in flight in one lane | `perf_counters/test_perf_varray`: telemetry attached to the array, mixed command streams |

Remaining (documented, not hidden):

| Mutant | Defect | Reason |
|---|---|---|
| M04-M14 | scratchpad parity check disabled | requires SRAM fault injection, which the framework does not do (G4); Module 04's own bench kills it |
| M07-X01..X05 | CDC event-count crossing | `hpc_perf_cdc_count` is not instanced in the single-clock tile (G3); Module 07's own bench covers it |

The nightly matrix runs all 158 mutants; its survivor list is generated into the report (§5.3).
