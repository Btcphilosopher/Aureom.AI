# Supported deviations and implementation-defined choices

Everything below is **checked**, not merely stated: the golden models implement exactly these choices and every
listed behaviour is exercised by a named test (`fp32/directed/<category>` unless noted). A behaviour outside this
list that differs from IEEE 754-2019 would be reported as a failure.

## 1. FP32 arithmetic (Module 02 lane units; Module 01 `fp32_fma` with its default parameters)

| # | Topic | Choice in the RTL | IEEE 754-2019 status | Verified by |
|---|---|---|---|---|
| D1 | NaN results | canonical quiet NaN `0x7FC00000`; input payloads not propagated (RISC-V) | allowed (payload propagation is only *recommended*) | directed/nan, every random and TestFloat run (`-checkNaNs` on `testfloat_ver`) |
| D2 | Tininess | detected **after** rounding; UF = tiny AND inexact (RISC-V, x86) | either convention allowed | directed/underflow (incl. `(2²⁴−1)·2⁻¹⁵⁰` → `0x00800000` with UF), TestFloat `-tininessafter` |
| D3 | Divide-by-zero flag | never raised (no division in the tile) | n/a | functional coverage excludes DZ bins |
| D4 | `0 × ∞ + qNaN` (FMA) | raises NV | implementation-defined in IEEE; required by RISC-V | directed/nan_inf_times_zero |
| D5 | FMIN / FMAX | `minimumNumber` / `maximumNumber`; −0 < +0; one NaN → other operand; NV on a signalling NaN even when the result is a number (RISC-V F 2.2) | IEEE 754-2019 §9.6 | directed/compare_minmax, directed/signed_zero |
| D6 | Comparisons | FEQ quiet (NV only for sNaN), FLT / FLE signalling (NV for any NaN); result is the integer 1 / 0 | IEEE predicates | directed/flags, TestFloat `f32_eq/lt/le` |
| D7 | Rounding attributes | RNE, RTZ, RDN, RUP, RMM (all five) | all required ones + roundTiesToAway | op × rm coverage 35/35 |
| D8 | `rm` codes 5–7 | **lane / array: the operation is illegal** (completes with `illegal = 1`, result 0, flags 0); **Module 01 `fp32_fma`: executed as RNE** | n/a (encoding) | vector_lane test_illegal_space; fp32 directed/illegal_rm (M01) |
| D9 | FNMADD / FNMSUB | negation of the inputs before the single rounding (RISC-V definition) | n/a (operations are ISA-defined) | directed/fma_single_rounding (all 4 forms × 5 modes discriminate fused vs. double rounding) |
| D10 | Subnormals | full support on inputs and outputs; no flush-to-zero, no DAZ | required | directed/subnormal, TestFloat |
| D11 | Exact zero sums | +0, except RDN → −0; equal-sign zero sums keep the sign; exact-zero product returns the addend exactly | required | directed/signed_zero |
| D12 | Exception signalling | flags only (no traps); per element at lane level, OR-accumulated per command at array level, OR over the job at tile level | default exception handling | vector_array, tile_integration |
| D13 | Integer ops | IADD / IMUL modulo 2³² (IMUL low half, signed = unsigned) | n/a | directed/integer, random |

Module 01 option `NAN_PROPAGATE = 1` (ARM-VFPv2 payload propagation) and `TININESS_AFTER_ROUNDING = 0` are verified
only by Module 01's own regression (re-run by `regression/legacy.py`); the tile never instantiates Module 01.

## 2. Reductions (Module 03)

| # | Choice | Consequence | Verified by |
|---|---|---|---|
| D14 | FP32 accumulator; every tree add and accumulator add rounds | not correctly rounded; reproducible for a given N | vector_array test_reduction (bit-exact against the specified order) |
| D15 | Order: pairwise tree over lane index per beat, absent elements skipped (no identity added), then sequential accumulation over beats starting from `cmd_scalar_i` | equals sequential software only for N = 1 | n1 configuration of test_reduction |
| D16 | Dot product is unfused (each product rounded before summation) | differs from an FMA-chain dot product | test_reduction (FMUL/red) |

## 3. Protocol / memory choices the tests rely on

| # | Choice | Verified by |
|---|---|---|
| D17 | Lane inputs do not have to be held stable while not ready (the framework's producers hold them anyway; checked on the producer side) | vector_lane chk_in |
| D18 | Scratchpad arrays and DMA-visible memory are not reset; reading never-written words returns undefined data (X in 4-state simulation) | scratchpad byte-mask comparison |
| D19 | Scratchpad write commits at the issue edge; reads issued later from any port see it; same-row read+write never issued at one edge | scratchpad model + formal A4 |
| D20 | DMA completion = every write acknowledged; source / destination must be word aligned (no byte-shifting datapath); ranges may not cross the scratchpad window (REGION) | dma suite |
