# Audit of the existing SilicaFlux-HPC verification infrastructure

Repository `btcphilosopher/Aureom.AI`, commit `ba7a6c0` (2026-11-07). The SilicaFlux-HPC compute tile exists
**only as zip archives** under `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` (the `SilicaFlux2.0/` copies of
Modules 01 and 02 are byte-identical). There is no checked-out RTL tree, no top-level build and no CI workflow for
them. Every archive was extracted read-only and inspected; `common/fetch_rtl.py` repeats this extraction
reproducibly and pins the archives by SHA-256.

## 1. What exists

| Module (archive) | RTL | SystemVerilog TBs | Verilator infra | cocotb | Formal | Regression scripts | FP reference models |
|---|---|---|---|---|---|---|---|
| 01 FP32 FMA (`silicaflux-hpc-fp32-fma.zip`) | `fp32_fma` + 12 step modules | — | C++ differential harness (SoftFloat in-process, TestFloat stream) | yes, 1.9.2 (Verilator ×6, Icarus ×2) | LZC equivalence (Yosys SAT); pipeline-control BMC depth 16 (induction does not close) | `scripts/regress.sh` (+ `QUICK=1`) | **Berkeley SoftFloat-3e and TestFloat-3e vendored** (pinned release 3e); MPFR cross-check (`ref/mpfr_ref.py`) |
| 02 vector lane (`-m02-vector-lane.zip`) | `hpc_vector_lane` + separate FP add / mul / FMA / misc / int-mul units | `tb_hpc_vector_lane.sv`, `tb_hpc_lzc.sv` | via Python scripts | — | — | `scripts/regress.py`, `mutate.py` (28 mutants), gate-level | exact rational model `ref/fp32_ref.py`, x86 hardware oracle (`fp32_hwref.c`) — **TestFloat not run** |
| 03 vector array (`-m03-vector-array.zip`) | `hpc_vector_array`, issue / collect / reduce / FIFO / perf; lane RTL copied unmodified | `tb_hpc_vector_array.sv` | yes | — | **none** (structural interface proof only) | `regress.py`, `mutate.py` (32), gate-level, P&R | `ref/varray_ref.c` on SoftFloat-3e (vendored again) |
| 04 scratchpad (`-m04-scratchpad.zip`) | `hpc_scratchpad`, addr map, bank arbiter, bank, perf | `tb_hpc_scratchpad.sv` (reference memory + arbiter), `tb_hpc_spm_addr_map.sv` | yes | — | **none** | `run_regress.py` (staged), `run_mutants.py` (26) | address-map model `model/hpc_spm_map.py` |
| 05 DMA adapter (`-m05-dma-adapter.zip`) | `hpc_dma_adapter`, route, SPM port, perf, **`hpc_tile_vseq`** (reference sequencer) | `tb_hpc_dma_adapter.sv`, `tb_hpc_dma_route.sv`, `tb_hpc_tile.sv` (integration) | yes | — | **none** (listed as next action) | `run_regress.py`, `run_mutants.py` (24), `run_integ.py` | `model/fp32_exact.py` |
| 06 | **no archive exists** (no command processor / FENCE RTL anywhere in the repository) | | | | | | |
| 07 perf counters (`-m07-perf-counters.zip`) | `hpc_perf_counters`, events, wtrack, tile binding, CDC; M03 observation-port patch | unit / events / varray / tile / CDC TBs | yes | — | BMC + k-induction of A1–A7 with negative controls | `run_*.py`, `run_mutants.py` (46) | `model/perf_ref.py` |
| DataFabric (vendored in 04/05/07) | DMA engines, SFB2 crossbar, SRAM slave | `sfb_protocol_checker.sv` | | | | | |
| SRAM wrapper library (vendored) | backends, response path | `SRAMLIB_ASSERT` checks | | | | | |

CI workflows: none for the HPC modules (other projects in the repository carry their own, unrelated workflows).
Tool baseline used by every module: Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python ≥ 3.10.

## 2. Consistency of vendored copies

Modules 03, 05 and 07 vendor copies of earlier modules, the DataFabric and the SRAM library. `fetch_rtl.py` compares
every vendored RTL file with its canonical source on every run: **118 / 120** copies are byte-identical; the two
differences are Module 07's documented observation-port patch of `hpc_vector_array.sv` / `hpc_varray_issue.sv`,
which Module 07 proves equivalent on all pre-existing outputs (Yosys `equiv_*`).

## 3. Findings that shaped the framework

1. **The tile's arithmetic is Module 02's, not Module 01's.** Every lane (hence the array and the tile) uses
   `hpc_fp32_add/mul/fma`; the TestFloat-verified FMA is the stand-alone Module 01 `fp32_fma`, which the tile does
   not instantiate. Module 02 was verified against its own exact model and x86 hardware only. The framework
   therefore runs SoftFloat-3e + TestFloat-3e (+ `testfloat_ver`) on the Module 02 units directly, and runs
   Module 01 side by side on the same vectors (two independent FMA implementations, one oracle).
2. **No command processor / FENCE exists.** The command-queue suite verifies the two queues that exist
   (vector-array command queue, DMA descriptor queue); FENCE and inter-command dependency tests are recorded as
   BLOCKED with an executable trace checker ready (`reference_models/cmdq_model.py`).
3. **No tile top exists.** The tile is assembled exactly as Modules 05 / 07 document it (array with observation
   port, scratchpad, DMA adapter, reference sequencer, telemetry) in `tile_integration/tb_tile_top.sv`.
4. **The dot product exists only inside the array.** `hpc_tile_vseq` drives `cmd_red_i = 0`; tile-level dot
   product is BLOCKED, array-level reduction is verified against the specified summation order.
5. **Formal coverage was thin** (Module 01 pipeline control, Module 07 counters). The framework adds FIFO,
   arbitration, address-map and lane-control properties with negative controls.
6. **The proven regressions are kept.** `regression/legacy.py` re-runs every module's own regression unchanged;
   nothing was replaced. cocotb 1.9.2 is pinned because cocotb 2.x needs Verilator ≥ 5.036.
7. **SymbiYosys is not installed** (as in Modules 05 / 07); formal is driven through `yosys-smtbmc` directly with
   the PyPI z3 (the Debian z3 4.8.12 hangs on the smtbmc pipe — Module 07 finding).
