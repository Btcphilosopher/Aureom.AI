"""cocotb tests for hpc_scratchpad (Module 04) through tb_spm_top.

A multi-port requester drives every port; the byte-accurate reference memory
(reference_models/spm_model.py) is updated at each request's ISSUE edge (the
documented commit point: ev_issue[p], in per-port acceptance order), so every
read is predicted exactly whatever the arbitration chose.  Per edge the model
also checks the collision rule and the bank port-model limit, and compares
ev_bank_ops.  Per port the responses must arrive in order with the right tag,
data (known bytes), error code and write flag.
"""
from __future__ import annotations

from collections import deque

import cocotb
from cocotb.triggers import ClockCycles, FallingEdge, ReadOnly, RisingEdge

from hpcv.cycle import Engine, bstr, field, field_str, masked_equal, val
from hpcv.stall import Stall
from hpcv.tbutil import env_int, env_str, publish, rng, seed, start_clock
from reference_models import spm_model as SM


def cfg():
    return SM.SpmConfig(cap=env_int("CAPACITY_BYTES", 65536), banks=env_int("NUM_BANKS", 2),
                        dw=env_int("DATA_WIDTH", 32), aw=env_int("ADDR_WIDTH", 32), base=env_int("BASE_ADDR", 0),
                        byte_we=env_int("BYTE_WE", 1), pmode=env_int("PORT_MODE", 0), mapping=env_int("MAP", 0),
                        write_ack=env_int("WRITE_ACK", 1))


class SpmEnv:
    """multi-port requester + responder model + scoreboard (one agent for all ports)"""

    def __init__(self, dut, req_stall="none", rsp_stall="none"):
        self.dut = dut
        self.c = cfg()
        self.P = env_int("NUM_PORTS", 2)
        self.QD = env_int("QUEUE_DEPTH", 0)
        self.RL = env_int("READ_LATENCY", 1)
        self.tw = env_int("TAG_W", 8)
        self.eng = Engine(dut)
        self.eng.add(self)
        self.mem = SM.Memory(self.c)
        s = seed()
        self.q = [deque() for _ in range(self.P)]
        self.cur = [None] * self.P
        self.acc_q = [deque() for _ in range(self.P)]
        self.exp = [deque() for _ in range(self.P)]
        self.req_st = [Stall(req_stall, s + p) for p in range(self.P)]
        self.rsp_st = [Stall(rsp_stall, s + 100 + p) for p in range(self.P)]
        self.fire = self.issue = self.rfire = 0
        self.rsp_cap = [None] * self.P
        self.prev_stalled = [None] * self.P
        self.force_rsp_ready = None
        self.stats = dict(accepted=0, issued=0, responses=0, reads=0, writes=0, errors=0, conflicts=0,
                          credit_stalls=0, max_wait=0, rsp_bp_cycles=0, same_bank_edges=0, mismatches=0)
        self.err_codes = {}
        self.bank_hits = [0] * self.c.banks
        self.present_cyc = [None] * self.P
        dut.req_valid.value = 0
        dut.rsp_ready.value = 0

    # ------------------------------------------------------------ stimulus
    def send(self, p, we, addr, wdata=0, wstrb=None, tag=0):
        if wstrb is None:
            wstrb = (1 << self.c.wb) - 1
        self.q[p].append({"we": we, "addr": addr, "wdata": wdata, "wstrb": wstrb, "tag": tag & ((1 << self.tw) - 1)})

    def idle(self):
        return all(not self.q[p] and self.cur[p] is None and not self.acc_q[p] and not self.exp[p]
                   for p in range(self.P))

    def reset(self):
        for p in range(self.P):
            self.q[p].clear()
            self.cur[p] = None
            self.acc_q[p].clear()
            self.exp[p].clear()
            self.prev_stalled[p] = None
            self.rsp_cap[p] = None
        self.fire = self.issue = self.rfire = 0
        self.dut.req_valid.value = 0

    def _bits(self, v, w, p):
        return (v >> (w * p)) & ((1 << w) - 1)

    # ------------------------------------------------------------ per edge
    def on_edge(self, cyc):
        if self.eng.in_reset:
            self.dut.req_valid.value = 0
            return
        issued = []
        for p in range(self.P):
            if (self.fire >> p) & 1:
                r = self.cur[p]
                self.cur[p] = None
                self.acc_q[p].append(r)
                self.stats["accepted"] += 1
                if self.present_cyc[p] is not None:
                    self.stats["max_wait"] = max(self.stats["max_wait"], cyc - self.present_cyc[p])
            if (self.issue >> p) & 1:
                if not self.acc_q[p]:
                    self.eng.error(f"port {p}: ev_issue without an accepted request")
                    continue
                issued.append((p, self.acc_q[p].popleft()))
        if issued:
            self.stats["issued"] += len(issued)
            resps, viol = SM.issue_edge(self.c, self.mem, issued)
            for v in viol:
                self.eng.error("arbitration/collision rule: " + v)
            for p, e in resps:
                self.exp[p].append(e)
            banks = [SM.decode(self.c, r["addr"], r["we"], r["wstrb"]) for _, r in issued]
            ok = [b[1] for b in banks if b[0] == 0]
            for b in ok:
                self.bank_hits[b] += 1
            if len(ok) != len(set(ok)):
                self.stats["same_bank_edges"] += 1
            for p, r in issued:
                code = SM.decode(self.c, r["addr"], r["we"], r["wstrb"])[0]
                k = ["ok", "range", "align", "strobe"][code]
                self.err_codes[k] = self.err_codes.get(k, 0) + 1
                self.stats["writes" if r["we"] else "reads"] += 1
            self._exp_bank_ops = {}
            for b in ok:
                self._exp_bank_ops[b] = self._exp_bank_ops.get(b, 0) + 1
        for p in range(self.P):
            if (self.rfire >> p) & 1:
                got = self.rsp_cap[p]
                self.stats["responses"] += 1
                if not self.exp[p]:
                    self.eng.error(f"port {p}: unsolicited / duplicate response {got}")
                    continue
                e = self.exp[p].popleft()
                m = e["mask"]
                if not masked_equal(got["rdata"], e["rdata"], m) or got["err"] != e["err"] or got["code"] != e["code"] or \
                        got["we"] != e["we"] or got["tag"] != e["tag"]:
                    self.stats["mismatches"] += 1
                    self.eng.error(f"port {p}: response mismatch: expected rdata={e['rdata']:x}&{m:x} err={e['err']} "
                                   f"code={e['code']} we={e['we']} tag={e['tag']}; got rdata={got['rdata']} "
                                   f"err={got['err']} code={got['code']} we={got['we']} tag={got['tag']}")
                if e["err"]:
                    self.stats["errors"] += 1
        # drive requests
        v = we = addr = wd = ws = tg = 0
        AW, DW, NB, TW = self.c.aw, self.c.dw, self.c.wb, self.tw
        for p in range(self.P):
            if self.cur[p] is None and self.q[p] and self.req_st[p]():
                self.cur[p] = self.q[p].popleft()
                self.present_cyc[p] = cyc
            r = self.cur[p]
            if r is not None:
                v |= 1 << p
                we |= r["we"] << p
                addr |= (r["addr"] & ((1 << AW) - 1)) << (AW * p)
                wd |= r["wdata"] << (DW * p)
                ws |= r["wstrb"] << (NB * p)
                tg |= r["tag"] << (TW * p)
        d = self.dut
        d.req_valid.value = v
        d.req_we.value = we
        d.req_addr.value = addr
        d.req_wdata.value = wd
        d.req_wstrb.value = ws
        d.req_tag.value = tg
        rr = 0
        for p in range(self.P):
            if self.force_rsp_ready is not None:
                rr |= self.force_rsp_ready << p
            elif self.rsp_st[p]():
                rr |= 1 << p
        d.rsp_ready.value = rr

    def sample(self, cyc):
        d = self.dut
        if self.eng.in_reset:
            self.fire = self.issue = self.rfire = 0
            return
        rdy, iss = val(d.req_ready), val(d.ev_issue)
        rv, rr = val(d.rsp_valid), val(d.rsp_ready)
        reqv = val(d.req_valid)
        self.fire = rdy & reqv
        self.issue = iss
        if self.QD == 0 and (self.fire != (iss & reqv) or (iss & ~reqv)):
            self.eng.error(f"QUEUE_DEPTH=0: accept {self.fire:b} != issue {iss:b} (accept = issue at the same edge)")
        self.stats["conflicts"] += bin(val(d.ev_conflict)).count("1")
        self.stats["credit_stalls"] += bin(val(d.ev_credit_stall)).count("1")
        rdata, err, code, rwe, rtag = bstr(d.rsp_rdata), bstr(d.rsp_err), bstr(d.rsp_err_code), bstr(d.rsp_we), \
            bstr(d.rsp_tag)
        self.rfire = rv & rr
        for p in range(self.P):
            if not (rv >> p) & 1:
                if self.prev_stalled[p] is not None:
                    self.eng.error(f"port {p}: rsp_valid dropped without handshake")
                self.prev_stalled[p] = None
                continue
            cap = {"rdata": field_str(rdata, self.c.dw * p, self.c.dw), "err": field(err, p, 1),
                   "code": field(code, 3 * p, 3), "we": field(rwe, p, 1), "tag": field(rtag, self.tw * p, self.tw)}
            if any(v < 0 for k, v in cap.items() if k != "rdata"):
                self.eng.error(f"port {p}: response payload X/Z while rsp_valid: {cap}")
            if self.prev_stalled[p] is not None and cap != self.prev_stalled[p]:
                self.eng.error(f"port {p}: response payload changed while back-pressured")
            self.rsp_cap[p] = cap
            if (rr >> p) & 1:
                self.prev_stalled[p] = None
            else:
                self.prev_stalled[p] = cap
                self.stats["rsp_bp_cycles"] += 1
        # ev_bank_ops (accesses per bank this cycle, 2 bits each) vs the requests issuing at this edge:
        # QUEUE_DEPTH = 0 -> the presented request (accept = issue); else the head of the port's queue
        eb = val(d.ev_bank_ops)
        exp = {}
        for p in range(self.P):
            if not (iss >> p) & 1:
                continue
            r = self.cur[p] if self.QD == 0 else (self.acc_q[p][0] if self.acc_q[p] else None)
            if r is None:
                continue
            code, b, _, _ = SM.decode(self.c, r["addr"], r["we"], r["wstrb"])
            if code == 0:
                exp[b] = exp.get(b, 0) + 1
        got = {b: self._bits(eb, 2, b) for b in range(self.c.banks) if self._bits(eb, 2, b)}
        if got != exp:
            self.eng.error(f"ev_bank_ops {got} != accesses issued per bank {exp}")

    async def drain(self, limit=100000):
        for _ in range(limit):
            await RisingEdge(self.dut.clk)
            if self.idle():
                break
        await ClockCycles(self.dut.clk, self.RL + 4)
        if not self.idle():
            self.eng.error(f"not drained: queued={[len(x) for x in self.q]} accepted-not-issued="
                           f"{[len(x) for x in self.acc_q]} expected-responses={[len(x) for x in self.exp]}")
        if val(self.dut.busy):
            self.eng.error("busy still high when idle")

    def addr_of(self, w):
        return self.c.base + w * self.c.wb

    async def init_words(self, r, words):
        """write every word that a test will read (the arrays are not reset; see O-3)"""
        for i, w in enumerate(sorted(set(words))):
            self.send(i % self.P, 1, self.addr_of(w), r.getrandbits(self.c.dw))
        await self.drain()


async def setup(dut, env):
    start_clock(dut)
    dut.rst_n.value = 0
    env.eng.start()
    env.eng.in_reset = True
    await ClockCycles(dut.clk, 3)
    await FallingEdge(dut.clk)
    dut.rst_n.value = 1
    env.eng.in_reset = False


def done(env, **extra):
    d = env.dut
    chk = val(d.chk_err)
    if chk:
        env.eng.error(f"SV protocol checkers: {chk} violation(s)")
    publish({"cycles": env.eng.cycle, "errors": len(env.eng.errors), "stats": env.stats, "codes": env.err_codes,
             "bank_hits": env.bank_hits, "sv_checker_errors": chk, **extra})
    if env.eng.errors:
        raise AssertionError(f"{len(env.eng.errors)} error(s); first: {env.eng.errors[0]}")


def stalls():
    return env_str("HPC_REQ_STALL", "random:0.7"), env_str("HPC_RSP_STALL", "random:0.6")


def rnd_word(r, c):
    return r.getrandbits(c.dw)


@cocotb.test()
async def test_all_banks_boundaries(dut):
    """write then read the first/last words of every bank and of the whole capacity, through every port"""
    env = SpmEnv(dut, *stalls())
    await setup(dut, env)
    r = rng("banks")
    c = env.c
    words = set()
    # every map is a bijection: enumerate words and keep the boundary rows of every bank
    want = {(b, row) for b in range(c.banks) for row in (0, 1, c.depth - 2, c.depth - 1)}
    for w in list(range(0, min(c.words, 4 * c.banks))) + list(range(c.words - 4 * c.banks, c.words)) + \
            [k * c.depth + d for k in range(c.banks) for d in (0, 1, c.depth - 2, c.depth - 1)]:
        if 0 <= w < c.words:
            words.add(w)
    for w in range(c.words):
        _, b, row, _ = SM.decode(c, env.addr_of(w))
        if (b, row) in want:
            words.add(w)
            want.discard((b, row))
        if not want:
            break
    words = sorted(words)
    for i, w in enumerate(words):
        env.send(i % env.P, 1, env.addr_of(w), rnd_word(r, c), tag=i)
    await env.drain()
    for i, w in enumerate(words):
        env.send((i + 1) % env.P, 0, env.addr_of(w), tag=i)
    await env.drain()
    hit = [h > 0 for h in env.bank_hits]
    if not all(hit):
        env.eng.error(f"not every bank was accessed: {env.bank_hits}")
    done(env, words=len(words))


@cocotb.test()
async def test_byte_enables(dut):
    """random byte-strobe writes merged into known words, read back from other ports"""
    env = SpmEnv(dut, *stalls())
    await setup(dut, env)
    r = rng("strb")
    c = env.c
    hot = [r.randrange(c.words) for _ in range(24)]
    for i, w in enumerate(hot):
        env.send(i % env.P, 1, env.addr_of(w), rnd_word(r, c), tag=i)
    await env.drain()
    full = (1 << c.wb) - 1
    for i in range(env_int("HPC_NREQ", 600)):
        w = r.choice(hot)
        p = r.randrange(env.P)
        if r.random() < 0.6:
            strb = r.randrange(0, full + 1) if c.byte_we else full
            env.send(p, 1, env.addr_of(w), rnd_word(r, c), strb, tag=i)
        else:
            env.send(p, 0, env.addr_of(w), tag=i)
    await env.drain()
    done(env)


@cocotb.test()
async def test_bank_conflicts(dut):
    """all ports hammer one bank (conflicts), then every port its own bank (no conflicts in LOW/HIGH maps)"""
    env = SpmEnv(dut, "none", "none")
    await setup(dut, env)
    r = rng("conf")
    c = env.c
    same = [w for w in range(0, c.words, 1) if SM.decode(c, env.addr_of(w))[1] == 0][:64]
    per = {p: [w for w in range(c.words) if SM.decode(c, env.addr_of(w))[1] == p][:64]
           for p in range(min(env.P, c.banks))}
    await env.init_words(r, same + [w for v in per.values() for w in v])
    c_init = env.stats["conflicts"]
    for i in range(160):
        p = i % env.P
        w = same[r.randrange(len(same))]
        env.send(p, r.random() < 0.5, env.addr_of(w), rnd_word(r, c), tag=i)
    await env.drain()
    conf_same = env.stats["conflicts"] - c_init
    if env.P > 1 and conf_same == 0:
        env.eng.error("ports competing for one bank produced no ev_conflict")
    c0 = env.stats["conflicts"]
    if c.banks >= env.P:
        for i in range(40):
            for p in range(env.P):
                env.send(p, r.random() < 0.5, env.addr_of(r.choice(per[p])), rnd_word(r, c), tag=i)
        await env.drain()
        if env.stats["conflicts"] != c0 and env.c.pmode == SM.PM_1RW:
            env.eng.error(f"disjoint banks produced {env.stats['conflicts'] - c0} conflict(s)")
    done(env, conflicts_same_bank=conf_same, conflicts_disjoint=env.stats["conflicts"] - c0)


@cocotb.test()
async def test_rw_collision(dut):
    """read and write the same words from different ports simultaneously (read-during-write rules)"""
    env = SpmEnv(dut, "none", env_str("HPC_RSP_STALL", "random:0.8"))
    await setup(dut, env)
    r = rng("coll")
    c = env.c
    hot = [r.randrange(c.words) for _ in range(4)]
    for w in hot:
        env.send(0, 1, env.addr_of(w), rnd_word(r, c))
    await env.drain()
    for i in range(env_int("HPC_NREQ", 600)):
        w = r.choice(hot)
        for p in range(env.P):
            env.send(p, (p + i) % 2, env.addr_of(w), rnd_word(r, c), tag=i)
    await env.drain()
    done(env)


@cocotb.test()
async def test_random_concurrent(dut):
    """random reads / writes / strobes / errors on every port with request and response stalls"""
    env = SpmEnv(dut, *stalls())
    await setup(dut, env)
    r = rng("rand")
    c = env.c
    # initialise a pool spread over every bank first: the arrays are not reset and the SRAM library's
    # own 4-state assertion (sram_rsp_path SRAMLIB_ASSERT, '==' on read data) rejects X data from
    # never-written words (observation O-3 in docs/KNOWN_GAPS.md); uninitialised reads stay covered by
    # the byte-mask comparison in the 2-state runs of the other tests.
    pool = sorted({r.randrange(c.words) for _ in range(160)})
    hot = pool[:32]
    for i, w in enumerate(pool):
        env.send(i % env.P, 1, env.addr_of(w), rnd_word(r, c))
    await env.drain()
    full = (1 << c.wb) - 1
    for i in range(env_int("HPC_NREQ", 1500)):
        p = r.randrange(env.P)
        x = r.random()
        if x < 0.85:
            w = r.choice(hot) if r.random() < 0.6 else r.choice(pool)
            a = env.addr_of(w)
        elif x < 0.92:
            a = env.addr_of(r.randrange(c.words)) + r.randrange(1, c.wb)       # misaligned
        else:
            a = c.base + c.cap + r.randrange(0, 4 * c.cap) & ~(c.wb - 1)       # out of range
        we = 1 if r.random() < 0.5 else 0
        strb = (r.randrange(full + 1) if r.random() < 0.3 else full) if c.byte_we else full
        env.send(p, we, a, rnd_word(r, c), strb, tag=i)
    await env.drain()
    done(env)


@cocotb.test()
async def test_errors_no_side_effect(dut):
    """RANGE / ALIGN / STROBE: error code, zero data, in order, and the aliased words are unchanged"""
    env = SpmEnv(dut, "none", "none")
    await setup(dut, env)
    r = rng("err")
    c = env.c
    ws = [0, 1, c.words // 2, c.words - 1]
    for w in ws:
        env.send(0, 1, env.addr_of(w), rnd_word(r, c))
    await env.drain()
    top = (1 << c.aw) - c.wb
    full = (1 << c.wb) - 1
    for w in ws:
        a = env.addr_of(w)
        for bad in (a + c.cap, a + 2 * c.cap, a + 3 * c.cap, top):          # exact aliases: RANGE
            env.send(1 % env.P, 1, bad, rnd_word(r, c))
        if c.base >= c.wb:
            env.send(0, 1, c.base - c.wb, rnd_word(r, c))                      # below the window
        env.send(0, 1, a + 1, rnd_word(r, c))                                   # ALIGN
        env.send(0, 0, a + c.wb - 1)
        if not c.byte_we:
            env.send(0, 1, a, rnd_word(r, c), 0x1)                              # STROBE
    await env.drain()
    for w in ws:                                                                 # unchanged?
        env.send(0, 0, env.addr_of(w))
    await env.drain()
    done(env)


@cocotb.test()
async def test_backpressure_ordering(dut):
    """responses held for long periods: per-port order, tags, credit stalls, nothing lost"""
    env = SpmEnv(dut, "none", "none")
    await setup(dut, env)
    r = rng("bp")
    c = env.c
    await env.init_words(r, range(min(c.words, 256)))
    for i in range(env_int("HPC_NREQ", 600)):
        p = r.randrange(env.P)
        env.send(p, r.random() < 0.4, env.addr_of(r.randrange(min(c.words, 256))), rnd_word(r, c), tag=i)
    for k in range(20):
        env.force_rsp_ready = 0
        await ClockCycles(dut.clk, r.randint(5, 40))
        env.force_rsp_ready = None if k % 2 else 1
        await ClockCycles(dut.clk, r.randint(5, 40))
    env.force_rsp_ready = None
    await env.drain()
    if env.stats["credit_stalls"] == 0 and env_int("RSP_FIFO_DEPTH", 2) > 0:
        env.eng.error("response back-pressure never produced ev_credit_stall")
    done(env)


@cocotb.test()
async def test_reset(dut):
    """asynchronous reset with requests queued and in flight: no response is ever delivered for them"""
    env = SpmEnv(dut, *stalls())
    await setup(dut, env)
    r = rng("reset")
    c = env.c
    for k in range(env_int("HPC_RESETS", 6)):
        for i in range(r.randint(10, 60)):
            env.send(r.randrange(env.P), r.random() < 0.5, env.addr_of(r.randrange(c.words)), rnd_word(r, c), tag=i)
        await ClockCycles(dut.clk, r.randint(2, 30))
        await FallingEdge(dut.clk)
        env.eng.in_reset = True
        dut.rst_n.value = 0
        await ReadOnly()
        if val(dut.rsp_valid) or val(dut.req_ready):
            env.eng.error("rsp_valid / req_ready high immediately after reset assertion")
        await FallingEdge(dut.clk)
        env.reset()
        # issued writes are in the array, queued ones dropped: the array content is now unknown to the model
        env.mem = SM.Memory(c)
        await ClockCycles(dut.clk, 2)
        await FallingEdge(dut.clk)
        dut.rst_n.value = 1
        env.eng.in_reset = False
        await ReadOnly()
        if val(dut.req_ready):
            env.eng.error("req_ready high in the first cycle after reset (H7)")
    for i in range(100):
        w = r.randrange(c.words)
        env.send(i % env.P, 1, env.addr_of(w), rnd_word(r, c), tag=i)
        env.send((i + 1) % env.P, 0, env.addr_of(w), tag=i)
    await env.drain()
    done(env)
