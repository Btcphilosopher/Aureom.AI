#!/usr/bin/env python3
"""Scratchpad suite (hpc_scratchpad, Module 04): byte-accurate model, every bank,
conflicts, concurrent ports, read/write collisions, byte enables, boundaries,
errors, ordering, back-pressure, reset.  Parameterised over 1/2/4/8 banks.
usage: run_scratchpad.py [--matrix ci|nightly] [--sim verilator|icarus] [--config NAME] [--only SUBSTR] [--seed N]
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import cocorun, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "scratchpad"
B = dict(NUM_PORTS=2, CAPACITY_BYTES=65536, NUM_BANKS=2, DATA_WIDTH=32, ADDR_WIDTH=32, BASE_ADDR=0, READ_LATENCY=1,
         BYTE_WE=1, PORT_MODE=0, MAP=0, ARB=0, QUEUE_DEPTH=0, RSP_FIFO_DEPTH=2, WRITE_ACK=1, TAG_W=8)
CONFIGS = {
    "b1_p2": dict(B, NUM_BANKS=1),
    "b1_p2_wordwe": dict(B, NUM_BANKS=1, BYTE_WE=0),
    "b4_p3_2rw_q2_rl2": dict(B, NUM_BANKS=4, NUM_PORTS=3, PORT_MODE=2, QUEUE_DEPTH=2, READ_LATENCY=2, RSP_FIFO_DEPTH=3,
                             BASE_ADDR=0x20000000),
    "b2_p2": dict(B),
    "b4_p3_xor_q2_rl2": dict(B, NUM_BANKS=4, NUM_PORTS=3, MAP=1, QUEUE_DEPTH=2, READ_LATENCY=2, RSP_FIFO_DEPTH=3,
                             BASE_ADDR=0x20000000),
    "b8_p4_high_1r1w": dict(B, NUM_BANKS=8, NUM_PORTS=4, MAP=2, PORT_MODE=1, RSP_FIFO_DEPTH=2),
    "b4_p4_2rw_fixed": dict(B, NUM_BANKS=4, NUM_PORTS=4, PORT_MODE=2, ARB=1, BASE_ADDR=0x20000000),
    "b2_p2_wordwe_posted": dict(B, BYTE_WE=0, WRITE_ACK=0, CAPACITY_BYTES=131072),
    "b8_p2_q4_rl3": dict(B, NUM_BANKS=8, QUEUE_DEPTH=4, READ_LATENCY=3, RSP_FIFO_DEPTH=4, CAPACITY_BYTES=262144),
    "b4_p2_dw64": dict(B, NUM_BANKS=4, DATA_WIDTH=64),
}
TESTS = ["test_all_banks_boundaries", "test_byte_enables", "test_bank_conflicts", "test_rw_collision",
         "test_random_concurrent", "test_errors_no_side_effect", "test_backpressure_ordering", "test_reset"]
MATRIX = {
    "ci": dict(configs=["b1_p2_wordwe", "b2_p2", "b4_p3_2rw_q2_rl2", "b8_p4_high_1r1w"], seeds=1, nreq=800,
               stalls=[("random:0.7", "random:0.6")], icarus_cfg=["b2_p2"], icarus=["test_random_concurrent"]),
    "nightly": dict(configs=list(CONFIGS), seeds=3, nreq=4000,
                    stalls=[("random:0.7", "random:0.6"), ("none", "none"), ("bursty", "random:0.2"),
                            ("starve", "bursty")],
                    icarus_cfg=["b2_p2", "b4_p3_xor_q2_rl2"], icarus=TESTS),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--sim", default=None, choices=["verilator", "icarus"])
    ap.add_argument("--only", default="")
    ap.add_argument("--config", action="append")
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    sim.ensure_rtl()
    srcs = FL.files("scratchpad") + FL.checker_files() + [HERE / "tb_spm_top.sv"]
    inc = FL.INCDIRS["scratchpad"]
    defs = {d: 1 for d in FL.SIM_DEFINES["scratchpad"]}
    print(f"== scratchpad suite, matrix {a.matrix}")
    runs = []
    if a.sim in (None, "verilator"):
        runs += [(c, "verilator", [t for t in TESTS if a.only in t]) for c in (a.config or mx["configs"])]
    if a.sim in (None, "icarus"):
        runs += [(c, "icarus", [t for t in mx["icarus"] if a.only in t]) for c in (a.config or mx["icarus_cfg"])]
    for cfg, s, tests in runs:
        P = CONFIGS[cfg]
        for si in range(mx["seeds"] if s == "verilator" else 1):
            seed = a.seed + si
            for k, (rq, rs) in enumerate(mx["stalls"]):
                tl = tests if k == 0 else [t for t in tests if t in ("test_random_concurrent", "test_byte_enables")]
                if not tl:
                    continue
                name = cfg if k == 0 else f"{cfg}+{rq}/{rs}".replace(":", "")
                cocorun.run_suite(SUITE, name, toplevel="tb_spm_top", sources=srcs, test_module="test_scratchpad",
                                  test_dir=HERE, testcases=tl, parameters=P, defines=defs, includes=inc, sim=s,
                                  seed=seed, env={**P, "HPC_NREQ": mx["nreq"] if s == "verilator" else 200,
                                                  "HPC_REQ_STALL": rq, "HPC_RSP_STALL": rs},
                                  config={"req_stall": rq, "rsp_stall": rs},
                                  repro_hint=f"python3 tests/hpc/scratchpad/run_scratchpad.py --sim {{sim}} "
                                             f"--config {cfg} --only {{tc}} --seed {{seed}}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
