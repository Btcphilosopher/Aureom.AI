// =============================================================================
// SilicaFlux-HPC verification :: tb_spm_top -- cocotb wrapper for hpc_scratchpad
// DUT: Module 04 hpc_scratchpad (unmodified, GENERIC backend) + framework checkers:
//   per port p: chk_req[p] (testbench producer contract: requester holds payload)
//               chk_rsp[p] (DUT: response stable while back-pressured, low in reset)
//               cons[p]    (WRITE_ACK = 1: one response per accepted request,
//                           outstanding bounded by queue + response credits)
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_spm_defs.svh"
module tb_spm_top #(
  parameter int          NUM_PORTS      = 2,
  parameter int          CAPACITY_BYTES = 65536,
  parameter int          NUM_BANKS      = 2,
  parameter int          DATA_WIDTH     = 32,
  parameter int          ADDR_WIDTH     = 32,
  parameter logic [63:0] BASE_ADDR      = 64'h0,
  parameter int          READ_LATENCY   = 1,
  parameter int          BYTE_WE        = 1,
  parameter int          PORT_MODE      = 0,
  parameter int          MAP            = 0,
  parameter int          ARB            = 0,
  parameter int          QUEUE_DEPTH    = 0,
  parameter int          RSP_FIFO_DEPTH = READ_LATENCY + 1,
  parameter int          WRITE_ACK      = 1,
  parameter int          TAG_W          = 8,
  localparam int P  = NUM_PORTS,
  localparam int DW = DATA_WIDTH,
  localparam int AW = ADDR_WIDTH,
  localparam int NB = DATA_WIDTH / 8
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic [P-1:0]      req_valid,
  output logic      [P-1:0]      req_ready,
  input  wire logic [P-1:0]      req_we,
  input  wire logic [P*AW-1:0]   req_addr,
  input  wire logic [P*DW-1:0]   req_wdata,
  input  wire logic [P*NB-1:0]   req_wstrb,
  input  wire logic [P*TAG_W-1:0] req_tag,
  output logic      [P-1:0]      rsp_valid,
  input  wire logic [P-1:0]      rsp_ready,
  output logic      [P*DW-1:0]   rsp_rdata,
  output logic      [P-1:0]      rsp_err,
  output logic      [P*3-1:0]    rsp_err_code,
  output logic      [P-1:0]      rsp_we,
  output logic      [P*TAG_W-1:0] rsp_tag,
  output logic      [P*NB-1:0]   rsp_ecc_syn,
  output logic      [P-1:0]      ev_accept, ev_issue, ev_conflict, ev_credit_stall, ev_error,
  output logic      [NUM_BANKS*2-1:0] ev_bank_ops,
  output logic      [NUM_BANKS-1:0]   ev_bank_conflict,
  output logic                   busy,
  output logic      [31:0]       chk_err
);
  logic [P-1:0] ev_ecc;
  logic [31:0]  pc_cycles, pc_ecc;
  logic [P*32-1:0] pc_acc, pc_iss, pc_cpl, pc_cfl, pc_wait, pc_err;
  logic [NUM_BANKS*32-1:0] pc_bank;
  hpc_scratchpad #(.NUM_PORTS(P), .CAPACITY_BYTES(CAPACITY_BYTES), .NUM_BANKS(NUM_BANKS), .DATA_WIDTH(DW),
                   .ADDR_WIDTH(AW), .BASE_ADDR(BASE_ADDR), .READ_LATENCY(READ_LATENCY), .BYTE_WE(BYTE_WE),
                   .PORT_MODE(PORT_MODE), .MAP(MAP), .ARB(ARB), .QUEUE_DEPTH(QUEUE_DEPTH),
                   .RSP_FIFO_DEPTH(RSP_FIFO_DEPTH), .WRITE_ACK(WRITE_ACK), .TAG_W(TAG_W), .ECC_MODE(0),
                   .BACKEND(0), .MACRO(0), .PERF_EN(1), .CNT_W(32)) dut (
    .clk, .rst_n, .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wstrb, .req_tag,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_err_code, .rsp_we, .rsp_tag, .rsp_ecc_syn,
    .ev_accept, .ev_issue, .ev_conflict, .ev_credit_stall, .ev_error, .ev_ecc_err(ev_ecc), .ev_bank_ops,
    .ev_bank_conflict, .perf_clear(1'b0), .perf_cycles(pc_cycles), .perf_accept(pc_acc), .perf_issue(pc_iss),
    .perf_complete(pc_cpl), .perf_conflict(pc_cfl), .perf_wait(pc_wait), .perf_error(pc_err),
    .perf_bank_ops(pc_bank), .perf_ecc_err(pc_ecc), .busy);

  logic [31:0] e_req [P], e_rsp [P], e_con [P];
  for (genvar p = 0; p < P; p++) begin : g_chk
    logic [31:0] x0, x1, x2, x3, x4;
    hpc_rv_checker #(.NAME("spm_req"), .W(1 + AW + DW + NB + TAG_W), .RESET_LOW(1'b0)) chk_req (
      .clk, .rst_n, .valid(req_valid[p]), .ready(req_ready[p]),
      .payload({req_we[p], req_addr[p*AW +: AW], req_wdata[p*DW +: DW], req_wstrb[p*NB +: NB], req_tag[p*TAG_W +: TAG_W]}),
      .err_cnt(e_req[p]), .xfer_cnt(x0));
    hpc_rv_checker #(.NAME("spm_rsp"), .W(DW + 1 + 3 + 1 + TAG_W), .RESET_LOW(1'b1),
                     .XCHK_MASK({{DW{1'b0}}, {(5 + TAG_W){1'b1}}})) chk_rsp (
      .clk, .rst_n, .valid(rsp_valid[p]), .ready(rsp_ready[p]),
      .payload({rsp_rdata[p*DW +: DW], rsp_err[p], rsp_err_code[p*3 +: 3], rsp_we[p], rsp_tag[p*TAG_W +: TAG_W]}),
      .err_cnt(e_rsp[p]), .xfer_cnt(x1));
    if (WRITE_ACK != 0) begin : g_cons
      hpc_txn_conservation #(.NAME("spm_port"),
                             .MAX_OUT(QUEUE_DEPTH + ((RSP_FIFO_DEPTH > 0) ? RSP_FIFO_DEPTH : READ_LATENCY) + 1)) cons (
        .clk, .rst_n, .acc(req_valid[p] && req_ready[p]), .cpl(rsp_valid[p] && rsp_ready[p]),
        .outstanding(x2), .err_cnt(e_con[p]), .acc_total(x3), .cpl_total(x4));
    end else begin : g_nocons
      assign e_con[p] = '0;
    end
  end
  always_comb begin
    chk_err = '0;
    for (int p = 0; p < P; p++) chk_err = chk_err + e_req[p] + e_rsp[p] + e_con[p];
  end
endmodule
`default_nettype wire
