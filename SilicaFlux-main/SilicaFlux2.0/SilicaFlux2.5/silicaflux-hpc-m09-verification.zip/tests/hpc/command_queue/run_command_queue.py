#!/usr/bin/env python3
"""Command-queue suite (brief §7).

Verified: the two command queues that exist in the RTL -- the vector-array
command queue (Module 03) and the DMA descriptor queue (Module 05): queue full,
queue empty, mixed command sequences, invalid opcodes / descriptors,
completion ordering under back-pressure.

BLOCKED (recorded, never counted as passed): FENCE semantics and inter-command
dependency tracking.  No SilicaFlux-HPC RTL implements a tile command processor
with FENCE (there is no Module 06 archive; Module 05's hpc_tile_vseq is a
serial reference sequencer without a command set).  The executable contract
(reference_models/cmdq_model.py check_trace, rules F1-F4, D1) is self-tested
here so it is ready to bind to that RTL when it exists.
usage: run_command_queue.py [--matrix ci|nightly] [--only SUBSTR] [--seed N]
"""
from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import cocorun, results as R, sim  # noqa: E402
import filelists as FL  # noqa: E402
from reference_models import cmdq_model as CQ  # noqa: E402

SUITE = "command_queue"
VA = dict(VL_W=16, TID_W=8, CMD_DEPTH=4, TRK_DEPTH=8, CPL_DEPTH=4, RED_EN=1, RED_LAT=3, LANE_ROB_DEPTH=8,
          LAT_FADD=3, LAT_FMUL=3, LAT_FMA=4, LAT_MISC=1, LAT_IMUL=2, EN_FCMP=1, EN_INT=1, NUM_LANES=2)
DM = dict(ENGINE=0, FIFO_DEPTH=8, BURST=8, DUAL_PORT=0, MAX_OUT=2, CMD_DEPTH=2, CPL_DEPTH=2, FAB_SLICE=0,
          SPM_BANKS=4, SPM_RL=1, SPM_QD=0, SPM_BYTES=65536)
VA_CFG = {"va_n2_q4": dict(VA), "va_n4_q1_c1": dict(VA, NUM_LANES=4, CMD_DEPTH=1, CPL_DEPTH=1),
          "va_n2_q8_c8": dict(VA, CMD_DEPTH=8, CPL_DEPTH=8), "va_n8_q2": dict(VA, NUM_LANES=8, CMD_DEPTH=2)}
DM_CFG = {"dma_q2_c2": dict(DM), "dma_q0_c2": dict(DM, CMD_DEPTH=0), "dma_q8_c4_buf": dict(DM, CMD_DEPTH=8,
                                                                                            CPL_DEPTH=4, ENGINE=1)}
VA_TESTS = ["test_queue_full", "test_queue_empty", "test_mixed_sequence", "test_invalid_opcodes",
            "test_completion_backpressure"]
DM_TESTS = ["test_queue_full", "test_queue_empty", "test_mixed_sequence"]
MATRIX = {"ci": dict(va=["va_n2_q4", "va_n4_q1_c1"], dm=["dma_q2_c2", "dma_q0_c2"], seeds=1),
          "nightly": dict(va=list(VA_CFG), dm=list(DM_CFG), seeds=3)}

BLOCKED = [
    ("fence/F1_no_start_before_predecessors_complete",
     "No RTL implements FENCE: there is no tile command processor (no Module 06 archive in the repository)."),
    ("fence/F2_fence_completion_ordering", "No RTL implements FENCE (see F1)."),
    ("dependencies/D1_raw_war_waw_between_commands",
     "No RTL tracks dependencies between tile commands: hpc_vector_array is a streaming unit without "
     "addresses; hpc_tile_vseq (M05) runs one job at a time and has no command set."),
    ("dependencies/cross_unit_dma_compute_overlap",
     "No hardware scheduler overlaps DMA and compute commands; ordering between them is the host's job today "
     "(exercised by tile_integration kernel F, sequenced by the testbench)."),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--only", default="")
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    sim.ensure_rtl()
    sim.ensure_ref()
    print(f"== command_queue suite, matrix {a.matrix}")
    # the FENCE / dependency contract checker must itself work (non-vacuity) before it can gate RTL
    t0 = time.time()
    st = CQ.self_test()
    R.record(SUITE, "model/fence_trace_checker_selftest", "PASS" if not st else "FAIL", duration=time.time() - t0,
             metrics={"problems": st}, simulator="python",
             repro="python3 -c 'from reference_models import cmdq_model as m; print(m.self_test())'")
    print(f"  [{'PASS' if not st else 'FAIL'}] command_queue/model/fence_trace_checker_selftest")
    for name, why in BLOCKED:
        R.blocked(SUITE, name, why, plan="bind reference_models/cmdq_model.check_trace to the processor's "
                                         "accept/start/complete events once the RTL exists")
        print(f"  [BLOCKED] command_queue/{name}")
    va_src = FL.files("varray") + FL.checker_files() + [HPC / "vector_array/tb_varray_top.sv"]
    for cfg in mx["va"]:
        P = VA_CFG[cfg]
        for si in range(mx["seeds"]):
            cocorun.run_suite(SUITE, cfg, toplevel="tb_varray_top", sources=va_src, test_module="test_cmdq_varray",
                              test_dir=HERE, testcases=[t for t in VA_TESTS if a.only in t], parameters=P,
                              seed=a.seed + si, env={**P, "HPC_NCMD": 120},
                              repro_hint=f"python3 tests/hpc/command_queue/run_command_queue.py --only {{tc}} "
                                         f"--seed {{seed}}  # config {cfg}")
    dm_src = FL.files("dma") + FL.files("df_checker") + FL.checker_files() + [HPC / "dma/tb_dma_top.sv"]
    for cfg in mx["dm"]:
        P = DM_CFG[cfg]
        for si in range(mx["seeds"]):
            cocorun.run_suite(SUITE, cfg, toplevel="tb_dma_top", sources=dm_src, test_module="test_cmdq_dma",
                              test_dir=HERE, testcases=[t for t in DM_TESTS if a.only in t], parameters=P,
                              defines={d: 1 for d in FL.SIM_DEFINES["dma"]}, includes=FL.INCDIRS["dma"],
                              seed=a.seed + si, env=P,
                              repro_hint=f"python3 tests/hpc/command_queue/run_command_queue.py --only {{tc}} "
                                         f"--seed {{seed}}  # config {cfg}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
