"""Command-queue tests of hpc_vector_array (Module 03) through tb_varray_top."""
from __future__ import annotations

import cocotb
from cocotb.triggers import ClockCycles, ReadOnly, RisingEdge

from hpcv.cycle import val
from hpcv.tbutil import env_int, finish, rng
from hpcv.varray_env import CHK, VArrayEnv, gen_cmd, setup
from reference_models import cmdq_model as CQ
from reference_models import fp32_softfloat as SF


@cocotb.test()
async def test_queue_full(dut):
    """operand stream blocked: exactly CMD_DEPTH + 1 commands accepted, then cmd_ready low; drains in order"""
    env = VArrayEnv(dut)
    await setup(dut, env)
    r = rng("full")
    env.opnd.enabled = False
    depth = env.C["CMD_DEPTH"]
    for t in range(depth + 6):
        env.send(gen_cmd(r, env.n, t, ops=[SF.FADD], vl=env.n * 3, red=0, vm_p=0.0))
    await ClockCycles(dut.clk, 40)
    acc = env.cmd_accepted
    want = CQ.varray_queue_full_accepts(depth)
    if acc != want:
        env.eng.error(f"{acc} commands accepted with the operand stream blocked; specification CMD_DEPTH+1 = {want}")
    await ReadOnly()
    if val(dut.cmd_ready):
        env.eng.error("cmd_ready high with a full command queue")
    await RisingEdge(dut.clk)
    env.opnd.enabled = True
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra={"accepted_while_blocked": acc, "expected": want})


@cocotb.test()
async def test_queue_empty(dut):
    """empty queue: cmd_ready high, busy low; vl = 0 commands complete without any beat"""
    env = VArrayEnv(dut)
    await setup(dut, env)
    r = rng("empty")
    await ClockCycles(dut.clk, 3)
    await ReadOnly()
    if not val(dut.cmd_ready) or val(dut.busy):
        env.eng.error("idle array: cmd_ready must be 1 and busy 0")
    await RisingEdge(dut.clk)
    for t in range(6):
        env.send(gen_cmd(r, env.n, t, vl=0, red=t % 2))
    await env.drain()
    await ReadOnly()
    if not val(dut.cmd_ready) or val(dut.busy):
        env.eng.error("after draining: cmd_ready must be 1 and busy 0")
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK)


@cocotb.test()
async def test_mixed_sequence(dut):
    """elementwise, reductions, vl = 0, illegal and broadcast commands interleaved under back-pressure:
    one completion per command, in command order, after its last beat"""
    env = VArrayEnv(dut, cmd_stall="random:0.9", opnd_stall="random:0.6", res_stall="random:0.4",
                    cpl_stall="random:0.3", hold="random:0.85")
    await setup(dut, env)
    r = rng("mixed")
    for t in range(env_int("HPC_NCMD", 120)):
        env.send(gen_cmd(r, env.n, t & 0xFF, red_p=0.3, illegal_p=0.15, max_vl=3 * env.n + 2))
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra={"coverage": env.cov})


@cocotb.test()
async def test_invalid_opcodes(dut):
    """every reserved opcode and every illegal rounding / reduction combination: framing kept, illegal = 1"""
    env = VArrayEnv(dut, res_stall="random:0.7")
    await setup(dut, env)
    r = rng("inv")
    t = 0
    for op in [o for o in range(32) if o not in SF.LEGAL_OPS]:
        env.send(gen_cmd(r, env.n, t & 0xFF, ops=[op], vl=env.n + 1, red=0))
        t += 1
    for op in (1, 3, 4):                                      # rm 5..7 on rounding operations
        c = gen_cmd(r, env.n, t & 0xFF, ops=[op], vl=env.n, red=0)
        c["rm"] = 5 + t % 3
        env.send(c)
        t += 1
    for op in (SF.FEQ, SF.IADD, SF.FMIN):                     # reductions of non-summable operations
        env.send(gen_cmd(r, env.n, t & 0xFF, ops=[op], vl=env.n, red=1))
        t += 1
    c = gen_cmd(r, env.n, t & 0xFF, ops=[SF.FMUL], vl=env.n, red=1)
    c["bcast"] = 1                                            # broadcast with reduction
    env.send(c)
    await env.drain()
    ill = env.cov["illegal"]
    if ill < t:
        env.eng.error(f"only {ill} of {t + 1} illegal commands reported illegal")
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra={"illegal_commands": ill})


@cocotb.test()
async def test_completion_backpressure(dut):
    """completion consumer blocked: the completion queue fills, the array stalls without loss, order kept"""
    env = VArrayEnv(dut)
    await setup(dut, env)
    r = rng("cplbp")
    env.cpl.force_ready = 0
    for t in range(env.C["CPL_DEPTH"] + env.C["CMD_DEPTH"] + 8):
        env.send(gen_cmd(r, env.n, t, vl=r.randint(1, 2 * env.n), red_p=0.3))
    await ClockCycles(dut.clk, 300)
    held = env.cpl.bp_cycles
    if not held:
        env.eng.error("completion back-pressure never observed")
    env.cpl.force_ready = None
    await env.drain()
    finish(env.eng, [env.res_sb, env.cpl_sb], dut, CHK, extra={"cpl_bp_cycles": held})
