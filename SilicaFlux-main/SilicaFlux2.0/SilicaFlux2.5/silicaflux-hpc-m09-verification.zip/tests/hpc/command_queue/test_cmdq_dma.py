"""Descriptor-queue tests of hpc_dma_adapter (Module 05) through tb_dma_top."""
from __future__ import annotations

import cocotb
from cocotb.triggers import ClockCycles, ReadOnly, RisingEdge

from hpcv.cycle import val
from hpcv.dma_env import EXT_BASE, SPM_BASE, DmaEnv, setup
from hpcv.tbutil import publish, rng
from reference_models import cmdq_model as CQ


def end(env, **extra):
    chk = val(env.dut.chk_err)
    if chk:
        env.eng.error(f"protocol checkers: {chk} violation(s)")
    publish({"cycles": env.eng.cycle, "errors": len(env.eng.errors), "descriptors": len(env.results),
             "codes": env.codes, "sv_checker_errors": chk, **extra})
    if env.eng.errors:
        raise AssertionError(f"{len(env.eng.errors)} error(s); first: {env.eng.errors[0]}")


@cocotb.test()
async def test_queue_full(dut):
    """completion consumer blocked: exactly CPL_DEPTH + CMD_DEPTH descriptors accepted, then cmd_ready low"""
    env = DmaEnv(dut, fab_stall="none", cpl_stall="none", cmd_stall="none")
    await setup(dut, env)
    env.cpl.force_ready = 0
    C = env.C
    for t in range(C["CMD_DEPTH"] + C["CPL_DEPTH"] + 4):
        env.desc(EXT_BASE + 0x100 * t, SPM_BASE + 0x100 * t, 16, t)
    await ClockCycles(dut.clk, 600)
    acc = len(env.pending)
    want = CQ.dma_queue_full_accepts(C["CMD_DEPTH"], C["CPL_DEPTH"])
    if acc != want:
        env.eng.error(f"{acc} descriptors accepted with completions blocked; specification {want}")
    await ReadOnly()
    if val(dut.cmd_ready):
        env.eng.error("cmd_ready high although the queues are full")
    await RisingEdge(dut.clk)
    env.cpl.force_ready = None
    await env.drain()
    end(env, accepted_while_blocked=acc, expected=want)


@cocotb.test()
async def test_queue_empty(dut):
    """idle adapter: cmd_ready high (CMD_DEPTH = 0: high only when idle), busy low, no request"""
    env = DmaEnv(dut, fab_stall="none", cpl_stall="none", cmd_stall="none")
    await setup(dut, env)
    await ClockCycles(dut.clk, 4)
    await ReadOnly()
    if not val(dut.cmd_ready) or val(dut.busy) or val(dut.fab_req_valid):
        env.eng.error("idle: cmd_ready must be 1, busy 0, no fabric request")
    await RisingEdge(dut.clk)
    if env.C["CMD_DEPTH"] == 0:
        env.desc(EXT_BASE, SPM_BASE, 0x200, 1)
        for _ in range(400):
            await RisingEdge(dut.clk)
            await ReadOnly()
            if val(dut.active) and val(dut.cmd_ready):
                env.eng.error("CMD_DEPTH = 0: cmd_ready high while a transfer is active")
                break
    await env.drain()
    end(env)


@cocotb.test()
async def test_mixed_sequence(dut):
    """valid / invalid / bus-error descriptors interleaved: one completion each, in acceptance order"""
    env = DmaEnv(dut, fab_stall="random:0.6", cpl_stall="random:0.4", cmd_stall="random:0.7")
    await setup(dut, env)
    r = rng("mix")
    env.spm_fill(r, 0, 0x800)
    await env.drain()
    for t in range(40):
        k = r.randrange(6)
        if k == 0:
            env.desc(EXT_BASE + 4 * r.randrange(64), SPM_BASE + 0x1000 + 0x40 * (t % 16), r.randint(1, 60), t)
        elif k == 1:
            env.desc(SPM_BASE + 4 * r.randrange(64), EXT_BASE + 0x4000 + 0x40 * t, r.randint(1, 60), t)
        elif k == 2:
            env.desc(EXT_BASE + 1, SPM_BASE, 8, t)                               # SRC_ALIGN
        elif k == 3:
            env.desc(EXT_BASE, EXT_BASE + 4, 16, t)                              # OVERLAP
        elif k == 4:
            env.desc(0x1000FFF0, SPM_BASE + 0x2000, 0x40, t)                     # READ_BUS (error window)
        else:
            env.desc(EXT_BASE, EXT_BASE + 0x8000, 0, t)                          # ZERO_LENGTH
    await env.drain()
    env.spm_check(0x1000, 0x400)
    await env.drain()
    end(env)
