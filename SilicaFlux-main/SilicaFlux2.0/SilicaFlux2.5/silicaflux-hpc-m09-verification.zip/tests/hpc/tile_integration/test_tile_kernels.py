"""Integrated SilicaFlux-HPC tile kernels (brief §8) through tb_tile_top.

Data path of every kernel: the host writes operands into host-visible memory ->
DMA (Module 05) into the scratchpad (Module 04) -> hpc_tile_vseq streams them
through the vector array (Module 03) -> results back into the scratchpad ->
DMA out -> the final host memory and the whole scratchpad region used are
compared byte by byte with golden images computed by SoftFloat-3e; the
completion status (flags, counts, illegal, error) of every vector job and DMA
descriptor is compared; at the end the Module 07 counters are cross-checked
against what the scoreboards saw (bytes moved, element operations, FLOPs,
commands).

Datasets are deterministic: generated from the kernel name and HPC_SEED.
"""
from __future__ import annotations

import cocotb
from cocotb.triggers import ClockCycles, RisingEdge

from hpcv import fpgen
from hpcv.cycle import Sink, Source, val
from hpcv.dma_env import EXT_BASE, SPM_BASE, DmaEnv, setup
from hpcv.stall import Stall
from hpcv.tbutil import env_int, env_str, publish, rng, seed
from reference_models import fp32_softfloat as SF

FLOPS = {SF.FADD: 1, SF.FSUB: 1, SF.FMUL: 1, SF.FMADD: 2, SF.FMSUB: 2, SF.FNMSUB: 2, SF.FNMADD: 2}
# Module 07 counter indices (docs/02_register_map.md §3)
C_CYCLES, C_CMD_ACC, C_CMD_CPL, C_VEC_ISS, C_VEC_RET, C_FLOPS, C_DMA_RD, C_DMA_WR = 0, 1, 2, 3, 4, 5, 8, 9
C_VEC_STALL, C_DMA_ACTIVE, C_OUT_BP, C_HW_ERR, C_VEC_BUSY, C_STARVE, C_INFL, C_RED, C_VEC_CPL = 6, 7, 14, 15, 16, 17, \
    18, 21, 22


class TileEnv(DmaEnv):
    def __init__(self, dut, **kw):
        super().__init__(dut, **kw)
        s = seed()
        self.N = env_int("N", 4)
        self.job = self.eng.add(Source(dut, "job_valid", "job_ready",
                                       {k: f"job_{k}" for k in ("op", "rm", "vl", "bcast", "scalar", "a", "b", "c", "d",
                                                                "tid")},
                                       stall=Stall("none", s + 7), on_accept=self._job_acc, name="job"))
        self.done = self.eng.add(Sink(dut, "done_valid", "done_ready",
                                      {k: f"done_{k}" for k in ("tid", "flags", "illegal", "count", "err")},
                                      stall=Stall(env_str("HPC_DONE_STALL", "random:0.7"), s + 8), on_item=self._done,
                                      name="done"))
        self.jobs = []
        self.done_tids = set()
        self.dma_done_tags = set()
        self.truth = dict(vec_cmds=0, elems=0, flops=0, dma_cmds=0, dma_rd=0, dma_wr=0)
        self.kernel_log = []
        hold = env_str("HPC_HOLD", "random:0.9")
        self.hold_lane = [Stall(hold, s + 30 + i) for i in range(self.N)] if hold != "none" else None
        self.eng.hooks_edge.append(self._drive_hold)
        self.eng.hooks_sample.append(self._cycle_truth)
        self.ct = dict(out_bp=0, vec_busy=0, dma_active=0, vec_stall=0, starve=0, hw_err=0, inflight_sum=0,
                       vec_cpl=0)
        self.inflight = 0
        dut.lane_hold.value = 0
        dut.rb_sel.value = 0

    def _drive_hold(self, cyc):
        if self.hold_lane is None or self.eng.in_reset:
            return
        self.dut.lane_hold.value = sum((0 if st() else 1) << i for i, st in enumerate(self.hold_lane))

    def _cycle_truth(self, cyc):
        """per-cycle truth for the Module 07 cycle / sum counters, from the documented handshakes
        (docs/03_event_definitions.md): OUT_BP, VEC_BUSY, DMA_ACTIVE, VEC_STALL, VEC_OPND_STARVE,
        HW_ERRORS, CMD_INFLIGHT_SUM, VEC_CMD_COMPLETED"""
        if self.eng.in_reset:
            return
        d, t = self.dut, self.ct
        rv, rr, kv, kr = val(d.r_valid), val(d.r_ready), val(d.k_valid), val(d.k_ready)
        dv, dr = val(d.cpl_valid), val(d.cpl_ready)
        t["out_bp"] += int((rv and not rr) or (kv and not kr) or (dv and not dr))
        t["vec_busy"] += val(d.va_busy)
        t["dma_active"] += val(d.active)
        st = val(d.ob_stl) | val(d.ob_stt) | val(d.ob_starve)
        t["vec_stall"] += st
        t["starve"] += val(d.ob_starve)
        kf, df = kv and kr, dv and dr
        t["hw_err"] += int(kf and val(d.k_ill)) + int(df and val(d.cpl_err)) + val(d.ev_bus_err) + \
            val(d.ev_tag_err) + bin(val(d.sp_err)).count("1") + bin(val(d.sp_ecc)).count("1")
        t["vec_cpl"] += int(kf)
        t["inflight_sum"] += self.inflight             # commands in flight at the start of this cycle
        self.inflight += int(val(d.c_valid) and val(d.c_ready)) + int(val(d.cmd_valid) and val(d.cmd_ready)) \
            - int(kf) - int(df)

    # ------------------------------------------------------------ host memory
    def host_write(self, a, words):
        for i, w in enumerate(words):
            self.ext.wword(a + 4 * i, w, 0xF)
            self.ext_exp.wword(a + 4 * i, w, 0xF)

    def host_read(self, a, n):
        return [self.ext.rword(a + 4 * i) for i in range(n)]

    def spm_word(self, a):
        o = a - SPM_BASE
        return sum(self.spm_exp[o + i] << (8 * i) for i in range(4))

    # ------------------------------------------------------------ jobs
    def job_send(self, op, rm, vl, a, b=0, c=0, d=0, bcast=0, scalar=0, tid=0):
        self.job.send({"op": op, "rm": rm, "vl": vl, "bcast": bcast, "scalar": scalar, "a": a, "b": b, "c": c,
                       "d": d, "tid": tid & 0xFF})

    def _job_acc(self, it, cyc):
        """predict the job from the golden scratchpad image at acceptance (operands are already in place)"""
        res, fl, ill = [], 0, 0
        op = it["op"]
        # hpc_tile_vseq loads operand x iff the operation reads it and bcast[x] = 0
        # (a: every op; b: every op but FMV; c: the FMA family); unread operands are irrelevant
        rd_b, rd_c = op != SF.FMV, 4 <= op <= 7
        for e in range(it["vl"]):
            x = it["scalar"] if it["bcast"] & 1 else self.spm_word(it["a"] + 4 * e)
            y = it["scalar"] if it["bcast"] & 2 else (self.spm_word(it["b"] + 4 * e) if rd_b else 0)
            z = it["scalar"] if it["bcast"] & 4 else (self.spm_word(it["c"] + 4 * e) if rd_c else 0)
            r, f, il = SF.op(it["op"], it["rm"], x, y, z)
            ill |= il
            res.append(r)
            fl |= f
        if ill:
            res, fl = [], 0
        self.jobs.append((it, res, fl, ill))

    def _done(self, it, cyc):
        if not self.jobs:
            self.eng.error(f"vseq done record without a job: {it}")
            return
        job, res, fl, ill = self.jobs.pop(0)
        exp = {"tid": job["tid"], "flags": fl, "illegal": ill, "count": 0 if ill else job["vl"], "err": 0}
        if it != exp:
            self.eng.error(f"job {job['tid']} ({SF.OP_NAMES.get(job['op'], job['op'])}): done {it}, expected {exp}")
        for e, r in enumerate(res):                       # results are now in the scratchpad
            o = job["d"] - SPM_BASE + 4 * e
            for i in range(4):
                self.spm_exp[o + i] = (r >> (8 * i)) & 0xFF
                self.spm_known[o + i] = 1
        self.done_tids.add(job["tid"])
        if not ill:
            self.truth["vec_cmds"] += 1
            self.truth["elems"] += job["vl"]
            self.truth["flops"] += job["vl"] * FLOPS.get(job["op"], 0)
        else:
            self.truth["vec_cmds"] += 1

    def _cpl(self, it, cyc):
        super()._cpl(it, cyc)
        d, got = self.results[-1]
        self.dma_done_tags.add(got["tag"])
        self.truth["dma_cmds"] += 1
        if got["code"] == 0:
            self.truth["dma_wr"] += d["len"]
            self.truth["dma_rd"] += 4 * ((d["len"] + 3) // 4)

    async def wait_jobs(self, tids, limit=500000):
        for _ in range(limit):
            if set(tids) <= self.done_tids:
                return
            await RisingEdge(self.dut.clk)
        self.eng.error(f"jobs {sorted(set(tids) - self.done_tids)} never completed")

    async def wait_dma(self, tags, limit=500000):
        for _ in range(limit):
            if set(tags) <= self.dma_done_tags:
                return
            await RisingEdge(self.dut.clk)
        self.eng.error(f"DMA descriptors {sorted(set(tags) - self.dma_done_tags)} never completed")

    def idle(self):
        return super().idle() and self.job.idle() and not self.jobs and self.done.pending is None

    # ------------------------------------------------------------ counters
    def counters(self):
        v = int(self.dut.perf_cnt.value)
        return [(v >> (64 * i)) & ((1 << 64) - 1) for i in range(23)]

    async def cross_check_counters(self):
        await ClockCycles(self.dut.clk, 6)                   # EV_REG: events reach the counters one cycle late
        c = self.counters()
        t = self.truth
        want = {"CMD_ACCEPTED": (c[C_CMD_ACC], t["vec_cmds"] + t["dma_cmds"]),
                "CMD_COMPLETED": (c[C_CMD_CPL], t["vec_cmds"] + t["dma_cmds"]),
                "VEC_ISSUED": (c[C_VEC_ISS], t["elems"]), "VEC_RETIRED": (c[C_VEC_RET], t["elems"]),
                "FLOPS_RETIRED": (c[C_FLOPS], t["flops"]), "DMA_BYTES_RD": (c[C_DMA_RD], t["dma_rd"]),
                "DMA_BYTES_WR": (c[C_DMA_WR], t["dma_wr"])}
        for k, (got, exp) in want.items():
            if got != exp:
                self.eng.error(f"Module 07 counter {k} = {got}, scoreboards observed {exp}")
        ct = self.ct
        want.update({"OUT_BP": (c[C_OUT_BP], ct["out_bp"]), "VEC_BUSY": (c[C_VEC_BUSY], ct["vec_busy"]),
                     "DMA_ACTIVE": (c[C_DMA_ACTIVE], ct["dma_active"]), "VEC_STALL": (c[C_VEC_STALL], ct["vec_stall"]),
                     "VEC_OPND_STARVE": (c[C_STARVE], ct["starve"]), "HW_ERRORS": (c[C_HW_ERR], ct["hw_err"]),
                     "CMD_INFLIGHT_SUM": (c[C_INFL], ct["inflight_sum"]), "RED_ADDS": (c[C_RED], 0),
                     "VEC_CMD_COMPLETED": (c[C_VEC_CPL], ct["vec_cpl"])})
        for k in ("OUT_BP", "VEC_BUSY", "DMA_ACTIVE", "VEC_STALL", "VEC_OPND_STARVE", "HW_ERRORS", "CMD_INFLIGHT_SUM",
                  "RED_ADDS", "VEC_CMD_COMPLETED"):
            got, exp = want[k]
            if got != exp:
                self.eng.error(f"Module 07 counter {k} = {got}, handshakes observed {exp}")
        cyc = c[C_CYCLES]
        if not (self.eng.cycle - 8 <= cyc <= self.eng.cycle + 2):
            self.eng.error(f"CYCLES counter {cyc} vs {self.eng.cycle} clock edges since reset release")
        return {k: v[0] for k, v in want.items()} | {"CYCLES": cyc}


def operands(r, n, kind="mixed"):
    if kind == "scaled":                         # well-conditioned values (finite, no overflow)
        return [(r.getrandbits(1) << 31) | (r.randint(110, 140) << 23) | r.getrandbits(23) for _ in range(n)]
    return [fpgen.operand(r) if r.random() < 0.5 else
            (r.getrandbits(1) << 31) | (r.randint(100, 150) << 23) | r.getrandbits(23) for _ in range(n)]


async def finish_kernel(env, name, **extra):
    await env.drain()
    env.spm_check(0, 0x8000)                     # every known scratchpad byte of the working area
    await env.drain()
    cnt = await env.cross_check_counters()
    chk = val(env.dut.chk_err)
    if chk:
        env.eng.error(f"tile protocol / conservation checkers: {chk} violation(s)")
    bad = env.check_ext_full()
    publish({"kernel": name, "cycles": env.eng.cycle, "errors": len(env.eng.errors), "jobs": env.truth["vec_cmds"],
             "dma_descriptors": env.truth["dma_cmds"], "elements": env.truth["elems"], "flops": env.truth["flops"],
             "counters": cnt, "dma_codes": env.codes, "ext_bytes_wrong": bad, "sv_checker_errors": chk, **extra})
    if env.eng.errors:
        raise AssertionError(f"{len(env.eng.errors)} error(s); first: {env.eng.errors[0]}")


async def elementwise_kernel(dut, name, op, rm, n, nops):
    env = TileEnv(dut)
    await setup(dut, env)
    r = rng(name)
    X, Y, Z = operands(r, n), operands(r, n), operands(r, n)
    ea, eb, ec, ed = EXT_BASE, EXT_BASE + 0x1000, EXT_BASE + 0x2000, EXT_BASE + 0x3000
    sa, sb, sc, sd = SPM_BASE, SPM_BASE + 0x1000, SPM_BASE + 0x2000, SPM_BASE + 0x3000
    env.host_write(ea, X)
    env.host_write(eb, Y)
    env.host_write(ec, Z)
    tags = [1, 2, 3][:nops]
    for t, (e, s) in zip(tags, [(ea, sa), (eb, sb), (ec, sc)]):
        env.desc(e, s, 4 * n, t)
    await env.wait_dma(tags)
    env.job_send(op, rm, n, sa, sb, sc, sd, tid=10)
    await env.wait_jobs([10])
    env.desc(sd, ed, 4 * n, 20)
    await env.wait_dma([20])
    await finish_kernel(env, name, n=n, op=SF.OP_NAMES[op], rm=rm)


@cocotb.test()
async def test_A_vector_add(dut):
    """A: Z = X + Y  (FADD, RNE), n not a multiple of N"""
    await elementwise_kernel(dut, "A_vadd", SF.FADD, 0, env_int("HPC_N_ELEM", 257), 2)


@cocotb.test()
async def test_B_vector_mul(dut):
    """B: Z = X * Y  (FMUL, RTZ)"""
    await elementwise_kernel(dut, "B_vmul", SF.FMUL, 1, env_int("HPC_N_ELEM", 257), 2)


@cocotb.test()
async def test_C_vector_fma(dut):
    """C: Z = X * Y + W  (FMADD, single rounding, RDN)"""
    await elementwise_kernel(dut, "C_vfma", SF.FMADD, 2, env_int("HPC_N_ELEM", 257), 3)


@cocotb.test()
async def test_E_dma_assisted_axpy(dut):
    """E: Y := alpha * X + Y over T tiles, double-buffered: DMA-in of tile k+1 and DMA-out of tile k-1
    overlap the computation of tile k (DMA and sequencer contend for the scratchpad banks)"""
    env = TileEnv(dut)
    await setup(dut, env)
    r = rng("E_axpy")
    T, L = env_int("HPC_TILES", 6), env_int("HPC_TILE_LEN", 64)
    alpha = 0x3FC00000                                    # 1.5
    X = operands(r, T * L, "scaled")
    Y = operands(r, T * L, "scaled")
    ex, ey, eo = EXT_BASE, EXT_BASE + 0x2000, EXT_BASE + 0x4000
    env.host_write(ex, X)
    env.host_write(ey, Y)
    buf = lambda k, which: SPM_BASE + 0x4000 * (k % 2) + 0x1000 * which          # which: 0 X, 1 Y, 2 out
    tag = 0

    def load(k):
        nonlocal tag
        t0, t1 = tag, tag + 1
        tag += 2
        env.desc(ex + 4 * L * k, buf(k, 0), 4 * L, t0)
        env.desc(ey + 4 * L * k, buf(k, 1), 4 * L, t1)
        return [t0, t1]

    pending_load = load(0)
    out_tags = []
    for k in range(T):
        await env.wait_dma(pending_load)
        env.job_send(SF.FMADD, 3, L, buf(k, 0), buf(k, 0), buf(k, 1), buf(k, 2), bcast=0b010, scalar=alpha,
                     tid=50 + k)                         # a = X, b = alpha (broadcast), c = Y   (RUP)
        if k + 1 < T:
            if k >= 1:
                await env.wait_dma(out_tags[-1:])        # buffer of tile k+1 = buffer of tile k-1: drained?
            pending_load = load(k + 1)                   # overlaps the computation of tile k
        await env.wait_jobs([50 + k])
        env.desc(buf(k, 2), eo + 4 * L * k, 4 * L, 200 + k)    # overlaps the next load / computation
        out_tags.append(200 + k)
    await env.wait_dma(out_tags)
    await finish_kernel(env, "E_axpy", tiles=T, tile_len=L)


@cocotb.test()
async def test_F_multi_command_sequence(dut):
    """F: dependent memory / compute chain with every rounding mode and an integer op:
         D = A*B + C (FMADD, RNE)   E = D - A (FSUB, RTZ; reads D: RAW in the scratchpad)
         F = E * s (FMUL with broadcast scalar, RMM)   G = A *int B (IMUL)   H = min(D, E) (FMIN)
         K = -(A*B) + C (FNMSUB, RUP)   + an illegal job (reserved opcode) in the middle
       then DMA out D, E (partial final word), F, G, H, K and compare everything"""
    env = TileEnv(dut)
    await setup(dut, env)
    r = rng("F_chain")
    n = env_int("HPC_N_ELEM", 257)
    A, B, C = operands(r, n), operands(r, n), operands(r, n)
    sp = lambda i: SPM_BASE + 0x0800 * i
    for i, V in enumerate((A, B, C)):
        env.host_write(EXT_BASE + 0x0800 * i, V)
        env.desc(EXT_BASE + 0x0800 * i, sp(i), 4 * n, i)
    await env.wait_dma([0, 1, 2])
    s = 0xC0490FDB                                       # -pi
    env.job_send(SF.FMADD, 0, n, sp(0), sp(1), sp(2), sp(3), tid=1)
    await env.wait_jobs([1])
    env.job_send(SF.FSUB, 1, n, sp(3), sp(0), 0, sp(4), tid=2)
    env.job_send(0x0D, 0, n, sp(0), sp(1), 0, sp(9), tid=3)          # reserved opcode: illegal, nothing written
    await env.wait_jobs([2, 3])
    env.job_send(SF.FMUL, 4, n, sp(4), 0, 0, sp(5), bcast=0b010, scalar=s, tid=4)
    env.job_send(SF.IMUL, 0, n, sp(0), sp(1), 0, sp(6), tid=5)
    env.job_send(SF.FMIN, 0, n, sp(3), sp(4), 0, sp(7), tid=6)
    env.job_send(SF.FNMSUB, 3, n, sp(0), sp(1), sp(2), sp(8), tid=7)
    await env.wait_jobs([4, 5, 6, 7])
    outs = [(3, 4 * n), (4, 4 * n - 3), (5, 4 * n), (6, 4 * n), (7, 4 * n - 1), (8, 4 * n)]
    for k, (i, ln) in enumerate(outs):
        env.desc(sp(i), EXT_BASE + 0x8000 + 0x0800 * k, ln, 100 + k)
    await env.wait_dma([100 + k for k in range(len(outs))])
    await finish_kernel(env, "F_chain", n=n)
