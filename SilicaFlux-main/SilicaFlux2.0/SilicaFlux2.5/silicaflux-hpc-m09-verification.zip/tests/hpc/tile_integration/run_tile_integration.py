#!/usr/bin/env python3
"""Tile-integration suite: complete kernels on the integrated tile (brief §8).

Kernels A (vector add), B (vector multiply), C (vector FMA), E (DMA-assisted,
double-buffered AXPY), F (dependent multi-command memory/compute chain).
Kernel D (dot product) is BLOCKED at tile level: the reduction is implemented
in the vector array (verified by vector_array/test_reduction against the
specified summation order), but no RTL path drives it from the scratchpad --
hpc_tile_vseq ties cmd_red_i to 0.
usage: run_tile_integration.py [--matrix ci|nightly] [--sim verilator|icarus] [--config NAME] [--only SUBSTR] [--seed N]
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import cocorun, results as R, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "tile_integration"
B = dict(N=4, ENGINE=0, DUAL_PORT=0, MAX_OUT=2, FIFO_DEPTH=8, CMD_DEPTH=4, VA_CMD_DEPTH=4, SPM_BANKS=4)
CONFIGS = {
    "n4_simple": dict(B),
    "n2_buffered": dict(B, N=2, ENGINE=1, MAX_OUT=2),
    "n8_dualport": dict(B, N=8, ENGINE=1, DUAL_PORT=1, MAX_OUT=4, SPM_BANKS=8),
    "n1_spm2": dict(B, N=1, SPM_BANKS=2, VA_CMD_DEPTH=1, CMD_DEPTH=0),
}
TESTS = ["test_A_vector_add", "test_B_vector_mul", "test_C_vector_fma", "test_E_dma_assisted_axpy",
         "test_F_multi_command_sequence"]
MATRIX = {
    "ci": dict(configs=["n4_simple", "n2_buffered"], seeds=1, n_elem=257, tiles=4, tile_len=64,
               icarus_cfg=["n4_simple"], icarus=["test_C_vector_fma"]),
    "nightly": dict(configs=list(CONFIGS), seeds=2, n_elem=1027, tiles=8, tile_len=256,
                    icarus_cfg=["n4_simple", "n2_buffered"], icarus=TESTS),
}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=list(MATRIX))
    ap.add_argument("--sim", default=None, choices=["verilator", "icarus"])
    ap.add_argument("--only", default="")
    ap.add_argument("--config", action="append")
    ap.add_argument("--seed", type=int, default=int(os.environ.get("HPC_SEED", "1")))
    a = ap.parse_args()
    mx = MATRIX[a.matrix]
    sim.ensure_rtl()
    sim.ensure_ref()
    print(f"== tile_integration suite, matrix {a.matrix}")
    if "D" in a.only or not a.only:
        R.blocked(SUITE, "kernel/D_dot_product_tile_level",
                  "The dot product (FMUL + sum reduction) is implemented in hpc_vector_array and verified there "
                  "(vector_array test_reduction, FMUL/red), but no tile RTL can launch it from the scratchpad: "
                  "hpc_tile_vseq drives cmd_red_i = 1'b0 and has no reduction result path.",
                  plan="enable when a vector load/store unit or sequencer with reduction support exists")
        print("  [BLOCKED] tile_integration/kernel/D_dot_product_tile_level")
    srcs = FL.files("tile") + FL.files("df_checker") + FL.checker_files() + [HERE / "tb_tile_top.sv"]
    inc = FL.INCDIRS["tile"]
    defs = {d: 1 for d in FL.SIM_DEFINES["tile"]}
    runs = []
    if a.sim in (None, "verilator"):
        runs += [(c, "verilator", [t for t in TESTS if a.only in t]) for c in (a.config or mx["configs"])]
    if a.sim in (None, "icarus"):
        runs += [(c, "icarus", [t for t in mx["icarus"] if a.only in t]) for c in (a.config or mx["icarus_cfg"])]
    for cfg, s, tests in runs:
        P = CONFIGS[cfg]
        if not tests:
            continue
        for si in range(mx["seeds"] if s == "verilator" else 1):
            env = {**P, "HPC_N_ELEM": mx["n_elem"] if s == "verilator" else 65, "HPC_TILES": mx["tiles"],
                   "HPC_TILE_LEN": mx["tile_len"] if s == "verilator" else 32,
                   "ENGINE": P["ENGINE"], "DUAL_PORT": P["DUAL_PORT"], "MAX_OUT": P["MAX_OUT"],
                   "CMD_DEPTH": P["CMD_DEPTH"], "CPL_DEPTH": 4, "SPM_BYTES": 65536}
            cocorun.run_suite(SUITE, cfg, toplevel="tb_tile_top", sources=srcs, test_module="test_tile_kernels",
                              test_dir=HERE, testcases=tests, parameters=P, defines=defs, includes=inc, sim=s,
                              seed=a.seed + si, env=env,
                              repro_hint=f"python3 tests/hpc/tile_integration/run_tile_integration.py --sim {{sim}} "
                                         f"--config {cfg} --only {{tc}} --seed {{seed}}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
