// =============================================================================
// SilicaFlux-HPC verification :: tb_tile_top -- integrated compute tile for kernels
//
// Real RTL, unmodified:
//   hpc_vector_array (Module 03, with the Module 07 observation port, proven equivalent)
//   hpc_tile_vseq    (Module 05 reference load/store sequencer)  scratchpad port 0
//   hpc_dma_adapter  (Module 05)                                 scratchpad port(s) 1..NP
//   hpc_scratchpad   (Module 04, 0x2000_0000)                    port NP+1 = testbench
//   hpc_perf_tile    (Module 07 telemetry unit: events + 64-bit counter bank)
// Host-visible memory: the cocotb SFB2 slave model on the adapter's fabric port(s)
// (the DataFabric crossbar is verified by DataFabric / Module 05 and not instanced).
// Signal names of the DMA side match tb_dma_top so lib/hpcv/dma_env.py is reused.
// Checkers: sfb_protocol_checker (DataFabric) on the fabric link(s); hpc_rv_checker
// on every internal sequencer <-> array channel, the job / done channel and the
// DMA descriptor / completion channel; one completion per vector command and per
// DMA descriptor.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_perf_defs.svh"
module tb_tile_top #(
  parameter int N            = 4,
  parameter int ENGINE       = 0,
  parameter int DUAL_PORT    = 0,
  parameter int MAX_OUT      = 2,
  parameter int FIFO_DEPTH   = 8,
  parameter int CMD_DEPTH    = 4,
  parameter int VA_CMD_DEPTH = 4,
  parameter int SPM_BANKS    = 4,
  parameter logic [31:0] SPM_BASE = 32'h2000_0000,
  localparam int SPMB = 65536,
  localparam int NP   = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1,
  localparam int NSP  = 1 + NP + 1,
  localparam int NC   = `HPC_PERF_NUM_CNT,
  localparam int TW   = 8
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // vector jobs (hpc_tile_vseq)
  input  wire logic             job_valid,
  output logic                  job_ready,
  input  wire logic [4:0]       job_op,
  input  wire logic [2:0]       job_rm,
  input  wire logic [15:0]      job_vl,
  input  wire logic [2:0]       job_bcast,
  input  wire logic [31:0]      job_scalar, job_a, job_b, job_c, job_d,
  input  wire logic [7:0]       job_tid,
  output logic                  done_valid,
  input  wire logic             done_ready,
  output logic [7:0]            done_tid,
  output logic [4:0]            done_flags,
  output logic                  done_illegal,
  output logic [15:0]           done_count,
  output logic                  done_err,
  output logic                  vseq_busy,
  input  wire logic [N-1:0]     lane_hold,
  // DMA descriptors (names as tb_dma_top)
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [31:0]      cmd_src, cmd_dst, cmd_len,
  input  wire logic [7:0]       cmd_tag,
  input  wire logic             cmd_abort,
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [7:0]            cpl_tag,
  output logic                  cpl_err,
  output logic [3:0]            cpl_code,
  output logic [31:0]           cpl_err_addr, cpl_bytes,
  output logic                  busy, active,
  output logic [NP-1:0]         fab_req_valid,
  input  wire logic [NP-1:0]    fab_req_ready,
  output logic [NP-1:0]         fab_req_write,
  output logic [NP*32-1:0]      fab_req_addr,
  output logic [NP*32-1:0]      fab_req_wdata,
  output logic [NP*4-1:0]       fab_req_wstrb,
  input  wire logic [NP-1:0]    fab_rsp_valid,
  output logic [NP-1:0]         fab_rsp_ready,
  input  wire logic [NP*32-1:0] fab_rsp_rdata,
  input  wire logic [NP-1:0]    fab_rsp_error,
  input  wire logic             tb_req_valid,
  output logic                  tb_req_ready,
  input  wire logic             tb_req_we,
  input  wire logic [31:0]      tb_req_addr, tb_req_wdata,
  input  wire logic [3:0]       tb_req_wstrb,
  input  wire logic [TW-1:0]    tb_req_tag,
  output logic                  tb_rsp_valid,
  input  wire logic             tb_rsp_ready,
  output logic [31:0]           tb_rsp_rdata,
  output logic                  tb_rsp_err,
  output logic                  tb_rsp_we,
  output logic [TW-1:0]         tb_rsp_tag,
  output logic [NP-1:0]         mon_spm_rsp_fire, mon_spm_rsp_we, mon_spm_req_fire,
  output logic                  ev_cpl, ev_start,
  output logic [7:0]            ev_outstanding, ev_bytes_wr, ev_bytes_rd,
  output logic                  ev_bus_err, ev_tag_err,
  output logic [7:0]            fifo_level,
  // telemetry
  input  wire logic             rb_sel, rb_we,
  input  wire logic [11:0]      rb_addr,
  input  wire logic [31:0]      rb_wdata,
  output logic [31:0]           rb_rdata,
  output logic                  rb_err,
  output logic [NC*64-1:0]      perf_cnt,
  output logic                  va_busy,
  output logic [31:0]           chk_err
);
  // ============================================================ scratchpad
  logic [NSP-1:0]     p_req_valid, p_req_we, p_rsp_ready, p_req_ready, p_rsp_valid, p_rsp_err, p_rsp_we;
  logic [NSP*32-1:0]  p_req_addr, p_req_wdata, p_rsp_rdata;
  logic [NSP*4-1:0]   p_req_wstrb, p_rsp_syn;
  logic [NSP*TW-1:0]  p_req_tag, p_rsp_tag;
  logic [NSP*3-1:0]   p_rsp_code;
  logic [NSP-1:0]     sp_acc, sp_iss, sp_conf, sp_cst, sp_err, sp_ecc;
  logic [SPM_BANKS*2-1:0] sp_bops;
  logic [SPM_BANKS-1:0]   sp_bconf;
  logic [31:0]        sp_cyc, sp_eccn;
  logic [NSP*32-1:0]  sp_pacc, sp_piss, sp_pcpl, sp_pconf, sp_pwait, sp_perr;
  logic [SPM_BANKS*32-1:0] sp_pbops;
  logic               sp_busy;
  hpc_scratchpad #(.NUM_PORTS(NSP), .CAPACITY_BYTES(SPMB), .NUM_BANKS(SPM_BANKS), .DATA_WIDTH(32), .ADDR_WIDTH(32),
                   .BASE_ADDR(64'(SPM_BASE)), .READ_LATENCY(1), .WRITE_ACK(1), .TAG_W(TW)) u_spm (
    .clk, .rst_n,
    .req_valid(p_req_valid), .req_ready(p_req_ready), .req_we(p_req_we), .req_addr(p_req_addr),
    .req_wdata(p_req_wdata), .req_wstrb(p_req_wstrb), .req_tag(p_req_tag),
    .rsp_valid(p_rsp_valid), .rsp_ready(p_rsp_ready), .rsp_rdata(p_rsp_rdata), .rsp_err(p_rsp_err),
    .rsp_err_code(p_rsp_code), .rsp_we(p_rsp_we), .rsp_tag(p_rsp_tag), .rsp_ecc_syn(p_rsp_syn),
    .ev_accept(sp_acc), .ev_issue(sp_iss), .ev_conflict(sp_conf), .ev_credit_stall(sp_cst), .ev_error(sp_err),
    .ev_ecc_err(sp_ecc), .ev_bank_ops(sp_bops), .ev_bank_conflict(sp_bconf),
    .perf_clear(1'b0), .perf_cycles(sp_cyc), .perf_accept(sp_pacc), .perf_issue(sp_piss), .perf_complete(sp_pcpl),
    .perf_conflict(sp_pconf), .perf_wait(sp_pwait), .perf_error(sp_perr), .perf_bank_ops(sp_pbops),
    .perf_ecc_err(sp_eccn), .busy(sp_busy));
  // testbench port = NSP-1
  assign p_req_valid[NSP-1] = tb_req_valid;
  assign p_req_we[NSP-1]    = tb_req_we;
  assign p_req_addr[(NSP-1)*32 +: 32]  = tb_req_addr;
  assign p_req_wdata[(NSP-1)*32 +: 32] = tb_req_wdata;
  assign p_req_wstrb[(NSP-1)*4 +: 4]   = tb_req_wstrb;
  assign p_req_tag[(NSP-1)*TW +: TW]   = tb_req_tag;
  assign p_rsp_ready[NSP-1] = tb_rsp_ready;
  assign tb_req_ready = p_req_ready[NSP-1];
  assign tb_rsp_valid = p_rsp_valid[NSP-1];
  assign tb_rsp_rdata = p_rsp_rdata[(NSP-1)*32 +: 32];
  assign tb_rsp_err   = p_rsp_err[NSP-1];
  assign tb_rsp_we    = p_rsp_we[NSP-1];
  assign tb_rsp_tag   = p_rsp_tag[(NSP-1)*TW +: TW];
  assign mon_spm_rsp_fire = p_rsp_valid[1 +: NP] & p_rsp_ready[1 +: NP];
  assign mon_spm_rsp_we   = p_rsp_we[1 +: NP];
  assign mon_spm_req_fire = p_req_valid[1 +: NP] & p_req_ready[1 +: NP];

  // ============================================================ DMA adapter
  logic [TW-1:0] cur_tag;
  logic [1:0]    ctl_state;
  logic [2:0]    eng_state;
  logic [31:0]   eng_bytes;
  logic          ev_cmd, ev_cpl_err, ev_stall;
  logic [`HPC_DMA_NUM_PC*32-1:0] dpc;
  hpc_dma_adapter #(.DW(32), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .BURST(FIFO_DEPTH), .DUAL_PORT(DUAL_PORT),
                    .MAX_OUT(MAX_OUT), .MAX_LEN_LOG2(16), .SPM_BASE(SPM_BASE), .SPM_BYTES(SPMB), .SPM_TAG_W(TW),
                    .CMD_DEPTH(CMD_DEPTH), .CPL_DEPTH(4), .TAG_W(8)) u_dma (
    .clk, .rst_n,
    .cmd_valid, .cmd_ready, .cmd_src, .cmd_dst, .cmd_len, .cmd_tag, .cmd_abort,
    .cpl_valid, .cpl_ready, .cpl_tag, .cpl_err, .cpl_code, .cpl_err_addr, .cpl_bytes,
    .busy, .active, .cur_tag, .ctl_state, .eng_state, .eng_bytes_done(eng_bytes), .fifo_level,
    .spm_req_valid(p_req_valid[1 +: NP]), .spm_req_ready(p_req_ready[1 +: NP]), .spm_req_we(p_req_we[1 +: NP]),
    .spm_req_addr(p_req_addr[32 +: NP*32]), .spm_req_wdata(p_req_wdata[32 +: NP*32]),
    .spm_req_wstrb(p_req_wstrb[4 +: NP*4]), .spm_req_tag(p_req_tag[TW +: NP*TW]),
    .spm_rsp_valid(p_rsp_valid[1 +: NP]), .spm_rsp_ready(p_rsp_ready[1 +: NP]),
    .spm_rsp_rdata(p_rsp_rdata[32 +: NP*32]), .spm_rsp_err(p_rsp_err[1 +: NP]),
    .spm_rsp_err_code(p_rsp_code[3 +: NP*3]), .spm_rsp_we(p_rsp_we[1 +: NP]), .spm_rsp_tag(p_rsp_tag[TW +: NP*TW]),
    .fab_req_valid, .fab_req_ready, .fab_req_write, .fab_req_addr, .fab_req_wdata, .fab_req_wstrb,
    .fab_rsp_valid, .fab_rsp_ready, .fab_rsp_rdata, .fab_rsp_error,
    .ev_cmd_accept(ev_cmd), .ev_start, .ev_cpl, .ev_cpl_err, .ev_bytes_rd, .ev_bytes_wr, .ev_req_stall(ev_stall),
    .ev_outstanding, .ev_bus_err, .ev_tag_err, .perf_clear(1'b0), .perf_cnt(dpc));

  // ============================================================ sequencer + vector array
  logic        c_valid, c_ready, o_valid, o_ready, r_valid, r_ready, k_valid, k_ready;
  logic [4:0]  c_op, k_flags;
  logic [2:0]  c_rm, c_bc;
  logic [15:0] c_vl, r_beat, k_count;
  logic [31:0] c_sc, k_result;
  logic [7:0]  c_tid, r_tid, k_tid;
  logic [N*32-1:0] o_a, o_b, o_c, r_data;
  logic [N*5-1:0]  r_flags;
  logic [N-1:0]    r_mask;
  logic            r_last, k_ill, k_red;
  logic [hpc_varray_pkg::PC_N*32-1:0] va_perf;
  logic [N-1:0]    ob_acc, ob_ret;
  logic [4:0]      ob_op;
  logic            ob_stl, ob_stt, ob_starve, ob_cqf;
  logic [$clog2(VA_CMD_DEPTH+1)-1:0] ob_cqc;
  hpc_tile_vseq #(.N(N), .VL_W(16), .TID_W(8), .SPM_TAG_W(TW)) u_vseq (
    .clk, .rst_n,
    .job_valid, .job_ready, .job_op, .job_rm, .job_vl, .job_bcast, .job_scalar, .job_a, .job_b, .job_c, .job_d,
    .job_tid, .done_valid, .done_ready, .done_tid, .done_flags, .done_illegal, .done_count, .done_err,
    .spm_req_valid(p_req_valid[0]), .spm_req_ready(p_req_ready[0]), .spm_req_we(p_req_we[0]),
    .spm_req_addr(p_req_addr[31:0]), .spm_req_wdata(p_req_wdata[31:0]), .spm_req_wstrb(p_req_wstrb[3:0]),
    .spm_req_tag(p_req_tag[TW-1:0]), .spm_rsp_valid(p_rsp_valid[0]), .spm_rsp_ready(p_rsp_ready[0]),
    .spm_rsp_rdata(p_rsp_rdata[31:0]), .spm_rsp_err(p_rsp_err[0]), .spm_rsp_tag(p_rsp_tag[TW-1:0]),
    .cmd_valid(c_valid), .cmd_ready(c_ready), .cmd_op(c_op), .cmd_rm(c_rm), .cmd_vl(c_vl), .cmd_bcast(c_bc),
    .cmd_scalar(c_sc), .cmd_tid(c_tid), .opnd_valid(o_valid), .opnd_ready(o_ready), .opnd_a(o_a), .opnd_b(o_b),
    .opnd_c(o_c), .res_valid(r_valid), .res_ready(r_ready), .res_data(r_data), .res_mask(r_mask),
    .cpl_valid(k_valid), .cpl_ready(k_ready), .cpl_flags(k_flags), .cpl_illegal(k_ill), .cpl_count(k_count),
    .busy(vseq_busy));
  hpc_vector_array #(.NUM_LANES(N), .VL_W(16), .TID_W(8), .CMD_DEPTH(VA_CMD_DEPTH)) u_va (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(c_valid), .cmd_ready_o(c_ready), .cmd_op_i(c_op), .cmd_rm_i(c_rm), .cmd_vl_i(c_vl), .cmd_vm_i(1'b0),
    .cmd_bcast_i(c_bc), .cmd_scalar_i(c_sc), .cmd_red_i(1'b0), .cmd_tid_i(c_tid),
    .opnd_valid_i(o_valid), .opnd_ready_o(o_ready), .opnd_a_i(o_a), .opnd_b_i(o_b), .opnd_c_i(o_c),
    .opnd_mask_i({N{1'b1}}),
    .res_valid_o(r_valid), .res_ready_i(r_ready), .res_data_o(r_data), .res_flags_o(r_flags), .res_mask_o(r_mask),
    .res_tid_o(r_tid), .res_beat_o(r_beat), .res_last_o(r_last),
    .cpl_valid_o(k_valid), .cpl_ready_i(k_ready), .cpl_tid_o(k_tid), .cpl_flags_o(k_flags), .cpl_illegal_o(k_ill),
    .cpl_count_o(k_count), .cpl_red_o(k_red), .cpl_result_o(k_result),
    .lane_hold_i(lane_hold), .busy_o(va_busy), .perf_clear_i(1'b0), .perf_cnt_o(va_perf),
    .obs_lane_accept_o(ob_acc), .obs_lane_retire_o(ob_ret), .obs_lane_op_o(ob_op), .obs_stall_lane_o(ob_stl),
    .obs_stall_trk_o(ob_stt), .obs_opnd_starve_o(ob_starve), .obs_cmdq_full_o(ob_cqf), .obs_cmdq_count_o(ob_cqc));

  // ============================================================ telemetry (Module 07)
  logic pf_irq, pf_frozen;
  hpc_perf_tile #(.N(N), .VL_W(16), .ROB_DEPTH(8), .CQ_W($clog2(VA_CMD_DEPTH+1)), .NSP(NSP), .DMA_NP(NP),
                  .DMA_BEAT_B(4), .DMA_CMDQ(CMD_DEPTH > 0), .FMA_FLOPS(2), .CMP_FLOPS(0), .EV_REG(1'b1),
                  .INSTR_PHASE(3), .CNT_W(64), .INC_W(32), .SNAP_EN(1'b1), .PRELOAD_EN(1'b1), .EN_RESET(1'b1),
                  .PLATFORM(0), .CLK_KHZ(0), .BUILD_ID(32'h0009_0001)) u_perf (
    .clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .va_cmd_valid(c_valid), .va_cmd_ready(c_ready), .va_cpl_valid(k_valid), .va_cpl_ready(k_ready),
    .va_cpl_illegal(k_ill), .va_cpl_red(k_red), .va_cpl_count(k_count), .va_res_valid(r_valid), .va_res_ready(r_ready),
    .va_busy, .va_lane_accept(ob_acc), .va_lane_retire(ob_ret), .va_lane_op(ob_op), .va_stall_lane(ob_stl),
    .va_stall_trk(ob_stt), .va_opnd_starve(ob_starve), .va_cmdq_full(ob_cqf), .va_cmdq_count(ob_cqc),
    .dma_cmd_valid(cmd_valid), .dma_cmd_ready(cmd_ready), .dma_cpl_valid(cpl_valid), .dma_cpl_ready(cpl_ready),
    .dma_cpl_err(cpl_err), .dma_active(active), .dma_bytes_rd(ev_bytes_rd), .dma_bytes_wr(ev_bytes_wr),
    .dma_outstanding(ev_outstanding), .dma_bus_err(ev_bus_err), .dma_tag_err(ev_tag_err),
    .spm_req_valid(p_req_valid), .spm_req_ready(p_req_ready), .spm_req_we(p_req_we), .spm_conflict(sp_conf),
    .spm_dec_err(sp_err), .spm_ecc_err(sp_ecc),
    .freeze_i(1'b0), .snap_i(1'b0), .irq_o(pf_irq), .frozen_o(pf_frozen), .cnt_o(perf_cnt));

  // ============================================================ checkers
  logic [31:0] v_fab [NP];
  for (genvar p = 0; p < NP; p++) begin : g_fchk
    logic [31:0] nq, nr, no;
    sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(MAX_OUT), .NAME("tile_fab")) u_chk (
      .clk, .rst_n, .req_valid(fab_req_valid[p]), .req_ready(fab_req_ready[p]), .req_write(fab_req_write[p]),
      .req_addr(fab_req_addr[p*32 +: 32]), .req_wdata(fab_req_wdata[p*32 +: 32]), .req_wstrb(fab_req_wstrb[p*4 +: 4]),
      .rsp_valid(fab_rsp_valid[p]), .rsp_ready(fab_rsp_ready[p]), .rsp_rdata(fab_rsp_rdata[p*32 +: 32]),
      .rsp_error(fab_rsp_error[p]), .violations(v_fab[p]), .n_req(nq), .n_rsp(nr), .outstanding(no));
  end
  logic [31:0] e [10];
  logic [31:0] xc [10];
  hpc_rv_checker #(.NAME("tile_va_cmd"), .W(5 + 3 + 16 + 3 + 32 + 8)) c0 (.clk, .rst_n, .valid(c_valid),
    .ready(c_ready), .payload({c_op, c_rm, c_vl, c_bc, c_sc, c_tid}), .err_cnt(e[0]), .xfer_cnt(xc[0]));
  hpc_rv_checker #(.NAME("tile_va_opnd"), .W(3 * N * 32)) c1 (.clk, .rst_n, .valid(o_valid), .ready(o_ready),
    .payload({o_a, o_b, o_c}), .err_cnt(e[1]), .xfer_cnt(xc[1]));
  hpc_rv_checker #(.NAME("tile_va_res"), .W(N * 32 + N * 5 + N + 8 + 16 + 1)) c2 (.clk, .rst_n, .valid(r_valid),
    .ready(r_ready), .payload({r_data, r_flags, r_mask, r_tid, r_beat, r_last}), .err_cnt(e[2]), .xfer_cnt(xc[2]));
  hpc_rv_checker #(.NAME("tile_va_cpl"), .W(8 + 5 + 1 + 16)) c3 (.clk, .rst_n, .valid(k_valid), .ready(k_ready),
    .payload({k_tid, k_flags, k_ill, k_count}), .err_cnt(e[3]), .xfer_cnt(xc[3]));
  hpc_rv_checker #(.NAME("tile_done"), .W(8 + 5 + 1 + 16 + 1)) c4 (.clk, .rst_n, .valid(done_valid),
    .ready(done_ready), .payload({done_tid, done_flags, done_illegal, done_count, done_err}), .err_cnt(e[4]),
    .xfer_cnt(xc[4]));
  hpc_rv_checker #(.NAME("tile_dma_cpl"), .W(8 + 1 + 4 + 64)) c5 (.clk, .rst_n, .valid(cpl_valid), .ready(cpl_ready),
    .payload({cpl_tag, cpl_err, cpl_code, cpl_err_addr, cpl_bytes}), .err_cnt(e[5]), .xfer_cnt(xc[5]));
  hpc_rv_checker #(.NAME("tile_tb_rsp"), .W(32 + 2 + TW), .XCHK_MASK({32'h0, {(2 + TW){1'b1}}})) c6 (
    .clk, .rst_n, .valid(tb_rsp_valid), .ready(tb_rsp_ready), .payload({tb_rsp_rdata, tb_rsp_err, tb_rsp_we, tb_rsp_tag}),
    .err_cnt(e[6]), .xfer_cnt(xc[6]));
  hpc_txn_conservation #(.NAME("tile_va_cmd")) k0 (.clk, .rst_n, .acc(c_valid && c_ready), .cpl(k_valid && k_ready),
    .outstanding(xc[7]), .err_cnt(e[7]), .acc_total(xc[8]), .cpl_total(xc[9]));
  logic [31:0] y0, y1, y2;
  hpc_txn_conservation #(.NAME("tile_dma")) k1 (.clk, .rst_n, .acc(cmd_valid && cmd_ready), .cpl(cpl_valid && cpl_ready),
    .outstanding(y0), .err_cnt(e[8]), .acc_total(y1), .cpl_total(y2));
  logic [31:0] z0, z1, z2;
  hpc_txn_conservation #(.NAME("tile_job")) k2 (.clk, .rst_n, .acc(job_valid && job_ready), .cpl(done_valid && done_ready),
    .outstanding(z0), .err_cnt(e[9]), .acc_total(z1), .cpl_total(z2));
  always_comb begin
    chk_err = '0;
    for (int i = 0; i < 10; i++) chk_err = chk_err + e[i];
    for (int p = 0; p < NP; p++) chk_err = chk_err + v_fab[p];
  end
endmodule
`default_nettype wire
