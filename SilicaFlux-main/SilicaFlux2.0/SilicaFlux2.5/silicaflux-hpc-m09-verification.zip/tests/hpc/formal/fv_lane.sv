// =============================================================================
// SilicaFlux-HPC verification :: fv_lane -- control properties of hpc_vector_lane
//
// The full lane (Module 02, unmodified, arithmetic included) with unconstrained
// inputs.  Environment: the tag of every accepted ENABLED operation is its
// sequence number modulo 2^TAG_W (a pure labelling assumption, the lane treats
// tags as opaque data); reset is asserted in the first cycle and may be asserted
// again at any time.
//   L1 conservation:  retired <= accepted-enabled; outstanding <= ROB_DEPTH
//   L2 ordering:      the k-th retired result carries tag k (in-order, no loss
//                     inside the window, no duplication, no misassociation)
//   L3 stability:     out_valid && !out_ready  ->  next cycle out_valid and the
//                     whole payload unchanged
//   L4 payload zero:  out_valid = 0 -> result, flags, tag, illegal are 0
//   L5 busy_o == (outstanding != 0)
//   L6 reset:         in the first cycle after reset release in_ready = 0 and
//                     out_valid = 0; outstanding work is discarded
//   L7 masking:       a disabled operation never produces a result (follows from
//                     L1 + L2 with the tag numbering only counting enabled ops)
// =============================================================================
`default_nettype none

module fv_lane #(
  parameter int ROB_DEPTH = 3,
  parameter int TAG_W     = 4
) (
  input wire logic             clk,
  input wire logic             rst_n,
  input wire logic             in_valid,
  input wire logic [4:0]       in_op,
  input wire logic [31:0]      in_a, in_b, in_c,
  input wire logic [2:0]       in_rm,
  input wire logic [TAG_W-1:0] in_tag,
  input wire logic             lane_en,
  input wire logic             out_ready
);
  logic             in_ready, out_valid, out_illegal, busy;
  logic [31:0]      out_result;
  logic [4:0]       out_flags;
  logic [TAG_W-1:0] out_tag;
  logic e0, e1, e2, e3, e4, e5;
  hpc_vector_lane #(.DATA_W(32), .TAG_W(TAG_W), .ROB_DEPTH(ROB_DEPTH), .LAT_FADD(2), .LAT_FMUL(2), .LAT_FMA(3),
                    .LAT_MISC(1), .LAT_IMUL(1), .EN_FCMP(1'b0), .EN_INT(1'b0)) dut (
    .clk_i(clk), .rst_ni(rst_n), .in_valid_i(in_valid), .in_ready_o(in_ready), .in_op_i(in_op), .in_a_i(in_a),
    .in_b_i(in_b), .in_c_i(in_c), .in_rm_i(in_rm), .in_tag_i(in_tag), .lane_en_i(lane_en),
    .out_valid_o(out_valid), .out_ready_i(out_ready), .out_result_o(out_result), .out_flags_o(out_flags),
    .out_tag_o(out_tag), .out_illegal_o(out_illegal), .busy_o(busy),
    .ev_accept_o(e0), .ev_retire_o(e1), .ev_pipe_stall_o(e2), .ev_backpressure_o(e3), .ev_illegal_o(e4),
    .ev_masked_o(e5));

  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  wire logic acc = in_valid && in_ready && lane_en;
  wire logic ret = out_valid && out_ready;
  logic [TAG_W-1:0] acc_seq, ret_seq;
  logic [7:0]       outst;
  always @(*) if (in_valid && lane_en) assume (in_tag == acc_seq);
  always @(posedge clk or negedge rst_n)
    if (!rst_n) begin acc_seq <= '0; ret_seq <= '0; outst <= 8'd0; end
    else begin
      if (acc) acc_seq <= acc_seq + 1'b1;
      if (ret) ret_seq <= ret_seq + 1'b1;
      outst <= outst + 8'(acc) - 8'(ret);
    end

  logic first_after_rst;
  always @(posedge clk or negedge rst_n) if (!rst_n) first_after_rst <= 1'b1; else first_after_rst <= 1'b0;

  always @(*) if (rst_n && !init) begin
    assert (outst <= 8'(ROB_DEPTH));                    // L1
    if (out_valid) assert (outst != 8'd0);
    if (out_valid) assert (out_tag == ret_seq);                   // L2
    if (!out_valid) assert (out_result == '0 && out_flags == '0 && out_tag == '0 && !out_illegal);  // L4
    assert (busy == (outst != 8'd0));                                // L5
    if (first_after_rst) assert (!in_ready && !out_valid);        // L6
  end
  always @(posedge clk) if (!init && rst_n && $past(rst_n) && $past(out_valid && !out_ready)) begin   // L3
    assert (out_valid);
    assert ($stable(out_result) && $stable(out_flags) && $stable(out_tag) && $stable(out_illegal));
  end
  always @(*) if (rst_n) cover (outst == 8'(ROB_DEPTH) && !out_ready);
  always @(*) if (rst_n) cover (ret && out_illegal);
endmodule
`default_nettype wire
