// =============================================================================
// SilicaFlux-HPC verification :: fv_spm_addr_map -- address bounds of hpc_spm_addr_map
//
// Two instances of the (combinational) decoder see two arbitrary addresses.
//   B1 ok, err_code: RANGE (1) if the address is outside [BASE, BASE+CAP) -- all
//      ADDR_WIDTH bits compared, no aliasing -- else ALIGN (2) if misaligned, else
//      STROBE (3) for a partial-strobe write when BYTE_WE = 0, else ok (code 0)
//   B2 for ok addresses, bank / row / byte offset equal an independent reference
//      written with division and modulo (Module 04 docs/02 table), for the LOW,
//      XOR and HIGH maps
//   B3 bank < NUM_BANKS and row < bank depth (address bounds)
//   B4 bijectivity: two different ok addresses never map to the same
//      (bank, row, byte offset) -- no two words share a storage location
// Exhaustive by SAT (no state: depth 1 proves it for every address).
// =============================================================================
`default_nettype none
`include "hpc_spm_defs.svh"

module fv_spm_addr_map #(
  parameter int          ADDR_WIDTH     = 32,
  parameter int          CAPACITY_BYTES = 65536,
  parameter logic [63:0] BASE_ADDR      = 64'h2000_0000,
  parameter int          DATA_WIDTH     = 32,
  parameter int          NUM_BANKS      = 4,
  parameter int          MAP            = 0,
  parameter int          BYTE_WE        = 1,
  localparam int NB   = DATA_WIDTH / 8,
  localparam int CB   = $clog2(CAPACITY_BYTES),
  localparam int OFF  = $clog2(NB),
  localparam int BW   = $clog2(NUM_BANKS),
  localparam int RW   = CB - OFF - BW,
  localparam int BWX  = (BW > 0) ? BW : 1,
  localparam int OFFX = (OFF > 0) ? OFF : 1
) (
  input wire logic                  clk,
  input wire logic [ADDR_WIDTH-1:0] a1, a2,
  input wire logic                  we1, we2,
  input wire logic [NB-1:0]         s1, s2
);
  logic          ok1, ok2;
  logic [2:0]    c1, c2;
  logic [BWX-1:0] b1, b2;
  logic [RW-1:0] r1, r2;
  logic [OFFX-1:0] o1, o2;
  hpc_spm_addr_map #(.ADDR_WIDTH(ADDR_WIDTH), .CAPACITY_BYTES(CAPACITY_BYTES), .BASE_ADDR(BASE_ADDR),
                     .DATA_WIDTH(DATA_WIDTH), .NUM_BANKS(NUM_BANKS), .MAP(MAP), .BYTE_WE(BYTE_WE)) d1 (
    .addr(a1), .we(we1), .wstrb(s1), .ok(ok1), .err_code(c1), .bank(b1), .row(r1), .boff(o1));
  hpc_spm_addr_map #(.ADDR_WIDTH(ADDR_WIDTH), .CAPACITY_BYTES(CAPACITY_BYTES), .BASE_ADDR(BASE_ADDR),
                     .DATA_WIDTH(DATA_WIDTH), .NUM_BANKS(NUM_BANKS), .MAP(MAP), .BYTE_WE(BYTE_WE)) d2 (
    .addr(a2), .we(we2), .wstrb(s2), .ok(ok2), .err_code(c2), .bank(b2), .row(r2), .boff(o2));

  // independent reference (64-bit arithmetic, division / modulo)
  localparam logic [63:0] CAP   = 64'(CAPACITY_BYTES);
  localparam logic [63:0] BASE  = BASE_ADDR;
  localparam logic [63:0] DEPTH = CAP / NB / NUM_BANKS;
  function automatic [2:0] ref_code(input logic [ADDR_WIDTH-1:0] a, input logic w, input logic [NB-1:0] s);
    logic [63:0] x;
    x = 64'(a);
    if (!(x >= BASE && x < BASE + CAP))                  ref_code = 3'd1;
    else if ((x % NB) != 0)                              ref_code = 3'd2;
    else if (w && BYTE_WE == 0 && s != {NB{1'b1}})      ref_code = 3'd3;
    else                                                 ref_code = 3'd0;
  endfunction
  function automatic [63:0] ref_bank(input logic [ADDR_WIDTH-1:0] a);
    logic [63:0] wd;
    wd = (64'(a) - BASE) / NB;
    if (MAP == `HPC_SPM_MAP_LOW)      ref_bank = wd % NUM_BANKS;
    else if (MAP == `HPC_SPM_MAP_XOR) ref_bank = (wd % NUM_BANKS) ^ ((wd / NUM_BANKS) % NUM_BANKS);
    else                              ref_bank = wd / DEPTH;
  endfunction
  function automatic [63:0] ref_row(input logic [ADDR_WIDTH-1:0] a);
    logic [63:0] wd;
    wd = (64'(a) - BASE) / NB;
    if (MAP == `HPC_SPM_MAP_HIGH) ref_row = wd % DEPTH;
    else                          ref_row = wd / NUM_BANKS;
  endfunction

  always @(*) begin
    assert (c1 == ref_code(a1, we1, s1));                                  // B1
    assert (ok1 == (c1 == 3'd0));
    if (ok1) begin
      if (NUM_BANKS > 1) assert (64'(b1) == ref_bank(a1));              // B2
      assert (64'(r1) == ref_row(a1));
      if (NB > 1) assert (64'(o1) == 64'(a1) % NB);
      assert (64'(b1) < NUM_BANKS || NUM_BANKS == 1);                  // B3
      assert (64'(r1) < DEPTH);
    end
    if (ok1 && ok2 && a1 != a2)                                             // B4
      assert (!(b1 == b2 && r1 == r2 && o1 == o2));
    cover (ok1 && ok2 && (b1 != b2 || r1 != r2));
  end
endmodule
`default_nettype wire
