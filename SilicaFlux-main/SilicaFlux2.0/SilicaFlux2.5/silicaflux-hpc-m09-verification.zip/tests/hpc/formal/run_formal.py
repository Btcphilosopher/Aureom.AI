#!/usr/bin/env python3
"""Formal verification runner (brief §10): Yosys 0.33 -> SMT2 -> yosys-smtbmc + z3.

For every property set and parameter configuration:
  BMC        all assertions hold for every input sequence of DEPTH cycles from reset
             -> reported as "bounded proof to depth DEPTH" (NOT a full proof)
  induction  k-induction with the same assertions; only a passing induction is
             reported as an unbounded PROOF
  cover      every cover statement is reachable within DEPTH (non-vacuity)
  negative   mutated copies of the RTL must be REFUTED (a counterexample found),
             showing the properties are able to fail
SymbiYosys is not available in this environment (as for Modules 05 / 07); the same
flow is driven directly.  z3 from PyPI (z3-solver) is used: the Debian z3 4.8.12
hangs on the yosys-smtbmc pipe (Module 07 finding).

usage: run_formal.py [--matrix ci|nightly] [--only SUBSTR] [--solver z3|boolector]
"""
from __future__ import annotations

import argparse
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
HPC = HERE.parent
sys.path[:0] = [str(HPC / "lib"), str(HPC), str(HPC / "common")]
from hpcv import results as R, sim  # noqa: E402
import filelists as FL  # noqa: E402

SUITE = "formal"
BLD = sim.BUILD / "formal"


def jobs(matrix):
    J = []
    fifo_depths = [1, 2, 3, 4, 5] if matrix == "nightly" else [1, 2, 4]
    for d in fifo_depths:
        J.append(dict(name=f"fifo/hpc_varray_fifo/D{d}", top="fv_varray_fifo", src=FL.files("varray_fifo"),
                      harness="fv_fifo.sv", params=dict(W=3, DEPTH=d), depth=12, ind=2 * d + 4,
                      assumptions="caller contract: no push while full unless popping, no pop while empty; reset in "
                                  "cycle 0, asynchronous re-assertion allowed",
                      props="F1 bounds, F2 count/empty/full == reference, F3 head == reference (order, no loss, "
                            "no duplication, no corruption), F4 empty after reset"))
    for d in ([2, 4, 8] if matrix == "nightly" else [2, 4]):
        J.append(dict(name=f"fifo/dma_fifo/D{d}", top="fv_dma_fifo", src=[FL.DF / "rtl/dma/dma_fifo.sv"],
                      harness="fv_fifo.sv", params=dict(WIDTH=3, DEPTH=d), depth=12, ind=2 * d + 4,
                      assumptions="caller contract: no push while full unless popping, no pop while empty; clr and "
                                  "reset at any time",
                      props="F1-F4 as hpc_varray_fifo, plus empty after clr"))
    arb = [(p, m, a) for p in ([2, 3, 4] if matrix == "nightly" else [2, 3]) for m in (0, 1, 2) for a in (0, 1)]
    for p, m, a in arb:
        J.append(dict(name=f"arbitration/hpc_spm_bank_arb/P{p}_{['1RW', '1R1W', '2RW'][m]}_{['RR', 'FIXED'][a]}",
                      top="fv_spm_bank_arb", src=FL.files("spm_bank_arb"), harness="fv_spm_arb.sv",
                      params=dict(NUM_PORTS=p, PORT_MODE=m, ARB=a, RW=2), depth=10, ind=p + 3,
                      incdirs=[FL.M04 / "rtl", FL.SL, FL.SL / "backends/asic"],
                      assumptions="reset in cycle 0; a request is held until granted (A8 only)",
                      props="A1 grants subset of requests, A2 one port per slot, A3 port-model slot rules, "
                            "A4 no same-row collision with a write, A5 any/idx/contended consistent, "
                            "A6 work conserving, A7 FIXED priority, A8 RR starvation-free within NUM_PORTS-1"))
    amap = [(b, m, base, bwe) for b in (1, 2, 4, 8, 16) for m in (0, 1, 2)
            for base, bwe in ([(0x20000000, 1)] if matrix == "ci" else [(0, 1), (0x20000000, 0)])]
    for b, m, base, bwe in amap:
        if b == 1 and m != 0:
            continue
        J.append(dict(name=f"address_bounds/hpc_spm_addr_map/B{b}_{['LOW', 'XOR', 'HIGH'][m]}_base{base:x}_bwe{bwe}",
                      top="fv_spm_addr_map", src=FL.files("spm_addr_map"), harness="fv_spm_addr_map.sv",
                      params=dict(ADDR_WIDTH=32, CAPACITY_BYTES=65536, BASE_ADDR=base, DATA_WIDTH=32, NUM_BANKS=b,
                                  MAP=m, BYTE_WE=bwe), depth=1, ind=None, incdirs=[FL.M04 / "rtl", FL.SL, FL.SL / "backends/asic"],
                      assumptions="none (combinational; every 32-bit address pair)",
                      props="B1 error code and priority vs reference, B2 bank/row/offset == division/modulo "
                            "reference, B3 bounds, B4 bijectivity (no two addresses share a location)"))
    J.append(dict(name="request_conservation_ordering/hpc_vector_lane/ROB3", top="fv_lane", src=FL.files("lane"),
                  harness="fv_lane.sv", params=dict(ROB_DEPTH=3, TAG_W=4), depth=14 if matrix == "ci" else 18,
                  ind=None, timeout=3600,
                  assumptions="tag of each accepted enabled op = its sequence number mod 16 (labelling only); "
                              "reset in cycle 0, re-assertion allowed; EN_FCMP = EN_INT = 0, minimum latencies",
                  props="L1 conservation + ROB bound, L2 in-order tagged completion, L3 output stable while "
                        "stalled, L4 payload 0 when not valid, L5 busy, L6 reset/initialisation cycle"))
    return J


NEGATIVE = [
    dict(name="neg/fifo_full_off_by_one", job="fifo/hpc_varray_fifo/D2", file="hpc_varray_fifo.sv",
         old="assign full_o  = (cnt_q == CW'(DEPTH));", new="assign full_o  = (cnt_q == CW'(DEPTH - 1));"),
    dict(name="neg/fifo_read_pointer_not_advanced_on_push_pop", job="fifo/hpc_varray_fifo/D2",
         file="hpc_varray_fifo.sv", old="if (pop_i)  rd_q <= ptr_inc(rd_q);",
         new="if (pop_i && !push_i)  rd_q <= ptr_inc(rd_q);"),
    dict(name="neg/dma_fifo_count_wrong", job="fifo/dma_fifo/D4", file="dma_fifo.sv",
         old="assign count = wp - rp;", new="assign count = wp - rp - (AW+1)'(wp[0] & rp[0]);"),
    dict(name="neg/arb_2rw_same_row_hazard_dropped", job="arbitration/hpc_spm_bank_arb/P2_2RW_RR",
         file="hpc_spm_bank_arb.sv", old="else         g_b = !any_b && !(a_row == r && (a_we || we[idx]));",
         new="else         g_b = !any_b;"),
    dict(name="neg/arb_1r1w_write_read_hazard_dropped", job="arbitration/hpc_spm_bank_arb/P2_1R1W_RR",
         file="hpc_spm_bank_arb.sv", old="if (we[idx]) g_a = !any_a && !(any_b && b_row == r);",
         new="if (we[idx]) g_a = !any_a;"),
    dict(name="neg/addr_map_xor_bank_wrong", job="address_bounds/hpc_spm_addr_map/B4_XOR_base20000000_bwe1",
         file="hpc_spm_addr_map.sv", old="assign bank = word[BW-1:0] ^ word[2*BW-1:BW];",
         new="assign bank = word[BW-1:0] ^ word[2*BW:BW+1];"),
    dict(name="neg/lane_rob_head_skips_on_alloc", job="request_conservation_ordering/hpc_vector_lane/ROB3",
         file="hpc_vector_lane.sv", old="if (retire) head_q <= ptr_inc(head_q);",
         new="if (retire) head_q <= alloc ? ptr_inc(ptr_inc(head_q)) : ptr_inc(head_q);", depth=10),
]


def yosys_smt2(job, out: Path, src_override=None):
    srcs = [src_override.get(Path(s).name, s) if src_override else s for s in job["src"]]
    inc = " ".join(f"-I{i}" for i in job.get("incdirs", []))
    ch = " ".join(f"-set {k} {v}" for k, v in job["params"].items())
    files = " ".join(str(s) for s in srcs)
    script = (f"read_verilog -sv -formal -DSYNTHESIS {inc} {files} {HERE / job['harness']}; "
              f"chparam {ch} {job['top']}; hierarchy -check -top {job['top']}; prep -top {job['top']}; "
              f"async2sync; dffunmap; write_smt2 -wires {out}")
    log = out.with_suffix(".yosys.log")
    r = subprocess.run(["yosys", "-q", "-l", str(log), "-p", script], capture_output=True, text=True)
    return r.returncode == 0, log


def smtbmc(smt2: Path, mode: str, depth: int, solver: str, timeout: int):
    args = ["yosys-smtbmc", "-s", solver]
    if mode == "bmc":
        args += ["--presat", "-t", str(depth)]
    elif mode == "ind":
        args += ["-i", "-t", str(depth)]
    elif mode == "cover":
        args += ["-c", "-t", str(depth)]
    log = smt2.with_suffix(f".{mode}.log")
    t0 = time.time()
    try:
        r = subprocess.run(args + [str(smt2)], capture_output=True, text=True, timeout=timeout)
        txt = r.stdout + r.stderr
        rc = r.returncode
    except subprocess.TimeoutExpired:
        txt, rc = f"TIMEOUT after {timeout} s", 124
    log.write_text(txt)
    return rc, txt, round(time.time() - t0, 1), log


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--matrix", default="ci", choices=["ci", "nightly"])
    ap.add_argument("--only", default="")
    ap.add_argument("--solver", default=os.environ.get("HPC_FORMAL_SOLVER", "z3"))
    a = ap.parse_args()
    sim.ensure_rtl()
    # prefer the PyPI z3 next to the running interpreter (see module docstring)
    venv_bin = Path(sys.executable).parent
    if (venv_bin / "z3").exists():
        os.environ["PATH"] = f"{venv_bin}{os.pathsep}{os.environ['PATH']}"
    ver = subprocess.run([a.solver, "--version"], capture_output=True, text=True).stdout.strip()
    print(f"== formal suite, matrix {a.matrix}, solver {ver}")
    BLD.mkdir(parents=True, exist_ok=True)
    J = {j["name"]: j for j in jobs(a.matrix)}
    for name, j in J.items():
        if a.only not in name:
            continue
        d = BLD / name.replace("/", "_")
        d.mkdir(parents=True, exist_ok=True)
        smt = d / "model.smt2"
        ok, ylog = yosys_smt2(j, smt)
        if not ok:
            R.record(SUITE, name, "FAIL", reason="yosys elaboration failed", log=ylog, simulator="yosys-smtbmc",
                     config=j["params"])
            print(f"  [FAIL] formal/{name}: yosys failed ({ylog})")
            continue
        to = j.get("timeout", 900)
        brc, btxt, bt, blog = smtbmc(smt, "bmc", j["depth"], a.solver, to)
        crc, ctxt, ct, clog = smtbmc(smt, "cover", j["depth"], a.solver, to)
        ncov = len(re.findall(r"Reached cover statement", ctxt))
        tcov = len(re.findall(r"cover", (HERE / j["harness"]).read_text())) if False else None
        ind = "not attempted"
        it = 0.0
        if j.get("ind"):
            irc, itxt, it, ilog = smtbmc(smt, "ind", j["ind"], a.solver, to)
            if irc == 0:
                ind = f"PROVEN (k-induction, k={j['ind']})"
            elif "TIMEOUT" in itxt:
                ind = f"not concluded (timeout {to} s)"
            else:
                ind = f"not closed at k={j['ind']} (counterexample to induction; bounded result only)"
        elif j["depth"] == 1:
            ind = "PROVEN (combinational: depth 1 covers every input)"
        bmc_ok = brc == 0
        cov_ok = crc == 0 and ncov > 0
        status = "PASS" if bmc_ok and cov_ok else "FAIL"
        kind = "unbounded proof" if ind.startswith("PROVEN") else f"bounded proof to depth {j['depth']}"
        R.record(SUITE, name, status, config=j["params"], duration=bt + ct + it, simulator="yosys-smtbmc",
                 metrics={"bmc": "PASS" if bmc_ok else ("TIMEOUT" if brc == 124 else "FAIL"), "bmc_depth": j["depth"],
                          "induction": ind, "result_kind": kind, "covers_reached": ncov, "assumptions": j["assumptions"],
                          "properties": j["props"], "solver": ver, "bmc_seconds": bt, "induction_seconds": it},
                 log=blog, repro=f"python3 tests/hpc/formal/run_formal.py --only '{name}'",
                 reason=None if status == "PASS" else (btxt[-600:] if not bmc_ok else "cover not reached"))
        print(f"  [{status}] formal/{name}: BMC depth {j['depth']} {'PASS' if bmc_ok else 'FAIL'} ({bt}s), "
              f"covers reached {ncov}, induction: {ind}")
    # ---------------------------------------------------------- negative controls
    for n in NEGATIVE:
        if a.only not in n["name"] and a.only not in n["job"]:
            continue
        j = dict(J[n["job"]])
        if "depth" in n:
            j["depth"] = n["depth"]
        d = BLD / n["name"].replace("/", "_")
        d.mkdir(parents=True, exist_ok=True)
        src = next(s for s in j["src"] if Path(s).name == n["file"])
        txt = Path(src).read_text()
        if txt.count(n["old"]) != 1:
            R.record(SUITE, n["name"], "FAIL", reason=f"mutation site not found exactly once in {n['file']}")
            print(f"  [FAIL] formal/{n['name']}: mutation site not unique")
            continue
        mut = d / n["file"]
        mut.write_text(txt.replace(n["old"], n["new"]))
        ok, ylog = yosys_smt2(j, d / "model.smt2", src_override={n["file"]: mut})
        if not ok:
            R.record(SUITE, n["name"], "FAIL", reason="yosys failed on the mutant", log=ylog)
            continue
        rc, out, t, log = smtbmc(d / "model.smt2", "bmc", j["depth"], a.solver, j.get("timeout", 900))
        refuted = rc != 0 and "TIMEOUT" not in out and "Assert failed" in out
        where = re.findall(r"Assert failed in [^:]*: ([^\s]+)", out)
        R.record(SUITE, n["name"], "PASS" if refuted else "FAIL", duration=t, simulator="yosys-smtbmc",
                 metrics={"mutation": f"{n['file']}: '{n['old']}' -> '{n['new']}'", "refuted": refuted,
                          "failed_assertion": where[0] if where else None, "on_job": n["job"]},
                 log=log, reason=None if refuted else "mutant NOT refuted: properties vacuous for this defect",
                 repro=f"python3 tests/hpc/formal/run_formal.py --only '{n['name']}'")
        print(f"  [{'PASS' if refuted else 'FAIL'}] formal/{n['name']}: "
              f"{'refuted at ' + (where[0] if where else '?') if refuted else 'NOT refuted'} ({t}s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
