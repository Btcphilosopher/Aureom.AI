// =============================================================================
// SilicaFlux-HPC verification :: fv_spm_bank_arb -- arbitration safety of hpc_spm_bank_arb
//
// Properties (from the guarantees stated in the hpc_spm_bank_arb header, Module 04):
//   A1 grants only to requesting ports
//   A2 at most one port per slot; a port never holds both slots
//   A3 PORT_MODE 1RW: slot B never used; 1R1W: slot A only writes, slot B only reads
//   A4 never two granted same-row accesses of which one is a write (collision rule)
//   A5 any / idx outputs consistent with the grant vectors; contended exact
//   A6 the bank is never idle while a port requests (work conserving)
//   A7 FIXED: the lowest-index requester is always granted
//   A8 RR: a port that keeps requesting is granted within NUM_PORTS-1 cycles
//      (bounded starvation freedom; environment assumption: a request is held
//      until granted, as the scratchpad's request queues / ports do)
//   R1 reset: no state is needed for safety; the RR pointer is reset (checked by A8
//      from the first cycle)
// =============================================================================
`default_nettype none
`include "hpc_spm_defs.svh"

module fv_spm_bank_arb #(
  parameter int NUM_PORTS = 3,
  parameter int PORT_MODE = 0,
  parameter int ARB       = 0,
  parameter int RW        = 2,
  localparam int P  = NUM_PORTS,
  localparam int PW = (P > 1) ? $clog2(P) : 1
) (
  input wire logic            clk,
  input wire logic            rst_n,
  input wire logic [P-1:0]    req,
  input wire logic [P-1:0]    we,
  input wire logic [P*RW-1:0] row
);
  logic [P-1:0]  gnt_a, gnt_b;
  logic          any_a, any_b, contended;
  logic [PW-1:0] idx_a, idx_b;
  hpc_spm_bank_arb #(.NUM_PORTS(P), .PORT_MODE(PORT_MODE), .ARB(ARB), .RW(RW)) dut (
    .clk, .rst_n, .req, .we, .row, .gnt_a, .gnt_b, .any_a, .any_b, .idx_a, .idx_b, .contended);

  logic init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);

  function automatic [7:0] popc(input logic [P-1:0] v);
    popc = 8'd0;
    for (int i = 0; i < P; i++) popc = popc + 8'(v[i]);
  endfunction
  wire logic [P-1:0] g = gnt_a | gnt_b;

  always @(*) if (rst_n && !init) begin
    assert ((g & ~req) == '0);                                            // A1
    assert (popc(gnt_a) <= 1 && popc(gnt_b) <= 1 && (gnt_a & gnt_b) == '0); // A2
    if (PORT_MODE == `HPC_SPM_PORT_1RW) assert (gnt_b == '0);            // A3
    if (PORT_MODE == `HPC_SPM_PORT_1R1W) begin
      assert ((gnt_a & ~we) == '0);
      assert ((gnt_b & we) == '0);
    end
    for (int i = 0; i < P; i++)                                           // A4
      for (int j = 0; j < P; j++)
        if (i != j && g[i] && g[j] && row[i*RW +: RW] == row[j*RW +: RW]) assert (!we[i] && !we[j]);
    assert (any_a == |gnt_a && any_b == |gnt_b);                          // A5
    if (any_a) assert (gnt_a[idx_a]);
    if (any_b) assert (gnt_b[idx_b]);
    assert (contended == |(req & ~g));
    if (req != '0) assert (g != '0);                                      // A6
    if (ARB == `HPC_SPM_ARB_FIXED)                                        // A7
      for (int i = 0; i < P; i++)
        if (req[i] && (req & ((1 << i) - 1)) == '0) assert (g[i]);
  end

  // A8: bounded starvation freedom under RR (requests held until granted)
  logic [7:0]   wait_c [P];
  logic [P-1:0] req_q, g_q;
  logic         live_q;
  always @(posedge clk) begin req_q <= req; g_q <= g; live_q <= rst_n && !init; end
  always @(*) if (rst_n && !init && live_q)
    for (int i = 0; i < P; i++) if (req_q[i] && !g_q[i]) assume (req[i]);
  always @(posedge clk or negedge rst_n)
    if (!rst_n) for (int i = 0; i < P; i++) wait_c[i] <= 8'd0;
    else for (int i = 0; i < P; i++) wait_c[i] <= (req[i] && !g[i]) ? wait_c[i] + 8'd1 : 8'd0;
  always @(*) if (rst_n && !init && ARB == `HPC_SPM_ARB_RR)
    for (int i = 0; i < P; i++) assert (wait_c[i] <= 8'(P - 1));
  // non-vacuity: contention, the longest RR wait, and (two-slot modes) both slots in use
  always @(*) if (rst_n) cover (contended);
  always @(*) if (rst_n) cover (wait_c[P-1] == 8'(P - 1));
  if (PORT_MODE != 0) begin : g_cov2
    always @(*) if (rst_n) cover (any_a && any_b);
  end
endmodule
`default_nettype wire
