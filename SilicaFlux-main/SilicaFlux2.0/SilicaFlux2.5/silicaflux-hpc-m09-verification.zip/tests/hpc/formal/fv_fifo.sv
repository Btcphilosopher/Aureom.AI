// =============================================================================
// SilicaFlux-HPC verification :: formal harnesses for the tile's FIFOs
//
// fv_varray_fifo : hpc_varray_fifo (Module 03: command / tracking / completion queues)
// fv_dma_fifo    : dma_fifo (DataFabric: DMA queues, scratchpad request queues)
//
// Each DUT is compared, every cycle, with an independent reference FIFO written
// here as a shift register (head at index 0) -- a different structure from the
// DUTs' pointer-based ring buffers:
//   F1 no overflow / underflow of the reference itself under the documented caller
//      contract (assumptions: no push when full, no pop when empty)
//   F2 count / empty / full equal the reference occupancy
//   F3 head data equals the reference head whenever the FIFO is not empty
//      (=> order preserved, nothing lost, nothing duplicated, no corruption)
//   F4 reset: occupancy 0 right after reset (and clr for dma_fifo)
// Reset is asserted in the first cycle (initial assumption) and may be asserted
// again at any time (asynchronous); the reference is reset with it.
// =============================================================================
`default_nettype none

module fv_varray_fifo #(
  parameter int W     = 3,
  parameter int DEPTH = 3
) (
  input wire logic         clk,
  input wire logic         rst_n,
  input wire logic         push,
  input wire logic [W-1:0] wdata,
  input wire logic         pop
);
  localparam int CW = $clog2(DEPTH + 1);
  logic [W-1:0]  rdata;
  logic          empty, full;
  logic [CW-1:0] count;
  hpc_varray_fifo #(.W(W), .DEPTH(DEPTH)) dut (
    .clk_i(clk), .rst_ni(rst_n), .push_i(push), .wdata_i(wdata), .pop_i(pop),
    .rdata_o(rdata), .empty_o(empty), .full_o(full), .count_o(count));

  logic [W-1:0] q [DEPTH];
  logic [7:0]   n;
  logic         init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  // caller contract (hpc_varray_fifo header + its simulation check): no push while full unless a
  // pop happens in the same cycle, no pop while empty
  always @(*) if (rst_n) begin
    assume (!(push && n == DEPTH && !pop));
    assume (!(pop && n == 0));
  end
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) n <= 0;
    else begin
      for (int i = 0; i < DEPTH; i++) begin
        if (pop) q[i] <= (i + 1 < DEPTH) ? q[i + 1] : q[i];
      end
      if (push) q[pop ? n - 1 : n] <= wdata;
      n <= n + 8'(push) - 8'(pop);
    end
  end
  always @(*) if (rst_n && !init) begin
    assert (n <= DEPTH);                                 // F1
    assert (8'(count) == n);                             // F2
    assert (empty == (n == 0));
    assert (full == (n == DEPTH));
    if (n > 0) assert (rdata == q[0]);                   // F3
  end
  always @(posedge clk) if (!init && $past(!rst_n)) assert (count == '0 && empty);   // F4
  // non-vacuity
  always @(*) if (rst_n) cover (full);
  always @(*) if (rst_n) cover (n == DEPTH && pop && push);
endmodule

module fv_dma_fifo #(
  parameter int WIDTH = 3,
  parameter int DEPTH = 4
) (
  input wire logic             clk,
  input wire logic             rst_n,
  input wire logic             clr,
  input wire logic             push,
  input wire logic [WIDTH-1:0] wdata,
  input wire logic             pop
);
  localparam int AW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  logic [WIDTH-1:0] rdata;
  logic [AW:0]      count;
  dma_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (.clk, .rst_n, .clr, .push, .wdata, .pop, .rdata, .count);

  logic [WIDTH-1:0] q [DEPTH];
  logic [7:0]       n;
  logic             init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) if (init) assume (!rst_n);
  // caller contract (dma_fifo header and its simulation check): no push while full unless
  // popping in the same cycle, no pop while empty
  always @(*) if (rst_n && !clr) begin
    assume (!(push && n == DEPTH && !pop));
    assume (!(pop && n == 0));
  end
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) n <= 0;
    else if (clr) n <= 0;
    else begin
      for (int i = 0; i < DEPTH; i++) begin
        if (pop) q[i] <= (i + 1 < DEPTH) ? q[i + 1] : q[i];
      end
      if (push) q[pop ? n - 1 : n] <= wdata;
      n <= n + 8'(push) - 8'(pop);
    end
  end
  always @(*) if (rst_n && !init) begin
    assert (n <= DEPTH);
    assert (8'(count) == n);
    if (n > 0) assert (rdata == q[0]);
  end
  always @(posedge clk) if (!init && ($past(!rst_n) || $past(clr))) assert (count == '0);
  always @(*) if (rst_n) cover (8'(count) == DEPTH);
endmodule
`default_nettype wire
