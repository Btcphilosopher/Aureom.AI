/* =============================================================================
 * SilicaFlux FlashMap -- reference storage model (tests only)
 *
 * Independent of the FTL: it never looks at FTL state.  For every LBA it keeps
 *   ver[]  the version the host last got an acknowledgement for
 *          (0 = never written or deallocated -> must read as zeros)
 *   pend[] the version of an operation that was in flight when it failed
 *          (power loss, ENOSPC...): the LBA may read as either.  The first
 *          successful read resolves it, and from then on the value must be
 *          stable (no flip-flopping across later restarts).
 * Data of version v of LBA l is a deterministic 64-bit hash pattern of
 * (l, v), so the model needs 8 bytes per LBA, not a copy of the data.
 * ===========================================================================*/
#ifndef REFMODEL_H
#define REFMODEL_H

#include <stdint.h>

#define REF_NONE 0xFFFFFFFFu

typedef struct {
  uint64_t nlba;
  uint32_t lba_bytes;
  uint32_t *ver, *pend;
  uint32_t next_ver;
  uint64_t in_doubt;          /* LBAs currently with a pending version */
} refmodel_t;

int  ref_init(refmodel_t *r, uint64_t nlba, uint32_t lba_bytes);
void ref_free(refmodel_t *r);
void ref_fill(const refmodel_t *r, uint64_t lba, uint32_t ver, uint8_t *out);
/* begin a write: assigns new pending versions, fills `data` */
void ref_write_begin(refmodel_t *r, uint64_t lba, uint32_t n, uint8_t *data);
void ref_trim_begin(refmodel_t *r, uint64_t lba, uint32_t n);
void ref_ack(refmodel_t *r, uint64_t lba, uint32_t n);          /* operation acknowledged */
/* check `data` read back for [lba, lba+n); resolves pending versions.
 * returns the number of mismatching LBAs (first one in *bad) */
uint32_t ref_check(refmodel_t *r, uint64_t lba, uint32_t n, const uint8_t *data, uint64_t *bad);

#endif
