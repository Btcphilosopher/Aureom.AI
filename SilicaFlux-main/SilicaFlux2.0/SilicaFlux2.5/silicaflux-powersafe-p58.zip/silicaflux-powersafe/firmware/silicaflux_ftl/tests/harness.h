/* =============================================================================
 * SilicaFlux FlashMap -- test harness: simulated NAND + FTL + reference model
 * ===========================================================================*/
#ifndef HARNESS_H
#define HARNESS_H

#include <stdint.h>
#include <stdio.h>
#include "sfftl.h"
#include "sfftl_powersafe.h"
#include "simnand.h"
#include "refmodel.h"

typedef struct {
  sfftl_geom_t  g;
  sfftl_cfg_t   cfg;
  simnand_cfg_t ncfg;
  simnand_t    *nand;
  sfftl_hal_t   hal;
  sfftl_t       ftl;
  void         *arena;
  size_t        arena_bytes;
  refmodel_t    ref;
  uint8_t      *io;
  uint32_t      io_max;          /* LBAs per I/O buffer */
  uint64_t      rng;
  int           mounted;
  char          why[256];        /* first failure */
} hx_t;

/* geometry helpers */
void hx_geom(sfftl_geom_t *g, uint32_t page, uint32_t ppb, uint32_t blocks);

/* create the device (factory state), format the FTL, size the reference model */
int  hx_init(hx_t *h, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const simnand_cfg_t *nc, uint64_t seed);
void hx_free(hx_t *h);
uint64_t hx_rand(hx_t *h);
uint64_t hx_nlba(const hx_t *h);

int  hx_write(hx_t *h, uint64_t lba, uint32_t n);    /* sfftl rc; reference updated */
int  hx_trim(hx_t *h, uint64_t lba, uint32_t n);
int  hx_verify(hx_t *h, uint64_t lba, uint32_t n);   /* 0 ok, 1 mismatch (h->why), <0 read error */
int  hx_verify_all(hx_t *h);
/* restart: power the device on (if a cut killed it) and mount without shutdown */
int  hx_crash_mount(hx_t *h);
int  hx_clean_remount(hx_t *h);
/* one random operation: write / read+verify / trim / flush / background / checkpoint.
 * Returns sfftl rc of the operation, or 1000 on a data mismatch. */
int  hx_random_op(hx_t *h, uint32_t max_len, uint32_t trim_pct, uint32_t hot_pct);
int  hx_violations(const hx_t *h);
extern uint32_t hx_extra_flags;   /* P58: flags added to every configuration */

#endif
