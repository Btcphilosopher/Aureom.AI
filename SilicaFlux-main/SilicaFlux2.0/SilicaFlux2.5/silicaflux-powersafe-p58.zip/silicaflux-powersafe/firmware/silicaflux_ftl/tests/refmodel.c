/* SilicaFlux FlashMap -- reference storage model (see refmodel.h) */
#include <stdlib.h>
#include <string.h>
#include "refmodel.h"

static uint64_t mix(uint64_t z) {
  z += 0x9E3779B97F4A7C15ull;
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}

int ref_init(refmodel_t *r, uint64_t nlba, uint32_t lba_bytes) {
  memset(r, 0, sizeof(*r));
  r->nlba = nlba;
  r->lba_bytes = lba_bytes;
  r->ver = (uint32_t *)calloc((size_t)nlba, 4);
  r->pend = (uint32_t *)malloc((size_t)nlba * 4);
  if (!r->ver || !r->pend) return -1;
  for (uint64_t i = 0; i < nlba; i++) r->pend[i] = REF_NONE;
  r->next_ver = 1;
  return 0;
}

void ref_free(refmodel_t *r) { free(r->ver); free(r->pend); memset(r, 0, sizeof(*r)); }

void ref_fill(const refmodel_t *r, uint64_t lba, uint32_t ver, uint8_t *out) {
  if (ver == 0) { memset(out, 0, r->lba_bytes); return; }
  uint64_t seed = mix(lba * 0x100000001B3ull ^ ((uint64_t)ver << 32) ^ ver);
  for (uint32_t i = 0; i < r->lba_bytes; i += 8) {
    uint64_t w = mix(seed + i);
    memcpy(out + i, &w, 8);
  }
}

static void set_pend(refmodel_t *r, uint64_t l, uint32_t v) {
  if (r->pend[l] == REF_NONE) r->in_doubt++;
  r->pend[l] = v;
}

void ref_write_begin(refmodel_t *r, uint64_t lba, uint32_t n, uint8_t *data) {
  for (uint32_t i = 0; i < n; i++) {
    uint32_t v = r->next_ver++;
    if (r->next_ver == REF_NONE) r->next_ver = 1;
    set_pend(r, lba + i, v);
    ref_fill(r, lba + i, v, data + (size_t)i * r->lba_bytes);
  }
}

void ref_trim_begin(refmodel_t *r, uint64_t lba, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) set_pend(r, lba + i, 0);
}

void ref_ack(refmodel_t *r, uint64_t lba, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) {
    uint64_t l = lba + i;
    if (r->pend[l] != REF_NONE) { r->ver[l] = r->pend[l]; r->pend[l] = REF_NONE; r->in_doubt--; }
  }
}

uint32_t ref_check(refmodel_t *r, uint64_t lba, uint32_t n, const uint8_t *data, uint64_t *bad) {
  uint8_t *exp = (uint8_t *)malloc(r->lba_bytes);
  uint32_t mism = 0;
  for (uint32_t i = 0; i < n; i++) {
    uint64_t l = lba + i;
    const uint8_t *got = data + (size_t)i * r->lba_bytes;
    ref_fill(r, l, r->ver[l], exp);
    if (memcmp(exp, got, r->lba_bytes) == 0) {
      if (r->pend[l] != REF_NONE) { r->pend[l] = REF_NONE; r->in_doubt--; }
      continue;
    }
    if (r->pend[l] != REF_NONE) {
      ref_fill(r, l, r->pend[l], exp);
      if (memcmp(exp, got, r->lba_bytes) == 0) { r->ver[l] = r->pend[l]; r->pend[l] = REF_NONE; r->in_doubt--; continue; }
    }
    if (!mism && bad) *bad = l;
    mism++;
  }
  free(exp);
  return mism;
}
