/* SilicaFlux FlashMap -- test harness (see harness.h) */
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include "harness.h"

void hx_geom(sfftl_geom_t *g, uint32_t page, uint32_t ppb, uint32_t blocks) {
  g->page_data_bytes = page;
  g->page_spare_bytes = page / 32u > SFFTL_OOB_BYTES ? page / 32u : SFFTL_OOB_BYTES;
  g->pages_per_block = ppb;
  g->blocks = blocks;
}

uint64_t hx_rand(hx_t *h) {
  uint64_t z = (h->rng += 0x9E3779B97F4A7C15ull);
  z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ull;
  z = (z ^ (z >> 27)) * 0x94D049BB133111EBull;
  return z ^ (z >> 31);
}

uint64_t hx_nlba(const hx_t *h) { return sfftl_capacity_lba(&h->ftl); }

uint32_t hx_extra_flags;   /* P58: OR-ed into every configuration (test_main --p58) */

int hx_init(hx_t *h, const sfftl_geom_t *g, const sfftl_cfg_t *cfg_in, const simnand_cfg_t *nc, uint64_t seed) {
  memset(h, 0, sizeof(*h));
  h->g = *g;
  h->cfg = *cfg_in;
  h->cfg.flags |= hx_extra_flags;
  const sfftl_cfg_t *cfg = &h->cfg;
  h->rng = seed;
  if (nc) h->ncfg = *nc;
  else {
    simnand_cfg_default(&h->ncfg, g->page_data_bytes, g->pages_per_block, g->blocks);
    h->ncfg.torn_pass_permille = 250;      /* 1 torn page in 4 slips past ECC: only the CRC can reject it */
  }
  h->ncfg.page_spare_bytes = g->page_spare_bytes;
  h->nand = simnand_create(&h->ncfg, seed * 7919u + 1u);
  if (!h->nand) return SFFTL_ENOMEM;
  simnand_hal(h->nand, &h->hal);
  h->arena_bytes = sfftl_mem_required(g, cfg);
  if (!h->arena_bytes) return SFFTL_EINVAL;
  h->arena = aligned_alloc(8, (h->arena_bytes + 7u) & ~(size_t)7u);
  int rc = sfftl_format(&h->ftl, g, cfg, &h->hal, h->arena, h->arena_bytes);
  if (rc < 0) return rc;
  h->mounted = 1;
  if (ref_init(&h->ref, hx_nlba(h), cfg->lba_bytes) < 0) return SFFTL_ENOMEM;
  h->io_max = 4u * (g->page_data_bytes / cfg->lba_bytes) + 64u;
  h->io = (uint8_t *)malloc((size_t)h->io_max * cfg->lba_bytes);
  return h->io ? SFFTL_OK : SFFTL_ENOMEM;
}

void hx_free(hx_t *h) {
  simnand_destroy(h->nand);
  free(h->arena);
  free(h->io);
  ref_free(&h->ref);
  memset(h, 0, sizeof(*h));
}

/* A failed (unacknowledged) write may still have landed some of its pages.
 * While the device is alive, resolve those LBAs at once by reading them back,
 * so the model never has to remember more than one in-doubt version per LBA.
 * After a power loss the device is dead: the next mount + verify resolves. */
static int resolve_failed(hx_t *h, uint64_t lba, uint32_t n, int rc) {
  if (rc == SFFTL_OK || rc == SFFTL_EPOWER || !simnand_powered(h->nand) || !h->ftl.mounted) return rc;
  int v = hx_verify(h, lba, n);
  if (v == 1) return 1000;                       /* real mismatch: neither old nor new data */
  return rc;
}

int hx_write(hx_t *h, uint64_t lba, uint32_t n) {
  ref_write_begin(&h->ref, lba, n, h->io);
  int rc = sfftl_write(&h->ftl, lba, n, h->io);
  if (rc == SFFTL_OK) ref_ack(&h->ref, lba, n);
  return resolve_failed(h, lba, n, rc);
}

int hx_trim(hx_t *h, uint64_t lba, uint32_t n) {
  ref_trim_begin(&h->ref, lba, n);
  int rc = sfftl_trim(&h->ftl, lba, n);
  if (rc == SFFTL_OK) ref_ack(&h->ref, lba, n);
  return resolve_failed(h, lba, n, rc);
}

int hx_verify(hx_t *h, uint64_t lba, uint32_t n) {
  while (n) {
    uint32_t k = n < h->io_max ? n : h->io_max;
    int rc = sfftl_read(&h->ftl, lba, k, h->io);
    if (rc < 0) {
      snprintf(h->why, sizeof(h->why), "read lba %" PRIu64 "+%u: %s", lba, k, sfftl_strerror(rc));
      return rc;
    }
    uint64_t bad = 0;
    uint32_t m = ref_check(&h->ref, lba, k, h->io, &bad);
    if (m) {
      snprintf(h->why, sizeof(h->why), "data mismatch: %u LBA(s), first %" PRIu64 " (ver %u pend %u)", m, bad,
               h->ref.ver[bad], h->ref.pend[bad]);
      return 1;
    }
    lba += k; n -= k;
  }
  return 0;
}

int hx_verify_all(hx_t *h) { return hx_verify(h, 0, (uint32_t)hx_nlba(h)); }

int hx_crash_mount(hx_t *h) {
  if (!simnand_powered(h->nand)) simnand_power_on(h->nand);
  simnand_disarm_powercut(h->nand);
  int rc = sfftl_mount(&h->ftl, &h->g, &h->cfg, &h->hal, h->arena, h->arena_bytes);
  h->mounted = rc == SFFTL_OK;
  return rc;
}

int hx_clean_remount(hx_t *h) {
  int rc = sfftl_shutdown(&h->ftl);
  if (rc < 0) return rc;
  return hx_crash_mount(h);
}

int hx_random_op(hx_t *h, uint32_t max_len, uint32_t trim_pct, uint32_t hot_pct) {
  uint64_t nlba = hx_nlba(h);
  uint32_t r = (uint32_t)(hx_rand(h) % 100u);
  uint32_t len = 1u + (uint32_t)(hx_rand(h) % max_len);
  uint64_t lba;
  /* hot_pct of the accesses go to the first 1/8 of the LBA space */
  if ((uint32_t)(hx_rand(h) % 100u) < hot_pct) lba = hx_rand(h) % (nlba / 8u ? nlba / 8u : 1u);
  else lba = hx_rand(h) % nlba;
  if (lba + len > nlba) len = (uint32_t)(nlba - lba);
  if (r < trim_pct) return hx_trim(h, lba, len);
  if (r < 60u) return hx_write(h, lba, len);
  if (r < 94u) { int v = hx_verify(h, lba, len); return v == 1 ? 1000 : v; }
  if (r < 96u) return sfftl_flush(&h->ftl);
  if (r < 99u) { int rc = sfftl_background(&h->ftl, 64); return rc > 0 ? 0 : rc; }
  return sfftl_checkpoint(&h->ftl);
}

int hx_violations(const hx_t *h) { return (int)simnand_stats(h->nand)->violations; }
