/* =============================================================================
 * SilicaFlux FlashMap firmware -- CRC-32 / copy microbenchmark on the ControlCore
 *
 * Evidence for the accelerator decision (docs/10 §4): the FTL self-test showed
 * CRC-32 is the largest CPU cost.  This image measures, with mcycle on the RTL
 * CPU, what software alone can do before hardware is considered:
 *   byte-at-a-time table (the library's v1 algorithm), slice-by-4, slice-by-8,
 *   the library's current sfftl_crc32_update,
 *   CRC read straight from the storage buffer SRAM (zero-copy variant),
 *   and the 528-byte DMEM <-> buffer SRAM copies the HAL performs.
 * All CRC variants must agree (checked).  Verdict via SYSCTRL.TEST_CTRL.
 * ===========================================================================*/
#include "cc_hw.h"
#include "sfs_map.h"
#include "fw.h"

uint32_t sfftl_crc32_update(uint32_t crc, const void *data, uint32_t len);

static uint32_t T[8][256];
static uint32_t g_buf[132];             /* 528 B, DMEM */

static void tables(void) {
  for (uint32_t i = 0; i < 256u; i++) {
    uint32_t c = i;
    for (int k = 0; k < 8; k++) c = (c & 1u) ? (0xEDB88320u ^ (c >> 1)) : (c >> 1);
    T[0][i] = c;
  }
  for (uint32_t k = 1; k < 8u; k++)
    for (uint32_t i = 0; i < 256u; i++) T[k][i] = (T[k - 1][i] >> 8) ^ T[0][T[k - 1][i] & 0xFFu];
}

static uint32_t crc_bytes(uint32_t c, const uint8_t *p, uint32_t len) {
  while (len--) c = T[0][(c ^ *p++) & 0xFFu] ^ (c >> 8);
  return c;
}

/* word-aligned buffers, little-endian CPU */
static uint32_t crc_s4(uint32_t c, const uint32_t *w, uint32_t words) {
  for (uint32_t i = 0; i < words; i++) {
    uint32_t a = w[i] ^ c;
    c = T[3][a & 0xFFu] ^ T[2][(a >> 8) & 0xFFu] ^ T[1][(a >> 16) & 0xFFu] ^ T[0][a >> 24];
  }
  return c;
}
static uint32_t crc_s8(uint32_t c, const uint32_t *w, uint32_t words) {
  for (uint32_t i = 0; i + 1u < words; i += 2u) {
    uint32_t a = w[i] ^ c, b = w[i + 1];
    c = T[7][a & 0xFFu] ^ T[6][(a >> 8) & 0xFFu] ^ T[5][(a >> 16) & 0xFFu] ^ T[4][a >> 24] ^
        T[3][b & 0xFFu] ^ T[2][(b >> 8) & 0xFFu] ^ T[1][(b >> 16) & 0xFFu] ^ T[0][b >> 24];
  }
  return c;
}
static uint32_t crc_bytes_volatile(uint32_t c, const volatile uint32_t *w, uint32_t words) {
  for (uint32_t i = 0; i < words; i++) {
    uint32_t v = w[i];
    for (int k = 0; k < 4; k++) { c = T[0][(c ^ v) & 0xFFu] ^ (c >> 8); v >>= 8; }
  }
  return c;
}
static uint32_t crc_s8_volatile(uint32_t c, const volatile uint32_t *w, uint32_t words) {
  for (uint32_t i = 0; i + 1u < words; i += 2u) {
    uint32_t a = w[i] ^ c, b = w[i + 1];
    c = T[7][a & 0xFFu] ^ T[6][(a >> 8) & 0xFFu] ^ T[5][(a >> 16) & 0xFFu] ^ T[4][a >> 24] ^
        T[3][b & 0xFFu] ^ T[2][(b >> 8) & 0xFFu] ^ T[1][(b >> 16) & 0xFFu] ^ T[0][b >> 24];
  }
  return c;
}

static uint32_t cyc(void) { return csr_read(mcycle); }

int main(void) {
  cprintf("\n[crc] CRC-32 / copy microbenchmark, 528-byte page (512 data + 16 spare)\n");
  tables();
  uint32_t x = 0x12345678u;
  for (uint32_t i = 0; i < 132u; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; g_buf[i] = x; }
  volatile uint32_t *sram = (volatile uint32_t *)(uintptr_t)SFS_BUF_BASE;
  uint32_t t0, c_lib, c_byte, c_s4, c_s8, c_sram_b, c_sram_s8, c_cpy_in, c_cpy_out, r_lib, r_byte, r_s4, r_s8, r_sb, r_s8b;
  int fail = 0;
  t0 = cyc(); r_byte = crc_bytes(0xFFFFFFFFu, (const uint8_t *)g_buf, 528u); c_byte = cyc() - t0;
  t0 = cyc(); r_lib = sfftl_crc32_update(0xFFFFFFFFu, g_buf, 528u); c_lib = cyc() - t0;
  t0 = cyc(); r_s4 = crc_s4(0xFFFFFFFFu, g_buf, 132u); c_s4 = cyc() - t0;
  t0 = cyc(); r_s8 = crc_s8(0xFFFFFFFFu, g_buf, 132u); c_s8 = cyc() - t0;
  t0 = cyc(); for (uint32_t i = 0; i < 132u; i++) sram[i] = g_buf[i]; c_cpy_in = cyc() - t0;
  t0 = cyc(); for (uint32_t i = 0; i < 132u; i++) g_buf[i] = sram[i]; c_cpy_out = cyc() - t0;
  t0 = cyc(); r_sb = crc_bytes_volatile(0xFFFFFFFFu, sram, 132u); c_sram_b = cyc() - t0;
  t0 = cyc(); r_s8b = crc_s8_volatile(0xFFFFFFFFu, sram, 132u); c_sram_s8 = cyc() - t0;
  if (r_byte != r_lib || r_s4 != r_lib || r_s8 != r_lib || r_sb != r_lib || r_s8b != r_lib) {
    cprintf("[crc] FAIL: results differ %x %x %x %x %x\n", r_lib, r_s4, r_s8, r_sb, r_s8b);
    fail = 1;
  }
  cprintf("[crc] crc32 %x (all variants agree: %s)\n", r_lib, fail ? "no" : "yes");
  cprintf("PERF crc_bytewise_dmem=%u crc_library_dmem=%u crc_slice4_dmem=%u crc_slice8_dmem=%u crc_bytewise_bufsram=%u"
          " crc_slice8_bufsram=%u copy_dmem_to_bufsram=%u copy_bufsram_to_dmem=%u\n", c_byte, c_lib, c_s4, c_s8, c_sram_b,
          c_sram_s8, c_cpy_in, c_cpy_out);
  cprintf("[crc] RESULT %s\n", fail ? "FAIL" : "PASS");
  test_finish(fail, 1);
  return 0;
}
