/* =============================================================================
 * SilicaFlux FlashMap firmware -- minimal platform layer for the ControlCore
 *   console (MAILBOX DIAG FIFO), libc subset, trap handler, test port.
 * Derived from StorageCore P51 firmware/app/platform.c (console, libc subset);
 * the FTL self-test is polled, so no interrupt is enabled.
 * ===========================================================================*/
#include <stdarg.h>
#include "cc_hw.h"
#include "fw.h"

void *memcpy(void *d, const void *s, size_t n) {
  uint8_t *dp = (uint8_t *)d;
  const uint8_t *sp = (const uint8_t *)s;
  if ((((uintptr_t)dp | (uintptr_t)sp | n) & 3u) == 0u) {          /* word path for aligned buffers */
    uint32_t *dw = (uint32_t *)d;
    const uint32_t *sw = (const uint32_t *)s;
    for (size_t i = 0; i < n / 4u; i++) dw[i] = sw[i];
    return d;
  }
  while (n--) *dp++ = *sp++;
  return d;
}
void *memset(void *d, int c, size_t n) {
  uint8_t *dp = (uint8_t *)d;
  if ((((uintptr_t)dp | n) & 3u) == 0u) {
    uint32_t v = (uint8_t)c * 0x01010101u, *dw = (uint32_t *)d;
    for (size_t i = 0; i < n / 4u; i++) dw[i] = v;
    return d;
  }
  while (n--) *dp++ = (uint8_t)c;
  return d;
}
int memcmp(const void *a, const void *b, size_t n) {
  const uint8_t *x = (const uint8_t *)a, *y = (const uint8_t *)b;
  for (size_t i = 0; i < n; i++) if (x[i] != y[i]) return x[i] < y[i] ? -1 : 1;
  return 0;
}

void con_putc(char c) { MBOX(CC_MBOX_DIAG_TX) = (uint8_t)c; }
static void con_puts(const char *s) { while (*s) con_putc(*s++); }
static void put_u(uint32_t v, unsigned base, int width, char pad) {
  char buf[12];
  int n = 0;
  do { uint32_t d = v % base; buf[n++] = (char)(d < 10 ? '0' + d : 'a' + d - 10); v /= base; } while (v);
  while (n < width) buf[n++] = pad;
  while (n) con_putc(buf[--n]);
}
void cprintf(const char *fmt, ...) {
  va_list ap;
  va_start(ap, fmt);
  for (; *fmt; fmt++) {
    if (*fmt != '%') { con_putc(*fmt); continue; }
    int width = 0;
    char pad = ' ';
    fmt++;
    if (*fmt == '0') { pad = '0'; fmt++; }
    while (*fmt >= '0' && *fmt <= '9') width = width * 10 + (*fmt++ - '0');
    switch (*fmt) {
      case 'c': con_putc((char)va_arg(ap, int)); break;
      case 's': con_puts(va_arg(ap, const char *)); break;
      case 'u': put_u(va_arg(ap, uint32_t), 10, width, pad); break;
      case 'd': { int v = va_arg(ap, int); if (v < 0) { con_putc('-'); v = -v; } put_u((uint32_t)v, 10, width, pad); break; }
      case 'x': put_u(va_arg(ap, uint32_t), 16, width, pad); break;
      case '%': con_putc('%'); break;
      default:  con_putc('?'); break;
    }
  }
  va_end(ap);
}


void test_finish(int fail, uint32_t code) {
  SYSCTRL(CC_SYSCTRL_TEST_CTRL) = 0x80000000u | (fail ? 0x40000000u : 0u) | (code & 0xFFFFu);
  for (;;) __asm__ volatile("wfi");
}

typedef struct { uint32_t x[32]; uint32_t mepc; } trap_frame_t;
void trap_handler(trap_frame_t *f) {
  cprintf("\n[FATAL] trap mcause=%x mepc=%x mtval=%x\n", csr_read(mcause), f->mepc, csr_read(mtval));
  test_finish(1, 0xDEADu);
}

/* testbench request: print "TBREQ <id> ...", wait until the host wrote <id> to SCRATCH3 */
static uint32_t g_req_id;
void tb_request(const char *what, uint32_t a, uint32_t b, uint32_t c, uint32_t d) {
  g_req_id++;
  cprintf("TBREQ %u %s %u %u %u %u\n", g_req_id, what, a, b, c, d);
  uint32_t t0 = csr_read(mcycle);
  while (SYSCTRL(CC_SYSCTRL_SCRATCH3) != g_req_id) {
    if (csr_read(mcycle) - t0 > 50000000u) { cprintf("[fw] testbench request %u not answered\n", g_req_id); test_finish(1, 0xBEEFu); }
  }
}
