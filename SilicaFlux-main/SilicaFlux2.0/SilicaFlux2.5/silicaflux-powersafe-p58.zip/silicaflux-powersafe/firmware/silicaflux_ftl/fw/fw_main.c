/* =============================================================================
 * SilicaFlux FlashMap firmware -- FTL self-test on the ControlCore (RV32IM)
 *
 * Runs the unmodified FTL library against the REAL StorageCore (P51) NAND
 * controller RTL and its behavioural flash model, in RTL simulation
 * (rtl_sim/tb_ftl_soc.sv).  An on-target reference model (16-bit version per
 * LBA; data regenerated from a hash of LBA and version) checks every read.
 *
 * Phases: bring-up, format (factory-bad blocks preset by the testbench),
 * sequential fill, random overwrites with GC, TRIM, clean restart, unclean
 * restart (RAM state discarded), grown bad block (program failure injected
 * through the testbench), correctable / uncorrectable read errors, final
 * verification.  Cycle counts (mcycle) are reported as PERF lines.
 * Verdict through the ControlCore test port (SYSCTRL.TEST_CTRL).
 * ===========================================================================*/
#include "cc_hw.h"
#include "sfs_map.h"
#include "fw.h"
#include "sfftl.h"
#include "sfftl_powersafe.h"
#include "hal_sfs.h"

#define SYS(o)       REG32(SFS_SYS_BASE + (o))
#define ARENA_BYTES  12288u
#define MAXLBA       1024u
#define N_RANDOM     1500u

uint32_t sfftl_crc32_update(uint32_t crc, const void *data, uint32_t len);   /* library-internal, measured below */

static uint64_t     g_arena[ARENA_BYTES / 8u];
static sfftl_t      g_ftl;
static sfs_hal_t    g_hw;
static sfftl_hal_t  g_hal;
static sfftl_cfg_t  g_cfg;
static const sfftl_geom_t g_geom = { 512u, 16u, SFS_HAL_PPB, SFS_HAL_BLOCKS };
static uint16_t     g_ver[MAXLBA];
static uint16_t     g_vnext = 1;
static uint32_t     g_wbuf[4 * 128], g_rbuf[4 * 128], g_xbuf[128];
static uint32_t     g_rng = 0x5F1CA0F1u, g_fail, g_checks, g_nlba;

static uint32_t rnd(void) { g_rng ^= g_rng << 13; g_rng ^= g_rng >> 17; g_rng ^= g_rng << 5; return g_rng; }

static void pattern(uint32_t lba, uint32_t v, uint32_t *out) {
  if (!v) { memset(out, 0, 512); return; }
  uint32_t x = (lba * 2654435761u) ^ (v * 0x9E3779B9u) ^ 0xA5A5A5A5u;
  if (!x) x = 1;
  for (uint32_t i = 0; i < 128u; i++) { x ^= x << 13; x ^= x >> 17; x ^= x << 5; out[i] = x ^ i; }
}

#define CHECK(c, what, a, b) do { g_checks++; if (!(c)) { g_fail++; if (g_fail < 12) cprintf("[fw] FAIL %s (%u, %u)\n", what, (uint32_t)(a), (uint32_t)(b)); } } while (0)

static int wr(uint32_t lba, uint32_t n) {
  uint16_t v0 = g_vnext;
  for (uint32_t i = 0; i < n; i++) pattern(lba + i, (uint16_t)(v0 + i), &g_wbuf[128u * i]);
  g_vnext = (uint16_t)(v0 + n);
  int rc = sfftl_write(&g_ftl, lba, n, g_wbuf);
  if (rc == SFFTL_OK) for (uint32_t i = 0; i < n; i++) g_ver[lba + i] = (uint16_t)(v0 + i);
  return rc;
}
static int vf(uint32_t lba) {
  int rc = sfftl_read(&g_ftl, lba, 1, g_rbuf);
  if (rc) return rc;
  pattern(lba, g_ver[lba], g_xbuf);
  return memcmp(g_xbuf, g_rbuf, 512) ? 1000 : 0;
}
static uint32_t verify_all(const char *when) {
  uint32_t bad = 0, first = 0;
  for (uint32_t l = 0; l < g_nlba; l++) if (vf(l)) { if (!bad) first = l; bad++; }
  CHECK(bad == 0, when, bad, first);
  CHECK(sfftl_check(&g_ftl) == SFFTL_OK, "invariants", 0, 0);
  cprintf("[fw] verify %s: %u LBAs, %u mismatches\n", when, g_nlba, bad);
  return bad;
}
static uint32_t cyc(void) { return csr_read(mcycle); }

static void print_stats(const char *tag) {
  const sfftl_stats_t *s = sfftl_stats(&g_ftl);
  sfftl_space_t sp; sfftl_space(&g_ftl, &sp);
  uint32_t prog = (uint32_t)(s->nand_prog_host + s->nand_prog_reloc + s->nand_prog_meta);
  uint32_t lbas = (uint32_t)s->host_lba_written;
  cprintf("[fw] %s: host LBAs %u, programs host/reloc/meta %u/%u/%u (WA x100 = %u), erases %u, GC victims %u, ckpts %u,"
          " retired %u, prog_fail %u, read corrected %u uncorrectable %u\n", tag, lbas, (uint32_t)s->nand_prog_host,
          (uint32_t)s->nand_prog_reloc, (uint32_t)s->nand_prog_meta, lbas ? prog * 100u / lbas : 0u,
          (uint32_t)(s->nand_erase_data + s->nand_erase_meta), (uint32_t)s->gc_victims, (uint32_t)s->ckpt_count,
          (uint32_t)s->blocks_retired, (uint32_t)s->prog_fail, (uint32_t)s->read_corrected, (uint32_t)s->read_uncorrectable);
  cprintf("[fw] %s: blocks free %u closed %u open %u meta %u bad factory %u grown %u; EC min %u max %u mean x10 %u\n", tag,
          sp.blocks_free, sp.blocks_closed, sp.blocks_open, sp.blocks_meta, sp.blocks_bad_factory, sp.blocks_bad_grown,
          sp.ec_min, sp.ec_max, sp.ec_blocks ? (uint32_t)(sp.ec_sum * 10u / sp.ec_blocks) : 0u);
}

static int do_mount(void) { return sfftl_mount(&g_ftl, &g_geom, &g_cfg, &g_hal, g_arena, sizeof(g_arena)); }

int main(void) {
  boot_stage(CC_BOOT_STAGE_FW_INIT);
  cprintf("\n[fw] SilicaFlux FlashMap FTL self-test, firmware %x, library %x\n", FW_VERSION, SFFTL_VERSION);
  /* ---------------------------------------------------------------- bring-up */
  boot_stage(CC_BOOT_STAGE_ACC_DISCOVERY);
  if (SYS(SFS_SYS_ID) != SFS_SYS_ID_VALUE) { cprintf("[fw] storage subsystem missing\n"); test_finish(1, 1); }
  uint32_t t0 = cyc();
  while (!(SYS(SFS_SYS_READY) & 1u)) if (cyc() - t0 > 4000000u) { cprintf("[fw] buffer not ready\n"); test_finish(1, 2); }
  uint32_t id0 = 0;
  int hrc = sfs_hal_init(&g_hw, 0, SFS_BUF_BASE, &id0);
  cprintf("[fw] NAND ch0: CH_INFO page %u B, ECC %u, READ_ID %x -> %d\n", REG32(SFS_NAND_BASE + SFS_NAND_CH_INFO) >> 16,
          g_hw.ecc, id0, hrc);
  if (hrc) test_finish(1, 3);
  sfs_hal_bind(&g_hw, &g_hal);
  sfftl_cfg_default(&g_cfg);
  g_cfg.flags |= SFFTL_F_PARANOID;
  g_cfg.wl_static_threshold = 8;
  g_cfg.wl_static_interval = 16;
  sfftl_layout_t L;
  sfftl_layout_info(&g_geom, &g_cfg, &L);
  cprintf("[fw] layout: arena %u B (L2P %u, bitmap %u, blocks %u, buffers %u, journal %u, scratch %u), instance %u B,"
          " %u metadata blocks, checkpoint %u pages\n", (uint32_t)L.total_bytes, (uint32_t)L.l2p_bytes, (uint32_t)L.vbm_bytes,
          (uint32_t)L.blk_bytes, (uint32_t)L.buf_bytes, (uint32_t)L.journal_bytes, (uint32_t)L.scratch_bytes,
          (uint32_t)sizeof(sfftl_t), L.meta_blocks, L.ckpt_pages);
  CHECK(L.total_bytes <= sizeof(g_arena), "arena fits", L.total_bytes, sizeof(g_arena));
  /* ---------------------------------------------------------------- format */
  boot_stage(CC_BOOT_STAGE_SELF_TEST);
  t0 = cyc();
  int rc = sfftl_format(&g_ftl, &g_geom, &g_cfg, &g_hal, g_arena, sizeof(g_arena));
  uint32_t c_format = cyc() - t0;
  CHECK(rc == SFFTL_OK, "format", (uint32_t)-rc, 0);
  if (rc) test_finish(1, 4);
  g_nlba = (uint32_t)sfftl_capacity_lba(&g_ftl);
  sfftl_space_t sp; sfftl_space(&g_ftl, &sp);
  cprintf("[fw] formatted: %u LBAs x 512 B, factory-bad blocks %u (expected 2: 13, 41)\n", g_nlba, sp.blocks_bad_factory);
  CHECK(sp.blocks_bad_factory == 2u && g_ftl.blk[13].state == SFFTL_BS_BAD && g_ftl.blk[41].state == SFFTL_BS_BAD,
        "factory markers found", sp.blocks_bad_factory, 0);
  cprintf("PERF format_cycles=%u\n", c_format);
  /* ---------------------------------------------------------------- sequential fill */
  for (uint32_t l = 0; l < g_nlba; l++) { rc = wr(l, 1); if (rc) { CHECK(0, "fill", l, (uint32_t)-rc); break; } }
  verify_all("after sequential fill");
  /* ---------------------------------------------------------------- random overwrites (GC) */
  const sfftl_stats_t *s = sfftl_stats(&g_ftl);
  uint32_t lba0 = (uint32_t)s->host_lba_written, hal0 = (uint32_t)g_hw.cyc_total, copy0 = (uint32_t)g_hw.cyc_copy;
  uint32_t prog0 = g_hw.programs, rd0 = g_hw.reads, er0 = g_hw.erases;
  t0 = cyc();
  for (uint32_t i = 0; i < N_RANDOM; i++) {
    uint32_t n = (rnd() % 8u == 0u) ? 4u : 1u;
    uint32_t l = rnd() % (g_nlba - n);
    rc = wr(l, n);
    if (rc) { CHECK(0, "random write", i, (uint32_t)-rc); break; }
    if ((i & 15u) == 0u) { uint32_t v = rnd() % g_nlba; CHECK(vf(v) == 0, "read after overwrite", v, i); }
  }
  uint32_t c_rand = cyc() - t0;
  uint32_t lbas = (uint32_t)s->host_lba_written - lba0, hal = (uint32_t)g_hw.cyc_total - hal0, copy = (uint32_t)g_hw.cyc_copy - copy0;
  cprintf("PERF random_phase_cycles=%u host_lbas=%u nand_programs=%u nand_reads=%u nand_erases=%u hal_cycles=%u copy_cycles=%u\n",
          c_rand, lbas, g_hw.programs - prog0, g_hw.reads - rd0, g_hw.erases - er0, hal, copy);
  cprintf("PERF write_cycles_per_lba=%u hal_cycles_per_lba=%u ftl_cycles_per_lba=%u\n", c_rand / lbas, hal / lbas,
          (c_rand - hal) / lbas);
  verify_all("after random overwrites");
  print_stats("after random overwrites");
  /* ---------------------------------------------------------------- reads */
  hal0 = (uint32_t)g_hw.cyc_total;
  t0 = cyc();
  for (uint32_t i = 0; i < 256u; i++) (void)sfftl_read(&g_ftl, rnd() % g_nlba, 1, g_rbuf);
  uint32_t c_read = cyc() - t0;
  hal = (uint32_t)g_hw.cyc_total - hal0;
  cprintf("PERF read_cycles_per_lba=%u hal_cycles_per_read=%u ftl_cycles_per_read=%u\n", c_read / 256u, hal / 256u,
          (c_read - hal) / 256u);
  /* ---------------------------------------------------------------- TRIM */
  for (uint32_t i = 0; i < 40u; i++) {
    uint32_t n = 1u + rnd() % 16u, l = rnd() % (g_nlba - n);
    rc = sfftl_trim(&g_ftl, l, n);
    CHECK(rc == SFFTL_OK, "trim", l, (uint32_t)-rc);
    if (!rc) for (uint32_t k = 0; k < n; k++) g_ver[l + k] = 0;
  }
  verify_all("after TRIM");
  t0 = cyc();
  for (uint32_t i = 0; i < 64u; i++) (void)sfftl_read(&g_ftl, 0, 1, g_rbuf);
  if (g_ver[0] == 0) cprintf("PERF unmapped_read_cycles=%u\n", (cyc() - t0) / 64u);
  /* ---------------------------------------------------------------- micro: CRC-32 of one page + spare */
  t0 = cyc();
  volatile uint32_t crc = sfftl_crc32_update(0xFFFFFFFFu, g_wbuf, 528u);
  (void)crc;
  cprintf("PERF crc32_528B_cycles=%u\n", cyc() - t0);
  /* ---------------------------------------------------------------- clean restart */
  t0 = cyc();
  rc = sfftl_shutdown(&g_ftl);
  uint32_t c_shut = cyc() - t0;
  CHECK(rc == SFFTL_OK, "shutdown", (uint32_t)-rc, 0);
  memset(&g_ftl, 0xA5, sizeof(g_ftl));                       /* RAM state really gone */
  memset(g_arena, 0x5A, sizeof(g_arena));
  t0 = cyc();
  rc = do_mount();
  uint32_t c_mclean = cyc() - t0;
  CHECK(rc == SFFTL_OK && sfftl_stats(&g_ftl)->mount_clean == 1u, "clean mount", (uint32_t)-rc, 0);
  cprintf("PERF shutdown_cycles=%u clean_mount_cycles=%u\n", c_shut, c_mclean);
  verify_all("after clean restart");
  /* ---------------------------------------------------------------- unclean restart */
  for (uint32_t i = 0; i < 300u; i++) { rc = wr(rnd() % g_nlba, 1); if (rc) { CHECK(0, "write", i, (uint32_t)-rc); break; } }
  memset(&g_ftl, 0xA5, sizeof(g_ftl));                       /* crash: no shutdown, RAM lost */
  memset(g_arena, 0x5A, sizeof(g_arena));
  t0 = cyc();
  rc = do_mount();
  uint32_t c_munclean = cyc() - t0;
  CHECK(rc == SFFTL_OK && sfftl_stats(&g_ftl)->mount_unclean == 1u, "unclean mount", (uint32_t)-rc, 0);
  cprintf("PERF unclean_mount_cycles=%u pages_replayed=%u\n", c_munclean, sfftl_stats(&g_ftl)->last_mount_pages_replayed);
  verify_all("after unclean restart (roll-forward)");
  /* ---------------------------------------------------------------- grown bad block: program failure */
  uint32_t hb = g_ftl.stream_blk[0];
  if (hb == SFFTL_NONE) { wr(1, 1); hb = g_ftl.stream_blk[0]; }
  tb_request("BAD", hb, 0, 0, 0);                             /* testbench: NAND model fails program/erase */
  for (uint32_t i = 0; i < 300u; i++) { rc = wr(rnd() % g_nlba, 1); if (rc) { CHECK(0, "write after bad", i, (uint32_t)-rc); break; } }
  (void)sfftl_background(&g_ftl, 1000u);
  CHECK(sfftl_stats(&g_ftl)->prog_fail >= 1u, "program failure seen", (uint32_t)sfftl_stats(&g_ftl)->prog_fail, hb);
  CHECK(g_ftl.blk[hb].state == SFFTL_BS_BAD, "failed block retired", hb, g_ftl.blk[hb].state);
  verify_all("after grown bad block");
  /* ---------------------------------------------------------------- read errors (SECDED in the controller) */
  uint32_t L1 = 0;
  while (g_ver[L1] == 0) L1++;
  uint32_t p1 = g_ftl.l2p[L1];
  tb_request("FLIP", p1 / 16u, p1 % 16u, (100u / 4u) * 5u + 0u, 3u);   /* 1 bit: corrected by SECDED */
  uint64_t corr0 = sfftl_stats(&g_ftl)->read_corrected;
  CHECK(vf(L1) == 0, "single-bit error corrected", L1, p1);
  CHECK(sfftl_stats(&g_ftl)->read_corrected > corr0, "correction reported", L1, 0);
  uint32_t L2 = L1 + 1;
  while (g_ver[L2] == 0) L2++;
  uint32_t p2 = g_ftl.l2p[L2];
  tb_request("FLIP", p2 / 16u, p2 % 16u, (200u / 4u) * 5u, 1u);       /* 2 bits in one word: uncorrectable */
  tb_request("FLIP", p2 / 16u, p2 % 16u, (200u / 4u) * 5u, 2u);
  rc = sfftl_read(&g_ftl, L2, 1, g_rbuf);
  CHECK(rc == SFFTL_EIO, "uncorrectable read reported, not returned", L2, (uint32_t)-rc);
  rc = wr(L2, 1);
  CHECK(rc == SFFTL_OK, "rewrite of the lost LBA", L2, (uint32_t)-rc);
  (void)sfftl_background(&g_ftl, 1000u);
  verify_all("after read errors");
  /* ---------------------------------------------------------------- final */
  t0 = cyc();
  rc = sfftl_checkpoint(&g_ftl);
  cprintf("PERF checkpoint_cycles=%u checkpoint_pages=%u\n", cyc() - t0, g_ftl.ckpt_pages);
  CHECK(rc == SFFTL_OK, "checkpoint", (uint32_t)-rc, 0);
  memset(&g_ftl, 0xA5, sizeof(g_ftl));
  rc = do_mount();
  CHECK(rc == SFFTL_OK, "final mount", (uint32_t)-rc, 0);
  verify_all("final");
  print_stats("final");
  cprintf("PERF hal_totals ops=%u reads=%u programs=%u erases=%u corrected_bits=%u uncorrectable=%u timeouts=%u\n",
          g_hw.ops, g_hw.reads, g_hw.programs, g_hw.erases, g_hw.corrected_bits, g_hw.uncorrectable, g_hw.timeouts);
  cprintf("[fw] RESULT %s: %u checks, %u failures\n", g_fail ? "FAIL" : "PASS", g_checks, g_fail);
  boot_stage(CC_BOOT_STAGE_SHUTDOWN);
  test_finish(g_fail != 0, g_checks);
  return 0;
}
