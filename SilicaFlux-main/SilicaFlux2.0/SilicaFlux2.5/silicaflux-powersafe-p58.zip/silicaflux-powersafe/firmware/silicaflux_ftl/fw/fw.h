/* SilicaFlux FlashMap firmware -- shared declarations */
#ifndef FLASHMAP_FW_H
#define FLASHMAP_FW_H
#include <stdint.h>
#include <stddef.h>

#define FW_VERSION 0x00560100u          /* Project 56, firmware 1.0 */

void *memcpy(void *d, const void *s, size_t n);
void *memset(void *d, int c, size_t n);
int   memcmp(const void *a, const void *b, size_t n);
void cprintf(const char *fmt, ...);
void con_putc(char c);
void test_finish(int fail, uint32_t code);
void tb_request(const char *what, uint32_t a, uint32_t b, uint32_t c, uint32_t d);

#endif
