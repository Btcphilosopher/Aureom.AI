/* =============================================================================
 * SilicaFlux FlashMap -- wear-levelling engine
 *
 * Erase counts (EC) are kept per block in RAM, persisted in every checkpoint
 * and journalled (SFFTL_J_ERASE) between checkpoints.
 *
 * Dynamic WL (SFFTL_WL_DYNAMIC*): every block allocation takes the FREE block
 * with the lowest EC (ties: lowest index -> deterministic).  Only blocks that
 * cycle through the free pool are levelled.
 *
 * Static WL (SFFTL_WL_DYNAMIC_STATIC): every wl_static_interval erases, if the
 * spread  max EC - min EC(closed data block)  exceeds wl_static_threshold,
 * the lowest-EC closed block (cold data parked on a young block) is relocated
 * into the COLD stream, whose blocks are taken from the HIGHEST-EC free
 * blocks.  The young block returns to the free pool and dynamic WL uses it.
 *
 * Baseline (SFFTL_WL_NONE): lowest free block index first.  Used only to
 * measure what the policies buy (reports/wear.md).  No endurance or lifetime
 * figure is derived from these counts: the wear model is uncalibrated.
 * ===========================================================================*/
#include "sfftl_internal.h"

uint32_t wear_pick_free(sfftl_t *f, uint32_t stream) {
  uint32_t best = SFFTL_NONE;
  for (uint32_t b = 0; b < f->g.blocks; b++) {
    const sfftl_blk_t *bk = &f->blk[b];
    if (bk->state != SFFTL_BS_FREE) continue;
    if (f->cfg.wl_policy == SFFTL_WL_NONE) return b;
    if (best == SFFTL_NONE) { best = b; continue; }
    if (stream == ST_COLD) {
      if (bk->ec > f->blk[best].ec) best = b;           /* cold data -> most worn free block */
    } else {
      if (bk->ec < f->blk[best].ec) best = b;           /* everything else -> least worn     */
    }
  }
  return best;
}

uint32_t wear_static_victim(sfftl_t *f) {
  if (f->cfg.wl_policy != SFFTL_WL_DYNAMIC_STATIC) return SFFTL_NONE;
  if (f->erases_since_wl < f->cfg.wl_static_interval) return SFFTL_NONE;
  f->erases_since_wl = 0;
  uint32_t vmin = SFFTL_NONE, ecmax = 0;
  for (uint32_t b = 0; b < f->g.blocks; b++) {
    const sfftl_blk_t *bk = &f->blk[b];
    if (bk->state == SFFTL_BS_BAD || bk->state == SFFTL_BS_META) continue;
    if (bk->ec > ecmax) ecmax = bk->ec;
    if (bk->state == SFFTL_BS_CLOSED && bk->valid > 0 && !(bk->flags & SFFTL_BF_RETIRE)) {
      if (vmin == SFFTL_NONE || bk->ec < f->blk[vmin].ec) vmin = b;
    }
  }
  if (vmin == SFFTL_NONE) return SFFTL_NONE;
  if (ecmax - f->blk[vmin].ec <= f->cfg.wl_static_threshold) return SFFTL_NONE;
  /* moving it only helps if a more worn free block can take the cold data */
  uint32_t dst = wear_pick_free(f, ST_COLD);
  if (f->stream_blk[ST_COLD] == SFFTL_NONE && (dst == SFFTL_NONE || f->blk[dst].ec <= f->blk[vmin].ec))
    return SFFTL_NONE;
  return vmin;
}
