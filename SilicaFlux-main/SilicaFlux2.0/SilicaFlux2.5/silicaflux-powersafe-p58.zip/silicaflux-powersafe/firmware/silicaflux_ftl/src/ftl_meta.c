/* =============================================================================
 * SilicaFlux FlashMap -- metadata log: journal, checkpoints, generation counter
 *
 * The metadata zone is a ring of `meta_blocks` blocks (the first good blocks
 * of the device by factory marker, so mount can find it without metadata).
 * Pages are appended in ring order: checkpoint bodies, checkpoint commits and
 * journal pages, each carrying the global SEQ in its spare record.
 *
 * Live region: from the block holding the first body page of the newest
 * committed checkpoint to the head block.  Blocks outside it are free for the
 * ring to erase and reuse.  Invariants:
 *   - the ring never erases a live block (meta_advance stops at live_start);
 *   - between API calls the head has an erased page ready (PowerSafe: the
 *     final journal page never needs an erase);
 *   - a checkpoint is forced while at least ceil(ckpt_pages / ppb) whole free
 *     ring blocks remain, so a checkpoint always fits -- also the one that
 *     mount writes into a fresh block after an unclean shutdown.
 * A checkpoint becomes valid only when its commit page (written last, with the
 * body CRC and the list of body page runs) is programmed: an interrupted
 * checkpoint leaves the previous one in force.
 * ===========================================================================*/
#include "sfftl_internal.h"

uint32_t meta_ring_next(const sfftl_t *f, uint32_t zi) {
  for (uint32_t i = 1; i <= f->meta_blocks; i++) {
    uint32_t z = (zi + i) % f->meta_blocks;
    if (f->blk[f->zone[z]].state != SFFTL_BS_BAD) return z;
  }
  return SFFTL_NONE;
}

uint32_t meta_room_blocks(const sfftl_t *f) {
  uint32_t n = 0;
  for (uint32_t i = 1; i < f->meta_blocks; i++) {
    uint32_t z = (f->mz_head + i) % f->meta_blocks;
    if (z == f->mz_live_start) break;
    if (f->blk[f->zone[z]].state != SFFTL_BS_BAD) n++;
  }
  return n;
}

static uint32_t zone_index(const sfftl_t *f, uint32_t pbn) {
  for (uint32_t i = 0; i < f->meta_blocks; i++) if (f->zone[i] == pbn) return i;
  return SFFTL_NONE;
}

/* a metadata block failed: never reuse it; move the live region away soon */
static void meta_block_bad(sfftl_t *f, uint32_t zi, uint32_t reason) {
  uint32_t b = f->zone[zi];
  f->blk[b].state = SFFTL_BS_BAD;
  f->blk[b].flags |= SFFTL_BF_GROWN;
  f->st.blocks_retired++;
  f->ckpt_pending = 1;
  (void)journal_add(f, SFFTL_J_RETIRE, b, reason);
}

static int meta_advance(sfftl_t *f) {
  for (;;) {
    uint32_t z = SFFTL_NONE;
    for (uint32_t i = 1; i < f->meta_blocks; i++) {
      uint32_t c = (f->mz_head + i) % f->meta_blocks;
      if (c == f->mz_live_start) break;                         /* never into the live region */
      if (f->blk[f->zone[c]].state != SFFTL_BS_BAD) { z = c; break; }
    }
    if (z == SFFTL_NONE) { f->read_only = 1; return SFFTL_EROFS; }
    int st = nand_erase(f, f->zone[z]);
    if (st == SFFTL_HAL_OK) {
      f->blk[f->zone[z]].flags &= (uint8_t)~SFFTL_BF_ERASED;
      f->mz_head = z;
      f->mz_wp = 0;
      return SFFTL_OK;
    }
    if (st != SFFTL_HAL_ERASE_FAIL) return hal_rc(st);
    f->st.erase_fail++;
    meta_block_bad(f, z, SFFTL_RETIRE_ERASE);
  }
}

int meta_ensure_head(sfftl_t *f) {
  if (f->mz_wp >= f->g.pages_per_block || f->blk[f->zone[f->mz_head]].state == SFFTL_BS_BAD) return meta_advance(f);
  return SFFTL_OK;
}

int meta_append(sfftl_t *f, uint32_t kind, uint32_t index, uint32_t gen, uint8_t *page) {
  uint8_t spare[SFFTL_OOB_BYTES];
  int rc = SFFTL_EROFS;
  le32_put(page + 0, SFFTL_META_MAGIC);
  page[4] = (uint8_t)kind; page[5] = (uint8_t)(kind >> 8);
  page[6] = (uint8_t)SFFTL_SCHEMA_VERSION; page[7] = (uint8_t)(SFFTL_SCHEMA_VERSION >> 8);
  le32_put(page + 8, gen);
  le32_put(page + 12, index);
  f->in_meta++;
  if (kind == SFFTL_MK_JOURNAL) EVT(f, SFFTL_EV_PRE_JOURNAL, index);
  for (uint32_t attempt = 0; attempt < f->meta_blocks + 2u; attempt++) {
    rc = meta_ensure_head(f);
    if (rc < 0) break;
    uint32_t b = f->zone[f->mz_head];
    uint32_t ppn = mk_ppn(f, b, f->mz_wp);
    oob_build(f, spare, SFFTL_OOB_TYPE_META, (kind << 24) | (index & 0xFFFFFFu), f->next_seq++, page);
    f->mz_wp++;
    f->blk[b].wp = (uint16_t)f->mz_wp;
    if (kind == SFFTL_MK_JOURNAL) EVT(f, SFFTL_EV_IN_JOURNAL, index);
    else if (kind == SFFTL_MK_COMMIT) EVT(f, SFFTL_EV_CKPT_IN_COMMIT, gen);
    int st = nand_program(f, ppn, page, spare, PG_META);
    if (st == SFFTL_HAL_OK) { f->meta_last_ppn = ppn; rc = SFFTL_OK; break; }
    if (st == SFFTL_HAL_WRITE_PROTECT) {          /* P58: refused, nothing programmed: no gap in the ring */
      f->mz_wp--;
      f->blk[b].wp = (uint16_t)f->mz_wp;
      rc = SFFTL_EPOWER;
      break;
    }
    if (st != SFFTL_HAL_PROGRAM_FAIL) { rc = hal_rc(st); break; }
    f->st.prog_fail++;
    meta_block_bad(f, f->mz_head, SFFTL_RETIRE_PROGRAM);
    rc = SFFTL_EROFS;
  }
  f->in_meta--;
  return rc;
}

/* ---------------------------------------------------------------- journal */
int journal_add(sfftl_t *f, uint32_t type, uint32_t a, uint32_t b) {
  if (!f->mounted) return SFFTL_OK;                 /* format / early mount: the next checkpoint covers it */
  if (f->jn >= f->jcap) return SFFTL_ECORRUPT;
  uint32_t *r = &f->jrec[f->jn * SFFTL_J_REC_WORDS];
  r[0] = type; r[1] = a; r[2] = b;
  f->jn++;
  f->st.journal_records++;
  if (f->jn >= SFFTL_REC_PER_PAGE(f) && !f->in_meta && !f->in_ckpt) return journal_flush(f);
  return SFFTL_OK;
}

int journal_flush(sfftl_t *f) {
  if (f->in_meta || !f->mounted) return SFFTL_OK;
  const uint32_t rpp = SFFTL_REC_PER_PAGE(f);
  while (f->jn > 0) {
    uint32_t n = f->jn < rpp ? f->jn : rpp;
    uint8_t *page = f->buf_meta;
    memset(page, 0, f->g.page_data_bytes);
    le32_put(page + SFFTL_META_HDR_BYTES, n);
    for (uint32_t i = 0; i < n * SFFTL_J_REC_WORDS; i++) le32_put(page + SFFTL_META_HDR_BYTES + 4u + 4u * i, f->jrec[i]);
    int rc = meta_append(f, SFFTL_MK_JOURNAL, f->jpage_counter, f->gen, page);
    if (rc < 0) return rc;
    /* P58: second copy (replay is idempotent: TRIM compares SEQs, ERASE takes the
     * maximum, RETIRE / PRETIRE / PFAIL / RECOVERY are set-once).  Not during a
     * power-fail flush, whose budget is one page. */
    if ((f->cfg.flags & SFFTL_F_JOURNAL_MIRROR) && !f->ps_warned) {
      rc = meta_append(f, SFFTL_MK_JOURNAL, f->jpage_counter, f->gen, page);
      if (rc < 0) return rc;
      f->st.journal_mirror_pages++;
    }
    f->jpage_counter++;
    f->st.journal_pages++;
    /* records added while the page was being written stay queued */
    uint32_t rest = (f->jn - n) * SFFTL_J_REC_WORDS;
    for (uint32_t i = 0; i < rest; i++) f->jrec[i] = f->jrec[n * SFFTL_J_REC_WORDS + i];
    f->jn -= n;
  }
  if (meta_ensure_head(f) < 0) f->ckpt_pending = 1;
  return SFFTL_OK;
}

int mark_dirty(sfftl_t *f) {
  if (!f->clean_on_media) return SFFTL_OK;
  int rc = journal_add(f, SFFTL_J_MOUNT, (uint32_t)f->life_mounts, 0);
  if (rc < 0) return rc;
  rc = journal_flush(f);
  if (rc < 0) return rc;
  f->clean_on_media = 0;
  return SFFTL_OK;
}

/* ---------------------------------------------------------------- checkpoint */
static uint32_t body_word(const sfftl_t *f, uint32_t k) {
  if (k < f->nlpn) return f->l2p[k];
  uint32_t j = k - f->nlpn, b = j >> 1;
  const sfftl_blk_t *bk = &f->blk[b];
  if (!(j & 1u)) return bk->ec;
  return (uint32_t)bk->state | ((uint32_t)bk->flags << 8) | ((uint32_t)bk->wp << 16);
}

int ckpt_write(sfftl_t *f, int clean) {
  const uint32_t ppb = f->g.pages_per_block, bwpp = f->body_words_pp;
  if (f->in_ckpt) return SFFTL_OK;
  uint32_t head_left = (f->blk[f->zone[f->mz_head]].state == SFFTL_BS_BAD) ? 0u : ppb - f->mz_wp;
  if (head_left + meta_room_blocks(f) * ppb < f->ckpt_pages) { f->read_only = 1; return SFFTL_EROFS; }
  f->in_ckpt = 1;
  const uint32_t gen = f->gen + 1u;
  const uint64_t ckpt_seq = f->next_seq - 1u;
  const uint32_t jn_mark = f->jn, W = f->body_words;
  uint32_t runs[2u * SFFTL_CK_MAX_RUNS], nruns = 0, idx = 0, crc = SFFTL_CRC_INIT;
  uint8_t *page = f->buf_meta;
  int rc = SFFTL_OK;
  for (uint32_t k = 0; k < W && rc == SFFTL_OK;) {
    /* P58: a power-fail warning stops a checkpoint at the next page boundary (the
     * previous checkpoint stays in force); its pages would only spend hold-up time */
    if (ps_blocked(f)) { rc = SFFTL_EPOWER; break; }
    uint32_t n = (W - k < bwpp) ? W - k : bwpp;
    memset(page, 0, f->g.page_data_bytes);
    for (uint32_t i = 0; i < n; i++) le32_put(page + SFFTL_META_HDR_BYTES + 4u * i, body_word(f, k + i));
    crc = sfftl_crc32_update(crc, page + SFFTL_META_HDR_BYTES, 4u * n);
    rc = meta_append(f, SFFTL_MK_BODY, idx, gen, page);
    if (rc < 0) break;
    EVT(f, SFFTL_EV_CKPT_BODY, idx);
    uint32_t p = f->meta_last_ppn;
    if (nruns && runs[2 * (nruns - 1)] + runs[2 * (nruns - 1) + 1] == p) runs[2 * (nruns - 1) + 1]++;
    else if (nruns < SFFTL_CK_MAX_RUNS) { runs[2 * nruns] = p; runs[2 * nruns + 1] = 1; nruns++; }
    else { rc = SFFTL_EROFS; break; }
    idx++;
    k += n;
  }
  if (rc == SFFTL_OK && ps_blocked(f)) rc = SFFTL_EPOWER;
  if (rc == SFFTL_OK) {
    uint8_t *w = page + SFFTL_META_HDR_BYTES;
    memset(page, 0, f->g.page_data_bytes);
    le32_put(w + 4 * SFFTL_CK_W_CKPT_SEQ, (uint32_t)ckpt_seq);
    le32_put(w + 4 * (SFFTL_CK_W_CKPT_SEQ + 1), (uint32_t)(ckpt_seq >> 32));
    le32_put(w + 4 * SFFTL_CK_W_NEXT_SEQ, (uint32_t)(f->next_seq + 1u));
    le32_put(w + 4 * (SFFTL_CK_W_NEXT_SEQ + 1), (uint32_t)((f->next_seq + 1u) >> 32));
    le32_put(w + 4 * SFFTL_CK_W_PAGE_DATA, f->g.page_data_bytes);
    le32_put(w + 4 * SFFTL_CK_W_PAGE_SPARE, f->g.page_spare_bytes);
    le32_put(w + 4 * SFFTL_CK_W_PPB, ppb);
    le32_put(w + 4 * SFFTL_CK_W_BLOCKS, f->g.blocks);
    le32_put(w + 4 * SFFTL_CK_W_LBA_BYTES, f->cfg.lba_bytes);
    le32_put(w + 4 * SFFTL_CK_W_NLBA, (uint32_t)f->nlba);
    le32_put(w + 4 * (SFFTL_CK_W_NLBA + 1), (uint32_t)(f->nlba >> 32));
    le32_put(w + 4 * SFFTL_CK_W_NLPN, f->nlpn);
    le32_put(w + 4 * SFFTL_CK_W_META_BLOCKS, f->meta_blocks);
    le32_put(w + 4 * SFFTL_CK_W_FLAGS, clean ? SFFTL_CKF_CLEAN : 0u);
    le32_put(w + 4 * SFFTL_CK_W_BODY_PAGES, idx);
    le32_put(w + 4 * SFFTL_CK_W_BODY_CRC, SFFTL_CRC_FINAL(crc));
    le32_put(w + 4 * SFFTL_CK_W_NRUNS, nruns);
    for (uint32_t i = 0; i < 2u * nruns; i++) le32_put(w + 4 * (SFFTL_CK_W_RUNS + i), runs[i]);
    uint64_t life[4] = { f->life_host_lba, f->life_prog + 1u, f->life_erase, f->life_mounts };
    for (uint32_t i = 0; i < 4; i++) {
      le32_put(w + 4 * (SFFTL_CK_W_LIFE + 2 * i), (uint32_t)life[i]);
      le32_put(w + 4 * (SFFTL_CK_W_LIFE + 2 * i + 1), (uint32_t)(life[i] >> 32));
    }
    /* P58 extension: previous checkpoint + persistent diagnostics */
    le32_put(w + 4 * SFFTL_CK_X_MAGIC, SFFTL_CK_X_MAGIC_VAL);
    le32_put(w + 4 * SFFTL_CK_X_PREV_FIRST, f->ckpt_first_ppn);
    le32_put(w + 4 * SFFTL_CK_X_PREV_GEN, f->gen);
    le32_put(w + 4 * SFFTL_CK_X_UNCLEAN, f->diag.unclean_mounts);
    le32_put(w + 4 * SFFTL_CK_X_PF_COUNT, f->diag.pfail_count);
    le32_put(w + 4 * SFFTL_CK_X_PF_INFO, f->diag.last_pfail_info);
    le32_put(w + 4 * SFFTL_CK_X_RC_COUNT, f->diag.recov_count);
    le32_put(w + 4 * SFFTL_CK_X_RC_INFO, f->diag.last_recov_info);
    EVT(f, SFFTL_EV_CKPT_PRE_COMMIT, gen);
    rc = meta_append(f, SFFTL_MK_COMMIT, 0, gen, page);
  }
  if (rc == SFFTL_OK) {
    EVT(f, SFFTL_EV_CKPT_POST_COMMIT, gen);
    /* live region: from this checkpoint's first body page -- or, with
     * DUAL_CKPT, from the previous checkpoint's, which then stays loadable */
    if ((f->cfg.flags & SFFTL_F_DUAL_CKPT) && f->ckpt_first_ppn != SFFTL_NONE)
      f->mz_live_start = zone_index(f, ppn_blk(f, f->ckpt_first_ppn));
    else
      f->mz_live_start = zone_index(f, ppn_blk(f, runs[0]));
    f->prev_first_ppn = f->ckpt_first_ppn;
    f->prev_gen = f->gen;
    f->ckpt_first_ppn = runs[0];
    f->gen = gen;
    /* journal records queued before the snapshot are inside the checkpoint */
    uint32_t keep = f->jn - jn_mark;
    for (uint32_t i = 0; i < keep * SFFTL_J_REC_WORDS; i++) f->jrec[i] = f->jrec[jn_mark * SFFTL_J_REC_WORDS + i];
    f->jn = keep;
    f->clean_on_media = clean;
    f->opened_since_ckpt = 0;
    f->ckpt_pending = 0;
    f->st.ckpt_count++;
    f->st.ckpt_pages += idx + 1u;
  }
  f->in_ckpt = 0;
  /* keep an erased page ready -- except after a clean shutdown commit, after
   * which nothing may touch the medium */
  if (rc == SFFTL_OK && !clean && meta_ensure_head(f) < 0) f->ckpt_pending = 1;
  return rc;
}

int maybe_checkpoint(sfftl_t *f) {
  if (!f->mounted || f->read_only || ps_blocked(f) || f->in_ckpt) return SFFTL_OK;
  const uint32_t ppb = f->g.pages_per_block;
  const uint32_t need = (f->ckpt_pages + ppb - 1u) / ppb;
  if (f->ckpt_pending || f->opened_since_ckpt >= f->ckpt_interval || meta_room_blocks(f) <= need)
    return ckpt_write(f, 0);
  return SFFTL_OK;
}
