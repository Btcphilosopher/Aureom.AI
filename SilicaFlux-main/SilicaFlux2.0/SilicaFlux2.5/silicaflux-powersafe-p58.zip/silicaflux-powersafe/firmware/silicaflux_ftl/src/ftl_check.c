/* =============================================================================
 * SilicaFlux FlashMap -- invariant checker, space accounting, reporting
 * ===========================================================================*/
#include "sfftl_internal.h"

uint64_t sfftl_capacity_lba(const sfftl_t *f) { return f ? f->nlba : 0u; }
const sfftl_stats_t *sfftl_stats(const sfftl_t *f) { return &f->st; }

const char *sfftl_strerror(int rc) {
  switch (rc) {
    case SFFTL_OK:       return "ok";
    case SFFTL_EINVAL:   return "invalid argument";
    case SFFTL_ERANGE:   return "LBA out of range";
    case SFFTL_EIO:      return "unreadable data";
    case SFFTL_ENOSPC:   return "no physical space";
    case SFFTL_EROFS:    return "read-only (degraded)";
    case SFFTL_EPOWER:   return "power loss / power-fail in progress";
    case SFFTL_ENOFS:    return "no valid FTL metadata";
    case SFFTL_ECORRUPT: return "metadata inconsistent";
    case SFFTL_ENOMEM:   return "arena too small";
    case SFFTL_EGEOM:    return "geometry / configuration mismatch";
    case SFFTL_ESTATE:   return "not mounted";
    default:             return "?";
  }
}

void sfftl_space(const sfftl_t *f, sfftl_space_t *s) {
  const uint32_t ppb = f->g.pages_per_block;
  memset(s, 0, sizeof(*s));
  s->blocks_total = f->g.blocks;
  s->nlba = f->nlba;
  s->nlpn = f->nlpn;
  s->blocks_reserved_gc = f->cfg.gc_reserve_blocks;
  s->read_only = (uint32_t)f->read_only;
  s->ec_min = 0xFFFFFFFFu;
  for (uint32_t b = 0; b < f->g.blocks; b++) {
    const sfftl_blk_t *bk = &f->blk[b];
    switch (bk->state) {
      case SFFTL_BS_META:   s->blocks_meta++; break;
      case SFFTL_BS_BAD:
        if (bk->flags & SFFTL_BF_FACTORY) s->blocks_bad_factory++; else s->blocks_bad_grown++;
        break;
      case SFFTL_BS_FREE:
        s->blocks_free++;
        if (bk->flags & SFFTL_BF_ERASED) s->blocks_free_erased++;
        s->pages_writable += ppb;
        break;
      case SFFTL_BS_OPEN:
        s->blocks_open++;
        s->pages_writable += ppb - bk->wp;
        s->pages_invalid += bk->wp - bk->valid;
        break;
      default:
        s->blocks_closed++;
        s->pages_invalid += ppb - bk->valid;          /* includes abandoned erased tail pages */
        break;
    }
    s->pages_valid += bk->valid;
    if (bk->state != SFFTL_BS_BAD) {
      if (bk->ec < s->ec_min) s->ec_min = bk->ec;
      if (bk->ec > s->ec_max) s->ec_max = bk->ec;
      s->ec_sum += bk->ec;
      s->ec_blocks++;
    }
  }
  if (!s->ec_blocks) s->ec_min = 0;
}

/* Recompute everything derivable and compare with the incremental state.
 * Used by the tests after every operation batch and by the firmware self-test. */
int sfftl_check(sfftl_t *f) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  const uint32_t ppb = f->g.pages_per_block;
  uint32_t mapped = 0, free_cnt = 0;
  /* every mapping points at a valid page of a data-bearing block */
  for (uint32_t l = 0; l < f->nlpn; l++) {
    uint32_t p = f->l2p[l];
    if (p == SFFTL_NONE) continue;
    if (p >= f->total_pages || !vbm_get(f, p)) return SFFTL_ECORRUPT;
    const sfftl_blk_t *bk = &f->blk[ppn_blk(f, p)];
    if (bk->state == SFFTL_BS_FREE || bk->state == SFFTL_BS_META) return SFFTL_ECORRUPT;
    if (bk->flags & SFFTL_BF_FACTORY) return SFFTL_ECORRUPT;
    if (ppn_pg(f, p) >= bk->wp) return SFFTL_ECORRUPT;
    mapped++;
  }
  /* per block: valid count == popcount of its VBM bits; states consistent */
  uint64_t vsum = 0;
  for (uint32_t b = 0; b < f->g.blocks; b++) {
    const sfftl_blk_t *bk = &f->blk[b];
    uint32_t n = 0;
    for (uint32_t p = 0; p < ppb; p++) n += (uint32_t)vbm_get(f, mk_ppn(f, b, p));
    if (n != bk->valid) return SFFTL_ECORRUPT;
    vsum += n;
    if (bk->state == SFFTL_BS_FREE) {
      free_cnt++;
      if (bk->valid) return SFFTL_ECORRUPT;
    }
    if ((bk->state == SFFTL_BS_META) && bk->valid) return SFFTL_ECORRUPT;
    if (bk->state == SFFTL_BS_OPEN) {
      int owned = 0;
      for (uint32_t s = 0; s < SFFTL_NSTREAMS; s++) owned |= f->stream_blk[s] == b;
      if (!owned) return SFFTL_ECORRUPT;
    }
    if (bk->wp > ppb) return SFFTL_ECORRUPT;
  }
  if (vsum != mapped || free_cnt != f->free_blocks) return SFFTL_ECORRUPT;
  for (uint32_t s = 0; s < SFFTL_NSTREAMS; s++) {
    uint32_t b = f->stream_blk[s];
    if (b != SFFTL_NONE && (b >= f->g.blocks || f->blk[b].state != SFFTL_BS_OPEN)) return SFFTL_ECORRUPT;
  }
  return SFFTL_OK;
}
