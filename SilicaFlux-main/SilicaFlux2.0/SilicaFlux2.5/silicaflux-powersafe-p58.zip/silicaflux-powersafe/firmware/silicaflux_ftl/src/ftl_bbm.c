/* =============================================================================
 * SilicaFlux FlashMap -- bad-block manager
 *
 * Factory bad blocks: identified ONCE, by format, from the manufacturer marker
 * (spare byte 0 of the first and last page != 0xFF), BEFORE any erase.  They
 * are never programmed or erased, so the markers stay intact for the life of
 * the device.  The decision uses a majority rule (>= 4 zero bits) so a single
 * read-disturb bit flip cannot turn a good block bad.  The FTL itself always
 * writes 0xFF in that byte.  Block 0 is guaranteed good by ONFI / NANDLab.
 *
 * Grown bad blocks (persisted in the checkpoint block table and journalled):
 *   program failure : the page is abandoned, the write retried elsewhere; the
 *                     block is closed and flagged RETIRE: GC relocates its
 *                     valid pages with priority, then retires it (PRETIRE
 *                     record makes the flag durable).
 *   erase failure   : the block holds no valid data -> retired at once.
 *   read failure    : (uncorrectable after retries) the block is flagged
 *                     RETIRE; GC moves what is readable; pages it cannot read
 *                     stay mapped to the retired block ("stranded") so reads of
 *                     those LBAs keep returning SFFTL_EIO instead of stale or
 *                     zero data, until the host rewrites or trims them.
 * Retired blocks are replaced simply by drawing from the free pool; capacity
 * is protected by over-provisioning, and when it runs out writes return
 * SFFTL_ENOSPC while reads keep working.
 * ===========================================================================*/
#include "sfftl_internal.h"

static uint32_t zero_bits(uint8_t v) {
  uint32_t n = 0;
  for (int i = 0; i < 8; i++) n += ((v >> i) & 1u) ? 0u : 1u;
  return n;
}

int bbm_is_factory_bad(sfftl_t *f, uint32_t pbn, int *bad) {
  uint32_t pages[2] = { 0u, f->g.pages_per_block - 1u };
  *bad = 0;
  for (int i = 0; i < 2; i++) {
    uint8_t m = 0xFFu;
    int st = f->hal.read_marker(f->hal.ctx, mk_ppn(f, pbn, pages[i]), &m);
    if (hal_dead(st)) return SFFTL_EPOWER;
    if (st != SFFTL_HAL_OK) { *bad = 1; return SFFTL_OK; }   /* unreadable marker: do not trust the block */
    if (zero_bits(m) >= 4u) *bad = 1;
  }
  return SFFTL_OK;
}

int bbm_retire(sfftl_t *f, uint32_t b, uint32_t reason) {
  sfftl_blk_t *bk = &f->blk[b];
  if (bk->state == SFFTL_BS_BAD) return SFFTL_OK;
  for (uint32_t s = 0; s < SFFTL_NSTREAMS; s++) if (f->stream_blk[s] == b) f->stream_blk[s] = SFFTL_NONE;
  if (bk->state == SFFTL_BS_FREE) f->free_blocks--;
  bk->state = SFFTL_BS_BAD;
  bk->flags = (uint8_t)((bk->flags & SFFTL_BF_FACTORY) | SFFTL_BF_GROWN);
  bk->stream = 0xFFu;
  if (bk->valid) f->st.pages_stranded += bk->valid;
  f->st.blocks_retired++;
  int rc = journal_add(f, SFFTL_J_RETIRE, b, reason);
  if (rc < 0) return rc;
  return journal_flush(f);
}

int bbm_program_failed(sfftl_t *f, uint32_t b) {
  sfftl_blk_t *bk = &f->blk[b];
  f->st.prog_fail++;
  for (uint32_t s = 0; s < SFFTL_NSTREAMS; s++) if (f->stream_blk[s] == b) f->stream_blk[s] = SFFTL_NONE;
  bk->flags |= SFFTL_BF_RETIRE;
  bk->state = SFFTL_BS_CLOSED;
  bk->stream = 0xFFu;
  bk->close_seq = (uint32_t)f->next_seq;
  if (bk->valid == 0) return bbm_retire(f, b, SFFTL_RETIRE_PROGRAM);
  int rc = journal_add(f, SFFTL_J_PRETIRE, b, 0);
  if (rc < 0) return rc;
  return journal_flush(f);
}

int bbm_erase_failed(sfftl_t *f, uint32_t b) {
  f->st.erase_fail++;
  return bbm_retire(f, b, SFFTL_RETIRE_ERASE);
}

void bbm_read_failed(sfftl_t *f, uint32_t b) {
  sfftl_blk_t *bk = &f->blk[b];
  if (bk->state == SFFTL_BS_CLOSED || bk->state == SFFTL_BS_OPEN) bk->flags |= SFFTL_BF_RETIRE;
}
