/* =============================================================================
 * SilicaFlux FlashMap -- host I/O path and PowerSafe hooks
 *
 * Out-of-place write of one logical page (docs/03_WRITE_PATH.md):
 *   1. allocate a new physical page (stream HOST; may open a block, which may
 *      run foreground GC and erase the chosen free block)
 *   2. program data + spare record {LPN, SEQ, CRC}
 *   3. confirm the program status (failure: retire block, retry elsewhere)
 *   4. commit the mapping L2P[LPN] = new page
 *   5. retire the previous page (VBM clear, valid count -1)
 * The previous copy is never touched before step 4, so a failure or power
 * loss at any point leaves either the old or the new data readable.
 * ===========================================================================*/
#include "sfftl_internal.h"

int ps_blocked(const sfftl_t *f) { return f->ps_state != SFFTL_PS_RUNNING || f->ps_warned; }

static int enter_mut(sfftl_t *f) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  if (ps_blocked(f)) return SFFTL_EPOWER;
  if (f->read_only) return SFFTL_EROFS;
  return mark_dirty(f);
}

static int range_ok(const sfftl_t *f, uint64_t lba, uint32_t nlb) {
  return lba < f->nlba && (uint64_t)nlb <= f->nlba - lba;
}

/* read one logical page into dst, verifying the spare record */
static int read_lpage(sfftl_t *f, uint32_t lpn, uint8_t *dst, int check_crc) {
  uint8_t spare[SFFTL_OOB_BYTES];
  oob_t o;
  uint32_t ppn = f->l2p[lpn];
  /* the spare record must name this LPN (misdirected read) and match the CRC
   * (miscorrection); a mismatch is re-read before it is reported */
  for (uint32_t a = 0;; a++) {
    int st = nand_read(f, ppn, dst, spare, RD_HOST);
    if (st == SFFTL_HAL_UNCORRECTABLE) { bbm_read_failed(f, ppn_blk(f, ppn)); return SFFTL_EIO; }
    if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) return hal_rc(st);
    int bad = 0;
    if (oob_parse(f, spare, check_crc ? dst : NULL, &o) != 0) { f->st.crc_errors++; bad = 1; }
    else if (o.type == SFFTL_OOB_TYPE_META || o.tag != lpn) { f->st.lpn_mismatch++; bad = 1; }
    if (!bad) return SFFTL_OK;
    if (a >= f->cfg.read_retries) return SFFTL_EIO;
  }
}

/* P58 SFFTL_F_VERIFY_WRITE: read the page back (into buf_meta, which no
 * metadata operation uses between a program and its mapping commit) and compare.
 * 1 = verified, 0 = mismatch, <0 = power loss */
static int verify_page(sfftl_t *f, uint32_t ppn, uint32_t lpn, const uint8_t *data) {
  uint8_t spare[SFFTL_OOB_BYTES];
  oob_t o;
  f->st.verify_write_reads++;
  int st = nand_read(f, ppn, f->buf_meta, spare, RD_VERIFY);
  if (hal_dead(st)) return SFFTL_EPOWER;
  if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) return 0;
  if (oob_parse(f, spare, f->buf_meta, &o) != 0 || o.tag != lpn || o.type != SFFTL_OOB_TYPE_HOST) return 0;
  return memcmp(f->buf_meta, data, f->g.page_data_bytes) == 0;
}

static int write_lpage(sfftl_t *f, uint32_t lpn, const uint8_t *data) {
  uint32_t ppn;
  for (uint32_t attempt = 0;; attempt++) {
    int rc = write_page(f, ST_HOST, SFFTL_OOB_TYPE_HOST, lpn, data, &ppn);  /* steps 1-3 */
    if (rc < 0) return rc;
    if (!(f->cfg.flags & SFFTL_F_VERIFY_WRITE)) break;
    int v = verify_page(f, ppn, lpn, data);                                /* step 3b (P58) */
    if (v < 0) {
      /* the read-back was refused (power fault) after a program that returned PASS:
       * the page IS on the medium with a valid spare record and roll-forward would
       * map it -- commit it in RAM too, so RAM and medium never disagree */
      map_commit(f, lpn, ppn);
      streams_settle(f);
      return v;
    }
    if (v == 1) break;
    f->st.verify_write_fail++;
    rc = bbm_program_failed(f, ppn_blk(f, ppn));       /* the copy does not read back: like a program failure */
    if (rc < 0) return rc;
    if (attempt + 1u >= SFFTL_PROG_ATTEMPTS) return SFFTL_EIO;
  }
  EVT(f, SFFTL_EV_PRE_MAP, lpn);
  map_commit(f, lpn, ppn);                                                  /* steps 4-5 */
  streams_settle(f);
  f->st.host_pages_written++;
  EVT(f, SFFTL_EV_POST_MAP, lpn);
  return SFFTL_OK;
}

int sfftl_read(sfftl_t *f, uint64_t lba, uint32_t nlb, void *buf) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  if (nlb == 0) return SFFTL_OK;
  if (!buf || !range_ok(f, lba, nlb)) return SFFTL_ERANGE;
  const uint32_t lb = f->cfg.lba_bytes, spp = f->spp;
  const int crc = (f->cfg.flags & SFFTL_F_VERIFY_READ_CRC) != 0;
  uint8_t *p = (uint8_t *)buf;
  f->st.host_read_cmds++;
  while (nlb) {
    uint32_t lpn = (uint32_t)(lba >> f->spp_shift), off = (uint32_t)(lba & (spp - 1u));
    uint32_t n = (nlb < spp - off) ? nlb : spp - off;
    int rc = SFFTL_OK;
    if (f->l2p[lpn] == SFFTL_NONE) {
      memset(p, 0, (size_t)n * lb);
      f->st.unmapped_reads += n;
    } else if (n == spp) {
      rc = read_lpage(f, lpn, p, crc);
    } else {
      rc = read_lpage(f, lpn, f->buf_host, crc);
      if (rc == SFFTL_OK) memcpy(p, f->buf_host + (size_t)off * lb, (size_t)n * lb);
    }
    if (rc < 0) { memset(p, 0, (size_t)n * lb); return rc; }
    f->st.host_lba_read += n;
    lba += n; nlb -= n; p += (size_t)n * lb;
  }
  return SFFTL_OK;
}

/* sectors [off, off+n) of a logical page: from src, or zeros when src == NULL */
static int write_partial(sfftl_t *f, uint32_t lpn, uint32_t off, uint32_t n, const uint8_t *src) {
  const uint32_t lb = f->cfg.lba_bytes;
  if (f->l2p[lpn] != SFFTL_NONE) {
    f->st.rmw_reads++;
    int rc = read_lpage(f, lpn, f->buf_host, 1);
    if (rc < 0) return rc;
  } else {
    if (!src) return SFFTL_OK;                        /* zeroing an unmapped page: nothing to do */
    memset(f->buf_host, 0, f->g.page_data_bytes);
  }
  if (src) memcpy(f->buf_host + (size_t)off * lb, src, (size_t)n * lb);
  else memset(f->buf_host + (size_t)off * lb, 0, (size_t)n * lb);
  return write_lpage(f, lpn, f->buf_host);
}

int sfftl_write(sfftl_t *f, uint64_t lba, uint32_t nlb, const void *buf) {
  int rc = enter_mut(f);
  if (rc < 0) return rc;
  if (nlb == 0) return SFFTL_OK;
  if (!buf || !range_ok(f, lba, nlb)) return SFFTL_ERANGE;
  const uint32_t lb = f->cfg.lba_bytes, spp = f->spp;
  const uint8_t *p = (const uint8_t *)buf;
  f->st.host_write_cmds++;
  while (nlb) {
    if (ps_blocked(f)) return SFFTL_EPOWER;
    uint32_t lpn = (uint32_t)(lba >> f->spp_shift), off = (uint32_t)(lba & (spp - 1u));
    uint32_t n = (nlb < spp - off) ? nlb : spp - off;
    rc = (n == spp) ? write_lpage(f, lpn, p) : write_partial(f, lpn, off, n, p);
    if (rc < 0) return rc;
    f->st.host_lba_written += n;
    f->life_host_lba += n;
    rc = gc_paced(f);                              /* incremental relocation, bounded per host page */
    if (rc < 0 && rc != SFFTL_ENOSPC) return rc;
    lba += n; nlb -= n; p += (size_t)n * lb;
  }
  (void)maybe_checkpoint(f);       /* the write itself is already durable: a checkpoint failure does not undo it */
  return SFFTL_OK;
}

int sfftl_trim(sfftl_t *f, uint64_t lba, uint32_t nlb) {
  int rc = enter_mut(f);
  if (rc < 0) return rc;
  if (nlb == 0) return SFFTL_OK;
  if (!range_ok(f, lba, nlb)) return SFFTL_ERANGE;
  const uint32_t spp = f->spp;
  f->st.host_trim_cmds++;
  uint64_t end = lba + nlb;
  /* head: partial logical page -> write zeros into the covered sectors */
  if (lba & (spp - 1u)) {
    uint32_t lpn = (uint32_t)(lba >> f->spp_shift), off = (uint32_t)(lba & (spp - 1u));
    uint32_t n = (end - lba < spp - off) ? (uint32_t)(end - lba) : spp - off;
    rc = write_partial(f, lpn, off, n, NULL);
    if (rc < 0) return rc;
    lba += n;
  }
  /* body: whole logical pages -> journal record (durable) then unmap */
  uint64_t first = lba >> f->spp_shift, last = end >> f->spp_shift;    /* [first, last) */
  if (last > first) {
    int any = 0;
    for (uint64_t l = first; l < last && !any; l++) any = f->l2p[l] != SFFTL_NONE;
    if (any) {
      rc = journal_add(f, SFFTL_J_TRIM, (uint32_t)first, (uint32_t)(last - first));
      if (rc < 0) return rc;
      rc = journal_flush(f);
      if (rc < 0) {
        /* P58: an aborted TRIM must not take effect LATER: if its record is still
         * queued (its page was not programmed) drop it, otherwise a flush after the
         * host rewrote these LBAs would carry a newer TRIM that unmaps acknowledged
         * data at the next mount.  If its page did reach the medium, the TRIM is
         * durable: apply it in RAM too, so RAM and medium agree (stable result). */
        int queued = 0;
        for (uint32_t i = 0; i < f->jn; i++) {
          uint32_t *r = &f->jrec[i * SFFTL_J_REC_WORDS];
          if (r[0] == SFFTL_J_TRIM && r[1] == (uint32_t)first && r[2] == (uint32_t)(last - first)) {
            for (uint32_t j = i; j + 1u < f->jn; j++)
              for (uint32_t w = 0; w < SFFTL_J_REC_WORDS; w++)
                f->jrec[j * SFFTL_J_REC_WORDS + w] = f->jrec[(j + 1u) * SFFTL_J_REC_WORDS + w];
            f->jn--;
            queued = 1;
            break;
          }
        }
        if (!queued) for (uint64_t l = first; l < last; l++) map_unmap(f, (uint32_t)l);
        return rc;
      }
      EVT(f, SFFTL_EV_TRIM_PRE_UNMAP, first);
      for (uint64_t l = first; l < last; l++) map_unmap(f, (uint32_t)l);
    }
    lba = last << f->spp_shift;
  }
  /* tail */
  if (lba < end) {
    rc = write_partial(f, (uint32_t)(lba >> f->spp_shift), 0, (uint32_t)(end - lba), NULL);
    if (rc < 0) return rc;
  }
  f->st.host_lba_trimmed += nlb;
  (void)maybe_checkpoint(f);
  return SFFTL_OK;
}

int sfftl_flush(sfftl_t *f) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  f->st.host_flush_cmds++;
  if (f->read_only) return SFFTL_OK;
  return journal_flush(f);
}

int sfftl_checkpoint(sfftl_t *f) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  if (ps_blocked(f)) return SFFTL_EPOWER;
  if (f->read_only) return SFFTL_EROFS;
  return ckpt_write(f, 0);
}

int sfftl_shutdown(sfftl_t *f) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  int rc = SFFTL_OK;
  if (!f->read_only) rc = ckpt_write(f, 1);
  f->mounted = 0;
  return rc;
}

int sfftl_background(sfftl_t *f, uint32_t budget) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  if (f->read_only || ps_blocked(f)) return 0;
  int rc = mark_dirty(f);
  if (rc < 0) return rc;
  rc = gc_background(f, budget);
  if (rc < 0) return rc;
  int c = maybe_checkpoint(f);
  if (c < 0) return c;
  return rc;
}

/* ---------------------------------------------------------------- PowerSafe */
void sfftl_ps_warn(sfftl_t *f) { f->ps_warned = 1; }

void sfftl_ps_set_diag(sfftl_t *f, uint32_t info) {
  f->diag_pending = 1;
  f->diag_info = info;
}

int sfftl_ps_power_fail(sfftl_t *f, uint32_t flags) {
  int n = 0;
  f->ps_warned = 1;
  /* P58: the power-fault record rides in the same (single) journal page */
  if (f->mounted && !f->read_only && (flags & SFFTL_PS_FLUSH_JOURNAL) && f->diag_pending) {
    f->diag_pending = 0;
    f->diag.pfail_count++;
    f->diag.last_pfail_info = f->diag_info;
    (void)journal_add(f, SFFTL_J_PFAIL, f->diag.pfail_count, f->diag_info);
  }
  if (f->mounted && !f->read_only && (flags & SFFTL_PS_FLUSH_JOURNAL) && f->jn > 0) {
    uint64_t p0 = f->st.nand_prog_meta;
    int rc = journal_flush(f);
    n = (int)(f->st.nand_prog_meta - p0);
    if (rc < 0) return rc;
  }
  f->ps_state = SFFTL_PS_SAFE;
  if (f->hal.write_protect) f->hal.write_protect(f->hal.ctx, 1);
  return n;
}

int sfftl_ps_power_restored(sfftl_t *f) {
  if (f->hal.write_protect) f->hal.write_protect(f->hal.ctx, 0);
  f->ps_state = SFFTL_PS_RUNNING;
  f->ps_warned = 0;
  return SFFTL_OK;
}

int sfftl_ps_state(const sfftl_t *f) { return f->ps_state; }

/* ---------------------------------------------------------------- P58 diagnostics */
const sfftl_diag_t *sfftl_diag(const sfftl_t *f) { return &f->diag; }

int sfftl_log_recovery(sfftl_t *f, uint32_t info) {
  if (!f || !f->mounted) return SFFTL_ESTATE;
  if (ps_blocked(f)) return SFFTL_EPOWER;
  if (f->read_only) return SFFTL_EROFS;
  int rc = mark_dirty(f);
  if (rc < 0) return rc;
  f->diag.recov_count++;
  f->diag.last_recov_info = info;
  rc = journal_add(f, SFFTL_J_RECOVERY, f->diag.recov_count, info);
  if (rc < 0) return rc;
  return journal_flush(f);
}

void sfftl_ps_worst_case_ops(const sfftl_t *f, sfftl_ps_budget_t *b) {
  /* the call in flight finishes its current page operation:
   *   host RMW page: 1 read + 1 program, or GC page: 1 read + 1 program
   *   (+1 verify read), plus at most one block erase if a block was being
   *   opened; then sfftl_ps_power_fail() programs at most one journal page.
   * Each program failure on the way adds 1 program + 1 journal program. */
  b->page_reads = 1u + ((f->cfg.flags & SFFTL_F_VERIFY_GC_COPY) ? 1u : 0u);
  b->page_programs = 1u + 1u;
  b->block_erases = 1u;
}
