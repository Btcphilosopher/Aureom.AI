/* =============================================================================
 * SilicaFlux FlashMap -- free-space management and the out-of-place write
 *
 * Block life cycle:
 *   FREE --(pick: wear policy, erase if needed)--> OPEN (stream frontier)
 *   OPEN --(last page programmed / program failure)--> CLOSED
 *   CLOSED --(last valid page invalidated, or GC)--> FREE
 *   any --(erase/program failure, retirement)--> BAD
 * Three write streams keep data of different temperature apart:
 *   HOST (host writes), RELOC (GC copies), COLD (static wear-levelling copies).
 *
 * Reserve: a host block may only open while more than gc_reserve_blocks are
 * free, so relocation can always obtain a destination block.  Foreground GC
 * runs before a host block opens when free blocks <= gc_fg_free_blocks.
 * ===========================================================================*/
#include "sfftl_internal.h"

uint32_t free_reserve(const sfftl_t *f) { return f->cfg.gc_reserve_blocks; }

void block_make_free(sfftl_t *f, uint32_t b) {
  sfftl_blk_t *bk = &f->blk[b];
  bk->state = SFFTL_BS_FREE;
  bk->flags &= (uint8_t)~(SFFTL_BF_ERASED | SFFTL_BF_REFRESH | SFFTL_BF_RETIRE);
  bk->stream = 0xFFu;
  f->free_blocks++;
}

void block_close(sfftl_t *f, uint32_t b) {
  sfftl_blk_t *bk = &f->blk[b];
  bk->state = SFFTL_BS_CLOSED;
  bk->stream = 0xFFu;
  bk->close_seq = (uint32_t)f->next_seq;
  if (bk->valid == 0 && !(bk->flags & SFFTL_BF_RETIRE)) block_make_free(f, b);
}

void stream_close(sfftl_t *f, uint32_t s) {
  uint32_t b = f->stream_blk[s];
  if (b == SFFTL_NONE) return;
  f->stream_blk[s] = SFFTL_NONE;
  if (f->blk[b].state == SFFTL_BS_OPEN) block_close(f, b);
}

/* open a fresh block for a stream: foreground GC (host only), wear-policy pick,
 * erase-on-allocate when the block is not known to be erased */
static int open_block(sfftl_t *f, uint32_t s) {
  if (s == ST_HOST) {
    if (f->free_blocks <= f->cfg.gc_fg_free_blocks) {
      int rc = gc_foreground(f);
      if (rc < 0 && rc != SFFTL_ENOSPC) return rc;
    }
    if (f->free_blocks <= free_reserve(f)) return SFFTL_ENOSPC;
  }
  for (;;) {
    if (f->free_blocks == 0) return SFFTL_ENOSPC;
    uint32_t b = wear_pick_free(f, s);
    if (b == SFFTL_NONE) return SFFTL_ENOSPC;
    sfftl_blk_t *bk = &f->blk[b];
    if (!(bk->flags & SFFTL_BF_ERASED)) {
      if (ps_blocked(f)) return SFFTL_EPOWER;
      int st = nand_erase(f, b);
      if (st == SFFTL_HAL_ERASE_FAIL) {
        int rc = bbm_erase_failed(f, b);
        if (rc < 0) return rc;
        continue;
      }
      if (st != SFFTL_HAL_OK) return hal_rc(st);
    }
    bk->state = SFFTL_BS_OPEN;
    bk->stream = (uint8_t)s;
    bk->valid = 0;
    bk->wp = 0;
    bk->flags &= (uint8_t)~(SFFTL_BF_ERASED | SFFTL_BF_REFRESH | SFFTL_BF_RETIRE);
    f->free_blocks--;
    f->opened_since_ckpt++;
    f->stream_blk[s] = b;
    return SFFTL_OK;
  }
}

int alloc_page(sfftl_t *f, uint32_t s, uint32_t *ppn) {
  for (;;) {
    uint32_t b = f->stream_blk[s];
    if (b != SFFTL_NONE && f->blk[b].wp < f->g.pages_per_block) {
      *ppn = mk_ppn(f, b, f->blk[b].wp);
      return SFFTL_OK;
    }
    stream_close(f, s);
    int rc = open_block(f, s);
    if (rc < 0) return rc;
  }
}

/* Steps 1-3 of the out-of-place write: allocate a new physical page, program
 * data + spare record, confirm the program status.  Program failure retires
 * the block (its earlier pages are relocated by GC) and retries on a fresh
 * page.  The caller commits the mapping (step 4) only after SFFTL_OK. */
int write_page(sfftl_t *f, uint32_t s, uint8_t type, uint32_t tag, const uint8_t *data, uint32_t *out) {
  uint8_t spare[SFFTL_OOB_BYTES];
  for (uint32_t attempt = 0; attempt < SFFTL_PROG_ATTEMPTS; attempt++) {
    uint32_t ppn;
    int rc = alloc_page(f, s, &ppn);
    if (rc < 0) return rc;
    if (ps_blocked(f)) return SFFTL_EPOWER;
    uint32_t b = ppn_blk(f, ppn);
    oob_build(f, spare, type, tag, f->next_seq++, data);
    f->blk[b].wp++;                                     /* the page is consumed whatever the outcome */
    if (s == ST_HOST) { EVT(f, SFFTL_EV_PRE_PROGRAM, tag); EVT(f, SFFTL_EV_IN_PROGRAM, tag); }
    else EVT(f, SFFTL_EV_GC_IN_COPY, tag);
    int st = nand_program(f, ppn, data, spare, (s == ST_HOST) ? PG_HOST : PG_RELOC);
    if (st == SFFTL_HAL_OK) {
      if (s == ST_HOST) EVT(f, SFFTL_EV_POST_PROGRAM, tag);
      *out = ppn;                                       /* full block closed by streams_settle() after commit */
      return SFFTL_OK;
    }
    if (st == SFFTL_HAL_WRITE_PROTECT) {
      /* P58: refused before it started -- the page is NOT consumed (a skipped erased
       * page in an open block would end the mount scan of that block early) */
      f->blk[b].wp--;
      return SFFTL_EPOWER;
    }
    if (st != SFFTL_HAL_PROGRAM_FAIL) return hal_rc(st);
    rc = bbm_program_failed(f, b);
    if (rc < 0) return rc;
  }
  return SFFTL_EIO;
}

/* close stream blocks whose last page is programmed -- only after the mapping
 * of that page was committed (closing a block with valid == 0 frees it) */
void streams_settle(sfftl_t *f) {
  for (uint32_t s = 0; s < SFFTL_NSTREAMS; s++) {
    uint32_t b = f->stream_blk[s];
    if (b != SFFTL_NONE && f->blk[b].wp >= f->g.pages_per_block) stream_close(f, s);
  }
}
