/* =============================================================================
 * SilicaFlux FlashMap -- layout, format, mount and recovery
 *
 * Mount (docs/07_PERSISTENCE.md section 5):
 *  1. metadata zone = first meta_blocks blocks whose factory marker is good
 *  2. read every zone page; catalogue valid metadata pages (CRC, header)
 *  3. newest commit whose body is complete and whose body CRC matches
 *     -> L2P + block table (+ generation, lifetime counters); else the
 *     previous one; none -> ENOFS, or rebuild from spare records if allowed
 *  4. journal pages newer than the checkpoint, in SEQ order:
 *     ERASE / RETIRE / PRETIRE   (TRIM is applied after step 5)
 *  5. unless the checkpoint is a clean-shutdown one with nothing after it:
 *     roll forward -- every data block whose first page is newer than the
 *     checkpoint, or that was open at it, is scanned; each valid data page
 *     with SEQ > checkpoint SEQ is applied when it is newer than what the
 *     L2P holds for its LPN (SEQ comparison; reads the current page's spare
 *     record when that mapping itself came from the roll-forward)
 *  6. TRIM records applied when newer than the LPN's current mapping
 *  7. VBM / valid counts rebuilt from the L2P; open blocks closed
 *  8. metadata head: continue after a clean commit, else a fresh ring block,
 *     and an unclean mount writes a new checkpoint at once
 * ===========================================================================*/
#include "sfftl_internal.h"

#define CAT_W 5u   /* catalogue entry: seq_lo, seq_hi | kind << 16, gen, index, ppn */

static int is_pow2(uint32_t v) { return v && !(v & (v - 1u)); }
static uint32_t log2u(uint32_t v) { uint32_t r = 0; while ((1u << r) < v) r++; return r; }
static size_t al8(size_t v) { return (v + 7u) & ~(size_t)7u; }

void sfftl_cfg_default(sfftl_cfg_t *c) {
  memset(c, 0, sizeof(*c));
  c->lba_bytes = 512u;
  c->nlba = 0;
  c->op_permille = 70u;
  c->meta_blocks = 0;
  c->gc_reserve_blocks = 2u;
  c->gc_fg_free_blocks = 3u;
  c->gc_bg_free_blocks = 6u;
  c->gc_policy = SFFTL_GC_GREEDY;
  c->wl_policy = SFFTL_WL_DYNAMIC_STATIC;
  c->wl_static_threshold = 64u;
  c->wl_static_interval = 64u;
  c->ckpt_interval_blocks = 0;          /* automatic: max(8, blocks / 4) */
  c->read_retries = 2u;
  c->refresh_bitflips = 0;
  c->flags = SFFTL_F_VERIFY_READ_CRC | SFFTL_F_PACED_GC;
}

typedef struct {
  uint32_t spp, bwpp, meta_blocks, nlpn_alloc, jcap, cat_entries;
  size_t o_l2p, o_vbm, o_blk, o_zone, o_bh, o_bg, o_bm, o_jrec, o_scr, bytes;
} plan_t;

static uint32_t capacity_lpn(const sfftl_geom_t *g, const sfftl_cfg_t *c, uint32_t meta, uint32_t nbad) {
  uint32_t hold = c->gc_fg_free_blocks > c->gc_reserve_blocks ? c->gc_fg_free_blocks : c->gc_reserve_blocks;
  uint32_t overhead = meta + nbad + hold + SFFTL_NSTREAMS + 1u;
  if (g->blocks <= overhead) return 0;
  uint64_t pages = (uint64_t)(g->blocks - overhead) * g->pages_per_block;
  pages = pages * (1000u - c->op_permille) / 1000u;
  return (uint32_t)pages;
}

static int plan(const sfftl_geom_t *g, const sfftl_cfg_t *c, plan_t *p) {
  if (!g || !c) return SFFTL_EINVAL;
  if (!is_pow2(g->page_data_bytes) || g->page_data_bytes < 512u || g->page_data_bytes > 16384u) return SFFTL_EINVAL;
  if (g->page_spare_bytes < SFFTL_OOB_BYTES) return SFFTL_EINVAL;
  if (!is_pow2(g->pages_per_block) || g->pages_per_block < 4u || g->pages_per_block > 1024u) return SFFTL_EINVAL;
  if (g->blocks < 16u || g->blocks > 65535u) return SFFTL_EINVAL;
  if (!is_pow2(c->lba_bytes) || c->lba_bytes < 512u || c->lba_bytes > g->page_data_bytes) return SFFTL_EINVAL;
  if (c->op_permille == 0u || c->op_permille >= 500u) return SFFTL_EINVAL;
  if (c->gc_reserve_blocks < 2u || c->gc_fg_free_blocks <= c->gc_reserve_blocks) return SFFTL_EINVAL;
  if (c->gc_bg_free_blocks < c->gc_fg_free_blocks) return SFFTL_EINVAL;
  memset(p, 0, sizeof(*p));
  p->spp = g->page_data_bytes / c->lba_bytes;
  p->bwpp = (g->page_data_bytes - SFFTL_META_HDR_BYTES) / 4u;
  uint32_t total = g->blocks * g->pages_per_block;
  uint32_t ckpt_bound = (total + 2u * g->blocks + p->bwpp - 1u) / p->bwpp + 1u;
  uint32_t need = (ckpt_bound + g->pages_per_block - 1u) / g->pages_per_block;
  /* ring: live region (one checkpoint, two with DUAL_CKPT) + room for the next one + slack */
  uint32_t m = ((c->flags & SFFTL_F_DUAL_CKPT) ? 3u : 2u) * need + 3u;
  if (m < SFFTL_MIN_META_BLOCKS) m = SFFTL_MIN_META_BLOCKS;
  if (c->meta_blocks > m) m = c->meta_blocks;
  if (2u * m > g->blocks) return SFFTL_EINVAL;
  p->meta_blocks = m;
  uint32_t cap0 = capacity_lpn(g, c, m, 0);
  if (c->nlba) {
    uint64_t n = (c->nlba + p->spp - 1u) / p->spp;
    if (n > cap0) return SFFTL_EINVAL;
    p->nlpn_alloc = (uint32_t)n;
  } else {
    p->nlpn_alloc = cap0;
  }
  if (p->nlpn_alloc == 0) return SFFTL_EINVAL;
  uint32_t rpp = ((g->page_data_bytes - SFFTL_META_HDR_BYTES) / 4u - 1u) / SFFTL_J_REC_WORDS;
  p->jcap = 2u * rpp + 8u;
  p->cat_entries = m * g->pages_per_block;
  size_t o = 0;
  p->o_l2p = o;  o = al8(o + (size_t)p->nlpn_alloc * 4u);
  p->o_vbm = o;  o = al8(o + (size_t)((total + 31u) / 32u) * 4u);
  p->o_blk = o;  o = al8(o + (size_t)g->blocks * sizeof(sfftl_blk_t));
  p->o_zone = o; o = al8(o + (size_t)m * 4u);
  p->o_bh = o;   o = al8(o + g->page_data_bytes);
  p->o_bg = o;   o = al8(o + g->page_data_bytes);
  p->o_bm = o;   o = al8(o + g->page_data_bytes);
  p->o_jrec = o; o = al8(o + (size_t)p->jcap * SFFTL_J_REC_WORDS * 4u);
  p->o_scr = o;  o = al8(o + (size_t)p->cat_entries * CAT_W * 4u);
  p->bytes = o;
  return SFFTL_OK;
}

size_t sfftl_mem_required(const sfftl_geom_t *g, const sfftl_cfg_t *cfg) {
  plan_t p;
  return plan(g, cfg, &p) == SFFTL_OK ? p.bytes : 0u;
}

int sfftl_layout_info(const sfftl_geom_t *g, const sfftl_cfg_t *cfg, sfftl_layout_t *o) {
  plan_t p;
  int rc = plan(g, cfg, &p);
  if (rc < 0) return rc;
  memset(o, 0, sizeof(*o));
  o->meta_blocks = p.meta_blocks;
  o->nlpn_max = cfg->nlba ? capacity_lpn(g, cfg, p.meta_blocks, 0) : p.nlpn_alloc;
  o->ckpt_pages = (o->nlpn_max + 2u * g->blocks + p.bwpp - 1u) / p.bwpp + 1u;
  o->l2p_bytes = p.o_vbm - p.o_l2p;
  o->vbm_bytes = p.o_blk - p.o_vbm;
  o->blk_bytes = p.o_zone - p.o_blk;
  o->buf_bytes = p.o_jrec - p.o_bh;
  o->journal_bytes = p.o_scr - p.o_jrec;
  o->scratch_bytes = p.bytes - p.o_scr;
  o->total_bytes = p.bytes;
  return SFFTL_OK;
}

static void set_nlpn(sfftl_t *f, uint32_t nlpn, uint64_t nlba) {
  f->nlpn = nlpn;
  f->nlba = nlba;
  f->body_words = nlpn + 2u * f->g.blocks;
  f->ckpt_pages = (f->body_words + f->body_words_pp - 1u) / f->body_words_pp + 1u;
}

int layout(sfftl_t *f, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const sfftl_hal_t *hal, void *arena,
           size_t arena_bytes) {
  plan_t p;
  if (!f || !hal || !hal->read || !hal->program || !hal->erase || !hal->read_marker || !arena) return SFFTL_EINVAL;
  int rc = plan(g, cfg, &p);
  if (rc < 0) return rc;
  if (arena_bytes < p.bytes || ((uintptr_t)arena & 7u)) return SFFTL_ENOMEM;
  memset(f, 0, sizeof(*f));
  memset(arena, 0, p.bytes);
  uint8_t *a = (uint8_t *)arena;
  f->g = *g;
  f->cfg = *cfg;
  f->hal = *hal;
  f->spp = p.spp;
  f->spp_shift = log2u(p.spp);
  f->total_pages = g->blocks * g->pages_per_block;
  f->ppb_shift = log2u(g->pages_per_block);
  f->meta_blocks = p.meta_blocks;
  f->body_words_pp = p.bwpp;
  f->l2p = (uint32_t *)(void *)(a + p.o_l2p);
  f->vbm = (uint32_t *)(void *)(a + p.o_vbm);
  f->blk = (sfftl_blk_t *)(void *)(a + p.o_blk);
  f->zone = (uint32_t *)(void *)(a + p.o_zone);
  f->buf_host = a + p.o_bh;
  f->buf_gc = a + p.o_bg;
  f->buf_meta = a + p.o_bm;
  f->jrec = (uint32_t *)(void *)(a + p.o_jrec);
  f->jcap = p.jcap;
  f->scratch = (uint32_t *)(void *)(a + p.o_scr);
  f->scratch_words = p.cat_entries * CAT_W;
  set_nlpn(f, p.nlpn_alloc, (uint64_t)p.nlpn_alloc * p.spp);
  for (uint32_t s = 0; s < SFFTL_NSTREAMS; s++) f->stream_blk[s] = SFFTL_NONE;
  for (uint32_t b = 0; b < g->blocks; b++) { f->blk[b].state = SFFTL_BS_FREE; f->blk[b].stream = 0xFFu; }
  f->ckpt_interval = cfg->ckpt_interval_blocks ? cfg->ckpt_interval_blocks : (g->blocks / 4u > 8u ? g->blocks / 4u : 8u);
  f->ps_state = SFFTL_PS_RUNNING;
  f->mz_live_start = SFFTL_NONE;
  f->gc_victim = SFFTL_NONE;
  f->ckpt_first_ppn = SFFTL_NONE;
  f->prev_first_ppn = SFFTL_NONE;
  return SFFTL_OK;
}

static uint32_t zone_index(const sfftl_t *f, uint32_t pbn) {
  for (uint32_t i = 0; i < f->meta_blocks; i++) if (f->zone[i] == pbn) return i;
  return SFFTL_NONE;
}

/* ================================================================ format */
int sfftl_format(sfftl_t *f, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const sfftl_hal_t *hal, void *arena,
                 size_t arena_bytes) {
  int rc = layout(f, g, cfg, hal, arena, arena_bytes);
  if (rc < 0) return rc;
  if (hal->write_protect) hal->write_protect(hal->ctx, 0);
  const uint32_t nb = g->blocks;
  uint32_t nbad = 0, nz = 0;
  /* 1. manufacturer markers, before anything is erased */
  for (uint32_t b = 0; b < nb; b++) {
    int bad;
    rc = bbm_is_factory_bad(f, b, &bad);
    if (rc < 0) return rc;
    if (bad) { f->blk[b].state = SFFTL_BS_BAD; f->blk[b].flags = SFFTL_BF_FACTORY; nbad++; }
  }
  /* 2. metadata zone */
  for (uint32_t b = 0; b < nb && nz < f->meta_blocks; b++)
    if (f->blk[b].state != SFFTL_BS_BAD) { f->zone[nz++] = b; f->blk[b].state = SFFTL_BS_META; }
  if (nz < f->meta_blocks) return SFFTL_EINVAL;
  /* 3. capacity */
  uint32_t cap = capacity_lpn(g, cfg, f->meta_blocks, nbad);
  uint32_t nlpn = cfg->nlba ? (uint32_t)((cfg->nlba + f->spp - 1u) / f->spp) : (cap < f->nlpn ? cap : f->nlpn);
  if (nlpn == 0 || nlpn > cap) return SFFTL_EINVAL;
  set_nlpn(f, nlpn, cfg->nlba ? cfg->nlba : (uint64_t)nlpn * f->spp);
  /* 4. erase every good block (data of a previous life must not be replayed) */
  for (uint32_t b = 0; b < nb; b++) {
    if (f->blk[b].state == SFFTL_BS_BAD) continue;
    int st = nand_erase(f, b);
    if (st == SFFTL_HAL_ERASE_FAIL) {
      f->st.erase_fail++;
      f->st.blocks_retired++;
      f->blk[b].state = SFFTL_BS_BAD;
      f->blk[b].flags |= SFFTL_BF_GROWN;
      continue;
    }
    if (st != SFFTL_HAL_OK) return hal_rc(st);
    if (f->blk[b].state == SFFTL_BS_FREE) f->free_blocks++;
  }
  uint32_t good_meta = 0, first = SFFTL_NONE;
  for (uint32_t i = 0; i < f->meta_blocks; i++)
    if (f->blk[f->zone[i]].state == SFFTL_BS_META) { good_meta++; if (first == SFFTL_NONE) first = i; }
  if (good_meta < 3u) return SFFTL_EROFS;
  for (uint32_t l = 0; l < f->nlpn; l++) f->l2p[l] = SFFTL_NONE;
  f->next_seq = 1;
  f->gen = 0;
  f->mz_head = first;
  f->mz_wp = 0;
  f->mz_live_start = first;
  f->mounted = 1;
  f->life_mounts = 0;
  rc = ckpt_write(f, 1);
  if (rc < 0) { f->mounted = 0; return rc; }
  return SFFTL_OK;
}

/* ================================================================ mount */
typedef struct {
  uint64_t ckpt_seq, next_seq, commit_seq;
  uint32_t gen, flags, commit_ppn, live_start;
  uint64_t life[4];
  int rebuild;
  uint32_t first_ppn, prev_first, prev_gen;   /* P58 */
  sfftl_diag_t diag;
} ckinfo_t;

static uint32_t *cat(sfftl_t *f, uint32_t i) { return &f->scratch[i * CAT_W]; }
static uint64_t cat_seq(sfftl_t *f, uint32_t i) { uint32_t *e = cat(f, i); return (uint64_t)e[0] | ((uint64_t)(e[1] & 0xFFFFu) << 32); }
static uint32_t cat_kind(sfftl_t *f, uint32_t i) { return (cat(f, i)[1] >> 16) & 0xFFu; }
#define CAT_TRIED 0x80u

static int read_meta_page(sfftl_t *f, uint32_t ppn) {
  uint8_t spare[SFFTL_OOB_BYTES];
  oob_t o;
  int st = nand_read(f, ppn, f->buf_meta, spare, RD_MOUNT);
  if (hal_dead(st)) return SFFTL_EPOWER;
  if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) return SFFTL_EIO;
  if (oob_parse(f, spare, f->buf_meta, &o) != 0 || o.type != SFFTL_OOB_TYPE_META) return SFFTL_EIO;
  return SFFTL_OK;
}

/* returns OK, EGEOM (stop), or EIO (try an older commit) */
static int load_checkpoint(sfftl_t *f, uint32_t ci, uint32_t ncat, ckinfo_t *ck) {
  const uint32_t nb = f->g.blocks;
  int rc = read_meta_page(f, cat(f, ci)[4]);
  if (rc == SFFTL_EPOWER) return rc;
  if (rc < 0) return SFFTL_EIO;
  const uint8_t *w = f->buf_meta + SFFTL_META_HDR_BYTES;
#define CW(i) le32_get(w + 4u * (i))
  if (CW(SFFTL_CK_W_PAGE_DATA) != f->g.page_data_bytes || CW(SFFTL_CK_W_PAGE_SPARE) != f->g.page_spare_bytes ||
      CW(SFFTL_CK_W_PPB) != f->g.pages_per_block || CW(SFFTL_CK_W_BLOCKS) != nb ||
      CW(SFFTL_CK_W_LBA_BYTES) != f->cfg.lba_bytes || CW(SFFTL_CK_W_META_BLOCKS) != f->meta_blocks)
    return SFFTL_EGEOM;
  uint64_t nlba = (uint64_t)CW(SFFTL_CK_W_NLBA) | ((uint64_t)CW(SFFTL_CK_W_NLBA + 1) << 32);
  uint32_t nlpn = CW(SFFTL_CK_W_NLPN);
  if (nlpn == 0 || nlpn > f->nlpn || (f->cfg.nlba && f->cfg.nlba != nlba) || nlba > (uint64_t)nlpn * f->spp)
    return SFFTL_EGEOM;
  uint32_t gen = cat(f, ci)[2], nruns = CW(SFFTL_CK_W_NRUNS), body_pages = CW(SFFTL_CK_W_BODY_PAGES);
  uint32_t body_crc = CW(SFFTL_CK_W_BODY_CRC);
  if (nruns == 0 || nruns > SFFTL_CK_MAX_RUNS) return SFFTL_EIO;
  uint32_t runs[2u * SFFTL_CK_MAX_RUNS];
  for (uint32_t i = 0; i < 2u * nruns; i++) runs[i] = CW(SFFTL_CK_W_RUNS + i);
  ck->ckpt_seq = (uint64_t)CW(SFFTL_CK_W_CKPT_SEQ) | ((uint64_t)CW(SFFTL_CK_W_CKPT_SEQ + 1) << 32);
  ck->next_seq = (uint64_t)CW(SFFTL_CK_W_NEXT_SEQ) | ((uint64_t)CW(SFFTL_CK_W_NEXT_SEQ + 1) << 32);
  ck->flags = CW(SFFTL_CK_W_FLAGS);
  for (uint32_t i = 0; i < 4; i++)
    ck->life[i] = (uint64_t)CW(SFFTL_CK_W_LIFE + 2 * i) | ((uint64_t)CW(SFFTL_CK_W_LIFE + 2 * i + 1) << 32);
  memset(&ck->diag, 0, sizeof(ck->diag));
  ck->prev_first = SFFTL_NONE;
  ck->prev_gen = 0;
  if (CW(SFFTL_CK_X_MAGIC) == SFFTL_CK_X_MAGIC_VAL) {      /* P58 extension present */
    ck->prev_first = CW(SFFTL_CK_X_PREV_FIRST);
    ck->prev_gen = CW(SFFTL_CK_X_PREV_GEN);
    ck->diag.unclean_mounts = CW(SFFTL_CK_X_UNCLEAN);
    ck->diag.pfail_count = CW(SFFTL_CK_X_PF_COUNT);
    ck->diag.last_pfail_info = CW(SFFTL_CK_X_PF_INFO);
    ck->diag.recov_count = CW(SFFTL_CK_X_RC_COUNT);
    ck->diag.last_recov_info = CW(SFFTL_CK_X_RC_INFO);
  }
#undef CW
  set_nlpn(f, nlpn, nlba);
  const uint32_t W = f->body_words, bwpp = f->body_words_pp;
  if (body_pages != (W + bwpp - 1u) / bwpp) return SFFTL_EIO;
  uint32_t k = 0, idx = 0, crc = SFFTL_CRC_INIT;
  for (uint32_t r = 0; r < nruns; r++) {
    for (uint32_t j = 0; j < runs[2 * r + 1]; j++) {
      uint32_t ppn = runs[2 * r] + j, e = SFFTL_NONE;
      for (uint32_t i = 0; i < ncat; i++)
        if (cat(f, i)[4] == ppn) { e = i; break; }
      if (e == SFFTL_NONE || cat_kind(f, e) != SFFTL_MK_BODY || cat(f, e)[2] != gen || cat(f, e)[3] != idx || k >= W)
        return SFFTL_EIO;
      rc = read_meta_page(f, ppn);
      if (rc == SFFTL_EPOWER) return rc;
      if (rc < 0) return SFFTL_EIO;
      uint32_t n = (W - k < bwpp) ? W - k : bwpp;
      const uint8_t *pw = f->buf_meta + SFFTL_META_HDR_BYTES;
      crc = sfftl_crc32_update(crc, pw, 4u * n);
      for (uint32_t i = 0; i < n; i++, k++) {
        uint32_t v = le32_get(pw + 4u * i);
        if (k < nlpn) {
          if (v != SFFTL_NONE && v >= f->total_pages) return SFFTL_EIO;
          f->l2p[k] = v;
        } else {
          uint32_t jj = k - nlpn, b = jj >> 1;
          sfftl_blk_t *bk = &f->blk[b];
          if (!(jj & 1u)) { bk->ec = v; continue; }
          uint32_t st = SFFTL_BR_STATE(v), fl = SFFTL_BR_FLAGS(v), wp = SFFTL_BR_WP(v);
          if (st > SFFTL_BS_BAD || wp > f->g.pages_per_block) return SFFTL_EIO;
          if (bk->state == SFFTL_BS_BAD && (bk->flags & SFFTL_BF_FACTORY)) continue;   /* marker wins */
          if (bk->state == SFFTL_BS_META) {
            if (st == SFFTL_BS_BAD) { bk->state = SFFTL_BS_BAD; bk->flags = SFFTL_BF_GROWN; }
            continue;
          }
          bk->state = (uint8_t)st;
          bk->flags = (uint8_t)fl;
          bk->wp = (uint16_t)wp;
        }
      }
      idx++;
    }
  }
  if (k != W || idx != body_pages || SFFTL_CRC_FINAL(crc) != body_crc) return SFFTL_EIO;
  ck->gen = gen;
  ck->commit_ppn = cat(f, ci)[4];
  ck->commit_seq = cat_seq(f, ci);
  ck->live_start = zone_index(f, ppn_blk(f, runs[0]));
  ck->first_ppn = runs[0];
  return SFFTL_OK;
}

/* P58 DUAL_CKPT: the live region starts at the previous checkpoint when its
 * first body page is still on the medium (catalogued with the right generation
 * and index 0); otherwise at the loaded checkpoint, as in P56. */
static uint32_t live_start_for(sfftl_t *f, uint32_t ncat, const ckinfo_t *ck, uint32_t *prev_ok) {
  *prev_ok = 0;
  if (!(f->cfg.flags & SFFTL_F_DUAL_CKPT) || ck->rebuild || ck->prev_first == SFFTL_NONE) return ck->live_start;
  for (uint32_t i = 0; i < ncat; i++) {
    const uint32_t *e = cat(f, i);
    if (e[4] == ck->prev_first && cat_kind(f, i) == SFFTL_MK_BODY && e[2] == ck->prev_gen && e[3] == 0u) {
      uint32_t z = zone_index(f, ppn_blk(f, ck->prev_first));
      if (z != SFFTL_NONE) { *prev_ok = 1; return z; }
    }
  }
  return ck->live_start;
}

/* replayed-LPN bitmap lives in the VBM storage during mount (rebuilt after) */
static int rbm_get(const sfftl_t *f, uint32_t l) { return (int)((f->vbm[l >> 5] >> (l & 31u)) & 1u); }
static void rbm_set(sfftl_t *f, uint32_t l) { f->vbm[l >> 5] |= 1u << (l & 31u); }
static void rbm_clr(sfftl_t *f, uint32_t l) { f->vbm[l >> 5] &= ~(1u << (l & 31u)); }

/* SEQ of the page an LPN currently maps to, when that mapping came from the
 * roll-forward (otherwise it is older than the checkpoint by construction) */
static int current_seq(sfftl_t *f, uint32_t lpn, uint64_t *seq) {
  uint8_t spare[SFFTL_OOB_BYTES];
  oob_t o;
  int st = nand_read(f, f->l2p[lpn], NULL, spare, RD_MOUNT);
  f->st.last_mount_reads++;
  if (hal_dead(st)) return SFFTL_EPOWER;
  if ((st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) || oob_parse(f, spare, NULL, &o) != 0) { *seq = 0; return SFFTL_OK; }
  *seq = o.seq;
  return SFFTL_OK;
}

static int replay_apply(sfftl_t *f, uint32_t lpn, uint32_t ppn, uint64_t seq) {
  if (f->l2p[lpn] != SFFTL_NONE && rbm_get(f, lpn)) {
    uint64_t cur;
    int rc = current_seq(f, lpn, &cur);
    if (rc < 0) return rc;
    if (cur >= seq) return SFFTL_OK;
  }
  f->l2p[lpn] = ppn;
  rbm_set(f, lpn);
  f->st.last_mount_pages_replayed++;
  return SFFTL_OK;
}

#define RS_SCANNED 0x01u   /* blk.rsvd during mount */
#define RS_EC_JRNL 0x02u
#define RS_REUSED  0x04u

static int replay(sfftl_t *f, const ckinfo_t *ck, uint64_t *maxseq) {
  const uint32_t ppb = f->g.pages_per_block;
  uint8_t spare[SFFTL_OOB_BYTES];
  oob_t o;
  memset(f->vbm, 0, ((f->total_pages + 31u) / 32u) * 4u);
  for (uint32_t b = 0; b < f->g.blocks; b++) {
    sfftl_blk_t *bk = &f->blk[b];
    if (bk->state == SFFTL_BS_META || (bk->state == SFFTL_BS_BAD && (bk->flags & SFFTL_BF_FACTORY))) continue;
    EVT(f, SFFTL_EV_MOUNT_SCAN, b);
    uint32_t from = SFFTL_NONE;
    int st = nand_read(f, mk_ppn(f, b, 0), f->buf_host, spare, RD_MOUNT);
    f->st.last_mount_reads++;
    if (hal_dead(st)) return SFFTL_EPOWER;
    if (st == SFFTL_HAL_OK || st == SFFTL_HAL_CORRECTED) {
      int r = oob_parse(f, spare, f->buf_host, &o);
      if (r == 1 && buf_erased(f->buf_host, f->g.page_data_bytes)) {
        bk->rsvd |= RS_SCANNED;                           /* nothing programmed since the last erase */
        bk->wp = 0;
        continue;
      }
      if (r == 0 && o.type != SFFTL_OOB_TYPE_META && o.seq <= ck->ckpt_seq) {
        if (bk->state != SFFTL_BS_OPEN) continue;           /* entirely older than the checkpoint */
        from = bk->wp;                                      /* open at the checkpoint: its tail is new */
      } else {
        from = 0;                                           /* (re)programmed after the checkpoint */
      }
    } else {
      from = 0;
    }
    /* reprogrammed after the checkpoint without having been erased before it:
     * an erase happened after the checkpoint (its journal record may be lost) */
    if (from == 0 && !(bk->flags & SFFTL_BF_ERASED) && !ck->rebuild) bk->rsvd |= RS_REUSED;
    uint32_t last = from;
    for (uint32_t p = from; p < ppb; p++) {
      uint32_t ppn = mk_ppn(f, b, p);
      int r = -1;
      for (uint32_t a = 0; a <= f->cfg.read_retries; a++) {     /* a CRC mismatch may be a transient miscorrection */
        st = nand_read(f, ppn, f->buf_host, spare, RD_MOUNT);
        f->st.last_mount_reads++;
        if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) break;
        r = oob_parse(f, spare, f->buf_host, &o);
        if (r >= 0) break;
      }
      if (hal_dead(st)) return SFFTL_EPOWER;
      if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) { f->st.last_mount_torn++; last = p + 1u; continue; }
      if (r == 1) {
        if (buf_erased(f->buf_host, f->g.page_data_bytes)) break;    /* end of the programmed part */
        f->st.last_mount_torn++; last = p + 1u; continue;
      }
      last = p + 1u;
      if (r < 0) { f->st.last_mount_torn++; continue; }
      if (o.type == SFFTL_OOB_TYPE_META) continue;
      if (o.seq > *maxseq) *maxseq = o.seq;
      f->st.last_mount_pages_scanned++;
      if (o.seq <= ck->ckpt_seq || o.tag >= f->nlpn) continue;
      int rc = replay_apply(f, o.tag, ppn, o.seq);
      if (rc < 0) return rc;
    }
    bk->rsvd |= RS_SCANNED;
    if (from == 0 || last > bk->wp) bk->wp = (uint16_t)last;
  }
  return SFFTL_OK;
}

/* journal pages newer than the checkpoint, in SEQ order; pass 0 = block
 * records, pass 1 = TRIM */
static int journal_replay(sfftl_t *f, uint32_t ncat, const ckinfo_t *ck, int pass) {
  uint64_t last = ck->ckpt_seq;
  for (;;) {
    uint32_t e = SFFTL_NONE;
    uint64_t best = 0;
    for (uint32_t i = 0; i < ncat; i++) {
      uint64_t s = cat_seq(f, i);
      if (cat_kind(f, i) == SFFTL_MK_JOURNAL && s > last && (e == SFFTL_NONE || s < best)) { e = i; best = s; }
    }
    if (e == SFFTL_NONE) return SFFTL_OK;
    last = best;
    int rc = read_meta_page(f, cat(f, e)[4]);
    if (rc == SFFTL_EPOWER) return rc;
    if (rc < 0) continue;
    const uint8_t *pw = f->buf_meta + SFFTL_META_HDR_BYTES;
    uint32_t n = le32_get(pw);
    if (n > SFFTL_REC_PER_PAGE(f)) continue;
    for (uint32_t r = 0; r < n; r++) {
      uint32_t t = le32_get(pw + 4u + 12u * r), a = le32_get(pw + 8u + 12u * r), v = le32_get(pw + 12u + 12u * r);
      if (pass == 0) f->st.last_mount_journal_records++;
      if (pass == 0 && t == SFFTL_J_PFAIL) {               /* P58 diagnostics: numbered, so a mirror is idempotent */
        if (a > f->diag.pfail_count) { f->diag.pfail_count = a; f->diag.last_pfail_info = v; }
      } else if (pass == 0 && t == SFFTL_J_RECOVERY) {
        if (a > f->diag.recov_count) { f->diag.recov_count = a; f->diag.last_recov_info = v; }
      } else if (pass == 0 && t != SFFTL_J_TRIM && a < f->g.blocks) {
        sfftl_blk_t *bk = &f->blk[a];
        if (t == SFFTL_J_ERASE) {
          if (v > bk->ec) { bk->ec = v; bk->rsvd |= RS_EC_JRNL; }
        } else if (t == SFFTL_J_RETIRE) {
          if (!(bk->state == SFFTL_BS_BAD)) { bk->state = SFFTL_BS_BAD; bk->flags = (uint8_t)((bk->flags & SFFTL_BF_FACTORY) | SFFTL_BF_GROWN); }
        } else if (t == SFFTL_J_PRETIRE) {
          if (bk->state != SFFTL_BS_BAD && bk->state != SFFTL_BS_META) bk->flags |= SFFTL_BF_RETIRE;
        }
      } else if (pass == 1 && t == SFFTL_J_TRIM) {
        for (uint32_t l = a; l < f->nlpn && l - a < v; l++) {
          if (f->l2p[l] == SFFTL_NONE) continue;
          if (rbm_get(f, l)) {
            uint64_t cur;
            rc = current_seq(f, l, &cur);
            if (rc < 0) return rc;
            if (cur > best) continue;                  /* rewritten after the TRIM */
          }
          f->l2p[l] = SFFTL_NONE;
          rbm_clr(f, l);
        }
      }
    }
  }
}

int sfftl_mount(sfftl_t *f, const sfftl_geom_t *g, const sfftl_cfg_t *cfg, const sfftl_hal_t *hal, void *arena,
                size_t arena_bytes) {
  int rc = layout(f, g, cfg, hal, arena, arena_bytes);
  if (rc < 0) return rc;
  if (hal->write_protect) hal->write_protect(hal->ctx, 0);   /* a power cycle releases WP# */
  const uint32_t nb = g->blocks, ppb = g->pages_per_block;
  uint8_t spare[SFFTL_OOB_BYTES];
  oob_t o;
  /* 1. metadata zone from factory markers */
  uint32_t nz = 0;
  for (uint32_t b = 0; b < nb && nz < f->meta_blocks; b++) {
    int bad;
    rc = bbm_is_factory_bad(f, b, &bad);
    if (rc < 0) return rc;
    if (bad) { f->blk[b].state = SFFTL_BS_BAD; f->blk[b].flags = SFFTL_BF_FACTORY; continue; }
    f->zone[nz++] = b;
    f->blk[b].state = SFFTL_BS_META;
  }
  if (nz < f->meta_blocks) return SFFTL_ENOFS;
  /* 2. catalogue every valid metadata page */
  uint32_t ncat = 0;
  uint64_t maxseq = 0;
  for (uint32_t zi = 0; zi < f->meta_blocks; zi++) {
    uint32_t b = f->zone[zi], last = 0;
    EVT(f, SFFTL_EV_MOUNT_SCAN, b);
    for (uint32_t p = 0; p < ppb; p++) {
      uint32_t ppn = mk_ppn(f, b, p);
      int st = nand_read(f, ppn, f->buf_meta, spare, RD_MOUNT);
      if (hal_dead(st)) return SFFTL_EPOWER;
      if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) { last = p + 1u; continue; }
      int r = oob_parse(f, spare, f->buf_meta, &o);
      if (r == 1 && buf_erased(f->buf_meta, g->page_data_bytes)) break;
      last = p + 1u;
      if (r != 0 || o.type != SFFTL_OOB_TYPE_META) continue;
      const uint8_t *h = f->buf_meta;
      uint32_t kind = (uint32_t)h[4] | ((uint32_t)h[5] << 8), schema = (uint32_t)h[6] | ((uint32_t)h[7] << 8);
      if (le32_get(h) != SFFTL_META_MAGIC || schema != SFFTL_SCHEMA_VERSION || kind < SFFTL_MK_BODY ||
          kind > SFFTL_MK_JOURNAL || (o.tag >> 24) != kind || ncat >= f->scratch_words / CAT_W)
        continue;
      uint32_t *e = cat(f, ncat++);
      e[0] = (uint32_t)o.seq; e[1] = (uint32_t)(o.seq >> 32) | (kind << 16);
      e[2] = le32_get(h + 8); e[3] = le32_get(h + 12); e[4] = ppn;
      if (o.seq > maxseq) maxseq = o.seq;
    }
    f->blk[b].wp = (uint16_t)last;
  }
  /* 3. newest loadable checkpoint */
  ckinfo_t ck;
  memset(&ck, 0, sizeof(ck));
  uint32_t chosen = SFFTL_NONE;
  for (;;) {
    uint32_t c = SFFTL_NONE;
    for (uint32_t i = 0; i < ncat; i++)
      if (cat_kind(f, i) == SFFTL_MK_COMMIT && !(cat(f, i)[1] & (CAT_TRIED << 16)) && (c == SFFTL_NONE || cat_seq(f, i) > cat_seq(f, c)))
        c = i;
    if (c == SFFTL_NONE) break;
    /* reset what a failed attempt may have written */
    for (uint32_t b = 0; b < nb; b++) {
      sfftl_blk_t *bk = &f->blk[b];
      if (bk->state == SFFTL_BS_META || (bk->state == SFFTL_BS_BAD && (bk->flags & SFFTL_BF_FACTORY))) continue;
      if (bk->state == SFFTL_BS_BAD && zone_index(f, b) != SFFTL_NONE) { bk->state = SFFTL_BS_META; bk->flags = 0; continue; }
      bk->state = SFFTL_BS_FREE; bk->flags = 0; bk->ec = 0; bk->wp = 0;
    }
    rc = load_checkpoint(f, c, ncat, &ck);
    if (rc == SFFTL_OK) { chosen = c; break; }
    if (rc == SFFTL_EGEOM || rc == SFFTL_EPOWER) return rc;
    cat(f, c)[1] |= CAT_TRIED << 16;
    f->st.last_mount_ckpt_rejected++;
  }
  if (chosen != SFFTL_NONE) f->diag = ck.diag;
  if (chosen == SFFTL_NONE) {
    if (!(cfg->flags & SFFTL_F_ALLOW_REBUILD)) return SFFTL_ENOFS;
    /* rebuild from the spare records alone: factory markers of every block,
     * empty map, checkpoint SEQ 0 (erase counts and pre-existing TRIMs that
     * were only in lost metadata cannot be recovered) */
    ck.rebuild = 1;
    for (uint32_t b = 0; b < nb; b++) {
      sfftl_blk_t *bk = &f->blk[b];
      if (bk->state == SFFTL_BS_META || bk->state == SFFTL_BS_BAD) continue;
      int bad;
      rc = bbm_is_factory_bad(f, b, &bad);
      if (rc < 0) return rc;
      bk->state = bad ? SFFTL_BS_BAD : SFFTL_BS_FREE;
      bk->flags = bad ? SFFTL_BF_FACTORY : 0u;
    }
    {
      plan_t pl;
      (void)plan(g, cfg, &pl);
      uint32_t nbad = 0;
      for (uint32_t b = 0; b < nb; b++) nbad += (f->blk[b].flags & SFFTL_BF_FACTORY) ? 1u : 0u;
      uint32_t n = cfg->nlba ? pl.nlpn_alloc : capacity_lpn(g, cfg, f->meta_blocks, nbad);
      if (n > pl.nlpn_alloc) n = pl.nlpn_alloc;
      set_nlpn(f, n, cfg->nlba ? cfg->nlba : (uint64_t)n * f->spp);
    }
    for (uint32_t l = 0; l < f->nlpn; l++) f->l2p[l] = SFFTL_NONE;
    ck.live_start = SFFTL_NONE;
    ck.first_ppn = SFFTL_NONE;
    ck.prev_first = SFFTL_NONE;
  }
  /* 4. block-level journal records */
  rc = journal_replay(f, ncat, &ck, 0);
  if (rc < 0) return rc;
  /* 5. roll forward unless a clean shutdown left nothing behind */
  int clean = !ck.rebuild && (ck.flags & SFFTL_CKF_CLEAN) && maxseq == ck.commit_seq;
  uint64_t dmax = 0;
  if (!clean) {
    rc = replay(f, &ck, &dmax);
    if (rc < 0) return rc;
    /* 6. deallocations newer than the data they cover */
    rc = journal_replay(f, ncat, &ck, 1);
    if (rc < 0) return rc;
  }
  /* 7. rebuild VBM + valid counts, normalise block states */
  memset(f->vbm, 0, ((f->total_pages + 31u) / 32u) * 4u);
  for (uint32_t b = 0; b < nb; b++) f->blk[b].valid = 0;
  for (uint32_t l = 0; l < f->nlpn; l++) {
    uint32_t p = f->l2p[l];
    if (p == SFFTL_NONE) continue;
    if (p >= f->total_pages) return SFFTL_ECORRUPT;
    sfftl_blk_t *bk = &f->blk[ppn_blk(f, p)];
    if (bk->state == SFFTL_BS_META || (bk->flags & SFFTL_BF_FACTORY) || vbm_get(f, p)) return SFFTL_ECORRUPT;
    vbm_set(f, p);
    bk->valid++;
  }
  f->free_blocks = 0;
  for (uint32_t b = 0; b < nb; b++) {
    sfftl_blk_t *bk = &f->blk[b];
    if ((bk->rsvd & RS_REUSED) && !(bk->rsvd & RS_EC_JRNL)) bk->ec++;    /* erase not journalled before the crash */
    bk->rsvd = 0;
    bk->stream = 0xFFu;
    if (bk->state == SFFTL_BS_META || bk->state == SFFTL_BS_BAD) continue;
    if (!clean) bk->flags &= (uint8_t)~SFFTL_BF_ERASED;
    if (bk->state == SFFTL_BS_OPEN || (bk->state == SFFTL_BS_FREE && bk->valid > 0)) bk->state = SFFTL_BS_CLOSED;
    if (bk->state == SFFTL_BS_CLOSED) {
      bk->close_seq = (uint32_t)ck.ckpt_seq;
      if (bk->valid == 0 && !(bk->flags & SFFTL_BF_RETIRE)) bk->state = SFFTL_BS_FREE;
    }
    if (bk->state == SFFTL_BS_FREE) { bk->flags &= (uint8_t)~(SFFTL_BF_RETIRE | SFFTL_BF_REFRESH); f->free_blocks++; }
  }
  /* sequence numbers continue above everything on the medium */
  uint64_t ns = ck.next_seq;
  if (maxseq + 1u > ns) ns = maxseq + 1u;
  if (dmax + 1u > ns) ns = dmax + 1u;
  if (ns == 0) ns = 1;
  f->next_seq = ns;
  f->gen = ck.gen;
  f->life_host_lba = ck.life[0];
  f->life_prog = ck.life[1];
  f->life_erase = ck.life[2];
  f->life_mounts = ck.life[3] + 1u;
  f->st.last_mount_ckpt_gen = ck.gen;
  /* 8. metadata head */
  uint32_t commit_zi = ck.rebuild ? SFFTL_NONE : zone_index(f, ppn_blk(f, ck.commit_ppn));
  uint32_t prev_ok = 0;
  uint32_t live0 = live_start_for(f, ncat, &ck, &prev_ok);
  f->ckpt_first_ppn = ck.first_ppn;
  f->prev_first_ppn = prev_ok ? ck.prev_first : SFFTL_NONE;
  f->prev_gen = prev_ok ? ck.prev_gen : 0u;
  if (clean && ppn_pg(f, ck.commit_ppn) + 1u < ppb && f->blk[f->zone[commit_zi]].wp == ppn_pg(f, ck.commit_ppn) + 1u) {
    f->mz_head = commit_zi;
    f->mz_wp = ppn_pg(f, ck.commit_ppn) + 1u;
    f->mz_live_start = live0;
  } else {
    /* fresh block after the last page that matters (commit + newer journals) */
    uint32_t live_end = commit_zi;
    uint64_t rel = ck.commit_seq;
    for (uint32_t i = 0; i < ncat; i++) {
      uint64_t s = cat_seq(f, i);
      if (cat_kind(f, i) == SFFTL_MK_JOURNAL && s > ck.ckpt_seq && s > rel) { rel = s; live_end = zone_index(f, ppn_blk(f, cat(f, i)[4])); }
    }
    if (live_end == SFFTL_NONE) live_end = 0;
    f->mz_live_start = ck.rebuild ? SFFTL_NONE : live0;
    f->mz_head = live_end;
    f->mz_wp = ppb;                                  /* force meta_advance to a fresh block */
    if (ck.rebuild) f->mz_live_start = live_end;     /* nothing to protect: ring may wrap up to here */
    rc = meta_ensure_head(f);
    if (rc == SFFTL_EROFS) f->read_only = 1;         /* metadata zone exhausted: serve reads only */
    else if (rc < 0) return rc;
  }
  /* streams start closed */
  for (uint32_t s = 0; s < SFFTL_NSTREAMS; s++) f->stream_blk[s] = SFFTL_NONE;
  f->mounted = 1;
  if (clean) {
    f->clean_on_media = 1;
    f->st.mount_clean++;
    f->st.last_mount_kind = 0;
  } else {
    if (ck.rebuild) f->st.mount_rebuild++; else f->st.mount_unclean++;
    f->st.last_mount_kind = ck.rebuild ? 2u : 1u;
    f->diag.unclean_mounts++;                        /* persisted by the checkpoint below */
    f->clean_on_media = 0;
    if (!f->read_only) {
      EVT(f, SFFTL_EV_MOUNT_CKPT, ck.gen);
      rc = ckpt_write(f, 0);                         /* bound the next roll-forward */
      if (rc == SFFTL_EROFS) f->read_only = 1;
      else if (rc < 0) { f->mounted = 0; return rc; }
    }
  }
  f->st.last_mount_programs = (uint32_t)(f->st.nand_prog_meta + f->st.nand_prog_host + f->st.nand_prog_reloc);
  f->st.last_mount_erases = (uint32_t)(f->st.nand_erase_meta + f->st.nand_erase_data);
  /* read_only: the map is recovered and reads are served, every change is
   * refused (SFFTL_EROFS); sfftl_space().read_only reports it */
  return SFFTL_OK;
}
