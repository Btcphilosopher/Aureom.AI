/* =============================================================================
 * SilicaFlux FlashMap (Project 56) -- NAND hardware abstraction layer contract
 *
 * The FTL never touches NAND registers.  It calls these five functions through
 * a table supplied by the integrator.  Two implementations exist:
 *   hal/sim/  host-side NAND device model with NANDLab (P52) semantics,
 *             fault and power-cut injection, timing model  (tests, benchmarks)
 *   hal/sfs/  ControlCore firmware backend for the StorageCore (P51)
 *             sfs_nand_ctrl register interface            (RTL simulation)
 *
 * Addressing is flat: physical block number pbn in [0, geom.blocks) and
 * physical page number ppn = pbn * pages_per_block + page.  Mapping pbn onto
 * channel / chip enable / LUN / plane / block is the HAL's job.
 *
 * Every call is synchronous: it returns once the device status is known.
 * ===========================================================================*/
#ifndef SFFTL_HAL_H
#define SFFTL_HAL_H

#include <stdint.h>
#include <stddef.h>

/* bytes of the spare area the FTL owns (see sfftl_schema.h for the layout).
 * Spare bytes beyond these are written as 0xFF by the HAL. */
#define SFFTL_OOB_BYTES 16u

enum sfftl_hal_status {
  SFFTL_HAL_OK            = 0,  /* operation succeeded                                    */
  SFFTL_HAL_CORRECTED     = 1,  /* read: data returned after ECC correction (*bitflips)   */
  SFFTL_HAL_UNCORRECTABLE = 2,  /* read: ECC failed; buffers hold raw (unusable) bytes    */
  SFFTL_HAL_PROGRAM_FAIL  = 3,  /* program: status FAIL; page content undefined           */
  SFFTL_HAL_ERASE_FAIL    = 4,  /* erase: status FAIL; block content undefined            */
  SFFTL_HAL_WRITE_PROTECT = 5,  /* program/erase refused: WP# asserted                    */
  SFFTL_HAL_POWER_LOSS    = 6,  /* supply lost: operation outcome unknown, device dead    */
  SFFTL_HAL_TIMEOUT       = 7,  /* device did not become ready                            */
  SFFTL_HAL_INVALID       = 8   /* address / argument outside the device                  */
};

typedef struct sfftl_hal {
  void *ctx;

  /* Read one page.  data (page_data_bytes) and spare (SFFTL_OOB_BYTES) may each
   * be NULL.  The ECC codeword covers data AND the FTL's spare bytes, so a
   * spare-only read is still ECC-checked (an implementation may read the whole
   * page internally).  *bitflips (may be NULL) receives the corrected bit count.
   * An erased page reads as all 0xFF with status OK. */
  int (*read)(void *ctx, uint32_t ppn, void *data, void *spare, uint32_t *bitflips);

  /* Program data (page_data_bytes) and spare (SFFTL_OOB_BYTES) in ONE device
   * program operation and return the device status.  The FTL programs the
   * pages of a block strictly in ascending order and each page at most once
   * between erases (NAND rules; checked by the simulated device). */
  int (*program)(void *ctx, uint32_t ppn, const void *data, const void *spare);

  /* Erase one block. */
  int (*erase)(void *ctx, uint32_t pbn);

  /* Raw (no ECC) read of the manufacturer bad-block marker byte: spare byte
   * SFFTL_BBM_OFFSET of the given page.  Used by format (pages 0 and last of
   * every block, BEFORE anything is erased) and by mount (metadata-zone
   * discovery).  Never used to write anything. */
  int (*read_marker)(void *ctx, uint32_t ppn, uint8_t *marker);

  /* Optional (may be NULL): assert / release the device write protect.
   * Called by the PowerSafe hook once the FTL has reached a safe state. */
  void (*write_protect)(void *ctx, int enable);
} sfftl_hal_t;

/* offset of the manufacturer bad-block marker inside the spare area
 * (NANDLab policy.bad_block_marker_byte = 0) */
#define SFFTL_BBM_OFFSET 0u

#endif /* SFFTL_HAL_H */
