/* =============================================================================
 * SilicaFlux FlashMap -- NAND HAL for the StorageCore (P51) sfs_nand_ctrl
 * Register usage follows P51 firmware/app/hal.c (channel bring-up, op staging,
 * completion polling); see hal_sfs.h for the page layout.
 * ===========================================================================*/
#include "hal_sfs.h"
#include "cc_hw.h"
#include "sfs_map.h"

#define NAND(c, o) REG32(SFS_NAND_BASE + (uint32_t)(c) * SFS_NAND_CH_STRIDE + (o))
#define HAL_TAG    0xB0u              /* internal tag (bit 7 set: not a host command) */
#define POLL_LIMIT 8000000u

uint32_t sfs_cycles(void) { return csr_read(mcycle); }

/* one operation, synchronously; returns the NST_* status or 0xFF on a poll timeout */
static uint32_t op_sync(sfs_hal_t *h, uint32_t op, uint32_t row, uint32_t col, uint32_t len, int ecc, uint32_t *info0) {
  NAND(h->ch, SFS_NAND_OP_ROW) = row;
  NAND(h->ch, SFS_NAND_OP_COL) = col;
  NAND(h->ch, SFS_NAND_OP_BUF) = h->slot;
  NAND(h->ch, SFS_NAND_OP_LEN) = len;
  NAND(h->ch, SFS_NAND_OP_SUBMIT) = op | (ecc ? (1u << 8) : 0u) | (HAL_TAG << 16);
  h->ops++;
  uint32_t t0 = sfs_cycles(), head;
  while (!((head = NAND(h->ch, SFS_NAND_CPL_HEAD)) & 0x80000000u)) {
    if (sfs_cycles() - t0 > POLL_LIMIT) { h->timeouts++; return 0xFFu; }
  }
  if (info0) *info0 = NAND(h->ch, SFS_NAND_CPL_INFO0);
  NAND(h->ch, SFS_NAND_CPL_POP) = 0u;
  return (head >> 8) & 0xFFu;
}

typedef uint32_t __attribute__((__may_alias__)) u32_alias;

static void copy_in(sfs_hal_t *h, const void *data, const void *spare) {
  uint32_t t0 = sfs_cycles();
  const uint8_t *d = (const uint8_t *)data, *s = (const uint8_t *)spare;
  volatile uint32_t *b = (volatile uint32_t *)(uintptr_t)h->slot;
  if (!((uintptr_t)d & 3u)) {                             /* aligned: one load + one store per word */
    const u32_alias *w = (const u32_alias *)(const void *)d;
    for (uint32_t i = 0; i < SFS_HAL_DATA_BYTES / 4u; i++) b[i] = w[i];
    d += SFS_HAL_DATA_BYTES;
  } else
  for (uint32_t i = 0; i < SFS_HAL_DATA_BYTES / 4u; i++, d += 4)
    b[i] = (uint32_t)d[0] | ((uint32_t)d[1] << 8) | ((uint32_t)d[2] << 16) | ((uint32_t)d[3] << 24);
  for (uint32_t i = 0; i < SFFTL_OOB_BYTES / 4u; i++, s += 4)
    b[SFS_HAL_DATA_BYTES / 4u + i] = (uint32_t)s[0] | ((uint32_t)s[1] << 8) | ((uint32_t)s[2] << 16) | ((uint32_t)s[3] << 24);
  h->cyc_copy += sfs_cycles() - t0;
}

static void copy_out(sfs_hal_t *h, void *data, void *spare) {
  uint32_t t0 = sfs_cycles();
  volatile uint32_t *b = (volatile uint32_t *)(uintptr_t)h->slot;
  if (data && !((uintptr_t)data & 3u)) {                   /* aligned: one load + one store per word */
    u32_alias *w = (u32_alias *)data;
    for (uint32_t i = 0; i < SFS_HAL_DATA_BYTES / 4u; i++) w[i] = b[i];
  } else if (data) {
    uint8_t *d = (uint8_t *)data;
    for (uint32_t i = 0; i < SFS_HAL_DATA_BYTES / 4u; i++, d += 4) {
      uint32_t w = b[i];
      d[0] = (uint8_t)w; d[1] = (uint8_t)(w >> 8); d[2] = (uint8_t)(w >> 16); d[3] = (uint8_t)(w >> 24);
    }
  }
  if (spare) {
    uint8_t *s = (uint8_t *)spare;
    for (uint32_t i = 0; i < SFFTL_OOB_BYTES / 4u; i++, s += 4) {
      uint32_t w = b[SFS_HAL_DATA_BYTES / 4u + i];
      s[0] = (uint8_t)w; s[1] = (uint8_t)(w >> 8); s[2] = (uint8_t)(w >> 16); s[3] = (uint8_t)(w >> 24);
    }
  }
  h->cyc_copy += sfs_cycles() - t0;
}

static int h_read(void *ctx, uint32_t ppn, void *data, void *spare, uint32_t *bitflips) {
  sfs_hal_t *h = (sfs_hal_t *)ctx;
  uint32_t t0 = sfs_cycles(), info = 0;
  h->reads++;
  uint32_t st = op_sync(h, SFS_NOP_READ_PAGE, ppn, 0u, SFS_HAL_USER_BYTES, (int)h->ecc, &info);
  int rc;
  if (st == SFS_NST_OK || st == SFS_NST_CORRECTED) {
    copy_out(h, data, spare);
    if (bitflips) *bitflips = info & 0xFFFFu;
    h->corrected_bits += info & 0xFFFFu;
    rc = (st == SFS_NST_CORRECTED) ? SFFTL_HAL_CORRECTED : SFFTL_HAL_OK;
  } else if (st == SFS_NST_UNCORR) {
    copy_out(h, data, spare);
    h->uncorrectable++;
    rc = SFFTL_HAL_UNCORRECTABLE;
  } else {
    rc = (st == 0xFFu || st == SFS_NST_TIMEOUT) ? SFFTL_HAL_TIMEOUT : SFFTL_HAL_INVALID;
  }
  h->cyc_total += sfs_cycles() - t0;
  return rc;
}

static int h_program(void *ctx, uint32_t ppn, const void *data, const void *spare) {
  sfs_hal_t *h = (sfs_hal_t *)ctx;
  uint32_t t0 = sfs_cycles();
  h->programs++;
  copy_in(h, data, spare);
  uint32_t st = op_sync(h, SFS_NOP_PROGRAM, ppn, 0u, SFS_HAL_USER_BYTES, (int)h->ecc, 0);
  h->cyc_total += sfs_cycles() - t0;
  if (st == SFS_NST_OK) return SFFTL_HAL_OK;
  if (st == SFS_NST_PROG_FAIL) return SFFTL_HAL_PROGRAM_FAIL;
  if (st == SFS_NST_WP) return SFFTL_HAL_WRITE_PROTECT;
  return (st == 0xFFu || st == SFS_NST_TIMEOUT) ? SFFTL_HAL_TIMEOUT : SFFTL_HAL_INVALID;
}

static int h_erase(void *ctx, uint32_t pbn) {
  sfs_hal_t *h = (sfs_hal_t *)ctx;
  uint32_t t0 = sfs_cycles();
  h->erases++;
  uint32_t st = op_sync(h, SFS_NOP_ERASE, pbn * SFS_HAL_PPB, 0u, 0u, 0, 0);
  h->cyc_total += sfs_cycles() - t0;
  if (st == SFS_NST_OK) return SFFTL_HAL_OK;
  if (st == SFS_NST_ERASE_FAIL) return SFFTL_HAL_ERASE_FAIL;
  if (st == SFS_NST_WP) return SFFTL_HAL_WRITE_PROTECT;
  return (st == 0xFFu || st == SFS_NST_TIMEOUT) ? SFFTL_HAL_TIMEOUT : SFFTL_HAL_INVALID;
}

static int h_marker(void *ctx, uint32_t ppn, uint8_t *m) {
  sfs_hal_t *h = (sfs_hal_t *)ctx;
  uint32_t t0 = sfs_cycles();
  uint32_t col = h->ecc ? SFS_HAL_MARKER_COL : SFS_HAL_DATA_BYTES;
  uint32_t st = op_sync(h, SFS_NOP_READ_PAGE, ppn, col, 4u, 0, 0);     /* raw: no ECC */
  h->cyc_total += sfs_cycles() - t0;
  if (st != SFS_NST_OK) return SFFTL_HAL_INVALID;
  *m = (uint8_t)REG32(h->slot);
  return SFFTL_HAL_OK;
}

static void h_wp(void *ctx, int on) {
  sfs_hal_t *h = (sfs_hal_t *)ctx;
  h->ctrl = on ? (h->ctrl & ~1u) : (h->ctrl | 1u);                  /* CH_CTRL[0] = WP_N */
  NAND(h->ch, SFS_NAND_CH_CTRL) = h->ctrl;
}

int sfs_hal_init(sfs_hal_t *h, uint32_t ch, uint32_t slot, uint32_t *id0) {
  uint32_t info = NAND(ch, SFS_NAND_CH_INFO);
  h->ch = ch;
  h->slot = slot;
  h->ecc = (info >> 8) & 1u;
  if ((info >> 16) != SFS_HAL_USER_BYTES) return -2;              /* SoC must be built with NAND_PAGE_BYTES = 528 */
  NAND(ch, SFS_NAND_TIMING0) = 0x02020202u;                         /* tWP tWH tRP tREH = 2 cycles (P51 default) */
  NAND(ch, SFS_NAND_TIMING1) = 0x00000404u;
  NAND(ch, SFS_NAND_TIMEOUT) = 0x00100000u;
  h->ctrl = 0x3u;                                                   /* WP_N, CE_EN (completion polled, no IRQ) */
  NAND(ch, SFS_NAND_CH_CTRL) = h->ctrl;
  if (op_sync(h, SFS_NOP_RESET, 0, 0, 0, 0, 0) != SFS_NST_OK) return -3;
  if (op_sync(h, SFS_NOP_READ_ID, 0, 0, 0, 0, id0) != SFS_NST_OK) return -4;
  return 0;
}

void sfs_hal_bind(sfs_hal_t *h, sfftl_hal_t *hal) {
  hal->ctx = h;
  hal->read = h_read;
  hal->program = h_program;
  hal->erase = h_erase;
  hal->read_marker = h_marker;
  hal->write_protect = h_wp;
}
