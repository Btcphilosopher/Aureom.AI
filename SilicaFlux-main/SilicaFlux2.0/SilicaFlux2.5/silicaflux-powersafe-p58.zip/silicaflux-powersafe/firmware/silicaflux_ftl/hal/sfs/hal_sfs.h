/* =============================================================================
 * SilicaFlux FlashMap -- NAND HAL for the StorageCore (P51) sfs_nand_ctrl
 *
 * Runs on the ControlCore RV32IM firmware processor.  Each HAL call stages one
 * operation (OP_ROW/COL/BUF/LEN), submits it (OP_SUBMIT {op, ECC_EN, tag}) and
 * polls the channel's completion queue (CPL_HEAD / INFO0 / POP): synchronous,
 * as the FTL contract requires.  Page data move between DMEM and a reserved
 * buffer-SRAM slot with 32-bit CPU copies.
 *
 * Page layout on the bus (ECC_EN = 1, x8 channel, 32-bit words): user bytes
 * 0..511 = FTL data, 512..527 = the FTL spare record, each 32-bit word
 * followed by its SECDED beat -> 660 raw bytes.  The SoC is instantiated with
 * NAND_PAGE_BYTES = 528 so data + spare go in ONE program operation, both
 * covered by the controller's ECC (the HAL contract).  The manufacturer
 * marker (FTL spare byte 0) is raw column 640 (= word 128 x 5 bytes),
 * read with ECC disabled.
 * ===========================================================================*/
#ifndef HAL_SFS_H
#define HAL_SFS_H

#include <stdint.h>
#include "sfftl_hal.h"

#define SFS_HAL_DATA_BYTES   512u
#define SFS_HAL_USER_BYTES   (SFS_HAL_DATA_BYTES + SFFTL_OOB_BYTES)   /* 528 */
#define SFS_HAL_MARKER_COL   640u                                     /* raw column of user byte 512 with ECC */
#define SFS_HAL_PPB          16u
#define SFS_HAL_BLOCKS       64u

typedef struct {
  uint32_t ch;            /* NAND channel                                  */
  uint32_t slot;          /* buffer-SRAM address of the HAL's page slot   */
  uint32_t ecc;           /* controller has page ECC                      */
  uint32_t ctrl;          /* CH_CTRL shadow                               */
  /* measurement */
  uint32_t ops, reads, programs, erases, corrected_bits, uncorrectable, timeouts;
  uint64_t cyc_total;     /* mcycle spent inside HAL calls (incl. NAND busy) */
  uint64_t cyc_copy;      /* of which: CPU copies DMEM <-> buffer SRAM     */
} sfs_hal_t;

/* bring the channel up (timing, CE/WP, RESET, READ_ID); 0 on success */
int  sfs_hal_init(sfs_hal_t *h, uint32_t ch, uint32_t buf_slot_addr, uint32_t *id0);
void sfs_hal_bind(sfs_hal_t *h, sfftl_hal_t *hal);
uint32_t sfs_cycles(void);

#endif
