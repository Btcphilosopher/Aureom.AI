/* =============================================================================
 * SilicaFlux FlashMap -- performance measurement on the simulated NAND device
 *
 *   ./sfftl_bench <outdir>      -> <outdir>/PERF.md and CSV files
 *
 * Measured (all from counters, not estimated):
 *   logical bytes written, physical bytes programmed (host / relocation /
 *   metadata), write amplification, GC overhead (pages moved, share of device
 *   time), erase-count distribution (FTL counters and device ground truth),
 *   free space over time, mapping memory, per-command latency (modelled
 *   device time of the synchronous call), mount cost.
 * Device times are the illustrative NANDLab slc_tiny values (tR 25 us,
 * tPROG 200 us, tBERS 2 ms, 30 ns/byte bus); latency results inherit that
 * caveat.  Host CPU time is NOT reported as FTL cost: ControlCore cycles come
 * from the RTL run (reports/RTL_RUN.md).  No device lifetime is inferred.
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <inttypes.h>
#include "harness.h"

typedef struct { const char *name; uint32_t page, ppb, blocks, lba; } dev_t2;
static const dev_t2 DEV_P51 = { "P51 (512 B x 16 x 64)", 512, 16, 64, 512 };
static const dev_t2 DEV_B   = { "Bench (4 KiB x 64 x 256)", 4096, 64, 256, 4096 };

enum { PAT_UNIFORM, PAT_HOTCOLD, PAT_SEQ };
typedef struct {
  const char *name;
  const dev_t2 *dev;
  int pattern;
  uint32_t hot_access_pct, hot_space_pct;
  double volume;                 /* host writes after the fill, in multiples of capacity */
  uint32_t read_pct;
  sfftl_gc_policy_t gc;
  sfftl_wl_policy_t wl;
  uint32_t op_permille;
  uint32_t io_lbas;
  uint32_t ckpt_interval;
  const char *tag;               /* CSV file stem for time series / histograms (NULL: none) */
  int no_paced;                  /* 1: blocking foreground GC only */
} run_t;

typedef struct {
  double wa_total, wa_nometa, reloc_per_host, meta_share, gc_time_share;
  uint64_t host_bytes, phys_bytes, prog_host, prog_reloc, prog_meta, erases, victims, ckpts;
  double ec_mean, ec_sd, dev_ec_mean, dev_ec_sd;
  uint32_t ec_min, ec_max, dev_ec_min, dev_ec_max;
  double w_p50, w_p99, w_p999, w_max, r_p50, r_p99, r_max;
  uint32_t enospc;
} res_t;

static int cmpd(const void *a, const void *b) {
  double x = *(const double *)a, y = *(const double *)b;
  return x < y ? -1 : x > y;
}
static double pct(double *v, size_t n, double p) {
  if (!n) return 0;
  size_t i = (size_t)(p * (double)(n - 1) + 0.5);
  return v[i];
}

static FILE *outf(const char *dir, const char *name) {
  char path[512];
  snprintf(path, sizeof(path), "%s/%s", dir, name);
  FILE *f = fopen(path, "w");
  if (!f) { perror(path); exit(1); }
  return f;
}

static uint64_t pick_lba(hx_t *h, const run_t *r, uint64_t nlba, uint64_t *seqp) {
  if (r->pattern == PAT_SEQ) { uint64_t l = *seqp; *seqp = (*seqp + r->io_lbas) % nlba; return l; }
  if (r->pattern == PAT_HOTCOLD) {
    uint64_t hot = nlba * r->hot_space_pct / 100u;
    if ((hx_rand(h) % 100u) < r->hot_access_pct) return hx_rand(h) % hot;
    return hot + hx_rand(h) % (nlba - hot);
  }
  return hx_rand(h) % nlba;
}

static void run(const run_t *r, const char *dir, res_t *o) {
  sfftl_geom_t g; hx_geom(&g, r->dev->page, r->dev->ppb, r->dev->blocks);
  sfftl_cfg_t c; sfftl_cfg_default(&c);
  c.lba_bytes = r->dev->lba;
  c.gc_policy = r->gc;
  c.wl_policy = r->wl;
  c.op_permille = r->op_permille;
  c.ckpt_interval_blocks = r->ckpt_interval;
  c.wl_static_threshold = 16;
  c.wl_static_interval = 32;
  if (r->no_paced) c.flags &= ~SFFTL_F_PACED_GC;
  hx_t h;
  memset(o, 0, sizeof(*o));
  if (hx_init(&h, &g, &c, NULL, 0xBE4C4u)) { fprintf(stderr, "init failed: %s\n", r->name); exit(1); }
  const uint64_t nlba = hx_nlba(&h);
  const simnand_stats_t *ns = simnand_stats(h.nand);
  /* fill the namespace sequentially (preconditioning), then measure */
  for (uint64_t l = 0; l < nlba; l += r->io_lbas) hx_write(&h, l, (uint32_t)(nlba - l < r->io_lbas ? nlba - l : r->io_lbas));
  sfftl_stats_t s0 = *sfftl_stats(&h.ftl);
  simnand_stats_t d0 = *ns;
  uint64_t writes = (uint64_t)(r->volume * (double)nlba / r->io_lbas), seq = 0;
  size_t nw = 0, nr = 0;
  size_t rcap = 1024;
  double *wl = (double *)malloc(sizeof(double) * (writes + 1)), *rl = (double *)malloc(sizeof(double) * rcap);
  FILE *ts = NULL;
  if (r->tag) {
    char nm[128]; snprintf(nm, sizeof(nm), "timeline_%s.csv", r->tag);
    ts = outf(dir, nm);
    fprintf(ts, "host_writes,capacity_multiple,free_blocks,valid_pages,invalid_pages,writable_pages,wa_cumulative\n");
  }
  uint64_t sample = writes / 100u ? writes / 100u : 1u;
  for (uint64_t i = 0; i < writes;) {
    uint64_t lba = pick_lba(&h, r, nlba, &seq);
    uint32_t n = r->io_lbas;
    if (lba + n > nlba) lba = nlba - n;
    if (r->read_pct && (hx_rand(&h) % 100u) < r->read_pct) {
      uint64_t t0 = ns->time_ns;
      sfftl_read(&h.ftl, lba, n, h.io);
      if (nr == rcap) { rcap *= 2; rl = (double *)realloc(rl, sizeof(double) * rcap); }
      rl[nr++] = (double)(ns->time_ns - t0) / 1000.0;
      continue;
    }
    ref_write_begin(&h.ref, lba, n, h.io);
    uint64_t t0 = ns->time_ns;
    int rc = sfftl_write(&h.ftl, lba, n, h.io);
    if (rc == SFFTL_OK) ref_ack(&h.ref, lba, n); else o->enospc++;
    wl[nw++] = (double)(ns->time_ns - t0) / 1000.0;
    i++;
    if (ts && (i % sample) == 0) {
      sfftl_space_t sp; sfftl_space(&h.ftl, &sp);
      const sfftl_stats_t *s = sfftl_stats(&h.ftl);
      double wa = (double)(s->nand_prog_host + s->nand_prog_reloc + s->nand_prog_meta - s0.nand_prog_host - s0.nand_prog_reloc - s0.nand_prog_meta) *
                  r->dev->page / ((double)(s->host_lba_written - s0.host_lba_written) * r->dev->lba);
      fprintf(ts, "%" PRIu64 ",%.3f,%u,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%.4f\n", i, (double)i * n / (double)nlba,
              sp.blocks_free, sp.pages_valid, sp.pages_invalid, sp.pages_writable, wa);
    }
  }
  if (ts) fclose(ts);
  /* correctness is not optional, even in a benchmark */
  if (hx_verify_all(&h)) { fprintf(stderr, "%s: DATA MISMATCH %s\n", r->name, h.why); exit(1); }
  if (sfftl_check(&h.ftl) || hx_violations(&h)) { fprintf(stderr, "%s: invariant/violation\n", r->name); exit(1); }

  const sfftl_stats_t *s = sfftl_stats(&h.ftl);
  o->prog_host = s->nand_prog_host - s0.nand_prog_host;
  o->prog_reloc = s->nand_prog_reloc - s0.nand_prog_reloc;
  o->prog_meta = s->nand_prog_meta - s0.nand_prog_meta;
  o->erases = (s->nand_erase_data + s->nand_erase_meta) - (s0.nand_erase_data + s0.nand_erase_meta);
  o->victims = s->gc_victims - s0.gc_victims;
  o->ckpts = s->ckpt_count - s0.ckpt_count;
  o->host_bytes = (s->host_lba_written - s0.host_lba_written) * r->dev->lba;
  o->phys_bytes = (o->prog_host + o->prog_reloc + o->prog_meta) * r->dev->page;
  o->wa_total = (double)o->phys_bytes / (double)o->host_bytes;
  o->wa_nometa = (double)((o->prog_host + o->prog_reloc) * r->dev->page) / (double)o->host_bytes;
  o->reloc_per_host = (double)o->prog_reloc / (double)o->prog_host;
  o->meta_share = (double)o->prog_meta / (double)(o->prog_host + o->prog_reloc + o->prog_meta);
  /* device-time attribution (modelled) */
  const simnand_cfg_t *nc = &h.ncfg;
  double tprog = nc->t_prog_ns + (double)nc->t_byte_ns * (r->dev->page + 16), tread = nc->t_r_ns + (double)nc->t_byte_ns * (r->dev->page + 16);
  double t_gc = (double)(s->nand_read_reloc - s0.nand_read_reloc + s->nand_read_verify - s0.nand_read_verify) * tread +
                (double)o->prog_reloc * tprog + (double)(s->nand_erase_data - s0.nand_erase_data) * nc->t_bers_ns;
  double t_all = (double)(ns->time_ns - d0.time_ns);
  o->gc_time_share = t_gc / t_all;
  /* erase-count distribution over data blocks */
  double sum = 0, sq = 0, dsum = 0, dsq = 0;
  uint32_t nb = 0;
  o->ec_min = o->dev_ec_min = 0xFFFFFFFFu;
  for (uint32_t b = 0; b < g.blocks; b++) {
    const sfftl_blk_t *bk = &h.ftl.blk[b];
    if (bk->state == SFFTL_BS_BAD || bk->state == SFFTL_BS_META) continue;
    uint32_t e = bk->ec, d = simnand_erase_count(h.nand, b);
    sum += e; sq += (double)e * e; dsum += d; dsq += (double)d * d; nb++;
    if (e < o->ec_min) o->ec_min = e;
    if (e > o->ec_max) o->ec_max = e;
    if (d < o->dev_ec_min) o->dev_ec_min = d;
    if (d > o->dev_ec_max) o->dev_ec_max = d;
  }
  o->ec_mean = sum / nb; o->ec_sd = sqrt(sq / nb - o->ec_mean * o->ec_mean);
  o->dev_ec_mean = dsum / nb; o->dev_ec_sd = sqrt(dsq / nb - o->dev_ec_mean * o->dev_ec_mean);
  if (r->tag) {
    char nm[128]; snprintf(nm, sizeof(nm), "erase_counts_%s.csv", r->tag);
    FILE *f = outf(dir, nm);
    fprintf(f, "block,state,ftl_erase_count,device_erase_count\n");
    for (uint32_t b = 0; b < g.blocks; b++)
      fprintf(f, "%u,%u,%u,%u\n", b, h.ftl.blk[b].state, h.ftl.blk[b].ec, simnand_erase_count(h.nand, b));
    fclose(f);
  }
  qsort(wl, nw, sizeof(double), cmpd);
  qsort(rl, nr, sizeof(double), cmpd);
  o->w_p50 = pct(wl, nw, 0.50); o->w_p99 = pct(wl, nw, 0.99); o->w_p999 = pct(wl, nw, 0.999); o->w_max = nw ? wl[nw - 1] : 0;
  o->r_p50 = pct(rl, nr, 0.50); o->r_p99 = pct(rl, nr, 0.99); o->r_max = nr ? rl[nr - 1] : 0;
  if (r->tag) {
    char nm[128]; snprintf(nm, sizeof(nm), "latency_%s.csv", r->tag);
    FILE *f = outf(dir, nm);
    fprintf(f, "percentile,write_us,read_us\n");
    for (int k = 0; k <= 1000; k++) {
      double p = k / 1000.0;
      fprintf(f, "%.3f,%.1f,%.1f\n", p, pct(wl, nw, p), pct(rl, nr, p));
    }
    fclose(f);
  }
  free(wl); free(rl);
  hx_free(&h);
}

static const char *gcn(sfftl_gc_policy_t g) { return g == SFFTL_GC_GREEDY ? "greedy" : "cost-benefit"; }
static const char *wln(sfftl_wl_policy_t w) { return w == SFFTL_WL_NONE ? "none" : w == SFFTL_WL_DYNAMIC ? "dynamic" : "dyn+static"; }

int main(int argc, char **argv) {
  const char *dir = argc > 1 ? argv[1] : ".";
  FILE *md = outf(dir, "PERF.md");
  FILE *csv = outf(dir, "runs.csv");
  fprintf(csv, "run,device,pattern,op_permille,gc,wl,host_MiB,phys_MiB,wa_total,wa_no_meta,reloc_per_host,meta_share,gc_time_share,"
               "erases,victims,ckpts,ec_min,ec_max,ec_mean,ec_sd,dev_ec_min,dev_ec_max,dev_ec_sd,w_p50_us,w_p99_us,w_p999_us,w_max_us,"
               "r_p50_us,r_p99_us,r_max_us,enospc\n");
  fprintf(md, "# FlashMap performance measurements (simulated NAND)\n\n"
              "Generated by `bench/bench.c` (`make bench`). Every run preconditions the namespace with a sequential fill, "
              "then measures the stated workload; after each run all data is verified against the reference model and the "
              "device must report zero NAND-rule violations. Device times are the illustrative NANDLab `slc_tiny` values "
              "(tR 25 us, tPROG 200 us, tBERS 2 ms, 30 ns/byte): latency figures inherit that caveat. Erase counts are "
              "reported as counts only; **no endurance or lifetime figure is derived** (the wear model is uncalibrated).\n\n");

  const run_t runs[] = {
    /* 1. workload shapes on the bench device */
    { "seq overwrite",          &DEV_B, PAT_SEQ,     0, 0,   4.0, 0,  SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, "seq" },
    { "uniform random",         &DEV_B, PAT_UNIFORM, 0, 0,   4.0, 0,  SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, "uniform" },
    { "uniform random, blocking GC only", &DEV_B, PAT_UNIFORM, 0, 0, 4.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, "uniform_blocking", 1 },
    { "hot/cold 80/20",         &DEV_B, PAT_HOTCOLD, 80, 20, 4.0, 0,  SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, NULL },
    { "hot/cold 90/10",         &DEV_B, PAT_HOTCOLD, 90, 10, 4.0, 0,  SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, NULL },
    { "mixed 70% read uniform", &DEV_B, PAT_UNIFORM, 0, 0,   2.0, 70, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, "mixed" },
    /* 2. GC policy on skewed data */
    { "hot/cold 90/10 cost-benefit", &DEV_B, PAT_HOTCOLD, 90, 10, 4.0, 0, SFFTL_GC_COST_BENEFIT, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, NULL },
    { "hot/cold 80/20 cost-benefit", &DEV_B, PAT_HOTCOLD, 80, 20, 4.0, 0, SFFTL_GC_COST_BENEFIT, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, NULL },
    { "uniform cost-benefit",        &DEV_B, PAT_UNIFORM, 0, 0,   4.0, 0, SFFTL_GC_COST_BENEFIT, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, NULL },
    /* 3. over-provisioning sweep (uniform random, greedy) */
    { "uniform OP 15%", &DEV_B, PAT_UNIFORM, 0, 0, 4.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 150, 1, 0, NULL },
    { "uniform OP 25%", &DEV_B, PAT_UNIFORM, 0, 0, 4.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 250, 1, 0, NULL },
    { "uniform OP 40%", &DEV_B, PAT_UNIFORM, 0, 0, 4.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 400, 1, 0, NULL },
    /* 4. wear levelling: long skewed run */
    { "WL none, 90/10 x20",       &DEV_B, PAT_HOTCOLD, 90, 10, 20.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_NONE,           70, 1, 0, "wl_none" },
    { "WL dynamic, 90/10 x20",    &DEV_B, PAT_HOTCOLD, 90, 10, 20.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC,        70, 1, 0, "wl_dynamic" },
    { "WL dyn+static, 90/10 x20", &DEV_B, PAT_HOTCOLD, 90, 10, 20.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, "wl_static" },
    /* 5. the StorageCore P51 device (the RTL target geometry) */
    { "P51 uniform random",  &DEV_P51, PAT_UNIFORM, 0, 0,   8.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, "p51" },
    { "P51 hot/cold 90/10",  &DEV_P51, PAT_HOTCOLD, 90, 10, 8.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 0, NULL },
    { "P51 uniform, ckpt every 64 blk", &DEV_P51, PAT_UNIFORM, 0, 0, 8.0, 0, SFFTL_GC_GREEDY, SFFTL_WL_DYNAMIC_STATIC, 70, 1, 64, NULL },
  };
  const size_t nruns = sizeof(runs) / sizeof(runs[0]);
  res_t res[sizeof(runs) / sizeof(runs[0])];
  const char *only = argc > 2 ? argv[2] : NULL;          /* optional: run only names containing this */
  for (size_t i = 0; i < nruns; i++) {
    const run_t *r = &runs[i];
    if (only && !strstr(r->name, only)) { memset(&res[i], 0, sizeof(res[i])); continue; }
    fprintf(stderr, "bench: %s ...\n", r->name);
    run(r, dir, &res[i]);
    const res_t *o = &res[i];
    fprintf(csv, "\"%s\",\"%s\",%s,%u,%s,%s,%.1f,%.1f,%.3f,%.3f,%.3f,%.4f,%.3f,%" PRIu64 ",%" PRIu64 ",%" PRIu64 ",%u,%u,%.2f,%.2f,%u,%u,%.2f,"
                 "%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%.0f,%u\n",
            r->name, r->dev->name, r->pattern == PAT_SEQ ? "seq" : r->pattern == PAT_UNIFORM ? "uniform" : "hotcold",
            r->op_permille, gcn(r->gc), wln(r->wl), o->host_bytes / 1048576.0, o->phys_bytes / 1048576.0, o->wa_total, o->wa_nometa,
            o->reloc_per_host, o->meta_share, o->gc_time_share, o->erases, o->victims, o->ckpts, o->ec_min, o->ec_max, o->ec_mean,
            o->ec_sd, o->dev_ec_min, o->dev_ec_max, o->dev_ec_sd, o->w_p50, o->w_p99, o->w_p999, o->w_max, o->r_p50, o->r_p99,
            o->r_max, o->enospc);
  }
  /* ---- tables */
  fprintf(md, "## 1. Write amplification and GC overhead\n\n"
              "WA = physical bytes programmed / logical bytes written by the host (after preconditioning). "
              "`reloc/host` = pages moved by GC per host page. `meta` = share of programs that are metadata "
              "(checkpoints + journal). `GC time` = share of modelled device time spent on relocation reads, "
              "relocation programs and erases.\n\n"
              "| run | device | OP | GC | host MiB | phys MiB | WA | WA w/o meta | reloc/host | meta | GC time | erases | ckpts |\n"
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|\n");
  for (size_t i = 0; i < nruns; i++) {
    const run_t *r = &runs[i]; const res_t *o = &res[i];
    if (r->wl != SFFTL_WL_DYNAMIC_STATIC) continue;
    fprintf(md, "| %s | %s | %.1f%% | %s | %.1f | %.1f | **%.2f** | %.2f | %.2f | %.1f%% | %.0f%% | %" PRIu64 " | %" PRIu64 " |\n",
            r->name, r->dev == &DEV_B ? "bench" : "P51", r->op_permille / 10.0, gcn(r->gc), o->host_bytes / 1048576.0,
            o->phys_bytes / 1048576.0, o->wa_total, o->wa_nometa, o->reloc_per_host, 100 * o->meta_share, 100 * o->gc_time_share,
            o->erases, o->ckpts);
  }
  fprintf(md, "\n## 2. Erase-count distribution (wear levelling)\n\n"
              "Data blocks only (metadata and bad blocks excluded). `FTL` = the FTL's own counters; `device` = ground "
              "truth from the simulated device. Workload: preconditioning fill, then 20x the capacity in single-page "
              "writes, 90 %% of them to 10 %% of the LBAs (the rest of the data is cold).\n\n"
              "| policy | FTL EC min | max | mean | std-dev | device EC min | max | std-dev | max/mean | WA |\n|---|---|---|---|---|---|---|---|---|---|\n");
  for (size_t i = 0; i < nruns; i++) {
    const run_t *r = &runs[i]; const res_t *o = &res[i];
    if (strncmp(r->name, "WL ", 3)) continue;
    fprintf(md, "| %s | %u | %u | %.1f | %.2f | %u | %u | %.2f | %.2f | %.2f |\n", wln(r->wl), o->ec_min, o->ec_max, o->ec_mean, o->ec_sd,
            o->dev_ec_min, o->dev_ec_max, o->dev_ec_sd, o->ec_max / o->ec_mean, o->wa_total);
  }
  fprintf(md, "\n## 3. Command latency (modelled device time per synchronous call)\n\n"
              "| run | write p50 us | p99 | p99.9 | max | read p50 us | p99 | max |\n|---|---|---|---|---|---|---|---|\n");
  for (size_t i = 0; i < nruns; i++) {
    const run_t *r = &runs[i]; const res_t *o = &res[i];
    if (r->wl != SFFTL_WL_DYNAMIC_STATIC) continue;
    fprintf(md, "| %s | %.0f | %.0f | %.0f | %.0f | %s%.0f | %.0f | %.0f |\n", r->name, o->w_p50, o->w_p99, o->w_p999, o->w_max,
            r->read_pct ? "" : "(no reads) ", o->r_p50, o->r_p99, o->r_max);
  }
  /* ---- mapping memory */
  fprintf(md, "\n## 4. Mapping memory (sfftl_mem_required)\n\n"
              "The arena holds the L2P table (4 B per logical page), the valid-page bitmap (1 bit per physical page), "
              "the block table (16 B per block), three page buffers, the journal queue and the mount scratch area. "
              "Instance struct: %zu B. The ControlCore DMEM is 32 KiB.\n\n"
              "| device | physical pages | logical pages | metadata blocks | L2P | bitmap | block table | buffers+journal+scratch | arena total | per GiB of NAND |\n"
              "|---|---|---|---|---|---|---|---|---|---|\n", sizeof(sfftl_t));
  struct { const char *n; uint32_t page, ppb, blocks, lba; } mem[] = {
    { "P51 model 512 B x 16 x 64", 512, 16, 64, 512 },
    { "NANDLab slc_tiny-like 512 B x 16 x 128", 512, 16, 128, 512 },
    { "bench 4 KiB x 64 x 256", 4096, 64, 256, 4096 },
    { "1 GiB: 4 KiB x 64 x 4096", 4096, 64, 4096, 4096 },
    { "16 GiB: 16 KiB x 256 x 4096", 16384, 256, 4096, 4096 },
  };
  for (size_t i = 0; i < sizeof(mem) / sizeof(mem[0]); i++) {
    sfftl_geom_t g; hx_geom(&g, mem[i].page, mem[i].ppb, mem[i].blocks);
    sfftl_cfg_t c; sfftl_cfg_default(&c); c.lba_bytes = mem[i].lba;
    sfftl_layout_t L;
    if (sfftl_layout_info(&g, &c, &L)) continue;
    double gib = (double)mem[i].page * mem[i].ppb * mem[i].blocks / 1073741824.0;
    fprintf(md, "| %s | %u | %u | %u | %.1f KiB | %.1f KiB | %.1f KiB | %.1f KiB | **%.1f KiB** | %.1f KiB |\n", mem[i].n,
            g.blocks * g.pages_per_block, L.nlpn_max, L.meta_blocks, L.l2p_bytes / 1024.0, L.vbm_bytes / 1024.0,
            L.blk_bytes / 1024.0, (L.buf_bytes + L.journal_bytes + L.scratch_bytes) / 1024.0, L.total_bytes / 1024.0,
            L.total_bytes / 1024.0 / gib);
  }
  /* ---- mount cost */
  fprintf(md, "\n## 5. Mount cost\n\nDevice operations of `sfftl_mount()` only (marker reads, metadata zone scan, checkpoint load, "
              "journal, roll-forward scan, and after an unclean shutdown the new checkpoint).\n\n"
              "| device | case | device ops | modelled time | data pages scanned | pages replayed |\n|---|---|---|---|---|---|\n");
  const dev_t2 *mdev[2] = { &DEV_P51, &DEV_B };
  for (int d = 0; d < 2; d++) {
    sfftl_geom_t g; hx_geom(&g, mdev[d]->page, mdev[d]->ppb, mdev[d]->blocks);
    sfftl_cfg_t c; sfftl_cfg_default(&c); c.lba_bytes = mdev[d]->lba;
    hx_t h;
    if (hx_init(&h, &g, &c, NULL, 99)) return 1;
    uint64_t nlba = hx_nlba(&h);
    for (uint64_t l = 0; l < nlba; l++) hx_write(&h, l, 1);
    for (uint64_t i = 0; i < nlba; i++) hx_write(&h, hx_rand(&h) % nlba, 1);
    for (int k = 0; k < 2; k++) {
      if (k == 0) sfftl_shutdown(&h.ftl); else { for (uint64_t i = 0; i < nlba / 3; i++) hx_write(&h, hx_rand(&h) % nlba, 1); simnand_power_off(h.nand); simnand_power_on(h.nand); }
      uint64_t op0 = simnand_ops(h.nand), t0 = simnand_stats(h.nand)->time_ns;
      int rc = sfftl_mount(&h.ftl, &h.g, &h.cfg, &h.hal, h.arena, h.arena_bytes);
      uint64_t ops = simnand_ops(h.nand) - op0, tns = simnand_stats(h.nand)->time_ns - t0;
      if (rc || hx_verify_all(&h)) { fprintf(stderr, "mount bench failed\n"); return 1; }
      const sfftl_stats_t *ms = sfftl_stats(&h.ftl);
      fprintf(md, "| %s | %s | %" PRIu64 " | %.1f ms | %u | %u |\n", mdev[d]->name,
              k ? "unclean: power lost after 1/3 x capacity of random writes" : "clean shutdown", ops, tns / 1e6,
              ms->last_mount_pages_scanned, ms->last_mount_pages_replayed);
    }
    hx_free(&h);
  }
  fclose(md);
  fclose(csv);
  fprintf(stderr, "bench: done -> %s/PERF.md\n", dir);
  return 0;
}
