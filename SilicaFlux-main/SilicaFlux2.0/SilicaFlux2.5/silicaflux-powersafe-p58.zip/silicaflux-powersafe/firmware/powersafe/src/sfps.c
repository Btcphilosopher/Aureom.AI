/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- firmware layer (see include/sfps.h)
 * ===========================================================================*/
#include "sfps.h"

#if defined(__STDC_HOSTED__) && __STDC_HOSTED__
#include <string.h>
#else
void *memset(void *d, int c, size_t n);
#endif

/* the FTL event ids are the controller's crash-point ids */
typedef char sfps_ev_ids_match[(SFFTL_EV_PRE_PROGRAM == SFPR_CP_PRE_PROGRAM && SFFTL_EV_IN_PROGRAM == SFPR_CP_IN_PROGRAM &&
                                SFFTL_EV_POST_PROGRAM == SFPR_CP_POST_PROGRAM && SFFTL_EV_PRE_MAP == SFPR_CP_PRE_MAP &&
                                SFFTL_EV_PRE_JOURNAL == SFPR_CP_PRE_JOURNAL && SFFTL_EV_IN_JOURNAL == SFPR_CP_IN_JOURNAL &&
                                SFFTL_EV_GC_POST_COPY == SFPR_CP_GC_POST_COPY && SFFTL_EV_GC_IN_COPY == SFPR_CP_GC_IN_COPY &&
                                SFFTL_EV_GC_PRE_ERASE == SFPR_CP_GC_PRE_ERASE && SFFTL_EV_IN_ERASE == SFPR_CP_IN_ERASE &&
                                SFFTL_EV_CKPT_BODY == SFPR_CP_CKPT_BODY && SFFTL_EV_CKPT_PRE_COMMIT == SFPR_CP_CKPT_PRE_COMMIT &&
                                SFFTL_EV_CKPT_IN_COMMIT == SFPR_CP_CKPT_IN_COMMIT &&
                                SFFTL_EV_CKPT_POST_COMMIT == SFPR_CP_CKPT_POST_COMMIT &&
                                SFFTL_EV_MOUNT_SCAN == SFPR_CP_MOUNT_SCAN && SFFTL_EV_MOUNT_CKPT == SFPR_CP_MOUNT_CKPT &&
                                SFFTL_EV_TRIM_PRE_UNMAP == SFPR_CP_TRIM_PRE_UNMAP &&
                                SFFTL_EV_WL_POST_COPY == SFPR_CP_WL_POST_COPY && SFFTL_EV_META_ERASE == SFPR_CP_META_ERASE &&
                                SFFTL_EV_POST_MAP == SFPR_CP_POST_MAP) ? 1 : -1];

static uint32_t rd(sfps_t *p, uint32_t off) { return p->bus.rd(p->bus.ctx, off); }
static void wr(sfps_t *p, uint32_t off, uint32_t v) { p->bus.wr(p->bus.ctx, off, v); }

void sfps_cfg_default(sfps_cfg_t *c) {
  memset(c, 0, sizeof(*c));
  c->forward_events = 1;
  c->pf_mode = SFPR_PF_MODE_STOP;
  c->pf_budget = 2;                /* DIAG worst case: one ring erase + one journal page */
  c->remount_on_restore = 1;
  c->ack_durable_on_pf = 1;
}

/* ---------------------------------------------------------------- phases */
/* in-flight policy: once a power fault was signalled the controller's sweep owns
 * every outstanding tag (DURABLE -> SUCCESS, anything else -> ABORT_PWR_LOSS);
 * the firmware reports nothing more for it */
static int pf_owned(const sfps_t *p) {
  return p->pf_pending || (p->mounted && (p->f->ps_warned || sfftl_ps_state(p->f) != SFFTL_PS_RUNNING));
}

static void phase_to(sfps_t *p, uint32_t target) {
  if (p->cur_tag < 0 || pf_owned(p)) return;
  while (p->cur_phase < target) {
    uint32_t nx;
    if (p->cur_kind == SFPR_KIND_FLUSH) nx = SFPR_PHASE_DURABLE;
    else if (p->cur_kind == SFPR_KIND_TRIM && p->cur_phase == SFPR_PHASE_ACCEPTED) nx = SFPR_PHASE_PROGRAMMED;
    else nx = p->cur_phase + 1u;
    if (p->cur_kind == SFPR_KIND_READ || p->cur_kind == SFPR_KIND_ADMIN) nx = target;
    wr(p, SFPR_PHASE_EV, SFPR_FLD(PHASE_EV, TAG, (uint32_t)p->cur_tag) | SFPR_FLD(PHASE_EV, PHASE, nx));
    p->cur_phase = nx;
  }
}

/* ---------------------------------------------------------------- FTL event hook */
static void evt(void *ctx, uint32_t ev, uint32_t arg) {
  sfps_t *p = (sfps_t *)ctx;
  if (p->observer) p->observer(p->octx, ev, arg);
  p->tel.events++;
  p->tel.ev_count[ev & 31u]++;
  if (p->cfg.forward_events) {
    uint32_t tag = p->cur_tag >= 0 ? (uint32_t)p->cur_tag : 0xFFu;
    wr(p, SFPR_CP_EVENT, SFPR_FLD(CP_EVENT, POINT, ev) | SFPR_FLD(CP_EVENT, TAG, tag));
    p->tel.events_forwarded++;
  }
  /* command-level persistence phases: a multi-page write reaches a phase when
   * its last logical page does (pages are processed strictly in order) */
  if (p->cur_tag >= 0 && p->cur_kind == SFPR_KIND_WRITE && arg == p->cur_last) {
    if (ev == SFFTL_EV_POST_PROGRAM) phase_to(p, SFPR_PHASE_PROGRAMMED);
    else if (ev == SFFTL_EV_PRE_MAP) phase_to(p, SFPR_PHASE_VERIFIED);
    else if (ev == SFFTL_EV_POST_MAP) phase_to(p, SFPR_PHASE_MAPPED);
  } else if (p->cur_tag >= 0 && p->cur_kind == SFPR_KIND_TRIM && ev == SFFTL_EV_TRIM_PRE_UNMAP) {
    phase_to(p, SFPR_PHASE_VERIFIED);          /* journal page programmed, status PASS */
  }
  /* interrupt delivery between FTL steps */
  if (p->bus.irq && p->bus.irq(p->bus.ctx)) sfps_isr(p);
}

int sfps_init(sfps_t *p, const sfps_bus_t *bus, const sfps_cfg_t *cfg, sfftl_t *f, const sfftl_geom_t *g,
              const sfftl_cfg_t *fcfg, const sfftl_hal_t *hal, void *arena, size_t arena_bytes) {
  memset(p, 0, sizeof(*p));
  p->bus = *bus;
  p->cfg = *cfg;
  p->f = f;
  p->g = *g;
  p->fcfg = *fcfg;
  p->fcfg.evt = evt;
  p->fcfg.evt_ctx = p;
  p->hal = *hal;
  p->arena = arena;
  p->arena_bytes = arena_bytes;
  p->cur_tag = -1;
  return rd(p, SFPR_ID) == SFPR_ID_VALUE ? 0 : -1;
}

static void configure(sfps_t *p) {
  uint32_t c = SFPR_CFG_RST & ~(SFPR_CFG_PF_MODE_MASK << SFPR_CFG_PF_MODE_LSB) & ~(SFPR_CFG_PF_BUDGET_MASK << SFPR_CFG_PF_BUDGET_LSB);
  c &= ~((1u << SFPR_CFG_REMOUNT_ON_RESTORE_LSB) | (1u << SFPR_CFG_ACK_DURABLE_ON_PF_LSB) | (1u << SFPR_CFG_PLP_QUAL_LSB));
  c |= SFPR_FLD(CFG, PF_MODE, p->cfg.pf_mode) | SFPR_FLD(CFG, PF_BUDGET, p->cfg.pf_budget);
  c |= SFPR_FLD(CFG, REMOUNT_ON_RESTORE, p->cfg.remount_on_restore ? 1u : 0u);
  c |= SFPR_FLD(CFG, ACK_DURABLE_ON_PF, p->cfg.ack_durable_on_pf ? 1u : 0u);
  c |= SFPR_FLD(CFG, WCE, p->cfg.wce ? 1u : 0u);
  wr(p, SFPR_CFG, c);
  if (p->cfg.recov_tmo) wr(p, SFPR_RECOV_TMO, p->cfg.recov_tmo);
  if (p->cfg.drain_tmo) wr(p, SFPR_DRAIN_TMO, p->cfg.drain_tmo);
  wr(p, SFPR_IRQ_EN, (1u << SFPR_IRQ_STATUS_PF_LSB) | (1u << SFPR_IRQ_STATUS_RESTORE_LSB));
}

static void publish_commit(sfps_t *p) {
  uint64_t s = p->f->next_seq - 1u;
  wr(p, SFPR_COMMIT_SEQ_LO, (uint32_t)s);
  wr(p, SFPR_COMMIT_SEQ_HI, (uint32_t)(s >> 32));
  wr(p, SFPR_CKPT_GEN, p->f->gen);
}

static void recovery_done(sfps_t *p, uint32_t result) {
  wr(p, SFPR_ACT, 0);
  wr(p, SFPR_CTRL, SFPR_FLD(CTRL, RECOVERY_DONE, 1u) | SFPR_FLD(CTRL, RESULT, result));
}

int sfps_format(sfps_t *p) {
  p->tel.boots++;
  configure(p);
  int rc = sfftl_format(p->f, &p->g, &p->fcfg, &p->hal, p->arena, p->arena_bytes);
  p->mounted = rc == SFFTL_OK;
  if (p->mounted) publish_commit(p);
  recovery_done(p, p->mounted ? 0u : 2u);
  return rc;
}

int sfps_boot(sfps_t *p) {
  p->tel.boots++;
  p->mounted = 0;
  p->cur_tag = -1;
  p->pf_pending = 0;
  /* interrupt status may hold events the previous firmware never serviced (it was reset first): they
   * are history -- RET_* carries it -- not work for this boot */
  wr(p, SFPR_IRQ_STATUS, 0xFFFFFFFFu);
  configure(p);
  p->tel.last_cause = rd(p, SFPR_RET_CAUSE);
  p->tel.last_ret_flags = rd(p, SFPR_RET_FLAGS);
  uint64_t retained = (uint64_t)rd(p, SFPR_COMMIT_SEQ_LO) | ((uint64_t)rd(p, SFPR_COMMIT_SEQ_HI) << 32);
  wr(p, SFPR_ACT, SFPR_FLD(ACT, MOUNT, 1u));
  int rc = sfftl_mount(p->f, &p->g, &p->fcfg, &p->hal, p->arena, p->arena_bytes);
  p->tel.last_mount_rc = rc;
  if (rc < 0) {
    p->tel.mount_failed++;
    recovery_done(p, 2u);                       /* FAILED: host sees a fatal controller */
    return rc;
  }
  p->mounted = 1;
  p->degraded = 0;
  const sfftl_stats_t *st = sfftl_stats(p->f);
  if (st->last_mount_kind == 0) p->tel.mounts_clean++;
  else if (st->last_mount_kind == 1) p->tel.mounts_unclean++;
  else p->tel.mounts_rebuild++;
  /* persistent commit status: the recovered medium must reach at least the
   * durable commit point the controller retained across the reset */
  if (retained) {
    p->tel.retained_seq_checks++;
    if (p->f->next_seq - 1u < retained) p->tel.retained_seq_violations++;
  }
  sfftl_space_t sp;
  sfftl_space(p->f, &sp);
  uint32_t result = sp.read_only ? 1u : 0u;
  if (sp.read_only) p->degraded = 1;
  if (!sp.read_only) {
    if (st->last_mount_kind != 0) {
      /* durable recovery record: cause, mount kind, rejected checkpoints, replayed pages */
      uint32_t info = (p->tel.last_cause & 0x7Fu) | ((st->last_mount_kind & 3u) << 8) |
                      ((st->last_mount_ckpt_rejected & 0xFu) << 12) |
                      ((st->last_mount_pages_replayed > 0xFFFFu ? 0xFFFFu : st->last_mount_pages_replayed) << 16);
      int lr = sfftl_log_recovery(p->f, info);
      if (lr == SFFTL_OK) p->tel.recovery_records++;
      else if (lr == SFFTL_EROFS) result = 1u;
    }
    publish_commit(p);
  } else {
    p->tel.mount_ro++;
  }
  recovery_done(p, result);
  return rc;
}

uint32_t sfps_state(sfps_t *p) { return SFPR_GET(rd(p, SFPR_STATE), STATE, FSM); }
const sfps_tel_t *sfps_telemetry(const sfps_t *p) { return &p->tel; }

/* ---------------------------------------------------------------- admission / completion */
int sfps_submit(sfps_t *p, uint32_t kind, uint32_t fua, uint32_t *status) {
  wr(p, SFPR_CMD_SUBMIT, SFPR_FLD(CMD_SUBMIT, KIND, kind) | SFPR_FLD(CMD_SUBMIT, FUA, fua ? 1u : 0u));
  uint32_t r = rd(p, SFPR_CMD_RESULT);
  p->tel.cmds++;
  if (SFPR_GET(r, CMD_RESULT, ACCEPTED)) return (int)SFPR_GET(r, CMD_RESULT, TAG);
  p->tel.rejected++;
  if (status) *status = SFPR_GET(r, CMD_RESULT, NO_TAG) ? SFPS_ST_ABORT_RESET : SFPR_GET(r, CMD_RESULT, STATUS);
  return -1;
}

static uint32_t complete(sfps_t *p, int tag, uint32_t status) {
  for (uint32_t tries = 0; tries < 64u; tries++) {
    wr(p, SFPR_CPL_REQ, SFPR_FLD(CPL_REQ, TAG, (uint32_t)tag) | SFPR_FLD(CPL_REQ, STATUS, status));
    uint32_t r = rd(p, SFPR_CPL_RESULT);
    if (SFPR_GET(r, CPL_RESULT, RELEASED)) {
      if (status == SFPS_ST_SUCCESS) p->tel.cpl_success++; else p->tel.cpl_error++;
      return status;
    }
    if (SFPR_GET(r, CPL_RESULT, REFUSED)) { p->tel.cpl_refused++; return 0xFFu; }
    p->tel.cpl_busy_retries++;
  }
  return 0xFEu;
}

static uint32_t status_of(int rc, int is_write) {
  switch (rc) {
    case SFFTL_OK:     return SFPS_ST_SUCCESS;
    case SFFTL_ERANGE: return SFPS_ST_LBA_RANGE;
    case SFFTL_ENOSPC: return SFPS_ST_CAPACITY;
    case SFFTL_EROFS:  return SFPS_ST_WRITE_PROT;
    case SFFTL_EPOWER: return SFPS_ST_ABORT_PWR_LOSS;
    case SFFTL_EIO:    return is_write ? SFPS_ST_MEDIA_WRITE : SFPS_ST_MEDIA_UNREC;
    default:           return SFPS_ST_INTERNAL_ERR;
  }
}

static void begin(sfps_t *p, int tag, uint32_t kind, uint64_t lba, uint32_t nlb) {
  p->cur_tag = tag;
  p->cur_kind = kind;
  p->cur_phase = SFPR_PHASE_ACCEPTED;
  if (nlb && p->mounted) {
    p->cur_first = (uint32_t)(lba >> p->f->spp_shift);
    p->cur_last = (uint32_t)((lba + nlb - 1u) >> p->f->spp_shift);
  } else {
    p->cur_first = p->cur_last = 0xFFFFFFFFu;
  }
}

/* the FTL degraded to read-only (worn out / metadata zone exhausted): tell the
 * controller, which then rejects WRITE / TRIM at admission and reports RO */
static void track_degradation(sfps_t *p) {
  if (!p->mounted || p->degraded) return;
  sfftl_space_t sp;
  sfftl_space(p->f, &sp);
  if (sp.read_only) {
    p->degraded = 1;
    wr(p, SFPR_CTRL, SFPR_FLD(CTRL, READ_ONLY, 1u));
  }
}

static uint32_t finish(sfps_t *p, int tag, int rc, int durable_kind) {
  uint32_t st = status_of(rc, durable_kind);
  track_degradation(p);
  if (rc == SFFTL_OK && durable_kind) {
    phase_to(p, SFPR_PHASE_DURABLE);
    publish_commit(p);
  }
  /* crash point PRE_COMPLETION: the command is durable, its completion not yet posted */
  evt(p, SFPR_CP_PRE_COMPLETION, (uint32_t)tag);
  p->cur_tag = -1;
  if (pf_owned(p)) return SFPS_ST_ABORT_PWR_LOSS;      /* the controller's sweep completes it */
  return complete(p, tag, st);
}

uint32_t sfps_write(sfps_t *p, int tag, uint64_t lba, uint32_t nlb, const void *buf, uint32_t fua) {
  (void)fua;
  p->tel.writes++;
  begin(p, tag, SFPR_KIND_WRITE, lba, nlb);
  phase_to(p, SFPR_PHASE_BUFFERED);             /* host data is in controller memory */
  if (p->cfg.bug_ack_before_durable && !pf_owned(p)) (void)complete(p, tag, SFPS_ST_SUCCESS);   /* must be refused */
  int rc = p->mounted ? sfftl_write(p->f, lba, nlb, buf) : SFFTL_ESTATE;
  return finish(p, tag, rc, 1);
}

uint32_t sfps_read(sfps_t *p, int tag, uint64_t lba, uint32_t nlb, void *buf) {
  p->tel.reads++;
  begin(p, tag, SFPR_KIND_READ, lba, nlb);
  int rc = p->mounted ? sfftl_read(p->f, lba, nlb, buf) : SFFTL_ESTATE;
  return finish(p, tag, rc, 0);
}

uint32_t sfps_trim(sfps_t *p, int tag, uint64_t lba, uint32_t nlb) {
  p->tel.trims++;
  begin(p, tag, SFPR_KIND_TRIM, lba, nlb);
  int rc = p->mounted ? sfftl_trim(p->f, lba, nlb) : SFFTL_ESTATE;
  return finish(p, tag, rc, 1);
}

uint32_t sfps_flush(sfps_t *p, int tag) {
  p->tel.flushes++;
  begin(p, tag, SFPR_KIND_FLUSH, 0, 0);
  int rc = p->mounted ? sfftl_flush(p->f) : SFFTL_ESTATE;
  return finish(p, tag, rc, 1);
}

int sfps_background(sfps_t *p, uint32_t budget) {
  if (!p->mounted) return 0;
  int rc = sfftl_background(p->f, budget);
  track_degradation(p);
  return rc;
}

/* ---------------------------------------------------------------- power fault */
void sfps_isr(sfps_t *p) {
  uint32_t s = rd(p, SFPR_IRQ_STATUS);
  if (s & (1u << SFPR_IRQ_STATUS_PF_LSB)) {
    /* act only while the fault is current: a PF event the controller already resolved (through a
     * reset / remount) must not put this firmware instance into power-fail mode */
    uint32_t st = sfps_state(p);
    if (st == SFPR_STATE_PF_DRAIN || st == SFPR_STATE_PF_SAFE || st == SFPR_STATE_PF_RESTORE) {
      p->pf_pending = 1;
      if (p->mounted) sfftl_ps_warn(p->f);     /* the FTL stops at its next page boundary */
    }
  }
  wr(p, SFPR_IRQ_STATUS, s);
}

int sfps_service(sfps_t *p) {
  if (!p->pf_pending) return 0;
  p->pf_pending = 0;
  p->tel.pf_handled++;
  if (p->mounted) {
    if (p->cfg.pf_mode == SFPR_PF_MODE_DIAG) {
      /* best effort: the controller's fault snapshot in one journal page; a tear
       * is harmless (CRC) and it carries no acknowledged data.  PF_ACK opens the
       * controller's program budget for exactly this (normal work is stopped) */
      wr(p, SFPR_CTRL, SFPR_FLD(CTRL, PF_ACK, 1u));
      sfftl_ps_set_diag(p->f, rd(p, SFPR_RET_PF_SNAP));
      p->tel.pf_diag_queued++;
      (void)sfftl_ps_power_fail(p->f, SFFTL_PS_FLUSH_JOURNAL);
    } else {
      (void)sfftl_ps_power_fail(p->f, 0);         /* STOP: nothing is written after the fault */
    }
  }
  wr(p, SFPR_CTRL, SFPR_FLD(CTRL, FW_SAFE, 1u));
  return 1;
}

int sfps_poll(sfps_t *p) {
  if (p->bus.irq && p->bus.irq(p->bus.ctx)) sfps_isr(p);
  return sfps_service(p);
}

int sfps_resume(sfps_t *p) {
  (void)sfps_poll(p);                           /* a power-fault interrupt still pending is handled first */
  if (p->mounted) (void)sfftl_ps_power_restored(p->f);
  wr(p, SFPR_CTRL, SFPR_FLD(CTRL, RESUME, 1u));
  p->tel.restores_resumed++;
  return 0;
}

int sfps_shutdown(sfps_t *p) {
  int rc = p->mounted ? sfftl_shutdown(p->f) : SFFTL_ESTATE;
  if (rc == SFFTL_OK) wr(p, SFPR_CTRL, SFPR_FLD(CTRL, SHUTDOWN_DONE, 1u));
  p->mounted = 0;
  return rc;
}
