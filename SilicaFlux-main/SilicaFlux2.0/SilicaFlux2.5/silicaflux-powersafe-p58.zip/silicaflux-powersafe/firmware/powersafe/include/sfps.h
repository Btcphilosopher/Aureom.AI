/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- firmware layer   Aureom.AI | SilicaFlux-STORE
 *
 * The ControlCore firmware half of the power-loss / recovery design.  It sits
 * between the host command path and the FlashMap FTL (P56, extended by P58)
 * and drives the silicaflux_storage_recovery controller (register page):
 *
 *   commands    admission through CMD_SUBMIT, execution on the FTL, persistence
 *               phases reported per tag (PHASE_EV), completion requested through
 *               the controller's acknowledgement gate (CPL_REQ).  A WRITE / TRIM /
 *               FLUSH is reported DURABLE only after the FTL returned OK, i.e.
 *               after its data pages (with spare records) or journal page are
 *               programmed and their status confirmed.
 *   events      every FTL persistence point (SFFTL_EV_*) is counted and, when
 *               enabled, forwarded to CP_EVENT (crash injection, telemetry).
 *   power fault interrupt -> sfftl_ps_warn(); main loop -> power-fault handler
 *               (policy STOP: nothing is written; DIAG: one journal page with the
 *               controller's fault snapshot) -> FW_SAFE.
 *   recovery    boot: read retained diagnostics, mount (roll-forward), check the
 *               retained commit status, write a durable recovery record after an
 *               unclean shutdown, RECOVERY_DONE with OK / READ_ONLY / FAILED.
 *
 * Freestanding C99: no malloc, no libc beyond the FTL's needs.  Register access
 * goes through sfps_bus_t (MMIO on the ControlCore; the Verilator model in the
 * co-simulation).
 * ===========================================================================*/
#ifndef SFPS_H
#define SFPS_H

#include <stdint.h>
#include <stddef.h>
#include "sfftl.h"
#include "sfftl_powersafe.h"
#include "generated/sfpr_regs.h"

#define SFPS_VERSION 0x00580100u

typedef struct {
  uint32_t (*rd)(void *ctx, uint32_t off);
  void     (*wr)(void *ctx, uint32_t off, uint32_t v);
  int      (*irq)(void *ctx);          /* optional: interrupt line level (polled between FTL steps) */
  void *ctx;
} sfps_bus_t;

typedef struct {
  uint32_t forward_events;       /* write every FTL event to CP_EVENT                         */
  uint32_t pf_mode;              /* SFPR_PF_MODE_STOP (default) / DIAG                         */
  uint32_t pf_budget;            /* DIAG: program/erase ops allowed after the fault            */
  uint32_t remount_on_restore;   /* brown-out restore: reset + recovery (default) or resume    */
  uint32_t wce;                  /* host volatile write cache: early acknowledgement at BUFFERED */
  uint32_t recov_tmo, drain_tmo; /* controller timeouts in cycles (0 = none / default)        */
  uint32_t ack_durable_on_pf;    /* PF sweep completes DURABLE tags with SUCCESS               */
  uint32_t bug_ack_before_durable;  /* fault injection into the firmware itself: request SUCCESS
                                       before the FTL ran; the controller's gate must refuse it */
} sfps_cfg_t;

typedef struct {
  uint64_t cmds, writes, reads, trims, flushes;
  uint64_t cpl_success, cpl_error, cpl_refused, cpl_busy_retries, rejected;
  uint64_t events, events_forwarded;
  uint32_t ev_count[32];          /* per event / crash-point id                                */
  uint32_t boots, mounts_clean, mounts_unclean, mounts_rebuild, mount_failed, mount_ro;
  int32_t  last_mount_rc;
  uint32_t last_cause, last_ret_flags;
  uint64_t retained_seq_checks, retained_seq_violations;
  uint32_t pf_handled, pf_diag_queued, restores_resumed;
  uint32_t recovery_records;
} sfps_tel_t;

typedef struct {
  sfps_bus_t   bus;
  sfps_cfg_t   cfg;
  sfftl_t     *f;
  sfftl_geom_t g;
  sfftl_cfg_t  fcfg;
  sfftl_hal_t  hal;
  void        *arena;
  size_t       arena_bytes;
  int          mounted;
  int          degraded;         /* the FTL turned read-only; the controller was told (RUN_RO) */
  /* command in execution (the firmware runs one at a time) */
  int32_t      cur_tag;
  uint32_t     cur_kind, cur_first, cur_last, cur_phase;
  volatile int pf_pending;
  sfps_tel_t   tel;
  /* optional observer of every FTL event (verification only; NULL in firmware) */
  void       (*observer)(void *octx, uint32_t ev, uint32_t arg);
  void        *octx;
} sfps_t;

/* status codes returned to the host (P51 sfs_status_e values) */
#define SFPS_ST_SUCCESS        0x00u
#define SFPS_ST_DATA_XFER_ERR  0x04u
#define SFPS_ST_ABORT_PWR_LOSS 0x05u
#define SFPS_ST_INTERNAL_ERR   0x06u
#define SFPS_ST_ABORT_RESET    0x07u
#define SFPS_ST_LBA_RANGE      0x08u
#define SFPS_ST_CAPACITY       0x09u
#define SFPS_ST_MEDIA_UNREC    0x10u
#define SFPS_ST_MEDIA_WRITE    0x11u
#define SFPS_ST_WRITE_PROT     0x14u

void sfps_cfg_default(sfps_cfg_t *c);

/* bind the layer; installs the FTL event hook into fcfg (copied) */
int  sfps_init(sfps_t *p, const sfps_bus_t *bus, const sfps_cfg_t *cfg, sfftl_t *f, const sfftl_geom_t *g,
               const sfftl_cfg_t *fcfg, const sfftl_hal_t *hal, void *arena, size_t arena_bytes);

/* boot / recovery: call when the sub-reset is released (controller in RECOVERY).
 * Returns the sfftl mount status (also when the result reported is FAILED). */
int  sfps_boot(sfps_t *p);

/* first-time format (manufacturing): only in RECOVERY; then RECOVERY_DONE */
int  sfps_format(sfps_t *p);

/* admission: returns the tag (>= 0); < 0 when not admitted, *status = completion status */
int  sfps_submit(sfps_t *p, uint32_t kind, uint32_t fua, uint32_t *status);

/* execute an admitted command and complete it through the gate.  Returns the
 * status the firmware asked the controller to complete with. */
uint32_t sfps_write(sfps_t *p, int tag, uint64_t lba, uint32_t nlb, const void *buf, uint32_t fua);
uint32_t sfps_read(sfps_t *p, int tag, uint64_t lba, uint32_t nlb, void *buf);
uint32_t sfps_trim(sfps_t *p, int tag, uint64_t lba, uint32_t nlb);
uint32_t sfps_flush(sfps_t *p, int tag);

/* interrupt handler (ISR-safe: flags only) and main-loop service */
void sfps_isr(sfps_t *p);
int  sfps_service(sfps_t *p);      /* power-fault handling; returns 1 while in a power fault */
int  sfps_poll(sfps_t *p);         /* main loop: take a pending interrupt, then sfps_service() */
int  sfps_resume(sfps_t *p);       /* PF_RESTORE without remount: resume in place */
int  sfps_shutdown(sfps_t *p);     /* clean shutdown checkpoint + SHUTDOWN_DONE */
int  sfps_background(sfps_t *p, uint32_t budget);

/* helpers */
uint32_t sfps_state(sfps_t *p);    /* controller FSM state */
const sfps_tel_t *sfps_telemetry(const sfps_t *p);

#endif /* SFPS_H */
