/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- ControlCore MMIO binding of the register bus
 *
 * The controller's 4 KiB page is PROPOSED at the next free StorageCore page,
 * 0x4000B000 (P51 uses page 10 = 0x4000A000 for SYS).  It is not wired into the
 * P51 SoC in this project (docs/03 section 9); the address is a placeholder the
 * integration must confirm.  The interrupt line is the storage EVENT line.
 * ===========================================================================*/
#include "sfps.h"

#ifndef SFPR_BASE
#define SFPR_BASE 0x4000B000u
#endif

static uint32_t mmio_rd(void *ctx, uint32_t off) {
  (void)ctx;
  return *(volatile uint32_t *)(uintptr_t)(SFPR_BASE + off);
}

static void mmio_wr(void *ctx, uint32_t off, uint32_t v) {
  (void)ctx;
  *(volatile uint32_t *)(uintptr_t)(SFPR_BASE + off) = v;
}

static int mmio_irq(void *ctx) {
  (void)ctx;
  uint32_t st = *(volatile uint32_t *)(uintptr_t)(SFPR_BASE + SFPR_IRQ_STATUS);
  uint32_t en = *(volatile uint32_t *)(uintptr_t)(SFPR_BASE + SFPR_IRQ_EN);
  return (st & en) != 0;
}

void sfps_mmio_bus(sfps_bus_t *b) {
  b->rd = mmio_rd;
  b->wr = mmio_wr;
  b->irq = mmio_irq;
  b->ctx = 0;
}
