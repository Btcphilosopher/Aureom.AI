/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- recovery reference model (see rrm.h)
 * ===========================================================================*/
#include "rrm.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static uint64_t mix(uint64_t x) {
  x += 0x9E3779B97F4A7C15ull;
  x = (x ^ (x >> 30)) * 0xBF58476D1CE4E5B9ull;
  x = (x ^ (x >> 27)) * 0x94D049BB133111EBull;
  return x ^ (x >> 31);
}

int rrm_init(rrm_t *r, uint64_t nlba, uint32_t lba_bytes, uint32_t page_bytes) {
  memset(r, 0, sizeof(*r));
  r->nlba = nlba;
  r->lba_bytes = lba_bytes;
  r->spp = page_bytes / lba_bytes;
  r->acked = (uint32_t *)calloc((size_t)nlba, sizeof(uint32_t));
  r->next_ver = 1;
  return r->acked ? 0 : -1;
}

void rrm_free(rrm_t *r) { free(r->acked); r->acked = NULL; }

void rrm_fill(const rrm_t *r, uint64_t lba, uint32_t ver, uint8_t *out) {
  if (ver == 0) { memset(out, 0, r->lba_bytes); return; }
  uint64_t s = mix((lba << 32) ^ ver);
  for (uint32_t i = 0; i < r->lba_bytes; i += 8) {
    uint64_t v = (i == 0) ? (lba | 0x5800000000000000ull) : (i == 8) ? (uint64_t)ver : mix(s + i);
    memcpy(out + i, &v, 8);
  }
}

void rrm_begin_write(rrm_t *r, uint64_t lba, uint32_t n, uint8_t *data) {
  r->doubt = 1;
  r->d_lba = lba; r->d_n = n; r->d_ver = r->next_ver++;
  for (uint32_t i = 0; i < n; i++) rrm_fill(r, lba + i, r->d_ver, data + (size_t)i * r->lba_bytes);
}

void rrm_begin_trim(rrm_t *r, uint64_t lba, uint32_t n) {
  r->doubt = 1;
  r->d_lba = lba; r->d_n = n; r->d_ver = 0;
}

void rrm_ack(rrm_t *r) {
  if (!r->doubt) return;
  for (uint32_t i = 0; i < r->d_n; i++) r->acked[r->d_lba + i] = r->d_ver;
  r->doubt = 0;
  r->acks++;
}

void rrm_not_acked(rrm_t *r) { if (r->doubt) r->doubts++; }

static int in_doubt(const rrm_t *r, uint64_t l) { return r->doubt && l >= r->d_lba && l < r->d_lba + r->d_n; }

/* check one logical page; returns 0 ok, 1 violation.  Settles the doubt for the page. */
static int check_page(rrm_t *r, uint64_t first, uint32_t n, const uint8_t *buf, uint8_t *exp) {
  int any_doubt = 0, can_old = 1, can_new = 1;
  r->page_checks++;
  for (uint32_t i = 0; i < n; i++) {
    uint64_t l = first + i;
    const uint8_t *d = buf + (size_t)i * r->lba_bytes;
    r->lba_checks++;
    rrm_fill(r, l, r->acked[l], exp);
    int is_old = memcmp(d, exp, r->lba_bytes) == 0;
    if (!in_doubt(r, l)) {
      if (!is_old) {
        uint64_t hdr0, hdr1;
        memcpy(&hdr0, d, 8); memcpy(&hdr1, d + 8, 8);
        int zero = 1;
        for (uint32_t z = 0; z < r->lba_bytes; z++) if (d[z]) { zero = 0; break; }
        snprintf(r->why, sizeof(r->why), "LBA %llu: not its acknowledged version %u (no command in doubt there); found %s %llu "
                 "(doubt: %s LBA %llu+%u ver %u)", (unsigned long long)l, r->acked[l], zero ? "zeros" :
                 ((hdr0 & 0xFF00000000000000ull) == 0x5800000000000000ull ? "version" : "garbage"),
                 (unsigned long long)(zero ? 0 : hdr1), r->doubt ? "yes" : "no", (unsigned long long)r->d_lba, r->d_n, r->d_ver);
        return 1;
      }
      continue;
    }
    any_doubt = 1;
    rrm_fill(r, l, r->d_ver, exp);
    int is_new = memcmp(d, exp, r->lba_bytes) == 0;
    if (!is_old) can_old = 0;
    if (!is_new) can_new = 0;
    if (!is_old && !is_new) {
      snprintf(r->why, sizeof(r->why), "LBA %llu: neither acknowledged version %u nor in-doubt version %u",
               (unsigned long long)l, r->acked[l], r->d_ver);
      return 1;
    }
  }
  if (!any_doubt) return 0;
  if (!can_old && !can_new) {
    snprintf(r->why, sizeof(r->why), "logical page at LBA %llu torn: part old, part new", (unsigned long long)first);
    return 1;
  }
  if (can_old && can_new) r->resolved_both++;
  else if (can_new) r->resolved_new++;
  else r->resolved_old++;
  if (!can_old) {                                  /* new contents observed: they are durable now */
    for (uint32_t i = 0; i < n; i++) if (in_doubt(r, first + i)) r->acked[first + i] = r->d_ver;
  }
  return 0;
}

static int verify_range(rrm_t *r, uint64_t lba, uint64_t end, rrm_read_fn rd, void *ctx, uint8_t *scratch) {
  int bad = 0;
  uint8_t *exp = scratch + (size_t)r->spp * r->lba_bytes;
  lba -= lba % r->spp;
  for (; lba < end; lba += r->spp) {
    uint32_t n = (uint32_t)((r->nlba - lba < r->spp) ? r->nlba - lba : r->spp);
    if (rd(ctx, lba, n, scratch) != 0) {
      snprintf(r->why, sizeof(r->why), "read error at LBA %llu", (unsigned long long)lba);
      return -1;
    }
    if (check_page(r, lba, n, scratch, exp)) { if (!bad) { /* keep first why */ } bad++; if (bad > 0) return bad; }
  }
  return bad;
}

int rrm_verify_all(rrm_t *r, rrm_read_fn rd, void *ctx, uint8_t *scratch) {
  int bad = verify_range(r, 0, r->nlba, rd, ctx, scratch);
  if (bad == 0) r->doubt = 0;
  return bad;
}

int rrm_resolve(rrm_t *r, rrm_read_fn rd, void *ctx, uint8_t *scratch) {
  if (!r->doubt) return 0;
  int bad = verify_range(r, r->d_lba, r->d_lba + r->d_n, rd, ctx, scratch);
  if (bad == 0) r->doubt = 0;
  return bad;
}
