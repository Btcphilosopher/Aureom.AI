/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- crash-consistency and power-fault campaigns
 *
 * Every test runs the REAL firmware (FlashMap FTL + PowerSafe layer) against the
 * Verilator model of silicaflux_storage_recovery.sv and a persistent simulated
 * NAND.  The invariant checked after every recovery, for every LBA:
 *
 *   every write / TRIM the host saw complete with SUCCESS is present; a command
 *   that did not complete with SUCCESS left each logical page it touched either
 *   entirely old or entirely new; nothing else changed.
 *
 *   ./test_recovery [--quick] [--seed N] [filter]
 * ===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "hc.h"

static int g_quick;
static uint64_t g_seed = 58;
static uint64_t g_checks, g_fail_checks;
static int g_tfail;
static FILE *g_csv;

#define CHECK(c, ...) do { g_checks++; if (!(c)) { g_fail_checks++; g_tfail = 1; \
  printf("    CHECK FAILED %s:%d: ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); } } while (0)
#define Q(full, quick) (g_quick ? (quick) : (full))

static const char *CP_NAME[32];
static void init_names(void) {
  CP_NAME[SFPR_CP_PRE_PROGRAM] = "PRE_PROGRAM"; CP_NAME[SFPR_CP_IN_PROGRAM] = "IN_PROGRAM";
  CP_NAME[SFPR_CP_POST_PROGRAM] = "POST_PROGRAM"; CP_NAME[SFPR_CP_PRE_MAP] = "PRE_MAP";
  CP_NAME[SFPR_CP_PRE_JOURNAL] = "PRE_JOURNAL"; CP_NAME[SFPR_CP_IN_JOURNAL] = "IN_JOURNAL";
  CP_NAME[SFPR_CP_PRE_COMPLETION] = "PRE_COMPLETION"; CP_NAME[SFPR_CP_GC_POST_COPY] = "GC_POST_COPY";
  CP_NAME[SFPR_CP_GC_IN_COPY] = "GC_IN_COPY"; CP_NAME[SFPR_CP_GC_PRE_ERASE] = "GC_PRE_ERASE";
  CP_NAME[SFPR_CP_IN_ERASE] = "IN_ERASE"; CP_NAME[SFPR_CP_CKPT_BODY] = "CKPT_BODY";
  CP_NAME[SFPR_CP_CKPT_PRE_COMMIT] = "CKPT_PRE_COMMIT"; CP_NAME[SFPR_CP_CKPT_IN_COMMIT] = "CKPT_IN_COMMIT";
  CP_NAME[SFPR_CP_CKPT_POST_COMMIT] = "CKPT_POST_COMMIT"; CP_NAME[SFPR_CP_MOUNT_SCAN] = "MOUNT_SCAN";
  CP_NAME[SFPR_CP_MOUNT_CKPT] = "MOUNT_CKPT"; CP_NAME[SFPR_CP_TRIM_PRE_UNMAP] = "TRIM_PRE_UNMAP";
  CP_NAME[SFPR_CP_WL_POST_COPY] = "WL_POST_COPY"; CP_NAME[SFPR_CP_META_ERASE] = "META_ERASE";
  CP_NAME[SFPR_CP_POST_MAP] = "POST_MAP"; CP_NAME[SFPR_CP_NAND_OP] = "NAND_OP";
}
__attribute__((unused)) static int is_tear_point(uint32_t p) { return (SFPR_CP_TEAR_MASK >> p) & 1u; }

/* ---------------------------------------------------------------- configurations */
static sfftl_geom_t geom(uint32_t page, uint32_t ppb, uint32_t blocks) {
  sfftl_geom_t g;
  g.page_data_bytes = page;
  g.page_spare_bytes = page >= 2048u ? 64u : 16u;
  g.pages_per_block = ppb;
  g.blocks = blocks;
  return g;
}

/* the P51 device geometry FlashMap runs on in RTL: 64 blocks x 16 pages of 512 B */
static sfftl_geom_t p51_geom(void) { return geom(512, 16, 64); }

#define P58_FLAGS (SFFTL_F_VERIFY_READ_CRC | SFFTL_F_PACED_GC | SFFTL_F_DUAL_CKPT | SFFTL_F_JOURNAL_MIRROR | SFFTL_F_VERIFY_WRITE)

static sfftl_cfg_t p58_cfg(void) {
  sfftl_cfg_t c;
  sfftl_cfg_default(&c);
  c.flags = P58_FLAGS;
  c.wl_static_threshold = 3;          /* make static wear levelling happen in short runs */
  c.wl_static_interval = 4;
  return c;
}

static sfftl_cfg_t p56_cfg(void) {
  sfftl_cfg_t c;
  sfftl_cfg_default(&c);
  return c;
}

static sfps_cfg_t fw_cfg(void) {
  sfps_cfg_t c;
  sfps_cfg_default(&c);
  return c;
}

static simnand_cfg_t nand_cfg(const sfftl_geom_t *g) {
  simnand_cfg_t n;
  simnand_cfg_default(&n, g->page_data_bytes, g->pages_per_block, g->blocks);
  n.torn_pass_permille = 250;         /* a quarter of torn pages slip past ECC: only the CRC rejects them */
  return n;
}

/* ---------------------------------------------------------------- a run */
typedef struct {
  sfftl_geom_t g;
  sfftl_cfg_t fcfg;
  sfps_cfg_t pcfg;
  simnand_cfg_t ncfg;
  uint64_t seed;
  uint32_t ops;              /* workload length */
  uint32_t max_len;
  uint32_t pct_trim;
  uint32_t fill_first;       /* write every LBA once before the workload */
  /* crash */
  uint32_t point, count, action;    /* point 0 = none */
  uint32_t arm_at_op;        /* arm the unit before this op (0 = before the workload) */
} run_t;

typedef struct {
  int pass;
  int fired;
  uint64_t crashes;
  uint64_t ev_count[32];
  uint64_t nand_ops, acked, not_acked, rejected, ops;
  char why[512];
} result_t;

static void run_defaults(run_t *r) {
  memset(r, 0, sizeof(*r));
  r->g = p51_geom();
  r->fcfg = p58_cfg();
  r->pcfg = fw_cfg();
  r->ncfg = nand_cfg(&r->g);
  r->seed = g_seed;
  r->ops = 700;
  r->max_len = 12;
  r->pct_trim = 8;
}

static void fill_all(hc_t *h) {
  for (uint64_t l = 0; l < h->nlba && !h->failed;) {
    op_t o = { OP_WRITE, l, (uint32_t)((h->nlba - l) < 64u ? (h->nlba - l) : 64u), 0 };
    hc_exec(h, &o);
    l += o.n;
  }
}

static void run_one(const run_t *rp, result_t *res) {
  memset(res, 0, sizeof(*res));
  hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
  if (hc_init(h, &rp->g, &rp->fcfg, &rp->ncfg, &rp->pcfg, rp->seed) < 0) {
    snprintf(res->why, sizeof(res->why), "init: %s", h->why);
    free(h);
    return;
  }
  if (rp->pcfg.bug_ack_before_durable) h->err_ignore |= 1u;
  wl_t w;
  wl_init(&w, rp->seed * 31u + 7u, h->nlba, rp->max_len);
  w.pct_trim = rp->pct_trim;
  if (rp->fill_first) fill_all(h);
  uint64_t crash0 = h->crashes;
  uint64_t ev0[32], nops0 = 0;
  memset(ev0, 0, sizeof(ev0));
  for (uint32_t i = 0; i < rp->ops && !h->failed; i++) {
    if (i == rp->arm_at_op) {                         /* the window crash points are counted in */
      hc_collect(h);
      memcpy(ev0, h->ev_total, sizeof(ev0));
      nops0 = h->s.nand_ops;
      if (rp->point) { sfci_arm(&h->s, rp->point, rp->count, rp->action); h->s.crash_fired = 0; }
    }
    op_t o = wl_next(&w);
    hc_exec(h, &o);
  }
  hc_collect(h);
  for (int i = 0; i < 32; i++) res->ev_count[i] = h->ev_total[i] - ev0[i];
  res->nand_ops = h->s.nand_ops - nops0;
  res->fired = h->s.crash_fired > 0;
  if (!h->failed) {
    sfci_disarm(&h->s);
    hc_verify(h);
  }
  if (!h->failed) hc_clean_cycle(h);
  if (!h->failed && hc_bad_errs(h)) hc_fail(h, "controller ERR bits 0x%x", hc_bad_errs(h));
  if (!h->failed && simnand_stats(h->s.nand)->violations) hc_fail(h, "NAND rule violations: %llu",
                                                                  (unsigned long long)simnand_stats(h->s.nand)->violations);
  if (!h->failed && sfpr_cosim_rtl_errors(h->s.rtl)) hc_fail(h, "RTL assertion failures");
  res->pass = !h->failed;
  res->crashes = h->crashes - crash0;
  res->acked = h->acked; res->not_acked = h->not_acked; res->rejected = h->rejected; res->ops = h->ops;
  snprintf(res->why, sizeof(res->why), "%s", h->why);
  hc_free(h);
  free(h);
}

/* ================================================================ campaign helpers */
static uint64_t rnd(uint64_t *s) { uint64_t x = *s; x ^= x << 13; x ^= x >> 7; x ^= x << 17; return *s = x; }
static uint64_t g_runs, g_fired, g_crashes_total;

static void csv(const char *test, const char *k1, const char *k2, uint64_t a, uint64_t b, uint64_t c, uint64_t d) {
  if (!g_csv) return;
  fprintf(g_csv, "%s,%s,%s,%llu,%llu,%llu,%llu\n", test, k1, k2, (unsigned long long)a, (unsigned long long)b,
          (unsigned long long)c, (unsigned long long)d);
}

/* occurrence indices to try for a point seen `occ` times: the first few, then evenly spread to the last */
static uint32_t pick_counts(uint64_t occ, uint32_t k, uint32_t *out) {
  uint32_t n = 0;
  if (occ == 0) return 0;
  uint32_t head = k / 2u ? k / 2u : 1u;
  for (uint32_t i = 1; i <= head && i <= occ; i++) out[n++] = i;
  for (uint32_t j = 1; n < k && j <= k; j++) {
    uint64_t v = (occ * j) / k;
    if (v > out[n - 1] && v <= occ) out[n++] = (uint32_t)v;
  }
  return n;
}

static const uint32_t SWEEP_POINTS[] = {
  SFPR_CP_PRE_PROGRAM, SFPR_CP_IN_PROGRAM, SFPR_CP_POST_PROGRAM, SFPR_CP_PRE_MAP, SFPR_CP_POST_MAP,
  SFPR_CP_PRE_JOURNAL, SFPR_CP_IN_JOURNAL, SFPR_CP_PRE_COMPLETION, SFPR_CP_TRIM_PRE_UNMAP,
  SFPR_CP_GC_IN_COPY, SFPR_CP_GC_POST_COPY, SFPR_CP_GC_PRE_ERASE, SFPR_CP_IN_ERASE, SFPR_CP_WL_POST_COPY,
  SFPR_CP_CKPT_BODY, SFPR_CP_CKPT_PRE_COMMIT, SFPR_CP_CKPT_IN_COMMIT, SFPR_CP_CKPT_POST_COMMIT, SFPR_CP_META_ERASE,
};
#define N_SWEEP (sizeof(SWEEP_POINTS) / sizeof(SWEEP_POINTS[0]))
static const uint32_t ACTIONS[] = { SFPR_CI_ACTION_CUT_NOW, SFPR_CI_ACTION_CUT_NEXT_PROG, SFPR_CI_ACTION_CPU_RESET };
static const char *ACT_NAME[] = { "CUT_NOW", "CUT_NEXT_PROG", "CPU_RESET", "CUT_NEXT_OP" };

/* sweep every crash point x action x sampled occurrence on one workload */
static void sweep(const char *test, run_t base, const uint32_t *points, uint32_t npoints, uint32_t per, int need_all) {
  result_t dry;
  run_one(&base, &dry);
  CHECK(dry.pass, "[%s] dry run: %s", test, dry.why);
  printf("    workload: %llu host ops, %llu NAND ops; acknowledged %llu\n", (unsigned long long)dry.ops,
         (unsigned long long)dry.nand_ops, (unsigned long long)dry.acked);
  printf("    %-18s %8s | %-24s | %-24s | %-24s\n", "point", "occurs", "CUT_NOW runs/fired/pass", "CUT_NEXT_PROG", "CPU_RESET");
  for (uint32_t pi = 0; pi < npoints; pi++) {
    uint32_t p = points[pi];
    uint64_t occ = dry.ev_count[p];
    if (need_all) CHECK(occ > 0, "[%s] crash point %s never occurs in the workload", test, CP_NAME[p]);
    uint32_t counts[64];
    uint32_t nc = pick_counts(occ, per, counts);
    char cell[3][40];
    for (uint32_t ai = 0; ai < 3; ai++) {
      uint32_t runs = 0, fired = 0, passed = 0;
      for (uint32_t ci = 0; ci < nc; ci++) {
        run_t r = base;
        r.point = p; r.count = counts[ci]; r.action = ACTIONS[ai];
        result_t res;
        run_one(&r, &res);
        runs++; fired += res.fired ? 1u : 0u; passed += res.pass ? 1u : 0u;
        g_runs++; g_fired += res.fired ? 1u : 0u; g_crashes_total += res.crashes;
        CHECK(res.pass, "[%s] %s #%u %s: %s", test, CP_NAME[p], counts[ci], ACT_NAME[ACTIONS[ai]], res.why);
        /* a tear needs a later program/erase: the last occurrences may legitimately run out of them */
        if (!(ACTIONS[ai] == SFPR_CI_ACTION_CUT_NEXT_PROG && ci + 1u == nc))
          CHECK(res.fired, "[%s] %s #%u %s did not fire", test, CP_NAME[p], counts[ci], ACT_NAME[ACTIONS[ai]]);
      }
      snprintf(cell[ai], sizeof(cell[ai]), "%3u / %3u / %3u", runs, fired, passed);
      csv(test, CP_NAME[p], ACT_NAME[ACTIONS[ai]], occ, runs, fired, passed);
    }
    printf("    %-18s %8llu | %-24s | %-24s | %-24s\n", CP_NAME[p], (unsigned long long)occ, cell[0], cell[1], cell[2]);
  }
}

/* ================================================================ tests */
static void t_smoke(void) {
  run_t r;
  run_defaults(&r);
  r.ops = Q(400, 200);
  result_t res;
  run_one(&r, &res);
  CHECK(res.pass, "workload without crash: %s", res.why);
  printf("    %llu host ops: %llu writes/TRIMs acknowledged, %llu not, %llu rejected\n", (unsigned long long)res.ops,
         (unsigned long long)res.acked, (unsigned long long)res.not_acked, (unsigned long long)res.rejected);
  printf("    %llu NAND ops; events: program %llu, map %llu, journal %llu, GC copies %llu, erases %llu, ckpt commits %llu\n",
         (unsigned long long)res.nand_ops, (unsigned long long)res.ev_count[SFPR_CP_IN_PROGRAM],
         (unsigned long long)res.ev_count[SFPR_CP_PRE_MAP], (unsigned long long)res.ev_count[SFPR_CP_IN_JOURNAL],
         (unsigned long long)res.ev_count[SFPR_CP_GC_IN_COPY], (unsigned long long)res.ev_count[SFPR_CP_IN_ERASE],
         (unsigned long long)res.ev_count[SFPR_CP_CKPT_IN_COMMIT]);
}

/* 1. every named crash point (the brief's eight and more) x 3 actions x sampled occurrences */
static void t_crash_points(void) {
  run_t r;
  run_defaults(&r);
  r.fill_first = 1;                     /* a full device: GC, static WL and checkpoints all happen */
  r.ops = Q(500, 220);
  sweep("crash_points", r, SWEEP_POINTS, N_SWEEP, Q(10, 3), 1);
}

/* 2. power cut at every NAND operation index of a workload on a full device */
static void t_nand_op_sweep(void) {
  run_t r;
  run_defaults(&r);
  r.fill_first = 1;
  r.ops = Q(160, 60);
  result_t base;
  run_one(&r, &base);
  CHECK(base.pass, "dry run: %s", base.why);
  uint64_t m = base.nand_ops;                     /* NAND ops of the workload proper (after the fill) */
  uint32_t limit = Q(1200, 200), stride = Q(1, 3);
  uint32_t runs = 0, fired = 0, passed = 0;
  for (uint32_t i = 1; i <= m && i <= limit * stride; i += stride) {
    run_t x = r;
    x.point = SFPR_CP_NAND_OP; x.count = i; x.action = SFPR_CI_ACTION_CUT_NOW;
    result_t res;
    run_one(&x, &res);
    runs++; fired += res.fired; passed += res.pass;
    g_runs++; g_fired += res.fired; g_crashes_total += res.crashes;
    CHECK(res.pass, "cut at NAND op %u: %s", i, res.why);
  }
  printf("    workload NAND ops %llu; %u cut points (every %u), %u fired, %u passed\n", (unsigned long long)m, runs, stride,
         fired, passed);
  csv("nand_op_sweep", "NAND_OP", "CUT_NOW", m, runs, fired, passed);
}

/* 3. crashes during recovery, nested up to 3 deep */
typedef struct { uint32_t depth, used, point, action, counts[4]; } nest_t;
static void nest_hook(sfci_sys_t *s, void *arg, uint32_t attempt) {
  nest_t *n = (nest_t *)arg;
  (void)attempt;
  if (n->used >= n->depth) return;
  sfci_arm(s, n->point, n->counts[n->used], n->action);
  n->used++;
}

static void t_repeated_recovery(void) {
  uint32_t runs = 0, passed = 0, nested_seen = 0;
  uint32_t trials = Q(80, 20);
  uint64_t rng = g_seed * 77u + 1u;
  for (uint32_t t = 0; t < trials; t++) {
    rng ^= rng << 13; rng ^= rng >> 7; rng ^= rng << 17;
    hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
    sfftl_geom_t g = p51_geom();
    sfftl_cfg_t c = p58_cfg();
    simnand_cfg_t nc = nand_cfg(&g);
    sfps_cfg_t pc = fw_cfg();
    if (hc_init(h, &g, &c, &nc, &pc, g_seed + t) < 0) { CHECK(0, "init"); free(h); continue; }
    wl_t w;
    wl_init(&w, g_seed + 1000u + t, h->nlba, 10);
    fill_all(h);
    for (uint32_t i = 0; i < 150 && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
    /* the first crash, then up to 3 crashes inside the recoveries that follow */
    nest_t n;
    memset(&n, 0, sizeof(n));
    n.depth = 1u + (uint32_t)(rng % 3u);
    n.point = (rng >> 8) % 3u == 0 ? SFPR_CP_MOUNT_SCAN : (rng >> 8) % 3u == 1 ? SFPR_CP_NAND_OP : SFPR_CP_MOUNT_CKPT;
    n.action = (rng >> 12) % 4u == 0 ? SFPR_CI_ACTION_CPU_RESET : SFPR_CI_ACTION_CUT_NOW;
    for (uint32_t d = 0; d < 4; d++) {
      uint32_t span = n.point == SFPR_CP_NAND_OP ? 300u : n.point == SFPR_CP_MOUNT_SCAN ? 60u : 1u;
      n.counts[d] = 1u + (uint32_t)((rng >> (16 + 8 * d)) % span);
    }
    h->s.boot_hook = nest_hook;
    h->s.boot_hook_arg = &n;
    sfci_arm(&h->s, SFPR_CP_IN_PROGRAM, 1u + (uint32_t)((rng >> 40) % 30u), SFPR_CI_ACTION_CUT_NEXT_PROG);
    for (uint32_t i = 0; i < 200 && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
    h->s.boot_hook = NULL;
    sfci_disarm(&h->s);
    if (!h->failed) hc_verify(h);
    if (!h->failed) hc_clean_cycle(h);
    if (!h->failed && hc_bad_errs(h)) hc_fail(h, "controller ERR 0x%x", hc_bad_errs(h));
    runs++;
    nested_seen += h->s.nested_boot_crashes ? 1u : 0u;
    passed += !h->failed;
    g_runs++; g_crashes_total += h->crashes + h->s.nested_boot_crashes;
    CHECK(!h->failed, "trial %u (depth %u, %s, %s): %s", t, n.depth, CP_NAME[n.point], ACT_NAME[n.action], h->why);
    hc_free(h);
    free(h);
  }
  printf("    %u trials, %u with crashes inside recovery, %u passed\n", runs, nested_seen, passed);
  CHECK(nested_seen > runs / 2u, "nested crashes actually happened (%u of %u)", nested_seen, runs);
  csv("repeated_recovery", "nested", "-", runs, nested_seen, passed, 0);
}

/* 4. randomized: geometries, policies, NAND faults, several crashes per run, clean cycles */
static void t_random(void) {
  uint32_t trials = Q(160, 30), passed = 0;
  uint64_t crashes = 0;
  const uint32_t pts[] = { SFPR_CP_PRE_PROGRAM, SFPR_CP_IN_PROGRAM, SFPR_CP_POST_PROGRAM, SFPR_CP_PRE_MAP,
                           SFPR_CP_IN_JOURNAL, SFPR_CP_PRE_COMPLETION, SFPR_CP_GC_IN_COPY, SFPR_CP_GC_POST_COPY,
                           SFPR_CP_GC_PRE_ERASE, SFPR_CP_IN_ERASE, SFPR_CP_CKPT_BODY, SFPR_CP_CKPT_IN_COMMIT,
                           SFPR_CP_TRIM_PRE_UNMAP, SFPR_CP_WL_POST_COPY, SFPR_CP_META_ERASE, SFPR_CP_NAND_OP };
  const char *only = getenv("RANDOM_TRIAL");
  for (uint32_t t = 0; t < trials; t++) {
    if (only && (uint32_t)atoi(only) != t) continue;
    uint64_t rng = (g_seed + t) * 0x2545F4914F6CDD1Dull + 3u;
#define RND() rnd(&rng)
    static const uint32_t G[][3] = { {512, 16, 64}, {512, 32, 48}, {1024, 16, 64}, {2048, 16, 80}, {4096, 8, 96}, {512, 64, 40} };
    const uint32_t *gg = G[RND() % 6u];
    sfftl_geom_t g = geom(gg[0], gg[1], gg[2]);
    sfftl_cfg_t c = p58_cfg();
    c.gc_policy = (RND() & 1u) ? SFFTL_GC_COST_BENEFIT : SFFTL_GC_GREEDY;
    c.wl_policy = (sfftl_wl_policy_t)(RND() % 3u);
    if (RND() & 1u) c.flags &= ~SFFTL_F_PACED_GC;
    if ((RND() % 4u) == 0) c.flags &= ~SFFTL_F_DUAL_CKPT;
    if ((RND() % 4u) == 0) c.flags &= ~SFFTL_F_JOURNAL_MIRROR;
    if ((RND() % 4u) == 0) c.flags &= ~SFFTL_F_VERIFY_WRITE;
    c.ckpt_interval_blocks = (RND() % 3u) == 0 ? 3u : (RND() % 2u) ? 0u : 24u;
    simnand_cfg_t nc = nand_cfg(&g);
    int faults = (RND() % 3u) == 0;
    if (faults) { nc.prog_fail_ppm = 1500; nc.erase_fail_ppm = 3000; nc.read_flip_ppm = 20000; }
    if (only) printf("    trial %u: geom %u/%u/%u faults %d flags 0x%x\n", t, gg[0], gg[1], gg[2], faults, c.flags);
    sfps_cfg_t pc = fw_cfg();
    hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
    if (hc_init(h, &g, &c, &nc, &pc, g_seed * 1000u + t) < 0) { CHECK(0, "init trial %u: %s", t, h->why); free(h); continue; }
    wl_t w;
    wl_init(&w, RND(), h->nlba, 1u + (uint32_t)(RND() % 40u));
    w.pct_trim = (uint32_t)(RND() % 20u);
    if (RND() & 1u) fill_all(h);
    uint32_t ops = 300u + (uint32_t)(RND() % 600u);
    uint32_t arm_in = 1u + (uint32_t)(RND() % 50u);
    for (uint32_t i = 0; i < ops && !h->failed; i++) {
      if (--arm_in == 0) {
        uint32_t p = pts[RND() % (sizeof(pts) / sizeof(pts[0]))];
        uint32_t a = (uint32_t)(RND() % 4u);
        sfci_arm(&h->s, p, 1u + (uint32_t)(RND() % (p == SFPR_CP_NAND_OP ? 400u : 40u)), a);
        arm_in = 20u + (uint32_t)(RND() % 120u);
      }
      op_t o = wl_next(&w);
      if (hc_exec(h, &o) == 1) crashes++;
      if ((RND() % 300u) == 0) hc_clean_cycle(h);
    }
    sfci_disarm(&h->s);
    if (!h->failed) hc_verify(h);
    if (!h->failed) hc_clean_cycle(h);
    if (!h->failed && hc_bad_errs(h)) hc_fail(h, "controller ERR 0x%x", hc_bad_errs(h));
    if (!h->failed && simnand_stats(h->s.nand)->violations) hc_fail(h, "NAND rule violations");
    passed += !h->failed;
    g_runs++; g_crashes_total += h->crashes;
    CHECK(!h->failed, "trial %u (geom %u/%u/%u): %s", t, gg[0], gg[1], gg[2], h->why);
    hc_free(h);
    free(h);
#undef RND
  }
  printf("    %u randomized runs (6 geometries, GC/WL/paced/dual/mirror/verify/ckpt-interval variants, NAND faults),"
         " %llu crashes, %u passed\n", trials, (unsigned long long)crashes, passed);
  csv("random", "-", "-", trials, crashes, passed, 0);
}

/* 5. power-fault WARNING: in-flight policy STOP / DIAG, then real loss (fast / slow) or brown-out */
enum { PF_DIE_FAST, PF_DIE_SLOW, PF_BROWN_REMOUNT, PF_BROWN_RESUME };
static const char *PF_OUT[] = { "die-fast", "die-slow", "brownout-remount", "brownout-resume" };

typedef struct { int rc; } fwrc_t;
static void resume_fn(sfci_sys_t *s, void *arg) { ((fwrc_t *)arg)->rc = sfps_resume(&s->fw); }

static int wait_state(hc_t *h, uint32_t st, uint32_t max) {
  for (uint32_t i = 0; i < max; i++) {
    if (sfci_state(&h->s) == st) return 0;
    int k = sfci_idle(&h->s, 16);              /* the firmware's main loop keeps running */
    if (k) { h->crashes++; hc_recover(h, k); return -2; }
  }
  return -1;
}

static void t_power_fault(void) {
  uint32_t trials = Q(24, 6);
  for (uint32_t mode = 0; mode < 2; mode++) {
    for (uint32_t out = 0; out < 4; out++) {
      uint32_t passed = 0, runs = 0, diag_found = 0;
      uint64_t max_progs_in_pf = 0, max_dev_progs = 0, aborted = 0;
      for (uint32_t t = 0; t < trials; t++) {
        uint64_t rng = (g_seed + 17u * t + 1000u * out + 5000u * mode) * 0x9E3779B97F4A7C15ull + 1u;
#define RND() rnd(&rng)
        sfftl_geom_t g = p51_geom();
        sfftl_cfg_t c = p58_cfg();
        simnand_cfg_t nc = nand_cfg(&g);
        sfps_cfg_t pc = fw_cfg();
        pc.pf_mode = mode ? SFPR_PF_MODE_DIAG : SFPR_PF_MODE_STOP;
        pc.pf_budget = 2;
        pc.remount_on_restore = out != PF_BROWN_RESUME;
        hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
        if (hc_init(h, &g, &c, &nc, &pc, g_seed + 31u * t) < 0) { CHECK(0, "init"); free(h); continue; }
        h->s.irq_latency_ops = (uint32_t)(RND() % 4u);    /* the firmware may learn of the fault late */
        wl_t w;
        wl_init(&w, RND(), h->nlba, 1u + (uint32_t)(RND() % 24u));
        fill_all(h);
        for (uint32_t i = 0; i < 60 && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
        uint64_t ops0 = h->s.nand_ops;
        h->s.pf_at_op = ops0 + 1u + RND() % 200u;
        h->s.die_after_pf = out == PF_DIE_FAST ? 1u + RND() % 60u : out == PF_DIE_SLOW ? 3000u + RND() % 3000u : 0u;
        h->s.progs_in_pf = 0;
        /* run until the warning arrives */
        for (uint32_t i = 0; i < 400 && !h->failed && !h->s.pf_asserted && h->s.pf_at_op; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
        uint64_t dev_progs = 0;
        if (h->s.pf_asserted && !h->failed) {
          /* the host keeps issuing: commands are refused (ABORT_PWR_LOSS) while the fault lasts */
          for (uint32_t i = 0; i < 3 && !h->failed && h->s.pf_asserted; i++) { op_t o = wl_next(&w); if (hc_exec(h, &o) == 1) break; }
          /* the firmware's idle main loop services the fault (DIAG page, FW_SAFE) */
          if (h->s.pf_asserted && !h->failed) {
            int k = sfci_idle(&h->s, 400);
            if (k) { h->crashes++; hc_recover(h, k); }
          }
          const simnand_stats_t *ns = simnand_stats(h->s.nand);
          if (h->s.pf_asserted) dev_progs = ns->programs + ns->erases - h->s.progs_at_pf_device;
          if (out == PF_DIE_FAST || out == PF_DIE_SLOW) {
            if (h->s.pf_asserted) {
              int k = 0;
              while (!k && h->s.die_at_cycle) k = sfci_idle(&h->s, 64);
              if (!k) { simnand_power_off(h->s.nand); k = SFCI_ABANDON_POWER; }
              h->s.die_at_cycle = 0;
              h->crashes++;
              hc_recover(h, k);
            }
          } else {
            uint32_t snap = sfpr_cosim_rd(h->s.rtl, SFPR_RET_PF_SNAP);
            sfpr_cosim_tick(h->s.rtl, 50);
            sfpr_cosim_set_pwr_fail(h->s.rtl, 0);
            h->s.pf_asserted = 0;
            h->s.pf_at_op = 0;
            if (out == PF_BROWN_REMOUNT) {
              hc_recover(h, SFCI_ABANDON_CPU);          /* the controller resets the CPU and runs recovery */
              if (!h->failed && mode) {
                const sfftl_diag_t *dg = sfftl_diag(&h->s.ftl);
                if (dg->pfail_count >= 1 && dg->last_pfail_info == snap) diag_found++;
                else if (getenv("HC_DEBUG")) {
                  hc_collect(h);
                  printf("      [debug] trial %u: pfail_count %u info 0x%08x snap 0x%08x; fw pf handled %llu; progs_in_pf %llu;"
                         " T_PF_NAND_OPS %u\n", t, dg->pfail_count, dg->last_pfail_info, snap,
                         (unsigned long long)h->fw_pf_handled, (unsigned long long)h->s.progs_in_pf,
                         sfpr_cosim_rd(h->s.rtl, SFPR_T_PF_NAND_OPS));
                }
              }
            } else {
              if (wait_state(h, SFPR_STATE_PF_RESTORE, 2000) < 0) hc_fail(h, "no PF_RESTORE");
              fwrc_t a = { -1 };
              if (!h->failed && sfci_run(&h->s, resume_fn, &a) != 0) hc_fail(h, "crash during resume");
              if (!h->failed && sfci_state(&h->s) != SFPR_STATE_RUN) hc_fail(h, "not RUN after RESUME");
            }
          }
        }
        aborted += h->not_acked;
        if (h->s.progs_in_pf > max_progs_in_pf) max_progs_in_pf = h->s.progs_in_pf;
        if (dev_progs > max_dev_progs) max_dev_progs = dev_progs;
        /* policy checks */
        if (!h->failed && mode == 0 && h->s.progs_in_pf != 0) hc_fail(h, "STOP: %llu program/erase started in a PF state",
                                                                   (unsigned long long)h->s.progs_in_pf);
        if (!h->failed && mode == 1 && h->s.progs_in_pf > pc.pf_budget) hc_fail(h, "DIAG: %llu programs > budget",
                                                                         (unsigned long long)h->s.progs_in_pf);
        /* keep working, then an unclean power cut: whatever the fault left in RAM must agree with what the
         * roll-forward reconstructs from the medium (resume-in-place hazards surface only here) */
        uint32_t after = (uint32_t)(RND() % 40u);          /* short: no checkpoint may hide a RAM/medium split */
        for (uint32_t i = 0; i < after && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
        if (!h->failed) {
          sfftl_space_t sp;
          sfftl_space(&h->s.ftl, &sp);
          if (sp.blocks_bad_grown) hc_fail(h, "a power fault retired %u healthy block(s)", sp.blocks_bad_grown);
        }
        if (!h->failed) {
          simnand_power_off(h->s.nand);
          h->crashes++;
          hc_recover(h, SFCI_ABANDON_POWER);
        }
        if (!h->failed) hc_verify(h);
        if (!h->failed) hc_clean_cycle(h);
        if (!h->failed && hc_bad_errs(h)) hc_fail(h, "controller ERR 0x%x", hc_bad_errs(h));
        runs++;
        passed += !h->failed;
        g_runs++; g_crashes_total += h->crashes;
        CHECK(!h->failed, "%s %s trial %u: %s", mode ? "DIAG" : "STOP", PF_OUT[out], t, h->why);
        hc_free(h);
        free(h);
#undef RND
      }
      printf("    %-4s %-17s %3u runs, %3u passed; max program/erase started in PF state %llu, device programs"
             " after the warning %llu%s\n", mode ? "DIAG" : "STOP", PF_OUT[out], runs, passed,
             (unsigned long long)max_progs_in_pf, (unsigned long long)max_dev_progs,
             (mode && out == PF_BROWN_REMOUNT) ? "" : "");
      if (mode && out == PF_BROWN_REMOUNT) {
        printf("         diagnostic record recovered after the brown-out: %u / %u\n", diag_found, runs);
        CHECK(diag_found == runs, "DIAG record persisted in every brown-out run (%u/%u)", diag_found, runs);
      }
      csv("power_fault", mode ? "DIAG" : "STOP", PF_OUT[out], runs, passed, max_progs_in_pf, max_dev_progs);
    }
  }
}

/* 6. metadata corruption: one damaged page in the live metadata set */
enum { MC_NEWEST_COMMIT, MC_COMMIT_AFTER_WRAP, MC_NEWEST_BODY, MC_NEWEST_JOURNAL, MC_RANDOM_LIVE, MC_STALE,
       MC_FLIP_CORRECTABLE, MC_ALL_ZONE, MC_N };
static const char *MC_NAME[] = { "newest commit", "newest commit + cut after ring erase", "newest body page", "newest journal page",
                                 "random live page", "stale (non-live) page", "correctable bit errors",
                                 "whole metadata zone" };

static int meta_page_info(sfftl_t *f, simnand_t *n, uint32_t ppn, uint32_t *kind, uint64_t *seq) {
  uint8_t d[16384], sp[16];
  uint32_t bf;
  int st = simnand_read(n, ppn, d, sp, &bf);
  if (st != SFFTL_HAL_OK && st != SFFTL_HAL_CORRECTED) return -1;
  if (sp[1] != SFFTL_OOB_TYPE_META) return -1;
  *kind = (uint32_t)d[4] | ((uint32_t)d[5] << 8);
  *seq = (uint64_t)sp[6] | ((uint64_t)sp[7] << 8) | ((uint64_t)sp[8] << 16) | ((uint64_t)sp[9] << 24) |
         ((uint64_t)sp[10] << 32) | ((uint64_t)sp[11] << 40);
  (void)f;
  return 0;
}

/* fires the crash unit on the NAND op right after the metadata-ring erase of the block that holds the
 * previous checkpoint (P56 sizing), or of any block (DUAL_CKPT never erases the previous checkpoint) */
typedef struct { hc_t *h; int armed; } cutobs_t;
static void cut_observer(void *octx, uint32_t ev, uint32_t arg) {
  cutobs_t *o = (cutobs_t *)octx;
  if (o->armed || ev != SFFTL_EV_META_ERASE || !o->h->s.fw.mounted) return;
  sfftl_t *f = &o->h->s.ftl;
  int dual = (f->cfg.flags & SFFTL_F_DUAL_CKPT) != 0;
  if (!dual && (f->prev_first_ppn == SFFTL_NONE || arg != f->prev_first_ppn / f->g.pages_per_block)) return;
  o->armed = 1;
  sfci_arm(&o->h->s, SFPR_CP_NAND_OP, 1, SFPR_CI_ACTION_CUT_NOW);   /* the erase itself is torn */
}

static void t_metadata_corruption(void) {
  printf("    %-28s | %-22s | %-22s\n", "damage", "P58 config pass/runs", "P56 config pass/runs");
  for (uint32_t m = 0; m < MC_N; m++) {
    uint32_t trials = m == MC_COMMIT_AFTER_WRAP ? Q(60, 16) : Q(20, 5);
    uint32_t pass[2] = {0, 0}, runs[2] = {0, 0}, enofs[2] = {0, 0};
    for (uint32_t cfgi = 0; cfgi < 2; cfgi++) {
      for (uint32_t t = 0; t < trials; t++) {
        uint64_t rng = (g_seed + t * 13u + m * 1000u) * 0x9E3779B97F4A7C15ull + 7u;
#define RND() rnd(&rng)
        sfftl_geom_t g = m == MC_COMMIT_AFTER_WRAP ? geom(512, 16, 256) : p51_geom();
        sfftl_cfg_t c = cfgi == 0 ? p58_cfg() : p56_cfg();
        simnand_cfg_t nc = nand_cfg(&g);
        sfps_cfg_t pc = fw_cfg();
        hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
        if (hc_init(h, &g, &c, &nc, &pc, g_seed + t) < 0) { CHECK(0, "init"); free(h); continue; }
        cutobs_t co = { h, 0 };
        wl_t w;
        wl_init(&w, RND(), h->nlba, 8);
        w.pct_trim = 20;
        fill_all(h);
        uint32_t ops = 100u + (uint32_t)(RND() % 300u);
        for (uint32_t i = 0; i < ops && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
        int pending = 0;
        if (m == MC_COMMIT_AFTER_WRAP) {
          /* double fault: the supply dies on the first program after the metadata ring recycled a block
           * (inside the next checkpoint / journal write) AND the newest commit is unreadable.  P56 keeps
           * only the newest checkpoint live, so the block just recycled may have held the previous one. */
          h->no_auto_recover = 1;
          h->s.observer = cut_observer; h->s.octx = &co;
          h->s.fw.observer = cut_observer; h->s.fw.octx = &co;
          for (uint32_t i = 0; i < 6000 && !h->failed && !pending; i++) {
            op_t o = wl_next(&w);
            if (hc_exec(h, &o) == 2) pending = h->pending_kind;
          }
          h->no_auto_recover = 0;
          h->s.observer = NULL; h->s.fw.observer = NULL;
          if (!pending) { hc_free(h); free(h); continue; }   /* not counted: the fault never arose */
          simnand_disarm_powercut(h->s.nand);               /* supply back (the medium is read below) */
          if (!simnand_powered(h->s.nand)) simnand_power_on(h->s.nand);
        }
        /* choose the damaged page from the medium (the attacker does not know the FTL's RAM) */
        sfftl_t *f = &h->s.ftl;
        uint32_t ppb = g.pages_per_block, cand[4096], nca = 0, best = SFFTL_NONE;
        uint64_t best_seq = 0;
        uint32_t want = (m == MC_NEWEST_COMMIT || m == MC_COMMIT_AFTER_WRAP) ? SFFTL_MK_COMMIT : m == MC_NEWEST_BODY ? SFFTL_MK_BODY :
                        m == MC_NEWEST_JOURNAL ? SFFTL_MK_JOURNAL : 0u;
        uint32_t live0 = f->mz_live_start;
        for (uint32_t z = 0; z < f->meta_blocks; z++) {
          uint32_t b = f->zone[z];
          int live = 0;
          for (uint32_t zz = live0; ; zz = (zz + 1u) % f->meta_blocks) { if (zz == z) { live = 1; break; } if (zz == f->mz_head) break; }
          for (uint32_t p = 0; p < ppb; p++) {
            uint32_t ppn = b * ppb + p, kind;
            uint64_t seq;
            if (meta_page_info(f, h->s.nand, ppn, &kind, &seq) < 0) continue;
            if (want && kind == want && seq > best_seq) { best_seq = seq; best = ppn; }
            if ((m == MC_RANDOM_LIVE || m == MC_FLIP_CORRECTABLE) && live && nca < 4096) cand[nca++] = ppn;
            if (m == MC_STALE && !live && nca < 4096) cand[nca++] = ppn;
          }
        }
        if (m == MC_ALL_ZONE) {
          for (uint32_t z = 0; z < f->meta_blocks; z++) for (uint32_t p = 0; p < ppb; p++) simnand_corrupt_page(h->s.nand, f->zone[z] * ppb + p);
        } else if (want) {
          if (best != SFFTL_NONE) simnand_corrupt_page(h->s.nand, best);
        } else if (nca) {
          uint32_t pick = cand[RND() % nca];
          if (m == MC_FLIP_CORRECTABLE) simnand_flip_bits(h->s.nand, pick, nc.ecc_bits ? nc.ecc_bits : 1u);
          else simnand_corrupt_page(h->s.nand, pick);
        }
        /* power loss, recovery, verification */
        if (!pending) { simnand_power_off(h->s.nand); h->crashes++; }
        uint32_t gen_before = h->s.ftl.gen, prev_before = h->s.ftl.prev_first_ppn, first_before = h->s.ftl.ckpt_first_ppn;
        int rc = sfci_recover(&h->s, SFCI_ABANDON_POWER, 2);
        if (getenv("HC_DEBUG") && m == MC_COMMIT_AFTER_WRAP)
          printf("      [debug] cfg %u: gen before %u (first %u prev %u) corrupted ppn %u -> rc %d loaded gen %u rejected %u\n",
                 cfgi, gen_before, first_before, prev_before, best, rc, sfftl_stats(&h->s.ftl)->last_mount_ckpt_gen,
                 sfftl_stats(&h->s.ftl)->last_mount_ckpt_rejected);
        runs[cfgi]++;
        if (m == MC_ALL_ZONE) {
          /* no metadata at all: the controller must FAIL SAFE (no guessed map) unless rebuild is enabled */
          int ok = rc == SFFTL_ENOFS && sfci_state(&h->s) == SFPR_STATE_FAILED;
          if (ok) { pass[cfgi]++; enofs[cfgi]++; }
        } else if (rc >= 0) {
          if (hc_verify(h) == 0) pass[cfgi]++;
        } else if (rc == SFFTL_ENOFS) {
          enofs[cfgi]++;
        }
        if (cfgi == 0) CHECK(!(m != MC_ALL_ZONE && (rc < 0 || h->failed)) && !(m == MC_ALL_ZONE && rc != SFFTL_ENOFS),
                             "P58 config, %s, trial %u: rc %d %s", MC_NAME[m], t, rc, h->why);
        g_runs++;
        hc_free(h);
        free(h);
#undef RND
      }
    }
    char a[32], b[32];
    snprintf(a, sizeof(a), "%u / %u", pass[0], runs[0]);
    snprintf(b, sizeof(b), "%u / %u (ENOFS %u)", pass[1], runs[1], enofs[1]);
    printf("    %-28s | %-22s | %-22s\n", MC_NAME[m], a, b);
    csv("metadata_corruption", MC_NAME[m], "P58/P56", pass[0], runs[0], pass[1], runs[1]);
  }
}

/* 6b. metadata-ring invariants checked at every ring erase (white box) */
typedef struct { hc_t *h; uint64_t erases, newest_hit, prev_hit; } ringobs_t;
static void ring_observer(void *octx, uint32_t ev, uint32_t arg) {
  ringobs_t *o = (ringobs_t *)octx;
  if (ev != SFFTL_EV_META_ERASE || !o->h->s.fw.mounted) return;
  sfftl_t *f = &o->h->s.ftl;
  uint32_t ppb = f->g.pages_per_block;
  o->erases++;
  if (f->ckpt_first_ppn != SFFTL_NONE && arg == f->ckpt_first_ppn / ppb) o->newest_hit++;
  if (f->prev_first_ppn != SFFTL_NONE && arg == f->prev_first_ppn / ppb) o->prev_hit++;
}

static void t_ring_invariants(void) {
  /* geometry 1: P51; geometry 2: a checkpoint spanning several blocks (wider recycling window) */
  for (int gi = 0; gi < 2; gi++)
  for (int cfgi = 0; cfgi < 2; cfgi++) {
    uint64_t erases = 0, newest = 0, prev = 0;
    uint32_t trials = Q(8, 3);
    for (uint32_t t = 0; t < trials; t++) {
      sfftl_geom_t g = gi ? geom(512, 16, 256) : p51_geom();
      sfftl_cfg_t c = cfgi == 0 ? p58_cfg() : p56_cfg();
      simnand_cfg_t nc = nand_cfg(&g);
      sfps_cfg_t pc = fw_cfg();
      hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
      ringobs_t o;
      memset(&o, 0, sizeof(o));
      o.h = h;
      if (hc_init(h, &g, &c, &nc, &pc, g_seed + 900u + t) < 0) { CHECK(0, "init"); free(h); continue; }
      h->s.observer = ring_observer;
      h->s.octx = &o;
      h->s.fw.observer = ring_observer;
      h->s.fw.octx = &o;
      wl_t w;
      wl_init(&w, g_seed + 77u * t, h->nlba, 8);
      w.pct_trim = 15;
      fill_all(h);
      for (uint32_t i = 0; i < Q(1500u, 600u) && !h->failed; i++) {
        if (i % 300 == 150) sfci_arm(&h->s, SFPR_CP_IN_PROGRAM, 1u + (i % 7u), SFPR_CI_ACTION_CUT_NEXT_PROG);
        op_t o2 = wl_next(&w);
        hc_exec(h, &o2);
      }
      CHECK(!h->failed, "%s", h->why);
      erases += o.erases; newest += o.newest_hit; prev += o.prev_hit;
      hc_free(h);
      free(h);
    }
    printf("    %s %s: %llu metadata-ring erases; erased the newest checkpoint's block %llu x, the previous"
           " checkpoint's block %llu x\n", gi ? "512 B x 16 x 256" : "P51 64 blocks   ", cfgi == 0 ? "P58 (dual)" : "P56       ",
           (unsigned long long)erases,
           (unsigned long long)newest, (unsigned long long)prev);
    CHECK(newest == 0, "the newest checkpoint is never erased");
    if (cfgi == 0) CHECK(prev == 0, "DUAL_CKPT: the previous checkpoint is never erased");
    csv("ring_invariants", cfgi == 0 ? "P58" : "P56", gi ? "512x16x256" : "P51", erases, newest, prev, 0);
  }
}

/* 6c. a TRIM aborted by a power fault (its journal page refused), brown-out resume, the host rewrites the
 *     same LBAs, a later journal flush, power cut: the aborted TRIM must never take effect after the rewrite */
typedef struct { hc_t *h; int fired; } trimobs_t;
static void trim_observer(void *octx, uint32_t ev, uint32_t arg) {
  trimobs_t *o = (trimobs_t *)octx;
  (void)arg;
  if (o->fired || ev != SFFTL_EV_IN_JOURNAL || o->h->s.fw.cur_kind != SFPR_KIND_TRIM || o->h->s.fw.cur_tag < 0) return;
  o->fired = 1;
  sfpr_cosim_set_pwr_fail(o->h->s.rtl, 1);              /* the warning arrives as the TRIM's journal page starts */
  o->h->s.pf_asserted = 1;
  sfpr_cosim_tick(o->h->s.rtl, 8);                      /* registered before the program is attempted: refused */
}

static void t_aborted_trim(void) {
  uint32_t trials = Q(12, 4), passed = 0, aborted = 0;
  for (uint32_t t = 0; t < trials; t++) {
    sfftl_geom_t g = p51_geom();
    sfftl_cfg_t c = p58_cfg();
    simnand_cfg_t nc = nand_cfg(&g);
    sfps_cfg_t pc = fw_cfg();
    pc.remount_on_restore = 0;                          /* resume in place: RAM state must agree with the medium */
    hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
    if (hc_init(h, &g, &c, &nc, &pc, g_seed + 300u + t) < 0) { CHECK(0, "init"); free(h); continue; }
    h->s.irq_latency_ops = 1000; h->s.irq_latency_cycles = 1u << 30;   /* firmware learns of the fault late */
    trimobs_t o = { h, 0 };
    fill_all(h);
    uint64_t lba = 16u * (1u + t % 8u);
    h->s.observer = trim_observer; h->s.octx = &o;
    h->s.fw.observer = trim_observer; h->s.fw.octx = &o;
    op_t tr = { OP_TRIM, lba, 16, 0 };
    hc_exec(h, &tr);                                    /* aborted: journal program refused */
    h->s.observer = NULL; h->s.fw.observer = NULL;
    if (!o.fired) { CHECK(0, "trial %u: TRIM journal point not reached", t); hc_free(h); free(h); continue; }
    aborted += h->last_acked ? 0u : 1u;
    h->s.irq_latency_ops = 0; h->s.irq_latency_cycles = 64;
    (void)sfci_idle(&h->s, 400);                        /* firmware services the fault */
    sfpr_cosim_set_pwr_fail(h->s.rtl, 0);
    h->s.pf_asserted = 0;
    if (wait_state(h, SFPR_STATE_PF_RESTORE, 2000) < 0) hc_fail(h, "no PF_RESTORE");
    fwrc_t a = { -1 };
    if (!h->failed && sfci_run(&h->s, resume_fn, &a) != 0) hc_fail(h, "crash during resume");
    /* the host rewrites the range (acknowledged), then something flushes the journal */
    op_t wr = { OP_WRITE, lba, 16, 0 }, fl = { OP_FLUSH, 0, 0, 0 }, tr2 = { OP_TRIM, lba + 200u, 4, 0 };
    if (!h->failed) hc_exec(h, &wr);
    if (!h->failed) hc_exec(h, &tr2);
    if (!h->failed) hc_exec(h, &fl);
    if (!h->failed && !h->last_acked) hc_fail(h, "flush not acknowledged");
    if (!h->failed) { simnand_power_off(h->s.nand); h->crashes++; hc_recover(h, SFCI_ABANDON_POWER); }
    if (!h->failed) hc_verify(h);
    passed += !h->failed;
    g_runs++; g_crashes_total += h->crashes;
    CHECK(!h->failed, "trial %u: %s", t, h->why);
    hc_free(h);
    free(h);
  }
  printf("    %u trials: TRIM aborted at its journal program by a power fault, resumed, LBAs rewritten, journal"
         " flushed, power cut: %u not acknowledged, %u passed\n", trials, aborted, passed);
}

/* 7. full device: every LBA written, small over-provisioning, ENOSPC conditions, crashes */
static void t_full_device(void) {
  run_t r;
  run_defaults(&r);
  r.fcfg.op_permille = 40;              /* 4 % spare: GC under pressure */
  r.fill_first = 1;
  r.ops = Q(400, 160);
  r.max_len = 32;
  r.pct_trim = 0;
  const uint32_t pts[] = { SFPR_CP_IN_PROGRAM, SFPR_CP_GC_IN_COPY, SFPR_CP_GC_POST_COPY, SFPR_CP_GC_PRE_ERASE,
                           SFPR_CP_IN_ERASE, SFPR_CP_CKPT_IN_COMMIT, SFPR_CP_PRE_COMPLETION };
  sweep("full_device", r, pts, sizeof(pts) / sizeof(pts[0]), Q(8, 3), 1);
}

/* 8. GC and wear-levelling interaction: aggressive static WL, both GC policies, paced and blocking */
static void t_gc_wl(void) {
  const uint32_t pts[] = { SFPR_CP_GC_IN_COPY, SFPR_CP_GC_POST_COPY, SFPR_CP_GC_PRE_ERASE, SFPR_CP_WL_POST_COPY,
                           SFPR_CP_IN_ERASE, SFPR_CP_META_ERASE };
  for (int v = 0; v < 2; v++) {
    run_t r;
    run_defaults(&r);
    r.fcfg.wl_policy = SFFTL_WL_DYNAMIC_STATIC;
    r.fcfg.wl_static_threshold = 3;
    r.fcfg.wl_static_interval = 4;
    r.fcfg.gc_policy = v ? SFFTL_GC_COST_BENEFIT : SFFTL_GC_GREEDY;
    if (v) r.fcfg.flags &= ~SFFTL_F_PACED_GC;
    r.fill_first = 1;
    r.ops = Q(500, 200);
    r.fcfg.wl_static_threshold = 2;
    r.fcfg.wl_static_interval = 2;
    printf("    -- %s GC, %s\n", v ? "cost-benefit" : "greedy", v ? "blocking" : "paced");
    sweep(v ? "gc_wl_cb" : "gc_wl_greedy", r, pts, sizeof(pts) / sizeof(pts[0]), Q(8, 3), 1);
  }
}

/* 9. defence in depth: firmware that acknowledges before durability is stopped by the controller */
static void t_gate_defense(void) {
  run_t r;
  run_defaults(&r);
  r.pcfg.bug_ack_before_durable = 1;
  r.fill_first = 1;
  r.ops = Q(300, 120);
  const uint32_t pts[] = { SFPR_CP_PRE_PROGRAM, SFPR_CP_IN_PROGRAM, SFPR_CP_POST_PROGRAM, SFPR_CP_PRE_MAP };
  hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
  sfftl_geom_t g = r.g;
  if (hc_init(h, &g, &r.fcfg, &r.ncfg, &r.pcfg, g_seed) == 0) {
    wl_t w;
    wl_init(&w, 99, h->nlba, 8);
    for (uint32_t i = 0; i < 100 && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
    uint32_t refused = sfpr_cosim_rd(h->s.rtl, SFPR_T_GATE_REFUSED);
    uint32_t err = sfpr_cosim_rd(h->s.rtl, SFPR_ERR);
    hc_collect(h);
    CHECK(refused > 0 && (err & 1u), "premature acknowledgements refused by the gate (%u, ERR 0x%x)", refused, err);
    CHECK(h->fw_cpl_refused == refused, "firmware saw every refusal (%llu vs %u)", (unsigned long long)h->fw_cpl_refused, refused);
    printf("    buggy firmware: %u premature SUCCESS requests refused by the controller (ERR.ACK_BEFORE_DURABLE set)\n", refused);
  }
  hc_free(h);
  free(h);
  sweep("gate_defense", r, pts, sizeof(pts) / sizeof(pts[0]), Q(6, 2), 1);
}

/* 10. CPU-only crashes: retained commit status cross-check, retained diagnostics */
static void t_cpu_reset(void) {
  uint32_t trials = Q(60, 15), passed = 0;
  uint64_t checks = 0;
  for (uint32_t t = 0; t < trials; t++) {
    hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
    sfftl_geom_t g = p51_geom();
    sfftl_cfg_t c = p58_cfg();
    simnand_cfg_t nc = nand_cfg(&g);
    sfps_cfg_t pc = fw_cfg();
    if (hc_init(h, &g, &c, &nc, &pc, g_seed + 500u + t) < 0) { CHECK(0, "init"); free(h); continue; }
    wl_t w;
    wl_init(&w, g_seed * 3u + t, h->nlba, 10);
    for (uint32_t i = 0; i < 200 && !h->failed; i++) {
      if (i % 40 == 5) sfci_arm(&h->s, SFPR_CP_NAND_OP, 1u + (uint32_t)((t * 7u + i) % 60u), SFPR_CI_ACTION_CPU_RESET);
      op_t o = wl_next(&w);
      hc_exec(h, &o);
    }
    sfci_disarm(&h->s);
    uint32_t cause = sfpr_cosim_rd(h->s.rtl, SFPR_RET_CAUSE), boots = sfpr_cosim_rd(h->s.rtl, SFPR_RET_BOOTS);
    hc_collect(h);
    if (!h->failed && h->crashes && !(cause & (1u << SFPR_CAUSE_CRASH))) hc_fail(h, "RET_CAUSE 0x%x", cause);
    if (!h->failed && boots != h->crashes) hc_fail(h, "RET_BOOTS %u != CPU resets %llu", boots, (unsigned long long)h->crashes);
    if (!h->failed) hc_verify(h);
    if (!h->failed && hc_bad_errs(h)) hc_fail(h, "controller ERR 0x%x", hc_bad_errs(h));
    checks += h->fw_retained_checks;
    passed += !h->failed;
    g_runs++; g_crashes_total += h->crashes;
    CHECK(!h->failed, "trial %u: %s", t, h->why);
    hc_free(h);
    free(h);
  }
  printf("    %u runs with CPU-only crashes, %llu retained-commit-status checks at recovery (0 violations), %u passed\n",
         trials, (unsigned long long)checks, passed);
  CHECK(checks > 0, "retained commit status was checked");
}

/* 11. persistent diagnostics: unclean-shutdown and recovery records survive checkpoints and clean cycles */
static void t_diagnostics(void) {
  hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
  sfftl_geom_t g = p51_geom();
  sfftl_cfg_t c = p58_cfg();
  simnand_cfg_t nc = nand_cfg(&g);
  sfps_cfg_t pc = fw_cfg();
  if (hc_init(h, &g, &c, &nc, &pc, g_seed) < 0) { CHECK(0, "init"); free(h); return; }
  wl_t w;
  wl_init(&w, 5, h->nlba, 8);
  uint32_t cuts = Q(12, 5);
  for (uint32_t k = 0; k < cuts && !h->failed; k++) {
    sfci_arm(&h->s, SFPR_CP_IN_PROGRAM, 3u + k, SFPR_CI_ACTION_CUT_NEXT_PROG);
    for (uint32_t i = 0; i < 60 && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
    if (k % 3 == 2) hc_clean_cycle(h);
  }
  const sfftl_diag_t *d = sfftl_diag(&h->s.ftl);
  CHECK(!h->failed, "%s", h->why);
  CHECK(d->unclean_mounts == h->crashes, "unclean mounts recorded %u == crashes %llu", d->unclean_mounts,
        (unsigned long long)h->crashes);
  CHECK(d->recov_count == h->crashes, "recovery records %u == crashes %llu", d->recov_count, (unsigned long long)h->crashes);
  uint32_t kind = (d->last_recov_info >> 8) & 3u;
  CHECK(kind == 1u, "last recovery record says 'unclean' (%u)", kind);
  printf("    %llu power cuts: unclean_mounts %u, recovery records %u, last record 0x%08x (cause 0x%02x, replayed %u pages)\n",
         (unsigned long long)h->crashes, d->unclean_mounts, d->recov_count, d->last_recov_info, d->last_recov_info & 0x7Fu,
         d->last_recov_info >> 16);
  hc_free(h);
  free(h);
}

/* 12. the P56 configuration (no dual checkpoint / mirror / verify) under the same crash points */
static void t_p56_config(void) {
  run_t r;
  run_defaults(&r);
  r.fcfg = p56_cfg();
  r.fill_first = 1;
  r.ops = Q(400, 160);
  sweep("p56_config", r, SWEEP_POINTS, N_SWEEP, Q(4, 2), 0);
}

/* ================================================================ performance (--perf DIR) */
static int cmp_u64(const void *a, const void *b) {
  uint64_t x = *(const uint64_t *)a, y = *(const uint64_t *)b;
  return x < y ? -1 : x > y;
}
static uint64_t pct(uint64_t *v, uint32_t n, double p) {
  if (!n) return 0;
  uint32_t i = (uint32_t)(p * (n - 1u) + 0.5);
  return v[i];
}

typedef struct { const char *name; uint32_t flags_on, flags_off; uint32_t ckpt; } pconf_t;

static sfftl_geom_t bench_geom(void) { return geom(2048, 64, 128); }   /* 16 MiB, 2 KiB pages, 4 x 512-B LBAs per page */

/* write latency, journal / metadata overhead, checkpoint frequency for several configurations */
static void perf_overhead(FILE *md, const char *dir) {
  static const pconf_t PC[] = {
    { "P56 baseline (no dual / mirror / verify)", 0, SFFTL_F_DUAL_CKPT | SFFTL_F_JOURNAL_MIRROR | SFFTL_F_VERIFY_WRITE, 0 },
    { "P58 + dual checkpoint", 0, SFFTL_F_JOURNAL_MIRROR | SFFTL_F_VERIFY_WRITE, 0 },
    { "P58 + dual + journal mirror", 0, SFFTL_F_VERIFY_WRITE, 0 },
    { "P58 full (dual + mirror + write verify)", 0, 0, 0 },
  };
  char path[512];
  snprintf(path, sizeof(path), "%s/latency.csv", dir);
  FILE *lc = fopen(path, "w");
  if (lc) fprintf(lc, "config,percentile,write_ns\n");
  fprintf(md, "## 1. Write completion latency and metadata overhead\n\n");
  fprintf(md, "Device: 2 KiB pages x 64 pages x 128 blocks (16 MiB), 512-B LBAs; NANDLab illustrative SLC timing "
              "(tR 25 us, tPROG 200 us, tBERS 2 ms + bus transfer).  Workload after a full fill: 3 000 commands, 80 %% "
              "random writes of 1-16 LBAs (70 %% to a hot 1/8), 6 %% TRIM, 4 %% FLUSH, 10 %% reads.  Latency = modelled "
              "NAND time from submission to the SUCCESS completion released by the controller's gate (no early "
              "acknowledgement exists in this design).\n\n");
  fprintf(md, "| Configuration | write p50 | p90 | p99 | max | meta programs / host page | journal pages / 1000 host pages | "
              "checkpoints / 1000 host pages | read-backs / host page |\n|---|---|---|---|---|---|---|---|---|\n");
  for (size_t ci = 0; ci < sizeof(PC) / sizeof(PC[0]); ci++) {
    sfftl_geom_t g = bench_geom();
    sfftl_cfg_t c = p58_cfg();
    c.wl_static_threshold = 64; c.wl_static_interval = 64;          /* realistic defaults for measurement */
    c.flags = (c.flags | PC[ci].flags_on) & ~PC[ci].flags_off;
    simnand_cfg_t nc = nand_cfg(&g);
    sfps_cfg_t pc = fw_cfg();
    pc.forward_events = 0;
    hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
    if (hc_init(h, &g, &c, &nc, &pc, 1) < 0) { CHECK(0, "perf init"); free(h); continue; }
    fill_all(h);
    wl_t w;
    wl_init(&w, 12345, h->nlba, 16);
    w.pct_write = 80; w.pct_read = 10; w.pct_trim = 6; w.pct_flush = 4; w.pct_bg = 0; w.pct_ckpt = 0;
    const sfftl_stats_t *st = sfftl_stats(&h->s.ftl);
    uint64_t m0 = st->nand_prog_meta, hp0 = st->host_pages_written, j0 = st->journal_pages + st->journal_mirror_pages,
             ck0 = st->ckpt_count, v0 = st->verify_write_reads;
    uint32_t n = Q(3000, 800), nl = 0;
    uint64_t *lat = (uint64_t *)malloc(n * sizeof(uint64_t));
    for (uint32_t i = 0; i < n && !h->failed; i++) {
      op_t o = wl_next(&w);
      hc_exec(h, &o);
      if (o.type == OP_WRITE && h->last_acked) lat[nl++] = h->last_ns;
    }
    qsort(lat, nl, sizeof(uint64_t), cmp_u64);
    uint64_t hp = st->host_pages_written - hp0;
    double meta = hp ? (double)(st->nand_prog_meta - m0) / (double)hp : 0;
    double jp = hp ? 1000.0 * (double)(st->journal_pages + st->journal_mirror_pages - j0) / (double)hp : 0;
    double ck = hp ? 1000.0 * (double)(st->ckpt_count - ck0) / (double)hp : 0;
    double vr = hp ? (double)(st->verify_write_reads - v0) / (double)hp : 0;
    fprintf(md, "| %s | %.2f ms | %.2f ms | %.2f ms | %.2f ms | %.3f | %.1f | %.2f | %.2f |\n", PC[ci].name,
            pct(lat, nl, 0.5) / 1e6, pct(lat, nl, 0.9) / 1e6, pct(lat, nl, 0.99) / 1e6, nl ? lat[nl - 1] / 1e6 : 0.0,
            meta, jp, ck, vr);
    if (lc) for (int p = 1; p <= 100; p++) fprintf(lc, "%s,%d,%llu\n", PC[ci].name, p, (unsigned long long)pct(lat, nl, p / 100.0));
    CHECK(!h->failed, "perf run %s: %s", PC[ci].name, h->why);
    if (!h->failed) CHECK(hc_verify(h) == 0, "perf data check");
    free(lat);
    hc_free(h);
    free(h);
  }
  if (lc) fclose(lc);
  fprintf(md, "\nA write is acknowledged only after every page it touched was programmed (status PASS), optionally read "
              "back, and its mapping committed: the p50 is one page program plus transfer; the tail comes from foreground "
              "garbage collection and block erases inside the write.  The early-acknowledgement lower bound (completion at "
              "BUFFERED, i.e. after the host-to-buffer DMA) would be ~0 NAND time -- it is NOT available without qualified "
              "PLP or a host-enabled volatile write cache.\n\n");
}

/* recovery time vs checkpoint interval and device size; clean vs unclean */
static void perf_recovery(FILE *md, const char *dir) {
  char path[512];
  snprintf(path, sizeof(path), "%s/recovery.csv", dir);
  FILE *rc = fopen(path, "w");
  if (rc) fprintf(rc, "device,ckpt_interval,kind,mount_ops,mount_ms,ctrl_cycles,pages_scanned,pages_replayed,meta_prog_per_host_page\n");
  fprintf(md, "## 2. Recovery time vs checkpoint interval\n\n");
  fprintf(md, "Each row: device filled, then a random-write workload; power is cut at a random point; the recovery "
              "(controller RECOVERY -> firmware mount with roll-forward -> recovery record -> RECOVERY_DONE) is timed.  "
              "Mean / max over the trials.  Modelled NAND time (ms) and controller clocks spent in RECOVERY are both "
              "reported; the latter includes the co-simulation's register-access cost.\n\n");
  fprintf(md, "| Device | ckpt interval (block openings) | unclean mount ops mean / max | unclean mount ms mean / max | "
              "pages replayed mean | clean mount ops | clean mount ms | meta programs / host page |\n|---|---|---|---|---|---|---|---|\n");
  static const uint32_t IV[] = { 2, 4, 8, 16, 32 };
  for (int dev = 0; dev < 2; dev++) {
    for (size_t ii = 0; ii < sizeof(IV) / sizeof(IV[0]); ii++) {
      sfftl_geom_t g = dev ? bench_geom() : p51_geom();
      sfftl_cfg_t c = p58_cfg();
      c.wl_static_threshold = 64; c.wl_static_interval = 64;
      c.ckpt_interval_blocks = IV[ii];
      simnand_cfg_t nc = nand_cfg(&g);
      sfps_cfg_t pc = fw_cfg();
      pc.forward_events = 0;
      uint32_t trials = Q(6, 2);
      double ops_sum = 0, ms_sum = 0, rep_sum = 0, ops_max = 0, ms_max = 0, meta_wa = 0, clean_ops = 0, clean_ms = 0;
      for (uint32_t t = 0; t < trials; t++) {
        hc_t *h = (hc_t *)calloc(1, sizeof(hc_t));
        if (hc_init(h, &g, &c, &nc, &pc, 100 + t) < 0) { CHECK(0, "init"); free(h); continue; }
        fill_all(h);
        wl_t w;
        wl_init(&w, 777 + t, h->nlba, 8);
        w.pct_write = 90; w.pct_read = 5; w.pct_trim = 5; w.pct_flush = 0; w.pct_bg = 0; w.pct_ckpt = 0;
        const sfftl_stats_t *st = sfftl_stats(&h->s.ftl);
        uint64_t m0 = st->nand_prog_meta, hp0 = st->host_pages_written;
        uint32_t n = (dev ? 600u : 300u) + (uint32_t)((t * 97u) % 200u);
        for (uint32_t i = 0; i < n && !h->failed; i++) { op_t o = wl_next(&w); hc_exec(h, &o); }
        uint64_t hp = st->host_pages_written - hp0;
        meta_wa += hp ? (double)(st->nand_prog_meta - m0) / (double)hp : 0;
        simnand_power_off(h->s.nand);                     /* power cut while idle */
        h->crashes++;
        hc_recover(h, SFCI_ABANDON_POWER);
        const sfftl_stats_t *s2 = sfftl_stats(&h->s.ftl);
        double ops = (double)h->s.boot_ops_last, ms = h->s.boot_ns_last / 1e6;
        ops_sum += ops; ms_sum += ms; rep_sum += s2->last_mount_pages_replayed;
        if (ops > ops_max) ops_max = ops;
        if (ms > ms_max) ms_max = ms;
        if (rc) fprintf(rc, "%s,%u,unclean,%llu,%.3f,%llu,%u,%u,%.4f\n", dev ? "16MiB" : "P51", IV[ii],
                        (unsigned long long)h->s.boot_ops_last, ms, (unsigned long long)h->s.boot_cycles_last,
                        s2->last_mount_pages_scanned, s2->last_mount_pages_replayed,
                        hp ? (double)(st->nand_prog_meta - m0) / (double)hp : 0.0);
        hc_clean_cycle(h);
        clean_ops += (double)h->s.boot_ops_last;
        clean_ms += h->s.boot_ns_last / 1e6;
        if (rc) fprintf(rc, "%s,%u,clean,%llu,%.3f,%llu,0,0,0\n", dev ? "16MiB" : "P51", IV[ii],
                        (unsigned long long)h->s.boot_ops_last, h->s.boot_ns_last / 1e6, (unsigned long long)h->s.boot_cycles_last);
        CHECK(!h->failed, "perf recovery: %s", h->why);
        hc_free(h);
        free(h);
      }
      fprintf(md, "| %s | %u | %.0f / %.0f | %.1f / %.1f | %.0f | %.0f | %.2f | %.3f |\n", dev ? "16 MiB (2 KiB x 64 x 128)" : "P51 (512 B x 16 x 64)",
              IV[ii], ops_sum / trials, ops_max, ms_sum / trials, ms_max, rep_sum / trials, clean_ops / trials,
              clean_ms / trials, meta_wa / trials);
    }
  }
  if (rc) fclose(rc);
  fprintf(md, "\nShorter checkpoint intervals bound the roll-forward (fewer blocks newer than the checkpoint) at the "
              "price of more metadata programs per host page.  An unclean mount reads page 0 of every block plus the "
              "post-checkpoint pages, so it grows with the device size even at a short interval; the clean mount reads "
              "only the metadata ring and the checkpoint.\n\n");
}

/* capacity consumed by recovery structures */
static void perf_capacity(FILE *md) {
  fprintf(md, "## 3. Capacity and memory consumed by the recovery structures\n\n");
  fprintf(md, "| Device | Config | metadata-ring blocks | %% of blocks | user LBAs | user capacity vs P56 | checkpoint pages | "
              "spare bytes used per page | firmware arena |\n|---|---|---|---|---|---|---|---|---|\n");
  sfftl_geom_t gs[3] = { p51_geom(), bench_geom(), geom(4096, 128, 1024) };
  const char *gn[3] = { "P51 (512 B x 16 x 64)", "16 MiB (2 KiB x 64 x 128)", "512 MiB (4 KiB x 128 x 1024)" };
  for (int gi = 0; gi < 3; gi++) {
    sfftl_layout_t l56, l58;
    sfftl_cfg_t c56 = p56_cfg(), c58 = p58_cfg();
    if (sfftl_layout_info(&gs[gi], &c56, &l56) < 0 || sfftl_layout_info(&gs[gi], &c58, &l58) < 0) continue;
    uint32_t spp = gs[gi].page_data_bytes / 512u;
    fprintf(md, "| %s | P56 | %u | %.1f %% | %llu | 100 %% | %u | 16 of %u | %.1f KiB |\n", gn[gi], l56.meta_blocks,
            100.0 * l56.meta_blocks / gs[gi].blocks, (unsigned long long)l56.nlpn_max * spp, l56.ckpt_pages,
            gs[gi].page_spare_bytes, l56.total_bytes / 1024.0);
    fprintf(md, "| %s | P58 (dual ckpt) | %u | %.1f %% | %llu | %.2f %% | %u | 16 of %u | %.1f KiB |\n", gn[gi], l58.meta_blocks,
            100.0 * l58.meta_blocks / gs[gi].blocks, (unsigned long long)l58.nlpn_max * spp,
            100.0 * l58.nlpn_max / (double)l56.nlpn_max, l58.ckpt_pages, gs[gi].page_spare_bytes, l58.total_bytes / 1024.0);
  }
  fprintf(md, "\nThe spare record (BBM, type, LPN, 48-bit SEQ, CRC-32) is what makes every acknowledged write durable "
              "without a checkpoint; its 16 bytes are part of the ECC-protected program.  The dual checkpoint keeps two "
              "checkpoint generations plus the journal between them live, which costs one checkpoint's worth of ring "
              "blocks.  The controller itself adds no NAND structure: its retention registers are flops.\n\n");
}

static int perf_main(const char *dir) {
  char path[512];
  snprintf(path, sizeof(path), "%s/PERF.md", dir);
  FILE *md = fopen(path, "w");
  if (!md) { printf("cannot write %s\n", path); return 1; }
  fprintf(md, "# PowerSafe performance measurements\n\n_Generated by `make perf` (build/test_recovery --perf). Host "
              "co-simulation: Verilator model of the controller + C firmware + simulated NAND with NANDLab illustrative "
              "timing.  All times are MODELLED, comparable with each other, not measurements of any device._\n\n");
  clock_t t0 = clock();
  perf_overhead(md, dir);
  perf_recovery(md, dir);
  perf_capacity(md);
  fprintf(md, "_Run time %.1f s; %s._\n", (double)(clock() - t0) / CLOCKS_PER_SEC, g_tfail ? "SOME CHECKS FAILED" : "all data checks passed");
  fclose(md);
  printf("perf: wrote %s (%s)\n", path, g_tfail ? "FAIL" : "PASS");
  return g_tfail;
}

/* ================================================================ runner */
typedef struct { const char *name; void (*fn)(void); } test_t;
static const test_t TESTS[] = {
  { "smoke", t_smoke },
  { "crash_points", t_crash_points },
  { "nand_op_sweep", t_nand_op_sweep },
  { "repeated_recovery", t_repeated_recovery },
  { "random", t_random },
  { "power_fault", t_power_fault },
  { "metadata_corruption", t_metadata_corruption },
  { "ring_invariants", t_ring_invariants },
  { "aborted_trim", t_aborted_trim },
  { "full_device", t_full_device },
  { "gc_wl", t_gc_wl },
  { "gate_defense", t_gate_defense },
  { "cpu_reset", t_cpu_reset },
  { "diagnostics", t_diagnostics },
  { "p56_config", t_p56_config },
};

int main(int argc, char **argv) {
  const char *filter = NULL;
  init_names();
  for (int i = 1; i < argc; i++) {
    if (!strcmp(argv[i], "--quick")) g_quick = 1;
    else if (!strcmp(argv[i], "--seed") && i + 1 < argc) g_seed = strtoull(argv[++i], NULL, 0);
    else if (!strcmp(argv[i], "--csv") && i + 1 < argc) g_csv = fopen(argv[++i], "w");
    else if (!strcmp(argv[i], "--perf") && i + 1 < argc) return perf_main(argv[++i]);
    else filter = argv[i];
  }
  int failed = 0, ran = 0;
  uint64_t c_all = 0;
  for (size_t i = 0; i < sizeof(TESTS) / sizeof(TESTS[0]); i++) {
    if (filter && !strstr(TESTS[i].name, filter)) continue;
    uint64_t c0 = g_checks, f0 = g_fail_checks;
    g_tfail = 0;
    printf("[ RUN  ] %s\n", TESTS[i].name);
    fflush(stdout);
    clock_t t0 = clock();
    TESTS[i].fn();
    double ms = 1000.0 * (double)(clock() - t0) / CLOCKS_PER_SEC;
    printf("RESULT %-22s %s %7llu checks %9.0f ms\n", TESTS[i].name, g_tfail ? "FAIL" : "PASS",
           (unsigned long long)(g_checks - c0), ms);
    (void)f0;
    fflush(stdout);
    failed += g_tfail;
    ran++;
    c_all += g_checks - c0;
  }
  printf("TOTAL  %llu system runs, %llu crashes injected and recovered\n", (unsigned long long)g_runs,
         (unsigned long long)g_crashes_total);
  printf("SUMMARY %d tests, %d failed, %llu checks, %llu failed checks%s\n", ran, failed, (unsigned long long)c_all,
         (unsigned long long)g_fail_checks, g_quick ? " (quick)" : "");
  if (g_csv) fclose(g_csv);
  return failed ? 1 : 0;
}
