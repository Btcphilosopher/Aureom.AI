/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- host model for the crash campaigns
 *
 * Issues commands through the firmware (sfps) running on the co-simulated
 * controller, watches the controller's completion queue, keeps the recovery
 * reference model (rrm) in step with what the host was told, recovers after
 * every crash and verifies the whole device.
 * ===========================================================================*/
#ifndef HC_H
#define HC_H

#include <stdint.h>
#include "sfci.h"
#include "rrm.h"

enum { OP_WRITE, OP_READ, OP_TRIM, OP_FLUSH, OP_BG, OP_CKPT };

typedef struct { uint32_t type; uint64_t lba; uint32_t n; uint32_t fua; } op_t;

typedef struct {
  uint64_t rng;
  uint64_t nlba;
  uint32_t max_len;      /* LBAs per command, 1..max_len                      */
  uint32_t pct_write, pct_read, pct_trim, pct_flush, pct_bg, pct_ckpt;
  uint32_t hot_pct;      /* % of commands that go to the hot 1/8 of the device */
  uint32_t seq_pct;      /* % of writes that continue sequentially             */
  uint64_t seq_next;
} wl_t;

void wl_init(wl_t *w, uint64_t seed, uint64_t nlba, uint32_t max_len);
op_t wl_next(wl_t *w);

typedef struct {
  sfci_sys_t s;
  rrm_t      r;
  uint8_t   *buf, *scratch;
  uint32_t   buf_lbas;
  uint64_t   nlba;
  int64_t    op_id;
  uint32_t   err_ignore;          /* controller ERR bits that are expected in this scenario */
  /* statistics */
  uint64_t ops, acked, not_acked, rejected, crashes, recoveries, verifies, read_checks;
  uint64_t recov_ops_sum, recov_ns_sum, recov_cycles_sum, recov_ops_max, recov_ns_max;
  uint32_t err_seen;              /* union of the controller's ERR register over the run */
  uint64_t ev_total[32];          /* firmware event counts accumulated over every boot */
  uint64_t fw_cpl_refused, fw_cpl_success, fw_recovery_records, fw_retained_checks, fw_pf_handled, fw_mounts_unclean;
  uint64_t last_ns, last_cycles;  /* modelled NAND time / controller clocks of the last command */
  int      last_acked;
  int      no_auto_recover;       /* hc_exec returns 2 after a crash and leaves the system down (pending_kind) */
  int      pending_kind;
  int      dbg_once;
  int      failed;
  char     why[512];
} hc_t;

/* create system + format; returns 0 or <0 */
int  hc_init(hc_t *h, const sfftl_geom_t *g, const sfftl_cfg_t *fcfg, const simnand_cfg_t *nc, const sfps_cfg_t *pc,
             uint64_t seed);
void hc_free(hc_t *h);

/* execute one host operation; returns 0, 1 (a crash happened and was recovered + verified) or -1 (failure, h->why) */
int  hc_exec(hc_t *h, const op_t *op);
/* recover after an abandonment observed outside a command (e.g. power died while idle) */
int  hc_recover(hc_t *h, int kind);
/* full device verification against the reference model */
int  hc_verify(hc_t *h);
/* clean shutdown + power cycle + verify */
int  hc_clean_cycle(hc_t *h);
/* controller ERR bits that indicate a defect (unexpected) seen so far */
uint32_t hc_bad_errs(const hc_t *h);
void hc_fail(hc_t *h, const char *fmt, ...);
/* fold the current firmware telemetry into the run totals (called before every boot and at the end) */
void hc_collect(hc_t *h);

#endif
