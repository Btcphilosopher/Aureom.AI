/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- host model (see hc.h)
 * ===========================================================================*/
#include "hc.h"
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ---------------------------------------------------------------- workload */
static uint64_t xs(uint64_t *s) {
  uint64_t x = *s;
  x ^= x << 13; x ^= x >> 7; x ^= x << 17;
  return *s = x;
}

void wl_init(wl_t *w, uint64_t seed, uint64_t nlba, uint32_t max_len) {
  memset(w, 0, sizeof(*w));
  w->rng = seed * 0x9E3779B97F4A7C15ull + 0x1234567ull;
  w->nlba = nlba;
  w->max_len = max_len;
  w->pct_write = 70; w->pct_read = 10; w->pct_trim = 8; w->pct_flush = 4; w->pct_bg = 6; w->pct_ckpt = 2;
  w->hot_pct = 70;
  w->seq_pct = 10;
}

op_t wl_next(wl_t *w) {
  op_t o;
  memset(&o, 0, sizeof(o));
  uint32_t r = (uint32_t)(xs(&w->rng) % 100u);
  uint32_t acc = w->pct_write;
  if (r < acc) o.type = OP_WRITE;
  else if (r < (acc += w->pct_read)) o.type = OP_READ;
  else if (r < (acc += w->pct_trim)) o.type = OP_TRIM;
  else if (r < (acc += w->pct_flush)) o.type = OP_FLUSH;
  else if (r < (acc += w->pct_bg)) o.type = OP_BG;
  else o.type = OP_CKPT;
  o.n = 1u + (uint32_t)(xs(&w->rng) % w->max_len);
  if (o.n > w->nlba) o.n = (uint32_t)w->nlba;
  if (o.type == OP_WRITE && w->seq_next && (xs(&w->rng) % 100u) < w->seq_pct && w->seq_next + o.n <= w->nlba) {
    o.lba = w->seq_next;
  } else if ((xs(&w->rng) % 100u) < w->hot_pct) {
    uint64_t hot = w->nlba / 8u > o.n ? w->nlba / 8u : o.n;
    o.lba = xs(&w->rng) % (hot - o.n + 1u);
  } else {
    o.lba = xs(&w->rng) % (w->nlba - o.n + 1u);
  }
  o.fua = (xs(&w->rng) % 10u) == 0;
  if (o.type == OP_WRITE) w->seq_next = o.lba + o.n;
  return o;
}

/* ---------------------------------------------------------------- helpers */
void hc_fail(hc_t *h, const char *fmt, ...) {
  if (h->failed) return;
  h->failed = 1;
  va_list ap;
  va_start(ap, fmt);
  vsnprintf(h->why, sizeof(h->why), fmt, ap);
  va_end(ap);
}

#define BAD_ERR_MASK ((1u << 0) | (1u << 1) | (1u << 2) | (1u << 3) | (1u << 8) | (1u << 9) | (1u << 10) | (1u << 12))

uint32_t hc_bad_errs(const hc_t *h) { return h->err_seen & BAD_ERR_MASK & ~h->err_ignore; }

void hc_collect(hc_t *h) {
  const sfps_tel_t *t = &h->s.fw.tel;
  for (int i = 0; i < 32; i++) h->ev_total[i] += t->ev_count[i];
  h->fw_cpl_refused += t->cpl_refused;
  h->fw_cpl_success += t->cpl_success;
  h->fw_recovery_records += t->recovery_records;
  h->fw_retained_checks += t->retained_seq_checks;
  h->fw_pf_handled += t->pf_handled;
  h->fw_mounts_unclean += t->mounts_unclean;
  memset(&h->s.fw.tel, 0, sizeof(h->s.fw.tel));
}

static void sample_err(hc_t *h) {
  uint32_t e = sfpr_cosim_rd(h->s.rtl, SFPR_ERR);
  h->err_seen |= e;
}

int hc_init(hc_t *h, const sfftl_geom_t *g, const sfftl_cfg_t *fcfg, const simnand_cfg_t *nc, const sfps_cfg_t *pc,
            uint64_t seed) {
  memset(h, 0, sizeof(*h));
  int rc = sfci_create(&h->s, g, fcfg, nc, pc, seed);
  if (rc < 0) { hc_fail(h, "system create/format failed: %d", rc); return rc; }
  h->nlba = sfftl_capacity_lba(&h->s.ftl);
  if (rrm_init(&h->r, h->nlba, fcfg->lba_bytes, g->page_data_bytes) < 0) return -1;
  h->buf_lbas = 256u;
  h->buf = (uint8_t *)malloc((size_t)h->buf_lbas * fcfg->lba_bytes);
  h->scratch = (uint8_t *)malloc(2u * (size_t)g->page_data_bytes + fcfg->lba_bytes);
  return (h->buf && h->scratch) ? 0 : -1;
}

void hc_free(hc_t *h) {
  sfci_destroy(&h->s);
  rrm_free(&h->r);
  free(h->buf);
  free(h->scratch);
}

/* ---------------------------------------------------------------- firmware-side command execution */
typedef struct {
  hc_t   *h;
  op_t    op;
  int     tag;
  int     submitted;
  int     rc;
} exec_arg_t;

static void exec_fn(sfci_sys_t *s, void *arg) {
  exec_arg_t *a = (exec_arg_t *)arg;
  sfps_t *p = &s->fw;
  uint32_t st = 0;
  (void)sfps_poll(p);              /* main loop: an interrupt may be pending */
  if (a->op.type == OP_BG) { a->rc = sfps_background(p, 16); (void)sfps_poll(p); return; }
  if (a->op.type == OP_CKPT) { a->rc = p->mounted ? sfftl_checkpoint(p->f) : -1; return; }
  uint32_t kind = a->op.type == OP_WRITE ? SFPR_KIND_WRITE : a->op.type == OP_READ ? SFPR_KIND_READ :
                  a->op.type == OP_TRIM ? SFPR_KIND_TRIM : SFPR_KIND_FLUSH;
  a->tag = sfps_submit(p, kind, a->op.fua, &st);
  if (a->tag < 0) { (void)sfps_poll(p); return; }
  a->submitted = 1;
  s->tag_owner[a->tag] = a->h->op_id;
  switch (a->op.type) {
    case OP_WRITE: (void)sfps_write(p, a->tag, a->op.lba, a->op.n, a->h->buf, a->op.fua); break;
    case OP_READ:  (void)sfps_read(p, a->tag, a->op.lba, a->op.n, a->h->buf); break;
    case OP_TRIM:  (void)sfps_trim(p, a->tag, a->op.lba, a->op.n); break;
    default:       (void)sfps_flush(p, a->tag); break;
  }
  (void)sfps_poll(p);              /* main loop: power-fault handling if one was signalled */
}

static int rd_ftl(void *ctx, uint64_t lba, uint32_t n, uint8_t *buf) {
  hc_t *h = (hc_t *)ctx;
  return sfftl_read(&h->s.ftl, lba, n, buf) == SFFTL_OK ? 0 : -1;
}

typedef struct { hc_t *h; int bad; int all; } ver_arg_t;
static void verify_fn(sfci_sys_t *s, void *arg) {
  (void)s;
  ver_arg_t *a = (ver_arg_t *)arg;
  a->bad = a->all ? rrm_verify_all(&a->h->r, rd_ftl, a->h, a->h->scratch) : rrm_resolve(&a->h->r, rd_ftl, a->h, a->h->scratch);
}

static int verify(hc_t *h, int all);

int hc_recover(hc_t *h, int kind) {
  sample_err(h);                               /* the controller's errors before it may lose them */
  hc_collect(h);
  int rc = sfci_recover(&h->s, kind, 6);
  h->recoveries++;
  if (rc < 0) { hc_fail(h, "recovery failed: %d (%s)", rc, rc > -100 ? sfftl_strerror(rc) : "harness"); return -1; }
  sfps_tel_t const *t = sfps_telemetry(&h->s.fw);
  if (t->retained_seq_violations) { hc_fail(h, "retained commit status above the recovered medium"); return -1; }
  h->recov_ops_sum += h->s.boot_ops_last;
  h->recov_ns_sum += h->s.boot_ns_last;
  h->recov_cycles_sum += h->s.boot_cycles_last;
  if (h->s.boot_ops_last > h->recov_ops_max) h->recov_ops_max = h->s.boot_ops_last;
  if (h->s.boot_ns_last > h->recov_ns_max) h->recov_ns_max = h->s.boot_ns_last;
  return verify(h, 1);
}

static int verify(hc_t *h, int all) {
  for (int tries = 0; tries < 4; tries++) {
    ver_arg_t a = { h, 0, all };
    int k = sfci_run(&h->s, verify_fn, &a);
    if (k == 0) {
      h->verifies++;
      if (a.bad != 0) { hc_fail(h, "verification: %s", h->r.why); return -1; }
      return 0;
    }
    /* a still-armed crash fired during verification: recover and verify again */
    h->crashes++;
    sample_err(h);
    hc_collect(h);
    int rc = sfci_recover(&h->s, k, 6);
    h->recoveries++;
    if (rc < 0) { hc_fail(h, "recovery failed during verify: %d", rc); return -1; }
    all = 1;
  }
  hc_fail(h, "verification kept crashing");
  return -1;
}

int hc_verify(hc_t *h) { return verify(h, 1); }

int hc_exec(hc_t *h, const op_t *op_in) {
  if (h->failed) return -1;
  op_t op = *op_in;
  if (op.n > h->buf_lbas) op.n = h->buf_lbas;
  int ready = (sfpr_cosim_host_status(h->s.rtl) & 1u) != 0;     /* host-visible RDY */
  rrm_t saved = h->r;
  int keep_doubt = 0;
  if (h->r.doubt && (op.type == OP_WRITE || op.type == OP_TRIM)) {
    if (ready) { if (verify(h, 0) < 0) return -1; }
    else keep_doubt = 1;           /* cannot read now (power fault): the command will be refused anyway */
  }
  h->op_id++;
  h->ops++;
  if (op.type == OP_WRITE) rrm_begin_write(&h->r, op.lba, op.n, h->buf);
  else if (op.type == OP_TRIM) rrm_begin_trim(&h->r, op.lba, op.n);
  exec_arg_t a;
  memset(&a, 0, sizeof(a));
  a.h = h; a.op = op; a.tag = -1;
  uint64_t t_ns0 = simnand_stats(h->s.nand)->time_ns, t_cy0 = sfpr_cosim_cycles(h->s.rtl);
  int k = sfci_run(&h->s, exec_fn, &a);
  h->last_ns = simnand_stats(h->s.nand)->time_ns - t_ns0;
  h->last_cycles = sfpr_cosim_cycles(h->s.rtl) - t_cy0;
  /* completions the host saw */
  int acked = 0, completed = 0;
  sfpr_cq_entry_t e[64];
  uint32_t n;
  while ((n = sfci_cq_take(&h->s, e, 64)) > 0) {
    for (uint32_t i = 0; i < n; i++) {
      if (e[i].tag < 16 && h->s.tag_owner[e[i].tag] == h->op_id) {
        completed = 1;
        if (e[i].status == SFPS_ST_SUCCESS) acked = 1;
        h->s.tag_owner[e[i].tag] = -1;
      }
    }
  }
  h->last_acked = acked;
  if (op.type == OP_WRITE || op.type == OP_TRIM) {
    if (keep_doubt && a.submitted) { hc_fail(h, "command admitted while the controller was not ready"); return -1; }
    if (!a.submitted) {            /* refused at admission, or the system died before admission: it never ran */
      if (k == 0) h->rejected++;
      if (keep_doubt) { h->r.doubt = saved.doubt; h->r.d_lba = saved.d_lba; h->r.d_n = saved.d_n; h->r.d_ver = saved.d_ver; }
      else h->r.doubt = 0;
    }
    else if (acked) { rrm_ack(&h->r); h->acked++; }
    else { rrm_not_acked(&h->r); h->not_acked++; }
  } else if (op.type == OP_READ && acked && k == 0) {
    /* host read through the whole firmware path: compare with the acknowledged contents */
    uint8_t *exp = h->scratch;
    for (uint32_t i = 0; i < op.n; i++) {
      uint64_t l = op.lba + i;
      if (h->r.doubt && l >= h->r.d_lba && l < h->r.d_lba + h->r.d_n) continue;
      rrm_fill(&h->r, l, h->r.acked[l], exp);
      h->read_checks++;
      if (memcmp(exp, h->buf + (size_t)i * h->r.lba_bytes, h->r.lba_bytes) != 0) {
        hc_fail(h, "host read of LBA %llu returned wrong data", (unsigned long long)l);
        return -1;
      }
    }
  }
  (void)completed;
  if (k != 0) {
    h->crashes++;
    if (h->no_auto_recover) { h->pending_kind = k; sample_err(h); return 2; }
    if (hc_recover(h, k) < 0) return -1;
    return 1;
  }
  sample_err(h);
  if (getenv("HC_DEBUG") && (h->err_seen & (1u << 10)) && !h->dbg_once) {
    h->dbg_once = 1;
    uint32_t o = sfpr_cosim_rd(h->s.rtl, SFPR_OUTSTANDING);
    printf("      [debug] NO_TAG first seen at op %lld (type %u): state %u outstanding %u boots %llu pf_pending %d"
           " ps_state %d warned %d mounted %d\n", (long long)h->op_id, op.type, sfci_state(&h->s), o & 0xFFu,
           (unsigned long long)h->s.boots, h->s.fw.pf_pending, h->s.fw.mounted ? sfftl_ps_state(&h->s.ftl) : -1,
           h->s.fw.mounted ? h->s.ftl.ps_warned : -1, h->s.fw.mounted);
    printf("      [debug]   pf_asserted %d pf_at_op %llu nand_ops %llu T_PF_EVENTS %u T_RESTORES %u IRQ_ST 0x%x CFG 0x%x"
           " RET_PF_COUNT %u T_RECOVERIES %u T_LATE %u\n", h->s.pf_asserted, (unsigned long long)h->s.pf_at_op,
           (unsigned long long)h->s.nand_ops, sfpr_cosim_rd(h->s.rtl, SFPR_T_PF_EVENTS), sfpr_cosim_rd(h->s.rtl, SFPR_T_RESTORES),
           sfpr_cosim_rd(h->s.rtl, SFPR_IRQ_STATUS), sfpr_cosim_rd(h->s.rtl, SFPR_CFG), sfpr_cosim_rd(h->s.rtl, SFPR_RET_PF_COUNT),
           sfpr_cosim_rd(h->s.rtl, SFPR_T_RECOVERIES), sfpr_cosim_rd(h->s.rtl, SFPR_T_LATE_FW));
  }
  if (sfpr_cosim_rtl_errors(h->s.rtl)) { hc_fail(h, "RTL assertion failed"); return -1; }
  return 0;
}

typedef struct { int rc; } sd_t;
static void shutdown_fn(sfci_sys_t *s, void *arg) { ((sd_t *)arg)->rc = sfps_shutdown(&s->fw); }

int hc_clean_cycle(hc_t *h) {
  if (h->failed) return -1;
  if (h->r.doubt && verify(h, 0) < 0) return -1;
  sfftl_space_t sp;
  sfftl_space(&h->s.ftl, &sp);
  if (sp.read_only && sfci_state(&h->s) != SFPR_STATE_RUN_RO) {
    hc_fail(h, "FTL read-only but the controller is not in RUN_RO (state %u)", sfci_state(&h->s));
    return -1;
  }
  sd_t a = { -1 };
  int k = sfci_run(&h->s, shutdown_fn, &a);
  if (k != 0) { h->crashes++; return hc_recover(h, k); }
  if (a.rc != SFFTL_OK) { hc_fail(h, "shutdown: %s", sfftl_strerror(a.rc)); return -1; }
  hc_collect(h);
  if (sfci_state(&h->s) != SFPR_STATE_SHUTDOWN) { hc_fail(h, "controller not in SHUTDOWN"); return -1; }
  sample_err(h);
  simnand_power_off(h->s.nand);
  int rc = sfci_recover(&h->s, SFCI_ABANDON_POWER, 2);
  if (rc < 0) { hc_fail(h, "boot after clean shutdown: %d", rc); return -1; }
  /* a read-only (worn-out) FTL cannot write its clean checkpoint: the next mount rolls forward, which is safe */
  if (sfftl_stats(&h->s.ftl)->last_mount_kind != 0 && !sp.read_only) {
    const sfftl_stats_t *st = sfftl_stats(&h->s.ftl);
    hc_fail(h, "mount after clean shutdown was not clean (kind %u, newer commits rejected %u, gen %u, read errors %llu,"
            " corrected %llu)", st->last_mount_kind, st->last_mount_ckpt_rejected, st->last_mount_ckpt_gen,
            (unsigned long long)st->read_uncorrectable, (unsigned long long)st->read_corrected);
    return -1;
  }
  return verify(h, 1);
}
