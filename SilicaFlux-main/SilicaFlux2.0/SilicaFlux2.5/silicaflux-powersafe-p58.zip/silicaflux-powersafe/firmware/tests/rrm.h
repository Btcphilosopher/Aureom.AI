/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- recovery reference model (tests only)
 *
 * Independent of the FTL, the firmware layer and the RTL.  It knows only what
 * the HOST knows: which commands it issued and which of them it saw complete
 * with SUCCESS.
 *
 *   acked[l]   version of LBA l the host last got a SUCCESS completion for
 *              (0 = never written / deallocated -> must read zeros)
 *   doubt      the one command that was in flight without a SUCCESS completion
 *              (crash, power-fault abort, error): after recovery each LOGICAL
 *              PAGE it touched must hold either entirely its old acknowledged
 *              contents or entirely the command's new contents (page atomicity;
 *              a multi-page command is not atomic as a whole -- documented
 *              contract).  The first verification resolves the doubt; from then
 *              on the observed value is the acknowledged one (no flip-flopping
 *              across later recoveries).
 *
 * Data of (LBA, version) is a deterministic pattern, so the model stores 4 bytes
 * per LBA, not the data.
 * ===========================================================================*/
#ifndef RRM_H
#define RRM_H

#include <stdint.h>

typedef struct {
  uint64_t nlba;
  uint32_t lba_bytes, spp;        /* LBAs per logical page */
  uint32_t *acked;
  uint32_t next_ver;
  int      doubt;                 /* a command is in doubt */
  uint64_t d_lba;
  uint32_t d_n, d_ver;            /* d_ver 0 = TRIM (zeros) */
  /* statistics */
  uint64_t acks, doubts, resolved_new, resolved_old, resolved_both, lba_checks, page_checks;
  char     why[256];
} rrm_t;

int  rrm_init(rrm_t *r, uint64_t nlba, uint32_t lba_bytes, uint32_t page_bytes);
void rrm_free(rrm_t *r);
void rrm_fill(const rrm_t *r, uint64_t lba, uint32_t ver, uint8_t *out);   /* one LBA */

/* a command starts (it may later be acknowledged or left in doubt) */
void rrm_begin_write(rrm_t *r, uint64_t lba, uint32_t n, uint8_t *data);   /* fills data */
void rrm_begin_trim(rrm_t *r, uint64_t lba, uint32_t n);
void rrm_ack(rrm_t *r);                  /* SUCCESS completion seen */
void rrm_not_acked(rrm_t *r);            /* no SUCCESS: the command stays in doubt */

/* verification: read callback reads [lba, lba+n) into buf, returns 0 on success */
typedef int (*rrm_read_fn)(void *ctx, uint64_t lba, uint32_t n, uint8_t *buf);
/* every LBA of the device; resolves the doubt.  Returns the number of violating
 * logical pages (first one described in r->why), or -1 on a read error. */
int  rrm_verify_all(rrm_t *r, rrm_read_fn rd, void *ctx, uint8_t *scratch);
/* only the pages touched by the command in doubt (resolve without a crash) */
int  rrm_resolve(rrm_t *r, rrm_read_fn rd, void *ctx, uint8_t *scratch);

#endif
