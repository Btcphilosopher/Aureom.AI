/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- crash-injection framework (host only)
 *
 * One "system" = persistent NAND backing store (simnand, survives everything
 * except an erase) + the Verilator model of silicaflux_storage_recovery + the
 * firmware (PowerSafe layer sfps + FlashMap FTL) + a host model.
 *
 * Crashes are DETERMINISTIC: the controller's crash-injection unit is armed with
 * (point, N-th occurrence, action) through its registers; the firmware forwards
 * every FTL persistence event to CP_EVENT; the NAND-controller model reports
 * every operation start.  When the unit fires:
 *   CUT_NOW / CUT_NEXT_* : the supply is lost -- a NAND operation in progress is
 *                          torn (simnand interrupts it), the firmware context is
 *                          ABANDONED at that instruction (longjmp: RAM gone), the
 *                          controller gets a power-on reset (registers, retention
 *                          and telemetry gone), the NAND keeps its contents;
 *   CPU_RESET            : the firmware context is abandoned, the NAND op in
 *                          flight completes, the controller runs its reset
 *                          sequence (retention and telemetry kept).
 * A power-fault WARNING can also be scheduled (pwr_fail pin at the N-th NAND
 * operation), followed by a real loss after D clocks or by a brown-out restore.
 * ===========================================================================*/
#ifndef SFCI_H
#define SFCI_H

#include <setjmp.h>
#include <stdint.h>
#include "sfftl.h"
#include "simnand.h"
#include "sfps.h"
#include "sfpr_cosim.h"

#define SFCI_ABANDON_POWER 1
#define SFCI_ABANDON_CPU   2

typedef struct sfci_sys {
  /* configuration */
  sfftl_geom_t  g;
  sfftl_cfg_t   fcfg;
  simnand_cfg_t ncfg;
  sfps_cfg_t    pcfg;
  uint64_t      seed;
  uint32_t      busy_clocks;           /* NAND busy time in controller clocks */
  /* components */
  simnand_t    *nand;
  sfpr_cosim_t *rtl;
  sfftl_hal_t   nhal;                  /* simnand */
  sfftl_hal_t   hal;                   /* gated by the controller (NAND-controller model) */
  sfps_bus_t    bus;
  sfps_t        fw;
  sfftl_t       ftl;
  void         *arena;
  size_t        arena_bytes;
  /* abandonment */
  jmp_buf       env;
  int           env_armed;
  int           abandon_kind;
  /* power-fault warning schedule */
  uint64_t      pf_at_op;              /* assert pwr_fail when NAND op #pf_at_op starts (0 = never) */
  uint64_t      die_at_cycle;          /* real power loss at this controller cycle (0 = never) */
  int           pf_asserted;
  uint64_t      die_after_pf;          /* real power loss this many clocks after the warning (0 = brown-out) */
  /* called before every firmware boot in sfci_recover (attempt 0, 1, ...): arm nested crashes */
  void        (*boot_hook)(struct sfci_sys *s, void *arg, uint32_t attempt);
  void         *boot_hook_arg;
  /* FTL event observer installed into every firmware instance (verification only) */
  void        (*observer)(void *octx, uint32_t ev, uint32_t arg);
  void         *octx;
  /* interrupt delivery latency: the firmware sees a raised interrupt line only after this many
   * further NAND operations (0 = immediately) -- models the race between the controller refusing
   * operations and the firmware learning about the fault */
  uint32_t      irq_latency_ops;
  uint32_t      irq_latency_cycles;    /* ... or after this many controller clocks, whichever comes first */
  int64_t       irq_seen_op;           /* NAND op count when the line was first seen high, -1 = low */
  uint64_t      irq_seen_cycle;
  /* counters */
  uint64_t nand_ops, nand_refused, tears, power_cuts, cpu_resets, boots, crash_fired, deaths;
  uint64_t ops_in_pf, progs_in_pf;     /* NAND ops started while the controller was in a PF state */
  uint64_t nand_ops_at_pf, progs_at_pf_device;   /* simnand program count when the warning arrived */
  uint64_t boot_cycles_last, boot_ops_last, boot_ns_last;
  uint32_t nested_boot_crashes;
  /* host side */
  int64_t  tag_owner[16];
} sfci_sys_t;

/* create a powered-on, factory-fresh system and format it (controller boots to RUN) */
int  sfci_create(sfci_sys_t *s, const sfftl_geom_t *g, const sfftl_cfg_t *fcfg, const simnand_cfg_t *ncfg,
                 const sfps_cfg_t *pcfg, uint64_t seed);
void sfci_destroy(sfci_sys_t *s);

/* arm the controller's crash-injection unit */
void sfci_arm(sfci_sys_t *s, uint32_t point, uint32_t count, uint32_t action);
void sfci_disarm(sfci_sys_t *s);

/* run fn(s, arg) as firmware: returns 0 if it completed, SFCI_ABANDON_* if the
 * firmware context was lost (crash / power loss) */
typedef void (*sfci_fw_fn)(sfci_sys_t *s, void *arg);
int  sfci_run(sfci_sys_t *s, sfci_fw_fn fn, void *arg);

/* after an abandonment (or any time): bring the system back -- power on if
 * needed, run the controller to RECOVERY, boot the firmware (recovery mount).
 * Crashes during recovery are handled (up to max_nested).  Returns the mount
 * status of the final, completed boot (or a negative value if none completed). */
int  sfci_recover(sfci_sys_t *s, int abandon_kind, uint32_t max_nested);

/* orderly power cycle: clean shutdown, power loss, boot (clean mount) */
int  sfci_clean_power_cycle(sfci_sys_t *s);

/* let `cycles` controller clocks pass while the firmware runs its idle main loop (sfps_poll every 16
 * clocks, when it is alive).  Returns 0, or SFCI_ABANDON_* if the system died / the CPU was reset meanwhile
 * (the caller then runs sfci_recover). */
int  sfci_idle(sfci_sys_t *s, uint32_t cycles);

/* host completion queue entries seen since the last call */
uint32_t sfci_cq_take(sfci_sys_t *s, sfpr_cq_entry_t *out, uint32_t max);

uint32_t sfci_state(sfci_sys_t *s);   /* controller FSM state (register read, not firmware) */

#endif
