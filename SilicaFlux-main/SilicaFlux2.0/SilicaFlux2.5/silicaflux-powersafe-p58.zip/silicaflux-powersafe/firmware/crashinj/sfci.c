/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- crash-injection framework (see sfci.h)
 * ===========================================================================*/
#include "sfci.h"
#include <stdlib.h>
#include <string.h>

/* ---------------------------------------------------------------- abandonment */
static void abandon(sfci_sys_t *s, int kind) {
  s->abandon_kind = kind;
  if (s->env_armed) {
    s->env_armed = 0;
    longjmp(s->env, kind);
  }
}

static void power_lost(sfci_sys_t *s) {
  if (simnand_powered(s->nand)) simnand_power_off(s->nand);
  s->power_cuts++;
  abandon(s, SFCI_ABANDON_POWER);
}

static void check_death(sfci_sys_t *s, uint32_t lookahead) {
  if (s->die_at_cycle && sfpr_cosim_cycles(s->rtl) + lookahead >= s->die_at_cycle) {
    s->die_at_cycle = 0;
    s->deaths++;
    power_lost(s);
  }
}

static void check_crash(sfci_sys_t *s) {
  uint32_t act;
  if (!sfpr_cosim_take_crash(s->rtl, &act)) return;
  s->crash_fired++;
  if (act == SFPR_CI_ACTION_CPU_RESET) { s->cpu_resets++; abandon(s, SFCI_ABANDON_CPU); return; }
  power_lost(s);
}

/* ---------------------------------------------------------------- register bus (firmware view) */
static uint32_t bus_rd(void *ctx, uint32_t off) {
  sfci_sys_t *s = (sfci_sys_t *)ctx;
  check_death(s, 0);
  uint32_t v = sfpr_cosim_rd(s->rtl, off);
  check_crash(s);
  return v;
}

static void bus_wr(void *ctx, uint32_t off, uint32_t v) {
  sfci_sys_t *s = (sfci_sys_t *)ctx;
  check_death(s, 0);
  sfpr_cosim_wr(s->rtl, off, v);
  check_crash(s);
}

/* interrupt line as the firmware sees it: delayed by irq_latency_ops NAND operations */
static int irq_visible(sfci_sys_t *s) {
  if (!sfpr_cosim_irq(s->rtl)) { s->irq_seen_op = -1; return 0; }
  uint64_t now = sfpr_cosim_cycles(s->rtl);
  if (s->irq_seen_op < 0) { s->irq_seen_op = (int64_t)s->nand_ops; s->irq_seen_cycle = now; }
  return (uint64_t)((int64_t)s->nand_ops - s->irq_seen_op) >= s->irq_latency_ops ||
         now - s->irq_seen_cycle >= s->irq_latency_cycles;
}

static int bus_irq(void *ctx) {
  sfci_sys_t *s = (sfci_sys_t *)ctx;
  return irq_visible(s);
}

/* ---------------------------------------------------------------- NAND controller model, gated by the RTL */
#define G_REFUSED 0
#define G_OK      1
#define G_CPU     2
#define G_TEAR    3

static int gate(sfci_sys_t *s, uint32_t kind) {
  check_death(s, 0);
  if (s->pf_at_op && !s->pf_asserted && s->nand_ops + 1u >= s->pf_at_op) {
    sfpr_cosim_set_pwr_fail(s->rtl, 1);           /* the supervisor's warning arrives with this op */
    s->pf_asserted = 1;
    s->nand_ops_at_pf = s->nand_ops;
    const simnand_stats_t *ns = simnand_stats(s->nand);
    s->progs_at_pf_device = ns->programs + ns->erases;
    if (s->die_after_pf) s->die_at_cycle = sfpr_cosim_cycles(s->rtl) + s->die_after_pf;
  }
  int ok = sfpr_cosim_nand_begin(s->rtl, kind);
  if (!ok) { s->nand_refused++; return G_REFUSED; }
  s->nand_ops++;
  if (sfpr_cosim_host_status(s->rtl) & 0x2u) { s->ops_in_pf++; if (kind) s->progs_in_pf++; }
  uint32_t act;
  if (sfpr_cosim_take_crash(s->rtl, &act)) {
    s->crash_fired++;
    if (act == SFPR_CI_ACTION_CPU_RESET) return G_CPU;   /* the op completes on its own */
    /* how the operation tears (not started / completed / almost done / torn, spare intact or not, ECC passes
     * or not) is drawn from a generator seeded by the crash position: deterministic, but varied */
    simnand_reseed(s->nand, (s->seed + 1u) * 0x9E3779B97F4A7C15ull ^ (s->nand_ops * 0xD1B54A32D192ED03ull) ^ s->tears);
    simnand_arm_powercut(s->nand, 0);                   /* the supply dies during this op */
    s->tears++;
    return G_TEAR;
  }
  if (s->die_at_cycle && sfpr_cosim_cycles(s->rtl) + s->busy_clocks >= s->die_at_cycle) {
    s->die_at_cycle = 0;
    s->deaths++;
    simnand_reseed(s->nand, (s->seed + 7u) * 0x9E3779B97F4A7C15ull ^ (s->nand_ops * 0xD1B54A32D192ED03ull));
    simnand_arm_powercut(s->nand, 0);
    s->tears++;
    return G_TEAR;
  }
  return G_OK;
}

static int after(sfci_sys_t *s, int g, int rc) {
  if (g == G_TEAR) power_lost(s);
  sfpr_cosim_nand_end(s->rtl, s->busy_clocks);
  if (g == G_CPU) { s->cpu_resets++; abandon(s, SFCI_ABANDON_CPU); }
  if (s->fw.f && irq_visible(s)) sfps_isr(&s->fw);              /* interrupt delivered after the op */
  return rc;
}

static int w_read(void *ctx, uint32_t ppn, void *data, void *spare, uint32_t *bf) {
  sfci_sys_t *s = (sfci_sys_t *)ctx;
  int g = gate(s, 0);
  if (g == G_REFUSED) return SFFTL_HAL_WRITE_PROTECT;
  int rc = s->nhal.read(s->nhal.ctx, ppn, data, spare, bf);
  return after(s, g, rc);
}

static int w_program(void *ctx, uint32_t ppn, const void *data, const void *spare) {
  sfci_sys_t *s = (sfci_sys_t *)ctx;
  int g = gate(s, 1);
  if (g == G_REFUSED) return SFFTL_HAL_WRITE_PROTECT;
  int rc = s->nhal.program(s->nhal.ctx, ppn, data, spare);
  return after(s, g, rc);
}

static int w_erase(void *ctx, uint32_t pbn) {
  sfci_sys_t *s = (sfci_sys_t *)ctx;
  int g = gate(s, 2);
  if (g == G_REFUSED) return SFFTL_HAL_WRITE_PROTECT;
  int rc = s->nhal.erase(s->nhal.ctx, pbn);
  return after(s, g, rc);
}

static int w_marker(void *ctx, uint32_t ppn, uint8_t *m) {
  sfci_sys_t *s = (sfci_sys_t *)ctx;
  int g = gate(s, 0);
  if (g == G_REFUSED) return SFFTL_HAL_WRITE_PROTECT;
  int rc = s->nhal.read_marker(s->nhal.ctx, ppn, m);
  return after(s, g, rc);
}

static void w_wp(void *ctx, int enable) { (void)ctx; (void)enable; }   /* WP# is driven by the controller */

/* ---------------------------------------------------------------- run as firmware */
int sfci_run(sfci_sys_t *s, sfci_fw_fn fn, void *arg) {
  s->abandon_kind = 0;
  int k = setjmp(s->env);
  if (k == 0) {
    s->env_armed = 1;
    fn(s, arg);
    s->env_armed = 0;
    return s->abandon_kind;      /* an abandonment outside longjmp reach (none expected) */
  }
  s->env_armed = 0;
  return k;
}

uint32_t sfci_state(sfci_sys_t *s) { return SFPR_GET(sfpr_cosim_rd(s->rtl, SFPR_STATE), STATE, FSM); }

static int wait_recovery(sfci_sys_t *s) {
  for (uint32_t i = 0; i < 200000u; i++) {
    sfpr_cosim_tick(s->rtl, 1);
    if (!sfpr_cosim_sub_reset(s->rtl) && (i & 7u) == 7u && sfci_state(s) == SFPR_STATE_RECOVERY) return 0;
  }
  return -1;
}

typedef struct { int rc; } boot_arg_t;

static void boot_fn(sfci_sys_t *s, void *arg) {
  boot_arg_t *a = (boot_arg_t *)arg;
  if (sfps_init(&s->fw, &s->bus, &s->pcfg, &s->ftl, &s->g, &s->fcfg, &s->hal, s->arena, s->arena_bytes) != 0) {
    a->rc = -1000;
    return;
  }
  s->fw.observer = s->observer;
  s->fw.octx = s->octx;
  a->rc = sfps_boot(&s->fw);
}

static void format_fn(sfci_sys_t *s, void *arg) {
  boot_arg_t *a = (boot_arg_t *)arg;
  if (sfps_init(&s->fw, &s->bus, &s->pcfg, &s->ftl, &s->g, &s->fcfg, &s->hal, s->arena, s->arena_bytes) != 0) {
    a->rc = -1000;
    return;
  }
  s->fw.observer = s->observer;
  s->fw.octx = s->octx;
  a->rc = sfps_format(&s->fw);
}

void sfci_arm(sfci_sys_t *s, uint32_t point, uint32_t count, uint32_t action) {
  sfpr_cosim_wr(s->rtl, SFPR_CI_COUNT, count ? count : 1u);
  sfpr_cosim_wr(s->rtl, SFPR_CI_CTRL, SFPR_FLD(CI_CTRL, ARM, 1u) | SFPR_FLD(CI_CTRL, ACTION, action) |
                                      SFPR_FLD(CI_CTRL, POINT, point));
}

void sfci_disarm(sfci_sys_t *s) { sfpr_cosim_wr(s->rtl, SFPR_CI_CTRL, 0); }

int sfci_recover(sfci_sys_t *s, int kind, uint32_t max_nested) {
  for (uint32_t n = 0;; n++) {
    s->die_at_cycle = 0;
    if (kind == SFCI_ABANDON_POWER) {
      simnand_disarm_powercut(s->nand);
      if (!simnand_powered(s->nand)) simnand_power_on(s->nand);
      sfpr_cosim_set_pwr_fail(s->rtl, 0);
      s->pf_asserted = 0;
      s->pf_at_op = 0;
      sfpr_cosim_power_on_reset(s->rtl);         /* the controller lost everything too */
    } else if (s->pf_asserted) {
      sfpr_cosim_set_pwr_fail(s->rtl, 0);        /* brown-out over */
      s->pf_asserted = 0;
      s->pf_at_op = 0;
    }
    s->fw.f = NULL;
    s->irq_seen_op = -1;
    if (wait_recovery(s) != 0) return -2000;
    if (s->boot_hook) s->boot_hook(s, s->boot_hook_arg, n);
    uint64_t c0 = sfpr_cosim_cycles(s->rtl), o0 = s->nand_ops, t0 = simnand_stats(s->nand)->time_ns;
    s->boots++;
    boot_arg_t a = { -3000 };
    int k = sfci_run(s, boot_fn, &a);
    if (k == 0) {
      s->boot_cycles_last = sfpr_cosim_cycles(s->rtl) - c0;
      s->boot_ops_last = s->nand_ops - o0;
      s->boot_ns_last = simnand_stats(s->nand)->time_ns - t0;
      return a.rc;
    }
    s->nested_boot_crashes++;
    kind = k;
    if (n >= max_nested) return -4000;
  }
}

typedef struct { int rc; } sd_arg_t;
static void shutdown_fn(sfci_sys_t *s, void *arg) { ((sd_arg_t *)arg)->rc = sfps_shutdown(&s->fw); }

int sfci_clean_power_cycle(sfci_sys_t *s) {
  sd_arg_t a = { -1 };
  int k = sfci_run(s, shutdown_fn, &a);
  if (k != 0) return sfci_recover(s, k, 4);
  if (a.rc != SFFTL_OK) return a.rc;
  simnand_power_off(s->nand);
  return sfci_recover(s, SFCI_ABANDON_POWER, 4);
}

uint32_t sfci_cq_take(sfci_sys_t *s, sfpr_cq_entry_t *out, uint32_t max) { return sfpr_cosim_cq_pop(s->rtl, out, max); }

static void idle_fn(sfci_sys_t *s, void *arg) { (void)arg; (void)sfps_poll(&s->fw); }

int sfci_idle(sfci_sys_t *s, uint32_t cycles) {
  uint64_t end = sfpr_cosim_cycles(s->rtl) + cycles;
  while (sfpr_cosim_cycles(s->rtl) < end) {
    if (s->die_at_cycle && sfpr_cosim_cycles(s->rtl) >= s->die_at_cycle) {
      s->die_at_cycle = 0;
      s->deaths++;
      if (simnand_powered(s->nand)) simnand_power_off(s->nand);
      s->power_cuts++;
      return SFCI_ABANDON_POWER;
    }
    sfpr_cosim_tick(s->rtl, 16);
    if (s->fw.f && s->fw.mounted && !sfpr_cosim_sub_reset(s->rtl)) {
      int k = sfci_run(s, idle_fn, NULL);
      if (k) return k;
    }
  }
  return 0;
}

int sfci_create(sfci_sys_t *s, const sfftl_geom_t *g, const sfftl_cfg_t *fcfg, const simnand_cfg_t *ncfg,
                const sfps_cfg_t *pcfg, uint64_t seed) {
  memset(s, 0, sizeof(*s));
  s->g = *g;
  s->fcfg = *fcfg;
  s->pcfg = *pcfg;
  s->seed = seed;
  s->busy_clocks = 4;
  s->irq_seen_op = -1;
  s->irq_latency_cycles = 64;
  if (ncfg) s->ncfg = *ncfg;
  else simnand_cfg_default(&s->ncfg, g->page_data_bytes, g->pages_per_block, g->blocks);
  s->ncfg.page_spare_bytes = g->page_spare_bytes;
  s->nand = simnand_create(&s->ncfg, seed * 7919u + 1u);
  if (!s->nand) return -1;
  simnand_manufacture(s->nand);
  simnand_hal(s->nand, &s->nhal);
  s->hal = s->nhal;
  s->hal.ctx = s;
  s->hal.read = w_read;
  s->hal.program = w_program;
  s->hal.erase = w_erase;
  s->hal.read_marker = w_marker;
  s->hal.write_protect = w_wp;
  s->bus.rd = bus_rd;
  s->bus.wr = bus_wr;
  s->bus.irq = bus_irq;
  s->bus.ctx = s;
  s->arena_bytes = sfftl_mem_required(g, fcfg);
  if (!s->arena_bytes) return -2;
  s->arena = aligned_alloc(8, (s->arena_bytes + 7u) & ~(size_t)7u);
  s->rtl = sfpr_cosim_create();
  if (!s->arena || !s->rtl) return -3;
  sfpr_cosim_set_nand_busy_clocks(s->rtl, s->busy_clocks);
  for (int i = 0; i < 16; i++) s->tag_owner[i] = -1;
  if (wait_recovery(s) != 0) return -4;
  boot_arg_t a = { -1 };
  if (sfci_run(s, format_fn, &a) != 0) return -5;
  return a.rc;
}

void sfci_destroy(sfci_sys_t *s) {
  if (s->rtl) sfpr_cosim_destroy(s->rtl);
  if (s->nand) simnand_destroy(s->nand);
  free(s->arena);
  memset(s, 0, sizeof(*s));
}
