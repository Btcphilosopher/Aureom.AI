# PowerSafe firmware tree

| Directory | Contents |
|---|---|
| `silicaflux_ftl/` | FlashMap FTL (Project 56) **extended by Project 58**: event hooks, dual checkpoint, journal mirror, write verify, diagnostics, refused-operation semantics (docs/04). Its own P56 test suite is kept: `make -C silicaflux_ftl test` (add `--p58` to the binary to run it with the P58 flags). |
| `powersafe/` | `sfps` — the PowerSafe firmware layer for the ControlCore: command execution with persistence phases, completion through the controller's acknowledgement gate, power-fault handler, recovery manager, degradation reporting. `include/generated/sfpr_regs.h` is generated from `config/sfpr_regmap.py`. |
| `crashinj/` | `sfci` — crash-injection framework (host only): system = Verilated controller + firmware + persistent simulated NAND; abandonment by `longjmp`; NAND-controller model gated by the RTL; interrupt latency; idle main loop. |
| `tests/` | `rrm` recovery reference model, `hc` host model, `test_recovery` campaigns and `--perf` measurements. |
| `fw/` | RV32IM size build for the ControlCore (`make -C fw`) and the MMIO register-bus binding `sfps_mmio.c`. |

Build and run from the project root: `make cosim`, `make test`, `make quick`, `make sanitize`, `make perf`.
