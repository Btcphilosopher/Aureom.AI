// =============================================================================
// SilicaFlux PowerSafe (Project 58) -- co-simulation wrapper around the Verilated RTL
// =============================================================================
#include "sfpr_cosim.h"
#include "Vsilicaflux_storage_recovery.h"
#include "verilated.h"
#include <cstdlib>
#include <cstring>

struct sfpr_cosim {
  VerilatedContext *ctx;
  Vsilicaflux_storage_recovery *m;
  uint64_t cycles;
  int last_err;
  int crash_seen;
  uint32_t crash_action;
  uint32_t busy_clocks;
  sfpr_cq_entry_t cq[SFPR_COSIM_CQ_MAX];
  uint32_t cq_n;
};

static void half(sfpr_cosim_t *c, int clk) {
  c->m->clk = clk;
  c->m->eval();
}

void sfpr_cosim_tick(sfpr_cosim_t *c, uint32_t n) {
  for (uint32_t i = 0; i < n; i++) {
    // sample outputs that are registered on the previous edge (valid during this cycle)
    half(c, 0);
    if (c->m->crash_req_o) { c->crash_seen = 1; c->crash_action = c->m->crash_action_o; }
    if (c->m->cq_valid_o && c->m->cq_ready_i && c->m->por_ni && c->cq_n < SFPR_COSIM_CQ_MAX) {
      c->cq[c->cq_n].tag = c->m->cq_tag_o;
      c->cq[c->cq_n].status = c->m->cq_status_o;
      c->cq[c->cq_n].cycle = c->cycles;
      c->cq_n++;
    }
    half(c, 1);
    c->cycles++;
    c->ctx->timeInc(1);
  }
}

extern "C" sfpr_cosim_t *sfpr_cosim_create(void) {
  sfpr_cosim_t *c = new sfpr_cosim();
  c->ctx = new VerilatedContext;
  c->ctx->errorLimit(1000000);          // count RTL $error, do not stop
  c->ctx->fatalOnError(false);
  c->m = new Vsilicaflux_storage_recovery(c->ctx);
  c->cycles = 0; c->last_err = 0; c->crash_seen = 0; c->crash_action = 0; c->busy_clocks = 4; c->cq_n = 0;
  c->m->clk = 0;
  c->m->por_ni = 0; c->m->rst_ni = 1; c->m->pwr_fail_ni = 1; c->m->cap_ok_i = 0;
  c->m->host_rst_req_i = 0; c->m->wdt_rst_req_i = 0;
  c->m->rb_sel = 0; c->m->rb_we = 0; c->m->rb_addr = 0; c->m->rb_wdata = 0;
  c->m->cmd_valid_i = 0; c->m->cmd_kind_i = 0; c->m->cmd_fua_i = 0;
  c->m->ev_valid_i = 0; c->m->ev_tag_i = 0; c->m->ev_phase_i = 0;
  c->m->cq_ready_i = 1;
  c->m->nand_busy_i = 0; c->m->nand_start_i = 0; c->m->nand_kind_i = 0;
  sfpr_cosim_power_on_reset(c);
  return c;
}

extern "C" void sfpr_cosim_destroy(sfpr_cosim_t *c) {
  if (!c) return;
  c->m->final();
  delete c->m;
  delete c->ctx;
  delete c;
}

extern "C" uint64_t sfpr_cosim_cycles(const sfpr_cosim_t *c) { return c->cycles; }

extern "C" void sfpr_cosim_power_on_reset(sfpr_cosim_t *c) {
  c->m->por_ni = 0;
  c->m->nand_busy_i = 0; c->m->nand_start_i = 0;
  sfpr_cosim_tick(c, 3);
  c->m->por_ni = 1;
  sfpr_cosim_tick(c, 3);
  c->crash_seen = 0;
}

extern "C" void sfpr_cosim_ext_reset(sfpr_cosim_t *c) {
  c->m->rst_ni = 0;
  sfpr_cosim_tick(c, 3);
  c->m->rst_ni = 1;
  sfpr_cosim_tick(c, 3);
}

extern "C" void sfpr_cosim_set_pwr_fail(sfpr_cosim_t *c, int failing) { c->m->pwr_fail_ni = failing ? 0 : 1; }
extern "C" void sfpr_cosim_set_cap_ok(sfpr_cosim_t *c, int ok) { c->m->cap_ok_i = ok ? 1 : 0; }
extern "C" void sfpr_cosim_host_reset(sfpr_cosim_t *c) {
  c->m->host_rst_req_i = 1; sfpr_cosim_tick(c, 1); c->m->host_rst_req_i = 0; sfpr_cosim_tick(c, 1);
}
extern "C" void sfpr_cosim_wdt(sfpr_cosim_t *c, int level) { c->m->wdt_rst_req_i = level ? 1 : 0; }

extern "C" uint32_t sfpr_cosim_rd(sfpr_cosim_t *c, uint32_t off) {
  c->m->rb_sel = 1; c->m->rb_we = 0; c->m->rb_addr = off & 0xFFFu;
  half(c, c->m->clk);                    // combinational read
  uint32_t v = c->m->rb_rdata;
  c->last_err = c->m->rb_err;
  sfpr_cosim_tick(c, 1);
  c->m->rb_sel = 0;
  return v;
}

extern "C" void sfpr_cosim_wr(sfpr_cosim_t *c, uint32_t off, uint32_t v) {
  c->m->rb_sel = 1; c->m->rb_we = 1; c->m->rb_addr = off & 0xFFFu; c->m->rb_wdata = v;
  half(c, c->m->clk);
  c->last_err = c->m->rb_err;
  sfpr_cosim_tick(c, 1);
  c->m->rb_sel = 0; c->m->rb_we = 0;
  sfpr_cosim_tick(c, 1);                 // let registered effects (crash_req, CQ) become visible
}

extern "C" int sfpr_cosim_last_err(const sfpr_cosim_t *c) { return c->last_err; }
extern "C" int sfpr_cosim_sub_reset(const sfpr_cosim_t *c) { return !c->m->sub_rst_no; }
extern "C" int sfpr_cosim_prog_ok(const sfpr_cosim_t *c) { return c->m->nand_prog_ok_o; }
extern "C" int sfpr_cosim_read_ok(const sfpr_cosim_t *c) { return c->m->nand_read_ok_o; }
extern "C" int sfpr_cosim_wp(const sfpr_cosim_t *c) { return !c->m->wp_no; }
extern "C" int sfpr_cosim_irq(const sfpr_cosim_t *c) { return c->m->irq_o; }
extern "C" uint32_t sfpr_cosim_host_status(const sfpr_cosim_t *c) { return c->m->host_status_o; }

extern "C" void sfpr_cosim_set_nand_busy_clocks(sfpr_cosim_t *c, uint32_t n) { c->busy_clocks = n ? n : 1; }

extern "C" int sfpr_cosim_nand_begin(sfpr_cosim_t *c, uint32_t kind) {
  half(c, c->m->clk);
  int ok = (kind == 0) ? c->m->nand_read_ok_o : c->m->nand_prog_ok_o;
  if (!ok) return 0;
  c->m->nand_start_i = 1; c->m->nand_kind_i = kind & 3u; c->m->nand_busy_i = 1;
  sfpr_cosim_tick(c, 1);
  c->m->nand_start_i = 0;
  sfpr_cosim_tick(c, 1);
  return 1;
}

extern "C" void sfpr_cosim_nand_force_start(sfpr_cosim_t *c, uint32_t kind) {
  c->m->nand_start_i = 1; c->m->nand_kind_i = kind & 3u; c->m->nand_busy_i = 1;
  sfpr_cosim_tick(c, 1);
  c->m->nand_start_i = 0;
  sfpr_cosim_tick(c, 1);
  c->m->nand_busy_i = 0;
  sfpr_cosim_tick(c, 1);
}

extern "C" void sfpr_cosim_nand_end(sfpr_cosim_t *c, uint32_t busy) {
  sfpr_cosim_tick(c, busy ? busy : c->busy_clocks);
  c->m->nand_busy_i = 0;
  sfpr_cosim_tick(c, 1);
}

extern "C" int sfpr_cosim_take_crash(sfpr_cosim_t *c, uint32_t *action) {
  int s = c->crash_seen;
  if (s && action) *action = c->crash_action;
  c->crash_seen = 0;
  return s;
}

extern "C" uint32_t sfpr_cosim_cq_pop(sfpr_cosim_t *c, sfpr_cq_entry_t *out, uint32_t max) {
  uint32_t n = c->cq_n < max ? c->cq_n : max;
  if (n) memcpy(out, c->cq, n * sizeof(*out));
  if (n < c->cq_n) memmove(c->cq, c->cq + n, (c->cq_n - n) * sizeof(*out));
  c->cq_n -= n;
  return n;
}

extern "C" uint64_t sfpr_cosim_rtl_errors(const sfpr_cosim_t *c) { return c->ctx->errorCount(); }
