/* =============================================================================
 * SilicaFlux PowerSafe (Project 58) -- co-simulation API
 *
 * C interface to the Verilator model of silicaflux_storage_recovery.sv, so the
 * C firmware (FTL + PowerSafe layer) and the crash-injection harness drive the
 * real RTL: register page, NAND handshake pins, power-fail / reset pins,
 * completion queue, crash-request output.
 *
 * Time: one call to sfpr_cosim_tick() is one controller clock.  A register
 * access costs one clock; a NAND operation holds nand_busy for a configurable
 * number of clocks.  Cycle counts are a property of this harness, not of real
 * hardware timing (the NAND timing model lives in simnand).
 * ===========================================================================*/
#ifndef SFPR_COSIM_H
#define SFPR_COSIM_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct sfpr_cosim sfpr_cosim_t;

#define SFPR_COSIM_CQ_MAX 4096u

sfpr_cosim_t *sfpr_cosim_create(void);
void          sfpr_cosim_destroy(sfpr_cosim_t *c);

/* clocks */
void     sfpr_cosim_tick(sfpr_cosim_t *c, uint32_t n);
uint64_t sfpr_cosim_cycles(const sfpr_cosim_t *c);

/* resets / supply: por_ni and rst_ni are held low for a few cycles */
void sfpr_cosim_power_on_reset(sfpr_cosim_t *c);   /* real power loss + return: everything in the RTL lost */
void sfpr_cosim_ext_reset(sfpr_cosim_t *c);        /* external hard reset: retention kept */
void sfpr_cosim_set_pwr_fail(sfpr_cosim_t *c, int failing);   /* pwr_fail_ni = !failing */
void sfpr_cosim_set_cap_ok(sfpr_cosim_t *c, int ok);
void sfpr_cosim_host_reset(sfpr_cosim_t *c);        /* one-cycle host reset request */
void sfpr_cosim_wdt(sfpr_cosim_t *c, int level);

/* register page (one clock each) */
uint32_t sfpr_cosim_rd(sfpr_cosim_t *c, uint32_t off);
void     sfpr_cosim_wr(sfpr_cosim_t *c, uint32_t off, uint32_t v);
int      sfpr_cosim_last_err(const sfpr_cosim_t *c);   /* rb_err of the last access */

/* pins */
int sfpr_cosim_sub_reset(const sfpr_cosim_t *c);    /* 1 while sub_rst_no is asserted */
int sfpr_cosim_prog_ok(const sfpr_cosim_t *c);
int sfpr_cosim_read_ok(const sfpr_cosim_t *c);
int sfpr_cosim_wp(const sfpr_cosim_t *c);           /* 1 while WP# is asserted */
int sfpr_cosim_irq(const sfpr_cosim_t *c);
uint32_t sfpr_cosim_host_status(const sfpr_cosim_t *c);

/* NAND controller handshake.  begin(): samples the permission for `kind`
 * (0 read, 1 program, 2 erase); when permitted pulses nand_start, raises
 * nand_busy and clocks twice (the crash unit fires one clock after a start).
 * Returns 1 if permitted.  end(): holds busy for `busy` more clocks, then drops it. */
int  sfpr_cosim_nand_begin(sfpr_cosim_t *c, uint32_t kind);
void sfpr_cosim_nand_end(sfpr_cosim_t *c, uint32_t busy);
void sfpr_cosim_set_nand_busy_clocks(sfpr_cosim_t *c, uint32_t n);
/* a NAND controller that ignores the gate (fault model): pulse start regardless */
void sfpr_cosim_nand_force_start(sfpr_cosim_t *c, uint32_t kind);

/* crash request: 1 if crash_req_o pulsed since the last call (action in *action) */
int sfpr_cosim_take_crash(sfpr_cosim_t *c, uint32_t *action);

/* completion queue: every handshake (cq_ready is always 1) is logged */
typedef struct { uint32_t tag, status; uint64_t cycle; } sfpr_cq_entry_t;
uint32_t sfpr_cosim_cq_pop(sfpr_cosim_t *c, sfpr_cq_entry_t *out, uint32_t max);

/* RTL assertion failures seen ($error inside the RTL) */
uint64_t sfpr_cosim_rtl_errors(const sfpr_cosim_t *c);

#ifdef __cplusplus
}
#endif
#endif /* SFPR_COSIM_H */
