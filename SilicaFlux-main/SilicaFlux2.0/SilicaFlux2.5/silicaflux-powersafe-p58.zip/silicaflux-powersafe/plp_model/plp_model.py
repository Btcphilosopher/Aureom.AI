#!/usr/bin/env python3
# =============================================================================
# SilicaFlux PowerSafe (Project 58) -- capacitor-backed PLP RESEARCH model
#
#   python3 plp_model/plp_model.py --config plp_model/plp_config.json --out reports/plp
#
# Sizes the hold-up energy a power-loss-protected write cache WOULD need, from
# the firmware's worst-case flush work and placeholder electrical values, across
# temperature and capacitor ageing.  Standard library only (SVG charts by hand).
#
# STATUS: estimates.  No SilicaFlux board, regulator, capacitor bank or power
# measurement exists.  The output is a sizing method and a qualification plan,
# not a qualified design -- the RTL keeps PLP_PRESENT = 0.
# =============================================================================
import argparse
import json
import math
import os


def derate(table, t):
    pts = sorted((float(k), v) for k, v in table.items())
    if t <= pts[0][0]:
        return pts[0][1]
    if t >= pts[-1][0]:
        return pts[-1][1]
    for (t0, v0), (t1, v1) in zip(pts, pts[1:]):
        if t0 <= t <= t1:
            return v0 + (v1 - v0) * (t - t0) / (t1 - t0)
    return 0.0


def ageing_loss(a, years, temp_c):
    if years <= 0:
        return 0.0
    loss = a["loss_at_ref"] * (years / a["years_ref"]) * 2.0 ** ((temp_c - a["ref_temp_c"]) / a["doubling_c"])
    return min(loss, 0.8)


def flush_time_s(cfg, sc, ts):
    d = cfg["detection"]
    t_detect = (d["supervisor_delay_us"] + (d["sync_cycles"] + d["controller_filter_cycles"]) / d["clock_mhz"] +
                d["firmware_irq_latency_us"]) * 1e-6
    xfer = ts["page_bytes"] * 8.0 / (ts["bus_mbps"] * 1e6)
    t_prog = ts["t_prog_us"] * 1e-6
    t_bers = ts["t_bers_us"] * 1e-6
    t_inflight = max(t_prog, t_bers)          # the op running at the fault cannot be stopped safely
    par = cfg["load"]["dies_programming_in_parallel"]
    t_data = math.ceil(sc["dirty_pages"] / par) * (t_prog + xfer) if sc["dirty_pages"] else 0.0
    t_journal = sc["journal_programs"] * (t_prog + xfer)
    t_erase = sc["erases"] * t_bers
    parts = {"detect": t_detect, "in_flight": t_inflight, "data": t_data, "journal": t_journal, "erase": t_erase}
    return sum(parts.values()), parts


def load_w(cfg):
    l = cfg["load"]
    return l["controller_w"] + l["sram_buffer_w"] + l["nand_die_program_w"] * l["dies_programming_in_parallel"] + l["misc_w"]


def bank_energy(cfg, temp_c, years):
    b = cfg["capacitor_bank"]
    r = cfg["regulator"]
    c_nom = b["c_each_uf"] * 1e-6 * b["count"]
    factor = (1 - b["tolerance"]) * (1 - derate(b["temp_derating"], temp_c)) * \
             (1 - ageing_loss(b["ageing"], years, cfg["corners"]["operating_temp_c"]))
    c_eff = c_nom * factor
    p = load_w(cfg)
    v_floor = r["v_min_input_v"] + r["uvlo_margin_v"]
    esr = b["esr_each_mohm"] * 1e-3 * b["esr_eol_factor"] / b["count"]       # parallel bank at end of life
    i_peak = p / (r["efficiency_worst"] * v_floor)
    v_low = v_floor + i_peak * esr
    e = 0.5 * c_eff * max(b["v_hold_v"] ** 2 - v_low ** 2, 0.0)
    return e, c_eff, v_low, factor


def required_c(cfg, e_req, temp_c, years):
    b = cfg["capacitor_bank"]
    _, _, v_low, factor = bank_energy(cfg, temp_c, years)
    denom = 0.5 * factor * (b["v_hold_v"] ** 2 - v_low ** 2)
    return e_req / denom if denom > 0 else float("inf")


# ---------------------------------------------------------------- minimal SVG line chart
def svg_chart(path, title, xlabel, ylabel, series, hlines=(), logy=False):
    W, H, L, R, T, B = 720, 420, 80, 24, 40, 56
    xs = [x for _, pts in series for x, _ in pts]
    ys = [y for _, pts in series for _, y in pts] + [y for _, y in hlines]
    xmin, xmax = min(xs), max(xs)
    ymin, ymax = (min(ys), max(ys))
    if logy:
        ymin = 10 ** math.floor(math.log10(max(min(y for y in ys if y > 0), 1e-12)))
        ymax = 10 ** math.ceil(math.log10(max(ys)))
    else:
        ymin = 0.0
        ymax = ymax * 1.1 if ymax > 0 else 1.0

    def X(x):
        return L + (W - L - R) * (x - xmin) / ((xmax - xmin) or 1)

    def Y(y):
        if logy:
            y = max(y, ymin)
            return T + (H - T - B) * (1 - (math.log10(y) - math.log10(ymin)) / (math.log10(ymax) - math.log10(ymin)))
        return T + (H - T - B) * (1 - (y - ymin) / ((ymax - ymin) or 1))

    colors = ["#2563eb", "#dc2626", "#16a34a", "#9333ea", "#ea580c", "#0891b2", "#4b5563"]
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" font-family="sans-serif" font-size="12">',
         f'<rect width="{W}" height="{H}" fill="white"/>',
         f'<text x="{W/2}" y="22" text-anchor="middle" font-size="15" font-weight="bold">{title}</text>',
         f'<line x1="{L}" y1="{H-B}" x2="{W-R}" y2="{H-B}" stroke="black"/>',
         f'<line x1="{L}" y1="{T}" x2="{L}" y2="{H-B}" stroke="black"/>',
         f'<text x="{(L+W-R)/2}" y="{H-14}" text-anchor="middle">{xlabel}</text>',
         f'<text x="18" y="{(T+H-B)/2}" text-anchor="middle" transform="rotate(-90 18 {(T+H-B)/2})">{ylabel}</text>']
    # ticks
    for i in range(6):
        xv = xmin + (xmax - xmin) * i / 5
        o.append(f'<text x="{X(xv):.1f}" y="{H-B+16}" text-anchor="middle">{xv:g}</text>')
    if logy:
        e0, e1 = int(math.log10(ymin)), int(math.log10(ymax))
        for e in range(e0, e1 + 1):
            yv = 10 ** e
            o.append(f'<line x1="{L}" y1="{Y(yv):.1f}" x2="{W-R}" y2="{Y(yv):.1f}" stroke="#e5e7eb"/>')
            o.append(f'<text x="{L-6}" y="{Y(yv)+4:.1f}" text-anchor="end">{yv:g}</text>')
    else:
        for i in range(6):
            yv = ymin + (ymax - ymin) * i / 5
            o.append(f'<line x1="{L}" y1="{Y(yv):.1f}" x2="{W-R}" y2="{Y(yv):.1f}" stroke="#e5e7eb"/>')
            o.append(f'<text x="{L-6}" y="{Y(yv)+4:.1f}" text-anchor="end">{yv:.3g}</text>')
    for k, (name, pts) in enumerate(series):
        c = colors[k % len(colors)]
        d = " ".join(f"{'M' if i == 0 else 'L'}{X(x):.1f},{Y(y):.1f}" for i, (x, y) in enumerate(pts))
        o.append(f'<path d="{d}" fill="none" stroke="{c}" stroke-width="2"/>')
        o.append(f'<rect x="{L+12}" y="{T+8+16*k}" width="12" height="3" fill="{c}"/>'
                 f'<text x="{L+30}" y="{T+12+16*k}">{name}</text>')
    for k, (name, yv) in enumerate(hlines):
        o.append(f'<line x1="{L}" y1="{Y(yv):.1f}" x2="{W-R}" y2="{Y(yv):.1f}" stroke="black" stroke-dasharray="6 4"/>')
        o.append(f'<text x="{W-R-4}" y="{Y(yv)-5:.1f}" text-anchor="end">{name}</text>')
    o.append("</svg>")
    with open(path, "w") as f:
        f.write("\n".join(o))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    os.makedirs(a.out, exist_ok=True)
    b = cfg["capacitor_bank"]
    r = cfg["regulator"]
    p = load_w(cfg)
    temps, years = cfg["corners"]["temps_c"], cfg["corners"]["years"]
    worst_t = min(temps)
    worst_y = max(years)
    e_avail_fresh, _, v_low, _ = bank_energy(cfg, 25, 0)
    e_avail_worst, c_eff_worst, _, f_worst = bank_energy(cfg, worst_t, worst_y)

    rows, csv = [], ["scenario,timing,t_flush_ms,energy_req_mj_with_margin,c_required_uf_worst,bank_uf,meets_worst"]
    for ts_name, ts in cfg["nand_timing_sets"].items():
        for sc in cfg["scenarios"]:
            t, parts = flush_time_s(cfg, sc, ts)
            if sc["mode"] == "stop":
                e_req = 0.0                    # correctness needs no hold-up: nothing must be finished
            else:
                e_req = p * t / r["efficiency_worst"] * cfg["design_margin"]
            c_req = required_c(cfg, e_req, worst_t, worst_y) if e_req > 0 else 0.0
            bank = b["c_each_uf"] * b["count"]
            ok = c_req <= bank * 1e-6
            rows.append((sc["name"], ts_name, t, parts, e_req, c_req, ok))
            csv.append(f"{sc['name']},{ts_name},{t*1e3:.3f},{e_req*1e3:.3f},{c_req*1e6:.0f},{bank:.0f},{int(ok)}")
    open(os.path.join(a.out, "plp_sizing.csv"), "w").write("\n".join(csv) + "\n")

    # chart 1: required capacitance vs dirty pages
    series = []
    for ts_name, ts in cfg["nand_timing_sets"].items():
        pts = []
        for n in [0, 8, 16, 32, 64, 128, 192, 256]:
            sc = {"dirty_pages": n, "journal_programs": 2, "erases": 1}
            t, _ = flush_time_s(cfg, sc, ts)
            e = p * t / r["efficiency_worst"] * cfg["design_margin"]
            pts.append((n, required_c(cfg, e, worst_t, worst_y) * 1e6))
        series.append((f"{ts_name} ({worst_t} C, {worst_y} y)", pts))
    svg_chart(os.path.join(a.out, "c_required_vs_dirty.svg"),
              "Hold-up capacitance needed vs dirty pages (estimate, margin x%g)" % cfg["design_margin"],
              "dirty write-cache pages to drain", "capacitance (uF, log)", series,
              hlines=[("placeholder bank %g uF" % (b["c_each_uf"] * b["count"]), b["c_each_uf"] * b["count"])], logy=True)
    # chart 2: available energy vs years
    series = []
    for tc in [-40, 0, 25, 85]:
        series.append((f"{tc} C", [(y, bank_energy(cfg, tc, y)[0] * 1e3) for y in years]))
    svg_chart(os.path.join(a.out, "energy_vs_age.svg"), "Usable bank energy vs capacitor age (estimate)",
              "years in service", "usable energy (mJ)", series)

    # report
    md = []
    md.append("# Capacitor-backed PLP -- research model (ESTIMATES ONLY)\n")
    md.append("_Generated by `make plp` from `plp_model/plp_config.json`.  Every electrical value is a placeholder in "
              "a datasheet-class range; nothing was measured on SilicaFlux hardware, because no SilicaFlux board, "
              "regulator or capacitor bank exists.  **This project does not claim hardware power-loss protection.** "
              "The RTL is delivered with `PLP_PRESENT = 0`._\n")
    md.append("## Model\n")
    md.append("* Required energy `E_req = P_shutdown x t_flush / eta_worst x margin`, with `t_flush = t_detect + t_in-flight "
              "+ ceil(dirty/parallel) x (tPROG + t_xfer) + journal x (tPROG + t_xfer) + erases x tBERS`.")
    md.append("* Usable energy `E = 1/2 C_eff (V_hold^2 - V_low^2)`, `C_eff = C_nom (1 - tolerance)(1 - temperature "
              "derating)(1 - ageing)`, `V_low = V_min,reg + UVLO margin + I_peak x ESR_end-of-life`.")
    md.append("* Ageing: capacitance loss %.0f %% after %.0f years at %.0f C, doubling every %.0f C (Arrhenius rule of "
              "thumb); ESR x%.1f at end of life." % (b["ageing"]["loss_at_ref"] * 100, b["ageing"]["years_ref"],
                                                   b["ageing"]["ref_temp_c"], b["ageing"]["doubling_c"], b["esr_eol_factor"]))
    md.append("* Worst corner used for sizing: %g C, %g years at %g C operating temperature, efficiency %.0f %%, design "
              "margin x%g.\n" % (worst_t, worst_y, cfg["corners"]["operating_temp_c"], r["efficiency_worst"] * 100,
                                 cfg["design_margin"]))
    md.append("Placeholder load on the hold-up rail: **%.2f W** (controller %.2f, buffer SRAM %.2f, %d dies programming x %.2f, "
              "misc %.2f).  Placeholder bank: %d x %.0f uF %s at %.1f V; usable energy %.1f mJ fresh at 25 C, "
              "**%.1f mJ** at the worst corner (C_eff factor %.2f, V_low %.2f V).\n" %
              (p, cfg["load"]["controller_w"], cfg["load"]["sram_buffer_w"], cfg["load"]["dies_programming_in_parallel"],
               cfg["load"]["nand_die_program_w"], cfg["load"]["misc_w"], b["count"], b["c_each_uf"], b["technology"],
               b["v_hold_v"], e_avail_fresh * 1e3, e_avail_worst * 1e3, f_worst, v_low))
    md.append("## Results\n")
    md.append("| Scenario | NAND timing | t_flush | of which in-flight op | energy needed (incl. margin) | C needed at worst "
              "corner | placeholder bank meets it? |")
    md.append("|---|---|---|---|---|---|---|")
    for name, ts_name, t, parts, e, c, ok in rows:
        md.append("| %s | %s | %.2f ms | %.2f ms | %s | %s | %s |" % (
            name, ts_name, t * 1e3, parts["in_flight"] * 1e3, ("%.1f mJ" % (e * 1e3)) if e else "0 (none needed)",
            ("%.0f uF" % (c * 1e6)) if e else "0", "n/a" if not e else ("yes" if ok else "**no**")))
    md.append("")
    md.append("![required capacitance](c_required_vs_dirty.svg)\n")
    md.append("![energy vs age](energy_vs_age.svg)\n")
    md.append("## What the numbers say (and do not say)\n")
    md.append("* The delivered design (**STOP**) needs **no stored energy for correctness**: a write is acknowledged only "
              "after its page and spare record are programmed, so when the supply collapses there is nothing that must "
              "still be written.  The NAND operation in flight may tear; a torn page fails its CRC and is ignored at "
              "recovery (verified by the crash campaigns).")
    md.append("* **DIAG** (one ring erase + one journal page of diagnostics) is best effort: it improves post-mortem "
              "information, not durability; if the energy runs out the page tears harmlessly.")
    md.append("* A **PLP-backed volatile write cache** (acknowledge at BUFFERED, drain on power fail) is where the energy "
              "budget becomes a correctness requirement.  Its size is dominated by worst-case program time x dirty "
              "pages / parallelism and by the cold, aged corner; with TLC-class timing the placeholder bank is "
              "insufficient beyond a handful of dirty pages.")
    md.append("* Detection latency (%.1f us here) is negligible next to NAND program / erase times.\n" %
              (flush_time_s(cfg, cfg["scenarios"][0], list(cfg["nand_timing_sets"].values())[0])[1]["detect"] * 1e6))
    md.append("## Before `PLP_PRESENT = 1` may be set -- qualification checklist\n")
    md.append("1. A board-level design exists: hold-up rail, charge circuit, isolation (ideal diode / load switch), "
              "regulator, supervisor with defined threshold and delay, and a capacitor health monitor driving "
              "`cap_ok_i`.")
    md.append("2. Measured, not estimated: capacitance and ESR across temperature, regulator efficiency and dropout at the "
              "flush load, worst-case flush power with all dies programming, supervisor delay, firmware interrupt latency "
              "on the ControlCore.")
    md.append("3. Measured hold-up time with a programmable load at every temperature corner, and on aged parts (HTOL / "
              "accelerated life), with the design margin above.")
    md.append("4. On-board power-fail injection: thousands of supply cuts during cached writes with the crash-campaign "
              "reference model checking every acknowledged write (the harness in this project, run on hardware).")
    md.append("5. Field health: periodic capacitor self-test (discharge timing) that drops `cap_ok_i`; the controller then "
              "revokes PLP (`ERR.PLP_REVOKED`), early acknowledgement stops, and the firmware flushes the cache.")
    md.append("6. Only then: synthesise with `PLP_PRESENT = 1`, firmware sets `CFG.PLP_QUAL` after its boot-time "
              "self-test, and `CFG.PF_MODE = PLP_FLUSH`.  The controller still refuses early acknowledgement whenever "
              "`cap_ok_i` is low or qualification was revoked.\n")
    open(os.path.join(a.out, "PLP_MODEL.md"), "w").write("\n".join(md))
    print("plp: wrote", os.path.join(a.out, "PLP_MODEL.md"))
    for name, ts_name, t, parts, e, c, ok in rows:
        print("  %-36s %-26s t_flush %8.2f ms  E %8.2f mJ  C_worst %9.0f uF  %s" %
              (name, ts_name, t * 1e3, e * 1e3, c * 1e6, "-" if not e else ("ok" if ok else "INSUFFICIENT")))


if __name__ == "__main__":
    main()
