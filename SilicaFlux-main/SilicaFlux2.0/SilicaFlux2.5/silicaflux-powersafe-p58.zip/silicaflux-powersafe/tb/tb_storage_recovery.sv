// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: tb_storage_recovery -- self-checking unit testbench
//
// Drives silicaflux_storage_recovery through its pins and register page and
// checks the FSM, admission control, tag tracker, acknowledgement gate, phase
// legality, power-fault policies, brown-out restore, reset sequencing, drain /
// recovery timeouts, retention domain, persistent commit status, crash
// injection, clean shutdown and PLP qualification.  A scoreboard monitor checks
// on EVERY cycle that no SUCCESS completion of a WRITE / TRIM / FLUSH leaves the
// controller unless the scoreboard's own phase model says DURABLE (or an early
// acknowledgement was legitimately permitted), and that no tag completes twice.
//
//   +TEST=<name>  run one test (default: all)      +SEED=<n>  random seed
//   parameter PLP (0/1): elaborate the DUT with PLP_PRESENT
// Runs on Verilator (--binary --timing) and Icarus Verilog (-g2012).
// Prints "TB RESULT PASS|FAIL plp=<p> tests=<n> checks=<n> errors=<n>".
// Classification: SIMULATION ONLY
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_storage_recovery;
  import sfpr_regs_pkg::*;
  parameter int PLP   = 0;
  parameter int NTAGS = 8;
  localparam int TW = $clog2(NTAGS);

  // ---------------------------------------------------------------- DUT signals
  logic clk = 1'b0;
  logic por_n = 1'b0, rst_n = 1'b1, pwr_fail_n = 1'b1, cap_ok = 1'b0;
  logic host_rst = 1'b0, wdt_rst = 1'b0;
  logic sub_rst_n;
  logic rb_sel = 1'b0, rb_we = 1'b0;
  logic [11:0] rb_addr = '0;
  logic [31:0] rb_wdata = '0, rb_rdata;
  logic rb_err;
  logic cmd_valid = 1'b0, cmd_fua = 1'b0;
  logic [2:0] cmd_kind = '0;
  logic cmd_accept, cmd_reject;
  logic [TW-1:0] cmd_tag;
  logic [7:0] cmd_rej_status, cmd_rej_err;
  logic ev_valid = 1'b0;
  logic [TW-1:0] ev_tag = '0;
  logic [2:0] ev_phase = '0;
  logic cq_valid, cq_ready = 1'b1;
  logic [TW-1:0] cq_tag;
  logic [7:0] cq_status;
  logic nand_busy = 1'b0, nand_start = 1'b0;
  logic [1:0] nand_kind = '0;
  logic prog_ok, read_ok, wp_n;
  logic [5:0] host_status;
  logic irq, crash_req;
  logic [1:0] crash_action;

  always #5 clk = ~clk;

  silicaflux_storage_recovery #(.NTAGS(NTAGS), .PLP_PRESENT(PLP), .PF_FILTER(2), .RESET_HOLD_CYCLES(16)) dut (
    .clk, .por_ni(por_n), .rst_ni(rst_n), .pwr_fail_ni(pwr_fail_n), .cap_ok_i(cap_ok),
    .host_rst_req_i(host_rst), .wdt_rst_req_i(wdt_rst), .sub_rst_no(sub_rst_n),
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .cmd_valid_i(cmd_valid), .cmd_kind_i(cmd_kind), .cmd_fua_i(cmd_fua), .cmd_accept_o(cmd_accept),
    .cmd_tag_o(cmd_tag), .cmd_reject_o(cmd_reject), .cmd_rej_status_o(cmd_rej_status), .cmd_rej_err_o(cmd_rej_err),
    .ev_valid_i(ev_valid), .ev_tag_i(ev_tag), .ev_phase_i(ev_phase),
    .cq_valid_o(cq_valid), .cq_tag_o(cq_tag), .cq_status_o(cq_status), .cq_ready_i(cq_ready),
    .nand_busy_i(nand_busy), .nand_start_i(nand_start), .nand_kind_i(nand_kind),
    .nand_prog_ok_o(prog_ok), .nand_read_ok_o(read_ok), .wp_no(wp_n),
    .host_status_o(host_status), .irq_o(irq), .crash_req_o(crash_req), .crash_action_o(crash_action));

  // ---------------------------------------------------------------- bookkeeping
  int checks = 0, errors = 0, tests = 0;
  int crash_pulses = 0;
  int cq_count = 0;
  logic [7:0] last_cq_status;
  logic [TW-1:0] last_cq_tag;

  `define CHECK(c, msg) begin checks++; if (!(c)) begin errors++; $display("ERROR %0t [%0s] %0s", $time, cur_test, msg); end end

  reg [8*24-1:0] cur_test;

  // scoreboard: phase model per tag, independent of the DUT
  logic        sb_busy   [NTAGS];
  logic [2:0]  sb_kind   [NTAGS];
  logic [2:0]  sb_phase  [NTAGS];
  logic        sb_vacked [NTAGS];
  logic        sb_fua    [NTAGS];
  logic        sb_early_ok;   // TB's own view: WCE set (or PLP effective) and state RUN

  function automatic bit durable_kind(input logic [2:0] k);
    return k == SFPR_KIND_WRITE || k == SFPR_KIND_TRIM || k == SFPR_KIND_FLUSH;
  endfunction

  // completion monitor: the core safety property, checked on every CQ handshake
  always @(posedge clk) begin
    if (crash_req) crash_pulses++;
    if (por_n && cq_valid && cq_ready) begin
      cq_count++;
      last_cq_status <= cq_status;
      last_cq_tag <= cq_tag;
      checks++;
      if (!sb_busy[cq_tag]) begin
        errors++; $display("ERROR %0t [%0s] completion for a tag the scoreboard thinks free: %0d", $time, cur_test, cq_tag);
      end else if (cq_status == SFPR_STATUS_SUCCESS && durable_kind(sb_kind[cq_tag]) && sb_phase[cq_tag] != SFPR_PHASE_DURABLE &&
                   !(sb_early_ok && sb_kind[cq_tag] == SFPR_KIND_WRITE && !sb_fua[cq_tag] && sb_phase[cq_tag] >= SFPR_PHASE_BUFFERED)) begin
        errors++; $display("ERROR %0t [%0s] SUCCESS completion before DURABLE: tag %0d kind %0d phase %0d",
                           $time, cur_test, cq_tag, sb_kind[cq_tag], sb_phase[cq_tag]);
      end
      // the scoreboard owns tag lifetime: an early (volatile) ack keeps the tag, anything else frees it
      if (cq_status == SFPR_STATUS_SUCCESS && durable_kind(sb_kind[cq_tag]) && sb_phase[cq_tag] != SFPR_PHASE_DURABLE &&
          sb_kind[cq_tag] == SFPR_KIND_WRITE) sb_vacked[cq_tag] = 1;
      else sb_busy[cq_tag] = 0;
    end
  end

  // ---------------------------------------------------------------- low-level tasks
  task automatic tick(input int n = 1);
    repeat (n) @(posedge clk);
    #1;
  endtask

  task automatic wr(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = 1'b1; rb_addr = a; rb_wdata = d;
    @(posedge clk); #1;
    rb_sel = 1'b0; rb_we = 1'b0;
  endtask

  task automatic rd(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = 1'b0; rb_addr = a;
    #1 d = rb_rdata;
    @(posedge clk); #1;
    rb_sel = 1'b0;
  endtask

  function automatic logic [3:0] fsm_of(input logic [31:0] st);
    return st[3:0];
  endfunction

  task automatic expect_state(input sfpr_state_e s, input [8*40-1:0] what);
    logic [31:0] v;
    rd(SFPR_STATE, v);
    checks++;
    if (v[3:0] != s) begin
      errors++; $display("ERROR %0t [%0s] %0s: state %0d, expected %0d", $time, cur_test, what, v[3:0], s);
    end
  endtask

  task automatic wait_state(input sfpr_state_e s, input int max_cycles, input [8*40-1:0] what);
    logic [31:0] v;
    int n;
    n = 0;
    rd(SFPR_STATE, v);
    while (v[3:0] != s && n < max_cycles) begin tick(); rd(SFPR_STATE, v); n++; end
    checks++;
    if (v[3:0] != s) begin
      errors++; $display("ERROR %0t [%0s] %0s: stuck in state %0d (want %0d)", $time, cur_test, what, v[3:0], s);
    end
  endtask

  task automatic sb_clear();
    for (int i = 0; i < NTAGS; i++) begin sb_busy[i] = 0; sb_phase[i] = 0; sb_vacked[i] = 0; sb_kind[i] = 0; sb_fua[i] = 0; end
  endtask

  task automatic power_on();
    por_n = 1'b0; rst_n = 1'b1; pwr_fail_n = 1'b1; cmd_valid = 0; ev_valid = 0; nand_busy = 0; nand_start = 0;
    host_rst = 0; wdt_rst = 0; cq_ready = 1; sb_early_ok = 0;
    sb_clear();
    tick(3);
    por_n = 1'b1;
    tick(4);
  endtask

  // boot to RUN (default debounce 64 cycles)
  task automatic boot_run();
    power_on();
    wait_state(SFPR_STATE_RECOVERY, 200, "boot -> RECOVERY");
    wr(SFPR_CTRL, 32'h1);                       // RECOVERY_DONE, RESULT OK
    expect_state(SFPR_STATE_RUN, "RECOVERY_DONE -> RUN");
  endtask

  // firmware-path submission; returns tag or -1
  task automatic submit(input logic [2:0] kind, input logic fua, output int tag, output logic [31:0] res);
    wr(SFPR_CMD_SUBMIT, {28'd0, fua, kind});
    rd(SFPR_CMD_RESULT, res);
    if (res[0]) begin
      tag = int'(res[7:4]);
      sb_busy[tag] = 1; sb_kind[tag] = kind; sb_phase[tag] = SFPR_PHASE_ACCEPTED; sb_vacked[tag] = 0; sb_fua[tag] = fua;
    end else tag = -1;
  endtask

  // legal phase event per the scoreboard (also used for illegal ones: sb updated only when legal)
  task automatic phase(input int tag, input logic [2:0] p, input bit expect_legal = 1);
    wr(SFPR_PHASE_EV, {20'd0, 1'b0, p, 8'(tag)});
    if (expect_legal) begin
      sb_phase[tag] = p;
      if (p == SFPR_PHASE_DURABLE && sb_vacked[tag]) sb_busy[tag] = 0;
    end
  endtask

  task automatic advance(input int tag, input logic [2:0] to);
    logic [2:0] p;
    p = sb_phase[tag];
    while (p < to) begin
      if (sb_kind[tag] == SFPR_KIND_TRIM && p == SFPR_PHASE_ACCEPTED) p = SFPR_PHASE_PROGRAMMED;
      else if (sb_kind[tag] == SFPR_KIND_FLUSH) p = SFPR_PHASE_DURABLE;
      else p = p + 3'd1;
      phase(tag, p);
    end
  endtask

  // completion request; returns CPL_RESULT; updates the scoreboard when released
  task automatic complete(input int tag, input logic [7:0] status, output logic [31:0] res);
    wr(SFPR_CPL_REQ, {16'd0, status, 8'(tag)});
    rd(SFPR_CPL_RESULT, res);
    tick(1);    // the CQ monitor updates the scoreboard at the handshake; silent frees are handled here
    if (res[0] && sb_vacked[tag] && status != SFPR_STATUS_SUCCESS) sb_busy[tag] = 0;
  endtask

  task automatic hw_cmd(input logic [2:0] kind, input logic fua, output bit acc, output bit rej, output int tag,
                        output logic [7:0] rst);
    @(negedge clk);
    cmd_valid = 1; cmd_kind = kind; cmd_fua = fua;
    #1;
    acc = cmd_accept; rej = cmd_reject; tag = cmd_accept ? int'(cmd_tag) : -1; rst = cmd_rej_status;
    @(posedge clk); #1;
    cmd_valid = 0;
    if (acc) begin
      sb_busy[tag] = 1; sb_kind[tag] = kind; sb_phase[tag] = SFPR_PHASE_ACCEPTED; sb_vacked[tag] = 0; sb_fua[tag] = fua;
    end
  endtask

  task automatic nand_op(input logic [1:0] kind, input int busy_cycles);
    @(negedge clk);
    nand_start = 1; nand_kind = kind; nand_busy = 1;
    @(negedge clk);
    nand_start = 0;
    repeat (busy_cycles) @(negedge clk);
    nand_busy = 0;
  endtask

  task automatic wait_sweep();
    logic [31:0] v;
    int n;
    n = 0;
    rd(SFPR_STATE, v);
    while (!v[SFPR_STATE_SWEEP_DONE_LSB] && n < 200) begin tick(); rd(SFPR_STATE, v); n++; end
    checks++;
    if (!v[SFPR_STATE_SWEEP_DONE_LSB]) begin errors++; $display("ERROR %0t [%0s] sweep did not finish", $time, cur_test); end
    tick(2);
  endtask

  task automatic clear_err();
    wr(SFPR_ERR, 32'hFFFF_FFFF);
  endtask

  task automatic read_err(output logic [31:0] e);
    rd(SFPR_ERR, e);
  endtask

  // power fail and restore (pin)
  task automatic pf_assert();
    @(negedge clk); pwr_fail_n = 0;
  endtask
  task automatic pf_release();
    @(negedge clk); pwr_fail_n = 1;
  endtask

  // ================================================================ tests
  task automatic t_boot();
    logic [31:0] v;
    cur_test = "boot";
    power_on();
    expect_state(SFPR_STATE_POR_INIT, "after POR");
    `CHECK(!sub_rst_n, "sub-reset held in POR_INIT")
    `CHECK(!wp_n, "WP# asserted in POR_INIT")
    `CHECK(!prog_ok, "no program in POR_INIT")
    rd(SFPR_ID, v);      `CHECK(v == SFPR_ID_VALUE, "ID")
    rd(SFPR_VERSION, v); `CHECK(v == SFPR_VERSION_VALUE, "VERSION")
    rd(SFPR_CONFIG, v);  `CHECK(v[7:0] == NTAGS && v[8] == (PLP != 0), "CONFIG")
    rd(SFPR_CFG, v);     `CHECK(v == (SFPR_CFG_RST & ~32'h2), "CFG reset value (STOP, budget 1, remount, auto-abort, strict)")
    wait_state(SFPR_STATE_RECOVERY, 200, "POR_INIT -> RECOVERY after debounce");
    `CHECK(sub_rst_n, "sub-reset released in RECOVERY")
    `CHECK(wp_n, "WP# released in RECOVERY")
    `CHECK(prog_ok && read_ok, "NAND usable for mount")
    `CHECK(host_status[2] && !host_status[0], "host sees recovering, not ready")
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_POR), "RET_CAUSE = POR")
    rd(SFPR_T_RECOVERIES, v); `CHECK(v == 1, "T_RECOVERIES = 1")
    rd(SFPR_IRQ_STATUS, v); `CHECK(v[SFPR_IRQ_STATUS_RECOVERY_LSB], "IRQ RECOVERY")
    tick(20);
    wr(SFPR_CTRL, 32'h1);
    expect_state(SFPR_STATE_RUN, "RUN");
    `CHECK(host_status[0], "host RDY")
    rd(SFPR_T_RECOV_CYC_LAST, v); `CHECK(v > 20 && v < 200, "recovery cycles measured")
    rd(SFPR_RET_FLAGS, v); `CHECK(v[SFPR_RET_FLAGS_UNCLEAN_LSB], "UNCLEAN set on RUN entry")
    // register error responses
    @(negedge clk); rb_sel = 1; rb_we = 0; rb_addr = 12'hFF0; #1; `CHECK(rb_err, "unmapped read -> rb_err")
    rb_we = 1; rb_addr = SFPR_ID; #1; `CHECK(rb_err, "write to RO -> rb_err")
    @(posedge clk); #1; rb_sel = 0; rb_we = 0;
  endtask

  task automatic t_admission();
    logic [31:0] v, res;
    bit acc, rej;
    int tag, n;
    logic [7:0] s;
    cur_test = "admission";
    power_on();
    // during POR_INIT / RECOVERY: NOT_READY
    hw_cmd(SFPR_KIND_READ, 0, acc, rej, tag, s);
    `CHECK(!acc && rej && s == SFPR_STATUS_ABORT_RESET, "POR_INIT rejects ABORT_RESET")
    wait_state(SFPR_STATE_RECOVERY, 200, "RECOVERY");
    hw_cmd(SFPR_KIND_WRITE, 0, acc, rej, tag, s);
    `CHECK(!acc && rej && s == SFPR_STATUS_ABORT_RESET && cmd_rej_err == SFPR_ERR_NOT_READY, "RECOVERY rejects NOT_READY")
    wr(SFPR_CTRL, 32'h1);
    // RUN: fill every tag through the hardware port
    n = 0;
    for (int i = 0; i < NTAGS; i++) begin
      hw_cmd(SFPR_KIND_WRITE, 0, acc, rej, tag, s);
      if (acc) n++;
    end
    `CHECK(n == NTAGS, "all tags allocated")
    hw_cmd(SFPR_KIND_READ, 0, acc, rej, tag, s);
    `CHECK(!acc && !rej, "full: held (neither accept nor reject)")
    submit(SFPR_KIND_READ, 0, tag, res);
    `CHECK(res[2] && !res[0] && !res[1], "register path: NO_TAG")
    read_err(v); `CHECK(v[10], "ERR.NO_TAG")
    rd(SFPR_OUTSTANDING, v); `CHECK(v[7:0] == NTAGS && v[15:8] == NTAGS && v[31:24] == NTAGS, "OUTSTANDING count/max/nondurable")
    // RUN_RO
    power_on();
    wait_state(SFPR_STATE_RECOVERY, 200, "RECOVERY");
    wr(SFPR_CTRL, 32'h1 | (32'd1 << 2));       // RESULT READ_ONLY
    expect_state(SFPR_STATE_RUN_RO, "RUN_RO");
    `CHECK(!prog_ok && read_ok && !wp_n, "RUN_RO: reads only, WP# asserted")
    hw_cmd(SFPR_KIND_WRITE, 0, acc, rej, tag, s);
    `CHECK(rej && s == SFPR_STATUS_WRITE_PROTECTED, "RUN_RO rejects WRITE")
    hw_cmd(SFPR_KIND_TRIM, 0, acc, rej, tag, s);
    `CHECK(rej && s == SFPR_STATUS_WRITE_PROTECTED, "RUN_RO rejects TRIM")
    hw_cmd(SFPR_KIND_READ, 0, acc, rej, tag, s);
    `CHECK(acc, "RUN_RO admits READ")
    hw_cmd(SFPR_KIND_FLUSH, 0, acc, rej, tag, s);
    `CHECK(acc, "RUN_RO admits FLUSH")
    `CHECK(host_status[3] && host_status[0], "host sees RO + RDY")
    // degradation at run time: RUN -> RUN_RO through CTRL.READ_ONLY
    power_on();
    wait_state(SFPR_STATE_RECOVERY, 200, "RECOVERY");
    wr(SFPR_CTRL, 32'h1);
    expect_state(SFPR_STATE_RUN, "RUN");
    wr(SFPR_CTRL, 32'h100);
    expect_state(SFPR_STATE_RUN_RO, "CTRL.READ_ONLY -> RUN_RO");
    hw_cmd(SFPR_KIND_WRITE, 0, acc, rej, tag, s);
    `CHECK(rej && s == SFPR_STATUS_WRITE_PROTECTED, "writes rejected after degradation")
    wr(SFPR_CTRL, 32'h100);
    expect_state(SFPR_STATE_RUN_RO, "READ_ONLY in RUN_RO: no change");
    // FAILED
    power_on();
    wait_state(SFPR_STATE_RECOVERY, 200, "RECOVERY");
    wr(SFPR_CTRL, 32'h1 | (32'd2 << 2));       // RESULT FAILED
    expect_state(SFPR_STATE_FAILED, "FAILED");
    hw_cmd(SFPR_KIND_READ, 0, acc, rej, tag, s);
    `CHECK(rej && s == SFPR_STATUS_INTERNAL_ERR, "FAILED rejects INTERNAL_ERR")
    `CHECK(host_status[4] && !wp_n, "host sees fatal, WP# asserted")
    rd(SFPR_RET_FLAGS, v); `CHECK(v[SFPR_RET_FLAGS_RECOV_FAILED_LSB], "RET_FLAGS.RECOV_FAILED")
    rd(SFPR_T_ADM_REJECTS, v); `CHECK(v >= 1, "T_ADM_REJECTS counts")
  endtask

  task automatic t_ack_gate();
    logic [31:0] v, res;
    int w, r, f, t;
    cur_test = "ack_gate";
    boot_run();
    submit(SFPR_KIND_WRITE, 0, w, res);
    `CHECK(w >= 0, "write accepted")
    complete(w, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[1] && !res[0], "SUCCESS at ACCEPTED refused")
    read_err(v); `CHECK(v[0], "ERR.ACK_BEFORE_DURABLE")
    rd(SFPR_ERR_INFO, v); `CHECK(v[7:0] == w && v[28:24] == 0, "ERR_INFO names tag and bit")
    clear_err();
    for (int p = SFPR_PHASE_BUFFERED; p <= SFPR_PHASE_MAPPED; p++) begin
      advance(w, 3'(p));
      complete(w, SFPR_STATUS_SUCCESS, res);
      `CHECK(res[1], "SUCCESS refused below DURABLE")
    end
    advance(w, SFPR_PHASE_DURABLE);
    complete(w, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0] && !res[3], "SUCCESS released at DURABLE")
    `CHECK(last_cq_status == SFPR_STATUS_SUCCESS && last_cq_tag == w, "CQ carries it")
    rd(SFPR_T_GATE_REFUSED, v); `CHECK(v == 5, "T_GATE_REFUSED = 5")
    rd(SFPR_T_ACK_DURABLE, v); `CHECK(v == 1, "T_ACK_DURABLE = 1")
    rd(SFPR_T_DUR_COUNT, v); `CHECK(v == 1, "T_DUR_COUNT = 1")
    rd(SFPR_T_LAT_DUR_LAST, v); `CHECK(v > 0, "accept->durable latency measured")
    // error completion always passes
    submit(SFPR_KIND_WRITE, 0, w, res);
    advance(w, SFPR_PHASE_PROGRAMMED);
    complete(w, 8'h11, res);
    `CHECK(res[0] && last_cq_status == 8'h11, "error completion released at any phase")
    // READ: no durability semantics
    submit(SFPR_KIND_READ, 0, r, res);
    complete(r, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0], "READ SUCCESS released at ACCEPTED")
    // FLUSH
    submit(SFPR_KIND_FLUSH, 0, f, res);
    complete(f, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[1], "FLUSH refused before DURABLE")
    advance(f, SFPR_PHASE_DURABLE);
    complete(f, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0], "FLUSH released at DURABLE")
    // TRIM chain
    submit(SFPR_KIND_TRIM, 0, t, res);
    advance(t, SFPR_PHASE_MAPPED);
    complete(t, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[1], "TRIM refused at MAPPED")
    advance(t, SFPR_PHASE_DURABLE);
    complete(t, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0], "TRIM released at DURABLE")
    // completion slot busy
    cq_ready = 0;
    submit(SFPR_KIND_READ, 0, r, res);
    submit(SFPR_KIND_READ, 0, f, res);
    complete(r, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0], "first completion takes the slot")
    complete(f, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[2] && !res[0], "second: BUSY while the slot is full")
    cq_ready = 1; tick(2);
    complete(f, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0], "retry after the slot drained")
    // completion for a free tag
    complete(NTAGS - 1, SFPR_STATUS_SUCCESS, res);
    read_err(v); `CHECK(res[1] && v[3], "completion of a free tag refused, ERR.CPL_FREE_TAG")
  endtask

  task automatic t_phases();
    logic [31:0] v, res;
    int w, t, f;
    cur_test = "phases";
    boot_run();
    submit(SFPR_KIND_WRITE, 0, w, res);
    phase(w, SFPR_PHASE_PROGRAMMED, 0);          // skips BUFFERED
    read_err(v); `CHECK(v[1], "skip -> ERR.PHASE_ILLEGAL")
    wr(SFPR_TAG_SEL, w); rd(SFPR_TAG_INFO, v);
    `CHECK(v[6:4] == SFPR_PHASE_ACCEPTED, "strict: illegal event ignored")
    advance(w, SFPR_PHASE_VERIFIED);
    clear_err();
    phase(w, SFPR_PHASE_BUFFERED, 0);            // backwards
    read_err(v); `CHECK(v[1], "backwards -> ERR.PHASE_ILLEGAL")
    rd(SFPR_TAG_INFO, v); `CHECK(v[6:4] == SFPR_PHASE_VERIFIED, "still VERIFIED")
    clear_err();
    phase(NTAGS - 1, SFPR_PHASE_BUFFERED, 0);    // free tag
    read_err(v); `CHECK(v[2], "free tag -> ERR.PHASE_FREE_TAG")
    // TRIM: ACCEPTED -> PROGRAMMED legal, BUFFERED illegal
    clear_err();
    submit(SFPR_KIND_TRIM, 0, t, res);
    phase(t, SFPR_PHASE_BUFFERED, 0);
    read_err(v); `CHECK(v[1], "TRIM BUFFERED illegal")
    clear_err();
    phase(t, SFPR_PHASE_PROGRAMMED);
    read_err(v); `CHECK(v == 0, "TRIM ACCEPTED->PROGRAMMED legal")
    // FLUSH: only ACCEPTED -> DURABLE
    submit(SFPR_KIND_FLUSH, 0, f, res);
    phase(f, SFPR_PHASE_MAPPED, 0);
    read_err(v); `CHECK(v[1], "FLUSH MAPPED illegal")
    clear_err();
    phase(f, SFPR_PHASE_DURABLE);
    read_err(v); `CHECK(v == 0, "FLUSH ACCEPTED->DURABLE legal")
    // non-strict: recorded and applied
    rd(SFPR_CFG, v);
    wr(SFPR_CFG, v & ~(32'd1 << SFPR_CFG_STRICT_PHASES_LSB));
    submit(SFPR_KIND_WRITE, 0, w, res);
    phase(w, SFPR_PHASE_MAPPED, 1);              // skip, but applied
    read_err(v); `CHECK(v[1], "non-strict: still flagged")
    wr(SFPR_TAG_SEL, w); rd(SFPR_TAG_INFO, v);
    `CHECK(v[6:4] == SFPR_PHASE_MAPPED, "non-strict: applied")
    rd(SFPR_T_PHASE_ERR, v); `CHECK(v == 5, "T_PHASE_ERR counts illegal events (free-tag events are separate)")
  endtask

  task automatic t_wce();
    logic [31:0] v, res;
    int w, w2, f, wf;
    cur_test = "wce";
    boot_run();
    submit(SFPR_KIND_WRITE, 0, w, res);
    advance(w, SFPR_PHASE_BUFFERED);
    complete(w, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[1], "no WCE: early ack refused")
    rd(SFPR_CFG, v);
    wr(SFPR_CFG, v | 32'h1);                     // host enables a volatile write cache
    sb_early_ok = 1;
    rd(SFPR_STATE, v); `CHECK(v[SFPR_STATE_EARLY_ACK_OK_LSB], "EARLY_ACK_OK with WCE")
    complete(w, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0] && res[3], "WCE: released as VOLATILE at BUFFERED")
    wr(SFPR_TAG_SEL, w); rd(SFPR_TAG_INFO, v);
    `CHECK(v[8] && v[7], "tag stays busy, VACKED")
    rd(SFPR_OUTSTANDING, v); `CHECK(v[23:16] == 1, "OUTSTANDING.VACKED = 1")
    complete(w, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[1], "second SUCCESS for a volatile write refused")
    submit(SFPR_KIND_WRITE, 1, wf, res);         // FUA
    advance(wf, SFPR_PHASE_BUFFERED);
    complete(wf, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[1], "FUA never early-acked")
    submit(SFPR_KIND_FLUSH, 0, f, res);
    advance(f, SFPR_PHASE_DURABLE);
    complete(f, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[1], "FLUSH refused while a VACKED write is not durable")
    advance(w, SFPR_PHASE_DURABLE);
    wr(SFPR_TAG_SEL, w); rd(SFPR_TAG_INFO, v);
    `CHECK(!v[8], "VACKED write freed silently at DURABLE")
    complete(f, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[0], "FLUSH released once nothing volatile remains")
    rd(SFPR_T_ACK_EARLY, v); `CHECK(v == 1, "T_ACK_EARLY = 1")
    // a volatile write lost at reset is reported
    submit(SFPR_KIND_WRITE, 0, w2, res);
    advance(w2, SFPR_PHASE_BUFFERED);
    complete(w2, SFPR_STATUS_SUCCESS, res);
    `CHECK(res[3], "second volatile ack")
    wr(SFPR_CTRL, {SFPR_CMD_KEY, 16'h0080});    // SW reset
    sb_clear(); sb_early_ok = 0;
    wait_state(SFPR_STATE_RECOVERY, 400, "SW reset -> RECOVERY");
    rd(SFPR_T_VOL_LOST, v); `CHECK(v == 1, "T_VOL_LOST = 1 after reset")
    read_err(v); `CHECK(v[12], "ERR.VOL_LOST")
  endtask

  task automatic t_pf_stop();
    logic [31:0] v, res;
    int d, p, r;
    cur_test = "pf_stop";
    boot_run();
    submit(SFPR_KIND_WRITE, 0, d, res); advance(d, SFPR_PHASE_DURABLE);     // durable, not yet acked
    submit(SFPR_KIND_WRITE, 0, p, res); advance(p, SFPR_PHASE_PROGRAMMED);  // in flight
    submit(SFPR_KIND_READ, 0, r, res);
    @(negedge clk); nand_start = 1; nand_kind = 2'd1; nand_busy = 1;    // a program is in flight
    @(negedge clk); nand_start = 0;
    pf_assert();
    tick(4);
    expect_state(SFPR_STATE_PF_DRAIN, "PF_DRAIN");
    `CHECK(!prog_ok && !read_ok, "STOP: no new NAND op")
    `CHECK(wp_n, "WP# not asserted while the program runs")
    `CHECK(host_status[1], "host sees PLP quiescence")
    begin
      bit acc, rej; int tg; logic [7:0] s;
      hw_cmd(SFPR_KIND_WRITE, 0, acc, rej, tg, s);
      `CHECK(rej && s == SFPR_STATUS_ABORT_PWR_LOSS && cmd_rej_err == SFPR_ERR_QUIESCED, "new command ABORT_PWR_LOSS")
    end
    rd(SFPR_RET_PF_SNAP, v);
    `CHECK(v[3:0] == SFPR_STATE_RUN && v[11:4] == 3 && v[19:12] == 1 && v[27:20] == 1 && v[28], "PF snapshot")
    tick(10);
    expect_state(SFPR_STATE_PF_DRAIN, "waits for the op in flight");
    @(negedge clk); nand_busy = 0;
    tick(3);
    expect_state(SFPR_STATE_PF_SAFE, "PF_SAFE once the NAND is idle");
    `CHECK(!wp_n, "WP# asserted")
    wait_sweep();
    // sweep: durable tag completed SUCCESS, the others aborted
    rd(SFPR_OUTSTANDING, v); `CHECK(v[7:0] == 0, "sweep completed every tag")
    rd(SFPR_T_ABORTS, v); `CHECK(v == 2, "2 aborted")
    rd(SFPR_T_ACK_DURABLE, v); `CHECK(v == 1, "durable tag acknowledged")
    sb_clear();
    rd(SFPR_STATE, v); `CHECK(v[SFPR_STATE_SWEEP_DONE_LSB], "SWEEP_DONE")
    // the firmware learns of the fault late and completes a tag the sweep already retired: expected, not an error
    clear_err();
    wr(SFPR_CPL_REQ, {16'd0, 8'h00, 8'(p)});
    wr(SFPR_PHASE_EV, {20'd0, 1'b0, 3'(SFPR_PHASE_MAPPED), 8'(p)});
    read_err(v); `CHECK(v[3:2] == 2'b00, "late firmware events in PF: no ERR")
    rd(SFPR_T_LATE_FW, v); `CHECK(v == 2, "T_LATE_FW counts them")
    // a NAND controller that ignores the gate is detected
    nand_op(2'd1, 2);
    read_err(v); `CHECK(v[9], "ERR.NAND_OP_BLOCKED")
    rd(SFPR_T_PF_NAND_OPS, v); `CHECK(v == 1, "ops after the fault counted")
    rd(SFPR_RET_PF_COUNT, v); `CHECK(v == 1, "RET_PF_COUNT")
    rd(SFPR_T_PF_SAFE_CYC, v); `CHECK(v > 10, "fault -> safe cycles")
    // supply returns: debounce, then remount (default)
    pf_release();
    tick(20);
    expect_state(SFPR_STATE_PF_SAFE, "debounce");
    wait_state(SFPR_STATE_RECOVERY, 300, "restore -> remount -> RECOVERY");
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_PF_REMOUNT), "RET_CAUSE = PF_REMOUNT")
    rd(SFPR_T_RESTORES, v); `CHECK(v == 1, "T_RESTORES")
    rd(SFPR_RET_BOOTS, v); `CHECK(v == 1, "RET_BOOTS")
  endtask

  task automatic t_pf_diag();
    logic [31:0] v;
    cur_test = "pf_diag";
    boot_run();
    rd(SFPR_CFG, v);
    wr(SFPR_CFG, (v & ~32'h0000_0FC0) | (32'(SFPR_PF_MODE_DIAG) << 6) | (32'd1 << 8));
    pf_assert(); tick(4);
    expect_state(SFPR_STATE_PF_DRAIN, "PF_DRAIN");
    `CHECK(!prog_ok && read_ok, "DIAG: no program before the firmware acknowledges the fault")
    wr(SFPR_CTRL, 32'h200);                      // PF_ACK
    `CHECK(prog_ok, "DIAG: one program allowed after PF_ACK")
    nand_op(2'd0, 2);                            // a read does not consume the budget
    `CHECK(prog_ok, "budget untouched by reads")
    nand_op(2'd1, 3);                            // the diagnostics page
    tick(1);
    `CHECK(!prog_ok, "budget exhausted")
    tick(3);
    expect_state(SFPR_STATE_PF_SAFE, "SAFE after the budget");
    read_err(v); `CHECK(!v[9], "no blocked op")
    // DIAG with FW_SAFE before the budget is used
    pf_release();
    wait_state(SFPR_STATE_RECOVERY, 300, "remount");
    wr(SFPR_CTRL, 32'h1);
    rd(SFPR_CFG, v);
    wr(SFPR_CFG, (v & ~32'h0000_0FC0) | (32'(SFPR_PF_MODE_DIAG) << 6) | (32'd2 << 8));
    pf_assert(); tick(4);
    expect_state(SFPR_STATE_PF_DRAIN, "PF_DRAIN");
    `CHECK(!prog_ok, "budget closed again for a new fault")
    wr(SFPR_CTRL, 32'h20);                        // FW_SAFE
    tick(2);
    expect_state(SFPR_STATE_PF_SAFE, "FW_SAFE -> SAFE");
    pf_release();
  endtask

  task automatic t_pf_resume();
    logic [31:0] v, res;
    int w;
    cur_test = "pf_resume";
    boot_run();
    rd(SFPR_CFG, v);
    wr(SFPR_CFG, v & ~(32'd1 << SFPR_CFG_REMOUNT_ON_RESTORE_LSB));
    submit(SFPR_KIND_WRITE, 0, w, res); advance(w, SFPR_PHASE_VERIFIED);
    pf_assert(); tick(6);
    expect_state(SFPR_STATE_PF_SAFE, "STOP, idle NAND -> SAFE");
    wait_sweep();
    pf_release();
    wait_state(SFPR_STATE_PF_RESTORE, 200, "PF_RESTORE");
    `CHECK(!wp_n && !prog_ok, "still protected until RESUME")
    tick(30);
    expect_state(SFPR_STATE_PF_RESTORE, "waits for the firmware");
    wr(SFPR_CTRL, 32'h10);                        // RESUME
    expect_state(SFPR_STATE_RUN, "resumed in place");
    `CHECK(wp_n && prog_ok, "writable again")
    rd(SFPR_RET_BOOTS, v); `CHECK(v == 0, "no reset sequence")
    // pf again during RESTORE goes back to SAFE
    pf_assert(); tick(6);
    pf_release();
    wait_state(SFPR_STATE_PF_RESTORE, 200, "PF_RESTORE again");
    pf_assert(); tick(4);
    expect_state(SFPR_STATE_PF_SAFE, "fault during RESTORE -> SAFE");
    pf_release();
    wait_state(SFPR_STATE_PF_RESTORE, 200, "PF_RESTORE");
    wr(SFPR_CTRL, 32'h10);
    expect_state(SFPR_STATE_RUN, "RUN");
    rd(SFPR_T_RESTORES, v); `CHECK(v == 3, "T_RESTORES = 3")
  endtask

  task automatic t_pf_glitch();
    logic [31:0] v;
    cur_test = "pf_glitch";
    boot_run();
    @(negedge clk); pwr_fail_n = 0;
    @(negedge clk); pwr_fail_n = 1;
    tick(8);
    expect_state(SFPR_STATE_RUN, "single-cycle glitch filtered");
    rd(SFPR_T_PF_EVENTS, v); `CHECK(v == 0, "no PF event")
  endtask

  task automatic t_pf_in_recovery();
    logic [31:0] v;
    cur_test = "pf_in_recovery";
    power_on();
    wait_state(SFPR_STATE_RECOVERY, 200, "RECOVERY");
    pf_assert(); tick(4);
    read_err(v); `CHECK(v[6], "ERR.PF_IN_RECOVERY")
    wait_state(SFPR_STATE_PF_SAFE, 50, "SAFE");
    rd(SFPR_CFG, v);
    wr(SFPR_CFG, v & ~(32'd1 << SFPR_CFG_REMOUNT_ON_RESTORE_LSB));    // resume not allowed: not resumable
    pf_release();
    wait_state(SFPR_STATE_RECOVERY, 300, "interrupted recovery restarts via reset");
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_PF_REMOUNT), "PF_REMOUNT")
    // fault while the CPU is in reset: CPU stays held
    wr(SFPR_CTRL, 32'h1);
    @(negedge clk); host_rst = 1; @(negedge clk); host_rst = 0;
    wait_state(SFPR_STATE_RESET_HOLD, 50, "RESET_HOLD");
    pf_assert(); tick(4);
    rd(SFPR_STATE, v);
    `CHECK(v[SFPR_STATE_CPU_HELD_LSB] && !sub_rst_n, "CPU held through the fault")
    `CHECK(!prog_ok, "nothing programs")
    pf_release();
    wait_state(SFPR_STATE_RECOVERY, 300, "remount");
    `CHECK(sub_rst_n, "released at RECOVERY")
  endtask

  task automatic t_reset_seq();
    logic [31:0] v, res;
    int w, n;
    cur_test = "reset_seq";
    boot_run();
    submit(SFPR_KIND_WRITE, 0, w, res); advance(w, SFPR_PHASE_PROGRAMMED);
    @(negedge clk); nand_start = 1; nand_kind = 2'd2; nand_busy = 1;
    @(negedge clk); nand_start = 0;
    @(negedge clk); host_rst = 1;
    @(negedge clk); host_rst = 0;
    tick(2);
    expect_state(SFPR_STATE_RESET_DRAIN, "RESET_DRAIN");
    `CHECK(!prog_ok && wp_n && sub_rst_n, "no new op, WP# not during the erase, CPU still up")
    tick(10);
    expect_state(SFPR_STATE_RESET_DRAIN, "waits for the erase");
    @(negedge clk); nand_busy = 0;
    tick(2);
    expect_state(SFPR_STATE_RESET_HOLD, "RESET_HOLD");
    `CHECK(!sub_rst_n && !wp_n, "sub-reset and WP# asserted")
    n = 0;
    while (!sub_rst_n && n < 100) begin tick(); n++; end
    `CHECK(n >= 13 && n <= 18, "sub-reset pulse ~16 cycles")
    sb_clear();
    expect_state(SFPR_STATE_RECOVERY, "RECOVERY");
    rd(SFPR_OUTSTANDING, v); `CHECK(v[7:0] == 0, "tags cleared")
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_HOST), "cause HOST")
    rd(SFPR_RET_BOOTS, v); `CHECK(v == 1, "RET_BOOTS = 1")
    wr(SFPR_CTRL, 32'h1);
    // watchdog
    @(negedge clk); wdt_rst = 1; @(negedge clk); wdt_rst = 0;
    wait_state(SFPR_STATE_RECOVERY, 100, "WDT -> RECOVERY");
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_WDT), "cause WDT")
    wr(SFPR_CTRL, 32'h1);
    // SW reset needs the key
    wr(SFPR_CTRL, {16'h1234, 16'h0080});
    tick(3);
    expect_state(SFPR_STATE_RUN, "wrong key ignored");
    wr(SFPR_CTRL, {SFPR_CMD_KEY, 16'h0080});
    wait_state(SFPR_STATE_RECOVERY, 100, "SW -> RECOVERY");
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_SW), "cause SW")
    rd(SFPR_RET_BOOTS, v); `CHECK(v == 3, "RET_BOOTS = 3")
    // drain timeout
    wr(SFPR_CTRL, 32'h1);
    wr(SFPR_DRAIN_TMO, 32'd20);
    @(negedge clk); nand_busy = 1;                // stuck busy
    @(negedge clk); host_rst = 1; @(negedge clk); host_rst = 0;
    wait_state(SFPR_STATE_RESET_HOLD, 60, "drain timeout -> RESET_HOLD");
    read_err(v); `CHECK(v[5], "ERR.DRAIN_TIMEOUT")
    @(negedge clk); nand_busy = 0;
  endtask

  task automatic t_recov_timeout();
    logic [31:0] v;
    cur_test = "recov_timeout";
    power_on();
    wr(SFPR_RECOV_TMO, 32'd50);
    wait_state(SFPR_STATE_RECOVERY, 200, "RECOVERY");
    wait_state(SFPR_STATE_FAILED, 100, "timeout -> FAILED");
    read_err(v); `CHECK(v[4], "ERR.RECOV_TIMEOUT")
    rd(SFPR_T_RECOV_CYC_LAST, v); `CHECK(v >= 49 && v <= 52, "recovery time recorded")
    wr(SFPR_RECOV_TMO, 32'd0);
    @(negedge clk); host_rst = 1; @(negedge clk); host_rst = 0;
    wait_state(SFPR_STATE_RECOVERY, 100, "reset from FAILED -> RECOVERY");
    wr(SFPR_CTRL, 32'h1);
    expect_state(SFPR_STATE_RUN, "second recovery succeeds");
  endtask

  task automatic t_retention();
    logic [31:0] v;
    cur_test = "retention";
    boot_run();
    wr(SFPR_RET_SCRATCH0, 32'hCAFEF00D);
    wr(SFPR_COMMIT_SEQ_LO, 32'h0000_1000); wr(SFPR_COMMIT_SEQ_HI, 32'h0000_0002);
    wr(SFPR_CKPT_GEN, 32'd7);
    // monotonic
    wr(SFPR_COMMIT_SEQ_LO, 32'h0000_0FFF); wr(SFPR_COMMIT_SEQ_HI, 32'h0000_0002);
    read_err(v); `CHECK(v[8], "COMMIT_SEQ regression -> ERR.SEQ_REGRESS")
    rd(SFPR_COMMIT_SEQ_LO, v); `CHECK(v == 32'h1000, "regression ignored")
    wr(SFPR_CKPT_GEN, 32'd6);
    rd(SFPR_CKPT_GEN, v); `CHECK(v == 7, "CKPT_GEN monotonic")
    pf_assert(); tick(8); pf_release();
    // external hard reset: functional state lost, retention kept
    @(negedge clk); rst_n = 0; tick(3); rst_n = 1; tick(4);
    expect_state(SFPR_STATE_POR_INIT, "ext reset -> POR_INIT");
    rd(SFPR_RET_SCRATCH0, v); `CHECK(v == 32'hCAFEF00D, "scratch retained")
    rd(SFPR_COMMIT_SEQ_LO, v); `CHECK(v == 32'h1000, "COMMIT_SEQ retained")
    rd(SFPR_COMMIT_SEQ_HI, v); `CHECK(v == 32'h2, "COMMIT_SEQ_HI retained")
    rd(SFPR_CKPT_GEN, v); `CHECK(v == 7, "CKPT_GEN retained")
    rd(SFPR_RET_PF_COUNT, v); `CHECK(v == 1, "RET_PF_COUNT retained")
    rd(SFPR_RET_FLAGS, v); `CHECK(v[0] && v[1], "UNCLEAN and PF_SEEN retained")
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_EXT), "RET_CAUSE = EXT")
    rd(SFPR_T_PF_EVENTS, v); `CHECK(v == 0, "telemetry cleared by ext reset")
    // power-on reset clears retention
    sb_clear();
    power_on();
    rd(SFPR_RET_SCRATCH0, v); `CHECK(v == 0, "POR clears scratch")
    rd(SFPR_COMMIT_SEQ_LO, v); `CHECK(v == 0, "POR clears COMMIT_SEQ")
    rd(SFPR_RET_CAUSE, v); `CHECK(v == 1, "RET_CAUSE = POR")
  endtask

  task automatic t_crash();
    logic [31:0] v, res;
    int c0, w;
    cur_test = "crash";
    boot_run();
    // CUT_NOW at the 3rd occurrence of point 4 (PRE_MAP)
    wr(SFPR_CI_COUNT, 3);
    wr(SFPR_CI_CTRL, (32'd4 << 8) | (32'(SFPR_CI_ACTION_CUT_NOW) << 2) | 32'h1);
    c0 = crash_pulses;
    wr(SFPR_CP_EVENT, 32'd4); wr(SFPR_CP_EVENT, 32'd5); wr(SFPR_CP_EVENT, 32'd4);
    tick(2);
    `CHECK(crash_pulses == c0, "not yet")
    rd(SFPR_CI_SEEN, v); `CHECK(v == 2, "CI_SEEN = 2")
    wr(SFPR_CP_EVENT, 32'd4);
    tick(2);
    `CHECK(crash_pulses == c0 + 1, "fires on the 3rd")
    rd(SFPR_CI_CTRL, v); `CHECK(v[1] && !v[0], "FIRED, disarmed")
    wr(SFPR_CP_EVENT, 32'd4); tick(2);
    `CHECK(crash_pulses == c0 + 1, "one-shot")
    rd(SFPR_RET_FLAGS, v); `CHECK(v[SFPR_RET_FLAGS_CRASH_FIRED_LSB], "RET_FLAGS.CRASH_FIRED")
    rd(SFPR_CI_FIRED_AT, v); `CHECK(v != 0, "CI_FIRED_AT stamped")
    // tag filter
    wr(SFPR_CI_COUNT, 1);
    wr(SFPR_CI_CTRL, (32'd5 << 24) | (32'd1 << 16) | (32'd7 << 8) | 32'h1);
    c0 = crash_pulses;
    wr(SFPR_CP_EVENT, (32'd3 << 8) | 32'd7); tick(2);
    `CHECK(crash_pulses == c0, "other tag ignored")
    wr(SFPR_CP_EVENT, (32'd5 << 8) | 32'd7); tick(2);
    `CHECK(crash_pulses == c0 + 1, "matching tag fires")
    // CUT_NEXT_PROG: armed by the event, fires at the next program, not at a read
    wr(SFPR_CI_CTRL, (32'd2 << 8) | (32'(SFPR_CI_ACTION_CUT_NEXT_PROG) << 2) | 32'h1);
    c0 = crash_pulses;
    wr(SFPR_CP_EVENT, 32'd2); tick(2);
    rd(SFPR_CI_CTRL, v); `CHECK(v[17] && crash_pulses == c0, "PENDING after the event")
    nand_op(2'd0, 2); tick(1);
    `CHECK(crash_pulses == c0, "a read does not tear")
    @(negedge clk); nand_start = 1; nand_kind = 2'd1; nand_busy = 1;
    @(negedge clk); nand_start = 0;
    `CHECK(crash_req && crash_action == SFPR_CI_ACTION_CUT_NEXT_PROG && nand_busy, "fires during the program (registered, while busy)")
    tick(1);
    `CHECK(crash_pulses == c0 + 1, "exactly one pulse")
    @(negedge clk); nand_busy = 0;
    // NAND_OP point: N-th operation of any kind
    wr(SFPR_CI_COUNT, 3);
    wr(SFPR_CI_CTRL, (32'd31 << 8) | (32'(SFPR_CI_ACTION_CUT_NOW) << 2) | 32'h1);
    c0 = crash_pulses;
    nand_op(2'd0, 1); nand_op(2'd1, 1);
    `CHECK(crash_pulses == c0, "2 ops: not yet")
    nand_op(2'd2, 1); tick(1);
    `CHECK(crash_pulses == c0 + 1, "3rd op fires")
    rd(SFPR_T_CRASHES, v); `CHECK(v == 4, "T_CRASHES = 4")
    // CPU_RESET action runs a reset sequence
    submit(SFPR_KIND_WRITE, 0, w, res);
    wr(SFPR_CI_COUNT, 1);
    wr(SFPR_CI_CTRL, (32'd7 << 8) | (32'(SFPR_CI_ACTION_CPU_RESET) << 2) | 32'h1);
    wr(SFPR_CP_EVENT, 32'd7);
    sb_clear();
    wait_state(SFPR_STATE_RECOVERY, 100, "CPU_RESET crash -> RECOVERY");
    rd(SFPR_RET_CAUSE, v); `CHECK(v == (32'd1 << SFPR_CAUSE_CRASH), "cause CRASH")
    rd(SFPR_IRQ_STATUS, v); `CHECK(v[SFPR_IRQ_STATUS_CRASH_LSB], "IRQ CRASH")
  endtask

  task automatic t_shutdown();
    logic [31:0] v;
    bit acc, rej; int tg; logic [7:0] s;
    cur_test = "shutdown";
    boot_run();
    wr(SFPR_CTRL, 32'h40);                        // SHUTDOWN_DONE
    expect_state(SFPR_STATE_SHUTDOWN, "SHUTDOWN");
    rd(SFPR_RET_FLAGS, v); `CHECK(!v[0], "UNCLEAN cleared")
    `CHECK(!wp_n && !prog_ok && host_status[5], "medium protected, host sees shutdown")
    hw_cmd(SFPR_KIND_READ, 0, acc, rej, tg, s);
    `CHECK(rej && s == SFPR_STATUS_ABORT_RESET, "commands rejected")
    pf_assert(); tick(4);
    expect_state(SFPR_STATE_SHUTDOWN, "power loss after shutdown: nothing to do");
    pf_release(); tick(2);
    @(negedge clk); host_rst = 1; @(negedge clk); host_rst = 0;
    wait_state(SFPR_STATE_RECOVERY, 100, "reset after shutdown -> RECOVERY");
  endtask

  task automatic t_plp();
    logic [31:0] v, res;
    int w;
    cur_test = "plp";
    cap_ok = 1'b1;
    boot_run();
    rd(SFPR_CFG, v);
    wr(SFPR_CFG, v | 32'h2 | (32'(SFPR_PF_MODE_PLP_FLUSH) << 6));
    read_err(v);
    rd(SFPR_STATE, res);
    if (PLP == 0) begin
      `CHECK(v[7], "PLP_QUAL / PLP_FLUSH without PLP_PRESENT -> ERR.PLP_POLICY")
      rd(SFPR_CFG, v); `CHECK(!v[1], "PLP_QUAL reads 0 without PLP_PRESENT")
      `CHECK(!res[SFPR_STATE_PLP_EFFECTIVE_LSB] && !res[SFPR_STATE_EARLY_ACK_OK_LSB], "no PLP, no early ack")
      submit(SFPR_KIND_WRITE, 0, w, res); advance(w, SFPR_PHASE_BUFFERED);
      complete(w, SFPR_STATUS_SUCCESS, res);
      `CHECK(res[1], "early ack refused without PLP")
      pf_assert(); tick(4);
      `CHECK(!prog_ok, "PLP_FLUSH degrades to STOP")
      wait_state(SFPR_STATE_PF_SAFE, 20, "SAFE");
    end else begin
      `CHECK(!v[7], "PLP_QUAL accepted with PLP_PRESENT")
      `CHECK(res[SFPR_STATE_PLP_EFFECTIVE_LSB] && res[SFPR_STATE_EARLY_ACK_OK_LSB], "PLP effective -> early ack")
      sb_early_ok = 1;
      submit(SFPR_KIND_WRITE, 0, w, res); advance(w, SFPR_PHASE_BUFFERED);
      complete(w, SFPR_STATUS_SUCCESS, res);
      `CHECK(res[0] && res[3], "early ack with qualified PLP")
      pf_assert(); tick(4);
      expect_state(SFPR_STATE_PF_DRAIN, "drain");
      `CHECK(prog_ok, "PLP_FLUSH: firmware may program")
      nand_op(2'd1, 2); nand_op(2'd1, 2);
      advance(w, SFPR_PHASE_DURABLE);           // buffered data drained to NAND
      wr(SFPR_CTRL, 32'h20);                     // FW_SAFE
      wait_state(SFPR_STATE_PF_SAFE, 20, "SAFE");
      rd(SFPR_T_VOL_LOST, v); `CHECK(v == 0, "nothing volatile lost")
      pf_release();
      wait_state(SFPR_STATE_RECOVERY, 300, "remount");
      wr(SFPR_CTRL, 32'h1);
      sb_clear(); sb_early_ok = 0;
      // the hold-up store degrades: qualification revoked
      @(negedge clk); cap_ok = 1'b0;
      tick(4);
      read_err(v); `CHECK(v[11], "ERR.PLP_REVOKED")
      rd(SFPR_STATE, res); `CHECK(!res[SFPR_STATE_PLP_EFFECTIVE_LSB] && !res[SFPR_STATE_EARLY_ACK_OK_LSB], "revoked")
      @(negedge clk); cap_ok = 1'b1; tick(4);
      rd(SFPR_STATE, res); `CHECK(!res[SFPR_STATE_PLP_EFFECTIVE_LSB], "stays revoked until re-qualified")
      submit(SFPR_KIND_WRITE, 0, w, res); advance(w, SFPR_PHASE_BUFFERED);
      complete(w, SFPR_STATUS_SUCCESS, res);
      `CHECK(res[1], "early ack refused after revocation")
      rd(SFPR_CFG, v); wr(SFPR_CFG, v & ~32'h2); wr(SFPR_CFG, v | 32'h2);
      rd(SFPR_STATE, res); `CHECK(res[SFPR_STATE_PLP_EFFECTIVE_LSB], "re-qualified")
    end
    pf_release();
    cap_ok = 1'b0;
  endtask

  // random stimulus: the completion monitor checks the gate on every handshake
  task automatic t_random(input int iters);
    logic [31:0] v, res;
    int tag, op, n_acc, n_rel;
    logic [2:0] k;
    cur_test = "random";
    boot_run();
    n_acc = 0; n_rel = 0;
    for (int it = 0; it < iters; it++) begin
      op = $urandom_range(0, 99);
      if (op < 25) begin
        k = 3'($urandom_range(0, 4));
        submit(k, 1'($urandom_range(0, 1)), tag, res);
        if (tag >= 0) n_acc++;
      end else if (op < 60) begin
        tag = $urandom_range(0, NTAGS - 1);
        if (sb_busy[tag] && sb_phase[tag] < SFPR_PHASE_DURABLE) begin
          if ($urandom_range(0, 9) == 0) phase(tag, 3'($urandom_range(1, 6)), 0);   // maybe illegal
          else advance(tag, sb_phase[tag] + 3'd1);
          // the DUT may have refused the random one: resynchronise the scoreboard from TAG_INFO
          wr(SFPR_TAG_SEL, tag); rd(SFPR_TAG_INFO, v);
          sb_phase[tag] = v[6:4]; sb_busy[tag] = v[8]; sb_vacked[tag] = v[7];
        end
      end else if (op < 90) begin
        tag = $urandom_range(0, NTAGS - 1);
        complete(tag, ($urandom_range(0, 4) == 0) ? 8'h05 : 8'h00, res);
        if (res[0]) n_rel++;
      end else if (op < 93) begin
        rd(SFPR_CFG, v);
        wr(SFPR_CFG, v ^ 32'h1);                 // toggle WCE
        sb_early_ok = !v[0];
      end else if (op < 95) begin
        cq_ready = 1'($urandom_range(0, 1));
        tick($urandom_range(1, 4));
        cq_ready = 1;
      end else if (op < 97) begin
        // power fault + restore + remount: every tag is completed once, volatile acks are dropped and counted
        begin : p_rnd_pf
          logic [31:0] vl0, vl1, o;
          int nv;
          nv = 0;
          for (int i = 0; i < NTAGS; i++) if (sb_busy[i] && sb_vacked[i]) nv++;
          rd(SFPR_T_VOL_LOST, vl0);
          pf_assert(); tick(6);
          wait_state(SFPR_STATE_PF_SAFE, 50, "random pf");
          wait_sweep();
          rd(SFPR_T_VOL_LOST, vl1);
          rd(SFPR_OUTSTANDING, o);
          `CHECK(o[7:0] == 0, "sweep leaves no tag")
          `CHECK(vl1 - vl0 == nv, "volatile acks dropped == T_VOL_LOST delta")
          for (int i = 0; i < NTAGS; i++) begin
            checks++;
            if (sb_busy[i] && !sb_vacked[i]) begin errors++; $display("ERROR %0t [random] tag %0d not completed by the sweep", $time, i); end
            sb_busy[i] = 0; sb_vacked[i] = 0;
          end
        end
        pf_release();
        wait_state(SFPR_STATE_RECOVERY, 300, "random remount");
        wr(SFPR_CTRL, 32'h1);
        rd(SFPR_CFG, v); sb_early_ok = v[0];
      end else begin
        tick($urandom_range(1, 8));
      end
    end
    $display("    random: %0d accepted, %0d completions released, %0d CQ entries", n_acc, n_rel, cq_count);
    rd(SFPR_T_GATE_REFUSED, v);
    `CHECK(v > 0, "the gate refused something during the random run")
  endtask

  // ================================================================ runner
  reg [8*32-1:0] only;
  int seed;
  initial begin
    if (!$value$plusargs("TEST=%s", only)) only = "all";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    void'($urandom(seed));
    cur_test = "init";
    sb_clear();
    sb_early_ok = 0;
    `define RUN(name, call) if (only == "all" || only == name) begin tests++; call; $display("  done %0s (errors so far %0d)", name, errors); end
    `RUN("boot", t_boot())
    `RUN("admission", t_admission())
    `RUN("ack_gate", t_ack_gate())
    `RUN("phases", t_phases())
    `RUN("wce", t_wce())
    `RUN("pf_stop", t_pf_stop())
    `RUN("pf_diag", t_pf_diag())
    `RUN("pf_resume", t_pf_resume())
    `RUN("pf_glitch", t_pf_glitch())
    `RUN("pf_in_recovery", t_pf_in_recovery())
    `RUN("reset_seq", t_reset_seq())
    `RUN("recov_timeout", t_recov_timeout())
    `RUN("retention", t_retention())
    `RUN("crash", t_crash())
    `RUN("shutdown", t_shutdown())
    `RUN("plp", t_plp())
    `RUN("random", t_random(4000))
    $display("TB RESULT %0s plp=%0d tests=%0d checks=%0d errors=%0d", (errors == 0 && tests > 0) ? "PASS" : "FAIL",
             PLP, tests, checks, errors);
    $finish;
  end

  initial begin
    #50_000_000;
    $display("TB RESULT FAIL timeout");
    $finish;
  end
endmodule

`default_nettype wire
