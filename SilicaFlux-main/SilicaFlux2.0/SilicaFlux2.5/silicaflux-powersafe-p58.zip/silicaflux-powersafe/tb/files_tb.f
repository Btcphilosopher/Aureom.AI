// SilicaFlux PowerSafe (Project 58) -- unit testbench file list
-f rtl/files.f
tb/tb_storage_recovery.sv
