# 03 — Recovery controller RTL (`silicaflux_storage_recovery.sv`)

Synthesizable SystemVerilog (Verilator 5.020 `-Wall` clean in simulation and synthesis views for 4 parameter sets;
Icarus 12 elaborates; Yosys 0.33 synthesizes with 0 latches, `check -assert` clean — `reports/lint.md`,
`reports/synth.md`). Register reference: `docs/REGISTERS.md` (generated).

| Module | Function |
|---|---|
| `silicaflux_storage_recovery` (top) | FSM, admission, NAND permissions + WP#, power-fault policy, reset sequencing, retention, telemetry, register page |
| `sfpr_tag_tracker` | outstanding-operation table, phase legality, acknowledgement gate, completion slot, power-fault sweep |
| `sfpr_crash_inj` | deterministic crash injection |
| `sfpr_regs_pkg` (generated) | offsets, fields, encodings, crash-point ids |
| `sfv_sync`, `sfv_rst_sync` (vendored, unmodified) | `pwr_fail_ni` / `cap_ok_i` synchronisers, reset synchronisers |

Parameters: `NTAGS` (2..16, default 8 = P51 `CMD_QUEUE_DEPTH`), `PLP_PRESENT` (0 delivered, 1 research only),
`PF_FILTER` (power-fail glitch filter, cycles, default 2), `RESET_HOLD_CYCLES` (16).

## 1. FSM

```
            por/ext reset
                 │
            ┌────▼─────┐ supply good for RESTORE_DEB
            │ POR_INIT ├──────────────────────────────┐            sub-reset held, WP# asserted
            └──────────┘                              │
                                                ┌─────▼─────┐ RECOVERY_DONE(OK)  ┌─────┐
            ┌──────────────────────────────────►│ RECOVERY  ├───────────────────►│ RUN │◄──────────┐
            │                                   └──┬──┬──┬──┘ (READ_ONLY)        └┬─┬─┬┘ RESUME    │
            │                    RECOV_TMO / FAILED │  │  └──────────►┌────────┐   │ │ │           │
            │                   ┌───────────────────┘  │              │ RUN_RO │◄──┘ │ │CTRL.READ_ONLY
            │              ┌────▼───┐                  │              └──┬──┬──┘     │ │           │
            │              │ FAILED │                  │ pwr fail        │  │        │ │           │
            │              └───┬────┘                  ▼                 │  │        │ │           │
            │     reset req    │           ┌──────────────┐◄─────────────┘  │        │ │     ┌─────┴──────┐
            │                  │           │   PF_DRAIN   │◄────────────────┼────────┘ │     │ PF_RESTORE │
            │                  │           └──────┬───────┘   pwr fail      │          │     └──▲───┬─────┘
            │                  │  NAND idle & (STOP | PF_ACK budget used    │          │ good   │   │ remount / CPU held
            │                  │  | FW_SAFE)  or DRAIN_TMO                  │          │ stable │   │ / not resumable
            │                  │           ┌──────▼───────┐                 │          │        │   │
            │                  │           │   PF_SAFE    ├─────────────────┼──────────┼────────┘   │
            │                  │           └──────────────┘ (sweep done)    │          │            │
            │                  ▼                               reset req    ▼          │SHUTDOWN    │
            │          ┌─────────────┐  NAND idle / DRAIN_TMO  ┌────────────────┐      │_DONE       │
            │          │ RESET_DRAIN ├───────────────────────► │   RESET_HOLD   │◄─────┼────────────┘
            │          └─────────────┘                          └───────┬────────┘      │
            │                                                           │ 16 cycles     ▼
            └───────────────────────────────────────────────────────────┘          SHUTDOWN
```

| State | Admission (new commands) | NAND program / erase | NAND read | WP# | Sub-reset | Notes |
|---|---|---|---|---|---|---|
| POR_INIT | reject ABORT_RESET / NOT_READY | no | no | asserted | held | waits for `RESTORE_DEB` cycles of good supply |
| RECOVERY | reject NOT_READY | yes | yes | released | released | firmware mounts; `RECOV_TMO`; IRQ RECOVERY |
| RUN | admit | yes | yes | released | released | |
| RUN_RO | WRITE / TRIM rejected WRITE_PROTECTED, others admitted | no | yes | asserted | released | entered from recovery (RESULT=1) or `CTRL.READ_ONLY` |
| PF_DRAIN | reject ABORT_PWR_LOSS / QUIESCED | STOP: no; DIAG: after `PF_ACK`, up to `PF_BUDGET`; PLP_FLUSH (only with effective PLP): yes | not in STOP | once NAND idle and no permission | held only if the CPU was in reset | the op in flight finishes |
| PF_SAFE | reject | no | no | asserted | as above | tag sweep; waits for debounced good supply |
| PF_RESTORE | reject | no | no | asserted | as above | `CFG.REMOUNT_ON_RESTORE` (default) → RESET_HOLD; else `CTRL.RESUME` → RUN/RUN_RO |
| RESET_DRAIN | reject ABORT_RESET | no | no | once NAND idle | released | host / watchdog / SW (keyed) / crash-injection reset request |
| RESET_HOLD | reject | no | no | asserted | **asserted** | tags cleared, `RET_BOOTS++`, `RET_CAUSE` |
| SHUTDOWN | reject NOT_READY | no | no | asserted | released | clean shutdown done, `RET_FLAGS.UNCLEAN` cleared |
| FAILED | reject INTERNAL_ERR | no | no | asserted | released | recovery failed / timed out; reset request retries |

A power fault always wins over a reset request; a reset request during a power fault marks the CPU held (no
firmware is waited for, remount on restore).

## 2. Power-fail input

`pwr_fail_ni` → `sfv_sync` (2 flops, reset value "good") → glitch filter (`PF_FILTER` consecutive cycles) → `pf_lvl`.
`CFG.FORCE_PF` injects a fault for tests. Supply-good debounce: `RESTORE_DEB` consecutive good cycles (default 64)
before POR_INIT → RECOVERY or PF_SAFE → PF_RESTORE. On entry to PF_DRAIN the controller latches the policy and
budget, snapshots `RET_PF_SNAP` {state, outstanding, non-durable writes, durable-unacknowledged, NAND busy,
activity}, increments `RET_PF_COUNT` / `T_PF_EVENTS` and raises IRQ PF.

## 3. Outstanding-operation tracking and the gate (`sfpr_tag_tracker`)

Per tag: busy, kind, FUA, phase, VACKED, accept timestamp. Two event sources per cycle (datapath port and firmware
register, applied in order). Phase chain per kind (docs/02 §2), strict by default. The gate rules are in docs/02 §3.
One completion output slot (valid/ready); a release while it is occupied returns `CPL_RESULT.BUSY` (retry).
Telemetry: accept→DURABLE latency (last/max/sum/count), acknowledgements by kind, refusals, aborts.

**Late firmware events.** While the controller owns the tags (power-fault and reset states) a phase event or a
completion request for a tag the sweep / reset already retired is expected — the firmware may learn of the fault
after the controller acted (interrupt latency). Such events are counted in `T_LATE_FW`, not flagged as errors; outside
those states they set `ERR.PHASE_FREE_TAG` / `ERR.CPL_FREE_TAG`.

**Sweep.** On PF_SAFE entry (with `CFG.AUTO_ABORT`, default) every busy tag is completed once: DURABLE durable-kind
tags with SUCCESS (`CFG.ACK_DURABLE_ON_PF`, default), everything else ABORT_PWR_LOSS; VACKED tags are dropped and
counted (`T_VOL_LOST`, `ERR.VOL_LOST`) — impossible in the delivered configuration.

## 4. NAND gating and WP#

The NAND controller must not **start** an operation the controller does not permit (`nand_prog_ok_o`,
`nand_read_ok_o`); an operation already in progress (`nand_busy_i`) is never interrupted — WP# is asserted only when
the NAND is idle and no permission is granted, so a program is never cut by WP#. A start seen while not permitted
sets `ERR.NAND_OP_BLOCKED` / `T_NAND_BLOCKED` (a NAND controller that ignores the gate is detected). Operations
started in a power-fault state are counted (`T_PF_NAND_OPS`) and charged to the DIAG budget.

## 5. Reset sequencing

Requests: host reset (edge), watchdog (level), `CTRL.SW_RESET` with key `0x5AFE`, crash injection CPU_RESET, and
brown-out remount. RESET_DRAIN closes admission, refuses new NAND operations and waits for the one in flight (or
`DRAIN_TMO`, `ERR.DRAIN_TIMEOUT`); RESET_HOLD asserts `sub_rst_no` for 16 cycles (firmware CPU + storage datapath),
clears every tag (outstanding commands are aborted without completion — the host reset semantics of P51), then
RECOVERY. The controller itself is not reset by the requests it sequences.

## 6. Reset domains, retention, persistent commit status

| Domain | Cleared by | Contents |
|---|---|---|
| Functional (F) | `por_ni`, `rst_ni` | FSM, tags, configuration, ERR, IRQ, telemetry `T_*`, crash-injection unit |
| Retention (R) | `por_ni` only | `RET_BOOTS`, `RET_CAUSE`, `RET_FLAGS` {UNCLEAN, PF_SEEN, CRASH_FIRED, RECOV_FAILED}, `RET_PF_SNAP`, `RET_PF_COUNT`, `RET_SCRATCH0/1`, `CI_FIRED_AT`, `COMMIT_SEQ`, `CKPT_GEN` |
| NAND (persistent) | erase only | FTL checkpoint diagnostics + journal records (docs/04 §4) |

Retention survives every reset the controller sequences and the external hard reset, **not** a real power loss — it
is flops, not non-volatile memory. Persistent diagnostics are therefore also written to NAND by the firmware.

**Persistent commit status.** `COMMIT_SEQ` (64-bit, write LO then HI) and `CKPT_GEN` are monotonic: a lower value is
ignored and sets `ERR.SEQ_REGRESS`. The firmware publishes the FTL's highest durable SEQ after every durable command.
After a CPU-only reset the recovery manager checks that the recovered medium reaches at least the retained value — a
lower value would mean an acknowledged write was lost (`cpu_reset` campaign: 300 checks, 0 violations).

## 7. Crash-injection unit (`sfpr_crash_inj`)

`CI_CTRL` {ARM, ACTION, POINT, TAG_EN, TAG}, `CI_COUNT` (fire on the N-th occurrence), `CI_SEEN`, `CI_FIRED_AT`
(retained). Occurrences: firmware `CP_EVENT` writes with the point id (and optional tag filter); point 31 (NAND_OP)
counts `nand_start_i`. Actions: CUT_NOW (at the event), CUT_NEXT_PROG / CUT_NEXT_OP (pending until the next
program-erase / any NAND start: that operation is torn), CPU_RESET (the controller runs its reset sequence).
`crash_req_o` is a one-cycle pulse for the environment (testbench, co-simulation, or a bench supply switch).
One-shot; deterministic. Production builds tie the ARM write off or leave it unused.

## 8. PLP qualification (research path)

`plp_effective = PLP_PRESENT && CFG.PLP_QUAL && cap_ok_s && !revoked`. Without `PLP_PRESENT` the `PLP_QUAL` bit
reads 0 and requesting it (or PF_MODE PLP_FLUSH) sets `ERR.PLP_POLICY`; at a fault PLP_FLUSH degrades to STOP. With it,
a drop of `cap_ok_i` while qualified revokes PLP (`ERR.PLP_REVOKED`) until the firmware re-qualifies (writes
`PLP_QUAL` 0 then 1). Simulation assertions check that PLP behaviour is impossible without `PLP_PRESENT`.

## 9. Integration with StorageCore P51 (not done here)

The controller is verified standalone and in co-simulation with the C firmware; it was **not** inserted into the
P51 SoC RTL. Plan: register page at the next free storage page (`0x4000B000` proposed, `firmware/fw/sfps_mmio.c`);
`pwr_fail_ni` shared with `sfs_sys_regs` (P58 supersedes P51's PLP quiescence logic, which can stay as a fallback);
`cmd_*` admission port in front of `sfs_cmd_ctrl` tag allocation; `cq_*` between firmware completions and
`sfs_host_if`; `nand_*` from `sfs_nand_ctrl` (start pulse per channel op, busy = any channel busy) with
`nand_prog_ok_o` gating `OP_SUBMIT` of PROGRAM/ERASE; `wp_no` ANDed into `CH_CTRL.WP_N`; `sub_rst_no` into the
storage accelerator-domain reset; IRQ on the storage EVENT line.
