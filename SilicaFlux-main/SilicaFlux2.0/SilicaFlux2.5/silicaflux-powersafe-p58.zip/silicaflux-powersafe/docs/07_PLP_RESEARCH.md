# 07 — Optional capacitor-backed PLP: research model

**Status: research only. No hardware power-loss protection is claimed or enabled.** The RTL ships with
`PLP_PRESENT = 0`; the delivered design needs no stored energy for correctness (docs/06).

`plp_model/plp_model.py` (standard-library Python) sizes the hold-up energy that a *PLP-backed volatile write cache*
would need, from the firmware's worst-case flush work and **placeholder** electrical values in
`plp_model/plp_config.json`. Output: `reports/plp/PLP_MODEL.md`, `plp_sizing.csv`, two SVG charts.

## 1. Model

* **Energy needed** `E_req = P_shutdown · t_flush / η_worst · margin`
  * `t_flush = t_detect + t_in-flight + ⌈dirty / parallel⌉ · (tPROG + t_xfer) + journal · (tPROG + t_xfer) + erases · tBERS`
  * `t_detect` = supervisor delay + 2 sync + 2 filter clocks + firmware interrupt latency
  * `t_in-flight` = the program or erase already running (cannot be stopped)
* **Energy available** `E = ½ C_eff (V_hold² − V_low²)`
  * `C_eff = C_nom · (1 − tolerance) · (1 − temperature derating) · (1 − ageing)`
  * `V_low = V_min,regulator + UVLO margin + I_peak · ESR_end-of-life`
  * ageing: loss at reference temperature and age, doubling every 10 °C (rule of thumb)
* **Corners**: −40…85 °C, 0…10 years; sizing at the worst (coldest, oldest) corner.
* **Two NAND timing sets**: the NANDLab illustrative SLC values used by every simulation in this repository, and
  TLC-class worst-case program / erase values.

## 2. Results with the placeholder inputs

See `reports/plp/PLP_MODEL.md` for the full table. In short:

* STOP (delivered): **0 J needed** — nothing must be written after the warning.
* DIAG: one ring erase + one journal page — small, and still not needed for correctness.
* A PLP write cache with 16-256 dirty pages: tens to hundreds of millijoules with SLC-like timing, several hundred
  mJ to over a joule with TLC-class worst-case timing; the placeholder 8 × 470 µF / 12 V bank covers only the small
  SLC cases at the worst corner. Worst-case program time × dirty pages ÷ parallelism and the cold, aged corner
  dominate; detection latency is negligible.

These numbers inherit every placeholder; they are a sizing method, not a design.

## 3. How the RTL is prepared for it

| Mechanism | Behaviour |
|---|---|
| `PLP_PRESENT` (elaboration) | without it: `CFG.PLP_QUAL` reads 0, requesting it or `PF_MODE = PLP_FLUSH` sets `ERR.PLP_POLICY`, PLP_FLUSH degrades to STOP at a fault, assertions check that PLP behaviour cannot occur |
| `CFG.PLP_QUAL` | firmware's declaration after its boot-time capacitor self-test |
| `cap_ok_i` | capacitor health monitor; a drop while qualified **revokes** PLP (`ERR.PLP_REVOKED`) until re-qualified |
| `STATE.PLP_EFFECTIVE` | `PLP_PRESENT ∧ PLP_QUAL ∧ cap_ok ∧ ¬revoked` — the only PLP condition that allows an early acknowledgement |
| PF_MODE PLP_FLUSH | programs allowed in PF_DRAIN until `FW_SAFE`, so the firmware can drain volatile-acknowledged writes |
| sweep | a volatile-acknowledged write still not durable at PF_SAFE is reported lost (`T_VOL_LOST`, `ERR.VOL_LOST`) — the drain must leave this at 0 |

The RTL testbench exercises all of this with `PLP_PRESENT = 1` (`t_plp`): early acknowledgement only while
qualified and healthy, drain under PLP_FLUSH with nothing lost, revocation on `cap_ok` loss, re-qualification.

## 4. Qualification checklist (before `PLP_PRESENT = 1`)

1. A board design: hold-up rail, charger, isolation, regulator, supervisor with defined threshold / delay, capacitor
   health monitor on `cap_ok_i`.
2. Measured values replacing every placeholder: capacitance and ESR over temperature, regulator efficiency and dropout
   at the flush load, worst-case flush power, supervisor delay, firmware interrupt latency on the ControlCore.
3. Hold-up time measured with a programmable load at every corner, on aged parts, with margin.
4. On-board power-fail injection — thousands of cuts during cached writes — checked by this project's reference model.
5. Field self-test that drops `cap_ok_i` when the bank degrades.
