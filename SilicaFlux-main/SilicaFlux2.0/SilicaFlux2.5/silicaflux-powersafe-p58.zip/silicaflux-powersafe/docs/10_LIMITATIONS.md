# 10 — Limitations and what is not claimed

## Not claimed

* **Hardware power-loss protection.** No capacitor bank, regulator or supervisor exists; `PLP_PRESENT = 0`. The PLP
  model's electrical values are placeholders (docs/07).
* **Silicon, FPGA, real NAND.** Everything ran in simulation: the RTL on Verilator 5.020 and Icarus 12; the firmware on
  the host, linked with the Verilated RTL; the NAND is P56's behavioural `simnand`. The RV32IM build only shows the
  firmware compiles freestanding and its size; it did **not** run on the ControlCore / P51 SoC RTL.
* **Absolute times.** NAND times are NANDLab's illustrative values; controller clocks in the co-simulation include its
  register-access cost (one clock per access). Latencies are comparable with each other only.
* **Timing closure / area.** Yosys generic-cell counts only; no technology library, no timing.
* **NVMe compliance.** P51's NVMe-inspired command set; no namespaces, no atomic-write-unit guarantee beyond one
  logical page, no Asynchronous Event reporting of power events.

## Design limits

* **Fault model.** One unreadable metadata page in the live set is survived (P58 configuration). Losing both copies of
  a journal page, both live checkpoints, or the whole metadata zone is not: the latter fails safe (mount refuses,
  controller FAILED); the former can lose TRIMs. Data pages that are corrupted but pass CRC-32 are not detected.
* **Trust in the firmware.** The acknowledgement gate enforces "SUCCESS only at DURABLE", but DURABLE is reported by
  the firmware. A firmware that lies about phases defeats it (mutation F1 — the reference model then finds the loss).
  The gate is defence in depth against premature acknowledgement, not proof of durability.
* **Multi-page commands are not atomic** (per logical page only); multi-command ordering is not promised for commands
  outstanding together.
* **Stability of unacknowledged writes after media failures.** After a program or verify *failure* (not a power event)
  an unacknowledged page may exist on the medium with a valid CRC; such a value can appear only after the next
  recovery. Power-event paths are stable (docs/04 §5); this media-failure corner is inherited from P56.
* **Recovery time grows with device size** (page 0 of every block is read during an unclean mount); a checkpoint
  interval trades it against metadata writes (docs/09). No incremental / bounded mount for gigabyte devices.
* **Retention is flops.** `RET_*`, `COMMIT_SEQ`, `CKPT_GEN` survive every reset the controller sequences and the
  external reset, not a real power loss. Durable diagnostics live on NAND (docs/04 §4).
* **Single queue, synchronous firmware.** One command executes at a time; the tag tracker supports `NTAGS` outstanding
  hardware tags, but the co-simulated firmware uses one at a time.
* **Crash-injection unit in production.** It is a debug feature; a production build should tie off `CI_CTRL` writes.
* **P51 integration not done** — plan in docs/03 §9; the MMIO address `0x4000B000` is a proposal.
* **Late interrupt model.** The co-simulation delays interrupt delivery by 0-3 NAND operations or 64 clocks; real
  ControlCore latency must be measured.

## Mutation-check survivors

`reports/mutation.md` lists every planted defect and its verdict. Survivors are reported, not hidden: a *redundant
guard* (L10, the ring's live-region stop, unreachable while the room-based checkpoint trigger holds) and mutants that
became *equivalent* because the controller now enforces the same property in hardware (F2, L7).

## Tools

Installed from Ubuntu 24.04 packages for this work: Verilator 5.020, Icarus Verilog 12, Yosys 0.33,
`gcc-riscv64-unknown-elf` 13.2. Python standard library only.
