# 04 — Persistent metadata and FTL persistence integration

The FlashMap FTL (P56) already provides the on-NAND structures the brief asks for; P58 coordinates with it, hardens it
against one damaged metadata page, adds diagnostics, and fixes the hazards that appear once a controller can refuse
NAND operations while the system stays powered. On-NAND schema stays **version 1**: P58 media mount on P56 code and
vice versa (P58 fields sit in unused commit-page words and in journal record types P56 ignores).

## 1. Structures (P56, unchanged)

| Brief | Implementation |
|---|---|
| Versioned checkpoints | body pages (L2P + per-block state) followed by ONE commit page written last; `gen` +1 per committed checkpoint; commit holds `ckpt_seq`, body page runs, body CRC, geometry fingerprint, lifetime counters |
| Journal records | TRIM, ERASE (erase count), RETIRE, PRETIRE, MOUNT; 3-word records, many per page |
| Generation numbers | `gen` in every metadata page header; journal pages carry the generation they follow |
| Commit markers | the commit page; a checkpoint without a valid commit does not exist |
| Integrity checks | CRC-32 over data ‖ spare on **every** page; header magic + schema + kind/index cross-check; body CRC; L2P range check; geometry check |
| Recovery scanning | mount: catalogue metadata zone → newest loadable checkpoint (older on failure) → journal pass 1 → roll-forward of data pages newer than the checkpoint (SEQ order) → journal pass 2 (TRIM vs newer data) → rebuild VBM / counts → fresh ring block → post-recovery checkpoint |
| Torn / partially written metadata | a torn page fails ECC or CRC and is ignored; an interrupted checkpoint leaves the previous one in force; the ring never erases the live region |

## 2. P58 additions (options, off by default in `sfftl_cfg_default`, on in the P58 configuration)

| Flag / API | What | Why | Cost (docs/09) |
|---|---|---|---|
| `SFFTL_F_DUAL_CKPT` | the live region starts at the **previous** checkpoint; its first-page PPN and generation are recorded in the commit extension; mount keeps it live when it is still catalogued; ring sized `3·need + 3` | P56 protects the previous checkpoint only empirically: the ring recycled it **39 times** with checkpoints spanning several blocks (once in the P51 geometry) during `ring_invariants`, 0 times with DUAL_CKPT; a damaged newest commit at such a moment leaves no loadable checkpoint (`metadata_corruption`, 4 seeds: P56 83 / 240 recovered, the rest fail safe with ENOFS; P58 240 / 240) | +1 ring block (P51: 98.1 % user capacity; 512 MiB: 99.8 %) |
| `SFFTL_F_JOURNAL_MIRROR` | every journal page programmed twice (not during the power-fail flush) | a single unreadable journal page lost a TRIM in P56 — trimmed data came back (`metadata_corruption`, 4 seeds: P56 14 / 80, P58 80 / 80) | journal pages ×2 (≈ +3 % NAND programs at 6 % TRIM) |
| `SFFTL_F_VERIFY_WRITE` | each host page read back and compared before its mapping commit | VERIFIED phase is a real check, not only the status register | +1 read per host page, ≈ +6 % write latency |
| event hook `cfg.evt` | 20 named persistence points (`SFFTL_EV_*` = controller crash-point ids) | crash injection, phase reporting, telemetry | one function-pointer test per point |
| diagnostics `sfftl_diag`, `sfftl_ps_set_diag`, `sfftl_log_recovery` | numbered J_PFAIL / J_RECOVERY journal records; unclean-mount counter; all carried in every checkpoint commit | "preserve diagnostics" across power loss | one journal page per unclean recovery |

Replay is idempotent for mirrored pages: TRIM compares SEQs, ERASE takes the maximum, RETIRE / PRETIRE are set-once,
PFAIL / RECOVERY records are numbered.

## 3. Commit-page extension (words after `SFFTL_CK_W_END`)

| Word | Field |
|---|---|
| `SFFTL_CK_X_MAGIC` | `0x58383550` "P58X" (absent on P56 media → fields read as zero) |
| `SFFTL_CK_X_PREV_FIRST`, `_PREV_GEN` | previous checkpoint's first body page and generation |
| `SFFTL_CK_X_UNCLEAN` | unclean mounts |
| `SFFTL_CK_X_PF_COUNT`, `_PF_INFO` | power-fault records and the newest snapshot (controller `RET_PF_SNAP`) |
| `SFFTL_CK_X_RC_COUNT`, `_RC_INFO` | recovery records and the newest summary {cause, mount kind, rejected checkpoints, replayed pages} |

97 words in total; the smallest page (512 B) has 124.

## 4. Diagnostics flow

| Event | Volatile (controller retention) | Persistent (NAND) |
|---|---|---|
| power fault | `RET_PF_SNAP`, `RET_PF_COUNT`, `RET_FLAGS.PF_SEEN`, IRQ | DIAG policy: J_PFAIL record in the single permitted journal page (best effort) |
| reset sequence | `RET_CAUSE`, `RET_BOOTS` | — |
| unclean recovery | `T_RECOVERIES`, `T_RECOV_CYC_*` | `unclean_mounts` (next checkpoint) + J_RECOVERY record written before RECOVERY_DONE |
| every checkpoint | — | all diagnostic counters in the commit extension |

`diagnostics` campaign: 12 power cuts → `unclean_mounts` 12, recovery records 12, survived 4 clean power cycles.
`power_fault`: the DIAG record is found after 96 / 96 brown-outs (4 seeds × 24).

## 5. Hazards found by the P58 campaigns and fixed in the FTL

P56's PowerSafe hook assumed WP# arrives only with a real power loss. With a controller that refuses NAND operations
while the system is alive (STOP policy, brown-out resume, interrupt latency), five latent problems appeared. Each is
covered by a mutant in `reports/mutation.md`.

| # | Hazard | Symptom | Fix |
|---|---|---|---|
| 1 | A refused program (WP#) still consumed its page (`wp++`) | an erased page in the middle of an open block ends the mount scan of that block: data written behind it after a resume is lost at the next crash | `write_page` / `meta_append` roll the page back on `SFFTL_HAL_WRITE_PROTECT` (nothing was programmed) and return EPOWER |
| 2 | An aborted TRIM left its record queued | the next journal flush (after the host rewrote those LBAs) writes a TRIM with a newer SEQ → acknowledged data unmapped at the next mount | on journal-flush failure the TRIM record is removed if still queued; if its page did reach NAND the unmap is applied in RAM as well (RAM = medium) |
| 3 | A refused read was treated as a media error | GC retired healthy blocks; verify / marker reads misjudged pages | `hal_dead()` = POWER_LOSS or WRITE_PROTECT → EPOWER everywhere, `hal_rc(WRITE_PROTECT)` = EPOWER |
| 4 | With write verify, a refused read-back after a program that returned PASS aborted without the mapping commit | RAM said old, the medium (roll-forward) said new → value flips at the next crash | commit the mapping before returning EPOWER |
| 5 | A checkpoint in progress kept writing after the power-fail warning | spent the DIAG budget; diagnostics lost | `ckpt_write` stops at the next page boundary when warned (the previous checkpoint stays in force) |

## 6. Change list vs P56 (`third_party/p56_baseline/SHA256SUMS.p56-ftl`)

`include/sfftl.h` (flags, event ids, `sfftl_diag_t`, fields, stats), `include/sfftl_schema.h` (commit extension,
J_PFAIL / J_RECOVERY), `include/sfftl_powersafe.h` (`sfftl_ps_set_diag`), `src/sfftl_internal.h` (`EVT`,
`hal_dead`), `src/ftl_alloc.c` (events, refused-program rollback), `src/ftl_io.c` (verify, events, aborted-TRIM
handling, diagnostics API), `src/ftl_gc.c` (events, verify-refusal commit), `src/ftl_meta.c` (events, mirror, dual
live region, extension, checkpoint stop), `src/ftl_mount.c` (ring sizing, extension load, diagnostics replay, dual
live start, events, stats), `src/ftl_util.c` (erase events, `hal_rc`), `src/ftl_bbm.c` (`hal_dead`),
`tests/harness.*`, `tests/test_main.c` (`--p58` switch). The P56 test suite passes 27/27 with and without the P58
flags.
