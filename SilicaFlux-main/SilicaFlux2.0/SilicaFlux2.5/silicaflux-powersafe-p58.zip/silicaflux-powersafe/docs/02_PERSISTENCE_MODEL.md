# 02 — Write persistence model

Exact definitions of the states a command passes through, when each holds, who observes it, and when the host may be
told. The controller tracks them per tag (`TAG_INFO.PHASE`); the firmware reports them (`PHASE_EV`); the
acknowledgement gate enforces the last row.

## 1. States of a WRITE

| State | Exact condition | Survives a crash? | Reported when |
|---|---|---|---|
| **Accepted** | Admission control allowed the command (state RUN; RUN_RO refuses WRITE), a tag was allocated, fields validated. | No — nothing is stored. | `CMD_SUBMIT` → `CMD_RESULT.ACCEPTED` (or `cmd_accept_o`) |
| **Buffered** | All host data of the command is in controller memory (buffer SRAM / firmware page buffer). P55: "H2B completion means committed in the volatile buffer, never durable". | No. | firmware, after the host→buffer transfer |
| **Programmed** | For every logical page of the command, a NAND program (data + 16-byte spare record {BBM, type, LPN, SEQ, CRC-32}, one ECC codeword) was issued and returned. | Not yet known: status not checked. | event POST_PROGRAM of the command's last logical page |
| **Verified** | Every program status was PASS; with `SFFTL_F_VERIFY_WRITE` each page was also read back and compared (data, CRC, LPN). A failed page is retired and re-written elsewhere before this state. | **Yes** for the programmed pages (roll-forward finds them by SEQ) — but not yet visible in RAM. | event PRE_MAP of the last page |
| **Mapping committed** | `L2P[LPN] = new page` in RAM, previous copy invalidated. Its persistent evidence is the spare record already on NAND — no extra metadata write is needed. | Yes. | event POST_MAP of the last page |
| **Durable** | All pages of the command are mapping-committed, i.e. `sfftl_write()` returned SFFTL_OK. Every SEQ ≤ the published `COMMIT_SEQ` is on the medium. | **Yes**, for any supported crash. | firmware `PHASE_EV DURABLE` |
| **Acknowledged** | The controller released a SUCCESS completion for the tag (CQ handshake). | Yes (it was durable first). | controller, `cq_valid_o` & `cq_ready_i` |

Ordering per page is strict (program → status → verify → map); pages of one command are processed in LBA order, one
at a time, so a command is PROGRAMMED when its last page is.

## 2. Other commands

| Command | Chain the controller enforces | Durable when |
|---|---|---|
| TRIM / DEALLOCATE | ACCEPTED → PROGRAMMED → VERIFIED → MAPPED → DURABLE (no BUFFERED) | its journal page (TRIM record) is programmed with PASS **before** the RAM unmap; partial-page head / tail are written as zeros (read-modify-write, like a WRITE) |
| FLUSH | ACCEPTED → DURABLE | journal records buffered in RAM (erase counts) are on NAND, **and** no volatile-acknowledged write is outstanding |
| READ, ADMIN | any increasing sequence | no durability semantics; SUCCESS allowed at any phase |
| FUA write | as WRITE | identical — every write is already durable at acknowledgement; FUA additionally can never be early-acknowledged |

An out-of-order or skipped phase is refused (`CFG.STRICT_PHASES`, default) and flagged `ERR.PHASE_ILLEGAL`.

## 3. The acknowledgement rule

The controller releases a **SUCCESS** completion for a WRITE, TRIM or FLUSH only when the tag is **DURABLE** (FLUSH
also needs `OUTSTANDING.VACKED == 0`). Anything else is refused (`CPL_RESULT.REFUSED`, `ERR.ACK_BEFORE_DURABLE`,
`T_GATE_REFUSED`). Error completions are always released.

The only exception is an **early (volatile) acknowledgement** of a non-FUA WRITE at BUFFERED or later, permitted
only while `STATE.EARLY_ACK_OK`, i.e. in RUN and

* `CFG.WCE` — the host explicitly enabled a volatile write cache (it then owns the risk and must FLUSH), or
* `PLP_EFFECTIVE` — `PLP_PRESENT` **and** `CFG.PLP_QUAL` **and** `cap_ok_i` **and** not revoked.

An early-acknowledged tag stays allocated (`VACKED`) until DURABLE, then frees without a second completion. In the
delivered configuration neither condition holds, so **every acknowledgement is durable**.

## 4. What the host may observe after a crash

| Command state at the crash | Contents after recovery |
|---|---|
| Acknowledged | new contents, always |
| Durable, not acknowledged (e.g. crash at PRE_COMPLETION) | almost always new — but the host was not told, so old is also legal |
| Mapping committed / verified / programmed, not durable | each logical page: old **or** new (atomic per page) |
| Accepted / buffered | old |
| Aborted with ABORT_PWR_LOSS during a brown-out | old or new per page, then **stable** |

"Stable" — the first read after recovery decides the value; later crashes and recoveries must not flip it. This is
stronger than "indeterminate" and needed the P58 FTL changes in docs/04 §5 once the controller can refuse NAND
operations while the system stays alive.

## 5. Why acknowledged writes survive (argument)

1. A write is acknowledged only at DURABLE (gate, §3); DURABLE implies every page of it was programmed with PASS and
   carries {LPN, SEQ, CRC} (FTL contract, unchanged from P56).
2. Such a page is found by the roll-forward unless it is older than the checkpoint in use (then the checkpoint holds
   its mapping) or it was superseded (a newer page of the same LPN — a later write or a GC copy with higher SEQ — or a
   TRIM journalled with higher SEQ). P56 docs/07 §6 gives the case analysis; P58 adds that the checkpoint and journal
   pages it relies on survive one damaged page (dual checkpoint, mirrored journal).
3. A crash cannot make the controller release an acknowledgement after the fact: the completion slot and all tags are
   functional-domain state, cleared by power-on reset; a CPU reset clears tags without completion.
4. The firmware cannot acknowledge on its own: completions pass the controller's gate. The gate trusts the firmware's
   phase reports — a firmware that lies about DURABLE defeats it (mutation F1 shows the reference model then finds the
   loss).
