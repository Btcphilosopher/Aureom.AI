# 08 — Verification

Results with numbers: **`reports/TESTS.md`** (generated from the logs). This document explains what each layer
checks and why it is credible.

## 1. Layers

| Layer | What runs | Judges |
|---|---|---|
| RTL unit testbench | `tb/tb_storage_recovery.sv` on Verilator (3 seeds) and Icarus, `PLP_PRESENT` 0 and 1 | 17 directed + random tests; a scoreboard checks **every** completion handshake against its own phase model: no SUCCESS for WRITE/TRIM/FLUSH below DURABLE (unless a legitimate early ack), no completion for a free tag; RTL `$error` assertions |
| FTL regression | the P56 suite (27 tests incl. power cut at every device op, mount-op sweep, random cuts with faults), unchanged, with and without the P58 flags | P56's own reference model and invariant checker |
| Co-simulation campaigns | Verilated controller + real firmware (sfps + FTL) + persistent simnand + host model | the recovery reference model (`rrm`) after every recovery; controller ERR register; NAND rule violations; RTL assertions |
| Sanitizers | the campaigns under ASan + UBSan (including the `longjmp` abandonment) | no report |
| Mutation check | 23 planted defects across RTL, firmware and FTL | the test meant to notice each must fail |
| Lint / synthesis | Verilator `-Wall` (2 views × 4 parameter sets), Icarus elaboration, Yosys `check -assert` | zero warnings, zero latches |

## 2. Campaigns (`build/test_recovery`)

| Test | Scenario | Brief |
|---|---|---|
| `crash_points` | 19 named points × 3 actions × sampled occurrences on a full device (GC, static WL, checkpoints, TRIM, FLUSH, reads) | §5 all eight crash locations, §9 fault injection |
| `nand_op_sweep` | power cut at each of 1 200 consecutive NAND operations | §5 during program / erase / journal / checkpoint |
| `repeated_recovery` | a crash, then 1-3 nested crashes inside the recoveries (mount scan, post-mount checkpoint, any op; power or CPU) | §9 repeated recovery |
| `random` | 160 runs: 6 geometries, GC policies, WL policies, paced / blocking GC, dual / mirror / verify on or off, checkpoint intervals, NAND program / erase failures and read flips, several crashes per run, clean cycles | §9 random workloads |
| `power_fault` | warning at a random NAND op; STOP / DIAG; loss after 1-60 or 3-6 k clocks, or brown-out with remount or resume; interrupt latency 0-3 ops; then more work, an unclean cut, verification | §3, §6 power-fault behaviour |
| `metadata_corruption` | one damaged live metadata page (newest commit / body / journal / random live / stale / correctable flips), a double fault (newest commit + cut while the ring recycles a block), whole zone lost; P58 vs P56 configuration | §4, §9 metadata corruption |
| `ring_invariants` | white box: at every ring erase, the newest checkpoint is never erased; with DUAL_CKPT, nor the previous one | §4 versioned checkpoints |
| `aborted_trim` | TRIM aborted at its journal program by a fault the firmware learns of late, resume, rewrite, flush, cut | §8 ordering contract |
| `full_device` | every LBA written, 4 % over-provisioning, ENOSPC, crash points in GC | §9 full storage |
| `gc_wl` | aggressive static wear levelling × greedy/paced and cost-benefit/blocking GC × GC / WL / erase points | §9 GC and wear-levelling interaction |
| `gate_defense` | firmware fault injection: SUCCESS requested at BUFFERED; the controller must refuse, and crashes must still lose nothing | defence in depth |
| `cpu_reset` | watchdog-like CPU loss at random NAND ops; retained commit status checked at every recovery | §3 persistent commit status |
| `diagnostics` | 12 power cuts: unclean-mount count and recovery records persist across checkpoints and clean cycles | §6 preserve diagnostics |
| `p56_config` | the crash-point sweep on the P56 configuration (no dual / mirror / verify) | baseline |

## 3. Bugs and weaknesses the campaigns found (all fixed)

| Found by | Problem | Layer | Fix |
|---|---|---|---|
| power-fault brown-out (resume) | refused program consumed its page → erased gap in an open block | FTL | roll back on refusal |
| power-fault design review + `aborted_trim` | aborted TRIM's journal record flushed later → acknowledged rewrite unmapped | FTL | drop or apply |
| power-fault STOP | refused read treated as media error | FTL | `hal_dead` |
| power-fault die-fast | refused read-back after PASS: RAM/medium split, value flips after the next crash | FTL | commit mapping first |
| power-fault DIAG | checkpoint continued after the warning, spent the budget | FTL | stop at page boundary |
| power-fault DIAG + latency | firmware work started before it knew of the fault spent the budget | RTL protocol | `CTRL.PF_ACK` |
| power-fault + latency | late completion of a swept tag flagged as a firmware error | RTL | `T_LATE_FW` while the controller owns the tags |
| brown-out remount + latency | stale PF interrupt after a reset put the new firmware into power-fail mode | firmware | clear IRQ at boot, act on PF only in a PF state |
| random trial 52 | FTL worn out → read-only, controller still in RUN | RTL + firmware | `CTRL.READ_ONLY` (RUN → RUN_RO) |
| metadata corruption (P56 config) | one unreadable journal page lost a TRIM | FTL | journal mirror |
| ring invariants (multi-block checkpoint) | P56 ring recycled the previous checkpoint 39 × (1 × in the P51 geometry) | FTL | dual checkpoint |
| harness (mutation survivors) | interrupt delivered instantly, no firmware idle loop, identical tear mode in every single-crash run | test infrastructure | latency model, idle main loop, tear mode reseeded per crash position |

The last row matters for credibility: the first mutation run caught only 6 of 21 planted defects; the misses were
traced to the harness being too ideal, and fixed before the final results.

## 4. Independence

* `rrm` never looks at FTL or controller state — only at what the host submitted and the completions it received.
* The RTL testbench's scoreboard keeps its own phase model.
* The controller's gate is checked from both sides: the testbench (RTL alone) and `gate_defense` (with firmware).
* Deterministic seeds: every failure is reproducible (`--seed`, `RANDOM_TRIAL`).
