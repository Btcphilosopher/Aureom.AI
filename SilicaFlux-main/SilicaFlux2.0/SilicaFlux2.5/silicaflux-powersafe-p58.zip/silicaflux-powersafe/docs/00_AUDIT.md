# 00 — Repository audit (Project 58 PowerSafe)

Audited: `btcphilosopher/Aureom.AI`, branch `claude/inspiring-albattani-uo15g5`, commit `4173a23`. As for every earlier
SilicaFlux project, the hardware and firmware work lives in zip archives under `SilicaFlux-main/` and
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`. The archives relevant to power loss and recovery were extracted and read:
`silicaflux-flashmap-p56.zip` (FTL), `silicaflux-storagecore-p51.zip` (StorageCore SoC: command path, DMA, NAND
controller, PLP pins, firmware), `silicaflux-buffercore-p55.zip` (write buffers), `silicaflux-ecccore-p54.zip`,
`silicaflux-flashlink-p53.zip`, `silicaflux-nandlab-v0.1.0.zip` (P52 NAND model), `silicaflux-controlcore.zip` (P21),
`silicaflux-powerclock.zip` (P27) and `silicaflux-hpc-m05-dma-adapter.zip`. "Evidence" is what the owning project
recorded; it was not re-run unless stated.

## 1. Findings per area named in the brief

| Area | Found | Consequence for P58 |
|---|---|---|
| **FTL** (P56 FlashMap) | C99 freestanding page-mapping FTL for the ControlCore. Every data page carries a 16-byte spare record {BBM, type, LPN, 48-bit SEQ, CRC-32} programmed in the same ECC-protected operation; a write returns OK only after its pages are programmed and mapped; TRIM only after its journal page. Metadata ring with commit-last checkpoints, journal, generation counter, roll-forward mount. 27 host tests incl. power cut at every device op. Header `sfftl_powersafe.h`: *"No PowerSafe project exists in the repository yet. This header is the contract the FTL offers to it."* | P58 builds on it. **Re-run here:** 27 / 27 pass unchanged (`reports/ftl_p56_suite.log`). P58 extends it (event hooks, dual checkpoint, journal mirror, write verify, diagnostics) and fixes four latent hazards that only appear once a controller can refuse NAND operations while the system stays powered (docs/04 §5). |
| **NAND model** | P52 NANDLab (SV device twin) and P56 `hal/sim/simnand.c` (C, NANDLab semantics: erase→1, program 1→0, ascending pages, factory markers, program/erase failures, torn programs on power loss, a quarter of torn pages "corrected" into garbage, seeded faults, timing). P51 `sfs_nand_flash_model.sv`. | `simnand` is the **persistent NAND backing store** of every campaign: it survives power cuts, CPU resets and controller resets; only erases change it. |
| **Write buffers** (P55 BufferCore) | Banked SRAM slots; H2B completion = "committed in the **volatile** buffer, never durable"; DIRTY cleared only by `COMMIT_D` after a successful NAND program; `STATUS.early_ack_ok = WCE \| PLP_PRESENT`; power fail refuses new H2B; "Nothing here claims data survives a reset or power loss without PLP draining." | Consistent with P58: BUFFERED is a volatile phase; the controller's gate refuses SUCCESS at BUFFERED unless WCE or qualified PLP. `PLP_PRESENT` stays 0. |
| **DMA** (P51 `sfs_dma`, HPC M05 adapter) | Completion = every write acknowledged by its target; abort only at beat boundaries; no quiesce input; reset discards queued descriptors without completion. | DMA completion only reaches BUFFERED; it never implies durability. Reset sequencing drains the NAND, not the DMA (DMA work is volatile). |
| **PowerClock** (P27) | DVFS / clock gating / thermal manager. **No** power-good, brown-out, voltage monitoring, retention or energy concept (`CAP.VOLTAGE_CTRL/POWER_SWITCHING` hard-wired 0). Reset synchroniser `sf_reset_sync`; drain handshake. | Nothing to reuse for power faults; P58 adds the power-fault FSM. |
| **ControlCore** (P21) | MCU-I RV32IM; reset domains POR / sys / accelerator; `cc_sysctrl` RESET_CAUSE {POR, SOFT, WDT, HOST} and SCRATCH0-3 in the POR domain (survive warm resets); watchdog; **no power-fail interrupt**; free IRQ lines 7-15; `ext_warn_i/ext_fatal_i`. | P58 keeps the same idea (POR-domain retention, reset cause) for the storage side and adds what is missing: power-fault cause, PF snapshot, persistent commit status. |
| **NVMe Flush handling** | P51 opcodes FLUSH 00h, WRITE 01h (+FUA), DEALLOCATE 09h. P51 firmware: FLUSH / FUA = checkpoint. P56: every acknowledged write is already durable, so FLUSH only commits buffered journal records (erase counts), FUA is implicit. | P58 FLUSH = durable kind: SUCCESS only at DURABLE **and** no volatile-acknowledged write outstanding (relevant only with WCE). FUA is never early-acknowledged. |
| **Metadata journal** | P56 ring: checkpoint body + commit (written last), journal records TRIM / ERASE / RETIRE / PRETIRE / MOUNT, CRC on every page, live region = newest checkpoint → head. | A damaged newest checkpoint falls back only if the previous one happens to be unerased, and a single unreadable journal page loses a TRIM. P58 adds dual-checkpoint retention and journal mirroring (measured in docs/09, demonstrated in the corruption campaign). |
| **Reset sequencing** | P51 `sfs_sys_regs` PLP: `pwr_fail_ni` → 2-flop sync → EVENT → QUIESCE (new commands ABORT_PWR_LOSS) → DRAINED → firmware FW_SAFE → AUTO_WP forces WP#; CLR on return. Storage on the ControlCore accelerator-domain reset. | Reused as the pattern and the status codes (ABORT_PWR_LOSS 0x05, QUIESCED 0x0E, NOT_READY 0x0F). P58's controller adds what P51 lacks: per-tag persistence tracking and an acknowledgement gate, in-flight policy with NAND budget, brown-out restore, recovery mode with timeout, reset sequencing that drains the NAND before resetting the CPU, retention, telemetry, crash injection. |
| ECC (P54) | BCH t=8 per 512-B sector + CRC-16; sector status CLEAN / CORRECTED / ERASED / UNCORR / INTEGRITY; `all_erased` intended for the FTL after power loss. | Matches the FTL's assumption that torn pages are rejected (ECC or CRC). Not integrated in the co-simulation (simnand models ECC behaviourally). |

## 2. What did not exist before P58

* any component that ties a **host acknowledgement** to **durability** in hardware;
* a **recovery mode** (controller state while the firmware mounts) and reporting of its result;
* a defined **in-flight policy** that assumes no hold-up energy;
* **deterministic crash injection** at named points (P56 cut power at device-op indices only);
* a crash-consistency reference model that judges at **logical-page** granularity with the host's view of acknowledgements;
* any **PLP energy model**.

## 3. Reuse

| Reused | How |
|---|---|
| P56 FTL (`firmware/silicaflux_ftl/`) | copied, extended in place; `third_party/p56_baseline/SHA256SUMS.p56-ftl` records the delivered P56 sources; every change is listed in docs/04 §6. The P56 test suite is kept unchanged (plus a `--p58` switch). |
| `simnand` (P56) | unchanged; the crash framework wraps it. |
| `sfv_common.sv` (SilicaFlux-V, vendored through P51) | **unmodified** (`sfv_sync` for `pwr_fail_ni` / `cap_ok_i`, `sfv_rst_sync` for both reset domains); SHA-256 `4c79395516527ef31bab858a3211965466dcd7c7b9d80d5e6d0a87be0bbc290f`, identical in all three archives that carry it. |
| P51 status / error codes, `rb_*` register-bus convention | same values and bus protocol. |

## 4. Tools

Installed in this container from Ubuntu 24.04 packages (the versions earlier projects record): Verilator 5.020,
Icarus Verilog 12, Yosys 0.33, `gcc-riscv64-unknown-elf` 13.2; host gcc 13.3, Python 3.13 (standard library only).
