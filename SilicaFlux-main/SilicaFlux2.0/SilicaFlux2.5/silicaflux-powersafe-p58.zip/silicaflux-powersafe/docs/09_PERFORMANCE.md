# 09 — Performance

Full tables, CSVs: `reports/perf/PERF.md`, `latency.csv`, `recovery.csv` (`make perf`). Times are **modelled**
(NANDLab illustrative SLC timing: tR 25 µs, tPROG 200 µs, tBERS 2 ms + bus transfer) and only comparable with each
other.

## 1. Write completion latency (16 MiB device, full, random 1-16 LBA writes, 3 000 commands)

| Configuration | p50 | p90 | p99 | max |
|---|---|---|---|---|
| P56 baseline | 4.01 ms | 8.20 ms | 10.46 ms | 14.30 ms |
| P58 full (dual checkpoint + journal mirror + write verify) | 4.27 ms | 8.46 ms | 10.89 ms | 13.43 ms |

Durable-before-acknowledge is P56's existing contract, so P58 adds latency only through write verify (+1 page read,
≈ +6 % at p50). The dominant cost is the device being full (GC inside writes). An early acknowledgement at BUFFERED
would cost ≈ 0 NAND time but is **not available** without qualified PLP or a host-enabled volatile cache.

## 2. Journal overhead and metadata write amplification

| Configuration | metadata programs per host page | journal pages per 1 000 host pages | checkpoints per 1 000 host pages |
|---|---|---|---|
| P56 baseline | 0.060 | 29.1 | 1.96 |
| + dual checkpoint | 0.057 | 30.1 | 1.82 |
| + journal mirror | 0.088 | 61.1 | 1.82 |
| + write verify | 0.088 | 61.1 | 1.82 (+1.00 read per host page) |

The mirror doubles journal pages (+0.03 metadata programs per host page, i.e. ≈ +3 % of all NAND programs at 6 %
TRIM); the dual checkpoint costs no extra programs (the ring is larger instead).

## 3. Recovery time vs checkpoint frequency

| Device | ckpt interval (block openings) | unclean mount: NAND ops / modelled ms (mean) | clean mount ms | metadata programs per host page |
|---|---|---|---|---|
| P51 (64 × 16 × 512 B) | 2 | 196 / 11.7 | 3.9 | 0.571 |
| | 8 | 248 / 13.7 | 4.1 | 0.174 |
| | 32 | 482 / 22.8 | 4.0 | 0.064 |
| 16 MiB (128 × 64 × 2 KiB) | 2 | 603 / 56.4 | 29.7 | 0.204 |
| | 8 | 703 / 64.5 | 30.8 | 0.072 |
| | 32 | 995 / 86.8 | 14.3 | 0.038 |

The checkpoint interval trades roll-forward length (recovery time) against metadata writes; the default (automatic,
`max(8, blocks/4)`) sits in the middle. An unclean mount always reads page 0 of every block, so it grows with device
size. The controller's own recovery time telemetry (`T_RECOV_CYC_LAST/MAX`) measures RECOVERY-state clocks on target.

## 4. Capacity and memory consumed by recovery structures

| Device | metadata-ring blocks P56 → P58 | user capacity P58 vs P56 | firmware arena P56 → P58 |
|---|---|---|---|
| P51 (512 B × 16 × 64) | 5 → 6 (9.4 %) | 98.1 % | 8.3 → 8.5 KiB |
| 16 MiB (2 KiB × 64 × 128) | 5 → 6 (4.7 %) | 99.1 % | 46.3 → 47.3 KiB |
| 512 MiB (4 KiB × 128 × 1024) | 7 → 9 (0.9 %) | 99.8 % | 539 → 543 KiB |

Spare area: 16 bytes per page for the self-describing record (all of a 528-byte P51 page's spare). The controller adds
no NAND structure; its silicon cost is in `reports/synth.md` (≈ 15.7 k generic cells, mostly 32-bit telemetry and
retention registers, which a production build can trim).

## 5. Firmware

RV32IM `-Os`: FTL + PowerSafe layer + MMIO bus **37.0 KB text, 0 data, 0 bss** (P56 library 29.6 KB; P58 FTL
changes +2.4 KB, `sfps` 4.9 KB). Per command the firmware adds ≈ 5-8 register accesses (submit, phases, completion,
commit status) plus one `CP_EVENT` write per FTL event when crash-point forwarding is enabled (debug builds).
