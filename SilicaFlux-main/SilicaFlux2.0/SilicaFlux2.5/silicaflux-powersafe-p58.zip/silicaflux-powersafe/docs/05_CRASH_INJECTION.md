# 05 — Crash-injection framework

## 1. What is co-simulated

```
 test_recovery (host model + reference model rrm)
      │ commands                         ▲ completions (CQ handshakes)
 ┌────▼──────────────────────────────────┴───────────────────────────┐
 │ firmware context (abandonable): sfps  ──►  FlashMap FTL           │
 │      │ registers (sfps_bus_t)              │ HAL                   │
 └──────┼─────────────────────────────────────┼──────────────────────┘
        ▼                                      ▼
 Verilator model of silicaflux_storage_recovery ◄── NAND-controller model (sfci): nand_begin/end pins,
   (cosim/sfpr_cosim.cpp: clock, registers,          refuses what the RTL does not permit,
    pins, CQ log, crash_req)                         tears the op when crash_req fires
                                                       │
                                               simnand: persistent NAND backing store
```

* **The RTL is the real controller**, not a model of it: every register access, phase event, completion, NAND
  permission, WP#, reset and crash-injection decision in the campaigns is made by the Verilated
  `silicaflux_storage_recovery.sv`; its `$error` assertions count as failures.
* **The NAND is persistent**: `simnand` (P56, unchanged) keeps every page across power cuts, CPU resets and controller
  resets; a power cut during an operation tears it (program: page partially programmed, a quarter of torn pages
  "correctable" into garbage; erase: block untouched, erased or partially garbage).
* **The firmware is abandoned**: a crash `longjmp`s out of whatever the firmware was doing — inside the FTL, a GC copy,
  a checkpoint, the mount — so its RAM is gone exactly as on real hardware. A fresh firmware instance boots and mounts.
* **The host is independent**: it only knows what it submitted and which SUCCESS completions it saw.

## 2. Determinism

Every crash is specified by (point, N-th occurrence, action) and armed in the controller's crash-injection unit; the
workload is a seeded generator; simnand faults are seeded.  How a cut operation tears (not started / completed /
almost done / torn with or without its spare record, ECC passing or failing) is drawn from a generator re-seeded
from the crash position — without that, every single-crash run drew the same "almost done" mode and the replay-CRC
mutant survived. The same seed reproduces the same crash at the same
instruction. `./build/test_recovery --seed N [test]` reruns a campaign; `RANDOM_TRIAL=k` isolates one random trial.

## 3. Crash points (the brief's eight and more)

| Brief | Points used | Actions applied |
|---|---|---|
| before NAND programming | PRE_PROGRAM | CUT_NOW, CUT_NEXT_PROG, CPU_RESET |
| during program operation | IN_PROGRAM (+ CUT_NEXT_PROG from any point; NAND_OP sweep) | torn program |
| after data programming | POST_PROGRAM | all three |
| before mapping update | PRE_MAP (+ GC_POST_COPY, WL_POST_COPY for relocations) | all three |
| during metadata journal update | PRE_JOURNAL, IN_JOURNAL, TRIM_PRE_UNMAP | all three; torn journal page |
| before command completion | PRE_COMPLETION | all three |
| during garbage collection | GC_IN_COPY, GC_POST_COPY, GC_PRE_ERASE, IN_ERASE, WL_POST_COPY | all three; torn copy / erase |
| during checkpoint creation | CKPT_BODY, CKPT_PRE_COMMIT, CKPT_IN_COMMIT, CKPT_POST_COMMIT, META_ERASE | all three; torn body / commit / ring erase |
| (recovery) | MOUNT_SCAN, MOUNT_CKPT, NAND_OP during boot | nested up to 3 deep |
| (anything) | NAND_OP = N-th device operation | cut at every op index |

Actions: **CUT_NOW** power lost at the event (between operations); **CUT_NEXT_PROG** power lost during the next
program / erase after the event (that operation tears); **CPU_RESET** firmware lost at the event, the NAND op in
flight completes, the controller drains and resets; **CUT_NEXT_OP** any next op.

## 4. Campaign structure

1. Fresh device, format, fill (so GC, static WL and checkpoints all occur), seeded workload: 70 % writes of 1-12 LBAs
   (hot 1/8 at 70 %, some sequential), 10 % reads (verified through the full firmware path), 8 % TRIM, 4 % FLUSH,
   6 % background GC, 2 % checkpoints.
2. A **dry run** counts each point's occurrences inside the armed window; the sweep then crashes at the first few and
   at evenly spread later occurrences of every point, for every action.
3. After the crash: power-on reset of the controller (or its own reset sequence), NAND power back, firmware boot,
   recovery mount, **full-device verification** against the reference model, workload continues, then a clean
   shutdown + power cycle + clean-mount verification, plus checks that the controller's ERR register holds no defect
   bit, the NAND saw no rule violation, and no RTL assertion fired.

## 5. Reference model (`firmware/tests/rrm.c`)

Per LBA the version the host last saw acknowledged; one command "in doubt" at a time (the one in flight without a
SUCCESS). Verification reads every logical page and requires: LBAs outside the doubt range hold their acknowledged
version; inside it, each logical page is entirely old or entirely new; the observed choice becomes the acknowledged
value (stability across later crashes). Data are deterministic patterns of (LBA, version) with the LBA and version in
the first 16 bytes, so a violation reports what was found ("found version 65") — that is how the five FTL hazards in
docs/04 §5 were diagnosed.

## 6. Interrupt latency and the firmware main loop

The co-simulation delivers the controller's interrupt to the firmware only after 0-3 further NAND operations or 64
clocks (random per run), and runs the firmware's idle main loop (`sfps_poll`) while the harness waits. Both matter:
with instant interrupt delivery the controller-refusal paths were never exercised and three FTL mutants survived;
with them, the campaigns found the stale-interrupt-after-reset and DIAG-budget issues (docs/06 §5).
