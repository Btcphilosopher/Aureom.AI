# 01 — PowerSafe design specification

Project 58 · Aureom.AI | SilicaFlux-STORE · primary RTL `rtl/silicaflux_storage_recovery.sv`

## 1. Goal and the one guarantee

Survive unexpected controller resets and power interruptions **without losing any write the host was told is
durable.** The fundamental invariant, checked after every injected crash in this project:

> **Every acknowledged durable write (and TRIM) is present and correct after any supported crash and recovery
> sequence.** A command that was not acknowledged leaves each logical page it touched either entirely old or entirely
> new, and nothing else on the device changes.

"Acknowledged" means a SUCCESS completion left the controller (the completion-queue handshake). "Supported crash"
is defined in §6.

## 2. Software-managed recovery, not physical PLP

The delivered design is **software-managed journal recovery with no stored energy**:

* A write is acknowledged only after its data **and** the metadata needed to find it are on NAND (each page carries
  {LPN, 48-bit SEQ, CRC-32} in its ECC-protected spare area; a TRIM's journal page is programmed first).
* Therefore **no energy is needed at power loss for correctness.** When the supply collapses, the NAND operation
  in flight may tear; the torn page fails ECC or CRC and is ignored by the roll-forward.
* **No hardware power-loss protection is claimed.** The RTL parameter `PLP_PRESENT` is 0; with it the controller
  ignores PLP qualification, never acknowledges early on PLP grounds, and degrades the PLP_FLUSH policy to STOP.
  A capacitor model exists only as research (docs/07, `reports/plp/PLP_MODEL.md`), with a qualification checklist
  that must be completed on real hardware before `PLP_PRESENT = 1` is allowed.

## 3. System view

```
 host ──SQ──► admission ──► tag tracker ◄── PHASE_EV (firmware) ──┐
             (controller)   (per-tag persistence phase)             │
                                 │ ack gate                          │
 host ◄──CQ── completion slot ◄──┘◄────────── CPL_REQ (firmware)     │
                                                                     │
 pwr_fail_ni ─► sync+filter ─► FSM ─► admission, NAND permissions, WP#, sweep, sub-reset
 cap_ok_i  ───► sync ─────────┘                                      │
                                                                     │
 ControlCore firmware:  sfps (PowerSafe layer) ── events ──► FlashMap FTL ── HAL ──► NAND controller ──► NAND
                         ▲  boot / recovery / PF handling                          ▲ nand_prog_ok / read_ok
                         └───────────── registers (4 KiB page) ────────────────────┘ nand_start / busy
```

| Component | File(s) | Role |
|---|---|---|
| Recovery controller (RTL) | `rtl/silicaflux_storage_recovery.sv` (+ `sfpr_tag_tracker.sv`, `sfpr_crash_inj.sv`, generated `sfpr_regs_pkg.sv`) | FSM, admission control, outstanding-operation tracking, acknowledgement gate, power-fault in-flight policy, NAND gating and WP#, reset sequencing, retention, telemetry, crash injection |
| PowerSafe firmware layer | `firmware/powersafe/` (`sfps.c`) | command execution with phase reporting, completion through the gate, FTL event forwarding, power-fault handler, recovery manager, degradation reporting |
| FTL (P56 + P58 integration) | `firmware/silicaflux_ftl/` | durable writes, checkpoints, journal, roll-forward; P58: events, dual checkpoint, journal mirror, write verify, diagnostics, refused-operation semantics |
| Crash-injection framework | `firmware/crashinj/sfci.c`, `cosim/` | Verilator co-simulation of RTL + firmware + persistent NAND; abandonment at any instruction |
| Recovery reference model | `firmware/tests/rrm.c` | independent host-side model of what each LBA may contain |
| Campaigns / power-fault tests | `firmware/tests/test_recovery.c`, `hc.c` | crash points, op sweeps, repeated recovery, random, power-fault policies, metadata corruption, full device, GC/WL, defence in depth, telemetry |
| RTL unit testbench | `tb/tb_storage_recovery.sv` | 17 self-checking tests, Verilator + Icarus |
| PLP research model | `plp_model/` | hold-up energy sizing, estimates only |

## 4. Write persistence model (summary; full definitions in docs/02)

| Phase | Meaning | Who reports it |
|---|---|---|
| ACCEPTED | admitted, tag allocated, command validated | controller (admission) |
| BUFFERED | host data in controller buffer SRAM (volatile) | firmware after the host→buffer DMA |
| PROGRAMMED | every NAND program of the command issued and returned | firmware (FTL event POST_PROGRAM of the last page) |
| VERIFIED | every program status PASS (+ read-back compare when `SFFTL_F_VERIFY_WRITE`) | firmware (PRE_MAP of the last page) |
| MAPPED | L2P committed in RAM; its persistent evidence (spare record / journal page) is on the medium | firmware (POST_MAP of the last page) |
| DURABLE | the above for every page; survives any supported crash | firmware, when the FTL call returned OK |
| ACKNOWLEDGED | SUCCESS completion released to the host | controller gate, only at DURABLE |

No early acknowledgement exists in the delivered configuration (no WCE from the host, no PLP).

## 5. Power-fault behaviour (summary; docs/06)

1. **Stop unsafe new work**: admission closes in the cycle the filtered fault is registered (new commands complete
   ABORT_PWR_LOSS / QUIESCED).
2. **In-flight policy STOP (default)**: the NAND operation already running finishes on its own (it cannot be stopped
   safely); **no new program or erase may start** — the controller refuses it, the FTL treats the refusal as "nothing
   happened" and aborts its call. WP# is asserted as soon as the NAND is idle. DIAG policy (optional): after the
   firmware's `PF_ACK`, at most `PF_BUDGET` (default 2) operations for one diagnostics journal page; a tear is harmless.
3. **Preserve diagnostics**: retained snapshot `RET_PF_SNAP`, counters and cause in the controller's retention domain;
   DIAG writes the snapshot to NAND; every unclean recovery writes a durable recovery record; both are carried in every
   checkpoint (`sfftl_diag`).
4. **Protect metadata**: checkpoints stop at the next page boundary; the previous checkpoint stays valid; the metadata
   ring never erases the live region; torn metadata pages fail CRC.
5. **Outstanding tags**: swept once — DURABLE ones complete SUCCESS (`ACK_DURABLE_ON_PF`), everything else
   ABORT_PWR_LOSS (not acknowledged: old or new contents per page).
6. Supply back (debounced): reset + recovery (default) or resume in place (`CTRL.RESUME`) — both verified.

## 6. Supported faults

| Fault | Supported | Evidence |
|---|---|---|
| Power cut at any instruction of the firmware / any NAND operation (torn program, torn erase) | yes | crash-point sweep, NAND-op sweep, random |
| Power cut during recovery, repeatedly (nested up to 3 deep) | yes | `repeated_recovery` |
| CPU-only reset (watchdog-like) with NAND op in flight | yes | `cpu_reset`, CPU_RESET action in every sweep |
| Power-fault warning followed by loss (fast / slow) or brown-out (remount / resume), firmware learning late | yes | `power_fault` |
| One unreadable metadata page in the live set (newest commit / body / journal / any live page) | yes (P58 config) | `metadata_corruption` |
| Damaged newest commit **and** power lost while the ring recycles the previous checkpoint | yes (DUAL_CKPT) | `metadata_corruption`, `ring_invariants` |
| Random NAND program / erase failures and read flips during the above | yes (data); a worn-out device turns read-only | `random` |
| Whole metadata zone destroyed | **fail-safe only**: mount refuses (ENOFS, controller FAILED), no guessed map | `metadata_corruption` |
| Two copies of a journal page lost, both checkpoints damaged, silent data corruption of data pages that passes CRC-32, firmware that lies about phases | **not supported** | docs/10 |

## 7. Atomicity and ordering contract

* Each **logical page** (one L2P entry) is atomic: after a crash a page holds either the complete old or the complete
  new contents of a non-acknowledged command.
* A multi-page command is **not** atomic as a whole; pages may mix old and new after a crash if it was not acknowledged.
* A whole-page TRIM range covered by one journal record is all-or-nothing; partial-page heads and tails are
  read-modify-write writes.
* Commands are executed one at a time by the firmware; there is no ordering promise between commands that are both
  outstanding and unacknowledged.
* Once a recovery completed and a read returned a value, that value is stable across further crashes (the reference
  model checks it).

## 8. Interfaces

* Register page (4 KiB, P51 `rb_*` bus): `docs/REGISTERS.md`, generated from `config/sfpr_regmap.py`.
* Hardware ports: admission (`cmd_valid_i`…), datapath phase events (`ev_*`), completion slot (`cq_*`), NAND handshake
  (`nand_busy_i`, `nand_start_i`, `nand_kind_i`, `nand_prog_ok_o`, `nand_read_ok_o`, `wp_no`), supervisor
  (`pwr_fail_ni`, `cap_ok_i`), resets (`por_ni`, `rst_ni`, `host_rst_req_i`, `wdt_rst_req_i`, `sub_rst_no`),
  `host_status_o`, `irq_o`, `crash_req_o`.
* Firmware API: `firmware/powersafe/include/sfps.h`; FTL API additions in `sfftl.h` / `sfftl_powersafe.h`.

## 9. Verification and results

See docs/08 and `reports/TESTS.md`. Definition of done — across reproducible injected crashes the controller
reconstructs a consistent mapping and preserves every acknowledged durable write — is met in simulation (RTL
unit testbench on two simulators; RTL + firmware co-simulation campaigns; sanitizers; mutation check).
