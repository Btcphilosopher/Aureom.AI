# 06 — Power-fault behaviour and in-flight policy

No hold-up energy is assumed. The supply supervisor's warning (`pwr_fail_ni`) may be followed by total loss at any
moment — immediately or much later — or by the supply coming back (brown-out).

## 1. Sequence

| t | Controller | Firmware (sfps) | FTL |
|---|---|---|---|
| 0 | `pwr_fail_ni` low | — | operation in progress |
| +2+2 clk | synchronised + filtered → **PF_DRAIN**: admission closed (ABORT_PWR_LOSS / QUIESCED), new NAND program / erase refused (STOP), `RET_PF_SNAP` taken, IRQ PF | interrupt (latency: next steps) | the NAND op already started finishes |
| … | NAND idle → WP# asserted → **PF_SAFE**: sweep completes every tag once | ISR: if the controller is in a PF state → `sfftl_ps_warn` | next page boundary: returns EPOWER (not acknowledged); a refused op = nothing happened |
| … | — | main loop: STOP → `sfftl_ps_power_fail(0)`; DIAG → `CTRL.PF_ACK`, snapshot into one journal page; `CTRL.FW_SAFE` | refuses every change; reads still served |
| loss | everything volatile gone | gone | gone; NAND keeps all programmed pages, the op in flight may be torn |
| or supply good for `RESTORE_DEB` | **PF_RESTORE** → remount (default: reset + RECOVERY) or wait for `CTRL.RESUME` | resume: `sfftl_ps_power_restored`, `CTRL.RESUME` | continues |

## 2. Policies (`CFG.PF_MODE`)

| Policy | Program / erase after the fault | Energy needed for correctness | Use |
|---|---|---|---|
| **STOP** (default) | none may start | **zero** | the delivered design |
| **DIAG** | after `CTRL.PF_ACK`, at most `PF_BUDGET` (default 2: one ring erase + one journal page) | zero (diagnostics are best effort; a tear is harmless) | post-mortem information |
| **PLP_FLUSH** | unrestricted until `FW_SAFE` | the drain of every volatile-acknowledged write — only meaningful with qualified PLP; without `PLP_PRESENT` it degrades to STOP | research path (docs/07) |

`PF_ACK` matters: firmware work started before the firmware knew of the fault (interrupt latency) must not spend the
budget — without the handshake the diagnostics page was lost in 1 brown-out out of 6.

## 3. In-flight commands

| At the fault | Outcome |
|---|---|
| DURABLE, completion not yet posted | sweep completes it **SUCCESS** (`ACK_DURABLE_ON_PF`) — or the host never sees it if the supply dies first; both are correct |
| not DURABLE | sweep completes it **ABORT_PWR_LOSS**: not acknowledged; each logical page old or new, then stable |
| new command | rejected ABORT_PWR_LOSS at admission |
| firmware completing a tag the sweep already retired (it learnt late) | ignored, counted `T_LATE_FW` |

## 4. Measured (campaign `power_fault`, 4 seeds × 8 cells × 24 runs)

| Policy / outcome | Runs | Passed | Program/erase started while the controller was in a PF state | Device programs after the warning |
|---|---|---|---|---|
| STOP, loss after 1-60 clk / 3-6 k clk, brown-out remount / resume | 384 | 384 | **0** | ≤ 1 (the operation already starting when the warning arrived) |
| DIAG, same four outcomes | 384 | 384 | ≤ 2 (= budget) | ≤ 3 (in-flight op + budget) |
| DIAG brown-out: diagnostic record recovered | 96 | 96 | | |

Every run ends with an unclean power cut after more work and a full verification, and checks that no healthy block
was retired.

## 5. Issues found and fixed while building this

* **Stale interrupt after a reset**: a PF event the previous firmware never serviced (it was reset first) put the new
  firmware's FTL into power-fail mode; writes then aborted forever. Fix: the firmware clears `IRQ_STATUS` at boot
  (history is in `RET_*`) and the ISR acts on PF only while the controller is in a PF state.
* **DIAG budget taken by unaware work** → `PF_ACK` (§2).
* **Checkpoint continuing after the warning** → stops at the next page (docs/04 §5).
* **Late completion flagged as an error** → `T_LATE_FW` (docs/03 §3).

## 6. Hold-up budget in operations (for a future PLP design)

From the warning: detection ≈ 4 controller clocks + supervisor delay; the operation in flight (≤ one program or
erase); then STOP: nothing; DIAG: ≤ 1 erase + 1 program. Converting this into capacitance needs measured board power —
see docs/07; no capacitance figure is claimed.
