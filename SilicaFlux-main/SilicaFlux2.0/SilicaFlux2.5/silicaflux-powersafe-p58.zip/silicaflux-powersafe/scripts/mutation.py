#!/usr/bin/env python3
# =============================================================================
# SilicaFlux PowerSafe (Project 58) -- mutation check
#
#   python3 scripts/mutation.py [id ...]     -> reports/mutation.md
#
# Each mutant plants ONE deliberate defect in a copy of the tree (RTL, firmware
# layer or FTL), rebuilds, and runs the test that should notice.  "Caught" means
# the test FAILED on the mutant (it builds; the test exits non-zero).  A mutant
# that survives is a hole in the verification -- reported, not hidden.
# =============================================================================
import os
import shutil
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.path.join(ROOT, "build", "mut")
COPY = ["rtl", "tb", "third_party", "config", "scripts", "firmware", "cosim", "Makefile"]

TB = ("tb", None)


def cosim(*tests):
    return ("cosim", list(tests))


MUTANTS = [
    # ---------------------------------------------------------------- RTL
    ("R1", "RTL", "ack gate releases SUCCESS below DURABLE", "rtl/sfpr_tag_tracker.sv",
     "        end else gate_ok = 1'b0;", "        end else gate_ok = 1'b1;", TB),
    ("R2", "RTL", "STOP policy lets programs start after the fault", "rtl/silicaflux_storage_recovery.sv",
     "((pf_mode_q == SFPR_PF_MODE_DIAG && pf_ack_q && budget_used_q < pf_budget_q) ||", "(1'b1 ||", TB),
    ("R3", "RTL", "admission open during a power fault", "rtl/silicaflux_storage_recovery.sv",
     "SFPR_STATE_PF_DRAIN, SFPR_STATE_PF_SAFE, SFPR_STATE_PF_RESTORE:\n                         admit = {1'b0,",
     "SFPR_STATE_PF_DRAIN, SFPR_STATE_PF_SAFE, SFPR_STATE_PF_RESTORE:\n                         admit = {1'b1,", TB),
    ("R4", "RTL", "power-fault sweep acknowledges every tag with SUCCESS", "rtl/sfpr_tag_tracker.sv",
     "if (ack_durable_on_pf && durable_kind(kind_d[st]) && phase_d[st] == SFPR_PHASE_DURABLE) begin",
     "if (1'b1) begin", cosim("power_fault")),
    ("R5", "RTL", "WP# not asserted in PF_SAFE", "rtl/silicaflux_storage_recovery.sv",
     "(st_q == SFPR_STATE_RESET_HOLD) || (st_q == SFPR_STATE_PF_SAFE) ||", "(st_q == SFPR_STATE_RESET_HOLD) ||", TB),
    ("R6", "RTL", "retention registers cleared by the external reset", "rtl/silicaflux_storage_recovery.sv",
     "  always_ff @(posedge clk or negedge prst_n) begin\n    if (!prst_n) begin",
     "  always_ff @(posedge clk or negedge frst_n) begin\n    if (!frst_n) begin", TB),
    ("R7", "RTL", "phase chain not enforced (skips allowed)", "rtl/sfpr_tag_tracker.sv",
     "SFPR_KIND_WRITE: ok = (p == cur + 3'd1);", "SFPR_KIND_WRITE: ok = (p > cur);", TB),
    ("R8", "RTL", "crash unit fires one occurrence early", "rtl/sfpr_crash_inj.sv",
     "wire hit      = occ && (seen_q + 32'd1 >= cnt_q);", "wire hit      = occ && (seen_q + 32'd2 >= cnt_q);", TB),
    # ---------------------------------------------------------------- firmware layer
    ("F1", "firmware", "firmware reports DURABLE at BUFFERED and completes early (gate cannot know)",
     "firmware/powersafe/src/sfps.c",
     "  phase_to(p, SFPR_PHASE_BUFFERED);             /* host data is in controller memory */",
     "  phase_to(p, SFPR_PHASE_DURABLE); (void)complete(p, tag, SFPS_ST_SUCCESS);", cosim("crash_points")),
    ("F2", "firmware", "EQUIVALENT: firmware keeps completing tags the power-fault sweep owns", "firmware/powersafe/src/sfps.c",
     "  if (pf_owned(p)) return SFPS_ST_ABORT_PWR_LOSS;      /* the controller's sweep completes it */", "",
     cosim("power_fault")),
    ("F3", "firmware", "power-fault interrupt never flagged: the firmware's power-fault service never runs",
     "firmware/powersafe/src/sfps.c", "      p->pf_pending = 1;", "", cosim("full:power_fault")),
    # ---------------------------------------------------------------- FTL (P56 + P58 changes)
    ("L1", "FTL", "TRIM acknowledged without its journal page", "firmware/silicaflux_ftl/src/ftl_io.c",
     "      rc = journal_flush(f);\n      if (rc < 0) {\n        /* P58: an aborted TRIM",
     "      rc = SFFTL_OK;\n      if (rc < 0) {\n        /* P58: an aborted TRIM", cosim("crash_points")),
    ("L2", "FTL", "dual checkpoint: previous checkpoint not kept live", "firmware/silicaflux_ftl/src/ftl_meta.c",
     "    if ((f->cfg.flags & SFFTL_F_DUAL_CKPT) && f->ckpt_first_ppn != SFFTL_NONE)", "    if (0)",
     cosim("ring_invariants", "metadata_corruption")),
    ("L3", "FTL", "journal mirror not written", "firmware/silicaflux_ftl/src/ftl_meta.c",
     "    if ((f->cfg.flags & SFFTL_F_JOURNAL_MIRROR) && !f->ps_warned) {", "    if (0) {", cosim("metadata_corruption")),
    ("L4", "FTL", "refused program consumes its page (gap in an open block)", "firmware/silicaflux_ftl/src/ftl_alloc.c",
     "      f->blk[b].wp--;\n      return SFFTL_EPOWER;", "      return SFFTL_EPOWER;", cosim("full:power_fault")),
    ("L5", "FTL", "aborted TRIM record left queued", "firmware/silicaflux_ftl/src/ftl_io.c",
     "if (r[0] == SFFTL_J_TRIM && r[1] == (uint32_t)first && r[2] == (uint32_t)(last - first)) {",
     "if (0 && r[0] == SFFTL_J_TRIM && r[1] == (uint32_t)first && r[2] == (uint32_t)(last - first)) {",
     cosim("aborted_trim")),
    ("L6", "FTL", "verify read refused: mapping not committed (RAM / medium disagree)",
     "firmware/silicaflux_ftl/src/ftl_io.c",
     "      map_commit(f, lpn, ppn);\n      streams_settle(f);\n      return v;", "      return v;", cosim("full:power_fault")),
    ("L7", "FTL", "EQUIVALENT: checkpoint keeps writing after the power-fail warning", "firmware/silicaflux_ftl/src/ftl_meta.c",
     "    if (ps_blocked(f)) { rc = SFFTL_EPOWER; break; }", "", cosim("full:power_fault")),
    ("L8", "FTL", "roll-forward ignores sequence order", "firmware/silicaflux_ftl/src/ftl_mount.c",
     "    if (cur >= seq) return SFFTL_OK;", "    if (cur > seq + 0xFFFFFFFFFFFFull) return SFFTL_OK;", cosim("crash_points", "nand_op_sweep")),
    ("L9", "FTL", "controller refusal treated like a media error", "firmware/silicaflux_ftl/src/sfftl_internal.h",
     "static inline int hal_dead(int st) { return st == SFFTL_HAL_POWER_LOSS || st == SFFTL_HAL_WRITE_PROTECT; }",
     "static inline int hal_dead(int st) { return st == SFFTL_HAL_POWER_LOSS; }", cosim("full:power_fault")),
    ("L10", "FTL", "REDUNDANT: metadata ring may erase the live region", "firmware/silicaflux_ftl/src/ftl_meta.c",
     "      if (c == f->mz_live_start) break;                         /* never into the live region */", "",
     cosim("ring_invariants", "metadata_corruption")),
    ("L11", "FTL", "roll-forward does not check the page CRC (torn pages replayed)", "firmware/silicaflux_ftl/src/ftl_mount.c",
     "        r = oob_parse(f, spare, f->buf_host, &o);\n        if (r >= 0) break;",
     "        r = oob_parse(f, spare, NULL, &o);\n        if (r >= 0) break;", cosim("full:nand_op_sweep")),
    ("L12", "FTL", "sequence numbers not resumed above the medium after a crash", "firmware/silicaflux_ftl/src/ftl_mount.c",
     "  if (dmax + 1u > ns) ns = dmax + 1u;", "", cosim("crash_points")),
]


def sh(cmd, cwd, timeout=1800):
    r = subprocess.run(cmd, cwd=cwd, shell=True, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr


def prepare(mid):
    d = os.path.join(WORK, mid)
    if os.path.isdir(d):
        shutil.rmtree(d)
    os.makedirs(d)
    for c in COPY:
        s = os.path.join(ROOT, c)
        if os.path.isdir(s):
            shutil.copytree(s, os.path.join(d, c), ignore=shutil.ignore_patterns("build", "*.o"))
        else:
            shutil.copy(s, d)
    return d


def main():
    sel = set(sys.argv[1:])
    rows, caught_n, total = [], 0, 0
    for mid, layer, desc, f, old, new, (kind, tests) in MUTANTS:
        if sel and mid not in sel:
            continue
        total += 1
        t0 = time.time()
        d = prepare(mid)
        p = os.path.join(d, f)
        s = open(p).read()
        if s.count(old) != 1:
            rows.append((mid, layer, desc, "-", "NOT APPLIED (pattern not found once)", ""))
            print(mid, "pattern not found")
            continue
        open(p, "w").write(s.replace(old, new))
        if kind == "tb":
            rc, out = sh("make -s build/vtb0/vtb && ./build/vtb0/vtb +SEED=1", d)
            ok_build = os.path.exists(os.path.join(d, "build", "vtb0", "vtb"))
            fail = "TB RESULT PASS" not in out
            ev = next((l.strip() for l in out.splitlines() if l.startswith("ERROR")), "")
            test = "RTL unit testbench (Verilator)"
        else:
            if layer != "RTL":       # reuse the verilated library of the clean tree
                src = os.path.join(ROOT, "build", "vcosim")
                if os.path.isdir(src):
                    shutil.copytree(src, os.path.join(d, "build", "vcosim"))
            rc, out = sh("make -s build/test_recovery", d)
            ok_build = rc == 0
            out2 = ""
            fail = False
            if ok_build:
                quick = "" if any(t.startswith("full:") for t in tests) else "--quick "
                names = " ".join(t.replace("full:", "") for t in tests)
                rc2, out2 = sh("./build/test_recovery " + quick + names, d)
                fail = rc2 != 0
            out = out + out2
            ev = next((l.strip() for l in out2.splitlines() if "CHECK FAILED" in l), "")
            test = "co-simulation: " + ", ".join(tests)
        if not ok_build:
            verdict = "BUILD FAILED (not counted as caught)"
        else:
            verdict = "caught" if fail else "**SURVIVED**"
            caught_n += 1 if fail else 0
        if desc.startswith("EQUIVALENT") and verdict == "**SURVIVED**":
            verdict = "equivalent (no defect left to observe)"
            total -= 1
        elif desc.startswith("REDUNDANT") and verdict == "**SURVIVED**":
            verdict = "survived: redundant guard"
        elif desc.startswith("EQUIVALENT") and verdict == "caught":
            pass
        rows.append((mid, layer, desc, test, verdict, ev[:160]))
        print(f"{mid:4} {layer:8} {verdict:10} {time.time() - t0:6.1f}s  {desc}")
        shutil.rmtree(d, ignore_errors=True)
    md = ["# Mutation check\n",
          "Each mutant plants one deliberate defect, rebuilds, and runs the test meant to notice it.\n",
          f"**{caught_n} / {total} mutants caught**, plus mutants that are equivalent by design (listed; not counted):\n",
          "* **F2** -- a firmware that keeps completing tags during a power fault is harmless because the controller "
          "ignores late events for retired tags (T_LATE_FW) and its gate still refuses premature SUCCESS.",
          "* **L7** -- an FTL checkpoint that keeps writing after the warning is stopped in hardware: in STOP nothing may "
          "start, in DIAG the budget opens only after the firmware's PF_ACK.  The FTL fix remains for PLP_FLUSH.\n",
          "A survivor marked *redundant guard* is a defensive check that the tested design cannot reach (L10: the "
          "metadata ring never needs to erase into the live region because a checkpoint is forced while enough ring "
          "blocks are free); it is reported, counted as not caught, and kept as defence in depth.\n",
          "| Id | Layer | Planted defect | Test | Verdict | First failure reported |", "|---|---|---|---|---|---|"]
    for r in rows:
        md.append("| %s | %s | %s | %s | %s | %s |" % (r[0], r[1], r[2], r[3], r[4], r[5].replace("|", "/")))
    md.append("")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    if not sel:
        open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(md))
    print(f"{caught_n}/{total} caught")
    sys.exit(0 if caught_n == total else 1)


if __name__ == "__main__":
    main()
