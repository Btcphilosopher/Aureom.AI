#!/usr/bin/env python3
# =============================================================================
# SilicaFlux PowerSafe (Project 58) -- Yosys generic synthesis estimate
#
#   python3 scripts/synth.py           -> reports/synth.md, build/synth/*.log
#
# Yosys 0.33 (Ubuntu 24.04) has no wildcard package import, so the flow reads a
# copy of the RTL in which `import sfpr_regs_pkg::*;` is replaced by an include
# of the same generated definitions (rtl/generated/sfpr_regs_defs.svh).  Generic
# cells only: no liberty, no timing, no area in um^2 -- an implementation-size
# estimate, not a physical result.
# =============================================================================
import os
import re
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
B = os.path.join(ROOT, "build", "synth")
SRC = os.path.join(B, "src")
FILES = ["third_party/silicaflux-v/rtl/common/sfv_common.sv", "rtl/sfpr_crash_inj.sv", "rtl/sfpr_tag_tracker.sv",
         "rtl/silicaflux_storage_recovery.sv"]
CONFIGS = [("NTAGS=8, PLP_PRESENT=0 (delivered)", {"NTAGS": 8, "PLP_PRESENT": 0}),
           ("NTAGS=8, PLP_PRESENT=1 (research)", {"NTAGS": 8, "PLP_PRESENT": 1}),
           ("NTAGS=16, PLP_PRESENT=0", {"NTAGS": 16, "PLP_PRESENT": 0})]


def prepare():
    os.makedirs(SRC, exist_ok=True)
    for f in FILES:
        s = open(os.path.join(ROOT, f)).read()
        s = s.replace("  import sfpr_regs_pkg::*;", '  `include "sfpr_regs_defs.svh"')
        open(os.path.join(SRC, os.path.basename(f)), "w").write(s)
    shutil.copy(os.path.join(ROOT, "rtl", "generated", "sfpr_regs_defs.svh"), SRC)


def run(name, params, idx):
    log = os.path.join(B, f"synth_{idx}.log")
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    script = ("read_verilog -sv -DSYNTHESIS " + " ".join(os.path.basename(f) for f in FILES) + "; "
              f"chparam {chp} silicaflux_storage_recovery; "
              "synth -top silicaflux_storage_recovery -flatten; check -assert; stat")
    r = subprocess.run(["yosys", "-q", "-l", log, "-p", script], cwd=SRC, capture_output=True, text=True)
    txt = open(log).read() if os.path.exists(log) else ""
    cells = re.findall(r"Number of cells:\s+(\d+)", txt)
    ff = sum(int(n) for k, n in re.findall(r"\$_(S?DFF\w*|DFFE\w*|ALDFF\w*)_\s+(\d+)", txt))
    latches = sum(int(n) for k, n in re.findall(r"\$_(DLATCH\w*)_\s+(\d+)", txt))
    return {"name": name, "ok": r.returncode == 0, "cells": int(cells[-1]) if cells else 0, "ff": ff,
            "latches": latches, "log": os.path.relpath(log, ROOT)}


def main():
    prepare()
    res = [run(n, p, i) for i, (n, p) in enumerate(CONFIGS)]
    ver = subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.strip()
    md = ["# Synthesis estimate (Yosys generic cells)\n",
          f"_{ver}; `synth -flatten` + `check -assert`; generic gates, no technology library, no timing.  An "
          "implementation-size estimate only._\n",
          "| Configuration | result | generic cells | flip-flops | latches | log |", "|---|---|---|---|---|---|"]
    for r in res:
        md.append(f"| {r['name']} | {'PASS' if r['ok'] else 'FAIL'} | {r['cells']} | {r['ff']} | {r['latches']} | "
                  f"`{r['log']}` |")
    md.append("\nThe controller is small next to the storage datapath it supervises: most flip-flops are the "
              "32-bit telemetry counters, the retention registers and the per-tag accept timestamps; they can be "
              "trimmed for a production build.  `check -assert` passing means no combinational loops, no multiple "
              "drivers and no undriven wires after synthesis.\n")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "synth.md"), "w").write("\n".join(md))
    for r in res:
        print(f"  {r['name']:<40} {'PASS' if r['ok'] else 'FAIL'}  cells {r['cells']:6}  ff {r['ff']:5}  latches {r['latches']}")
    sys.exit(0 if all(r["ok"] for r in res) else 1)


if __name__ == "__main__":
    main()
