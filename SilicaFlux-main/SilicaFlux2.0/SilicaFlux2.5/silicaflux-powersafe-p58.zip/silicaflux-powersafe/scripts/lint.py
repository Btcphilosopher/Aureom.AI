#!/usr/bin/env python3
# =============================================================================
# SilicaFlux PowerSafe (Project 58) -- lint: Verilator -Wall (simulation and
# synthesis views, several parameter sets) + Icarus elaboration + generated-file
# freshness.  Writes reports/lint.md; exit 1 on any warning or error.
# =============================================================================
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = [l.strip() for l in open(os.path.join(ROOT, "rtl", "files.f")) if l.strip() and not l.startswith("//")]
CONFIGS = [("NTAGS=8 PLP=0", []), ("NTAGS=8 PLP=1", ["-GPLP_PRESENT=1"]), ("NTAGS=16 PLP=0", ["-GNTAGS=16"]),
           ("NTAGS=2 PLP=1", ["-GNTAGS=2", "-GPLP_PRESENT=1"])]


def run(cmd):
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr)


def main():
    rows, bad = [], 0
    for view, extra in (("simulation", []), ("synthesis", ["+define+SYNTHESIS"])):
        for name, g in CONFIGS:
            rc, out = run(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME"] + extra + g + FILES +
                          ["--top-module", "silicaflux_storage_recovery"])
            w = [l for l in out.splitlines() if l.startswith("%")]
            ok = rc == 0 and not w
            bad += 0 if ok else 1
            rows.append(f"| Verilator 5.020 -Wall | {view} | {name} | {'clean' if ok else 'FAIL'} | {len(w)} |")
    for name, p in (("PLP=0", "0"), ("PLP=1", "1")):
        rc, out = run(["iverilog", "-g2012", "-o", "/dev/null", "-P", f"silicaflux_storage_recovery.PLP_PRESENT={p}",
                       "-s", "silicaflux_storage_recovery"] + FILES)
        errs = [l for l in out.splitlines() if ": error:" in l or "error(s)" in l]
        notes = [l for l in out.splitlines() if "sorry" in l or "warning" in l]
        ok = rc == 0 and not errs
        bad += 0 if ok else 1
        rows.append(f"| Icarus Verilog 12 -g2012 | elaboration | {name} | {'clean' if ok else 'FAIL'} | {len(notes)} notes |")
    rc, out = run([sys.executable, "-B", "scripts/gen_regs.py", "--check"])
    bad += 0 if rc == 0 else 1
    rows.append(f"| gen_regs.py --check | generated files | - | {'up to date' if rc == 0 else 'STALE'} | - |")
    md = ["# Lint\n", "| Tool | View | Parameters | Result | Messages |", "|---|---|---|---|---|"] + rows
    md.append("\nIcarus notes are its standard `sorry: constant selects in always_* processes` (the whole vector is "
              "put in the sensitivity list; behaviour is unchanged) and `$error` in the simulation-only assertion blocks.\n")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "lint.md"), "w").write("\n".join(md))
    print("\n".join(rows))
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
