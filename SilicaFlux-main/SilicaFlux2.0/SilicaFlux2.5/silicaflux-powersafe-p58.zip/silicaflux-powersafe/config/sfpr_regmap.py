# =============================================================================
# SilicaFlux PowerSafe (Project 58) -- register map and encodings, single source
#
# scripts/gen_regs.py turns this file into
#   rtl/generated/sfpr_regs_pkg.sv                      (SystemVerilog package)
#   firmware/powersafe/include/generated/sfpr_regs.h    (C header)
#   docs/REGISTERS.md                                   (reference)
# so the RTL, the firmware and the documentation cannot disagree.
#
# Data only.  Offsets are byte offsets inside the 4 KiB register page.
# Access: RO read-only, RW read/write, WO write-only (reads 0), W1C write 1 to
# clear, RC read-only counter.  "dom" = reset domain:
#   F  functional  -- cleared by por_ni and by rst_ni
#   R  retention   -- cleared by por_ni only (survives rst_ni and every internal
#                     reset the controller sequences; lost on real power loss)
# =============================================================================

PAGE_ID = 0x52504653          # "SFPR"
VERSION = 0x00580100          # Project 58, RTL 1.0

# ---------------------------------------------------------------- enumerations
ENUMS = {
    # FSM state (STATE.FSM)
    "state": [
        ("POR_INIT",    0, "power-on / external reset: sub-reset held, WP# asserted, waiting for stable power"),
        ("RECOVERY",    1, "firmware mounting: admission closed (NOT_READY), NAND writable, recovery timer running"),
        ("RUN",         2, "normal operation"),
        ("RUN_RO",      3, "degraded: reads admitted, WRITE / TRIM rejected WRITE_PROTECTED, program/erase blocked"),
        ("PF_DRAIN",    4, "power fault: admission closed (ABORT_PWR_LOSS); in-flight NAND op finishes; policy budget"),
        ("PF_SAFE",     5, "power fault safe: WP# asserted, no NAND op, outstanding tags swept"),
        ("PF_RESTORE",  6, "supply back and debounced: resume (CTRL.RESUME) or remount (reset sequence)"),
        ("RESET_DRAIN", 7, "reset requested: admission closed, no new NAND op, wait for the op in flight"),
        ("RESET_HOLD",  8, "sub-reset asserted, tags cleared"),
        ("SHUTDOWN",    9, "clean shutdown complete: nothing may touch the medium until reset"),
        ("FAILED",     10, "recovery failed or timed out: every command rejected, WP# asserted"),
    ],
    # command kind (CMD_SUBMIT.KIND, hardware cmd_kind_i)
    "kind": [
        ("READ",  0, "no durability semantics"),
        ("WRITE", 1, "durable kind: success completion only at DURABLE (or a permitted early ack)"),
        ("TRIM",  2, "durable kind (deallocate): success completion only at DURABLE"),
        ("FLUSH", 3, "durable kind: success only at DURABLE and with no volatile-acknowledged write outstanding"),
        ("ADMIN", 4, "identify / log / vendor: no durability semantics"),
    ],
    # write persistence phase (PHASE_EV.PHASE, ev_phase_i, TAG_INFO.PHASE)
    "phase": [
        ("FREE",       0, "tag not in use"),
        ("ACCEPTED",   1, "admitted, tag allocated, command validated"),
        ("BUFFERED",   2, "host data in the controller buffer (volatile SRAM)"),
        ("PROGRAMMED", 3, "every NAND program of the command issued and returned"),
        ("VERIFIED",   4, "every program status PASS (and read-back verified when enabled)"),
        ("MAPPED",     5, "L2P committed in RAM; its persistent evidence (spare record / journal page) is on the medium"),
        ("DURABLE",    6, "all of the above for every page of the command: survives any supported crash"),
    ],
    # completion status (P51 sfs_status_e values, plus WRITE_PROTECTED)
    "status": [
        ("SUCCESS",         0x00, "completed successfully"),
        ("INTERNAL_ERR",    0x06, "controller failed (FAILED state)"),
        ("ABORT_PWR_LOSS",  0x05, "aborted by power-loss quiescence (not acknowledged: old or new data)"),
        ("ABORT_RESET",     0x07, "aborted / refused: controller reset or recovery in progress"),
        ("WRITE_PROTECTED", 0x14, "write refused: controller is read-only (P58 addition)"),
    ],
    # error detail (P51 sfs_err_e values)
    "err": [
        ("NONE",      0x00, ""),
        ("FW",        0x0D, "firmware-detected condition"),
        ("QUIESCED",  0x0E, "controller quiescing (power loss)"),
        ("NOT_READY", 0x0F, "controller not ready (reset / recovery)"),
        ("NAND_WP",   0x10, "NAND write-protected"),
    ],
    # power-fault in-flight policy (CFG.PF_MODE)
    "pf_mode": [
        ("STOP",      0, "default, no hold-up energy assumed: no NAND program/erase may START after the fault"),
        ("DIAG",      1, "best effort: after CTRL.PF_ACK, at most CFG.PF_BUDGET program/erase ops (diagnostics page); may tear harmlessly"),
        ("PLP_FLUSH", 2, "only with qualified PLP: firmware drains buffered data before FW_SAFE; otherwise treated as STOP"),
    ],
    # crash-injection action (CI_CTRL.ACTION)
    "ci_action": [
        ("CUT_NOW",       0, "power cut at the triggering event (between operations)"),
        ("CUT_NEXT_PROG", 1, "power cut during the next program/erase op after the event (torn op)"),
        ("CPU_RESET",     2, "firmware CPU lost at the event; controller drains NAND and resets"),
        ("CUT_NEXT_OP",   3, "power cut during the next NAND op of any kind after the event"),
    ],
    # reset cause (RET_CAUSE bit positions)
    "cause": [
        ("POR",        0, "power-on reset"),
        ("EXT",        1, "external hard reset (rst_ni)"),
        ("HOST",       2, "host controller reset request"),
        ("WDT",        3, "watchdog"),
        ("SW",         4, "firmware CTRL.SW_RESET"),
        ("CRASH",      5, "crash injection CPU_RESET"),
        ("PF_REMOUNT", 6, "brown-out restore with CFG.REMOUNT_ON_RESTORE"),
    ],
}

# crash points: (name, id, tear?, where) -- reported by firmware through CP_EVENT,
# except NAND_OP which the controller counts itself from nand_start_i.
CRASH_POINTS = [
    ("PRE_PROGRAM",      1, False, "host page assembled, before its NAND program"),
    ("IN_PROGRAM",       2, True,  "during the host page program (torn page)"),
    ("POST_PROGRAM",     3, False, "host page program returned PASS, before verify / mapping"),
    ("PRE_MAP",          4, False, "host page verified, before the L2P update"),
    ("PRE_JOURNAL",      5, False, "journal page built (TRIM / retire / erase records), before its program"),
    ("IN_JOURNAL",       6, True,  "during the journal page program (torn metadata)"),
    ("PRE_COMPLETION",   7, False, "command DURABLE, before the host completion is posted"),
    ("GC_POST_COPY",     8, False, "GC: relocated copy programmed, before its mapping update"),
    ("GC_IN_COPY",       9, True,  "GC: during the relocation program"),
    ("GC_PRE_ERASE",    10, False, "GC: victim has no valid page, before its erase"),
    ("IN_ERASE",        11, True,  "during a data-block erase (GC victim or block opening)"),
    ("CKPT_BODY",       12, False, "checkpoint: after a body page"),
    ("CKPT_PRE_COMMIT", 13, False, "checkpoint: body complete, commit page not written"),
    ("CKPT_IN_COMMIT",  14, True,  "checkpoint: during the commit page program"),
    ("CKPT_POST_COMMIT",15, False, "checkpoint: committed, before the live region moves"),
    ("MOUNT_SCAN",      16, False, "recovery: during the medium scan / roll-forward"),
    ("MOUNT_CKPT",      17, False, "recovery: before the post-recovery checkpoint"),
    ("TRIM_PRE_UNMAP",  18, False, "TRIM journal durable, before the RAM unmap"),
    ("WL_POST_COPY",    19, False, "static wear levelling: cold copy programmed, before mapping"),
    ("META_ERASE",      20, True,  "during a metadata-ring block erase"),
    ("POST_MAP",        21, False, "host page mapped, before the next page / command end"),
    ("NAND_OP",         31, True,  "N-th NAND operation of any kind (counted by the controller)"),
]

# ---------------------------------------------------------------- registers
# (name, offset, access, dom, reset, description, [fields: (name, msb, lsb, desc)])
REGS = [
    ("ID", 0x000, "RO", "F", PAGE_ID, "page identifier 'SFPR'", []),
    ("VERSION", 0x004, "RO", "F", VERSION, "Project 58, RTL 1.0", []),
    ("CONFIG", 0x008, "RO", "F", None, "elaboration parameters", [
        ("NTAGS", 7, 0, "tracked command tags"),
        ("PLP_PRESENT", 8, 8, "hold-up circuitry declared present (parameter)"),
    ]),
    ("STATE", 0x010, "RO", "F", None, "controller state", [
        ("FSM", 3, 0, "state, see enum state"),
        ("ADMIT", 4, 4, "new commands admitted"),
        ("ADMIT_WR", 5, 5, "WRITE / TRIM admitted"),
        ("WP", 6, 6, "WP# asserted to the NAND"),
        ("PROG_OK", 7, 7, "NAND program/erase may start"),
        ("PWR_FAIL", 8, 8, "power-fail input (synchronised, filtered)"),
        ("CAP_OK", 9, 9, "hold-up store healthy (synchronised)"),
        ("EARLY_ACK_OK", 10, 10, "an early (volatile) acknowledgement is currently permitted"),
        ("PLP_EFFECTIVE", 11, 11, "PLP present AND qualified AND healthy AND not revoked"),
        ("NAND_BUSY", 12, 12, "NAND array operation in progress"),
        ("SUB_RST", 13, 13, "sub-reset (firmware CPU + datapath) asserted"),
        ("CPU_HELD", 14, 14, "power fault arrived while the CPU was in reset"),
        ("SWEEP_DONE", 15, 15, "PF_SAFE tag sweep finished"),
    ]),
    ("CTRL", 0x014, "WO", "F", 0, "firmware actions (write 1)", [
        ("RECOVERY_DONE", 0, 0, "RECOVERY -> RUN / RUN_RO / FAILED according to RESULT"),
        ("RESULT", 3, 2, "with RECOVERY_DONE: 0 OK, 1 READ_ONLY, 2 FAILED"),
        ("RESUME", 4, 4, "PF_RESTORE -> RUN (resume in place)"),
        ("FW_SAFE", 5, 5, "PF_DRAIN: firmware finished its power-fault work"),
        ("SHUTDOWN_DONE", 6, 6, "clean shutdown checkpoint written -> SHUTDOWN, UNCLEAN cleared"),
        ("SW_RESET", 7, 7, "request a reset sequence (needs KEY)"),
        ("READ_ONLY", 8, 8, "RUN -> RUN_RO: the FTL degraded to read-only (worn out / metadata zone exhausted)"),
        ("PF_ACK", 9, 9, "PF_DRAIN, policy DIAG: the firmware stopped normal work; opens the PF_BUDGET for its diagnostics"),
        ("KEY", 31, 16, "0x5AFE for SW_RESET"),
    ]),
    ("CFG", 0x018, "RW", "F", 0x0000_111C, "configuration", [
        ("WCE", 0, 0, "host enabled a volatile write cache: early ack at BUFFERED permitted (not for FUA)"),
        ("PLP_QUAL", 1, 1, "firmware declares PLP qualified; ignored (reads 0) unless PLP_PRESENT"),
        ("REMOUNT_ON_RESTORE", 2, 2, "brown-out restore runs the reset + recovery sequence"),
        ("AUTO_ABORT", 3, 3, "PF_SAFE sweeps outstanding tags (abort / complete durable)"),
        ("ACK_DURABLE_ON_PF", 4, 4, "the sweep completes DURABLE tags with SUCCESS"),
        ("FORCE_PF", 5, 5, "behave as if pwr_fail_ni were low (test)"),
        ("PF_MODE", 7, 6, "power-fault policy, see enum pf_mode"),
        ("PF_BUDGET", 11, 8, "DIAG: program/erase ops allowed after the fault"),
        ("STRICT_PHASES", 12, 12, "refuse illegal phase transitions (else record and apply)"),
    ]),
    ("RECOV_TMO", 0x01C, "RW", "F", 0, "recovery timeout in cycles (0 = none)", []),
    ("DRAIN_TMO", 0x020, "RW", "F", 0x0010_0000, "NAND drain timeout in cycles (PF_DRAIN, RESET_DRAIN)", []),
    ("RESTORE_DEB", 0x024, "RW", "F", 64, "supply-good debounce in cycles", []),
    ("ERR", 0x030, "W1C", "F", 0, "sticky errors", [
        ("ACK_BEFORE_DURABLE", 0, 0, "success completion of a durable kind refused by the ack gate"),
        ("PHASE_ILLEGAL", 1, 1, "phase event out of order / skipped a required phase"),
        ("PHASE_FREE_TAG", 2, 2, "phase event for a free tag (outside power-fault / reset states)"),
        ("CPL_FREE_TAG", 3, 3, "completion request for a free tag (outside power-fault / reset states)"),
        ("RECOV_TIMEOUT", 4, 4, "recovery did not finish within RECOV_TMO"),
        ("DRAIN_TIMEOUT", 5, 5, "NAND did not become idle within DRAIN_TMO"),
        ("PF_IN_RECOVERY", 6, 6, "power fault while recovering"),
        ("PLP_POLICY", 7, 7, "PLP_QUAL / PF_MODE PLP_FLUSH requested without effective PLP"),
        ("SEQ_REGRESS", 8, 8, "COMMIT_SEQ / CKPT_GEN write lower than the current value (ignored)"),
        ("NAND_OP_BLOCKED", 9, 9, "a NAND op started although not permitted"),
        ("NO_TAG", 10, 10, "CMD_SUBMIT with no free tag"),
        ("PLP_REVOKED", 11, 11, "cap_ok fell while PLP was qualified"),
        ("VOL_LOST", 12, 12, "a volatile-acknowledged write was dropped (power fault / reset)"),
    ]),
    ("ERR_INFO", 0x034, "RO", "F", 0, "context of the last ERR event", [
        ("TAG", 7, 0, "tag"),
        ("PHASE", 11, 8, "phase (current)"),
        ("REQ", 15, 12, "requested phase / status low nibble"),
        ("STATE", 19, 16, "FSM state"),
        ("BIT", 28, 24, "ERR bit number"),
    ]),
    ("IRQ_EN", 0x038, "RW", "F", 0, "interrupt enables (bits as IRQ_STATUS)", []),
    ("IRQ_STATUS", 0x03C, "W1C", "F", 0, "interrupt sources", [
        ("PF", 0, 0, "power fault detected"),
        ("RESTORE", 1, 1, "supply restored (PF_RESTORE)"),
        ("RECOVERY", 2, 2, "RECOVERY entered: mount now"),
        ("ERR", 3, 3, "an ERR bit was set"),
        ("CRASH", 4, 4, "crash injection fired"),
        ("SAFE", 5, 5, "PF_SAFE reached"),
    ]),
    ("CMD_SUBMIT", 0x040, "WO", "F", 0, "firmware command admission (same allocator as cmd_valid_i)", [
        ("KIND", 2, 0, "enum kind"),
        ("FUA", 3, 3, "force unit access (never early-acked)"),
    ]),
    ("CMD_RESULT", 0x044, "RO", "F", 0, "result of the last CMD_SUBMIT", [
        ("ACCEPTED", 0, 0, "tag allocated"),
        ("REJECTED", 1, 1, "refused by admission control (complete with STATUS/ERRC)"),
        ("NO_TAG", 2, 2, "no free tag, retry"),
        ("TAG", 7, 4, "allocated tag"),
        ("STATUS", 15, 8, "reject status"),
        ("ERRC", 23, 16, "reject error detail"),
    ]),
    ("PHASE_EV", 0x048, "WO", "F", 0, "firmware phase event", [
        ("TAG", 7, 0, "tag"),
        ("PHASE", 11, 8, "new phase (enum phase)"),
    ]),
    ("CPL_REQ", 0x04C, "WO", "F", 0, "firmware completion request (through the ack gate)", [
        ("TAG", 7, 0, "tag"),
        ("STATUS", 15, 8, "completion status (enum status)"),
    ]),
    ("CPL_RESULT", 0x050, "RO", "F", 0, "result of the last CPL_REQ", [
        ("RELEASED", 0, 0, "completion released to the host CQ (or tag silently freed)"),
        ("REFUSED", 1, 1, "refused by the ack gate / free tag"),
        ("BUSY", 2, 2, "CQ output slot occupied: retry"),
        ("VOLATILE", 3, 3, "released as an early (volatile) acknowledgement"),
        ("STATUS", 15, 8, "status released"),
    ]),
    ("OUTSTANDING", 0x054, "RO", "F", 0, "outstanding tags", [
        ("COUNT", 7, 0, "tags in use"),
        ("MAX", 15, 8, "high-water mark"),
        ("VACKED", 23, 16, "volatile-acknowledged writes not yet durable"),
        ("NONDURABLE_WR", 31, 24, "WRITE / TRIM tags below DURABLE"),
    ]),
    ("TAG_SEL", 0x058, "RW", "F", 0, "TAG_INFO select", []),
    ("TAG_INFO", 0x05C, "RO", "F", 0, "state of tag TAG_SEL", [
        ("KIND", 2, 0, "kind"),
        ("FUA", 3, 3, "FUA"),
        ("PHASE", 6, 4, "phase"),
        ("VACKED", 7, 7, "volatile-acknowledged"),
        ("BUSY", 8, 8, "in use"),
    ]),
    ("COMMIT_SEQ_LO", 0x060, "RW", "R", 0, "persistent commit status: highest durable FTL SEQ (monotonic; write LO then HI)", []),
    ("COMMIT_SEQ_HI", 0x064, "RW", "R", 0, "bits 63:32; the 64-bit value updates when HI is written", []),
    ("CKPT_GEN", 0x068, "RW", "R", 0, "persistent commit status: newest committed checkpoint generation (monotonic)", []),
    ("ACT", 0x06C, "RW", "F", 0, "firmware background activity (telemetry)", [
        ("GC", 0, 0, "garbage collection"),
        ("CKPT", 1, 1, "checkpoint"),
        ("JOURNAL", 2, 2, "journal write"),
        ("MOUNT", 3, 3, "mount / recovery scan"),
        ("WL", 4, 4, "static wear levelling"),
    ]),
    ("CP_EVENT", 0x070, "WO", "F", 0, "crash-point event from firmware", [
        ("POINT", 4, 0, "crash point id"),
        ("TAG", 15, 8, "tag of the command, 0xFF none"),
    ]),
    ("CI_CTRL", 0x080, "RW", "F", 0, "crash injection", [
        ("ARM", 0, 0, "armed (cleared when it fires)"),
        ("FIRED", 1, 1, "fired since the last arm (RO)"),
        ("ACTION", 3, 2, "enum ci_action"),
        ("POINT", 12, 8, "crash point id"),
        ("TAG_EN", 16, 16, "only count events of TAG"),
        ("PENDING", 17, 17, "fired, waiting for the next NAND op (RO)"),
        ("TAG", 31, 24, "tag filter"),
    ]),
    ("CI_COUNT", 0x084, "RW", "F", 1, "fire at this occurrence (1 = first)", []),
    ("CI_SEEN", 0x088, "RO", "F", 0, "occurrences counted since ARM", []),
    ("CI_FIRED_AT", 0x08C, "RO", "R", 0, "cycle stamp of the last firing", []),
    ("RET_BOOTS", 0x0A0, "RO", "R", 0, "reset sequences since power-on", []),
    ("RET_CAUSE", 0x0A4, "RO", "R", 1, "cause of the last reset (one-hot, enum cause)", []),
    ("RET_FLAGS", 0x0A8, "W1C", "R", 0, "retained flags", [
        ("UNCLEAN", 0, 0, "RUN entered and no clean shutdown since (set again on every RUN entry)"),
        ("PF_SEEN", 1, 1, "a power fault occurred since power-on"),
        ("CRASH_FIRED", 2, 2, "crash injection fired since power-on"),
        ("RECOV_FAILED", 3, 3, "a recovery ended FAILED"),
    ]),
    ("RET_PF_SNAP", 0x0AC, "RO", "R", 0, "snapshot at the last power fault", [
        ("STATE", 3, 0, "FSM state when the fault arrived"),
        ("OUTSTANDING", 11, 4, "tags in use"),
        ("NONDURABLE", 19, 12, "WRITE / TRIM tags below DURABLE (will not be acknowledged)"),
        ("DURABLE_UNACKED", 27, 20, "DURABLE tags not yet completed"),
        ("NAND_BUSY", 28, 28, "a NAND op was in flight"),
        ("ACT", 31, 29, "ACT[2:0] (GC, CKPT, JOURNAL)"),
    ]),
    ("RET_PF_COUNT", 0x0B0, "RO", "R", 0, "power faults since power-on", []),
    ("RET_SCRATCH0", 0x0B4, "RW", "R", 0, "firmware scratch, retained", []),
    ("RET_SCRATCH1", 0x0B8, "RW", "R", 0, "firmware scratch, retained", []),
    ("T_CYCLES", 0x100, "RC", "F", 0, "free-running cycle counter", []),
    ("T_PF_EVENTS", 0x104, "RC", "F", 0, "power faults", []),
    ("T_RESTORES", 0x108, "RC", "F", 0, "brown-outs survived (PF_RESTORE)", []),
    ("T_RECOVERIES", 0x10C, "RC", "F", 0, "RECOVERY entries", []),
    ("T_RECOV_CYC_LAST", 0x110, "RC", "F", 0, "cycles of the last recovery (RECOVERY entry -> RECOVERY_DONE)", []),
    ("T_RECOV_CYC_MAX", 0x114, "RC", "F", 0, "longest recovery", []),
    ("T_ACKS", 0x118, "RC", "F", 0, "completions released", []),
    ("T_ACK_DURABLE", 0x11C, "RC", "F", 0, "success completions of durable kinds released at DURABLE", []),
    ("T_ACK_EARLY", 0x120, "RC", "F", 0, "volatile (early) acknowledgements", []),
    ("T_ABORTS", 0x124, "RC", "F", 0, "error / abort completions released", []),
    ("T_GATE_REFUSED", 0x128, "RC", "F", 0, "completions refused by the ack gate", []),
    ("T_ADM_REJECTS", 0x12C, "RC", "F", 0, "commands rejected by admission control", []),
    ("T_LAT_DUR_LAST", 0x130, "RC", "F", 0, "accept -> DURABLE cycles, last", []),
    ("T_LAT_DUR_MAX", 0x134, "RC", "F", 0, "accept -> DURABLE cycles, max", []),
    ("T_LAT_DUR_SUM", 0x138, "RC", "F", 0, "accept -> DURABLE cycles, sum (low 32 bits)", []),
    ("T_DUR_COUNT", 0x13C, "RC", "F", 0, "tags that reached DURABLE", []),
    ("T_PF_SAFE_CYC", 0x140, "RC", "F", 0, "fault -> PF_SAFE cycles, last", []),
    ("T_PF_NAND_OPS", 0x144, "RC", "F", 0, "NAND ops started after a fault (all faults)", []),
    ("T_NAND_BLOCKED", 0x148, "RC", "F", 0, "NAND op starts seen while not permitted", []),
    ("T_CRASHES", 0x14C, "RC", "F", 0, "crash injections fired", []),
    ("T_VOL_LOST", 0x150, "RC", "F", 0, "volatile-acknowledged writes dropped", []),
    ("T_PHASE_ERR", 0x154, "RC", "F", 0, "illegal phase events", []),
    ("T_LATE_FW", 0x158, "RC", "F", 0, "phase events / completion requests for tags the power-fault sweep or a reset "
     "already retired (expected while the controller owns the tags; not an error)", []),
]

CMD_KEY = 0x5AFE
