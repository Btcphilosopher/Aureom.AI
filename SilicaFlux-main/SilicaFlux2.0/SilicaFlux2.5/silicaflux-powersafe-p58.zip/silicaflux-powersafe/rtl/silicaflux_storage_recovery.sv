// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: silicaflux_storage_recovery
// Power-loss protection and storage recovery controller.   Aureom.AI | SilicaFlux-STORE
//
// What it is: the hardware half of a SOFTWARE-MANAGED crash-consistency scheme.
// It does not store energy and does not make data durable by itself.  It
//   * decides which new commands are admitted (admission control),
//   * tracks every outstanding command's persistence phase (tag tracker),
//   * refuses to release a SUCCESS completion of a WRITE / TRIM / FLUSH before
//     the firmware reported it DURABLE (acknowledgement gate) -- unless the host
//     enabled a volatile write cache or physical PLP is present AND qualified,
//   * reacts to a power-fault warning without assuming hold-up energy:
//     stops admission at once, lets the NAND op in flight finish (it cannot be
//     stopped safely), starts no new program/erase (policy STOP) or at most a
//     small budget (DIAG), asserts WP#, completes outstanding tags once,
//   * sequences resets (host, watchdog, firmware, crash injection): admission
//     closed, NAND drained, sub-reset pulse, then RECOVERY until the firmware's
//     mount reports a result,
//   * keeps retained diagnostics across every reset it sequences and across the
//     external reset, telemetry counters, and a persistent commit status,
//   * injects deterministic crashes (sfpr_crash_inj).
//
// FSM (docs/03_RECOVERY_CONTROLLER.md):
//   POR_INIT -> RECOVERY -> RUN | RUN_RO | FAILED
//   RUN/RUN_RO/RECOVERY --pf--> PF_DRAIN -> PF_SAFE -> PF_RESTORE -> RUN (resume) | RESET_HOLD (remount)
//   RUN/RUN_RO/RECOVERY/SHUTDOWN/FAILED --reset req--> RESET_DRAIN -> RESET_HOLD -> RECOVERY
//   RUN/RUN_RO --SHUTDOWN_DONE--> SHUTDOWN          RUN --CTRL.READ_ONLY--> RUN_RO (FTL degraded)
//
// Reset domains: por_ni clears everything; rst_ni (external hard reset) clears
// the functional state but keeps the retention registers (RET_*, COMMIT_SEQ,
// CKPT_GEN, CI_FIRED_AT).  Retention is flops: a real power loss erases it --
// durable diagnostics are the firmware's NAND records (docs/04).
//
// PLP_PRESENT = 0 (default, and the only configuration this project claims):
// no hold-up energy exists, PLP_QUAL is ignored, PF_MODE PLP_FLUSH degrades to
// STOP, and early acknowledgement is possible only through host-enabled WCE.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module silicaflux_storage_recovery
#(
  parameter int NTAGS             = 8,       // 2..16 (P51 CMD_QUEUE_DEPTH)
  parameter int PLP_PRESENT       = 0,       // 1: hold-up circuitry exists AND has a qualified energy budget (docs/07)
  parameter int PF_FILTER         = 2,       // power-fail must be seen this many cycles (after sync)
  parameter int RESET_HOLD_CYCLES = 16,
  parameter int TW                = (NTAGS > 1) ? $clog2(NTAGS) : 1
) (
  input  wire logic          clk,
  input  wire logic          por_ni,          // power-on reset (async)
  input  wire logic          rst_ni,          // external hard reset (async)
  // power supervisor
  input  wire logic          pwr_fail_ni,     // async, active low
  input  wire logic          cap_ok_i,        // async: hold-up store healthy (PLP_PRESENT only)
  // reset requests
  input  wire logic          host_rst_req_i,  // host controller reset (edge)
  input  wire logic          wdt_rst_req_i,   // watchdog (level)
  output logic               sub_rst_no,      // firmware CPU + storage datapath reset
  // register page
  input  wire logic          rb_sel,
  input  wire logic          rb_we,
  input  wire logic [11:0]   rb_addr,
  input  wire logic [31:0]   rb_wdata,
  output logic [31:0]        rb_rdata,
  output logic               rb_err,
  // hardware admission port (command fetch)
  input  wire logic          cmd_valid_i,
  input  wire logic [2:0]    cmd_kind_i,
  input  wire logic          cmd_fua_i,
  output logic               cmd_accept_o,
  output logic [TW-1:0]      cmd_tag_o,
  output logic               cmd_reject_o,
  output logic [7:0]         cmd_rej_status_o,
  output logic [7:0]         cmd_rej_err_o,
  // hardware phase-event port (datapath)
  input  wire logic          ev_valid_i,
  input  wire logic [TW-1:0] ev_tag_i,
  input  wire logic [2:0]    ev_phase_i,
  // completion to the host completion-queue writer
  output logic               cq_valid_o,
  output logic [TW-1:0]      cq_tag_o,
  output logic [7:0]         cq_status_o,
  input  wire logic          cq_ready_i,
  // NAND controller
  input  wire logic          nand_busy_i,     // an array operation is in progress
  input  wire logic          nand_start_i,    // an operation starts this cycle
  input  wire logic [1:0]    nand_kind_i,     // 0 read, 1 program, 2 erase
  output logic               nand_prog_ok_o,  // program / erase may start
  output logic               nand_read_ok_o,  // read may start
  output logic               wp_no,           // NAND WP# (0 = write protected)
  // host-visible status / interrupt
  output logic [5:0]         host_status_o,   // {shutdown, fatal, ro, recovering, pf, rdy}
  output logic               irq_o,
  // crash injection
  output logic               crash_req_o,
  output logic [1:0]         crash_action_o
);
  import sfpr_regs_pkg::*;
  localparam bit PLP = (PLP_PRESENT != 0);

  // ================================================================ resets
  // frst_n is also sampled by the simulation-only assertions at the end of the module
  /* verilator lint_off SYNCASYNCNET */
  logic frst_n, prst_n;
  /* verilator lint_on SYNCASYNCNET */
  wire  f_async_n = por_ni & rst_ni;
  sfv_rst_sync u_frst (.clk, .rst_ni(f_async_n), .test_mode(1'b0), .test_rst_ni(1'b1), .rst_no(frst_n));
  sfv_rst_sync u_prst (.clk, .rst_ni(por_ni),    .test_mode(1'b0), .test_rst_ni(1'b1), .rst_no(prst_n));

  // ================================================================ asynchronous inputs
  logic pwr_ok_s, cap_ok_s;
  sfv_sync #(.RESET_VAL(1'b1)) u_pf_sync  (.clk, .rst_n(frst_n), .d(pwr_fail_ni), .q(pwr_ok_s));
  sfv_sync #(.RESET_VAL(1'b0)) u_cap_sync (.clk, .rst_n(frst_n), .d(cap_ok_i),    .q(cap_ok_s));

  // ================================================================ state / registers
  sfpr_state_e st_q, st_d;
  logic [31:0] cyc_q;
  logic [31:0] cfg_q, recov_tmo_q, drain_tmo_q, deb_q, irq_en_q, irq_st_q, err_q, err_info_q;
  logic [31:0] cmd_res_q, cpl_res_q;
  logic [TW-1:0] tag_sel_q;
  logic [4:0]  act_q;
  logic [7:0]  out_max_q;
  logic [7:0]  pf_cnt_q;
  logic [31:0] good_cnt_q, tmr_q, pf_cyc_q;
  logic [3:0]  budget_used_q;
  logic [1:0]  pf_mode_q;
  logic [3:0]  pf_budget_q;
  logic        fw_safe_q, cpu_held_q, pf_resumable_q, pf_from_ro_q, plp_revoked_q, sweep_kick_q, pf_ack_q;
  logic [6:0]  pend_cause_q;
  logic        host_rst_q, f_started_q;
  // telemetry
  logic [31:0] t_pf, t_rest, t_recov, t_rc_last, t_rc_max, t_acks, t_ackd, t_acke, t_abort, t_gate, t_adm;
  logic [31:0] t_ld_last, t_ld_max, t_ld_sum, t_dur, t_pf_safe, t_pf_ops, t_nblk, t_crash, t_vlost, t_perr, t_late;
  // retention
  logic [31:0] r_boots, r_cause, r_flags, r_snap, r_pfcnt, r_scr0, r_scr1, r_ci_at;
  logic [63:0] r_seq;
  logic [31:0] r_gen, seq_lo_stage_q;
  logic        r_seen_func;

  // ---------------------------------------------------------------- configuration fields
  wire       cfg_wce      = cfg_q[SFPR_CFG_WCE_LSB];
  wire       cfg_plp_qual = cfg_q[SFPR_CFG_PLP_QUAL_LSB];
  wire       cfg_remount  = cfg_q[SFPR_CFG_REMOUNT_ON_RESTORE_LSB];
  wire       cfg_autoab   = cfg_q[SFPR_CFG_AUTO_ABORT_LSB];
  wire       cfg_ackdur   = cfg_q[SFPR_CFG_ACK_DURABLE_ON_PF_LSB];
  wire       cfg_force_pf = cfg_q[SFPR_CFG_FORCE_PF_LSB];
  wire [1:0] cfg_pf_mode  = cfg_q[SFPR_CFG_PF_MODE_LSB +: SFPR_CFG_PF_MODE_W];
  wire [3:0] cfg_budget   = cfg_q[SFPR_CFG_PF_BUDGET_LSB +: SFPR_CFG_PF_BUDGET_W];
  wire       cfg_strict   = cfg_q[SFPR_CFG_STRICT_PHASES_LSB];

  // ---------------------------------------------------------------- power-fail filter / supply-good debounce
  wire pf_raw = !pwr_ok_s || cfg_force_pf;
  wire pf_lvl = pf_raw && (pf_cnt_q >= 8'(PF_FILTER - 1));
  wire good_stable = !pf_raw && (good_cnt_q >= deb_q);

  // ---------------------------------------------------------------- PLP qualification
  wire plp_effective = PLP && cfg_plp_qual && cap_ok_s && !plp_revoked_q;
  wire early_ok      = (st_q == SFPR_STATE_RUN) && (cfg_wce || plp_effective);

  // ---------------------------------------------------------------- register decode
  wire wr = rb_sel && rb_we;
  wire rd = rb_sel && !rb_we;
  wire w_ctrl   = wr && rb_addr == SFPR_CTRL;
  wire w_cfg    = wr && rb_addr == SFPR_CFG;
  wire w_submit = wr && rb_addr == SFPR_CMD_SUBMIT;
  wire w_phase  = wr && rb_addr == SFPR_PHASE_EV;
  wire w_cpl    = wr && rb_addr == SFPR_CPL_REQ;
  wire w_cp     = wr && rb_addr == SFPR_CP_EVENT;
  wire w_ci     = wr && rb_addr == SFPR_CI_CTRL;
  wire w_cicnt  = wr && rb_addr == SFPR_CI_COUNT;
  wire w_seq_lo = wr && rb_addr == SFPR_COMMIT_SEQ_LO;
  wire w_seq_hi = wr && rb_addr == SFPR_COMMIT_SEQ_HI;
  wire w_gen    = wr && rb_addr == SFPR_CKPT_GEN;

  wire c_recov_done = w_ctrl && rb_wdata[SFPR_CTRL_RECOVERY_DONE_LSB];
  wire [1:0] c_result = rb_wdata[SFPR_CTRL_RESULT_LSB +: SFPR_CTRL_RESULT_W];
  wire c_resume     = w_ctrl && rb_wdata[SFPR_CTRL_RESUME_LSB];
  wire c_fw_safe    = w_ctrl && rb_wdata[SFPR_CTRL_FW_SAFE_LSB];
  wire c_shutdown   = w_ctrl && rb_wdata[SFPR_CTRL_SHUTDOWN_DONE_LSB];
  wire c_sw_reset   = w_ctrl && rb_wdata[SFPR_CTRL_SW_RESET_LSB] && rb_wdata[31:16] == SFPR_CMD_KEY;
  wire c_read_only  = w_ctrl && rb_wdata[SFPR_CTRL_READ_ONLY_LSB];
  wire c_pf_ack     = w_ctrl && rb_wdata[SFPR_CTRL_PF_ACK_LSB];

  // ---------------------------------------------------------------- crash injection
  logic ci_armed, ci_pend, ci_fired, ci_tag_en, ci_fire;
  logic [1:0] ci_act, ci_fact;
  logic [4:0] ci_pt;
  logic [7:0] ci_tag;
  logic [31:0] ci_cnt, ci_seen;
  sfpr_crash_inj u_ci (
    .clk, .rst_n(frst_n),
    .cfg_we(w_ci), .cfg_arm(rb_wdata[SFPR_CI_CTRL_ARM_LSB]),
    .cfg_action(rb_wdata[SFPR_CI_CTRL_ACTION_LSB +: SFPR_CI_CTRL_ACTION_W]),
    .cfg_point(rb_wdata[SFPR_CI_CTRL_POINT_LSB +: SFPR_CI_CTRL_POINT_W]),
    .cfg_tag_en(rb_wdata[SFPR_CI_CTRL_TAG_EN_LSB]),
    .cfg_tag(rb_wdata[SFPR_CI_CTRL_TAG_LSB +: SFPR_CI_CTRL_TAG_W]),
    .cnt_we(w_cicnt), .cnt_wdata(rb_wdata),
    .cp_valid(w_cp), .cp_point(rb_wdata[SFPR_CP_EVENT_POINT_LSB +: SFPR_CP_EVENT_POINT_W]),
    .cp_tag(rb_wdata[SFPR_CP_EVENT_TAG_LSB +: SFPR_CP_EVENT_TAG_W]),
    .nand_start(nand_start_i), .nand_kind(nand_kind_i),
    .armed(ci_armed), .pending(ci_pend), .fired(ci_fired), .action(ci_act), .point(ci_pt),
    .tag_en(ci_tag_en), .tag(ci_tag), .count(ci_cnt), .seen(ci_seen),
    .fire(ci_fire), .fire_action(ci_fact));
  assign crash_req_o    = ci_fire;
  assign crash_action_o = ci_fact;
  wire crash_cpu = ci_fire && (ci_fact == SFPR_CI_ACTION_CPU_RESET);

  // ---------------------------------------------------------------- state classes
  wire s_pf    = (st_q == SFPR_STATE_PF_DRAIN) || (st_q == SFPR_STATE_PF_SAFE) || (st_q == SFPR_STATE_PF_RESTORE);
  wire s_run   = (st_q == SFPR_STATE_RUN) || (st_q == SFPR_STATE_RUN_RO);
  wire s_reset = (st_q == SFPR_STATE_RESET_DRAIN) || (st_q == SFPR_STATE_RESET_HOLD);

  // ---------------------------------------------------------------- admission control
  function automatic logic [16:0] admit(input logic [3:0] s, input logic [2:0] k);
    // {allowed, status[7:0], err[7:0]}
    case (s)
      SFPR_STATE_RUN:    admit = {1'b1, 8'h00, 8'h00};
      SFPR_STATE_RUN_RO: admit = (k == SFPR_KIND_WRITE || k == SFPR_KIND_TRIM)
                                 ? {1'b0, 8'(SFPR_STATUS_WRITE_PROTECTED), 8'(SFPR_ERR_NAND_WP)}
                                 : {1'b1, 8'h00, 8'h00};
      SFPR_STATE_PF_DRAIN, SFPR_STATE_PF_SAFE, SFPR_STATE_PF_RESTORE:
                         admit = {1'b0, 8'(SFPR_STATUS_ABORT_PWR_LOSS), 8'(SFPR_ERR_QUIESCED)};
      SFPR_STATE_FAILED: admit = {1'b0, 8'(SFPR_STATUS_INTERNAL_ERR), 8'(SFPR_ERR_FW)};
      default:           admit = {1'b0, 8'(SFPR_STATUS_ABORT_RESET), 8'(SFPR_ERR_NOT_READY)};
    endcase
  endfunction

  wire [2:0]  sub_kind = rb_wdata[SFPR_CMD_SUBMIT_KIND_LSB +: SFPR_CMD_SUBMIT_KIND_W];
  wire        sub_fua  = rb_wdata[SFPR_CMD_SUBMIT_FUA_LSB];
  wire [16:0] adm_reg  = admit(st_q, sub_kind);
  wire [16:0] adm_hw   = admit(st_q, cmd_kind_i);

  logic          trk_avail;
  logic [TW-1:0] trk_tag;
  wire reg_alloc = w_submit && adm_reg[16] && trk_avail;
  wire hw_try    = cmd_valid_i && !w_submit;            // the firmware path has priority
  wire hw_alloc  = hw_try && adm_hw[16] && trk_avail;
  assign cmd_accept_o     = hw_alloc;
  assign cmd_tag_o        = trk_tag;
  assign cmd_reject_o     = hw_try && !adm_hw[16];
  assign cmd_rej_status_o = adm_hw[15:8];
  assign cmd_rej_err_o    = adm_hw[7:0];

  // ---------------------------------------------------------------- tag tracker
  logic          trk_clear;
  logic          cpl_rel, cpl_ref, cpl_busy, cpl_vol;
  logic          sw_act, sw_done;
  logic [7:0]    n_busy, n_vacked, n_ndw, n_dun, e_vlost;
  logic [8:0]    tinfo;
  logic          e_pill, e_pfree, e_cfree, e_gref, e_ack, e_ackd, e_acke, e_abort, e_dur, e_late;
  logic [31:0]   e_dlat;
  logic [TW-1:0] e_etag;
  logic [2:0]    e_ephase;
  logic [3:0]    e_ereq;
  wire [2*TW-1:0] ev_tag_a   = {rb_wdata[SFPR_PHASE_EV_TAG_LSB +: TW], ev_tag_i};
  wire [5:0]      ev_phase_a = {rb_wdata[SFPR_PHASE_EV_PHASE_LSB +: 3], ev_phase_i};

  sfpr_tag_tracker #(.NTAGS(NTAGS), .TW(TW)) u_trk (
    .clk, .rst_n(frst_n), .clear(trk_clear), .now(cyc_q), .strict(cfg_strict), .early_ok, .owned(s_pf || s_reset),
    .alloc_req(reg_alloc || hw_alloc), .alloc_kind(reg_alloc ? sub_kind : cmd_kind_i),
    .alloc_fua(reg_alloc ? sub_fua : cmd_fua_i), .alloc_avail(trk_avail), .alloc_tag(trk_tag),
    .ev_valid({w_phase, ev_valid_i}), .ev_tag(ev_tag_a), .ev_phase(ev_phase_a),
    .cpl_req(w_cpl), .cpl_tag(rb_wdata[SFPR_CPL_REQ_TAG_LSB +: TW]),
    .cpl_status(rb_wdata[SFPR_CPL_REQ_STATUS_LSB +: 8]),
    .cpl_released(cpl_rel), .cpl_refused(cpl_ref), .cpl_busy(cpl_busy), .cpl_volatile(cpl_vol),
    .cq_valid(cq_valid_o), .cq_tag(cq_tag_o), .cq_status(cq_status_o), .cq_ready(cq_ready_i),
    .sweep_start(sweep_kick_q), .ack_durable_on_pf(cfg_ackdur), .sweep_active(sw_act), .sweep_done(sw_done),
    .n_busy, .n_vacked, .n_nondurable_wr(n_ndw), .n_durable_unacked(n_dun),
    .info_sel(tag_sel_q), .info(tinfo),
    .e_phase_illegal(e_pill), .e_phase_free(e_pfree), .e_cpl_free(e_cfree), .e_late, .e_gate_refused(e_gref),
    .e_ack, .e_ack_durable(e_ackd), .e_ack_early(e_acke), .e_abort, .e_vol_lost(e_vlost),
    .e_durable(e_dur), .e_durable_lat(e_dlat), .e_err_tag(e_etag), .e_err_phase(e_ephase), .e_err_req(e_ereq));

  // ---------------------------------------------------------------- NAND permissions
  // DIAG: work the firmware started before it knew of the fault gets nothing; the budget opens only after
  // the firmware acknowledges the fault (CTRL.PF_ACK) and is reserved for its diagnostics
  wire pf_prog_ok = (st_q == SFPR_STATE_PF_DRAIN) && !cpu_held_q &&
                    ((pf_mode_q == SFPR_PF_MODE_DIAG && pf_ack_q && budget_used_q < pf_budget_q) ||
                     (pf_mode_q == SFPR_PF_MODE_PLP_FLUSH));
  assign nand_prog_ok_o = (st_q == SFPR_STATE_RECOVERY) || (st_q == SFPR_STATE_RUN) || pf_prog_ok;
  assign nand_read_ok_o = (st_q == SFPR_STATE_RECOVERY) || s_run ||
                          ((st_q == SFPR_STATE_PF_DRAIN) && !cpu_held_q && pf_mode_q != SFPR_PF_MODE_STOP);
  wire wp_assert = (st_q == SFPR_STATE_POR_INIT) || (st_q == SFPR_STATE_RESET_HOLD) || (st_q == SFPR_STATE_PF_SAFE) ||
                   (st_q == SFPR_STATE_PF_RESTORE) || (st_q == SFPR_STATE_SHUTDOWN) || (st_q == SFPR_STATE_FAILED) ||
                   (st_q == SFPR_STATE_RUN_RO) ||
                   (((st_q == SFPR_STATE_PF_DRAIN) || (st_q == SFPR_STATE_RESET_DRAIN)) && !nand_busy_i && !nand_prog_ok_o);
  assign wp_no = !wp_assert;
  wire nand_blocked = nand_start_i &&
                      (((nand_kind_i == 2'd1 || nand_kind_i == 2'd2) && !nand_prog_ok_o) ||
                       (nand_kind_i == 2'd0 && !nand_read_ok_o));

  // ---------------------------------------------------------------- reset requests
  wire host_rst_edge = host_rst_req_i && !host_rst_q;
  wire wdt_req       = wdt_rst_req_i;
  wire any_rst_req   = host_rst_edge || wdt_req || c_sw_reset || crash_cpu;
  logic [6:0] req_cause;
  always_comb begin
    req_cause = '0;
    if (host_rst_edge) req_cause[SFPR_CAUSE_HOST] = 1'b1;
    if (wdt_req)       req_cause[SFPR_CAUSE_WDT]  = 1'b1;
    if (c_sw_reset)    req_cause[SFPR_CAUSE_SW]   = 1'b1;
    if (crash_cpu)     req_cause[SFPR_CAUSE_CRASH] = 1'b1;
  end

  // ---------------------------------------------------------------- next state
  wire pf_drain_done = !nand_busy_i &&
                       (pf_mode_q == SFPR_PF_MODE_STOP || cpu_held_q || fw_safe_q || c_fw_safe ||
                        (pf_mode_q == SFPR_PF_MODE_DIAG && budget_used_q >= pf_budget_q));
  wire tmr_drain_to  = (drain_tmo_q != 0) && (tmr_q >= drain_tmo_q);
  wire tmr_recov_to  = (recov_tmo_q != 0) && (tmr_q >= recov_tmo_q);
  always_comb begin
    st_d = st_q;
    case (st_q)
      SFPR_STATE_POR_INIT:    if (good_stable) st_d = SFPR_STATE_RECOVERY;
      SFPR_STATE_RECOVERY: begin
        if (pf_lvl)                st_d = SFPR_STATE_PF_DRAIN;
        else if (any_rst_req)      st_d = SFPR_STATE_RESET_DRAIN;
        else if (c_recov_done) begin
          if (c_result == 2'd0)      st_d = SFPR_STATE_RUN;
          else if (c_result == 2'd1) st_d = SFPR_STATE_RUN_RO;
          else                       st_d = SFPR_STATE_FAILED;
        end
        else if (tmr_recov_to)     st_d = SFPR_STATE_FAILED;
      end
      SFPR_STATE_RUN, SFPR_STATE_RUN_RO: begin
        if (pf_lvl)                st_d = SFPR_STATE_PF_DRAIN;
        else if (any_rst_req)      st_d = SFPR_STATE_RESET_DRAIN;
        else if (c_shutdown)       st_d = SFPR_STATE_SHUTDOWN;
        else if (c_read_only && st_q == SFPR_STATE_RUN) st_d = SFPR_STATE_RUN_RO;
      end
      SFPR_STATE_PF_DRAIN:    if (pf_drain_done || tmr_drain_to) st_d = SFPR_STATE_PF_SAFE;
      SFPR_STATE_PF_SAFE:     if (good_stable && !sw_act && !sweep_kick_q) st_d = SFPR_STATE_PF_RESTORE;
      SFPR_STATE_PF_RESTORE: begin
        if (pf_lvl)                                             st_d = SFPR_STATE_PF_SAFE;
        else if (cfg_remount || cpu_held_q || !pf_resumable_q) st_d = SFPR_STATE_RESET_HOLD;
        else if (c_resume && pf_from_ro_q)                      st_d = SFPR_STATE_RUN_RO;
        else if (c_resume)                                      st_d = SFPR_STATE_RUN;
      end
      SFPR_STATE_RESET_DRAIN: begin
        if (pf_lvl)                                st_d = SFPR_STATE_PF_DRAIN;
        else if (!nand_busy_i || tmr_drain_to)     st_d = SFPR_STATE_RESET_HOLD;
      end
      SFPR_STATE_RESET_HOLD: begin
        if (pf_lvl)                                      st_d = SFPR_STATE_PF_DRAIN;
        else if (tmr_q >= 32'(RESET_HOLD_CYCLES - 1))    st_d = SFPR_STATE_RECOVERY;
      end
      SFPR_STATE_SHUTDOWN, SFPR_STATE_FAILED: if (any_rst_req) st_d = SFPR_STATE_RESET_DRAIN;
      default: st_d = SFPR_STATE_POR_INIT;
    endcase
  end
  wire enter = (st_d != st_q);
  wire enter_pf = enter && (st_d == SFPR_STATE_PF_DRAIN);
  assign trk_clear = (st_q == SFPR_STATE_RESET_HOLD) || (st_q == SFPR_STATE_POR_INIT);

  // sub-reset: firmware CPU + datapath
  assign sub_rst_no = !((st_q == SFPR_STATE_POR_INIT) || (st_q == SFPR_STATE_RESET_HOLD) || (s_pf && cpu_held_q));

  // ---------------------------------------------------------------- error vector (set this cycle)
  logic [12:0] err_set;
  wire seq_new_ok = {rb_wdata, seq_lo_stage_q} >= r_seq;
  wire gen_new_ok = rb_wdata >= r_gen;
  always_comb begin
    err_set = '0;
    err_set[0]  = e_gref;
    err_set[1]  = e_pill;
    err_set[2]  = e_pfree;
    err_set[3]  = e_cfree;
    err_set[4]  = (st_q == SFPR_STATE_RECOVERY) && !pf_lvl && !any_rst_req && !c_recov_done && tmr_recov_to;
    err_set[5]  = ((st_q == SFPR_STATE_PF_DRAIN && !pf_drain_done) || (st_q == SFPR_STATE_RESET_DRAIN && nand_busy_i)) &&
                  tmr_drain_to;
    err_set[6]  = (st_q == SFPR_STATE_RECOVERY) && pf_lvl;
    err_set[7]  = (w_cfg && rb_wdata[SFPR_CFG_PLP_QUAL_LSB] && !PLP) ||
                  (w_cfg && rb_wdata[SFPR_CFG_PF_MODE_LSB +: 2] == SFPR_PF_MODE_PLP_FLUSH && !PLP) ||
                  (enter_pf && cfg_pf_mode == SFPR_PF_MODE_PLP_FLUSH && !plp_effective);
    err_set[8]  = (w_seq_hi && !seq_new_ok) || (w_gen && !gen_new_ok);
    err_set[9]  = nand_blocked;
    err_set[10] = w_submit && adm_reg[16] && !trk_avail;
    err_set[11] = PLP && cfg_plp_qual && !cap_ok_s && !plp_revoked_q;
    err_set[12] = (e_vlost != 8'd0);
  end

  // ---------------------------------------------------------------- functional sequential logic
  always_ff @(posedge clk or negedge frst_n) begin
    if (!frst_n) begin
      st_q <= SFPR_STATE_POR_INIT;
      cyc_q <= '0;
      cfg_q <= SFPR_CFG_RST & ~(PLP ? 32'h0 : 32'h2);
      recov_tmo_q <= SFPR_RECOV_TMO_RST; drain_tmo_q <= SFPR_DRAIN_TMO_RST; deb_q <= SFPR_RESTORE_DEB_RST;
      irq_en_q <= '0; irq_st_q <= '0; err_q <= '0; err_info_q <= '0; cmd_res_q <= '0; cpl_res_q <= '0;
      tag_sel_q <= '0; act_q <= '0; out_max_q <= '0;
      pf_cnt_q <= '0; good_cnt_q <= '0; tmr_q <= '0; pf_cyc_q <= '0; budget_used_q <= '0;
      pf_mode_q <= '0; pf_budget_q <= '0; fw_safe_q <= 1'b0; cpu_held_q <= 1'b0; pf_resumable_q <= 1'b0;
      pf_from_ro_q <= 1'b0; plp_revoked_q <= 1'b0; sweep_kick_q <= 1'b0; pend_cause_q <= '0; host_rst_q <= 1'b0;
      pf_ack_q <= 1'b0;
      f_started_q <= 1'b0;
      t_pf <= '0; t_rest <= '0; t_recov <= '0; t_rc_last <= '0; t_rc_max <= '0; t_acks <= '0; t_ackd <= '0;
      t_acke <= '0; t_abort <= '0; t_gate <= '0; t_adm <= '0; t_ld_last <= '0; t_ld_max <= '0; t_ld_sum <= '0;
      t_dur <= '0; t_pf_safe <= '0; t_pf_ops <= '0; t_nblk <= '0; t_crash <= '0; t_vlost <= '0; t_perr <= '0; t_late <= '0;
      seq_lo_stage_q <= '0;
    end else begin
      f_started_q <= 1'b1;
      cyc_q <= cyc_q + 32'd1;
      host_rst_q <= host_rst_req_i;
      st_q <= st_d;

      // power-fail filter and supply-good debounce
      pf_cnt_q   <= pf_raw ? ((pf_cnt_q == 8'hFF) ? pf_cnt_q : pf_cnt_q + 8'd1) : 8'd0;
      good_cnt_q <= pf_raw ? 32'd0 : ((good_cnt_q == 32'hFFFF_FFFF) ? good_cnt_q : good_cnt_q + 32'd1);

      // state timer (restarts on every state change)
      tmr_q <= enter ? 32'd0 : ((tmr_q == 32'hFFFF_FFFF) ? tmr_q : tmr_q + 32'd1);
      if (s_pf && !(st_q == SFPR_STATE_PF_SAFE || st_q == SFPR_STATE_PF_RESTORE)) pf_cyc_q <= pf_cyc_q + 32'd1;

      // ---- state entry actions
      if (enter_pf) begin
        pf_mode_q <= (cfg_pf_mode == SFPR_PF_MODE_PLP_FLUSH && !plp_effective) ? SFPR_PF_MODE_STOP :
                     (cfg_pf_mode == 2'd3) ? SFPR_PF_MODE_STOP : cfg_pf_mode;
        pf_budget_q <= cfg_budget;
        budget_used_q <= '0;
        fw_safe_q <= 1'b0;
        pf_ack_q <= 1'b0;
        pf_cyc_q <= '0;
        pf_resumable_q <= s_run;
        pf_from_ro_q <= (st_q == SFPR_STATE_RUN_RO);
        if (st_q == SFPR_STATE_POR_INIT || s_reset) cpu_held_q <= 1'b1;
        t_pf <= t_pf + 32'd1;
      end
      if (enter && st_d == SFPR_STATE_PF_SAFE) begin
        sweep_kick_q <= cfg_autoab;
        t_pf_safe <= pf_cyc_q;
      end else begin
        sweep_kick_q <= 1'b0;
      end
      if (enter && st_d == SFPR_STATE_PF_RESTORE) begin
        t_rest <= t_rest + 32'd1;
      end
      if (enter && st_d == SFPR_STATE_RESET_DRAIN) pend_cause_q <= req_cause;
      if (enter && st_d == SFPR_STATE_RECOVERY) begin
        cpu_held_q <= 1'b0;
        t_recov <= t_recov + 32'd1;
      end
      if (st_q == SFPR_STATE_RECOVERY && (c_recov_done || tmr_recov_to) && enter) begin
        t_rc_last <= tmr_q;
        if (tmr_q > t_rc_max) t_rc_max <= tmr_q;
      end
      // a reset request during a power fault: the CPU will be held, firmware is no longer waited for
      if (s_pf && any_rst_req) cpu_held_q <= 1'b1;
      if ((st_q == SFPR_STATE_PF_DRAIN) && c_fw_safe) fw_safe_q <= 1'b1;
      if ((st_q == SFPR_STATE_PF_DRAIN) && c_pf_ack) pf_ack_q <= 1'b1;
      if (s_pf && nand_start_i) begin
        t_pf_ops <= t_pf_ops + 32'd1;
        if (nand_kind_i != 2'd0 && budget_used_q != 4'hF) budget_used_q <= budget_used_q + 4'd1;
      end

      // ---- PLP revocation
      if (w_cfg && !rb_wdata[SFPR_CFG_PLP_QUAL_LSB]) plp_revoked_q <= 1'b0;
      else if (PLP && cfg_plp_qual && !cap_ok_s) plp_revoked_q <= 1'b1;

      // ---- registers
      if (w_cfg) cfg_q <= rb_wdata & (PLP ? 32'h0000_1FFF : 32'h0000_1FFD);
      if (wr && rb_addr == SFPR_RECOV_TMO)   recov_tmo_q <= rb_wdata;
      if (wr && rb_addr == SFPR_DRAIN_TMO)   drain_tmo_q <= rb_wdata;
      if (wr && rb_addr == SFPR_RESTORE_DEB) deb_q <= rb_wdata;
      if (wr && rb_addr == SFPR_IRQ_EN)      irq_en_q <= rb_wdata;
      if (wr && rb_addr == SFPR_TAG_SEL)     tag_sel_q <= rb_wdata[TW-1:0];
      if (wr && rb_addr == SFPR_ACT)         act_q <= rb_wdata[4:0];
      if (w_seq_lo) seq_lo_stage_q <= rb_wdata;
      if (w_submit) begin
        cmd_res_q <= '0;
        if (!adm_reg[16]) begin
          cmd_res_q[SFPR_CMD_RESULT_REJECTED_LSB] <= 1'b1;
          cmd_res_q[SFPR_CMD_RESULT_STATUS_LSB +: 8] <= adm_reg[15:8];
          cmd_res_q[SFPR_CMD_RESULT_ERRC_LSB +: 8] <= adm_reg[7:0];
        end else if (!trk_avail) begin
          cmd_res_q[SFPR_CMD_RESULT_NO_TAG_LSB] <= 1'b1;
        end else begin
          cmd_res_q[SFPR_CMD_RESULT_ACCEPTED_LSB] <= 1'b1;
          cmd_res_q[SFPR_CMD_RESULT_TAG_LSB +: 4] <= 4'(trk_tag);
        end
      end
      if (w_cpl) begin
        cpl_res_q <= '0;
        cpl_res_q[SFPR_CPL_RESULT_RELEASED_LSB] <= cpl_rel;
        cpl_res_q[SFPR_CPL_RESULT_REFUSED_LSB]  <= cpl_ref;
        cpl_res_q[SFPR_CPL_RESULT_BUSY_LSB]     <= cpl_busy;
        cpl_res_q[SFPR_CPL_RESULT_VOLATILE_LSB] <= cpl_vol;
        cpl_res_q[SFPR_CPL_RESULT_STATUS_LSB +: 8] <= rb_wdata[SFPR_CPL_REQ_STATUS_LSB +: 8];
      end

      // ---- errors (sticky, W1C) and interrupts
      begin : p_err_irq
        logic [31:0] e_next, i_next;
        e_next = err_q;
        if (wr && rb_addr == SFPR_ERR) e_next = e_next & ~rb_wdata;
        e_next = e_next | {19'd0, err_set};
        err_q <= e_next;
        i_next = irq_st_q;
        if (wr && rb_addr == SFPR_IRQ_STATUS) i_next = i_next & ~rb_wdata;
        if (err_set != '0) i_next[SFPR_IRQ_STATUS_ERR_LSB] = 1'b1;
        if (ci_fire) i_next[SFPR_IRQ_STATUS_CRASH_LSB] = 1'b1;
        if (enter_pf) i_next[SFPR_IRQ_STATUS_PF_LSB] = 1'b1;
        if (enter && st_d == SFPR_STATE_PF_SAFE) i_next[SFPR_IRQ_STATUS_SAFE_LSB] = 1'b1;
        if (enter && st_d == SFPR_STATE_PF_RESTORE) i_next[SFPR_IRQ_STATUS_RESTORE_LSB] = 1'b1;
        if (enter && st_d == SFPR_STATE_RECOVERY) i_next[SFPR_IRQ_STATUS_RECOVERY_LSB] = 1'b1;
        irq_st_q <= i_next;
      end
      if (err_set != '0) begin : p_err_info
        logic [4:0] b;
        b = '0;
        for (int i = 12; i >= 0; i--) if (err_set[i]) b = 5'(i);
        err_info_q <= {3'd0, b, 4'd0, 4'(st_q), e_ereq, {1'b0, e_ephase}, 8'(e_etag)};
      end

      // ---- telemetry
      if (n_busy > out_max_q) out_max_q <= n_busy;
      if (e_ack)   t_acks  <= t_acks + 32'd1;
      if (e_ackd)  t_ackd  <= t_ackd + 32'd1;
      if (e_acke)  t_acke  <= t_acke + 32'd1;
      if (e_abort) t_abort <= t_abort + 32'd1;
      if (e_gref)  t_gate  <= t_gate + 32'd1;
      if (e_pill)  t_perr  <= t_perr + 32'd1;
      if (e_late)  t_late  <= t_late + 32'd1;
      if ((w_submit && !adm_reg[16]) || (hw_try && !adm_hw[16])) t_adm <= t_adm + 32'd1;
      if (e_dur) begin
        t_ld_last <= e_dlat;
        if (e_dlat > t_ld_max) t_ld_max <= e_dlat;
        t_ld_sum <= t_ld_sum + e_dlat;
        t_dur <= t_dur + 32'd1;
      end
      if (nand_blocked) t_nblk <= t_nblk + 32'd1;
      if (ci_fire) t_crash <= t_crash + 32'd1;
      if (e_vlost != 8'd0) t_vlost <= t_vlost + 32'(e_vlost);
    end
  end

  // ---------------------------------------------------------------- retention domain (por_ni only)
  always_ff @(posedge clk or negedge prst_n) begin
    if (!prst_n) begin
      r_boots <= '0; r_cause <= 32'd1 << SFPR_CAUSE_POR; r_flags <= '0; r_snap <= '0; r_pfcnt <= '0;
      r_scr0 <= '0; r_scr1 <= '0; r_ci_at <= '0; r_seq <= '0; r_gen <= '0; r_seen_func <= 1'b0;
    end else begin
      // external hard reset seen: the functional domain restarted while retention survived
      if (!f_started_q) begin
        if (r_seen_func) r_cause <= 32'd1 << SFPR_CAUSE_EXT;
        r_seen_func <= 1'b1;
      end
      if (f_started_q) begin
        if (enter && st_d == SFPR_STATE_RESET_HOLD) begin
          r_boots <= r_boots + 32'd1;
          r_cause <= (st_q == SFPR_STATE_PF_RESTORE) ? (32'd1 << SFPR_CAUSE_PF_REMOUNT) : {25'd0, pend_cause_q};
        end
        if (enter && (st_d == SFPR_STATE_RUN || st_d == SFPR_STATE_RUN_RO)) r_flags[SFPR_RET_FLAGS_UNCLEAN_LSB] <= 1'b1;
        if (enter && st_d == SFPR_STATE_SHUTDOWN) r_flags[SFPR_RET_FLAGS_UNCLEAN_LSB] <= 1'b0;
        if (enter && st_d == SFPR_STATE_FAILED) r_flags[SFPR_RET_FLAGS_RECOV_FAILED_LSB] <= 1'b1;
        if (enter_pf) begin
          r_flags[SFPR_RET_FLAGS_PF_SEEN_LSB] <= 1'b1;
          r_pfcnt <= r_pfcnt + 32'd1;
          r_snap <= {act_q[2:0], nand_busy_i, n_dun, n_ndw, n_busy, 4'(st_q)};
        end
        if (ci_fire) begin
          r_flags[SFPR_RET_FLAGS_CRASH_FIRED_LSB] <= 1'b1;
          r_ci_at <= cyc_q;
        end
        if (wr && rb_addr == SFPR_RET_FLAGS) r_flags <= r_flags & ~rb_wdata;
        if (wr && rb_addr == SFPR_RET_SCRATCH0) r_scr0 <= rb_wdata;
        if (wr && rb_addr == SFPR_RET_SCRATCH1) r_scr1 <= rb_wdata;
        if (w_seq_hi && seq_new_ok) r_seq <= {rb_wdata, seq_lo_stage_q};
        if (w_gen && gen_new_ok) r_gen <= rb_wdata;
      end
    end
  end

  // ---------------------------------------------------------------- outputs
  assign irq_o = |(irq_st_q & irq_en_q);
  assign host_status_o = {(st_q == SFPR_STATE_SHUTDOWN), (st_q == SFPR_STATE_FAILED), (st_q == SFPR_STATE_RUN_RO),
                          (st_q == SFPR_STATE_POR_INIT || st_q == SFPR_STATE_RECOVERY || s_reset), s_pf, s_run};

  // ---------------------------------------------------------------- register read
  logic [31:0] state_w;
  always_comb begin
    state_w = '0;
    state_w[SFPR_STATE_FSM_LSB +: 4]        = st_q;
    state_w[SFPR_STATE_ADMIT_LSB]           = s_run;
    state_w[SFPR_STATE_ADMIT_WR_LSB]        = (st_q == SFPR_STATE_RUN);
    state_w[SFPR_STATE_WP_LSB]              = wp_assert;
    state_w[SFPR_STATE_PROG_OK_LSB]         = nand_prog_ok_o;
    state_w[SFPR_STATE_PWR_FAIL_LSB]        = pf_lvl;
    state_w[SFPR_STATE_CAP_OK_LSB]          = cap_ok_s;
    state_w[SFPR_STATE_EARLY_ACK_OK_LSB]    = early_ok;
    state_w[SFPR_STATE_PLP_EFFECTIVE_LSB]   = plp_effective;
    state_w[SFPR_STATE_NAND_BUSY_LSB]       = nand_busy_i;
    state_w[SFPR_STATE_SUB_RST_LSB]         = !sub_rst_no;
    state_w[SFPR_STATE_CPU_HELD_LSB]        = cpu_held_q;
    state_w[SFPR_STATE_SWEEP_DONE_LSB]      = sw_done;
  end

  logic [31:0] ci_ctrl_w;
  always_comb begin
    ci_ctrl_w = '0;
    ci_ctrl_w[SFPR_CI_CTRL_ARM_LSB]                        = ci_armed;
    ci_ctrl_w[SFPR_CI_CTRL_FIRED_LSB]                      = ci_fired;
    ci_ctrl_w[SFPR_CI_CTRL_ACTION_LSB +: 2]                = ci_act;
    ci_ctrl_w[SFPR_CI_CTRL_POINT_LSB +: 5]                 = ci_pt;
    ci_ctrl_w[SFPR_CI_CTRL_TAG_EN_LSB]                     = ci_tag_en;
    ci_ctrl_w[SFPR_CI_CTRL_PENDING_LSB]                    = ci_pend;
    ci_ctrl_w[SFPR_CI_CTRL_TAG_LSB +: 8]                   = ci_tag;
  end

  logic known, ro;
  always_comb begin
    rb_rdata = '0;
    known = 1'b1;
    ro = 1'b0;
    case (rb_addr)
      SFPR_ID:            begin rb_rdata = SFPR_ID_VALUE; ro = 1'b1; end
      SFPR_VERSION:       begin rb_rdata = SFPR_VERSION_VALUE; ro = 1'b1; end
      SFPR_CONFIG:        begin rb_rdata = {23'd0, PLP, 8'(NTAGS)}; ro = 1'b1; end
      SFPR_STATE:         begin rb_rdata = state_w; ro = 1'b1; end
      SFPR_CTRL:          rb_rdata = '0;
      SFPR_CFG:           rb_rdata = cfg_q;
      SFPR_RECOV_TMO:     rb_rdata = recov_tmo_q;
      SFPR_DRAIN_TMO:     rb_rdata = drain_tmo_q;
      SFPR_RESTORE_DEB:   rb_rdata = deb_q;
      SFPR_ERR:           rb_rdata = err_q;
      SFPR_ERR_INFO:      begin rb_rdata = err_info_q; ro = 1'b1; end
      SFPR_IRQ_EN:        rb_rdata = irq_en_q;
      SFPR_IRQ_STATUS:    rb_rdata = irq_st_q;
      SFPR_CMD_SUBMIT:    rb_rdata = '0;
      SFPR_CMD_RESULT:    begin rb_rdata = cmd_res_q; ro = 1'b1; end
      SFPR_PHASE_EV:      rb_rdata = '0;
      SFPR_CPL_REQ:       rb_rdata = '0;
      SFPR_CPL_RESULT:    begin rb_rdata = cpl_res_q; ro = 1'b1; end
      SFPR_OUTSTANDING:   begin rb_rdata = {n_ndw, n_vacked, out_max_q, n_busy}; ro = 1'b1; end
      SFPR_TAG_SEL:       rb_rdata = 32'(tag_sel_q);
      SFPR_TAG_INFO:      begin rb_rdata = {23'd0, tinfo}; ro = 1'b1; end
      SFPR_COMMIT_SEQ_LO: rb_rdata = r_seq[31:0];
      SFPR_COMMIT_SEQ_HI: rb_rdata = r_seq[63:32];
      SFPR_CKPT_GEN:      rb_rdata = r_gen;
      SFPR_ACT:           rb_rdata = {27'd0, act_q};
      SFPR_CP_EVENT:      rb_rdata = '0;
      SFPR_CI_CTRL:       rb_rdata = ci_ctrl_w;
      SFPR_CI_COUNT:      rb_rdata = ci_cnt;
      SFPR_CI_SEEN:       begin rb_rdata = ci_seen; ro = 1'b1; end
      SFPR_CI_FIRED_AT:   begin rb_rdata = r_ci_at; ro = 1'b1; end
      SFPR_RET_BOOTS:     begin rb_rdata = r_boots; ro = 1'b1; end
      SFPR_RET_CAUSE:     begin rb_rdata = r_cause; ro = 1'b1; end
      SFPR_RET_FLAGS:     rb_rdata = r_flags;
      SFPR_RET_PF_SNAP:   begin rb_rdata = r_snap; ro = 1'b1; end
      SFPR_RET_PF_COUNT:  begin rb_rdata = r_pfcnt; ro = 1'b1; end
      SFPR_RET_SCRATCH0:  rb_rdata = r_scr0;
      SFPR_RET_SCRATCH1:  rb_rdata = r_scr1;
      SFPR_T_CYCLES:      begin rb_rdata = cyc_q; ro = 1'b1; end
      SFPR_T_PF_EVENTS:   begin rb_rdata = t_pf; ro = 1'b1; end
      SFPR_T_RESTORES:    begin rb_rdata = t_rest; ro = 1'b1; end
      SFPR_T_RECOVERIES:  begin rb_rdata = t_recov; ro = 1'b1; end
      SFPR_T_RECOV_CYC_LAST: begin rb_rdata = t_rc_last; ro = 1'b1; end
      SFPR_T_RECOV_CYC_MAX:  begin rb_rdata = t_rc_max; ro = 1'b1; end
      SFPR_T_ACKS:        begin rb_rdata = t_acks; ro = 1'b1; end
      SFPR_T_ACK_DURABLE: begin rb_rdata = t_ackd; ro = 1'b1; end
      SFPR_T_ACK_EARLY:   begin rb_rdata = t_acke; ro = 1'b1; end
      SFPR_T_ABORTS:      begin rb_rdata = t_abort; ro = 1'b1; end
      SFPR_T_GATE_REFUSED:begin rb_rdata = t_gate; ro = 1'b1; end
      SFPR_T_ADM_REJECTS: begin rb_rdata = t_adm; ro = 1'b1; end
      SFPR_T_LAT_DUR_LAST:begin rb_rdata = t_ld_last; ro = 1'b1; end
      SFPR_T_LAT_DUR_MAX: begin rb_rdata = t_ld_max; ro = 1'b1; end
      SFPR_T_LAT_DUR_SUM: begin rb_rdata = t_ld_sum; ro = 1'b1; end
      SFPR_T_DUR_COUNT:   begin rb_rdata = t_dur; ro = 1'b1; end
      SFPR_T_PF_SAFE_CYC: begin rb_rdata = t_pf_safe; ro = 1'b1; end
      SFPR_T_PF_NAND_OPS: begin rb_rdata = t_pf_ops; ro = 1'b1; end
      SFPR_T_NAND_BLOCKED:begin rb_rdata = t_nblk; ro = 1'b1; end
      SFPR_T_CRASHES:     begin rb_rdata = t_crash; ro = 1'b1; end
      SFPR_T_VOL_LOST:    begin rb_rdata = t_vlost; ro = 1'b1; end
      SFPR_T_PHASE_ERR:   begin rb_rdata = t_perr; ro = 1'b1; end
      SFPR_T_LATE_FW:     begin rb_rdata = t_late; ro = 1'b1; end
      default:            known = 1'b0;
    endcase
    if (!rd) rb_rdata = '0;
  end
  assign rb_err = rb_sel && (!known || (rb_we && ro));

  // unused bits (lint)
  wire unused_ok = &{1'b0, rb_wdata[15:8] != 8'd0, cpl_res_q[31:16], 1'b0};

`ifndef SYNTHESIS
`ifndef SFPR_NO_ASSERT
  // admission: nothing is accepted outside RUN / RUN_RO
  always_ff @(posedge clk) if (frst_n && cmd_accept_o && !s_run) $error("sfpr: command accepted in state %0d", st_q);
  // a NAND program/erase may not be permitted in PF_SAFE / RESET_HOLD
  always_ff @(posedge clk) if (frst_n && nand_prog_ok_o && (st_q == SFPR_STATE_PF_SAFE || st_q == SFPR_STATE_RESET_HOLD))
    $error("sfpr: program permitted in state %0d", st_q);
  // without PLP the PLP-only policy can never be in force
  always_ff @(posedge clk) if (frst_n && !PLP && (plp_effective || pf_mode_q == SFPR_PF_MODE_PLP_FLUSH))
    $error("sfpr: PLP behaviour without PLP");
`endif
`endif
endmodule

`default_nettype wire
