// SilicaFlux PowerSafe (Project 58) -- RTL file list (order matters: package first)
rtl/generated/sfpr_regs_pkg.sv
third_party/silicaflux-v/rtl/common/sfv_common.sv
rtl/sfpr_crash_inj.sv
rtl/sfpr_tag_tracker.sv
rtl/silicaflux_storage_recovery.sv
