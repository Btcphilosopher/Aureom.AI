// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: sfpr_tag_tracker
//
// Outstanding-operation table and acknowledgement gate.
//
//   * one entry per command tag: kind, FUA, persistence phase, VACKED, accept time
//   * allocation (lowest free tag) for the admission port
//   * phase events from two sources (datapath port, firmware register), checked
//     against the per-kind phase chain (docs/02_PERSISTENCE_MODEL.md):
//        WRITE  ACCEPTED -> BUFFERED -> PROGRAMMED -> VERIFIED -> MAPPED -> DURABLE
//        TRIM   ACCEPTED ->             PROGRAMMED -> VERIFIED -> MAPPED -> DURABLE
//        FLUSH  ACCEPTED ->                                                 DURABLE
//        READ / ADMIN: any increasing sequence
//   * the ACK GATE: a SUCCESS completion of a durable kind (WRITE, TRIM, FLUSH)
//     is released to the host only when the tag is DURABLE -- or, for a non-FUA
//     WRITE at BUFFERED or later, when an early acknowledgement is permitted
//     (host-enabled volatile write cache, or qualified PLP).  An early-acked tag
//     stays allocated (VACKED) until it reaches DURABLE, then frees silently.
//     FLUSH additionally requires that no VACKED write is outstanding.
//   * the power-fault SWEEP: every outstanding tag is completed once --
//     DURABLE durable-kind tags with SUCCESS (if enabled), everything else with
//     ABORT_PWR_LOSS; VACKED tags are dropped and reported as volatile loss.
//   * one completion output slot (valid/ready) shared by the gate and the sweep.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sfpr_tag_tracker
#(
  parameter int NTAGS = 8,
  parameter int TW    = (NTAGS > 1) ? $clog2(NTAGS) : 1
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  input  wire logic           clear,           // sub-reset: drop every tag (no completion)
  input  wire logic [31:0]    now,
  input  wire logic           strict,
  input  wire logic           early_ok,
  input  wire logic           owned,           // the controller owns the tags (power fault / reset): late
                                               // firmware events for retired tags are expected, not errors
  // allocation
  input  wire logic           alloc_req,
  input  wire logic [2:0]     alloc_kind,
  input  wire logic           alloc_fua,
  output logic                alloc_avail,
  output logic [TW-1:0]       alloc_tag,
  // phase events: [0] datapath port, [1] firmware register
  input  wire logic [1:0]     ev_valid,
  input  wire logic [2*TW-1:0] ev_tag,         // {port 1, port 0}
  input  wire logic [5:0]     ev_phase,        // {port 1, port 0}
  // completion request (firmware)
  input  wire logic           cpl_req,
  input  wire logic [TW-1:0]  cpl_tag,
  input  wire logic [7:0]     cpl_status,
  output logic                cpl_released,
  output logic                cpl_refused,
  output logic                cpl_busy,
  output logic                cpl_volatile,
  // completion output slot
  output logic                cq_valid,
  output logic [TW-1:0]       cq_tag,
  output logic [7:0]          cq_status,
  input  wire logic           cq_ready,
  // power-fault sweep
  input  wire logic           sweep_start,
  input  wire logic           ack_durable_on_pf,
  output logic                sweep_active,
  output logic                sweep_done,
  // status
  output logic [7:0]          n_busy,
  output logic [7:0]          n_vacked,
  output logic [7:0]          n_nondurable_wr,
  output logic [7:0]          n_durable_unacked,
  input  wire logic [TW-1:0]  info_sel,
  output logic [8:0]          info,            // {busy, vacked, phase[2:0], fua, kind[2:0]}
  // event pulses (telemetry / ERR)
  output logic                e_phase_illegal,
  output logic                e_phase_free,
  output logic                e_cpl_free,
  output logic                e_late,          // late firmware event for a retired tag (while owned)
  output logic                e_gate_refused,
  output logic                e_ack,           // completion entered the CQ slot
  output logic                e_ack_durable,
  output logic                e_ack_early,
  output logic                e_abort,
  output logic [7:0]          e_vol_lost,      // VACKED tags dropped this cycle
  output logic                e_durable,
  output logic [31:0]         e_durable_lat,
  output logic [TW-1:0]       e_err_tag,
  output logic [2:0]          e_err_phase,
  output logic [3:0]          e_err_req
);
  import sfpr_regs_pkg::*;
  // ---------------------------------------------------------------- state
  logic          busy_q   [NTAGS];
  logic [2:0]    kind_q   [NTAGS];
  logic          fua_q    [NTAGS];
  logic [2:0]    phase_q  [NTAGS];
  logic          vacked_q [NTAGS];
  logic [31:0]   t0_q     [NTAGS];
  logic          cqv_q;
  logic [TW-1:0] cqt_q;
  logic [7:0]    cqs_q;
  logic          sw_act_q, sw_done_q;
  logic [TW:0]   sw_ptr_q;

  logic          busy_d   [NTAGS];
  logic [2:0]    kind_d   [NTAGS];
  logic          fua_d    [NTAGS];
  logic [2:0]    phase_d  [NTAGS];
  logic          vacked_d [NTAGS];
  logic [31:0]   t0_d     [NTAGS];
  logic          cqv_d;
  logic [TW-1:0] cqt_d;
  logic [7:0]    cqs_d;
  logic          sw_act_d, sw_done_d;
  logic [TW:0]   sw_ptr_d;

  // ---------------------------------------------------------------- helpers
  function automatic logic durable_kind(input logic [2:0] k);
    durable_kind = (k == SFPR_KIND_WRITE) || (k == SFPR_KIND_TRIM) || (k == SFPR_KIND_FLUSH);
  endfunction

  function automatic logic phase_legal(input logic [2:0] k, input logic [2:0] cur, input logic [2:0] p);
    logic ok;
    ok = 1'b0;
    case (k)
      SFPR_KIND_WRITE: ok = (p == cur + 3'd1);
      SFPR_KIND_TRIM:  ok = ((cur == SFPR_PHASE_ACCEPTED) && (p == SFPR_PHASE_PROGRAMMED)) ||
                            ((cur >= SFPR_PHASE_PROGRAMMED) && (p == cur + 3'd1));
      SFPR_KIND_FLUSH: ok = (cur == SFPR_PHASE_ACCEPTED) && (p == SFPR_PHASE_DURABLE);
      default:         ok = (p > cur) && (p <= SFPR_PHASE_DURABLE);
    endcase
    if (p == SFPR_PHASE_FREE || p > SFPR_PHASE_DURABLE) ok = 1'b0;
    phase_legal = ok;
  endfunction

  // ---------------------------------------------------------------- counts (current state)
  logic [7:0] c_busy, c_vacked, c_ndw, c_dun;
  always_comb begin
    c_busy = '0; c_vacked = '0; c_ndw = '0; c_dun = '0;
    for (int i = 0; i < NTAGS; i++) begin
      if (busy_q[i]) begin
        c_busy = c_busy + 8'd1;
        if (vacked_q[i]) c_vacked = c_vacked + 8'd1;
        if ((kind_q[i] == SFPR_KIND_WRITE || kind_q[i] == SFPR_KIND_TRIM) && phase_q[i] != SFPR_PHASE_DURABLE)
          c_ndw = c_ndw + 8'd1;
        if (phase_q[i] == SFPR_PHASE_DURABLE && !vacked_q[i]) c_dun = c_dun + 8'd1;
      end
    end
  end
  assign n_busy = c_busy;
  assign n_vacked = c_vacked;
  assign n_nondurable_wr = c_ndw;
  assign n_durable_unacked = c_dun;

  // lowest free tag
  always_comb begin
    alloc_avail = 1'b0;
    alloc_tag   = '0;
    for (int i = NTAGS - 1; i >= 0; i--) begin
      if (!busy_q[i]) begin
        alloc_avail = 1'b1;
        alloc_tag   = TW'(i);
      end
    end
  end

  // ---------------------------------------------------------------- next state
  always_comb begin : p_next
    logic          slot_free;
    logic [TW-1:0] t;
    logic [2:0]    p;
    logic          legal;
    logic          gate_ok, early;
    logic [TW-1:0] st;
    logic [7:0]    vl;

    for (int i = 0; i < NTAGS; i++) begin
      busy_d[i] = busy_q[i]; kind_d[i] = kind_q[i]; fua_d[i] = fua_q[i];
      phase_d[i] = phase_q[i]; vacked_d[i] = vacked_q[i]; t0_d[i] = t0_q[i];
    end
    cqv_d = cqv_q && !cq_ready;
    cqt_d = cqt_q;
    cqs_d = cqs_q;
    sw_act_d = sw_act_q; sw_done_d = sw_done_q; sw_ptr_d = sw_ptr_q;
    slot_free = !cqv_q;              // one completion per cycle at most, never while the slot is full

    cpl_released = 1'b0; cpl_refused = 1'b0; cpl_busy = 1'b0; cpl_volatile = 1'b0;
    e_phase_illegal = 1'b0; e_phase_free = 1'b0; e_cpl_free = 1'b0; e_gate_refused = 1'b0; e_late = 1'b0;
    e_ack = 1'b0; e_ack_durable = 1'b0; e_ack_early = 1'b0; e_abort = 1'b0;
    e_durable = 1'b0; e_durable_lat = '0;
    e_err_tag = '0; e_err_phase = '0; e_err_req = '0;
    vl = '0;
    t = '0; p = '0; legal = 1'b0; gate_ok = 1'b0; early = 1'b0; st = '0;

    // ---- allocation (from the current free set)
    if (alloc_req && alloc_avail) begin
      busy_d[alloc_tag]   = 1'b1;
      kind_d[alloc_tag]   = alloc_kind;
      fua_d[alloc_tag]    = alloc_fua;
      phase_d[alloc_tag]  = SFPR_PHASE_ACCEPTED;
      vacked_d[alloc_tag] = 1'b0;
      t0_d[alloc_tag]     = now;
    end

    // ---- phase events (port 0 then port 1)
    for (int e = 0; e < 2; e++) begin
      if (ev_valid[e]) begin
        t = ev_tag[e*TW +: TW];
        p = ev_phase[e*3 +: 3];
        if (!busy_d[t] || (alloc_req && alloc_avail && alloc_tag == t)) begin
          if (owned) e_late = 1'b1;
          else begin
            e_phase_free = 1'b1;
            e_err_tag = t; e_err_phase = phase_d[t]; e_err_req = {1'b0, p};
          end
        end else begin
          legal = phase_legal(kind_d[t], phase_d[t], p);
          if (!legal) begin
            e_phase_illegal = 1'b1;
            e_err_tag = t; e_err_phase = phase_d[t]; e_err_req = {1'b0, p};
          end
          if (legal || (!strict && p > phase_d[t] && p <= SFPR_PHASE_DURABLE)) begin
            phase_d[t] = p;
            if (p == SFPR_PHASE_DURABLE) begin
              e_durable = 1'b1;
              e_durable_lat = now - t0_d[t];
              if (vacked_d[t]) busy_d[t] = 1'b0;      // early-acked write now durable: free silently
            end
          end
        end
      end
    end

    // ---- completion request through the ack gate
    if (cpl_req) begin
      t = cpl_tag;
      if (!busy_d[t]) begin
        cpl_refused = 1'b1;
        if (owned) e_late = 1'b1;
        else begin
          e_cpl_free = 1'b1;
          e_err_tag = t; e_err_phase = phase_d[t]; e_err_req = cpl_status[3:0];
        end
      end else if (vacked_d[t]) begin
        if (cpl_status == SFPR_STATUS_SUCCESS) begin        // second success for a volatile write
          cpl_refused = 1'b1; e_gate_refused = 1'b1;
          e_err_tag = t; e_err_phase = phase_d[t]; e_err_req = cpl_status[3:0];
        end else begin                                     // firmware gives up on a volatile write
          busy_d[t] = 1'b0; cpl_released = 1'b1; vl = vl + 8'd1;
        end
      end else begin
        early = 1'b0;
        if (cpl_status != SFPR_STATUS_SUCCESS || !durable_kind(kind_d[t])) gate_ok = 1'b1;
        else if (kind_d[t] == SFPR_KIND_FLUSH) gate_ok = (phase_d[t] == SFPR_PHASE_DURABLE) && (c_vacked == 8'd0);
        else if (phase_d[t] == SFPR_PHASE_DURABLE) gate_ok = 1'b1;
        else if (early_ok && kind_d[t] == SFPR_KIND_WRITE && !fua_d[t] && phase_d[t] >= SFPR_PHASE_BUFFERED) begin
          gate_ok = 1'b1; early = 1'b1;
        end else gate_ok = 1'b0;
        if (!gate_ok) begin
          cpl_refused = 1'b1; e_gate_refused = 1'b1;
          e_err_tag = t; e_err_phase = phase_d[t]; e_err_req = cpl_status[3:0];
        end else if (!slot_free) begin
          cpl_busy = 1'b1;
        end else begin
          slot_free = 1'b0;
          cqv_d = 1'b1; cqt_d = t; cqs_d = cpl_status;
          cpl_released = 1'b1; e_ack = 1'b1;
          if (early) begin
            vacked_d[t] = 1'b1; cpl_volatile = 1'b1; e_ack_early = 1'b1;
          end else begin
            busy_d[t] = 1'b0;
            if (cpl_status != SFPR_STATUS_SUCCESS) e_abort = 1'b1;
            else if (durable_kind(kind_d[t])) e_ack_durable = 1'b1;
          end
        end
      end
    end

    // ---- power-fault sweep: one tag per cycle, waits for the slot
    if (sweep_start && !sw_act_q) begin
      sw_act_d = 1'b1; sw_done_d = 1'b0; sw_ptr_d = '0;
    end else if (sw_act_q) begin
      if (sw_ptr_q >= (TW+1)'(NTAGS)) begin
        sw_act_d = 1'b0; sw_done_d = 1'b1;
      end else begin
        st = sw_ptr_q[TW-1:0];
        if (!busy_d[st]) begin
          sw_ptr_d = sw_ptr_q + 1'b1;
        end else if (vacked_d[st]) begin
          busy_d[st] = 1'b0; vl = vl + 8'd1; sw_ptr_d = sw_ptr_q + 1'b1;
        end else if (slot_free) begin
          slot_free = 1'b0;
          cqv_d = 1'b1; cqt_d = st;
          if (ack_durable_on_pf && durable_kind(kind_d[st]) && phase_d[st] == SFPR_PHASE_DURABLE) begin
            cqs_d = SFPR_STATUS_SUCCESS; e_ack_durable = 1'b1;
          end else begin
            cqs_d = SFPR_STATUS_ABORT_PWR_LOSS; e_abort = 1'b1;
          end
          e_ack = 1'b1;
          busy_d[st] = 1'b0;
          sw_ptr_d = sw_ptr_q + 1'b1;
        end
      end
    end

    // ---- sub-reset: everything dropped, nothing completed
    if (clear) begin
      for (int i = 0; i < NTAGS; i++) begin
        if (busy_q[i] && vacked_q[i]) vl = vl + 8'd1;
        busy_d[i] = 1'b0; vacked_d[i] = 1'b0; phase_d[i] = SFPR_PHASE_FREE;
      end
      cqv_d = 1'b0; sw_act_d = 1'b0; sw_done_d = 1'b0; sw_ptr_d = '0;
    end
    e_vol_lost = vl;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NTAGS; i++) begin
        busy_q[i] <= 1'b0; kind_q[i] <= '0; fua_q[i] <= 1'b0;
        phase_q[i] <= SFPR_PHASE_FREE; vacked_q[i] <= 1'b0; t0_q[i] <= '0;
      end
      cqv_q <= 1'b0; cqt_q <= '0; cqs_q <= '0;
      sw_act_q <= 1'b0; sw_done_q <= 1'b0; sw_ptr_q <= '0;
    end else begin
      for (int i = 0; i < NTAGS; i++) begin
        busy_q[i] <= busy_d[i]; kind_q[i] <= kind_d[i]; fua_q[i] <= fua_d[i];
        phase_q[i] <= busy_d[i] ? phase_d[i] : SFPR_PHASE_FREE;
        vacked_q[i] <= busy_d[i] && vacked_d[i];
        t0_q[i] <= t0_d[i];
      end
      cqv_q <= cqv_d; cqt_q <= cqt_d; cqs_q <= cqs_d;
      sw_act_q <= sw_act_d; sw_done_q <= sw_done_d; sw_ptr_q <= sw_ptr_d;
    end
  end

  assign cq_valid     = cqv_q;
  assign cq_tag       = cqt_q;
  assign cq_status    = cqs_q;
  assign sweep_active = sw_act_q;
  assign sweep_done   = sw_done_q;
  assign info = {busy_q[info_sel], vacked_q[info_sel], phase_q[info_sel], fua_q[info_sel], kind_q[info_sel]};

`ifndef SYNTHESIS
`ifndef SFPR_NO_ASSERT
  // a durable-kind SUCCESS completion leaves the gate only at DURABLE or as a permitted early ack
  always_ff @(posedge clk) begin
    if (rst_n && cpl_req && cpl_released && !cpl_volatile && cpl_status == SFPR_STATUS_SUCCESS &&
        busy_q[cpl_tag] && !vacked_q[cpl_tag] && durable_kind(kind_q[cpl_tag]) &&
        !(ev_valid != 2'b00) && phase_q[cpl_tag] != SFPR_PHASE_DURABLE)
      $error("sfpr_tag_tracker: SUCCESS released before DURABLE (tag %0d)", cpl_tag);
  end
`endif
`endif
endmodule

`default_nettype wire
