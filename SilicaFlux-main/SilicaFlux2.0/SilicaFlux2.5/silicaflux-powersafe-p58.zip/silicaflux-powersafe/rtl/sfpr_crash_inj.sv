// =============================================================================
// SilicaFlux PowerSafe (Project 58) :: sfpr_crash_inj -- deterministic crash injection
//
// Counts occurrences of ONE crash point and fires on the N-th:
//   * firmware crash points arrive through CP_EVENT (point id, optional tag);
//   * point NAND_OP (31) is counted by the unit itself from nand_start.
// Actions (CI_CTRL.ACTION):
//   CUT_NOW        fire at the triggering event          (between operations)
//   CUT_NEXT_PROG  fire at the next program/erase start  (that operation is torn)
//   CPU_RESET      fire at the event; the controller runs a reset sequence
//   CUT_NEXT_OP    fire at the next NAND op of any kind
// "fire" is a one-cycle pulse on crash_req; the environment (testbench, co-
// simulation harness, or on a bench the power-supervisor test input) turns it
// into the actual power cut.  Deterministic: no randomness inside the unit.
// One-shot: ARM clears when it fires.
// Classification: SYNTHESIZABLE (debug feature; tie arm to 0 in production)
// =============================================================================
`default_nettype none

module sfpr_crash_inj
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  // configuration (CI_CTRL / CI_COUNT write)
  input  wire logic        cfg_we,          // CI_CTRL written
  input  wire logic        cfg_arm,
  input  wire logic [1:0]  cfg_action,
  input  wire logic [4:0]  cfg_point,
  input  wire logic        cfg_tag_en,
  input  wire logic [7:0]  cfg_tag,
  input  wire logic        cnt_we,          // CI_COUNT written
  input  wire logic [31:0] cnt_wdata,
  // occurrences
  input  wire logic        cp_valid,
  input  wire logic [4:0]  cp_point,
  input  wire logic [7:0]  cp_tag,
  input  wire logic        nand_start,
  input  wire logic [1:0]  nand_kind,       // 0 read, 1 program, 2 erase
  // status
  output logic             armed,
  output logic             pending,
  output logic             fired,
  output logic [1:0]       action,
  output logic [4:0]       point,
  output logic             tag_en,
  output logic [7:0]       tag,
  output logic [31:0]      count,
  output logic [31:0]      seen,
  // fire
  output logic             fire,
  output logic [1:0]       fire_action
);
  import sfpr_regs_pkg::*;
  logic        armed_q, pend_q, fired_q, tag_en_q, fire_q;
  logic [1:0]  act_q, fact_q;
  logic [4:0]  pt_q;
  logic [7:0]  tag_q;
  logic [31:0] cnt_q, seen_q;

  wire occ_fw   = cp_valid && (pt_q != SFPR_CP_NAND_OP) && (cp_point == pt_q) && (!tag_en_q || cp_tag == tag_q);
  wire occ_nand = nand_start && (pt_q == SFPR_CP_NAND_OP);
  wire occ      = armed_q && !pend_q && (occ_fw || occ_nand);
  wire hit      = occ && (seen_q + 32'd1 >= cnt_q);
  wire tear_act = (act_q == SFPR_CI_ACTION_CUT_NEXT_PROG) || (act_q == SFPR_CI_ACTION_CUT_NEXT_OP);
  // an occurrence that is itself a NAND start satisfies "next op" at once
  wire pend_ok  = nand_start && ((act_q == SFPR_CI_ACTION_CUT_NEXT_OP) || (nand_kind == 2'd1) || (nand_kind == 2'd2));
  wire now_fire = (hit && (!tear_act || (occ_nand && pend_ok))) || (pend_q && pend_ok);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      armed_q <= 1'b0; pend_q <= 1'b0; fired_q <= 1'b0; tag_en_q <= 1'b0; fire_q <= 1'b0;
      act_q <= '0; fact_q <= '0; pt_q <= '0; tag_q <= '0; cnt_q <= 32'd1; seen_q <= '0;
    end else begin
      fire_q <= 1'b0;
      if (cfg_we) begin
        armed_q <= cfg_arm; pend_q <= 1'b0;
        act_q <= cfg_action; pt_q <= cfg_point; tag_en_q <= cfg_tag_en; tag_q <= cfg_tag;
        if (cfg_arm) begin fired_q <= 1'b0; seen_q <= '0; end
      end else begin
        if (occ) seen_q <= seen_q + 32'd1;
        if (now_fire) begin
          fire_q <= 1'b1; fact_q <= act_q;
          armed_q <= 1'b0; pend_q <= 1'b0; fired_q <= 1'b1;
        end else if (hit && tear_act) begin
          pend_q <= 1'b1;                       // wait for the operation to tear
        end
      end
      if (cnt_we) cnt_q <= (cnt_wdata == 32'd0) ? 32'd1 : cnt_wdata;
    end
  end

  assign armed = armed_q;
  assign pending = pend_q;
  assign fired = fired_q;
  assign action = act_q;
  assign point = pt_q;
  assign tag_en = tag_en_q;
  assign tag = tag_q;
  assign count = cnt_q;
  assign seen = seen_q;
  assign fire = fire_q;
  assign fire_action = fact_q;
endmodule

`default_nettype wire
