# Mutation check

Each mutant plants one deliberate defect, rebuilds, and runs the test meant to notice it.

**20 / 21 mutants caught**, plus mutants that are equivalent by design (listed; not counted):

* **F2** -- a firmware that keeps completing tags during a power fault is harmless because the controller ignores late events for retired tags (T_LATE_FW) and its gate still refuses premature SUCCESS.
* **L7** -- an FTL checkpoint that keeps writing after the warning is stopped in hardware: in STOP nothing may start, in DIAG the budget opens only after the firmware's PF_ACK.  The FTL fix remains for PLP_FLUSH.

A survivor marked *redundant guard* is a defensive check that the tested design cannot reach (L10: the metadata ring never needs to erase into the live region because a checkpoint is forced while enough ring blocks are free); it is reported, counted as not caught, and kept as defence in depth.

| Id | Layer | Planted defect | Test | Verdict | First failure reported |
|---|---|---|---|---|---|
| R1 | RTL | ack gate releases SUCCESS below DURABLE | RTL unit testbench (Verilator) | caught |  |
| R2 | RTL | STOP policy lets programs start after the fault | RTL unit testbench (Verilator) | caught | ERROR 9266000 [pf_stop] STOP: no new NAND op |
| R3 | RTL | admission open during a power fault | RTL unit testbench (Verilator) | caught |  |
| R4 | RTL | power-fault sweep acknowledges every tag with SUCCESS | co-simulation: power_fault | caught | CHECK FAILED firmware/tests/test_recovery.c:545: STOP die-fast trial 1: verification: LBA 83: not its acknowledged version 66 (no command in doubt there); found |
| R5 | RTL | WP# not asserted in PF_SAFE | RTL unit testbench (Verilator) | caught | ERROR 9436000 [pf_stop] WP# asserted |
| R6 | RTL | retention registers cleared by the external reset | RTL unit testbench (Verilator) | caught | ERROR 23946000 [retention] scratch retained |
| R7 | RTL | phase chain not enforced (skips allowed) | RTL unit testbench (Verilator) | caught | ERROR 6546000 [phases] skip -> ERR.PHASE_ILLEGAL |
| R8 | RTL | crash unit fires one occurrence early | RTL unit testbench (Verilator) | caught | ERROR 24926000 [crash] not yet |
| F1 | firmware | firmware reports DURABLE at BUFFERED and completes early (gate cannot know) | co-simulation: crash_points | caught | CHECK FAILED firmware/tests/test_recovery.c:218: [crash_points] dry run: controller ERR bits 0x8 |
| F2 | firmware | EQUIVALENT: firmware keeps completing tags the power-fault sweep owns | co-simulation: power_fault | equivalent (no defect left to observe) |  |
| F3 | firmware | power-fault interrupt never flagged: the firmware's power-fault service never runs | co-simulation: full:power_fault | caught | CHECK FAILED firmware/tests/test_recovery.c:545: DIAG brownout-remount trial 0: recovery failed: -2000 (harness) |
| L1 | FTL | TRIM acknowledged without its journal page | co-simulation: crash_points | caught | CHECK FAILED firmware/tests/test_recovery.c:238: [crash_points] PRE_PROGRAM #309 CUT_NOW: verification: LBA 53: not its acknowledged version 0 (no command in do |
| L2 | FTL | dual checkpoint: previous checkpoint not kept live | co-simulation: ring_invariants, metadata_corruption | caught | CHECK FAILED firmware/tests/test_recovery.c:683: P58 config, newest commit + cut after ring erase, trial 1: rc -7 |
| L3 | FTL | journal mirror not written | co-simulation: metadata_corruption | caught | CHECK FAILED firmware/tests/test_recovery.c:683: P58 config, newest journal page, trial 0: rc 0 verification: LBA 522: not its acknowledged version 0 (no comman |
| L4 | FTL | refused program consumes its page (gap in an open block) | co-simulation: full:power_fault | caught | CHECK FAILED firmware/tests/test_recovery.c:545: STOP brownout-resume trial 0: recovery failed: -8 (metadata inconsistent) |
| L5 | FTL | aborted TRIM record left queued | co-simulation: aborted_trim | caught | CHECK FAILED firmware/tests/test_recovery.c:806: trial 0: verification: LBA 16: not its acknowledged version 13 (no command in doubt there); found zeros 0 (doub |
| L6 | FTL | verify read refused: mapping not committed (RAM / medium disagree) | co-simulation: full:power_fault | caught | CHECK FAILED firmware/tests/test_recovery.c:545: STOP brownout-resume trial 11: verification: LBA 640: not its acknowledged version 11 (no command in doubt ther |
| L7 | FTL | EQUIVALENT: checkpoint keeps writing after the power-fail warning | co-simulation: full:power_fault | equivalent (no defect left to observe) |  |
| L8 | FTL | roll-forward ignores sequence order | co-simulation: crash_points, nand_op_sweep | caught | CHECK FAILED firmware/tests/test_recovery.c:295: cut at NAND op 217: verification: LBA 71: not its acknowledged version 28 (no command in doubt there); found ve |
| L9 | FTL | controller refusal treated like a media error | co-simulation: full:power_fault | caught | CHECK FAILED firmware/tests/test_recovery.c:545: STOP brownout-resume trial 4: a power fault retired 1 healthy block(s) |
| L10 | FTL | REDUNDANT: metadata ring may erase the live region | co-simulation: ring_invariants, metadata_corruption | survived: redundant guard |  |
| L11 | FTL | roll-forward does not check the page CRC (torn pages replayed) | co-simulation: full:nand_op_sweep | caught | CHECK FAILED firmware/tests/test_recovery.c:295: cut at NAND op 10: verification: read error at LBA 56 |
| L12 | FTL | sequence numbers not resumed above the medium after a crash | co-simulation: crash_points | caught | CHECK FAILED firmware/tests/test_recovery.c:238: [crash_points] PRE_PROGRAM #309 CPU_RESET: retained commit status above the recovered medium |
