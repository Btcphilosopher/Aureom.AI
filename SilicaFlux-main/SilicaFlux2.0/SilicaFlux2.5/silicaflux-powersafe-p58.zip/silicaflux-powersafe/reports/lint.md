# Lint

| Tool | View | Parameters | Result | Messages |
|---|---|---|---|---|
| Verilator 5.020 -Wall | simulation | NTAGS=8 PLP=0 | clean | 0 |
| Verilator 5.020 -Wall | simulation | NTAGS=8 PLP=1 | clean | 0 |
| Verilator 5.020 -Wall | simulation | NTAGS=16 PLP=0 | clean | 0 |
| Verilator 5.020 -Wall | simulation | NTAGS=2 PLP=1 | clean | 0 |
| Verilator 5.020 -Wall | synthesis | NTAGS=8 PLP=0 | clean | 0 |
| Verilator 5.020 -Wall | synthesis | NTAGS=8 PLP=1 | clean | 0 |
| Verilator 5.020 -Wall | synthesis | NTAGS=16 PLP=0 | clean | 0 |
| Verilator 5.020 -Wall | synthesis | NTAGS=2 PLP=1 | clean | 0 |
| Icarus Verilog 12 -g2012 | elaboration | PLP=0 | clean | 11 notes |
| Icarus Verilog 12 -g2012 | elaboration | PLP=1 | clean | 11 notes |
| gen_regs.py --check | generated files | - | up to date | - |

Icarus notes are its standard `sorry: constant selects in always_* processes` (the whole vector is put in the sensitivity list; behaviour is unchanged) and `$error` in the simulation-only assertion blocks.
