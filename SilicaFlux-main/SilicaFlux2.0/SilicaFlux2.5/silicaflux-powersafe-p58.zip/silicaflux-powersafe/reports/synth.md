# Synthesis estimate (Yosys generic cells)

_Yosys 0.33 (git sha1 2584903a060); `synth -flatten` + `check -assert`; generic gates, no technology library, no timing.  An implementation-size estimate only._

| Configuration | result | generic cells | flip-flops | latches | log |
|---|---|---|---|---|---|
| NTAGS=8, PLP_PRESENT=0 (delivered) | PASS | 15723 | 3904 | 0 | `build/synth/synth_0.log` |
| NTAGS=8, PLP_PRESENT=1 (research) | PASS | 15724 | 3908 | 0 | `build/synth/synth_1.log` |
| NTAGS=16, PLP_PRESENT=0 | PASS | 21020 | 4570 | 0 | `build/synth/synth_2.log` |

The controller is small next to the storage datapath it supervises: most flip-flops are the 32-bit telemetry counters, the retention registers and the per-tag accept timestamps; they can be trimmed for a production build.  `check -assert` passing means no combinational loops, no multiple drivers and no undriven wires after synthesis.
