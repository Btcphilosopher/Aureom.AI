# Third-party / reused material

| Path | Origin | Modified? | Check |
|---|---|---|---|
| `third_party/silicaflux-v/rtl/common/sfv_common.sv` | SilicaFlux-V common primitives, vendored through `silicaflux-storagecore-p51.zip` → `third_party/silicaflux-controlcore/third_party/silicaflux-v/rtl/common/` | **no** | SHA-256 `4c79395516527ef31bab858a3211965466dcd7c7b9d80d5e6d0a87be0bbc290f` (identical in the three archives that carry it) |
| `firmware/silicaflux_ftl/` | FlashMap FTL, `silicaflux-flashmap-p56.zip` → `firmware/silicaflux_ftl/` | **yes** — extended by P58 (docs/04 §6) | `third_party/p56_baseline/SHA256SUMS.p56-ftl` lists the delivered P56 sources; diff against them to see every P58 change |
| `firmware/silicaflux_ftl/hal/sim/simnand.*` | P56 simulated NAND | one addition: `simnand_reseed()` (test infrastructure) | as above |
| P51 status / error codes, `rb_*` bus convention | `silicaflux-storagecore-p51.zip` docs/MEMORY_MAP.md | re-used values | — |

No licence file exists in the repository (as noted by earlier projects).
