# SilicaFlux PowerSafe · Project 58 — Power-loss protection and storage recovery

**Primary RTL:** [`rtl/silicaflux_storage_recovery.sv`](rtl/silicaflux_storage_recovery.sv) · Aureom.AI | SilicaFlux-STORE

A recovery controller (SystemVerilog) and its firmware (C, ControlCore RV32IM) that let the SilicaFlux storage
controller survive unexpected resets and power interruptions **without losing any write the host was told is
durable** — using software-managed journal recovery, with **no stored energy**. The controller admits commands,
tracks every outstanding command's persistence phase, refuses to acknowledge a write before it is durable, stops all
new NAND work the moment the supply fails, sequences resets and recovery, keeps diagnostics, and injects
deterministic crashes. The firmware layer drives it and the FlashMap FTL (Project 56), which P58 extends and hardens.

> **Status — read first.** Simulation only: Verilator 5.020 / Icarus 12 for the RTL; the C firmware linked with the
> Verilated RTL and a persistent simulated NAND. Nothing ran on an FPGA, silicon or a real NAND device. **No hardware
> power-loss protection is claimed**: `PLP_PRESENT = 0`; the capacitor model is research with placeholder values and a
> qualification checklist. NAND times are NANDLab's illustrative values. Delivered as an archive; nothing was
> committed. See [docs/10_LIMITATIONS.md](docs/10_LIMITATIONS.md).

## Definition of done — met in simulation

*Across reproducible injected crashes, the controller reconstructs a consistent mapping and preserves every
acknowledged durable write.*

| Evidence | Result | Report |
|---|---|---|
| Crash-consistency campaigns: real RTL controller + real firmware + persistent NAND; after **every** crash a full-device check against an independent reference model (acknowledged data present; unacknowledged commands old-or-new per logical page; stable afterwards) | **15 / 15 tests PASS, 3 418 system runs, 4 002 injected crashes recovered, 0 violations** (4 569 checks) | [reports/TESTS.md](reports/TESTS.md) |
| The brief's eight crash locations (and 11 more) × CUT_NOW / torn-next-program / CPU reset × sampled occurrences, on a full device with GC, static wear levelling, TRIM, FLUSH, checkpoints | every cell fired and passed | `crash_points`, `gc_wl`, `full_device` |
| Power cut at each of **1 200** consecutive NAND operations | 1 200 / 1 200 | `nand_op_sweep` |
| Crashes **inside** recovery, nested up to 3 deep (power or CPU) | 80 / 80 trials (79 with nested crashes) | `repeated_recovery` |
| 160 randomized runs: 6 geometries, GC / WL / checkpoint policies, NAND program / erase failures and read flips, 639 crashes | 160 / 160 | `random` |
| Power-fault warning → STOP / DIAG policy → loss (fast / slow) or brown-out (remount / resume), firmware learning late; 4 seeds | **768 / 768**; STOP: **0** program/erase started in a power-fault state; DIAG record recovered **96 / 96** | `power_fault`, [reports/extra_seeds.log](reports/extra_seeds.log) |
| Metadata corruption (one damaged live page; double fault: newest commit + cut while the ring recycles a block) — P58 vs P56 configuration, 4 seeds | P58 **all pass**; P56: damaged journal page 14 / 80 (the rest: trimmed data came back), double fault 83 / 240 (the rest refuse to mount, ENOFS) | `metadata_corruption` |
| Defence in depth: firmware that requests SUCCESS before durability | 71 premature acknowledgements refused by the controller; no data lost under crashes | `gate_defense` |
| RTL unit testbench (17 tests, scoreboard checks every completion) | **PASS** on Verilator (PLP 0 / 1 × 3 seeds) and Icarus (PLP 0 / 1) | [reports/sim/](reports/sim/) |
| P56 FTL suite, unchanged tests | 27 / 27 with and without the P58 flags | `reports/ftl_p56_suite*.log` |
| ASan + UBSan | 15 / 15, 0 reports | [reports/sanitize.log](reports/sanitize.log) |
| Mutation check: 23 planted defects in RTL, firmware and FTL | **20 / 21 caught**, 2 equivalent by design, 1 redundant guard survives (reported) | [reports/mutation.md](reports/mutation.md) |
| Lint / synthesis | Verilator `-Wall` clean (2 views × 4 parameter sets), Icarus elaborates, Yosys: 15.7 k generic cells, 0 latches | [reports/lint.md](reports/lint.md), [reports/synth.md](reports/synth.md) |

## What the campaigns found (and P58 fixed)

Five latent FTL hazards that appear once a controller can refuse NAND operations while the system stays powered
(refused program left an erased gap; aborted TRIM resurrected later; refused read treated as media error; refused
read-back split RAM from medium; checkpoint continuing after the warning); two protocol issues exposed by interrupt
latency (`PF_ACK` for the DIAG budget, late completions); a stale interrupt across reset; run-time read-only
degradation not reported to the controller; and in the P56 configuration, a single damaged journal page or a
recycled previous checkpoint losing data — fixed by the journal mirror and the dual checkpoint.
[docs/08 §3](docs/08_VERIFICATION.md), [docs/04 §5](docs/04_PERSISTENT_METADATA.md).

## Key measurements (modelled)

| | |
|---|---|
| Write completion latency, full 16 MiB device, p50 / p99 | 4.27 / 10.89 ms (P56 baseline 4.01 / 10.46 ms; difference = write verify) |
| Metadata programs per host page (P56 → P58) | 0.060 → 0.088 (journal mirror); journal pages per 1 000 host pages 29 → 61 |
| Unclean recovery, P51 device, checkpoint interval 2 / 8 / 32 | 11.7 / 13.7 / 22.8 ms (196 / 248 / 482 NAND ops); clean mount ≈ 4 ms |
| Unclean recovery, 16 MiB device, interval 2 / 8 / 32 | 56 / 65 / 87 ms |
| Capacity cost of the dual checkpoint | P51 98.1 %, 16 MiB 99.1 %, 512 MiB 99.8 % of P56 user capacity |
| Hold-up energy needed for correctness (STOP) | **0** — PLP write cache would need 0.04-1.2 J (estimates, docs/07) |
| Firmware (RV32IM, `-Os`) | FTL + PowerSafe layer 37.0 KB text, 0 data, 0 bss |

Details: [docs/09_PERFORMANCE.md](docs/09_PERFORMANCE.md), [reports/perf/PERF.md](reports/perf/PERF.md),
[reports/plp/PLP_MODEL.md](reports/plp/PLP_MODEL.md).

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit (FTL, NAND model, write buffers, DMA, PowerClock, ControlCore, Flush, journal, reset sequencing) | [docs/00_AUDIT.md](docs/00_AUDIT.md) |
| 2 | Write persistence model: accepted … acknowledged; no durable ack before NAND | [docs/02_PERSISTENCE_MODEL.md](docs/02_PERSISTENCE_MODEL.md); enforced by the gate (`sfpr_tag_tracker.sv`) |
| 3 | Recovery controller: power-fault input, admission, outstanding tracking, persistent commit status, recovery mode, error/status registers, reset & recovery FSM | [rtl/](rtl/), [docs/03_RECOVERY_CONTROLLER.md](docs/03_RECOVERY_CONTROLLER.md), [docs/REGISTERS.md](docs/REGISTERS.md) |
| 4 | Persistent metadata: versioned checkpoints, journal, generations, commit markers, integrity, scanning; torn metadata | [docs/04_PERSISTENT_METADATA.md](docs/04_PERSISTENT_METADATA.md), `firmware/silicaflux_ftl/` |
| 5 | Deterministic crashes at the eight locations, restart, verify | `sfpr_crash_inj.sv`, [docs/05_CRASH_INJECTION.md](docs/05_CRASH_INJECTION.md), `crash_points` |
| 6 | Power-loss behaviour: stop new work, in-flight policy, diagnostics, metadata protection, no energy assumed | [docs/06_POWER_FAULT_POLICY.md](docs/06_POWER_FAULT_POLICY.md), `power_fault` |
| 7 | Optional capacitor PLP research model (energy, hold-up voltage, efficiency, shutdown power, flush time, temperature, ageing) | [plp_model/](plp_model/), [docs/07_PLP_RESEARCH.md](docs/07_PLP_RESEARCH.md) |
| 8 | Recovery correctness invariant and contract | [docs/01 §1, §7](docs/01_SPECIFICATION.md), [docs/02 §4-5](docs/02_PERSISTENCE_MODEL.md), `firmware/tests/rrm.c` |
| 9 | Crash-consistency tests: persistent NAND, fault injection, independent reference, random workloads, repeated recovery, metadata corruption, full storage, GC / WL | [docs/08_VERIFICATION.md](docs/08_VERIFICATION.md), `firmware/tests/` |
| 10 | Recovery time, completion latency, journal overhead, metadata WA, checkpoint frequency, capacity | [docs/09_PERFORMANCE.md](docs/09_PERFORMANCE.md) |
| 11 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_storage_recovery.sv` | [rtl/silicaflux_storage_recovery.sv](rtl/silicaflux_storage_recovery.sv) + `sfpr_tag_tracker.sv`, `sfpr_crash_inj.sv`, generated `sfpr_regs_pkg.sv`; [tb/tb_storage_recovery.sv](tb/tb_storage_recovery.sv) |
| FTL persistence integration | `firmware/silicaflux_ftl/` (P56 + P58 changes, docs/04 §6); `firmware/powersafe/` (`sfps`) |
| Crash-injection framework | `rtl/sfpr_crash_inj.sv`, `firmware/crashinj/`, `cosim/` |
| Recovery reference model | `firmware/tests/rrm.c` |
| Power-fault tests | `firmware/tests/test_recovery.c` (`power_fault`, `aborted_trim`, `cpu_reset`, …), RTL tests `pf_*` |
| Recovery telemetry | controller `T_*`, `RET_*`, `COMMIT_SEQ` registers; firmware `sfps_tel_t`; FTL `sfftl_stats` / `sfftl_diag` (persistent) |
| Design specification | [docs/01_SPECIFICATION.md](docs/01_SPECIFICATION.md) and docs/00-10, [docs/REGISTERS.md](docs/REGISTERS.md) |

## Quick start

Tools (Ubuntu 24.04): `verilator` 5.020, `iverilog` 12, `yosys` 0.33, `gcc-riscv64-unknown-elf` 13.2, `gcc`, Python 3.

```bash
sudo apt-get install -y verilator iverilog yosys gcc-riscv64-unknown-elf
```

```bash
make quick
```

```bash
make test
```

```bash
make tb tb-iv lint
```

`make test` runs the full campaigns (≈ 3 min); `make sanitize`, `make perf`, `make plp`, `make synth`, `make fw`,
`make mutation` (≈ 12 min), `make ftl-test`; `python3 scripts/report.py` regenerates `reports/TESTS.md`.
`./build/test_recovery --seed N <test>` reproduces any campaign; `make regs` regenerates the register files.

## Layout

```
rtl/            controller RTL, generated register package, files.f
tb/             RTL unit testbench
cosim/          Verilator C API (sfpr_cosim)
firmware/       silicaflux_ftl/ (P56+P58)  powersafe/ (sfps)  crashinj/ (sfci)  tests/  fw/ (RV32 build)
plp_model/      capacitor hold-up research model + placeholder inputs
config/         register map source (sfpr_regmap.py)
scripts/        gen_regs, lint, synth, mutation, report
third_party/    sfv_common.sv (unmodified), P56 baseline hashes, provenance
docs/           00 audit … 10 limitations, REGISTERS.md
reports/        TESTS.md, campaigns.csv, logs, perf/, plp/, sim/, lint, synth, mutation
```
