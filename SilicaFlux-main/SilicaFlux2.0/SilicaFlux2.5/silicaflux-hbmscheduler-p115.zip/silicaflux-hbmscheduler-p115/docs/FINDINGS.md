# What the verification found (and fixed) along the way

Honest record of defects found by the bench, the checkers, the tools and an independent review, in the order they appeared. They are the reason the corresponding checks exist.

## Design (RTL) defects found by the bench

| # | defect | found by | fix |
|---|---|---|---|
| 1 | a **late backend response** that arrived while a timed-out slot was still waiting for its (error) delivery was counted as a spurious response and the slot was then parked as a zombie that would never be reclaimed | scenario `timeout` (sticky `err_spurious_o`) | `late` flag in `sf_hbm_trk_slot`: the late answer is absorbed and the slot is freed at delivery |
| 2 | the backend adapter kept **presenting a command / write beat for one cycle after `mc_init_done` had already dropped** (it reacted one cycle late) | the SFMC protocol checker in scenarios `fault` / `fatal` | `mc_cmd_valid` / `mc_wd_valid` are gated combinationally with the fault condition; the checker waives rule C1 only in a fault cycle |
| 3 | the **comparator chains of the scheduler** made the pick logic 280 generic gate levels deep | `scripts/synth.py` (`ltp`) | balanced-tree selector `sf_hbm_maxsel` (171 levels, 25 % fewer cells); behaviour is cycle-identical (checked against the linear version on the policy scenarios) |
| 4 | the first **monolithic tracker** could not be elaborated by Yosys in reasonable time (> 5 min for the front end alone) | Yosys | restructured into per-slot / per-source modules (16 s) |

## Model and bench defects (not RTL bugs, but they would have produced false passes or false failures)

| # | defect | found by | fix |
|---|---|---|---|
| 5 | the **memory model dropped a command or write beat** whose `ready` had already been driven high when a hang froze it (the DUT saw a handshake, the model ignored it) | scenario `timeout`: hundreds of data mismatches on one configuration | handshakes are accepted before the freeze branch |
| 6 | the model memory was **not re-initialised between scenarios** while the reference was | `rand_mixed` after `seq` | `bd_init` backdoor pulse in `begin_test` |
| 7 | performance-counter cross-check compared cumulative wire counts with counters that restart each scenario | `seq` | per-scenario baselines |
| 8 | a timeout of 400 cycles was shorter than the legitimate backend latency of a saturated single lane | `timeout` on the 1-channel build | timeout 1500 during the hang window only, disabled afterwards |
| 9 | the poison ranges of `be_err` were not reached under map modes other than 0 | `ch4` (bank-interleaved map) | lane-local addresses are generated through the inverse of the independent mapper |
| 10 | the **arbiter-priority** assertion measured accept-to-response latency, on which a lane-ingress priority has no effect, and in the default configuration the system is limited by the sources' outstanding window, not by arbitration | `arb_prio` | end-to-end latency (offer to response) + arbitration-loss counter `S_ARB_LOSS`; asserted only where lane capacity is below the outstanding window |
| 11 | the benchmark **buffers were all power-of-two aligned**, so five sequential streams fought for bank 0 (row-conflict rate 99 %) | first `bench_seq_rd` run | staggered layout is the default workload, the aligned layout is kept as `bench_seq_rd_aligned` (a real pathology that the hashed map and the policies address) |

## Defects found by the independent review (the regression had passed 39 / 39 with all of them present)

| # | defect | how it became visible | fix |
|---|---|---|---|
| 12 | adapter outstanding counter leaked one count whenever a read last-beat and a write response coincided | new end-state check `idle_o` at the end of every scenario (fails on the pre-fix RTL with the jittered backend) | decrement by both completions |
| 13 | a timed-out slot waiting for delivery ignored a lane flush and became a permanent zombie | new scenario `timeout_flush` (pre-fix RTL fails) | flush marks it `late` |
| 14 | FCFS deadlocked once the age counters of dependent entries saturated and tied | new scenario `fcfs_saturate` (pre-fix RTL deadlocks) | blocked oldest entry is bypassed by the oldest issuable one |
| 15 | per-source queue-wait count only 2 bits (wrong with >= 4 lanes); foreign tag sources not counted; unchecked link-timer width | by inspection (no stimulus reproduced the first) | widened / counted / elaboration check |

Details, the reviewer's list of items it found correct, and the three items documented instead of changed: `reports/REVIEW.md`.

## Bench gap found by mutation testing

| # | gap | how it became visible | fix |
|---|---|---|---|
| 16 | **nothing checked the ORDER in which commands reach the backend.** A mutant that made strict FCFS pick the younger of the two queue heads passed all 39 regression runs: data, responses and counters are correct under any issue order, so only throughput and latency would show it | first mutation run: 27 of 28 mutants killed, `fcfs_youngest_first` **survived** (`reports/mutation_first_run.md`) | new scenario `fcfs_order` (per-lane acceptance FIFO in the bench compared with the commands on the wire, on hazard-free traffic); the mutant now fails it at cycle 74 and the unmutated RTL passes it (1500 commands per run) |

The same blind spot applies to the other policies: their *selection* is not asserted either, only their effects on throughput are measured in `reports/BENCHMARKS.md`. That is stated in `docs/LIMITATIONS.md`.

## Policy-study lessons (see `reports/BENCHMARKS.md`)

* A reordering policy's benefit depends on parameters that the first measurement did not respect: with the default age limit (256) the starvation override fired on almost every request under saturation and the policies collapsed to oldest-first. The first measurement is kept (`reports/BENCHMARKS_age256_first_measurement.md`) next to the tuned one.
* FR-FCFS loses 31 % to FCFS on friendly sequential streams because oldest-hit-first clusters the column commands in one bank group (70 % of adjacent commands in the same group vs 20 % under FCFS: the column spacing doubles from tCCD_S to tCCD_L); row hits are identical. The bank-aware tiers fix the clustering (15 %) but still trail FCFS by ~12 %.
* The hypothesis "deferring a source's oldest request stalls it" was tested with a bypass cap and **refuted**; the cap stays in the RTL, off.
