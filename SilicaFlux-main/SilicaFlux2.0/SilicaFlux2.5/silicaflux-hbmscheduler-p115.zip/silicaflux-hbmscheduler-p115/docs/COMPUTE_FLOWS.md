# Compute request flows (traffic models) and how stalls are measured

**Honest scope.** The brief asks to *connect* TensorCore operand transfers, Vector Engine traffic, StreamDMA, ControlCore requests and shared-SRAM staging buffers and to *measure stalls from real
request flows*. The repository audit (`AUDIT.md`) found that none of those blocks has an RTL path to an HBM-style memory port today (TensorCore reaches memory only through the TC07 SFB2 adapter, VectorCore has no wide
LSU, StreamDMA speaks AXI4, ControlCore speaks single-outstanding SFB2). Connecting them needs the bridges listed in `HARDWARE_INTEGRATION.md` section 4, which are **not built here**.
What *is* delivered: the scheduler's five source ports (the binding in `sf_hbm_defs.svh`), and **closed-loop traffic models** in the system bench whose parameters are taken from the documented behaviour of those blocks. They
drive the real scheduler RTL through the real source ports, so the stalls they show are the stalls of this scheduler against the behavioural memory - not of the real compute blocks.

| source | model (`+TEST=`) | taken from | what it does |
|---|---|---|---|
| 0 TENSOR | `bench_tensor`, `bench_tensor_alone`, `bench_system` | TC07 `tensor_dma_adapter` (ping-pong tile sets FREE / FILLING / READY / IN_USE, prefetch), TensorScratch (4 KiB A + 4 KiB B per set) | **tile-fetch flow**: tile = 128 granules (4 KiB); two buffers; the fetch engine reads the next tile into the free buffer while the *consumer* computes on the other for `+TCOMP` cycles (default 512); a result tile of 16 granules is written back after each tile; 24 tiles. A buffer is not refilled until its compute ended (ownership rule). **Starvation = cycles the consumer is idle waiting for a tile** (after the first tile started), plus the longest idle run |
| 1 VECTOR | `bench_vector` (src 1, 2, 4 patterns), background in `bench_system` | VectorScratch (`VEC_BYTES` lines, unit-stride / strided / gather) | unit-stride stream with 30 % writes; stride-17 stream; indexed gather (runs of 1-4 granules at random places) |
| 2 STREAMDMA | `bench_dma_copy`, background in `bench_tensor` / `bench_system` | P103 `sf_stream_dma` (read stream + write stream, bursts) | copy flow: read chunk i of the source stream, write chunk i of the destination stream (alternating requests, sequential) |
| 3 CONTROL | `bench_ctrl_probe`, `bench_system` | ControlCore `cc_sfb_gate` (sparse single-outstanding accesses) | random single-granule accesses at ~3 % of the cycles, ids reused |
| 4 CLOUD | background in `bench_tensor` / `bench_ctrl_probe` / `bench_system` | cloud DMA / DPU style small-block traffic | random granules, 60 / 40 read / write |

**Shared SRAM staging buffers.** In every flow the HBM port is the *fill / drain* side of a staging buffer (TensorScratch A / B sets, VectorScratch regions, StreamDMA's data buffer). The tensor model includes the
buffer-ownership rule (a set cannot be refilled while the consumer holds it), so staging back-pressure shows up as consumer idle time; the other flows model the staging buffers as always able to absorb data.

## What is measured (all from RTL counters and bench-side timestamps; per source)

* accepted requests, bytes, **end-to-end latency** (offer at the port -> response) mean / p50 / p99 / max, **ingress stall cycles** (request offered, not accepted), arbitration losses, ROB stall cycles / reordered responses;
* tensor consumer idle cycles and longest idle run (the starvation measure);
* the same for the control probes under background load, with and without arbiter priority (`+PRIO=1`: control first, tensor second; `+PRIO=2`: tensor first).

Results: `reports/BENCHMARKS.md`, sections "Per-source view" and "Tensor starvation". Run any of them with e.g.

```bash
build/base/simx +TEST=bench_system +POLICY=3 +N=2000 +TCOMP=512 +SEED=1
```
