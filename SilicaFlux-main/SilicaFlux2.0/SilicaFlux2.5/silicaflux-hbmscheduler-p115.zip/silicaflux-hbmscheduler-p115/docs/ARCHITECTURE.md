# Architecture

> **Scope.** HBMScheduler is the *transaction scheduler and re-ordering layer* that sits between several memory clients and one memory
> controller per channel. It is **not** an HBM controller or PHY: it contains no DRAM command sequencing, no refresh scheduling, no training and no
> signalling. Everything below the SFMC boundary belongs to a technology-specific controller / PHY IP (`HARDWARE_INTEGRATION.md`).

## 1. Data path

```
 source ports (flat, one slice per source; default 5: TENSOR VECTOR STREAMDMA CONTROL CLOUD)
      |  req_valid/ready  we  id  addr  wdata[LINE_W]  wstrb[BURST_BYTES]        rsp_valid/ready  id  we  data  status[3:0]
      v
 ┌─ per source ──────────────────────────────────────────────┐
 │ sf_hbm_address_map   addr -> lane, lane-local addr {row|bg|bank|col|off}, in_range, aligned
 │ sf_hbm_req_check     range / alignment / permission window / write strobe        -> status
 └───────────────────────────────────────────────────────────┘
      |  accepted?  = (valid) & (tracker slot free) & (lane arbiter grant | rejected request)
      v
 sf_hbm_response_tracker   allocate slot at ACCEPTANCE: tag = {source, slot}; order matrix; read-data store; timeout / zombie / flush
      |                                         ^  issue / read beats / write responses / flush  (per lane)
      v                                         |
 ┌─ per lane (NUM_CH x NUM_PC) : sf_hbm_lane ───┴────────────────────────────────────────────────────────────┐
 │ sf_hbm_channel_arbiter  (round robin | priority classes with aging)  one grant = one acceptance            │
 │ sf_hbm_read_queue  / sf_hbm_write_queue   random-access entries, age counters, RAW / WAR / WAW masks        │
 │ sf_hbm_scheduler   policy 0 FCFS | 1 read priority + write drain | 2 FR-FCFS | 3 bank-aware, + age override │
 │ sf_hbm_backend_adapter  link FSM, command FIFO, write-data FIFO + beat serialiser, outstanding limit        │
 └───────────────────────────────────────────────────────────────────────────────────────────────────────────┘
      |  SFMC (+ SFMC-X sideband)   mc_cmd / mc_wd / mc_rd / mc_wr / mc_init_done / mc_fatal / mc_busy / ECC flags
      v
 controller adapter (NOT in this project)  ->  HBM controller + PHY  (or  model/sf_hbm_mem_model.sv in simulation)
 sf_hbm_perf: counters for every handshake / stall   (perf_sel / perf_data / perf_clr)
```

One **lane** is the scheduling domain: a (logical channel, pseudo-channel) pair. Lane index = `channel * NUM_PC + pseudo_channel`.
The shipped default is **two logical channels, one pseudo-channel each = two lanes**, on the behavioural model.

## 2. Modules

| file | role | notes |
|---|---|---|
| `rtl/sf_hbm_defs.svh` | constants: status codes, policies, map modes, profile limits, link states, perf-counter indices | `define macros only (repository coding rules) |
| `rtl/sf_hbm_address_map.sv` | combinational address decode; elaboration-time geometry check | `docs/ADDRESS_MAP.md` |
| `rtl/sf_hbm_req_check.sv` | request validation | ST_ERR_ADDR / ALIGN / PERM / STRB |
| `rtl/sf_hbm_channel_arbiter.sv` | per-lane source arbiter | RR or priority + aging; grant == acceptance |
| `rtl/sf_hbm_read_queue.sv` / `sf_hbm_write_queue.sv` | per-lane queues | random access; write queue holds data + strobes |
| **`rtl/sf_hbm_scheduler.sv`** | **per-lane scheduling policy (primary RTL)** | `docs/SCHEDULING.md` |
| `rtl/sf_hbm_backend_adapter.sv` | the only controller-facing block | SFMC master, link FSM, width conversion |
| `rtl/sf_hbm_response_tracker.sv` | outstanding-transaction table, re-ordering buffer: wrapper of `sf_hbm_trk_src` (one table slice per source) | `docs/ORDERING.md` |
| `rtl/sf_hbm_trk_src.sv` / `rtl/sf_hbm_trk_slot.sv` | one source's slice (allocation, oldest-eligible pick, registered response channel, events) / one slot (state, tag match, order-matrix row, read-data store) | split out of the first monolithic tracker, which Yosys could not elaborate in reasonable time |
| `rtl/sf_hbm_maxsel.sv` | balanced-tree "max key among valid" selector used by the scheduler | ties -> lower index, same as a left-to-right scan |
| `rtl/sf_hbm_lane.sv` | integration of one lane | optional in-flight hazard hold (`BE_ORDER_SAFE = 0`) |
| `rtl/sf_hbm_perf.sv` | 48-bit counter bank | `docs/PERFORMANCE.md` |
| `rtl/sf_hbm_sched_top.sv` | integration top | `sf_hbm_scheduler.sv` is the policy core; the **top** is `sf_hbm_sched_top` |
| `model/sf_hbm_mem_model.sv` | timing-aware behavioural SFMC slave (simulation only) | `docs/TIMING_MODEL.md` |
| `tb/` | self-checking benches, SFMC protocol checker, address-map unit bench | `docs/VERIFICATION.md` |

## 3. Interfaces

**Source port (per source).** One access granule per request: `BURST_BYTES = DATA_W/8 * BURST_LEN` bytes at a granule-aligned byte address
(default 32 B). `req_*` and `rsp_*` are independent ready/valid channels. `wdata` carries the whole granule (`LINE_W` bits), `wstrb` one bit per byte
(partial writes are supported and reach the backend as per-beat strobes; a write with `wstrb == 0` is rejected). `id` (`ID_W` bits) is returned unchanged.
`status` (4 bits): `0 OK`, `1 OK_ECC_CE`, `2 ERR_ADDR`, `3 ERR_ALIGN`, `4 ERR_PERM`, `5 ERR_BE`, `6 ERR_ECC_UE`, `7 ERR_DBUS`, `8 ERR_TIMEOUT`,
`9 ERR_FLUSH`, `10 ERR_STRB`. Status `>= 2` is an error and the response data is forced to zero.
Multi-granule transfers are expressed as several requests (the AXI4 / SFB2 bridges split bursts, `HARDWARE_INTEGRATION.md`).

**Backend (per lane): SFMC.** The generic memory-controller contract of the MemoryBridge (P24, `docs/MC_INTERFACE.md`, rules C1-C11), master side. Commands carry
`len = BURST_LEN-1`, data is `DATA_W` bits per beat. Optional SFMC-X sideband (tie to 0 when absent): `mc_busy` (refresh / maintenance in progress),
`mc_rd_ce / mc_rd_ue / mc_rd_dbus` (ECC corrected, uncorrectable, data-bus error, aligned with a read beat), `mc_ev_hit / miss / conf` (row-buffer events for the counters).

**Configuration (flat inputs, quasi-static).** `cfg_policy`, `cfg_wr_hi / cfg_wr_lo` (write-drain watermarks), `cfg_age_limit`, `cfg_idle_wr`, `cfg_busy_cyc`
(bank-busy hint), `cfg_arb_mode / prio / age`, `cfg_timeout`, `cfg_out_limit` (per-source outstanding limit), permission windows (`cfg_perm_en`, `cfg_win_*`),
`cfg_link_retry`. A CSR block that drives these is **not** part of this project.

## 4. Identity and ordering in one paragraph

A request is *accepted* in the cycle of its `req` handshake; that cycle defines its position in the global order. A tracker slot is allocated in the
same cycle and the transaction **tag `{source, slot}`** is what travels to the backend and back: a response is matched by tag, lane and kind, so a response can never
be attributed to a different request. The tag of a live transaction is unique and is not reused until the response has been delivered (or, after a timeout, until the late
response has arrived). Responses leave each source **in acceptance order** (`ORDER_MODE = 0`) or, AXI-like, in order only among equal ids (`ORDER_MODE = 1`), whatever order
the backend completes them in. Accesses to the same granule take effect in acceptance order. Details and the proof obligations: `docs/ORDERING.md`.

## 5. Clock, reset, readiness

Single clock domain (`clk`), active-low reset `rst_n` (assumed synchronised outside). Per lane the adapter holds the controller in reset for `RST_HOLD` cycles, waits for
`mc_init_done` (`CAL_TIMEOUT` optional) and only then issues. If the controller drops `mc_init_done` or raises `mc_fatal` while READY the lane goes to FLUSH: every
transaction of that lane that was already issued is answered with `ERR_FLUSH`, queued requests wait, the controller is reset and the lane recovers on its own. A controller
in another clock domain needs a P24-style asynchronous bridge between the adapter and the controller (documented, not built).

## 6. Parameters (top)

`NUM_SRC, NUM_CH, NUM_PC, PROFILE, ADDR_W, DATA_W, BURST_LEN, BG_W, BANK_W, ROW_W, COL_W, MAP_MODE, ID_W, RQ_DEPTH, WQ_DEPTH, OUT_PER_SRC, LANE_OUT, WD_DEPTH, CMD_DEPTH, AGE_W,
BUSY_W, NUM_WIN, ORDER_MODE, BE_ORDER_SAFE, RST_HOLD, CAL_TIMEOUT, SHADOW_CLR_BUSY` - see the header of `sf_hbm_sched_top.sv`. Unsupported combinations are rejected at
elaboration (`reports/regression.md`, "Illegal geometry").
