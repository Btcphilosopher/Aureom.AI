# Phase 1 - Repository audit

Scope: the `Aureom.AI` repository, working tree of the session branch. **No file of the repository was modified and nothing was committed or
pushed** (the deliverable is this zip). Method: every module below was extracted into a scratch directory and its README / interface /
RTL header read; tools were installed (`verilator 5.020`, `iverilog 12.0`, `yosys 0.33` from the distribution) and each claim in "Reused" was
turned into something this project actually does. Where a module was only *listed* (not read) the table says so.

## 0. Layout facts

* 748 non-`.git` files. The SilicaFlux tree is mostly **archives**: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` holds 155 entries, ~140 of them
  `silicaflux-*.zip` module packs. A handful of loose `.sf` files (`memory_controller.sf`, `scheduler.sf`, `noc_interconnect.sf`, ...) sit beside them.
* `.sf` is SystemVerilog text with a label (an earlier audit in `silicaflux-hbmcore` re-verified that with Verilator; it was **not** re-tested here).
* **RTL coding rules of the repository** (stated in the READMEs of P24 / P103 / P107): flat ports, `define headers, **no structs, interfaces or
  package imports in synthesizable RTL**, Verilator 5.020 + Icarus 12 + Yosys 0.33. P115 follows them; the toolchain here is the same
  version set.

## 1. What was inspected and what it means for this project

| item | where | read / inspected | finding | used for |
|---|---|---|---|---|
| **Existing HBM work** (`silicaflux-hbmcore`) | `silicaflux-hbmcore.zip` | README, AUDIT, SCHEDULER, file list | a complete HBM4-*style* **controller** (pseudo-channel scheduler, bank FSMs, timing engine, DRAM model, cocotb / formal, 24 RTL files). All timing profiles `HYPOTHETICAL_SIM`; no JEDEC claim. **Its regression was not re-run here.** | positioning: P115 is the *multi-source transaction scheduler and re-ordering layer* **above** a controller (and a behavioural controller stand-in), not a second controller. Its honesty rules (hypothetical profiles, no compliance claim, modelled-not-measured numbers) are adopted. No RTL was copied. |
| **External memory bridge** (P24) | `silicaflux-extmem-bridge-p24.zip` | README, `docs/MC_INTERFACE.md`, `docs/ROADMAP_DDR_HBM.md`, `extmem_defs.svh`, top-level ports, `extmem_sim_mc.sv` header | defines **SFMC**, the generic memory-controller contract (cmd / write-data / read-data / write-response, rules C1-C11, `mc_init_done` / `mc_fatal`), a scheduler, ROB and tracker for ONE upstream port, and a simulated controller. States plainly that **no vendor controller exists** and HBM is "research". | **the backend interface of every lane is SFMC** (+ an optional sideband), so one controller adapter can serve both P24 and P115; rule C9 (overlapping accesses take effect in acceptance order) is the hazard contract; the link FSM (reset / calibrate / ready / flush) follows its states; AXI4 adapter notes are reused as the integration path. |
| **StreamDMA** (P103 r2) | `silicaflux-streamdma-p103-r2.zip` | README + `sf_stream_dma` port list | AXI4-style master: `ar_/r_/aw_/w_/b_` with ids, `BURST_LENGTH` (default 16) x `DATA_WIDTH` (128), `MAX_OUTSTANDING_READS/WRITES` 1..8, 48-bit counters. Verified (by its own README) against MemoryMatrix. | the **StreamDMA source** is modelled as a copy flow (sequential read stream + sequential write stream, bursts); the AXI4 -> granule bridge needed to attach the real engine is described in `HARDWARE_INTEGRATION.md` (not built). |
| **TensorCore operand transfers** (TC07 `tensor_dma_adapter`) | `silicaflux-tensorcore07.zip` | README, parameter list | the real TensorCore <-> external-memory path: 2-D strided transfers over **SFB2** (32-bit words), `MAX_OUT` = 4 transactions in flight, double-buffered tile sets (FREE / FILLING / READY / IN_USE) with next-tile prefetch; output buffer back to memory. **There is no TensorCore RTL that talks to memory directly.** | the **TENSOR source** is a tile-fetch flow with ping-pong buffers and a compute consumer (`bench_tensor_*`): "tensor starvation" = consumer idle cycles. Not an RTL integration. |
| **TensorScratch** (P75) | `silicaflux-tensorscratch-p75.zip` | README, `sf_ts_dma_port` ports | DMA **fill port** `dma_req_*` (word wide, 8-bit tag, per-byte strobes), A/B operand sets of 4 KiB, ping-pong ownership, bank-conflict / compute-starvation events | tile size (4 KiB A + 4 KiB B per set = 256 granules of 32 B) and the event vocabulary of the starvation metric. Not instantiated. |
| **VectorScratch** (P76) | `silicaflux-vectorscratch-p76.zip` | README, integration doc | wide-vector SRAM, `VEC_BYTES` = 16 / 32 / 64, per-byte mask, strided / gather / scatter option, in-order completion, DMA port. Documents that the tile top-level integration **was not done** and no wide-port LSU exists. | VECTOR source = unit-stride / strided / gather line streams (`bench_vector_*`). Not instantiated. |
| **ControlCore** (P21) | `silicaflux-controlcore.zip` | README, `cc_sfb_gate` header | RV32 control processor; its external data port is an **SFB2** pass-through gate: **one transaction at a time**, 32-bit words, refusal answered with `rsp_error`. | CONTROL source = sparse, single-outstanding, latency-critical accesses (`bench_ctrl_probe`); error-response semantics (error + zero data) match the tracker's. |
| **Performance counters** (Module 07) | `silicaflux-hpc-m07-perf-counters.zip` | README | event-at-handshake counters, 64-bit values, SUM / MAX kinds, snapshot, sticky overflow, off-chip derivation of metrics. | `sf_hbm_perf` uses the same philosophy (raw counts in RTL, derived metrics in `scripts/gen_report.py`; MAX counters; documented wrap). |
| **MemoryCore / SRAM, MemoryMatrix** | `silicaflux-memorycore-sram.zip` (+ copies inside P101/P103) | **file inventory only** | on-chip scratchpad controllers; not a DRAM path. | not used (the "shared SRAM staging buffer" appears only as the *client* of the DMA flows; see section 3). |
| **DataFabric / NoC v2** | `silicaflux-datafabric-noc-v2.zip` | **file inventory only**; contract taken from the hbmcore audit and P24 | SFB2 / NoC packets are **32-bit addressed**; memory-target NI exists. | HBM windows need an address-extension register or a wider path (listed as a blocker). |
| **Existing `.sf` scheduler / memory controller** | `scheduler.sf`, `memory_controller.sf` | headers only (as reported by the hbmcore audit) | `scheduler.sf` is the *dataflow token* scheduler, `memory_controller.sf` the *on-chip scratchpad* controller - neither is a DRAM transaction scheduler. | nothing reusable; name collision avoided (`sf_hbm_*`). |

## 2. Gaps the audit found (they shape the design)

1. **No HBM controller or PHY IP, no JEDEC / vendor document, no PDK** exists in the tree or the environment. Hence: the technology profiles are
   *modelling* profiles, the memory model is hypothetical, and every number in `reports/` is **modelled, never measured**.
2. The interface contract between "memory client" and "controller" already exists (SFMC) but only for **one** requester; nothing arbitrates
   several requesters over several channels, tracks identity per requester, or enforces an ordering contract across channels. That is the gap P115 fills.
3. TensorCore has **no operand-buffer-to-HBM RTL path other than TC07's SFB2 adapter**, and VectorCore's wide LSU does not exist: real
   request flows cannot be *connected* at RTL level today. The brief's "measure stalls from real request flows" is therefore met with **traffic
   models derived from the documented module behaviour**, labelled as such (section 3 of `docs/HARDWARE_INTEGRATION.md`).
4. The repository's DataFabric addresses are 32 bits wide; an HBM stack needs 33-36 bits. The scheduler's `ADDR_W` is a parameter (<= 64), but the
   fabric side needs an extension window.

## 3. Mapping of the brief's client list to what exists

| client in the brief | real module in the repository | what P115 does with it |
|---|---|---|
| TensorCore operand transfers | TC07 `tensor_dma_adapter` (SFB2, 2-D strided, ping-pong, prefetch) | source 0 + tile-fetch flow; **starvation metric** |
| Vector Engine memory traffic | VectorScratch (`VEC_BYTES` lines, strided / gather) | source 1; unit-stride / strided / gather patterns |
| StreamDMA | P103 `sf_stream_dma` (AXI4-style) | source 2; read-stream + write-stream copy flow; AXI4 bridge documented |
| ControlCore requests | P21 `cc_sfb_gate` (single outstanding SFB2) | source 3; sparse single-outstanding probes with arbitration priority |
| shared SRAM staging buffers | TensorScratch / VectorScratch sets, MemoryMatrix | the *consumer* side of the tile / DMA flows (fill = HBM read, drain = HBM write) |
| "cloud processing modules" | CloudDMA / DPU packs (not read) | source 4; random mixed small-block traffic |
