# Address mapping and technology profiles

## 1. Fields and lane-local layout

A global byte address is split into **lane** (= logical channel x pseudo-channel), **bank group**, **bank**, **row**, **column** and **byte offset**. The access
granule is `BURST_BYTES = DATA_W/8 * BURST_LEN` (default 32 B); the byte offset is the low `log2(BURST_BYTES)` bits and must be zero (an unaligned request is rejected with `ST_ERR_ALIGN`).

The **lane-local address** handed to the backend (SFMC `mc_cmd_addr`) is always laid out as

```
  | row | bank group | bank | column | byte offset |        (MSB ... LSB)
```

whatever `MAP_MODE` is. `MAP_MODE` only chooses which *global* address bits feed which field. The scheduler's bank awareness (shadow open rows, bank-group alternation)
reads this layout. **If a real controller uses a different internal mapping, the scheduler's bank hints become less accurate - performance, never correctness, is affected.**

## 2. Modes (fields listed LSB -> MSB above the byte offset)

| `MAP_MODE` | name | order | what it does |
|---|---|---|---|
| 0 | `CH_COL` | ch, pc, col, bg, bank, row | consecutive granules alternate across lanes; a lane then walks the columns of one page (long row-hit runs); pages step bank group, bank, row |
| 1 | `BANK_INT` | ch, pc, bg, bank, col, row | consecutive granules rotate across lanes and then across all banks (maximum bank-level parallelism, columns above) |
| 2 | `PAGE_CH` | col, ch, pc, bg, bank, row | whole pages alternate across lanes (a short stream stays on one lane) |
| 3 | `HASHED` | as 0, then `bank ^= row[BANK_W-1:0]`, `bg ^= row[BANK_W +: BG_W]` | bijective XOR hash that spreads power-of-two strides over banks (the hash is applied before the lane-local address is formed, so the backend sees the hashed bank) |

Lane index = `channel * NUM_PC + pseudo_channel`. `in_range` is false when any address bit above the window (`2^MAP_W` bytes, `MAP_W = log2(lanes) + OFF + COL + BG + BANK + ROW`) is set.

## 3. Technology profiles

`PROFILE` selects the geometry limits in `sf_hbm_defs.svh`. **Every profile is a modelling profile.** No JEDEC document or vendor datasheet was available; the limits only
express "what this profile claims to describe", and the address map **refuses** (generate-time `$error`) any combination outside them:

| profile | channels | pseudo-channels | bank groups x banks | col bits | row bits | access granule |
|---|---|---|---|---|---|---|
| 0 `SIM_GENERIC` (default) | 1..32 (power of two) | 1 or 2 | 2^1..3 x 2^1..3 | 1..5 | 1..14 | 16 / 32 / 64 / 128 B |
| 1 `HBM2E_STYLE` (illustrative) | 1..8 | 2 | 4 x 4 | 1..5 | 1..14 | 32 B |
| 2 `HBM3_STYLE` (illustrative) | 1..16 | 2 | 4 x 4 | 1..5 | 1..15 | 32 B |

*Illustrative* means: the shape (2 pseudo-channels per channel, 16 banks in 4 groups, 32 B per pseudo-channel access) resembles what is publicly described for those
generations, **unverified here**. Passing elaboration does **not** mean the configuration is a real HBM device, and the code never claims that an arbitrary channel/PC
count matches a part. Row counts of the profiles are *maxima*; simulation uses `ROW_W = 6..8` to keep the memory model small.

Rejected at elaboration (tested in `reports/regression.md`, section "Illegal geometry"): non-power-of-two channel count, more channels than the profile, pseudo-channel counts the
profile lacks, access granule outside 16..128 B or different from a profile's fixed granule, bank / column / row widths outside the profile, hashed map with too few row bits,
unknown map mode or profile, address bus narrower than the window.

## 4. Verification

`tb/tb_addr_map.sv` compares the RTL with an independent integer (div / mod) implementation for **every granule of the window** (65,536 for the default), checks that the map is a
**bijection** (no two granules share a (lane, lane-local) pair and every lane-local granule is used), and probes byte offsets and out-of-window addresses, for all four modes and
several geometries (`reports/regression.md`). The system bench uses its own copy of the integer mapper for expected lanes, poison ranges and the final image.
