# Behavioural timing-aware memory model

File: `model/sf_hbm_mem_model.sv` (simulation only, **not synthesizable, not an HBM controller or PHY**). One instance per lane, SFMC slave side.

## 1. Purpose and honesty statement

The model gives the scheduler something that costs cycles in the ways a DRAM does, so scheduling policies can be compared. Its timing parameters are **hypothetical controller-clock
cycle counts** (`model/sf_hbm_model_defs.svh`): chosen to have the right order of magnitude for an HBM2-class device at about 1 cycle = 1 ns (tRCD / tRP 14, tRAS 33, tCL 14, tFAW 16,
tREFI 3900, tRFC 260). They were **not** taken from JEDEC or a datasheet, are identical for the three profiles, and **no result measured with this model is a physical-performance claim**.
No physical timing compliance is claimed; that needs the compatible controller model and the device specification.

## 2. What is modelled

| item | model |
|---|---|
| banks | `2^(BG_W+BANK_W)` banks, open row per bank (open-page policy) |
| commands | ACT, PRE, RD, WR, REF, **one command slot per cycle** |
| row timing | tRCD, tRP, tRAS (ACT->PRE), tRTP (RD->PRE), tWR (write data end -> PRE) |
| bank groups | tRRD_S / tRRD_L, tCCD_S / tCCD_L, tWTR_S / tWTR_L |
| activation window | tFAW (any 4 ACTs span at least tFAW) |
| data bus | `BURST_LEN` cycles per access; windows `[t+tCL, +BL)` / `[t+tCWL, +BL)` never overlap; read->write spacing tRTW, write->read tCWL+BL+tWTR |
| bank conflict / miss / hit | PRE+ACT / ACT / none, classified at the column command and exported as pulses (`mc_ev_*`) |
| refresh | all-bank: every `T_REFI` the model stops new ACT/column commands, closes every bank, waits tRP, refreshes for `T_RFC`; `mc_busy` is high from the request to the end |
| command window | `CMDQ` commands, **column commands strictly in acceptance order**, row preparation (PRE/ACT) of the next `LOOKAHEAD` commands on other banks proceeds early (bank-level parallelism); same-address accesses therefore take effect in acceptance order (SFMC C9) |
| response timing | reads after tCL + burst, writes after the write data; optional per-response random delay `RSP_JITTER`, read beats of different tags interleaved (`INTERLEAVE`) |
| adversarial backend | `ORDER_VIOLATE = 1`: column commands may issue out of acceptance order within the window (an AXI-like backend without C9) - only used to test `BE_ORDER_SAFE = 0` and as the negative test |
| faults | poisoned lane-local ranges (backend error, corrected ECC, uncorrectable ECC, data-bus error), hang, calibration drop, fatal; controller reset clears the DRAM-side state, the memory content survives |
| contract checks | tag re-use while live, wrong `len`, queue overflow -> `violations` counter (the bench requires 0) |

## 3. What is NOT modelled

DFI / PHY, training, per-bank refresh, self-refresh, power states, ranks / stacks, closed-page or adaptive page policy, command-bus contention between the two pseudo-channels of a
channel (each lane has its own command slot), write-to-read forwarding inside the controller, real ECC data correction (flags only), real device timing.

## 4. Independent check of the model

`+CMDLOG=<file>` makes every lane write `<file>.laneN`: one line per ACT / PRE / RD / WR / REF with its cycle. `scripts/check_timing_log.py` re-checks **every rule above** from the log
alone (it shares no code with the model): tRCD, tRP, tRAS, tRC, tRRD_S/L, tFAW, tRTP, tWR, tCCD, RD->WR, WR->RD, data-bus overlap, matching open row, REF only with all banks closed and
at least tRP after the last PRE, no command during tRFC, refresh interval, one command per cycle. Result: `reports/regression.md`, section "Independent timing checker".

## 5. Profiles

`PROFILE` (0 SIM_GENERIC, 1 HBM2E-style, 2 HBM3-style) selects **geometry limits only** (`ADDRESS_MAP.md`); the timing table is shared (placeholders). Any timing parameter can be overridden
per build; the bench passes `T_REFI` / `T_RFC` and `BURST_LEN`-derived values.
