# Hardware integration notes

**What this project is and is not.** `sf_hbm_sched_top` is generic synthesizable RTL for *scheduling and ordering* memory transactions. It does **not** contain an HBM controller, a PHY,
training, DFI, refresh scheduling or any signalling, and **no HBM hard macro is created or implied**. Physical HBM requires technology-specific, licensed (or vendor-provided)
controller / PHY IP and a stacked-memory package; nothing in this tree can claim real stacked-memory integration.

## 1. The adapter boundary (SFMC)

Every lane exposes the master side of **SFMC**, the generic memory-controller contract of the MemoryBridge (P24, `docs/MC_INTERFACE.md` of that package; rules C1-C11) plus a small
optional sideband. A *controller adapter* (one per controller family, **not delivered**) maps SFMC to the controller's user interface:

| SFMC | AXI4 user port (typical licensed HBM controller; check the exact IP) | adapter work |
|---|---|---|
| `mc_cmd_*` (+ `mc_cmd_tag`) | AR / AW: `ADDR = base + mc_cmd_addr`, `LEN = mc_cmd_len`, `SIZE = log2(DATA_W/8)`, `BURST = INCR`, `ID = tag` | split by `mc_cmd_write`; keep bursts inside the 4 KiB AXI rule (a granule is <= 128 B) |
| `mc_wd_*` | W (`WSTRB`, `WLAST`) | direct; data follows the command (rule C7) |
| `mc_rd_*` | R (`RID`, `RLAST`, `RRESP`) | `mc_rd_error = RRESP[1]`; beats of different ids may interleave (handled by the tracker) |
| `mc_wr_*` | B (`BID`, `BRESP`) | `mc_wr_error = BRESP[1]` |
| rule **C9** (overlapping accesses execute in command order) | **not guaranteed by AXI between channels / ids** | either the adapter holds a request overlapping an un-acknowledged one, **or build the lane with `BE_ORDER_SAFE = 0`** (the lane then holds a dependent entry until the older command completes; verified with a reordering backend) |
| `mc_init_done` / `mc_fatal` | controller / PHY "calibration complete" and fatal-error indications | direct (see 3) |
| SFMC-X `mc_busy` | the controller's refresh / maintenance-in-progress status, if it exposes one | optional; tie 0 if absent (the scheduler then reports no refresh stall) |
| SFMC-X `mc_rd_ce / ue / dbus` | per-response ECC / data-bus status if the controller reports it with the data; many controllers report ECC only through status registers or an interrupt | optional per-beat flags; otherwise tie 0 and read the status through the controller's CSRs |
| SFMC-X `mc_ev_*` | controller performance events | optional |

Which pseudo-channel / channel a lane belongs to is **fixed by the address map and the physical wiring**: lane `l` = `channel * NUM_PC + pc`. A controller that exposes one AXI port per
pseudo-channel (the usual arrangement) maps 1:1; a controller with a shared command bus between the two pseudo-channels of a channel is **not modelled** (each lane has its own command slot).

## 2. Clock-domain boundaries

The scheduler, tracker and adapters are **one clock domain** (`clk`). Typical cases:

* controller user clock == scheduler clock: connect directly.
* controller user clock != scheduler clock (common: the controller runs at the memory-derived clock): put an **asynchronous bridge between the adapter and the controller adapter**, exactly like
  P24 (`extmem_mc_cdc`, async FIFOs with the SFMC rules C1-C11 preserved, `mc_rst_n` synchronised). Do not put CDC inside the scheduler. The bridge must keep rule C7 (data may become visible up to
  one controller cycle before its command behind a CDC - the adapter must buffer it).
* source clients on other clocks (TensorCore tile clock, vector clock, DMA clock): each source port is a plain ready/valid channel and needs its own async FIFO / bridge, not provided here.

## 3. Readiness, reset sequencing, errors

* **Reset sequencing**: `rst_n` (assumed synchronised) clears the scheduler. Each lane then holds `mc_rst_n` low for `RST_HOLD` cycles, waits for `mc_init_done` (calibration / training done by the
  controller + PHY), and only then issues. `CAL_TIMEOUT` (0 = wait) moves a lane to CALFAIL; `cfg_link_retry` re-starts the sequence. Requests are accepted and queued while a lane is not ready
  (back-pressure when the queues fill); responses are not generated for requests that were never issued.
* **PHY / controller readiness loss** while READY (`mc_init_done` falls or `mc_fatal` rises) fails every issued transaction of that lane with `ERR_FLUSH`, resets the controller and recovers.
* **Error status**: backend error responses, ECC flags and data-bus errors are mapped to the 4-bit response status (`ARCHITECTURE.md`); ECC *semantics are controller-specific* (the scheduler neither
  corrects nor interprets them, and does not assume they behave like the on-chip SECDED of the SRAM blocks). Partial writes into ECC-protected memory may require read-modify-write in the
  controller; the scheduler passes byte strobes and leaves that to the controller.
* **Refresh**: owned by the controller. The scheduler never issues or schedules refresh; it only observes `mc_busy`.
* **Timeouts**: `cfg_timeout` (cycles after issue) is a *scheduler-side* watchdog, not a DRAM timing parameter; see `ORDERING.md` for the zombie-slot rule.

## 4. Attaching the clients (what exists, what is needed)

| client | interface in the repository | needed to attach | status here |
|---|---|---|---|
| TensorCore operand / result transfers | TC07 `tensor_dma_adapter`: SFB2, 32-bit words, 2-D strided, `MAX_OUT` = 4, ping-pong tile sets | SFB2 -> granule bridge: assemble `BURST_BYTES` granules from words, keep the SFB2 single-outstanding-per-id rule, map SFB2 errors | **not built**; traffic model `bench_tensor*` |
| Vector Engine | VectorScratch DMA port / (future) wide LSU, `VEC_BYTES` lines | line-to-granule adapter | **not built**; traffic model `bench_vector` |
| StreamDMA | `sf_stream_dma` AXI4-style master (bursts of up to 16 x `DATA_WIDTH`) | **AXI4 -> granule bridge**: split INCR bursts at granule boundaries, one request per granule, re-assemble R beats in order (per-source in-order mode gives AXI per-id order), error mapping; the byte strobes of W map to `wstrb` | **not built**; traffic model `bench_dma_copy` |
| ControlCore | `cc_sfb_gate` (SFB2, one transaction at a time, 32-bit) | word <-> granule adapter (read-modify-write for sub-granule writes is **not** available: a sub-granule write is a masked granule write via `wstrb`) | **not built**; traffic model `bench_ctrl_probe` |
| shared SRAM staging buffers | TensorScratch / VectorScratch / MemoryMatrix | they are the *consumers / producers* of the DMA flows above | not instantiated |

The fabric addresses of the repository are **32 bits**; an HBM stack needs 33-36 bits (`ADDR_W` of the scheduler is a parameter, <= 64): put an address-extension (window) register in the
fabric-side adapter.

## 5. Physical-design dependencies (floorplanning)

Nothing was placed or routed (no PDK, no OpenROAD). What the RTL implies for a physical flow:

* the **write queue** (`WQ_DEPTH x LINE_W` bits per lane), the **tracker read-data store** (`NUM_SRC x OUT_PER_SRC x LINE_W` bits) and the adapter write-data FIFO are register arrays here (flip-flop
  counts in `reports/SYNTH.md`); in silicon they should be register-file / SRAM macros. The 2-lane top synthesises to 37,643 flip-flops (53 % of the cells are the response tracker, 27 % the two lanes, 19 % the performance counters) - how much of that becomes SRAM / register-file macros is a decision for the physical team.
* the **scheduler's pick logic** is the deepest combinational block of the design on its own: 171 generic-gate levels (the response tracker is 108); in the flattened top the longest path is 268 levels and continues from the pick
  into a 48-bit performance-counter increment (`reports/SYNTH.md`; the counter attribution is inferred from the adder width). These are proxy depths from generic gates with ripple comparators, not timing. Pipeline the pick
  (register it, re-validate against the popped entry) and feed the counters from registered events if the lane must run at the controller clock; the RTL keeps `iss_ok` / pick / pop as one combinational path for simplicity, and
  neither change was tried.
* each lane's SFMC bus is a point-to-point interface to **its** controller port. HBM channels sit on the stack edge facing the PHY; place lanes next to their controller / PHY ports and keep the
  source-side crossbar (tracker, arbiters) in the middle. The tracker and the address maps are shared by all lanes (wiring grows with `NUM_LANES x DATA_W`).
* PHY / controller floorplans, bump maps, interposer routing and signal integrity are outside this RTL and must come with the PHY vendor's integration package.
