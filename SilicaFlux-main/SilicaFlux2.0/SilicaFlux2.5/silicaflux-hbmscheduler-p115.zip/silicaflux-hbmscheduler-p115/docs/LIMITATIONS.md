# Limitations and non-claims

Read this before using any number or any block of this project.

## Status of the evidence

* **Simulation only.** RTL simulation (Verilator, plus the Icarus items listed in `reports/CROSSSIM.md`) against a **behavioural, hypothetical** memory model; Yosys generic-gate synthesis statistics.
  No FPGA, no silicon, no PDK, no static timing, no power, no place and route, no formal proof, no gate-level simulation. **No frequency, area, power or bandwidth figure of a real device is claimed.**
* **No JEDEC compliance and no vendor-IP compatibility is claimed.** No JEDEC specification, vendor datasheet, controller IP or PHY document was available. The three technology profiles are modelling
  profiles (`ADDRESS_MAP.md`); the timing table of the model is a set of placeholders of plausible magnitude (`TIMING_MODEL.md`). A configuration that elaborates is **not** thereby a real HBM device.
* **All performance numbers are MODELLED.** They show how scheduling policies compare *on this model*; absolute values must not be quoted as HBM performance.
* No functional or line coverage was collected. The scenario list, mutation results and negative checks are the evidence of bench strength, not a coverage metric.

## What is not in this project

* No HBM controller, PHY, DFI, training, calibration, refresh scheduling, power states or ECC engine. No controller adapter for real IP (SFMC -> AXI4 etc.) and **no HBM hard macro** - only integration notes.
* No source-side bridges: the repository's real TensorCore (TC07 / SFB2), VectorCore, StreamDMA (AXI4) and ControlCore (SFB2) interfaces are **not connected at RTL level**. Their request flows are **traffic models derived
  from the documented behaviour of those modules** (`reports/BENCHMARKS.md` says so wherever it uses them). "Measure stalls from real request flows" is therefore met with modelled flows, not with the real RTL.
* No CSR block for the `cfg_*` inputs; no asynchronous (CDC) bridge between adapter and controller; no interrupt / error-capture registers.
* Single clock domain. A controller in another clock domain needs an asynchronous bridge (documented).

## Behavioural limits of the scheduler

* One access granule (`BURST_BYTES`) per request; multi-granule transfers are several requests. A sub-granule write is a masked granule write (`wstrb`); the scheduler does no read-modify-write (a controller with ECC may need one).
* Same-granule hazards are resolved at **granule** granularity (exact, because requests are granule aligned).
* **Timeout / hung backend:** a timed-out transaction leaves a *zombie* slot that is reclaimed only by the late response or a lane flush. A backend that never answers permanently removes slots (documented in `ORDERING.md`); recovery needs a reset.
* A backend that violates the SFMC contract can corrupt order unless the lane is built with `BE_ORDER_SAFE = 0`; other contract violations (duplicate or foreign tags) are detected and counted, not repaired.
* Queued (not yet issued) requests have **no timeout**: if the backend never becomes ready they wait forever (the queues fill and back-pressure reaches the sources).
* The scheduler's bank awareness assumes an open-page controller and the lane-local address layout of `ADDRESS_MAP.md`. With another controller policy the hints are less accurate (never incorrect).
* Command-bus sharing between the two pseudo-channels of a channel, per-bank refresh, rank / stack effects and DRAM power states are not modelled.
* **Configuration constraint (policies 1-3):** with `cfg_idle_wr = 0` AND `cfg_age_limit = 0` a write is only issued when `wq_count >= cfg_wr_hi`; below that watermark a write (and any read that depends on it) can wait forever. Keep `cfg_idle_wr = 1` or `cfg_age_limit != 0` (the study uses `cfg_idle_wr = 1`).
* **Backend contract violations are detected, not repaired.** A completion with a foreign or duplicate tag still decrements the adapter's outstanding counter (it is tag-agnostic) and, with `BE_ORDER_SAFE = 0`, can leave the lane's in-flight hazard table short of an entry; a stray response of another lane carrying a live tag can shadow that lane's genuine response in the slot decode. The tracker counts and flags what it can (`G_SPURIOUS`, `err_spurious_o`, foreign source fields included) but a controller that breaks SFMC must be fixed in its adapter.
* `perf` counters wrap at 2^48 and have no snapshot; a read during traffic is not coherent across counters.
* `ADDR_W` is a parameter (<= 64); the repository's fabric addresses are 32 bits (address-extension window needed).

## Verification gaps that are known

* **Policy selection is only asserted for FCFS.** `fcfs_order` checks that strict FCFS issues in acceptance order. For policies 1-3 (read priority, FR-FCFS, bank-aware) the bench checks that every result is *correct* (data, ordering, hazards) and the benchmarks measure what the policies *achieve*, but no test asserts that the right entry was chosen. A bug in a policy's ranking (for example the tier order of BANKAWARE) would keep every regression run green and show up only as a change in the benchmark tables, which are not part of the regression. A reference model of each policy's choice would close this; it was not written.
* **No coverage metric, no formal proof** (`docs/VERIFICATION.md` section 6). The mutation checks are the only measure of bench strength; 28 hand-written mutants are a small sample of possible bugs.

## Synthesis proxy caveats

`reports/SYNTH.md` counts generic gates after `synth -flatten`. Storage (write queue, tracker read-data store, adapter FIFOs) is implemented as flip-flop arrays; Yosys maps comparators as ripple structures, so the *logic-level* figures of
comparator-heavy blocks (scheduler, tracker) overstate what a timing-driven flow would produce. Neither number is area or frequency.

## Things deliberately left for the next steps

SFB2 / AXI4 / vector-line source bridges and the controller adapter; registered (pipelined) scheduler pick; CSR block; async bridges; formal proofs of the ordering rules; coverage collection; a second memory model
(e.g. a DRAMsim3 / Ramulator cross-check) once a device specification is available.
