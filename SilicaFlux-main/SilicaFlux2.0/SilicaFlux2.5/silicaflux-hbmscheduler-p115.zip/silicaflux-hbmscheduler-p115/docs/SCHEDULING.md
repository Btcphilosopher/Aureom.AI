# Scheduling policies

Primary RTL: `rtl/sf_hbm_scheduler.sv`. One scheduler per lane; every cycle it picks **at most one** entry of the read / write queue to issue to the backend adapter.
The policy is a **runtime input** (`cfg_policy`), so one binary can be measured under every policy.

## 1. What the scheduler may and may not do

* It only considers entries whose dependency mask is empty (`*_ready`, RAW / WAR / WAW, see `ORDERING.md`) and that the backend can take now (`iss_ok_rd`, `iss_ok_wr`: link READY,
  outstanding < `LANE_OUT`, command FIFO and (for writes) write-data FIFO not full).
* It never issues a refresh, never sequences DRAM commands, and never needs to know the device timing. `be_busy` (the controller's refresh / maintenance indication) is **observed**:
  it feeds the refresh-stall counter and clears the shadow open rows; the controller keeps ownership of refresh.
* Bank awareness uses a **shadow** of the backend (open row per bank under an open-page assumption, a busy countdown `cfg_busy_cyc` set at issue, the last bank group). It is a hint:
  a wrong guess can only cost performance.

## 2. Policies

| `cfg_policy` | name | decision | purpose |
|---|---|---|---|
| 0 | **FCFS** | the globally oldest valid entry of either queue (age counters); if the backend cannot take it the scheduler waits (no bypass). Only if the oldest entry is blocked by a *hazard* mask (possible after the age counters saturate and tie, or behind an in-flight command with `BE_ORDER_SAFE = 0`) the oldest *issuable* entry is taken instead, so FCFS can never wait for an entry that only another issuable entry can unblock | **measured baseline**; preserves arrival order |
| 1 | RDPRIO | reads first; writes drain in bursts: drain mode starts at `wq_count >= cfg_wr_hi`, ends at `<= cfg_wr_lo` (hysteresis); with `cfg_idle_wr` a write also issues when no read is issuable; oldest-first inside the class | reads are latency critical, write bursts amortise bus turnaround |
| 2 | FRFCFS | RDPRIO class selection; inside the class a **row hit** (shadow) beats an older miss; oldest-first among equals | row-buffer locality |
| 3 | BANKAWARE | FRFCFS plus tiers: (0) hit in a different bank group than the last issue, (1) hit in the same bank group, (2) idle bank (closed), (3) conflict on a bank that is not busy, (4) bank busy; oldest-first inside a tier | avoid tCCD_L, avoid back-to-back use of a recently opened / closed bank |

**Starvation prevention (policies 1-3).** If any issuable entry is older than `cfg_age_limit` cycles, the **oldest issuable entry of either queue** is issued, whatever the class or
row state (`L_AGE_OVR` counts it). `cfg_age_limit = 0` disables it. FCFS needs none (it is already oldest-first).

**Bypass cap (`cfg_bypass_cap`, policies 1-3, 0 = off).** After this many consecutive issues of entries that are NOT the oldest issuable one, the oldest issuable entry is forced (`L_BYP_OVR`). It was implemented to test the hypothesis that deferring a source's oldest request stalls that source (in-order responses + small outstanding window). **The measurement refuted it** (`reports/BENCHMARKS.md`, "Parameter study"): it does not recover the sequential-stream loss and costs up to 35 % on mixed workloads at small caps. It stays in the RTL, off by default, as a documented knob.

**Fairness among sources** is a separate stage, the per-lane arbiter: round robin by default; `cfg_arb_mode = 1` gives static priority classes with aging (a source that loses
`cfg_arb_age` consecutive arbitrations is promoted above all classes), so a low-priority source is delayed by a bounded amount and a high-priority one cannot be starved. `S_ARB_LOSS`
counts the losses per source.

## 3. Implementation notes

* Entries are random-access; `age` is a saturating cycle counter per entry (`AGE_W`, default 12 bits = 4095 cycles; ties only after saturation). The order key is the age, so no wrapping
  sequence numbers exist.
* The pick is combinational over `RQ_DEPTH + WQ_DEPTH` entries (max-key reductions). It is the deepest logic of the design (`reports/SYNTH.md`); a registered / pipelined pick is the
  first timing optimisation if the lane must run faster (not done: no timing closure was attempted).
* One pop per cycle per lane; the popped slot is reusable next cycle.

## 4. How the policies were studied

1. **Baseline first.** Strict FCFS was verified (full regression) and measured on 15 workloads x 3 seeds before any other policy was run; the result was frozen with SHA-256 (`reports/BASELINE_FCFS.md`, `reports/bench/pre_review/`). After the independent review fixed three latent RTL defects
   the baseline was re-measured on the fixed RTL: **all 37 records are identical** (cycles and bytes).
2. **First policy measurement** with default parameters (`cfg_age_limit` 256): `reports/BENCHMARKS_age256_first_measurement.md`. It showed the reordering policies collapsing toward oldest-first under saturation (thousands of starvation overrides).
3. **Parameter study on seed 1** (`reports/PARAM_STUDY.md`): age limit, bypass cap. Age limit >= 512-1024 removes the collapse (e.g. aligned buffers 1.60 -> 5.03 B/cycle, row-mix 2.2 -> 3.1); 1024 is adopted. The bypass cap is refuted (see 2).
4. **Held-out evaluation** of the adopted setting on seeds 2 and 3 (`reports/BENCHMARKS_heldout_seeds23.md`) next to all-seed results (`reports/BENCHMARKS.md`).
5. Mechanism analysis from the memory model's command logs (below).

## 5. Findings (all MODELLED, two lanes, hypothetical timing; numbers from `reports/BENCHMARKS.md`, age limit 1024)

| workload | FCFS B/cyc | RDPRIO | FRFCFS | **BANKAWARE** | reading |
|---|---|---|---|---|---|
| `bench_system` (all five flows) | 4.98 | +11 % | +26 % | **+27 %** | mixed read / write traffic: the reordering policies win |
| `bench_tensor` (tile flow + background) | 5.08 | +12 % | +23 % | **+27 %** | tensor span for 24 tiles 88 k -> 48 k cycles |
| `bench_seq_mix` (30 % writes) | 8.77 | +25 % | +23 % | **+27 %** | write draining removes turnarounds (0.42 -> 0.24 per request) |
| `bench_vector` / `bench_ctrl_probe` | 4.80 / 4.90 | +15 / +4 % | +17 / +19 % | **+20 / +24 %** | |
| `bench_rowmix` (3 hot rows per bank) | 2.14 | **-13 %** | +40 % | **+46 %** | RDPRIO alone defers writes and stalls the sources |
| `bench_hotbank` | 0.80 | +1 % | +178 % | **+178 %** | row-hit batching in the one busy bank |
| `bench_seq_rd_aligned` (power-of-two buffers) | 1.27 | 0 % | +295 % | **+295 %** | row-hit reordering rescues the pathological layout |
| `bench_rand_rd` / `bench_rand_mix` | 5.04 / 4.45 | 0 / +3 % | +1 / +3 % | **+11 / +9 %** | little row locality to exploit; the bank-busy tiers help |
| `bench_seq_rd` / `bench_seq_wr` (friendly streams) | 22.52 / 22.74 | 0 % | **-31 % / -30 %** | **-12 % / -3 %** | FCFS is already near-optimal; see mechanism |
| `bench_rowwalk` (every request opens a row of a private bank) | 5.69 | **-51 %** | -51 % | **-43 %** | no locality to exploit; deferring the oldest request stalls the in-order source |
| `bench_dma_copy`, `bench_tensor_alone` | 2.56 / 8.24 | 0 | 0 | 0 | limited by the source / the consumer, not by the memory |

**Mechanism of the losses (from the command logs).** On friendly sequential streams FCFS interleaves five streams round-robin by arrival, so only 20 % of adjacent column commands fall in the same bank group (spacing tCCD_S = 2). FR-FCFS
("oldest hit first") keeps picking hits of one bank: 70 % of adjacent commands are in the same group (spacing tCCD_L = 4) although the row-hit rate is identical (96.5 %). The bank-aware tiers (hit in a *different* group first) reduce the same-group share to 15 %, but the
policy still reorders more than FCFS and loses ~12 %. On `bench_rowwalk` and with RDPRIO the loss comes from **deferring a source's oldest request**: sources have an 8-deep outstanding window and in-order responses, so a request that waits behind reordered ones stalls its source.
A bypass cap (force the oldest after K bypasses) was implemented to test this explanation: it did **not** recover the sequential loss and cost up to 35 % on mixed workloads at small caps (`PARAM_STUDY.md`), so the explanation is at best partial; the cap is off by default.

**Fairness.** FCFS shares the memory almost equally among the five flows of `bench_system` (1.03-1.10 B/cycle per source, CONTROL 0.77 by construction). The reordering policies are **not neutral**: with BANKAWARE the read-dominated TENSOR flow gets 2.13 B/cycle (+107 %, end-to-end latency 276 -> 132 cycles) and VECTOR 1.55 (+50 %), STREAMDMA is unchanged (1.06), CONTROL is unchanged in rate (0.76) but its mean latency improves (249 -> 195) while its **p99 gets worse** (600 -> 696), and the random 40 %-write CLOUD flow **loses 25 %** (1.10 -> 0.83 B/cycle, latency 261 -> 345). Whoever deploys a reordering policy is choosing who wins. Arbiter priority classes do **not** correct this here (`reports/PRIORITY.md`): lane ingress is not the bottleneck, the sources' outstanding windows are.

**Quality of service lever that works: window shaping** (`reports/WINDOW_SHAPING.md`). Limiting the background sources to 1-2 transactions in flight (`cfg_out_limit`) cuts the 24-tile tensor run from 88 k to 27-36 k cycles under FCFS (idle 83 % -> 50-62 %) and CONTROL p99 from 600 to ~390-420 cycles, with no loss of aggregate throughput.

## 6. Chosen policy (documented recommendation)

* **Default for mixed system traffic: policy 3 (BANKAWARE), `cfg_age_limit = 1024`, `cfg_bypass_cap = 0`, `cfg_idle_wr = 1`, `cfg_wr_hi/lo = 3/4 and 1/4 of the write queue`, `cfg_busy_cyc = 16`.** It is the best or tied-best policy on every mixed or locality-rich workload and has the smallest loss of the three reordering policies on friendly streams (-12 % / -3 %).
* **Where not to use it:** pure friendly sequential streaming (use FCFS or RDPRIO: identical on read-only streams) and traffic in which every access opens a new row of a private bank (`bench_rowwalk`).
* Because the choice is a **runtime** input (`cfg_policy`), a system can select FCFS for a streaming phase and BANKAWARE otherwise; no rebuild is needed.
* For tensor starvation use **window shaping** first, arbiter priority second.
* These conclusions hold for **this behavioural memory model** (open page, in-order column commands, 4-command row-preparation lookahead). A real controller with its own reordering, a different bank-group penalty or a different page policy can change them; re-measure with the real controller model before adopting.
