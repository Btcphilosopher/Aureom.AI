# Transaction identity, ordering and response tracking

## 1. Contract

For one scheduler instance:

1. **Exactly once.** Every request that is *accepted* (the cycle of its `req` handshake) receives exactly one response. A rejected request (range, alignment, permission,
   strobe) is accepted too and receives an *error* response, so errors are ordered like data. Nothing is lost, duplicated or answered after a reset.
2. **Identity.** The response carries the request's `id` and direction unchanged. Inside the scheduler a transaction is named by its **tag `{source, slot}`**; a backend response
   is matched to a slot by tag AND lane AND kind (read beat vs write response). A response that matches no live slot is counted (`G_SPURIOUS`, sticky `err_spurious_o`) and
   discarded; it can never complete another request.
3. **Response order** (parameter `ORDER_MODE`): `0` - per source, strictly in acceptance order; `1` - AXI-like: among responses with the **same id** in order, different ids
   may overtake. The tracker re-orders whatever the backend and the lanes complete (reads and writes, different lanes, a jittering backend).
4. **Memory order.** Accesses to the same granule take effect in acceptance order: a read sees every write accepted before it and none accepted after it (RAW), a write never
   overtakes an older read (WAR) or an older write (WAW) of the same granule. Accesses to different granules have no order.
5. **Outstanding limit.** At most `OUT_PER_SRC` live transactions per source (tracker slots), `cfg_out_limit` can lower it per source; at most `LANE_OUT` commands in flight per lane.

## 2. How it is enforced

| mechanism | where | what it guarantees |
|---|---|---|
| slot allocated in the acceptance cycle | `sf_hbm_response_tracker` (`sf_hbm_trk_src`) | one tag per live transaction; order defined at acceptance |
| tag `{source, slot}` carried through queue, SFMC `mc_cmd_tag`, response | lane / adapter | no response mix-up; SFMC rule C4 (no live tag re-issued) |
| exact "older-than" bit matrix per source (row stored in each slot, cleared when the older slot leaves) | `sf_hbm_trk_slot` | ordering that cannot be broken by counter wrap, however long a slot lives |
| `blocked = older live slot (of the same id in mode 1)`; the oldest eligible slot is loaded into a registered response channel | `sf_hbm_trk_src` | in-order (mode 0) / same-id order (mode 1); response stable under back-pressure |
| dependency masks at enqueue (RAW, WAR, WAW) | `sf_hbm_read_queue`, `sf_hbm_write_queue` | the scheduler cannot issue a dependent entry before its dependency was **issued** |
| rule C9 of SFMC: the backend executes overlapping accesses in command order | contract with the controller adapter | issue order == execution order for the same bytes |
| `BE_ORDER_SAFE = 0`: an in-flight table in the lane | `sf_hbm_lane` | for a backend WITHOUT C9: a dependent entry also waits until the older command **completed** |
| read data assembled into the slot by beat index | `sf_hbm_trk_slot` | SFMC rule C5: beats of different tags may interleave |

## 3. Failure paths (nothing may be mis-attributed)

| event | handling |
|---|---|
| backend error response / `mc_rd_error` | status `ERR_BE`, data zeroed |
| ECC flags from the controller | corrected -> `OK_ECC_CE` (data valid); uncorrectable -> `ERR_ECC_UE` (data untrusted, zeroed); data-bus error -> `ERR_DBUS`. Flags are **passed through**; the scheduler does not correct data and does **not** assume external ECC behaves like on-chip SECDED |
| read framing error (`rd_last` at the wrong beat) | `ERR_BE` |
| **timeout** (`cfg_timeout` cycles after issue, 0 = off) | the slot completes with `ERR_TIMEOUT` and is delivered in order, then becomes a **ZOMBIE**: it is not re-allocated until the late backend response arrives (or the lane is flushed), so a late response cannot hit a new transaction. A hung backend therefore shrinks the usable slots instead of corrupting data (documented limit). If the late response arrives while the timed-out slot still waits for delivery, it is absorbed (`late`) |
| backend loses calibration / `mc_fatal` while READY | lane FSM -> FLUSH: every already-issued transaction of that lane completes with `ERR_FLUSH`, the controller is reset, queued requests wait for the link and continue. Responses seen while the link is not READY are dropped |
| spurious / unexpected backend response | counted, ignored |
| system reset | everything is cleared; the bench checks that nothing comes back afterwards |

## 4. Verification

Independent reference memory with the **acceptance-time snapshot** rule (`tb/sf_hbm_tb.sv`, `docs/VERIFICATION.md`): a read's expected data is the reference memory at the cycle the request is
accepted. This checks (4) exactly, whichever order the scheduler picks. Hot-set scenarios (6 granules, 5 sources, 50 % writes) exercise RAW / WAR / WAW continuously. The negative build
`neg_c9` (backend that breaks C9 while the scheduler is built to trust it) **must fail** and does (`reports/regression.md`); the `unsafe` build (same backend, `BE_ORDER_SAFE = 0`) must pass and does.
