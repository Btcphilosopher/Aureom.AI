# Performance measurement

Everything is measured at handshakes in RTL simulation against the HYPOTHETICAL behavioural memory model. **Results are modelled, never measured on hardware, and are not claims about any HBM device.**
Reproduce: `make bench` (see `README.md`); runs are deterministic (the bench has its own xorshift PRNG; one `(binary, scenario, policy, seed, N)` always gives the same record - `reports/bench/*.json` carry
the SHA-256 of the binary and of every RTL file).

## 1. Counters (`sf_hbm_perf`, 48-bit, wrap at 2^48; MAX counters keep the maximum)

Read through `perf_sel = {group[1:0], instance[5:0], index[7:0]}` / `perf_data[63:0]`; `perf_clr` clears. Index names: `sf_hbm_defs.svh`.

| requirement of the brief | counter(s) | derivation (off-chip, `scripts/gen_report.py`) |
|---|---|---|
| useful bytes per cycle | `G_BYTES_RD`, `G_BYTES_WR`, `G_CYCLES` / `G_ACTIVE` | bytes of **successful** responses (enabled strobe bytes for writes) / cycles |
| read / write throughput | `G_BYTES_RD`, `G_BYTES_WR`, `S_BYTES` per source | per direction, per source |
| channel utilisation | `L_BEATS` (data beats moved on the backend interface) | `L_BEATS / cycles` (1 beat per cycle is the lane peak) |
| bank conflicts | `L_BE_CONF` (backend-reported row conflicts), `L_CONF` (scheduler shadow), `L_BANK_CONF` (issue to a bank still considered busy) | rate = conflicts / (hit + miss + conflict) |
| row-hit rate (where modelled) | `L_BE_HIT / L_BE_MISS / L_BE_CONF` (SFMC-X pins; 0 if the backend has none), `L_HIT / L_MISS / L_CONF` (shadow) | hit / total |
| queue waiting time | `L_QW_SUM / L_QW_CNT / L_QW_MAX` (accept -> issue, per lane), `S_QW_SUM / S_QW_CNT` (per source), `L_RQ_OCC_SUM / L_WQ_OCC_SUM`, `L_RQ_MAX / L_WQ_MAX`, `L_QFULL_RD / WR` | mean = sum / count |
| request latency | `G_LAT_SUM`, `G_LAT_MAX`, `S_LAT_SUM / S_LAT_MAX` per source, **latency histogram** (log2 buckets) | mean, max; p50 / p99 from the histogram (bench-side exact percentiles are in the JSON) |
| response reordering | `S_REORDERED` (responses that completed before an older one and had to wait), `S_ROB_STALL` / `G_ROB_STALL` (cycles with a completed response held back), `S_ROB_MAXD` (max held) | |
| refresh stalls | `L_REF_STALL` (cycles with queued work while the backend reports busy) | share of cycles |
| tensor starvation | `S_ING_STALL` of the TENSOR source (cycles its request was offered and not accepted), `S_ARB_LOSS`, per-source latency; the bench's tile-fetch flow reports the **consumer idle cycles** | `bench_tensor*` JSON `tensor.starve_cycles` |
| other | `L_TURN` (read<->write direction changes), `L_DRAIN_CYC`, `L_AGE_OVR`, `L_HAZ_STALL`, `L_BE_STALL`, `L_LINK_RST`, `L_UNAVAIL`, `G_TIMEOUT / SPURIOUS / FLUSHED / ZOMBIE_CYC`, `G_REJECT` | |

## 2. Independent cross-check of the counters

The bench computes the same quantities from the port handshakes and the SFMC wires and compares them with the RTL counters at the end of every scenario (`perf_check`): requests, responses,
read / write bytes, latency sums and maxima, error responses, ingress stalls, rejected requests, issued reads / writes and data beats per lane (against the protocol checker's wire counts), the issue-to-queue-wait
count, and the latency histogram total. A mismatch fails the run.

## 3. Definitions used in the reports

* *useful B/cycle* = payload bytes of successful responses / (cycle of the last response - cycle of the first accept + 1)
* *peak* = lanes x DATA_W / 8 bytes per cycle (every beat of every lane useful); *% of peak* = useful B/cycle / peak
* *latency* = cycle of response delivery - cycle of acceptance (the request handshake); *end-to-end latency* = delivery - the cycle the request was first offered at the port (includes the ingress wait)
* *row hit / conflict %* = backend-reported at the column command
* *q-wait* = accept -> issue to the backend
* *tensor idle* = cycles in which the double-buffered consumer waits for a tile (after the first tile started)

## 4. Limits

The row-hit counters of the backend come from simulation pins; with a real controller they exist only if the controller exposes them. Counter widths and wrap: `docs/ARCHITECTURE.md`. No counter snapshot / overflow interrupt
exists (unlike the Module-07 bank) - read while idle or accept skew.
