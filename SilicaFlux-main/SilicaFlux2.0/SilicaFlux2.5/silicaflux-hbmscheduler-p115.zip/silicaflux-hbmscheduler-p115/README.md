# SilicaFlux HBMScheduler - Project 115

**High-bandwidth-memory transaction scheduling engine** for the SilicaFlux compute architecture. Primary RTL: `rtl/sf_hbm_scheduler.sv` (per-lane policy core); integration top: `rtl/sf_hbm_sched_top.sv`.
Aureom.AI | SilicaFlux Cloud Semiconductor Systems. Delivered as a zip; **nothing was committed or pushed to GitHub, and no file of the repository was modified.**

> ## Status - read this first
> * **Simulation-grade engineering model. Not silicon-ready.** Everything here is RTL simulation (Verilator 5.020; Icarus items in `reports/CROSSSIM.md`), Yosys generic-gate statistics and Python post-processing. No FPGA, no PDK, no timing, no power, no formal proof.
> * **This is a scheduler, not an HBM controller or PHY.** It contains no DRAM command sequencing, refresh scheduling, training, DFI or signalling. Physical HBM needs technology-specific controller / PHY IP behind the SFMC boundary; **no HBM hard macro is created and no real stacked-memory integration is claimed.**
> * **No JEDEC / vendor compliance is claimed.** The three technology profiles are *modelling* profiles; the memory model's timing numbers are hypothetical placeholders of plausible magnitude. A configuration that elaborates is not thereby a real HBM device.
> * **All performance numbers are MODELLED** (simulation against the behavioural memory model). They compare policies on that model; they are not HBM performance figures.
> * **The compute blocks are not connected at RTL level.** TensorCore, Vector Engine, StreamDMA and ControlCore appear as *traffic models* derived from their documented behaviour (`docs/COMPUTE_FLOWS.md`), because the repository has no RTL path from them to a memory port (`docs/AUDIT.md`).

## What the scheduler does

```
memory requests -> request validation -> address mapping -> channel (lane) selection -> request queues -> scheduler -> memory-controller adapter (SFMC) -> response re-ordering
```

Five source ports (TensorCore, Vector, StreamDMA, ControlCore, cloud; the number is a parameter) share `NUM_CH x NUM_PC` lanes. Every request is validated, mapped, given a tag `{source, slot}` at the cycle it is accepted, arbitrated
per lane, queued (read / write queues with RAW / WAR / WAW dependency masks), picked by the selected policy, and sent to the controller through SFMC (the generic controller contract of the repository's MemoryBridge). Responses are
re-ordered per source (strictly, or AXI-like per id) whatever order the lanes and the backend complete them in. The default configuration is **two logical channels on the behavioural memory model**; policy 0 is **strict FCFS** and was
measured and frozen **before** any other policy (`reports/BASELINE_FCFS.md`).

## Deliverables (brief section 15)

| requested | file |
|---|---|
| `sf_hbm_scheduler.sv` | `rtl/sf_hbm_scheduler.sv` (+ `sf_hbm_maxsel.sv` tree selector) |
| `sf_hbm_address_map.sv` | `rtl/sf_hbm_address_map.sv` (+ `sf_hbm_req_check.sv` validation) |
| `sf_hbm_read_queue.sv`, `sf_hbm_write_queue.sv` | `rtl/` |
| `sf_hbm_channel_arbiter.sv` | `rtl/` |
| `sf_hbm_response_tracker.sv` | `rtl/sf_hbm_response_tracker.sv` (+ `sf_hbm_trk_src.sv`, `sf_hbm_trk_slot.sv`) |
| `sf_hbm_backend_adapter.sv` | `rtl/` |
| `sf_hbm_perf.sv` | `rtl/` |
| (integration) | `rtl/sf_hbm_lane.sv`, `rtl/sf_hbm_sched_top.sv`, `rtl/sf_hbm_defs.svh` |
| behavioural timing model | `model/sf_hbm_mem_model.sv`, `model/sf_hbm_model_defs.svh`, independent checker `scripts/check_timing_log.py` |
| tests | `tb/sf_hbm_tb.sv` (system bench, 23 scenarios + benchmark workloads), `tb/sf_hbm_sfmc_check.sv`, `tb/tb_addr_map.sv`, `scripts/run_regress.py`, `scripts/run_mutation.py` |
| synthesis and benchmark reports | `reports/` (see the index below) |
| hardware integration notes | `docs/HARDWARE_INTEGRATION.md` |

## Quick start

```bash
make lint                 # Verilator -Wall over the RTL: must be clean
make sim && make smoke    # build the 2-channel bench, run all scenarios
make regress              # 13 configs x 3 seeds x 23 scenarios, timing checker, unit bench, negative test, illegal geometry   (long)
make bench                # FCFS baseline, then policies, then channel scaling                                                    (long)
make mutation             # inject RTL bugs, the bench must kill them                                                              (long)
make synth                # Yosys statistics -> reports/SYNTH.md
make zip                  # rebuild dist/silicaflux-hbmscheduler-p115.zip
```

One scenario by hand: `build/base/simx +TEST=hazard +N=300 +SEED=1 +POLICY=2`. Tools: Verilator >= 5.020, Python 3, Yosys 0.33, Icarus 12 (optional).

## Layout

| path | content |
|---|---|
| `rtl/` | 14 synthesizable SystemVerilog modules + 1 header, following the repository's coding rules (flat ports, `define header, no packages / structs / interfaces) |
| `model/` | behavioural timing-aware SFMC memory model (simulation only) |
| `tb/` | self-checking system bench, SFMC protocol checker, address-map unit bench |
| `scripts/` | build, regression, benchmark, mutation, synthesis, report and packaging scripts; `configs.json` (13 test configurations) |
| `reports/` | machine-readable and human results; `reports/bench/` raw benchmark JSON with SHA-256 of every RTL file used |
| `docs/` | `AUDIT`, `ARCHITECTURE`, `ADDRESS_MAP`, `SCHEDULING`, `ORDERING`, `TIMING_MODEL`, `PERFORMANCE`, `VERIFICATION`, `COMPUTE_FLOWS`, `HARDWARE_INTEGRATION`, `LIMITATIONS`, `FINDINGS` |
| `MANIFEST.sha256` | SHA-256 of every file in the archive |

## Results at a glance

Every number below is **MODELLED**: RTL simulation against the hypothetical behavioural memory model (SIM_GENERIC profile, two lanes = 32 B/cycle peak unless stated). They compare scheduling policies on that model;
they are not HBM performance figures. Every figure has its source report, raw JSON (with the SHA-256 of every RTL file used) and a command to reproduce it.

### Baseline: strict FCFS, measured first and frozen (`reports/BASELINE_FCFS.md`)

| workload | useful B/cycle | % of peak | mean / p99 latency (cycles) | row hit % |
|---|---|---|---|---|
| sequential read, 5 streams | 22.52 | 70 | 56 / 359 | 96.6 |
| sequential write, 5 streams | 22.74 | 71 | 55 / 363 | 96.5 |
| random read | 5.04 | 16 | 249 / 588 | 1.4 |
| random mix | 4.45 | 14 | 285 / 643 | 1.4 |
| compute-system mix (tensor + vector + DMA + control) | 4.98 | 16 | 242 / 587 | 48.4 |
| sequential read, power-of-two aligned buffers (pathology) | 1.27 | 4 | 1003 / 1246 | 0.0 |

### Scheduling policies vs the frozen baseline (`reports/BENCHMARKS.md`, 3 seeds, `docs/SCHEDULING.md` §5-6)

| workload | RDPRIO | FR-FCFS | BANKAWARE |
|---|---|---|---|
| sequential read | +0.0 % | **-31.5 %** | **-12.4 %** |
| sequential mix | +25.1 % | +23.4 % | +26.9 % |
| random mix | +2.6 % | +3.2 % | +9.1 % |
| row-conflict mix | -12.7 % | +40.0 % | +46.4 % |
| one hot bank | +1.1 % | +178 % | +178 % |
| row walk (every access opens a new row) | **-51.3 %** | **-51.3 %** | **-43.4 %** |
| aligned buffers | +0.0 % | +295 % | +295 % |
| compute-system mix | +11.3 % | +26.1 % | +27.1 % |

Documented default for mixed system traffic: **BANKAWARE with the age override at 1024 cycles**; use FCFS for pure friendly streaming. The losses are real and are kept in the table. The age limit was tuned on seed 1 and
checked on held-out seeds (`reports/BENCHMARKS_heldout_seeds23.md`); the first, untuned measurement is kept (`reports/BENCHMARKS_age256_first_measurement.md`). Tensor starvation is reduced by shaping the
outstanding window, not by arbiter priority (`reports/WINDOW_SHAPING.md`, `reports/PRIORITY.md`).

### Channel scaling (`reports/SCALING.md`)

Sequential read under FCFS: 11.2 -> 22.5 -> 46.0 B/cycle for 1 -> 2 -> 4 lanes (70-72 % of peak). Eight lanes with the default outstanding window reach only 43 % of peak (the sources cannot feed them);
with a larger window, 76 %. 4 channels and 2 x 2 pseudo-channels give identical results because the model has no shared command bus (stated in the report).

### Verification (`docs/VERIFICATION.md`, `reports/regression.md`)

* **Regression: 13 configurations x 3 seeds x 32 scenario runs (23 scenarios; `policy` expands to 10 variants) - all pass**, each against an independent byte-addressable reference memory, per-source scoreboards, an SFMC protocol checker
  and cross-checks of the RTL performance counters. Configurations cover 1 / 2 / 4 channels, pseudo-channels, four address maps, both ordering modes, a jittered and interleaving backend, a backend without SFMC rule C9, and three data widths.
* The independent Python timing checker passes on the command logs of 4 configurations (10 lane logs).
* Negative test: a scheduler built to trust rule C9 over a backend that violates it **fails on 3 of 3 seeds**, as it must.
* `make lint` (Verilator `-Wall` over the RTL, with the style-only waivers of `lint.vlt`) is clean.
* Address-map unit bench: 11 variants pass on Verilator; the four map modes also pass on Icarus. 19 of 19 illegal geometry / parameter combinations are rejected at elaboration.
* **Mutation check: 28 deliberate RTL bugs, 28 killed on the final bench - but read `reports/mutation_analysis.md`.** The first run killed 27 of 28; the survivor (strict FCFS issuing the younger queue head) exposed that no check
  looked at the order commands reach the backend, so a scenario (`fcfs_order`) was added and the same list re-run. The 28 / 28 is therefore not independent evidence; ten mutants are held by a single scenario, and no mutant touches
  the ranking keys of policies 1-3 (their *selection* is not asserted, only their effects are measured: `docs/LIMITATIONS.md`).
* **Not done:** formal proof, coverage collection, gate-level simulation, FPGA, timing / power. The full system bench was not run on Icarus (compile did not finish in 5 minutes); see `reports/CROSSSIM.md`.

### Independent review (`reports/REVIEW.md`, `docs/FINDINGS.md`)

A fresh-context reviewer read the RTL after the regression had passed 39 / 39. Its nine findings were each checked against the code before any change: **six were fixed** (an adapter outstanding counter that leaked,
a timed-out slot that became a permanent zombie on a lane flush, an FCFS deadlock after age-counter saturation, a 2-bit per-source counter, uncounted foreign tags, an unchecked timer width), **three were documented** as
backend-contract violations. Three of the fixes (counter leak, zombie slot, FCFS deadlock) have new bench checks that fail on the pre-fix RTL; the timer width has an elaboration check; the foreign-tag count and the 2-bit counter are fixed by inspection only, because no stimulus reproduced them.

### Synthesis proxy (`reports/SYNTH.md`; Yosys 0.33 generic gates - not area, timing or power)

| block | cells | flip-flops | longest path (levels) |
|---|---|---|---|
| `sf_hbm_scheduler` (primary RTL, one lane) | 13,640 | 252 | 171 |
| lane (queues + scheduler + adapter + arbiter) | 38,162 | 8,071 | 171 |
| response tracker | 149,085 | 14,660 | 108 |
| performance counters | 52,406 | 7,328 | 28 |
| **top, 2 lanes, defaults** | **283,045** | **37,643** | **268** |

No latches; Yosys' CHECK passes on all 19 rows. The tracker is 53 % of the top. The scheduler's pick is the deepest block (171 levels); the top's longest path continues from it into a 48-bit counter increment (inferred from the adder width).
Storage is flip-flop arrays here and belongs in register files / SRAM in silicon. A 4- or 8-lane top and a tracker with 16 outstanding per source were **not synthesised**: Yosys was killed for lack of memory on the 15 GB build machine.

## Index of reports

| file | content |
|---|---|
| `reports/BASELINE_FCFS.md` | the frozen FCFS baseline (measured before any other policy; SHA-256 of the RTL in `reports/bench/`) |
| `reports/BENCHMARKS.md` | policy study with the tuned age limit (3 seeds); `BENCHMARKS_age256_first_measurement.md` is the untuned first measurement, `BENCHMARKS_heldout_seeds23.md` the held-out seeds |
| `reports/PARAM_STUDY.md`, `reports/dse/` | scheduler parameter study (tuned on seed 1 only) |
| `reports/PRIORITY.md`, `reports/WINDOW_SHAPING.md` | arbiter priority and outstanding-window shaping vs tensor-engine starvation |
| `reports/SCALING.md` | 1 / 2 / 4 / 8 lanes (with the model's limits stated) |
| `reports/regression.md` / `.json`, `regression_run.log` | final regression, timing checker, negative test, unit bench, illegal geometry |
| `reports/mutation.md`, `mutation_analysis.md` | mutation check on the final bench and what it does and does not show; `mutation_first_run.md` is the run before `fcfs_order` existed |
| `reports/REVIEW.md` | independent review: nine findings, disposition and evidence |
| `reports/SYNTH.md` / `synth.json` | Yosys statistics |
| `reports/CROSSSIM.md` | what ran on Icarus (unit bench, elaboration) and what did not (full bench) |
| `reports/bench/` | raw benchmark JSON |

Reproduce: `make regress`, `make bench`, `make mutation`, `make synth`, `make crosssim` (all long); every table above is regenerated by the script named in its report.
