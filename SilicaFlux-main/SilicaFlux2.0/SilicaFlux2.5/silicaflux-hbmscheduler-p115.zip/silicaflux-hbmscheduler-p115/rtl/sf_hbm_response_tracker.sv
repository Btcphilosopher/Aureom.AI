// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_response_tracker
//
// Outstanding-transaction table + response re-ordering buffer.  One table slice
// of OUT_PER_SRC slots per source.  A slot is allocated when a request is
// ACCEPTED at a source port (so ordering is defined at the acceptance point) and
// freed when its response has been delivered.  The slot number is part of the
// transaction TAG = {source, slot} that travels to the backend and back, so a
// backend response can never be attributed to the wrong request (no mix-ups):
// the tag of a live transaction is unique and is not reused while the
// transaction (or a timed-out "zombie" of it) is in the table.
//
// Slot states: FREE, QUEUED (in a lane queue), ISSUED (sent to the backend),
// DONE (completed, waiting to be delivered), ZOMBIE (timed out and already
// delivered with ST_ERR_TIMEOUT; the slot stays reserved until the late backend
// response arrives or the lane is flushed, so the late response cannot hit a
// re-allocated slot).
//
// Ordering contract of the delivered responses (ORDER_MODE):
//   0 : per source, strictly in request-acceptance order
//   1 : AXI-like: responses with the SAME id are in order; different ids may
//       overtake each other
// Order relations are kept as an exact per-slice "older-than" bit matrix (no
// wrapping sequence numbers), so they stay correct however long a slot lives.
//
// Read data is assembled directly into the slot (beat index counted here), so
// the backend may interleave the beats of different tags (SFMC rule C5).
// Error responses carry zeroed data.
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_response_tracker #(
  parameter int NUM_SRC     = 5,
  parameter int NUM_LANES   = 2,
  parameter int OUT_PER_SRC = 8,       // power of two >= 2
  parameter int ID_W        = 4,
  parameter int DATA_W      = 128,
  parameter int BURST_LEN   = 2,
  parameter int ORDER_MODE  = 0,
  parameter int TS_W        = 32,
  parameter int BYTES_W     = 16,
  localparam int SLOT_W  = $clog2(OUT_PER_SRC),
  localparam int SRC_W   = (NUM_SRC > 1) ? $clog2(NUM_SRC) : 1,
  localparam int TAG_W   = SRC_W + SLOT_W,
  localparam int LANE_IW = (NUM_LANES > 1) ? $clog2(NUM_LANES) : 1,
  localparam int LINE_W  = DATA_W * BURST_LEN,
  localparam int LIM_W   = SLOT_W + 1
) (
  input  wire logic                           clk,
  input  wire logic                           rst_n,
  input  wire logic [TS_W-1:0]                ts_i,
  input  wire logic [TS_W-1:0]                cfg_timeout,      // 0 = disabled
  input  wire logic [NUM_SRC*LIM_W-1:0]       cfg_out_limit,    // per source, 0 = OUT_PER_SRC
  // ---- allocation (one request per source per cycle)
  output logic [NUM_SRC-1:0]                  alloc_ok_o,
  output logic [NUM_SRC*SLOT_W-1:0]           alloc_slot_o,
  input  wire logic [NUM_SRC-1:0]             a_valid,
  input  wire logic [NUM_SRC*ID_W-1:0]        a_id,
  input  wire logic [NUM_SRC-1:0]             a_we,
  input  wire logic [NUM_SRC*LANE_IW-1:0]     a_lane,
  input  wire logic [NUM_SRC*4-1:0]           a_status,         // 0 = goes to a lane, else immediate error
  input  wire logic [NUM_SRC*BYTES_W-1:0]     a_bytes,          // useful bytes of the request
  // ---- issue events (lane popped the request toward the backend)
  input  wire logic [NUM_LANES-1:0]           iss_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]     iss_tag,
  // ---- backend completions (from the adapters)
  input  wire logic [NUM_LANES-1:0]           rb_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]     rb_tag,
  input  wire logic [NUM_LANES*DATA_W-1:0]    rb_data,
  input  wire logic [NUM_LANES-1:0]           rb_last,
  input  wire logic [NUM_LANES-1:0]           rb_err,
  input  wire logic [NUM_LANES-1:0]           rb_ce,
  input  wire logic [NUM_LANES-1:0]           rb_ue,
  input  wire logic [NUM_LANES-1:0]           rb_dbus,
  input  wire logic [NUM_LANES-1:0]           wr_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]     wr_tag,
  input  wire logic [NUM_LANES-1:0]           wr_err,
  input  wire logic [NUM_LANES-1:0]           flush,
  // ---- responses to the sources
  output logic [NUM_SRC-1:0]                  r_valid,
  input  wire logic [NUM_SRC-1:0]             r_ready,
  output logic [NUM_SRC*ID_W-1:0]             r_id,
  output logic [NUM_SRC-1:0]                  r_we,
  output logic [NUM_SRC*LINE_W-1:0]           r_data,
  output logic [NUM_SRC*4-1:0]                r_status,
  // ---- events for the performance counters
  output logic [NUM_SRC-1:0]                  ev_rsp,
  output logic [NUM_SRC*TS_W-1:0]             ev_lat,
  output logic [NUM_SRC-1:0]                  ev_err_rsp,
  output logic [NUM_SRC*BYTES_W-1:0]          ev_rbytes,
  output logic [NUM_SRC*BYTES_W-1:0]          ev_wbytes,
  output logic [NUM_SRC-1:0]                  ev_reordered,
  output logic [NUM_SRC*8-1:0]                rob_depth_o,
  output logic [NUM_SRC*8-1:0]                ev_qw_cnt,
  output logic [NUM_SRC*16-1:0]               ev_qw_sum,
  output logic [7:0]                          ev_timeout_n,
  output logic [7:0]                          ev_spurious_n,
  output logic [7:0]                          ev_flushed_n,
  output logic [15:0]                         zombie_n_o,
  output logic [15:0]                         out_total_o,
  output logic [NUM_SRC*LIM_W-1:0]            live_cnt_o
);

  // The table is a generate array of per-source slices (sf_hbm_trk_src), each a generate array of slots
  // (sf_hbm_trk_slot).  This module only slices the flat buses and adds up the per-source event counts.
  logic [NUM_SRC*8-1:0]    to_s, sp_s, fl_s;
  logic [NUM_SRC*16-1:0]   zom_s, out_s;

  genvar gs;
  generate
    for (gs = 0; gs < NUM_SRC; gs = gs + 1) begin : g_src
      sf_hbm_trk_src #(
        .SRC(gs), .NUM_SRC(NUM_SRC), .NUM_LANES(NUM_LANES), .OUT_PER_SRC(OUT_PER_SRC), .ID_W(ID_W), .DATA_W(DATA_W),
        .BURST_LEN(BURST_LEN), .ORDER_MODE(ORDER_MODE), .TS_W(TS_W), .BYTES_W(BYTES_W)
      ) u_src (
        .clk(clk), .rst_n(rst_n), .ts_i(ts_i), .cfg_timeout(cfg_timeout), .cfg_limit(cfg_out_limit[gs*LIM_W +: LIM_W]),
        .alloc_ok_o(alloc_ok_o[gs]), .alloc_slot_o(alloc_slot_o[gs*SLOT_W +: SLOT_W]),
        .a_valid(a_valid[gs]), .a_id(a_id[gs*ID_W +: ID_W]), .a_we(a_we[gs]), .a_lane(a_lane[gs*LANE_IW +: LANE_IW]),
        .a_status(a_status[gs*4 +: 4]), .a_bytes(a_bytes[gs*BYTES_W +: BYTES_W]),
        .iss_valid(iss_valid), .iss_tag(iss_tag), .rb_valid(rb_valid), .rb_tag(rb_tag), .rb_data(rb_data), .rb_last(rb_last),
        .rb_err(rb_err), .rb_ce(rb_ce), .rb_ue(rb_ue), .rb_dbus(rb_dbus), .wr_valid(wr_valid), .wr_tag(wr_tag),
        .wr_err(wr_err), .flush(flush),
        .r_valid(r_valid[gs]), .r_ready(r_ready[gs]), .r_id(r_id[gs*ID_W +: ID_W]), .r_we(r_we[gs]),
        .r_data(r_data[gs*LINE_W +: LINE_W]), .r_status(r_status[gs*4 +: 4]),
        .ev_rsp(ev_rsp[gs]), .ev_lat(ev_lat[gs*TS_W +: TS_W]), .ev_err_rsp(ev_err_rsp[gs]),
        .ev_rbytes(ev_rbytes[gs*BYTES_W +: BYTES_W]), .ev_wbytes(ev_wbytes[gs*BYTES_W +: BYTES_W]),
        .ev_reordered(ev_reordered[gs]), .rob_depth_o(rob_depth_o[gs*8 +: 8]), .ev_qw_cnt(ev_qw_cnt[gs*8 +: 8]),
        .ev_qw_sum(ev_qw_sum[gs*16 +: 16]),
        .n_timeout_o(to_s[gs*8 +: 8]), .n_spurious_o(sp_s[gs*8 +: 8]), .n_flushed_o(fl_s[gs*8 +: 8]),
        .n_zombie_o(zom_s[gs*16 +: 16]), .n_out_o(out_s[gs*16 +: 16]), .live_cnt_o(live_cnt_o[gs*LIM_W +: LIM_W])
      );
    end
  endgenerate

  // backend responses whose source field names no source (possible when NUM_SRC is not a power of two) match no slot: count them here
  logic [7:0] foreign_n;
  always_comb begin
    foreign_n = '0;
    for (int l = 0; l < NUM_LANES; l++) begin
      if (rb_valid[l] && ({{(32-SRC_W){1'b0}}, rb_tag[l*TAG_W + SLOT_W +: SRC_W]} >= NUM_SRC)) foreign_n = foreign_n + 1'b1;
      if (wr_valid[l] && ({{(32-SRC_W){1'b0}}, wr_tag[l*TAG_W + SLOT_W +: SRC_W]} >= NUM_SRC)) foreign_n = foreign_n + 1'b1;
    end
  end

  always_comb begin
    ev_timeout_n = '0; ev_spurious_n = foreign_n; ev_flushed_n = '0; zombie_n_o = '0; out_total_o = '0;
    for (int s = 0; s < NUM_SRC; s++) begin
      ev_timeout_n  = ev_timeout_n  + to_s[s*8 +: 8];
      ev_spurious_n = ev_spurious_n + sp_s[s*8 +: 8];
      ev_flushed_n  = ev_flushed_n  + fl_s[s*8 +: 8];
      zombie_n_o    = zombie_n_o    + zom_s[s*16 +: 16];
      out_total_o   = out_total_o   + out_s[s*16 +: 16];
    end
  end

endmodule
`default_nettype wire
