// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_lane
//
// One scheduling domain = one (logical channel, pseudo-channel) pair.
//
//   per-source ingress ──► channel arbiter ──► read queue ─┐
//   (validated, tagged)                        write queue ─┼─► scheduler ──► backend adapter ──► SFMC
//                                                           │        (pick)         (link FSM, FIFOs)
//                         hazard masks (RAW/WAR/WAW) <──────┘
//
// A grant of the arbiter IS the acceptance of the request: the caller (top
// level) has already reserved a response-tracker slot, and the arbiter only
// considers requests whose target queue has room.
//
// Ordering contract with the backend (BE_ORDER_SAFE):
//   1 : the backend executes accesses to overlapping bytes in command-acceptance
//       order (SFMC rule C9).  Hazards are then resolved purely inside the
//       queues: a dependent entry is not issued before its older dependency was
//       ISSUED.
//   0 : the backend gives no such guarantee (e.g. an AXI4 controller with
//       unique ids).  The lane additionally holds an entry back while an
//       in-flight command touches the same granule (reads wait for in-flight
//       writes; writes wait for any in-flight access to the granule) until that
//       command COMPLETES.
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_lane #(
  parameter int NUM_SRC     = 5,
  parameter int TAG_W       = 6,
  parameter int DATA_W      = 128,
  parameter int BURST_LEN   = 2,
  parameter int OFF_W       = 5,
  parameter int COL_W       = 5,
  parameter int BG_W        = 2,
  parameter int BANK_W      = 2,
  parameter int ROW_W       = 8,
  parameter int RQ_DEPTH    = 16,
  parameter int WQ_DEPTH    = 16,
  parameter int AGE_W       = 12,
  parameter int BUSY_W      = 6,
  parameter int BYP_W       = 6,
  parameter int LANE_OUT    = 8,
  parameter int WD_DEPTH    = 4,
  parameter int CMD_DEPTH   = 2,
  parameter int RST_HOLD    = 8,
  parameter int CAL_TIMEOUT = 0,
  parameter int BE_ORDER_SAFE = 1,
  parameter int SHADOW_CLR_BUSY = 1,
  localparam int LA_W    = OFF_W + COL_W + BG_W + BANK_W + ROW_W,
  localparam int GA_W    = LA_W - OFF_W,
  localparam int BK_W    = BG_W + BANK_W,
  localparam int LINE_W  = DATA_W * BURST_LEN,
  localparam int STRB_W  = LINE_W / 8,
  localparam int BSTRB_W = DATA_W / 8,
  localparam int SRC_IW  = (NUM_SRC > 1) ? $clog2(NUM_SRC) : 1,
  localparam int RIDX_W  = (RQ_DEPTH > 1) ? $clog2(RQ_DEPTH) : 1,
  localparam int WIDX_W  = (WQ_DEPTH > 1) ? $clog2(WQ_DEPTH) : 1,
  localparam int RCNT_W  = $clog2(RQ_DEPTH + 1),
  localparam int WCNT_W  = $clog2(WQ_DEPTH + 1),
  localparam int OCNT_W  = $clog2(LANE_OUT + 1),
  localparam int INF_IW  = (LANE_OUT > 1) ? $clog2(LANE_OUT) : 1
) (
  input  wire logic                      clk,
  input  wire logic                      rst_n,
  // ---- runtime configuration
  input  wire logic [2:0]                cfg_policy,
  input  wire logic [WCNT_W-1:0]         cfg_wr_hi,
  input  wire logic [WCNT_W-1:0]         cfg_wr_lo,
  input  wire logic [AGE_W-1:0]          cfg_age_limit,
  input  wire logic                      cfg_idle_wr,
  input  wire logic [BUSY_W-1:0]         cfg_busy_cyc,
  input  wire logic [BYP_W-1:0]          cfg_bypass_cap,
  input  wire logic                      cfg_arb_mode,
  input  wire logic [NUM_SRC*2-1:0]      cfg_arb_prio,
  input  wire logic [7:0]                cfg_arb_age,
  input  wire logic                      cfg_link_retry,
  // ---- ingress (one slot per source; already validated, tagged, mapped to this lane)
  input  wire logic [NUM_SRC-1:0]        in_valid,
  input  wire logic [NUM_SRC-1:0]        in_we,
  input  wire logic [NUM_SRC*TAG_W-1:0]  in_tag,
  input  wire logic [NUM_SRC*LA_W-1:0]   in_la,
  input  wire logic [NUM_SRC*LINE_W-1:0] in_wdata,
  input  wire logic [NUM_SRC*STRB_W-1:0] in_wstrb,
  output logic [NUM_SRC-1:0]             in_gnt,
  output logic [NUM_SRC-1:0]             arb_loss_o,
  // ---- SFMC master
  output logic                           mc_rst_n,
  input  wire logic                      mc_init_done,
  input  wire logic                      mc_fatal,
  output logic                           mc_cmd_valid,
  input  wire logic                      mc_cmd_ready,
  output logic                           mc_cmd_write,
  output logic [LA_W-1:0]                mc_cmd_addr,
  output logic [7:0]                     mc_cmd_len,
  output logic [TAG_W-1:0]               mc_cmd_tag,
  output logic                           mc_wd_valid,
  input  wire logic                      mc_wd_ready,
  output logic [DATA_W-1:0]              mc_wd_data,
  output logic [BSTRB_W-1:0]             mc_wd_strb,
  output logic                           mc_wd_last,
  input  wire logic                      mc_rd_valid,
  output logic                           mc_rd_ready,
  input  wire logic [DATA_W-1:0]         mc_rd_data,
  input  wire logic [TAG_W-1:0]          mc_rd_tag,
  input  wire logic                      mc_rd_last,
  input  wire logic                      mc_rd_error,
  input  wire logic                      mc_wr_valid,
  output logic                           mc_wr_ready,
  input  wire logic [TAG_W-1:0]          mc_wr_tag,
  input  wire logic                      mc_wr_error,
  // ---- optional SFMC-X sideband (tie to 0 if absent)
  input  wire logic                      mc_busy,
  input  wire logic                      mc_rd_ce,
  input  wire logic                      mc_rd_ue,
  input  wire logic                      mc_rd_dbus,
  input  wire logic                      mc_ev_hit,
  input  wire logic                      mc_ev_miss,
  input  wire logic                      mc_ev_conf,
  // ---- toward the response tracker
  output logic                           trk_iss_valid,
  output logic [TAG_W-1:0]               trk_iss_tag,
  output logic                           trk_rb_valid,
  output logic [TAG_W-1:0]               trk_rb_tag,
  output logic [DATA_W-1:0]              trk_rb_data,
  output logic                           trk_rb_last,
  output logic                           trk_rb_err,
  output logic                           trk_rb_ce,
  output logic                           trk_rb_ue,
  output logic                           trk_rb_dbus,
  output logic                           trk_wr_valid,
  output logic [TAG_W-1:0]               trk_wr_tag,
  output logic                           trk_wr_err,
  output logic                           trk_flush,
  // ---- status / events (for the performance counters)
  output logic [RCNT_W-1:0]              rq_count_o,
  output logic [WCNT_W-1:0]              wq_count_o,
  output logic [OCNT_W-1:0]              out_cnt_o,
  output logic [2:0]                     link_state_o,
  output logic                           ev_iss_rd,
  output logic                           ev_iss_wr,
  output logic [AGE_W-1:0]               ev_qw,
  output logic [1:0]                     ev_beats,
  output logic                           ev_hit,
  output logic                           ev_miss,
  output logic                           ev_conf,
  output logic                           ev_be_hit,
  output logic                           ev_be_miss,
  output logic                           ev_be_conf,
  output logic                           ev_bank_conf,
  output logic                           ev_turn,
  output logic                           ev_qfull_rd,
  output logic                           ev_qfull_wr,
  output logic                           ev_ref_stall,
  output logic                           ev_haz_stall,
  output logic                           ev_be_stall,
  output logic                           ev_age_ovr,
  output logic                           ev_byp_ovr,
  output logic                           ev_drain,
  output logic                           ev_link_rst,
  output logic                           ev_unavail,
  output logic                           ev_idle
);

  // ------------------------------------------------------------------ arbiter
  logic              rq_full, wq_full;
  logic [NUM_SRC-1:0] req_elig;
  logic [NUM_SRC-1:0] gnt;
  logic               gnt_v;
  logic [SRC_IW-1:0]  gnt_i;

  always_comb begin
    for (int s = 0; s < NUM_SRC; s++) begin
      req_elig[s] = in_valid[s] && (in_we[s] ? !wq_full : !rq_full);
    end
  end

  sf_hbm_channel_arbiter #(.NUM_SRC(NUM_SRC)) u_arb (
    .clk(clk), .rst_n(rst_n),
    .req_i(req_elig), .cfg_mode(cfg_arb_mode), .cfg_prio(cfg_arb_prio), .cfg_age_lim(cfg_arb_age),
    .gnt_o(gnt), .gnt_valid_o(gnt_v), .gnt_idx_o(gnt_i)
  );
  assign in_gnt = gnt;
  assign arb_loss_o = req_elig & ~gnt;

  // winner's fields
  logic                e_we;
  logic [TAG_W-1:0]    e_tag;
  logic [LINE_W-1:0]   e_data;
  logic [STRB_W-1:0]   e_strb;
  logic [GA_W-1:0]     e_ga;
  logic [BK_W-1:0]     e_bank;
  logic [ROW_W-1:0]    e_row;
  always_comb begin
    e_we   = in_we[gnt_i];
    e_tag  = in_tag[gnt_i*TAG_W +: TAG_W];
    e_data = in_wdata[gnt_i*LINE_W +: LINE_W];
    e_strb = in_wstrb[gnt_i*STRB_W +: STRB_W];
    e_ga   = in_la[gnt_i*LA_W + OFF_W +: GA_W];
    e_bank = e_ga[COL_W +: BK_W];
    e_row  = e_ga[GA_W-1 -: ROW_W];
  end

  // ------------------------------------------------------------------ queues
  logic [RQ_DEPTH-1:0]        rq_valid, rq_ready, rq_pop_oh;
  logic [RQ_DEPTH*BK_W-1:0]   rq_bank;
  logic [RQ_DEPTH*ROW_W-1:0]  rq_row;
  logic [RQ_DEPTH*AGE_W-1:0]  rq_age;
  logic [RQ_DEPTH*GA_W-1:0]   rq_ga;
  logic [TAG_W-1:0]           rq_pop_tag;
  logic [GA_W-1:0]            rq_pop_ga;
  logic [AGE_W-1:0]           rq_pop_age;

  logic [WQ_DEPTH-1:0]        wq_valid, wq_ready, wq_pop_oh;
  logic [WQ_DEPTH*BK_W-1:0]   wq_bank;
  logic [WQ_DEPTH*ROW_W-1:0]  wq_row;
  logic [WQ_DEPTH*AGE_W-1:0]  wq_age;
  logic [WQ_DEPTH*GA_W-1:0]   wq_ga;
  logic [TAG_W-1:0]           wq_pop_tag;
  logic [GA_W-1:0]            wq_pop_ga;
  logic [AGE_W-1:0]           wq_pop_age;
  logic [LINE_W-1:0]          wq_pop_data;
  logic [STRB_W-1:0]          wq_pop_strb;

  logic               pick_v, pick_wr;
  logic [((RIDX_W > WIDX_W) ? RIDX_W : WIDX_W)-1:0] pick_i;
  logic               pop_rd, pop_wr;
  assign pop_rd = pick_v && !pick_wr;
  assign pop_wr = pick_v &&  pick_wr;

  sf_hbm_read_queue #(
    .DEPTH(RQ_DEPTH), .TAG_W(TAG_W), .GA_W(GA_W), .BK_W(BK_W), .ROW_W(ROW_W), .AGE_W(AGE_W), .OTH_D(WQ_DEPTH)
  ) u_rq (
    .clk(clk), .rst_n(rst_n),
    .enq_valid(gnt_v && !e_we), .enq_tag(e_tag), .enq_ga(e_ga), .enq_bank(e_bank), .enq_row(e_row),
    .full_o(rq_full), .count_o(rq_count_o),
    .oth_valid(wq_valid), .oth_ga(wq_ga), .oth_pop(wq_pop_oh),
    .ent_valid(rq_valid), .ent_ready(rq_ready), .ent_bank(rq_bank), .ent_row(rq_row), .ent_age(rq_age), .ent_ga(rq_ga),
    .pop_valid(pop_rd), .pop_idx(pick_i[RIDX_W-1:0]),
    .pop_tag(rq_pop_tag), .pop_ga(rq_pop_ga), .pop_age(rq_pop_age), .pop_oh(rq_pop_oh)
  );

  sf_hbm_write_queue #(
    .DEPTH(WQ_DEPTH), .TAG_W(TAG_W), .GA_W(GA_W), .BK_W(BK_W), .ROW_W(ROW_W), .AGE_W(AGE_W),
    .LINE_W(LINE_W), .STRB_W(STRB_W), .OTH_D(RQ_DEPTH)
  ) u_wq (
    .clk(clk), .rst_n(rst_n),
    .enq_valid(gnt_v && e_we), .enq_tag(e_tag), .enq_ga(e_ga), .enq_bank(e_bank), .enq_row(e_row),
    .enq_data(e_data), .enq_strb(e_strb),
    .full_o(wq_full), .count_o(wq_count_o),
    .oth_valid(rq_valid), .oth_ga(rq_ga), .oth_pop(rq_pop_oh),
    .ent_valid(wq_valid), .ent_ready(wq_ready), .ent_bank(wq_bank), .ent_row(wq_row), .ent_age(wq_age), .ent_ga(wq_ga),
    .pop_valid(pop_wr), .pop_idx(pick_i[WIDX_W-1:0]),
    .pop_tag(wq_pop_tag), .pop_ga(wq_pop_ga), .pop_age(wq_pop_age),
    .pop_data(wq_pop_data), .pop_strb(wq_pop_strb), .pop_oh(wq_pop_oh)
  );

  // ------------------------------------------------------------------ in-flight hazard mask (BE_ORDER_SAFE = 0 only)
  logic [RQ_DEPTH-1:0] rq_blk;
  logic [WQ_DEPTH-1:0] wq_blk;
  logic                a_flush, a_rb_valid, a_rb_last, a_wr_valid;
  logic [TAG_W-1:0]    a_rb_tag, a_wr_tag;
  logic [TAG_W-1:0]    iss_tag_w;
  logic [GA_W-1:0]     iss_ga_w;

  generate
    if (BE_ORDER_SAFE != 0) begin : g_inf_off
      assign rq_blk = '0;
      assign wq_blk = '0;
    end else begin : g_inf_on
      logic              inf_v   [0:LANE_OUT-1];
      logic              inf_we  [0:LANE_OUT-1];
      logic [TAG_W-1:0]  inf_tag [0:LANE_OUT-1];
      logic [GA_W-1:0]   inf_ga  [0:LANE_OUT-1];
      logic [INF_IW-1:0]   free_i;
      logic                free_ok;
      always_comb begin
        free_ok = 1'b0; free_i = '0;
        for (int j = LANE_OUT - 1; j >= 0; j--) begin
          if (!inf_v[j]) begin free_ok = 1'b1; free_i = j[INF_IW-1:0]; end
        end
        for (int i = 0; i < RQ_DEPTH; i++) begin
          rq_blk[i] = 1'b0;
          for (int j = 0; j < LANE_OUT; j++) begin
            if (inf_v[j] && inf_we[j] && inf_ga[j] == rq_ga[i*GA_W +: GA_W]) rq_blk[i] = 1'b1;
          end
        end
        for (int i = 0; i < WQ_DEPTH; i++) begin
          wq_blk[i] = 1'b0;
          for (int j = 0; j < LANE_OUT; j++) begin
            if (inf_v[j] && inf_ga[j] == wq_ga[i*GA_W +: GA_W]) wq_blk[i] = 1'b1;
          end
        end
      end
      always_ff @(posedge clk) begin
        if (!rst_n || a_flush) begin
          for (int j = 0; j < LANE_OUT; j++) begin inf_v[j] <= 1'b0; inf_we[j] <= 1'b0; inf_tag[j] <= '0; inf_ga[j] <= '0; end
        end else begin
          for (int j = 0; j < LANE_OUT; j++) begin
            if (inf_v[j] && ((a_rb_valid && a_rb_last && a_rb_tag == inf_tag[j] && !inf_we[j]) ||
                             (a_wr_valid && a_wr_tag == inf_tag[j] && inf_we[j]))) inf_v[j] <= 1'b0;
          end
          if (pick_v && free_ok) begin
            inf_v[free_i]   <= 1'b1;
            inf_we[free_i]  <= pick_wr;
            inf_tag[free_i] <= iss_tag_w;
            inf_ga[free_i]  <= iss_ga_w;
          end
        end
      end
    end
  endgenerate

  // ------------------------------------------------------------------ scheduler
  logic iss_ok_rd, iss_ok_wr, be_busy;
  logic s_hit, s_miss, s_conf, s_bconf, s_turn, s_aovr, s_drain, s_haz, s_bes, s_refs, drain_o;

  sf_hbm_scheduler #(
    .RQ_DEPTH(RQ_DEPTH), .WQ_DEPTH(WQ_DEPTH), .BK_W(BK_W), .BG_W(BG_W), .ROW_W(ROW_W), .AGE_W(AGE_W),
    .BUSY_W(BUSY_W), .BYP_W(BYP_W), .SHADOW_CLR_BUSY(SHADOW_CLR_BUSY)
  ) u_sched (
    .clk(clk), .rst_n(rst_n),
    .cfg_policy(cfg_policy), .cfg_wr_hi(cfg_wr_hi), .cfg_wr_lo(cfg_wr_lo), .cfg_age_limit(cfg_age_limit),
    .cfg_idle_wr(cfg_idle_wr), .cfg_busy_cyc(cfg_busy_cyc), .cfg_bypass_cap(cfg_bypass_cap),
    .rq_valid(rq_valid), .rq_ready(rq_ready), .rq_bank(rq_bank), .rq_row(rq_row), .rq_age(rq_age),
    .rq_blk(rq_blk), .rq_count(rq_count_o),
    .wq_valid(wq_valid), .wq_ready(wq_ready), .wq_bank(wq_bank), .wq_row(wq_row), .wq_age(wq_age),
    .wq_blk(wq_blk), .wq_count(wq_count_o),
    .iss_ok_rd(iss_ok_rd), .iss_ok_wr(iss_ok_wr), .be_busy(be_busy),
    .pick_valid(pick_v), .pick_wr(pick_wr), .pick_idx(pick_i), .drain_o(drain_o),
    .ev_hit(s_hit), .ev_miss(s_miss), .ev_conf(s_conf), .ev_bank_conf(s_bconf), .ev_turn(s_turn),
    .ev_age_ovr(s_aovr), .ev_byp_ovr(ev_byp_ovr), .ev_drain(s_drain), .ev_haz_stall(s_haz), .ev_be_stall(s_bes), .ev_ref_stall(s_refs)
  );

  // ------------------------------------------------------------------ issue -> adapter
  assign iss_tag_w = pick_wr ? wq_pop_tag : rq_pop_tag;
  assign iss_ga_w  = pick_wr ? wq_pop_ga  : rq_pop_ga;

  sf_hbm_backend_adapter #(
    .TAG_W(TAG_W), .LA_W(LA_W), .DATA_W(DATA_W), .BURST_LEN(BURST_LEN), .LANE_OUT(LANE_OUT),
    .WD_DEPTH(WD_DEPTH), .CMD_DEPTH(CMD_DEPTH), .RST_HOLD(RST_HOLD), .CAL_TIMEOUT(CAL_TIMEOUT)
  ) u_be (
    .clk(clk), .rst_n(rst_n), .cfg_link_retry(cfg_link_retry),
    .iss_ok_rd(iss_ok_rd), .iss_ok_wr(iss_ok_wr),
    .iss_valid(pick_v), .iss_we(pick_wr), .iss_tag(iss_tag_w), .iss_la({iss_ga_w, {OFF_W{1'b0}}}),
    .iss_wdata(wq_pop_data), .iss_wstrb(wq_pop_strb),
    .mc_rst_n(mc_rst_n), .mc_init_done(mc_init_done), .mc_fatal(mc_fatal),
    .mc_cmd_valid(mc_cmd_valid), .mc_cmd_ready(mc_cmd_ready), .mc_cmd_write(mc_cmd_write),
    .mc_cmd_addr(mc_cmd_addr), .mc_cmd_len(mc_cmd_len), .mc_cmd_tag(mc_cmd_tag),
    .mc_wd_valid(mc_wd_valid), .mc_wd_ready(mc_wd_ready), .mc_wd_data(mc_wd_data), .mc_wd_strb(mc_wd_strb),
    .mc_wd_last(mc_wd_last),
    .mc_rd_valid(mc_rd_valid), .mc_rd_ready(mc_rd_ready), .mc_rd_data(mc_rd_data), .mc_rd_tag(mc_rd_tag),
    .mc_rd_last(mc_rd_last), .mc_rd_error(mc_rd_error),
    .mc_wr_valid(mc_wr_valid), .mc_wr_ready(mc_wr_ready), .mc_wr_tag(mc_wr_tag), .mc_wr_error(mc_wr_error),
    .mc_busy(mc_busy), .mc_rd_ce(mc_rd_ce), .mc_rd_ue(mc_rd_ue), .mc_rd_dbus(mc_rd_dbus),
    .rb_valid(a_rb_valid), .rb_tag(a_rb_tag), .rb_data(trk_rb_data), .rb_last(a_rb_last), .rb_err(trk_rb_err),
    .rb_ce(trk_rb_ce), .rb_ue(trk_rb_ue), .rb_dbus(trk_rb_dbus),
    .wr_valid(a_wr_valid), .wr_tag(a_wr_tag), .wr_err(trk_wr_err),
    .flush_o(a_flush),
    .link_state_o(link_state_o), .out_cnt_o(out_cnt_o), .be_busy_o(be_busy),
    .ev_beats(ev_beats), .ev_link_rst(ev_link_rst), .ev_unavail(ev_unavail)
  );

  assign trk_iss_valid = pick_v;
  assign trk_iss_tag   = iss_tag_w;
  assign trk_rb_valid  = a_rb_valid;
  assign trk_rb_tag    = a_rb_tag;
  assign trk_rb_last   = a_rb_last;
  assign trk_wr_valid  = a_wr_valid;
  assign trk_wr_tag    = a_wr_tag;
  assign trk_flush     = a_flush;

  // ------------------------------------------------------------------ events
  assign ev_iss_rd    = pop_rd;
  assign ev_iss_wr    = pop_wr;
  assign ev_qw        = pick_wr ? wq_pop_age : rq_pop_age;
  assign ev_hit       = s_hit;
  assign ev_miss      = s_miss;
  assign ev_conf      = s_conf;
  assign ev_be_hit    = mc_ev_hit;
  assign ev_be_miss   = mc_ev_miss;
  assign ev_be_conf   = mc_ev_conf;
  assign ev_bank_conf = s_bconf;
  assign ev_turn      = s_turn;
  assign ev_qfull_rd  = (|(in_valid & ~in_we)) && rq_full;
  assign ev_qfull_wr  = (|(in_valid &  in_we)) && wq_full;
  assign ev_ref_stall = s_refs;
  assign ev_haz_stall = s_haz;
  assign ev_be_stall  = s_bes;
  assign ev_age_ovr   = s_aovr;
  assign ev_drain     = s_drain;
  assign ev_idle      = (rq_count_o == '0) && (wq_count_o == '0) && (out_cnt_o == '0);

  // (drain_o is observable through ev_drain)
  logic unused_ok;
  assign unused_ok = &{1'b0, drain_o, pick_i[0]};

endmodule
`default_nettype wire
