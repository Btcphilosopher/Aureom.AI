// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_channel_arbiter
//
// Per-lane source arbiter: picks which source's request enters the lane's
// read / write queue this cycle (at most one per cycle).  The caller gates
// req_i with "the target queue has room", so a grant IS an acceptance.
//
//   cfg_mode = 0 : round robin (default) -- long-run fair among requesters
//   cfg_mode = 1 : static priority classes (cfg_prio, 3 = highest) with
//                  AGING: a source that has lost cfg_age_lim consecutive
//                  arbitrations while requesting is promoted above every
//                  class, so a low-priority source cannot starve forever and
//                  a high-priority source is delayed by a bounded amount.
// Ties are broken round robin from the rotating pointer.
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_channel_arbiter #(
  parameter int NUM_SRC = 5,
  parameter int WAIT_W  = 8,
  localparam int SRC_IW = (NUM_SRC > 1) ? $clog2(NUM_SRC) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic [NUM_SRC-1:0]     req_i,
  input  wire logic                   cfg_mode,
  input  wire logic [NUM_SRC*2-1:0]   cfg_prio,
  input  wire logic [WAIT_W-1:0]      cfg_age_lim,
  output logic [NUM_SRC-1:0]          gnt_o,
  output logic                        gnt_valid_o,
  output logic [SRC_IW-1:0]           gnt_idx_o
);

  logic [SRC_IW-1:0] rr_q;
  logic [WAIT_W-1:0] wait_q [0:NUM_SRC-1];

  logic        best_v;
  logic [2:0]  best_c;
  integer      best_i;
  integer      k, idx, rr_i;
  logic [2:0]  cls;

  always_comb begin
    best_v = 1'b0;
    best_c = 3'd0;
    best_i = 0;
    rr_i   = {{(32-SRC_IW){1'b0}}, rr_q};
    for (k = 0; k < NUM_SRC; k = k + 1) begin
      idx = rr_i + k;
      if (idx >= NUM_SRC) idx = idx - NUM_SRC;
      cls = 3'd0;
      if (cfg_mode) begin
        cls = {1'b0, cfg_prio[idx*2 +: 2]};
        if (cfg_age_lim != '0 && wait_q[idx] >= cfg_age_lim) cls = 3'd4;
      end
      if (req_i[idx] && (!best_v || cls > best_c)) begin
        best_v = 1'b1;
        best_c = cls;
        best_i = idx;
      end
    end
  end

  always_comb begin
    gnt_o       = '0;
    gnt_valid_o = best_v;
    gnt_idx_o   = best_i[SRC_IW-1:0];
    if (best_v) gnt_o[best_i] = 1'b1;
  end

  integer s;
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      rr_q <= '0;
      for (s = 0; s < NUM_SRC; s = s + 1) wait_q[s] <= '0;
    end else begin
      if (best_v) rr_q <= (best_i == NUM_SRC - 1) ? '0 : best_i[SRC_IW-1:0] + 1'b1;
      for (s = 0; s < NUM_SRC; s = s + 1) begin
        if (req_i[s] && !gnt_o[s]) begin
          if (wait_q[s] != {WAIT_W{1'b1}}) wait_q[s] <= wait_q[s] + 1'b1;
        end else begin
          wait_q[s] <= '0;
        end
      end
    end
  end

endmodule
`default_nettype wire
