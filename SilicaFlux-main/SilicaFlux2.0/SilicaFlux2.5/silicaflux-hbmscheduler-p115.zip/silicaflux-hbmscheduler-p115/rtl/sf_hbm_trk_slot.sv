// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_trk_slot
//
// ONE slot of the outstanding-transaction table (see sf_hbm_response_tracker.sv
// for the table-level contract).  A slot is fully described by its own registers;
// everything it needs to know about its neighbours arrives through three small
// vectors from the source slice (ids of all slots, "gone", "leave").
//
//   states : FREE -> QUEUED -> ISSUED -> DONE -> (delivered) FREE
//                                  \-> DONE with tz (timeout) -> (delivered) ZOMBIE -> FREE
//   the slot matches backend events by its constant tag {SRC, SLOT} and by lane.
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_trk_slot #(
  parameter int SRC         = 0,
  parameter int SLOT        = 0,
  parameter int NUM_SRC     = 5,
  parameter int NUM_LANES   = 2,
  parameter int OUT_PER_SRC = 8,
  parameter int ID_W        = 4,
  parameter int DATA_W      = 128,
  parameter int BURST_LEN   = 2,
  parameter int ORDER_MODE  = 0,
  parameter int TS_W        = 32,
  parameter int BYTES_W     = 16,
  localparam int SLOT_W  = $clog2(OUT_PER_SRC),
  localparam int SRC_W   = (NUM_SRC > 1) ? $clog2(NUM_SRC) : 1,
  localparam int TAG_W   = SRC_W + SLOT_W,
  localparam int LANE_IW = (NUM_LANES > 1) ? $clog2(NUM_LANES) : 1,
  localparam int LINE_W  = DATA_W * BURST_LEN,
  localparam int BEAT_W  = $clog2(BURST_LEN + 1)
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  input  wire logic [TS_W-1:0]              ts_i,
  input  wire logic [TS_W-1:0]              cfg_timeout,
  // ---- allocation
  input  wire logic                         a_en,
  input  wire logic [ID_W-1:0]              a_id,
  input  wire logic                         a_we,
  input  wire logic [LANE_IW-1:0]           a_lane,
  input  wire logic [3:0]                   a_status,
  input  wire logic [BYTES_W-1:0]           a_bytes,
  input  wire logic [OUT_PER_SRC-1:0]       a_ord,
  // ---- events of every lane
  input  wire logic [NUM_LANES-1:0]         iss_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]   iss_tag,
  input  wire logic [NUM_LANES-1:0]         rb_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]   rb_tag,
  input  wire logic [NUM_LANES*DATA_W-1:0]  rb_data,
  input  wire logic [NUM_LANES-1:0]         rb_last,
  input  wire logic [NUM_LANES-1:0]         rb_err,
  input  wire logic [NUM_LANES-1:0]         rb_ce,
  input  wire logic [NUM_LANES-1:0]         rb_ue,
  input  wire logic [NUM_LANES-1:0]         rb_dbus,
  input  wire logic [NUM_LANES-1:0]         wr_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]   wr_tag,
  input  wire logic [NUM_LANES-1:0]         wr_err,
  input  wire logic [NUM_LANES-1:0]         flush,
  // ---- ordering context from the source slice
  input  wire logic [OUT_PER_SRC*ID_W-1:0]  ids_i,
  input  wire logic [OUT_PER_SRC-1:0]       gone_i,
  input  wire logic [OUT_PER_SRC-1:0]       leave_i,
  // ---- state / status outputs
  output logic [2:0]                        st_o,
  output logic [ID_W-1:0]                   id_o,
  output logic                              we_o,
  output logic [3:0]                        stat_o,
  output logic [BYTES_W-1:0]                bytes_o,
  output logic [TS_W-1:0]                   tacc_o,
  output logic [LINE_W-1:0]                 data_o,
  output logic                              blkseen_o,
  output logic [OUT_PER_SRC-1:0]            ord_o,
  output logic                              blocked_o,
  output logic                              elig_o,
  output logic                              live_o,
  output logic                              iss_ev_o,
  output logic                              ev_to_o,
  output logic                              ev_sp_o,
  output logic                              ev_fl_o,
  output logic                              zombie_o
);

  localparam logic [2:0] S_FREE = 3'd0, S_QUEUED = 3'd1, S_ISSUED = 3'd2, S_DONE = 3'd3, S_ZOMBIE = 3'd4;
  localparam logic [TAG_W-1:0] MYTAG = {SRC[SRC_W-1:0], SLOT[SLOT_W-1:0]};

  logic [2:0]         st_q;
  logic [ID_W-1:0]    id_q;
  logic               we_q;
  logic [LANE_IW-1:0] lane_q;
  logic [3:0]         stat_q;
  logic               f_err_q, f_ce_q, f_ue_q, f_db_q, tz_q, late_q, blk_q;
  logic [BEAT_W-1:0]  beat_q;
  logic [BYTES_W-1:0] bytes_q;
  logic [TS_W-1:0]    tacc_q, tiss_q;
  logic [LINE_W-1:0]  data_q;
  logic [OUT_PER_SRC-1:0] ord_q;

  // ------------------------------------------------------------------ event decode
  logic               evr, evw, evi, flsh;
  logic [LANE_IW-1:0] lsel;
  logic               l_last, l_err, l_ce, l_ue, l_db;
  logic [DATA_W-1:0]  l_data;
  logic               rsp_hit;

  always_comb begin
    evr = 1'b0; evw = 1'b0; evi = 1'b0; flsh = 1'b0; lsel = '0;
    l_last = 1'b0; l_err = 1'b0; l_ce = 1'b0; l_ue = 1'b0; l_db = 1'b0; l_data = '0;
    for (int l = 0; l < NUM_LANES; l++) begin
      if (rb_valid[l] && rb_tag[l*TAG_W +: TAG_W] == MYTAG && !(evr || evw)) begin
        evr = 1'b1; lsel = l[LANE_IW-1:0]; l_last = rb_last[l]; l_err = rb_err[l];
        l_ce = rb_ce[l]; l_ue = rb_ue[l]; l_db = rb_dbus[l]; l_data = rb_data[l*DATA_W +: DATA_W];
      end
      if (wr_valid[l] && wr_tag[l*TAG_W +: TAG_W] == MYTAG && !(evr || evw)) begin
        evw = 1'b1; lsel = l[LANE_IW-1:0]; l_err = wr_err[l];
      end
      if (iss_valid[l] && iss_tag[l*TAG_W +: TAG_W] == MYTAG) evi = 1'b1;
      if (flush[l] && lane_q == l[LANE_IW-1:0]) flsh = 1'b1;
    end
    rsp_hit = (evr || evw) && (lsel == lane_q);
  end

  // ------------------------------------------------------------------ ordering
  logic [OUT_PER_SRC-1:0] sm;
  logic                   blocked, deliver;
  always_comb begin
    for (int j = 0; j < OUT_PER_SRC; j++) begin
      sm[j] = (ORDER_MODE == 0) ? 1'b1 : (ids_i[j*ID_W +: ID_W] == id_q);
    end
    blocked = |(ord_q & sm & ~gone_i);
    deliver = leave_i[SLOT];
  end

  // ------------------------------------------------------------------ next state
  logic [2:0]         st_n;
  logic [3:0]         stat_n;
  logic               f_err_n, f_ce_n, f_ue_n, f_db_n, tz_n, late_n;
  logic [BEAT_W-1:0]  beat_n;
  logic               beat_wr;
  logic [BEAT_W-1:0]  beat_ix;
  logic               o_to, o_sp, o_fl;

  always_comb begin
    st_n = st_q; stat_n = stat_q; f_err_n = f_err_q; f_ce_n = f_ce_q; f_ue_n = f_ue_q; f_db_n = f_db_q;
    tz_n = tz_q; late_n = late_q; beat_n = beat_q; beat_wr = 1'b0; beat_ix = '0;
    o_to = 1'b0; o_sp = 1'b0; o_fl = 1'b0;
    case (st_q)
      S_QUEUED: begin
        if (evi) st_n = S_ISSUED;
        if (evr || evw) o_sp = 1'b1;                         // a response for a request that was never issued
      end
      S_ISSUED: begin
        if (evr && rsp_hit && !we_q) begin
          if (beat_q < BURST_LEN[BEAT_W-1:0]) begin beat_wr = 1'b1; beat_ix = beat_q; end
          beat_n  = (beat_q == {BEAT_W{1'b1}}) ? beat_q : beat_q + 1'b1;
          f_err_n = f_err_q | l_err;
          f_ce_n  = f_ce_q  | l_ce;
          f_ue_n  = f_ue_q  | l_ue;
          f_db_n  = f_db_q  | l_db;
          if (l_last) begin
            if (beat_q + 1'b1 != BURST_LEN[BEAT_W-1:0]) f_err_n = 1'b1;           // framing error
            st_n = S_DONE;
            if (f_ue_n)       stat_n = `SF_HBM_ST_ERR_ECC_UE;
            else if (f_db_n)  stat_n = `SF_HBM_ST_ERR_DBUS;
            else if (f_err_n) stat_n = `SF_HBM_ST_ERR_BE;
            else if (f_ce_n)  stat_n = `SF_HBM_ST_OK_ECC_CE;
            else              stat_n = `SF_HBM_ST_OK;
          end
        end else if (evw && rsp_hit && we_q) begin
          st_n   = S_DONE;
          stat_n = l_err ? `SF_HBM_ST_ERR_BE : `SF_HBM_ST_OK;
        end else if (evr || evw) begin
          o_sp = 1'b1;                                       // wrong kind / wrong lane
        end else if (flsh) begin
          st_n = S_DONE; stat_n = `SF_HBM_ST_ERR_FLUSH; o_fl = 1'b1;
        end else if (cfg_timeout != '0 && (ts_i - tiss_q) >= cfg_timeout) begin
          st_n = S_DONE; stat_n = `SF_HBM_ST_ERR_TIMEOUT; tz_n = 1'b1; o_to = 1'b1;
        end
      end
      S_DONE: begin
        if ((evr || evw) && tz_q && rsp_hit) begin
          // the late answer of a timed-out transaction that is still waiting for its (error) delivery
          if (evw || l_last) late_n = 1'b1;
        end else if (evr || evw) o_sp = 1'b1;               // extra beat / response after completion
        // the controller was reset by a lane flush: no late answer can ever come, so the timed-out slot must not become a zombie
        if (flsh && tz_q) late_n = 1'b1;
        if (deliver) st_n = (tz_q && !late_n) ? S_ZOMBIE : S_FREE;
      end
      S_ZOMBIE: begin
        if ((evr || evw) && rsp_hit) begin
          if (evw || l_last) st_n = S_FREE;                  // the late response arrived: slot reusable
        end else if (flsh) st_n = S_FREE;
      end
      default: begin                                          // FREE
        if (evr || evw) o_sp = 1'b1;
      end
    endcase
  end

  // ------------------------------------------------------------------ registers
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st_q <= S_FREE; id_q <= '0; we_q <= 1'b0; lane_q <= '0; stat_q <= '0;
      f_err_q <= 1'b0; f_ce_q <= 1'b0; f_ue_q <= 1'b0; f_db_q <= 1'b0; tz_q <= 1'b0; late_q <= 1'b0; blk_q <= 1'b0;
      beat_q <= '0; bytes_q <= '0; tacc_q <= '0; tiss_q <= '0; data_q <= '0; ord_q <= '0;
    end else begin
      st_q    <= st_n;
      stat_q  <= stat_n;
      f_err_q <= f_err_n; f_ce_q <= f_ce_n; f_ue_q <= f_ue_n; f_db_q <= f_db_n;
      tz_q    <= tz_n;
      late_q  <= late_n;
      beat_q  <= beat_n;
      if (evi && st_q == S_QUEUED) tiss_q <= ts_i;
      if (beat_wr) data_q[beat_ix*DATA_W +: DATA_W] <= l_data;
      ord_q   <= ord_q & ~leave_i;                           // entries leaving the live set this cycle are no longer "older"
      if (st_q == S_DONE && blocked) blk_q <= 1'b1;
      if (a_en) begin                                        // allocation (the slot is FREE by construction)
        id_q    <= a_id;
        we_q    <= a_we;
        lane_q  <= a_lane;
        bytes_q <= a_bytes;
        tacc_q  <= ts_i;
        tiss_q  <= ts_i;
        f_err_q <= 1'b0; f_ce_q <= 1'b0; f_ue_q <= 1'b0; f_db_q <= 1'b0;
        tz_q    <= 1'b0; late_q <= 1'b0; blk_q <= 1'b0; beat_q <= '0;
        ord_q   <= a_ord;
        if (a_status == `SF_HBM_ST_OK) begin st_q <= S_QUEUED; stat_q <= `SF_HBM_ST_OK; end
        else                           begin st_q <= S_DONE;   stat_q <= a_status;      end
      end
    end
  end

  // ------------------------------------------------------------------ outputs
  assign st_o      = st_q;
  assign id_o      = id_q;
  assign we_o      = we_q;
  assign stat_o    = stat_q;
  assign bytes_o   = bytes_q;
  assign tacc_o    = tacc_q;
  assign data_o    = data_q;
  assign blkseen_o = blk_q;
  assign ord_o     = ord_q;
  assign blocked_o = blocked;
  assign elig_o    = (st_q == S_DONE) && !gone_i[SLOT] && !blocked;
  assign live_o    = (st_q == S_QUEUED) || (st_q == S_ISSUED) || (st_q == S_DONE);
  assign iss_ev_o  = evi && (st_q == S_QUEUED);
  assign ev_to_o   = o_to;
  assign ev_sp_o   = o_sp;
  assign ev_fl_o   = o_fl;
  assign zombie_o  = (st_q == S_ZOMBIE);

endmodule
`default_nettype wire
