// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_req_check
//
// Request validation (combinational), one instance per source port.
//   1. address inside the mapped window            -> ST_ERR_ADDR
//   2. address aligned to the access granule       -> ST_ERR_ALIGN
//   3. permission window (when cfg_perm_en = 1)    -> ST_ERR_PERM
//   4. write with a non-zero byte-enable mask      -> ST_ERR_STRB
// The first failing check (in that order) is reported.  A rejected request
// never reaches a lane queue and never touches memory; it still receives an
// ordered error response (the tracker allocates a slot for it).
//
// Permission model: NUM_WIN windows [base, last] (inclusive byte addresses).
// A request is allowed iff some window contains the whole access granule and
// grants this source the needed right (read or write).  cfg_perm_en = 0 (reset
// default of the top level) disables the check.
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_req_check #(
  parameter int ADDR_W      = 32,
  parameter int NUM_SRC     = 5,
  parameter int SRC_IDX     = 0,
  parameter int BURST_BYTES = 32,
  parameter int NUM_WIN     = 4
) (
  input  wire logic                           we_i,
  input  wire logic [ADDR_W-1:0]              addr_i,
  input  wire logic [BURST_BYTES-1:0]         wstrb_i,
  input  wire logic                           in_range_i,
  input  wire logic                           aligned_i,
  input  wire logic                           cfg_perm_en,
  input  wire logic [NUM_WIN*ADDR_W-1:0]      cfg_win_base,
  input  wire logic [NUM_WIN*ADDR_W-1:0]      cfg_win_last,
  input  wire logic [NUM_WIN*NUM_SRC*2-1:0]   cfg_win_perm,   // [(w*NUM_SRC+s)*2] = read, +1 = write
  output logic                                ok_o,
  output logic [3:0]                          status_o
);

  localparam logic [ADDR_W:0] BM1 = BURST_BYTES - 1;
  logic perm_ok;
  logic [ADDR_W:0] a_first, a_last;

  always_comb begin
    perm_ok = 1'b0;
    a_first = {1'b0, addr_i};
    a_last  = {1'b0, addr_i} + BM1;
    for (int w = 0; w < NUM_WIN; w++) begin
      if ({1'b0, cfg_win_base[w*ADDR_W +: ADDR_W]} <= a_first &&
          a_last <= {1'b0, cfg_win_last[w*ADDR_W +: ADDR_W]} &&
          cfg_win_perm[(w*NUM_SRC + SRC_IDX)*2 + (we_i ? 1 : 0)]) begin
        perm_ok = 1'b1;
      end
    end
  end

  always_comb begin
    ok_o     = 1'b1;
    status_o = `SF_HBM_ST_OK;
    if (!in_range_i) begin
      ok_o = 1'b0; status_o = `SF_HBM_ST_ERR_ADDR;
    end else if (!aligned_i) begin
      ok_o = 1'b0; status_o = `SF_HBM_ST_ERR_ALIGN;
    end else if (cfg_perm_en && !perm_ok) begin
      ok_o = 1'b0; status_o = `SF_HBM_ST_ERR_PERM;
    end else if (we_i && (wstrb_i == '0)) begin
      ok_o = 1'b0; status_o = `SF_HBM_ST_ERR_STRB;
    end
  end

endmodule
`default_nettype wire
