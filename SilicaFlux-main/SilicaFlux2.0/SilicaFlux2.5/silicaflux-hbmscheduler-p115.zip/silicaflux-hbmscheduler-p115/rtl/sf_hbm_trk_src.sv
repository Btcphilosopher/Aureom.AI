// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_trk_src
//
// The table slice of ONE source: OUT_PER_SRC slots (sf_hbm_trk_slot) plus
//   * allocation: first free slot, per-source outstanding limit
//   * ordering  : exact "older-than" matrix rows live in the slots; here the eligible
//                 set is formed and the single OLDEST eligible slot is picked
//   * response register: the picked slot is loaded into a registered response
//                 channel (stable under back-pressure), next pick computed while it is presented
//   * event outputs for the performance counters
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_trk_src #(
  parameter int SRC         = 0,
  parameter int NUM_SRC     = 5,
  parameter int NUM_LANES   = 2,
  parameter int OUT_PER_SRC = 8,
  parameter int ID_W        = 4,
  parameter int DATA_W      = 128,
  parameter int BURST_LEN   = 2,
  parameter int ORDER_MODE  = 0,
  parameter int TS_W        = 32,
  parameter int BYTES_W     = 16,
  localparam int SLOT_W  = $clog2(OUT_PER_SRC),
  localparam int SRC_W   = (NUM_SRC > 1) ? $clog2(NUM_SRC) : 1,
  localparam int TAG_W   = SRC_W + SLOT_W,
  localparam int LANE_IW = (NUM_LANES > 1) ? $clog2(NUM_LANES) : 1,
  localparam int LINE_W  = DATA_W * BURST_LEN,
  localparam int LIM_W   = SLOT_W + 1
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  input  wire logic [TS_W-1:0]              ts_i,
  input  wire logic [TS_W-1:0]              cfg_timeout,
  input  wire logic [LIM_W-1:0]             cfg_limit,         // 0 = OUT_PER_SRC
  // ---- allocation
  output logic                              alloc_ok_o,
  output logic [SLOT_W-1:0]                 alloc_slot_o,
  input  wire logic                         a_valid,
  input  wire logic [ID_W-1:0]              a_id,
  input  wire logic                         a_we,
  input  wire logic [LANE_IW-1:0]           a_lane,
  input  wire logic [3:0]                   a_status,
  input  wire logic [BYTES_W-1:0]           a_bytes,
  // ---- lane events (full buses)
  input  wire logic [NUM_LANES-1:0]         iss_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]   iss_tag,
  input  wire logic [NUM_LANES-1:0]         rb_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]   rb_tag,
  input  wire logic [NUM_LANES*DATA_W-1:0]  rb_data,
  input  wire logic [NUM_LANES-1:0]         rb_last,
  input  wire logic [NUM_LANES-1:0]         rb_err,
  input  wire logic [NUM_LANES-1:0]         rb_ce,
  input  wire logic [NUM_LANES-1:0]         rb_ue,
  input  wire logic [NUM_LANES-1:0]         rb_dbus,
  input  wire logic [NUM_LANES-1:0]         wr_valid,
  input  wire logic [NUM_LANES*TAG_W-1:0]   wr_tag,
  input  wire logic [NUM_LANES-1:0]         wr_err,
  input  wire logic [NUM_LANES-1:0]         flush,
  // ---- response channel
  output logic                              r_valid,
  input  wire logic                         r_ready,
  output logic [ID_W-1:0]                   r_id,
  output logic                              r_we,
  output logic [LINE_W-1:0]                 r_data,
  output logic [3:0]                        r_status,
  // ---- events
  output logic                              ev_rsp,
  output logic [TS_W-1:0]                   ev_lat,
  output logic                              ev_err_rsp,
  output logic [BYTES_W-1:0]                ev_rbytes,
  output logic [BYTES_W-1:0]                ev_wbytes,
  output logic                              ev_reordered,
  output logic [7:0]                        rob_depth_o,
  output logic [7:0]                        ev_qw_cnt,
  output logic [15:0]                       ev_qw_sum,
  output logic [7:0]                        n_timeout_o,
  output logic [7:0]                        n_spurious_o,
  output logic [7:0]                        n_flushed_o,
  output logic [15:0]                       n_zombie_o,
  output logic [15:0]                       n_out_o,
  output logic [LIM_W-1:0]                  live_cnt_o
);

  localparam logic [2:0] S_FREE = 3'd0, S_DONE = 3'd3;

  // ------------------------------------------------------------------ slot array (flat vectors)
  logic [OUT_PER_SRC*3-1:0]         s_st;
  logic [OUT_PER_SRC*ID_W-1:0]      s_id;
  logic [OUT_PER_SRC-1:0]           s_we, s_blkseen, s_blocked, s_elig, s_live, s_iss, s_to, s_sp, s_fl, s_zom;
  logic [OUT_PER_SRC*4-1:0]         s_stat;
  logic [OUT_PER_SRC*BYTES_W-1:0]   s_bytes;
  logic [OUT_PER_SRC*TS_W-1:0]      s_tacc;
  logic [OUT_PER_SRC*LINE_W-1:0]    s_data;
  logic [OUT_PER_SRC*OUT_PER_SRC-1:0] s_ord;

  logic                             sel_v_q;
  logic [SLOT_W-1:0]                sel_slot_q;
  logic [OUT_PER_SRC-1:0]           gone_m, leave_m, a_en_m;
  logic [OUT_PER_SRC-1:0]           live_m;
  logic [SLOT_W-1:0]                free_slot;
  logic                             free_ok;
  logic [LIM_W-1:0]                 live_n, lim_eff;
  logic [OUT_PER_SRC-1:0]           elig_m;
  logic                             pick_v;
  logic [SLOT_W-1:0]                pick_slot;

  genvar gk;
  generate
    for (gk = 0; gk < OUT_PER_SRC; gk = gk + 1) begin : g_slot
      sf_hbm_trk_slot #(
        .SRC(SRC), .SLOT(gk), .NUM_SRC(NUM_SRC), .NUM_LANES(NUM_LANES), .OUT_PER_SRC(OUT_PER_SRC), .ID_W(ID_W),
        .DATA_W(DATA_W), .BURST_LEN(BURST_LEN), .ORDER_MODE(ORDER_MODE), .TS_W(TS_W), .BYTES_W(BYTES_W)
      ) u_slot (
        .clk(clk), .rst_n(rst_n), .ts_i(ts_i), .cfg_timeout(cfg_timeout),
        .a_en(a_en_m[gk]), .a_id(a_id), .a_we(a_we), .a_lane(a_lane), .a_status(a_status), .a_bytes(a_bytes), .a_ord(live_m & ~leave_m),
        .iss_valid(iss_valid), .iss_tag(iss_tag), .rb_valid(rb_valid), .rb_tag(rb_tag), .rb_data(rb_data), .rb_last(rb_last),
        .rb_err(rb_err), .rb_ce(rb_ce), .rb_ue(rb_ue), .rb_dbus(rb_dbus), .wr_valid(wr_valid), .wr_tag(wr_tag),
        .wr_err(wr_err), .flush(flush),
        .ids_i(s_id), .gone_i(gone_m), .leave_i(leave_m),
        .st_o(s_st[gk*3 +: 3]), .id_o(s_id[gk*ID_W +: ID_W]), .we_o(s_we[gk]), .stat_o(s_stat[gk*4 +: 4]),
        .bytes_o(s_bytes[gk*BYTES_W +: BYTES_W]), .tacc_o(s_tacc[gk*TS_W +: TS_W]), .data_o(s_data[gk*LINE_W +: LINE_W]),
        .blkseen_o(s_blkseen[gk]), .ord_o(s_ord[gk*OUT_PER_SRC +: OUT_PER_SRC]), .blocked_o(s_blocked[gk]),
        .elig_o(s_elig[gk]), .live_o(s_live[gk]), .iss_ev_o(s_iss[gk]), .ev_to_o(s_to[gk]), .ev_sp_o(s_sp[gk]),
        .ev_fl_o(s_fl[gk]), .zombie_o(s_zom[gk])
      );
    end
  endgenerate

  // ------------------------------------------------------------------ slice-level logic
  always_comb begin
    for (int k = 0; k < OUT_PER_SRC; k++) begin
      gone_m[k]  = sel_v_q && (sel_slot_q == k[SLOT_W-1:0]);
      leave_m[k] = sel_v_q && r_ready && (sel_slot_q == k[SLOT_W-1:0]);
    end
  end

  always_comb begin
    live_m  = s_live;
    elig_m  = s_elig;
    free_ok = 1'b0; free_slot = '0; live_n = '0;
    for (int k = OUT_PER_SRC - 1; k >= 0; k--) begin
      if (s_st[k*3 +: 3] == S_FREE) begin free_ok = 1'b1; free_slot = k[SLOT_W-1:0]; end
      if (s_live[k]) live_n = live_n + 1'b1;
    end
    lim_eff = cfg_limit;
    if (cfg_limit == '0) lim_eff = OUT_PER_SRC[LIM_W-1:0];
    alloc_ok_o   = free_ok && (live_n < lim_eff);
    alloc_slot_o = free_slot;
    live_cnt_o   = live_n;
    for (int k = 0; k < OUT_PER_SRC; k++) a_en_m[k] = a_valid && (free_slot == k[SLOT_W-1:0]);

    // oldest eligible slot: no OTHER eligible slot is older than it (the older-than relation is a total order on live slots)
    pick_v = 1'b0; pick_slot = '0;
    for (int k = 0; k < OUT_PER_SRC; k++) begin
      if (s_elig[k] && ((s_ord[k*OUT_PER_SRC +: OUT_PER_SRC] & ~gone_m & elig_m) == '0)) begin
        pick_v = 1'b1; pick_slot = k[SLOT_W-1:0];
      end
    end
  end

  // ------------------------------------------------------------------ registered response channel
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      sel_v_q <= 1'b0; sel_slot_q <= '0;
    end else if (!sel_v_q || r_ready) begin
      sel_v_q <= pick_v; sel_slot_q <= pick_slot;
    end
  end

  logic [3:0]          sel_stat;
  logic [BYTES_W-1:0]  sel_bytes;
  logic [TS_W-1:0]     sel_tacc;
  logic                sel_we, sel_blk;
  logic [ID_W-1:0]     sel_id;
  logic [LINE_W-1:0]   sel_data;
  always_comb begin
    sel_id    = s_id[sel_slot_q*ID_W +: ID_W];
    sel_we    = s_we[sel_slot_q];
    sel_stat  = s_stat[sel_slot_q*4 +: 4];
    sel_bytes = s_bytes[sel_slot_q*BYTES_W +: BYTES_W];
    sel_tacc  = s_tacc[sel_slot_q*TS_W +: TS_W];
    sel_blk   = s_blkseen[sel_slot_q];
    sel_data  = s_data[sel_slot_q*LINE_W +: LINE_W];
    r_valid   = sel_v_q;
    r_id      = sel_id;
    r_we      = sel_we;
    r_status  = sel_stat;
    r_data    = (sel_stat >= 4'd2 || sel_we) ? '0 : sel_data;
  end

  // ------------------------------------------------------------------ events
  logic deliver;
  logic [BYTES_W-1:0] rb_b, wb_b;
  logic [7:0] rd_depth, to_n, sp_n, fl_n;
  logic [15:0] zom_n, out_n;
  logic [7:0] qw_c;
  logic [31:0] qw_s, qw_one;
  always_comb begin
    deliver      = sel_v_q && r_ready;
    ev_rsp       = deliver;
    ev_lat       = ts_i - sel_tacc;
    ev_err_rsp   = deliver && (sel_stat >= 4'd2);
    rb_b = '0; wb_b = '0;
    if (deliver && sel_stat < 4'd2) begin
      if (sel_we) wb_b = sel_bytes; else rb_b = sel_bytes;
    end
    ev_rbytes    = rb_b;
    ev_wbytes    = wb_b;
    ev_reordered = deliver && sel_blk;
    rd_depth = '0; to_n = '0; sp_n = '0; fl_n = '0; zom_n = '0; out_n = '0; qw_c = '0; qw_s = '0; qw_one = '0;
    for (int k = 0; k < OUT_PER_SRC; k++) begin
      if (s_st[k*3 +: 3] == S_DONE && s_blocked[k] && !gone_m[k]) rd_depth = rd_depth + 1'b1;
      to_n  = to_n  + {7'd0, s_to[k]};
      sp_n  = sp_n  + {7'd0, s_sp[k]};
      fl_n  = fl_n  + {7'd0, s_fl[k]};
      zom_n = zom_n + {15'd0, s_zom[k]};
      if (s_st[k*3 +: 3] != S_FREE && !s_zom[k]) out_n = out_n + 1'b1;
      if (s_iss[k]) begin
        qw_c   = qw_c + 1'b1;
        qw_one = {{(32-TS_W){1'b0}}, ts_i - s_tacc[k*TS_W +: TS_W]};
        qw_s   = qw_s + ((qw_one > 32'd65535) ? 32'd65535 : qw_one);
      end
    end
    rob_depth_o  = rd_depth;
    ev_qw_cnt    = qw_c;
    ev_qw_sum    = (qw_s > 32'd65535) ? 16'hFFFF : qw_s[15:0];
    n_timeout_o  = to_n;
    n_spurious_o = sp_n;
    n_flushed_o  = fl_n;
    n_zombie_o   = zom_n;
    n_out_o      = out_n;
  end

endmodule
`default_nettype wire
