// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_backend_adapter
//
// The ONLY place where the scheduler touches a memory controller.  One instance
// per lane.  Controller side = SFMC, the generic memory-controller contract of
// the SilicaFlux MemoryBridge (P24, docs/MC_INTERFACE.md rules C1..C11), plus an
// OPTIONAL sideband ("SFMC-X", all inputs may be tied to 0):
//     mc_busy      refresh / maintenance in progress (owned by the controller)
//     mc_rd_ce     corrected-ECC flag, aligned with a read beat
//     mc_rd_ue     uncorrectable-ECC flag, aligned with a read beat
//     mc_rd_dbus   data-bus error flag, aligned with a read beat
// A vendor HBM controller (AXI4 user port, DFI to the PHY) is reached through a
// *separate* SFMC->AXI4 adapter, exactly as in P24 (MC_INTERFACE.md 5.3); that
// adapter must provide ordering rule C9 (or this lane must be built with
// BE_ORDER_SAFE = 0, see sf_hbm_lane).  No vendor adapter is delivered here.
//
// What this block does
//   * link FSM: RESET (mc_rst_n low, RST_HOLD cycles) -> CAL (wait for
//     mc_init_done, optional timeout) -> READY -> FLUSH (controller lost
//     calibration / fatal: in-flight transactions are failed upstream through
//     flush_o) -> RESET ...   Nothing is issued unless the state is READY.
//   * command FIFO (CMD_DEPTH) and write-data FIFO (WD_DEPTH lines): a write
//     command is pushed together with its whole burst (LINE_W bits); the burst
//     is serialised into BURST_LEN beats of DATA_W bits AFTER its command was
//     accepted (rule C7).
//   * outstanding limit LANE_OUT (issued, not yet completed).
//   * read beats / write responses are forwarded unbuffered (mc_rd_ready and
//     mc_wr_ready are held 1: the tracker has storage for every issued read).
//     Responses seen while the link is not READY are dropped (the controller is
//     in reset; anything it still says is stale).
// Clocking: single clock domain.  If the controller's user clock differs, put a
// P24-style async bridge between this block and the controller
// (docs/HARDWARE_INTEGRATION.md).
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_backend_adapter #(
  parameter int TAG_W       = 6,
  parameter int LA_W        = 24,
  parameter int DATA_W      = 128,
  parameter int BURST_LEN   = 2,
  parameter int LANE_OUT    = 8,
  parameter int WD_DEPTH    = 4,
  parameter int CMD_DEPTH   = 2,
  parameter int RST_HOLD    = 8,
  parameter int CAL_TIMEOUT = 0,
  localparam int LINE_W  = DATA_W * BURST_LEN,
  localparam int STRB_W  = LINE_W / 8,
  localparam int BSTRB_W = DATA_W / 8,
  localparam int BEAT_W  = (BURST_LEN > 1) ? $clog2(BURST_LEN) : 1,
  localparam int OCNT_W  = $clog2(LANE_OUT + 1)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 cfg_link_retry,
  // ---- issue side (from the lane)
  output logic                      iss_ok_rd,
  output logic                      iss_ok_wr,
  input  wire logic                 iss_valid,
  input  wire logic                 iss_we,
  input  wire logic [TAG_W-1:0]     iss_tag,
  input  wire logic [LA_W-1:0]      iss_la,
  input  wire logic [LINE_W-1:0]    iss_wdata,
  input  wire logic [STRB_W-1:0]    iss_wstrb,
  // ---- SFMC master
  output logic                      mc_rst_n,
  input  wire logic                 mc_init_done,
  input  wire logic                 mc_fatal,
  output logic                      mc_cmd_valid,
  input  wire logic                 mc_cmd_ready,
  output logic                      mc_cmd_write,
  output logic [LA_W-1:0]           mc_cmd_addr,
  output logic [7:0]                mc_cmd_len,
  output logic [TAG_W-1:0]          mc_cmd_tag,
  output logic                      mc_wd_valid,
  input  wire logic                 mc_wd_ready,
  output logic [DATA_W-1:0]         mc_wd_data,
  output logic [BSTRB_W-1:0]        mc_wd_strb,
  output logic                      mc_wd_last,
  input  wire logic                 mc_rd_valid,
  output logic                      mc_rd_ready,
  input  wire logic [DATA_W-1:0]    mc_rd_data,
  input  wire logic [TAG_W-1:0]     mc_rd_tag,
  input  wire logic                 mc_rd_last,
  input  wire logic                 mc_rd_error,
  input  wire logic                 mc_wr_valid,
  output logic                      mc_wr_ready,
  input  wire logic [TAG_W-1:0]     mc_wr_tag,
  input  wire logic                 mc_wr_error,
  // ---- optional sideband (tie to 0 if absent)
  input  wire logic                 mc_busy,
  input  wire logic                 mc_rd_ce,
  input  wire logic                 mc_rd_ue,
  input  wire logic                 mc_rd_dbus,
  // ---- completion events to the response tracker
  output logic                      rb_valid,
  output logic [TAG_W-1:0]          rb_tag,
  output logic [DATA_W-1:0]         rb_data,
  output logic                      rb_last,
  output logic                      rb_err,
  output logic                      rb_ce,
  output logic                      rb_ue,
  output logic                      rb_dbus,
  output logic                      wr_valid,
  output logic [TAG_W-1:0]          wr_tag,
  output logic                      wr_err,
  output logic                      flush_o,
  // ---- status / events
  output logic [2:0]                link_state_o,
  output logic [OCNT_W-1:0]         out_cnt_o,
  output logic                      be_busy_o,
  output logic [1:0]                ev_beats,
  output logic                      ev_link_rst,
  output logic                      ev_unavail
);

  localparam int CMD_W   = 1 + TAG_W + LA_W;
  localparam int WDW     = LINE_W + STRB_W;
  localparam int CPTR_W  = (CMD_DEPTH > 1) ? $clog2(CMD_DEPTH) : 1;
  localparam int CCNT_W  = $clog2(CMD_DEPTH + 1);
  localparam int WPTR_W  = (WD_DEPTH > 1) ? $clog2(WD_DEPTH) : 1;
  localparam int WCNT_W  = $clog2(WD_DEPTH + 1);
  localparam int TMR_W   = 24;

  // ------------------------------------------------------------------ link FSM
  logic [2:0]       st_q;
  logic [TMR_W-1:0] tmr_q;
  logic             fault_now;
  logic             link_ready;

  assign fault_now  = !mc_init_done || mc_fatal;
  assign link_ready = (st_q == `SF_HBM_LK_READY) && !fault_now;
  assign mc_rst_n   = (st_q != `SF_HBM_LK_RESET);
  assign flush_o    = (st_q == `SF_HBM_LK_FLUSH);
  assign ev_link_rst = (st_q == `SF_HBM_LK_FLUSH);
  assign ev_unavail  = (st_q != `SF_HBM_LK_READY);
  assign link_state_o = st_q;
  assign be_busy_o    = mc_busy;

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      st_q  <= `SF_HBM_LK_RESET;
      tmr_q <= '0;
    end else begin
      case (st_q)
        `SF_HBM_LK_RESET: begin
          if (tmr_q >= RST_HOLD[TMR_W-1:0]) begin st_q <= `SF_HBM_LK_CAL; tmr_q <= '0; end
          else tmr_q <= tmr_q + 1'b1;
        end
        `SF_HBM_LK_CAL: begin
          if (mc_init_done && !mc_fatal) begin st_q <= `SF_HBM_LK_READY; tmr_q <= '0; end
          else if (CAL_TIMEOUT != 0 && tmr_q >= CAL_TIMEOUT[TMR_W-1:0]) begin st_q <= `SF_HBM_LK_CALFAIL; end
          else tmr_q <= tmr_q + 1'b1;
        end
        `SF_HBM_LK_READY: begin
          if (fault_now) begin st_q <= `SF_HBM_LK_FLUSH; end
        end
        `SF_HBM_LK_FLUSH: begin
          st_q <= `SF_HBM_LK_RESET; tmr_q <= '0;
        end
        default: begin   // CALFAIL
          if (cfg_link_retry) begin st_q <= `SF_HBM_LK_RESET; tmr_q <= '0; end
        end
      endcase
    end
  end

  // ------------------------------------------------------------------ outstanding counter
  logic [OCNT_W-1:0] out_q;
  logic              done_rd, done_wr;
  assign out_cnt_o = out_q;
  assign done_rd   = (st_q == `SF_HBM_LK_READY) && mc_rd_valid && mc_rd_last;
  assign done_wr   = (st_q == `SF_HBM_LK_READY) && mc_wr_valid;

  // a read last-beat and a write response may complete in the same cycle (independent channels): subtract BOTH, never below zero
  logic [1:0]        dec_n;
  logic [OCNT_W+1:0] out_sum, dec_w, out_tmp;
  logic [OCNT_W-1:0] out_nxt;
  assign dec_n   = {1'b0, done_rd} + {1'b0, done_wr};
  assign out_sum = {2'b00, out_q} + {{(OCNT_W+1){1'b0}}, iss_valid};
  assign dec_w   = {{OCNT_W{1'b0}}, dec_n};
  assign out_tmp = (out_sum < dec_w) ? {(OCNT_W+2){1'b0}} : (out_sum - dec_w);
  assign out_nxt = out_tmp[OCNT_W-1:0];   // the result never exceeds LANE_OUT, the upper bits are only guard bits

  always_ff @(posedge clk) begin
    if (!rst_n || flush_o) out_q <= '0;
    else                   out_q <= out_nxt;
  end

  // ------------------------------------------------------------------ command FIFO
  logic [CMD_W-1:0]  cmd_mem [0:CMD_DEPTH-1];
  logic [CPTR_W-1:0] cmd_wp, cmd_rp;
  logic [CCNT_W-1:0] cmd_cnt;
  logic              cmd_full, cmd_push, cmd_pop;
  logic [CMD_W-1:0]  cmd_head;

  assign cmd_full  = (cmd_cnt == CMD_DEPTH[CCNT_W-1:0]);
  assign cmd_push  = iss_valid;
  assign cmd_head  = cmd_mem[cmd_rp];
  // nothing is presented in a cycle in which the fault is already visible (a presented command may then be withdrawn: the lane is being flushed)
  assign mc_cmd_valid = link_ready && (cmd_cnt != '0);
  assign cmd_pop   = mc_cmd_valid && mc_cmd_ready;
  assign mc_cmd_write = cmd_head[CMD_W-1];
  assign mc_cmd_tag   = cmd_head[CMD_W-2 -: TAG_W];
  assign mc_cmd_addr  = cmd_head[LA_W-1:0];
  assign mc_cmd_len   = BURST_LEN[7:0] - 8'd1;

  always_ff @(posedge clk) begin
    if (!rst_n || flush_o) begin
      cmd_wp <= '0; cmd_rp <= '0; cmd_cnt <= '0;
    end else begin
      if (cmd_push) begin
        cmd_mem[cmd_wp] <= {iss_we, iss_tag, iss_la};
        cmd_wp <= (cmd_wp == CMD_DEPTH[CPTR_W-1:0] - 1'b1) ? '0 : cmd_wp + 1'b1;
      end
      if (cmd_pop) cmd_rp <= (cmd_rp == CMD_DEPTH[CPTR_W-1:0] - 1'b1) ? '0 : cmd_rp + 1'b1;
      case ({cmd_push, cmd_pop})
        2'b10:   cmd_cnt <= cmd_cnt + 1'b1;
        2'b01:   cmd_cnt <= cmd_cnt - 1'b1;
        default: cmd_cnt <= cmd_cnt;
      endcase
    end
  end

  // ------------------------------------------------------------------ write-data FIFO + beat serialiser
  logic [WDW-1:0]    wd_mem [0:WD_DEPTH-1];
  logic [WPTR_W-1:0] wd_wp, wd_rp;
  logic [WCNT_W-1:0] wd_cnt;
  logic [BEAT_W-1:0] beat_q;
  logic [WCNT_W-1:0] wcred_q;          // accepted write commands whose data has not finished
  logic              wd_full, wd_push, wd_line_done, wcmd_acc;
  logic [WDW-1:0]    wd_head;
  logic [LINE_W-1:0] wd_line;
  logic [STRB_W-1:0] wd_strb;

  assign wd_full = (wd_cnt == WD_DEPTH[WCNT_W-1:0]);
  assign wd_push = iss_valid && iss_we;
  assign wd_head = wd_mem[wd_rp];
  assign wd_line = wd_head[LINE_W-1:0];
  assign wd_strb = wd_head[WDW-1 -: STRB_W];
  assign wcmd_acc = cmd_pop && mc_cmd_write;

  assign mc_wd_valid = link_ready && (wd_cnt != '0) && (wcred_q != '0);
  assign mc_wd_data  = wd_line[beat_q*DATA_W +: DATA_W];
  assign mc_wd_strb  = wd_strb[beat_q*BSTRB_W +: BSTRB_W];
  assign mc_wd_last  = (beat_q == BURST_LEN[BEAT_W-1:0] - 1'b1);
  assign wd_line_done = mc_wd_valid && mc_wd_ready && mc_wd_last;

  always_ff @(posedge clk) begin
    if (!rst_n || flush_o) begin
      wd_wp <= '0; wd_rp <= '0; wd_cnt <= '0; beat_q <= '0; wcred_q <= '0;
    end else begin
      if (wd_push) begin
        wd_mem[wd_wp] <= {iss_wstrb, iss_wdata};
        wd_wp <= (wd_wp == WD_DEPTH[WPTR_W-1:0] - 1'b1) ? '0 : wd_wp + 1'b1;
      end
      if (mc_wd_valid && mc_wd_ready) begin
        if (mc_wd_last) beat_q <= '0; else beat_q <= beat_q + 1'b1;
      end
      if (wd_line_done) wd_rp <= (wd_rp == WD_DEPTH[WPTR_W-1:0] - 1'b1) ? '0 : wd_rp + 1'b1;
      case ({wd_push, wd_line_done})
        2'b10:   wd_cnt <= wd_cnt + 1'b1;
        2'b01:   wd_cnt <= wd_cnt - 1'b1;
        default: wd_cnt <= wd_cnt;
      endcase
      case ({wcmd_acc, wd_line_done})
        2'b10:   wcred_q <= wcred_q + 1'b1;
        2'b01:   wcred_q <= wcred_q - 1'b1;
        default: wcred_q <= wcred_q;
      endcase
    end
  end

  // ------------------------------------------------------------------ issue acceptance
  logic room;
  assign room      = link_ready && (out_q < LANE_OUT[OCNT_W-1:0]) && !cmd_full;
  assign iss_ok_rd = room;
  assign iss_ok_wr = room && !wd_full;

  // ------------------------------------------------------------------ response forwarding
  assign mc_rd_ready = 1'b1;
  assign mc_wr_ready = 1'b1;
  assign rb_valid = (st_q == `SF_HBM_LK_READY) && mc_rd_valid;
  assign rb_tag   = mc_rd_tag;
  assign rb_data  = mc_rd_data;
  assign rb_last  = mc_rd_last;
  assign rb_err   = mc_rd_error;
  assign rb_ce    = mc_rd_ce;
  assign rb_ue    = mc_rd_ue;
  assign rb_dbus  = mc_rd_dbus;
  assign wr_valid = (st_q == `SF_HBM_LK_READY) && mc_wr_valid;
  assign wr_tag   = mc_wr_tag;
  assign wr_err   = mc_wr_error;

  assign ev_beats = {1'b0, rb_valid} + {1'b0, (mc_wd_valid && mc_wd_ready)};

endmodule
`default_nettype wire
