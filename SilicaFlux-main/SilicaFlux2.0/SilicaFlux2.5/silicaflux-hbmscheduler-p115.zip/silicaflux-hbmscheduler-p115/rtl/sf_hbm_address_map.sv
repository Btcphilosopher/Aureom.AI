// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_address_map
//
// Combinational address mapping: a byte address of the global window is split
// into lane (= logical channel x pseudo-channel), bank group, bank, row, column
// and byte offset.  The lane-local address handed to the backend is ALWAYS laid
// out as  { row | bank group | bank | column | byte offset }  (docs/ADDRESS_MAP.md),
// whatever MAP_MODE is; MAP_MODE only chooses which *global* address bits feed
// which field.
//
// "Explicitly selected memory technology profile": PROFILE selects the
// geometry limits in sf_hbm_defs.svh.  Combinations the profile does not
// describe are rejected at elaboration (generate-time $error).  The profiles
// are MODELLING profiles: none is verified against a JEDEC document or a vendor
// datasheet; a passing elaboration does NOT mean the configuration is a real
// HBM device.
//
// Outputs:
//   in_range_o : the address lies inside the 2^MAP_W-byte mapped window
//   aligned_o  : the address is aligned to the access granule (BURST_BYTES)
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_address_map #(
  parameter int PROFILE     = 0,
  parameter int ADDR_W      = 32,
  parameter int NUM_CH      = 2,
  parameter int NUM_PC      = 1,
  parameter int BURST_BYTES = 32,
  parameter int BG_W        = 2,
  parameter int BANK_W      = 2,
  parameter int ROW_W       = 8,
  parameter int COL_W       = 5,
  parameter int MAP_MODE    = 0,
  localparam int OFF_W   = $clog2(BURST_BYTES),
  localparam int CH_W    = $clog2(NUM_CH),
  localparam int PC_W    = $clog2(NUM_PC),
  localparam int LANE_W  = CH_W + PC_W,
  localparam int LANE_IW = (LANE_W > 0) ? LANE_W : 1,
  localparam int LA_W    = OFF_W + COL_W + BG_W + BANK_W + ROW_W,
  localparam int MAP_W   = LA_W + LANE_W
) (
  input  wire logic [ADDR_W-1:0]   addr_i,
  output logic [LANE_IW-1:0]       lane_o,
  output logic [LA_W-1:0]          la_o,
  output logic [BG_W-1:0]          bg_o,
  output logic [BANK_W-1:0]        bank_o,
  output logic [ROW_W-1:0]         row_o,
  output logic [COL_W-1:0]         col_o,
  output logic                     in_range_o,
  output logic                     aligned_o
);

  // ------------------------------------------------------------------ geometry validation
  localparam int P_MAX_CH  = `SF_HBM_PROF_MAX_CH(PROFILE);
  localparam int P_MIN_PC  = `SF_HBM_PROF_MIN_PC(PROFILE);
  localparam int P_MAX_PC  = `SF_HBM_PROF_MAX_PC(PROFILE);
  localparam int P_MAX_COL = `SF_HBM_PROF_MAX_COL_W(PROFILE);
  localparam int P_MAX_ROW = `SF_HBM_PROF_MAX_ROW_W(PROFILE);
  localparam int P_BURST_B = `SF_HBM_PROF_BURST_B(PROFILE);

  generate
    if (PROFILE < 0 || PROFILE > 2) begin : g_e_profile
      $error("sf_hbm_address_map: PROFILE must be 0 (SIM_GENERIC), 1 (HBM2E_STYLE) or 2 (HBM3_STYLE)");
    end
    if (NUM_CH < 1 || (NUM_CH & (NUM_CH - 1)) != 0) begin : g_e_ch_pow2
      $error("sf_hbm_address_map: NUM_CH must be a power of two >= 1");
    end
    if (NUM_CH > P_MAX_CH) begin : g_e_ch_max
      $error("sf_hbm_address_map: NUM_CH exceeds the channel count of the selected profile");
    end
    if (NUM_PC < P_MIN_PC || NUM_PC > P_MAX_PC || (NUM_PC & (NUM_PC - 1)) != 0) begin : g_e_pc
      $error("sf_hbm_address_map: NUM_PC not supported by the selected profile");
    end
    if (BURST_BYTES < 16 || BURST_BYTES > 128 || (BURST_BYTES & (BURST_BYTES - 1)) != 0) begin : g_e_burst_range
      $error("sf_hbm_address_map: BURST_BYTES must be 16, 32, 64 or 128");
    end
    if (P_BURST_B != 0 && BURST_BYTES != P_BURST_B) begin : g_e_burst_prof
      $error("sf_hbm_address_map: BURST_BYTES differs from the access granule of the selected profile");
    end
    if (PROFILE == 0) begin : g_p0_geom
      if (BG_W < 1 || BG_W > 3 || BANK_W < 1 || BANK_W > 3) begin : g_e_bank0
        $error("sf_hbm_address_map: SIM_GENERIC supports BG_W and BANK_W in 1..3");
      end
    end else begin : g_pn_geom
      if (BG_W != `SF_HBM_PROF_BG_W(PROFILE) || BANK_W != `SF_HBM_PROF_BANK_W(PROFILE)) begin : g_e_bankn
        $error("sf_hbm_address_map: bank-group / bank widths differ from the selected profile");
      end
    end
    if (COL_W < 1 || COL_W > P_MAX_COL) begin : g_e_col
      $error("sf_hbm_address_map: COL_W out of range for the selected profile");
    end
    if (ROW_W < 1 || ROW_W > P_MAX_ROW) begin : g_e_row
      $error("sf_hbm_address_map: ROW_W out of range for the selected profile");
    end
    if (MAP_MODE < 0 || MAP_MODE > 3) begin : g_e_mode
      $error("sf_hbm_address_map: MAP_MODE must be 0..3");
    end
    if (MAP_MODE == 3 && ROW_W < BG_W + BANK_W) begin : g_e_hash
      $error("sf_hbm_address_map: MAP_MODE 3 (hashed banks) needs ROW_W >= BG_W + BANK_W");
    end
    if (ADDR_W < MAP_W) begin : g_e_addr_lo
      $error("sf_hbm_address_map: ADDR_W is smaller than the mapped window");
    end
    if (ADDR_W > 64) begin : g_e_addr_hi
      $error("sf_hbm_address_map: ADDR_W must be <= 64");
    end
  endgenerate

  // ------------------------------------------------------------------ field positions (LSB of each field)
  localparam int P_CH   = (MAP_MODE == 2) ? OFF_W + COL_W : OFF_W;
  localparam int P_PC   = P_CH + CH_W;
  localparam int P_COL  = (MAP_MODE == 1) ? OFF_W + CH_W + PC_W + BG_W + BANK_W :
                          (MAP_MODE == 2) ? OFF_W : OFF_W + CH_W + PC_W;
  localparam int P_BG   = (MAP_MODE == 1) ? OFF_W + CH_W + PC_W :
                          (MAP_MODE == 2) ? OFF_W + COL_W + CH_W + PC_W : OFF_W + CH_W + PC_W + COL_W;
  localparam int P_BANK = P_BG + BG_W;
  localparam int P_ROW  = (MAP_MODE == 1) ? P_COL + COL_W : P_BANK + BANK_W;

  logic [BG_W-1:0]   bg_raw;
  logic [BANK_W-1:0] bank_raw;
  logic [OFF_W-1:0]  boff;

  always_comb begin
    bg_raw   = addr_i[P_BG   +: BG_W];
    bank_raw = addr_i[P_BANK +: BANK_W];
    row_o    = addr_i[P_ROW  +: ROW_W];
    col_o    = addr_i[P_COL  +: COL_W];
    boff     = addr_i[OFF_W-1:0];
    bg_o     = bg_raw;
    bank_o   = bank_raw;
    if (MAP_MODE == 3) begin
      bank_o = bank_raw ^ row_o[BANK_W-1:0];
      bg_o   = bg_raw   ^ row_o[BANK_W +: BG_W];
    end
  end

  // lane = { channel, pseudo-channel }  (pseudo-channel in the low bits)
  generate
    if (LANE_W == 0) begin : g_lane0
      always_comb lane_o = 1'b0;
    end else if (PC_W == 0) begin : g_lane_ch
      always_comb lane_o = addr_i[P_CH +: CH_W];
    end else if (CH_W == 0) begin : g_lane_pc
      always_comb lane_o = addr_i[P_PC +: PC_W];
    end else begin : g_lane_both
      always_comb lane_o = {addr_i[P_CH +: CH_W], addr_i[P_PC +: PC_W]};
    end
  endgenerate

  always_comb la_o = {row_o, bg_o, bank_o, col_o, boff};

  generate
    if (ADDR_W > MAP_W) begin : g_range_hi
      always_comb in_range_o = (addr_i[ADDR_W-1:MAP_W] == '0);
    end else begin : g_range_eq
      always_comb in_range_o = 1'b1;
    end
  endgenerate

  always_comb aligned_o = (boff == '0);

endmodule
`default_nettype wire
