// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_write_queue
//
// Per-lane write request queue: DEPTH random-access entries holding the request
// metadata AND the write data / byte enables (LINE_W bits per entry).
//
// Dependencies (older accesses to the same granule that must issue first):
//   * WAR : older READS  of the same granule (oth_* = read-queue view)
//   * WAW : older WRITES of the same granule (own entries)
// A write is "ready" for the scheduler when both masks are empty.  Masks are
// computed at enqueue time and cleared when the dependency issues.
//
// Write data is stored in registers here; a physical implementation would use
// a register file or SRAM macro (docs/HARDWARE_INTEGRATION.md).
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_write_queue #(
  parameter int DEPTH   = 16,
  parameter int TAG_W   = 6,
  parameter int GA_W    = 17,
  parameter int BK_W    = 4,
  parameter int ROW_W   = 8,
  parameter int AGE_W   = 12,
  parameter int LINE_W  = 256,
  parameter int STRB_W  = 32,
  parameter int OTH_D   = 16,   // depth of the read queue (hazard source)
  localparam int IDX_W = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int CNT_W = $clog2(DEPTH + 1)
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // enqueue
  input  wire logic                  enq_valid,
  input  wire logic [TAG_W-1:0]      enq_tag,
  input  wire logic [GA_W-1:0]       enq_ga,
  input  wire logic [BK_W-1:0]       enq_bank,
  input  wire logic [ROW_W-1:0]      enq_row,
  input  wire logic [LINE_W-1:0]     enq_data,
  input  wire logic [STRB_W-1:0]     enq_strb,
  output logic                       full_o,
  output logic [CNT_W-1:0]           count_o,
  // hazard source: the read queue's registered view
  input  wire logic [OTH_D-1:0]      oth_valid,
  input  wire logic [OTH_D*GA_W-1:0] oth_ga,
  input  wire logic [OTH_D-1:0]      oth_pop,
  // scheduler view
  output logic [DEPTH-1:0]           ent_valid,
  output logic [DEPTH-1:0]           ent_ready,
  output logic [DEPTH*BK_W-1:0]      ent_bank,
  output logic [DEPTH*ROW_W-1:0]     ent_row,
  output logic [DEPTH*AGE_W-1:0]     ent_age,
  output logic [DEPTH*GA_W-1:0]      ent_ga,
  // issue (pop)
  input  wire logic                  pop_valid,
  input  wire logic [IDX_W-1:0]      pop_idx,
  output logic [TAG_W-1:0]           pop_tag,
  output logic [GA_W-1:0]            pop_ga,
  output logic [AGE_W-1:0]           pop_age,
  output logic [LINE_W-1:0]          pop_data,
  output logic [STRB_W-1:0]          pop_strb,
  output logic [DEPTH-1:0]           pop_oh
);

  logic [DEPTH-1:0]  v_q;
  logic [TAG_W-1:0]  tag_q  [0:DEPTH-1];
  logic [GA_W-1:0]   ga_q   [0:DEPTH-1];
  logic [BK_W-1:0]   bk_q   [0:DEPTH-1];
  logic [ROW_W-1:0]  row_q  [0:DEPTH-1];
  logic [AGE_W-1:0]  age_q  [0:DEPTH-1];
  logic [LINE_W-1:0] dat_q  [0:DEPTH-1];
  logic [STRB_W-1:0] str_q  [0:DEPTH-1];
  logic [OTH_D-1:0]  depo_q [0:DEPTH-1];   // older reads (WAR)
  logic [DEPTH-1:0]  deps_q [0:DEPTH-1];   // older writes (WAW)

  logic [IDX_W-1:0] free_idx;
  logic             free_ok;
  always_comb begin
    free_ok  = 1'b0;
    free_idx = '0;
    for (int i = DEPTH - 1; i >= 0; i--) begin
      if (!v_q[i]) begin free_ok = 1'b1; free_idx = i[IDX_W-1:0]; end
    end
  end
  assign full_o = !free_ok;

  logic [OTH_D-1:0] hit_o;
  logic [DEPTH-1:0] hit_s;
  always_comb begin
    for (int j = 0; j < OTH_D; j++) begin
      hit_o[j] = oth_valid[j] && (oth_ga[j*GA_W +: GA_W] == enq_ga) && !oth_pop[j];
    end
    for (int j = 0; j < DEPTH; j++) begin
      hit_s[j] = v_q[j] && (ga_q[j] == enq_ga) && !pop_oh[j];
    end
  end

  always_comb begin
    pop_oh = '0;
    if (pop_valid) pop_oh[pop_idx] = 1'b1;
    for (int i = 0; i < DEPTH; i++) begin
      ent_valid[i]                  = v_q[i];
      ent_ready[i]                  = v_q[i] && (depo_q[i] == '0) && (deps_q[i] == '0);
      ent_bank[i*BK_W +: BK_W]      = bk_q[i];
      ent_row[i*ROW_W +: ROW_W]     = row_q[i];
      ent_age[i*AGE_W +: AGE_W]     = age_q[i];
      ent_ga[i*GA_W +: GA_W]        = ga_q[i];
    end
    pop_tag  = tag_q[pop_idx];
    pop_ga   = ga_q[pop_idx];
    pop_age  = age_q[pop_idx];
    pop_data = dat_q[pop_idx];
    pop_strb = str_q[pop_idx];
  end

  always_comb begin
    count_o = '0;
    for (int i = 0; i < DEPTH; i++) count_o = count_o + {{(CNT_W-1){1'b0}}, v_q[i]};
  end

  always_ff @(posedge clk) begin
    if (!rst_n) begin
      v_q <= '0;
      for (int i = 0; i < DEPTH; i++) begin
        tag_q[i] <= '0; ga_q[i] <= '0; bk_q[i] <= '0; row_q[i] <= '0; age_q[i] <= '0;
        dat_q[i] <= '0; str_q[i] <= '0; depo_q[i] <= '0; deps_q[i] <= '0;
      end
    end else begin
      for (int i = 0; i < DEPTH; i++) begin
        if (v_q[i]) begin
          depo_q[i] <= depo_q[i] & ~oth_pop;
          deps_q[i] <= deps_q[i] & ~pop_oh;
          if (age_q[i] != {AGE_W{1'b1}}) age_q[i] <= age_q[i] + 1'b1;
        end
      end
      if (pop_valid) v_q[pop_idx] <= 1'b0;
      if (enq_valid && free_ok) begin
        v_q[free_idx]    <= 1'b1;
        tag_q[free_idx]  <= enq_tag;
        ga_q[free_idx]   <= enq_ga;
        bk_q[free_idx]   <= enq_bank;
        row_q[free_idx]  <= enq_row;
        age_q[free_idx]  <= '0;
        dat_q[free_idx]  <= enq_data;
        str_q[free_idx]  <= enq_strb;
        depo_q[free_idx] <= hit_o;
        deps_q[free_idx] <= hit_s;
      end
    end
  end

endmodule
`default_nettype wire
