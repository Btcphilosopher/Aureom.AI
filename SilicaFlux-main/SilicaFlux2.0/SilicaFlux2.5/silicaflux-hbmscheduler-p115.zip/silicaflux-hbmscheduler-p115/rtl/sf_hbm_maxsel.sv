// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_maxsel
//
// Balanced-tree "maximum key among valid candidates" selector: a recursive pair
// of half-size selectors and one comparator, i.e. ceil(log2 N) comparator
// levels instead of an N-long compare chain.  Ties go to the LOWER index (the
// left half), exactly like a left-to-right scan with a strict ">" would.
//   in : v[i] candidate valid, k[i] key
//   out: out_v any valid, out_i index of the winner, out_k its key
// =============================================================================
`default_nettype none

module sf_hbm_maxsel #(
  parameter int N  = 16,
  parameter int KW = 12,
  localparam int IW = (N > 1) ? $clog2(N) : 1
) (
  input  wire logic [N-1:0]     v,
  input  wire logic [N*KW-1:0]  k,
  output logic                  out_v,
  output logic [IW-1:0]         out_i,
  output logic [KW-1:0]         out_k
);

  generate
    if (N == 1) begin : g_leaf
      assign out_v = v[0];
      assign out_k = k[KW-1:0];
      assign out_i = '0;
    end else begin : g_node
      localparam int NL  = (N + 1) / 2;
      localparam int NR  = N - NL;
      localparam int IWL = (NL > 1) ? $clog2(NL) : 1;
      localparam int IWR = (NR > 1) ? $clog2(NR) : 1;
      logic              lv, rv;
      logic [KW-1:0]     lk, rk;
      logic [IWL-1:0]    li;
      logic [IWR-1:0]    ri;
      logic              take_r;

      sf_hbm_maxsel #(.N(NL), .KW(KW)) u_l (.v(v[NL-1:0]), .k(k[NL*KW-1:0]),    .out_v(lv), .out_i(li), .out_k(lk));
      sf_hbm_maxsel #(.N(NR), .KW(KW)) u_r (.v(v[N-1:NL]), .k(k[N*KW-1:NL*KW]), .out_v(rv), .out_i(ri), .out_k(rk));

      // the right half wins only if it has a candidate and the left half has none, or its key is strictly larger
      assign take_r = rv && (!lv || (rk > lk));
      assign out_v  = lv || rv;
      assign out_k  = take_r ? rk : lk;
      assign out_i  = take_r ? (NL[IW-1:0] + {{(IW-IWR){1'b0}}, ri}) : {{(IW-IWL){1'b0}}, li};
    end
  endgenerate

endmodule
`default_nettype wire
