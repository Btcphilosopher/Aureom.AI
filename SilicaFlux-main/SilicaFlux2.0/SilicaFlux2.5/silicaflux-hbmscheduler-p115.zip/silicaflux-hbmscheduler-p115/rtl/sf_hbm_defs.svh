// =============================================================================
// SilicaFlux HBMScheduler (Project 115) :: sf_hbm_defs.svh
// Shared constants.  Plain `define macros: the SilicaFlux RTL coding rules
// (flat ports, no structs / interfaces / package imports in synthesizable RTL)
// are followed, exactly as in the MemoryBridge (P24) and StreamDMA (P103).
// =============================================================================
`ifndef SF_HBM_DEFS_SVH
`define SF_HBM_DEFS_SVH

// ---------------------------------------------------------------- request sources
// Source-port numbering used by the default 5-source configuration.  The RTL is
// generic in NUM_SRC; these names only document the intended binding.
`define SF_HBM_SRC_TENSOR     0   // TensorCore operand / result transfers (via its DMA)
`define SF_HBM_SRC_VECTOR     1   // Vector Engine memory traffic
`define SF_HBM_SRC_STREAMDMA  2   // StreamDMA (scatter-gather) traffic
`define SF_HBM_SRC_CONTROL    3   // ControlCore requests (latency critical, sparse)
`define SF_HBM_SRC_CLOUD      4   // cloud processing modules (CloudDMA / DPU / packet engines)

// ---------------------------------------------------------------- response status codes
// Status < 2 means "data valid".  Status >= 2 is an error: the response data is
// forced to zero by the tracker so poisoned / stale data never leaves it.
`define SF_HBM_ST_OK          4'd0   // completed, no backend flag
`define SF_HBM_ST_OK_ECC_CE   4'd1   // completed; backend reported a *corrected* error (data valid)
`define SF_HBM_ST_ERR_ADDR    4'd2   // address outside the mapped window / geometry
`define SF_HBM_ST_ERR_ALIGN   4'd3   // address not aligned to the access granule
`define SF_HBM_ST_ERR_PERM    4'd4   // permission window violation
`define SF_HBM_ST_ERR_BE      4'd5   // backend returned an error response
`define SF_HBM_ST_ERR_ECC_UE  4'd6   // backend reported an uncorrectable ECC error (data untrusted)
`define SF_HBM_ST_ERR_DBUS    4'd7   // backend reported a data-bus error
`define SF_HBM_ST_ERR_TIMEOUT 4'd8   // no backend response within cfg_timeout cycles of issue
`define SF_HBM_ST_ERR_FLUSH   4'd9   // aborted: backend link lost / fatal while in flight
`define SF_HBM_ST_ERR_STRB    4'd10  // write with an all-zero byte-enable mask

// ---------------------------------------------------------------- scheduling policy (cfg_policy)
`define SF_HBM_POL_FCFS       3'd0   // strict first-come-first-served across reads and writes (BASELINE)
`define SF_HBM_POL_RDPRIO     3'd1   // read priority + watermark write draining, FCFS inside each class
`define SF_HBM_POL_FRFCFS     3'd2   // RDPRIO + row-hit first inside the class
`define SF_HBM_POL_BANKAWARE  3'd3   // FRFCFS + bank-group alternation + busy-bank avoidance
// every policy except FCFS includes the age-based starvation override (cfg_age_limit)

// ---------------------------------------------------------------- address-map modes (MAP_MODE), LSB -> MSB after the byte offset
`define SF_HBM_MAP_CH_COL     0   // ch | pc | col | bg | bank | row  (burst interleave across lanes, page-local columns)
`define SF_HBM_MAP_BANK_INT   1   // ch | pc | bg | bank | col | row  (burst interleave across lanes and banks)
`define SF_HBM_MAP_PAGE_CH    2   // col | ch | pc | bg | bank | row  (page interleave across lanes)
`define SF_HBM_MAP_HASHED     3   // CH_COL with bank / bank-group XOR-ed with low row bits

// ---------------------------------------------------------------- memory technology profiles (PROFILE)
// EVERY profile is a *modelling* profile.  None is verified against a JEDEC
// document or a vendor datasheet (none was available in this project).  The
// geometry limits below make the address map refuse combinations that the
// *profile* does not describe; they do not certify any real HBM device.
//   0 SIM_GENERIC           : behavioural reference profile (the default)
//   1 HBM2E_STYLE_ILLUSTR   : HBM2E-shaped geometry placeholder (8 ch x 2 PC, 4 BG x 4 banks, 32 B access)
//   2 HBM3_STYLE_ILLUSTR    : HBM3-shaped geometry placeholder (16 ch x 2 PC, 4 BG x 4 banks, 32 B access)
`define SF_HBM_PROF_SIM_GENERIC   0
`define SF_HBM_PROF_HBM2E_STYLE   1
`define SF_HBM_PROF_HBM3_STYLE    2

// per-profile limits: (profile) -> value
`define SF_HBM_PROF_MAX_CH(p)    (((p) == 0) ? 32 : ((p) == 1) ?  8 : 16)
`define SF_HBM_PROF_MIN_PC(p)    (((p) == 0) ?  1 : 2)
`define SF_HBM_PROF_MAX_PC(p)    2
`define SF_HBM_PROF_BG_W(p)      2
`define SF_HBM_PROF_BANK_W(p)    2
`define SF_HBM_PROF_MAX_COL_W(p) 5           // 32 columns x 32 B = 1 KiB page
`define SF_HBM_PROF_MAX_ROW_W(p) (((p) == 0) ? 14 : ((p) == 1) ? 14 : 15)
// native access granule in bytes: 0 = any power of two in 16..128
`define SF_HBM_PROF_BURST_B(p)   (((p) == 0) ? 0 : 32)

// ---------------------------------------------------------------- backend link FSM (adapter)
`define SF_HBM_LK_RESET     3'd0   // controller held in reset (RST_HOLD cycles)
`define SF_HBM_LK_CAL       3'd1   // waiting for mc_init_done
`define SF_HBM_LK_READY     3'd2   // normal operation
`define SF_HBM_LK_FLUSH     3'd3   // failing in-flight transactions, then reset the controller
`define SF_HBM_LK_CALFAIL   3'd4   // calibration timeout; waits for cfg_link_retry

// ---------------------------------------------------------------- performance counter map
// perf_sel[15:14] = group, [13:8] = instance, [7:0] = index
`define SF_HBM_PG_GLOBAL    2'd0
`define SF_HBM_PG_LANE      2'd1
`define SF_HBM_PG_SRC       2'd2
`define SF_HBM_PG_HIST      2'd3   // global latency histogram: index = bucket (floor(log2(latency)))

// global counters (instance 0)
`define SF_HBM_G_CYCLES        0   // cycles since clear
`define SF_HBM_G_ACTIVE        1   // cycles with at least one outstanding transaction
`define SF_HBM_G_REQ           2   // requests accepted (incl. rejected ones that got an error response)
`define SF_HBM_G_RSP           3   // responses delivered
`define SF_HBM_G_RSP_ERR       4   // responses delivered with status >= 2
`define SF_HBM_G_BYTES_RD      5   // useful bytes read (successful read responses x BURST_BYTES)
`define SF_HBM_G_BYTES_WR      6   // useful bytes written (enabled strobe bytes of successful writes)
`define SF_HBM_G_ING_STALL     7   // source-cycles with req_valid && !req_ready
`define SF_HBM_G_REJECT        8   // requests rejected by validation
`define SF_HBM_G_TIMEOUT       9   // timeouts
`define SF_HBM_G_SPURIOUS     10   // backend responses that matched no live transaction
`define SF_HBM_G_FLUSHED      11   // transactions failed by a link flush
`define SF_HBM_G_ZOMBIE_CYC   12   // slot-cycles held by timed-out (zombie) transactions
`define SF_HBM_G_LAT_SUM      13   // sum of accept -> delivery latency (cycles)
`define SF_HBM_G_LAT_MAX      14   // max  of accept -> delivery latency   (MAX counter)
`define SF_HBM_G_OUT_SUM      15   // sum over cycles of outstanding transactions
`define SF_HBM_G_OUT_MAX      16   // max outstanding transactions         (MAX counter)
`define SF_HBM_G_ROB_STALL    17   // cycles with a completed response held back by ordering rules
`define SF_HBM_G_N            18

// per-lane counters (instance = lane)
`define SF_HBM_L_ISS_RD        0   // read commands issued to the backend
`define SF_HBM_L_ISS_WR        1   // write commands issued
`define SF_HBM_L_BEATS         2   // data-bus beats moved (read beats + write beats accepted by the backend)
`define SF_HBM_L_HIT           3   // scheduler-side (shadow) row-hit classification at issue
`define SF_HBM_L_MISS          4   // shadow: bank closed
`define SF_HBM_L_CONF          5   // shadow: open row differs
`define SF_HBM_L_BE_HIT        6   // backend-reported row hits (0 if the backend has no such pins)
`define SF_HBM_L_BE_MISS       7   // backend-reported row misses
`define SF_HBM_L_BE_CONF       8   // backend-reported row conflicts
`define SF_HBM_L_BANK_CONF     9   // issues to a bank the shadow model still considers busy
`define SF_HBM_L_TURN         10   // read<->write direction changes at issue
`define SF_HBM_L_QFULL_RD     11   // cycles a read request was held off by a full read queue
`define SF_HBM_L_QFULL_WR     12   // cycles a write request was held off by a full write queue
`define SF_HBM_L_RQ_OCC_SUM   13   // sum over cycles of read-queue occupancy
`define SF_HBM_L_WQ_OCC_SUM   14   // sum over cycles of write-queue occupancy
`define SF_HBM_L_RQ_MAX       15   // MAX
`define SF_HBM_L_WQ_MAX       16   // MAX
`define SF_HBM_L_QW_SUM       17   // sum of queue waiting time (accept -> issue)
`define SF_HBM_L_QW_CNT       18   // number of issued commands (denominator of the mean)
`define SF_HBM_L_QW_MAX       19   // MAX queue waiting time
`define SF_HBM_L_REF_STALL    20   // cycles with queued work while the backend reports busy/refresh
`define SF_HBM_L_HAZ_STALL    21   // cycles where queued work existed but every entry was blocked by an ordering hazard
`define SF_HBM_L_BE_STALL     22   // cycles where an issuable candidate existed but the backend could not accept it
`define SF_HBM_L_AGE_OVR      23   // starvation overrides taken
`define SF_HBM_L_DRAIN_CYC    24   // cycles in write-drain mode
`define SF_HBM_L_OUT_SUM      25   // sum over cycles of in-flight commands
`define SF_HBM_L_OUT_MAX      26   // MAX in-flight commands
`define SF_HBM_L_LINK_RST     27   // backend link resets (fault / flush sequences)
`define SF_HBM_L_UNAVAIL      28   // cycles the backend link was not READY
`define SF_HBM_L_IDLE_CYC     29   // cycles with empty queues and nothing in flight
`define SF_HBM_L_BYP_OVR     30   // bypass-cap overrides taken (oldest issuable entry forced after cfg_bypass_cap bypasses)
`define SF_HBM_L_N            31

// per-source counters (instance = source)
`define SF_HBM_S_REQ           0   // requests accepted
`define SF_HBM_S_BYTES         1   // useful bytes (successful responses)
`define SF_HBM_S_RSP           2   // responses delivered
`define SF_HBM_S_ERR           3   // error responses
`define SF_HBM_S_LAT_SUM       4   // accept -> delivery latency, sum
`define SF_HBM_S_LAT_MAX       5   // MAX
`define SF_HBM_S_ING_STALL     6   // cycles req_valid && !req_ready (ingress back-pressure; "starvation" for a tensor source)
`define SF_HBM_S_ROB_STALL     7   // cycles a completed response of this source was held back by ordering
`define SF_HBM_S_REORDERED     8   // responses that completed before an older response and had to wait
`define SF_HBM_S_ROB_MAXD      9   // MAX number of completed-but-held responses
`define SF_HBM_S_QW_SUM       10   // sum of accept -> issue wait (cycles)
`define SF_HBM_S_QW_CNT       11   // issued commands of this source
`define SF_HBM_S_GRANTS       12   // arbiter grants (== accepted requests that reached a lane)
`define SF_HBM_S_ARB_LOSS     13   // cycles this source had an issuable request at a lane arbiter and lost the arbitration
`define SF_HBM_S_N            14

`endif
