// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_sched_top           (integration top)
//
//  source ports (TensorCore / Vector / StreamDMA / ControlCore / cloud ...)
//     |  request validation (sf_hbm_req_check)  : range, alignment, permission, strobes
//     |  address mapping    (sf_hbm_address_map): lane = channel x pseudo-channel, bank, row, column
//     |  tracker allocation (sf_hbm_response_tracker): tag = {source, slot}, order bookkeeping
//     v
//  NUM_LANES x sf_hbm_lane   (arbiter -> read/write queues -> scheduler -> backend adapter)
//     |  SFMC (+ optional sideband) per lane  ->  controller adapter  ->  HBM controller / PHY
//     v
//  sf_hbm_response_tracker (re-ordering) -> source response ports;  sf_hbm_perf (counters)
//
// This module schedules and orders memory transactions.  It is NOT an HBM
// controller or PHY: no DRAM command sequencing, refresh, training or PHY logic
// lives here (docs/HARDWARE_INTEGRATION.md).
//
// Defaults reproduce the first configuration of the brief: two logical
// channels (NUM_CH = 2, one pseudo-channel each) on the SIM_GENERIC profile.
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_sched_top #(
  parameter int NUM_SRC       = 5,
  parameter int NUM_CH        = 2,
  parameter int NUM_PC        = 1,
  parameter int PROFILE       = 0,
  parameter int ADDR_W        = 32,
  parameter int DATA_W        = 128,    // bits per backend beat (per controller clock)
  parameter int BURST_LEN     = 2,      // beats per access: access granule = DATA_W/8*BURST_LEN bytes
  parameter int BG_W          = 2,
  parameter int BANK_W        = 2,
  parameter int ROW_W         = 8,
  parameter int COL_W         = 5,
  parameter int MAP_MODE      = 0,
  parameter int ID_W          = 4,
  parameter int RQ_DEPTH      = 16,     // read queue depth per lane
  parameter int WQ_DEPTH      = 16,     // write queue depth per lane
  parameter int OUT_PER_SRC   = 8,      // outstanding-request slots per source (power of two)
  parameter int LANE_OUT      = 8,      // commands in flight per lane
  parameter int WD_DEPTH      = 4,
  parameter int CMD_DEPTH     = 2,
  parameter int AGE_W         = 12,
  parameter int BUSY_W        = 6,
  parameter int BYP_W         = 6,
  parameter int NUM_WIN       = 4,
  parameter int ORDER_MODE    = 0,      // 0 per-source in order, 1 same-id in order
  parameter int BE_ORDER_SAFE = 1,      // backend honours SFMC rule C9
  parameter int RST_HOLD      = 8,
  parameter int CAL_TIMEOUT   = 0,
  parameter int SHADOW_CLR_BUSY = 1,
  localparam int BURST_BYTES = DATA_W * BURST_LEN / 8,
  localparam int OFF_W       = $clog2(BURST_BYTES),
  localparam int NUM_LANES   = NUM_CH * NUM_PC,
  localparam int LANE_IW     = (NUM_LANES > 1) ? $clog2(NUM_LANES) : 1,
  localparam int LA_W        = OFF_W + COL_W + BG_W + BANK_W + ROW_W,
  localparam int LINE_W      = DATA_W * BURST_LEN,
  localparam int STRB_W      = BURST_BYTES,
  localparam int BSTRB_W     = DATA_W / 8,
  localparam int SLOT_W      = $clog2(OUT_PER_SRC),
  localparam int SRC_W       = (NUM_SRC > 1) ? $clog2(NUM_SRC) : 1,
  localparam int TAG_W       = SRC_W + SLOT_W,
  localparam int LIM_W       = SLOT_W + 1,
  localparam int RCNT_W      = $clog2(RQ_DEPTH + 1),
  localparam int WCNT_W      = $clog2(WQ_DEPTH + 1),
  localparam int OCNT_W      = $clog2(LANE_OUT + 1),
  localparam int TS_W        = 32,
  localparam int BYTES_W     = 16,
  localparam int INC_W       = 16
) (
  input  wire logic                           clk,
  input  wire logic                           rst_n,
  // ---------------------------------------------------------------- runtime configuration
  input  wire logic [2:0]                     cfg_policy,
  input  wire logic [WCNT_W-1:0]              cfg_wr_hi,
  input  wire logic [WCNT_W-1:0]              cfg_wr_lo,
  input  wire logic [AGE_W-1:0]               cfg_age_limit,
  input  wire logic                           cfg_idle_wr,
  input  wire logic [BUSY_W-1:0]              cfg_busy_cyc,
  input  wire logic [BYP_W-1:0]               cfg_bypass_cap,
  input  wire logic                           cfg_arb_mode,
  input  wire logic [NUM_SRC*2-1:0]           cfg_arb_prio,
  input  wire logic [7:0]                     cfg_arb_age,
  input  wire logic [TS_W-1:0]                cfg_timeout,
  input  wire logic [NUM_SRC*LIM_W-1:0]       cfg_out_limit,
  input  wire logic                           cfg_perm_en,
  input  wire logic [NUM_WIN*ADDR_W-1:0]      cfg_win_base,
  input  wire logic [NUM_WIN*ADDR_W-1:0]      cfg_win_last,
  input  wire logic [NUM_WIN*NUM_SRC*2-1:0]   cfg_win_perm,
  input  wire logic                           cfg_link_retry,
  // ---------------------------------------------------------------- source ports (flat: source s uses slice s)
  input  wire logic [NUM_SRC-1:0]             s_req_valid,
  output logic [NUM_SRC-1:0]                  s_req_ready,
  input  wire logic [NUM_SRC-1:0]             s_req_we,
  input  wire logic [NUM_SRC*ID_W-1:0]        s_req_id,
  input  wire logic [NUM_SRC*ADDR_W-1:0]      s_req_addr,
  input  wire logic [NUM_SRC*LINE_W-1:0]      s_req_wdata,
  input  wire logic [NUM_SRC*STRB_W-1:0]      s_req_wstrb,
  output logic [NUM_SRC-1:0]                  s_rsp_valid,
  input  wire logic [NUM_SRC-1:0]             s_rsp_ready,
  output logic [NUM_SRC*ID_W-1:0]             s_rsp_id,
  output logic [NUM_SRC-1:0]                  s_rsp_we,
  output logic [NUM_SRC*LINE_W-1:0]           s_rsp_data,
  output logic [NUM_SRC*4-1:0]                s_rsp_status,
  // ---------------------------------------------------------------- SFMC per lane (lane l uses slice l)
  output logic [NUM_LANES-1:0]                mc_rst_n,
  input  wire logic [NUM_LANES-1:0]           mc_init_done,
  input  wire logic [NUM_LANES-1:0]           mc_fatal,
  output logic [NUM_LANES-1:0]                mc_cmd_valid,
  input  wire logic [NUM_LANES-1:0]           mc_cmd_ready,
  output logic [NUM_LANES-1:0]                mc_cmd_write,
  output logic [NUM_LANES*LA_W-1:0]           mc_cmd_addr,
  output logic [NUM_LANES*8-1:0]              mc_cmd_len,
  output logic [NUM_LANES*TAG_W-1:0]          mc_cmd_tag,
  output logic [NUM_LANES-1:0]                mc_wd_valid,
  input  wire logic [NUM_LANES-1:0]           mc_wd_ready,
  output logic [NUM_LANES*DATA_W-1:0]         mc_wd_data,
  output logic [NUM_LANES*BSTRB_W-1:0]        mc_wd_strb,
  output logic [NUM_LANES-1:0]                mc_wd_last,
  input  wire logic [NUM_LANES-1:0]           mc_rd_valid,
  output logic [NUM_LANES-1:0]                mc_rd_ready,
  input  wire logic [NUM_LANES*DATA_W-1:0]    mc_rd_data,
  input  wire logic [NUM_LANES*TAG_W-1:0]     mc_rd_tag,
  input  wire logic [NUM_LANES-1:0]           mc_rd_last,
  input  wire logic [NUM_LANES-1:0]           mc_rd_error,
  input  wire logic [NUM_LANES-1:0]           mc_wr_valid,
  output logic [NUM_LANES-1:0]                mc_wr_ready,
  input  wire logic [NUM_LANES*TAG_W-1:0]     mc_wr_tag,
  input  wire logic [NUM_LANES-1:0]           mc_wr_error,
  // ---------------------------------------------------------------- SFMC-X sideband (tie to 0 if absent)
  input  wire logic [NUM_LANES-1:0]           mc_busy,
  input  wire logic [NUM_LANES-1:0]           mc_rd_ce,
  input  wire logic [NUM_LANES-1:0]           mc_rd_ue,
  input  wire logic [NUM_LANES-1:0]           mc_rd_dbus,
  input  wire logic [NUM_LANES-1:0]           mc_ev_hit,
  input  wire logic [NUM_LANES-1:0]           mc_ev_miss,
  input  wire logic [NUM_LANES-1:0]           mc_ev_conf,
  // ---------------------------------------------------------------- performance counters / status
  input  wire logic                           perf_clr,
  input  wire logic [15:0]                    perf_sel,
  output logic [63:0]                         perf_data,
  output logic                                idle_o,
  output logic [NUM_LANES*3-1:0]              link_state_o,
  output logic                                err_spurious_o,     // sticky: a backend response matched no live transaction
  output logic                                err_timeout_o       // sticky: a transaction timed out
);

  // ------------------------------------------------------------------ elaboration checks
  generate
    if (NUM_SRC < 1 || NUM_SRC > 16) begin : g_e_src
      $error("sf_hbm_sched_top: NUM_SRC must be 1..16");
    end
    if (OUT_PER_SRC < 2 || (OUT_PER_SRC & (OUT_PER_SRC - 1)) != 0) begin : g_e_out
      $error("sf_hbm_sched_top: OUT_PER_SRC must be a power of two >= 2");
    end
    if (NUM_LANES > 64) begin : g_e_lanes
      $error("sf_hbm_sched_top: NUM_CH * NUM_PC must be <= 64");
    end
    if (DATA_W % 8 != 0 || DATA_W < 32 || BURST_LEN < 1 || BURST_LEN > 16) begin : g_e_data
      $error("sf_hbm_sched_top: DATA_W must be a multiple of 8 (>= 32) and BURST_LEN in 1..16");
    end
    if (RQ_DEPTH < 2 || WQ_DEPTH < 2 || LANE_OUT < 1 || LANE_OUT > 64 || WD_DEPTH < 1 || CMD_DEPTH < 1) begin : g_e_q
      $error("sf_hbm_sched_top: queue / outstanding depth out of range");
    end
    if (ID_W < 1 || ID_W > 16) begin : g_e_id
      $error("sf_hbm_sched_top: ID_W must be 1..16");
    end
    if (RST_HOLD < 0 || RST_HOLD >= (1 << 24) || CAL_TIMEOUT < 0 || CAL_TIMEOUT >= (1 << 24)) begin : g_e_timer
      $error("sf_hbm_sched_top: RST_HOLD and CAL_TIMEOUT must fit the 24-bit link timer");
    end
    if (ORDER_MODE != 0 && ORDER_MODE != 1) begin : g_e_order
      $error("sf_hbm_sched_top: ORDER_MODE must be 0 or 1");
    end
    if (AGE_W < 4 || AGE_W > 16) begin : g_e_age
      $error("sf_hbm_sched_top: AGE_W must be 4..16");
    end
  endgenerate

  // ------------------------------------------------------------------ timestamp
  logic [TS_W-1:0] ts_q;
  always_ff @(posedge clk) begin
    if (!rst_n) ts_q <= '0;
    else        ts_q <= ts_q + 1'b1;
  end

  // ------------------------------------------------------------------ front end: map + validate (per source)
  logic [NUM_SRC-1:0]             fe_ok;
  logic [NUM_SRC*4-1:0]           fe_status;
  logic [NUM_SRC*LANE_IW-1:0]     fe_lane;
  logic [NUM_SRC*LA_W-1:0]        fe_la;
  logic [NUM_SRC*TAG_W-1:0]       fe_tag;
  logic [NUM_SRC-1:0]             alloc_ok;
  logic [NUM_SRC*SLOT_W-1:0]      alloc_slot;

  genvar gs;
  generate
    for (gs = 0; gs < NUM_SRC; gs = gs + 1) begin : g_fe
      logic [LANE_IW-1:0] lane_w;
      logic [LA_W-1:0]    la_w;
      logic               in_range_w, aligned_w;
      logic [BG_W-1:0]    bg_unused;
      logic [BANK_W-1:0]  bank_unused;
      logic [ROW_W-1:0]   row_unused;
      logic [COL_W-1:0]   col_unused;

      sf_hbm_address_map #(
        .PROFILE(PROFILE), .ADDR_W(ADDR_W), .NUM_CH(NUM_CH), .NUM_PC(NUM_PC), .BURST_BYTES(BURST_BYTES),
        .BG_W(BG_W), .BANK_W(BANK_W), .ROW_W(ROW_W), .COL_W(COL_W), .MAP_MODE(MAP_MODE)
      ) u_map (
        .addr_i(s_req_addr[gs*ADDR_W +: ADDR_W]), .lane_o(lane_w), .la_o(la_w),
        .bg_o(bg_unused), .bank_o(bank_unused), .row_o(row_unused), .col_o(col_unused),
        .in_range_o(in_range_w), .aligned_o(aligned_w)
      );

      sf_hbm_req_check #(
        .ADDR_W(ADDR_W), .NUM_SRC(NUM_SRC), .SRC_IDX(gs), .BURST_BYTES(BURST_BYTES), .NUM_WIN(NUM_WIN)
      ) u_chk (
        .we_i(s_req_we[gs]), .addr_i(s_req_addr[gs*ADDR_W +: ADDR_W]), .wstrb_i(s_req_wstrb[gs*STRB_W +: STRB_W]),
        .in_range_i(in_range_w), .aligned_i(aligned_w),
        .cfg_perm_en(cfg_perm_en), .cfg_win_base(cfg_win_base), .cfg_win_last(cfg_win_last), .cfg_win_perm(cfg_win_perm),
        .ok_o(fe_ok[gs]), .status_o(fe_status[gs*4 +: 4])
      );

      assign fe_lane[gs*LANE_IW +: LANE_IW] = lane_w;
      assign fe_la[gs*LA_W +: LA_W]         = la_w;
      assign fe_tag[gs*TAG_W +: TAG_W]      = {gs[SRC_W-1:0], alloc_slot[gs*SLOT_W +: SLOT_W]};

      logic unused_fe;
      assign unused_fe = &{1'b0, bg_unused, bank_unused, row_unused, col_unused};
    end
  endgenerate

  // ------------------------------------------------------------------ lanes
  logic [NUM_LANES*NUM_SRC-1:0]  ln_in_valid, ln_gnt, ln_arb_loss;
  logic [NUM_LANES-1:0]          trk_iss_valid, trk_rb_valid, trk_rb_last, trk_rb_err, trk_rb_ce, trk_rb_ue, trk_rb_dbus;
  logic [NUM_LANES-1:0]          trk_wr_valid, trk_wr_err, trk_flush;
  logic [NUM_LANES*TAG_W-1:0]    trk_iss_tag, trk_rb_tag, trk_wr_tag;
  logic [NUM_LANES*DATA_W-1:0]   trk_rb_data;

  logic [NUM_LANES*RCNT_W-1:0]   ln_rq_count;
  logic [NUM_LANES*WCNT_W-1:0]   ln_wq_count;
  logic [NUM_LANES*OCNT_W-1:0]   ln_out_cnt;
  logic [NUM_LANES-1:0]          ln_ev_iss_rd, ln_ev_iss_wr, ln_ev_hit, ln_ev_miss, ln_ev_conf, ln_ev_be_hit, ln_ev_be_miss, ln_ev_be_conf;
  logic [NUM_LANES-1:0]          ln_ev_bank_conf, ln_ev_turn, ln_ev_qfull_rd, ln_ev_qfull_wr, ln_ev_ref_stall, ln_ev_haz_stall;
  logic [NUM_LANES-1:0]          ln_ev_be_stall, ln_ev_age_ovr, ln_ev_byp_ovr, ln_ev_drain, ln_ev_link_rst, ln_ev_unavail, ln_ev_idle;
  logic [NUM_LANES*AGE_W-1:0]    ln_ev_qw;
  logic [NUM_LANES*2-1:0]        ln_ev_beats;

  genvar gl;
  generate
    for (gl = 0; gl < NUM_LANES; gl = gl + 1) begin : g_lane
      always_comb begin
        for (int s = 0; s < NUM_SRC; s++) begin
          ln_in_valid[gl*NUM_SRC + s] = s_req_valid[s] && fe_ok[s] && alloc_ok[s] &&
                                        (fe_lane[s*LANE_IW +: LANE_IW] == gl[LANE_IW-1:0]);
        end
      end

      sf_hbm_lane #(
        .NUM_SRC(NUM_SRC), .TAG_W(TAG_W), .DATA_W(DATA_W), .BURST_LEN(BURST_LEN),
        .OFF_W(OFF_W), .COL_W(COL_W), .BG_W(BG_W), .BANK_W(BANK_W), .ROW_W(ROW_W),
        .RQ_DEPTH(RQ_DEPTH), .WQ_DEPTH(WQ_DEPTH), .AGE_W(AGE_W), .BUSY_W(BUSY_W), .BYP_W(BYP_W),
        .LANE_OUT(LANE_OUT), .WD_DEPTH(WD_DEPTH), .CMD_DEPTH(CMD_DEPTH), .RST_HOLD(RST_HOLD),
        .CAL_TIMEOUT(CAL_TIMEOUT), .BE_ORDER_SAFE(BE_ORDER_SAFE), .SHADOW_CLR_BUSY(SHADOW_CLR_BUSY)
      ) u_lane (
        .clk(clk), .rst_n(rst_n),
        .cfg_policy(cfg_policy), .cfg_wr_hi(cfg_wr_hi), .cfg_wr_lo(cfg_wr_lo), .cfg_age_limit(cfg_age_limit),
        .cfg_idle_wr(cfg_idle_wr), .cfg_busy_cyc(cfg_busy_cyc), .cfg_bypass_cap(cfg_bypass_cap), .cfg_arb_mode(cfg_arb_mode),
        .cfg_arb_prio(cfg_arb_prio), .cfg_arb_age(cfg_arb_age), .cfg_link_retry(cfg_link_retry),
        .in_valid(ln_in_valid[gl*NUM_SRC +: NUM_SRC]), .in_we(s_req_we), .in_tag(fe_tag), .in_la(fe_la),
        .in_wdata(s_req_wdata), .in_wstrb(s_req_wstrb), .in_gnt(ln_gnt[gl*NUM_SRC +: NUM_SRC]),
        .arb_loss_o(ln_arb_loss[gl*NUM_SRC +: NUM_SRC]),
        .mc_rst_n(mc_rst_n[gl]), .mc_init_done(mc_init_done[gl]), .mc_fatal(mc_fatal[gl]),
        .mc_cmd_valid(mc_cmd_valid[gl]), .mc_cmd_ready(mc_cmd_ready[gl]), .mc_cmd_write(mc_cmd_write[gl]),
        .mc_cmd_addr(mc_cmd_addr[gl*LA_W +: LA_W]), .mc_cmd_len(mc_cmd_len[gl*8 +: 8]),
        .mc_cmd_tag(mc_cmd_tag[gl*TAG_W +: TAG_W]),
        .mc_wd_valid(mc_wd_valid[gl]), .mc_wd_ready(mc_wd_ready[gl]), .mc_wd_data(mc_wd_data[gl*DATA_W +: DATA_W]),
        .mc_wd_strb(mc_wd_strb[gl*BSTRB_W +: BSTRB_W]), .mc_wd_last(mc_wd_last[gl]),
        .mc_rd_valid(mc_rd_valid[gl]), .mc_rd_ready(mc_rd_ready[gl]), .mc_rd_data(mc_rd_data[gl*DATA_W +: DATA_W]),
        .mc_rd_tag(mc_rd_tag[gl*TAG_W +: TAG_W]), .mc_rd_last(mc_rd_last[gl]), .mc_rd_error(mc_rd_error[gl]),
        .mc_wr_valid(mc_wr_valid[gl]), .mc_wr_ready(mc_wr_ready[gl]), .mc_wr_tag(mc_wr_tag[gl*TAG_W +: TAG_W]),
        .mc_wr_error(mc_wr_error[gl]),
        .mc_busy(mc_busy[gl]), .mc_rd_ce(mc_rd_ce[gl]), .mc_rd_ue(mc_rd_ue[gl]), .mc_rd_dbus(mc_rd_dbus[gl]),
        .mc_ev_hit(mc_ev_hit[gl]), .mc_ev_miss(mc_ev_miss[gl]), .mc_ev_conf(mc_ev_conf[gl]),
        .trk_iss_valid(trk_iss_valid[gl]), .trk_iss_tag(trk_iss_tag[gl*TAG_W +: TAG_W]),
        .trk_rb_valid(trk_rb_valid[gl]), .trk_rb_tag(trk_rb_tag[gl*TAG_W +: TAG_W]),
        .trk_rb_data(trk_rb_data[gl*DATA_W +: DATA_W]), .trk_rb_last(trk_rb_last[gl]), .trk_rb_err(trk_rb_err[gl]),
        .trk_rb_ce(trk_rb_ce[gl]), .trk_rb_ue(trk_rb_ue[gl]), .trk_rb_dbus(trk_rb_dbus[gl]),
        .trk_wr_valid(trk_wr_valid[gl]), .trk_wr_tag(trk_wr_tag[gl*TAG_W +: TAG_W]), .trk_wr_err(trk_wr_err[gl]),
        .trk_flush(trk_flush[gl]),
        .rq_count_o(ln_rq_count[gl*RCNT_W +: RCNT_W]), .wq_count_o(ln_wq_count[gl*WCNT_W +: WCNT_W]),
        .out_cnt_o(ln_out_cnt[gl*OCNT_W +: OCNT_W]), .link_state_o(link_state_o[gl*3 +: 3]),
        .ev_iss_rd(ln_ev_iss_rd[gl]), .ev_iss_wr(ln_ev_iss_wr[gl]), .ev_qw(ln_ev_qw[gl*AGE_W +: AGE_W]),
        .ev_beats(ln_ev_beats[gl*2 +: 2]), .ev_hit(ln_ev_hit[gl]), .ev_miss(ln_ev_miss[gl]), .ev_conf(ln_ev_conf[gl]),
        .ev_be_hit(ln_ev_be_hit[gl]), .ev_be_miss(ln_ev_be_miss[gl]), .ev_be_conf(ln_ev_be_conf[gl]),
        .ev_bank_conf(ln_ev_bank_conf[gl]), .ev_turn(ln_ev_turn[gl]), .ev_qfull_rd(ln_ev_qfull_rd[gl]),
        .ev_qfull_wr(ln_ev_qfull_wr[gl]), .ev_ref_stall(ln_ev_ref_stall[gl]), .ev_haz_stall(ln_ev_haz_stall[gl]),
        .ev_be_stall(ln_ev_be_stall[gl]), .ev_age_ovr(ln_ev_age_ovr[gl]), .ev_byp_ovr(ln_ev_byp_ovr[gl]), .ev_drain(ln_ev_drain[gl]),
        .ev_link_rst(ln_ev_link_rst[gl]), .ev_unavail(ln_ev_unavail[gl]), .ev_idle(ln_ev_idle[gl])
      );
    end
  endgenerate

  // ------------------------------------------------------------------ accept handshake and tracker allocation
  logic [NUM_SRC-1:0]         acc;            // request accepted this cycle
  logic [NUM_SRC*BYTES_W-1:0] a_bytes;
  logic [NUM_SRC*4-1:0]       a_status;
  logic [NUM_SRC-1:0]         gnt_any;

  always_comb begin
    for (int s = 0; s < NUM_SRC; s++) begin
      gnt_any[s] = 1'b0;
      for (int l = 0; l < NUM_LANES; l++) gnt_any[s] = gnt_any[s] | ln_gnt[l*NUM_SRC + s];
      s_req_ready[s] = fe_ok[s] ? gnt_any[s] : alloc_ok[s];
      acc[s]         = s_req_valid[s] && s_req_ready[s];
      a_status[s*4 +: 4] = fe_ok[s] ? `SF_HBM_ST_OK : fe_status[s*4 +: 4];
      a_bytes[s*BYTES_W +: BYTES_W] = '0;
      if (!s_req_we[s]) begin
        a_bytes[s*BYTES_W +: BYTES_W] = BURST_BYTES[BYTES_W-1:0];
      end else begin
        for (int b = 0; b < STRB_W; b++) begin
          a_bytes[s*BYTES_W +: BYTES_W] = a_bytes[s*BYTES_W +: BYTES_W] + {{(BYTES_W-1){1'b0}}, s_req_wstrb[s*STRB_W + b]};
        end
      end
    end
  end

  // ------------------------------------------------------------------ response tracker
  logic [NUM_SRC-1:0]            ev_rsp, ev_err_rsp, ev_reordered;
  logic [NUM_SRC*TS_W-1:0]       ev_lat;
  logic [NUM_SRC*BYTES_W-1:0]    ev_rbytes, ev_wbytes;
  logic [NUM_SRC*8-1:0]          rob_depth;
  logic [NUM_SRC*8-1:0]          ev_qw_cnt;
  logic [NUM_SRC*16-1:0]         ev_qw_sum;
  logic [7:0]                    ev_timeout_n, ev_spurious_n, ev_flushed_n;
  logic [15:0]                   zombie_n, out_total;
  logic [NUM_SRC*LIM_W-1:0]      live_cnt;

  sf_hbm_response_tracker #(
    .NUM_SRC(NUM_SRC), .NUM_LANES(NUM_LANES), .OUT_PER_SRC(OUT_PER_SRC), .ID_W(ID_W), .DATA_W(DATA_W),
    .BURST_LEN(BURST_LEN), .ORDER_MODE(ORDER_MODE), .TS_W(TS_W), .BYTES_W(BYTES_W)
  ) u_trk (
    .clk(clk), .rst_n(rst_n), .ts_i(ts_q), .cfg_timeout(cfg_timeout), .cfg_out_limit(cfg_out_limit),
    .alloc_ok_o(alloc_ok), .alloc_slot_o(alloc_slot),
    .a_valid(acc), .a_id(s_req_id), .a_we(s_req_we), .a_lane(fe_lane), .a_status(a_status), .a_bytes(a_bytes),
    .iss_valid(trk_iss_valid), .iss_tag(trk_iss_tag),
    .rb_valid(trk_rb_valid), .rb_tag(trk_rb_tag), .rb_data(trk_rb_data), .rb_last(trk_rb_last), .rb_err(trk_rb_err),
    .rb_ce(trk_rb_ce), .rb_ue(trk_rb_ue), .rb_dbus(trk_rb_dbus),
    .wr_valid(trk_wr_valid), .wr_tag(trk_wr_tag), .wr_err(trk_wr_err), .flush(trk_flush),
    .r_valid(s_rsp_valid), .r_ready(s_rsp_ready), .r_id(s_rsp_id), .r_we(s_rsp_we), .r_data(s_rsp_data),
    .r_status(s_rsp_status),
    .ev_rsp(ev_rsp), .ev_lat(ev_lat), .ev_err_rsp(ev_err_rsp), .ev_rbytes(ev_rbytes), .ev_wbytes(ev_wbytes),
    .ev_reordered(ev_reordered), .rob_depth_o(rob_depth), .ev_qw_cnt(ev_qw_cnt), .ev_qw_sum(ev_qw_sum),
    .ev_timeout_n(ev_timeout_n), .ev_spurious_n(ev_spurious_n), .ev_flushed_n(ev_flushed_n),
    .zombie_n_o(zombie_n), .out_total_o(out_total), .live_cnt_o(live_cnt)
  );

  // ------------------------------------------------------------------ sticky error flags / idle
  always_ff @(posedge clk) begin
    if (!rst_n || perf_clr) begin
      err_spurious_o <= 1'b0;
      err_timeout_o  <= 1'b0;
    end else begin
      if (ev_spurious_n != 8'd0) err_spurious_o <= 1'b1;
      if (ev_timeout_n  != 8'd0) err_timeout_o  <= 1'b1;
    end
  end
  assign idle_o = (&ln_ev_idle) && (out_total == 16'd0);

  // ------------------------------------------------------------------ performance counter event assembly
  function automatic logic [INC_W-1:0] clamp16(input logic [31:0] x);
    clamp16 = (x > 32'd65535) ? 16'hFFFF : x[15:0];
  endfunction

  logic [`SF_HBM_G_N*INC_W-1:0]             g_inc;
  logic [NUM_LANES*`SF_HBM_L_N*INC_W-1:0]   l_inc;
  logic [NUM_SRC*`SF_HBM_S_N*INC_W-1:0]     s_inc;
  logic [16*4-1:0]                          h_inc;

  always_comb begin
    logic [31:0] n_req, n_rsp, n_err, n_rby, n_wby, n_ing, n_rej, n_lat, m_lat, n_rob;
    logic [31:0] lat_s;
    int          hb;
    hb = 0;
    n_req = 0; n_rsp = 0; n_err = 0; n_rby = 0; n_wby = 0; n_ing = 0; n_rej = 0; n_lat = 0; m_lat = 0; n_rob = 0;
    h_inc = '0;
    lat_s = '0;
    for (int s = 0; s < NUM_SRC; s++) begin
      lat_s = {{(32-TS_W){1'b0}}, ev_lat[s*TS_W +: TS_W]};
      n_req = n_req + {31'd0, acc[s]};
      n_rsp = n_rsp + {31'd0, ev_rsp[s]};
      n_err = n_err + {31'd0, ev_err_rsp[s]};
      n_rby = n_rby + {{(32-BYTES_W){1'b0}}, ev_rbytes[s*BYTES_W +: BYTES_W]};
      n_wby = n_wby + {{(32-BYTES_W){1'b0}}, ev_wbytes[s*BYTES_W +: BYTES_W]};
      n_ing = n_ing + {31'd0, (s_req_valid[s] && !s_req_ready[s])};
      n_rej = n_rej + {31'd0, (acc[s] && !fe_ok[s])};
      if (ev_rsp[s]) begin
        n_lat = n_lat + lat_s;
        if (lat_s > m_lat) m_lat = lat_s;
        hb = 0;
        for (int b = 1; b < 16; b++) if (lat_s >= (32'd1 << b)) hb = b;
        h_inc[hb*4 +: 4] = h_inc[hb*4 +: 4] + 4'd1;
      end
      if (rob_depth[s*8 +: 8] != 8'd0) n_rob = 32'd1;
    end
    g_inc = '0;
    g_inc[`SF_HBM_G_CYCLES*INC_W   +: INC_W] = 16'd1;
    g_inc[`SF_HBM_G_ACTIVE*INC_W   +: INC_W] = {15'd0, (out_total != 16'd0)};
    g_inc[`SF_HBM_G_REQ*INC_W      +: INC_W] = clamp16(n_req);
    g_inc[`SF_HBM_G_RSP*INC_W      +: INC_W] = clamp16(n_rsp);
    g_inc[`SF_HBM_G_RSP_ERR*INC_W  +: INC_W] = clamp16(n_err);
    g_inc[`SF_HBM_G_BYTES_RD*INC_W +: INC_W] = clamp16(n_rby);
    g_inc[`SF_HBM_G_BYTES_WR*INC_W +: INC_W] = clamp16(n_wby);
    g_inc[`SF_HBM_G_ING_STALL*INC_W +: INC_W] = clamp16(n_ing);
    g_inc[`SF_HBM_G_REJECT*INC_W   +: INC_W] = clamp16(n_rej);
    g_inc[`SF_HBM_G_TIMEOUT*INC_W  +: INC_W] = {8'd0, ev_timeout_n};
    g_inc[`SF_HBM_G_SPURIOUS*INC_W +: INC_W] = {8'd0, ev_spurious_n};
    g_inc[`SF_HBM_G_FLUSHED*INC_W  +: INC_W] = {8'd0, ev_flushed_n};
    g_inc[`SF_HBM_G_ZOMBIE_CYC*INC_W +: INC_W] = zombie_n;
    g_inc[`SF_HBM_G_LAT_SUM*INC_W  +: INC_W] = clamp16(n_lat);
    g_inc[`SF_HBM_G_LAT_MAX*INC_W  +: INC_W] = clamp16(m_lat);
    g_inc[`SF_HBM_G_OUT_SUM*INC_W  +: INC_W] = out_total;
    g_inc[`SF_HBM_G_OUT_MAX*INC_W  +: INC_W] = out_total;
    g_inc[`SF_HBM_G_ROB_STALL*INC_W +: INC_W] = clamp16(n_rob);
  end

  always_comb begin
    l_inc = '0;
    for (int l = 0; l < NUM_LANES; l++) begin
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_ISS_RD)*INC_W    +: INC_W] = {15'd0, ln_ev_iss_rd[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_ISS_WR)*INC_W    +: INC_W] = {15'd0, ln_ev_iss_wr[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_BEATS)*INC_W     +: INC_W] = {14'd0, ln_ev_beats[l*2 +: 2]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_HIT)*INC_W       +: INC_W] = {15'd0, ln_ev_hit[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_MISS)*INC_W      +: INC_W] = {15'd0, ln_ev_miss[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_CONF)*INC_W      +: INC_W] = {15'd0, ln_ev_conf[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_BE_HIT)*INC_W    +: INC_W] = {15'd0, ln_ev_be_hit[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_BE_MISS)*INC_W   +: INC_W] = {15'd0, ln_ev_be_miss[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_BE_CONF)*INC_W   +: INC_W] = {15'd0, ln_ev_be_conf[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_BANK_CONF)*INC_W +: INC_W] = {15'd0, ln_ev_bank_conf[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_TURN)*INC_W      +: INC_W] = {15'd0, ln_ev_turn[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_QFULL_RD)*INC_W  +: INC_W] = {15'd0, ln_ev_qfull_rd[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_QFULL_WR)*INC_W  +: INC_W] = {15'd0, ln_ev_qfull_wr[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_RQ_OCC_SUM)*INC_W +: INC_W] = {{(INC_W-RCNT_W){1'b0}}, ln_rq_count[l*RCNT_W +: RCNT_W]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_WQ_OCC_SUM)*INC_W +: INC_W] = {{(INC_W-WCNT_W){1'b0}}, ln_wq_count[l*WCNT_W +: WCNT_W]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_RQ_MAX)*INC_W    +: INC_W] = {{(INC_W-RCNT_W){1'b0}}, ln_rq_count[l*RCNT_W +: RCNT_W]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_WQ_MAX)*INC_W    +: INC_W] = {{(INC_W-WCNT_W){1'b0}}, ln_wq_count[l*WCNT_W +: WCNT_W]};
      if (ln_ev_iss_rd[l] || ln_ev_iss_wr[l]) begin
        l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_QW_SUM)*INC_W  +: INC_W] = {{(INC_W-AGE_W){1'b0}}, ln_ev_qw[l*AGE_W +: AGE_W]};
        l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_QW_CNT)*INC_W  +: INC_W] = 16'd1;
        l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_QW_MAX)*INC_W  +: INC_W] = {{(INC_W-AGE_W){1'b0}}, ln_ev_qw[l*AGE_W +: AGE_W]};
      end
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_REF_STALL)*INC_W +: INC_W] = {15'd0, ln_ev_ref_stall[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_HAZ_STALL)*INC_W +: INC_W] = {15'd0, ln_ev_haz_stall[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_BE_STALL)*INC_W  +: INC_W] = {15'd0, ln_ev_be_stall[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_AGE_OVR)*INC_W   +: INC_W] = {15'd0, ln_ev_age_ovr[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_BYP_OVR)*INC_W   +: INC_W] = {15'd0, ln_ev_byp_ovr[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_DRAIN_CYC)*INC_W +: INC_W] = {15'd0, ln_ev_drain[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_OUT_SUM)*INC_W   +: INC_W] = {{(INC_W-OCNT_W){1'b0}}, ln_out_cnt[l*OCNT_W +: OCNT_W]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_OUT_MAX)*INC_W   +: INC_W] = {{(INC_W-OCNT_W){1'b0}}, ln_out_cnt[l*OCNT_W +: OCNT_W]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_LINK_RST)*INC_W  +: INC_W] = {15'd0, ln_ev_link_rst[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_UNAVAIL)*INC_W   +: INC_W] = {15'd0, ln_ev_unavail[l]};
      l_inc[(l*`SF_HBM_L_N + `SF_HBM_L_IDLE_CYC)*INC_W  +: INC_W] = {15'd0, ln_ev_idle[l]};
    end
  end

  always_comb begin
    logic [31:0] lat_s;
    logic [31:0] by_s;
    logic        lost_any;
    s_inc = '0;
    lost_any = 1'b0;
    for (int s = 0; s < NUM_SRC; s++) begin
      lat_s = {{(32-TS_W){1'b0}}, ev_lat[s*TS_W +: TS_W]};
      by_s  = {{(32-BYTES_W){1'b0}}, ev_rbytes[s*BYTES_W +: BYTES_W]} + {{(32-BYTES_W){1'b0}}, ev_wbytes[s*BYTES_W +: BYTES_W]};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_REQ)*INC_W      +: INC_W] = {15'd0, acc[s]};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_BYTES)*INC_W    +: INC_W] = clamp16(by_s);
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_RSP)*INC_W      +: INC_W] = {15'd0, ev_rsp[s]};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_ERR)*INC_W      +: INC_W] = {15'd0, ev_err_rsp[s]};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_LAT_SUM)*INC_W  +: INC_W] = ev_rsp[s] ? clamp16(lat_s) : 16'd0;
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_LAT_MAX)*INC_W  +: INC_W] = ev_rsp[s] ? clamp16(lat_s) : 16'd0;
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_ING_STALL)*INC_W +: INC_W] = {15'd0, (s_req_valid[s] && !s_req_ready[s])};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_ROB_STALL)*INC_W +: INC_W] = {15'd0, (rob_depth[s*8 +: 8] != 8'd0)};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_REORDERED)*INC_W +: INC_W] = {15'd0, ev_reordered[s]};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_ROB_MAXD)*INC_W  +: INC_W] = {8'd0, rob_depth[s*8 +: 8]};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_QW_SUM)*INC_W   +: INC_W] = ev_qw_sum[s*16 +: 16];
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_QW_CNT)*INC_W   +: INC_W] = {8'd0, ev_qw_cnt[s*8 +: 8]};
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_GRANTS)*INC_W   +: INC_W] = {15'd0, (acc[s] && fe_ok[s])};
      lost_any = 1'b0;
      for (int l = 0; l < NUM_LANES; l++) lost_any = lost_any | ln_arb_loss[l*NUM_SRC + s];
      s_inc[(s*`SF_HBM_S_N + `SF_HBM_S_ARB_LOSS)*INC_W +: INC_W] = {15'd0, lost_any};
    end
  end

  sf_hbm_perf #(.NUM_SRC(NUM_SRC), .NUM_LANES(NUM_LANES)) u_perf (
    .clk(clk), .rst_n(rst_n), .clr(perf_clr),
    .g_inc(g_inc), .l_inc(l_inc), .s_inc(s_inc), .h_inc(h_inc),
    .perf_sel(perf_sel), .perf_data(perf_data)
  );

  logic unused_top;
  assign unused_top = &{1'b0, live_cnt};

endmodule
`default_nettype wire
