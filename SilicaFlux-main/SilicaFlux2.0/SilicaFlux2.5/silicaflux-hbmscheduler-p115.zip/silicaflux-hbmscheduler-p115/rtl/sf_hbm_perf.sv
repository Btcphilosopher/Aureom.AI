// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_perf
//
// Performance-counter bank.  Counts what the hardware does at its handshakes
// (the top level wires the events; nothing here is estimated).
//
//   groups : global (1 instance), lane (NUM_LANES), source (NUM_SRC), latency
//            histogram (global; bucket b counts latencies with floor(log2) = b,
//            latency 0 and 1 share bucket 0, the last bucket saturates)
//   kinds  : SUM counters add the per-cycle increment (INC_W bits wide, the
//            top level saturates a sum of several events at 2^INC_W - 1);
//            MAX counters keep the maximum of the observed value.
//   widths : CNT_W (48) bits, wrap on overflow (2^48 cycles = 3 days at 1 GHz).
//
// Read-out: perf_sel = {group[1:0], instance[5:0], index[7:0]} selects one
// counter, perf_data returns it zero-extended to 64 bits (combinational).
// perf_clr (a pulse) clears every counter.  Counter indices: sf_hbm_defs.svh.
// Derived metrics (bytes/cycle, utilisation, row-hit rate, mean latency ...)
// are computed OFF-chip from these raw counts (scripts/gen_report.py).
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_perf #(
  parameter int NUM_SRC   = 5,
  parameter int NUM_LANES = 2,
  parameter int CNT_W     = 48,
  parameter int INC_W     = 16,
  parameter int HIST_B    = 16,
  // which counters are MAX counters (bit = counter index)
  parameter logic [31:0] G_MAX_MASK = (32'd1 << `SF_HBM_G_LAT_MAX) | (32'd1 << `SF_HBM_G_OUT_MAX),
  parameter logic [31:0] L_MAX_MASK = (32'd1 << `SF_HBM_L_RQ_MAX) | (32'd1 << `SF_HBM_L_WQ_MAX) |
                                      (32'd1 << `SF_HBM_L_QW_MAX) | (32'd1 << `SF_HBM_L_OUT_MAX),
  parameter logic [31:0] S_MAX_MASK = (32'd1 << `SF_HBM_S_LAT_MAX) | (32'd1 << `SF_HBM_S_ROB_MAXD)
) (
  input  wire logic                                     clk,
  input  wire logic                                     rst_n,
  input  wire logic                                     clr,
  input  wire logic [`SF_HBM_G_N*INC_W-1:0]             g_inc,
  input  wire logic [NUM_LANES*`SF_HBM_L_N*INC_W-1:0]   l_inc,
  input  wire logic [NUM_SRC*`SF_HBM_S_N*INC_W-1:0]     s_inc,
  input  wire logic [HIST_B*4-1:0]                      h_inc,
  input  wire logic [15:0]                              perf_sel,
  output logic [63:0]                                   perf_data
);

  localparam int GIW = $clog2(`SF_HBM_G_N);
  localparam int HIW = $clog2(HIST_B);
  localparam int NG = `SF_HBM_G_N;
  localparam int NL = `SF_HBM_L_N;
  localparam int NS = `SF_HBM_S_N;

  logic [CNT_W-1:0] g_cnt [0:NG-1];
  logic [CNT_W-1:0] l_cnt [0:NUM_LANES*NL-1];
  logic [CNT_W-1:0] s_cnt [0:NUM_SRC*NS-1];
  logic [CNT_W-1:0] h_cnt [0:HIST_B-1];

  genvar gi, gj;
  generate
    for (gi = 0; gi < NG; gi = gi + 1) begin : g_g
      always_ff @(posedge clk) begin
        if (!rst_n || clr) g_cnt[gi] <= '0;
        else if (G_MAX_MASK[gi]) begin
          if ({{(CNT_W-INC_W){1'b0}}, g_inc[gi*INC_W +: INC_W]} > g_cnt[gi])
            g_cnt[gi] <= {{(CNT_W-INC_W){1'b0}}, g_inc[gi*INC_W +: INC_W]};
        end else g_cnt[gi] <= g_cnt[gi] + {{(CNT_W-INC_W){1'b0}}, g_inc[gi*INC_W +: INC_W]};
      end
    end
    for (gi = 0; gi < NUM_LANES; gi = gi + 1) begin : g_l
      for (gj = 0; gj < NL; gj = gj + 1) begin : g_c
        always_ff @(posedge clk) begin
          if (!rst_n || clr) l_cnt[gi*NL+gj] <= '0;
          else if (L_MAX_MASK[gj]) begin
            if ({{(CNT_W-INC_W){1'b0}}, l_inc[(gi*NL+gj)*INC_W +: INC_W]} > l_cnt[gi*NL+gj])
              l_cnt[gi*NL+gj] <= {{(CNT_W-INC_W){1'b0}}, l_inc[(gi*NL+gj)*INC_W +: INC_W]};
          end else l_cnt[gi*NL+gj] <= l_cnt[gi*NL+gj] + {{(CNT_W-INC_W){1'b0}}, l_inc[(gi*NL+gj)*INC_W +: INC_W]};
        end
      end
    end
    for (gi = 0; gi < NUM_SRC; gi = gi + 1) begin : g_s
      for (gj = 0; gj < NS; gj = gj + 1) begin : g_c
        always_ff @(posedge clk) begin
          if (!rst_n || clr) s_cnt[gi*NS+gj] <= '0;
          else if (S_MAX_MASK[gj]) begin
            if ({{(CNT_W-INC_W){1'b0}}, s_inc[(gi*NS+gj)*INC_W +: INC_W]} > s_cnt[gi*NS+gj])
              s_cnt[gi*NS+gj] <= {{(CNT_W-INC_W){1'b0}}, s_inc[(gi*NS+gj)*INC_W +: INC_W]};
          end else s_cnt[gi*NS+gj] <= s_cnt[gi*NS+gj] + {{(CNT_W-INC_W){1'b0}}, s_inc[(gi*NS+gj)*INC_W +: INC_W]};
        end
      end
    end
    for (gi = 0; gi < HIST_B; gi = gi + 1) begin : g_h
      always_ff @(posedge clk) begin
        if (!rst_n || clr) h_cnt[gi] <= '0;
        else h_cnt[gi] <= h_cnt[gi] + {{(CNT_W-4){1'b0}}, h_inc[gi*4 +: 4]};
      end
    end
  endgenerate

  // ---------------------------------------------------------------- read-out
  logic [1:0] sel_grp;
  logic [5:0] sel_ins;
  logic [7:0] sel_idx;
  logic [CNT_W-1:0] rd;
  always_comb begin
    sel_grp = perf_sel[15:14];
    sel_ins = perf_sel[13:8];
    sel_idx = perf_sel[7:0];
    rd      = '0;
    case (sel_grp)
      `SF_HBM_PG_GLOBAL: if (sel_ins == 6'd0 && sel_idx < NG[7:0]) rd = g_cnt[sel_idx[GIW-1:0]];
      `SF_HBM_PG_LANE:   if ({26'd0, sel_ins} < NUM_LANES && sel_idx < NL[7:0]) rd = l_cnt[{26'd0, sel_ins} * NL + {24'd0, sel_idx}];
      `SF_HBM_PG_SRC:    if ({26'd0, sel_ins} < NUM_SRC && sel_idx < NS[7:0])   rd = s_cnt[{26'd0, sel_ins} * NS + {24'd0, sel_idx}];
      default:           if (sel_ins == 6'd0 && {24'd0, sel_idx} < HIST_B) rd = h_cnt[sel_idx[HIW-1:0]];
    endcase
    perf_data = {{(64-CNT_W){1'b0}}, rd};
  end

endmodule
`default_nettype wire
