// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_scheduler           *** primary RTL ***
//
// Per-lane transaction scheduler.  Every cycle it looks at the registered view
// of the read queue and the write queue and picks AT MOST ONE entry to issue to
// the backend adapter.  It never reorders anything that is not dependency-free:
// `*_ready` already encodes the RAW / WAR / WAW hazard masks of the queues and
// `*_blk` the optional in-flight hazard mask of the lane.
//
// Policies (runtime cfg_policy, see docs/SCHEDULING.md):
//   0 FCFS       strict first-come-first-served over reads AND writes
//                (oldest valid entry; stalls if the backend cannot take it).
//                THIS IS THE MEASURED BASELINE.
//   1 RDPRIO     read priority + watermark write draining (hysteresis
//                cfg_wr_hi / cfg_wr_lo, opportunistic writes when no read is
//                issuable if cfg_idle_wr), FCFS (oldest first) inside the class
//   2 FRFCFS     RDPRIO + row-hit-first inside the class
//   3 BANKAWARE  FRFCFS + bank-group alternation + busy-bank avoidance
// Policies 1-3 include the age-based starvation override: if any issuable entry
// is older than cfg_age_limit cycles the OLDEST issuable entry (either queue) is
// taken, whatever the class / row state (0 = override off).
//
// Bank awareness uses a *shadow* of the backend's banks (open row + a busy
// countdown set at issue).  It is a HEURISTIC HINT built on an open-page
// assumption and on the lane-local address layout of docs/ADDRESS_MAP.md.  The
// backend remains the timing authority: a wrong guess costs performance, never
// correctness.  The shadow open rows are cleared when the backend's busy
// (refresh) indication rises, if SHADOW_CLR_BUSY = 1.
// =============================================================================
`include "sf_hbm_defs.svh"
`default_nettype none

module sf_hbm_scheduler #(
  parameter int RQ_DEPTH       = 16,
  parameter int WQ_DEPTH       = 16,
  parameter int BK_W           = 4,    // bank-group + bank bits
  parameter int BG_W           = 2,    // bank-group bits (the upper BG_W bits of the bank id)
  parameter int ROW_W          = 8,
  parameter int AGE_W          = 12,
  parameter int BUSY_W         = 6,
  parameter int BYP_W          = 6,
  parameter int SHADOW_CLR_BUSY = 1,
  localparam int RIDX_W = (RQ_DEPTH > 1) ? $clog2(RQ_DEPTH) : 1,
  localparam int WIDX_W = (WQ_DEPTH > 1) ? $clog2(WQ_DEPTH) : 1,
  localparam int PIDX_W = (RIDX_W > WIDX_W) ? RIDX_W : WIDX_W,
  localparam int RCNT_W = $clog2(RQ_DEPTH + 1),
  localparam int WCNT_W = $clog2(WQ_DEPTH + 1),
  localparam int NB     = (1 << BK_W),
  localparam int KW     = 3 + AGE_W
) (
  input  wire logic                      clk,
  input  wire logic                      rst_n,
  // runtime configuration (quasi-static)
  input  wire logic [2:0]                cfg_policy,
  input  wire logic [WCNT_W-1:0]         cfg_wr_hi,
  input  wire logic [WCNT_W-1:0]         cfg_wr_lo,
  input  wire logic [AGE_W-1:0]          cfg_age_limit,
  input  wire logic                      cfg_idle_wr,
  input  wire logic [BUSY_W-1:0]         cfg_busy_cyc,
  input  wire logic [BYP_W-1:0]          cfg_bypass_cap,   // policies 1-3: force the oldest issuable entry after this many bypasses (0 = off)
  // read queue view
  input  wire logic [RQ_DEPTH-1:0]       rq_valid,
  input  wire logic [RQ_DEPTH-1:0]       rq_ready,
  input  wire logic [RQ_DEPTH*BK_W-1:0]  rq_bank,
  input  wire logic [RQ_DEPTH*ROW_W-1:0] rq_row,
  input  wire logic [RQ_DEPTH*AGE_W-1:0] rq_age,
  input  wire logic [RQ_DEPTH-1:0]       rq_blk,
  input  wire logic [RCNT_W-1:0]         rq_count,
  // write queue view
  input  wire logic [WQ_DEPTH-1:0]       wq_valid,
  input  wire logic [WQ_DEPTH-1:0]       wq_ready,
  input  wire logic [WQ_DEPTH*BK_W-1:0]  wq_bank,
  input  wire logic [WQ_DEPTH*ROW_W-1:0] wq_row,
  input  wire logic [WQ_DEPTH*AGE_W-1:0] wq_age,
  input  wire logic [WQ_DEPTH-1:0]       wq_blk,
  input  wire logic [WCNT_W-1:0]         wq_count,
  // backend availability
  input  wire logic                      iss_ok_rd,
  input  wire logic                      iss_ok_wr,
  input  wire logic                      be_busy,
  // decision
  output logic                           pick_valid,
  output logic                           pick_wr,
  output logic [PIDX_W-1:0]              pick_idx,
  output logic                           drain_o,
  // events (1-cycle pulses, valid with pick_valid unless noted)
  output logic                           ev_hit,
  output logic                           ev_miss,
  output logic                           ev_conf,
  output logic                           ev_bank_conf,
  output logic                           ev_turn,
  output logic                           ev_age_ovr,
  output logic                           ev_byp_ovr,
  output logic                           ev_drain,        // level: drain mode active this cycle
  output logic                           ev_haz_stall,    // level
  output logic                           ev_be_stall,     // level
  output logic                           ev_ref_stall     // level
);

  // ------------------------------------------------------------------ shadow bank state
  logic [NB-1:0]     sb_open_q;
  logic [ROW_W-1:0]  sb_row_q  [0:NB-1];
  logic [BUSY_W-1:0] sb_busy_q [0:NB-1];
  logic [BG_W-1:0]   last_bg_q;
  logic              last_v_q;
  logic              last_wr_q;
  logic              drain_q;
  logic [BYP_W-1:0]  byp_q;
  logic              busy_d_q;

  // ------------------------------------------------------------------ per-entry classification
  logic [RQ_DEPTH*KW-1:0] keyp_r;
  logic [WQ_DEPTH*KW-1:0] keyp_w;
  logic [2:0]      tier;
  logic [BK_W-1:0] bnk;
  logic [ROW_W-1:0] rw;
  logic [BG_W-1:0] bgx;
  logic            hit, busy_b, same_bg;

  logic [RQ_DEPTH-1:0] elig_r, cand_r;
  logic [WQ_DEPTH-1:0] elig_w, cand_w;

  always_comb begin
    for (int i = 0; i < RQ_DEPTH; i++) begin
      bnk     = rq_bank[i*BK_W +: BK_W];
      rw      = rq_row[i*ROW_W +: ROW_W];
      bgx     = bnk[BK_W-1 -: BG_W];
      hit     = sb_open_q[bnk] && (sb_row_q[bnk] == rw);
      busy_b  = (sb_busy_q[bnk] != '0);
      same_bg = last_v_q && (bgx == last_bg_q);
      if (hit && !same_bg)         tier = 3'd0;
      else if (hit)                tier = 3'd1;
      else if (busy_b)             tier = 3'd4;
      else if (!sb_open_q[bnk])    tier = 3'd2;
      else                         tier = 3'd3;
      cand_r[i] = rq_ready[i] && !rq_blk[i];
      elig_r[i] = rq_ready[i] && !rq_blk[i] && iss_ok_rd;
      if (cfg_policy == `SF_HBM_POL_BANKAWARE)     keyp_r[i*KW +: KW] = {3'd7 - tier, rq_age[i*AGE_W +: AGE_W]};
      else if (cfg_policy == `SF_HBM_POL_FRFCFS)   keyp_r[i*KW +: KW] = {2'b00, hit, rq_age[i*AGE_W +: AGE_W]};
      else                                         keyp_r[i*KW +: KW] = {3'b000, rq_age[i*AGE_W +: AGE_W]};
    end
    for (int i = 0; i < WQ_DEPTH; i++) begin
      bnk     = wq_bank[i*BK_W +: BK_W];
      rw      = wq_row[i*ROW_W +: ROW_W];
      bgx     = bnk[BK_W-1 -: BG_W];
      hit     = sb_open_q[bnk] && (sb_row_q[bnk] == rw);
      busy_b  = (sb_busy_q[bnk] != '0);
      same_bg = last_v_q && (bgx == last_bg_q);
      if (hit && !same_bg)         tier = 3'd0;
      else if (hit)                tier = 3'd1;
      else if (busy_b)             tier = 3'd4;
      else if (!sb_open_q[bnk])    tier = 3'd2;
      else                         tier = 3'd3;
      cand_w[i] = wq_ready[i] && !wq_blk[i];
      elig_w[i] = wq_ready[i] && !wq_blk[i] && iss_ok_wr;
      if (cfg_policy == `SF_HBM_POL_BANKAWARE)     keyp_w[i*KW +: KW] = {3'd7 - tier, wq_age[i*AGE_W +: AGE_W]};
      else if (cfg_policy == `SF_HBM_POL_FRFCFS)   keyp_w[i*KW +: KW] = {2'b00, hit, wq_age[i*AGE_W +: AGE_W]};
      else                                         keyp_w[i*KW +: KW] = {3'b000, wq_age[i*AGE_W +: AGE_W]};
    end
  end

  // ------------------------------------------------------------------ max-key reductions (balanced trees, sf_hbm_maxsel)
  // P : policy key over issuable entries.  A : age over issuable entries.  V : age over all valid entries.
  logic            bpr_v, bpw_v, bar_v, baw_v, bvr_v, bvw_v;
  logic [AGE_W-1:0] bar_k, baw_k, bvr_k, bvw_k;
  logic [RIDX_W-1:0] bpr_i, bar_i, bvr_i;
  logic [WIDX_W-1:0] bpw_i, baw_i, bvw_i;
  logic [KW-1:0]    bpr_k_unused, bpw_k_unused;

  sf_hbm_maxsel #(.N(RQ_DEPTH), .KW(KW))    u_pr (.v(elig_r),   .k(keyp_r), .out_v(bpr_v), .out_i(bpr_i), .out_k(bpr_k_unused));
  sf_hbm_maxsel #(.N(RQ_DEPTH), .KW(AGE_W)) u_ar (.v(elig_r),   .k(rq_age), .out_v(bar_v), .out_i(bar_i), .out_k(bar_k));
  sf_hbm_maxsel #(.N(RQ_DEPTH), .KW(AGE_W)) u_vr (.v(rq_valid), .k(rq_age), .out_v(bvr_v), .out_i(bvr_i), .out_k(bvr_k));
  sf_hbm_maxsel #(.N(WQ_DEPTH), .KW(KW))    u_pw (.v(elig_w),   .k(keyp_w), .out_v(bpw_v), .out_i(bpw_i), .out_k(bpw_k_unused));
  sf_hbm_maxsel #(.N(WQ_DEPTH), .KW(AGE_W)) u_aw (.v(elig_w),   .k(wq_age), .out_v(baw_v), .out_i(baw_i), .out_k(baw_k));
  sf_hbm_maxsel #(.N(WQ_DEPTH), .KW(AGE_W)) u_vw (.v(wq_valid), .k(wq_age), .out_v(bvw_v), .out_i(bvw_i), .out_k(bvw_k));

  // ------------------------------------------------------------------ decision
  logic drain_eff;
  logic starve_r, starve_w, starve_any;
  logic cap_hit, oldest_is_w, oldest_v;
  logic sel_v, sel_wr, sel_age_ovr;
  logic [PIDX_W-1:0] sel_idx;
  logic fc_oldest_is_wr, fc_have;
  logic fc_blk;

  always_comb begin
    drain_eff = (wq_count >= cfg_wr_hi) || (drain_q && (wq_count > cfg_wr_lo));
    starve_r  = (cfg_age_limit != '0) && bar_v && (bar_k >= cfg_age_limit);
    starve_w  = (cfg_age_limit != '0) && baw_v && (baw_k >= cfg_age_limit);
    // oldest ISSUABLE entry of either queue (age key); the bypass cap forces it after cfg_bypass_cap younger entries were issued ahead of it
    oldest_v    = bar_v || baw_v;
    oldest_is_w = baw_v && (!bar_v || baw_k > bar_k);
    cap_hit     = (cfg_bypass_cap != '0) && (byp_q >= cfg_bypass_cap) && oldest_v;
    starve_any = starve_r || starve_w;

    sel_v = 1'b0; sel_wr = 1'b0; sel_idx = '0; sel_age_ovr = 1'b0;
    fc_oldest_is_wr = 1'b0; fc_have = 1'b0; fc_blk = 1'b0;

    if (cfg_policy == `SF_HBM_POL_FCFS) begin
      // strict order: the globally oldest valid entry, or nothing
      fc_have         = bvr_v || bvw_v;
      fc_oldest_is_wr = bvw_v && (!bvr_v || bvw_k > bvr_k);
      if (fc_have) begin
        if (fc_oldest_is_wr) begin
          fc_blk  = wq_blk[bvw_i] || !wq_ready[bvw_i];
          sel_v   = iss_ok_wr && !fc_blk;
          sel_wr  = 1'b1;
          sel_idx = {{(PIDX_W-WIDX_W){1'b0}}, bvw_i};
        end else begin
          fc_blk  = rq_blk[bvr_i] || !rq_ready[bvr_i];
          sel_v   = iss_ok_rd && !fc_blk;
          sel_wr  = 1'b0;
          sel_idx = {{(PIDX_W-RIDX_W){1'b0}}, bvr_i};
        end
        // Strict order is kept while the oldest entry is merely waiting for the backend.  If it is blocked by a HAZARD mask (an older
        // in-flight command with BE_ORDER_SAFE = 0, or entries whose ages saturated at 2^AGE_W - 1 and tie), the oldest ISSUABLE entry is
        // taken instead, so FCFS can never wait for an entry that only an issuable one can unblock.
        if (fc_blk && oldest_v) begin
          sel_v = 1'b1;
          if (oldest_is_w) begin sel_wr = 1'b1; sel_idx = {{(PIDX_W-WIDX_W){1'b0}}, baw_i}; end
          else             begin sel_wr = 1'b0; sel_idx = {{(PIDX_W-RIDX_W){1'b0}}, bar_i}; end
        end
      end
    end else if (starve_any || cap_hit) begin
      sel_v       = 1'b1;
      sel_age_ovr = starve_any;
      if (starve_any ? (starve_w && (!starve_r || baw_k > bar_k)) : oldest_is_w) begin
        sel_wr = 1'b1; sel_idx = {{(PIDX_W-WIDX_W){1'b0}}, baw_i};
      end else begin
        sel_wr = 1'b0; sel_idx = {{(PIDX_W-RIDX_W){1'b0}}, bar_i};
      end
    end else if (drain_eff && bpw_v) begin
      sel_v = 1'b1; sel_wr = 1'b1; sel_idx = {{(PIDX_W-WIDX_W){1'b0}}, bpw_i};
    end else if (bpr_v) begin
      sel_v = 1'b1; sel_wr = 1'b0; sel_idx = {{(PIDX_W-RIDX_W){1'b0}}, bpr_i};
    end else if (bpw_v && cfg_idle_wr) begin
      sel_v = 1'b1; sel_wr = 1'b1; sel_idx = {{(PIDX_W-WIDX_W){1'b0}}, bpw_i};
    end
  end

  assign pick_valid = sel_v;
  assign pick_wr    = sel_wr;
  assign pick_idx   = sel_idx;
  assign drain_o    = drain_eff;

  // ------------------------------------------------------------------ classification of the picked entry (for events + shadow update)
  logic [BK_W-1:0]  p_bank;
  logic [ROW_W-1:0] p_row;
  logic             p_hit, p_open, p_busy;
  always_comb begin
    p_bank = '0;
    p_row  = '0;
    if (sel_wr) begin
      p_bank = wq_bank[sel_idx[WIDX_W-1:0]*BK_W +: BK_W];
      p_row  = wq_row[sel_idx[WIDX_W-1:0]*ROW_W +: ROW_W];
    end else begin
      p_bank = rq_bank[sel_idx[RIDX_W-1:0]*BK_W +: BK_W];
      p_row  = rq_row[sel_idx[RIDX_W-1:0]*ROW_W +: ROW_W];
    end
    p_open = sb_open_q[p_bank];
    p_hit  = p_open && (sb_row_q[p_bank] == p_row);
    p_busy = (sb_busy_q[p_bank] != '0);
  end

  assign ev_hit       = sel_v && p_hit;
  assign ev_miss      = sel_v && !p_open;
  assign ev_conf      = sel_v && p_open && !p_hit;
  assign ev_bank_conf = sel_v && p_busy;
  assign ev_turn      = sel_v && last_v_q && (last_wr_q != sel_wr);
  assign ev_age_ovr   = sel_v && sel_age_ovr;
  assign ev_byp_ovr   = sel_v && (cfg_policy != `SF_HBM_POL_FCFS) && !sel_age_ovr && cap_hit;
  assign ev_drain     = drain_eff;
  assign ev_haz_stall = ((|rq_valid) || (|wq_valid)) && !(|cand_r) && !(|cand_w);
  assign ev_be_stall  = ((|cand_r) || (|cand_w)) && !iss_ok_rd && !iss_ok_wr;
  assign ev_ref_stall = ((rq_count != '0) || (wq_count != '0)) && be_busy;

  // ------------------------------------------------------------------ state update
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      sb_open_q <= '0;
      for (int b = 0; b < NB; b++) begin sb_row_q[b] <= '0; sb_busy_q[b] <= '0; end
      last_bg_q <= '0;
      last_v_q  <= 1'b0;
      last_wr_q <= 1'b0;
      drain_q   <= 1'b0;
      busy_d_q  <= 1'b0;
      byp_q     <= '0;
    end else begin
      busy_d_q <= be_busy;
      drain_q  <= drain_eff;
      for (int b = 0; b < NB; b++) begin
        if (sb_busy_q[b] != '0) sb_busy_q[b] <= sb_busy_q[b] - 1'b1;
      end
      if (SHADOW_CLR_BUSY != 0 && be_busy && !busy_d_q) sb_open_q <= '0;
      if (sel_v && cfg_policy != `SF_HBM_POL_FCFS) begin
        // bypass accounting: an issue that is not the oldest issuable entry is a bypass
        if (oldest_v && (sel_wr == oldest_is_w) && (sel_wr ? (sel_idx[WIDX_W-1:0] == baw_i) : (sel_idx[RIDX_W-1:0] == bar_i))) byp_q <= '0;
        else if (byp_q != {BYP_W{1'b1}}) byp_q <= byp_q + 1'b1;
      end
      if (sel_v) begin
        sb_open_q[p_bank] <= 1'b1;
        sb_row_q[p_bank]  <= p_row;
        sb_busy_q[p_bank] <= p_hit ? '0 : cfg_busy_cyc;
        last_bg_q         <= p_bank[BK_W-1 -: BG_W];
        last_v_q          <= 1'b1;
        last_wr_q         <= sel_wr;
      end
    end
  end

endmodule
`default_nettype wire
