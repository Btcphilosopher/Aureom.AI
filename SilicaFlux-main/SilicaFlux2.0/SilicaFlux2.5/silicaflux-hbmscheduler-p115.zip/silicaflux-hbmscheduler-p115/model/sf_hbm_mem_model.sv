// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_mem_model
//
//  ***  SIMULATION-ONLY.  NOT SYNTHESIZABLE.  NOT AN HBM CONTROLLER OR PHY.  ***
//
// A configurable, timing-AWARE behavioural stand-in for "HBM controller +
// DRAM" behind the SFMC interface of ONE lane (one pseudo-channel's worth of
// banks).  It exists to give the scheduler something that costs cycles in the
// ways a DRAM does, so scheduling policies can be compared.
//
// What it models (every parameter is a controller-clock cycle count):
//   * banks (bank-group x bank) with an open row (open-page policy)
//   * ACT / PRE / RD / WR command slots, ONE command per cycle
//   * tRCD tRP tRAS tRTP tWR tCL tCWL tCCD_S/L tRRD_S/L tFAW tWTR_S/L tRTW
//   * bank conflicts (PRE + ACT), row misses (ACT), row hits
//   * data-bus occupancy (BURST_LEN cycles per access) and read/write turnaround
//   * all-bank refresh: every T_REFI cycles banks are closed, no command for
//     T_RFC cycles; mc_busy is high from the refresh request to its end
//   * a bounded in-order command window (CMDQ) with LOOKAHEAD row preparation:
//     column commands issue strictly in command-acceptance order, but PRE/ACT of
//     the next LOOKAHEAD commands (different banks) may proceed early.  Same-
//     address accesses therefore take effect in acceptance order (SFMC C9).
//   * response timing: reads return after tCL + burst, writes respond after the
//     write data; optional random extra delay (RSP_JITTER), out-of-order
//     completion (the jitter makes responses of different tags overtake), and
//     interleaving of read beats of different tags (INTERLEAVE)
//   * ORDER_VIOLATE = 1 additionally lets columns issue out of acceptance order
//     (an adversarial / AXI-like backend WITHOUT rule C9) -- used only to show
//     that the BE_ORDER_SAFE = 0 scheduler build still preserves ordering
//   * fault injection: poisoned address ranges (backend error, ECC CE / UE,
//     data-bus error), hang, calibration drop, fatal
//   * a command log (+CMDLOG=<file>) that an independent checker
//     (scripts/check_timing_log.py) validates against every timing rule above
//
// NOT modelled: DFI / PHY, training, per-bank refresh, self-refresh, power
// states, rank/stack structure, ECC data correction (flags only), real device
// timing.  Timing numbers are HYPOTHETICAL: they are not JEDEC / vendor values
// and nothing measured with this model is a physical-performance claim.
// =============================================================================
`include "sf_hbm_model_defs.svh"
`default_nettype none

module sf_hbm_mem_model #(
  parameter int DATA_W     = 128,
  parameter int BURST_LEN  = 2,
  parameter int TAG_W      = 6,
  parameter int OFF_W      = 5,
  parameter int COL_W      = 5,
  parameter int BG_W       = 2,
  parameter int BANK_W     = 2,
  parameter int ROW_W      = 8,
  parameter int CMDQ       = 8,
  parameter int LOOKAHEAD  = 4,
  parameter int RPQ        = 64,
  // ---- timing (controller-clock cycles)
  parameter int T_RCD      = 14,
  parameter int T_RP       = 14,
  parameter int T_RAS      = 33,
  parameter int T_CL       = 14,
  parameter int T_CWL      = 7,
  parameter int T_WR       = 15,
  parameter int T_RTP      = 5,
  parameter int T_CCD_S    = 2,
  parameter int T_CCD_L    = 4,
  parameter int T_RRD_S    = 4,
  parameter int T_RRD_L    = 6,
  parameter int T_FAW      = 16,
  parameter int T_WTR_S    = 4,
  parameter int T_WTR_L    = 8,
  parameter int T_RTW      = 11,
  parameter int T_REFI     = 3900,
  parameter int T_RFC      = 260,
  parameter int REFRESH_EN = 1,
  // ---- behaviour
  parameter int RSP_JITTER    = 0,
  parameter int INTERLEAVE    = 0,
  parameter int ORDER_VIOLATE = 0,
  parameter int CAL_CYCLES    = 20,
  parameter int ACCEPT_PCT    = 100,
  parameter int SEED          = 1,
  parameter int LANE_ID       = 0,
  localparam int LA_W    = OFF_W + COL_W + BG_W + BANK_W + ROW_W,
  localparam int BK_W    = BG_W + BANK_W,
  localparam int NB      = (1 << (BG_W + BANK_W)),
  localparam int BSTRB_W = DATA_W / 8,
  localparam int LINE_W  = DATA_W * BURST_LEN,
  localparam int MEM_BYTES = (1 << LA_W),
  localparam int WDQ     = CMDQ * BURST_LEN + 4
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,          // system reset of the model (memory content survives)
  // ---- SFMC (slave side)
  input  wire logic                 mc_rst_n,
  output logic                      mc_init_done,
  output logic                      mc_fatal,
  input  wire logic                 mc_cmd_valid,
  output logic                      mc_cmd_ready,
  input  wire logic                 mc_cmd_write,
  input  wire logic [LA_W-1:0]      mc_cmd_addr,
  input  wire logic [7:0]           mc_cmd_len,
  input  wire logic [TAG_W-1:0]     mc_cmd_tag,
  input  wire logic                 mc_wd_valid,
  output logic                      mc_wd_ready,
  input  wire logic [DATA_W-1:0]    mc_wd_data,
  input  wire logic [BSTRB_W-1:0]   mc_wd_strb,
  input  wire logic                 mc_wd_last,
  output logic                      mc_rd_valid,
  input  wire logic                 mc_rd_ready,
  output logic [DATA_W-1:0]         mc_rd_data,
  output logic [TAG_W-1:0]          mc_rd_tag,
  output logic                      mc_rd_last,
  output logic                      mc_rd_error,
  output logic                      mc_wr_valid,
  input  wire logic                 mc_wr_ready,
  output logic [TAG_W-1:0]          mc_wr_tag,
  output logic                      mc_wr_error,
  // ---- SFMC-X sideband
  output logic                      mc_busy,
  output logic                      mc_rd_ce,
  output logic                      mc_rd_ue,
  output logic                      mc_rd_dbus,
  output logic                      mc_ev_hit,
  output logic                      mc_ev_miss,
  output logic                      mc_ev_conf,
  // ---- fault injection (lane-local byte address ranges, inclusive; hi < lo disables)
  input  wire logic [LA_W-1:0]      inj_be_lo,
  input  wire logic [LA_W-1:0]      inj_be_hi,
  input  wire logic [LA_W-1:0]      inj_ce_lo,
  input  wire logic [LA_W-1:0]      inj_ce_hi,
  input  wire logic [LA_W-1:0]      inj_ue_lo,
  input  wire logic [LA_W-1:0]      inj_ue_hi,
  input  wire logic [LA_W-1:0]      inj_db_lo,
  input  wire logic [LA_W-1:0]      inj_db_hi,
  input  wire logic                 inj_hang,
  input  wire logic                 inj_cal_drop,
  input  wire logic                 inj_fatal,
  // ---- backdoor (testbench): one access granule of the lane-local memory, combinational
  input  wire logic [LA_W-1:0]      bd_addr,
  output logic [LINE_W-1:0]         bd_line,
  input  wire logic                 bd_init            // pulse: restore the initial memory pattern
);

  // ------------------------------------------------------------------ storage
  reg [7:0] mem [0:MEM_BYTES-1];
  integer   mi;
  initial begin
    for (mi = 0; mi < MEM_BYTES; mi = mi + 1) mem[mi] = `SF_HBM_MODEL_PATTERN(mi, LANE_ID);
  end
  integer mj;
  always @(posedge bd_init) begin
    for (mj = 0; mj < MEM_BYTES; mj = mj + 1) mem[mj] = `SF_HBM_MODEL_PATTERN(mj, LANE_ID);
  end

  // backdoor read of one access granule (bd_addr is rounded down to the granule)
  always @* begin
    for (int bj = 0; bj < BURST_LEN * BSTRB_W; bj++) bd_line[bj*8 +: 8] = mem[{bd_addr[LA_W-1:OFF_W], {OFF_W{1'b0}}} + bj];
  end

  // ------------------------------------------------------------------ state
  integer now;
  reg [31:0] rng;

  // banks
  reg                 b_open   [0:NB-1];
  reg [ROW_W-1:0]     b_row    [0:NB-1];
  integer             b_t_col  [0:NB-1];   // earliest column command (ACT + tRCD)
  integer             b_t_pre  [0:NB-1];   // earliest PRE
  integer             b_t_act  [0:NB-1];   // earliest ACT (PRE + tRP)
  // global command history
  integer last_act_t, last_act_bank;
  integer faw_t [0:3];
  integer last_col_t, last_col_bank;
  reg     last_col_wr, last_col_v;
  integer dbus_free;
  // refresh
  integer ref_next, ref_until;
  reg     ref_pend;
  // command window (index 0 = oldest)
  reg                 cq_wr    [0:CMDQ-1];
  reg [TAG_W-1:0]     cq_tag   [0:CMDQ-1];
  reg [LA_W-1:0]      cq_la    [0:CMDQ-1];
  reg                 cq_pre   [0:CMDQ-1];
  reg                 cq_act   [0:CMDQ-1];
  integer             cq_cnt;
  // write-data FIFO (beats)
  reg [DATA_W-1:0]    wd_d     [0:WDQ-1];
  reg [BSTRB_W-1:0]   wd_s     [0:WDQ-1];
  integer             wd_cnt;
  // pending read responses
  reg                 rp_v     [0:RPQ-1];
  reg [TAG_W-1:0]     rp_tag   [0:RPQ-1];
  integer             rp_t     [0:RPQ-1];
  integer             rp_left  [0:RPQ-1];
  integer             rp_ix    [0:RPQ-1];
  integer             rp_seq   [0:RPQ-1];
  reg [LINE_W-1:0]    rp_line  [0:RPQ-1];
  reg                 rp_err   [0:RPQ-1];
  reg                 rp_ce    [0:RPQ-1];
  reg                 rp_ue    [0:RPQ-1];
  reg                 rp_db    [0:RPQ-1];
  integer             rp_cur;
  integer             rp_seq_n;
  // pending write responses
  reg                 wp_v     [0:RPQ-1];
  reg [TAG_W-1:0]     wp_tag   [0:RPQ-1];
  integer             wp_t     [0:RPQ-1];
  integer             wp_seq   [0:RPQ-1];
  reg                 wp_err   [0:RPQ-1];
  // calibration
  integer cal_cnt;
  // contract / statistics counters visible to the testbench
  integer violations;
  integer n_act, n_pre, n_rd, n_wr, n_ref, n_hit, n_miss, n_conf;
  integer n_cmd_stall_full;
  integer busy_cycles;

  // command log
  integer logf;
  reg     log_en;
  reg [1023:0] logname;
  reg [1023:0] logfile;
  initial begin
    log_en = 1'b0;
    if ($value$plusargs("CMDLOG=%s", logname)) begin
      $sformat(logfile, "%0s.lane%0d", logname, LANE_ID);
      logf = $fopen(logfile, "w");
      log_en = (logf != 0);
      if (log_en) begin
        $fdisplay(logf, "# P115 model command log: lane=%0d BL=%0d tCL=%0d tCWL=%0d", LANE_ID, BURST_LEN, T_CL, T_CWL);
      end
    end
  end

  // ------------------------------------------------------------------ helpers
  function integer bank_of(input [LA_W-1:0] la);
    bank_of = la[OFF_W+COL_W +: BK_W];
  endfunction
  function integer row_of(input [LA_W-1:0] la);
    row_of = la[LA_W-1 -: ROW_W];
  endfunction
  function integer col_of(input [LA_W-1:0] la);
    col_of = la[OFF_W +: COL_W];
  endfunction
  function integer bg_of(input integer b);
    bg_of = b >> BANK_W;
  endfunction
  function in_rng(input [LA_W-1:0] a, input [LA_W-1:0] lo, input [LA_W-1:0] hi);
    in_rng = (lo <= hi) && (a >= lo) && (a <= hi);
  endfunction
  function integer imax(input integer a, input integer b);
    imax = (a > b) ? a : b;
  endfunction

  task rnd_next;
    begin
      rng = rng ^ (rng << 13);
      rng = rng ^ (rng >> 17);
      rng = rng ^ (rng << 5);
    end
  endtask

  // op: 0 ACT, 1 PRE, 2 RD, 3 WR, 4 REF
  task log_cmd(input integer op, input integer bank, input integer row, input integer col);
    begin
      if (log_en) begin
        case (op)
          0: $fdisplay(logf, "%0d ACT %0d %0d %0d", now, bank, row, col);
          1: $fdisplay(logf, "%0d PRE %0d %0d %0d", now, bank, row, col);
          2: $fdisplay(logf, "%0d RD %0d %0d %0d",  now, bank, row, col);
          3: $fdisplay(logf, "%0d WR %0d %0d %0d",  now, bank, row, col);
          default: $fdisplay(logf, "%0d REF %0d %0d %0d", now, bank, row, col);
        endcase
      end
    end
  endtask

  // earliest cycle at which entry k may issue its column command (ignores row state)
  function integer col_time(input integer k);
    integer t, b;
    reg same;
    begin
      b = bank_of(cq_la[k]);
      t = b_t_col[b];
      if (last_col_v) begin
        same = (bg_of(b) == bg_of(last_col_bank));
        if (!cq_wr[k] && !last_col_wr)      t = imax(t, last_col_t + (same ? T_CCD_L : T_CCD_S));
        else if (cq_wr[k] && last_col_wr)   t = imax(t, last_col_t + (same ? T_CCD_L : T_CCD_S));
        else if (cq_wr[k] && !last_col_wr)  t = imax(t, last_col_t + T_RTW);
        else                                t = imax(t, last_col_t + T_CWL + BURST_LEN + (same ? T_WTR_L : T_WTR_S));
      end
      col_time = t;
    end
  endfunction

  function integer faw_ok_time(input integer dummy);
    // oldest of the last four ACTs + tFAW
    integer t, i;
    begin
      t = faw_t[0];
      for (i = 1; i < 4; i = i + 1) if (faw_t[i] < t) t = faw_t[i];
      faw_ok_time = t + T_FAW;
    end
  endfunction

  function integer act_time(input integer b);
    integer t;
    begin
      t = b_t_act[b];
      if (last_act_t >= 0) t = imax(t, last_act_t + ((bg_of(b) == bg_of(last_act_bank)) ? T_RRD_L : T_RRD_S));
      t = imax(t, faw_ok_time(0));
      act_time = t;
    end
  endfunction

  // ------------------------------------------------------------------ scratch (step task)
  integer k, j, b, r, sel, ci, dwait, start, wi, bi, bb, nb_, oldest_w;
  reg     issued_cmd, col_done, hit_c, any_open, all_idle_ok;
  reg     v_err, v_ce, v_ue, v_db;
  reg [LA_W-1:0] a_;
  reg [LINE_W-1:0] line_;
  reg [7:0] byt_;
  reg     ok_order;
  integer cand, best_t, best_s, nready, pickn, ti;
  reg     rd_slot_free, wr_slot_free;

  // outputs staged here, driven with NBAs at the end of the cycle
  reg                 o_rd_valid, o_rd_last, o_rd_err, o_rd_ce, o_rd_ue, o_rd_db;
  reg [DATA_W-1:0]    o_rd_data;
  reg [TAG_W-1:0]     o_rd_tag;
  reg                 o_wr_valid, o_wr_err;
  reg [TAG_W-1:0]     o_wr_tag;
  reg                 o_ev_hit, o_ev_miss, o_ev_conf;
  reg                 o_cmd_ready, o_wd_ready;

  // ------------------------------------------------------------------ reset of the DRAM-side state
  task reset_state;
    integer i;
    begin
      cq_cnt = 0; wd_cnt = 0; rp_cur = -1; rp_seq_n = 0;
      for (i = 0; i < NB; i = i + 1) begin
        b_open[i] = 1'b0; b_row[i] = '0; b_t_col[i] = 0; b_t_pre[i] = 0; b_t_act[i] = 0;
      end
      for (i = 0; i < 4; i = i + 1) faw_t[i] = -100000;
      last_act_t = -100000; last_act_bank = 0; last_col_t = -100000; last_col_bank = 0; last_col_wr = 1'b0; last_col_v = 1'b0;
      dbus_free = 0; ref_pend = 1'b0; ref_until = 0; ref_next = now + T_REFI;
      for (i = 0; i < RPQ; i = i + 1) begin rp_v[i] = 1'b0; wp_v[i] = 1'b0; end
      cal_cnt = 0;
    end
  endtask

  initial begin
    rng = SEED * 32'h9E3779B1 + LANE_ID * 32'h85EBCA6B + 32'd1;
    now = 0;
    violations = 0; n_act = 0; n_pre = 0; n_rd = 0; n_wr = 0; n_ref = 0; n_hit = 0; n_miss = 0; n_conf = 0;
    n_cmd_stall_full = 0; busy_cycles = 0;
    reset_state;
  end

  // ------------------------------------------------------------------ main clocked process
  always @(posedge clk) begin
    now = now + 1;
    o_ev_hit = 1'b0; o_ev_miss = 1'b0; o_ev_conf = 1'b0;
    o_wr_valid = 1'b0; o_wr_err = 1'b0; o_wr_tag = '0;

    if (!rst_n || !mc_rst_n) begin
      reset_state;
      o_rd_valid = 1'b0; o_rd_last = 1'b0; o_rd_err = 1'b0; o_rd_ce = 1'b0; o_rd_ue = 1'b0; o_rd_db = 1'b0;
      o_rd_data = '0; o_rd_tag = '0; o_cmd_ready = 1'b0; o_wd_ready = 1'b0;
      mc_init_done <= 1'b0;
    end else begin
      // ---------------- calibration
      if (cal_cnt < CAL_CYCLES) cal_cnt = cal_cnt + 1;
      mc_init_done <= (cal_cnt >= CAL_CYCLES) && !inj_cal_drop;

      // A handshake is a handshake: ready was driven high in the previous cycle, so a command / write beat presented now IS accepted,
      // frozen or not (dropping it would lose a transaction).
        // ---------------- accept a command (handshake: valid seen now AND ready driven last cycle)
        if (mc_cmd_valid && mc_cmd_ready) begin
          if (cq_cnt >= CMDQ) violations = violations + 1;
          else begin
            if (mc_cmd_len != BURST_LEN - 1) violations = violations + 1;
            // C4: tag must not be live
            for (ci = 0; ci < cq_cnt; ci = ci + 1) if (cq_tag[ci] == mc_cmd_tag) violations = violations + 1;
            for (ci = 0; ci < RPQ; ci = ci + 1) begin
              if (rp_v[ci] && rp_tag[ci] == mc_cmd_tag) violations = violations + 1;
              if (wp_v[ci] && wp_tag[ci] == mc_cmd_tag) violations = violations + 1;
            end
            cq_wr[cq_cnt] = mc_cmd_write; cq_tag[cq_cnt] = mc_cmd_tag; cq_la[cq_cnt] = mc_cmd_addr;
            cq_pre[cq_cnt] = 1'b0; cq_act[cq_cnt] = 1'b0;
            cq_cnt = cq_cnt + 1;
          end
        end
        // ---------------- accept write data beats
        if (mc_wd_valid && mc_wd_ready) begin
          if (wd_cnt >= WDQ) violations = violations + 1;
          else begin
            wd_d[wd_cnt] = mc_wd_data; wd_s[wd_cnt] = mc_wd_strb; wd_cnt = wd_cnt + 1;
          end
        end

      if (inj_hang || cal_cnt < CAL_CYCLES) begin
        // frozen: nothing new is accepted or produced; a beat already presented may still be taken
        o_cmd_ready = 1'b0; o_wd_ready = 1'b0;
        if (mc_wr_valid && !mc_wr_ready) begin
          o_wr_valid = mc_wr_valid; o_wr_tag = mc_wr_tag; o_wr_err = mc_wr_error;
        end
        if (mc_rd_valid && !mc_rd_ready) begin
          o_rd_valid = mc_rd_valid; o_rd_data = mc_rd_data; o_rd_tag = mc_rd_tag; o_rd_last = mc_rd_last;
          o_rd_err = mc_rd_error; o_rd_ce = mc_rd_ce; o_rd_ue = mc_rd_ue; o_rd_db = mc_rd_dbus;
        end else begin
          o_rd_valid = 1'b0; o_rd_last = 1'b0; o_rd_err = 1'b0; o_rd_ce = 1'b0; o_rd_ue = 1'b0; o_rd_db = 1'b0;
          o_rd_data = '0; o_rd_tag = '0;
        end
      end else begin
        // ---------------- refresh state machine + command issue (one command slot per cycle)
        issued_cmd = 1'b0;
        if (REFRESH_EN != 0 && !ref_pend && now >= ref_next && now >= ref_until) ref_pend = 1'b1;

        if (now < ref_until) begin
          issued_cmd = 1'b1;                       // tRFC: command bus idle
        end else if (ref_pend) begin
          // close every open bank (one PRE per cycle), then refresh
          for (b = 0; b < NB && !issued_cmd; b = b + 1) begin
            if (b_open[b] && now >= b_t_pre[b]) begin
              b_open[b] = 1'b0; b_t_act[b] = now + T_RP; n_pre = n_pre + 1; issued_cmd = 1'b1;
              log_cmd(1, b, 0, 0);
            end
          end
          if (!issued_cmd) begin
            any_open = 1'b0; all_idle_ok = 1'b1;
            for (b = 0; b < NB; b = b + 1) begin
              if (b_open[b]) any_open = 1'b1;
              if (now < b_t_act[b]) all_idle_ok = 1'b0;
            end
            if (!any_open && all_idle_ok) begin
              ref_until = now + T_RFC; ref_next = ref_next + T_REFI; ref_pend = 1'b0; n_ref = n_ref + 1; issued_cmd = 1'b1;
              log_cmd(4, 0, 0, 0);
              for (b = 0; b < NB; b = b + 1) b_t_act[b] = imax(b_t_act[b], now + T_RFC);
            end
          end
        end else begin
          // ---- 1. column command
          col_done = 1'b0;
          sel = -1;
          if (cq_cnt > 0) begin
            if (ORDER_VIOLATE == 0) begin
              ok_order = 1'b1;
              if (b_open[bank_of(cq_la[0])] && b_row[bank_of(cq_la[0])] == row_of(cq_la[0]) &&
                  now >= col_time(0) && (!cq_wr[0] || wd_cnt >= BURST_LEN) &&
                  (now + (cq_wr[0] ? T_CWL : T_CL)) >= dbus_free) sel = 0;
            end else begin
              // adversarial: any entry within the lookahead window; writes keep data order (oldest write only)
              oldest_w = -1;
              for (k = 0; k < cq_cnt; k = k + 1) if (oldest_w < 0 && cq_wr[k]) oldest_w = k;
              pickn = 0;
              for (k = 0; k < cq_cnt && k < LOOKAHEAD; k = k + 1) begin
                if (b_open[bank_of(cq_la[k])] && b_row[bank_of(cq_la[k])] == row_of(cq_la[k]) &&
                    now >= col_time(k) && (!cq_wr[k] || (k == oldest_w && wd_cnt >= BURST_LEN)) &&
                    (now + (cq_wr[k] ? T_CWL : T_CL)) >= dbus_free) begin
                  pickn = pickn + 1;
                  rnd_next;
                  if (sel < 0 || (rng[7:0] < 8'd96)) sel = k;
                end
              end
            end
          end
          if (sel >= 0) begin
            issued_cmd = 1'b1;
            a_  = cq_la[sel];
            bi  = bank_of(a_);
            hit_c = !(cq_pre[sel] || cq_act[sel]);
            if (cq_pre[sel])      begin o_ev_conf = 1'b1; n_conf = n_conf + 1; end
            else if (cq_act[sel]) begin o_ev_miss = 1'b1; n_miss = n_miss + 1; end
            else                  begin o_ev_hit  = 1'b1; n_hit  = n_hit  + 1; end
            v_err = in_rng(a_, inj_be_lo, inj_be_hi);
            v_ce  = in_rng(a_, inj_ce_lo, inj_ce_hi);
            v_ue  = in_rng(a_, inj_ue_lo, inj_ue_hi);
            v_db  = in_rng(a_, inj_db_lo, inj_db_hi);
            rnd_next;
            dwait = (RSP_JITTER > 0) ? (rng[15:0] % (RSP_JITTER + 1)) : 0;
            last_col_v = 1'b1; last_col_t = now; last_col_bank = bi; last_col_wr = cq_wr[sel];
            if (!cq_wr[sel]) begin
              // ---- read
              n_rd = n_rd + 1;
              start = now + T_CL;
              dbus_free = start + BURST_LEN;
              b_t_pre[bi] = imax(b_t_pre[bi], now + T_RTP);
              log_cmd(2, bi, row_of(a_), col_of(a_));
              line_ = '0;
              for (j = 0; j < BURST_LEN * BSTRB_W; j = j + 1) line_[j*8 +: 8] = mem[a_ + j];
              for (ti = 0; ti < RPQ && !col_done; ti = ti + 1) begin
                if (!rp_v[ti]) begin
                  col_done = 1'b1;
                  rp_v[ti] = 1'b1; rp_tag[ti] = cq_tag[sel]; rp_t[ti] = start + dwait; rp_left[ti] = BURST_LEN; rp_ix[ti] = 0;
                  rp_seq[ti] = rp_seq_n; rp_seq_n = rp_seq_n + 1; rp_line[ti] = line_;
                  rp_err[ti] = v_err; rp_ce[ti] = v_ce; rp_ue[ti] = v_ue; rp_db[ti] = v_db;
                end
              end
              if (!col_done) violations = violations + 1;
            end else begin
              // ---- write: consume BURST_LEN beats, apply with byte enables (unless poisoned)
              n_wr = n_wr + 1;
              start = now + T_CWL;
              dbus_free = start + BURST_LEN;
              b_t_pre[bi] = imax(b_t_pre[bi], now + T_CWL + BURST_LEN + T_WR);
              log_cmd(3, bi, row_of(a_), col_of(a_));
              if (!v_err) begin
                for (j = 0; j < BURST_LEN; j = j + 1)
                  for (wi = 0; wi < BSTRB_W; wi = wi + 1)
                    if (wd_s[j][wi]) mem[a_ + j*BSTRB_W + wi] = wd_d[j][wi*8 +: 8];
              end
              for (j = 0; j + BURST_LEN < WDQ; j = j + 1) begin wd_d[j] = wd_d[j+BURST_LEN]; wd_s[j] = wd_s[j+BURST_LEN]; end
              wd_cnt = wd_cnt - BURST_LEN;
              for (ti = 0; ti < RPQ && !col_done; ti = ti + 1) begin
                if (!wp_v[ti]) begin
                  col_done = 1'b1;
                  wp_v[ti] = 1'b1; wp_tag[ti] = cq_tag[sel]; wp_t[ti] = start + BURST_LEN + dwait;
                  wp_seq[ti] = rp_seq_n; rp_seq_n = rp_seq_n + 1; wp_err[ti] = v_err;
                end
              end
              if (!col_done) violations = violations + 1;
            end
            // remove entry `sel` from the window
            for (j = sel; j + 1 < CMDQ; j = j + 1) begin
              cq_wr[j] = cq_wr[j+1]; cq_tag[j] = cq_tag[j+1]; cq_la[j] = cq_la[j+1]; cq_pre[j] = cq_pre[j+1]; cq_act[j] = cq_act[j+1];
            end
            cq_cnt = cq_cnt - 1;
          end

          // ---- 2. row preparation (PRE / ACT) for the next commands, if the slot is still free
          if (!issued_cmd) begin
            for (k = 0; k < cq_cnt && k < LOOKAHEAD && !issued_cmd; k = k + 1) begin
              bi = bank_of(cq_la[k]);
              ok_order = 1'b1;
              for (j = 0; j < k; j = j + 1) if (bank_of(cq_la[j]) == bi) ok_order = 1'b0;   // an older command owns the bank
              if (ok_order) begin
                if (b_open[bi] && b_row[bi] != row_of(cq_la[k])) begin
                  if (now >= b_t_pre[bi]) begin
                    b_open[bi] = 1'b0; b_t_act[bi] = now + T_RP; cq_pre[k] = 1'b1; n_pre = n_pre + 1; issued_cmd = 1'b1;
                    log_cmd(1, bi, 0, 0);
                  end
                end else if (!b_open[bi]) begin
                  if (now >= act_time(bi)) begin
                    b_open[bi] = 1'b1; b_row[bi] = row_of(cq_la[k]);
                    b_t_col[bi] = now + T_RCD; b_t_pre[bi] = now + T_RAS;
                    cq_act[k] = 1'b1; n_act = n_act + 1; issued_cmd = 1'b1;
                    last_act_t = now; last_act_bank = bi;
                    for (j = 0; j < 3; j = j + 1) faw_t[j] = faw_t[j+1];
                    faw_t[3] = now;
                    log_cmd(0, bi, row_of(cq_la[k]), 0);
                  end
                end
              end
            end
          end
        end

        // ---------------- response output: read beats
        o_rd_valid = 1'b0; o_rd_last = 1'b0; o_rd_err = 1'b0; o_rd_ce = 1'b0; o_rd_ue = 1'b0; o_rd_db = 1'b0;
        o_rd_data = '0; o_rd_tag = '0;
        rd_slot_free = !mc_rd_valid || mc_rd_ready;
        if (!rd_slot_free) begin
          // beat not taken: hold it unchanged
          o_rd_valid = mc_rd_valid; o_rd_data = mc_rd_data; o_rd_tag = mc_rd_tag; o_rd_last = mc_rd_last;
          o_rd_err = mc_rd_error; o_rd_ce = mc_rd_ce; o_rd_ue = mc_rd_ue; o_rd_db = mc_rd_dbus;
        end else begin
          cand = -1;
          if (INTERLEAVE == 0 && rp_cur >= 0 && rp_v[rp_cur]) cand = rp_cur;
          else begin
            nready = 0; best_s = 0;
            for (ti = 0; ti < RPQ; ti = ti + 1) begin
              if (rp_v[ti] && rp_t[ti] <= now) begin
                nready = nready + 1;
                if (INTERLEAVE == 0) begin
                  if (cand < 0 || rp_t[ti] < best_t || (rp_t[ti] == best_t && rp_seq[ti] < best_s)) begin
                    cand = ti; best_t = rp_t[ti]; best_s = rp_seq[ti];
                  end
                end else begin
                  rnd_next;
                  if (cand < 0 || rng[3:0] < 4'd6) cand = ti;
                end
              end
            end
          end
          if (cand >= 0) begin
            o_rd_valid = 1'b1;
            o_rd_tag   = rp_tag[cand];
            o_rd_data  = rp_line[cand][rp_ix[cand]*DATA_W +: DATA_W];
            o_rd_err   = rp_err[cand];
            o_rd_ce    = rp_ce[cand];
            o_rd_ue    = rp_ue[cand];
            o_rd_db    = rp_db[cand];
            rp_ix[cand]   = rp_ix[cand] + 1;
            rp_left[cand] = rp_left[cand] - 1;
            o_rd_last  = (rp_left[cand] == 0);
            if (rp_left[cand] == 0) begin rp_v[cand] = 1'b0; rp_cur = -1; end
            else                    begin rp_cur = (INTERLEAVE == 0) ? cand : -1; end
          end
        end

        // ---------------- response output: write responses (one per cycle, earliest first)
        if (!mc_wr_valid || mc_wr_ready) begin
          cand = -1; best_t = 0; best_s = 0;
          for (ti = 0; ti < RPQ; ti = ti + 1) begin
            if (wp_v[ti] && wp_t[ti] <= now) begin
              if (cand < 0 || wp_t[ti] < best_t || (wp_t[ti] == best_t && wp_seq[ti] < best_s)) begin
                cand = ti; best_t = wp_t[ti]; best_s = wp_seq[ti];
              end
            end
          end
          if (cand >= 0) begin
            o_wr_valid = 1'b1; o_wr_tag = wp_tag[cand]; o_wr_err = wp_err[cand]; wp_v[cand] = 1'b0;
          end
        end else begin
          o_wr_valid = mc_wr_valid; o_wr_tag = mc_wr_tag; o_wr_err = mc_wr_error;
        end

        // ---------------- ready for the next cycle
        rnd_next;
        o_cmd_ready = (cq_cnt < CMDQ) && ((ACCEPT_PCT >= 100) || ((rng[15:8] % 100) < ACCEPT_PCT));
        o_wd_ready  = (wd_cnt + 1 <= WDQ - 1);
        if (cq_cnt >= CMDQ) n_cmd_stall_full = n_cmd_stall_full + 1;
      end
    end

    if (ref_pend || now < ref_until) busy_cycles = busy_cycles + 1;

    // drive the interface (NBA so the scheduler samples pre-edge values at the next edge)
    mc_rd_valid  <= o_rd_valid;
    mc_rd_data   <= o_rd_data;
    mc_rd_tag    <= o_rd_tag;
    mc_rd_last   <= o_rd_last;
    mc_rd_error  <= o_rd_err;
    mc_rd_ce     <= o_rd_ce;
    mc_rd_ue     <= o_rd_ue;
    mc_rd_dbus   <= o_rd_db;
    mc_wr_valid  <= o_wr_valid;
    mc_wr_tag    <= o_wr_tag;
    mc_wr_error  <= o_wr_err;
    mc_ev_hit    <= o_ev_hit;
    mc_ev_miss   <= o_ev_miss;
    mc_ev_conf   <= o_ev_conf;
    mc_cmd_ready <= o_cmd_ready;
    mc_wd_ready  <= o_wd_ready;
    mc_busy      <= ref_pend || (now < ref_until);
    mc_fatal     <= inj_fatal;
  end

  initial begin
    mc_init_done = 1'b0; mc_fatal = 1'b0; mc_cmd_ready = 1'b0; mc_wd_ready = 1'b0;
    mc_rd_valid = 1'b0; mc_rd_data = '0; mc_rd_tag = '0; mc_rd_last = 1'b0; mc_rd_error = 1'b0;
    mc_rd_ce = 1'b0; mc_rd_ue = 1'b0; mc_rd_dbus = 1'b0;
    mc_wr_valid = 1'b0; mc_wr_tag = '0; mc_wr_error = 1'b0; mc_busy = 1'b0;
    mc_ev_hit = 1'b0; mc_ev_miss = 1'b0; mc_ev_conf = 1'b0;
  end

endmodule
`default_nettype wire
