// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_model_defs.svh   (simulation only)
// Shared by the behavioural memory model and the testbenches.
//
// Timing tables below are HYPOTHETICAL controller-clock cycle counts, one table
// per technology profile.  They were chosen to have the right ORDER OF
// MAGNITUDE for an HBM2-class device at roughly 1 cycle = 1 ns (tRCD/tRP of
// ~14, tRAS ~33, tFAW 16, tREFI 3.9 us, tRFC 260).  They are NOT taken from a
// JEDEC document or a vendor datasheet (none was available in this project) and
// must not be used for any physical claim.  The HBM3-style profile reuses the
// same placeholders.
// =============================================================================
`ifndef SF_HBM_MODEL_DEFS_SVH
`define SF_HBM_MODEL_DEFS_SVH

// deterministic initial memory content: a function of the lane-local byte address and the lane id
`define SF_HBM_MODEL_PATTERN(a, lane) ((((a) & 255) ^ (((a) >> 8) * 3) ^ (((a) >> 16) * 7) ^ ((lane) * 29 + 5)) & 255)

// per-profile timing placeholders: macro(profile) -> cycles
`define SF_HBM_T_RCD(p)   14
`define SF_HBM_T_RP(p)    14
`define SF_HBM_T_RAS(p)   33
`define SF_HBM_T_CL(p)    14
`define SF_HBM_T_CWL(p)   7
`define SF_HBM_T_WR(p)    15
`define SF_HBM_T_RTP(p)   5
`define SF_HBM_T_RRD_S(p) 4
`define SF_HBM_T_RRD_L(p) 6
`define SF_HBM_T_FAW(p)   16
`define SF_HBM_T_WTR_S(p) 4
`define SF_HBM_T_WTR_L(p) 8
`define SF_HBM_T_REFI(p)  3900
`define SF_HBM_T_RFC(p)   260

`endif
