// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_tb      (self-checking system bench)
//
// DUT  : sf_hbm_sched_top   (NUM_LANES lanes)
// Back : NUM_LANES x sf_hbm_mem_model  (timing-aware behavioural SFMC slaves)
//
// Independent checking (nothing here uses a DUT-internal signal):
//   * an independent BYTE-ADDRESSABLE reference memory indexed by the GLOBAL
//     address.  A request is applied to it at the cycle it is ACCEPTED (the
//     ordering point).  A read's expected data is the snapshot at that moment, so
//     RAW / WAR / WAW hazards are checked exactly, whatever the scheduler does.
//   * an independent address mapper written with integer arithmetic
//     (div / mod), not with the RTL's bit slices; it is used for the expected lane,
//     the expected lane-local address, the poison ranges and the final image.
//   * per-source scoreboards: exactly one response per request, id / direction /
//     status / data, and the ordering contract (ORDER_MODE 0: strict per source,
//     1: same id in order).
//   * SFMC protocol checkers on every lane (sf_hbm_sfmc_check) and the model's
//     own contract counters.
//   * a final-image comparison (every touched granule + a sample of untouched
//     ones) between the reference and the models' memories.
//   * the RTL performance counters are compared with the bench's own counts.
//
// Select the scenario with +TEST=<name> (see the list at the bottom); +SEED=<n>,
// +POLICY=<0..3>, +N=<requests per source> modify it.  Output: lines starting
// with "RESULT:" (PASS / FAIL) and, for benchmark scenarios, "BENCH_JSON".
// =============================================================================
`include "sf_hbm_defs.svh"
`include "sf_hbm_model_defs.svh"

module sf_hbm_tb #(
  parameter int NUM_SRC       = 5,
  parameter int NUM_CH        = 2,
  parameter int NUM_PC        = 1,
  parameter int PROFILE       = 0,
  parameter int ADDR_W        = 32,
  parameter int DATA_W        = 128,
  parameter int BURST_LEN     = 2,
  parameter int BG_W          = 2,
  parameter int BANK_W        = 2,
  parameter int ROW_W         = 6,
  parameter int COL_W         = 5,
  parameter int MAP_MODE      = 0,
  parameter int ID_W          = 4,
  parameter int RQ_DEPTH      = 16,
  parameter int WQ_DEPTH      = 16,
  parameter int OUT_PER_SRC   = 8,
  parameter int LANE_OUT      = 8,
  parameter int WD_DEPTH      = 4,
  parameter int CMD_DEPTH     = 2,
  parameter int AGE_W         = 12,
  parameter int BUSY_W        = 6,
  parameter int BYP_W         = 6,
  parameter int NUM_WIN       = 4,
  parameter int ORDER_MODE    = 0,
  parameter int BE_ORDER_SAFE = 1,
  parameter int RST_HOLD      = 8,
  parameter int CAL_TIMEOUT   = 0,
  parameter int SHADOW_CLR_BUSY = 1,
  // ---- memory model
  parameter int CMDQ          = 8,
  parameter int LOOKAHEAD     = 4,
  parameter int REFRESH_EN    = 1,
  parameter int T_REFI        = 3900,
  parameter int T_RFC         = 260,
  parameter int RSP_JITTER    = 0,
  parameter int INTERLEAVE    = 0,
  parameter int ORDER_VIOLATE = 0,
  parameter int CAL_CYCLES    = 20,
  parameter int ACCEPT_PCT    = 100,
  parameter int HIST_MAX      = 8192,
  localparam int BURST_BYTES = DATA_W * BURST_LEN / 8,
  localparam int OFF_W       = $clog2(BURST_BYTES),
  localparam int NUM_LANES   = NUM_CH * NUM_PC,
  localparam int LA_W        = OFF_W + COL_W + BG_W + BANK_W + ROW_W,
  localparam int LINE_W      = DATA_W * BURST_LEN,
  localparam int STRB_W      = BURST_BYTES,
  localparam int BSTRB_W     = DATA_W / 8,
  localparam int SLOT_W      = $clog2(OUT_PER_SRC),
  localparam int SRC_W       = (NUM_SRC > 1) ? $clog2(NUM_SRC) : 1,
  localparam int TAG_W       = SRC_W + SLOT_W,
  localparam int LIM_W       = SLOT_W + 1,
  localparam int WCNT_W      = $clog2(WQ_DEPTH + 1),
  localparam int NCOL        = (1 << COL_W),
  localparam int NBG         = (1 << BG_W),
  localparam int NBANK       = (1 << BANK_W),
  localparam int NROW        = (1 << ROW_W),
  localparam int CAP_GRAN    = NUM_LANES * NCOL * NBG * NBANK * NROW,
  localparam int CAP_BYTES   = CAP_GRAN * BURST_BYTES,
  localparam int REC         = 128
) ();

  // ------------------------------------------------------------------ clock / reset
  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n;

  // ------------------------------------------------------------------ DUT wiring
  logic [2:0]                    cfg_policy;
  logic [WCNT_W-1:0]             cfg_wr_hi, cfg_wr_lo;
  logic [AGE_W-1:0]              cfg_age_limit;
  logic                          cfg_idle_wr;
  logic [BUSY_W-1:0]             cfg_busy_cyc;
  logic [BYP_W-1:0]              cfg_bypass_cap;
  logic                          cfg_arb_mode;
  logic [NUM_SRC*2-1:0]          cfg_arb_prio;
  logic [7:0]                    cfg_arb_age;
  logic [31:0]                   cfg_timeout;
  logic [NUM_SRC*LIM_W-1:0]      cfg_out_limit;
  logic                          cfg_perm_en;
  logic [NUM_WIN*ADDR_W-1:0]     cfg_win_base, cfg_win_last;
  logic [NUM_WIN*NUM_SRC*2-1:0]  cfg_win_perm;
  logic                          cfg_link_retry;

  logic [NUM_SRC-1:0]            s_req_valid, s_req_ready, s_req_we;
  logic [NUM_SRC*ID_W-1:0]       s_req_id;
  logic [NUM_SRC*ADDR_W-1:0]     s_req_addr;
  logic [NUM_SRC*LINE_W-1:0]     s_req_wdata;
  logic [NUM_SRC*STRB_W-1:0]     s_req_wstrb;
  logic [NUM_SRC-1:0]            s_rsp_valid, s_rsp_ready, s_rsp_we;
  logic [NUM_SRC*ID_W-1:0]       s_rsp_id;
  logic [NUM_SRC*LINE_W-1:0]     s_rsp_data;
  logic [NUM_SRC*4-1:0]          s_rsp_status;

  logic [NUM_LANES-1:0]          mc_rst_n, mc_init_done, mc_fatal, mc_cmd_valid, mc_cmd_ready, mc_cmd_write;
  logic [NUM_LANES*LA_W-1:0]     mc_cmd_addr;
  logic [NUM_LANES*8-1:0]        mc_cmd_len;
  logic [NUM_LANES*TAG_W-1:0]    mc_cmd_tag;
  logic [NUM_LANES-1:0]          mc_wd_valid, mc_wd_ready, mc_wd_last;
  logic [NUM_LANES*DATA_W-1:0]   mc_wd_data;
  logic [NUM_LANES*BSTRB_W-1:0]  mc_wd_strb;
  logic [NUM_LANES-1:0]          mc_rd_valid, mc_rd_ready, mc_rd_last, mc_rd_error;
  logic [NUM_LANES*DATA_W-1:0]   mc_rd_data;
  logic [NUM_LANES*TAG_W-1:0]    mc_rd_tag;
  logic [NUM_LANES-1:0]          mc_wr_valid, mc_wr_ready, mc_wr_error;
  logic [NUM_LANES*TAG_W-1:0]    mc_wr_tag;
  logic [NUM_LANES-1:0]          mc_busy, mc_rd_ce, mc_rd_ue, mc_rd_dbus, mc_ev_hit, mc_ev_miss, mc_ev_conf;

  logic                          perf_clr;
  logic [15:0]                   perf_sel;
  logic [63:0]                   perf_data;
  logic                          idle_o, err_spurious_o, err_timeout_o;
  logic [NUM_LANES*3-1:0]        link_state_o;

  // fault injection (flat, one slice per lane)
  logic [NUM_LANES*LA_W-1:0]     inj_be_lo, inj_be_hi, inj_ce_lo, inj_ce_hi, inj_ue_lo, inj_ue_hi, inj_db_lo, inj_db_hi;
  logic [NUM_LANES-1:0]          inj_hang, inj_cal_drop, inj_fatal;
  logic [NUM_LANES*LA_W-1:0]     bd_addr;
  logic [NUM_LANES*LINE_W-1:0]   bd_line;
  logic [NUM_LANES-1:0]          bd_init;

  sf_hbm_sched_top #(
    .NUM_SRC(NUM_SRC), .NUM_CH(NUM_CH), .NUM_PC(NUM_PC), .PROFILE(PROFILE), .ADDR_W(ADDR_W), .DATA_W(DATA_W),
    .BURST_LEN(BURST_LEN), .BG_W(BG_W), .BANK_W(BANK_W), .ROW_W(ROW_W), .COL_W(COL_W), .MAP_MODE(MAP_MODE),
    .ID_W(ID_W), .RQ_DEPTH(RQ_DEPTH), .WQ_DEPTH(WQ_DEPTH), .OUT_PER_SRC(OUT_PER_SRC), .LANE_OUT(LANE_OUT),
    .WD_DEPTH(WD_DEPTH), .CMD_DEPTH(CMD_DEPTH), .AGE_W(AGE_W), .BUSY_W(BUSY_W), .BYP_W(BYP_W), .NUM_WIN(NUM_WIN),
    .ORDER_MODE(ORDER_MODE), .BE_ORDER_SAFE(BE_ORDER_SAFE), .RST_HOLD(RST_HOLD), .CAL_TIMEOUT(CAL_TIMEOUT),
    .SHADOW_CLR_BUSY(SHADOW_CLR_BUSY)
  ) dut (.*);

  // ------------------------------------------------------------------ memory models + protocol checkers
  integer chk_viol [0:NUM_LANES-1];
  integer chk_resp_viol [0:NUM_LANES-1];
  integer chk_n_rd [0:NUM_LANES-1];
  integer chk_n_wr [0:NUM_LANES-1];
  integer chk_beats [0:NUM_LANES-1];
  integer mdl_viol [0:NUM_LANES-1];
  integer mdl_hit [0:NUM_LANES-1];
  integer mdl_miss [0:NUM_LANES-1];
  integer mdl_conf [0:NUM_LANES-1];
  integer mdl_ref [0:NUM_LANES-1];
  integer mdl_busy [0:NUM_LANES-1];
  integer mdl_act [0:NUM_LANES-1];
  integer mdl_pre [0:NUM_LANES-1];

  genvar gl;
  generate
    for (gl = 0; gl < NUM_LANES; gl = gl + 1) begin : g_lane
      integer c_v, c_rv, c_nr, c_nw, c_nb;
      sf_hbm_mem_model #(
        .DATA_W(DATA_W), .BURST_LEN(BURST_LEN), .TAG_W(TAG_W), .OFF_W(OFF_W), .COL_W(COL_W), .BG_W(BG_W),
        .BANK_W(BANK_W), .ROW_W(ROW_W), .CMDQ(CMDQ), .LOOKAHEAD(LOOKAHEAD),
        .T_RCD(`SF_HBM_T_RCD(PROFILE)), .T_RP(`SF_HBM_T_RP(PROFILE)), .T_RAS(`SF_HBM_T_RAS(PROFILE)),
        .T_CL(`SF_HBM_T_CL(PROFILE)), .T_CWL(`SF_HBM_T_CWL(PROFILE)), .T_WR(`SF_HBM_T_WR(PROFILE)),
        .T_RTP(`SF_HBM_T_RTP(PROFILE)), .T_CCD_S(BURST_LEN), .T_CCD_L(BURST_LEN + 2),
        .T_RRD_S(`SF_HBM_T_RRD_S(PROFILE)), .T_RRD_L(`SF_HBM_T_RRD_L(PROFILE)), .T_FAW(`SF_HBM_T_FAW(PROFILE)),
        .T_WTR_S(`SF_HBM_T_WTR_S(PROFILE)), .T_WTR_L(`SF_HBM_T_WTR_L(PROFILE)),
        .T_RTW(`SF_HBM_T_CL(PROFILE) + BURST_LEN + 2 - `SF_HBM_T_CWL(PROFILE)),
        .T_REFI(T_REFI), .T_RFC(T_RFC), .REFRESH_EN(REFRESH_EN),
        .RSP_JITTER(RSP_JITTER), .INTERLEAVE(INTERLEAVE), .ORDER_VIOLATE(ORDER_VIOLATE),
        .CAL_CYCLES(CAL_CYCLES), .ACCEPT_PCT(ACCEPT_PCT), .SEED(gl + 1), .LANE_ID(gl)
      ) u_mem (
        .clk(clk), .rst_n(rst_n), .mc_rst_n(mc_rst_n[gl]), .mc_init_done(mc_init_done[gl]), .mc_fatal(mc_fatal[gl]),
        .mc_cmd_valid(mc_cmd_valid[gl]), .mc_cmd_ready(mc_cmd_ready[gl]), .mc_cmd_write(mc_cmd_write[gl]),
        .mc_cmd_addr(mc_cmd_addr[gl*LA_W +: LA_W]), .mc_cmd_len(mc_cmd_len[gl*8 +: 8]), .mc_cmd_tag(mc_cmd_tag[gl*TAG_W +: TAG_W]),
        .mc_wd_valid(mc_wd_valid[gl]), .mc_wd_ready(mc_wd_ready[gl]), .mc_wd_data(mc_wd_data[gl*DATA_W +: DATA_W]),
        .mc_wd_strb(mc_wd_strb[gl*BSTRB_W +: BSTRB_W]), .mc_wd_last(mc_wd_last[gl]),
        .mc_rd_valid(mc_rd_valid[gl]), .mc_rd_ready(mc_rd_ready[gl]), .mc_rd_data(mc_rd_data[gl*DATA_W +: DATA_W]),
        .mc_rd_tag(mc_rd_tag[gl*TAG_W +: TAG_W]), .mc_rd_last(mc_rd_last[gl]), .mc_rd_error(mc_rd_error[gl]),
        .mc_wr_valid(mc_wr_valid[gl]), .mc_wr_ready(mc_wr_ready[gl]), .mc_wr_tag(mc_wr_tag[gl*TAG_W +: TAG_W]),
        .mc_wr_error(mc_wr_error[gl]),
        .mc_busy(mc_busy[gl]), .mc_rd_ce(mc_rd_ce[gl]), .mc_rd_ue(mc_rd_ue[gl]), .mc_rd_dbus(mc_rd_dbus[gl]),
        .mc_ev_hit(mc_ev_hit[gl]), .mc_ev_miss(mc_ev_miss[gl]), .mc_ev_conf(mc_ev_conf[gl]),
        .inj_be_lo(inj_be_lo[gl*LA_W +: LA_W]), .inj_be_hi(inj_be_hi[gl*LA_W +: LA_W]),
        .inj_ce_lo(inj_ce_lo[gl*LA_W +: LA_W]), .inj_ce_hi(inj_ce_hi[gl*LA_W +: LA_W]),
        .inj_ue_lo(inj_ue_lo[gl*LA_W +: LA_W]), .inj_ue_hi(inj_ue_hi[gl*LA_W +: LA_W]),
        .inj_db_lo(inj_db_lo[gl*LA_W +: LA_W]), .inj_db_hi(inj_db_hi[gl*LA_W +: LA_W]),
        .inj_hang(inj_hang[gl]), .inj_cal_drop(inj_cal_drop[gl]), .inj_fatal(inj_fatal[gl]),
        .bd_addr(bd_addr[gl*LA_W +: LA_W]), .bd_line(bd_line[gl*LINE_W +: LINE_W]), .bd_init(bd_init[gl])
      );

      sf_hbm_sfmc_check #(
        .TAG_W(TAG_W), .LA_W(LA_W), .DATA_W(DATA_W), .BURST_LEN(BURST_LEN), .LANE_OUT(LANE_OUT), .LANE_ID(gl)
      ) u_chk (
        .clk(clk), .rst_n(rst_n), .mc_rst_n(mc_rst_n[gl]), .mc_init_done(mc_init_done[gl]), .mc_fatal(mc_fatal[gl]),
        .mc_cmd_valid(mc_cmd_valid[gl]), .mc_cmd_ready(mc_cmd_ready[gl]), .mc_cmd_write(mc_cmd_write[gl]),
        .mc_cmd_addr(mc_cmd_addr[gl*LA_W +: LA_W]), .mc_cmd_len(mc_cmd_len[gl*8 +: 8]), .mc_cmd_tag(mc_cmd_tag[gl*TAG_W +: TAG_W]),
        .mc_wd_valid(mc_wd_valid[gl]), .mc_wd_ready(mc_wd_ready[gl]), .mc_wd_data(mc_wd_data[gl*DATA_W +: DATA_W]),
        .mc_wd_strb(mc_wd_strb[gl*BSTRB_W +: BSTRB_W]), .mc_wd_last(mc_wd_last[gl]),
        .mc_rd_valid(mc_rd_valid[gl]), .mc_rd_ready(mc_rd_ready[gl]), .mc_rd_tag(mc_rd_tag[gl*TAG_W +: TAG_W]),
        .mc_rd_last(mc_rd_last[gl]), .mc_wr_valid(mc_wr_valid[gl]), .mc_wr_ready(mc_wr_ready[gl]),
        .mc_wr_tag(mc_wr_tag[gl*TAG_W +: TAG_W]),
        .viol_o(c_v), .resp_viol_o(c_rv), .n_cmd_rd_o(c_nr), .n_cmd_wr_o(c_nw), .n_beats_o(c_nb)
      );
      always @* begin
        chk_viol[gl] = c_v; chk_resp_viol[gl] = c_rv; chk_n_rd[gl] = c_nr; chk_n_wr[gl] = c_nw; chk_beats[gl] = c_nb;
        mdl_viol[gl] = u_mem.violations; mdl_hit[gl] = u_mem.n_hit; mdl_miss[gl] = u_mem.n_miss; mdl_conf[gl] = u_mem.n_conf;
        mdl_ref[gl] = u_mem.n_ref; mdl_busy[gl] = u_mem.busy_cycles; mdl_act[gl] = u_mem.n_act; mdl_pre[gl] = u_mem.n_pre;
      end
    end
  endgenerate

  // ------------------------------------------------------------------ PRNG (own xorshift: simulator independent)
  reg [31:0] rng_s;
  function [31:0] xs(input [31:0] x);
    reg [31:0] y;
    begin
      y = x; y = y ^ (y << 13); y = y ^ (y >> 17); y = y ^ (y << 5); xs = y;
    end
  endfunction
  task rnd(output [31:0] r);
    begin rng_s = xs(rng_s); r = rng_s; end
  endtask
  function integer rn(input integer n);       // 0 .. n-1  (call only from procedural code: updates rng_s)
    begin rng_s = xs(rng_s); rn = (n <= 1) ? 0 : (rng_s >> 4) % n; end
  endfunction

  // ------------------------------------------------------------------ reference memory (global addresses)
  reg [7:0] ref_mem  [0:CAP_BYTES-1];
  reg       touched  [0:CAP_GRAN-1];
  reg       suspect  [0:CAP_GRAN-1];

  // ------------------------------------------------------------------ independent address mapper
  // Integer arithmetic on the documented field order (docs/ADDRESS_MAP.md), NOT bit slicing.
  integer m_lane;
  reg [LA_W-1:0] m_la;
  reg m_inr;
  task t_map(input integer addr);
    integer g, boff, ch, pc, col, bg, bank, row;
    begin
      boff = addr % BURST_BYTES;
      g    = addr / BURST_BYTES;
      ch = 0; pc = 0; col = 0; bg = 0; bank = 0; row = 0;
      if (MAP_MODE == 1) begin
        ch = g % NUM_CH; g = g / NUM_CH;  pc = g % NUM_PC; g = g / NUM_PC;
        bg = g % NBG;    g = g / NBG;     bank = g % NBANK; g = g / NBANK;
        col = g % NCOL;  g = g / NCOL;    row = g % NROW;   g = g / NROW;
      end else if (MAP_MODE == 2) begin
        col = g % NCOL;  g = g / NCOL;
        ch = g % NUM_CH; g = g / NUM_CH;  pc = g % NUM_PC; g = g / NUM_PC;
        bg = g % NBG;    g = g / NBG;     bank = g % NBANK; g = g / NBANK;
        row = g % NROW;  g = g / NROW;
      end else begin
        ch = g % NUM_CH; g = g / NUM_CH;  pc = g % NUM_PC; g = g / NUM_PC;
        col = g % NCOL;  g = g / NCOL;    bg = g % NBG;     g = g / NBG;
        bank = g % NBANK; g = g / NBANK;  row = g % NROW;   g = g / NROW;
      end
      m_inr = (g == 0);
      if (MAP_MODE == 3) begin
        bank = bank ^ (row % NBANK);
        bg   = bg   ^ ((row / NBANK) % NBG);
      end
      m_lane = ch * NUM_PC + pc;
      m_la   = ((((row * NBG + bg) * NBANK + bank) * NCOL + col) * BURST_BYTES) + boff;
    end
  endtask

  // inverse of t_map for PHYSICAL fields: lane, {bg,bank} index, row, column -> byte address
  integer inv_addr;
  task t_inv(input integer lane, input integer bk, input integer row, input integer col);
    integer ch, pc, bg, bank, braw, graw, g;
    begin
      ch = lane / NUM_PC; pc = lane % NUM_PC;
      bg = bk / NBANK; bank = bk % NBANK;
      braw = bank; graw = bg;
      if (MAP_MODE == 3) begin braw = bank ^ (row % NBANK); graw = bg ^ ((row / NBANK) % NBG); end
      if (MAP_MODE == 1)      g = ch + NUM_CH * (pc + NUM_PC * (graw + NBG * (braw + NBANK * (col + NCOL * row))));
      else if (MAP_MODE == 2) g = col + NCOL * (ch + NUM_CH * (pc + NUM_PC * (graw + NBG * (braw + NBANK * row))));
      else                    g = ch + NUM_CH * (pc + NUM_PC * (col + NCOL * (graw + NBG * (braw + NBANK * row))));
      inv_addr = g * BURST_BYTES;
    end
  endtask

  function integer bank_of_la(input [LA_W-1:0] la);       // {bg,bank} index, for statistics
    bank_of_la = (la >> (OFF_W + COL_W)) & ((1 << (BG_W + BANK_W)) - 1);
  endfunction

  // ------------------------------------------------------------------ poison table (the bench knows what it injected)
  reg [LA_W-1:0] p_be_lo [0:NUM_LANES-1];
  reg [LA_W-1:0] p_be_hi [0:NUM_LANES-1];
  reg [LA_W-1:0] p_ce_lo [0:NUM_LANES-1];
  reg [LA_W-1:0] p_ce_hi [0:NUM_LANES-1];
  reg [LA_W-1:0] p_ue_lo [0:NUM_LANES-1];
  reg [LA_W-1:0] p_ue_hi [0:NUM_LANES-1];
  reg [LA_W-1:0] p_db_lo [0:NUM_LANES-1];
  reg [LA_W-1:0] p_db_hi [0:NUM_LANES-1];
  integer pz;
  task poison_clear;
    begin
      for (pz = 0; pz < NUM_LANES; pz = pz + 1) begin
        p_be_lo[pz] = 1; p_be_hi[pz] = 0; p_ce_lo[pz] = 1; p_ce_hi[pz] = 0;
        p_ue_lo[pz] = 1; p_ue_hi[pz] = 0; p_db_lo[pz] = 1; p_db_hi[pz] = 0;
        inj_be_lo[pz*LA_W +: LA_W] = 1; inj_be_hi[pz*LA_W +: LA_W] = 0;
        inj_ce_lo[pz*LA_W +: LA_W] = 1; inj_ce_hi[pz*LA_W +: LA_W] = 0;
        inj_ue_lo[pz*LA_W +: LA_W] = 1; inj_ue_hi[pz*LA_W +: LA_W] = 0;
        inj_db_lo[pz*LA_W +: LA_W] = 1; inj_db_hi[pz*LA_W +: LA_W] = 0;
      end
    end
  endtask
  function rng_in(input [LA_W-1:0] a, input [LA_W-1:0] lo, input [LA_W-1:0] hi);
    rng_in = (lo <= hi) && (a >= lo) && (a <= hi);
  endfunction

  // ------------------------------------------------------------------ permission windows (bench copy)
  reg [ADDR_W-1:0] w_base [0:NUM_WIN-1];
  reg [ADDR_W-1:0] w_last [0:NUM_WIN-1];
  reg              w_rd   [0:NUM_WIN-1][0:NUM_SRC-1];
  reg              w_wr   [0:NUM_WIN-1][0:NUM_SRC-1];
  reg              perm_on;
  function perm_allows(input integer s, input we, input integer addr);
    integer w;
    begin
      perm_allows = 1'b0;
      for (w = 0; w < NUM_WIN; w = w + 1)
        if (w_base[w] <= addr && (addr + BURST_BYTES - 1) <= w_last[w] && (we ? w_wr[w][s] : w_rd[w][s])) perm_allows = 1'b1;
    end
  endfunction

  // ------------------------------------------------------------------ generator configuration (per source)
  localparam int PAT_SEQ = 0, PAT_RAND = 1, PAT_HOT = 2, PAT_LANE0 = 3, PAT_ROWMIX = 4, PAT_COPY = 5, PAT_ROWWALK = 6, PAT_GATHER = 7, PAT_POISON = 8, PAT_UNIQ = 9;
  integer g_pat    [0:NUM_SRC-1];
  integer g_base   [0:NUM_SRC-1];   // granule index
  integer g_span   [0:NUM_SRC-1];   // granules
  integer g_stride [0:NUM_SRC-1];   // granules
  integer g_wr_pct [0:NUM_SRC-1];   // 0..100 (100 = writes only); -1 = reads only after writes handled by scenario
  integer g_rate   [0:NUM_SRC-1];   // percent of cycles in which a new request is offered
  integer g_left   [0:NUM_SRC-1];
  integer g_hot    [0:NUM_SRC-1];
  integer g_bad    [0:NUM_SRC-1];   // percent of requests that are deliberately invalid
  integer g_idr    [0:NUM_SRC-1];   // id range
  integer g_ptr    [0:NUM_SRC-1];
  integer g_fullstrb [0:NUM_SRC-1]; // percent of writes with a full byte-enable mask
  integer g_nrows  [0:NUM_SRC-1];   // PAT_ROWMIX: number of distinct rows
  integer g_bank   [0:NUM_SRC-1];   // PAT_ROWMIX / PAT_ROWWALK: {bg,bank} index
  integer g_dst    [0:NUM_SRC-1];   // PAT_COPY: destination base granule
  integer g_flow   [0:NUM_SRC-1];   // 1 = this source is driven by the tensor tile-fetch flow
  integer rsp_pct;                  // percent of cycles in which a response is taken
  reg     gen_on;
  reg     lenient;                  // fault scenario: FLUSH / TIMEOUT statuses and suspect data are tolerated

  // pending request (what is driven on the port)
  reg                p_v   [0:NUM_SRC-1];
  reg                p_we  [0:NUM_SRC-1];
  reg [ID_W-1:0]     p_id  [0:NUM_SRC-1];
  reg [ADDR_W-1:0]   p_addr[0:NUM_SRC-1];
  reg [LINE_W-1:0]   p_data[0:NUM_SRC-1];
  reg [STRB_W-1:0]   p_strb[0:NUM_SRC-1];

  // records of accepted, not yet answered requests (per source, circular)
  reg                r_alive [0:NUM_SRC*REC-1];
  reg                r_we    [0:NUM_SRC*REC-1];
  reg [ID_W-1:0]     r_id    [0:NUM_SRC*REC-1];
  reg [ADDR_W-1:0]   r_addr  [0:NUM_SRC*REC-1];
  reg [3:0]          r_stat  [0:NUM_SRC*REC-1];
  reg [LINE_W-1:0]   r_data  [0:NUM_SRC*REC-1];
  reg                r_susp  [0:NUM_SRC*REC-1];
  reg                r_okw   [0:NUM_SRC*REC-1];   // a write that was applied to the reference
  integer            r_tacc  [0:NUM_SRC*REC-1];
  integer            r_wbytes[0:NUM_SRC*REC-1];   // enabled bytes of a write (its useful bytes)
  integer            r_head  [0:NUM_SRC-1];       // oldest possibly-alive position (monotonic counter)
  integer            r_tail  [0:NUM_SRC-1];       // next position to allocate (monotonic counter)

  // ------------------------------------------------------------------ statistics (bench-side, independent of the RTL counters)
  integer cyc;
  integer errors;
  reg     trace_on;
  integer n_acc [0:NUM_SRC-1];
  integer n_rsp [0:NUM_SRC-1];
  integer n_rej [0:NUM_SRC-1];
  integer n_err_rsp [0:NUM_SRC-1];
  integer b_rd  [0:NUM_SRC-1];
  integer b_wr  [0:NUM_SRC-1];
  integer lat_sum [0:NUM_SRC-1];
  integer lat_max [0:NUM_SRC-1];
  integer ing_stall [0:NUM_SRC-1];
  integer n_reord [0:NUM_SRC-1];                  // responses that left the source in a different order than they completed? (bench: not observable) -> count of out-of-acceptance-order deliveries
  integer lat_hist [0:HIST_MAX-1];
  integer lat_over;
  integer t_first, t_last;
  integer tot_acc, tot_rsp;
  integer n_stat [0:15];
  integer max_out_seen [0:NUM_SRC-1];
  integer n_out [0:NUM_SRC-1];
  integer lim_cfg [0:NUM_SRC-1];

  // protocol watch on the response ports
  reg                 rw_v   [0:NUM_SRC-1];
  reg [ID_W-1:0]      rw_id  [0:NUM_SRC-1];
  reg [3:0]           rw_st  [0:NUM_SRC-1];
  reg [LINE_W-1:0]    rw_d   [0:NUM_SRC-1];

  task fail(input [8*64-1:0] msg, input integer a, input integer b);
    begin
      errors = errors + 1;
      if (errors <= 12) $display("[TB] t=%0t cyc=%0d ERROR: %0s (%0d, %0d)", $time, cyc, msg, a, b);
    end
  endtask

  // expected status of a *valid* request given the poison tables
  function [3:0] exp_status(input integer lane, input [LA_W-1:0] la, input we);
    reg be, ce, ue, db;
    begin
      be = rng_in(la, p_be_lo[lane], p_be_hi[lane]);
      ce = rng_in(la, p_ce_lo[lane], p_ce_hi[lane]);
      ue = rng_in(la, p_ue_lo[lane], p_ue_hi[lane]);
      db = rng_in(la, p_db_lo[lane], p_db_hi[lane]);
      if (we) exp_status = be ? `SF_HBM_ST_ERR_BE : `SF_HBM_ST_OK;
      else if (ue) exp_status = `SF_HBM_ST_ERR_ECC_UE;
      else if (db) exp_status = `SF_HBM_ST_ERR_DBUS;
      else if (be) exp_status = `SF_HBM_ST_ERR_BE;
      else if (ce) exp_status = `SF_HBM_ST_OK_ECC_CE;
      else exp_status = `SF_HBM_ST_OK;
    end
  endfunction


  // ------------------------------------------------------------------ tensor tile-fetch flow (source 0): ping-pong buffers + compute consumer
  integer tn_tile_g, tn_ntiles, tn_tcomp, tn_cw_g, tn_base, tn_cbase;
  integer tn_fetch_t, tn_fetch_k, tn_cw_left, tn_cw_out;
  integer tn_recv [0:1];
  reg     tn_full [0:1];
  reg     tn_inuse[0:1];
  reg     tn_busy;
  integer tn_left, tn_cbuf, tn_done, tn_starve, tn_first_start, tn_idle_run, tn_max_idle, tn_start_cyc, tn_end_cyc;
  reg     tn_active;
  reg [3:0] p_aux [0:NUM_SRC-1];
  integer p_toff [0:NUM_SRC-1];
  integer r_toff [0:NUM_SRC*REC-1];
  integer e2e_sum [0:NUM_SRC-1];
  integer e2e_max [0:NUM_SRC-1];
  integer e2e_hist [0:NUM_SRC*4096-1];
  reg [3:0] r_aux [0:NUM_SRC*REC-1];
  task tn_start(input integer ntiles, input integer tile_g, input integer tcomp, input integer cw_g);
    begin
      tn_ntiles = ntiles; tn_tile_g = tile_g; tn_tcomp = tcomp; tn_cw_g = cw_g;
      tn_base = 0; tn_cbase = 262144 % CAP_GRAN;
      tn_fetch_t = 0; tn_fetch_k = 0; tn_cw_left = 0; tn_cw_out = 0;
      tn_recv[0] = 0; tn_recv[1] = 0; tn_full[0] = 1'b0; tn_full[1] = 1'b0; tn_inuse[0] = 1'b0; tn_inuse[1] = 1'b0;
      tn_busy = 1'b0; tn_left = 0; tn_cbuf = 0; tn_done = 0; tn_starve = 0; tn_first_start = -1; tn_idle_run = 0; tn_max_idle = 0;
      tn_start_cyc = cyc; tn_end_cyc = 0; tn_active = 1'b1; g_flow[0] = 1;
    end
  endtask

  // ------------------------------------------------------------------ request generation
  integer q_s;
  task gen_request(input integer s);
    integer gi, span, kind, n, i;
    reg [31:0] r1, r2;
    reg bad;
    begin
      p_we[s] = (rn(100) < g_wr_pct[s]);
      p_id[s] = rn(g_idr[s]);
      span = (g_span[s] < 1) ? 1 : g_span[s];
      case (g_pat[s])
        PAT_SEQ:   begin gi = g_base[s] + (g_ptr[s] % span); g_ptr[s] = g_ptr[s] + g_stride[s]; end
        PAT_RAND:  gi = g_base[s] + rn(span);
        PAT_HOT:   gi = g_base[s] + rn((g_hot[s] < 1) ? 1 : g_hot[s]);
        PAT_LANE0: begin                                                  // every request in lane 0 (rejection sampling on the independent mapper)
          gi = g_base[s] + rn(span); t_map(gi * BURST_BYTES); n = 0;
          while (m_lane != 0 && n < 64) begin gi = g_base[s] + rn(span); t_map(gi * BURST_BYTES); n = n + 1; end
        end
        PAT_ROWMIX: begin   // random columns over g_nrows rows of ONE bank of lane 0
          t_inv(0, g_bank[s], g_base[s] % NROW + rn((g_nrows[s] < 1) ? 1 : g_nrows[s]), rn(NCOL));
          gi = inv_addr / BURST_BYTES;
        end
        PAT_ROWWALK: begin  // every request opens a new row of one bank (worst-case row conflicts)
          t_inv(g_ptr[s] % NUM_LANES, g_bank[s], (g_base[s] + g_ptr[s] / NUM_LANES) % NROW, (g_ptr[s] / (NUM_LANES * NROW)) % NCOL);
          g_ptr[s] = g_ptr[s] + 1; gi = inv_addr / BURST_BYTES;
        end
        PAT_POISON: begin   // lane-local granules 0..23 of bank 0 / row 0 of a random lane: the first 16 are poisoned by the be_err scenario
          t_inv(rn(NUM_LANES), 0, 0, rn((24 < NCOL) ? 24 : NCOL));
          gi = inv_addr / BURST_BYTES;
        end
        PAT_UNIQ: begin     // every request a DIFFERENT granule of a private power-of-two region (odd multiplier = bijection): hazard-free, scattered over banks / rows
          gi = g_base[s] + ((g_ptr[s] * 1031) & (span - 1)); g_ptr[s] = g_ptr[s] + 1;
        end
        PAT_COPY: begin     // read chunk i from the source stream, then write chunk i to the destination stream
          gi = ((g_ptr[s] % 2) == 0) ? (g_base[s] + ((g_ptr[s] / 2) % span)) : (g_dst[s] + ((g_ptr[s] / 2) % span));
          p_we[s] = ((g_ptr[s] % 2) == 1); g_ptr[s] = g_ptr[s] + 1;
        end
        PAT_GATHER: begin   // indexed gather: runs of 1-4 consecutive granules at random places
          if ((g_ptr[s] % 4) == 0 || rn(3) == 0) g_hot[s] = rn(span);
          gi = g_base[s] + ((g_hot[s] + (g_ptr[s] % 4)) % span); g_ptr[s] = g_ptr[s] + 1;
        end
        default:   gi = g_base[s];
      endcase
      p_addr[s] = gi * BURST_BYTES;
      // data / strobes
      for (i = 0; i < LINE_W / 32; i = i + 1) begin rnd(r1); p_data[s][i*32 +: 32] = r1; end
      if (rn(100) < g_fullstrb[s]) p_strb[s] = {STRB_W{1'b1}};
      else begin
        p_strb[s] = '0;
        for (i = 0; i < STRB_W; i = i + 1) p_strb[s][i] = (rn(100) < 60);
        if (p_strb[s] == '0) p_strb[s][rn(STRB_W)] = 1'b1;
      end
      // deliberately invalid requests
      bad = (g_bad[s] > 0) && (rn(100) < g_bad[s]);
      if (bad) begin
        kind = rn(4);
        case (kind)
          0: p_addr[s] = CAP_BYTES + rn(64) * BURST_BYTES;                         // out of range
          1: p_addr[s] = (gi * BURST_BYTES) + 1 + rn(BURST_BYTES - 1);             // misaligned
          2: begin p_we[s] = 1'b1; p_strb[s] = '0; end                              // zero strobe
          default: p_addr[s] = (rn(2) == 0) ? (CAP_BYTES - BURST_BYTES) : (gi * BURST_BYTES); // maybe outside a window
        endcase
      end
    end
  endtask

  // ------------------------------------------------------------------ FCFS issue-order monitor (scenario fcfs_order)
  // Per lane, the (direction, lane-local address) of every VALID request in the order of ACCEPTANCE (at most one per lane per cycle), compared
  // with the commands that actually cross the SFMC boundary.  Only meaningful for hazard-free traffic under policy 0 (strict FCFS).
  localparam int OF_DEPTH = 1024;
  reg                of_on;
  reg                of_we [0:NUM_LANES*OF_DEPTH-1];
  reg [LA_W-1:0]     of_la [0:NUM_LANES*OF_DEPTH-1];
  integer            of_h  [0:NUM_LANES-1];
  integer            of_t  [0:NUM_LANES-1];
  integer            of_n_chk, of_n_dir;
  reg                of_last_we [0:NUM_LANES-1];
  reg                of_have_last [0:NUM_LANES-1];
  integer            of_l;
  task of_clear;
    integer q;
    begin
      for (q = 0; q < NUM_LANES; q = q + 1) begin of_h[q] = 0; of_t[q] = 0; of_have_last[q] = 1'b0; of_last_we[q] = 1'b0; end
      of_n_chk = 0; of_n_dir = 0;
    end
  endtask

  // ------------------------------------------------------------------ acceptance: apply to the reference, compute expectation
  task on_accept(input integer s);
    integer pos, i, g, lane;
    reg [LINE_W-1:0] line;
    reg [3:0] st;
    reg susp, okw, valid_;
    begin
      t_map(p_addr[s]);
      lane = m_lane;
      valid_ = 1'b1; st = `SF_HBM_ST_OK; susp = 1'b0; okw = 1'b0; line = '0;
      if (!m_inr)                                          begin valid_ = 1'b0; st = `SF_HBM_ST_ERR_ADDR;  end
      else if ((p_addr[s] % BURST_BYTES) != 0)             begin valid_ = 1'b0; st = `SF_HBM_ST_ERR_ALIGN; end
      else if (perm_on && !perm_allows(s, p_we[s], p_addr[s])) begin valid_ = 1'b0; st = `SF_HBM_ST_ERR_PERM; end
      else if (p_we[s] && p_strb[s] == '0)                 begin valid_ = 1'b0; st = `SF_HBM_ST_ERR_STRB;  end
      if (valid_ && of_on) begin
        if ((of_t[lane] - of_h[lane]) >= OF_DEPTH) fail("fcfs_order: monitor FIFO overflow", lane, 0);
        else begin
          of_we[lane * OF_DEPTH + (of_t[lane] % OF_DEPTH)] = p_we[s];
          of_la[lane * OF_DEPTH + (of_t[lane] % OF_DEPTH)] = m_la;
          of_t[lane] = of_t[lane] + 1;
        end
      end
      if (valid_) begin
        g = p_addr[s] / BURST_BYTES;
        st = exp_status(lane, m_la, p_we[s]);
        if (!p_we[s]) begin
          for (i = 0; i < BURST_BYTES; i = i + 1) line[i*8 +: 8] = ref_mem[p_addr[s] + i];
          susp = suspect[g];
        end else begin
          // the write is applied at its ordering point (acceptance) unless the backend will fail it
          touched[g] = 1'b1;
          if (lenient) suspect[g] = 1'b1;
          if (st < 4'd2) begin
            for (i = 0; i < BURST_BYTES; i = i + 1) if (p_strb[s][i]) ref_mem[p_addr[s] + i] = p_data[s][i*8 +: 8];
            okw = 1'b1;
          end
        end
      end else begin
        n_rej[s] = n_rej[s] + 1;
      end
      // record
      pos = (r_tail[s] % REC) + s * REC;
      if (r_tail[s] - r_head[s] >= REC) fail("record table overflow", s, 0);
      r_alive[pos] = 1'b1; r_we[pos] = p_we[s]; r_id[pos] = p_id[s]; r_addr[pos] = p_addr[s];
      r_stat[pos] = st; r_data[pos] = (st >= 4'd2 || p_we[s]) ? {LINE_W{1'b0}} : line; r_susp[pos] = susp; r_okw[pos] = okw;
      r_tacc[pos] = cyc;
      r_aux[pos] = p_aux[s];
      r_toff[pos] = p_toff[s];
      r_wbytes[pos] = 0;
      if (p_we[s]) for (i = 0; i < BURST_BYTES; i = i + 1) r_wbytes[pos] = r_wbytes[pos] + (p_strb[s][i] ? 1 : 0);
      if (trace_on) $display("[TR] %0d ACC s=%0d %s id=%0d addr=%0h lane=%0d la=%0h st=%0d d0=%0h", cyc, s, p_we[s] ? "WR" : "RD", p_id[s], p_addr[s], lane, m_la, st, p_we[s] ? p_data[s][31:0] : line[31:0]);
      r_tail[s] = r_tail[s] + 1;
      n_acc[s] = n_acc[s] + 1; n_out[s] = n_out[s] + 1; tot_acc = tot_acc + 1;
      if (n_out[s] > max_out_seen[s]) max_out_seen[s] = n_out[s];
      if (t_first < 0) t_first = cyc;
    end
  endtask

  // ------------------------------------------------------------------ response check
  task on_response(input integer s);
    integer k, pos, found, lat, b, nolder;
    reg [ID_W-1:0] id_;
    reg [3:0] st_;
    reg [LINE_W-1:0] d_;
    reg we_;
    begin
      id_ = s_rsp_id[s*ID_W +: ID_W]; st_ = s_rsp_status[s*4 +: 4]; d_ = s_rsp_data[s*LINE_W +: LINE_W]; we_ = s_rsp_we[s];
      if (trace_on) $display("[TR] %0d RSP s=%0d %s id=%0d st=%0d d0=%0h", cyc, s, s_rsp_we[s] ? "WR" : "RD", id_, st_, d_[31:0]);
      found = -1; nolder = 0;
      // oldest alive record (ORDER_MODE 0) or oldest alive record with the same id (ORDER_MODE 1)
      for (k = r_head[s]; k < r_tail[s] && found < 0; k = k + 1) begin
        pos = (k % REC) + s * REC;
        if (r_alive[pos]) begin
          if (ORDER_MODE == 0) found = k;
          else if (r_id[pos] == id_) found = k;
        end
      end
      if (found < 0) begin
        fail("unexpected response (no matching live request)", s, id_);
      end else begin
        pos = (found % REC) + s * REC;
        if (ORDER_MODE == 0 && r_id[pos] != id_) fail("response out of order / wrong id", s, id_);
        if (r_we[pos] != we_) fail("response direction mismatch", s, id_);
        if (st_ != r_stat[pos]) begin
          if (lenient && (st_ == `SF_HBM_ST_ERR_FLUSH || st_ == `SF_HBM_ST_ERR_TIMEOUT)) begin
            if (r_we[pos]) suspect[r_addr[pos] / BURST_BYTES] = 1'b1;
            // a tolerated failure of a request the reference thought OK: its effect is unknown
          end else fail("status mismatch (got)", s, st_);
          if (!(lenient && (st_ == `SF_HBM_ST_ERR_FLUSH || st_ == `SF_HBM_ST_ERR_TIMEOUT)) && errors <= 12)
            $display("[TB]    expected status %0d  addr=%0h we=%0d", r_stat[pos], r_addr[pos], r_we[pos]);
        end else if (st_ < 4'd2 && !r_we[pos] && !r_susp[pos] && !(lenient && suspect[r_addr[pos] / BURST_BYTES])) begin
          if (d_ !== r_data[pos]) begin
            fail("read data mismatch", s, r_addr[pos]);
            if (errors <= 12) $display("[TB]    exp %0h\n[TB]    got %0h", r_data[pos], d_);
          end
        end
        if (st_ >= 4'd2 && d_ !== {LINE_W{1'b0}}) fail("error response carries non-zero data", s, st_);
        // statistics
        lat = cyc - r_tacc[pos];
        e2e_sum[s] = e2e_sum[s] + (cyc - r_toff[pos]); if (cyc - r_toff[pos] > e2e_max[s]) e2e_max[s] = cyc - r_toff[pos];
        e2e_hist[s*4096 + (((cyc - r_toff[pos]) < 4095) ? (cyc - r_toff[pos]) : 4095)] = e2e_hist[s*4096 + (((cyc - r_toff[pos]) < 4095) ? (cyc - r_toff[pos]) : 4095)] + 1;
        lat_sum[s] = lat_sum[s] + lat; if (lat > lat_max[s]) lat_max[s] = lat;
        if (lat < HIST_MAX) lat_hist[lat] = lat_hist[lat] + 1; else lat_over = lat_over + 1;
        n_stat[st_] = n_stat[st_] + 1;
        if (st_ >= 4'd2) n_err_rsp[s] = n_err_rsp[s] + 1;
        else if (r_we[pos]) b_wr[s] = b_wr[s] + r_wbytes[pos];
        else b_rd[s] = b_rd[s] + BURST_BYTES;
        // out-of-acceptance-order delivery (only possible with ORDER_MODE 1 / different ids)
        if (found != r_head[s]) n_reord[s] = n_reord[s] + 1;
        if (s == 0 && g_flow[0] != 0) begin
          if (r_aux[pos][3:2] == 2'd1) begin                    // tile fetch response
            tn_recv[r_aux[pos][0]] = tn_recv[r_aux[pos][0]] + 1;
            if (tn_recv[r_aux[pos][0]] == tn_tile_g) tn_full[r_aux[pos][0]] = 1'b1;
          end else if (r_aux[pos][3:2] == 2'd2) tn_cw_out = tn_cw_out - 1;  // result write acknowledged
        end
        r_alive[pos] = 1'b0;
        while (r_head[s] < r_tail[s] && !r_alive[(r_head[s] % REC) + s * REC]) r_head[s] = r_head[s] + 1;
        n_out[s] = n_out[s] - 1;
        n_rsp[s] = n_rsp[s] + 1; tot_rsp = tot_rsp + 1; t_last = cyc;
      end
    end
  endtask

  // ------------------------------------------------------------------ cycle process: generators, handshakes, monitors
  integer s, i3;
  reg [31:0] rr, rr3;
  always @(posedge clk) begin
    if (!rst_n) begin
      cyc = cyc + 1;
      s_req_valid <= '0;
      for (s = 0; s < NUM_SRC; s = s + 1) p_v[s] = 1'b0;
    end else begin
      cyc = cyc + 1;
      if (of_on) begin
        for (of_l = 0; of_l < NUM_LANES; of_l = of_l + 1) begin
          if (mc_cmd_valid[of_l] && mc_cmd_ready[of_l]) begin
            if (of_h[of_l] >= of_t[of_l]) fail("fcfs_order: a command was issued that no accepted request explains", of_l, 0);
            else begin
              if (of_we[of_l * OF_DEPTH + (of_h[of_l] % OF_DEPTH)] !== mc_cmd_write[of_l] ||
                  of_la[of_l * OF_DEPTH + (of_h[of_l] % OF_DEPTH)] !== mc_cmd_addr[of_l*LA_W +: LA_W])
                fail("fcfs_order: command issue order differs from acceptance order", of_l, of_h[of_l]);
              of_h[of_l] = of_h[of_l] + 1; of_n_chk = of_n_chk + 1;
              if (of_have_last[of_l] && of_last_we[of_l] != mc_cmd_write[of_l]) of_n_dir = of_n_dir + 1;
              of_last_we[of_l] = mc_cmd_write[of_l]; of_have_last[of_l] = 1'b1;
            end
          end
        end
      end
      for (s = 0; s < NUM_SRC; s = s + 1) begin
        // ---- request handshake (both sampled before this edge)
        if (s_req_valid[s] && !s_req_ready[s]) ing_stall[s] = ing_stall[s] + 1;
        if (s_req_valid[s] && s_req_ready[s]) begin
          on_accept(s);
          p_v[s] = 1'b0;
        end
        // ---- response handshake
        if (s_rsp_valid[s] && s_rsp_ready[s]) on_response(s);
        // ---- response payload stability under back-pressure (valid && !ready must persist unchanged)
        if (rw_v[s]) begin
          if (!s_rsp_valid[s] || s_rsp_id[s*ID_W +: ID_W] !== rw_id[s] || s_rsp_status[s*4 +: 4] !== rw_st[s] ||
              s_rsp_data[s*LINE_W +: LINE_W] !== rw_d[s]) fail("response changed / dropped while stalled", s, 0);
        end
        rw_v[s] = s_rsp_valid[s] && !s_rsp_ready[s];
        rw_id[s] = s_rsp_id[s*ID_W +: ID_W]; rw_st[s] = s_rsp_status[s*4 +: 4]; rw_d[s] = s_rsp_data[s*LINE_W +: LINE_W];
        // ---- outstanding limit
        if (lim_cfg[s] > 0 && n_out[s] > lim_cfg[s]) fail("outstanding limit exceeded", s, n_out[s]);
        // ---- tensor flow (source 0): compute consumer + fetch / result-write generator
        if (s == 0 && g_flow[0] != 0 && tn_active) begin
          // compute engine
          if (tn_busy) begin
            tn_left = tn_left - 1;
            if (tn_left == 0) begin
              tn_busy = 1'b0; tn_inuse[tn_cbuf] = 1'b0; tn_recv[tn_cbuf] = 0; tn_done = tn_done + 1;
              tn_cw_left = tn_cw_left + tn_cw_g; tn_cbuf = 1 - tn_cbuf;
              if (tn_done == tn_ntiles) tn_end_cyc = cyc;
            end
          end
          if (!tn_busy && tn_done < tn_ntiles) begin
            if (tn_full[tn_cbuf]) begin
              tn_busy = 1'b1; tn_left = tn_tcomp; tn_full[tn_cbuf] = 1'b0; tn_inuse[tn_cbuf] = 1'b1;
              if (tn_first_start < 0) tn_first_start = cyc;
              if (tn_idle_run > tn_max_idle) tn_max_idle = tn_idle_run;
              tn_idle_run = 0;
            end else if (tn_first_start >= 0) begin tn_starve = tn_starve + 1; tn_idle_run = tn_idle_run + 1; end
          end
          // request generation: result writes first, then the next tile fetch
          if (!p_v[0] && gen_on && rn(100) < g_rate[0]) begin
            if (tn_cw_left > 0) begin
              p_we[0] = 1'b1; p_id[0] = rn(g_idr[0]); p_addr[0] = (tn_cbase + (tn_done * tn_cw_g + tn_cw_left) % 4096) * BURST_BYTES;
              p_strb[0] = {STRB_W{1'b1}}; for (i3 = 0; i3 < LINE_W / 32; i3 = i3 + 1) begin rnd(rr3); p_data[0][i3*32 +: 32] = rr3; end
              p_aux[0] = {2'd2, 2'd0}; tn_cw_left = tn_cw_left - 1; tn_cw_out = tn_cw_out + 1; p_v[0] = 1'b1; p_toff[0] = cyc;
            end else if (tn_fetch_t < tn_ntiles && !tn_inuse[tn_fetch_t % 2] && !tn_full[tn_fetch_t % 2]) begin
              p_we[0] = 1'b0; p_id[0] = rn(g_idr[0]);
              p_addr[0] = (tn_base + tn_fetch_t * tn_tile_g + tn_fetch_k) % CAP_GRAN * BURST_BYTES;
              p_strb[0] = {STRB_W{1'b1}}; p_data[0] = '0;
              p_aux[0] = {2'd1, 1'b0, tn_fetch_t[0]}; tn_fetch_k = tn_fetch_k + 1;
              if (tn_fetch_k == tn_tile_g) begin tn_fetch_k = 0; tn_fetch_t = tn_fetch_t + 1; end
              p_v[0] = 1'b1; p_toff[0] = cyc;
            end
          end
          if (tn_done == tn_ntiles && tn_cw_left == 0 && tn_cw_out == 0 && !p_v[0]) tn_active = 1'b0;
        end
        // ---- offer a new request
        if (!(s == 0 && g_flow[0] != 0) && !p_v[s] && gen_on && g_left[s] > 0 && rn(100) < g_rate[s]) begin
          p_aux[s] = 4'd0;
          gen_request(s);
          p_toff[s] = cyc;
          p_v[s] = 1'b1;
          g_left[s] = g_left[s] - 1;
        end
        // ---- drive
        s_req_valid[s]                       <= p_v[s];
        s_req_we[s]                          <= p_we[s];
        s_req_id[s*ID_W +: ID_W]             <= p_id[s];
        s_req_addr[s*ADDR_W +: ADDR_W]       <= p_addr[s];
        s_req_wdata[s*LINE_W +: LINE_W]      <= p_data[s];
        s_req_wstrb[s*STRB_W +: STRB_W]      <= p_strb[s];
        s_rsp_ready[s]                       <= (rsp_pct >= 100) ? 1'b1 : (rn(100) < rsp_pct);
      end
    end
  end

  // ------------------------------------------------------------------ helpers for scenarios
  task cfg_defaults;
    integer sx;
    begin
      cfg_policy    = 3'd0;
      cfg_wr_hi     = (WQ_DEPTH * 3) / 4;
      cfg_wr_lo     = WQ_DEPTH / 4;
      cfg_age_limit = 12'd256;
      cfg_idle_wr   = 1'b1;
      cfg_busy_cyc  = 6'd16;
      cfg_bypass_cap = '0;
      cfg_arb_mode  = 1'b0;
      cfg_arb_prio  = '0;
      cfg_arb_age   = 8'd32;
      cfg_timeout   = 32'd0;
      cfg_out_limit = '0;
      cfg_perm_en   = 1'b0;
      cfg_win_base  = '0; cfg_win_last = '0; cfg_win_perm = '0;
      cfg_link_retry = 1'b0;
      perm_on = 1'b0;
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) lim_cfg[sx] = 0;
      perf_clr = 1'b0; perf_sel = 16'd0;
      mc_busy_unused = 1'b0;
    end
  endtask
  reg mc_busy_unused;

  task gen_off;
    integer sx;
    begin
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
        g_pat[sx] = PAT_RAND; g_base[sx] = 0; g_span[sx] = 1024; g_stride[sx] = 1; g_wr_pct[sx] = 50; g_rate[sx] = 100;
        g_left[sx] = 0; g_hot[sx] = 8; g_bad[sx] = 0; g_idr[sx] = (1 << ID_W); g_ptr[sx] = 0; g_fullstrb[sx] = 75;
        g_nrows[sx] = 2; g_bank[sx] = 0; g_dst[sx] = 0; g_flow[sx] = 0;
      end
      rsp_pct = 100;
      lenient = 1'b0;
      tn_active = 1'b0; g_flow[0] = 0;
    end
  endtask

  task stats_clear;
    integer sx, hx;
    begin
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
        n_acc[sx] = 0; n_rsp[sx] = 0; n_rej[sx] = 0; n_err_rsp[sx] = 0; b_rd[sx] = 0; b_wr[sx] = 0;
        lat_sum[sx] = 0; lat_max[sx] = 0; ing_stall[sx] = 0; n_reord[sx] = 0; max_out_seen[sx] = 0;
        n_out[sx] = 0; r_head[sx] = 0; r_tail[sx] = 0; p_v[sx] = 1'b0; rw_v[sx] = 1'b0; e2e_sum[sx] = 0; e2e_max[sx] = 0; p_toff[sx] = 0;
        for (hx = 0; hx < 4096; hx = hx + 1) e2e_hist[sx*4096 + hx] = 0;
        p_we[sx] = 1'b0; p_id[sx] = '0; p_addr[sx] = '0; p_data[sx] = '0; p_strb[sx] = '0;
      end
      for (hx = 0; hx < HIST_MAX; hx = hx + 1) lat_hist[hx] = 0;
      for (hx = 0; hx < 16; hx = hx + 1) n_stat[hx] = 0;
      lat_over = 0; t_first = -1; t_last = 0; tot_acc = 0; tot_rsp = 0;
      for (hx = 0; hx < NUM_SRC*REC; hx = hx + 1) r_alive[hx] = 1'b0;
    end
  endtask

  // reference memory <- initial pattern (via the independent mapper)
  integer ig, ib;
  task ref_init;
    begin
      for (ig = 0; ig < CAP_GRAN; ig = ig + 1) begin
        t_map(ig * BURST_BYTES);
        for (ib = 0; ib < BURST_BYTES; ib = ib + 1)
          ref_mem[ig * BURST_BYTES + ib] = `SF_HBM_MODEL_PATTERN(m_la + ib, m_lane);
        touched[ig] = 1'b0; suspect[ig] = 1'b0;
      end
    end
  endtask

  // reference memory <- the models' memories (used only after injected faults, where the outcome of in-flight writes is unknowable)
  task ref_resync;
    integer rg, rb;
    begin
      for (rg = 0; rg < CAP_GRAN; rg = rg + 1) begin
        if (touched[rg] || suspect[rg]) begin
          t_map(rg * BURST_BYTES);
          bd_addr[m_lane*LA_W +: LA_W] = m_la;
          #1;
          for (rb = 0; rb < BURST_BYTES; rb = rb + 1) ref_mem[rg * BURST_BYTES + rb] = bd_line[m_lane*LINE_W + rb*8 +: 8];
          suspect[rg] = 1'b0;
        end
      end
    end
  endtask

  // compare the reference with the models' memories: every touched granule + a sample of untouched ones
  task image_check(input integer sample);
    integer cg, cb, cnt, bad, smp;
    reg [7:0] eb;
    begin
      bad = 0; cnt = 0;
      for (cg = 0; cg < CAP_GRAN; cg = cg + 1) begin
        smp = (!touched[cg]) && (sample > 0) && ((cg % ((CAP_GRAN / sample) + 1)) == 0);
        if (touched[cg] || smp) begin
          t_map(cg * BURST_BYTES);
          bd_addr[m_lane*LA_W +: LA_W] = m_la;
          #1;
          cnt = cnt + 1;
          for (cb = 0; cb < BURST_BYTES; cb = cb + 1) begin
            eb = ref_mem[cg * BURST_BYTES + cb];
            if (bd_line[m_lane*LINE_W + cb*8 +: 8] !== eb) bad = bad + 1;
          end
          if (bad > 0 && bad <= BURST_BYTES && errors < 12)
            $display("[TB]    image mismatch granule %0d lane %0d la=%0h", cg, m_lane, m_la);
        end
      end
      if (bad != 0) fail("final memory image differs from the reference", bad, cnt);
      checks_image = checks_image + cnt;
    end
  endtask
  integer checks_image;

  // run until every generator is done and everything is answered
  integer wait_cyc;
  task run_to_idle(input integer max_cyc);
    integer sx, left;
    reg done;
    begin
      wait_cyc = 0; done = 1'b0;
      while (!done && wait_cyc < max_cyc) begin
        @(posedge clk);
        wait_cyc = wait_cyc + 1;
        left = 0;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) left = left + g_left[sx] + (p_v[sx] ? 1 : 0) + n_out[sx];
        if (tn_active) left = left + 1;
        done = (left == 0);
      end
      if (!done) begin
        fail("timeout: requests still outstanding", 0, 0);
        for (sx = 0; sx < NUM_SRC; sx = sx + 1)
          $display("[TB]    src %0d: left=%0d pend=%0d out=%0d", sx, g_left[sx], p_v[sx], n_out[sx]);
      end
      repeat (4) @(posedge clk);
    end
  endtask

  // ------------------------------------------------------------------ RTL counter access
  reg [63:0] v2_, v1_;
  task rdp(input [1:0] grp, input integer ins, input integer idx, output [63:0] val);
    begin
      perf_sel = {grp, ins[5:0], idx[7:0]};
      #1;
      val = perf_data;
    end
  endtask

  integer base_rd [0:NUM_LANES-1];
  integer base_wr [0:NUM_LANES-1];
  integer base_bt [0:NUM_LANES-1];
  integer checks_perf;
  task perf_check;
    integer sx, lx;
    reg [63:0] v;
    integer sum_req, sum_rsp, sum_rb, sum_wb, sum_lat, sum_rej, sum_err, hsum, hb, sum_ing, sum_sq, sum_lq;
    begin
      sum_req = 0; sum_rsp = 0; sum_rb = 0; sum_wb = 0; sum_lat = 0; sum_rej = 0; sum_err = 0; sum_ing = 0;
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_REQ, v);   if (v !== n_acc[sx]) fail("perf S_REQ", sx, v);
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_RSP, v);   if (v !== n_rsp[sx]) fail("perf S_RSP", sx, v);
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_BYTES, v); if (v !== (b_rd[sx] + b_wr[sx])) fail("perf S_BYTES", sx, v);
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_LAT_SUM, v); if (v !== lat_sum[sx]) fail("perf S_LAT_SUM", sx, v);
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_LAT_MAX, v); if (v !== lat_max[sx]) fail("perf S_LAT_MAX", sx, v);
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_ERR, v);   if (v !== n_err_rsp[sx]) fail("perf S_ERR", sx, v);
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_ING_STALL, v); if (v !== ing_stall[sx]) fail("perf S_ING_STALL", sx, v);
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_GRANTS, v); if (v !== (n_acc[sx] - n_rej[sx])) fail("perf S_GRANTS", sx, v);
        sum_req = sum_req + n_acc[sx]; sum_rsp = sum_rsp + n_rsp[sx]; sum_rb = sum_rb + b_rd[sx]; sum_wb = sum_wb + b_wr[sx];
        sum_lat = sum_lat + lat_sum[sx]; sum_rej = sum_rej + n_rej[sx]; sum_err = sum_err + n_err_rsp[sx]; sum_ing = sum_ing + ing_stall[sx];
      end
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_REQ, v);      if (v !== sum_req) fail("perf G_REQ", sum_req, v);
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_RSP, v);      if (v !== sum_rsp) fail("perf G_RSP", sum_rsp, v);
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_BYTES_RD, v); if (v !== sum_rb) fail("perf G_BYTES_RD", sum_rb, v);
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_BYTES_WR, v); if (v !== sum_wb) fail("perf G_BYTES_WR", sum_wb, v);
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_LAT_SUM, v);  if (v !== sum_lat) fail("perf G_LAT_SUM", sum_lat, v);
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_REJECT, v);   if (v !== sum_rej) fail("perf G_REJECT", sum_rej, v);
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_RSP_ERR, v);  if (v !== sum_err) fail("perf G_RSP_ERR", sum_err, v);
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_ING_STALL, v); if (v !== sum_ing) fail("perf G_ING_STALL", sum_ing, v);
      hsum = 0;
      for (hb = 0; hb < 16; hb = hb + 1) begin rdp(`SF_HBM_PG_HIST, 0, hb, v); hsum = hsum + v; end
      if (hsum != sum_rsp) fail("perf latency histogram total", sum_rsp, hsum);
      // per-source issue counts (events can coincide: several lanes may issue for one source in a cycle) against the per-lane counts
      sum_sq = 0; sum_lq = 0;
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_QW_CNT, v); sum_sq = sum_sq + v; end
      for (lx = 0; lx < NUM_LANES; lx = lx + 1) begin rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_QW_CNT, v); sum_lq = sum_lq + v; end
      if (sum_sq != sum_lq) fail("perf: sum of S_QW_CNT differs from sum of L_QW_CNT", sum_sq, sum_lq);
      for (lx = 0; lx < NUM_LANES; lx = lx + 1) begin
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_ISS_RD, v); if (v !== (chk_n_rd[lx] - base_rd[lx])) fail("perf L_ISS_RD vs wire count", lx, v);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_ISS_WR, v); if (v !== (chk_n_wr[lx] - base_wr[lx])) fail("perf L_ISS_WR vs wire count", lx, v);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_BEATS, v);  if (v !== (chk_beats[lx] - base_bt[lx])) fail("perf L_BEATS vs wire count", lx, v);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_QW_CNT, v); if (v !== ((chk_n_rd[lx] - base_rd[lx]) + (chk_n_wr[lx] - base_wr[lx]))) fail("perf L_QW_CNT", lx, v);
      end
      checks_perf = checks_perf + 1;
    end
  endtask

  // ------------------------------------------------------------------ end-of-test verdict helpers
  integer checks_total;
  task common_checks(input integer check_perf_en, input integer allow_resp_viol);
    integer lx;
    begin
      for (lx = 0; lx < NUM_LANES; lx = lx + 1) begin
        if (chk_viol[lx] != 0) fail("SFMC protocol violations (lane)", lx, chk_viol[lx]);
        if (!allow_resp_viol && chk_resp_viol[lx] != 0) fail("controller response violations (lane)", lx, chk_resp_viol[lx]);
        if (mdl_viol[lx] != 0) fail("memory-model contract violations (lane)", lx, mdl_viol[lx]);
      end
      if (!allow_resp_viol && err_spurious_o) fail("sticky spurious-response flag set", 0, 0);
      if (check_perf_en != 0) perf_check;
    end
  endtask

  // ------------------------------------------------------------------ scenarios
  integer test_n, sc_rs;
  reg [255:0] tname;
  integer N, SEED_V;

  task do_reset(input integer cycles);
    begin
      rst_n = 1'b0;
      repeat (cycles) @(posedge clk);
      rst_n = 1'b1;
      repeat (3) @(posedge clk);
    end
  endtask

  // wait until all lanes report READY (state 2)
  task wait_ready;
    integer wt, lx;
    reg ok;
    begin
      wt = 0; ok = 1'b0;
      while (!ok && wt < 5000) begin
        @(posedge clk); wt = wt + 1;
        ok = 1'b1;
        for (lx = 0; lx < NUM_LANES; lx = lx + 1) if (link_state_o[lx*3 +: 3] != `SF_HBM_LK_READY) ok = 1'b0;
      end
      if (!ok) fail("backend links did not reach READY", 0, 0);
    end
  endtask

  integer pa_v;
  task apply_plusargs;
    integer sx;
    begin
      if ($value$plusargs("POLICY=%d", pa_v)) cfg_policy = pa_v;
      if ($value$plusargs("BUSY=%d", pa_v))   cfg_busy_cyc = pa_v;
      if ($value$plusargs("WRHI=%d", pa_v))   cfg_wr_hi = pa_v;
      if ($value$plusargs("WRLO=%d", pa_v))   cfg_wr_lo = pa_v;
      if ($value$plusargs("AGE=%d", pa_v))    cfg_age_limit = pa_v;
      if ($value$plusargs("BYP=%d", pa_v))    cfg_bypass_cap = pa_v;
      if ($value$plusargs("IDLEWR=%d", pa_v)) cfg_idle_wr = pa_v;
      if ($value$plusargs("LIMBG=%d", pa_v)) begin
        // outstanding-window shaping: limit every source except TENSOR (0) and CONTROL (3) to pa_v transactions in flight
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) if (sx != 0 && sx != 3) begin lim_cfg[sx] = pa_v; cfg_out_limit[sx*LIM_W +: LIM_W] = pa_v; end
      end
      if ($value$plusargs("PRIO=%d", pa_v)) begin
        cfg_arb_mode = (pa_v != 0);
        // PRIO=1: ControlCore (3) highest, TensorCore (0) next, others lowest;  PRIO=2: TensorCore highest
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) cfg_arb_prio[sx*2 +: 2] = 2'd0;
        if (pa_v == 1) begin cfg_arb_prio[3*2 +: 2] = 2'd3; cfg_arb_prio[0*2 +: 2] = 2'd2; end
        if (pa_v == 2) begin cfg_arb_prio[0*2 +: 2] = 2'd3; cfg_arb_prio[3*2 +: 2] = 2'd2; end
      end
    end
  endtask

  task begin_test(input [255:0] nm);
    integer sx;
    begin
      $display("[TB] ---- test %0s ----", nm);
      gen_on = 1'b0;
      gen_off;
      poison_clear;
      for (sx = 0; sx < NUM_LANES; sx = sx + 1) begin inj_hang[sx] = 1'b0; inj_cal_drop[sx] = 1'b0; inj_fatal[sx] = 1'b0; end
      cfg_defaults;
      apply_plusargs;
      do_reset(6);
      stats_clear;
      ref_init;
      bd_init = {NUM_LANES{1'b1}}; #1; bd_init = '0; #1;      // models' memories back to the initial pattern
      wait_ready;
      for (sx = 0; sx < NUM_LANES; sx = sx + 1) begin base_rd[sx] = chk_n_rd[sx]; base_wr[sx] = chk_n_wr[sx]; base_bt[sx] = chk_beats[sx]; end
      errors = 0;
      gen_on = 1'b1;
    end
  endtask

  task end_test(input [255:0] nm, input integer check_perf_en);
    begin
      repeat (40) @(posedge clk);
      // everything answered: queues empty and no command in flight (an outstanding counter that leaks would show here)
      if (!idle_o) fail("idle_o low at the end of the test: a queue or an outstanding counter did not drain", 0, 0);
      common_checks(check_perf_en, 0);
      image_check(2048);
      if (errors == 0) $display("RESULT: PASS test=%0s cycles=%0d acc=%0d rsp=%0d image_granules=%0d", nm, cyc, tot_acc, tot_rsp, checks_image);
      else             $display("RESULT: FAIL test=%0s errors=%0d", nm, errors);
      total_errors = total_errors + errors;
      checks_image = 0;
    end
  endtask
  integer total_errors;

  // fill [base, base+span) granules with writes from the sources, then read it all back
  task fill_then_read(input integer base_g, input integer span_g, input integer nsrc);
    integer sx;
    begin
      gen_on = 1'b1;
      for (sx = 0; sx < nsrc; sx = sx + 1) begin
        g_pat[sx] = PAT_SEQ; g_base[sx] = base_g + sx * (span_g / nsrc); g_span[sx] = span_g / nsrc; g_stride[sx] = 1;
        g_wr_pct[sx] = 100; g_left[sx] = span_g / nsrc; g_fullstrb[sx] = 100; g_ptr[sx] = 0;
      end
      run_to_idle(400000);
      for (sx = 0; sx < nsrc; sx = sx + 1) begin
        g_pat[sx] = PAT_SEQ; g_base[sx] = base_g + sx * (span_g / nsrc); g_span[sx] = span_g / nsrc; g_stride[sx] = 1;
        g_wr_pct[sx] = 0; g_left[sx] = span_g / nsrc; g_ptr[sx] = 0;
      end
      run_to_idle(400000);
    end
  endtask

  // set the same random mixed workload on every source
  task mixed_all(input integer wr_pct, input integer rate, input integer n, input integer span, input integer idr);
    integer sx;
    begin
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
        g_pat[sx] = PAT_RAND; g_base[sx] = 0; g_span[sx] = span; g_wr_pct[sx] = wr_pct; g_rate[sx] = rate;
        g_left[sx] = n; g_idr[sx] = idr;
      end
    end
  endtask

  integer sx_i, tx;

  // ------------------------------------------------------------------ benchmark report (one JSON line)
  integer bz;
  function integer pct_from_hist(input integer num, input integer den);   // smallest latency L with CDF(L) >= num/den
    integer acc, tot, th, hx;
    begin
      tot = 0; for (hx = 0; hx < HIST_MAX; hx = hx + 1) tot = tot + lat_hist[hx]; tot = tot + lat_over;
      th = (tot * num + den - 1) / den; acc = 0; pct_from_hist = HIST_MAX;
      for (hx = 0; hx < HIST_MAX; hx = hx + 1) begin
        acc = acc + lat_hist[hx];
        if (acc >= th && pct_from_hist == HIST_MAX) pct_from_hist = hx;
      end
    end
  endfunction
  function integer pct_src(input integer sx, input integer num, input integer den);
    integer acc, tot, th, hx;
    begin
      tot = 0; for (hx = 0; hx < 4096; hx = hx + 1) tot = tot + e2e_hist[sx*4096 + hx];
      th = (tot * num + den - 1) / den; acc = 0; pct_src = 4095;
      for (hx = 0; hx < 4096; hx = hx + 1) begin
        acc = acc + e2e_hist[sx*4096 + hx];
        if (acc >= th && pct_src == 4095) pct_src = hx;
      end
    end
  endfunction
  task bench_report(input [255:0] nm);
    integer sx, lx, el, tot_rd, tot_wr, hits, miss, conf, bhit, bmiss, bconf, qw_s, qw_c, qw_m, tot_lat, tot_n;
    reg [63:0] v, v1, v2, v3;
    real bpc, peak;
    begin
      el = t_last - t_first + 1;
      tot_rd = 0; tot_wr = 0; tot_lat = 0; tot_n = 0;
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin tot_rd = tot_rd + b_rd[sx]; tot_wr = tot_wr + b_wr[sx]; tot_lat = tot_lat + lat_sum[sx]; tot_n = tot_n + n_rsp[sx]; end
      peak = NUM_LANES * (DATA_W / 8.0);
      bpc = (tot_rd + tot_wr) / (el * 1.0);
      $write("BENCH_JSON {\"name\":\"%0s\",\"policy\":%0d,\"cfg\":{\"ch\":%0d,\"pc\":%0d,\"lanes\":%0d,\"map\":%0d,\"rq\":%0d,\"wq\":%0d,\"order\":%0d,\"data_w\":%0d,\"burst_len\":%0d,\"burst_bytes\":%0d},",
             nm, cfg_policy, NUM_CH, NUM_PC, NUM_LANES, MAP_MODE, RQ_DEPTH, WQ_DEPTH, ORDER_MODE, DATA_W, BURST_LEN, BURST_BYTES);
      $write("\"cycles\":%0d,\"requests\":%0d,\"bytes_rd\":%0d,\"bytes_wr\":%0d,\"bytes_per_cycle\":%f,\"peak_bytes_per_cycle\":%f,\"efficiency\":%f,\"rd_bpc\":%f,\"wr_bpc\":%f,",
             el, tot_n, tot_rd, tot_wr, bpc, peak, bpc / peak, tot_rd / (el * 1.0), tot_wr / (el * 1.0));
      $write("\"lat_mean\":%f,\"lat_p50\":%0d,\"lat_p90\":%0d,\"lat_p99\":%0d,\"lat_p999\":%0d,", (tot_n > 0) ? tot_lat / (tot_n * 1.0) : 0.0,
             pct_from_hist(50, 100), pct_from_hist(90, 100), pct_from_hist(99, 100), pct_from_hist(999, 1000));
      // lanes
      $write("\"lanes_detail\":[");
      for (lx = 0; lx < NUM_LANES; lx = lx + 1) begin
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_BEATS, v);
        $write("%s{\"util\":%f", (lx == 0) ? "" : ",", v / (el * 1.0));
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_ISS_RD, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_ISS_WR, v2);
        $write(",\"iss_rd\":%0d,\"iss_wr\":%0d", v1, v2);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_HIT, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_MISS, v2); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_CONF, v3);
        $write(",\"shadow_hit\":%0d,\"shadow_miss\":%0d,\"shadow_conf\":%0d", v1, v2, v3);
        $write(",\"be_hit\":%0d,\"be_miss\":%0d,\"be_conf\":%0d,\"be_act\":%0d,\"be_pre\":%0d", mdl_hit[lx], mdl_miss[lx], mdl_conf[lx], mdl_act[lx], mdl_pre[lx]);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_BANK_CONF, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_TURN, v2); $write(",\"bank_conf\":%0d,\"turn\":%0d", v1, v2);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_QW_SUM, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_QW_CNT, v2); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_QW_MAX, v3);
        $write(",\"qw_sum\":%0d,\"qw_cnt\":%0d,\"qw_max\":%0d", v1, v2, v3);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_RQ_OCC_SUM, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_WQ_OCC_SUM, v2); $write(",\"rq_occ_sum\":%0d,\"wq_occ_sum\":%0d", v1, v2);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_RQ_MAX, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_WQ_MAX, v2); $write(",\"rq_max\":%0d,\"wq_max\":%0d", v1, v2);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_QFULL_RD, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_QFULL_WR, v2); $write(",\"qfull_rd\":%0d,\"qfull_wr\":%0d", v1, v2);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_REF_STALL, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_HAZ_STALL, v2); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_BE_STALL, v3);
        $write(",\"ref_stall\":%0d,\"haz_stall\":%0d,\"be_stall\":%0d,\"model_refreshes\":%0d", v1, v2, v3, mdl_ref[lx]);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_AGE_OVR, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_DRAIN_CYC, v2); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_BYP_OVR, v3); $write(",\"age_ovr\":%0d,\"drain_cyc\":%0d,\"byp_ovr\":%0d", v1, v2, v3);
        rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_OUT_SUM, v1); rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_OUT_MAX, v2); $write(",\"out_sum\":%0d,\"out_max\":%0d}", v1, v2);
      end
      $write("],\"src\":[");
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
        rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_REORDERED, v1); rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_ROB_STALL, v2); rdp(`SF_HBM_PG_SRC, sx, `SF_HBM_S_QW_SUM, v3);
        $write("%s{\"id\":%0d,\"req\":%0d,\"rsp\":%0d,\"err\":%0d,\"bytes\":%0d,\"lat_sum\":%0d,\"lat_max\":%0d,\"ing_stall\":%0d,\"reordered\":%0d,\"rob_stall\":%0d,\"qw_sum\":%0d,\"e2e_sum\":%0d,\"e2e_max\":%0d,\"e2e_p50\":%0d,\"e2e_p99\":%0d}",
               (sx == 0) ? "" : ",", sx, n_acc[sx], n_rsp[sx], n_err_rsp[sx], b_rd[sx] + b_wr[sx], lat_sum[sx], lat_max[sx], ing_stall[sx], v1, v2, v3,
               e2e_sum[sx], e2e_max[sx], pct_src(sx, 50, 100), pct_src(sx, 99, 100));
      end
      rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_ROB_STALL, v1);
      $write("],\"rob_stall_cycles\":%0d,\"tensor\":{\"active\":%0d,\"tiles\":%0d,\"tile_granules\":%0d,\"tcomp\":%0d,\"starve_cycles\":%0d,\"max_idle_run\":%0d,\"first_start\":%0d,\"span\":%0d}}\n",
             v1, g_flow[0], tn_done, tn_tile_g, tn_tcomp, tn_starve, tn_max_idle, tn_first_start - tn_start_cyc, (tn_end_cyc > 0) ? tn_end_cyc - tn_start_cyc : 0);
    end
  endtask

  integer fin_perf;
  task run_scenario(input [255:0] nm);
    integer sx, lx, k, base_g, rep, spn;
    reg [31:0] rr2;
    reg [63:0] v;
    begin
      fin_perf = 1;
      if (nm != "policy" && nm != "prefill") begin_test(nm);
      if (nm == "smoke") begin
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 0;
        g_pat[2] = PAT_SEQ; g_base[2] = 0; g_span[2] = 64; g_stride[2] = 1; g_wr_pct[2] = 100; g_left[2] = 64; g_fullstrb[2] = 100;
        run_to_idle(100000);
        g_wr_pct[2] = 0; g_left[2] = 64; g_ptr[2] = 0;
        run_to_idle(100000);
        fin_perf = 1;
      end else if (nm == "seq") begin
        fill_then_read(0, 1024, NUM_SRC);
        fin_perf = 1;
      end else if (nm == "rand_mixed") begin
        mixed_all(50, 100, N, 4096, (1 << ID_W));
        run_to_idle(2000000);
        fin_perf = 1;
      end else if (nm == "hazard") begin
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          g_pat[sx] = PAT_HOT; g_base[sx] = 0; g_hot[sx] = 6; g_wr_pct[sx] = 50; g_rate[sx] = 100; g_left[sx] = N;
          g_idr[sx] = 4; g_fullstrb[sx] = 50;
        end
        run_to_idle(2000000);
        fin_perf = 1;
      end else if (nm == "contend") begin
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          g_pat[sx] = PAT_LANE0; g_base[sx] = sx * 8; g_span[sx] = 1024; g_wr_pct[sx] = 40; g_rate[sx] = 100; g_left[sx] = N;
        end
        run_to_idle(2000000);
        if (NUM_LANES > 1) begin
          // lane 0 carried (nearly) everything
          if ((chk_n_rd[1] - base_rd[1]) + (chk_n_wr[1] - base_wr[1]) != 0) fail("contend: traffic leaked to lane 1", chk_n_rd[1], chk_n_wr[1]);
        end
        fin_perf = 1;
      end else if (nm == "multi_ch") begin
        mixed_all(40, 100, N, CAP_GRAN, (1 << ID_W));
        run_to_idle(2000000);
        for (lx = 0; lx < NUM_LANES; lx = lx + 1)
          if ((chk_n_rd[lx] - base_rd[lx]) + (chk_n_wr[lx] - base_wr[lx]) == 0) fail("multi_ch: a lane saw no traffic", lx, 0);
        fin_perf = 1;
      end else if (nm == "qsat") begin
        mixed_all(50, 100, N, 2048, (1 << ID_W));
        run_to_idle(4000000);
        rdp(`SF_HBM_PG_LANE, 0, `SF_HBM_L_QFULL_RD, v);
        rdp(`SF_HBM_PG_LANE, 0, `SF_HBM_L_QFULL_WR, v2_);
        v = v + v2_;
        if (v == 0 && (RQ_DEPTH <= 4 || ACCEPT_PCT <= 30)) fail("qsat: no queue-full cycle was recorded", 0, 0);
        rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_ING_STALL, v);
        if (v == 0 && (RQ_DEPTH <= 4 || ACCEPT_PCT <= 30)) fail("qsat: no ingress back-pressure was recorded", 0, 0);
        $display("[TB] qsat: queue-full cycles lane0 (rd+wr) and ingress stall cycles recorded: %0d", v);
        fin_perf = 1;
      end else if (nm == "backpressure") begin
        rsp_pct = 15;
        mixed_all(50, 100, N, 2048, (1 << ID_W));
        run_to_idle(4000000);
        fin_perf = 1;
      end else if (nm == "reorder") begin
        mixed_all(50, 100, N, 2048, 4);       // few ids: same-id ordering matters
        run_to_idle(4000000);
        rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_ROB_STALL, v);
        $display("[TB] reorder: ROB stall cycles = %0d, deliveries out of acceptance order = %0d", v, n_reord[0] + n_reord[1] + n_reord[2] + n_reord[3] + n_reord[4]);
        if (RSP_JITTER > 0 && v == 0) fail("reorder: the jittered backend never forced a re-order wait", 0, 0);
        if (ORDER_MODE == 0 && (n_reord[0] + n_reord[1] + n_reord[2] + n_reord[3] + n_reord[4]) != 0) fail("reorder: ORDER_MODE 0 delivered out of order", 0, 0);
        fin_perf = 1;
      end else if (nm == "invalid") begin
        // permission windows: source s may read everywhere, write only in the lower half
        cfg_perm_en = 1'b1; perm_on = 1'b1;
        for (k = 0; k < NUM_WIN; k = k + 1) begin
          w_base[k] = 0; w_last[k] = 0;
          for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin w_rd[k][sx] = 1'b0; w_wr[k][sx] = 1'b0; end
        end
        w_base[0] = 0; w_last[0] = CAP_BYTES - 1;
        w_base[1] = 0; w_last[1] = CAP_BYTES / 2 - 1;
        w_base[2] = 1; w_last[2] = 0;       // empty window
        w_base[3] = 1; w_last[3] = 0;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin w_rd[0][sx] = 1'b1; w_wr[1][sx] = 1'b1; end
        for (k = 0; k < NUM_WIN; k = k + 1) begin
          cfg_win_base[k*ADDR_W +: ADDR_W] = w_base[k]; cfg_win_last[k*ADDR_W +: ADDR_W] = w_last[k];
          for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
            cfg_win_perm[(k*NUM_SRC + sx)*2]     = w_rd[k][sx];
            cfg_win_perm[(k*NUM_SRC + sx)*2 + 1] = w_wr[k][sx];
          end
        end
        mixed_all(50, 100, N, CAP_GRAN, (1 << ID_W));
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_bad[sx] = 30;
        run_to_idle(2000000);
        if (n_stat[`SF_HBM_ST_ERR_ADDR] == 0 || n_stat[`SF_HBM_ST_ERR_ALIGN] == 0 || n_stat[`SF_HBM_ST_ERR_STRB] == 0)
          fail("invalid: not every error class was exercised", n_stat[2], n_stat[3]);
        if (n_stat[`SF_HBM_ST_ERR_PERM] == 0) fail("invalid: no permission error was exercised", 0, 0);
        fin_perf = 1;
      end else if (nm == "be_err") begin
        // poison lane-0 / lane-(last) ranges: BE error, corrected ECC, uncorrectable ECC, data-bus error
        for (lx = 0; lx < NUM_LANES; lx = lx + 1) begin
          p_be_lo[lx] = 0;                              p_be_hi[lx] = 3 * BURST_BYTES - 1;
          p_ce_lo[lx] = 4 * BURST_BYTES;                p_ce_hi[lx] = 7 * BURST_BYTES - 1;
          p_ue_lo[lx] = 8 * BURST_BYTES;                p_ue_hi[lx] = 11 * BURST_BYTES - 1;
          p_db_lo[lx] = 12 * BURST_BYTES;               p_db_hi[lx] = 15 * BURST_BYTES - 1;
          inj_be_lo[lx*LA_W +: LA_W] = p_be_lo[lx]; inj_be_hi[lx*LA_W +: LA_W] = p_be_hi[lx];
          inj_ce_lo[lx*LA_W +: LA_W] = p_ce_lo[lx]; inj_ce_hi[lx*LA_W +: LA_W] = p_ce_hi[lx];
          inj_ue_lo[lx*LA_W +: LA_W] = p_ue_lo[lx]; inj_ue_hi[lx*LA_W +: LA_W] = p_ue_hi[lx];
          inj_db_lo[lx*LA_W +: LA_W] = p_db_lo[lx]; inj_db_hi[lx*LA_W +: LA_W] = p_db_hi[lx];
        end
        // lane-local addresses 0..15 granules of every lane  =  global granules {0 .. 16*NUM_LANES-1} in mode 0 (checked by the mapper anyway)
        mixed_all(50, 100, N, 1024, (1 << ID_W));
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_pat[sx] = PAT_POISON;
        run_to_idle(2000000);
        if (n_stat[`SF_HBM_ST_ERR_BE] == 0 || n_stat[`SF_HBM_ST_ERR_ECC_UE] == 0 || n_stat[`SF_HBM_ST_ERR_DBUS] == 0 || n_stat[`SF_HBM_ST_OK_ECC_CE] == 0)
          fail("be_err: not every backend status was exercised", n_stat[5], n_stat[6]);
        fin_perf = 1;
      end else if (nm == "reset") begin
        mixed_all(60, 100, 100000, 2048, (1 << ID_W));
        for (rep = 0; rep < 3; rep = rep + 1) begin
          repeat (200 + 37 * rep) @(posedge clk);
          // reset in the middle of traffic
          gen_on = 1'b0;
          rst_n = 1'b0;
          repeat (4) @(posedge clk);
          rst_n = 1'b1;
          // everything in flight is gone: the bench forgets it and takes the models' memories as the new truth
          stats_clear_keep;
          repeat (3) @(posedge clk);
          wait_ready;
          // after reset: nothing may come back, counters restart
          repeat (50) @(posedge clk);
          if (!idle_o) fail("reset: scheduler not idle after reset", 0, 0);
          if (err_spurious_o) fail("reset: spurious response after reset", 0, 0);
          ref_resync;
          gen_on = 1'b1;
          for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 100000;
        end
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 300;
        run_to_idle(2000000);
        fin_perf = 0;
      end else if (nm == "refresh") begin
        mixed_all(50, 100, N, 4096, (1 << ID_W));
        run_to_idle(4000000);
        v = 0;
        for (lx = 0; lx < NUM_LANES; lx = lx + 1) begin rdp(`SF_HBM_PG_LANE, lx, `SF_HBM_L_REF_STALL, v2_); v = v + v2_; end
        $display("[TB] refresh: model refreshes lane0=%0d, RTL refresh-stall cycles (all lanes)=%0d", mdl_ref[0], v);
        if (REFRESH_EN != 0 && mdl_ref[0] == 0) fail("refresh: the model never refreshed", 0, 0);
        if (REFRESH_EN != 0 && mdl_ref[0] > 0 && v == 0) begin
          // a stall needs queued work during the refresh; lightly loaded lanes (many lanes per source) legitimately have none
          if (NUM_LANES <= 2) fail("refresh: the scheduler recorded no refresh stall", 0, 0);
          else $display("[TB] refresh: note: no queued work during a refresh in this lightly loaded configuration");
        end
        fin_perf = 1;
      end else if (nm == "outlimit") begin
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          lim_cfg[sx] = 1 + (sx % 3);
          cfg_out_limit[sx*LIM_W +: LIM_W] = lim_cfg[sx];
        end
        mixed_all(50, 100, N, 2048, (1 << ID_W));
        run_to_idle(4000000);
        for (sx = 0; sx < NUM_SRC; sx = sx + 1)
          if (max_out_seen[sx] > lim_cfg[sx]) fail("outlimit: limit exceeded", sx, max_out_seen[sx]);
        fin_perf = 1;
      end else if (nm == "policy") begin
        // the same random workload under every policy and under the parameter settings the study uses; each run must be exact
        for (k = 0; k < 10; k = k + 1) begin
          begin_test("policy");
          case (k)
            0, 1, 2, 3: begin cfg_policy = k[2:0]; end                                   // the four policies, default parameters
            4:          begin cfg_policy = 3'd2; cfg_age_limit = 12'd1024; end            // tuned age limit
            5:          begin cfg_policy = 3'd3; cfg_age_limit = 12'd1024; end
            6:          begin cfg_policy = 3'd1; cfg_bypass_cap = 6'd4; end               // bypass cap
            7:          begin cfg_policy = 3'd2; cfg_bypass_cap = 6'd4; end
            8:          begin cfg_policy = 3'd3; cfg_bypass_cap = 6'd2; cfg_age_limit = 12'd1024; end
            default:    begin cfg_policy = 3'd3; cfg_age_limit = 12'd32; cfg_busy_cyc = 6'd40; end // frequent starvation overrides, long busy hint
          endcase
          mixed_all(50, 100, N, 4096, (1 << ID_W));
          run_to_idle(4000000);
          $display("[TB] policy variant %0d (policy %0d): %0d cycles for %0d requests", k, cfg_policy, t_last - t_first, tot_acc);
          fin_perf = 1;
          end_test("policy", 1);
        end
      end else if (nm == "prefill") begin
        // traffic is offered while the links are still coming up, so every lane starts issuing in the same cycle: several lanes pop an
        // entry of the SAME source at once (per-source issue counts must equal the per-lane counts)
        $display("[TB] ---- test prefill ----");
        gen_on = 1'b0; gen_off; poison_clear;
        for (sx = 0; sx < NUM_LANES; sx = sx + 1) begin inj_hang[sx] = 1'b0; inj_cal_drop[sx] = 1'b0; inj_fatal[sx] = 1'b0; end
        cfg_defaults; apply_plusargs;
        do_reset(6); stats_clear; ref_init;
        bd_init = {NUM_LANES{1'b1}}; #1; bd_init = '0; #1;
        for (sx = 0; sx < NUM_LANES; sx = sx + 1) begin base_rd[sx] = chk_n_rd[sx]; base_wr[sx] = chk_n_wr[sx]; base_bt[sx] = chk_beats[sx]; end
        errors = 0;
        mixed_all(50, 100, N, 4096, (1 << ID_W));
        gen_on = 1'b1;
        run_to_idle(2000000);
        fin_perf = 1;
      end else if (nm == "timeout_flush") begin
        // requests time out while the consumers are not taking responses (so timed-out slots WAIT for delivery), then the controller loses
        // calibration: the flush must free those slots (no late answer can ever come); no zombie may remain
        cfg_timeout = 32'd300;
        mixed_all(50, 30, 100000, 1024, (1 << ID_W));
        repeat (200) @(posedge clk);
        lenient = 1'b1;
        inj_hang = {NUM_LANES{1'b1}};
        rsp_pct = 0;
        repeat (900) @(posedge clk);                       // issued commands time out, their error responses wait for the consumers
        inj_cal_drop = {NUM_LANES{1'b1}};                  // calibration lost: the lane is flushed while those slots are DONE + timed-out
        repeat (60) @(posedge clk);
        inj_cal_drop = '0; inj_hang = '0;
        repeat (100) @(posedge clk);
        gen_on = 1'b0;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 0;
        rsp_pct = 100;
        run_to_idle(400000);
        lenient = 1'b0; cfg_timeout = 32'd0;
        repeat (300) @(posedge clk);
        rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_ZOMBIE_CYC, v); rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_CYCLES, v2_);
        repeat (200) @(posedge clk);
        rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_ZOMBIE_CYC, v1_);
        if (v1_ != v) fail("timeout_flush: zombie slots remain after the flush (never reclaimed)", v, v1_);
        ref_resync;
        gen_on = 1'b1;
        mixed_all(50, 100, 400, 1024, (1 << ID_W));
        run_to_idle(400000);
        fin_perf = 0;
      end else if (nm == "fcfs_saturate") begin
        // the backend hangs for longer than the age counters can count (2^AGE_W - 1 cycles) while dependent entries wait in the queues; after
        // the hang everything must drain (FCFS must not wait for an entry that only another issuable entry can unblock)
        cfg_policy = 3'd0;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          g_pat[sx] = PAT_HOT; g_base[sx] = 0; g_hot[sx] = 4; g_wr_pct[sx] = 50; g_rate[sx] = 100; g_left[sx] = 20 + N / 4; g_idr[sx] = 4;
        end
        repeat (150) @(posedge clk);
        inj_hang = {NUM_LANES{1'b1}};
        repeat ((1 << AGE_W) + 600) @(posedge clk);
        inj_hang = '0;
        run_to_idle(2000000);
        fin_perf = 1;
      end else if (nm == "fcfs_order") begin
        // Strict FCFS on hazard-free traffic: per lane, the commands must cross the SFMC boundary in exactly the order the requests were accepted.
        // (Data and response checks cannot see the issue order; this scenario exists because a mutant that made FCFS pick the younger queue head
        // survived the whole regression.)  Needs: policy 0, no two requests on one granule, no age saturation (waits << 2^AGE_W).
        cfg_policy = 3'd0;
        spn = 1; while (spn < N) spn = spn * 2;
        while (NUM_SRC * spn > CAP_GRAN) spn = spn / 2;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          g_pat[sx] = PAT_UNIQ; g_base[sx] = sx * spn; g_span[sx] = spn; g_ptr[sx] = 0; g_wr_pct[sx] = 50; g_rate[sx] = 100;
          g_left[sx] = (N < spn) ? N : spn; g_idr[sx] = 4;
        end
        of_clear; of_on = 1'b1;
        run_to_idle(4000000);
        of_on = 1'b0;
        for (lx = 0; lx < NUM_LANES; lx = lx + 1) if (of_h[lx] != of_t[lx]) fail("fcfs_order: accepted requests whose command was never seen", lx, of_t[lx] - of_h[lx]);
        $display("[TB] fcfs_order: %0d commands checked against acceptance order, %0d read<->write alternations on the wires", of_n_chk, of_n_dir);
        if (of_n_chk == 0) fail("fcfs_order: nothing was checked", 0, 0);
        if (NUM_SRC > 0 && of_n_dir == 0) fail("fcfs_order: vacuous - no read/write alternation reached the wires", 0, 0);
        fin_perf = 1;
      end else if (nm == "arb_prio") begin
        cfg_arb_mode = 1'b1;
        cfg_arb_prio = 10'b00_00_00_00_11;     // source 0 high priority, the rest lowest
        cfg_arb_age  = 8'd250;                 // aging threshold well above the contention window
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          g_pat[sx] = PAT_LANE0; g_base[sx] = sx * 8; g_span[sx] = 1024; g_wr_pct[sx] = 50; g_rate[sx] = 100; g_left[sx] = N;
        end
        run_to_idle(4000000);
        $display("[TB] arb_prio: end-to-end (offer->response) mean latency src0..4 = %0d %0d %0d %0d %0d, max %0d %0d %0d %0d %0d; ingress stall cycles %0d %0d %0d %0d %0d",
                 e2e_sum[0] / (n_rsp[0] + 1), e2e_sum[1] / (n_rsp[1] + 1), e2e_sum[2] / (n_rsp[2] + 1), e2e_sum[3] / (n_rsp[3] + 1), e2e_sum[4] / (n_rsp[4] + 1),
                 e2e_max[0], e2e_max[1], e2e_max[2], e2e_max[3], e2e_max[4], ing_stall[0], ing_stall[1], ing_stall[2], ing_stall[3], ing_stall[4]);
        // the priority is only observable when lane arbitration is the bottleneck: lane capacity (queues + in-flight) below the sources' outstanding window
        rdp(`SF_HBM_PG_SRC, 0, `SF_HBM_S_ARB_LOSS, v); rdp(`SF_HBM_PG_SRC, 1, `SF_HBM_S_ARB_LOSS, v2_);
        $display("[TB] arb_prio: arbitration losses src0=%0d src1=%0d (lane capacity %0d vs window %0d)", v, v2_, RQ_DEPTH + WQ_DEPTH + LANE_OUT, NUM_SRC * OUT_PER_SRC);
        if ((RQ_DEPTH + WQ_DEPTH + LANE_OUT) < NUM_SRC * OUT_PER_SRC) begin
          if (NUM_SRC > 1 && v * 4 > v2_) fail("arb_prio: the high-priority source lost too many arbitrations", v, v2_);
          // the priority acts at the lane ingress, i.e. on the wait BEFORE acceptance: compare end-to-end (offer -> response) latency
          if (NUM_SRC > 1 && (e2e_sum[0] / (n_rsp[0] + 1)) >= (e2e_sum[1] / (n_rsp[1] + 1))) fail("arb_prio: the high-priority source was not faster (e2e)", e2e_sum[0] / (n_rsp[0] + 1), e2e_sum[1] / (n_rsp[1] + 1));
        end else $display("[TB] arb_prio: note: the lane queues are not the bottleneck in this configuration (outstanding window is), priority effect not asserted");
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) if (n_rsp[sx] != N) fail("arb_prio: a source was starved", sx, n_rsp[sx]);
        fin_perf = 1;
      end else if (nm == "timeout") begin
        // hang the backend of every lane, let requests time out, release, check recovery
        cfg_timeout = 32'd1500;                 // well above the backend latency of a saturated single lane
        mixed_all(50, 40, 100000, 1024, (1 << ID_W));
        repeat (300) @(posedge clk);
        lenient = 1'b1;
        inj_hang = {NUM_LANES{1'b1}};
        repeat (3500) @(posedge clk);
        gen_on = 1'b0;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 0;
        // requests still queued at the hung backend cannot complete: they are only answered once the backend returns
        inj_hang = '0;
        run_to_idle(200000);
        if (n_stat[`SF_HBM_ST_ERR_TIMEOUT] == 0) fail("timeout: no request timed out", 0, 0);
        // zombie slots are reclaimed by the late responses
        repeat (200) @(posedge clk);
        rdp(`SF_HBM_PG_GLOBAL, 0, `SF_HBM_G_TIMEOUT, v);
        if (v == 0) fail("timeout: RTL timeout counter is zero", 0, 0);
        lenient = 1'b0;
        cfg_timeout = 32'd0;
        ref_resync;
        // recovery: full exactness again, and every slot must be usable (zombies reclaimed)
        gen_on = 1'b1;
        mixed_all(50, 100, 600, 1024, (1 << ID_W));
        run_to_idle(400000);
        fin_perf = 0;
      end else if (nm == "fault") begin
        // controller loses calibration mid-traffic: in-flight transactions fail, the link resets, traffic resumes
        mixed_all(50, 100, 100000, 1024, (1 << ID_W));
        repeat (300) @(posedge clk);
        lenient = 1'b1;
        inj_cal_drop = {NUM_LANES{1'b1}};
        repeat (60) @(posedge clk);
        inj_cal_drop = '0;
        repeat (400) @(posedge clk);
        gen_on = 1'b0;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 0;
        run_to_idle(400000);
        rdp(`SF_HBM_PG_LANE, 0, `SF_HBM_L_LINK_RST, v);
        if (v == 0) fail("fault: no link reset recorded", 0, 0);
        if (n_stat[`SF_HBM_ST_ERR_FLUSH] == 0) $display("[TB] fault: note: no in-flight request was caught by the flush");
        lenient = 1'b0;
        ref_resync;
        gen_on = 1'b1;
        mixed_all(50, 100, 600, 1024, (1 << ID_W));
        run_to_idle(400000);
        fin_perf = 0;
      end else if (nm == "fatal") begin
        mixed_all(50, 100, 100000, 1024, (1 << ID_W));
        repeat (300) @(posedge clk);
        lenient = 1'b1;
        inj_fatal = {NUM_LANES{1'b1}};
        repeat (30) @(posedge clk);
        inj_fatal = '0;
        repeat (300) @(posedge clk);
        gen_on = 1'b0;
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 0;
        run_to_idle(400000);
        lenient = 1'b0;
        ref_resync;
        gen_on = 1'b1;
        mixed_all(50, 100, 400, 1024, (1 << ID_W));
        run_to_idle(400000);
        fin_perf = 0;

      end else if (nm == "bench_seq_rd" || nm == "bench_seq_wr" || nm == "bench_seq_mix" || nm == "bench_seq_rd_aligned") begin
        // 'friendly' layout: the five streams start in five different banks (staggered); 'aligned': power-of-two aligned buffers that all start in bank 0
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          g_pat[sx] = PAT_SEQ; g_span[sx] = 4096; g_stride[sx] = 1; g_rate[sx] = 100; g_left[sx] = N;
          if (nm == "bench_seq_rd_aligned") g_base[sx] = sx * 8192 % CAP_GRAN;
          else begin t_inv(0, (3 * sx) % (NBG * NBANK), 8 * sx, 0); g_base[sx] = inv_addr / BURST_BYTES; end
          g_wr_pct[sx] = (nm == "bench_seq_wr") ? 100 : (nm == "bench_seq_mix") ? 30 : 0; g_fullstrb[sx] = 100;
        end
        run_to_idle(8000000); bench_report(nm);
      end else if (nm == "bench_rand_rd" || nm == "bench_rand_mix") begin
        mixed_all((nm == "bench_rand_rd") ? 0 : 30, 100, N, CAP_GRAN, (1 << ID_W));
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_fullstrb[sx] = 100;
        run_to_idle(8000000); bench_report(nm);
      end else if (nm == "bench_rowmix" || nm == "bench_rowwalk" || nm == "bench_hotbank") begin
        for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
          g_rate[sx] = 100; g_left[sx] = N; g_wr_pct[sx] = 25; g_fullstrb[sx] = 100;
          if (nm == "bench_rowmix")       begin g_pat[sx] = PAT_ROWMIX;  g_bank[sx] = sx;  g_nrows[sx] = 3; g_base[sx] = sx * 7; end
          else if (nm == "bench_rowwalk") begin g_pat[sx] = PAT_ROWWALK; g_bank[sx] = sx;  g_base[sx] = sx * 5; end
          else                            begin g_pat[sx] = PAT_ROWMIX;  g_bank[sx] = 0;   g_nrows[sx] = 4; g_base[sx] = 0; end
        end
        run_to_idle(8000000); bench_report(nm);
      end else if (nm == "bench_vector") begin
        // vector engine: unit-stride stream (src 1), strided (src 2), gather (src 4)
        g_pat[1] = PAT_SEQ;    g_base[1] = 0;     g_span[1] = 8192; g_stride[1] = 1;  g_wr_pct[1] = 30; g_rate[1] = 100; g_left[1] = N; g_fullstrb[1] = 100;
        g_pat[2] = PAT_SEQ;    g_base[2] = 16384; g_span[2] = 8192; g_stride[2] = 17; g_wr_pct[2] = 30; g_rate[2] = 100; g_left[2] = N; g_fullstrb[2] = 100;
        g_pat[4] = PAT_GATHER; g_base[4] = 32768; g_span[4] = 16384; g_wr_pct[4] = 0;  g_rate[4] = 100; g_left[4] = N;
        run_to_idle(8000000); bench_report(nm);
      end else if (nm == "bench_dma_copy") begin
        // StreamDMA: read stream + write stream of the same chunks (src 2), a second channel on src 4
        g_pat[2] = PAT_COPY; g_base[2] = 0;     g_dst[2] = 20000; g_span[2] = 4096; g_rate[2] = 100; g_left[2] = N; g_fullstrb[2] = 100;
        g_pat[4] = PAT_COPY; g_base[4] = 8192;  g_dst[4] = 30000; g_span[4] = 4096; g_rate[4] = 100; g_left[4] = N; g_fullstrb[4] = 100;
        run_to_idle(8000000); bench_report(nm);
      end else if (nm == "bench_tensor_alone" || nm == "bench_tensor" || nm == "bench_ctrl_probe" || nm == "bench_system") begin
        // background: vector stream (1), DMA copy (2), cloud random mix (4); control probes (3); tensor tile flow (0)
        if (nm != "bench_tensor_alone") begin
          g_pat[1] = PAT_SEQ;  g_base[1] = 40000 % CAP_GRAN; g_span[1] = 8192; g_stride[1] = 1; g_wr_pct[1] = 30; g_rate[1] = 100; g_left[1] = 1000000; g_fullstrb[1] = 100;
          g_pat[2] = PAT_COPY; g_base[2] = 0; g_dst[2] = 20000; g_span[2] = 4096; g_rate[2] = 100; g_left[2] = 1000000; g_fullstrb[2] = 100;
          g_pat[4] = PAT_RAND; g_base[4] = 0; g_span[4] = CAP_GRAN; g_wr_pct[4] = 40; g_rate[4] = 100; g_left[4] = 1000000; g_fullstrb[4] = 100;
        end
        if (nm == "bench_ctrl_probe" || nm == "bench_system") begin
          g_pat[3] = PAT_RAND; g_base[3] = 0; g_span[3] = CAP_GRAN; g_wr_pct[3] = 10; g_rate[3] = 3; g_left[3] = 1000000; g_idr[3] = 2;
        end
        if (nm != "bench_ctrl_probe") begin
          if (!$value$plusargs("TCOMP=%d", pa_v)) pa_v = 512;
          tn_start(24, 128, pa_v, 16);
        end else begin
          g_pat[0] = PAT_SEQ; g_base[0] = 0; g_span[0] = 8192; g_stride[0] = 1; g_wr_pct[0] = 20; g_rate[0] = 100; g_left[0] = 1000000; g_fullstrb[0] = 100;
        end
        if (nm == "bench_ctrl_probe") begin
          // fixed measurement window instead of a request count: run the probes for N * 40 cycles
          repeat (N * 40) @(posedge clk);
          for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 0;
          run_to_idle(2000000);
        end else if (nm == "bench_system") begin
          // run until the tensor flow has finished, then stop the open-ended background sources
          while (tn_active) @(posedge clk);
          for (sx = 0; sx < NUM_SRC; sx = sx + 1) if (sx != 0) g_left[sx] = 0;
          run_to_idle(2000000);
        end else begin
          while (tn_active) @(posedge clk);
          for (sx = 0; sx < NUM_SRC; sx = sx + 1) if (sx != 0) g_left[sx] = 0;
          run_to_idle(2000000);
        end
        bench_report(nm);
      end else begin
        $display("[TB] unknown test %0s", nm);
        total_errors = total_errors + 1;
      end
      if (nm != "policy") end_test(nm, fin_perf);
    end
  endtask

  // clear the bench's request bookkeeping but keep the ref memory (reset scenario)
  task stats_clear_keep;
    integer sx, hx;
    begin
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) begin
        n_out[sx] = 0; r_head[sx] = 0; r_tail[sx] = 0; p_v[sx] = 1'b0; rw_v[sx] = 1'b0;
      end
      for (hx = 0; hx < NUM_SRC*REC; hx = hx + 1) r_alive[hx] = 1'b0;
      for (sx = 0; sx < NUM_SRC; sx = sx + 1) g_left[sx] = 0;
      s_req_valid = '0;
    end
  endtask

  // ------------------------------------------------------------------ main
  localparam int NTESTS = 23;
  integer ti_;
  reg [255:0] cur_name;
  function [255:0] test_by_index(input integer i);
    case (i)
      0: test_by_index = "smoke";        1: test_by_index = "seq";          2: test_by_index = "rand_mixed";
      3: test_by_index = "hazard";       4: test_by_index = "contend";      5: test_by_index = "multi_ch";
      6: test_by_index = "qsat";         7: test_by_index = "backpressure"; 8: test_by_index = "reorder";
      9: test_by_index = "invalid";     10: test_by_index = "be_err";      11: test_by_index = "reset";
     12: test_by_index = "refresh";     13: test_by_index = "outlimit";    14: test_by_index = "policy";
     15: test_by_index = "arb_prio";    16: test_by_index = "timeout";     17: test_by_index = "fault";
     18: test_by_index = "fatal";       19: test_by_index = "prefill";     20: test_by_index = "timeout_flush";
     21: test_by_index = "fcfs_saturate";
     default: test_by_index = "fcfs_order";
    endcase
  endfunction
  initial begin
    errors = 0; total_errors = 0; cyc = 0; checks_image = 0; checks_perf = 0; trace_on = 1'b0;
    if ($test$plusargs("TRACE")) trace_on = 1'b1;
    rst_n = 1'b0; gen_on = 1'b0; lenient = 1'b0; of_on = 1'b0; of_clear;
    s_req_valid = '0; s_req_we = '0; s_req_id = '0; s_req_addr = '0; s_req_wdata = '0; s_req_wstrb = '0; s_rsp_ready = '0;
    inj_hang = '0; inj_cal_drop = '0; inj_fatal = '0; bd_addr = '0; bd_init = '0;
    inj_be_lo = '0; inj_be_hi = '0; inj_ce_lo = '0; inj_ce_hi = '0; inj_ue_lo = '0; inj_ue_hi = '0; inj_db_lo = '0; inj_db_hi = '0;
    mc_busy_unused = 1'b0;
    gen_off; cfg_defaults; stats_clear; poison_clear;
    N = 400; SEED_V = 1;
    if ($value$plusargs("N=%d", N)) ;
    if ($value$plusargs("SEED=%d", SEED_V)) ;
    rng_s = 32'h1234_5678 ^ (SEED_V * 32'h9E37_79B1);
    if ($value$plusargs("TEST=%s", tname)) ; else tname = "all";
    repeat (3) @(posedge clk);
    for (ti_ = 0; ti_ < ((tname == "all") ? NTESTS : 1); ti_ = ti_ + 1) begin
      cur_name = (tname == "all") ? test_by_index(ti_) : tname;
      run_scenario(cur_name);
    end
    if (total_errors == 0) $display("RESULT: ALL PASS");
    else $display("RESULT: ALL FAIL errors=%0d", total_errors);
    if (total_errors != 0) $fatal(1, "testbench failed");
    $finish;
  end

endmodule
