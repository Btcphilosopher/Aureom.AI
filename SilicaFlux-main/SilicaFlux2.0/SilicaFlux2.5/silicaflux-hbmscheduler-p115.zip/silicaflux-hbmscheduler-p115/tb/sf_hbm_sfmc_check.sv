// =============================================================================
// SilicaFlux HBMScheduler (P115) :: sf_hbm_sfmc_check   (simulation only)
//
// Passive SFMC protocol checker for ONE lane, placed on the wires between the
// scheduler's backend adapter and the controller (model).  It encodes the rules
// of the MemoryBridge SFMC contract (MC_INTERFACE.md C1..C8, C10) that concern
// the MASTER (the adapter) and the response channels, plus the HBMScheduler's
// own promises (outstanding limit, one cmd per tag, no issue before ready).
// It is independent of the adapter RTL: it only looks at wires.
//
//   C1/C2/C3  a presented command / write beat keeps valid + payload until taken
//   C4        a tag is never re-issued while live (issued, not yet completed)
//   C5        every read tag returns exactly BURST_LEN beats, rd_last on the last
//   C6        every write tag returns exactly one response
//   C7        write data: BURST_LEN beats per write, wd_last on the last, data
//             never presented before its command was accepted
//   C8        no X on valids
//   -         no command while mc_rst_n = 0 or mc_init_done = 0
//   -         live transactions <= LANE_OUT
//   -         mc_rd_ready == 1 and mc_wr_ready == 1 whenever the link is up
// Responses are only checked while a transaction is live: a response for a dead
// tag is a controller-side violation and is counted separately (resp_viol_o).
// =============================================================================
`default_nettype none

module sf_hbm_sfmc_check #(
  parameter int TAG_W     = 6,
  parameter int LA_W      = 24,
  parameter int DATA_W    = 128,
  parameter int BURST_LEN = 2,
  parameter int LANE_OUT  = 8,
  parameter int LANE_ID   = 0,
  localparam int BSTRB_W  = DATA_W / 8
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 mc_rst_n,
  input  wire logic                 mc_init_done,
  input  wire logic                 mc_fatal,
  input  wire logic                 mc_cmd_valid,
  input  wire logic                 mc_cmd_ready,
  input  wire logic                 mc_cmd_write,
  input  wire logic [LA_W-1:0]      mc_cmd_addr,
  input  wire logic [7:0]           mc_cmd_len,
  input  wire logic [TAG_W-1:0]     mc_cmd_tag,
  input  wire logic                 mc_wd_valid,
  input  wire logic                 mc_wd_ready,
  input  wire logic [DATA_W-1:0]    mc_wd_data,
  input  wire logic [BSTRB_W-1:0]   mc_wd_strb,
  input  wire logic                 mc_wd_last,
  input  wire logic                 mc_rd_valid,
  input  wire logic                 mc_rd_ready,
  input  wire logic [TAG_W-1:0]     mc_rd_tag,
  input  wire logic                 mc_rd_last,
  input  wire logic                 mc_wr_valid,
  input  wire logic                 mc_wr_ready,
  input  wire logic [TAG_W-1:0]     mc_wr_tag,
  output integer                    viol_o,
  output integer                    resp_viol_o,
  output integer                    n_cmd_rd_o,
  output integer                    n_cmd_wr_o,
  output integer                    n_beats_o
);

  localparam int NTAG = (1 << TAG_W);

  reg              live    [0:NTAG-1];
  reg              live_wr [0:NTAG-1];
  integer          beats   [0:NTAG-1];
  integer          n_live;
  integer          wr_cmds_acc, wr_lines_done, wd_beat;
  reg              pc_v;                      // previous cycle: command was valid and stalled
  reg [LA_W-1:0]   pc_a;
  reg [TAG_W-1:0]  pc_t;
  reg              pc_w;
  reg              pw_v;
  reg [DATA_W-1:0] pw_d;
  reg [BSTRB_W-1:0] pw_s;
  reg              pw_l;
  integer          i;

  task viol(input [8*40-1:0] what);
    begin
      viol_o = viol_o + 1;
      if (viol_o <= 5) $display("[SFMC-CHK lane %0d] t=%0t VIOLATION: %0s", LANE_ID, $time, what);
    end
  endtask

  initial begin
    viol_o = 0; resp_viol_o = 0; n_cmd_rd_o = 0; n_cmd_wr_o = 0; n_beats_o = 0;
    n_live = 0; wr_cmds_acc = 0; wr_lines_done = 0; wd_beat = 0;
    pc_v = 1'b0; pw_v = 1'b0;
    for (i = 0; i < NTAG; i = i + 1) begin live[i] = 1'b0; live_wr[i] = 1'b0; beats[i] = 0; end
  end

  always @(posedge clk) begin
    if (!rst_n || !mc_rst_n) begin
      // controller reset: everything is forgotten
      n_live = 0; wr_cmds_acc = 0; wr_lines_done = 0; wd_beat = 0; pc_v = 1'b0; pw_v = 1'b0;
      for (i = 0; i < NTAG; i = i + 1) begin live[i] = 1'b0; beats[i] = 0; end
    end else begin
      // ---- C8
      if ((^mc_cmd_valid) === 1'bx || (^mc_wd_valid) === 1'bx || (^mc_rd_valid) === 1'bx || (^mc_wr_valid) === 1'bx)
        viol("X on a valid");
      // ---- ready rules
      if (mc_init_done && (!mc_rd_ready || !mc_wr_ready)) viol("response ready not held 1");
      // ---- command channel
      // C1 is waived in a cycle in which the controller reports a fault (init_done low / fatal): the lane is being flushed
      if (pc_v && mc_init_done && !mc_fatal && !(mc_cmd_valid && mc_cmd_write == pc_w && mc_cmd_addr == pc_a && mc_cmd_tag == pc_t))
        viol("C1 command changed/dropped under stall");
      if (mc_cmd_valid && (!mc_init_done || mc_fatal)) viol("command while controller not initialised / fatal");
      if (mc_cmd_valid && mc_cmd_ready) begin
        if (mc_cmd_len != BURST_LEN - 1) viol("cmd len != BURST_LEN-1");
        if (live[mc_cmd_tag]) viol("C4 tag re-issued while live");
        live[mc_cmd_tag] = 1'b1; live_wr[mc_cmd_tag] = mc_cmd_write; beats[mc_cmd_tag] = 0;
        n_live = n_live + 1;
        if (n_live > LANE_OUT) viol("more than LANE_OUT live transactions");
        if (mc_cmd_write) begin wr_cmds_acc = wr_cmds_acc + 1; n_cmd_wr_o = n_cmd_wr_o + 1; end
        else n_cmd_rd_o = n_cmd_rd_o + 1;
        pc_v = 1'b0;
      end else begin
        pc_v = mc_cmd_valid; pc_a = mc_cmd_addr; pc_t = mc_cmd_tag; pc_w = mc_cmd_write;
      end
      // ---- write data channel
      if (pw_v && mc_init_done && !mc_fatal && !(mc_wd_valid && mc_wd_data == pw_d && mc_wd_strb == pw_s && mc_wd_last == pw_l))
        viol("C2 write beat changed/dropped under stall");
      if (mc_wd_valid && (!mc_init_done || mc_fatal)) viol("write data while controller not initialised / fatal");
      if (mc_wd_valid && wr_lines_done >= wr_cmds_acc) begin
        // data presented for a write whose command was not accepted yet (C7) -- the same-cycle accept is allowed
        if (!(mc_cmd_valid && mc_cmd_ready && mc_cmd_write && wr_lines_done == wr_cmds_acc - 1)) viol("C7 data before its command");
      end
      if (mc_wd_valid && mc_wd_ready) begin
        n_beats_o = n_beats_o + 1;
        if (mc_wd_last != (wd_beat == BURST_LEN - 1)) viol("C7 wd_last framing");
        if (wd_beat == BURST_LEN - 1) begin wd_beat = 0; wr_lines_done = wr_lines_done + 1; end
        else wd_beat = wd_beat + 1;
        pw_v = 1'b0;
      end else begin
        pw_v = mc_wd_valid; pw_d = mc_wd_data; pw_s = mc_wd_strb; pw_l = mc_wd_last;
      end
      // ---- read data channel
      if (mc_rd_valid && mc_rd_ready) begin
        n_beats_o = n_beats_o + 1;
        if (!live[mc_rd_tag] || live_wr[mc_rd_tag]) resp_viol_o = resp_viol_o + 1;
        else begin
          beats[mc_rd_tag] = beats[mc_rd_tag] + 1;
          if (mc_rd_last != (beats[mc_rd_tag] == BURST_LEN)) viol("C5 rd_last framing");
          if (beats[mc_rd_tag] > BURST_LEN) viol("C5 too many beats");
          if (mc_rd_last) begin live[mc_rd_tag] = 1'b0; n_live = n_live - 1; end
        end
      end
      // ---- write response channel
      if (mc_wr_valid && mc_wr_ready) begin
        if (!live[mc_wr_tag] || !live_wr[mc_wr_tag]) resp_viol_o = resp_viol_o + 1;
        else begin live[mc_wr_tag] = 1'b0; n_live = n_live - 1; end
      end
    end
  end

endmodule
`default_nettype wire
