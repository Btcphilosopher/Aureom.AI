// =============================================================================
// SilicaFlux HBMScheduler (P115) :: tb_addr_map     (unit bench, address map)
//
// Compares sf_hbm_address_map (bit slices) with an independent integer
// (div / mod) implementation of the documented field order, for EVERY address of
// the mapped window (plus out-of-window and misaligned probes), and checks that
// the map is a BIJECTION: no two granules of the window share a (lane, lane-local
// address) pair, and every lane-local address is inside the lane's memory.
// Parameters (-G): PROFILE NUM_CH NUM_PC BURST_BYTES BG_W BANK_W ROW_W COL_W MAP_MODE.
// =============================================================================
module tb_addr_map #(
  parameter int PROFILE     = 0,
  parameter int ADDR_W      = 32,
  parameter int NUM_CH      = 2,
  parameter int NUM_PC      = 1,
  parameter int BURST_BYTES = 32,
  parameter int BG_W        = 2,
  parameter int BANK_W      = 2,
  parameter int ROW_W       = 6,
  parameter int COL_W       = 5,
  parameter int MAP_MODE    = 0,
  localparam int OFF_W   = $clog2(BURST_BYTES),
  localparam int LANES   = NUM_CH * NUM_PC,
  localparam int LANE_IW = (LANES > 1) ? $clog2(LANES) : 1,
  localparam int LA_W    = OFF_W + COL_W + BG_W + BANK_W + ROW_W,
  localparam int GRAN    = LANES * (1 << (COL_W + BG_W + BANK_W + ROW_W)),
  localparam int LGRAN   = (1 << (COL_W + BG_W + BANK_W + ROW_W))
) ();

  logic [ADDR_W-1:0]   addr;
  logic [LANE_IW-1:0]  lane;
  logic [LA_W-1:0]     la;
  logic [BG_W-1:0]     bg;
  logic [BANK_W-1:0]   bank;
  logic [ROW_W-1:0]    row;
  logic [COL_W-1:0]    col;
  logic                inr, aln;

  sf_hbm_address_map #(
    .PROFILE(PROFILE), .ADDR_W(ADDR_W), .NUM_CH(NUM_CH), .NUM_PC(NUM_PC), .BURST_BYTES(BURST_BYTES),
    .BG_W(BG_W), .BANK_W(BANK_W), .ROW_W(ROW_W), .COL_W(COL_W), .MAP_MODE(MAP_MODE)
  ) dut (.addr_i(addr), .lane_o(lane), .la_o(la), .bg_o(bg), .bank_o(bank), .row_o(row), .col_o(col),
         .in_range_o(inr), .aligned_o(aln));

  reg seen [0:GRAN-1];
  integer errors, checks, g, boff, e_lane, e_la, e_ch, e_pc, e_col, e_bg, e_bank, e_row, rest, probe;
  reg e_inr;

  task ref_map(input integer a);
    integer q;
    begin
      boff = a % BURST_BYTES; q = a / BURST_BYTES;
      e_ch = 0; e_pc = 0; e_col = 0; e_bg = 0; e_bank = 0; e_row = 0;
      if (MAP_MODE == 1) begin
        e_ch = q % NUM_CH; q = q / NUM_CH; e_pc = q % NUM_PC; q = q / NUM_PC;
        e_bg = q % (1 << BG_W); q = q / (1 << BG_W); e_bank = q % (1 << BANK_W); q = q / (1 << BANK_W);
        e_col = q % (1 << COL_W); q = q / (1 << COL_W); e_row = q % (1 << ROW_W); q = q / (1 << ROW_W);
      end else if (MAP_MODE == 2) begin
        e_col = q % (1 << COL_W); q = q / (1 << COL_W);
        e_ch = q % NUM_CH; q = q / NUM_CH; e_pc = q % NUM_PC; q = q / NUM_PC;
        e_bg = q % (1 << BG_W); q = q / (1 << BG_W); e_bank = q % (1 << BANK_W); q = q / (1 << BANK_W);
        e_row = q % (1 << ROW_W); q = q / (1 << ROW_W);
      end else begin
        e_ch = q % NUM_CH; q = q / NUM_CH; e_pc = q % NUM_PC; q = q / NUM_PC;
        e_col = q % (1 << COL_W); q = q / (1 << COL_W); e_bg = q % (1 << BG_W); q = q / (1 << BG_W);
        e_bank = q % (1 << BANK_W); q = q / (1 << BANK_W); e_row = q % (1 << ROW_W); q = q / (1 << ROW_W);
      end
      e_inr = (q == 0);
      if (MAP_MODE == 3) begin
        e_bank = e_bank ^ (e_row % (1 << BANK_W));
        e_bg   = e_bg   ^ ((e_row / (1 << BANK_W)) % (1 << BG_W));
      end
      e_lane = e_ch * NUM_PC + e_pc;
      e_la   = ((((e_row * (1 << BG_W) + e_bg) * (1 << BANK_W) + e_bank) * (1 << COL_W) + e_col) * BURST_BYTES) + boff;
    end
  endtask

  task check(input integer a);
    begin
      addr = a; #1;
      ref_map(a);
      checks = checks + 1;
      if (inr !== e_inr) begin errors = errors + 1; if (errors < 8) $display("in_range mismatch at %0h", a); end
      if (aln !== ((a % BURST_BYTES) == 0)) begin errors = errors + 1; if (errors < 8) $display("aligned mismatch at %0h", a); end
      if (e_inr) begin
        if (lane !== e_lane[LANE_IW-1:0]) begin errors = errors + 1; if (errors < 8) $display("lane mismatch at %0h: %0d vs %0d", a, lane, e_lane); end
        if (la !== e_la[LA_W-1:0])        begin errors = errors + 1; if (errors < 8) $display("la mismatch at %0h: %0h vs %0h", a, la, e_la); end
        if (row !== e_row[ROW_W-1:0] || bg !== e_bg[BG_W-1:0] || bank !== e_bank[BANK_W-1:0] || col !== e_col[COL_W-1:0]) begin
          errors = errors + 1; if (errors < 8) $display("field mismatch at %0h", a);
        end
      end
    end
  endtask

  initial begin
    errors = 0; checks = 0;
    for (g = 0; g < GRAN; g = g + 1) seen[g] = 1'b0;
    // every granule of the window: field-exact + bijective (lane, la)
    for (g = 0; g < GRAN; g = g + 1) begin
      check(g * BURST_BYTES);
      if (e_inr) begin
        if (seen[lane * LGRAN + (la >> OFF_W)]) begin errors = errors + 1; if (errors < 8) $display("collision at granule %0d", g); end
        seen[lane * LGRAN + (la >> OFF_W)] = 1'b1;
      end
    end
    for (g = 0; g < GRAN; g = g + 1) if (!seen[g]) begin errors = errors + 1; if (errors < 8) $display("unmapped lane-local granule %0d", g); end
    // byte offsets inside a granule are preserved and flagged as unaligned
    for (probe = 1; probe < BURST_BYTES; probe = probe + 1) check(7 * BURST_BYTES + probe);
    // out of the window
    check(GRAN * BURST_BYTES);
    check(GRAN * BURST_BYTES + BURST_BYTES);
    check(GRAN * BURST_BYTES * 2 + 5 * BURST_BYTES);
    if (errors == 0) $display("RESULT: PASS tb_addr_map profile=%0d ch=%0d pc=%0d mode=%0d granules=%0d checks=%0d", PROFILE, NUM_CH, NUM_PC, MAP_MODE, GRAN, checks);
    else $display("RESULT: FAIL tb_addr_map errors=%0d", errors);
    if (errors != 0) $fatal(1, "tb_addr_map failed");
    $finish;
  end
endmodule
