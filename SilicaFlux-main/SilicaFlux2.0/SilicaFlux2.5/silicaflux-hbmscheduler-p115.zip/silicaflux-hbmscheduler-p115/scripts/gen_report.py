#!/usr/bin/env python3
"""Turn run_bench.py JSON files into the markdown tables of the benchmark reports.

Every number is derived from raw counts recorded in the JSON (RTL performance
counters + bench-side measurements); nothing is estimated here.  Aggregation over
seeds: mean, with min..max shown where the workload is randomised.

  gen_report.py baseline  FILE.json  --out reports/BASELINE_FCFS.md
  gen_report.py compare   BASE.json  POL1.json [POL2.json ...] --out reports/BENCHMARKS.md
  gen_report.py scaling   FILE.json [FILE.json ...] --out reports/SCALING.md
"""
import argparse, json, os, statistics, sys
from collections import defaultdict

POLNAME = {0: "FCFS", 1: "RDPRIO", 2: "FRFCFS", 3: "BANKAWARE"}


def load(paths, seeds=None):
    recs, metas = [], []
    for p in paths:
        d = json.load(open(p))
        metas.append(d["meta"])
        recs += [r for r in d["records"] if r["pass"] and "result" in r and (not seeds or r["seed"] in seeds)]
        bad = [r for r in d["records"] if not r["pass"]]
        if bad:
            print(f"WARNING: {len(bad)} failed records in {p} are excluded", file=sys.stderr)
    return recs, metas


def derive(r):
    x = r["result"]
    lanes = x["lanes_detail"]
    cyc = x["cycles"]
    nl = len(lanes)
    hit = sum(l["be_hit"] for l in lanes)
    miss = sum(l["be_miss"] for l in lanes)
    conf = sum(l["be_conf"] for l in lanes)
    tot = hit + miss + conf
    qw_c = sum(l["qw_cnt"] for l in lanes)
    d = {
        "bpc": x["bytes_per_cycle"], "eff": x["efficiency"] * 100, "rd_bpc": x["rd_bpc"], "wr_bpc": x["wr_bpc"],
        "lat_mean": x["lat_mean"], "lat_p50": x["lat_p50"], "lat_p99": x["lat_p99"], "lat_p999": x["lat_p999"],
        "util": 100 * sum(l["util"] for l in lanes) / nl,
        "util_min": 100 * min(l["util"] for l in lanes), "util_max": 100 * max(l["util"] for l in lanes),
        "hit": 100 * hit / tot if tot else 0.0, "conf": 100 * conf / tot if tot else 0.0, "miss": 100 * miss / tot if tot else 0.0,
        "shadow_hit": 100 * sum(l["shadow_hit"] for l in lanes) / max(1, sum(l["shadow_hit"] + l["shadow_miss"] + l["shadow_conf"] for l in lanes)),
        "qw": sum(l["qw_sum"] for l in lanes) / qw_c if qw_c else 0.0, "qw_max": max(l["qw_max"] for l in lanes),
        "ref": 100 * sum(l["ref_stall"] for l in lanes) / (cyc * nl),
        "turn": sum(l["turn"] for l in lanes) / max(1, qw_c), "bank_conf": sum(l["bank_conf"] for l in lanes),
        "be_stall": 100 * sum(l["be_stall"] for l in lanes) / (cyc * nl), "haz": 100 * sum(l["haz_stall"] for l in lanes) / (cyc * nl),
        "age_ovr": sum(l["age_ovr"] for l in lanes), "drain": 100 * sum(l["drain_cyc"] for l in lanes) / (cyc * nl),
        "rq_occ": sum(l["rq_occ_sum"] for l in lanes) / (cyc * nl), "wq_occ": sum(l["wq_occ_sum"] for l in lanes) / (cyc * nl),
        "qfull": sum(l["qfull_rd"] + l["qfull_wr"] for l in lanes), "rob": x["rob_stall_cycles"], "cycles": cyc,
        "requests": x["requests"], "src": x["src"], "tensor": x["tensor"],
        "reordered": sum(s["reordered"] for s in x["src"]),
    }
    return d


def agg(recs):
    """(label, workload, policy) -> {metric: (mean, min, max)} over seeds"""
    groups = defaultdict(list)
    for r in recs:
        groups[(r["config_label"], r["workload"], r["policy"])].append(derive(r))
    out = {}
    for k, ds in groups.items():
        m = {}
        for key in ds[0]:
            if isinstance(ds[0][key], (int, float)):
                vals = [d[key] for d in ds]
                m[key] = (statistics.fmean(vals), min(vals), max(vals))
        m["_n"] = len(ds)
        m["_src"] = [d["src"] for d in ds]
        m["_tensor"] = [d["tensor"] for d in ds]
        out[k] = m
    return out


def f(t, nd=2, rng=False):
    mean, lo, hi = t
    if rng and abs(hi - lo) > 1e-9:
        return f"{mean:.{nd}f} ({lo:.{nd}f}..{hi:.{nd}f})"
    return f"{mean:.{nd}f}"


def meta_block(metas):
    lines = []
    for m in metas:
        lines.append(f"* run `{m['tag']}` (config `{m['label']}`, policies {m['policies']}, seeds {m['seeds']}, N={m['n']} requests / source), "
                     f"binary sha256 `{m['exe_sha256'][:16]}`, bench sha256 `{m['tb_sha256'][:16]}`, created {m['created']}")
    return "\n".join(lines)


def table(rows, header):
    s = "| " + " | ".join(header) + " |\n|" + "|".join("---" for _ in header) + "|\n"
    for r in rows:
        s += "| " + " | ".join(str(c) for c in r) + " |\n"
    return s


def cmd_baseline(a):
    recs, metas = load(a.files, a.seeds)
    g = agg(recs)
    label = metas[0]["label"]
    wls = [w for w in dict.fromkeys(r["workload"] for r in recs)]
    rows = []
    for w in wls:
        m = g.get((label, w, 0))
        if not m:
            continue
        rows.append([w, f(m["bpc"], 2, True), f(m["eff"], 1), f(m["util"], 1), f(m["lat_mean"], 0), f(m["lat_p99"], 0, True),
                     f(m["hit"], 1), f(m["conf"], 1), f(m["qw"], 0), f(m["turn"], 2), f(m["ref"], 1), f(m["rob"], 0)])
    hdr = ["workload", "useful B/cycle", "% of peak", "lane util %", "mean lat", "p99 lat", "row hit %", "row conflict %", "mean q-wait",
           "turnarounds/req", "refresh stall %", "ROB stall cyc"]
    txt = f"""# Baseline: strict FCFS (policy 0), measured

Configuration `{label}`. **This table was produced and frozen before any other scheduling policy was measured** (the files were written in this order;
`reports/bench/*.json` carry the SHA-256 of every RTL file used). All figures are **MODELLED**: RTL simulation against the HYPOTHETICAL behavioural memory
model (`docs/TIMING_MODEL.md`), not a device. Peak = lanes x DATA_W/8 bytes per cycle.

{meta_block(metas)}

Definitions: *useful B/cycle* = payload bytes of successful responses (enabled bytes for writes) / cycles between the first accept and the last response;
*row hit / conflict %* = backend-reported at the column command (model pins), *mean lat / p99* = accept -> response delivered (cycles),
*q-wait* = accept -> issue to the backend, *turnarounds/req* = read<->write direction changes at issue per issued command,
*ROB stall* = cycles in which a completed response was held back by the ordering rule.

{table(rows, hdr)}
"""
    open(a.out, "w").write(txt)
    print("wrote", a.out)


def cmd_compare(a):
    recs, metas = load(a.files, a.seeds)
    g = agg(recs)
    labels = list(dict.fromkeys(k[0] for k in g))
    label = labels[0]
    pols = sorted({k[2] for k in g})
    wls = list(dict.fromkeys(k[1] for k in g))
    out = [f"# {a.title or 'Scheduling-policy study'} (all numbers MODELLED)\n\nConfiguration `{label}`.  Baseline = policy 0 (FCFS), measured first and frozen (`BASELINE_FCFS.md`). "
           f"Policies: " + ", ".join(f"{p}={POLNAME[p]}" for p in pols) + ".\n\n" + meta_block(metas) + "\n"]
    # throughput table
    hdr = ["workload"] + [f"{POLNAME[p]} B/cyc" for p in pols] + [f"{POLNAME[p]} vs FCFS" for p in pols if p != 0]
    rows = []
    for w in wls:
        base = g.get((label, w, 0))
        if not base:
            continue
        row = [w] + [f(g[(label, w, p)]["bpc"], 2, True) if (label, w, p) in g else "-" for p in pols]
        for p in pols:
            if p == 0:
                continue
            k = (label, w, p)
            row.append(f"{(g[k]['bpc'][0] / base['bpc'][0] - 1) * 100:+.1f} %" if k in g else "-")
        rows.append(row)
    out.append("## Useful throughput (bytes per cycle; seeds: mean (min..max))\n\n" + table(rows, hdr))
    # latency
    hdr = ["workload"] + [f"{POLNAME[p]} mean / p99" for p in pols]
    rows = []
    for w in wls:
        rows.append([w] + [f"{g[(label, w, p)]['lat_mean'][0]:.0f} / {g[(label, w, p)]['lat_p99'][0]:.0f}" if (label, w, p) in g else "-" for p in pols])
    out.append("## Request latency, accept -> response (cycles)\n\n" + table(rows, hdr))
    # row-buffer
    hdr = ["workload"] + [f"{POLNAME[p]} hit % / conflict %" for p in pols]
    rows = []
    for w in wls:
        rows.append([w] + [f"{g[(label, w, p)]['hit'][0]:.1f} / {g[(label, w, p)]['conf'][0]:.1f}" if (label, w, p) in g else "-" for p in pols])
    out.append("## Row-buffer behaviour (backend-reported)\n\n" + table(rows, hdr))
    # mechanism metrics
    hdr = ["workload", "policy", "q-wait mean", "q-wait max", "turnarounds / req", "drain %", "age overrides", "bank-busy issues", "refresh stall %", "ROB stall cyc", "lane util %"]
    rows = []
    for w in wls:
        for p in pols:
            k = (label, w, p)
            if k in g:
                m = g[k]
                rows.append([w, POLNAME[p], f(m["qw"], 0), f(m["qw_max"], 0), f(m["turn"], 2), f(m["drain"], 1), f(m["age_ovr"], 0), f(m["bank_conf"], 0),
                             f(m["ref"], 1), f(m["rob"], 0), f(m["util"], 1)])
    out.append("## Mechanism metrics\n\n" + table(rows, hdr))
    # per-source / tensor
    for w in ("bench_system", "bench_tensor", "bench_ctrl_probe", "bench_tensor_alone"):
        if not any((label, w, p) in g for p in pols):
            continue
        hdr = ["policy", "src", "requests", "bytes", "e2e mean", "e2e p50", "e2e p99", "e2e max", "ingress stall cyc"]
        rows = []
        for p in pols:
            k = (label, w, p)
            if k not in g:
                continue
            srcs = g[k]["_src"][0]
            for s in srcs:
                if s["rsp"] == 0:
                    continue
                rows.append([POLNAME[p], s["id"], s["rsp"], s["bytes"], f"{s['e2e_sum'] / s['rsp']:.0f}", s["e2e_p50"], s["e2e_p99"], s["e2e_max"], s["ing_stall"]])
        out.append(f"## Per-source view: `{w}` (first seed)\n\nSource 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.\n\n" + table(rows, hdr))
    # tensor starvation
    hdr = ["workload", "policy", "tiles", "compute idle cycles (after first start)", "longest idle run", "span (cycles)", "idle %", "first-tile wait"]
    rows = []
    for w in ("bench_tensor_alone", "bench_tensor", "bench_system"):
        for p in pols:
            k = (label, w, p)
            if k in g and g[k]["_tensor"][0]["active"]:
                t = g[k]["_tensor"][0]
                rows.append([w, POLNAME[p], t["tiles"], t["starve_cycles"], t["max_idle_run"], t["span"], f"{100 * t['starve_cycles'] / max(1, t['span']):.1f}", t["first_start"]])
    if rows:
        out.append("## Tensor starvation (tile-fetch flow, double-buffered consumer)\n\n" + table(rows, hdr))
    open(a.out, "w").write("\n".join(out))
    print("wrote", a.out)


def cmd_scaling(a):
    recs, metas = load(a.files, a.seeds)
    g = agg(recs)
    wls = list(dict.fromkeys(k[1] for k in g))
    labels = list(dict.fromkeys(k[0] for k in g))
    pols = sorted({k[2] for k in g})
    out = ["# Channel scaling (MODELLED)\n\n" + meta_block(metas) + "\n"]
    for p in pols:
        hdr = ["workload"] + labels
        rows = []
        for w in wls:
            row = [w]
            for l in labels:
                k = (l, w, p)
                row.append(f"{g[k]['bpc'][0]:.2f} ({g[k]['eff'][0]:.0f} %)" if k in g else "-")
            rows.append(row)
        out.append(f"## {POLNAME[p]}: useful B/cycle (% of peak)\n\n" + table(rows, hdr))
    out.append(SCALING_NOTES)
    open(a.out, "w").write("\n".join(out))
    print("wrote", a.out)


SCALING_NOTES = """## How to read this (and what it does not show)

* Configurations (`scripts/scale_configs.json`): `sc_ch1` = 1 lane, `sc_ch2` = 2 lanes (the default), `sc_ch4` = 4 channels, `sc_pc2` = 2 channels x 2 pseudo-channels (4 lanes),
  `sc_ch4pc2` = 8 lanes, `sc_ch4pc2_win32` = the same 8 lanes with the outstanding window raised from 8 to 32 per source and from 8 to 16 per lane. Peak = lanes x one 16-byte beat per cycle.
* **`sc_ch4` and `sc_pc2` are identical** to the digit. That is expected and is a limit of the model, not a result: a lane is an independent scheduling domain with its own behavioural
  memory, and the model has **no shared command / address bus, no pseudo-channel coupling and no shared refresh or power budget**. Real 2 x 2 and 4 x 1 organisations would not behave identically.
* **The 8-lane run with the default window is window-limited, not lane-limited.** Sequential read reaches 43 % of peak with the default window and 76 % with a window of 32 / 16
  (the same lanes, the same traffic). Treat the `sc_ch4pc2` column as "default sources cannot feed 8 lanes", and `sc_ch4pc2_win32` as the capacity of the lanes.
* Sequential traffic scales close to linearly up to 4 lanes under FCFS (11.2 -> 22.5 -> 46.0 B/cycle). The random-mix workload stays at 10-14 % of peak at every size; its absolute rate
  grows with lanes (2.3 -> 8.0 B/cycle from 1 to 4 lanes) but I did not diagnose why it grows less than linearly, so no cause is claimed.
* One seed (1), N = 2000 requests per source, no confidence interval: differences of a few percent are not significant. The policy columns repeat the policy study's configuration
  (`cfg_age_limit` 1024); the policy comparison itself is in `BENCHMARKS.md`, where more seeds were used.
* All values are from the behavioural memory model with the SIM_GENERIC profile. They say nothing about a real HBM stack.
"""


def main():
    ap = argparse.ArgumentParser()
    sp = ap.add_subparsers(dest="cmd", required=True)
    for n in ("baseline", "compare", "scaling"):
        p = sp.add_parser(n)
        p.add_argument("files", nargs="+")
        p.add_argument("--out", required=True)
        p.add_argument("--seeds", type=int, nargs="*", help="only use these seeds (e.g. the held-out seeds 2 3)")
        p.add_argument("--title", default=None)
    a = ap.parse_args()
    {"baseline": cmd_baseline, "compare": cmd_compare, "scaling": cmd_scaling}[a.cmd](a)


if __name__ == "__main__":
    main()
