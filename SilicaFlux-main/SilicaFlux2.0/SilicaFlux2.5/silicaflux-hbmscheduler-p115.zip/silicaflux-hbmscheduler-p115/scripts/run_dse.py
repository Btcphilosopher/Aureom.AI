#!/usr/bin/env python3
"""Small design-space sweep of the scheduler's runtime parameters.

Tuning is done on seed 1 only; the report then evaluates the chosen setting on seeds 2 and 3 (see
run_bench.py + gen_report.py) so the tuned numbers are not the numbers the parameters were fitted to.

  run_dse.py --exe build/base/simx --param AGE 128 256 512 1024 2048 4000 --policies 2 3 --workloads ... --tag dse_age
"""
import argparse, concurrent.futures as cf, json, os, re, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def one(job):
    exe, wl, pol, pname, pval, seed, n, extra = job
    args = [exe, f"+TEST={wl}", f"+POLICY={pol}", f"+SEED={seed}", f"+N={n}", f"+{pname}={pval}"] + extra
    r = subprocess.run(args, capture_output=True, text=True, timeout=3000)
    out = r.stdout + r.stderr
    m = re.search(r"BENCH_JSON (\{.*\})", out)
    ok = r.returncode == 0 and "RESULT: ALL PASS" in out and m
    return {"workload": wl, "policy": pol, "param": pname, "value": pval, "seed": seed, "pass": bool(ok),
            "bpc": json.loads(m.group(1))["bytes_per_cycle"] if ok else None,
            "lat_mean": json.loads(m.group(1))["lat_mean"] if ok else None,
            "lat_p99": json.loads(m.group(1))["lat_p99"] if ok else None}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exe", required=True)
    ap.add_argument("--param", nargs="+", required=True, help="NAME v1 v2 ...  (plusarg name: AGE BUSY WRHI WRLO IDLEWR PRIO)")
    ap.add_argument("--policies", type=int, nargs="+", default=[2, 3])
    ap.add_argument("--workloads", nargs="+", required=True)
    ap.add_argument("--seeds", type=int, nargs="+", default=[1])
    ap.add_argument("--n", type=int, default=2000)
    ap.add_argument("--extra", nargs="*", default=[])
    ap.add_argument("--tag", required=True)
    ap.add_argument("--jobs", type=int, default=3)
    a = ap.parse_args()
    pname, vals = a.param[0], a.param[1:]
    jobs = [(a.exe, w, p, pname, v, s, a.n, a.extra) for w in a.workloads for p in a.policies for v in vals for s in a.seeds]
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(one, jobs))
    os.makedirs(os.path.join(ROOT, "reports", "dse"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "dse", a.tag + ".json"), "w"), indent=1)
    # table: workload x policy rows, one column per value
    print(f"| workload | policy | " + " | ".join(f"{pname}={v}" for v in vals) + " |")
    print("|---|---|" + "---|" * len(vals))
    for w in a.workloads:
        for p in a.policies:
            row = []
            for v in vals:
                xs = [r["bpc"] for r in res if r["workload"] == w and r["policy"] == p and r["value"] == v and r["pass"]]
                row.append(f"{sum(xs) / len(xs):.2f}" if xs else "FAIL")
            print(f"| {w} | {p} | " + " | ".join(row) + " |")
    return 0 if all(r["pass"] for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
