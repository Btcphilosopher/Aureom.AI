#!/usr/bin/env python3
"""Icarus Verilog 12 cross-checks (secondary simulator).  Verilator is the primary simulator.

 1. address-map unit bench on Icarus for the four map modes
 2. RTL-only elaboration of the whole design (warnings are listed, not hidden)
 3. the full system bench: compile with a time limit; if it builds, run the cheap scenarios and compare the
    RESULT lines (cycle counts, request counts) with the Verilator build of the same configuration

Everything that did not happen is stated as such in reports/CROSSSIM.md.
"""
import os, re, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.environ.get("BUILD_DIR", os.path.join(ROOT, "build"))
VERILATOR_EXE = os.environ.get("VERILATOR_EXE", os.path.join(BUILD, "base", "simx"))
LIMIT = int(os.environ.get("ICARUS_COMPILE_LIMIT", "1200"))
RTL = [os.path.join(ROOT, "rtl", f"sf_hbm_{m}.sv") for m in
       "address_map req_check channel_arbiter read_queue write_queue scheduler backend_adapter maxsel trk_slot trk_src response_tracker perf lane sched_top".split()]


def sh(cmd, timeout):
    t0 = time.time()
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout + r.stderr, time.time() - t0
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT", time.time() - t0


def main():
    out = ["# Icarus Verilog cross-checks (secondary simulator)\n", f"`iverilog` = {sh(['iverilog', '-V'], 20)[1].splitlines()[0]}\n"]
    os.makedirs(os.path.join(BUILD, "icarus"), exist_ok=True)
    # 1. unit bench
    out.append("## 1. Address-map unit bench\n\n| map mode | result |\n|---|---|\n")
    for m in range(4):
        vvp = os.path.join(BUILD, "icarus", f"am{m}.vvp")
        rc, txt, _ = sh(["iverilog", "-g2012", f"-Pmain.MAP_MODE={m}", "-Ptb_addr_map.MAP_MODE=%d" % m, "-I" + os.path.join(ROOT, "rtl"), "-s", "tb_addr_map", "-o", vvp,
                         RTL[0], os.path.join(ROOT, "tb", "tb_addr_map.sv")], 300)
        res = "compile failed"
        if rc == 0:
            rc2, txt2, _ = sh(["vvp", vvp], 600)
            m2 = re.search(r"RESULT: (PASS|FAIL).*", txt2)
            res = m2.group(0) if m2 else "no RESULT line"
        out.append(f"| {m} | {res} |\n")
    # 2. RTL elaboration
    rc, txt, dt = sh(["iverilog", "-g2012", "-I" + os.path.join(ROOT, "rtl"), "-s", "sf_hbm_sched_top", "-o", os.path.join(BUILD, "icarus", "top.vvp")] + RTL, 600)
    sorry = sorted(set(re.findall(r"sorry: (.*)", txt)))
    errs = [l for l in txt.splitlines() if "error" in l.lower()]
    out.append(f"\n## 2. RTL-only elaboration (`-s sf_hbm_sched_top`)\n\nexit code {rc} in {dt:.0f} s; errors: {len(errs)}; distinct Icarus limitations reported: {sorry or 'none'}.\n"
               "(`constant selects in always_* processes are not currently supported (all bits will be included)` makes the affected processes sensitive to every bit: expected to be functionally neutral for combinational processes (more evaluations only), but NOT demonstrated here because the full bench did not run on Icarus.)\n")
    # 3. full bench
    vvp = os.path.join(BUILD, "icarus", "tb.vvp")
    rc, txt, dt = sh(["iverilog", "-g2012", "-I" + os.path.join(ROOT, "rtl"), "-I" + os.path.join(ROOT, "model"), "-I" + os.path.join(ROOT, "tb"), "-s", "sf_hbm_tb", "-o", vvp] + RTL +
                     [os.path.join(ROOT, "model", "sf_hbm_mem_model.sv"), os.path.join(ROOT, "tb", "sf_hbm_sfmc_check.sv"), os.path.join(ROOT, "tb", "sf_hbm_tb.sv")], LIMIT)
    out.append(f"\n## 3. Full system bench on Icarus\n\n")
    if rc != 0:
        why = "did not finish within the time limit" if rc == 124 else "compile errors: " + " | ".join(l for l in txt.splitlines() if 'error' in l.lower())[:300]
        out.append(f"**Not run.** Compilation {why} (limit {LIMIT} s). The system bench is therefore verified on Verilator only; "
                   "the secondary-simulator evidence is limited to sections 1 and 2.\n")
    else:
        out.append(f"compiled in {dt:.0f} s. Same scenarios, same seed, compared with the Verilator build `{VERILATOR_EXE}`:\n\n| scenario | Verilator | Icarus | identical |\n|---|---|---|---|\n")
        for t in ("smoke", "seq", "hazard", "reorder"):
            rv = sh([VERILATOR_EXE, f"+TEST={t}", "+N=100", "+SEED=1"], 600)[1]
            ri = sh(["vvp", vvp, f"+TEST={t}", "+N=100", "+SEED=1"], 3000)[1]
            fv = re.findall(r"RESULT: \w+ test=\S+ cycles=\d+ acc=\d+ rsp=\d+", rv)
            fi = re.findall(r"RESULT: \w+ test=\S+ cycles=\d+ acc=\d+ rsp=\d+", ri)
            out.append(f"| {t} | {fv[:1]} | {fi[:1]} | {'yes' if fv and fv == fi else 'NO'} |\n")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "CROSSSIM.md"), "w").write("".join(out))
    print("".join(out))


if __name__ == "__main__":
    main()
