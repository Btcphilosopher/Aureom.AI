#!/usr/bin/env python3
"""Independent timing checker for the P115 behavioural memory model.

Reads the command log written by sf_hbm_mem_model (+CMDLOG=<file>) and checks
EVERY timing rule of the model against the parameter set, without using any of
the model's own code:

    ACT -> RD/WR   same bank          >= tRCD
    ACT -> PRE     same bank          >= tRAS
    PRE -> ACT     same bank          >= tRP
    ACT -> ACT     other bank         >= tRRD_S (other bank group) / tRRD_L (same group)
    any 4 ACTs     window             >= tFAW   (ACT[i+4] - ACT[i])
    RD -> PRE      same bank          >= tRTP
    WR -> PRE      same bank          >= tCWL + BL + tWR
    column spacing                    >= tCCD_S / tCCD_L  (same direction)
    RD -> WR                          >= tRTW
    WR -> RD                          >= tCWL + BL + tWTR_S / tWTR_L
    data bus windows never overlap    (RD: [t+tCL, t+tCL+BL), WR: [t+tCWL, t+tCWL+BL))
    column command needs the matching row to be open
    REF needs all banks precharged (tRP elapsed); no command for tRFC after REF
    refresh interval                  REF-to-REF <= tREFI + slack

Usage: check_timing_log.py LOG --bl 2 --bank-bits 2 [--tRCD 14 ...] [--no-refresh]
Exit status 0 = no violation.  Parameter defaults are the SIM_GENERIC profile.
"""
import argparse
import sys
from collections import defaultdict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("log")
    ap.add_argument("--bl", type=int, default=2)
    ap.add_argument("--bank-bits", type=int, default=2, help="bank bits inside a bank group")
    for name, dv in dict(tRCD=14, tRP=14, tRAS=33, tCL=14, tCWL=7, tWR=15, tRTP=5, tRRD_S=4, tRRD_L=6,
                         tFAW=16, tWTR_S=4, tWTR_L=8, tREFI=3900, tRFC=260).items():
        ap.add_argument("--" + name, type=int, default=dv)
    ap.add_argument("--tCCD_S", type=int, default=None)
    ap.add_argument("--tCCD_L", type=int, default=None)
    ap.add_argument("--tRTW", type=int, default=None)
    ap.add_argument("--refi-slack", type=int, default=400)
    ap.add_argument("--no-refresh", action="store_true")
    a = ap.parse_args()
    bl = a.bl
    t = dict(RCD=a.tRCD, RP=a.tRP, RAS=a.tRAS, CL=a.tCL, CWL=a.tCWL, WR=a.tWR, RTP=a.tRTP, RRD_S=a.tRRD_S,
             RRD_L=a.tRRD_L, FAW=a.tFAW, WTR_S=a.tWTR_S, WTR_L=a.tWTR_L, RFC=a.tRFC, REFI=a.tREFI)
    t["CCD_S"] = a.tCCD_S if a.tCCD_S is not None else bl
    t["CCD_L"] = a.tCCD_L if a.tCCD_L is not None else bl + 2
    t["RTW"] = a.tRTW if a.tRTW is not None else a.tCL + bl + 2 - a.tCWL

    def bg(b):
        return b >> a.bank_bits

    viol = []

    def v(msg, line):
        if len(viol) < 20:
            viol.append(f"{msg}  [log line {line}]")
        else:
            viol.append(None)

    open_row = {}              # bank -> row
    t_act = {}                 # bank -> time of last ACT
    t_pre = {}                 # bank -> time of last PRE
    t_rd = {}                  # bank -> time of last RD
    t_wr = {}                  # bank -> time of last WR
    acts = []                  # ACT times
    last_act = None            # (time, bank)
    last_col = None            # (time, bank, is_wr)
    dbus_free = -10**9
    ref_until = -1
    last_ref = None
    last_t = -1
    counts = defaultdict(int)
    with open(a.log) as f:
        for ln, raw in enumerate(f, 1):
            if raw.startswith("#") or not raw.strip():
                continue
            parts = raw.split()
            tm, op, bank, row, col = int(parts[0]), parts[1], int(parts[2]), int(parts[3]), int(parts[4])
            counts[op] += 1
            if tm < last_t:
                v(f"time went backwards ({tm} < {last_t})", ln)
            if tm == last_t:
                v(f"two commands in cycle {tm} (one command slot per cycle)", ln)
            last_t = tm
            if tm < ref_until:
                v(f"{op} at {tm} during refresh (until {ref_until})", ln)
            if op == "ACT":
                if bank in open_row:
                    v(f"ACT to bank {bank} that is already open", ln)
                if bank in t_pre and tm - t_pre[bank] < t["RP"]:
                    v(f"tRP violated bank {bank}: {tm - t_pre[bank]} < {t['RP']}", ln)
                if bank in t_act and tm - t_act[bank] < t["RAS"] + t["RP"]:
                    v(f"tRC violated bank {bank}", ln)
                if last_act is not None:
                    need = t["RRD_L"] if bg(bank) == bg(last_act[1]) else t["RRD_S"]
                    if tm - last_act[0] < need:
                        v(f"tRRD violated: {tm - last_act[0]} < {need}", ln)
                if len(acts) >= 4 and tm - acts[-4] < t["FAW"]:
                    v(f"tFAW violated: {tm - acts[-4]} < {t['FAW']}", ln)
                acts.append(tm)
                open_row[bank] = row
                t_act[bank] = tm
                last_act = (tm, bank)
            elif op == "PRE":
                if bank not in open_row:
                    v(f"PRE to bank {bank} that is not open", ln)
                else:
                    if tm - t_act[bank] < t["RAS"]:
                        v(f"tRAS violated bank {bank}: {tm - t_act[bank]} < {t['RAS']}", ln)
                    if bank in t_rd and t_rd[bank] > t_act[bank] and tm - t_rd[bank] < t["RTP"]:
                        v(f"tRTP violated bank {bank}", ln)
                    if bank in t_wr and t_wr[bank] > t_act[bank] and tm - t_wr[bank] < t["CWL"] + bl + t["WR"]:
                        v(f"tWR violated bank {bank}", ln)
                    del open_row[bank]
                t_pre[bank] = tm
            elif op in ("RD", "WR"):
                is_wr = op == "WR"
                if bank not in open_row:
                    v(f"{op} to bank {bank} with no open row", ln)
                else:
                    if open_row[bank] != row:
                        v(f"{op} row {row} but open row is {open_row[bank]} (bank {bank})", ln)
                    if tm - t_act[bank] < t["RCD"]:
                        v(f"tRCD violated bank {bank}: {tm - t_act[bank]} < {t['RCD']}", ln)
                if last_col is not None:
                    lt, lb, lw = last_col
                    same = bg(bank) == bg(lb)
                    if not is_wr and not lw:
                        need = t["CCD_L"] if same else t["CCD_S"]
                    elif is_wr and lw:
                        need = t["CCD_L"] if same else t["CCD_S"]
                    elif is_wr and not lw:
                        need = t["RTW"]
                    else:
                        need = t["CWL"] + bl + (t["WTR_L"] if same else t["WTR_S"])
                    if tm - lt < need:
                        kind = ("RD->RD" if not is_wr and not lw else "WR->WR" if is_wr and lw else "RD->WR" if is_wr else "WR->RD")
                        v(f"{kind} spacing violated: {tm - lt} < {need}", ln)
                start = tm + (t["CWL"] if is_wr else t["CL"])
                if start < dbus_free:
                    v(f"data bus overlap: window starts {start} but bus busy until {dbus_free}", ln)
                dbus_free = start + bl
                last_col = (tm, bank, is_wr)
                (t_wr if is_wr else t_rd)[bank] = tm
            elif op == "REF":
                if open_row:
                    v(f"REF with open banks {sorted(open_row)}", ln)
                for b, tp in t_pre.items():
                    if tm - tp < t["RP"]:
                        v(f"REF only {tm - tp} cycles after PRE of bank {b} (< tRP)", ln)
                ref_until = tm + t["RFC"]
                if last_ref is not None and tm - last_ref > t["REFI"] + a.refi_slack:
                    v(f"refresh interval {tm - last_ref} > tREFI + slack", ln)
                last_ref = tm
            else:
                v(f"unknown op {op}", ln)
    extra = sum(1 for x in viol if x is None)
    shown = [x for x in viol if x is not None]
    print(f"{a.log}: {dict(counts)}")
    if not a.no_refresh and counts["REF"] == 0 and last_t > t["REFI"] + a.refi_slack:
        shown.append("no refresh in a log longer than tREFI + slack")
    if shown:
        for m in shown:
            print("VIOLATION:", m)
        if extra:
            print(f"... and {extra} more")
        print("TIMING CHECK: FAIL")
        return 1
    print("TIMING CHECK: PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
