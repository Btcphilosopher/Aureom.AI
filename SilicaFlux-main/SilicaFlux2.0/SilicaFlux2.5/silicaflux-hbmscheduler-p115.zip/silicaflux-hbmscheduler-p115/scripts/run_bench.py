#!/usr/bin/env python3
"""P115 benchmark runner.

Runs benchmark scenarios of the self-checking bench (every run is ALSO a full
correctness check: a run whose data / ordering checks fail produces no result),
parses the BENCH_JSON line printed at the end and stores all records in one JSON
file.  The simulator is deterministic and the bench PRNG is its own xorshift, so a
(binary, scenario, policy, seed, N) tuple always gives the same record.

  run_bench.py --exe build/base/simx --label base --policies 0 --workloads all --seeds 1 2 3 --tag baseline_fcfs
"""
import argparse, concurrent.futures as cf, hashlib, json, os, re, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORKLOADS = ["bench_seq_rd", "bench_seq_wr", "bench_seq_mix", "bench_seq_rd_aligned", "bench_rand_rd", "bench_rand_mix",
             "bench_rowmix", "bench_rowwalk", "bench_hotbank", "bench_vector", "bench_dma_copy",
             "bench_tensor_alone", "bench_tensor", "bench_ctrl_probe", "bench_system"]
RANDOMISED = {"bench_rand_rd", "bench_rand_mix", "bench_rowmix", "bench_vector", "bench_tensor", "bench_ctrl_probe",
              "bench_system", "bench_tensor_alone", "bench_dma_copy", "bench_rowwalk", "bench_hotbank"}


def sha(path):
    h = hashlib.sha256()
    h.update(open(path, "rb").read())
    return h.hexdigest()


def one(job):
    exe, label, wl, pol, seed, n, extra = job
    args = [exe, f"+TEST={wl}", f"+POLICY={pol}", f"+SEED={seed}", f"+N={n}"] + extra
    t0 = time.time()
    r = subprocess.run(args, capture_output=True, text=True, timeout=3000)
    out = r.stdout + r.stderr
    m = re.search(r"BENCH_JSON (\{.*\})", out)
    ok = r.returncode == 0 and "RESULT: ALL PASS" in out and m is not None
    rec = {"config_label": label, "workload": wl, "policy": pol, "seed": seed, "n": n, "extra": extra, "pass": ok,
           "wall_s": round(time.time() - t0, 2)}
    if m:
        try:
            rec["result"] = json.loads(m.group(1))
        except Exception as e:  # malformed JSON is a failure, never silently dropped
            rec["pass"] = False
            rec["error"] = f"bad json: {e}"
    if not ok:
        rec["tail"] = out[-1200:]
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--exe", required=True)
    ap.add_argument("--label", required=True, help="configuration label stored in every record")
    ap.add_argument("--policies", type=int, nargs="+", default=[0])
    ap.add_argument("--workloads", nargs="+", default=["all"])
    ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3])
    ap.add_argument("--n", type=int, default=2000)
    ap.add_argument("--tag", required=True)
    ap.add_argument("--extra", nargs="*", default=[], help="extra plusargs, e.g. +BUSY=16")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports", "bench"))
    a = ap.parse_args()
    wls = WORKLOADS if a.workloads == ["all"] else a.workloads
    jobs = []
    for wl in wls:
        for pol in a.policies:
            seeds = a.seeds if wl in RANDOMISED else a.seeds[:1]
            for sd in seeds:
                jobs.append((a.exe, a.label, wl, pol, sd, a.n, a.extra))
    os.makedirs(a.out, exist_ok=True)
    recs = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for rec in ex.map(one, jobs):
            recs.append(rec)
            tag = "ok " if rec["pass"] else "FAIL"
            bw = rec.get("result", {}).get("bytes_per_cycle")
            print(f"{tag} {a.label:6s} {rec['workload']:22s} pol={rec['policy']} seed={rec['seed']} "
                  f"{'' if bw is None else f'{bw:7.3f} B/cyc'}", flush=True)
    meta = {"tag": a.tag, "label": a.label, "exe_sha256": sha(a.exe), "policies": a.policies, "seeds": a.seeds, "n": a.n,
            "extra": a.extra, "rtl_sha256": {f: sha(os.path.join(ROOT, "rtl", f)) for f in sorted(os.listdir(os.path.join(ROOT, "rtl")))},
            "tb_sha256": sha(os.path.join(ROOT, "tb", "sf_hbm_tb.sv")), "model_sha256": sha(os.path.join(ROOT, "model", "sf_hbm_mem_model.sv")),
            "created": time.strftime("%Y-%m-%d %H:%M:%S")}
    path = os.path.join(a.out, a.tag + ".json")
    json.dump({"meta": meta, "records": recs}, open(path, "w"), indent=1)
    bad = [r for r in recs if not r["pass"]]
    print(f"wrote {path}: {len(recs)} records, {len(bad)} failed")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
