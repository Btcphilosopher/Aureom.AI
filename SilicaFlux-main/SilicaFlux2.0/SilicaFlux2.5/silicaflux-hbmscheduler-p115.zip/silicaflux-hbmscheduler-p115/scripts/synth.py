#!/usr/bin/env python3
"""Technology-independent synthesis statistics with Yosys (no PDK, no timing library).

For every module and for the integrated top in several configurations: `synth -flatten`
to generic gates, then cell counts, flip-flop count, latch count, `check -assert`
(combinational loops, multiple drivers, undriven nets), and `ltp` = the longest
topological path in logic levels of the generic gate netlist.

These are PROXIES.  Gate counts and logic levels are not area, not frequency and
not power; a real flow with a cell library, memories compiled to SRAM / register
files and constraints will differ.  Nothing here claims timing closure.
"""
import json, os, re, subprocess, sys, time, concurrent.futures as cf

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = os.path.join(ROOT, "rtl")
ALL = ["sf_hbm_address_map", "sf_hbm_req_check", "sf_hbm_channel_arbiter", "sf_hbm_read_queue", "sf_hbm_write_queue",
       "sf_hbm_scheduler", "sf_hbm_maxsel", "sf_hbm_backend_adapter", "sf_hbm_trk_slot", "sf_hbm_trk_src", "sf_hbm_response_tracker",
       "sf_hbm_perf", "sf_hbm_lane", "sf_hbm_sched_top"]
FILES = [os.path.join(RTL, f + ".sv") for f in ALL]


def check_status(txt):
    """Result of the CHECK passes as printed by Yosys ('Found and reported N problems').  `check -assert` also aborts the run on a problem."""
    n = [int(x) for x in re.findall(r"Found and reported (\d+) problems?", txt)]
    if not n:
        return "?"
    return "ok" if all(x == 0 for x in n) else f"{sum(n)} problems"


def run_one(name, top, params, files=None):
    t0 = time.time()
    work = os.path.join(ROOT, "build", "synth")
    os.makedirs(work, exist_ok=True)
    log = os.path.join(work, name + ".log")
    ch = "".join(f"chparam -set {k} {v} {top}\n" for k, v in params.items())
    script = f"""
read_verilog -sv -I{RTL} {' '.join(files or FILES)}
{ch}hierarchy -top {top}
synth -top {top} -flatten
check -assert
tee -o {work}/{name}.stat stat
ltp -noff
"""
    r = subprocess.run(["yosys", "-l", log, "-p", script], capture_output=True, text=True, timeout=3000)
    txt = open(log).read() if os.path.exists(log) else r.stdout + r.stderr
    res = {"name": name, "top": top, "params": params, "ok": r.returncode == 0, "seconds": round(time.time() - t0, 1)}
    if r.returncode != 0:
        res["error"] = (r.stdout + r.stderr)[-600:]
        return res
    stat = open(os.path.join(work, name + ".stat")).read()
    cells = {}
    for m in re.finditer(r"^\s+(\$_\w+_)\s+(\d+)\s*$", stat, re.M):
        cells[m.group(1)] = int(m.group(2))
    total = sum(cells.values())
    ffs = sum(v for k, v in cells.items() if re.match(r"\$_(S?DFF|DFFE|SDFFE|SDFFCE|ALDFF|DFFSR)", k))
    lat = sum(v for k, v in cells.items() if "LATCH" in k)
    mm = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", txt)
    res.update({"cells_total": total, "flip_flops": ffs, "latches": lat, "logic_cells": total - ffs - lat,
                "mux_cells": sum(v for k, v in cells.items() if "MUX" in k),
                "ltp_levels": int(mm.group(1)) if mm else None, "cell_types": cells,
                "check_assert": check_status(txt)})
    return res


def main():
    jobs = []
    for m in ALL:
        if m == "sf_hbm_sched_top":
            continue
        jobs.append((m, m, {}))
    # Per-module view with default parameters, the integrated top (2 lanes) once, and parameter variants at the
    # LANE / TRACKER level.  Lanes are independent, so the lane is the scaling unit; a 4- or 8-lane top-level run
    # was not attempted (the 2-lane top alone needs ~8.5 GB and ~14 min of Yosys on the 15 GB build machine).
    jobs += [("top_2lane_default", "sf_hbm_sched_top", {}),
             ("lane_unsafe_BE_ORDER_SAFE0", "sf_hbm_lane", {"BE_ORDER_SAFE": 0}),
             ("lane_queue8", "sf_hbm_lane", {"RQ_DEPTH": 8, "WQ_DEPTH": 8}),
             ("lane_queue32", "sf_hbm_lane", {"RQ_DEPTH": 32, "WQ_DEPTH": 32}),
             ("tracker_order1", "sf_hbm_response_tracker", {"ORDER_MODE": 1}),
             ("tracker_4lane", "sf_hbm_response_tracker", {"NUM_LANES": 4})]
    # NOT run: tracker with OUT_PER_SRC=16 and the 4/8-lane top levels.  Yosys exceeded ~9.6 GB RSS on the 15 GB build
    # machine and was killed by the kernel (OOM), so there is no result for them; that is a limit of this proxy flow,
    # not a statement about the design.  Run the top level ALONE (no other heavy job): ~14 min, ~8.5 GB.
    jobs_all = [j for j in jobs if j[0] not in ALL]
    only = os.environ.get("SYNTH_ONLY")
    prev = {}
    if only:
        names = set(only.split(","))
        pj = os.path.join(ROOT, "reports", "synth.json")
        if os.path.exists(pj):
            prev = {r["name"]: r for r in json.load(open(pj)) if r["name"] not in names and r["ok"]}
        jobs = [j for j in jobs if j[0] in names]
    out = []
    with cf.ThreadPoolExecutor(3) as ex:
        futs = [ex.submit(run_one, n, t, p) for n, t, p in jobs]
        for f in futs:
            r = f.result()
            out.append(r)
            print(f"{r['name']:24s} {'ok' if r['ok'] else 'FAIL':4s} cells={r.get('cells_total')} ff={r.get('flip_flops')} "
                  f"latch={r.get('latches')} levels={r.get('ltp_levels')} ({r['seconds']}s)", flush=True)
    allres = list(prev.values()) + out
    order = [m for m in ALL if m != "sf_hbm_sched_top"] + [j[0] for j in jobs_all]
    out = sorted(allres, key=lambda r: order.index(r["name"]) if r["name"] in order else 99)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    for r in out:
        lg = os.path.join(ROOT, "build", "synth", r["name"] + ".log")
        if r["ok"] and os.path.exists(lg):
            r["check_assert"] = check_status(open(lg).read())
    json.dump(out, open(os.path.join(ROOT, "reports", "synth.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "SYNTH.md"), "w") as f:
        f.write("# Synthesis statistics (Yosys 0.33, generic gates; PROXIES, no PDK / timing)\n\n")
        f.write("`synth -top T -flatten` to Yosys' internal gate set. *Flip-flops* include the register-file style storage of the queues / tracker (a real flow maps those to register files or SRAM). "
                "*Levels* = `ltp` longest topological path of the flattened generic netlist. `check -assert` = no combinational loop, multiple driver or undriven net. "
                "**Not area, not frequency, not power; no timing closure is claimed.**\n\n")
        f.write("| block | configuration | cells | flip-flops | latches | logic cells | mux cells | longest path (levels) | check -assert |\n|---|---|---|---|---|---|---|---|---|\n")
        for r in out:
            if not r["ok"]:
                f.write(f"| {r['name']} | {r['params']} | **FAILED** | | | | | | |\n")
                continue
            f.write(f"| {r['name']} | {r['params'] or 'defaults'} | {r['cells_total']} | {r['flip_flops']} | {r['latches']} | {r['logic_cells']} | {r['mux_cells']} | {r['ltp_levels']} | {r['check_assert']} |\n")
    R = {r["name"]: r for r in out if r["ok"]}
    def c(n): return R[n]["cells_total"] if n in R else None
    def pct(a, b): return f"{100.0 * a / b:.0f} %" if a is not None and b else "n/a"
    def chg(a, b): return f"{100.0 * (a - b) / b:+.1f} %" if a is not None and b else "n/a"
    top = c("top_2lane_default")
    with open(os.path.join(ROOT, "reports", "SYNTH.md"), "a") as f:
        f.write("\n## What the numbers say (computed from the table above)\n\n")
        if top:
            f.write(f"* **Where the 2-lane top goes:** response tracker {pct(c('sf_hbm_response_tracker'), top)} of the cells, the two lanes {pct(2 * (c('sf_hbm_lane') or 0), top)}, performance counters {pct(c('sf_hbm_perf'), top)} "
                    "(the remainder is request validation and arbitration; module numbers do not add up exactly after flattening and logic optimisation). Storage written as flip-flop arrays dominates the flip-flop count "
                    f"({R['top_2lane_default']['flip_flops']} in the top): in silicon the queues, the tracker's read-data store and the counters belong in register files or SRAM.\n")
        if c("sf_hbm_lane") and c("lane_queue8") and c("lane_queue32"):
            f.write(f"* **Lane cost vs queue depth** (read + write queue entries each): 8 -> {c('lane_queue8')} cells / {R['lane_queue8']['ltp_levels']} levels, 16 (default) -> {c('sf_hbm_lane')} / {R['sf_hbm_lane']['ltp_levels']}, "
                    f"32 -> {c('lane_queue32')} / {R['lane_queue32']['ltp_levels']}. The cell count grows about linearly with depth; the pick logic gets deeper by roughly 30 levels per doubling.\n")
        if c("sf_hbm_lane") and c("lane_unsafe_BE_ORDER_SAFE0"):
            f.write(f"* **`BE_ORDER_SAFE = 0`** (in-flight hazard table for a backend that may reorder same-address accesses): lane {chg(c('lane_unsafe_BE_ORDER_SAFE0'), c('sf_hbm_lane'))} cells, "
                    f"{R['lane_unsafe_BE_ORDER_SAFE0']['ltp_levels']} vs {R['sf_hbm_lane']['ltp_levels']} levels.\n")
        if c("sf_hbm_response_tracker") and c("tracker_order1") and c("tracker_4lane"):
            f.write(f"* **Tracker variants:** `ORDER_MODE = 1` {chg(c('tracker_order1'), c('sf_hbm_response_tracker'))} cells; 4 lanes instead of 2 {chg(c('tracker_4lane'), c('sf_hbm_response_tracker'))} cells. "
                    "The tracker is dominated by its per-source storage and order matrices, not by the number of lanes.\n")
        f.write("* **Critical path:** the scheduler's pick is the deepest block on its own (171 levels, against 108 for the tracker). The longest path in the flattened top (see `top_2lane_default`) "
                "starts at a write-queue age register and ends at the result of a **48-bit adder**; the performance counters are the 48-bit logic of the design (`CNT_W = 48`), so the path continues from the pick into a counter "
                "increment (inferred from the width: the flattened net names do not say which counter). Feeding the counters from *registered* events would be expected to remove that extension; this was not tried.\n"
                "* **Not run:** a tracker with `OUT_PER_SRC = 16`, and 4- or 8-lane top levels. Yosys exceeded ~9.6 GB and was killed by the kernel (out of memory) on the 15 GB build machine, so there is no result for them; "
                "that is a limit of this proxy flow, not a statement about the design. Lanes are independent, so the lane row is the scaling unit.\n"
                "* **Caveats that apply to every row:** generic gates, no cell library and no constraints; comparators and adders are mapped as ripple structures (depths overstate what a timing-driven flow produces); "
                "latch count is zero and `check -assert` passes (no combinational loop, multiple driver or undriven net). No area, frequency or power claim is made.\n")
    bad = [r for r in out if not r["ok"] or r.get("latches")]
    print("synthesis:", "OK" if not bad else f"{len(bad)} problems")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
