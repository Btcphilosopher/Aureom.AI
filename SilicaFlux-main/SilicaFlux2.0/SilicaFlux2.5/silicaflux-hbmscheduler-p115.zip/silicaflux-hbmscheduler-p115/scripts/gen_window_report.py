#!/usr/bin/env python3
"""Outstanding-window shaping study: limit the background sources (VECTOR, STREAMDMA, CLOUD) to L transactions in flight (cfg_out_limit) and
measure TensorCore starvation and ControlCore latency."""
import json, os, statistics
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
POL = {0: "FCFS", 3: "BANKAWARE"}
rows = []
for L in (8, 4, 2, 1):
    p = os.path.join(ROOT, "reports", "bench", f"window_limbg{L}.json")
    if not os.path.exists(p):
        continue
    recs = [r for r in json.load(open(p))["records"] if r["pass"]]
    for pol in (0, 3):
        for wl in ("bench_tensor", "bench_system"):
            rs = [r["result"] for r in recs if r["policy"] == pol and r["workload"] == wl]
            if not rs:
                continue
            m = lambda f: statistics.fmean(f(x) for x in rs)
            rows.append((L, POL[pol], wl, len(rs), m(lambda x: x["bytes_per_cycle"]),
                         m(lambda x: 100 * x["tensor"]["starve_cycles"] / max(1, x["tensor"]["span"])),
                         m(lambda x: x["tensor"]["span"]), m(lambda x: x["tensor"]["max_idle_run"]),
                         m(lambda x: x["src"][3]["e2e_sum"] / max(1, x["src"][3]["rsp"])) if wl == "bench_system" else None,
                         m(lambda x: x["src"][3]["e2e_p99"]) if wl == "bench_system" else None,
                         m(lambda x: x["src"][0]["e2e_sum"] / max(1, x["src"][0]["rsp"]))))
f = lambda v, nd=0: "-" if v is None else f"{v:.{nd}f}"
out = ["# Outstanding-window shaping (MODELLED)\n\nThe three background sources (VECTOR, STREAMDMA, CLOUD) are limited to *L* transactions in flight each (`cfg_out_limit`; the default window is 8 per source); TENSOR and CONTROL keep the full window. "
       "Scheduler age limit 1024, seeds 1-3 (mean). *span* = cycles for the 24-tile tensor run; *tensor e2e* = mean offer -> response latency of the tensor requests.\n\n",
       "| L (background window) | policy | workload | runs | total B/cycle | tensor idle % | tensor span | longest tensor idle run | tensor e2e mean | CONTROL e2e mean | CONTROL e2e p99 |\n|---|---|---|---|---|---|---|---|---|---|---|\n"]
for r in rows:
    out.append(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {f(r[4], 2)} | {f(r[5], 1)} | {f(r[6])} | {f(r[7])} | {f(r[10])} | {f(r[8])} | {f(r[9])} |\n")
open(os.path.join(ROOT, "reports", "WINDOW_SHAPING.md"), "w").write("".join(out))
print("wrote reports/WINDOW_SHAPING.md")
