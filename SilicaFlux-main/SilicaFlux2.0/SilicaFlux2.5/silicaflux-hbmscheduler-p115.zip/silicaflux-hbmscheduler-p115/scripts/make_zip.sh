#!/usr/bin/env bash
# Package the delivery archive.  Writes MANIFEST.sha256 (every file) and dist/silicaflux-hbmscheduler-p115.zip.
# Nothing is committed to git; the archive is the only delivery.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
NAME=silicaflux-hbmscheduler-p115
cd "$ROOT"
mkdir -p dist
rm -f MANIFEST.sha256
find . -type f ! -path './build/*' ! -path './dist/*' ! -name 'MANIFEST.sha256' ! -name '*.pyc' ! -path '*/__pycache__/*' | sort | xargs sha256sum > MANIFEST.sha256
STAGE="$(mktemp -d)"
mkdir -p "$STAGE/$NAME"
tar -C "$ROOT" --exclude=./build --exclude=./dist --exclude='__pycache__' --exclude='*.pyc' -cf - . | tar -C "$STAGE/$NAME" -xf -
rm -f "$ROOT/dist/$NAME.zip"
(cd "$STAGE" && zip -qr "$ROOT/dist/$NAME.zip" "$NAME")
rm -rf "$STAGE"
echo "$ROOT/dist/$NAME.zip"
unzip -l "$ROOT/dist/$NAME.zip" | tail -1
