#!/usr/bin/env python3
"""Format reports/dse/*.json (run_dse.py) as reports/PARAM_STUDY.md."""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
POL = {1: "RDPRIO", 2: "FRFCFS", 3: "BANKAWARE"}
out = ["# Scheduler parameter study (MODELLED; tuned on seed 1 only)\n",
       "Each table: useful bytes per cycle on the default two-channel configuration; the policy, the swept parameter and the workload are in the row / column headers. "
       "Tuning used **seed 1 only**; the settings adopted afterwards are evaluated on the held-out seeds 2 and 3 in `BENCHMARKS.md`. The FCFS baseline does not depend on these parameters. "
       "A failed run (data / ordering check) would show `FAIL`; none occurred.\n"]
for tag, title in (("dse_age", "Starvation age limit `cfg_age_limit` (cycles)"), ("dse_byp", "Bypass cap `cfg_bypass_cap` (age limit 1024)")):
    p = os.path.join(ROOT, "reports", "dse", tag + ".json")
    if not os.path.exists(p):
        continue
    res = json.load(open(p))
    vals = sorted({r["value"] for r in res}, key=lambda x: int(x))
    wls = list(dict.fromkeys(r["workload"] for r in res))
    pols = sorted({r["policy"] for r in res})
    out.append(f"## {title}\n\n| workload | policy | " + " | ".join(str(v) for v in vals) + " |\n|---|---|" + "---|" * len(vals) + "\n")
    for w in wls:
        for pl in pols:
            row = []
            for v in vals:
                xs = [r["bpc"] for r in res if r["workload"] == w and r["policy"] == pl and r["value"] == v and r["pass"]]
                row.append(f"{sum(xs) / len(xs):.2f}" if xs else "FAIL")
            out.append(f"| {w} | {POL.get(pl, pl)} | " + " | ".join(row) + " |\n")
    out.append("\n")
open(os.path.join(ROOT, "reports", "PARAM_STUDY.md"), "w").write("".join(out))
print("wrote reports/PARAM_STUDY.md")
