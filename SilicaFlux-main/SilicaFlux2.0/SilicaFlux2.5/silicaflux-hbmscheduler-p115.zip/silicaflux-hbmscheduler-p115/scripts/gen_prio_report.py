#!/usr/bin/env python3
"""Arbiter-priority study: ControlCore latency and TensorCore starvation with and without arbiter priority classes."""
import json, os, statistics
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
def load(f):
    d = json.load(open(os.path.join(ROOT, "reports", "bench", f)))
    return [r for r in d["records"] if r["pass"]]
sets = {"round robin (no priority)": ("policies_final_age1024.json", "baseline_fcfs_final.json"),
        "CONTROL first, TENSOR second (+PRIO=1)": ("prio_control_first.json",),
        "TENSOR first, CONTROL second (+PRIO=2)": ("prio_tensor_first.json",)}
POL = {0: "FCFS", 3: "BANKAWARE"}
rows = []
for name, files in sets.items():
    recs = [r for f in files for r in load(f)]
    for pol in (0, 3):
        for wl in ("bench_ctrl_probe", "bench_tensor", "bench_system"):
            rs = [r["result"] for r in recs if r["policy"] == pol and r["workload"] == wl]
            if not rs:
                continue
            m = lambda f: statistics.fmean(f(x) for x in rs)
            c = lambda x: x["src"][3]
            t = lambda x: x["tensor"]
            rows.append((name, POL[pol], wl, len(rs), m(lambda x: x["bytes_per_cycle"]),
                         m(lambda x: c(x)["e2e_sum"] / max(1, c(x)["rsp"])) if wl != "bench_tensor" else None,
                         m(lambda x: c(x)["e2e_p99"]) if wl != "bench_tensor" else None,
                         m(lambda x: c(x)["e2e_max"]) if wl != "bench_tensor" else None,
                         m(lambda x: 100 * t(x)["starve_cycles"] / max(1, t(x)["span"])) if wl != "bench_ctrl_probe" else None,
                         m(lambda x: t(x)["span"]) if wl != "bench_ctrl_probe" else None))
f = lambda v, nd=0: "-" if v is None else f"{v:.{nd}f}"
out = ["# Arbiter priority study (MODELLED)\n\nPer-lane arbiter modes (`cfg_arb_mode`, `cfg_arb_prio`, `cfg_arb_age`), scheduler age limit 1024, seeds 1-3 (mean). *CONTROL e2e* = ControlCore probes, offer -> response; "
       "*tensor idle %* = consumer idle cycles / span of the 24-tile run; *span* = cycles for the 24 tiles. `-` = not applicable to the workload.\n",
       "| arbiter | policy | workload | runs | B/cycle | CONTROL e2e mean | CONTROL e2e p99 | CONTROL e2e max | tensor idle % | tensor span |\n|---|---|---|---|---|---|---|---|---|---|\n"]
for r in rows:
    out.append(f"| {r[0]} | {r[1]} | {r[2]} | {r[3]} | {f(r[4], 2)} | {f(r[5])} | {f(r[6])} | {f(r[7])} | {f(r[8], 1)} | {f(r[9])} |\n")
open(os.path.join(ROOT, "reports", "PRIORITY.md"), "w").write("".join(out))
print("wrote reports/PRIORITY.md")
