#!/usr/bin/env bash
# Build the system bench with Verilator.  usage: build_sim.sh <build-name> [-Gparam=value ...]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
RTL_DIR="${RTL_DIR:-$ROOT/rtl}"
NAME="$1"; shift
OUT="${BUILD_DIR:-$ROOT/build}/$NAME"
mkdir -p "$OUT"
verilator --binary --timing --timescale 1ns/1ps -O2 --unroll-stmts 2000 --unroll-count 256 -Wno-fatal -Wno-lint -Wno-style -Wno-MULTIDRIVEN -Wno-BLKSEQ -Wno-INITIALDLY \
  -Wno-WIDTH -Wno-CASEINCOMPLETE -Wno-UNOPTFLAT -Wno-LATCH \
  -I"$RTL_DIR" -I"$ROOT/model" -I"$ROOT/tb" \
  --top-module sf_hbm_tb \
  "$RTL_DIR"/sf_hbm_{address_map,req_check,channel_arbiter,read_queue,write_queue,scheduler,backend_adapter,maxsel,trk_slot,trk_src,response_tracker,perf,lane,sched_top}.sv \
  "$ROOT"/model/sf_hbm_mem_model.sv "$ROOT"/tb/sf_hbm_sfmc_check.sv "$ROOT"/tb/sf_hbm_tb.sv \
  -Mdir "$OUT" -o simx "$@" > "$OUT/build.log" 2>&1 || { tail -40 "$OUT/build.log"; exit 1; }
echo "$OUT/simx"
