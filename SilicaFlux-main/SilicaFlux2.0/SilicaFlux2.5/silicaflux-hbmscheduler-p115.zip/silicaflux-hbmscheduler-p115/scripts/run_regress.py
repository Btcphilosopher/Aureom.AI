#!/usr/bin/env python3
"""P115 regression runner.

  * builds every configuration of scripts/configs.json with Verilator (parallel),
  * runs the full scenario list (+TEST=all) for several seeds on each,
  * runs the independent timing checker on the memory model's command logs,
  * runs the address-map unit bench (4 map modes + profiles) and the illegal-
    geometry rejection tests,
  * runs the NEGATIVE check: a build that must FAIL (SFMC rule C9 violated while the
    scheduler is told to trust it),
  * writes reports/regression.json and reports/regression.md.

Nothing is reported as passing unless its RESULT line was seen; a build error, a
crash or a missing RESULT line is a failure.
"""
import argparse, concurrent.futures as cf, json, os, re, subprocess, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.environ.get("BUILD_DIR", os.path.join(ROOT, "build"))


def gflags(g):
    return [f"-G{k}={v}" for k, v in g.items()]


def build(name, g, extra=()):
    env = dict(os.environ, BUILD_DIR=BUILD)
    t0 = time.time()
    r = subprocess.run([os.path.join(ROOT, "scripts", "build_sim.sh"), name] + gflags(g) + list(extra),
                       capture_output=True, text=True, env=env)
    return name, r.returncode == 0, time.time() - t0, (r.stdout + r.stderr)[-2000:]


def run(name, args, timeout=3000):
    exe = os.path.join(BUILD, name, "simx")
    t0 = time.time()
    try:
        r = subprocess.run([exe] + args, capture_output=True, text=True, timeout=timeout)
        out = r.stdout + r.stderr
        rc = r.returncode
    except subprocess.TimeoutExpired as e:
        out, rc = "TIMEOUT", 124
    return rc, out, time.time() - t0


def parse(out):
    res = re.findall(r"RESULT: (PASS|FAIL) test=(\S+)(.*)", out)
    tests = [(t, v == "PASS", rest.strip()) for v, t, rest in res]
    allpass = "RESULT: ALL PASS" in out
    return tests, allpass


def timing_args(g):
    d = dict(DATA_W=128, BURST_LEN=2, BANK_W=2, T_REFI=3900, T_RFC=260, PROFILE=0)
    d.update(g)
    bl = d["BURST_LEN"]
    cl, cwl = 14, 7
    return ["--bl", str(bl), "--bank-bits", str(d["BANK_W"]), "--tCCD_S", str(bl), "--tCCD_L", str(bl + 2),
            "--tRTW", str(cl + bl + 2 - cwl), "--tREFI", str(d["T_REFI"]), "--tRFC", str(d["T_RFC"])]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="*", default=[1, 2, 3])
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--configs", nargs="*")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    ap.add_argument("--tag", default="regression")
    ap.add_argument("--no-build", action="store_true")
    a = ap.parse_args()
    cfgs = json.load(open(os.path.join(ROOT, "scripts", "configs.json")))
    if a.configs:
        cfgs = {k: v for k, v in cfgs.items() if k in a.configs}
    os.makedirs(a.out, exist_ok=True)
    report = {"configs": {}, "unit": {}, "negative": {}, "timing": {}, "illegal": {}}

    # ---------------------------------------------------------------- builds
    if not a.no_build:
        with cf.ThreadPoolExecutor(a.jobs) as ex:
            futs = [ex.submit(build, n, c["G"]) for n, c in cfgs.items()]
            futs.append(ex.submit(build, "neg_c9", {"BE_ORDER_SAFE": 1, "ORDER_VIOLATE": 1, "ORDER_MODE": 1, "RSP_JITTER": 20}))
            builds = {}
            for f in cf.as_completed(futs):
                n, ok, dt, log = f.result()
                builds[n] = ok
                print(f"build {n}: {'ok' if ok else 'FAILED'} ({dt:.0f}s)", flush=True)
                if not ok:
                    print(log)
    else:
        builds = {n: True for n in list(cfgs) + ["neg_c9"]}

    # ---------------------------------------------------------------- scenario runs
    for n, c in cfgs.items():
        ent = {"desc": c["desc"], "G": c["G"], "build": builds.get(n, False), "runs": []}
        if builds.get(n):
            for seed in a.seeds:
                rc, out, dt = run(n, [f"+TEST=all", f"+N={a.n}", f"+SEED={seed}"])
                tests, allpass = parse(out)
                ok = allpass and rc == 0 and len(tests) >= 23 and all(p for _, p, _ in tests)
                ent["runs"].append({"seed": seed, "pass": ok, "seconds": round(dt, 1), "tests": [(t, p) for t, p, _ in tests],
                                    "tail": "" if ok else out[-1500:]})
                print(f"run {n} seed {seed}: {'PASS' if ok else 'FAIL'} ({len(tests)} scenarios, {dt:.0f}s)", flush=True)
        report["configs"][n] = ent

    # ---------------------------------------------------------------- timing checker on the model's command logs
    for n in ("base", "pc2", "b64", "bl4"):
        if n not in cfgs or not builds.get(n):
            continue
        logbase = os.path.join(BUILD, n, "cmdlog")
        for f in os.listdir(os.path.join(BUILD, n)):
            if f.startswith("cmdlog.lane"):
                os.remove(os.path.join(BUILD, n, f))
        rc, out, _ = run(n, ["+TEST=rand_mixed", f"+N={a.n}", "+SEED=7", f"+CMDLOG={logbase}"])
        res = []
        for f in sorted(os.listdir(os.path.join(BUILD, n))):
            if f.startswith("cmdlog.lane"):
                p = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "check_timing_log.py"),
                                    os.path.join(BUILD, n, f)] + timing_args(cfgs[n]["G"]), capture_output=True, text=True)
                res.append({"log": f, "pass": p.returncode == 0, "out": p.stdout.strip().splitlines()[-3:]})
        report["timing"][n] = res
        print(f"timing {n}: {[r['pass'] for r in res]}", flush=True)

    # ---------------------------------------------------------------- negative: SFMC rule C9 violated, scheduler trusts it
    if builds.get("neg_c9"):
        fails = 0
        for seed in a.seeds:
            rc, out, _ = run("neg_c9", ["+TEST=hazard", f"+N={a.n}", f"+SEED={seed}"])
            fails += (rc != 0) or ("RESULT: FAIL" in out)
        report["negative"]["neg_c9"] = {"expected": "FAIL on every seed", "failed_seeds": fails, "seeds": len(a.seeds),
                                        "pass": fails == len(a.seeds)}
        print(f"negative neg_c9: failed {fails}/{len(a.seeds)} seeds (expected all)", flush=True)

    # ---------------------------------------------------------------- address-map unit bench + illegal geometry
    def unit(name, g):
        d = os.path.join(BUILD, "unit_" + name)
        os.makedirs(d, exist_ok=True)
        cmd = ["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-WIDTH",
               "-I" + os.path.join(ROOT, "rtl"), os.path.join(ROOT, "rtl/sf_hbm_address_map.sv"), os.path.join(ROOT, "tb/tb_addr_map.sv"),
               "--top-module", "tb_addr_map", "-Mdir", d, "-o", "sim"] + gflags(g)
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode:
            return False, r.stderr[-300:]
        r = subprocess.run([os.path.join(d, "sim")], capture_output=True, text=True)
        return r.returncode == 0 and "RESULT: PASS" in r.stdout, r.stdout.strip().splitlines()[-1] if r.stdout.strip() else r.stderr[-200:]

    ucfgs = {f"mode{m}": {"MAP_MODE": m} for m in range(4)}
    ucfgs.update({"pc2_mode0": {"NUM_PC": 2}, "ch4_mode1": {"NUM_CH": 4, "MAP_MODE": 1}, "ch1_mode2": {"NUM_CH": 1, "MAP_MODE": 2},
                  "hbm2": {"PROFILE": 1, "NUM_CH": 2, "NUM_PC": 2}, "hbm3_hash": {"PROFILE": 2, "NUM_CH": 2, "NUM_PC": 2, "MAP_MODE": 3},
                  "b64": {"BURST_BYTES": 64, "BG_W": 1, "BANK_W": 3, "ROW_W": 5}, "b16": {"BURST_BYTES": 16, "COL_W": 4}})
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        futs = {n: ex.submit(unit, n, g) for n, g in ucfgs.items()}
        for n, f in futs.items():
            ok, line = f.result()
            report["unit"][n] = {"pass": ok, "line": line}
            print(f"unit addr_map {n}: {'PASS' if ok else 'FAIL'}", flush=True)

    illegal = {
        "NUM_CH=3 (not a power of two)": {"NUM_CH": 3},
        "NUM_CH=64 (more than SIM_GENERIC allows)": {"NUM_CH": 64},
        "HBM2E profile with 16 channels": {"PROFILE": 1, "NUM_CH": 16, "NUM_PC": 2},
        "HBM2E profile with 1 pseudo-channel": {"PROFILE": 1, "NUM_PC": 1},
        "HBM3 profile with 64 B access": {"PROFILE": 2, "BURST_BYTES": 64, "NUM_PC": 2},
        "BURST_BYTES=48": {"BURST_BYTES": 48},
        "BURST_BYTES=256": {"BURST_BYTES": 256},
        "HBM2E profile with 3 banks bits": {"PROFILE": 1, "NUM_PC": 2, "BANK_W": 3},
        "COL_W=6 (page larger than the profile)": {"COL_W": 6},
        "ROW_W=15 on SIM_GENERIC": {"ROW_W": 15},
        "hashed map with ROW_W < BG_W+BANK_W": {"MAP_MODE": 3, "ROW_W": 3},
        "MAP_MODE=4": {"MAP_MODE": 4},
        "ADDR_W smaller than the window": {"ADDR_W": 16},
        "PROFILE=3": {"PROFILE": 3},
    }
    for desc, g in illegal.items():
        cmd = ["verilator", "--lint-only", "-I" + os.path.join(ROOT, "rtl"), os.path.join(ROOT, "rtl/sf_hbm_address_map.sv"),
               "--top-module", "sf_hbm_address_map"] + gflags(g)
        r = subprocess.run(cmd, capture_output=True, text=True)
        rejected = r.returncode != 0 and "sf_hbm_address_map:" in (r.stdout + r.stderr)
        report["illegal"][desc] = {"rejected": rejected, "message": next((l.strip() for l in (r.stdout + r.stderr).splitlines() if "sf_hbm_address_map:" in l), "")[:140]}
        print(f"illegal geometry [{desc}]: {'rejected' if rejected else 'NOT REJECTED'}", flush=True)
    # top-level parameter checks
    for desc, (g, needle) in {"OUT_PER_SRC=6": ({"OUT_PER_SRC": 6}, "OUT_PER_SRC must be a power of two"),
                              "NUM_SRC=0": ({"NUM_SRC": 0}, "NUM_SRC must be 1..16"),
                              "ORDER_MODE=2": ({"ORDER_MODE": 2}, "ORDER_MODE must be 0 or 1"),
                              "LANE_OUT=0": ({"LANE_OUT": 0}, "queue / outstanding depth out of range"),
                              "DATA_W=20": ({"DATA_W": 20}, "DATA_W must be a multiple of 8")}.items():
        rtl = [os.path.join(ROOT, "rtl", f"sf_hbm_{m}.sv") for m in
               "sched_top lane channel_arbiter read_queue write_queue scheduler maxsel backend_adapter trk_slot trk_src response_tracker perf address_map req_check".split()]
        cmd = ["verilator", "--lint-only", "-Wno-fatal", "-I" + os.path.join(ROOT, "rtl")] + rtl + ["--top-module", "sf_hbm_sched_top"] + gflags(g)
        r = subprocess.run(cmd, capture_output=True, text=True)
        txt = r.stdout + r.stderr
        rejected = needle in txt
        report["illegal"][desc] = {"rejected": bool(rejected), "message": next((l.strip() for l in txt.splitlines() if "sf_hbm_sched_top:" in l), "")[:140]}
        print(f"illegal top parameter [{desc}]: {'rejected' if rejected else 'NOT REJECTED'}", flush=True)

    # ---------------------------------------------------------------- verdict
    ok = True
    for n, e in report["configs"].items():
        ok &= e["build"] and all(r["pass"] for r in e["runs"]) and len(e["runs"]) == len(a.seeds)
    ok &= all(r["pass"] for v in report["timing"].values() for r in v)
    ok &= all(v["pass"] for v in report["negative"].values())
    ok &= all(v["pass"] for v in report["unit"].values())
    ok &= all(v["rejected"] for v in report["illegal"].values())
    report["all_pass"] = bool(ok)
    def scrub(x):                                   # no absolute build-machine paths in the delivered reports
        if isinstance(x, str): return x.replace(ROOT + os.sep, "").replace(BUILD + os.sep, "build" + os.sep)
        if isinstance(x, list): return [scrub(i) for i in x]
        if isinstance(x, dict): return {k: scrub(v) for k, v in x.items()}
        return x
    report = scrub(report)
    json.dump(report, open(os.path.join(a.out, a.tag + ".json"), "w"), indent=1)
    with open(os.path.join(a.out, a.tag + ".md"), "w") as f:
        f.write(f"# Regression ({a.tag})\n\nseeds {a.seeds}, N={a.n} requests per source per scenario\n\n")
        f.write("| config | description | build | seeds passed | scenarios per run |\n|---|---|---|---|---|\n")
        for n, e in report["configs"].items():
            ps = sum(1 for r in e["runs"] if r["pass"])
            f.write(f"| {n} | {e['desc']} | {'ok' if e['build'] else 'FAILED'} | {ps}/{len(e['runs'])} | {len(e['runs'][0]['tests']) if e['runs'] else 0} |\n")
        f.write("\n## Independent timing checker (model command logs)\n\n| config | lane logs | result |\n|---|---|---|\n")
        for n, v in report["timing"].items():
            f.write(f"| {n} | {len(v)} | {'PASS' if all(r['pass'] for r in v) else 'FAIL'} |\n")
        f.write("\n## Negative test\n\n")
        for n, v in report["negative"].items():
            f.write(f"* `{n}`: {v['expected']} -> failed {v['failed_seeds']}/{v['seeds']} seeds: {'as expected' if v['pass'] else 'UNEXPECTED'}\n")
        f.write("\n## Address-map unit bench\n\n| config | result | detail |\n|---|---|---|\n")
        for n, v in report["unit"].items():
            f.write(f"| {n} | {'PASS' if v['pass'] else 'FAIL'} | {v['line']} |\n")
        f.write("\n## Illegal geometry / parameter rejection (elaboration time)\n\n| case | rejected | message |\n|---|---|---|\n")
        for n, v in report["illegal"].items():
            f.write(f"| {n} | {'yes' if v['rejected'] else '**NO**'} | {v['message']} |\n")
        f.write(f"\n**Overall: {'ALL PASS' if ok else 'FAILURES'}**\n")
    print("OVERALL:", "ALL PASS" if ok else "FAILURES")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
