#!/usr/bin/env python3
"""Build the channel-scaling configurations (all with MAP_MODE 0 so only the lane count changes)."""
import concurrent.futures as cf, json, os, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.environ.get("BUILD_DIR", os.path.join(ROOT, "build"))
cfgs = json.load(open(os.path.join(ROOT, "scripts", "scale_configs.json")))
def b(item):
    n, c = item
    r = subprocess.run([os.path.join(ROOT, "scripts", "build_sim.sh"), n] + [f"-G{k}={v}" for k, v in c["G"].items()],
                       capture_output=True, text=True, env=dict(os.environ, BUILD_DIR=BUILD))
    return n, r.returncode == 0
with cf.ThreadPoolExecutor(3) as ex:
    res = list(ex.map(b, cfgs.items()))
for n, ok in res:
    print(n, "ok" if ok else "FAILED")
sys.exit(0 if all(ok for _, ok in res) else 1)
