#!/usr/bin/env python3
"""RTL mutation check.

One deliberate bug at a time is injected into a COPY of the RTL (the originals are never
touched), the system bench is rebuilt on the configuration where the bug is observable, and
the full scenario list is run.  A mutant is KILLED if any scenario fails, the simulator
crashes or times out; it SURVIVES if every scenario passes.  A mutant whose edit does not
apply or whose build fails is INVALID (never counted as killed).

This measures the strength of the BENCH (does it notice real bugs?), not the correctness of
the RTL.  Survivors are analysed by hand in reports/mutation.md.
"""
import argparse, concurrent.futures as cf, json, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORK = os.environ.get("MUT_DIR", os.path.join(ROOT, "build", "mutation"))

# name, file, old, new, config (name in scripts/configs.json), what it breaks
M = [
 ("raw_mask_dropped",      "sf_hbm_read_queue.sv",  "dep_q[free_idx] <= hit_o;", "dep_q[free_idx] <= '0;", "base", "RAW hazard: a read may pass an older write to the same granule"),
 ("war_mask_dropped",      "sf_hbm_write_queue.sv", "depo_q[free_idx] <= hit_o;", "depo_q[free_idx] <= '0;", "base", "WAR hazard: a write may pass an older read of the same granule"),
 ("waw_mask_dropped",      "sf_hbm_write_queue.sv", "deps_q[free_idx] <= hit_s;", "deps_q[free_idx] <= '0;", "base", "WAW hazard: two writes to one granule may swap"),
 ("order_disabled",        "sf_hbm_trk_slot.sv",    "blocked = |(ord_q & sm & ~gone_i);", "blocked = 1'b0;", "base", "responses delivered as soon as complete (no re-ordering)"),
 ("order_mode1_no_order",  "sf_hbm_trk_slot.sv",    "sm[j] = (ORDER_MODE == 0) ? 1'b1 : (ids_i[j*ID_W +: ID_W] == id_q);", "sm[j] = (ORDER_MODE == 0) ? 1'b1 : 1'b0;", "ord1", "same-id ordering not enforced in ORDER_MODE 1"),
 ("no_zombie",             "sf_hbm_trk_slot.sv",    "(tz_q && !late_n) ? S_ZOMBIE : S_FREE", "S_FREE", "base", "timed-out slot freed at once: a late response can hit a re-allocated slot"),
 ("timeout_never",         "sf_hbm_trk_slot.sv",    "(ts_i - tiss_q) >= cfg_timeout", "(ts_i - tiss_q) >= (cfg_timeout + 32'h10000000)", "base", "timeout never fires"),
 ("flush_ignored",         "sf_hbm_trk_slot.sv",    "if (flush[l] && lane_q == l[LANE_IW-1:0]) flsh = 1'b1;", "if (1'b0) flsh = 1'b1;", "base", "link flush does not fail in-flight transactions"),
 ("read_beat_index",       "sf_hbm_trk_slot.sv",    "beat_wr = 1'b1; beat_ix = beat_q; end", "beat_wr = 1'b1; beat_ix = '0; end", "base", "all read beats land in beat 0"),
 ("ue_never_reported",     "sf_hbm_trk_slot.sv",    "if (f_ue_n)       stat_n", "if (f_ue_n && 1'b0) stat_n", "base", "uncorrectable ECC reported as another status"),
 ("wdata_beat_order",      "sf_hbm_backend_adapter.sv", "wd_line[beat_q*DATA_W +: DATA_W]", "wd_line[(BURST_LEN-1-beat_q)*DATA_W +: DATA_W]", "base", "write beats reversed"),
 ("wstrb_beat0",           "sf_hbm_backend_adapter.sv", "wd_strb[beat_q*BSTRB_W +: BSTRB_W]", "wd_strb[0 +: BSTRB_W]", "base", "byte enables of beat 0 used for every beat"),
 ("out_counter_stuck",     "sf_hbm_backend_adapter.sv", "assign dec_w   = {{OCNT_W{1'b0}}, dec_n};", "assign dec_w   = '0;", "base", "outstanding counter never decrements"),
 ("out_counter_one_dec",   "sf_hbm_backend_adapter.sv", "assign dec_n   = {1'b0, done_rd} + {1'b0, done_wr};", "assign dec_n   = {1'b0, done_rd | done_wr};", "ord1", "REVIEW FINDING 1 re-introduced: one decrement when a read-last and a write response coincide"),
 ("flush_zombie_reintro",  "sf_hbm_trk_slot.sv",    "if (flsh && tz_q) late_n = 1'b1;", "if (1'b0) late_n = 1'b1;", "base", "REVIEW FINDING 2 re-introduced: flushed timed-out slot becomes a permanent zombie"),
 ("fcfs_no_fallback",      "sf_hbm_scheduler.sv",   "if (fc_blk && oldest_v) begin", "if (1'b0) begin", "base", "REVIEW FINDING 3 re-introduced: FCFS waits for a hazard-blocked oldest entry (deadlock after age saturation)"),
 ("cmd_len_wrong",         "sf_hbm_backend_adapter.sv", "assign mc_cmd_len   = BURST_LEN[7:0] - 8'd1;", "assign mc_cmd_len   = BURST_LEN[7:0];", "base", "SFMC command length off by one"),
 ("issue_ignores_link",    "sf_hbm_backend_adapter.sv", "assign mc_cmd_valid = link_ready && (cmd_cnt != '0);", "assign mc_cmd_valid = (cmd_cnt != '0);", "base", "commands presented while the controller is not ready"),
 ("tag_swapped",           "sf_hbm_lane.sv",        "assign iss_tag_w = pick_wr ? wq_pop_tag : rq_pop_tag;", "assign iss_tag_w = pick_wr ? rq_pop_tag : wq_pop_tag;", "base", "tag of the wrong queue travels to the backend"),
 ("arb_wdata_source0",     "sf_hbm_lane.sv",        "e_data = in_wdata[gnt_i*LINE_W +: LINE_W];", "e_data = in_wdata[0 +: LINE_W];", "base", "write data of source 0 stored for every source"),
 ("inflight_mask_dropped", "sf_hbm_lane.sv",        "if (inf_v[j] && inf_we[j] && inf_ga[j] == rq_ga[i*GA_W +: GA_W]) rq_blk[i] = 1'b1;", "if (inf_v[j] && inf_we[j] && inf_ga[j] == rq_ga[i*GA_W +: GA_W]) rq_blk[i] = 1'b0;", "unsafe", "BE_ORDER_SAFE=0: reads no longer wait for in-flight writes"),
 ("wq_wrong_data",         "sf_hbm_write_queue.sv", "pop_data = dat_q[pop_idx];", "pop_data = dat_q[0];", "base", "issued write carries the data of entry 0"),
 ("addr_bg_flipped",       "sf_hbm_address_map.sv", "bg_o     = bg_raw;", "bg_o     = bg_raw ^ {{(BG_W-1){1'b0}}, 1'b1};", "base", "bank-group bit flipped in the lane-local address"),
 ("align_check_removed",   "sf_hbm_req_check.sv",   "end else if (!aligned_i) begin", "end else if (1'b0) begin", "base", "misaligned requests accepted"),
 ("perm_rw_swapped",       "sf_hbm_req_check.sv",   "(we_i ? 1 : 0)]) begin", "(we_i ? 0 : 1)]) begin", "base", "read / write permission bits swapped"),
 ("fcfs_youngest_first",   "sf_hbm_scheduler.sv",   "fc_oldest_is_wr = bvw_v && (!bvr_v || bvw_k > bvr_k);", "fc_oldest_is_wr = bvw_v && (!bvr_v || bvw_k < bvr_k);", "base", "FCFS picks the younger queue head"),
 ("sched_ignores_deps",    "sf_hbm_scheduler.sv",   "elig_r[i] = rq_ready[i] && !rq_blk[i] && iss_ok_rd;", "elig_r[i] = rq_valid[i] && !rq_blk[i] && iss_ok_rd;", "base", "policies 1-3 issue reads whose dependency has not issued"),
 ("perf_wbytes_missing",   "sf_hbm_sched_top.sv",   "n_wby = n_wby + {{(32-BYTES_W){1'b0}}, ev_wbytes[s*BYTES_W +: BYTES_W]};", "n_wby = n_wby;", "base", "write bytes not counted"),
]


def build_and_run(mut, cfgs, seeds, n):
    name, fn, old, new, cfg, why = mut
    d = os.path.join(WORK, name)
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(os.path.join(d, "rtl"))
    for f in os.listdir(os.path.join(ROOT, "rtl")):
        shutil.copy(os.path.join(ROOT, "rtl", f), os.path.join(d, "rtl", f))
    src = open(os.path.join(d, "rtl", fn)).read()
    rec = {"name": name, "file": fn, "config": cfg, "why": why, "old": old, "new": new}
    if src.count(old) != 1:
        rec.update(status="INVALID", detail=f"edit target occurs {src.count(old)} times")
        return rec
    open(os.path.join(d, "rtl", fn), "w").write(src.replace(old, new))
    env = dict(os.environ, RTL_DIR=os.path.join(d, "rtl"), BUILD_DIR=os.path.join(d, "b"))
    g = [f"-G{k}={v}" for k, v in cfgs[cfg]["G"].items()]
    b = subprocess.run([os.path.join(ROOT, "scripts", "build_sim.sh"), cfg] + g, capture_output=True, text=True, env=env)
    if b.returncode != 0:
        rec.update(status="INVALID", detail="build failed: " + (b.stdout + b.stderr)[-300:])
        return rec
    exe = os.path.join(d, "b", cfg, "simx")
    killers = []
    for sd in seeds:
        try:
            r = subprocess.run([exe, "+TEST=all", f"+N={n}", f"+SEED={sd}"], capture_output=True, text=True, timeout=600)
            out = r.stdout + r.stderr
            rc = r.returncode
        except subprocess.TimeoutExpired:
            out, rc = "", 124
        fails = re.findall(r"RESULT: FAIL test=(\S+)", out)
        ok = rc == 0 and "RESULT: ALL PASS" in out and not fails
        if not ok:
            killers.append({"seed": sd, "rc": rc, "scenarios": sorted(set(fails)) or (["TIMEOUT"] if rc == 124 else ["crash/other"])})
            break
    rec.update(status="KILLED" if killers else "SURVIVED", killers=killers)
    shutil.rmtree(os.path.join(d, "b"), ignore_errors=True)
    return rec


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, nargs="+", default=[1, 2, 3])
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--out", default=os.path.join(ROOT, "reports"))
    a = ap.parse_args()
    cfgs = json.load(open(os.path.join(ROOT, "scripts", "configs.json")))
    muts = [m for m in M if not a.only or m[0] in a.only]
    os.makedirs(WORK, exist_ok=True)
    res = []
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        for r in ex.map(lambda m: build_and_run(m, cfgs, a.seeds, a.n), muts):
            res.append(r)
            print(f"{r['status']:9s} {r['name']:24s} [{r['config']}] {r.get('killers', [{}])[0].get('scenarios', '') if r.get('killers') else r.get('detail', '')}", flush=True)
    kill = sum(1 for r in res if r["status"] == "KILLED")
    inv = sum(1 for r in res if r["status"] == "INVALID")
    sur = [r for r in res if r["status"] == "SURVIVED"]
    json.dump({"mutants": res, "killed": kill, "invalid": inv, "survived": len(sur)}, open(os.path.join(a.out, "mutation.json"), "w"), indent=1)
    with open(os.path.join(a.out, "mutation.md"), "w") as f:
        f.write(f"# RTL mutation check\n\n{len(res)} injected bugs (one at a time, on a copy of the RTL), full scenario list, seeds {a.seeds}: "
                f"**{kill} killed, {len(sur)} survived, {inv} invalid** (invalid = edit did not apply / mutant did not build; never counted as killed).\n\n"
                "| mutant | file | config | what it breaks | result | killed by |\n|---|---|---|---|---|---|\n")
        for r in res:
            k = ", ".join(r["killers"][0]["scenarios"]) if r.get("killers") else (r.get("detail", "") if r["status"] == "INVALID" else "-")
            f.write(f"| {r['name']} | {r['file']} | {r['config']} | {r['why']} | {r['status']} | {k} |\n")
        f.write("\nAnalysis of the result (survivors, margins, what is not covered): reports/mutation_analysis.md.\n")
    print(f"mutation: {kill} killed, {len(sur)} survived, {inv} invalid of {len(res)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
