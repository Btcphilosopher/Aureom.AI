# Scheduler parameter study (MODELLED; tuned on seed 1 only)
Each table: useful bytes per cycle on the default two-channel configuration; the policy, the swept parameter and the workload are in the row / column headers. Tuning used **seed 1 only**; the settings adopted afterwards are evaluated on the held-out seeds 2 and 3 in `BENCHMARKS.md`. The FCFS baseline does not depend on these parameters. A failed run (data / ordering check) would show `FAIL`; none occurred.
## Starvation age limit `cfg_age_limit` (cycles)

| workload | policy | 256 | 512 | 1024 | 2048 | 4000 |
|---|---|---|---|---|---|---|
| bench_seq_rd | FRFCFS | 15.44 | 15.18 | 15.42 | 15.42 | 15.42 |
| bench_seq_rd | BANKAWARE | 18.72 | 19.54 | 19.72 | 19.72 | 19.72 |
| bench_seq_mix | FRFCFS | 10.73 | 10.89 | 10.82 | 10.82 | 10.82 |
| bench_seq_mix | BANKAWARE | 11.30 | 11.42 | 11.12 | 11.12 | 11.12 |
| bench_rand_mix | FRFCFS | 4.58 | 4.50 | 4.57 | 4.57 | 4.57 |
| bench_rand_mix | BANKAWARE | 4.78 | 4.78 | 4.85 | 4.85 | 4.85 |
| bench_rowmix | FRFCFS | 2.22 | 2.86 | 2.98 | 3.00 | 3.00 |
| bench_rowmix | BANKAWARE | 2.23 | 3.10 | 3.19 | 3.11 | 3.11 |
| bench_tensor | FRFCFS | 6.24 | 6.30 | 6.26 | 6.26 | 6.26 |
| bench_tensor | BANKAWARE | 6.28 | 6.55 | 6.41 | 6.25 | 6.25 |
| bench_system | FRFCFS | 6.01 | 6.20 | 6.25 | 6.23 | 6.23 |
| bench_system | BANKAWARE | 6.10 | 6.16 | 6.25 | 6.39 | 6.39 |
| bench_seq_rd_aligned | FRFCFS | 1.60 | 5.03 | 5.03 | 5.03 | 5.03 |
| bench_seq_rd_aligned | BANKAWARE | 1.60 | 5.03 | 5.03 | 5.03 | 5.03 |

## Bypass cap `cfg_bypass_cap` (age limit 1024)

| workload | policy | 0 | 2 | 4 | 8 | 16 | 32 | 63 |
|---|---|---|---|---|---|---|---|---|
| bench_seq_rd | FRFCFS | 15.42 | 15.70 | 15.04 | 15.18 | 15.13 | 15.09 | 15.55 |
| bench_seq_rd | BANKAWARE | 19.72 | 20.66 | 19.95 | 19.84 | 19.93 | 19.61 | 19.44 |
| bench_seq_wr | FRFCFS | 15.97 | 16.10 | 15.91 | 15.72 | 15.70 | 15.59 | 15.30 |
| bench_seq_wr | BANKAWARE | 21.97 | 22.70 | 22.56 | 22.35 | 22.33 | 22.16 | 21.42 |
| bench_seq_mix | FRFCFS | 10.82 | 7.04 | 8.46 | 9.64 | 10.80 | 10.80 | 10.82 |
| bench_seq_mix | BANKAWARE | 11.12 | 7.51 | 8.74 | 10.09 | 11.16 | 11.29 | 11.12 |
| bench_rand_mix | FRFCFS | 4.57 | 4.33 | 4.49 | 4.50 | 4.51 | 4.57 | 4.57 |
| bench_rand_mix | BANKAWARE | 4.85 | 4.67 | 4.71 | 4.83 | 4.84 | 4.86 | 4.85 |
| bench_rowmix | FRFCFS | 2.98 | 2.58 | 2.87 | 2.96 | 2.95 | 2.97 | 2.98 |
| bench_rowmix | BANKAWARE | 3.19 | 2.65 | 3.00 | 2.99 | 3.17 | 3.14 | 3.19 |
| bench_vector | FRFCFS | 5.59 | 5.57 | 5.59 | 5.69 | 5.65 | 5.59 | 5.59 |
| bench_vector | BANKAWARE | 5.68 | 5.54 | 5.61 | 5.70 | 5.57 | 5.68 | 5.68 |
| bench_tensor | FRFCFS | 6.26 | 5.13 | 5.62 | 5.94 | 6.18 | 6.23 | 6.31 |
| bench_tensor | BANKAWARE | 6.41 | 5.29 | 5.59 | 5.98 | 6.27 | 6.39 | 6.42 |
| bench_system | FRFCFS | 6.25 | 5.07 | 5.65 | 6.00 | 6.02 | 6.16 | 6.19 |
| bench_system | BANKAWARE | 6.25 | 5.33 | 5.65 | 5.95 | 6.03 | 6.31 | 6.37 |

