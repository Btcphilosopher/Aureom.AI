# Outstanding-window shaping (MODELLED)

The three background sources (VECTOR, STREAMDMA, CLOUD) are limited to *L* transactions in flight each (`cfg_out_limit`; the default window is 8 per source); TENSOR and CONTROL keep the full window. Scheduler age limit 1024, seeds 1-3 (mean). *span* = cycles for the 24-tile tensor run; *tensor e2e* = mean offer -> response latency of the tensor requests.

| L (background window) | policy | workload | runs | total B/cycle | tensor idle % | tensor span | longest tensor idle run | tensor e2e mean | CONTROL e2e mean | CONTROL e2e p99 |
|---|---|---|---|---|---|---|---|---|---|---|
| 8 | FCFS | bench_tensor | 3 | 5.08 | 83.0 | 88412 | 4420 | 229 | - | - |
| 8 | FCFS | bench_system | 3 | 4.98 | 85.4 | 106755 | 5052 | 276 | 249 | 600 |
| 8 | BANKAWARE | bench_tensor | 3 | 6.42 | 71.2 | 48279 | 2237 | 124 | - | - |
| 8 | BANKAWARE | bench_system | 3 | 6.32 | 72.6 | 51432 | 2388 | 132 | 195 | 696 |
| 4 | FCFS | bench_tensor | 3 | 5.03 | 74.0 | 56613 | 3133 | 146 | - | - |
| 4 | FCFS | bench_system | 3 | 4.95 | 78.3 | 69448 | 3957 | 179 | 170 | 507 |
| 4 | BANKAWARE | bench_tensor | 3 | 5.59 | 69.2 | 46403 | 2277 | 119 | - | - |
| 4 | BANKAWARE | bench_system | 3 | 5.63 | 71.0 | 49183 | 2021 | 126 | 150 | 477 |
| 2 | FCFS | bench_tensor | 3 | 5.73 | 61.6 | 35850 | 1495 | 91 | - | - |
| 2 | FCFS | bench_system | 3 | 5.27 | 70.3 | 47149 | 1878 | 121 | 118 | 419 |
| 2 | BANKAWARE | bench_tensor | 3 | 5.63 | 62.5 | 36690 | 1890 | 93 | - | - |
| 2 | BANKAWARE | bench_system | 3 | 5.49 | 67.9 | 43116 | 1839 | 110 | 115 | 420 |
| 1 | FCFS | bench_tensor | 3 | 5.98 | 49.6 | 26789 | 1086 | 68 | - | - |
| 1 | FCFS | bench_system | 3 | 5.49 | 61.2 | 34964 | 1468 | 89 | 95 | 392 |
| 1 | BANKAWARE | bench_tensor | 3 | 5.98 | 49.6 | 26789 | 1086 | 68 | - | - |
| 1 | BANKAWARE | bench_system | 3 | 5.61 | 59.9 | 33774 | 1322 | 86 | 94 | 369 |
