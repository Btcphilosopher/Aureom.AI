# Regression (regression)

seeds [1, 2, 3], N=300 requests per source per scenario

| config | description | build | seeds passed | scenarios per run |
|---|---|---|---|---|
| base | two logical channels, SIM_GENERIC profile, per-source in-order responses | ok | 3/3 | 32 |
| ord1 | same-id ordering, jittered / interleaving backend | ok | 3/3 | 32 |
| ord0j | strict ordering over a jittered / interleaving backend | ok | 3/3 | 32 |
| sat | tiny queues + slow command acceptance (saturation) | ok | 3/3 | 32 |
| pc2 | 2 channels x 2 pseudo-channels = 4 lanes | ok | 3/3 | 32 |
| ch4 | 4 channels, bank-interleaved map | ok | 3/3 | 32 |
| ch1 | single channel, page-interleaved map | ok | 3/3 | 32 |
| hash | hashed bank map | ok | 3/3 | 32 |
| hbm2 | HBM2E-style illustrative profile, 4 ch x 2 pc | ok | 3/3 | 32 |
| bl4 | 64-bit beats x 4 = 32 B access, shallow queues | ok | 3/3 | 32 |
| w256 | 256-bit single-beat access | ok | 3/3 | 32 |
| b64 | 64 B access granule | ok | 3/3 | 32 |
| unsafe | backend WITHOUT SFMC rule C9 (reorders same-address accesses) + in-flight hazard hold | ok | 3/3 | 32 |

## Independent timing checker (model command logs)

| config | lane logs | result |
|---|---|---|
| base | 2 | PASS |
| pc2 | 4 | PASS |
| b64 | 2 | PASS |
| bl4 | 2 | PASS |

## Negative test

* `neg_c9`: FAIL on every seed -> failed 3/3 seeds: as expected

## Address-map unit bench

| config | result | detail |
|---|---|---|
| mode0 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| mode1 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| mode2 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| mode3 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| pc2_mode0 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| ch4_mode1 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| ch1_mode2 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| hbm2 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| hbm3_hash | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| b64 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |
| b16 | PASS | - tb/tb_addr_map.sv:116: Verilog $finish |

## Illegal geometry / parameter rejection (elaboration time)

| case | rejected | message |
|---|---|---|
| NUM_CH=3 (not a power of two) | yes | %Warning-USERERROR: rtl/sf_h |
| NUM_CH=64 (more than SIM_GENERIC allows) | yes | %Warning-USERERROR: rtl/sf_h |
| HBM2E profile with 16 channels | yes | %Warning-USERERROR: rtl/sf_h |
| HBM2E profile with 1 pseudo-channel | yes | %Warning-USERERROR: rtl/sf_h |
| HBM3 profile with 64 B access | yes | %Warning-USERERROR: rtl/sf_h |
| BURST_BYTES=48 | yes | %Warning-USERERROR: rtl/sf_h |
| BURST_BYTES=256 | yes | %Warning-USERERROR: rtl/sf_h |
| HBM2E profile with 3 banks bits | yes | %Warning-USERERROR: rtl/sf_h |
| COL_W=6 (page larger than the profile) | yes | %Warning-USERERROR: rtl/sf_h |
| ROW_W=15 on SIM_GENERIC | yes | %Warning-USERERROR: rtl/sf_h |
| hashed map with ROW_W < BG_W+BANK_W | yes | %Warning-USERERROR: rtl/sf_h |
| MAP_MODE=4 | yes | %Warning-USERERROR: rtl/sf_h |
| ADDR_W smaller than the window | yes | %Warning-USERERROR: rtl/sf_h |
| PROFILE=3 | yes | %Warning-USERERROR: rtl/sf_h |
| OUT_PER_SRC=6 | yes | %Warning-USERERROR: rtl/sf_h |
| NUM_SRC=0 | yes | %Warning-USERERROR: rtl/sf_h |
| ORDER_MODE=2 | yes | %Warning-USERERROR: rtl/sf_h |
| LANE_OUT=0 | yes | %Warning-USERERROR: rtl/sf_h |
| DATA_W=20 | yes | %Warning-USERERROR: rtl/sf_h |

**Overall: ALL PASS**
