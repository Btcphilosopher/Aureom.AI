# Scheduling-policy study (tuned: age limit 1024) (all numbers MODELLED)

Configuration `base`.  Baseline = policy 0 (FCFS), measured first and frozen (`BASELINE_FCFS.md`). Policies: 0=FCFS, 1=RDPRIO, 2=FRFCFS, 3=BANKAWARE.

* run `baseline_fcfs_final` (config `base`, policies [0], seeds [1, 2, 3], N=2000 requests / source), binary sha256 `dac33209e995e5d3`, bench sha256 `2b4a524ee3920012`, created 2026-11-20 17:50:31
* run `policies_final_age1024` (config `base`, policies [1, 2, 3], seeds [1, 2, 3], N=2000 requests / source), binary sha256 `dac33209e995e5d3`, bench sha256 `2b4a524ee3920012`, created 2026-11-20 17:54:52

## Useful throughput (bytes per cycle; seeds: mean (min..max))

| workload | FCFS B/cyc | RDPRIO B/cyc | FRFCFS B/cyc | BANKAWARE B/cyc | RDPRIO vs FCFS | FRFCFS vs FCFS | BANKAWARE vs FCFS |
|---|---|---|---|---|---|---|---|
| bench_seq_rd | 22.52 | 22.52 | 15.42 | 19.72 | +0.0 % | -31.5 % | -12.4 % |
| bench_seq_wr | 22.74 | 22.74 | 15.97 | 21.97 | +0.0 % | -29.8 % | -3.4 % |
| bench_seq_mix | 8.77 | 10.97 | 10.82 | 11.12 | +25.1 % | +23.4 % | +26.9 % |
| bench_seq_rd_aligned | 1.27 | 1.27 | 5.03 | 5.03 | +0.0 % | +295.4 % | +295.4 % |
| bench_rand_rd | 5.04 (5.01..5.06) | 5.04 (5.01..5.06) | 5.08 (5.06..5.09) | 5.61 (5.57..5.64) | +0.0 % | +0.7 % | +11.4 % |
| bench_rand_mix | 4.45 (4.44..4.47) | 4.57 (4.52..4.60) | 4.59 (4.57..4.63) | 4.86 (4.83..4.89) | +2.6 % | +3.2 % | +9.1 % |
| bench_rowmix | 2.14 (2.13..2.14) | 1.87 (1.86..1.88) | 2.99 (2.98..3.00) | 3.13 (3.07..3.19) | -12.7 % | +40.0 % | +46.4 % |
| bench_rowwalk | 5.69 (5.68..5.70) | 2.77 (2.76..2.78) | 2.77 (2.76..2.78) | 3.22 (3.20..3.24) | -51.3 % | -51.3 % | -43.4 % |
| bench_hotbank | 0.80 (0.80..0.80) | 0.81 (0.81..0.81) | 2.22 (2.17..2.30) | 2.22 (2.17..2.30) | +1.1 % | +178.3 % | +178.3 % |
| bench_vector | 4.80 (4.75..4.85) | 5.53 (5.41..5.69) | 5.61 (5.58..5.68) | 5.75 (5.68..5.83) | +15.4 % | +17.1 % | +19.8 % |
| bench_dma_copy | 2.56 | 2.56 | 2.56 | 2.56 | +0.0 % | +0.0 % | +0.0 % |
| bench_tensor_alone | 8.24 | 8.24 | 8.24 | 8.24 | +0.0 % | +0.0 % | +0.0 % |
| bench_tensor | 5.08 (5.00..5.13) | 5.70 (5.57..5.79) | 6.26 (6.24..6.27) | 6.42 (6.40..6.45) | +12.3 % | +23.2 % | +26.5 % |
| bench_ctrl_probe | 4.90 (4.90..4.91) | 5.11 (4.90..5.29) | 5.86 (5.80..5.97) | 6.06 (5.97..6.16) | +4.2 % | +19.4 % | +23.6 % |
| bench_system | 4.98 (4.95..5.03) | 5.54 (5.48..5.58) | 6.28 (6.25..6.33) | 6.32 (6.25..6.37) | +11.3 % | +26.1 % | +27.1 % |

## Request latency, accept -> response (cycles)

| workload | FCFS mean / p99 | RDPRIO mean / p99 | FRFCFS mean / p99 | BANKAWARE mean / p99 |
|---|---|---|---|---|
| bench_seq_rd | 56 / 359 | 56 / 359 | 81 / 515 | 63 / 403 |
| bench_seq_wr | 55 / 363 | 55 / 363 | 78 / 462 | 56 / 393 |
| bench_seq_mix | 145 / 452 | 114 / 453 | 115 / 431 | 110 / 464 |
| bench_seq_rd_aligned | 1003 / 1246 | 1003 / 1246 | 253 / 541 | 253 / 541 |
| bench_rand_rd | 249 / 588 | 249 / 588 | 247 / 595 | 224 / 554 |
| bench_rand_mix | 285 / 643 | 277 / 699 | 275 / 731 | 260 / 688 |
| bench_rowmix | 441 / 846 | 613 / 1252 | 411 / 1073 | 392 / 1007 |
| bench_rowwalk | 224 / 523 | 454 / 1075 | 454 / 1075 | 392 / 910 |
| bench_hotbank | 1183 / 1685 | 1230 / 1710 | 558 / 1234 | 558 / 1234 |
| bench_vector | 158 / 518 | 129 / 462 | 126 / 450 | 124 / 452 |
| bench_dma_copy | 199 / 494 | 199 / 494 | 199 / 494 | 199 / 494 |
| bench_tensor_alone | 24 / 48 | 24 / 48 | 24 / 48 | 24 / 48 |
| bench_tensor | 200 / 539 | 178 / 565 | 162 / 608 | 158 / 600 |
| bench_ctrl_probe | 246 / 612 | 227 / 664 | 199 / 720 | 191 / 662 |
| bench_system | 242 / 587 | 208 / 650 | 185 / 706 | 183 / 698 |

## Row-buffer behaviour (backend-reported)

| workload | FCFS hit % / conflict % | RDPRIO hit % / conflict % | FRFCFS hit % / conflict % | BANKAWARE hit % / conflict % |
|---|---|---|---|---|
| bench_seq_rd | 96.6 / 2.2 | 96.6 / 2.2 | 96.4 / 1.7 | 96.6 / 2.0 |
| bench_seq_wr | 96.5 / 2.2 | 96.5 / 2.2 | 96.5 / 1.8 | 96.7 / 2.1 |
| bench_seq_mix | 96.0 / 1.0 | 96.1 / 1.4 | 96.1 / 1.4 | 95.8 / 1.9 |
| bench_seq_rd_aligned | 0.0 / 99.3 | 0.0 / 99.3 | 72.4 / 27.0 | 72.4 / 26.9 |
| bench_rand_rd | 1.4 / 94.1 | 1.4 / 94.1 | 2.2 / 93.4 | 2.3 / 93.9 |
| bench_rand_mix | 1.4 / 93.7 | 1.4 / 93.8 | 1.7 / 93.6 | 1.7 / 93.8 |
| bench_rowmix | 32.6 / 66.2 | 32.3 / 66.2 | 66.2 / 32.8 | 65.9 / 33.1 |
| bench_rowwalk | 0.0 / 99.4 | 0.0 / 98.4 | 0.0 / 98.4 | 0.0 / 98.7 |
| bench_hotbank | 24.8 / 74.8 | 25.2 / 74.3 | 77.4 / 22.4 | 77.4 / 22.4 |
| bench_vector | 47.6 / 47.2 | 50.4 / 45.3 | 50.7 / 44.9 | 51.3 / 44.4 |
| bench_dma_copy | 47.1 / 48.9 | 47.1 / 48.9 | 47.1 / 48.9 | 47.1 / 48.9 |
| bench_tensor_alone | 96.6 / 0.5 | 96.6 / 0.5 | 96.6 / 0.5 | 96.6 / 0.5 |
| bench_tensor | 60.4 / 34.9 | 65.2 / 30.4 | 73.5 / 22.6 | 74.1 / 21.9 |
| bench_ctrl_probe | 48.7 / 46.4 | 49.7 / 45.6 | 60.8 / 35.0 | 61.2 / 34.7 |
| bench_system | 48.4 / 46.9 | 55.0 / 40.5 | 64.6 / 31.4 | 64.5 / 31.5 |

## Mechanism metrics

| workload | policy | q-wait mean | q-wait max | turnarounds / req | drain % | age overrides | bank-busy issues | refresh stall % | ROB stall cyc | lane util % |
|---|---|---|---|---|---|---|---|---|---|---|
| bench_seq_rd | FCFS | 31 | 378 | 0.00 | 0.0 | 0 | 200 | 6.2 | 3548 | 70.4 |
| bench_seq_rd | RDPRIO | 31 | 378 | 0.00 | 0.0 | 0 | 200 | 6.2 | 3548 | 70.4 |
| bench_seq_rd | FRFCFS | 42 | 631 | 0.00 | 0.0 | 0 | 346 | 7.0 | 12160 | 48.2 |
| bench_seq_rd | BANKAWARE | 33 | 567 | 0.00 | 0.0 | 0 | 304 | 7.2 | 4154 | 61.6 |
| bench_seq_wr | FCFS | 30 | 346 | 0.00 | 99.6 | 0 | 192 | 6.3 | 5070 | 71.1 |
| bench_seq_wr | RDPRIO | 30 | 346 | 0.00 | 99.6 | 0 | 192 | 6.3 | 5070 | 71.1 |
| bench_seq_wr | FRFCFS | 36 | 668 | 0.00 | 81.1 | 0 | 334 | 7.4 | 14618 | 49.9 |
| bench_seq_wr | BANKAWARE | 31 | 568 | 0.00 | 97.6 | 0 | 304 | 6.1 | 1566 | 68.6 |
| bench_seq_mix | FCFS | 60 | 410 | 0.42 | 0.0 | 0 | 53 | 6.4 | 30809 | 27.4 |
| bench_seq_mix | RDPRIO | 34 | 501 | 0.24 | 0.0 | 0 | 162 | 6.0 | 28266 | 34.3 |
| bench_seq_mix | FRFCFS | 32 | 884 | 0.24 | 0.0 | 0 | 249 | 4.0 | 28335 | 33.8 |
| bench_seq_mix | BANKAWARE | 32 | 788 | 0.23 | 0.0 | 0 | 256 | 5.1 | 27494 | 34.8 |
| bench_seq_rd_aligned | FCFS | 599 | 868 | 0.00 | 0.0 | 0 | 76 | 7.3 | 4607 | 4.0 |
| bench_seq_rd_aligned | RDPRIO | 599 | 868 | 0.00 | 0.0 | 0 | 76 | 7.3 | 4607 | 4.0 |
| bench_seq_rd_aligned | FRFCFS | 149 | 445 | 0.00 | 0.0 | 0 | 2632 | 7.2 | 4078 | 15.7 |
| bench_seq_rd_aligned | BANKAWARE | 148 | 480 | 0.00 | 0.0 | 0 | 2512 | 7.2 | 8623 | 15.7 |
| bench_rand_rd | FCFS | 111 | 575 | 0.00 | 0.0 | 0 | 787 | 6.3 | 57061 | 15.7 |
| bench_rand_rd | RDPRIO | 111 | 575 | 0.00 | 0.0 | 0 | 787 | 6.3 | 57061 | 15.7 |
| bench_rand_rd | FRFCFS | 108 | 567 | 0.00 | 0.0 | 0 | 801 | 5.8 | 58018 | 15.9 |
| bench_rand_rd | BANKAWARE | 100 | 569 | 0.00 | 0.0 | 0 | 197 | 6.7 | 53887 | 17.5 |
| bench_rand_mix | FCFS | 128 | 627 | 0.42 | 0.2 | 0 | 601 | 5.9 | 65328 | 13.9 |
| bench_rand_mix | RDPRIO | 83 | 839 | 0.23 | 1.4 | 0 | 742 | 5.5 | 68571 | 14.3 |
| bench_rand_mix | FRFCFS | 84 | 791 | 0.23 | 1.5 | 0 | 754 | 6.1 | 68070 | 14.4 |
| bench_rand_mix | BANKAWARE | 78 | 833 | 0.23 | 1.0 | 0 | 390 | 5.9 | 64226 | 15.2 |
| bench_rowmix | FCFS | 319 | 848 | 0.41 | 5.1 | 0 | 862 | 3.7 | 0 | 6.7 |
| bench_rowmix | RDPRIO | 362 | 1315 | 0.09 | 9.3 | 251 | 1437 | 3.7 | 141967 | 5.8 |
| bench_rowmix | FRFCFS | 179 | 1226 | 0.08 | 7.2 | 23 | 1872 | 3.6 | 103525 | 9.3 |
| bench_rowmix | BANKAWARE | 167 | 1065 | 0.09 | 7.2 | 14 | 1687 | 3.6 | 98608 | 9.8 |
| bench_rowwalk | FCFS | 103 | 457 | 0.38 | 0.0 | 0 | 6 | 6.8 | 39571 | 17.8 |
| bench_rowwalk | RDPRIO | 146 | 1176 | 0.20 | 0.0 | 14 | 1867 | 6.7 | 110431 | 8.7 |
| bench_rowwalk | FRFCFS | 146 | 1176 | 0.20 | 0.0 | 14 | 1867 | 6.7 | 110431 | 8.7 |
| bench_rowwalk | BANKAWARE | 130 | 1054 | 0.20 | 0.0 | 3 | 998 | 6.5 | 94217 | 10.1 |
| bench_hotbank | FCFS | 860 | 1551 | 0.40 | 4.8 | 0 | 1494 | 3.6 | 0 | 2.5 |
| bench_hotbank | RDPRIO | 882 | 1516 | 0.28 | 5.4 | 3621 | 1602 | 3.6 | 132464 | 2.5 |
| bench_hotbank | FRFCFS | 226 | 1202 | 0.12 | 6.1 | 106 | 1567 | 3.6 | 140201 | 7.0 |
| bench_hotbank | BANKAWARE | 226 | 1202 | 0.12 | 6.1 | 106 | 1567 | 3.6 | 140201 | 7.0 |
| bench_vector | FCFS | 34 | 438 | 0.32 | 0.0 | 0 | 687 | 4.9 | 32453 | 15.0 |
| bench_vector | RDPRIO | 18 | 538 | 0.29 | 0.0 | 0 | 873 | 4.0 | 30302 | 17.3 |
| bench_vector | FRFCFS | 17 | 517 | 0.29 | 0.0 | 0 | 864 | 3.8 | 29467 | 17.5 |
| bench_vector | BANKAWARE | 18 | 585 | 0.29 | 0.0 | 0 | 838 | 4.3 | 28549 | 18.0 |
| bench_dma_copy | FCFS | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | RDPRIO | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | FRFCFS | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | BANKAWARE | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_tensor_alone | FCFS | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | RDPRIO | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | FRFCFS | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | BANKAWARE | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor | FCFS | 69 | 512 | 0.49 | 0.0 | 0 | 628 | 5.6 | 77063 | 15.9 |
| bench_tensor | RDPRIO | 40 | 689 | 0.31 | 0.0 | 0 | 724 | 5.4 | 54656 | 17.8 |
| bench_tensor | FRFCFS | 36 | 919 | 0.31 | 0.0 | 0 | 665 | 5.8 | 49015 | 19.5 |
| bench_tensor | BANKAWARE | 35 | 989 | 0.33 | 0.0 | 1 | 626 | 5.5 | 47888 | 20.1 |
| bench_ctrl_probe | FCFS | 99 | 590 | 0.47 | 0.0 | 0 | 532 | 5.8 | 71031 | 15.4 |
| bench_ctrl_probe | RDPRIO | 58 | 840 | 0.29 | 0.1 | 0 | 1119 | 5.9 | 78643 | 16.0 |
| bench_ctrl_probe | FRFCFS | 50 | 1071 | 0.29 | 0.1 | 3 | 1165 | 6.0 | 79002 | 18.3 |
| bench_ctrl_probe | BANKAWARE | 48 | 1000 | 0.29 | 0.0 | 1 | 1076 | 6.0 | 78752 | 19.0 |
| bench_system | FCFS | 100 | 597 | 0.45 | 0.0 | 0 | 799 | 6.2 | 94229 | 15.6 |
| bench_system | RDPRIO | 53 | 878 | 0.28 | 0.2 | 0 | 829 | 6.1 | 60675 | 17.3 |
| bench_system | FRFCFS | 46 | 1031 | 0.27 | 0.1 | 2 | 747 | 6.5 | 51218 | 19.6 |
| bench_system | BANKAWARE | 46 | 1022 | 0.27 | 0.1 | 2 | 696 | 6.3 | 51548 | 19.8 |

## Per-source view: `bench_system` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 279 | 255 | 658 | 924 | 103680 |
| FCFS | 1 | 3471 | 111072 | 279 | 256 | 650 | 893 | 104611 |
| FCFS | 2 | 3501 | 112032 | 277 | 252 | 660 | 942 | 104585 |
| FCFS | 3 | 2639 | 83593 | 250 | 229 | 610 | 774 | 20090 |
| FCFS | 4 | 3700 | 118400 | 262 | 242 | 620 | 871 | 104327 |
| RDPRIO | 0 | 3456 | 110592 | 156 | 127 | 536 | 817 | 56644 |
| RDPRIO | 1 | 2084 | 66688 | 262 | 233 | 705 | 868 | 58736 |
| RDPRIO | 2 | 1612 | 51584 | 339 | 303 | 837 | 1047 | 59238 |
| RDPRIO | 3 | 1500 | 47531 | 179 | 139 | 584 | 739 | 8215 |
| RDPRIO | 4 | 1954 | 62528 | 279 | 253 | 711 | 1261 | 58843 |
| FRFCFS | 0 | 3456 | 110592 | 133 | 107 | 490 | 898 | 47889 |
| FRFCFS | 1 | 2452 | 78464 | 191 | 150 | 745 | 1115 | 49803 |
| FRFCFS | 2 | 1736 | 55552 | 270 | 231 | 763 | 963 | 50577 |
| FRFCFS | 3 | 1199 | 37939 | 205 | 143 | 757 | 918 | 10435 |
| FRFCFS | 4 | 1395 | 44640 | 336 | 300 | 926 | 1149 | 50892 |
| BANKAWARE | 0 | 3456 | 110592 | 135 | 108 | 565 | 844 | 48776 |
| BANKAWARE | 1 | 2504 | 80128 | 190 | 156 | 588 | 752 | 50462 |
| BANKAWARE | 2 | 1738 | 55616 | 273 | 213 | 1020 | 1115 | 51276 |
| BANKAWARE | 3 | 1324 | 41949 | 193 | 137 | 726 | 858 | 9137 |
| BANKAWARE | 4 | 1384 | 44288 | 344 | 308 | 891 | 1130 | 51636 |

## Per-source view: `bench_tensor` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 232 | 209 | 592 | 713 | 85367 |
| FCFS | 1 | 3467 | 110944 | 233 | 210 | 599 | 725 | 86588 |
| FCFS | 2 | 3505 | 112160 | 230 | 207 | 611 | 822 | 86571 |
| FCFS | 4 | 3657 | 117024 | 221 | 201 | 585 | 767 | 86402 |
| RDPRIO | 0 | 3456 | 110592 | 145 | 122 | 445 | 694 | 52311 |
| RDPRIO | 1 | 2287 | 73184 | 222 | 198 | 612 | 706 | 54401 |
| RDPRIO | 2 | 1878 | 60096 | 270 | 245 | 704 | 816 | 54763 |
| RDPRIO | 4 | 2245 | 71840 | 226 | 201 | 617 | 788 | 54431 |
| FRFCFS | 0 | 3456 | 110592 | 127 | 107 | 452 | 787 | 45723 |
| FRFCFS | 1 | 2783 | 89056 | 160 | 134 | 544 | 784 | 47051 |
| FRFCFS | 2 | 1990 | 63680 | 224 | 192 | 663 | 813 | 47853 |
| FRFCFS | 4 | 1539 | 49248 | 291 | 237 | 934 | 1186 | 48326 |
| BANKAWARE | 0 | 3456 | 110592 | 127 | 105 | 466 | 652 | 45525 |
| BANKAWARE | 1 | 2841 | 90912 | 156 | 130 | 520 | 791 | 46818 |
| BANKAWARE | 2 | 2130 | 68160 | 209 | 178 | 630 | 776 | 47533 |
| BANKAWARE | 4 | 1543 | 49376 | 289 | 242 | 972 | 1152 | 48148 |

## Per-source view: `bench_ctrl_probe` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 2553 | 81696 | 281 | 254 | 664 | 806 | 77489 |
| FCFS | 1 | 2553 | 81696 | 281 | 256 | 674 | 811 | 77494 |
| FCFS | 2 | 2577 | 82464 | 279 | 250 | 683 | 852 | 77510 |
| FCFS | 3 | 1890 | 59766 | 254 | 230 | 631 | 701 | 14938 |
| FCFS | 4 | 2733 | 87456 | 263 | 238 | 644 | 905 | 77269 |
| RDPRIO | 0 | 3239 | 103648 | 221 | 192 | 615 | 902 | 76782 |
| RDPRIO | 1 | 2914 | 93248 | 247 | 221 | 665 | 880 | 77204 |
| RDPRIO | 2 | 2332 | 74624 | 308 | 276 | 792 | 1112 | 77822 |
| RDPRIO | 3 | 2025 | 64021 | 178 | 143 | 614 | 907 | 11353 |
| RDPRIO | 4 | 2777 | 88864 | 258 | 240 | 680 | 953 | 77228 |
| FRFCFS | 0 | 4297 | 137504 | 167 | 143 | 553 | 660 | 75767 |
| FRFCFS | 1 | 3873 | 123936 | 185 | 151 | 606 | 922 | 76323 |
| FRFCFS | 2 | 2690 | 86080 | 267 | 231 | 778 | 1016 | 77562 |
| FRFCFS | 3 | 1888 | 59831 | 208 | 148 | 846 | 1065 | 16262 |
| FRFCFS | 4 | 2250 | 72000 | 319 | 277 | 868 | 1070 | 77761 |
| BANKAWARE | 0 | 4316 | 138112 | 166 | 135 | 577 | 816 | 75690 |
| BANKAWARE | 1 | 3742 | 119744 | 191 | 157 | 624 | 842 | 76260 |
| BANKAWARE | 2 | 2752 | 88064 | 261 | 231 | 761 | 1070 | 77310 |
| BANKAWARE | 3 | 1921 | 60853 | 193 | 144 | 783 | 1086 | 12727 |
| BANKAWARE | 4 | 2240 | 71680 | 320 | 279 | 869 | 983 | 77814 |

## Per-source view: `bench_tensor_alone` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| RDPRIO | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| FRFCFS | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| BANKAWARE | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |

## Tensor starvation (tile-fetch flow, double-buffered consumer)

| workload | policy | tiles | compute idle cycles (after first start) | longest idle run | span (cycles) | idle % | first-tile wait |
|---|---|---|---|---|---|---|---|
| bench_tensor_alone | FCFS | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | RDPRIO | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | FRFCFS | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | BANKAWARE | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor | FCFS | 24 | 74506 | 4168 | 89305 | 83.4 | 2511 |
| bench_tensor | RDPRIO | 24 | 41781 | 2324 | 56102 | 74.5 | 2033 |
| bench_tensor | FRFCFS | 24 | 35565 | 1885 | 49466 | 71.9 | 1613 |
| bench_tensor | BANKAWARE | 24 | 35491 | 2569 | 49350 | 71.9 | 1571 |
| bench_system | FCFS | 24 | 91745 | 5059 | 107582 | 85.3 | 3549 |
| bench_system | RDPRIO | 24 | 46026 | 2498 | 60258 | 76.4 | 1944 |
| bench_system | FRFCFS | 24 | 37555 | 2226 | 51635 | 72.7 | 1792 |
| bench_system | BANKAWARE | 24 | 38379 | 2411 | 52621 | 72.9 | 1954 |
