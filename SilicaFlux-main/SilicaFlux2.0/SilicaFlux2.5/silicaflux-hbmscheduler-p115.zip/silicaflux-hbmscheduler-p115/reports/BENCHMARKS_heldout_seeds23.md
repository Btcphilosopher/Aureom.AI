# Scheduling-policy study, HELD-OUT seeds 2 and 3 (age limit 1024 was tuned on seed 1) (all numbers MODELLED)

Configuration `base`.  Baseline = policy 0 (FCFS), measured first and frozen (`BASELINE_FCFS.md`). Policies: 0=FCFS, 1=RDPRIO, 2=FRFCFS, 3=BANKAWARE.

* run `baseline_fcfs_final` (config `base`, policies [0], seeds [1, 2, 3], N=2000 requests / source), binary sha256 `dac33209e995e5d3`, bench sha256 `2b4a524ee3920012`, created 2026-11-20 17:50:31
* run `policies_final_age1024` (config `base`, policies [1, 2, 3], seeds [1, 2, 3], N=2000 requests / source), binary sha256 `dac33209e995e5d3`, bench sha256 `2b4a524ee3920012`, created 2026-11-20 17:54:52

## Useful throughput (bytes per cycle; seeds: mean (min..max))

| workload | FCFS B/cyc | RDPRIO B/cyc | FRFCFS B/cyc | BANKAWARE B/cyc | RDPRIO vs FCFS | FRFCFS vs FCFS | BANKAWARE vs FCFS |
|---|---|---|---|---|---|---|---|
| bench_rand_rd | 5.04 (5.01..5.06) | 5.04 (5.01..5.06) | 5.08 (5.07..5.09) | 5.60 (5.57..5.62) | +0.0 % | +0.9 % | +11.1 % |
| bench_rand_mix | 4.44 (4.44..4.45) | 4.55 (4.52..4.58) | 4.61 (4.58..4.63) | 4.86 (4.83..4.89) | +2.4 % | +3.7 % | +9.4 % |
| bench_rowmix | 2.13 (2.13..2.14) | 1.87 (1.86..1.88) | 3.00 (2.99..3.00) | 3.10 (3.07..3.12) | -12.4 % | +40.4 % | +45.0 % |
| bench_rowwalk | 5.68 (5.68..5.69) | 2.78 (2.77..2.78) | 2.78 (2.77..2.78) | 3.23 (3.22..3.24) | -51.2 % | -51.2 % | -43.2 % |
| bench_hotbank | 0.80 (0.80..0.80) | 0.81 (0.81..0.81) | 2.25 (2.20..2.30) | 2.25 (2.20..2.30) | +0.9 % | +181.8 % | +181.8 % |
| bench_vector | 4.77 (4.75..4.80) | 5.46 (5.41..5.50) | 5.63 (5.58..5.68) | 5.78 (5.73..5.83) | +14.4 % | +17.9 % | +21.2 % |
| bench_dma_copy | 2.56 | 2.56 | 2.56 | 2.56 | +0.0 % | +0.0 % | +0.0 % |
| bench_tensor_alone | 8.24 | 8.24 | 8.24 | 8.24 | +0.0 % | +0.0 % | +0.0 % |
| bench_tensor | 5.11 (5.10..5.13) | 5.76 (5.74..5.79) | 6.25 (6.24..6.27) | 6.43 (6.40..6.45) | +12.7 % | +22.3 % | +25.6 % |
| bench_ctrl_probe | 4.91 (4.91..4.91) | 5.03 (4.90..5.15) | 5.80 (5.80..5.80) | 6.11 (6.06..6.16) | +2.4 % | +18.2 % | +24.5 % |
| bench_system | 4.99 (4.96..5.03) | 5.53 (5.48..5.58) | 6.29 (6.25..6.33) | 6.36 (6.35..6.37) | +10.7 % | +26.0 % | +27.4 % |

## Request latency, accept -> response (cycles)

| workload | FCFS mean / p99 | RDPRIO mean / p99 | FRFCFS mean / p99 | BANKAWARE mean / p99 |
|---|---|---|---|---|
| bench_rand_rd | 249 / 579 | 249 / 579 | 246 / 592 | 225 / 554 |
| bench_rand_mix | 286 / 642 | 278 / 704 | 274 / 728 | 260 / 682 |
| bench_rowmix | 442 / 857 | 611 / 1250 | 411 / 1074 | 395 / 1022 |
| bench_rowwalk | 224 / 526 | 453 / 1068 | 453 / 1068 | 391 / 894 |
| bench_hotbank | 1182 / 1690 | 1232 / 1711 | 552 / 1224 | 552 / 1224 |
| bench_vector | 158 / 544 | 131 / 466 | 126 / 454 | 123 / 460 |
| bench_dma_copy | 199 / 494 | 199 / 494 | 199 / 494 | 199 / 494 |
| bench_tensor_alone | 24 / 48 | 24 / 48 | 24 / 48 | 24 / 48 |
| bench_tensor | 199 / 530 | 176 / 567 | 162 / 580 | 157 / 594 |
| bench_ctrl_probe | 246 / 608 | 231 / 681 | 201 / 726 | 190 / 656 |
| bench_system | 241 / 588 | 209 / 638 | 185 / 704 | 181 / 690 |

## Row-buffer behaviour (backend-reported)

| workload | FCFS hit % / conflict % | RDPRIO hit % / conflict % | FRFCFS hit % / conflict % | BANKAWARE hit % / conflict % |
|---|---|---|---|---|
| bench_rand_rd | 1.5 / 94.0 | 1.5 / 94.0 | 2.3 / 93.3 | 2.4 / 93.8 |
| bench_rand_mix | 1.5 / 93.5 | 1.5 / 93.7 | 1.7 / 93.6 | 1.8 / 93.7 |
| bench_rowmix | 32.2 / 66.7 | 32.1 / 66.3 | 66.2 / 32.8 | 65.7 / 33.3 |
| bench_rowwalk | 0.0 / 99.4 | 0.0 / 98.4 | 0.0 / 98.4 | 0.0 / 98.6 |
| bench_hotbank | 24.7 / 74.9 | 25.0 / 74.6 | 77.8 / 22.0 | 77.8 / 22.0 |
| bench_vector | 47.5 / 47.3 | 50.0 / 45.7 | 50.8 / 44.8 | 51.4 / 44.2 |
| bench_dma_copy | 47.1 / 48.9 | 47.1 / 48.9 | 47.1 / 48.9 | 47.1 / 48.9 |
| bench_tensor_alone | 96.6 / 0.5 | 96.6 / 0.5 | 96.6 / 0.5 | 96.6 / 0.5 |
| bench_tensor | 60.4 / 34.9 | 65.7 / 30.1 | 73.4 / 22.6 | 74.2 / 21.8 |
| bench_ctrl_probe | 48.5 / 46.5 | 48.8 / 46.4 | 60.1 / 35.7 | 61.3 / 34.6 |
| bench_system | 48.4 / 46.8 | 54.7 / 41.0 | 64.9 / 31.2 | 65.0 / 31.0 |

## Mechanism metrics

| workload | policy | q-wait mean | q-wait max | turnarounds / req | drain % | age overrides | bank-busy issues | refresh stall % | ROB stall cyc | lane util % |
|---|---|---|---|---|---|---|---|---|---|---|
| bench_rand_rd | FCFS | 110 | 568 | 0.00 | 0.0 | 0 | 776 | 6.4 | 57310 | 15.7 |
| bench_rand_rd | RDPRIO | 110 | 568 | 0.00 | 0.0 | 0 | 776 | 6.4 | 57310 | 15.7 |
| bench_rand_rd | FRFCFS | 108 | 567 | 0.00 | 0.0 | 0 | 800 | 5.9 | 57738 | 15.9 |
| bench_rand_rd | BANKAWARE | 99 | 566 | 0.00 | 0.0 | 0 | 203 | 6.7 | 54324 | 17.5 |
| bench_rand_mix | FCFS | 128 | 614 | 0.43 | 0.2 | 0 | 598 | 5.9 | 65624 | 13.9 |
| bench_rand_mix | RDPRIO | 83 | 854 | 0.23 | 1.6 | 0 | 744 | 5.4 | 69098 | 14.2 |
| bench_rand_mix | FRFCFS | 85 | 796 | 0.23 | 1.6 | 0 | 744 | 6.4 | 67786 | 14.4 |
| bench_rand_mix | BANKAWARE | 78 | 800 | 0.23 | 1.0 | 0 | 384 | 6.0 | 64248 | 15.2 |
| bench_rowmix | FCFS | 320 | 866 | 0.41 | 5.0 | 0 | 850 | 3.7 | 0 | 6.7 |
| bench_rowmix | RDPRIO | 363 | 1315 | 0.08 | 9.7 | 233 | 1430 | 3.7 | 140128 | 5.8 |
| bench_rowmix | FRFCFS | 178 | 1188 | 0.08 | 7.0 | 22 | 1857 | 3.6 | 103364 | 9.4 |
| bench_rowmix | BANKAWARE | 168 | 1077 | 0.09 | 7.0 | 15 | 1678 | 3.6 | 99482 | 9.7 |
| bench_rowwalk | FCFS | 92 | 460 | 0.38 | 0.0 | 0 | 6 | 6.4 | 46128 | 17.8 |
| bench_rowwalk | RDPRIO | 146 | 1131 | 0.20 | 0.1 | 14 | 1880 | 6.7 | 110762 | 8.7 |
| bench_rowwalk | FRFCFS | 146 | 1131 | 0.20 | 0.1 | 14 | 1880 | 6.7 | 110762 | 8.7 |
| bench_rowwalk | BANKAWARE | 131 | 1057 | 0.19 | 0.0 | 2 | 988 | 6.5 | 93753 | 10.1 |
| bench_hotbank | FCFS | 860 | 1576 | 0.40 | 4.7 | 0 | 1478 | 3.6 | 0 | 2.5 |
| bench_hotbank | RDPRIO | 884 | 1539 | 0.27 | 5.5 | 3625 | 1614 | 3.6 | 132956 | 2.5 |
| bench_hotbank | FRFCFS | 225 | 1133 | 0.12 | 6.1 | 97 | 1560 | 3.6 | 138364 | 7.0 |
| bench_hotbank | BANKAWARE | 225 | 1133 | 0.12 | 6.1 | 97 | 1560 | 3.6 | 138364 | 7.0 |
| bench_vector | FCFS | 34 | 458 | 0.32 | 0.0 | 0 | 674 | 4.8 | 32904 | 14.9 |
| bench_vector | RDPRIO | 19 | 519 | 0.28 | 0.0 | 0 | 880 | 4.0 | 30440 | 17.1 |
| bench_vector | FRFCFS | 17 | 480 | 0.29 | 0.0 | 0 | 872 | 3.9 | 29342 | 17.6 |
| bench_vector | BANKAWARE | 17 | 603 | 0.30 | 0.0 | 0 | 830 | 3.8 | 28900 | 18.1 |
| bench_dma_copy | FCFS | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | RDPRIO | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | FRFCFS | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | BANKAWARE | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_tensor_alone | FCFS | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | RDPRIO | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | FRFCFS | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | BANKAWARE | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor | FCFS | 68 | 504 | 0.49 | 0.0 | 0 | 624 | 5.5 | 76681 | 16.0 |
| bench_tensor | RDPRIO | 40 | 690 | 0.31 | 0.0 | 0 | 720 | 5.4 | 53910 | 18.0 |
| bench_tensor | FRFCFS | 36 | 908 | 0.31 | 0.0 | 0 | 660 | 6.0 | 49274 | 19.5 |
| bench_tensor | BANKAWARE | 34 | 970 | 0.33 | 0.0 | 1 | 620 | 5.6 | 47358 | 20.1 |
| bench_ctrl_probe | FCFS | 100 | 594 | 0.47 | 0.0 | 0 | 520 | 6.0 | 71133 | 15.4 |
| bench_ctrl_probe | RDPRIO | 60 | 840 | 0.29 | 0.1 | 0 | 1132 | 6.0 | 78777 | 15.7 |
| bench_ctrl_probe | FRFCFS | 51 | 1088 | 0.29 | 0.1 | 4 | 1168 | 6.1 | 78905 | 18.2 |
| bench_ctrl_probe | BANKAWARE | 48 | 1042 | 0.28 | 0.0 | 2 | 1072 | 6.2 | 78837 | 19.1 |
| bench_system | FCFS | 101 | 576 | 0.45 | 0.0 | 0 | 772 | 6.3 | 93412 | 15.6 |
| bench_system | RDPRIO | 54 | 916 | 0.27 | 0.2 | 0 | 846 | 6.3 | 61044 | 17.3 |
| bench_system | FRFCFS | 46 | 1033 | 0.27 | 0.1 | 2 | 740 | 6.8 | 50858 | 19.7 |
| bench_system | BANKAWARE | 46 | 1014 | 0.28 | 0.1 | 2 | 680 | 6.6 | 50971 | 19.9 |

## Per-source view: `bench_system` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 277 | 251 | 635 | 762 | 103110 |
| FCFS | 1 | 3478 | 111296 | 278 | 253 | 637 | 784 | 104217 |
| FCFS | 2 | 3523 | 112736 | 274 | 249 | 644 | 793 | 104176 |
| FCFS | 3 | 2608 | 82630 | 249 | 229 | 587 | 691 | 19124 |
| FCFS | 4 | 3670 | 117440 | 263 | 241 | 608 | 782 | 103992 |
| RDPRIO | 0 | 3456 | 110592 | 157 | 129 | 524 | 799 | 56985 |
| RDPRIO | 1 | 2094 | 67008 | 263 | 238 | 703 | 1028 | 59463 |
| RDPRIO | 2 | 1616 | 51712 | 341 | 303 | 820 | 1103 | 59877 |
| RDPRIO | 3 | 1649 | 52248 | 177 | 136 | 536 | 688 | 9503 |
| RDPRIO | 4 | 1936 | 61952 | 285 | 262 | 724 | 911 | 59627 |
| FRFCFS | 0 | 3456 | 110592 | 131 | 106 | 475 | 731 | 47175 |
| FRFCFS | 1 | 2518 | 80576 | 183 | 152 | 609 | 830 | 48825 |
| FRFCFS | 2 | 1708 | 54656 | 270 | 224 | 762 | 935 | 49787 |
| FRFCFS | 3 | 1183 | 37364 | 222 | 147 | 892 | 1094 | 12273 |
| FRFCFS | 4 | 1345 | 43040 | 343 | 299 | 980 | 1191 | 50050 |
| BANKAWARE | 0 | 3456 | 110592 | 131 | 104 | 520 | 678 | 47270 |
| BANKAWARE | 1 | 2535 | 81120 | 181 | 149 | 645 | 1235 | 48815 |
| BANKAWARE | 2 | 1700 | 54400 | 271 | 219 | 790 | 1645 | 49650 |
| BANKAWARE | 3 | 1223 | 38708 | 201 | 140 | 713 | 1147 | 10312 |
| BANKAWARE | 4 | 1336 | 42752 | 345 | 310 | 967 | 1119 | 50081 |

## Per-source view: `bench_tensor` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 227 | 204 | 573 | 679 | 83996 |
| FCFS | 1 | 3489 | 111648 | 227 | 206 | 578 | 694 | 84877 |
| FCFS | 2 | 3529 | 112928 | 224 | 202 | 580 | 682 | 84813 |
| FCFS | 4 | 3707 | 118624 | 214 | 195 | 548 | 708 | 84661 |
| RDPRIO | 0 | 3456 | 110592 | 142 | 118 | 490 | 745 | 51020 |
| RDPRIO | 1 | 2385 | 76320 | 209 | 189 | 635 | 757 | 53164 |
| RDPRIO | 2 | 1882 | 60224 | 265 | 230 | 691 | 1137 | 53695 |
| RDPRIO | 4 | 2247 | 71904 | 221 | 200 | 619 | 807 | 53311 |
| FRFCFS | 0 | 3456 | 110592 | 128 | 107 | 443 | 520 | 46011 |
| FRFCFS | 1 | 2766 | 88512 | 162 | 134 | 523 | 718 | 47434 |
| FRFCFS | 2 | 2084 | 66688 | 216 | 182 | 628 | 848 | 48148 |
| FRFCFS | 4 | 1561 | 49952 | 289 | 250 | 815 | 887 | 48700 |
| BANKAWARE | 0 | 3456 | 110592 | 124 | 106 | 433 | 515 | 44580 |
| BANKAWARE | 1 | 2738 | 87616 | 159 | 134 | 516 | 673 | 45960 |
| BANKAWARE | 2 | 2032 | 65024 | 215 | 180 | 739 | 1148 | 46668 |
| BANKAWARE | 4 | 1547 | 49504 | 283 | 241 | 871 | 1121 | 47244 |

## Per-source view: `bench_ctrl_probe` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 2550 | 81600 | 282 | 258 | 683 | 866 | 77471 |
| FCFS | 1 | 2550 | 81600 | 282 | 258 | 677 | 855 | 77492 |
| FCFS | 2 | 2571 | 82272 | 280 | 255 | 682 | 806 | 77561 |
| FCFS | 3 | 1928 | 61145 | 251 | 228 | 624 | 853 | 15449 |
| FCFS | 4 | 2730 | 87360 | 263 | 243 | 635 | 808 | 77293 |
| RDPRIO | 0 | 3129 | 100128 | 229 | 196 | 697 | 1009 | 76962 |
| RDPRIO | 1 | 2861 | 91552 | 251 | 223 | 744 | 908 | 77224 |
| RDPRIO | 2 | 2260 | 72320 | 318 | 288 | 830 | 1126 | 77796 |
| RDPRIO | 3 | 2020 | 63765 | 187 | 147 | 596 | 730 | 12025 |
| RDPRIO | 4 | 2675 | 85600 | 268 | 238 | 735 | 1048 | 77383 |
| FRFCFS | 0 | 4116 | 131712 | 174 | 144 | 559 | 815 | 75980 |
| FRFCFS | 1 | 3670 | 117440 | 195 | 161 | 646 | 988 | 76356 |
| FRFCFS | 2 | 2604 | 83328 | 275 | 237 | 853 | 1147 | 77427 |
| FRFCFS | 3 | 1996 | 63183 | 196 | 147 | 735 | 971 | 13863 |
| FRFCFS | 4 | 2180 | 69760 | 330 | 291 | 888 | 1163 | 77941 |
| BANKAWARE | 0 | 4466 | 142912 | 160 | 132 | 555 | 762 | 75555 |
| BANKAWARE | 1 | 3853 | 123296 | 186 | 158 | 602 | 1076 | 76203 |
| BANKAWARE | 2 | 2838 | 90816 | 253 | 218 | 708 | 928 | 77220 |
| BANKAWARE | 3 | 1987 | 62840 | 193 | 141 | 696 | 1170 | 14061 |
| BANKAWARE | 4 | 2296 | 73472 | 313 | 265 | 947 | 1225 | 77714 |

## Per-source view: `bench_tensor_alone` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| RDPRIO | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| FRFCFS | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| BANKAWARE | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |

## Tensor starvation (tile-fetch flow, double-buffered consumer)

| workload | policy | tiles | compute idle cycles (after first start) | longest idle run | span (cycles) | idle % | first-tile wait |
|---|---|---|---|---|---|---|---|
| bench_tensor_alone | FCFS | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | RDPRIO | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | FRFCFS | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | BANKAWARE | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor | FCFS | 24 | 72862 | 4356 | 87960 | 82.8 | 2810 |
| bench_tensor | RDPRIO | 24 | 40566 | 2325 | 54608 | 74.3 | 1754 |
| bench_tensor | FRFCFS | 24 | 35981 | 2111 | 49860 | 72.2 | 1591 |
| bench_tensor | BANKAWARE | 24 | 34267 | 2060 | 48273 | 71.0 | 1718 |
| bench_system | FCFS | 24 | 91558 | 4987 | 107176 | 85.4 | 3330 |
| bench_system | RDPRIO | 24 | 46564 | 2559 | 60759 | 76.6 | 1907 |
| bench_system | FRFCFS | 24 | 36626 | 2095 | 50608 | 72.4 | 1694 |
| bench_system | BANKAWARE | 24 | 36977 | 2295 | 51109 | 72.3 | 1844 |
