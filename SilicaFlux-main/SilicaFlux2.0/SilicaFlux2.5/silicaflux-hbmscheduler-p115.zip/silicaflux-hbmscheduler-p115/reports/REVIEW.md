# Independent RTL review - findings and disposition

A fresh-context reviewer (a separate agent that had only the project root, `docs/ARCHITECTURE.md`, `docs/ORDERING.md` and the instruction to find real defects; it ran nothing and edited nothing) read the tracker, scheduler,
adapter, lane, queues, arbiter and top. Its nine findings were each **checked against the code by the author** before anything was changed. Evidence for the fixes: the pre-fix RTL is kept in the archive only as a
description here; the "before / after" runs below were done on a copy of the RTL taken before the fixes.

| # | finding (reviewer) | verified in code | fix | evidence |
|---|---|---|---|---|
| 1 | adapter outstanding counter loses a decrement when a read last-beat and a write response complete in the same cycle (`out_q` leaks; after `LANE_OUT` leaks the lane never issues) | **yes** (`any_done` decrements by at most 1) | `out_q` subtracts `done_rd + done_wr` (0..2), clamped at 0, together with the +1 for an issue | **new bench check**: `idle_o` must be high at the end of every scenario. On the pre-fix RTL with the jittered backend (`ord1`) the `policy` scenarios **fail** (counter never drains); on the fixed RTL they pass. The old regression passed because nothing observed the counter and the leak is slow |
| 2 | a timed-out slot that still waits for delivery ignores a lane flush and then becomes a zombie that is never reclaimed | **yes** (flush handled in ISSUED and ZOMBIE only) | in DONE with the timeout flag a flush marks the slot `late`, so it is freed at delivery | **new scenario `timeout_flush`**: pre-fix RTL **fails** ("zombie slots remain after the flush"), fixed RTL passes |
| 3 | policy 0 (FCFS) can deadlock after the age counters saturate (ties pick the read, which depends on the write that is never chosen) | **yes** (FCFS key is taken over all valid entries, not ready ones) | if the oldest entry is blocked by a hazard mask the oldest *issuable* entry is taken (strict order is kept while it merely waits for the backend) | **new scenario `fcfs_saturate`** (backend hung for 2^AGE_W + 600 cycles with dependent entries queued): pre-fix RTL **deadlocks** (requests still outstanding after 2 M cycles), fixed RTL drains and is exact. Baseline numbers unchanged (checked, `reports/BASELINE_FCFS.md` is regenerated on the fixed RTL) |
| 4 | policies 1-3: with `cfg_idle_wr = 0` and `cfg_age_limit = 0` a write below the drain watermark waits forever | yes (configuration constraint) | documented in `docs/LIMITATIONS.md` and `docs/SCHEDULING.md` (not a bug of the default configuration) | - |
| 5 | a backend response whose tag names no source (possible when `NUM_SRC` is not a power of two) is not counted as spurious | yes | the tracker wrapper counts foreign source fields | by inspection / lint (no stimulus in the bench produces a foreign tag; the model never does) |
| 6 | stray response of another lane carrying a live tag can shadow that lane's genuine response; can suppress a flush pulse | yes (backend contract violation only) | not changed: documented in `docs/LIMITATIONS.md` ("detected, not repaired") | - |
| 7 | a completion with a foreign / duplicate tag still decrements the adapter counter; with `BE_ORDER_SAFE = 0` the in-flight table can run short | yes (contract violation only) | not changed: documented | - |
| 8 | the 24-bit link timers truncate `RST_HOLD` / `CAL_TIMEOUT` >= 2^24 | yes | elaboration check in `sf_hbm_sched_top` | illegal-parameter test list |
| 9 | per-source queue-wait count is 2 bits wide although up to `NUM_LANES` commands of one source can issue in one cycle (counters wrong with >= 4 lanes) | yes | widened to 8 bits end to end | **no stimulus reproduced it**: the new directed scenario `prefill` (all lanes start issuing in the same cycle) did not trigger the wrap even on 4 lanes on the pre-fix RTL, so this one is fixed by inspection only; the new cross-check "sum of `S_QW_CNT` == sum of `L_QW_CNT`" would catch it |

## What the reviewer checked and found fine (not re-verified by the author)

Order matrix and slot life cycle (allocation + delivery in the same cycle, bit reuse, mode-1 same-id order, registered response channel never delivers twice and is stable); timeout / response / flush priorities and the late-response
transitions (except finding 2); flush vs issue timing; RAW / WAR / WAW masks for simultaneous enqueue and pop, slot reuse and non-power-of-two depths; `sf_hbm_maxsel` index and tie arithmetic; adapter FIFO pointer wrap
for depths 1-4 and write-data credit ordering; small configurations (`BURST_LEN = 1`, `NUM_SRC = 1`, `NUM_LANES = 1`); arbiter wrap and grant == acceptance; scheduler `pick_valid` always implies the adapter accepts; the in-flight
hazard table (no gap between queue-mask clear and table entry, cleared on flush); no latches or incomplete sensitivity.

## Lessons recorded

* The regression passed 39 / 39 on RTL that contained findings 1-3: a green regression says what the checks can see, not that the design is right. Three of the nine items were found only by reading, then turned into checks.
* A defect that leaks slowly (finding 1) needs an *end-state* assertion (`idle_o`), not only per-transaction checks.
