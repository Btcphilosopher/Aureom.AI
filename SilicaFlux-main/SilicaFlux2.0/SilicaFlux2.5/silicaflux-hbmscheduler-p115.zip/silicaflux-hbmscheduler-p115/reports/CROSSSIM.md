# Icarus Verilog cross-checks (secondary simulator)
`iverilog` = Icarus Verilog version 12.0 (stable) ()
## 1. Address-map unit bench

| map mode | result |
|---|---|
| 0 | RESULT: PASS tb_addr_map profile=0 ch=2 pc=1 mode=0 granules=65536 checks=65570 |
| 1 | RESULT: PASS tb_addr_map profile=0 ch=2 pc=1 mode=1 granules=65536 checks=65570 |
| 2 | RESULT: PASS tb_addr_map profile=0 ch=2 pc=1 mode=2 granules=65536 checks=65570 |
| 3 | RESULT: PASS tb_addr_map profile=0 ch=2 pc=1 mode=3 granules=65536 checks=65570 |

## 2. RTL-only elaboration (`-s sf_hbm_sched_top`)

exit code 0 in 0 s; errors: 0; distinct Icarus limitations reported: ['constant selects in always_* processes are not currently supported (all bits will be included).'].
(`constant selects in always_* processes are not currently supported (all bits will be included)` makes the affected processes sensitive to every bit: expected to be functionally neutral for combinational processes (more evaluations only), but NOT demonstrated here because the full bench did not run on Icarus.)

## 3. Full system bench on Icarus

**Not run.** Compilation did not finish within the time limit (limit 300 s). The system bench is therefore verified on Verilator only; the secondary-simulator evidence is limited to sections 1 and 2.
