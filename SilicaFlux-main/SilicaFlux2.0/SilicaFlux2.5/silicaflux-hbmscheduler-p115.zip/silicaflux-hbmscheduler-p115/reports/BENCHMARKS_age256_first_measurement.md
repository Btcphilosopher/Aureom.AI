# Policy study, FIRST measurement (default age limit 256) (all numbers MODELLED)

Configuration `base`.  Baseline = policy 0 (FCFS), measured first and frozen (`BASELINE_FCFS.md`). Policies: 0=FCFS, 1=RDPRIO, 2=FRFCFS, 3=BANKAWARE.

* run `baseline_fcfs` (config `base`, policies [0], seeds [1, 2, 3], N=2000 requests / source), binary sha256 `ce0f4ad5e379f883`, bench sha256 `65666f4fb39e063c`, created 2026-11-20 17:23:06
* run `policies_123` (config `base`, policies [1, 2, 3], seeds [1, 2, 3], N=2000 requests / source), binary sha256 `ce0f4ad5e379f883`, bench sha256 `65666f4fb39e063c`, created 2026-11-20 17:24:55

## Useful throughput (bytes per cycle; seeds: mean (min..max))

| workload | FCFS B/cyc | RDPRIO B/cyc | FRFCFS B/cyc | BANKAWARE B/cyc | RDPRIO vs FCFS | FRFCFS vs FCFS | BANKAWARE vs FCFS |
|---|---|---|---|---|---|---|---|
| bench_seq_rd | 22.52 | 22.52 | 15.44 | 18.72 | +0.0 % | -31.4 % | -16.9 % |
| bench_seq_wr | 22.74 | 22.74 | 15.93 | 21.29 | +0.0 % | -30.0 % | -6.4 % |
| bench_seq_mix | 8.77 | 11.07 | 10.73 | 11.30 | +26.3 % | +22.4 % | +28.9 % |
| bench_seq_rd_aligned | 1.27 | 1.27 | 1.60 | 1.60 | +0.0 % | +25.8 % | +25.8 % |
| bench_rand_rd | 5.04 (5.01..5.06) | 5.04 (5.01..5.06) | 5.12 (5.07..5.21) | 5.58 (5.56..5.59) | +0.0 % | +1.5 % | +10.7 % |
| bench_rand_mix | 4.45 (4.44..4.47) | 4.54 (4.49..4.60) | 4.56 (4.51..4.59) | 4.80 (4.78..4.83) | +2.0 % | +2.5 % | +7.9 % |
| bench_rowmix | 2.14 (2.13..2.14) | 2.19 (2.18..2.20) | 2.23 (2.22..2.25) | 2.23 (2.23..2.23) | +2.7 % | +4.4 % | +4.3 % |
| bench_rowwalk | 5.69 (5.68..5.70) | 2.61 (2.30..2.87) | 2.61 (2.30..2.87) | 3.10 (2.65..3.47) | -54.1 % | -54.1 % | -45.4 % |
| bench_hotbank | 0.80 (0.80..0.80) | 0.80 (0.80..0.80) | 0.80 (0.80..0.80) | 0.80 (0.80..0.80) | +0.0 % | -0.0 % | -0.0 % |
| bench_vector | 4.80 (4.75..4.85) | 5.59 (5.54..5.65) | 5.65 (5.60..5.69) | 5.75 (5.61..5.88) | +16.6 % | +17.9 % | +19.9 % |
| bench_dma_copy | 2.56 | 2.56 | 2.56 | 2.56 | +0.0 % | +0.0 % | +0.0 % |
| bench_tensor_alone | 8.24 | 8.24 | 8.24 | 8.24 | +0.0 % | +0.0 % | +0.0 % |
| bench_tensor | 5.08 (5.00..5.13) | 5.61 (5.58..5.64) | 6.18 (6.06..6.24) | 6.28 (6.24..6.33) | +10.5 % | +21.7 % | +23.8 % |
| bench_ctrl_probe | 4.90 (4.90..4.91) | 4.89 (4.77..5.00) | 5.46 (5.30..5.60) | 5.69 (5.50..5.87) | -0.4 % | +11.2 % | +16.0 % |
| bench_system | 4.98 (4.95..5.03) | 5.37 (5.33..5.42) | 5.98 (5.90..6.03) | 6.07 (6.03..6.10) | +7.9 % | +20.1 % | +21.9 % |

## Request latency, accept -> response (cycles)

| workload | FCFS mean / p99 | RDPRIO mean / p99 | FRFCFS mean / p99 | BANKAWARE mean / p99 |
|---|---|---|---|---|
| bench_seq_rd | 56 / 359 | 56 / 359 | 81 / 377 | 67 / 378 |
| bench_seq_wr | 55 / 363 | 55 / 363 | 78 / 383 | 59 / 362 |
| bench_seq_mix | 145 / 452 | 112 / 429 | 116 / 416 | 109 / 415 |
| bench_seq_rd_aligned | 1003 / 1246 | 1003 / 1246 | 797 / 1058 | 797 / 1058 |
| bench_rand_rd | 249 / 588 | 249 / 588 | 245 / 580 | 225 / 558 |
| bench_rand_mix | 285 / 643 | 279 / 642 | 277 / 649 | 263 / 625 |
| bench_rowmix | 441 / 846 | 437 / 842 | 447 / 875 | 447 / 855 |
| bench_rowwalk | 224 / 523 | 492 / 844 | 492 / 844 | 414 / 826 |
| bench_hotbank | 1183 / 1685 | 1182 / 1681 | 1183 / 1685 | 1183 / 1685 |
| bench_vector | 158 / 518 | 128 / 445 | 126 / 464 | 124 / 441 |
| bench_dma_copy | 199 / 494 | 199 / 494 | 199 / 494 | 199 / 494 |
| bench_tensor_alone | 24 / 48 | 24 / 48 | 24 / 48 | 24 / 48 |
| bench_tensor | 200 / 539 | 181 / 528 | 164 / 517 | 161 / 520 |
| bench_ctrl_probe | 246 / 612 | 240 / 619 | 214 / 588 | 205 / 571 |
| bench_system | 242 / 587 | 216 / 583 | 195 / 561 | 191 / 574 |

## Row-buffer behaviour (backend-reported)

| workload | FCFS hit % / conflict % | RDPRIO hit % / conflict % | FRFCFS hit % / conflict % | BANKAWARE hit % / conflict % |
|---|---|---|---|---|
| bench_seq_rd | 96.6 / 2.2 | 96.6 / 2.2 | 96.5 / 1.7 | 96.5 / 1.9 |
| bench_seq_wr | 96.5 / 2.2 | 96.5 / 2.2 | 96.5 / 1.8 | 96.6 / 2.1 |
| bench_seq_mix | 96.0 / 1.0 | 96.1 / 1.4 | 96.1 / 1.3 | 96.2 / 1.5 |
| bench_seq_rd_aligned | 0.0 / 99.3 | 0.0 / 99.3 | 20.0 / 78.9 | 20.0 / 78.9 |
| bench_rand_rd | 1.4 / 94.1 | 1.4 / 94.1 | 2.2 / 93.5 | 2.2 / 93.9 |
| bench_rand_mix | 1.4 / 93.7 | 1.5 / 93.7 | 1.7 / 93.5 | 1.8 / 93.7 |
| bench_rowmix | 32.6 / 66.2 | 32.8 / 66.1 | 42.3 / 56.4 | 42.5 / 56.2 |
| bench_rowwalk | 0.0 / 99.4 | 0.0 / 98.2 | 0.0 / 98.2 | 0.0 / 98.6 |
| bench_hotbank | 24.8 / 74.8 | 24.8 / 74.7 | 24.8 / 74.7 | 24.8 / 74.7 |
| bench_vector | 47.6 / 47.2 | 50.8 / 44.8 | 50.8 / 44.9 | 51.3 / 44.4 |
| bench_dma_copy | 47.1 / 48.9 | 47.1 / 48.9 | 47.1 / 48.9 | 47.1 / 48.9 |
| bench_tensor_alone | 96.6 / 0.5 | 96.6 / 0.5 | 96.6 / 0.5 | 96.6 / 0.5 |
| bench_tensor | 60.4 / 34.9 | 64.7 / 30.8 | 71.1 / 24.9 | 70.7 / 25.2 |
| bench_ctrl_probe | 48.7 / 46.4 | 46.5 / 48.5 | 54.0 / 41.5 | 55.5 / 40.2 |
| bench_system | 48.4 / 46.9 | 52.6 / 42.9 | 59.3 / 36.5 | 59.8 / 36.1 |

## Mechanism metrics

| workload | policy | q-wait mean | q-wait max | turnarounds / req | drain % | age overrides | bank-busy issues | refresh stall % | ROB stall cyc | lane util % |
|---|---|---|---|---|---|---|---|---|---|---|
| bench_seq_rd | FCFS | 31 | 378 | 0.00 | 0.0 | 0 | 200 | 6.2 | 3548 | 70.4 |
| bench_seq_rd | RDPRIO | 31 | 378 | 0.00 | 0.0 | 72 | 200 | 6.2 | 3548 | 70.4 |
| bench_seq_rd | FRFCFS | 38 | 521 | 0.00 | 0.0 | 305 | 316 | 7.0 | 12219 | 48.3 |
| bench_seq_rd | BANKAWARE | 33 | 456 | 0.00 | 0.0 | 157 | 334 | 6.8 | 9283 | 58.5 |
| bench_seq_wr | FCFS | 30 | 346 | 0.00 | 99.6 | 0 | 192 | 6.3 | 5070 | 71.1 |
| bench_seq_wr | RDPRIO | 30 | 346 | 0.00 | 99.6 | 71 | 192 | 6.3 | 5070 | 71.1 |
| bench_seq_wr | FRFCFS | 40 | 529 | 0.00 | 86.4 | 352 | 331 | 6.7 | 11652 | 49.8 |
| bench_seq_wr | BANKAWARE | 32 | 425 | 0.00 | 97.1 | 209 | 316 | 5.9 | 3913 | 66.5 |
| bench_seq_mix | FCFS | 60 | 410 | 0.42 | 0.0 | 0 | 53 | 6.4 | 30809 | 27.4 |
| bench_seq_mix | RDPRIO | 33 | 447 | 0.23 | 0.1 | 61 | 172 | 6.5 | 27619 | 34.6 |
| bench_seq_mix | FRFCFS | 34 | 425 | 0.24 | 0.0 | 105 | 230 | 6.8 | 28639 | 33.5 |
| bench_seq_mix | BANKAWARE | 32 | 453 | 0.24 | 0.1 | 59 | 249 | 5.6 | 26990 | 35.3 |
| bench_seq_rd_aligned | FCFS | 599 | 868 | 0.00 | 0.0 | 0 | 76 | 7.3 | 4607 | 4.0 |
| bench_seq_rd_aligned | RDPRIO | 599 | 868 | 0.00 | 0.0 | 9972 | 76 | 7.3 | 4607 | 4.0 |
| bench_seq_rd_aligned | FRFCFS | 475 | 868 | 0.00 | 0.0 | 9974 | 2012 | 7.2 | 4506 | 5.0 |
| bench_seq_rd_aligned | BANKAWARE | 475 | 868 | 0.00 | 0.0 | 9974 | 2012 | 7.2 | 4506 | 5.0 |
| bench_rand_rd | FCFS | 111 | 575 | 0.00 | 0.0 | 0 | 787 | 6.3 | 57061 | 15.7 |
| bench_rand_rd | RDPRIO | 111 | 575 | 0.00 | 0.0 | 305 | 787 | 6.3 | 57061 | 15.7 |
| bench_rand_rd | FRFCFS | 109 | 566 | 0.00 | 0.0 | 292 | 820 | 5.8 | 57611 | 16.0 |
| bench_rand_rd | BANKAWARE | 100 | 529 | 0.00 | 0.0 | 265 | 216 | 6.6 | 53933 | 17.4 |
| bench_rand_mix | FCFS | 128 | 627 | 0.42 | 0.2 | 0 | 601 | 5.9 | 65328 | 13.9 |
| bench_rand_mix | RDPRIO | 91 | 596 | 0.30 | 0.8 | 1193 | 716 | 6.1 | 69368 | 14.2 |
| bench_rand_mix | FRFCFS | 89 | 603 | 0.30 | 0.9 | 1150 | 707 | 6.3 | 69187 | 14.3 |
| bench_rand_mix | BANKAWARE | 84 | 598 | 0.28 | 0.7 | 945 | 370 | 5.9 | 65707 | 15.0 |
| bench_rowmix | FCFS | 319 | 848 | 0.41 | 5.1 | 0 | 862 | 3.7 | 0 | 6.7 |
| bench_rowmix | RDPRIO | 315 | 843 | 0.36 | 6.7 | 7218 | 754 | 3.7 | 13159 | 6.9 |
| bench_rowmix | FRFCFS | 312 | 880 | 0.37 | 7.7 | 7875 | 1186 | 3.7 | 50392 | 7.0 |
| bench_rowmix | BANKAWARE | 312 | 839 | 0.37 | 7.2 | 7933 | 1138 | 3.7 | 54649 | 7.0 |
| bench_rowwalk | FCFS | 103 | 457 | 0.38 | 0.0 | 0 | 6 | 6.8 | 39571 | 17.8 |
| bench_rowwalk | RDPRIO | 162 | 694 | 0.36 | 0.0 | 3644 | 1143 | 4.9 | 122711 | 8.2 |
| bench_rowwalk | FRFCFS | 162 | 694 | 0.36 | 0.0 | 3644 | 1143 | 4.9 | 122711 | 8.2 |
| bench_rowwalk | BANKAWARE | 157 | 686 | 0.33 | 0.0 | 2819 | 619 | 6.5 | 102673 | 9.7 |
| bench_hotbank | FCFS | 860 | 1551 | 0.40 | 4.8 | 0 | 1494 | 3.6 | 0 | 2.5 |
| bench_hotbank | RDPRIO | 860 | 1557 | 0.40 | 4.9 | 9978 | 1496 | 3.6 | 98 | 2.5 |
| bench_hotbank | FRFCFS | 860 | 1545 | 0.40 | 4.9 | 9976 | 1497 | 3.6 | 632 | 2.5 |
| bench_hotbank | BANKAWARE | 860 | 1545 | 0.40 | 4.9 | 9976 | 1497 | 3.6 | 632 | 2.5 |
| bench_vector | FCFS | 34 | 438 | 0.32 | 0.0 | 0 | 687 | 4.9 | 32453 | 15.0 |
| bench_vector | RDPRIO | 18 | 504 | 0.30 | 0.0 | 37 | 831 | 3.7 | 30056 | 17.5 |
| bench_vector | FRFCFS | 18 | 458 | 0.29 | 0.0 | 34 | 877 | 4.1 | 28899 | 17.7 |
| bench_vector | BANKAWARE | 18 | 469 | 0.29 | 0.0 | 35 | 856 | 4.1 | 28996 | 18.0 |
| bench_dma_copy | FCFS | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | RDPRIO | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | FRFCFS | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_dma_copy | BANKAWARE | 0 | 0 | 0.75 | 0.0 | 0 | 507 | 0.0 | 44496 | 8.0 |
| bench_tensor_alone | FCFS | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | RDPRIO | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | FRFCFS | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor_alone | BANKAWARE | 0 | 0 | 0.03 | 0.0 | 0 | 113 | 0.1 | 341 | 25.8 |
| bench_tensor | FCFS | 69 | 512 | 0.49 | 0.0 | 0 | 628 | 5.6 | 77063 | 15.9 |
| bench_tensor | RDPRIO | 40 | 571 | 0.33 | 0.0 | 210 | 753 | 5.2 | 56060 | 17.5 |
| bench_tensor | FRFCFS | 38 | 567 | 0.32 | 0.0 | 290 | 681 | 5.8 | 49958 | 19.3 |
| bench_tensor | BANKAWARE | 37 | 545 | 0.32 | 0.0 | 271 | 647 | 5.6 | 49870 | 19.6 |
| bench_ctrl_probe | FCFS | 99 | 590 | 0.47 | 0.0 | 0 | 532 | 5.8 | 71031 | 15.4 |
| bench_ctrl_probe | RDPRIO | 67 | 618 | 0.31 | 0.1 | 784 | 1178 | 5.9 | 78725 | 15.3 |
| bench_ctrl_probe | FRFCFS | 58 | 589 | 0.30 | 0.0 | 774 | 1264 | 6.3 | 78842 | 17.1 |
| bench_ctrl_probe | BANKAWARE | 54 | 557 | 0.30 | 0.0 | 763 | 1106 | 6.6 | 78843 | 17.8 |
| bench_system | FCFS | 100 | 597 | 0.45 | 0.0 | 0 | 799 | 6.2 | 94229 | 15.6 |
| bench_system | RDPRIO | 59 | 578 | 0.29 | 0.4 | 736 | 923 | 5.9 | 67793 | 16.8 |
| bench_system | FRFCFS | 54 | 581 | 0.28 | 0.1 | 672 | 836 | 6.2 | 56652 | 18.7 |
| bench_system | BANKAWARE | 51 | 566 | 0.28 | 0.3 | 619 | 765 | 6.2 | 55741 | 19.0 |

## Per-source view: `bench_system` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 279 | 255 | 658 | 924 | 103680 |
| FCFS | 1 | 3471 | 111072 | 279 | 256 | 650 | 893 | 104611 |
| FCFS | 2 | 3501 | 112032 | 277 | 252 | 660 | 942 | 104585 |
| FCFS | 3 | 2639 | 83593 | 250 | 229 | 610 | 774 | 20090 |
| FCFS | 4 | 3700 | 118400 | 262 | 242 | 620 | 871 | 104327 |
| RDPRIO | 0 | 3456 | 110592 | 171 | 140 | 558 | 762 | 62145 |
| RDPRIO | 1 | 2315 | 74080 | 259 | 241 | 678 | 850 | 64556 |
| RDPRIO | 2 | 1798 | 57536 | 334 | 323 | 725 | 948 | 65006 |
| RDPRIO | 3 | 1631 | 51574 | 194 | 160 | 536 | 802 | 10030 |
| RDPRIO | 4 | 2161 | 69152 | 277 | 263 | 687 | 814 | 64701 |
| FRFCFS | 0 | 3456 | 110592 | 143 | 115 | 500 | 761 | 51712 |
| FRFCFS | 1 | 2279 | 72928 | 221 | 193 | 630 | 860 | 53796 |
| FRFCFS | 2 | 1782 | 57024 | 282 | 267 | 716 | 836 | 54361 |
| FRFCFS | 3 | 1376 | 43607 | 198 | 166 | 557 | 661 | 8824 |
| FRFCFS | 4 | 1678 | 53696 | 300 | 302 | 673 | 905 | 54374 |
| BANKAWARE | 0 | 3456 | 110592 | 139 | 115 | 481 | 739 | 50319 |
| BANKAWARE | 1 | 2341 | 74912 | 210 | 181 | 609 | 823 | 52576 |
| BANKAWARE | 2 | 1690 | 54080 | 290 | 275 | 750 | 949 | 52852 |
| BANKAWARE | 3 | 1366 | 43189 | 195 | 160 | 526 | 620 | 8808 |
| BANKAWARE | 4 | 1650 | 52800 | 298 | 308 | 667 | 838 | 52887 |

## Per-source view: `bench_tensor` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 232 | 209 | 592 | 713 | 85367 |
| FCFS | 1 | 3467 | 110944 | 233 | 210 | 599 | 725 | 86588 |
| FCFS | 2 | 3505 | 112160 | 230 | 207 | 611 | 822 | 86571 |
| FCFS | 4 | 3657 | 117024 | 221 | 201 | 585 | 767 | 86402 |
| RDPRIO | 0 | 3456 | 110592 | 145 | 121 | 453 | 659 | 52492 |
| RDPRIO | 1 | 2343 | 74976 | 217 | 192 | 610 | 783 | 54368 |
| RDPRIO | 2 | 1902 | 60864 | 267 | 241 | 681 | 920 | 54822 |
| RDPRIO | 4 | 2251 | 72032 | 226 | 202 | 592 | 697 | 54488 |
| FRFCFS | 0 | 3456 | 110592 | 128 | 107 | 451 | 576 | 46072 |
| FRFCFS | 1 | 2642 | 84544 | 170 | 145 | 528 | 679 | 47544 |
| FRFCFS | 2 | 1972 | 63104 | 228 | 200 | 646 | 920 | 48227 |
| FRFCFS | 4 | 1732 | 55424 | 260 | 250 | 610 | 847 | 48433 |
| BANKAWARE | 0 | 3456 | 110592 | 129 | 106 | 477 | 667 | 46428 |
| BANKAWARE | 1 | 2650 | 84800 | 172 | 143 | 520 | 768 | 48384 |
| BANKAWARE | 2 | 2068 | 66176 | 221 | 196 | 606 | 840 | 48995 |
| BANKAWARE | 4 | 1864 | 59648 | 245 | 230 | 626 | 758 | 49175 |

## Per-source view: `bench_ctrl_probe` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 2553 | 81696 | 281 | 254 | 664 | 806 | 77489 |
| FCFS | 1 | 2553 | 81696 | 281 | 256 | 674 | 811 | 77494 |
| FCFS | 2 | 2577 | 82464 | 279 | 250 | 683 | 852 | 77510 |
| FCFS | 3 | 1890 | 59766 | 254 | 230 | 631 | 701 | 14938 |
| FCFS | 4 | 2733 | 87456 | 263 | 238 | 644 | 905 | 77269 |
| RDPRIO | 0 | 2993 | 95776 | 240 | 214 | 606 | 795 | 77087 |
| RDPRIO | 1 | 2741 | 87712 | 262 | 241 | 631 | 841 | 77302 |
| RDPRIO | 2 | 2186 | 69952 | 328 | 312 | 773 | 976 | 77855 |
| RDPRIO | 3 | 2013 | 63907 | 195 | 159 | 550 | 641 | 11426 |
| RDPRIO | 4 | 2593 | 82976 | 277 | 258 | 656 | 900 | 77407 |
| FRFCFS | 0 | 3311 | 105952 | 216 | 184 | 598 | 827 | 76728 |
| FRFCFS | 1 | 3161 | 101152 | 227 | 192 | 624 | 898 | 76849 |
| FRFCFS | 2 | 2444 | 78208 | 294 | 274 | 745 | 1046 | 77597 |
| FRFCFS | 3 | 1968 | 62196 | 205 | 170 | 607 | 804 | 14230 |
| FRFCFS | 4 | 2414 | 77248 | 298 | 292 | 694 | 913 | 77736 |
| BANKAWARE | 0 | 4012 | 128384 | 178 | 148 | 554 | 974 | 76011 |
| BANKAWARE | 1 | 3502 | 112064 | 205 | 176 | 603 | 785 | 76514 |
| BANKAWARE | 2 | 2598 | 83136 | 276 | 256 | 683 | 968 | 77417 |
| BANKAWARE | 3 | 2028 | 64394 | 188 | 151 | 555 | 694 | 12049 |
| BANKAWARE | 4 | 2559 | 81888 | 280 | 272 | 665 | 880 | 77473 |

## Per-source view: `bench_tensor_alone` (first seed)

Source 0 = TENSOR, 1 = VECTOR, 2 = STREAMDMA, 3 = CONTROL, 4 = CLOUD. *e2e* = from the cycle a request is offered at the port to its response.

| policy | src | requests | bytes | e2e mean | e2e p50 | e2e p99 | e2e max | ingress stall cyc |
|---|---|---|---|---|---|---|---|---|
| FCFS | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| RDPRIO | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| FRFCFS | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |
| BANKAWARE | 0 | 3456 | 110592 | 27 | 23 | 70 | 349 | 7095 |

## Tensor starvation (tile-fetch flow, double-buffered consumer)

| workload | policy | tiles | compute idle cycles (after first start) | longest idle run | span (cycles) | idle % | first-tile wait |
|---|---|---|---|---|---|---|---|
| bench_tensor_alone | FCFS | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | RDPRIO | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | FRFCFS | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor_alone | BANKAWARE | 24 | 697 | 253 | 13363 | 5.2 | 378 |
| bench_tensor | FCFS | 24 | 74506 | 4168 | 89305 | 83.4 | 2511 |
| bench_tensor | RDPRIO | 24 | 41540 | 2518 | 56311 | 73.8 | 2483 |
| bench_tensor | FRFCFS | 24 | 35981 | 2407 | 49880 | 72.1 | 1611 |
| bench_tensor | BANKAWARE | 24 | 36262 | 2361 | 50128 | 72.3 | 1578 |
| bench_system | FCFS | 24 | 91745 | 5059 | 107582 | 85.3 | 3549 |
| bench_system | RDPRIO | 24 | 51796 | 3382 | 66066 | 78.4 | 1982 |
| bench_system | FRFCFS | 24 | 41377 | 2237 | 55547 | 74.5 | 1882 |
| bench_system | BANKAWARE | 24 | 39961 | 2428 | 54022 | 74.0 | 1773 |
