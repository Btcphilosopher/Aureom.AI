# RTL mutation check

28 injected bugs (one at a time, on a copy of the RTL), full scenario list, seeds [1, 2, 3]: **28 killed, 0 survived, 0 invalid** (invalid = edit did not apply / mutant did not build; never counted as killed).

| mutant | file | config | what it breaks | result | killed by |
|---|---|---|---|---|---|
| raw_mask_dropped | sf_hbm_read_queue.sv | base | RAW hazard: a read may pass an older write to the same granule | KILLED | fcfs_saturate, policy |
| war_mask_dropped | sf_hbm_write_queue.sv | base | WAR hazard: a write may pass an older read of the same granule | KILLED | policy |
| waw_mask_dropped | sf_hbm_write_queue.sv | base | WAW hazard: two writes to one granule may swap | KILLED | fcfs_saturate |
| order_disabled | sf_hbm_trk_slot.sv | base | responses delivered as soon as complete (no re-ordering) | KILLED | backpressure, be_err, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, timeout, timeout_flush |
| order_mode1_no_order | sf_hbm_trk_slot.sv | ord1 | same-id ordering not enforced in ORDER_MODE 1 | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, seq, smoke, timeout, timeout_flush |
| no_zombie | sf_hbm_trk_slot.sv | base | timed-out slot freed at once: a late response can hit a re-allocated slot | KILLED | timeout |
| timeout_never | sf_hbm_trk_slot.sv | base | timeout never fires | KILLED | timeout |
| flush_ignored | sf_hbm_trk_slot.sv | base | link flush does not fail in-flight transactions | KILLED | fatal, fault, timeout_flush |
| read_beat_index | sf_hbm_trk_slot.sv | base | all read beats land in beat 0 | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, seq, smoke, timeout, timeout_flush |
| ue_never_reported | sf_hbm_trk_slot.sv | base | uncorrectable ECC reported as another status | KILLED | be_err |
| wdata_beat_order | sf_hbm_backend_adapter.sv | base | write beats reversed | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, seq, smoke, timeout, timeout_flush |
| wstrb_beat0 | sf_hbm_backend_adapter.sv | base | byte enables of beat 0 used for every beat | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, timeout, timeout_flush |
| out_counter_stuck | sf_hbm_backend_adapter.sv | base | outstanding counter never decrements | KILLED | TIMEOUT |
| out_counter_one_dec | sf_hbm_backend_adapter.sv | ord1 | REVIEW FINDING 1 re-introduced: one decrement when a read-last and a write response coincide | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, timeout, timeout_flush |
| flush_zombie_reintro | sf_hbm_trk_slot.sv | base | REVIEW FINDING 2 re-introduced: flushed timed-out slot becomes a permanent zombie | KILLED | timeout_flush |
| fcfs_no_fallback | sf_hbm_scheduler.sv | base | REVIEW FINDING 3 re-introduced: FCFS waits for a hazard-blocked oldest entry (deadlock after age saturation) | KILLED | fcfs_saturate |
| cmd_len_wrong | sf_hbm_backend_adapter.sv | base | SFMC command length off by one | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, seq, smoke, timeout, timeout_flush |
| issue_ignores_link | sf_hbm_backend_adapter.sv | base | commands presented while the controller is not ready | KILLED | fatal, fcfs_order, fcfs_saturate, prefill, timeout_flush |
| tag_swapped | sf_hbm_lane.sv | base | tag of the wrong queue travels to the backend | KILLED | TIMEOUT |
| arb_wdata_source0 | sf_hbm_lane.sv | base | write data of source 0 stored for every source | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, seq, smoke, timeout, timeout_flush |
| inflight_mask_dropped | sf_hbm_lane.sv | unsafe | BE_ORDER_SAFE=0: reads no longer wait for in-flight writes | KILLED | be_err, fatal, fault, fcfs_saturate, hazard, policy, qsat, reset, timeout, timeout_flush |
| wq_wrong_data | sf_hbm_write_queue.sv | base | issued write carries the data of entry 0 | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, seq, timeout, timeout_flush |
| addr_bg_flipped | sf_hbm_address_map.sv | base | bank-group bit flipped in the lane-local address | KILLED | arb_prio, backpressure, be_err, contend, fatal, fault, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, reset, seq, smoke, timeout, timeout_flush |
| align_check_removed | sf_hbm_req_check.sv | base | misaligned requests accepted | KILLED | invalid |
| perm_rw_swapped | sf_hbm_req_check.sv | base | read / write permission bits swapped | KILLED | invalid |
| fcfs_youngest_first | sf_hbm_scheduler.sv | base | FCFS picks the younger queue head | KILLED | fcfs_order |
| sched_ignores_deps | sf_hbm_scheduler.sv | base | policies 1-3 issue reads whose dependency has not issued | KILLED | fcfs_saturate, policy |
| perf_wbytes_missing | sf_hbm_sched_top.sv | base | write bytes not counted | KILLED | arb_prio, backpressure, be_err, contend, fcfs_order, fcfs_saturate, hazard, invalid, multi_ch, outlimit, policy, prefill, qsat, rand_mixed, refresh, reorder, seq, smoke |

Analysis of the result (survivors, margins, what is not covered): reports/mutation_analysis.md.
