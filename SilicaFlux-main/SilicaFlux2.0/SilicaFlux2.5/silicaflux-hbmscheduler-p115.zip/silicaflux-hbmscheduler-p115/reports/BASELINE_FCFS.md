# Baseline: strict FCFS (policy 0), measured

Configuration `base`. **This table was produced and frozen before any other scheduling policy was measured** (the files were written in this order;
`reports/bench/*.json` carry the SHA-256 of every RTL file used). All figures are **MODELLED**: RTL simulation against the HYPOTHETICAL behavioural memory
model (`docs/TIMING_MODEL.md`), not a device. Peak = lanes x DATA_W/8 bytes per cycle.

* run `baseline_fcfs_final` (config `base`, policies [0], seeds [1, 2, 3], N=2000 requests / source), binary sha256 `dac33209e995e5d3`, bench sha256 `2b4a524ee3920012`, created 2026-11-20 17:50:31

Definitions: *useful B/cycle* = payload bytes of successful responses (enabled bytes for writes) / cycles between the first accept and the last response;
*row hit / conflict %* = backend-reported at the column command (model pins), *mean lat / p99* = accept -> response delivered (cycles),
*q-wait* = accept -> issue to the backend, *turnarounds/req* = read<->write direction changes at issue per issued command,
*ROB stall* = cycles in which a completed response was held back by the ordering rule.

| workload | useful B/cycle | % of peak | lane util % | mean lat | p99 lat | row hit % | row conflict % | mean q-wait | turnarounds/req | refresh stall % | ROB stall cyc |
|---|---|---|---|---|---|---|---|---|---|---|---|
| bench_seq_rd | 22.52 | 70.4 | 70.4 | 56 | 359 | 96.6 | 2.2 | 31 | 0.00 | 6.2 | 3548 |
| bench_seq_wr | 22.74 | 71.1 | 71.1 | 55 | 363 | 96.5 | 2.2 | 30 | 0.00 | 6.3 | 5070 |
| bench_seq_mix | 8.77 | 27.4 | 27.4 | 145 | 452 | 96.0 | 1.0 | 60 | 0.42 | 6.4 | 30809 |
| bench_seq_rd_aligned | 1.27 | 4.0 | 4.0 | 1003 | 1246 | 0.0 | 99.3 | 599 | 0.00 | 7.3 | 4607 |
| bench_rand_rd | 5.04 (5.01..5.06) | 15.7 | 15.7 | 249 | 588 (569..607) | 1.4 | 94.1 | 111 | 0.00 | 6.3 | 57061 |
| bench_rand_mix | 4.45 (4.44..4.47) | 13.9 | 13.9 | 285 | 643 (640..645) | 1.4 | 93.7 | 128 | 0.42 | 5.9 | 65328 |
| bench_rowmix | 2.14 (2.13..2.14) | 6.7 | 6.7 | 441 | 846 (824..868) | 32.6 | 66.2 | 319 | 0.41 | 3.7 | 0 |
| bench_rowwalk | 5.69 (5.68..5.70) | 17.8 | 17.8 | 224 | 523 (517..526) | 0.0 | 99.4 | 103 | 0.38 | 6.8 | 39571 |
| bench_hotbank | 0.80 (0.80..0.80) | 2.5 | 2.5 | 1183 | 1685 (1674..1704) | 24.8 | 74.8 | 860 | 0.40 | 3.6 | 0 |
| bench_vector | 4.80 (4.75..4.85) | 15.0 | 15.0 | 158 | 518 (466..587) | 47.6 | 47.2 | 34 | 0.32 | 4.9 | 32453 |
| bench_dma_copy | 2.56 | 8.0 | 8.0 | 199 | 494 | 47.1 | 48.9 | 0 | 0.75 | 0.0 | 44496 |
| bench_tensor_alone | 8.24 | 25.8 | 25.8 | 24 | 48 | 96.6 | 0.5 | 0 | 0.03 | 0.1 | 341 |
| bench_tensor | 5.08 (5.00..5.13) | 15.9 | 15.9 | 200 | 539 (529..557) | 60.4 | 34.9 | 69 | 0.49 | 5.6 | 77063 |
| bench_ctrl_probe | 4.90 (4.90..4.91) | 15.3 | 15.4 | 246 | 612 (599..618) | 48.7 | 46.4 | 99 | 0.47 | 5.8 | 71031 |
| bench_system | 4.98 (4.95..5.03) | 15.6 | 15.6 | 242 | 587 (583..592) | 48.4 | 46.9 | 100 | 0.45 | 6.2 | 94229 |

