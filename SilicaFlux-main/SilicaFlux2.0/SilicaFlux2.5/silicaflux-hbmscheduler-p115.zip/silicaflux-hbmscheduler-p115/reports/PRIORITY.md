# Arbiter priority study (MODELLED)

Per-lane arbiter modes (`cfg_arb_mode`, `cfg_arb_prio`, `cfg_arb_age`), scheduler age limit 1024, seeds 1-3 (mean). *CONTROL e2e* = ControlCore probes, offer -> response; *tensor idle %* = consumer idle cycles / span of the 24-tile run; *span* = cycles for the 24 tiles. `-` = not applicable to the workload.
| arbiter | policy | workload | runs | B/cycle | CONTROL e2e mean | CONTROL e2e p99 | CONTROL e2e max | tensor idle % | tensor span |
|---|---|---|---|---|---|---|---|---|---|
| round robin (no priority) | FCFS | bench_ctrl_probe | 3 | 4.90 | 253 | 629 | 752 | - | - |
| round robin (no priority) | FCFS | bench_tensor | 3 | 5.08 | - | - | - | 83.0 | 88412 |
| round robin (no priority) | FCFS | bench_system | 3 | 4.98 | 249 | 600 | 725 | 85.4 | 106755 |
| round robin (no priority) | BANKAWARE | bench_ctrl_probe | 3 | 6.06 | 190 | 689 | 1006 | - | - |
| round robin (no priority) | BANKAWARE | bench_tensor | 3 | 6.42 | - | - | - | 71.2 | 48279 |
| round robin (no priority) | BANKAWARE | bench_system | 3 | 6.32 | 195 | 696 | 944 | 72.6 | 51432 |
| CONTROL first, TENSOR second (+PRIO=1) | FCFS | bench_ctrl_probe | 3 | 4.93 | 253 | 599 | 749 | - | - |
| CONTROL first, TENSOR second (+PRIO=1) | FCFS | bench_tensor | 3 | 5.13 | - | - | - | 82.8 | 87498 |
| CONTROL first, TENSOR second (+PRIO=1) | FCFS | bench_system | 3 | 5.03 | 246 | 586 | 697 | 85.1 | 104889 |
| CONTROL first, TENSOR second (+PRIO=1) | BANKAWARE | bench_ctrl_probe | 3 | 6.04 | 194 | 676 | 818 | - | - |
| CONTROL first, TENSOR second (+PRIO=1) | BANKAWARE | bench_tensor | 3 | 6.49 | - | - | - | 70.6 | 47700 |
| CONTROL first, TENSOR second (+PRIO=1) | BANKAWARE | bench_system | 3 | 6.37 | 199 | 806 | 1108 | 72.5 | 51048 |
| TENSOR first, CONTROL second (+PRIO=2) | FCFS | bench_ctrl_probe | 3 | 4.88 | 253 | 615 | 730 | - | - |
| TENSOR first, CONTROL second (+PRIO=2) | FCFS | bench_tensor | 3 | 5.13 | - | - | - | 82.8 | 87498 |
| TENSOR first, CONTROL second (+PRIO=2) | FCFS | bench_system | 3 | 5.00 | 247 | 603 | 733 | 85.3 | 106096 |
| TENSOR first, CONTROL second (+PRIO=2) | BANKAWARE | bench_ctrl_probe | 3 | 5.95 | 197 | 728 | 1179 | - | - |
| TENSOR first, CONTROL second (+PRIO=2) | BANKAWARE | bench_tensor | 3 | 6.49 | - | - | - | 70.6 | 47700 |
| TENSOR first, CONTROL second (+PRIO=2) | BANKAWARE | bench_system | 3 | 6.37 | 206 | 748 | 1065 | 72.8 | 51314 |
