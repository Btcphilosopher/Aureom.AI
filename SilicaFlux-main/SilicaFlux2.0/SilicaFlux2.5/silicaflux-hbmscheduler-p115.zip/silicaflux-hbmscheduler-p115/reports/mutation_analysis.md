# Mutation check - what the result does and does not show

Data: `reports/mutation.md` / `.json` (final bench, 28 mutants, seeds 1-3, N = 300) and `reports/mutation_first_run.md` / `.json` (the first run, before the bench was extended).
A mutant is one deliberate bug injected into a copy of the RTL (`scripts/run_mutation.py`, list in the script); it is *killed* when any scenario fails, the simulator crashes, or it times out.

## Outcome

| run | bench | killed | survived | invalid |
|---|---|---|---|---|
| first | 22 scenarios | 27 | **1** (`fcfs_youngest_first`) | 0 |
| final | 23 scenarios (`fcfs_order` added) | **28** | 0 | 0 |

**The 28 / 28 is not independent evidence.** The only survivor of the first run was analysed, a scenario was written *because of it*, and the same mutant list was then run again. That is a bench tuned to a
known miss; it says that this one gap is closed, nothing about the bugs nobody thought of. The first run's 27 / 28 is the better estimate of how strong the bench was before it saw the survivor.

## The survivor and why it survived

`fcfs_youngest_first` (strict FCFS chooses the *younger* of the oldest read and the oldest write). Every check in the bench looks at **results** - data, status, response order, hazards, counters - and none of those depends on
the order in which independent, hazard-free commands reach the backend. Only throughput and latency change, and those are measured by the benchmarks, not asserted by the regression. The new scenario `fcfs_order` records
the acceptance order per lane in the bench and compares it with the commands on the SFMC wires (1500 commands per run on the unmutated RTL, about 750 read / write alternations so the check cannot be vacuous).
On the mutant it fails at cycle 74.

## Margins the result hides

* **Ten mutants are caught by exactly one scenario** - if that scenario were weakened, the bug would pass: `war_mask_dropped` (`policy`), `waw_mask_dropped` (`fcfs_saturate`), `no_zombie` and `timeout_never` (`timeout`),
  `ue_never_reported` (`be_err`), `flush_zombie_reintro` (`timeout_flush`), `fcfs_no_fallback` (`fcfs_saturate`), `align_check_removed` and `perm_rw_swapped` (`invalid`), `fcfs_youngest_first` (`fcfs_order`).
* **Two mutants were not caught on seed 1**: `war_mask_dropped` and `waw_mask_dropped` were killed only on seed 2 (the script stops at the first killing seed, so what seed 3 would have done is not recorded). A one-seed regression would have let them through.
* **The RAW / WAR / WAW hazard mutants are not caught by the `hazard` scenario.** Under the default policy (FCFS) nothing is reordered, so a missing dependency mask cannot be seen; they die only in the
  reordering-policy runs (`policy`) or when FCFS is forced to bypass a blocked entry (`fcfs_saturate`). Hazard traffic that is *not* also run under a reordering policy tests nothing about the masks.
* **Two mutants were killed only by the simulator timeout** (`out_counter_stuck`, `tag_swapped`): the design hung and no check fired. That is a kill, but a weaker one than a failing assertion with a message.

## What the 28 mutants do not cover

* **No mutant in the policy ranking keys** (the BANKAWARE tiers, the FR-FCFS row-hit key, the write-drain watermarks, the age override). A bug there would not corrupt data, so the functional checks would not see it; only the
  benchmark tables would move. `docs/LIMITATIONS.md` states this gap; a reference model of each policy's choice would be needed to close it, and was not written.
* Almost nothing in the performance counters (one mutant, `perf_wbytes_missing`), the refresh handling, the arbiter's priority / aging logic, or the memory model and the bench themselves.
* 28 hand-written mutants are a small sample; the mutation score is a measure of the bench on *these* bugs, not a coverage metric. No code or functional coverage was collected.
