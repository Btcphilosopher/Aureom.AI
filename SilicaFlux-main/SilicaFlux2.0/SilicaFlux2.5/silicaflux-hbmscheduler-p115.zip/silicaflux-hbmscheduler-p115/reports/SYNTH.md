# Synthesis statistics (Yosys 0.33, generic gates; PROXIES, no PDK / timing)

`synth -top T -flatten` to Yosys' internal gate set. *Flip-flops* include the register-file style storage of the queues / tracker (a real flow maps those to register files or SRAM). *Levels* = `ltp` longest topological path of the flattened generic netlist. `check -assert` = no combinational loop, multiple driver or undriven net. **Not area, not frequency, not power; no timing closure is claimed.**

| block | configuration | cells | flip-flops | latches | logic cells | mux cells | longest path (levels) | check -assert |
|---|---|---|---|---|---|---|---|---|
| sf_hbm_address_map | defaults | 12 | 0 | 0 | 12 | 0 | 4 | ok |
| sf_hbm_req_check | defaults | 1466 | 0 | 0 | 1466 | 4 | 29 | ok |
| sf_hbm_channel_arbiter | defaults | 1212 | 43 | 0 | 1169 | 150 | 66 | ok |
| sf_hbm_read_queue | defaults | 4267 | 1024 | 0 | 3243 | 813 | 24 | ok |
| sf_hbm_write_queue | defaults | 15032 | 5888 | 0 | 9144 | 5389 | 24 | ok |
| sf_hbm_scheduler | defaults | 13640 | 252 | 0 | 13388 | 6066 | 171 | ok |
| sf_hbm_maxsel | defaults | 1241 | 0 | 0 | 1241 | 194 | 50 | ok |
| sf_hbm_backend_adapter | defaults | 2670 | 1262 | 0 | 1408 | 1042 | 12 | ok |
| sf_hbm_trk_slot | defaults | 2692 | 366 | 0 | 2326 | 158 | 33 | ok |
| sf_hbm_trk_src | defaults | 30033 | 2932 | 0 | 27101 | 3757 | 108 | ok |
| sf_hbm_response_tracker | defaults | 149085 | 14660 | 0 | 134425 | 18823 | 108 | ok |
| sf_hbm_perf | defaults | 52406 | 7328 | 0 | 45078 | 240 | 28 | ok |
| sf_hbm_lane | defaults | 38162 | 8071 | 0 | 30091 | 15133 | 171 | ok |
| top_2lane_default | defaults | 283045 | 37643 | 0 | 245402 | 49642 | 268 | ok |
| lane_unsafe_BE_ORDER_SAFE0 | {'BE_ORDER_SAFE': 0} | 47651 | 8271 | 0 | 39380 | 15181 | 178 | ok |
| lane_queue8 | {'RQ_DEPTH': 8, 'WQ_DEPTH': 8} | 21982 | 4615 | 0 | 17367 | 8765 | 141 | ok |
| lane_queue32 | {'RQ_DEPTH': 32, 'WQ_DEPTH': 32} | 76750 | 16135 | 0 | 60615 | 29068 | 202 | ok |
| tracker_order1 | {'ORDER_MODE': 1} | 150961 | 14660 | 0 | 136301 | 18820 | 108 | ok |
| tracker_4lane | {'NUM_LANES': 4} | 162074 | 14700 | 0 | 147374 | 29521 | 108 | ok |

## What the numbers say (computed from the table above)

* **Where the 2-lane top goes:** response tracker 53 % of the cells, the two lanes 27 %, performance counters 19 % (the remainder is request validation and arbitration; module numbers do not add up exactly after flattening and logic optimisation). Storage written as flip-flop arrays dominates the flip-flop count (37643 in the top): in silicon the queues, the tracker's read-data store and the counters belong in register files or SRAM.
* **Lane cost vs queue depth** (read + write queue entries each): 8 -> 21982 cells / 141 levels, 16 (default) -> 38162 / 171, 32 -> 76750 / 202. The cell count grows about linearly with depth; the pick logic gets deeper by roughly 30 levels per doubling.
* **`BE_ORDER_SAFE = 0`** (in-flight hazard table for a backend that may reorder same-address accesses): lane +24.9 % cells, 178 vs 171 levels.
* **Tracker variants:** `ORDER_MODE = 1` +1.3 % cells; 4 lanes instead of 2 +8.7 % cells. The tracker is dominated by its per-source storage and order matrices, not by the number of lanes.
* **Critical path:** the scheduler's pick is the deepest block on its own (171 levels, against 108 for the tracker). The longest path in the flattened top (see `top_2lane_default`) starts at a write-queue age register and ends at the result of a **48-bit adder**; the performance counters are the 48-bit logic of the design (`CNT_W = 48`), so the path continues from the pick into a counter increment (inferred from the width: the flattened net names do not say which counter). Feeding the counters from *registered* events would be expected to remove that extension; this was not tried.
* **Not run:** a tracker with `OUT_PER_SRC = 16`, and 4- or 8-lane top levels. Yosys exceeded ~9.6 GB and was killed by the kernel (out of memory) on the 15 GB build machine, so there is no result for them; that is a limit of this proxy flow, not a statement about the design. Lanes are independent, so the lane row is the scaling unit.
* **Caveats that apply to every row:** generic gates, no cell library and no constraints; comparators and adders are mapped as ripple structures (depths overstate what a timing-driven flow produces); latch count is zero and `check -assert` passes (no combinational loop, multiple driver or undriven net). No area, frequency or power claim is made.
