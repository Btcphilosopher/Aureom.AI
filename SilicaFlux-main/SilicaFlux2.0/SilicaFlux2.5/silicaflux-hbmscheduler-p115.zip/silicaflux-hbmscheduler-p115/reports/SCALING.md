# Channel scaling (MODELLED)

* run `scale_sc_ch1` (config `sc_ch1`, policies [0, 3], seeds [1], N=2000 requests / source), binary sha256 `8272543dcf460a04`, bench sha256 `8bf5d80f5de9955f`, created 2026-11-20 18:12:08
* run `scale_sc_ch2` (config `sc_ch2`, policies [0, 3], seeds [1], N=2000 requests / source), binary sha256 `dac33209e995e5d3`, bench sha256 `8bf5d80f5de9955f`, created 2026-11-20 18:12:19
* run `scale_sc_ch4` (config `sc_ch4`, policies [0, 3], seeds [1], N=2000 requests / source), binary sha256 `a87a3c912937f69b`, bench sha256 `8bf5d80f5de9955f`, created 2026-11-20 18:12:31
* run `scale_sc_pc2` (config `sc_pc2`, policies [0, 3], seeds [1], N=2000 requests / source), binary sha256 `2a8710a08b65d345`, bench sha256 `8bf5d80f5de9955f`, created 2026-11-20 18:12:44
* run `scale_sc_ch4pc2` (config `sc_ch4pc2`, policies [0, 3], seeds [1], N=2000 requests / source), binary sha256 `a31b00080973f26b`, bench sha256 `8bf5d80f5de9955f`, created 2026-11-20 18:13:01
* run `scale_sc_ch4pc2_win32` (config `sc_ch4pc2_win32`, policies [0, 3], seeds [1], N=2000 requests / source), binary sha256 `dfb280c470de0d04`, bench sha256 `8bf5d80f5de9955f`, created 2026-11-20 18:13:23

## FCFS: useful B/cycle (% of peak)

| workload | sc_ch1 | sc_ch2 | sc_ch4 | sc_pc2 | sc_ch4pc2 | sc_ch4pc2_win32 |
|---|---|---|---|---|---|---|
| bench_seq_rd | 11.19 (70 %) | 22.52 (70 %) | 46.04 (72 %) | 46.04 (72 %) | 55.46 (43 %) | 97.80 (76 %) |
| bench_seq_wr | 11.26 (70 %) | 22.74 (71 %) | 46.55 (73 %) | 46.55 (73 %) | 66.56 (52 %) | 97.98 (77 %) |
| bench_rand_mix | 2.26 (14 %) | 4.47 (14 %) | 8.00 (12 %) | 8.00 (12 %) | 12.69 (10 %) | 16.69 (13 %) |
| bench_system | 2.40 (15 %) | 4.95 (15 %) | 8.89 (14 %) | 8.89 (14 %) | 13.40 (10 %) | 18.41 (14 %) |

## BANKAWARE: useful B/cycle (% of peak)

| workload | sc_ch1 | sc_ch2 | sc_ch4 | sc_pc2 | sc_ch4pc2 | sc_ch4pc2_win32 |
|---|---|---|---|---|---|---|
| bench_seq_rd | 9.84 (61 %) | 19.72 (62 %) | 46.23 (72 %) | 46.23 (72 %) | 55.46 (43 %) | 100.85 (79 %) |
| bench_seq_wr | 10.88 (68 %) | 21.97 (69 %) | 50.26 (79 %) | 50.26 (79 %) | 66.56 (52 %) | 99.19 (77 %) |
| bench_rand_mix | 2.75 (17 %) | 4.85 (15 %) | 8.33 (13 %) | 8.33 (13 %) | 12.76 (10 %) | 17.54 (14 %) |
| bench_system | 4.75 (30 %) | 6.25 (20 %) | 9.38 (15 %) | 9.38 (15 %) | 13.40 (10 %) | 20.85 (16 %) |

## How to read this (and what it does not show)

* Configurations (`scripts/scale_configs.json`): `sc_ch1` = 1 lane, `sc_ch2` = 2 lanes (the default), `sc_ch4` = 4 channels, `sc_pc2` = 2 channels x 2 pseudo-channels (4 lanes),
  `sc_ch4pc2` = 8 lanes, `sc_ch4pc2_win32` = the same 8 lanes with the outstanding window raised from 8 to 32 per source and from 8 to 16 per lane. Peak = lanes x one 16-byte beat per cycle.
* **`sc_ch4` and `sc_pc2` are identical** to the digit. That is expected and is a limit of the model, not a result: a lane is an independent scheduling domain with its own behavioural
  memory, and the model has **no shared command / address bus, no pseudo-channel coupling and no shared refresh or power budget**. Real 2 x 2 and 4 x 1 organisations would not behave identically.
* **The 8-lane run with the default window is window-limited, not lane-limited.** Sequential read reaches 43 % of peak with the default window and 76 % with a window of 32 / 16
  (the same lanes, the same traffic). Treat the `sc_ch4pc2` column as "default sources cannot feed 8 lanes", and `sc_ch4pc2_win32` as the capacity of the lanes.
* Sequential traffic scales close to linearly up to 4 lanes under FCFS (11.2 -> 22.5 -> 46.0 B/cycle). The random-mix workload stays at 10-14 % of peak at every size; its absolute rate
  grows with lanes (2.3 -> 8.0 B/cycle from 1 to 4 lanes) but I did not diagnose why it grows less than linearly, so no cause is claimed.
* One seed (1), N = 2000 requests per source, no confidence interval: differences of a few percent are not significant. The policy columns repeat the policy study's configuration
  (`cfg_age_limit` 1024); the policy comparison itself is in `BENCHMARKS.md`, where more seeds were used.
* All values are from the behavioural memory model with the SIM_GENERIC profile. They say nothing about a real HBM stack.
