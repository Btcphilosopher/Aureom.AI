# Reused SilicaFlux IP (vendored UNMODIFIED)

| File | Origin in `btcphilosopher/Aureom.AI` | Used by | Why |
|---|---|---|---|
| `sync_fifo.sv` | `SilicaFlux-main/memory_cache_repo.zip` → `rtl/sync_fifo.sv` (own TB `tb_sync_fifo.sv`) | delay / decision / sideband FIFOs when `FIFO_RAM = 0` (FWFT=1) | Verified parameterised synchronous FIFO, power-of-2 depth. Its asynchronous-read memory synthesises to registers on an FPGA, so the engine default (`FIFO_RAM = 1`) uses the block-RAM `rtl/sf_pkt_fifo.sv` instead (both are regression-tested). |
| `sfb_skid_buffer.sv` | `SilicaFlux-main/silicaflux-datafabric.zip` → `rtl/interconnect/` (formal proof `fv_sfb_skid.sv`) | ingress register slice, AXIS MAC adapter TX slice | Formally-checked 2-entry valid/ready slice |
| `sf_rr_arb.sv` | `silicaflux-p40-floorplanbuild.zip` → `rtl/common/` | RR arbitration inside the scheduler (RR mode / intra-class) | Round-robin with advance-on-accept |
| `sf_reset_sync.sv` | same | optional reset bridge in MAC adapter | async-assert / sync-deassert |

SHA-256 of each vendored file is in `SHA256SUMS`; `make verify-vendor` re-checks it.
Not reusable (audited, no match in the repository): Ethernet MAC / PCS, AXI-Stream, IP one's-complement
checksum, Toeplitz/RSS. CRC-32 exists (`sfsec_crc`, SecureStore P59) but is not needed here because this
engine neither generates nor checks the Ethernet FCS (that belongs at the MAC).
