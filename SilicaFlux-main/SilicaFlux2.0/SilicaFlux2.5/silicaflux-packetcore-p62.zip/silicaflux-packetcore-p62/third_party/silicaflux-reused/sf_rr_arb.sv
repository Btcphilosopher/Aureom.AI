// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_rr_arb
// Round-robin arbiter. The priority pointer advances past the winner only when
// `advance` is asserted (i.e. the grant was accepted downstream).
// -----------------------------------------------------------------------------
module sf_rr_arb #(
  parameter int N  = 3,
  parameter int IW = (N > 1) ? $clog2(N) : 1
) (
  input  logic          clk,
  input  logic          rst_n,
  input  logic [N-1:0]  req,
  input  logic          advance,
  output logic [N-1:0]  gnt,
  output logic [IW-1:0] gnt_idx,
  output logic          any
);
  logic [IW-1:0] last;
  logic [IW:0]   cand;

  always_comb begin
    gnt     = '0;
    gnt_idx = '0;
    any     = 1'b0;
    cand    = '0;
    for (int k = 1; k <= N; k++) begin
      cand = {1'b0, last} + k[IW:0];
      if (cand >= N[IW:0]) cand = cand - N[IW:0];
      if (!any && req[cand[IW-1:0]]) begin
        gnt[cand[IW-1:0]] = 1'b1;
        gnt_idx           = cand[IW-1:0];
        any               = 1'b1;
      end
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)              last <= IW'(N - 1);   // first grant favours index 0
    else if (advance && any) last <= gnt_idx;
  end
endmodule
