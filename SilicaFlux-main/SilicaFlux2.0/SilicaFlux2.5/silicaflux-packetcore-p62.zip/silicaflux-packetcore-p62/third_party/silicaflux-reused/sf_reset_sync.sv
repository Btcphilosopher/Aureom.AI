// -----------------------------------------------------------------------------
// SilicaFlux Project 40 | sf_reset_sync
// Asynchronous-assert / synchronous-deassert reset bridge.
// test_mode bypasses the synchroniser so reset is directly controllable (DFT).
// -----------------------------------------------------------------------------
module sf_reset_sync (
  input  logic clk,
  input  logic arst_n,
  input  logic test_mode,
  output logic rst_n_sync
);
  logic r1, r2;
  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) begin
      r1 <= 1'b0;
      r2 <= 1'b0;
    end else begin
      r1 <= 1'b1;
      r2 <= r1;
    end
  end
  assign rst_n_sync = test_mode ? arst_n : r2;
endmodule
