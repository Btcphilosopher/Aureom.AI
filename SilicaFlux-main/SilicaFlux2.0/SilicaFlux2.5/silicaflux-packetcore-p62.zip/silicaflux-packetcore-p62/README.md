# SilicaFlux PacketCore (Project 62) -- programmable cloud network processor

`silicaflux_packet_engine.sv` is a synthesizable SystemVerilog packet engine for the SilicaFlux CloudDPU: streaming ingress -> parse (Ethernet, VLAN, IPv4, IPv6, TCP, UDP, VXLAN metadata, RSS hash)
-> match/action classification -> egress queues (commit/abort) -> packet-atomic scheduler -> egress stream, with a management punt port, a versioned register interface with **hardware-enforced tenant
isolation**, in-flight DSCP/TTL rewrite with RFC 1624 checksum update, and a statistics block. It processes real packet streams, preserves bytes and ordering per its contract, and applies forwarding
policy under sustained traffic and back-pressure (measured **1.000 beats/cycle** for every frame size, including back-to-back minimum frames, DW = 64..512).

**Status: verified in simulation against an independent software model; synthesised (Yosys) and place-and-routed on a reduced reference configuration (nextpnr, ECP5-85F-6) where it fits but
does NOT meet a 50 MHz clock (20.6 - 27.8 MHz achieved, see `docs/FPGA.md`); the full default configuration does not fit that device. Not run on hardware, no vendor FPGA flow, no real Ethernet MAC attached.** Read `docs/ISSUES.md` before relying on anything; throughput figures in Gbit/s are analytical unless `docs/PERFORMANCE.md` says "measured".

## Layout

| Path | Contents |
|---|---|
| `rtl/silicaflux_packet_engine.sv` | **top level** (integration, admission control, FIFOs, statistics wiring) |
| `rtl/sf_pkt_parser.sv`, `sf_pkt_toeplitz.sv` | header-window capture + 7-stage II=1 parse pipeline, RSS-compatible hash |
| `rtl/sf_pkt_classifier.sv` | match/action lookup, policy, TC/queue selection, rewrite computation |
| `rtl/sf_pkt_dispatch.sv`, `sf_pkt_queue.sv`, `sf_pkt_fifo.sv` | frame steering with late checks + commit/abort, packet FIFOs, FWFT FIFO |
| `rtl/sf_pkt_sched.sv` | RR / strict priority + aging / DWRR, token-bucket rate limiting |
| `rtl/sf_pkt_regs.sv`, `sf_pkt_counters.sv` | versioned register file, rule table, tenant isolation; saturating counters with atomic snapshot |
| `rtl/sf_pkt_mac_adapter.sv` | AXI-S adapter for an *existing* Ethernet MAC |
| `rtl/sf_pkt_defs.svh`, `sf_pkt_macros.svh` | **generated** layouts (`tools/gen_defs.py`) |
| `third_party/silicaflux-reused/` | vendored SilicaFlux IP (unmodified, SHA-256 + provenance) |
| `model/` | independent software model, packet builders, test harness, regressions |
| `tb/` | Verilator testbenches (parser unit, system, MAC adapter) |
| `docs/` | `ARCHITECTURE`, `INTERFACE`, `PARSER_POLICY`, `CLASSIFIER`, `ISOLATION`, `SCHEDULER`, `REGISTERS` (generated), `VERIFICATION`, `PERFORMANCE`, `FPGA`, `ISSUES` |
| `reports/` | logs and `SUMMARY.md` of every regression / synthesis / place-and-route run |
| `synth/` | Yosys / nextpnr scripts and the place-and-route harness |

## Quick start

```bash
sudo apt install verilator yosys nextpnr-ecp5 python3-pip && pip install scapy     # Verilator 5.020, Yosys 0.33
make regress          # gen, vendor check, lint, model self-test, parser + system + sweep + MAC regressions, mutation check
make test-system      # just the default-configuration system regression (~1 min)
make synth            # Yosys + nextpnr (long)
```

Instantiate (defaults shown): `silicaflux_packet_engine #(.DW(128), .NUM_QUEUES(4), .NUM_RULES(16), .NUM_TENANTS(8), .MAX_FRAME_BYTES(9216), .QUEUE_BYTES(16384))` -- see `docs/ARCHITECTURE.md` for all
parameters and `docs/INTERFACE.md` for the stream contract (byte order, `keep`, partial final beats, `last`, error status, metadata, queue id).

## What is reused from the SilicaFlux repository

`sync_fifo`, `sfb_skid_buffer` (DataFabric, formally checked), `sf_rr_arb`, `sf_reset_sync` (P40) -- vendored unmodified. Audit result: **no Ethernet MAC/PHY, AXI-Stream infrastructure, IP checksum or Toeplitz hash exists
in the repository**; those were written here (checksum and hash validated against external references).
