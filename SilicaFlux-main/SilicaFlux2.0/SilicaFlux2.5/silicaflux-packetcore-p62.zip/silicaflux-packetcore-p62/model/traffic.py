"""Flow-based traffic generation for the system tests."""
import random
import struct

import pktgen as G
import pktmodel as M


class Flow:
    def __init__(self, rng, kind=None, vlans=None, vni=None, src=None):
        self.kind = kind or rng.choice(["udp4", "tcp4", "udp6", "tcp6", "vxlan4", "icmp4", "udp4", "tcp4"])
        self.vlans = vlans if vlans is not None else rng.choice([(), (), (), ((0x8100, rng.randrange(8), 0, rng.choice([100, 200, 300])),),
                                                                  ((0x88A8, 2, 0, rng.choice([100, 200])), (0x8100, 1, 0, 7))])
        self.sport = rng.randrange(1024, 65535)
        self.dport = rng.choice([53, 80, 443, 4789 if self.kind == "vxlan4" else 8080, 5001, 22, 25])
        if self.kind == "vxlan4":
            self.dport = 4789
        self.dscp = rng.choice([0, 0, 8, 10, 18, 26, 34, 46])
        self.ttl = rng.choice([64, 64, 128, 255, 2, 1])
        self.vni = vni if vni is not None else rng.randrange(1, 1 << 24)
        self.ip4s = "10.%d.%d.%d" % (rng.randrange(256), rng.randrange(256), rng.randrange(1, 255))
        self.ip4d = "192.168.%d.%d" % (rng.randrange(256), rng.randrange(1, 255))
        self.ip6s = "2001:db8:%x::%x" % (rng.randrange(1, 65535), rng.randrange(1, 65535))
        self.ip6d = "2001:db8:%x::%x" % (rng.randrange(1, 65535), rng.randrange(1, 65535))
        self.src = src if src is not None else rng.randrange(0, 16)
        self.flags = rng.choice([0x02, 0x10, 0x18, 0x11, 0x04])

    def build(self, rng, plen):
        pl = bytes(rng.randrange(256) for _ in range(plen))
        v = self.vlans
        if self.kind == "udp4":
            return G.eth(vlans=v) + G.ipv4(self.ip4s, self.ip4d, 17, G.udp(self.sport, self.dport, pl), ttl=self.ttl, tos=self.dscp << 2)
        if self.kind == "tcp4":
            return G.eth(vlans=v) + G.ipv4(self.ip4s, self.ip4d, 6, G.tcp(self.sport, self.dport, self.flags, pl), ttl=self.ttl, tos=(self.dscp << 2) | 1)
        if self.kind == "icmp4":
            return G.eth(vlans=v) + G.ipv4(self.ip4s, self.ip4d, 1, b"\x08\x00" + pl[:8].ljust(8, b"\0"), ttl=self.ttl, tos=self.dscp << 2)
        if self.kind == "udp6":
            return G.eth(etype=0x86DD, vlans=v) + G.ipv6(self.ip6s, self.ip6d, 17, G.udp(self.sport, self.dport, pl), hlim=self.ttl, tc=(self.dscp << 2) | 2, flow=0x12345)
        if self.kind == "tcp6":
            return G.eth(etype=0x86DD, vlans=v) + G.ipv6(self.ip6s, self.ip6d, 6, G.tcp(self.sport, self.dport, self.flags, pl), hlim=self.ttl, tc=self.dscp << 2)
        if self.kind == "vxlan4":
            inner = G.eth() + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2, pl[:20]))
            return G.eth(vlans=v) + G.ipv4(self.ip4s, self.ip4d, 17, G.udp(self.sport, 4789, G.vxlan(self.vni, inner)), ttl=self.ttl, tos=self.dscp << 2)
        raise ValueError(self.kind)


def plen_dist(rng):
    r = rng.random()
    if r < 0.35:
        return rng.randrange(0, 30)
    if r < 0.7:
        return rng.randrange(30, 400)
    if r < 0.95:
        return rng.randrange(400, 1500)
    return rng.randrange(1500, 4000)


def special(rng):
    """malformed / unusual frames"""
    k = rng.choice(["badcsum", "badver", "trunc", "frag", "nonip", "tinyvlan3", "ext6", "ihl", "udplen"])
    if k == "badcsum":
        return G.pad(G.eth() + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2, b"abcd"), csum=rng.randrange(65536)))
    if k == "badver":
        return G.pad(G.eth() + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2), ver=rng.choice([0, 3, 5, 6, 15])))
    if k == "trunc":
        p = G.pad(G.eth() + G.ipv4("1.1.1.1", "2.2.2.2", 6, G.tcp(1, 2, 0x10, b"x" * 30)))
        return p[:rng.randrange(14, 60)]
    if k == "frag":
        return G.pad(G.eth() + G.ipv4("9.9.9.9", "8.8.8.8", 17, G.udp(5, 6, b"f" * 40), flags=rng.choice([0, 1]), frag=rng.choice([0, 0, 64, 1000])))
    if k == "nonip":
        return G.pad(G.eth(etype=rng.choice([0x0806, 0x88CC, 0x8847, 0x0100])) + bytes(rng.randrange(256) for _ in range(rng.randrange(20, 120))))
    if k == "tinyvlan3":
        return G.pad(G.eth(vlans=[(0x8100, 0, 0, 1), (0x8100, 0, 0, 2), (0x8100, 0, 0, 3)]) + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2)))
    if k == "ext6":
        n = rng.randrange(1, 7)
        chain = b""
        for i in reversed(range(n)):
            chain = bytes([17 if i == n - 1 else 0, 0]) + bytes(6) + chain
        return G.pad(G.eth(etype=0x86DD) + G.ipv6("2001:db8::a", "2001:db8::b", 0, chain + G.udp(1, 2, b"e" * 12)))
    if k == "ihl":
        return G.pad(G.eth() + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2), ihl=rng.choice([0, 1, 2, 3, 4])))
    return G.pad(G.eth() + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2, b"abcd"), tot=rng.choice([0, 20, 27, 28, 100, 2000])))


def mix(rng, n, flows=None, special_frac=0.12, nflows=14, src_range=16, max_plen=None):
    flows = flows or [Flow(rng) for _ in range(nflows)]
    out = []
    for _ in range(n):
        if rng.random() < special_frac:
            p = special(rng)
            out.append((p, rng.randrange(src_range), 0))
        else:
            f = rng.choice(flows)
            pl = plen_dist(rng)
            if max_plen:
                pl = min(pl, max_plen)
            p = G.pad(f.build(rng, pl))
            flags = 0
            r = rng.random()
            if r < 0.01:
                flags = 1
            elif r < 0.015:
                flags = rng.choice([2, 4, 8])
            out.append((p, f.src, flags))
    return out, flows
