#!/usr/bin/env python3
"""Parser unit regression: generate vectors, build the Verilator TB, run, compare token-by-token against the model."""
import argparse, os, subprocess, sys, random
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import pktgen as G, pktmodel as M, sfdefs as D


def build(dw, hdr_cap, max_ext, ext_step, obj, rtl=None):
    rtl = rtl or os.path.join(ROOT, "rtl")
    exe = os.path.join(obj, "Vtb_pkt_parser")
    os.makedirs(obj, exist_ok=True)      # verilator --Mdir creates only the last path component
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O2", "--Mdir", obj,
           "--top-module", "tb_pkt_parser", "-I" + os.path.join(ROOT, "rtl"), "-I" + rtl,
           "-GDW=%d" % dw, "-GHDR_CAP=%d" % hdr_cap, "-GMAX_EXT=%d" % max_ext, "-GEXT_STEP=%d" % ext_step,
           os.path.join(rtl, "sf_pkt_toeplitz.sv"), os.path.join(rtl, "sf_pkt_parser.sv"),
           os.path.join(ROOT, "tb/tb_pkt_parser.sv"), "-o", "Vtb_pkt_parser"]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-3000:], r.stderr[-3000:]); sys.exit(2)
    return exe


def run_case(exe, name, base, items, cfg, gap, outdir, runcfg):
    out = os.path.join(outdir, name + ".tok")
    args = [exe, "+vec=" + base, "+npkts=%d" % len(items), "+out=" + out, "+gap=%d" % gap,
            "+csum=%d" % cfg["csum_en"], "+vxlan=%d" % cfg["vxlan_en"], "+tpid0=%x" % cfg["tpid0"],
            "+tpid1=%x" % cfg["tpid1"], "+vxport=%x" % cfg["vxlan_port"]]
    r = subprocess.run(args, capture_output=True, text=True, timeout=1800)
    if "TB_RESULT DONE" not in r.stdout:
        print(r.stdout[-1500:], r.stderr[-1500:]); return 0, len(items), ["simulation did not finish"]
    got = [int(x, 16) for x in open(out).read().split()]
    bad = []
    for i, (pkt, src, meta) in enumerate(items):
        exp = M.parse(pkt, src, dict(cfg, win=runcfg["win"], max_ext=runcfg["max_ext"]))
        e = M.token_int(exp)
        if i >= len(got) or got[i] != e:
            g = D.unpack(D.TOK_L, got[i]) if i < len(got) else {}
            diff = {k: (exp[k], g.get(k)) for k in exp if exp[k] != g.get(k)}
            bad.append("pkt %d len=%d: %s" % (i, len(pkt), diff))
            if len(bad) >= 8:
                break
    return len(items), len(bad), bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dw", type=int, default=128)
    ap.add_argument("--hdr-cap", type=int, default=128)
    ap.add_argument("--max-ext", type=int, default=4)
    ap.add_argument("--ext-step", type=int, default=2)
    ap.add_argument("--nrandom", type=int, default=3000)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--rtl", default=None)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--work", default=os.path.join(ROOT, "sim", "parser"))
    a = ap.parse_args()
    os.makedirs(a.work, exist_ok=True)
    win = ((a.hdr_cap + a.dw // 8 - 1) // (a.dw // 8)) * (a.dw // 8)
    runcfg = dict(win=win, max_ext=a.max_ext)
    exe = build(a.dw, a.hdr_cap, a.max_ext, a.ext_step, os.path.join(a.work, "obj_%d" % a.dw), a.rtl)
    sets = G.build_parser_vectors(os.path.join(a.work, "vec"), seed=a.seed, nrandom=a.nrandom)
    total = fails = 0
    base_cfg = dict(M.DEFAULT_CFG)
    variants = [("default", base_cfg, 0), ("default_gaps", base_cfg, 40),
                ("nocsum_novx", dict(base_cfg, csum_en=0, vxlan_en=0), 10),
                ("alt_tpid_vxport", dict(base_cfg, tpid0=0x9100, tpid1=0x8100, vxlan_port=8472), 25)]
    if a.quick:
        variants = variants[:1]
    for vname, cfg, gap in variants:
        for sname, (base, items) in sets.items():
            n, nbad, bad = run_case(exe, "%s_%s" % (vname, sname), base, items, cfg, gap, a.work, runcfg)
            total += n; fails += nbad
            print("%-38s %6d packets  %s" % ("%s/%s (gap=%d)" % (vname, sname, gap), n, "PASS" if nbad == 0 else "FAIL(%d)" % nbad))
            for b in bad:
                print("    ", b)
    print("PARSER REGRESSION dw=%d: %d packet checks, %d mismatches -> %s" % (a.dw, total, fails, "PASS" if fails == 0 else "FAIL"))
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
