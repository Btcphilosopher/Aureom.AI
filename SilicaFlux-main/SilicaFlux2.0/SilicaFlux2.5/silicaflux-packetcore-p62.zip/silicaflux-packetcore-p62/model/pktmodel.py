"""
SilicaFlux PacketCore -- INDEPENDENT software packet-decoding / policy model.

Written sequentially from docs/PARSER_POLICY.md (not from the RTL structure).  The RTL parser token is
compared bit-for-bit against `parse()`; the system testbench compares forwarding decisions, queue/TC
selection and rewritten bytes against `classify()` / `rewrite()`.

Window semantics (spec): the parser sees the first WIN bytes of the frame; bytes beyond the received
length read as 0 and every required field is bounds-checked against `avail = min(len, WIN)`.
"""
import struct
import sfdefs as D

MS_KEY = bytes.fromhex(
    "6d5a56da255b0ec24167253d43a38fb0d0ca2bcbae7b30b477cb2da38030f20c6a42b73bbeac01fa")

DEFAULT_CFG = dict(
    win=128, max_ext=4, tpid0=0x8100, tpid1=0x88A8, vxlan_port=4789, csum_en=1, vxlan_en=1,
    enable_vxlan=1, enable_rss=1, rss_key=MS_KEY,
)


# ------------------------------------------------------------------------------------------------
# primitives
# ------------------------------------------------------------------------------------------------
def csum16(data: bytes) -> int:
    """RFC 1071 internet checksum (complemented)."""
    if len(data) & 1:
        data += b"\x00"
    s = sum((data[i] << 8) | data[i + 1] for i in range(0, len(data), 2))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF


def ones_fold(data: bytes) -> int:
    """Folded ones'-complement sum (not complemented)."""
    if len(data) & 1:
        data += b"\x00"
    s = sum((data[i] << 8) | data[i + 1] for i in range(0, len(data), 2))
    while s >> 16:
        s = (s & 0xFFFF) + (s >> 16)
    return s


def toeplitz(data: bytes, key: bytes = MS_KEY) -> int:
    keybits = int.from_bytes(key, "big")
    klen = len(key) * 8
    r = 0
    for i in range(len(data) * 8):
        if (data[i // 8] >> (7 - (i % 8))) & 1:
            r ^= (keybits >> (klen - 32 - i)) & 0xFFFFFFFF
    return r


def is_ext_nh(nh):
    return nh in (0, 43, 60, 44, 51)


# ------------------------------------------------------------------------------------------------
# parser model
# ------------------------------------------------------------------------------------------------
def parse(pkt: bytes, src: int, cfg=None) -> dict:
    """Return the parser token as a dict keyed by D.TOK field names."""
    c = dict(DEFAULT_CFG)
    if cfg:
        c.update(cfg)
    WIN = c["win"]
    L = len(pkt)
    avail = min(L, WIN)
    eop = 1 if L <= WIN else 0
    w = pkt[:avail] + bytes(WIN - avail)

    def B(i):
        return w[i] if 0 <= i < WIN else 0

    def U16(i):
        return (B(i) << 8) | B(i + 1)

    t = {n: 0 for n, _ in D.TOK}
    t["eop_seen"], t["avail"], t["src_id"] = eop, avail, src & 0xFF

    # ---- L2 -------------------------------------------------------------------------------
    tp = (c["tpid0"], c["tpid1"])
    et0, et1, et2 = U16(12), U16(16), U16(20)
    t0 = et0 in tp
    t1 = t0 and et1 in tp
    t2 = t1 and et2 in tp
    vcnt = 2 if t1 else (1 if t0 else 0)
    etype = et2 if t1 else (et1 if t0 else et0)
    tci0, tci1 = U16(14), U16(18)
    t["dmac"] = int.from_bytes(bytes(B(i) for i in range(0, 6)), "big")
    t["smac"] = int.from_bytes(bytes(B(i) for i in range(6, 12)), "big")
    t["ethertype"] = etype
    t["vlan_cnt"] = vcnt
    if t0:
        t["vlan_vid"], t["vlan_pcp"], t["vlan_dei"] = tci0 & 0xFFF, tci0 >> 13, (tci0 >> 12) & 1
    if t1:
        t["vlan_vid2"] = tci1 & 0xFFF
    l3t = D.L3_IPV4 if etype == 0x0800 else D.L3_IPV6 if etype == 0x86DD else D.L3_NONE
    l3off = 14 + 4 * vcnt
    t["l3_type"], t["l3_off"] = l3t, l3off
    eth_trunc = avail < 14 or (t0 and avail < 18) or (t1 and avail < 22)
    vovf = t2

    # error / state flags
    e_ver = e_ihl = e_l3t = e_tot = False
    dgk = False
    ip_frag = ip_nf = 0
    csum_ok = 0
    # extension-walk state / L4 start
    off, nh, done, frag, nf, tr, uw = 0, 0, True, False, False, False, False
    dgend = 0

    v4 = l3t == D.L3_IPV4 and not eth_trunc
    v6 = l3t == D.L3_IPV6 and not eth_trunc

    def B3(rel):
        return B(l3off + rel)

    if v4:
        vihl, tos = B3(0), B3(1)
        ihl = vihl & 0xF
        hlen = ihl * 4
        tl = (B3(2) << 8) | B3(3)
        ff = (B3(6) << 8) | B3(7)
        ttl, proto = B3(8), B3(9)
        csum = (B3(10) << 8) | B3(11)
        t["ip_w0"] = (vihl << 8) | tos
        t["ip_tc"], t["ip_ttl"], t["ip_csum"] = tos, ttl, csum
        ip_frag = 1 if ((ff >> 13) & 1) or (ff & 0x1FFF) else 0
        ip_nf = 1 if (ff & 0x1FFF) else 0
        t["sip"] = int.from_bytes(bytes(B3(12 + i) for i in range(4)), "big")
        t["dip"] = int.from_bytes(bytes(B3(16 + i) for i in range(4)), "big")
        dgend = min(0xFFFF, l3off + tl)
        e_ver = (vihl >> 4) != 4
        e_ihl = ihl < 5
        e_l3t = avail < l3off + 20 or (not e_ihl and avail < l3off + hlen)
        e_tot = (not e_ihl) and tl < hlen
        dgk = True
        off, nh, done = l3off + hlen, proto, True
        hdr = bytes(B3(j) if j < ihl * 4 else 0 for j in range(60))
        # only words j < ihl*2 contribute
        words = hdr[:ihl * 4]
        csum_ok = 1 if ones_fold(words) == 0xFFFF else 0
    elif v6:
        b0, b1 = B3(0), B3(1)
        plen = (B3(4) << 8) | B3(5)
        nh0, hlim = B3(6), B3(7)
        t["ip_w0"] = (b0 << 8) | b1
        t["ip_tc"] = ((b0 & 0xF) << 4) | (b1 >> 4)
        t["ip_ttl"] = hlim
        t["sip"] = int.from_bytes(bytes(B3(8 + i) for i in range(16)), "big")
        t["dip"] = int.from_bytes(bytes(B3(24 + i) for i in range(16)), "big")
        dgend = min(0xFFFF, l3off + 40 + plen)
        e_ver = (b0 >> 4) != 6
        e_l3t = avail < l3off + 40
        dgk = plen != 0
        off, nh, done = l3off + 40, nh0, False
        for _ in range(c["max_ext"]):
            if done or tr or uw:
                continue
            if not is_ext_nh(nh):
                done = True
            elif off + 2 > avail:
                tr, uw = (True, False) if eop else (False, True)
            else:
                nh2 = B(off)
                if nh == 44:
                    hl = 8
                elif nh == 51:
                    hl = (B(off + 1) + 2) * 4
                else:
                    hl = (B(off + 1) + 1) * 8
                endo = off + hl
                if endo > avail:
                    tr, uw = (True, False) if eop else (False, True)
                else:
                    if nh == 44:
                        frag = True
                        if (U16(off + 2) >> 3) != 0:
                            nf = True
                    off, nh = endo, nh2
        ip_frag |= 1 if frag else 0
        ip_nf |= 1 if nf else 0
    t["ip_frag"], t["ip_nonfirst"] = ip_frag, ip_nf
    t["need_len"] = dgend if (v4 or v6) else 0
    t["csum_ok"] = csum_ok

    # ---- L4 ---------------------------------------------------------------------------------
    limit = (not done) and is_ext_nh(nh) and not tr and not uw
    e_l3t_all = e_l3t or tr
    l3err = (eth_trunc or e_ver or e_ihl or e_l3t_all or e_tot or
             (c["csum_en"] and l3t == D.L3_IPV4 and not csum_ok))
    cand = l3t != D.L3_NONE and not l3err and not uw and not limit and not ip_frag
    is_tcp = cand and nh == 6
    is_udp = cand and nh == 17
    is_oth = cand and not is_tcp and not is_udp and not (l3t == D.L3_IPV6 and nh == 59)
    need = 20 if is_tcp else 8 if is_udp else 0
    l4_missing = (is_tcp or is_udp) and off + need > avail
    e_l4t = l4_missing and bool(eop)
    uw2 = l4_missing and not eop
    e_doff = e_l4l = False
    sport = dport = flags = 0
    vni_valid = vni = 0
    vx_missing = False
    l4t = D.L4_TCP if is_tcp else D.L4_UDP if is_udp else D.L4_OTHER if is_oth else D.L4_NONE
    if (is_tcp or is_udp) and not l4_missing:
        sport, dport = U16(off), U16(off + 2)
        ulen = U16(off + 4)
        if is_tcp:
            doff = B(off + 12) >> 4
            flags = B(off + 13)
            e_doff = doff < 5
            if not e_doff:
                hl = doff * 4
                if dgk and dgend < off + hl:
                    e_l4l = True
                if eop and avail < off + hl:
                    e_l4t = True
        else:
            if ulen < 8:
                e_l4l = True
            elif dgk and dgend < ulen + off:
                e_l4l = True
            vx_cand = (c["enable_vxlan"] and c["vxlan_en"] and not e_l4l and dport == c["vxlan_port"] and ulen >= 16)
            if vx_cand:
                if off + 16 > avail:
                    vx_missing = True
                    if eop:
                        e_l4t = True
                    else:
                        uw2 = True
                else:
                    vni_valid = (B(off + 8) >> 3) & 1
                    vni = (B(off + 12) << 16) | (B(off + 13) << 8) | B(off + 14)
    uwin = uw or uw2

    t["ip_proto"] = nh if (v4 or v6) else 0
    if l4_missing or vx_missing:
        l4t = D.L4_NONE
    t["l4_type"] = l4t
    t["l4_off"] = off if l4t != D.L4_NONE else 0
    t["sport"], t["dport"], t["tcp_flags"] = sport, dport, flags
    t["vni_valid"], t["vni"] = vni_valid, vni

    # ---- final classification -------------------------------------------------------------------
    csum_bad = bool(c["csum_en"]) and l3t == D.L3_IPV4 and not csum_ok
    if eth_trunc:
        perr = D.PE_ETH_TRUNC
    elif e_ver:
        perr = D.PE_IP_VER
    elif e_ihl:
        perr = D.PE_IPV4_IHL
    elif e_l3t_all:
        perr = D.PE_L3_TRUNC
    elif e_tot:
        perr = D.PE_IPV4_TOTLEN
    elif csum_bad:
        perr = D.PE_IPV4_CSUM
    elif e_l4t:
        perr = D.PE_L4_TRUNC
    elif e_doff:
        perr = D.PE_TCP_DOFF
    elif e_l4l:
        perr = D.PE_L4_LEN
    else:
        perr = D.PE_NONE
    if perr != D.PE_NONE:
        unsupp = D.UN_NONE
    elif vovf:
        unsupp = D.UN_VLAN_OVF
    elif limit:
        unsupp = D.UN_EXT_LIMIT
    elif uwin:
        unsupp = D.UN_WINDOW
    else:
        unsupp = D.UN_NONE
    t["perr"], t["unsupp"] = perr, unsupp
    if perr != D.PE_NONE:
        for k in ("ip_w0", "ip_tc", "ip_ttl", "ip_proto", "ip_csum", "need_len", "ip_frag", "ip_nonfirst",
                  "sip", "dip", "csum_ok"):
            t[k] = 0
    if perr != D.PE_NONE or unsupp != D.UN_NONE:
        for k in ("l4_type", "l4_off", "sport", "dport", "tcp_flags", "vni_valid", "vni"):
            t[k] = 0

    # ---- RSS ------------------------------------------------------------------------------------
    h = 0
    if c["enable_rss"] and t["l3_type"] != D.L3_NONE and perr == D.PE_NONE:
        if t["l3_type"] == D.L3_IPV4:
            data = struct.pack(">II", t["sip"], t["dip"])
        else:
            data = t["sip"].to_bytes(16, "big") + t["dip"].to_bytes(16, "big")
        if t["l4_type"] in (D.L4_TCP, D.L4_UDP):
            data += struct.pack(">HH", t["sport"], t["dport"])
        h = toeplitz(data, c["rss_key"])
    t["flow_hash"] = h
    return t


def token_int(t: dict) -> int:
    return D.pack(D.TOK_L, t)
