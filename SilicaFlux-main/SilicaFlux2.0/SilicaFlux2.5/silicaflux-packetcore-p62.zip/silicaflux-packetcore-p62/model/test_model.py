#!/usr/bin/env python3
"""Self-test of the software reference model (run before trusting it as the oracle for the RTL).

 1. Toeplitz/RSS against the Intel 82599 datasheet "RSS Verification Suite" vectors (as published in
    DPDK app/test/test_thash.c) -- IPv4 (L3, L3+L4) and IPv6.
 2. Header-field decode against Scapy (an independent dissector) on well-formed packets.
 3. Internet-checksum helpers against Scapy.
"""
import ipaddress
import os
import random
import socket
import struct
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pktgen as G
import pktmodel as M
import sfdefs as D

V4 = [  # dst, src, dport, sport, hash_l3, hash_l3l4  (82599 datasheet 7.1.2.8.3)
    ("161.142.100.80", "66.9.149.187", 1766, 2794, 0x323e8fc2, 0x51ccc178),
    ("65.69.140.83", "199.92.111.2", 4739, 14230, 0xd718262a, 0xc626b0ea),
    ("12.22.207.184", "24.19.198.95", 38024, 12898, 0xd2d0a5de, 0x5c2b394a),
    ("209.142.163.6", "38.27.205.30", 2217, 48228, 0x82989176, 0xafc7327f),
    ("202.188.127.2", "153.39.163.191", 1303, 44251, 0x5d1809c5, 0x10e828a2),
]
V6 = [
    ("3ffe:2501:200:3::1", "3ffe:2501:200:1fff::7", 1766, 2794, 0x2cc18cd5, 0x40207d3d),
    ("ff02::1", "3ffe:501:8::260:97ff:fe40:efab", 4739, 14230, 0x0f0c461c, 0xdde51bbf),
    ("fe80::200:f8ff:fe21:67cf", "3ffe:1900:4545:3:200:f8ff:fe21:67cf", 38024, 44251, 0x4b61e985, 0x02d1feef),
]


def test_rss():
    for dst, src, dp, sp, h3, h4 in V4:
        a = socket.inet_aton(src) + socket.inet_aton(dst)
        assert M.toeplitz(a) == h3, (src, dst)
        assert M.toeplitz(a + struct.pack(">HH", sp, dp)) == h4, (src, dst)
    for dst, src, dp, sp, h3, h4 in V6:
        a = ipaddress.IPv6Address(src).packed + ipaddress.IPv6Address(dst).packed
        assert M.toeplitz(a) == h3, (src, dst)
        assert M.toeplitz(a + struct.pack(">HH", sp, dp)) == h4, (src, dst)
    # the packet-level model must reproduce the same hashes end-to-end
    for dst, src, dp, sp, h3, h4 in V4:
        p = G.pad(G.eth() + G.ipv4(src, dst, 6, G.tcp(sp, dp)))
        assert M.parse(p, 0)["flow_hash"] == h4
        p = G.pad(G.eth() + G.ipv4(src, dst, 1, bytes(8)))
        assert M.parse(p, 0)["flow_hash"] == h3
    for dst, src, dp, sp, h3, h4 in V6:
        p = G.pad(G.eth(etype=0x86DD) + G.ipv6(src, dst, 17, G.udp(sp, dp)))
        assert M.parse(p, 0)["flow_hash"] == h4
    print("RSS: %d IPv4 + %d IPv6 vectors PASS" % (len(V4), len(V6)))


def test_scapy():
    from scapy.all import Ether, Dot1Q, IP, IPv6, TCP, UDP, raw
    rng = random.Random(7)
    n = 0
    for _ in range(300):
        v6 = rng.random() < 0.4
        vl = rng.choice((0, 0, 1, 2))
        sport, dport = rng.randrange(1, 65535), rng.randrange(1, 65535)
        proto = rng.choice(("tcp", "udp"))
        l4 = TCP(sport=sport, dport=dport, flags=rng.randrange(0, 256)) if proto == "tcp" else UDP(sport=sport, dport=dport)
        if v6:
            l3 = IPv6(src="2001:db8::%x" % rng.randrange(1, 65535), dst="2001:db8:1::%x" % rng.randrange(1, 65535),
                      hlim=rng.randrange(1, 255), tc=rng.randrange(256), fl=rng.randrange(1 << 20))
        else:
            l3 = IP(src="10.%d.%d.%d" % (rng.randrange(256), rng.randrange(256), rng.randrange(1, 255)),
                    dst="192.168.%d.%d" % (rng.randrange(256), rng.randrange(1, 255)), ttl=rng.randrange(1, 255),
                    tos=rng.randrange(256), options=[] if rng.random() < 0.7 else [])
        e = Ether(src="02:00:00:00:00:01", dst="02:00:00:00:00:02")
        stack = e
        tpid = 0x8100
        vids = []
        for k in range(vl):
            stack = stack / Dot1Q(vlan=rng.randrange(1, 4095), prio=rng.randrange(8))
            vids.append(stack.getlayer(Dot1Q, k + 1))
        stack = stack / l3 / l4 / bytes(rng.randrange(256) for _ in range(rng.randrange(0, 40)))
        pkt = raw(stack)
        if len(pkt) < 60:
            pkt += bytes(60 - len(pkt))
        t = M.parse(pkt, 3)
        assert t["perr"] == 0 and t["unsupp"] == 0, (t["perr"], t["unsupp"])
        assert t["vlan_cnt"] == vl
        if vl:
            assert t["vlan_vid"] == vids[0].vlan and t["vlan_pcp"] == vids[0].prio
        if vl > 1:
            assert t["vlan_vid2"] == vids[1].vlan
        if v6:
            assert t["l3_type"] == D.L3_IPV6
            assert t["sip"] == int(ipaddress.IPv6Address(l3.src)) and t["dip"] == int(ipaddress.IPv6Address(l3.dst))
            assert t["ip_ttl"] == l3.hlim and t["ip_tc"] == l3.tc
        else:
            assert t["l3_type"] == D.L3_IPV4
            assert t["sip"] == int(ipaddress.IPv4Address(l3.src)) and t["dip"] == int(ipaddress.IPv4Address(l3.dst))
            assert t["ip_ttl"] == l3.ttl and t["ip_tc"] == l3.tos and t["csum_ok"] == 1
        assert t["l4_type"] == (D.L4_TCP if proto == "tcp" else D.L4_UDP)
        assert t["sport"] == sport and t["dport"] == dport
        if proto == "tcp":
            assert t["tcp_flags"] == int(l4.flags) & 0xFF
        n += 1
    print("Scapy cross-check: %d packets PASS" % n)


def test_csum():
    from scapy.all import IP, raw
    rng = random.Random(3)
    for _ in range(200):
        ip = IP(src="10.0.0.%d" % rng.randrange(1, 255), dst="10.0.1.%d" % rng.randrange(1, 255),
                ttl=rng.randrange(1, 255), tos=rng.randrange(256), id=rng.randrange(65536))
        b = bytearray(raw(ip / b"abcd"))
        chk = (b[10] << 8) | b[11]
        b[10:12] = b"\x00\x00"
        assert M.csum16(bytes(b[:20])) == chk
    print("IPv4 checksum helper vs Scapy: PASS")


if __name__ == "__main__":
    test_rss()
    test_scapy()
    test_csum()
    print("MODEL SELF-TEST PASS")
