"""System test harness: build / run the Verilator system TB, parse its log, and score it against the model."""
import collections
import hashlib
import os
import random
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import pktgen as G
import pktmodel as M
import sfdefs as D
import sysmodel as S

RTL_FILES = ["sim/vendor_build/sync_fifo.sv", "rtl/sf_pkt_fifo.sv", "sim/vendor_build/sfb_skid_buffer.sv", "sim/vendor_build/sf_rr_arb.sv",
             "rtl/sf_pkt_toeplitz.sv", "rtl/sf_pkt_parser.sv", "rtl/sf_pkt_classifier.sv", "rtl/sf_pkt_counters.sv",
             "rtl/sf_pkt_queue.sv", "rtl/sf_pkt_dispatch.sv", "rtl/sf_pkt_sched.sv", "rtl/sf_pkt_regs.sv",
             "rtl/silicaflux_packet_engine.sv", "tb/tb_packet_engine.sv"]

DEFAULT_PARAMS = dict(DW=128, SRC_W=4, META_W=32, NQ=4, NR=16, NT=8, MAXF=9216, QBYTES=16384, MBYTES=16384,
                      PKT_DEPTH=64, DELAYB=64, DECD=32, HDR_CAP=128, MAX_EXT=4, EXT_STEP=2,
                      ENABLE_REWRITE=1, ENABLE_TENANT=1, FIFO_RAM=1)


def src_hash():
    h = hashlib.sha1()
    for f in RTL_FILES + ["rtl/sf_pkt_defs.svh", "rtl/sf_pkt_macros.svh"]:
        h.update(open(os.path.join(ROOT, f), "rb").read())
    return h.hexdigest()[:10]


_built = {}


def build(params):
    p = dict(DEFAULT_PARAMS)
    p.update(params)
    key = "_".join("%s%s" % (k, p[k]) for k in sorted(p)) + "_" + src_hash()
    key = hashlib.sha1(key.encode()).hexdigest()[:12]
    obj = os.path.join(ROOT, "sim", "sys", "obj_" + key)
    exe = os.path.join(obj, "Vtb")
    if os.path.exists(exe):
        return exe, p
    os.makedirs(obj, exist_ok=True)      # verilator --Mdir creates only the last path component (clean checkout: sim/ is empty)
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O2", "--Mdir", obj,
           "--top-module", "tb_packet_engine", "-I" + os.path.join(ROOT, "rtl"), "-I" + os.path.join(ROOT, "sim/vendor_build")]
    for k, v in p.items():
        cmd.append("-G%s=%d" % (k, v))
    cmd += [os.path.join(ROOT, f) for f in RTL_FILES] + ["-o", "Vtb"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    if r.returncode != 0:
        print(r.stdout[-3000:], r.stderr[-3000:])
        raise SystemExit("verilator build failed")
    return exe, p


class Result:
    def __init__(self, path):
        self.out = []          # (port, sop, eop, q_or_reason, tc, src, meta, hash, len, bytes)
        self.inj = {}          # meta -> cycle of SOP accept
        self.rd = []           # (tenant, addr, data, err)
        self.wr = []
        self.rst = []
        self.partial = []
        self.proto = []
        self.timeouts = []
        self.stat = {}
        self.seq = []          # chronological register ops (kind, tenant, addr, data, err)
        for line in open(path):
            t = line.split()
            if not t:
                continue
            if t[0] == "OUT":
                self.out.append((t[1], int(t[2]), int(t[3]), int(t[4]), int(t[5]), int(t[6]), int(t[7]), int(t[8]), int(t[9]),
                                 bytes.fromhex(t[10]) if len(t) > 10 else b""))
            elif t[0] == "INJ":
                self.inj[int(t[1])] = int(t[2])
            elif t[0] in ("RD", "WR"):
                rec = (t[0], int(t[1]), int(t[2], 16), int(t[3], 16), int(t[4]))
                self.seq.append(rec)
                (self.rd if t[0] == "RD" else self.wr).append(rec[1:])
            elif t[0] == "RST":
                self.rst.append(int(t[1]))
            elif t[0] == "PARTIAL":
                self.partial.append(line.strip())
            elif t[0] == "PROTO":
                self.proto.append(line.strip())
            elif t[0] == "TIMEOUT":
                self.timeouts.append(line.strip())
            elif t[0] == "STAT":
                self.stat = dict(kv.split("=") for kv in t[1:])
                self.stat = {k: int(v) for k, v in self.stat.items()}

    def reg_reads(self, addr):
        return [r for r in self.rd if r[1] == addr]


def run(name, params, packets, script, work=None, seed=1, expect_timeouts=False):
    """packets: list of (bytes, src[, flags]); meta = index.  script: S.Script.  Returns (Result, p)."""
    exe, p = build(params)
    work = work or os.path.join(ROOT, "sim", "sys", "run_" + name)
    os.makedirs(work, exist_ok=True)
    base = os.path.join(work, "vec")
    items = [(pk[0], pk[1], i, pk[2] if len(pk) > 2 else 0) for i, pk in enumerate(packets)]
    G.write_vectors(base, items)
    sp = os.path.join(work, "script.txt")
    script.write(sp)
    out = os.path.join(work, "out.log")
    r = subprocess.run([exe, "+vec=" + base, "+script=" + sp, "+out=" + out, "+seed=%d" % seed], capture_output=True,
                       text=True, timeout=3600)
    if "TB_RESULT DONE" not in r.stdout:
        print(r.stdout[-2000:], r.stderr[-2000:])
        raise RuntimeError("simulation of %s did not finish" % name)
    res = Result(out)
    return res, p


# ------------------------------------------------------------------------------------------------
# scoreboard
# ------------------------------------------------------------------------------------------------
class Check:
    def __init__(self, name):
        self.name = name
        self.errors = []
        self.notes = []

    def err(self, msg):
        if len(self.errors) < 25:
            self.errors.append(msg)
        else:
            self.errors.append(None)

    def ok(self):
        return not self.errors

    def report(self):
        e = [x for x in self.errors if x]
        status = "PASS" if not self.errors else "FAIL(%d)" % len(self.errors)
        print("  %-52s %s  %s" % (self.name, status, "; ".join(self.notes)))
        for x in e[:12]:
            print("      !", x)
        return self.ok()


def expected_fates(packets, cfg, dwb):
    return [S.fate(pk[0], pk[1], pk[2] if len(pk) > 2 else 0, cfg, dwb) for pk in packets]


def check_outputs(name, packets, fates, res, cfg, dwb, lossless=True, min_meta=0, only=None, strict_order=True, allow_timeouts=False):
    """Every expected packet appears exactly once with the right bytes / queue / tc / sideband; per-queue order holds."""
    c = Check(name)
    c.notes.append("%d pkts" % len(packets))
    if res.proto:
        c.err("protocol checker: " + res.proto[0])
    if res.timeouts and not allow_timeouts:
        c.err("timeout: " + res.timeouts[0])
    outs = collections.defaultdict(list)
    for o in res.out:
        outs[o[6]].append(o)
    ids = range(min_meta, len(packets)) if only is None else only
    nfwd = nmgmt = ndrop = 0
    for i in ids:
        f = fates[i]
        got = outs.get(i, [])
        if f["fate"] == "drop":
            ndrop += 1
            if got:
                c.err("pkt %d should be dropped (reason %d) but appeared on port %s" % (i, f["reason"], got[0][0]))
            continue
        if len(got) != 1 and lossless:
            c.err("pkt %d expected exactly one output (%s), got %d" % (i, f["fate"], len(got)))
            continue
        if not got:
            continue
        o = got[0]
        port, _, _, qr, tc, src, meta, h, ln, data = o
        d = f["dec"]
        if f["fate"] == "fwd":
            nfwd += 1
            if port != "D":
                c.err("pkt %d fwd expected on D, got %s" % (i, port)); continue
            if qr != d["qid"]:
                c.err("pkt %d queue exp %d got %d" % (i, d["qid"], qr))
        else:
            nmgmt += 1
            if port != "M":
                c.err("pkt %d mgmt expected on M, got %s" % (i, port)); continue
            if qr != f["reason"]:
                c.err("pkt %d punt reason exp %d got %d" % (i, f["reason"], qr))
        if tc != d["tc"]:
            c.err("pkt %d tc exp %d got %d" % (i, d["tc"], tc))
        if src != (packets[i][1] & ((1 << 4) - 1)) and src != packets[i][1]:
            c.err("pkt %d src exp %d got %d" % (i, packets[i][1], src))
        if h != d["hash"]:
            c.err("pkt %d hash exp %08x got %08x" % (i, d["hash"], h))
        if f["fate"] == "fwd" and d["patches"] and f["tok"]["l3_type"] == D.L3_IPV4:
            l3, ihl = f["tok"]["l3_off"], (f["tok"]["ip_w0"] >> 8) & 0xF
            if M.ones_fold(data[l3:l3 + ihl * 4]) != 0xFFFF:
                c.err("pkt %d: rewritten IPv4 header checksum does not verify" % i)
            changed = {k for k in range(min(len(data), len(packets[i][0]))) if data[k] != packets[i][0][k]}
            if not changed <= set(d["patches"]):
                c.err("pkt %d: bytes outside the explicit rewrite changed: %s" % (i, sorted(changed - set(d["patches"]))))
        if ln != len(f["bytes"]) or data != f["bytes"]:
            first = next((k for k in range(min(len(data), len(f["bytes"]))) if data[k] != f["bytes"][k]), None)
            c.err("pkt %d bytes differ (len exp %d got %d, first diff at %s)" % (i, len(f["bytes"]), len(data), first))
    # unexpected ids on the wire
    for m in outs:
        if m >= len(packets):                       # (ids < min_meta are pre-reset frames; the reset test checks their timing)
            c.err("output for unknown packet id %d" % m)
    # per-queue ordering (data port): meta order == injection order, per queue
    if strict_order:
        last = collections.defaultdict(lambda: -1)
        for o in res.out:
            if o[0] != "D":
                continue
            q = o[3]
            if o[6] < last[q]:
                c.err("queue %d reordered: id %d after %d" % (q, o[6], last[q]))
                break
            last[q] = o[6]
        lastm = -1
        for o in res.out:
            if o[0] == "M":
                if o[6] < lastm:
                    c.err("management port reordered"); break
                lastm = o[6]
    c.notes.append("fwd=%d mgmt=%d drop=%d" % (nfwd, nmgmt, ndrop))
    return c


def check_reg_expectations(name, script, res):
    """Compare every register op against the expectations recorded in the script (err flag / read data)."""
    c = Check(name)
    if len(script.exp) != len(res.seq):
        c.err("expected %d register responses, log has %d" % (len(script.exp), len(res.seq)))
        return c
    n = 0
    for e, g in zip(script.exp, res.seq):
        kind, t, a, err, val, mask = e
        gk, gt, ga, gd, ge = g
        if (kind, t, a) != (gk, gt, ga):
            c.err("register op order mismatch: expected %s t%d %x, log %s t%d %x" % (kind, t, a, gk, gt, ga))
            break
        if err is not None:
            n += 1
            if ge != err:
                c.err("%s t%d addr 0x%x: err expected %d got %d" % (kind, t, a, err, ge))
        if val is not None:
            n += 1
            if (gd & mask) != (val & mask):
                c.err("%s t%d addr 0x%x: data expected 0x%x got 0x%x" % (kind, t, a, val & mask, gd & mask))
    c.notes.append("%d expectations" % n)
    return c


def counter_value(res, idx, base=D.GCNT_BASE):
    lo = [r for r in res.rd if r[1] == base + idx * 8]
    hi = [r for r in res.rd if r[1] == base + idx * 8 + 4]
    if not lo or not hi:
        return None
    return lo[-1][2] | (hi[-1][2] << 32)


def expected_counters(packets, fates, cfg, dwb, ids=None):
    """Expected global counters for a lossless run in which every packet was injected."""
    ids = range(len(packets)) if ids is None else ids
    e = collections.Counter()
    q = collections.defaultdict(collections.Counter)
    rule = collections.defaultdict(collections.Counter)
    for i in ids:
        pk, f = packets[i], fates[i]
        L = len(pk[0])
        fl = pk[2] if len(pk) > 2 else 0
        rxb, dropb = S.rtl_byte_counts(L, fl, dwb)
        tok, d = f["tok"], f["dec"]
        e["rx_pkts"] += 1
        e["rx_bytes"] += rxb
        e["lat_pipe_cnt"] += 1
        if tok["perr"]:
            e["parse_err"] += 1
        elif tok["unsupp"]:
            e["parse_unsupp"] += 1
        if (not tok["perr"]) and tok["ip_frag"]:
            e["parse_frag"] += 1
        if d["hit"] and d["count"]:
            rule[d["rule"]]["hits"] += 1
            rule[d["rule"]]["bytes"] += dropb          # dispatcher length (== L unless the keep contract was violated)
        if f["fate"] == "drop":
            e["drop_pkts"] += 1
            e["drop_bytes"] += dropb
            e["drop_" + {D.DR_MACERR: "macerr", D.DR_KEEP: "keep", D.DR_RUNT: "runt", D.DR_OVERSIZE: "oversize",
                         D.DR_MALFORMED: "malformed", D.DR_LENMIS: "lenmis", D.DR_UNSUPP: "unsupp", D.DR_FRAG: "frag",
                         D.DR_RULE: "rule", D.DR_QFULL: "qfull"}[f["reason"]]] += 1
        elif f["fate"] == "fwd":
            e["fwd_pkts"] += 1
            e["fwd_bytes"] += len(f["bytes"])
            e["egr_busy"] += (len(f["bytes"]) + dwb - 1) // dwb
            e["lat_e2e_cnt"] += 1
            q[d["qid"]]["enq_pkts"] += 1
            q[d["qid"]]["deq_pkts"] += 1
            q[d["qid"]]["deq_bytes"] += len(f["bytes"])
            if f["dec"]["patches"]:
                e["rewrite_pkts"] += 1
        else:
            e["mgmt_pkts"] += 1
            e["mgmt_bytes"] += len(f["bytes"])
            if f["reason"] == D.PR_TTL:
                e["ttl_punt"] += 1
    return e, q, rule


def read_all_counters_script(s, nq):
    names = [g[0] for g in D.GLOBAL_CNT]
    s.w(0, D.reg_addr("CTRL"), (1 << 0) | (1 << 1) | (1 << 8) | (1 << 10))
    for i in range(len(names)):
        s.r(0, D.GCNT_BASE + i * D.GCNT_STRIDE)
        s.r(0, D.GCNT_BASE + i * D.GCNT_STRIDE + 4)
    for q in range(nq):
        for k in range(len(D.QUEUE_CNT)):
            idx = D.G_STRIDE + q * D.Q_STRIDE + k
            s.r(0, D.GCNT_BASE + idx * D.GCNT_STRIDE)
            s.r(0, D.GCNT_BASE + idx * D.GCNT_STRIDE + 4)


def check_counters(name, res, packets, fates, cfg, dwb, nq, skip=(), check_rules=True, nr=16):
    c = Check(name)
    e, q, rule = expected_counters(packets, fates, cfg, dwb)
    names = [g[0] for g in D.GLOBAL_CNT]
    n = 0
    for k, v in e.items():
        if k in skip:
            continue
        got = counter_value(res, names.index(k))
        n += 1
        if got != v:
            c.err("counter %s expected %d got %s" % (k, v, got))
    for qi in range(nq):
        for k in ("enq_pkts", "deq_pkts", "deq_bytes"):
            got = counter_value(res, D.queue_counter_index(qi, k))
            n += 1
            if got != q[qi][k]:
                c.err("queue %d %s expected %d got %s" % (qi, k, q[qi][k], got))
    if check_rules:
        for r in range(nr):
            for kk, off in (("hits", 0), ("bytes", 8)):
                lo = [x for x in res.rd if x[1] == D.RULE_CNT_BASE + r * D.RULE_CNT_STRIDE + off]
                hi = [x for x in res.rd if x[1] == D.RULE_CNT_BASE + r * D.RULE_CNT_STRIDE + off + 4]
                if lo and hi:
                    got = lo[-1][2] | (hi[-1][2] << 32)
                    n += 1
                    if got != rule[r][kk]:
                        c.err("rule %d %s expected %d got %d" % (r, kk, rule[r][kk], got))
    c.notes.append("%d counters compared" % n)
    return c


def rule_counter_reads(s, nr, tenant=0):
    s.w(tenant, D.RULE_SNAP, 1)
    for r in range(nr):
        for off in (0, 4, 8, 12):
            s.r(tenant, D.RULE_CNT_BASE + r * D.RULE_CNT_STRIDE + off)
