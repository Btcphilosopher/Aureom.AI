#!/usr/bin/env python3
"""
PacketCore system regression.  Every test programs the DUT through its register bus, streams real packets
through the RTL (Verilator) and scores the observed egress against the independent software model.

  python3 model/run_system_tests.py [--dw 128] [--only name,name] [--quick]
"""
import argparse
import collections
import json
import os
import random
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import pktgen as G
import pktmodel as M
import sfdefs as D
import sysharness as H
import sysmodel as S
import traffic as T

RESULTS = []          # (name, ok)
METRICS = {}          # measured numbers for the reports


class Ctx:
    def __init__(self, dw, quick, nq=4, nr=16, nt=8, srcw=4, maxf=9216, qbytes=16384, pktdepth=64, fifo_ram=1):
        self.dw, self.dwb, self.quick = dw, dw // 8, quick
        self.nq, self.nr, self.nt, self.srcw, self.maxf, self.qbytes = nq, nr, nt, srcw, maxf, qbytes
        self.params = dict(DW=dw, NQ=nq, NR=nr, NT=nt, SRC_W=srcw, MAXF=maxf, QBYTES=qbytes, MBYTES=qbytes, PKT_DEPTH=pktdepth, FIFO_RAM=fifo_ram)


def done(checks):
    ok = True
    for c in checks:
        ok &= c.report()
    RESULTS.extend((c.name, c.ok()) for c in checks)
    return ok


def newcfg(ctx, **kw):
    return S.Cfg(nq=ctx.nq, nr=ctx.nr, nt=ctx.nt, max_frame=ctx.maxf, **kw)


def run_basic(ctx, name, cfg, packets, gap=0, egr=100, mgr=100, seed=1, counters=True, rules_cnt=True, params=None,
              pre=None, post=None, skip=(), allow_timeouts=False):
    s = S.Script()
    cfg.program(s)
    if pre:
        pre(s)
    s.mode(1, gap); s.mode(2, egr); s.mode(3, mgr); s.mode(6, seed)
    s.send(0, len(packets)); s.waitinj(); s.drain()
    if counters:
        H.read_all_counters_script(s, ctx.nq)
        H.rule_counter_reads(s, ctx.nr)
    if post:
        post(s)
    pr = dict(ctx.params)
    pr.update(params or {})
    res, p = H.run(name, pr, packets, s, seed=seed)
    fates = H.expected_fates(packets, cfg, ctx.dwb)
    cs = [H.check_outputs(name + ": egress vs model", packets, fates, res, cfg, ctx.dwb, allow_timeouts=allow_timeouts)]
    if counters:
        cs.append(H.check_counters(name + ": counters vs model", res, packets, fates, cfg, ctx.dwb, ctx.nq, skip=skip,
                                   check_rules=rules_cnt, nr=ctx.nr))
    return cs, res, fates


# ------------------------------------------------------------------------------------------------
# 1. registers / versioning
# ------------------------------------------------------------------------------------------------
def test_registers(ctx):
    print("[registers] reset values, access control, versioning")
    s = S.Script()
    A = D.reg_addr
    s.r(0, A("ID"), err=0, val=D.ID_VALUE)
    s.r(0, A("VERSION"), err=0, val=(D.VERSION[0] << 16) | (D.VERSION[1] << 8) | D.VERSION[2])
    s.r(0, A("CAPS0"), err=0, val=(ctx.dwb << 24) | (ctx.nt << 16) | (ctx.nr << 8) | ctx.nq)
    s.r(0, A("CAPS1"), err=0, val=(ctx.maxf << 16) | (4 << 5) | 0x1F)
    s.r(0, A("CAPS2"), err=0, val=(40 << 24) | ((((128 + ctx.dwb - 1) // ctx.dwb) * ctx.dwb) << 16) | (ctx.qbytes // 64))
    for name, addr, acc, rst, fields in D.REGS:
        if acc == "RW-A" and rst is not None and name not in ("CTRL", "SCRATCH"):
            s.r(0, addr, err=0, val=rst)
    s.r(0, A("POL_LEN"), err=0, val=60 | (ctx.maxf << 16))
    s.r(0, A("CTRL"), err=0, val=0x3)
    s.r(0, A("STATUS"), err=0, val=1, mask=1)
    for i in range(10):
        s.r(0, D.RSS_KEY_BASE + 4 * i, err=0, val=int.from_bytes(M.MS_KEY, "big") >> (32 * (9 - i)) & 0xFFFFFFFF)
    for q in range(ctx.nq):
        b = D.QCFG_BASE + q * D.QCFG_STRIDE
        for n, off, v in (("PRIO", 0, 0), ("WEIGHT", 4, 1), ("RL_INC", 8, 0), ("RL_BURST", 12, 0xFFFF), ("WM", 16, 0xFFFFFFFF), ("OCC", 20, 0)):
            s.r(0, b + off, err=0, val=v)
    # read / write
    for v in (0xDEADBEEF, 0x12345678, 0):
        s.w(0, A("SCRATCH"), v, err=0)
        s.r(0, A("SCRATCH"), err=0, val=v)
    s.w(0, A("POL_LEN"), (0x0100 << 16) | 0x0040, err=0)
    s.r(0, A("POL_LEN"), err=0, val=(0x0100 << 16) | 0x0040)           # values below MAX_FRAME_BYTES pass through
    s.w(0, A("POL_LEN"), (0xFFFF << 16) | 70, err=0)
    s.r(0, A("POL_LEN"), err=0, val=(ctx.maxf << 16) | 70)               # clamped to MAX_FRAME_BYTES
    s.w(0, A("POL_LEN"), 60 | (ctx.maxf << 16), err=0)
    s.w(0, A("TC_QMAP"), 0x76543210, err=0); s.r(0, A("TC_QMAP"), err=0, val=0x76543210)
    s.w(0, A("TC_QMAP"), 0, err=0)
    s.w(0, D.QCFG_BASE + D.QCFG["WEIGHT"], 0, err=0); s.r(0, D.QCFG_BASE + D.QCFG["WEIGHT"], err=0, val=1)    # weight 0 -> 1
    # errors
    s.r(0, 0x01D, err=1, val=0)                                         # unaligned
    s.r(0, 0x0F0, err=1, val=0)                                         # unmapped
    s.w(0, A("ID"), 1, err=1)                                           # RO
    s.w(0, A("VERSION"), 1, err=1)
    s.r(0, D.QCFG_BASE + ctx.nq * D.QCFG_STRIDE, err=1)                 # queue out of range
    s.w(0, D.QCFG_BASE + D.QCFG["OCC"], 5, err=1)
    s.r(0, D.OWNER_BASE + 4 * ctx.nr, err=1)                            # rule out of range
    s.r(0, D.GCNT_BASE + (D.G_STRIDE + 16 * D.Q_STRIDE) * 8, err=1)                   # beyond the last counter slot
    if ctx.nt < 16:
        s.w(0, D.OWNER_BASE, ctx.nt, err=1)                             # owner id >= NT (not encodable when NT = 16)
    # tenants: capability reads allowed, everything else rejected
    t3 = min(3, ctx.nt - 1)
    s.r(t3, A("ID"), err=0, val=D.ID_VALUE); s.r(t3, A("CAPS0"), err=0)
    s.r(t3, A("POL_ERR"), err=1, val=0); s.w(t3, A("SCRATCH"), 1, err=1); s.r(t3, A("SCRATCH"), err=1, val=0)
    s.w(t3, A("POL_ERR"), 0, err=1); s.w(t3, D.QCFG_BASE, 1, err=1); s.r(t3, D.GCNT_BASE, err=1, val=0)
    if ctx.nt < 16:
        s.r(ctx.nt, A("ID"), err=1); s.r(ctx.nt, A("POL_ERR"), err=1)     # unknown accessor id (>= NT): fail closed
    s.r(0, A("SCRATCH"), err=0, val=0)                                  # tenant write did not land
    # violation log + counter
    s.r(0, A("VIOL_LAST"), err=0)
    res, p = H.run("registers", ctx.params, [], s)
    c = H.check_reg_expectations("registers: reset values / access control", s, res)
    c2 = H.Check("registers: no protocol errors")
    if res.proto:
        c2.err(res.proto[0])
    done([c, c2])


# ------------------------------------------------------------------------------------------------
# 2. default mix and stalls
# ------------------------------------------------------------------------------------------------
def test_default_mix(ctx):
    print("[mix] default policy, all packet classes (valid, malformed, fragments, MAC errors, keep violations)")
    n = 400 if ctx.quick else 900
    for seed in ((1,) if ctx.quick else (1, 2, 3)):
        rng = random.Random(seed)
        pk, _ = T.mix(rng, n)
        cs, res, f = run_basic(ctx, "mix%d" % seed, newcfg(ctx), pk, seed=seed)
        done(cs)


def test_stalls(ctx):
    print("[stalls] random ingress gaps, random + patterned egress back-pressure, slow management port")
    rng = random.Random(11)
    n = 250 if ctx.quick else 500
    phases = [(0, 100, 100), (50, 100, 100), (0, 30, 100), (30, 50, 20), (0, 100, 5), (10, 70, 70)]
    pk, flows = T.mix(rng, n * len(phases))
    cfg = newcfg(ctx)
    cfg.pol["unsupp_act"] = D.ACT_PUNT
    s = S.Script()
    cfg.program(s)
    for i, (gap, egr, mgr) in enumerate(phases):
        s.mode(1, gap); s.mode(2, egr); s.mode(3, mgr); s.mode(6, 100 + i)
        s.send(i * n, n); s.waitinj(); s.drain()
    s.mode(1, 0); s.mode(2, 0); s.mode(4, (3 << 16) | 7)            # patterned stall: 3 on / 7 off
    s.send(0, 0)
    pk2, _ = T.mix(rng, n, flows=flows)
    pk += pk2
    s.send(len(pk) - n, n); s.waitinj(); s.drain()
    s.mode(4, 0); s.mode(2, 100)
    H.read_all_counters_script(s, ctx.nq)
    res, p = H.run("stalls", ctx.params, pk, s)
    fates = H.expected_fates(pk, cfg, ctx.dwb)
    done([H.check_outputs("stalls: egress vs model", pk, fates, res, cfg, ctx.dwb),
          H.check_counters("stalls: counters vs model", res, pk, fates, cfg, ctx.dwb, ctx.nq, check_rules=False)])


# ------------------------------------------------------------------------------------------------
# 3. random rule tables (first-match, TC/queue/hash/count/rewrite)
# ------------------------------------------------------------------------------------------------
def random_rule(rng, nq, tok, src, wide_ok=False):
    key = S.key_of(tok)
    cand = ["ethertype", "vid", "pcp", "vlan_valid", "l3_type", "ip_proto", "dscp", "sip", "dip", "sport",
            "dport", "tcp_flags", "vni", "vni_valid", "src_id", "dmac", "frag"]
    fields = rng.sample(cand, rng.randrange(1, 4))
    match = {}
    for f in fields:
        w = dict(D.RULE_MATCH)[f]
        v = key[f]
        r = rng.random()
        if r < 0.6:
            m = (1 << w) - 1
        elif r < 0.9:
            m = ((1 << w) - 1) & ~((1 << rng.randrange(0, max(1, w // 2))) - 1)    # prefix style (mostly specific)
        else:
            m = rng.randrange(1, 1 << min(w, 30))
        match[f] = (v, m)
    verdict = rng.choices(["FWD", "DROP", "MGMT"], [78, 8, 14])[0]
    qid = tcv = hb = dscp = None
    if verdict == "FWD":
        r = rng.random()
        if r < 0.55:
            qid = rng.randrange(nq)
        elif r < 0.7 and nq >= 2:
            hb = rng.choice([h for h in (1, 2) if (1 << h) <= nq])
            qid = rng.randrange(0, nq - (1 << hb) + 1)
    if rng.random() < 0.5:
        tcv = rng.randrange(8)
    if rng.random() < 0.3:
        dscp = rng.randrange(64)
    return S.make_rule(match, verdict, qid, hb, tcv, count=rng.random() < 0.6, dscp=dscp, dec_ttl=rng.random() < 0.3,
                       valid=rng.random() < 0.9)


def test_rules_random(ctx):
    print("[rules] random match/action tables vs model (first-match, ternary masks, TC/queue/hash select, count, rewrite)")
    tot = collections.Counter()
    for seed in ((21, 22) if ctx.quick else (21, 22, 23, 24, 25, 26, 27, 28)):
        rng = random.Random(seed)
        n = 600 if ctx.quick else 1400
        pk, flows = T.mix(rng, n, special_frac=0.08)
        cfg = newcfg(ctx)
        p = cfg.pol
        p["tc_src"] = rng.choice([0, 1, 2]); p["tc_qmap"] = [rng.randrange(ctx.nq) for _ in range(8)]
        p["def_verdict"] = rng.choices([D.VERD_FWD, D.VERD_DROP, D.VERD_MGMT], [88, 4, 8])[0]
        p["def_set_q"] = rng.randrange(2); p["def_qid"] = rng.randrange(ctx.nq); p["def_tc"] = rng.randrange(8)
        p["malformed_act"] = rng.choice([D.ACT_DROP, D.ACT_PUNT]); p["unsupp_act"] = rng.choice([0, 1, 2]); p["frag_act"] = rng.choice([0, 1, 2])
        p["csum_en"] = rng.choice([0, 1, 1]); p["vxlan_en"] = rng.choice([0, 1, 1]); p["min_len"] = rng.choice([0, 60])
        toks = [M.parse(x[0], x[1], cfg.parser_cfg()) for x in rng.sample(pk, 40)]
        for r in range(ctx.nr):
            cfg.rules[r] = random_rule(rng, ctx.nq, rng.choice(toks), 0)
        # a few dependable rewrite rules (specific, so they actually fire)
        cfg.rules[ctx.nr - 1] = S.make_rule({"ip_proto": (17, 0xFF)}, "FWD", 2 % ctx.nq, dscp=rng.randrange(64), dec_ttl=True, count=True)
        cfg.rules[ctx.nr - 2] = S.make_rule({"ip_proto": (6, 0xFF), "l3_type": (D.L3_IPV4, 3)}, "FWD", 1 % ctx.nq, tc=6, dec_ttl=True)
        cs, res, f = run_basic(ctx, "rules%d" % seed, cfg, pk, gap=rng.choice([0, 10]), egr=rng.choice([100, 60]),
                               mgr=100, seed=seed)         # mgmt overflow is tested separately (mgmt queue is always tail-drop)
        done(cs)
        for x in f:
            tot["pkts"] += 1
            tot["fate_" + x["fate"]] += 1
            d = x["dec"]
            tot["rule_hit"] += bool(d["hit"])
            tot["rewritten"] += bool(d["patches"]) and x["fate"] == "fwd"
            tot["ttl_punt"] += (d["reason"] == D.PR_TTL and x["fate"] == "mgmt")
    print("      coverage: " + ", ".join("%s=%d" % kv for kv in sorted(tot.items())))
    METRICS["rules_random_coverage"] = dict(tot)


# ------------------------------------------------------------------------------------------------
# 4. policy matrix (error / unsupported / fragment handling x checksum)
# ------------------------------------------------------------------------------------------------
def test_policy_matrix(ctx):
    print("[policy] malformed x unsupported x fragment x checksum policy matrix")
    rng = random.Random(31)
    base = [(p, i % 16, 0) for i, p in enumerate(G.directed_set(rng)) if len(p) < 1600]
    for k in range(40):
        base.append((T.special(rng), rng.randrange(16), 0))
    combos = [(m, u, f, c) for m in (0, 1) for u in (0, 1, 2) for f in (0, 1, 2) for c in (0, 1)]
    if ctx.quick:
        combos = combos[::5]
    pk = []
    cfgs = []
    for (m, u, f, c) in combos:
        cfg = newcfg(ctx)
        cfg.pol.update(malformed_act=m, unsupp_act=u, frag_act=f, csum_en=c)
        cfgs.append(cfg)
        pk += base
    s = S.Script()
    for i, cfg in enumerate(cfgs):
        cfg.program(s)
        s.send(i * len(base), len(base)); s.waitinj(); s.drain()
    res, p = H.run("policy", ctx.params, pk, s)
    cs = []
    allok = True
    nchk = 0
    bad = H.Check("policy matrix: %d policy combinations x %d packets" % (len(combos), len(base)))
    for i, cfg in enumerate(cfgs):
        sub = pk[i * len(base):(i + 1) * len(base)]
        fates = [S.fate(x[0], x[1], x[2], cfg, ctx.dwb) for x in sub]
        sres = H.Result.__new__(H.Result)
        sres.__dict__.update(res.__dict__)
        lo, hi = i * len(base), (i + 1) * len(base)
        sres.out = [o for o in res.out if lo <= o[6] < hi]
        sres.out = [(o[0], o[1], o[2], o[3], o[4], o[5], o[6] - lo, o[7], o[8], o[9]) for o in sres.out]
        c = H.check_outputs("p%d" % i, sub, fates, sres, cfg, ctx.dwb)
        nchk += len(sub)
        for e in c.errors:
            if e:
                bad.err("combo %s: %s" % (combos[i], e))
    bad.notes.append("%d packet checks" % nchk)
    done([bad])


# ------------------------------------------------------------------------------------------------
# 5. lengths: min / max / oversize / runt / partial final beats / MAC error / keep violations
# ------------------------------------------------------------------------------------------------
def frame_of_len(L, rng, proto="udp"):
    """Valid IPv4/UDP frame of exactly L bytes (L >= 42)."""
    pay = L - 42
    p = G.eth() + G.ipv4("10.0.0.1", "10.0.0.2", 17, G.udp(1000, 2000, bytes(rng.randrange(256) for _ in range(pay))))
    assert len(p) == L
    return p


def test_lengths(ctx):
    print("[lengths] min/max/jumbo/oversize/runt frames, every partial-final-beat size, MAC error, keep violations")
    rng = random.Random(41)
    dwb = ctx.dwb
    pk = []
    mf = ctx.maxf
    sizes = list(range(60, 60 + 3 * dwb + 3)) + [64, 65, 127, 128, 129, 255, 256, 511, 512, 1500, 1514, 1518, 1522, 2047, 2048, 4095, 4096, 8191, 9000, 9215, 9216]
    sizes = sorted(set([x for x in sizes if x < mf] + [mf - 1, mf]))
    for L in sizes:
        pk.append((frame_of_len(L, rng), rng.randrange(16), 0))
    for L in [mf + 1, mf + 2, mf + 80, mf + 2000, 20000, 65000]:
        if L <= 65000:
            pk.append((frame_of_len(L, rng), 1, 0))             # oversize -> drop
    for L in (42, 43, 50, 55, 58, 59):
        pk.append((frame_of_len(L, rng), 2, 0))                 # runt (< 60) -> drop
    pk.append((G.eth() + bytes(3), 3, 0))                       # shorter than an Ethernet header
    pk.append((G.eth(), 3, 0))
    for L in (60, 61, 128, 129, 1500, mf):                      # MAC error on legal sizes
        pk.append((frame_of_len(L, rng), 4, 1))
    for fl in (2, 4, 8):                                        # illegal keep patterns
        for L in (60, 100, 300, min(1500, mf)):
            pk.append((frame_of_len(L, rng), 5, fl))
    # declared IP length larger than the frame (truncated frames)
    base = G.eth() + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2, b"x" * 200))
    for cut in (60, 70, 100, 150, 200, 240, 241):
        pk.append((base[:cut], 6, 0))
    cs, res, f = run_basic(ctx, "lengths", newcfg(ctx), pk, counters=True, rules_cnt=False)
    done(cs)
    # second phase: lower max length, lower min length; boundary exactly at the limits
    cfg = newcfg(ctx)
    cfg.pol["max_len"] = min(1600, mf)
    cfg.pol["min_len"] = 100
    pk2 = [(frame_of_len(L, rng), 0, 0) for L in (99, 100, 101, 1599, 1600, 1601, 1602, mf)]
    cs, res, f = run_basic(ctx, "lengths_cfg", cfg, pk2, counters=True, rules_cnt=False)
    done(cs)


# ------------------------------------------------------------------------------------------------
# 6. throughput / latency
# ------------------------------------------------------------------------------------------------
def test_throughput(ctx):
    print("[throughput] back-to-back frames at line rate (1 beat/cycle), unloaded latency")
    rng = random.Random(51)
    sizes = sorted(set([60, 64, 128, 256, 512, 1024, 1518] + [x for x in (4096, 9000) if x <= ctx.maxf]))
    npk = 120 if ctx.quick else 300
    cfg = newcfg(ctx)
    pk, phases = [], []
    s = S.Script()
    cfg.program(s)
    for sz in sizes:
        first = len(pk)
        pk += [(frame_of_len(sz, rng), i % 16, 0) for i in range(npk)]
        phases.append((sz, first, npk))
        s.mode(1, 0); s.mode(2, 100)
        s.send(first, npk); s.waitinj(); s.drain()
    # unloaded latency: one frame at a time
    lat_first = len(pk)
    lat_sizes = [x for x in (60, 128, 512, 1518, 9000) if x <= ctx.maxf]
    for sz in lat_sizes:
        pk.append((frame_of_len(sz, rng), 0, 0))
        s.send(len(pk) - 1, 1); s.waitinj(); s.drain()
    H.read_all_counters_script(s, ctx.nq)
    res, p = H.run("throughput", ctx.params, pk, s)
    fates = H.expected_fates(pk, cfg, ctx.dwb)
    c1 = H.check_outputs("throughput: data integrity", pk, fates, res, cfg, ctx.dwb)
    c2 = H.Check("throughput: sustained rate")
    rows = []
    byid = {o[6]: o for o in res.out}
    for sz, first, n in phases:
        ids = [first + i for i in range(n) if first + i in byid]
        if len(ids) != n:
            c2.err("size %d: only %d of %d frames delivered" % (sz, len(ids), n)); continue
        a, b = ids[n // 10], ids[-1]
        beats = sum((sz + ctx.dwb - 1) // ctx.dwb for _ in range(a + 1, b + 1))
        cycles = byid[b][2] - byid[a][2]
        rate = beats / cycles
        fps = (b - a) / cycles                                           # frames per cycle
        lat = byid[first][1] - res.inj[first]
        rows.append(dict(size=sz, frames=n, beats_per_cycle=round(rate, 4), frames_per_cycle=round(fps, 4),
                         bytes_per_cycle=round(sz * fps, 2), first_frame_latency_cycles=lat))
        thr = 0.99
        if rate < thr:
            c2.err("size %d: %.4f beats/cycle < %.2f" % (sz, rate, thr))
    c2.notes.append("; ".join("%dB:%.3f" % (r["size"], r["beats_per_cycle"]) for r in rows))
    lat_rows = []
    for k, sz in enumerate(lat_sizes):
        i = lat_first + k
        o = byid.get(i)
        if o:
            lat_rows.append(dict(size=sz, sop_latency_cycles=o[1] - res.inj[i], eop_latency_cycles=o[2] - res.inj[i]))
    METRICS["throughput_dw%d" % ctx.dw] = dict(rows=rows, unloaded_latency=lat_rows)
    METRICS["throughput_counters"] = {}
    done([c1, c2])


# ------------------------------------------------------------------------------------------------
# 7. queue saturation
# ------------------------------------------------------------------------------------------------
def test_saturation(ctx):
    print("[saturation] lossless back-pressure, tail-drop mode, management-port overflow")
    rng = random.Random(61)
    # ---- lossless: everything steered to queue 1, data egress blocked
    qs = 1 % ctx.nq                                   # the queue everything is steered to
    cfg = newcfg(ctx)
    cfg.pol.update(def_set_q=1, def_qid=qs)
    n = 90
    pk = [(frame_of_len(rng.choice([600, 1000, 1400]), rng), i % 16, 0) for i in range(n)]
    s = S.Script()
    cfg.program(s)
    s.mode(2, 0)
    s.send(0, n); s.waitinj(30000)
    s.w(0, D.reg_addr("CTRL"), (1 << 0) | (1 << 1) | (1 << 8))
    s.r(0, D.GCNT_BASE + D.counter_index("ing_stall") * 8)
    s.r(0, D.GCNT_BASE + D.queue_counter_index(qs, "hwm_bytes") * 8)
    s.r(0, D.GCNT_BASE + D.queue_counter_index(qs, "occ_bytes") * 8)
    s.r(0, D.GCNT_BASE + D.counter_index("drop_pkts") * 8)
    s.mode(2, 100); s.waitinj(); s.drain()
    H.read_all_counters_script(s, ctx.nq)
    res, p = H.run("sat_lossless", ctx.params, pk, s)
    fates = H.expected_fates(pk, cfg, ctx.dwb)
    cs = [H.check_outputs("saturation/lossless: no loss, order kept", pk, fates, res, cfg, ctx.dwb, allow_timeouts=True),
          H.check_counters("saturation/lossless: counters", res, pk, fates, cfg, ctx.dwb, ctx.nq, check_rules=False, skip=("ing_stall", "egr_stall"))]
    c = H.Check("saturation/lossless: ingress back-pressured while the queue is full")
    if not res.timeouts:
        c.err("injection never stalled: queue did not saturate")
    stall, hwm, occ, drops = [r[2] for r in res.rd[:4]]
    if stall == 0:
        c.err("ing_stall counter is zero")
    if drops != 0:
        c.err("packets dropped in lossless mode (%d)" % drops)
    if hwm < ctx.qbytes - 2 * 1400:
        c.err("queue high-water mark only %d bytes" % hwm)
    c.notes.append("ing_stall=%d hwm=%d bytes occ_at_stall=%d" % (stall, hwm, occ))
    cs.append(c)
    done(cs)
    # ---- tail-drop: same blocked egress, ingress must never stall for long
    cfg = newcfg(ctx)
    cfg.pol.update(def_set_q=1, def_qid=qs, qdrop=1)
    n = 140
    pk = [(frame_of_len(rng.choice([300, 700, 1200, 1500]), rng), i % 16, 0) for i in range(n)]
    s = S.Script()
    cfg.program(s)
    s.mode(2, 0)
    s.send(0, n); s.waitinj(200000)
    s.mode(2, 100); s.drain()
    H.read_all_counters_script(s, ctx.nq)
    res, p = H.run("sat_drop", ctx.params, pk, s)
    c = H.Check("saturation/tail-drop: conservation, order, byte-exactness")
    if res.proto:
        c.err(res.proto[0])
    if res.timeouts:
        c.err("ingress stalled in tail-drop mode: " + res.timeouts[0])
    deliv = [o for o in res.out if o[0] == "D"]
    ids = [o[6] for o in deliv]
    if ids != sorted(ids) or len(set(ids)) != len(ids):
        c.err("delivered frames reordered or duplicated")
    for o in deliv:
        if o[9] != pk[o[6]][0]:
            c.err("frame %d corrupted" % o[6])
            break
    qf = H.counter_value(res, D.counter_index("drop_qfull"))
    qd = H.counter_value(res, D.queue_counter_index(qs, "drop_pkts"))
    if len(deliv) + (qf or 0) != n:
        c.err("delivered %d + drop_qfull %s != injected %d" % (len(deliv), qf, n))
    if qf != qd:
        c.err("drop_qfull %s != queue %d drop_pkts %s" % (qf, qs, qd))
    if not qf:
        c.err("expected tail drops, got none")
    enq = H.counter_value(res, D.queue_counter_index(qs, "enq_pkts"))
    if enq != len(deliv):
        c.err("enq_pkts %s != delivered %d" % (enq, len(deliv)))
    # the head of the stream (what fitted before the queue filled) must have been delivered
    if not ids or ids[0] != 0:
        c.err("first frame lost")
    c.notes.append("injected=%d delivered=%d tail-dropped=%s" % (n, len(deliv), qf))
    done([c])
    # ---- management port overflow: lossless data path must never be blocked by a stalled CPU port
    cfg = newcfg(ctx)
    cfg.pol.update(unsupp_act=D.ACT_PUNT, qdrop=0)
    n = 80
    pk = []
    for i in range(n):
        p = G.pad(G.eth(vlans=[(0x8100, 0, 0, 1), (0x8100, 0, 0, 2), (0x8100, 0, 0, 3)]) + G.ipv4("1.1.1.1", "2.2.2.2", 17, G.udp(1, 2, bytes(1100))))
        pk.append((p, i % 16, 0))
    for i in range(20):
        pk.append((G.pad(frame_of_len(300, rng)), 1, 0))
    s = S.Script()
    cfg.program(s)
    s.mode(3, 0)
    s.send(0, len(pk)); s.waitinj(200000)
    s.mode(3, 100); s.drain()
    H.read_all_counters_script(s, ctx.nq)
    res, p = H.run("sat_mgmt", ctx.params, pk, s)
    c = H.Check("saturation/management: overflow drops, data plane unaffected")
    if res.timeouts:
        c.err("data plane blocked by a stalled management port")
    mg = [o for o in res.out if o[0] == "M"]
    dd = [o for o in res.out if o[0] == "D"]
    md = H.counter_value(res, D.counter_index("mgmt_drop"))
    if len(dd) != 20:
        c.err("data frames delivered %d != 20" % len(dd))
    if len(mg) + (md or 0) != 80:
        c.err("mgmt delivered %d + dropped %s != 80" % (len(mg), md))
    if not md:
        c.err("management queue never overflowed")
    c.notes.append("mgmt delivered=%d dropped=%s data=%d" % (len(mg), md, len(dd)))
    done([c])


# ------------------------------------------------------------------------------------------------
# 8. tenant isolation
# ------------------------------------------------------------------------------------------------
def test_isolation(ctx):
    if ctx.nq < 4 or ctx.nt < 4 or ctx.nr < 13:
        print("[isolation] skipped (needs NQ>=4, NT>=4, NR>=13)"); return
    print("[isolation] one tenant cannot read or modify another tenant's rules / counters / policy")
    rng = random.Random(71)
    A = D.reg_addr
    cfg = newcfg(ctx)
    cfg.ten[1] = dict(vid=100, vni=None, qmask=0b0011, en=1)
    cfg.ten[2] = dict(vid=200, vni=None, qmask=0b1100, en=1)
    cfg.ten[3] = dict(vid=None, vni=0x1234, qmask=0b1111, en=1)
    for r in (0, 1, 2, 3):
        cfg.owner[r] = 1
    for r in (4, 5, 6, 7):
        cfg.owner[r] = 2
    for r in (8, 9):
        cfg.owner[r] = 3
    # administrator rule below the tenants (lowest priority): everything else -> queue 3, tc 7
    cfg.rules[12] = S.make_rule({}, "FWD", 3, tc=7)
    s = S.Script()
    # program administrator state first (without tenant rules)
    cfg0 = newcfg(ctx)
    cfg0.ten, cfg0.owner = cfg.ten, cfg.owner
    cfg0.rules[12] = cfg.rules[12]
    cfg0.program(s)
    viol = 0
    # ---- legitimate tenant programming ------------------------------------------------------------------
    def commit(t, idx, rule, expect_err, viol_expected):
        nonlocal viol
        for k, w in enumerate(S.rule_words(rule)):
            s.w(t, D.STAGE_BASE + 4 * k, w, err=0)
        s.w(t, D.RULE_CMD, (D.CMD_COMMIT << 28) | idx, err=expect_err)
        s.r(t, D.RULE_STATUS, err=0)
        viol += viol_expected
    r1 = S.make_rule({}, "FWD", 1, tc=5, count=True)                                 # tenant 1: wildcard (scope-limited to VLAN 100)
    r2 = S.make_rule({}, "DROP")                                                      # tenant 2: wildcard drop (scope VLAN 200)
    r3 = S.make_rule({}, "FWD", 2, tc=2, count=True, dscp=46)                         # tenant 3: VNI scope
    commit(1, 0, r1, 0, 0); commit(2, 4, r2, 0, 0); commit(3, 8, r3, 0, 0)
    cfg.rules[0], cfg.rules[4], cfg.rules[8] = r1, r2, r3
    # ---- attacks ---------------------------------------------------------------------------------------------------
    atk = S.make_rule({}, "DROP")
    s.w(2, D.OWNER_BASE + 0, 2, err=1); viol += 1                                      # steal slot 0
    s.w(1, D.OWNER_BASE + 16, 1, err=1); viol += 1
    commit(2, 0, atk, 1, 1)                                                           # commit into tenant 1's slot
    commit(1, 4, atk, 1, 1)                                                           # commit into tenant 2's slot
    commit(1, 8, atk, 1, 1)
    commit(1, 12, atk, 1, 1)                                                          # administrator-owned slot
    # staging race: tenant 1 stages, tenant 2 claims the window, tenant 1's commit must be refused
    for k, w in enumerate(S.rule_words(S.make_rule({}, "DROP"))):
        s.w(1, D.STAGE_BASE + 4 * k, w, err=0)
    s.w(2, D.STAGE_BASE, 0, err=0)                                                    # tenant 2 claims + clears the window
    s.w(1, D.RULE_CMD, (D.CMD_COMMIT << 28) | 1, err=1); viol += 1                    # ERR_STAGE
    s.r(1, D.RULE_STATUS, err=0, val=D.RS_ERR_STAGE, mask=0xF)
    s.r(1, D.STAGE_BASE, err=1, val=0); viol += 1                                      # window is tenant 2's now
    # policy violations (verdict MGMT, queue outside mask, FWD without queue)
    commit(1, 1, S.make_rule({}, "MGMT"), 1, 1)
    commit(1, 1, S.make_rule({}, "FWD", 2), 1, 1)
    commit(1, 1, S.make_rule({}, "FWD"), 1, 1)
    commit(1, 1, S.make_rule({}, "FWD", 1, hash_bits=2), 1, 1)                        # hash group 1..4 leaves mask 0b0011
    commit(3, 9, S.make_rule({}, "FWD", 3, hash_bits=2), 1, 1)                        # 3..6 >= NQ
    s.r(1, D.RULE_STATUS, err=0, val=D.RS_ERR_POLICY, mask=0xF)
    # range / command errors are not isolation violations
    s.w(1, D.RULE_CMD, (D.CMD_COMMIT << 28) | 200, err=1)
    s.w(1, D.RULE_CMD, (7 << 28) | 0, err=1)
    # reading / writing other tenants' or global state
    s.r(1, A("POL_ERR"), err=1, val=0); viol += 1
    s.w(1, A("POL_ERR"), 0, err=1); viol += 1
    s.w(2, A("SCHED_MODE"), 2, err=1); viol += 1
    s.w(2, D.QCFG_BASE + D.QCFG["RL_INC"], 1, err=1); viol += 1
    s.r(1, D.TEN_BASE + 2 * D.TEN_STRIDE + D.TEN["QMASK"], err=1, val=0); viol += 1
    s.w(1, D.TEN_BASE + 1 * D.TEN_STRIDE + D.TEN["QMASK"], 0xFFFF, err=1); viol += 1   # tenant widening its own mask
    s.r(1, D.TEN_BASE + 1 * D.TEN_STRIDE + D.TEN["QMASK"], err=0, val=0b0011)         # may read its own entry
    s.r(1, D.OWNER_BASE + 16, err=1, val=0); viol += 1                                # owner of slot 4 (tenant 2's)
    s.r(1, D.OWNER_BASE + 0, err=0, val=1)
    s.r(1, D.RULE_CNT_BASE + 4 * D.RULE_CNT_STRIDE, err=1, val=0); viol += 1          # tenant 2's counters
    s.r(2, D.GCNT_BASE, err=1, val=0); viol += 1
    if ctx.nt < 16:
        s.r(12, A("ID"), err=1); viol += 1                                            # unknown accessor id: everything rejected
        s.r(12, D.RULE_CNT_BASE, err=1); viol += 1
    s.w(1, D.RULE_CMD, (D.CMD_READ << 28) | 4, err=1); viol += 1                      # read tenant 2's rule into the window
    s.w(1, D.RULE_CMD, (D.CMD_CLEAR << 28) | 4, err=1); viol += 1
    s.w(1, D.RULE_CMD, (D.CMD_READ << 28) | 0, err=0)                                 # own rule: ok
    for k in range(3):
        s.r(1, D.STAGE_BASE + 4 * k, err=0, val=S.rule_words(r1)[k])                  # reads back exactly what was committed
    # ---- violation counter / log -------------------------------------------------------------------------------------
    s.w(0, A("CTRL"), 0x3 | (1 << 8))
    s.r(0, D.GCNT_BASE + D.counter_index("viol") * 8, err=0, val=viol)
    s.r(0, A("VIOL_LAST"), err=0)
    # ---- traffic ---------------------------------------------------------------------------------------------------------
    flows = [T.Flow(rng, vlans=((0x8100, 1, 0, 100),)), T.Flow(rng, vlans=((0x8100, 2, 0, 200),)),
             T.Flow(rng, vlans=((0x8100, 3, 0, 300),)), T.Flow(rng, vlans=()),
             T.Flow(rng, kind="vxlan4", vlans=(), vni=0x1234), T.Flow(rng, kind="vxlan4", vlans=((0x8100, 0, 0, 100),), vni=0x1234),
             T.Flow(rng, kind="vxlan4", vlans=(), vni=0x9999), T.Flow(rng, kind="udp6", vlans=((0x8100, 0, 0, 100),)),
             T.Flow(rng, kind="udp6", vlans=((0x8100, 0, 0, 200),))]
    pk, _ = T.mix(rng, 700, flows=flows, special_frac=0.05)
    s.send(0, len(pk)); s.waitinj(); s.drain()
    H.rule_counter_reads(s, ctx.nr, tenant=0)
    s.w(1, D.RULE_SNAP, 1, err=0)
    s.r(1, D.RULE_CNT_BASE + 0 * D.RULE_CNT_STRIDE, err=0)
    s.r(1, D.RULE_CNT_BASE + 4 * D.RULE_CNT_STRIDE, err=1)
    s.r(2, D.RULE_CNT_BASE + 4 * D.RULE_CNT_STRIDE, err=0)
    # the administrator removes tenant 1's enable; its rule must stop matching at once (no rule edit needed)
    s.w(0, D.TEN_BASE + D.TEN_STRIDE + D.TEN["ENABLE"], 0, err=0)
    pk2, _ = T.mix(rng, 300, flows=flows, special_frac=0.05)
    pk += pk2
    s.send(len(pk) - 300, 300); s.waitinj(); s.drain()
    res, p = H.run("isolation", ctx.params, pk, s)
    fates1 = H.expected_fates(pk[:700], cfg, ctx.dwb)
    cfg2 = newcfg(ctx)
    cfg2.ten, cfg2.owner, cfg2.rules = {t: dict(e) for t, e in cfg.ten.items()}, list(cfg.owner), list(cfg.rules)
    cfg2.ten[1]["en"] = 0
    fates2 = H.expected_fates(pk[700:], cfg2, ctx.dwb)
    # combined scoring: second batch ids are offset
    fates = fates1 + fates2
    class _C:  # per-batch config lookup for the scoreboard
        pass
    c0 = H.check_reg_expectations("isolation: every attack rejected, legitimate access allowed", s, res)
    c1 = H.check_outputs("isolation: forwarding follows the rules actually committed", pk, fates, res, cfg, ctx.dwb)
    c2 = H.Check("isolation: tenant rules only ever touched their own tenant's traffic")
    n_t1 = n_other = 0
    for i, f in enumerate(fates):
        d = f["dec"]
        if d["hit"] and d["rule"] in (0, 4, 8):
            tok = f["tok"]
            ok = {0: tok["vlan_cnt"] and tok["vlan_vid"] == 100, 4: tok["vlan_cnt"] and tok["vlan_vid"] == 200,
                  8: tok["vni_valid"] and tok["vni"] == 0x1234}[d["rule"]]
            if not ok:
                c2.err("model self-check failed: pkt %d hit tenant rule %d outside scope" % (i, d["rule"]))
            n_t1 += 1
        else:
            n_other += 1
    # out-of-scope traffic must have reached the administrator default (queue 3 tc 7) unchanged
    for o in res.out:
        if o[0] == "D":
            f = fates[o[6]]
            tok = f["tok"]
            if not (tok["vlan_cnt"] and tok["vlan_vid"] in (100, 200)) and not (tok["vni_valid"] and tok["vni"] == 0x1234):
                if f["fate"] == "fwd" and not f["dec"]["hit"] or (f["dec"]["hit"] and f["dec"]["rule"] == 12):
                    if o[3] != 3 or o[4] != 7:
                        c2.err("out-of-scope packet %d was steered by a tenant (q%d tc%d)" % (o[6], o[3], o[4]))
                        break
    c2.notes.append("%d tenant-rule hits, %d other" % (n_t1, n_other))
    # rule counter visibility per tenant (read results of the final reads)
    done([c0, c1, c2])


# ------------------------------------------------------------------------------------------------
# 9. scheduler
# ------------------------------------------------------------------------------------------------
def sched_setup(ctx, per_q, size, mode, prio=None, weight=None, rl=None, starve=0, quant=1000, extra_after=None):
    nq = ctx.nq
    cfg = newcfg(ctx)
    cfg.pol.update(sched_mode=mode, starve=starve, quant=quant)
    for q in range(nq):
        cfg.rules[q] = S.make_rule({"src_id": (q, 0xF)}, "FWD", q)
        if prio:
            cfg.q[q]["prio"] = prio[q]
        if weight:
            cfg.q[q]["weight"] = weight[q]
    if rl:
        for q, (inc, burst) in rl.items():
            cfg.q[q]["rl_inc"], cfg.q[q]["rl_burst"] = inc, burst
    rng = random.Random(81)
    pk = []
    for i in range(per_q):                                   # interleaved arrival so every queue backlogs equally
        for q in range(nq):
            pk.append((frame_of_len(size, rng), q, 0))
    return cfg, pk


def run_sched(ctx, name, cfg, pk, release_after=40000):
    """Fill every queue while NO queue is eligible (rate-limit gate: 1 B/period, burst 0 => tokens never positive),
    then release all queues in the same instant so the discipline under test sees a full backlog."""
    s = S.Script()
    cfg.program(s)
    for q in range(ctx.nq):
        b = D.QCFG_BASE + q * D.QCFG_STRIDE
        s.w(0, b + D.QCFG["RL_BURST"], 0)
        s.w(0, b + D.QCFG["RL_INC"], 1)
    s.mode(2, 0)
    s.send(0, len(pk)); s.waitinj(release_after)            # the queues absorb the whole backlog
    s.wait(300)
    for q in range(ctx.nq):
        b = D.QCFG_BASE + q * D.QCFG_STRIDE
        s.w(0, b + D.QCFG["RL_BURST"], cfg.q[q]["rl_burst"])
        s.w(0, b + D.QCFG["RL_INC"], cfg.q[q]["rl_inc"])
    s.mode(2, 100); s.waitinj(); s.drain()
    res, p = H.run(name, ctx.params, pk, s)
    fates = H.expected_fates(pk, cfg, ctx.dwb)
    return res, fates


def test_scheduler(ctx):
    if ctx.nq != 4 or ctx.qbytes < 16384:
        print("[scheduler] skipped (scenarios are written for NQ=4 and 16 KB queues)"); return
    print("[scheduler] round-robin fairness, strict priority + starvation guard, DWRR weights, rate limiting")
    nq = ctx.nq
    per_q = 24
    # ---- RR
    cfg, pk = sched_setup(ctx, per_q, 500, D.SCHED_RR)
    res, fates = run_sched(ctx, "sched_rr", cfg, pk)
    c = H.check_outputs("scheduler/RR: data integrity", pk, fates, res, cfg, ctx.dwb)
    seq = [o[3] for o in res.out if o[0] == "D"]
    bad = 0
    for i in range(2, len(seq) - 3 * nq, nq):               # skip the staggered-release slots and the draining tail
        if sorted(seq[i:i + nq]) != list(range(nq)):
            bad += 1
    c2 = H.Check("scheduler/RR: every window of %d frames serves each backlogged queue once" % nq)
    if bad:
        c2.err("%d unfair windows, e.g. %s" % (bad, seq[:16]))
    done([c, c2])
    # ---- SP
    cfg, pk = sched_setup(ctx, per_q, 500, D.SCHED_SP, prio=[0, 1, 2, 3])
    res, fates = run_sched(ctx, "sched_sp", cfg, pk)
    seq = [o[3] for o in res.out if o[0] == "D"]
    c = H.Check("scheduler/SP: strict priority order while higher classes are backlogged")
    if seq != sorted(seq):
        c.err("order not strictly priority-sorted: %s" % seq[:40])
    cc = H.check_outputs("scheduler/SP: data integrity", pk, fates, res, cfg, ctx.dwb)
    done([c, cc])
    # ---- SP + starvation guard: queue 3 (lowest class) is fed only AFTER egress is released, while queue 0 stays backlogged
    S_LIM = max(40, min(200, (16384 // ctx.dwb) // 4))        # guard scaled to the backlog the 16 KB queue can hold
    pkt_cycles = (500 + ctx.dwb - 1) // ctx.dwb + 1
    for guard in (0, S_LIM):
        cfg, _ = sched_setup(ctx, 1, 500, D.SCHED_SP, prio=[0, 1, 2, 3], starve=guard)
        rng2 = random.Random(82)
        pk = [(frame_of_len(500, rng2), 0, 0) for _ in range(30)] + [(frame_of_len(500, rng2), 3, 0) for _ in range(4)]
        s = S.Script()
        cfg.program(s)
        s.mode(2, 0)
        s.send(0, 30); s.waitinj(); s.wait(100)
        s.mode(2, 100); s.wait(60)
        s.send(30, 4); s.waitinj(); s.drain()
        res, p = H.run("sched_sp_age%d" % guard, ctx.params, pk, s)
        fates = H.expected_fates(pk, cfg, ctx.dwb)
        outs = [o for o in res.out if o[0] == "D"]
        q3 = [o for o in outs if o[3] == 3]
        q0 = [o for o in outs if o[3] == 0]
        c = H.Check("scheduler/SP guard=%d: low class wait while a higher class stays backlogged" % guard)
        wait = q3[0][1] - res.inj[30]
        q0_end = q0[-1][2]
        c.notes.append("queue3 first frame served %d cycles after arrival (queue0 backlog ends at +%d)" % (wait, q0_end - res.inj[30]))
        if guard == 0:
            if q3[0][1] < q0_end:
                c.err("strict priority violated: queue 3 served before queue 0 drained")
        else:
            bound = guard + 3 * pkt_cycles + 60            # own frame transfer + guard + frame in flight + reservation + pipeline
            if wait > bound:
                c.err("queue 3 waited %d cycles > bound %d" % (wait, bound))
            if q3[0][1] > q0_end - 3 * pkt_cycles:
                c.err("starvation guard had no effect")
            METRICS["sched_sp_aging"] = dict(guard_cycles=guard, q3_wait_cycles=wait, bound_cycles=bound,
                                             q0_backlog_cycles=q0_end - res.inj[30])
        cc = H.check_outputs("scheduler/SP guard=%d: data integrity" % guard, pk, fates, res, cfg, ctx.dwb)
        done([c, cc])
    # ---- DWRR
    wts = [1, 2, 3, 4]
    cfg, pk = sched_setup(ctx, 30, 500, D.SCHED_DWRR, weight=wts, quant=500)
    res, fates = run_sched(ctx, "sched_dwrr", cfg, pk)
    outs = [o for o in res.out if o[0] == "D"]
    seq = [o[3] for o in outs]
    c = H.Check("scheduler/DWRR: byte shares proportional to weights while backlogged")
    window = seq[6:6 + sum(wts) * 3]                       # skip the start-up slots (staggered release)
    cnt = collections.Counter(window)
    for q in range(nq):
        exp = wts[q] * 3
        if abs(cnt[q] - exp) > 1:
            c.err("queue %d got %d of the first %d frames, expected ~%d" % (q, cnt[q], len(window), exp))
    c.notes.append("first %d frames: %s" % (len(window), dict(sorted(cnt.items()))))
    cc = H.check_outputs("scheduler/DWRR: data integrity", pk, fates, res, cfg, ctx.dwb)
    done([c, cc])
    # ---- rate limit: queue 0 limited below its fair share (RR share is ~3.9 B/cycle for 500 B frames), others unlimited
    for inc, period, rate_exp in ((2, 1, 2.0), (8, 4, 2.0), (1, 1, 1.0)):
        cfg, pk = sched_setup(ctx, 24, 500, D.SCHED_RR, rl={0: (inc, 600)})
        cfg.pol["rl_period"] = period
        res, fates = run_sched(ctx, "sched_rl_%d_%d" % (inc, period), cfg, pk)
        outs = [o for o in res.out if o[0] == "D"]
        q0 = [o for o in outs if o[3] == 0]
        c = H.Check("scheduler/rate-limit %d B per %d clk: limited queue holds %.1f B/cycle" % (inc, period, rate_exp))
        if len(q0) < 20:
            c.err("only %d frames from the limited queue" % len(q0))
        else:
            mid = q0[3:len(q0) - 3]
            rate = (len(mid) - 1) * 500 / (mid[-1][1] - mid[0][1])
            c.notes.append("steady state %.3f B/cycle (configured %.2f)" % (rate, rate_exp))
            # allowance: the 600-byte bucket credit shifts the window by at most burst/window_bytes
            tol = 0.02 + 600.0 / ((len(mid) - 1) * 500)
            if abs(rate - rate_exp) > tol * rate_exp:
                c.err("limited queue rate %.3f B/cycle outside %.2f +-%.1f%%" % (rate, rate_exp, tol * 100))
            end_unl = max(o[2] for o in outs if o[3] != 0)
            beats = sum((o[8] + ctx.dwb - 1) // ctx.dwb for o in outs if o[2] <= end_unl)
            util = beats / (end_unl - outs[0][1] + 1)
            c.notes.append("link %.3f busy while unlimited queues have traffic" % util)
            if util < 0.97:
                c.err("link under-used while unlimited queues are backlogged (%.3f)" % util)
            METRICS.setdefault("sched_rate_limit", []).append(dict(inc_bytes=inc, period_clocks=period, configured_bytes_per_cycle=rate_exp,
                                                                   measured_bytes_per_cycle=round(rate, 4)))
        cc = H.check_outputs("scheduler/rate-limit %d/%d: data integrity" % (inc, period), pk, fates, res, cfg, ctx.dwb)
        done([c, cc])


# ------------------------------------------------------------------------------------------------
# 10. reset mid-packet, atomic rule update, quiesce
# ------------------------------------------------------------------------------------------------
def test_reset(ctx):
    print("[reset] reset in the middle of ingress / queued / egress frames, recovery with clean state")
    rng = random.Random(91)
    for variant, egr in (("ingress", 100), ("egress-stalled", 25)):
        cfg = newcfg(ctx)
        pre = [(frame_of_len(rng.choice([3000, 4000, 6000]), rng), i % 16, 0) for i in range(8)]
        post, _ = T.mix(rng, 60)
        pk = pre + post
        s = S.Script()
        cfg.program(s)
        s.mode(2, egr)
        s.send(0, len(pre))
        s.wait(260 if variant == "ingress" else 700)
        s.reset(4)
        cfg.program(s)                                      # registers are reset too: reprogram
        s.mode(2, 100)
        s.send(len(pre), len(post)); s.waitinj(); s.drain()
        H.read_all_counters_script(s, ctx.nq)
        res, p = H.run("reset_" + variant, ctx.params, pk, s)
        fates = H.expected_fates(pk, cfg, ctx.dwb)
        c1 = H.check_outputs("reset/%s: post-reset frames exact" % variant, pk, fates, res, cfg, ctx.dwb, min_meta=len(pre))
        c2 = H.Check("reset/%s: no stale / partial frame escapes after reset" % variant)
        rst = res.rst[0]
        for o in res.out:
            if o[6] < len(pre) and o[1] > rst:
                c2.err("pre-reset frame %d emitted after reset (sop cycle %d > reset %d)" % (o[6], o[1], rst))
        if not [r for r in res.out if r[6] >= len(pre)]:
            c2.err("nothing forwarded after reset")
        c2.notes.append("in-flight at reset: %d partial egress frame(s) cut" % len(res.partial))
        e_pkts = len(post)
        rx = H.counter_value(res, D.counter_index("rx_pkts"))
        if rx != e_pkts:
            c2.err("rx_pkts %s != %d post-reset frames (counters reset)" % (rx, e_pkts))
        done([c1, c2])


def test_atomic_update(ctx):
    print("[atomic] rule updates under traffic: each frame sees the old or the new rule, never a mix")
    rng = random.Random(101)
    cfg = newcfg(ctx)
    qa, qb = 1 % ctx.nq, 2 % ctx.nq
    A = S.make_rule({"dport": (80, 0xFFFF)}, "FWD", qa, tc=3)
    B = S.make_rule({"dport": (80, 0xFFFF)}, "FWD", qb, tc=5)
    cfg.rules[0] = A
    fl = T.Flow(rng, kind="udp4", vlans=())
    fl.dport = 80
    n = 700 if ctx.quick else 1600
    pk = [(G.pad(fl.build(rng, rng.randrange(0, 100))), 0, 0) for _ in range(n)]
    s = S.Script()
    cfg.program(s)
    s.send(0, n)
    toggles = 0
    for k in range(40 if ctx.quick else 90):
        r = B if k % 2 == 0 else A
        for kk, w in enumerate(S.rule_words(r)):
            s.w(0, D.STAGE_BASE + 4 * kk, w)
        s.w(0, D.RULE_CMD, (D.CMD_COMMIT << 28) | 0)
        s.wait(3 + (k % 5))
        toggles += 1
    s.waitinj(); s.drain()
    res, p = H.run("atomic", ctx.params, pk, s)
    c = H.Check("atomic rule update: %d commits under traffic" % toggles)
    pairs = collections.Counter((o[3], o[4]) for o in res.out if o[0] == "D")
    for k in pairs:
        if k not in ((qa, 3), (qb, 5)):
            c.err("mixed old-match/new-action outcome observed: queue %d tc %d (%d frames)" % (k[0], k[1], pairs[k]))
    if len(res.out) != n:
        c.err("%d of %d frames delivered" % (len(res.out), n))
    if len(pairs) < 2:
        c.err("only one rule version ever observed: %s" % dict(pairs))
    c.notes.append("outcomes %s" % dict(pairs))
    for o in res.out:
        if o[9] != pk[o[6]][0]:
            c.err("frame %d corrupted" % o[6]); break
    done([c])


def test_quiesce(ctx):
    print("[quiesce] CTRL.enable=0 stops admitting packets; STATUS.idle; resume without loss")
    rng = random.Random(111)
    cfg = newcfg(ctx)
    pk, _ = T.mix(rng, 300, special_frac=0.0)
    s = S.Script()
    cfg.program(s)
    s.send(0, len(pk))
    s.wait(300)
    s.w(0, D.reg_addr("CTRL"), 0x2)                       # enable = 0
    s.wait(1500)
    s.r(0, D.reg_addr("STATUS"), err=0, val=1, mask=1)    # engine drained to idle although packets are still queued upstream
    s.wait(300)
    s.w(0, D.reg_addr("CTRL"), 0x3)
    s.waitinj(); s.drain()
    res, p = H.run("quiesce", ctx.params, pk, s)
    fates = H.expected_fates(pk, cfg, ctx.dwb)
    c0 = H.check_outputs("quiesce: no loss, order kept", pk, fates, res, cfg, ctx.dwb)
    c1 = H.check_reg_expectations("quiesce: engine reports idle", s, res)
    c2 = H.Check("quiesce: no new packet admitted while disabled")
    ts = sorted(res.inj.values())
    gaps = [b - a for a, b in zip(ts, ts[1:])]
    if not gaps or max(gaps) < 1500:
        c2.err("no admission gap seen (largest %d cycles)" % (max(gaps) if gaps else 0))
    c2.notes.append("largest admission gap %d cycles" % max(gaps))
    done([c0, c1, c2])


# ------------------------------------------------------------------------------------------------
TESTS = collections.OrderedDict([
    ("registers", test_registers), ("mix", test_default_mix), ("stalls", test_stalls), ("rules", test_rules_random),
    ("policy", test_policy_matrix), ("lengths", test_lengths), ("throughput", test_throughput),
    ("saturation", test_saturation), ("isolation", test_isolation), ("scheduler", test_scheduler),
    ("reset", test_reset), ("atomic", test_atomic_update), ("quiesce", test_quiesce)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dw", type=int, default=128)
    ap.add_argument("--only", default="")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--metrics", default=None)
    ap.add_argument("--nq", type=int, default=4)
    ap.add_argument("--nr", type=int, default=16)
    ap.add_argument("--nt", type=int, default=8)
    ap.add_argument("--srcw", type=int, default=4)
    ap.add_argument("--maxf", type=int, default=9216)
    ap.add_argument("--qbytes", type=int, default=16384)
    ap.add_argument("--pktdepth", type=int, default=64)
    ap.add_argument("--fifo-ram", type=int, default=1)
    a = ap.parse_args()
    ctx = Ctx(a.dw, a.quick, a.nq, a.nr, a.nt, a.srcw, a.maxf, a.qbytes, a.pktdepth, a.fifo_ram)
    only = [x for x in a.only.split(",") if x]
    t0 = time.time()
    for name, fn in TESTS.items():
        if only and name not in only:
            continue
        fn(ctx)
    nfail = sum(1 for _, ok in RESULTS if not ok)
    print("\nSYSTEM REGRESSION dw=%d nq=%d nr=%d nt=%d srcw=%d maxf=%d qbytes=%d: %d checks, %d failed, %.0fs -> %s" % (a.dw, a.nq, a.nr, a.nt, a.srcw, a.maxf, a.qbytes, len(RESULTS), nfail, time.time() - t0, "PASS" if nfail == 0 else "FAIL"))
    if a.metrics:
        json.dump(METRICS, open(a.metrics, "w"), indent=1)
    sys.exit(1 if nfail else 0)


if __name__ == "__main__":
    main()
