"""Packet builders (raw, byte-exact, checksum-correct unless a defect is requested) + vector-file writers."""
import os
import random
import struct

import pktmodel as M

MAC_A = bytes.fromhex("0a0b0c0d0e01")
MAC_B = bytes.fromhex("1a1b1c1d1e02")


def ip4(a):
    return bytes(int(x) for x in a.split("."))


def ip6(a):
    import ipaddress
    return ipaddress.IPv6Address(a).packed


def eth(dst=MAC_A, src=MAC_B, etype=0x0800, vlans=()):
    """vlans: iterable of (tpid, pcp, dei, vid)"""
    h = dst + src
    for tpid, pcp, dei, vid in vlans:
        h += struct.pack(">HH", tpid, (pcp << 13) | (dei << 12) | vid)
    return h + struct.pack(">H", etype)


def ipv4(src, dst, proto, payload=b"", ttl=64, tos=0, ident=1, flags=0, frag=0, opts=b"", ver=4, ihl=None,
         tot=None, csum=None):
    assert len(opts) % 4 == 0
    ihl_v = 5 + len(opts) // 4 if ihl is None else ihl
    tl = 20 + len(opts) + len(payload) if tot is None else tot
    h = struct.pack(">BBHHHBBH", (ver << 4) | ihl_v, tos, tl, ident, (flags << 13) | frag, ttl, proto, 0)
    h += ip4(src) + ip4(dst) + opts
    c = M.csum16(h) if csum is None else csum
    h = h[:10] + struct.pack(">H", c) + h[12:]
    return h + payload


def tcp(sport, dport, flags=0x10, payload=b"", doff=None, opts=b"", seq=1, ack=0):
    assert len(opts) % 4 == 0
    d = 5 + len(opts) // 4 if doff is None else doff
    return struct.pack(">HHIIBBHHH", sport, dport, seq, ack, d << 4, flags, 1024, 0, 0) + opts + payload


def udp(sport, dport, payload=b"", length=None):
    ln = 8 + len(payload) if length is None else length
    return struct.pack(">HHHH", sport, dport, ln, 0) + payload


def vxlan(vni, inner=b"", flags=0x08):
    return struct.pack(">B3s3sB", flags, b"\0\0\0", vni.to_bytes(3, "big"), 0) + inner


def ipv6(src, dst, nh, payload=b"", hlim=64, tc=0, flow=0, plen=None, ver=6):
    pl = len(payload) if plen is None else plen
    first = (ver << 28) | (tc << 20) | flow
    return struct.pack(">IHBB", first, pl, nh, hlim) + ip6(src) + ip6(dst) + payload


def frag_hdr(nh_next, off8=0, mf=0, ident=0x11223344):
    return struct.pack(">BBHI", nh_next, 0, (off8 << 3) | mf, ident)


def ah_hdr(nh_next, words=6):
    """Authentication header of total length words*4 bytes (>=12). len field = words-2."""
    return bytes([nh_next, words - 2]) + bytes(2) + bytes(words * 4 - 4)


def pad(pkt, n=60):
    return pkt + bytes(max(0, n - len(pkt)))


# ----- canned well-formed packets --------------------------------------------------------------------
def udp4(sport=1111, dport=2222, payload=b"x" * 18, **kw):
    vl = kw.pop("vlans", ())
    return pad(eth(vlans=vl) + ipv4("10.1.1.1", "10.2.2.2", 17, udp(sport, dport, payload), **kw))


def tcp4(sport=3333, dport=80, payload=b"y" * 6, flags=0x18, **kw):
    vl = kw.pop("vlans", ())
    return pad(eth(vlans=vl) + ipv4("10.3.3.3", "10.4.4.4", 6, tcp(sport, dport, flags, payload), **kw))


# ------------------------------------------------------------------------------------------------
# vector files:  <base>.bytes.mem (one byte per line) + <base>.idx.mem (5 words per packet: off len src meta flags)
# ------------------------------------------------------------------------------------------------
def write_vectors(base, pkts):
    """pkts: list of (bytes, src, meta) or (bytes, src, meta, flags); flags bits: 1 s_err, 2 mid-frame partial keep,
    4 hole in last keep, 8 extra zero-keep last beat"""
    os.makedirs(os.path.dirname(base) or ".", exist_ok=True)
    off = 0
    with open(base + ".bytes.mem", "w") as fb, open(base + ".idx.mem", "w") as fi:
        for it in pkts:
            data, src, meta = it[0], it[1], it[2]
            flags = it[3] if len(it) > 3 else 0
            fi.write("%08x\n%08x\n%08x\n%08x\n%08x\n" % (off, len(data), src, meta, flags))
            for b in data:
                fb.write("%02x\n" % b)
            off += len(data)
    return len(pkts)


# ------------------------------------------------------------------------------------------------
# parser test-set generators
# ------------------------------------------------------------------------------------------------
def directed_set(rng):
    P = []
    a = P.append
    # ---- valid plain
    a(udp4()); a(tcp4()); a(udp4(vlans=[(0x8100, 5, 1, 100)])); a(tcp4(vlans=[(0x88A8, 3, 0, 200), (0x8100, 1, 0, 300)]))
    a(pad(eth(vlans=[(0x8100, 2, 0, 7)]) + ipv4("1.1.1.1", "2.2.2.2", 1, b"\x08\x00" + bytes(10))))   # ICMP -> OTHER
    a(pad(eth(etype=0x0806) + bytes(28)))                                   # ARP
    a(pad(eth(etype=0x0100) + bytes(46)))                                   # 802.3 length field
    a(pad(eth(etype=0x88CC) + bytes(40)))                                   # LLDP
    # IPv4 options (IHL 6..15)
    for n in range(1, 11):
        a(pad(eth() + ipv4("10.0.0.1", "10.0.0.2", 17, udp(1, 2, b"o" * 4), opts=bytes(range(4 * n)))))
        a(pad(eth(vlans=[(0x8100, 0, 0, 5), (0x8100, 0, 0, 6)]) + ipv4("10.0.0.1", "10.0.0.2", 6, tcp(1, 2, 0x02, b"t" * 4), opts=b"\x01" * (4 * n))))
    # TCP with options
    a(pad(eth() + ipv4("1.2.3.4", "5.6.7.8", 6, tcp(40000, 443, 0x12, b"", opts=b"\x02\x04\x05\xb4\x01\x03\x03\x08\x04\x02\x01\x01"))))
    # fragments v4: first (MF), middle, last
    a(pad(eth() + ipv4("9.9.9.9", "8.8.8.8", 17, udp(5, 6, b"frag" * 4), flags=1, frag=0)))
    a(pad(eth() + ipv4("9.9.9.9", "8.8.8.8", 17, b"mid" * 8, flags=1, frag=100)))
    a(pad(eth() + ipv4("9.9.9.9", "8.8.8.8", 6, b"end" * 8, flags=0, frag=200)))
    a(pad(eth() + ipv4("9.9.9.9", "8.8.8.8", 17, udp(5, 6, b"df" * 4), flags=2)))     # DF only: not a fragment
    # IPv6 plain + ext chains
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::1", "2001:db8::2", 17, udp(10, 20, b"a" * 20))))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::1", "2001:db8::2", 6, tcp(10, 20, 0x10, b"a" * 20), tc=0xB8, flow=0xABCDE)))
    a(pad(eth(etype=0x86DD, vlans=[(0x8100, 1, 0, 9)]) + ipv6("fe80::1", "ff02::1", 58, b"\x80\x00" + bytes(14))))
    for k in range(1, 6):          # k extension headers, 4 supported
        nhs = [0, 43, 60, 0, 43][:k]
        body = udp(111, 222, b"e" * 12)
        chain = b""
        for i in reversed(range(k)):
            nxt = 17 if i == k - 1 else nhs[i + 1]
            chain = bytes([nxt, 0]) + bytes(6) + chain
        a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", nhs[0], chain + body)))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 44, frag_hdr(17, 0, 1) + udp(1, 2, b"f" * 12))))     # first frag
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 44, frag_hdr(17, 50, 1) + b"q" * 20)))               # later frag
    for off8 in (0, 1, 2, 3, 7, 8, 100, 4095, 8191):    # every fragment-offset bit position
        for mf in (0, 1):
            a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 44, frag_hdr(6, off8, mf) + b"q" * 24)))
    for ln in (0, 1, 15, 16, 31, 63, 64, 127, 128, 200, 254, 255):   # ext-header length field sweep (HBH and AH)
        a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 0, bytes([17, ln]) + bytes(6) + udp(1, 2, b"L" * 12))))
        a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 51, bytes([17, ln]) + bytes(6) + udp(1, 2, b"L" * 12))))
        a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 0, bytes([60, 0]) + bytes(6) + bytes([17, ln]) + bytes(6) + udp(1, 2, b"L" * 12))))
    for do in range(0, 16):                              # TCP data offset sweep (min / max / illegal)
        a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 6, tcp(1, 2, 0x10, b"abcd", doff=do, opts=bytes(max(0, (do - 5)) * 4)))))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 51, ah_hdr(17, 6) + udp(3, 4, b"a" * 12))))          # AH
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 50, bytes(30))))                                       # ESP
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 59, bytes(8))))                                        # no next header
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 0, bytes([6, 0]) + bytes(6) + tcp(1, 2, 0x10, b"h"))))
    # long HBH pushing L4 beyond window -> unsupported WINDOW
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 0, bytes([17, 13]) + bytes(110) + udp(1, 2, b"w" * 12))))
    # 3 VLAN tags -> VLAN_OVF
    a(pad(eth(vlans=[(0x8100, 0, 0, 1), (0x8100, 0, 0, 2), (0x8100, 0, 0, 3)]) + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2))))
    # VXLAN v4 / v6 / vlan / flag unset / short
    a(pad(eth() + ipv4("172.16.0.1", "172.16.0.2", 17, udp(49152, 4789, vxlan(0x123456, bytes(60))))))
    a(pad(eth(vlans=[(0x8100, 0, 0, 77)]) + ipv4("172.16.0.1", "172.16.0.2", 17, udp(49152, 4789, vxlan(0xABCDEF, bytes(60))))))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::1", "2001:db8::2", 17, udp(49152, 4789, vxlan(0x00FFEE, bytes(60))))))
    a(pad(eth() + ipv4("172.16.0.1", "172.16.0.2", 17, udp(49152, 4789, vxlan(0x555555, bytes(60), flags=0x00)))))
    a(pad(eth() + ipv4("172.16.0.1", "172.16.0.2", 17, udp(49152, 4789, bytes(8)))))        # udp len 16 vxlan header only
    a(pad(eth() + ipv4("172.16.0.1", "172.16.0.2", 17, udp(49152, 4789, bytes(4)))))        # shorter than a VXLAN header
    # Ethernet padding: IP total length shorter than frame
    a(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"p" * 2)) + bytes(30))
    # ---- malformed
    for ver in (0, 3, 5, 6, 15):
        a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2), ver=ver)))
    for ihl in (0, 1, 2, 3, 4):
        a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2), ihl=ihl)))
    for tot in (0, 5, 19, 20, 27, 28, 29, 200, 1500, 65535):
        a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"abcd"), tot=tot)))
    a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"abcd"), csum=0x1234)))
    a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"abcd"), csum=0x0000)))
    a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"abcd"), csum=0xFFFF)))
    a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 6, tcp(1, 2, 0x10, b"abcd", doff=3))))
    a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 6, tcp(1, 2, 0x10, b"abcd", doff=15))))
    a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 6, tcp(1, 2, 0x10, b"abcd", doff=6, opts=b"\x01\x01\x01\x01"))))
    for ul in (0, 1, 7, 8, 9, 11, 12, 13, 500):
        a(pad(eth() + ipv4("1.1.1.1", "2.2.2.2", 17, udp(1, 2, b"abcd", length=ul))))
    for ver in (0, 4, 7):
        a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 17, udp(1, 2), ver=ver)))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 17, udp(1, 2, b"abcd"), plen=0)))      # jumbo/unknown
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 17, udp(1, 2, b"abcd"), plen=8)))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 17, udp(1, 2, b"abcd"), plen=9)))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::a", "2001:db8::b", 17, udp(1, 2, b"abcd"), plen=1000)))
    # jumbo-sized valid
    a(pad(eth() + ipv4("10.9.9.9", "10.8.8.8", 17, udp(100, 200, bytes(rng.randrange(256) for _ in range(8900))))))
    a(pad(eth(etype=0x86DD) + ipv6("2001:db8::9", "2001:db8::8", 6, tcp(100, 200, 0x10, bytes(rng.randrange(256) for _ in range(8900))))))
    return P


def truncation_sweep(base_pkts, rng, step_limit=140):
    out = []
    for p in base_pkts:
        for n in range(1, min(len(p), step_limit) + 1):
            out.append(p[:n])
        # a few mid-length prefixes
        for n in (len(p) - 1, len(p) // 2):
            if n > 0:
                out.append(p[:n])
    return out


def mutate(p, rng, hdr=100):
    q = bytearray(p)
    for _ in range(rng.choice((1, 1, 2, 3, 6))):
        i = rng.randrange(min(len(q), hdr))
        r = rng.random()
        if r < 0.5:
            q[i] ^= 1 << rng.randrange(8)
        elif r < 0.8:
            q[i] = rng.randrange(256)
        else:
            q[i] = rng.choice((0x00, 0xFF, 0x45, 0x60, 0x08, 0x86, 0x81, 0x00, 0x11, 0x06, 0x2B, 0x3C))
    return bytes(q)


def random_set(rng, n):
    base = directed_set(rng)
    P = []
    for _ in range(n):
        r = rng.random()
        if r < 0.55:
            P.append(mutate(rng.choice(base), rng))
        elif r < 0.8:
            L = rng.choice((1, 13, 14, 20, 33, 59, 60, 61, 64, 127, 128, 129, 200, 600, 1500))
            P.append(bytes(rng.randrange(256) for _ in range(L)))
        else:
            p = rng.choice(base)
            P.append(p[:rng.randrange(1, len(p) + 1)])
    return P


def build_parser_vectors(outdir, seed=1, nrandom=3000):
    rng = random.Random(seed)
    base = directed_set(rng)
    small_base = [p for p in base if len(p) <= 200]
    sets = {
        "directed": base,
        "truncation": truncation_sweep(small_base, rng),
        "random": random_set(rng, nrandom),
    }
    paths = {}
    for name, pk in sets.items():
        items = [(p, rng.randrange(256), i) for i, p in enumerate(pk)]
        b = os.path.join(outdir, "parser_" + name)
        write_vectors(b, items)
        paths[name] = (b, items)
    return paths
