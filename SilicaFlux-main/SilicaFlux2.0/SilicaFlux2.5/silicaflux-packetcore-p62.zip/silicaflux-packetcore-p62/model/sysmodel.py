"""
System-level reference model: configuration, match/action classification, header rewrite and the expected
fate of every packet (forward / management / drop + reason).  Independent of the RTL structure; written
from docs/CLASSIFIER.md and docs/ARCHITECTURE.md.
"""
import struct

import pktmodel as M
import sfdefs as D

VERD = dict(FWD=D.VERD_FWD, DROP=D.VERD_DROP, MGMT=D.VERD_MGMT)


# ------------------------------------------------------------------------------------------------
# rule helpers
# ------------------------------------------------------------------------------------------------
def make_rule(match=None, verdict="FWD", qid=None, hash_bits=None, tc=None, count=False, dscp=None, dec_ttl=False,
              valid=True):
    """match: {field: (value, mask)}  -- fields as in D.RULE_MATCH; omitted fields are wildcards."""
    r = {n: 0 for n, _ in D.RULE}
    r["valid"] = 1 if valid else 0
    r["verdict"] = VERD[verdict] if isinstance(verdict, str) else verdict
    if qid is not None:
        if hash_bits is not None:
            r["qsel_hash"], r["hash_bits"] = 1, hash_bits
        else:
            r["set_queue"] = 1
        r["qid"] = qid
    if tc is not None:
        r["set_tc"], r["tc"] = 1, tc
    r["count"] = 1 if count else 0
    if dscp is not None:
        r["set_dscp"], r["dscp"] = 1, dscp
    r["dec_ttl"] = 1 if dec_ttl else 0
    for f, (v, m) in (match or {}).items():
        r[f + "_v"], r[f + "_m"] = v, m
    return r


def rule_int(r):
    return D.pack(D.RULE_L, r)


def rule_words(r):
    return D.word_list(rule_int(r), D.RULE_WORDS)


def rule_pol_ok(r, qmask, nq):
    """tenant policy (mirror of the RTL check): FWD/DROP only, FWD needs explicit queue(s) inside the mask."""
    vd = r["verdict"]
    if vd in (D.VERD_MGMT, 3):
        return False
    if vd == D.VERD_FWD:
        if not r["set_queue"] and not r["qsel_hash"]:
            return False
        if r["set_queue"]:
            return r["qid"] < nq and bool((qmask >> r["qid"]) & 1)
        span = (1 << r["hash_bits"]) - 1
        for j in range(span + 1):
            q = r["qid"] + j
            if q >= nq or not (qmask >> q) & 1:
                return False
    return True


def rule_adm_ok(r, nq):
    if r["verdict"] == 3:
        return False
    if r["verdict"] == D.VERD_FWD:
        if r["set_queue"] and r["qid"] >= nq:
            return False
        if not r["set_queue"] and r["qsel_hash"] and r["qid"] + (1 << r["hash_bits"]) - 1 >= nq:
            return False
    return True


# ------------------------------------------------------------------------------------------------
# configuration
# ------------------------------------------------------------------------------------------------
class Cfg:
    def __init__(self, nq=4, nr=16, nt=8, max_frame=9216, win=128, max_ext=4):
        self.nq, self.nr, self.nt, self.max_frame, self.win, self.max_ext = nq, nr, nt, max_frame, win, max_ext
        self.rules = [make_rule(valid=False) for _ in range(nr)]
        self.owner = [0] * nr
        self.ten = {t: dict(vid=None, vni=None, qmask=0, en=0) for t in range(1, nt)}
        self.pol = dict(malformed_act=D.ACT_DROP, unsupp_act=D.ACT_PUNT, frag_act=D.ACT_CONT, csum_en=1, vxlan_en=1,
                        qdrop=0, min_len=60, max_len=max_frame, def_verdict=D.VERD_FWD, def_set_q=0, def_qid=0,
                        def_tc=0, tpid0=0x8100, tpid1=0x88A8, vxlan_port=4789, tc_src=D.TCSRC_NONE,
                        tc_qmap=[0] * 8, rl_period=1, sched_mode=D.SCHED_RR, starve=0, quant=2048)
        self.q = [dict(prio=0, weight=1, rl_inc=0, rl_burst=0xFFFF, wm=0xFFFFFFFF) for _ in range(nq)]
        self.rss_key = M.MS_KEY

    # ---- derived -----------------------------------------------------------------------------
    def parser_cfg(self):
        p = self.pol
        return dict(win=self.win, max_ext=self.max_ext, tpid0=p["tpid0"], tpid1=p["tpid1"], vxlan_port=p["vxlan_port"],
                    csum_en=p["csum_en"], vxlan_en=p["vxlan_en"], rss_key=self.rss_key)

    def eff_valid(self, r):
        rl = self.rules[r]
        if not rl["valid"]:
            return False
        ow = self.owner[r]
        if ow == 0:
            return True
        t = self.ten.get(ow)
        return bool(t and t["en"] and rule_pol_ok(rl, t["qmask"], self.nq))

    def scope_ok(self, r, tok):
        ow = self.owner[r]
        if ow == 0:
            return True
        t = self.ten[ow]
        if t["vid"] is not None and tok["vlan_cnt"] != 0 and tok["vlan_vid"] == t["vid"]:
            return True
        if t["vni"] is not None and tok["vni_valid"] and tok["vni"] == t["vni"]:
            return True
        return False

    # ---- register programming (administrator) ---------------------------------------------------
    def program(self, s, tenant=0):
        p = self.pol
        A = D.reg_addr

        def fld(reg, name, v):
            lsb, w = D.reg_field(reg, name)
            assert v < (1 << w), (reg, name, v)
            return v << lsb
        s.w(tenant, A("POL_ERR"), fld("POL_ERR", "malformed_act", p["malformed_act"]) | fld("POL_ERR", "unsupp_act", p["unsupp_act"])
            | fld("POL_ERR", "frag_act", p["frag_act"]) | fld("POL_ERR", "csum_en", p["csum_en"])
            | fld("POL_ERR", "vxlan_en", p["vxlan_en"]) | fld("POL_ERR", "qdrop", p["qdrop"]))
        s.w(tenant, A("POL_LEN"), p["min_len"] | (p["max_len"] << 16))
        s.w(tenant, A("POL_DEF"), p["def_verdict"] | (p["def_set_q"] << 2) | (p["def_qid"] << 4) | (p["def_tc"] << 8))
        s.w(tenant, A("POL_TPID"), p["tpid0"] | (p["tpid1"] << 16))
        s.w(tenant, A("POL_VXLAN"), p["vxlan_port"])
        s.w(tenant, A("POL_TC"), p["tc_src"])
        s.w(tenant, A("TC_QMAP"), sum(q << (4 * i) for i, q in enumerate(p["tc_qmap"])))
        s.w(tenant, A("RL_PERIOD"), p["rl_period"])
        s.w(tenant, A("SCHED_MODE"), p["sched_mode"])
        s.w(tenant, A("SCHED_STARVE"), p["starve"])
        s.w(tenant, A("SCHED_QUANT"), p["quant"])
        key = int.from_bytes(self.rss_key, "big")
        for i in range(D.RSS_KEY_WORDS):
            s.w(tenant, D.RSS_KEY_BASE + 4 * i, (key >> (32 * (9 - i))) & 0xFFFFFFFF)
        for qi, q in enumerate(self.q):
            b = D.QCFG_BASE + qi * D.QCFG_STRIDE
            s.w(tenant, b + D.QCFG["PRIO"], q["prio"])
            s.w(tenant, b + D.QCFG["WEIGHT"], q["weight"])
            s.w(tenant, b + D.QCFG["RL_INC"], q["rl_inc"])
            s.w(tenant, b + D.QCFG["RL_BURST"], q["rl_burst"])
            s.w(tenant, b + D.QCFG["WM"], q["wm"])
        for t, e in self.ten.items():
            b = D.TEN_BASE + t * D.TEN_STRIDE
            s.w(tenant, b + D.TEN["SCOPE_VID"], ((1 << 16) | e["vid"]) if e["vid"] is not None else 0)
            s.w(tenant, b + D.TEN["SCOPE_VNI"], ((1 << 31) | e["vni"]) if e["vni"] is not None else 0)
            s.w(tenant, b + D.TEN["QMASK"], e["qmask"])
            s.w(tenant, b + D.TEN["ENABLE"], e["en"])
        for r in range(self.nr):
            s.w(tenant, D.OWNER_BASE + 4 * r, self.owner[r])
        for r in range(self.nr):
            if self.rules[r]["valid"] or any(self.rules[r][k] for k in self.rules[r]):
                self.program_rule(s, tenant, r)

    def program_rule(self, s, tenant, idx, rule=None):
        if rule is not None:
            self.rules[idx] = rule
        for k, w in enumerate(rule_words(self.rules[idx])):
            s.w(tenant, D.STAGE_BASE + 4 * k, w)
        s.w(tenant, D.RULE_CMD, (D.CMD_COMMIT << 28) | idx)


# ------------------------------------------------------------------------------------------------
# classification (mirror of docs/CLASSIFIER.md)
# ------------------------------------------------------------------------------------------------
def upd16(hc, m, m2):
    s = ((~hc) & 0xFFFF) + ((~m) & 0xFFFF) + m2
    s = (s & 0xFFFF) + (s >> 16)
    s = (s & 0xFFFF) + (s >> 16)
    return (~s) & 0xFFFF


def key_of(tok):
    return dict(src_id=tok["src_id"], frag=tok["ip_frag"], vlan_valid=1 if tok["vlan_cnt"] else 0, vid=tok["vlan_vid"],
               pcp=tok["vlan_pcp"], ethertype=tok["ethertype"], dmac=tok["dmac"], l3_type=tok["l3_type"],
               ip_proto=tok["ip_proto"], dscp=tok["ip_tc"] >> 2, sip=tok["sip"], dip=tok["dip"], sport=tok["sport"],
               dport=tok["dport"], tcp_flags=tok["tcp_flags"], vni_valid=tok["vni_valid"], vni=tok["vni"])


def tok_matches(tok, rl):
    key = key_of(tok)
    for n, _ in D.RULE_MATCH:
        if ((key[n] ^ rl[n + "_v"]) & rl[n + "_m"]) != 0:
            return False
    return True


def classify(tok, cfg):
    p = cfg.pol
    hit, hidx = False, 0
    ovr = False
    verdict, reason = None, 0
    if tok["perr"]:
        ovr, verdict = True, (D.VERD_MGMT if p["malformed_act"] == D.ACT_PUNT else D.VERD_DROP)
        reason = D.PR_MALFORMED if verdict == D.VERD_MGMT else D.DR_MALFORMED
    elif tok["unsupp"] and p["unsupp_act"] != D.ACT_CONT:
        ovr, verdict = True, (D.VERD_MGMT if p["unsupp_act"] == D.ACT_PUNT else D.VERD_DROP)
        reason = D.PR_UNSUPP if verdict == D.VERD_MGMT else D.DR_UNSUPP
    elif tok["ip_frag"] and p["frag_act"] != D.ACT_CONT:
        ovr, verdict = True, (D.VERD_MGMT if p["frag_act"] == D.ACT_PUNT else D.VERD_DROP)
        reason = D.PR_FRAG if verdict == D.VERD_MGMT else D.DR_FRAG
    if not ovr:
        for r in range(cfg.nr):
            if cfg.eff_valid(r) and cfg.scope_ok(r, tok) and tok_matches(tok, cfg.rules[r]):
                hit, hidx = True, r
                break
    a = cfg.rules[hidx] if hit else None
    # traffic class
    if p["tc_src"] == D.TCSRC_PCP:
        tcb = tok["vlan_pcp"] if tok["vlan_cnt"] else 0
    elif p["tc_src"] == D.TCSRC_DSCP:
        tcb = (tok["ip_tc"] >> 5) if tok["l3_type"] != D.L3_NONE else 0
    else:
        tcb = p["def_tc"]
    tc = a["tc"] if (hit and a["set_tc"]) else tcb
    if ovr:
        v = verdict
    elif hit:
        v = a["verdict"]
    else:
        v = p["def_verdict"]
    if v == 3:
        v = D.VERD_DROP
    if hit and a["set_queue"]:
        q = a["qid"]
    elif hit and a["qsel_hash"]:
        q = a["qid"] + (tok["flow_hash"] & ((1 << a["hash_bits"]) - 1))
    elif (not hit) and p["def_set_q"]:
        q = p["def_qid"]
    else:
        q = p["tc_qmap"][tc]
    if q >= cfg.nq:
        q = 0
    if not ovr:
        if v == D.VERD_DROP:
            reason = D.DR_RULE
        elif v == D.VERD_MGMT:
            reason = D.PR_RULE if hit else D.PR_DEFAULT
    # rewrite
    patches = {}
    is4, is6 = tok["l3_type"] == D.L3_IPV4, tok["l3_type"] == D.L3_IPV6
    want_dscp = hit and a["set_dscp"] and cfg.rewrite_enabled
    want_ttl = hit and a["dec_ttl"] and cfg.rewrite_enabled
    rw_ok = (v == D.VERD_FWD) and (is6 or (is4 and tok["csum_ok"])) and (want_dscp or want_ttl)
    if rw_ok and want_ttl and tok["ip_ttl"] <= 1:
        v, reason, rw_ok = D.VERD_MGMT, D.PR_TTL, False
    l3 = tok["l3_off"]
    if rw_ok:
        ttl_new = tok["ip_ttl"] - 1 if want_ttl else tok["ip_ttl"]
        if is4:
            tos = tok["ip_tc"]
            tos_new = ((a["dscp"] << 2) | (tos & 3)) if want_dscp else tos
            w0, w0n = tok["ip_w0"], (tok["ip_w0"] & 0xFF00) | tos_new
            w4, w4n = (tok["ip_ttl"] << 8) | tok["ip_proto"], (ttl_new << 8) | tok["ip_proto"]
            cs = tok["ip_csum"]
            if w0n != w0:
                cs = upd16(cs, w0, w0n)
            if w4n != w4:
                cs = upd16(cs, w4, w4n)
            if w0n != w0:
                patches[l3 + 1] = tos_new
            if w4n != w4:
                patches[l3 + 8] = ttl_new
            if w0n != w0 or w4n != w4:
                patches[l3 + 10], patches[l3 + 11] = cs >> 8, cs & 0xFF
        else:
            tc8 = tok["ip_tc"]
            tcn = ((a["dscp"] << 2) | (tc8 & 3)) if want_dscp else tc8
            if tcn != tc8:
                patches[l3] = ((tok["ip_w0"] >> 8) & 0xF0) | (tcn >> 4)
                patches[l3 + 1] = ((tcn & 0xF) << 4) | (tok["ip_w0"] & 0xF)
            if want_ttl:
                patches[l3 + 7] = ttl_new
    return dict(verdict=v, qid=q, tc=tc, reason=reason, hit=hit and not ovr, rule=hidx, count=bool(hit and a["count"]),
                need_len=tok["need_len"], hash=tok["flow_hash"], patches=patches)


Cfg.rewrite_enabled = True


def keep_bad(flags, nbytes, dwb):
    """Mirror of the testbench's keep-violation injection."""
    nb_data = (nbytes + dwb - 1) // dwb
    nb_last = nbytes - (nb_data - 1) * dwb
    bad = False
    if flags & 2 and nb_data > 2:
        bad = True
    if flags & 4 and nb_last >= 2:
        bad = True
    if flags & 8:
        bad = True
    return bad


def parser_view(pkt, flags, dwb):
    """Bytes the parser actually sees for frames carrying injected keep violations (masked bytes read as 0; a
    zero-keep final beat makes the last data beat count as a full beat).  Such frames are dropped as KEEP anyway;
    this only keeps the parse/rule statistics exact."""
    nb_data = (len(pkt) + dwb - 1) // dwb
    nb_last = len(pkt) - (nb_data - 1) * dwb
    b = bytearray(pkt)
    if flags & 2 and nb_data > 2 and 2 * dwb - 1 < len(b):
        b[2 * dwb - 1] = 0
    if flags & 4 and nb_last >= 2:
        b[(nb_data - 1) * dwb] = 0
    if flags & 8:
        b += bytes(nb_data * dwb - len(b))
    return bytes(b)


def rtl_byte_counts(L, flags, dwb):
    """(rx_bytes, drop_bytes) as accounted by the RTL: rx = popcount(keep) per beat; the dispatcher counts every
    non-final beat as a full beat and the final beat by popcount(keep)."""
    nb_data = (L + dwb - 1) // dwb
    nb_last = L - (nb_data - 1) * dwb
    if flags & 2 and nb_data > 2:
        return L - 1, L
    if flags & 4 and nb_last >= 2:
        return L - 1, L - 1
    if flags & 8:
        return L, nb_data * dwb
    return L, L


def fate(pkt, src, flags, cfg, dwb):
    """Expected disposition of one frame under configuration cfg (lossless queues)."""
    tok = M.parse(parser_view(pkt, flags, dwb), src, cfg.parser_cfg())
    d = classify(tok, cfg)
    L = len(pkt)
    out = dict(tok=tok, dec=d)
    if flags & 1:
        out["fate"], out["reason"] = "drop", D.DR_MACERR
    elif keep_bad(flags, L, dwb):
        out["fate"], out["reason"] = "drop", D.DR_KEEP
    elif L > cfg.pol["max_len"]:
        out["fate"], out["reason"] = "drop", D.DR_OVERSIZE
    elif L < cfg.pol["min_len"]:
        out["fate"], out["reason"] = "drop", D.DR_RUNT
    elif d["verdict"] == D.VERD_DROP:
        out["fate"], out["reason"] = "drop", d["reason"]
    elif L < d["need_len"]:
        out["fate"], out["reason"] = "drop", D.DR_LENMIS
    else:
        b = bytearray(pkt)
        for off, v in d["patches"].items():
            b[off] = v
        out["bytes"] = bytes(b)
        if d["verdict"] == D.VERD_MGMT:
            out["fate"], out["reason"] = "mgmt", d["reason"]
        else:
            out["fate"], out["reason"] = "fwd", 0
    return out


# ------------------------------------------------------------------------------------------------
# script builder
# ------------------------------------------------------------------------------------------------
class Script:
    """Numeric script for tb_packet_engine.  Register ops may carry expectations (err flag, read data)."""

    def __init__(self):
        self.lines = []
        self.exp = []          # one entry per register op, in order: (kind, tenant, addr, err, val, mask)

    def w(self, t, a, d, err=None):
        self.lines.append((1, t, a, d & 0xFFFFFFFF))
        self.exp.append(("WR", t, a, err, None, 0))

    def r(self, t, a, err=None, val=None, mask=0xFFFFFFFF):
        self.lines.append((2, t, a, 0))
        self.exp.append(("RD", t, a, err, val, mask))

    def wait(self, n):
        self.lines.append((3, n, 0, 0))

    def send(self, first, n):
        self.lines.append((4, first, n, 0))

    def waitinj(self, timeout=4000000):
        self.lines.append((5, timeout, 0, 0))

    def drain(self, timeout=4000000):
        self.lines.append((6, timeout, 0, 0))

    def mode(self, key, val):
        self.lines.append((7, key, val, 0))

    def reset(self, n=4):
        self.lines.append((8, n, 0, 0))

    def write(self, path):
        with open(path, "w") as f:
            for l in self.lines:
                f.write("%x %x %x %x\n" % l)

    # convenience: read a register block
    def rule_status(self, t):
        self.r(t, D.RULE_STATUS)

    def snap_and_read(self, names_idx):
        self.w(0, D.reg_addr("CTRL"), (1 << 0) | (1 << 1) | (1 << 8))
        for idx in names_idx:
            self.r(0, D.GCNT_BASE + idx * D.GCNT_STRIDE)
            self.r(0, D.GCNT_BASE + idx * D.GCNT_STRIDE + 4)
