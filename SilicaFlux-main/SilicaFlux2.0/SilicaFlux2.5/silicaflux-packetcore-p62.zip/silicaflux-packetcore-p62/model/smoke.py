import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import sysharness as H, sysmodel as S, traffic as T, sfdefs as D

rng = random.Random(5)
pk, flows = T.mix(rng, 300)
cfg = S.Cfg()
s = S.Script()
cfg.program(s)
for a in (D.reg_addr("ID"), D.reg_addr("VERSION"), D.reg_addr("CAPS0"), D.reg_addr("CAPS1"), D.reg_addr("CAPS2")):
    s.r(0, a)
s.send(0, len(pk)); s.waitinj(); s.drain()
H.read_all_counters_script(s, 4)
res, p = H.run("smoke", {}, pk, s)
fates = H.expected_fates(pk, cfg, 16)
print([hex(r[2]) for r in res.rd[:5]], "stat", res.stat)
c = H.check_outputs("smoke fwd", pk, fates, res, cfg, 16); c.report()
c = H.check_counters("smoke counters", res, pk, fates, cfg, 16, 4, check_rules=False); c.report()
