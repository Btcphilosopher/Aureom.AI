#!/usr/bin/env python3
"""MAC adapter regression: behavioural AXI-S MAC -> adapter -> engine -> adapter -> behavioural sink."""
import os, subprocess, sys, random, hashlib
HERE = os.path.dirname(os.path.abspath(__file__)); ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)
import pktgen as G, sysmodel as S, traffic as T, sfdefs as D, sysharness as H, run_system_tests as R

FILES = ["sim/vendor_build/sync_fifo.sv", "rtl/sf_pkt_fifo.sv", "sim/vendor_build/sfb_skid_buffer.sv", "sim/vendor_build/sf_rr_arb.sv",
         "rtl/sf_pkt_toeplitz.sv", "rtl/sf_pkt_parser.sv", "rtl/sf_pkt_classifier.sv", "rtl/sf_pkt_counters.sv",
         "rtl/sf_pkt_queue.sv", "rtl/sf_pkt_dispatch.sv", "rtl/sf_pkt_sched.sv", "rtl/sf_pkt_regs.sv",
         "rtl/silicaflux_packet_engine.sv", "rtl/sf_pkt_mac_adapter.sv", "tb/tb_mac_adapter.sv"]


def build(dw, rxb):
    key = hashlib.sha1(("%d_%d_%s" % (dw, rxb, H.src_hash())).encode()).hexdigest()[:10]
    obj = os.path.join(ROOT, "sim", "mac", "obj_" + key)
    exe = os.path.join(obj, "Vtb")
    if os.path.exists(exe):
        return exe
    os.makedirs(obj, exist_ok=True)      # verilator --Mdir creates only the last path component (clean checkout: sim/ is empty)
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-O2", "--Mdir", obj,
           "--top-module", "tb_mac_adapter", "-I" + os.path.join(ROOT, "rtl"), "-I" + os.path.join(ROOT, "sim/vendor_build"),
           "-GDW=%d" % dw, "-GRXB=%d" % rxb] + [os.path.join(ROOT, f) for f in FILES] + ["-o", "Vtb"]
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    if r.returncode:
        print(r.stdout[-2000:], r.stderr[-2000:]); sys.exit(2)
    return exe


def run(name, dw, rxb, pk, rxgap=0, txrdy=100, txblock=0, seed=1):
    exe = build(dw, rxb)
    work = os.path.join(ROOT, "sim", "mac", "run_" + name); os.makedirs(work, exist_ok=True)
    base = os.path.join(work, "vec")
    G.write_vectors(base, [(p[0], 0, i, p[1] if len(p) > 1 else 0) for i, p in enumerate(pk)])
    out = os.path.join(work, "out.log")
    r = subprocess.run([exe, "+vec=" + base, "+out=" + out, "+n=%d" % len(pk), "+rxgap=%d" % rxgap, "+txrdy=%d" % txrdy,
                        "+txblock=%d" % txblock, "+seed=%d" % seed], capture_output=True, text=True, timeout=3600)
    if "TB_RESULT DONE" not in r.stdout:
        print(r.stdout[-1500:], r.stderr[-1500:]); raise RuntimeError("sim failed")
    tx, stat, proto = [], {}, []
    for line in open(out):
        t = line.split()
        if t[0] == "TX":
            tx.append((int(t[1]), int(t[2]), int(t[3]), bytes.fromhex(t[4]) if len(t) > 4 else b""))
        elif t[0] == "STAT":
            stat = {k: int(v) for k, v in (x.split("=") for x in t[1:])}
        elif t[0] == "PROTO":
            proto.append(line.strip())
    return tx, stat, proto


def main():
    dws = [int(x) for x in (sys.argv[1:] or ["128"])]
    ok_all = True
    for dw in dws:
        dwb = dw // 8
        rng = random.Random(7)
        cfg = S.Cfg(); cfg.pol["unsupp_act"] = D.ACT_DROP        # management port is not wired to a MAC: drop instead
        print("[mac adapter] DW=%d" % dw)
        # ---- 1. normal operation (idle gaps on RX, random TX ready): everything forwardable must come out, in order
        pk, _ = T.mix(rng, 500, special_frac=0.1)
        pk = [(p[0], 1 if p[2] & 1 else 0) for p in pk]           # keep only the MAC bad-frame flag
        tx, stat, proto = run("n%d" % dw, dw, 32768, pk, rxgap=25, txrdy=60)
        fates = [S.fate(p[0], 0, p[1], cfg, dwb) for p in pk]
        exp = [f["bytes"] for f in fates if f["fate"] == "fwd"]
        c = H.Check("mac/normal: forwarded frames exact and in order (%d expected)" % len(exp))
        got = [t[3] for t in tx]
        if got != exp:
            c.err("TX sequence differs: got %d frames, expected %d" % (len(got), len(exp)))
        if proto: c.err(proto[0])
        if stat["rx_overflow"]: c.err("unexpected RX overflow %d" % stat["rx_overflow"])
        if stat["rx_bad"] != sum(1 for p in pk if p[1] & 1): c.err("rx_bad counter %d" % stat["rx_bad"])
        c.notes.append("rx_frames=%d bad=%d tx_frames=%d" % (stat["rx_frames"], stat["rx_bad"], stat["tx_frames"]))
        ok_all &= c.report()
        # ---- 2. RX line-rate burst while the TX is stalled: whole-frame drops only, no partial frames, no corruption
        pk = [(G.pad(R.frame_of_len(rng.choice([300, 700, 1200, 1500]), rng)), 0) for _ in range(200)]
        # stall the TX for a fixed BYTE volume of RX line-rate traffic (96 kB), independent of the datapath width, so that the
        # 16 kB RX buffer plus the engine queues must overflow at every width (a fixed cycle count does not at DW = 64)
        blk = 96000 * 8 // dw
        tx, stat, proto = run("o%d" % dw, dw, 16384, pk, rxgap=0, txrdy=100, txblock=blk)
        exp_map = {G.pad(p[0]): i for i, p in enumerate(pk)}
        c = H.Check("mac/overflow: RX cannot be paused -> whole-frame drops, delivered frames intact and ordered")
        idsq = []
        for t in tx:
            i = exp_map.get(t[3])
            if i is None: c.err("a delivered frame matches no injected frame (partial / corrupt)"); break
            idsq.append(i)
        if idsq != sorted(idsq) or len(set(idsq)) != len(idsq): c.err("delivered frames reordered / duplicated")
        if stat["rx_overflow"] == 0: c.err("buffer never overflowed")
        if len(tx) + stat["rx_overflow"] != len(pk): c.err("delivered %d + overflow %d != injected %d" % (len(tx), stat["rx_overflow"], len(pk)))
        if proto: c.err(proto[0])
        c.notes.append("injected=%d delivered=%d dropped-whole=%d" % (len(pk), len(tx), stat["rx_overflow"]))
        ok_all &= c.report()
        # ---- 3. back-to-back minimum frames at MAC line rate
        pk = [(R.frame_of_len(60, rng), 0) for _ in range(400)]
        tx, stat, proto = run("l%d" % dw, dw, 32768, pk, rxgap=0, txrdy=100)
        c = H.Check("mac/line-rate: 400 back-to-back 60 B frames, no loss")
        if len(tx) != 400 or stat["rx_overflow"]: c.err("delivered %d, overflow %d" % (len(tx), stat["rx_overflow"]))
        if proto: c.err(proto[0])
        sp = [t[1] for t in tx]
        if len(sp) > 20:
            span = sp[-1] - sp[19]; beats = (len(sp) - 20) * ((60 + dwb - 1) // dwb)
            c.notes.append("TX %.3f beats/cycle" % (beats / span))
        ok_all &= c.report()
    print("MAC ADAPTER REGRESSION:", "PASS" if ok_all else "FAIL")
    sys.exit(0 if ok_all else 1)


if __name__ == "__main__":
    main()
