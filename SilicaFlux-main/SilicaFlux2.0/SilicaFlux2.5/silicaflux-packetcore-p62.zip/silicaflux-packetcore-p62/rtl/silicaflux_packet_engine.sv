// =============================================================================
// SilicaFlux PacketCore (Project 62) :: silicaflux_packet_engine -- programmable cloud network processor
//
// Streaming packet engine:  ingress stream -> parse -> match/action classify -> steer into egress queues
// (store-and-forward at the queue, commit/abort) -> packet-atomic scheduler -> egress stream; plus a
// management (punt) port, a versioned register interface with tenant isolation, and a statistics block.
//
// STREAM CONTRACT (ingress s_*, egress m_*, management x_*)  -- AXI4-Stream compatible subset
//   * Transfer on valid && ready.  `last` marks the final beat of a frame; the first beat after a `last`
//     (or after reset) is the start of packet (SOP) -- there is no separate SOP signal.
//   * Byte ordering: frame byte 0 (first destination-MAC byte on the wire) is data[7:0] of beat 0; byte k of
//     a beat is data[8k+7:8k].  Within a frame the byte stream is contiguous across beats.
//   * keep (byte enable): all-ones on every beat except the last; on the last beat keep is a contiguous
//     low-order mask (2^n - 1, n >= 1) -- partial final beats.  Frames EXCLUDE the Ethernet FCS (the MAC
//     strips/validates it and reports a bad frame with s_err).  A keep pattern violating this is detected and
//     the frame is dropped (DROP_KEEP).  Data under keep = 0 is never used.
//   * s_err is sampled on the last beat only: 1 = the MAC flagged the frame bad (e.g. FCS) -> dropped
//     (DROP_MACERR), never forwarded.  m_err is tied 0 (the engine never forwards a frame flagged bad).
//   * s_src (ingress queue / port id, SRC_W bits) and s_meta (opaque user metadata, META_W bits) are sampled
//     on the FIRST beat of each frame; they are carried unchanged to m_src / m_meta (and x_*).  Egress
//     sideband (m_queue, m_tc, m_src, m_meta, m_hash, m_len) is valid on every beat of the frame and constant
//     for the frame.  Frames are never interleaved and the downstream receives whole frames or nothing.
//   * Ordering: frames leave a given queue in arrival order; frames of one flow take one path unless the
//     rule table is edited.  Across queues the scheduler interleaves at frame boundaries only.
//   * Reset (async, active low) mid-frame: all in-flight state is discarded.  An egress frame that was in
//     progress is cut without `last`; the receiver must be reset with the engine (system-level reset).
// DOES NOT: generate / check Ethernet FCS, implement a MAC or PHY, modify bytes other than the explicit
//   rewrite actions (DSCP / TTL / IPv4 checksum bytes).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_pkt_macros.svh"
`default_nettype none

module silicaflux_packet_engine #(
  parameter int DW              = 128,     // datapath width in bits (multiple of 8; 64/128/256/512 verified)
  parameter int SRC_W           = 4,       // ingress source / queue id width (<= 8)
  parameter int META_W          = 16,      // opaque metadata width
  parameter int NUM_QUEUES      = 4,       // egress data queues (1..16)
  parameter int NUM_RULES       = 16,      // match/action rules (1..64)
  parameter int NUM_TENANTS     = 8,       // tenant ids 0..NUM_TENANTS-1 (0 = administrator)
  parameter int MAX_FRAME_BYTES = 9216,    // largest supported frame (<= 65535)
  parameter int QUEUE_BYTES     = 16384,   // storage per egress queue (power-of-2 beats, >= MAX_FRAME_BYTES)
  parameter int MGMT_BYTES      = 16384,   // storage of the management queue
  parameter int PKT_DEPTH       = 64,      // committed frames per queue (power of 2)
  parameter int HDR_CAP_BYTES   = 128,     // parser header window (>=128, <=255 after rounding to beats)
  parameter int MAX_EXT         = 4,       // IPv6 extension headers walked (multiple of EXT_STEP)
  parameter int EXT_STEP        = 2,
  parameter int DELAY_BEATS     = 64,      // delay FIFO depth in beats (power of 2)
  parameter int DEC_DEPTH       = 32,      // max frames in flight between ingress and dispatch (power of 2)
  parameter int CW              = 40,      // statistics counter width (33..64)
  parameter bit ENABLE_RSS      = 1'b1,
  parameter bit RSS_PROG_KEY    = 1'b1,   // 0 = fixed Microsoft RSS key (smaller); RSS_KEY registers then have no effect
  parameter bit ENABLE_VXLAN    = 1'b1,
  parameter bit ENABLE_REWRITE  = 1'b1,
  parameter bit ENABLE_TENANT   = 1'b1,
  parameter bit ENABLE_PERF     = 1'b1,
  parameter bit ENABLE_RULE_READ = 1'b1,   // 0: omit rule read-back (RULE_CMD READ -> ERR_CMD); smaller register block
  parameter bit FIFO_RAM         = 1'b1    // 1: block-RAM friendly FIFOs (sf_pkt_fifo); 0: vendored async-read sync_fifo (registers on FPGA)
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---- ingress stream ------------------------------------------------------------------------------
  input  wire logic                   s_valid,
  output logic                        s_ready,
  input  wire logic [DW-1:0]          s_data,
  input  wire logic [DW/8-1:0]        s_keep,
  input  wire logic                   s_last,
  input  wire logic                   s_err,
  input  wire logic [SRC_W-1:0]       s_src,
  input  wire logic [META_W-1:0]      s_meta,
  // ---- data egress stream ---------------------------------------------------------------------------
  output logic                        m_valid,
  input  wire logic                   m_ready,
  output logic [DW-1:0]               m_data,
  output logic [DW/8-1:0]             m_keep,
  output logic                        m_last,
  output logic                        m_err,
  output logic [3:0]                  m_queue,
  output logic [2:0]                  m_tc,
  output logic [SRC_W-1:0]            m_src,
  output logic [META_W-1:0]           m_meta,
  output logic [31:0]                 m_hash,
  output logic [15:0]                 m_len,
  // ---- management (punt) egress stream ------------------------------------------------------------------
  output logic                        x_valid,
  input  wire logic                   x_ready,
  output logic [DW-1:0]               x_data,
  output logic [DW/8-1:0]             x_keep,
  output logic                        x_last,
  output logic [3:0]                  x_reason,
  output logic [2:0]                  x_tc,
  output logic [SRC_W-1:0]            x_src,
  output logic [META_W-1:0]           x_meta,
  output logic [31:0]                 x_hash,
  output logic [15:0]                 x_len,
  // ---- register bus ----------------------------------------------------------------------------------------
  input  wire logic                   rb_req,
  input  wire logic                   rb_we,
  input  wire logic [15:0]            rb_addr,
  input  wire logic [31:0]            rb_wdata,
  input  wire logic [3:0]             rb_tenant,
  output logic                        rb_rvalid,
  output logic [31:0]                 rb_rdata,
  output logic                        rb_err,
  // ---- status ----------------------------------------------------------------------------------------------
  output logic                        idle
);
  `include "sf_pkt_defs.svh"

  localparam int DWB       = DW / 8;
  localparam int DESC_W    = 87 + SRC_W + META_W;
  localparam int SB_W      = SRC_W + META_W + 32;
  localparam int HDR_BEATS = (HDR_CAP_BYTES + DWB - 1) / DWB;
  localparam int QDEPTH    = QUEUE_BYTES / DWB;
  localparam int MQDEPTH   = MGMT_BYTES / DWB;
  localparam int PCW       = $clog2(PKT_DEPTH) + 1;
  localparam int AW_ADM    = $clog2(DEC_DEPTH) + 1;
  localparam int NQ        = NUM_QUEUES;
  localparam int IW        = DW + DWB + 2 + SRC_W + META_W;

  generate
    if (SRC_W < 1 || SRC_W > 8)             begin : g_e1 initial $error("SRC_W must be 1..8"); end
    if (NQ < 1 || NQ > 16)                  begin : g_e2 initial $error("NUM_QUEUES must be 1..16"); end
    if (QUEUE_BYTES < MAX_FRAME_BYTES + DWB) begin : g_e3 initial $error("QUEUE_BYTES must exceed MAX_FRAME_BYTES (lossless mode deadlock-freedom)"); end
    if (MGMT_BYTES  < MAX_FRAME_BYTES + DWB) begin : g_e4 initial $error("MGMT_BYTES must exceed MAX_FRAME_BYTES"); end
    if ((QDEPTH & (QDEPTH - 1)) != 0)       begin : g_e5 initial $error("QUEUE_BYTES/(DW/8) must be a power of two"); end
    if ((MQDEPTH & (MQDEPTH - 1)) != 0)     begin : g_e6 initial $error("MGMT_BYTES/(DW/8) must be a power of two"); end
    if (DELAY_BEATS < HDR_BEATS + 16)       begin : g_e7 initial $error("DELAY_BEATS must be >= header beats + 16"); end
    if ((DELAY_BEATS & (DELAY_BEATS - 1)) != 0) begin : g_e8 initial $error("DELAY_BEATS must be a power of two"); end
    if ((DEC_DEPTH & (DEC_DEPTH - 1)) != 0 || DEC_DEPTH < 16) begin : g_e9 initial $error("DEC_DEPTH must be a power of two >= 16"); end
  endgenerate

  function automatic [15:0] popcnt_f(input [DWB-1:0] k);
    integer i;
    reg [15:0] c;
    begin
      c = 16'd0;
      for (i = 0; i < DWB; i = i + 1) c = c + {15'd0, k[i]};
      popcnt_f = c;
    end
  endfunction

  // ---------------------------------------------------------------------------------------------------
  // free-running time base, register block
  // ---------------------------------------------------------------------------------------------------
  reg [31:0] now;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) now <= 32'd0;
    else        now <= now + 32'd1;
  end

  // config wires
  wire        cfg_enable, cfg_cnt_en, cfg_csum_en, cfg_vxlan_en, cfg_qdrop, cfg_def_setq;
  wire [1:0]  cfg_malformed_act, cfg_unsupp_act, cfg_frag_act, cfg_def_verdict, cfg_tc_src, cfg_sched_mode;
  wire [15:0] cfg_min_len, cfg_max_len, cfg_tpid0, cfg_tpid1, cfg_vxlan_port, cfg_rl_period, cfg_quant;
  wire [3:0]  cfg_def_qid;
  wire [2:0]  cfg_def_tc;
  wire [31:0] cfg_tc_qmap, cfg_starve;
  wire [319:0] cfg_rss_key;
  wire [NQ*2-1:0]  q_prio;
  wire [NQ*8-1:0]  q_weight;
  wire [NQ*16-1:0] q_rl_inc;
  wire [NQ*24-1:0] q_rl_burst;
  wire [NQ*32-1:0] q_wm;
  wire [NUM_RULES*`SFP_RL_W-1:0]     rule_flat;
  wire [NUM_RULES*`SFP_RL_ACT_W-1:0] act_flat;
  wire [NUM_RULES-1:0]   rl_eff_valid, rl_scoped, rl_sc_vidv, rl_sc_vniv;
  wire [NUM_RULES*12-1:0] rl_sc_vid;
  wire [NUM_RULES*24-1:0] rl_sc_vni;
  wire [7:0]       cnt_rd_idx, rr_idx;
  wire [CW-1:0]    cnt_rd_data, rr_hits, rr_bytes;
  wire             snap_g, clr_g, snap_r, clr_r, ev_viol, ev_rd, ev_wr;
  wire [NQ*32-1:0] q_occ_bytes;
  wire             st_idle;
  wire [7:0]       st_inflight;

  sf_pkt_regs #(.NQ(NQ), .NR(NUM_RULES), .NT(NUM_TENANTS), .DW(DW), .MAX_FRAME_BYTES(MAX_FRAME_BYTES),
                .QUEUE_BYTES(QUEUE_BYTES), .WIN_BYTES(HDR_BEATS * DWB), .MAX_EXT(MAX_EXT), .CW(CW),
                .ENABLE_RSS(ENABLE_RSS), .ENABLE_VXLAN(ENABLE_VXLAN), .ENABLE_REWRITE(ENABLE_REWRITE),
                .ENABLE_TENANT(ENABLE_TENANT), .ENABLE_PERF(ENABLE_PERF), .ENABLE_RULE_READ(ENABLE_RULE_READ)) u_regs (
    .clk(clk), .rst_n(rst_n),
    .rb_req(rb_req), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_tenant(rb_tenant),
    .rb_rvalid(rb_rvalid), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .st_idle(st_idle), .st_inflight(st_inflight), .q_occ_bytes(q_occ_bytes),
    .cnt_rd_idx(cnt_rd_idx), .cnt_rd_data(cnt_rd_data), .rr_idx(rr_idx), .rr_hits(rr_hits), .rr_bytes(rr_bytes),
    .snap_g(snap_g), .clr_g(clr_g), .snap_r(snap_r), .clr_r(clr_r), .ev_viol(ev_viol), .ev_rd(ev_rd), .ev_wr(ev_wr),
    .cfg_enable(cfg_enable), .cfg_cnt_en(cfg_cnt_en),
    .cfg_malformed_act(cfg_malformed_act), .cfg_unsupp_act(cfg_unsupp_act), .cfg_frag_act(cfg_frag_act),
    .cfg_csum_en(cfg_csum_en), .cfg_vxlan_en(cfg_vxlan_en), .cfg_qdrop(cfg_qdrop),
    .cfg_min_len(cfg_min_len), .cfg_max_len(cfg_max_len),
    .cfg_def_verdict(cfg_def_verdict), .cfg_def_setq(cfg_def_setq), .cfg_def_qid(cfg_def_qid), .cfg_def_tc(cfg_def_tc),
    .cfg_tpid0(cfg_tpid0), .cfg_tpid1(cfg_tpid1), .cfg_vxlan_port(cfg_vxlan_port),
    .cfg_tc_src(cfg_tc_src), .cfg_tc_qmap(cfg_tc_qmap), .cfg_rl_period(cfg_rl_period),
    .cfg_sched_mode(cfg_sched_mode), .cfg_starve(cfg_starve), .cfg_quant(cfg_quant), .cfg_rss_key(cfg_rss_key),
    .q_prio(q_prio), .q_weight(q_weight), .q_rl_inc(q_rl_inc), .q_rl_burst(q_rl_burst), .q_wm(q_wm),
    .rule_flat(rule_flat), .act_flat(act_flat), .rl_eff_valid(rl_eff_valid), .rl_scoped(rl_scoped),
    .rl_sc_vidv(rl_sc_vidv), .rl_sc_vid(rl_sc_vid), .rl_sc_vniv(rl_sc_vniv), .rl_sc_vni(rl_sc_vni));

  // ---------------------------------------------------------------------------------------------------
  // ingress: register slice + admission control
  // ---------------------------------------------------------------------------------------------------
  wire [IW-1:0] sk_in = {s_meta, s_src, s_err, s_last, s_keep, s_data};
  wire [IW-1:0] sk_out;
  wire          i_valid;
  wire          i_ready;
  sfb_skid_buffer #(.WIDTH(IW)) u_in_slice (
    .clk(clk), .rst_n(rst_n),
    .s_valid(s_valid), .s_ready(s_ready), .s_data(sk_in),
    .m_valid(i_valid), .m_ready(i_ready), .m_data(sk_out));

  wire [DW-1:0]     i_data = sk_out[0 +: DW];
  wire [DWB-1:0]    i_keep = sk_out[DW +: DWB];
  wire              i_last = sk_out[DW + DWB];
  wire              i_err  = sk_out[DW + DWB + 1];
  wire [SRC_W-1:0]  i_src  = sk_out[DW + DWB + 2 +: SRC_W];
  wire [META_W-1:0] i_meta = sk_out[DW + DWB + 2 + SRC_W +: META_W];

  reg               in_pkt;
  reg  [AW_ADM-1:0] admit_cnt;
  wire              dly_full, dly_empty;
  wire              acc     = i_valid && i_ready;
  wire              sop_acc = acc && !in_pkt;
  wire              dec_pop;
  assign i_ready = !dly_full && (in_pkt || (cfg_enable && (admit_cnt < AW_ADM'(DEC_DEPTH))));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      in_pkt    <= 1'b0;
      admit_cnt <= '0;
    end else begin
      if (acc) in_pkt <= !i_last;
      case ({sop_acc, dec_pop})
        2'b10:   admit_cnt <= admit_cnt + 1'b1;
        2'b01:   admit_cnt <= admit_cnt - 1'b1;
        default: admit_cnt <= admit_cnt;
      endcase
    end
  end

  // delay FIFO: holds every beat until its packet's decision exists
  wire [DW+DWB+1:0] dly_rd;
  wire              d_pop;
  wire [$clog2(DELAY_BEATS):0] dly_count;
  sf_pkt_fifo #(.WIDTH(DW + DWB + 2), .DEPTH(DELAY_BEATS), .RAM(FIFO_RAM)) u_dly (
    .clk(clk), .rst_n(rst_n),
    .push(acc), .wdata({i_err, i_last, i_keep, i_data}),
    .pop(d_pop), .rdata(dly_rd),
    .full(dly_full), .empty(dly_empty), .overflow(), .underflow(), .count(dly_count));

  // sideband FIFO (one entry per packet): {ts, meta, src}
  wire [SB_W-1:0] sb_rd;
  wire            sb_empty, sb_full;
  wire [$clog2(DEC_DEPTH):0] sb_count;
  sf_pkt_fifo #(.WIDTH(SB_W), .DEPTH(DEC_DEPTH), .RAM(FIFO_RAM)) u_sb (
    .clk(clk), .rst_n(rst_n),
    .push(sop_acc), .wdata({now, i_meta, i_src}),
    .pop(dec_pop), .rdata(sb_rd),
    .full(sb_full), .empty(sb_empty), .overflow(), .underflow(), .count(sb_count));

  // ---------------------------------------------------------------------------------------------------
  // parser + classifier
  // ---------------------------------------------------------------------------------------------------
  wire                   tok_valid;
  wire [`SFP_TK_W-1:0]   tok;
  sf_pkt_parser #(.DW(DW), .HDR_CAP_BYTES(HDR_CAP_BYTES), .MAX_EXT(MAX_EXT), .EXT_STEP(EXT_STEP),
                  .ENABLE_VXLAN(ENABLE_VXLAN), .ENABLE_RSS(ENABLE_RSS), .RSS_PROG_KEY(RSS_PROG_KEY)) u_parser (
    .clk(clk), .rst_n(rst_n),
    .acc_valid(acc), .acc_data(i_data), .acc_keep(i_keep), .acc_last(i_last), .acc_src({{(8-SRC_W){1'b0}}, i_src}),
    .cfg_tpid0(cfg_tpid0), .cfg_tpid1(cfg_tpid1), .cfg_vxlan_port(cfg_vxlan_port),
    .cfg_csum_en(cfg_csum_en), .cfg_vxlan_en(cfg_vxlan_en), .cfg_rss_key(cfg_rss_key),
    .tok_valid(tok_valid), .tok(tok));

  wire                   dec_in_valid;
  wire [`SFP_DC_W-1:0]   dec_in;
  wire                   ev_parse_err, ev_parse_unsupp, ev_parse_frag, cls_busy;
  sf_pkt_classifier #(.NQ(NQ), .NR(NUM_RULES), .ENABLE_REWRITE(ENABLE_REWRITE)) u_cls (
    .clk(clk), .rst_n(rst_n), .tok_valid(tok_valid), .tok(tok),
    .rule_flat(rule_flat), .act_flat(act_flat), .rl_eff_valid(rl_eff_valid), .rl_scoped(rl_scoped),
    .rl_sc_vidv(rl_sc_vidv), .rl_sc_vid(rl_sc_vid), .rl_sc_vniv(rl_sc_vniv), .rl_sc_vni(rl_sc_vni),
    .cfg_malformed_act(cfg_malformed_act), .cfg_unsupp_act(cfg_unsupp_act), .cfg_frag_act(cfg_frag_act),
    .cfg_def_verdict(cfg_def_verdict), .cfg_def_setq(cfg_def_setq), .cfg_def_qid(cfg_def_qid), .cfg_def_tc(cfg_def_tc),
    .cfg_tc_src(cfg_tc_src), .cfg_tc_qmap(cfg_tc_qmap),
    .dec_valid(dec_in_valid), .dec(dec_in),
    .ev_parse_err(ev_parse_err), .ev_parse_unsupp(ev_parse_unsupp), .ev_parse_frag(ev_parse_frag), .busy(cls_busy));

  wire [`SFP_DC_W-1:0] dec_rd;
  wire                 dec_empty, dec_full;
  wire [$clog2(DEC_DEPTH):0] dec_count;
  sf_pkt_fifo #(.WIDTH(`SFP_DC_W), .DEPTH(DEC_DEPTH), .RAM(FIFO_RAM)) u_dec (
    .clk(clk), .rst_n(rst_n),
    .push(dec_in_valid), .wdata(dec_in),
    .pop(dec_pop), .rdata(dec_rd),
    .full(dec_full), .empty(dec_empty), .overflow(), .underflow(), .count(dec_count));

  // ---------------------------------------------------------------------------------------------------
  // dispatcher + queues
  // ---------------------------------------------------------------------------------------------------
  wire [NQ:0]      q_wr_beat, q_wr_commit, q_wr_abort, q_space_ok, q_pkt_ok;
  wire [DW-1:0]    wr_data;
  wire [DWB-1:0]   wr_keep;
  wire             wr_last;
  wire [DESC_W-1:0] wr_desc;
  wire             ev_end, ev_commit, ev_drop, ev_to_mgmt, ev_ttl, ev_rewrote, ev_rule_cnt, ev_lat_valid;
  wire [15:0]      ev_len;
  wire [3:0]       ev_reason;
  wire [4:0]       ev_q;
  wire [7:0]       ev_rule_idx;
  wire [31:0]      ev_lat;

  sf_pkt_dispatch #(.DW(DW), .NQ(NQ), .SRC_W(SRC_W), .META_W(META_W), .ENABLE_REWRITE(ENABLE_REWRITE)) u_disp (
    .clk(clk), .rst_n(rst_n), .now(now),
    .d_valid(!dly_empty), .d_data(dly_rd[0 +: DW]), .d_keep(dly_rd[DW +: DWB]), .d_last(dly_rd[DW + DWB]),
    .d_err(dly_rd[DW + DWB + 1]), .d_pop(d_pop),
    .dec_valid(!dec_empty), .dec(dec_rd), .sb_valid(!sb_empty), .sb(sb_rd), .dec_pop(dec_pop),
    .cfg_min_len(cfg_min_len), .cfg_max_len(cfg_max_len), .cfg_qdrop(cfg_qdrop),
    .q_wr_beat(q_wr_beat), .q_wr_commit(q_wr_commit), .q_wr_abort(q_wr_abort),
    .wr_data(wr_data), .wr_keep(wr_keep), .wr_last(wr_last), .wr_desc(wr_desc),
    .q_space_ok(q_space_ok), .q_pkt_ok(q_pkt_ok),
    .ev_end(ev_end), .ev_len(ev_len), .ev_commit(ev_commit), .ev_drop(ev_drop), .ev_reason(ev_reason), .ev_q(ev_q),
    .ev_to_mgmt(ev_to_mgmt), .ev_ttl(ev_ttl), .ev_rewrote(ev_rewrote), .ev_rule_cnt(ev_rule_cnt),
    .ev_rule_idx(ev_rule_idx), .ev_lat_valid(ev_lat_valid), .ev_lat(ev_lat));

  wire [NQ-1:0]          qv, qlast, qpop;
  wire [NQ*DW-1:0]       qdata;
  wire [NQ*DWB-1:0]      qkeep;
  wire [NQ*PCW-1:0]      qpcnt;
  wire [NQ*16-1:0]       qlen0, qlen1, qlen2;
  wire [NQ*DESC_W-1:0]   qdesc0;
  wire [NQ*($clog2(QDEPTH)+1)-1:0] qocc_beats;

  genvar gq;
  generate
    for (gq = 0; gq < NQ; gq = gq + 1) begin : g_q
      wire [DESC_W-1:0] d1, d2;
      sf_pkt_queue #(.DW(DW), .DEPTH_BEATS(QDEPTH), .PKT_DEPTH(PKT_DEPTH), .DESC_W(DESC_W)) u_q (
        .clk(clk), .rst_n(rst_n),
        .wr_beat(q_wr_beat[gq]), .wr_data(wr_data), .wr_keep(wr_keep), .wr_last(wr_last),
        .wr_commit(q_wr_commit[gq]), .wr_desc(wr_desc), .wr_abort(q_wr_abort[gq]),
        .wr_space_ok(q_space_ok[gq]), .wr_pkt_ok(q_pkt_ok[gq]),
        .rd_valid(qv[gq]), .rd_data(qdata[gq*DW +: DW]), .rd_keep(qkeep[gq*DWB +: DWB]), .rd_last(qlast[gq]),
        .rd_pop(qpop[gq]), .pkt_cnt(qpcnt[gq*PCW +: PCW]),
        .desc0(qdesc0[gq*DESC_W +: DESC_W]), .desc1(d1), .desc2(d2),
        .occ_beats(qocc_beats[gq*($clog2(QDEPTH)+1) +: ($clog2(QDEPTH)+1)]));
      assign qlen0[gq*16 +: 16] = qdesc0[gq*DESC_W +: 16];
      assign qlen1[gq*16 +: 16] = d1[15:0];
      assign qlen2[gq*16 +: 16] = d2[15:0];
      assign q_occ_bytes[gq*32 +: 32] = 32'(qocc_beats[gq*($clog2(QDEPTH)+1) +: ($clog2(QDEPTH)+1)]) * 32'(DWB);
    end
  endgenerate

  // management queue
  wire [DESC_W-1:0] mq_d0, mq_d1, mq_d2;
  wire              mq_rv, mq_rl;
  wire [DW-1:0]     mq_rdata;
  wire [DWB-1:0]    mq_rkeep;
  wire [PCW-1:0]    mq_pc;
  wire [$clog2(MQDEPTH):0] mq_occ;
  wire              mq_pop = mq_rv && x_ready;
  sf_pkt_queue #(.DW(DW), .DEPTH_BEATS(MQDEPTH), .PKT_DEPTH(PKT_DEPTH), .DESC_W(DESC_W)) u_mq (
    .clk(clk), .rst_n(rst_n),
    .wr_beat(q_wr_beat[NQ]), .wr_data(wr_data), .wr_keep(wr_keep), .wr_last(wr_last),
    .wr_commit(q_wr_commit[NQ]), .wr_desc(wr_desc), .wr_abort(q_wr_abort[NQ]),
    .wr_space_ok(q_space_ok[NQ]), .wr_pkt_ok(q_pkt_ok[NQ]),
    .rd_valid(mq_rv), .rd_data(mq_rdata), .rd_keep(mq_rkeep), .rd_last(mq_rl),
    .rd_pop(mq_pop), .pkt_cnt(mq_pc), .desc0(mq_d0), .desc1(mq_d1), .desc2(mq_d2), .occ_beats(mq_occ));

  assign x_valid  = mq_rv;
  assign x_data   = mq_rdata;
  assign x_keep   = mq_rkeep;
  assign x_last   = mq_rl;
  assign x_len    = mq_d0[15:0];
  assign x_reason = mq_d0[19 +: 4];
  assign x_tc     = mq_d0[16 +: 3];
  assign x_hash   = mq_d0[55 +: 32];
  assign x_src    = mq_d0[87 +: SRC_W];
  assign x_meta   = mq_d0[87 + SRC_W +: META_W];

  // ---------------------------------------------------------------------------------------------------
  // scheduler
  // ---------------------------------------------------------------------------------------------------
  wire              sc_sop, sc_idle;
  wire [4:0]        sc_sel;
  wire [DESC_W-1:0] sc_desc;
  sf_pkt_sched #(.DW(DW), .NQ(NQ), .PCW(PCW), .DESC_W(DESC_W)) u_sched (
    .clk(clk), .rst_n(rst_n),
    .cfg_mode(cfg_sched_mode), .cfg_starve(cfg_starve), .cfg_quant(cfg_quant), .cfg_rl_period(cfg_rl_period),
    .q_prio(q_prio), .q_weight(q_weight), .q_rl_inc(q_rl_inc), .q_rl_burst(q_rl_burst),
    .qv(qv), .qdata(qdata), .qkeep(qkeep), .qlast(qlast), .qpop(qpop), .qpcnt(qpcnt),
    .qlen0(qlen0), .qlen1(qlen1), .qlen2(qlen2), .qdesc0(qdesc0),
    .m_valid(m_valid), .m_ready(m_ready), .m_data(m_data), .m_keep(m_keep), .m_last(m_last),
    .m_sop(sc_sop), .m_sel(sc_sel), .m_desc(sc_desc), .idle(sc_idle));

  assign m_err   = 1'b0;
  assign m_queue = sc_sel[3:0];
  assign m_len   = sc_desc[15:0];
  assign m_tc    = sc_desc[16 +: 3];
  assign m_hash  = sc_desc[55 +: 32];
  assign m_src   = sc_desc[87 +: SRC_W];
  assign m_meta  = sc_desc[87 + SRC_W +: META_W];

  // ---------------------------------------------------------------------------------------------------
  // status
  // ---------------------------------------------------------------------------------------------------
  reg all_q_empty;
  always_comb begin
    all_q_empty = 1'b1;
    for (int i = 0; i < NQ; i++) if (qocc_beats[i*($clog2(QDEPTH)+1) +: ($clog2(QDEPTH)+1)] != 0) all_q_empty = 1'b0;
  end
  assign st_idle     = (admit_cnt == '0) && !in_pkt && all_q_empty && sc_idle && !cls_busy;
  assign st_inflight = 8'(admit_cnt);
  assign idle        = st_idle;

  // ---------------------------------------------------------------------------------------------------
  // statistics
  // ---------------------------------------------------------------------------------------------------
  generate
    if (ENABLE_PERF) begin : g_perf
      reg [`SFP_NSLOT-1:0]    cnt_evt;
      reg [`SFP_NSLOT*32-1:0] cnt_val;
      wire                    m_hs   = m_valid && m_ready;
      wire                    x_hs   = x_valid && x_ready;
      wire [15:0]             rx_b   = popcnt_f(i_keep);
      wire [15:0]             m_b    = popcnt_f(m_keep);
      wire [15:0]             x_b    = popcnt_f(x_keep);
      wire [31:0]             lat_e2e = now - sc_desc[23 +: 32];
      wire                    e2e_v  = m_hs && sc_sop;
      wire [31:0]             lat_p_c = (ev_lat > 32'h000FFFFF) ? 32'h000FFFFF : ev_lat;
      wire [31:0]             lat_e_c = (lat_e2e > 32'h000FFFFF) ? 32'h000FFFFF : lat_e2e;
      wire [NQ-1:0]           sel_oh;
      for (gq = 0; gq < NQ; gq = gq + 1) begin : g_oh
        assign sel_oh[gq] = (sc_sel == 5'(gq));
      end

      always_comb begin
        cnt_evt = '0;
        cnt_val = '0;
        for (int sl = 0; sl < CI_NSLOT; sl++) cnt_val[sl*32 +: 32] = 32'd1;   // default increment = 1 per event
        cnt_evt[CI_RX_PKTS]   = acc && i_last;                 cnt_val[CI_RX_PKTS*32 +: 32]   = 32'd1;
        cnt_evt[CI_RX_BYTES]  = acc;                           cnt_val[CI_RX_BYTES*32 +: 32]  = {16'd0, rx_b};
        cnt_evt[CI_FWD_PKTS]  = m_hs && m_last;                cnt_val[CI_FWD_PKTS*32 +: 32]  = 32'd1;
        cnt_evt[CI_FWD_BYTES] = m_hs;                          cnt_val[CI_FWD_BYTES*32 +: 32] = {16'd0, m_b};
        cnt_evt[CI_MGMT_PKTS] = x_hs && x_last;                cnt_val[CI_MGMT_PKTS*32 +: 32] = 32'd1;
        cnt_evt[CI_MGMT_BYTES] = x_hs;                         cnt_val[CI_MGMT_BYTES*32 +: 32] = {16'd0, x_b};
        cnt_evt[CI_DROP_PKTS] = ev_drop;                       cnt_val[CI_DROP_PKTS*32 +: 32] = 32'd1;
        cnt_evt[CI_DROP_BYTES] = ev_drop;                      cnt_val[CI_DROP_BYTES*32 +: 32] = {16'd0, ev_len};
        cnt_evt[CI_DROP_MACERR]   = ev_drop && (ev_reason == 4'(DR_MACERR));
        cnt_evt[CI_DROP_KEEP]     = ev_drop && (ev_reason == 4'(DR_KEEP));
        cnt_evt[CI_DROP_RUNT]     = ev_drop && (ev_reason == 4'(DR_RUNT));
        cnt_evt[CI_DROP_OVERSIZE] = ev_drop && (ev_reason == 4'(DR_OVERSIZE));
        cnt_evt[CI_DROP_MALFORMED] = ev_drop && (ev_reason == 4'(DR_MALFORMED));
        cnt_evt[CI_DROP_LENMIS]   = ev_drop && (ev_reason == 4'(DR_LENMIS));
        cnt_evt[CI_DROP_UNSUPP]   = ev_drop && (ev_reason == 4'(DR_UNSUPP));
        cnt_evt[CI_DROP_FRAG]     = ev_drop && (ev_reason == 4'(DR_FRAG));
        cnt_evt[CI_DROP_RULE]     = ev_drop && (ev_reason == 4'(DR_RULE));
        cnt_evt[CI_DROP_QFULL]    = ev_drop && (ev_reason == 4'(DR_QFULL));
        cnt_evt[CI_PARSE_ERR]     = ev_parse_err;
        cnt_evt[CI_PARSE_UNSUPP]  = ev_parse_unsupp;
        cnt_evt[CI_PARSE_FRAG]    = ev_parse_frag;
        cnt_evt[CI_ING_STALL]     = s_valid && !s_ready;
        cnt_evt[CI_EGR_STALL]     = m_valid && !m_ready;
        cnt_evt[CI_EGR_BUSY]      = m_hs;
        cnt_evt[CI_CYCLES]        = 1'b1;
        cnt_evt[CI_TTL_PUNT]      = ev_ttl;
        cnt_evt[CI_REWRITE_PKTS]  = ev_rewrote;
        cnt_evt[CI_VIOL]          = ev_viol;
        cnt_evt[CI_LAT_PIPE_SUM]  = ev_lat_valid;  cnt_val[CI_LAT_PIPE_SUM*32 +: 32] = lat_p_c;
        cnt_evt[CI_LAT_PIPE_CNT]  = ev_lat_valid;  cnt_val[CI_LAT_PIPE_CNT*32 +: 32] = 32'd1;
        cnt_evt[CI_LAT_PIPE_MIN]  = ev_lat_valid;  cnt_val[CI_LAT_PIPE_MIN*32 +: 32] = ev_lat;
        cnt_evt[CI_LAT_PIPE_MAX]  = ev_lat_valid;  cnt_val[CI_LAT_PIPE_MAX*32 +: 32] = ev_lat;
        cnt_evt[CI_LAT_E2E_SUM]   = e2e_v;         cnt_val[CI_LAT_E2E_SUM*32 +: 32]  = lat_e_c;
        cnt_evt[CI_LAT_E2E_CNT]   = e2e_v;         cnt_val[CI_LAT_E2E_CNT*32 +: 32]  = 32'd1;
        cnt_evt[CI_LAT_E2E_MIN]   = e2e_v;         cnt_val[CI_LAT_E2E_MIN*32 +: 32]  = lat_e2e;
        cnt_evt[CI_LAT_E2E_MAX]   = e2e_v;         cnt_val[CI_LAT_E2E_MAX*32 +: 32]  = lat_e2e;
        cnt_evt[CI_MGMT_DROP]     = ev_drop && (ev_reason == 4'(DR_QFULL)) && (ev_q == 5'(NQ));
        cnt_evt[CI_RB_READS]      = ev_rd;
        cnt_evt[CI_RB_WRITES]     = ev_wr;
        for (int q = 0; q < NQ; q++) begin
          cnt_evt[CI_G_STRIDE + q*CI_Q_STRIDE + CQ_ENQ_PKTS]  = ev_commit && (ev_q == 5'(q));
          cnt_val[(CI_G_STRIDE + q*CI_Q_STRIDE + CQ_ENQ_PKTS)*32 +: 32] = 32'd1;
          cnt_evt[CI_G_STRIDE + q*CI_Q_STRIDE + CQ_DEQ_PKTS]  = m_hs && m_last && sel_oh[q];
          cnt_val[(CI_G_STRIDE + q*CI_Q_STRIDE + CQ_DEQ_PKTS)*32 +: 32] = 32'd1;
          cnt_evt[CI_G_STRIDE + q*CI_Q_STRIDE + CQ_DEQ_BYTES] = m_hs && sel_oh[q];
          cnt_val[(CI_G_STRIDE + q*CI_Q_STRIDE + CQ_DEQ_BYTES)*32 +: 32] = {16'd0, m_b};
          cnt_evt[CI_G_STRIDE + q*CI_Q_STRIDE + CQ_DROP_PKTS] = ev_drop && (ev_reason == 4'(DR_QFULL)) && (ev_q == 5'(q));
          cnt_val[(CI_G_STRIDE + q*CI_Q_STRIDE + CQ_DROP_PKTS)*32 +: 32] = 32'd1;
          cnt_evt[CI_G_STRIDE + q*CI_Q_STRIDE + CQ_WM_CYCLES] = (q_occ_bytes[q*32 +: 32] > q_wm[q*32 +: 32]);
          cnt_val[(CI_G_STRIDE + q*CI_Q_STRIDE + CQ_WM_CYCLES)*32 +: 32] = 32'd1;
          cnt_evt[CI_G_STRIDE + q*CI_Q_STRIDE + CQ_HWM_BYTES] = 1'b1;
          cnt_val[(CI_G_STRIDE + q*CI_Q_STRIDE + CQ_HWM_BYTES)*32 +: 32] = q_occ_bytes[q*32 +: 32];
          cnt_val[(CI_G_STRIDE + q*CI_Q_STRIDE + CQ_OCC_BYTES)*32 +: 32] = q_occ_bytes[q*32 +: 32];
        end
      end

      sf_pkt_counters #(.NQ(NQ), .NR(NUM_RULES), .CW(CW)) u_cnt (
        .clk(clk), .rst_n(rst_n), .cnt_en(cfg_cnt_en), .snap_g(snap_g), .clr_g(clr_g), .snap_r(snap_r), .clr_r(clr_r),
        .evt(cnt_evt), .val(cnt_val), .rd_idx(cnt_rd_idx), .rd_data(cnt_rd_data),
        .rule_evt(ev_rule_cnt), .rule_idx(ev_rule_idx), .rule_len(ev_len),
        .rr_idx(rr_idx), .rr_hits(rr_hits), .rr_bytes(rr_bytes));
    end else begin : g_noperf
      assign cnt_rd_data = '0;
      assign rr_hits     = '0;
      assign rr_bytes    = '0;
    end
  endgenerate
endmodule

`default_nettype wire
