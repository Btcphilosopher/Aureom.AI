// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_parser -- streaming header capture + feed-forward parse pipeline
//
// Contract
//   * Taps the accepted ingress beats (acc_*).  Captures the first WIN = ceil(HDR_CAP_BYTES/(DW/8))*(DW/8)
//     bytes of every packet ("header window") and emits ONE token per packet when the window is complete
//     or the packet ends, whichever comes first.  Byte 0 of the frame = acc_data[7:0] of beat 0.
//   * The pipeline has NO back-pressure and initiation interval 1: a new token may enter every cycle.
//     Flow control is done upstream by limiting packets in flight (see silicaflux_packet_engine).
//   * Bytes beyond the received length read as 0; every field read is bounds-checked against `avail`
//     (bytes actually received, capped at WIN) -- the parser never uses a byte that was not on the wire.
//   * Bounded policy: Ethernet II, up to 2 VLAN tags (TPIDs configurable), IPv4 (IHL 5..15, options skipped
//     by IHL), IPv6 with up to MAX_EXT extension headers (HBH 0, Routing 43, Dest 60, Fragment 44, AH 51)
//     inside the window, TCP, UDP, optional VXLAN VNI extraction.  Anything else is reported through the
//     token's `unsupp` code (never silently mis-parsed).  Malformed headers set `perr`.
//   * Fragments (IPv4 MF/offset!=0, any IPv6 Fragment header) are classified on L3 fields only
//     (l4_type = NONE, ports/flags = 0).
//   * Pipeline depth after the accept of the beat that completes the window: 6 + NS cycles (NS=1 for
//     MAX_EXT<=2*EXT_STEP).  See docs/PARSER_POLICY.md.
// Classification: SYNTHESIZABLE (flat-vector SV subset accepted by Yosys 0.33 and Verilator 5)
// =============================================================================
`include "sf_pkt_macros.svh"
`default_nettype none

module sf_pkt_parser #(
  parameter int DW            = 128,
  parameter int HDR_CAP_BYTES = 128,
  parameter int MAX_EXT       = 4,
  parameter int EXT_STEP      = 2,
  parameter bit ENABLE_VXLAN  = 1'b1,
  parameter bit ENABLE_RSS    = 1'b1,
  parameter bit RSS_PROG_KEY  = 1'b1   // 0: fixed Microsoft key (constant-folds the Toeplitz network to ~1/4 of the area)
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // accepted beats (tap)
  input  wire logic                acc_valid,
  input  wire logic [DW-1:0]       acc_data,
  input  wire logic [DW/8-1:0]     acc_keep,
  input  wire logic                acc_last,
  input  wire logic [7:0]          acc_src,
  // static-ish configuration (not packet-atomic when changed under traffic)
  input  wire logic [15:0]         cfg_tpid0,
  input  wire logic [15:0]         cfg_tpid1,
  input  wire logic [15:0]         cfg_vxlan_port,
  input  wire logic                cfg_csum_en,
  input  wire logic                cfg_vxlan_en,
  input  wire logic [319:0]        cfg_rss_key,
  // token
  output logic                     tok_valid,
  output logic [`SFP_TK_W-1:0]     tok
);
  `include "sf_pkt_defs.svh"

  localparam int DWB        = DW / 8;
  localparam int HDR_BEATS  = (HDR_CAP_BYTES + DWB - 1) / DWB;
  localparam int WIN        = HDR_BEATS * DWB;
  localparam int WB         = WIN * 8;
  localparam int BCW        = $clog2(HDR_BEATS + 1);
  localparam int NEXT_STG   = (MAX_EXT + EXT_STEP - 1) / EXT_STEP;
  localparam int NS         = (NEXT_STG > 1) ? (NEXT_STG - 1) : 1;

  generate
    if (WIN > 255)  begin : g_chk_win  initial $error("sf_pkt_parser: header window must be <= 255 bytes"); end
    if (WIN < 128)  begin : g_chk_win2 initial $error("sf_pkt_parser: header window must be >= 128 bytes"); end
    if (DW % 8 != 0) begin : g_chk_dw  initial $error("sf_pkt_parser: DW must be a multiple of 8"); end
    if (MAX_EXT % EXT_STEP != 0) begin : g_chk_ext initial $error("sf_pkt_parser: MAX_EXT must be a multiple of EXT_STEP"); end
  endgenerate

  // extras flag bit positions
  localparam int F_ETH = 0, F_VOVF = 1, F_EVER = 2, F_EIHL = 3, F_EL3T = 4, F_ETOT = 5, F_DGK = 6,
                 F_EL4T = 7, F_EDOFF = 8, F_EL4L = 9, F_UWIN = 10, F_LIMIT = 11;

  // ---------------------------------------------------------------------------
  // helper functions
  // ---------------------------------------------------------------------------
  function automatic [15:0] popcnt_f(input [DWB-1:0] k);
    integer i;
    reg [15:0] c;
    begin
      c = 16'd0;
      for (i = 0; i < DWB; i = i + 1) c = c + {15'd0, k[i]};
      popcnt_f = c;
    end
  endfunction

  // byte at constant/dynamic position (0 beyond window)
  function automatic [7:0] wbd(input [WB-1:0] w, input [9:0] idx);
    begin
      if (32'(idx) < WIN) wbd = w[8*idx +: 8];
      else           wbd = 8'h00;
    end
  endfunction

  // byte at (L3 offset by vlan count) + rel
  function automatic [7:0] l3b(input [WB-1:0] w, input [1:0] vc, input integer rel);
    begin
      case (vc)
        2'd0:    l3b = wbd(w, 10'(14 + rel));
        2'd1:    l3b = wbd(w, 10'(18 + rel));
        default: l3b = wbd(w, 10'(22 + rel));
      endcase
    end
  endfunction

  function automatic is_ext_nh(input [7:0] nh);
    begin
      is_ext_nh = (nh == 8'd0) || (nh == 8'd43) || (nh == 8'd60) || (nh == 8'd44) || (nh == 8'd51);
    end
  endfunction

  // IPv6 extension-header step.  state = {off[7:0], nh[7:0], done, frag, nonfirst, trunc, uwin}
  // `off` is always EVEN (l3_off in {14,18,22}; 40, 8, (len+1)*8 and (len+2)*4 are even), so the four bytes at
  // {off, off+1, off+2, off+3} are fetched with ONE word-aligned shift of the window (one 32-bit read per step).
  function automatic [20:0] ext_step(input [WB-1:0] w, input [7:0] av, input eop, input [20:0] s);
    reg [7:0] off, nh, nh2, ln;
    reg done, frag, nf, tr, uw;
    reg [11:0] hl, endo;   // 12 bits: (255+1)*8 = 2048 must not wrap
    reg [15:0] fo;
    reg [WB-1:0] sh;
    begin
      {off, nh, done, frag, nf, tr, uw} = s;
      sh  = w >> {off[7:1], 4'b0000};
      nh2 = sh[7:0];
      ln  = sh[15:8];
      fo  = {sh[23:16], sh[31:24]};
      if (!done && !tr && !uw) begin
        if (!is_ext_nh(nh)) begin
          done = 1'b1;
        end else if ({2'b00, off} + 10'd2 > {2'b00, av}) begin
          if (eop) tr = 1'b1; else uw = 1'b1;
        end else begin
          if (nh == 8'd44)      hl = 12'd8;
          else if (nh == 8'd51) hl = ({4'b0000, ln} + 12'd2) << 2;
          else                  hl = ({4'b0000, ln} + 12'd1) << 3;
          endo = {4'b0000, off} + hl;
          if (endo > {4'b0000, av}) begin
            if (eop) tr = 1'b1; else uw = 1'b1;
          end else begin
            if (nh == 8'd44) begin
              frag = 1'b1;
              if (fo[15:3] != 13'd0) nf = 1'b1;
            end
            off = endo[7:0];   // endo <= av <= 255 here
            nh  = nh2;
          end
        end
      end
      ext_step = {off, nh, done, frag, nf, tr, uw};
    end
  endfunction

  // ---------------------------------------------------------------------------
  // P0: header capture
  // ---------------------------------------------------------------------------
  reg  [DW-1:0]  winr [0:HDR_BEATS-1];
  reg  [BCW-1:0] cap_beat;
  reg  [7:0]     cap_src;
  wire           sop     = (cap_beat == '0);
  wire           in_win  = (cap_beat < BCW'(HDR_BEATS));
  reg  [DW-1:0]  bm;
  reg  [WB-1:0]  asm_w;
  wire [15:0]    nb      = acc_last ? popcnt_f(acc_keep) : 16'(DWB);
  wire [15:0]    avail_f = 16'(cap_beat) * 16'(DWB) + nb;
  wire           emit    = acc_valid && in_win && (acc_last || (cap_beat == BCW'(HDR_BEATS - 1)));

  always_comb begin
    for (int k = 0; k < DWB; k++) bm[8*k +: 8] = acc_keep[k] ? acc_data[8*k +: 8] : 8'h00;
    for (int j = 0; j < HDR_BEATS; j++) begin
      if (BCW'(j) < cap_beat)       asm_w[j*DW +: DW] = winr[j];
      else if (BCW'(j) == cap_beat) asm_w[j*DW +: DW] = bm;
      else                          asm_w[j*DW +: DW] = {DW{1'b0}};
    end
  end

  genvar gj;
  generate
    for (gj = 0; gj < HDR_BEATS; gj = gj + 1) begin : g_win
      always_ff @(posedge clk) begin
        if (acc_valid && (cap_beat == BCW'(gj))) winr[gj] <= bm;
      end
    end
  endgenerate

  reg            p0_v;
  reg [WB-1:0]   p0_win;
  reg [7:0]      p0_avail;
  reg            p0_eop;
  reg [7:0]      p0_src;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cap_beat <= '0;
      cap_src  <= 8'd0;
      p0_v     <= 1'b0;
    end else begin
      p0_v <= emit;
      if (acc_valid) begin
        if (sop) cap_src <= acc_src;
        if (acc_last)    cap_beat <= '0;
        else if (in_win) cap_beat <= cap_beat + 1'b1;
      end
    end
  end

  always_ff @(posedge clk) begin
    p0_win   <= asm_w;
    p0_avail <= avail_f[7:0];
    p0_eop   <= acc_last;
    p0_src   <= sop ? acc_src : cap_src;
  end

  // ---------------------------------------------------------------------------
  // P1: Ethernet + VLAN
  // ---------------------------------------------------------------------------
  reg [TK_W-1:0] s1_t;
  reg [15:0]     s1_xf;
  reg [15:0]     et0, et1, et2, tci0, tci1, etype;
  reg            t0, t1, t2;
  reg [1:0]      vcnt;

  always_comb begin
    et0  = {wbd(p0_win, 10'd12), wbd(p0_win, 10'd13)};
    et1  = {wbd(p0_win, 10'd16), wbd(p0_win, 10'd17)};
    et2  = {wbd(p0_win, 10'd20), wbd(p0_win, 10'd21)};
    tci0 = {wbd(p0_win, 10'd14), wbd(p0_win, 10'd15)};
    tci1 = {wbd(p0_win, 10'd18), wbd(p0_win, 10'd19)};
    t0   = (et0 == cfg_tpid0) || (et0 == cfg_tpid1);
    t1   = t0 && ((et1 == cfg_tpid0) || (et1 == cfg_tpid1));
    t2   = t1 && ((et2 == cfg_tpid0) || (et2 == cfg_tpid1));
    vcnt = t0 ? (t1 ? 2'd2 : 2'd1) : 2'd0;
    etype = t1 ? et2 : (t0 ? et1 : et0);

    s1_t = {TK_W{1'b0}};
    s1_t[TK_EOP_SEEN_LSB +: TK_EOP_SEEN_W] = p0_eop;
    s1_t[TK_AVAIL_LSB +: TK_AVAIL_W]       = p0_avail;
    s1_t[TK_SRC_ID_LSB +: TK_SRC_ID_W]     = p0_src;
    s1_t[TK_DMAC_LSB +: TK_DMAC_W]         = {wbd(p0_win, 10'd0), wbd(p0_win, 10'd1), wbd(p0_win, 10'd2),
                                              wbd(p0_win, 10'd3), wbd(p0_win, 10'd4), wbd(p0_win, 10'd5)};
    s1_t[TK_SMAC_LSB +: TK_SMAC_W]         = {wbd(p0_win, 10'd6), wbd(p0_win, 10'd7), wbd(p0_win, 10'd8),
                                              wbd(p0_win, 10'd9), wbd(p0_win, 10'd10), wbd(p0_win, 10'd11)};
    s1_t[TK_ETHERTYPE_LSB +: TK_ETHERTYPE_W] = etype;
    s1_t[TK_VLAN_CNT_LSB +: TK_VLAN_CNT_W]   = vcnt;
    s1_t[TK_VLAN_VID_LSB +: TK_VLAN_VID_W]   = t0 ? tci0[11:0] : 12'd0;
    s1_t[TK_VLAN_PCP_LSB +: TK_VLAN_PCP_W]   = t0 ? tci0[15:13] : 3'd0;
    s1_t[TK_VLAN_DEI_LSB +: TK_VLAN_DEI_W]   = t0 ? tci0[12] : 1'b0;
    s1_t[TK_VLAN_VID2_LSB +: TK_VLAN_VID2_W] = t1 ? tci1[11:0] : 12'd0;
    s1_t[TK_L3_TYPE_LSB +: TK_L3_TYPE_W]     = (etype == 16'h0800) ? 2'(L3_IPV4) :
                                               (etype == 16'h86DD) ? 2'(L3_IPV6) : 2'(L3_NONE);
    s1_t[TK_L3_OFF_LSB +: TK_L3_OFF_W]       = 8'd14 + {4'd0, vcnt, 2'b00};
    s1_xf = 16'd0;
    s1_xf[F_ETH]  = (p0_avail < 8'd14) || (t0 && (p0_avail < 8'd18)) || (t1 && (p0_avail < 8'd22));
    s1_xf[F_VOVF] = t2;
  end

  reg            r1_v;
  reg [WB-1:0]   r1_w;
  reg [TK_W-1:0] r1_t;
  reg [15:0]     r1_xf;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) r1_v <= 1'b0;
    else        r1_v <= p0_v;
  end
  always_ff @(posedge clk) begin
    r1_w  <= p0_win;
    r1_t  <= s1_t;
    r1_xf <= s1_xf;
  end

  // ---------------------------------------------------------------------------
  // P2: L3 decode (IPv4 / IPv6), IPv4 checksum partial sums, ext-walk init + first steps
  // ---------------------------------------------------------------------------
  reg [TK_W-1:0] s2_t;
  reg [15:0]     s2_xf;
  reg [20:0]     s2_es;
  reg [143:0]    s2_cs;

  reg  [1:0]  vc2;
  reg  [7:0]  l3off2, av2;
  reg  [1:0]  l3t2;
  reg         eop2, v4, v6;
  reg  [7:0]  vihl, tos, ttl4, proto4, nh0, hlim;
  reg  [3:0]  ihl;
  reg  [5:0]  hlen4;
  reg  [15:0] tl, ff, csum4, plen;
  reg  [127:0] sip6, dip6;
  reg  [7:0]  b0v6, b1v6;
  reg  [4:0]  ihl2;
  reg  [9:0]  tmp10;
  reg  [16:0] dg17;
  reg  [20:0] es_init;
  reg  [16*30-1:0] wsum;
  reg  [18*8-1:0]  gsum;

  always_comb begin
    vc2    = r1_t[TK_VLAN_CNT_LSB +: TK_VLAN_CNT_W];
    l3off2 = r1_t[TK_L3_OFF_LSB +: TK_L3_OFF_W];
    l3t2   = r1_t[TK_L3_TYPE_LSB +: TK_L3_TYPE_W];
    av2    = r1_t[TK_AVAIL_LSB +: TK_AVAIL_W];
    eop2   = r1_t[TK_EOP_SEEN_LSB];
    v4     = (l3t2 == 2'(L3_IPV4)) && !r1_xf[F_ETH];
    v6     = (l3t2 == 2'(L3_IPV6)) && !r1_xf[F_ETH];

    vihl   = l3b(r1_w, vc2, 0);
    ihl    = vihl[3:0];
    hlen4  = {ihl, 2'b00};
    tos    = l3b(r1_w, vc2, 1);
    tl     = {l3b(r1_w, vc2, 2), l3b(r1_w, vc2, 3)};
    ff     = {l3b(r1_w, vc2, 6), l3b(r1_w, vc2, 7)};
    ttl4   = l3b(r1_w, vc2, 8);
    proto4 = l3b(r1_w, vc2, 9);
    csum4  = {l3b(r1_w, vc2, 10), l3b(r1_w, vc2, 11)};
    nh0    = l3b(r1_w, vc2, 6);
    hlim   = l3b(r1_w, vc2, 7);
    plen   = {l3b(r1_w, vc2, 4), l3b(r1_w, vc2, 5)};
    b0v6   = l3b(r1_w, vc2, 0);
    b1v6   = l3b(r1_w, vc2, 1);
    ihl2   = {ihl, 1'b0};
    for (int i = 0; i < 16; i++) begin
      sip6[8*(15-i) +: 8] = l3b(r1_w, vc2, 8 + i);
      dip6[8*(15-i) +: 8] = l3b(r1_w, vc2, 24 + i);
    end

    dg17  = 17'd0;
    tmp10 = 10'd0;
    s2_t  = r1_t;
    s2_xf = r1_xf;
    es_init = {8'd0, 8'd0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0};

    if (v4) begin
      s2_t[TK_IP_W0_LSB +: TK_IP_W0_W]       = {vihl, tos};
      s2_t[TK_IP_TC_LSB +: TK_IP_TC_W]       = tos;
      s2_t[TK_IP_TTL_LSB +: TK_IP_TTL_W]     = ttl4;
      s2_t[TK_IP_CSUM_LSB +: TK_IP_CSUM_W]   = csum4;
      s2_t[TK_IP_FRAG_LSB +: TK_IP_FRAG_W]   = ff[13] || (ff[12:0] != 13'd0);
      s2_t[TK_IP_NONFIRST_LSB +: TK_IP_NONFIRST_W] = (ff[12:0] != 13'd0);
      s2_t[TK_SIP_LSB +: TK_SIP_W]           = {96'd0, l3b(r1_w, vc2, 12), l3b(r1_w, vc2, 13), l3b(r1_w, vc2, 14), l3b(r1_w, vc2, 15)};
      s2_t[TK_DIP_LSB +: TK_DIP_W]           = {96'd0, l3b(r1_w, vc2, 16), l3b(r1_w, vc2, 17), l3b(r1_w, vc2, 18), l3b(r1_w, vc2, 19)};
      dg17 = {1'b0, tl} + {9'd0, l3off2};
      s2_t[TK_NEED_LEN_LSB +: TK_NEED_LEN_W] = dg17[16] ? 16'hFFFF : dg17[15:0];
      s2_xf[F_EVER] = (vihl[7:4] != 4'd4);
      s2_xf[F_EIHL] = (ihl < 4'd5);
      tmp10 = {2'b00, l3off2} + 10'd20;
      s2_xf[F_EL3T] = ({2'b00, av2} < tmp10);
      tmp10 = {2'b00, l3off2} + {4'd0, hlen4};
      if (!s2_xf[F_EIHL] && ({2'b00, av2} < tmp10)) s2_xf[F_EL3T] = 1'b1;
      s2_xf[F_ETOT] = !s2_xf[F_EIHL] && (tl < {10'd0, hlen4});
      s2_xf[F_DGK]  = 1'b1;
      es_init = {l3off2 + {2'd0, hlen4}, proto4, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0};
    end else if (v6) begin
      s2_t[TK_IP_W0_LSB +: TK_IP_W0_W]       = {b0v6, b1v6};
      s2_t[TK_IP_TC_LSB +: TK_IP_TC_W]       = {b0v6[3:0], b1v6[7:4]};
      s2_t[TK_IP_TTL_LSB +: TK_IP_TTL_W]     = hlim;
      s2_t[TK_SIP_LSB +: TK_SIP_W]           = sip6;
      s2_t[TK_DIP_LSB +: TK_DIP_W]           = dip6;
      dg17 = {1'b0, (plen != 16'd0) ? plen : 16'd0} + {9'd0, l3off2} + 17'd40;
      s2_t[TK_NEED_LEN_LSB +: TK_NEED_LEN_W] = dg17[16] ? 16'hFFFF : dg17[15:0];
      s2_xf[F_EVER] = (b0v6[7:4] != 4'd6);
      tmp10 = {2'b00, l3off2} + 10'd40;
      s2_xf[F_EL3T] = ({2'b00, av2} < tmp10);
      s2_xf[F_DGK]  = (plen != 16'd0);
      es_init = {l3off2 + 8'd40, nh0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0};
      for (int e = 0; e < EXT_STEP; e++) es_init = ext_step(r1_w, av2, eop2, es_init);
    end

    // IPv4 checksum: 30 candidate words, masked by header length, summed in 8 groups
    wsum = {16*30{1'b0}};
    for (int j = 0; j < 30; j++) begin
      if (v4 && (5'(j) < ihl2)) wsum[16*j +: 16] = {l3b(r1_w, vc2, 2*j), l3b(r1_w, vc2, 2*j + 1)};
    end
    gsum = {18*8{1'b0}};
    for (int g = 0; g < 7; g++)
      gsum[18*g +: 18] = {2'b00, wsum[16*(4*g) +: 16]} + {2'b00, wsum[16*(4*g+1) +: 16]} +
                         {2'b00, wsum[16*(4*g+2) +: 16]} + {2'b00, wsum[16*(4*g+3) +: 16]};
    gsum[18*7 +: 18] = {2'b00, wsum[16*28 +: 16]} + {2'b00, wsum[16*29 +: 16]};
    s2_cs = gsum;
    s2_es = es_init;
  end

  // stage registers 0..NS (index 0 = output of P2)
  reg [NS:0]              cv;
  reg [(NS+1)*WB-1:0]     cw;
  reg [(NS+1)*TK_W-1:0]   ct;
  reg [(NS+1)*16-1:0]     cxf;
  reg [(NS+1)*21-1:0]     ces;
  reg [143:0]             ccs;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cv[0] <= 1'b0;
    else        cv[0] <= r1_v;
  end
  always_ff @(posedge clk) begin
    cw[0 +: WB]    <= r1_w;
    ct[0 +: TK_W]  <= s2_t;
    cxf[0 +: 16]   <= s2_xf;
    ces[0 +: 21]   <= s2_es;
    ccs            <= s2_cs;
  end

  generate
    for (gj = 1; gj <= NS; gj = gj + 1) begin : g_ext
      wire [WB-1:0]   iw  = cw[(gj-1)*WB +: WB];
      wire [TK_W-1:0] it  = ct[(gj-1)*TK_W +: TK_W];
      wire [15:0]     ixf = cxf[(gj-1)*16 +: 16];
      wire [20:0]     ies = ces[(gj-1)*21 +: 21];
      wire [7:0]      iav = it[TK_AVAIL_LSB +: TK_AVAIL_W];
      wire            ieo = it[TK_EOP_SEEN_LSB];
      reg  [20:0]     nes;
      reg  [TK_W-1:0] nt;
      reg  [20:0]     tot;
      reg  [16:0]     f1;
      always_comb begin
        nes = ies;
        if (gj < NEXT_STG) begin
          for (int e = 0; e < EXT_STEP; e++) nes = ext_step(iw, iav, ieo, nes);
        end
        nt = it;
        nt[TK_IP_FRAG_LSB +: TK_IP_FRAG_W]         = it[TK_IP_FRAG_LSB] | nes[3];
        nt[TK_IP_NONFIRST_LSB +: TK_IP_NONFIRST_W] = it[TK_IP_NONFIRST_LSB] | nes[2];
        tot = 21'd0; f1 = 17'd0;
        if (gj == 1) begin
          tot = {3'd0, ccs[17:0]} + {3'd0, ccs[35:18]} + {3'd0, ccs[53:36]} + {3'd0, ccs[71:54]}
              + {3'd0, ccs[89:72]} + {3'd0, ccs[107:90]} + {3'd0, ccs[125:108]} + {3'd0, ccs[143:126]};
          // One end-around fold suffices: f1 <= 0x1001E < 2*0xFFFF, so f1 == 0xFFFF is the only
          // representation of a verified (all-ones) ones'-complement sum.
          f1 = {1'b0, tot[15:0]} + {12'd0, tot[20:16]};
          nt[TK_CSUM_OK_LSB +: TK_CSUM_OK_W] = (it[TK_L3_TYPE_LSB +: TK_L3_TYPE_W] == 2'(L3_IPV4)) && !ixf[F_ETH] && (f1 == 17'h0FFFF);
        end
      end
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) cv[gj] <= 1'b0;
        else        cv[gj] <= cv[gj-1];
      end
      always_ff @(posedge clk) begin
        cw[gj*WB +: WB]       <= iw;
        ct[gj*TK_W +: TK_W]   <= nt;
        cxf[gj*16 +: 16]      <= ixf;
        ces[gj*21 +: 21]      <= nes;
      end
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // P_L4: transport header decode (TCP / UDP / other), VXLAN, length consistency
  // ---------------------------------------------------------------------------
  wire [WB-1:0]   lw  = cw[NS*WB +: WB];
  wire [TK_W-1:0] lt  = ct[NS*TK_W +: TK_W];
  /* verilator lint_off UNUSEDSIGNAL */
  wire [15:0]     lxf = cxf[NS*16 +: 16];
  wire [20:0]     les = ces[NS*21 +: 21];

  reg [TK_W-1:0] s4_t;
  reg [15:0]     s4_xf;

  reg [7:0]  l_off, l_nh, l_av;
  reg        l_done, l_frag, l_nf, l_tr, l_uw, l_eop, l_limit, l_l3err, l_cand;
  reg [1:0]  l_l3t, l4t;
  reg        is_tcp, is_udp, is_oth, l4_missing, e_l4t, e_doff, e_l4l, uw2, vx_cand, vx_missing;
  reg [9:0]  need4, tmp4;
  reg [WB-1:0] shw;
  reg [127:0]  l4w;
  reg [3:0]  doff;
  reg [15:0] dg_end, ulen;
  reg [9:0]  hl_t;
  /* verilator lint_on UNUSEDSIGNAL */

  always_comb begin
    {l_off, l_nh, l_done, l_frag, l_nf, l_tr, l_uw} = les;
    l_av   = lt[TK_AVAIL_LSB +: TK_AVAIL_W];
    l_eop  = lt[TK_EOP_SEEN_LSB];
    l_l3t  = lt[TK_L3_TYPE_LSB +: TK_L3_TYPE_W];
    l_limit = !l_done && is_ext_nh(l_nh) && !l_tr && !l_uw;
    l_l3err = lxf[F_ETH] || lxf[F_EVER] || lxf[F_EIHL] || lxf[F_EL3T] || l_tr || lxf[F_ETOT] ||
              (cfg_csum_en && (l_l3t == 2'(L3_IPV4)) && !lt[TK_CSUM_OK_LSB]);
    l_cand = (l_l3t != 2'(L3_NONE)) && !l_l3err && !l_uw && !l_limit && !lt[TK_IP_FRAG_LSB];
    is_tcp = l_cand && (l_nh == 8'd6);
    is_udp = l_cand && (l_nh == 8'd17);
    is_oth = l_cand && !is_tcp && !is_udp && !((l_l3t == 2'(L3_IPV6)) && (l_nh == 8'd59));
    need4  = is_tcp ? 10'd20 : (is_udp ? 10'd8 : 10'd0);
    l4_missing = (is_tcp || is_udp) && ({2'b00, l_off} + need4 > {2'b00, l_av});
    shw    = lw >> {l_off[7:1], 4'b0000};     // l4 offset is always even (see ext_step)
    l4w    = shw[127:0];
    doff   = l4w[8*12+4 +: 4];
    ulen   = {l4w[8*4 +: 8], l4w[8*5 +: 8]};
    dg_end = lt[TK_NEED_LEN_LSB +: TK_NEED_LEN_W];
    hl_t   = {4'd0, doff, 2'b00};

    e_doff = is_tcp && !l4_missing && (doff < 4'd5);
    e_l4t  = l4_missing && l_eop;
    uw2    = l4_missing && !l_eop;
    e_l4l  = 1'b0;
    tmp4   = 10'd0;
    if (is_tcp && !l4_missing && !e_doff) begin
      tmp4 = {2'b00, l_off} + hl_t;
      if (lxf[F_DGK] && (dg_end < {6'd0, tmp4})) e_l4l = 1'b1;
      if (l_eop && ({2'b00, l_av} < tmp4))       e_l4t = 1'b1;
    end
    if (is_udp && !l4_missing) begin
      if (ulen < 16'd8) e_l4l = 1'b1;
      else if (lxf[F_DGK] && ({1'b0, dg_end} < ({1'b0, ulen} + {9'd0, l_off}))) e_l4l = 1'b1;
    end
    vx_cand = ENABLE_VXLAN && cfg_vxlan_en && is_udp && !l4_missing && !e_l4l &&
              ({l4w[8*2 +: 8], l4w[8*3 +: 8]} == cfg_vxlan_port) && (ulen >= 16'd16);
    vx_missing = vx_cand && ({2'b00, l_off} + 10'd16 > {2'b00, l_av});
    if (vx_missing && l_eop)  e_l4t = 1'b1;
    if (vx_missing && !l_eop) uw2   = 1'b1;

    l4t = is_tcp ? 2'(L4_TCP) : is_udp ? 2'(L4_UDP) : is_oth ? 2'(L4_OTHER) : 2'(L4_NONE);

    s4_t  = lt;
    s4_xf = lxf;
    s4_xf[F_EL3T]  = lxf[F_EL3T] | l_tr;
    s4_xf[F_EL4T]  = e_l4t;
    s4_xf[F_EDOFF] = e_doff;
    s4_xf[F_EL4L]  = e_l4l;
    s4_xf[F_UWIN]  = l_uw | uw2;
    s4_xf[F_LIMIT] = l_limit;
    s4_t[TK_IP_PROTO_LSB +: TK_IP_PROTO_W] = l_nh;
    s4_t[TK_L4_TYPE_LSB +: TK_L4_TYPE_W]   = (l4_missing || vx_missing) ? 2'(L4_NONE) : l4t;
    s4_t[TK_L4_OFF_LSB +: TK_L4_OFF_W]     = (l4t == 2'(L4_NONE) || l4_missing || vx_missing) ? 8'd0 : l_off;
    if (!l4_missing && !vx_missing && (is_tcp || is_udp)) begin
      s4_t[TK_SPORT_LSB +: TK_SPORT_W] = {l4w[8*0 +: 8], l4w[8*1 +: 8]};
      s4_t[TK_DPORT_LSB +: TK_DPORT_W] = {l4w[8*2 +: 8], l4w[8*3 +: 8]};
    end
    if (!l4_missing && is_tcp) s4_t[TK_TCP_FLAGS_LSB +: TK_TCP_FLAGS_W] = l4w[8*13 +: 8];
    if (vx_cand && !vx_missing) begin
      s4_t[TK_VNI_VALID_LSB +: TK_VNI_VALID_W] = l4w[8*8 + 3];
      s4_t[TK_VNI_LSB +: TK_VNI_W]             = {l4w[8*12 +: 8], l4w[8*13 +: 8], l4w[8*14 +: 8]};
    end
  end

  reg            r4_v;
  reg [TK_W-1:0] r4_t;
  reg [15:0]     r4_xf;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) r4_v <= 1'b0;
    else        r4_v <= cv[NS];
  end
  always_ff @(posedge clk) begin
    r4_t  <= s4_t;
    r4_xf <= s4_xf;
  end

  // ---------------------------------------------------------------------------
  // P_FIN: error / unsupported classification, zeroing of meaningless fields
  // ---------------------------------------------------------------------------
  reg [TK_W-1:0] sf_t;
  reg [3:0]      perr;
  reg [2:0]      unsupp;
  reg            csum_bad;

  always_comb begin
    csum_bad = cfg_csum_en && (r4_t[TK_L3_TYPE_LSB +: TK_L3_TYPE_W] == 2'(L3_IPV4)) && !r4_t[TK_CSUM_OK_LSB];
    if      (r4_xf[F_ETH])  perr = 4'(PE_ETH_TRUNC);
    else if (r4_xf[F_EVER]) perr = 4'(PE_IP_VER);
    else if (r4_xf[F_EIHL]) perr = 4'(PE_IPV4_IHL);
    else if (r4_xf[F_EL3T]) perr = 4'(PE_L3_TRUNC);
    else if (r4_xf[F_ETOT]) perr = 4'(PE_IPV4_TOTLEN);
    else if (csum_bad)      perr = 4'(PE_IPV4_CSUM);
    else if (r4_xf[F_EL4T]) perr = 4'(PE_L4_TRUNC);
    else if (r4_xf[F_EDOFF]) perr = 4'(PE_TCP_DOFF);
    else if (r4_xf[F_EL4L]) perr = 4'(PE_L4_LEN);
    else                    perr = 4'(PE_NONE);

    if (perr != 4'(PE_NONE))   unsupp = 3'(UN_NONE);
    else if (r4_xf[F_VOVF])    unsupp = 3'(UN_VLAN_OVF);
    else if (r4_xf[F_LIMIT])   unsupp = 3'(UN_EXT_LIMIT);
    else if (r4_xf[F_UWIN])    unsupp = 3'(UN_WINDOW);
    else                       unsupp = 3'(UN_NONE);

    sf_t = r4_t;
    sf_t[TK_PERR_LSB +: TK_PERR_W]     = perr;
    sf_t[TK_UNSUPP_LSB +: TK_UNSUPP_W] = unsupp;
    if (perr != 4'(PE_NONE)) begin
      sf_t[TK_IP_W0_LSB +: TK_IP_W0_W] = 16'd0;       sf_t[TK_IP_TC_LSB +: TK_IP_TC_W] = 8'd0;
      sf_t[TK_IP_TTL_LSB +: TK_IP_TTL_W] = 8'd0;      sf_t[TK_IP_PROTO_LSB +: TK_IP_PROTO_W] = 8'd0;
      sf_t[TK_IP_CSUM_LSB +: TK_IP_CSUM_W] = 16'd0;   sf_t[TK_NEED_LEN_LSB +: TK_NEED_LEN_W] = 16'd0;
      sf_t[TK_IP_FRAG_LSB +: TK_IP_FRAG_W] = 1'b0;    sf_t[TK_IP_NONFIRST_LSB +: TK_IP_NONFIRST_W] = 1'b0;
      sf_t[TK_SIP_LSB +: TK_SIP_W] = 128'd0;          sf_t[TK_DIP_LSB +: TK_DIP_W] = 128'd0;
      sf_t[TK_CSUM_OK_LSB +: TK_CSUM_OK_W] = 1'b0;
    end
    if (perr != 4'(PE_NONE) || unsupp != 3'(UN_NONE)) begin
      sf_t[TK_L4_TYPE_LSB +: TK_L4_TYPE_W] = 2'(L4_NONE); sf_t[TK_L4_OFF_LSB +: TK_L4_OFF_W] = 8'd0;
      sf_t[TK_SPORT_LSB +: TK_SPORT_W] = 16'd0;           sf_t[TK_DPORT_LSB +: TK_DPORT_W] = 16'd0;
      sf_t[TK_TCP_FLAGS_LSB +: TK_TCP_FLAGS_W] = 8'd0;
      sf_t[TK_VNI_VALID_LSB +: TK_VNI_VALID_W] = 1'b0;    sf_t[TK_VNI_LSB +: TK_VNI_W] = 24'd0;
    end
  end

  reg            r5_v;
  reg [TK_W-1:0] r5_t;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) r5_v <= 1'b0;
    else        r5_v <= r4_v;
  end
  always_ff @(posedge clk) r5_t <= sf_t;

  // ---------------------------------------------------------------------------
  // P_HASH: RSS-compatible Toeplitz hash over the 4-tuple (3-tuple fallback = addresses only)
  // ---------------------------------------------------------------------------
  wire [1:0]   h_l3t  = r5_t[TK_L3_TYPE_LSB +: TK_L3_TYPE_W];
  wire [1:0]   h_l4t  = r5_t[TK_L4_TYPE_LSB +: TK_L4_TYPE_W];
  wire         h_ip   = (h_l3t != 2'(L3_NONE)) && (r5_t[TK_PERR_LSB +: TK_PERR_W] == 4'(PE_NONE));
  wire         h_port = (h_l4t == 2'(L4_TCP)) || (h_l4t == 2'(L4_UDP));
  wire [127:0] h_sip  = r5_t[TK_SIP_LSB +: TK_SIP_W];
  wire [127:0] h_dip  = r5_t[TK_DIP_LSB +: TK_DIP_W];
  wire [31:0]  h_ports = {r5_t[TK_SPORT_LSB +: TK_SPORT_W], r5_t[TK_DPORT_LSB +: TK_DPORT_W]};
  reg  [287:0] hin;
  wire [31:0]  hval;

  always_comb begin
    hin = 288'd0;
    if (ENABLE_RSS && h_ip) begin
      if (h_l3t == 2'(L3_IPV4)) begin
        hin[287 -: 96] = {h_sip[31:0], h_dip[31:0], h_port ? h_ports : 32'd0};
      end else begin
        hin = {h_sip, h_dip, h_port ? h_ports : 32'd0};
      end
    end
  end

  localparam [319:0] MS_KEY_C = 320'h6d5a56da255b0ec24167253d43a38fb0d0ca2bcbae7b30b477cb2da38030f20c6a42b73bbeac01fa;
  sf_pkt_toeplitz u_toeplitz (.hin(hin), .key(RSS_PROG_KEY ? cfg_rss_key : MS_KEY_C), .hash(hval));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) tok_valid <= 1'b0;
    else        tok_valid <= r5_v;
  end
  always_ff @(posedge clk) begin
    tok <= r5_t;
    tok[TK_FLOW_HASH_LSB +: TK_FLOW_HASH_W] <= ENABLE_RSS ? (h_ip ? hval : 32'd0) : 32'd0;
  end

endmodule

`default_nettype wire
