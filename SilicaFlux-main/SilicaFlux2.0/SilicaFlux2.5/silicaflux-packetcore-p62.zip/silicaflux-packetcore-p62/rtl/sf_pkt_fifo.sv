// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_fifo -- first-word-fall-through FIFO, block-RAM friendly
//
//   Wrapper that selects between
//     RAM = 1 : synchronous-read dual-port RAM + prefetched output register (maps to BRAM / LUT-RAM-with-register)
//     RAM = 0 : the vendored, verified SilicaFlux `sync_fifo` (asynchronous-read memory; on an FPGA it becomes registers
//               plus a wide read mux -- fine for ASIC flows / small depths, large on FPGA)
//   Port behaviour is the same for both (FWFT: rdata valid whenever !empty; push/pop on any cycle; count = words stored;
//   sticky overflow / underflow flags for the testbench).  Latency from push to !empty is 1 cycle (RAM = 0) or 3 cycles
//   (RAM = 1); throughput is one word per cycle in both.  DEPTH must be a power of two >= 4.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_pkt_fifo #(
  parameter int WIDTH = 32,
  parameter int DEPTH = 16,
  parameter bit RAM   = 1'b1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 push,
  input  wire logic [WIDTH-1:0]     wdata,
  input  wire logic                 pop,
  output logic [WIDTH-1:0]          rdata,
  output logic                      full,
  output logic                      empty,
  output logic [$clog2(DEPTH):0]    count,
  output logic                      overflow,
  output logic                      underflow
);
  localparam int AW = $clog2(DEPTH);
  localparam int PW = AW + 1;

  generate
    if (RAM) begin : g_ram
      reg [WIDTH-1:0] mem [0:DEPTH-1];
      reg [PW-1:0]    wptr, fptr, pptr;      // write, fetch (next RAM read), pop (words consumed)
      reg             s1_v, h_v;
      reg [WIDTH-1:0] mq, h;
      wire [PW-1:0]   used  = wptr - pptr;
      assign full  = (used == PW'(DEPTH));
      assign empty = !h_v;
      assign count = used[AW:0];
      wire            do_push = push && !full;
      wire            h_free  = !h_v || (pop && h_v);
      wire            avail   = (wptr != fptr);
      wire            issue   = avail && (!s1_v || h_free);

      always_ff @(posedge clk) begin
        if (do_push) mem[wptr[AW-1:0]] <= wdata;
        if (issue)   mq <= mem[fptr[AW-1:0]];
        if (h_free)  h  <= mq;
      end
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          wptr <= '0; fptr <= '0; pptr <= '0; s1_v <= 1'b0; h_v <= 1'b0; overflow <= 1'b0; underflow <= 1'b0;
        end else begin
          if (do_push) wptr <= wptr + 1'b1;
          if (issue)   fptr <= fptr + 1'b1;
          s1_v <= issue || (s1_v && !h_free);
          if (h_free)  h_v <= s1_v;
          if (pop && h_v) pptr <= pptr + 1'b1;
          if (push && full)  overflow  <= 1'b1;
          if (pop && !h_v)   underflow <= 1'b1;
        end
      end
      assign rdata = h;
    end else begin : g_reg
      sync_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH), .AFULL_THRESH(2), .AEMPTY_THRESH(2), .FWFT(1'b1)) u_f (
        .clk(clk), .rst_n(rst_n), .push(push), .wdata(wdata), .pop(pop), .rdata(rdata),
        .full(full), .empty(empty), .almost_full(), .almost_empty(), .overflow(overflow), .underflow(underflow), .count(count));
    end
  endgenerate
endmodule

`default_nettype wire
