// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_counters -- performance / statistics block
//
//   * additive counters SATURATE at all-ones (never wrap);  max/min trackers;  gauges (latched at snapshot)
//   * CTRL.snap_global copies EVERY live counter into the shadow registers in ONE cycle: software reads a
//     mutually consistent set (including both halves of a >32-bit value).  CTRL.clear_global zeroes them.
//   * per-rule hit / byte counters have their own snapshot / clear (tenants may snapshot, admin clears).
//   * Pattern follows sfb_perf_counters (SilicaFlux DataFabric).  Slot map: sf_pkt_defs.svh (CI_*, CQ_*).
//   * Live counters use a SYNCHRONOUS clear that also covers reset (rst_n low for >= 1 clock), which maps to the
//     FPGA flip-flop's native sync-reset input (an async reset + sync clear pair would cost a LUT per bit).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_pkt_macros.svh"
`default_nettype none

module sf_pkt_counters #(
  parameter int NQ   = 4,
  parameter int NR   = 16,
  parameter int CW   = 40,
  parameter int ADDW = 20
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  input  wire logic                         cnt_en,
  input  wire logic                         snap_g,
  input  wire logic                         clr_g,
  input  wire logic                         snap_r,
  input  wire logic                         clr_r,
  input  wire logic [`SFP_NSLOT-1:0]        evt,
  input  wire logic [`SFP_NSLOT*32-1:0]     val,
  input  wire logic [7:0]                   rd_idx,
  output logic [CW-1:0]                     rd_data,
  input  wire logic                         rule_evt,
  input  wire logic [7:0]                   rule_idx,
  input  wire logic [15:0]                  rule_len,
  input  wire logic [7:0]                   rr_idx,
  output logic [CW-1:0]                     rr_hits,
  output logic [CW-1:0]                     rr_bytes
);
  `include "sf_pkt_defs.svh"
  // rst_n deliberately feeds both the async-reset shadow registers and the synchronous clear of the live counters.
  /* verilator lint_off SYNCASYNCNET */

  localparam int NSLOT = CI_NSLOT;

  wire [NSLOT*CW-1:0] shadow_flat;
  genvar gs;
  generate
    for (gs = 0; gs < NSLOT; gs = gs + 1) begin : g_slot
      localparam int T      = 32'(cnt_type(gs));
      localparam bit ACTIVE = (gs < CI_G_STRIDE) ? (T != 4) : (((gs - CI_G_STRIDE) / CI_Q_STRIDE) < NQ);
      reg  [CW-1:0] live;
      reg  [CW-1:0] shad;
      wire [31:0]   v = val[gs*32 +: 32];
      if (ACTIVE) begin : g_act
        if (T == 0) begin : g_add
          wire [CW:0] sum = {1'b0, live} + {{(CW+1-ADDW){1'b0}}, v[ADDW-1:0]};
          always_ff @(posedge clk) begin
            if (!rst_n || clr_g)         live <= '0;
            else if (cnt_en && evt[gs])  live <= sum[CW] ? {CW{1'b1}} : sum[CW-1:0];
          end
        end else if (T == 1) begin : g_max
          always_ff @(posedge clk) begin
            if (!rst_n || clr_g)         live <= '0;
            else if (cnt_en && evt[gs] && ({{(CW-32){1'b0}}, v} > live)) live <= {{(CW-32){1'b0}}, v};
          end
        end else if (T == 2) begin : g_min
          always_ff @(posedge clk) begin
            if (!rst_n || clr_g)         live <= {CW{1'b1}};
            else if (cnt_en && evt[gs] && ({{(CW-32){1'b0}}, v} < live)) live <= {{(CW-32){1'b0}}, v};
          end
        end else begin : g_gauge
          always_comb live = {{(CW-32){1'b0}}, v};
        end
        always_ff @(posedge clk or negedge rst_n) begin
          if (!rst_n)       shad <= '0;
          else if (snap_g)  shad <= live;
        end
      end else begin : g_off
        always_comb begin live = '0; shad = '0; end
      end
      assign shadow_flat[gs*CW +: CW] = shad;
    end
  endgenerate
  // explicit AND-OR read mux (a variable part-select on the flat vector would synthesise as a full barrel shifter)
  always_comb begin
    rd_data = '0;
    for (int s = 0; s < NSLOT; s++) rd_data = rd_data | ({CW{rd_idx == 8'(s)}} & shadow_flat[s*CW +: CW]);
  end

  // ---- per-rule counters ---------------------------------------------------------------------------
  wire [NR*CW-1:0] sh_hits, sh_bytes;
  genvar gr;
  generate
    for (gr = 0; gr < NR; gr = gr + 1) begin : g_rule
      reg [CW-1:0] hl, bl, hs, bs;
      wire         e   = cnt_en && rule_evt && (rule_idx == 8'(gr));
      wire [CW:0]  hsum = {1'b0, hl} + {{CW{1'b0}}, 1'b1};
      wire [CW:0]  bsum = {1'b0, bl} + {{(CW-15){1'b0}}, rule_len};
      always_ff @(posedge clk) begin
        if (!rst_n || clr_r) begin hl <= '0; bl <= '0; end
        else if (e) begin
          hl <= hsum[CW] ? {CW{1'b1}} : hsum[CW-1:0];
          bl <= bsum[CW] ? {CW{1'b1}} : bsum[CW-1:0];
        end
      end
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)       begin hs <= '0; bs <= '0; end
        else if (snap_r)  begin hs <= hl; bs <= bl; end
      end
      assign sh_hits[gr*CW +: CW]  = hs;
      assign sh_bytes[gr*CW +: CW] = bs;
    end
  endgenerate
  always_comb begin
    rr_hits  = '0;
    rr_bytes = '0;
    for (int r = 0; r < NR; r++) begin
      rr_hits  = rr_hits  | ({CW{rr_idx == 8'(r)}} & sh_hits[r*CW +: CW]);
      rr_bytes = rr_bytes | ({CW{rr_idx == 8'(r)}} & sh_bytes[r*CW +: CW]);
    end
  end
  /* verilator lint_on SYNCASYNCNET */
endmodule

`default_nettype wire
