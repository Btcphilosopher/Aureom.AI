// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_regs -- versioned register interface, rule table, tenant isolation
//
//   Bus      one request per cycle (rb_req); response (rb_rvalid, rb_rdata, rb_err) exactly one cycle later.
//            rb_tenant = accessor identity: 0 = administrator, 1..NT-1 = tenants (driven by the trusted
//            interconnect / hypervisor; the engine cannot authenticate it -- see docs/ISOLATION.md).
//   Isolation (enforced here, in hardware, independent of software):
//     * Global policy, queue/scheduler config, tenant table, rule-ownership table, global counters:
//       administrator only.  Any tenant access is rejected (rb_err), counted and logged (VIOL_LAST).
//     * A rule slot belongs to exactly one owner (OWNER[r], administrator-written).  A tenant may stage /
//       commit / clear / read / count ONLY slots it owns.
//     * The staging window is single-owner: a tenant's first staging write claims it and clears any other
//       party's data, so words from different tenants can never be merged into one rule.
//     * A tenant rule is limited to FWD/DROP, must name explicit queue(s) inside the tenant's queue mask, and
//       at lookup time is AND-ed with the tenant scope (VLAN id / VNI) -- it can only ever match that
//       tenant's own traffic.  Policy is re-checked every cycle (rl_eff_valid), so shrinking a tenant's mask
//       or disabling the tenant takes effect immediately without touching its rules.
//     * Rule commits are atomic: the match table is written in one cycle and the action table copy one cycle
//       later, aligned to the classifier pipeline (no packet sees old-match + new-action).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_pkt_macros.svh"
`default_nettype none

module sf_pkt_regs #(
  parameter int NQ              = 4,
  parameter int NR              = 16,
  parameter int NT              = 8,
  parameter int DW              = 128,
  parameter int MAX_FRAME_BYTES = 9216,
  parameter int QUEUE_BYTES     = 16384,
  parameter int WIN_BYTES       = 128,
  parameter int MAX_EXT         = 4,
  parameter int CW              = 40,
  parameter bit ENABLE_RSS      = 1'b1,
  parameter bit ENABLE_VXLAN    = 1'b1,
  parameter bit ENABLE_REWRITE  = 1'b1,
  parameter bit ENABLE_TENANT   = 1'b1,
  parameter bit ENABLE_PERF     = 1'b1,
  parameter bit ENABLE_RULE_READ = 1'b1   // 0: no RULE_CMD READ (saves a 876 x NR AND-OR mux); READ then returns ERR_CMD
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  // register bus
  input  wire logic                         rb_req,
  input  wire logic                         rb_we,
  input  wire logic [15:0]                  rb_addr,
  input  wire logic [31:0]                  rb_wdata,
  input  wire logic [3:0]                   rb_tenant,
  output logic                              rb_rvalid,
  output logic [31:0]                       rb_rdata,
  output logic                              rb_err,
  // status in
  input  wire logic                         st_idle,
  input  wire logic [7:0]                   st_inflight,
  input  wire logic [NQ*32-1:0]             q_occ_bytes,
  // counters
  output logic [7:0]                        cnt_rd_idx,
  input  wire logic [CW-1:0]                cnt_rd_data,
  output logic [7:0]                        rr_idx,
  input  wire logic [CW-1:0]                rr_hits,
  input  wire logic [CW-1:0]                rr_bytes,
  output logic                              snap_g,
  output logic                              clr_g,
  output logic                              snap_r,
  output logic                              clr_r,
  output logic                              ev_viol,
  output logic                              ev_rd,
  output logic                              ev_wr,
  // global configuration
  output logic                              cfg_enable,
  output logic                              cfg_cnt_en,
  output logic [1:0]                        cfg_malformed_act,
  output logic [1:0]                        cfg_unsupp_act,
  output logic [1:0]                        cfg_frag_act,
  output logic                              cfg_csum_en,
  output logic                              cfg_vxlan_en,
  output logic                              cfg_qdrop,
  output logic [15:0]                       cfg_min_len,
  output logic [15:0]                       cfg_max_len,
  output logic [1:0]                        cfg_def_verdict,
  output logic                              cfg_def_setq,
  output logic [3:0]                        cfg_def_qid,
  output logic [2:0]                        cfg_def_tc,
  output logic [15:0]                       cfg_tpid0,
  output logic [15:0]                       cfg_tpid1,
  output logic [15:0]                       cfg_vxlan_port,
  output logic [1:0]                        cfg_tc_src,
  output logic [31:0]                       cfg_tc_qmap,
  output logic [15:0]                       cfg_rl_period,
  output logic [1:0]                        cfg_sched_mode,
  output logic [31:0]                       cfg_starve,
  output logic [15:0]                       cfg_quant,
  output logic [319:0]                      cfg_rss_key,
  // per-queue configuration
  output logic [NQ*2-1:0]                   q_prio,
  output logic [NQ*8-1:0]                   q_weight,
  output logic [NQ*16-1:0]                  q_rl_inc,
  output logic [NQ*24-1:0]                  q_rl_burst,
  output logic [NQ*32-1:0]                  q_wm,
  // rule tables
  output logic [NR*`SFP_RL_W-1:0]           rule_flat,
  output logic [NR*`SFP_RL_ACT_W-1:0]       act_flat,
  output logic [NR-1:0]                     rl_eff_valid,
  output logic [NR-1:0]                     rl_scoped,
  output logic [NR-1:0]                     rl_sc_vidv,
  output logic [NR*12-1:0]                  rl_sc_vid,
  output logic [NR-1:0]                     rl_sc_vniv,
  output logic [NR*24-1:0]                  rl_sc_vni
);
  `include "sf_pkt_defs.svh"
  // Indices into the tenant / queue / rule arrays are range-checked (t_in, q_in, o_in, r_in, ...) before use;
  // the narrow-index and wide-reset-fill style warnings below are therefore benign.
  /* verilator lint_off WIDTHTRUNC */
  /* verilator lint_off WIDTHCONCAT */

  localparam int RW   = `SFP_RL_W;
  localparam int AW   = `SFP_RL_ACT_W;
  localparam int NRW  = RL_WORDS;
  localparam int SQ_W = (NQ > 1) ? $clog2(NQ) : 1;

  generate
    if (NQ < 1 || NQ > NQ_MAX)  begin : g_c1 initial $error("sf_pkt_regs: NQ out of range"); end
    if (NR < 1 || NR > NR_MAX)  begin : g_c2 initial $error("sf_pkt_regs: NR out of range"); end
    if (NT < 1 || NT > NT_MAX)  begin : g_c3 initial $error("sf_pkt_regs: NT out of range"); end
    if (MAX_FRAME_BYTES > 65535) begin : g_c4 initial $error("sf_pkt_regs: MAX_FRAME_BYTES must fit 16 bits"); end
  endgenerate

  localparam int RSS_KEY_WORDS_C = 10;
  localparam [31:0] ID_VALUE_C = 32'h53465045;
  localparam [319:0] MS_KEY = 320'h6d5a56da255b0ec24167253d43a38fb0d0ca2bcbae7b30b477cb2da38030f20c6a42b73bbeac01fa;

  // ---------------------------------------------------------------------------------------------------
  // storage
  // ---------------------------------------------------------------------------------------------------
  reg [15:0]  r_minlen, r_maxlen, r_tpid0, r_tpid1, r_vxport, r_rlper, r_quant;
  reg [1:0]   r_malf, r_unsupp, r_frag, r_defv, r_tcsrc, r_smode;
  reg         r_csum, r_vxlan, r_qdrop, r_defsetq, r_en, r_cnten;
  reg [3:0]   r_defq;
  reg [2:0]   r_deftc;
  reg [31:0]  r_tcqmap, r_starve, r_scratch;
  reg [319:0] r_key;
  reg [NQ*2-1:0]  r_qprio;
  reg [NQ*8-1:0]  r_qweight;
  reg [NQ*16-1:0] r_qrlinc;
  reg [NQ*24-1:0] r_qrlburst;
  reg [NQ*32-1:0] r_qwm;
  reg [NT-1:0]    t_vidv, t_vniv, t_en;
  reg [NT*12-1:0] t_vid;
  reg [NT*24-1:0] t_vni;
  reg [NT*16-1:0] t_qm;
  reg [NR*4-1:0]  r_owner;
  wire [NR*RW-1:0]  r_rules;      // per-rule registers live in g_rl (no variable part-selects on big vectors)
  wire [NR*AW-1:0]  r_acts;
  wire [NRW*32-1:0] r_stage;      // staging window words live in g_stg
  reg [3:0]       r_stage_owner;
  reg [NT*4-1:0]  r_rstat;
  reg [NT*8-1:0]  r_rseq;
  reg [15:0]      r_viol_addr;
  reg [3:0]       r_viol_ten;
  reg             r_viol_we;
  reg             act_pv;
  reg [7:0]       act_pidx;
  reg [AW-1:0]    act_pdat;

  // ---------------------------------------------------------------------------------------------------
  // policy checks
  // ---------------------------------------------------------------------------------------------------
  // tenant policy: FWD/DROP only; FWD needs explicit queue(s) inside the tenant's queue mask.
  // hash group = 2^hash_bits consecutive queues starting at qid: all must exist (< NQ) and be in the mask.
  function automatic rule_pol_ok(input [RW-1:0] r, input [15:0] qm);
    reg [1:0]  vd;
    reg        setq, qh, ok;
    reg [3:0]  qid;
    reg [1:0]  hb;
    reg [7:0]  gs;        // group size 1,2,4,8
    reg [15:0] smask;     // (1 << gs) - 1
    reg [15:0] shq;
    reg [4:0]  lastq;
    begin
      vd = r[RL_VERDICT_LSB +: 2];  setq = r[RL_SET_QUEUE_LSB];  qh = r[RL_QSEL_HASH_LSB];
      qid = r[RL_QID_LSB +: 4];     hb = r[RL_HASH_BITS_LSB +: 2];
      gs    = 8'd1 << hb;
      smask = (16'd1 << gs) - 16'd1;
      shq   = qm >> qid;
      lastq = {1'b0, qid} + gs[4:0] - 5'd1;
      ok = 1'b1;
      if (vd == 2'(VERD_MGMT) || vd == 2'd3) ok = 1'b0;
      if (vd == 2'(VERD_FWD)) begin
        if (!setq && !qh) ok = 1'b0;
        if (setq) begin
          if ({1'b0, qid} >= 5'(NQ) || !qm[qid]) ok = 1'b0;
        end else if (qh) begin
          if (lastq >= 5'(NQ) || ((shq & smask) != smask)) ok = 1'b0;
        end
      end
      rule_pol_ok = ok;
    end
  endfunction

  // administrator sanity: reserved verdict and out-of-range queues are rejected
  function automatic rule_adm_ok(input [RW-1:0] r);
    reg [1:0] vd;
    reg       ok;
    reg [3:0] qid;
    reg [1:0] hb;
    integer   span;
    begin
      vd = r[RL_VERDICT_LSB +: 2];  qid = r[RL_QID_LSB +: 4];  hb = r[RL_HASH_BITS_LSB +: 2];
      ok = 1'b1;
      if (vd == 2'd3) ok = 1'b0;
      if (vd == 2'(VERD_FWD)) begin
        if (r[RL_SET_QUEUE_LSB] && (32'(qid) >= NQ)) ok = 1'b0;
        else if (r[RL_QSEL_HASH_LSB]) begin
          span = (1 << hb) - 1;
          if (32'(qid) + span >= NQ) ok = 1'b0;
        end
      end
      rule_adm_ok = ok;
    end
  endfunction

  // ---------------------------------------------------------------------------------------------------
  // address decode
  // ---------------------------------------------------------------------------------------------------
  wire [31:0] a32     = {16'd0, rb_addr};
  wire        aligned = (rb_addr[1:0] == 2'b00);
  wire        is_adm  = (rb_tenant == 4'd0);
  wire        t_valid = is_adm || (ENABLE_TENANT && (32'(rb_tenant) < NT));
  wire [3:0]  t       = rb_tenant;

  wire reg_glob = (a32 < 32'h0100);
  wire reg_qcfg = (a32 >= A_QCFG) && (a32 < A_QCFG + 32'(NQ_MAX) * A_QCFG_STRIDE);
  wire reg_ten  = (a32 >= A_TEN)  && (a32 < A_TEN + 32'(NT_MAX) * A_TEN_STRIDE);
  wire reg_own  = (a32 >= A_OWNER) && (a32 < A_OWNER + 32'(NR_MAX) * 4);
  wire reg_stg  = (a32 >= A_STAGE) && (a32 < A_STAGE + 32'(NRW) * 4);
  wire reg_rcmd = (a32 == A_RULE_CMD);
  wire reg_rst  = (a32 == A_RULE_STATUS);
  wire reg_sown = (a32 == A_STAGE_OWNER);
  wire reg_rsnp = (a32 == A_RULE_SNAP);
  wire reg_rcnt = (a32 >= A_RULE_CNT) && (a32 < A_RULE_CNT + 32'(NR_MAX) * A_RULE_CNT_STRIDE);
  wire reg_gcnt = (a32 >= A_GCNT) && (a32 < A_GCNT + 32'(CI_NSLOT) * A_GCNT_STRIDE);

  wire [7:0] qi   = 8'((a32 - A_QCFG) >> 5);
  wire [4:0] qoff = 5'((a32 - A_QCFG) & 32'h1F);
  wire [7:0] ti   = 8'((a32 - A_TEN) >> 4);
  wire [3:0] toff = 4'((a32 - A_TEN) & 32'hF);
  wire [7:0] oi   = 8'((a32 - A_OWNER) >> 2);
  wire [7:0] si   = 8'((a32 - A_STAGE) >> 2);
  wire [7:0] ri   = 8'((a32 - A_RULE_CNT) >> 4);
  wire [1:0] rsel = 2'((a32 - A_RULE_CNT) >> 2);
  wire [7:0] gi   = 8'((a32 - A_GCNT) >> 3);
  wire       ghi  = rb_addr[2];

  wire q_in = (qi < 8'(NQ));
  wire t_in = (ti < 8'(NT));
  wire o_in = (oi < 8'(NR));
  wire r_in = (ri < 8'(NR));

  wire [3:0] own_of_oi = r_owner[oi*4 +: 4];
  wire [3:0] own_of_ri = r_owner[ri*4 +: 4];

  // global register address pieces
  wire g_id   = (a32 == A_ID);
  wire g_ver  = (a32 == A_VERSION);
  wire g_cap0 = (a32 == A_CAPS0);
  wire g_cap1 = (a32 == A_CAPS1);
  wire g_cap2 = (a32 == A_CAPS2);
  wire g_caps = g_id || g_ver || g_cap0 || g_cap1 || g_cap2;
  wire g_rss  = (a32 >= A_RSS_KEY) && (a32 < A_RSS_KEY + 32'(RSS_KEY_WORDS_C) * 4);
  wire [3:0] rss_w = 4'((a32 - A_RSS_KEY) >> 2);

  wire g_ctrl = (a32 == A_CTRL), g_stat = (a32 == A_STATUS), g_scr = (a32 == A_SCRATCH),
       g_perr = (a32 == A_POL_ERR), g_plen = (a32 == A_POL_LEN), g_pdef = (a32 == A_POL_DEF),
       g_ptpid = (a32 == A_POL_TPID), g_pvx = (a32 == A_POL_VXLAN), g_ptc = (a32 == A_POL_TC),
       g_qmap = (a32 == A_TC_QMAP), g_rlp = (a32 == A_RL_PERIOD), g_smode = (a32 == A_SCHED_MODE),
       g_sstv = (a32 == A_SCHED_STARVE), g_squ = (a32 == A_SCHED_QUANT), g_vl = (a32 == A_VIOL_LAST);
  wire g_rw_a = g_ctrl || g_scr || g_perr || g_plen || g_pdef || g_ptpid || g_pvx || g_ptc || g_qmap ||
                g_rlp || g_smode || g_sstv || g_squ || g_rss;
  wire g_ro   = g_caps || g_stat || g_vl;

  // ---------------------------------------------------------------------------------------------------
  // access control
  // ---------------------------------------------------------------------------------------------------
  reg mapped, perm, ro_wr;
  always_comb begin
    mapped = 1'b0;
    perm   = 1'b0;
    ro_wr  = 1'b0;
    if (reg_glob) begin
      mapped = g_rw_a || g_ro;
      perm   = is_adm || (g_caps && !rb_we);
      ro_wr  = rb_we && g_ro;
    end else if (reg_qcfg) begin
      mapped = q_in && (qoff == 5'(QC_PRIO) || qoff == 5'(QC_WEIGHT) || qoff == 5'(QC_RL_INC) ||
                        qoff == 5'(QC_RL_BURST) || qoff == 5'(QC_WM) || qoff == 5'(QC_OCC));
      perm   = is_adm;
      ro_wr  = rb_we && (qoff == 5'(QC_OCC));
    end else if (reg_ten) begin
      mapped = t_in && (toff == 4'(TN_SCOPE_VID) || toff == 4'(TN_SCOPE_VNI) || toff == 4'(TN_QMASK) || toff == 4'(TN_ENABLE));
      perm   = is_adm || (!rb_we && (ti == {4'd0, t}));
    end else if (reg_own) begin
      mapped = o_in;
      perm   = is_adm || (!rb_we && o_in && (own_of_oi == t));
    end else if (reg_stg) begin
      mapped = 1'b1;
      perm   = is_adm || rb_we || (r_stage_owner == t);
    end else if (reg_rcmd) begin
      mapped = 1'b1; perm = rb_we || is_adm; ro_wr = !rb_we;
    end else if (reg_rst || reg_sown) begin
      mapped = 1'b1; perm = 1'b1; ro_wr = rb_we;
    end else if (reg_rsnp) begin
      mapped = 1'b1; perm = rb_we || is_adm; ro_wr = !rb_we;
    end else if (reg_rcnt) begin
      mapped = r_in;
      perm   = is_adm || (!rb_we && r_in && (own_of_ri == t));
      ro_wr  = rb_we;
    end else if (reg_gcnt) begin
      mapped = (gi < 8'(CI_NSLOT));
      perm   = is_adm;
      ro_wr  = rb_we;
    end
  end

  wire own_val_bad = reg_own && rb_we && ((32'(rb_wdata[3:0]) >= NT) || (!ENABLE_TENANT && (rb_wdata[3:0] != 4'd0)));
  wire acc_ok   = rb_req && aligned && t_valid && mapped && perm && !ro_wr && !own_val_bad;
  wire viol_c   = rb_req && !is_adm && ((!t_valid) || (aligned && mapped && !perm));
  wire do_wr    = acc_ok && rb_we;
  wire do_rd    = acc_ok && !rb_we;

  // ---------------------------------------------------------------------------------------------------
  // rule command execution
  // ---------------------------------------------------------------------------------------------------
  wire [3:0]  cmd      = rb_wdata[31:28];
  wire [7:0]  cidx     = rb_wdata[7:0];
  wire [RW-1:0] stage_rule = r_stage[RW-1:0];
  wire [3:0]  own_cidx = (cidx < 8'(NR)) ? r_owner[cidx*4 +: 4] : 4'd0;
  wire [15:0] t_qmask  = (32'(t) < NT) ? t_qm[t*16 +: 16] : 16'd0;
  wire        cmd_go   = rb_req && rb_we && aligned && t_valid && reg_rcmd;

  reg [3:0] cs;               // command status
  reg       c_commit, c_clear, c_read;
  always_comb begin
    cs = 4'(RS_OK); c_commit = 1'b0; c_clear = 1'b0; c_read = 1'b0;
    if (cmd != 4'(CMD_COMMIT) && cmd != 4'(CMD_CLEAR) && !(cmd == 4'(CMD_READ) && ENABLE_RULE_READ)) cs = 4'(RS_ERR_CMD);
    else if (cidx >= 8'(NR))                                                    cs = 4'(RS_ERR_RANGE);
    else if (!is_adm && own_cidx != t)                                          cs = 4'(RS_ERR_PERM);
    else if (cmd == 4'(CMD_COMMIT)) begin
      if (!is_adm && r_stage_owner != t)              cs = 4'(RS_ERR_STAGE);
      else if (is_adm  && !rule_adm_ok(stage_rule))   cs = 4'(RS_ERR_POLICY);
      else if (!is_adm && !rule_pol_ok(stage_rule, t_qmask)) cs = 4'(RS_ERR_POLICY);
    end
    if (cs == 4'(RS_OK)) begin
      c_commit = (cmd == 4'(CMD_COMMIT));
      c_clear  = (cmd == 4'(CMD_CLEAR));
      c_read   = (cmd == 4'(CMD_READ));
    end
  end
  wire cmd_viol = cmd_go && !is_adm && (cs == 4'(RS_ERR_PERM) || cs == 4'(RS_ERR_STAGE) || cs == 4'(RS_ERR_POLICY));

  // ---------------------------------------------------------------------------------------------------
  // read mux
  // ---------------------------------------------------------------------------------------------------
  wire [31:0] caps0 = {8'(DW/8), 8'(NT), 8'(NR), 8'(NQ)};
  wire [31:0] caps1 = {16'(MAX_FRAME_BYTES), 8'd0, 3'(MAX_EXT), 1'(ENABLE_PERF), 1'(ENABLE_TENANT), 1'(ENABLE_REWRITE), 1'(ENABLE_VXLAN), 1'(ENABLE_RSS)};
  wire [31:0] caps2 = {8'(CW), 8'(WIN_BYTES), 16'(QUEUE_BYTES / 64)};
  wire [31:0] ctrl_r = {30'd0, r_cnten, r_en};
  wire [31:0] stat_r = {16'd0, st_inflight, 7'd0, st_idle};
  wire [31:0] perr_r = {21'd0, r_qdrop, r_vxlan, r_csum, 2'd0, r_frag, r_unsupp, r_malf};
  wire [31:0] plen_r = {r_maxlen, r_minlen};
  wire [31:0] pdef_r = {21'd0, r_deftc, r_defq, 1'b0, r_defsetq, r_defv};
  wire [31:0] ptpid_r = {r_tpid1, r_tpid0};
  wire [31:0] vl_r   = {11'd0, r_viol_we, r_viol_ten, r_viol_addr};

  reg [31:0] rd_c;
  reg [CW-1:0] cntv;
  always_comb begin
    rd_c = 32'd0;
    cnt_rd_idx = gi;
    rr_idx     = ri;
    cntv = cnt_rd_data;
    if (reg_glob) begin
      if (g_id)        rd_c = ID_VALUE_C;
      else if (g_ver)  rd_c = {8'd0, 8'(SFP_VER_MAJOR), 8'(SFP_VER_MINOR), 8'(SFP_VER_PATCH)};
      else if (g_cap0) rd_c = caps0;
      else if (g_cap1) rd_c = caps1;
      else if (g_cap2) rd_c = caps2;
      else if (g_ctrl) rd_c = ctrl_r;
      else if (g_stat) rd_c = stat_r;
      else if (g_scr)  rd_c = r_scratch;
      else if (g_perr) rd_c = perr_r;
      else if (g_plen) rd_c = plen_r;
      else if (g_pdef) rd_c = pdef_r;
      else if (g_ptpid) rd_c = ptpid_r;
      else if (g_pvx)  rd_c = {16'd0, r_vxport};
      else if (g_ptc)  rd_c = {30'd0, r_tcsrc};
      else if (g_qmap) rd_c = r_tcqmap;
      else if (g_rlp)  rd_c = {16'd0, r_rlper};
      else if (g_smode) rd_c = {30'd0, r_smode};
      else if (g_sstv) rd_c = r_starve;
      else if (g_squ)  rd_c = {16'd0, r_quant};
      else if (g_vl)   rd_c = vl_r;
      else if (g_rss)  rd_c = r_key[(32'd9 - 32'(rss_w)) * 32 +: 32];
    end else if (reg_qcfg && q_in) begin
      case (qoff)
        5'(QC_PRIO):     rd_c = {30'd0, r_qprio[qi*2 +: 2]};
        5'(QC_WEIGHT):   rd_c = {24'd0, r_qweight[qi*8 +: 8]};
        5'(QC_RL_INC):   rd_c = {16'd0, r_qrlinc[qi*16 +: 16]};
        5'(QC_RL_BURST): rd_c = {8'd0, r_qrlburst[qi*24 +: 24]};
        5'(QC_WM):       rd_c = r_qwm[qi*32 +: 32];
        5'(QC_OCC):      rd_c = q_occ_bytes[qi*32 +: 32];
        default:         rd_c = 32'd0;
      endcase
    end else if (reg_ten && t_in) begin
      case (toff)
        4'(TN_SCOPE_VID): rd_c = {15'd0, t_vidv[ti], 4'd0, t_vid[ti*12 +: 12]};
        4'(TN_SCOPE_VNI): rd_c = {t_vniv[ti], 7'd0, t_vni[ti*24 +: 24]};
        4'(TN_QMASK):     rd_c = {16'd0, t_qm[ti*16 +: 16]};
        4'(TN_ENABLE):    rd_c = {31'd0, t_en[ti]};
        default:          rd_c = 32'd0;
      endcase
    end else if (reg_own && o_in) begin
      rd_c = {28'd0, own_of_oi};
    end else if (reg_stg) begin
      rd_c = 32'd0;
      for (int k = 0; k < NRW; k++) rd_c = rd_c | ({32{si == 8'(k)}} & r_stage[k*32 +: 32]);
    end else if (reg_rst) begin
      rd_c = {16'd0, r_rseq[(32'(t) < NT ? t : 4'd0)*8 +: 8], 4'd0, r_rstat[(32'(t) < NT ? t : 4'd0)*4 +: 4]};
    end else if (reg_sown) begin
      rd_c = is_adm ? {28'd0, r_stage_owner} : {31'd0, (r_stage_owner == t)};
    end else if (reg_rcnt && r_in) begin
      case (rsel)
        2'd0: rd_c = rr_hits[31:0];
        2'd1: rd_c = {{(64-CW){1'b0}}, rr_hits[CW-1:32]} ;
        2'd2: rd_c = rr_bytes[31:0];
        default: rd_c = {{(64-CW){1'b0}}, rr_bytes[CW-1:32]};
      endcase
    end else if (reg_gcnt) begin
      rd_c = ghi ? {{(64-CW){1'b0}}, cntv[CW-1:32]} : cntv[31:0];
    end
  end

  // ---------------------------------------------------------------------------------------------------
  // response, pulses
  // ---------------------------------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rb_rvalid <= 1'b0;
      rb_rdata  <= 32'd0;
      rb_err    <= 1'b0;
      snap_g <= 1'b0; clr_g <= 1'b0; snap_r <= 1'b0; clr_r <= 1'b0;
      ev_viol <= 1'b0; ev_rd <= 1'b0; ev_wr <= 1'b0;
    end else begin
      rb_rvalid <= rb_req;
      rb_rdata  <= (do_rd) ? rd_c : 32'd0;
      // a rule command that fails reports its error on the same response
      rb_err    <= rb_req && (!acc_ok || (cmd_go && (cs != 4'(RS_OK))));
      snap_g <= do_wr && g_ctrl && rb_wdata[F_CTRL_SNAP_GLOBAL_LSB];
      clr_g  <= do_wr && g_ctrl && rb_wdata[F_CTRL_CLEAR_GLOBAL_LSB];
      snap_r <= (do_wr && g_ctrl && rb_wdata[F_CTRL_SNAP_RULES_LSB]) || (do_wr && reg_rsnp);
      clr_r  <= do_wr && g_ctrl && rb_wdata[F_CTRL_CLEAR_RULES_LSB];
      ev_viol <= viol_c || cmd_viol;
      ev_rd   <= do_rd;
      ev_wr   <= do_wr;
    end
  end

  // ---------------------------------------------------------------------------------------------------
  // writes
  // ---------------------------------------------------------------------------------------------------
  integer ii;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_en <= 1'b1; r_cnten <= 1'b1;
      r_malf <= 2'(ACT_DROP); r_unsupp <= 2'(ACT_PUNT); r_frag <= 2'(ACT_CONT);
      r_csum <= 1'b1; r_vxlan <= 1'b1; r_qdrop <= 1'b0;
      r_minlen <= 16'd60; r_maxlen <= 16'(MAX_FRAME_BYTES);
      r_defv <= 2'(VERD_FWD); r_defsetq <= 1'b0; r_defq <= 4'd0; r_deftc <= 3'd0;
      r_tpid0 <= 16'h8100; r_tpid1 <= 16'h88A8; r_vxport <= 16'd4789;
      r_tcsrc <= 2'(TCSRC_NONE); r_tcqmap <= 32'd0;
      r_rlper <= 16'd1; r_smode <= 2'(SCHED_RR); r_starve <= 32'd0; r_quant <= 16'd2048;
      r_scratch <= 32'd0; r_key <= MS_KEY;
      for (ii = 0; ii < NQ; ii = ii + 1) begin
        r_qprio[ii*2 +: 2] <= 2'd0;        r_qweight[ii*8 +: 8] <= 8'd1;
        r_qrlinc[ii*16 +: 16] <= 16'd0;    r_qrlburst[ii*24 +: 24] <= 24'h00FFFF;
        r_qwm[ii*32 +: 32] <= 32'hFFFFFFFF;
      end
      t_vidv <= '0; t_vniv <= '0; t_en <= '0; t_vid <= '0; t_vni <= '0; t_qm <= '0;
      r_owner <= '0;
      r_stage_owner <= 4'd0;
      r_rstat <= '0; r_rseq <= '0;
      r_viol_addr <= 16'd0; r_viol_ten <= 4'd0; r_viol_we <= 1'b0;
      act_pv <= 1'b0; act_pidx <= 8'd0; act_pdat <= '0;
    end else begin
      // ---- violation log ------------------------------------------------------------------------------------
      if (viol_c || cmd_viol) begin
        r_viol_addr <= rb_addr; r_viol_ten <= t; r_viol_we <= rb_we;
      end
      // ---- delayed action-table copy (pipeline aligned) -----------------------------------------------------
      act_pv <= 1'b0;

      // ---- register writes ------------------------------------------------------------------------------------
      if (do_wr && reg_glob) begin
        if (g_ctrl) begin r_en <= rb_wdata[F_CTRL_ENABLE_LSB]; r_cnten <= rb_wdata[F_CTRL_CNT_EN_LSB]; end
        if (g_scr)  r_scratch <= rb_wdata;
        if (g_perr) begin
          r_malf <= rb_wdata[F_POL_ERR_MALFORMED_ACT_LSB +: 2];
          r_unsupp <= rb_wdata[F_POL_ERR_UNSUPP_ACT_LSB +: 2];
          r_frag <= rb_wdata[F_POL_ERR_FRAG_ACT_LSB +: 2];
          r_csum <= rb_wdata[F_POL_ERR_CSUM_EN_LSB];
          r_vxlan <= rb_wdata[F_POL_ERR_VXLAN_EN_LSB];
          r_qdrop <= rb_wdata[F_POL_ERR_QDROP_LSB];
        end
        if (g_plen) begin
          r_minlen <= rb_wdata[15:0];
          r_maxlen <= (rb_wdata[31:16] > 16'(MAX_FRAME_BYTES)) ? 16'(MAX_FRAME_BYTES) : rb_wdata[31:16];
        end
        if (g_pdef) begin
          r_defv <= rb_wdata[F_POL_DEF_VERDICT_LSB +: 2]; r_defsetq <= rb_wdata[F_POL_DEF_SET_Q_LSB];
          r_defq <= rb_wdata[F_POL_DEF_QID_LSB +: 4];     r_deftc <= rb_wdata[F_POL_DEF_TC_LSB +: 3];
        end
        if (g_ptpid) begin r_tpid0 <= rb_wdata[15:0]; r_tpid1 <= rb_wdata[31:16]; end
        if (g_pvx)   r_vxport <= rb_wdata[15:0];
        if (g_ptc)   r_tcsrc <= rb_wdata[1:0];
        if (g_qmap)  r_tcqmap <= rb_wdata;
        if (g_rlp)   r_rlper <= (rb_wdata[15:0] == 16'd0) ? 16'd1 : rb_wdata[15:0];
        if (g_smode) r_smode <= rb_wdata[1:0];
        if (g_sstv)  r_starve <= rb_wdata;
        if (g_squ)   r_quant <= rb_wdata[15:0];
        if (g_rss)   r_key[(32'd9 - 32'(rss_w)) * 32 +: 32] <= rb_wdata;
      end
      if (do_wr && reg_qcfg && q_in) begin
        case (qoff)
          5'(QC_PRIO):     r_qprio[qi*2 +: 2] <= rb_wdata[1:0];
          5'(QC_WEIGHT):   r_qweight[qi*8 +: 8] <= (rb_wdata[7:0] == 8'd0) ? 8'd1 : rb_wdata[7:0];
          5'(QC_RL_INC):   r_qrlinc[qi*16 +: 16] <= rb_wdata[15:0];
          5'(QC_RL_BURST): r_qrlburst[qi*24 +: 24] <= rb_wdata[23:0];
          5'(QC_WM):       r_qwm[qi*32 +: 32] <= rb_wdata;
          default: ;
        endcase
      end
      if (do_wr && reg_ten && t_in && is_adm) begin
        case (toff)
          4'(TN_SCOPE_VID): begin t_vid[ti*12 +: 12] <= rb_wdata[11:0]; t_vidv[ti] <= rb_wdata[16]; end
          4'(TN_SCOPE_VNI): begin t_vni[ti*24 +: 24] <= rb_wdata[23:0]; t_vniv[ti] <= rb_wdata[31]; end
          4'(TN_QMASK):     t_qm[ti*16 +: 16] <= rb_wdata[15:0];
          4'(TN_ENABLE):    t_en[ti] <= rb_wdata[0];
          default: ;
        endcase
      end
      if (do_wr && reg_own && o_in && is_adm) r_owner[oi*4 +: 4] <= rb_wdata[3:0];

      // ---- staging window ---------------------------------------------------------------------------------------------
      if (stg_wr && stg_claim) r_stage_owner <= t;          // word writes / clearing happen in g_stg

      // ---- rule commands --------------------------------------------------------------------------------------------------
      if (cmd_go) begin
        r_rstat[(32'(t) < NT ? t : 4'd0)*4 +: 4] <= cs;
        r_rseq[(32'(t) < NT ? t : 4'd0)*8 +: 8]  <= r_rseq[(32'(t) < NT ? t : 4'd0)*8 +: 8] + 8'd1;
        if (c_commit) begin
          act_pv <= 1'b1; act_pidx <= cidx; act_pdat <= stage_rule[AW-1:0];     // match table: g_rl, this edge
        end
        if (c_clear) begin
          act_pv <= 1'b1; act_pidx <= cidx; act_pdat <= '0;
        end
        if (c_read) r_stage_owner <= t;                                           // window words: g_stg
      end
    end
  end

  // ---------------------------------------------------------------------------------------------------
  // rule table, action-table copy and staging window: one register per rule / per word
  // ---------------------------------------------------------------------------------------------------
  reg [RW-1:0] rule_sel;                                   // selected rule (for the READ command), AND-OR mux
  always_comb begin
    rule_sel = '0;
    if (ENABLE_RULE_READ) begin
      for (int r = 0; r < NR; r++) rule_sel = rule_sel | ({RW{cidx == 8'(r)}} & r_rules[r*RW +: RW]);
    end
  end
  wire [NRW*32-1:0] rule_sel_p = {{(NRW*32-RW){1'b0}}, rule_sel};
  wire              stg_wr    = do_wr && reg_stg && (si < 8'(NRW));
  wire              stg_claim = (r_stage_owner != t);
  wire              stg_load  = cmd_go && c_read;
  wire              rl_wr_any = cmd_go && (c_commit || c_clear);

  genvar gk, gl;
  generate
    for (gk = 0; gk < NRW; gk = gk + 1) begin : g_stg
      reg [31:0] sw;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)          sw <= 32'd0;
        else if (stg_load)   sw <= rule_sel_p[gk*32 +: 32];
        else if (stg_wr) begin
          if (si == 8'(gk))  sw <= rb_wdata;
          else if (stg_claim) sw <= 32'd0;                 // claiming the window clears every other word
        end
      end
      assign r_stage[gk*32 +: 32] = sw;
    end
    for (gl = 0; gl < NR; gl = gl + 1) begin : g_rl
      reg [RW-1:0] rq;
      reg [AW-1:0] aq;
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)                           rq <= '0;
        else if (rl_wr_any && cidx == 8'(gl)) rq <= c_clear ? {RW{1'b0}} : stage_rule;
      end
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)                           aq <= '0;
        else if (act_pv && act_pidx == 8'(gl)) aq <= act_pdat;   // one cycle after the match table (pipeline aligned)
      end
      assign r_rules[gl*RW +: RW] = rq;
      assign r_acts[gl*AW +: AW]  = aq;
    end
  endgenerate

  // ---------------------------------------------------------------------------------------------------
  // outputs
  // ---------------------------------------------------------------------------------------------------
  assign cfg_enable        = r_en;
  assign cfg_cnt_en        = r_cnten;
  assign cfg_malformed_act = r_malf;
  assign cfg_unsupp_act    = r_unsupp;
  assign cfg_frag_act      = r_frag;
  assign cfg_csum_en       = r_csum;
  assign cfg_vxlan_en      = r_vxlan && ENABLE_VXLAN;
  assign cfg_qdrop         = r_qdrop;
  assign cfg_min_len       = r_minlen;
  assign cfg_max_len       = r_maxlen;
  assign cfg_def_verdict   = r_defv;
  assign cfg_def_setq      = r_defsetq;
  assign cfg_def_qid       = r_defq;
  assign cfg_def_tc        = r_deftc;
  assign cfg_tpid0         = r_tpid0;
  assign cfg_tpid1         = r_tpid1;
  assign cfg_vxlan_port    = r_vxport;
  assign cfg_tc_src        = r_tcsrc;
  assign cfg_tc_qmap       = r_tcqmap;
  assign cfg_rl_period     = r_rlper;
  assign cfg_sched_mode    = r_smode;
  assign cfg_starve        = r_starve;
  assign cfg_quant         = r_quant;
  assign cfg_rss_key       = r_key;
  assign q_prio            = r_qprio;
  assign q_weight          = r_qweight;
  assign q_rl_inc          = r_qrlinc;
  assign q_rl_burst        = r_qrlburst;
  assign q_wm              = r_qwm;
  assign rule_flat         = r_rules;
  assign act_flat          = r_acts;

  genvar gr;
  generate
    for (gr = 0; gr < NR; gr = gr + 1) begin : g_rule
      wire [3:0]    ow     = r_owner[gr*4 +: 4];
      wire          scoped = (ow != 4'd0);
      wire [RW-1:0] rl     = r_rules[gr*RW +: RW];
      // owner's tenant entry: AND-OR over the (few) tenants (a variable part-select would synthesise as a barrel shifter)
      reg           ow_ok, t_en_o, vidv_o, vniv_o;
      reg [11:0]    vid_o;
      reg [23:0]    vni_o;
      reg [15:0]    qm_o;
      always_comb begin
        ow_ok = 1'b0; t_en_o = 1'b0; vidv_o = 1'b0; vniv_o = 1'b0; vid_o = 12'd0; vni_o = 24'd0; qm_o = 16'd0;
        for (int tt = 0; tt < NT; tt++) begin
          if (ow == 4'(tt)) begin
            ow_ok  = 1'b1;
            t_en_o = t_en[tt];     vidv_o = t_vidv[tt];   vniv_o = t_vniv[tt];
            vid_o  = t_vid[tt*12 +: 12];  vni_o = t_vni[tt*24 +: 24];  qm_o = t_qm[tt*16 +: 16];
          end
        end
      end
      wire          ten_ok = ow_ok && t_en_o && rule_pol_ok(rl, qm_o);
      assign rl_eff_valid[gr] = rl[RL_VALID_LSB] && (!scoped || ten_ok);
      assign rl_scoped[gr]    = scoped;
      assign rl_sc_vidv[gr]   = ow_ok && vidv_o;
      assign rl_sc_vid[gr*12 +: 12] = vid_o;
      assign rl_sc_vniv[gr]   = ow_ok && vniv_o;
      assign rl_sc_vni[gr*24 +: 24] = vni_o;
    end
  endgenerate
  /* verilator lint_on WIDTHCONCAT */
  /* verilator lint_on WIDTHTRUNC */
endmodule

`default_nettype wire
