// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_classifier -- match/action lookup and decision
//
// Exact lookup semantics (also in docs/CLASSIFIER.md):
//   1. A rule matches iff  eff_valid[r]  &&  scope_ok[r]  &&  for every field ((key ^ value) & mask) == 0.
//      eff_valid already folds in the owner tenant's enable and policy (see sf_pkt_regs).
//      scope_ok: administrator-owned rules are unscoped; tenant-owned rules additionally require the packet
//      to be inside the tenant's scope (outer VLAN id == scope VID, or VXLAN VNI == scope VNI).
//   2. The LOWEST-numbered matching rule wins (TCAM order).
//   3. Error overrides precede the lookup (the lookup does not run for these packets):
//        parser error      -> malformed policy (DROP | PUNT)
//        unsupported chain -> unsupported policy (DROP | PUNT | CONT)
//        IP fragment       -> fragment policy (DROP | PUNT | CONT)
//      CONT = classify normally on the fields that were parsed (L3 only for fragments).
//   4. No match -> default verdict.  TC = rule.set_tc ? rule.tc : base_tc, where base_tc comes from the
//      POL_TC.tc_src policy (VLAN PCP / IP DSCP[5:3] / default tc).  Queue = rule.set_queue ? rule.qid :
//      rule.qsel_hash ? rule.qid + (flow_hash & (2^hash_bits-1)) : default-set ? def_qid : tc_qmap[tc].
//      Queues >= NQ fall back to queue 0.
//   5. Optional rewrite (rule.set_dscp / rule.dec_ttl) on verified IPv4 (checksum ok) and IPv6 headers, FWD
//      only.  TTL/hop-limit <= 1 with dec_ttl -> punt to management (reason TTL), packet unmodified.
//      IPv4 checksum is updated per RFC 1624 eq.3 for each changed 16-bit word.
// Pipeline: C1 match -> C2 first-hit + action fetch -> C3 decision (3 cycles after the parser token).
// The action table is the rule table's copy delayed by exactly one cycle (see sf_pkt_regs) so a rule
// update is atomic per packet: a packet never sees the old match with the new action.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_pkt_macros.svh"
`default_nettype none

module sf_pkt_classifier #(
  parameter int NQ             = 4,
  parameter int NR             = 16,
  parameter bit ENABLE_REWRITE = 1'b1
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  input  wire logic                       tok_valid,
  input  wire logic [`SFP_TK_W-1:0]       tok,
  // rule tables (flattened) and per-rule derived state
  input  wire logic [NR*`SFP_RL_W-1:0]    rule_flat,
  input  wire logic [NR*`SFP_RL_ACT_W-1:0] act_flat,
  input  wire logic [NR-1:0]              rl_eff_valid,
  input  wire logic [NR-1:0]              rl_scoped,
  input  wire logic [NR-1:0]              rl_sc_vidv,
  input  wire logic [NR*12-1:0]           rl_sc_vid,
  input  wire logic [NR-1:0]              rl_sc_vniv,
  input  wire logic [NR*24-1:0]           rl_sc_vni,
  // policy
  input  wire logic [1:0]                 cfg_malformed_act,
  input  wire logic [1:0]                 cfg_unsupp_act,
  input  wire logic [1:0]                 cfg_frag_act,
  input  wire logic [1:0]                 cfg_def_verdict,
  input  wire logic                       cfg_def_setq,
  input  wire logic [3:0]                 cfg_def_qid,
  input  wire logic [2:0]                 cfg_def_tc,
  input  wire logic [1:0]                 cfg_tc_src,
  input  wire logic [31:0]                cfg_tc_qmap,
  // decision
  output logic                            dec_valid,
  output logic [`SFP_DC_W-1:0]            dec,
  // events aligned with dec_valid
  output logic                            ev_parse_err,
  output logic                            ev_parse_unsupp,
  output logic                            ev_parse_frag,
  // pipeline occupancy (for safe rule commits / debug)
  output logic                            busy
);
  `include "sf_pkt_defs.svh"

  // carried-field layout
  localparam int CF_PERR = 0,  CF_UNS = 4,  CF_FRAG = 7,  CF_VCNT = 8,  CF_PCP = 10, CF_L3T = 13,
                 CF_TC = 15,   CF_TTL = 23, CF_PROTO = 31, CF_W0 = 39,  CF_CSUM = 55, CF_L3OFF = 71,
                 CF_NEED = 79, CF_HASH = 95, CF_CSOK = 127, CF_W = 128;

  // ---------------------------------------------------------------------------------------------------
  // C1: per-rule match
  // ---------------------------------------------------------------------------------------------------
  wire [7:0]   k_src   = tok[TK_SRC_ID_LSB +: TK_SRC_ID_W];
  wire         k_frag  = tok[TK_IP_FRAG_LSB];
  wire         k_vlanv = (tok[TK_VLAN_CNT_LSB +: TK_VLAN_CNT_W] != 2'd0);
  wire [11:0]  k_vid   = tok[TK_VLAN_VID_LSB +: TK_VLAN_VID_W];
  wire [2:0]   k_pcp   = tok[TK_VLAN_PCP_LSB +: TK_VLAN_PCP_W];
  wire [15:0]  k_etype = tok[TK_ETHERTYPE_LSB +: TK_ETHERTYPE_W];
  wire [47:0]  k_dmac  = tok[TK_DMAC_LSB +: TK_DMAC_W];
  wire [1:0]   k_l3t   = tok[TK_L3_TYPE_LSB +: TK_L3_TYPE_W];
  wire [7:0]   k_proto = tok[TK_IP_PROTO_LSB +: TK_IP_PROTO_W];
  wire [5:0]   k_dscp  = tok[TK_IP_TC_LSB + 2 +: 6];
  wire [127:0] k_sip   = tok[TK_SIP_LSB +: TK_SIP_W];
  wire [127:0] k_dip   = tok[TK_DIP_LSB +: TK_DIP_W];
  wire [15:0]  k_sport = tok[TK_SPORT_LSB +: TK_SPORT_W];
  wire [15:0]  k_dport = tok[TK_DPORT_LSB +: TK_DPORT_W];
  wire [7:0]   k_flags = tok[TK_TCP_FLAGS_LSB +: TK_TCP_FLAGS_W];
  wire         k_vniv  = tok[TK_VNI_VALID_LSB];
  wire [23:0]  k_vni   = tok[TK_VNI_LSB +: TK_VNI_W];

  wire [CF_W-1:0] cf_in;
  assign cf_in[CF_PERR +: 4]   = tok[TK_PERR_LSB +: TK_PERR_W];
  assign cf_in[CF_UNS  +: 3]   = tok[TK_UNSUPP_LSB +: TK_UNSUPP_W];
  assign cf_in[CF_FRAG]        = tok[TK_IP_FRAG_LSB];
  assign cf_in[CF_VCNT +: 2]   = tok[TK_VLAN_CNT_LSB +: TK_VLAN_CNT_W];
  assign cf_in[CF_PCP  +: 3]   = tok[TK_VLAN_PCP_LSB +: TK_VLAN_PCP_W];
  assign cf_in[CF_L3T  +: 2]   = tok[TK_L3_TYPE_LSB +: TK_L3_TYPE_W];
  assign cf_in[CF_TC   +: 8]   = tok[TK_IP_TC_LSB +: TK_IP_TC_W];
  assign cf_in[CF_TTL  +: 8]   = tok[TK_IP_TTL_LSB +: TK_IP_TTL_W];
  assign cf_in[CF_PROTO +: 8]  = tok[TK_IP_PROTO_LSB +: TK_IP_PROTO_W];
  assign cf_in[CF_W0   +: 16]  = tok[TK_IP_W0_LSB +: TK_IP_W0_W];
  assign cf_in[CF_CSUM +: 16]  = tok[TK_IP_CSUM_LSB +: TK_IP_CSUM_W];
  assign cf_in[CF_L3OFF +: 8]  = tok[TK_L3_OFF_LSB +: TK_L3_OFF_W];
  assign cf_in[CF_NEED +: 16]  = tok[TK_NEED_LEN_LSB +: TK_NEED_LEN_W];
  assign cf_in[CF_HASH +: 32]  = tok[TK_FLOW_HASH_LSB +: TK_FLOW_HASH_W];
  assign cf_in[CF_CSOK]        = tok[TK_CSUM_OK_LSB];

  wire [NR-1:0] match_c;
  genvar gr;
  generate
    for (gr = 0; gr < NR; gr = gr + 1) begin : g_match
      wire [`SFP_RL_W-1:0] rl = rule_flat[gr*`SFP_RL_W +: `SFP_RL_W];
      wire m_src   = ~|((k_src   ^ rl[RL_SRC_ID_V_LSB +: 8])    & rl[RL_SRC_ID_M_LSB +: 8]);
      wire m_frag  = ~|((k_frag  ^ rl[RL_FRAG_V_LSB])           & rl[RL_FRAG_M_LSB]);
      wire m_vlanv = ~|((k_vlanv ^ rl[RL_VLAN_VALID_V_LSB])     & rl[RL_VLAN_VALID_M_LSB]);
      wire m_vid   = ~|((k_vid   ^ rl[RL_VID_V_LSB +: 12])      & rl[RL_VID_M_LSB +: 12]);
      wire m_pcp   = ~|((k_pcp   ^ rl[RL_PCP_V_LSB +: 3])       & rl[RL_PCP_M_LSB +: 3]);
      wire m_etype = ~|((k_etype ^ rl[RL_ETHERTYPE_V_LSB +: 16]) & rl[RL_ETHERTYPE_M_LSB +: 16]);
      wire m_dmac  = ~|((k_dmac  ^ rl[RL_DMAC_V_LSB +: 48])     & rl[RL_DMAC_M_LSB +: 48]);
      wire m_l3t   = ~|((k_l3t   ^ rl[RL_L3_TYPE_V_LSB +: 2])   & rl[RL_L3_TYPE_M_LSB +: 2]);
      wire m_proto = ~|((k_proto ^ rl[RL_IP_PROTO_V_LSB +: 8])  & rl[RL_IP_PROTO_M_LSB +: 8]);
      wire m_dscp  = ~|((k_dscp  ^ rl[RL_DSCP_V_LSB +: 6])      & rl[RL_DSCP_M_LSB +: 6]);
      wire m_sip   = ~|((k_sip   ^ rl[RL_SIP_V_LSB +: 128])     & rl[RL_SIP_M_LSB +: 128]);
      wire m_dip   = ~|((k_dip   ^ rl[RL_DIP_V_LSB +: 128])     & rl[RL_DIP_M_LSB +: 128]);
      wire m_sport = ~|((k_sport ^ rl[RL_SPORT_V_LSB +: 16])    & rl[RL_SPORT_M_LSB +: 16]);
      wire m_dport = ~|((k_dport ^ rl[RL_DPORT_V_LSB +: 16])    & rl[RL_DPORT_M_LSB +: 16]);
      wire m_flags = ~|((k_flags ^ rl[RL_TCP_FLAGS_V_LSB +: 8]) & rl[RL_TCP_FLAGS_M_LSB +: 8]);
      wire m_vniv  = ~|((k_vniv  ^ rl[RL_VNI_VALID_V_LSB])      & rl[RL_VNI_VALID_M_LSB]);
      wire m_vni   = ~|((k_vni   ^ rl[RL_VNI_V_LSB +: 24])      & rl[RL_VNI_M_LSB +: 24]);
      wire scope_ok = !rl_scoped[gr] ||
                      (rl_sc_vidv[gr] && k_vlanv && (k_vid == rl_sc_vid[gr*12 +: 12])) ||
                      (rl_sc_vniv[gr] && k_vniv  && (k_vni == rl_sc_vni[gr*24 +: 24]));
      assign match_c[gr] = rl_eff_valid[gr] && scope_ok && m_src && m_frag && m_vlanv && m_vid && m_pcp &&
                           m_etype && m_dmac && m_l3t && m_proto && m_dscp && m_sip && m_dip && m_sport &&
                           m_dport && m_flags && m_vniv && m_vni;
    end
  endgenerate

  reg                c1_v;
  reg [NR-1:0]       c1_match;
  reg [CF_W-1:0]     c1_cf;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) c1_v <= 1'b0;
    else        c1_v <= tok_valid;
  end
  always_ff @(posedge clk) begin
    c1_match <= match_c;
    c1_cf    <= cf_in;
  end

  // ---------------------------------------------------------------------------------------------------
  // C2: first hit + action fetch
  // ---------------------------------------------------------------------------------------------------
  reg            hit_c;
  reg [7:0]      idx_c;
  always_comb begin
    hit_c = 1'b0;
    idx_c = 8'd0;
    for (int r = NR - 1; r >= 0; r--) begin
      if (c1_match[r]) begin
        hit_c = 1'b1;
        idx_c = 8'(r);
      end
    end
  end
  wire [`SFP_RL_ACT_W-1:0] act_c = act_flat[idx_c*`SFP_RL_ACT_W +: `SFP_RL_ACT_W];

  reg                       c2_v, c2_hit;
  reg [7:0]                 c2_idx;
  reg [`SFP_RL_ACT_W-1:0]   c2_act;
  reg [CF_W-1:0]            c2_cf;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) c2_v <= 1'b0;
    else        c2_v <= c1_v;
  end
  always_ff @(posedge clk) begin
    c2_hit <= hit_c;
    c2_idx <= idx_c;
    c2_act <= act_c;
    c2_cf  <= c1_cf;
  end

  // ---------------------------------------------------------------------------------------------------
  // C3: decision
  // ---------------------------------------------------------------------------------------------------
  function automatic [15:0] csum_upd(input [15:0] hc, input [15:0] m, input [15:0] m2);
    reg [18:0] s;
    begin
      s = {3'b000, ~hc} + {3'b000, ~m} + {3'b000, m2};
      s = {3'b000, s[15:0]} + {16'd0, s[18:16]};
      s = {3'b000, s[15:0]} + {16'd0, s[18:16]};
      csum_upd = ~s[15:0];
    end
  endfunction

  wire [3:0]  f_perr  = c2_cf[CF_PERR +: 4];
  wire [2:0]  f_uns   = c2_cf[CF_UNS +: 3];
  wire        f_frag  = c2_cf[CF_FRAG];
  wire [1:0]  f_vcnt  = c2_cf[CF_VCNT +: 2];
  wire [2:0]  f_pcp   = c2_cf[CF_PCP +: 3];
  wire [1:0]  f_l3t   = c2_cf[CF_L3T +: 2];
  wire [7:0]  f_tc    = c2_cf[CF_TC +: 8];
  wire [7:0]  f_ttl   = c2_cf[CF_TTL +: 8];
  wire [7:0]  f_proto = c2_cf[CF_PROTO +: 8];
  wire [15:0] f_w0    = c2_cf[CF_W0 +: 16];
  wire [15:0] f_csum  = c2_cf[CF_CSUM +: 16];
  wire [7:0]  f_l3off = c2_cf[CF_L3OFF +: 8];
  wire [15:0] f_need  = c2_cf[CF_NEED +: 16];
  wire [31:0] f_hash  = c2_cf[CF_HASH +: 32];
  wire        f_csok  = c2_cf[CF_CSOK];

  wire [1:0]  a_verdict = c2_act[RL_VERDICT_LSB +: RL_VERDICT_W];
  wire        a_setq    = c2_act[RL_SET_QUEUE_LSB];
  wire [3:0]  a_qid     = c2_act[RL_QID_LSB +: RL_QID_W];
  wire        a_hash    = c2_act[RL_QSEL_HASH_LSB];
  wire [1:0]  a_hbits   = c2_act[RL_HASH_BITS_LSB +: RL_HASH_BITS_W];
  wire        a_settc   = c2_act[RL_SET_TC_LSB];
  wire [2:0]  a_tc      = c2_act[RL_TC_LSB +: RL_TC_W];
  wire        a_count   = c2_act[RL_COUNT_LSB];
  wire        a_setdscp = c2_act[RL_SET_DSCP_LSB];
  wire [5:0]  a_dscp    = c2_act[RL_DSCP_LSB +: RL_DSCP_W];
  wire        a_dectt   = c2_act[RL_DEC_TTL_LSB];

  reg [`SFP_DC_W-1:0] d_c;
  reg                 e_perr_c, e_uns_c, e_frag_c;

  reg [1:0]   v;
  reg [4:0]   q5;
  reg [3:0]   q;
  reg [2:0]   tc, tc_base;
  reg [3:0]   reason;
  reg         ovr, hit_eff;
  reg [1:0]   ovr_act;
  reg         is4, is6, rw_ok, want_dscp, want_ttl, ttl_exp;
  reg [3:0]   pen;
  reg [7:0]   po0, po1, po2, po3, pv0, pv1, pv2, pv3;
  reg [7:0]   tos_new, tc_new, ttl_new;
  reg [15:0]  w0_new, w4_old, w4_new, cs1, cs2;
  reg         ch0, ch4;
  reg [3:0]   hmask;

  always_comb begin
    // ---- error overrides -----------------------------------------------------------------------------
    ovr     = 1'b0;
    ovr_act = 2'd0;
    reason  = 4'd0;
    if (f_perr != 4'(PE_NONE)) begin
      ovr = 1'b1; ovr_act = (cfg_malformed_act == 2'(ACT_PUNT)) ? 2'(ACT_PUNT) : 2'(ACT_DROP);
      reason = (ovr_act == 2'(ACT_PUNT)) ? 4'(PR_MALFORMED) : 4'(DR_MALFORMED);
    end else if (f_uns != 3'(UN_NONE) && cfg_unsupp_act != 2'(ACT_CONT)) begin
      ovr = 1'b1; ovr_act = (cfg_unsupp_act == 2'(ACT_PUNT)) ? 2'(ACT_PUNT) : 2'(ACT_DROP);
      reason = (ovr_act == 2'(ACT_PUNT)) ? 4'(PR_UNSUPP) : 4'(DR_UNSUPP);
    end else if (f_frag && cfg_frag_act != 2'(ACT_CONT)) begin
      ovr = 1'b1; ovr_act = (cfg_frag_act == 2'(ACT_PUNT)) ? 2'(ACT_PUNT) : 2'(ACT_DROP);
      reason = (ovr_act == 2'(ACT_PUNT)) ? 4'(PR_FRAG) : 4'(DR_FRAG);
    end
    hit_eff = c2_hit && !ovr;

    // ---- traffic class -------------------------------------------------------------------------------------
    case (cfg_tc_src)
      2'(TCSRC_PCP):  tc_base = (f_vcnt != 2'd0) ? f_pcp : 3'd0;
      2'(TCSRC_DSCP): tc_base = (f_l3t != 2'(L3_NONE)) ? f_tc[7:5] : 3'd0;
      default:        tc_base = cfg_def_tc;
    endcase
    tc = (hit_eff && a_settc) ? a_tc : tc_base;

    // ---- verdict / queue ----------------------------------------------------------------------------------
    if (ovr)          v = (ovr_act == 2'(ACT_PUNT)) ? 2'(VERD_MGMT) : 2'(VERD_DROP);
    else if (hit_eff) v = a_verdict;
    else              v = cfg_def_verdict;
    if (v == 2'd3) v = 2'(VERD_DROP);              // reserved encoding fails closed

    hmask = (a_hbits == 2'd0) ? 4'd0 : (a_hbits == 2'd1) ? 4'd1 : (a_hbits == 2'd2) ? 4'd3 : 4'd7;
    if (hit_eff && a_setq)        q5 = {1'b0, a_qid};
    else if (hit_eff && a_hash)   q5 = {1'b0, a_qid} + {2'b00, f_hash[2:0] & hmask[2:0]};
    else if (!hit_eff && cfg_def_setq) q5 = {1'b0, cfg_def_qid};
    else                          q5 = {1'b0, cfg_tc_qmap[4*tc +: 4]};
    q = (q5 >= 5'(NQ)) ? 4'd0 : q5[3:0];

    if (!ovr) begin
      if (v == 2'(VERD_DROP)) reason = 4'(DR_RULE);
      else if (v == 2'(VERD_MGMT)) reason = hit_eff ? 4'(PR_RULE) : 4'(PR_DEFAULT);
    end

    // ---- optional rewrite -------------------------------------------------------------------------------------
    is4 = (f_l3t == 2'(L3_IPV4));
    is6 = (f_l3t == 2'(L3_IPV6));
    want_dscp = ENABLE_REWRITE && hit_eff && a_setdscp;
    want_ttl  = ENABLE_REWRITE && hit_eff && a_dectt;
    rw_ok     = (v == 2'(VERD_FWD)) && (is6 || (is4 && f_csok)) && (want_dscp || want_ttl);
    ttl_exp   = rw_ok && want_ttl && (f_ttl <= 8'd1);
    if (ttl_exp) begin
      v = 2'(VERD_MGMT);
      reason = 4'(PR_TTL);
      rw_ok = 1'b0;
    end

    pen = 4'd0; po0 = 8'd0; po1 = 8'd0; po2 = 8'd0; po3 = 8'd0; pv0 = 8'd0; pv1 = 8'd0; pv2 = 8'd0; pv3 = 8'd0;
    tos_new = f_tc; tc_new = f_tc; ttl_new = f_ttl; w0_new = f_w0; w4_old = 16'd0; w4_new = 16'd0;
    cs1 = f_csum; cs2 = f_csum; ch0 = 1'b0; ch4 = 1'b0;
    if (rw_ok) begin
      ttl_new = want_ttl ? (f_ttl - 8'd1) : f_ttl;
      if (is4) begin
        tos_new = want_dscp ? {a_dscp, f_tc[1:0]} : f_tc;
        w0_new  = {f_w0[15:8], tos_new};
        w4_old  = {f_ttl, f_proto};
        w4_new  = {ttl_new, f_proto};
        ch0 = (w0_new != f_w0);
        ch4 = (w4_new != w4_old);
        cs1 = ch0 ? csum_upd(f_csum, f_w0, w0_new) : f_csum;
        cs2 = ch4 ? csum_upd(cs1, w4_old, w4_new) : cs1;
        pen[0] = ch0;  po0 = f_l3off + 8'd1;  pv0 = tos_new;
        pen[1] = ch4;  po1 = f_l3off + 8'd8;  pv1 = ttl_new;
        pen[2] = ch0 || ch4; po2 = f_l3off + 8'd10; pv2 = cs2[15:8];
        pen[3] = ch0 || ch4; po3 = f_l3off + 8'd11; pv3 = cs2[7:0];
      end else begin
        tc_new = want_dscp ? {a_dscp, f_tc[1:0]} : f_tc;
        ch0 = (tc_new != f_tc);
        pen[0] = ch0;       po0 = f_l3off;         pv0 = {f_w0[15:12], tc_new[7:4]};
        pen[1] = ch0;       po1 = f_l3off + 8'd1;  pv1 = {tc_new[3:0], f_w0[3:0]};
        pen[2] = want_ttl;  po2 = f_l3off + 8'd7;  pv2 = ttl_new;
      end
    end

    // ---- pack --------------------------------------------------------------------------------------------------------
    d_c = {`SFP_DC_W{1'b0}};
    d_c[DC_VERDICT_LSB +: DC_VERDICT_W]  = v;
    d_c[DC_QID_LSB +: DC_QID_W]          = q;
    d_c[DC_TC_LSB +: DC_TC_W]            = tc;
    d_c[DC_REASON_LSB +: DC_REASON_W]    = reason;
    d_c[DC_RULE_HIT_LSB]                 = hit_eff;
    d_c[DC_RULE_IDX_LSB +: DC_RULE_IDX_W] = hit_eff ? c2_idx : 8'd0;
    d_c[DC_COUNT_LSB]                    = hit_eff && a_count;
    d_c[DC_NEED_LEN_LSB +: DC_NEED_LEN_W] = f_need;
    d_c[DC_FLOW_HASH_LSB +: DC_FLOW_HASH_W] = f_hash;
    d_c[DC_PATCH_EN_LSB +: DC_PATCH_EN_W] = pen;
    d_c[DC_PATCH_OFF0_LSB +: 8] = po0;  d_c[DC_PATCH_OFF1_LSB +: 8] = po1;
    d_c[DC_PATCH_OFF2_LSB +: 8] = po2;  d_c[DC_PATCH_OFF3_LSB +: 8] = po3;
    d_c[DC_PATCH_VAL0_LSB +: 8] = pv0;  d_c[DC_PATCH_VAL1_LSB +: 8] = pv1;
    d_c[DC_PATCH_VAL2_LSB +: 8] = pv2;  d_c[DC_PATCH_VAL3_LSB +: 8] = pv3;
    d_c[DC_REWROTE_LSB]                  = (pen != 4'd0);
    e_perr_c = (f_perr != 4'(PE_NONE));
    e_uns_c  = (f_perr == 4'(PE_NONE)) && (f_uns != 3'(UN_NONE));
    e_frag_c = (f_perr == 4'(PE_NONE)) && f_frag;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      dec_valid       <= 1'b0;
      ev_parse_err    <= 1'b0;
      ev_parse_unsupp <= 1'b0;
      ev_parse_frag   <= 1'b0;
    end else begin
      dec_valid       <= c2_v;
      ev_parse_err    <= c2_v && e_perr_c;
      ev_parse_unsupp <= c2_v && e_uns_c;
      ev_parse_frag   <= c2_v && e_frag_c;
    end
  end
  always_ff @(posedge clk) dec <= d_c;
  assign busy = c1_v || c2_v;
endmodule

`default_nettype wire
