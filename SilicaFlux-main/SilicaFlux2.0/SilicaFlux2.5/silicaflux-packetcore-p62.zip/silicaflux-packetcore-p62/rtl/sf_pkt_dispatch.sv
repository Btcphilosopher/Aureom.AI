// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_dispatch -- decision-driven packet steering into the egress queues
//
//   Consumes, in lock-step per packet:  delay-FIFO beats  +  one decision  +  one sideband record.
//   * Beats are written speculatively into the selected queue (or the management queue); the packet
//     only becomes visible on a COMMIT at its last beat, so any late failure simply ABORTS it.
//   * Late checks (need the whole frame): MAC error flag, illegal keep pattern, runt, oversize,
//     declared-IP-length > received length.  Priority (first match = reported reason):
//        MACERR > KEEP > OVERSIZE > RUNT > classifier DROP reason > LENMIS > QFULL
//   * Queue full: lossless mode stalls the whole ingress (head-of-line blocking, documented);
//     tail-drop mode (cfg_qdrop) discards the packet.  The management queue is ALWAYS tail-drop so a
//     stalled CPU port can never block the data plane.
//   * Header rewrite (optional): up to 4 byte patches {offset,value} carried in the decision are applied
//     in-flight (DSCP / TTL / IPv4 checksum bytes).  No other byte is ever modified.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sf_pkt_macros.svh"
`default_nettype none

module sf_pkt_dispatch #(
  parameter int DW              = 128,
  parameter int NQ              = 4,
  parameter int SRC_W           = 4,
  parameter int META_W          = 16,
  parameter bit ENABLE_REWRITE  = 1'b1,
  parameter int DESC_W          = 87 + SRC_W + META_W,
  parameter int SB_W            = SRC_W + META_W + 32
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic [31:0]         now,
  // delay FIFO head (FWFT)
  input  wire logic                d_valid,
  input  wire logic [DW-1:0]       d_data,
  input  wire logic [DW/8-1:0]     d_keep,
  input  wire logic                d_last,
  input  wire logic                d_err,
  output logic                     d_pop,
  // decision + sideband heads (FWFT)
  input  wire logic                dec_valid,
  input  wire logic [`SFP_DC_W-1:0] dec,
  input  wire logic                sb_valid,
  input  wire logic [SB_W-1:0]     sb,
  output logic                     dec_pop,
  // configuration
  input  wire logic [15:0]         cfg_min_len,
  input  wire logic [15:0]         cfg_max_len,
  input  wire logic                cfg_qdrop,
  // queue write buses (index NQ = management queue)
  output logic [NQ:0]              q_wr_beat,
  output logic [NQ:0]              q_wr_commit,
  output logic [NQ:0]              q_wr_abort,
  output logic [DW-1:0]            wr_data,
  output logic [DW/8-1:0]          wr_keep,
  output logic                     wr_last,
  output logic [DESC_W-1:0]        wr_desc,
  input  wire logic [NQ:0]         q_space_ok,
  input  wire logic [NQ:0]         q_pkt_ok,
  // events (one-cycle pulses)
  output logic                     ev_end,
  output logic [15:0]              ev_len,
  output logic                     ev_commit,
  output logic                     ev_drop,
  output logic [3:0]               ev_reason,
  output logic [4:0]               ev_q,
  output logic                     ev_to_mgmt,
  output logic                     ev_ttl,
  output logic                     ev_rewrote,
  output logic                     ev_rule_cnt,
  output logic [7:0]               ev_rule_idx,
  output logic                     ev_lat_valid,
  output logic [31:0]              ev_lat
);
  `include "sf_pkt_defs.svh"

  localparam int DWB = DW / 8;
  localparam int LG  = $clog2(DWB);

  generate
    if (NQ < 1 || NQ > 16) begin : g_chk_nq initial $error("sf_pkt_dispatch: NQ must be 1..16"); end
  endgenerate

  function automatic [15:0] popcnt_f(input [DWB-1:0] k);
    integer i;
    reg [15:0] c;
    begin
      c = 16'd0;
      for (i = 0; i < DWB; i = i + 1) c = c + {15'd0, k[i]};
      popcnt_f = c;
    end
  endfunction

  // ---- decision decode ----------------------------------------------------------------------------
  wire [1:0]  verdict = dec[DC_VERDICT_LSB +: DC_VERDICT_W];
  wire [3:0]  qid     = dec[DC_QID_LSB +: DC_QID_W];
  wire [2:0]  tcv     = dec[DC_TC_LSB +: DC_TC_W];
  wire [3:0]  dreason = dec[DC_REASON_LSB +: DC_REASON_W];
  wire        rhit    = dec[DC_RULE_HIT_LSB];
  wire [7:0]  ridx    = dec[DC_RULE_IDX_LSB +: DC_RULE_IDX_W];
  wire        rcount  = dec[DC_COUNT_LSB];
  wire [15:0] needl   = dec[DC_NEED_LEN_LSB +: DC_NEED_LEN_W];
  wire [31:0] fhash   = dec[DC_FLOW_HASH_LSB +: DC_FLOW_HASH_W];
  wire [3:0]  pen     = dec[DC_PATCH_EN_LSB +: DC_PATCH_EN_W];
  wire        rewr    = dec[DC_REWROTE_LSB];

  wire [SRC_W-1:0]  sb_src  = sb[0 +: SRC_W];
  wire [META_W-1:0] sb_meta = sb[SRC_W +: META_W];
  wire [31:0]       sb_ts   = sb[SRC_W + META_W +: 32];

  // ---- packet state ---------------------------------------------------------------------------------
  reg         w_act, w_keepbad, w_over, w_ovf, w_written;
  reg [17:0]  w_len;
  reg [15:0]  w_bidx;

  wire        first = !w_act;
  wire        have  = d_valid && dec_valid && sb_valid;

  reg  [4:0]  tq;
  always_comb begin
    if (verdict == 2'(VERD_MGMT))  tq = 5'(NQ);
    else if ({1'b0, qid} >= 5'(NQ)) tq = 5'd0;       // 5-bit compare: NQ = 16 must not truncate
    else                           tq = {1'b0, qid};
  end

  wire [15:0] nbytes   = d_last ? popcnt_f(d_keep) : 16'(DWB);
  wire [18:0] sum19    = {1'b0, w_len} + {3'b000, nbytes};
  wire [17:0] len_new  = sum19[18] ? 18'h3FFFF : sum19[17:0];
  wire        keep_all = &d_keep;
  wire        keep_cnt = (d_keep != '0) && ((d_keep & (d_keep + 1'b1)) == '0);
  wire        keep_ok  = d_last ? keep_cnt : keep_all;
  wire        over_now = (len_new > {2'b00, cfg_max_len});
  wire        runt     = d_last && (len_new < {2'b00, cfg_min_len});
  wire        lenmis   = d_last && (len_new < {2'b00, needl});
  wire        cls_drop = (verdict == 2'(VERD_DROP));
  wire        good     = !cls_drop && !w_keepbad && !w_over && !w_ovf && keep_ok && !over_now;
  wire        late_bad = d_last && (d_err || runt || lenmis);
  wire        want_wr  = have && good && !late_bad;
  reg  [NQ:0] tq_oh;
  always_comb begin
    for (int q = 0; q <= NQ; q++) tq_oh[q] = (tq == 5'(q));
  end
  wire        sp_ok    = (|(q_space_ok & tq_oh)) && (first ? (|(q_pkt_ok & tq_oh)) : 1'b1);
  wire        drop_md  = cfg_qdrop || (tq == 5'(NQ));
  wire        sp_fail  = want_wr && !sp_ok;
  wire        stall    = have && sp_fail && !drop_md;
  wire        proc     = have && !stall;
  wire        do_wr    = want_wr && sp_ok;

  assign d_pop   = proc;
  assign dec_pop = proc && d_last;

  // ---- final reason -----------------------------------------------------------------------------------
  wire        keepbad_f = w_keepbad || !keep_ok;
  wire        over_f    = w_over || over_now;
  wire        ovf_f     = w_ovf || (sp_fail && drop_md);
  reg  [3:0]  reason_f;
  always_comb begin
    if (d_err)           reason_f = 4'(DR_MACERR);
    else if (keepbad_f)  reason_f = 4'(DR_KEEP);
    else if (over_f)     reason_f = 4'(DR_OVERSIZE);
    else if (runt)       reason_f = 4'(DR_RUNT);
    else if (cls_drop)   reason_f = dreason;
    else if (lenmis)     reason_f = 4'(DR_LENMIS);
    else if (ovf_f)      reason_f = 4'(DR_QFULL);
    else                 reason_f = 4'(DR_NONE);
  end

  // ---- in-flight patching -------------------------------------------------------------------------------
  wire [7:0] po0 = dec[DC_PATCH_OFF0_LSB +: 8];
  wire [7:0] po1 = dec[DC_PATCH_OFF1_LSB +: 8];
  wire [7:0] po2 = dec[DC_PATCH_OFF2_LSB +: 8];
  wire [7:0] po3 = dec[DC_PATCH_OFF3_LSB +: 8];
  wire [7:0] pv0 = dec[DC_PATCH_VAL0_LSB +: 8];
  wire [7:0] pv1 = dec[DC_PATCH_VAL1_LSB +: 8];
  wire [7:0] pv2 = dec[DC_PATCH_VAL2_LSB +: 8];
  wire [7:0] pv3 = dec[DC_PATCH_VAL3_LSB +: 8];

  always_comb begin
    wr_data = d_data;
    if (ENABLE_REWRITE) begin
      for (int k = 0; k < DWB; k++) begin
        if (pen[0] && (w_bidx == (16'(po0) >> LG)) && (po0[LG-1:0] == LG'(k))) wr_data[8*k +: 8] = pv0;
        if (pen[1] && (w_bidx == (16'(po1) >> LG)) && (po1[LG-1:0] == LG'(k))) wr_data[8*k +: 8] = pv1;
        if (pen[2] && (w_bidx == (16'(po2) >> LG)) && (po2[LG-1:0] == LG'(k))) wr_data[8*k +: 8] = pv2;
        if (pen[3] && (w_bidx == (16'(po3) >> LG)) && (po3[LG-1:0] == LG'(k))) wr_data[8*k +: 8] = pv3;
      end
    end
  end
  assign wr_keep = d_keep;
  assign wr_last = d_last;
  assign wr_desc = {sb_meta, sb_src, fhash, sb_ts, dreason, tcv, len_new[15:0]};

  // ---- queue controls ---------------------------------------------------------------------------------------
  wire final_commit = do_wr && d_last;
  always_comb begin
    for (int q = 0; q <= NQ; q++) begin
      q_wr_beat[q]   = do_wr && tq_oh[q];
      q_wr_commit[q] = final_commit && tq_oh[q];
      q_wr_abort[q]  = proc && d_last && !do_wr && w_written && tq_oh[q];
    end
  end

  // ---- events -----------------------------------------------------------------------------------------------------
  assign ev_end       = proc && d_last;
  assign ev_len       = (len_new > 18'h0FFFF) ? 16'hFFFF : len_new[15:0];
  assign ev_commit    = final_commit;
  assign ev_drop      = ev_end && !final_commit;
  assign ev_reason    = reason_f;
  assign ev_q         = tq;
  assign ev_to_mgmt   = final_commit && (tq == 5'(NQ));
  assign ev_ttl       = final_commit && (verdict == 2'(VERD_MGMT)) && (dreason == 4'(PR_TTL));
  assign ev_rewrote   = final_commit && (verdict == 2'(VERD_FWD)) && rewr;
  assign ev_rule_cnt  = ev_end && rhit && rcount;
  assign ev_rule_idx  = ridx;
  assign ev_lat_valid = proc && first;
  assign ev_lat       = now - sb_ts;

  // ---- state ----------------------------------------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      w_act     <= 1'b0;
      w_len     <= 18'd0;
      w_bidx    <= 16'd0;
      w_keepbad <= 1'b0;
      w_over    <= 1'b0;
      w_ovf     <= 1'b0;
      w_written <= 1'b0;
    end else if (proc) begin
      if (d_last) begin
        w_act     <= 1'b0;
        w_len     <= 18'd0;
        w_bidx    <= 16'd0;
        w_keepbad <= 1'b0;
        w_over    <= 1'b0;
        w_ovf     <= 1'b0;
        w_written <= 1'b0;
      end else begin
        w_act     <= 1'b1;
        w_len     <= len_new;
        w_bidx    <= w_bidx + 16'd1;
        w_keepbad <= w_keepbad || !keep_ok;
        w_over    <= w_over || over_now;
        w_ovf     <= w_ovf || (sp_fail && drop_md);
        w_written <= w_written || do_wr;
      end
    end
  end
endmodule

`default_nettype wire
