// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_queue -- packet FIFO with speculative write, commit / abort
//
//   Write side (single writer: the dispatcher)
//     wr_beat    write one beat at the speculative pointer (needs wr_space_ok)
//     wr_commit  with wr_beat on the packet's LAST beat: publish the packet and push its descriptor
//     wr_abort   (without wr_beat) discard every uncommitted beat -- the packet vanishes, nothing was visible
//   Read side (FWFT head beat, prefetched; zero bubble across packet boundaries)
//     Only committed beats are ever fetched, so a partially written / aborted packet is never visible.
//   Descriptors: DESC_W bits, FIFO of PKT_DEPTH entries; desc0/1/2 = head, head+1, head+2 (valid when
//   pkt_cnt > 0/1/2).  Convention: desc[15:0] = packet length in bytes.
//   Storage is a simple dual-port RAM with synchronous read (BRAM-friendly).
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_pkt_queue #(
  parameter int DW          = 128,
  parameter int DEPTH_BEATS = 1024,   // power of two
  parameter int PKT_DEPTH   = 64,     // power of two
  parameter int DESC_W      = 128
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  // write side
  input  wire logic                         wr_beat,
  input  wire logic [DW-1:0]                wr_data,
  input  wire logic [DW/8-1:0]              wr_keep,
  input  wire logic                         wr_last,
  input  wire logic                         wr_commit,
  input  wire logic [DESC_W-1:0]            wr_desc,
  input  wire logic                         wr_abort,
  output logic                              wr_space_ok,
  output logic                              wr_pkt_ok,
  // read side
  output logic                              rd_valid,
  output logic [DW-1:0]                     rd_data,
  output logic [DW/8-1:0]                   rd_keep,
  output logic                              rd_last,
  input  wire logic                         rd_pop,
  // packet info
  output logic [$clog2(PKT_DEPTH):0]        pkt_cnt,
  output logic [DESC_W-1:0]                 desc0,
  output logic [DESC_W-1:0]                 desc1,
  output logic [DESC_W-1:0]                 desc2,
  // occupancy (beats, includes uncommitted beats of the packet being written)
  output logic [$clog2(DEPTH_BEATS):0]      occ_beats
);
  localparam int DWB = DW / 8;
  localparam int AW  = $clog2(DEPTH_BEATS);
  localparam int PW  = AW + 1;
  localparam int DAW = $clog2(PKT_DEPTH);
  localparam int EW  = DW + DWB + 1;

  generate
    if ((DEPTH_BEATS & (DEPTH_BEATS - 1)) != 0) begin : g_chk_d initial $error("sf_pkt_queue: DEPTH_BEATS must be a power of two"); end
    if ((PKT_DEPTH & (PKT_DEPTH - 1)) != 0)     begin : g_chk_p initial $error("sf_pkt_queue: PKT_DEPTH must be a power of two"); end
  endgenerate

  reg [EW-1:0]       mem  [0:DEPTH_BEATS-1];
  reg [DESC_W-1:0]   dmem [0:PKT_DEPTH-1];

  reg [PW-1:0]  spec, commit, fetch, popp;
  reg [DAW-1:0] dwr, drd;
  reg [$clog2(PKT_DEPTH):0] pcnt;

  wire [PW-1:0] used = spec - popp;
  assign wr_space_ok = (used != PW'(DEPTH_BEATS));
  assign wr_pkt_ok   = (pcnt != (($clog2(PKT_DEPTH)+1)'(PKT_DEPTH)));
  assign occ_beats   = used[AW:0];
  assign pkt_cnt     = pcnt;

  // ---- write ------------------------------------------------------------------------------------
  always_ff @(posedge clk) begin
    if (wr_beat) mem[spec[AW-1:0]] <= {wr_last, wr_keep, wr_data};
  end
  wire commit_evt = wr_beat && wr_commit;
  always_ff @(posedge clk) begin
    if (commit_evt) dmem[dwr] <= wr_desc;
  end

  // ---- read pipeline ----------------------------------------------------------------------------
  reg            s1_v, h_v;
  reg [EW-1:0]   mq;
  reg [EW-1:0]   h;
  wire           h_free      = !h_v || rd_pop;
  wire           fetch_avail = (commit != fetch);
  wire           issue       = fetch_avail && (!s1_v || h_free);
  wire           pkt_pop_evt = rd_pop && h_v && h[EW-1];

  always_ff @(posedge clk) begin
    if (issue)  mq <= mem[fetch[AW-1:0]];
    if (h_free) h  <= mq;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      spec   <= '0;
      commit <= '0;
      fetch  <= '0;
      popp   <= '0;
      dwr    <= '0;
      drd    <= '0;
      pcnt   <= '0;
      s1_v   <= 1'b0;
      h_v    <= 1'b0;
    end else begin
      if (wr_abort)      spec <= commit;
      else if (wr_beat)  spec <= spec + 1'b1;
      if (commit_evt) begin
        commit <= spec + 1'b1;
        dwr    <= dwr + 1'b1;
      end
      if (issue) fetch <= fetch + 1'b1;
      s1_v <= issue || (s1_v && !h_free);
      if (h_free) h_v <= s1_v;
      if (rd_pop && h_v) popp <= popp + 1'b1;
      if (pkt_pop_evt) drd <= drd + 1'b1;
      case ({commit_evt, pkt_pop_evt})
        2'b10:   pcnt <= pcnt + 1'b1;
        2'b01:   pcnt <= pcnt - 1'b1;
        default: pcnt <= pcnt;
      endcase
    end
  end

  assign rd_valid = h_v;
  assign rd_data  = h[DW-1:0];
  assign rd_keep  = h[DW +: DWB];
  assign rd_last  = h[EW-1];

  assign desc0 = dmem[drd];
  assign desc1 = dmem[drd + DAW'(1)];
  assign desc2 = dmem[drd + DAW'(2)];
endmodule

`default_nettype wire
