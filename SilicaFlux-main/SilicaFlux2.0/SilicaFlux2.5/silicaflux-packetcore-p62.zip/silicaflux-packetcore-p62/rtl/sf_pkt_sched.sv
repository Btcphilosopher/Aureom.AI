// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_sched -- packet-atomic egress scheduler
//
//   Modes (cfg_mode):  0 RR   packet-granularity round robin among eligible queues
//                      1 SP   strict priority classes (q_prio 0 = highest), RR inside a class, plus an
//                             aging guard: an eligible queue passed over for >= cfg_starve cycles becomes
//                             URGENT and is served before any priority class (0 disables the guard)
//                      2 DWRR deficit-weighted RR in bytes; quantum(q) = weight(q) * cfg_quant; deficits are
//                             replenished for all eligible queues when none can afford its head packet;
//                             a queue with nothing queued has its deficit reset (classic DRR)
//   Rate limit (per queue, optional when q_rl_inc != 0): signed token bucket.  Every cfg_rl_period clocks
//     the bucket gains q_rl_inc bytes (capped at q_rl_burst).  A packet may START only when tokens > 0; its
//     length is deducted at selection (the bucket may go negative = debt), so long-run rate = inc/period
//     bytes per clock for any packet size.
//   Packets are never interleaved on the egress port.  A two-deep selection pipeline (cur / nxt) lets the
//   next packet be chosen while the current one streams, so back-to-back packets (even single-beat ones)
//   leave with zero idle cycles.  Per-queue reservations are tracked so descriptor offsets 0/1/2 of the
//   queue are used for head / head+1 / head+2.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_pkt_sched #(
  parameter int DW      = 128,
  parameter int NQ      = 4,
  parameter int PCW     = 7,       // width of the per-queue packet count
  parameter int DESC_W  = 128
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // configuration
  input  wire logic [1:0]            cfg_mode,
  input  wire logic [31:0]           cfg_starve,
  input  wire logic [15:0]           cfg_quant,
  input  wire logic [15:0]           cfg_rl_period,
  input  wire logic [NQ*2-1:0]       q_prio,
  input  wire logic [NQ*8-1:0]       q_weight,
  input  wire logic [NQ*16-1:0]      q_rl_inc,
  input  wire logic [NQ*24-1:0]      q_rl_burst,
  // queue read sides (FWFT)
  input  wire logic [NQ-1:0]         qv,
  input  wire logic [NQ*DW-1:0]      qdata,
  input  wire logic [NQ*DW/8-1:0]    qkeep,
  input  wire logic [NQ-1:0]         qlast,
  output logic [NQ-1:0]              qpop,
  input  wire logic [NQ*PCW-1:0]     qpcnt,
  input  wire logic [NQ*16-1:0]      qlen0,
  input  wire logic [NQ*16-1:0]      qlen1,
  input  wire logic [NQ*16-1:0]      qlen2,
  input  wire logic [NQ*DESC_W-1:0]  qdesc0,
  // egress stream
  output logic                       m_valid,
  input  wire logic                  m_ready,
  output logic [DW-1:0]              m_data,
  output logic [DW/8-1:0]            m_keep,
  output logic                       m_last,
  output logic                       m_sop,
  output logic [4:0]                 m_sel,
  output logic [DESC_W-1:0]          m_desc,
  output logic                       idle
);
  localparam int DWB = DW / 8;
  localparam int QW  = (NQ > 1) ? $clog2(NQ) : 1;
  localparam int TW  = 28;          // signed token width
  localparam int DQW = 26;          // deficit width

  // ---- selection pipeline state -----------------------------------------------------------------------
  reg            cur_v, nxt_v;
  reg [QW-1:0]   cur_sel, nxt_sel;
  reg            in_pkt;

  wire last_hs = cur_v && m_valid && m_ready && m_last;
  wire adv     = !cur_v || last_hs;
  wire nxt_free = !nxt_v || adv;

  // ---- per-queue combinational view -----------------------------------------------------------------------
  wire [NQ-1:0]       elig, avail, dwok, urgent;
  wire [NQ*16-1:0]    lenq;
  wire [NQ*DQW-1:0]   quantum;
  reg  [NQ*DQW-1:0]   deficit;
  reg  [NQ*32-1:0]    starve_cnt;
  reg  [NQ*TW-1:0]    tok;

  wire sel_fire;
  wire [NQ-1:0] gnt;
  wire [QW-1:0] gidx;

  wire [DQW-1:0] qunit = (cfg_quant == 16'd0) ? DQW'(1) : DQW'(cfg_quant);

  genvar q;
  generate
    for (q = 0; q < NQ; q = q + 1) begin : g_q
      wire        is_cur = cur_v && (cur_sel == QW'(q));
      wire        is_nxt = nxt_v && (nxt_sel == QW'(q));
      wire [1:0]  rsv    = {1'b0, is_cur} + {1'b0, is_nxt};
      wire [PCW-1:0] pc  = qpcnt[q*PCW +: PCW];
      wire        av     = (pc > PCW'(rsv));
      wire [15:0] ln     = (rsv == 2'd0) ? qlen0[q*16 +: 16] : (rsv == 2'd1) ? qlen1[q*16 +: 16] : qlen2[q*16 +: 16];
      wire [15:0] inc    = q_rl_inc[q*16 +: 16];
      wire signed [TW-1:0] tk = tok[q*TW +: TW];
      wire        rl_en  = (inc != 16'd0);
      wire        rl_ok  = !rl_en || (tk > 0);
      wire [DQW-1:0] qu  = DQW'(q_weight[q*8 +: 8]) * qunit;
      wire [DQW-1:0] df  = deficit[q*DQW +: DQW];
      assign avail[q]   = av;
      assign elig[q]    = av && rl_ok;
      assign lenq[q*16 +: 16] = ln;
      assign quantum[q*DQW +: DQW] = qu;
      assign dwok[q]    = (df >= DQW'(ln));
      assign urgent[q]  = elig[q] && (cfg_starve != 32'd0) && (starve_cnt[q*32 +: 32] >= cfg_starve);
    end
  endgenerate

  // ---- candidate set per mode ---------------------------------------------------------------------------------
  reg [NQ-1:0] cand;
  reg [1:0]    minp;
  always_comb begin
    minp = 2'd3;
    for (int i = 0; i < NQ; i++) if (elig[i] && (q_prio[i*2 +: 2] < minp)) minp = q_prio[i*2 +: 2];
    case (cfg_mode)
      2'd1: begin
        if (|urgent) cand = urgent;
        else begin
          for (int i = 0; i < NQ; i++) cand[i] = elig[i] && (q_prio[i*2 +: 2] == minp);
        end
      end
      2'd2:    cand = elig & dwok;
      default: cand = elig;
    endcase
  end

  wire any_c;
  sf_rr_arb #(.N(NQ)) u_arb (.clk(clk), .rst_n(rst_n), .req(cand), .advance(sel_fire),
                             .gnt(gnt), .gnt_idx(gidx), .any(any_c));
  assign sel_fire = nxt_free && any_c;

  wire replenish = (cfg_mode == 2'd2) && nxt_free && (|elig) && !any_c;

  reg [15:0] len_sel;
  always_comb begin
    len_sel = 16'd0;
    for (int i = 0; i < NQ; i++) if (gnt[i]) len_sel = lenq[i*16 +: 16];
  end

  // ---- rate-limiter tick -----------------------------------------------------------------------------------------------
  reg [15:0] rl_cnt;
  wire       tick = (rl_cnt >= (cfg_rl_period - 16'd1));
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)      rl_cnt <= 16'd0;
    else if (tick)   rl_cnt <= 16'd0;
    else             rl_cnt <= rl_cnt + 16'd1;
  end

  // ---- state update -----------------------------------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cur_v <= 1'b0; nxt_v <= 1'b0; cur_sel <= '0; nxt_sel <= '0;
      in_pkt <= 1'b0;
      deficit <= '0;
      starve_cnt <= '0;
      for (int i = 0; i < NQ; i++) tok[i*TW +: TW] <= TW'(24'h00FFFF);
    end else begin
      if (adv) begin
        cur_v <= nxt_v; cur_sel <= nxt_sel; nxt_v <= 1'b0;
      end
      if (sel_fire) begin
        nxt_v <= 1'b1; nxt_sel <= gidx;
      end
      if (m_valid && m_ready) in_pkt <= !m_last;

      for (int i = 0; i < NQ; i++) begin
        // token bucket
        begin : tb
          reg signed [TW-1:0] t0, t1, bst;
          t0  = tok[i*TW +: TW];
          bst = $signed({{(TW-24){1'b0}}, q_rl_burst[i*24 +: 24]});
          t1  = t0 + (tick ? $signed({{(TW-16){1'b0}}, q_rl_inc[i*16 +: 16]}) : '0)
                   - ((sel_fire && gnt[i]) ? $signed({{(TW-16){1'b0}}, len_sel}) : '0);
          if (q_rl_inc[i*16 +: 16] == 16'd0) tok[i*TW +: TW] <= bst;
          else if (t1 > bst)                 tok[i*TW +: TW] <= bst;
          else                               tok[i*TW +: TW] <= t1;
        end
        // starvation counter
        if (!elig[i] || (sel_fire && gnt[i]))       starve_cnt[i*32 +: 32] <= 32'd0;
        else if (starve_cnt[i*32 +: 32] != 32'hFFFFFFFF) starve_cnt[i*32 +: 32] <= starve_cnt[i*32 +: 32] + 32'd1;
        // DWRR deficit
        if (!avail[i])                              deficit[i*DQW +: DQW] <= '0;
        else if (sel_fire && gnt[i] && (cfg_mode == 2'd2)) deficit[i*DQW +: DQW] <= deficit[i*DQW +: DQW] - DQW'(lenq[i*16 +: 16]);
        else if (replenish && elig[i])              deficit[i*DQW +: DQW] <= deficit[i*DQW +: DQW] + quantum[i*DQW +: DQW];
      end
    end
  end

  // ---- datapath mux ----------------------------------------------------------------------------------------------------------------
  always_comb begin
    m_valid = 1'b0;
    m_data  = '0;
    m_keep  = '0;
    m_last  = 1'b0;
    m_desc  = '0;
    qpop    = '0;
    if (cur_v) begin
      for (int i = 0; i < NQ; i++) begin
        if (cur_sel == QW'(i)) begin
          m_valid = qv[i];
          m_data  = qdata[i*DW +: DW];
          m_keep  = qkeep[i*DWB +: DWB];
          m_last  = qlast[i];
          m_desc  = qdesc0[i*DESC_W +: DESC_W];
          qpop[i] = qv[i] && m_ready;
        end
      end
    end
  end
  assign m_sop = !in_pkt;
  assign m_sel = {{(5-QW){1'b0}}, cur_sel};
  assign idle  = !cur_v && !nxt_v;
endmodule

`default_nettype wire
