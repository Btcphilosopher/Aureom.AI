// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_toeplitz -- RSS-compatible Toeplitz hash
//
//   hash = XOR over every input bit i (bit 0 = MSB of the first input byte) that is 1 of the 32-bit
//          window key[i .. i+31] (key bit 0 = MSB of key byte 0).
//   Input stream order (network byte order): src addr, dst addr, src port, dst port, left-justified in
//   the 288-bit vector `hin` (hin[287] is stream bit 0); unused tail is zero.
//   Each output bit is a single reduction XOR of 288 AND terms, so synthesis builds a BALANCED tree (an
//   `if (bit) hash ^= window` loop synthesises as a 288-deep serial chain -- measured at 21 MHz on an ECP5
//   before this form was used).  Registered by the caller.  Checked against the Microsoft RSS verification
//   vectors (model/test_model.py) and bit-for-bit against the model in every parser regression.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_pkt_toeplitz (
  input  wire logic [287:0] hin,
  input  wire logic [319:0] key,
  output logic      [31:0]  hash
);
  always_comb begin
    for (int b = 0; b < 32; b++) begin
      logic [287:0] term;
      for (int i = 0; i < 288; i++) term[i] = hin[287 - i] & key[288 - i + b];
      hash[b] = ^term;
    end
  end
endmodule

`default_nettype wire
