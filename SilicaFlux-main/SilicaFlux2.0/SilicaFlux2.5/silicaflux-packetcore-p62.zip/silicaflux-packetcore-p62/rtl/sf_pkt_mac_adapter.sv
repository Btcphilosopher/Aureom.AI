// =============================================================================
// SilicaFlux PacketCore :: sf_pkt_mac_adapter -- AXI4-Stream Ethernet-MAC adapter for the packet engine
//
//   Connects an EXISTING Ethernet MAC (not part of this project and NOT in the SilicaFlux repository) to the
//   engine's stream interface.  It does not implement a MAC, PCS or SerDes/PHY.
//
//   Assumed MAC conventions (the common AXI-Stream MAC interface, e.g. Xilinx 10/25/40/100G subsystem in
//   AXI-S mode, verilog-ethernet eth_mac_*): the MAC and this adapter share ONE clock and ONE data width;
//     RX  rx_tdata/rx_tkeep/rx_tvalid/rx_tlast, no tready, rx_tuser_bad (= tuser[0]) marks a bad frame
//         (FCS error etc.) on the last beat; the FCS is stripped; the first byte on the wire is tdata[7:0].
//     TX  tx_tdata/tx_tkeep/tx_tvalid/tx_tlast with tx_tready; the MAC pads runts and appends the FCS.
//   For a different clock or width, instantiate the MAC vendor's clock-converter / width-converter first.
//
//   RX path: a MAC cannot be paused, so frames go through a packet-aware buffer (sf_pkt_queue: speculative
//   write, commit at a good last beat).  If the buffer (or its descriptor FIFO) cannot take a frame it is
//   dropped WHOLE and counted (rx_overflow); a frame never reaches the engine partially.  A frame flagged bad
//   by the MAC is passed on with s_err = 1 so the engine drops and counts it (DROP_MACERR).
//   s_src = PORT_ID, s_meta = arrival timestamp (free-running clock count at the first beat).
//   TX path: registered through a skid slice.  The engine only starts a frame that is already complete in its
//   queue, so tx_tvalid never drops in the middle of a frame (no MAC underrun) while tx_tready is respected.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_pkt_mac_adapter #(
  parameter int DW         = 128,
  parameter int SRC_W      = 4,
  parameter int META_W     = 32,
  parameter int RX_BYTES   = 32768,     // RX buffer (power-of-2 beats after division); must hold >= 1 max frame
  parameter int PKT_DEPTH  = 64,
  parameter int PORT_ID    = 0
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // MAC side
  input  wire logic                 rx_tvalid,
  input  wire logic [DW-1:0]        rx_tdata,
  input  wire logic [DW/8-1:0]      rx_tkeep,
  input  wire logic                 rx_tlast,
  input  wire logic                 rx_tuser_bad,
  output logic                      tx_tvalid,
  input  wire logic                 tx_tready,
  output logic [DW-1:0]             tx_tdata,
  output logic [DW/8-1:0]           tx_tkeep,
  output logic                      tx_tlast,
  output logic                      tx_tuser,
  // engine side: ingress
  output logic                      s_valid,
  input  wire logic                 s_ready,
  output logic [DW-1:0]             s_data,
  output logic [DW/8-1:0]           s_keep,
  output logic                      s_last,
  output logic                      s_err,
  output logic [SRC_W-1:0]          s_src,
  output logic [META_W-1:0]         s_meta,
  // engine side: egress
  input  wire logic                 m_valid,
  output logic                      m_ready,
  input  wire logic [DW-1:0]        m_data,
  input  wire logic [DW/8-1:0]      m_keep,
  input  wire logic                 m_last,
  // statistics (saturating 32-bit)
  output logic [31:0]               stat_rx_frames,
  output logic [31:0]               stat_rx_overflow,
  output logic [31:0]               stat_rx_bad,
  output logic [31:0]               stat_tx_frames
);
  localparam int DWB     = DW / 8;
  localparam int DEPTH_B = RX_BYTES / DWB;
  localparam int DESC_W  = META_W + 1;
  localparam int PCW     = $clog2(PKT_DEPTH) + 1;

  reg [META_W-1:0] ts;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) ts <= '0;
    else        ts <= ts + 1'b1;
  end

  // ---- RX: speculative write / commit / drop-whole -----------------------------------------------
  reg  rx_act;          // inside a frame
  reg  rx_drop;         // discarding the rest of this frame
  reg  rx_wrote;        // at least one beat of this frame is in the buffer (uncommitted)
  reg  [META_W-1:0] rx_ts;
  wire space_ok, pkt_ok;

  wire rx_first = !rx_act;
  wire can      = space_ok && (rx_first ? pkt_ok : 1'b1);
  wire do_wr    = rx_tvalid && !rx_drop && can;
  wire fail     = rx_tvalid && !rx_drop && !can;                       // buffer cannot take this beat
  wire [META_W-1:0] ts_now = rx_first ? ts : rx_ts;

  wire q_beat   = do_wr;
  wire q_commit = do_wr && rx_tlast;
  wire q_abort  = fail && rx_wrote;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rx_act <= 1'b0; rx_drop <= 1'b0; rx_wrote <= 1'b0; rx_ts <= '0;
      stat_rx_frames <= 32'd0; stat_rx_overflow <= 32'd0; stat_rx_bad <= 32'd0;
    end else if (rx_tvalid) begin
      if (rx_first) rx_ts <= ts;
      if (rx_tlast) begin
        rx_act <= 1'b0; rx_drop <= 1'b0; rx_wrote <= 1'b0;
      end else begin
        rx_act <= 1'b1;
        if (fail)  rx_drop <= 1'b1;
        if (do_wr) rx_wrote <= 1'b1;
      end
      if (fail && (stat_rx_overflow != 32'hFFFFFFFF) && !(rx_drop)) begin
        // count once per frame: at the first failing beat
        stat_rx_overflow <= stat_rx_overflow + 32'd1;
      end
      if (q_commit && (stat_rx_frames != 32'hFFFFFFFF)) stat_rx_frames <= stat_rx_frames + 32'd1;
      if (q_commit && rx_tuser_bad && (stat_rx_bad != 32'hFFFFFFFF)) stat_rx_bad <= stat_rx_bad + 32'd1;
    end
  end

  wire         rq_valid, rq_last, rq_pop;
  wire [DW-1:0] rq_data;
  wire [DWB-1:0] rq_keep;
  wire [PCW-1:0] rq_pcnt;
  wire [DESC_W-1:0] rq_d0, rq_d1, rq_d2;
  wire [$clog2(DEPTH_B):0] rq_occ;

  sf_pkt_queue #(.DW(DW), .DEPTH_BEATS(DEPTH_B), .PKT_DEPTH(PKT_DEPTH), .DESC_W(DESC_W)) u_rxq (
    .clk(clk), .rst_n(rst_n),
    .wr_beat(q_beat), .wr_data(rx_tdata), .wr_keep(rx_tkeep), .wr_last(rx_tlast),
    .wr_commit(q_commit), .wr_desc({ts_now, rx_tuser_bad}), .wr_abort(q_abort),
    .wr_space_ok(space_ok), .wr_pkt_ok(pkt_ok),
    .rd_valid(rq_valid), .rd_data(rq_data), .rd_keep(rq_keep), .rd_last(rq_last), .rd_pop(rq_pop),
    .pkt_cnt(rq_pcnt), .desc0(rq_d0), .desc1(rq_d1), .desc2(rq_d2), .occ_beats(rq_occ));

  assign s_valid = rq_valid;
  assign s_data  = rq_data;
  assign s_keep  = rq_keep;
  assign s_last  = rq_last;
  assign s_err   = rq_last && rq_d0[0];
  assign s_src   = SRC_W'(PORT_ID);
  assign s_meta  = rq_d0[1 +: META_W];
  assign rq_pop  = rq_valid && s_ready;

  // ---- TX: skid slice ------------------------------------------------------------------------------------------------
  wire [DW+DWB+1-1:0] tx_pk;
  sfb_skid_buffer #(.WIDTH(DW + DWB + 1)) u_tx (
    .clk(clk), .rst_n(rst_n),
    .s_valid(m_valid), .s_ready(m_ready), .s_data({m_last, m_keep, m_data}),
    .m_valid(tx_tvalid), .m_ready(tx_tready), .m_data(tx_pk));
  assign tx_tdata = tx_pk[0 +: DW];
  assign tx_tkeep = tx_pk[DW +: DWB];
  assign tx_tlast = tx_pk[DW + DWB];
  assign tx_tuser = 1'b0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) stat_tx_frames <= 32'd0;
    else if (tx_tvalid && tx_tready && tx_tlast && stat_tx_frames != 32'hFFFFFFFF) stat_tx_frames <= stat_tx_frames + 32'd1;
  end
endmodule

`default_nettype wire
