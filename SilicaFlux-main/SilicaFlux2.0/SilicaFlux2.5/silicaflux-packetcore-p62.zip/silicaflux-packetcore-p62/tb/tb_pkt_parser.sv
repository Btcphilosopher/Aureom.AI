// =============================================================================
// SilicaFlux PacketCore :: tb_pkt_parser -- parser unit testbench (file-driven, compared against model)
//   +vec=<base>        reads <base>.bytes.mem / <base>.idx.mem (5 words/pkt: offset len src meta flags)
//   +npkts=<n>         number of packets
//   +out=<file>        token dump (one hex token per line, in packet order)
//   +gap=<pct>         probability (0..100) of an idle cycle between beats
//   +tpid0 +tpid1 +vxport (hex) +csum=<0|1> +vxlan=<0|1> +seed=<n>
// =============================================================================
`timescale 1ns/1ps
`include "sf_pkt_macros.svh"

module tb_pkt_parser;
  parameter int DW       = 128;
  parameter int HDR_CAP  = 128;
  parameter int MAX_EXT  = 4;
  parameter int EXT_STEP = 2;
  localparam int DWB  = DW / 8;
  localparam int MAXB = 8 * 1024 * 1024;
  localparam int MAXP = 65536;

  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n;

  logic            acc_valid;
  logic [DW-1:0]   acc_data;
  logic [DWB-1:0]  acc_keep;
  logic            acc_last;
  logic [7:0]      acc_src;
  logic [15:0]     cfg_tpid0, cfg_tpid1, cfg_vxlan_port;
  logic            cfg_csum_en, cfg_vxlan_en;
  logic [319:0]    key;
  logic            tok_valid;
  logic [`SFP_TK_W-1:0] tok;

  sf_pkt_parser #(.DW(DW), .HDR_CAP_BYTES(HDR_CAP), .MAX_EXT(MAX_EXT), .EXT_STEP(EXT_STEP)) dut (
    .clk(clk), .rst_n(rst_n),
    .acc_valid(acc_valid), .acc_data(acc_data), .acc_keep(acc_keep), .acc_last(acc_last), .acc_src(acc_src),
    .cfg_tpid0(cfg_tpid0), .cfg_tpid1(cfg_tpid1), .cfg_vxlan_port(cfg_vxlan_port),
    .cfg_csum_en(cfg_csum_en), .cfg_vxlan_en(cfg_vxlan_en), .cfg_rss_key(key),
    .tok_valid(tok_valid), .tok(tok));

  logic [7:0]  bytes [0:MAXB-1];
  logic [31:0] idx   [0:MAXP*5-1];
  string vec, outf;
  integer npk, gap, seed, fo, p, b, nbeats, k, off, len, ntok;
  integer csum, vxen;
  logic [31:0] tp0, tp1, vxp;

  always @(posedge clk) begin
    if (tok_valid) begin
      $fwrite(fo, "%h\n", tok);
      ntok <= ntok + 1;
    end
  end

  initial begin
    key = 320'h6d5a56da255b0ec24167253d43a38fb0d0ca2bcbae7b30b477cb2da38030f20c6a42b73bbeac01fa;
    npk = 0; gap = 0; seed = 1; csum = 1; vxen = 1; tp0 = 32'h8100; tp1 = 32'h88A8; vxp = 32'd4789; ntok = 0;
    if (!$value$plusargs("vec=%s", vec))   $fatal(1, "need +vec");
    if (!$value$plusargs("out=%s", outf))  $fatal(1, "need +out");
    void'($value$plusargs("npkts=%d", npk));
    void'($value$plusargs("gap=%d", gap));
    void'($value$plusargs("seed=%d", seed));
    void'($value$plusargs("csum=%d", csum));
    void'($value$plusargs("vxlan=%d", vxen));
    void'($value$plusargs("tpid0=%h", tp0));
    void'($value$plusargs("tpid1=%h", tp1));
    void'($value$plusargs("vxport=%h", vxp));
    void'($urandom(seed));
    cfg_tpid0 = tp0[15:0]; cfg_tpid1 = tp1[15:0]; cfg_vxlan_port = vxp[15:0];
    cfg_csum_en = csum[0]; cfg_vxlan_en = vxen[0];
    $readmemh({vec, ".bytes.mem"}, bytes);
    $readmemh({vec, ".idx.mem"}, idx);
    fo = $fopen(outf, "w");
    acc_valid = 1'b0; acc_data = '0; acc_keep = '0; acc_last = 1'b0; acc_src = 8'd0;
    rst_n = 1'b0;
    repeat (4) @(posedge clk);
    rst_n = 1'b1;
    repeat (2) @(posedge clk);
    for (p = 0; p < npk; p = p + 1) begin
      off = idx[p*5+0]; len = idx[p*5+1];
      nbeats = (len + DWB - 1) / DWB;
      for (b = 0; b < nbeats; b = b + 1) begin
        while (($urandom_range(0, 99)) < gap) begin
          acc_valid <= 1'b0;
          @(posedge clk);
        end
        acc_valid <= 1'b1;
        acc_src   <= idx[p*5+2][7:0];
        acc_last  <= (b == nbeats - 1);
        for (k = 0; k < DWB; k = k + 1) begin
          if (b * DWB + k < len) begin
            acc_data[8*k +: 8] <= bytes[off + b * DWB + k];
            acc_keep[k]        <= 1'b1;
          end else begin
            acc_data[8*k +: 8] <= 8'hA5;   // garbage under keep=0: must never influence the token
            acc_keep[k]        <= 1'b0;
          end
        end
        @(posedge clk);
      end
    end
    acc_valid <= 1'b0;
    repeat (60) @(posedge clk);
    $fclose(fo);
    if (ntok != npk) $display("TB_RESULT FAIL tokens=%0d packets=%0d", ntok, npk);
    else             $display("TB_RESULT DONE tokens=%0d", ntok);
    $finish;
  end
endmodule
