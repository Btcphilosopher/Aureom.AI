// =============================================================================
// SilicaFlux PacketCore :: tb_packet_engine -- file/script driven system testbench
//
//   +vec=<base>     packet vectors  <base>.bytes.mem / <base>.idx.mem   (5 words/pkt: off len src meta flags)
//                   flags: [0] s_err on last beat   [1] partial keep on a middle beat
//                          [2] non-contiguous keep on last beat   [3] extra zero-keep last beat
//   +script=<file>  numeric script, one op per line:  op a b c   (hex)
//        1 t addr data   register WRITE as tenant t        2 t addr   register READ
//        3 n             wait n cycles                      4 first n  inject packets [first,first+n)  (non-blocking)
//        5 timeout       wait until injection finished      6 timeout  wait until the engine and ports are quiet
//        7 key val       MODE: key 1 ingress gap %, 2 egress ready %, 3 mgmt ready %, 4 egress stall pattern
//                        ((on<<16)|off cycles, 0 = off), 5 mgmt stall pattern, 6 seed
//        8 n             assert reset for n cycles (flushes the injector; ports reset)
//   +out=<file>     event log:  INJ meta cyc | OUT D|M cyc_sop cyc_eop q tc src meta hash len hex | RD/WR t addr data err
//                   | RST cyc | PROTO msg | STAT ...
// Protocol self-checks (always on): AXIS payload/sideband stability under stall, keep legality, sideband
// constancy within a frame, m_len == byte count, FIFO overflow/underflow flags of the vendored FIFOs.
// =============================================================================
`timescale 1ns/1ps
`include "sf_pkt_macros.svh"

module tb_packet_engine;
  parameter int DW              = 128;
  parameter int SRC_W           = 4;
  parameter int META_W          = 32;
  parameter int NQ              = 4;
  parameter int NR              = 16;
  parameter int NT              = 8;
  parameter int MAXF            = 9216;
  parameter int QBYTES          = 16384;
  parameter int MBYTES          = 16384;
  parameter int PKT_DEPTH       = 64;
  parameter int DELAYB          = 64;
  parameter int DECD            = 32;
  parameter int HDR_CAP         = 128;
  parameter int MAX_EXT         = 4;
  parameter int EXT_STEP        = 2;
  parameter int ENABLE_REWRITE  = 1;
  parameter int ENABLE_TENANT   = 1;
  parameter int FIFO_RAM        = 1;
  localparam int DWB  = DW / 8;
  localparam int MAXB = 12 * 1024 * 1024;
  localparam int MAXP = 65536;

  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n;
  integer cyc;

  logic                  s_valid, s_ready, s_last, s_err;
  logic [DW-1:0]         s_data;
  logic [DWB-1:0]        s_keep;
  logic [SRC_W-1:0]      s_src;
  logic [META_W-1:0]     s_meta;
  logic                  m_valid, m_ready, m_last, m_err;
  logic [DW-1:0]         m_data;
  logic [DWB-1:0]        m_keep;
  logic [3:0]            m_queue;
  logic [2:0]            m_tc;
  logic [SRC_W-1:0]      m_src;
  logic [META_W-1:0]     m_meta;
  logic [31:0]           m_hash;
  logic [15:0]           m_len;
  logic                  x_valid, x_ready, x_last;
  logic [DW-1:0]         x_data;
  logic [DWB-1:0]        x_keep;
  logic [3:0]            x_reason;
  logic [2:0]            x_tc;
  logic [SRC_W-1:0]      x_src;
  logic [META_W-1:0]     x_meta;
  logic [31:0]           x_hash;
  logic [15:0]           x_len;
  logic                  rb_req, rb_we, rb_rvalid, rb_err;
  logic [15:0]           rb_addr;
  logic [31:0]           rb_wdata, rb_rdata;
  logic [3:0]            rb_tenant;
  logic                  idle;

  silicaflux_packet_engine #(
    .DW(DW), .SRC_W(SRC_W), .META_W(META_W), .NUM_QUEUES(NQ), .NUM_RULES(NR), .NUM_TENANTS(NT),
    .MAX_FRAME_BYTES(MAXF), .QUEUE_BYTES(QBYTES), .MGMT_BYTES(MBYTES), .PKT_DEPTH(PKT_DEPTH),
    .HDR_CAP_BYTES(HDR_CAP), .MAX_EXT(MAX_EXT), .EXT_STEP(EXT_STEP), .DELAY_BEATS(DELAYB), .DEC_DEPTH(DECD),
    .ENABLE_REWRITE(ENABLE_REWRITE != 0), .ENABLE_TENANT(ENABLE_TENANT != 0), .FIFO_RAM(FIFO_RAM != 0)) dut (
    .clk(clk), .rst_n(rst_n),
    .s_valid(s_valid), .s_ready(s_ready), .s_data(s_data), .s_keep(s_keep), .s_last(s_last), .s_err(s_err),
    .s_src(s_src), .s_meta(s_meta),
    .m_valid(m_valid), .m_ready(m_ready), .m_data(m_data), .m_keep(m_keep), .m_last(m_last), .m_err(m_err),
    .m_queue(m_queue), .m_tc(m_tc), .m_src(m_src), .m_meta(m_meta), .m_hash(m_hash), .m_len(m_len),
    .x_valid(x_valid), .x_ready(x_ready), .x_data(x_data), .x_keep(x_keep), .x_last(x_last),
    .x_reason(x_reason), .x_tc(x_tc), .x_src(x_src), .x_meta(x_meta), .x_hash(x_hash), .x_len(x_len),
    .rb_req(rb_req), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_tenant(rb_tenant),
    .rb_rvalid(rb_rvalid), .rb_rdata(rb_rdata), .rb_err(rb_err), .idle(idle));

  // ---------------------------------------------------------------------------------------------------
  // vectors / script / log
  // ---------------------------------------------------------------------------------------------------
  logic [7:0]  bytes [0:MAXB-1];
  logic [31:0] idx   [0:MAXP*5-1];
  string vec, scr, outf;
  integer fo, fs;

  integer gap_pct, egr_pct, mgr_pct, egr_pat, mgr_pat, seed_v;
  integer inj_ptr, inj_end, inj_done, inj_beat, inj_nbeats, inj_len, inj_off, inj_flags;
  logic   inj_active, req_flush;
  logic [31:0] inj_meta;
  logic [SRC_W-1:0] inj_src;
  integer acc_beats, egr_beats, m_pkts, x_pkts, proto_errs;
  integer mid_beat;

  // ---------------------------------------------------------------------------------------------------
  // cycle counter, reset-aware helpers
  // ---------------------------------------------------------------------------------------------------
  always @(posedge clk) cyc <= cyc + 1;

  // ---------------------------------------------------------------------------------------------------
  // ingress driver
  // ---------------------------------------------------------------------------------------------------
  integer k, nb_last, nb_data;
  logic [DWB-1:0] kmask;
  always @(posedge clk) begin
    if (!rst_n || req_flush) begin
      s_valid <= 1'b0; s_last <= 1'b0; s_err <= 1'b0; s_keep <= '0; s_data <= '0;
      inj_active = 1'b0;
      if (req_flush) begin inj_ptr = inj_end; req_flush = 1'b0; end
    end else begin
      if (s_valid && s_ready) begin
        acc_beats = acc_beats + 1;
        if (inj_beat == 0) $fwrite(fo, "INJ %0d %0d\n", inj_meta, cyc);
        if (s_last) begin
          inj_active = 1'b0; inj_done = inj_done + 1;
        end else inj_beat = inj_beat + 1;
      end
      if (!s_valid || s_ready) begin
        if (!inj_active && inj_ptr < inj_end) begin
          inj_off    = idx[inj_ptr*5+0]; inj_len = idx[inj_ptr*5+1];
          inj_src    = idx[inj_ptr*5+2][SRC_W-1:0]; inj_meta = idx[inj_ptr*5+3]; inj_flags = idx[inj_ptr*5+4];
          nb_data    = (inj_len + DWB - 1) / DWB;
          inj_nbeats = nb_data + (((inj_flags & 8) != 0) ? 1 : 0);
          inj_beat   = 0; inj_active = 1'b1; inj_ptr = inj_ptr + 1;
        end
        if (inj_active && !(gap_pct > 0 && $urandom_range(0, 99) < gap_pct)) begin
          s_valid <= 1'b1;
          s_src   <= inj_src;
          s_meta  <= inj_meta;
          s_last  <= (inj_beat == inj_nbeats - 1);
          s_err   <= 1'b0;
          if (inj_beat == nb_data) begin
            // flag 8: extra last beat carrying keep = 0
            s_keep <= '0;
            for (k = 0; k < DWB; k = k + 1) s_data[8*k +: 8] <= 8'h5A;
          end else begin
            nb_last = inj_len - (nb_data - 1) * DWB;          // bytes in the last data beat
            for (k = 0; k < DWB; k = k + 1) begin
              if (inj_beat * DWB + k < inj_len) begin
                s_data[8*k +: 8] <= bytes[inj_off + inj_beat * DWB + k];
                kmask[k] = 1'b1;
              end else begin
                s_data[8*k +: 8] <= 8'hA5;                     // garbage under keep=0
                kmask[k] = 1'b0;
              end
            end
            if (((inj_flags & 2) != 0) && inj_beat == 1 && nb_data > 2)       kmask[DWB-1] = 1'b0;   // partial keep mid-frame
            if (((inj_flags & 4) != 0) && inj_beat == nb_data - 1 && nb_last >= 2) kmask[0] = 1'b0;  // hole in last keep
            s_keep <= kmask;
            if (((inj_flags & 1) != 0) && inj_beat == inj_nbeats - 1) s_err <= 1'b1;
          end
        end else begin
          s_valid <= 1'b0;
        end
      end
    end
  end

  // ---------------------------------------------------------------------------------------------------
  // egress ready generation
  // ---------------------------------------------------------------------------------------------------
  always @(posedge clk) begin
    if (egr_pat != 0) m_ready <= ((cyc % ((egr_pat >> 16) + (egr_pat & 16'hFFFF))) < (egr_pat >> 16));
    else              m_ready <= ($urandom_range(0, 99) < egr_pct);
    if (mgr_pat != 0) x_ready <= ((cyc % ((mgr_pat >> 16) + (mgr_pat & 16'hFFFF))) < (mgr_pat >> 16));
    else              x_ready <= ($urandom_range(0, 99) < mgr_pct);
  end

  // ---------------------------------------------------------------------------------------------------
  // egress monitors + protocol checks
  // ---------------------------------------------------------------------------------------------------
  logic [7:0] mbuf [0:MAXF+DWB];
  logic [7:0] xbuf [0:MAXF+DWB];
  integer m_n, x_n, m_sop_cyc, x_sop_cyc, bi;
  logic   m_in, x_in;
  logic [3:0] m_q0; logic [2:0] m_tc0; logic [SRC_W-1:0] m_src0; logic [META_W-1:0] m_meta0; logic [31:0] m_hash0; logic [15:0] m_len0;
  logic [3:0] x_r0; logic [2:0] x_tc0; logic [SRC_W-1:0] x_src0; logic [META_W-1:0] x_meta0; logic [31:0] x_hash0; logic [15:0] x_len0;
  // stability
  logic pm_stall, px_stall;
  logic [DW-1:0] pm_data, px_data; logic [DWB-1:0] pm_keep, px_keep; logic pm_last, px_last;
  logic [META_W-1:0] pm_meta, px_meta;

  task automatic perr(input string msg);
    begin
      proto_errs = proto_errs + 1;
      $fwrite(fo, "PROTO %s cyc=%0d\n", msg, cyc);
    end
  endtask

  function automatic logic keep_ok(input logic [DWB-1:0] kp, input logic lst);
    begin
      if (lst) keep_ok = (kp != 0) && ((kp & (kp + 1'b1)) == 0);
      else     keep_ok = &kp;
    end
  endfunction

  always @(posedge clk) begin
    if (!rst_n) begin
      if (m_in) $fwrite(fo, "PARTIAL D %0d beats=%0d\n", cyc, m_n);
      if (x_in) $fwrite(fo, "PARTIAL M %0d beats=%0d\n", cyc, x_n);
      m_in = 1'b0; m_n = 0; x_in = 1'b0; x_n = 0; pm_stall = 1'b0; px_stall = 1'b0;
    end else begin
      // ---- data port ----
      if (pm_stall && m_valid && (m_data !== pm_data || m_keep !== pm_keep || m_last !== pm_last || m_meta !== pm_meta)) perr("m_* changed while stalled");
      if (pm_stall && !m_valid) perr("m_valid dropped while stalled");
      pm_stall = m_valid && !m_ready; pm_data = m_data; pm_keep = m_keep; pm_last = m_last; pm_meta = m_meta;
      if (m_valid && m_ready) begin
        egr_beats = egr_beats + 1;
        if (!keep_ok(m_keep, m_last)) perr("m_keep illegal");
        if (!m_in) begin
          m_in = 1'b1; m_n = 0; m_sop_cyc = cyc;
          m_q0 = m_queue; m_tc0 = m_tc; m_src0 = m_src; m_meta0 = m_meta; m_hash0 = m_hash; m_len0 = m_len;
        end else if (m_queue !== m_q0 || m_tc !== m_tc0 || m_src !== m_src0 || m_meta !== m_meta0 || m_hash !== m_hash0 || m_len !== m_len0)
          perr("m_ sideband changed within a frame");
        for (bi = 0; bi < DWB; bi = bi + 1)
          if (m_keep[bi] && m_n * DWB + bi <= MAXF + DWB - 1) mbuf[m_n * DWB + bi] = m_data[8*bi +: 8];
        m_n = m_n + 1;
        if (m_last) begin
          // byte count = (m_n-1)*DWB + popcount(last keep)
          bi = 0; for (k = 0; k < DWB; k = k + 1) if (m_keep[k]) bi = bi + 1;
          if ((m_n - 1) * DWB + bi != m_len0) perr("m_len != byte count");
          $fwrite(fo, "OUT D %0d %0d %0d %0d %0d %0d %0d %0d ", m_sop_cyc, cyc, m_q0, m_tc0, m_src0, m_meta0, m_hash0, m_len0);
          for (k = 0; k < (m_n - 1) * DWB + bi; k = k + 1) $fwrite(fo, "%02x", mbuf[k]);
          $fwrite(fo, "\n");
          m_pkts = m_pkts + 1; m_in = 1'b0; m_n = 0;
        end
      end
      if (m_err) perr("m_err asserted");
      // ---- management port ----
      if (px_stall && x_valid && (x_data !== px_data || x_keep !== px_keep || x_last !== px_last || x_meta !== px_meta)) perr("x_* changed while stalled");
      if (px_stall && !x_valid) perr("x_valid dropped while stalled");
      px_stall = x_valid && !x_ready; px_data = x_data; px_keep = x_keep; px_last = x_last; px_meta = x_meta;
      if (x_valid && x_ready) begin
        if (!keep_ok(x_keep, x_last)) perr("x_keep illegal");
        if (!x_in) begin
          x_in = 1'b1; x_n = 0; x_sop_cyc = cyc;
          x_r0 = x_reason; x_tc0 = x_tc; x_src0 = x_src; x_meta0 = x_meta; x_hash0 = x_hash; x_len0 = x_len;
        end else if (x_reason !== x_r0 || x_tc !== x_tc0 || x_src !== x_src0 || x_meta !== x_meta0 || x_len !== x_len0)
          perr("x_ sideband changed within a frame");
        for (bi = 0; bi < DWB; bi = bi + 1)
          if (x_keep[bi] && x_n * DWB + bi <= MAXF + DWB - 1) xbuf[x_n * DWB + bi] = x_data[8*bi +: 8];
        x_n = x_n + 1;
        if (x_last) begin
          bi = 0; for (k = 0; k < DWB; k = k + 1) if (x_keep[k]) bi = bi + 1;
          if ((x_n - 1) * DWB + bi != x_len0) perr("x_len != byte count");
          $fwrite(fo, "OUT M %0d %0d %0d %0d %0d %0d %0d %0d ", x_sop_cyc, cyc, x_r0, x_tc0, x_src0, x_meta0, x_hash0, x_len0);
          for (k = 0; k < (x_n - 1) * DWB + bi; k = k + 1) $fwrite(fo, "%02x", xbuf[k]);
          $fwrite(fo, "\n");
          x_pkts = x_pkts + 1; x_in = 1'b0; x_n = 0;
        end
      end
      // ---- vendored FIFO flags must never fire ----
      if (dut.u_dly.overflow || dut.u_dly.underflow) perr("delay FIFO overflow/underflow");
      if (dut.u_sb.overflow  || dut.u_sb.underflow)  perr("sideband FIFO overflow/underflow");
      if (dut.u_dec.overflow || dut.u_dec.underflow) perr("decision FIFO overflow/underflow");
    end
  end

  // ---------------------------------------------------------------------------------------------------
  // register access
  // ---------------------------------------------------------------------------------------------------
  // Driven / sampled 1 ns after the clock edge (race-free under any simulator's scheduling): request is
  // presented for exactly one clock, the registered response is sampled just after the next edge.
  task automatic regop(input integer we, input integer t, input integer a, input integer d);
    begin
      @(posedge clk); #1;
      rb_req = 1'b1; rb_we = we[0]; rb_addr = a[15:0]; rb_wdata = d; rb_tenant = t[3:0];
      @(posedge clk); #1;
      rb_req = 1'b0; rb_we = 1'b0;
      if (!rb_rvalid) perr("no register response");
      $fwrite(fo, "%s %0d %0h %0h %0d\n", we ? "WR" : "RD", t, a, we ? d : rb_rdata, rb_err);
    end
  endtask

  // ---------------------------------------------------------------------------------------------------
  // script executor
  // ---------------------------------------------------------------------------------------------------
  integer op, a1, a2, a3, r, w, quiet;
  logic [31:0] tmpv;
  initial begin
    cyc = 0; gap_pct = 0; egr_pct = 100; mgr_pct = 100; egr_pat = 0; mgr_pat = 0; seed_v = 1;
    inj_ptr = 0; inj_end = 0; inj_done = 0; inj_beat = 0; inj_nbeats = 0; inj_active = 1'b0; req_flush = 1'b0;
    acc_beats = 0; egr_beats = 0; m_pkts = 0; x_pkts = 0; proto_errs = 0; m_in = 1'b0; x_in = 1'b0; m_n = 0; x_n = 0;
    pm_stall = 1'b0; px_stall = 1'b0;
    rb_req = 1'b0; rb_we = 1'b0; rb_addr = '0; rb_wdata = '0; rb_tenant = '0; m_ready = 1'b0; x_ready = 1'b0;
    s_valid = 1'b0; s_data = '0; s_keep = '0; s_last = 1'b0; s_err = 1'b0; s_src = '0; s_meta = '0;
    if (!$value$plusargs("vec=%s", vec))    vec = "";
    if (!$value$plusargs("script=%s", scr)) $fatal(1, "need +script");
    if (!$value$plusargs("out=%s", outf))   $fatal(1, "need +out");
    void'($value$plusargs("seed=%d", seed_v));
    void'($urandom(seed_v));
    if (vec != "") begin
      $readmemh({vec, ".bytes.mem"}, bytes);
      $readmemh({vec, ".idx.mem"}, idx);
    end
    fo = $fopen(outf, "w");
    fs = $fopen(scr, "r");
    if (fs == 0) $fatal(1, "cannot open script");
    rst_n = 1'b0;
    repeat (5) @(posedge clk);
    rst_n = 1'b1;
    repeat (3) @(posedge clk);
    while (!$feof(fs)) begin
      op = -1; a1 = 0; a2 = 0; a3 = 0;
      r = $fscanf(fs, "%h %h %h %h\n", op, a1, a2, a3);
      case (op)
        1: regop(1, a1, a2, a3);
        2: regop(0, a1, a2, 0);
        3: repeat (a1) @(posedge clk);
        4: begin inj_ptr = a1; inj_end = a1 + a2; end
        5: begin
             w = 0;
             while ((inj_ptr < inj_end || inj_active || s_valid) && w < a1) begin @(posedge clk); w = w + 1; end
             if (w >= a1) $fwrite(fo, "TIMEOUT WAITINJ cyc=%0d inj_ptr=%0d inj_end=%0d\n", cyc, inj_ptr, inj_end);
           end
        6: begin
             w = 0; quiet = 0;
             while (quiet < 40 && w < a1) begin
               @(posedge clk); w = w + 1;
               if (inj_ptr >= inj_end && !inj_active && !s_valid && idle && !m_valid && !x_valid) quiet = quiet + 1; else quiet = 0;
             end
             if (w >= a1) $fwrite(fo, "TIMEOUT DRAIN cyc=%0d\n", cyc);
           end
        7: case (a1)
             1: gap_pct = a2;
             2: egr_pct = a2;
             3: mgr_pct = a2;
             4: egr_pat = a2;
             5: mgr_pat = a2;
             6: begin seed_v = a2; void'($urandom(seed_v)); end
             default: ;
           endcase
        8: begin
             req_flush = 1'b1;
             @(posedge clk); @(posedge clk);
             rst_n = 1'b0;
             $fwrite(fo, "RST %0d\n", cyc);
             repeat (a1) @(posedge clk);
             rst_n = 1'b1;
             repeat (3) @(posedge clk);
           end
        default: ;
      endcase
    end
    repeat (20) @(posedge clk);
    $fwrite(fo, "STAT cycles=%0d acc_beats=%0d egr_beats=%0d m_pkts=%0d x_pkts=%0d proto_errs=%0d\n",
            cyc, acc_beats, egr_beats, m_pkts, x_pkts, proto_errs);
    $fclose(fo);
    $display("TB_RESULT DONE proto_errs=%0d", proto_errs);
    $finish;
  end

  // watchdog
  initial begin
    #(64'd2000000000);
    $display("TB_RESULT WATCHDOG");
    $finish;
  end
endmodule
