// =============================================================================
// SilicaFlux PacketCore :: tb_mac_adapter -- behavioural AXI-S MAC  <->  adapter  <->  engine
//   The "MAC" here is a bus-functional model written for this test (an RX source that can NOT be paused and a
//   TX sink with random tready).  It is NOT a verified Ethernet MAC; no MAC IP exists in the SilicaFlux repo.
//   +vec=<base> +n=<pkts> +out=<file> +rxgap=<pct> +txrdy=<pct> +txblock=<cycles tready=0 at start> +seed=<n>
//   idx flags bit0 => rx_tuser_bad on the last beat.
// =============================================================================
`timescale 1ns/1ps
module tb_mac_adapter;
  parameter int DW    = 128;
  parameter int RXB   = 32768;
  parameter int MAXF  = 9216;
  localparam int DWB  = DW / 8;
  localparam int SRC_W = 4;
  localparam int META_W = 32;
  localparam int MAXB = 4 * 1024 * 1024;
  localparam int MAXP = 16384;

  logic clk = 1'b0;
  always #5 clk = ~clk;
  logic rst_n;
  integer cyc;
  always @(posedge clk) cyc <= cyc + 1;

  // MAC side
  logic rx_tvalid, rx_tlast, rx_tuser_bad;
  logic [DW-1:0] rx_tdata;
  logic [DWB-1:0] rx_tkeep;
  logic tx_tvalid, tx_tready, tx_tlast, tx_tuser;
  logic [DW-1:0] tx_tdata;
  logic [DWB-1:0] tx_tkeep;
  // adapter <-> engine
  logic s_valid, s_ready, s_last, s_err;
  logic [DW-1:0] s_data;
  logic [DWB-1:0] s_keep;
  logic [SRC_W-1:0] s_src;
  logic [META_W-1:0] s_meta;
  logic m_valid, m_ready, m_last, m_err;
  logic [DW-1:0] m_data;
  logic [DWB-1:0] m_keep;
  logic [3:0] m_queue; logic [2:0] m_tc; logic [SRC_W-1:0] m_src; logic [META_W-1:0] m_meta; logic [31:0] m_hash; logic [15:0] m_len;
  logic x_valid, x_last;
  logic [DW-1:0] x_data; logic [DWB-1:0] x_keep; logic [3:0] x_reason; logic [2:0] x_tc; logic [SRC_W-1:0] x_src; logic [META_W-1:0] x_meta; logic [31:0] x_hash; logic [15:0] x_len;
  logic idle;
  logic [31:0] st_rx, st_ovf, st_bad, st_tx;

  sf_pkt_mac_adapter #(.DW(DW), .SRC_W(SRC_W), .META_W(META_W), .RX_BYTES(RXB), .PORT_ID(3)) u_ad (
    .clk(clk), .rst_n(rst_n),
    .rx_tvalid(rx_tvalid), .rx_tdata(rx_tdata), .rx_tkeep(rx_tkeep), .rx_tlast(rx_tlast), .rx_tuser_bad(rx_tuser_bad),
    .tx_tvalid(tx_tvalid), .tx_tready(tx_tready), .tx_tdata(tx_tdata), .tx_tkeep(tx_tkeep), .tx_tlast(tx_tlast), .tx_tuser(tx_tuser),
    .s_valid(s_valid), .s_ready(s_ready), .s_data(s_data), .s_keep(s_keep), .s_last(s_last), .s_err(s_err), .s_src(s_src), .s_meta(s_meta),
    .m_valid(m_valid), .m_ready(m_ready), .m_data(m_data), .m_keep(m_keep), .m_last(m_last),
    .stat_rx_frames(st_rx), .stat_rx_overflow(st_ovf), .stat_rx_bad(st_bad), .stat_tx_frames(st_tx));

  silicaflux_packet_engine #(.DW(DW), .SRC_W(SRC_W), .META_W(META_W), .MAX_FRAME_BYTES(MAXF)) u_eng (
    .clk(clk), .rst_n(rst_n),
    .s_valid(s_valid), .s_ready(s_ready), .s_data(s_data), .s_keep(s_keep), .s_last(s_last), .s_err(s_err), .s_src(s_src), .s_meta(s_meta),
    .m_valid(m_valid), .m_ready(m_ready), .m_data(m_data), .m_keep(m_keep), .m_last(m_last), .m_err(m_err),
    .m_queue(m_queue), .m_tc(m_tc), .m_src(m_src), .m_meta(m_meta), .m_hash(m_hash), .m_len(m_len),
    .x_valid(x_valid), .x_ready(1'b1), .x_data(x_data), .x_keep(x_keep), .x_last(x_last), .x_reason(x_reason), .x_tc(x_tc),
    .x_src(x_src), .x_meta(x_meta), .x_hash(x_hash), .x_len(x_len),
    .rb_req(1'b0), .rb_we(1'b0), .rb_addr(16'd0), .rb_wdata(32'd0), .rb_tenant(4'd0),
    .rb_rvalid(), .rb_rdata(), .rb_err(), .idle(idle));

  logic [7:0] bytes [0:MAXB-1];
  logic [31:0] idx [0:MAXP*5-1];
  string vec, outf;
  integer npk, rxgap, txrdy, txblock, seed, fo, p, b, nbeats, k, off, len, flags, perrs, nx;
  integer tx_n, tx_sop, tx_frames;
  logic [7:0] tbuf [0:MAXF+DWB];
  logic tx_in, ptx_stall;
  logic [DW-1:0] ptx_data; logic [DWB-1:0] ptx_keep; logic ptx_last;
  integer i2, pc;

  // ---- TX sink / checks ----------------------------------------------------------------------------------------
  always @(posedge clk) begin
    if (!rst_n) begin
      tx_in = 1'b0; tx_n = 0; ptx_stall = 1'b0;
    end else begin
      tx_tready <= (cyc < txblock) ? 1'b0 : ($urandom_range(0, 99) < txrdy);
      if (ptx_stall && tx_tvalid && (tx_tdata !== ptx_data || tx_tkeep !== ptx_keep || tx_tlast !== ptx_last)) begin
        perrs = perrs + 1; $fwrite(fo, "PROTO tx data changed while stalled cyc=%0d\n", cyc);
      end
      if (ptx_stall && !tx_tvalid) begin perrs = perrs + 1; $fwrite(fo, "PROTO tx_tvalid dropped while stalled cyc=%0d\n", cyc); end
      // MAC underrun rule: once a frame has started tx_tvalid must stay high until tlast has been accepted
      if (tx_in && !tx_tvalid) begin perrs = perrs + 1; $fwrite(fo, "PROTO tx underrun (tvalid low mid-frame) cyc=%0d\n", cyc); end
      ptx_stall = tx_tvalid && !tx_tready; ptx_data = tx_tdata; ptx_keep = tx_tkeep; ptx_last = tx_tlast;
      if (tx_tvalid && tx_tready) begin
        if (!tx_in) begin tx_in = 1'b1; tx_n = 0; tx_sop = cyc; end
        for (i2 = 0; i2 < DWB; i2 = i2 + 1) if (tx_tkeep[i2]) tbuf[tx_n * DWB + i2] = tx_tdata[8*i2 +: 8];
        tx_n = tx_n + 1;
        if (tx_tlast) begin
          pc = 0; for (i2 = 0; i2 < DWB; i2 = i2 + 1) if (tx_tkeep[i2]) pc = pc + 1;
          $fwrite(fo, "TX %0d %0d %0d ", tx_sop, cyc, (tx_n - 1) * DWB + pc);
          for (i2 = 0; i2 < (tx_n - 1) * DWB + pc; i2 = i2 + 1) $fwrite(fo, "%02x", tbuf[i2]);
          $fwrite(fo, "\n");
          tx_in = 1'b0; tx_frames = tx_frames + 1;
        end
      end
    end
  end

  // ---- RX source (cannot be paused) ----------------------------------------------------------------------------------
  initial begin
    cyc = 0; perrs = 0; tx_frames = 0; txrdy = 100; rxgap = 0; txblock = 0; seed = 1; npk = 0;
    rx_tvalid = 0; rx_tdata = '0; rx_tkeep = '0; rx_tlast = 0; rx_tuser_bad = 0; tx_tready = 0;
    if (!$value$plusargs("vec=%s", vec)) $fatal(1, "need +vec");
    if (!$value$plusargs("out=%s", outf)) $fatal(1, "need +out");
    void'($value$plusargs("n=%d", npk)); void'($value$plusargs("rxgap=%d", rxgap));
    void'($value$plusargs("txrdy=%d", txrdy)); void'($value$plusargs("txblock=%d", txblock)); void'($value$plusargs("seed=%d", seed));
    void'($urandom(seed));
    $readmemh({vec, ".bytes.mem"}, bytes);
    $readmemh({vec, ".idx.mem"}, idx);
    fo = $fopen(outf, "w");
    rst_n = 1'b0;
    repeat (5) @(posedge clk);
    rst_n = 1'b1;
    repeat (3) @(posedge clk);
    for (p = 0; p < npk; p = p + 1) begin
      off = idx[p*5+0]; len = idx[p*5+1]; flags = idx[p*5+4];
      nbeats = (len + DWB - 1) / DWB;
      for (b = 0; b < nbeats; b = b + 1) begin
        while ($urandom_range(0, 99) < rxgap) begin rx_tvalid <= 1'b0; @(posedge clk); end
        rx_tvalid <= 1'b1;
        rx_tlast  <= (b == nbeats - 1);
        rx_tuser_bad <= ((flags & 1) != 0) && (b == nbeats - 1);
        for (k = 0; k < DWB; k = k + 1) begin
          if (b * DWB + k < len) begin rx_tdata[8*k +: 8] <= bytes[off + b * DWB + k]; rx_tkeep[k] <= 1'b1; end
          else begin rx_tdata[8*k +: 8] <= 8'hA5; rx_tkeep[k] <= 1'b0; end
        end
        @(posedge clk);       // the MAC never waits: there is no tready on RX
      end
    end
    rx_tvalid <= 1'b0; rx_tlast <= 1'b0;
    nx = 0;
    while (nx < 300) begin
      @(posedge clk);
      if (!tx_tvalid && idle && !s_valid && !m_valid) nx = nx + 1; else nx = 0;
      if (cyc > 400000000) nx = 1000;
    end
    $fwrite(fo, "STAT rx_frames=%0d rx_overflow=%0d rx_bad=%0d tx_frames=%0d tb_tx=%0d proto_errs=%0d cycles=%0d\n", st_rx, st_ovf, st_bad, st_tx, tx_frames, perrs, cyc);
    $fclose(fo);
    $display("TB_RESULT DONE proto_errs=%0d", perrs);
    $finish;
  end
endmodule
