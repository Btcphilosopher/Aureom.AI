#!/usr/bin/env python3
"""Condense a nextpnr-ecp5 log into reports/pnr_<tag>.summary: utilisation, final Fmax, critical-path endpoints.
Usage: tools/pnr_summary.py <log> [seed]"""
import re, sys

log = open(sys.argv[1], errors="replace").read().splitlines()
seed = sys.argv[2] if len(sys.argv) > 2 else "?"
out = ["seed=%s" % seed]
for key in ("TRELLIS_COMB", "TRELLIS_FF", "TRELLIS_RAMW", "DP16KD", "MULT18X18D"):
    for l in log:
        m = re.match(r"Info:\s+%s:\s+(\d+)\s*/\s*(\d+)\s+(\d+)%%" % key, l)
        if m:
            out.append("%-13s %6s / %-6s (%s%%)" % (key, m.group(1), m.group(2), m.group(3)))
            break
fm = [l for l in log if "Max frequency for clock" in l]
if fm:
    f = lambda l: re.search(r"([\d.]+) MHz", l).group(1)
    tgt = re.search(r"\((PASS|FAIL) at ([\d.]+) MHz\)", fm[-1])
    out.append("Fmax after routing: %s MHz (%s at %s MHz target)" % (f(fm[-1]), tgt.group(1), tgt.group(2)))
    if len(fm) > 1:
        out.append("Fmax estimate after placement (before routing): %s MHz" % f(fm[0]))
# first critical-path report = the clock domain path after routing (last 'Critical path report for clock' block)
idx = [i for i, l in enumerate(log) if l.startswith("Info: Critical path report for clock")]
if idx:
    blk = log[idx[-1]:]
    src = next((re.search(r"Source (\S+)", l).group(1) for l in blk if "Source" in l), "?")
    snk = [re.search(r"Setup (\S+)", l).group(1) for l in blk if "Setup" in l]
    lr = next((l for l in blk if "ns logic" in l and "routing" in l), "")
    lr = re.search(r"([\d.]+) ns logic, ([\d.]+) ns routing", lr)
    short = lambda s: s if len(s) <= 90 else s[:87] + "..."
    out.append("critical path: %s  ->  %s" % (short(src), short(snk[0]) if snk else "?"))
    if lr:
        out.append("  %s ns logic + %s ns routing" % (lr.group(1), lr.group(2)))
print("\n".join(out))
