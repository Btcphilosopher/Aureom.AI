#!/usr/bin/env python3
"""Export the packet test vectors as artefacts:  vectors/directed_packets.pcap (open in Wireshark), directed_packets.json
(hex bytes + the model's expected parse token + expected fate under the default policy), the TB vector files, and the
published RSS verification vectors."""
import json, os, random, struct, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "model"))
import pktgen as G, pktmodel as M, sfdefs as D, sysmodel as S, traffic as T
import test_model as TM

out = os.path.join(ROOT, "vectors"); os.makedirs(out, exist_ok=True)
rng = random.Random(1)
pk = G.directed_set(rng)
fl = T.Flow(rng)
pk += [G.pad(fl.build(rng, n)) for n in (0, 18, 100, 600, 1400)]
cfg = S.Cfg()
rows = []
for i, p in enumerate(pk):
    f = S.fate(p, i % 16, 0, cfg, 16)
    t = f["tok"]
    rows.append(dict(id=i, src=i % 16, length=len(p), hex=p.hex(),
                     token={k: (hex(v) if k in ("dmac", "smac", "sip", "dip", "flow_hash") else v) for k, v in t.items()},
                     perr=next(n for n, v in D.CODES["PE"].items() if v == t["perr"]),
                     unsupp=next(n for n, v in D.CODES["UN"].items() if v == t["unsupp"]),
                     default_policy_fate=f["fate"], default_policy_reason=f["reason"],
                     queue=f["dec"]["qid"], tc=f["dec"]["tc"]))
json.dump(rows, open(os.path.join(out, "directed_packets.json"), "w"), indent=1)
# classic pcap (LINKTYPE_ETHERNET)
with open(os.path.join(out, "directed_packets.pcap"), "wb") as f:
    f.write(struct.pack("<IHHiIII", 0xA1B2C3D4, 2, 4, 0, 0, 65535, 1))
    for i, p in enumerate(pk):
        f.write(struct.pack("<IIII", 1700000000 + i, 0, len(p), len(p)) + p)
G.write_vectors(os.path.join(out, "parser_directed"), [(p, i % 16, i) for i, p in enumerate(pk)])
rss = []
for dst, src, dp, sp, h3, h4 in TM.V4:
    rss.append(dict(family="ipv4", src=src, dst=dst, sport=sp, dport=dp, hash_l3=hex(h3), hash_l3l4=hex(h4)))
for dst, src, dp, sp, h3, h4 in TM.V6:
    rss.append(dict(family="ipv6", src=src, dst=dst, sport=sp, dport=dp, hash_l3=hex(h3), hash_l3l4=hex(h4)))
json.dump(dict(source="Intel 82599 datasheet 7.1.2.8.3 RSS Verification Suite, as published in DPDK app/test/test_thash.c",
               key=M.MS_KEY.hex(), vectors=rss), open(os.path.join(out, "rss_verification_vectors.json"), "w"), indent=1)
print("exported %d packets, %d RSS vectors to vectors/" % (len(pk), len(rss)))
