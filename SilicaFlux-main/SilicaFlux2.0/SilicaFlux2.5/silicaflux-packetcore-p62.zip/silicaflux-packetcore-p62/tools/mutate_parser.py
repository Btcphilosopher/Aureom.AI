#!/usr/bin/env python3
"""Mutation check: inject single-point RTL bugs into the parser; the parser regression MUST fail for each."""
import os, shutil, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = open(os.path.join(ROOT, "rtl/sf_pkt_parser.sv")).read()
MUTS = [
    ("ihl check off-by-one", "(ihl < 4'd5)", "(ihl < 4'd4)"),
    ("eth runt threshold", "(p0_avail < 8'd14)", "(p0_avail < 8'd13)"),
    ("checksum carry-in of upper sum bits dropped", "f1 = {1'b0, tot[15:0]} + {12'd0, tot[20:16]};", "f1 = {1'b0, tot[15:0]};"),
    ("checksum compare constant", "(f1 == 17'h0FFFF)", "(f1 == 17'h00000)"),
    ("ext header end bound >=", "if (endo > {4'b0000, av}) begin", "if (endo >= {4'b0000, av}) begin"),
    ("udp length minimum", "if (ulen < 16'd8) e_l4l = 1'b1;", "if (ulen < 16'd7) e_l4l = 1'b1;"),
    ("fragment offset low bit ignored", "if (fo[15:3] != 13'd0) nf = 1'b1;", "if (fo[15:4] != 12'd0) nf = 1'b1;"),
    ("tcp data-offset minimum", "(doff < 4'd5)", "(doff < 4'd4)"),
    ("udp datagram bound <=", "({1'b0, dg_end} < ({1'b0, ulen} + {9'd0, l_off}))", "({1'b0, dg_end} <= ({1'b0, ulen} + {9'd0, l_off}))"),
    ("MF flag ignored", "ff[13] || (ff[12:0] != 13'd0)", "(ff[12:0] != 13'd0)"),
    ("keep mask removed (reads beyond packet)", "bm[8*k +: 8] = acc_keep[k] ? acc_data[8*k +: 8] : 8'h00;", "bm[8*k +: 8] = acc_data[8*k +: 8];"),
    ("l3 offset for 1 vlan tag", "2'd1:    l3b = wbd(w, 10'(18 + rel));", "2'd1:    l3b = wbd(w, 10'(19 + rel));"),
    ("tcp min header", "need4  = is_tcp ? 10'd20", "need4  = is_tcp ? 10'd19"),
    ("vxlan I-flag bit", "l4w[8*8 + 3]", "l4w[8*8 + 2]"),
    ("ipv6 ext len units", "else                  hl = ({4'b0000, ln} + 12'd1) << 3;", "else                  hl = ({4'b0000, ln} + 12'd1) << 2;"),
    ("ipv6 ext end-offset width (10b wrap)", "reg [11:0] hl, endo;", "reg [9:0] hl, endo;"),
]
def main():
    work = os.path.join(ROOT, "sim", "mutants"); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
    killed = 0
    for i, (name, old, new) in enumerate(MUTS):
        assert SRC.count(old) == 1, (name, SRC.count(old))
        d = os.path.join(work, "m%d" % i); os.makedirs(d)
        for f in ("sf_pkt_toeplitz.sv",):
            shutil.copy(os.path.join(ROOT, "rtl", f), d)
        open(os.path.join(d, "sf_pkt_parser.sv"), "w").write(SRC.replace(old, new))
        r = subprocess.run([sys.executable, os.path.join(ROOT, "model/run_parser_tests.py"), "--rtl", d, "--work", os.path.join(d, "w"),
                            "--nrandom", "400", "--quick"], capture_output=True, text=True)
        caught = r.returncode != 0
        killed += caught
        print("%-45s %s" % (name, "KILLED" if caught else "SURVIVED  <-- test gap"))
    print("MUTATION SCORE: %d/%d killed" % (killed, len(MUTS)))
    sys.exit(0 if killed == len(MUTS) else 1)
if __name__ == "__main__":
    main()
