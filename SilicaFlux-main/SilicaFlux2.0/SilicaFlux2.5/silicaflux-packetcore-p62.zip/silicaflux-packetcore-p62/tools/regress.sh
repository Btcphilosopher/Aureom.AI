#!/usr/bin/env bash
# Full regression with every step logged under reports/ (used to build reports/SUMMARY.md).
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"; mkdir -p reports; rc=0
step() { local name="$1"; shift; echo "== $name"; "$@" > "reports/$name.log" 2>&1; local r=$?; echo "   exit $r"; [ $r -eq 0 ] || rc=1; }
before=$(sha256sum rtl/sf_pkt_defs.svh rtl/sf_pkt_macros.svh model/sfdefs.py docs/REGISTERS.md | sha256sum)
python3 tools/gen_defs.py > reports/gen.log 2>&1
after=$(sha256sum rtl/sf_pkt_defs.svh rtl/sf_pkt_macros.svh model/sfdefs.py docs/REGISTERS.md | sha256sum)
[ "$before" = "$after" ] && echo "== gen: generated files up to date" || { echo "== gen: generated files were STALE (regenerated)"; rc=1; }
step verify_vendor bash -c "cd third_party/silicaflux-reused && sha256sum -c SHA256SUMS"
step vendor_build tools/prep_vendor.sh
step lint tools/lint.sh
step model_selftest python3 model/test_model.py
step parser_regression python3 model/run_parser_tests.py --dw 128 --nrandom 3000 --seed 7
step parser_sweep tools/parser_sweep.sh
step final_system_dw128 python3 model/run_system_tests.py --dw 128 --metrics reports/system_metrics_dw128.json
step system_sweep tools/system_sweep.sh
step system_vendored_fifo python3 model/run_system_tests.py --dw 128 --fifo-ram 0
step mac_regression python3 model/run_mac_tests.py 128 64 256 512
step parser_mutation python3 tools/mutate_parser.py
python3 tools/make_summary.py >> reports/gen.log 2>&1
echo "REGRESSION $([ $rc -eq 0 ] && echo PASS || echo FAIL)" | tee reports/regress.result
exit $rc
