#!/usr/bin/env python3
"""
SilicaFlux PacketCore (Project 62) -- single source of truth for every layout shared between
the RTL, the independent Python model and the documentation.

Emits:
  rtl/sf_pkt_defs.svh   SystemVerilog localparams (included INSIDE modules; no packages, because the
                        Yosys 0.33 front-end used by the SilicaFlux flows cannot read packages/enums/structs)
  model/sfdefs.py       Python mirror (pack/unpack helpers, register map)
  docs/REGISTERS.md     Register / counter reference

Run:  python3 tools/gen_defs.py      (from the project root)
"""
import os, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

VERSION = (1, 0, 0)          # (major, minor, patch).  Major bump == incompatible register layout.
ID_VALUE = 0x53465045        # 'SFPE'

# ---------------------------------------------------------------------------------------------
# Parser token (parser -> classifier).  LSB first.  All widths are fixed, independent of DW.
# ---------------------------------------------------------------------------------------------
TOK = [
    ("eop_seen", 1), ("avail", 8), ("src_id", 8),
    ("dmac", 48), ("smac", 48), ("ethertype", 16),
    ("vlan_cnt", 2), ("vlan_vid", 12), ("vlan_pcp", 3), ("vlan_dei", 1), ("vlan_vid2", 12),
    ("l3_type", 2), ("l3_off", 8),
    ("ip_w0", 16), ("ip_tc", 8), ("ip_ttl", 8), ("ip_proto", 8), ("ip_csum", 16),
    ("need_len", 16), ("ip_frag", 1), ("ip_nonfirst", 1),
    ("sip", 128), ("dip", 128),
    ("l4_type", 2), ("l4_off", 8), ("sport", 16), ("dport", 16), ("tcp_flags", 8),
    ("vni_valid", 1), ("vni", 24),
    ("flow_hash", 32),
    ("perr", 4), ("unsupp", 3), ("csum_ok", 1),
]

# ---------------------------------------------------------------------------------------------
# Decision (classifier -> dispatcher).
# ---------------------------------------------------------------------------------------------
DEC = [
    ("verdict", 2), ("qid", 4), ("tc", 3), ("reason", 4),
    ("rule_hit", 1), ("rule_idx", 8), ("count", 1),
    ("need_len", 16), ("flow_hash", 32),
    ("patch_en", 4),
    ("patch_off0", 8), ("patch_off1", 8), ("patch_off2", 8), ("patch_off3", 8),
    ("patch_val0", 8), ("patch_val1", 8), ("patch_val2", 8), ("patch_val3", 8),
    ("rewrote", 1),
]

# ---------------------------------------------------------------------------------------------
# Match/action rule.  valid + action occupy the low 24 bits (ACT_W) so the action table copy is a
# plain low-bit slice.  Then (value, mask) pairs per match field.  Register window = 32-bit words.
# ---------------------------------------------------------------------------------------------
RULE_ACT = [
    ("valid", 1), ("verdict", 2), ("set_queue", 1), ("qid", 4), ("qsel_hash", 1), ("hash_bits", 2),
    ("set_tc", 1), ("tc", 3), ("count", 1), ("set_dscp", 1), ("dscp", 6), ("dec_ttl", 1),
]
RULE_MATCH = [   # name, width (value and mask each)
    ("src_id", 8), ("frag", 1), ("vlan_valid", 1), ("vid", 12), ("pcp", 3), ("ethertype", 16),
    ("dmac", 48), ("l3_type", 2), ("ip_proto", 8), ("dscp", 6),
    ("sip", 128), ("dip", 128), ("sport", 16), ("dport", 16), ("tcp_flags", 8),
    ("vni_valid", 1), ("vni", 24),
]
RULE = list(RULE_ACT)
for n, w in RULE_MATCH:
    RULE.append((n + "_v", w))
    RULE.append((n + "_m", w))

# ---------------------------------------------------------------------------------------------
# Codes
# ---------------------------------------------------------------------------------------------
CODES = {
    "VERD": [("FWD", 0), ("DROP", 1), ("MGMT", 2)],
    "L3": [("NONE", 0), ("IPV4", 1), ("IPV6", 2)],
    "L4": [("NONE", 0), ("TCP", 1), ("UDP", 2), ("OTHER", 3)],
    "PE": [("NONE", 0), ("ETH_TRUNC", 1), ("IP_VER", 2), ("IPV4_IHL", 3), ("L3_TRUNC", 4),
           ("IPV4_TOTLEN", 5), ("IPV4_CSUM", 6), ("L4_TRUNC", 7), ("TCP_DOFF", 8), ("L4_LEN", 9)],
    "UN": [("NONE", 0), ("EXT_LIMIT", 1), ("VLAN_OVF", 2), ("WINDOW", 3)],
    "DR": [("NONE", 0), ("RULE", 1), ("MALFORMED", 2), ("UNSUPP", 3), ("FRAG", 4), ("MACERR", 5),
           ("KEEP", 6), ("RUNT", 7), ("OVERSIZE", 8), ("LENMIS", 9), ("QFULL", 10)],
    "PR": [("RULE", 0), ("MALFORMED", 1), ("UNSUPP", 2), ("FRAG", 3), ("TTL", 4), ("DEFAULT", 5)],
    "ACT": [("DROP", 0), ("PUNT", 1), ("CONT", 2)],       # policy actions for error classes
    "SCHED": [("RR", 0), ("SP", 1), ("DWRR", 2)],
    "TCSRC": [("NONE", 0), ("PCP", 1), ("DSCP", 2)],
    "RS": [("OK", 0), ("ERR_PERM", 1), ("ERR_STAGE", 2), ("ERR_POLICY", 3), ("ERR_RANGE", 4), ("ERR_CMD", 5)],
    "CMD": [("COMMIT", 1), ("CLEAR", 2), ("READ", 3)],
}

# ---------------------------------------------------------------------------------------------
# Counters.  type: add | max | min | gauge.   Global block has fixed stride G_STRIDE, then per-queue
# blocks of Q_STRIDE slots each.
# ---------------------------------------------------------------------------------------------
GLOBAL_CNT = [
    ("rx_pkts", "add", "Packets accepted at ingress (counted at last beat)"),
    ("rx_bytes", "add", "Bytes accepted at ingress"),
    ("fwd_pkts", "add", "Packets delivered on the data egress port"),
    ("fwd_bytes", "add", "Bytes delivered on the data egress port"),
    ("mgmt_pkts", "add", "Packets delivered on the management port"),
    ("mgmt_bytes", "add", "Bytes delivered on the management port"),
    ("drop_pkts", "add", "All dropped packets (sum of the drop_* reasons)"),
    ("drop_bytes", "add", "Bytes of dropped packets (bytes seen before the drop decision completed)"),
    ("drop_macerr", "add", "Dropped: MAC flagged bad frame (s_err on last beat)"),
    ("drop_keep", "add", "Dropped: illegal byte-enable pattern (keep contract violated)"),
    ("drop_runt", "add", "Dropped: shorter than POL_LEN.min_len"),
    ("drop_oversize", "add", "Dropped: longer than POL_LEN.max_len"),
    ("drop_malformed", "add", "Dropped: header validation failure, policy=DROP"),
    ("drop_lenmis", "add", "Dropped: declared IP length exceeds received frame (late check)"),
    ("drop_unsupp", "add", "Dropped: unsupported header chain, policy=DROP"),
    ("drop_frag", "add", "Dropped: IP fragment, policy=DROP"),
    ("drop_rule", "add", "Dropped by a match/action rule or the default action"),
    ("drop_qfull", "add", "Dropped: tail-drop on egress queue / management queue overflow"),
    ("parse_err", "add", "Packets with a header-validation error (before policy)"),
    ("parse_unsupp", "add", "Packets with an unsupported header chain (before policy)"),
    ("parse_frag", "add", "IP fragments seen (before policy)"),
    ("ing_stall", "add", "Cycles s_valid && !s_ready (ingress backpressure)"),
    ("egr_stall", "add", "Cycles m_valid && !m_ready (egress backpressure)"),
    ("egr_busy", "add", "Cycles m_valid && m_ready (data beats delivered)"),
    ("cycles", "add", "Clock cycles while CTRL.CNT_EN=1 (throughput denominator)"),
    ("ttl_punt", "add", "Packets punted to management because TTL/hop-limit expired"),
    ("rewrite_pkts", "add", "Packets whose headers were rewritten (DSCP/TTL) with checksum update"),
    ("viol", "add", "Rejected register accesses (tenant isolation violations)"),
    ("lat_pipe_sum", "add", "Sum of ingress-SOP -> dispatch latency (cycles, clipped 2^20-1 per packet)"),
    ("lat_pipe_cnt", "add", "Samples in lat_pipe_sum"),
    ("lat_pipe_min", "min", "Minimum ingress-SOP -> dispatch latency (cycles)"),
    ("lat_pipe_max", "max", "Maximum ingress-SOP -> dispatch latency (cycles)"),
    ("lat_e2e_sum", "add", "Sum of ingress-SOP -> egress-SOP latency (cycles, clipped 2^20-1 per packet)"),
    ("lat_e2e_cnt", "add", "Samples in lat_e2e_sum"),
    ("lat_e2e_min", "min", "Minimum ingress-SOP -> egress-SOP latency (cycles)"),
    ("lat_e2e_max", "max", "Maximum ingress-SOP -> egress-SOP latency (cycles)"),
    ("mgmt_drop", "add", "Packets dropped because the management queue was full"),
    ("rb_reads", "add", "Register reads"),
    ("rb_writes", "add", "Register writes"),
]
G_STRIDE = 48
QUEUE_CNT = [
    ("enq_pkts", "add", "Packets committed into this queue"),
    ("deq_pkts", "add", "Packets sent from this queue"),
    ("deq_bytes", "add", "Bytes sent from this queue"),
    ("drop_pkts", "add", "Tail-dropped packets (queue full)"),
    ("wm_cycles", "add", "Cycles occupancy > QCFG.WM (congestion counter)"),
    ("hwm_bytes", "max", "High-water mark of occupancy (bytes)"),
    ("occ_bytes", "gauge", "Occupancy now (bytes, latched at snapshot)"),
    ("spare", "add", "Reserved"),
]
Q_STRIDE = 8
NQ_MAX = 16
NR_MAX = 64
NT_MAX = 16

# ---------------------------------------------------------------------------------------------
# Register map (byte addresses)
# ---------------------------------------------------------------------------------------------
# (name, addr, access, reset, [(field, lsb, width, description)], description)
REGS = [
    ("ID", 0x000, "RO", ID_VALUE, [], "ASCII 'SFPE'"),
    ("VERSION", 0x004, "RO", (VERSION[0] << 16) | (VERSION[1] << 8) | VERSION[2],
     [("patch", 0, 8, ""), ("minor", 8, 8, ""), ("major", 16, 8, "major change = incompatible register layout")],
     "Register-interface version"),
    ("CAPS0", 0x008, "RO", None,
     [("num_queues", 0, 8, ""), ("num_rules", 8, 8, ""), ("num_tenants", 16, 8, ""), ("dw_bytes", 24, 8, "datapath width in bytes")],
     "Build-time parameters"),
    ("CAPS1", 0x00C, "RO", None,
     [("rss", 0, 1, ""), ("vxlan", 1, 1, ""), ("rewrite", 2, 1, ""), ("tenant", 3, 1, ""), ("perf", 4, 1, ""),
      ("max_ext", 5, 3, "IPv6 extension headers walked"), ("max_frame", 16, 16, "bytes")],
     "Build-time features"),
    ("CAPS2", 0x010, "RO", None,
     [("queue_64b", 0, 16, "per-queue storage in 64-byte units"), ("win_bytes", 16, 8, "parser header window"),
      ("cnt_bits", 24, 8, "counter width")],
     "Build-time sizes"),
    ("CTRL", 0x014, "RW-A", 0x3,
     [("enable", 0, 1, "0 = stop accepting new packets (quiesce) so global policy can be changed atomically"),
      ("cnt_en", 1, 1, "count cycles / enable counters"),
      ("snap_global", 8, 1, "W1P: snapshot all global/queue counters"),
      ("clear_global", 9, 1, "W1P: clear all global/queue counters"),
      ("snap_rules", 10, 1, "W1P: snapshot per-rule counters (any tenant)"),
      ("clear_rules", 11, 1, "W1P: clear per-rule counters (admin)")],
     "Control (admin). Pulse bits read as 0"),
    ("STATUS", 0x018, "RO", None,
     [("idle", 0, 1, "no packet in flight anywhere in the engine"), ("inflight", 8, 8, "packets admitted, not yet dispatched")],
     "Status"),
    ("SCRATCH", 0x01C, "RW-A", 0, [], "Bus read-back test"),
    ("POL_ERR", 0x020, "RW-A", (1 << 2) | (2 << 4) | (1 << 8) | (1 << 9),
     [("malformed_act", 0, 2, "0 DROP,1 PUNT"), ("unsupp_act", 2, 2, "0 DROP,1 PUNT,2 CONT"),
      ("frag_act", 4, 2, "0 DROP,1 PUNT,2 CONT"), ("csum_en", 8, 1, "verify IPv4 header checksum"),
      ("vxlan_en", 9, 1, "extract VNI from UDP/VXLAN"), ("qdrop", 10, 1, "0 lossless backpressure, 1 tail-drop on queue full")],
     "Error / unsupported / fragment policy"),
    ("POL_LEN", 0x024, "RW-A", None,
     [("min_len", 0, 16, "bytes, 0 disables"), ("max_len", 16, 16, "bytes, clamped to build MAX_FRAME_BYTES")],
     "Frame length limits (frames exclude Ethernet FCS)"),
    ("POL_DEF", 0x028, "RW-A", 0,
     [("verdict", 0, 2, "action when no rule matches"), ("set_q", 2, 1, "use def_qid instead of the TC queue map"),
      ("qid", 4, 4, ""), ("tc", 8, 3, "")],
     "Default (no-match) action"),
    ("POL_TPID", 0x02C, "RW-A", 0x88A88100,
     [("tpid0", 0, 16, ""), ("tpid1", 16, 16, "")], "VLAN TPIDs recognised"),
    ("POL_VXLAN", 0x030, "RW-A", 4789, [("port", 0, 16, "")], "VXLAN UDP destination port"),
    ("POL_TC", 0x034, "RW-A", 0, [("tc_src", 0, 2, "0 none (TC 0), 1 VLAN PCP, 2 IP DSCP[5:3]")], "Traffic-class derivation"),
    ("TC_QMAP", 0x038, "RW-A", 0, [("tc%d" % i, 4 * i, 4, "queue for TC %d" % i) for i in range(8)], "TC -> queue map"),
    ("RL_PERIOD", 0x03C, "RW-A", 1, [("period", 0, 16, "clocks per token-refill tick (>=1)")], "Rate-limiter tick"),
    ("SCHED_MODE", 0x040, "RW-A", 0, [("mode", 0, 2, "0 RR, 1 strict priority(+aging), 2 DWRR")], "Scheduler mode"),
    ("SCHED_STARVE", 0x044, "RW-A", 0, [("cycles", 0, 32, "SP: a queue waiting this long becomes urgent; 0 disables")], "Starvation guard"),
    ("SCHED_QUANT", 0x048, "RW-A", 2048, [("bytes", 0, 16, "DWRR quantum per weight unit")], "DWRR quantum"),
    ("VIOL_LAST", 0x050, "RO", 0, [("addr", 0, 16, ""), ("tenant", 16, 4, ""), ("is_write", 20, 1, "")], "Last rejected access"),
]
RSS_KEY_BASE = 0x060
RSS_KEY_WORDS = 10
QCFG_BASE = 0x100
QCFG_STRIDE = 0x20
QCFG = [("PRIO", 0x00, "RW-A", 0, "priority class 0 (highest)..3"),
        ("WEIGHT", 0x04, "RW-A", 1, "DWRR weight >= 1"),
        ("RL_INC", 0x08, "RW-A", 0, "bytes added per RL_PERIOD ticks; 0 = unlimited"),
        ("RL_BURST", 0x0C, "RW-A", 0xFFFF, "token cap (bytes)"),
        ("WM", 0x10, "RW-A", 0xFFFFFFFF, "congestion watermark (bytes)"),
        ("OCC", 0x14, "RO", 0, "live occupancy (bytes)")]
TEN_BASE = 0x400
TEN_STRIDE = 0x10
TEN = [("SCOPE_VID", 0x0, "vid[11:0], valid[16]"), ("SCOPE_VNI", 0x4, "vni[23:0], valid[31]"),
       ("QMASK", 0x8, "queues the tenant may use"), ("ENABLE", 0xC, "[0] tenant active")]
OWNER_BASE = 0x600
STAGE_BASE = 0x800
RULE_CMD = 0x880
RULE_STATUS = 0x884
STAGE_OWNER = 0x888
RULE_SNAP = 0x88C
RULE_CNT_BASE = 0x1000
RULE_CNT_STRIDE = 0x10
GCNT_BASE = 0x4000
GCNT_STRIDE = 8


def layout(fields):
    out, pos = {}, 0
    for n, w in fields:
        out[n] = (pos, w)
        pos += w
    return out, pos


def main():
    tok, TOK_W = layout(TOK)
    dec, DEC_W = layout(DEC)
    rule, RULE_W = layout(RULE)
    act, ACT_W = layout(RULE_ACT)
    RULE_WORDS = (RULE_W + 31) // 32

    gnames = [g[0] for g in GLOBAL_CNT]
    assert len(gnames) <= G_STRIDE
    NSLOT = G_STRIDE + NQ_MAX * Q_STRIDE

    # ------------------------------------------------------------------ SystemVerilog
    L = []
    a = L.append
    a("// -----------------------------------------------------------------------------")
    a("// GENERATED by tools/gen_defs.py -- DO NOT EDIT.  SilicaFlux PacketCore (Project 62)")
    a("// Included inside modules (no packages: Yosys 0.33 front-end constraint).")
    a("// -----------------------------------------------------------------------------")
    a("/* verilator lint_off UNUSEDPARAM */")
    a("localparam int SFP_VER_MAJOR = %d;" % VERSION[0])
    a("localparam int SFP_VER_MINOR = %d;" % VERSION[1])
    a("localparam int SFP_VER_PATCH = %d;" % VERSION[2])
    a("localparam int NQ_MAX = %d;  localparam int NR_MAX = %d;  localparam int NT_MAX = %d;" % (NQ_MAX, NR_MAX, NT_MAX))

    def emit_layout(prefix, lay, total):
        for n, (p, w) in lay.items():
            a("localparam int %s_%s_LSB = %d;  localparam int %s_%s_W = %d;" % (prefix, n.upper(), p, prefix, n.upper(), w))
        a("localparam int %s_W = %d;" % (prefix, total))

    emit_layout("TK", tok, TOK_W)
    emit_layout("DC", dec, DEC_W)
    emit_layout("RL", rule, RULE_W)
    a("localparam int RL_ACT_W = %d;" % ACT_W)
    a("localparam int RL_WORDS = %d;" % RULE_WORDS)
    for grp, items in CODES.items():
        for n, v in items:
            a("localparam int %s_%s = %d;" % (grp, n, v))
    # counters
    for i, g in enumerate(GLOBAL_CNT):
        a("localparam int CI_%s = %d;" % (g[0].upper(), i))
    a("localparam int CI_G_STRIDE = %d;  localparam int CI_Q_STRIDE = %d;  localparam int CI_NSLOT = %d;" % (G_STRIDE, Q_STRIDE, NSLOT))
    for i, q in enumerate(QUEUE_CNT):
        a("localparam int CQ_%s = %d;" % (q[0].upper(), i))
    # counter type ROM function: 0 add 1 max 2 min 3 gauge 4 unused
    a("function automatic [2:0] cnt_type(input integer idx);")
    a("  integer k;")
    a("  begin")
    a("    cnt_type = 3'd4;")
    a("    if (idx < CI_G_STRIDE) begin")
    for i, g in enumerate(GLOBAL_CNT):
        t = {"add": 0, "max": 1, "min": 2, "gauge": 3}[g[1]]
        if t != 0:
            a("      if (idx == %d) cnt_type = 3'd%d;" % (i, t))
        else:
            pass
    a("      if (idx < %d) begin if (cnt_type == 3'd4) cnt_type = 3'd0; end" % len(GLOBAL_CNT))
    a("    end else begin")
    a("      k = (idx - CI_G_STRIDE) % CI_Q_STRIDE;")
    for i, q in enumerate(QUEUE_CNT):
        t = {"add": 0, "max": 1, "min": 2, "gauge": 3}[q[1]]
        a("      if (k == %d) cnt_type = 3'd%d;" % (i, t))
    a("    end")
    a("  end")
    a("endfunction")
    # registers
    for r in REGS:
        a("localparam int A_%s = 32'h%04X;" % (r[0], r[1]))
        for f in r[4]:
            a("localparam int F_%s_%s_LSB = %d;  localparam int F_%s_%s_W = %d;" % (r[0], f[0].upper(), f[1], r[0], f[0].upper(), f[2]))
    a("localparam int A_RSS_KEY = 32'h%04X;" % RSS_KEY_BASE)
    a("localparam int A_QCFG = 32'h%04X;  localparam int A_QCFG_STRIDE = %d;" % (QCFG_BASE, QCFG_STRIDE))
    for n, off, *_ in QCFG:
        a("localparam int QC_%s = 32'h%02X;" % (n, off))
    a("localparam int A_TEN = 32'h%04X;  localparam int A_TEN_STRIDE = %d;" % (TEN_BASE, TEN_STRIDE))
    for n, off, _ in TEN:
        a("localparam int TN_%s = 32'h%X;" % (n, off))
    a("localparam int A_OWNER = 32'h%04X;" % OWNER_BASE)
    a("localparam int A_STAGE = 32'h%04X;" % STAGE_BASE)
    a("localparam int A_RULE_CMD = 32'h%04X;  localparam int A_RULE_STATUS = 32'h%04X;  localparam int A_STAGE_OWNER = 32'h%04X;  localparam int A_RULE_SNAP = 32'h%04X;" % (RULE_CMD, RULE_STATUS, STAGE_OWNER, RULE_SNAP))
    a("localparam int A_RULE_CNT = 32'h%04X;  localparam int A_RULE_CNT_STRIDE = %d;" % (RULE_CNT_BASE, RULE_CNT_STRIDE))
    a("localparam int A_GCNT = 32'h%04X;  localparam int A_GCNT_STRIDE = %d;" % (GCNT_BASE, GCNT_STRIDE))
    a("/* verilator lint_on UNUSEDPARAM */")
    with open(os.path.join(ROOT, "rtl", "sf_pkt_macros.svh"), "w") as f:
        f.write("// GENERATED by tools/gen_defs.py -- DO NOT EDIT.  Width macros usable in module port lists.\n"
                "`ifndef SFP_DEFS_MACROS\n`define SFP_DEFS_MACROS\n"
                "`define SFP_TK_W %d\n`define SFP_DC_W %d\n`define SFP_RL_W %d\n`define SFP_RL_ACT_W %d\n`define SFP_NSLOT %d\n`endif\n"
                % (TOK_W, DEC_W, RULE_W, ACT_W, NSLOT))
    with open(os.path.join(ROOT, "rtl", "sf_pkt_defs.svh"), "w") as f:
        f.write("\n".join(L) + "\n")

    # ------------------------------------------------------------------ Python
    P = []
    p = P.append
    p('"""GENERATED by tools/gen_defs.py -- DO NOT EDIT.  Python mirror of rtl/sf_pkt_defs.svh."""')
    p("VERSION = %r" % (VERSION,))
    p("ID_VALUE = 0x%08X" % ID_VALUE)
    p("TOK = %r" % (TOK,))
    p("DEC = %r" % (DEC,))
    p("RULE = %r" % (RULE,))
    p("RULE_ACT = %r" % (RULE_ACT,))
    p("RULE_MATCH = %r" % (RULE_MATCH,))
    p("TOK_W = %d\nDEC_W = %d\nRULE_W = %d\nRULE_ACT_W = %d\nRULE_WORDS = %d" % (TOK_W, DEC_W, RULE_W, ACT_W, RULE_WORDS))
    p("CODES = %r" % ({k: dict(v) for k, v in CODES.items()},))
    for grp, items in CODES.items():
        for n, v in items:
            p("%s_%s = %d" % (grp, n, v))
    p("GLOBAL_CNT = %r" % ([(g[0], g[1]) for g in GLOBAL_CNT],))
    p("QUEUE_CNT = %r" % ([(q[0], q[1]) for q in QUEUE_CNT],))
    p("G_STRIDE = %d\nQ_STRIDE = %d\nNQ_MAX = %d\nNR_MAX = %d\nNT_MAX = %d" % (G_STRIDE, Q_STRIDE, NQ_MAX, NR_MAX, NT_MAX))
    p("REGS = %r" % ([(r[0], r[1], r[2], r[3], [(f[0], f[1], f[2]) for f in r[4]]) for r in REGS],))
    p("RSS_KEY_BASE = 0x%X\nRSS_KEY_WORDS = %d" % (RSS_KEY_BASE, RSS_KEY_WORDS))
    p("QCFG_BASE = 0x%X\nQCFG_STRIDE = 0x%X" % (QCFG_BASE, QCFG_STRIDE))
    p("QCFG = %r" % ({n: off for n, off, *_ in QCFG},))
    p("TEN_BASE = 0x%X\nTEN_STRIDE = 0x%X" % (TEN_BASE, TEN_STRIDE))
    p("TEN = %r" % ({n: off for n, off, _ in TEN},))
    p("OWNER_BASE = 0x%X\nSTAGE_BASE = 0x%X\nRULE_CMD = 0x%X\nRULE_STATUS = 0x%X\nSTAGE_OWNER = 0x%X\nRULE_SNAP = 0x%X" % (OWNER_BASE, STAGE_BASE, RULE_CMD, RULE_STATUS, STAGE_OWNER, RULE_SNAP))
    p("RULE_CNT_BASE = 0x%X\nRULE_CNT_STRIDE = 0x%X\nGCNT_BASE = 0x%X\nGCNT_STRIDE = 0x%X" % (RULE_CNT_BASE, RULE_CNT_STRIDE, GCNT_BASE, GCNT_STRIDE))
    p("""
def _layout(fields):
    out, pos = {}, 0
    for n, w in fields:
        out[n] = (pos, w)
        pos += w
    return out, pos

TOK_L, _ = _layout(TOK)
DEC_L, _ = _layout(DEC)
RULE_L, _ = _layout(RULE)

def unpack(layout, value):
    return {n: (value >> p) & ((1 << w) - 1) for n, (p, w) in layout.items()}

def pack(layout, d):
    v = 0
    for n, x in d.items():
        p, w = layout[n]
        assert 0 <= x < (1 << w), (n, x, w)
        v |= x << p
    return v

def counter_index(name):
    return [g[0] for g in GLOBAL_CNT].index(name)

def queue_counter_index(q, name):
    return G_STRIDE + q * Q_STRIDE + [c[0] for c in QUEUE_CNT].index(name)

def reg_addr(name):
    for r in REGS:
        if r[0] == name:
            return r[1]
    raise KeyError(name)

def reg_field(name, field):
    for r in REGS:
        if r[0] == name:
            for f in r[4]:
                if f[0] == field:
                    return f[1], f[2]
    raise KeyError((name, field))

def word_list(value, nwords):
    return [(value >> (32 * i)) & 0xFFFFFFFF for i in range(nwords)]
""")
    with open(os.path.join(ROOT, "model", "sfdefs.py"), "w") as f:
        f.write("\n".join(P) + "\n")

    # ------------------------------------------------------------------ Markdown
    M = []
    m = M.append
    m("# SilicaFlux PacketCore register & counter reference\n")
    m("_Generated by `tools/gen_defs.py` from the same table that produces `rtl/sf_pkt_defs.svh` and `model/sfdefs.py`._\n")
    m("Register version **%d.%d.%d** (`VERSION` register: `[23:16]` major, `[15:8]` minor, `[7:0]` patch). A major-version change means an "
      "incompatible layout; minor adds registers/fields; patch is documentation/behaviour-neutral." % VERSION)
    m("\nBus: word-addressed 32-bit, byte addresses below. One request per cycle (`rb_req`), response one cycle later (`rb_rvalid`, `rb_rdata`, `rb_err`). "
      "`rb_tenant` identifies the accessor: **0 = administrator**, 1..NT-1 = tenants. Access classes: `RO`, `RW-A` (administrator only), `RW-T` (owner or administrator).\n")
    m("## Global registers\n")
    m("| Addr | Name | Access | Reset | Fields / description |")
    m("|---|---|---|---|---|")
    for r in REGS:
        fl = "; ".join("`%s[%d:%d]`%s" % (f[0], f[1] + f[2] - 1, f[1], (" " + f[3]) if f[3] else "") for f in r[4])
        rst = "build-dependent" if r[3] is None else "0x%08X" % r[3]
        m("| 0x%04X | %s | %s | %s | %s %s |" % (r[1], r[0], r[2], rst, r[5] + ".", fl))
    m("| 0x%04X..0x%04X | RSS_KEY[0..9] | RW-A | Microsoft RSS default key | Toeplitz key, word 0 = key bytes 0..3 (byte 0 = bits [31:24]) |" % (RSS_KEY_BASE, RSS_KEY_BASE + 4 * RSS_KEY_WORDS - 4))
    m("\n## Per-queue registers (`0x%04X + q*0x%X`)\n" % (QCFG_BASE, QCFG_STRIDE))
    m("| Offset | Name | Access | Reset | Description |\n|---|---|---|---|---|")
    for n, off, acc, rst, d in QCFG:
        m("| +0x%02X | %s | %s | 0x%X | %s |" % (off, n, acc, rst, d))
    m("\n## Tenant table (`0x%04X + t*0x%X`, administrator-writable)\n" % (TEN_BASE, TEN_STRIDE))
    m("| Offset | Name | Description |\n|---|---|---|")
    for n, off, d in TEN:
        m("| +0x%X | %s | %s |" % (off, n, d))
    m("\n## Rule programming\n")
    m("* `0x%04X + r*4` **OWNER[r]** (RW-A, 4 bits): tenant that owns rule slot *r* (0 = administrator).\n"
      "* `0x%04X + 4*k` **STAGE[k]**, k = 0..%d: staging window holding one rule (%d bits, layout below). A write by tenant *T* when `STAGE_OWNER != T` "
      "first clears the whole window and claims it for *T* (so staged words of different tenants can never be mixed).\n"
      "* `0x%04X` **RULE_CMD** (write): `[31:28]` command (1 COMMIT stage->rule, 2 CLEAR rule, 3 READ rule->stage), `[7:0]` rule index.\n"
      "* `0x%04X` **RULE_STATUS** (RO, per accessor): `[3:0]` result of that accessor\'s last command (0 OK, 1 ERR_PERM, 2 ERR_STAGE, 3 ERR_POLICY, 4 ERR_RANGE, 5 ERR_CMD), `[15:8]` command sequence number.\n"
      "* `0x%04X` **STAGE_OWNER** (RO; tenants read 1 if the window is theirs, administrators read the owner id).\n"
      "* `0x%04X` **RULE_SNAP** (W, any tenant): snapshot the per-rule counters.\n"
      "* `0x%04X + r*0x%X` **RULE_CNT[r]**: HITS_LO, HITS_HI, BYTES_LO, BYTES_HI (owner or administrator; read after `CTRL.snap_rules`).\n"
      % (OWNER_BASE, STAGE_BASE, RULE_WORDS - 1, RULE_W, RULE_CMD, RULE_STATUS, STAGE_OWNER, RULE_SNAP, RULE_CNT_BASE, RULE_CNT_STRIDE))
    m("\n### Rule layout (LSB first, %d bits = %d words)\n" % (RULE_W, RULE_WORDS))
    m("| Field | LSB | Width |\n|---|---|---|")
    for n, (p, w) in rule.items():
        m("| %s | %d | %d |" % (n, p, w))
    m("\nMatch semantics: a field matches when `((key ^ value) & mask) == 0`; a rule matches when its `valid` bit is set, every field matches, and (for tenant-owned rules) the packet is inside the tenant scope. "
      "The **lowest-numbered matching rule wins** (TCAM order). A zero mask is a wildcard.\n")
    m("## Counters (administrator, after `CTRL.snap_global`)\n")
    m("Each counter is `cnt_bits` wide (saturating, never wraps), read as LO at `0x%04X + idx*8` and HI at `+4`.\n" % GCNT_BASE)
    m("| Index | Name | Type | Description |\n|---|---|---|---|")
    for i, g in enumerate(GLOBAL_CNT):
        m("| %d | %s | %s | %s |" % (i, g[0], g[1], g[2]))
    m("\nPer-queue counters: index = `%d + q*%d + k`:\n" % (G_STRIDE, Q_STRIDE))
    m("| k | Name | Type | Description |\n|---|---|---|---|")
    for i, q in enumerate(QUEUE_CNT):
        m("| %d | %s | %s | %s |" % (i, q[0], q[1], q[2]))
    m("\n## Reason / error codes\n")
    for grp, items in CODES.items():
        m("* **%s**: " % grp + ", ".join("%s=%d" % (n, v) for n, v in items))
    m("\n## Parser token layout (internal, parser -> classifier, %d bits)\n" % TOK_W)
    m("| Field | LSB | Width |\n|---|---|---|")
    for n, (p, w) in tok.items():
        m("| %s | %d | %d |" % (n, p, w))
    with open(os.path.join(ROOT, "docs", "REGISTERS.md"), "w") as f:
        f.write("\n".join(M) + "\n")
    print("TOK_W=%d DEC_W=%d RULE_W=%d (%d words) NSLOT=%d" % (TOK_W, DEC_W, RULE_W, RULE_WORDS, NSLOT))


if __name__ == "__main__":
    main()
