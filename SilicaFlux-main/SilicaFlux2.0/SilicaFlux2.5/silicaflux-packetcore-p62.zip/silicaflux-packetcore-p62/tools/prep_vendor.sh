#!/usr/bin/env bash
# Build-time copy of the vendored (unmodified) SilicaFlux IP for Verilator.
# The vendored sync_fifo.sv fences a SystemVerilog sequence assertion (##1) with `// synthesis translate_off/on`.
# Verilator 5.020 does not honour that pragma and cannot parse the sequence.  The ONLY change made is to replace
# the two pragma comments by `ifndef VERILATOR / `endif (same fenced region, no logic change); the diff is stored
# next to the copy.  Yosys reads the pristine file directly.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SRC="$ROOT/third_party/silicaflux-reused"
DST="$ROOT/sim/vendor_build"
mkdir -p "$DST"
for f in "$SRC"/*.sv; do
  b="$(basename "$f")"
  sed -e 's#// synthesis translate_off#`ifndef VERILATOR#' -e 's#// synthesis translate_on#`endif#' "$f" > "$DST/$b"
done
( cd "$ROOT" && diff -u third_party/silicaflux-reused/sync_fifo.sv sim/vendor_build/sync_fifo.sv > "$DST/verilator_pragma.diff" || true )
echo "vendor copy ready: $DST ($(grep -c '^[-+][^-+]' "$DST/verilator_pragma.diff") changed lines)"
