#!/usr/bin/env bash
# Verilator -Wall lint (only the unused-signal / unused-parameter style warnings are waived: generated field
# tables and carried-but-unused token fields) + Yosys elaboration with latch / combinational-loop checks.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
V="sim/vendor_build/sync_fifo.sv sim/vendor_build/sfb_skid_buffer.sv sim/vendor_build/sf_rr_arb.sv"
M="rtl/sf_pkt_toeplitz.sv rtl/sf_pkt_parser.sv rtl/sf_pkt_classifier.sv rtl/sf_pkt_counters.sv rtl/sf_pkt_queue.sv rtl/sf_pkt_fifo.sv rtl/sf_pkt_dispatch.sv rtl/sf_pkt_sched.sv rtl/sf_pkt_regs.sv rtl/silicaflux_packet_engine.sv rtl/sf_pkt_mac_adapter.sv"
mkdir -p reports
echo "== Verilator lint (engine)"; verilator --lint-only -Wall -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-PINCONNECTEMPTY -Irtl $V $M --top-module silicaflux_packet_engine 2>&1 | tee reports/lint_engine.log | grep -E "^%(Error|Warning)" && { echo "LINT FAIL"; exit 1; } || echo "engine: clean"
echo "== Verilator lint (MAC adapter)"; verilator --lint-only -Wall -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-PINCONNECTEMPTY -Irtl $V $M --top-module sf_pkt_mac_adapter 2>&1 | tee reports/lint_mac.log | grep -E "^%(Error|Warning)" && { echo "LINT FAIL"; exit 1; } || echo "mac adapter: clean"
echo "== Verilator lint (configurations)"
for cfg in "-GDW=64" "-GDW=256" "-GDW=512" "-GNUM_QUEUES=16 -GNUM_RULES=64 -GNUM_TENANTS=16" "-GNUM_QUEUES=1 -GNUM_RULES=1 -GNUM_TENANTS=1" "-GENABLE_RSS=0 -GENABLE_VXLAN=0 -GENABLE_REWRITE=0 -GENABLE_TENANT=0 -GENABLE_PERF=0" "-GFIFO_RAM=0" "-GRSS_PROG_KEY=0 -GENABLE_RULE_READ=0"; do
  verilator --lint-only -Wall -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM -Wno-DECLFILENAME -Wno-PINCONNECTEMPTY -Irtl $V $M --top-module silicaflux_packet_engine $cfg 2>&1 | grep -E "^%(Error|Warning)" && { echo "LINT FAIL ($cfg)"; exit 1; } || echo "  $cfg: clean"
done
echo "== Yosys elaboration + check (latches, loops, multiple drivers)"
yosys -q -l reports/yosys_check.log -p "read_verilog -sv -Irtl third_party/silicaflux-reused/sync_fifo.sv third_party/silicaflux-reused/sfb_skid_buffer.sv third_party/silicaflux-reused/sf_rr_arb.sv $M; hierarchy -check -top silicaflux_packet_engine; proc; opt -fast; check -assert" >/dev/null 2>&1 && echo "yosys: OK (check -assert passed)" || { echo "YOSYS CHECK FAIL"; exit 1; }
