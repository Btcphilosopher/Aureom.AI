#!/usr/bin/env bash
set -uo pipefail; ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"; mkdir -p reports; rc=0
: > reports/system_sweep.log
for dw in 64 256 512; do
  python3 model/run_system_tests.py --dw $dw --metrics reports/system_metrics_dw$dw.json > reports/system_regression_dw$dw.log 2>&1 || rc=1
  tail -1 reports/system_regression_dw$dw.log | tee -a reports/system_sweep.log
done
i=1
for v in "--nq 8 --nr 32 --nt 16 --srcw 8 --pktdepth 32" "--nq 2 --nr 8 --nt 4 --maxf 1522 --qbytes 4096 --pktdepth 16" "--nq 16 --nr 64 --nt 16 --dw 64" "--nq 1 --nr 4 --nt 2 --dw 512 --maxf 2048 --qbytes 8192"; do
  python3 model/run_system_tests.py $v > reports/system_regression_variant$i.log 2>&1 || rc=1
  tail -1 reports/system_regression_variant$i.log | tee -a reports/system_sweep.log; i=$((i+1))
done; exit $rc
