#!/usr/bin/env bash
set -uo pipefail; ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"; mkdir -p reports
: > reports/parser_width_sweep.log; rc=0
for cfg in "128 128 4 2" "64 128 4 2" "256 128 4 2" "512 128 4 2" "128 128 2 2" "128 128 6 2" "128 128 4 1" "64 192 4 2"; do
  set -- $cfg; echo "=== DW=$1 HDR_CAP=$2 MAX_EXT=$3 EXT_STEP=$4" | tee -a reports/parser_width_sweep.log
  python3 model/run_parser_tests.py --dw $1 --hdr-cap $2 --max-ext $3 --ext-step $4 --nrandom 2000 --seed 7 --work sim/parser_sweep_$1_$2_$3_$4 2>&1 | tail -1 | tee -a reports/parser_width_sweep.log
  [ "${PIPESTATUS[0]}" -eq 0 ] || rc=1
done; exit $rc
