#!/usr/bin/env bash
# Build the deliverable zip (no git involved).  Usage: tools/package.sh <output.zip>
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:?usage: tools/package.sh <output.zip>}"
NAME=silicaflux-packetcore-p62
STAGE="$(mktemp -d)"; trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/$NAME"
( cd "$ROOT" && tar cf - --exclude='./sim' --exclude='__pycache__' --exclude='*.pyc' --exclude='./.git' . ) | ( cd "$STAGE/$NAME" && tar xf - )
mkdir -p "$STAGE/$NAME/sim"; printf 'build products go here (make vendor / make regress)\n' > "$STAGE/$NAME/sim/README.txt"
# large logs: keep them, compressed
find "$STAGE/$NAME/reports" -type f -name '*.log' -size +2M -exec gzip -9 {} \;
( cd "$STAGE" && rm -f "$OUT" && zip -r -q -9 "$OUT" "$NAME" )
echo "wrote $OUT ($(du -h "$OUT" | cut -f1)); $(unzip -l "$OUT" | tail -1)"
