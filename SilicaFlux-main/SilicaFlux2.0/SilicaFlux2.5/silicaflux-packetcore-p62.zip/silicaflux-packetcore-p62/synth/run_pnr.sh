#!/usr/bin/env bash
# Usage: synth/run_pnr.sh <tag> "<pnr_top chparams>" <target MHz>
# synth_ecp5 (flat) of the harness + engine, then nextpnr-ecp5 on LFE5U-85F-6 / CABGA381.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
TAG="$1"; PARAMS="${2:-}"; FREQ="${3:-100}"
CH=""; for kv in $PARAMS; do CH="$CH -chparam ${kv%%=*} ${kv#*=}"; done
FILES="third_party/silicaflux-reused/sync_fifo.sv third_party/silicaflux-reused/sfb_skid_buffer.sv third_party/silicaflux-reused/sf_rr_arb.sv rtl/sf_pkt_toeplitz.sv rtl/sf_pkt_parser.sv rtl/sf_pkt_classifier.sv rtl/sf_pkt_counters.sv rtl/sf_pkt_queue.sv rtl/sf_pkt_fifo.sv rtl/sf_pkt_dispatch.sv rtl/sf_pkt_sched.sv rtl/sf_pkt_regs.sv rtl/silicaflux_packet_engine.sv synth/pnr_top.sv"
mkdir -p reports sim/synth
J=sim/synth/pnr_${TAG}.json
yosys -l reports/pnr_${TAG}.synth.log -p "read_verilog -sv -Irtl $FILES; hierarchy -check -top pnr_top $CH; synth_ecp5 -top pnr_top -json $J; tee -o reports/pnr_${TAG}.stat stat" >/dev/null 2>&1 || { echo "$TAG: SYNTH FAILED"; exit 1; }
# the heap placer occasionally fails legalisation on a given seed (control-set packing); retry with other seeds
for SEED in 7 3 11 5; do
  nextpnr-ecp5 --85k --package CABGA381 --speed 6 --json $J --freq $FREQ --seed $SEED --timing-allow-fail --placer heap > reports/pnr_${TAG}.pnr.log 2>&1
  grep -q "Max frequency for clock" reports/pnr_${TAG}.pnr.log && break
  echo "seed $SEED failed to place; retrying" >> reports/pnr_${TAG}.retries
done
python3 tools/pnr_summary.py reports/pnr_${TAG}.pnr.log $SEED | tee reports/pnr_${TAG}.summary
