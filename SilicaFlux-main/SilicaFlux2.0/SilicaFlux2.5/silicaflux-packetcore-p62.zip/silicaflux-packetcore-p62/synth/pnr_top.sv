// =============================================================================
// Place-and-route characterisation harness (NOT part of the product).
// An FPGA flow needs every top-level port on a pin; the engine has ~600 wide stream ports.  This wrapper
// drives the engine from a free-running 1024-bit LFSR (registered), reduces every engine output into one
// registered XOR signature, so the only top-level ports are clk, rst_n and `sig`.  Timing paths inside the
// engine are therefore real; the wrapper's own paths are short, registered and not critical.
// Stimulus is pseudo-random (so the engine toggles), not meaningful traffic.
// =============================================================================
`default_nettype none
module pnr_top #(
  parameter int DW = 128, parameter int NQ = 4, parameter int NR = 16, parameter int NT = 8,
  parameter int MAXF = 9216, parameter int QB = 16384, parameter int HDR = 128, parameter int MAXE = 4,
  parameter int EXTS = 2, parameter bit PERF = 1'b1, parameter bit RSSK = 1'b1, parameter bit RDRULE = 1'b1, parameter bit TEN = 1'b1,
  parameter bit RSS = 1'b1, parameter bit VXL = 1'b1, parameter bit RWR = 1'b1
) (
  input  wire logic clk,
  input  wire logic rst_n,
  output logic      sig
);
  localparam int DWB = DW / 8;
  reg [1023:0] rnd;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) rnd <= 1024'h5A5A_1234_DEAD_BEEF_0123_4567_89AB_CDEF;
    else        rnd <= {rnd[1022:0], rnd[1023] ^ rnd[1021] ^ rnd[1010] ^ rnd[1000]};
  end
  reg s_valid, s_last, s_err, m_ready, x_ready, rb_req, rb_we;
  reg [DW-1:0] s_data;
  reg [3:0] s_src; reg [15:0] s_meta; reg [15:0] rb_addr; reg [31:0] rb_wdata; reg [3:0] rb_tenant;
  always_ff @(posedge clk) begin
    s_valid <= rnd[3] | rnd[7]; s_last <= rnd[11] & rnd[12] & rnd[13]; s_err <= rnd[20] & rnd[21] & rnd[22] & rnd[23];
    m_ready <= rnd[30] | rnd[31]; x_ready <= rnd[33] | rnd[34];
    rb_req <= rnd[40] & rnd[41] & rnd[42]; rb_we <= rnd[43]; rb_addr <= rnd[63:48]; rb_wdata <= rnd[127:96]; rb_tenant <= rnd[131:128] & 4'h3;
    s_data <= rnd[1023 -: DW]; s_src <= rnd[140:137]; s_meta <= rnd[160:145];
  end
  wire s_ready, m_valid, m_last, m_err, x_valid, x_last, rb_rvalid, rb_err, idle;
  wire [DW-1:0] m_data, x_data; wire [DWB-1:0] m_keep, x_keep;
  wire [3:0] m_queue, x_reason; wire [2:0] m_tc, x_tc; wire [3:0] m_src, x_src; wire [15:0] m_meta, x_meta;
  wire [31:0] m_hash, x_hash, rb_rdata; wire [15:0] m_len, x_len;
  silicaflux_packet_engine #(.DW(DW), .SRC_W(4), .META_W(16), .NUM_QUEUES(NQ), .NUM_RULES(NR), .NUM_TENANTS(NT),
      .MAX_FRAME_BYTES(MAXF), .QUEUE_BYTES(QB), .MGMT_BYTES(QB), .HDR_CAP_BYTES(HDR), .MAX_EXT(MAXE), .EXT_STEP(EXTS),
      .ENABLE_PERF(PERF), .RSS_PROG_KEY(RSSK), .ENABLE_RULE_READ(RDRULE), .ENABLE_TENANT(TEN), .ENABLE_RSS(RSS), .ENABLE_VXLAN(VXL), .ENABLE_REWRITE(RWR)) u_eng (
    .clk(clk), .rst_n(rst_n),
    .s_valid(s_valid), .s_ready(s_ready), .s_data(s_data), .s_keep({DWB{1'b1}}), .s_last(s_last), .s_err(s_err), .s_src(s_src), .s_meta(s_meta),
    .m_valid(m_valid), .m_ready(m_ready), .m_data(m_data), .m_keep(m_keep), .m_last(m_last), .m_err(m_err),
    .m_queue(m_queue), .m_tc(m_tc), .m_src(m_src), .m_meta(m_meta), .m_hash(m_hash), .m_len(m_len),
    .x_valid(x_valid), .x_ready(x_ready), .x_data(x_data), .x_keep(x_keep), .x_last(x_last), .x_reason(x_reason), .x_tc(x_tc),
    .x_src(x_src), .x_meta(x_meta), .x_hash(x_hash), .x_len(x_len),
    .rb_req(rb_req), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_tenant(rb_tenant),
    .rb_rvalid(rb_rvalid), .rb_rdata(rb_rdata), .rb_err(rb_err), .idle(idle));
  localparam int OW = 2 * DW + 2 * DWB + 2*(4+3+4+16+32+16) + 32 + 8;
  wire [OW-1:0] ov = {m_data, x_data, m_keep, x_keep, m_queue, x_reason, m_tc, x_tc, m_src, x_src, m_meta, x_meta, m_hash, x_hash,
                      m_len, x_len, rb_rdata, m_valid, m_last, m_err, x_valid, x_last, rb_rvalid, rb_err, idle, s_ready};
  reg [OW-1:0] ovr;
  reg [63:0]   fold;
  always_ff @(posedge clk) begin
    ovr <= ov;
    for (int i = 0; i < 64; i++) begin
      fold[i] <= 1'b0;
      for (int j = i; j < OW; j = j + 64) fold[i] <= fold[i] ^ ovr[j];
    end
    sig <= ^fold;
  end
endmodule
