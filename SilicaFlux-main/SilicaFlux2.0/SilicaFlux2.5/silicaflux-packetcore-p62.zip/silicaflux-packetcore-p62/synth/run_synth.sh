#!/usr/bin/env bash
# Usage: synth/run_synth.sh <tag> "<chparam list>"   e.g.  synth/run_synth.sh ref "DW=128 NUM_RULES=16"
# Produces reports/synth_<tag>_{generic,ecp5}.{log,stat} and (flat) a JSON netlist for nextpnr.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TAG="$1"; PARAMS="${2:-}"
cd "$ROOT"
CH=""
for kv in $PARAMS; do CH="$CH -chparam ${kv%%=*} ${kv#*=}"; done
FILES="third_party/silicaflux-reused/sync_fifo.sv third_party/silicaflux-reused/sfb_skid_buffer.sv third_party/silicaflux-reused/sf_rr_arb.sv rtl/sf_pkt_toeplitz.sv rtl/sf_pkt_parser.sv rtl/sf_pkt_classifier.sv rtl/sf_pkt_counters.sv rtl/sf_pkt_queue.sv rtl/sf_pkt_fifo.sv rtl/sf_pkt_dispatch.sv rtl/sf_pkt_sched.sv rtl/sf_pkt_regs.sv rtl/silicaflux_packet_engine.sv"
mkdir -p reports sim/synth
# (1) hierarchical ECP5 mapping: per-module resource table
yosys -l reports/synth_${TAG}_hier.log -p "read_verilog -sv -Irtl $FILES; hierarchy -check -top silicaflux_packet_engine $CH; synth_ecp5 -noflatten -top silicaflux_packet_engine; tee -o reports/synth_${TAG}_hier.stat stat -top silicaflux_packet_engine" > /dev/null 2>&1
echo "hier done $TAG"
# (2) flat ECP5 mapping for place-and-route
yosys -l reports/synth_${TAG}_flat.log -p "read_verilog -sv -Irtl $FILES; hierarchy -check -top silicaflux_packet_engine $CH; synth_ecp5 -top silicaflux_packet_engine -json sim/synth/${TAG}.json; tee -o reports/synth_${TAG}_flat.stat stat" > /dev/null 2>&1
echo "flat done $TAG"
