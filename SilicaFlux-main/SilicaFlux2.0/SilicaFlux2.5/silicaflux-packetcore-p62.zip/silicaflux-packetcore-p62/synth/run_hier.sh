#!/usr/bin/env bash
# Usage: synth/run_hier.sh <tag> "<chparam list>"
# Hierarchical Yosys synth_ecp5 of the whole engine -> per-module LUT4 / FF / EBR / DPR table (reports/hier_<tag>.stat).
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
TAG="$1"; PARAMS="${2:-}"
CH=""; for kv in $PARAMS; do CH="$CH -chparam ${kv%%=*} ${kv#*=}"; done
FILES="third_party/silicaflux-reused/sync_fifo.sv third_party/silicaflux-reused/sfb_skid_buffer.sv third_party/silicaflux-reused/sf_rr_arb.sv rtl/sf_pkt_toeplitz.sv rtl/sf_pkt_parser.sv rtl/sf_pkt_classifier.sv rtl/sf_pkt_counters.sv rtl/sf_pkt_queue.sv rtl/sf_pkt_fifo.sv rtl/sf_pkt_dispatch.sv rtl/sf_pkt_sched.sv rtl/sf_pkt_regs.sv rtl/silicaflux_packet_engine.sv"
mkdir -p reports
yosys -l reports/hier_${TAG}.log -p "read_verilog -sv -Irtl $FILES; hierarchy -check -top silicaflux_packet_engine $CH; synth_ecp5 -noflatten -top silicaflux_packet_engine; tee -o reports/hier_${TAG}.stat stat -top silicaflux_packet_engine" >/dev/null 2>&1 && echo "hier $TAG done" || echo "hier $TAG FAILED"
