#!/usr/bin/env bash
# Usage: synth/run_block.sh <top-module> <tag> "<chparam list>" <target-MHz>
# Yosys synth_ecp5 (flat) resource count for one block; optional nextpnr-ecp5 (PNR=1) on an ECP5 LFE5U-85F (speed grade 6, CABGA381).
# Reports: reports/block_<tag>.{synth,pnr}.log and reports/block_<tag>.txt (one-line summary).
# No board / bitstream is produced; the clock constraint is a single `clk` at the target frequency.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
TOP="$1"; TAG="$2"; PARAMS="${3:-}"; FREQ="${4:-100}"
CH=""; for kv in $PARAMS; do CH="$CH -chparam ${kv%%=*} ${kv#*=}"; done
FILES="third_party/silicaflux-reused/sync_fifo.sv third_party/silicaflux-reused/sfb_skid_buffer.sv third_party/silicaflux-reused/sf_rr_arb.sv rtl/sf_pkt_toeplitz.sv rtl/sf_pkt_parser.sv rtl/sf_pkt_classifier.sv rtl/sf_pkt_counters.sv rtl/sf_pkt_queue.sv rtl/sf_pkt_fifo.sv rtl/sf_pkt_dispatch.sv rtl/sf_pkt_sched.sv rtl/sf_pkt_regs.sv rtl/silicaflux_packet_engine.sv rtl/sf_pkt_mac_adapter.sv"
mkdir -p reports sim/synth
J=sim/synth/block_${TAG}.json
yosys -l reports/block_${TAG}.synth.log -p "read_verilog -sv -Irtl $FILES; hierarchy -check -top $TOP $CH; synth_ecp5 -top $TOP -json $J; tee -o reports/block_${TAG}.stat stat" >/dev/null 2>&1 || { echo "$TAG: SYNTH FAILED" | tee reports/block_${TAG}.txt; exit 1; }
LUT=$(grep -E "^\s+LUT4\s" reports/block_${TAG}.stat | tail -1 | awk '{print $2}')
FF=$(grep -E "TRELLIS_FF" reports/block_${TAG}.stat | tail -1 | awk '{print $2}')
EBR=$(grep -E "DP16KD|PDPW16KD" reports/block_${TAG}.stat | awk '{s+=$2} END{print s+0}')
DPR=$(grep -E "TRELLIS_DPR16X4" reports/block_${TAG}.stat | tail -1 | awk '{print $2}')
# Place-and-route is optional (PNR=1): a bare block has far more pins than the package has user I/O, so the
# per-block run reports resources only; the harness-wrapped reference builds (synth/run_pnr.sh) are the ones placed.
FMAX=""
if [ "${PNR:-0}" = "1" ]; then
  nextpnr-ecp5 --85k --package CABGA381 --speed 6 --json $J --freq $FREQ --seed 1 --timing-allow-fail > reports/block_${TAG}.pnr.log 2>&1
  FMAX=$(grep -E "Max frequency for clock" reports/block_${TAG}.pnr.log | tail -1 | sed -E 's/.*: ([0-9.]+) MHz.*/\1/')
fi
echo "$TAG top=$TOP params=[$PARAMS] LUT4=${LUT:-0} FF=${FF:-0} EBR=${EBR:-0} DPR16X4=${DPR:-0} Fmax_MHz=${FMAX:-n/a} (target ${FREQ})" | tee reports/block_${TAG}.txt
