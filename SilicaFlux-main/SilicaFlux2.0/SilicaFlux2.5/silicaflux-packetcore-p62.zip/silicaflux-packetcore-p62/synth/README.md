# Synthesis and place-and-route scripts

Tools: Yosys 0.33 (`synth_ecp5`), nextpnr-ecp5 0.6, target Lattice ECP5 LFE5U-85F, speed grade 6, CABGA381. Results land in `../reports/`; `../tools/make_summary.py` folds them into `reports/SUMMARY.md` and the
generated tables of `docs/PERFORMANCE.md` and `docs/FPGA.md`. **No vendor tool, board or bitstream is involved.**

| Script | What it does |
|---|---|
| `run_hier.sh <tag> "<chparams>"` | hierarchical (`-noflatten`) `synth_ecp5` of the engine -> `reports/hier_<tag>.stat` (per-module LUT4 / FF / EBR / DPR16X4) |
| `run_block.sh <top> <tag> "<chparams>" <MHz>` | flat resource count of one block -> `reports/block_<tag>.txt` (`PNR=1` also runs nextpnr; a bare block exceeds the package's I/O so this normally reports resources only) |
| `run_pnr.sh <tag> "<pnr_top chparams>" <MHz>` | flat synthesis of `pnr_top.sv` (engine + LFSR/XOR-signature harness, only `clk`, `rst_n`, `sig` on pins) and nextpnr-ecp5 (`--placer heap`, seeds 7/3/11/5 tried in turn because the placer sometimes fails legalisation) -> `reports/pnr_<tag>.{pnr.log,summary}` |
| `run_synth.sh <tag> "<chparams>"` | engine-only hierarchical + flat Yosys mapping (resource counts, JSON netlist) |
| `pnr_top.sv` | harness; **not part of the product** -- stimulus is pseudo-random, paths inside the engine are real |

`make synth` runs the two hierarchy tables and the two reference place-and-route builds used in `docs/FPGA.md`. Expect roughly one to two hours on a 4-core machine (nextpnr routing dominates).
Reported frequency is the post-route `Max frequency` line of nextpnr, not a vendor sign-off number; the achieved results to date **fail** the 50 MHz target (see `docs/FPGA.md`).
