# Classifier: exact lookup semantics

## Match

A rule matches a frame iff **all** of:
1. `valid` is set and the rule is *effective* (administrator-owned, or tenant-owned with its tenant enabled and its action still inside that
   tenant's policy -- re-evaluated every cycle);
2. for **every** match field, `((key ^ value) & mask) == 0` (a zero mask is a wildcard);
3. for a tenant-owned rule, the frame is inside the tenant scope: outer VLAN id == scope VID, **or** VXLAN VNI == scope VNI.

The **lowest-numbered matching rule wins** (TCAM order). Keys (from the parser token): `src_id` (ingress `s_src`, zero-extended to 8 bits), `frag`,
`vlan_valid`, `vid` (outer tag), `pcp`, `ethertype` (after tags), `dmac`, `l3_type`, `ip_proto` (final protocol after IPv6 extension headers),
`dscp` (= IPv4 TOS / IPv6 traffic class >> 2), `sip`/`dip` (128 bit; IPv4 occupies the low 32 bits), `sport`, `dport`, `tcp_flags`, `vni_valid`, `vni`.

## Decision order

1. **Error overrides** (the lookup does not run): parser error -> `malformed_act`; unsupported chain -> `unsupp_act`; fragment -> `frag_act`
   (see `PARSER_POLICY.md`).
2. No match -> `POL_DEF.verdict`; match -> the rule's verdict (FORWARD, DROP, MGMT/punt; the reserved encoding fails closed to DROP).
3. **Traffic class**: `rule.set_tc ? rule.tc : base_tc`; `base_tc` follows `POL_TC.tc_src` (0: `POL_DEF.tc`, 1: VLAN PCP, 2: IP DSCP[5:3]).
4. **Queue** (FORWARD only): `rule.set_queue` -> `rule.qid`; else `rule.qsel_hash` -> `rule.qid + (flow_hash & (2^hash_bits - 1))`;
   else (no match) `POL_DEF.set_q ? def_qid : TC_QMAP[tc]`; queues >= `NUM_QUEUES` fall back to queue 0. MGMT goes to the management port.
5. **Count**: `rule.count` increments that rule's hit/byte counters (counted at the last beat for every frame the rule selected, whatever its final
   fate; bytes are the received length).
6. **Rewrite** (optional, FORWARD only, IPv6 or IPv4 with a verified header checksum): `set_dscp` rewrites DSCP (ECN preserved); `dec_ttl`
   decrements TTL / hop-limit; IPv4 checksum is updated per **RFC 1624 eq. 3** for each changed 16-bit word (every rewritten header is re-verified
   independently by the scoreboard). `dec_ttl` with TTL <= 1 **punts** the unmodified frame to management (reason `TTL`). No other byte of
   a frame is ever modified; VLAN push/pop, NAT and L4 checksum rewriting are not implemented.
7. **Late drops** (at the last beat, priority order): MAC error > illegal keep > oversize > runt > classifier DROP reason > declared-length mismatch >
   queue full.

## Atomic updates

A rule commit writes the match table in one cycle and the action table (a copy) one cycle later, exactly the classifier's match-to-action
distance, so a frame never sees the old match with the new action (verified with 90 commits under line-rate traffic). Global policy registers
are **not** packet-atomic: quiesce (`CTRL.enable = 0`, wait for `STATUS.idle`) before changing them if that matters.

## Queueing semantics

Each egress queue is a speculative-write, commit/abort packet FIFO. Lossless mode (`POL_ERR.qdrop = 0`, default): a full queue back-pressures
the whole ingress (**head-of-line blocking** across queues is inherent to a single ingress stream); deadlock-freedom is guaranteed because
`QUEUE_BYTES` must exceed `MAX_FRAME_BYTES`. Tail-drop mode (`qdrop = 1`): a frame that does not fit is dropped whole and counted per queue
(`drop_qfull`). The management queue is always tail-drop.
