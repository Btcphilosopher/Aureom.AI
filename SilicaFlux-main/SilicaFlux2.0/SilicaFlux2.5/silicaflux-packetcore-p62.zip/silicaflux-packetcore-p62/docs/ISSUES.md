# Known limitations and open items

Stated plainly so nobody has to discover them. "Verified" in this project means: simulated in Verilator against an independent software model,
linted, elaborated and synthesised with Yosys. It does **not** mean silicon- or board-proven.

## Not done / not verified

| Item | Status |
|---|---|
| **Real MAC / PHY** | No Ethernet MAC exists in the SilicaFlux repo and none was written. `sf_pkt_mac_adapter` was exercised only against a behavioural AXI-S MAC model written for this project. No 100/200/400 GbE SerDes/PCS is provided or claimed. |
| **FPGA timing of the full engine** | Place-and-route was run only on a reduced reference configuration and only on the open ECP5 flow (nextpnr). **It did not meet its 50 MHz target: 20.56 MHz (default parser shape) and 27.78 MHz (one extension header per stage)**; the limiting paths are long single-cycle combinational chains (IPv6 extension-header walk; scheduler <-> queue head read), with routing delay about 4x logic delay. The full default configuration (105.7 k LUT4) does not fit an ECP5-85F at all. No Vivado / Quartus / Libero run. See `FPGA.md`; throughput in Gbit/s is *analytical* unless stated. |
| **Formal verification** | None. Properties are checked by simulation (protocol monitors, FIFO overflow flags, model comparison, mutation testing of the parser). |
| **Gate-level / post-route simulation, CDC, power, DFT, ASIC flow** | Not done. |
| **Other simulators** | The regression is Verilator 5.020. Icarus 12 elaborates the RTL (with "constant selects in always_*" warnings) but the testbenches were not run there. |
| **L4 checksum verification / generation** | Not implemented (TCP/UDP checksums need the full payload; rewrites never touch fields they cover). |
| **FCS** | The engine neither generates nor checks it (MAC's job); frames exclude FCS. |
| **VLAN push/pop, NAT, VXLAN encap/decap, inner-frame parsing, ECN marking, PFC/pause** | Not implemented. VXLAN is parse-only (VNI metadata from the outer headers). |
| **Clock-domain crossing** | None inside the engine; the MAC adapter requires MAC clock == engine clock. |

## Design limits (by construction)

* **Parser window** is 128 bytes by default (`HDR_CAP_BYTES`, 128..255); IPv6 chains with more than `MAX_EXT` (4) extension headers, or that run past the window, are
  reported `unsupp` and handled by policy (punt by default), not parsed.
* **Head-of-line blocking** in lossless mode: one full queue stalls the single ingress stream. Use tail-drop (`POL_ERR.qdrop`) or per-queue rate limits where that matters.
  The management queue is always tail-drop.
* **Store-and-forward at the queue**: latency of a frame grows with its length (measured: 21 cycles for 60 B up to 584 cycles for 9000 B SOP-to-SOP at DW = 128).
* **Policy registers are not packet-atomic** (rule commits are). Quiesce with `CTRL.enable` for a consistent global change.
* **Tenant identity is trusted, not authenticated** (`rb_tenant` comes from the interconnect). No timing/buffer side-channel protection.
* **Scheduler**: selection is up to two frames ahead of the egress (bounded priority inversion), and DWRR uses round replenishment (see `SCHEDULER.md`).
* **Byte counters for frames that violate the `keep` contract are best-effort** (such frames are always dropped as KEEP; the parse statistics are exact against the model).
* **Statistics** are 40-bit saturating (configurable `CW`); latency counters measure SOP-to-dispatch and SOP-to-egress in clocks.
* `m_err` is tied 0: bad frames are never forwarded (no "forward with error" mode).
* **Reset** is asynchronous-assert; an egress frame in progress at reset is cut without `last` (system reset required).

## Area

The engine is large for an FPGA because it is a fully pipelined (II = 1) parser with dynamic offsets into a 1024-bit window, a flip-flop based TCAM-style rule table, a
programmable-key Toeplitz hash and ~100 saturating counters. Per-block numbers are in `PERFORMANCE.md`; the build options that shrink it are `NUM_RULES`, `HDR_CAP_BYTES`,
`MAX_EXT`, `RSS_PROG_KEY = 0`, `ENABLE_RULE_READ = 0`, `ENABLE_PERF = 0`, `CW`, `NUM_QUEUES`. A BRAM/CAM based rule store and a counter RAM are the obvious next
steps for a smaller footprint.

## Tooling notes

* Yosys 0.33's front-end cannot read packages, enums or struct casts, so the RTL is flat-vector SystemVerilog with generated field tables (`tools/gen_defs.py`).
* The vendored `sync_fifo.sv` is used unmodified; its `synthesis translate_off` assertion block is skipped for Verilator by a build-time copy (`tools/prep_vendor.sh`, diff stored in
  `sim/vendor_build/verilator_pragma.diff`). Its memory is an asynchronous-read array: it maps to LUT RAM / registers, not block RAM (the delay FIFO is 64 beats x 150 bit).
* Two bugs found by the verification (not by inspection) are worth remembering: a 10-bit overflow in the IPv6 extension-header length arithmetic (found by random mutation of packets
  against the model) and a 4-bit truncation of `NUM_QUEUES = 16` in the dispatcher (found by the parameter-variant regression). Both are fixed and covered by directed tests.
