# PacketCore architecture

PacketCore is a synthesizable, programmable data-plane engine for the SilicaFlux CloudDPU: it receives frames on a streaming interface, parses
Ethernet/VLAN/IPv4/IPv6/TCP/UDP (+VXLAN metadata), classifies them with a match/action table, steers them into egress queues, schedules the queues,
and transmits valid frame streams. A management (punt) port, a versioned register interface with tenant isolation and a statistics block are included.

```
 s_* ─► [skid slice] ──acc──┬─► Parser: header-window capture ─► 7-stage II=1 pipeline ─► token ─► Classifier (3 stages) ─► Decision FIFO ─┐
 (frames)                   ├─► Delay FIFO  (every beat, until its decision exists) ────────────────────────────────────────────────────┤
                            └─► Sideband FIFO {timestamp, meta, src} (1 entry / frame) ───────────────────────────────────────────────────┤
                                                                                                                                         ▼
                                  Dispatcher: beat steering, header patching, late checks, COMMIT / ABORT per frame
                                     │ speculative write                                                      │ (punts, always tail-drop)
                          ┌──────────┴───────────┐                                                            ▼
                       Q0 … QN-1   (commit/abort packet FIFOs)                                          Management queue ─► x_*
                          │  FWFT heads
                          ▼
                 Scheduler: RR | SP + aging | DWRR, token buckets, 2-deep reservation ─► m_*
 rb_* ─► Register file (policy · queues · tenant table · rule table + delayed action copy · staging window) ─► every block
         Statistics block (saturating counters, atomic snapshot)
```

## Data flow and flow control

1. **Ingress slice** (`sfb_skid_buffer`, reused): registers `s_ready`/`s_data`. Admission control keeps at most `DEC_DEPTH` frames between ingress and dispatch
   (`admit_cnt`), which is what lets the parse and classify pipelines run **without back-pressure** and the decision/sideband FIFOs never overflow
   (the testbench asserts the vendored FIFO overflow/underflow flags every cycle). `CTRL.enable = 0` stops admitting new frames (quiesce).
2. **Parser** captures the first 128 bytes (`HDR_CAP_BYTES`) into a window while the beats continue into the **delay FIFO**. The token appears 7 cycles after the beat that
   completes the window; the classifier adds 3.
3. **Dispatcher** consumes one decision + one sideband record per frame and streams the frame's beats out of the delay FIFO into the chosen queue **speculatively**:
   the write pointer advances but the frame stays invisible until the last beat, where it is **committed** (descriptor pushed) or **aborted** (pointer rewound).
   This is cut-through *into* the queue, store-and-forward *out of* it: a frame is never emitted before it is complete, so a late failure (MAC error, illegal `keep`,
   runt, oversize, declared-length mismatch) costs nothing downstream. Rewrites are applied to the beats in flight (byte patches carried in the decision).
4. **Queues** (`sf_pkt_queue`): simple dual-port RAM with synchronous read (maps to block RAM: 9 EBR per 16 KB queue at DW = 128), prefetched FWFT head, descriptor FIFO
   with head/head+1/head+2 visible to the scheduler. Lossless mode back-pressures the ingress when a queue is full; tail-drop mode drops whole frames.
5. **Scheduler** picks frames, never beats (see `SCHEDULER.md`). **Throughput is one beat per cycle** (`DW` bits/clock), including back-to-back minimum frames at every width.

## Why these decisions

* **Early decision, late validation.** The destination is decided from the first 128 bytes so the data can move into its queue immediately; the checks that need the whole
  frame run at the last beat and use commit/abort. A single small delay FIFO (64 beats default) replaces a per-ingress frame buffer, so each frame byte is stored once.
* **Parser as a feed-forward pipeline** (II = 1) so one frame per cycle can be parsed even at 512-bit width where a minimum frame is one beat. The price is area: dynamic
  offsets into a 1024-bit window (see `PERFORMANCE.md` for the measured cost); the window, IPv6 extension depth and rule count are build parameters.
* **Flat-vector SystemVerilog, no packages / structs / enums.** The SilicaFlux synthesis flows use Yosys 0.33, whose front-end cannot read packages, enums or struct casts. All
  field layouts (token, decision, rule, registers, counter indices) come from one generated table (`tools/gen_defs.py` -> `rtl/sf_pkt_defs.svh`, `model/sfdefs.py`,
  `docs/REGISTERS.md`) so RTL, reference model and documentation cannot drift apart.
* **No clock-domain crossing inside the engine.** One clock (`clk`) and one asynchronous-assert, active-low reset (`rst_n`), as everywhere in SilicaFlux. The MAC clock must equal
  `clk` or be converted outside.

## Reused SilicaFlux IP (vendored unmodified, SHA-256 in `third_party/silicaflux-reused/SHA256SUMS`)

| IP | From | Used for |
|---|---|---|
| `sync_fifo` | `memory_cache_repo` | delay / decision / sideband FIFOs when `FIFO_RAM = 0` (asynchronous-read memory: registers on an FPGA, so the default `FIFO_RAM = 1` uses the block-RAM `sf_pkt_fifo` instead; both are regression-tested) |
| `sfb_skid_buffer` | DataFabric | ingress slice, MAC adapter TX slice |
| `sf_rr_arb` | P40 | scheduler arbitration |
| `sf_reset_sync` | P40 | recommended reset bridge (not instantiated inside the engine) |
| counter pattern | DataFabric `sfb_perf_counters` | snapshot / clear / saturate semantics (re-implemented: different counter set) |

Audited and **not reusable** (nothing matching exists in the repository): Ethernet MAC / PCS / PHY, AXI-Stream infrastructure, IPv4 one's-complement checksum, Toeplitz/RSS.
`sfsec_crc` (CRC-32 IEEE 802.3) exists but is not needed: this engine neither generates nor checks the FCS.

## Parameters (top level)

`DW` (64/128/256/512 verified), `SRC_W` (<= 8), `META_W`, `NUM_QUEUES` (1..16), `NUM_RULES` (1..64), `NUM_TENANTS` (1..16), `MAX_FRAME_BYTES` (<= 65535), `QUEUE_BYTES`/`MGMT_BYTES` (power-of-two
beats, > `MAX_FRAME_BYTES`), `PKT_DEPTH`, `HDR_CAP_BYTES` (128..255), `MAX_EXT`/`EXT_STEP`, `DELAY_BEATS`, `DEC_DEPTH`, `CW` (counter bits) and feature switches
`ENABLE_RSS/VXLAN/REWRITE/TENANT/PERF`, and area options `RSS_PROG_KEY` (0 = fixed Microsoft key), `ENABLE_RULE_READ` (0 = no rule read-back), `FIFO_RAM` (1 = block-RAM FIFOs, default). Elaboration checks reject inconsistent combinations (for example a queue that cannot hold a maximum frame, which would
deadlock in lossless mode).
