# Virtual cloud networking and tenant isolation

Requirement: *one tenant cannot modify another tenant's forwarding rules.* This is enforced **in hardware, in the register block**
(`sf_pkt_regs`) and in the lookup (`sf_pkt_classifier`), independent of software.

## Model

* Every register access carries an accessor id `rb_tenant`: 0 = administrator (hypervisor / control plane), 1..`NUM_TENANTS`-1 = tenants.
  **The engine cannot authenticate this id**: it must come from a trusted interconnect (for example a PCIe function / VF number or a
  hypervisor-owned MMIO window per tenant). An id >= `NUM_TENANTS` is rejected for every access, including `ID` (fail closed).
* The administrator owns: all global policy, queue / scheduler configuration, the tenant table (`SCOPE_VID`, `SCOPE_VNI`, `QMASK`, `ENABLE`), the
  rule-ownership table (`OWNER[r]`) and the global counters.

## What a tenant can do

| Action | Allowed when |
|---|---|
| Program / clear / read back a rule | the slot is owned by that tenant (`OWNER[r] == id`) |
| Rule content | verdict FORWARD or DROP only; FORWARD must name its queue(s) (`set_queue` or `qsel_hash`) and **every named queue must be in the tenant's queue mask**; `count`, `set_tc`, `set_dscp`, `dec_ttl` are allowed (they only touch the tenant's own traffic) |
| Match scope | automatic: a tenant rule is AND-ed with the tenant scope (outer VLAN id == `SCOPE_VID`, or VXLAN VNI == `SCOPE_VNI`), so it can never match another tenant's traffic, whatever fields it sets |
| Read rule counters | own slots only (after `RULE_SNAP`) |
| Read | `ID`, `VERSION`, `CAPS*`, its own tenant-table entry, its own `RULE_STATUS`, `OWNER[r]` of its own slots |

Everything else is rejected: no state change, `rb_err = 1`, the global `viol` counter increments and `VIOL_LAST` records {address, accessor, read/write}.

## Mechanisms that matter

1. **Single-owner staging window.** A rule is written word-by-word into a staging window and committed with `RULE_CMD`. The window has one owner: any
   write by a different accessor first **clears the window** and claims it. A commit by an accessor that does not own the window fails (`ERR_STAGE`), so
   words from two tenants can never be merged into one rule. Tested: tenant 1 stages, tenant 2 claims, tenant 1's commit is refused and the final rule table is
   exactly what the model predicts.
2. **Re-checked at lookup.** Effective validity of a tenant rule is recomputed every cycle from the tenant's `ENABLE`, `QMASK` and the rule itself
   (`rl_eff_valid`). Disabling a tenant, or shrinking its queue mask, takes effect immediately without rewriting any rule (tested mid-traffic).
3. **Atomic commit.** A commit changes the match table in one cycle and the action table one cycle later (aligned to the classifier), so a frame never sees a
   half-updated rule.
4. **Per-accessor status.** `RULE_STATUS` is per accessor, so a tenant cannot observe another tenant's command results.

## Verified

`run_system_tests.py::test_isolation` (437 register-level expectations + 1000 packets): ownership theft, cross-slot commit / clear / read, staging race,
MGMT verdict, queue outside the mask, FORWARD without a queue, hash group leaving the mask, global-register read/write, other tenant's table / owner / counters,
out-of-range accessor id, tenant widening its own mask, and the **exact violation count**; then traffic with five VLAN / VNI flows to confirm that tenant rules only ever
steer their own tenant's traffic and that out-of-scope traffic reaches the administrator default unchanged.

## Not covered (be aware)

* Timing or buffer side channels: tenants that share an egress queue share its congestion and latency. Isolate bandwidth with per-queue rate limits and
  separate queue masks; the engine does not partition the delay FIFO / parser.
* Overlapping scopes configured by the administrator are the administrator's responsibility. Rules match in slot order, so a tenant that owns a low slot
  overrides administrator rules *for its own scope* by design.
* Tenant identity is not authenticated here (see Model). `ENABLE_TENANT = 0` removes the tenant machinery (all accessors except 0 are rejected).
