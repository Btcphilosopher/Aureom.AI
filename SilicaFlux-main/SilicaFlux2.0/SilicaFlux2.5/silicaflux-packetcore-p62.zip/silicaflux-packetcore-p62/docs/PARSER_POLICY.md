# Parser: explicit, bounded policy

The parser (`sf_pkt_parser`) never assumes a fixed header length and never reads a byte that was not received.
Everything not covered here is reported through `unsupp` (never silently mis-parsed) or `perr` (malformed).

## Window and timing

* The parser captures the first **WIN = ceil(HDR_CAP_BYTES/(DW/8)) x (DW/8)** bytes of every frame (128 bytes for DW = 64..512 with the default
  `HDR_CAP_BYTES = 128`; 192 for DW = 64 with `HDR_CAP_BYTES = 192`). WIN must be in 128..255.
* One **token** per frame is produced when the window is complete **or** the frame ends, whichever is first (`eop_seen` tells which).
  `avail = min(frame length, WIN)`. Bytes beyond `avail` read as 0 and every field access is bounds-checked against `avail`
  (exhaustively tested: every truncation length 1..140 of every directed packet).
* The pipeline has initiation interval 1 and no back-pressure (admission control upstream limits frames in flight): **7 clock cycles** from the
  accept of the beat that completes the window to the token, then 3 cycles of classification.

## What is parsed

| Layer | Supported | Out of scope / behaviour |
|---|---|---|
| Ethernet | Ethernet II. `ethertype < 0x0600` (802.3 length) is carried as `ethertype`, `l3_type = none`. | LLC/SNAP not parsed. |
| VLAN | Up to **2 tags**; two programmable TPIDs (`POL_TPID`, default `0x8100`, `0x88A8`), either accepted at either position. Outer tag -> `vlan_vid/pcp/dei`, inner -> `vlan_vid2`. | A 3rd tag -> `unsupp = VLAN_OVF`. |
| IPv4 | IHL 5..15 (**options skipped by IHL**, not interpreted). | - |
| IPv6 | Fixed header + extension headers **Hop-by-Hop (0), Routing (43), Destination (60), Fragment (44), AH (51)**, at most **MAX_EXT = 4** and entirely inside the window. ESP (50) and No-Next-Header (59) are terminal. | A longer chain -> `unsupp = EXT_LIMIT`; a header that would end beyond the window while the frame continues -> `unsupp = WINDOW`; a header cut off by the end of the frame -> `perr = L3_TRUNC`. `payload length = 0` (jumbogram) disables the length checks. |
| L4 | TCP (ports, flags, data offset), UDP (ports, length); any other protocol is `l4_type = OTHER` with `ip_proto`. | **TCP/UDP checksums are not verified** (they need the whole payload). |
| Tunnel | **VXLAN** metadata: UDP destination port == `POL_VXLAN.port` (4789) and UDP length >= 16 -> `vni_valid` = I-flag, `vni`. | Only the outer headers are parsed; the inner frame is not. UDP/4789 with a shorter payload is plain UDP. |
| Hash | RSS-compatible **Toeplitz** over (src, dst) and, when TCP/UDP and not a fragment, (sport, dport); runtime key (`RSS_KEY`, default = Microsoft key). | Checked against the published 82599 verification vectors (IPv4 and IPv6). |

## Validation (all in the parser unless noted)

| Check | Result on failure (`perr`) | Priority |
|---|---|---|
| Frame shorter than the Ethernet header + tags present | `ETH_TRUNC` | 1 (highest) |
| IP version field (4 / 6) | `IP_VER` | 2 |
| IPv4 IHL < 5 | `IPV4_IHL` | 3 |
| IP header (or IPv6 ext header) beyond the received bytes | `L3_TRUNC` | 4 |
| IPv4 total length < IHL x 4 | `IPV4_TOTLEN` | 5 |
| IPv4 header checksum (`POL_ERR.csum_en`) | `IPV4_CSUM` | 6 |
| L4 header beyond the received bytes | `L4_TRUNC` | 7 |
| TCP data offset < 5 | `TCP_DOFF` | 8 |
| UDP length < 8, or L4 header/length beyond the IP datagram | `L4_LEN` | 9 |
| **Declared IP datagram longer than the received frame** | late check at the dispatcher: `drop_lenmis` | - |
| Frame < `POL_LEN.min_len` / > `POL_LEN.max_len` (default 60 / `MAX_FRAME_BYTES`) | late: `drop_runt` / `drop_oversize` | - |

Frames *longer* than their IP datagram are legal (Ethernet padding). Length-dependent checks need the whole frame, so they are
done at the last beat, where the speculative queue write is simply aborted (nothing becomes visible).

When `perr != 0` all L3/L4 token fields are zero (deterministic, compared bit-exactly against the model). When `unsupp != 0` the L4 fields are zero
and the L3 fields remain valid.

## Fragments

An IPv4 packet with MF set or a non-zero offset, and any IPv6 packet with a Fragment header (including "atomic" fragments), has
`ip_frag = 1` (`ip_nonfirst = 1` for offset != 0). **No L4 fields are extracted from any fragment** (`l4_type = none`), so all fragments of a
flow are classified and hashed consistently on L3 fields. Handling is a policy: `POL_ERR.frag_act` = DROP / PUNT to management /
CONT (classify normally on L3; the default).

## Policy actions

`malformed_act` (parser errors): DROP (default) or PUNT. `unsupp_act`: DROP, PUNT (default) or CONT. `frag_act`: DROP, PUNT or CONT (default).
CONT = continue with the normal match/action lookup on the fields that were parsed. A MAC-flagged bad frame, an illegal `keep`
pattern, a runt and an oversize frame are always dropped, never punted.
