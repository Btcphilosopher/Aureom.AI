# FPGA integration, and what was (and was not) run

## 1. Attaching an existing Ethernet MAC

`sf_pkt_mac_adapter` (see `INTERFACE.md` section 3) is the only MAC-facing block. **No MAC, PCS or SerDes/PHY is implemented here, and no 100/200/400 GbE PHY is invented**:
use the MAC IP of your platform (vendor 10/25/40/100G MAC subsystems or an open one) in its AXI-Stream mode. Checklist:

| Item | Requirement |
|---|---|
| Clock | MAC user clock == engine `clk`, or put the MAC vendor's clock-converter FIFO in front. The engine has no CDC. |
| Width | `DW` equal to the MAC stream width (64/128/256/512), or an AXI-S width converter in front. |
| RX | no `tready` on the MAC side; `tuser[0]` = bad frame on the last beat; FCS stripped; first wire byte on `tdata[7:0]`. Frames the buffer cannot take are dropped whole and counted (`stat_rx_overflow`). |
| TX | MAC pads runts and appends the FCS; `tx_tvalid` stays high through a frame (the engine only starts complete frames). |
| Reset | system reset: release the engine, adapter and MAC together; use `sf_reset_sync` (vendored) to synchronise deassertion. |
| Management port | `x_*` is a separate stream (frames punted for the CPU / control plane) with a reason code; drain it, or it overflows (tail-drop, counted `mgmt_drop`). |
| Registers | `rb_*` bus with `rb_tenant` driven by a trusted interconnect (`ISOLATION.md`). |

## 2. Synthesis and place-and-route that was actually run

Tools: Yosys 0.33 `synth_ecp5`, nextpnr-ecp5 0.6, target **Lattice ECP5 LFE5U-85F, speed grade 6, CABGA381**. No vendor tool (Vivado / Quartus / Libero), no board, no bitstream.

**Resource counts** (technology-mapped, before place-and-route) for the default and reduced builds are in `PERFORMANCE.md` section 4 and `reports/SUMMARY.md`.
The default configuration (DW = 128, 16 rules, 8 tenants, ...) **does not fit one ECP5-85F**, so it was not placed and routed.

**Place-and-route reference configuration** (it fits; it is a *reduced* engine, not the default): `DW = 128`, 2 queues x 4 KB, 4 rules, 2 tenants, `MAX_FRAME_BYTES = 2048`, statistics block off,
fixed RSS key, no rule read-back. The engine has ~600 stream pins, so it was wrapped in a harness (`synth/pnr_top.sv`) that drives it from an LFSR and XOR-reduces every output into one registered bit;
only `clk`, `rst_n` and that bit are top-level ports. Paths inside the engine are real; stimulus is pseudo-random, not traffic. Target clock 50 MHz. Two parser shapes were placed
(same seed 7, `--placer heap`, `--timing-allow-fail`):

| Run | `MAX_EXT` / `EXT_STEP` | Fmax after routing | Limiting path |
|---|---|---|---|
| `ref_small` (library default shape) | 4 / 2 | **20.56 MHz -- FAILS 50 MHz** | parser IPv6 extension-header walk (`g_ext[1]`: next-type, next-size, offset add, bound compare in one cycle) |
| `ref_small_ext1` | 2 / 1 | **27.78 MHz -- FAILS 50 MHz** | scheduler: `cur_v` -> queue head-descriptor read (distributed RAM) -> reservation compare / token update -> arbiter |

Neither run closed timing. Raw summaries (utilisation, post-placement estimate, post-route Fmax, critical-path endpoints) follow; full logs are in `reports/pnr_*.pnr.log`.

<!-- BEGIN GENERATED:pnr_ref -->
`pnr_ref_small.summary`
```
seed=7
TRELLIS_COMB   31023 / 83640  (37%)
TRELLIS_FF     15753 / 83640  (18%)
TRELLIS_RAMW     114 / 10455  (1%)
DP16KD            13 / 208    (6%)
MULT18X18D         6 / 156    (3%)
Fmax after routing: 20.56 MHz (FAIL at 50.00 MHz target)
Fmax estimate after placement (before routing): 12.40 MHz
critical path: u_eng.u_parser.ces_TRELLIS_FF_Q_29.Q  ->  u_eng.u_parser.ces_TRELLIS_FF_Q_3.DI
  9.5 ns logic + 39.1 ns routing
```

`pnr_ref_small_ext1.summary`
```
seed=7
TRELLIS_COMB   29711 / 83640  (35%)
TRELLIS_FF     15753 / 83640  (18%)
TRELLIS_RAMW     114 / 10455  (1%)
DP16KD            13 / 208    (6%)
MULT18X18D         6 / 156    (3%)
Fmax after routing: 27.78 MHz (FAIL at 50.00 MHz target)
Fmax estimate after placement (before routing): 19.28 MHz
critical path: u_eng.u_sched.cur_v_TRELLIS_FF_Q.Q  ->  u_eng.u_sched.tok_TRELLIS_FF_Q_52.DI
  12.2 ns logic + 23.8 ns routing
```
<!-- END GENERATED:pnr_ref -->

## 3. Real achieved vs analytical (kept separate on purpose)

* **Achieved (section 2)**: the open ECP5 flow *failed* to close 50 MHz for the reference configuration. The best result, 27.78 MHz, times `DW = 128` bits is a **datapath capacity of about 3.6 Gbit/s**
  (`f x DW`, before wire overhead) for that reduced build; the library-default parser shape gave 20.56 MHz (about 2.6 Gbit/s). That is *below* 10 GbE at DW = 128 (needs 60 - 77 MHz, `PERFORMANCE.md` section 3).
* **Analytical** (`PERFORMANCE.md` section 3): the clock a line rate would *require* at 1.000 beats/cycle. Comparing the two is the honest statement: **this implementation on an ECP5-85F-6 serves a few Gbit/s,
  not 10/25/100 GbE.** Wider datapaths (DW = 512 needs only 15 - 20 MHz for 10 GbE) were *not* place-and-routed, so no claim is made for them; faster fabrics (UltraScale+/Agilex) were not measured either.
* Throughput in beats per cycle (1.000) is a property of the RTL and is measured in simulation, independent of the FPGA.
* No claim is made that any 25/40/100/200/400 GbE rate is achieved on any FPGA; those rows are only the clock a line rate would require.

## 4. Known timing structure (from the place-and-route reports)

* **Parser, IPv6 extension-header walk** (`ref_small`, 20.56 MHz): 9.5 ns logic + 39.1 ns routing. Each walk step does a word-aligned window read, a next-header decode, a header-length add and a bound compare in one clock;
  the placer also spread it across the die (nets of 3 - 4 ns). `EXT_STEP = 1` and a smaller `MAX_EXT` shorten it (second run); splitting each step into read / decode / add stages is a feed-forward change (+1 cycle of parser latency per stage, no
  effect on throughput) and is the straightforward fix. **Not done.**
* **Scheduler / queue head read** (`ref_small_ext1`, 27.78 MHz): 12.2 ns logic + 23.8 ns routing. Approximately: the head descriptor is read from the queue's distributed-RAM storage and consumed combinationally by the length/token reservation and the
  arbiter in the same cycle (the reported path alternates between `u_sched` and `u_q.dmem` cells). Registering the head-descriptor fields one stage earlier (the descriptor FIFO already exposes head/+1/+2) is the expected fix, but it changes the scheduler's zero-bubble timing, so it needs the scheduler tests re-derived and a fresh regression; its effect on Fmax is **not measured**. **Not done.**
* Routing is ~80% of the first path and ~65% of the second: with 31 k of 83.6 k LUT4 used, the open placer is not timing-driven enough to keep these chains local. A vendor tool with timing-driven placement may do better; **that was not run.**
* **History**: an earlier run (before `rtl/sf_pkt_toeplitz.sv` was rewritten from a serial `if`/XOR chain into a balanced XOR tree) reported 21.14 MHz with the Toeplitz hash as the critical path. *The log file of that
  run was overwritten when the flow was re-run and is not in `reports/`; the figure is quoted from the run output.* The present 20.56 MHz result is a different path (the extension-header walk) and is **not** an improvement over it.
