# Egress scheduler

`sf_pkt_sched` arbitrates **whole frames** between the `NUM_QUEUES` data queues onto the single egress stream (frames are never interleaved).
The management queue is not scheduled: it has its own port.

| Mode (`SCHED_MODE`) | Behaviour |
|---|---|
| 0 RR | Packet-granularity round robin among eligible queues (reuses `sf_rr_arb` from the SilicaFlux P40 set). |
| 1 SP | Strict priority classes (`QCFG.PRIO`, 0 = highest), round robin inside a class, plus an **aging guard**: a queue that has been eligible but not served for >= `SCHED_STARVE` clocks becomes *urgent* and is served before any class (0 disables the guard). |
| 2 DWRR | Deficit-weighted round robin in bytes. quantum(q) = `QCFG.WEIGHT` x `SCHED_QUANT`. When no eligible queue can afford its head frame, every eligible queue's deficit is increased by its quantum ("round replenishment"); an empty queue's deficit is reset (classic DRR). |

**Eligibility:** a queue is eligible when it has an unreserved committed frame and its rate limiter allows a start.
**Rate limiter** (per queue, enabled when `QCFG.RL_INC != 0`): signed token bucket; every `RL_PERIOD` clocks it gains `RL_INC` bytes (capped at `RL_BURST`); a frame may *start* when
tokens > 0 and its length is deducted at selection (the bucket may go negative = debt). Long-run rate = `RL_INC`/`RL_PERIOD` bytes per clock for any frame size.
**Congestion counters:** per-queue occupancy, high-water mark, cycles above `QCFG.WM`, tail-drops.
**Zero bubbles:** a two-deep selection pipeline (current / next) chooses the next frame while the current one streams, so even single-beat frames leave back-to-back
(measured 1.000 beats/cycle for every frame size, DW = 64..256).

## Behaviour worth knowing

* Selection happens up to two frames ahead of the egress, so a frame that arrives a few cycles after a lower-priority frame was already reserved will wait behind it:
  priority inversion is bounded by **two frames**.
* Packet-slot quantisation: with equal-size frames, round robin gives each queue the same number of *frames*; a frame occupies `ceil(len/(DW/8))` beats. A rate limit
  above a queue's fair share has no effect (the limiter only binds below the share) -- measured while writing the tests.
* Starvation bound (SP + guard): a starved queue waits at most `guard + own frame transfer + frame in flight + reservation + commit pipeline`; measured 292 cycles
  with a 200-cycle guard at DW = 128 (strict priority alone: 899 cycles, i.e. until the high class drained).
* DWRR is exact for equal frame sizes (measured shares 3:6:9:12 for weights 1:2:3:4); with mixed sizes the usual DRR error of one frame per round applies.

## Measured (simulation, see `reports/system_metrics_dw*.json`)

| Test | Result |
|---|---|
| RR, 4 backlogged queues | every window of 4 frames serves each queue once |
| SP, 4 classes | output strictly priority-sorted while higher classes are backlogged |
| SP + guard 200 | lowest class served after 292 cycles (DW = 128) instead of 1027 |
| DWRR weights 1:2:3:4 | first 30 frames: 3 / 6 / 9 / 12 |
| Rate limit 2 B/clk (and 8 B per 4 clk) | 2.06 B/clk steady state (burst credit explains the +3 %), link 100 % busy |
| Rate limit 1 B/clk | 1.006 B/clk |
