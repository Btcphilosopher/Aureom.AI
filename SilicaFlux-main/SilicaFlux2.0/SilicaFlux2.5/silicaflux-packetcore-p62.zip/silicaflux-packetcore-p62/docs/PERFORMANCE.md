# Performance

Three kinds of number appear in this project and they are kept apart:

| Kind | Source | Where |
|---|---|---|
| **Measured (simulation)** | cycle-accurate RTL simulation: testbench-counted cycles and the engine's own statistics registers | this file |
| **Analytical** | measured beats/cycle x datapath width x an *assumed* clock | this file, section 3, clearly labelled |
| **Achieved FPGA** | nextpnr place-and-route result of the RTL on an ECP5 | `FPGA.md` only |

## 1. Measured throughput (simulation)

Back-to-back frames of one size, ingress never idle, egress always ready, default configuration; "sustained" is measured over the middle 90 % of 300 frames.
**The engine sustains 1.000 beats per cycle for every frame size at every verified width** -- including back-to-back minimum frames (4 beats at DW = 128, 1 beat at DW = 512): the parse and
classify pipelines have initiation interval 1, the dispatcher and queues move one beat per cycle across frame boundaries, and the scheduler selects the next frame while the current one streams (zero idle cycles).

DW = 128:

<!-- BEGIN GENERATED:throughput_dw128 -->
| Frame (B) | sustained beats/cycle | frames/cycle | bytes/cycle | first-frame latency (cycles, SOP in -> SOP out) |
|---|---|---|---|---|
| 60 | 1.0000 | 0.2500 | 15.00 | 23 |
| 64 | 1.0000 | 0.2500 | 16.00 | 23 |
| 128 | 1.0000 | 0.1250 | 16.00 | 31 |
| 256 | 1.0000 | 0.0625 | 16.00 | 39 |
| 512 | 1.0000 | 0.0312 | 16.00 | 55 |
| 1024 | 1.0000 | 0.0156 | 16.00 | 87 |
| 1518 | 1.0000 | 0.0105 | 15.98 | 118 |
| 4096 | 1.0000 | 0.0039 | 16.00 | 279 |
| 9000 | 1.0000 | 0.0018 | 15.99 | 586 |
<!-- END GENERATED:throughput_dw128 -->

DW = 512:

<!-- BEGIN GENERATED:throughput_dw512 -->
| Frame (B) | sustained beats/cycle | frames/cycle | bytes/cycle | first-frame latency (cycles, SOP in -> SOP out) |
|---|---|---|---|---|
| 60 | 1.0000 | 1.0000 | 60.00 | 17 |
| 64 | 1.0000 | 1.0000 | 64.00 | 17 |
| 128 | 1.0000 | 0.5000 | 64.00 | 19 |
| 256 | 1.0000 | 0.2500 | 64.00 | 21 |
| 512 | 1.0000 | 0.1250 | 64.00 | 25 |
| 1024 | 1.0000 | 0.0625 | 64.00 | 33 |
| 1518 | 1.0000 | 0.0417 | 63.25 | 41 |
| 4096 | 1.0000 | 0.0156 | 64.00 | 81 |
| 9000 | 1.0000 | 0.0071 | 63.83 | 158 |
<!-- END GENERATED:throughput_dw512 -->

(DW = 64 and 256 are in `reports/SUMMARY.md`.) "frames/cycle" for 60 B frames is 1/ceil(60/(DW/8)): 0.25 at DW = 128, 1.0 at DW = 512.

## 2. Measured latency

Unloaded (one frame in an empty engine), cycles from the first ingress beat accepted to the first / last egress beat accepted:

<!-- BEGIN GENERATED:latency -->
| DW | frame (B) | SOP-to-SOP (cycles) | EOP-to-EOP (cycles) |
|---|---|---|---|
| 64 | 60 | 31 | 38 |
| 64 | 128 | 47 | 62 |
| 64 | 512 | 95 | 158 |
| 64 | 1518 | 221 | 410 |
| 64 | 9000 | 1156 | 2280 |
| 128 | 60 | 23 | 26 |
| 128 | 128 | 31 | 38 |
| 128 | 512 | 55 | 86 |
| 128 | 1518 | 118 | 212 |
| 128 | 9000 | 586 | 1148 |
| 256 | 60 | 19 | 20 |
| 256 | 128 | 23 | 26 |
| 256 | 512 | 35 | 50 |
| 256 | 1518 | 67 | 114 |
| 256 | 9000 | 301 | 582 |
| 512 | 60 | 17 | 17 |
| 512 | 128 | 19 | 20 |
| 512 | 512 | 25 | 32 |
| 512 | 1518 | 41 | 64 |
| 512 | 9000 | 158 | 298 |
<!-- END GENERATED:latency -->

The first-beat latency grows with frame length because each frame is **committed into its queue at its last beat** before it can leave (store-and-forward at the queue; the destination itself is decided from the
first 128 bytes, a fixed number of cycles after the window completes: 7 cycles parse + 3 cycles classify + dispatch + queue commit + 2-deep scheduler selection). For a 60 B frame at DW = 128 this is 21 cycles.
Loaded latency is queueing delay; the engine measures it in hardware (`lat_pipe_*`: ingress -> dispatch, `lat_e2e_*`: ingress -> egress, each with sum / count / min / max).

## 3. Analytical: clock needed to keep up with a line rate

Because the datapath moves one beat per cycle, it keeps up with a line rate R when `f_clk >= frames_per_second x beats_per_frame` (frames exclude the FCS; wire overhead = 20 B preamble + inter-frame gap + 4 B FCS).
**These are requirements, not achievements.** The achieved clock of the RTL on a real FPGA is in `FPGA.md`.

<!-- BEGIN GENERATED:analytic -->
| Line rate | frame size | frames/s (M) | DW=64 | DW=128 | DW=256 | DW=512 |
|---|---|---|---|---|---|---|
| 10 GbE | 60 B | 14.9 | 119 MHz | 60 MHz | 30 MHz | 15 MHz |
| 10 GbE | 1514 B | 0.8 | 154 MHz | 77 MHz | 39 MHz | 20 MHz |
| 25 GbE | 60 B | 37.2 | 298 MHz | 149 MHz | 74 MHz | 37 MHz |
| 25 GbE | 1514 B | 2.0 | 386 MHz | 193 MHz | 98 MHz | 49 MHz |
| 40 GbE | 60 B | 59.5 | 476 MHz | 238 MHz | 119 MHz | 60 MHz |
| 40 GbE | 1514 B | 3.3 | 618 MHz | 309 MHz | 156 MHz | 78 MHz |
| 100 GbE | 60 B | 148.8 | 1190 MHz | 595 MHz | 298 MHz | 149 MHz |
| 100 GbE | 1514 B | 8.1 | 1544 MHz | 772 MHz | 390 MHz | 195 MHz |
| 200 GbE | 60 B | 297.6 | 2381 MHz | 1190 MHz | 595 MHz | 298 MHz |
| 200 GbE | 1514 B | 16.3 | 3088 MHz | 1544 MHz | 780 MHz | 390 MHz |
| 400 GbE | 60 B | 595.2 | 4762 MHz | 2381 MHz | 1190 MHz | 595 MHz |
| 400 GbE | 1514 B | 32.5 | 6177 MHz | 3088 MHz | 1560 MHz | 780 MHz |
<!-- END GENERATED:analytic -->

## 4. Resources (Yosys `synth_ecp5`, technology-mapped, before place-and-route)

Default configuration (`DW = 128`, 4 queues x 16 KB, 16 rules, 8 tenants, programmable RSS key, rule read-back, 40-bit counters), hierarchical:

<!-- BEGIN GENERATED:hier_default -->
| Module | LUT4 | FF | EBR (18 kb) | distributed RAM (DPR16X4) |
|---|---|---|---|---|
| sf_pkt_classifier | 10075 | 417 | 0 | 0 |
| sf_pkt_counters | 13688 | 7924 | 0 | 0 |
| sf_pkt_parser | 11275 | 7964 | 0 | 0 |
| sf_pkt_sched | 2747 | 367 | 0 | 0 |
| sf_pkt_dispatch | 1747 | 39 | 0 | 0 |
| sf_pkt_regs | 52595 | 16876 | 0 | 0 |
| sf_pkt_fifo (instance 1) | 95 | 126 | 0 | 26 |
| sf_pkt_fifo (instance 2) | 183 | 302 | 0 | 70 |
| sf_pkt_fifo (instance 3) | 199 | 471 | 5 | 0 |
| sf_pkt_queue | 1244 | 512 | 9 | 324 |
| sf_rr_arb | 215 | 2 | 0 | 0 |
| sfb_skid_buffer | 174 | 334 | 0 | 0 |
| sf_pkt_toeplitz | 6176 | 0 | 0 | 0 |
| silicaflux_packet_engine | 352 | 39 | 0 | 0 |
| **total (hierarchy)** | **105741** | **37421** | **50** | **1716** |
<!-- END GENERATED:hier_default -->

Same configuration with `RSS_PROG_KEY = 0` and `ENABLE_RULE_READ = 0` (note: the Toeplitz module is shown unflattened with a generic key input; flattened with the key constant it folds to roughly a third of its size -- see the standalone parser rows below):

<!-- BEGIN GENERATED:hier_small -->
| Module | LUT4 | FF | EBR (18 kb) | distributed RAM (DPR16X4) |
|---|---|---|---|---|
| sf_pkt_classifier | 10094 | 417 | 0 | 0 |
| sf_pkt_counters | 13688 | 7924 | 0 | 0 |
| sf_pkt_sched | 2747 | 367 | 0 | 0 |
| sf_pkt_dispatch | 1747 | 39 | 0 | 0 |
| sf_pkt_regs | 42985 | 16876 | 0 | 0 |
| sf_pkt_fifo (instance 1) | 95 | 126 | 0 | 26 |
| sf_pkt_fifo (instance 2) | 183 | 302 | 0 | 70 |
| sf_pkt_fifo (instance 3) | 199 | 471 | 5 | 0 |
| sf_pkt_queue | 1248 | 512 | 9 | 324 |
| sf_pkt_parser | 12177 | 7964 | 0 | 0 |
| sf_rr_arb | 215 | 2 | 0 | 0 |
| sfb_skid_buffer | 174 | 334 | 0 | 0 |
| sf_pkt_toeplitz | 6176 | 0 | 0 | 0 |
| silicaflux_packet_engine | 352 | 39 | 0 | 0 |
| **total (hierarchy)** | **97072** | **37421** | **50** | **1716** |
<!-- END GENERATED:hier_small -->

Standalone block syntheses:

<!-- BEGIN GENERATED:blocks -->
| Block (standalone) | Parameters | LUT4 | FF | EBR | DPR16X4 |
|---|---|---|---|---|---|
| sf_pkt_counters | NQ=4 NR=16 CW=40 | 14038 | 7924 | 0 | 0 |
| sf_pkt_parser | DW=128 | 21625 | 7964 | 0 | 0 |
| sf_pkt_parser | DW=128 RSS_PROG_KEY=0 | 14149 | 7964 | 0 | 0 |
| sf_pkt_regs | NQ=4 NR=16 NT=8 DW=128 | 51727 | 16876 | 0 | 0 |
| sf_pkt_regs | NQ=4 NR=16 NT=8 DW=128 ENABLE_RULE_READ=0 | 42871 | 16876 | 0 | 0 |
| sf_pkt_regs | NQ=4 NR=4 NT=8 DW=128 | 29122 | 6028 | 0 | 0 |
| sf_pkt_regs | NQ=4 NR=8 NT=8 DW=128 | 36154 | 9644 | 0 | 0 |
| sf_pkt_regs | NQ=4 NR=16 NT=2 DW=128 | 43907 | 16474 | 0 | 0 |
<!-- END GENERATED:blocks -->

What the area is (default configuration, 105.7 k LUT4 in the hierarchical table): the **register block** (`sf_pkt_regs`: flip-flop rule table, 876 bits x `NUM_RULES`, plus tenant, queue and staging state) is about
half (52.6 k LUT4, 50%); the **statistics counters** (about 100 saturating 40-bit counters + shadow) 13.7 k (13%); the **parser** 11.3 k (11%) plus the RSS Toeplitz hash 6.2 k (6%);
the **classifier** (16 parallel ternary compares) 10.1 k (10%); the scheduler, dispatcher, queues and FIFOs are small (about 7 k together; queue storage is block RAM / distributed RAM, 50 EBR + 1716 DPR16X4).
The default configuration therefore does **not** fit one ECP5-85F (83.6 k LUT4). `NUM_RULES`, `HDR_CAP_BYTES`, `MAX_EXT`, `RSS_PROG_KEY`, `ENABLE_RULE_READ`, `ENABLE_PERF` and `CW` are the levers
(a BRAM/CAM rule store and a counter RAM are the next structural step, not done). The standalone block table is a separate Yosys run per block (flattened, so constants fold differently from the hierarchical table).
Timing is a separate matter: see `FPGA.md` -- the reduced reference build that fits did not reach 50 MHz.

## 5. Using the statistics registers

`cycles`, `egr_busy` (beats delivered), `fwd_bytes`, `fwd_pkts` over a snapshot window give throughput; `ing_stall` / `egr_stall` give back-pressure; per-queue `hwm_bytes` / `wm_cycles` / `drop_pkts` give
congestion; `lat_*` give latency. Counters saturate rather than wrap; read a consistent set after `CTRL.snap_global`.
