# PacketCore interfaces

## 1. Streaming interface (ingress `s_*`, data egress `m_*`, management egress `x_*`)

An AXI4-Stream-compatible subset with a documented last-beat convention. Everything below is checked by the
testbench protocol monitors (stability under stall, keep legality, sideband constancy, length consistency).

| Signal | Dir (ingress) | Meaning |
|---|---|---|
| `valid`/`ready` | in / out | Transfer on `valid && ready`. Once `valid` is asserted, payload and sideband are held until accepted. |
| `data[DW-1:0]` | in | Frame bytes. **Byte 0 of the frame (first destination-MAC byte on the wire) is `data[7:0]` of beat 0**; byte *k* of a beat is `data[8k+7:8k]`. |
| `keep[DW/8-1:0]` | in | Byte enable. **All-ones on every beat except the last.** On the last beat it is a **contiguous low-order mask** (`2^n-1`, n >= 1): partial final beats. |
| `last` | in | Final beat of the frame. There is **no SOP signal**: the first beat after a `last` (or after reset) starts a frame. |
| `err` (`s_err`) | in | Sampled **on the last beat only**. 1 = the MAC flagged the frame bad (e.g. FCS). The frame is dropped and counted (`drop_macerr`), never forwarded. `m_err` is tied 0: the engine never forwards a frame flagged bad. |
| `src` (`s_src`, `SRC_W` bits) | in | Ingress queue / port id, **sampled on the first beat**, carried unchanged to `m_src`/`x_src`. |
| `meta` (`s_meta`, `META_W` bits) | in | Opaque user metadata, sampled on the first beat, carried unchanged to `m_meta`/`x_meta`. |

**Egress sideband** (`m_queue`, `m_tc`, `m_src`, `m_meta`, `m_hash`, `m_len`; management: `x_reason`, `x_tc`, `x_src`, `x_meta`, `x_hash`, `x_len`)
is valid on **every beat** and constant for the whole frame; `m_hash` is the RSS-compatible Toeplitz hash, `m_len` the frame length in
bytes. Frames are never interleaved and a frame leaves either completely or not at all.

**Frames exclude the Ethernet FCS.** The engine neither generates nor checks FCS: that belongs at the MAC. It does not advertise any
FCS function. A `keep` pattern that violates the rule above is detected, the frame dropped (`drop_keep`) and the beat data under
`keep = 0` is never used (tested with garbage injected under `keep = 0`).

**Ordering.** Frames leave a given queue in arrival order. A flow stays on one queue as long as the rule table is unchanged. Across
queues the scheduler interleaves at frame boundaries only. Frames to the management port keep arrival order among themselves.

**Reset** is asynchronous-assert, active low (`rst_n`; SilicaFlux convention, `sf_reset_sync` in the vendored set is the recommended
bridge). Reset in the middle of a frame discards everything in flight; an egress frame in progress is cut **without** `last`, so the
receiver must be reset together with the engine (system reset). Registers return to their reset values (rules invalid, default action
FWD to queue 0).

**Back-pressure.** `s_ready` can be deasserted for up to the full queue depth (lossless mode, head-of-line blocking across queues,
documented in `CLASSIFIER.md`) or never for long (tail-drop mode). The management port is always tail-drop so a stalled CPU can never block
the data plane.

## 2. Register bus

One request per cycle: `rb_req`, `rb_we`, `rb_addr[15:0]` (byte address, word aligned), `rb_wdata[31:0]`, `rb_tenant[3:0]`.
The response arrives exactly **one cycle later**: `rb_rvalid`, `rb_rdata[31:0]`, `rb_err`. `rb_tenant` is the accessor identity (0 =
administrator, 1..NUM_TENANTS-1 = tenants); it must be driven by a trusted interconnect (`ISOLATION.md`). The register map is
versioned (`VERSION` register: major/minor/patch) and capability-discoverable (`CAPS0..2`); the full list is `REGISTERS.md`
(generated from the same table as the RTL and the model).

## 3. MAC adapter (`sf_pkt_mac_adapter`)

Connects an **existing** Ethernet MAC. No MAC, PCS or SerDes/PHY is implemented or invented here, and **no MAC exists in the SilicaFlux
repository** to verify against.

Assumed MAC conventions (the common AXI-Stream MAC interface): single shared clock and data width; RX has `tdata/tkeep/tvalid/tlast`,
**no `tready`**, and `tuser[0]` = bad frame on the last beat, FCS stripped; TX has `tready`, the MAC pads and appends the FCS. For a
different clock or width, place the vendor's clock/width converter in front.

* **RX** cannot be paused, so frames go through a packet-aware buffer (the same commit/abort queue as the engine). A frame that does not
  fit is dropped **whole** and counted (`stat_rx_overflow`); the engine never sees a partial frame. A MAC-flagged bad frame is passed on
  with `s_err = 1` so the engine's own accounting applies.
* **TX** is registered through a skid slice. The engine starts a frame only when it is complete in its queue, so `tx_tvalid` does not drop
  in the middle of a frame (no MAC underrun); the testbench checks this.
* `s_src = PORT_ID`, `s_meta` = arrival timestamp.

Tested only against a **behavioural AXI-S MAC model written for this project** (an RX source that cannot be paused and a TX sink with
random `tready`): normal traffic, overflow while TX is blocked, back-to-back minimum frames. It has **not** been exercised against any real
MAC IP.
