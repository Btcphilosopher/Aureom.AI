build products go here (make vendor / make regress)
