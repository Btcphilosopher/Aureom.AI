# SilicaFlux-HPC · Project 32 — ComputeCluster: floorplan-aware vector and tensor regions

**Primary RTL:** [`rtl/silicaflux_compute_cluster.sv`](rtl/silicaflux_compute_cluster.sv) · Aureom.AI | SilicaFlux-HPC

ComputeCluster organises the validated SilicaFlux engines into repeatable physical regions. Each region wraps
exactly **one unmodified engine** — the HPC Module 08 FP32 vector tile or the TENSORCORE 08 INT8 tensor unit — in a
thin shell that gives every cluster the same interface: a word-serial command stream, an in-order completion stream,
a CSR window, NoC-facing SFB2 memory ports, registered interrupt / error / status / performance outputs, a reset
sequencer that never corrupts the NoC, and a clock-enable request. The integration shell replicates the regions under
stable names (`u_vector_0..7`, `u_tensor_0..3`), routes commands and completions, and is generated into region
constraints from the *actual* synthesized hierarchy.

> **Status — read this first.** RTL simulation (Verilator, Icarus), technology-independent Yosys synthesis and
> offline execution of the generated constraint scripts only. **No silicon area, frequency, power or placement is
> claimed**; region boxes are proposals. **OpenROAD was not run** (it could not be installed in this environment;
> `physical/openroad_region_check.tcl` is the check to run where it is available). Six clusters are six of the
> existing engines — no illustration-scale throughput is implied. Delivered as an archive; nothing was committed.
> Details: [docs/07_LIMITATIONS.md](docs/07_LIMITATIONS.md).

## Definition of done

The minimum configuration works and the HPC hierarchy elaborates, simulates and synthesizes, with every compute
region identifiable in the netlist:

* **Minimum chip configuration** (`compute_min`: one M08 vector tile + one TC08 tensor unit, no slices, no local
  memory) passes every scenario — single commands, both engines at once, contention, back-pressure, routing, reset,
  forced drain, errors, CSR / legacy register-page submission, latency — and adds no latency to the memory path.
* **HPC hierarchy** (`compute_hpc`: `u_vector_0..3`, `u_tensor_0..1`) passes the multi-cluster scenarios; the
  testbench requires — and measured — cycles with two or more vector engines, both tensor engines, and vector and
  tensor engines busy at the same time (`reports/regression.md`). The full 8 V + 4 T configuration elaborates in
  Verilator, Icarus and Yosys (`reports/lint.md`) and runs under Icarus; it was not synthesized.
* **Every region is identifiable in the synthesis netlist**: `reports/synth/compute_hpc/netlist.v.gz` instantiates exactly
  `\u_vector_0.u_cl … \u_vector_3.u_cl`, `\u_tensor_0.u_cl`, `\u_tensor_1.u_cl`; the region Tcl generated from that
  hierarchy assigns all 880 094 gates and 2 177 120 memory bits to exactly one region each.

## Results (final run on frozen RTL, logic hash `901d9c2ff32c9b7e` recorded by every run — [reports/SUMMARY.md](reports/SUMMARY.md))

| Check | Result | Report |
|---|---|---|
| Re-run of the reused engines first: TC08 lint + stage 1, TC08 tile + tensor coexistence | 11/11 + 18/18 + **2/2**, **9/9** | `reports/audit/` |
| Lint / elaboration of 12 legal configurations: Verilator `-Wall` (**0 warnings in new RTL**), Icarus, Yosys | **12 / 12** | [lint](reports/lint.md) |
| 13 illegal configurations refused by Verilator, Icarus **and** Yosys | **13 / 13** | [lint](reports/lint.md) |
| Regression: 15 scenarios over 8 configurations, 1–3 seeds each (7 configurations Verilator, `max` 8 V + 4 T Icarus) | **85 / 85** | [regression](reports/regression.md) |
| Completion packets checked (src, tag, per-cluster order, header, engine record) + whole memory image per run | **1 997** | [regression](reports/regression.md) |
| SFB2 protocol checkers on every cluster NoC / local / scratchpad port, stream monitors, white-box drain check | 0 violations | [regression](reports/regression.md) |
| Icarus cross-simulation of the minimum configuration | **8 / 8** pass; 7 / 8 cycle-identical (the eighth is traced to the reused TC07 DMA, docs/06 §3) | [regression](reports/regression.md) |
| Mutation testing of the new RTL | **12 / 13** killed; survivor analysed as unreachable with a working engine | [mutation](reports/mutation.md) |
| Yosys generic synthesis, one vector cluster | **160 274** gates, 11 661 FF, 34 inferred memories (530 484 bits) | [synth](reports/synth.md) |
| Yosys generic synthesis, one tensor cluster | **118 779** gates, 12 519 FF, 39 inferred memories (27 592 bits) | [synth](reports/synth.md) |
| Yosys generic synthesis, minimum subsystem (1 V + 1 T) | **278 799** gates, 24 257 FF, 73 memories | [synth](reports/synth.md) |
| Yosys generic synthesis, HPC subsystem (4 V + 2 T) | **880 094** gates, 71 761 FF, 214 memories (2 177 120 bits); latch-free, `check -assert` | [synth](reports/synth.md) |
| Shell overhead per cluster (adapter, gates, control) | ≈ 3.4 % of a vector cluster's gates, ≈ 4.4 % of a tensor cluster's | [synth](reports/synth.md) |
| Generated region / sub-region Tcl executed against the synthesized names (OpenROAD- and Yosys-style names) | **8 / 8**: every instance in exactly one region, no overlap, accounting exact | [physical](reports/physical.md) |
| OpenROAD placement-region support | **not run** — OpenROAD could not be installed here; check script provided | [docs/05 §6](docs/05_PHYSICAL.md) |

Measured round trip of single commands (`latency`, cycles): vector NOP 27, tensor NOP 50, tensor 4×4×4 GEMM 169 in
`compute_min`; with every pipeline boundary enabled (64-bit) 29 / 52 / 180 ([docs/04](docs/04_TIMING.md) §5).

### Defects found and fixed during verification

* **Forced reset with a held scratchpad response** (found by mutation analysis): the scratchpad gate would have turned a
  response the NoC had not yet accepted into an error response — an SFB2 R4 violation. The gate now captures that
  response and delivers it unchanged; `reset_drain` covers it and the DataFabric protocol checker kills the mutant.
* **Forced reset with a presented request**: the memory gate now keeps such a request on the NoC from shell registers
  and drops its response, instead of being unable to force the reset.
* Testbench defects (not RTL): stimulus diverging between simulators, a signed-zero reference error, an over-broad
  error expectation — all fixed before the final run (docs/06).


## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit of the vector array, tile, tensor unit, TensorCore verification, scratchpad, DataFabric, actual synthesis results; reuse validated RTL | [docs/00_AUDIT.md](docs/00_AUDIT.md), `reports/audit/` (TC08 re-run 2/2 + 9/9, byte identity) |
| 2 | `silicaflux_vector_cluster.sv`, `silicaflux_tensor_cluster.sv`, `silicaflux_compute_cluster.sv`; clock/reset, command request / completion, memory request/response, interrupt/error status, performance events | `rtl/`; [docs/01](docs/01_ARCHITECTURE.md), [docs/02](docs/02_INTERFACES.md) §1 |
| 3 | Vector / tensor cluster counts, lanes, PE array, scratchpad capacity, transaction width, optional local memory; minimum chip configuration | [docs/01](docs/01_ARCHITECTURE.md) §4, [docs/03](docs/03_CONFIGURATIONS.md), `config/`, [docs/02](docs/02_INTERFACES.md) §8 |
| 4 | Identifiable hierarchy, `u_vector_0..3` / `u_tensor_0..1`, no coordinates in RTL | [docs/05](docs/05_PHYSICAL.md) §1–2, `reports/synth/compute_hpc/netlist.v.gz` |
| 5 | Command acceptance, busy, completion, errors, reset, clock-enable request, perf events; no duplicated arithmetic | `rtl/sfx_cl_cmd_port.sv`, `rtl/sfx_cl_ctrl.sv`; [docs/01](docs/01_ARCHITECTURE.md) §2 |
| 6 | Locality through hierarchy and constraints | [docs/05](docs/05_PHYSICAL.md) §3–5, `constraints/` |
| 7 | Build targets: one vector cluster, one tensor cluster, full subsystem; cell counts and memory inference | `make synth`, [reports/synth.md](reports/synth.md) |
| 8 | High-fanout signals, wide buses, pipeline boundaries, latency and buffering | [docs/04_TIMING.md](docs/04_TIMING.md) |
| 9 | Single / multiple clusters, simultaneous vector + tensor, SRAM contention, back-pressure, completion routing, cluster reset, error propagation, parameter configurations | [docs/06](docs/06_VERIFICATION.md), [reports/regression.md](reports/regression.md) |
| 10 | Tcl regions / instance groups with actual synthesis names; OpenROAD region constraints and tool-support check | `constraints/`, `physical/`, [docs/05](docs/05_PHYSICAL.md) §5–6, [reports/physical.md](reports/physical.md) |
| 11 | Deliverables | below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_compute_cluster.sv` | `rtl/silicaflux_compute_cluster.sv` (slots, command router, completion merge, CSR decode) |
| `silicaflux_vector_cluster.sv` | `rtl/silicaflux_vector_cluster.sv` |
| `silicaflux_tensor_cluster.sv` | `rtl/silicaflux_tensor_cluster.sv` |
| Cluster shell blocks | `rtl/sfx_cl_cmd_port.sv`, `sfx_cl_mem_port.sv`, `sfx_cl_slv_gate.sv`, `sfx_cl_ctrl.sv`, `sfx_cl_defs.svh` |
| Cluster configuration files | `config/compute_min.json`, `config/compute_hpc.json`, `config/compute_wide.json`; [docs/03](docs/03_CONFIGURATIONS.md) |
| Physical hierarchy constraints | `constraints/compute_{min,hpc}.{groups,regions,subregions}.tcl`; `physical/` (OpenROAD check flow, mock OpenDB) |
| Tests | `tb/tb_cc.sv` (+ `tb_sfb_mem`, `tb_sfb_throttle`, `tb_stream_mon`), `scripts/run_tests.py`, `scripts/run_mutants.py` |
| Actual synthesis reports | [reports/synth.md](reports/synth.md), `reports/synth.json`, `reports/synth/<target>/` (logs, stats, hierarchical netlists, instance and memory lists) |
| Cluster interface documentation | [docs/02_INTERFACES.md](docs/02_INTERFACES.md) (+ docs/01, 04, 05) |
| Reused sources | `third_party/` (byte-identical, `SHA256SUMS`, `PROVENANCE.md`) |

## Quick start

```bash
sudo apt-get install -y verilator iverilog yosys tcl8.6 python3
```

```bash
make test-min       # minimum configuration (1 vector + 1 tensor cluster), every scenario
```

```bash
make lint synth check-physical mutants test report
```

`make help` lists every target. Ubuntu 24.04 packages: Verilator 5.020, Icarus 12, Yosys 0.33, Tcl 8.6; Python ≥ 3.10
standard library only. The 4 V + 2 T testbench needs about 6 GB of RAM per compiler process.
