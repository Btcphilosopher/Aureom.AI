#!/usr/bin/env python3
"""Project 32 ComputeCluster -- independent synthesis targets (Yosys 0.33, technology independent).

Every number in reports/synth.md is parsed from the logs this script writes under reports/synth/<target>/.

Flow per target (hierarchy KEPT, so every replicated region stays a separate instance in the netlist):
  read (rtl/files.f, -DSYNTHESIS) -> hierarchy -check -top T [-chparam ...]
  synth -run coarse:fine        (proc, opt, fsm, wreduce, alumacc, share, memory -nomap)
  write_json coarse.json        (structure + inferred memories, used for the instance / memory reports)
  opt -fast -full; techmap; opt -fast; abc -fast; opt_clean      (generic gates; memories stay $mem_v2)
  check -assert; no latch; stat -top T; write_verilog netlist.v (hierarchical, shipped as netlist.v.gz)
Memories are NOT mapped to flip-flops: each inferred memory stays one $mem_v2 cell (a future SRAM macro) and is
listed with its instance path, width and depth.  Gate counts are Yosys internal cells ($_AND_, $_DFF_P_, ...):
they are NOT standard cells, NOT area, NOT timing.  No silicon area is claimed from this flow.

  python3 syn/run_synth.py                        # all targets
  python3 syn/run_synth.py --targets vector_cluster
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from common import REPORTS, flist, rtl_hash, run, tool_versions, write_json  # noqa: E402

TARGETS = {
    # one vector cluster: minimum-chip engine parameters (4 lanes, 32-bit, 64 KiB scratchpad, 4 banks)
    "vector_cluster": dict(top="silicaflux_vector_cluster", params={}),
    # one tensor cluster: TENSORCORE 08 baseline (4x4 INT8, 2 KiB operand buffers)
    "tensor_cluster": dict(top="silicaflux_tensor_cluster", params={}),
    # minimum chip configuration: u_vector_0 + u_tensor_0
    "compute_min":    dict(top="silicaflux_compute_cluster", params={"NUM_VECTOR_CLUSTERS": 1, "NUM_TENSOR_CLUSTERS": 1}),
    # default HPC configuration: u_vector_0..3 + u_tensor_0..1
    "compute_hpc":    dict(top="silicaflux_compute_cluster", params={}),
}
FF_RE = re.compile(r"^\$_(S?DFFE?|DFFSRE?|ALDFFE?|SDFFCE|DLATCH)\w*$")


def reads() -> str:
    inc, files = flist(ROOT / "rtl/files.f")
    files = [f for f in files if "stubs" not in f]          # ASIC macro black boxes: not used (GENERIC backend)
    return "read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{i}" for i in inc) + " " + " ".join(files)


def yosys(d: Path, name: str, script: str, timeout=14400):
    (d / f"{name}.ys").write_text(script.replace("; ", ";\n") + "\n")
    t0 = time.time()
    rc, out = run(["yosys", "-l", str(d / f"{name}.log"), "-s", str(d / f"{name}.ys")], timeout=timeout)
    (d / f"{name}.stdout.tail").write_text(out[-20000:])
    return rc, round(time.time() - t0, 1)


# ------------------------------------------------------------------ parsing
def parse_stat(log: str) -> dict:
    """Per-module cell-type counts of the LAST 'stat' in a yosys log."""
    i = log.rfind("Printing statistics")
    s = log[i:]
    mods = {}
    for blk in re.split(r"\n=== ", s)[1:]:
        name = blk.split(" ===", 1)[0].strip()
        types = {}
        for m in re.finditer(r"^\s{5}(\S+)\s+(\d+)\s*$", blk, re.M):
            types[m[1]] = int(m[2])
        mods[name] = types
    top_tot = None
    m = re.search(r"design hierarchy ===.*?Number of cells:\s+(\d+)", s, re.S)
    if m:
        top_tot = int(m[1])
    return dict(modules=mods, hierarchy_total=top_tot)


def coarse_info(js: dict):
    """module -> (submodule instances {cellname: type}, memories [(name, width, depth, rd, wr)])."""
    info = {}
    names = set(js["modules"])
    for mname, m in js["modules"].items():
        subs, mems = {}, []
        for cname, c in m.get("cells", {}).items():
            t = c["type"]
            if t == "$mem_v2":
                p = c["parameters"]
                w, n = int(p["WIDTH"], 2), int(p["SIZE"], 2)
                mems.append(dict(cell=cname, memid=p.get("MEMID", ""), width=w, depth=n, bits=w * n,
                                 rd=int(p["RD_PORTS"], 2), wr=int(p["WR_PORTS"], 2)))
            elif t in names:                         # submodule instance (plain or $paramod$...)
                subs[cname] = t
        info[mname] = (subs, mems)
    return info


def clean(n: str) -> str:
    return n[1:] if n.startswith("\\") else n


def totals(stat_mods: dict, info: dict, top: str):
    """Recursive totals per module: cells (gates + memories), flip-flops, memory cells / bits."""
    memo = {}

    def rec(m):
        if m in memo:
            return memo[m]
        own = stat_mods.get(m, {})
        subs = info.get(m, ({}, []))[0]
        sub_types = set(subs.values())
        cells = sum(v for k, v in own.items() if k not in sub_types and k not in ("$mem_v2",))
        ffs = sum(v for k, v in own.items() if FF_RE.match(k))
        mems = list(info.get(m, ({}, []))[1])
        t = dict(cells=cells, ffs=ffs, mem_cells=len(mems), mem_bits=sum(x["bits"] for x in mems))
        for _, st in subs.items():
            r = rec(st)
            for k in t:
                t[k] += r[k]
        memo[m] = t
        return t

    return rec(top), rec


def own(stat_mods: dict, info: dict, m: str) -> dict:
    """Cells of module m itself (generic gates, flip-flops, memories), submodule instances excluded."""
    o = stat_mods.get(m, {})
    subs, mems = info.get(m, ({}, []))
    sub_types = set(subs.values())
    return dict(own_cells=sum(v for k, v in o.items() if k not in sub_types and k != "$mem_v2"),
                own_ffs=sum(v for k, v in o.items() if FF_RE.match(k)),
                own_mems=[dict(cell=clean(x["cell"]), width=x["width"], depth=x["depth"]) for x in mems])


def instance_tree(info: dict, top: str, rec, stat_mods: dict):
    """Every module instance (full depth) with recursive totals and its own cells.  Paths join module levels
    with '/' (OpenROAD's hierarchy divider after linking a hierarchical netlist); a generate scope stays part of
    the instance name ('g_core.u_array'), exactly as Yosys names the cell."""
    rows = []

    def walk(m, path, depth):
        subs = info.get(m, ({}, []))[0]
        for cname, st in sorted(subs.items()):
            p = f"{path}/{clean(cname)}" if path else clean(cname)
            rows.append(dict(path=p, module=clean(st), depth=depth, **rec(st), **own(stat_mods, info, st)))
            walk(st, p, depth + 1)

    walk(top, "", 0)
    return rows


def memory_list(info: dict, top: str):
    out = []

    def walk(m, path):
        subs, mems = info.get(m, ({}, []))
        for x in mems:
            out.append(dict(path=(path + "/" if path else "") + clean(x["cell"]), memid=clean(x["memid"]),
                            width=x["width"], depth=x["depth"], bits=x["bits"], rd_ports=x["rd"], wr_ports=x["wr"]))
        for cname, st in subs.items():
            walk(st, (path + "/" if path else "") + clean(cname))

    walk(top, "")
    return out


# ------------------------------------------------------------------ job
def job(name: str) -> dict:
    t = TARGETS[name]
    d = REPORTS / "synth" / name
    d.mkdir(parents=True, exist_ok=True)
    ch = " ".join(f"-chparam {k} {v}" for k, v in t["params"].items())
    top = t["top"]
    script = (f"{reads()}; hierarchy -check -top {top} {ch}; synth -top {top} -run coarse:fine; "
              f"tee -q -o {d}/coarse_stat.txt stat -top {top}; write_json {d}/coarse.json; "
              f"opt -fast -full; techmap; opt -fast; abc -fast; opt_clean; hierarchy -check; check -assert; "
              f"select -assert-none t:$dlatch t:$_DLATCH_N_ t:$_DLATCH_P_; "
              f"tee -o {d}/stat.txt stat -top {top}; write_verilog -noattr {d}/netlist.v")
    rc, secs = yosys(d, "synth", script)
    res = dict(target=name, top=top, params=t["params"], ok=rc == 0, seconds=secs)
    log = (d / "synth.log").read_text() if (d / "synth.log").exists() else ""
    # the script asserts 'no latch' (select -assert-none) and 'check -assert': a successful run proves both
    res["latch_free"] = rc == 0 and "select -assert-none t:$dlatch" in (d / "synth.ys").read_text()
    res["check_assert"] = rc == 0
    if rc != 0:
        res["error"] = [l for l in log.splitlines() if "ERROR" in l][:5]
        return res
    js = json.loads((d / "coarse.json").read_text())
    info = coarse_info(js)
    st = parse_stat(log)
    # the top module name in stat / json
    topn = [m for m in info if clean(m) == top or (m.startswith("$paramod") and m.endswith("\\" + top))]
    topn = top if top in info else (topn[0] if topn else top)
    tot, rec = totals(st["modules"], info, topn)
    res.update(totals=tot, hierarchy_total_cells=st["hierarchy_total"], modules=len(info))
    tree = instance_tree(info, topn, rec, st["modules"])
    res["top_own"] = own(st["modules"], info, topn)
    mems = memory_list(info, topn)
    write_json(d / "instances.json", tree)
    write_json(d / "memories.json", mems)
    res["memories"] = dict(count=len(mems), bits=sum(m["bits"] for m in mems),
                           shapes=sorted({f"{m['depth']}x{m['width']}" for m in mems}))
    res["top_instances"] = [r for r in tree if r["depth"] == 0]
    # coarse.json is only an intermediate (large): keep a compressed copy of nothing, drop it
    (d / "coarse.json").unlink()
    nl = d / "netlist.v"
    res["netlist_bytes"] = nl.stat().st_size if nl.exists() else 0
    # shipped compressed: netlist.v.gz, synth.log.gz
    import gzip, shutil
    for f in (nl, d / "synth.log"):
        if f.exists():
            with open(f, "rb") as src, gzip.open(str(f) + ".gz", "wb", compresslevel=9) as dst:
                shutil.copyfileobj(src, dst)
            f.unlink()
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--targets", default=",".join(TARGETS))
    ap.add_argument("--jobs", type=int, default=2)
    a = ap.parse_args()
    names = [n for n in a.targets.split(",") if n]
    out = dict(tools=tool_versions(), results={})
    old = REPORTS / "synth.json"
    if old.exists():
        try:
            out["results"] = json.loads(old.read_text()).get("results", {})
        except Exception:
            pass
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for n, r in zip(names, ex.map(job, names)):
            out["results"][n] = r
            t = r.get("totals", {})
            print(f"{n}: {'OK' if r['ok'] else 'FAILED'} {r['seconds']} s  cells {t.get('cells')}  ffs {t.get('ffs')}  "
                  f"memories {r.get('memories', {}).get('count')} ({r.get('memories', {}).get('bits')} bits)", flush=True)
    out["tools"] = tool_versions()
    out["rtl_hash"] = rtl_hash()
    write_json(REPORTS / "synth.json", out)
    return 0 if all(r["ok"] for r in out["results"].values()) else 1


if __name__ == "__main__":
    sys.exit(main())
