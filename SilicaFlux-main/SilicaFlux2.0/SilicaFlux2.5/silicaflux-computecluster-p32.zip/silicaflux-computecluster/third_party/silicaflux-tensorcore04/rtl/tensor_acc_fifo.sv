// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tensor_acc_fifo.sv
//  Small synchronous flop FIFO (first-word-fall-through).
//  push when full or pop when empty is a caller bug (credit discipline makes
//  both impossible inside tensor_accumulator); a simulation check reports it.
// =============================================================================
`timescale 1ns/1ps
module tensor_acc_fifo #(
    parameter int WIDTH = 8,
    parameter int DEPTH = 4,
    parameter int CW    = $clog2(DEPTH + 1)
) (
    input  logic             clk,
    input  logic             rst_n,
    input  logic             push,
    input  logic [WIDTH-1:0] din,
    input  logic             pop,
    output logic [WIDTH-1:0] dout,
    output logic             empty,
    output logic [CW-1:0]    count
);
    localparam int PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;

    logic [WIDTH-1:0] mem [DEPTH];
    logic [PW-1:0]    rd_q, wr_q;
    logic [CW-1:0]    cnt_q;

    function automatic logic [PW-1:0] inc(input logic [PW-1:0] p);
        if (32'(p) == DEPTH - 1) inc = '0;
        else                     inc = p + PW'(1);
    endfunction

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            rd_q  <= '0;
            wr_q  <= '0;
            cnt_q <= '0;
        end else begin
            if (push) begin
                mem[wr_q] <= din;
                wr_q      <= inc(wr_q);
            end
            if (pop) rd_q <= inc(rd_q);
            cnt_q <= cnt_q + CW'(push) - CW'(pop);
        end
    end

    assign dout  = mem[rd_q];
    assign empty = (cnt_q == '0);
    assign count = cnt_q;

    // synthesis translate_off
`ifndef TA_NO_INVARIANTS
    always @(posedge clk) begin
        if (rst_n === 1'b1) begin
            if (push && !pop && 32'(cnt_q) == DEPTH) $error("%m: push into full FIFO");
            if (pop && cnt_q == '0)                  $error("%m: pop from empty FIFO");
        end
    end
`endif
    // synthesis translate_on
endmodule
