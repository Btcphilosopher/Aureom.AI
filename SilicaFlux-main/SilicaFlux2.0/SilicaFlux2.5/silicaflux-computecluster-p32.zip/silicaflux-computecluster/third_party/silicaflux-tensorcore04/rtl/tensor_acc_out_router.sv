// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tensor_acc_out_router.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  Routes each committed result beat to any subset of three consumers:
//      bit 0  output SRAM writer     (raw exact INT32 / OUT_W lanes)
//      bit 1  quantisation engine    (o_wide: exact ACC_W lanes)
//      bit 2  DMA path               (raw exact INT32 / OUT_W lanes)
//  The destination set is per tile (cfg_dest), so raw INT32 results are never
//  forced through requantisation.
//
//  EAGER FORK.  A beat is offered to every selected port at once; each port
//  takes it independently; the beat retires (in_ready) when every selected
//  port has taken it.  Ports that already took the beat see valid = 0, so no
//  consumer ever receives a beat twice.  out_valid never depends on any
//  out_ready (AXI-stream rule), and the shared payload is held stable until
//  the beat retires (it comes straight from the accumulator's output FIFO
//  head, which only advances on in_ready).
// =============================================================================
`timescale 1ns/1ps
module tensor_acc_out_router (
    input  logic       clk,
    input  logic       rst_n,
    input  logic       in_valid,
    output logic       in_ready,
    input  logic [2:0] in_dest,
    output logic [2:0] out_valid,     // {dma, quant, sram}
    input  logic [2:0] out_ready
);
    logic [2:0] done_q, need, take, fin;

    assign need      = in_dest & ~done_q;
    assign out_valid = {3{in_valid}} & need;
    assign take      = out_valid & out_ready;
    assign fin       = ~in_dest | done_q | take;   // per port: nothing left to deliver
    assign in_ready  = in_valid & (&fin);

    always_ff @(posedge clk) begin
        if (!rst_n)        done_q <= '0;
        else if (in_ready) done_q <= '0;
        else if (in_valid) done_q <= done_q | take;
    end
endmodule
