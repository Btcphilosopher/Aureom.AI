// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tensor_acc_subsystem.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  Integration wrapper:  tensor_accumulator  +  tensor_acc_storage (reference
//  1R1W storage, DEPTH = NUM_TILES*ROWS entries)  +  tensor_acc_out_router
//  (SRAM / quantiser / DMA).  Connects directly to the TENSORCORE 02 array
//  readout:  m_valid->ps_valid, ps_ready->m_ready, m_row->ps_row,
//  m_data->ps_data, m_col_mask->ps_col_mask, m_last->ps_last; the K-chunk
//  sequencer supplies ps_slot / ps_tag / ps_chunk / ps_chunk_k.
//
//  st_rd_block / st_wr_block inject storage-port contention (tie to 0 when
//  the storage is private to the accumulator).
// =============================================================================
`timescale 1ns/1ps
module tensor_acc_subsystem #(
    parameter int ROWS         = 4,
    parameter int COLS         = 4,
    parameter int DATA_W       = 8,
    parameter int PSUM_W       = 32,
    parameter int ACC_W        = 32,
    parameter int OUT_W        = 32,
    parameter int BIAS_W       = 32,
    parameter int NUM_TILES    = 2,
    parameter int TAG_W        = 16,
    parameter int CHUNK_W      = 16,
    parameter int KC_W         = 17,
    parameter int KTOT_W       = 40,
    parameter int RD_LAT       = 1,
    parameter int OVF_POLICY   = 0,
    parameter int STRICT_RANGE = 1,
    parameter int PSUM_GUARD   = 1,
    parameter int OFIFO_DEPTH  = 4,
    parameter int HFIFO_DEPTH  = 4,
    parameter int PERF_EN      = 1,
    parameter int PERF_W       = 40,
    // ---------------- derived: never override ----------------
    parameter int SLOT_W = (NUM_TILES > 1) ? $clog2(NUM_TILES) : 1,
    parameter int RIDW   = (ROWS > 1) ? $clog2(ROWS) : 1,
    parameter int MW     = $clog2(ROWS + 1),
    parameter int NW     = $clog2(COLS + 1),
    parameter int AW     = (NUM_TILES * ROWS > 1) ? $clog2(NUM_TILES * ROWS) : 1,
    parameter int EW     = COLS * (ACC_W + 1),
    parameter int EVW    = $clog2(COLS + 1),
    parameter int NPERF  = tensor_acc_pkg::NPERF
) (
    input  logic                       clk,
    input  logic                       rst_n,
    // tile configuration
    input  logic                       cfg_valid,
    output logic                       cfg_ready,
    input  logic [SLOT_W-1:0]          cfg_slot,
    input  logic [TAG_W-1:0]           cfg_tag,
    input  logic [MW-1:0]              cfg_m,
    input  logic [NW-1:0]              cfg_n,
    input  logic [KTOT_W-1:0]          cfg_k_total,
    input  logic [CHUNK_W-1:0]         cfg_n_chunks,
    input  logic                       cfg_bias_en,
    input  logic [COLS*BIAS_W-1:0]     cfg_bias,
    input  logic [2:0]                 cfg_dest,
    output logic                       cfg_reject,
    output logic [2:0]                 cfg_reject_code,
    // partial sums
    input  logic                       ps_valid,
    output logic                       ps_ready,
    input  logic [SLOT_W-1:0]          ps_slot,
    input  logic [TAG_W-1:0]           ps_tag,
    input  logic [CHUNK_W-1:0]         ps_chunk,
    input  logic [KC_W-1:0]            ps_chunk_k,
    input  logic [RIDW-1:0]            ps_row,
    input  logic [COLS*PSUM_W-1:0]     ps_data,
    input  logic [COLS-1:0]            ps_col_mask,
    input  logic                       ps_last,
    // host port
    input  logic                       hc_valid,
    output logic                       hc_ready,
    input  logic [1:0]                 hc_op,
    input  logic [SLOT_W-1:0]          hc_slot,
    input  logic [RIDW-1:0]            hc_row,
    input  logic [COLS*ACC_W-1:0]      hc_wdata,
    output logic                       hr_valid,
    input  logic                       hr_ready,
    output logic [2:0]                 hr_status,
    output logic [COLS*ACC_W-1:0]      hr_data,
    output logic [COLS-1:0]            hr_ovf,
    output logic                       hr_vld,
    output logic [CHUNK_W-1:0]         hr_nchunk,
    output logic [KTOT_W-1:0]          hr_kacc,
    // storage contention
    input  logic                       st_rd_block,
    input  logic                       st_wr_block,
    // result ports (shared payload, one valid/ready per destination)
    output logic                       osram_valid,
    input  logic                       osram_ready,
    output logic                       oquant_valid,
    input  logic                       oquant_ready,
    output logic                       odma_valid,
    input  logic                       odma_ready,
    output logic [TAG_W-1:0]           o_tag,
    output logic [SLOT_W-1:0]          o_slot,
    output logic [RIDW-1:0]            o_row,
    output logic                       o_last,
    output logic [COLS-1:0]            o_col_mask,
    output logic [COLS*ACC_W-1:0]      o_wide,
    output logic [COLS*OUT_W-1:0]      o_data,
    output logic [COLS-1:0]            o_ovf,
    output logic [COLS-1:0]            o_clip,
    output logic                       o_err,
    // completion / status
    output logic                       cmt_done,
    output logic [SLOT_W-1:0]          cmt_slot,
    output logic [TAG_W-1:0]           cmt_tag,
    output logic                       cmt_ovf,
    output logic                       cmt_clip,
    output logic                       cmt_err,
    output logic [NUM_TILES*2-1:0]     slot_state,
    output logic                       idle,
    output logic                       err_pulse,
    output logic [2:0]                 err_code,
    output logic [7:0]                 err_sticky,
    // performance
    input  logic                       perf_clr,
    output logic [NPERF*EVW-1:0]       ev_inc,
    output logic [NPERF*PERF_W-1:0]    perf_o,
    // storage interface (observability)
    output logic                       st_en,
    output logic                       st_rd_req,
    output logic                       st_rd_ready,
    output logic                       st_wr_req,
    output logic                       st_wr_ready
);

    logic [AW-1:0] st_rd_addr, st_wr_addr;
    logic [EW-1:0] st_rd_data, st_wr_data;
    logic          o_valid, o_ready;
    logic [2:0]    o_dest;

    tensor_accumulator #(
        .ROWS(ROWS), .COLS(COLS), .DATA_W(DATA_W), .PSUM_W(PSUM_W), .ACC_W(ACC_W),
        .OUT_W(OUT_W), .BIAS_W(BIAS_W), .NUM_TILES(NUM_TILES), .TAG_W(TAG_W),
        .CHUNK_W(CHUNK_W), .KC_W(KC_W), .KTOT_W(KTOT_W), .RD_LAT(RD_LAT),
        .OVF_POLICY(OVF_POLICY), .STRICT_RANGE(STRICT_RANGE), .PSUM_GUARD(PSUM_GUARD),
        .OFIFO_DEPTH(OFIFO_DEPTH), .HFIFO_DEPTH(HFIFO_DEPTH), .PERF_EN(PERF_EN), .PERF_W(PERF_W)
    ) u_acc (
        .clk, .rst_n,
        .cfg_valid, .cfg_ready, .cfg_slot, .cfg_tag, .cfg_m, .cfg_n, .cfg_k_total,
        .cfg_n_chunks, .cfg_bias_en, .cfg_bias, .cfg_dest, .cfg_reject, .cfg_reject_code,
        .ps_valid, .ps_ready, .ps_slot, .ps_tag, .ps_chunk, .ps_chunk_k, .ps_row,
        .ps_data, .ps_col_mask, .ps_last,
        .hc_valid, .hc_ready, .hc_op, .hc_slot, .hc_row, .hc_wdata,
        .hr_valid, .hr_ready, .hr_status, .hr_data, .hr_ovf, .hr_vld, .hr_nchunk, .hr_kacc,
        .st_en, .st_rd_req, .st_rd_addr, .st_rd_ready, .st_rd_data,
        .st_wr_req, .st_wr_addr, .st_wr_data, .st_wr_ready,
        .o_valid, .o_ready, .o_dest, .o_tag, .o_slot, .o_row, .o_last, .o_col_mask,
        .o_wide, .o_data, .o_ovf, .o_clip, .o_err,
        .cmt_done, .cmt_slot, .cmt_tag, .cmt_ovf, .cmt_clip, .cmt_err,
        .slot_state, .idle, .err_pulse, .err_code, .err_sticky,
        .perf_clr, .ev_inc, .perf_o
    );

    tensor_acc_storage #(.DEPTH(NUM_TILES*ROWS), .WIDTH(EW), .RD_LAT(RD_LAT)) u_store (
        .clk, .rst_n, .en(st_en),
        .rd_req(st_rd_req), .rd_addr(st_rd_addr), .rd_ready(st_rd_ready), .rd_data(st_rd_data),
        .wr_req(st_wr_req), .wr_addr(st_wr_addr), .wr_data(st_wr_data), .wr_ready(st_wr_ready),
        .rd_block(st_rd_block), .wr_block(st_wr_block)
    );

    logic [2:0] ov;
    tensor_acc_out_router u_route (
        .clk, .rst_n, .in_valid(o_valid), .in_ready(o_ready), .in_dest(o_dest),
        .out_valid(ov), .out_ready({odma_ready, oquant_ready, osram_ready})
    );
    assign osram_valid  = ov[tensor_acc_pkg::DEST_SRAM];
    assign oquant_valid = ov[tensor_acc_pkg::DEST_QUANT];
    assign odma_valid   = ov[tensor_acc_pkg::DEST_DMA];

endmodule
