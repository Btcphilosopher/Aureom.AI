// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tensor_acc_pkg.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  Shared encodings for the tensor partial-sum accumulator subsystem.
//  Plain localparams and constant functions only, so the package elaborates
//  identically in Icarus Verilog 12, Verilator 5 and Yosys 0.33 (Yosys 0.33
//  rejects `return` in functions; assignment-to-function-name is used).
//  Importers use scoped references (tensor_acc_pkg::X), never `import` in a
//  module header (also rejected by Yosys 0.33).
// =============================================================================
`ifndef TENSOR_ACC_PKG_SV
`define TENSOR_ACC_PKG_SV
`timescale 1ns/1ps

package tensor_acc_pkg;

    /* verilator lint_off UNUSEDPARAM */

    // ------------------------------------------------------------------
    // Arithmetic contract (parameter OVF_POLICY)
    //   SATURATE : an add whose exact result leaves the ACC_W range clamps
    //              to ACC_MAX / ACC_MIN in the direction of the exact sum.
    //   WRAP     : the low ACC_W bits of the exact sum are kept (modulo
    //              2^ACC_W).  Only meaningful when explicitly selected.
    //   In BOTH policies the per-lane sticky overflow bit is set and an
    //   overflow event is emitted: nothing overflows silently.
    // ------------------------------------------------------------------
    localparam int OVF_SATURATE = 0;
    localparam int OVF_WRAP     = 1;

    // ------------------------------------------------------------------
    // Slot (output tile storage) states
    // ------------------------------------------------------------------
    localparam logic [1:0] ST_FREE   = 2'd0;   // no tile; cfg may open it
    localparam logic [1:0] ST_ACCUM  = 2'd1;   // tile open, K chunks arriving
    localparam logic [1:0] ST_COMMIT = 2'd2;   // every element complete; rows draining

    // ------------------------------------------------------------------
    // Host / sequencer storage operations (hc_op)
    // ------------------------------------------------------------------
    localparam logic [1:0] HC_READ  = 2'd0;    // read entry value + ovf + metadata
    localparam logic [1:0] HC_WRITE = 2'd1;    // preload an entry (only before chunk 0 lands)
    localparam logic [1:0] HC_CLEAR = 2'd2;    // logically clear one row (restart its K reduction)
    localparam logic [1:0] HC_ABORT = 2'd3;    // drop an open tile, free its slot

    // host response status (hr_status)
    localparam logic [2:0] HS_OK        = 3'd0;
    localparam logic [2:0] HS_ERR_SLOT  = 3'd1;   // slot out of range / wrong state
    localparam logic [2:0] HS_ERR_ROW   = 3'd2;   // row >= tile M
    localparam logic [2:0] HS_ERR_ORDER = 3'd3;   // WRITE after a chunk already landed

    // ------------------------------------------------------------------
    // Partial-sum protocol error codes (err_code).  A beat with an error is
    // DROPPED: it never contributes to any accumulator.
    // ------------------------------------------------------------------
    localparam logic [2:0] PE_NONE      = 3'd0;
    localparam logic [2:0] PE_NO_TILE   = 3'd1;   // slot out of range, slot FREE, or tag mismatch
    localparam logic [2:0] PE_ROW       = 3'd2;   // row >= tile M
    localparam logic [2:0] PE_MASK      = 3'd3;   // col mask / last flag inconsistent with tile
    localparam logic [2:0] PE_CHUNK_K   = 3'd4;   // chunk_k == 0 or chunk_k > PSUM_KMAX
    localparam logic [2:0] PE_ORDER     = 3'd5;   // chunk skipped ahead, or chunk >= n_chunks
    localparam logic [2:0] PE_K_OVERRUN = 3'd6;   // K bookkeeping would exceed / miss k_total
    localparam logic [2:0] PE_RANGE     = 3'd7;   // psum value unreachable for chunk_k INT products

    // ------------------------------------------------------------------
    // cfg reject codes (cfg_reject_code)
    // ------------------------------------------------------------------
    localparam logic [2:0] CR_OK     = 3'd0;
    localparam logic [2:0] CR_SLOT   = 3'd1;   // cfg_slot >= NUM_TILES
    localparam logic [2:0] CR_DIM    = 3'd2;   // M or N outside 1..ROWS / 1..COLS
    localparam logic [2:0] CR_CHUNKS = 3'd3;   // n_chunks == 0 or n_chunks > k_total
    localparam logic [2:0] CR_DEST   = 3'd4;   // no destination selected
    localparam logic [2:0] CR_RANGE  = 3'd5;   // k_total (+bias) can overflow ACC_W (STRICT_RANGE)

    // ------------------------------------------------------------------
    // Output destinations (cfg_dest / o_dest bit index)
    // ------------------------------------------------------------------
    localparam int DEST_SRAM  = 0;
    localparam int DEST_QUANT = 1;
    localparam int DEST_DMA   = 2;

    // ------------------------------------------------------------------
    // Internal pipeline op types
    // ------------------------------------------------------------------
    localparam logic [2:0] OP_NONE   = 3'd0;
    localparam logic [2:0] OP_ADD    = 3'd1;   // partial-sum add (writes storage)
    localparam logic [2:0] OP_HREAD  = 3'd2;   // host read (response)
    localparam logic [2:0] OP_HWRITE = 3'd3;   // host preload (writes storage, response)
    localparam logic [2:0] OP_HMETA  = 3'd4;   // host clear/abort/error (response only)
    localparam logic [2:0] OP_CREAD  = 3'd5;   // commit read (output beat)

    // ------------------------------------------------------------------
    // Performance event / counter indices.  ev_inc[i*EVW +: EVW] is the
    // per-cycle increment of event i; perf_o[i*PERF_W +: PERF_W] its
    // saturating counter.  See docs/PERF_EVENTS.md for exact definitions.
    // ------------------------------------------------------------------
    localparam int PF_PSUM_BEATS   = 0;   // partial-sum beats accepted (handshakes)
    localparam int PF_PSUM_ELEMS   = 1;   // partial-sum elements actually added
    localparam int PF_PSUM_DUP     = 2;   // replayed beats dropped (already applied)
    localparam int PF_PSUM_ERR     = 3;   // malformed beats dropped
    localparam int PF_RD_STALL     = 4;   // accumulator read stalls
    localparam int PF_WR_STALL     = 5;   // accumulator write stalls
    localparam int PF_OVF_ACC      = 6;   // element adds that overflowed ACC_W
    localparam int PF_OVF_OUT      = 7;   // committed elements clipped when narrowed to OUT_W
    localparam int PF_COMMIT_ELEMS = 8;   // output elements committed
    localparam int PF_COMMIT_TILES = 9;   // output tiles committed
    localparam int PF_CHUNKS       = 10;  // K chunks completed (all rows of a tile)
    localparam int PF_IN_STALL     = 11;  // ps_valid & ~ps_ready cycles
    localparam int PF_OUT_STALL    = 12;  // o_valid & ~o_ready cycles
    localparam int PF_CFG_REJECT   = 13;  // tile configurations rejected
    localparam int PF_HOST_OPS     = 14;  // host operations accepted
    localparam int PF_BUSY         = 15;  // cycles with work in the pipeline / FIFOs
    localparam int NPERF           = 16;

    // ------------------------------------------------------------------
    // max_exact_k(acc_w, dw)
    //   Largest K such that EVERY sum of K products of two signed dw-bit
    //   operands, starting from zero, fits a signed acc_w-bit register.
    //   Binding term: the positive extreme (-2^(dw-1))^2 = 2^(2dw-2).
    //     K * 2^(2dw-2) <= 2^(acc_w-1) - 1  <=>  K <= 2^(acc_w-2dw+1) - 1
    //   INT8: acc 32 -> 131 071, 40 -> 33 554 431, 48 -> 8 589 934 591.
    //   Saturates at 2^64-1 when the bound exceeds 64 bits.
    // ------------------------------------------------------------------
    function automatic logic [63:0] max_exact_k(input int unsigned acc_w,
                                                input int unsigned dw);
        int unsigned sh;
        sh = 0;
        if (acc_w < 2 * dw) begin
            max_exact_k = 64'd0;
        end else begin
            sh = acc_w - 2 * dw + 1;
            if (sh >= 64) max_exact_k = {64{1'b1}};
            else          max_exact_k = (64'd1 << sh) - 64'd1;
        end
    endfunction

    /* verilator lint_on UNUSEDPARAM */

endpackage

`endif // TENSOR_ACC_PKG_SV
