// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tensor_accumulator.sv          (PRIMARY SOURCE)
//  Tensor partial-sum and accumulator engine
//  Aureom.AI | SilicaFlux-HPC
//
//  C[m,n] = bias[n] + sum_k A[m,k] * B[k,n]     for K far larger than one
//  operand-buffer load, computed as a sequence of K CHUNKS on the
//  TENSORCORE 02 output-stationary systolic array.
//
//  ---------------------------------------------------------------------------
//  WHAT THE ARRAY ALREADY DOES (audit, docs/AUDIT.md)
//    Each TC02 PE owns an ACC_WIDTH (32) accumulator that is ZEROED by the
//    one-cycle CLEAR state at every launch.  One launch therefore computes
//    exactly one chunk's partial sum  P_c[m,n] = sum_{k in chunk c} A*B  and
//    streams it out one row per beat (m_valid/m_ready, m_row, m_data,
//    m_col_mask, m_last).  The array never carries a sum across launches.
//
//  WHAT THIS MODULE ADDS
//    A persistent per-element accumulator outside the array:
//        acc[m,n] = (bias[n] + P_0[m,n]) + P_1[m,n] + ... + P_{C-1}[m,n]
//    Each P_c row is added EXACTLY ONCE.  There is no second accumulation of
//    the same products: the PE accumulator holds only the current chunk, this
//    module holds only completed chunks, and a per-row chunk sequence number
//    makes a replayed chunk (array restarted, chunk re-run) a no-op.
//
//  ---------------------------------------------------------------------------
//  K-CHUNK PROTOCOL (per output tile, docs/ARCHITECTURE.md section 2)
//    1. cfg handshake opens tile slot `cfg_slot` with {tag, M, N, k_total,
//       n_chunks, bias, dest}.  All of its rows become "not initialised".
//    2. The sequencer runs chunk c (c = 0 .. n_chunks-1) on the array.
//    3. The array's readout beats arrive on ps_* with sideband
//       {slot, tag, chunk = c, chunk_k = K of this chunk}.
//    4. Per row r the beat is
//          applied  if c == nch[r]  (the next chunk this row expects)
//          dropped  if c <  nch[r]  (replay of an already-added chunk)
//          an error if c >  nch[r]  (a chunk was skipped)  -> dropped, flagged
//    5. FIRST CHUNK INITIALISES DIRECTLY: when nch[r] == 0 the add uses base
//       0 (or a host preload) instead of reading storage, so no clear pass
//       and no read of stale storage is ever needed.  The tile bias is
//       folded into this same initialising add: bias is applied once per
//       element, BEFORE/WITH the first K chunk, never per chunk.
//    6. When every active row has applied n_chunks chunks (and therefore
//       exactly k_total K-steps, checked) the tile enters COMMIT and its rows
//       are read out to the SRAM / quantiser / DMA ports.  Nothing is
//       committed earlier: the commit trigger is the per-row chunk count,
//       and commit reads are ordered behind every in-flight add (forwarding).
//
//  ---------------------------------------------------------------------------
//  NUMERIC CONTRACT (docs/NUMERIC_RANGE.md)
//    * Products: signed DATA_W x DATA_W; |product| <= 2^(2*DATA_W-2) (16384).
//    * Partial sums arrive as signed PSUM_W (array ACC_WIDTH = 32); a chunk
//      may hold at most PSUM_KMAX = 2^(PSUM_W-2*DATA_W+1)-1 K-steps (131 071)
//      or the array itself could have wrapped -> beat rejected (PE_CHUNK_K).
//    * Persistent accumulator: signed ACC_W (32 baseline; 40/48 for longer K).
//    * STRICT_RANGE = 1: a tile is accepted only if NO input data can
//      overflow ACC_W:   bias[n] + k_total*16384 <= ACC_MAX  and
//                        bias[n] - k_total*16256 >= ACC_MIN   for every n.
//      Without bias, ACC_W = 32 -> k_total <= 131 071 (the brief's bound).
//    * Every add is computed exactly in ACC_W+2 bits; leaving the ACC_W range
//      sets the lane's sticky ovf bit and an overflow event, and the value
//      follows OVF_POLICY (saturate, default, or explicitly selected wrap).
//    * Output lanes: o_wide = exact ACC_W value; o_data = OUT_W value (INT32
//      baseline).  If ACC_W > OUT_W and the value does not fit, o_clip is set
//      and o_data is saturated/wrapped per OVF_POLICY.  Raw INT32 is the
//      default; requantisation is never forced.
//
//  ---------------------------------------------------------------------------
//  PIPELINE AND HAZARDS (docs/ARCHITECTURE.md section 4)
//    A  : arbitrate (commit > host > psum), check, update row metadata,
//         issue storage read if the row holds a value.
//    P1..P_RD_LAT : storage read latency; P_RD_LAT is the execute stage X.
//    X  : base = youngest in-flight write to the same entry (forwarding from W
//         and RD_LAT history registers) else storage data; exact add; policy.
//    W  : storage write; push commit beat / host response into FIFO.
//    RAW: an entry written by an op issued d <= RD_LAT+1 enabled cycles
//         earlier is not yet in storage when the younger op reads it; the
//         forwarding network covers exactly those d, so back-to-back adds to
//         one entry (M = 1 tiles, multiple chunks) run at full rate.
//    Backpressure: output/host FIFOs are credit-reserved at issue, so the
//         pipeline never stalls on them.  A busy storage READ port inserts a
//         bubble at A (read stall).  A busy WRITE port freezes the whole
//         pipeline including the storage read registers (write stall).
//    Metadata (valid, chunk count, K count, tile state) is updated at A, so
//         every younger op sees the effect of every older op immediately.
//    Reset: synchronous; clears every slot, metadata, FIFO and counter.
//         Storage contents are not needed after reset (all rows invalid).
// =============================================================================
`timescale 1ns/1ps
module tensor_accumulator #(
    parameter int ROWS         = 4,     // output tile rows    (= array ROWS)
    parameter int COLS         = 4,     // output tile columns (= array COLS)
    parameter int DATA_W       = 8,     // operand width of the producing array (range analysis)
    parameter int PSUM_W       = 32,    // partial-sum lane width from the array
    parameter int ACC_W        = 32,    // persistent accumulator width
    parameter int OUT_W        = 32,    // narrowed output lane width (INT32 baseline)
    parameter int BIAS_W       = 32,    // bias width (INT32)
    parameter int NUM_TILES    = 2,     // output tile slots held in storage
    parameter int TAG_W        = 16,    // tile tag (identifies a tile; stale-beat filter)
    parameter int CHUNK_W      = 16,    // chunk index / count width
    parameter int KC_W         = 17,    // K width of one chunk (= array K_WIDTH)
    parameter int KTOT_W       = 40,    // total-K width
    parameter int RD_LAT       = 1,     // storage read latency, 1..3
    parameter int OVF_POLICY   = 0,     // tensor_acc_pkg::OVF_SATURATE / OVF_WRAP
    parameter int STRICT_RANGE = 1,     // 1: reject tiles whose K (+bias) could overflow
    parameter int PSUM_GUARD   = 1,     // 1: reject psums unreachable for chunk_k products
    parameter int OFIFO_DEPTH  = 4,     // commit beat FIFO
    parameter int HFIFO_DEPTH  = 4,     // host response FIFO
    parameter int PERF_EN      = 1,     // 1: saturating performance counters
    parameter int PERF_W       = 40,
    // ---------------- derived: never override ----------------
    parameter int SLOT_W = (NUM_TILES > 1) ? $clog2(NUM_TILES) : 1,
    parameter int RIDW   = (ROWS > 1) ? $clog2(ROWS) : 1,
    parameter int MW     = $clog2(ROWS + 1),
    parameter int NW     = $clog2(COLS + 1),
    parameter int AW     = (NUM_TILES * ROWS > 1) ? $clog2(NUM_TILES * ROWS) : 1,
    parameter int EW     = COLS * (ACC_W + 1),
    parameter int EVW    = $clog2(COLS + 1),
    parameter int NPERF  = tensor_acc_pkg::NPERF
) (
    input  logic                       clk,
    input  logic                       rst_n,          // synchronous, active low

    // ------------------------------------------------ tile configuration
    input  logic                       cfg_valid,
    output logic                       cfg_ready,
    input  logic [SLOT_W-1:0]          cfg_slot,
    input  logic [TAG_W-1:0]           cfg_tag,
    input  logic [MW-1:0]              cfg_m,          // 1..ROWS
    input  logic [NW-1:0]              cfg_n,          // 1..COLS
    input  logic [KTOT_W-1:0]          cfg_k_total,    // total reduction length
    input  logic [CHUNK_W-1:0]         cfg_n_chunks,   // number of K chunks, 1..k_total
    input  logic                       cfg_bias_en,
    input  logic [COLS*BIAS_W-1:0]     cfg_bias,       // bias[n], lane n
    input  logic [2:0]                 cfg_dest,       // {dma, quant, sram}
    output logic                       cfg_reject,     // 1-cycle pulse after an illegal cfg was consumed
    output logic [2:0]                 cfg_reject_code,

    // ------------------------------------------------ partial sums (array readout)
    input  logic                       ps_valid,
    output logic                       ps_ready,
    input  logic [SLOT_W-1:0]          ps_slot,
    input  logic [TAG_W-1:0]           ps_tag,
    input  logic [CHUNK_W-1:0]         ps_chunk,       // chunk index c
    input  logic [KC_W-1:0]            ps_chunk_k,     // K-steps in chunk c
    input  logic [RIDW-1:0]            ps_row,         // = array m_row
    input  logic [COLS*PSUM_W-1:0]     ps_data,        // = array m_data
    input  logic [COLS-1:0]            ps_col_mask,    // = array m_col_mask
    input  logic                       ps_last,        // = array m_last

    // ------------------------------------------------ host / sequencer storage port
    input  logic                       hc_valid,
    output logic                       hc_ready,
    input  logic [1:0]                 hc_op,          // tensor_acc_pkg::HC_*
    input  logic [SLOT_W-1:0]          hc_slot,
    input  logic [RIDW-1:0]            hc_row,
    input  logic [COLS*ACC_W-1:0]      hc_wdata,
    output logic                       hr_valid,
    input  logic                       hr_ready,
    output logic [2:0]                 hr_status,
    output logic [COLS*ACC_W-1:0]      hr_data,
    output logic [COLS-1:0]            hr_ovf,
    output logic                       hr_vld,
    output logic [CHUNK_W-1:0]         hr_nchunk,
    output logic [KTOT_W-1:0]          hr_kacc,

    // ------------------------------------------------ accumulator storage interface
    output logic                       st_en,
    output logic                       st_rd_req,
    output logic [AW-1:0]              st_rd_addr,
    input  logic                       st_rd_ready,
    input  logic [EW-1:0]              st_rd_data,
    output logic                       st_wr_req,
    output logic [AW-1:0]              st_wr_addr,
    output logic [EW-1:0]              st_wr_data,
    input  logic                       st_wr_ready,

    // ------------------------------------------------ committed results
    output logic                       o_valid,
    input  logic                       o_ready,
    output logic [2:0]                 o_dest,
    output logic [TAG_W-1:0]           o_tag,
    output logic [SLOT_W-1:0]          o_slot,
    output logic [RIDW-1:0]            o_row,
    output logic                       o_last,
    output logic [COLS-1:0]            o_col_mask,
    output logic [COLS*ACC_W-1:0]      o_wide,         // exact ACC_W values
    output logic [COLS*OUT_W-1:0]      o_data,         // OUT_W values
    output logic [COLS-1:0]            o_ovf,          // accumulation overflowed (value inexact)
    output logic [COLS-1:0]            o_clip,         // o_data narrowed out of range
    output logic                       o_err,          // a malformed beat was rejected on this tile

    // ------------------------------------------------ tile completion / status
    output logic                       cmt_done,       // pulse: last row of a tile delivered
    output logic [SLOT_W-1:0]          cmt_slot,
    output logic [TAG_W-1:0]           cmt_tag,
    output logic                       cmt_ovf,
    output logic                       cmt_clip,
    output logic                       cmt_err,
    output logic [NUM_TILES*2-1:0]     slot_state,
    output logic                       idle,
    output logic                       err_pulse,      // pulse: psum beat dropped as malformed
    output logic [2:0]                 err_code,
    output logic [7:0]                 err_sticky,     // bit c: error code c seen since reset

    // ------------------------------------------------ performance
    input  logic                       perf_clr,
    output logic [NPERF*EVW-1:0]       ev_inc,
    output logic [NPERF*PERF_W-1:0]    perf_o
);

    // =========================================================================
    // constants and elaboration checks
    // =========================================================================
    localparam int  NENT = NUM_TILES * ROWS;
    localparam int  LW   = ACC_W + 1;             // stored lane {ovf, value}
    localparam int  PW   = ACC_W + 1;             // payload lane (psum + bias)
    localparam int  SW   = ACC_W + 2;             // exact sum lane
    localparam bit  SAT  = (OVF_POLICY == tensor_acc_pkg::OVF_SATURATE);
    localparam int  PSH  = 2 * DATA_W - 2;        // positive extreme product = 2^PSH
    localparam int  NSH  = DATA_W - 1;            // negative extreme magnitude = 2^PSH - 2^NSH
    localparam logic [63:0] PSUM_KMAX = tensor_acc_pkg::max_exact_k(PSUM_W, DATA_W);

    // synthesis translate_off
    initial begin
        if (ROWS < 1 || COLS < 1 || COLS > 64)  $fatal(1, "tensor_accumulator: need 1 <= ROWS, 1 <= COLS <= 64");
        if (NUM_TILES < 1)                      $fatal(1, "tensor_accumulator: NUM_TILES must be >= 1");
        if (DATA_W < 2)                         $fatal(1, "tensor_accumulator: DATA_W must be >= 2");
        if (PSUM_W < 2 * DATA_W)                $fatal(1, "tensor_accumulator: PSUM_W must be >= 2*DATA_W");
        if (ACC_W < PSUM_W)                     $fatal(1, "tensor_accumulator: ACC_W must be >= PSUM_W");
        if (BIAS_W > ACC_W || BIAS_W < 1)       $fatal(1, "tensor_accumulator: need 1 <= BIAS_W <= ACC_W");
        if (OUT_W > ACC_W || OUT_W < 2)         $fatal(1, "tensor_accumulator: need 2 <= OUT_W <= ACC_W");
        if (KC_W > KTOT_W || KC_W < 1)          $fatal(1, "tensor_accumulator: need 1 <= KC_W <= KTOT_W");
        if (CHUNK_W < 1 || TAG_W < 1)           $fatal(1, "tensor_accumulator: CHUNK_W, TAG_W must be >= 1");
        if (RD_LAT < 1 || RD_LAT > 3)           $fatal(1, "tensor_accumulator: RD_LAT must be 1..3");
        if (OVF_POLICY != 0 && OVF_POLICY != 1) $fatal(1, "tensor_accumulator: OVF_POLICY must be 0 or 1");
        if (OFIFO_DEPTH < 1 || HFIFO_DEPTH < 1) $fatal(1, "tensor_accumulator: FIFO depths must be >= 1");
        if (SLOT_W != ((NUM_TILES > 1) ? $clog2(NUM_TILES) : 1) ||
            RIDW   != ((ROWS > 1) ? $clog2(ROWS) : 1) ||
            MW     != $clog2(ROWS + 1) || NW != $clog2(COLS + 1) ||
            AW     != ((NENT > 1) ? $clog2(NENT) : 1) ||
            EW     != COLS * (ACC_W + 1) || EVW != $clog2(COLS + 1) ||
            NPERF  != tensor_acc_pkg::NPERF)
            $fatal(1, "tensor_accumulator: derived parameters must not be overridden");
    end
    // synthesis translate_on

    function automatic logic [EVW-1:0] b2e(input logic b);
        b2e = '0;
        b2e[0] = b;
    endfunction

    function automatic logic [EVW-1:0] popc(input logic [COLS-1:0] v);
        popc = '0;
        for (int i = 0; i < COLS; i++) popc = popc + EVW'(v[i]);
    endfunction

    // =========================================================================
    // pipeline record (A -> P1 .. P_RD_LAT(=X) -> W).  Flat packed vector.
    // =========================================================================
    localparam int F_VLD   = 0;
    localparam int F_TYP   = F_VLD   + 1;
    localparam int F_ADDR  = F_TYP   + 3;
    localparam int F_SLOT  = F_ADDR  + AW;
    localparam int F_ROW   = F_SLOT  + SLOT_W;
    localparam int F_USERD = F_ROW   + RIDW;
    localparam int F_WR    = F_USERD + 1;
    localparam int F_LAST  = F_WR    + 1;
    localparam int F_ERR   = F_LAST  + 1;
    localparam int F_TAG   = F_ERR   + 1;
    localparam int F_DEST  = F_TAG   + TAG_W;
    localparam int F_CMASK = F_DEST  + 3;
    localparam int F_HST   = F_CMASK + COLS;
    localparam int F_HVLD  = F_HST   + 3;
    localparam int F_HNCH  = F_HVLD  + 1;
    localparam int F_HKACC = F_HNCH  + CHUNK_W;
    localparam int F_PAY   = F_HKACC + KTOT_W;       // first payload bit (= width of the meta part)
    localparam int RECW    = F_PAY   + COLS * PW;

    // =========================================================================
    // slot (tile) registers and per-row metadata
    // =========================================================================
    logic [NUM_TILES*2-1:0]           s_state_q;
    logic [NUM_TILES*TAG_W-1:0]       s_tag_q;
    logic [NUM_TILES*MW-1:0]          s_m_q;
    logic [NUM_TILES*COLS-1:0]        s_cmask_q;
    logic [NUM_TILES*KTOT_W-1:0]      s_ktot_q;
    logic [NUM_TILES*CHUNK_W-1:0]     s_nchunks_q;
    logic [NUM_TILES-1:0]             s_bias_en_q;
    logic [NUM_TILES*COLS*BIAS_W-1:0] s_bias_q;
    logic [NUM_TILES*3-1:0]           s_dest_q;
    logic [NUM_TILES*CHUNK_W-1:0]     s_cdone_q;       // chunks complete on ALL active rows
    logic [NUM_TILES-1:0]             s_err_q;

    logic [NENT-1:0]                  e_vld_q;         // entry holds a value for the current tile
    logic [NENT*CHUNK_W-1:0]          e_nch_q;         // chunks applied to this row
    logic [NENT*KTOT_W-1:0]           e_kacc_q;        // K-steps applied to this row

    // A-stage update requests (at most one op issues per cycle)
    logic                  a_meta_we;
    logic [AW-1:0]         a_meta_idx;
    logic                  a_meta_vld_d;
    logic [CHUNK_W-1:0]    a_meta_nch_d;
    logic [KTOT_W-1:0]     a_meta_kacc_d;
    logic                  a_cdone_we;
    logic [SLOT_W-1:0]     a_cdone_slot;
    logic [CHUNK_W-1:0]    a_cdone_d;
    logic                  a_state_we;
    logic [SLOT_W-1:0]     a_state_slot;
    logic [1:0]            a_state_d;
    logic                  a_serr_we;
    logic [SLOT_W-1:0]     a_serr_slot;

    // =========================================================================
    // configuration
    // =========================================================================
    localparam int RW0 = (KTOT_W + 2 * DATA_W > ACC_W + 1) ? KTOT_W + 2 * DATA_W : ACC_W + 1;
    localparam int RW  = RW0 + 2;
    localparam logic signed [RW-1:0] R_ACC_MAX = {{(RW-ACC_W+1){1'b0}}, {(ACC_W-1){1'b1}}};
    localparam logic signed [RW-1:0] R_ACC_MIN = {{(RW-ACC_W+1){1'b1}}, {(ACC_W-1){1'b0}}};

    logic             cfg_soob, cfg_legal, cfg_go, cfg_range_ok;
    logic [2:0]       cfg_code;
    logic [COLS-1:0]  cfg_cmask, cfg_col_ok;
    logic signed [RW-1:0] cfg_kp_max, cfg_kp_minmag;

    /* verilator lint_off CMPCONST */
    /* verilator lint_off UNSIGNED */
    assign cfg_soob = (32'(cfg_slot) >= NUM_TILES);
    /* verilator lint_on UNSIGNED */
    /* verilator lint_on CMPCONST */
    assign cfg_ready = cfg_soob ? 1'b1 : (s_state_q[32'(cfg_slot)*2 +: 2] == tensor_acc_pkg::ST_FREE);

    assign cfg_kp_max    = $signed(RW'(cfg_k_total) << PSH);
    assign cfg_kp_minmag = $signed((RW'(cfg_k_total) << PSH) - (RW'(cfg_k_total) << NSH));

    genvar gj;
    generate
        for (gj = 0; gj < COLS; gj++) begin : g_cfg_col
            logic signed [RW-1:0] bterm, hi, lo;
            assign cfg_cmask[gj] = (32'(cfg_n) > gj);
            assign bterm = cfg_bias_en ? RW'($signed(cfg_bias[gj*BIAS_W +: BIAS_W])) : '0;
            assign hi    = bterm + cfg_kp_max;
            assign lo    = bterm - cfg_kp_minmag;
            assign cfg_col_ok[gj] = ~cfg_cmask[gj] | ((hi <= R_ACC_MAX) & (lo >= R_ACC_MIN));
        end
    endgenerate
    assign cfg_range_ok = (STRICT_RANGE == 0) | (&cfg_col_ok);

    always_comb begin
        cfg_code = tensor_acc_pkg::CR_OK;
        /* verilator lint_off CMPCONST */
        if (cfg_soob)                                                      cfg_code = tensor_acc_pkg::CR_SLOT;
        else if (cfg_m == '0 || 32'(cfg_m) > ROWS || cfg_n == '0 || 32'(cfg_n) > COLS)
                                                                           cfg_code = tensor_acc_pkg::CR_DIM;
        /* verilator lint_on CMPCONST */
        else if (cfg_n_chunks == '0 || KTOT_W'(cfg_n_chunks) > cfg_k_total) cfg_code = tensor_acc_pkg::CR_CHUNKS;
        else if (cfg_dest == 3'b000)                                       cfg_code = tensor_acc_pkg::CR_DEST;
        else if (!cfg_range_ok)                                            cfg_code = tensor_acc_pkg::CR_RANGE;
    end
    assign cfg_legal = (cfg_code == tensor_acc_pkg::CR_OK);
    assign cfg_go    = cfg_valid & cfg_ready & cfg_legal;

    logic       cfg_rej_q;
    logic [2:0] cfg_rej_code_q;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            cfg_rej_q      <= 1'b0;
            cfg_rej_code_q <= '0;
        end else begin
            cfg_rej_q      <= cfg_valid & cfg_ready & ~cfg_legal;
            cfg_rej_code_q <= (cfg_valid & cfg_ready & ~cfg_legal) ? cfg_code : '0;
        end
    end
    assign cfg_reject      = cfg_rej_q;
    assign cfg_reject_code = cfg_rej_code_q;

    // =========================================================================
    // slot registers (one generate block per slot; decoded write enables)
    // =========================================================================
    genvar gs, ge;
    generate
        for (gs = 0; gs < NUM_TILES; gs++) begin : g_slot
            logic [1:0]             st_r;
            logic [TAG_W-1:0]       tag_r;
            logic [MW-1:0]          m_r;
            logic [COLS-1:0]        cmask_r;
            logic [KTOT_W-1:0]      ktot_r;
            logic [CHUNK_W-1:0]     nchunks_r, cdone_r;
            logic                   bias_en_r, err_r;
            logic [COLS*BIAS_W-1:0] bias_r;
            logic [2:0]             dest_r;
            logic                   sel_cfg;
            assign sel_cfg = cfg_go & (32'(cfg_slot) == gs);

            always_ff @(posedge clk) begin
                if (!rst_n) begin
                    st_r <= tensor_acc_pkg::ST_FREE;
                    tag_r <= '0; m_r <= '0; cmask_r <= '0; ktot_r <= '0; nchunks_r <= '0;
                    cdone_r <= '0; bias_en_r <= 1'b0; err_r <= 1'b0; bias_r <= '0; dest_r <= '0;
                end else if (sel_cfg) begin
                    st_r      <= tensor_acc_pkg::ST_ACCUM;
                    tag_r     <= cfg_tag;
                    m_r       <= cfg_m;
                    cmask_r   <= cfg_cmask;
                    ktot_r    <= cfg_k_total;
                    nchunks_r <= cfg_n_chunks;
                    bias_en_r <= cfg_bias_en;
                    bias_r    <= cfg_bias;
                    dest_r    <= cfg_dest;
                    cdone_r   <= '0;
                    err_r     <= 1'b0;
                end else begin
                    if (a_state_we && 32'(a_state_slot) == gs) st_r    <= a_state_d;
                    if (a_cdone_we && 32'(a_cdone_slot) == gs) cdone_r <= a_cdone_d;
                    if (a_serr_we  && 32'(a_serr_slot)  == gs) err_r   <= 1'b1;
                end
            end

            assign s_state_q  [gs*2 +: 2]                 = st_r;
            assign s_tag_q    [gs*TAG_W +: TAG_W]         = tag_r;
            assign s_m_q      [gs*MW +: MW]               = m_r;
            assign s_cmask_q  [gs*COLS +: COLS]           = cmask_r;
            assign s_ktot_q   [gs*KTOT_W +: KTOT_W]       = ktot_r;
            assign s_nchunks_q[gs*CHUNK_W +: CHUNK_W]     = nchunks_r;
            assign s_cdone_q  [gs*CHUNK_W +: CHUNK_W]     = cdone_r;
            assign s_bias_en_q[gs]                        = bias_en_r;
            assign s_bias_q   [gs*COLS*BIAS_W +: COLS*BIAS_W] = bias_r;
            assign s_dest_q   [gs*3 +: 3]                 = dest_r;
            assign s_err_q    [gs]                        = err_r;
        end

        for (ge = 0; ge < NENT; ge++) begin : g_ent
            localparam int ES = ge / ROWS;
            logic                vld_r;
            logic [CHUNK_W-1:0]  nch_r;
            logic [KTOT_W-1:0]   kacc_r;
            always_ff @(posedge clk) begin
                if (!rst_n) begin
                    vld_r <= 1'b0; nch_r <= '0; kacc_r <= '0;
                end else if (cfg_go && 32'(cfg_slot) == ES) begin
                    vld_r <= 1'b0; nch_r <= '0; kacc_r <= '0;      // tile open: rows not initialised
                end else if (a_meta_we && 32'(a_meta_idx) == ge) begin
                    vld_r <= a_meta_vld_d; nch_r <= a_meta_nch_d; kacc_r <= a_meta_kacc_d;
                end
            end
            assign e_vld_q [ge]                       = vld_r;
            assign e_nch_q [ge*CHUNK_W +: CHUNK_W]    = nch_r;
            assign e_kacc_q[ge*KTOT_W +: KTOT_W]      = kacc_r;
        end
    endgenerate

    assign slot_state = s_state_q;

    // =========================================================================
    // pipeline control, credits, arbitration
    // =========================================================================
    logic                 pipe_en, issue_ok;
    logic                 w_vld, w_wr;
    logic [2:0]           w_typ;
    logic [AW-1:0]        w_addr;
    logic [EW-1:0]        w_entry;
    logic [F_PAY-1:0]     w_meta;

    assign pipe_en  = ~(w_vld & w_wr & ~st_wr_ready);    // write port busy -> freeze everything
    assign issue_ok = pipe_en & st_rd_ready;             // every issue needs the read port slot

    localparam int OCW = $clog2(OFIFO_DEPTH + RD_LAT + 3);
    localparam int HCW = $clog2(HFIFO_DEPTH + RD_LAT + 3);
    logic [OCW-1:0] o_infl_q;
    logic [HCW-1:0] h_infl_q;
    logic [$clog2(OFIFO_DEPTH+1)-1:0] ofifo_cnt;
    logic [$clog2(HFIFO_DEPTH+1)-1:0] hfifo_cnt;
    logic o_credit_ok, h_credit_ok;
    assign o_credit_ok = (32'(o_infl_q) + 32'(ofifo_cnt)) < OFIFO_DEPTH;
    assign h_credit_ok = (32'(h_infl_q) + 32'(hfifo_cnt)) < HFIFO_DEPTH;

    // commit engine: finishes one tile before starting another (contiguous beats)
    logic                 cm_active_q;
    logic [SLOT_W-1:0]    cm_slot_q;
    logic [RIDW-1:0]      cm_row_q;
    logic                 cm_any;
    logic [SLOT_W-1:0]    cm_first, cm_sel;
    always_comb begin
        cm_any   = 1'b0;
        cm_first = '0;
        for (int s = NUM_TILES - 1; s >= 0; s--) begin
            if (s_state_q[s*2 +: 2] == tensor_acc_pkg::ST_COMMIT) begin
                cm_any   = 1'b1;
                cm_first = SLOT_W'(s);
            end
        end
    end
    assign cm_sel = cm_active_q ? cm_slot_q : cm_first;

    logic cm_req, hc_req, cm_fire, hc_fire, ps_fire;
    assign cm_req   = (cm_active_q | cm_any) & o_credit_ok;
    assign hc_req   = hc_valid & h_credit_ok;
    assign cm_fire  = issue_ok & cm_req;
    assign hc_ready = issue_ok & ~cm_req & h_credit_ok;
    assign hc_fire  = hc_valid & hc_ready;
    assign ps_ready = issue_ok & ~cm_req & ~hc_req;
    assign ps_fire  = ps_valid & ps_ready;

    // =========================================================================
    // A stage: partial-sum checks
    // =========================================================================
    logic                 ps_soob, ps_rowoob, ps_tagok, ps_dup, ps_apply, ps_chunk_done;
    logic [SLOT_W-1:0]    ps_si;
    logic [1:0]           ps_st;
    logic [MW-1:0]        ps_m;
    logic [AW-1:0]        ps_idx;
    logic                 ps_evld;
    logic [CHUNK_W-1:0]   ps_nch, ps_nchunks, ps_cdone;
    logic [KTOT_W-1:0]    ps_kacc, ps_ktot;
    logic [KTOT_W:0]      ps_kacc_new;
    logic [COLS-1:0]      ps_cmask_t, ps_lane_ok;
    logic [ROWS-1:0]      ps_other_ok;
    logic [2:0]           ps_code;
    logic                 ps_bias_first;
    logic [COLS*PW-1:0]   ps_pay;

    /* verilator lint_off CMPCONST */
    /* verilator lint_off UNSIGNED */
    assign ps_soob   = (32'(ps_slot) >= NUM_TILES);
    /* verilator lint_on UNSIGNED */
    /* verilator lint_on CMPCONST */
    assign ps_si      = ps_soob ? '0 : ps_slot;
    assign ps_st      = s_state_q  [32'(ps_si)*2 +: 2];
    assign ps_m       = s_m_q      [32'(ps_si)*MW +: MW];
    assign ps_tagok   = (ps_tag == s_tag_q[32'(ps_si)*TAG_W +: TAG_W]);
    assign ps_cmask_t = s_cmask_q  [32'(ps_si)*COLS +: COLS];
    assign ps_ktot    = s_ktot_q   [32'(ps_si)*KTOT_W +: KTOT_W];
    assign ps_nchunks = s_nchunks_q[32'(ps_si)*CHUNK_W +: CHUNK_W];
    assign ps_cdone   = s_cdone_q  [32'(ps_si)*CHUNK_W +: CHUNK_W];
    assign ps_rowoob  = (32'(ps_row) >= 32'(ps_m));
    assign ps_idx     = AW'(32'(ps_si) * ROWS + (ps_rowoob ? 0 : 32'(ps_row)));
    assign ps_evld    = e_vld_q [ps_idx];
    assign ps_nch     = e_nch_q [32'(ps_idx)*CHUNK_W +: CHUNK_W];
    assign ps_kacc    = e_kacc_q[32'(ps_idx)*KTOT_W +: KTOT_W];
    assign ps_kacc_new = {1'b0, ps_kacc} + (KTOT_W+1)'(ps_chunk_k);

    // chunk completion: every OTHER active row of the tile is already past ps_nch
    generate
        for (genvar gr = 0; gr < ROWS; gr++) begin : g_oth
            assign ps_other_ok[gr] = (32'(ps_row) == gr) || (32'(ps_m) <= gr) ||
                (e_nch_q[(32'(ps_si)*ROWS + gr)*CHUNK_W +: CHUNK_W] > ps_nch);
        end
    endgenerate

    // psum range guard: a chunk of chunk_k products lies in
    //   [ -chunk_k*(2^PSH - 2^NSH) , chunk_k*2^PSH ]
    localparam int GW0 = (KC_W + 2 * DATA_W > PSUM_W) ? KC_W + 2 * DATA_W : PSUM_W;
    localparam int GW  = GW0 + 2;
    logic signed [GW-1:0] g_kmax, g_kminmag;
    assign g_kmax    = $signed(GW'(ps_chunk_k) << PSH);
    assign g_kminmag = $signed((GW'(ps_chunk_k) << PSH) - (GW'(ps_chunk_k) << NSH));

    assign ps_bias_first = (ps_nch == '0) & s_bias_en_q[ps_si];

    generate
        for (gj = 0; gj < COLS; gj++) begin : g_ps_lane
            logic signed [GW-1:0] pv;
            logic signed [PW-1:0] pterm, bterm;
            assign pv = GW'($signed(ps_data[gj*PSUM_W +: PSUM_W]));
            assign ps_lane_ok[gj] = (PSUM_GUARD == 0) | ~ps_cmask_t[gj] |
                                    ((pv <= g_kmax) & (pv >= -g_kminmag));
            assign pterm = PW'($signed(ps_data[gj*PSUM_W +: PSUM_W]));
            assign bterm = ps_bias_first ?
                           PW'($signed(s_bias_q[(32'(ps_si)*COLS + gj)*BIAS_W +: BIAS_W])) : '0;
            assign ps_pay[gj*PW +: PW] = ps_cmask_t[gj] ? (pterm + bterm) : '0;
        end
    endgenerate

    always_comb begin
        ps_code = tensor_acc_pkg::PE_NONE;
        ps_dup  = 1'b0;
        if (ps_soob || ps_st == tensor_acc_pkg::ST_FREE || !ps_tagok)
            ps_code = tensor_acc_pkg::PE_NO_TILE;
        else if (ps_rowoob)
            ps_code = tensor_acc_pkg::PE_ROW;
        else if (ps_col_mask != ps_cmask_t || ps_last != (32'(ps_row) == 32'(ps_m) - 1))
            ps_code = tensor_acc_pkg::PE_MASK;
        // (vacuous when KC_W cannot exceed PSUM_KMAX, e.g. the default 17 / 32-bit pairing)
        /* verilator lint_off CMPCONST */
        else if (ps_chunk_k == '0 || 64'(ps_chunk_k) > PSUM_KMAX)
            ps_code = tensor_acc_pkg::PE_CHUNK_K;
        /* verilator lint_on CMPCONST */
        else if (ps_chunk < ps_nch)
            ps_dup  = 1'b1;                                          // replay: already applied
        else if (ps_chunk != ps_nch || ps_chunk >= ps_nchunks)
            ps_code = tensor_acc_pkg::PE_ORDER;
        else if (ps_kacc_new > (KTOT_W+1)'(ps_ktot) ||
                 (ps_chunk == ps_nchunks - CHUNK_W'(1) && ps_kacc_new != (KTOT_W+1)'(ps_ktot)))
            ps_code = tensor_acc_pkg::PE_K_OVERRUN;
        else if (!(&ps_lane_ok))
            ps_code = tensor_acc_pkg::PE_RANGE;
    end
    assign ps_apply      = (ps_code == tensor_acc_pkg::PE_NONE) & ~ps_dup;
    assign ps_chunk_done = (ps_nch == ps_cdone) & (&ps_other_ok);

    // =========================================================================
    // A stage: host checks
    // =========================================================================
    logic                 hc_soob, hc_rowoob;
    logic [SLOT_W-1:0]    hc_si;
    logic [1:0]           hc_st;
    logic [AW-1:0]        hc_idx;
    logic                 hc_evld;
    logic [CHUNK_W-1:0]   hc_nch;
    logic [KTOT_W-1:0]    hc_kacc;
    logic [COLS-1:0]      hc_cmask_t;
    logic [2:0]           hc_stat;
    logic                 hc_meta_ok;
    logic [COLS*PW-1:0]   hc_pay;

    /* verilator lint_off CMPCONST */
    /* verilator lint_off UNSIGNED */
    assign hc_soob    = (32'(hc_slot) >= NUM_TILES);
    /* verilator lint_on UNSIGNED */
    /* verilator lint_on CMPCONST */
    assign hc_si      = hc_soob ? '0 : hc_slot;
    assign hc_st      = s_state_q[32'(hc_si)*2 +: 2];
    assign hc_rowoob  = (32'(hc_row) >= 32'(s_m_q[32'(hc_si)*MW +: MW]));
    assign hc_idx     = AW'(32'(hc_si) * ROWS + (hc_rowoob ? 0 : 32'(hc_row)));
    assign hc_evld    = e_vld_q [hc_idx];
    assign hc_nch     = e_nch_q [32'(hc_idx)*CHUNK_W +: CHUNK_W];
    assign hc_kacc    = e_kacc_q[32'(hc_idx)*KTOT_W +: KTOT_W];
    assign hc_cmask_t = s_cmask_q[32'(hc_si)*COLS +: COLS];

    generate
        for (gj = 0; gj < COLS; gj++) begin : g_hc_lane
            assign hc_pay[gj*PW +: PW] = hc_cmask_t[gj] ? PW'($signed(hc_wdata[gj*ACC_W +: ACC_W])) : '0;
        end
    endgenerate

    always_comb begin
        hc_stat = tensor_acc_pkg::HS_OK;
        case (hc_op)
            tensor_acc_pkg::HC_READ:
                if (hc_soob || hc_st == tensor_acc_pkg::ST_FREE)  hc_stat = tensor_acc_pkg::HS_ERR_SLOT;
                else if (hc_rowoob)                               hc_stat = tensor_acc_pkg::HS_ERR_ROW;
            tensor_acc_pkg::HC_WRITE:
                if (hc_soob || hc_st != tensor_acc_pkg::ST_ACCUM) hc_stat = tensor_acc_pkg::HS_ERR_SLOT;
                else if (hc_rowoob)                               hc_stat = tensor_acc_pkg::HS_ERR_ROW;
                else if (hc_nch != '0)                            hc_stat = tensor_acc_pkg::HS_ERR_ORDER;
            tensor_acc_pkg::HC_CLEAR:
                if (hc_soob || hc_st != tensor_acc_pkg::ST_ACCUM) hc_stat = tensor_acc_pkg::HS_ERR_SLOT;
                else if (hc_rowoob)                               hc_stat = tensor_acc_pkg::HS_ERR_ROW;
            default: // HC_ABORT
                if (hc_soob || hc_st != tensor_acc_pkg::ST_ACCUM) hc_stat = tensor_acc_pkg::HS_ERR_SLOT;
        endcase
    end

    assign hc_meta_ok = (hc_stat == tensor_acc_pkg::HS_OK) & (hc_op != tensor_acc_pkg::HC_ABORT);

    // =========================================================================
    // A stage: commit lookups
    // =========================================================================
    logic [AW-1:0]        cm_idx;
    logic [MW-1:0]        cm_m;
    logic                 cm_last;
    assign cm_m    = s_m_q[32'(cm_sel)*MW +: MW];
    assign cm_idx  = AW'(32'(cm_sel) * ROWS + 32'(cm_row_q));
    assign cm_last = (32'(cm_row_q) == 32'(cm_m) - 1);

    // =========================================================================
    // A stage: op selection, record build, metadata updates
    // =========================================================================
    logic [RECW-1:0] a_rec;
    logic            a_vld, a_userd;
    logic            ev_chunk_c, ev_apply_c;

    always_comb begin
        a_rec         = '0;
        a_vld         = 1'b0;
        a_userd       = 1'b0;
        a_meta_we     = 1'b0;
        a_meta_idx    = '0;
        a_meta_vld_d  = 1'b0;
        a_meta_nch_d  = '0;
        a_meta_kacc_d = '0;
        a_cdone_we    = 1'b0;
        a_cdone_slot  = '0;
        a_cdone_d     = '0;
        a_state_we    = 1'b0;
        a_state_slot  = '0;
        a_state_d     = tensor_acc_pkg::ST_FREE;
        a_serr_we     = 1'b0;
        a_serr_slot   = '0;
        ev_chunk_c    = 1'b0;
        ev_apply_c    = 1'b0;

        if (cm_fire) begin
            // ---------------- commit read of one complete row
            a_vld   = 1'b1;
            a_userd = 1'b1;          // nch == n_chunks >= 1, so the row holds a value
            a_rec[F_TYP +: 3]        = tensor_acc_pkg::OP_CREAD;
            a_rec[F_ADDR +: AW]      = cm_idx;
            a_rec[F_SLOT +: SLOT_W]  = cm_sel;
            a_rec[F_ROW +: RIDW]     = cm_row_q;
            a_rec[F_LAST]            = cm_last;
            a_rec[F_ERR]             = s_err_q[cm_sel] |
                                       (e_kacc_q[32'(cm_idx)*KTOT_W +: KTOT_W] != s_ktot_q[32'(cm_sel)*KTOT_W +: KTOT_W]);
            a_rec[F_TAG +: TAG_W]    = s_tag_q[32'(cm_sel)*TAG_W +: TAG_W];
            a_rec[F_DEST +: 3]       = s_dest_q[32'(cm_sel)*3 +: 3];
            a_rec[F_CMASK +: COLS]   = s_cmask_q[32'(cm_sel)*COLS +: COLS];
            if (cm_last) begin
                a_state_we   = 1'b1;
                a_state_slot = cm_sel;
                a_state_d    = tensor_acc_pkg::ST_FREE;   // storage no longer needed
            end
        end else if (hc_fire) begin
            // ---------------- host operation (always produces one response)
            a_vld = 1'b1;
            a_rec[F_ADDR +: AW]       = hc_idx;
            a_rec[F_SLOT +: SLOT_W]   = hc_si;
            a_rec[F_ROW +: RIDW]      = hc_row;
            a_rec[F_HST +: 3]         = hc_stat;
            // pre-op row metadata is reported only for legal row ops (READ/WRITE/CLEAR);
            // ABORT is a slot op and error responses carry zeros
            a_rec[F_HVLD]             = hc_meta_ok ? hc_evld : 1'b0;
            a_rec[F_HNCH +: CHUNK_W]  = hc_meta_ok ? hc_nch  : '0;
            a_rec[F_HKACC +: KTOT_W]  = hc_meta_ok ? hc_kacc : '0;
            a_rec[F_TYP +: 3]         = tensor_acc_pkg::OP_HMETA;
            if (hc_stat == tensor_acc_pkg::HS_OK) begin
                case (hc_op)
                    tensor_acc_pkg::HC_READ: begin
                        a_rec[F_TYP +: 3] = tensor_acc_pkg::OP_HREAD;
                        a_userd           = hc_evld;     // invalid row reads as 0
                    end
                    tensor_acc_pkg::HC_WRITE: begin
                        a_rec[F_TYP +: 3]     = tensor_acc_pkg::OP_HWRITE;
                        a_rec[F_WR]           = 1'b1;
                        a_rec[F_PAY +: COLS*PW] = hc_pay;
                        a_meta_we     = 1'b1;
                        a_meta_idx    = hc_idx;
                        a_meta_vld_d  = 1'b1;
                        a_meta_nch_d  = hc_nch;
                        a_meta_kacc_d = hc_kacc;
                    end
                    tensor_acc_pkg::HC_CLEAR: begin
                        a_meta_we     = 1'b1;
                        a_meta_idx    = hc_idx;
                        a_cdone_we    = 1'b1;          // this row restarts from chunk 0
                        a_cdone_slot  = hc_si;
                        a_cdone_d     = '0;
                    end
                    default: begin                     // HC_ABORT
                        a_state_we    = 1'b1;
                        a_state_slot  = hc_si;
                        a_state_d     = tensor_acc_pkg::ST_FREE;
                    end
                endcase
            end
        end else if (ps_fire) begin
            // ---------------- partial-sum beat
            if (ps_code != tensor_acc_pkg::PE_NONE && ps_code != tensor_acc_pkg::PE_NO_TILE) begin
                a_serr_we   = 1'b1;
                a_serr_slot = ps_si;
            end
            if (ps_apply) begin
                ev_apply_c = 1'b1;
                a_vld   = 1'b1;
                a_userd = ps_evld;      // first chunk with no preload: base 0, no read
                a_rec[F_TYP +: 3]       = tensor_acc_pkg::OP_ADD;
                a_rec[F_ADDR +: AW]     = ps_idx;
                a_rec[F_SLOT +: SLOT_W] = ps_si;
                a_rec[F_ROW +: RIDW]    = ps_row;
                a_rec[F_WR]             = 1'b1;
                a_rec[F_CMASK +: COLS]  = ps_cmask_t;
                a_rec[F_PAY +: COLS*PW] = ps_pay;
                a_meta_we     = 1'b1;
                a_meta_idx    = ps_idx;
                a_meta_vld_d  = 1'b1;
                a_meta_nch_d  = ps_nch + CHUNK_W'(1);
                a_meta_kacc_d = ps_kacc_new[KTOT_W-1:0];
                if (ps_chunk_done) begin
                    ev_chunk_c   = 1'b1;
                    a_cdone_we   = 1'b1;
                    a_cdone_slot = ps_si;
                    a_cdone_d    = ps_nch + CHUNK_W'(1);
                    if (ps_nch + CHUNK_W'(1) == ps_nchunks) begin
                        a_state_we   = 1'b1;           // every element has all K contributions
                        a_state_slot = ps_si;
                        a_state_d    = tensor_acc_pkg::ST_COMMIT;
                    end
                end
            end
        end
        a_rec[F_VLD]   = a_vld;
        a_rec[F_USERD] = a_userd;
    end

    assign st_rd_req  = a_vld & a_userd;   // a_vld implies issue_ok
    assign st_rd_addr = a_rec[F_ADDR +: AW];

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            cm_active_q <= 1'b0;
            cm_slot_q   <= '0;
            cm_row_q    <= '0;
        end else if (cm_fire) begin
            if (cm_last) begin
                cm_active_q <= 1'b0;
                cm_row_q    <= '0;
            end else begin
                cm_active_q <= 1'b1;
                cm_slot_q   <= cm_sel;
                cm_row_q    <= cm_row_q + RIDW'(1);
            end
        end
    end

    // =========================================================================
    // P stages (storage read latency); X = last P stage
    // =========================================================================
    logic [RD_LAT*RECW-1:0] p_q;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            p_q <= '0;
        end else if (pipe_en) begin
            p_q[0 +: RECW] <= a_rec;
            for (int s = 1; s < RD_LAT; s++) p_q[s*RECW +: RECW] <= p_q[(s-1)*RECW +: RECW];
        end
    end

    logic [RECW-1:0]  x_rec;
    logic             x_vld, x_userd, x_wr;
    logic [2:0]       x_typ;
    logic [AW-1:0]    x_addr;
    logic [COLS-1:0]  x_cmask;
    assign x_rec   = p_q[(RD_LAT-1)*RECW +: RECW];
    assign x_vld   = x_rec[F_VLD];
    assign x_typ   = x_rec[F_TYP +: 3];
    assign x_addr  = x_rec[F_ADDR +: AW];
    assign x_userd = x_rec[F_USERD];
    assign x_wr    = x_rec[F_WR];
    assign x_cmask = x_rec[F_CMASK +: COLS];

    // ---------------------------------------------------- forwarding network
    //  W holds the op issued 1 enabled cycle before X's op; h[i] the op issued
    //  i+2 cycles before.  An op issued d <= RD_LAT+1 cycles earlier has not
    //  reached storage when X's op read it; d >= RD_LAT+2 has.  Youngest wins.
    logic [RD_LAT-1:0]      h_vld;
    logic [RD_LAT*AW-1:0]   h_addr;
    logic [RD_LAT*EW-1:0]   h_entry;
    logic [EW-1:0]          x_base;
    /* verilator lint_off UNUSEDSIGNAL */
    logic                   x_hit;    // coverage probe: base came from forwarding (read by the TB)
    /* verilator lint_on UNUSEDSIGNAL */

    always_comb begin
        x_base = st_rd_data;
        x_hit  = 1'b0;
        for (int i = RD_LAT - 1; i >= 0; i--) begin
            if (h_vld[i] && h_addr[i*AW +: AW] == x_addr) begin
                x_base = h_entry[i*EW +: EW];
                x_hit  = 1'b1;
            end
        end
        if (w_vld && w_wr && w_addr == x_addr) begin
            x_base = w_entry;
            x_hit  = 1'b1;
        end
        if (!x_userd) begin
            x_base = '0;
            x_hit  = 1'b0;
        end
    end

    // ---------------------------------------------------- exact add + policy
    logic [EW-1:0]    x_entry;
    logic [COLS-1:0]  x_ovf_now;
    generate
        for (gj = 0; gj < COLS; gj++) begin : g_x_lane
            logic signed [ACC_W-1:0] bv, res;
            logic                    bo, of;
            logic signed [PW-1:0]    pay;
            logic signed [SW-1:0]    sum;
            assign bv  = $signed(x_base[gj*LW +: ACC_W]);
            assign bo  = x_base[gj*LW + ACC_W];
            assign pay = $signed(x_rec[F_PAY + gj*PW +: PW]);
            assign sum = SW'(bv) + SW'(pay);
            // representable in ACC_W bits iff the top three bits of the exact sum agree
            assign of  = ~((&sum[SW-1:ACC_W-1]) | ~(|sum[SW-1:ACC_W-1]));
            always_comb begin
                if (of && SAT) res = sum[SW-1] ? {1'b1, {(ACC_W-1){1'b0}}} : {1'b0, {(ACC_W-1){1'b1}}};
                else           res = sum[ACC_W-1:0];
            end
            assign x_entry[gj*LW +: LW] = {bo | of, res};
            assign x_ovf_now[gj]        = of;
        end
    endgenerate

    // =========================================================================
    // W stage + write-history
    // =========================================================================
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            w_vld   <= 1'b0;
            w_wr    <= 1'b0;
            w_typ   <= tensor_acc_pkg::OP_NONE;
            w_addr  <= '0;
            w_entry <= '0;
            w_meta  <= '0;
            h_vld   <= '0;
            h_addr  <= '0;
            h_entry <= '0;
        end else if (pipe_en) begin
            w_vld   <= x_vld;
            w_wr    <= x_vld & x_wr;
            w_typ   <= x_typ;
            w_addr  <= x_addr;
            w_entry <= x_entry;
            w_meta  <= x_rec[F_PAY-1:0];
            h_vld[0]          <= w_vld & w_wr;
            h_addr[0 +: AW]   <= w_addr;
            h_entry[0 +: EW]  <= w_entry;
            for (int i = 1; i < RD_LAT; i++) begin
                h_vld[i]              <= h_vld[i-1];
                h_addr[i*AW +: AW]    <= h_addr[(i-1)*AW +: AW];
                h_entry[i*EW +: EW]   <= h_entry[(i-1)*EW +: EW];
            end
        end
    end

    assign st_en      = pipe_en;
    assign st_wr_req  = w_vld & w_wr;
    assign st_wr_addr = w_addr;
    assign st_wr_data = w_entry;

    // =========================================================================
    // output (commit) FIFO and host response FIFO
    // =========================================================================
    localparam int OFW = 3 + TAG_W + SLOT_W + RIDW + 1 + COLS + 1 + EW;
    localparam int HFW = 3 + 1 + CHUNK_W + KTOT_W + EW;

    logic ofifo_push, ofifo_pop, ofifo_empty;
    logic hfifo_push, hfifo_pop, hfifo_empty;
    logic [OFW-1:0] ofifo_din, ofifo_dout;
    logic [HFW-1:0] hfifo_din, hfifo_dout;

    assign ofifo_push = pipe_en & w_vld & (w_typ == tensor_acc_pkg::OP_CREAD);
    assign hfifo_push = pipe_en & w_vld & ((w_typ == tensor_acc_pkg::OP_HREAD) |
                                           (w_typ == tensor_acc_pkg::OP_HWRITE) |
                                           (w_typ == tensor_acc_pkg::OP_HMETA));
    assign ofifo_din = {w_meta[F_DEST +: 3], w_meta[F_TAG +: TAG_W], w_meta[F_SLOT +: SLOT_W],
                        w_meta[F_ROW +: RIDW], w_meta[F_LAST], w_meta[F_CMASK +: COLS],
                        w_meta[F_ERR], w_entry};
    assign hfifo_din = {w_meta[F_HST +: 3], w_meta[F_HVLD], w_meta[F_HNCH +: CHUNK_W],
                        w_meta[F_HKACC +: KTOT_W], w_entry};

    tensor_acc_fifo #(.WIDTH(OFW), .DEPTH(OFIFO_DEPTH)) u_ofifo (
        .clk(clk), .rst_n(rst_n), .push(ofifo_push), .din(ofifo_din), .pop(ofifo_pop),
        .dout(ofifo_dout), .empty(ofifo_empty), .count(ofifo_cnt));

    tensor_acc_fifo #(.WIDTH(HFW), .DEPTH(HFIFO_DEPTH)) u_hfifo (
        .clk(clk), .rst_n(rst_n), .push(hfifo_push), .din(hfifo_din), .pop(hfifo_pop),
        .dout(hfifo_dout), .empty(hfifo_empty), .count(hfifo_cnt));

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            o_infl_q <= '0;
            h_infl_q <= '0;
        end else begin
            o_infl_q <= o_infl_q + OCW'(cm_fire) - OCW'(ofifo_push);
            h_infl_q <= h_infl_q + HCW'(hc_fire) - HCW'(hfifo_push);
        end
    end

    // ---------------------------------------------------- committed result beat
    logic [EW-1:0] o_entry;
    assign o_valid    = ~ofifo_empty;
    assign ofifo_pop  = o_valid & o_ready;
    assign o_entry    = ofifo_dout[EW-1:0];
    assign o_err      = ofifo_dout[EW];
    assign o_col_mask = ofifo_dout[EW+1 +: COLS];
    assign o_last     = ofifo_dout[EW+1+COLS];
    assign o_row      = ofifo_dout[EW+2+COLS +: RIDW];
    assign o_slot     = ofifo_dout[EW+2+COLS+RIDW +: SLOT_W];
    assign o_tag      = ofifo_dout[EW+2+COLS+RIDW+SLOT_W +: TAG_W];
    assign o_dest     = ofifo_dout[EW+2+COLS+RIDW+SLOT_W+TAG_W +: 3];

    generate
        for (gj = 0; gj < COLS; gj++) begin : g_o_lane
            logic [ACC_W-1:0] v;
            logic             cl;
            assign v = o_entry[gj*LW +: ACC_W];
            assign o_wide[gj*ACC_W +: ACC_W] = v;
            assign o_ovf[gj] = o_entry[gj*LW + ACC_W];
            if (ACC_W > OUT_W) begin : g_narrow
                logic in_rng;
                assign in_rng = (&v[ACC_W-1:OUT_W-1]) | ~(|v[ACC_W-1:OUT_W-1]);
                assign cl     = ~in_rng;
                assign o_data[gj*OUT_W +: OUT_W] =
                    (cl && SAT) ? (v[ACC_W-1] ? {1'b1, {(OUT_W-1){1'b0}}} : {1'b0, {(OUT_W-1){1'b1}}})
                                : v[OUT_W-1:0];
            end else begin : g_same
                assign cl = 1'b0;
                assign o_data[gj*OUT_W +: OUT_W] = v;
            end
            assign o_clip[gj] = cl;
        end
    endgenerate

    // ---------------------------------------------------- tile completion
    logic t_ovf_q, t_clip_q, t_err_q;
    logic cmt_done_q, cmt_ovf_q, cmt_clip_q, cmt_err_q;
    logic [SLOT_W-1:0] cmt_slot_q;
    logic [TAG_W-1:0]  cmt_tag_q;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            t_ovf_q <= 1'b0; t_clip_q <= 1'b0; t_err_q <= 1'b0;
            cmt_done_q <= 1'b0; cmt_ovf_q <= 1'b0; cmt_clip_q <= 1'b0; cmt_err_q <= 1'b0;
            cmt_slot_q <= '0; cmt_tag_q <= '0;
        end else begin
            cmt_done_q <= 1'b0;
            if (ofifo_pop) begin
                if (o_last) begin
                    cmt_done_q <= 1'b1;
                    cmt_slot_q <= o_slot;
                    cmt_tag_q  <= o_tag;
                    cmt_ovf_q  <= t_ovf_q  | (|o_ovf);
                    cmt_clip_q <= t_clip_q | (|o_clip);
                    cmt_err_q  <= t_err_q  | o_err;
                    t_ovf_q <= 1'b0; t_clip_q <= 1'b0; t_err_q <= 1'b0;
                end else begin
                    t_ovf_q  <= t_ovf_q  | (|o_ovf);
                    t_clip_q <= t_clip_q | (|o_clip);
                    t_err_q  <= t_err_q  | o_err;
                end
            end
        end
    end
    assign cmt_done = cmt_done_q;
    assign cmt_slot = cmt_slot_q;
    assign cmt_tag  = cmt_tag_q;
    assign cmt_ovf  = cmt_ovf_q;
    assign cmt_clip = cmt_clip_q;
    assign cmt_err  = cmt_err_q;

    // ---------------------------------------------------- host response
    assign hr_valid  = ~hfifo_empty;
    assign hfifo_pop = hr_valid & hr_ready;
    assign hr_status = hfifo_dout[EW+1+CHUNK_W+KTOT_W +: 3];
    assign hr_vld    = hfifo_dout[EW+CHUNK_W+KTOT_W];
    assign hr_nchunk = hfifo_dout[EW+KTOT_W +: CHUNK_W];
    assign hr_kacc   = hfifo_dout[EW +: KTOT_W];
    generate
        for (gj = 0; gj < COLS; gj++) begin : g_hr_lane
            assign hr_data[gj*ACC_W +: ACC_W] = hfifo_dout[gj*LW +: ACC_W];
            assign hr_ovf[gj]                 = hfifo_dout[gj*LW + ACC_W];
        end
    endgenerate

    // =========================================================================
    // status, errors
    // =========================================================================
    logic p_any;
    always_comb begin
        p_any = 1'b0;
        for (int s = 0; s < RD_LAT; s++) p_any = p_any | p_q[s*RECW + F_VLD];
    end
    logic idle_c;
    assign idle_c = ~p_any & ~w_vld & ofifo_empty & hfifo_empty & ~cm_active_q & ~cm_any;
    assign idle   = idle_c;

    logic       err_q;
    logic [2:0] err_code_q;
    logic [7:0] err_sticky_q;
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            err_q <= 1'b0; err_code_q <= '0; err_sticky_q <= '0;
        end else begin
            err_q      <= ps_fire & (ps_code != tensor_acc_pkg::PE_NONE);
            err_code_q <= ps_fire ? ps_code : '0;
            if (ps_fire && ps_code != tensor_acc_pkg::PE_NONE) err_sticky_q[ps_code] <= 1'b1;
        end
    end
    assign err_pulse  = err_q;
    assign err_code   = err_code_q;
    assign err_sticky = err_sticky_q;

    // =========================================================================
    // performance events and counters
    // =========================================================================
    logic [NPERF*EVW-1:0] ev;
    always_comb begin
        ev = '0;
        ev[tensor_acc_pkg::PF_PSUM_BEATS*EVW +: EVW]   = b2e(ps_fire);
        ev[tensor_acc_pkg::PF_PSUM_ELEMS*EVW +: EVW]   = ev_apply_c ? popc(ps_cmask_t) : '0;
        ev[tensor_acc_pkg::PF_PSUM_DUP*EVW +: EVW]     = b2e(ps_fire & ps_dup);
        ev[tensor_acc_pkg::PF_PSUM_ERR*EVW +: EVW]     = b2e(ps_fire & (ps_code != tensor_acc_pkg::PE_NONE));
        ev[tensor_acc_pkg::PF_RD_STALL*EVW +: EVW]     = b2e(pipe_en & ~st_rd_ready & (cm_req | hc_req | ps_valid));
        ev[tensor_acc_pkg::PF_WR_STALL*EVW +: EVW]     = b2e(~pipe_en);
        ev[tensor_acc_pkg::PF_OVF_ACC*EVW +: EVW]      = (pipe_en & x_vld & (x_typ == tensor_acc_pkg::OP_ADD))
                                                         ? popc(x_ovf_now & x_cmask) : '0;
        ev[tensor_acc_pkg::PF_OVF_OUT*EVW +: EVW]      = ofifo_pop ? popc(o_clip & o_col_mask) : '0;
        ev[tensor_acc_pkg::PF_COMMIT_ELEMS*EVW +: EVW] = ofifo_pop ? popc(o_col_mask) : '0;
        ev[tensor_acc_pkg::PF_COMMIT_TILES*EVW +: EVW] = b2e(ofifo_pop & o_last);
        ev[tensor_acc_pkg::PF_CHUNKS*EVW +: EVW]       = b2e(ev_chunk_c);
        ev[tensor_acc_pkg::PF_IN_STALL*EVW +: EVW]     = b2e(ps_valid & ~ps_ready);
        ev[tensor_acc_pkg::PF_OUT_STALL*EVW +: EVW]    = b2e(o_valid & ~o_ready);
        ev[tensor_acc_pkg::PF_CFG_REJECT*EVW +: EVW]   = b2e(cfg_valid & cfg_ready & ~cfg_legal);
        ev[tensor_acc_pkg::PF_HOST_OPS*EVW +: EVW]     = b2e(hc_fire);
        ev[tensor_acc_pkg::PF_BUSY*EVW +: EVW]         = b2e(~idle_c);
    end
    assign ev_inc = ev;

    generate
        if (PERF_EN != 0) begin : g_perf
            logic [NPERF*PERF_W-1:0] cnt_q;
            always_ff @(posedge clk) begin
                if (!rst_n || perf_clr) begin
                    cnt_q <= '0;
                end else begin
                    for (int i = 0; i < NPERF; i++) begin
                        if (cnt_q[i*PERF_W +: PERF_W] <= {PERF_W{1'b1}} - PERF_W'(ev[i*EVW +: EVW]))
                            cnt_q[i*PERF_W +: PERF_W] <= cnt_q[i*PERF_W +: PERF_W] + PERF_W'(ev[i*EVW +: EVW]);
                        else
                            cnt_q[i*PERF_W +: PERF_W] <= {PERF_W{1'b1}};    // saturate, never wrap
                    end
                end
            end
            assign perf_o = cnt_q;
        end else begin : g_noperf
            assign perf_o = '0;
        end
    endgenerate

    // =========================================================================
    // simulation-only invariants (compile with +define+TA_NO_INVARIANTS to remove
    // them, e.g. to show that the testbench alone detects a mutant)
    // =========================================================================
    // synthesis translate_off
`ifndef TA_NO_INVARIANTS
    always @(posedge clk) begin
        if (rst_n === 1'b1) begin
            if ((32'(cm_fire) + 32'(hc_fire) + 32'(ps_fire)) > 1)
                $error("%m: more than one op issued in one cycle");
            if (a_vld && !issue_ok)
                $error("%m: op issued without issue_ok");
            if (cm_fire && !e_vld_q[cm_idx])
                $error("%m: commit read of an uninitialised row");
            if (cm_fire && e_nch_q[32'(cm_idx)*CHUNK_W +: CHUNK_W] != s_nchunks_q[32'(cm_sel)*CHUNK_W +: CHUNK_W])
                $error("%m: commit read of a row missing K chunks");
        end
    end
`endif
    // synthesis translate_on

endmodule
