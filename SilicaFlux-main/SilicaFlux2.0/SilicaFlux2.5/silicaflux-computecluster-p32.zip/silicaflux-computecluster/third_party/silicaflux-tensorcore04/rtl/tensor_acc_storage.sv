// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tensor_acc_storage.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  Reference implementation of the ACCUMULATOR STORAGE INTERFACE
//  (docs/STORAGE_INTERFACE.md).  Any replacement (SRAM macro wrapper,
//  banked register file, ...) must honour exactly this contract:
//
//    * 1 read port + 1 write port, DEPTH entries of WIDTH bits, one entry
//      per output-tile row (entry = COLS lanes of {ovf, ACC_W value}).
//    * READ: a request (rd_req & rd_ready & en) in cycle t returns the entry
//      on rd_data in cycle t + RD_LAT and holds it while en == 0.  rd_data
//      is a register output for every RD_LAT >= 1 (no combinational path
//      from rd_addr to rd_data).
//    * WRITE: a request (wr_req & wr_ready) in cycle t updates the entry at
//      the end of cycle t.
//    * SAME-CYCLE READ/WRITE to one address returns the OLD value
//      (read-before-write).  A write in cycle t is visible to reads
//      requested in cycle t+1 or later.  The accumulator's forwarding
//      network is sized for exactly this behaviour.
//    * en is the accumulator's global pipeline enable.  While en == 0 the
//      read pipeline holds (the accumulator never requests a read then).
//    * rd_ready / wr_ready model port availability (arbitration with another
//      agent, refresh, BIST...).  Here they are driven from rd_block /
//      wr_block so a testbench can inject contention.
//    * Contents are NOT reset.  The accumulator never consumes an entry it
//      has not written for the current tile (valid tracking), so the reset
//      value is never relied upon.
// =============================================================================
`timescale 1ns/1ps
module tensor_acc_storage #(
    parameter int DEPTH  = 8,
    parameter int WIDTH  = 132,
    parameter int RD_LAT = 1,
    parameter int AW     = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
    input  logic             clk,
    input  logic             rst_n,
    input  logic             en,
    // read port
    input  logic             rd_req,
    input  logic [AW-1:0]    rd_addr,
    output logic             rd_ready,
    output logic [WIDTH-1:0] rd_data,
    // write port
    input  logic             wr_req,
    input  logic [AW-1:0]    wr_addr,
    input  logic [WIDTH-1:0] wr_data,
    output logic             wr_ready,
    // port contention (external arbiter / testbench)
    input  logic             rd_block,
    input  logic             wr_block
);

    // synthesis translate_off
    initial begin
        if (RD_LAT < 1 || RD_LAT > 3) $fatal(1, "tensor_acc_storage: RD_LAT must be 1..3");
        if (DEPTH < 1)                 $fatal(1, "tensor_acc_storage: DEPTH must be >= 1");
    end
    // synthesis translate_on

    assign rd_ready = ~rd_block;
    assign wr_ready = ~wr_block;

    logic [WIDTH-1:0] mem [DEPTH];

    always_ff @(posedge clk) begin
        if (wr_req && wr_ready) mem[wr_addr] <= wr_data;
    end

    // read pipeline: stage 0 is the array read register, further stages model
    // SRAM output registers.  All stages hold while en == 0.
    logic [RD_LAT*WIDTH-1:0] rp_q;

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            rp_q <= '0;
        end else if (en) begin
            if (rd_req && rd_ready) rp_q[0 +: WIDTH] <= mem[rd_addr];
            for (int s = 1; s < RD_LAT; s++) rp_q[s*WIDTH +: WIDTH] <= rp_q[(s-1)*WIDTH +: WIDTH];
        end
    end

    assign rd_data = rp_q[(RD_LAT-1)*WIDTH +: WIDTH];

endmodule
