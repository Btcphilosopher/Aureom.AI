// =============================================================================
// SilicaFlux TENSORCORE 06 :: ttc_tile_iter
// Tile traversal of one GEMM:  output tiles TILE_M x TILE_N, K in chunks of kc.
//
//   step = (m0, n0, k0)   element coordinates of the block, multiples of
//                         TILE_M / TILE_N / kc
//   K is always the innermost loop (output-stationary: one output tile is
//   finished before the next is started, so one accumulator slot per tile in
//   flight suffices).  The two outer orders:
//     nmajor = 0  M-major:  for m0 { for n0 { for k0 } }   (A block reusable across n0)
//     nmajor = 1  N-major:  for n0 { for m0 { for k0 } }   (B block reusable across m0)
//
//   eff_m = min(TILE_M, M - m0)   eff_n = min(TILE_N, N - n0)   eff_k = min(kc, K - k0)
//   Boundary tiles are therefore smaller than the array; nothing beyond the
//   matrix edge is ever part of a step.
//
// Two instances (loader, scheduler) run the same sequence independently; the
// scheduler cross-checks its geometry against TC03's tile response.
// init: first step.  adv: next step (ignored after the last step, `done`).
// All widths cover the worst case: M, N <= 65535, K <= 131071, kc <= 131071.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module ttc_tile_iter #(
  parameter int TILE_M = 4,
  parameter int TILE_N = 4,
  localparam int MW = $clog2(TILE_M + 1),
  localparam int NW = $clog2(TILE_N + 1)
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        init,
  input  wire logic        adv,
  input  wire logic        nmajor,
  input  wire logic [15:0] m,
  input  wire logic [15:0] n,
  input  wire logic [16:0] k,
  input  wire logic [16:0] kc,
  output logic [15:0]      m0,
  output logic [15:0]      n0,
  output logic [16:0]      k0,
  output logic [15:0]      kidx,        // chunk index (TC04 ps_chunk)
  output logic [MW-1:0]    eff_m,
  output logic [NW-1:0]    eff_n,
  output logic [16:0]      eff_k,
  output logic             first_k,     // first chunk of the output tile
  output logic             last_k,      // last chunk of the output tile
  output logic             last_step,   // last step of the GEMM
  output logic             done,        // advanced past the last step
  output logic [31:0]      step_idx
);
  logic [16:0] m_end, n_end;            // m0 + TILE_M, n0 + TILE_N (17 bits: never wraps)
  logic [17:0] k_end;                   // k0 + kc
  logic        last_m, last_n;

  assign m_end  = 17'(m0) + 17'(TILE_M);
  assign n_end  = 17'(n0) + 17'(TILE_N);
  assign k_end  = 18'(k0) + 18'(kc);
  assign last_m = (m_end >= 17'(m));
  assign last_n = (n_end >= 17'(n));
  assign last_k = (k_end >= 18'(k));
  assign first_k = (k0 == 17'd0);
  assign last_step = last_k && last_m && last_n;

  assign eff_m = last_m ? MW'(m - m0) : MW'(TILE_M);
  assign eff_n = last_n ? NW'(n - n0) : NW'(TILE_N);
  assign eff_k = last_k ? (k - k0)    : kc;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      m0 <= '0; n0 <= '0; k0 <= '0; kidx <= '0; done <= 1'b0; step_idx <= '0;
    end else if (init) begin
      m0 <= '0; n0 <= '0; k0 <= '0; kidx <= '0; done <= 1'b0; step_idx <= '0;
    end else if (adv && !done) begin
      step_idx <= step_idx + 32'd1;
      if (last_step) begin
        done <= 1'b1;
      end else if (!last_k) begin
        k0   <= k_end[16:0];
        kidx <= kidx + 16'd1;
      end else begin
        k0   <= '0;
        kidx <= '0;
        if (!nmajor) begin                     // M-major: n0 is the inner tile loop
          if (!last_n) n0 <= n_end[15:0];
          else begin n0 <= '0; m0 <= m_end[15:0]; end
        end else begin                         // N-major: m0 is the inner tile loop
          if (!last_m) m0 <= m_end[15:0];
          else begin m0 <= '0; n0 <= n_end[15:0]; end
        end
      end
    end
  end
endmodule

`default_nettype wire
