// =============================================================================
//  SilicaFlux TENSORCORE 05  --  tensor_quant_lane.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  One output lane, pipeline stages B and C of tensor_quantize.
//
//    stage B (register R2 at the end):   p = x * M          exact, PW bits
//    stage C (combinational, -> FIFO):   r = R_rm(p / 2^S)   exact, PW bits
//                                        y = r + zp          exact, YW bits
//                                        q = sat_fmt(y)  or  y mod 2^32 (WRAP)
//                                        q = max(q, zp)      if RELU
//
//  Pass-through and bias-only modes reach this lane with M = 1, S = 0, zp = 0
//  (forced by the descriptor path), for which every rounding mode is the
//  identity, so one datapath implements every mode with no bypass mux.
//
//  ROUNDING (S >= 1).  fl = p >>> S is floor(p / 2^S); the discarded bits give
//      g   = bit S-1 of p                 (the 1/2 position)
//      st  = OR of bits S-2 .. 0           (anything below 1/2)
//      neg = sign of p                     (= sign of p / 2^S when g|st)
//      lsb = bit 0 of fl
//  and the increment applied to fl is
//      RNE  g & (st | lsb)       nearest, ties to even
//      RTZ  neg & (g | st)       toward zero
//      RDN  0                    floor
//      RUP  g | st               ceil
//      RMM  g & (st | ~neg)      nearest, ties away from zero
//  The equality of this table with the definitional rounding of p / 2^S is
//  checked exhaustively for small widths and randomly at full width by
//  tests/test_ref_model.py, and bit for bit against the Fraction-based
//  reference by every testbench.  For S = 0 all masks are empty: inc = 0.
//
//  NO INTERMEDIATE CAN OVERFLOW: |x| < 2^(XW-1), |M| <= 2^31 so p fits PW =
//  XW + 32; |r| <= |p| (S = 0) or |p|/2 + 1 (S >= 1) so r fits PW; y fits
//  PW + 1.  Saturation compares the exact y with the output range.
// =============================================================================
`timescale 1ns/1ps
module tensor_quant_lane #(
    parameter int XW = 33,
    parameter int PW = XW + 32,
    parameter int YW = PW + 1
) (
    input  logic                 clk,
    input  logic                 en,         // R1 -> R2 (stage-A beat valid)
    // stage-B inputs (R1, held in tensor_quantize)
    input  logic signed [XW-1:0] x,
    input  logic signed [31:0]   mult,
    input  logic [5:0]           shift,
    input  logic signed [31:0]   zp,
    input  logic                 act,        // lane carries an element
    input  logic                 fmt8,       // 1: INT8 output, 0: INT32
    input  logic [2:0]           rm,
    input  logic                 relu,
    input  logic                 wrap,
    // stage-C outputs (valid in the cycle after en)
    output logic [31:0]          q,
    output logic                 sat,
    output logic                 relu_hit
);
    // ------------------------------------------------------------ stage B
    logic signed [PW-1:0] p_n;
    assign p_n = x * mult;                   // operands sign-extended to PW: exact

    logic signed [PW-1:0] p2;
    logic [5:0]           s2;
    logic signed [31:0]   z2;
    logic                 act2, fmt8_2, relu2, wrap2;
    logic [2:0]           rm2;

    always_ff @(posedge clk) begin
        if (en) begin
            p2     <= p_n;
            s2     <= shift;
            z2     <= zp;
            act2   <= act;
            fmt8_2 <= fmt8;
            rm2    <= rm;
            relu2  <= relu;
            wrap2  <= wrap;
        end
    end

    // ------------------------------------------------------------ stage C
    logic signed [PW-1:0] fl, r;
    logic [PW-1:0]        gm, sm;
    logic                 g, st, neg, inc;
    logic signed [YW-1:0] y, qmax, qmin;
    logic                 hi, lo;
    logic signed [31:0]   qs;

    assign fl  = p2 >>> s2;
    assign gm  = (s2 == 6'd0) ? '0 : (PW'(1) << (s2 - 6'd1));
    assign sm  = (s2 <= 6'd1) ? '0 : ((PW'(1) << (s2 - 6'd1)) - PW'(1));
    assign g   = |(p2 & gm);
    assign st  = |(p2 & sm);
    assign neg = p2[PW-1];

    always_comb begin
        case (rm2)
            tensor_quantize_pkg::RM_RNE: inc = g & (st | fl[0]);
            tensor_quantize_pkg::RM_RTZ: inc = neg & (g | st);
            tensor_quantize_pkg::RM_RDN: inc = 1'b0;
            tensor_quantize_pkg::RM_RUP: inc = g | st;
            tensor_quantize_pkg::RM_RMM: inc = g & (st | ~neg);
            default:                     inc = 1'b0;   // unreachable: RM validated at OPEN
        endcase
    end

    assign r    = fl + PW'(inc);
    assign y    = YW'(r) + YW'(z2);              // both sign-extended (signed operands)
    assign qmax = fmt8_2 ? YW'(127)  : YW'(32'sh7FFF_FFFF);
    assign qmin = fmt8_2 ? -YW'(128) : -(YW'(1) <<< 31);
    assign hi   = (y > qmax);
    assign lo   = (y < qmin);

    always_comb begin
        if (wrap2)   qs = y[31:0];                    // explicitly selected wraparound (INT32)
        else if (hi) qs = qmax[31:0];
        else if (lo) qs = qmin[31:0];
        else         qs = y[31:0];
    end

    assign relu_hit = act2 & relu2 & (qs < z2);
    assign q        = !act2 ? 32'd0 : (relu_hit ? z2 : qs);
    assign sat      = act2 & (hi | lo);
endmodule
