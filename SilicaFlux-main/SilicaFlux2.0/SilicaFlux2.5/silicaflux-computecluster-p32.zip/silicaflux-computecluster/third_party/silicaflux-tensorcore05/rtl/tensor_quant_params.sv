// =============================================================================
//  SilicaFlux TENSORCORE 05  --  tensor_quant_params.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  Per-output-channel parameter storage and its loading interface.
//
//  ORGANISATION.  The output channel is the N (column) dimension of
//  C = A x B: lane j of a result beat is channel  CH_GRP*COLS + j.  Every row
//  of a tile therefore uses the same COLS parameter sets, so the table is
//  organised as NUM_GRP channel GROUPS of COLS lanes, and a tile reads one
//  whole group (one wide word, SRAM-friendly) when its descriptor opens.
//
//  Per lane and group:  bias (s32), mult (s32), shift (u6), zp (s32),
//                       colsum (s IN_W, ASYM_EN only), and one VALID bit per
//                       field (cleared by reset, set by writes).
//
//  WRITE PORT (p_*).  One write = one group, any subset of lanes
//  (p_lane_mask) and any subset of fields (p_fmask, tensor_quantize_pkg::FMB_*).
//  A write is applied whole or not at all:
//      p_grp >= NUM_GRP              -> rejected, PW_GRP
//      column sum with ASYM_EN == 0  -> rejected, PW_UNSUP
//  wr_ok / wr_err / wr_code describe the write accepted in this cycle.
//
//  READ PORT.  Combinational read of one group (rd_*), used by the descriptor
//  path of tensor_quantize.  A write accepted in cycle t updates the table at
//  the end of cycle t, so a descriptor accepted in the SAME cycle reads the
//  OLD contents and descriptors accepted in t+1 or later read the new ones.
//  (This is the only ordering rule between the two ports; tested directly.)
//
//  Data storage is not reset (SRAM-like); the valid bits are.  Contents of a
//  field whose valid bit is clear are never used: tensor_quantize rejects a
//  descriptor that would need one (QR_PARAM).
// =============================================================================
`timescale 1ns/1ps
module tensor_quant_params #(
    parameter int COLS    = 4,
    parameter int IN_W    = 32,
    parameter int NUM_GRP = 16,
    parameter int ASYM_EN = 0,
    parameter int GRP_W   = (NUM_GRP > 1) ? $clog2(NUM_GRP) : 1
) (
    input  logic                     clk,
    input  logic                     rst_n,
    input  logic                     en,            // 0 during / just after reset: port not ready
    // ------------------------------------------------ write port
    input  logic                     p_valid,
    output logic                     p_ready,
    input  logic [15:0]              p_grp,
    input  logic [COLS-1:0]          p_lane_mask,
    input  logic [4:0]               p_fmask,
    input  logic [COLS*32-1:0]       p_bias,
    input  logic [COLS*32-1:0]       p_mult,
    input  logic [COLS*6-1:0]        p_shift,
    input  logic [COLS*32-1:0]       p_zp,
    input  logic [COLS*IN_W-1:0]     p_cs,
    output logic                     wr_ok,         // write applied this cycle
    output logic                     wr_err,        // write rejected this cycle
    output logic [1:0]               wr_code,
    // ------------------------------------------------ group read port (combinational)
    input  logic [GRP_W-1:0]         rd_grp,
    output logic [COLS*32-1:0]       rd_bias,
    output logic [COLS*32-1:0]       rd_mult,
    output logic [COLS*6-1:0]        rd_shift,
    output logic [COLS*32-1:0]       rd_zp,
    output logic [COLS*IN_W-1:0]     rd_cs,
    output logic [COLS*5-1:0]        rd_vld          // per lane {cs, zp, shift, mult, bias}
);
    logic acc, grp_ok, unsup;
    logic [GRP_W-1:0] wg;

    assign p_ready = en;
    assign acc     = p_valid & p_ready;
    assign grp_ok  = (32'(p_grp) < NUM_GRP);
    assign unsup   = p_fmask[tensor_quantize_pkg::FMB_CS] & (ASYM_EN == 0);
    assign wr_ok   = acc & grp_ok & ~unsup;
    assign wr_err  = acc & ~(grp_ok & ~unsup);
    assign wr_code = !grp_ok ? tensor_quantize_pkg::PW_GRP :
                     unsup   ? tensor_quantize_pkg::PW_UNSUP : tensor_quantize_pkg::PW_OK;
    assign wg      = GRP_W'(p_grp);

    for (genvar j = 0; j < COLS; j++) begin : g_lane
        logic [31:0] t_bias  [NUM_GRP];
        logic [31:0] t_mult  [NUM_GRP];
        logic [5:0]  t_shift [NUM_GRP];
        logic [31:0] t_zp    [NUM_GRP];
        logic [4:0]  t_vld   [NUM_GRP];
        logic        we;
        logic [4:0]  fm;

        assign we = wr_ok & p_lane_mask[j];
        assign fm = p_fmask & ((ASYM_EN != 0) ? 5'b11111 : 5'b01111);

        always_ff @(posedge clk) begin
            if (we && fm[tensor_quantize_pkg::FMB_BIAS])  t_bias[wg]  <= p_bias[j*32 +: 32];
            if (we && fm[tensor_quantize_pkg::FMB_MULT])  t_mult[wg]  <= p_mult[j*32 +: 32];
            if (we && fm[tensor_quantize_pkg::FMB_SHIFT]) t_shift[wg] <= p_shift[j*6 +: 6];
            if (we && fm[tensor_quantize_pkg::FMB_ZP])    t_zp[wg]    <= p_zp[j*32 +: 32];
        end

        always_ff @(posedge clk) begin
            if (!rst_n) begin
                for (int g = 0; g < NUM_GRP; g++) t_vld[g] <= '0;
            end else if (we) begin
                t_vld[wg] <= t_vld[wg] | fm;
            end
        end

        assign rd_bias[j*32 +: 32]  = t_bias[rd_grp];
        assign rd_mult[j*32 +: 32]  = t_mult[rd_grp];
        assign rd_shift[j*6 +: 6]   = t_shift[rd_grp];
        assign rd_zp[j*32 +: 32]    = t_zp[rd_grp];
        assign rd_vld[j*5 +: 5]     = t_vld[rd_grp];

        if (ASYM_EN != 0) begin : g_cs
            logic [IN_W-1:0] t_cs [NUM_GRP];
            always_ff @(posedge clk)
                if (we && fm[tensor_quantize_pkg::FMB_CS]) t_cs[wg] <= p_cs[j*IN_W +: IN_W];
            assign rd_cs[j*IN_W +: IN_W] = t_cs[rd_grp];
        end else begin : g_nocs
            assign rd_cs[j*IN_W +: IN_W] = '0;
            /* verilator lint_off UNUSEDSIGNAL */
            logic unused_cs;
            assign unused_cs = ^p_cs[j*IN_W +: IN_W];
            /* verilator lint_on UNUSEDSIGNAL */
        end
    end
endmodule
