// =============================================================================
//  SilicaFlux TENSORCORE 05  --  tensor_quantize_pkg.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  Encodings of the output-conversion descriptor ABI, parameter port, error
//  codes, performance counters, and the intermediate-width formulas.
//  Conventions follow TENSORCORE 04 (tensor_acc_pkg): localparams and constant
//  functions only, assignment-to-function-name (Yosys 0.33 rejects `return`),
//  importers use scoped references (tensor_quantize_pkg::X).
//
//  Every value here is mirrored in model/tq_ref.py; tools/check_abi.py checks
//  the two agree.
// =============================================================================
`ifndef TENSOR_QUANTIZE_PKG_SV
`define TENSOR_QUANTIZE_PKG_SV
`timescale 1ns/1ps

package tensor_quantize_pkg;

    /* verilator lint_off UNUSEDPARAM */

    // ------------------------------------------------------------------
    // Descriptor header (word 0).  Layout: docs/NUMERIC_FORMAT.md section 8.
    //   [7:0] OPCODE  [11:8] VERSION  [14:12] RM  [15] rsvd
    //   [23:16] FLAGS  [27:24] OFMT  [31:28] rsvd
    // ------------------------------------------------------------------
    localparam logic [7:0] OP_OPEN  = 8'h40;   // open an output-tile context
    localparam logic [7:0] OP_CLOSE = 8'h41;   // release a context without beats
    localparam logic [3:0] VERSION  = 4'd1;

    // rounding modes: Module 02 / RISC-V frm encoding, reused unchanged
    localparam logic [2:0] RM_RNE = 3'd0;      // nearest, ties to even   (baseline)
    localparam logic [2:0] RM_RTZ = 3'd1;      // toward zero
    localparam logic [2:0] RM_RDN = 3'd2;      // toward -infinity (floor)
    localparam logic [2:0] RM_RUP = 3'd3;      // toward +infinity (ceil)
    localparam logic [2:0] RM_RMM = 3'd4;      // nearest, ties away from zero

    // FLAGS bit positions
    localparam int FLB_BIAS = 0;               // add per-channel INT32 bias (table)
    localparam int FLB_RQ   = 1;               // requantise: R(x*M/2^S) + zp
    localparam int FLB_PC   = 2;               // per-channel M/S/zp (table) instead of per-tensor
    localparam int FLB_RELU = 3;               // ReLU (floor = output zero-point)
    localparam int FLB_WRAP = 4;               // INT32 only: wrap instead of saturate (flagged)

    // output formats
    localparam logic [3:0] OFMT_INT32 = 4'd0;
    localparam logic [3:0] OFMT_INT8  = 4'd1;

    // ------------------------------------------------------------------
    // Descriptor reject codes (desc_rej_code).  First failing rule wins.
    // VERSION / OPCODE / CTX: nothing is opened.  CLOSE failures: nothing is
    // closed.  Any other OPEN failure opens the context POISONED, so the
    // tile's beats still drain (flagged, zero data) and nothing deadlocks.
    // ------------------------------------------------------------------
    localparam logic [3:0] QR_OK      = 4'd0;
    localparam logic [3:0] QR_VERSION = 4'd1;
    localparam logic [3:0] QR_OPCODE  = 4'd2;
    localparam logic [3:0] QR_CTX     = 4'd3;   // CTX >= NUM_CTX
    localparam logic [3:0] QR_RSVD    = 4'd4;   // reserved bit, or a field unused by the mode, non-zero
    localparam logic [3:0] QR_STATE   = 4'd5;   // CLOSE of a context that is not open with that TAG
    localparam logic [3:0] QR_FMT     = 4'd6;   // OFMT not INT32/INT8
    localparam logic [3:0] QR_RM      = 4'd7;   // RM 5..7
    localparam logic [3:0] QR_FLAGS   = 4'd8;   // PC without RQ, WRAP without INT32
    localparam logic [3:0] QR_UNSUP   = 4'd9;   // ZB != 0 (never supported) / ZA != 0 with ASYM_EN = 0
    localparam logic [3:0] QR_DIM     = 4'd10;  // M, N out of range, or M0 + M - 1 > 2^32 - 1
    localparam logic [3:0] QR_ZP      = 4'd11;  // per-tensor zero-point outside the output range
    localparam logic [3:0] QR_CHAN    = 4'd12;  // CH_GRP >= NUM_GRP while the table is used
    localparam logic [3:0] QR_PARAM   = 4'd13;  // a required table field is not loaded (active lane)
    localparam logic [3:0] QR_PZP     = 4'd14;  // per-channel zero-point outside the output range

    // ------------------------------------------------------------------
    // Beat error codes (out_err_code), priority order.
    // NOCTX / TAG / POISON: no usable parameters -> data, sat and index
    // fields are zero.  FRAME / UPSTREAM: computed normally, flagged.
    // ------------------------------------------------------------------
    localparam logic [2:0] BE_NONE     = 3'd0;
    localparam logic [2:0] BE_NOCTX    = 3'd1;  // in_ctx >= NUM_CTX
    localparam logic [2:0] BE_TAG      = 3'd2;  // context open with a different tag
    localparam logic [2:0] BE_POISON   = 3'd3;  // context opened by a rejected descriptor
    localparam logic [2:0] BE_FRAME    = 3'd4;  // row >= M, col_mask != tile mask, last != (row == M-1)
    localparam logic [2:0] BE_UPSTREAM = 3'd5;  // producer flagged the beat (TC04 o_err)

    // ------------------------------------------------------------------
    // Parameter port: field mask bits and write status
    // ------------------------------------------------------------------
    localparam int FMB_BIAS  = 0;
    localparam int FMB_MULT  = 1;
    localparam int FMB_SHIFT = 2;
    localparam int FMB_ZP    = 3;
    localparam int FMB_CS    = 4;               // weight column sum (ASYM_EN only)
    localparam int NFIELD    = 5;
    localparam logic [1:0] PW_OK    = 2'd0;
    localparam logic [1:0] PW_GRP   = 2'd1;     // p_grp >= NUM_GRP
    localparam logic [1:0] PW_UNSUP = 2'd2;     // column-sum write with ASYM_EN = 0

    // ------------------------------------------------------------------
    // Fixed field widths of the arithmetic contract
    // ------------------------------------------------------------------
    localparam int BIAS_W  = 32;                // signed
    localparam int MULT_W  = 32;                // signed (negative scales permitted)
    localparam int SHIFT_W = 6;                 // unsigned, 0..63
    localparam int ZP_W    = 32;                // signed; must lie in the output range
    localparam int ZA_W    = 8;                 // signed input (activation) zero-point
    localparam int OUT_W   = 32;                // output lane container

    // ------------------------------------------------------------------
    // Performance counters (perf_o[i*PERF_W +: PERF_W]), saturating
    // ------------------------------------------------------------------
    localparam int PF_BEATS_IN   = 0;    // input beats accepted
    localparam int PF_BEATS_OUT  = 1;    // output beats delivered
    localparam int PF_ELEMS      = 2;    // active elements converted
    localparam int PF_SAT        = 3;    // elements saturated (or wrapped) to the output range
    localparam int PF_RELU       = 4;    // elements raised to the ReLU floor
    localparam int PF_BEAT_ERR   = 5;    // beats with out_err
    localparam int PF_DESC_OK    = 6;    // descriptors accepted cleanly (OPEN or CLOSE)
    localparam int PF_DESC_REJ   = 7;    // descriptors rejected (incl. poisoned OPEN)
    localparam int PF_PARAM_WR   = 8;    // parameter writes applied
    localparam int PF_PARAM_REJ  = 9;    // parameter writes rejected
    localparam int PF_IN_STALL   = 10;   // in_valid & ~in_ready cycles
    localparam int PF_CTX_WAIT   = 11;   // in_valid while the beat's context is not open
    localparam int PF_OUT_STALL  = 12;   // out_valid & ~out_ready cycles
    localparam int NPERF         = 13;

    // ------------------------------------------------------------------
    // Intermediate widths (proof: docs/NUMERIC_FORMAT.md section 5, checked
    // by corner enumeration in tests/test_ref_model.py).  IN_W >= 32.
    //   CW : bias_eff = bias - zA*colsum
    //   XW : x = acc + bias_eff
    //   PW : p = x * M        (exact signed product)
    //   YW : y = R(p / 2^S) + zp
    // ------------------------------------------------------------------
    function automatic int cw_of(input int in_w, input int asym);
        if (asym != 0) cw_of = in_w + 8;
        else           cw_of = BIAS_W;
    endfunction
    function automatic int xw_of(input int in_w, input int asym);
        if (asym != 0) xw_of = in_w + 8;
        else           xw_of = in_w + 1;
    endfunction

    /* verilator lint_on UNUSEDPARAM */

endpackage

`endif // TENSOR_QUANTIZE_PKG_SV
