// =============================================================================
//  SilicaFlux TENSORCORE 05  --  tensor_quantize.sv              (PRIMARY SOURCE)
//  Tensor quantisation, bias, activation and output conversion
//  Aureom.AI | SilicaFlux-HPC
//
//  Converts the exact signed accumulations committed by TENSORCORE 04
//  (tensor_acc_subsystem, `oquant_*` port, one tile row per beat) into the
//  output format requested by a per-tile descriptor:
//
//      INT32 pass-through          q = x
//      INT32 + bias                q = sat32(acc + bias[n])        (or explicit wrap)
//      INT8 requantisation         q = sat8( R_rm(x * M / 2^S) + zp )
//      optional ReLU               q = max(q, zp)                  (zero-point floor)
//      x = acc + bias[n] - zA * colsum[n]                          (bias, zA optional)
//
//  Order of operations (docs/NUMERIC_FORMAT.md section 2):
//      accumulation (TC04) -> bias / input-zero-point correction -> requantisation
//      (multiply, round, + zp, saturate) -> activation (ReLU) -> output
//  No real-number arithmetic: scale = M / 2^S with M a signed 32-bit integer
//  and 0 <= S <= 63.  Every intermediate is exact (width analysis in
//  tensor_quant_lane.sv and NUMERIC_FORMAT.md section 5): the only places a
//  value can change are the single rounding R_rm and the final saturation,
//  both defined exactly and both flagged.
//
//  ---------------------------------------------------------------------------
//  OUTPUT CHANNEL.  The output channel is the N (column) dimension of
//  C = A x B (TC04's bias[n] axis).  Lane j of a beat is channel
//  CH_GRP*COLS + j.  All rows of a tile share the same COLS channels, so the
//  per-channel parameters of a tile are read ONCE, when its descriptor opens,
//  into a per-context snapshot (tensor_quant_params.sv).
//
//  CONTEXTS.  NUM_CTX contexts, indexed by the producer's slot (TC04 o_slot).
//  TC04 commits tiles in completion order, which differs from descriptor
//  order across slots, so a beat finds its parameters by slot and checks the
//  tag.  A beat whose context is not open WAITS (in_ready = 0) until its
//  descriptor arrives.  The context is released by the beat with in_last.
//
//  ASSOCIATION UNDER BACKPRESSURE.  The parameters a beat needs are copied
//  out of its context at stage A, in the same cycle the beat is accepted, and
//  travel with the beat through fixed registers (R1, R2) into the output
//  FIFO.  The pipeline never stalls: output backpressure is absorbed by a
//  credit-reserved FIFO (a beat is accepted only if a FIFO slot is reserved
//  for it).  Nothing is looked up after acceptance, so no stall, reload of
//  the table, re-open of the context or interleaving of tiles can pair a
//  result with another beat's parameters.
//
//  PIPELINE (one beat per cycle; latency 3 cycles to out_valid)
//    A : accept, context lookup, checks, x = acc + bias_eff        -> R1
//    B : p = x * M                                                 -> R2 (lane)
//    C : round, + zp, saturate/wrap, ReLU                          -> output FIFO
//
//  ERRORS ARE NEVER SILENT.  Malformed descriptors are answered with a code;
//  one that fails a semantic check still opens its context POISONED so the
//  tile drains (flagged, zero data) instead of deadlocking the producer.
//  Malformed beats are delivered flagged (out_err, out_err_code), never
//  dropped, so the element stream stays aligned with the producer.
//
//  ASYMMETRIC INPUTS.  zA != 0 (ASYM_EN = 1) is supported for symmetric
//  weights only (zB = 0): the correction  -zA * sum_k B[k][n]  needs only the
//  weight column sums, loaded with the parameters, and is folded into
//  bias_eff once per tile.  zB != 0 needs per-row sums of A, which the INT8
//  array does not produce: it is UNSUPPORTED and rejected (QR_UNSUP).
//
//  Reset: synchronous, active low; clears contexts, pipeline, FIFO, credits,
//  parameter valid bits, sticky errors and counters.
// =============================================================================
`timescale 1ns/1ps
module tensor_quantize #(
    parameter int ROWS        = 4,      // tile rows    (= TC04 ROWS)
    parameter int COLS        = 4,      // tile columns (= TC04 COLS), lanes per beat
    parameter int IN_W        = 32,     // accumulator lane width (= TC04 ACC_W, o_wide)
    parameter int NUM_CTX     = 2,      // contexts (= TC04 NUM_TILES)
    parameter int NUM_GRP     = 16,     // parameter table depth in channel groups
    parameter int ASYM_EN     = 0,      // 1: input zero-point correction (zB = 0 only)
    parameter int OFIFO_DEPTH = 4,      // output FIFO; >= 4 for one beat per cycle
    parameter int PERF_EN     = 1,
    parameter int PERF_W      = 32,
    // ---------------- derived: never override ----------------
    parameter int CTX_W = (NUM_CTX > 1) ? $clog2(NUM_CTX) : 1,
    parameter int RIDW  = (ROWS > 1) ? $clog2(ROWS) : 1,
    parameter int GRP_W = (NUM_GRP > 1) ? $clog2(NUM_GRP) : 1,
    parameter int EVW   = $clog2(COLS + 1),
    parameter int NPERF = tensor_quantize_pkg::NPERF
) (
    input  logic                     clk,
    input  logic                     rst_n,          // synchronous, active low

    // ------------------------------------------------ descriptors (256-bit, ABI v1)
    input  logic                     desc_valid,
    output logic                     desc_ready,
    input  logic [255:0]             desc_data,
    output logic                     desc_ok,        // pulse (cycle after accept): clean OPEN / CLOSE
    output logic                     desc_rej,       // pulse (cycle after accept): rejected
    output logic [3:0]               desc_rej_code,

    // ------------------------------------------------ per-channel parameter load
    input  logic                     p_valid,
    output logic                     p_ready,
    input  logic [15:0]              p_grp,
    input  logic [COLS-1:0]          p_lane_mask,
    input  logic [4:0]               p_fmask,
    input  logic [COLS*32-1:0]       p_bias,
    input  logic [COLS*32-1:0]       p_mult,
    input  logic [COLS*6-1:0]        p_shift,
    input  logic [COLS*32-1:0]       p_zp,
    input  logic [COLS*IN_W-1:0]     p_cs,
    output logic                     p_err,          // pulse (cycle after accept)
    output logic [1:0]               p_err_code,

    // ------------------------------------------------ accumulator beats (TC04 oquant_*)
    input  logic                     in_valid,
    output logic                     in_ready,
    input  logic [CTX_W-1:0]         in_ctx,         // = TC04 o_slot
    input  logic [15:0]              in_tag,         // = TC04 o_tag
    input  logic [RIDW-1:0]          in_row,         // = TC04 o_row
    input  logic [COLS-1:0]          in_col_mask,    // = TC04 o_col_mask
    input  logic                     in_last,        // = TC04 o_last
    input  logic [COLS*IN_W-1:0]     in_data,        // = TC04 o_wide (exact)
    input  logic [COLS-1:0]          in_ovf,         // = TC04 o_ovf
    input  logic                     in_err,         // = TC04 o_err

    // ------------------------------------------------ converted results
    output logic                     out_valid,
    input  logic                     out_ready,
    output logic [15:0]              out_tag,        // transaction tag
    output logic [CTX_W-1:0]         out_ctx,
    output logic [RIDW-1:0]          out_row,        // row within the tile
    output logic [31:0]              out_m,          // element index: global row  M0 + row
    output logic [31:0]              out_ch0,        // element index: channel of lane 0 (CH_GRP*COLS)
    output logic [COLS-1:0]          out_col_mask,
    output logic                     out_last,
    output logic [3:0]               out_fmt,        // OFMT_INT32 / OFMT_INT8
    output logic [COLS*32-1:0]       out_data,       // lane j: value, INT8 sign-extended
    output logic [COLS*8-1:0]        out_q8,         // packed INT8 view (valid when out_fmt = INT8)
    output logic [COLS-1:0]          out_sat,        // lane saturated (or wrapped) here
    output logic [COLS-1:0]          out_iovf,       // lane already inexact upstream (TC04 o_ovf)
    output logic                     out_err,
    output logic [2:0]               out_err_code,

    // ------------------------------------------------ status
    output logic [NUM_CTX-1:0]       ctx_open,
    output logic [NUM_CTX-1:0]       ctx_poison,
    output logic                     idle,           // no beat in the pipeline or FIFO
    output logic [15:0]              desc_err_sticky,   // bit k: reject code k seen
    output logic [7:0]               beat_err_sticky,   // bit k: beat error code k seen
    output logic [3:0]               param_err_sticky,  // bit k: write status k seen

    // ------------------------------------------------ performance
    input  logic                     perf_clr,
    output logic [NPERF*PERF_W-1:0]  perf_o
);
    localparam int CW = tensor_quantize_pkg::cw_of(IN_W, ASYM_EN);
    localparam int XW = tensor_quantize_pkg::xw_of(IN_W, ASYM_EN);
    localparam int PW = XW + 32;
    localparam int YW = PW + 1;
    localparam int MW = $clog2(ROWS + 1);
    localparam int CRW = $clog2(OFIFO_DEPTH + 1);

    // synthesis translate_off
    initial begin
        if (IN_W < 32 || IN_W > 64) $fatal(1, "tensor_quantize: IN_W must be 32..64");
        if (ROWS < 1 || ROWS > 255 || COLS < 1 || COLS > 32) $fatal(1, "tensor_quantize: ROWS 1..255, COLS 1..32");
        if (NUM_CTX < 1 || NUM_CTX > 256) $fatal(1, "tensor_quantize: NUM_CTX must be 1..256");
        if (NUM_GRP < 1 || NUM_GRP > 65536) $fatal(1, "tensor_quantize: NUM_GRP must be 1..65536");
        if (OFIFO_DEPTH < 1) $fatal(1, "tensor_quantize: OFIFO_DEPTH must be >= 1");
        if (PERF_W < 2 || PERF_W > 64) $fatal(1, "tensor_quantize: PERF_W must be 2..64");
        if (PW <= 63) $fatal(1, "tensor_quantize: product width must exceed the maximum shift");
    end
    // synthesis translate_on

    // ======================================================================
    // run gate: ready outputs are low during reset and the cycle after it
    // ======================================================================
    logic run_q;
    always_ff @(posedge clk) run_q <= rst_n;

    // ======================================================================
    // parameter table
    // ======================================================================
    logic [GRP_W-1:0]      rd_grp;
    logic [COLS*32-1:0]    rd_bias, rd_mult, rd_zp;
    logic [COLS*6-1:0]     rd_shift;
    logic [COLS*IN_W-1:0]  rd_cs;
    logic [COLS*5-1:0]     rd_vld;
    logic                  pw_ok, pw_err;
    logic [1:0]            pw_code;

    tensor_quant_params #(.COLS(COLS), .IN_W(IN_W), .NUM_GRP(NUM_GRP), .ASYM_EN(ASYM_EN)) u_params (
        .clk, .rst_n, .en(run_q),
        .p_valid, .p_ready, .p_grp, .p_lane_mask, .p_fmask, .p_bias, .p_mult, .p_shift, .p_zp, .p_cs,
        .wr_ok(pw_ok), .wr_err(pw_err), .wr_code(pw_code),
        .rd_grp, .rd_bias, .rd_mult, .rd_shift, .rd_zp, .rd_cs, .rd_vld);

    // ======================================================================
    // contexts
    // ======================================================================
    logic [NUM_CTX-1:0]        c_open, c_poison;
    logic [15:0]               c_tag   [NUM_CTX];
    logic [MW-1:0]             c_m     [NUM_CTX];
    logic [COLS-1:0]           c_tmask [NUM_CTX];
    logic [31:0]               c_m0    [NUM_CTX];
    logic [31:0]               c_ch0   [NUM_CTX];
    logic                      c_fmt8  [NUM_CTX];
    logic [2:0]                c_rm    [NUM_CTX];
    logic                      c_relu  [NUM_CTX];
    logic                      c_wrap  [NUM_CTX];
    logic [COLS*CW-1:0]        c_beff  [NUM_CTX];
    logic [COLS*32-1:0]        c_mult  [NUM_CTX];
    logic [COLS*6-1:0]         c_shift [NUM_CTX];
    logic [COLS*32-1:0]        c_zp    [NUM_CTX];

    assign ctx_open   = c_open;
    assign ctx_poison = c_poison;

    // ======================================================================
    // descriptor decode and validation (combinational)
    // ======================================================================
    logic [31:0] dw0, dw1, dw2, dw3, dw4, dw5, dw6, dw7;
    assign {dw7, dw6, dw5, dw4, dw3, dw2, dw1, dw0} = desc_data;

    logic [7:0]  d_op, d_fl, d_ctx, d_m, d_n, d_r1, d_zb, d_r5b;
    logic [3:0]  d_ver, d_fmt, d_r0b;
    logic [2:0]  d_rm;
    logic        d_r0a;
    logic [15:0] d_tag, d_grp;
    logic [5:0]  d_shift;
    logic [1:0]  d_r5a;
    logic signed [7:0]  d_za;
    logic signed [31:0] d_mult, d_zp;
    assign d_op    = dw0[7:0];
    assign d_ver   = dw0[11:8];
    assign d_rm    = dw0[14:12];
    assign d_r0a   = dw0[15];
    assign d_fl    = dw0[23:16];
    assign d_fmt   = dw0[27:24];
    assign d_r0b   = dw0[31:28];
    assign d_tag   = dw1[15:0];
    assign d_ctx   = dw1[23:16];
    assign d_r1    = dw1[31:24];
    assign d_m     = dw2[7:0];
    assign d_n     = dw2[15:8];
    assign d_grp   = dw2[31:16];
    assign d_mult  = dw4;
    assign d_shift = dw5[5:0];
    assign d_r5a   = dw5[7:6];
    assign d_za    = dw5[15:8];
    assign d_zb    = dw5[23:16];
    assign d_r5b   = dw5[31:24];
    assign d_zp    = dw6;

    logic f_bias, f_rq, f_pc, f_relu, f_wrap;
    assign f_bias = d_fl[tensor_quantize_pkg::FLB_BIAS];
    assign f_rq   = d_fl[tensor_quantize_pkg::FLB_RQ];
    assign f_pc   = d_fl[tensor_quantize_pkg::FLB_PC];
    assign f_relu = d_fl[tensor_quantize_pkg::FLB_RELU];
    assign f_wrap = d_fl[tensor_quantize_pkg::FLB_WRAP];

    logic             is_open, is_close, ver_ok, ctx_in, grp_in, uses_table, za_nz, fmt8;
    logic [CTX_W-1:0] dsel;
    logic [4:0]       need;
    assign is_open    = (d_op == tensor_quantize_pkg::OP_OPEN);
    assign is_close   = (d_op == tensor_quantize_pkg::OP_CLOSE);
    assign ver_ok     = (d_ver == tensor_quantize_pkg::VERSION);
    assign ctx_in     = (32'(d_ctx) < NUM_CTX);
    assign dsel       = ctx_in ? CTX_W'(d_ctx) : '0;
    assign grp_in     = (32'(d_grp) < NUM_GRP);
    assign za_nz      = (d_za != 8'sd0);
    assign uses_table = f_bias | f_pc | za_nz;
    assign rd_grp     = grp_in ? GRP_W'(d_grp) : '0;
    assign fmt8       = (d_fmt == tensor_quantize_pkg::OFMT_INT8);
    // fields the snapshot needs from the table, in FMB_* order {cs, zp, shift, mult, bias}
    assign need       = {za_nz, f_pc, f_pc, f_pc, f_bias};

    // per-lane checks and snapshot values
    logic [COLS-1:0]    lane_in, lane_missing, lane_pzp_bad;
    logic [COLS*CW-1:0] s_beff;
    logic [COLS*32-1:0] s_mult, s_zp;
    logic [COLS*6-1:0]  s_shift;

    for (genvar j = 0; j < COLS; j++) begin : g_dl
        logic signed [31:0]      tb, tm, tz;
        logic signed [IN_W-1:0]  tcs;
        /* verilator lint_off UNUSEDSIGNAL */
        logic signed [IN_W+7:0]  csprod;         // upper bits unused when ASYM_EN = 0 (CW = 32)
        /* verilator lint_on UNUSEDSIGNAL */
        logic signed [CW-1:0]    csterm;
        logic signed [CW-1:0]    beff;
        assign tb  = rd_bias[j*32 +: 32];
        assign tm  = rd_mult[j*32 +: 32];
        assign tz  = rd_zp[j*32 +: 32];
        assign tcs = rd_cs[j*IN_W +: IN_W];
        assign lane_in[j]      = (j < 32'(d_n));
        assign lane_missing[j] = lane_in[j] & ((rd_vld[j*5 +: 5] & need) != need);
        assign lane_pzp_bad[j] = lane_in[j] & fmt8 & ((tz > 32'sd127) | (tz < -32'sd128));
        // zA * colsum (exact: |.| <= 2^(IN_W+6)).  The signed product is formed on its own:
        // inside a ?: with an unsigned arm it would be evaluated unsigned (zero-extended).
        // It is only used when zA != 0, i.e. when the column sum is known to be loaded.
        assign csprod = d_za * tcs;
        assign csterm = (ASYM_EN != 0 && za_nz) ? CW'(csprod) : '0;
        assign beff   = (f_bias ? CW'(tb) : CW'(0)) - csterm;
        assign s_beff[j*CW +: CW]  = lane_in[j] ? beff : '0;
        assign s_mult[j*32 +: 32]  = !lane_in[j] ? 32'd0 : !f_rq ? 32'd1 : f_pc ? tm : d_mult;
        assign s_shift[j*6 +: 6]   = (!lane_in[j] || !f_rq) ? 6'd0 : f_pc ? rd_shift[j*6 +: 6] : d_shift;
        assign s_zp[j*32 +: 32]    = (!lane_in[j] || !f_rq) ? 32'd0 : f_pc ? tz : d_zp;
    end

    logic       rsvd_static, rsvd_unused, dim_bad, zp_bad;
    logic [3:0] d_code;
    assign rsvd_static = d_r0a | (d_r0b != 0) | (d_fl[7:5] != 0) | (d_r1 != 0) | (d_r5a != 0) |
                         (d_r5b != 0) | (dw7 != 0);
    assign rsvd_unused = (!f_rq && (d_rm != 0 || d_mult != 0 || d_shift != 0 || d_zp != 0)) ||
                         (f_pc && (d_mult != 0 || d_shift != 0 || d_zp != 0));
    assign dim_bad     = (d_m == 0) || (32'(d_m) > ROWS) || (d_n == 0) || (32'(d_n) > COLS) ||
                         ((33'(dw3) + 33'(d_m)) > 33'h1_0000_0000);
    assign zp_bad      = f_rq && !f_pc && fmt8 && ((d_zp > 32'sd127) || (d_zp < -32'sd128));

    always_comb begin
        if (!ver_ok)                                       d_code = tensor_quantize_pkg::QR_VERSION;
        else if (!is_open && !is_close)                    d_code = tensor_quantize_pkg::QR_OPCODE;
        else if (!ctx_in)                                  d_code = tensor_quantize_pkg::QR_CTX;
        else if (is_close) begin
            if (d_rm != 0 || d_r0a || d_fl != 0 || d_fmt != 0 || d_r0b != 0 || d_r1 != 0 ||
                dw2 != 0 || dw3 != 0 || dw4 != 0 || dw5 != 0 || dw6 != 0 || dw7 != 0)
                                                           d_code = tensor_quantize_pkg::QR_RSVD;
            else if (!c_open[dsel] || c_tag[dsel] != d_tag) d_code = tensor_quantize_pkg::QR_STATE;
            else                                           d_code = tensor_quantize_pkg::QR_OK;
        end
        else if (rsvd_static)                              d_code = tensor_quantize_pkg::QR_RSVD;
        else if (d_fmt > tensor_quantize_pkg::OFMT_INT8)   d_code = tensor_quantize_pkg::QR_FMT;
        else if (d_rm > tensor_quantize_pkg::RM_RMM)       d_code = tensor_quantize_pkg::QR_RM;
        else if ((f_pc && !f_rq) || (f_wrap && d_fmt != tensor_quantize_pkg::OFMT_INT32))
                                                           d_code = tensor_quantize_pkg::QR_FLAGS;
        else if (rsvd_unused)                              d_code = tensor_quantize_pkg::QR_RSVD;
        else if (d_zb != 0 || (za_nz && ASYM_EN == 0))     d_code = tensor_quantize_pkg::QR_UNSUP;
        else if (dim_bad)                                  d_code = tensor_quantize_pkg::QR_DIM;
        else if (zp_bad)                                   d_code = tensor_quantize_pkg::QR_ZP;
        else if (uses_table && !grp_in)                    d_code = tensor_quantize_pkg::QR_CHAN;
        else if (uses_table && (lane_missing != 0))        d_code = tensor_quantize_pkg::QR_PARAM;
        else if (f_pc && (lane_pzp_bad != 0))              d_code = tensor_quantize_pkg::QR_PZP;
        else                                               d_code = tensor_quantize_pkg::QR_OK;
    end

    // an OPEN that can open (valid version, opcode, context) waits for its context to be free;
    // everything else is consumed at once.  desc_ready never depends on desc_valid.
    logic opener, d_acc, do_open, do_close, d_poison;
    assign opener     = ver_ok & is_open & ctx_in;
    assign desc_ready = run_q & (~opener | ~c_open[dsel]);
    assign d_acc      = desc_valid & desc_ready;
    assign do_open    = d_acc & opener;
    assign d_poison   = (d_code != tensor_quantize_pkg::QR_OK);
    assign do_close   = d_acc & ver_ok & is_close & ctx_in & ~d_poison;

    // ======================================================================
    // stage A: beat acceptance, context lookup, checks, bias
    // ======================================================================
    logic [CRW-1:0]   crd_q;          // free output-FIFO slots not yet reserved
    logic             b_ctx_ok, b_stall, b_acc, b_tag_ok, b_frame, b_zero, b_rel;
    logic [CTX_W-1:0] bsel;
    logic [2:0]       b_code;
    logic [COLS-1:0]  b_act;
    logic             ofifo_pop;

    assign b_ctx_ok = (32'(in_ctx) < NUM_CTX);
    assign bsel     = b_ctx_ok ? in_ctx : '0;
    assign b_stall  = b_ctx_ok & ~c_open[bsel];
    assign in_ready = run_q & (crd_q != '0) & ~b_stall;
    assign b_acc    = in_valid & in_ready;
    assign b_tag_ok = (c_tag[bsel] == in_tag);
    assign b_frame  = (32'(in_row) >= 32'(c_m[bsel])) || (in_col_mask != c_tmask[bsel]) ||
                      (in_last != (32'(in_row) == 32'(c_m[bsel]) - 1));

    always_comb begin
        if (!b_ctx_ok)           b_code = tensor_quantize_pkg::BE_NOCTX;
        else if (!b_tag_ok)      b_code = tensor_quantize_pkg::BE_TAG;
        else if (c_poison[bsel]) b_code = tensor_quantize_pkg::BE_POISON;
        else if (b_frame)        b_code = tensor_quantize_pkg::BE_FRAME;
        else if (in_err)         b_code = tensor_quantize_pkg::BE_UPSTREAM;
        else                     b_code = tensor_quantize_pkg::BE_NONE;
    end
    assign b_zero = (b_code == tensor_quantize_pkg::BE_NOCTX) || (b_code == tensor_quantize_pkg::BE_TAG) ||
                    (b_code == tensor_quantize_pkg::BE_POISON);
    assign b_act  = b_zero ? '0 : (in_col_mask & c_tmask[bsel]);
    // the tile's last beat releases its context (poisoned tiles too); tag must match
    assign b_rel  = b_acc & b_ctx_ok & b_tag_ok & in_last;

    // R1
    logic                 v1;
    logic [15:0]          r1_tag;
    logic [CTX_W-1:0]     r1_ctx;
    logic [RIDW-1:0]      r1_row;
    logic [31:0]          r1_m, r1_ch0;
    logic [COLS-1:0]      r1_mask, r1_act, r1_iovf;
    logic                 r1_last, r1_fmt8, r1_relu, r1_wrap;
    logic [2:0]           r1_rm, r1_code;
    logic [COLS*XW-1:0]   r1_x;
    logic [COLS*32-1:0]   r1_mult, r1_zp;
    logic [COLS*6-1:0]    r1_shift;

    logic [COLS*XW-1:0]   a_x;
    for (genvar j = 0; j < COLS; j++) begin : g_ax
        logic signed [IN_W-1:0] acc;
        logic signed [CW-1:0]   be;
        assign acc = in_data[j*IN_W +: IN_W];
        assign be  = c_beff[bsel][j*CW +: CW];
        assign a_x[j*XW +: XW] = b_act[j] ? (XW'(acc) + XW'(be)) : '0;   // exact: fits XW
    end

    always_ff @(posedge clk) begin
        if (!rst_n) v1 <= 1'b0;
        else        v1 <= b_acc;
        if (b_acc) begin
            r1_tag   <= in_tag;
            r1_ctx   <= in_ctx;
            r1_row   <= in_row;
            r1_mask  <= in_col_mask;
            r1_last  <= in_last;
            r1_iovf  <= in_ovf & in_col_mask;
            r1_code  <= b_code;
            r1_act   <= b_act;
            r1_m     <= b_zero ? 32'd0 : (c_m0[bsel] + 32'(in_row));
            r1_ch0   <= b_zero ? 32'd0 : c_ch0[bsel];
            r1_fmt8  <= b_zero ? 1'b0 : c_fmt8[bsel];
            r1_rm    <= c_rm[bsel];
            r1_relu  <= c_relu[bsel];
            r1_wrap  <= c_wrap[bsel];
            r1_x     <= a_x;
            r1_mult  <= c_mult[bsel];
            r1_shift <= c_shift[bsel];
            r1_zp    <= c_zp[bsel];
        end
    end

    // ======================================================================
    // stages B, C: lanes
    // ======================================================================
    logic                 v2;
    logic [15:0]          r2_tag;
    logic [CTX_W-1:0]     r2_ctx;
    logic [RIDW-1:0]      r2_row;
    logic [31:0]          r2_m, r2_ch0;
    logic [COLS-1:0]      r2_mask, r2_iovf;
    logic                 r2_last, r2_fmt8;
    logic [2:0]           r2_code;
    logic [COLS*32-1:0]   c_q;
    logic [COLS-1:0]      c_sat, c_relu_hit;

    for (genvar j = 0; j < COLS; j++) begin : g_lane
        tensor_quant_lane #(.XW(XW), .PW(PW), .YW(YW)) u_lane (
            .clk, .en(v1),
            .x(r1_x[j*XW +: XW]), .mult(r1_mult[j*32 +: 32]), .shift(r1_shift[j*6 +: 6]),
            .zp(r1_zp[j*32 +: 32]), .act(r1_act[j]), .fmt8(r1_fmt8), .rm(r1_rm),
            .relu(r1_relu), .wrap(r1_wrap),
            .q(c_q[j*32 +: 32]), .sat(c_sat[j]), .relu_hit(c_relu_hit[j]));
    end

    always_ff @(posedge clk) begin
        if (!rst_n) v2 <= 1'b0;
        else        v2 <= v1;
        if (v1) begin
            r2_tag  <= r1_tag;
            r2_ctx  <= r1_ctx;
            r2_row  <= r1_row;
            r2_m    <= r1_m;
            r2_ch0  <= r1_ch0;
            r2_mask <= r1_mask;
            r2_iovf <= r1_iovf;
            r2_last <= r1_last;
            r2_fmt8 <= r1_fmt8;
            r2_code <= r1_code;
        end
    end

    // ======================================================================
    // output FIFO (TENSORCORE 04 tensor_acc_fifo, reused unmodified) + credits
    // ======================================================================
    localparam int OFW = 16 + CTX_W + RIDW + 32 + 32 + COLS + 1 + 1 + 3 + COLS * 32 + COLS + COLS;
    logic [OFW-1:0]    of_din, of_dout;
    logic              of_empty;
    logic [CRW-1:0]    of_cnt;

    assign of_din = {r2_tag, r2_ctx, r2_row, r2_m, r2_ch0, r2_mask, r2_last, r2_fmt8, r2_code,
                     c_q, c_sat, r2_iovf};

    tensor_acc_fifo #(.WIDTH(OFW), .DEPTH(OFIFO_DEPTH)) u_ofifo (
        .clk, .rst_n, .push(v2), .din(of_din), .pop(ofifo_pop), .dout(of_dout),
        .empty(of_empty), .count(of_cnt));

    logic of_fmt8;
    assign out_valid = ~of_empty;
    assign ofifo_pop = out_valid & out_ready;
    assign {out_tag, out_ctx, out_row, out_m, out_ch0, out_col_mask, out_last, of_fmt8, out_err_code,
            out_data, out_sat, out_iovf} = of_dout;
    assign out_fmt = of_fmt8 ? tensor_quantize_pkg::OFMT_INT8 : tensor_quantize_pkg::OFMT_INT32;
    assign out_err = (out_err_code != tensor_quantize_pkg::BE_NONE);
    for (genvar j = 0; j < COLS; j++) begin : g_q8
        assign out_q8[j*8 +: 8] = out_data[j*32 +: 8];
    end

    // credits: a beat is accepted only with a reserved FIFO slot; returned on pop
    always_ff @(posedge clk) begin
        if (!rst_n) crd_q <= CRW'(OFIFO_DEPTH);
        else        crd_q <= crd_q - CRW'(b_acc) + CRW'(ofifo_pop);
    end

    assign idle = ~v1 & ~v2 & of_empty;

    // ======================================================================
    // context state
    // ======================================================================
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            c_open   <= '0;
            c_poison <= '0;
        end else begin
            for (int k = 0; k < NUM_CTX; k++) begin
                if (do_open && dsel == CTX_W'(k)) begin
                    c_open[k]   <= 1'b1;
                    c_poison[k] <= d_poison;
                end else if ((do_close && dsel == CTX_W'(k)) || (b_rel && bsel == CTX_W'(k))) begin
                    c_open[k]   <= 1'b0;
                    c_poison[k] <= 1'b0;
                end
            end
        end
    end

    // snapshot: written when a context opens (contents of a poisoned context are never used)
    always_ff @(posedge clk) begin
        for (int k = 0; k < NUM_CTX; k++) begin
            if (do_open && dsel == CTX_W'(k)) begin
                c_tag[k]   <= d_tag;
                c_m[k]     <= d_poison ? MW'(0) : MW'(d_m);
                c_tmask[k] <= d_poison ? '0 : lane_in;
                c_m0[k]    <= dw3;
                c_ch0[k]   <= 32'(d_grp) * 32'(COLS);
                c_fmt8[k]  <= fmt8;
                c_rm[k]    <= d_rm;
                c_relu[k]  <= f_relu;
                c_wrap[k]  <= f_wrap;
                c_beff[k]  <= d_poison ? '0 : s_beff;
                c_mult[k]  <= d_poison ? '0 : s_mult;
                c_shift[k] <= d_poison ? '0 : s_shift;
                c_zp[k]    <= d_poison ? '0 : s_zp;
            end
        end
    end

    // ======================================================================
    // responses and sticky errors
    // ======================================================================
    always_ff @(posedge clk) begin
        if (!rst_n) begin
            desc_ok          <= 1'b0;
            desc_rej         <= 1'b0;
            desc_rej_code    <= '0;
            p_err            <= 1'b0;
            p_err_code       <= '0;
            desc_err_sticky  <= '0;
            beat_err_sticky  <= '0;
            param_err_sticky <= '0;
        end else begin
            desc_ok       <= d_acc & ~d_poison;
            desc_rej      <= d_acc & d_poison;
            desc_rej_code <= d_acc ? d_code : 4'd0;
            p_err         <= pw_err;
            p_err_code    <= pw_err ? pw_code : 2'd0;
            if (d_acc && d_poison) desc_err_sticky[d_code] <= 1'b1;
            if (b_acc && b_code != tensor_quantize_pkg::BE_NONE) beat_err_sticky[b_code] <= 1'b1;
            if (pw_err) param_err_sticky[pw_code] <= 1'b1;
        end
    end

    // ======================================================================
    // performance counters
    // ======================================================================
    function automatic logic [EVW-1:0] popc(input logic [COLS-1:0] v);
        popc = '0;
        for (int i = 0; i < COLS; i++) popc = popc + EVW'(v[i]);
    endfunction

    logic [NPERF*EVW-1:0] ev;
    always_comb begin
        ev = '0;
        ev[tensor_quantize_pkg::PF_BEATS_IN  * EVW +: EVW] = EVW'(b_acc);
        ev[tensor_quantize_pkg::PF_BEATS_OUT * EVW +: EVW] = EVW'(ofifo_pop);
        ev[tensor_quantize_pkg::PF_ELEMS     * EVW +: EVW] = b_acc ? popc(b_act) : '0;
        ev[tensor_quantize_pkg::PF_SAT       * EVW +: EVW] = v2 ? popc(c_sat) : '0;
        ev[tensor_quantize_pkg::PF_RELU      * EVW +: EVW] = v2 ? popc(c_relu_hit) : '0;
        ev[tensor_quantize_pkg::PF_BEAT_ERR  * EVW +: EVW] = EVW'({b_acc && b_code != tensor_quantize_pkg::BE_NONE});
        ev[tensor_quantize_pkg::PF_DESC_OK   * EVW +: EVW] = EVW'({d_acc & ~d_poison});
        ev[tensor_quantize_pkg::PF_DESC_REJ  * EVW +: EVW] = EVW'({d_acc & d_poison});
        ev[tensor_quantize_pkg::PF_PARAM_WR  * EVW +: EVW] = EVW'(pw_ok);
        ev[tensor_quantize_pkg::PF_PARAM_REJ * EVW +: EVW] = EVW'(pw_err);
        ev[tensor_quantize_pkg::PF_IN_STALL  * EVW +: EVW] = EVW'({in_valid & ~in_ready});
        ev[tensor_quantize_pkg::PF_CTX_WAIT  * EVW +: EVW] = EVW'({in_valid & b_stall});
        ev[tensor_quantize_pkg::PF_OUT_STALL * EVW +: EVW] = EVW'({out_valid & ~out_ready});
    end

    if (PERF_EN != 0) begin : g_perf
        logic [PERF_W-1:0] cnt [NPERF];
        always_ff @(posedge clk) begin
            for (int i = 0; i < NPERF; i++) begin
                if (!rst_n || perf_clr) cnt[i] <= '0;
                else begin
                    logic [PERF_W:0] s;
                    s = {1'b0, cnt[i]} + (PERF_W + 1)'(ev[i*EVW +: EVW]);
                    cnt[i] <= s[PERF_W] ? {PERF_W{1'b1}} : s[PERF_W-1:0];
                end
            end
        end
        for (genvar i = 0; i < NPERF; i++) begin : g_o
            assign perf_o[i*PERF_W +: PERF_W] = cnt[i];
        end
    end else begin : g_noperf
        assign perf_o = '0;
        /* verilator lint_off UNUSEDSIGNAL */
        logic unused_perf;
        assign unused_perf = ^{ev, perf_clr};
        /* verilator lint_on UNUSEDSIGNAL */
    end

    // ======================================================================
    // simulation invariants (compiled out with +define+TQ_NO_INVARIANTS for
    // mutation testing, so that only the testbench can kill a mutant)
    // ======================================================================
    // synthesis translate_off
`ifndef TQ_NO_INVARIANTS
    always @(posedge clk) begin
        if (rst_n === 1'b1 && run_q === 1'b1) begin
            if (32'(crd_q) + 32'(of_cnt) + 32'(v1) + 32'(v2) != OFIFO_DEPTH)
                $error("%m: credit invariant broken: crd=%0d fifo=%0d v1=%0d v2=%0d", crd_q, of_cnt, v1, v2);
            if (do_open && c_open[dsel]) $error("%m: OPEN of a busy context");
            if (b_acc && b_ctx_ok && !c_open[bsel]) $error("%m: beat accepted on a closed context");
        end
    end
`endif
    // synthesis translate_on

endmodule
