#!/usr/bin/env python3
"""
SilicaFlux TENSORCORE 05 -- independent integer reference model.
Aureom.AI | SilicaFlux-HPC

This file is the executable form of docs/NUMERIC_FORMAT.md.  It is written
independently of the RTL:

  * values are unbounded Python integers (no widths, no masks, no wrap);
  * every division by 2^S is done on an exact fractions.Fraction and rounded by
    the textbook definition of each mode (Python's round() on a Fraction is
    round-half-to-even; floor/ceil/trunc come from math).  The RTL instead uses
    an arithmetic shift plus guard/sticky bits.  The two are compared bit for
    bit by the testbenches;
  * the asymmetric-input GEMM reference (qgemm_direct) evaluates
    sum_k (A[m,k] - zA) * B[k,n] literally, never through the correction
    identity that the hardware uses.

Standard library only (Python >= 3.8).

Element contract (per output element, all integers exact):

    x  = acc + bias[n] - zA * colsum[n]                  (bias, colsum optional)
    y  = R_rm( x * M[n] / 2^S[n] ) + zp[n]      if RQ_EN
       = x                                      otherwise
    q  = clamp(y, qmin, qmax)                   (or y mod 2^32 if WRAP, INT32 only)
    q  = max(q, zp[n] if RQ_EN else 0)          if RELU
    sat = (y < qmin) or (y > qmax)
"""
from fractions import Fraction
import math

# ----------------------------------------------------------------------------- ABI constants
VERSION = 1
OP_OPEN = 0x40          # open an output-tile context (class 0x4X: tensor output conversion)
OP_CLOSE = 0x41         # release a context without beats (after an upstream abort)

# rounding modes: Module 02 / RISC-V frm encoding, reused unchanged
RM_RNE, RM_RTZ, RM_RDN, RM_RUP, RM_RMM = 0, 1, 2, 3, 4
RM_NAMES = {RM_RNE: "RNE", RM_RTZ: "RTZ", RM_RDN: "RDN", RM_RUP: "RUP", RM_RMM: "RMM"}

FL_BIAS, FL_RQ, FL_PC, FL_RELU, FL_WRAP = 0x01, 0x02, 0x04, 0x08, 0x10
FL_ALL = 0x1F

OFMT_INT32, OFMT_INT8 = 0, 1
FMT_RANGE = {OFMT_INT32: (-(1 << 31), (1 << 31) - 1), OFMT_INT8: (-128, 127)}

# descriptor reject codes (desc_rej_code); first failing rule wins
QR_OK, QR_VERSION, QR_OPCODE, QR_CTX, QR_RSVD, QR_STATE, QR_FMT, QR_RM, QR_FLAGS, \
    QR_UNSUP, QR_DIM, QR_ZP, QR_CHAN, QR_PARAM, QR_PZP = range(15)
QR_NAMES = ["OK", "VERSION", "OPCODE", "CTX", "RSVD", "STATE", "FMT", "RM", "FLAGS",
            "UNSUP", "DIM", "ZP", "CHAN", "PARAM", "PZP"]
HARD_REJECTS = (QR_VERSION, QR_OPCODE, QR_CTX)     # nothing is opened

# beat error codes (out_err_code), priority order
BE_NONE, BE_NOCTX, BE_TAG, BE_POISON, BE_FRAME, BE_UPSTREAM = range(6)
BE_NAMES = ["NONE", "NOCTX", "TAG", "POISON", "FRAME", "UPSTREAM"]

# parameter write
FM_BIAS, FM_MULT, FM_SHIFT, FM_ZP, FM_CS = 0x01, 0x02, 0x04, 0x08, 0x10
PW_OK, PW_GRP, PW_UNSUP = 0, 1, 2

# performance counter indices
PF_BEATS_IN, PF_BEATS_OUT, PF_ELEMS, PF_SAT, PF_RELU, PF_BEAT_ERR, PF_DESC_OK, PF_DESC_REJ, \
    PF_PARAM_WR, PF_PARAM_REJ, PF_IN_STALL, PF_CTX_WAIT, PF_OUT_STALL = range(13)
NPERF = 13
PF_NAMES = ["BEATS_IN", "BEATS_OUT", "ELEMS", "SAT", "RELU", "BEAT_ERR", "DESC_OK", "DESC_REJ",
            "PARAM_WR", "PARAM_REJ", "IN_STALL", "CTX_WAIT", "OUT_STALL"]

MULT_W, SHIFT_W, ZP_W, BIAS_W, ZA_W, OUT_W = 32, 6, 32, 32, 8, 32
SHIFT_MAX = (1 << SHIFT_W) - 1      # 63


# ----------------------------------------------------------------------------- integer helpers
def sx(v, w):
    """Interpret the low w bits of v as two's complement."""
    v &= (1 << w) - 1
    return v - (1 << w) if v >> (w - 1) else v


def ux(v, w):
    return v & ((1 << w) - 1)


def srange(w):
    return -(1 << (w - 1)), (1 << (w - 1)) - 1


def fits(v, w):
    lo, hi = srange(w)
    return lo <= v <= hi


# ----------------------------------------------------------------------------- rounding
def round_rational(f, rm):
    """Round an exact rational to an integer by the definition of mode rm."""
    if not isinstance(f, Fraction):
        f = Fraction(f)
    if rm == RM_RNE:
        return round(f)                      # Fraction.__round__: nearest, ties to even
    if rm == RM_RTZ:
        return math.trunc(f)
    if rm == RM_RDN:
        return math.floor(f)
    if rm == RM_RUP:
        return math.ceil(f)
    if rm == RM_RMM:                         # nearest, ties away from zero
        fl = math.floor(f)
        d = f - fl
        if d > Fraction(1, 2):
            return fl + 1
        if d < Fraction(1, 2):
            return fl
        return fl + 1 if f > 0 else fl
    raise ValueError("illegal rounding mode %d" % rm)


def rescale(x, mult, shift, rm):
    """R_rm(x * mult / 2^shift), exact."""
    return round_rational(Fraction(x * mult, 1 << shift), rm)


# ----------------------------------------------------------------------------- element contract
def element(acc, bias=0, za=0, colsum=0, mult=1, shift=0, zp=0, rq=False, ofmt=OFMT_INT32,
            wrap=False, relu=False, rm=RM_RNE):
    """One output element.  Returns (q, sat, relu_hit).  Literal contract, no widths."""
    x = acc + bias - za * colsum
    if rq:
        y = rescale(x, mult, shift, rm) + zp
        floor = zp
    else:
        y = x
        floor = 0
    lo, hi = FMT_RANGE[ofmt]
    sat = (y < lo) or (y > hi)
    if wrap:
        assert ofmt == OFMT_INT32
        q = sx(y, 32)
    else:
        q = min(max(y, lo), hi)
    relu_hit = bool(relu and q < floor)
    if relu:
        q = max(q, floor)
    return q, sat, relu_hit


# ----------------------------------------------------------------------------- widths (design)
def widths(in_w, asym_en):
    """Intermediate widths used by the RTL (tensor_quantize_pkg).  Their sufficiency is
    *checked*, not assumed, by tests/test_ref_model.py (extreme-value enumeration)."""
    # bias_eff = bias - zA*colsum.  |zA*colsum| <= 2^7 * 2^(IN_W-1) = 2^(IN_W+6), |bias| <= 2^31
    cw = in_w + 8 if asym_en else BIAS_W
    # x = acc + bias_eff.  ASYM: |x| < 2^(IN_W-1) + 2^31 + 2^(IN_W+6) <= 2^(IN_W+7)  (IN_W >= 32)
    #                      else: |x| <= 2^(IN_W-1) + 2^31 <= 2^IN_W
    xw = in_w + 8 if asym_en else in_w + 1
    pw = xw + MULT_W                            # p = x * M
    yw = pw + 1                                 # y = R(p / 2^S) + zp
    return dict(CW=cw, XW=xw, PW=pw, YW=yw)


# ----------------------------------------------------------------------------- software helper
def quantize_multiplier(scale, shift_max=SHIFT_MAX):
    """Software-side conversion of a real scale to (M, S): scale ~= M / 2^S, with M a signed
    32-bit integer and 0 <= S <= shift_max.  Picks the largest S whose rounded M still fits,
    i.e. the most precise representation.  This runs on the host; the RTL never sees a real."""
    f = Fraction(scale)
    if f == 0:
        return 0, 0
    lo, hi = srange(MULT_W)
    best = None
    for s in range(shift_max, -1, -1):
        m = round(f * (1 << s))
        if lo <= m <= hi:
            best = (m, s)
            break
    if best is None:
        raise ValueError("scale %r not representable (|scale| >= 2^31)" % scale)
    return best


# ----------------------------------------------------------------------------- descriptor ABI
def encode_desc(op=OP_OPEN, ver=VERSION, rm=RM_RNE, flags=0, ofmt=OFMT_INT32, tag=0, ctx=0,
                m=1, n=1, grp=0, m0=0, mult=0, shift=0, za=0, zb=0, zp=0,
                rsvd=None):
    """Pack a 256-bit descriptor as 8 little-endian 32-bit words (word 0 first).
    `rsvd` = dict(word -> OR mask) to poke reserved bits for negative tests."""
    w = [0] * 8
    w[0] = (op & 0xFF) | ((ver & 0xF) << 8) | ((rm & 0x7) << 12) | ((flags & 0xFF) << 16) | \
           ((ofmt & 0xF) << 24)
    w[1] = (tag & 0xFFFF) | ((ctx & 0xFF) << 16)
    w[2] = (m & 0xFF) | ((n & 0xFF) << 8) | ((grp & 0xFFFF) << 16)
    w[3] = m0 & 0xFFFFFFFF
    w[4] = mult & 0xFFFFFFFF
    w[5] = (shift & 0x3F) | ((za & 0xFF) << 8) | ((zb & 0xFF) << 16)
    w[6] = zp & 0xFFFFFFFF
    w[7] = 0
    if rsvd:
        for k, v in rsvd.items():
            w[k] |= v
    return w


def decode_desc(w):
    h = w[0]
    return dict(op=h & 0xFF, ver=(h >> 8) & 0xF, rm=(h >> 12) & 0x7, r0a=(h >> 15) & 1,
                flags=(h >> 16) & 0xFF, ofmt=(h >> 24) & 0xF, r0b=h >> 28,
                tag=w[1] & 0xFFFF, ctx=(w[1] >> 16) & 0xFF, r1=w[1] >> 24,
                m=w[2] & 0xFF, n=(w[2] >> 8) & 0xFF, grp=w[2] >> 16,
                m0=w[3], mult=sx(w[4], 32), shift=w[5] & 0x3F, r5a=(w[5] >> 6) & 3,
                za=sx((w[5] >> 8) & 0xFF, 8), zb=(w[5] >> 16) & 0xFF, r5b=w[5] >> 24,
                zp=sx(w[6], 32), r7=w[7], words=list(w))


# ----------------------------------------------------------------------------- architectural model
class Config:
    def __init__(self, rows=4, cols=4, in_w=32, num_ctx=2, num_grp=16, asym_en=0):
        self.rows, self.cols, self.in_w = rows, cols, in_w
        self.num_ctx, self.num_grp, self.asym_en = num_ctx, num_grp, asym_en
        self.w = widths(in_w, asym_en)


class Snap:
    """Context snapshot taken when a descriptor is accepted (the RTL copies the same values)."""
    def __init__(self, **kw):
        self.__dict__.update(kw)


class TQModel:
    def __init__(self, cfg):
        self.c = cfg
        self.reset()

    def reset(self):
        c = self.c
        self.val = [[dict(bias=0, mult=0, shift=0, zp=0, cs=0) for _ in range(c.cols)]
                    for _ in range(c.num_grp)]
        self.vld = [[0] * c.cols for _ in range(c.num_grp)]     # bit mask of FM_* per lane
        self.ctx = [None] * c.num_ctx                           # open Snap or None

    # ---------------------------------------------------------------- parameter port
    def param_write(self, grp, lane_mask, fmask, lanes):
        """lanes[j] = dict(bias, mult, shift, zp, cs).  Returns PW_* code."""
        c = self.c
        if grp >= c.num_grp:
            return PW_GRP
        if (fmask & FM_CS) and not c.asym_en:
            return PW_UNSUP
        for j in range(c.cols):
            if not (lane_mask >> j) & 1:
                continue
            e, l = self.val[grp][j], lanes[j]
            if fmask & FM_BIAS:
                e["bias"] = sx(l["bias"], BIAS_W)
            if fmask & FM_MULT:
                e["mult"] = sx(l["mult"], MULT_W)
            if fmask & FM_SHIFT:
                e["shift"] = ux(l["shift"], SHIFT_W)
            if fmask & FM_ZP:
                e["zp"] = sx(l["zp"], ZP_W)
            if fmask & FM_CS:
                e["cs"] = sx(l["cs"], c.in_w)
            self.vld[grp][j] |= fmask & 0x1F
        return PW_OK

    # ---------------------------------------------------------------- descriptor port
    def desc(self, words):
        """Returns (code, kind, snap).  kind: 'none' | 'open' | 'poison' | 'close'.
        Caller guarantees an OPEN targets a free context (the RTL backpressures otherwise)."""
        c = self.c
        d = decode_desc(words)
        if d["ver"] != VERSION:
            return QR_VERSION, "none", None
        if d["op"] not in (OP_OPEN, OP_CLOSE):
            return QR_OPCODE, "none", None
        if d["ctx"] >= c.num_ctx:
            return QR_CTX, "none", None
        k = d["ctx"]
        if d["op"] == OP_CLOSE:
            if d["rm"] or d["r0a"] or d["flags"] or d["ofmt"] or d["r0b"] or d["r1"] or \
               any(words[2:8]):
                return QR_RSVD, "none", None
            s = self.ctx[k]
            if s is None or s.tag != d["tag"]:
                return QR_STATE, "none", None
            self.ctx[k] = None
            return QR_OK, "close", None
        assert self.ctx[k] is None, "model: OPEN on a busy context (RTL would wait)"
        fl = d["flags"]
        bias_en, rq, pc = bool(fl & FL_BIAS), bool(fl & FL_RQ), bool(fl & FL_PC)
        relu, wrap = bool(fl & FL_RELU), bool(fl & FL_WRAP)
        M, N, grp, za, ofmt = d["m"], d["n"], d["grp"], d["za"], d["ofmt"]
        uses_table = bias_en or pc or za != 0
        need = (FM_BIAS if bias_en else 0) | ((FM_MULT | FM_SHIFT | FM_ZP) if pc else 0) | \
               (FM_CS if za != 0 else 0)
        code = QR_OK
        if d["r0a"] or d["r0b"] or (fl & ~FL_ALL & 0xFF) or d["r1"] or d["r5a"] or d["r5b"] or d["r7"]:
            code = QR_RSVD
        elif ofmt not in FMT_RANGE:
            code = QR_FMT
        elif d["rm"] > RM_RMM:
            code = QR_RM
        elif (pc and not rq) or (wrap and ofmt != OFMT_INT32):
            code = QR_FLAGS
        elif (not rq and (d["rm"] or d["mult"] or d["shift"] or d["zp"])) or \
             (pc and (d["mult"] or d["shift"] or d["zp"])):
            code = QR_RSVD
        elif d["zb"] != 0 or (za != 0 and not c.asym_en):
            code = QR_UNSUP
        elif not (1 <= M <= c.rows) or not (1 <= N <= c.cols) or d["m0"] + M - 1 > 0xFFFFFFFF:
            code = QR_DIM
        elif rq and not pc and not (FMT_RANGE[ofmt][0] <= d["zp"] <= FMT_RANGE[ofmt][1]):
            code = QR_ZP
        elif uses_table and grp >= c.num_grp:
            code = QR_CHAN
        elif uses_table and any((self.vld[grp][j] & need) != need for j in range(N)):
            code = QR_PARAM
        elif pc and any(not (FMT_RANGE[ofmt][0] <= self.val[grp][j]["zp"] <= FMT_RANGE[ofmt][1])
                        for j in range(N)):
            code = QR_PZP
        if code != QR_OK:
            s = Snap(tag=d["tag"], poison=True, code=code)
            self.ctx[k] = s
            return code, "poison", s
        lanes = []
        for j in range(c.cols):
            if j < N:
                e = self.val[grp][j] if uses_table else None
                lanes.append(dict(
                    bias=e["bias"] if bias_en else 0,
                    cs=e["cs"] if za != 0 else 0,
                    mult=(e["mult"] if pc else d["mult"]) if rq else 1,
                    shift=(e["shift"] if pc else d["shift"]) if rq else 0,
                    zp=(e["zp"] if pc else d["zp"]) if rq else 0))
            else:
                lanes.append(None)
        s = Snap(tag=d["tag"], poison=False, code=QR_OK, M=M, N=N, m0=d["m0"],
                 ch0=grp * c.cols, ofmt=ofmt, rm=d["rm"], rq=rq, relu=relu, wrap=wrap, za=za,
                 lanes=lanes)
        self.ctx[k] = s
        return QR_OK, "open", s

    # ---------------------------------------------------------------- beats
    def release_if_last(self, ctx, tag, last):
        if ctx < self.c.num_ctx and self.ctx[ctx] is not None and self.ctx[ctx].tag == tag and last:
            self.ctx[ctx] = None

    def eval_beat(self, snap, ctx, tag, row, col_mask, last, err, data, ovf):
        """Expected output beat.  `snap` is the context the beat meets (None if ctx is out of
        range).  The caller (generator) knows which tile a context holds when the beat is
        processed; see tools/gen_unit.py for the ordering rules that make this deterministic."""
        c = self.c
        cm = (1 << c.cols) - 1
        out = dict(tag=tag, ctx=ctx, row=row, col_mask=col_mask & cm, last=last,
                   iovf=ovf & col_mask & cm, data=[0] * c.cols, sat=0, relu=0, active=0,
                   m=0, ch0=0, fmt=0, err=0, code=BE_NONE)
        if ctx >= c.num_ctx:
            out.update(err=1, code=BE_NOCTX)
            return out
        assert snap is not None
        if snap.tag != tag:
            out.update(err=1, code=BE_TAG)
            return out
        if snap.poison:
            out.update(err=1, code=BE_POISON)
            return out
        tmask = (1 << snap.N) - 1
        code = BE_NONE
        if row >= snap.M or (col_mask & cm) != tmask or bool(last) != (row == snap.M - 1):
            code = BE_FRAME
        elif err:
            code = BE_UPSTREAM
        out.update(err=int(code != BE_NONE), code=code, m=(snap.m0 + row) & 0xFFFFFFFF,
                   ch0=snap.ch0, fmt=snap.ofmt)
        for j in range(c.cols):
            if not ((col_mask >> j) & 1 and (tmask >> j) & 1):
                continue
            l = snap.lanes[j]
            q, sat, rh = element(data[j], bias=l["bias"], za=snap.za, colsum=l["cs"],
                                 mult=l["mult"], shift=l["shift"], zp=l["zp"], rq=snap.rq,
                                 ofmt=snap.ofmt, wrap=snap.wrap, relu=snap.relu, rm=snap.rm)
            out["data"][j] = q
            out["sat"] |= int(sat) << j
            out["relu"] |= int(rh) << j
            out["active"] += 1
        return out


# ----------------------------------------------------------------------------- GEMM references
def qgemm_direct(A, B, za=0, bias=None, mult=None, shift=None, zp=None, rq=True,
                 ofmt=OFMT_INT8, relu=False, rm=RM_RNE, wrap=False):
    """Quantised GEMM, evaluated literally:
         acc_true[m][n] = sum_k (A[m][k] - za) * B[k][n]      (weights symmetric: zB = 0)
         then bias / requantise / activate per channel n.
    bias/mult/shift/zp are per-channel lists (len N).  Returns (Q, SAT) as lists of lists."""
    M, K, N = len(A), len(B), len(B[0])
    bias = bias or [0] * N
    Q, SAT = [], []
    for m in range(M):
        qr, sr = [], []
        for n in range(N):
            acc = 0
            for k in range(K):
                acc += (A[m][k] - za) * B[k][n]
            q, s, _ = element(acc, bias=bias[n], mult=mult[n] if rq else 1,
                              shift=shift[n] if rq else 0, zp=zp[n] if rq else 0, rq=rq,
                              ofmt=ofmt, wrap=wrap, relu=relu, rm=rm)
            qr.append(q)
            sr.append(s)
        Q.append(qr)
        SAT.append(sr)
    return Q, SAT


def colsum(B):
    """Weight column sums sum_k B[k][n]: the only extra statistic the zA correction needs."""
    return [sum(B[k][n] for k in range(len(B))) for n in range(len(B[0]))]


def float_requant(acc, real_scale, zp, ofmt=OFMT_INT8):
    """INFORMATIONAL ONLY: requantisation with the real-valued scale (float64 product,
    round-half-even).  Used to report how close the fixed-point contract is to the ideal real
    scale on representative data.  Never a pass/fail criterion."""
    y = round(acc * real_scale) + zp
    lo, hi = FMT_RANGE[ofmt]
    return min(max(y, lo), hi)
