// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_tile_agu
// Tile address-generation unit: validates one tile descriptor and turns it into
// the per-lane / per-row byte addresses the fetch engines use.
//
// Matrix contract (row-major, INT8, every address in BYTES, relative to the
// start of the set's A or B region):
//   A[r][c] at  a_addr + r * lda + c        (A is mat_m x mat_k, lda >= mat_k)
//   B[r][c] at  b_addr + r * ldb + c        (B is mat_k x mat_n, ldb >= mat_n)
// A tile = origin (m0, n0, k0) and tile_k:
//   eff_m = min(ARRAY_ROWS, mat_m - m0)      live A lanes  (row mask)
//   eff_n = min(ARRAY_COLS, mat_n - n0)      live B lanes  (column mask)
//   eff_k = min(tile_k,     mat_k - k0)      k-slices delivered
//   slice k (0 <= k < eff_k):  lane i <  eff_m : A[m0+i][k0+k]   else 0
//                              lane j <  eff_n : B[k0+k][n0+j]   else 0
//
// Sequence (one shared multiplier; latency 8 + ARRAY_ROWS cycles, hidden by
// the two-entry context queue while the previous tile streams):
//   IDLE  accept (latches descriptor, compute-set index and ownership)
//   CHK   eff_m/n/k; OWNER > EMPTY > LD errors
//   M0    A0    = a_addr + m0*lda + k0                       (first A byte)
//   M1    Alast = a_addr + (m0+eff_m-1)*lda + k0 + eff_k-1   (last A byte)
//   M2    B0    = b_addr + k0*ldb + n0                       (first B byte)
//   M3    Blast = b_addr + (k0+eff_k-1)*ldb + n0 + eff_n-1   (last B byte)
//   RCHK  A_OVF (Alast >= 2^ADDR_W) > A_RANGE (Alast >= A_SET_BYTES) > B_OVF > B_RANGE
//   LANE  ARRAY_ROWS cycles: lane i start = A0 + i*lda  ->  word, byte offset
//   OUT   result offered until accepted
// Arithmetic is XW = ADDR_W + MW + 2 bits wide, which cannot wrap for any
// input, so overflow is DETECTED (never silently wrapped).  Because addresses
// grow with r and c (lda, ldb >= 0), checking the last byte of A and of B
// bounds every byte the tile touches.  Error tiles touch no memory.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tob_defs.svh"
`default_nettype none

module tob_tile_agu #(
  parameter int  R           = 4,
  parameter int  C           = 4,
  parameter int  WB          = 4,
  parameter int  ADDR_W      = 32,
  parameter int  IDX_W       = 16,
  parameter int  K_W         = 17,
  parameter int  TAG_W       = 8,
  parameter int  A_SET_BYTES = 4096,
  parameter int  B_SET_BYTES = 4096,
  parameter int  NUM_SETS    = 2,
  localparam int LWB         = (WB > 1) ? $clog2(WB) : 1,   // (clamped: WB = 1 is rejected below)
  localparam int SW          = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int ABW         = $clog2(A_SET_BYTES),
  localparam int BBW         = $clog2(B_SET_BYTES),
  localparam int AWW         = ABW - LWB,
  localparam int RMW         = $clog2(R + 1),
  localparam int CNW         = $clog2(C + 1),
  localparam int MW          = ((IDX_W > K_W) ? IDX_W : K_W) + 1,
  localparam int XW          = ADDR_W + MW + 2,
  localparam int LIW         = (R > 1) ? $clog2(R) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // ---------------------------------------------------------- descriptor
  input  wire logic                  tile_valid,
  output logic                       tile_ready,
  input  wire logic [ADDR_W-1:0]     t_a_addr,
  input  wire logic [ADDR_W-1:0]     t_lda,
  input  wire logic [ADDR_W-1:0]     t_b_addr,
  input  wire logic [ADDR_W-1:0]     t_ldb,
  input  wire logic [IDX_W-1:0]      t_m0,
  input  wire logic [IDX_W-1:0]      t_n0,
  input  wire logic [K_W-1:0]        t_k0,
  input  wire logic [IDX_W-1:0]      t_mat_m,
  input  wire logic [IDX_W-1:0]      t_mat_n,
  input  wire logic [K_W-1:0]        t_mat_k,
  input  wire logic [K_W-1:0]        t_k,
  input  wire logic [TAG_W-1:0]      t_tag,
  input  wire logic                  accept_en,      // low: a release of the compute set is pending
  input  wire logic                  owner_ok,       // compute set is in COMPUTE state
  input  wire logic [SW-1:0]         cur_set,
  output logic                       busy,
  // ---------------------------------------------------------- result
  output logic                       out_valid,
  input  wire logic                  out_ready,
  output logic                       out_err,
  output logic      [3:0]            out_code,
  output logic      [SW-1:0]         out_set,
  output logic      [RMW-1:0]        out_m,
  output logic      [CNW-1:0]        out_n,
  output logic      [K_W-1:0]        out_k,
  output logic      [R*AWW-1:0]      out_w0,         // lane i: first word (in-set word index)
  output logic      [R*LWB-1:0]      out_off0,       // lane i: byte offset of A[m0+i][k0] in that word
  output logic      [BBW-1:0]        out_b0,         // in-set byte address of B[k0][n0]
  output logic      [BBW-1:0]        out_ldb,        // ldb modulo the B set size (exact for every live row)
  output logic      [IDX_W-1:0]      out_m0,
  output logic      [IDX_W-1:0]      out_n0,
  output logic      [K_W-1:0]        out_k0,
  output logic      [TAG_W-1:0]      out_tag
);

  // checked first: with WB = 1 the byte-offset fields below would be zero-width
  if (WB < 2 || (1 << LWB) != WB) begin : g_err_wb
    `SRAM_CFG_FATAL("tob_tile_agu: WORD_BYTES must be a power of two >= 2")
  end

  localparam logic [3:0] S_IDLE = 4'd0, S_CHK = 4'd1, S_M0 = 4'd2, S_M1 = 4'd3, S_M2 = 4'd4,
                         S_M3 = 4'd5, S_RCHK = 4'd6, S_LANE = 4'd7, S_OUT = 4'd8;

  logic [3:0]        st_q;
  logic              alive_q;
  // latched descriptor
  logic [ADDR_W-1:0] a_addr_q, lda_q, b_addr_q, ldb_q;
  logic [IDX_W-1:0]  m0_q, n0_q, mat_m_q, mat_n_q;
  logic [K_W-1:0]    k0_q, mat_k_q, tk_q;
  logic [TAG_W-1:0]  tag_q;
  logic              own_q;
  logic [SW-1:0]     set_q;
  // results
  logic [RMW-1:0]    em_q;
  logic [CNW-1:0]    en_q;
  logic [K_W-1:0]    ek_q;
  logic [3:0]        code_q;
  logic [XW-1:0]     alast_q, blast_q;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [XW-1:0]     a0_q, b0_q;          // only the in-set bits are used (range already checked)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [ABW-1:0]    acc_q;
  logic [LIW-1:0]    li_q;
  logic [R*AWW-1:0]  w0_q;
  logic [R*LWB-1:0]  off0_q;

  assign tile_ready = alive_q && (st_q == S_IDLE) && accept_en;
  wire   accept     = tile_valid && tile_ready;
  assign busy       = (st_q != S_IDLE);

  // ------------------------------------------------------------ CHK: effective sizes and early errors
  logic             empty_c, ld_c;
  logic [IDX_W-1:0] mrem_c, nrem_c;
  logic [K_W-1:0]   krem_c;
  logic [RMW-1:0]   em_c;
  logic [CNW-1:0]   en_c;
  logic [K_W-1:0]   ek_c;
  always_comb begin
    empty_c = (m0_q >= mat_m_q) || (n0_q >= mat_n_q) || (k0_q >= mat_k_q) || (tk_q == '0);
    ld_c    = (lda_q < ADDR_W'(mat_k_q)) || (ldb_q < ADDR_W'(mat_n_q));
    mrem_c  = mat_m_q - m0_q;
    nrem_c  = mat_n_q - n0_q;
    krem_c  = mat_k_q - k0_q;
    em_c    = (32'(mrem_c) >= R) ? RMW'(R) : RMW'(mrem_c);
    en_c    = (32'(nrem_c) >= C) ? CNW'(C) : CNW'(nrem_c);
    ek_c    = (tk_q <= krem_c) ? tk_q : krem_c;
  end

  // ------------------------------------------------------------ shared multiplier
  logic [MW-1:0]        mx;
  logic [ADDR_W-1:0]    my;
  logic [MW+ADDR_W-1:0] prod;
  always_comb begin
    mx = '0;
    my = lda_q;
    case (st_q)
      S_M0:    begin mx = MW'(m0_q);                                  my = lda_q; end
      S_M1:    begin mx = MW'(m0_q) + MW'(em_q) - MW'(1);             my = lda_q; end
      S_M2:    begin mx = MW'(k0_q);                                  my = ldb_q; end
      S_M3:    begin mx = MW'(k0_q) + MW'(ek_q) - MW'(1);             my = ldb_q; end
      default: begin mx = '0;                                         my = lda_q; end
    endcase
    prod = (MW+ADDR_W)'(mx) * (MW+ADDR_W)'(my);
  end
  wire [XW-1:0] prod_x = XW'(prod);

  // ------------------------------------------------------------ RCHK: overflow / range
  logic [3:0] rcode_c;
  always_comb begin
    if (alast_q[XW-1:ADDR_W] != '0)                rcode_c = `TOB_TERR_A_OVF;
    else if (alast_q >= XW'(A_SET_BYTES))          rcode_c = `TOB_TERR_A_RANGE;
    else if (blast_q[XW-1:ADDR_W] != '0)           rcode_c = `TOB_TERR_B_OVF;
    else if (blast_q >= XW'(B_SET_BYTES))          rcode_c = `TOB_TERR_B_RANGE;
    else                                           rcode_c = `TOB_TERR_OK;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q    <= S_IDLE;
      alive_q <= 1'b0;
    end else begin
      alive_q <= 1'b1;
      case (st_q)
        S_IDLE: if (accept) st_q <= S_CHK;
        S_CHK:  st_q <= (!own_q || empty_c || ld_c) ? S_OUT : S_M0;
        S_M0:   st_q <= S_M1;
        S_M1:   st_q <= S_M2;
        S_M2:   st_q <= S_M3;
        S_M3:   st_q <= S_RCHK;
        S_RCHK: st_q <= (rcode_c != `TOB_TERR_OK) ? S_OUT : S_LANE;
        S_LANE: if (li_q == LIW'(R - 1)) st_q <= S_OUT;
        S_OUT:  if (out_ready) st_q <= S_IDLE;
        default: st_q <= S_IDLE;
      endcase
    end
  end

  always_ff @(posedge clk) begin
    case (st_q)
      S_IDLE: if (accept) begin
        a_addr_q <= t_a_addr;  lda_q   <= t_lda;   b_addr_q <= t_b_addr; ldb_q <= t_ldb;
        m0_q     <= t_m0;      n0_q    <= t_n0;    k0_q     <= t_k0;
        mat_m_q  <= t_mat_m;   mat_n_q <= t_mat_n; mat_k_q  <= t_mat_k;  tk_q  <= t_k;
        tag_q    <= t_tag;     own_q   <= owner_ok; set_q   <= cur_set;
      end
      S_CHK: begin
        em_q <= em_c;
        en_q <= en_c;
        ek_q <= ek_c;
        if (!own_q)       code_q <= `TOB_TERR_OWNER;
        else if (empty_c) code_q <= `TOB_TERR_EMPTY;
        else if (ld_c)    code_q <= `TOB_TERR_LD;
        else              code_q <= `TOB_TERR_OK;
      end
      S_M0: a0_q    <= XW'(a_addr_q) + prod_x + XW'(k0_q);
      S_M1: alast_q <= XW'(a_addr_q) + prod_x + XW'(k0_q) + XW'(ek_q) - XW'(1);
      S_M2: b0_q    <= XW'(b_addr_q) + prod_x + XW'(n0_q);
      S_M3: blast_q <= XW'(b_addr_q) + prod_x + XW'(n0_q) + XW'(en_q) - XW'(1);
      S_RCHK: begin
        code_q <= rcode_c;
        acc_q  <= a0_q[ABW-1:0];
        li_q   <= '0;
      end
      S_LANE: begin
        // lane li starts at A0 + li*lda; only the in-set bits are kept (exact
        // for every live lane: they all lie below Alast < A_SET_BYTES)
        w0_q[li_q*AWW +: AWW]   <= acc_q[ABW-1:LWB];
        off0_q[li_q*LWB +: LWB] <= acc_q[LWB-1:0];
        acc_q                   <= acc_q + lda_q[ABW-1:0];
        li_q                    <= li_q + 1'b1;
      end
      default: ;
    endcase
  end

  assign out_valid = (st_q == S_OUT);
  assign out_err   = (code_q != `TOB_TERR_OK);
  assign out_code  = code_q;
  assign out_set   = set_q;
  assign out_m     = out_err ? '0 : em_q;
  assign out_n     = out_err ? '0 : en_q;
  assign out_k     = out_err ? '0 : ek_q;
  assign out_w0    = w0_q;
  assign out_off0  = off0_q;
  assign out_b0    = b0_q[BBW-1:0];
  assign out_ldb   = ldb_q[BBW-1:0];
  assign out_m0    = m0_q;
  assign out_n0    = n0_q;
  assign out_k0    = k0_q;
  assign out_tag   = tag_q;

endmodule

`default_nettype wire
