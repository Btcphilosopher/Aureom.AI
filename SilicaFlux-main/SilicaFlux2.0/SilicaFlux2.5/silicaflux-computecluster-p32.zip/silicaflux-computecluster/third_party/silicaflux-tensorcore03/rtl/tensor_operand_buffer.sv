// =============================================================================
// SilicaFlux TENSORCORE 03 :: tensor_operand_buffer          (PRIMARY SOURCE)
// Aureom.AI | SilicaFlux-HPC
//
// Banked A / B operand buffers that feed the TENSORCORE 02 output-stationary
// systolic array (tensor_systolic_array) one k-slice per handshake:
//      s_a = A[m0 .. m0+R-1][k0+k]   (lane i = array row i)
//      s_b = B[k0+k][n0 .. n0+C-1]   (lane j = array column j)
// Dead lanes (outside the matrix: partial tiles) carry 0 and a cleared mask bit.
// The array applies its own skew; this buffer delivers unskewed slices.
//
//   DMA (Module 05 adapter / any SFB2-style master)
//     | write-only fill port, Module 04 port protocol        (tob_dma_port)
//     v   ownership check: only a set in FILL may be written (tob_dbuf_ctrl)
//   +-----------------------+   +-----------------------+
//   | A buffer              |   | B buffer              |
//   |  A_BANKS x A_REPL     |   |  B_BANKS              |  physical banks =
//   |  (x NUM_SETS if SPLIT)|   |  (x NUM_SETS if SPLIT)|  SRAM Wrapper Library
//   +-----------------------+   +-----------------------+  raw backends (tob_bank)
//     ^ per-bank arbiters (tob_bank_arb): 1RW or 1R1W port model, RR between
//     | readers, compute-first with a bounded DMA write wait
//   A lane fetchers (R)          B row fetcher
//     one word per lane per        one row (all words, distinct banks) per
//     WORD_BYTES k-steps           beat; several beats if B_BANKS is too small
//     v  fixed-latency return pipelines (READ_LATENCY)
//   A lane staging FIFOs         B row staging FIFO (C bytes per row, extracted)
//     v  slice assembly: byte (off0_i + k) mod WB of lane i's head word
//   output register: s_valid/s_ready + coordinates (s_k, s_kg, s_m0, s_n0, masks, first/last, tag)
//
// Tiles: tob_tile_agu validates a descriptor (row-major, byte addresses,
// overflow and range checked) and produces a context; a two-entry context
// queue lets tile t+1 be validated and fetched while tile t is delivered.
// Everything is single-clock; reset is asynchronous active-low (arrays are
// never reset).  Exact timing, address map and stall rules: docs/.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tob_defs.svh"
`default_nettype none

module tensor_operand_buffer #(
  parameter int          ARRAY_ROWS      = 4,                       // R: A lanes
  parameter int          ARRAY_COLS      = 4,                       // C: B lanes
  parameter int          WORD_BYTES      = 4,                       // bank word = DMA beat (power of two, 2..16)
  parameter int          A_SET_BYTES     = 4096,                    // A capacity per set (power of two)
  parameter int          B_SET_BYTES     = 4096,                    // B capacity per set (power of two)
  parameter int          A_BANKS         = 4,                       // power of two
  parameter int          B_BANKS         = 2,                       // power of two
  parameter int          A_REPL          = 1,                       // A replication (1, 2, 4; <= ARRAY_ROWS)
  parameter int          NUM_SETS        = 2,                       // 1: single buffer, 2: ping-pong
  parameter int          SET_MAP         = `TOB_SET_SHARED,         // where the two sets live
  parameter int          PORT_MODE       = `TOB_PORT_1R1W,          // bank memory-port model
  parameter int          READ_LATENCY    = 1,                       // SRAM read latency, 1..8
  parameter int          A_STAGE         = 2,                       // staged words per A lane (power of two >= 2)
  parameter int          B_STAGE         = 4,                       // staged B rows (power of two >= 2)
  parameter int          WR_STARVE_LIMIT = 8,                       // max cycles a DMA write yields to reads
  parameter int          ADDR_W          = 32,                      // descriptor and DMA byte-address width
  parameter logic [63:0] DMA_BASE        = 64'h0,                   // DMA window base
  parameter int          IDX_W           = 16,                      // m0, n0, mat_m, mat_n width
  parameter int          K_W             = 17,                      // k0, mat_k, tile_k, s_k width (= TC02 K_WIDTH)
  parameter int          TAG_W           = 8,
  parameter int          DMA_RSP_DEPTH   = 4,
  parameter int          BACKEND         = `SRAM_BACKEND_GENERIC,
  parameter int          MACRO_A         = 0,
  parameter int          MACRO_B         = 0,
  parameter int          PERF_EN         = 1,
  parameter int          CNT_W           = 32,
  // ------------------------------------------------------------ derived (never set)
  localparam int R        = ARRAY_ROWS,
  localparam int C        = ARRAY_COLS,
  localparam int WB       = WORD_BYTES,
  localparam int DW       = 8 * WB,
  localparam int LWB      = (WB > 1) ? $clog2(WB) : 1,  // (clamped: WB = 1 is rejected below)
  localparam int SW       = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int RMW      = $clog2(R + 1),
  localparam int CNW      = $clog2(C + 1),
  localparam int ABW      = $clog2(A_SET_BYTES),
  localparam int BBW      = $clog2(B_SET_BYTES),
  localparam int AWW      = ABW - LWB,                              // in-set word index widths
  localparam int BWW      = BBW - LWB,
  localparam int LNA      = $clog2(A_BANKS),
  localparam int LNB      = $clog2(B_BANKS),
  localparam int RAWA     = AWW - LNA,                              // in-set row index widths
  localparam int RAWB     = BWW - LNB,
  localparam bit SPLIT2   = (SET_MAP == `TOB_SET_SPLIT && NUM_SETS == 2),
  localparam int GRP      = SPLIT2 ? 2 : 1,                         // bank groups
  localparam int ARW      = RAWA + ((NUM_SETS == 2 && !SPLIT2) ? 1 : 0),   // physical row widths
  localparam int BRW      = RAWB + ((NUM_SETS == 2 && !SPLIT2) ? 1 : 0),
  localparam int A_DEPTH  = 1 << ARW,
  localparam int B_DEPTH  = 1 << BRW,
  localparam int NPA      = GRP * A_REPL * A_BANKS,                 // physical A banks
  localparam int NPB      = GRP * B_BANKS,                          // physical B banks
  localparam int PBW      = (NPA > 1) ? $clog2(NPA) : 1,
  localparam int NWB      = (C + 2 * WB - 2) / WB,                  // max words one B row of C bytes spans
  localparam int NBEAT    = (NWB + B_BANKS - 1) / B_BANKS,          // beats per B row, worst case
  localparam int BQW      = (NBEAT > 1) ? $clog2(NBEAT) : 1,
  localparam int NWW      = $clog2(NWB + 1),
  localparam int BKB      = (B_BANKS > 1) ? LNB : 1,
  localparam int ACW      = $clog2(A_STAGE + 1),
  localparam int BCW      = $clog2(B_STAGE + 1),
  localparam int EV_W     = 8
) (
  input  wire logic                           clk,
  input  wire logic                           rst_n,
  // ---------------------------------------------------------- DMA fill port (Module 04 port protocol)
  input  wire logic                           dma_req_valid,
  output logic                                dma_req_ready,
  input  wire logic                           dma_req_we,
  input  wire logic [ADDR_W-1:0]              dma_req_addr,
  input  wire logic [DW-1:0]                  dma_req_wdata,
  input  wire logic [WB-1:0]                  dma_req_wstrb,
  input  wire logic [TAG_W-1:0]               dma_req_tag,
  output logic                                dma_rsp_valid,
  input  wire logic                           dma_rsp_ready,
  output logic      [DW-1:0]                  dma_rsp_rdata,
  output logic                                dma_rsp_err,
  output logic      [2:0]                     dma_rsp_err_code,
  output logic                                dma_rsp_we,
  output logic      [TAG_W-1:0]               dma_rsp_tag,
  // ---------------------------------------------------------- set ownership (tob_dbuf_ctrl)
  input  wire logic                           fill_begin_valid,
  output logic                                fill_begin_ready,
  input  wire logic                           fill_end_valid,
  output logic                                fill_end_ready,
  input  wire logic                           cmp_begin_valid,
  output logic                                cmp_begin_ready,
  input  wire logic                           cmp_end_valid,
  output logic                                cmp_end_ready,
  output logic      [SW-1:0]                  fill_set,
  output logic      [SW-1:0]                  cmp_set,
  output logic      [NUM_SETS*2-1:0]          set_state,
  // ---------------------------------------------------------- tile descriptors
  input  wire logic                           tile_valid,
  output logic                                tile_ready,
  input  wire logic [ADDR_W-1:0]              tile_a_addr,
  input  wire logic [ADDR_W-1:0]              tile_lda,
  input  wire logic [ADDR_W-1:0]              tile_b_addr,
  input  wire logic [ADDR_W-1:0]              tile_ldb,
  input  wire logic [IDX_W-1:0]               tile_m0,
  input  wire logic [IDX_W-1:0]               tile_n0,
  input  wire logic [K_W-1:0]                 tile_k0,
  input  wire logic [IDX_W-1:0]               tile_mat_m,
  input  wire logic [IDX_W-1:0]               tile_mat_n,
  input  wire logic [K_W-1:0]                 tile_mat_k,
  input  wire logic [K_W-1:0]                 tile_k,
  input  wire logic [TAG_W-1:0]               tile_tag,
  output logic                                tile_rsp_valid,
  input  wire logic                           tile_rsp_ready,
  output logic      [TAG_W-1:0]               tile_rsp_tag,
  output logic                                tile_rsp_err,
  output logic      [3:0]                     tile_rsp_code,
  output logic      [RMW-1:0]                 tile_rsp_m,      // = cfg_m of the array
  output logic      [CNW-1:0]                 tile_rsp_n,      // = cfg_n
  output logic      [K_W-1:0]                 tile_rsp_k,      // = cfg_k
  // ---------------------------------------------------------- k-slice stream (to tensor_systolic_array)
  output logic                                s_valid,
  input  wire logic                           s_ready,
  output logic      [R*8-1:0]                 s_a,
  output logic      [C*8-1:0]                 s_b,
  output logic      [K_W-1:0]                 s_k,             // k inside the tile (== array s_k)
  output logic      [K_W-1:0]                 s_kg,            // global reduction index k0 + k
  output logic      [IDX_W-1:0]               s_m0,            // matrix row of lane 0
  output logic      [IDX_W-1:0]               s_n0,            // matrix column of lane 0
  output logic      [R-1:0]                   s_row_mask,
  output logic      [C-1:0]                   s_col_mask,
  output logic                                s_first,
  output logic                                s_last,
  output logic      [TAG_W-1:0]               s_tag,
  output logic      [SW-1:0]                  s_set,
  // ---------------------------------------------------------- status / performance
  output logic                                busy,
  output logic                                engine_idle,
  output logic      [`TOB_NUM_EV*EV_W-1:0]    ev_inc,
  output logic      [NPA-1:0]                 ev_bank_conflict_a,
  input  wire logic                           perf_clear,
  output logic      [`TOB_NUM_EV*CNT_W-1:0]   perf_cnt
);

  // ============================================================ configuration checks
  if (R < 1 || C < 1) begin : g_err_array_size
    `SRAM_CFG_FATAL("tensor_operand_buffer: ARRAY_ROWS and ARRAY_COLS must be >= 1")
  end
  if (WB < 2 || WB > 16 || (1 << LWB) != WB) begin : g_err_word_bytes
    `SRAM_CFG_FATAL("tensor_operand_buffer: WORD_BYTES must be a power of two, 2..16")
  end
  if ((1 << LNA) != A_BANKS || (1 << LNB) != B_BANKS) begin : g_err_banks_pow2
    `SRAM_CFG_FATAL("tensor_operand_buffer: A_BANKS and B_BANKS must be powers of two")
  end
  if ((1 << ABW) != A_SET_BYTES || (1 << BBW) != B_SET_BYTES) begin : g_err_set_pow2
    `SRAM_CFG_FATAL("tensor_operand_buffer: A_SET_BYTES and B_SET_BYTES must be powers of two")
  end
  if (RAWA < 1 || RAWB < 1) begin : g_err_rows_per_bank
    `SRAM_CFG_FATAL("tensor_operand_buffer: every bank needs >= 2 rows per set (SET_BYTES >= 2 * WORD_BYTES * BANKS)")
  end
  if (A_REPL != 1 && A_REPL != 2 && A_REPL != 4) begin : g_err_repl
    `SRAM_CFG_FATAL("tensor_operand_buffer: A_REPL must be 1, 2 or 4")
  end
  if (A_REPL > R) begin : g_err_repl_gt_rows
    `SRAM_CFG_FATAL("tensor_operand_buffer: A_REPL must not exceed ARRAY_ROWS")
  end
  if (NUM_SETS != 1 && NUM_SETS != 2) begin : g_err_num_sets
    `SRAM_CFG_FATAL("tensor_operand_buffer: NUM_SETS must be 1 or 2")
  end
  if (SET_MAP != `TOB_SET_SHARED && SET_MAP != `TOB_SET_SPLIT) begin : g_err_set_map
    `SRAM_CFG_FATAL("tensor_operand_buffer: SET_MAP must be TOB_SET_SHARED or TOB_SET_SPLIT")
  end
  if (READ_LATENCY < 1 || READ_LATENCY > 8) begin : g_err_read_latency
    `SRAM_CFG_FATAL("tensor_operand_buffer: READ_LATENCY must be 1..8")
  end
  if (A_STAGE < 2 || (1 << $clog2(A_STAGE)) != A_STAGE || B_STAGE < 2 || (1 << $clog2(B_STAGE)) != B_STAGE) begin : g_err_stage
    `SRAM_CFG_FATAL("tensor_operand_buffer: A_STAGE and B_STAGE must be powers of two >= 2")
  end
  if (ADDR_W < ABW || ADDR_W < BBW || ADDR_W > 48) begin : g_err_addr_w
    `SRAM_CFG_FATAL("tensor_operand_buffer: ADDR_W must cover one set and be <= 48")
  end
  if (BACKEND == `SRAM_BACKEND_ASIC && (MACRO_A == 0 || MACRO_B == 0)) begin : g_err_asic_macro
    `SRAM_CFG_FATAL("tensor_operand_buffer: BACKEND=ASIC needs MACRO_A and MACRO_B (no flip-flop fallback)")
  end

  // ============================================================ helpers
  function automatic logic [ARW-1:0] a_prow(input logic [SW-1:0] s, input logic [RAWA-1:0] rin);
    if (NUM_SETS == 2 && !SPLIT2) a_prow = ARW'({s, rin});
    else                          a_prow = ARW'(rin);
  endfunction
  function automatic logic [BRW-1:0] b_prow(input logic [SW-1:0] s, input logic [RAWB-1:0] rin);
    if (NUM_SETS == 2 && !SPLIT2) b_prow = BRW'({s, rin});
    else                          b_prow = BRW'(rin);
  endfunction
  function automatic int grp_of(input logic [SW-1:0] s);
    grp_of = SPLIT2 ? 32'(s) : 0;
  endfunction

  logic alive_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) alive_q <= 1'b0;
    else        alive_q <= 1'b1;
  end

  // ============================================================ set ownership
  logic fb_rdy, fe_rdy, cb_rdy, ce_rdy, cmp_owned, dma_hold_v, dma_rsp_pend;
  tob_dbuf_ctrl #(.NUM_SETS(NUM_SETS)) u_dbuf (
    .clk(clk), .rst_n(rst_n),
    .fill_begin_valid(fill_begin_valid && alive_q), .fill_begin_ready(fb_rdy),
    .fill_end_valid  (fill_end_valid   && alive_q), .fill_end_ready  (fe_rdy),
    .cmp_begin_valid (cmp_begin_valid  && alive_q), .cmp_begin_ready (cb_rdy),
    .cmp_end_valid   (cmp_end_valid    && alive_q), .cmp_end_ready   (ce_rdy),
    .dma_idle(!dma_hold_v), .engine_idle(engine_idle),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(set_state), .cmp_owned(cmp_owned)
  );
  assign fill_begin_ready = fb_rdy && alive_q;
  assign fill_end_ready   = fe_rdy && alive_q;
  assign cmp_begin_ready  = cb_rdy && alive_q;
  assign cmp_end_ready    = ce_rdy && alive_q;

  // ============================================================ DMA fill port
  logic             wr_valid, wr_is_b, wr_force, wr_go;
  logic [SW-1:0]    wr_set;
  logic [AWW-1:0]   wr_word_a;
  logic [BWW-1:0]   wr_word_b;
  logic [DW-1:0]    wr_data;
  logic [WB-1:0]    wr_mask;
  logic             dev_wr, dev_wr_stall, dev_err;

  tob_dma_port #(
    .ADDR_W(ADDR_W), .WB(WB), .TAG_W(TAG_W), .DMA_BASE(DMA_BASE), .A_SET_BYTES(A_SET_BYTES),
    .B_SET_BYTES(B_SET_BYTES), .NUM_SETS(NUM_SETS), .RSP_DEPTH(DMA_RSP_DEPTH), .WR_STARVE_LIMIT(WR_STARVE_LIMIT)
  ) u_dma (
    .clk(clk), .rst_n(rst_n),
    .req_valid(dma_req_valid), .req_ready(dma_req_ready), .req_we(dma_req_we), .req_addr(dma_req_addr),
    .req_wdata(dma_req_wdata), .req_wstrb(dma_req_wstrb), .req_tag(dma_req_tag),
    .rsp_valid(dma_rsp_valid), .rsp_ready(dma_rsp_ready), .rsp_rdata(dma_rsp_rdata), .rsp_err(dma_rsp_err),
    .rsp_err_code(dma_rsp_err_code), .rsp_we(dma_rsp_we), .rsp_tag(dma_rsp_tag),
    .set_state(set_state),
    .wr_valid(wr_valid), .wr_is_b(wr_is_b), .wr_set(wr_set), .wr_word_a(wr_word_a), .wr_word_b(wr_word_b),
    .wr_data(wr_data), .wr_mask(wr_mask), .wr_force(wr_force), .wr_go(wr_go),
    .hold_valid(dma_hold_v), .rsp_pending(dma_rsp_pend),
    .ev_wr(dev_wr), .ev_wr_stall(dev_wr_stall), .ev_err(dev_err)
  );

  // write target (logical bank / physical row / bank group) in each buffer
  wire [AWW-1:0]  wa_bank_w = wr_word_a & AWW'(A_BANKS - 1);
  wire [RAWA-1:0] wa_rin    = RAWA'(wr_word_a >> LNA);
  wire [ARW-1:0]  wa_prow   = a_prow(wr_set, wa_rin);
  wire [BWW-1:0]  wb_bank_w = wr_word_b & BWW'(B_BANKS - 1);
  wire [RAWB-1:0] wb_rin    = RAWB'(wr_word_b >> LNB);
  wire [BRW-1:0]  wb_prow   = b_prow(wr_set, wb_rin);

  // ============================================================ tile AGU, response FIFO, context queue
  logic             agu_busy, agu_ov, agu_or, agu_err;
  logic [3:0]       agu_code;
  logic [SW-1:0]    agu_set;
  logic [RMW-1:0]   agu_m;
  logic [CNW-1:0]   agu_n;
  logic [K_W-1:0]   agu_k, agu_k0;
  logic [R*AWW-1:0] agu_w0;
  logic [R*LWB-1:0] agu_off0;
  logic [BBW-1:0]   agu_b0, agu_ldb;
  logic [IDX_W-1:0] agu_m0, agu_n0;
  logic [TAG_W-1:0] agu_tag;

  tob_tile_agu #(
    .R(R), .C(C), .WB(WB), .ADDR_W(ADDR_W), .IDX_W(IDX_W), .K_W(K_W), .TAG_W(TAG_W),
    .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES), .NUM_SETS(NUM_SETS)
  ) u_agu (
    .clk(clk), .rst_n(rst_n),
    .tile_valid(tile_valid), .tile_ready(tile_ready),
    .t_a_addr(tile_a_addr), .t_lda(tile_lda), .t_b_addr(tile_b_addr), .t_ldb(tile_ldb),
    .t_m0(tile_m0), .t_n0(tile_n0), .t_k0(tile_k0), .t_mat_m(tile_mat_m), .t_mat_n(tile_mat_n),
    .t_mat_k(tile_mat_k), .t_k(tile_k), .t_tag(tile_tag),
    .accept_en(!cmp_end_valid), .owner_ok(cmp_owned), .cur_set(cmp_set), .busy(agu_busy),
    .out_valid(agu_ov), .out_ready(agu_or), .out_err(agu_err), .out_code(agu_code), .out_set(agu_set),
    .out_m(agu_m), .out_n(agu_n), .out_k(agu_k), .out_w0(agu_w0), .out_off0(agu_off0),
    .out_b0(agu_b0), .out_ldb(agu_ldb), .out_m0(agu_m0), .out_n0(agu_n0), .out_k0(agu_k0), .out_tag(agu_tag)
  );

  // tile response FIFO (DataFabric dma_fifo, unmodified)
  localparam int TRW = TAG_W + 1 + 4 + RMW + CNW + K_W;
  logic [1:0]     tr_cnt;
  logic [TRW-1:0] tr_head;
  wire            agu_fire = agu_ov && agu_or;
  dma_fifo #(.WIDTH(TRW), .DEPTH(2)) u_trsp (
    .clk(clk), .rst_n(rst_n), .clr(1'b0),
    .push(agu_fire), .wdata({agu_tag, agu_err, agu_code, agu_m, agu_n, agu_k}),
    .pop(tile_rsp_valid && tile_rsp_ready), .rdata(tr_head), .count(tr_cnt)
  );
  assign tile_rsp_valid = (tr_cnt != '0);
  assign {tile_rsp_tag, tile_rsp_err, tile_rsp_code, tile_rsp_m, tile_rsp_n, tile_rsp_k} = tr_head;

  // context = everything the fetch engines and the slice assembler need
  localparam int O_SET = 0;
  localparam int O_M   = O_SET + SW;
  localparam int O_N   = O_M   + RMW;
  localparam int O_K   = O_N   + CNW;
  localparam int O_W0  = O_K   + K_W;
  localparam int O_OFF = O_W0  + R * AWW;
  localparam int O_B0  = O_OFF + R * LWB;
  localparam int O_LDB = O_B0  + BBW;
  localparam int O_M0  = O_LDB + BBW;
  localparam int O_N0  = O_M0  + IDX_W;
  localparam int O_K0  = O_N0  + IDX_W;
  localparam int O_TAG = O_K0  + K_W;
  localparam int CTXW  = O_TAG + TAG_W;

  logic [CTXW-1:0] cq0, cq1;
  logic [1:0]      wp_q, fp_q, cp_q;                     // write / fetch / consume pointers (index + wrap)
  wire             cq_space = (wp_q - cp_q) != 2'd2;
  assign agu_or = alive_q && (tr_cnt != 2'd2) && (agu_err || cq_space);
  wire             cq_push  = agu_fire && !agu_err;
  wire [CTXW-1:0]  ctx_in   = {agu_tag, agu_k0, agu_n0, agu_m0, agu_ldb, agu_b0, agu_off0, agu_w0,
                               agu_k, agu_n, agu_m, agu_set};

  always_ff @(posedge clk) begin
    if (cq_push && !wp_q[0]) cq0 <= ctx_in;
    if (cq_push &&  wp_q[0]) cq1 <= ctx_in;
  end

  // ============================================================ fetch side
  logic f_run_q;                                          // fetch FSM: 0 idle, 1 run
  // the fetch side reads only the geometry fields of its context
  /* verilator lint_off UNUSEDSIGNAL */
  wire [CTXW-1:0]  fctx   = fp_q[0] ? cq1 : cq0;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [SW-1:0]    f_set  = fctx[O_SET +: SW];
  wire [RMW-1:0]   f_m    = fctx[O_M   +: RMW];
  wire [CNW-1:0]   f_n    = fctx[O_N   +: CNW];
  wire [K_W-1:0]   f_k    = fctx[O_K   +: K_W];
  wire [BBW-1:0]   f_b0   = fctx[O_B0  +: BBW];
  wire [BBW-1:0]   f_ldb  = fctx[O_LDB +: BBW];
  wire             f_load = !f_run_q && (fp_q != wp_q);
  logic [R-1:0]    fact;                                  // lane still has words to request
  logic            bact_q;
  wire             f_done = f_run_q && (fact == '0) && !bact_q;

  // ---------------------------------------------------------------- A lanes: request side
  logic [R-1:0]     lane_req, lane_urg, lane_gnt, a_pop, a_nonempty;
  logic [R*PBW-1:0] lane_pb;
  logic [R*ARW-1:0] lane_prow;
  logic [R*ACW-1:0] lane_cnt;
  logic [R*DW-1:0]  a_head;
  logic [NPA*DW-1:0] a_rdata;

  for (genvar i = 0; i < R; i++) begin : g_lane
    localparam int REP = i % A_REPL;
    logic [AWW-1:0] fa_q, fe_q;
    logic [ACW-1:0] cnt_q;
    wire  [AWW-1:0] w0   = fctx[O_W0  + i*AWW +: AWW];
    wire  [LWB-1:0] off0 = fctx[O_OFF + i*LWB +: LWB];
    wire  [K_W:0]   span = (K_W+1)'(off0) + (K_W+1)'(f_k) - (K_W+1)'(1);    // last byte offset from the first word

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        fact[i] <= 1'b0;
        cnt_q   <= '0;
      end else begin
        cnt_q <= cnt_q + ACW'(lane_gnt[i]) - ACW'(a_pop[i]);
        if (f_load)                            fact[i] <= (32'(f_m) > i);
        else if (lane_gnt[i] && fa_q == fe_q)  fact[i] <= 1'b0;
      end
    end
    always_ff @(posedge clk) begin
      if (f_load) begin
        fa_q <= w0;
        fe_q <= w0 + AWW'(span >> LWB);
      end else if (lane_gnt[i]) begin
        fa_q <= fa_q + 1'b1;
      end
    end

    // target bank / row of the next word
    wire [AWW-1:0]  bk  = fa_q & AWW'(A_BANKS - 1);
    wire [RAWA-1:0] rin = RAWA'(fa_q >> LNA);
    assign lane_req[i]              = fact[i] && f_run_q && (cnt_q < ACW'(A_STAGE));
    assign lane_urg[i]              = (cnt_q <= ACW'(1));    // at most the head word staged / in flight
    assign lane_prow[i*ARW +: ARW]  = a_prow(f_set, rin);
    assign lane_pb[i*PBW +: PBW]    = PBW'((grp_of(f_set) * A_REPL + REP) * A_BANKS + 32'(bk));
    assign lane_cnt[i*ACW +: ACW]   = cnt_q;

    // return side: fixed-latency pipeline aligned with the SRAM read data
    logic [READ_LATENCY-1:0]     rpv;
    logic [READ_LATENCY*PBW-1:0] rpb;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) rpv <= '0;
      else begin
        rpv[0] <= lane_gnt[i];
        for (int s = 1; s < READ_LATENCY; s++) rpv[s] <= rpv[s-1];
      end
    end
    always_ff @(posedge clk) begin
      rpb[0 +: PBW] <= lane_pb[i*PBW +: PBW];
      for (int s = 1; s < READ_LATENCY; s++) rpb[s*PBW +: PBW] <= rpb[(s-1)*PBW +: PBW];
    end
    wire [PBW-1:0] spb = rpb[(READ_LATENCY-1)*PBW +: PBW];
    logic [$clog2(A_STAGE):0] fcnt;

    dma_fifo #(.WIDTH(DW), .DEPTH(A_STAGE)) u_stage (
      .clk(clk), .rst_n(rst_n), .clr(1'b0),
      .push(rpv[READ_LATENCY-1]), .wdata(a_rdata[spb*DW +: DW]),
      .pop(a_pop[i]), .rdata(a_head[i*DW +: DW]), .count(fcnt)
    );
    assign a_nonempty[i] = (fcnt != '0);
  end

  // ---------------------------------------------------------------- A banks
  logic [NPA*R-1:0] a_gnt, a_blk;
  logic [NPA-1:0]   a_wok, a_wreq, a_rd_en, a_conf;

  for (genvar p = 0; p < NPA; p++) begin : g_abank
    localparam int PG = p / (A_REPL * A_BANKS);
    localparam int PB = p % A_BANKS;
    logic [R-1:0]   req;
    logic [ARW-1:0] rrow;
    always_comb begin
      for (int i = 0; i < R; i++) req[i] = lane_req[i] && (lane_pb[i*PBW +: PBW] == PBW'(p));
    end
    assign a_wreq[p] = wr_valid && !wr_is_b && (wa_bank_w == AWW'(PB)) && (grp_of(wr_set) == PG);

    /* verilator lint_off PINCONNECTEMPTY */
    tob_bank_arb #(.NR(R), .PORT_MODE(PORT_MODE), .RW(ARW)) u_arb (
      .clk(clk), .rst_n(rst_n),
      .rd_req(req), .rd_urg(lane_urg), .rd_row(lane_prow),
      .wr_req(a_wreq[p]), .wr_row(wa_prow), .wr_force(wr_force), .wr_ok(a_wok[p]), .wr_go(wr_go),
      .rd_gnt(a_gnt[p*R +: R]), .rd_any(a_rd_en[p]), .rd_idx(), .rd_row_g(rrow),
      .conflict(a_conf[p]), .rd_wr_blk(a_blk[p*R +: R])
    );
    /* verilator lint_on PINCONNECTEMPTY */
    tob_bank #(
      .DW(DW), .DEPTH(A_DEPTH), .RL(READ_LATENCY), .PORT_MODE(PORT_MODE), .BACKEND(BACKEND), .MACRO(MACRO_A)
    ) u_bank (
      .clk(clk), .wr_en(wr_go && a_wreq[p]), .wr_row(wa_prow), .wr_data(wr_data), .wr_mask(wr_mask),
      .rd_en(a_rd_en[p]), .rd_row(rrow), .rd_data(a_rdata[p*DW +: DW])
    );
`ifdef TOB_ASSERT
    always_ff @(posedge clk) begin
      if (rst_n) `SRAM_CHK(!(wr_go && a_wreq[p] && a_rd_en[p] && rrow == wa_prow),
                           "A bank: read and write of the same row issued in one cycle")
    end
`endif
  end

  always_comb begin
    lane_gnt = '0;
    for (int p = 0; p < NPA; p++) lane_gnt = lane_gnt | a_gnt[p*R +: R];
  end

  // ---------------------------------------------------------------- B row fetcher
  logic [BBW-1:0] bb_q;                                    // in-set byte address of B row bk_q
  logic [K_W-1:0] bk_q;
  logic [BQW-1:0] bq_q;                                    // beat inside the row
  logic [BCW-1:0] bcnt_q;                                  // staged + in-flight rows
  logic           b_req, b_go, b_pop, b_nonempty;

  wire [BWW-1:0]           b_ws   = bb_q[BBW-1:LWB];
  wire [LWB-1:0]           b_off  = bb_q[LWB-1:0];
  wire [LWB+CNW:0]         b_lb   = (LWB+CNW+1)'(b_off) + (LWB+CNW+1)'(f_n) - (LWB+CNW+1)'(1);
  wire [NWW-1:0]           b_nw   = NWW'(b_lb >> LWB) + NWW'(1);           // words this row spans
  wire [NWW-1:0]           b_lq   = NWW'((b_nw - NWW'(1)) >> LNB);         // index of its last beat
  wire                     b_lastbeat = (NWW'(bq_q) == b_lq);
  wire [BWW-1:0]           b_base = b_ws + (BWW'(bq_q) << LNB);            // first word of this beat
  wire [NWW-1:0]           b_left = b_nw - (NWW'(bq_q) << LNB);            // words from this beat on
  wire [BKB-1:0]           b_bank0 = BKB'(b_base & BWW'(B_BANKS - 1));
  logic [B_BANKS-1:0]      b_inv;
  logic [B_BANKS*BRW-1:0]  b_prw;

  always_comb begin
    for (int b = 0; b < B_BANKS; b++) begin
      int            xl;
      logic [BWW-1:0] wrd;
      xl  = (b - 32'(b_bank0)) & (B_BANKS - 1);
      wrd = b_base + BWW'(xl);
      b_inv[b]               = (xl < 32'(b_left));
      b_prw[b*BRW +: BRW]    = b_prow(f_set, RAWB'(wrd >> LNB));
    end
  end

  assign b_req = bact_q && f_run_q && ((bq_q != '0) || (bcnt_q < BCW'(B_STAGE)));

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      bact_q <= 1'b0;
      bcnt_q <= '0;
    end else begin
      bcnt_q <= bcnt_q + BCW'(b_go && bq_q == '0) - BCW'(b_pop);
      if (f_load)                                         bact_q <= 1'b1;
      else if (b_go && b_lastbeat && bk_q == f_k - 1'b1)  bact_q <= 1'b0;
    end
  end
  always_ff @(posedge clk) begin
    if (f_load) begin
      bb_q <= f_b0;
      bk_q <= '0;
      bq_q <= '0;
    end else if (b_go) begin
      if (b_lastbeat) begin
        bb_q <= bb_q + f_ldb;
        bk_q <= bk_q + 1'b1;
        bq_q <= '0;
      end else begin
        bq_q <= (NBEAT > 1) ? bq_q + 1'b1 : '0;
      end
    end
  end

  // ---------------------------------------------------------------- B banks
  logic [NPB-1:0]    b_rdreq, b_gnt, b_wok, b_wreq, b_rd_en, b_blk;
  logic [NPB*DW-1:0] b_rdata;

  for (genvar q = 0; q < NPB; q++) begin : g_bbank
    localparam int QG = q / B_BANKS;
    localparam int QB = q % B_BANKS;
    assign b_rdreq[q] = b_req && b_inv[QB] && (grp_of(f_set) == QG);
    assign b_wreq[q]  = wr_valid && wr_is_b && (wb_bank_w == BWW'(QB)) && (grp_of(wr_set) == QG);

    /* verilator lint_off PINCONNECTEMPTY */
    tob_bank_arb #(.NR(1), .PORT_MODE(PORT_MODE), .RW(BRW)) u_arb (
      .clk(clk), .rst_n(rst_n),
      .rd_req(b_rdreq[q]), .rd_urg(1'b1), .rd_row(b_prw[QB*BRW +: BRW]),
      .wr_req(b_wreq[q]), .wr_row(wb_prow), .wr_force(wr_force), .wr_ok(b_wok[q]), .wr_go(wr_go),
      .rd_gnt(b_gnt[q]), .rd_any(), .rd_idx(), .rd_row_g(), .conflict(), .rd_wr_blk(b_blk[q])
    );
    /* verilator lint_on PINCONNECTEMPTY */
    assign b_rd_en[q] = b_go && b_rdreq[q];
    tob_bank #(
      .DW(DW), .DEPTH(B_DEPTH), .RL(READ_LATENCY), .PORT_MODE(PORT_MODE), .BACKEND(BACKEND), .MACRO(MACRO_B)
    ) u_bank (
      .clk(clk), .wr_en(wr_go && b_wreq[q]), .wr_row(wb_prow), .wr_data(wr_data), .wr_mask(wr_mask),
      .rd_en(b_rd_en[q]), .rd_row(b_prw[QB*BRW +: BRW]), .rd_data(b_rdata[q*DW +: DW])
    );
`ifdef TOB_ASSERT
    always_ff @(posedge clk) begin
      if (rst_n) `SRAM_CHK(!(wr_go && b_wreq[q] && b_rd_en[q] && b_prw[QB*BRW +: BRW] == wb_prow),
                           "B bank: read and write of the same row issued in one cycle")
    end
`endif
  end

  // all-or-nothing: every bank of the beat must grant the read
  assign b_go  = b_req && ((~b_rdreq | b_gnt) == '1);
  // a write needs every target bank (all replicas of an A bank)
  assign wr_go = wr_valid && (a_wok == '1) && (b_wok == '1);

  // ---------------------------------------------------------------- B return pipeline + row assembly
  localparam int BPW = 1 + BQW + BKB + LWB + SW;
  logic [READ_LATENCY-1:0]     bpv;
  logic [READ_LATENCY*BPW-1:0] bpd;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) bpv <= '0;
    else begin
      bpv[0] <= b_go;
      for (int s = 1; s < READ_LATENCY; s++) bpv[s] <= bpv[s-1];
    end
  end
  always_ff @(posedge clk) begin
    bpd[0 +: BPW] <= {b_lastbeat, bq_q, b_bank0, b_off, f_set};
    for (int s = 1; s < READ_LATENCY; s++) bpd[s*BPW +: BPW] <= bpd[(s-1)*BPW +: BPW];
  end
  wire           o_v = bpv[READ_LATENCY-1];
  wire [BPW-1:0] o_d = bpd[(READ_LATENCY-1)*BPW +: BPW];
  wire [SW-1:0]  o_set   = o_d[0 +: SW];
  wire [LWB-1:0] o_off   = o_d[SW +: LWB];
  /* verilator lint_off UNUSEDSIGNAL */
  wire [BKB-1:0] o_bank0 = o_d[SW + LWB +: BKB];           // constant-folded away when B_BANKS = 1
  /* verilator lint_on UNUSEDSIGNAL */
  wire [BQW-1:0] o_bq    = o_d[SW + LWB + BKB +: BQW];
  wire           o_last  = o_d[BPW-1];

  logic [NWB*DW-1:0] line_q, line_n;
  logic [C*8-1:0]    b_row;
  always_comb begin
    line_n = line_q;
    for (int w = 0; w < NWB; w++) begin
      for (int xl = 0; xl < B_BANKS; xl++) begin
        if (32'(o_bq) * B_BANKS + xl == w)
          line_n[w*DW +: DW] = b_rdata[(grp_of(o_set) * B_BANKS + ((32'(o_bank0) + xl) & (B_BANKS - 1)))*DW +: DW];
      end
    end
    for (int j = 0; j < C; j++) b_row[j*8 +: 8] = line_n[(32'(o_off) + j)*8 +: 8];
  end
  if (NBEAT > 1) begin : g_line
    always_ff @(posedge clk) if (o_v) line_q <= line_n;
  end else begin : g_noline
    assign line_q = '0;
  end

  logic [C*8-1:0]             b_head;
  logic [$clog2(B_STAGE):0]   bfc;
  dma_fifo #(.WIDTH(C*8), .DEPTH(B_STAGE)) u_bstage (
    .clk(clk), .rst_n(rst_n), .clr(1'b0),
    .push(o_v && o_last), .wdata(b_row), .pop(b_pop), .rdata(b_head), .count(bfc)
  );
  assign b_nonempty = (bfc != '0);

  // ---------------------------------------------------------------- fetch FSM / context pointers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      f_run_q <= 1'b0;
      wp_q    <= '0;
      fp_q    <= '0;
    end else begin
      if (cq_push) wp_q <= wp_q + 1'b1;
      if (f_load) f_run_q <= 1'b1;
      else if (f_done) begin
        f_run_q <= 1'b0;
        fp_q    <= fp_q + 1'b1;
      end
    end
  end

  // ============================================================ slice assembly (consume side)
  wire [CTXW-1:0]  cctx   = cp_q[0] ? cq1 : cq0;
  wire [SW-1:0]    c_set  = cctx[O_SET +: SW];
  wire [RMW-1:0]   c_m    = cctx[O_M   +: RMW];
  wire [CNW-1:0]   c_n    = cctx[O_N   +: CNW];
  wire [K_W-1:0]   c_k    = cctx[O_K   +: K_W];
  wire [IDX_W-1:0] c_m0   = cctx[O_M0  +: IDX_W];
  wire [IDX_W-1:0] c_n0   = cctx[O_N0  +: IDX_W];
  wire [K_W-1:0]   c_k0   = cctx[O_K0  +: K_W];
  wire [TAG_W-1:0] c_tag  = cctx[O_TAG +: TAG_W];
  wire             cons_v = (cp_q != wp_q);

  logic [K_W-1:0]  ck_q;
  logic            out_v;
  wire             c_last = (ck_q == c_k - 1'b1);
  logic [R-1:0]    live, a_ok_l;
  logic [C-1:0]    cmask;
  logic [R*8-1:0]  sa_c;
  logic [C*8-1:0]  sb_c;

  always_comb begin
    for (int i = 0; i < R; i++) begin
      logic [LWB-1:0] hoff;
      hoff        = cctx[O_OFF + i*LWB +: LWB] + ck_q[LWB-1:0];   // byte of A[m0+i][k0+ck] in the head word
      live[i]     = (32'(c_m) > i);
      a_ok_l[i]   = !live[i] || a_nonempty[i];
      sa_c[i*8 +: 8] = live[i] ? a_head[i*DW + 32'(hoff)*8 +: 8] : 8'h00;
    end
    for (int j = 0; j < C; j++) begin
      cmask[j]       = (32'(c_n) > j);
      sb_c[j*8 +: 8] = cmask[j] ? b_head[j*8 +: 8] : 8'h00;
    end
  end

  wire a_ok      = (a_ok_l == '1);
  wire slice_rdy = cons_v && a_ok && b_nonempty;
  wire out_free  = !out_v || s_ready;
  wire emit      = slice_rdy && out_free;
  assign b_pop   = emit;

  for (genvar i = 0; i < R; i++) begin : g_pop
    wire [LWB-1:0] hoff = cctx[O_OFF + i*LWB +: LWB] + ck_q[LWB-1:0];
    // the head word is retired after its last byte, or at the end of the tile
    assign a_pop[i] = emit && live[i] && ((hoff == LWB'(WB - 1)) || c_last);
  end

  logic [R*8-1:0]   sa_q;
  logic [C*8-1:0]   sb_q;
  logic [K_W-1:0]   sk_q, skg_q;
  logic [IDX_W-1:0] sm0_q, sn0_q;
  logic [R-1:0]     srm_q;
  logic [C-1:0]     scm_q;
  logic             sfirst_q, slast_q;
  logic [TAG_W-1:0] stag_q;
  logic [SW-1:0]    sset_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      out_v <= 1'b0;
      ck_q  <= '0;
      cp_q  <= '0;
    end else begin
      if (emit)         out_v <= 1'b1;
      else if (s_ready) out_v <= 1'b0;
      if (emit) begin
        ck_q <= c_last ? '0 : ck_q + 1'b1;
        if (c_last) cp_q <= cp_q + 1'b1;
      end
    end
  end
  always_ff @(posedge clk) begin
    if (emit) begin
      sa_q     <= sa_c;
      sb_q     <= sb_c;
      sk_q     <= ck_q;
      skg_q    <= c_k0 + ck_q;
      sm0_q    <= c_m0;
      sn0_q    <= c_n0;
      srm_q    <= live;
      scm_q    <= cmask;
      sfirst_q <= (ck_q == '0);
      slast_q  <= c_last;
      stag_q   <= c_tag;
      sset_q   <= c_set;
    end
  end

  assign s_valid    = out_v;
  assign s_a        = sa_q;
  assign s_b        = sb_q;
  assign s_k        = sk_q;
  assign s_kg       = skg_q;
  assign s_m0       = sm0_q;
  assign s_n0       = sn0_q;
  assign s_row_mask = srm_q;
  assign s_col_mask = scm_q;
  assign s_first    = sfirst_q;
  assign s_last     = slast_q;
  assign s_tag      = stag_q;
  assign s_set      = sset_q;

  // ============================================================ status
  wire lanes_empty = (lane_cnt == '0);
  assign engine_idle = alive_q && !agu_busy && (wp_q == cp_q) && !f_run_q && !out_v && lanes_empty && (bcnt_q == '0);
  assign busy        = !engine_idle || dma_hold_v || dma_rsp_pend || tile_rsp_valid;

  // ============================================================ events / performance
  logic [EV_W-1:0] n_ard, n_brd, n_ast, n_conf, n_blk;
  always_comb begin
    n_ard = '0; n_brd = '0; n_ast = '0; n_conf = '0; n_blk = '0;
    for (int p = 0; p < NPA; p++) begin
      n_ard  = n_ard  + EV_W'(a_rd_en[p]);
      n_conf = n_conf + EV_W'(a_conf[p]);
      for (int i = 0; i < R; i++) n_blk = n_blk + EV_W'(a_blk[p*R + i]);
    end
    for (int q = 0; q < NPB; q++) begin
      n_brd = n_brd + EV_W'(b_rd_en[q]);
      n_blk = n_blk + EV_W'(b_blk[q]);
    end
    for (int i = 0; i < R; i++) n_ast = n_ast + EV_W'(lane_req[i] && !lane_gnt[i]);
  end

  wire starve   = cons_v && out_free && !(a_ok && b_nonempty);
  wire slice_hs = s_valid && s_ready;
  always_comb begin
    ev_inc = '0;
    ev_inc[`TOB_EV_CYCLES        *EV_W +: EV_W] = EV_W'(1);
    ev_inc[`TOB_EV_ACTIVE        *EV_W +: EV_W] = EV_W'(cons_v);
    ev_inc[`TOB_EV_SLICES        *EV_W +: EV_W] = EV_W'(slice_hs);
    ev_inc[`TOB_EV_STARVE        *EV_W +: EV_W] = EV_W'(starve);
    ev_inc[`TOB_EV_STARVE_A      *EV_W +: EV_W] = EV_W'(starve && !a_ok);
    ev_inc[`TOB_EV_STARVE_B      *EV_W +: EV_W] = EV_W'(starve && !b_nonempty);
    ev_inc[`TOB_EV_ARRAY_BP      *EV_W +: EV_W] = EV_W'(out_v && !s_ready);
    ev_inc[`TOB_EV_A_RD_WORDS    *EV_W +: EV_W] = n_ard;
    ev_inc[`TOB_EV_B_RD_WORDS    *EV_W +: EV_W] = n_brd;
    ev_inc[`TOB_EV_A_RD_STALL    *EV_W +: EV_W] = n_ast;
    ev_inc[`TOB_EV_B_RD_STALL    *EV_W +: EV_W] = EV_W'(b_req && !b_go);
    ev_inc[`TOB_EV_BANK_CONFLICT *EV_W +: EV_W] = n_conf;
    ev_inc[`TOB_EV_RD_WR_BLOCK   *EV_W +: EV_W] = n_blk;
    ev_inc[`TOB_EV_WR_STALL      *EV_W +: EV_W] = EV_W'(dev_wr_stall);
    ev_inc[`TOB_EV_WR_WORDS      *EV_W +: EV_W] = EV_W'(dev_wr);
    ev_inc[`TOB_EV_WR_FORCED     *EV_W +: EV_W] = EV_W'(dev_wr && (n_blk != '0));
    ev_inc[`TOB_EV_DMA_ERR       *EV_W +: EV_W] = EV_W'(dev_err);
    ev_inc[`TOB_EV_TILE_OK       *EV_W +: EV_W] = EV_W'(agu_fire && !agu_err);
    ev_inc[`TOB_EV_TILE_ERR      *EV_W +: EV_W] = EV_W'(agu_fire && agu_err);
    ev_inc[`TOB_EV_OVERLAP       *EV_W +: EV_W] = EV_W'(dev_wr && slice_hs);
  end
  assign ev_bank_conflict_a = a_conf;

  if (PERF_EN != 0) begin : g_perf
    tob_perf #(.NUM_EV(`TOB_NUM_EV), .EV_W(EV_W), .CNT_W(CNT_W)) u_perf (
      .clk(clk), .rst_n(rst_n), .clear(perf_clear), .inc(ev_inc), .cnt(perf_cnt)
    );
  end else begin : g_noperf
    assign perf_cnt = '0;
    wire unused_perf = &{1'b0, perf_clear};
  end

  // ============================================================ embedded checks (simulation / formal)
`ifdef TOB_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      `SRAM_CHK(!(emit && c_last && fp_q == cp_q), "consumer finished a tile whose fetch has not completed")
      `SRAM_CHK(!(b_go && !b_req), "B read issued without request")
      `SRAM_CHK((lane_gnt & ~lane_req) == '0, "A lane granted without request")
      `SRAM_CHK(!(s_valid && !s_ready && emit), "output register overwritten while held")
    end
  end
`endif

endmodule

`default_nettype wire
