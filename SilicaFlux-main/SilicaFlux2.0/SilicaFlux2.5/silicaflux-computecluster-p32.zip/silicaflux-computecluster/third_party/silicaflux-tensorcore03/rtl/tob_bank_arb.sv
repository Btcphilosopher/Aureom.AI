// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_bank_arb
// Arbiter of ONE physical operand bank.  It never grants more accesses than
// the bank's memory-port model provides:
//
//   PORT_MODE 1RW  : one access per cycle - one read OR the DMA write.
//   PORT_MODE 1R1W : one read AND one write per cycle, except that a read and
//                    a write of the SAME row are never issued in the same
//                    cycle (the array then never sees a read-during-write
//                    collision, whatever the backend's cross-port behaviour:
//                    FPGA inference returns old data, OpenRAM/IHP macros are
//                    undefined).
//
// Read requesters (NR, e.g. the A lanes that use this bank's replica) are
// served in two classes:
//   urgent (rd_urg = 1: the requester's next word is needed within WB cycles -
//           for an A lane, at most its head word is staged or in flight)
//   prefetch (rd_urg = 0: the requester already holds or awaits its next word).
// The first eligible URGENT requester in round-robin order wins; only if none
// is urgent does the first eligible prefetch requester win.  Round-robin order
// = ptr, ptr+1, ..., ptr-1; the pointer moves past the winner whenever a read
// is granted.  Starvation-free: an urgent requester that keeps requesting is
// granted within NR-1 read grants of this bank; a prefetch requester becomes
// urgent as soon as its staged data drains.  (Plain round-robin can serve a
// lane's third word while another lane on the same bank still lacks its
// next one: measurable bubbles at tile starts on large arrays.)
//
// Read/write policy (compute first, bounded DMA wait):
//   "hazard" requesters hz = all read requesters (1RW) or those reading the
//   write's row (1R1W).
//   wr_ok  = !wr_req || hz == 0 || wr_force      (computed from REQUESTS only)
//   The global write decision wr_go (the AND of wr_ok over every bank the
//   write targets: replicas of an A bank) comes back in; when it is set, the
//   hazard requesters are blocked this cycle (rd_wr_blk) and the rest
//   compete for the read slot.  wr_force is raised by the DMA port after
//   WR_STARVE_LIMIT cycles of waiting, so a write waits at most
//   WR_STARVE_LIMIT + 1 cycles for this bank.
// No combinational loop: wr_ok depends on requests, the grants on wr_go.
//
// Events: conflict = >= 2 eligible readers (one is served, the others wait);
//         rd_wr_blk = readers blocked by the write.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tob_defs.svh"
`default_nettype none

module tob_bank_arb #(
  parameter int  NR        = 4,                      // read requesters
  parameter int  PORT_MODE = `TOB_PORT_1R1W,
  parameter int  RW        = 8,                      // physical row-address width
  localparam int PW        = (NR > 1) ? $clog2(NR) : 1
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [NR-1:0]    rd_req,
  input  wire logic [NR-1:0]    rd_urg,              // request is urgent (see above)
  input  wire logic [NR*RW-1:0] rd_row,
  input  wire logic             wr_req,              // the pending DMA write targets this bank
  input  wire logic [RW-1:0]    wr_row,
  input  wire logic             wr_force,            // write waited WR_STARVE_LIMIT cycles
  output logic                  wr_ok,               // write may be performed here this cycle
  input  wire logic             wr_go,               // global write decision (all target banks ok)
  output logic      [NR-1:0]    rd_gnt,              // one-hot read grant (final)
  output logic                  rd_any,
  output logic      [PW-1:0]    rd_idx,
  output logic      [RW-1:0]    rd_row_g,            // row of the granted read
  output logic                  conflict,
  output logic      [NR-1:0]    rd_wr_blk
);

  if (PORT_MODE != `TOB_PORT_1RW && PORT_MODE != `TOB_PORT_1R1W) begin : g_err_port_mode
    `SRAM_CFG_FATAL("tob_bank_arb: PORT_MODE must be TOB_PORT_1RW or TOB_PORT_1R1W")
  end

  logic [NR-1:0] hz, elig;
  logic [PW-1:0] ptr_q;

  always_comb begin
    for (int i = 0; i < NR; i++) begin
      if (PORT_MODE == `TOB_PORT_1RW) hz[i] = rd_req[i];
      else                            hz[i] = rd_req[i] && (rd_row[i*RW +: RW] == wr_row);
    end
  end

  assign wr_ok     = !wr_req || (hz == '0) || wr_force;
  assign rd_wr_blk = (wr_go && wr_req) ? hz : '0;
  assign elig      = rd_req & ~rd_wr_blk;
  assign conflict  = (elig & (elig - 1'b1)) != '0;   // at least two eligible readers

  wire [NR-1:0] elig_u = elig & rd_urg;
  wire [NR-1:0] cand   = (elig_u != '0) ? elig_u : elig;   // urgent class first

  always_comb begin
    int   idx;
    logic found;
    rd_gnt = '0;
    rd_idx = '0;
    found  = 1'b0;
    idx    = 0;
    for (int k = 0; k < NR; k++) begin
      idx = 32'(ptr_q) + k;
      if (idx >= NR) idx = idx - NR;
      if (!found && cand[idx]) begin
        found       = 1'b1;
        rd_gnt[idx] = 1'b1;
        rd_idx      = PW'(idx);
      end
    end
    rd_any = found;
  end

  assign rd_row_g = rd_row[rd_idx*RW +: RW];

  if (NR > 1) begin : g_rr
    localparam logic [PW-1:0] LAST = PW'(NR - 1);
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)      ptr_q <= '0;
      else if (rd_any) ptr_q <= (rd_idx == LAST) ? '0 : rd_idx + 1'b1;
    end
  end else begin : g_single
    assign ptr_q = '0;
    wire unused_single = &{1'b0, clk, rst_n};
  end

endmodule

`default_nettype wire
