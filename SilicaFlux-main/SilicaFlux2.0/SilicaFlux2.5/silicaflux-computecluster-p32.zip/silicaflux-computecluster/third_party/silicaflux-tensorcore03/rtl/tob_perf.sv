// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_perf
// Saturating event counters of the operand buffer (PERF_EN = 1).
// One CNT_W-bit counter per event of the ev_inc vector (tob_defs.svh
// TOB_EV_*); each adds its per-cycle increment (EV_W bits, several events per
// cycle allowed).  Reset by rst_n and by clear (synchronous); counters
// saturate at all-ones instead of wrapping.  The same ev_inc vector can drive
// the Module 07 counter bank (hpc_perf_counters.inc_i) instead.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tob_perf #(
  parameter int NUM_EV = 20,
  parameter int EV_W   = 8,
  parameter int CNT_W  = 32
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  input  wire logic                    clear,
  input  wire logic [NUM_EV*EV_W-1:0]  inc,
  output logic      [NUM_EV*CNT_W-1:0] cnt
);

  localparam logic [CNT_W-1:0] MAXV = {CNT_W{1'b1}};

  function automatic logic [CNT_W-1:0] sat_add(input logic [CNT_W-1:0] v, input logic [EV_W-1:0] d);
    logic [CNT_W:0] s;
    s = {1'b0, v} + {{(CNT_W + 1 - EV_W){1'b0}}, d};
    sat_add = s[CNT_W] ? MAXV : s[CNT_W-1:0];   // (no `return`: Yosys 0.33 front end)
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)     cnt <= '0;
    else if (clear) cnt <= '0;
    else begin
      for (int e = 0; e < NUM_EV; e++)
        cnt[e*CNT_W +: CNT_W] <= sat_add(cnt[e*CNT_W +: CNT_W], inc[e*EV_W +: EV_W]);
    end
  end

endmodule

`default_nettype wire
