// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_dbuf_ctrl
// Ownership controller of the operand-buffer sets (optional ping-pong).
//
// Every set s (an A region plus a B region) has an explicit owner state:
//
//      EMPTY --fill_begin--> FILL --fill_end--> READY --cmp_begin--> COMPUTE
//        ^                   (DMA)                                   (compute)
//        +------------------------------cmp_end-----------------------+
//
//   * DMA writes are performed only into a set in FILL (else OWNER error).
//   * Tiles are accepted only while the compute set is in COMPUTE.
//   * fill_end is accepted only when the DMA port holds no request
//     (dma_idle): every write the DMA issued before fill_end is in the array.
//   * cmp_end is accepted only when the operand engine is drained
//     (engine_idle: no tile being validated, staged, fetched or waiting in
//     the output register), i.e. every operand of the set was delivered.
//   * Sets are used in strict ping-pong order: fill_ptr names the next set
//     to fill, cmp_ptr the next set to compute; each advances by one (mod
//     NUM_SETS) at fill_end / cmp_end.  With NUM_SETS = 1 the same states
//     serialise DMA fill and compute on a single buffer.
// Each command is a valid/ready handshake; ready is low (the command waits)
// while its precondition is false, it is never dropped.  At most one
// transition happens per set per cycle (the preconditions are exclusive).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tob_defs.svh"
`default_nettype none

module tob_dbuf_ctrl #(
  parameter int  NUM_SETS = 2,
  localparam int SW       = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  fill_begin_valid,
  output logic                       fill_begin_ready,
  input  wire logic                  fill_end_valid,
  output logic                       fill_end_ready,
  input  wire logic                  cmp_begin_valid,
  output logic                       cmp_begin_ready,
  input  wire logic                  cmp_end_valid,
  output logic                       cmp_end_ready,
  input  wire logic                  dma_idle,
  input  wire logic                  engine_idle,
  output logic      [SW-1:0]         fill_set,
  output logic      [SW-1:0]         cmp_set,
  output logic      [NUM_SETS*2-1:0] set_state,
  output logic                       cmp_owned       // state[cmp_set] == COMPUTE
);

  if (NUM_SETS != 1 && NUM_SETS != 2) begin : g_err_num_sets
    `SRAM_CFG_FATAL("tob_dbuf_ctrl: NUM_SETS must be 1 (single buffer) or 2 (ping-pong)")
  end

  logic [NUM_SETS*2-1:0] st_q;
  logic [SW-1:0]         fp_q, cp_q;
  logic [1:0]            st_f, st_c;

  assign st_f = st_q[fp_q*2 +: 2];
  assign st_c = st_q[cp_q*2 +: 2];

  assign fill_begin_ready = (st_f == `TOB_ST_EMPTY);
  assign fill_end_ready   = (st_f == `TOB_ST_FILL) && dma_idle;
  assign cmp_begin_ready  = (st_c == `TOB_ST_READY);
  assign cmp_end_ready    = (st_c == `TOB_ST_COMPUTE) && engine_idle;

  wire fb = fill_begin_valid && fill_begin_ready;
  wire fe = fill_end_valid   && fill_end_ready;
  wire cb = cmp_begin_valid  && cmp_begin_ready;
  wire ce = cmp_end_valid    && cmp_end_ready;

  function automatic logic [SW-1:0] nxt(input logic [SW-1:0] p);
    nxt = (NUM_SETS > 1) ? p + 1'b1 : p;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= '0;                                   // every set EMPTY
      fp_q <= '0;
      cp_q <= '0;
    end else begin
      if (fb) st_q[fp_q*2 +: 2] <= `TOB_ST_FILL;
      if (fe) begin
        st_q[fp_q*2 +: 2] <= `TOB_ST_READY;
        fp_q              <= nxt(fp_q);
      end
      if (cb) st_q[cp_q*2 +: 2] <= `TOB_ST_COMPUTE;
      if (ce) begin
        st_q[cp_q*2 +: 2] <= `TOB_ST_EMPTY;
        cp_q              <= nxt(cp_q);
      end
    end
  end

  assign fill_set  = fp_q;
  assign cmp_set   = cp_q;
  assign set_state = st_q;
  assign cmp_owned = (st_c == `TOB_ST_COMPUTE);

endmodule

`default_nettype wire
