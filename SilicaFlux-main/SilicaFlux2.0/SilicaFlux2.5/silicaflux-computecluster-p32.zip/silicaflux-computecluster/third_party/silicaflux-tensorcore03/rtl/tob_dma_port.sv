// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_dma_port
// DMA fill port of the operand buffer.  Request/response protocol identical
// to one requester port of the Module 04 scratchpad (hpc_scratchpad, built
// with WRITE_ACK = 1), so the Module 05 adapter hpc_dma_spm_port drives it
// unchanged:
//   request : req_valid/req_ready, req_we, req_addr (bytes), req_wdata,
//             req_wstrb (one bit per byte lane), req_tag
//   response: rsp_valid/rsp_ready, rsp_rdata (always 0), rsp_err,
//             rsp_err_code[2:0], rsp_we (echo), rsp_tag (echo)
//   * exactly one response per request, in acceptance order;
//   * a write is acknowledged only after it was performed in every target
//     bank (and every replica);
//   * req_ready never depends on rsp_ready (response credits);
//   * never a response in the acceptance cycle.
//
// Address window (byte offsets from DMA_BASE, REGION = max(A_TOTAL, B_TOTAL)):
//   [0, A_TOTAL)                 A region: set = off / A_SET_BYTES
//   [A_TOTAL, REGION)            hole          -> RANGE
//   [REGION, REGION + B_TOTAL)   B region: set = (off - REGION) / B_SET_BYTES
//   anything else                              -> RANGE
// with X_TOTAL = NUM_SETS * X_SET_BYTES.  Within a set, byte offset o is word
// o / WB, byte lane o % WB (little endian, lane l = wdata[8l +: 8]).
//
// Pipeline: an accepted request enters a one-entry hold register.  In the hold
// stage it is decoded (RANGE > ALIGN > UNSUP(read) > OWNER(set not in FILL));
// an erroneous request retires at once with an error response and no side
// effect; a legal write is offered to the bank arbiters (wr_valid) and retires
// at the edge where they grant it (wr_go): the array is written at that edge,
// the acknowledgement enters the response FIFO at the same edge and is visible
// the next cycle.  Back-to-back throughput: one write per cycle when the banks
// grant it and RSP_DEPTH >= 3.
//
// Write starvation bound: the cycles a legal write has waited are counted;
// at WR_STARVE_LIMIT the write is forced (wr_force), i.e. it is granted in the
// next arbitration whatever reads are pending.  A write therefore waits at most
// WR_STARVE_LIMIT cycles.  WR_STARVE_LIMIT = 0 gives writes strict priority.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tob_defs.svh"
`default_nettype none

module tob_dma_port #(
  parameter int          ADDR_W          = 32,
  parameter int          WB              = 4,              // bytes per word = bytes per DMA beat
  parameter int          TAG_W           = 8,
  parameter logic [63:0] DMA_BASE        = 64'h0,
  parameter int          A_SET_BYTES     = 4096,
  parameter int          B_SET_BYTES     = 4096,
  parameter int          NUM_SETS        = 2,
  parameter int          RSP_DEPTH       = 4,              // response FIFO entries (power of two >= 2)
  parameter int          WR_STARVE_LIMIT = 8,
  localparam int DW   = 8 * WB,
  localparam int LWB  = (WB > 1) ? $clog2(WB) : 1,   // (clamped: WB = 1 is rejected below)
  localparam int SW   = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int ABW  = $clog2(A_SET_BYTES),
  localparam int BBW  = $clog2(B_SET_BYTES),
  localparam int AWW  = ABW - LWB,
  localparam int BWW  = BBW - LWB,
  localparam int RAW  = $clog2(RSP_DEPTH),
  localparam int WCW  = $clog2(WR_STARVE_LIMIT + 2)
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // ---------------------------------------------------------- request
  input  wire logic                  req_valid,
  output logic                       req_ready,
  input  wire logic                  req_we,
  input  wire logic [ADDR_W-1:0]     req_addr,
  input  wire logic [DW-1:0]         req_wdata,
  input  wire logic [WB-1:0]         req_wstrb,
  input  wire logic [TAG_W-1:0]      req_tag,
  // ---------------------------------------------------------- response
  output logic                       rsp_valid,
  input  wire logic                  rsp_ready,
  output logic      [DW-1:0]         rsp_rdata,
  output logic                       rsp_err,
  output logic      [2:0]            rsp_err_code,
  output logic                       rsp_we,
  output logic      [TAG_W-1:0]      rsp_tag,
  // ---------------------------------------------------------- ownership
  input  wire logic [NUM_SETS*2-1:0] set_state,
  // ---------------------------------------------------------- to the bank arbiters
  output logic                       wr_valid,         // hold stage has a legal write
  output logic                       wr_is_b,          // 0: A region, 1: B region
  output logic      [SW-1:0]         wr_set,
  output logic      [AWW-1:0]        wr_word_a,        // word index inside the A set
  output logic      [BWW-1:0]        wr_word_b,        // word index inside the B set
  output logic      [DW-1:0]         wr_data,
  output logic      [WB-1:0]         wr_mask,
  output logic                       wr_force,
  input  wire logic                  wr_go,            // all target banks perform the write at this edge
  // ---------------------------------------------------------- status / events
  output logic                       hold_valid,
  output logic                       rsp_pending,
  output logic                       ev_wr,            // write performed this cycle
  output logic                       ev_wr_stall,      // legal write waiting for a bank port
  output logic                       ev_err            // error response produced this cycle
);

  localparam logic [63:0] A_TOT  = 64'(NUM_SETS) * 64'(A_SET_BYTES);
  localparam logic [63:0] B_TOT  = 64'(NUM_SETS) * 64'(B_SET_BYTES);
  localparam logic [63:0] REGION = (A_TOT > B_TOT) ? A_TOT : B_TOT;
  localparam logic [ADDR_W-1:0] BASE_T = DMA_BASE[ADDR_W-1:0];

  // ------------------------------------------------------------ configuration checks
  if (WB < 2 || (1 << LWB) != WB) begin : g_err_wb
    `SRAM_CFG_FATAL("tob_dma_port: WB must be a power of two >= 2")
  end
  if ((1 << ABW) != A_SET_BYTES || (1 << BBW) != B_SET_BYTES) begin : g_err_set_pow2
    `SRAM_CFG_FATAL("tob_dma_port: A_SET_BYTES and B_SET_BYTES must be powers of two")
  end
  if (RSP_DEPTH < 2 || (1 << RAW) != RSP_DEPTH) begin : g_err_rsp_depth
    `SRAM_CFG_FATAL("tob_dma_port: RSP_DEPTH must be a power of two >= 2")
  end
  if (ADDR_W < 64 && (DMA_BASE + REGION + B_TOT) > (64'd1 << ADDR_W)) begin : g_err_window
    `SRAM_CFG_FATAL("tob_dma_port: DMA window does not fit in ADDR_W bits")
  end
  if ((DMA_BASE % 64'(WB)) != 0) begin : g_err_base_align
    `SRAM_CFG_FATAL("tob_dma_port: DMA_BASE must be word aligned")
  end
  if (WR_STARVE_LIMIT < 0) begin : g_err_limit
    `SRAM_CFG_FATAL("tob_dma_port: WR_STARVE_LIMIT must be >= 0")
  end

  // ------------------------------------------------------------ hold stage
  logic              alive_q;
  logic              h_v, h_we;
  logic [ADDR_W-1:0] h_addr;
  logic [DW-1:0]     h_wdata;
  logic [WB-1:0]     h_wstrb;
  logic [TAG_W-1:0]  h_tag;

  // decode (combinational from the hold register)
  logic [ADDR_W-1:0] off, off_b;
  logic              below, in_a, in_b;
  logic [SW-1:0]     set_a, set_b, set_x;
  logic [1:0]        st_x;
  logic [2:0]        code;

  always_comb begin
    off   = h_addr - BASE_T;
    /* verilator lint_off UNSIGNED */
    below = h_addr < BASE_T;                 // constant 0 when DMA_BASE = 0
    /* verilator lint_on UNSIGNED */
    off_b = off - REGION[ADDR_W-1:0];
    in_a  = !below && (64'(off) < A_TOT);
    in_b  = !below && (64'(off) >= REGION) && (64'(off) < REGION + B_TOT);
    set_a = (NUM_SETS > 1) ? SW'(off >> ABW)   : '0;
    set_b = (NUM_SETS > 1) ? SW'(off_b >> BBW) : '0;
    set_x = in_a ? set_a : set_b;
    st_x  = set_state[set_x*2 +: 2];
    if (!in_a && !in_b)              code = `TOB_DERR_RANGE;
    else if (off[LWB-1:0] != '0)     code = `TOB_DERR_ALIGN;
    else if (!h_we)                  code = `TOB_DERR_UNSUP;
    else if (st_x != `TOB_ST_FILL)   code = `TOB_DERR_OWNER;
    else                             code = `TOB_DERR_OK;
  end

  wire h_err   = (code != `TOB_DERR_OK);
  wire retire  = h_v && (h_err || wr_go);

  assign wr_valid  = h_v && !h_err;
  assign wr_is_b   = !in_a;
  assign wr_set    = set_x;
  assign wr_word_a = AWW'(off[ABW-1:LWB]);
  assign wr_word_b = BWW'(off_b[BBW-1:LWB]);
  assign wr_data   = h_wdata;
  assign wr_mask   = h_wstrb;

  // ------------------------------------------------------------ response FIFO (DataFabric dma_fifo, unmodified)
  localparam int RW_ = TAG_W + 3 + 1;
  logic [RAW:0]    rf_cnt;
  logic [RW_-1:0]  rf_head;
  wire             rf_pop = rsp_valid && rsp_ready;

  dma_fifo #(.WIDTH(RW_), .DEPTH(RSP_DEPTH)) u_rsp_fifo (
    .clk(clk), .rst_n(rst_n), .clr(1'b0),
    .push(retire), .wdata({h_tag, code, h_we}),
    .pop(rf_pop), .rdata(rf_head), .count(rf_cnt)
  );

  assign rsp_valid    = (rf_cnt != '0);
  assign rsp_we       = rf_head[0];
  assign rsp_err_code = rf_head[3:1];
  assign rsp_err      = (rf_head[3:1] != `TOB_DERR_OK);
  assign rsp_tag      = rf_head[RW_-1:4];
  assign rsp_rdata    = '0;

  // credit: FIFO entries + the hold entry never exceed RSP_DEPTH
  wire [RAW+1:0] occ = (RAW+2)'(rf_cnt) + (RAW+2)'(h_v);
  assign req_ready = alive_q && (occ < (RAW+2)'(RSP_DEPTH)) && (!h_v || retire);
  wire   accept    = req_valid && req_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      alive_q <= 1'b0;
      h_v     <= 1'b0;
    end else begin
      alive_q <= 1'b1;
      if (accept)      h_v <= 1'b1;
      else if (retire) h_v <= 1'b0;
    end
  end

  always_ff @(posedge clk) begin
    if (accept) begin
      h_we    <= req_we;
      h_addr  <= req_addr;
      h_wdata <= req_wdata;
      h_wstrb <= req_wstrb;
      h_tag   <= req_tag;
    end
  end

  // ------------------------------------------------------------ write starvation counter
  logic [WCW-1:0] w_q;
  /* verilator lint_off UNSIGNED */      // WR_STARVE_LIMIT = 0 (write priority) makes these compares constant
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)                                                    w_q <= '0;
    else if (!h_v || retire)                                       w_q <= '0;
    else if (wr_valid && !wr_go && w_q < WCW'(WR_STARVE_LIMIT))    w_q <= w_q + 1'b1;
  end
  assign wr_force = (w_q >= WCW'(WR_STARVE_LIMIT));
  /* verilator lint_on UNSIGNED */

  assign hold_valid  = h_v;
  assign rsp_pending = rsp_valid;
  assign ev_wr       = retire && !h_err;
  assign ev_wr_stall = wr_valid && !wr_go;
  assign ev_err      = retire && h_err;

`ifdef TOB_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n) begin
      `SRAM_CHK(!(retire && !h_err && !wr_go), "tob_dma_port: legal write retired without wr_go")
      `SRAM_CHK(!(wr_valid && w_q > WCW'(WR_STARVE_LIMIT)), "tob_dma_port: write waited beyond WR_STARVE_LIMIT")
      `SRAM_CHK(!(wr_valid && wr_force && !wr_go), "tob_dma_port: forced write not granted")
    end
  end
`endif

endmodule

`default_nettype wire
