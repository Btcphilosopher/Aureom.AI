// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_bank
// One physical operand bank = one SilicaFlux SRAM Wrapper Library raw backend,
// used unmodified (third_party/silicaflux-sramlib):
//
//   PORT_MODE 1R1W -> sram_backend_1r1w  (write port = DMA, read port = compute)
//   PORT_MODE 1RW  -> sram_backend_1rw   (one port, time-shared by the arbiter)
//
//   BACKEND GENERIC : behavioural / synthesizable array (simulation, logic synthesis)
//   BACKEND FPGA    : block-RAM inference template (no vendor IP)
//   BACKEND ASIC    : real foundry/compiler macros (MACRO id), tiled by
//                     sram_asic_array; never falls back to flip-flops
//
// Word = DW bits, one write-mask lane per byte (DMA byte strobes).
// Raw contract (sramlib): rd_data is valid EXACTLY RL cycles after the read
// edge, for that one cycle; no reset of the array; addresses < DEPTH.
// Under 1RW the arbiter guarantees wr_en and rd_en are never both set.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tob_defs.svh"
`default_nettype none

module tob_bank #(
  parameter int  DW        = 32,
  parameter int  DEPTH     = 256,
  parameter int  RL        = 1,
  parameter int  PORT_MODE = `TOB_PORT_1R1W,
  parameter int  BACKEND   = `SRAM_BACKEND_GENERIC,
  parameter int  MACRO     = 0,
  localparam int NBY       = DW / 8,
  localparam int RW        = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic           clk,
  input  wire logic           wr_en,
  input  wire logic [RW-1:0]  wr_row,
  input  wire logic [DW-1:0]  wr_data,
  input  wire logic [NBY-1:0] wr_mask,
  input  wire logic           rd_en,
  input  wire logic [RW-1:0]  rd_row,
  output logic      [DW-1:0]  rd_data
);

  // The two branches share the block name g_ram (IEEE 1800 if-generate rule),
  // so the array is at <bank>.g_ram.u_ram.g_generic.u_mem.mem in both port
  // modes (testbench backdoor).
  if (PORT_MODE == `TOB_PORT_1R1W) begin : g_ram
    sram_backend_1r1w #(
      .DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(NBY), .READ_LATENCY(RL),
      .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_ram (
      .clk(clk), .we(wr_en), .wmask(wr_mask), .waddr(wr_row), .wdata(wr_data),
      .re(rd_en), .raddr(rd_row), .rdata(rd_data)
    );
  end else begin : g_ram
    sram_backend_1rw #(
      .DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(NBY), .READ_LATENCY(RL),
      .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_ram (
      .clk(clk), .ce(wr_en | rd_en), .we(wr_en), .wmask(wr_mask),
      .addr(wr_en ? wr_row : rd_row), .wdata(wr_data), .rdata(rd_data)
    );
`ifdef TOB_ASSERT
    // (the bank has no reset: skip the cycles before reset, where the enables are still X)
    always_ff @(posedge clk) begin
      if (!$isunknown({wr_en, rd_en}))
        `SRAM_CHK(!(wr_en && rd_en), "tob_bank: 1RW bank given a read and a write in one cycle")
    end
`endif
  end

endmodule

`default_nettype wire
