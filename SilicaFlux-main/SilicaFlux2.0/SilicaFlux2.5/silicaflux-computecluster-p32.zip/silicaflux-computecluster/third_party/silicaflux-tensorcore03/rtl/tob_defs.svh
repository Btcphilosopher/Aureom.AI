// =============================================================================
// SilicaFlux TENSORCORE 03 :: tob_defs.svh
// Constants of the banked tensor operand buffer (tensor_operand_buffer).
//
// A `define header rather than a package, for the same reason as the SRAM
// Wrapper Library's sram_defs.svh and Module 04's hpc_spm_defs.svh: Yosys 0.33
// cannot resolve package references in module parameter lists, and every
// synthesizable module here must elaborate unaided in Verilator 5.020,
// Icarus 12 and Yosys 0.33.
//
// Values are part of the public contract: never renumber, only append.
// =============================================================================
`ifndef TOB_DEFS_SVH
`define TOB_DEFS_SVH

`include "sram_defs.svh"

// ------------------------------------------------------------ bank memory-port model
// 1RW  : one read OR one write per physical bank per cycle  (sram_backend_1rw;
//        e.g. IHP SG13G2 1P, GF180MCU macros, FPGA single-port BRAM)
// 1R1W : one read AND one write per physical bank per cycle (sram_backend_1r1w;
//        e.g. FPGA simple-dual-port BRAM, SKY130 OpenRAM 1RW1R, IHP 2P)
`define TOB_PORT_1RW   0
`define TOB_PORT_1R1W  1

// ------------------------------------------------------------ placement of the two sets (NUM_SETS = 2)
// SHARED : both sets live in the same physical banks; the set index is the MSB
//          of the bank row.  DMA fill of one set and compute reads of the other
//          share each bank's ports (they contend under 1RW, not under 1R1W).
// SPLIT  : each set has its own physical banks (twice the banks, half the
//          depth).  DMA fill and compute reads never touch the same bank.
`define TOB_SET_SHARED 0
`define TOB_SET_SPLIT  1

// ------------------------------------------------------------ set ownership states (2 bits per set)
`define TOB_ST_EMPTY   2'd0   // no valid operands; nobody may access it
`define TOB_ST_FILL    2'd1   // owned by DMA: writes allowed, compute reads refused
`define TOB_ST_READY   2'd2   // filled and valid; waiting for compute
`define TOB_ST_COMPUTE 2'd3   // owned by compute: tiles may read, DMA writes refused

// ------------------------------------------------------------ DMA port response codes (3 bits)
// Codes 0..2 have the hpc_scratchpad (Module 04) meaning so the Module 05
// hpc_dma_spm_port adapter can drive this port unchanged; 6 and 7 use codes
// Module 04 reserves.  rdata is always zero.  Priority: RANGE > ALIGN > UNSUP > OWNER.
`define TOB_DERR_OK     3'd0  // write performed (array written before the response)
`define TOB_DERR_RANGE  3'd1  // outside the A or B window (incl. the hole between them): no side effect
`define TOB_DERR_ALIGN  3'd2  // byte address not word aligned: no side effect
`define TOB_DERR_OWNER  3'd6  // target set is not in FILL state (in use by compute, or not opened): no side effect
`define TOB_DERR_UNSUP  3'd7  // read request: the fill port is write-only: no side effect

// ------------------------------------------------------------ tile response codes (4 bits)
// Priority (first match wins): OWNER > EMPTY > LD > A_OVF > A_RANGE > B_OVF > B_RANGE.
`define TOB_TERR_OK      4'd0
`define TOB_TERR_EMPTY   4'd1  // tile_k == 0 or tile origin outside the matrix (m0>=mat_m, n0>=mat_n, k0>=mat_k)
`define TOB_TERR_LD      4'd2  // lda < mat_k or ldb < mat_n (rows would overlap)
`define TOB_TERR_A_OVF   4'd3  // last A byte address >= 2^ADDR_W (would wrap a naive ADDR_W adder)
`define TOB_TERR_A_RANGE 4'd4  // last A byte address >= A_SET_BYTES
`define TOB_TERR_B_OVF   4'd5
`define TOB_TERR_B_RANGE 4'd6
`define TOB_TERR_OWNER   4'd7  // no set is in COMPUTE state

// ------------------------------------------------------------ event vector (ev_inc), one field of EV_W bits per event
// Every field is the number of events in that cycle (multi-event increments),
// directly usable as the inc_i input of hpc_perf_counters (Module 07).
`define TOB_EV_CYCLES         0   // 1 every cycle
`define TOB_EV_ACTIVE         1   // a tile is being delivered (consumer has a context)
`define TOB_EV_SLICES         2   // k-slices delivered (s_valid && s_ready)
`define TOB_EV_STARVE         3   // operand starvation: a tile is active, the output stage can take a slice, operands missing
`define TOB_EV_STARVE_A       4   //   ... of which at least one live A lane had no staged word
`define TOB_EV_STARVE_B       5   //   ... of which no staged B row
`define TOB_EV_ARRAY_BP       6   // s_valid && !s_ready (consumer back-pressure)
`define TOB_EV_A_RD_WORDS     7   // A bank words read this cycle
`define TOB_EV_B_RD_WORDS     8   // B bank words read this cycle
`define TOB_EV_A_RD_STALL     9   // A lanes that requested a word and were not granted
`define TOB_EV_B_RD_STALL    10   // B row/beat request not granted (1)
`define TOB_EV_BANK_CONFLICT 11   // physical banks with >= 2 eligible read requesters (one served, rest wait)
`define TOB_EV_RD_WR_BLOCK   12   // read requesters blocked by a DMA write (1RW port or same-row hazard)
`define TOB_EV_WR_STALL      13   // a legal DMA write waited for a bank port this cycle
`define TOB_EV_WR_WORDS      14   // DMA writes performed
`define TOB_EV_WR_FORCED     15   // DMA writes that displaced a read (starvation limit reached)
`define TOB_EV_DMA_ERR       16   // DMA error responses produced
`define TOB_EV_TILE_OK       17   // tiles accepted without error
`define TOB_EV_TILE_ERR      18   // tiles rejected
`define TOB_EV_OVERLAP       19   // cycles in which a DMA write was performed AND a slice was delivered
`define TOB_NUM_EV           20

`endif // TOB_DEFS_SVH
