// =============================================================================
//  SilicaFlux TENSORCORE 02  --  tensor_systolic_array.sv        (PRIMARY SOURCE)
//  Aureom.AI | SilicaFlux-HPC
//
//  Configurable 2D OUTPUT-STATIONARY systolic array:
//        C[M,N] = A[M,K] x B[K,N]          one output tile per launch,
//        M <= ARRAY_ROWS, N <= ARRAY_COLS, 1 <= K < 2**K_WIDTH.
//
//  DATAFLOW (full detail in docs/ARCHITECTURE.md)
//    * PE(i,j) owns C[i][j] and keeps its partial sum in its own accumulator.
//    * A operands travel EAST along each row, B operands travel SOUTH down each
//      column, one registered hop per enabled cycle.
//    * The producer presents one "k-slice" per handshake: s_a = A[:,k] (lane i =
//      row i) and s_b = B[k,:] (lane j = column j).  tensor_skew delays A lane
//      i by (1+i) registers and B lane j by (1+j), so A[i][k] and B[k][j] meet
//      at PE(i,j) in the same en-cycle  t = k + 1 + i + j  (en-cycles counted
//      from the first accepted slice).
//    * This is NOT weight-stationary: no operand is preloaded or held in a PE.
//
//  STALL PROTOCOL: single GLOBAL pipeline enable `pipe_en`.
//    pipe_en = ~stall_i & ( RUN ? s_valid : DRAIN )
//    - RUN   : the array advances exactly when a slice is accepted.  A missing
//              slice (s_valid == 0) or stall_i freezes EVERYTHING (skew, PEs,
//              accumulators, tags).  No bubble tokens are injected.
//    - DRAIN : free-running (bubbles injected) unless stall_i freezes it.
//    - No PE is ever stalled on its own.
//
//  TILE LIFECYCLE
//    IDLE --cfg--> CLEAR(1 cycle, clr to all PEs/skew) --> RUN(K accepted
//    slices) --> DRAIN(until every active PE reports done) --> READOUT(results
//    stable; tile_done=1; M rows streamed with valid/ready) --> IDLE.
//
//  RESULT / BACKPRESSURE
//    Results are held in the PE accumulators and streamed one row per beat
//    (m_data = COLS x ACC_WIDTH).  m_ready only paces the readout sequencer; the
//    accumulators are static during READOUT so partial sums cannot be disturbed.
//    Mid-computation global backpressure is stall_i (see above).
//
//  TUNABLES:  ARRAY_ROWS, ARRAY_COLS, DATA_WIDTH, ACC_WIDTH (required), plus
//    K_WIDTH   : width of K counter / cfg_k.  Default 17 -> K_max = 131071, the
//                largest K for which INT8xINT8 -> INT32 cannot overflow.
//    MUL_PIPE  : 0/1 product register inside every PE.
//    CHECK_ALIGN: 1 enables the in-array K-index/valid alignment checker
//                (sticky `align_err`).  0 removes it (and the k-index sideband
//                registers are pruned by synthesis).
//    PERF_EN   : 1 instantiates the per-tile performance counters.
// =============================================================================
module tensor_systolic_array #(
    parameter int ARRAY_ROWS  = 4,
    parameter int ARRAY_COLS  = 4,
    parameter int DATA_WIDTH  = 8,
    parameter int ACC_WIDTH   = 32,
    parameter int K_WIDTH     = 17,
    parameter int MUL_PIPE    = 0,
    parameter int CHECK_ALIGN = 1,
    parameter int PERF_EN     = 1
) (
    input  logic                                   clk,
    input  logic                                   rst_n,

    // ---------------------------------------------------------- tile launch
    input  logic                                   cfg_valid,
    output logic                                   cfg_ready,
    input  logic [$clog2(ARRAY_ROWS+1)-1:0]        cfg_m,       // 1..ARRAY_ROWS
    input  logic [$clog2(ARRAY_COLS+1)-1:0]        cfg_n,       // 1..ARRAY_COLS
    input  logic [K_WIDTH-1:0]                     cfg_k,       // 1..2**K_WIDTH-1
    output logic                                   cfg_reject,  // 1-cycle pulse: illegal cfg dropped

    // ------------------------------------------------------ operand k-slices
    input  logic                                   s_valid,
    output logic                                   s_ready,
    input  logic [ARRAY_ROWS*DATA_WIDTH-1:0]       s_a,         // A[:,k], lane i = row i
    input  logic [ARRAY_COLS*DATA_WIDTH-1:0]       s_b,         // B[k,:], lane j = col j
    output logic [K_WIDTH-1:0]                     s_k,         // index k of the slice expected next

    // ------------------------------------------------- global freeze request
    input  logic                                   stall_i,

    // -------------------------------------------------------- result stream
    output logic                                   m_valid,
    input  logic                                   m_ready,
    output logic [((ARRAY_ROWS>1)?$clog2(ARRAY_ROWS):1)-1:0] m_row,
    output logic [ARRAY_COLS*ACC_WIDTH-1:0]        m_data,      // lane j = C[m_row][j]
    output logic [ARRAY_COLS-1:0]                  m_col_mask,
    output logic                                   m_last,

    // --------------------------------------------------------------- status
    output logic                                   busy,
    output logic                                   tile_done,   // level, high throughout READOUT
    output logic                                   align_err,   // sticky until next launch/reset

    // ---------------------------------------------- per-tile perf counters
    output logic [39:0]                            perf_busy,      // CLEAR+RUN+DRAIN cycles
    output logic [39:0]                            perf_issue,     // accepted slices (== K)
    output logic [39:0]                            perf_stall_up,  // RUN cycles starved of a slice
    output logic [39:0]                            perf_stall_ext, // RUN/DRAIN cycles frozen by stall_i
    output logic [39:0]                            perf_mac,       // useful MACs committed
    output logic [39:0]                            perf_pad        // PE-slots lost to padding (per issued slice)
);

    // ------------------------------------------------------------- constants
    localparam int RIDW = (ARRAY_ROWS > 1) ? $clog2(ARRAY_ROWS) : 1;
    localparam int TW   = K_WIDTH + DATA_WIDTH + 2;     // {kidx, data, last, valid}
    localparam int NPE  = ARRAY_ROWS * ARRAY_COLS;
    localparam int AW   = ARRAY_COLS + 1;               // A-bus columns per row
    localparam int PERF_W = 40;

    localparam logic [2:0] S_IDLE    = 3'd0;
    localparam logic [2:0] S_CLEAR   = 3'd1;
    localparam logic [2:0] S_RUN     = 3'd2;
    localparam logic [2:0] S_DRAIN   = 3'd3;
    localparam logic [2:0] S_READOUT = 3'd4;

    // synthesis translate_off
    initial begin
        if (ARRAY_ROWS < 1 || ARRAY_COLS < 1) $fatal(1, "array dimensions must be >= 1");
        if (K_WIDTH < 1)                      $fatal(1, "K_WIDTH must be >= 1");
        if (ACC_WIDTH < 2*DATA_WIDTH)         $fatal(1, "ACC_WIDTH must be >= 2*DATA_WIDTH");
    end
    // synthesis translate_on

    // ------------------------------------------------------ controller state
    logic [2:0]                         state_q, state_d;
    logic [$clog2(ARRAY_ROWS+1)-1:0]    m_q;
    // n_q only feeds the optional performance counters (PERF_EN); unused when PERF_EN == 0.
    /* verilator lint_off UNUSEDSIGNAL */
    logic [$clog2(ARRAY_COLS+1)-1:0]    n_q;
    /* verilator lint_on UNUSEDSIGNAL */
    logic [K_WIDTH-1:0]                 k_len_q, k_cnt_q;
    logic [ARRAY_ROWS-1:0]              row_mask_q;
    logic [ARRAY_COLS-1:0]              col_mask_q;
    logic [RIDW-1:0]                    rd_row_q;
    logic                               cfg_reject_q;

    logic cfg_legal, cfg_go, s_go, k_last, pipe_en, clr_c, all_done;

    assign cfg_ready = (state_q == S_IDLE);
    // The upper-bound compares are vacuously true when cfg_m/cfg_n are too narrow to
    // exceed the array size (e.g. 1x1, or 3 rows -> 2-bit M); that is intended.
    /* verilator lint_off CMPCONST */
    assign cfg_legal = (cfg_m != '0) && (32'(cfg_m) <= ARRAY_ROWS) &&
                       (cfg_n != '0) && (32'(cfg_n) <= ARRAY_COLS) &&
                       (cfg_k != '0);
    /* verilator lint_on CMPCONST */
    assign cfg_go    = cfg_valid & cfg_ready & cfg_legal;

    assign s_ready   = (state_q == S_RUN) & ~stall_i;
    assign s_go      = s_valid & s_ready;
    assign k_last    = (k_cnt_q == (k_len_q - K_WIDTH'(1)));
    assign s_k       = k_cnt_q;

    assign pipe_en   = ~stall_i & ((state_q == S_RUN) ? s_valid : (state_q == S_DRAIN));
    assign clr_c     = (state_q == S_CLEAR);

    assign m_valid   = (state_q == S_READOUT);
    assign tile_done = (state_q == S_READOUT);
    assign busy      = (state_q != S_IDLE);
    assign m_row     = rd_row_q;
    assign m_col_mask= col_mask_q;
    assign m_last    = (32'(rd_row_q) == 32'(m_q) - 1);
    assign cfg_reject= cfg_reject_q;

    always_comb begin
        state_d = state_q;
        case (state_q)
            S_IDLE:    if (cfg_go)                       state_d = S_CLEAR;
            S_CLEAR:                                     state_d = S_RUN;
            S_RUN:     if (s_go && k_last)               state_d = S_DRAIN;
            S_DRAIN:   if (all_done)                     state_d = S_READOUT;
            S_READOUT: if (m_valid && m_ready && m_last) state_d = S_IDLE;
            default:                                     state_d = S_IDLE;
        endcase
    end

    always_ff @(posedge clk) begin
        if (!rst_n) begin
            state_q      <= S_IDLE;
            m_q          <= '0;
            n_q          <= '0;
            k_len_q      <= '0;
            k_cnt_q      <= '0;
            row_mask_q   <= '0;
            col_mask_q   <= '0;
            rd_row_q     <= '0;
            cfg_reject_q <= 1'b0;
        end else begin
            state_q      <= state_d;
            cfg_reject_q <= cfg_valid & cfg_ready & ~cfg_legal;

            if (cfg_go) begin
                m_q      <= cfg_m;
                n_q      <= cfg_n;
                k_len_q  <= cfg_k;
                k_cnt_q  <= '0;
                rd_row_q <= '0;
                for (int i = 0; i < ARRAY_ROWS; i++) row_mask_q[i] <= (32'(cfg_m) > i);
                for (int j = 0; j < ARRAY_COLS; j++) col_mask_q[j] <= (32'(cfg_n) > j);
            end

            if (s_go) k_cnt_q <= k_cnt_q + K_WIDTH'(1);

            if (m_valid && m_ready && !m_last) rd_row_q <= rd_row_q + RIDW'(1);
        end
    end

    // ------------------------------------------- input distribution / padding
    //  A lane is "live" only for the accepted slice AND only if its row/column
    //  lies inside the active MxN tile.  Dead lanes inject valid = 0 AND data = 0
    //  (zero padding); both protections are independent: valid gates the MAC,
    //  zeroing keeps the datapath quiet.
    logic [ARRAY_ROWS*TW-1:0] a_tok_in, a_tok_out;
    logic [ARRAY_COLS*TW-1:0] b_tok_in, b_tok_out;

    genvar i, j;
    generate
        for (i = 0; i < ARRAY_ROWS; i++) begin : g_ainj
            logic live;
            assign live = s_go & row_mask_q[i];
            assign a_tok_in[i*TW +: TW] = {
                live ? k_cnt_q                          : {K_WIDTH{1'b0}},
                live ? s_a[i*DATA_WIDTH +: DATA_WIDTH]  : {DATA_WIDTH{1'b0}},
                live & k_last,
                live
            };
        end
        for (j = 0; j < ARRAY_COLS; j++) begin : g_binj
            logic live;
            assign live = s_go & col_mask_q[j];
            assign b_tok_in[j*TW +: TW] = {
                live ? k_cnt_q                          : {K_WIDTH{1'b0}},
                live ? s_b[j*DATA_WIDTH +: DATA_WIDTH]  : {DATA_WIDTH{1'b0}},
                live & k_last,
                live
            };
        end
    endgenerate

    tensor_skew #(.LANES(ARRAY_ROWS), .WIDTH(TW), .BASE(1)) u_skew_a (
        .clk(clk), .rst_n(rst_n), .clr(clr_c), .en(pipe_en),
        .in_flat(a_tok_in), .out_flat(a_tok_out));

    tensor_skew #(.LANES(ARRAY_COLS), .WIDTH(TW), .BASE(1)) u_skew_b (
        .clk(clk), .rst_n(rst_n), .clr(clr_c), .en(pipe_en),
        .in_flat(b_tok_in), .out_flat(b_tok_out));

    // ---------------------------------------------------------------- PE grid
    //  Flat buses.  A token at the input of PE(i,j): index i*AW + j  (j==COLS is
    //  the unused east edge).  B token at the input of PE(i,j): i*COLS + j
    //  (i==ROWS is the unused south edge).
    // The east/south edge slots and the fire_flat vector are intentionally not
    // consumed inside the design (edge terminations / verification visibility).
    /* verilator lint_off UNUSEDSIGNAL */
    logic [ARRAY_ROWS*AW-1:0]                      a_valid_bus, a_last_bus;
    logic [ARRAY_ROWS*AW*DATA_WIDTH-1:0]           a_data_bus;
    logic [ARRAY_ROWS*AW*K_WIDTH-1:0]              a_kidx_bus;
    logic [(ARRAY_ROWS+1)*ARRAY_COLS-1:0]          b_valid_bus, b_last_bus;
    logic [(ARRAY_ROWS+1)*ARRAY_COLS*DATA_WIDTH-1:0] b_data_bus;
    logic [(ARRAY_ROWS+1)*ARRAY_COLS*K_WIDTH-1:0]  b_kidx_bus;

    logic [NPE*ACC_WIDTH-1:0] acc_flat;
    logic [NPE-1:0]           done_flat, fire_flat, commit_flat, err_flat;
    /* verilator lint_on UNUSEDSIGNAL */

    generate
        for (i = 0; i < ARRAY_ROWS; i++) begin : g_aedge
            assign a_valid_bus[i*AW] = a_tok_out[i*TW];
            assign a_last_bus [i*AW] = a_tok_out[i*TW + 1];
            assign a_data_bus[(i*AW)*DATA_WIDTH +: DATA_WIDTH] = a_tok_out[i*TW + 2 +: DATA_WIDTH];
            assign a_kidx_bus[(i*AW)*K_WIDTH    +: K_WIDTH]    = a_tok_out[i*TW + 2 + DATA_WIDTH +: K_WIDTH];
        end
        for (j = 0; j < ARRAY_COLS; j++) begin : g_bedge
            assign b_valid_bus[j] = b_tok_out[j*TW];
            assign b_last_bus [j] = b_tok_out[j*TW + 1];
            assign b_data_bus[j*DATA_WIDTH +: DATA_WIDTH] = b_tok_out[j*TW + 2 +: DATA_WIDTH];
            assign b_kidx_bus[j*K_WIDTH    +: K_WIDTH]    = b_tok_out[j*TW + 2 + DATA_WIDTH +: K_WIDTH];
        end

        for (i = 0; i < ARRAY_ROWS; i++) begin : g_row
            for (j = 0; j < ARRAY_COLS; j++) begin : g_col
                localparam int AI = i*AW + j;               // A input index
                localparam int BI = i*ARRAY_COLS + j;       // B input index
                localparam int PI = i*ARRAY_COLS + j;       // PE index
                tensor_pe #(
                    .DATA_WIDTH (DATA_WIDTH),
                    .ACC_WIDTH  (ACC_WIDTH),
                    .KIDX_WIDTH (K_WIDTH),
                    .MUL_PIPE   (MUL_PIPE),
                    .CHECK_ALIGN(CHECK_ALIGN)
                ) u_pe (
                    .clk(clk), .rst_n(rst_n), .clr(clr_c), .en(pipe_en),
                    .chk_en(row_mask_q[i] & col_mask_q[j]),
                    .a_valid_i(a_valid_bus[AI]),
                    .a_last_i (a_last_bus[AI]),
                    .a_data_i (a_data_bus[AI*DATA_WIDTH +: DATA_WIDTH]),
                    .a_kidx_i (a_kidx_bus[AI*K_WIDTH +: K_WIDTH]),
                    .b_valid_i(b_valid_bus[BI]),
                    .b_last_i (b_last_bus[BI]),
                    .b_data_i (b_data_bus[BI*DATA_WIDTH +: DATA_WIDTH]),
                    .b_kidx_i (b_kidx_bus[BI*K_WIDTH +: K_WIDTH]),
                    .a_valid_o(a_valid_bus[AI+1]),
                    .a_last_o (a_last_bus[AI+1]),
                    .a_data_o (a_data_bus[(AI+1)*DATA_WIDTH +: DATA_WIDTH]),
                    .a_kidx_o (a_kidx_bus[(AI+1)*K_WIDTH +: K_WIDTH]),
                    .b_valid_o(b_valid_bus[BI+ARRAY_COLS]),
                    .b_last_o (b_last_bus[BI+ARRAY_COLS]),
                    .b_data_o (b_data_bus[(BI+ARRAY_COLS)*DATA_WIDTH +: DATA_WIDTH]),
                    .b_kidx_o (b_kidx_bus[(BI+ARRAY_COLS)*K_WIDTH +: K_WIDTH]),
                    .acc_o    (acc_flat[PI*ACC_WIDTH +: ACC_WIDTH]),
                    .done_o   (done_flat[PI]),
                    .fire_o   (fire_flat[PI]),
                    .commit_o (commit_flat[PI]),
                    .err_o    (err_flat[PI])
                );
            end
        end
    endgenerate

    // ------------------------------------------------------ output collection
    logic [ARRAY_COLS*ACC_WIDTH-1:0] rd_data;

    tensor_output_collect #(
        .ARRAY_ROWS(ARRAY_ROWS), .ARRAY_COLS(ARRAY_COLS), .ACC_WIDTH(ACC_WIDTH)
    ) u_collect (
        .acc_flat(acc_flat), .done_flat(done_flat),
        .row_mask(row_mask_q), .col_mask(col_mask_q),
        .rd_row(rd_row_q),
        .all_done(all_done), .rd_data(rd_data)
    );
    assign m_data = rd_data;

    // ------------------------------------------------ alignment error (sticky)
    logic align_err_q;
    always_ff @(posedge clk) begin
        if (!rst_n || clr_c)  align_err_q <= 1'b0;
        else if (|err_flat)   align_err_q <= 1'b1;
    end
    assign align_err = align_err_q;

    // ------------------------------------------------------ performance counters
    generate
        if (PERF_EN != 0) begin : g_perf
            logic [PERF_W-1:0] busy_q, issue_q, stall_up_q, stall_ext_q, mac_q, pad_q;
            localparam int PCW = $clog2(NPE + 1);
            logic [PCW-1:0] popc;
            int             pad_slots_c;
            always_comb begin
                pad_slots_c = NPE - 32'(m_q) * 32'(n_q);
                popc = '0;
                for (int x = 0; x < NPE; x++) popc = popc + PCW'(commit_flat[x]);
            end
            always_ff @(posedge clk) begin
                if (!rst_n || cfg_go) begin
                    busy_q <= '0; issue_q <= '0; stall_up_q <= '0;
                    stall_ext_q <= '0; mac_q <= '0; pad_q <= '0;
                end else begin
                    if (state_q == S_CLEAR || state_q == S_RUN || state_q == S_DRAIN)
                        busy_q <= busy_q + PERF_W'(1);
                    if (s_go) begin
                        issue_q <= issue_q + PERF_W'(1);
                        pad_q   <= pad_q + PERF_W'(pad_slots_c);
                    end
                    if (state_q == S_RUN && !stall_i && !s_valid)
                        stall_up_q <= stall_up_q + PERF_W'(1);
                    // Only EFFECTIVE stalls are counted: a stall asserted in the DRAIN
                    // cycle in which all_done is already true delays nothing (the FSM
                    // leaves DRAIN regardless), so it is excluded.  This keeps the
                    // identity  busy = 1 + K + M + N + MUL_PIPE + stall_up + stall_ext.
                    if ((state_q == S_RUN || (state_q == S_DRAIN && !all_done)) && stall_i)
                        stall_ext_q <= stall_ext_q + PERF_W'(1);
                    mac_q <= mac_q + PERF_W'(popc);
                end
            end
            assign perf_busy      = busy_q;
            assign perf_issue     = issue_q;
            assign perf_stall_up  = stall_up_q;
            assign perf_stall_ext = stall_ext_q;
            assign perf_mac       = mac_q;
            assign perf_pad       = pad_q;
        end else begin : g_noperf
            assign perf_busy      = '0;
            assign perf_issue     = '0;
            assign perf_stall_up  = '0;
            assign perf_stall_ext = '0;
            assign perf_mac       = '0;
            assign perf_pad       = '0;
        end
    endgenerate

endmodule
