// =============================================================================
//  SilicaFlux TENSORCORE 02  --  tensor_skew.sv
//  Triangular skew (input-distribution) network.
//
//  Lane l is delayed by BASE + l pipeline registers.
//    * BASE = 1 gives every lane one common input register (so no top-level
//      input pin feeds a multiplier combinationally).  A uniform extra delay on
//      all lanes does not change relative alignment.
//    * The "+ l" term is the systolic skew: A row i is delayed by i, B column j
//      by j, so that A[i][k] and B[k][j] reach PE(i,j) in the same en-cycle.
//
//  All registers shift together under the single global enable `en`; with
//  en == 0 the whole network holds, which preserves token alignment through any
//  stall.  `clr` flushes the network (tile launch); rst_n likewise.
//
//  Token layout is opaque to this module (WIDTH bits per lane), lane l occupies
//  bits [l*WIDTH +: WIDTH] of the flat buses.
// =============================================================================
module tensor_skew #(
    parameter int LANES = 4,
    parameter int WIDTH = 10,
    parameter int BASE  = 1
) (
    input  logic                    clk,
    input  logic                    rst_n,
    input  logic                    clr,
    input  logic                    en,
    input  logic [LANES*WIDTH-1:0]  in_flat,
    output logic [LANES*WIDTH-1:0]  out_flat
);

    genvar l;
    generate
        for (l = 0; l < LANES; l++) begin : g_lane
            localparam int D = BASE + l;
            if (D == 0) begin : g_wire
                assign out_flat[l*WIDTH +: WIDTH] = in_flat[l*WIDTH +: WIDTH];
            end else begin : g_sr
                logic [WIDTH-1:0] sr [D];
                always_ff @(posedge clk) begin
                    if (!rst_n || clr) begin
                        for (int s = 0; s < D; s++) sr[s] <= '0;
                    end else if (en) begin
                        sr[0] <= in_flat[l*WIDTH +: WIDTH];
                        for (int s = 1; s < D; s++) sr[s] <= sr[s-1];
                    end
                end
                assign out_flat[l*WIDTH +: WIDTH] = sr[D-1];
            end
        end
    endgenerate

endmodule
