// =============================================================================
//  SilicaFlux TENSORCORE 02  --  tensor_output_collect.sv
//  Output collection logic.
//
//  1. COMPLETION DETECTION  (all_done)
//     all_done = every ACTIVE PE (row_mask[i] & col_mask[j]) has raised its
//     sticky done flag.  A PE raises done at the clock edge that commits its
//     K-th (tagged `last`) product, so all_done == 1 means:
//        - every required K product has been accumulated in every active PE,
//        - the accumulators are final and stable (no further valid tokens can
//          reach an active PE: its own `last` token was the final one),
//        - the useful wavefront has drained.
//     This is a measured condition on the real PEs.  It is NOT a fixed delay
//     and it automatically absorbs the PE's MUL_PIPE latency and any stalls.
//
//  2. RESULT EXTRACTION  (rd_data)
//     Combinational row-select mux over the (stable) accumulators.  Columns
//     outside col_mask read as zero.  Row sequencing and the valid/ready
//     handshake live in the array top.
// =============================================================================
module tensor_output_collect #(
    parameter int ARRAY_ROWS = 4,
    parameter int ARRAY_COLS = 4,
    parameter int ACC_WIDTH  = 32
) (
    input  logic [ARRAY_ROWS*ARRAY_COLS*ACC_WIDTH-1:0] acc_flat,   // [i*COLS+j]
    input  logic [ARRAY_ROWS*ARRAY_COLS-1:0]           done_flat,
    input  logic [ARRAY_ROWS-1:0]                      row_mask,
    input  logic [ARRAY_COLS-1:0]                      col_mask,
    input  logic [((ARRAY_ROWS>1)?$clog2(ARRAY_ROWS):1)-1:0] rd_row,

    output logic                                       all_done,
    output logic [ARRAY_COLS*ACC_WIDTH-1:0]            rd_data
);

    // ---------------------------------------------------- completion detect
    logic [ARRAY_ROWS*ARRAY_COLS-1:0] pending;
    genvar i, j;
    generate
        for (i = 0; i < ARRAY_ROWS; i++) begin : g_pr
            for (j = 0; j < ARRAY_COLS; j++) begin : g_pc
                assign pending[i*ARRAY_COLS + j] =
                    row_mask[i] & col_mask[j] & ~done_flat[i*ARRAY_COLS + j];
            end
        end
    endgenerate
    assign all_done = ~(|pending);

    // ------------------------------------------------------- row read mux
    generate
        for (j = 0; j < ARRAY_COLS; j++) begin : g_rd
            assign rd_data[j*ACC_WIDTH +: ACC_WIDTH] =
                col_mask[j]
                ? acc_flat[(32'(rd_row)*ARRAY_COLS + j)*ACC_WIDTH +: ACC_WIDTH]
                : '0;
        end
    endgenerate

endmodule
