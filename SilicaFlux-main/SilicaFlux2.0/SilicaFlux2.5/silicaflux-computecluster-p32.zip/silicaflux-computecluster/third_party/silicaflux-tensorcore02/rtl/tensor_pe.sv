// =============================================================================
//  SilicaFlux TENSORCORE 02  --  tensor_pe.sv
//  Aureom.AI | SilicaFlux-HPC
//
//  PROVENANCE NOTE
//  ---------------
//  The brief names an existing `tensor_pe.sv`.  No such file (and no other
//  tensor RTL) was present in the repository handed to this session, so this
//  module is a NEW implementation written for TENSORCORE 02.  It has been
//  verified only by the tests shipped in this repository (tb/tb_pe.sv and the
//  array-level regression).  It must NOT be assumed to match any earlier PE.
//  See docs/AUDIT.md.
//
//  FUNCTION
//  --------
//  Output-stationary signed multiply-accumulate processing element.
//    * Operand tokens arrive from the west (A) and the north (B).
//    * Both tokens are forwarded, REGISTERED, to the east (A) and south (B)
//      (one hop = exactly one enabled cycle).
//    * When BOTH tokens at the input pins are valid, the product is accumulated
//      into the local signed ACC_WIDTH accumulator.  Padded/invalid tokens can
//      never accumulate: accumulation is gated by (a_valid & b_valid), not by
//      the data value.
//
//  LATENCY  (en-cycles; an "en-cycle" is a clock cycle in which `en` == 1)
//  -------
//    MUL_PIPE = 0 : token at the input pins in en-cycle t -> accumulator updated
//                   at the clock edge ending t (visible in the next cycle).
//    MUL_PIPE = 1 : product registered at the edge ending t, accumulated at the
//                   edge ending t+1.  PE MAC latency = 2.
//    Forward latency (A->east, B->south): 1 en-cycle, independent of MUL_PIPE.
//  Throughput: 1 MAC per PE per en-cycle in both modes (demonstrated by the
//  array-level tests, see docs/PERFORMANCE.md).
//
//  STALL SEMANTICS
//  ---------------
//  `en` is the GLOBAL pipeline enable.  When en == 0 every datapath register
//  (forward regs, product reg, accumulator, done flag) HOLDS.  A PE is never
//  stalled independently of its neighbours.  `clr` is a synchronous tile-launch
//  clear that overrides `en` (it is only issued while the array is idle).
//
//  DONE SEMANTICS
//  --------------
//  `done_o` is a sticky flag set at the SAME clock edge that commits the token
//  tagged `last` (k == K-1) into the accumulator, so done_o == 1 implies
//  acc_o already holds the final dot product.  The tag travels through the
//  same registers as the data, so done tracks the real PE latency (it is not a
//  fixed delay).
// =============================================================================
module tensor_pe #(
    parameter int DATA_WIDTH  = 8,
    parameter int ACC_WIDTH   = 32,
    parameter int KIDX_WIDTH  = 17,
    parameter int MUL_PIPE    = 0,   // 0: MAC in one stage, 1: registered product
    parameter int CHECK_ALIGN = 0    // 1: enable K-index / valid alignment checker
) (
    input  logic                          clk,
    input  logic                          rst_n,
    input  logic                          clr,       // tile launch clear (overrides en)
    input  logic                          en,        // global pipeline enable
    input  logic                          chk_en,    // PE lies inside the active MxN region

    // ---- A token, from the west -------------------------------------------
    input  logic                          a_valid_i,
    input  logic                          a_last_i,
    input  logic signed [DATA_WIDTH-1:0]  a_data_i,
    input  logic [KIDX_WIDTH-1:0]         a_kidx_i,
    // ---- B token, from the north ------------------------------------------
    input  logic                          b_valid_i,
    input  logic                          b_last_i,
    input  logic signed [DATA_WIDTH-1:0]  b_data_i,
    input  logic [KIDX_WIDTH-1:0]         b_kidx_i,

    // ---- forwarded tokens (registered) ------------------------------------
    output logic                          a_valid_o,
    output logic                          a_last_o,
    output logic signed [DATA_WIDTH-1:0]  a_data_o,
    output logic [KIDX_WIDTH-1:0]         a_kidx_o,
    output logic                          b_valid_o,
    output logic                          b_last_o,
    output logic signed [DATA_WIDTH-1:0]  b_data_o,
    output logic [KIDX_WIDTH-1:0]         b_kidx_o,

    // ---- result / status ---------------------------------------------------
    output logic signed [ACC_WIDTH-1:0]   acc_o,
    output logic                          done_o,
    output logic                          fire_o,    // operands consumed this en-cycle
    output logic                          commit_o,  // accumulator updated this en-cycle
    output logic                          err_o      // alignment violation (CHECK_ALIGN)
);

    // ---------------------------------------------------------------- checks
    // synthesis translate_off
    initial begin
        if (ACC_WIDTH < 2*DATA_WIDTH)
            $fatal(1, "tensor_pe: ACC_WIDTH (%0d) must be >= 2*DATA_WIDTH (%0d)",
                   ACC_WIDTH, 2*DATA_WIDTH);
        if (MUL_PIPE != 0 && MUL_PIPE != 1)
            $fatal(1, "tensor_pe: MUL_PIPE must be 0 or 1");
    end
    // synthesis translate_on

    // ------------------------------------------------------------- datapath
    logic signed [ACC_WIDTH-1:0]    acc_q;
    logic                           done_q;

    logic fire_c;
    assign fire_c = a_valid_i & b_valid_i;

    logic signed [2*DATA_WIDTH-1:0] prod_c;
    assign prod_c = a_data_i * b_data_i;               // signed x signed

    logic signed [2*DATA_WIDTH-1:0] prod_q;            // used when MUL_PIPE == 1
    logic                           prod_vld_q;
    logic                           prod_last_q;

    logic                           mac_c;             // accumulate this en-cycle
    logic                           mac_last_c;
    logic signed [2*DATA_WIDTH-1:0] mac_prod_c;

    always_comb begin
        if (MUL_PIPE == 0) begin
            mac_c      = fire_c;
            mac_last_c = a_last_i & b_last_i;
            mac_prod_c = prod_c;
        end else begin
            mac_c      = prod_vld_q;
            mac_last_c = prod_last_q;
            mac_prod_c = prod_q;
        end
    end

    logic signed [ACC_WIDTH-1:0] mac_prod_ext;
    // Explicit SIGN extension of the 2*DATA_WIDTH product to ACC_WIDTH.
    assign mac_prod_ext = ACC_WIDTH'($signed(mac_prod_c));

    always_ff @(posedge clk) begin
        if (!rst_n || clr) begin
            a_valid_o   <= 1'b0;
            a_last_o    <= 1'b0;
            a_data_o    <= '0;
            a_kidx_o    <= '0;
            b_valid_o   <= 1'b0;
            b_last_o    <= 1'b0;
            b_data_o    <= '0;
            b_kidx_o    <= '0;
            acc_q       <= '0;
            done_q      <= 1'b0;
            prod_q      <= '0;
            prod_vld_q  <= 1'b0;
            prod_last_q <= 1'b0;
        end else if (en) begin
            // operand forwarding: one registered hop
            a_valid_o <= a_valid_i;
            a_last_o  <= a_last_i;
            a_data_o  <= a_data_i;
            a_kidx_o  <= a_kidx_i;
            b_valid_o <= b_valid_i;
            b_last_o  <= b_last_i;
            b_data_o  <= b_data_i;
            b_kidx_o  <= b_kidx_i;

            // optional product register stage
            if (MUL_PIPE == 1) begin
                prod_vld_q  <= fire_c;
                prod_last_q <= fire_c & a_last_i & b_last_i;
                if (fire_c) prod_q <= prod_c;
            end

            // accumulate: only on a genuine valid/valid token pair
            if (mac_c) begin
                acc_q <= acc_q + mac_prod_ext;
                if (mac_last_c) done_q <= 1'b1;
            end
        end
    end

    assign acc_o    = acc_q;
    assign done_o   = done_q;
    assign fire_o   = en & fire_c;
    assign commit_o = en & mac_c;

    // ------------------------------------------------------ alignment checker
    //  (1) both tokens valid but carrying different reduction indices k
    //  (2) both tokens valid but disagreeing on the `last` tag
    //  (3) PE is inside the active MxN region yet only one token is valid
    //      (token missing / skew wrong).  Not applied outside the active
    //      region, where one-sided valid tokens are legitimate (padding).
    logic err_kidx_c, err_last_c, err_miss_c, err_c;
    assign err_kidx_c = a_valid_i & b_valid_i & (a_kidx_i != b_kidx_i);
    assign err_last_c = a_valid_i & b_valid_i & (a_last_i != b_last_i);
    assign err_miss_c = chk_en & (a_valid_i != b_valid_i);
    assign err_c      = (CHECK_ALIGN != 0) & (err_kidx_c | err_last_c | err_miss_c);
    assign err_o = en & err_c;

endmodule
