// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_agu
// 2-D strided word-address generator for one side (source or destination) of
// a transfer.  Rows r = 0 .. ROWS-1 start at byte  s_r = base + r*stride  and
// cover ROW_LEN bytes.  For each row it emits the aligned words
//     floor(s_r / WB) .. floor((s_r + ROW_LEN - 1) / WB)
// with the byte lanes [lo, hi] of each word that belong to the row:
//     lo = (first word) ? s_r mod WB : 0
//     hi = (last word)  ? (s_r + ROW_LEN - 1) mod WB : WB-1
// so no word without a byte of the row is ever emitted, every row boundary,
// byte tail and misalignment is handled by the lane range, and rows are fully
// independent (no assumption that the matrix is packed).  Row starts advance
// by adding the stride (no multiplier); the validated footprint guarantees the
// 32-bit sums never wrap for the rows that are actually visited.
// One word per `adv` (the consumer's grant).  `valid` falls when every word of
// every row has been emitted.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tdma_agu #(
  parameter int  WB  = 4,                         // bytes per bus word (power of two >= 2)
  localparam int LWB = $clog2(WB)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            start,             // load a new transfer (only while idle)
  input  wire logic [31:0]     base,
  input  wire logic [31:0]     stride,
  input  wire logic [15:0]     len,               // >= 1
  input  wire logic [15:0]     rows,              // >= 1
  input  wire logic            adv,               // current word taken
  output logic                 valid,             // a word is pending
  output logic [31:0]          addr,              // word-aligned byte address
  output logic [LWB-1:0]       lo,
  output logic [LWB-1:0]       hi,
  output logic [LWB:0]         n,                 // hi - lo + 1
  output logic                 row_last_word,     // this word ends its row
  output logic                 last               // this word is the last of the transfer
);
  logic        act;
  logic [31:0] s;            // byte address of the current row
  logic [31:0] str;
  logic [15:0] ln, nrows, r;
  logic [16:0] j;            // word index inside the row
  logic [16:0] span;         // (s mod WB) + len - 1
  logic [16:0] nw_m1;        // words in the row - 1

  assign span   = 17'(s[LWB-1:0]) + 17'(ln) - 17'd1;
  assign nw_m1  = span >> LWB;
  assign lo     = (j == 17'd0)  ? s[LWB-1:0]    : '0;
  assign hi     = (j == nw_m1)  ? span[LWB-1:0] : LWB'(WB - 1);
  assign n      = (LWB+1)'(hi) - (LWB+1)'(lo) + (LWB+1)'(1);
  assign addr   = {s[31:LWB] + (32-LWB)'(j), {LWB{1'b0}}};
  assign valid  = act;
  assign row_last_word = (j == nw_m1);
  assign last   = row_last_word && (r == nrows - 16'd1);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      act <= 1'b0; s <= '0; str <= '0; ln <= '0; nrows <= '0; r <= '0; j <= '0;
    end else if (start) begin
      act <= 1'b1; s <= base; str <= stride; ln <= len; nrows <= rows; r <= '0; j <= '0;
    end else if (act && adv) begin
      if (row_last_word) begin
        j <= '0;
        if (r == nrows - 16'd1) act <= 1'b0;
        else begin
          r <= r + 16'd1;
          s <= s + str;
        end
      end else begin
        j <= j + 17'd1;
      end
    end
  end
endmodule

`default_nettype wire
