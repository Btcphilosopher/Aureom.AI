// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_queue
// Descriptor queue of one channel: a FIFO whose entries are all visible, so
// the dependency checker of the OTHER channel can scan every pending
// descriptor (age and external footprint).  Push/pop are issued under the
// caller's credit (never full / never empty, asserted).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tdma_queue #(
  parameter int  W     = 64,
  parameter int  DEPTH = 4,                       // power of two >= 2
  localparam int AW    = $clog2(DEPTH)
) (
  input  wire logic               clk,
  input  wire logic               rst_n,
  input  wire logic               push,
  input  wire logic [W-1:0]       wdata,
  input  wire logic               pop,
  output logic      [W-1:0]       head,
  output logic      [AW:0]        count,
  output logic      [DEPTH*W-1:0] ent,            // entry i = slot i (not age order)
  output logic      [DEPTH-1:0]   ent_valid
);
  if (DEPTH < 2 || (1 << AW) != DEPTH) begin : g_err_depth
    `SRAM_CFG_FATAL("tdma_queue: DEPTH must be a power of two >= 2")
  end

  logic [W-1:0] mem [DEPTH];
  logic [AW:0]  wp, rp;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0;
    end else begin
      if (push) wp <= wp + 1'b1;
      if (pop)  rp <= rp + 1'b1;
    end
  end
  always_ff @(posedge clk) if (push) mem[wp[AW-1:0]] <= wdata;

  assign head  = mem[rp[AW-1:0]];
  assign count = wp - rp;

  always_comb begin
    for (int i = 0; i < DEPTH; i++) begin
      ent[i*W +: W] = mem[i];
      ent_valid[i]  = (AW'(AW'(i) - rp[AW-1:0]) < count[AW-1:0]) || (count == (AW+1)'(DEPTH));
    end
  end

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (push && !pop && count == (AW+1)'(DEPTH)) $error("tdma_queue: push while full");
    if (pop && count == '0) $error("tdma_queue: pop while empty");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
