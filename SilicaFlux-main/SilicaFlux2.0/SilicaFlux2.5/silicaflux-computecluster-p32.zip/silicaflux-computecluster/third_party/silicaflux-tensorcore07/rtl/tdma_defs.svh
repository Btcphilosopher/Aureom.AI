// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_defs.svh
// Public contract of the tensor DMA adapter: the 2-D transfer descriptor, the
// descriptor kinds and flags, completion codes, buffer-state names and the
// performance-counter indices.  A `define header (not a package) for the same
// reason as tob_defs.svh / hpc_spm_defs.svh: Yosys 0.33 cannot resolve package
// references in module parameter lists.  Values are ABI: never renumber, only
// append.  The Python mirror is model/tdma_desc.py (checked by scripts/check_abi.py).
// =============================================================================
`ifndef TDMA_DEFS_SVH
`define TDMA_DEFS_SVH

`include "sram_defs.svh"   // SRAM_CFG_FATAL: elaboration errors portable to Verilator / Icarus / Yosys

// ----------------------------------------------------------------------------
// 2-D TRANSFER DESCRIPTOR (192 bits = six little-endian 32-bit words)
//
//   word | bits      | field       | meaning
//   -----+-----------+-------------+---------------------------------------------
//    0   | [31:0]    | SRC         | source byte address (row 0, byte 0)
//    1   | [63:32]   | DST         | destination byte address (row 0, byte 0)
//    2   | [95:64]   | SRC_STRIDE  | bytes from the start of a source row to the next
//    3   | [127:96]  | DST_STRIDE  | bytes from the start of a destination row to the next
//    4   | [143:128] | ROW_LEN     | bytes per row (transfer length of one row), 1..65535
//        | [159:144] | ROWS        | number of rows, 1..65535 (ROWS = 1: plain 1-D copy)
//    5   | [167:160] | ID          | transaction identifier, echoed in the completion
//        | [169:168] | KIND        | LOAD_A / LOAD_B / STORE (3 reserved)
//        | [175:170] | FLAGS       | bit 0 SEAL, bit 1 FENCE, bits 2..5 reserved (0)
//        | [183:176] | RSVD        | must be 0
//        | [191:184] | VERSION     | must be TDMA_VERSION
//
// Address spaces (byte addresses everywhere, no alignment requirement):
//   LOAD_A : SRC = external (SFB2) address, DST = byte offset inside the A region
//            of the operand-buffer set currently being filled (TC03 fill_set)
//   LOAD_B : SRC = external address,        DST = offset inside the B region of that set
//   STORE  : SRC = byte offset inside the output-buffer set currently being drained,
//            DST = external address
// The adapter adds the base of the set that the buffer coordinator owns, so the
// host never needs to know which physical set (ping or pong) is in use.
// Bytes moved = ROW_LEN * ROWS.  Row r covers [SRC + r*SRC_STRIDE, + ROW_LEN) and
// [DST + r*DST_STRIDE, + ROW_LEN).  SRC_STRIDE may be anything (0 = broadcast a
// row, < ROW_LEN = overlapping reads); destination rows must not overlap.
// ----------------------------------------------------------------------------
`define TDMA_DESC_W        192
`define TDMA_D_SRC         31:0
`define TDMA_D_DST         63:32
`define TDMA_D_SSTRIDE     95:64
`define TDMA_D_DSTRIDE     127:96
`define TDMA_D_ROWLEN      143:128
`define TDMA_D_ROWS        159:144
`define TDMA_D_ID          167:160
`define TDMA_D_KIND        169:168
`define TDMA_D_FLAGS       175:170
`define TDMA_D_RSVD        183:176
`define TDMA_D_VER         191:184
`define TDMA_VERSION       8'h07

// descriptor kinds
`define TDMA_K_LOAD_A      2'd0   // external memory -> TC03 A region
`define TDMA_K_LOAD_B      2'd1   // external memory -> TC03 B region
`define TDMA_K_STORE       2'd2   // tensor output buffer -> external memory
`define TDMA_K_RSVD        2'd3   // rejected (RSVD)

// flags
`define TDMA_F_SEAL        0      // LOAD: set becomes READY (fill_end) after this descriptor;
                                  // STORE: output set is released (FREE) after this descriptor
`define TDMA_F_FENCE       1      // start only after every older descriptor has completed
`define TDMA_F_RSVD_MASK   6'b111100

// ----------------------------------------------------------------------------
// completion codes (4 bits).  Codes 1..6: rejected before any side effect
// (no bus request, no buffer write, no ownership change).  7..11: the transfer
// started and stopped at the first failing transaction; the completion reports
// the failing address and the contiguous prefix of destination bytes whose
// writes were acknowledged without error.  Ownership never changes on an error.
// ----------------------------------------------------------------------------
`define TDMA_C_OK          4'd0
`define TDMA_C_RSVD        4'd1   // bad VERSION, KIND 3, reserved flag or RSVD bits set
`define TDMA_C_ZERO        4'd2   // ROW_LEN == 0 or ROWS == 0
`define TDMA_C_DST_ROWS    4'd3   // ROWS > 1 and DST_STRIDE < ROW_LEN (destination rows overlap)
`define TDMA_C_EXT_OVF     4'd4   // last external byte >= 2^32 (range would wrap)
`define TDMA_C_EXT_RANGE   4'd5   // external range outside [MEM_LO, MEM_HI)
`define TDMA_C_LOC_RANGE   4'd6   // local range does not fit in one set (A / B / output)
`define TDMA_C_RD_BUS      4'd7   // LOAD: SFB2 read answered with rsp_error
`define TDMA_C_WR_BUS      4'd8   // STORE: SFB2 write answered with rsp_error
`define TDMA_C_LOC_RD      4'd9   // STORE: output-buffer read refused (OWNER/RANGE/ALIGN/PARITY)
`define TDMA_C_LOC_WR      4'd10  // LOAD: TC03 fill write refused (OWNER/RANGE/ALIGN)
`define TDMA_C_PROTO       4'd11  // local response with a wrong tag / direction (misrouted, duplicated)

// ----------------------------------------------------------------------------
// buffer states, 2 bits per set.  Identical encoding to TC03 (tob_defs.svh):
// FREE = EMPTY, FILLING = FILL, READY = READY, IN_USE = COMPUTE.
//   operand set : FILLING = owned by the DMA,     IN_USE = owned by compute
//   output set  : FILLING = owned by compute,     IN_USE = owned by the DMA
// ----------------------------------------------------------------------------
`define TDMA_BS_FREE       2'd0
`define TDMA_BS_FILLING    2'd1
`define TDMA_BS_READY      2'd2
`define TDMA_BS_IN_USE     2'd3

// ----------------------------------------------------------------------------
// performance counters (tdma_perf, saturating, CNT_W bits each)
// ----------------------------------------------------------------------------
`define TDMA_PC_ACTIVE      0   // cycles with at least one descriptor in a channel
`define TDMA_PC_RD_BYTES    1   // descriptor bytes read (returned without error)
`define TDMA_PC_WR_BYTES    2   // descriptor bytes written and acknowledged without error
`define TDMA_PC_RD_REQ      3   // read transactions accepted (SFB2 + output buffer)
`define TDMA_PC_WR_REQ      4   // write transactions accepted (SFB2 + TC03 fill)
`define TDMA_PC_STALL       5   // cycles with a request presented and not accepted (any port)
`define TDMA_PC_SFB_STALL   6   //   ... on the SFB2 port
`define TDMA_PC_LOC_STALL   7   //   ... on a local buffer port
`define TDMA_PC_OUT_SUM     8   // sum over cycles of outstanding transactions (average = /ACTIVE)
`define TDMA_PC_OUT_MAX     9   // maximum outstanding transactions observed
`define TDMA_PC_BUF_WAIT   10   // cycles a channel waited for buffer ownership
`define TDMA_PC_DEP_WAIT   11   // cycles a ready head waited for a memory dependency / fence
`define TDMA_PC_XFER_ERR   12   // descriptors completed with an error code
`define TDMA_PC_DESC_OK    13   // descriptors completed OK
`define TDMA_PC_OVERLAP    14   // cycles with a TC03 fill write while an operand set is IN_USE
`define TDMA_PC_CPL_STALL  15   // cycles a completion record waited for cpl_ready
`define TDMA_PC_LD_BUSY    16   // cycles the load channel was busy (OPEN..CPL)
`define TDMA_PC_ST_BUSY    17   // cycles the store channel was busy
`define TDMA_NUM_PC        18

// channel FSM (status output)
`define TDMA_CH_IDLE       3'd0
`define TDMA_CH_OPEN       3'd1   // acquiring buffer ownership
`define TDMA_CH_RUN        3'd2   // moving data
`define TDMA_CH_SEAL       3'd3   // ownership hand-over after a successful SEAL descriptor
`define TDMA_CH_CPL        3'd4   // pushing the completion record

`endif
