// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_perf
// Saturating counter bank.  Counter i adds inc[i] (IW bits) every cycle, or,
// when MAX_MASK[i] = 1, keeps the maximum value of inc[i] seen (high-water
// mark).  Counters saturate at all-ones and never wrap.  perf_clear zeroes all.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tdma_perf #(
  parameter int              N        = 18,
  parameter int              IW       = 8,
  parameter int              CNT_W    = 32,
  parameter logic [N-1:0]    MAX_MASK = {N{1'b0}}
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  input  wire logic [N*IW-1:0]   inc,
  output logic      [N*CNT_W-1:0] cnt
);
  for (genvar i = 0; i < N; i++) begin : g_c
    logic [CNT_W-1:0] q;
    logic [CNT_W:0]   sum;
    logic [IW-1:0]    d;
    assign d   = inc[i*IW +: IW];
    assign sum = (CNT_W+1)'(q) + (CNT_W+1)'(d);
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)           q <= '0;
      else if (clear)       q <= '0;
      else if (MAX_MASK[i]) begin
        if (CNT_W'(d) > q)  q <= CNT_W'(d);
      end
      else if (sum[CNT_W])  q <= {CNT_W{1'b1}};
      else                  q <= sum[CNT_W-1:0];
    end
    assign cnt[i*CNT_W +: CNT_W] = q;
  end
endmodule

`default_nettype wire
