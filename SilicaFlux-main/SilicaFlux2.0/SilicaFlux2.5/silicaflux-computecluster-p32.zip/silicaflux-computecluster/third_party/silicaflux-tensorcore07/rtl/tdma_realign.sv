// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_realign
// Byte realigner between the read side and the write side of a channel: a
// circular byte FIFO of CAP bytes with a multi-byte push and a multi-byte pop.
//
//   push : one source word; its row bytes are lanes [lo, lo+n) -> compacted
//          (shifted down by lo) and appended in order
//   pop  : the oldest k bytes, placed at destination lanes [lo, lo+k) of the
//          output word (other lanes 0); used for one destination word
//
// The transfer is a stream of rows, each ROW_LEN bytes; the source AGU emits
// exactly the row bytes in order and the destination AGU consumes exactly the
// row bytes in order, so source and destination may have ANY byte alignment and
// stride with no read-modify-write and no assumption about packing.
// Flow control is the caller's: the read side reserves n bytes before issuing
// a read (count + reserved + n <= CAP), the write side pops only when
// count >= k.  Overflow / underflow are therefore impossible (asserted).
// Storage is not reset (datapath); pointers and count are.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tdma_realign #(
  parameter int  WB  = 4,                 // bytes per word (power of two >= 2)
  parameter int  CAP = 16,                // bytes (power of two >= 2*WB)
  localparam int LWB = $clog2(WB),
  localparam int CW  = $clog2(CAP)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             clr,
  input  wire logic             push,
  input  wire logic [8*WB-1:0]  push_data,
  input  wire logic [LWB-1:0]   push_lo,
  input  wire logic [LWB:0]     push_n,
  input  wire logic             pop,
  input  wire logic [LWB-1:0]   pop_lo,
  input  wire logic [LWB:0]     pop_k,
  output logic      [8*WB-1:0]  pop_data,
  output logic      [CW:0]      count
);
  if (WB < 2 || (1 << LWB) != WB) begin : g_err_wb
    `SRAM_CFG_FATAL("tdma_realign: WB must be a power of two >= 2")
  end
  if ((1 << CW) != CAP || CAP < 2 * WB) begin : g_err_cap
    `SRAM_CFG_FATAL("tdma_realign: CAP must be a power of two >= 2*WB")
  end

  logic [7:0]    mem [CAP];
  logic [CW-1:0] wp, rp;
  logic [CW:0]   cnt;
  logic [8*WB-1:0] comp;
  logic [7:0]    head [WB];

  assign comp = push_data >> {push_lo, 3'b000};

  always_comb begin
    for (int i = 0; i < WB; i++) head[i] = mem[rp + CW'(i)];
    pop_data = '0;
    for (int l = 0; l < WB; l++) begin
      if ((LWB+1)'(l) >= (LWB+1)'(pop_lo) && (LWB+1)'(l) < (LWB+1)'(pop_lo) + pop_k)
        pop_data[8*l +: 8] = head[LWB'(l) - pop_lo];
    end
  end

  always_ff @(posedge clk) begin
    if (push && !clr) begin
      for (int i = 0; i < WB; i++)
        if ((LWB+1)'(i) < push_n) mem[wp + CW'(i)] <= comp[8*i +: 8];
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp <= '0; rp <= '0; cnt <= '0;
    end else if (clr) begin
      wp <= '0; rp <= '0; cnt <= '0;
    end else begin
      if (push) wp <= wp + CW'(push_n);
      if (pop)  rp <= rp + CW'(pop_k);
      cnt <= cnt + (push ? (CW+1)'(push_n) : '0) - (pop ? (CW+1)'(pop_k) : '0);
    end
  end
  assign count = cnt;

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n && !clr) begin
    if (pop && (CW+1)'(pop_k) > cnt) $error("tdma_realign: pop of %0d bytes with %0d stored", pop_k, cnt);
    if (push && (cnt + (CW+1)'(push_n) - (pop ? (CW+1)'(pop_k) : '0)) > (CW+1)'(CAP))
      $error("tdma_realign: overflow");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
