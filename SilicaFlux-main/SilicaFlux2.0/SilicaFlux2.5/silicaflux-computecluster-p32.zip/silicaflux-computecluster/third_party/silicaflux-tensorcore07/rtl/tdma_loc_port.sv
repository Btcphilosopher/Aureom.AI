// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_loc_port
// Requester for one local buffer port speaking the Module 04 port protocol
// (hpc_scratchpad requester port; TENSORCORE 03 tob_dma_port is identical):
//   request : req_valid/req_ready, req_we, req_addr (bytes), req_wdata, req_wstrb, req_tag
//   response: rsp_valid/rsp_ready, rsp_rdata, rsp_err, rsp_err_code[2:0], rsp_we, rsp_tag
// Used twice by the adapter: load channel -> TC03 fill port (writes only) and
// output buffer DMA port -> store channel (reads only).
//
//   * H2: the request is held in a register (req_valid is a flop) and never
//     withdrawn; it does not depend on req_ready.
//   * every accepted request is recorded {tag, we, addr}; the tag is a
//     sequence number, so a response whose tag or direction does not match the
//     oldest outstanding request (misrouted, duplicated, re-ordered) is turned
//     into an error (detail bit 3 = PROTO) and its data is never used.
//   * rsp_ready = 1: the channel holds a credit for every response.
//   * at most MAX_OUT requests granted and not answered.
// Response detail = {proto, rsp_err_code}.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tdma_loc_port #(
  parameter int  WB      = 4,
  parameter int  MAX_OUT = 4,                          // power of two, 1..16
  parameter int  TAG_W   = 8,                          // 2^TAG_W > MAX_OUT
  localparam int DW      = 8 * WB,
  localparam int OD      = (MAX_OUT < 2) ? 2 : MAX_OUT,
  localparam int OW      = $clog2(OD)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- channel side
  input  wire logic             u_valid,
  input  wire logic             u_we,
  input  wire logic [31:0]      u_addr,
  input  wire logic [DW-1:0]    u_data,
  input  wire logic [WB-1:0]    u_strb,
  output logic                  u_gnt,
  output logic                  u_rsp_valid,
  output logic [DW-1:0]         u_rsp_data,
  output logic                  u_rsp_err,
  output logic [3:0]            u_rsp_detail,
  output logic [31:0]           u_rsp_addr,
  // ---------------------------------------------------------- Module 04 requester port
  output logic                  req_valid,
  input  wire logic             req_ready,
  output logic                  req_we,
  output logic [31:0]           req_addr,
  output logic [DW-1:0]         req_wdata,
  output logic [WB-1:0]         req_wstrb,
  output logic [TAG_W-1:0]      req_tag,
  input  wire logic             rsp_valid,
  output logic                  rsp_ready,
  input  wire logic [DW-1:0]    rsp_rdata,
  input  wire logic             rsp_err,
  input  wire logic [2:0]       rsp_err_code,
  input  wire logic             rsp_we,
  input  wire logic [TAG_W-1:0] rsp_tag,
  // ---------------------------------------------------------- status / events
  output logic [OW:0]           outstanding,
  output logic                  idle,
  output logic                  ev_stall,
  output logic                  ev_acc,
  output logic                  ev_unsolicited
);
  if (MAX_OUT < 1 || MAX_OUT > 16 || (MAX_OUT & (MAX_OUT - 1)) != 0) begin : g_err_max_out
    `SRAM_CFG_FATAL("tdma_loc_port: MAX_OUT must be 1, 2, 4, 8 or 16")
  end
  if ((1 << TAG_W) <= 2 * OD) begin : g_err_tag
    `SRAM_CFG_FATAL("tdma_loc_port: TAG_W too small for MAX_OUT")
  end

  logic             rq_v, rq_we;
  logic [31:0]      rq_addr;
  logic [DW-1:0]    rq_data;
  logic [WB-1:0]    rq_strb;
  logic [TAG_W-1:0] seq;
  logic [OW:0]      cnt, of_cnt;
  logic             acc, can_load, rsp_go;

  assign acc      = rq_v && req_ready;
  assign can_load = !rq_v || acc;
  assign u_gnt    = can_load && u_valid && (cnt < (OW+1)'(MAX_OUT));

  assign req_valid = rq_v;
  assign req_we    = rq_we;
  assign req_addr  = rq_addr;
  assign req_wdata = rq_we ? rq_data : '0;
  assign req_wstrb = rq_we ? rq_strb : '0;
  assign req_tag   = seq;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rq_v <= 1'b0; rq_we <= 1'b0; rq_addr <= '0; rq_data <= '0; rq_strb <= '0; seq <= '0;
    end else begin
      if (acc) seq <= seq + TAG_W'(1);
      if (u_gnt) begin
        rq_v <= 1'b1; rq_we <= u_we; rq_addr <= u_addr; rq_data <= u_data; rq_strb <= u_strb;
      end else if (acc) begin
        rq_v <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------- outstanding FIFO {tag, we, addr}
  localparam int RW_ = TAG_W + 1 + 32;
  logic [RW_-1:0]   of_head;
  logic [TAG_W-1:0] h_tag;
  logic             h_we, mism;
  logic [31:0]      h_addr;

  assign rsp_ready = 1'b1;
  assign rsp_go    = rsp_valid && (of_cnt != '0);

  dma_fifo #(.WIDTH(RW_), .DEPTH(OD)) u_of (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(acc), .wdata({seq, rq_we, rq_addr}),
    .pop(rsp_go), .rdata(of_head), .count(of_cnt));
  assign {h_tag, h_we, h_addr} = of_head;

  assign mism         = (rsp_tag != h_tag) || (rsp_we != h_we);
  assign u_rsp_valid  = rsp_go;
  assign u_rsp_err    = rsp_err || mism;
  assign u_rsp_detail = {mism, rsp_err_code};
  assign u_rsp_data   = (rsp_err || mism) ? '0 : rsp_rdata;
  assign u_rsp_addr   = h_addr;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cnt <= '0;
    else        cnt <= cnt + (OW+1)'(u_gnt) - (OW+1)'(rsp_go);
  end

  assign outstanding    = cnt;
  assign idle           = (cnt == '0);
  assign ev_stall       = rq_v && !req_ready;
  assign ev_acc         = acc;
  assign ev_unsolicited = rsp_valid && (of_cnt == '0);

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (cnt > (OW+1)'(MAX_OUT)) $error("tdma_loc_port: %0d transactions in flight, limit %0d", cnt, MAX_OUT);
    if (ev_unsolicited) $error("tdma_loc_port: unsolicited local response");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
