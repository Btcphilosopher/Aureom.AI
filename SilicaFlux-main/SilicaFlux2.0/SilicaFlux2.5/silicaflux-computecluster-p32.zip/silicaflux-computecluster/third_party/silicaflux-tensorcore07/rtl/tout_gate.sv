// =============================================================================
// SilicaFlux TENSORCORE 07 :: tout_gate
// Ownership gate in front of one hpc_scratchpad requester port (Module 04
// protocol on both sides).  It enforces in HARDWARE who may touch an output
// set, exactly as TC03 tob_dma_port does for operand sets:
//   MODE 0 (producer / compute writer port): writes only, to a set in FILLING
//   MODE 1 (DMA read port)                 : reads only, from a set in IN_USE
// A request that breaks the rule is accepted and answered with an error, with
// NO side effect (it never reaches the scratchpad).  Codes (Module 04 / TC03
// numbering): RANGE 1 (outside the buffer), UNSUP 7 (wrong direction),
// OWNER 6 (set not in the required state).
// Ordering: a pending FIFO records, for every accepted request, whether it was
// forwarded or refused; responses are delivered strictly in acceptance order
// (a refused entry waits behind older forwarded ones; the scratchpad holds a
// younger response, H4/H6).  Requires hpc_scratchpad QUEUE_DEPTH = 0, so the
// ownership check and the bank access happen at the same edge.
// `idle` = nothing pending (used by tob_dbuf_ctrl before a hand-over).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tout_gate #(
  parameter int  WB        = 4,
  parameter int  TAG_W     = 8,
  parameter int  O_SETS    = 2,
  parameter int  SET_BYTES = 256,
  parameter int  MODE      = 0,            // 0: producer writes, 1: DMA reads
  parameter int  PD        = 8,            // pending entries (power of two >= 2)
  localparam int DW        = 8 * WB,
  localparam int PW        = $clog2(PD),
  localparam int SBW       = $clog2(SET_BYTES),
  localparam int OSW       = (O_SETS > 1) ? $clog2(O_SETS) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic [O_SETS*2-1:0]   set_state,
  // ---------------------------------------------------------- requester side
  input  wire logic                  u_req_valid,
  output logic                       u_req_ready,
  input  wire logic                  u_req_we,
  input  wire logic [31:0]           u_req_addr,
  input  wire logic [DW-1:0]         u_req_wdata,
  input  wire logic [WB-1:0]         u_req_wstrb,
  input  wire logic [TAG_W-1:0]      u_req_tag,
  output logic                       u_rsp_valid,
  input  wire logic                  u_rsp_ready,
  output logic      [DW-1:0]         u_rsp_rdata,
  output logic                       u_rsp_err,
  output logic      [2:0]            u_rsp_err_code,
  output logic                       u_rsp_we,
  output logic      [TAG_W-1:0]      u_rsp_tag,
  // ---------------------------------------------------------- scratchpad side
  output logic                       s_req_valid,
  input  wire logic                  s_req_ready,
  output logic                       s_req_we,
  output logic      [31:0]           s_req_addr,
  output logic      [DW-1:0]         s_req_wdata,
  output logic      [WB-1:0]         s_req_wstrb,
  output logic      [TAG_W-1:0]      s_req_tag,
  input  wire logic                  s_rsp_valid,
  output logic                       s_rsp_ready,
  input  wire logic [DW-1:0]         s_rsp_rdata,
  input  wire logic                  s_rsp_err,
  input  wire logic [2:0]            s_rsp_err_code,
  input  wire logic                  s_rsp_we,
  input  wire logic [TAG_W-1:0]      s_rsp_tag,
  // ---------------------------------------------------------- status
  output logic                       idle,
  output logic                       ev_refused
);
  if (PD < 2 || (1 << PW) != PD) begin : g_err_pd
    `SRAM_CFG_FATAL("tout_gate: PD must be a power of two >= 2")
  end
  if ((1 << SBW) != SET_BYTES) begin : g_err_sb
    `SRAM_CFG_FATAL("tout_gate: SET_BYTES must be a power of two")
  end

  localparam logic [32:0] CAP  = 33'(O_SETS) * 33'(SET_BYTES);
  localparam logic [1:0]  NEED = (MODE == 0) ? `TDMA_BS_FILLING : `TDMA_BS_IN_USE;

  logic [2:0]  code;
  logic        refuse, space, acc;
  logic [1:0]  st_x;
  logic [OSW-1:0] sidx;

  assign sidx = (O_SETS > 1) ? OSW'(u_req_addr >> SBW) : '0;   // out of range: RANGE wins anyway
  assign st_x = set_state[sidx*2 +: 2];

  always_comb begin
    if (33'(u_req_addr) >= CAP)                code = 3'd1;   // RANGE
    else if (u_req_we != (MODE == 0))          code = 3'd7;   // UNSUP: wrong direction
    else if (st_x != NEED)                     code = 3'd6;   // OWNER
    else                                       code = 3'd0;
  end
  assign refuse = (code != 3'd0);

  // ---------------------------------------------------------- pending FIFO {refused, code, we, tag}
  localparam int PEW = 1 + 3 + 1 + TAG_W;
  logic [PEW-1:0] p_head;
  logic [PW:0]    p_cnt;
  logic           p_ref, p_we, pop;
  logic [2:0]     p_code;
  logic [TAG_W-1:0] p_tag;

  assign space       = (p_cnt < (PW+1)'(PD));
  assign s_req_valid = u_req_valid && space && !refuse;
  assign u_req_ready = space && (refuse || s_req_ready);
  assign acc         = u_req_valid && u_req_ready;
  assign s_req_we    = u_req_we;
  assign s_req_addr  = u_req_addr;
  assign s_req_wdata = u_req_wdata;
  assign s_req_wstrb = u_req_wstrb;
  assign s_req_tag   = u_req_tag;

  dma_fifo #(.WIDTH(PEW), .DEPTH(PD)) u_pend (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(acc), .wdata({refuse, code, u_req_we, u_req_tag}),
    .pop(pop), .rdata(p_head), .count(p_cnt));
  assign {p_ref, p_code, p_we, p_tag} = p_head;

  always_comb begin
    if (p_cnt == '0) begin
      u_rsp_valid = 1'b0; u_rsp_rdata = '0; u_rsp_err = 1'b0; u_rsp_err_code = 3'd0; u_rsp_we = 1'b0; u_rsp_tag = '0;
      s_rsp_ready = 1'b0;
    end else if (p_ref) begin
      u_rsp_valid = 1'b1; u_rsp_rdata = '0; u_rsp_err = 1'b1; u_rsp_err_code = p_code; u_rsp_we = p_we; u_rsp_tag = p_tag;
      s_rsp_ready = 1'b0;
    end else begin
      u_rsp_valid = s_rsp_valid; u_rsp_rdata = s_rsp_rdata; u_rsp_err = s_rsp_err; u_rsp_err_code = s_rsp_err_code;
      u_rsp_we = s_rsp_we; u_rsp_tag = s_rsp_tag;
      s_rsp_ready = u_rsp_ready;
    end
  end
  assign pop        = u_rsp_valid && u_rsp_ready;
  assign idle       = (p_cnt == '0);
  assign ev_refused = acc && refuse;

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (s_rsp_valid && p_cnt == '0)
      $error("tout_gate: scratchpad response with no request pending");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
