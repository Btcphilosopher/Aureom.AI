// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_buf_coord
// Buffer coordination between the DMA channels and the two double-buffered
// stores.  The ownership state machines themselves are the existing,
// unmodified tob_dbuf_ctrl (TENSORCORE 03): one inside TC03 for the operand
// sets, one inside tensor_output_buffer for the output sets.  They are the
// single source of truth; this block only decides WHEN the DMA side issues its
// two commands, and it never keeps a copy of a set pointer.
//
//                 operand set (TC03)                       output set (tensor_output_buffer)
//  FREE     ─fill_begin(DMA)─► FILLING ─fill_end(DMA)─►     FREE    ─(compute writer)─► FILLING
//  READY    ─cmp_begin(compute)─► IN_USE ─cmp_end(compute)─► READY  ─rd_begin(DMA)─► IN_USE ─rd_end(DMA)─► FREE
//
// Load channel (LOAD_A / LOAD_B):
//   acquire : the fill set is FILLING  -> go (continuation, e.g. B after A)
//             the fill set is FREE     -> fill_begin, if the policy allows
//             READY / IN_USE           -> wait (a buffer is never overwritten
//                                         before compute released it)
//   policy  : PREFETCH  fill_begin as soon as the next set is FREE, i.e. while
//                       compute still owns the other set (next-tile prefetch)
//             SEQUENTIAL fill_begin only when NO operand set is READY or IN_USE
//                       (compute idle: load, compute, load, ... never overlap)
//   seal    : fill_end after every write of the SEAL descriptor is acknowledged
//             -> READY: compute can start only on completely written data.
// Store channel (STORE):
//   acquire : the drain set is IN_USE -> go (continuation); READY -> rd_begin;
//             FREE / FILLING -> wait (compute has not finished the tile)
//   seal    : rd_end after every write to external memory is acknowledged.
// TC03 / tob_dbuf_ctrl readies are combinational functions of the set state,
// so a command is presented only when it is accepted in the same cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tdma_buf_coord #(
  parameter int  NUM_SETS = 2,
  parameter int  O_SETS   = 2,
  localparam int SW       = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int OSW      = (O_SETS > 1) ? $clog2(O_SETS) : 1
) (
  input  wire logic                   prefetch,
  // ---------------------------------------------------------- operand sets (TC03)
  input  wire logic [NUM_SETS*2-1:0]  op_state,
  input  wire logic [SW-1:0]          op_fill_set,
  output logic                        fill_begin_valid,
  input  wire logic                   fill_begin_ready,
  output logic                        fill_end_valid,
  input  wire logic                   fill_end_ready,
  // ---------------------------------------------------------- output sets
  input  wire logic [O_SETS*2-1:0]    ob_state,
  input  wire logic [OSW-1:0]         ob_rd_set,
  output logic                        rd_begin_valid,
  input  wire logic                   rd_begin_ready,
  output logic                        rd_end_valid,
  input  wire logic                   rd_end_ready,
  // ---------------------------------------------------------- load channel
  input  wire logic                   ld_acq,
  output logic                        ld_acq_ok,
  input  wire logic                   ld_seal,
  output logic                        ld_seal_ok,
  // ---------------------------------------------------------- store channel
  input  wire logic                   st_acq,
  output logic                        st_acq_ok,
  input  wire logic                   st_seal,
  output logic                        st_seal_ok,
  // ---------------------------------------------------------- status
  output logic                        op_compute_owns,   // an operand set is READY or IN_USE
  output logic                        op_in_use,         // an operand set is IN_USE (compute reading)
  output logic                        ld_wait,
  output logic                        st_wait
);
  logic [1:0] fst, ost;
  logic       policy_ok;

  assign fst = op_state[op_fill_set*2 +: 2];
  assign ost = ob_state[ob_rd_set*2 +: 2];

  always_comb begin
    op_compute_owns = 1'b0;
    op_in_use       = 1'b0;
    for (int s = 0; s < NUM_SETS; s++) begin
      if (op_state[s*2 +: 2] == `TDMA_BS_READY || op_state[s*2 +: 2] == `TDMA_BS_IN_USE) op_compute_owns = 1'b1;
      if (op_state[s*2 +: 2] == `TDMA_BS_IN_USE) op_in_use = 1'b1;
    end
  end

  assign policy_ok        = prefetch || !op_compute_owns;
  assign fill_begin_valid = ld_acq && (fst == `TDMA_BS_FREE) && policy_ok;
  assign ld_acq_ok        = ld_acq && (fst == `TDMA_BS_FILLING);
  assign fill_end_valid   = ld_seal;
  assign ld_seal_ok       = fill_end_valid && fill_end_ready;

  assign rd_begin_valid   = st_acq && (ost == `TDMA_BS_READY);
  assign st_acq_ok        = st_acq && (ost == `TDMA_BS_IN_USE);
  assign rd_end_valid     = st_seal;
  assign st_seal_ok       = rd_end_valid && rd_end_ready;

  assign ld_wait = ld_acq && !ld_acq_ok && !(fill_begin_valid && fill_begin_ready);
  assign st_wait = st_acq && !st_acq_ok && !(rd_begin_valid && rd_begin_ready);

endmodule

`default_nettype wire
