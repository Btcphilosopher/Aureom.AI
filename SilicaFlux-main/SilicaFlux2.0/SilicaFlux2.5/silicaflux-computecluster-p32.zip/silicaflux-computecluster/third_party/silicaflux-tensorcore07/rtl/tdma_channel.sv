// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_channel
// Datapath of one transfer channel: 2-D source AGU -> byte realigner -> 2-D
// destination AGU, with credit-based flow control and in-order completion
// tracking.  The channel is port-agnostic: the adapter connects its read side
// and write side to the SFB2 port or to a local buffer port.
//
//   start ──► rAGU ──rd_*──► (port) ──rr_*──► realigner ──► wAGU ──wr_*──► (port) ──wa_*
//
// Credits (so every response is always absorbed, rr/wa have no ready):
//   * a read is issued only if the realigner has room for its bytes:
//       count + reserved + n <= RCAP   (reserved = bytes of reads in flight)
//   * at most MAXR reads and MAXW writes in flight (meta FIFOs, in order)
//   * a write is issued only when the realigner holds all its bytes.
// Completion: `done` pulses when every issued read has been answered and every
// issued write has been ACKNOWLEDGED (the port's write response), and either
// every word has been moved or an error stopped the transfer.  A write
// acknowledgement is, by the port contracts (SFB2 R7, Module 04 WRITE_ACK,
// TC03 tob_dma_port), issued only after the target performed the write, so
// `done` without error means the destination holds all ROW_LEN*ROWS bytes.
// Errors: the first error response stops further issue (reads and writes);
// outstanding transactions drain.  bytes_ok = destination bytes of writes
// acknowledged OK before the first write error = a contiguous prefix of the
// destination stream (writes are acknowledged in issue order).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tdma_channel #(
  parameter int  WB   = 4,
  parameter int  RCAP = 16,                 // realigner bytes, power of two >= 2*WB
  parameter int  MAXR = 4,                  // reads in flight, power of two >= 2
  parameter int  MAXW = 4,                  // writes in flight, power of two >= 2
  localparam int LWB  = $clog2(WB),
  localparam int CW   = $clog2(RCAP),
  localparam int RW   = $clog2(MAXR),
  localparam int WW   = $clog2(MAXW)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- control
  input  wire logic             start,
  input  wire logic [31:0]      src,
  input  wire logic [31:0]      dst,
  input  wire logic [31:0]      src_stride,
  input  wire logic [31:0]      dst_stride,
  input  wire logic [15:0]      row_len,
  input  wire logic [15:0]      rows,
  output logic                  busy,
  output logic                  done,          // pulse
  output logic                  err,           // with done: the transfer failed
  output logic                  err_wr,        // 0: a read failed, 1: a write failed
  output logic [3:0]            err_detail,    // port detail of the first failing response
  output logic [31:0]           err_addr,      // address of the first failing transaction
  output logic [31:0]           bytes_ok,
  // ---------------------------------------------------------- read requests / responses
  output logic                  rd_valid,
  output logic [31:0]           rd_addr,
  output logic [LWB:0]          rd_n,          // row bytes inside the word
  input  wire logic             rd_gnt,
  input  wire logic             rr_valid,
  input  wire logic [8*WB-1:0]  rr_data,
  input  wire logic             rr_err,
  input  wire logic [3:0]       rr_detail,
  input  wire logic [31:0]      rr_addr,
  // ---------------------------------------------------------- write requests / acknowledgements
  output logic                  wr_valid,
  output logic [31:0]           wr_addr,
  output logic [8*WB-1:0]       wr_data,
  output logic [WB-1:0]         wr_strb,
  input  wire logic             wr_gnt,
  input  wire logic             wa_valid,
  input  wire logic             wa_err,
  input  wire logic [3:0]       wa_detail,
  input  wire logic [31:0]      wa_addr,
  // ---------------------------------------------------------- events (one cycle)
  output logic [LWB:0]          ev_rd_bytes,   // bytes returned OK and buffered
  output logic [LWB:0]          ev_wr_bytes    // bytes acknowledged OK
);
  if (RCAP < 2 * WB) begin : g_err_rcap
    `SRAM_CFG_FATAL("tdma_channel: RCAP must be >= 2*WB")
  end
  if (MAXR < 2 || (1 << RW) != MAXR || MAXW < 2 || (1 << WW) != MAXW) begin : g_err_out
    `SRAM_CFG_FATAL("tdma_channel: MAXR and MAXW must be powers of two >= 2")
  end

  logic act, errq, wr_err_seen;

  // ------------------------------------------------------------ source / destination AGUs
  logic          ra_valid, wa_g_valid;
  logic [31:0]   ra_addr, wa_g_addr;
  logic [LWB-1:0] ra_lo, wg_lo, wg_hi;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [LWB-1:0] ra_hi;                  // the read side needs only lo and n
  /* verilator lint_on UNUSEDSIGNAL */
  logic [LWB:0]  ra_n, wg_n;
  /* verilator lint_off UNUSEDSIGNAL */
  logic          ra_rlw, ra_last, wg_rlw, wg_last;
  /* verilator lint_on UNUSEDSIGNAL */
  logic          rd_go, wr_go;

  tdma_agu #(.WB(WB)) u_ragu (
    .clk(clk), .rst_n(rst_n), .start(start), .base(src), .stride(src_stride), .len(row_len), .rows(rows),
    .adv(rd_go), .valid(ra_valid), .addr(ra_addr), .lo(ra_lo), .hi(ra_hi), .n(ra_n),
    .row_last_word(ra_rlw), .last(ra_last));
  tdma_agu #(.WB(WB)) u_wagu (
    .clk(clk), .rst_n(rst_n), .start(start), .base(dst), .stride(dst_stride), .len(row_len), .rows(rows),
    .adv(wr_go), .valid(wa_g_valid), .addr(wa_g_addr), .lo(wg_lo), .hi(wg_hi), .n(wg_n),
    .row_last_word(wg_rlw), .last(wg_last));

  // ------------------------------------------------------------ in-flight bookkeeping (in order)
  logic [RW:0]          rm_cnt;
  logic [LWB+LWB:0]     rm_head;          // {lo, n}
  logic [LWB-1:0]       rh_lo;
  logic [LWB:0]         rh_n;
  logic [WW:0]          wm_cnt;
  logic [LWB:0]         wm_head;          // bytes of the write
  logic                 rr_take, wa_take;

  assign rr_take = rr_valid && (rm_cnt != '0);
  assign wa_take = wa_valid && (wm_cnt != '0);

  dma_fifo #(.WIDTH(2*LWB+1), .DEPTH(MAXR)) u_rmeta (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(rd_go), .wdata({ra_lo, ra_n}),
    .pop(rr_take), .rdata(rm_head), .count(rm_cnt));
  assign {rh_lo, rh_n} = rm_head;

  dma_fifo #(.WIDTH(LWB+1), .DEPTH(MAXW)) u_wmeta (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(wr_go), .wdata(wg_n),
    .pop(wa_take), .rdata(wm_head), .count(wm_cnt));

  // ------------------------------------------------------------ realigner + credits
  logic [CW:0]   ra_count, res;
  logic          rl_push;
  logic [CW+1:0] used_next;

  assign rl_push = rr_take && !rr_err && !errq;

  tdma_realign #(.WB(WB), .CAP(RCAP)) u_rl (
    .clk(clk), .rst_n(rst_n), .clr(start),
    .push(rl_push), .push_data(rr_data), .push_lo(rh_lo), .push_n(rh_n),
    .pop(wr_go), .pop_lo(wg_lo), .pop_k(wg_n), .pop_data(wr_data), .count(ra_count));

  assign used_next = (CW+2)'(ra_count) + (CW+2)'(res) + (CW+2)'(ra_n);

  // ------------------------------------------------------------ issue
  assign rd_valid = act && !errq && ra_valid && (rm_cnt < (RW+1)'(MAXR)) && (used_next <= (CW+2)'(RCAP));
  assign rd_addr  = ra_addr;
  assign rd_n     = ra_n;
  assign rd_go    = rd_valid && rd_gnt;

  assign wr_valid = act && !errq && wa_g_valid && (ra_count >= (CW+1)'(wg_n)) && (wm_cnt < (WW+1)'(MAXW));
  assign wr_addr  = wa_g_addr;
  always_comb begin
    for (int l = 0; l < WB; l++) wr_strb[l] = (LWB'(l) >= wg_lo) && (LWB'(l) <= wg_hi);
  end
  assign wr_go    = wr_valid && wr_gnt;

  // ------------------------------------------------------------ completion
  logic finish;
  assign finish = act && (rm_cnt == '0) && (wm_cnt == '0) && !rd_go && !wr_go &&
                  (errq || (!ra_valid && !wa_g_valid));
  assign done = finish;
  assign busy = act;
  assign err  = errq;

  assign ev_rd_bytes = rl_push ? rh_n : '0;
  assign ev_wr_bytes = (wa_take && !wa_err && !wr_err_seen) ? wm_head : '0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      act <= 1'b0; errq <= 1'b0; wr_err_seen <= 1'b0; err_wr <= 1'b0; err_detail <= '0; err_addr <= '0;
      bytes_ok <= '0; res <= '0;
    end else if (start) begin
      act <= 1'b1; errq <= 1'b0; wr_err_seen <= 1'b0; err_wr <= 1'b0; err_detail <= '0; err_addr <= '0;
      bytes_ok <= '0; res <= '0;
    end else begin
      if (finish) act <= 1'b0;
      res <= res + (rd_go ? (CW+1)'(ra_n) : '0) - (rr_take ? (CW+1)'(rh_n) : '0);
      if (wa_take && !wa_err && !wr_err_seen) bytes_ok <= bytes_ok + 32'(wm_head);
      if (wa_take && wa_err) wr_err_seen <= 1'b1;
      // first error wins; a read and a write error in the same cycle: the read is reported
      if (!errq) begin
        if (rr_take && rr_err) begin
          errq <= 1'b1; err_wr <= 1'b0; err_detail <= rr_detail; err_addr <= rr_addr;
        end else if (wa_take && wa_err) begin
          errq <= 1'b1; err_wr <= 1'b1; err_detail <= wa_detail; err_addr <= wa_addr;
        end
      end
    end
  end

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (rr_valid && rm_cnt == '0) $error("tdma_channel: read response with no read in flight");
    if (wa_valid && wm_cnt == '0) $error("tdma_channel: write acknowledgement with no write in flight");
    if (start && act) $error("tdma_channel: start while busy");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
