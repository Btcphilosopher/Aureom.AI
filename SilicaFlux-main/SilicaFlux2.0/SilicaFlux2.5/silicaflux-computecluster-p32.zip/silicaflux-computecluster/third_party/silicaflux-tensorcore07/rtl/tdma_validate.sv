// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_validate
// Descriptor validation (combinational).  Every rule is checked before the
// descriptor can touch a bus, a buffer or an ownership state; the first
// failing rule wins (docs/02_DESCRIPTOR.md §3):
//   RSVD      VERSION != TDMA_VERSION, KIND == 3, a reserved FLAG or RSVD bit set
//   ZERO      ROW_LEN == 0 or ROWS == 0
//   DST_ROWS  ROWS > 1 and DST_STRIDE < ROW_LEN  (destination rows would overlap)
//   EXT_OVF   last external byte >= 2^32           (64-bit arithmetic, never wraps)
//   EXT_RANGE external footprint not inside [MEM_LO, MEM_HI)
//   LOC_RANGE last local byte >= the set size of the target region (A / B / output)
// The external footprint is reported as the bounding interval [ext_lo, ext_hi]
// (used by the dependency checker).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tdma_validate #(
  parameter logic [32:0] MEM_LO      = 33'h0_0000_0000,
  parameter logic [32:0] MEM_HI      = 33'h1_0000_0000,
  parameter int          A_SET_BYTES = 512,
  parameter int          B_SET_BYTES = 512,
  parameter int          O_SET_BYTES = 256
) (
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [`TDMA_DESC_W-1:0] desc,          // ID bits are not validated
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [3:0]                   code,
  output logic [31:0]                  ext_lo,
  output logic [31:0]                  ext_hi
);
  logic [31:0] src, dst, sstr, dstr, ext_b, ext_s, loc_b, loc_s;
  logic [15:0] len, rows, rm1;
  logic [1:0]  kind;
  logic [5:0]  flags;
  logic [7:0]  rsvd, ver;
  logic [63:0] ext_last, loc_last, set_bytes;
  logic        is_store;

  assign src   = desc[`TDMA_D_SRC];
  assign dst   = desc[`TDMA_D_DST];
  assign sstr  = desc[`TDMA_D_SSTRIDE];
  assign dstr  = desc[`TDMA_D_DSTRIDE];
  assign len   = desc[`TDMA_D_ROWLEN];
  assign rows  = desc[`TDMA_D_ROWS];
  assign kind  = desc[`TDMA_D_KIND];
  assign flags = desc[`TDMA_D_FLAGS];
  assign rsvd  = desc[`TDMA_D_RSVD];
  assign ver   = desc[`TDMA_D_VER];

  assign is_store = (kind == `TDMA_K_STORE);
  assign ext_b = is_store ? dst  : src;
  assign ext_s = is_store ? dstr : sstr;
  assign loc_b = is_store ? src  : dst;
  assign loc_s = is_store ? sstr : dstr;
  assign rm1   = rows - 16'd1;

  // one 16x32 product per side; the sums are 64-bit so nothing can wrap
  assign ext_last  = 64'(ext_b) + 64'(rm1) * 64'(ext_s) + 64'(len) - 64'd1;
  assign loc_last  = 64'(loc_b) + 64'(rm1) * 64'(loc_s) + 64'(len) - 64'd1;
  assign set_bytes = (kind == `TDMA_K_LOAD_A) ? 64'(A_SET_BYTES) :
                     (kind == `TDMA_K_LOAD_B) ? 64'(B_SET_BYTES) : 64'(O_SET_BYTES);

  always_comb begin
    if (ver != `TDMA_VERSION || kind == `TDMA_K_RSVD || (flags & `TDMA_F_RSVD_MASK) != 6'd0 || rsvd != 8'd0)
      code = `TDMA_C_RSVD;
    else if (len == 16'd0 || rows == 16'd0)
      code = `TDMA_C_ZERO;
    else if (rows > 16'd1 && dstr < 32'(len))
      code = `TDMA_C_DST_ROWS;
    else if (ext_last[63:32] != 32'd0)
      code = `TDMA_C_EXT_OVF;
    /* verilator lint_off UNSIGNED */                  // MEM_LO = 0 makes the first compare constant
    else if (33'(ext_b) < MEM_LO || 33'(ext_last[31:0]) >= MEM_HI)
    /* verilator lint_on UNSIGNED */
      code = `TDMA_C_EXT_RANGE;
    else if (loc_last >= set_bytes)
      code = `TDMA_C_LOC_RANGE;
    else
      code = `TDMA_C_OK;
  end

  assign ext_lo = ext_b;
  assign ext_hi = ext_last[31:0];
endmodule

`default_nettype wire
