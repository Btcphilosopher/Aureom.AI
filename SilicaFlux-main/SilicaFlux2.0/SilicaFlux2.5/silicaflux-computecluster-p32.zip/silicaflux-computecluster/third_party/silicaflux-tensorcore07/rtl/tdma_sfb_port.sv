// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_sfb_port
// The adapter's single SFB2 master port (DataFabric PROTOCOL.md rev 2.0),
// shared by the load channel (reads of external memory) and the store channel
// (writes of external memory).
//
//   requesters  r: load-channel reads      w: store-channel writes
//        | round robin (pointer moves past the winner), outstanding credit
//        v
//   request register: req_valid is a flop (R3), payload held until accepted (R2)
//        v
//   SFB2 master  ──► DataFabric crossbar master port or a slave
//        | outstanding FIFO {write, addr}: one entry per ACCEPTED request
//        v (R5: exactly one response each, in acceptance order)
//   responses, rsp_ready = 1 (R4; both channels hold credits for every
//   response they can receive):  read -> load channel, write ack -> store channel
//
// Outstanding limit: out_cnt = requests granted (register or accepted) and not
// yet answered <= MAX_OUT.  MAX_OUT = 1 is the baseline "one transaction in
// flight" mode.  Behind the DataFabric crossbar (R6: one transaction per master
// port) MAX_OUT >= 2 lets the next request wait in the register so the crossbar
// can accept it in the cycle the previous response is accepted.
// A write response is, by R7, issued only after the write was performed.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tdma_sfb_port #(
  parameter int  WB      = 4,
  parameter int  MAX_OUT = 4,                          // 1..16
  localparam int DW      = 8 * WB,
  localparam int OD      = (MAX_OUT < 2) ? 2 : MAX_OUT, // outstanding FIFO depth
  localparam int OW      = $clog2(OD)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- load-channel reads
  input  wire logic             r_valid,
  input  wire logic [31:0]      r_addr,
  output logic                  r_gnt,
  output logic                  r_rsp_valid,
  output logic [DW-1:0]         r_rsp_data,
  output logic                  r_rsp_err,
  output logic [31:0]           r_rsp_addr,
  // ---------------------------------------------------------- store-channel writes
  input  wire logic             w_valid,
  input  wire logic [31:0]      w_addr,
  input  wire logic [DW-1:0]    w_data,
  input  wire logic [WB-1:0]    w_strb,
  output logic                  w_gnt,
  output logic                  w_ack_valid,
  output logic                  w_ack_err,
  output logic [31:0]           w_ack_addr,
  // ---------------------------------------------------------- SFB2 master
  output logic                  req_valid,
  input  wire logic             req_ready,
  output logic                  req_write,
  output logic [31:0]           req_addr,
  output logic [DW-1:0]         req_wdata,
  output logic [WB-1:0]         req_wstrb,
  input  wire logic             rsp_valid,
  output logic                  rsp_ready,
  input  wire logic [DW-1:0]    rsp_rdata,
  input  wire logic             rsp_error,
  // ---------------------------------------------------------- status / events
  output logic [OW:0]           outstanding,
  output logic                  idle,
  output logic                  ev_stall,              // req_valid && !req_ready
  output logic                  ev_rd_acc,             // read accepted by the bus
  output logic                  ev_wr_acc,             // write accepted by the bus
  output logic                  ev_unsolicited         // response with nothing outstanding (dropped)
);
  if (MAX_OUT < 1 || MAX_OUT > 16 || (MAX_OUT & (MAX_OUT - 1)) != 0) begin : g_err_max_out
    `SRAM_CFG_FATAL("tdma_sfb_port: MAX_OUT must be 1, 2, 4, 8 or 16")
  end

  logic          rq_v, rq_w, prio_w;
  logic [31:0]   rq_addr;
  logic [DW-1:0] rq_data;
  logic [WB-1:0] rq_strb;
  logic [OW:0]   cnt, of_cnt;
  logic          acc, can_load, r_ok, w_ok, pick_r, pick_w, rsp_go;

  assign acc      = rq_v && req_ready;
  assign can_load = !rq_v || acc;
  assign r_ok     = r_valid && (cnt < (OW+1)'(MAX_OUT));
  assign w_ok     = w_valid && (cnt < (OW+1)'(MAX_OUT));
  assign pick_w   = can_load && w_ok && (!r_ok || prio_w);
  assign pick_r   = can_load && r_ok && !pick_w;
  assign r_gnt    = pick_r;
  assign w_gnt    = pick_w;

  assign req_valid = rq_v;
  assign req_write = rq_w;
  assign req_addr  = rq_addr;
  assign req_wdata = rq_w ? rq_data : '0;
  assign req_wstrb = rq_w ? rq_strb : '0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rq_v <= 1'b0; rq_w <= 1'b0; rq_addr <= '0; rq_data <= '0; rq_strb <= '0; prio_w <= 1'b0;
    end else begin
      if (pick_r) begin
        rq_v <= 1'b1; rq_w <= 1'b0; rq_addr <= r_addr; rq_data <= '0; rq_strb <= '0; prio_w <= 1'b1;
      end else if (pick_w) begin
        rq_v <= 1'b1; rq_w <= 1'b1; rq_addr <= w_addr; rq_data <= w_data; rq_strb <= w_strb; prio_w <= 1'b0;
      end else if (acc) begin
        rq_v <= 1'b0;
      end
    end
  end

  // ---------------------------------------------------------- outstanding FIFO {write, addr}
  logic [32:0] of_head;
  assign rsp_ready = 1'b1;
  assign rsp_go    = rsp_valid && (of_cnt != '0);

  dma_fifo #(.WIDTH(33), .DEPTH(OD)) u_of (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(acc), .wdata({rq_w, rq_addr}),
    .pop(rsp_go), .rdata(of_head), .count(of_cnt));

  assign r_rsp_valid = rsp_go && !of_head[32];
  assign r_rsp_data  = rsp_error ? '0 : rsp_rdata;
  assign r_rsp_err   = rsp_error;
  assign r_rsp_addr  = of_head[31:0];
  assign w_ack_valid = rsp_go && of_head[32];
  assign w_ack_err   = rsp_error;
  assign w_ack_addr  = of_head[31:0];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) cnt <= '0;
    else        cnt <= cnt + (OW+1)'(pick_r || pick_w) - (OW+1)'(rsp_go);
  end

  assign outstanding    = cnt;
  assign idle           = (cnt == '0);
  assign ev_stall       = rq_v && !req_ready;
  assign ev_rd_acc      = acc && !rq_w;
  assign ev_wr_acc      = acc && rq_w;
  assign ev_unsolicited = rsp_valid && (of_cnt == '0);

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (cnt > (OW+1)'(MAX_OUT)) $error("tdma_sfb_port: %0d transactions in flight, limit %0d", cnt, MAX_OUT);
    if (ev_unsolicited) $error("tdma_sfb_port: unsolicited SFB2 response");
    if (rq_v && rq_addr[$clog2(WB)-1:0] != '0) $error("tdma_sfb_port: misaligned SFB2 address (R9)");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
