// =============================================================================
// SilicaFlux TENSORCORE 07 :: tensor_output_buffer
// Double-buffered tensor output buffer between the TENSORCORE 04 commit port
// and the tensor DMA adapter.  No addressable output buffer existed in the
// repository (TC04 delivers committed rows as a valid/ready stream; TC06 wrote
// them straight to memory), so this block is built from existing, unmodified
// parts:
//   * storage      : Module 04 hpc_scratchpad (2 requester ports, banked,
//                    1RW / 1R1W, SRAM Wrapper Library backends)
//   * ownership    : TENSORCORE 03 tob_dbuf_ctrl (FREE -> FILLING -> READY -> IN_USE)
//   * gates (new)  : tout_gate, hardware enforcement of the ownership rules
//   * writer (new) : TC04 row beats -> word writes into the FILLING set
//
//   TC04 osram row beats ──► row writer ──► tout_gate(MODE 0) ──► port 0 ┐
//                              │ fill_begin / fill_end                   ├─ hpc_scratchpad
//   DMA (tdma_loc_port) ─────► tout_gate(MODE 1) ──────────────► port 1 ┘
//                              │ rd_begin / rd_end (= cmp_begin / cmp_end)
//                         tob_dbuf_ctrl (O_SETS = 1 or 2, strict alternation)
//
// Output set layout: tile row r, column j (INT32, little endian) at
//   set * O_SET_BYTES + r * O_LD + 4 * j
// One tile per set.  The writer acquires the next set (FREE -> FILLING) at
// the first beat of a tile, writes the active lanes of every row, waits for
// every write acknowledgement after the tile's last row (o_last) and only then
// hands the set to the DMA side (FILLING -> READY) together with the tile's
// tag / rows / columns / flags.  A set is never written while READY or IN_USE
// (the writer waits; the gate refuses), and the DMA can read a set only while
// IN_USE (gate), i.e. only after the whole tile is in the buffer.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`include "hpc_spm_defs.svh"
`default_nettype none

module tensor_output_buffer #(
  parameter int  WB           = 4,                 // word bytes (>= 4: one INT32 lane per write)
  parameter int  O_SETS       = 2,
  parameter int  O_SET_BYTES  = 256,               // power of two
  parameter int  TILE_M       = 4,
  parameter int  TILE_N       = 4,
  parameter int  O_LD         = 16,                // row pitch inside a set (bytes, multiple of 4)
  parameter int  NUM_BANKS    = 2,
  parameter int  PORT_MODE    = `HPC_SPM_PORT_1RW,
  parameter int  READ_LATENCY = 1,
  parameter int  BACKEND      = `SRAM_BACKEND_GENERIC,
  parameter int  TAG_W        = 8,
  localparam int DW   = 8 * WB,
  localparam int RIDW = (TILE_M > 1) ? $clog2(TILE_M) : 1,
  localparam int MW   = $clog2(TILE_M + 1),
  localparam int NW   = $clog2(TILE_N + 1),
  localparam int LW   = (TILE_N > 1) ? $clog2(TILE_N) : 1,
  localparam int OSW  = (O_SETS > 1) ? $clog2(O_SETS) : 1
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // ---------------------------------------------------------- producer: committed rows (TC04 osram + o_*)
  input  wire logic                   in_valid,
  output logic                        in_ready,
  input  wire logic [RIDW-1:0]        in_row,
  input  wire logic [TILE_N-1:0]      in_col_mask,
  input  wire logic [TILE_N*32-1:0]   in_data,
  input  wire logic                   in_last,
  input  wire logic [15:0]            in_tag,
  input  wire logic                   in_err,
  input  wire logic [TILE_N-1:0]      in_ovf,
  // ---------------------------------------------------------- DMA read port (Module 04 protocol)
  input  wire logic                   d_req_valid,
  output logic                        d_req_ready,
  input  wire logic                   d_req_we,
  input  wire logic [31:0]            d_req_addr,
  input  wire logic [DW-1:0]          d_req_wdata,
  input  wire logic [WB-1:0]          d_req_wstrb,
  input  wire logic [TAG_W-1:0]       d_req_tag,
  output logic                        d_rsp_valid,
  input  wire logic                   d_rsp_ready,
  output logic [DW-1:0]               d_rsp_rdata,
  output logic                        d_rsp_err,
  output logic [2:0]                  d_rsp_err_code,
  output logic                        d_rsp_we,
  output logic [TAG_W-1:0]            d_rsp_tag,
  // ---------------------------------------------------------- DMA ownership
  input  wire logic                   rd_begin_valid,
  output logic                        rd_begin_ready,
  input  wire logic                   rd_end_valid,
  output logic                        rd_end_ready,
  // ---------------------------------------------------------- state
  output logic [OSW-1:0]              wr_set,
  output logic [OSW-1:0]              rd_set,
  output logic [O_SETS*2-1:0]         set_state,
  output logic [O_SETS*16-1:0]        set_tag,          // tile record, valid from READY
  output logic [O_SETS*MW-1:0]        set_rows,
  output logic [O_SETS*NW-1:0]        set_cols,
  output logic [O_SETS*3-1:0]         set_flags,        // {write error, mask error, ovf/err from TC04}
  // ---------------------------------------------------------- events
  output logic                        ev_wr,            // producer word write accepted
  output logic                        ev_rd,            // DMA read accepted by the scratchpad
  output logic [1:0]                  ev_conflict,      // [0] writer / [1] DMA lost bank arbitration
  output logic                        ev_refused,       // a gate refused a request
  output logic                        ev_wr_err,        // a writer word write was answered with an error
  output logic                        ev_wr_wait        // a beat is waiting because no set is FREE
);
  if (WB < 4) begin : g_err_wb
    `SRAM_CFG_FATAL("tensor_output_buffer: WB must be >= 4 (one INT32 lane per word write)")
  end
  if ((O_LD % 4) != 0 || O_LD < 4 * TILE_N || (TILE_M - 1) * O_LD + 4 * TILE_N > O_SET_BYTES) begin : g_err_ld
    `SRAM_CFG_FATAL("tensor_output_buffer: O_LD must be a multiple of 4, >= 4*TILE_N, and a tile must fit in a set")
  end

  localparam int CAP = O_SETS * O_SET_BYTES;
  localparam int LWB = $clog2(WB);

  // ============================================================ ownership (TC03 tob_dbuf_ctrl, unmodified)
  logic fb_v, fb_r, fe_v, fe_r, g0_idle, g1_idle;
  /* verilator lint_off UNUSEDSIGNAL */
  logic own_cmp_owned;
  /* verilator lint_on UNUSEDSIGNAL */
  tob_dbuf_ctrl #(.NUM_SETS(O_SETS)) u_own (
    .clk(clk), .rst_n(rst_n),
    .fill_begin_valid(fb_v), .fill_begin_ready(fb_r), .fill_end_valid(fe_v), .fill_end_ready(fe_r),
    .cmp_begin_valid(rd_begin_valid), .cmp_begin_ready(rd_begin_ready),
    .cmp_end_valid(rd_end_valid), .cmp_end_ready(rd_end_ready),
    .dma_idle(g0_idle), .engine_idle(g1_idle),
    .fill_set(wr_set), .cmp_set(rd_set), .set_state(set_state), .cmp_owned(own_cmp_owned));

  // ============================================================ row writer
  localparam logic [2:0] W_IDLE = 3'd0, W_BEGIN = 3'd1, W_ROWS = 3'd2, W_WAIT = 3'd3, W_END = 3'd4;
  logic [2:0]    ws;
  logic [31:0]   sbase;
  logic [LW-1:0] lane;
  logic [NW-1:0] n_lanes;
  logic          mask_ok, last_lane, w_go;
  logic [15:0]   r_tag;
  logic [MW-1:0] r_rows;
  logic [NW-1:0] r_cols;
  logic [2:0]    r_flags;
  logic [31:0]   lane_addr;
  logic [DW-1:0] lane_data;
  logic [WB-1:0] lane_strb;
  logic [LWB-1:0] boff;

  always_comb begin
    n_lanes = '0;
    for (int j = 0; j < TILE_N; j++) n_lanes = n_lanes + NW'(in_col_mask[j]);
  end
  assign mask_ok   = (n_lanes != '0) && (in_col_mask == TILE_N'(({{TILE_N{1'b0}}, 1'b1} << n_lanes) - 1'b1));
  assign last_lane = ((NW)'(lane) == n_lanes - NW'(1)) || !mask_ok;
  assign lane_addr = sbase + 32'(in_row) * 32'(O_LD) + (32'(lane) << 2);   // byte address of the INT32 lane
  assign boff      = lane_addr[LWB-1:0];
  assign lane_data = DW'(in_data[32*lane +: 32]) << {boff, 3'b000};
  assign lane_strb = WB'(4'hF) << boff;

  // writer requester (H2 hold register, tag check) = tdma_loc_port
  logic          wq_v, wq_g, wr_rsp_v, wr_rsp_e;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [DW-1:0] wr_rsp_d;
  logic [3:0]    wr_rsp_det;
  logic [31:0]   wr_rsp_a;
  logic          wp_stall, wp_unsol;
  logic [2:0]    wp_out;
  /* verilator lint_on UNUSEDSIGNAL */
  logic          wp_idle, wp_acc;
  logic          p0_req_v, p0_req_r, p0_req_we, p0_rsp_v, p0_rsp_r, p0_rsp_e, p0_rsp_we;
  logic [31:0]   p0_req_a;
  logic [DW-1:0] p0_req_d, p0_rsp_d;
  logic [WB-1:0] p0_req_s;
  logic [TAG_W-1:0] p0_req_t, p0_rsp_t;
  logic [2:0]    p0_rsp_c;

  assign wq_v = (ws == W_ROWS) && in_valid && mask_ok;
  assign w_go = (ws == W_ROWS) && in_valid && (mask_ok ? wq_g : 1'b1);   // a malformed beat is dropped (flagged)
  assign in_ready = w_go && last_lane;

  tdma_loc_port #(.WB(WB), .MAX_OUT(4), .TAG_W(TAG_W)) u_wport (
    .clk(clk), .rst_n(rst_n),
    .u_valid(wq_v), .u_we(1'b1), .u_addr({lane_addr[31:LWB], {LWB{1'b0}}}), .u_data(lane_data), .u_strb(lane_strb),
    .u_gnt(wq_g),
    .u_rsp_valid(wr_rsp_v), .u_rsp_data(wr_rsp_d), .u_rsp_err(wr_rsp_e), .u_rsp_detail(wr_rsp_det),
    .u_rsp_addr(wr_rsp_a),
    .req_valid(p0_req_v), .req_ready(p0_req_r), .req_we(p0_req_we), .req_addr(p0_req_a),
    .req_wdata(p0_req_d), .req_wstrb(p0_req_s), .req_tag(p0_req_t),
    .rsp_valid(p0_rsp_v), .rsp_ready(p0_rsp_r), .rsp_rdata(p0_rsp_d), .rsp_err(p0_rsp_e),
    .rsp_err_code(p0_rsp_c), .rsp_we(p0_rsp_we), .rsp_tag(p0_rsp_t),
    .outstanding(wp_out), .idle(wp_idle), .ev_stall(wp_stall), .ev_acc(wp_acc), .ev_unsolicited(wp_unsol));

  assign fb_v = (ws == W_BEGIN);
  assign fe_v = (ws == W_END);

  logic [15:0]    m_tag  [O_SETS];
  logic [MW-1:0]  m_rows [O_SETS];
  logic [NW-1:0]  m_cols [O_SETS];
  logic [2:0]     m_flg  [O_SETS];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ws <= W_IDLE; sbase <= '0; lane <= '0; r_tag <= '0; r_rows <= '0; r_cols <= '0; r_flags <= '0;
      for (int s = 0; s < O_SETS; s++) begin m_tag[s] <= '0; m_rows[s] <= '0; m_cols[s] <= '0; m_flg[s] <= '0; end
    end else begin
      case (ws)
        W_IDLE:  if (in_valid) ws <= W_BEGIN;
        W_BEGIN: if (fb_r) begin
          ws <= W_ROWS; sbase <= 32'(wr_set) * 32'(O_SET_BYTES); lane <= '0;
          r_tag <= in_tag; r_rows <= '0; r_cols <= n_lanes; r_flags <= '0;
        end
        W_ROWS: if (w_go) begin
          lane <= last_lane ? '0 : lane + LW'(1);
          if (last_lane) begin
            r_rows  <= MW'(in_row) + MW'(1);
            r_flags <= r_flags | {1'b0, !mask_ok || (in_tag != r_tag) || (n_lanes != r_cols), in_err || (|in_ovf)};
            if (in_last) ws <= W_WAIT;
          end
        end
        W_WAIT:  if (wp_idle) ws <= W_END;
        W_END:   if (fe_r) begin
          m_tag[wr_set] <= r_tag; m_rows[wr_set] <= r_rows; m_cols[wr_set] <= r_cols; m_flg[wr_set] <= r_flags;
          ws <= W_IDLE;
        end
        default: ws <= W_IDLE;
      endcase
      if (wr_rsp_v && wr_rsp_e) r_flags[2] <= 1'b1;            // a write was refused / failed
    end
  end

  always_comb begin
    for (int s = 0; s < O_SETS; s++) begin
      set_tag[s*16 +: 16]  = m_tag[s];
      set_rows[s*MW +: MW] = m_rows[s];
      set_cols[s*NW +: NW] = m_cols[s];
      set_flags[s*3 +: 3]  = m_flg[s];
    end
  end

  // ============================================================ gates
  logic          g0_ref, g1_ref;
  logic          q0_v, q0_r, q0_we, r0_v, r0_r, r0_e, r0_we, q1_v, q1_r, q1_we, r1_v, r1_r, r1_e, r1_we;
  logic [31:0]   q0_a, q1_a;
  logic [DW-1:0] q0_d, r0_d, q1_d, r1_d;
  logic [WB-1:0] q0_s, q1_s;
  logic [TAG_W-1:0] q0_t, r0_t, q1_t, r1_t;
  logic [2:0]    r0_c, r1_c;

  tout_gate #(.WB(WB), .TAG_W(TAG_W), .O_SETS(O_SETS), .SET_BYTES(O_SET_BYTES), .MODE(0)) u_g0 (
    .clk(clk), .rst_n(rst_n), .set_state(set_state),
    .u_req_valid(p0_req_v), .u_req_ready(p0_req_r), .u_req_we(p0_req_we), .u_req_addr(p0_req_a),
    .u_req_wdata(p0_req_d), .u_req_wstrb(p0_req_s), .u_req_tag(p0_req_t),
    .u_rsp_valid(p0_rsp_v), .u_rsp_ready(p0_rsp_r), .u_rsp_rdata(p0_rsp_d), .u_rsp_err(p0_rsp_e),
    .u_rsp_err_code(p0_rsp_c), .u_rsp_we(p0_rsp_we), .u_rsp_tag(p0_rsp_t),
    .s_req_valid(q0_v), .s_req_ready(q0_r), .s_req_we(q0_we), .s_req_addr(q0_a), .s_req_wdata(q0_d),
    .s_req_wstrb(q0_s), .s_req_tag(q0_t),
    .s_rsp_valid(r0_v), .s_rsp_ready(r0_r), .s_rsp_rdata(r0_d), .s_rsp_err(r0_e), .s_rsp_err_code(r0_c),
    .s_rsp_we(r0_we), .s_rsp_tag(r0_t), .idle(g0_idle), .ev_refused(g0_ref));

  tout_gate #(.WB(WB), .TAG_W(TAG_W), .O_SETS(O_SETS), .SET_BYTES(O_SET_BYTES), .MODE(1)) u_g1 (
    .clk(clk), .rst_n(rst_n), .set_state(set_state),
    .u_req_valid(d_req_valid), .u_req_ready(d_req_ready), .u_req_we(d_req_we), .u_req_addr(d_req_addr),
    .u_req_wdata(d_req_wdata), .u_req_wstrb(d_req_wstrb), .u_req_tag(d_req_tag),
    .u_rsp_valid(d_rsp_valid), .u_rsp_ready(d_rsp_ready), .u_rsp_rdata(d_rsp_rdata), .u_rsp_err(d_rsp_err),
    .u_rsp_err_code(d_rsp_err_code), .u_rsp_we(d_rsp_we), .u_rsp_tag(d_rsp_tag),
    .s_req_valid(q1_v), .s_req_ready(q1_r), .s_req_we(q1_we), .s_req_addr(q1_a), .s_req_wdata(q1_d),
    .s_req_wstrb(q1_s), .s_req_tag(q1_t),
    .s_rsp_valid(r1_v), .s_rsp_ready(r1_r), .s_rsp_rdata(r1_d), .s_rsp_err(r1_e), .s_rsp_err_code(r1_c),
    .s_rsp_we(r1_we), .s_rsp_tag(r1_t), .idle(g1_idle), .ev_refused(g1_ref));

  // ============================================================ storage: Module 04 hpc_scratchpad (unmodified)
  /* verilator lint_off UNUSEDSIGNAL */
  logic [2*WB-1:0]  sp_syn;
  logic [1:0]       sp_acc, sp_issue, sp_cstall, sp_err, sp_ecc;
  logic [NUM_BANKS*2-1:0] sp_bops;
  logic [NUM_BANKS-1:0]   sp_bconf;
  logic [31:0]      sp_pc_cyc, sp_pc_ecc;
  logic [2*32-1:0]  sp_pc_acc, sp_pc_iss, sp_pc_cpl, sp_pc_conf, sp_pc_wait, sp_pc_err;
  logic [NUM_BANKS*32-1:0] sp_pc_bops;
  logic             sp_busy;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [1:0]       sp_conf;

  hpc_scratchpad #(
    .NUM_PORTS(2), .CAPACITY_BYTES(CAP), .NUM_BANKS(NUM_BANKS), .DATA_WIDTH(DW), .ADDR_WIDTH(32),
    .BASE_ADDR(64'h0), .READ_LATENCY(READ_LATENCY), .BYTE_WE(1), .PORT_MODE(PORT_MODE), .MAP(`HPC_SPM_MAP_LOW),
    .ARB(`HPC_SPM_ARB_RR), .QUEUE_DEPTH(0), .RSP_FIFO_DEPTH(READ_LATENCY + 1), .WRITE_ACK(1), .TAG_W(TAG_W),
    .ECC_MODE(`HPC_SPM_ECC_NONE), .BACKEND(BACKEND), .MACRO(0), .PERF_EN(0), .CNT_W(32)
  ) u_spm (
    .clk(clk), .rst_n(rst_n),
    .req_valid({q1_v, q0_v}), .req_ready({q1_r, q0_r}), .req_we({q1_we, q0_we}), .req_addr({q1_a, q0_a}),
    .req_wdata({q1_d, q0_d}), .req_wstrb({q1_s, q0_s}), .req_tag({q1_t, q0_t}),
    .rsp_valid({r1_v, r0_v}), .rsp_ready({r1_r, r0_r}), .rsp_rdata({r1_d, r0_d}), .rsp_err({r1_e, r0_e}),
    .rsp_err_code({r1_c, r0_c}), .rsp_we({r1_we, r0_we}), .rsp_tag({r1_t, r0_t}), .rsp_ecc_syn(sp_syn),
    .ev_accept(sp_acc), .ev_issue(sp_issue), .ev_conflict(sp_conf), .ev_credit_stall(sp_cstall),
    .ev_error(sp_err), .ev_ecc_err(sp_ecc), .ev_bank_ops(sp_bops), .ev_bank_conflict(sp_bconf),
    .perf_clear(1'b0), .perf_cycles(sp_pc_cyc), .perf_accept(sp_pc_acc), .perf_issue(sp_pc_iss),
    .perf_complete(sp_pc_cpl), .perf_conflict(sp_pc_conf), .perf_wait(sp_pc_wait), .perf_error(sp_pc_err),
    .perf_bank_ops(sp_pc_bops), .perf_ecc_err(sp_pc_ecc), .busy(sp_busy));

  assign ev_wr       = wp_acc;
  assign ev_rd       = q1_v && q1_r;
  assign ev_conflict = sp_conf;
  assign ev_refused  = g0_ref || g1_ref;
  assign ev_wr_err   = wr_rsp_v && wr_rsp_e;
  assign ev_wr_wait  = (ws == W_BEGIN) && !fb_r;
endmodule

`default_nettype wire
