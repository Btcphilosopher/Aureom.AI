// =============================================================================
// SilicaFlux TENSORCORE 07 :: tensor_dma_adapter
// Tensor DMA adapter and memory-movement pipeline (primary source).
// Aureom.AI | SilicaFlux-HPC
//
// Moves tensor operands and results between external memory (one SFB2 master
// port: DataFabric crossbar or a memory slave) and the TensorCore buffers:
//   LOAD_A : external memory -> TC03 operand buffer, A region of the fill set
//   LOAD_B : external memory -> TC03 operand buffer, B region of the fill set
//   STORE  : tensor output buffer (drain set) -> external memory
// with 2-D strided, byte-addressed descriptors (tdma_defs.svh), explicit
// double-buffer ownership and an optional next-tile prefetch mode.
//
//   desc ─► intake reg ─► tdma_validate ─┬─► load queue ──► LOAD channel FSM ─┐   tdma_buf_coord
//    (192 b)  (seq no.)                  └─► store queue ─► STORE channel FSM ─┤◄─► TC03 fill_begin/end
//                         dependency check: age + external footprint (both ways)  ◄─► OBUF rd_begin/end
//   LOAD  datapath: tdma_channel  rd ─► tdma_sfb_port (SFB2)    wr ─► tdma_loc_port ─► TC03 fill port
//   STORE datapath: tdma_channel  rd ─► tdma_loc_port ─► OBUF   wr ─► tdma_sfb_port (SFB2)
//   completions (any channel, carrying ID) ─► completion FIFO ─► cpl_*
//   events ─► tdma_perf (18 saturating counters)
//
// MODES (cfg_prefetch, sampled every cycle; change it only while idle):
//   0 SEQUENTIAL  descriptors execute one at a time in submission order, and an
//                 operand fill starts only when compute holds no operand set:
//                 load -> compute -> store never overlap (fallback mode).
//   1 PREFETCH    the load and store channels run concurrently on the shared
//                 SFB2 port; the next operand set is filled while compute uses
//                 the other one.  Memory dependencies are preserved: a
//                 descriptor waits while an OLDER descriptor of the other
//                 channel that is still pending (queued or active) has an
//                 overlapping external footprint (RAW: load after store, WAR:
//                 store after load).  Same-channel order is program order.
//                 FENCE forces "every older descriptor completed" per descriptor.
// COMPLETION: one record per descriptor, after every destination write of the
//   descriptor was acknowledged by its target (SFB2 R7 / TC03 / Module 04
//   WRITE_ACK: acknowledged = performed) and, for SEAL, after the ownership
//   hand-over.  Records of one channel are in submission order; in SEQUENTIAL
//   mode all records are in submission order.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`default_nettype none

module tensor_dma_adapter #(
  parameter int          WB          = 4,             // bytes per word: SFB2 DW = 8*WB = TC03 / OBUF word
  parameter int          NUM_SETS    = 2,             // TC03 operand sets (1 or 2) - must match TC03
  parameter int          A_SET_BYTES = 512,           // TC03 A set size            - must match TC03
  parameter int          B_SET_BYTES = 512,           // TC03 B set size            - must match TC03
  parameter logic [31:0] OP_BASE     = 32'h0,         // TC03 DMA_BASE
  parameter int          O_SETS      = 2,             // output sets (1 or 2)       - must match OBUF
  parameter int          O_SET_BYTES = 256,           // output set size            - must match OBUF
  parameter logic [31:0] OB_BASE     = 32'h0,         // output buffer window base
  parameter logic [32:0] MEM_LO      = 33'h0_0000_0000, // legal external window [MEM_LO, MEM_HI)
  parameter logic [32:0] MEM_HI      = 33'h1_0000_0000,
  parameter int          MAX_OUT     = 4,             // SFB2 transactions in flight (1 = baseline)
  parameter int          LOC_OUT     = 4,             // local-port transactions in flight
  parameter int          RCAP        = 32,            // realigner bytes per channel
  parameter int          QDEPTH      = 4,             // descriptor queue per channel
  parameter int          CPL_DEPTH   = 4,             // completion queue
  parameter int          TAG_W       = 8,             // local-port tag width
  parameter int          CNT_W       = 32,
  localparam int DW   = 8 * WB,
  localparam int SW   = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int OSW  = (O_SETS > 1) ? $clog2(O_SETS) : 1,
  localparam int SOD  = (MAX_OUT < 2) ? 2 : MAX_OUT,
  localparam int LOD  = (LOC_OUT < 2) ? 2 : LOC_OUT,
  localparam int SOW  = $clog2(SOD),
  localparam int LOW_ = $clog2(LOD),
  localparam int NPC  = `TDMA_NUM_PC
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic                   cfg_prefetch,
  // ---------------------------------------------------------- descriptors
  input  wire logic                   desc_valid,
  output logic                        desc_ready,
  input  wire logic [`TDMA_DESC_W-1:0] desc_data,
  // ---------------------------------------------------------- completions
  output logic                        cpl_valid,
  input  wire logic                   cpl_ready,
  output logic [7:0]                  cpl_id,
  output logic [1:0]                  cpl_kind,
  output logic [3:0]                  cpl_code,
  output logic [2:0]                  cpl_detail,      // local port error code (LOC_RD / LOC_WR)
  output logic [31:0]                 cpl_err_addr,
  output logic [31:0]                 cpl_bytes,       // destination bytes acknowledged OK (prefix)
  // ---------------------------------------------------------- SFB2 master (external memory)
  output logic                        req_valid,
  input  wire logic                   req_ready,
  output logic                        req_write,
  output logic [31:0]                 req_addr,
  output logic [DW-1:0]               req_wdata,
  output logic [WB-1:0]               req_wstrb,
  input  wire logic                   rsp_valid,
  output logic                        rsp_ready,
  input  wire logic [DW-1:0]          rsp_rdata,
  input  wire logic                   rsp_error,
  // ---------------------------------------------------------- TC03 fill port (Module 04 protocol)
  output logic                        op_req_valid,
  input  wire logic                   op_req_ready,
  output logic                        op_req_we,
  output logic [31:0]                 op_req_addr,
  output logic [DW-1:0]               op_req_wdata,
  output logic [WB-1:0]               op_req_wstrb,
  output logic [TAG_W-1:0]            op_req_tag,
  input  wire logic                   op_rsp_valid,
  output logic                        op_rsp_ready,
  input  wire logic [DW-1:0]          op_rsp_rdata,
  input  wire logic                   op_rsp_err,
  input  wire logic [2:0]             op_rsp_err_code,
  input  wire logic                   op_rsp_we,
  input  wire logic [TAG_W-1:0]       op_rsp_tag,
  // ---------------------------------------------------------- TC03 ownership (DMA side)
  output logic                        op_fill_begin_valid,
  input  wire logic                   op_fill_begin_ready,
  output logic                        op_fill_end_valid,
  input  wire logic                   op_fill_end_ready,
  input  wire logic [SW-1:0]          op_fill_set,
  input  wire logic [NUM_SETS*2-1:0]  op_set_state,
  // ---------------------------------------------------------- output buffer DMA port (Module 04 protocol)
  output logic                        ob_req_valid,
  input  wire logic                   ob_req_ready,
  output logic                        ob_req_we,
  output logic [31:0]                 ob_req_addr,
  output logic [DW-1:0]               ob_req_wdata,
  output logic [WB-1:0]               ob_req_wstrb,
  output logic [TAG_W-1:0]            ob_req_tag,
  input  wire logic                   ob_rsp_valid,
  output logic                        ob_rsp_ready,
  input  wire logic [DW-1:0]          ob_rsp_rdata,
  input  wire logic                   ob_rsp_err,
  input  wire logic [2:0]             ob_rsp_err_code,
  input  wire logic                   ob_rsp_we,
  input  wire logic [TAG_W-1:0]       ob_rsp_tag,
  // ---------------------------------------------------------- output buffer ownership (DMA side)
  output logic                        ob_rd_begin_valid,
  input  wire logic                   ob_rd_begin_ready,
  output logic                        ob_rd_end_valid,
  input  wire logic                   ob_rd_end_ready,
  input  wire logic [OSW-1:0]         ob_rd_set,
  input  wire logic [O_SETS*2-1:0]    ob_set_state,
  // ---------------------------------------------------------- status
  output logic                        busy,            // a descriptor is queued or in a channel
  output logic [2:0]                  ld_state,
  output logic [2:0]                  st_state,
  output logic [7:0]                  ld_id,
  output logic [7:0]                  st_id,
  output logic [SOW:0]                sfb_outstanding,
  output logic [LOW_:0]               op_outstanding,
  output logic [LOW_:0]               ob_outstanding,
  output logic                        ev_cpl,          // a completion record was produced (descriptor finished)
  output logic [7:0]                  ev_cpl_id,       //   ... its ID
  output logic                        ev_proto,        // unsolicited response on any port (dropped)
  // ---------------------------------------------------------- performance counters
  input  wire logic                   perf_clear,
  output logic [NPC*CNT_W-1:0]        perf_cnt
);
  // ============================================================ configuration checks
  if (WB < 2 || (WB & (WB - 1)) != 0) begin : g_err_wb
    `SRAM_CFG_FATAL("tensor_dma_adapter: WB must be a power of two >= 2")
  end
  if (NUM_SETS != 1 && NUM_SETS != 2) begin : g_err_sets
    `SRAM_CFG_FATAL("tensor_dma_adapter: NUM_SETS must be 1 or 2 (TC03)")
  end
  if (O_SETS != 1 && O_SETS != 2) begin : g_err_osets
    `SRAM_CFG_FATAL("tensor_dma_adapter: O_SETS must be 1 or 2")
  end
  if (QDEPTH < 2 || (QDEPTH & (QDEPTH - 1)) != 0 || QDEPTH > 16) begin : g_err_qd
    `SRAM_CFG_FATAL("tensor_dma_adapter: QDEPTH must be a power of two in 2..16")
  end
  if (CPL_DEPTH < 2 || (CPL_DEPTH & (CPL_DEPTH - 1)) != 0) begin : g_err_cpl
    `SRAM_CFG_FATAL("tensor_dma_adapter: CPL_DEPTH must be a power of two >= 2")
  end
  if (RCAP < 2 * WB || (RCAP & (RCAP - 1)) != 0) begin : g_err_rcap
    `SRAM_CFG_FATAL("tensor_dma_adapter: RCAP must be a power of two >= 2*WB")
  end
  if (MAX_OUT < 1 || MAX_OUT > 16 || (MAX_OUT & (MAX_OUT - 1)) != 0) begin : g_err_max_out
    `SRAM_CFG_FATAL("tensor_dma_adapter: MAX_OUT must be 1, 2, 4, 8 or 16")
  end
  if (LOC_OUT < 1 || LOC_OUT > 16 || (LOC_OUT & (LOC_OUT - 1)) != 0) begin : g_err_loc_out
    `SRAM_CFG_FATAL("tensor_dma_adapter: LOC_OUT must be 1, 2, 4, 8 or 16")
  end
  if (MEM_LO >= MEM_HI) begin : g_err_mem
    `SRAM_CFG_FATAL("tensor_dma_adapter: MEM_LO must be below MEM_HI")
  end

  localparam logic [31:0] A_TOT  = 32'(NUM_SETS * A_SET_BYTES);
  localparam logic [31:0] B_TOT  = 32'(NUM_SETS * B_SET_BYTES);
  localparam logic [31:0] REGION = (A_TOT > B_TOT) ? A_TOT : B_TOT;      // = TC03 tob_dma_port REGION
  localparam int QAW = $clog2(QDEPTH);

  // ============================================================ queue entry layout
  localparam int E_SRC = 0, E_DST = 32, E_SSTR = 64, E_DSTR = 96, E_LEN = 128, E_ROWS = 144, E_ID = 160,
                 E_KIND = 168, E_SEAL = 170, E_FENCE = 171, E_CODE = 172, E_SEQ = 176, E_LO = 184, E_HI = 216,
                 QW = 248;

  // ============================================================ intake + validation
  logic                    in_v, in_go, in_store;
  logic [`TDMA_DESC_W-1:0] in_d;
  logic [3:0]              v_code;
  logic [31:0]             v_lo, v_hi;
  logic [7:0]              seq_ctr;
  logic [QW-1:0]           in_ent;
  logic [QAW:0]            ql_cnt, qs_cnt;

  tdma_validate #(.MEM_LO(MEM_LO), .MEM_HI(MEM_HI), .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES),
                  .O_SET_BYTES(O_SET_BYTES)) u_val (
    .desc(in_d), .code(v_code), .ext_lo(v_lo), .ext_hi(v_hi));

  assign in_store   = (in_d[`TDMA_D_KIND] == `TDMA_K_STORE);
  assign in_go      = in_v && (in_store ? (qs_cnt < (QAW+1)'(QDEPTH)) : (ql_cnt < (QAW+1)'(QDEPTH)));
  assign desc_ready = !in_v || in_go;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [5:0] in_flags;                               // reserved bits: checked by tdma_validate
  /* verilator lint_on UNUSEDSIGNAL */
  assign in_flags   = in_d[`TDMA_D_FLAGS];
  assign in_ent     = {v_hi, v_lo, seq_ctr, v_code, in_flags[`TDMA_F_FENCE], in_flags[`TDMA_F_SEAL],
                       in_d[`TDMA_D_KIND], in_d[`TDMA_D_ID], in_d[`TDMA_D_ROWS], in_d[`TDMA_D_ROWLEN],
                       in_d[`TDMA_D_DSTRIDE], in_d[`TDMA_D_SSTRIDE], in_d[`TDMA_D_DST], in_d[`TDMA_D_SRC]};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      in_v <= 1'b0; in_d <= '0; seq_ctr <= '0;
    end else begin
      if (in_go) seq_ctr <= seq_ctr + 8'd1;
      if (desc_valid && desc_ready) begin
        in_v <= 1'b1; in_d <= desc_data;
      end else if (in_go) begin
        in_v <= 1'b0;
      end
    end
  end

  // ============================================================ channel queues
  logic [QW-1:0]        ql_head, qs_head;
  logic [QDEPTH*QW-1:0] ql_ent, qs_ent;
  logic [QDEPTH-1:0]    ql_ev, qs_ev;
  logic                 ql_pop, qs_pop;

  tdma_queue #(.W(QW), .DEPTH(QDEPTH)) u_ql (
    .clk(clk), .rst_n(rst_n), .push(in_go && !in_store), .wdata(in_ent), .pop(ql_pop),
    .head(ql_head), .count(ql_cnt), .ent(ql_ent), .ent_valid(ql_ev));
  tdma_queue #(.W(QW), .DEPTH(QDEPTH)) u_qs (
    .clk(clk), .rst_n(rst_n), .push(in_go && in_store), .wdata(in_ent), .pop(qs_pop),
    .head(qs_head), .count(qs_cnt), .ent(qs_ent), .ent_valid(qs_ev));

  // ============================================================ channel control registers
  // index 0 = load channel, 1 = store channel
  logic [2:0]  st   [2];
  logic [31:0] a_src[2], a_dst[2], a_sstr[2], a_dstr[2], a_lo[2], a_hi[2];
  logic [15:0] a_len[2], a_rows[2];
  logic [7:0]  a_id [2], a_seq[2];
  logic [1:0]  a_kind[2];
  logic        a_seal[2], a_ok[2];
  logic [3:0]  c_code[2];
  logic [2:0]  c_det [2];
  logic [31:0] c_addr[2], c_bytes[2];

  // ------------------------------------------------------------ dependency check
  // a submitted before b: sequence numbers are 8-bit and fewer than 128 descriptors are ever pending
  // (2*QDEPTH + 3 <= 35), so the sign of the modular difference is the age order.
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic older(input logic [7:0] a, input logic [7:0] b);
    logic [7:0] d;
    d = a - b;
    older = d[7];
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */
  function automatic logic ovl(input logic [31:0] alo, input logic [31:0] ahi,
                               input logic [31:0] blo, input logic [31:0] bhi);
    ovl = (alo <= bhi) && (blo <= ahi);
  endfunction

  logic [QW-1:0] hd [2];
  logic          hv [2], blocked[2], can_start[2], older_any[2], older_ovl[2];
  assign hd[0] = ql_head;
  assign hd[1] = qs_head;
  assign hv[0] = (ql_cnt != '0);
  assign hv[1] = (qs_cnt != '0);

  always_comb begin
    for (int c = 0; c < 2; c++) begin
      older_any[c] = 1'b0;
      older_ovl[c] = 1'b0;
      // the other channel's active descriptor
      if (st[1-c] != `TDMA_CH_IDLE && older(a_seq[1-c], hd[c][E_SEQ +: 8])) begin
        older_any[c] = 1'b1;
        if (a_ok[1-c] && ovl(a_lo[1-c], a_hi[1-c], hd[c][E_LO +: 32], hd[c][E_HI +: 32])) older_ovl[c] = 1'b1;
      end
      // every queued descriptor of the other channel
      for (int i = 0; i < QDEPTH; i++) begin
        if (c == 0) begin
          if (qs_ev[i] && older(qs_ent[i*QW + E_SEQ +: 8], hd[c][E_SEQ +: 8])) begin
            older_any[c] = 1'b1;
            if (qs_ent[i*QW + E_CODE +: 4] == `TDMA_C_OK &&
                ovl(qs_ent[i*QW + E_LO +: 32], qs_ent[i*QW + E_HI +: 32], hd[c][E_LO +: 32], hd[c][E_HI +: 32]))
              older_ovl[c] = 1'b1;
          end
        end else begin
          if (ql_ev[i] && older(ql_ent[i*QW + E_SEQ +: 8], hd[c][E_SEQ +: 8])) begin
            older_any[c] = 1'b1;
            if (ql_ent[i*QW + E_CODE +: 4] == `TDMA_C_OK &&
                ovl(ql_ent[i*QW + E_LO +: 32], ql_ent[i*QW + E_HI +: 32], hd[c][E_LO +: 32], hd[c][E_HI +: 32]))
              older_ovl[c] = 1'b1;
          end
        end
      end
      if (!cfg_prefetch || hd[c][E_FENCE]) blocked[c] = older_any[c];
      else                                 blocked[c] = (hd[c][E_CODE +: 4] == `TDMA_C_OK) && older_ovl[c];
      can_start[c] = hv[c] && (st[c] == `TDMA_CH_IDLE) && !blocked[c];
    end
  end
  assign ql_pop = can_start[0];
  assign qs_pop = can_start[1];

  // ============================================================ buffer coordination
  logic ld_acq, ld_acq_ok, ld_seal, ld_seal_ok, st_acq, st_acq_ok, st_seal, st_seal_ok;
  logic op_compute_owns, op_in_use, ld_bwait, st_bwait;

  assign ld_acq  = (st[0] == `TDMA_CH_OPEN);
  assign ld_seal = (st[0] == `TDMA_CH_SEAL);
  assign st_acq  = (st[1] == `TDMA_CH_OPEN);
  assign st_seal = (st[1] == `TDMA_CH_SEAL);

  tdma_buf_coord #(.NUM_SETS(NUM_SETS), .O_SETS(O_SETS)) u_coord (
    .prefetch(cfg_prefetch),
    .op_state(op_set_state), .op_fill_set(op_fill_set),
    .fill_begin_valid(op_fill_begin_valid), .fill_begin_ready(op_fill_begin_ready),
    .fill_end_valid(op_fill_end_valid), .fill_end_ready(op_fill_end_ready),
    .ob_state(ob_set_state), .ob_rd_set(ob_rd_set),
    .rd_begin_valid(ob_rd_begin_valid), .rd_begin_ready(ob_rd_begin_ready),
    .rd_end_valid(ob_rd_end_valid), .rd_end_ready(ob_rd_end_ready),
    .ld_acq(ld_acq), .ld_acq_ok(ld_acq_ok), .ld_seal(ld_seal), .ld_seal_ok(ld_seal_ok),
    .st_acq(st_acq), .st_acq_ok(st_acq_ok), .st_seal(st_seal), .st_seal_ok(st_seal_ok),
    .op_compute_owns(op_compute_owns), .op_in_use(op_in_use), .ld_wait(ld_bwait), .st_wait(st_bwait));

  // local addresses of the owned sets
  logic [31:0] ld_loc_dst, st_loc_src;
  assign ld_loc_dst = (a_kind[0] == `TDMA_K_LOAD_B)
                    ? OP_BASE + REGION + 32'(op_fill_set) * 32'(B_SET_BYTES) + a_dst[0]
                    : OP_BASE + 32'(op_fill_set) * 32'(A_SET_BYTES) + a_dst[0];
  assign st_loc_src = OB_BASE + 32'(ob_rd_set) * 32'(O_SET_BYTES) + a_src[1];

  // ============================================================ datapaths
  logic ch_start [2];
  assign ch_start[0] = ld_acq_ok;
  assign ch_start[1] = st_acq_ok;

  logic          ld_busy, ld_done, ld_err, ld_err_wr, st_busy, st_done, st_err, st_err_wr;
  logic [3:0]    ld_det, st_det;
  logic [31:0]   ld_eaddr, ld_bytes, st_eaddr, st_bytes;
  // load: SFB2 reads -> TC03 writes
  logic          l_rd_v, l_rd_g, l_rr_v, l_rr_e, l_wr_v, l_wr_g, l_wa_v, l_wa_e;
  logic [31:0]   l_rd_a, l_rr_a, l_wr_a, l_wa_a;
  logic [DW-1:0] l_rr_d, l_wr_d;
  logic [WB-1:0] l_wr_s;
  logic [3:0]    l_wa_det;
  logic [$clog2(WB):0] l_rd_n, l_evr, l_evw;
  // store: OBUF reads -> SFB2 writes
  logic          s_rd_v, s_rd_g, s_rr_v, s_rr_e, s_wr_v, s_wr_g, s_wa_v, s_wa_e;
  logic [31:0]   s_rd_a, s_rr_a, s_wr_a, s_wa_a;
  logic [DW-1:0] s_rr_d, s_wr_d;
  logic [WB-1:0] s_wr_s;
  logic [3:0]    s_rr_det;
  logic [$clog2(WB):0] s_rd_n, s_evr, s_evw;

  tdma_channel #(.WB(WB), .RCAP(RCAP), .MAXR(SOD), .MAXW(LOD)) u_ld (
    .clk(clk), .rst_n(rst_n), .start(ch_start[0]),
    .src(a_src[0]), .dst(ld_loc_dst), .src_stride(a_sstr[0]), .dst_stride(a_dstr[0]),
    .row_len(a_len[0]), .rows(a_rows[0]),
    .busy(ld_busy), .done(ld_done), .err(ld_err), .err_wr(ld_err_wr), .err_detail(ld_det),
    .err_addr(ld_eaddr), .bytes_ok(ld_bytes),
    .rd_valid(l_rd_v), .rd_addr(l_rd_a), .rd_n(l_rd_n), .rd_gnt(l_rd_g),
    .rr_valid(l_rr_v), .rr_data(l_rr_d), .rr_err(l_rr_e), .rr_detail(4'd0), .rr_addr(l_rr_a),
    .wr_valid(l_wr_v), .wr_addr(l_wr_a), .wr_data(l_wr_d), .wr_strb(l_wr_s), .wr_gnt(l_wr_g),
    .wa_valid(l_wa_v), .wa_err(l_wa_e), .wa_detail(l_wa_det), .wa_addr(l_wa_a),
    .ev_rd_bytes(l_evr), .ev_wr_bytes(l_evw));

  tdma_channel #(.WB(WB), .RCAP(RCAP), .MAXR(LOD), .MAXW(SOD)) u_st (
    .clk(clk), .rst_n(rst_n), .start(ch_start[1]),
    .src(st_loc_src), .dst(a_dst[1]), .src_stride(a_sstr[1]), .dst_stride(a_dstr[1]),
    .row_len(a_len[1]), .rows(a_rows[1]),
    .busy(st_busy), .done(st_done), .err(st_err), .err_wr(st_err_wr), .err_detail(st_det),
    .err_addr(st_eaddr), .bytes_ok(st_bytes),
    .rd_valid(s_rd_v), .rd_addr(s_rd_a), .rd_n(s_rd_n), .rd_gnt(s_rd_g),
    .rr_valid(s_rr_v), .rr_data(s_rr_d), .rr_err(s_rr_e), .rr_detail(s_rr_det), .rr_addr(s_rr_a),
    .wr_valid(s_wr_v), .wr_addr(s_wr_a), .wr_data(s_wr_d), .wr_strb(s_wr_s), .wr_gnt(s_wr_g),
    .wa_valid(s_wa_v), .wa_err(s_wa_e), .wa_detail(4'd0), .wa_addr(s_wa_a),
    .ev_rd_bytes(s_evr), .ev_wr_bytes(s_evw));

  // ------------------------------------------------------------ ports
  logic sfb_idle, sfb_stall, sfb_rd_acc, sfb_wr_acc, sfb_unsol;
  logic op_idle, op_stall, op_acc, op_unsol, ob_idle, ob_stall, ob_acc, ob_unsol;

  tdma_sfb_port #(.WB(WB), .MAX_OUT(MAX_OUT)) u_sfb (
    .clk(clk), .rst_n(rst_n),
    .r_valid(l_rd_v), .r_addr(l_rd_a), .r_gnt(l_rd_g),
    .r_rsp_valid(l_rr_v), .r_rsp_data(l_rr_d), .r_rsp_err(l_rr_e), .r_rsp_addr(l_rr_a),
    .w_valid(s_wr_v), .w_addr(s_wr_a), .w_data(s_wr_d), .w_strb(s_wr_s), .w_gnt(s_wr_g),
    .w_ack_valid(s_wa_v), .w_ack_err(s_wa_e), .w_ack_addr(s_wa_a),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr),
    .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .outstanding(sfb_outstanding), .idle(sfb_idle), .ev_stall(sfb_stall), .ev_rd_acc(sfb_rd_acc),
    .ev_wr_acc(sfb_wr_acc), .ev_unsolicited(sfb_unsol));

  /* verilator lint_off UNUSEDSIGNAL */
  logic [DW-1:0] op_rsp_data_unused;
  /* verilator lint_on UNUSEDSIGNAL */
  tdma_loc_port #(.WB(WB), .MAX_OUT(LOC_OUT), .TAG_W(TAG_W)) u_opp (
    .clk(clk), .rst_n(rst_n),
    .u_valid(l_wr_v), .u_we(1'b1), .u_addr(l_wr_a), .u_data(l_wr_d), .u_strb(l_wr_s), .u_gnt(l_wr_g),
    .u_rsp_valid(l_wa_v), .u_rsp_data(op_rsp_data_unused), .u_rsp_err(l_wa_e), .u_rsp_detail(l_wa_det),
    .u_rsp_addr(l_wa_a),
    .req_valid(op_req_valid), .req_ready(op_req_ready), .req_we(op_req_we), .req_addr(op_req_addr),
    .req_wdata(op_req_wdata), .req_wstrb(op_req_wstrb), .req_tag(op_req_tag),
    .rsp_valid(op_rsp_valid), .rsp_ready(op_rsp_ready), .rsp_rdata(op_rsp_rdata), .rsp_err(op_rsp_err),
    .rsp_err_code(op_rsp_err_code), .rsp_we(op_rsp_we), .rsp_tag(op_rsp_tag),
    .outstanding(op_outstanding), .idle(op_idle), .ev_stall(op_stall), .ev_acc(op_acc), .ev_unsolicited(op_unsol));

  tdma_loc_port #(.WB(WB), .MAX_OUT(LOC_OUT), .TAG_W(TAG_W)) u_obp (
    .clk(clk), .rst_n(rst_n),
    .u_valid(s_rd_v), .u_we(1'b0), .u_addr(s_rd_a), .u_data('0), .u_strb('0), .u_gnt(s_rd_g),
    .u_rsp_valid(s_rr_v), .u_rsp_data(s_rr_d), .u_rsp_err(s_rr_e), .u_rsp_detail(s_rr_det),
    .u_rsp_addr(s_rr_a),
    .req_valid(ob_req_valid), .req_ready(ob_req_ready), .req_we(ob_req_we), .req_addr(ob_req_addr),
    .req_wdata(ob_req_wdata), .req_wstrb(ob_req_wstrb), .req_tag(ob_req_tag),
    .rsp_valid(ob_rsp_valid), .rsp_ready(ob_rsp_ready), .rsp_rdata(ob_rsp_rdata), .rsp_err(ob_rsp_err),
    .rsp_err_code(ob_rsp_err_code), .rsp_we(ob_rsp_we), .rsp_tag(ob_rsp_tag),
    .outstanding(ob_outstanding), .idle(ob_idle), .ev_stall(ob_stall), .ev_acc(ob_acc), .ev_unsolicited(ob_unsol));

  // ============================================================ completion queue
  localparam int CW_ = 8 + 2 + 4 + 3 + 32 + 32;     // {id, kind, code, detail, err_addr, bytes}
  localparam int CQ_CODE = 3 + 32 + 32;
  localparam int CAW = $clog2(CPL_DEPTH);
  logic [CW_-1:0] cq_head, cq_in;
  logic [CAW:0]   cq_cnt;
  logic           cq_space, cq_push, cpl_g0, cpl_g1, cpl_g [2], cpl_rr;

  // round robin between the channels (cpl_rr = 1: the load channel won last)
  assign cq_space = (cq_cnt < (CAW+1)'(CPL_DEPTH));
  assign cpl_g0   = cq_space && (st[0] == `TDMA_CH_CPL) && (st[1] != `TDMA_CH_CPL || !cpl_rr);
  assign cpl_g1   = cq_space && (st[1] == `TDMA_CH_CPL) && !cpl_g0;
  assign cpl_g[0] = cpl_g0;
  assign cpl_g[1] = cpl_g1;
  assign cq_push  = cpl_g0 || cpl_g1;
  assign cq_in    = cpl_g0 ? {a_id[0], a_kind[0], c_code[0], c_det[0], c_addr[0], c_bytes[0]}
                             : {a_id[1], a_kind[1], c_code[1], c_det[1], c_addr[1], c_bytes[1]};

  dma_fifo #(.WIDTH(CW_), .DEPTH(CPL_DEPTH)) u_cq (
    .clk(clk), .rst_n(rst_n), .clr(1'b0), .push(cq_push), .wdata(cq_in),
    .pop(cpl_valid && cpl_ready), .rdata(cq_head), .count(cq_cnt));

  assign cpl_valid = (cq_cnt != '0);
  assign {cpl_id, cpl_kind, cpl_code, cpl_detail, cpl_err_addr, cpl_bytes} = cq_head;

  // ============================================================ channel FSMs
  logic        ch_done[2], ch_err[2], ch_err_wr[2], ch_acq_ok[2], ch_seal_ok[2];
  logic [3:0]  ch_det[2];
  logic [31:0] ch_eaddr[2], ch_bytes[2];
  assign ch_done[0] = ld_done;   assign ch_done[1] = st_done;
  assign ch_err[0]  = ld_err;    assign ch_err[1]  = st_err;
  assign ch_err_wr[0] = ld_err_wr; assign ch_err_wr[1] = st_err_wr;
  assign ch_det[0]  = ld_det;    assign ch_det[1]  = st_det;
  assign ch_eaddr[0] = ld_eaddr; assign ch_eaddr[1] = st_eaddr;
  assign ch_bytes[0] = ld_bytes; assign ch_bytes[1] = st_bytes;
  assign ch_acq_ok[0] = ld_acq_ok; assign ch_acq_ok[1] = st_acq_ok;
  assign ch_seal_ok[0] = ld_seal_ok; assign ch_seal_ok[1] = st_seal_ok;

  function automatic logic [3:0] err_code(input int c, input logic wr, input logic proto);
    if (c == 0) err_code = wr ? (proto ? `TDMA_C_PROTO : `TDMA_C_LOC_WR) : `TDMA_C_RD_BUS;
    else        err_code = wr ? `TDMA_C_WR_BUS : (proto ? `TDMA_C_PROTO : `TDMA_C_LOC_RD);
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cpl_rr <= 1'b0;
      for (int c = 0; c < 2; c++) begin
        st[c] <= `TDMA_CH_IDLE;
        a_src[c] <= '0; a_dst[c] <= '0; a_sstr[c] <= '0; a_dstr[c] <= '0; a_lo[c] <= '0; a_hi[c] <= '0;
        a_len[c] <= '0; a_rows[c] <= '0; a_id[c] <= '0; a_seq[c] <= '0; a_kind[c] <= '0; a_seal[c] <= 1'b0;
        a_ok[c] <= 1'b0; c_code[c] <= '0; c_det[c] <= '0; c_addr[c] <= '0; c_bytes[c] <= '0;
      end
    end else begin
      if (cq_push) cpl_rr <= cpl_g0;
      for (int c = 0; c < 2; c++) begin
        case (st[c])
          `TDMA_CH_IDLE: if (can_start[c]) begin
            a_src[c]  <= hd[c][E_SRC +: 32];   a_dst[c]  <= hd[c][E_DST +: 32];
            a_sstr[c] <= hd[c][E_SSTR +: 32];  a_dstr[c] <= hd[c][E_DSTR +: 32];
            a_len[c]  <= hd[c][E_LEN +: 16];   a_rows[c] <= hd[c][E_ROWS +: 16];
            a_id[c]   <= hd[c][E_ID +: 8];     a_kind[c] <= hd[c][E_KIND +: 2];
            a_seal[c] <= hd[c][E_SEAL];        a_seq[c]  <= hd[c][E_SEQ +: 8];
            a_lo[c]   <= hd[c][E_LO +: 32];    a_hi[c]   <= hd[c][E_HI +: 32];
            a_ok[c]   <= (hd[c][E_CODE +: 4] == `TDMA_C_OK);
            c_code[c] <= hd[c][E_CODE +: 4];   c_det[c]  <= '0; c_addr[c] <= '0; c_bytes[c] <= '0;
            st[c]     <= (hd[c][E_CODE +: 4] == `TDMA_C_OK) ? `TDMA_CH_OPEN : `TDMA_CH_CPL;
          end
          `TDMA_CH_OPEN: if (ch_acq_ok[c]) st[c] <= `TDMA_CH_RUN;
          `TDMA_CH_RUN: if (ch_done[c]) begin
            c_bytes[c] <= ch_bytes[c];
            if (ch_err[c]) begin
              c_code[c] <= err_code(c, ch_err_wr[c], ch_det[c][3]);
              c_det[c]  <= ch_det[c][2:0];
              c_addr[c] <= ch_eaddr[c];
              st[c]     <= `TDMA_CH_CPL;
            end else begin
              st[c]     <= a_seal[c] ? `TDMA_CH_SEAL : `TDMA_CH_CPL;
            end
          end
          `TDMA_CH_SEAL: if (ch_seal_ok[c]) st[c] <= `TDMA_CH_CPL;
          `TDMA_CH_CPL: if (cpl_g[c]) st[c] <= `TDMA_CH_IDLE;
          default: st[c] <= `TDMA_CH_IDLE;
        endcase
      end
    end
  end

  // ============================================================ status
  assign busy     = in_v || (ql_cnt != '0) || (qs_cnt != '0) || (st[0] != `TDMA_CH_IDLE) || (st[1] != `TDMA_CH_IDLE);
  assign ld_state = st[0];
  assign st_state = st[1];
  assign ld_id    = a_id[0];
  assign st_id    = a_id[1];
  assign ev_cpl   = cq_push;
  assign ev_cpl_id = cpl_g0 ? a_id[0] : a_id[1];
  assign ev_proto = sfb_unsol || op_unsol || ob_unsol;

  // ============================================================ performance counters
  localparam int IW = 8;
  logic [NPC*IW-1:0] inc;
  logic [IW-1:0]     out_now;
  assign out_now = IW'(sfb_outstanding) + IW'(op_outstanding) + IW'(ob_outstanding);
  always_comb begin
    inc = '0;
    inc[`TDMA_PC_ACTIVE    *IW +: IW] = IW'((st[0] != `TDMA_CH_IDLE) || (st[1] != `TDMA_CH_IDLE));
    inc[`TDMA_PC_RD_BYTES  *IW +: IW] = IW'(l_evr) + IW'(s_evr);
    inc[`TDMA_PC_WR_BYTES  *IW +: IW] = IW'(l_evw) + IW'(s_evw);
    inc[`TDMA_PC_RD_REQ    *IW +: IW] = IW'(sfb_rd_acc) + IW'(ob_acc);
    inc[`TDMA_PC_WR_REQ    *IW +: IW] = IW'(sfb_wr_acc) + IW'(op_acc);
    inc[`TDMA_PC_STALL     *IW +: IW] = IW'(sfb_stall || op_stall || ob_stall);
    inc[`TDMA_PC_SFB_STALL *IW +: IW] = IW'(sfb_stall);
    inc[`TDMA_PC_LOC_STALL *IW +: IW] = IW'(op_stall || ob_stall);
    inc[`TDMA_PC_OUT_SUM   *IW +: IW] = out_now;
    inc[`TDMA_PC_OUT_MAX   *IW +: IW] = out_now;
    inc[`TDMA_PC_BUF_WAIT  *IW +: IW] = IW'(ld_bwait) + IW'(st_bwait);
    inc[`TDMA_PC_DEP_WAIT  *IW +: IW] = IW'(hv[0] && st[0] == `TDMA_CH_IDLE && blocked[0]) +
                                        IW'(hv[1] && st[1] == `TDMA_CH_IDLE && blocked[1]);
    inc[`TDMA_PC_XFER_ERR  *IW +: IW] = IW'(cq_push && cq_in[CQ_CODE +: 4] != `TDMA_C_OK);
    inc[`TDMA_PC_DESC_OK   *IW +: IW] = IW'(cq_push && cq_in[CQ_CODE +: 4] == `TDMA_C_OK);
    inc[`TDMA_PC_OVERLAP   *IW +: IW] = IW'(op_acc && op_in_use);
    inc[`TDMA_PC_CPL_STALL *IW +: IW] = IW'(cpl_valid && !cpl_ready);
    inc[`TDMA_PC_LD_BUSY   *IW +: IW] = IW'(st[0] != `TDMA_CH_IDLE);
    inc[`TDMA_PC_ST_BUSY   *IW +: IW] = IW'(st[1] != `TDMA_CH_IDLE);
  end

  tdma_perf #(.N(NPC), .IW(IW), .CNT_W(CNT_W), .MAX_MASK(NPC'(1) << `TDMA_PC_OUT_MAX)) u_perf (
    .clk(clk), .rst_n(rst_n), .clear(perf_clear), .inc(inc), .cnt(perf_cnt));

  /* verilator lint_off UNUSEDSIGNAL */
  logic unused_ok;
  assign unused_ok = ld_busy ^ st_busy ^ sfb_idle ^ op_idle ^ ob_idle ^ op_compute_owns ^ (|l_rd_n) ^ (|s_rd_n);
  /* verilator lint_on UNUSEDSIGNAL */

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    if (st[0] == `TDMA_CH_RUN && op_fill_begin_valid) $error("tensor_dma_adapter: fill_begin during a load");
    if (op_req_valid && op_set_state[op_fill_set*2 +: 2] != `TDMA_BS_FILLING && st[0] == `TDMA_CH_RUN)
      $error("tensor_dma_adapter: TC03 write while the fill set is not FILLING");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
