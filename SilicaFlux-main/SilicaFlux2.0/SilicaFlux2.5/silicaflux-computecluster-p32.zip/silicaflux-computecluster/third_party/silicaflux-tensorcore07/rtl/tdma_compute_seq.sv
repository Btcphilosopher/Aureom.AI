// =============================================================================
// SilicaFlux TENSORCORE 07 :: tdma_compute_seq
// Reference compute sequencer for the integration tests: the compute consumer
// of the operand sets and the producer of the output sets.  It executes one
// "job" = one K chunk of one output tile on the UNMODIFIED TENSORCORE 02 array
// with TENSORCORE 03 operands and TENSORCORE 04 accumulation, and does nothing
// the DMA could rely on except the ownership handshakes:
//
//   job ─► cmp_begin (waits until TC03 says the set is READY = the DMA sealed it)
//       ─► TC04 cfg (first chunk only: open slot, k_total, n_chunks, dest = output SRAM)
//       ─► TC03 tile descriptor (the block as a small matrix inside the set) ─► tile_rsp
//       ─► TC02 cfg (eff m/n/k from TC03) ─► slices TC03 -> TC02 (direct wiring)
//       ─► after the last slice: cmp_end (the set is released to the DMA)
//       ─► readout TC02 -> TC04 (sideband slot/tag/chunk/chunk_k held by this block)
//       ─► next job.  TC04 commits a tile after its last chunk; the committed rows go
//          to tensor_output_buffer, which hands the output set to the DMA.
// One job at a time (the array runs one tile per launch); the DMA overlaps with it.
// Errors (TC03 tile rejected, TC02 / TC04 cfg rejected, TC04 malformed beat,
// array alignment error) are sticky in `err_flags` and never silently dropped.
// Classification: SYNTHESIZABLE (test infrastructure; a production scheduler is TC06)
// =============================================================================
`default_nettype none

module tdma_compute_seq #(
  parameter int  TILE_M    = 4,
  parameter int  TILE_N    = 4,
  parameter int  NUM_SLOTS = 2,
  localparam int MW        = $clog2(TILE_M + 1),
  localparam int NW        = $clog2(TILE_N + 1),
  localparam int SLOT_W    = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---------------------------------------------------------- jobs
  input  wire logic                job_valid,
  output logic                     job_ready,
  input  wire logic [15:0]         job_tag,         // output tile tag (same for every chunk of a tile)
  input  wire logic [MW-1:0]       job_m,
  input  wire logic [NW-1:0]       job_n,
  input  wire logic [16:0]         job_k,           // K of this chunk
  input  wire logic [39:0]         job_k_total,     // K of the tile (first chunk)
  input  wire logic [15:0]         job_n_chunks,
  input  wire logic [15:0]         job_chunk,       // chunk index
  input  wire logic [31:0]         job_a_addr, job_lda, job_b_addr, job_ldb,   // block layout inside the set
  // ---------------------------------------------------------- TC03 ownership + tiles + slice tap
  output logic                     cmp_begin_valid,
  input  wire logic                cmp_begin_ready,
  output logic                     cmp_end_valid,
  input  wire logic                cmp_end_ready,
  output logic                     tile_valid,
  input  wire logic                tile_ready,
  output logic [31:0]              tile_a_addr, tile_lda, tile_b_addr, tile_ldb,
  output logic [15:0]              tile_mat_m, tile_mat_n,
  output logic [16:0]              tile_mat_k, tile_k,
  output logic [7:0]               tile_tag,
  input  wire logic                tile_rsp_valid,
  input  wire logic                tile_rsp_err,
  input  wire logic [MW-1:0]       tile_rsp_m,
  input  wire logic [NW-1:0]       tile_rsp_n,
  input  wire logic [16:0]         tile_rsp_k,
  input  wire logic                s_hs_last,        // TC03 -> TC02 slice handshake with s_last
  // ---------------------------------------------------------- TC02
  output logic                     arr_cfg_valid,
  input  wire logic                arr_cfg_ready,
  output logic [MW-1:0]            arr_cfg_m,
  output logic [NW-1:0]            arr_cfg_n,
  output logic [16:0]              arr_cfg_k,
  input  wire logic                arr_cfg_reject,
  input  wire logic                arr_align_err,
  input  wire logic                arr_m_hs_last,    // readout handshake with m_last
  // ---------------------------------------------------------- TC04
  output logic                     acc_cfg_valid,
  input  wire logic                acc_cfg_ready,
  output logic [SLOT_W-1:0]        acc_cfg_slot,
  output logic [15:0]              acc_cfg_tag,
  output logic [MW-1:0]            acc_cfg_m,
  output logic [NW-1:0]            acc_cfg_n,
  output logic [39:0]              acc_cfg_k_total,
  output logic [15:0]              acc_cfg_n_chunks,
  input  wire logic                acc_cfg_reject,
  output logic [SLOT_W-1:0]        ps_slot,
  output logic [15:0]              ps_tag,
  output logic [15:0]              ps_chunk,
  output logic [16:0]              ps_chunk_k,
  input  wire logic                acc_err_pulse,
  // ---------------------------------------------------------- status
  output logic                     busy,
  output logic [4:0]               err_flags,        // {acc beat, acc cfg, array cfg/align, tile rejected, -}
  output logic [31:0]              jobs_done,
  output logic                     ev_compute        // array launched and not yet read out
);
  localparam logic [3:0] S_IDLE = 4'd0, S_CB = 4'd1, S_CFG = 4'd2, S_TILE = 4'd3, S_TRSP = 4'd4, S_ACFG = 4'd5,
                         S_RUN = 4'd6, S_CE = 4'd7, S_RD = 4'd8;
  logic [3:0]        s;
  logic [15:0]       j_tag, j_nch, j_chunk;
  logic [MW-1:0]     j_m, e_m;
  logic [NW-1:0]     j_n, e_n;
  logic [16:0]       j_k, e_k;
  logic [39:0]       j_kt;
  logic [31:0]       j_aa, j_lda, j_ba, j_ldb;
  logic [SLOT_W-1:0] slot;
  logic              slices_done, rd_done;

  assign job_ready       = (s == S_IDLE);
  assign cmp_begin_valid = (s == S_CB);
  assign acc_cfg_valid   = (s == S_CFG);
  assign tile_valid      = (s == S_TILE);
  assign arr_cfg_valid   = (s == S_ACFG);
  assign cmp_end_valid   = (s == S_CE);

  assign acc_cfg_slot = slot;     assign acc_cfg_tag = j_tag;  assign acc_cfg_m = j_m;  assign acc_cfg_n = j_n;
  assign acc_cfg_k_total = j_kt;  assign acc_cfg_n_chunks = j_nch;
  assign tile_a_addr = j_aa;  assign tile_lda = j_lda;  assign tile_b_addr = j_ba;  assign tile_ldb = j_ldb;
  assign tile_mat_m = 16'(j_m);  assign tile_mat_n = 16'(j_n);  assign tile_mat_k = j_k;  assign tile_k = j_k;
  assign tile_tag = j_tag[7:0];
  assign arr_cfg_m = e_m;  assign arr_cfg_n = e_n;  assign arr_cfg_k = e_k;
  assign ps_slot = slot;  assign ps_tag = j_tag;  assign ps_chunk = j_chunk;  assign ps_chunk_k = j_k;
  assign busy = (s != S_IDLE);
  assign ev_compute = (s == S_RUN) || (s == S_CE) || (s == S_RD);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s <= S_IDLE; j_tag <= '0; j_nch <= '0; j_chunk <= '0; j_m <= '0; j_n <= '0; j_k <= '0; j_kt <= '0;
      j_aa <= '0; j_lda <= '0; j_ba <= '0; j_ldb <= '0; e_m <= '0; e_n <= '0; e_k <= '0; slot <= '0;
      slices_done <= 1'b0; rd_done <= 1'b0; err_flags <= '0; jobs_done <= '0;
    end else begin
      if (s_hs_last)     slices_done <= 1'b1;
      if (arr_m_hs_last) rd_done     <= 1'b1;
      if (arr_cfg_reject || arr_align_err) err_flags[2] <= 1'b1;
      if (acc_cfg_reject) err_flags[3] <= 1'b1;
      if (acc_err_pulse)  err_flags[4] <= 1'b1;
      case (s)
        S_IDLE: if (job_valid) begin
          j_tag <= job_tag; j_nch <= job_n_chunks; j_chunk <= job_chunk; j_m <= job_m; j_n <= job_n; j_k <= job_k;
          j_kt <= job_k_total; j_aa <= job_a_addr; j_lda <= job_lda; j_ba <= job_b_addr; j_ldb <= job_ldb;
          s <= S_CB;
        end
        S_CB:   if (cmp_begin_ready) s <= (j_chunk == 16'd0) ? S_CFG : S_TILE;
        S_CFG:  if (acc_cfg_ready) s <= S_TILE;
        S_TILE: if (tile_ready) begin s <= S_TRSP; slices_done <= 1'b0; rd_done <= 1'b0; end
        S_TRSP: if (tile_rsp_valid) begin
          if (tile_rsp_err) err_flags[1] <= 1'b1;
          e_m <= tile_rsp_m; e_n <= tile_rsp_n; e_k <= tile_rsp_k;
          s <= S_ACFG;
        end
        S_ACFG: if (arr_cfg_ready) s <= S_RUN;
        S_RUN:  if (slices_done || s_hs_last) s <= S_CE;
        S_CE:   if (cmp_end_ready) s <= S_RD;
        S_RD:   if (rd_done || arr_m_hs_last) begin
          if (j_chunk == j_nch - 16'd1) slot <= (NUM_SLOTS > 1) ? slot + SLOT_W'(1) : slot;
          jobs_done <= jobs_done + 32'd1;
          s <= S_IDLE;
        end
        default: s <= S_IDLE;
      endcase
    end
  end
endmodule

`default_nettype wire
