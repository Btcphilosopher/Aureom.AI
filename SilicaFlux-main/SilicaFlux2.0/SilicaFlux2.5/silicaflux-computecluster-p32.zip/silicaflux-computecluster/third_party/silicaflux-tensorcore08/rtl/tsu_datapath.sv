// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_datapath
// The tensor datapath of silicaflux_tensor_unit: every block below is reused
// UNMODIFIED; this module only wires them, selects the output path per command
// and taps handshakes for monitoring.  The wiring of the INT32 path is the one
// verified in TENSORCORE 07 tdma_tile_system (328 end-to-end GEMM runs), with
// TC04's destination made a per-command input instead of the constant 3'b001.
//
//   descriptors ─► TC07 tensor_dma_adapter ◄─► SFB2 master (to tsu_bus_gate)
//                   │ fill port + fill_begin/end            ▲ DMA read port + rd_begin/end
//                   ▼                                       │
//   TC03 tensor_operand_buffer ─slices─► TC02 tensor_systolic_array ─rows─► TC04 tensor_acc_subsystem
//        ▲ cmp_begin/end, tile desc          ▲ cfg                              │ osram (INT32)   │ oquant (INT8)
//        └──────────── TC07 tdma_compute_seq (jobs) ──── cfg + sideband ────────┤                 ▼
//                                                                               │     TC05 tensor_quantize
//                                                                               │                 │ tsu_q8_pack
//                                                                               ▼                 ▼
//                                                          TC07 tensor_output_buffer (M04 scratchpad)
//
// cfg_int8 (static during a command): 0 -> TC04 cfg_dest = SRAM, rows go
// straight to the output buffer as INT32 lanes; 1 -> cfg_dest = QUANT, rows go
// through TC05 (per-tensor requantisation, one OPEN descriptor per tile from
// the scheduler) and are packed four INT8 values per 32-bit lane.
//
// FAULT_INJ = 1 adds verification-only fault hooks selected by fi_mode (all
// compiled out with FAULT_INJ = 0, the default):
//   1 FI_OP_ADDR  flip the set-select bit of operand-buffer fill addresses
//                 (writes into a set the DMA does not own -> TC03 OWNER refusal)
//   2 FI_ACC_KTOT force TC04 cfg_k_total to its maximum (STRICT_RANGE refusal)
//   3 FI_OB_ADDR  flip the set bit of output-buffer DMA reads (ownership gate refusal)
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tdma_defs.svh"
`include "tob_defs.svh"
`include "hpc_spm_defs.svh"
`include "sram_defs.svh"
`default_nettype none

module tsu_datapath #(
  parameter int          TILE_M       = 4,
  parameter int          TILE_N       = 4,
  parameter int          NUM_SETS     = 1,
  parameter int          A_SET_BYTES  = 1024,
  parameter int          B_SET_BYTES  = 1024,
  parameter int          A_BANKS      = 4,
  parameter int          B_BANKS      = 2,
  parameter int          TOB_PORT     = `TOB_PORT_1R1W,
  parameter int          O_SETS       = 1,
  parameter int          O_SET_BYTES  = 256,
  parameter int          O_LD         = 16,
  parameter int          O_BANKS      = 2,
  parameter int          O_PORT       = `HPC_SPM_PORT_1RW,
  parameter int          NUM_SLOTS    = 2,
  parameter logic [32:0] MEM_LO       = 33'h0_0000_0000,
  parameter logic [32:0] MEM_HI       = 33'h1_0000_0000,
  parameter int          MAX_OUT      = 4,
  parameter int          LOC_OUT      = 4,
  parameter int          RCAP         = 32,
  parameter int          QDEPTH       = 4,
  parameter int          QUANT_EN     = 0,
  parameter int          FAULT_INJ    = 0,
  parameter int          MEM_BACKEND  = `SRAM_BACKEND_GENERIC,
  localparam int WB     = 4,
  localparam int DW     = 32,
  localparam int MW     = $clog2(TILE_M + 1),
  localparam int NW     = $clog2(TILE_N + 1),
  localparam int RIDW   = (TILE_M > 1) ? $clog2(TILE_M) : 1,
  localparam int SW     = (NUM_SETS > 1) ? $clog2(NUM_SETS) : 1,
  localparam int OSW    = (O_SETS > 1) ? $clog2(O_SETS) : 1,
  localparam int SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1,
  localparam int NPC    = `TDMA_NUM_PC,
  localparam int SATW   = $clog2(TILE_N + 1)
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,           // datapath reset (hard reset AND scheduler soft reset)
  input  wire logic                    cfg_prefetch,
  input  wire logic                    cfg_int8,
  input  wire logic [1:0]              fi_mode,
  // ---------------------------------------------------------- DMA descriptors / completions
  input  wire logic                    desc_valid,
  output logic                         desc_ready,
  input  wire logic [`TDMA_DESC_W-1:0] desc_data,
  output logic                         cpl_valid,
  input  wire logic                    cpl_ready,
  output logic [7:0]                   cpl_id,
  output logic [1:0]                   cpl_kind,
  output logic [3:0]                   cpl_code,
  output logic [2:0]                   cpl_detail,
  output logic [31:0]                  cpl_err_addr,
  output logic [31:0]                  cpl_bytes,
  // ---------------------------------------------------------- compute jobs
  input  wire logic                    job_valid,
  output logic                         job_ready,
  input  wire logic [15:0]             job_tag,
  input  wire logic [MW-1:0]           job_m,
  input  wire logic [NW-1:0]           job_n,
  input  wire logic [16:0]             job_k,
  input  wire logic [39:0]             job_k_total,
  input  wire logic [15:0]             job_n_chunks,
  input  wire logic [15:0]             job_chunk,
  input  wire logic [31:0]             job_lda,
  input  wire logic [31:0]             job_ldb,
  // ---------------------------------------------------------- TC05 descriptors (INT8 output)
  input  wire logic                    tq_desc_valid,
  output logic                         tq_desc_ready,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [255:0]            tq_desc_data,     // unused in a build without TC05
  /* verilator lint_on UNUSEDSIGNAL */
  // ---------------------------------------------------------- SFB2 master
  output logic                         req_valid,
  input  wire logic                    req_ready,
  output logic                         req_write,
  output logic [31:0]                  req_addr,
  output logic [DW-1:0]                req_wdata,
  output logic [WB-1:0]                req_wstrb,
  input  wire logic                    rsp_valid,
  output logic                         rsp_ready,
  input  wire logic [DW-1:0]           rsp_rdata,
  input  wire logic                    rsp_error,
  // ---------------------------------------------------------- status
  output logic                         dma_busy,
  output logic                         cmp_busy,
  output logic [4:0]                   cmp_err,
  output logic                         ev_compute,
  output logic                         tq_idle,
  output logic [NUM_SETS*2-1:0]        op_state,
  output logic [O_SETS*2-1:0]          ob_state,
  output logic [SLOT_W-1:0]            acc_cfg_slot_seen,   // TC04 cfg slot (for the scheduler's slot check)
  output logic                         acc_cfg_hs,
  // ---------------------------------------------------------- monitors (1-cycle pulses)
  output logic                         mon_acc_range,       // TC04 refused a tile: K could overflow ACC_W
  output logic                         mon_acc_cfg,         // TC04 refused a tile for another reason
  output logic                         mon_acc_beat,        // TC04 dropped a malformed partial-sum beat
  output logic                         mon_acc_ovf,         // a committed row carried an overflowed lane
  output logic                         mon_ob_werr,         // output buffer row write failed
  output logic                         mon_ob_gate,         // output buffer gate refused a request
  output logic                         mon_tq_rej,          // TC05 rejected an OPEN descriptor
  output logic                         mon_tq_beat,         // TC05 delivered a beat with an error code
  output logic                         mon_dma_proto,       // the adapter dropped an unsolicited local response
  output logic [SATW-1:0]              sat_inc,             // INT8 elements saturated in this beat
  output logic                         progress,            // any handshake inside the datapath
  input  wire logic                    perf_clear,
  output logic [NPC*32-1:0]            dma_perf_cnt
);
  /* verilator lint_off UNUSEDSIGNAL */
  // ------------------------------------------------------------ adapter <-> TC03
  logic          o_rq_v, o_rq_r, o_rq_we, o_rs_v, o_rs_r, o_rs_e, o_rs_we;
  logic [31:0]   o_rq_a, o_rq_a_fi;
  logic [DW-1:0] o_rq_d, o_rs_d;
  logic [WB-1:0] o_rq_s;
  logic [7:0]    o_rq_t, o_rs_t;
  logic [2:0]    o_rs_c;
  logic          fb_v, fb_r, fe_v, fe_r, cb_v, cb_r, ce_v, ce_r;
  logic [SW-1:0] fill_set, cmp_set;
  // ------------------------------------------------------------ adapter <-> output buffer
  logic          b_rq_v, b_rq_r, b_rq_we, b_rs_v, b_rs_r, b_rs_e, b_rs_we;
  logic [31:0]   b_rq_a, b_rq_a_fi;
  logic [DW-1:0] b_rq_d, b_rs_d;
  logic [WB-1:0] b_rq_s;
  logic [7:0]    b_rq_t, b_rs_t;
  logic [2:0]    b_rs_c;
  logic          rb_v, rb_r, re_v, re_r;
  logic [OSW-1:0] ob_wr_set, ob_rd_set;
  // ------------------------------------------------------------ TC03 tiles / slices
  logic          t_v, t_r, tr_v, tr_e;
  logic [31:0]   t_aa, t_lda, t_ba, t_ldb;
  logic [15:0]   t_mm, t_mn;
  logic [16:0]   t_mk, t_k, tr_k, s_k, s_kg, a_s_k;
  logic [7:0]    t_tag, tr_tag, s_tag;
  logic [3:0]    tr_code;
  logic [MW-1:0] tr_m;
  logic [NW-1:0] tr_n;
  logic          s_valid, s_ready, s_first, s_last, t_busy, t_eidle;
  logic [TILE_M*8-1:0] s_a;
  logic [TILE_N*8-1:0] s_b;
  logic [15:0]   s_m0, s_n0;
  logic [TILE_M-1:0] s_rm;
  logic [TILE_N-1:0] s_cm;
  logic [SW-1:0] s_set;
  logic [`TOB_NUM_EV*8-1:0]  t_ev;
  logic [`TOB_NUM_EV*32-1:0] t_pc;
  logic [A_BANKS-1:0] t_bconf;
  // ------------------------------------------------------------ TC02
  logic          a_cfg_v, a_cfg_r, a_cfg_rej, a_busy, a_done, a_align;
  logic [MW-1:0] a_cfg_m;
  logic [NW-1:0] a_cfg_n;
  logic [16:0]   a_cfg_k;
  logic          m_valid, m_ready, m_last;
  logic [RIDW-1:0] m_row;
  logic [TILE_N*32-1:0] m_data;
  logic [TILE_N-1:0] m_cm;
  logic [39:0]   p_busy, p_issue, p_su, p_se, p_mac, p_pad;
  // ------------------------------------------------------------ TC04
  logic          c_cfg_v, c_cfg_r, c_cfg_rej, c_err, c_idle, c_cmt, c_cmt_ovf, c_cmt_clip, c_cmt_err;
  logic [2:0]    c_rej_code, c_err_code;
  logic [7:0]    c_err_sticky;
  logic [SLOT_W-1:0] c_slot, ps_slot, o_slot, c_cmt_slot;
  logic [15:0]   c_tag, ps_tag, ps_chunk, c_nch, o_tag, c_cmt_tag;
  logic [MW-1:0] c_m;
  logic [NW-1:0] c_n;
  logic [39:0]   c_kt, c_kt_fi;
  logic [16:0]   ps_ck;
  logic          osram_v, osram_r, oquant_v, oquant_r, odma_v;
  logic [RIDW-1:0] o_row;
  logic          o_last, o_err;
  logic [TILE_N-1:0] o_cm, o_ovf, o_clip;
  logic [TILE_N*32-1:0] o_wide, o_data;
  logic [NUM_SLOTS*2-1:0] c_slot_state;
  logic [tensor_acc_pkg::NPERF*$clog2(TILE_N+1)-1:0] c_ev;
  logic [tensor_acc_pkg::NPERF*40-1:0] c_perf;
  logic          c_hc_r, c_hr_v, c_hr_vld, c_st_en, c_st_rr, c_st_rrdy, c_st_wr, c_st_wrdy;
  logic [2:0]    c_hr_st;
  logic [TILE_N*32-1:0] c_hr_d;
  logic [TILE_N-1:0] c_hr_ovf;
  logic [15:0]   c_hr_nc;
  logic [39:0]   c_hr_ka;
  // ------------------------------------------------------------ output buffer
  logic          ob_in_v, ob_in_r, ob_in_last, ob_in_err;
  logic [RIDW-1:0] ob_in_row;
  logic [TILE_N-1:0] ob_in_cm, ob_in_ovf;
  logic [TILE_N*32-1:0] ob_in_d;
  logic [15:0]   ob_in_tag;
  logic          ob_ev_wr, ob_ev_rd, ob_ev_ref, ob_ev_werr, ob_ev_wait;
  logic [O_SETS*16-1:0] ob_tag;
  logic [O_SETS*MW-1:0] ob_rows;
  logic [O_SETS*NW-1:0] ob_cols;
  logic [O_SETS*3-1:0]  ob_flags;
  logic [1:0]    ob_conflict;
  // ------------------------------------------------------------ adapter status
  logic [2:0]    ld_st_u, st_st_u;
  logic [7:0]    ld_id_u, st_id_u;
  logic          ev_cpl_u, ev_proto;
  logic [7:0]    ev_cpl_id_u;
  logic [$clog2((MAX_OUT < 2) ? 2 : MAX_OUT):0] sfb_out_u;
  logic [$clog2((LOC_OUT < 2) ? 2 : LOC_OUT):0] op_out_u, ob_out_u;
  logic [31:0]   jobs_done;
  // ------------------------------------------------------------ TC05
  logic          q_out_v, q_out_r, q_out_last, q_out_err;
  logic [15:0]   q_out_tag;
  logic [SLOT_W-1:0] q_out_ctx;
  logic [RIDW-1:0] q_out_row;
  logic [TILE_N-1:0] q_out_cm, q_out_sat, q_out_iovf;
  logic [TILE_N*8-1:0] q_out_q8;
  logic          q_desc_rej;
  /* verilator lint_on UNUSEDSIGNAL */

  // ============================================================ fault injection hooks (verification only)
  logic [1:0] fi;
  assign fi = (FAULT_INJ != 0) ? fi_mode : 2'd0;
  assign o_rq_a_fi = (fi == 2'd1) ? (o_rq_a ^ 32'(A_SET_BYTES)) : o_rq_a;
  assign b_rq_a_fi = (fi == 2'd3) ? (b_rq_a ^ 32'(O_SET_BYTES)) : b_rq_a;
  assign c_kt_fi   = (fi == 2'd2) ? 40'hFF_FFFF_FFFF : c_kt;

  // ============================================================ DMA adapter (TC07, unmodified)
  tensor_dma_adapter #(
    .WB(WB), .NUM_SETS(NUM_SETS), .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES), .OP_BASE(32'h0),
    .O_SETS(O_SETS), .O_SET_BYTES(O_SET_BYTES), .OB_BASE(32'h0), .MEM_LO(MEM_LO), .MEM_HI(MEM_HI),
    .MAX_OUT(MAX_OUT), .LOC_OUT(LOC_OUT), .RCAP(RCAP), .QDEPTH(QDEPTH), .CPL_DEPTH(4), .TAG_W(8), .CNT_W(32)
  ) u_dma (
    .clk(clk), .rst_n(rst_n), .cfg_prefetch(cfg_prefetch),
    .desc_valid(desc_valid), .desc_ready(desc_ready), .desc_data(desc_data),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_id(cpl_id), .cpl_kind(cpl_kind), .cpl_code(cpl_code),
    .cpl_detail(cpl_detail), .cpl_err_addr(cpl_err_addr), .cpl_bytes(cpl_bytes),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr),
    .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .op_req_valid(o_rq_v), .op_req_ready(o_rq_r), .op_req_we(o_rq_we), .op_req_addr(o_rq_a),
    .op_req_wdata(o_rq_d), .op_req_wstrb(o_rq_s), .op_req_tag(o_rq_t),
    .op_rsp_valid(o_rs_v), .op_rsp_ready(o_rs_r), .op_rsp_rdata(o_rs_d), .op_rsp_err(o_rs_e),
    .op_rsp_err_code(o_rs_c), .op_rsp_we(o_rs_we), .op_rsp_tag(o_rs_t),
    .op_fill_begin_valid(fb_v), .op_fill_begin_ready(fb_r), .op_fill_end_valid(fe_v), .op_fill_end_ready(fe_r),
    .op_fill_set(fill_set), .op_set_state(op_state),
    .ob_req_valid(b_rq_v), .ob_req_ready(b_rq_r), .ob_req_we(b_rq_we), .ob_req_addr(b_rq_a),
    .ob_req_wdata(b_rq_d), .ob_req_wstrb(b_rq_s), .ob_req_tag(b_rq_t),
    .ob_rsp_valid(b_rs_v), .ob_rsp_ready(b_rs_r), .ob_rsp_rdata(b_rs_d), .ob_rsp_err(b_rs_e),
    .ob_rsp_err_code(b_rs_c), .ob_rsp_we(b_rs_we), .ob_rsp_tag(b_rs_t),
    .ob_rd_begin_valid(rb_v), .ob_rd_begin_ready(rb_r), .ob_rd_end_valid(re_v), .ob_rd_end_ready(re_r),
    .ob_rd_set(ob_rd_set), .ob_set_state(ob_state),
    .busy(dma_busy), .ld_state(ld_st_u), .st_state(st_st_u), .ld_id(ld_id_u), .st_id(st_id_u),
    .sfb_outstanding(sfb_out_u), .op_outstanding(op_out_u), .ob_outstanding(ob_out_u),
    .ev_cpl(ev_cpl_u), .ev_cpl_id(ev_cpl_id_u), .ev_proto(ev_proto),
    .perf_clear(perf_clear), .perf_cnt(dma_perf_cnt));

  // ============================================================ TENSORCORE 03 (unmodified)
  tensor_operand_buffer #(
    .ARRAY_ROWS(TILE_M), .ARRAY_COLS(TILE_N), .WORD_BYTES(WB), .A_SET_BYTES(A_SET_BYTES), .B_SET_BYTES(B_SET_BYTES),
    .A_BANKS(A_BANKS), .B_BANKS(B_BANKS), .A_REPL(1), .NUM_SETS(NUM_SETS), .SET_MAP(`TOB_SET_SHARED),
    .PORT_MODE(TOB_PORT), .READ_LATENCY(1), .A_STAGE(2), .B_STAGE(4), .WR_STARVE_LIMIT(8), .ADDR_W(32),
    .DMA_BASE(64'h0), .IDX_W(16), .K_W(17), .TAG_W(8), .DMA_RSP_DEPTH(4), .PERF_EN(1), .CNT_W(32),
    .BACKEND(MEM_BACKEND)
  ) u_tob (
    .clk(clk), .rst_n(rst_n),
    .dma_req_valid(o_rq_v), .dma_req_ready(o_rq_r), .dma_req_we(o_rq_we), .dma_req_addr(o_rq_a_fi),
    .dma_req_wdata(o_rq_d), .dma_req_wstrb(o_rq_s), .dma_req_tag(o_rq_t),
    .dma_rsp_valid(o_rs_v), .dma_rsp_ready(o_rs_r), .dma_rsp_rdata(o_rs_d), .dma_rsp_err(o_rs_e),
    .dma_rsp_err_code(o_rs_c), .dma_rsp_we(o_rs_we), .dma_rsp_tag(o_rs_t),
    .fill_begin_valid(fb_v), .fill_begin_ready(fb_r), .fill_end_valid(fe_v), .fill_end_ready(fe_r),
    .cmp_begin_valid(cb_v), .cmp_begin_ready(cb_r), .cmp_end_valid(ce_v), .cmp_end_ready(ce_r),
    .fill_set(fill_set), .cmp_set(cmp_set), .set_state(op_state),
    .tile_valid(t_v), .tile_ready(t_r), .tile_a_addr(t_aa), .tile_lda(t_lda), .tile_b_addr(t_ba),
    .tile_ldb(t_ldb), .tile_m0(16'd0), .tile_n0(16'd0), .tile_k0(17'd0), .tile_mat_m(t_mm), .tile_mat_n(t_mn),
    .tile_mat_k(t_mk), .tile_k(t_k), .tile_tag(t_tag),
    .tile_rsp_valid(tr_v), .tile_rsp_ready(1'b1), .tile_rsp_tag(tr_tag), .tile_rsp_err(tr_e),
    .tile_rsp_code(tr_code), .tile_rsp_m(tr_m), .tile_rsp_n(tr_n), .tile_rsp_k(tr_k),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .s_kg(s_kg), .s_m0(s_m0), .s_n0(s_n0),
    .s_row_mask(s_rm), .s_col_mask(s_cm), .s_first(s_first), .s_last(s_last), .s_tag(s_tag), .s_set(s_set),
    .busy(t_busy), .engine_idle(t_eidle), .ev_inc(t_ev), .ev_bank_conflict_a(t_bconf),
    .perf_clear(perf_clear), .perf_cnt(t_pc));

  // ============================================================ TENSORCORE 02 (unmodified)
  tensor_systolic_array #(
    .ARRAY_ROWS(TILE_M), .ARRAY_COLS(TILE_N), .DATA_WIDTH(8), .ACC_WIDTH(32), .K_WIDTH(17),
    .MUL_PIPE(0), .CHECK_ALIGN(1), .PERF_EN(1)
  ) u_arr (
    .clk(clk), .rst_n(rst_n),
    .cfg_valid(a_cfg_v), .cfg_ready(a_cfg_r), .cfg_m(a_cfg_m), .cfg_n(a_cfg_n), .cfg_k(a_cfg_k), .cfg_reject(a_cfg_rej),
    .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(a_s_k), .stall_i(1'b0),
    .m_valid(m_valid), .m_ready(m_ready), .m_row(m_row), .m_data(m_data), .m_col_mask(m_cm), .m_last(m_last),
    .busy(a_busy), .tile_done(a_done), .align_err(a_align),
    .perf_busy(p_busy), .perf_issue(p_issue), .perf_stall_up(p_su), .perf_stall_ext(p_se),
    .perf_mac(p_mac), .perf_pad(p_pad));

  // ============================================================ TENSORCORE 04 (unmodified)
  tensor_acc_subsystem #(
    .ROWS(TILE_M), .COLS(TILE_N), .DATA_W(8), .PSUM_W(32), .ACC_W(32), .OUT_W(32), .BIAS_W(32),
    .NUM_TILES(NUM_SLOTS), .TAG_W(16), .CHUNK_W(16), .KC_W(17), .KTOT_W(40), .RD_LAT(1),
    .OVF_POLICY(tensor_acc_pkg::OVF_SATURATE), .STRICT_RANGE(1), .PSUM_GUARD(1),
    .OFIFO_DEPTH(4), .HFIFO_DEPTH(4), .PERF_EN(1), .PERF_W(40)
  ) u_acc (
    .clk(clk), .rst_n(rst_n),
    .cfg_valid(c_cfg_v), .cfg_ready(c_cfg_r), .cfg_slot(c_slot), .cfg_tag(c_tag), .cfg_m(c_m),
    .cfg_n(c_n), .cfg_k_total(c_kt_fi), .cfg_n_chunks(c_nch), .cfg_bias_en(1'b0),
    .cfg_bias({TILE_N*32{1'b0}}), .cfg_dest(cfg_int8 ? 3'b010 : 3'b001), .cfg_reject(c_cfg_rej),
    .cfg_reject_code(c_rej_code),
    .ps_valid(m_valid), .ps_ready(m_ready), .ps_slot(ps_slot), .ps_tag(ps_tag), .ps_chunk(ps_chunk),
    .ps_chunk_k(ps_ck), .ps_row(m_row), .ps_data(m_data), .ps_col_mask(m_cm), .ps_last(m_last),
    .hc_valid(1'b0), .hc_ready(c_hc_r), .hc_op(2'd0), .hc_slot({SLOT_W{1'b0}}), .hc_row({RIDW{1'b0}}),
    .hc_wdata({TILE_N*32{1'b0}}),
    .hr_valid(c_hr_v), .hr_ready(1'b1), .hr_status(c_hr_st), .hr_data(c_hr_d), .hr_ovf(c_hr_ovf),
    .hr_vld(c_hr_vld), .hr_nchunk(c_hr_nc), .hr_kacc(c_hr_ka),
    .st_rd_block(1'b0), .st_wr_block(1'b0),
    .osram_valid(osram_v), .osram_ready(osram_r), .oquant_valid(oquant_v), .oquant_ready(oquant_r),
    .odma_valid(odma_v), .odma_ready(1'b1),
    .o_tag(o_tag), .o_slot(o_slot), .o_row(o_row), .o_last(o_last), .o_col_mask(o_cm), .o_wide(o_wide),
    .o_data(o_data), .o_ovf(o_ovf), .o_clip(o_clip), .o_err(o_err),
    .cmt_done(c_cmt), .cmt_slot(c_cmt_slot), .cmt_tag(c_cmt_tag), .cmt_ovf(c_cmt_ovf), .cmt_clip(c_cmt_clip),
    .cmt_err(c_cmt_err), .slot_state(c_slot_state), .idle(c_idle), .err_pulse(c_err), .err_code(c_err_code),
    .err_sticky(c_err_sticky), .perf_clr(perf_clear), .ev_inc(c_ev), .perf_o(c_perf),
    .st_en(c_st_en), .st_rd_req(c_st_rr), .st_rd_ready(c_st_rrdy), .st_wr_req(c_st_wr),
    .st_wr_ready(c_st_wrdy));

  // ============================================================ output conversion (TC05, unmodified) + packing
  if (QUANT_EN != 0) begin : g_quant
    /* verilator lint_off UNUSEDSIGNAL */
    logic [3:0]  q_rej_code;               // the sticky / pulse are enough: any reject is an error
    logic        q_desc_ok, q_p_ready, q_p_err;
    logic [1:0]  q_p_err_code;
    logic [31:0] q_out_m, q_out_ch0;
    logic [3:0]  q_out_fmt;
    logic [TILE_N*32-1:0] q_out_data;
    logic [2:0]  q_out_err_code;
    logic [NUM_SLOTS-1:0] q_ctx_open, q_ctx_poison;
    logic [15:0] q_desc_sticky;
    logic [7:0]  q_beat_sticky;
    logic [3:0]  q_param_sticky;
    logic [tensor_quantize_pkg::NPERF*32-1:0] q_perf;
    /* verilator lint_on UNUSEDSIGNAL */
    tensor_quantize #(
      .ROWS(TILE_M), .COLS(TILE_N), .IN_W(32), .NUM_CTX(NUM_SLOTS), .NUM_GRP(1), .ASYM_EN(0),
      .OFIFO_DEPTH(4), .PERF_EN(1), .PERF_W(32)
    ) u_tq (
      .clk(clk), .rst_n(rst_n),
      .desc_valid(tq_desc_valid), .desc_ready(tq_desc_ready), .desc_data(tq_desc_data),
      .desc_ok(q_desc_ok), .desc_rej(q_desc_rej), .desc_rej_code(q_rej_code),
      .p_valid(1'b0), .p_ready(q_p_ready), .p_grp(16'd0), .p_lane_mask({TILE_N{1'b0}}), .p_fmask(5'd0),
      .p_bias({TILE_N*32{1'b0}}), .p_mult({TILE_N*32{1'b0}}), .p_shift({TILE_N*6{1'b0}}),
      .p_zp({TILE_N*32{1'b0}}), .p_cs({TILE_N*32{1'b0}}), .p_err(q_p_err), .p_err_code(q_p_err_code),
      .in_valid(oquant_v), .in_ready(oquant_r), .in_ctx(o_slot), .in_tag(o_tag), .in_row(o_row),
      .in_col_mask(o_cm), .in_last(o_last), .in_data(o_wide), .in_ovf(o_ovf), .in_err(o_err),
      .out_valid(q_out_v), .out_ready(q_out_r), .out_tag(q_out_tag), .out_ctx(q_out_ctx), .out_row(q_out_row),
      .out_m(q_out_m), .out_ch0(q_out_ch0), .out_col_mask(q_out_cm), .out_last(q_out_last), .out_fmt(q_out_fmt),
      .out_data(q_out_data), .out_q8(q_out_q8), .out_sat(q_out_sat), .out_iovf(q_out_iovf),
      .out_err(q_out_err), .out_err_code(q_out_err_code),
      .ctx_open(q_ctx_open), .ctx_poison(q_ctx_poison), .idle(tq_idle), .desc_err_sticky(q_desc_sticky),
      .beat_err_sticky(q_beat_sticky), .param_err_sticky(q_param_sticky), .perf_clr(perf_clear), .perf_o(q_perf));
  end else begin : g_noquant
    assign tq_desc_ready = 1'b0;
    assign oquant_r      = 1'b1;     // never selected: cfg_int8 is 0 in a build without quantisation
    assign q_out_v = 1'b0; assign q_out_tag = '0; assign q_out_ctx = '0; assign q_out_row = '0;
    assign q_out_cm = '0; assign q_out_last = 1'b0; assign q_out_q8 = '0; assign q_out_sat = '0;
    assign q_out_iovf = '0; assign q_out_err = 1'b0; assign q_desc_rej = 1'b0; assign tq_idle = 1'b1;
  end

  logic [TILE_N*32-1:0] pk_data;
  logic [TILE_N-1:0]    pk_mask;
  tsu_q8_pack #(.COLS(TILE_N)) u_pack (.q8(q_out_q8), .col_mask(q_out_cm), .data(pk_data), .lane_mask(pk_mask));

  // per-command output path select (static while a command runs)
  assign ob_in_v    = cfg_int8 ? q_out_v    : osram_v;
  assign ob_in_row  = cfg_int8 ? q_out_row  : o_row;
  assign ob_in_cm   = cfg_int8 ? pk_mask    : o_cm;
  assign ob_in_d    = cfg_int8 ? pk_data    : o_data;
  assign ob_in_last = cfg_int8 ? q_out_last : o_last;
  assign ob_in_tag  = cfg_int8 ? q_out_tag  : o_tag;
  assign ob_in_err  = cfg_int8 ? q_out_err  : o_err;
  assign ob_in_ovf  = cfg_int8 ? '0         : o_ovf;
  assign osram_r    = cfg_int8 ? 1'b1       : ob_in_r;
  assign q_out_r    = cfg_int8 ? ob_in_r    : 1'b1;

  // ============================================================ output buffer (TC07, unmodified)
  tensor_output_buffer #(
    .WB(WB), .O_SETS(O_SETS), .O_SET_BYTES(O_SET_BYTES), .TILE_M(TILE_M), .TILE_N(TILE_N), .O_LD(O_LD),
    .NUM_BANKS(O_BANKS), .PORT_MODE(O_PORT), .READ_LATENCY(1), .BACKEND(MEM_BACKEND), .TAG_W(8)
  ) u_ob (
    .clk(clk), .rst_n(rst_n),
    .in_valid(ob_in_v), .in_ready(ob_in_r), .in_row(ob_in_row), .in_col_mask(ob_in_cm), .in_data(ob_in_d),
    .in_last(ob_in_last), .in_tag(ob_in_tag), .in_err(ob_in_err), .in_ovf(ob_in_ovf),
    .d_req_valid(b_rq_v), .d_req_ready(b_rq_r), .d_req_we(b_rq_we), .d_req_addr(b_rq_a_fi),
    .d_req_wdata(b_rq_d), .d_req_wstrb(b_rq_s), .d_req_tag(b_rq_t),
    .d_rsp_valid(b_rs_v), .d_rsp_ready(b_rs_r), .d_rsp_rdata(b_rs_d), .d_rsp_err(b_rs_e),
    .d_rsp_err_code(b_rs_c), .d_rsp_we(b_rs_we), .d_rsp_tag(b_rs_t),
    .rd_begin_valid(rb_v), .rd_begin_ready(rb_r), .rd_end_valid(re_v), .rd_end_ready(re_r),
    .wr_set(ob_wr_set), .rd_set(ob_rd_set), .set_state(ob_state), .set_tag(ob_tag), .set_rows(ob_rows),
    .set_cols(ob_cols), .set_flags(ob_flags),
    .ev_wr(ob_ev_wr), .ev_rd(ob_ev_rd), .ev_conflict(ob_conflict), .ev_refused(ob_ev_ref),
    .ev_wr_err(ob_ev_werr), .ev_wr_wait(ob_ev_wait));

  // ============================================================ compute sequencer (TC07, unmodified)
  tdma_compute_seq #(.TILE_M(TILE_M), .TILE_N(TILE_N), .NUM_SLOTS(NUM_SLOTS)) u_seq (
    .clk(clk), .rst_n(rst_n),
    .job_valid(job_valid), .job_ready(job_ready), .job_tag(job_tag), .job_m(job_m), .job_n(job_n), .job_k(job_k),
    .job_k_total(job_k_total), .job_n_chunks(job_n_chunks), .job_chunk(job_chunk),
    .job_a_addr(32'd0), .job_lda(job_lda), .job_b_addr(32'd0), .job_ldb(job_ldb),
    .cmp_begin_valid(cb_v), .cmp_begin_ready(cb_r), .cmp_end_valid(ce_v), .cmp_end_ready(ce_r),
    .tile_valid(t_v), .tile_ready(t_r), .tile_a_addr(t_aa), .tile_lda(t_lda), .tile_b_addr(t_ba), .tile_ldb(t_ldb),
    .tile_mat_m(t_mm), .tile_mat_n(t_mn), .tile_mat_k(t_mk), .tile_k(t_k), .tile_tag(t_tag),
    .tile_rsp_valid(tr_v), .tile_rsp_err(tr_e), .tile_rsp_m(tr_m), .tile_rsp_n(tr_n), .tile_rsp_k(tr_k),
    .s_hs_last(s_valid && s_ready && s_last),
    .arr_cfg_valid(a_cfg_v), .arr_cfg_ready(a_cfg_r), .arr_cfg_m(a_cfg_m), .arr_cfg_n(a_cfg_n), .arr_cfg_k(a_cfg_k),
    .arr_cfg_reject(a_cfg_rej), .arr_align_err(a_align), .arr_m_hs_last(m_valid && m_ready && m_last),
    .acc_cfg_valid(c_cfg_v), .acc_cfg_ready(c_cfg_r), .acc_cfg_slot(c_slot), .acc_cfg_tag(c_tag),
    .acc_cfg_m(c_m), .acc_cfg_n(c_n), .acc_cfg_k_total(c_kt), .acc_cfg_n_chunks(c_nch), .acc_cfg_reject(c_cfg_rej),
    .ps_slot(ps_slot), .ps_tag(ps_tag), .ps_chunk(ps_chunk), .ps_chunk_k(ps_ck), .acc_err_pulse(c_err),
    .busy(cmp_busy), .err_flags(cmp_err), .jobs_done(jobs_done), .ev_compute(ev_compute));

  // ============================================================ monitors
  logic beat_hs;
  assign beat_hs       = (osram_v && osram_r) || (oquant_v && oquant_r);
  assign mon_acc_range = c_cfg_rej && (c_rej_code == tensor_acc_pkg::CR_RANGE);
  assign mon_acc_cfg   = c_cfg_rej && (c_rej_code != tensor_acc_pkg::CR_RANGE);
  assign mon_acc_beat  = c_err;
  assign mon_acc_ovf   = beat_hs && (|(o_ovf & o_cm));
  assign mon_ob_werr   = ob_ev_werr;
  assign mon_ob_gate   = ob_ev_ref;
  assign mon_tq_rej    = q_desc_rej;
  assign mon_tq_beat   = q_out_v && q_out_r && q_out_err;
  assign mon_dma_proto = ev_proto;
  assign acc_cfg_slot_seen = c_slot;
  assign acc_cfg_hs    = c_cfg_v && c_cfg_r;

  always_comb begin
    sat_inc = '0;
    if (q_out_v && q_out_r)
      for (int j = 0; j < TILE_N; j++) sat_inc = sat_inc + {{(SATW-1){1'b0}}, q_out_sat[j] & q_out_cm[j]};
  end

  assign progress = (req_valid && req_ready) || (rsp_valid && rsp_ready) || (cpl_valid && cpl_ready) ||
                    (o_rq_v && o_rq_r) || (s_valid && s_ready) || (m_valid && m_ready) || ob_ev_wr || ob_ev_rd ||
                    (job_valid && job_ready) || (desc_valid && desc_ready) || (q_out_v && q_out_r) ||
                    (tq_desc_valid && tq_desc_ready) || beat_hs;

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n && odma_v) $error("tsu_datapath: unexpected TC04 DMA beat");
  always_ff @(posedge clk) if (rst_n && QUANT_EN == 0 && oquant_v) $error("tsu_datapath: TC04 QUANT beat without TC05");
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
