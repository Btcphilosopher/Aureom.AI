// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_bus_gate
// SFB2 quiesce gate between the tensor DMA adapter (upstream master u_*) and
// the unit's external SFB2 master port (downstream d_*).
//
// Normal operation (q_req = 0): transparent, zero cycles, both channels.
// Quiesce (q_req = 1): no NEW request reaches the fabric.  A request that is
//   already presented downstream and not yet accepted keeps being presented
//   until it is accepted (SFB2 R2: no cancellation).  Responses keep flowing
//   upstream.  `quiesced` rises once nothing is presented and every accepted
//   transaction has been answered; only then may the scheduler reset the
//   adapter (the fabric then holds no transaction of this master, so no stale
//   response can reach the freshly reset adapter, and no request was withdrawn
//   from the fabric's point of view).
// Paths: d_req_valid = u_req_valid & pass, where `pass` is registered state
// only (R3 holds: no dependence on d_req_ready); u_req_ready = d_req_ready & pass.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tsu_bus_gate #(
  parameter int DW    = 32,
  parameter int OUT_W = 6          // outstanding counter width (>= log2(MAX_OUT) + 2)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             q_req,
  output logic                  quiesced,
  output logic [OUT_W-1:0]      outstanding,
  output logic                  ev_unsolicited,   // a response with nothing outstanding (fabric fault), dropped
  // upstream (adapter)
  input  wire logic             u_req_valid,
  output logic                  u_req_ready,
  input  wire logic             u_req_write,
  input  wire logic [31:0]      u_req_addr,
  input  wire logic [DW-1:0]    u_req_wdata,
  input  wire logic [DW/8-1:0]  u_req_wstrb,
  output logic                  u_rsp_valid,
  input  wire logic             u_rsp_ready,
  output logic [DW-1:0]         u_rsp_rdata,
  output logic                  u_rsp_error,
  // downstream (fabric)
  output logic                  d_req_valid,
  input  wire logic             d_req_ready,
  output logic                  d_req_write,
  output logic [31:0]           d_req_addr,
  output logic [DW-1:0]         d_req_wdata,
  output logic [DW/8-1:0]       d_req_wstrb,
  input  wire logic             d_rsp_valid,
  output logic                  d_rsp_ready,
  input  wire logic [DW-1:0]    d_rsp_rdata,
  input  wire logic             d_rsp_error
);
  logic             held_q, q_q, pass;
  logic [OUT_W-1:0] out_q;
  logic             unsol;

  // q_q: registered quiesce request; held_q: a request was presented and not accepted
  assign pass = !q_q || held_q;

  assign d_req_valid = u_req_valid && pass;
  assign u_req_ready = d_req_ready && pass;
  assign d_req_write = u_req_write;
  assign d_req_addr  = u_req_addr;
  assign d_req_wdata = u_req_wdata;
  assign d_req_wstrb = u_req_wstrb;

  // A response with nothing outstanding is a fabric protocol fault (R5): it is
  // absorbed here and flagged instead of being delivered to the adapter.
  assign unsol       = d_rsp_valid && (out_q == '0);
  assign u_rsp_valid = d_rsp_valid && !unsol;
  assign u_rsp_rdata = d_rsp_rdata;
  assign u_rsp_error = d_rsp_error;
  assign d_rsp_ready = unsol ? 1'b1 : u_rsp_ready;
  assign ev_unsolicited = unsol;

  wire acc = d_req_valid && d_req_ready;
  wire ret = d_rsp_valid && d_rsp_ready && !unsol;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      held_q <= 1'b0; q_q <= 1'b0; out_q <= '0; quiesced <= 1'b0;
    end else begin
      q_q    <= q_req;
      held_q <= d_req_valid && !d_req_ready;
      case ({acc, ret})
        2'b10:   out_q <= out_q + 1'b1;
        2'b01:   out_q <= out_q - 1'b1;
        default: out_q <= out_q;
      endcase
      // quiesced: the request is registered, nothing is presented, nothing is
      // in flight (next-state view, so the flag is exact at the next edge)
      quiesced <= q_req && q_q && !(d_req_valid && !d_req_ready) &&
                  ((acc ? out_q + OUT_W'(1) : out_q) - OUT_W'(ret)) == '0;
    end
  end
  assign outstanding = out_q;

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n && acc && (out_q == {OUT_W{1'b1}}))
    $error("tsu_bus_gate: outstanding counter overflow");
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
