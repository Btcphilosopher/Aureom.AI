// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_regs
// Register page of silicaflux_tensor_unit on the SilicaFlux-V register bus
// (rb_sel one-cycle strobe with rb_we / rb_addr[11:0] / rb_wdata; rb_rdata and
// rb_err answered combinationally in the strobe cycle; side effects at the end
// of the strobe cycle) -- the contract of DataFabric dma_control_regs and of
// HPC Module 06 hpc_cq_mmio, whose register model this page follows:
//   * staging words DESC0..11, then DOORBELL = exactly one command-queue push
//     (refused with rb_err while the queue is full: nothing happens);
//   * CPL0..5 = head completion record, CPL_POP = exactly one pop (refused if
//     there is none);
//   * rb_err for unmapped / misaligned offsets and writes to read-only
//     registers, always without side effect.  DOORBELL / CPL_POP read as 0.
// Map: rtl/tsu_defs.svh (TSU_R_*).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tsu_defs.svh"
`default_nettype none

module tsu_regs #(
  parameter int          NPC      = `TSU_NUM_PC,
  parameter int          DPC      = 18,
  parameter logic [31:0] INFO     = 32'd0,
  parameter logic [31:0] CAPS     = 32'd0,
  parameter logic [31:0] OPBUF    = 32'd0,
  parameter logic [31:0] MEM_LO   = 32'd0,
  parameter logic [31:0] MEM_LAST = 32'hFFFF_FFFF,
  parameter logic [31:0] KMAX     = 32'd131071
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // register bus
  input  wire logic                    rb_sel,
  input  wire logic                    rb_we,
  input  wire logic [11:0]             rb_addr,
  input  wire logic [31:0]             rb_wdata,
  output logic [31:0]                  rb_rdata,
  output logic                         rb_err,
  // command queue push
  output logic                         cq_in_valid,
  input  wire logic                    cq_in_ready,
  output logic [`TSU_DESC_W-1:0]       cq_in_data,
  // completion queue head
  input  wire logic                    cpl_valid,
  output logic                         cpl_pop,
  input  wire logic [`TSU_CPL_W-1:0]   cpl_data,
  // control
  output logic                         ctrl_err_cont,
  output logic                         ctrl_err_clear,
  output logic                         ctrl_perf_clear,
  output logic                         ctrl_abort,
  // status
  input  wire logic [31:0]             status,
  input  wire logic                    ev_irq,
  input  wire logic                    ev_err,
  input  wire logic                    ev_done,
  output logic                         irq,
  // counters
  input  wire logic [NPC*32-1:0]       perf_cnt,
  input  wire logic [DPC*32-1:0]       dma_perf_cnt
);
  logic [31:0] desc_q [`TSU_DESC_WORDS];
  logic        err_cont_q;
  logic [2:0]  int_en_q, int_st_q;
  logic [31:0] submitted_q;

  wire wr = rb_sel && rb_we;
  wire rd = rb_sel && !rb_we;
  wire aligned = (rb_addr[1:0] == 2'b00);

  // ------------------------------------------------------------ decode
  logic        is_desc, is_cpl, is_perf, is_dperf;
  logic [3:0]  desc_i;
  logic [2:0]  cpl_i;
  logic [7:0]  perf_i;
  assign desc_i  = 4'((rb_addr - `TSU_R_DESC0) >> 2);
  assign cpl_i   = 3'((rb_addr - `TSU_R_CPL0) >> 2);
  assign perf_i  = 8'((rb_addr - `TSU_R_PERF0) >> 2);
  assign is_desc  = aligned && rb_addr >= `TSU_R_DESC0 && rb_addr < `TSU_R_DESC0 + 12'(4 * `TSU_DESC_WORDS);
  assign is_cpl   = aligned && rb_addr >= `TSU_R_CPL0 && rb_addr < `TSU_R_CPL0 + 12'(4 * `TSU_CPL_WORDS);
  assign is_perf  = aligned && rb_addr >= `TSU_R_PERF0 && rb_addr < `TSU_R_PERF0 + 12'(4 * NPC);
  assign is_dperf = aligned && rb_addr >= `TSU_R_DMA_PERF0 && rb_addr < `TSU_R_DMA_PERF0 + 12'(4 * DPC);

  logic [7:0] dperf_i;
  assign dperf_i = 8'((rb_addr - `TSU_R_DMA_PERF0) >> 2);

  wire a_doorbell = aligned && rb_addr == `TSU_R_DOORBELL;
  wire a_cpl_pop  = aligned && rb_addr == `TSU_R_CPL_POP;
  wire a_ctrl     = aligned && rb_addr == `TSU_R_CTRL;
  wire a_inten    = aligned && rb_addr == `TSU_R_INT_ENABLE;
  wire a_intst    = aligned && rb_addr == `TSU_R_INT_STATUS;
  wire a_ro       = aligned && (rb_addr == `TSU_R_ID || rb_addr == `TSU_R_INFO || rb_addr == `TSU_R_CAPS ||
                                rb_addr == `TSU_R_OPBUF || rb_addr == `TSU_R_MEM_LO || rb_addr == `TSU_R_MEM_LAST ||
                                rb_addr == `TSU_R_STATUS || rb_addr == `TSU_R_SUBMITTED || rb_addr == `TSU_R_KMAX ||
                                is_cpl || is_perf || is_dperf);
  wire a_rw       = is_desc || a_ctrl || a_inten || a_intst;
  wire a_wo       = a_doorbell || a_cpl_pop;

  // ------------------------------------------------------------ read data / error
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_sel) begin
      if (rd) begin
        if (is_desc)                         rb_rdata = desc_q[desc_i];
        else if (is_cpl)                     rb_rdata = cpl_valid ? cpl_data[32*cpl_i +: 32] : 32'd0;
        else if (is_perf)                    rb_rdata = perf_cnt[32*perf_i +: 32];
        else if (is_dperf)                   rb_rdata = dma_perf_cnt[32*dperf_i +: 32];
        else if (!aligned)                   rb_err   = 1'b1;
        else case (rb_addr)
          `TSU_R_ID:         rb_rdata = `TSU_ID_VALUE;
          `TSU_R_INFO:       rb_rdata = INFO;
          `TSU_R_CAPS:       rb_rdata = CAPS;
          `TSU_R_OPBUF:      rb_rdata = OPBUF;
          `TSU_R_MEM_LO:     rb_rdata = MEM_LO;
          `TSU_R_MEM_LAST:   rb_rdata = MEM_LAST;
          `TSU_R_CTRL:       rb_rdata = {31'd0, err_cont_q};
          `TSU_R_STATUS:     rb_rdata = status;
          `TSU_R_INT_ENABLE: rb_rdata = {29'd0, int_en_q};
          `TSU_R_INT_STATUS: rb_rdata = {29'd0, int_st_q};
          `TSU_R_SUBMITTED:  rb_rdata = submitted_q;
          `TSU_R_KMAX:       rb_rdata = KMAX;
          `TSU_R_DOORBELL, `TSU_R_CPL_POP: rb_rdata = 32'd0;
          default:           rb_err   = 1'b1;
        endcase
      end else begin
        if (a_ro || !(a_rw || a_wo))          rb_err = 1'b1;     // read-only, unmapped or misaligned
        else if (a_doorbell && !cq_in_ready)  rb_err = 1'b1;     // queue full: refused, nothing happens
        else if (a_cpl_pop && !cpl_valid)     rb_err = 1'b1;     // no record: refused
      end
    end
  end

  // ------------------------------------------------------------ side effects
  assign cq_in_valid = wr && a_doorbell && cq_in_ready;
  assign cpl_pop     = wr && a_cpl_pop && cpl_valid;
  always_comb for (int i = 0; i < `TSU_DESC_WORDS; i++) cq_in_data[32*i +: 32] = desc_q[i];

  assign ctrl_err_cont   = err_cont_q;
  assign ctrl_err_clear  = wr && a_ctrl && rb_wdata[`TSU_CTRL_ERR_CLEAR];
  assign ctrl_perf_clear = wr && a_ctrl && rb_wdata[`TSU_CTRL_PERF_CLEAR];
  assign ctrl_abort      = wr && a_ctrl && rb_wdata[`TSU_CTRL_ABORT];

  wire [2:0] int_set = {ev_done, ev_err, ev_irq};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < `TSU_DESC_WORDS; i++) desc_q[i] <= 32'd0;
      err_cont_q <= 1'b0; int_en_q <= 3'd0; int_st_q <= 3'd0; submitted_q <= 32'd0;
    end else begin
      if (wr && is_desc) desc_q[desc_i] <= rb_wdata;
      if (wr && a_ctrl) err_cont_q <= rb_wdata[`TSU_CTRL_ERR_CONT];
      if (wr && a_inten) int_en_q <= rb_wdata[2:0];
      int_st_q <= (int_st_q & ~((wr && a_intst) ? rb_wdata[2:0] : 3'd0)) | int_set;   // set wins
      if (cq_in_valid) submitted_q <= submitted_q + 32'd1;
    end
  end
  assign irq = |(int_st_q & int_en_q);
endmodule

`default_nettype wire
