// =============================================================================
// SilicaFlux TENSORCORE 08 :: silicaflux_tensor_unit   (primary source)
// Complete tensor accelerator for the SilicaFlux-HPC tile.  Aureom.AI | SilicaFlux-HPC
//
// A host writes a 12-word GEMM descriptor into the register page and rings the
// doorbell; the unit validates it, moves the INT8 operand blocks from memory
// into the operand buffers, runs the systolic array chunk by chunk, accumulates
// the partial sums, converts the results (exact INT32, or requantised INT8),
// writes C back to memory and, only after every C write has been acknowledged
// by memory, pushes a completion record and (optionally) raises an interrupt.
//
//   host rb page ─► tsu_regs ─► cmd queue (M08 hpc_command_queue) ─► tsu_sched ─► cpl queue ─► tsu_regs
//                                                                     │ validate / iterate / collect / abort
//                       ┌─────────────────────── tsu_datapath ────────┴──────────────────────────┐
//                       │ TC07 DMA adapter ─ TC03 operand buffers ─ TC02 systolic array ─        │
//                       │ TC04 accumulator ─ [TC05 quantiser + pack] ─ TC07 output buffer        │
//                       │ TC07 compute sequencer                                                 │
//                       └──────────────── SFB2 ─► tsu_bus_gate (quiesce) ─► m_* (DataFabric) ────┘
//   counters: M08 hpc_perf_counters (PERF page) + perf_ev (event interface)
//
// One clock domain; reset asynchronous assert / synchronous release (SilicaFlux
// convention).  rst_n resets everything (records of destroyed commands are not
// produced).  The scheduler's datapath soft reset (after an error or abort) is
// rst_n AND a registered request, held for SRST_CYCLES clock edges, so both the
// asynchronous (TC02/03/07, M04) and the synchronous-reset blocks (TC04/05) see it.
// No cache-coherent port: the unit reads and writes memory through one plain
// SFB2 master; software owns coherence (docs/06).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tsu_defs.svh"
`include "tdma_defs.svh"
`include "tob_defs.svh"
`include "hpc_spm_defs.svh"
`include "sram_defs.svh"
`default_nettype none

module silicaflux_tensor_unit #(
  // ------------------------------------------------------------ brief parameters
  parameter int          ARRAY_ROWS              = 4,      // systolic array rows    (TILE_M)
  parameter int          ARRAY_COLS              = 4,      // systolic array columns (TILE_N)
  parameter int          DATA_WIDTH              = 8,      // operand width: 8 (INT8) only
  parameter int          ACC_WIDTH               = 32,     // accumulator width: 32 only
  parameter int          TILE_K                  = 64,     // maximum K chunk per operand set
  parameter int          OPERAND_BUFFER_BYTES    = 2048,   // TC03 A + B capacity, all sets (power of two)
  parameter int          NUM_MEMORY_BANKS        = 4,      // TC03 A banks (B and output buffer: half)
  parameter int          ENABLE_QUANTIZATION     = 0,      // 1: INT8 requantised output (TC05)
  parameter int          ENABLE_DOUBLE_BUFFERING = 0,      // 1: two operand / output sets, PREFETCH flag
  // ------------------------------------------------------------ secondary
  parameter int          CMD_QUEUE_DEPTH         = 4,
  parameter int          CPL_QUEUE_DEPTH         = 4,
  parameter logic [32:0] MEM_LO                  = 33'h0_0000_0000,   // legal memory window [MEM_LO, MEM_HI)
  parameter logic [32:0] MEM_HI                  = 33'h1_0000_0000,
  parameter int          MAX_OUT                 = 4,      // SFB2 transactions in flight (1, 2, 4, 8, 16)
  parameter int          K_MAX                   = 131071, // largest overflow-free INT8 x INT8 -> INT32 K
  parameter int          WDOG_LOG2               = 16,     // no-progress watchdog
  parameter int          PERF_EN                 = 1,
  parameter int          ALLOW_UNVERIFIED        = 0,      // 1: accept array shapes not in the verified list
  parameter int          FAULT_INJ               = 0,      // 1: verification-only fault hooks (fi_mode)
  parameter int          MEM_BACKEND             = `SRAM_BACKEND_GENERIC,  // buffers: GENERIC or FPGA block RAM
  // ------------------------------------------------------------ derived (never set)
  localparam int NUM_SETS    = (ENABLE_DOUBLE_BUFFERING != 0) ? 2 : 1,
  localparam int O_SETS      = NUM_SETS,
  localparam int SET_BYTES   = OPERAND_BUFFER_BYTES / (2 * NUM_SETS),
  localparam int A_BANKS     = NUM_MEMORY_BANKS,
  localparam int B_BANKS     = (NUM_MEMORY_BANKS >= 2) ? NUM_MEMORY_BANKS / 2 : 1,
  localparam int O_BANKS     = B_BANKS,
  localparam int O_LD        = 4 * ARRAY_COLS,
  localparam int O_TILE      = 4 * ARRAY_ROWS * ARRAY_COLS,
  localparam int O_SET_BYTES = (O_TILE <= 256) ? 256 : (O_TILE <= 1024) ? 1024 : (O_TILE <= 4096) ? 4096 : 16384,
  localparam int LDA_LOC_MAX = ((TILE_K + 3) / 4) * 4 + 4,
  localparam int LDB_LOC     = ((ARRAY_COLS + 3) / 4) * 4,
  localparam int NUM_SLOTS   = 2,
  localparam int NPC         = `TSU_NUM_PC,
  localparam int DPC         = `TDMA_NUM_PC,
  localparam int QDW         = (CMD_QUEUE_DEPTH > 1) ? $clog2(CMD_QUEUE_DEPTH + 1) : 1,
  localparam int PIW         = 32
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ---------------------------------------------------------- host register page (SilicaFlux-V rb)
  input  wire logic              rb_sel,
  input  wire logic              rb_we,
  input  wire logic [11:0]       rb_addr,
  input  wire logic [31:0]       rb_wdata,
  output logic [31:0]            rb_rdata,
  output logic                   rb_err,
  // ---------------------------------------------------------- SFB2 master (DataFabric crossbar or memory)
  output logic                   m_req_valid,
  input  wire logic              m_req_ready,
  output logic                   m_req_write,
  output logic [31:0]            m_req_addr,
  output logic [31:0]            m_req_wdata,
  output logic [3:0]             m_req_wstrb,
  input  wire logic              m_rsp_valid,
  output logic                   m_rsp_ready,
  input  wire logic [31:0]       m_rsp_rdata,
  input  wire logic              m_rsp_error,
  // ---------------------------------------------------------- interrupt / status
  output logic                   irq,
  output logic                   busy,
  output logic                   halted,
  // ---------------------------------------------------------- performance event interface (TSU_PC_* increments)
  output logic [NPC*PIW-1:0]     perf_ev,
  // ---------------------------------------------------------- verification hook (tie to 0; ignored unless FAULT_INJ)
  input  wire logic [1:0]        fi_mode
);
  // ============================================================ configuration checks (portable elaboration errors)
  if (DATA_WIDTH != 8) begin : g_err_dw
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: DATA_WIDTH must be 8 (INT8 operands are the only implemented type)")
  end
  if (ACC_WIDTH != 32) begin : g_err_aw
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: ACC_WIDTH must be 32 (INT32 accumulation is the only implemented width)")
  end
  if (ARRAY_ROWS < 1 || ARRAY_ROWS > 16 || ARRAY_COLS < 1 || ARRAY_COLS > 16) begin : g_err_shape
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: ARRAY_ROWS and ARRAY_COLS must be 1..16")
  end
  if (ALLOW_UNVERIFIED == 0 && !((ARRAY_ROWS == 4 && ARRAY_COLS == 4) || (ARRAY_ROWS == 8 && ARRAY_COLS == 8) ||
                                 (ARRAY_ROWS == 2 && ARRAY_COLS == 2))) begin : g_err_unverified
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: array shape not in the verified list (2x2, 4x4, 8x8); set ALLOW_UNVERIFIED")
  end
  if (TILE_K < 1 || TILE_K > 32767) begin : g_err_tk
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: TILE_K must be 1..32767 (KC field width)")
  end
  if (OPERAND_BUFFER_BYTES < 64 || (OPERAND_BUFFER_BYTES & (OPERAND_BUFFER_BYTES - 1)) != 0) begin : g_err_ob
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: OPERAND_BUFFER_BYTES must be a power of two >= 64")
  end
  if (NUM_MEMORY_BANKS < 1 || NUM_MEMORY_BANKS > 16 || (NUM_MEMORY_BANKS & (NUM_MEMORY_BANKS - 1)) != 0) begin : g_err_nb
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: NUM_MEMORY_BANKS must be a power of two 1..16")
  end
  if (SET_BYTES < 2 * 4 * A_BANKS) begin : g_err_rows
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: OPERAND_BUFFER_BYTES too small for NUM_MEMORY_BANKS (TC03: >= 2 rows per bank)")
  end
  if ((ARRAY_ROWS - 1) * LDA_LOC_MAX + TILE_K > SET_BYTES) begin : g_err_acap
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: an A block of TILE_K bytes per row does not fit in one operand set")
  end
  if ((TILE_K - 1) * LDB_LOC + ARRAY_COLS > SET_BYTES) begin : g_err_bcap
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: a B block of TILE_K rows does not fit in one operand set")
  end
  if (ENABLE_QUANTIZATION != 0 && ENABLE_QUANTIZATION != 1) begin : g_err_q
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: ENABLE_QUANTIZATION must be 0 or 1")
  end
  if (ENABLE_DOUBLE_BUFFERING != 0 && ENABLE_DOUBLE_BUFFERING != 1) begin : g_err_db
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: ENABLE_DOUBLE_BUFFERING must be 0 or 1")
  end
  if (MAX_OUT < 1 || MAX_OUT > 16 || (MAX_OUT & (MAX_OUT - 1)) != 0) begin : g_err_mo
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: MAX_OUT must be 1, 2, 4, 8 or 16")
  end
  if (CMD_QUEUE_DEPTH < 2 || CMD_QUEUE_DEPTH > 256 || (CMD_QUEUE_DEPTH & (CMD_QUEUE_DEPTH - 1)) != 0 ||
      CPL_QUEUE_DEPTH < 2 || CPL_QUEUE_DEPTH > 256 || (CPL_QUEUE_DEPTH & (CPL_QUEUE_DEPTH - 1)) != 0) begin : g_err_qd
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: CMD_QUEUE_DEPTH / CPL_QUEUE_DEPTH must be powers of two 2..256")
  end
  if (K_MAX < 1 || K_MAX > 131071) begin : g_err_kmax
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: K_MAX must be 1..131071 (exact INT32 bound for INT8 x INT8)")
  end
  if (MEM_LO >= MEM_HI || MEM_LO[1:0] != 2'b00 || MEM_HI[1:0] != 2'b00) begin : g_err_mem
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: memory window must be non-empty and 4-byte aligned")
  end
  if (MEM_BACKEND != `SRAM_BACKEND_GENERIC && MEM_BACKEND != `SRAM_BACKEND_FPGA) begin : g_err_be
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: MEM_BACKEND must be GENERIC or FPGA (ASIC needs SRAM macros, not wired here)")
  end
  if (WDOG_LOG2 < 4 || WDOG_LOG2 > 30) begin : g_err_wd
    `SRAM_CFG_FATAL("silicaflux_tensor_unit: WDOG_LOG2 must be 4..30")
  end

  // ============================================================ register page
  localparam logic [31:0] INFO = {5'd0, 1'(PERF_EN != 0), 1'(ENABLE_DOUBLE_BUFFERING), 1'(ENABLE_QUANTIZATION),
                                  8'(ARRAY_COLS), 8'(ARRAY_ROWS), 4'($clog2(CMD_QUEUE_DEPTH)), `TSU_ABI_VERSION};
  localparam logic [31:0] CAPS = {8'(ACC_WIDTH), 8'(DATA_WIDTH), 16'(TILE_K)};
  localparam logic [32:0] MEM_LAST33 = MEM_HI - 33'd1;

  logic                   cq_in_v, cq_in_r, cq_out_v, cq_out_r, cq_full, cq_empty;
  logic [`TSU_DESC_W-1:0] cq_in_d, cq_out_d;
  logic [QDW-1:0]         cq_level;
  logic                   rec_v, rec_r, cpl_v, cpl_pop;
  /* verilator lint_off UNUSEDSIGNAL */
  logic                   cpl_full_u, cpl_empty_u;
  logic [`TSU_CPL_W-1:0]  rec_d, cpl_d;
  logic [$clog2(CPL_QUEUE_DEPTH + 1)-1:0] cpl_level_u;
  /* verilator lint_on UNUSEDSIGNAL */
  logic                   c_err_cont, c_err_clear, c_perf_clear, c_abort;
  logic                   s_busy, s_err_sticky, s_aborting, s_halted;
  logic [3:0]             s_state;
  logic                   ev_commit, ev_commit_err, ev_commit_irq, ev_gemm_ok, ev_tile, ev_job, ev_desc,
                          ev_rec_stall, ev_abort;
  logic [31:0]            ev_macs;
  logic [NPC*32-1:0]      perf_cnt;
  logic [DPC*32-1:0]      dma_perf_cnt;
  logic [31:0]            status;

  assign status = {8'(CMD_QUEUE_DEPTH) - 8'(cq_level), 8'(cq_level), 4'd0, s_state, 1'b0, s_halted, s_aborting,
                   cpl_v, cq_empty, cq_full, s_err_sticky, s_busy || !cq_empty};

  tsu_regs #(.NPC(NPC), .DPC(DPC), .INFO(INFO), .CAPS(CAPS), .OPBUF(32'(OPERAND_BUFFER_BYTES)),
             .MEM_LO(MEM_LO[31:0]), .MEM_LAST(MEM_LAST33[31:0]), .KMAX(32'(K_MAX))) u_regs (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .cq_in_valid(cq_in_v), .cq_in_ready(cq_in_r), .cq_in_data(cq_in_d),
    .cpl_valid(cpl_v), .cpl_pop(cpl_pop), .cpl_data(cpl_d),
    .ctrl_err_cont(c_err_cont), .ctrl_err_clear(c_err_clear), .ctrl_perf_clear(c_perf_clear), .ctrl_abort(c_abort),
    .status(status), .ev_irq(ev_commit_irq), .ev_err(ev_commit_err), .ev_done(ev_commit), .irq(irq),
    .perf_cnt(perf_cnt), .dma_perf_cnt(dma_perf_cnt));

  // ============================================================ command / completion queues (M08, unmodified)
  hpc_command_queue #(.WIDTH(`TSU_DESC_W), .DEPTH(CMD_QUEUE_DEPTH)) u_cq (
    .clk(clk), .rst_n(rst_n), .in_valid(cq_in_v), .in_ready(cq_in_r), .in_data(cq_in_d),
    .out_valid(cq_out_v), .out_ready(cq_out_r), .out_data(cq_out_d), .level(cq_level), .full(cq_full), .empty(cq_empty));

  hpc_command_queue #(.WIDTH(`TSU_CPL_W), .DEPTH(CPL_QUEUE_DEPTH)) u_cplq (
    .clk(clk), .rst_n(rst_n), .in_valid(rec_v), .in_ready(rec_r), .in_data(rec_d),
    .out_valid(cpl_v), .out_ready(cpl_pop), .out_data(cpl_d), .level(cpl_level_u), .full(cpl_full_u),
    .empty(cpl_empty_u));

  // ============================================================ scheduler
  localparam int MW = $clog2(ARRAY_ROWS + 1), NW = $clog2(ARRAY_COLS + 1), SATW = $clog2(ARRAY_COLS + 1);
  logic                    dp_srst, dp_prefetch, dp_int8, srst_q;
  logic                    d_v, d_r, c_v, c_r, j_v, j_r, q_v, q_r;
  logic [`TDMA_DESC_W-1:0] d_d;
  logic [1:0]              c_kind;
  logic [3:0]              c_code;
  logic [2:0]              c_det;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [7:0]              c_id_u;               // records are matched by order, not ID
  logic                    m_gate_u;
  logic [NUM_SETS*2-1:0]   op_state_u;
  logic [O_SETS*2-1:0]     ob_state_u;
  logic [5:0]              g_out_u;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [31:0]             c_ea, c_bytes;
  logic [15:0]             j_tag, j_nch, j_chunk;
  logic [MW-1:0]           j_m;
  logic [NW-1:0]           j_n;
  logic [16:0]             j_k;
  logic [39:0]             j_kt;
  logic [31:0]             j_lda, j_ldb;
  logic [255:0]            q_d;
  logic                    dma_busy, cmp_busy, ev_compute, tq_idle, acc_hs;
  logic [4:0]              cmp_err;
  logic                    m_rng, m_cfg, m_beat, m_ovf, m_werr, m_tqr, m_tqb, m_proto, dp_prog;
  logic [SATW-1:0]         sat_inc;
  logic                    acc_slot;
  logic                    g_qreq, g_quiesced, g_unsol;

  tsu_sched #(
    .TILE_M(ARRAY_ROWS), .TILE_N(ARRAY_COLS), .TILE_K(TILE_K), .K_MAX(K_MAX), .NUM_SLOTS(NUM_SLOTS),
    .QUANT_EN(ENABLE_QUANTIZATION), .DBUF_EN(ENABLE_DOUBLE_BUFFERING), .O_LD(O_LD), .MEM_LO(MEM_LO),
    .MEM_HI(MEM_HI), .WDOG_LOG2(WDOG_LOG2), .SRST_CYCLES(4)
  ) u_sched (
    .clk(clk), .rst_n(rst_n),
    .cq_valid(cq_out_v), .cq_ready(cq_out_r), .cq_data(cq_out_d),
    .rec_valid(rec_v), .rec_ready(rec_r), .rec_data(rec_d),
    .ctrl_err_cont(c_err_cont), .ctrl_err_clear(c_err_clear), .ctrl_abort(c_abort),
    .busy(s_busy), .err_sticky(s_err_sticky), .aborting(s_aborting), .halted(s_halted), .state(s_state),
    .dp_srst(dp_srst), .dp_prefetch(dp_prefetch), .dp_int8(dp_int8),
    .d_valid(d_v), .d_ready(d_r), .d_data(d_d),
    .c_valid(c_v), .c_ready(c_r), .c_kind(c_kind), .c_code(c_code), .c_detail(c_det), .c_err_addr(c_ea),
    .c_bytes(c_bytes),
    .j_valid(j_v), .j_ready(j_r), .j_tag(j_tag), .j_m(j_m), .j_n(j_n), .j_k(j_k), .j_ktot(j_kt), .j_nch(j_nch),
    .j_chunk(j_chunk), .j_lda(j_lda), .j_ldb(j_ldb),
    .q_valid(q_v), .q_ready(q_r), .q_data(q_d),
    .dma_busy(dma_busy), .cmp_busy(cmp_busy), .cmp_err(cmp_err), .tq_idle(tq_idle),
    .acc_cfg_hs(acc_hs), .acc_cfg_slot(acc_slot),
    .mon_acc_range(m_rng), .mon_acc_cfg(m_cfg), .mon_acc_beat(m_beat), .mon_acc_ovf(m_ovf), .mon_ob_werr(m_werr),
    .mon_tq_rej(m_tqr), .mon_tq_beat(m_tqb), .mon_dma_proto(m_proto), .sat_inc(sat_inc), .progress(dp_prog),
    .g_qreq(g_qreq), .g_quiesced(g_quiesced),
    .ev_commit(ev_commit), .ev_commit_err(ev_commit_err), .ev_commit_irq(ev_commit_irq), .ev_gemm_ok(ev_gemm_ok),
    .ev_tile(ev_tile), .ev_job(ev_job), .ev_macs(ev_macs), .ev_desc(ev_desc), .ev_rec_stall(ev_rec_stall),
    .ev_abort(ev_abort));

  assign busy   = s_busy || !cq_empty;
  assign halted = s_halted;

  // datapath reset: hard reset, or the scheduler's registered soft-reset request (glitch-free)
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) srst_q <= 1'b0;
    else        srst_q <= dp_srst;
  end
  wire dp_rst_n = rst_n && !srst_q;

  // ============================================================ datapath
  logic          a_req_v, a_req_r, a_req_w, a_rsp_v, a_rsp_r, a_rsp_e;
  logic [31:0]   a_req_a, a_req_d, a_rsp_d;
  logic [3:0]    a_req_s;

  tsu_datapath #(
    .TILE_M(ARRAY_ROWS), .TILE_N(ARRAY_COLS), .NUM_SETS(NUM_SETS), .A_SET_BYTES(SET_BYTES), .B_SET_BYTES(SET_BYTES),
    .A_BANKS(A_BANKS), .B_BANKS(B_BANKS), .TOB_PORT(`TOB_PORT_1R1W), .O_SETS(O_SETS), .O_SET_BYTES(O_SET_BYTES),
    .O_LD(O_LD), .O_BANKS(O_BANKS), .O_PORT(`HPC_SPM_PORT_1RW), .NUM_SLOTS(NUM_SLOTS), .MEM_LO(MEM_LO),
    .MEM_HI(MEM_HI), .MAX_OUT(MAX_OUT), .LOC_OUT(4), .RCAP(32), .QDEPTH(4), .QUANT_EN(ENABLE_QUANTIZATION),
    .FAULT_INJ(FAULT_INJ), .MEM_BACKEND(MEM_BACKEND)
  ) u_dp (
    .clk(clk), .rst_n(dp_rst_n), .cfg_prefetch(dp_prefetch), .cfg_int8(dp_int8), .fi_mode(fi_mode),
    .desc_valid(d_v), .desc_ready(d_r), .desc_data(d_d),
    .cpl_valid(c_v), .cpl_ready(c_r), .cpl_id(c_id_u), .cpl_kind(c_kind), .cpl_code(c_code), .cpl_detail(c_det),
    .cpl_err_addr(c_ea), .cpl_bytes(c_bytes),
    .job_valid(j_v), .job_ready(j_r), .job_tag(j_tag), .job_m(j_m), .job_n(j_n), .job_k(j_k), .job_k_total(j_kt),
    .job_n_chunks(j_nch), .job_chunk(j_chunk), .job_lda(j_lda), .job_ldb(j_ldb),
    .tq_desc_valid(q_v), .tq_desc_ready(q_r), .tq_desc_data(q_d),
    .req_valid(a_req_v), .req_ready(a_req_r), .req_write(a_req_w), .req_addr(a_req_a), .req_wdata(a_req_d),
    .req_wstrb(a_req_s), .rsp_valid(a_rsp_v), .rsp_ready(a_rsp_r), .rsp_rdata(a_rsp_d), .rsp_error(a_rsp_e),
    .dma_busy(dma_busy), .cmp_busy(cmp_busy), .cmp_err(cmp_err), .ev_compute(ev_compute), .tq_idle(tq_idle),
    .op_state(op_state_u), .ob_state(ob_state_u), .acc_cfg_slot_seen(acc_slot), .acc_cfg_hs(acc_hs),
    .mon_acc_range(m_rng), .mon_acc_cfg(m_cfg), .mon_acc_beat(m_beat), .mon_acc_ovf(m_ovf), .mon_ob_werr(m_werr),
    .mon_ob_gate(m_gate_u), .mon_tq_rej(m_tqr), .mon_tq_beat(m_tqb), .mon_dma_proto(m_proto), .sat_inc(sat_inc),
    .progress(dp_prog), .perf_clear(c_perf_clear), .dma_perf_cnt(dma_perf_cnt));

  // ============================================================ bus quiesce gate
  tsu_bus_gate #(.DW(32), .OUT_W(6)) u_gate (
    .clk(clk), .rst_n(rst_n), .q_req(g_qreq), .quiesced(g_quiesced), .outstanding(g_out_u),
    .ev_unsolicited(g_unsol),
    .u_req_valid(a_req_v), .u_req_ready(a_req_r), .u_req_write(a_req_w), .u_req_addr(a_req_a),
    .u_req_wdata(a_req_d), .u_req_wstrb(a_req_s), .u_rsp_valid(a_rsp_v), .u_rsp_ready(a_rsp_r),
    .u_rsp_rdata(a_rsp_d), .u_rsp_error(a_rsp_e),
    .d_req_valid(m_req_valid), .d_req_ready(m_req_ready), .d_req_write(m_req_write), .d_req_addr(m_req_addr),
    .d_req_wdata(m_req_wdata), .d_req_wstrb(m_req_wstrb), .d_rsp_valid(m_rsp_valid), .d_rsp_ready(m_rsp_ready),
    .d_rsp_rdata(m_rsp_rdata), .d_rsp_error(m_rsp_error));

  // ============================================================ performance events + counters (M08, unmodified)
  wire ext_acc = m_req_valid && m_req_ready;
  logic [NPC*PIW-1:0] inc;
  always_comb begin
    inc = '0;
    inc[`TSU_PC_CYCLES      * PIW +: PIW] = 32'd1;
    inc[`TSU_PC_BUSY        * PIW +: PIW] = 32'(s_busy);
    inc[`TSU_PC_CMD_ACCEPT  * PIW +: PIW] = 32'(cq_in_v && cq_in_r);
    inc[`TSU_PC_CMD_DONE    * PIW +: PIW] = 32'(ev_commit);
    inc[`TSU_PC_CMD_ERR     * PIW +: PIW] = 32'(ev_commit_err);
    inc[`TSU_PC_GEMM_OK     * PIW +: PIW] = 32'(ev_gemm_ok);
    inc[`TSU_PC_TILES       * PIW +: PIW] = 32'(ev_tile);
    inc[`TSU_PC_CHUNKS      * PIW +: PIW] = 32'(ev_job);
    inc[`TSU_PC_MACS        * PIW +: PIW] = ev_macs;
    inc[`TSU_PC_COMPUTE_CYC * PIW +: PIW] = 32'(ev_compute);
    inc[`TSU_PC_DMA_ACTIVE  * PIW +: PIW] = 32'(dma_busy);
    inc[`TSU_PC_OVERLAP     * PIW +: PIW] = 32'(ext_acc && ev_compute);
    inc[`TSU_PC_RD_WORDS    * PIW +: PIW] = 32'(ext_acc && !m_req_write);
    inc[`TSU_PC_WR_WORDS    * PIW +: PIW] = 32'(ext_acc && m_req_write);
    inc[`TSU_PC_BUS_STALL   * PIW +: PIW] = 32'(m_req_valid && !m_req_ready);
    inc[`TSU_PC_DESC        * PIW +: PIW] = 32'(ev_desc);
    inc[`TSU_PC_Q_FULL      * PIW +: PIW] = 32'(cq_full);
    inc[`TSU_PC_CPL_STALL   * PIW +: PIW] = 32'(ev_rec_stall);
    inc[`TSU_PC_SAT         * PIW +: PIW] = 32'(sat_inc);
    inc[`TSU_PC_ABORTS      * PIW +: PIW] = 32'(ev_abort);
  end
  assign perf_ev = inc;

  if (PERF_EN != 0) begin : g_perf
    hpc_perf_counters #(.NUM(NPC), .CW(32), .IW(PIW)) u_pc (
      .clk(clk), .rst_n(rst_n), .clear(c_perf_clear), .enable(1'b1), .inc(inc), .cnt(perf_cnt));
  end else begin : g_noperf
    assign perf_cnt = '0;
  end

`ifndef SYNTHESIS
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n && g_unsol) $error("silicaflux_tensor_unit: unsolicited SFB2 response");
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
