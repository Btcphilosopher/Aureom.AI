// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_validate
// Validation of one host command descriptor (tsu_defs.svh, VERSION 2) BEFORE
// any side effect.  First failing rule wins:
//
//   VERSION > OPCODE > FLAGS > RSVD > RM > LAYOUT > PRECISION > DIM_ZERO >
//   DIM_RANGE > CHUNK > LD > ALIGN > ADDR_OVF > RANGE > ALIAS
//
// The GEMM rules from LAYOUT on are TENSORCORE 06 ttc_validate's eleven rules in
// the same order, generalised to an output element size of 4 (INT32) or 1
// (requantised INT8); the header rules follow HPC Module 06.  ttc_validate is
// not instantiated because its C rules are fixed to INT32.
//
// Sequence (start pulse; desc stable until done):
//   V_LOOP   18 cycles: four shift-and-add products and the chunk-count division
//            run in parallel, one bit per cycle (no hardware multiplier):
//              pa = (M-1)*LDA   pb = (K-1)*LDB   pc = (M-1)*LDC   pk = KC_EFF*LDB
//              n_chunks = ceil(K / KC_EFF)  (restoring division of K + KC_EFF - 1)
//   V_CHECK  rules evaluated on registered values -> done pulse (20 cycles total)
// All address arithmetic is 64 bits wide: nothing wraps, an overflow is
// detected, never computed modulo 2^32.  A product built from out-of-range or
// zero fields is never decisive, because an earlier rule has already failed.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tsu_defs.svh"
`default_nettype none

module tsu_validate #(
  parameter int          TILE_K   = 64,
  parameter int          K_MAX    = 131071,
  parameter int          QUANT_EN = 0,
  parameter int          DBUF_EN  = 0,
  parameter logic [32:0] MEM_LO   = 33'h0_0000_0000,
  parameter logic [32:0] MEM_HI   = 33'h1_0000_0000
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  input  wire logic                    start,
  input  wire logic [`TSU_DESC_W-1:0]  desc,
  output logic                         done,       // 1-cycle pulse
  output logic [7:0]                   code,       // TSU_E_*
  // decoded command, valid with done (and stable while desc is)
  output logic                         is_gemm,
  output logic                         out_int8,
  output logic [16:0]                  kc_eff,
  output logic [15:0]                  n_chunks,
  output logic [31:0]                  kc_ldb       // KC_EFF * LDB (low 32 bits; only used when K > KC_EFF)
);
  // ---------------------------------------------------------------- fields
  logic [31:0] w [`TSU_DESC_WORDS];
  always_comb for (int i = 0; i < `TSU_DESC_WORDS; i++) w[i] = desc[32*i +: 32];

  logic [7:0]  op, flags;
  logic [3:0]  ver;
  logic [2:0]  rm;
  logic        h15, relu;
  logic [15:0] m, n;
  logic [16:0] k;
  logic [14:0] kc;
  logic [31:0] a_base, b_base, c_base, lda, ldb, ldc, qmult;
  logic [1:0]  a_type, b_type, ofmt, a_lay, b_lay, c_lay;
  assign op     = w[0][7:0];
  assign ver    = w[0][11:8];
  assign rm     = w[0][14:12];
  assign h15    = w[0][15];
  assign flags  = w[0][23:16];
  assign a_base = w[1];
  assign b_base = w[2];
  assign c_base = w[3];
  assign m      = w[4][15:0];
  assign n      = w[4][31:16];
  assign k      = w[5][16:0];
  assign kc     = w[5][31:17];
  assign lda    = w[6];
  assign ldb    = w[7];
  assign ldc    = w[8];
  assign a_type = w[9][1:0];
  assign b_type = w[9][3:2];
  assign ofmt   = w[9][5:4];
  assign a_lay  = w[9][9:8];
  assign b_lay  = w[9][11:10];
  assign c_lay  = w[9][13:12];
  assign relu   = w[9][14];
  assign qmult  = w[10];

  logic        int8;
  logic [16:0] kce;
  logic [15:0] m_m1;
  logic [16:0] k_m1;
  assign m_m1 = m - 16'd1;
  assign k_m1 = k - 17'd1;
  assign int8 = (ofmt == `TSU_OFMT_INT8);
  assign kce  = (kc == 15'd0) ? 17'(TILE_K) : 17'(kc);

  // ---------------------------------------------------------------- sequencer
  localparam logic [1:0] V_IDLE = 2'd0, V_LOOP = 2'd1, V_CHECK = 2'd2;
  logic [1:0]  st;
  logic [4:0]  it;
  logic [17:0] mul_m, mul_k, mul_c;      // multipliers, shifted out MSB first
  logic [49:0] pa, pb, pc;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [49:0] pk;                       // only the low 32 bits are used (see kc_ldb)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [17:0] num_q, rem, quo;
  logic [18:0] r2;
  assign r2 = {rem, num_q[17]};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= V_IDLE; it <= '0; mul_m <= '0; mul_k <= '0; mul_c <= '0;
      pa <= '0; pb <= '0; pc <= '0; pk <= '0; num_q <= '0; rem <= '0; quo <= '0;
    end else begin
      case (st)
        V_IDLE: if (start) begin
          mul_m <= 18'(m_m1);
          mul_k <= 18'(k_m1);
          mul_c <= 18'(kce);
          pa <= '0; pb <= '0; pc <= '0; pk <= '0;
          num_q <= 18'(k) + 18'(kce) - 18'd1;          // ceil(K/kc) = floor((K + kc - 1) / kc)
          rem <= '0; quo <= '0;
          it <= 5'd18;
          st <= V_LOOP;
        end
        V_LOOP: begin
          pa <= {pa[48:0], 1'b0} + (mul_m[17] ? 50'(lda) : 50'd0);
          pc <= {pc[48:0], 1'b0} + (mul_m[17] ? 50'(ldc) : 50'd0);
          pb <= {pb[48:0], 1'b0} + (mul_k[17] ? 50'(ldb) : 50'd0);
          pk <= {pk[48:0], 1'b0} + (mul_c[17] ? 50'(ldb) : 50'd0);
          mul_m <= {mul_m[16:0], 1'b0};
          mul_k <= {mul_k[16:0], 1'b0};
          mul_c <= {mul_c[16:0], 1'b0};
          num_q <= {num_q[16:0], 1'b0};
          if (r2 >= 19'(kce)) begin rem <= 18'(r2 - 19'(kce)); quo <= {quo[16:0], 1'b1}; end
          else                begin rem <= r2[17:0];            quo <= {quo[16:0], 1'b0}; end
          it <= it - 5'd1;
          if (it == 5'd1) st <= V_CHECK;
        end
        default: st <= V_IDLE;                                  // V_CHECK: one cycle, result below
      endcase
    end
  end

  // ---------------------------------------------------------------- rules
  logic [63:0] al, bl, cl;
  logic [33:0] esz_n;
  assign esz_n = int8 ? 34'(n) : {16'd0, n, 2'b00};
  assign al = 64'(a_base) + 64'(pa) + 64'(k) - 64'd1;            // A + (M-1)*LDA + K - 1
  assign bl = 64'(b_base) + 64'(pb) + 64'(n) - 64'd1;            // B + (K-1)*LDB + N - 1
  assign cl = 64'(c_base) + 64'(pc) + 64'(esz_n) - 64'd1;        // C + (M-1)*LDC + esz*N - 1

  /* verilator lint_off UNSIGNED */
  function automatic logic out_win(input logic [31:0] lo, input logic [63:0] hi);
    out_win = (33'(lo) < MEM_LO) || (hi >= 64'(MEM_HI));
  endfunction
  /* verilator lint_on UNSIGNED */

  logic        gemm, nop, fl_bad, rsvd_bad;
  logic [7:0]  c_code;
  assign gemm = (op == `TSU_OP_GEMM);
  assign nop  = (op == `TSU_OP_NOP);

  always_comb begin
    fl_bad   = 1'b0;
    rsvd_bad = h15;
    if (nop) begin
      fl_bad = (flags & ~8'((1 << `TSU_FL_IRQ) | (1 << `TSU_FL_BARRIER))) != 8'd0;
      rsvd_bad = rsvd_bad || (rm != 3'd0);
      for (int i = 1; i < `TSU_DESC_WORDS; i++) rsvd_bad = rsvd_bad || (w[i] != 32'd0);
    end else begin
      fl_bad = ((flags & ~`TSU_FL_MASK) != 8'd0) || (flags[`TSU_FL_PREFETCH] && (DBUF_EN == 0));
      rsvd_bad = rsvd_bad || ((w[9] & `TSU_W9_RSVD_MASK) != 32'd0) || ((w[11] & `TSU_W11_RSVD_MASK) != 32'd0);
      if (ofmt == `TSU_OFMT_INT32)
        rsvd_bad = rsvd_bad || (rm != 3'd0) || relu || (qmult != 32'd0) || (w[11] != 32'd0);
    end
  end

  always_comb begin
    c_code = `TSU_E_NONE;
    if (ver != `TSU_ABI_VERSION)                                                 c_code = `TSU_E_VERSION;
    else if (!nop && !gemm)                                                      c_code = `TSU_E_OPCODE;
    else if (fl_bad)                                                             c_code = `TSU_E_FLAGS;
    else if (rsvd_bad)                                                           c_code = `TSU_E_RSVD;
    else if (nop)                                                                c_code = `TSU_E_NONE;
    else if (int8 && rm > `TSU_RM_RMM)                                           c_code = `TSU_E_RM;
    else if (a_lay != `TSU_LAYOUT_ROW || b_lay != `TSU_LAYOUT_ROW ||
             c_lay != `TSU_LAYOUT_ROW)                                           c_code = `TSU_E_LAYOUT;
    else if (a_type != `TSU_TYPE_INT8 || b_type != `TSU_TYPE_INT8 ||
             !(ofmt == `TSU_OFMT_INT32 || (int8 && QUANT_EN != 0)))              c_code = `TSU_E_PRECISION;
    else if (m == 16'd0 || n == 16'd0 || k == 17'd0)                             c_code = `TSU_E_DIM_ZERO;
    else if (32'(k) > 32'(K_MAX))                                                c_code = `TSU_E_DIM_RANGE;
    else if (32'(kc) > 32'(TILE_K) || quo > 18'd65535)                           c_code = `TSU_E_CHUNK;
    else if (lda < 32'(k) || ldb < 32'(n) || 34'(ldc) < esz_n)                   c_code = `TSU_E_LD;
    else if (!int8 && (c_base[1:0] != 2'b00 || ldc[1:0] != 2'b00))               c_code = `TSU_E_ALIGN;
    else if (al[63:32] != 32'd0 || bl[63:32] != 32'd0 || cl[63:32] != 32'd0)     c_code = `TSU_E_ADDR_OVF;
    else if (out_win(a_base, al) || out_win(b_base, bl) || out_win(c_base, cl))  c_code = `TSU_E_RANGE;
    else if ((64'(c_base) <= al && 64'(a_base) <= cl) ||
             (64'(c_base) <= bl && 64'(b_base) <= cl))                           c_code = `TSU_E_ALIAS;
  end

  assign done     = (st == V_CHECK);
  assign code     = c_code;
  assign is_gemm  = gemm;
  assign out_int8 = int8;
  assign kc_eff   = kce;
  assign n_chunks = quo[15:0];
  assign kc_ldb   = pk[31:0];
endmodule

`default_nettype wire
