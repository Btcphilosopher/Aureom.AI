// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_sched
// Command execution scheduler of silicaflux_tensor_unit.
//
// One command at a time, strictly in queue order, exactly one completion record
// per dequeued command:
//
//   IDLE ─► DECODE (tsu_validate, 20 cycles) ─► PREP ─► RUN ─────────────────► RECORD ─► IDLE
//              │ invalid / NOP / skipped ───────────────────────────────────────▲   │
//              └──────────── RUN: execution error / abort / watchdog ─► QUIESCE ─► SRST ┘   └► FLUSH (abort)
//
// RUN drives the datapath with two INDEPENDENT iterators over the same tile
// sequence (TENSORCORE 06 ttc_tile_iter, unmodified; M-major or N-major
// output tiles, K innermost in chunks of KC):
//   * descriptor iterator  per step  LOAD_A, LOAD_B (SEAL); after a tile's last
//     chunk STORE (SEAL) -> TENSORCORE 07 tensor_dma_adapter.  This is the
//     schedule of TC07 model/gemm_gen.py, generated in hardware with
//     incremental address pointers (no multiplier on the step path).
//   * job iterator         per step  one compute job (TC07 tdma_compute_seq),
//     preceded, for INT8 output, by one TENSORCORE 05 OPEN descriptor per tile.
// The two streams only meet through buffer ownership (TC03 / output buffer
// FREE -> FILLING -> READY -> IN_USE), so neither can deadlock the other: a
// job only waits for a set whose LOADs were issued earlier; a STORE only waits
// for a tile whose jobs were issued earlier (TC07 doc 04 sec. 5 ordering rule).
//
// COMPLETION is reported only after every descriptor of the command completed
// (each STORE completion means every C write was ACKNOWLEDGED by memory, SFB2
// R7) and compute is idle.  COUNT = C bytes acknowledged, TILES = STOREs OK.
//
// ERRORS: the first error wins (adapter completion code, compute / output /
// quantiser monitors, watchdog, host abort).  The scheduler stops issuing,
// asks tsu_bus_gate to quiesce the SFB2 port (no request withdrawn, every
// response collected), holds the datapath in reset for SRST_CYCLES, then
// records the error.  The datapath is therefore always clean for the next
// command.  If the port cannot be quiesced within 2^WDOG_LOG2 cycles the record
// is still produced, then the unit HALTs (hard reset needed).
// Stop-on-error (CTRL.ERR_CONT = 0): after an ERROR record every command is
// completed as SKIPPED (PRIOR) until ERR_CLEAR.  ABORT: the running command
// completes ERROR (ABORTED), every queued command SKIPPED (ABORTED).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tsu_defs.svh"
`include "tdma_defs.svh"
`default_nettype none

module tsu_sched #(
  parameter int          TILE_M      = 4,
  parameter int          TILE_N      = 4,
  parameter int          TILE_K      = 64,
  parameter int          K_MAX       = 131071,
  parameter int          NUM_SLOTS   = 2,
  parameter int          QUANT_EN    = 0,
  parameter int          DBUF_EN     = 0,
  parameter int          O_LD        = 16,
  parameter logic [32:0] MEM_LO      = 33'h0_0000_0000,
  parameter logic [32:0] MEM_HI      = 33'h1_0000_0000,
  parameter int          WDOG_LOG2   = 16,
  parameter int          SRST_CYCLES = 4,
  localparam int MW     = $clog2(TILE_M + 1),
  localparam int NW     = $clog2(TILE_N + 1),
  localparam int SLOT_W = (NUM_SLOTS > 1) ? $clog2(NUM_SLOTS) : 1,
  localparam int SATW   = $clog2(TILE_N + 1)
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---------------------------------------------------------- command queue (head)
  input  wire logic                    cq_valid,
  output logic                         cq_ready,
  input  wire logic [`TSU_DESC_W-1:0]  cq_data,
  // ---------------------------------------------------------- completion queue (tail)
  output logic                         rec_valid,
  input  wire logic                    rec_ready,
  output logic [`TSU_CPL_W-1:0]        rec_data,
  // ---------------------------------------------------------- control / status
  input  wire logic                    ctrl_err_cont,
  input  wire logic                    ctrl_err_clear,
  input  wire logic                    ctrl_abort,
  output logic                         busy,
  output logic                         err_sticky,
  output logic                         aborting,
  output logic                         halted,
  output logic [3:0]                   state,
  // ---------------------------------------------------------- datapath control
  output logic                         dp_srst,
  output logic                         dp_prefetch,
  output logic                         dp_int8,
  output logic                         d_valid,
  input  wire logic                    d_ready,
  output logic [`TDMA_DESC_W-1:0]      d_data,
  input  wire logic                    c_valid,
  output logic                         c_ready,
  input  wire logic [1:0]              c_kind,
  input  wire logic [3:0]              c_code,
  input  wire logic [2:0]              c_detail,
  input  wire logic [31:0]             c_err_addr,
  input  wire logic [31:0]             c_bytes,
  output logic                         j_valid,
  input  wire logic                    j_ready,
  output logic [15:0]                  j_tag,
  output logic [MW-1:0]                j_m,
  output logic [NW-1:0]                j_n,
  output logic [16:0]                  j_k,
  output logic [39:0]                  j_ktot,
  output logic [15:0]                  j_nch,
  output logic [15:0]                  j_chunk,
  output logic [31:0]                  j_lda,
  output logic [31:0]                  j_ldb,
  output logic                         q_valid,
  input  wire logic                    q_ready,
  output logic [255:0]                 q_data,
  input  wire logic                    dma_busy,
  input  wire logic                    cmp_busy,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [4:0]              cmp_err,          // bit 0 is unused by tdma_compute_seq
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic                    tq_idle,
  input  wire logic                    acc_cfg_hs,
  input  wire logic [SLOT_W-1:0]       acc_cfg_slot,
  input  wire logic                    mon_acc_range,
  input  wire logic                    mon_acc_cfg,
  input  wire logic                    mon_acc_beat,
  input  wire logic                    mon_acc_ovf,
  input  wire logic                    mon_ob_werr,
  input  wire logic                    mon_tq_rej,
  input  wire logic                    mon_tq_beat,
  input  wire logic                    mon_dma_proto,
  input  wire logic [SATW-1:0]         sat_inc,
  input  wire logic                    progress,
  // ---------------------------------------------------------- bus gate
  output logic                         g_qreq,
  input  wire logic                    g_quiesced,
  // ---------------------------------------------------------- events (1-cycle; counts where noted)
  output logic                         ev_commit,
  output logic                         ev_commit_err,     // ERROR or SKIPPED
  output logic                         ev_commit_irq,
  output logic                         ev_gemm_ok,
  output logic                         ev_tile,
  output logic                         ev_job,
  output logic [31:0]                  ev_macs,           // MACs of the job accepted this cycle
  output logic                         ev_desc,
  output logic                         ev_rec_stall,
  output logic                         ev_abort
);
  // ============================================================ state
  localparam logic [3:0] S_IDLE = `TSU_S_IDLE, S_DECODE = `TSU_S_DECODE, S_PREP = `TSU_S_PREP, S_RUN = `TSU_S_RUN,
                         S_QUIESCE = `TSU_S_QUIESCE, S_SRST = `TSU_S_SRST, S_RECORD = `TSU_S_RECORD,
                         S_FLUSH = `TSU_S_FLUSH, S_HALT = `TSU_S_HALT;
  logic [3:0] st;
  assign state = st;

  // ============================================================ current command
  logic [`TSU_DESC_W-1:0] cd;
  logic [31:0] w [`TSU_DESC_WORDS];
  always_comb for (int i = 0; i < `TSU_DESC_WORDS; i++) w[i] = cd[32*i +: 32];

  logic [7:0]  f_op, f_tid;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [7:0]  f_flags;                  // BARRIER and reserved bits have no effect here
  /* verilator lint_on UNUSEDSIGNAL */
  logic [2:0]  f_rm;
  logic [31:0] f_a, f_b, f_c, f_lda, f_ldb, f_ldc, f_qmult;
  logic [15:0] f_m, f_n;
  logic [16:0] f_k;
  logic        f_relu;
  logic [5:0]  f_qshift;
  logic [7:0]  f_qzp;
  assign f_op     = w[0][7:0];
  assign f_rm     = w[0][14:12];
  assign f_flags  = w[0][23:16];
  assign f_tid    = w[0][31:24];
  assign f_a      = w[1];
  assign f_b      = w[2];
  assign f_c      = w[3];
  assign f_m      = w[4][15:0];
  assign f_n      = w[4][31:16];
  assign f_k      = w[5][16:0];
  assign f_lda    = w[6];
  assign f_ldb    = w[7];
  assign f_ldc    = w[8];
  assign f_relu   = w[9][14];
  assign f_qmult  = w[10];
  assign f_qshift = w[11][5:0];
  assign f_qzp    = w[11][15:8];

  // ============================================================ validation
  logic        v_start, v_done, v_gemm, v_int8;
  logic [7:0]  v_code;
  logic [16:0] v_kc;
  logic [15:0] v_nch;
  logic [31:0] v_kcldb;
  tsu_validate #(.TILE_K(TILE_K), .K_MAX(K_MAX), .QUANT_EN(QUANT_EN), .DBUF_EN(DBUF_EN),
                 .MEM_LO(MEM_LO), .MEM_HI(MEM_HI)) u_val (
    .clk(clk), .rst_n(rst_n), .start(v_start), .desc(cd), .done(v_done), .code(v_code),
    .is_gemm(v_gemm), .out_int8(v_int8), .kc_eff(v_kc), .n_chunks(v_nch), .kc_ldb(v_kcldb));

  // ============================================================ per-command registers
  logic        r_int8, r_nmajor;
  logic [16:0] r_kc;
  logic [15:0] r_nch;
  logic [31:0] r_kcldb, r_tm_lda, r_tm_ldc, r_tn_esz;
  localparam logic [31:0] LDB_LOC = 32'((TILE_N + 3) / 4 * 4);

  function automatic logic [31:0] lda_loc(input logic [16:0] ek);
    logic [17:0] r4;
    r4 = (18'(ek) + 18'd3) & ~18'd3;
    lda_loc = r4[2] ? 32'(r4) : 32'(r4) + 32'd4;      // odd word stride: A rows in distinct TC03 banks
  endfunction

  // ============================================================ iterators (TC06 ttc_tile_iter, unmodified)
  logic        it_init, d_adv, jj_adv;
  logic [15:0] d_m0, d_n0, j_m0, j_kidx;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [15:0] d_kidx, j_n0;             // not needed: chunk index / tile column come from the other stream
  logic        d_first, j_first, j_laststep;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [16:0] d_k0, d_ek, j_k0, j_ek;
  logic [MW-1:0] d_em, j_em;
  logic [NW-1:0] d_en, j_en;
  logic        d_lastk, d_laststep, d_done, j_lastk, j_done;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] d_sidx, j_sidx;
  logic [16:0] j_k0_u;
  /* verilator lint_on UNUSEDSIGNAL */
  ttc_tile_iter #(.TILE_M(TILE_M), .TILE_N(TILE_N)) u_dit (
    .clk(clk), .rst_n(rst_n), .init(it_init), .adv(d_adv), .nmajor(r_nmajor), .m(f_m), .n(f_n), .k(f_k), .kc(r_kc),
    .m0(d_m0), .n0(d_n0), .k0(d_k0), .kidx(d_kidx), .eff_m(d_em), .eff_n(d_en), .eff_k(d_ek), .first_k(d_first),
    .last_k(d_lastk), .last_step(d_laststep), .done(d_done), .step_idx(d_sidx));
  ttc_tile_iter #(.TILE_M(TILE_M), .TILE_N(TILE_N)) u_jit (
    .clk(clk), .rst_n(rst_n), .init(it_init), .adv(jj_adv), .nmajor(r_nmajor), .m(f_m), .n(f_n), .k(f_k), .kc(r_kc),
    .m0(j_m0), .n0(j_n0), .k0(j_k0), .kidx(j_kidx), .eff_m(j_em), .eff_n(j_en), .eff_k(j_ek), .first_k(j_first),
    .last_k(j_lastk), .last_step(j_laststep), .done(j_done), .step_idx(j_sidx));
  assign j_k0_u = j_k0;

  // ============================================================ RUN bookkeeping
  logic        err_seen, abort_pend, halt_after;
  logic [7:0]  e_code;
  logic [3:0]  e_detail;
  logic [31:0] e_addr;
  logic [1:0]  r_status;
  logic        r_sat;
  logic [31:0] n_desc, n_cpl, bytes_ok, tiles_ok, cyc, wd;
  logic [1:0]  dsub;                     // 0 LOAD_A, 1 LOAD_B, 2 STORE
  logic        jsub_open;                // next job-side item is a TC05 OPEN
  logic [7:0]  d_id;
  logic [15:0] tile_tag;
  logic [SLOT_W-1:0] slot_pred, slot_chk;
  logic [31:0] a_row, b_col, c_row, c_col, kofs_b;
  logic [4:0]  srst_cnt;
  logic        run_go;

  wire stop_run = err_seen || abort_pend;
  assign run_go = (st == S_RUN) && !stop_run;

  // ------------------------------------------------------------ descriptor stream
  logic [`TDMA_DESC_W-1:0] dd;
  always_comb begin
    dd = '0;
    dd[`TDMA_D_ID]   = d_id;
    dd[`TDMA_D_VER]  = `TDMA_VERSION;
    dd[`TDMA_D_RSVD] = 8'd0;
    case (dsub)
      2'd0: begin                                              // LOAD_A: eff_m rows x eff_k bytes
        dd[`TDMA_D_SRC]     = a_row + 32'(d_k0);
        dd[`TDMA_D_DST]     = 32'd0;
        dd[`TDMA_D_SSTRIDE] = f_lda;
        dd[`TDMA_D_DSTRIDE] = lda_loc(d_ek);
        dd[`TDMA_D_ROWLEN]  = d_ek[15:0];
        dd[`TDMA_D_ROWS]    = 16'(d_em);
        dd[`TDMA_D_KIND]    = `TDMA_K_LOAD_A;
        dd[`TDMA_D_FLAGS]   = 6'd0;
      end
      2'd1: begin                                              // LOAD_B: eff_k rows x eff_n bytes, SEAL
        dd[`TDMA_D_SRC]     = b_col + kofs_b;
        dd[`TDMA_D_DST]     = 32'd0;
        dd[`TDMA_D_SSTRIDE] = f_ldb;
        dd[`TDMA_D_DSTRIDE] = LDB_LOC;
        dd[`TDMA_D_ROWLEN]  = 16'(d_en);
        dd[`TDMA_D_ROWS]    = d_ek[15:0];
        dd[`TDMA_D_KIND]    = `TDMA_K_LOAD_B;
        dd[`TDMA_D_FLAGS]   = 6'(1 << `TDMA_F_SEAL);
      end
      default: begin                                           // STORE: eff_m rows x eff_n*esz bytes, SEAL
        dd[`TDMA_D_SRC]     = 32'd0;
        dd[`TDMA_D_DST]     = c_row + c_col;
        dd[`TDMA_D_SSTRIDE] = 32'(O_LD);
        dd[`TDMA_D_DSTRIDE] = f_ldc;
        dd[`TDMA_D_ROWLEN]  = r_int8 ? 16'(d_en) : 16'({d_en, 2'b00});
        dd[`TDMA_D_ROWS]    = 16'(d_em);
        dd[`TDMA_D_KIND]    = `TDMA_K_STORE;
        dd[`TDMA_D_FLAGS]   = 6'(1 << `TDMA_F_SEAL);
      end
    endcase
  end
  assign d_data  = dd;
  assign d_valid = run_go && !d_done;
  wire   d_hs    = d_valid && d_ready;
  assign d_adv   = d_hs && ((dsub == 2'd2) || (dsub == 2'd1 && !d_lastk));

  // ------------------------------------------------------------ job stream
  assign j_tag   = tile_tag;
  assign j_m     = j_em;
  assign j_n     = j_en;
  assign j_k     = j_ek;
  assign j_ktot  = 40'(f_k);
  assign j_nch   = r_nch;
  assign j_chunk = j_kidx;
  assign j_lda   = lda_loc(j_ek);
  assign j_ldb   = LDB_LOC;
  assign j_valid = run_go && !j_done && !jsub_open;
  wire   j_hs    = j_valid && j_ready;
  assign jj_adv  = j_hs;

  // TC05 OPEN descriptor (tensor_quantize_pkg ABI v1, per-tensor requantisation)
  always_comb begin
    q_data = '0;
    q_data[7:0]     = 8'h40;                                   // OP_OPEN
    q_data[11:8]    = 4'd1;                                    // VERSION
    q_data[14:12]   = f_rm;
    q_data[23:16]   = 8'(2 | (f_relu ? 8 : 0));                // RQ | RELU
    q_data[27:24]   = 4'd1;                                    // OFMT_INT8
    q_data[47:32]   = tile_tag;                                // TAG
    q_data[55:48]   = 8'(slot_pred);                           // CTX = the TC04 slot of this tile
    q_data[71:64]   = 8'(j_em);                                // M
    q_data[79:72]   = 8'(j_en);                                // N
    q_data[95:80]   = 16'd0;                                   // CH_GRP (table unused: per-tensor)
    q_data[127:96]  = 32'(j_m0);                               // M0
    q_data[159:128] = f_qmult;                                 // MULT
    q_data[165:160] = f_qshift;                                // SHIFT (ZA = ZB = 0)
    q_data[223:192] = {{24{f_qzp[7]}}, f_qzp};                 // ZP
  end
  assign q_valid = run_go && !j_done && jsub_open;
  wire   q_hs    = q_valid && q_ready;

  // ------------------------------------------------------------ completions from the adapter
  assign c_ready = 1'b1;
  wire c_hs = c_valid;

  // ------------------------------------------------------------ RUN completion condition
  wire run_complete = d_done && j_done && (n_cpl == n_desc) && !c_valid && !dma_busy && !cmp_busy && tq_idle;

  // ------------------------------------------------------------ error capture (first wins, priority within a cycle)
  logic       ex_err;
  logic [7:0] ex_code;
  logic [3:0] ex_det;
  logic [31:0] ex_addr;
  always_comb begin
    ex_err = 1'b0; ex_code = `TSU_E_NONE; ex_det = 4'd0; ex_addr = 32'd0;
    if (c_hs && c_code != `TDMA_C_OK) begin
      ex_err = 1'b1; ex_det = c_code; ex_addr = c_err_addr;
      case (c_code)
        `TDMA_C_RD_BUS:                  ex_code = `TSU_E_DMA_READ;
        `TDMA_C_WR_BUS:                  ex_code = `TSU_E_DMA_WRITE;
        `TDMA_C_LOC_RD, `TDMA_C_LOC_WR:  begin ex_code = `TSU_E_BUF_ACCESS; ex_det = {1'b0, c_detail}; end
        `TDMA_C_PROTO:                   ex_code = `TSU_E_DMA_PROTO;
        default:                         ex_code = `TSU_E_DMA_REJECT;
      endcase
    end else if (mon_acc_range) begin ex_err = 1'b1; ex_code = `TSU_E_ACC_OVF;  ex_det = `TSU_IE_ACC_RANGE; end
    else if (mon_acc_ovf)       begin ex_err = 1'b1; ex_code = `TSU_E_ACC_OVF;  ex_det = `TSU_IE_ACC_OVF;   end
    else if (mon_acc_cfg)       begin ex_err = 1'b1; ex_code = `TSU_E_COMPUTE;  ex_det = `TSU_IE_ACC_CFG;   end
    else if (mon_acc_beat)      begin ex_err = 1'b1; ex_code = `TSU_E_COMPUTE;  ex_det = `TSU_IE_ACC_BEAT;  end
    else if (cmp_err[1])        begin ex_err = 1'b1; ex_code = `TSU_E_COMPUTE;  ex_det = `TSU_IE_TILE_REJ;  end
    else if (cmp_err[2])        begin ex_err = 1'b1; ex_code = `TSU_E_COMPUTE;  ex_det = `TSU_IE_ARR;       end
    else if (cmp_err[3])        begin ex_err = 1'b1; ex_code = `TSU_E_COMPUTE;  ex_det = `TSU_IE_ACC_CFG;   end
    else if (cmp_err[4])        begin ex_err = 1'b1; ex_code = `TSU_E_COMPUTE;  ex_det = `TSU_IE_ACC_BEAT;  end
    else if (mon_ob_werr)       begin ex_err = 1'b1; ex_code = `TSU_E_OUTBUF;   ex_det = `TSU_IE_OB_WRITE;  end
    else if (mon_tq_rej)        begin ex_err = 1'b1; ex_code = `TSU_E_QUANT;    ex_det = `TSU_IE_Q_DESC;    end
    else if (mon_tq_beat)       begin ex_err = 1'b1; ex_code = `TSU_E_QUANT;    ex_det = `TSU_IE_Q_BEAT;    end
    else if (mon_dma_proto)     begin ex_err = 1'b1; ex_code = `TSU_E_DMA_PROTO; end
  end

  // ------------------------------------------------------------ queue / record handshakes
  wire flush_hs = (st == S_FLUSH) && cq_valid && rec_ready;
  assign cq_ready = ((st == S_IDLE) && !abort_pend) || flush_hs;
  wire deq = (st == S_IDLE) && !abort_pend && cq_valid;

  logic [31:0] seq;
  logic [`TSU_CPL_W-1:0] rec;
  always_comb begin
    rec = '0;
    if (st == S_FLUSH) begin
      rec[7:0]   = cq_data[31:24];                 // TID
      rec[15:8]  = cq_data[7:0];                   // OPCODE
      rec[23:16] = `TSU_E_ABORTED;
      rec[25:24] = `TSU_ST_SKIPPED;
      rec[26]    = cq_data[16 + `TSU_FL_IRQ];
    end else begin
      rec[7:0]   = f_tid;
      rec[15:8]  = f_op;
      rec[23:16] = e_code;
      rec[25:24] = r_status;
      rec[26]    = f_flags[`TSU_FL_IRQ];
      rec[27]    = r_sat;
      rec[31:28] = e_detail;
      rec[63:32] = bytes_ok;
      rec[95:64] = e_addr;
      rec[159:128] = cyc;
      rec[191:160] = tiles_ok;
    end
    rec[127:96] = seq;
  end
  assign rec_data  = rec;
  assign rec_valid = (st == S_RECORD) || (st == S_FLUSH && cq_valid);
  wire rec_hs = rec_valid && rec_ready;

  // ------------------------------------------------------------ control outputs
  assign v_start     = (st == S_DECODE) && (wd == 32'd0) && !(err_sticky && !ctrl_err_cont);
  assign it_init     = (st == S_PREP);
  assign dp_srst     = (st == S_SRST) && (srst_cnt > 5'd2);
  assign g_qreq      = (st == S_QUIESCE) || (st == S_SRST) || (st == S_HALT);
  assign busy        = (st != S_IDLE);
  assign aborting    = abort_pend;
  assign halted      = (st == S_HALT);

  // ------------------------------------------------------------ events
  assign ev_commit     = rec_hs;
  assign ev_commit_err = rec_hs && (rec[25:24] != `TSU_ST_OK);
  assign ev_commit_irq = rec_hs && rec[26];
  assign ev_gemm_ok    = rec_hs && (st == S_RECORD) && (f_op == `TSU_OP_GEMM) && (r_status == `TSU_ST_OK);
  assign ev_tile       = c_hs && (c_kind == `TDMA_K_STORE) && (c_code == `TDMA_C_OK);
  assign ev_job        = j_hs;
  assign ev_macs       = j_hs ? 32'(j_em) * 32'(j_en) * 32'(j_ek) : 32'd0;
  assign ev_desc       = d_hs;
  assign ev_rec_stall  = rec_valid && !rec_ready;
  assign ev_abort      = (st == S_QUIESCE) && g_quiesced;

  localparam logic [31:0] WD_LIM = 32'(1) << WDOG_LOG2;

  // ============================================================ sequential
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; cd <= '0; err_sticky <= 1'b0; abort_pend <= 1'b0; halt_after <= 1'b0;
      err_seen <= 1'b0; e_code <= '0; e_detail <= '0; e_addr <= '0; r_status <= '0; r_sat <= 1'b0;
      n_desc <= '0; n_cpl <= '0; bytes_ok <= '0; tiles_ok <= '0; cyc <= '0; wd <= '0;
      dsub <= '0; jsub_open <= 1'b0; d_id <= '0; tile_tag <= '0; slot_pred <= '0; slot_chk <= '0;
      a_row <= '0; b_col <= '0; c_row <= '0; c_col <= '0; kofs_b <= '0; srst_cnt <= '0; seq <= '0;
      r_int8 <= 1'b0; r_nmajor <= 1'b0; r_kc <= 17'd1; r_nch <= '0; r_kcldb <= '0;
      r_tm_lda <= '0; r_tm_ldc <= '0; r_tn_esz <= '0; dp_prefetch <= 1'b0; dp_int8 <= 1'b0;
    end else begin
      if (ctrl_abort) abort_pend <= 1'b1;
      if (ctrl_err_clear) err_sticky <= 1'b0;
      if (st != S_IDLE && st != S_FLUSH && st != S_HALT && cyc != 32'hFFFF_FFFF) cyc <= cyc + 32'd1;
      if (rec_hs) seq <= seq + 32'd1;

      case (st)
        // ---------------------------------------------------------------- IDLE
        S_IDLE: begin
          if (abort_pend) st <= S_FLUSH;
          else if (deq) begin
            cd <= cq_data; st <= S_DECODE; cyc <= 32'd1; wd <= '0;
            err_seen <= 1'b0; e_code <= `TSU_E_NONE; e_detail <= '0; e_addr <= '0; r_sat <= 1'b0;
            bytes_ok <= '0; tiles_ok <= '0; r_status <= `TSU_ST_OK;
          end
        end
        // ---------------------------------------------------------------- DECODE
        S_DECODE: begin
          wd <= wd + 32'd1;                                     // wd = 0 on entry: start pulse
          if (err_sticky && !ctrl_err_cont) begin
            r_status <= `TSU_ST_SKIPPED; e_code <= `TSU_E_PRIOR; st <= S_RECORD;
          end else if (v_done) begin
            if (v_code != `TSU_E_NONE) begin
              r_status <= `TSU_ST_ERROR; e_code <= v_code; st <= S_RECORD;
            end else if (!v_gemm) begin
              st <= S_RECORD;                                   // NOP
            end else if (abort_pend) begin
              r_status <= `TSU_ST_ERROR; e_code <= `TSU_E_ABORTED; st <= S_RECORD;
            end else begin
              r_int8   <= v_int8;
              r_nmajor <= f_flags[`TSU_FL_NMAJOR];
              r_kc     <= v_kc;
              r_nch    <= v_nch;
              r_kcldb  <= v_kcldb;
              r_tm_lda <= 32'(TILE_M) * f_lda;
              r_tm_ldc <= 32'(TILE_M) * f_ldc;
              r_tn_esz <= v_int8 ? 32'(TILE_N) : 32'(4 * TILE_N);
              dp_prefetch <= f_flags[`TSU_FL_PREFETCH] && (DBUF_EN != 0);
              dp_int8     <= v_int8 && (QUANT_EN != 0);
              st <= S_PREP;
            end
          end
        end
        // ---------------------------------------------------------------- PREP (iterators initialised)
        S_PREP: begin
          a_row <= f_a; b_col <= f_b; c_row <= f_c; c_col <= '0; kofs_b <= '0;
          dsub <= 2'd0; jsub_open <= r_int8; n_desc <= '0; n_cpl <= '0; wd <= '0;
          st <= S_RUN;
        end
        // ---------------------------------------------------------------- RUN
        S_RUN: begin
          // descriptor iterator + incremental address pointers
          if (d_hs) begin
            n_desc <= n_desc + 32'd1;
            d_id   <= d_id + 8'd1;
            case (dsub)
              2'd0:    dsub <= 2'd1;
              2'd1:    dsub <= d_lastk ? 2'd2 : 2'd0;
              default: dsub <= 2'd0;
            endcase
            if (d_adv && !d_laststep) begin
              if (!d_lastk) kofs_b <= kofs_b + r_kcldb;
              else begin
                kofs_b <= '0;
                if (!r_nmajor) begin
                  if (17'(d_n0) + 17'(TILE_N) < 17'(f_n)) begin b_col <= b_col + 32'(TILE_N); c_col <= c_col + r_tn_esz; end
                  else begin b_col <= f_b; c_col <= '0; a_row <= a_row + r_tm_lda; c_row <= c_row + r_tm_ldc; end
                end else begin
                  if (17'(d_m0) + 17'(TILE_M) < 17'(f_m)) begin a_row <= a_row + r_tm_lda; c_row <= c_row + r_tm_ldc; end
                  else begin a_row <= f_a; c_row <= f_c; b_col <= b_col + 32'(TILE_N); c_col <= c_col + r_tn_esz; end
                end
              end
            end
          end
          // job iterator
          if (q_hs) jsub_open <= 1'b0;
          if (j_hs && j_lastk) begin
            tile_tag  <= tile_tag + 16'd1;
            slot_pred <= (NUM_SLOTS > 1) ? slot_pred + SLOT_W'(1) : slot_pred;
            jsub_open <= r_int8;
          end
          // completions
          if (c_hs) begin
            n_cpl <= n_cpl + 32'd1;
            if (c_kind == `TDMA_K_STORE) begin
              bytes_ok <= bytes_ok + c_bytes;
              if (c_code == `TDMA_C_OK) tiles_ok <= tiles_ok + 32'd1;
            end
          end
          if (sat_inc != '0) r_sat <= 1'b1;
          // watchdog: cycles without any datapath handshake
          if (progress || d_hs || q_hs) wd <= '0;
          else if (wd != WD_LIM) wd <= wd + 32'd1;
          // first error wins
          if (!err_seen) begin
            if (ex_err) begin
              err_seen <= 1'b1; e_code <= ex_code; e_detail <= ex_det; e_addr <= ex_addr;
            end else if (abort_pend) begin
              err_seen <= 1'b1; e_code <= `TSU_E_ABORTED;
            end else if (wd == WD_LIM) begin
              err_seen <= 1'b1; e_code <= `TSU_E_TIMEOUT;
            end
          end
          if (stop_run || ex_err || wd == WD_LIM) begin
            st <= S_QUIESCE; wd <= '0; r_status <= `TSU_ST_ERROR;
          end else if (run_complete) begin
            st <= S_RECORD; r_status <= `TSU_ST_OK;
          end
        end
        // ---------------------------------------------------------------- QUIESCE (bus port drained)
        S_QUIESCE: begin
          if (c_hs && c_kind == `TDMA_K_STORE) begin
            bytes_ok <= bytes_ok + c_bytes;
            if (c_code == `TDMA_C_OK) tiles_ok <= tiles_ok + 32'd1;
          end
          if (g_quiesced) begin st <= S_SRST; srst_cnt <= 5'(SRST_CYCLES + 2); end
          else if (wd == WD_LIM) begin
            halt_after <= 1'b1; st <= S_RECORD;
            if (e_code == `TSU_E_NONE) e_code <= `TSU_E_TIMEOUT;
          end else if (progress) wd <= '0;                    // responses still arriving: keep draining
          else wd <= wd + 32'd1;
        end
        // ---------------------------------------------------------------- SRST (datapath reset, then 2 settle cycles)
        S_SRST: begin
          if (srst_cnt == 5'd1) begin
            st <= S_RECORD; dsub <= 2'd0; jsub_open <= 1'b0; slot_pred <= '0; slot_chk <= '0;
            dp_prefetch <= 1'b0; dp_int8 <= 1'b0;
          end
          srst_cnt <= srst_cnt - 5'd1;
        end
        // ---------------------------------------------------------------- RECORD
        S_RECORD: if (rec_ready) begin
          if (r_status == `TSU_ST_ERROR) err_sticky <= 1'b1;
          if (halt_after)      st <= S_HALT;
          else if (abort_pend) st <= S_FLUSH;
          else                 st <= S_IDLE;
        end
        // ---------------------------------------------------------------- FLUSH (abort: queued commands SKIPPED)
        S_FLUSH: if (!cq_valid) begin abort_pend <= 1'b0; st <= S_IDLE; end
        // ---------------------------------------------------------------- HALT (only a hard reset leaves it)
        default: st <= S_HALT;
      endcase

      if (acc_cfg_hs) slot_chk <= (NUM_SLOTS > 1) ? slot_chk + SLOT_W'(1) : slot_chk;
    end
  end

`ifndef SYNTHESIS
  // ============================================================ self-checks (simulation only)
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    // incremental pointers == the products of the GEMM contract
    if (d_hs) begin : chk_ptr
      logic [63:0] ea, eb, ec;
      ea = 64'(f_a) + 64'(d_m0) * 64'(f_lda) + 64'(d_k0);
      eb = 64'(f_b) + 64'(d_k0) * 64'(f_ldb) + 64'(d_n0);
      ec = 64'(f_c) + 64'(d_m0) * 64'(f_ldc) + (r_int8 ? 64'(d_n0) : 64'(d_n0) * 64'd4);
      if (dsub == 2'd0 && 64'(dd[`TDMA_D_SRC]) != ea) $error("tsu_sched: LOAD_A source %h != %h", dd[`TDMA_D_SRC], ea);
      if (dsub == 2'd1 && 64'(dd[`TDMA_D_SRC]) != eb) $error("tsu_sched: LOAD_B source %h != %h", dd[`TDMA_D_SRC], eb);
      if (dsub == 2'd2 && 64'(dd[`TDMA_D_DST]) != ec) $error("tsu_sched: STORE destination %h != %h", dd[`TDMA_D_DST], ec);
    end
    // the TC05 context of a tile is the TC04 slot the compute sequencer opens for it
    if (acc_cfg_hs && acc_cfg_slot != slot_chk) $error("tsu_sched: TC04 slot %0d, expected %0d", acc_cfg_slot, slot_chk);
    if (q_hs && QUANT_EN == 0) $error("tsu_sched: TC05 descriptor without quantiser");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
