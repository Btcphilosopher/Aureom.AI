// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_defs.svh
// Shared command package of silicaflux_tensor_unit: the host command ABI
// (GEMM descriptor, completion record, error codes), the register map and the
// performance-counter map.  Aureom.AI | SilicaFlux-HPC
//
// SINGLE SOURCE.  scripts/gen_abi.py generates the C header
// (sw/include/tsu_abi.h) and the Python module (model/tsu_abi.py) from the
// `define lines below; scripts/check_abi.py checks that all three agree.
//
// A `define header, not a SystemVerilog package, following tdma_defs.svh /
// ttc_defs.svh / tob_defs.svh: Yosys 0.33 cannot resolve package references in
// module parameter lists, and every synthesizable module must elaborate in
// the three tools of the SilicaFlux baseline (see README).
//
// Values are ABI: never renumber, only append.  A layout change needs a new
// VERSION.
// =============================================================================
`ifndef TSU_DEFS_SVH
`define TSU_DEFS_SVH

// ----------------------------------------------------------------------------
// COMMAND DESCRIPTOR, VERSION 2 (384 bits = 12 little-endian 32-bit words)
//
// The header word is the HPC Module 06 header (OPCODE / VERSION / RM / FLAGS /
// TID at the same bit positions); VERSION 2 marks the 12-word layout (Module 06
// v1 is 8 words).  The GEMM layout is the one TENSORCORE 06 doc 02 sec. 5
// proposed for opcode class 0x4X, with words 10..11 used for requantisation.
//
//  word | bits     | field      | meaning
//  -----+----------+------------+------------------------------------------------
//   0   | [7:0]    | OPCODE     | 0x00 NOP, 0x40 TENSOR_GEMM; others reserved
//       | [11:8]   | VERSION    | must be 2
//       | [14:12]  | RM         | INT8 requantisation rounding mode (RNE 0, RTZ 1,
//       |          |            | RDN 2, RUP 3, RMM 4); 0 for INT32 output / NOP
//       | [15]     | -          | reserved, 0
//       | [23:16]  | FLAGS      | bit0 IRQ, bit1 BARRIER, bit2 PREFETCH, bit3 NMAJOR
//       | [31:24]  | TID        | transaction id, echoed in the completion record
//   1   | [31:0]   | A_BASE     | byte address of A[0][0]   (INT8, row-major)
//   2   | [31:0]   | B_BASE     | byte address of B[0][0]   (INT8, row-major)
//   3   | [31:0]   | C_BASE     | byte address of C[0][0]   (INT32 or INT8, row-major)
//   4   | [15:0]   | M          | rows of A and C, 1..65535
//       | [31:16]  | N          | columns of B and C, 1..65535
//   5   | [16:0]   | K          | columns of A / rows of B, 1..K_MAX (<= 131071)
//       | [31:17]  | KC         | K chunk length, 0 = TILE_K, else 1..TILE_K
//   6   | [31:0]   | LDA        | A row stride in bytes (>= K)
//   7   | [31:0]   | LDB        | B row stride in bytes (>= N)
//   8   | [31:0]   | LDC        | C row stride in bytes (>= N * element size)
//   9   | [1:0]    | A_TYPE     | 0 INT8 (only supported value)
//       | [3:2]    | B_TYPE     | 0 INT8 (only supported value)
//       | [5:4]    | OUT_FMT    | 0 INT32 (exact), 1 INT8 (requantised, needs
//       |          |            | ENABLE_QUANTIZATION); 2, 3 reserved
//       | [7:6]    | -          | reserved, 0
//       | [9:8]    | A_LAYOUT   | 0 row-major (only supported value)
//       | [11:10]  | B_LAYOUT   | 0 row-major
//       | [13:12]  | C_LAYOUT   | 0 row-major
//       | [14]     | RELU       | INT8 output only: q = max(q, Q_ZP)
//       | [31:15]  | -          | reserved, 0
//  10   | [31:0]   | Q_MULT     | INT8 output only: signed multiplier M
//  11   | [5:0]    | Q_SHIFT    | INT8 output only: right shift S, 0..63
//       | [7:6]    | -          | reserved, 0
//       | [15:8]   | Q_ZP       | INT8 output only: signed output zero-point
//       | [31:16]  | -          | reserved, 0
//
//  C[m][n] = sum_k A[m][k] * B[k][n]           (exact, INT32 accumulation)
//  A[m][k] at A_BASE + m*LDA + k,  B[k][n] at B_BASE + k*LDB + n
//  INT32 output: C[m][n] at C_BASE + m*LDC + 4n (little endian, 4-aligned)
//  INT8 output : C[m][n] at C_BASE + m*LDC + n, value
//                clamp(R_rm(acc * Q_MULT / 2^Q_SHIFT) + Q_ZP, -128, 127)
//                [then max(., Q_ZP) if RELU]   (TENSORCORE 05 contract)
// Units: every address and stride is in BYTES; no alignment is required for A,
// B, LDA, LDB, or for C with INT8 output.  INT32 C needs C_BASE, LDC 4-aligned.
// ----------------------------------------------------------------------------
`define TSU_DESC_WORDS      12
`define TSU_DESC_W          384
`define TSU_ABI_VERSION     4'd2

// opcodes
`define TSU_OP_NOP          8'h00
`define TSU_OP_GEMM         8'h40

// FLAGS (header bits 23:16)
`define TSU_FL_IRQ          0      // pulse the IRQ event when this command commits
`define TSU_FL_BARRIER      1      // start after every older command completed (always true: in-order, one at a time)
`define TSU_FL_PREFETCH     2      // double-buffered overlap of DMA and compute (needs ENABLE_DOUBLE_BUFFERING)
`define TSU_FL_NMAJOR       3      // N-major tile traversal (default M-major)
`define TSU_FL_MASK         8'h0F  // bits 4..7 reserved

// word-9 format fields
`define TSU_TYPE_INT8       2'd0
`define TSU_LAYOUT_ROW      2'd0
`define TSU_OFMT_INT32      2'd0
`define TSU_OFMT_INT8       2'd1
`define TSU_W9_RSVD_MASK    32'hFFFF_80C0   // bits 31:15 and 7:6
`define TSU_W11_RSVD_MASK   32'hFFFF_00C0   // bits 31:16 and 7:6

// rounding modes (Module 02 / RISC-V frm encoding, as TENSORCORE 05)
`define TSU_RM_RNE          3'd0
`define TSU_RM_RTZ          3'd1
`define TSU_RM_RDN          3'd2
`define TSU_RM_RUP          3'd3
`define TSU_RM_RMM          3'd4

// ----------------------------------------------------------------------------
// COMPLETION RECORD (192 bits = 6 words).  Words 0..3 have the HPC Module 06
// record layout; words 4..5 are appended.
//
//  word | bits     | field      | meaning
//  -----+----------+------------+------------------------------------------------
//   0   | [7:0]    | TID        | echo
//       | [15:8]   | OPCODE     | echo (also for rejected opcodes)
//       | [23:16]  | ERR_CODE   | TSU_E_*; 0 when STATUS = OK
//       | [25:24]  | STATUS     | 0 OK, 1 ERROR, 2 SKIPPED
//       | [26]     | IRQ        | echo of FLAGS.IRQ
//       | [27]     | SAT        | INT8 output: at least one element saturated
//       | [31:28]  | DETAIL     | sub-code: TDMA completion code for DMA_*, local
//       |          |            | buffer error code for BUF_ACCESS, TSU_IE_* for
//       |          |            | COMPUTE / OUTBUF / QUANT
//   1   | [31:0]   | COUNT      | C bytes written AND acknowledged by memory
//       |          |            | (= M*N*element size on success)
//   2   | [31:0]   | ERR_ADDR   | failing bus address (DMA errors), else 0
//   3   | [31:0]   | SEQ        | n-th command accepted since reset (0, 1, 2 ...)
//   4   | [31:0]   | CYCLES     | cycles from dequeue to record (saturating)
//   5   | [31:0]   | TILES      | output tiles stored and acknowledged
// ----------------------------------------------------------------------------
`define TSU_CPL_WORDS       6
`define TSU_CPL_W           192

`define TSU_ST_OK           2'd0
`define TSU_ST_ERROR        2'd1
`define TSU_ST_SKIPPED      2'd2

// error codes (8 bits).  0x01..0x0F: validation, first failing rule wins, NO side
// effect (no bus access, no buffer write).  0x18..0x3F: execution errors; the
// unit stops issuing, quiesces its bus port, resets its datapath, then reports.
// 0x40: not executed (stop-on-error).
`define TSU_E_NONE          8'h00
`define TSU_E_VERSION       8'h01  // VERSION != 2
`define TSU_E_OPCODE        8'h02  // reserved opcode
`define TSU_E_FLAGS         8'h03  // reserved flag, PREFETCH without double buffering, GEMM-only flag on NOP
`define TSU_E_RSVD          8'h04  // reserved bit / unused field non-zero
`define TSU_E_RM            8'h05  // rounding mode 5..7
`define TSU_E_LAYOUT        8'h06  // A, B or C layout not row-major (never silently transposed)
`define TSU_E_PRECISION     8'h07  // A/B type not INT8, or output format unsupported in this build
`define TSU_E_DIM_ZERO      8'h08  // M, N or K is 0
`define TSU_E_DIM_RANGE     8'h09  // K > K_MAX
`define TSU_E_CHUNK         8'h0A  // KC > TILE_K, or ceil(K/KC) > 65535 chunks
`define TSU_E_LD            8'h0B  // LDA < K, LDB < N or LDC < N * element size
`define TSU_E_ALIGN         8'h0C  // INT32 output: C_BASE or LDC not 4-aligned
`define TSU_E_ADDR_OVF      8'h0D  // last byte of A, B or C >= 2^32
`define TSU_E_RANGE         8'h0E  // a footprint leaves the memory window [MEM_LO, MEM_HI)
`define TSU_E_ALIAS         8'h0F  // C footprint intersects the A or B footprint
`define TSU_E_DMA_READ      8'h18  // SFB2 read answered with an error (ERR_ADDR = word address)
`define TSU_E_DMA_WRITE     8'h19  // SFB2 write answered with an error (ERR_ADDR = word address)
`define TSU_E_DMA_REJECT    8'h1A  // the DMA adapter rejected a generated descriptor (DETAIL = TDMA code)
`define TSU_E_DMA_PROTO     8'h1B  // misrouted / duplicated local response inside the DMA adapter
`define TSU_E_BUF_ACCESS    8'h20  // an operand / output buffer refused an access (DETAIL 6 = ownership violation)
`define TSU_E_COMPUTE       8'h21  // the compute path refused a tile (DETAIL = TSU_IE_*)
`define TSU_E_OUTBUF        8'h22  // the output buffer flagged a malformed / failed row write
`define TSU_E_ACC_OVF       8'h28  // accumulator overflow possible (TC04 range check) or flagged (TC04 o_ovf)
`define TSU_E_QUANT         8'h29  // output conversion (TC05) rejected a descriptor or flagged a beat
`define TSU_E_TIMEOUT       8'h30  // no progress for 2^WDOG_LOG2 cycles
`define TSU_E_ABORTED       8'h38  // host abort (CTRL.ABORT)
`define TSU_E_PRIOR         8'h40  // SKIPPED: an older command failed, stop-on-error mode

// DETAIL sub-codes for COMPUTE / OUTBUF / QUANT / ACC_OVF
`define TSU_IE_TILE_REJ     4'd1   // TC03 rejected a tile descriptor
`define TSU_IE_ARR          4'd2   // TC02 rejected a launch or its alignment checker fired
`define TSU_IE_ACC_CFG      4'd3   // TC04 rejected a tile configuration (non-range reason)
`define TSU_IE_ACC_BEAT     4'd4   // TC04 dropped a malformed partial-sum beat
`define TSU_IE_ACC_RANGE    4'd5   // TC04 STRICT_RANGE: K could overflow the accumulator
`define TSU_IE_ACC_OVF      4'd6   // TC04 flagged an overflowed lane on a committed row
`define TSU_IE_OB_WRITE     4'd7   // output buffer row write failed
`define TSU_IE_OB_GATE      4'd8   // output buffer ownership gate refused a request
`define TSU_IE_Q_DESC       4'd9   // TC05 rejected an OPEN descriptor
`define TSU_IE_Q_BEAT       4'd10  // TC05 delivered a beat with an error code

// ----------------------------------------------------------------------------
// REGISTER PAGE (SilicaFlux-V register bus: rb_sel / rb_we / rb_addr[11:0] /
// rb_wdata -> rb_rdata / rb_err, answered in the strobe cycle; the contract of
// DataFabric dma_control_regs and HPC Module 06 hpc_cq_mmio).
// rb_err = 1: access refused, no effect (unmapped / misaligned offset, write to
// a read-only register, DOORBELL with a full queue, CPL_POP with no record).
// ----------------------------------------------------------------------------
`define TSU_ID_VALUE        32'h5346_5443   // "SFTC"
`define TSU_R_ID            12'h000  // RO  ID
`define TSU_R_INFO          12'h004  // RO  [3:0] ABI version, [7:4] log2 queue depth, [15:8] ARRAY_ROWS,
                                     //     [23:16] ARRAY_COLS, [24] ENABLE_QUANTIZATION,
                                     //     [25] ENABLE_DOUBLE_BUFFERING, [26] PERF_EN
`define TSU_R_CAPS          12'h008  // RO  [15:0] TILE_K, [23:16] DATA_WIDTH, [31:24] ACC_WIDTH
`define TSU_R_OPBUF         12'h00C  // RO  OPERAND_BUFFER_BYTES
`define TSU_R_MEM_LO        12'h010  // RO  first byte of the memory window
`define TSU_R_MEM_LAST      12'h014  // RO  last byte of the memory window
`define TSU_R_CTRL          12'h018  // RW  [0] ERR_CONT; W1 pulses (read 0): [1] ERR_CLEAR [2] PERF_CLEAR [3] ABORT
`define TSU_R_STATUS        12'h01C  // RO  see TSU_SB_*
`define TSU_R_INT_ENABLE    12'h020  // RW  [0] IRQ [1] ERR [2] DONE
`define TSU_R_INT_STATUS    12'h024  // W1C same bits; set wins over a same-cycle clear
`define TSU_R_SUBMITTED     12'h028  // RO  doorbells accepted since reset
`define TSU_R_KMAX          12'h02C  // RO  K_MAX of this build (largest legal K)
`define TSU_R_DESC0         12'h040  // RW  DESC0 .. DESC11 at 0x040 + 4*i (kept after DOORBELL)
`define TSU_R_DOORBELL      12'h070  // WO  submit the staged descriptor (refused while the queue is full)
`define TSU_R_CPL0          12'h080  // RO  CPL0 .. CPL5 at 0x080 + 4*i: head completion record (0 if none)
`define TSU_R_CPL_POP       12'h098  // WO  release the head record (refused if none)
`define TSU_R_PERF0         12'h100  // RO  PERF[i] at 0x100 + 4*i, i < TSU_NUM_PC
`define TSU_R_DMA_PERF0     12'h200  // RO  DMA adapter counter j at 0x200 + 4*j, j < 18 (TDMA_PC_*)

`define TSU_CTRL_ERR_CONT   0
`define TSU_CTRL_ERR_CLEAR  1
`define TSU_CTRL_PERF_CLEAR 2
`define TSU_CTRL_ABORT      3

`define TSU_SB_BUSY         0      // STATUS bits
`define TSU_SB_ERR_STICKY   1
`define TSU_SB_Q_FULL       2
`define TSU_SB_Q_EMPTY      3
`define TSU_SB_CPL_VALID    4
`define TSU_SB_ABORTING     5
`define TSU_SB_HALTED       6
`define TSU_SB_STATE_LO     8      // [11:8] scheduler state (TSU_S_*)
`define TSU_SB_QCOUNT_LO    16     // [23:16] commands queued
`define TSU_SB_QFREE_LO     24     // [31:24] free queue slots

`define TSU_INT_IRQ         0
`define TSU_INT_ERR         1
`define TSU_INT_DONE        2

// scheduler state (STATUS[11:8])
`define TSU_S_IDLE          4'd0
`define TSU_S_DECODE        4'd1   // command latched, validation running
`define TSU_S_PREP          4'd2   // per-command constants
`define TSU_S_RUN           4'd3   // descriptors / jobs issued, completions collected
`define TSU_S_QUIESCE       4'd4   // error / abort: bus port drained
`define TSU_S_SRST          4'd5   // datapath soft reset
`define TSU_S_RECORD        4'd6   // completion record pushed
`define TSU_S_FLUSH         4'd7   // abort: queued commands completed as SKIPPED
`define TSU_S_HALT          4'd8   // quiesce timed out: bus port held, hard reset needed

// ----------------------------------------------------------------------------
// PERFORMANCE COUNTERS (hpc_perf_counters, saturating 32-bit, PERF[i])
// The same increments leave the unit on perf_ev (performance event interface).
// ----------------------------------------------------------------------------
`define TSU_PC_CYCLES       0      // cycles
`define TSU_PC_BUSY         1      // cycles the scheduler is not idle
`define TSU_PC_CMD_ACCEPT   2      // doorbells accepted
`define TSU_PC_CMD_DONE     3      // completion records produced
`define TSU_PC_CMD_ERR      4      // records with STATUS ERROR or SKIPPED
`define TSU_PC_GEMM_OK      5      // GEMM commands completed OK
`define TSU_PC_TILES        6      // output tiles stored and acknowledged
`define TSU_PC_CHUNKS       7      // compute jobs (one K chunk of one tile) accepted by compute
`define TSU_PC_MACS         8      // useful MACs (eff_m * eff_n * eff_k per job)
`define TSU_PC_COMPUTE_CYC  9      // cycles the array is launched and not yet read out
`define TSU_PC_DMA_ACTIVE   10     // cycles the DMA adapter holds a descriptor
`define TSU_PC_OVERLAP      11     // cycles an SFB2 request is accepted while the array computes
`define TSU_PC_RD_WORDS     12     // SFB2 read requests accepted (one 32-bit word each)
`define TSU_PC_WR_WORDS     13     // SFB2 write requests accepted
`define TSU_PC_BUS_STALL    14     // cycles an SFB2 request is presented and not accepted
`define TSU_PC_DESC         15     // DMA descriptors issued
`define TSU_PC_Q_FULL       16     // cycles the command queue is full
`define TSU_PC_CPL_STALL    17     // cycles a record waits for completion-queue space
`define TSU_PC_SAT          18     // INT8 output elements saturated
`define TSU_PC_ABORTS       19     // execution errors / aborts that went through quiesce + soft reset
`define TSU_NUM_PC          20

`endif // TSU_DEFS_SVH
