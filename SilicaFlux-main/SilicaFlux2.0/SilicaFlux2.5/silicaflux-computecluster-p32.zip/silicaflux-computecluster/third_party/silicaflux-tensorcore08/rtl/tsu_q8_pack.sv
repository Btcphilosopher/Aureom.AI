// =============================================================================
// SilicaFlux TENSORCORE 08 :: tsu_q8_pack
// Packs one requantised INT8 tile row (TENSORCORE 05 out_q8, COLS bytes) into
// the INT32 lanes of the tensor output buffer, four bytes per lane:
//
//   lane l = { q8[4l+3], q8[4l+2], q8[4l+1], q8[4l] }    (little endian)
//   lane_mask = the first ceil(eff_n / 4) lanes, eff_n = popcount(col_mask)
//
// The output buffer writes lane l at r*O_LD + 4l, so row r of the INT8 tile
// occupies bytes [r*O_LD, r*O_LD + eff_n) of the set (plus padding up to the
// lane boundary, which the STORE descriptor never reads: its ROW_LEN is eff_n).
// TC05's col_mask is the tile mask (contiguous from lane 0; a FRAME error is
// flagged by TC05 otherwise), so the packed mask is contiguous too.
// Purely combinational.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module tsu_q8_pack #(
  parameter int  COLS = 4,
  localparam int NW   = $clog2(COLS + 1)
) (
  input  wire logic [COLS*8-1:0]  q8,
  input  wire logic [COLS-1:0]    col_mask,
  output logic      [COLS*32-1:0] data,
  output logic      [COLS-1:0]    lane_mask
);
  localparam int PL = (COLS + 3) / 4;           // packed lanes
  logic [NW-1:0] eff_n;
  logic [NW-1:0] n_lanes;

  always_comb begin
    eff_n = '0;
    for (int j = 0; j < COLS; j++) eff_n = eff_n + NW'(col_mask[j]);
  end
  assign n_lanes = NW'((32'(eff_n) + 32'd3) >> 2);

  always_comb begin
    data = '0;
    for (int l = 0; l < PL; l++)
      for (int b = 0; b < 4; b++)
        if (4 * l + b < COLS) data[32*l + 8*b +: 8] = q8[8*(4*l + b) +: 8];
    lane_mask = '0;
    for (int l = 0; l < COLS; l++) lane_mask[l] = (NW'(l) < n_lanes);
  end
endmodule

`default_nettype wire
