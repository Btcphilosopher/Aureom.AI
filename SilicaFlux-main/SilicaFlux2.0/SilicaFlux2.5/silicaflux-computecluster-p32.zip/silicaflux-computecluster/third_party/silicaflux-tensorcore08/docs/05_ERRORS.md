# 05 — Error detection and propagation

Every error the brief lists, how it is detected, what the record says, what is left in memory, and the test that
proves it (`model/gen_tests.py`; results in `reports/regression.md`).

| Brief error | Detected by | Record | Memory / bus | Test |
|---|---|---|---|---|
| Invalid opcode | `tsu_validate` rule 2 | ERROR `0x02 OPCODE` | untouched, no bus access | `invalid` (0x01, 0x41, 0xFF) |
| Unsupported precision | rule 7 (A/B type, OUT_FMT, INT8 without quantisation); rule 6 for layouts | ERROR `0x07 PRECISION` / `0x06 LAYOUT` | untouched | `invalid`, `quant_invalid` |
| Invalid dimensions | rules 8–11 (zero, K > K_MAX, KC > TILE_K, chunk count, leading dimensions) | ERROR `0x08`–`0x0B` | untouched | `invalid`, `tk16_invalid` (DIM_RANGE with K_MAX = 4096) |
| Address overflow | rule 13, 64-bit arithmetic | ERROR `0x0D ADDR_OVF` | untouched | `invalid` (A at 0xFFFF_FFF0, LDB · (K−1) ≥ 2³²) |
| Memory bounds violation | rule 14 (window `[MEM_LO, MEM_HI)`); TC07 re-checks every transfer | ERROR `0x0E RANGE` | untouched | `invalid` (below the window, past its end); `system` (the tile scratchpad) |
| DMA failure | TC07 completion code RD_BUS / WR_BUS from an SFB2 error response | ERROR `0x18 DMA_READ` / `0x19 DMA_WRITE`, DETAIL = TDMA code, ERR_ADDR = failing word, COUNT = acknowledged C prefix, TILES | stores before the failure are in memory; nothing after it | `dma_errors` (exact ERR_ADDR, COUNT, TILES) |
| Accumulator overflow | not reachable for valid commands (K ≤ 131 071 is the exact bound); TC04 STRICT_RANGE refusal and the TC04 `o_ovf` flag are monitored | ERROR `0x28 ACC_OVF`, DETAIL 5 (range) / 6 (flagged) | C untouched by that tile | `fault` (fault hook forces an overflowing K into TC04) |
| — INT8 output overflow | TC05 saturation (the defined behaviour, not an error) | OK with SAT = 1, PERF SAT | C saturated per the contract | `quant` (saturating cases, checked element by element) |
| Buffer ownership violation | TC03 refuses a fill write into a set the DMA does not own; the output buffer's gate refuses a read of a set not IN_USE; reported by TC07 as LOC_WR / LOC_RD | ERROR `0x20 BUF_ACCESS`, DETAIL **6 (OWNER)** | C untouched | `fault` modes 1 and 3 (fill / drain addresses redirected into the other set) |
| (also) compute path | TC03 tile rejection, TC02 launch rejection / alignment checker, TC04 configuration / beat errors | ERROR `0x21 COMPUTE`, DETAIL `TSU_IE_*` | | defence in depth (unreachable for valid commands) |
| (also) quantiser | TC05 descriptor rejection, beat error | ERROR `0x29 QUANT` | | |
| (also) no progress | watchdog: no datapath handshake for 2^WDOG_LOG2 cycles | ERROR `0x30 TIMEOUT` | | `watchdog` (slow memory: recovers; dead memory: HALT, then hard reset) |
| (also) host abort | CTRL.ABORT | ERROR / SKIPPED `0x38 ABORTED` | partial C of the running command | `abort` (6 seeds × 2 memories: aborts in the 1st, 2nd, 3rd command and after completion) |

## Execution-error handling (all codes ≥ `0x18`)

1. The first error wins (the adapter's completion code, then compute / output / quantiser monitors, then abort,
   then watchdog); later errors of the same command are ignored.
2. The scheduler stops issuing descriptors and jobs.
3. `tsu_bus_gate` drains the SFB2 port: a request already presented stays presented until accepted (R2); no new
   request leaves; every outstanding response is collected (completion records of descriptors still in flight are
   consumed and their acknowledged bytes added to COUNT).
4. The datapath (adapter, TC02–TC05, output buffer, compute sequencer) is reset for 4 clock edges through a registered
   request; queues, registers and counters are not. A failed SEAL can leave TC03 / output-buffer sets FILLING or
   IN_USE forever (TC07 doc 10: ownership never changes on an error); the reset is what makes the next command safe.
5. The record is pushed; `STATUS.ERR_STICKY` is set. In stop mode later commands are SKIPPED (PRIOR) until ERR_CLEAR.
6. If the port cannot be drained within 2^WDOG_LOG2 cycles (a slave never answers), the record is still produced and
   the unit enters HALT with the port held; only a hard reset recovers (`watchdog` test, second half).

Every test that injects an error is followed by a clean command on the same, soft-reset datapath, checked exactly.
