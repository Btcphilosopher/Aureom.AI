# 03 — Register map and host programming model

One 4 KiB page on the SilicaFlux-V register bus — the contract of DataFabric `dma_control_regs`, HPC Module 06
`hpc_cq_mmio` and HPC Module 08 `hpc_tile_regs`:

* one-cycle `rb_sel` strobe with `rb_we`, `rb_addr[11:0]`, `rb_wdata`; `rb_rdata` / `rb_err` answered combinationally
  in the strobe cycle; side effects at the end of the strobe cycle; 32-bit accesses only;
* `rb_err = 1` means **refused, no effect**: unmapped or misaligned offset, write to a read-only register, DOORBELL
  while the command queue is full, CPL_POP with no record. Reads have no side effects; DOORBELL / CPL_POP read 0.

Proposed SoC placement: page 9 (`0x4000_9000`), next to the HPC tile's page 8 (`0x4000_8000`); interrupt line
`irq`. `integration/sfx_hpc_tensor_system.sv` decodes exactly this.

| Offset | Name | Access | Fields |
|---|---|---|---|
| `0x000` | ID | RO | `0x5346_5443` ("SFTC") |
| `0x004` | INFO | RO | [3:0] ABI version (2), [7:4] log2 CMD_QUEUE_DEPTH, [15:8] ARRAY_ROWS, [23:16] ARRAY_COLS, [24] ENABLE_QUANTIZATION, [25] ENABLE_DOUBLE_BUFFERING, [26] PERF_EN |
| `0x008` | CAPS | RO | [15:0] TILE_K, [23:16] DATA_WIDTH, [31:24] ACC_WIDTH |
| `0x00C` | OPBUF | RO | OPERAND_BUFFER_BYTES |
| `0x010` | MEM_LO | RO | first byte of the legal memory window |
| `0x014` | MEM_LAST | RO | last byte of the legal memory window |
| `0x018` | CTRL | RW | [0] ERR_CONT (0 stop on error, 1 continue); write-1 pulses, read 0: [1] ERR_CLEAR, [2] PERF_CLEAR, [3] ABORT |
| `0x01C` | STATUS | RO | [0] BUSY (scheduler active or queue non-empty) [1] ERR_STICKY [2] Q_FULL [3] Q_EMPTY [4] CPL_VALID [5] ABORTING [6] HALTED [11:8] scheduler state (doc 01 §7) [23:16] queued commands [31:24] free queue slots |
| `0x020` | INT_ENABLE | RW | [0] IRQ (a command with FLAGS.IRQ committed) [1] ERR (an ERROR / SKIPPED record) [2] DONE (any record) |
| `0x024` | INT_STATUS | W1C | same bits; set by the record push, the set wins over a same-cycle clear; `irq = OR(INT_STATUS & INT_ENABLE)` (level) |
| `0x028` | SUBMITTED | RO | doorbells accepted since reset |
| `0x02C` | KMAX | RO | K_MAX of this build |
| `0x040`–`0x06C` | DESC0–DESC11 | RW | descriptor staging, kept after DOORBELL |
| `0x070` | DOORBELL | WO | push the staged descriptor: exactly one command, or refused (`rb_err`) when full |
| `0x080`–`0x094` | CPL0–CPL5 | RO | head completion record (doc 02 §5); 0 when none |
| `0x098` | CPL_POP | WO | release the head record; refused when none |
| `0x100` + 4i | PERF[i] | RO | counter i < 20 (§1), 32-bit saturating |
| `0x200` + 4j | DMA_PERF[j] | RO | TENSORCORE 07 adapter counter j < 18 (`TDMA_PC_*`: active, bytes, requests, stalls, outstanding, buffer / dependency waits, errors, overlap) |

## 1. Performance counters (`PERF[i]`, also the `perf_ev` increments)

| i | Name | i | Name |
|---|---|---|---|
| 0 | CYCLES | 10 | DMA_ACTIVE (adapter holds a descriptor) |
| 1 | BUSY (scheduler not idle) | 11 | OVERLAP (SFB2 request accepted while the array computes) |
| 2 | CMD_ACCEPT (doorbells accepted) | 12 | RD_WORDS (SFB2 read requests accepted) |
| 3 | CMD_DONE (records) | 13 | WR_WORDS (SFB2 write requests accepted) |
| 4 | CMD_ERR (ERROR / SKIPPED records) | 14 | BUS_STALL (request presented, not accepted) |
| 5 | GEMM_OK | 15 | DESC (DMA descriptors issued) |
| 6 | TILES (STOREs OK) | 16 | Q_FULL (cycles the command queue is full) |
| 7 | CHUNKS (jobs accepted by compute) | 17 | CPL_STALL (record waits for completion-queue space) |
| 8 | MACS (eff_m·eff_n·eff_k per job) | 18 | SAT (INT8 elements saturated) |
| 9 | COMPUTE_CYC (array launched, not yet read out) | 19 | ABORTS (quiesce + soft reset sequences) |

The regression checks GEMM_OK, TILES, CHUNKS, MACS, DESC, RD_WORDS, WR_WORDS, CMD_DONE and CMD_ACCEPT **exactly**
against the reference model on every run without reset / abort / execution error (docs/08).

## 2. Programming sequence

1. `ID` and `INFO[3:0] = 2`; read `CAPS`, `MEM_LO`, `MEM_LAST`, `KMAX` (the driver's host-side check uses them);
   `INT_ENABLE = 0`; clear `INT_STATUS`; `CTRL = 0` (stop on error).
2. Submit: if `STATUS[31:24]` > 0, write DESC0..DESC11, then DOORBELL. A refused doorbell changed nothing and is safe
   to retry. Commands may be submitted back to back without waiting.
3. Complete: poll `STATUS.CPL_VALID` (or take `irq`), read CPL0..CPL5, write CPL_POP. Records arrive in submission
   order; SEQ identifies them.
4. Error (stop mode): the failing command's record is ERROR; later commands complete SKIPPED (PRIOR) until
   `CTRL.ERR_CLEAR`. In continue mode (`CTRL.ERR_CONT = 1`) later commands execute.
5. Abort: write `CTRL.ABORT`; wait until `STATUS.ABORTING = 0`; the running command completes ERROR (ABORTED), every
   queued one SKIPPED (ABORTED); clear the sticky error. Commands written before ABORTING returns to 0 may be flushed.
6. `STATUS.HALTED = 1` (the bus port could not be drained after an error) is left only by a hard reset.

Cost per command over the register bus: 13 writes + 1 status read to submit, 8 accesses per record.
