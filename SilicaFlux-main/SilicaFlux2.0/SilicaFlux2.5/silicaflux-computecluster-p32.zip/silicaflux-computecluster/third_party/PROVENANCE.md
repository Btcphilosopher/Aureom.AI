# third_party — provenance (Project 32 ComputeCluster)

Project 32 vendors TENSORCORE 08's `third_party/` tree unchanged (below, as TC08 recorded it), plus:

| Directory / file | Source archive | Content used |
|---|---|---|
| `silicaflux-tensorcore08/rtl/` | `SilicaFlux-main/silicaflux-tensorcore08.zip` (`rtl/`) | the tensor unit, unmodified (`silicaflux_tensor_unit.sv` + `tsu_*`) |
| `silicaflux-tensorcore08/docs/` | same archive | command ABI, register map, errors (reference for docs/02) |
| `silicaflux-datafabric/rtl/interconnect/sfb_reg_slice.sv`, `sfb_skid_buffer.sv` | `SilicaFlux-main/silicaflux-datafabric.zip` | pipeline boundaries of the cluster ports |
| `silicaflux-datafabric/docs/PROTOCOL.md` | same archive | SFB2 rules referenced by docs/02 and docs/04 |

Byte identity: `reports/audit/byte_identity.txt`; checksums: `third_party/SHA256SUMS` (regenerated for this tree).

## As recorded by TENSORCORE 08


Every file below `third_party/` is copied **byte for byte** from an archive in `btcphilosopher/Aureom.AI`
(`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`); `SHA256SUMS` lists all of them. Nothing here is modified.
Byte identity with the original archives (and between the copies different stages vendor) was checked in
docs/00_AUDIT.md §2.

| Directory | Source archive | Content used |
|---|---|---|
| `silicaflux-tensorcore02/` | `silicaflux-tensorcore02.zip` (via TC07 `third_party/`, identical) | systolic array, PE, skew, output collect |
| `silicaflux-tensorcore03/` | `silicaflux-tensorcore03.zip` (via TC07, identical) | operand buffer, banks, arbiter, ownership, DMA port, tile AGU |
| `silicaflux-tensorcore04/` | `silicaflux-tensorcore04.zip` (via TC07, identical) | accumulator subsystem |
| `silicaflux-tensorcore05/` | `silicaflux-tensorcore05.zip` | `rtl/` quantiser; `model/tq_ref.py` (reference used by the TC08 checker) |
| `silicaflux-tensorcore06/` | `silicaflux-tensorcore06.zip` | `ttc_tile_iter.sv` only |
| `silicaflux-tensorcore07/` | `silicaflux-tensorcore07.zip` | DMA adapter and channels, output buffer, gate, compute sequencer, `tdma_defs.svh` (`tdma_tile_system.sv` kept for reference, not compiled) |
| `silicaflux-hpc-m04-scratchpad/` | `silicaflux-hpc-m04-scratchpad.zip` (via TC07, identical) | scratchpad inside the output buffer |
| `silicaflux-hpc-m08-tile/rtl/` | `silicaflux-hpc-m08-tile.zip` | `hpc_command_queue.sv`, `hpc_perf_counters.sv` (used by the tensor unit); the tile RTL (coexistence system only); `docs/02_commands.md`, `docs/03_register_map.md` |
| `silicaflux-hpc-m08-tile/third_party/` | `silicaflux-hpc-m08-tile.zip` `third_party/` | Module 03 vector array, Module 05 DMA adapter (tile only); `PROVENANCE_M08.md` = the tile's own provenance file |
| `silicaflux-datafabric/` | `silicaflux-datafabric.zip` (via TC07 / M08, identical) | SFB2 protocol doc, crossbar, arbiter, decoders, SRAM slave, DMA engines + FIFO, protocol checker |
| `silicaflux-sramlib/` | `silicaflux-sramlib.zip` (via TC07, identical) | SRAM wrapper library (generic / FPGA / ASIC-leaf backends) |

Not redistributed: the SkyWater SKY130 `sky130_fd_sc_hd__tt_025C_1v80.lib` liberty used by the ASIC smoke test is
downloaded by `syn/run_synth.py` from OpenROAD-flow-scripts (URL and SHA-256 in that script and in `reports/synth.md`).
