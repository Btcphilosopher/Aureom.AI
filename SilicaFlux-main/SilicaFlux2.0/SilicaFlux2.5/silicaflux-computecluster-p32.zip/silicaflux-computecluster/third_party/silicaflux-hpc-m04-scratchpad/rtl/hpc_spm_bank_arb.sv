// =============================================================================
// SilicaFlux-HPC Module 04 :: hpc_spm_bank_arb
// Per-bank arbiter.  Grants at most as many requester ports per cycle as the
// bank's physical memory-port model allows:
//
//   PORT_MODE 1RW  : slot A only - one read or one write.
//   PORT_MODE 1R1W : slot A = the write port, slot B = the read port.  A read
//                    and a write to the SAME row are never granted together
//                    (the later one in priority order is stalled).
//   PORT_MODE 2RW  : slots A and B, any kind.  Two accesses to the same row
//                    where at least one is a write are never granted together.
//
// Hence the array never sees a same-cycle read-during-write or write-write
// collision on one row, whatever the backend's (undefined / READ_FIRST /
// WRITE_FIRST) cross-port behaviour is.
//
// Priority order: ARB = RR    -> ports ptr, ptr+1, ..., ptr-1 (mod NUM_PORTS)
//                 ARB = FIXED -> ports 0, 1, ..., NUM_PORTS-1
// Scan: every requesting port, in priority order, takes the first slot it is
// allowed to use (rules above).  The FIRST requesting port in priority order is
// therefore always granted (no hazard exists against an empty bank).
// RR pointer update on any grant: ptr <- (first granted port) + 1.  Because the
// first requester is always granted, a port that keeps requesting is granted
// within NUM_PORTS-1 cycles in every port mode (starvation-free).  Moving the
// pointer past the LAST winner instead would let a hazard-blocked port be
// skipped forever in 1R1W/2RW mode - deliberately not done.
// For PORT_MODE 1RW this is exactly sram_bank_controller's rotating priority
// (ptr <- winner + 1).
//
// contended = some requesting port was not granted this cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_spm_defs.svh"
`default_nettype none

module hpc_spm_bank_arb #(
  parameter int  NUM_PORTS = 2,
  parameter int  PORT_MODE = `HPC_SPM_PORT_1RW,
  parameter int  ARB       = `HPC_SPM_ARB_RR,
  parameter int  RW        = 10,                             // row-address width
  localparam int PW        = (NUM_PORTS > 1) ? $clog2(NUM_PORTS) : 1
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  input  wire logic [NUM_PORTS-1:0]    req,
  input  wire logic [NUM_PORTS-1:0]    we,
  input  wire logic [NUM_PORTS*RW-1:0] row,
  output logic      [NUM_PORTS-1:0]    gnt_a,
  output logic      [NUM_PORTS-1:0]    gnt_b,
  output logic                         any_a,
  output logic                         any_b,
  output logic      [PW-1:0]           idx_a,
  output logic      [PW-1:0]           idx_b,
  output logic                         contended
);

  localparam logic [PW-1:0] LAST_P = PW'(NUM_PORTS - 1);

  logic [PW-1:0] ptr_q;
  logic [PW-1:0] first_idx;
  logic          first_found;

  always_comb begin
    logic          a_we, g_a, g_b;
    logic [RW-1:0] a_row, b_row, r;
    int            idx;
    gnt_a = '0; gnt_b = '0; any_a = 1'b0; any_b = 1'b0; idx_a = '0; idx_b = '0;
    a_we = 1'b0; a_row = '0; b_row = '0; r = '0; g_a = 1'b0; g_b = 1'b0;
    first_idx = '0; first_found = 1'b0;
    for (int k = 0; k < NUM_PORTS; k++) begin
      idx = (ARB == `HPC_SPM_ARB_RR) ? ({{(32-PW){1'b0}}, ptr_q} + k) : k;
      if (idx >= NUM_PORTS) idx = idx - NUM_PORTS;
      r   = row[idx*RW +: RW];
      g_a = 1'b0;
      g_b = 1'b0;
      if (req[idx]) begin
        if (PORT_MODE == `HPC_SPM_PORT_1R1W) begin
          if (we[idx]) g_a = !any_a && !(any_b && b_row == r);
          else         g_b = !any_b && !(any_a && a_row == r);
        end else if (PORT_MODE == `HPC_SPM_PORT_2RW) begin
          if (!any_a)  g_a = 1'b1;
          else         g_b = !any_b && !(a_row == r && (a_we || we[idx]));
        end else begin
          g_a = !any_a;
        end
      end
      if (g_a) begin
        gnt_a[idx] = 1'b1; any_a = 1'b1; idx_a = PW'(idx); a_row = r; a_we = we[idx];
      end
      if (g_b) begin
        gnt_b[idx] = 1'b1; any_b = 1'b1; idx_b = PW'(idx); b_row = r;
      end
      if ((g_a || g_b) && !first_found) begin
        first_found = 1'b1;
        first_idx   = PW'(idx);
      end
    end
    contended = |(req & ~(gnt_a | gnt_b));
  end

  if (ARB == `HPC_SPM_ARB_RR) begin : g_rr
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)           ptr_q <= '0;
      else if (first_found) ptr_q <= (first_idx == LAST_P) ? '0 : first_idx + 1'b1;
    end
  end else begin : g_fixed
    assign ptr_q = '0;
    wire unused_fixed = &{1'b0, clk, rst_n, first_idx, first_found};
  end

endmodule

`default_nettype wire
