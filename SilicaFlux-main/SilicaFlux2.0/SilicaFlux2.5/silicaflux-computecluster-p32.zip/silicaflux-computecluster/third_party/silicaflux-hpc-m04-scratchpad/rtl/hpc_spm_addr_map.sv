// =============================================================================
// SilicaFlux-HPC Module 04 :: hpc_spm_addr_map
// Byte address -> (bank, row, byte offset, error) decoder.  Pure combinational,
// one instance per requester port.  The mapping is the documented contract of
// docs/02_address_map.md; model/hpc_spm_map.py is its executable reference.
//
//   CB   = log2(CAPACITY_BYTES)          OFF = log2(DATA_WIDTH/8)
//   WAW  = CB - OFF  (word-address bits)  BW  = log2(NUM_BANKS)   RW = WAW - BW
//
//   in range  : addr[ADDR_WIDTH-1:CB] == BASE_ADDR[ADDR_WIDTH-1:CB]
//               (BASE_ADDR is CAPACITY-aligned, so this is exactly
//               BASE_ADDR <= addr < BASE_ADDR + CAPACITY_BYTES).  Nothing above
//               bit CB-1 is ever dropped: an out-of-range address is an error,
//               never an alias of an in-range word.
//   byte off  : addr[OFF-1:0]
//   word      : addr[CB-1:OFF]
//   LOW  map  : bank = word[BW-1:0]                     row = word[WAW-1:BW]
//   XOR  map  : bank = word[BW-1:0] ^ word[2BW-1:BW]    row = word[WAW-1:BW]
//   HIGH map  : bank = word[WAW-1:RW]                   row = word[RW-1:0]
//   error     : RANGE (out of range) > ALIGN (byte off != 0)
//               > STROBE (BYTE_WE = 0, write, wstrb != all ones)
// Every map is a bijection between the CAPACITY/WORD_BYTES words and the
// (bank, row) pairs (checked exhaustively by model/hpc_spm_map.py and by the
// testbench backdoor test t_all_banks).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_spm_defs.svh"
`default_nettype none

module hpc_spm_addr_map #(
  parameter int          ADDR_WIDTH     = 32,
  parameter int          CAPACITY_BYTES = 65536,
  parameter logic [63:0] BASE_ADDR      = 64'h0,
  parameter int          DATA_WIDTH     = 32,
  parameter int          NUM_BANKS      = 2,
  parameter int          MAP            = `HPC_SPM_MAP_LOW,
  parameter int          BYTE_WE        = 1,
  localparam int         NBYTES         = DATA_WIDTH / 8,
  localparam int         CB             = $clog2(CAPACITY_BYTES),
  localparam int         OFF            = $clog2(NBYTES),
  localparam int         WAW            = CB - OFF,
  localparam int         BW             = $clog2(NUM_BANKS),
  localparam int         RW             = WAW - BW,
  localparam int         BWX            = (BW > 0) ? BW : 1,
  localparam int         OFFX           = (OFF > 0) ? OFF : 1
) (
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic                  we,
  input  wire logic [NBYTES-1:0]     wstrb,
  output logic                       ok,
  output logic [2:0]                 err_code,
  output logic [BWX-1:0]             bank,
  output logic [RW-1:0]              row,
  output logic [OFFX-1:0]            boff
);

  // ------------------------------------------------------------ range
  logic in_range;
  if (ADDR_WIDTH > CB) begin : g_range
    localparam logic [ADDR_WIDTH-CB-1:0] BASE_HI = BASE_ADDR[ADDR_WIDTH-1:CB];
    assign in_range = (addr[ADDR_WIDTH-1:CB] == BASE_HI);
  end else begin : g_full_range
    assign in_range = 1'b1;
  end

  // ------------------------------------------------------------ offset / word
  logic [WAW-1:0] word;
  assign word = addr[CB-1:OFF];
  if (OFF > 0) begin : g_off
    assign boff = addr[OFF-1:0];
  end else begin : g_no_off
    assign boff = 1'b0;
  end
  wire misaligned = (OFF > 0) && (boff != '0);

  // ------------------------------------------------------------ bank / row
  if (BW == 0) begin : g_one_bank
    assign bank = 1'b0;
    assign row  = word;
  end else if (MAP == `HPC_SPM_MAP_HIGH) begin : g_high
    assign bank = word[WAW-1:RW];
    assign row  = word[RW-1:0];
  end else if (MAP == `HPC_SPM_MAP_XOR) begin : g_xor
    assign bank = word[BW-1:0] ^ word[2*BW-1:BW];
    assign row  = word[WAW-1:BW];
  end else begin : g_low
    assign bank = word[BW-1:0];
    assign row  = word[WAW-1:BW];
  end

  // ------------------------------------------------------------ errors
  wire bad_strobe = (BYTE_WE == 0) && we && (wstrb != {NBYTES{1'b1}});
  always_comb begin
    if (!in_range)       err_code = `HPC_SPM_ERR_RANGE;
    else if (misaligned) err_code = `HPC_SPM_ERR_ALIGN;
    else if (bad_strobe) err_code = `HPC_SPM_ERR_STROBE;
    else                 err_code = `HPC_SPM_ERR_OK;
  end
  assign ok = (err_code == `HPC_SPM_ERR_OK);

endmodule

`default_nettype wire
