// =============================================================================
// SilicaFlux-HPC Module 04 :: hpc_spm_bank
// One scratchpad bank: write-side integrity encoding + the SilicaFlux SRAM
// Wrapper Library raw backend for the selected memory-port model.  The SRAM
// library modules are used unmodified (third_party/silicaflux-sramlib):
//
//   PORT_MODE 1RW  -> sram_backend_1rw   (slot A)
//   PORT_MODE 1R1W -> sram_backend_1r1w  (slot A = write port, slot B = read port)
//   PORT_MODE 2RW  -> sram_backend_2rw   (slot A = port a, slot B = port b)
//
//   BACKEND GENERIC : behavioural / synthesizable array (simulation, formal,
//                     logic synthesis; an ASIC flow would make flip-flops)
//   BACKEND FPGA    : block-RAM inference templates (no vendor IP)
//   BACKEND ASIC    : real foundry/compiler macros tiled by sram_asic_array,
//                     selected by MACRO; never falls back to flip-flops
//
// Stored word (STORE_W bits):
//   ECC_MODE NONE        : STORE_W = DATA_WIDTH, data bytes as given.
//   ECC_MODE BYTE_PARITY : STORE_W = 9 * DATA_WIDTH / 8; lane l = {p_l, byte_l}
//                          with p_l = ~^byte_l (ODD parity: a lane of nine
//                          zeros - e.g. a dead row - is detected).
// Write mask: BYTE_WE = 1 -> one mask lane per byte (8 or 9 bits wide);
//             BYTE_WE = 0 -> one lane for the whole word (word-write memory;
//                            partial strobes are rejected by the address map).
// Raw outputs (rdata_a / rdata_b) are the stored words, valid exactly
// READ_LATENCY cycles after a read edge, for one cycle (sramlib contract).
// The parity CHECK is in hpc_scratchpad, after per-port read-data routing.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_spm_defs.svh"
`default_nettype none

module hpc_spm_bank #(
  parameter int  DATA_WIDTH   = 32,
  parameter int  DEPTH        = 1024,
  parameter int  READ_LATENCY = 1,
  parameter int  PORT_MODE    = `HPC_SPM_PORT_1RW,
  parameter int  BYTE_WE      = 1,
  parameter int  ECC_MODE     = `HPC_SPM_ECC_NONE,
  parameter int  BACKEND      = `SRAM_BACKEND_GENERIC,
  parameter int  MACRO        = 0,
  localparam int NBYTES       = DATA_WIDTH / 8,
  localparam int LANE_W       = (ECC_MODE == `HPC_SPM_ECC_BYTE_PARITY) ? 9 : 8,
  localparam int STORE_W      = NBYTES * LANE_W,
  localparam int MASK_W       = (BYTE_WE != 0) ? NBYTES : 1,
  localparam int RW           = $clog2(DEPTH)
) (
  input  wire logic                  clk,
  // slot A
  input  wire logic                  a_ce,
  input  wire logic                  a_we,
  input  wire logic [RW-1:0]         a_row,
  input  wire logic [DATA_WIDTH-1:0] a_wdata,
  input  wire logic [NBYTES-1:0]     a_wstrb,
  output logic      [STORE_W-1:0]    a_rdata,
  // slot B (1R1W: read port; 2RW: second port; 1RW: unused)
  input  wire logic                  b_ce,
  input  wire logic                  b_we,
  input  wire logic [RW-1:0]         b_row,
  input  wire logic [DATA_WIDTH-1:0] b_wdata,
  input  wire logic [NBYTES-1:0]     b_wstrb,
  output logic      [STORE_W-1:0]    b_rdata
);

  // ------------------------------------------------------------ write encoding
  logic [STORE_W-1:0] a_sw, b_sw;
  logic [MASK_W-1:0]  a_m,  b_m;
  for (genvar l = 0; l < NBYTES; l++) begin : g_enc
    if (ECC_MODE == `HPC_SPM_ECC_BYTE_PARITY) begin : g_par
      assign a_sw[l*LANE_W +: LANE_W] = {~^a_wdata[l*8 +: 8], a_wdata[l*8 +: 8]};
      assign b_sw[l*LANE_W +: LANE_W] = {~^b_wdata[l*8 +: 8], b_wdata[l*8 +: 8]};
    end else begin : g_plain
      assign a_sw[l*LANE_W +: LANE_W] = a_wdata[l*8 +: 8];
      assign b_sw[l*LANE_W +: LANE_W] = b_wdata[l*8 +: 8];
    end
  end
  if (BYTE_WE != 0) begin : g_bmask
    assign a_m = a_wstrb;
    assign b_m = b_wstrb;
  end else begin : g_wmask
    assign a_m = &a_wstrb;      // the address map only lets all-ones strobes through
    assign b_m = &b_wstrb;
  end

  // ------------------------------------------------------------ array
  // The three branches share the block name g_ram (IEEE 1800 if-generate
  // rule), so the array is at <bank>.g_ram.u_ram.g_generic.u_mem.mem in
  // every port mode (testbench backdoor / fault injection).
  if (PORT_MODE == `HPC_SPM_PORT_1R1W) begin : g_ram
    sram_backend_1r1w #(
      .DATA_WIDTH(STORE_W), .DEPTH(DEPTH), .MASK_WIDTH(MASK_W), .READ_LATENCY(READ_LATENCY),
      .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_ram (
      .clk(clk), .we(a_ce), .wmask(a_m), .waddr(a_row), .wdata(a_sw),
      .re(b_ce), .raddr(b_row), .rdata(b_rdata)
    );
    assign a_rdata = '0;
    wire unused_1r1w = &{1'b0, a_we, b_we, b_sw, b_m};
  end else if (PORT_MODE == `HPC_SPM_PORT_2RW) begin : g_ram
    sram_backend_2rw #(
      .DATA_WIDTH(STORE_W), .DEPTH(DEPTH), .MASK_WIDTH(MASK_W), .READ_LATENCY(READ_LATENCY),
      .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_ram (
      .clk(clk),
      .a_ce(a_ce), .a_we(a_we), .a_wmask(a_m), .a_addr(a_row), .a_wdata(a_sw), .a_rdata(a_rdata),
      .b_ce(b_ce), .b_we(b_we), .b_wmask(b_m), .b_addr(b_row), .b_wdata(b_sw), .b_rdata(b_rdata)
    );
  end else begin : g_ram
    sram_backend_1rw #(
      .DATA_WIDTH(STORE_W), .DEPTH(DEPTH), .MASK_WIDTH(MASK_W), .READ_LATENCY(READ_LATENCY),
      .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_ram (
      .clk(clk), .ce(a_ce), .we(a_we), .wmask(a_m), .addr(a_row), .wdata(a_sw), .rdata(a_rdata)
    );
    assign b_rdata = '0;
    wire unused_1rw = &{1'b0, b_ce, b_we, b_row, b_sw, b_m};
  end

endmodule

`default_nettype wire
