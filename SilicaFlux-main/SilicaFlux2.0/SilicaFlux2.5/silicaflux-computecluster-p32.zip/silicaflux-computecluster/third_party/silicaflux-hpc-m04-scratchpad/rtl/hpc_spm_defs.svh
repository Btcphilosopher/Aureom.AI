// =============================================================================
// SilicaFlux-HPC Module 04 :: hpc_spm_defs.svh
// Constants of the banked scratchpad (hpc_scratchpad).
//
// A `define header, not a package, for the same reason as the SilicaFlux SRAM
// Wrapper Library's sram_defs.svh: Yosys 0.33 cannot resolve package
// references in module parameter lists, and every synthesizable module here
// must elaborate unaided in Verilator 5.020, Icarus 12 and Yosys 0.33.
//
// Values are part of the public contract: never renumber, only append.
// =============================================================================
`ifndef HPC_SPM_DEFS_SVH
`define HPC_SPM_DEFS_SVH

`include "sram_defs.svh"

// ------------------------------------------------------------ address map
// word = (byte_address - BASE_ADDR) >> log2(DATA_WIDTH/8)
// LOW  : bank = word[BW-1:0]                       row = word >> BW   (default)
// XOR  : bank = word[BW-1:0] ^ word[2*BW-1:BW]     row = word >> BW   (conflict experiments)
// HIGH : bank = word >> RW                         row = word[RW-1:0] (contiguous regions)
`define HPC_SPM_MAP_LOW   0
`define HPC_SPM_MAP_XOR   1
`define HPC_SPM_MAP_HIGH  2

// ------------------------------------------------------------ bank memory-port model
// 1RW  : one read OR one write per bank per cycle      (sram_backend_1rw)
// 1R1W : one read AND one write per bank per cycle     (sram_backend_1r1w)
// 2RW  : two accesses of any kind per bank per cycle   (sram_backend_2rw)
`define HPC_SPM_PORT_1RW  0
`define HPC_SPM_PORT_1R1W 1
`define HPC_SPM_PORT_2RW  2

// ------------------------------------------------------------ arbitration
`define HPC_SPM_ARB_RR    0   // per-bank round robin, pointer moves past the last winner
`define HPC_SPM_ARB_FIXED 1   // per-bank fixed priority, port 0 highest (can starve)

// ------------------------------------------------------------ integrity
// NONE        : no check bits.
// BYTE_PARITY : one odd-parity bit per byte lane, encoded on write, checked on
//               read; detects any odd number of flipped bits per byte; no
//               correction.  Compatible with byte writes (no read-modify-write).
// SECDED      : RESERVED.  Rejected at elaboration (no encoder/decoder exists).
`define HPC_SPM_ECC_NONE        0
`define HPC_SPM_ECC_BYTE_PARITY 1
`define HPC_SPM_ECC_SECDED      2

// ------------------------------------------------------------ response error codes (rsp_err_code, 3 bits)
// rsp_err = (rsp_err_code != OK).  Read data is zero for every error response.
// Priority when several apply: RANGE > ALIGN > STROBE.
`define HPC_SPM_ERR_OK       3'd0   // no error
`define HPC_SPM_ERR_RANGE    3'd1   // address outside [BASE_ADDR, BASE_ADDR + CAPACITY_BYTES): never wrapped, no side effect
`define HPC_SPM_ERR_ALIGN    3'd2   // byte offset inside the word != 0 (unaligned): no side effect
`define HPC_SPM_ERR_STROBE   3'd3   // BYTE_WE = 0 and a write strobe that is not all-ones: no side effect
`define HPC_SPM_ERR_PARITY   3'd4   // read data failed the byte-parity check (ECC_MODE = BYTE_PARITY only)
`define HPC_SPM_ERR_ECC_UE   3'd5   // RESERVED for a future SECDED decoder (uncorrectable) - never generated
`define HPC_SPM_ERR_RSVD6    3'd6   // reserved
`define HPC_SPM_ERR_RSVD7    3'd7   // reserved

`endif // HPC_SPM_DEFS_SVH
