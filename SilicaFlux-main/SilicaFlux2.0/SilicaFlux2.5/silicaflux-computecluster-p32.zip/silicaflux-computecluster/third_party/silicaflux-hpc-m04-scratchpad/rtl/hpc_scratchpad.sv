// =============================================================================
// SilicaFlux-HPC Module 04 :: hpc_scratchpad
// Banked high-bandwidth scratchpad SRAM for the SilicaFlux-HPC compute tile.
// Aureom.AI | SilicaFlux-HPC.  Primary source of the module.
//
//   NUM_PORTS requester ports (e.g. vector array lanes + DMA engine)
//        |  ready/valid request: we, byte address, wdata, wstrb, tag
//        v
//   [optional per-port request queue, QUEUE_DEPTH entries (DataFabric dma_fifo)]
//        v
//   hpc_spm_addr_map : byte address -> bank / row / byte offset / error
//        v
//   hpc_spm_bank_arb (one per bank) : RR or fixed priority, at most as many
//        grants per bank per cycle as its memory-port model allows (1RW: 1,
//        1R1W: 1 read + 1 write, 2RW: 2), never two same-row accesses with a
//        write in one cycle
//        v
//   hpc_spm_bank (one per bank) : SRAM Wrapper Library raw backend
//        (GENERIC / FPGA block-RAM inference / ASIC macros) + byte parity encode
//        v
//   owner pipelines route each bank's read data to the issuing port
//        v
//   sram_rsp_path (SRAM Wrapper Library, one per port): in-order responses
//        with tag, credit-based response back-pressure, response FIFO
//        v
//   ready/valid response: rdata, err, err_code, we, tag, integrity syndrome
//
// ---------------------------------------------------------------- timing
//   Cycle t = the clock period that ends with rising edge t.
//   QUEUE_DEPTH = 0 (direct)    : accept == issue.  A request presented in
//                                 cycle t and granted is accepted AND issued
//                                 at edge t (req_ready = grant, combinational
//                                 from req_valid/req_addr, never from rsp_ready).
//   QUEUE_DEPTH > 0 (queued)    : accepted at edge t when the queue is not
//                                 full (req_ready is a register output); the
//                                 earliest issue is edge t+1.
//   Write commit                : at the ISSUE edge.  A read issued at a
//                                 later edge (from any port) returns the new
//                                 data; a read issued at the same edge cannot
//                                 target the same row of the same bank (the
//                                 arbiter never co-issues such a pair).
//   Read data / any response    : rsp_valid in cycle (issue + READ_LATENCY)
//                                 when the response channel is not stalled
//                                 (bypass of the response FIFO); later, in
//                                 order, when rsp_ready was low.
//   Write acknowledgement       : WRITE_ACK = 1: one response per write,
//                                 also at issue + READ_LATENCY, after the
//                                 array was written.  WRITE_ACK = 0: posted;
//                                 only erroneous writes are answered.
//   Errors                      : RANGE / ALIGN / STROBE requests never touch
//                                 a bank; they take the same READ_LATENCY path
//                                 and are answered in order with rsp_err = 1
//                                 and rdata = 0.  PARITY errors are flagged on
//                                 the read response itself (rdata = 0).
//   Ordering                    : per port, exactly one response per
//                                 response-producing request, strictly in
//                                 acceptance order, carrying its tag.  No
//                                 ordering between ports except through the
//                                 issue edges above.
//   Reset (async assert)        : discards queued and in-flight requests (no
//                                 response is ever delivered for them).
//                                 Writes already issued remain in the array;
//                                 queued writes are dropped.  The arrays are
//                                 never reset (ASIC SRAM has no reset).
//                                 req_ready = 0 in reset and the first cycle
//                                 after it.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_spm_defs.svh"
`default_nettype none

module hpc_scratchpad #(
  parameter int          NUM_PORTS      = 2,                       // requester ports, 1..8
  parameter int          CAPACITY_BYTES = 65536,                   // power of two
  parameter int          NUM_BANKS      = 2,                       // 1, 2, 4, 8, 16
  parameter int          DATA_WIDTH     = 32,                      // bits per bank word / port, 8..1024, power of two
  parameter int          ADDR_WIDTH     = 32,                      // byte-address width of the ports
  parameter logic [63:0] BASE_ADDR      = 64'h0,                   // CAPACITY-aligned window base
  parameter int          READ_LATENCY   = 1,                       // issue edge -> response, 1..8
  parameter int          BYTE_WE        = 1,                       // 1: byte write enables; 0: word writes only
  parameter int          PORT_MODE      = `HPC_SPM_PORT_1RW,       // bank memory-port model
  parameter int          MAP            = `HPC_SPM_MAP_LOW,        // address -> bank mapping
  parameter int          ARB            = `HPC_SPM_ARB_RR,         // per-bank arbitration
  parameter int          QUEUE_DEPTH    = 0,                       // per-port request queue: 0, 2, 4, 8, 16
  parameter int          RSP_FIFO_DEPTH = READ_LATENCY + 1,        // per-port response credits; 0 = no back-pressure
  parameter int          WRITE_ACK      = 1,                       // 1: every write is answered
  parameter int          TAG_W          = 8,                       // request tag width, 1..32
  parameter int          ECC_MODE       = `HPC_SPM_ECC_NONE,       // NONE or BYTE_PARITY (SECDED reserved)
  parameter int          BACKEND        = `SRAM_BACKEND_GENERIC,   // GENERIC / FPGA / ASIC
  parameter int          MACRO          = 0,                       // ASIC macro id (sram_macro_ids.svh)
  parameter int          PERF_EN        = 1,                       // event counters
  parameter int          CNT_W          = 32,                      // counter width, 8..64
  // ------------------------------------------------------------ derived (never set)
  localparam int NBYTES  = (DATA_WIDTH >= 8) ? DATA_WIDTH / 8 : 1,
  localparam int CB      = (CAPACITY_BYTES > 1) ? $clog2(CAPACITY_BYTES) : 1,
  localparam int OFF     = $clog2(NBYTES),
  localparam int WAW     = CB - OFF,
  localparam int BW      = $clog2(NUM_BANKS),
  localparam int RW_RAW  = WAW - BW,
  localparam int RW      = (RW_RAW > 0) ? RW_RAW : 1,                 // row-address bits
  localparam int BANK_DEPTH = 1 << RW,                               // words per bank
  localparam int BWX     = (BW > 0) ? BW : 1,
  localparam int OFFX    = (OFF > 0) ? OFF : 1,
  localparam int PW      = (NUM_PORTS > 1) ? $clog2(NUM_PORTS) : 1,
  localparam int PAR     = (ECC_MODE == `HPC_SPM_ECC_BYTE_PARITY) ? 1 : 0,
  localparam int LANE_W  = 8 + PAR,
  localparam int STORE_W = NBYTES * LANE_W,
  localparam int RSPW    = DATA_WIDTH + PAR * NBYTES,                 // response-path data: {syndrome, data}
  localparam int IDW     = TAG_W + 3,                                 // response-path id: {err_code, tag}
  localparam int REQW    = 1 + ADDR_WIDTH + DATA_WIDTH + NBYTES + TAG_W,
  localparam int WCW     = 5
) (
  input  wire logic                             clk,
  input  wire logic                             rst_n,
  // ---------------------------------------------------------- request channel (port p = slice p)
  input  wire logic [NUM_PORTS-1:0]             req_valid,
  output logic      [NUM_PORTS-1:0]             req_ready,
  input  wire logic [NUM_PORTS-1:0]             req_we,
  input  wire logic [NUM_PORTS*ADDR_WIDTH-1:0]  req_addr,
  input  wire logic [NUM_PORTS*DATA_WIDTH-1:0]  req_wdata,
  input  wire logic [NUM_PORTS*NBYTES-1:0]      req_wstrb,
  input  wire logic [NUM_PORTS*TAG_W-1:0]       req_tag,
  // ---------------------------------------------------------- response channel
  output logic      [NUM_PORTS-1:0]             rsp_valid,
  input  wire logic [NUM_PORTS-1:0]             rsp_ready,
  output logic      [NUM_PORTS*DATA_WIDTH-1:0]  rsp_rdata,
  output logic      [NUM_PORTS-1:0]             rsp_err,
  output logic      [NUM_PORTS*3-1:0]           rsp_err_code,
  output logic      [NUM_PORTS-1:0]             rsp_we,
  output logic      [NUM_PORTS*TAG_W-1:0]       rsp_tag,
  output logic      [NUM_PORTS*NBYTES-1:0]      rsp_ecc_syn,       // integrity syndrome (byte-parity failure mask); 0 for ECC NONE
  // ---------------------------------------------------------- events (one-cycle pulses)
  output logic      [NUM_PORTS-1:0]             ev_accept,         // request accepted
  output logic      [NUM_PORTS-1:0]             ev_issue,          // request issued (bank access or error path)
  output logic      [NUM_PORTS-1:0]             ev_conflict,       // issuable request lost bank arbitration
  output logic      [NUM_PORTS-1:0]             ev_credit_stall,   // request blocked by response back-pressure
  output logic      [NUM_PORTS-1:0]             ev_error,          // decode-error request issued
  output logic      [NUM_PORTS-1:0]             ev_ecc_err,        // read data failed the integrity check
  output logic      [NUM_BANKS*2-1:0]           ev_bank_ops,       // accesses performed by bank b this cycle (0..2)
  output logic      [NUM_BANKS-1:0]             ev_bank_conflict,  // bank b left a requester unserved
  // ---------------------------------------------------------- performance counters (PERF_EN = 1, else 0)
  input  wire logic                             perf_clear,
  output logic      [CNT_W-1:0]                 perf_cycles,
  output logic      [NUM_PORTS*CNT_W-1:0]       perf_accept,
  output logic      [NUM_PORTS*CNT_W-1:0]       perf_issue,
  output logic      [NUM_PORTS*CNT_W-1:0]       perf_complete,
  output logic      [NUM_PORTS*CNT_W-1:0]       perf_conflict,
  output logic      [NUM_PORTS*CNT_W-1:0]       perf_wait,
  output logic      [NUM_PORTS*CNT_W-1:0]       perf_error,
  output logic      [NUM_BANKS*CNT_W-1:0]       perf_bank_ops,
  output logic      [CNT_W-1:0]                 perf_ecc_err,
  output logic                                  busy
);

  // ============================================================ configuration checks
  // Elaboration-time rejection of every unsupported combination (the message
  // is repeated in the generate-block name for tools that drop it).
  if (NUM_PORTS < 1 || NUM_PORTS > 8) begin : g_err_num_ports_must_be_1_to_8
    `SRAM_CFG_FATAL("hpc_scratchpad: NUM_PORTS must be 1..8")
  end
  if (NUM_BANKS != 1 && NUM_BANKS != 2 && NUM_BANKS != 4 && NUM_BANKS != 8 && NUM_BANKS != 16) begin : g_err_num_banks_must_be_1_2_4_8_16
    `SRAM_CFG_FATAL("hpc_scratchpad: NUM_BANKS must be 1, 2, 4, 8 or 16")
  end
  if (DATA_WIDTH < 8 || DATA_WIDTH > 1024 || (DATA_WIDTH & (DATA_WIDTH - 1)) != 0) begin : g_err_data_width_must_be_pow2_8_to_1024
    `SRAM_CFG_FATAL("hpc_scratchpad: DATA_WIDTH must be a power of two between 8 and 1024")
  end
  if (CAPACITY_BYTES < 2 || (CAPACITY_BYTES & (CAPACITY_BYTES - 1)) != 0) begin : g_err_capacity_must_be_pow2
    `SRAM_CFG_FATAL("hpc_scratchpad: CAPACITY_BYTES must be a power of two")
  end
  if (CAPACITY_BYTES < NUM_BANKS * NBYTES * 2) begin : g_err_capacity_too_small_for_banks
    `SRAM_CFG_FATAL("hpc_scratchpad: CAPACITY_BYTES must give every bank at least 2 words (CAPACITY >= 2 * NUM_BANKS * DATA_WIDTH/8)")
  end
  if (ADDR_WIDTH < CB || ADDR_WIDTH > 64) begin : g_err_addr_width_out_of_range
    `SRAM_CFG_FATAL("hpc_scratchpad: ADDR_WIDTH must be >= log2(CAPACITY_BYTES) and <= 64")
  end
  if ((BASE_ADDR & (64'(CAPACITY_BYTES) - 64'd1)) != 64'h0) begin : g_err_base_addr_not_capacity_aligned
    `SRAM_CFG_FATAL("hpc_scratchpad: BASE_ADDR must be aligned to CAPACITY_BYTES")
  end
  if (ADDR_WIDTH < 64 && (BASE_ADDR >> ADDR_WIDTH) != 64'h0) begin : g_err_base_addr_exceeds_addr_width
    `SRAM_CFG_FATAL("hpc_scratchpad: BASE_ADDR does not fit in ADDR_WIDTH bits")
  end
  if (READ_LATENCY < 1 || READ_LATENCY > 8) begin : g_err_read_latency_must_be_1_to_8
    `SRAM_CFG_FATAL("hpc_scratchpad: READ_LATENCY must be 1..8")
  end
  if (BYTE_WE != 0 && BYTE_WE != 1) begin : g_err_byte_we_must_be_0_or_1
    `SRAM_CFG_FATAL("hpc_scratchpad: BYTE_WE must be 0 or 1")
  end
  if (PORT_MODE != `HPC_SPM_PORT_1RW && PORT_MODE != `HPC_SPM_PORT_1R1W && PORT_MODE != `HPC_SPM_PORT_2RW) begin : g_err_unknown_port_mode
    `SRAM_CFG_FATAL("hpc_scratchpad: unknown PORT_MODE (0 = 1RW, 1 = 1R1W, 2 = 2RW)")
  end
  if (MAP != `HPC_SPM_MAP_LOW && MAP != `HPC_SPM_MAP_XOR && MAP != `HPC_SPM_MAP_HIGH) begin : g_err_unknown_map
    `SRAM_CFG_FATAL("hpc_scratchpad: unknown MAP (0 = LOW, 1 = XOR, 2 = HIGH)")
  end
  if (MAP == `HPC_SPM_MAP_XOR && RW_RAW < BW) begin : g_err_xor_map_needs_bank_depth_ge_num_banks
    `SRAM_CFG_FATAL("hpc_scratchpad: MAP = XOR needs at least NUM_BANKS words per bank")
  end
  if (ARB != `HPC_SPM_ARB_RR && ARB != `HPC_SPM_ARB_FIXED) begin : g_err_unknown_arb
    `SRAM_CFG_FATAL("hpc_scratchpad: unknown ARB (0 = RR, 1 = FIXED)")
  end
  if (QUEUE_DEPTH != 0 && QUEUE_DEPTH != 2 && QUEUE_DEPTH != 4 && QUEUE_DEPTH != 8 && QUEUE_DEPTH != 16) begin : g_err_queue_depth_must_be_0_2_4_8_16
    `SRAM_CFG_FATAL("hpc_scratchpad: QUEUE_DEPTH must be 0, 2, 4, 8 or 16")
  end
  if (RSP_FIFO_DEPTH < 0 || RSP_FIFO_DEPTH > 64) begin : g_err_rsp_fifo_depth_must_be_0_to_64
    `SRAM_CFG_FATAL("hpc_scratchpad: RSP_FIFO_DEPTH must be 0..64")
  end
  if (WRITE_ACK != 0 && WRITE_ACK != 1) begin : g_err_write_ack_must_be_0_or_1
    `SRAM_CFG_FATAL("hpc_scratchpad: WRITE_ACK must be 0 or 1")
  end
  if (TAG_W < 1 || TAG_W > 32) begin : g_err_tag_w_must_be_1_to_32
    `SRAM_CFG_FATAL("hpc_scratchpad: TAG_W must be 1..32")
  end
  if (ECC_MODE == `HPC_SPM_ECC_SECDED) begin : g_err_ecc_secded_reserved_not_implemented
    `SRAM_CFG_FATAL("hpc_scratchpad: ECC_MODE = SECDED is reserved and NOT implemented (no encoder/decoder exists); use NONE or BYTE_PARITY")
  end
  if (ECC_MODE != `HPC_SPM_ECC_NONE && ECC_MODE != `HPC_SPM_ECC_BYTE_PARITY && ECC_MODE != `HPC_SPM_ECC_SECDED) begin : g_err_unknown_ecc_mode
    `SRAM_CFG_FATAL("hpc_scratchpad: unknown ECC_MODE")
  end
  if (BACKEND != `SRAM_BACKEND_GENERIC && BACKEND != `SRAM_BACKEND_FPGA && BACKEND != `SRAM_BACKEND_ASIC) begin : g_err_unknown_backend
    `SRAM_CFG_FATAL("hpc_scratchpad: unknown BACKEND")
  end
  if (BACKEND == `SRAM_BACKEND_ASIC && MACRO == 0) begin : g_err_asic_backend_requires_macro
    `SRAM_CFG_FATAL("hpc_scratchpad: BACKEND = ASIC requires an explicit MACRO (no flip-flop fallback)")
  end
  if (PERF_EN != 0 && PERF_EN != 1) begin : g_err_perf_en_must_be_0_or_1
    `SRAM_CFG_FATAL("hpc_scratchpad: PERF_EN must be 0 or 1")
  end
  if (CNT_W < 8 || CNT_W > 64) begin : g_err_cnt_w_must_be_8_to_64
    `SRAM_CFG_FATAL("hpc_scratchpad: CNT_W must be 8..64")
  end


  // The datapath is only elaborated for a valid configuration, so an invalid
  // one is reported by the messages above and never by a sub-module.
  localparam bit CFG_OK =
    NUM_PORTS >= 1 && NUM_PORTS <= 8 &&
    (NUM_BANKS == 1 || NUM_BANKS == 2 || NUM_BANKS == 4 || NUM_BANKS == 8 || NUM_BANKS == 16) &&
    DATA_WIDTH >= 8 && DATA_WIDTH <= 1024 && (DATA_WIDTH & (DATA_WIDTH - 1)) == 0 &&
    CAPACITY_BYTES >= 2 && (CAPACITY_BYTES & (CAPACITY_BYTES - 1)) == 0 &&
    CAPACITY_BYTES >= NUM_BANKS * NBYTES * 2 &&
    ADDR_WIDTH >= CB && ADDR_WIDTH <= 64 &&
    (BASE_ADDR & (64'(CAPACITY_BYTES) - 64'd1)) == 64'h0 &&
    (ADDR_WIDTH >= 64 || (BASE_ADDR >> ADDR_WIDTH) == 64'h0) &&
    READ_LATENCY >= 1 && READ_LATENCY <= 8 &&
    (BYTE_WE == 0 || BYTE_WE == 1) &&
    (PORT_MODE == `HPC_SPM_PORT_1RW || PORT_MODE == `HPC_SPM_PORT_1R1W || PORT_MODE == `HPC_SPM_PORT_2RW) &&
    (MAP == `HPC_SPM_MAP_LOW || MAP == `HPC_SPM_MAP_XOR || MAP == `HPC_SPM_MAP_HIGH) &&
    !(MAP == `HPC_SPM_MAP_XOR && RW_RAW < BW) &&
    (ARB == `HPC_SPM_ARB_RR || ARB == `HPC_SPM_ARB_FIXED) &&
    (QUEUE_DEPTH == 0 || QUEUE_DEPTH == 2 || QUEUE_DEPTH == 4 || QUEUE_DEPTH == 8 || QUEUE_DEPTH == 16) &&
    RSP_FIFO_DEPTH >= 0 && RSP_FIFO_DEPTH <= 64 &&
    (WRITE_ACK == 0 || WRITE_ACK == 1) &&
    TAG_W >= 1 && TAG_W <= 32 &&
    (ECC_MODE == `HPC_SPM_ECC_NONE || ECC_MODE == `HPC_SPM_ECC_BYTE_PARITY) &&
    (BACKEND == `SRAM_BACKEND_GENERIC || BACKEND == `SRAM_BACKEND_FPGA || BACKEND == `SRAM_BACKEND_ASIC) &&
    !(BACKEND == `SRAM_BACKEND_ASIC && MACRO == 0) &&
    (PERF_EN == 0 || PERF_EN == 1) &&
    CNT_W >= 8 && CNT_W <= 64;

  if (!CFG_OK) begin : g_cfg_invalid
    // never reached: elaboration stops at the $fatal above
    assign req_ready = '0; assign rsp_valid = '0; assign rsp_rdata = '0; assign rsp_err = '0;
    assign rsp_err_code = '0; assign rsp_we = '0; assign rsp_tag = '0; assign rsp_ecc_syn = '0;
    assign ev_accept = '0; assign ev_issue = '0; assign ev_conflict = '0; assign ev_credit_stall = '0;
    assign ev_error = '0; assign ev_ecc_err = '0; assign ev_bank_ops = '0; assign ev_bank_conflict = '0;
    assign perf_cycles = '0; assign perf_accept = '0; assign perf_issue = '0; assign perf_complete = '0;
    assign perf_conflict = '0; assign perf_wait = '0; assign perf_error = '0; assign perf_bank_ops = '0;
    assign perf_ecc_err = '0; assign busy = 1'b0;
    wire unused_invalid = &{1'b0, clk, rst_n, req_valid, req_we, req_addr, req_wdata, req_wstrb, req_tag,
                            rsp_ready, perf_clear};
  end else begin : g_core

  // ============================================================ reset release
  logic live_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_q <= 1'b0;
    else        live_q <= 1'b1;
  end

  // ============================================================ per-port front end
  // h_* = the request at the head of port p (the input itself, or the queue head)
  logic [NUM_PORTS-1:0]            h_valid, h_we, h_ok;
  logic [NUM_PORTS*ADDR_WIDTH-1:0] h_addr;
  logic [NUM_PORTS*DATA_WIDTH-1:0] h_wdata;
  logic [NUM_PORTS*NBYTES-1:0]     h_wstrb;
  logic [NUM_PORTS*TAG_W-1:0]      h_tag;
  logic [NUM_PORTS*3-1:0]          h_code;
  logic [NUM_PORTS*BWX-1:0]        h_bank;
  logic [NUM_PORTS*RW-1:0]         h_row;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_PORTS*OFFX-1:0]       h_boff;      // byte offset (only checked for alignment)
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NUM_PORTS-1:0]            p_need, p_can, p_credit, p_elig, p_gnt, p_issue;
  logic [NUM_PORTS*WCW-1:0]        p_wait_inc;
  logic [NUM_PORTS-1:0]            q_nonempty;

  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_front
    if (QUEUE_DEPTH == 0) begin : g_direct
      // accept == issue
      assign h_valid[p]                          = req_valid[p];
      assign h_we[p]                             = req_we[p];
      assign h_addr[p*ADDR_WIDTH +: ADDR_WIDTH]  = req_addr[p*ADDR_WIDTH +: ADDR_WIDTH];
      assign h_wdata[p*DATA_WIDTH +: DATA_WIDTH] = req_wdata[p*DATA_WIDTH +: DATA_WIDTH];
      assign h_wstrb[p*NBYTES +: NBYTES]         = req_wstrb[p*NBYTES +: NBYTES];
      assign h_tag[p*TAG_W +: TAG_W]             = req_tag[p*TAG_W +: TAG_W];
      assign req_ready[p]                        = p_issue[p];
      assign q_nonempty[p]                       = 1'b0;
      assign p_wait_inc[p*WCW +: WCW]            = WCW'(req_valid[p] && !p_issue[p]);
    end else begin : g_queue
      // registered request queue (DataFabric dma_fifo, unmodified): first-word
      // fall-through, pushed on acceptance, popped on issue
      localparam int QAW = $clog2(QUEUE_DEPTH);
      localparam logic [QAW:0] QD = (QAW+1)'(QUEUE_DEPTH);
      logic [QAW:0]    cnt;
      logic [REQW-1:0] q_head;
      wire push = req_valid[p] && req_ready[p];
      dma_fifo #(.WIDTH(REQW), .DEPTH(QUEUE_DEPTH)) u_queue (
        .clk(clk), .rst_n(rst_n), .clr(1'b0),
        .push(push),
        .wdata({req_we[p], req_addr[p*ADDR_WIDTH +: ADDR_WIDTH], req_wdata[p*DATA_WIDTH +: DATA_WIDTH],
                req_wstrb[p*NBYTES +: NBYTES], req_tag[p*TAG_W +: TAG_W]}),
        .pop(p_issue[p]), .rdata(q_head), .count(cnt)
      );
      assign req_ready[p] = live_q && (cnt != QD);
      assign h_valid[p]   = (cnt != '0);
      assign {h_we[p], h_addr[p*ADDR_WIDTH +: ADDR_WIDTH], h_wdata[p*DATA_WIDTH +: DATA_WIDTH],
              h_wstrb[p*NBYTES +: NBYTES], h_tag[p*TAG_W +: TAG_W]} = q_head;
      assign q_nonempty[p] = h_valid[p];
      // queued-and-not-issued entries + the presented input (accepted or not)
      assign p_wait_inc[p*WCW +: WCW] = WCW'(cnt) - WCW'(p_issue[p]) + WCW'(req_valid[p]);
    end

    hpc_spm_addr_map #(
      .ADDR_WIDTH(ADDR_WIDTH), .CAPACITY_BYTES(CAPACITY_BYTES), .BASE_ADDR(BASE_ADDR), .DATA_WIDTH(DATA_WIDTH),
      .NUM_BANKS(NUM_BANKS), .MAP(MAP), .BYTE_WE(BYTE_WE)
    ) u_map (
      .addr(h_addr[p*ADDR_WIDTH +: ADDR_WIDTH]), .we(h_we[p]), .wstrb(h_wstrb[p*NBYTES +: NBYTES]),
      .ok(h_ok[p]), .err_code(h_code[p*3 +: 3]), .bank(h_bank[p*BWX +: BWX]), .row(h_row[p*RW +: RW]),
      .boff(h_boff[p*OFFX +: OFFX])
    );

    // response credit: every read, every acknowledged write and every error
    // needs one; a posted (WRITE_ACK = 0) error-free write needs none
    assign p_need[p]   = !h_we[p] || (WRITE_ACK != 0) || !h_ok[p];
    assign p_credit[p] = p_can[p] || (!p_need[p] && live_q);
    assign p_elig[p]   = h_valid[p] && h_ok[p] && p_credit[p];
    // decode errors need no bank: issued as soon as a response credit is free
    assign p_issue[p]  = p_gnt[p] || (h_valid[p] && !h_ok[p] && p_can[p]);
  end

  // ============================================================ per-bank arbitration and banks
  logic [NUM_BANKS*NUM_PORTS-1:0] b_gnt_a, b_gnt_b;
  logic [NUM_BANKS-1:0]           b_any_a, b_any_b, b_we_a, b_we_b, b_rd_a, b_rd_b;
  logic [NUM_BANKS*PW-1:0]        b_idx_a, b_idx_b;
  logic [NUM_BANKS*STORE_W-1:0]   b_rdata_a, b_rdata_b;

  for (genvar b = 0; b < NUM_BANKS; b++) begin : g_bank
    logic [NUM_PORTS-1:0] breq, gnt_a, gnt_b;
    logic                 contended;
    always_comb begin
      for (int p = 0; p < NUM_PORTS; p++)
        breq[p] = p_elig[p] && (h_bank[p*BWX +: BWX] == BWX'(b));
    end

    hpc_spm_bank_arb #(.NUM_PORTS(NUM_PORTS), .PORT_MODE(PORT_MODE), .ARB(ARB), .RW(RW)) u_arb (
      .clk(clk), .rst_n(rst_n), .req(breq), .we(h_we), .row(h_row),
      .gnt_a(gnt_a), .gnt_b(gnt_b), .any_a(b_any_a[b]), .any_b(b_any_b[b]),
      .idx_a(b_idx_a[b*PW +: PW]), .idx_b(b_idx_b[b*PW +: PW]), .contended(contended)
    );
    assign b_gnt_a[b*NUM_PORTS +: NUM_PORTS] = gnt_a;
    assign b_gnt_b[b*NUM_PORTS +: NUM_PORTS] = gnt_b;
    assign ev_bank_conflict[b]  = contended;
    assign ev_bank_ops[b*2 +: 2] = {1'b0, b_any_a[b]} + {1'b0, b_any_b[b]};

    // slot multiplexers (one-hot grants: AND-OR)
    logic                  a_we, b_we;
    logic [RW-1:0]         a_row, b_row;
    logic [DATA_WIDTH-1:0] a_wd, b_wd;
    logic [NBYTES-1:0]     a_ws, b_ws;
    always_comb begin
      a_we = 1'b0; a_row = '0; a_wd = '0; a_ws = '0;
      b_we = 1'b0; b_row = '0; b_wd = '0; b_ws = '0;
      for (int p = 0; p < NUM_PORTS; p++) begin
        if (gnt_a[p]) begin
          a_we  = a_we  | h_we[p];
          a_row = a_row | h_row[p*RW +: RW];
          a_wd  = a_wd  | h_wdata[p*DATA_WIDTH +: DATA_WIDTH];
          a_ws  = a_ws  | h_wstrb[p*NBYTES +: NBYTES];
        end
        if (gnt_b[p]) begin
          b_we  = b_we  | h_we[p];
          b_row = b_row | h_row[p*RW +: RW];
          b_wd  = b_wd  | h_wdata[p*DATA_WIDTH +: DATA_WIDTH];
          b_ws  = b_ws  | h_wstrb[p*NBYTES +: NBYTES];
        end
      end
    end
    assign b_we_a[b] = a_we;
    assign b_we_b[b] = b_we;
    assign b_rd_a[b] = b_any_a[b] && !a_we;
    assign b_rd_b[b] = b_any_b[b] && !b_we;

    hpc_spm_bank #(
      .DATA_WIDTH(DATA_WIDTH), .DEPTH(BANK_DEPTH), .READ_LATENCY(READ_LATENCY), .PORT_MODE(PORT_MODE),
      .BYTE_WE(BYTE_WE), .ECC_MODE(ECC_MODE), .BACKEND(BACKEND), .MACRO(MACRO)
    ) u_bank (
      .clk(clk),
      .a_ce(b_any_a[b]), .a_we(a_we), .a_row(a_row), .a_wdata(a_wd), .a_wstrb(a_ws),
      .a_rdata(b_rdata_a[b*STORE_W +: STORE_W]),
      .b_ce(b_any_b[b]), .b_we(b_we), .b_row(b_row), .b_wdata(b_wd), .b_wstrb(b_ws),
      .b_rdata(b_rdata_b[b*STORE_W +: STORE_W])
    );
  end

  always_comb begin
    p_gnt = '0;
    for (int b = 0; b < NUM_BANKS; b++)
      p_gnt = p_gnt | b_gnt_a[b*NUM_PORTS +: NUM_PORTS] | b_gnt_b[b*NUM_PORTS +: NUM_PORTS];
  end

  // ============================================================ read-data owner pipelines
  // stage k of bank b, slot s: index b*READ_LATENCY + k.  The last stage is
  // aligned with the bank's read data (READ_LATENCY cycles after the read edge).
  localparam int NS = NUM_BANKS * READ_LATENCY;
  logic [NS-1:0]    own_va, own_vb;
  logic [NS*PW-1:0] own_ia, own_ib;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      own_va <= '0;
      own_vb <= '0;
    end else begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        own_va[b*READ_LATENCY] <= b_rd_a[b];
        own_vb[b*READ_LATENCY] <= b_rd_b[b];
        for (int k = 1; k < READ_LATENCY; k++) begin
          own_va[b*READ_LATENCY + k] <= own_va[b*READ_LATENCY + k - 1];
          own_vb[b*READ_LATENCY + k] <= own_vb[b*READ_LATENCY + k - 1];
        end
      end
    end
  end
  always_ff @(posedge clk) begin
    for (int b = 0; b < NUM_BANKS; b++) begin
      own_ia[(b*READ_LATENCY)*PW +: PW] <= b_idx_a[b*PW +: PW];
      own_ib[(b*READ_LATENCY)*PW +: PW] <= b_idx_b[b*PW +: PW];
      for (int k = 1; k < READ_LATENCY; k++) begin
        own_ia[(b*READ_LATENCY + k)*PW +: PW] <= own_ia[(b*READ_LATENCY + k - 1)*PW +: PW];
        own_ib[(b*READ_LATENCY + k)*PW +: PW] <= own_ib[(b*READ_LATENCY + k - 1)*PW +: PW];
      end
    end
  end

  logic [NUM_PORTS*STORE_W-1:0] p_raw;
  logic [NUM_PORTS-1:0]         p_owned;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NUM_PORTS-1:0]         p_owned2;    // two sources in one cycle (assertion)
  /* verilator lint_on UNUSEDSIGNAL */
  always_comb begin
    for (int p = 0; p < NUM_PORTS; p++) begin
      p_raw[p*STORE_W +: STORE_W] = '0;
      p_owned[p]  = 1'b0;
      p_owned2[p] = 1'b0;
      for (int b = 0; b < NUM_BANKS; b++) begin
        if (own_va[b*READ_LATENCY + READ_LATENCY - 1] &&
            own_ia[(b*READ_LATENCY + READ_LATENCY - 1)*PW +: PW] == PW'(p)) begin
          p_raw[p*STORE_W +: STORE_W] = p_raw[p*STORE_W +: STORE_W] | b_rdata_a[b*STORE_W +: STORE_W];
          p_owned2[p] = p_owned2[p] | p_owned[p];
          p_owned[p]  = 1'b1;
        end
        if (own_vb[b*READ_LATENCY + READ_LATENCY - 1] &&
            own_ib[(b*READ_LATENCY + READ_LATENCY - 1)*PW +: PW] == PW'(p)) begin
          p_raw[p*STORE_W +: STORE_W] = p_raw[p*STORE_W +: STORE_W] | b_rdata_b[b*STORE_W +: STORE_W];
          p_owned2[p] = p_owned2[p] | p_owned[p];
          p_owned[p]  = 1'b1;
        end
      end
    end
  end

  // ============================================================ per-port integrity check + response path
  logic [NUM_PORTS-1:0] p_busy, p_stg_v, p_stg_rd;
  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_rsp
    logic [RSPW-1:0]    arr, out;
    logic [IDW-1:0]     out_id;
    logic [NBYTES-1:0]  syn_stage, syn_out;
    logic [DATA_WIDTH-1:0] data_stage;
    logic               path_err;
    for (genvar l = 0; l < NBYTES; l++) begin : g_lane
      assign data_stage[l*8 +: 8] = p_raw[p*STORE_W + l*LANE_W +: 8];
      if (PAR != 0) begin : g_par
        // odd parity: the 9 stored bits of a good lane XOR to 1
        assign syn_stage[l] = ~^p_raw[p*STORE_W + l*LANE_W +: LANE_W];
      end else begin : g_nopar
        assign syn_stage[l] = 1'b0;
      end
    end
    if (PAR != 0) begin : g_arr_par
      assign arr     = {syn_stage, data_stage};
      assign syn_out = out[DATA_WIDTH +: NBYTES];
    end else begin : g_arr
      assign arr     = data_stage;
      assign syn_out = '0;
    end
    assign ev_ecc_err[p] = (PAR != 0) && p_stg_v[p] && p_stg_rd[p] && (|syn_stage);

    sram_rsp_path #(
      .DATA_WIDTH(RSPW), .LATENCY(READ_LATENCY), .FIFO_DEPTH(RSP_FIFO_DEPTH), .ID_WIDTH(IDW)
    ) u_rsp (
      .clk(clk), .rst_n(rst_n), .can_issue(p_can[p]),
      .iss_valid(p_issue[p] && p_need[p]), .iss_rd(!h_we[p] && h_ok[p]), .iss_err(!h_ok[p]), .iss_we(h_we[p]),
      .iss_id({h_code[p*3 +: 3], h_tag[p*TAG_W +: TAG_W]}),
      .arr_rdata(arr), .stg_valid(p_stg_v[p]), .stg_rd(p_stg_rd[p]),
      .rsp_valid(rsp_valid[p]), .rsp_ready(rsp_ready[p]), .rsp_rdata(out), .rsp_err(path_err),
      .rsp_we(rsp_we[p]), .rsp_id(out_id), .busy(p_busy[p])
    );

    logic [2:0] code;
    always_comb begin
      if (out_id[TAG_W +: 3] != `HPC_SPM_ERR_OK) code = out_id[TAG_W +: 3];
      else if (|syn_out)                         code = `HPC_SPM_ERR_PARITY;
      else                                       code = `HPC_SPM_ERR_OK;
    end
    assign rsp_err_code[p*3 +: 3]          = code;
    assign rsp_err[p]                      = (code != `HPC_SPM_ERR_OK);
    assign rsp_rdata[p*DATA_WIDTH +: DATA_WIDTH] = (code != `HPC_SPM_ERR_OK) ? '0 : out[DATA_WIDTH-1:0];
    assign rsp_tag[p*TAG_W +: TAG_W]       = out_id[TAG_W-1:0];
    assign rsp_ecc_syn[p*NBYTES +: NBYTES] = syn_out;
    wire unused_rsp = &{1'b0, path_err};
  end

  // ============================================================ events
  for (genvar p = 0; p < NUM_PORTS; p++) begin : g_ev
    assign ev_accept[p]       = req_valid[p] && req_ready[p];
    assign ev_issue[p]        = p_issue[p];
    assign ev_conflict[p]     = p_elig[p] && !p_gnt[p];
    assign ev_credit_stall[p] = h_valid[p] && live_q && (h_ok[p] ? !p_credit[p] : !p_can[p]);
    assign ev_error[p]        = p_issue[p] && !h_ok[p];
  end
  assign busy = (|p_busy) || (|q_nonempty);

  // ============================================================ performance counters
  if (PERF_EN != 0) begin : g_perf
    logic [NUM_PORTS-1:0] ev_complete;
    assign ev_complete = rsp_valid & rsp_ready;
    hpc_spm_perf #(.NUM_PORTS(NUM_PORTS), .NUM_BANKS(NUM_BANKS), .CNT_W(CNT_W)) u_perf (
      .clk(clk), .rst_n(rst_n), .clear(perf_clear),
      .ev_accept(ev_accept), .ev_issue(ev_issue), .ev_complete(ev_complete), .ev_conflict(ev_conflict),
      .ev_error(ev_error), .wait_inc(p_wait_inc), .ev_bank_ops(ev_bank_ops), .ev_ecc_err(ev_ecc_err),
      .cycles(perf_cycles), .accept(perf_accept), .issue(perf_issue), .complete(perf_complete),
      .conflict(perf_conflict), .waitc(perf_wait), .error(perf_error), .bank_ops(perf_bank_ops),
      .ecc_err(perf_ecc_err)
    );
  end else begin : g_noperf
    assign perf_cycles = '0; assign perf_accept = '0; assign perf_issue = '0; assign perf_complete = '0;
    assign perf_conflict = '0; assign perf_wait = '0; assign perf_error = '0; assign perf_bank_ops = '0;
    assign perf_ecc_err = '0;
    wire unused_perf = &{1'b0, perf_clear, p_wait_inc};
  end

  // ============================================================ embedded checkers
`ifdef HPC_SPM_ASSERT
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) begin
    if (rst_n) begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        logic [NUM_PORTS-1:0] ga, gb;
        ga = b_gnt_a[b*NUM_PORTS +: NUM_PORTS];
        gb = b_gnt_b[b*NUM_PORTS +: NUM_PORTS];
        `SRAM_CHK($countones(ga) <= 1, "bank slot A granted to more than one port")
        `SRAM_CHK($countones(gb) <= 1, "bank slot B granted to more than one port")
        `SRAM_CHK((ga & gb) == '0, "one port granted both slots of a bank")
        `SRAM_CHK(PORT_MODE != `HPC_SPM_PORT_1RW || gb == '0, "1RW bank used slot B")
        `SRAM_CHK(PORT_MODE != `HPC_SPM_PORT_1R1W || !b_any_a[b] || b_we_a[b], "1R1W write slot used for a read")
        `SRAM_CHK(PORT_MODE != `HPC_SPM_PORT_1R1W || !b_any_b[b] || !b_we_b[b], "1R1W read slot used for a write")
      end
      for (int p = 0; p < NUM_PORTS; p++) begin
        `SRAM_CHK(!p_gnt[p] || p_elig[p], "grant without an eligible request")
        `SRAM_CHK(p_owned[p] == (p_stg_v[p] && p_stg_rd[p]), "read data owner and response stage disagree (misrouted or dropped read)")
        `SRAM_CHK(!p_owned2[p], "two bank slots returned data to one port in one cycle (duplicated read)")
      end
    end
  end
  /* verilator lint_on SYNCASYNCNET */
`endif

  end // g_core

endmodule

`default_nettype wire
