// =============================================================================
// SilicaFlux-HPC Module 04 :: hpc_spm_perf
// Saturating event counters of the scratchpad (PERF_EN = 1).  All counters
// are CNT_W bits, reset by rst_n and by perf_clear (synchronous), and
// saturate at all-ones instead of wrapping.
//
//   cycles            cycles since the last clear
//   accept[p]         requests accepted (req_valid && req_ready)
//   issue[p]          requests issued to a bank or to the error path
//   complete[p]       responses delivered (rsp_valid && rsp_ready)
//   conflict[p]       cycles in which port p had an issuable request that lost
//                     bank arbitration (ev_conflict)
//   wait[p]           sum over cycles of requests of port p that were
//                     presented or queued but NOT issued in that cycle
//                     (Little's-law numerator: per request this is
//                     issue_cycle - present_cycle)
//   error[p]          error responses issued (decode errors; parity errors are
//                     counted in ecc_err)
//   bank_ops[b]       accesses performed by bank b (0, 1 or 2 per cycle)
//   ecc_err           read responses (all ports) that failed the integrity check
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module hpc_spm_perf #(
  parameter int  NUM_PORTS = 2,
  parameter int  NUM_BANKS = 2,
  parameter int  CNT_W     = 32,
  localparam int WCW       = 5                    // width of the per-cycle wait increment
) (
  input  wire logic                         clk,
  input  wire logic                         rst_n,
  input  wire logic                         clear,
  input  wire logic [NUM_PORTS-1:0]         ev_accept,
  input  wire logic [NUM_PORTS-1:0]         ev_issue,
  input  wire logic [NUM_PORTS-1:0]         ev_complete,
  input  wire logic [NUM_PORTS-1:0]         ev_conflict,
  input  wire logic [NUM_PORTS-1:0]         ev_error,
  input  wire logic [NUM_PORTS*WCW-1:0]     wait_inc,
  input  wire logic [NUM_BANKS*2-1:0]       ev_bank_ops,
  input  wire logic [NUM_PORTS-1:0]         ev_ecc_err,
  output logic      [CNT_W-1:0]             cycles,
  output logic      [NUM_PORTS*CNT_W-1:0]   accept,
  output logic      [NUM_PORTS*CNT_W-1:0]   issue,
  output logic      [NUM_PORTS*CNT_W-1:0]   complete,
  output logic      [NUM_PORTS*CNT_W-1:0]   conflict,
  output logic      [NUM_PORTS*CNT_W-1:0]   waitc,
  output logic      [NUM_PORTS*CNT_W-1:0]   error,
  output logic      [NUM_BANKS*CNT_W-1:0]   bank_ops,
  output logic      [CNT_W-1:0]             ecc_err
);

  localparam logic [CNT_W-1:0] MAXV = {CNT_W{1'b1}};

  function automatic logic [CNT_W-1:0] sat_add(input logic [CNT_W-1:0] v, input logic [WCW-1:0] inc);
    logic [CNT_W:0] s;
    s = {1'b0, v} + {{(CNT_W+1-WCW){1'b0}}, inc};
    sat_add = s[CNT_W] ? MAXV : s[CNT_W-1:0];   // (no `return`: Yosys 0.33 front end)
  endfunction

  logic [WCW-1:0] ecc_inc;
  always_comb begin
    ecc_inc = '0;
    for (int p = 0; p < NUM_PORTS; p++) ecc_inc = ecc_inc + WCW'(ev_ecc_err[p]);
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cycles <= '0; accept <= '0; issue <= '0; complete <= '0; conflict <= '0; waitc <= '0;
      error <= '0; bank_ops <= '0; ecc_err <= '0;
    end else if (clear) begin
      cycles <= '0; accept <= '0; issue <= '0; complete <= '0; conflict <= '0; waitc <= '0;
      error <= '0; bank_ops <= '0; ecc_err <= '0;
    end else begin
      cycles  <= sat_add(cycles, WCW'(1));
      ecc_err <= sat_add(ecc_err, ecc_inc);
      for (int p = 0; p < NUM_PORTS; p++) begin
        accept[p*CNT_W +: CNT_W]   <= sat_add(accept[p*CNT_W +: CNT_W],   WCW'(ev_accept[p]));
        issue[p*CNT_W +: CNT_W]    <= sat_add(issue[p*CNT_W +: CNT_W],    WCW'(ev_issue[p]));
        complete[p*CNT_W +: CNT_W] <= sat_add(complete[p*CNT_W +: CNT_W], WCW'(ev_complete[p]));
        conflict[p*CNT_W +: CNT_W] <= sat_add(conflict[p*CNT_W +: CNT_W], WCW'(ev_conflict[p]));
        error[p*CNT_W +: CNT_W]    <= sat_add(error[p*CNT_W +: CNT_W],    WCW'(ev_error[p]));
        waitc[p*CNT_W +: CNT_W]    <= sat_add(waitc[p*CNT_W +: CNT_W],    wait_inc[p*WCW +: WCW]);
      end
      for (int b = 0; b < NUM_BANKS; b++)
        bank_ops[b*CNT_W +: CNT_W] <= sat_add(bank_ops[b*CNT_W +: CNT_W], WCW'(ev_bank_ops[b*2 +: 2]));
    end
  end

endmodule

`default_nettype wire
