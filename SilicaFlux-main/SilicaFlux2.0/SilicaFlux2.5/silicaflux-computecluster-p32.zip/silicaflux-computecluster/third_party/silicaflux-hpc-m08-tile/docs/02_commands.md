# 02 — Commands and completion records

Encodings are defined once in `rtl/hpc_tile_defs.svh`. `scripts/gen_headers.py` generates the C header
(`sw/include/hpc_tile_regs.h`) and the Python constants (`model/tile_defs.py`) from it.

## 1. Descriptor (8 × 32-bit words, written to CMD0..CMD7, submitted by DOORBELL)

| Word | Bits | Field | Meaning |
|---|---|---|---|
| W0 | 3:0 | TYPE | 0 NOP, 1 DMA, 2 VEC, 3 KERNEL; 4..15 reserved (BAD_TYPE) |
| | 8:4 | VOP | element operation, Module 02 encoding (FMV 00, FADD 01, FSUB 02, FMUL 03, FMADD 04, FMSUB 05, FNMSUB 06, FNMADD 07, FMIN 08, FMAX 09, FEQ 0A, FLT 0B, FLE 0C, IADD 10, IMUL 11) |
| | 11:9 | RM | RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4 |
| | 14:12 | BCAST | {c, b, a}: replace that operand of every element by SCALAR |
| | 15 | RED | 1 = sum-reduce the element results (Module 03 §9.3, defined order) |
| | 23:16 | TAG | host tag, echoed in the completion record |
| | 24 | FENCE | start only after every older command has completed |
| | 31:25 | — | reserved, must be 0 (BAD_RSVD) |
| W1 | | VL / LEN | elements (VEC, KERNEL) or bytes (DMA) |
| W2 | | SCALAR | broadcast scalar; initial value of a reduction |
| W3 | | A | VEC: scratchpad address; KERNEL: host address; DMA: SRC |
| W4 | | B | VEC: scratchpad address; KERNEL: host address; DMA: DST |
| W5 | | C | VEC: scratchpad address; KERNEL: host address |
| W6 | | D | destination: VEC scratchpad, KERNEL host |
| W7 | | STAGE | KERNEL: scratchpad staging base |

Words a command type does not use are ignored. An operand is **read** when the operation reads it and it is
not broadcast:
* a: every operation;
* b: every operation except FMV;
* c: the FMA family only.

## 2. Command types

| TYPE | Semantics | Units used |
|---|---|---|
| NOP | completes immediately (with FENCE: after everything older) | none |
| DMA | copy LEN bytes SRC → DST: host → scratchpad, scratchpad → host, scratchpad → scratchpad, host → host. Byte-accurate lengths; SRC / DST DATA_WIDTH/8-aligned. Validated by the reused DataFabric `dma_validate` plus Module 05's REGION rule; any failure is reported as DMA_ERR with DETAIL = DMA code. | DMA |
| VEC | `D[e] = op(A[e], B[e], C[e])` for e < VL on scratchpad-resident data. With RED = 1, D receives the single reduction result, which is also in the completion record. | LSU + array |
| KERNEL | the complete memory → compute → memory sequence in **one** command. Steps: LOAD_A, LOAD_B, LOAD_C (only operands the operation reads), COMPUTE, STORE_D. Each step starts only after the previous one completed; the first failing step ends the command. Staging layout in the scratchpad: A at STAGE, B at STAGE + S, C at STAGE + 2S, D at STAGE + 3S, where S = VL·4 rounded up to DATA_WIDTH/8. | DMA + LSU + array (exclusive) |

## 3. Validation (before any side effect, first failing rule wins)

`BAD_TYPE > BAD_RSVD > BAD_OP > BAD_VL > ALIGN > SPM_RANGE > OVERLAP`. The last five apply to VEC and KERNEL.

| Rule | VEC | KERNEL |
|---|---|---|
| BAD_OP | `hpc_varray_pkg::cmd_legal`: the array's own legality rule (reserved opcode; RM 5..7 on a rounding operation; a reduction of a non-arithmetic operation; a reduction with broadcast) | same |
| BAD_VL | VL = 0 or VL > VL_MAX (= SCRATCHPAD_BYTES/4) | same |
| ALIGN | A / B / C (if read) and D not DATA_WIDTH/8-aligned | STAGE, A / B / C (if read) and D |
| SPM_RANGE | any read range [x, x+4·VL) or the destination range (4 bytes for a reduction) outside the scratchpad window | the 4·S staging area outside the window |
| OVERLAP | elementwise: D partially overlaps a read range. D equal to a source base (exact in place) is allowed. A reduction has no rule: its word is stored after every load. | — |

A command that fails validation is never sent to a unit and completes, in order, with its status. Its
destination is untouched; the testbench checks this.

## 4. Completion record

| Register | Field | Meaning |
|---|---|---|
| CPL_INFO [7:0] | TAG | from W0 |
| [11:8] | STATUS | table below |
| [15:12] | TYPE | command type |
| [19:16] | DETAIL | DMA_ERR: DMA completion code (DataFabric codes 1..10 + REGION 11); SPM_ERR: scratchpad error code (RANGE 1, ALIGN 2, STROBE 3, PARITY 4) |
| [24:20] | FFLAGS | {NV, DZ, OF, UF, NX}: OR over the active elements (and the reduction adds) |
| [27:25] | STEP | KERNEL: step that produced the final status (LOAD_A 1, LOAD_B 2, LOAD_C 3, COMPUTE 4, STORE_D 5); 0 on success |
| [31] | VALID | a record is present (all fields 0 otherwise) |
| CPL_SEQ | SEQ | submission sequence number (16 bits; = SUBMITTED at the DOORBELL write) |
| CPL_COUNT | COUNT | elements computed (VEC, KERNEL), or bytes written and acknowledged (DMA; contiguous prefix on error) |
| CPL_RESULT | RESULT | reduction result |
| CPL_ERR_ADDR | ERR_ADDR | failing address (DMA bus error, REGION boundary, scratchpad error word) |
| CPL_CYCLES | CYCLES | cycles from dispatch to retirement (0 with ENABLE_PERF_COUNTERS = 0) |

| STATUS | Name | Executed? |
|---|---|---|
| 0 | OK | yes; every write acknowledged by its target |
| 1 | BAD_TYPE | no |
| 2 | BAD_RSVD | no |
| 3 | BAD_OP | no |
| 4 | BAD_VL | no |
| 5 | SPM_RANGE | no |
| 6 | ALIGN | no |
| 7 | OVERLAP | no |
| 8 | DMA_ERR | validation codes 1..7 and 11: no bus access; bus errors 8 / 9: the transfer stopped at the failing word |
| 9 | SPM_ERR | partially: stores issued before the error are in memory; none after it |
| 10 | ARRAY_ILL | no (defence in depth; unreachable while the scheduler's legality check exists) |
| 11 | CANCELLED | no (discarded by FLUSH) |

**Exactly one** record per accepted command, in submission order, carrying its TAG and SEQ. No record is ever
generated for a command that was not accepted (DOORBELL refused), and none for commands destroyed by a reset.
