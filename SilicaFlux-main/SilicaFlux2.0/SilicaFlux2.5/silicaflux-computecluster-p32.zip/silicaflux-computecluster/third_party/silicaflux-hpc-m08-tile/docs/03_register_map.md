# 03 — Register map

The tile's register file is one 4 KiB page on the SilicaFlux-V register bus (`sfv_periph_bridge`: `rb_sel`
one-cycle strobe, `rb_we`, `rb_addr[11:0]`, `rb_wdata`; `rb_rdata` / `rb_err` in the same cycle; side effects
at the end of the strobe cycle; 32-bit accesses only). In `sfv_soc_hpc` it is page 8, at `0x4000_8000`.

* Unmapped offsets and writes to read-only registers answer `rb_err = 1` and have no effect; the bridge
  turns this into an SFB2 error response.
* Reads have no side effects.
* Source: `rtl/hpc_tile_regs.sv`, offsets in `rtl/hpc_tile_defs.svh`.

| Offset | Name | Access | Reset | Description |
|---|---|---|---|---|
| 0x000 | ID | RO | `0x53464854` "SFHT" | |
| 0x004 | VERSION | RO | `0x0001_0000` | 1.0 |
| 0x008 | CONFIG0 | RO | | [7:0] NUM_LANES, [15:8] DATA_WIDTH/8, [20:16] log2 SCRATCHPAD_BYTES, [25:21] NUM_BANKS, [26] counters present, [27] buffered DMA, [28] host scratchpad window, [31:29] LSU ports − 1 |
| 0x00C | CONFIG1 | RO | | [7:0] CMD_QUEUE_DEPTH, [15:8] CPL_QUEUE_DEPTH, [23:16] log2 DMA_BUFFER_DEPTH (0 = simple engine), [31:24] number of counters |
| 0x010 | SPM_BASE | RO | | scratchpad window base (same address for the host window and for DMA) |
| 0x014 | VL_MAX | RO | | largest legal VL |
| 0x020 | CTRL | WO (reads 0) | | write 1: [0] SOFT_RESET, [1] RESUME, [2] FLUSH, [3] PERF_CLEAR |
| 0x024 | CFG | RW | `0x1` | [0] HALT_ON_ERROR, [1] PERF_FREEZE |
| 0x028 | STATUS | RO, [7:6] W1C | 0 | [0] BUSY, [1] HALTED, [2] FLUSHING, [3] SOFT_RESET in progress, [4] CMDQ_FULL, [5] CPL_VALID, [6] SUBMIT_OVF (sticky), [7] ERR (sticky: an error record was produced), [8] DMA_ACTIVE, [9] VEC_ACTIVE, [10] KERNEL_ACTIVE, [23:16] command-queue level, [31:24] completion-queue level |
| 0x030 | IRQ_EN | RW | 0 | [0] completion, [1] error completion, [2] halt |
| 0x034 | IRQ_STATUS | W1C | 0 | [0] a record was pushed, [1] an error record was pushed, [2] the scheduler halted; `irq = OR(IRQ_STATUS & IRQ_EN)` |
| 0x038 | SUBMITTED | RO | 0 | commands accepted since hard reset (the next SEQ) |
| 0x03C | CMDQ_FREE | RO | depth | free command-queue slots |
| 0x040 | CPL_INFO | RO | | head record: TAG, STATUS, TYPE, DETAIL, FFLAGS, STEP, VALID (doc 02 §4) |
| 0x044 | CPL_SEQ | RO | | |
| 0x048 | CPL_COUNT | RO | | |
| 0x04C | CPL_RESULT | RO | | |
| 0x050 | CPL_ERR_ADDR | RO | | |
| 0x054 | CPL_CYCLES | RO | | |
| 0x058 | CPL_POP | WO | | pop the head record (no effect when empty) |
| 0x080–0x09C | CMD0..CMD7 | RW | 0 | descriptor staging (W0..W7) |
| 0x0A0 | DOORBELL | WO | | push {SUBMITTED, CMD7..CMD0}. **Queue full or soft reset in progress → `rb_err = 1`, SUBMIT_OVF set, nothing queued** (never a silent drop, never a stalled bus) |
| 0x100 + 4i | PERF[i] | RO | 0 | counter i (32-bit, saturating; reads 0 when counters are absent) |

## Performance counters (`PERF[i]`)

| i | Name | Counts | | i | Name | Counts |
|---|---|---|---|---|---|---|
| 0 | CYCLES | cycles while not frozen | | 12 | LSU_LOADS | scratchpad loads accepted from the LSU |
| 1 | BUSY | cycles STATUS.BUSY | | 13 | LSU_STORES | scratchpad stores accepted from the LSU |
| 2 | SUBMITTED | commands accepted | | 14 | SPM_CONFLICTS | port-cycles lost to bank arbitration (all ports) |
| 3 | COMPLETED | records pushed | | 15 | OVERLAP | cycles DMA engine and vector unit both active |
| 4 | ERRORS | records with an error status | | 16 | HAZARD_STALL | cycles the next command waits only for an address hazard |
| 5 | CANCELLED | records CANCELLED | | 17 | HALTED | cycles halted |
| 6 | DMA_ACTIVE | cycles the DMA engine executes | | 18 | CMDQ_FULL | cycles the command queue is full |
| 7 | DMA_BYTES_RD | bytes of error-free DMA read responses | | 19 | CPLQ_STALL | cycles retirement waits for completion-queue space |
| 8 | DMA_BYTES_WR | bytes committed by error-free DMA writes | | 20 | HOST_SPM | host scratchpad-window requests accepted |
| 9 | VEC_ACTIVE | cycles the vector unit holds a job | | 21 | DMA_CMDS | DMA commands completed OK |
| 10 | VEC_ELEMS | active elements computed | | 22 | VEC_CMDS | VEC commands completed OK |
| 11 | VEC_FLOPS | elements × (FADD/FSUB/FMUL 1, FMA family 2, others 0) | | 23 | KERNEL_CMDS | KERNEL commands completed OK |

Counter rules:
* PERF_CLEAR zeroes every counter and wins over a simultaneous event.
* PERF_FREEZE holds every counter.
* Counters are in the always-on domain, so a soft reset does not clear them.
