// =============================================================================
// SilicaFlux-HPC Module 05 :: hpc_dma_route
// Address router for ONE DMA engine port: SFB2 slave (from the reused
// DataFabric engine) -> two SFB2 targets
//   target 0 (SPM): the tile scratchpad window [SPM_BASE, SPM_BASE+SPM_BYTES)
//   target 1 (FAB): everything else -> the adapter's DataFabric master port
//
// Response ownership without IDs (SFB2 rev 2.0 has none, PROTOCOL.md sec. 8):
//   * all outstanding requests of this port target ONE target (tgt_q); up to
//     MAX_OUT of them (cnt_q);
//   * a request to the OTHER target is held (req_ready = 0, nothing presented
//     downstream) until every outstanding response has been accepted.  Each
//     target answers in order (SFB2 R5 / SPM H5), so the merged response
//     stream is in request order and every response goes back to the request
//     that caused it.  A response that retires in the same cycle counts as
//     gone (same rule as sfb_crossbar: full throughput with 1-cycle targets).
//   * responses are taken only from the owning target; a response from the
//     other target (impossible by construction) is never consumed and raises
//     ev_unsolicited (+ simulation assertion).
//   * downstream SFB2 R2 is preserved: once a request is presented to a
//     target, the hold condition can only relax (cnt_q only decreases while
//     the upstream request is held, tgt_q is unchanged while cnt_q > 0), so
//     the downstream valid stays high until accepted.
// Per-outstanding bookkeeping (write flag, committed-byte count of the write
// strobe) is kept in a MAX_OUT-entry FIFO so that the performance events count
// bytes when they are ACKNOWLEDGED (error-free response), not when requested.
//
// Combinational paths: req_* -> {spm,fab}_req_* ; {spm,fab}_req_ready ->
// req_ready ; {spm,fab}_rsp_* -> rsp_* ; rsp_ready -> {spm,fab}_rsp_ready ;
// {spm,fab}_rsp_valid, rsp_ready -> {spm,fab}_req_valid (retire-and-issue).
// Loop-free when the attached components obey SFB2 R3/R4 (they do: the engines
// register req_valid; targets never make rsp_valid depend on req_* in the
// same cycle, R5).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_dma_defs.svh"
`default_nettype none

module hpc_dma_route #(
  parameter int          DW        = 32,
  parameter logic [31:0] SPM_BASE  = 32'h2000_0000,
  parameter int          SPM_BYTES = 65536,       // power of two, SPM_BASE aligned to it
  parameter int          MAX_OUT   = 1,           // >= 1
  localparam int SB  = DW / 8,
  localparam int CW  = $clog2(((MAX_OUT > 0) ? MAX_OUT : 1) + 1),
  localparam int QW  = (MAX_OUT > 1) ? $clog2(MAX_OUT) : 1,
  localparam int MO  = (MAX_OUT > 0) ? MAX_OUT : 1,                 // storage depth (illegal 0 is reported)
  localparam int BCW = $clog2(SB + 1),
  localparam int CB  = (SPM_BYTES > 1) ? $clog2(SPM_BYTES) : 1
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  // ---------------------------------------------------------- upstream: engine port (SFB2 slave)
  input  wire logic          req_valid,
  output logic               req_ready,
  input  wire logic          req_write,
  input  wire logic [31:0]   req_addr,
  input  wire logic [DW-1:0] req_wdata,
  input  wire logic [SB-1:0] req_wstrb,
  output logic               rsp_valid,
  input  wire logic          rsp_ready,
  output logic [DW-1:0]      rsp_rdata,
  output logic               rsp_error,
  // ---------------------------------------------------------- target 0: scratchpad (SFB2 master)
  output logic               spm_req_valid,
  input  wire logic          spm_req_ready,
  output logic               spm_req_write,
  output logic [31:0]        spm_req_addr,
  output logic [DW-1:0]      spm_req_wdata,
  output logic [SB-1:0]      spm_req_wstrb,
  input  wire logic          spm_rsp_valid,
  output logic               spm_rsp_ready,
  input  wire logic [DW-1:0] spm_rsp_rdata,
  input  wire logic          spm_rsp_error,
  // ---------------------------------------------------------- target 1: DataFabric (SFB2 master)
  output logic               fab_req_valid,
  input  wire logic          fab_req_ready,
  output logic               fab_req_write,
  output logic [31:0]        fab_req_addr,
  output logic [DW-1:0]      fab_req_wdata,
  output logic [SB-1:0]      fab_req_wstrb,
  input  wire logic          fab_rsp_valid,
  output logic               fab_rsp_ready,
  input  wire logic [DW-1:0] fab_rsp_rdata,
  input  wire logic          fab_rsp_error,
  // ---------------------------------------------------------- events (this cycle)
  output logic               ev_req_rd,       // read request accepted
  output logic               ev_req_wr,       // write request accepted
  output logic               ev_req_spm,      // request accepted towards the scratchpad
  output logic               ev_req_fab,      // request accepted towards the DataFabric
  output logic               ev_req_stall,    // request presented upstream, not accepted
  output logic               ev_rsp,          // response accepted
  output logic               ev_rsp_err,      // ... with rsp_error
  output logic               ev_rd_ok,        // error-free read response (SB bytes read)
  output logic [BCW-1:0]     ev_wr_bytes,     // bytes committed by an error-free write response
  output logic               ev_unsolicited,  // a non-owning target presented a response (never expected)
  output logic [CW-1:0]      outstanding      // requests outstanding (registered)
);
  if (MAX_OUT < 1) begin : g_err_max_out
    `SRAM_CFG_FATAL("hpc_dma_route: MAX_OUT must be >= 1")
  end
  if (SPM_BYTES < 8 || (SPM_BYTES & (SPM_BYTES - 1)) != 0 || (SPM_BASE & 32'(SPM_BYTES - 1)) != 32'd0) begin : g_err_window
    `SRAM_CFG_FATAL("hpc_dma_route: SPM_BYTES must be a power of two and SPM_BASE aligned to it")
  end

  logic [CW-1:0] cnt_q;
  logic          tgt_q;                    // 0 = SPM, 1 = FAB (valid while cnt_q != 0)

  // ---------------------------------------------------------- decode: aligned power-of-two window, no aliasing
  wire sel_fab = (req_addr[31:CB] != SPM_BASE[31:CB]);

  // ---------------------------------------------------------- response side (from the owning target)
  wire own     = (cnt_q != '0);
  assign rsp_valid     = own && (tgt_q ? fab_rsp_valid : spm_rsp_valid);
  assign rsp_rdata     = tgt_q ? fab_rsp_rdata : spm_rsp_rdata;
  assign rsp_error     = tgt_q ? fab_rsp_error : spm_rsp_error;
  assign spm_rsp_ready = own && !tgt_q && rsp_ready;
  assign fab_rsp_ready = own &&  tgt_q && rsp_ready;
  wire rsp_hs  = rsp_valid && rsp_ready;

  // ---------------------------------------------------------- request side
  wire [CW-1:0] cnt_eff = cnt_q - CW'(rsp_hs);          // a retiring response frees its slot now
  wire allow   = (cnt_eff == '0) || ((tgt_q == sel_fab) && (cnt_eff < CW'(MAX_OUT)));

  assign spm_req_valid = req_valid && allow && !sel_fab;
  assign fab_req_valid = req_valid && allow &&  sel_fab;
  assign req_ready     = allow && (sel_fab ? fab_req_ready : spm_req_ready);
  assign spm_req_write = req_write;
  assign spm_req_addr  = req_addr;
  assign spm_req_wdata = req_wdata;
  assign spm_req_wstrb = req_wstrb;
  assign fab_req_write = req_write;
  assign fab_req_addr  = req_addr;
  assign fab_req_wdata = req_wdata;
  assign fab_req_wstrb = req_wstrb;
  wire req_hs  = req_valid && req_ready;

  // ---------------------------------------------------------- per-outstanding bookkeeping FIFO
  logic [BCW:0] info_q [0:MO-1];            // {write, strobe byte count}
  logic [QW-1:0] wp_q, rp_q;
  logic [BCW-1:0] nbytes;
  always_comb begin
    nbytes = '0;
    for (int b = 0; b < SB; b++) nbytes = nbytes + BCW'(req_wstrb[b]);
  end
  wire [BCW:0] head = info_q[rp_q];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cnt_q <= '0;
      tgt_q <= 1'b0;
      wp_q  <= '0;
      rp_q  <= '0;
    end else begin
      cnt_q <= cnt_q + CW'(req_hs) - CW'(rsp_hs);
      if (req_hs) begin
        tgt_q <= sel_fab;
        wp_q  <= (MAX_OUT > 1) ? ((wp_q == QW'(MAX_OUT - 1)) ? '0 : wp_q + 1'b1) : '0;
      end
      if (rsp_hs)
        rp_q  <= (MAX_OUT > 1) ? ((rp_q == QW'(MAX_OUT - 1)) ? '0 : rp_q + 1'b1) : '0;
    end
  end
  always_ff @(posedge clk) if (req_hs) info_q[wp_q] <= {req_write, req_write ? nbytes : BCW'(0)};

  // ---------------------------------------------------------- events
  assign ev_req_rd      = req_hs && !req_write;
  assign ev_req_wr      = req_hs &&  req_write;
  assign ev_req_spm     = req_hs && !sel_fab;
  assign ev_req_fab     = req_hs &&  sel_fab;
  assign ev_req_stall   = req_valid && !req_ready;
  assign ev_rsp         = rsp_hs;
  assign ev_rsp_err     = rsp_hs && rsp_error;
  assign ev_rd_ok       = rsp_hs && !rsp_error && !head[BCW];
  assign ev_wr_bytes    = (rsp_hs && !rsp_error && head[BCW]) ? head[BCW-1:0] : '0;
  assign ev_unsolicited = (spm_rsp_valid && !(own && !tgt_q)) || (fab_rsp_valid && !(own && tgt_q));
  assign outstanding    = cnt_q;

`ifdef HPC_DMA_ASSERT
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    assert (!ev_unsolicited) else $error("%m: response from a target that owns no outstanding request");
    assert (!(req_hs && cnt_q == CW'(MAX_OUT) && !rsp_hs)) else $error("%m: more than MAX_OUT outstanding");
    assert (!(rsp_valid && !own)) else $error("%m: response without an outstanding request");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
endmodule

`default_nettype wire
