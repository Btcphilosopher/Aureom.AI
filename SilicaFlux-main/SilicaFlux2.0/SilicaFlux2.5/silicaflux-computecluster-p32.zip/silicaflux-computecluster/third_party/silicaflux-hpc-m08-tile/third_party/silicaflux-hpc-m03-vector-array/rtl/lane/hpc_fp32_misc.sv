// =============================================================================
// SilicaFlux-HPC :: hpc_fp32_misc -- single-segment move / min / max / compare
//                                    / INT32 add unit
//
//   MOP_FMV   res = a, bit-exact (NaN payloads preserved), no flags
//   MOP_FMIN  IEEE 754-2019 minimumNumber == RISC-V FMIN.S:
//   MOP_FMAX  maximumNumber == RISC-V FMAX.S:
//               both NaN -> canonical NaN; one NaN -> the other operand;
//               -0 < +0; NV if either input is a signalling NaN.
//   MOP_FEQ   quiet equality   (+0 == -0); NV only for signalling NaN inputs
//   MOP_FLT   signalling <     ; NV for any NaN input
//   MOP_FLE   signalling <=    ; NV for any NaN input
//               comparisons return 32'd1 / 32'd0; NaN operands compare false
//   MOP_IADD  (a + b) mod 2^32, no flags
//
// EN_FCMP / EN_INT = 0 remove the corresponding logic (the lane decodes those
// opcodes as illegal, so they never reach this unit).
// Latency LAT >= 1 (LAT-1 output registers).
// =============================================================================
`default_nettype none

module hpc_fp32_misc #(
  parameter int LAT     = 1,
  parameter int IDW     = 3,
  parameter bit EN_FCMP = 1'b1,
  parameter bit EN_INT  = 1'b1
) (
  input  wire logic                              clk_i,
  input  wire logic                              rst_ni,
  input  wire logic                              valid_i,
  input  wire logic [IDW-1:0]                    id_i,
  input  wire logic [hpc_vector_pkg::MOP_W-1:0]  mop_i,
  input  wire logic [31:0]                       a_i,
  input  wire logic [31:0]                       b_i,
  output logic                                   valid_o,
  output logic [IDW-1:0]                         id_o,
  output logic [31:0]                            res_o,
  output logic [4:0]                             flags_o
);
  if (LAT < hpc_vector_pkg::MIN_LAT_MISC) begin : g_bad_lat
    hpc_param_error_LAT_MISC_below_minimum u_err ();
  end

  wire logic a_nan   = hpc_vector_pkg::fp_is_nan(a_i);
  wire logic b_nan   = hpc_vector_pkg::fp_is_nan(b_i);
  wire logic any_nan = a_nan | b_nan;
  wire logic any_snan = hpc_vector_pkg::fp_is_snan(a_i) | hpc_vector_pkg::fp_is_snan(b_i);
  wire logic both_zero = hpc_vector_pkg::fp_is_zero(a_i) & hpc_vector_pkg::fp_is_zero(b_i);

  // Ordering of non-NaN encodings.
  //   lt_num : numeric a < b   (+0 == -0)
  //   lt_mm  : a < b with -0 ordered below +0 (for min/max)
  wire logic mag_lt = a_i[30:0] < b_i[30:0];
  wire logic mag_gt = a_i[30:0] > b_i[30:0];
  wire logic lt_mm  = (a_i[31] != b_i[31]) ? a_i[31] : (a_i[31] ? mag_gt : mag_lt);
  wire logic lt_num = lt_mm & ~both_zero;
  wire logic eq_num = (a_i == b_i) | both_zero;

  logic [31:0] res;
  logic [4:0]  flags;
  always_comb begin
    res   = a_i;
    flags = 5'b00000;
    case (mop_i)
      hpc_vector_pkg::MOP_FMV: begin
        res = a_i;
      end
      hpc_vector_pkg::MOP_FMIN, hpc_vector_pkg::MOP_FMAX: begin
        if (EN_FCMP) begin
          flags[hpc_vector_pkg::FLAG_NV] = any_snan;
          if (a_nan & b_nan)   res = hpc_vector_pkg::FP32_QNAN;
          else if (a_nan)      res = b_i;
          else if (b_nan)      res = a_i;
          else if (mop_i == hpc_vector_pkg::MOP_FMIN) res = lt_mm ? a_i : b_i;
          else                                        res = lt_mm ? b_i : a_i;
        end else begin
          res = 32'd0;
        end
      end
      hpc_vector_pkg::MOP_FEQ: begin
        if (EN_FCMP) begin
          flags[hpc_vector_pkg::FLAG_NV] = any_snan;
          res = {31'd0, ~any_nan & eq_num};
        end else begin
          res = 32'd0;
        end
      end
      hpc_vector_pkg::MOP_FLT: begin
        if (EN_FCMP) begin
          flags[hpc_vector_pkg::FLAG_NV] = any_nan;
          res = {31'd0, ~any_nan & lt_num};
        end else begin
          res = 32'd0;
        end
      end
      hpc_vector_pkg::MOP_FLE: begin
        if (EN_FCMP) begin
          flags[hpc_vector_pkg::FLAG_NV] = any_nan;
          res = {31'd0, ~any_nan & (lt_num | eq_num)};
        end else begin
          res = 32'd0;
        end
      end
      hpc_vector_pkg::MOP_IADD: begin
        res = EN_INT ? (a_i + b_i) : 32'd0;
      end
      default: begin
        res = 32'd0;
      end
    endcase
  end

  hpc_pipe #(.W(IDW + 37), .N(LAT - 1)) u_po (
    .clk_i, .rst_ni, .valid_i(valid_i), .data_i({id_i, res, flags}),
    .valid_o(valid_o), .data_o({id_o, res_o, flags_o}));
endmodule
