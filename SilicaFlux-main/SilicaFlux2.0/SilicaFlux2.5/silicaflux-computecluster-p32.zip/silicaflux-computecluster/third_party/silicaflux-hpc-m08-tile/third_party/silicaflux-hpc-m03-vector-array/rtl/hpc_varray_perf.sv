// =============================================================================
// SilicaFlux-HPC :: hpc_varray_perf -- vector-array performance counters
//
// PC_N saturating counters (map: hpc_varray_pkg::PC_*), CW bits each, exposed
// as one flat read-only vector.  House pattern of sfb_perf_counters
// (DataFabric): counters saturate at all-ones (no silent wrap) and
// clear_i zeroes them synchronously.  Event inputs are the single-cycle
// pulses / per-cycle counts produced by the array sub-blocks.
// =============================================================================
`default_nettype none

module hpc_varray_perf #(
  parameter int N  = 2,
  parameter int CW = 32
) (
  input  wire logic                        clk_i,
  input  wire logic                        rst_ni,
  input  wire logic                        clear_i,
  input  wire logic                        ev_busy_i,
  input  wire logic                        ev_cmd_in_i,
  input  wire logic                        ev_cmd_done_i,
  input  wire logic                        ev_beat_in_i,
  input  wire logic                        ev_beat_out_i,
  input  wire logic [$clog2(N+1)-1:0]      ev_elem_in_i,
  input  wire logic [$clog2(N+1)-1:0]      ev_elem_out_i,
  input  wire logic                        ev_stall_lane_i,
  input  wire logic                        ev_stall_trk_i,
  input  wire logic [$clog2(N+1)-1:0]      ev_lane_stall_i,
  input  wire logic                        ev_opnd_starve_i,
  input  wire logic                        ev_res_bp_i,
  input  wire logic                        ev_coll_wait_i,
  input  wire logic                        ev_red_wait_i,
  input  wire logic                        ev_cpl_bp_i,
  output logic [hpc_varray_pkg::PC_N*CW-1:0] perf_cnt_o
);
  localparam int NC  = hpc_varray_pkg::PC_N;
  localparam int PCW = $clog2(N + 1);

  logic [NC*PCW-1:0] inc;
  always_comb begin
    inc = '0;
    inc[hpc_varray_pkg::PC_CYCLES      *PCW +: PCW] = PCW'(1);
    inc[hpc_varray_pkg::PC_BUSY        *PCW +: PCW] = PCW'(ev_busy_i);
    inc[hpc_varray_pkg::PC_CMD_IN      *PCW +: PCW] = PCW'(ev_cmd_in_i);
    inc[hpc_varray_pkg::PC_CMD_DONE    *PCW +: PCW] = PCW'(ev_cmd_done_i);
    inc[hpc_varray_pkg::PC_BEAT_IN     *PCW +: PCW] = PCW'(ev_beat_in_i);
    inc[hpc_varray_pkg::PC_BEAT_OUT    *PCW +: PCW] = PCW'(ev_beat_out_i);
    inc[hpc_varray_pkg::PC_ELEM_IN     *PCW +: PCW] = ev_elem_in_i;
    inc[hpc_varray_pkg::PC_ELEM_OUT    *PCW +: PCW] = ev_elem_out_i;
    inc[hpc_varray_pkg::PC_STALL_LANE  *PCW +: PCW] = PCW'(ev_stall_lane_i);
    inc[hpc_varray_pkg::PC_STALL_TRK   *PCW +: PCW] = PCW'(ev_stall_trk_i);
    inc[hpc_varray_pkg::PC_LANE_STALL  *PCW +: PCW] = ev_lane_stall_i;
    inc[hpc_varray_pkg::PC_OPND_STARVE *PCW +: PCW] = PCW'(ev_opnd_starve_i);
    inc[hpc_varray_pkg::PC_RES_BP      *PCW +: PCW] = PCW'(ev_res_bp_i);
    inc[hpc_varray_pkg::PC_COLL_WAIT   *PCW +: PCW] = PCW'(ev_coll_wait_i);
    inc[hpc_varray_pkg::PC_RED_WAIT    *PCW +: PCW] = PCW'(ev_red_wait_i);
    inc[hpc_varray_pkg::PC_CPL_BP      *PCW +: PCW] = PCW'(ev_cpl_bp_i);
  end

  for (genvar i = 0; i < NC; i++) begin : g_cnt
    logic [CW-1:0] c_q;
    wire  logic [CW:0] sum = {1'b0, c_q} + {{(CW+1-PCW){1'b0}}, inc[i*PCW +: PCW]};
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni)      c_q <= '0;
      else if (clear_i) c_q <= '0;
      else              c_q <= sum[CW] ? {CW{1'b1}} : sum[CW-1:0];
    end
    assign perf_cnt_o[i*CW +: CW] = c_q;
  end
endmodule
