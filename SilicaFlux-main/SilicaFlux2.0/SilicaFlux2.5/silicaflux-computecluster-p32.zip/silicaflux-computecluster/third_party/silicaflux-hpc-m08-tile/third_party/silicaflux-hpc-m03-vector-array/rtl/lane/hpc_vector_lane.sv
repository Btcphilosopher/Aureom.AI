// =============================================================================
// SilicaFlux-HPC :: hpc_vector_lane -- configurable HPC vector execution lane
//
// One reusable, synthesizable vector lane: accepts one operation per cycle
// (valid/ready), executes it on one of several fixed-latency, fully pipelined
// execution units of DIFFERENT latencies, and returns every result exactly
// once, IN ACCEPTANCE ORDER, with its transaction tag and IEEE exception
// flags (valid/ready).
//
// Pipeline (docs/MICROARCHITECTURE.md)
//   ACC  input acceptance, opcode decode, operand routing, completion-slot
//        allocation (in-order reorder buffer, ROB_DEPTH entries)
//   ISS  issue register: decoded micro-op + operands + ROB slot index
//   EXE  execution unit u, LAT_u segments; the last segment writes the
//        result/flags into the allocated ROB slot (completion)
//   RET  the oldest slot retires through out_valid_o/out_ready_i once complete
//
// Completion policy: IN-ORDER completion through a reorder buffer.  Execution
// units may finish out of order (different latencies); results are written to
// their pre-allocated slot and released strictly in acceptance order.  An
// operation is accepted only if a slot is free, so execution pipelines never
// stall and can never drop a result.
//
// Handshake / timing contract (docs/LANE_INTERFACE.md)
//   * in_ready_o and all out_* outputs are functions of registered state only
//     (no combinational input->output path through the lane).
//   * an operation is accepted in a cycle with in_valid_i & in_ready_o.
//   * lane_en_i is sampled with the operation.  A disabled operation is
//     consumed by the same handshake, is NOT decoded, NOT executed, produces
//     NO result and raises no flags (ev_masked_o pulses).
//   * illegal opcode / illegal rounding mode on a rounding operation: the
//     operation still completes (in order) with out_illegal_o = 1,
//     out_result_o = 0, out_flags_o = 0; no execution unit is used.
//   * reset (rst_ni low, asynchronous assert, synchronous de-assert by the
//     SoC reset synchronizer) discards all in-flight operations; in_ready_o
//     is 0 during reset and in the first cycle after de-assertion.
// =============================================================================
`default_nettype none

module hpc_vector_lane #(
  parameter int DATA_W    = 32,       // operand width (this version: 32)
  parameter int TAG_W     = 8,        // transaction tag width (>= 1)
  parameter int ROB_DEPTH = 8,        // completion slots (>= 1); full
                                      // throughput needs >= max LAT + 2
  parameter int LAT_FADD  = 3,        // >= 2
  parameter int LAT_FMUL  = 3,        // >= 2
  parameter int LAT_FMA   = 4,        // >= 3
  parameter int LAT_MISC  = 1,        // >= 1
  parameter int LAT_IMUL  = 2,        // >= 1
  parameter bit EN_FCMP   = 1'b1,     // FMIN/FMAX/FEQ/FLT/FLE implemented
  parameter bit EN_INT    = 1'b1      // IADD/IMUL implemented
) (
  input  wire logic                              clk_i,
  input  wire logic                              rst_ni,
  // ------------------------------------------------------------- operation in
  input  wire logic                              in_valid_i,
  output logic                                   in_ready_o,
  input  wire logic [hpc_vector_pkg::OP_W-1:0]   in_op_i,
  input  wire logic [DATA_W-1:0]                 in_a_i,
  input  wire logic [DATA_W-1:0]                 in_b_i,
  input  wire logic [DATA_W-1:0]                 in_c_i,
  input  wire logic [2:0]                        in_rm_i,
  input  wire logic [TAG_W-1:0]                  in_tag_i,
  input  wire logic                              lane_en_i,
  // ------------------------------------------------------------- result out
  output logic                                   out_valid_o,
  input  wire logic                              out_ready_i,
  output logic [DATA_W-1:0]                      out_result_o,
  output logic [hpc_vector_pkg::FLAGS_W-1:0]     out_flags_o,
  output logic [TAG_W-1:0]                       out_tag_o,
  output logic                                   out_illegal_o,
  // ------------------------------------------------------------- status
  output logic                                   busy_o,
  // ------------------------------------------------------------- perf events
  output logic                                   ev_accept_o,       // enabled op accepted
  output logic                                   ev_retire_o,       // result handed over
  output logic                                   ev_pipe_stall_o,   // op waiting, no slot
  output logic                                   ev_backpressure_o, // result waiting
  output logic                                   ev_illegal_o,      // illegal op accepted
  output logic                                   ev_masked_o        // disabled op consumed
);
  localparam int NU = hpc_vector_pkg::N_UNITS;
  localparam int IW = (ROB_DEPTH > 1) ? $clog2(ROB_DEPTH) : 1;
  localparam int CW = $clog2(ROB_DEPTH + 1);
  localparam int FW = hpc_vector_pkg::FLAGS_W;

  // --------------------------------------------------- elaboration checks
  if (DATA_W != 32) begin : g_bad_data_w
    hpc_param_error_DATA_W_must_be_32 u_err ();
  end
  if (TAG_W < 1) begin : g_bad_tag_w
    hpc_param_error_TAG_W_below_1 u_err ();
  end
  if (ROB_DEPTH < 1) begin : g_bad_depth
    hpc_param_error_ROB_DEPTH_below_1 u_err ();
  end

  function automatic logic [IW-1:0] ptr_inc(input logic [IW-1:0] p);
    ptr_inc = (p == IW'(ROB_DEPTH - 1)) ? '0 : p + IW'(1);
  endfunction

  // ===================================================================
  // ACC: acceptance, decode, routing
  // ===================================================================
  logic          init_q;                 // 0 in reset and first cycle after
  logic [CW-1:0] cnt_q;                  // occupied completion slots
  logic [IW-1:0] head_q, tail_q;

  assign in_ready_o = init_q && (cnt_q != CW'(ROB_DEPTH));

  wire logic hs_in  = in_valid_i & in_ready_o;
  wire logic alloc  = hs_in & lane_en_i;          // enabled op: takes a slot
  wire logic masked = hs_in & ~lane_en_i;         // disabled op: consumed only

  logic [NU-1:0]                    dec_unit;
  logic                             dec_legal, dec_sub, dec_negp, dec_nega;
  logic [hpc_vector_pkg::MOP_W-1:0] dec_mop;
  wire  logic                       rm_ok = hpc_vector_pkg::rm_legal(in_rm_i);

  always_comb begin
    dec_unit  = '0;
    dec_legal = 1'b0;
    dec_sub   = 1'b0;
    dec_negp  = 1'b0;
    dec_nega  = 1'b0;
    dec_mop   = hpc_vector_pkg::MOP_FMV;
    case (in_op_i)
      hpc_vector_pkg::OP_FMV:    begin dec_unit[hpc_vector_pkg::U_MISC] = 1'b1;
                                       dec_mop = hpc_vector_pkg::MOP_FMV;  dec_legal = 1'b1;    end
      hpc_vector_pkg::OP_FADD:   begin dec_unit[hpc_vector_pkg::U_FADD] = 1'b1; dec_legal = rm_ok; end
      hpc_vector_pkg::OP_FSUB:   begin dec_unit[hpc_vector_pkg::U_FADD] = 1'b1; dec_legal = rm_ok;
                                       dec_sub = 1'b1;                                             end
      hpc_vector_pkg::OP_FMUL:   begin dec_unit[hpc_vector_pkg::U_FMUL] = 1'b1; dec_legal = rm_ok; end
      hpc_vector_pkg::OP_FMADD:  begin dec_unit[hpc_vector_pkg::U_FMA]  = 1'b1; dec_legal = rm_ok; end
      hpc_vector_pkg::OP_FMSUB:  begin dec_unit[hpc_vector_pkg::U_FMA]  = 1'b1; dec_legal = rm_ok;
                                       dec_nega = 1'b1;                                            end
      hpc_vector_pkg::OP_FNMSUB: begin dec_unit[hpc_vector_pkg::U_FMA]  = 1'b1; dec_legal = rm_ok;
                                       dec_negp = 1'b1;                                            end
      hpc_vector_pkg::OP_FNMADD: begin dec_unit[hpc_vector_pkg::U_FMA]  = 1'b1; dec_legal = rm_ok;
                                       dec_negp = 1'b1; dec_nega = 1'b1;                           end
      hpc_vector_pkg::OP_FMIN:   begin dec_unit[hpc_vector_pkg::U_MISC] = 1'b1;
                                       dec_mop = hpc_vector_pkg::MOP_FMIN; dec_legal = EN_FCMP;  end
      hpc_vector_pkg::OP_FMAX:   begin dec_unit[hpc_vector_pkg::U_MISC] = 1'b1;
                                       dec_mop = hpc_vector_pkg::MOP_FMAX; dec_legal = EN_FCMP;  end
      hpc_vector_pkg::OP_FEQ:    begin dec_unit[hpc_vector_pkg::U_MISC] = 1'b1;
                                       dec_mop = hpc_vector_pkg::MOP_FEQ;  dec_legal = EN_FCMP;  end
      hpc_vector_pkg::OP_FLT:    begin dec_unit[hpc_vector_pkg::U_MISC] = 1'b1;
                                       dec_mop = hpc_vector_pkg::MOP_FLT;  dec_legal = EN_FCMP;  end
      hpc_vector_pkg::OP_FLE:    begin dec_unit[hpc_vector_pkg::U_MISC] = 1'b1;
                                       dec_mop = hpc_vector_pkg::MOP_FLE;  dec_legal = EN_FCMP;  end
      hpc_vector_pkg::OP_IADD:   begin dec_unit[hpc_vector_pkg::U_MISC] = 1'b1;
                                       dec_mop = hpc_vector_pkg::MOP_IADD; dec_legal = EN_INT;   end
      hpc_vector_pkg::OP_IMUL:   begin dec_unit[hpc_vector_pkg::U_IMUL] = 1'b1; dec_legal = EN_INT; end
      default:                   begin dec_legal = 1'b0;                                           end
    endcase
    if (!dec_legal) dec_unit = '0;
  end

  // ===================================================================
  // ISS: issue register (operand routing to the execution units)
  // ===================================================================
  logic [NU-1:0]                    iss_v_q;   // one-hot unit valid
  logic [IW-1:0]                    iss_id_q;
  logic [31:0]                      iss_a_q, iss_b_q, iss_c_q;
  logic [2:0]                       iss_rm_q;
  logic                             iss_sub_q, iss_negp_q, iss_nega_q;
  logic [hpc_vector_pkg::MOP_W-1:0] iss_mop_q;

  wire logic issue = alloc & dec_legal;

  always_ff @(posedge clk_i) begin           // datapath: qualified by iss_v_q
    if (issue) begin
      iss_id_q   <= tail_q;
      iss_a_q    <= in_a_i;
      iss_b_q    <= in_b_i;
      iss_c_q    <= in_c_i;
      iss_rm_q   <= in_rm_i;
      iss_sub_q  <= dec_sub;
      iss_negp_q <= dec_negp;
      iss_nega_q <= dec_nega;
      iss_mop_q  <= dec_mop;
    end
  end

  // ===================================================================
  // EXE: execution units
  // ===================================================================
  logic [NU-1:0]    u_vld;
  logic [NU*IW-1:0] u_id;
  logic [NU*32-1:0] u_res;
  logic [NU*FW-1:0] u_flg;

  hpc_fp32_add #(.LAT(LAT_FADD), .IDW(IW)) u_fadd (
    .clk_i, .rst_ni,
    .valid_i(iss_v_q[hpc_vector_pkg::U_FADD]), .id_i(iss_id_q),
    .a_i(iss_a_q), .b_i(iss_b_q), .sub_i(iss_sub_q), .rm_i(iss_rm_q),
    .valid_o(u_vld[hpc_vector_pkg::U_FADD]),
    .id_o   (u_id [hpc_vector_pkg::U_FADD*IW +: IW]),
    .res_o  (u_res[hpc_vector_pkg::U_FADD*32 +: 32]),
    .flags_o(u_flg[hpc_vector_pkg::U_FADD*FW +: FW]));

  hpc_fp32_mul #(.LAT(LAT_FMUL), .IDW(IW)) u_fmul (
    .clk_i, .rst_ni,
    .valid_i(iss_v_q[hpc_vector_pkg::U_FMUL]), .id_i(iss_id_q),
    .a_i(iss_a_q), .b_i(iss_b_q), .rm_i(iss_rm_q),
    .valid_o(u_vld[hpc_vector_pkg::U_FMUL]),
    .id_o   (u_id [hpc_vector_pkg::U_FMUL*IW +: IW]),
    .res_o  (u_res[hpc_vector_pkg::U_FMUL*32 +: 32]),
    .flags_o(u_flg[hpc_vector_pkg::U_FMUL*FW +: FW]));

  hpc_fp32_fma #(.LAT(LAT_FMA), .IDW(IW)) u_fma (
    .clk_i, .rst_ni,
    .valid_i(iss_v_q[hpc_vector_pkg::U_FMA]), .id_i(iss_id_q),
    .a_i(iss_a_q), .b_i(iss_b_q), .c_i(iss_c_q),
    .neg_prod_i(iss_negp_q), .neg_add_i(iss_nega_q), .rm_i(iss_rm_q),
    .valid_o(u_vld[hpc_vector_pkg::U_FMA]),
    .id_o   (u_id [hpc_vector_pkg::U_FMA*IW +: IW]),
    .res_o  (u_res[hpc_vector_pkg::U_FMA*32 +: 32]),
    .flags_o(u_flg[hpc_vector_pkg::U_FMA*FW +: FW]));

  hpc_fp32_misc #(.LAT(LAT_MISC), .IDW(IW), .EN_FCMP(EN_FCMP), .EN_INT(EN_INT)) u_misc (
    .clk_i, .rst_ni,
    .valid_i(iss_v_q[hpc_vector_pkg::U_MISC]), .id_i(iss_id_q), .mop_i(iss_mop_q),
    .a_i(iss_a_q), .b_i(iss_b_q),
    .valid_o(u_vld[hpc_vector_pkg::U_MISC]),
    .id_o   (u_id [hpc_vector_pkg::U_MISC*IW +: IW]),
    .res_o  (u_res[hpc_vector_pkg::U_MISC*32 +: 32]),
    .flags_o(u_flg[hpc_vector_pkg::U_MISC*FW +: FW]));

  if (EN_INT) begin : g_imul
    hpc_int32_mul #(.LAT(LAT_IMUL), .IDW(IW)) u_imul (
      .clk_i, .rst_ni,
      .valid_i(iss_v_q[hpc_vector_pkg::U_IMUL]), .id_i(iss_id_q),
      .a_i(iss_a_q), .b_i(iss_b_q),
      .valid_o(u_vld[hpc_vector_pkg::U_IMUL]),
      .id_o   (u_id [hpc_vector_pkg::U_IMUL*IW +: IW]),
      .res_o  (u_res[hpc_vector_pkg::U_IMUL*32 +: 32]),
      .flags_o(u_flg[hpc_vector_pkg::U_IMUL*FW +: FW]));
  end else begin : g_no_imul
    assign u_vld[hpc_vector_pkg::U_IMUL]            = 1'b0;
    assign u_id [hpc_vector_pkg::U_IMUL*IW +: IW]   = '0;
    assign u_res[hpc_vector_pkg::U_IMUL*32 +: 32]   = '0;
    assign u_flg[hpc_vector_pkg::U_IMUL*FW +: FW]   = '0;
  end

  // Completion one-hot per slot: cmp_hit[e] = some unit completes into slot e.
  logic [ROB_DEPTH-1:0] cmp_hit;
  always_comb begin
    cmp_hit = '0;
    for (int e = 0; e < ROB_DEPTH; e++)
      for (int u = 0; u < NU; u++)
        if (u_vld[u] && (u_id[u*IW +: IW] == IW'(e))) cmp_hit[e] = 1'b1;
  end

  // ===================================================================
  // ROB: completion slots
  // ===================================================================
  logic [ROB_DEPTH-1:0]       rob_done_q;     // result present
  logic [ROB_DEPTH-1:0]       rob_ill_q;      // illegal operation
  logic [ROB_DEPTH*32-1:0]    rob_res_q;
  logic [ROB_DEPTH*FW-1:0]    rob_flg_q;
  logic [ROB_DEPTH*TAG_W-1:0] rob_tag_q;

  wire logic retire;

  // datapath storage: written at allocation (tag) / completion (result)
  always_ff @(posedge clk_i) begin
    for (int e = 0; e < ROB_DEPTH; e++) begin
      if (alloc && (tail_q == IW'(e)))
        rob_tag_q[e*TAG_W +: TAG_W] <= in_tag_i;
      for (int u = 0; u < NU; u++) begin
        if (u_vld[u] && (u_id[u*IW +: IW] == IW'(e))) begin
          rob_res_q[e*32 +: 32] <= u_res[u*32 +: 32];
          rob_flg_q[e*FW +: FW] <= u_flg[u*FW +: FW];
        end
      end
    end
  end

  // control state
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      init_q     <= 1'b0;
      cnt_q      <= '0;
      head_q     <= '0;
      tail_q     <= '0;
      iss_v_q    <= '0;
      rob_done_q <= '0;
      rob_ill_q  <= '0;
    end else begin
      init_q  <= 1'b1;
      iss_v_q <= issue ? dec_unit : '0;
      if (alloc)  tail_q <= ptr_inc(tail_q);
      if (retire) head_q <= ptr_inc(head_q);
      cnt_q <= cnt_q + CW'(alloc) - CW'(retire);
      for (int e = 0; e < ROB_DEPTH; e++) begin
        if (retire && (head_q == IW'(e))) rob_done_q[e] <= 1'b0;
        if (alloc && (tail_q == IW'(e))) begin
          rob_done_q[e] <= ~dec_legal;          // illegal: complete at once
          rob_ill_q[e]  <= ~dec_legal;
        end
        if (cmp_hit[e]) rob_done_q[e] <= 1'b1;
      end
    end
  end

  // ===================================================================
  // RET: in-order retirement
  // ===================================================================
  wire logic             h_done = rob_done_q[head_q];
  wire logic             h_ill  = rob_ill_q[head_q];
  wire logic [31:0]      h_res  = rob_res_q[head_q*32 +: 32];
  wire logic [FW-1:0]    h_flg  = rob_flg_q[head_q*FW +: FW];
  wire logic [TAG_W-1:0] h_tag  = rob_tag_q[head_q*TAG_W +: TAG_W];

  assign out_valid_o   = h_done;
  assign retire        = out_valid_o & out_ready_i;
  // payload is forced to 0 when not valid (deterministic, X-free interface)
  assign out_result_o  = (h_done && !h_ill) ? h_res : '0;
  assign out_flags_o   = (h_done && !h_ill) ? h_flg : '0;
  assign out_tag_o     = h_done ? h_tag : '0;
  assign out_illegal_o = h_done & h_ill;

  assign busy_o = (cnt_q != '0);

  // ===================================================================
  // Performance events (single-cycle pulses, same cycle as the event)
  // ===================================================================
  assign ev_accept_o       = alloc;
  assign ev_retire_o       = retire;
  assign ev_pipe_stall_o   = in_valid_i & init_q & ~in_ready_o;
  assign ev_backpressure_o = out_valid_o & ~out_ready_i;
  assign ev_illegal_o      = alloc & ~dec_legal;
  assign ev_masked_o       = masked;

  // ===================================================================
  // Simulation-only structural checks
  // ===================================================================
`ifndef SYNTHESIS
  logic [ROB_DEPTH-1:0] sim_alloc_q;            // slot between alloc and retire
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sim_alloc_q <= '0;
    end else begin
      for (int e = 0; e < ROB_DEPTH; e++) begin
        int hits;
        hits = 0;
        for (int u = 0; u < NU; u++)
          if (u_vld[u] && (u_id[u*IW +: IW] == IW'(e))) hits = hits + 1;
        if (hits > 1)
          $fatal(1, "hpc_vector_lane: %0d completions into slot %0d in one cycle", hits, e);
        if (hits == 1 && (!sim_alloc_q[e] || rob_done_q[e]))
          $fatal(1, "hpc_vector_lane: completion into free or already-complete slot %0d", e);
        if (retire && head_q == IW'(e) && !sim_alloc_q[e])
          $fatal(1, "hpc_vector_lane: retire from unallocated slot %0d", e);
        if (alloc && tail_q == IW'(e) && sim_alloc_q[e])
          $fatal(1, "hpc_vector_lane: allocation into occupied slot %0d", e);
        if (retire && head_q == IW'(e)) sim_alloc_q[e] <= 1'b0;
        if (alloc  && tail_q == IW'(e)) sim_alloc_q[e] <= 1'b1;
      end
      if (alloc && !retire && cnt_q == CW'(ROB_DEPTH))
        $fatal(1, "hpc_vector_lane: slot counter overflow");
      if (retire && !alloc && cnt_q == '0)
        $fatal(1, "hpc_vector_lane: slot counter underflow");
    end
  end
`endif
endmodule
