// =============================================================================
// SilicaFlux-HPC :: hpc_fp32_add -- pipelined IEEE-754 binary32 adder
//
//   res = round(a + (sub_i ? -b : b))      all five rounding modes, full
//   subnormal support, IEEE 754-2019 / RISC-V exception flags, canonical NaN.
//
// Dedicated datapath (not derived from the FMA).  Two combinational segments:
//   A  unpack, special cases, magnitude swap, exact alignment, add/subtract
//   B  leading-zero count, normalize (B1) | round, pack (B2)
// Alignment keeps 26 bits below the larger operand's LSB, so the sum is exact
// whenever the exponent difference d <= 26; for d >= 27 the smaller operand is
// < 1/8 ulp of the larger one and is represented by a single sticky bit,
// which yields the identical rounding decision (docs/FP_SEMANTICS.md).
//
// Latency LAT >= 2: one register between A and B.  With LAT == 2 the output
// of B is combinational (the lane's completion buffer is the final
// register).  LAT >= 3 splits B into B1 (normalize) | B2 (round); any further
// stages are output registers (retiming slack).  Fully pipelined, never
// stalls.
// =============================================================================
`default_nettype none

module hpc_fp32_add #(
  parameter int LAT = 3,
  parameter int IDW = 3
) (
  input  wire logic           clk_i,
  input  wire logic           rst_ni,
  input  wire logic           valid_i,
  input  wire logic [IDW-1:0] id_i,
  input  wire logic [31:0]    a_i,
  input  wire logic [31:0]    b_i,
  input  wire logic           sub_i,
  input  wire logic [2:0]     rm_i,
  output logic                valid_o,
  output logic [IDW-1:0]      id_o,
  output logic [31:0]         res_o,
  output logic [4:0]          flags_o
);
  if (LAT < hpc_vector_pkg::MIN_LAT_FADD) begin : g_bad_lat
    hpc_param_error_LAT_FADD_below_minimum u_err ();
  end

  // =========================================================== segment A
  wire logic sa = a_i[31];
  wire logic sb = b_i[31] ^ sub_i;

  wire logic a_nan  = hpc_vector_pkg::fp_is_nan(a_i);
  wire logic b_nan  = hpc_vector_pkg::fp_is_nan(b_i);
  wire logic a_inf  = hpc_vector_pkg::fp_is_inf(a_i);
  wire logic b_inf  = hpc_vector_pkg::fp_is_inf(b_i);
  wire logic any_snan = hpc_vector_pkg::fp_is_snan(a_i) | hpc_vector_pkg::fp_is_snan(b_i);

  logic        spec, spec_nv;
  logic [31:0] spec_res;
  always_comb begin
    spec = 1'b1; spec_nv = 1'b0; spec_res = hpc_vector_pkg::FP32_QNAN;
    if (a_nan | b_nan) begin
      spec_nv = any_snan;
    end else if (a_inf & b_inf) begin
      if (sa != sb) spec_nv = 1'b1;                              // inf - inf
      else          spec_res = {sa, hpc_vector_pkg::FP32_INF_M};
    end else if (a_inf) begin
      spec_res = {sa, hpc_vector_pkg::FP32_INF_M};
    end else if (b_inf) begin
      spec_res = {sb, hpc_vector_pkg::FP32_INF_M};
    end else begin
      spec = 1'b0;
    end
  end

  wire logic [7:0]  ea   = hpc_vector_pkg::fp_exp(a_i);
  wire logic [7:0]  eb   = hpc_vector_pkg::fp_exp(b_i);
  wire logic [23:0] siga = hpc_vector_pkg::fp_sig(a_i);
  wire logic [23:0] sigb = hpc_vector_pkg::fp_sig(b_i);
  wire logic        a_ge = {ea, siga} >= {eb, sigb};             // |a| >= |b|

  logic [7:0]  ex, ey, dexp;
  logic [23:0] sigx, sigy;
  logic        sx, eff_sub;
  logic [49:0] xa, ya;
  logic [50:0] sum;
  always_comb begin
    ex   = a_ge ? ea   : eb;
    ey   = a_ge ? eb   : ea;
    sigx = a_ge ? siga : sigb;
    sigy = a_ge ? sigb : siga;
    sx   = a_ge ? sa   : sb;
    eff_sub = sa ^ sb;
    dexp = ex - ey;
    xa   = {sigx, 26'd0};
    if (dexp > 8'd26) ya = {49'd0, |sigy};                      // < 1/8 ulp: sticky
    else              ya = {sigy, 26'd0} >> dexp;               // exact
    sum  = eff_sub ? ({1'b0, xa} - {1'b0, ya}) : ({1'b0, xa} + {1'b0, ya});
  end

  // ------------------------------------------------- register A -> B
  localparam int WA = IDW + 1 + 1 + 32 + 51 + 8 + 1 + 1 + 3;
  logic          v_b;
  logic [WA-1:0] d_b;
  hpc_pipe #(.W(WA), .N(1)) u_pa (
    .clk_i, .rst_ni, .valid_i(valid_i),
    .data_i({id_i, spec, spec_nv, spec_res, sum, ex, sx, eff_sub, rm_i}),
    .valid_o(v_b), .data_o(d_b));

  logic [IDW-1:0] id_b;
  logic           spec_b, spec_nv_b, sx_b, eff_sub_b;
  logic [31:0]    spec_res_b;
  logic [50:0]    sum_b;
  logic [7:0]     ex_b;
  logic [2:0]     rm_b;
  assign {id_b, spec_b, spec_nv_b, spec_res_b, sum_b, ex_b, sx_b, eff_sub_b, rm_b} = d_b;

  // ===================================================== segment B1: normalize
  logic [5:0] lz;
  hpc_lzc #(.W(51)) u_lzc (.x_i(sum_b), .cnt_o(lz));
  wire logic [50:0] norm = sum_b << lz;
  wire logic [11:0] e_n  = {4'd0, ex_b} + 12'd1 - {6'd0, lz};  // lead one at 50 <=> ex+1

  // results that bypass the rounder: specials and exact zero
  //   x + (-x) is +0 except in RDN; zero + same-signed zero keeps the sign
  wire logic        byp     = spec_b | (sum_b == 51'd0);
  wire logic [31:0] byp_res = spec_b ? spec_res_b
                                     : {eff_sub_b ? (rm_b == hpc_vector_pkg::RM_RDN) : sx_b, 31'd0};
  wire logic        byp_nv  = spec_b & spec_nv_b;

  // ------------------------------------------------- optional split register
  // The first latency stage beyond the minimum cuts normalize | round.
  localparam int SPLIT = (LAT > hpc_vector_pkg::MIN_LAT_FADD) ? 1 : 0;
  localparam int WN = IDW + 1 + 32 + 1 + 1 + 12 + 24 + 1 + 1 + 3;
  logic          v_r;
  logic [WN-1:0] d_r;
  hpc_pipe #(.W(WN), .N(SPLIT)) u_pn (
    .clk_i, .rst_ni, .valid_i(v_b),
    .data_i({id_b, byp, byp_res, byp_nv, sx_b, e_n, norm[50:27], norm[26], |norm[25:0], rm_b}),
    .valid_o(v_r), .data_o(d_r));

  logic [IDW-1:0] id_r;
  logic           byp_r, byp_nv_r, sign_r, g_r, st_r;
  logic [31:0]    byp_res_r;
  logic [11:0]    e_r;
  logic [23:0]    sig_r;
  logic [2:0]     rm_r;
  assign {id_r, byp_r, byp_res_r, byp_nv_r, sign_r, e_r, sig_r, g_r, st_r, rm_r} = d_r;

  // ===================================================== segment B2: round
  logic [31:0] r_res;
  logic        r_of, r_uf, r_nx;
  hpc_fp32_round #(.EW(12)) u_round (
    .sign_i(sign_r), .exp_i(e_r), .sig_i(sig_r), .guard_i(g_r), .sticky_i(st_r),
    .rm_i(rm_r), .res_o(r_res), .of_o(r_of), .uf_o(r_uf), .nx_o(r_nx));

  wire logic [31:0] res_r   = byp_r ? byp_res_r : r_res;
  wire logic [4:0]  flags_r = byp_r ? {byp_nv_r, 4'b0000} : {2'b00, r_of, r_uf, r_nx};

  // ------------------------------------------------- output stages
  hpc_pipe #(.W(IDW + 37), .N(LAT - hpc_vector_pkg::MIN_LAT_FADD - SPLIT)) u_po (
    .clk_i, .rst_ni, .valid_i(v_r), .data_i({id_r, res_r, flags_r}),
    .valid_o(valid_o), .data_o({id_o, res_o, flags_o}));
endmodule
