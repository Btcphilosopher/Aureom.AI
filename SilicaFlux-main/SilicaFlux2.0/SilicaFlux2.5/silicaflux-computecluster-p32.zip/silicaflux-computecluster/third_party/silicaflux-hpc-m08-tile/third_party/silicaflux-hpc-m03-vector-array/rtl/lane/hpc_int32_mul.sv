// =============================================================================
// SilicaFlux-HPC :: hpc_int32_mul -- INT32 multiply, low 32 bits of the product
//
//   res = (a * b) mod 2^32 ; identical for signed and unsigned operands.
//   No exception flags.
//
// The multiplier is inferred ('*').  For a timing-driven build the SilicaFlux
// TimingLab carry-save low-half multiplier (sf_mul_lo_csa + sf_csa_tree) is
// a drop-in replacement for the expression below (docs/AUDIT.md).
// Latency LAT >= 1 (LAT-1 output registers, retimable).
// =============================================================================
`default_nettype none

module hpc_int32_mul #(
  parameter int LAT = 2,
  parameter int IDW = 3
) (
  input  wire logic           clk_i,
  input  wire logic           rst_ni,
  input  wire logic           valid_i,
  input  wire logic [IDW-1:0] id_i,
  input  wire logic [31:0]    a_i,
  input  wire logic [31:0]    b_i,
  output logic                valid_o,
  output logic [IDW-1:0]      id_o,
  output logic [31:0]         res_o,
  output logic [4:0]          flags_o
);
  if (LAT < hpc_vector_pkg::MIN_LAT_IMUL) begin : g_bad_lat
    hpc_param_error_LAT_IMUL_below_minimum u_err ();
  end

  wire logic [31:0] prod = a_i * b_i;      // low half only

  hpc_pipe #(.W(IDW + 37), .N(LAT - 1)) u_po (
    .clk_i, .rst_ni, .valid_i(valid_i), .data_i({id_i, prod, 5'b00000}),
    .valid_o(valid_o), .data_o({id_o, res_o, flags_o}));
endmodule
