// =============================================================================
// SilicaFlux-HPC :: hpc_varray_reduce -- ordered FP32 sum-reduction unit and
//                                       in-order completion-token stage
//
// Every item from the collector passes through this block in order:
//   TOKEN  (elementwise command finished)  -> forwarded as a completion token
//   GROUP  (one beat of a sum-reduction)   -> reduced; the last GROUP of the
//                                             command produces its token
//
// Reduction definition (docs/REDUCTION.md; RED_EN = 1)
//   x_e    = element result of the command's element operation (e.g. FMV for
//            a vector sum, FMUL for an unfused dot product), FP32, rounded
//            with the command's rm by the lane.
//   S_g    = pairwise tree over LANE INDEX of the active elements of beat g:
//            level 0 nodes are (x_{gN+2j}, x_{gN+2j+1}); every node adds its two
//            children if both are present, forwards the single present child
//            UNCHANGED if only one is, and is absent if neither is.  No
//            identity element is ever added, so signed zeros, NaN payloads of
//            single elements and flags are exactly those of the adds that
//            happen.
//   acc_0  = init (cmd_scalar_i)
//   acc    = acc + S_g, strictly in beat order, only for beats with >= 1
//            active element (FP32 accumulator, one rounding per add, cmd rm)
//   result = final acc;  flags = OR of element-op flags, tree-add flags and
//            accumulator-add flags.
//   NUM_LANES = 1 degenerates to strict left-to-right accumulation
//   ((init + x_0) + x_1) + ..., identical to sequential FP32 software.
//
// Timing
//   * every add is an hpc_fp32_add (Module 02, verified) with LAT = RLAT; each
//     tree level is RLAT cycles (RLAT-1 adder stages + 1 node register); an
//     input register in front of the tree decouples the collector (lane
//     result multiplexers) from the first adder, so the array adds no logic
//     depth to the lane's own pipeline segments;
//   * the accumulator has one add in flight: after admitting a GROUP with an
//     active element the input is closed for RLAT cycles (one beat per RLAT
//     cycles of reduction throughput); TOKEN items flow at one per cycle;
//   * tokens are emitted in item order (the spacing guarantees no overtaking);
//   * token bypass: a TOKEN item admitted while NO item is in flight in the
//     tree or the accumulator cannot overtake anything, so it skips the tree
//     pipeline and is emitted in the next cycle (elementwise completion
//     latency and credit turnaround independent of NUM_LANES);
//   * credits: an item that will produce a token is admitted only if a slot
//     of the completion queue (CPL_DEPTH) is reserved for it, so this block
//     never needs to stall internally.
//
// RED_EN = 0: no adders; GROUP items (always from illegal reductions) produce
// an illegal token at the command's last item.
// =============================================================================
`default_nettype none

module hpc_varray_reduce #(
  parameter int N         = 2,
  parameter int VL_W      = 16,
  parameter int TID_W     = 8,
  parameter int LBS_W     = 3,
  parameter bit RED_EN    = 1'b1,
  parameter int RLAT      = 3,    // reduction adder latency (hpc_fp32_add LAT >= 2)
  parameter int CPL_DEPTH = 4
) (
  input  wire logic                   clk_i,
  input  wire logic                   rst_ni,
  // ---------------------------------------------------------------- items in
  input  wire logic                   it_valid_i,
  output logic                        it_ready_o,
  input  wire logic                   it_grp_i,
  input  wire logic [N*32-1:0]        it_vals_i,
  input  wire logic [N-1:0]           it_act_i,
  input  wire logic [4:0]             it_flags_i,
  input  wire logic [VL_W-1:0]        it_count_i,
  input  wire logic                   it_first_i,
  input  wire logic                   it_last_i,
  input  wire logic [2:0]             it_rm_i,
  input  wire logic [31:0]            it_init_i,
  input  wire logic [TID_W-1:0]       it_tid_i,
  input  wire logic                   it_ill_i,
  input  wire logic                   it_wait_i,
  input  wire logic [LBS_W-1:0]       it_lbseq_i,
  // ---------------------------------------------------------------- tokens out
  output logic                        tk_valid_o,
  output logic [TID_W-1:0]            tk_tid_o,
  output logic [4:0]                  tk_flags_o,
  output logic [VL_W-1:0]             tk_count_o,
  output logic                        tk_ill_o,
  output logic                        tk_red_o,
  output logic [31:0]                 tk_result_o,
  output logic                        tk_wait_o,
  output logic [LBS_W-1:0]            tk_lbseq_o,
  // ---------------------------------------------------------------- credit return
  input  wire logic                   cpl_pop_i,
  output logic                        busy_o
);
  localparam int CRW = $clog2(CPL_DEPTH + 1);

  if (RLAT < hpc_vector_pkg::MIN_LAT_FADD) begin : g_bad_rlat
    hpc_param_error_RLAT_below_minimum u_err ();
  end

  // ===================================================================
  // Admission: credits and accumulator spacing
  // ===================================================================
  logic [CRW-1:0] cred_q;
  logic [7:0]     sp_q;                 // cycles until the next admission

  assign it_ready_o = (cred_q != '0) & (sp_q == '0);
  wire logic it_fire  = it_valid_i & it_ready_o;
  wire logic tok_item = ~it_grp_i | it_last_i;            // will produce a token
  wire logic need_add = RED_EN & it_grp_i & (|it_act_i);  // accumulator add
  wire logic cred_take = it_fire & tok_item;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cred_q <= CRW'(CPL_DEPTH);
      sp_q   <= '0;
    end else begin
      cred_q <= cred_q - CRW'(cred_take) + CRW'(cpl_pop_i);
      if (it_fire && need_add) sp_q <= 8'(RLAT - 1);
      else if (sp_q != '0)     sp_q <= sp_q - 8'd1;
    end
  end

  // token output register
  logic             tk_v_q;
  logic [TID_W-1:0] tk_tid_q;
  logic [4:0]       tk_flags_q;
  logic [VL_W-1:0]  tk_count_q;
  logic             tk_ill_q, tk_red_q, tk_wait_q;
  logic [31:0]      tk_result_q;
  logic [LBS_W-1:0] tk_lbseq_q;

  assign tk_valid_o  = tk_v_q;
  assign tk_tid_o    = tk_tid_q;
  assign tk_flags_o  = tk_flags_q;
  assign tk_count_o  = tk_count_q;
  assign tk_ill_o    = tk_ill_q;
  assign tk_red_o    = tk_red_q;
  assign tk_result_o = tk_result_q;
  assign tk_wait_o   = tk_wait_q;
  assign tk_lbseq_o  = tk_lbseq_q;

  if (!RED_EN) begin : g_pass
    // ---------------------------------------------------------- pass-through
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_ok = ^{it_vals_i, it_act_i, it_first_i, it_rm_i, it_init_i, need_add};
    /* verilator lint_on UNUSEDSIGNAL */
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) tk_v_q <= 1'b0;
      else         tk_v_q <= it_fire & tok_item;
    end
    always_ff @(posedge clk_i) begin
      if (it_fire && tok_item) begin
        tk_tid_q    <= it_tid_i;
        tk_flags_q  <= it_grp_i ? 5'd0 : it_flags_i;
        tk_count_q  <= it_grp_i ? '0 : it_count_i;
        tk_ill_q    <= it_ill_i;
        tk_red_q    <= it_grp_i;
        tk_result_q <= 32'd0;
        tk_wait_q   <= it_wait_i;
        tk_lbseq_q  <= it_lbseq_i;
      end
    end
    assign busy_o = tk_v_q;

  end else begin : g_red
    // ===================================================================
    // Pairwise tree over lane index
    // ===================================================================
    localparam int LV = $clog2(N);         // tree levels (0 for N = 1)
    localparam int TL = LV * RLAT;         // tree latency

    // items admitted and not yet finished at the accumulator; TOKEN bypass
    logic [7:0] infl_q;
    wire  logic byp     = it_fire & ~it_grp_i & (infl_q == '0);
    wire  logic item_in = it_fire & ~byp;     // item enters the pipeline

    // input register (stage 0 of the tree)
    logic            in_v_q;
    logic [N*32-1:0] in_x_q;
    logic [N-1:0]    in_xv_q;
    logic [2:0]      in_rm_q;
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) in_v_q <= 1'b0;
      else         in_v_q <= item_in;
    end
    always_ff @(posedge clk_i) begin
      if (item_in) begin
        in_x_q  <= it_vals_i;
        in_xv_q <= it_act_i;
        in_rm_q <= it_rm_i;
      end
    end

    /* verilator lint_off UNUSEDSIGNAL */  // upper node positions of deep levels
    logic [(LV+1)*N*32-1:0] lx;            // level k node values at k*N*32
    logic [(LV+1)*N-1:0]    lxv;           // node present
    logic [LV:0]            lv;            // item valid entering level k
    logic [(LV+1)*3-1:0]    lrm;
    logic [(LV+1)*5-1:0]    lfl;           // tree-add flags so far
    /* verilator lint_on UNUSEDSIGNAL */

    assign lx [0 +: N*32] = in_x_q;
    assign lxv[0 +: N]    = in_xv_q;
    assign lv [0]         = in_v_q;
    assign lrm[0 +: 3]    = in_rm_q;
    assign lfl[0 +: 5]    = 5'd0;

    for (genvar k = 0; k < LV; k++) begin : g_lvl
      localparam int M = N >> (k + 1);     // nodes at this level
      /* verilator lint_off UNUSEDSIGNAL */      // upper positions unused for k > 0
      wire logic [N*32-1:0] xin  = lx [k*N*32 +: N*32];
      wire logic [N-1:0]    xvin = lxv[k*N +: N];
      /* verilator lint_on UNUSEDSIGNAL */
      wire logic            vin  = lv [k];
      wire logic [2:0]      rmin = lrm[k*3 +: 3];

      // level sideband: rm and flags so far (RLAT-1 stages)
      logic       sv;
      logic [7:0] sd;
      hpc_pipe #(.W(8), .N(RLAT - 1)) u_sb (
        .clk_i, .rst_ni, .valid_i(vin), .data_i({rmin, lfl[k*5 +: 5]}),
        .valid_o(sv), .data_o(sd));

      logic [M*32-1:0] nres;               // node result at stage RLAT-1
      logic [M-1:0]    npres;              // node present
      logic [M*5-1:0]  nflg;               // node add flags (0 if no add)

      for (genvar j = 0; j < M; j++) begin : g_node
        wire logic [31:0] xa = xin[(2*j)*32   +: 32];
        wire logic [31:0] xb = xin[(2*j+1)*32 +: 32];
        wire logic        va = xvin[2*j];
        wire logic        vb = xvin[2*j+1];

        logic        av;
        logic [31:0] ar;
        logic [4:0]  af;
        /* verilator lint_off PINCONNECTEMPTY */
        hpc_fp32_add #(.LAT(RLAT), .IDW(1)) u_add (
          .clk_i, .rst_ni,
          .valid_i(vin & va & vb), .id_i(1'b0),
          .a_i(xa), .b_i(xb), .sub_i(1'b0), .rm_i(rmin),
          .valid_o(av), .id_o(), .res_o(ar), .flags_o(af));
        /* verilator lint_on PINCONNECTEMPTY */

        logic        bv;
        logic [33:0] bd;                   // {va, vb, single present child}
        hpc_pipe #(.W(34), .N(RLAT - 1)) u_byp (
          .clk_i, .rst_ni, .valid_i(vin), .data_i({va, vb, va ? xa : xb}),
          .valid_o(bv), .data_o(bd));

        wire logic both = bd[33] & bd[32];
        assign nres [j*32 +: 32] = both ? ar : bd[31:0];
        assign npres[j]          = bd[33] | bd[32];
        assign nflg [j*5 +: 5]   = both ? af : 5'd0;

`ifndef SYNTHESIS
        always @(posedge clk_i or negedge rst_ni) begin
          if (!rst_ni) begin
          end else if (av != (bv & both))
            $fatal(1, "hpc_varray_reduce: tree node %0d.%0d adder/bypass misaligned", k, j);
        end
`endif
      end

      wire  logic [4:0] sd_fl = sd[4:0];
      wire  logic [2:0] sd_rm = sd[7:5];
      logic [4:0] nflg_or;
      always_comb begin
        nflg_or = sd_fl;
        for (int j = 0; j < M; j++) nflg_or = nflg_or | nflg[j*5 +: 5];
      end

      // node registers (stage RLAT of this level)
      logic            v_q;
      logic [M*32-1:0] x_q;
      logic [M-1:0]    xv_q;
      logic [2:0]      rm_q;
      logic [4:0]      fl_q;
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) v_q <= 1'b0;
        else         v_q <= sv;
      end
      always_ff @(posedge clk_i) begin
        if (sv) begin
          x_q  <= nres;
          xv_q <= npres;
          rm_q <= sd_rm;
          fl_q <= nflg_or;
        end
      end
      assign lv [k+1]               = v_q;
      assign lx [(k+1)*N*32 +: N*32] = {{(N-M)*32{1'b0}}, x_q};
      assign lxv[(k+1)*N +: N]      = {{(N-M){1'b0}}, xv_q};
      assign lrm[(k+1)*3 +: 3]      = rm_q;
      assign lfl[(k+1)*5 +: 5]      = fl_q;
    end

    wire logic [31:0] root    = lx [LV*N*32 +: 32];
    wire logic        root_p  = lxv[LV*N];
    wire logic [4:0]  tree_fl = lfl[LV*5 +: 5];

    // item sideband through the input register and the whole tree (TL + 1 stages)
    localparam int SBW = 1 + 5 + VL_W + 1 + 1 + 3 + 32 + TID_W + 1 + 1 + LBS_W;
    logic           sb_v;
    logic [SBW-1:0] sb_d;
    hpc_pipe #(.W(SBW), .N(TL + 1)) u_side (
      .clk_i, .rst_ni, .valid_i(item_in),
      .data_i({it_grp_i, it_flags_i, it_count_i, it_first_i, it_last_i, it_rm_i,
               it_init_i, it_tid_i, it_ill_i, it_wait_i, it_lbseq_i}),
      .valid_o(sb_v), .data_o(sb_d));

    wire logic [LBS_W-1:0] s_lbseq = sb_d[0 +: LBS_W];
    wire logic             s_wait  = sb_d[LBS_W];
    wire logic             s_ill   = sb_d[LBS_W+1];
    wire logic [TID_W-1:0] s_tid   = sb_d[LBS_W+2 +: TID_W];
    wire logic [31:0]      s_init  = sb_d[LBS_W+2+TID_W +: 32];
    wire logic [2:0]       s_rm    = sb_d[LBS_W+34+TID_W +: 3];
    wire logic             s_last  = sb_d[LBS_W+37+TID_W];
    wire logic             s_first = sb_d[LBS_W+38+TID_W];
    wire logic [VL_W-1:0]  s_count = sb_d[LBS_W+39+TID_W +: VL_W];
    wire logic [4:0]       s_flags = sb_d[LBS_W+39+TID_W+VL_W +: 5];
    wire logic             s_grp   = sb_d[LBS_W+44+TID_W+VL_W];

`ifndef SYNTHESIS
    always @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
      end else if (sb_v != lv[LV])
        $fatal(1, "hpc_varray_reduce: sideband and tree out of step");
    end
`endif

    // ===================================================================
    // Accumulator (one add in flight)
    // ===================================================================
    logic [31:0]     acc_q;
    logic [4:0]      afl_q;
    logic [VL_W-1:0] acnt_q;

    wire logic [31:0]     acc_in = s_first ? s_init : acc_q;
    wire logic [4:0]      fl_new = (s_first ? 5'd0 : afl_q) | s_flags | tree_fl;
    wire logic [VL_W-1:0] cn_new = (s_first ? '0 : acnt_q) + s_count;

    wire logic add_go  = sb_v & s_grp & root_p;      // start accumulator add
    wire logic grp_nop = sb_v & s_grp & ~root_p;     // empty beat: no add
    wire logic tok_now = sb_v & ~s_grp;              // TOKEN item

    logic        aav;
    logic [31:0] aar;
    logic [4:0]  aaf;
    /* verilator lint_off PINCONNECTEMPTY */
    hpc_fp32_add #(.LAT(RLAT), .IDW(1)) u_acc (
      .clk_i, .rst_ni,
      .valid_i(add_go), .id_i(1'b0),
      .a_i(acc_in), .b_i(root), .sub_i(1'b0), .rm_i(s_rm),
      .valid_o(aav), .id_o(), .res_o(aar), .flags_o(aaf));
    /* verilator lint_on PINCONNECTEMPTY */

    // token info of the add in flight
    logic                 pv;
    logic [TID_W+1:0]     pd;            // {last, ill, tid}
    hpc_pipe #(.W(TID_W + 2), .N(RLAT - 1)) u_pend (
      .clk_i, .rst_ni, .valid_i(add_go), .data_i({s_last, s_ill, s_tid}),
      .valid_o(pv), .data_o(pd));
    wire logic             p_last = pd[TID_W+1];
    wire logic             p_ill  = pd[TID_W];
    wire logic [TID_W-1:0] p_tid  = pd[TID_W-1:0];

    wire logic emit_tok  = tok_now;
    wire logic emit_nop  = grp_nop & s_last;
    wire logic emit_add  = pv & p_last;
    wire logic emit      = byp | emit_tok | emit_nop | emit_add;

    always_ff @(posedge clk_i) begin           // accumulator state (datapath)
      if (add_go || grp_nop) begin
        afl_q  <= fl_new;
        acnt_q <= cn_new;
      end
      if (grp_nop) acc_q <= acc_in;
      if (pv) begin
        acc_q <= aar;
        afl_q <= afl_q | aaf;
      end
    end

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) tk_v_q <= 1'b0;
      else         tk_v_q <= emit;
    end

    always_ff @(posedge clk_i) begin
      if (byp) begin
        tk_tid_q    <= it_tid_i;
        tk_flags_q  <= it_flags_i;
        tk_count_q  <= it_count_i;
        tk_ill_q    <= it_ill_i;
        tk_red_q    <= 1'b0;
        tk_result_q <= 32'd0;
        tk_wait_q   <= it_wait_i;
        tk_lbseq_q  <= it_lbseq_i;
      end else if (emit_tok) begin
        tk_tid_q    <= s_tid;
        tk_flags_q  <= s_flags;
        tk_count_q  <= s_count;
        tk_ill_q    <= s_ill;
        tk_red_q    <= 1'b0;
        tk_result_q <= 32'd0;
        tk_wait_q   <= s_wait;
        tk_lbseq_q  <= s_lbseq;
      end else if (emit_nop) begin
        tk_tid_q    <= s_tid;
        tk_flags_q  <= s_ill ? 5'd0 : fl_new;
        tk_count_q  <= s_ill ? '0 : cn_new;
        tk_ill_q    <= s_ill;
        tk_red_q    <= 1'b1;
        tk_result_q <= s_ill ? 32'd0 : acc_in;
        tk_wait_q   <= 1'b0;
        tk_lbseq_q  <= s_lbseq;
      end else if (emit_add) begin
        tk_tid_q    <= p_tid;
        tk_flags_q  <= afl_q | aaf;
        tk_count_q  <= acnt_q;
        tk_ill_q    <= p_ill;
        tk_red_q    <= 1'b1;
        tk_result_q <= aar;
        tk_wait_q   <= 1'b0;
        tk_lbseq_q  <= '0;
      end
    end

    wire  logic item_done = tok_now | grp_nop | pv;
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) infl_q <= '0;
      else         infl_q <= infl_q + 8'(item_in) - 8'(item_done);
    end
    assign busy_o = (infl_q != '0) | tk_v_q;

`ifndef SYNTHESIS
    always @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
      end else begin
        if (sb_v && pv)
          $fatal(1, "hpc_varray_reduce: item reached the accumulator while an add is in flight");
        if (aav != pv)
          $fatal(1, "hpc_varray_reduce: accumulator adder/pending pipe misaligned");
        if (add_go && s_ill)
          $fatal(1, "hpc_varray_reduce: active element in an illegal reduction");
        if (byp && (sb_v || pv))
          $fatal(1, "hpc_varray_reduce: bypass token collides with a pipeline emission");
      end
    end
`endif
  end
endmodule
