// =============================================================================
// SilicaFlux-HPC Module 05 :: hpc_dma_adapter
// HPC DMA adapter: connects the SilicaFlux-HPC compute tile (Module 04
// scratchpad, Module 03 vector array) to the EXISTING DataFabric DMA engine and
// the DataFabric SFB2 interconnect.  Aureom.AI | SilicaFlux-HPC.  Primary
// source of the module.
//
//   tile / host control                                   (this module)
//   cmd: valid/ready src dst len tag -->[descriptor queue CMD_DEPTH]--+
//   cmd_abort --------------------------------------------------+    |
//                                                               v    v
//            dma_validate (reused) + window REGION check --> control FSM
//                                                               | start / cfg
//                                                               v
//      ENGINE = 0: dma_transfer_engine  (DataFabric, UNMODIFIED; 1 transaction in flight)
//      ENGINE = 1: dma_burst_engine     (DataFabric, UNMODIFIED; FIFO_DEPTH, BURST,
//                                        MAX_OUT, DUAL_PORT)
//                                                               | SFB2, NP ports
//                       +---------------------------------------+
//                       v (one per engine port)
//               hpc_dma_route: SPM window -> target 0, else -> target 1
//                  |                                   |
//          hpc_dma_spm_port                    [sfb_reg_slice if FAB_SLICE]
//          SFB2 -> scratchpad port              SFB2 master -> DataFabric
//          (tag ownership check)                 sfb_crossbar master port
//                  v                                   v
//      hpc_scratchpad port (Module 04)        external / host-visible memory
//
//   cpl: valid/ready tag err code err_addr bytes <--[completion queue CPL_DEPTH]
//   status, events, performance counters (hpc_dma_perf)
//
// ---------------------------------------------------------------- address spaces
//   SPM window   [SPM_BASE, SPM_BASE + SPM_BYTES): the tile scratchpad, reached
//                ONLY through the adapter's scratchpad port(s) (never through the
//                fabric).  Default SPM_BASE = 0x2000_0000 = the DataFabric memory
//                map's TSPM window.
//   external     every other 32-bit byte address: forwarded to the DataFabric;
//                legality is decided by the fabric (unmapped / denied addresses
//                come back as decode errors, SFB2 R8).
//   A transfer's source range and destination range must each lie entirely in
//   one space (else REGION, no bus access).  Directions: external->SPM,
//   SPM->external, SPM->SPM (and external->external, the DataFabric DMA's case).
//
// ---------------------------------------------------------------- transfer semantics
//   * descriptors are executed one at a time, in acceptance order; exactly one
//     completion record per accepted descriptor, in the same order, carrying
//     its tag.  A transfer is started only when a completion slot is free, so
//     the engine never waits for the completion consumer (no deadlock; a
//     stalled consumer back-pressures cmd_ready instead).
//   * lengths are byte-accurate (1 .. 2^MAX_LEN_LOG2); src/dst DW-aligned; the
//     final partial word is written with a strobe covering only bytes < len.
//   * COMPLETION = every write of the transfer has been ACKNOWLEDGED OK by its
//     target.  Both targets acknowledge a write only after it was performed
//     (SFB2 R7; scratchpad commit at issue edge, WRITE_ACK = 1), so a consumer
//     that sees cpl_valid observes the data in memory.  The reused engines
//     signal done only after the LAST write response (DataFabric DMA.md sec 4).
//   * errors: bus errors stop the transfer (cpl_code READ_BUS/WRITE_BUS,
//     cpl_err_addr); cpl_bytes = contiguous prefix of acknowledged bytes.
//   * cmd_abort: stops the ACTIVE transfer at the next beat boundary (engine rule);
//     queued descriptors are not affected; ignored when no transfer is active.
//   * reset (async assert, shared with fabric and scratchpad, SFB2 R11):
//     queued and active descriptors are discarded, no completion is produced
//     for them, no request is presented in reset or afterwards until the next
//     descriptor; writes of the interrupted transfer may or may not have been
//     performed (each beat entirely or not at all).
// Timing: docs/05_timing.md.  State diagrams: docs/04_state_diagrams.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_dma_defs.svh"
`default_nettype none

module hpc_dma_adapter #(
  parameter int          DW           = 32,              // data width of both targets (32/64/128)
  parameter int          ENGINE       = 0,               // 0 simple (baseline), 1 buffered
  parameter int          FIFO_DEPTH   = 8,               // buffered: data FIFO beats (power of two >= 2)
  parameter int          BURST        = 8,               // buffered, single port: beats per phase (1..FIFO_DEPTH)
  parameter int          DUAL_PORT    = 0,               // buffered: 1 = separate read and write ports
  parameter int          MAX_OUT      = 2,               // buffered: requests outstanding per port
  parameter int          MAX_LEN_LOG2 = 24,              // maximum length 2^MAX_LEN_LOG2 bytes
  parameter logic [31:0] SPM_BASE     = 32'h2000_0000,   // scratchpad window (DataFabric TSPM)
  parameter int          SPM_BYTES    = 65536,           // power of two, = hpc_scratchpad CAPACITY_BYTES
  parameter int          SPM_TAG_W    = 8,               // = hpc_scratchpad TAG_W
  parameter int          CMD_DEPTH    = 2,               // descriptor queue: 0 (none), 2, 4, 8, 16
  parameter int          CPL_DEPTH    = 2,               // completion queue: 2, 4, 8, 16
  parameter int          TAG_W        = 8,               // descriptor tag width
  parameter int          FAB_SLICE    = 0,               // 1: sfb_reg_slice on the fabric port(s)
  parameter int          PERF_EN      = 1,
  parameter int          CNT_W        = 32,
  // ------------------------------------------------------------ derived (never set)
  localparam int SB   = DW / 8,
  localparam int NP   = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1,
  localparam int RMO  = (ENGINE != 0) ? MAX_OUT : 1,     // outstanding limit seen by the routers
  localparam int CW   = $clog2(((RMO > 0) ? RMO : 1) + 1),
  localparam int BCW  = $clog2(SB + 1),
  localparam int CPLW = TAG_W + 1 + 4 + 32 + 32,
  localparam int CMDW = 32 + 32 + 32 + TAG_W,
  localparam int CQW  = (CMD_DEPTH > 1) ? $clog2(CMD_DEPTH) : 1,
  localparam int PQW  = (CPL_DEPTH > 1) ? $clog2(CPL_DEPTH) : 1,
  localparam int CB   = $clog2(SPM_BYTES)
) (
  input  wire logic                     clk,
  input  wire logic                     rst_n,
  // ---------------------------------------------------------- descriptor (command) channel
  input  wire logic                     cmd_valid,
  output logic                          cmd_ready,
  input  wire logic [31:0]              cmd_src,
  input  wire logic [31:0]              cmd_dst,
  input  wire logic [31:0]              cmd_len,         // bytes
  input  wire logic [TAG_W-1:0]         cmd_tag,
  input  wire logic                     cmd_abort,       // stop the active transfer at the next beat boundary
  // ---------------------------------------------------------- completion channel
  output logic                          cpl_valid,
  input  wire logic                     cpl_ready,
  output logic [TAG_W-1:0]              cpl_tag,
  output logic                          cpl_err,         // cpl_code != NONE
  output logic [3:0]                    cpl_code,        // hpc_dma_defs.svh
  output logic [31:0]                   cpl_err_addr,
  output logic [31:0]                   cpl_bytes,       // bytes written and acknowledged (contiguous prefix)
  // ---------------------------------------------------------- status
  output logic                          busy,            // a descriptor is queued or in progress
  output logic                          active,          // the engine is executing a transfer
  output logic [TAG_W-1:0]              cur_tag,         // tag of the descriptor in progress
  output logic [1:0]                    ctl_state,       // HPC_DMA_AST_*
  output logic [2:0]                    eng_state,       // DMA_ST_* (DataFabric encoding)
  output logic [31:0]                   eng_bytes_done,  // live: bytes acknowledged so far
  output logic [7:0]                    fifo_level,      // buffered engine data-FIFO occupancy
  // ---------------------------------------------------------- scratchpad port(s) (hpc_scratchpad requester ports)
  output logic [NP-1:0]                 spm_req_valid,
  input  wire logic [NP-1:0]            spm_req_ready,
  output logic [NP-1:0]                 spm_req_we,
  output logic [NP*32-1:0]              spm_req_addr,
  output logic [NP*DW-1:0]              spm_req_wdata,
  output logic [NP*SB-1:0]              spm_req_wstrb,
  output logic [NP*SPM_TAG_W-1:0]       spm_req_tag,
  input  wire logic [NP-1:0]            spm_rsp_valid,
  output logic [NP-1:0]                 spm_rsp_ready,
  input  wire logic [NP*DW-1:0]         spm_rsp_rdata,
  input  wire logic [NP-1:0]            spm_rsp_err,
  input  wire logic [NP*3-1:0]          spm_rsp_err_code,
  input  wire logic [NP-1:0]            spm_rsp_we,
  input  wire logic [NP*SPM_TAG_W-1:0]  spm_rsp_tag,
  // ---------------------------------------------------------- DataFabric SFB2 master port(s)
  output logic [NP-1:0]                 fab_req_valid,
  input  wire logic [NP-1:0]            fab_req_ready,
  output logic [NP-1:0]                 fab_req_write,
  output logic [NP*32-1:0]              fab_req_addr,
  output logic [NP*DW-1:0]              fab_req_wdata,
  output logic [NP*SB-1:0]              fab_req_wstrb,
  input  wire logic [NP-1:0]            fab_rsp_valid,
  output logic [NP-1:0]                 fab_rsp_ready,
  input  wire logic [NP*DW-1:0]         fab_rsp_rdata,
  input  wire logic [NP-1:0]            fab_rsp_error,
  // ---------------------------------------------------------- events (this cycle)
  output logic                          ev_cmd_accept,   // descriptor accepted
  output logic                          ev_start,        // descriptor started (validation)
  output logic                          ev_cpl,          // completion record produced
  output logic                          ev_cpl_err,      // ... with an error code
  output logic [7:0]                    ev_bytes_rd,     // bytes read by error-free responses
  output logic [7:0]                    ev_bytes_wr,     // bytes committed by error-free write responses
  output logic                          ev_req_stall,    // a request presented by the engine was not accepted
  output logic [7:0]                    ev_outstanding,  // requests outstanding (all ports)
  output logic                          ev_bus_err,      // an error response was received
  output logic                          ev_tag_err,      // response-ownership violation: scratchpad tag/type mismatch or unsolicited response
  // ---------------------------------------------------------- performance counters
  input  wire logic                     perf_clear,
  output logic [`HPC_DMA_NUM_PC*CNT_W-1:0] perf_cnt
);
  // ============================================================ configuration checks
  if (DW != 32 && DW != 64 && DW != 128) begin : g_err_dw_must_be_32_64_128
    `SRAM_CFG_FATAL("hpc_dma_adapter: DW must be 32, 64 or 128 (SFB2 widths)")
  end
  if (ENGINE != 0 && ENGINE != 1) begin : g_err_engine_must_be_0_or_1
    `SRAM_CFG_FATAL("hpc_dma_adapter: ENGINE must be 0 (simple) or 1 (buffered)")
  end
  if (ENGINE == 1 && (FIFO_DEPTH < 2 || FIFO_DEPTH > 256 || (FIFO_DEPTH & (FIFO_DEPTH - 1)) != 0)) begin : g_err_fifo_depth_pow2_2_to_256
    `SRAM_CFG_FATAL("hpc_dma_adapter: FIFO_DEPTH must be a power of two 2..256")
  end
  if (ENGINE == 1 && (BURST < 1 || BURST > FIFO_DEPTH)) begin : g_err_burst_1_to_fifo_depth
    `SRAM_CFG_FATAL("hpc_dma_adapter: BURST must be 1..FIFO_DEPTH")
  end
  if (ENGINE == 1 && (MAX_OUT < 1 || MAX_OUT > 16)) begin : g_err_max_out_1_to_16
    `SRAM_CFG_FATAL("hpc_dma_adapter: MAX_OUT must be 1..16")
  end
  if (MAX_LEN_LOG2 < 1 || MAX_LEN_LOG2 > 31) begin : g_err_max_len_log2
    `SRAM_CFG_FATAL("hpc_dma_adapter: MAX_LEN_LOG2 must be 1..31")
  end
  if (SPM_BYTES < 2 * SB || (SPM_BYTES & (SPM_BYTES - 1)) != 0 || (SPM_BASE & 32'(SPM_BYTES - 1)) != 32'd0) begin : g_err_spm_window
    `SRAM_CFG_FATAL("hpc_dma_adapter: SPM_BYTES must be a power of two >= 2 words and SPM_BASE aligned to it")
  end
  if (CMD_DEPTH != 0 && CMD_DEPTH != 2 && CMD_DEPTH != 4 && CMD_DEPTH != 8 && CMD_DEPTH != 16) begin : g_err_cmd_depth
    `SRAM_CFG_FATAL("hpc_dma_adapter: CMD_DEPTH must be 0, 2, 4, 8 or 16")
  end
  if (CPL_DEPTH != 2 && CPL_DEPTH != 4 && CPL_DEPTH != 8 && CPL_DEPTH != 16) begin : g_err_cpl_depth
    `SRAM_CFG_FATAL("hpc_dma_adapter: CPL_DEPTH must be 2, 4, 8 or 16")
  end
  if (TAG_W < 1 || TAG_W > 32) begin : g_err_tag_w
    `SRAM_CFG_FATAL("hpc_dma_adapter: TAG_W must be 1..32")
  end
  if (SPM_TAG_W < 2 || SPM_TAG_W > 32) begin : g_err_spm_tag_w
    `SRAM_CFG_FATAL("hpc_dma_adapter: SPM_TAG_W must be 2..32")
  end
  if (SPM_TAG_W >= 2 && SPM_TAG_W < 32 && (64'd1 << (SPM_TAG_W - 1)) <= 64'(RMO)) begin : g_err_spm_tag_space
    `SRAM_CFG_FATAL("hpc_dma_adapter: 2^(SPM_TAG_W-1) must exceed MAX_OUT (scratchpad tag sequence would alias)")
  end
  if (CNT_W < 8 || CNT_W > 64) begin : g_err_cnt_w
    `SRAM_CFG_FATAL("hpc_dma_adapter: CNT_W must be 8..64")
  end
  // The datapath is elaborated only for a legal configuration, so an illegal one always stops with the
  // message above and never with a derived-width error from a sub-module (same rule as Module 04).
  localparam bit CFG_OK =
    (DW == 32 || DW == 64 || DW == 128) && (ENGINE == 0 || ENGINE == 1) &&
    (ENGINE == 0 || (FIFO_DEPTH >= 2 && FIFO_DEPTH <= 256 && (FIFO_DEPTH & (FIFO_DEPTH - 1)) == 0 &&
                     BURST >= 1 && BURST <= FIFO_DEPTH && MAX_OUT >= 1 && MAX_OUT <= 16)) &&
    MAX_LEN_LOG2 >= 1 && MAX_LEN_LOG2 <= 31 &&
    SPM_BYTES >= 2 * SB && (SPM_BYTES & (SPM_BYTES - 1)) == 0 && (SPM_BASE & 32'(SPM_BYTES - 1)) == 32'd0 &&
    (CMD_DEPTH == 0 || CMD_DEPTH == 2 || CMD_DEPTH == 4 || CMD_DEPTH == 8 || CMD_DEPTH == 16) &&
    (CPL_DEPTH == 2 || CPL_DEPTH == 4 || CPL_DEPTH == 8 || CPL_DEPTH == 16) && TAG_W >= 1 && TAG_W <= 32 &&
    SPM_TAG_W >= 2 && SPM_TAG_W <= 32 && (SPM_TAG_W >= 32 || (64'd1 << (SPM_TAG_W - 1)) > 64'(RMO)) &&
    CNT_W >= 8 && CNT_W <= 64;

  if (!CFG_OK) begin : g_off
    assign cmd_ready = 1'b0; assign cpl_valid = 1'b0; assign cpl_tag = '0; assign cpl_err = 1'b0; assign cpl_code = '0;
    assign cpl_err_addr = '0; assign cpl_bytes = '0; assign busy = 1'b0; assign active = 1'b0; assign cur_tag = '0;
    assign ctl_state = '0; assign eng_state = '0; assign eng_bytes_done = '0; assign fifo_level = '0;
    assign spm_req_valid = '0; assign spm_req_we = '0; assign spm_req_addr = '0; assign spm_req_wdata = '0;
    assign spm_req_wstrb = '0; assign spm_req_tag = '0; assign spm_rsp_ready = '0;
    assign fab_req_valid = '0; assign fab_req_write = '0; assign fab_req_addr = '0; assign fab_req_wdata = '0;
    assign fab_req_wstrb = '0; assign fab_rsp_ready = '0;
    assign ev_cmd_accept = 1'b0; assign ev_start = 1'b0; assign ev_cpl = 1'b0; assign ev_cpl_err = 1'b0;
    assign ev_bytes_rd = '0; assign ev_bytes_wr = '0; assign ev_req_stall = 1'b0; assign ev_outstanding = '0;
    assign ev_bus_err = 1'b0; assign ev_tag_err = 1'b0; assign perf_cnt = '0;
  end else begin : g_core

  // ============================================================ descriptor queue
  logic          desc_avail, desc_take;
  logic [31:0]   q_src, q_dst, q_len;
  logic [TAG_W-1:0] q_tag;
  logic [PQW:0]  cpl_count;
  logic [1:0]    st_q;
  wire           cpl_space = (cpl_count < (PQW+1)'(CPL_DEPTH));

  if (CMD_DEPTH > 0) begin : g_cmdq
    logic [CQW:0]    cmd_count;
    logic [CMDW-1:0] head;
    dma_fifo #(.WIDTH(CMDW), .DEPTH(CMD_DEPTH)) u_cmdq (
      .clk, .rst_n, .clr(1'b0), .push(cmd_valid && cmd_ready), .wdata({cmd_src, cmd_dst, cmd_len, cmd_tag}),
      .pop(desc_take), .rdata(head), .count(cmd_count));
    assign cmd_ready  = (cmd_count < (CQW+1)'(CMD_DEPTH));
    assign desc_avail = (cmd_count != '0);
    assign {q_src, q_dst, q_len, q_tag} = head;
    assign busy = (st_q != `HPC_DMA_AST_IDLE) || (cmd_count != '0);
  end else begin : g_nocmdq
    assign cmd_ready  = (st_q == `HPC_DMA_AST_IDLE) && cpl_space;
    assign desc_avail = cmd_valid;
    assign {q_src, q_dst, q_len, q_tag} = {cmd_src, cmd_dst, cmd_len, cmd_tag};
    assign busy = (st_q != `HPC_DMA_AST_IDLE);
  end
  assign desc_take     = (st_q == `HPC_DMA_AST_IDLE) && desc_avail && cpl_space;
  assign ev_cmd_accept = cmd_valid && cmd_ready;

  // ============================================================ control FSM
  logic [31:0]      d_src, d_dst, d_len;
  logic [TAG_W-1:0] d_tag;
  logic [3:0]       vcode;
  logic             e_busy, e_done, e_fail;
  logic [3:0]       e_code;
  logic [31:0]      e_addr, e_bytes;

  dma_validate #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) u_val (
    .src(d_src), .dst(d_dst), .len(d_len), .code(vcode));

  // region rule (only meaningful once vcode == NONE: len >= 1, no 2^32 wrap)
  localparam logic [32:0] W_LO = {1'b0, SPM_BASE};
  localparam logic [32:0] W_HI = {1'b0, SPM_BASE} + 33'(SPM_BYTES);
  function automatic logic range_ok(input logic [31:0] a, input logic [31:0] n);
    logic [32:0] lo, hi;
    lo = {1'b0, a};
    hi = {1'b0, a} + {1'b0, n};
    range_ok = (lo >= W_LO && hi <= W_HI) ||          // entirely inside the window
               (hi <= W_LO || lo >= W_HI);            // entirely outside it
  endfunction
  function automatic logic [31:0] boundary(input logic [31:CB] a_hi);
    boundary = (a_hi == SPM_BASE[31:CB]) ? W_HI[31:0] : SPM_BASE;       // the edge the range crosses
  endfunction
  wire src_ok   = range_ok(d_src, d_len);
  wire dst_ok   = range_ok(d_dst, d_len);
  wire reg_fail = (st_q == `HPC_DMA_AST_CHECK) && (vcode == `DMA_ERR_NONE) && !(src_ok && dst_ok);
  wire e_start  = (st_q == `HPC_DMA_AST_CHECK) && !reg_fail;
  wire e_abort  = cmd_abort && (st_q == `HPC_DMA_AST_RUN);

  // completion record
  logic            cpl_push;
  logic [CPLW-1:0] cpl_wdata, cpl_head;
  always_comb begin
    cpl_push  = 1'b0;
    cpl_wdata = {d_tag, 1'b0, `DMA_ERR_NONE, 32'd0, 32'd0};
    if (reg_fail) begin
      cpl_push  = 1'b1;
      cpl_wdata = {d_tag, 1'b1, `HPC_DMA_ERR_REGION, src_ok ? boundary(d_dst[31:CB]) : boundary(d_src[31:CB]), 32'd0};
    end else if (st_q == `HPC_DMA_AST_RUN && (e_done || e_fail)) begin
      cpl_push  = 1'b1;
      cpl_wdata = {d_tag, e_fail, e_fail ? e_code : `DMA_ERR_NONE, e_fail ? e_addr : 32'd0, e_bytes};
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q  <= `HPC_DMA_AST_IDLE;
      d_src <= '0; d_dst <= '0; d_len <= '0; d_tag <= '0;
    end else begin
      case (st_q)
        `HPC_DMA_AST_IDLE: if (desc_take) begin
          d_src <= q_src; d_dst <= q_dst; d_len <= q_len; d_tag <= q_tag;
          st_q  <= `HPC_DMA_AST_CHECK;
        end
        `HPC_DMA_AST_CHECK: st_q <= reg_fail ? `HPC_DMA_AST_IDLE : `HPC_DMA_AST_RUN;
        `HPC_DMA_AST_RUN:   if (e_done || e_fail) st_q <= `HPC_DMA_AST_IDLE;
        default:            st_q <= `HPC_DMA_AST_IDLE;
      endcase
    end
  end

  dma_fifo #(.WIDTH(CPLW), .DEPTH(CPL_DEPTH)) u_cplq (
    .clk, .rst_n, .clr(1'b0), .push(cpl_push), .wdata(cpl_wdata),
    .pop(cpl_valid && cpl_ready), .rdata(cpl_head), .count(cpl_count));
  assign cpl_valid = (cpl_count != '0);
  logic cpl_err_unused;
  assign {cpl_tag, cpl_err_unused, cpl_code, cpl_err_addr, cpl_bytes} = cpl_head;
  assign cpl_err   = (cpl_code != `DMA_ERR_NONE);

  assign active    = e_busy;
  assign cur_tag   = d_tag;
  assign ctl_state = st_q;
  assign ev_start  = e_start;
  assign ev_cpl    = cpl_push;
  assign ev_cpl_err = cpl_push && cpl_wdata[CPLW-TAG_W-1];
  assign eng_bytes_done = e_bytes;

  // ============================================================ reused DataFabric engine (UNMODIFIED)
  logic [NP-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NP*32-1:0] m_req_addr;
  logic [NP*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NP*SB-1:0] m_req_wstrb;
  logic             e_stall_unused;

  if (ENGINE == 0) begin : g_simple
    dma_transfer_engine #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) u_eng (
      .clk, .rst_n, .start(e_start), .abort(e_abort), .cfg_src(d_src), .cfg_dst(d_dst), .cfg_len(d_len),
      .busy(e_busy), .done(e_done), .fail(e_fail), .err_code(e_code), .err_addr(e_addr), .bytes_done(e_bytes),
      .state(eng_state), .ev_stall(e_stall_unused),
      .req_valid(m_req_valid[0]), .req_ready(m_req_ready[0]), .req_write(m_req_write[0]),
      .req_addr(m_req_addr[31:0]), .req_wdata(m_req_wdata[DW-1:0]), .req_wstrb(m_req_wstrb[SB-1:0]),
      .rsp_valid(m_rsp_valid[0]), .rsp_ready(m_rsp_ready[0]), .rsp_rdata(m_rsp_rdata[DW-1:0]),
      .rsp_error(m_rsp_error[0]));
    assign fifo_level = 8'd0;
  end else begin : g_buffered
    dma_burst_engine #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2), .FIFO_DEPTH(FIFO_DEPTH), .BURST(BURST),
                       .DUAL_PORT(DUAL_PORT), .MAX_OUT(MAX_OUT)) u_eng (
      .clk, .rst_n, .start(e_start), .abort(e_abort), .cfg_src(d_src), .cfg_dst(d_dst), .cfg_len(d_len),
      .busy(e_busy), .done(e_done), .fail(e_fail), .err_code(e_code), .err_addr(e_addr), .bytes_done(e_bytes),
      .state(eng_state), .ev_stall(e_stall_unused), .fifo_level,
      .req_valid(m_req_valid), .req_ready(m_req_ready), .req_write(m_req_write),
      .req_addr(m_req_addr), .req_wdata(m_req_wdata), .req_wstrb(m_req_wstrb),
      .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready), .rsp_rdata(m_rsp_rdata),
      .rsp_error(m_rsp_error));
  end

  // ============================================================ per engine port: router + protocol adapters
  logic [NP-1:0]     p_rd, p_wr, p_spm, p_fab, p_stall, p_rsp, p_rsp_err, p_rd_ok, p_unsol, p_tag_err;
  logic [NP*BCW-1:0] p_wr_bytes;
  logic [NP*CW-1:0]  p_out;

  for (genvar p = 0; p < NP; p++) begin : g_port
    // router -> scratchpad adapter (SFB2)
    logic          s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
    logic [31:0]   s_req_addr;
    logic [DW-1:0] s_req_wdata, s_rsp_rdata;
    logic [SB-1:0] s_req_wstrb;
    // router -> fabric (SFB2)
    logic          f_req_valid, f_req_ready, f_req_write, f_rsp_valid, f_rsp_ready, f_rsp_error;
    logic [31:0]   f_req_addr;
    logic [DW-1:0] f_req_wdata, f_rsp_rdata;
    logic [SB-1:0] f_req_wstrb;

    hpc_dma_route #(.DW(DW), .SPM_BASE(SPM_BASE), .SPM_BYTES(SPM_BYTES), .MAX_OUT(RMO)) u_route (
      .clk, .rst_n,
      .req_valid(m_req_valid[p]), .req_ready(m_req_ready[p]), .req_write(m_req_write[p]),
      .req_addr(m_req_addr[p*32 +: 32]), .req_wdata(m_req_wdata[p*DW +: DW]), .req_wstrb(m_req_wstrb[p*SB +: SB]),
      .rsp_valid(m_rsp_valid[p]), .rsp_ready(m_rsp_ready[p]), .rsp_rdata(m_rsp_rdata[p*DW +: DW]),
      .rsp_error(m_rsp_error[p]),
      .spm_req_valid(s_req_valid), .spm_req_ready(s_req_ready), .spm_req_write(s_req_write),
      .spm_req_addr(s_req_addr), .spm_req_wdata(s_req_wdata), .spm_req_wstrb(s_req_wstrb),
      .spm_rsp_valid(s_rsp_valid), .spm_rsp_ready(s_rsp_ready), .spm_rsp_rdata(s_rsp_rdata),
      .spm_rsp_error(s_rsp_error),
      .fab_req_valid(f_req_valid), .fab_req_ready(f_req_ready), .fab_req_write(f_req_write),
      .fab_req_addr(f_req_addr), .fab_req_wdata(f_req_wdata), .fab_req_wstrb(f_req_wstrb),
      .fab_rsp_valid(f_rsp_valid), .fab_rsp_ready(f_rsp_ready), .fab_rsp_rdata(f_rsp_rdata),
      .fab_rsp_error(f_rsp_error),
      .ev_req_rd(p_rd[p]), .ev_req_wr(p_wr[p]), .ev_req_spm(p_spm[p]), .ev_req_fab(p_fab[p]),
      .ev_req_stall(p_stall[p]), .ev_rsp(p_rsp[p]), .ev_rsp_err(p_rsp_err[p]), .ev_rd_ok(p_rd_ok[p]),
      .ev_wr_bytes(p_wr_bytes[p*BCW +: BCW]), .ev_unsolicited(p_unsol[p]), .outstanding(p_out[p*CW +: CW]));

    logic       spm_err_ev_unused;
    logic [2:0] spm_err_code_unused;
    hpc_dma_spm_port #(.DW(DW), .AW(32), .SPM_TAG_W(SPM_TAG_W), .MAX_OUT(RMO)) u_spm (
      .clk, .rst_n,
      .req_valid(s_req_valid), .req_ready(s_req_ready), .req_write(s_req_write), .req_addr(s_req_addr),
      .req_wdata(s_req_wdata), .req_wstrb(s_req_wstrb),
      .rsp_valid(s_rsp_valid), .rsp_ready(s_rsp_ready), .rsp_rdata(s_rsp_rdata), .rsp_error(s_rsp_error),
      .spm_req_valid(spm_req_valid[p]), .spm_req_ready(spm_req_ready[p]), .spm_req_we(spm_req_we[p]),
      .spm_req_addr(spm_req_addr[p*32 +: 32]), .spm_req_wdata(spm_req_wdata[p*DW +: DW]),
      .spm_req_wstrb(spm_req_wstrb[p*SB +: SB]), .spm_req_tag(spm_req_tag[p*SPM_TAG_W +: SPM_TAG_W]),
      .spm_rsp_valid(spm_rsp_valid[p]), .spm_rsp_ready(spm_rsp_ready[p]), .spm_rsp_rdata(spm_rsp_rdata[p*DW +: DW]),
      .spm_rsp_err(spm_rsp_err[p]), .spm_rsp_err_code(spm_rsp_err_code[p*3 +: 3]), .spm_rsp_we(spm_rsp_we[p]),
      .spm_rsp_tag(spm_rsp_tag[p*SPM_TAG_W +: SPM_TAG_W]),
      .ev_tag_err(p_tag_err[p]), .ev_spm_err(spm_err_ev_unused), .spm_err_code(spm_err_code_unused));

    if (FAB_SLICE != 0) begin : g_slice
      sfb_reg_slice #(.AW(32), .DW(DW), .REQ_SLICE(1), .RSP_SLICE(1)) u_slice (
        .clk, .rst_n,
        .s_req_valid(f_req_valid), .s_req_ready(f_req_ready), .s_req_write(f_req_write), .s_req_addr(f_req_addr),
        .s_req_wdata(f_req_wdata), .s_req_wstrb(f_req_wstrb),
        .s_rsp_valid(f_rsp_valid), .s_rsp_ready(f_rsp_ready), .s_rsp_rdata(f_rsp_rdata), .s_rsp_error(f_rsp_error),
        .m_req_valid(fab_req_valid[p]), .m_req_ready(fab_req_ready[p]), .m_req_write(fab_req_write[p]),
        .m_req_addr(fab_req_addr[p*32 +: 32]), .m_req_wdata(fab_req_wdata[p*DW +: DW]),
        .m_req_wstrb(fab_req_wstrb[p*SB +: SB]),
        .m_rsp_valid(fab_rsp_valid[p]), .m_rsp_ready(fab_rsp_ready[p]), .m_rsp_rdata(fab_rsp_rdata[p*DW +: DW]),
        .m_rsp_error(fab_rsp_error[p]));
    end else begin : g_wire
      assign fab_req_valid[p]          = f_req_valid;
      assign f_req_ready               = fab_req_ready[p];
      assign fab_req_write[p]          = f_req_write;
      assign fab_req_addr[p*32 +: 32]  = f_req_addr;
      assign fab_req_wdata[p*DW +: DW] = f_req_wdata;
      assign fab_req_wstrb[p*SB +: SB] = f_req_wstrb;
      assign f_rsp_valid               = fab_rsp_valid[p];
      assign fab_rsp_ready[p]          = f_rsp_ready;
      assign f_rsp_rdata               = fab_rsp_rdata[p*DW +: DW];
      assign f_rsp_error               = fab_rsp_error[p];
    end
  end

  // ============================================================ aggregated events + counters
  logic [7:0] n_rd, n_wr, n_spm, n_fab, n_berr, n_terr, n_out, b_rd, b_wr;
  logic       any_stall, any_rsp;
  always_comb begin
    n_rd = '0; n_wr = '0; n_spm = '0; n_fab = '0; n_berr = '0; n_terr = '0; n_out = '0; b_rd = '0; b_wr = '0;
    any_stall = 1'b0; any_rsp = 1'b0;
    for (int p = 0; p < NP; p++) begin
      n_rd   = n_rd   + 8'(p_rd[p]);
      n_wr   = n_wr   + 8'(p_wr[p]);
      n_spm  = n_spm  + 8'(p_spm[p]);
      n_fab  = n_fab  + 8'(p_fab[p]);
      n_berr = n_berr + 8'(p_rsp_err[p]);
      n_terr = n_terr + 8'(p_tag_err[p]) + 8'(p_unsol[p]);
      n_out  = n_out  + 8'(p_out[p*CW +: CW]);
      b_rd   = b_rd   + (p_rd_ok[p] ? 8'(SB) : 8'd0);
      b_wr   = b_wr   + 8'(p_wr_bytes[p*BCW +: BCW]);
      any_stall = any_stall | p_stall[p];
      any_rsp   = any_rsp   | p_rsp[p];
    end
  end
  assign ev_bytes_rd    = b_rd;
  assign ev_bytes_wr    = b_wr;
  assign ev_req_stall   = any_stall;
  assign ev_outstanding = n_out;
  assign ev_bus_err     = (n_berr != '0);
  assign ev_tag_err     = (n_terr != '0);

  hpc_dma_perf #(.PERF_EN(PERF_EN), .CNT_W(CNT_W), .EW(8)) u_perf (
    .clk, .rst_n, .perf_clear,
    .e_active(e_busy), .e_bytes_rd(b_rd), .e_bytes_wr(b_wr), .e_reads(n_rd), .e_writes(n_wr),
    .e_req_stall(any_stall), .e_rsp_wait((n_out != '0) && !any_rsp), .e_outstanding(n_out),
    .e_cpl_ok(cpl_push && !cpl_wdata[CPLW-TAG_W-1]), .e_cpl_err(cpl_push && cpl_wdata[CPLW-TAG_W-1]),
    .e_bus_err(n_berr), .e_tag_err(n_terr), .e_spm_req(n_spm), .e_fab_req(n_fab),
    .perf_cnt);

`ifdef HPC_DMA_ASSERT
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk) if (rst_n) begin
    assert (!(cpl_push && cpl_count == (PQW+1)'(CPL_DEPTH) && !(cpl_valid && cpl_ready)))
      else $error("%m: completion pushed into a full queue (slot was not reserved)");
    assert (!(|m_req_valid && !e_busy)) else $error("%m: engine request while the engine is idle");
    assert (p_unsol == '0) else $error("%m: unsolicited response");
  end
  /* verilator lint_on SYNCASYNCNET */
`endif
  end // g_core
endmodule

`default_nettype wire
