// =============================================================================
// SilicaFlux-HPC :: hpc_varray_pkg -- shared vector-array interface definitions
//
// Module 03 (scalable parallel vector execution array).  Stateless package:
// command-field encodings, the array-level legality rule, completion-record
// encodings and the performance-counter map shared by hpc_vector_array, its
// sub-blocks (issue controller, collector, reduction unit, counters) and the
// testbench.  Port bundles are documented in docs/ARRAY_INTERFACE.md.
//
// Element operations reuse the hpc_vector_pkg (Module 02) opcode, rounding
// mode and flag encodings unchanged; this package only adds what the array
// needs on top of a single lane.
//
// Coding rules: SilicaFlux RTL subset (Verilator 5.020 / Icarus 12 /
// Yosys 0.33): no `import`, no `return`, no `inside`, no structs/unions,
// functions assign to their own name.
// =============================================================================
`default_nettype none

package hpc_varray_pkg;

  // ---------------------------------------------------------------------------
  // Command: cmd_bcast_i bit positions.  A set bit replaces that operand of
  // EVERY element of the command by cmd_scalar_i (vector-scalar forms).
  // ---------------------------------------------------------------------------
  localparam int BC_W = 3;
  localparam int BC_A = 0;
  localparam int BC_B = 1;
  localparam int BC_C = 2;

  // ---------------------------------------------------------------------------
  // Legality of an element operation on one lane (mirrors the decode table of
  // hpc_vector_lane; docs/ARRAY_INTERFACE.md section 4).  The array filters
  // illegal commands itself, so no illegal operation ever reaches a lane
  // (checked by a simulation assertion in the collector).
  // ---------------------------------------------------------------------------
  function automatic logic elem_op_legal(input logic [hpc_vector_pkg::OP_W-1:0] op,
                                         input logic [2:0] rm,
                                         input logic en_fcmp, input logic en_int);
    case (op)
      hpc_vector_pkg::OP_FMV:    elem_op_legal = 1'b1;
      hpc_vector_pkg::OP_FADD,
      hpc_vector_pkg::OP_FSUB,
      hpc_vector_pkg::OP_FMUL,
      hpc_vector_pkg::OP_FMADD,
      hpc_vector_pkg::OP_FMSUB,
      hpc_vector_pkg::OP_FNMSUB,
      hpc_vector_pkg::OP_FNMADD: elem_op_legal = hpc_vector_pkg::rm_legal(rm);
      hpc_vector_pkg::OP_FMIN,
      hpc_vector_pkg::OP_FMAX,
      hpc_vector_pkg::OP_FEQ,
      hpc_vector_pkg::OP_FLT,
      hpc_vector_pkg::OP_FLE:    elem_op_legal = en_fcmp;
      hpc_vector_pkg::OP_IADD,
      hpc_vector_pkg::OP_IMUL:   elem_op_legal = en_int;
      default:                   elem_op_legal = 1'b0;
    endcase
  endfunction

  // ---------------------------------------------------------------------------
  // Legality of a whole command.
  //   elementwise (red = 0): the element operation must be legal.
  //   sum-reduction (red = 1): the reduction unit must be present (RED_EN),
  //     the element operation must be one of the FP arithmetic forms
  //     FMV, FADD, FSUB, FMUL, FMADD, FMSUB, FNMSUB, FNMADD (codes 0..7),
  //     rm must be one of the five architected modes (the reduction adds
  //     always round, even for FMV), and no operand may be broadcast
  //     (cmd_scalar_i is the accumulator's initial value instead).
  // Command legality does not depend on vl: an illegal command with vl = 0
  // is still reported illegal.
  // ---------------------------------------------------------------------------
  function automatic logic cmd_legal(input logic [hpc_vector_pkg::OP_W-1:0] op,
                                     input logic [2:0] rm, input logic red,
                                     input logic [BC_W-1:0] bcast,
                                     input logic en_fcmp, input logic en_int,
                                     input logic red_en);
    if (red)
      cmd_legal = red_en && (op[4:3] == 2'b00) && hpc_vector_pkg::rm_legal(rm) &&
                  (bcast == '0);
    else
      cmd_legal = elem_op_legal(op, rm, en_fcmp, en_int);
  endfunction

  // ---------------------------------------------------------------------------
  // Performance-counter map (hpc_varray_perf, perf_cnt_o[i*CW +: CW]).
  // All counters saturate; perf_clear_i zeroes them.  Definitions:
  // docs/PERFORMANCE.md section 1.
  // ---------------------------------------------------------------------------
  localparam int PC_CYCLES      = 0;   // clock cycles since clear
  localparam int PC_BUSY        = 1;   // cycles with busy_o = 1
  localparam int PC_CMD_IN      = 2;   // commands accepted (cmd handshake)
  localparam int PC_CMD_DONE    = 3;   // completion records handed over
  localparam int PC_BEAT_IN     = 4;   // operand beats accepted
  localparam int PC_BEAT_OUT    = 5;   // result beats handed over
  localparam int PC_ELEM_IN     = 6;   // active elements issued to lanes
  localparam int PC_ELEM_OUT    = 7;   // active element results collected
  localparam int PC_STALL_LANE  = 8;   // beat offered, >= 1 lane cannot take it
  localparam int PC_STALL_TRK   = 9;   // beat offered, tracking queue full
  localparam int PC_LANE_STALL  = 10;  // lane-cycles: lane must take, cannot
  localparam int PC_OPND_STARVE = 11;  // command waiting for an operand beat
  localparam int PC_RES_BP      = 12;  // result presented, not taken
  localparam int PC_COLL_WAIT   = 13;  // head beat waiting for lane results
  localparam int PC_RED_WAIT    = 14;  // collector waiting for reduction unit
  localparam int PC_CPL_BP      = 15;  // completion presented, not taken
  localparam int PC_N           = 16;

endpackage
