// =============================================================================
// SilicaFlux-HPC :: hpc_fp32_round -- FP32 round / denormalize / pack
//
// Combinational.  Converts a non-zero, finite, *normalized* intermediate
//     value = (-1)^sign_i * 1.sig_i[22:0] * 2^(exp_i - 127)   (+ guard/sticky)
// with an unbounded signed biased exponent into an IEEE-754 binary32 encoding,
// applying the rounding mode and computing OF/UF/NX.
//
//   sig_i[23] must be 1.  guard_i is the first bit below sig_i[0]; sticky_i is
//   the OR of every further bit of the exact value.
//
// Semantics (IEEE 754-2019 default exception handling, RISC-V conventions):
//   * exp_i < 1: the value is denormalized (shifted right with sticky
//     collection) and rounded once on the subnormal grid; a carry out of the
//     subnormal significand yields the smallest normal number naturally.
//   * overflow: exponent >= 255 after rounding -> OF|NX, result is +-inf or
//     +-largest finite depending on rounding mode and sign.
//   * tininess is detected AFTER rounding: the value is tiny if, rounded to 24
//     bits with an unbounded exponent range, its magnitude is below 2^-126.
//   * UF = tiny AND inexact (the default, non-trapping definition).
// =============================================================================
`default_nettype none

module hpc_fp32_round #(
  parameter int EW = 12                      // width of the signed exponent
) (
  input  wire logic          sign_i,
  input  wire logic [EW-1:0] exp_i,          // signed, biased
  input  wire logic [23:0]   sig_i,          // normalized: sig_i[23] == 1
  input  wire logic          guard_i,
  input  wire logic          sticky_i,
  input  wire logic [2:0]    rm_i,
  output logic [31:0]        res_o,
  output logic               of_o,
  output logic               uf_o,
  output logic               nx_o
);
  // ---------------------------------------------------------------- tininess
  // Rounding at 24-bit precision with unbounded exponent carries into the next
  // binade iff the significand is all ones and the increment fires.
  wire logic inc_unb   = hpc_vector_pkg::round_inc(rm_i, sign_i, sig_i[0], guard_i, sticky_i);
  wire logic carry_unb = inc_unb & (&sig_i);

  wire logic signed [EW-1:0] e_s = $signed(exp_i);
  wire logic exp_lt1   = (e_s < $signed(EW'(1)));
  wire logic exp_eq0   = (e_s == $signed(EW'(0)));
  wire logic exp_ge255 = (e_s > $signed(EW'(254)));
  wire logic tiny      = exp_lt1 & ~(exp_eq0 & carry_unb);

  // ---------------------------------------------------------- denormalize
  // v = {sig, guard, sticky}; for exp_i < 1 shift right by d = 1 - exp_i,
  // OR-ing every shifted-out bit into the sticky position v[0].
  wire logic [25:0]   v_in = {sig_i, guard_i, sticky_i};
  wire logic [EW-1:0] dsh  = EW'(1) - exp_i;             // used only if exp_lt1
  wire logic [5:0]    d    = (dsh > EW'(26)) ? 6'd26 : dsh[5:0];
  wire logic [25:0]   v_sh = v_in >> d;
  wire logic          lost = |(v_in << (6'd26 - d));     // the d bits shifted out
  /* verilator lint_off UNUSEDSIGNAL */
  wire logic [25:0]   v    = exp_lt1 ? {v_sh[25:1], v_sh[0] | lost} : v_in;
  /* verilator lint_on UNUSEDSIGNAL */                   // v[25]: hidden bit

  // ------------------------------------------------------------------ round
  wire logic lsb = v[2];
  wire logic g   = v[1];
  wire logic s   = v[0];
  wire logic inc = hpc_vector_pkg::round_inc(rm_i, sign_i, lsb, g, s);

  // {exponent field, fraction} + increment: a fraction carry propagates into
  // the exponent (normal: next binade; subnormal: smallest normal).
  wire logic [7:0]  e_field   = exp_lt1 ? 8'd0 : exp_i[7:0];
  wire logic [30:0] packed_m  = {e_field, v[24:2]};
  wire logic [30:0] rounded_m = packed_m + 31'(inc);
  wire logic [7:0]  rounded_e = rounded_m[30:23];

  wire logic ovf = exp_ge255 | (~exp_lt1 & (rounded_e == 8'hFF));

  // Overflow result: inf for RNE/RMM and for the directed mode rounding away
  // from zero in this sign; largest finite otherwise.
  logic to_inf;
  always_comb begin
    case (rm_i)
      hpc_vector_pkg::RM_RTZ: to_inf = 1'b0;
      hpc_vector_pkg::RM_RDN: to_inf = sign_i;
      hpc_vector_pkg::RM_RUP: to_inf = ~sign_i;
      default:                to_inf = 1'b1;     // RNE, RMM
    endcase
  end

  always_comb begin
    if (ovf) begin
      res_o = {sign_i, to_inf ? hpc_vector_pkg::FP32_INF_M : hpc_vector_pkg::FP32_MAX_M};
      of_o  = 1'b1;
      nx_o  = 1'b1;
      uf_o  = 1'b0;
    end else begin
      res_o = {sign_i, rounded_m};
      of_o  = 1'b0;
      nx_o  = g | s;
      uf_o  = tiny & (g | s);
    end
  end
endmodule
