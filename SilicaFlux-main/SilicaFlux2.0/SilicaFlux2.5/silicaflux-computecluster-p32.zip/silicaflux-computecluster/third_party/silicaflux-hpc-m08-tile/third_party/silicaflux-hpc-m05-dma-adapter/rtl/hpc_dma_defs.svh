// =============================================================================
// SilicaFlux-HPC Module 05 :: hpc_dma_defs.svh
// Constants of the HPC DMA adapter (hpc_dma_adapter).
//
// A `define header, not a package, for the same reason as DataFabric's
// dma_defs.svh and the SRAM Wrapper Library's sram_defs.svh: Yosys 0.33 cannot
// resolve package references in module parameter lists.
//
// Completion codes 0..10 are the DataFabric DMA error codes (dma_defs.svh,
// enum dma.error of memmap/silicaflux_v_datafabric.yaml) and keep their meaning
// unchanged; the adapter only appends.  Never renumber, only append.
// =============================================================================
`ifndef HPC_DMA_DEFS_SVH
`define HPC_DMA_DEFS_SVH

`include "dma_defs.svh"
`include "sram_defs.svh"     // SRAM_CFG_FATAL: portable elaboration-time configuration errors

// ------------------------------------------------------------ completion codes (cpl_code, 4 bits)
//  0 NONE          transfer completed; every write acknowledged OK
//  1 ZERO_LENGTH   \
//  2 LENGTH         |
//  3 SRC_ALIGN      |  descriptor rejected by the reused DataFabric engine's
//  4 DST_ALIGN      |  dma_validate (first failing rule wins), no bus access
//  5 SRC_OVERFLOW   |
//  6 DST_OVERFLOW   |
//  7 OVERLAP       /
//  8 READ_BUS      a read was answered with an error (fabric decode error, slave
//                  error, scratchpad RANGE/PARITY, adapter tag check); err_addr
//  9 WRITE_BUS     a write was answered with an error; err_addr
// 10 ABORTED       stopped by `abort` at a beat boundary
// 11 REGION        (adapter) the source or destination range is neither entirely
//                  inside the scratchpad window nor entirely outside it; checked
//                  only after rules 1-7 passed; no bus access; err_addr = the
//                  window boundary the range crosses
`define HPC_DMA_ERR_REGION     4'd11

// ------------------------------------------------------------ adapter control state (status_state)
`define HPC_DMA_AST_IDLE   2'd0   // waiting for a descriptor and a completion slot
`define HPC_DMA_AST_CHECK  2'd1   // descriptor latched: validation + region check this cycle
`define HPC_DMA_AST_RUN    2'd2   // reused engine executing the transfer
`define HPC_DMA_AST_RSVD   2'd3

// ------------------------------------------------------------ performance counter map (perf_cnt, CNT_W each)
`define HPC_DMA_PC_CYCLES        0   // cycles since reset / perf_clear
`define HPC_DMA_PC_ACTIVE        1   // cycles the engine was busy (a transfer in VALIDATE..terminal)
`define HPC_DMA_PC_BYTES_RD      2   // bytes returned by error-free read responses (full words)
`define HPC_DMA_PC_BYTES_WR      3   // bytes committed: strobe bytes of error-free write responses
`define HPC_DMA_PC_READS         4   // read requests accepted (all ports)
`define HPC_DMA_PC_WRITES        5   // write requests accepted (all ports)
`define HPC_DMA_PC_REQ_STALL     6   // cycles >= 1 port presented a request that was not accepted
`define HPC_DMA_PC_RSP_WAIT      7   // cycles with requests outstanding and no response on any port
`define HPC_DMA_PC_OUT_SUM       8   // sum over cycles of outstanding requests (Little's law: mean latency)
`define HPC_DMA_PC_OUT_MAX       9   // maximum outstanding requests observed (all ports)
`define HPC_DMA_PC_CPL_OK       10   // completion records with code NONE
`define HPC_DMA_PC_CPL_ERR      11   // completion records with an error code
`define HPC_DMA_PC_BUS_ERR      12   // error responses received (all ports)
`define HPC_DMA_PC_TAG_ERR      13   // response-ownership violations: scratchpad tag/type mismatch, unsolicited response
`define HPC_DMA_PC_SPM_REQ      14   // requests accepted by the scratchpad path
`define HPC_DMA_PC_FAB_REQ      15   // requests accepted by the DataFabric path
`define HPC_DMA_NUM_PC          16

`endif // HPC_DMA_DEFS_SVH
