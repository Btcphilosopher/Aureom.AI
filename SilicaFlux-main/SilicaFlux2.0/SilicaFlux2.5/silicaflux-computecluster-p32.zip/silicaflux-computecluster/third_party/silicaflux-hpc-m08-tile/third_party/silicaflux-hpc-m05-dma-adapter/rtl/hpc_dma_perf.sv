// =============================================================================
// SilicaFlux-HPC Module 05 :: hpc_dma_perf
// Saturating performance counters of the DMA adapter (counter map:
// hpc_dma_defs.svh HPC_DMA_PC_*).  All inputs are this-cycle event values
// computed in hpc_dma_adapter; the counters only accumulate them.
//   * counters saturate at 2^CNT_W - 1 (never wrap: a wrapped byte count would
//     silently under-report bandwidth); OUT_MAX is a running maximum;
//   * perf_clear (synchronous) zeroes every counter in the cycle it is high
//     (events of that cycle are not counted);
//   * PERF_EN = 0 removes the counters (outputs 0).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_dma_defs.svh"
`default_nettype none

module hpc_dma_perf #(
  parameter int PERF_EN = 1,
  parameter int CNT_W   = 32,
  parameter int EW      = 8            // width of the multi-valued event inputs
) (
  input  wire logic                               clk,
  input  wire logic                               rst_n,
  input  wire logic                               perf_clear,
  input  wire logic                               e_active,
  input  wire logic [EW-1:0]                      e_bytes_rd,
  input  wire logic [EW-1:0]                      e_bytes_wr,
  input  wire logic [EW-1:0]                      e_reads,
  input  wire logic [EW-1:0]                      e_writes,
  input  wire logic                               e_req_stall,
  input  wire logic                               e_rsp_wait,
  input  wire logic [EW-1:0]                      e_outstanding,
  input  wire logic                               e_cpl_ok,
  input  wire logic                               e_cpl_err,
  input  wire logic [EW-1:0]                      e_bus_err,
  input  wire logic [EW-1:0]                      e_tag_err,
  input  wire logic [EW-1:0]                      e_spm_req,
  input  wire logic [EW-1:0]                      e_fab_req,
  output logic [`HPC_DMA_NUM_PC*CNT_W-1:0]        perf_cnt
);
  if (CNT_W < 8 || CNT_W > 64) begin : g_err_cnt_w
    `SRAM_CFG_FATAL("hpc_dma_perf: CNT_W must be 8..64")
  end

  if (PERF_EN != 0) begin : g_perf
    logic [CNT_W-1:0] c_q [0:`HPC_DMA_NUM_PC-1];
    logic [EW-1:0]    inc [0:`HPC_DMA_NUM_PC-1];
    always_comb begin
      inc[`HPC_DMA_PC_CYCLES]    = EW'(1);
      inc[`HPC_DMA_PC_ACTIVE]    = EW'(e_active);
      inc[`HPC_DMA_PC_BYTES_RD]  = e_bytes_rd;
      inc[`HPC_DMA_PC_BYTES_WR]  = e_bytes_wr;
      inc[`HPC_DMA_PC_READS]     = e_reads;
      inc[`HPC_DMA_PC_WRITES]    = e_writes;
      inc[`HPC_DMA_PC_REQ_STALL] = EW'(e_req_stall);
      inc[`HPC_DMA_PC_RSP_WAIT]  = EW'(e_rsp_wait);
      inc[`HPC_DMA_PC_OUT_SUM]   = e_outstanding;
      inc[`HPC_DMA_PC_OUT_MAX]   = EW'(0);                 // maximum, handled separately
      inc[`HPC_DMA_PC_CPL_OK]    = EW'(e_cpl_ok);
      inc[`HPC_DMA_PC_CPL_ERR]   = EW'(e_cpl_err);
      inc[`HPC_DMA_PC_BUS_ERR]   = e_bus_err;
      inc[`HPC_DMA_PC_TAG_ERR]   = e_tag_err;
      inc[`HPC_DMA_PC_SPM_REQ]   = e_spm_req;
      inc[`HPC_DMA_PC_FAB_REQ]   = e_fab_req;
    end
    for (genvar i = 0; i < `HPC_DMA_NUM_PC; i++) begin : g_c
      wire [CNT_W:0] sum = {1'b0, c_q[i]} + (CNT_W+1)'(inc[i]);
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n)           c_q[i] <= '0;
        else if (perf_clear)  c_q[i] <= '0;
        else if (i == `HPC_DMA_PC_OUT_MAX) begin
          if (CNT_W'(e_outstanding) > c_q[i]) c_q[i] <= CNT_W'(e_outstanding);
        end else              c_q[i] <= sum[CNT_W] ? {CNT_W{1'b1}} : sum[CNT_W-1:0];
      end
      assign perf_cnt[i*CNT_W +: CNT_W] = c_q[i];
    end
  end else begin : g_noperf
    assign perf_cnt = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused = ^{clk, rst_n, perf_clear, e_active, e_bytes_rd, e_bytes_wr, e_reads, e_writes, e_req_stall,
                    e_rsp_wait, e_outstanding, e_cpl_ok, e_cpl_err, e_bus_err, e_tag_err, e_spm_req, e_fab_req};
    /* verilator lint_on UNUSEDSIGNAL */
  end
endmodule

`default_nettype wire
