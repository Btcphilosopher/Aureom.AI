// =============================================================================
// SilicaFlux-HPC :: hpc_fp32_fma -- pipelined IEEE-754 binary32 fused
//                                   multiply-add
//
//   res = round( (neg_prod_i ? -(a*b) : a*b) + (neg_add_i ? -c : c) )
//   computed with a SINGLE rounding: FMADD, FMSUB, FNMSUB, FNMADD.
//   All five rounding modes, full subnormal support, IEEE 754-2019 / RISC-V
//   exception flags (incl. NV for inf*0 even when c is a quiet NaN),
//   canonical NaN.
//
// Datapath (docs/MICROARCHITECTURE.md, "FMA alignment frame"):
//   A  unpack, special cases, normalize a/b significands, 24x24 product P
//      (P in [2^46, 2^48)), align c into an 80-bit frame in parallel
//   B  80-bit add / subtract with sticky-borrow, absolute value
//   C  leading-zero count, normalize (C1) | round, pack (C2)
//
// Frame (bit 0 = LSB):  P occupies [49:2]; c (24 bits) is placed with its LSB
// at bit 2+d, d = exponent(c LSB) - exponent(P LSB).
//   * 0 <= shift <= 80: c is exact inside the frame, bits shifted below bit 0
//     only occur when c < 2^23 << P and are collapsed into a sticky bit (the
//     sum is then positive and the collapsed bits lie >= 24 positions below
//     the result's rounding point).
//   * shift < 0 (c dominates by more than the frame): c is clamped to the top
//     [79:56]; P (< 2^50) then lies more than 6 binades below c's LSB, i.e.
//     strictly inside (0, ulp/8) of c, and only contributes to sticky /
//     the borrow -- identical rounding decision.
//
// Latency LAT >= 3: registers between A/B and B/C.  LAT >= 4 (default) splits
// C into C1 (normalize) | C2 (round); further stages are output registers.
// =============================================================================
`default_nettype none

module hpc_fp32_fma #(
  parameter int LAT = 4,
  parameter int IDW = 3
) (
  input  wire logic           clk_i,
  input  wire logic           rst_ni,
  input  wire logic           valid_i,
  input  wire logic [IDW-1:0] id_i,
  input  wire logic [31:0]    a_i,
  input  wire logic [31:0]    b_i,
  input  wire logic [31:0]    c_i,
  input  wire logic           neg_prod_i,
  input  wire logic           neg_add_i,
  input  wire logic [2:0]     rm_i,
  output logic                valid_o,
  output logic [IDW-1:0]      id_o,
  output logic [31:0]         res_o,
  output logic [4:0]          flags_o
);
  if (LAT < hpc_vector_pkg::MIN_LAT_FMA) begin : g_bad_lat
    hpc_param_error_LAT_FMA_below_minimum u_err ();
  end

  localparam int FW = 80;           // alignment frame width
  localparam int SW = FW + 1;       // sum width (carry)

  // =========================================================== segment A
  wire logic sp = a_i[31] ^ b_i[31] ^ neg_prod_i;    // sign of the product term
  wire logic sc = c_i[31] ^ neg_add_i;               // sign of the addend term
  wire logic eff_sub = sp ^ sc;

  wire logic a_nan  = hpc_vector_pkg::fp_is_nan(a_i);
  wire logic b_nan  = hpc_vector_pkg::fp_is_nan(b_i);
  wire logic c_nan  = hpc_vector_pkg::fp_is_nan(c_i);
  wire logic a_inf  = hpc_vector_pkg::fp_is_inf(a_i);
  wire logic b_inf  = hpc_vector_pkg::fp_is_inf(b_i);
  wire logic c_inf  = hpc_vector_pkg::fp_is_inf(c_i);
  wire logic a_zero = hpc_vector_pkg::fp_is_zero(a_i);
  wire logic b_zero = hpc_vector_pkg::fp_is_zero(b_i);
  wire logic c_zero = hpc_vector_pkg::fp_is_zero(c_i);
  wire logic any_snan = hpc_vector_pkg::fp_is_snan(a_i) | hpc_vector_pkg::fp_is_snan(b_i) |
                        hpc_vector_pkg::fp_is_snan(c_i);
  wire logic inv_mul  = (a_inf & b_zero) | (a_zero & b_inf);
  wire logic [30:0] c_mag = c_i[30:0];

  logic        spec, spec_nv;
  logic [31:0] spec_res;
  always_comb begin
    spec = 1'b1; spec_nv = 1'b0; spec_res = hpc_vector_pkg::FP32_QNAN;
    if (a_nan | b_nan | c_nan) begin
      spec_nv = any_snan | inv_mul;                 // RISC-V: inf*0+qNaN -> NV
    end else if (inv_mul) begin
      spec_nv = 1'b1;
    end else if (a_inf | b_inf) begin
      if (c_inf & eff_sub) spec_nv = 1'b1;          // inf - inf
      else                 spec_res = {sp, hpc_vector_pkg::FP32_INF_M};
    end else if (c_inf) begin
      spec_res = {sc, hpc_vector_pkg::FP32_INF_M};
    end else if (a_zero | b_zero) begin
      // product is an exact zero: result is exactly the addend
      if (c_zero) spec_res = {(sp == sc) ? sp : (rm_i == hpc_vector_pkg::RM_RDN), 31'd0};
      else        spec_res = {sc, c_mag};
    end else begin
      spec = 1'b0;
    end
  end

  // ---- normalize multiplicands (leading one at bit 23)
  wire logic [23:0] siga = hpc_vector_pkg::fp_sig(a_i);
  wire logic [23:0] sigb = hpc_vector_pkg::fp_sig(b_i);
  logic [4:0] lza, lzb;
  hpc_lzc #(.W(24)) u_lza (.x_i(siga), .cnt_o(lza));
  hpc_lzc #(.W(24)) u_lzb (.x_i(sigb), .cnt_o(lzb));
  wire logic [23:0] siga_n = siga << lza;
  wire logic [23:0] sigb_n = sigb << lzb;
  wire logic [7:0]  ea   = hpc_vector_pkg::fp_exp(a_i);
  wire logic [7:0]  eb   = hpc_vector_pkg::fp_exp(b_i);
  wire logic [11:0] ea_n = {4'd0, ea} - {7'd0, lza};                      // signed
  wire logic [11:0] eb_n = {4'd0, eb} - {7'd0, lzb};                      // signed
  wire logic [47:0] prod = siga_n * sigb_n;

  // ---- align the addend
  wire logic [23:0] sigc = c_zero ? 24'd0 : hpc_vector_pkg::fp_sig(c_i);
  wire logic [7:0]  ec8  = hpc_vector_pkg::fp_exp(c_i);
  wire logic [11:0] ec   = {4'd0, ec8};
  //  d = (ec - 150) - (ea_n + eb_n - 300)  : LSB(c) exponent - LSB(P) exponent
  wire logic [11:0] dd     = ec - ea_n - eb_n + 12'd150;
  wire logic [11:0] sh_raw = 12'd54 - dd;                      // FW-24 - (2+d)
  wire logic        clamp  = ($signed(sh_raw) < $signed(12'd0)) && !c_zero;
  wire logic        sh_neg = $signed(sh_raw) < $signed(12'd0);
  wire logic        sh_big = $signed(sh_raw) > $signed(12'(FW));
  wire logic [6:0]  sh     = sh_neg ? 7'd0 : (sh_big ? 7'(FW) : sh_raw[6:0]);
  wire logic [FW+23:0] t   = {sigc, {FW{1'b0}}} >> sh;
  wire logic [FW-1:0]  c_frame  = t[FW+23:24];
  wire logic           c_sticky = |t[23:0];
  // signed exponent of frame bit 0
  wire logic [11:0] f_exp = clamp ? (ec - 12'd150 - 12'd56) : (ea_n + eb_n - 12'd302);

  // ------------------------------------------------- register A -> B
  localparam int WA = IDW + 1 + 1 + 32 + 48 + FW + 1 + 12 + 1 + 1 + 1 + 3;
  logic          v_b;
  logic [WA-1:0] d_b;
  hpc_pipe #(.W(WA), .N(1)) u_pa (
    .clk_i, .rst_ni, .valid_i(valid_i),
    .data_i({id_i, spec, spec_nv, spec_res, prod, c_frame, c_sticky, f_exp,
             sp, sc, eff_sub, rm_i}),
    .valid_o(v_b), .data_o(d_b));

  logic [IDW-1:0] id_b;
  logic           spec_b, spec_nv_b, c_sticky_b, sp_b, sc_b, eff_sub_b;
  logic [31:0]    spec_res_b;
  logic [47:0]    prod_b;
  logic [FW-1:0]  c_frame_b;
  logic [11:0]    f_exp_b;
  logic [2:0]     rm_b;
  assign {id_b, spec_b, spec_nv_b, spec_res_b, prod_b, c_frame_b, c_sticky_b, f_exp_b,
          sp_b, sc_b, eff_sub_b, rm_b} = d_b;

  // =========================================================== segment B
  logic [SW:0]   s_raw;                 // SW+1 bits, two's complement
  logic          s_neg;
  logic [SW-1:0] s_abs;
  logic          r_sign;
  wire logic [SW:0] p_ext = {{(SW+1-50){1'b0}}, prod_b, 2'b00};
  wire logic [SW:0] c_ext = {2'b00, c_frame_b};
  wire logic [SW-1:0] s_neg_raw = ~s_raw[SW-1:0] + {{(SW-1){1'b0}}, 1'b1};  // -s_raw mod 2^SW
  assign s_raw  = eff_sub_b ? (p_ext - c_ext - {{SW{1'b0}}, c_sticky_b}) : (p_ext + c_ext);
  assign s_neg  = s_raw[SW];            // only possible when c_sticky_b == 0
  assign s_abs  = s_neg ? s_neg_raw : s_raw[SW-1:0];
  assign r_sign = s_neg ? sc_b : sp_b;

  // ------------------------------------------------- register B -> C
  localparam int WB = IDW + 1 + 1 + 32 + SW + 1 + 12 + 1 + 1 + 3;
  logic          v_c;
  logic [WB-1:0] d_c;
  hpc_pipe #(.W(WB), .N(1)) u_pb (
    .clk_i, .rst_ni, .valid_i(v_b),
    .data_i({id_b, spec_b, spec_nv_b, spec_res_b, s_abs, c_sticky_b, f_exp_b,
             r_sign, eff_sub_b, rm_b}),
    .valid_o(v_c), .data_o(d_c));

  logic [IDW-1:0] id_c;
  logic           spec_c, spec_nv_c, sticky_c, r_sign_c, eff_sub_c;
  logic [31:0]    spec_res_c;
  logic [SW-1:0]  s_abs_c;
  logic [11:0]    f_exp_c;
  logic [2:0]     rm_c;
  assign {id_c, spec_c, spec_nv_c, spec_res_c, s_abs_c, sticky_c, f_exp_c,
          r_sign_c, eff_sub_c, rm_c} = d_c;

  // ===================================================== segment C1: normalize
  logic [6:0] lz;
  hpc_lzc #(.W(SW)) u_lzc (.x_i(s_abs_c), .cnt_o(lz));
  wire logic [SW-1:0] norm = s_abs_c << lz;
  wire logic [11:0]   e_n  = f_exp_c + 12'(SW - 1 + 127) - {5'd0, lz};  // lead one at SW-1

  // results that bypass the rounder: specials and exact cancellation
  // (+0, or -0 in RDN)
  wire logic        exact_zero = (s_abs_c == '0) && !sticky_c;
  wire logic        byp     = spec_c | exact_zero;
  wire logic [31:0] byp_res = spec_c ? spec_res_c
                                     : {eff_sub_c ? (rm_c == hpc_vector_pkg::RM_RDN) : r_sign_c, 31'd0};
  wire logic        byp_nv  = spec_c & spec_nv_c;

  // ------------------------------------------------- optional split register
  // The first latency stage beyond the minimum cuts normalize | round.
  localparam int SPLIT = (LAT > hpc_vector_pkg::MIN_LAT_FMA) ? 1 : 0;
  localparam int WN = IDW + 1 + 32 + 1 + 1 + 12 + 24 + 1 + 1 + 3;
  logic          v_r;
  logic [WN-1:0] d_r;
  hpc_pipe #(.W(WN), .N(SPLIT)) u_pn (
    .clk_i, .rst_ni, .valid_i(v_c),
    .data_i({id_c, byp, byp_res, byp_nv, r_sign_c, e_n, norm[SW-1:SW-24], norm[SW-25],
             (|norm[SW-26:0]) | sticky_c, rm_c}),
    .valid_o(v_r), .data_o(d_r));

  logic [IDW-1:0] id_r;
  logic           byp_r, byp_nv_r, sign_r, g_r, st_r;
  logic [31:0]    byp_res_r;
  logic [11:0]    e_r;
  logic [23:0]    sig_r;
  logic [2:0]     rm_r;
  assign {id_r, byp_r, byp_res_r, byp_nv_r, sign_r, e_r, sig_r, g_r, st_r, rm_r} = d_r;

  // ===================================================== segment C2: round
  logic [31:0] r_res;
  logic        r_of, r_uf, r_nx;
  hpc_fp32_round #(.EW(12)) u_round (
    .sign_i(sign_r), .exp_i(e_r), .sig_i(sig_r), .guard_i(g_r), .sticky_i(st_r),
    .rm_i(rm_r), .res_o(r_res), .of_o(r_of), .uf_o(r_uf), .nx_o(r_nx));

  wire logic [31:0] res_r   = byp_r ? byp_res_r : r_res;
  wire logic [4:0]  flags_r = byp_r ? {byp_nv_r, 4'b0000} : {2'b00, r_of, r_uf, r_nx};

  // ------------------------------------------------- output stages
  hpc_pipe #(.W(IDW + 37), .N(LAT - hpc_vector_pkg::MIN_LAT_FMA - SPLIT)) u_po (
    .clk_i, .rst_ni, .valid_i(v_r), .data_i({id_r, res_r, flags_r}),
    .valid_o(valid_o), .data_o({id_o, res_o, flags_o}));

`ifndef SYNTHESIS
  // A negative frame sum implies |c| > |P|, which excludes collapsed c bits.
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
    end else if (v_b && !spec_b && s_neg && c_sticky_b) begin
      $fatal(1, "hpc_fp32_fma: negative sum with collapsed addend bits");
    end
  end
`endif
endmodule
