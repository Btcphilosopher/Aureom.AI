// =============================================================================
// SilicaFlux-HPC Module 05 :: hpc_tile_vseq
// Minimal REFERENCE vector load/store sequencer for the integration test:
// scratchpad (Module 04 port) -> operand beats -> hpc_vector_array (Module 03)
// -> result beats -> scratchpad.  It exists because Module 03 has a streaming
// interface only (no memory port, Module 03 README "Operand supply") and the
// integration test needs a compute operation that consumes the data the DMA
// moved into the scratchpad.
//
// It is deliberately simple and SERIAL: per beat it loads the needed operand
// words (one scratchpad request per cycle when granted, responses in order),
// presents one operand beat, waits for the result beat and stores the
// res_mask'ed result words, waiting for every write acknowledgement before
// the next beat.  Throughput is therefore ~(loads + stores + latencies) cycles
// per beat -- NOT a performance design (a VRF / streaming load unit is a
// future module).  It shares the scratchpad with the DMA on its own port, so
// vector and DMA traffic contend for banks under the scratchpad's arbitration.
//
// Job: op, rm, vl, bcast{c,b,a}, scalar, element addresses a/b/c/d (FP32/INT32
// words, little-endian, contiguous), tid.  Operand x is loaded iff the
// operation reads it and bcast[x] = 0 (a: all ops; b: all but FMV; c: FMA
// family).  Element e of beat g = floor(e/N) is lane e mod N (Module 03 sec 5).
// Reductions are not used (cmd_red = 0).  Done record: tid, OR of the array's
// flags, illegal, count, err (a scratchpad error response was received; the
// affected operand reads as 0 / the write may be missing).
// Classification: SYNTHESIZABLE (reference integration glue)
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module hpc_tile_vseq #(
  parameter int N         = 4,              // = hpc_vector_array NUM_LANES
  parameter int VL_W      = 16,
  parameter int TID_W     = 8,
  parameter int SPM_TAG_W = 8,
  localparam int LB       = $clog2(N),                 // log2 lanes (0 for N = 1)
  localparam int LW       = (N > 1) ? LB : 1           // lane-index width
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  // ---------------------------------------------------------- job / done
  input  wire logic                  job_valid,
  output logic                       job_ready,
  input  wire logic [4:0]            job_op,
  input  wire logic [2:0]            job_rm,
  input  wire logic [VL_W-1:0]       job_vl,
  input  wire logic [2:0]            job_bcast,
  input  wire logic [31:0]           job_scalar,
  input  wire logic [31:0]           job_a,
  input  wire logic [31:0]           job_b,
  input  wire logic [31:0]           job_c,
  input  wire logic [31:0]           job_d,
  input  wire logic [TID_W-1:0]      job_tid,
  output logic                       done_valid,
  input  wire logic                  done_ready,
  output logic [TID_W-1:0]           done_tid,
  output logic [4:0]                 done_flags,
  output logic                       done_illegal,
  output logic [VL_W-1:0]            done_count,
  output logic                       done_err,
  // ---------------------------------------------------------- scratchpad port
  output logic                       spm_req_valid,
  input  wire logic                  spm_req_ready,
  output logic                       spm_req_we,
  output logic [31:0]                spm_req_addr,
  output logic [31:0]                spm_req_wdata,
  output logic [3:0]                 spm_req_wstrb,
  output logic [SPM_TAG_W-1:0]       spm_req_tag,
  input  wire logic                  spm_rsp_valid,
  output logic                       spm_rsp_ready,
  input  wire logic [31:0]           spm_rsp_rdata,
  input  wire logic                  spm_rsp_err,
  input  wire logic [SPM_TAG_W-1:0]  spm_rsp_tag,
  // ---------------------------------------------------------- hpc_vector_array (master side)
  output logic                       cmd_valid,
  input  wire logic                  cmd_ready,
  output logic [4:0]                 cmd_op,
  output logic [2:0]                 cmd_rm,
  output logic [VL_W-1:0]            cmd_vl,
  output logic [2:0]                 cmd_bcast,
  output logic [31:0]                cmd_scalar,
  output logic [TID_W-1:0]           cmd_tid,
  output logic                       opnd_valid,
  input  wire logic                  opnd_ready,
  output logic [N*32-1:0]            opnd_a,
  output logic [N*32-1:0]            opnd_b,
  output logic [N*32-1:0]            opnd_c,
  input  wire logic                  res_valid,
  output logic                       res_ready,
  input  wire logic [N*32-1:0]       res_data,
  input  wire logic [N-1:0]          res_mask,
  input  wire logic                  cpl_valid,
  output logic                       cpl_ready,
  input  wire logic [4:0]            cpl_flags,
  input  wire logic                  cpl_illegal,
  input  wire logic [VL_W-1:0]       cpl_count,
  output logic                       busy
);
  if (SPM_TAG_W < 2 + LW + 1 || N > 16 || (N & (N - 1)) != 0) begin : g_err_cfg
    `SRAM_CFG_FATAL("hpc_tile_vseq: N must be 1, 2, 4, 8 or 16 and SPM_TAG_W must hold {we, operand, lane}")
  end

  localparam logic [2:0] S_IDLE = 3'd0, S_CMD = 3'd1, S_LOAD = 3'd2, S_OPND = 3'd3, S_RES = 3'd4,
                         S_STORE = 3'd5, S_CPL = 3'd6, S_DONE = 3'd7;
  logic [2:0]       st_q;
  logic [4:0]       op_q;
  logic [2:0]       rm_q, bc_q, rd_q;
  logic [VL_W-1:0]  vl_q, g_q, nb_q;                   // beat index, number of beats
  logic [31:0]      sc_q, a_q, b_q, c_q, d_q;
  logic [TID_W-1:0] tid_q;
  logic [1:0]       io_q;                              // operand being issued (0 a, 1 b, 2 c)
  logic [LW:0]      il_q;                              // lane being issued
  logic [7:0]       n_iss_q, n_rsp_q;                  // requests / responses of this beat phase
  logic [N*32-1:0]  ra_q, rb_q, rc_q, rd_dat_q;
  logic [N-1:0]     rmask_q;
  logic             err_q;
  logic [4:0]       fl_q;
  logic             ill_q;
  logic [VL_W-1:0]  cnt_q;

  // operands an operation reads (Module 02 encoding: FMV 0x00, FMA family 0x04..0x07)
  function automatic logic [2:0] reads(input logic [4:0] op, input logic [2:0] bc);
    logic [2:0] r;
    r = 3'b001;
    if (op != 5'h00) r[1] = 1'b1;
    if (op >= 5'h04 && op <= 5'h07) r[2] = 1'b1;
    reads = r & ~bc;                                    // (no `return`: Yosys 0.33)
  endfunction

  // element index of (beat g, lane l) and whether it is inside the vector
  wire [VL_W+LW:0] e_iss   = ((VL_W+LW+1)'(g_q) << LB) + (VL_W+LW+1)'(il_q);
  wire             e_valid = (e_iss < (VL_W+LW+1)'(vl_q)) && (il_q < (LW+1)'(N));
  wire [31:0]      base_iss = (io_q == 2'd0) ? a_q : (io_q == 2'd1) ? b_q : c_q;

  // next (operand, lane) to issue in LOAD: skip operands not read; lanes beyond vl are not loaded
  logic       ld_more;
  logic [1:0] nx_o;
  logic       nx_ok;
  always_comb begin
    nx_ok = 1'b0; nx_o = io_q;
    if (io_q == 2'd0 && rd_q[1])                 begin nx_o = 2'd1; nx_ok = 1'b1; end
    else if (io_q == 2'd0 && rd_q[2])            begin nx_o = 2'd2; nx_ok = 1'b1; end
    else if (io_q == 2'd1 && rd_q[2])            begin nx_o = 2'd2; nx_ok = 1'b1; end
  end
  assign ld_more = e_valid;                              // current (io_q, il_q) is a real load

  // ---------------------------------------------------------- outputs
  assign job_ready    = (st_q == S_IDLE);
  assign done_valid   = (st_q == S_DONE);
  assign done_tid     = tid_q;
  assign done_flags   = fl_q;
  assign done_illegal = ill_q;
  assign done_count   = cnt_q;
  assign done_err     = err_q;
  assign busy         = (st_q != S_IDLE);

  assign cmd_valid  = (st_q == S_CMD);
  assign cmd_op     = op_q;
  assign cmd_rm     = rm_q;
  assign cmd_vl     = vl_q;
  assign cmd_bcast  = bc_q;
  assign cmd_scalar = sc_q;
  assign cmd_tid    = tid_q;
  assign opnd_valid = (st_q == S_OPND);
  assign opnd_a     = ra_q;
  assign opnd_b     = rb_q;
  assign opnd_c     = rc_q;
  assign res_ready  = (st_q == S_RES);
  assign cpl_ready  = (st_q == S_CPL);
  assign spm_rsp_ready = 1'b1;

  // scratchpad requests: loads in S_LOAD, stores in S_STORE (one per cycle, held until accepted)
  wire st_lane_ok = (il_q < (LW+1)'(N)) && rmask_q[il_q[LW-1:0]];
  assign spm_req_valid = ((st_q == S_LOAD) && ld_more) || ((st_q == S_STORE) && st_lane_ok);
  assign spm_req_we    = (st_q == S_STORE);
  assign spm_req_addr  = (st_q == S_STORE) ? d_q + 32'({e_iss, 2'b00}) : base_iss + 32'({e_iss, 2'b00});
  assign spm_req_wdata = rd_dat_q[il_q[LW-1:0]*32 +: 32];
  assign spm_req_wstrb = 4'hF;
  assign spm_req_tag   = SPM_TAG_W'({(st_q == S_STORE), io_q, il_q[LW-1:0]});
  wire req_hs = spm_req_valid && spm_req_ready;
  wire rsp_hs = spm_rsp_valid;                          // rsp_ready = 1

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= S_IDLE;
      op_q <= '0; rm_q <= '0; bc_q <= '0; rd_q <= '0; vl_q <= '0; g_q <= '0; nb_q <= '0;
      sc_q <= '0; a_q <= '0; b_q <= '0; c_q <= '0; d_q <= '0; tid_q <= '0;
      io_q <= '0; il_q <= '0; n_iss_q <= '0; n_rsp_q <= '0;
      rmask_q <= '0; err_q <= 1'b0; fl_q <= '0; ill_q <= 1'b0; cnt_q <= '0;
    end else begin
      // responses of the current load/store phase (in order; tag carries {we, operand, lane})
      if (rsp_hs) begin
        n_rsp_q <= n_rsp_q + 1'b1;
        if (spm_rsp_err) err_q <= 1'b1;
      end
      case (st_q)
        S_IDLE: if (job_valid) begin
          op_q <= job_op; rm_q <= job_rm; vl_q <= job_vl; bc_q <= job_bcast; sc_q <= job_scalar;
          a_q <= job_a; b_q <= job_b; c_q <= job_c; d_q <= job_d; tid_q <= job_tid;
          rd_q <= reads(job_op, job_bcast);
          nb_q <= VL_W'((({1'b0, job_vl}) + (VL_W+1)'(N - 1)) >> LB);
          err_q <= 1'b0;
          st_q <= S_CMD;
        end
        S_CMD: if (cmd_ready) begin
          g_q <= '0;
          st_q <= (nb_q == '0) ? S_CPL : S_LOAD;
          io_q <= rd_q[0] ? 2'd0 : rd_q[1] ? 2'd1 : 2'd2;
          il_q <= '0; n_iss_q <= '0; n_rsp_q <= '0;
          ra_q <= '0; rb_q <= '0; rc_q <= '0;
        end
        S_LOAD: begin
          // issue: walk lanes of the current operand, then the next operand read by the op
          if (!ld_more || req_hs) begin
            if (req_hs) n_iss_q <= n_iss_q + 1'b1;
            if ((LW+2)'(il_q) + 1'b1 < (LW+2)'(N) && e_valid && ({1'b0, e_iss} + 1'b1 < (VL_W+LW+2)'(vl_q))) il_q <= il_q + 1'b1;
            else if (nx_ok) begin io_q <= nx_o; il_q <= '0; end
            else il_q <= (LW+1)'(N);                    // all issued for this beat
          end
          // all issued and answered -> operand beat
          if (il_q == (LW+1)'(N) && n_rsp_q + (rsp_hs ? 8'd1 : 8'd0) == n_iss_q) st_q <= S_OPND;
        end
        S_OPND: if (opnd_ready) st_q <= S_RES;
        S_RES: if (res_valid) begin
          rd_dat_q <= res_data; rmask_q <= res_mask;
          il_q <= '0; n_iss_q <= '0; n_rsp_q <= '0;
          st_q <= S_STORE;
        end
        S_STORE: begin
          if (!st_lane_ok || req_hs) begin
            if (req_hs) n_iss_q <= n_iss_q + 1'b1;
            if (il_q < (LW+1)'(N)) il_q <= il_q + 1'b1;
          end
          if (il_q == (LW+1)'(N) && n_rsp_q + (rsp_hs ? 8'd1 : 8'd0) == n_iss_q) begin
            if (g_q + 1'b1 == nb_q) st_q <= S_CPL;
            else begin
              g_q <= g_q + 1'b1;
              io_q <= rd_q[0] ? 2'd0 : rd_q[1] ? 2'd1 : 2'd2;
              il_q <= '0; n_iss_q <= '0; n_rsp_q <= '0;
              ra_q <= '0; rb_q <= '0; rc_q <= '0;
              st_q <= S_LOAD;
            end
          end
        end
        S_CPL: if (cpl_valid) begin
          fl_q <= cpl_flags; ill_q <= cpl_illegal; cnt_q <= cpl_count;
          st_q <= S_DONE;
        end
        default: if (done_ready) st_q <= S_IDLE;        // S_DONE
      endcase
      // capture load data by its tag (independent of the issue walk)
      if (rsp_hs && !spm_rsp_tag[2 + LW]) begin
        case (spm_rsp_tag[LW +: 2])
          2'd0:    ra_q[spm_rsp_tag[LW-1:0]*32 +: 32] <= spm_rsp_err ? 32'd0 : spm_rsp_rdata;
          2'd1:    rb_q[spm_rsp_tag[LW-1:0]*32 +: 32] <= spm_rsp_err ? 32'd0 : spm_rsp_rdata;
          default: rc_q[spm_rsp_tag[LW-1:0]*32 +: 32] <= spm_rsp_err ? 32'd0 : spm_rsp_rdata;
        endcase
      end
    end
  end
endmodule

`default_nettype wire
