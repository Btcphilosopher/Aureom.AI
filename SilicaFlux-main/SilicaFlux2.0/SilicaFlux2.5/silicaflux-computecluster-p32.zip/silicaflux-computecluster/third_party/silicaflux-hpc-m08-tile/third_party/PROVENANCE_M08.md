# Third-party (SilicaFlux in-repo) sources — vendored UNMODIFIED

Origin: repository `btcphilosopher/Aureom.AI`, branch `claude/epic-albattani-tv5m7y`, commit `03981c2`. Every file
here is byte-identical to the member of the named archive (compared against a fresh extraction, 0
differences). To verify: `cd third_party && sha256sum -c SHA256SUMS`.

| Directory | Origin archive (path in the repository) | Archive SHA-256 |
|---|---|---|
| `silicaflux-datafabric/` | `SilicaFlux-main/silicaflux-datafabric.zip` (identical copy in `SilicaFlux2.0/SilicaFlux2.5/`) | `9f1f37357c8e25e00c214227894bca37c45e18ae9d7a993f87039a7679b665fb` |
| `silicaflux-sramlib/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` | `13b1cee1f913d7b5821f338ce0d12a038e02a1062538c66e4917cae2599beb16` |
| `silicaflux-hpc-m03-vector-array/` (with Module 02 in `rtl/lane/`) | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m03-vector-array.zip` | `c1b6d2946c5bb56b22bcaeb1da6940f61c9a07defa21a2ea40a532138d021f3d` |
| `silicaflux-hpc-m04-scratchpad/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m04-scratchpad.zip` | `1457466c57542c8c76c20b2d5ec5b466865fbe3fdecfd19d6d8f7955c5d5b524` |
| `silicaflux-hpc-m05-dma-adapter/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m05-dma-adapter.zip` | `655b668494942bae93ab6d2ea81bf429f95421a17b3437997ab15284e4c7e3f8` |
| `silicaflux-hpc-fp32-fma/` (Module 01 RTL, not instantiated) | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-fp32-fma.zip` | `8ca1a6d8c80466632f63b9928f34ddcf81de94a812e4ccfd7e43054594af530b` |
| `berkeley-softfloat-3/` (Release 3e, BSD-3-Clause; used only by the model self-test) | `third_party/` of the Module 01 archive above | (same archive) |

Subsets copied:

* **DataFabric**: `rtl/` (DMA engines, crossbar, SRAM slaves, SoC `sfv_soc_df`), `generated/`, `memmap/`, `firmware/`,
  `tb/common` (protocol checker, trace monitor), `tb/soc`, `python/datafabric/memmap_gen.py`,
  `scripts/datafabric/soc_regress.py`, `docs/datafabric/{PROTOCOL,DMA,MEMORY_MAP,ARCHITECTURE,FIRMWARE}.md`, and
  its `third_party/silicaflux-v` (SilicaFlux-V CPU, peripherals, boot ROM and firmware sources).
* **SRAM Wrapper Library**: `rtl/` (`README.upstream.md` = its README).
* **Modules 01, 03, 04, 05**: `rtl/` only.

Nothing here is edited. Module 08 reuses these files by instantiation. The SoC variant
`soc/rtl/sfv_soc_hpc.sv` and its testbench are **generated** from `sfv_soc_df.sv` / `tb_soc_df.sv` by
`soc/derive_soc.py`, which lists every edit explicitly. The memory map `soc/memmap/silicaflux_v_hpc.yaml`
is a copy of the DataFabric YAML with additions marked `new: true`.
