// =============================================================================
// SilicaFlux-HPC :: hpc_varray_fifo -- small synchronous FIFO (DEPTH >= 1)
//
// Register-based FIFO used for the command queue, the beat-tracking queue and
// the completion queue of hpc_vector_array.
//   * empty_o / full_o / count_o are functions of registered state only;
//   * rdata_o is the head entry (a mux over storage registers: registered
//     state only);
//   * push_i while full or pop_i while empty is a caller error (simulation
//     assertion); simultaneous push and pop are allowed in any non-error state.
//   * pointers and count are control state (asynchronously reset); storage is
//     datapath state qualified by the pointers (not reset, SilicaFlux rule 4).
// =============================================================================
`default_nettype none

module hpc_varray_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 2
) (
  input  wire logic                         clk_i,
  input  wire logic                         rst_ni,
  input  wire logic                         push_i,
  input  wire logic [W-1:0]                 wdata_i,
  input  wire logic                         pop_i,
  output logic      [W-1:0]                 rdata_o,
  output logic                              empty_o,
  output logic                              full_o,
  output logic      [$clog2(DEPTH+1)-1:0]   count_o
);
  localparam int IW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  localparam int CW = $clog2(DEPTH + 1);

  if (DEPTH < 1) begin : g_bad_depth
    hpc_param_error_FIFO_DEPTH_below_1 u_err ();
  end

  function automatic logic [IW-1:0] ptr_inc(input logic [IW-1:0] p);
    ptr_inc = (p == IW'(DEPTH - 1)) ? '0 : p + IW'(1);
  endfunction

  logic [W-1:0]  mem_q [0:DEPTH-1];
  logic [IW-1:0] rd_q, wr_q;
  logic [CW-1:0] cnt_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rd_q  <= '0;
      wr_q  <= '0;
      cnt_q <= '0;
    end else begin
      if (push_i) wr_q <= ptr_inc(wr_q);
      if (pop_i)  rd_q <= ptr_inc(rd_q);
      cnt_q <= cnt_q + CW'(push_i) - CW'(pop_i);
    end
  end

  always_ff @(posedge clk_i) begin
    if (push_i) mem_q[wr_q] <= wdata_i;
  end

  assign rdata_o = mem_q[rd_q];
  assign empty_o = (cnt_q == '0);
  assign full_o  = (cnt_q == CW'(DEPTH));
  assign count_o = cnt_q;

`ifndef SYNTHESIS
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
    end else begin
      if (push_i && full_o && !pop_i)
        $fatal(1, "hpc_varray_fifo %m: push while full");
      if (pop_i && empty_o)
        $fatal(1, "hpc_varray_fifo %m: pop while empty");
    end
  end
`endif
endmodule
