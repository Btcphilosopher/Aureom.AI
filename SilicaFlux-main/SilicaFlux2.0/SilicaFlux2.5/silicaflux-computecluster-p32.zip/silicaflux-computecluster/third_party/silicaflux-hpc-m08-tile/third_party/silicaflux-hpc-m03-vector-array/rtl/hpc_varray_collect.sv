// =============================================================================
// SilicaFlux-HPC :: hpc_varray_collect -- in-order result collector
//
// Consumes the beat-tracking queue in order.  For the beat at the head of the
// queue it waits until EVERY active lane of that beat presents its result,
// then takes all of them in the same cycle (lane out_ready) and
//   * elementwise command: loads one result beat into the output register
//     (inactive element positions carry data 0 / flags 0 / mask bit 0);
//   * sum-reduction command: forwards the beat's element results to the
//     reduction unit as one GROUP item;
// and accumulates the command's exception flags and active-element count.
//
// Losslessness and association (docs/MICROARCHITECTURE.md section 4)
//   * a lane result is only ever consumed by an out_ready handshake; until
//     then it is held in that lane's completion buffer (Module 02 contract:
//     out_valid never falls and the payload is stable without a handover).
//     A late or stalled lane therefore delays the beat but never loses or
//     overwrites the results of the other lanes;
//   * each lane is in-order, and lane l's next result always belongs to the
//     oldest beat in which l is active.  The collector only consumes results
//     for the head beat, so result i of lane l is associated with the i-th
//     beat that activated l.  The lane tag (beat sequence number) is checked
//     against this expectation by a simulation assertion.
//
// Completion tokens enter the item stream in command order:
//   * elementwise command: TOKEN item pushed together with its last beat; it
//     carries a last-beat sequence number (lbseq) so that the completion
//     output can hold it until that beat has been handed over;
//   * vl = 0 elementwise command: TOKEN item (no beats);
//   * reduction: GROUP items; the reduction unit produces the token.
//
// Interface timing: res_valid_o and every res_* payload output are registered
// (payload forced to 0 while res_valid_o = 0).  res_ready_i fans into the
// lane out_ready signals and the queue pop (no path to any output).
// =============================================================================
`default_nettype none

module hpc_varray_collect #(
  parameter int N      = 2,
  parameter int VL_W   = 16,
  parameter int TID_W  = 8,
  parameter int LTAG_W = 4,
  parameter int LBS_W  = 3
) (
  input  wire logic                              clk_i,
  input  wire logic                              rst_ni,
  // ---------------------------------------------------------------- tracking queue head
  input  wire logic                              trk_empty_i,
  output logic                                   trk_pop_o,
  input  wire logic [N-1:0]                      trk_act_i,
  input  wire logic                              trk_last_i,
  input  wire logic                              trk_nobeat_i,
  input  wire logic                              trk_ill_i,
  input  wire logic                              trk_red_i,
  input  wire logic [2:0]                        trk_rm_i,
  input  wire logic [TID_W-1:0]                  trk_tid_i,
  input  wire logic [31:0]                       trk_scalar_i,
  // ---------------------------------------------------------------- lanes
  input  wire logic [N-1:0]                      ln_ovalid_i,
  output logic [N-1:0]                           ln_oready_o,
  input  wire logic [N*32-1:0]                   ln_result_i,
  input  wire logic [N*5-1:0]                    ln_flags_i,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [N*LTAG_W-1:0]               ln_tag_i,      // simulation check only
  input  wire logic [N-1:0]                      ln_illegal_i,  // simulation check only
  /* verilator lint_on UNUSEDSIGNAL */
  // ---------------------------------------------------------------- result stream
  output logic                                   res_valid_o,
  input  wire logic                              res_ready_i,
  output logic [N*32-1:0]                        res_data_o,
  output logic [N*5-1:0]                         res_flags_o,
  output logic [N-1:0]                           res_mask_o,
  output logic [TID_W-1:0]                       res_tid_o,
  output logic [VL_W-1:0]                        res_beat_o,
  output logic                                   res_last_o,
  output logic                                   res_lastpend_o,  // res_valid & res_last
  output logic [LBS_W-1:0]                       res_lbseq_o,
  // ---------------------------------------------------------------- items (to reduction / completion)
  output logic                                   it_valid_o,
  input  wire logic                              it_ready_i,
  output logic                                   it_grp_o,        // 1 GROUP, 0 TOKEN
  output logic [N*32-1:0]                        it_vals_o,
  output logic [N-1:0]                           it_act_o,
  output logic [4:0]                             it_flags_o,
  output logic [VL_W-1:0]                        it_count_o,
  output logic                                   it_first_o,
  output logic                                   it_last_o,
  output logic [2:0]                             it_rm_o,
  output logic [31:0]                            it_init_o,
  output logic [TID_W-1:0]                       it_tid_o,
  output logic                                   it_ill_o,
  output logic                                   it_wait_o,
  output logic [LBS_W-1:0]                       it_lbseq_o,
  // ---------------------------------------------------------------- events
  output logic                                   ev_res_bp_o,
  output logic                                   ev_coll_wait_o,
  output logic                                   ev_red_wait_o,
  output logic [$clog2(N+1)-1:0]                 ev_elem_o
);
  localparam int PCW = $clog2(N + 1);

  function automatic logic [PCW-1:0] popcnt(input logic [N-1:0] v);
    popcnt = '0;
    for (int i = 0; i < N; i++) popcnt = popcnt + PCW'(v[i]);
  endfunction

  // ===================================================================
  // Head-beat evaluation
  // ===================================================================
  logic             res_valid_q;
  logic [N*32-1:0]  res_data_q;
  logic [N*5-1:0]   res_flags_q;
  logic [N-1:0]     res_mask_q;
  logic [TID_W-1:0] res_tid_q;
  logic [VL_W-1:0]  res_beat_q;
  logic             res_last_q;
  logic [LBS_W-1:0] res_lbseq_q;

  logic             cfirst_q;           // next head entry starts a command
  logic [4:0]       cflags_q;           // flags of the command so far
  logic [VL_W-1:0]  ccount_q;           // active elements of the command so far
  logic [VL_W-1:0]  cbeat_q;            // beat index within the command
  logic [LTAG_W-1:0] ctag_q;            // expected lane tag of the head beat
  logic [LBS_W-1:0] lbs_q;              // last-beat sequence number

  wire logic h_v    = ~trk_empty_i;
  wire logic h_beat = ~trk_nobeat_i;

  // lane results of the head beat: masked by the active vector
  logic [N*32-1:0] hv_vals;
  logic [N*5-1:0]  hv_flags;
  logic [4:0]      beat_flags;
  always_comb begin
    beat_flags = '0;
    for (int l = 0; l < N; l++) begin
      hv_vals [l*32 +: 32] = trk_act_i[l] ? ln_result_i[l*32 +: 32] : 32'd0;
      hv_flags[l*5  +: 5]  = trk_act_i[l] ? ln_flags_i [l*5  +: 5]  : 5'd0;
      beat_flags           = beat_flags | hv_flags[l*5 +: 5];
    end
  end
  wire logic [PCW-1:0] beat_cnt = popcnt(trk_act_i);

  wire logic lanes_rdy = &(~trk_act_i | ln_ovalid_i);
  wire logic res_free  = ~res_valid_q | res_ready_i;

  wire logic need_lanes = h_beat;
  wire logic need_res   = h_beat & ~trk_red_i;
  wire logic want_item  = trk_nobeat_i | trk_red_i | trk_last_i;

  wire logic pre  = h_v & (~need_lanes | lanes_rdy) & (~need_res | res_free);
  assign it_valid_o = pre & want_item;
  wire logic fire = pre & (~want_item | it_ready_i);

  assign trk_pop_o   = fire;
  assign ln_oready_o = {N{fire & h_beat}} & trk_act_i;

  wire logic res_load = fire & need_res;

  // ===================================================================
  // Item stream
  // ===================================================================
  wire logic elem_tok = ~trk_red_i;     // elementwise -> TOKEN item
  assign it_grp_o   = trk_red_i;
  assign it_vals_o  = hv_vals;
  assign it_act_o   = h_beat ? trk_act_i : '0;
  assign it_flags_o = trk_red_i ? beat_flags
                                : (h_beat ? (cflags_q | beat_flags) : 5'd0);
  assign it_count_o = trk_red_i ? (h_beat ? VL_W'(beat_cnt) : '0)
                                : (h_beat ? (ccount_q + VL_W'(beat_cnt)) : '0);
  assign it_first_o = cfirst_q;
  assign it_last_o  = trk_last_i;
  assign it_rm_o    = trk_rm_i;
  assign it_init_o  = trk_scalar_i;
  assign it_tid_o   = trk_tid_i;
  assign it_ill_o   = trk_ill_i;
  assign it_wait_o  = elem_tok & h_beat;    // completion waits for its last beat
  assign it_lbseq_o = lbs_q;

  // ===================================================================
  // State
  // ===================================================================
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      res_valid_q <= 1'b0;
      cfirst_q    <= 1'b1;
      cflags_q    <= '0;
      ccount_q    <= '0;
      cbeat_q     <= '0;
      ctag_q      <= '0;
      lbs_q       <= '0;
    end else begin
      if (res_load)                       res_valid_q <= 1'b1;
      else if (res_valid_q && res_ready_i) res_valid_q <= 1'b0;
      if (fire) begin
        if (trk_last_i) begin             // also every vl = 0 entry
          cfirst_q <= 1'b1;
          cflags_q <= '0;
          ccount_q <= '0;
          cbeat_q  <= '0;
        end else begin
          cfirst_q <= 1'b0;
          cflags_q <= cflags_q | beat_flags;
          ccount_q <= ccount_q + VL_W'(beat_cnt);
          cbeat_q  <= cbeat_q + VL_W'(1);
        end
        if (h_beat) ctag_q <= ctag_q + LTAG_W'(1);
        if (h_beat && elem_tok && trk_last_i) lbs_q <= lbs_q + LBS_W'(1);
      end
    end
  end

  always_ff @(posedge clk_i) begin           // datapath, qualified by res_valid_q
    if (res_load) begin
      res_data_q  <= hv_vals;
      res_flags_q <= hv_flags;
      res_mask_q  <= trk_act_i;
      res_tid_q   <= trk_tid_i;
      res_beat_q  <= cbeat_q;
      res_last_q  <= trk_last_i;
      res_lbseq_q <= lbs_q;
    end
  end

  assign res_valid_o    = res_valid_q;
  assign res_data_o     = res_valid_q ? res_data_q  : '0;
  assign res_flags_o    = res_valid_q ? res_flags_q : '0;
  assign res_mask_o     = res_valid_q ? res_mask_q  : '0;
  assign res_tid_o      = res_valid_q ? res_tid_q   : '0;
  assign res_beat_o     = res_valid_q ? res_beat_q  : '0;
  assign res_last_o     = res_valid_q & res_last_q;
  assign res_lastpend_o = res_valid_q & res_last_q;
  assign res_lbseq_o    = res_lbseq_q;

  // ===================================================================
  // Events
  // ===================================================================
  assign ev_res_bp_o    = res_valid_q & ~res_ready_i;
  assign ev_coll_wait_o = h_v & need_lanes & ~lanes_rdy;
  assign ev_red_wait_o  = it_valid_o & ~it_ready_i;
  assign ev_elem_o      = (fire & h_beat) ? beat_cnt : '0;

  // ===================================================================
  // Simulation-only association checks
  // ===================================================================
`ifndef SYNTHESIS
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
    end else if (fire && h_beat) begin
      for (int l = 0; l < N; l++) begin
        if (trk_act_i[l] && (ln_tag_i[l*LTAG_W +: LTAG_W] != ctag_q))
          $fatal(1, "hpc_varray_collect: lane %0d result tag %0d, expected beat %0d",
                 l, ln_tag_i[l*LTAG_W +: LTAG_W], ctag_q);
        if (trk_act_i[l] && ln_illegal_i[l])
          $fatal(1, "hpc_varray_collect: lane %0d returned an illegal operation", l);
      end
    end
  end
`endif
endmodule
