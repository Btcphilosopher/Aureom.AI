// =============================================================================
// SilicaFlux-HPC Module 05 :: hpc_dma_spm_port
// Protocol adapter: SFB2 slave (DataFabric bus, PROTOCOL.md) -> one requester
// port of the Module 04 banked scratchpad (hpc_scratchpad, doc 01 sec. 3-4).
//
//   SFB2 (from hpc_dma_route)                hpc_scratchpad port
//   req_valid/req_ready   ---------------->  req_valid/req_ready   (wires)
//   req_write/addr/wdata/wstrb ----------->  req_we/addr/wdata/wstrb
//                         seq_q, write --->  req_tag = {write, seq}
//   rsp_valid/rsp_ready   <----------------  rsp_valid/rsp_ready   (wires)
//   rsp_rdata, rsp_error  <-- tag check ---  rsp_rdata/err/err_code/we/tag
//
// Why the two protocols compose without a buffer (all rules cited):
//   * request: both are valid/ready with "hold until accepted" (SFB2 R2 /
//     SPM H2).  The scratchpad's req_ready may depend combinationally on
//     req_valid/addr (SPM H3), which SFB2 R3 allows; it never depends on
//     rsp_ready, so SFB2 R4 holds.
//   * response: exactly one per request in acceptance order (SPM H5 with
//     WRITE_ACK = 1 = SFB2 R5); never in the acceptance cycle (READ_LATENCY
//     >= 1); held stable under back-pressure (SPM H4 = SFB2 R4); rdata = 0
//     for writes and errors (SFB2 R8).
//   * write completion: the scratchpad acknowledges a write only after the
//     array was written at its issue edge (doc 01 sec. 5), i.e. SFB2 R7.
//     The scratchpad MUST therefore be built with WRITE_ACK = 1 (posted
//     writes would break the one-response-per-request rule and would let the
//     DMA report completion before the data is in the array).
//   * alignment: SFB2 R9 requires DW-aligned addresses, the scratchpad
//     rejects unaligned ones with ALIGN (error response, no side effect).
//
// Response ownership check: the scratchpad echoes the request tag.  The
// adapter numbers its requests (seq_q, mod 2^(SPM_TAG_W-1)) and records the
// direction in the tag's MSB, then checks every response against the
// expected {write, seq} and rsp_we.  A mismatch (misrouted, duplicated,
// dropped or reordered response) is turned into rsp_error = 1 with
// rsp_rdata = 0 -- the DMA engine then stops with READ_BUS / WRITE_BUS
// instead of writing wrong data -- and pulses ev_tag_err.  The tag space must
// exceed the number of outstanding requests (elaboration check).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_dma_defs.svh"
`default_nettype none

module hpc_dma_spm_port #(
  parameter int DW        = 32,
  parameter int AW        = 32,
  parameter int SPM_TAG_W = 8,          // hpc_scratchpad TAG_W
  parameter int MAX_OUT   = 1,          // requests this port can have outstanding
  localparam int SB       = DW / 8,
  localparam int SQW      = SPM_TAG_W - 1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---------------------------------------------------------- SFB2 slave side
  input  wire logic                 req_valid,
  output logic                      req_ready,
  input  wire logic                 req_write,
  input  wire logic [AW-1:0]        req_addr,
  input  wire logic [DW-1:0]        req_wdata,
  input  wire logic [SB-1:0]        req_wstrb,
  output logic                      rsp_valid,
  input  wire logic                 rsp_ready,
  output logic [DW-1:0]             rsp_rdata,
  output logic                      rsp_error,
  // ---------------------------------------------------------- scratchpad port (master side)
  output logic                      spm_req_valid,
  input  wire logic                 spm_req_ready,
  output logic                      spm_req_we,
  output logic [AW-1:0]             spm_req_addr,
  output logic [DW-1:0]             spm_req_wdata,
  output logic [SB-1:0]             spm_req_wstrb,
  output logic [SPM_TAG_W-1:0]      spm_req_tag,
  input  wire logic                 spm_rsp_valid,
  output logic                      spm_rsp_ready,
  input  wire logic [DW-1:0]        spm_rsp_rdata,
  input  wire logic                 spm_rsp_err,
  input  wire logic [2:0]           spm_rsp_err_code,
  input  wire logic                 spm_rsp_we,
  input  wire logic [SPM_TAG_W-1:0] spm_rsp_tag,
  // ---------------------------------------------------------- events
  output logic                      ev_tag_err,     // response failed the ownership check (this cycle)
  output logic                      ev_spm_err,     // scratchpad reported an error code (this cycle)
  output logic [2:0]                spm_err_code    // code of that response (0 otherwise)
);
  if (SPM_TAG_W < 2 || SPM_TAG_W > 32) begin : g_err_spm_tag_w
    `SRAM_CFG_FATAL("hpc_dma_spm_port: SPM_TAG_W must be 2..32")
  end
  if (SQW < 31 && (64'd1 << SQW) <= 64'(MAX_OUT)) begin : g_err_tag_space
    `SRAM_CFG_FATAL("hpc_dma_spm_port: 2^(SPM_TAG_W-1) must exceed MAX_OUT (tag sequence would alias)")
  end

  logic [SQW-1:0] iss_seq_q, rsp_seq_q;

  // ---------------------------------------------------------- request: wires + tag
  assign spm_req_valid = req_valid;
  assign req_ready     = spm_req_ready;
  assign spm_req_we    = req_write;
  assign spm_req_addr  = req_addr;
  assign spm_req_wdata = req_wdata;
  assign spm_req_wstrb = req_wstrb;
  assign spm_req_tag   = {req_write, iss_seq_q};

  // ---------------------------------------------------------- response: wires + ownership check
  wire tag_bad = spm_rsp_valid &&
                 ((spm_rsp_tag[SQW-1:0] != rsp_seq_q) || (spm_rsp_tag[SPM_TAG_W-1] != spm_rsp_we));
  assign rsp_valid     = spm_rsp_valid;
  assign spm_rsp_ready = rsp_ready;
  assign rsp_error     = spm_rsp_err || tag_bad;
  assign rsp_rdata     = (spm_rsp_err || tag_bad) ? '0 : spm_rsp_rdata;
  assign ev_tag_err    = tag_bad && rsp_ready;
  assign ev_spm_err    = spm_rsp_valid && rsp_ready && spm_rsp_err;
  assign spm_err_code  = (spm_rsp_valid && spm_rsp_err) ? spm_rsp_err_code : 3'd0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      iss_seq_q <= '0;
      rsp_seq_q <= '0;
    end else begin
      if (req_valid && spm_req_ready)  iss_seq_q <= iss_seq_q + 1'b1;
      if (spm_rsp_valid && rsp_ready)  rsp_seq_q <= rsp_seq_q + 1'b1;
    end
  end
endmodule

`default_nettype wire
