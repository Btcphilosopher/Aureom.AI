// =============================================================================
// SilicaFlux-HPC :: hpc_lzc -- log-depth leading-zero counter
//
//   cnt_o = number of leading (MSB-side) zeros of x_i;  cnt_o = W if x_i == 0.
//
// The input is padded on the LSB side with a single 1 (and zeros) up to
// P = 2^ceil(log2(W+1)) bits, so the all-zero case needs no special logic.
// A binary tree of (valid, count) nodes combines halves in ceil(log2(W+1))
// 2:1-mux levels:
//     count(node) = valid(hi) ? count(hi) : 2^level + count(lo)
// (the add is an OR because count(lo) < 2^level).  Combinational.
// =============================================================================
`default_nettype none

module hpc_lzc #(
  parameter int W = 24
) (
  input  wire logic [W-1:0]             x_i,
  output logic [$clog2(W+1)-1:0]        cnt_o
);
  localparam int CW = $clog2(W + 1);
  localparam int P  = 1 << CW;            // P >= W + 1

  function automatic logic [CW-1:0] tree(input logic [P-1:0] x);
    logic [P-1:0]    v;                   // node "contains a one"
    logic [P*CW-1:0] c;                   // node leading-zero count
    logic            vh, vl;
    logic [CW-1:0]   ch, cl;
    v = x;
    c = '0;
    // In-place reduction: at level l node n reads children 2n+1 (MSB half)
    // and 2n (LSB half) before index n is overwritten (2n >= n).
    for (int l = 0; l < CW; l++) begin
      for (int n = 0; n < (P >> (l + 1)); n++) begin
        vh = v[2*n+1];
        vl = v[2*n];
        ch = c[(2*n+1)*CW +: CW];
        cl = c[(2*n)*CW +: CW];
        v[n] = vh | vl;
        c[n*CW +: CW] = vh ? ch : (cl | CW'(1 << l));
      end
    end
    tree = c[CW-1:0];
  endfunction

  wire logic [P-1:0] xp = (P'(x_i) << (P - W)) | (P'(1) << (P - W - 1));
  assign cnt_o = tree(xp);
endmodule
