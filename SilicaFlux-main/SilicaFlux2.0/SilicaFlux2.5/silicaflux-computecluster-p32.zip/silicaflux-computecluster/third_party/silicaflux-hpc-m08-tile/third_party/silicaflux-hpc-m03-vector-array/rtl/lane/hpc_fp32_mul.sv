// =============================================================================
// SilicaFlux-HPC :: hpc_fp32_mul -- pipelined IEEE-754 binary32 multiplier
//
//   res = round(a * b)      all five rounding modes, full subnormal support,
//   IEEE 754-2019 / RISC-V exception flags, canonical NaN.
//
// Dedicated datapath (not derived from the FMA).  Two combinational segments:
//   A  unpack, special cases, 24x24 significand product (exact, 48 bits)
//   B  leading-zero count (subnormal operands), normalize (B1) | round (B2)
// The 48-bit product is exact, so rounding needs only the top 24 bits, the
// next bit (guard) and the OR of the rest (sticky).
//
// Latency LAT >= 2: one register between A and B.  LAT >= 3 (default) splits
// B into B1 (normalize) | B2 (round); further stages are output registers
// (retiming slack).
// =============================================================================
`default_nettype none

module hpc_fp32_mul #(
  parameter int LAT = 3,
  parameter int IDW = 3
) (
  input  wire logic           clk_i,
  input  wire logic           rst_ni,
  input  wire logic           valid_i,
  input  wire logic [IDW-1:0] id_i,
  input  wire logic [31:0]    a_i,
  input  wire logic [31:0]    b_i,
  input  wire logic [2:0]     rm_i,
  output logic                valid_o,
  output logic [IDW-1:0]      id_o,
  output logic [31:0]         res_o,
  output logic [4:0]          flags_o
);
  if (LAT < hpc_vector_pkg::MIN_LAT_FMUL) begin : g_bad_lat
    hpc_param_error_LAT_FMUL_below_minimum u_err ();
  end

  // =========================================================== segment A
  wire logic sp = a_i[31] ^ b_i[31];

  wire logic a_nan  = hpc_vector_pkg::fp_is_nan(a_i);
  wire logic b_nan  = hpc_vector_pkg::fp_is_nan(b_i);
  wire logic a_inf  = hpc_vector_pkg::fp_is_inf(a_i);
  wire logic b_inf  = hpc_vector_pkg::fp_is_inf(b_i);
  wire logic a_zero = hpc_vector_pkg::fp_is_zero(a_i);
  wire logic b_zero = hpc_vector_pkg::fp_is_zero(b_i);
  wire logic any_snan = hpc_vector_pkg::fp_is_snan(a_i) | hpc_vector_pkg::fp_is_snan(b_i);

  logic        spec, spec_nv;
  logic [31:0] spec_res;
  always_comb begin
    spec = 1'b1; spec_nv = 1'b0; spec_res = hpc_vector_pkg::FP32_QNAN;
    if (a_nan | b_nan) begin
      spec_nv = any_snan;
    end else if ((a_inf & b_zero) | (a_zero & b_inf)) begin
      spec_nv = 1'b1;                                            // 0 * inf
    end else if (a_inf | b_inf) begin
      spec_res = {sp, hpc_vector_pkg::FP32_INF_M};
    end else if (a_zero | b_zero) begin
      spec_res = {sp, 31'd0};                                    // exact zero
    end else begin
      spec = 1'b0;
    end
  end

  wire logic [23:0] siga = hpc_vector_pkg::fp_sig(a_i);
  wire logic [23:0] sigb = hpc_vector_pkg::fp_sig(b_i);
  wire logic [7:0]  ea   = hpc_vector_pkg::fp_exp(a_i);
  wire logic [7:0]  eb   = hpc_vector_pkg::fp_exp(b_i);
  wire logic [47:0] prod = siga * sigb;
  // biased exponent of the product if its leading one were at bit 47
  wire logic [11:0] e0 = {4'd0, ea} + {4'd0, eb} - 12'd126;

  // ------------------------------------------------- register A -> B
  localparam int WA = IDW + 1 + 1 + 32 + 48 + 12 + 1 + 3;
  logic          v_b;
  logic [WA-1:0] d_b;
  hpc_pipe #(.W(WA), .N(1)) u_pa (
    .clk_i, .rst_ni, .valid_i(valid_i),
    .data_i({id_i, spec, spec_nv, spec_res, prod, e0, sp, rm_i}),
    .valid_o(v_b), .data_o(d_b));

  logic [IDW-1:0] id_b;
  logic           spec_b, spec_nv_b, sp_b;
  logic [31:0]    spec_res_b;
  logic [47:0]    prod_b;
  logic [11:0]    e0_b;
  logic [2:0]     rm_b;
  assign {id_b, spec_b, spec_nv_b, spec_res_b, prod_b, e0_b, sp_b, rm_b} = d_b;

  // ===================================================== segment B1: normalize
  logic [5:0] lz;
  hpc_lzc #(.W(48)) u_lzc (.x_i(prod_b), .cnt_o(lz));
  wire logic [47:0] norm = prod_b << lz;
  wire logic [11:0] e_n  = e0_b - {6'd0, lz};

  // ------------------------------------------------- optional split register
  // The first latency stage beyond the minimum cuts normalize | round.
  localparam int SPLIT = (LAT > hpc_vector_pkg::MIN_LAT_FMUL) ? 1 : 0;
  localparam int WN = IDW + 1 + 1 + 32 + 1 + 12 + 24 + 1 + 1 + 3;
  logic          v_r;
  logic [WN-1:0] d_r;
  hpc_pipe #(.W(WN), .N(SPLIT)) u_pn (
    .clk_i, .rst_ni, .valid_i(v_b),
    .data_i({id_b, spec_b, spec_nv_b, spec_res_b, sp_b, e_n, norm[47:24], norm[23],
             |norm[22:0], rm_b}),
    .valid_o(v_r), .data_o(d_r));

  logic [IDW-1:0] id_r;
  logic           spec_r, spec_nv_r, sign_r, g_r, st_r;
  logic [31:0]    spec_res_r;
  logic [11:0]    e_r;
  logic [23:0]    sig_r;
  logic [2:0]     rm_r;
  assign {id_r, spec_r, spec_nv_r, spec_res_r, sign_r, e_r, sig_r, g_r, st_r, rm_r} = d_r;

  // ===================================================== segment B2: round
  logic [31:0] r_res;
  logic        r_of, r_uf, r_nx;
  hpc_fp32_round #(.EW(12)) u_round (
    .sign_i(sign_r), .exp_i(e_r), .sig_i(sig_r), .guard_i(g_r), .sticky_i(st_r),
    .rm_i(rm_r), .res_o(r_res), .of_o(r_of), .uf_o(r_uf), .nx_o(r_nx));

  wire logic [31:0] res_r   = spec_r ? spec_res_r : r_res;
  wire logic [4:0]  flags_r = spec_r ? {spec_nv_r, 4'b0000} : {2'b00, r_of, r_uf, r_nx};

  // ------------------------------------------------- output stages
  hpc_pipe #(.W(IDW + 37), .N(LAT - hpc_vector_pkg::MIN_LAT_FMUL - SPLIT)) u_po (
    .clk_i, .rst_ni, .valid_i(v_r), .data_i({id_r, res_r, flags_r}),
    .valid_o(valid_o), .data_o({id_o, res_o, flags_o}));
endmodule
