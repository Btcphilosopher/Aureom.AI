// =============================================================================
// SilicaFlux-HPC :: hpc_pipe -- N-stage valid/data delay line (N >= 0)
//
// Non-stallable pipeline register chain used inside the execution units.  The
// lane guarantees a completion slot for every operation before it is issued,
// so execution pipelines never need to stall (docs/MICROARCHITECTURE.md).
//
//   * valid bits are control state: asynchronously reset to 0;
//   * data registers are datapath state qualified by valid: not reset, loaded
//     only when the incoming stage is valid (acts as a clock enable, so idle
//     pipelines do not toggle).
//   * N = 0 is a pure wire.
// =============================================================================
`default_nettype none

module hpc_pipe #(
  parameter int W = 1,
  parameter int N = 1
) (
  input  wire logic         clk_i,
  input  wire logic         rst_ni,
  input  wire logic         valid_i,
  input  wire logic [W-1:0] data_i,
  output logic              valid_o,
  output logic [W-1:0]      data_o
);
  if (N == 0) begin : g_wire
    assign valid_o = valid_i;
    assign data_o  = data_i;
    // clk_i / rst_ni intentionally unused in this configuration
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_ok = clk_i ^ rst_ni;
    /* verilator lint_on UNUSEDSIGNAL */
  end else begin : g_regs
    logic [N-1:0]     v_q;
    logic [N*W-1:0]   d_q;
    wire  [N:0]       v_all = {v_q, valid_i};
    wire  [(N+1)*W-1:0] d_all = {d_q, data_i};

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) v_q <= '0;
      else         v_q <= v_all[N-1:0];
    end

    always_ff @(posedge clk_i) begin
      for (int i = 0; i < N; i++)
        if (v_all[i]) d_q[i*W +: W] <= d_all[i*W +: W];
    end

    assign valid_o = v_q[N-1];
    assign data_o  = d_q[(N-1)*W +: W];
  end
endmodule
