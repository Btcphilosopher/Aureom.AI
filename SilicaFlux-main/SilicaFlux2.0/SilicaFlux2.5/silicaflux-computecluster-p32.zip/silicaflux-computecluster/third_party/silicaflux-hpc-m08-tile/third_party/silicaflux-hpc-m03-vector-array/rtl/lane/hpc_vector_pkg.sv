// =============================================================================
// SilicaFlux-HPC :: hpc_vector_pkg -- shared encodings for the vector lane
//
// Stateless package: operation encodings, rounding-mode and exception-flag
// encodings, unit identifiers and side-effect-free helper functions shared by
// hpc_vector_lane and its execution units.
//
// Encodings follow the SilicaFlux architectural package (silicaflux_pkg.sf,
// section 7) wherever one exists:
//   * rounding modes   = silicaflux_pkg::fp_rm_e   (RISC-V frm encoding)
//   * exception flags  = silicaflux_pkg::fflags_t  ({NV,DZ,OF,UF,NX}, RISC-V
//                        fflags bit order)
//   * NaN results      = RISC-V canonical quiet NaN 0x7FC0_0000
//
// Coding rules: SilicaFlux RTL subset (Verilator 5.020 / Icarus 12 /
// Yosys 0.33): no `import`, no `return`, no `inside`, no structs, functions
// assign to their own name.
// =============================================================================
`default_nettype none

package hpc_vector_pkg;

  // ---------------------------------------------------------------------------
  // Operation encodings (in_op_i).  Values are frozen once published; new
  // operations may only take currently-illegal code points.
  // ---------------------------------------------------------------------------
  localparam int OP_W = 5;

  localparam logic [OP_W-1:0] OP_FMV    = 5'h00; // result = a (bit-exact move)
  localparam logic [OP_W-1:0] OP_FADD   = 5'h01; // a + b
  localparam logic [OP_W-1:0] OP_FSUB   = 5'h02; // a - b
  localparam logic [OP_W-1:0] OP_FMUL   = 5'h03; // a * b
  localparam logic [OP_W-1:0] OP_FMADD  = 5'h04; //  (a*b) + c   (single rounding)
  localparam logic [OP_W-1:0] OP_FMSUB  = 5'h05; //  (a*b) - c
  localparam logic [OP_W-1:0] OP_FNMSUB = 5'h06; // -(a*b) + c
  localparam logic [OP_W-1:0] OP_FNMADD = 5'h07; // -(a*b) - c
  localparam logic [OP_W-1:0] OP_FMIN   = 5'h08; // minimumNumber(a, b)  [EN_FCMP]
  localparam logic [OP_W-1:0] OP_FMAX   = 5'h09; // maximumNumber(a, b)  [EN_FCMP]
  localparam logic [OP_W-1:0] OP_FEQ    = 5'h0A; // a == b (quiet)       [EN_FCMP]
  localparam logic [OP_W-1:0] OP_FLT    = 5'h0B; // a <  b (signaling)   [EN_FCMP]
  localparam logic [OP_W-1:0] OP_FLE    = 5'h0C; // a <= b (signaling)   [EN_FCMP]
  //                                    5'h0D .. 5'h0F reserved (illegal)
  localparam logic [OP_W-1:0] OP_IADD   = 5'h10; // a + b mod 2^32        [EN_INT]
  localparam logic [OP_W-1:0] OP_IMUL   = 5'h11; // (a * b) mod 2^32      [EN_INT]
  //                                    5'h12 .. 5'h1F reserved (illegal)

  // ---------------------------------------------------------------------------
  // Rounding modes (in_rm_i) -- silicaflux_pkg::fp_rm_e.  RM_DYN (3'b111) must
  // be resolved by the issuing core; 3'b101..3'b111 are illegal for operations
  // that round (FADD/FSUB/FMUL/FMA family) and ignored by all others.
  // ---------------------------------------------------------------------------
  localparam logic [2:0] RM_RNE = 3'b000; // nearest, ties to even
  localparam logic [2:0] RM_RTZ = 3'b001; // toward zero
  localparam logic [2:0] RM_RDN = 3'b010; // toward -inf
  localparam logic [2:0] RM_RUP = 3'b011; // toward +inf
  localparam logic [2:0] RM_RMM = 3'b100; // nearest, ties away from zero

  // ---------------------------------------------------------------------------
  // Exception flags (out_flags_o) -- silicaflux_pkg::fflags_t bit order.
  // DZ is never raised by this lane (no division) but keeps its position.
  // ---------------------------------------------------------------------------
  localparam int FLAGS_W = 5;
  /* verilator lint_off UNUSEDPARAM */
  localparam int FLAG_NV = 4;  // invalid operation
  localparam int FLAG_DZ = 3;  // divide by zero (never set)
  localparam int FLAG_OF = 2;  // overflow
  localparam int FLAG_UF = 1;  // underflow (tiny after rounding AND inexact)
  localparam int FLAG_NX = 0;  // inexact
  /* verilator lint_on UNUSEDPARAM */

  // ---------------------------------------------------------------------------
  // FP32 constants
  // ---------------------------------------------------------------------------
  localparam logic [31:0] FP32_QNAN   = 32'h7FC0_0000; // canonical quiet NaN
  localparam logic [30:0] FP32_INF_M  = 31'h7F80_0000; // |inf|
  localparam logic [30:0] FP32_MAX_M  = 31'h7F7F_FFFF; // |largest finite|

  // ---------------------------------------------------------------------------
  // Execution units (one-hot index into the lane's dispatch vector)
  // ---------------------------------------------------------------------------
  localparam int N_UNITS = 5;
  localparam int U_FADD  = 0;  // FADD, FSUB
  localparam int U_FMUL  = 1;  // FMUL
  localparam int U_FMA   = 2;  // FMADD, FMSUB, FNMSUB, FNMADD
  localparam int U_MISC  = 3;  // FMV, FMIN, FMAX, FEQ, FLT, FLE, IADD
  localparam int U_IMUL  = 4;  // IMUL

  // MISC-unit sub-operations
  localparam int MOP_W = 3;
  localparam logic [MOP_W-1:0] MOP_FMV  = 3'd0;
  localparam logic [MOP_W-1:0] MOP_FMIN = 3'd1;
  localparam logic [MOP_W-1:0] MOP_FMAX = 3'd2;
  localparam logic [MOP_W-1:0] MOP_FEQ  = 3'd3;
  localparam logic [MOP_W-1:0] MOP_FLT  = 3'd4;
  localparam logic [MOP_W-1:0] MOP_FLE  = 3'd5;
  localparam logic [MOP_W-1:0] MOP_IADD = 3'd6;

  // Minimum legal pipeline latencies (register stages from the issue
  // register to the completion write, see docs/MICROARCHITECTURE.md).
  localparam int MIN_LAT_FADD = 2;
  localparam int MIN_LAT_FMUL = 2;
  localparam int MIN_LAT_FMA  = 3;
  localparam int MIN_LAT_MISC = 1;
  localparam int MIN_LAT_IMUL = 1;

  // ---------------------------------------------------------------------------
  // Helper functions (pure)
  // ---------------------------------------------------------------------------

  // Rounding mode is one of the five architected modes.
  function automatic logic rm_legal(input logic [2:0] rm);
    rm_legal = (rm == RM_RNE) || (rm == RM_RTZ) || (rm == RM_RDN) ||
               (rm == RM_RUP) || (rm == RM_RMM);
  endfunction

  // Round-increment decision for a magnitude with least-significant kept bit
  // `lsb`, first discarded bit `g` and OR of all further discarded bits `s`.
  function automatic logic round_inc(input logic [2:0] rm, input logic sign,
                                     input logic lsb, input logic g,
                                     input logic s);
    case (rm)
      RM_RNE:  round_inc = g & (s | lsb);
      RM_RTZ:  round_inc = 1'b0;
      RM_RDN:  round_inc = sign & (g | s);
      RM_RUP:  round_inc = ~sign & (g | s);
      RM_RMM:  round_inc = g;
      default: round_inc = 1'b0;
    endcase
  endfunction

  // Field extraction / classification of an FP32 encoding (sign ignored).
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic fp_is_zero(input logic [31:0] x);
    fp_is_zero = (x[30:23] == 8'h00) && (x[22:0] == 23'd0);
  endfunction
  function automatic logic fp_is_inf(input logic [31:0] x);
    fp_is_inf = (x[30:23] == 8'hFF) && (x[22:0] == 23'd0);
  endfunction
  function automatic logic fp_is_nan(input logic [31:0] x);
    fp_is_nan = (x[30:23] == 8'hFF) && (x[22:0] != 23'd0);
  endfunction
  function automatic logic fp_is_snan(input logic [31:0] x);
    fp_is_snan = (x[30:23] == 8'hFF) && (x[22:0] != 23'd0) && !x[22];
  endfunction
  // Significand with hidden bit (subnormals: hidden bit 0).
  function automatic logic [23:0] fp_sig(input logic [31:0] x);
    fp_sig = {(x[30:23] != 8'h00), x[22:0]};
  endfunction
  // Effective biased exponent (subnormals and zero use 1).
  function automatic logic [7:0] fp_exp(input logic [31:0] x);
    fp_exp = (x[30:23] == 8'h00) ? 8'd1 : x[30:23];
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */

endpackage
