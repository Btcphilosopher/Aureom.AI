// =============================================================================
// SilicaFlux-HPC :: hpc_varray_issue -- vector issue controller
//
// Accepts vector commands (valid/ready) into a command queue, sequences each
// command into ceil(vl / N) operand beats, and distributes every beat's
// elements across the N lanes.
//
//   element e of a command  ->  beat g = e / N,  lane l = e % N
//   active(e) = (e < vl) & (vm == 0 | mask_g[l]) & command legal
//
// Responsibilities (docs/MICROARCHITECTURE.md section 3)
//   * distribute work:   one beat = N elements, one element per lane;
//   * apply masks:       tail lanes (e >= vl) are not offered anything;
//                        mask-inactive lanes are sent the operation with
//                        lane_en = 0 (consumed by the lane, no slot, no
//                        result -- Module 02 contract);
//   * per-lane issue:    lanes take their element independently; a lane that
//                        is not ready (completion buffer full, or held) is
//                        retried while the other lanes' acceptance is
//                        remembered (acc_q).  The beat is released upstream
//                        only when every live lane has taken its element, so
//                        NO lane is assumed to be ready;
//   * track accepted work: one entry per beat (active mask, last-beat flag,
//                        command info) is pushed to the tracking queue that
//                        the collector consumes in order; commands with
//                        vl = 0 push a single beat-less entry;
//   * backpressure:      opnd_ready_o is low while any live lane cannot take
//                        its element or the tracking queue is full;
//   * ordering:          commands are started strictly in acceptance order and
//                        beats in element order; each lane is in-order.
//
// Interface timing: cmd_ready_o and opnd_ready_o are functions of registered
// state only (lane in_ready, the registered hold vector, queue counts, the
// current-command registers).  Lane valid outputs depend combinationally on
// opnd_valid_i (allowed: the lane's in_ready does not depend on in_valid).
// =============================================================================
`default_nettype none

module hpc_varray_issue #(
  parameter int N         = 2,     // lanes
  parameter int VL_W      = 16,    // vector-length width
  parameter int TID_W     = 8,     // transaction-id width
  parameter int CMD_DEPTH = 4,     // command queue entries
  parameter int LTAG_W    = 4,     // lane tag width (beat sequence number)
  parameter bit EN_FCMP   = 1'b1,
  parameter bit EN_INT    = 1'b1,
  parameter bit RED_EN    = 1'b1
) (
  input  wire logic                              clk_i,
  input  wire logic                              rst_ni,
  // ---------------------------------------------------------------- commands
  input  wire logic                              cmd_valid_i,
  output logic                                   cmd_ready_o,
  input  wire logic [hpc_vector_pkg::OP_W-1:0]   cmd_op_i,
  input  wire logic [2:0]                        cmd_rm_i,
  input  wire logic [VL_W-1:0]                   cmd_vl_i,
  input  wire logic                              cmd_vm_i,
  input  wire logic [hpc_varray_pkg::BC_W-1:0]   cmd_bcast_i,
  input  wire logic [31:0]                       cmd_scalar_i,
  input  wire logic                              cmd_red_i,
  input  wire logic [TID_W-1:0]                  cmd_tid_i,
  // ---------------------------------------------------------------- operands
  input  wire logic                              opnd_valid_i,
  output logic                                   opnd_ready_o,
  input  wire logic [N*32-1:0]                   opnd_a_i,
  input  wire logic [N*32-1:0]                   opnd_b_i,
  input  wire logic [N*32-1:0]                   opnd_c_i,
  input  wire logic [N-1:0]                      opnd_mask_i,
  // ---------------------------------------------------------------- lane hold
  input  wire logic [N-1:0]                      lane_hold_i,
  // ---------------------------------------------------------------- lanes
  output logic [N-1:0]                           ln_valid_o,
  input  wire logic [N-1:0]                      ln_ready_i,
  output logic [hpc_vector_pkg::OP_W-1:0]        ln_op_o,
  output logic [2:0]                             ln_rm_o,
  output logic [N*32-1:0]                        ln_a_o,
  output logic [N*32-1:0]                        ln_b_o,
  output logic [N*32-1:0]                        ln_c_o,
  output logic [N-1:0]                           ln_en_o,
  output logic [LTAG_W-1:0]                      ln_tag_o,
  // ---------------------------------------------------------------- tracking
  output logic                                   trk_push_o,
  input  wire logic                              trk_full_i,
  output logic [N-1:0]                           trk_act_o,
  output logic                                   trk_last_o,
  output logic                                   trk_nobeat_o,
  output logic                                   trk_ill_o,
  output logic                                   trk_red_o,
  output logic [2:0]                             trk_rm_o,
  output logic [TID_W-1:0]                       trk_tid_o,
  output logic [31:0]                            trk_scalar_o,
  // ---------------------------------------------------------------- status
  output logic                                   busy_o,
  output logic                                   ev_stall_lane_o,  // beat waits on a lane
  output logic                                   ev_stall_trk_o,   // beat waits on tracking queue
  output logic                                   ev_opnd_starve_o, // command waits for operands
  output logic [$clog2(N+1)-1:0]                 ev_lane_stall_o,  // # lanes stalling this cycle
  output logic [$clog2(N+1)-1:0]                 ev_elem_o         // # active elements issued (beat fire)
);
  localparam int OPW  = hpc_vector_pkg::OP_W;
  localparam int BCW  = hpc_varray_pkg::BC_W;
  localparam int CMDW = TID_W + 1 + 32 + BCW + 1 + VL_W + 3 + OPW;
  localparam int PCW  = $clog2(N + 1);

  if (VL_W <= $clog2(N) || VL_W > 31) begin : g_bad_vlw
    hpc_param_error_VL_W_out_of_range u_err ();
  end

  // ===================================================================
  // Command queue
  // ===================================================================
  logic            init_q;              // 0 in reset and first cycle after
  logic            cq_empty, cq_full, cq_pop;
  logic [CMDW-1:0] cq_head;

  assign cmd_ready_o = init_q & ~cq_full;
  wire logic cmd_hs = cmd_valid_i & cmd_ready_o;

  hpc_varray_fifo #(.W(CMDW), .DEPTH(CMD_DEPTH)) u_cq (
    .clk_i, .rst_ni,
    .push_i (cmd_hs),
    .wdata_i({cmd_tid_i, cmd_red_i, cmd_scalar_i, cmd_bcast_i, cmd_vm_i, cmd_vl_i,
              cmd_rm_i, cmd_op_i}),
    .pop_i  (cq_pop),
    .rdata_o(cq_head),
    .empty_o(cq_empty),
    .full_o (cq_full),
    /* verilator lint_off PINCONNECTEMPTY */
    .count_o()
    /* verilator lint_on PINCONNECTEMPTY */
  );

  wire logic [OPW-1:0]   h_op     = cq_head[0 +: OPW];
  wire logic [2:0]       h_rm     = cq_head[OPW +: 3];
  wire logic [VL_W-1:0]  h_vl     = cq_head[OPW+3 +: VL_W];
  wire logic             h_vm     = cq_head[OPW+3+VL_W];
  wire logic [BCW-1:0]   h_bcast  = cq_head[OPW+4+VL_W +: BCW];
  wire logic [31:0]      h_scalar = cq_head[OPW+4+VL_W+BCW +: 32];
  wire logic             h_red    = cq_head[OPW+36+VL_W+BCW];
  wire logic [TID_W-1:0] h_tid    = cq_head[OPW+37+VL_W+BCW +: TID_W];
  wire logic             h_legal  = hpc_varray_pkg::cmd_legal(h_op, h_rm, h_red, h_bcast,
                                                              EN_FCMP, EN_INT, RED_EN);

  // ===================================================================
  // Current command
  // ===================================================================
  logic             cur_v_q;            // a command is being issued
  logic [OPW-1:0]   cur_op_q;
  logic [2:0]       cur_rm_q;
  logic [VL_W-1:0]  cur_rem_q;          // elements not yet covered by a beat
  logic             cur_vm_q;
  logic [BCW-1:0]   cur_bcast_q;
  logic [31:0]      cur_scalar_q;
  logic             cur_red_q;
  logic [TID_W-1:0] cur_tid_q;
  logic             cur_ill_q;
  logic [N-1:0]     acc_q;              // lanes that took their element of this beat
  logic [N-1:0]     hold_q;             // registered lane hold
  logic [LTAG_W-1:0] bseq_q;            // beat sequence number (lane tag)

  wire logic beat_ph = cur_v_q & (cur_rem_q != '0);   // issuing beats
  wire logic tok_ph  = cur_v_q & (cur_rem_q == '0);   // vl = 0: token only

  // tail-active lanes of the current beat: lane l covers element base + l
  logic [N-1:0] tail_act;
  always_comb begin
    for (int l = 0; l < N; l++) tail_act[l] = (cur_rem_q > VL_W'(l));
  end
  wire logic last_beat = (cur_rem_q <= VL_W'(N));

  // per-lane issue
  logic [N-1:0] lane_need, lane_ok, ln_en;
  always_comb begin
    for (int l = 0; l < N; l++) begin
      lane_need[l] = tail_act[l] & ~acc_q[l] & ~cur_ill_q;
      lane_ok[l]   = ~lane_need[l] | (ln_ready_i[l] & ~hold_q[l]);
      ln_en[l]     = ~cur_vm_q | opnd_mask_i[l];
    end
  end

  wire logic offer = beat_ph & ~trk_full_i;
  assign opnd_ready_o = offer & (&lane_ok);
  wire logic beat_fire = opnd_valid_i & opnd_ready_o;
  wire logic tok_fire  = tok_ph & ~trk_full_i;

  assign ln_valid_o = {N{offer & opnd_valid_i}} & lane_need & ~hold_q;
  assign ln_en_o    = ln_en;
  assign ln_op_o    = cur_op_q;
  assign ln_rm_o    = cur_rm_q;
  assign ln_tag_o   = bseq_q;
  wire logic bc_a = cur_bcast_q[hpc_varray_pkg::BC_A];
  wire logic bc_b = cur_bcast_q[hpc_varray_pkg::BC_B];
  wire logic bc_c = cur_bcast_q[hpc_varray_pkg::BC_C];
  always_comb begin
    for (int l = 0; l < N; l++) begin
      ln_a_o[l*32 +: 32] = bc_a ? cur_scalar_q : opnd_a_i[l*32 +: 32];
      ln_b_o[l*32 +: 32] = bc_b ? cur_scalar_q : opnd_b_i[l*32 +: 32];
      ln_c_o[l*32 +: 32] = bc_c ? cur_scalar_q : opnd_c_i[l*32 +: 32];
    end
  end

  // command sequencing: load the next command when idle or finishing
  wire logic cur_done = (beat_fire & last_beat) | tok_fire;
  assign cq_pop = ~cq_empty & (~cur_v_q | cur_done);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      init_q    <= 1'b0;
      cur_v_q   <= 1'b0;
      cur_rem_q <= '0;
      acc_q     <= '0;
      hold_q    <= '0;
      bseq_q    <= '0;
    end else begin
      init_q <= 1'b1;
      hold_q <= lane_hold_i;
      acc_q  <= beat_fire ? '0 : (acc_q | (ln_valid_o & ln_ready_i));
      if (beat_fire) bseq_q <= bseq_q + LTAG_W'(1);
      if (cq_pop) begin
        cur_v_q   <= 1'b1;
        cur_rem_q <= h_vl;
      end else if (cur_done) begin
        cur_v_q   <= 1'b0;
        cur_rem_q <= '0;
      end else if (beat_fire) begin
        cur_rem_q <= cur_rem_q - VL_W'(N);
      end
    end
  end

  // command fields: datapath registers qualified by cur_v_q
  always_ff @(posedge clk_i) begin
    if (cq_pop) begin
      cur_op_q     <= h_op;
      cur_rm_q     <= h_rm;
      cur_vm_q     <= h_vm;
      cur_bcast_q  <= h_bcast;
      cur_scalar_q <= h_scalar;
      cur_red_q    <= h_red;
      cur_tid_q    <= h_tid;
      cur_ill_q    <= ~h_legal;
    end
  end

  // ===================================================================
  // Tracking-queue entry (one per beat, or one per vl = 0 command)
  // ===================================================================
  wire logic [N-1:0] act = tail_act & ln_en & {N{~cur_ill_q}};

  assign trk_push_o   = beat_fire | tok_fire;
  assign trk_act_o    = tok_ph ? '0 : act;
  assign trk_last_o   = tok_ph | last_beat;
  assign trk_nobeat_o = tok_ph;
  assign trk_ill_o    = cur_ill_q;
  assign trk_red_o    = cur_red_q;
  assign trk_rm_o     = cur_rm_q;
  assign trk_tid_o    = cur_tid_q;
  assign trk_scalar_o = cur_scalar_q;

  // ===================================================================
  // Status and events
  // ===================================================================
  assign busy_o = cur_v_q | ~cq_empty;

  function automatic logic [PCW-1:0] popcnt(input logic [N-1:0] v);
    popcnt = '0;
    for (int i = 0; i < N; i++) popcnt = popcnt + PCW'(v[i]);
  endfunction

  assign ev_stall_lane_o  = offer & opnd_valid_i & ~(&lane_ok);
  assign ev_stall_trk_o   = beat_ph & opnd_valid_i & trk_full_i;
  assign ev_opnd_starve_o = beat_ph & ~opnd_valid_i;
  assign ev_lane_stall_o  = (offer & opnd_valid_i) ? popcnt(~lane_ok) : '0;
  assign ev_elem_o        = beat_fire ? popcnt(act) : '0;

`ifndef SYNTHESIS
  // a beat is never released while a live lane has not taken its element
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
    end else if (beat_fire) begin
      for (int l = 0; l < N; l++)
        if (lane_need[l] && !(ln_valid_o[l] && ln_ready_i[l]))
          $fatal(1, "hpc_varray_issue: beat released before lane %0d took its element", l);
    end
  end
`endif
endmodule
