// =============================================================================
// SilicaFlux-HPC Module 08 :: hpc_tile_lsu
// Vector load/store unit: scratchpad (Module 04 ports) -> operand beats ->
// hpc_vector_array (Module 03) -> result beats -> scratchpad.
// Aureom.AI | SilicaFlux-HPC.
//
// Replaces Module 05's serial reference sequencer hpc_tile_vseq (one access
// per cycle, waits for every response before the next beat) by a streaming,
// multi-port unit.  One job (one vector command) at a time.
//
// ---------------------------------------------------------------- data layout
// Vectors are FP32/INT32 arrays at DW-aligned scratchpad byte addresses
// (alignment is checked by the scheduler).  A scratchpad word holds
// EPW = DW/32 elements.  A "group" is one word access that serves
// LPW = min(N, EPW) consecutive lanes; a beat of N elements is WPB = N/LPW
// groups.  Element e of beat g = e/N is lane e mod N (Module 03 sec. 5).
//   group j of beat g: first element e0 = g*N + j*LPW
//                      word  = base_word + e0 / EPW, slots (e0 mod EPW) .. +LPW-1
// Group j is always served by scratchpad port j mod P (P = LSU ports), so the
// responses of one group arrive in order; each group has a FIFO of FD
// operand sets {a, b, c} x LPW.
//
// ---------------------------------------------------------------- streaming
//   load walker (per port): beat g, groups j = p, p+P, ...: one request per
//     operand the operation reads (a: always unless broadcast; b: all but FMV;
//     c: FMA family), skipping groups beyond VL.  A group's first load of a
//     beat reserves a FIFO slot (credit), so a response always has a slot.
//   assembler: beat g is offered to the array when every active group's FIFO
//     holds its set (or immediately if the op reads no operand).
//   store path: one result beat is buffered; each port stores its groups with
//     byte strobes = res_mask (inactive lanes are never written).  Stores have
//     priority over loads on a port; a presented request is held until
//     accepted (Module 04 H2).
//   reduction: no result beats; the FP32 result is stored to D (one word).
//   rsp_ready = 1 on every port (each load response has a reserved slot and a
//     store acknowledgement needs no space), so the scratchpad never
//     back-pressures this unit's responses -- no response-credit deadlock.
//
// ---------------------------------------------------------------- completion
//   done = the array's completion record received, the last result beat
//   stored and EVERY store acknowledged (scratchpad WRITE_ACK = 1: an
//   acknowledged store is in the array).  A consumer of `done` observes all
//   results in memory.
//
// ---------------------------------------------------------------- errors
//   The first scratchpad error response (load or store) is recorded with its
//   code and word address; from then on no further store of the job is issued
//   (results computed from a failed load are never written); loads and the
//   array stream continue so that the array's framing rule (ceil(vl/N) beats
//   per command) is kept; done reports SPM_ERR.  Stores accepted before the
//   error are in memory (documented partial update, docs/05_errors.md).
//
// Ordering inside a job: a load of element e precedes the store of element e
// (data dependence).  The scheduler only accepts D equal to a source base
// (exact in-place) or disjoint from it, so no load can observe a store of
// the same job (docs/04_memory_and_ordering.md).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "hpc_tile_defs.svh"
`default_nettype none

module hpc_tile_lsu #(
  parameter int          N        = 4,              // = hpc_vector_array NUM_LANES
  parameter int          DW       = 32,             // scratchpad word width
  parameter int          VL_W     = 16,
  parameter int          CB       = 16,             // log2(scratchpad bytes)
  parameter logic [31:0] SPM_BASE = 32'h2000_0000,
  parameter int          P        = 4,              // scratchpad ports used by the LSU
  parameter int          TAG_W    = 24,             // scratchpad TAG_W
  parameter int          FD       = 2,              // operand-set FIFO depth per group (beats)
  parameter int          TID_W    = 4,
  // ------------------------------------------------------------ derived (never set)
  localparam int SB    = DW / 8,
  localparam int OFF   = $clog2(SB),
  localparam int EPW   = DW / 32,
  localparam int EPWB  = $clog2(EPW),
  localparam int LPW   = (N < EPW) ? N : EPW,
  localparam int LPWB  = $clog2(LPW),
  localparam int WPB   = N / LPW,
  localparam int GPP   = WPB / P,
  localparam int KW    = (GPP > 1) ? $clog2(GPP) : 1,
  localparam int SGN   = EPW / LPW,
  localparam int SGW   = (SGN > 1) ? $clog2(SGN) : 1,
  localparam int WOW   = CB - OFF,
  localparam int LB    = $clog2(N),
  localparam int EW    = VL_W + LB + 2,
  localparam int TAG_NEED = WOW + SGW + KW + 3,
  localparam int PCW   = $clog2(P + 1),
  localparam int FCW   = $clog2(FD + 1),
  localparam int FPW   = (FD > 1) ? $clog2(FD) : 1,
  localparam int GJW   = (WPB > 1) ? $clog2(WPB) : 1
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  // ---------------------------------------------------------- job / done
  input  wire logic                 job_valid,
  output logic                      job_ready,
  input  wire logic [4:0]           job_op,
  input  wire logic [2:0]           job_rm,
  input  wire logic [VL_W-1:0]      job_vl,
  input  wire logic [2:0]           job_bcast,
  input  wire logic [31:0]          job_scalar,
  input  wire logic                 job_red,
  /* verilator lint_off UNUSEDSIGNAL */                    // only the scratchpad word offset is used (validated by the scheduler)
  input  wire logic [31:0]          job_a,
  input  wire logic [31:0]          job_b,
  input  wire logic [31:0]          job_c,
  input  wire logic [31:0]          job_d,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic                      done_valid,
  input  wire logic                 done_ready,
  output logic [3:0]                done_status,
  output logic [3:0]                done_detail,
  output logic [31:0]               done_err_addr,
  output logic [4:0]                done_flags,
  output logic [31:0]               done_count,
  output logic [31:0]               done_result,
  // ---------------------------------------------------------- scratchpad ports (hpc_scratchpad requester ports)
  output logic [P-1:0]              spm_req_valid,
  input  wire logic [P-1:0]         spm_req_ready,
  output logic [P-1:0]              spm_req_we,
  output logic [P*32-1:0]           spm_req_addr,
  output logic [P*DW-1:0]           spm_req_wdata,
  output logic [P*SB-1:0]           spm_req_wstrb,
  output logic [P*TAG_W-1:0]        spm_req_tag,
  input  wire logic [P-1:0]         spm_rsp_valid,
  output logic [P-1:0]              spm_rsp_ready,
  input  wire logic [P*DW-1:0]      spm_rsp_rdata,
  input  wire logic [P-1:0]         spm_rsp_err,
  input  wire logic [P*3-1:0]       spm_rsp_err_code,
  input  wire logic [P-1:0]         spm_rsp_we,
  input  wire logic [P*TAG_W-1:0]   spm_rsp_tag,
  // ---------------------------------------------------------- hpc_vector_array (master side)
  output logic                      arr_cmd_valid,
  input  wire logic                 arr_cmd_ready,
  output logic [4:0]                arr_cmd_op,
  output logic [2:0]                arr_cmd_rm,
  output logic [VL_W-1:0]           arr_cmd_vl,
  output logic                      arr_cmd_vm,
  output logic [2:0]                arr_cmd_bcast,
  output logic [31:0]               arr_cmd_scalar,
  output logic                      arr_cmd_red,
  output logic [TID_W-1:0]          arr_cmd_tid,
  output logic                      arr_opnd_valid,
  input  wire logic                 arr_opnd_ready,
  output logic [N*32-1:0]           arr_opnd_a,
  output logic [N*32-1:0]           arr_opnd_b,
  output logic [N*32-1:0]           arr_opnd_c,
  output logic [N-1:0]              arr_opnd_mask,
  input  wire logic                 arr_res_valid,
  output logic                      arr_res_ready,
  input  wire logic [N*32-1:0]      arr_res_data,
  input  wire logic [N-1:0]         arr_res_mask,
  /* verilator lint_off UNUSEDSIGNAL */                    // tids are checked by assertions only
  input  wire logic [TID_W-1:0]     arr_res_tid,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [VL_W-1:0]      arr_res_beat,
  input  wire logic                 arr_cpl_valid,
  output logic                      arr_cpl_ready,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [TID_W-1:0]     arr_cpl_tid,
  /* verilator lint_on UNUSEDSIGNAL */
  input  wire logic [4:0]           arr_cpl_flags,
  input  wire logic                 arr_cpl_illegal,
  input  wire logic [VL_W-1:0]      arr_cpl_count,
  input  wire logic [31:0]          arr_cpl_result,
  // ---------------------------------------------------------- status / events
  output logic                      busy,
  output logic [PCW-1:0]            ev_loads,       // load requests accepted this cycle
  output logic [PCW-1:0]            ev_stores       // store requests accepted this cycle
);
  // ============================================================ configuration checks
  if (N != 1 && N != 2 && N != 4 && N != 8 && N != 16) begin : g_err_n
    `SRAM_CFG_FATAL("hpc_tile_lsu: N must be 1, 2, 4, 8 or 16")
  end
  if (DW != 32 && DW != 64 && DW != 128) begin : g_err_dw
    `SRAM_CFG_FATAL("hpc_tile_lsu: DW must be 32, 64 or 128")
  end
  if (P < 1 || (P & (P - 1)) != 0 || P > WPB) begin : g_err_p
    `SRAM_CFG_FATAL("hpc_tile_lsu: P must be a power of two <= words per beat")
  end
  if (TAG_W < TAG_NEED || TAG_W > 32) begin : g_err_tag
    `SRAM_CFG_FATAL("hpc_tile_lsu: TAG_W must hold {we, operand, group, slot group, word offset} and be <= 32")
  end
  if (FD != 1 && FD != 2 && FD != 4 && FD != 8) begin : g_err_fd
    `SRAM_CFG_FATAL("hpc_tile_lsu: FD must be 1, 2, 4 or 8")
  end

  // ============================================================ helpers
  // operands an operation reads (Module 02 encoding: FMV 0x00 reads a; FMA
  // family 0x04..0x07 reads a, b, c; every other operation reads a and b),
  // minus the broadcast ones
  function automatic logic [2:0] reads(input logic [4:0] op, input logic [2:0] bc);
    logic [2:0] r;
    r = 3'b001;
    if (op != 5'h00) r[1] = 1'b1;
    if (op >= 5'h04 && op <= 5'h07) r[2] = 1'b1;
    reads = r & ~bc;
  endfunction
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic [1:0] first_op(input logic [2:0] m);
    first_op = m[0] ? 2'd0 : m[1] ? 2'd1 : 2'd2;
  endfunction
  function automatic logic [1:0] last_op(input logic [2:0] m);
    last_op = m[2] ? 2'd2 : m[1] ? 2'd1 : 2'd0;
  endfunction
  // next operand after x in mask m (valid only if one exists)
  function automatic logic [2:0] next_op(input logic [2:0] m, input logic [1:0] x);
    // returns {exists, op[1:0]}
    if (x == 2'd0 && m[1])      next_op = {1'b1, 2'd1};
    else if (x <= 2'd1 && m[2]) next_op = {1'b1, 2'd2};
    else                        next_op = {1'b0, 2'd0};
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */

  // ============================================================ job state
  localparam logic [2:0] L_IDLE = 3'd0, L_CMD = 3'd1, L_RUN = 3'd2, L_DONE = 3'd3;
  logic [2:0]       st_q;
  logic [4:0]       op_q;
  logic [2:0]       rm_q, bc_q, ops_q;
  logic [VL_W-1:0]  vl_q, nb_q;
  logic [31:0]      sc_q;
  logic             red_q;
  logic [WOW-1:0]   offa_q, offb_q, offc_q, offd_q;
  logic [TID_W-1:0] tid_q;
  logic [1:0]       fop_q, lop_q;

  wire run = (st_q == L_CMD) || (st_q == L_RUN);

  // completion of the array
  logic             cpl_got_q, cpl_ill_q;
  logic [4:0]       cpl_fl_q;
  logic [VL_W-1:0]  cpl_cnt_q;
  logic [31:0]      cpl_res_q;
  // errors
  logic             err_q;
  logic [2:0]       err_code_q;
  logic [31:0]      err_addr_q;
  // reduction store
  logic             red_iss_q;
  // stores outstanding
  logic [7:0]       st_out_q;

  // ============================================================ group FIFOs (operand sets)
  logic [WPB-1:0]   g_nz;                       // FIFO holds >= 1 committed set
  logic [WPB-1:0]   g_cred;                     // a slot can be reserved
  logic [WPB-1:0]   g_rsv_inc, g_pop;
  logic [WPB*3*LPW*32-1:0] g_head;              // head set of every group: {c, b, a} x LPW
  logic [EW-1:0]    ag_q;                       // assembler beat
  logic [WPB-1:0]   g_act_asm;                  // group active in the assembler's beat

  // per-port response decode, visible to the groups
  logic [P-1:0]           rl_valid;             // load response
  logic [P*2-1:0]         rl_x;
  logic [P*KW-1:0]        rl_k;
  logic [P*LPW*32-1:0]    rl_data;

  genvar gj;
  for (gj = 0; gj < WPB; gj++) begin : g_grp
    localparam int PJ = gj % P;                 // serving port
    localparam int KJ = gj / P;                 // local index on that port
    logic [3*LPW*32-1:0] ent [FD];
    logic [FPW-1:0]      wp_q, rp_q;
    logic [FCW-1:0]      cnt_q, rsv_q;
    wire hit    = rl_valid[PJ] && (rl_k[PJ*KW +: KW] == KW'(KJ));
    wire [1:0] x = rl_x[PJ*2 +: 2];
    wire commit = hit && (x == lop_q);
    always_ff @(posedge clk) begin
      if (hit) ent[wp_q][x*LPW*32 +: LPW*32] <= rl_data[PJ*LPW*32 +: LPW*32];
    end
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        wp_q <= '0; rp_q <= '0; cnt_q <= '0; rsv_q <= '0;
      end else if (st_q == L_IDLE) begin
        wp_q <= '0; rp_q <= '0; cnt_q <= '0; rsv_q <= '0;
      end else begin
        if (commit)    wp_q <= (FD > 1) ? wp_q + 1'b1 : '0;             // FD is a power of two
        if (g_pop[gj]) rp_q <= (FD > 1) ? rp_q + 1'b1 : '0;
        cnt_q <= cnt_q + FCW'(commit) - FCW'(g_pop[gj]);
        rsv_q <= rsv_q + FCW'(g_rsv_inc[gj]) - FCW'(g_pop[gj]);
      end
    end
    assign g_nz[gj]   = (cnt_q != '0);
    assign g_cred[gj] = (rsv_q < FCW'(FD));
    assign g_head[gj*3*LPW*32 +: 3*LPW*32] = ent[rp_q];
    wire [EW-1:0] e0a = (EW'(ag_q) << LB) + EW'(gj * LPW);
    assign g_act_asm[gj] = (e0a < EW'(vl_q));
`ifdef HPC_TILE_ASSERT
    always_ff @(posedge clk) if (rst_n && run) begin
      if (cnt_q > FCW'(FD) || rsv_q > FCW'(FD) || cnt_q > rsv_q) $fatal(1, "hpc_tile_lsu: group %0d FIFO accounting", gj);
      if (g_pop[gj] && cnt_q == '0) $fatal(1, "hpc_tile_lsu: group %0d pop while empty", gj);
    end
`endif
  end

  // ============================================================ assembler -> operand beats
  wire asm_ready = (ops_q == 3'b000) || (&(~g_act_asm | g_nz));
  assign arr_opnd_valid = run && (ag_q < EW'(nb_q)) && asm_ready;
  assign arr_opnd_mask  = '1;
  wire opnd_hs = arr_opnd_valid && arr_opnd_ready;
  always_comb begin
    arr_opnd_a = '0; arr_opnd_b = '0; arr_opnd_c = '0;
    for (int j = 0; j < WPB; j++) begin
      arr_opnd_a[j*LPW*32 +: LPW*32] = g_head[(j*3 + 0)*LPW*32 +: LPW*32];
      arr_opnd_b[j*LPW*32 +: LPW*32] = g_head[(j*3 + 1)*LPW*32 +: LPW*32];
      arr_opnd_c[j*LPW*32 +: LPW*32] = g_head[(j*3 + 2)*LPW*32 +: LPW*32];
    end
  end
  assign g_pop = (opnd_hs && ops_q != 3'b000) ? g_act_asm : '0;

  // ============================================================ result-beat buffer
  logic            rb_v_q;
  logic [VL_W-1:0] rb_g_q;
  logic [N*32-1:0] rb_data_q;
  logic [N-1:0]    rb_mask_q;
  assign arr_res_ready = run && !rb_v_q;
  wire   res_hs        = arr_res_valid && arr_res_ready;
  assign arr_cpl_ready = run && !cpl_got_q;
  wire   cpl_hs        = arr_cpl_valid && arr_cpl_ready;

  // ============================================================ per-port walkers and request mux
  localparam logic [1:0] K_NONE = 2'd0, K_LOAD = 2'd1, K_STORE = 2'd2, K_RED = 2'd3;
  logic [P-1:0] ld_acc, st_acc, ack_ok, ack_err, rsp_err_any;
  logic [P-1:0] sdone_now;
  logic [P-1:0] sdone_q;
  logic [P*32-1:0] rsp_err_addr;

  genvar gp;
  for (gp = 0; gp < P; gp++) begin : g_port
    // ---------------- load walker
    logic [VL_W-1:0] lg_q;
    logic [KW-1:0]   lk_q;
    logic [1:0]      lx_q;
    logic            lfin_q;
    wire  [31:0]     lj      = 32'(lk_q) * 32'(P) + 32'(gp);           // group index
    wire  [EW-1:0]   le0     = (EW'(lg_q) << LB) + EW'(lj * LPW);
    wire             lact    = (le0 < EW'(vl_q));
    wire             lfirst  = (lx_q == fop_q);
    wire             lcred   = g_cred[lj[GJW-1:0]];                         // lj < WPB
    wire             ld_cond = run && !lfin_q && lact && (!lfirst || lcred);
    wire             ld_skip = run && !lfin_q && !lact;
    wire  [WOW-1:0]  lbase   = (lx_q == 2'd0) ? offa_q : (lx_q == 2'd1) ? offb_q : offc_q;
    wire  [WOW-1:0]  lwoff   = lbase + WOW'(le0 >> EPWB);
    /* verilator lint_off UNUSEDSIGNAL */
    wire  [EW-1:0]   lsh     = le0 >> LPWB;
    /* verilator lint_on UNUSEDSIGNAL */
    wire  [SGW-1:0]  lsg     = (SGN > 1) ? lsh[SGW-1:0] : '0;               // slot group (SGN is a power of two)
    // ---------------- store walker (buffered result beat)
    logic [KW-1:0]   sk_q;
    wire  [31:0]     sj      = 32'(sk_q) * 32'(P) + 32'(gp);
    wire  [EW-1:0]   se0     = (EW'(rb_g_q) << LB) + EW'(sj * LPW);
    wire  [LPW-1:0]  smask   = rb_mask_q[(sj % WPB) * LPW +: LPW];
    wire             st_cond = rb_v_q && !sdone_q[gp] && (smask != '0) && !err_q;
    wire  [WOW-1:0]  swoff   = offd_q + WOW'(se0 >> EPWB);
    /* verilator lint_off UNUSEDSIGNAL */
    wire  [EW-1:0]   ssh     = se0 >> LPWB;
    /* verilator lint_on UNUSEDSIGNAL */
    wire  [SGW-1:0]  ssg     = (SGN > 1) ? ssh[SGW-1:0] : '0;
    logic [DW-1:0]   swdata;
    logic [SB-1:0]   swstrb;
    always_comb begin
      swdata = '0; swstrb = '0;
      for (int i = 0; i < LPW; i++) begin
        swdata[(32'(ssg) * LPW + i) * 32 +: 32] = rb_data_q[((sj % WPB) * LPW + i) * 32 +: 32];
        swstrb[(32'(ssg) * LPW + i) * 4 +: 4]   = {4{smask[i]}};
      end
    end
    // ---------------- reduction store (port 0 only)
    wire red_cond = (gp == 0) && run && cpl_got_q && red_q && !red_iss_q && !err_q;
    // ---------------- request mux with hold-until-accepted lock
    logic [1:0] lock_q;
    logic [1:0] kind;
    always_comb begin
      if (lock_q != K_NONE)  kind = lock_q;
      else if (red_cond)     kind = K_RED;
      else if (st_cond)      kind = K_STORE;
      else if (ld_cond)      kind = K_LOAD;
      else                   kind = K_NONE;
    end
    wire valid = (kind != K_NONE);
    wire acc   = valid && spm_req_ready[gp];
    assign spm_req_valid[gp] = valid;
    assign spm_req_we[gp]    = (kind == K_STORE) || (kind == K_RED);
    always_comb begin
      logic [WOW-1:0] wo;
      logic [SGW-1:0] sg;
      logic [KW-1:0]  kk;
      logic [1:0]     xx;
      wo = lwoff; sg = lsg; kk = lk_q; xx = lx_q;
      spm_req_wdata[gp*DW +: DW] = '0;
      spm_req_wstrb[gp*SB +: SB] = '0;
      if (kind == K_STORE) begin
        wo = swoff; sg = ssg; kk = sk_q; xx = 2'd3;
        spm_req_wdata[gp*DW +: DW] = swdata;
        spm_req_wstrb[gp*SB +: SB] = swstrb;
      end else if (kind == K_RED) begin
        wo = offd_q; sg = '0; kk = '0; xx = 2'd3;
        spm_req_wdata[gp*DW +: DW] = DW'(cpl_res_q);
        spm_req_wstrb[gp*SB +: SB] = SB'(4'hF);
      end
      spm_req_addr[gp*32 +: 32] = {SPM_BASE[31:CB], wo, {OFF{1'b0}}};
      spm_req_tag[gp*TAG_W +: TAG_W] = TAG_W'({spm_req_we[gp], xx, kk, sg, wo});
    end
    assign ld_acc[gp] = acc && (kind == K_LOAD);
    assign st_acc[gp] = acc && ((kind == K_STORE) || (kind == K_RED));
    wire st_adv = (acc && kind == K_STORE) || (lock_q != K_STORE && rb_v_q && !sdone_q[gp] && !st_cond);
    assign sdone_now[gp] = st_adv && (32'(sk_q) + 1 == 32'(GPP));
    wire ld_adv = (acc && kind == K_LOAD) || (lock_q != K_LOAD && ld_skip);
    wire [2:0] nx = next_op(ops_q, lx_q);

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        lg_q <= '0; lk_q <= '0; lx_q <= '0; lfin_q <= 1'b1;
        sk_q <= '0; sdone_q[gp] <= 1'b1; lock_q <= K_NONE;
      end else begin
        lock_q <= (valid && !spm_req_ready[gp]) ? kind : K_NONE;
        if (st_q == L_IDLE) begin
          lg_q <= '0; lk_q <= '0; lfin_q <= 1'b1;
          if (job_valid) begin
            lx_q   <= first_op(reads(job_op, job_bcast));
            lfin_q <= (reads(job_op, job_bcast) == 3'b000) || (job_vl == '0);
          end
        end else if (ld_adv) begin
          if (acc && kind == K_LOAD && nx[2]) lx_q <= nx[1:0];
          else begin
            lx_q <= fop_q;
            if (32'(lk_q) + 1 < 32'(GPP)) lk_q <= lk_q + 1'b1;
            else begin
              lk_q <= '0;
              lg_q <= lg_q + 1'b1;
              if (lg_q + 1'b1 == nb_q) lfin_q <= 1'b1;
            end
            if (ld_skip && !(acc && kind == K_LOAD)) lfin_q <= 1'b1;   // inactive group: rest of the last beat is inactive too
          end
        end
        // store walker
        if (res_hs) begin
          sk_q <= '0; sdone_q[gp] <= 1'b0;
        end else if (st_adv) begin
          if (32'(sk_q) + 1 == 32'(GPP)) sdone_q[gp] <= 1'b1;
          else sk_q <= sk_q + 1'b1;
        end
      end
    end
    // reserve a FIFO slot of group lj when its first load of a beat is accepted
    // (driven per group below from these per-port signals)
    wire rsv_fire = acc && (kind == K_LOAD) && lfirst;
    // ---------------- response decode (rsp_ready = 1)
    assign spm_rsp_ready[gp] = 1'b1;
    /* verilator lint_off UNUSEDSIGNAL */                  // the we bit and pad bits of the tag are not needed (rsp_we)
    wire [TAG_W-1:0] t = spm_rsp_tag[gp*TAG_W +: TAG_W];
    /* verilator lint_on UNUSEDSIGNAL */
    wire [1:0]       tx  = t[WOW + SGW + KW +: 2];
    wire [KW-1:0]    tk  = t[WOW + SGW +: KW];
    wire [SGW-1:0]   tsg = t[WOW +: SGW];
    wire [WOW-1:0]   two = t[0 +: WOW];
    assign rl_valid[gp]          = spm_rsp_valid[gp] && !spm_rsp_we[gp];
    assign rl_x[gp*2 +: 2]       = tx;
    assign rl_k[gp*KW +: KW]     = tk;
    always_comb begin
      rl_data[gp*LPW*32 +: LPW*32] = '0;
      if (!spm_rsp_err[gp])
        for (int i = 0; i < LPW; i++)
          rl_data[(gp*LPW + i)*32 +: 32] = spm_rsp_rdata[gp*DW + (32'(tsg) * LPW + i) * 32 +: 32];
    end
    assign ack_ok[gp]      = spm_rsp_valid[gp] && spm_rsp_we[gp] && !spm_rsp_err[gp];
    assign ack_err[gp]     = spm_rsp_valid[gp] && spm_rsp_we[gp] && spm_rsp_err[gp];
    assign rsp_err_any[gp] = spm_rsp_valid[gp] && spm_rsp_err[gp];
    assign rsp_err_addr[gp*32 +: 32] = {SPM_BASE[31:CB], two, {OFF{1'b0}}};
`ifdef HPC_TILE_ASSERT
    always_ff @(posedge clk) if (rst_n) begin
      if (rl_valid[gp] && !run) $fatal(1, "hpc_tile_lsu: load response while idle (port %0d)", gp);
      if (rl_valid[gp] && (32'(tk) * 32'(P) + 32'(gp)) >= 32'(WPB)) $fatal(1, "hpc_tile_lsu: response tag group out of range");
    end
`endif
  end

  // per-group reservation strobes from the serving port
  for (gj = 0; gj < WPB; gj++) begin : g_rsv
    localparam int PJ = gj % P;
    localparam int KJ = gj / P;
    assign g_rsv_inc[gj] = g_port[PJ].rsv_fire && (g_port[PJ].lk_q == KW'(KJ));
  end

  // ============================================================ counters / events
  function automatic logic [PCW-1:0] popc(input logic [P-1:0] v);
    logic [PCW-1:0] c;
    c = '0;
    for (int i = 0; i < P; i++) c = c + PCW'(v[i]);
    popc = c;
  endfunction
  assign ev_loads  = popc(ld_acc);
  assign ev_stores = popc(st_acc);
  wire [7:0] st_inc = 8'(popc(st_acc));
  wire [7:0] st_dec = 8'(popc(ack_ok | ack_err));

  // first error (lowest port wins within a cycle)
  logic       err_new;
  logic [2:0] err_new_code;
  logic [31:0] err_new_addr;
  always_comb begin
    err_new = 1'b0; err_new_code = '0; err_new_addr = '0;
    for (int i = P - 1; i >= 0; i--)
      if (rsp_err_any[i]) begin
        err_new = 1'b1;
        err_new_code = spm_rsp_err_code[i*3 +: 3];
        err_new_addr = rsp_err_addr[i*32 +: 32];
      end
  end

  // ============================================================ job FSM
  assign job_ready      = (st_q == L_IDLE);
  assign busy           = (st_q != L_IDLE);
  assign arr_cmd_valid  = (st_q == L_CMD);
  assign arr_cmd_op     = op_q;
  assign arr_cmd_rm     = rm_q;
  assign arr_cmd_vl     = vl_q;
  assign arr_cmd_vm     = 1'b0;
  assign arr_cmd_bcast  = bc_q;
  assign arr_cmd_scalar = sc_q;
  assign arr_cmd_red    = red_q;
  assign arr_cmd_tid    = tid_q;

  assign done_valid    = (st_q == L_DONE);
  assign done_status   = err_q ? `HPC_ST_SPM_ERR : cpl_ill_q ? `HPC_ST_ARRAY_ILL : `HPC_ST_OK;
  assign done_detail   = err_q ? {1'b0, err_code_q} : 4'd0;
  assign done_err_addr = err_q ? err_addr_q : 32'd0;
  assign done_flags    = cpl_fl_q;
  assign done_count    = 32'(cpl_cnt_q);
  assign done_result   = cpl_res_q;

  wire all_sdone = &(sdone_q | sdone_now);
  wire finished  = cpl_got_q && !rb_v_q && (!red_q || red_iss_q || err_q) && (st_out_q == 8'd0) && (st_inc == 8'd0);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= L_IDLE;
      op_q <= '0; rm_q <= '0; bc_q <= '0; ops_q <= '0; vl_q <= '0; nb_q <= '0; sc_q <= '0; red_q <= 1'b0;
      offa_q <= '0; offb_q <= '0; offc_q <= '0; offd_q <= '0; tid_q <= '0; fop_q <= '0; lop_q <= '0;
      cpl_got_q <= 1'b0; cpl_ill_q <= 1'b0; cpl_fl_q <= '0; cpl_cnt_q <= '0; cpl_res_q <= '0;
      err_q <= 1'b0; err_code_q <= '0; err_addr_q <= '0; red_iss_q <= 1'b0; st_out_q <= '0;
      ag_q <= '0; rb_v_q <= 1'b0; rb_g_q <= '0; rb_mask_q <= '0;
    end else begin
      st_out_q <= st_out_q + st_inc - st_dec;
      if (run && err_new && !err_q) begin
        err_q <= 1'b1; err_code_q <= err_new_code; err_addr_q <= err_new_addr;
      end
      if (opnd_hs) ag_q <= ag_q + 1'b1;
      if (res_hs) begin
        rb_v_q <= 1'b1; rb_g_q <= arr_res_beat; rb_data_q <= arr_res_data; rb_mask_q <= arr_res_mask;
      end else if (rb_v_q && all_sdone) rb_v_q <= 1'b0;
      if (cpl_hs) begin
        cpl_got_q <= 1'b1; cpl_ill_q <= arr_cpl_illegal; cpl_fl_q <= arr_cpl_flags;
        cpl_cnt_q <= arr_cpl_count; cpl_res_q <= arr_cpl_result;
      end
      if (|(st_acc & 1) && red_q && cpl_got_q && g_port[0].kind == K_RED) red_iss_q <= 1'b1;
      case (st_q)
        L_IDLE: if (job_valid) begin
          op_q <= job_op; rm_q <= job_rm; vl_q <= job_vl; bc_q <= job_bcast; sc_q <= job_scalar;
          red_q <= job_red; ops_q <= reads(job_op, job_bcast);
          fop_q <= first_op(reads(job_op, job_bcast)); lop_q <= last_op(reads(job_op, job_bcast));
          offa_q <= job_a[CB-1:OFF]; offb_q <= job_b[CB-1:OFF]; offc_q <= job_c[CB-1:OFF]; offd_q <= job_d[CB-1:OFF];
          nb_q <= VL_W'(((VL_W+LB+1)'(job_vl) + (VL_W+LB+1)'(N - 1)) >> LB);
          cpl_got_q <= 1'b0; cpl_ill_q <= 1'b0; cpl_fl_q <= '0; cpl_cnt_q <= '0; cpl_res_q <= '0;
          err_q <= 1'b0; err_code_q <= '0; err_addr_q <= '0; red_iss_q <= 1'b0;
          ag_q <= '0; rb_v_q <= 1'b0;
          st_q <= L_CMD;
        end
        L_CMD:  if (arr_cmd_ready) st_q <= L_RUN;
        L_RUN:  if (finished) st_q <= L_DONE;
        default: if (done_ready) begin st_q <= L_IDLE; tid_q <= tid_q + 1'b1; end
      endcase
    end
  end

`ifdef HPC_TILE_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    if (res_hs && arr_res_tid != tid_q) $fatal(1, "hpc_tile_lsu: result beat of another command (tid %0d, expected %0d)", arr_res_tid, tid_q);
    if (cpl_hs && arr_cpl_tid != tid_q) $fatal(1, "hpc_tile_lsu: completion of another command");
    if (st_out_q < st_dec && st_inc == 0) $fatal(1, "hpc_tile_lsu: store acknowledgement without a store");
    if (opnd_hs && ag_q >= EW'(nb_q)) $fatal(1, "hpc_tile_lsu: operand beat beyond the command");
  end
`endif
endmodule

`default_nettype wire
