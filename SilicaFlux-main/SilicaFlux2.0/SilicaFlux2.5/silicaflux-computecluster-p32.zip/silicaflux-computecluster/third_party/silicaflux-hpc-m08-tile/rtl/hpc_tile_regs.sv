// =============================================================================
// SilicaFlux-HPC Module 08 :: hpc_tile_regs
// Host register block of the SilicaFlux-HPC compute tile: command staging and
// submission, completion read-back, control / status / interrupts,
// performance-counter read-back and the soft-reset sequencer.
// Aureom.AI | SilicaFlux-HPC.
//
// Bus: the SilicaFlux-V register bus (silicaflux-v rtl/bus/sfv_periph_bridge.sv,
// the convention of every SilicaFlux-V / DataFabric peripheral, e.g.
// dma_control_regs): rb_sel one-cycle strobe, rb_we, rb_addr[11:0], rb_wdata;
// rb_rdata / rb_err answered combinationally in the strobe cycle; side effects
// at the end of the strobe cycle; 32-bit registers only.  Map:
// hpc_tile_defs.svh / docs/03_register_map.md.  Unmapped offsets and writes to
// read-only registers return rb_err = 1 with no effect; reads have no side
// effects.
//
// Submission: DOORBELL pushes {SEQ, CMD7..CMD0} into the command queue in the
// strobe cycle.  If the queue is full or a soft reset is in progress the write
// answers rb_err = 1, sets STATUS.SUBMIT_OVF and queues nothing (never a silent
// drop, never a stalled bus: a halted tile with a full queue cannot hang the
// CPU on its own submission).  SEQ = SUBMITTED counter (16 LSBs).
//
// Soft reset (CTRL.SOFT_RESET), docs/05_errors.md sec. 6:
//   QUIESCE  scheduler stops dispatching; the DMA adapter's active transfer is
//            aborted at the next beat boundary (cmd_abort held); the host
//            scratchpad port stops accepting; wait until the DMA engine is idle
//            and NO bus transaction of the tile is outstanding (SFB2 R11: a
//            master may not be reset with a transaction in flight)
//   RESET    tile domain held in reset for 4 cycles (queues, scheduler, LSU,
//            vector array, scratchpad control, DMA adapter); scratchpad and
//            host memory contents are kept
//   RELEASE  synchronous release; then IDLE
// This block, its configuration, interrupt state and the performance
// counters are in the always-on domain (hard reset only).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "hpc_tile_defs.svh"
`default_nettype none

module hpc_tile_regs #(
  parameter logic [31:0] CONFIG0  = 32'd0,
  parameter logic [31:0] CONFIG1  = 32'd0,
  parameter logic [31:0] SPM_BASE = 32'd0,
  parameter logic [31:0] VL_MAX   = 32'd0,
  parameter int          CQ_DEPTH = 8,
  parameter int          NPC      = `HPC_NUM_PC,
  parameter int          PERF_EN  = 1,
  localparam int QLW = 8
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,           // hard reset (always-on domain)
  // ---------------------------------------------------------- register bus
  input  wire logic                    rb_sel,
  input  wire logic                    rb_we,
  input  wire logic [11:0]             rb_addr,
  input  wire logic [31:0]             rb_wdata,
  output logic [31:0]                  rb_rdata,
  output logic                         rb_err,
  // ---------------------------------------------------------- command submission
  output logic                         sub_valid,
  input  wire logic                    sub_ready,
  output logic [`HPC_QDESC_W-1:0]      sub_data,
  // ---------------------------------------------------------- completion queue head
  input  wire logic                    cplq_valid,
  input  wire logic [`HPC_CPL_W-1:0]   cplq_data,
  output logic                         cplq_pop,
  // ---------------------------------------------------------- status
  input  wire logic [QLW-1:0]          cmdq_level,
  input  wire logic [QLW-1:0]          cplq_level,
  input  wire logic                    cmdq_full,
  input  wire logic                    st_busy,
  input  wire logic                    st_halted,
  input  wire logic                    st_flushing,
  input  wire logic                    st_dma,
  input  wire logic                    st_vec,
  input  wire logic                    st_kernel,
  // ---------------------------------------------------------- control
  output logic                         cfg_halt_on_err,
  output logic                         cfg_perf_freeze,
  output logic                         ctl_resume,
  output logic                         ctl_flush,
  output logic                         ctl_perf_clear,
  // ---------------------------------------------------------- soft reset
  output logic                         sr_quiesce,      // stop dispatch / host port, abort DMA
  output logic                         sr_tile_rst_n,   // tile-domain reset (registered, synchronous release)
  input  wire logic                    sr_quiet,        // DMA engine idle and no bus transaction outstanding
  // ---------------------------------------------------------- events (interrupt sources)
  input  wire logic                    ev_cpl_push,
  input  wire logic                    ev_cpl_err,
  input  wire logic                    ev_halt_enter,
  output logic                         ev_submit,       // a command was accepted (perf)
  // ---------------------------------------------------------- performance counters
  input  wire logic [NPC*32-1:0]       perf_cnt,
  output logic                         irq
);
  // ------------------------------------------------------------ state
  logic [31:0] cmd_q [8];
  logic        halt_en_q, freeze_q;
  logic        ovf_q, err_q;
  logic [2:0]  ie_q, is_q;
  logic [31:0] submitted_q;
  localparam logic [1:0] SR_IDLE = 2'd0, SR_QUIESCE = 2'd1, SR_RESET = 2'd2, SR_RELEASE = 2'd3;
  logic [1:0]  sr_q;
  logic [2:0]  sr_cnt_q;
  logic        sr_rst_n_q;

  wire wr  = rb_sel && rb_we;
  wire a_cmd = (rb_addr >= `HPC_REG_CMD0) && (rb_addr < `HPC_REG_CMD0 + 12'h20) && (rb_addr[1:0] == 2'b00);
  wire a_perf = (rb_addr >= `HPC_REG_PERF0) && (rb_addr < `HPC_REG_PERF0 + 12'(NPC * 4)) && (rb_addr[1:0] == 2'b00);
  wire [2:0] cmd_idx = rb_addr[4:2];
  wire [7:0] perf_idx = 8'((rb_addr - `HPC_REG_PERF0) >> 2);

  wire can_submit  = (sr_q == SR_IDLE) && sub_ready;
  wire doorbell    = wr && (rb_addr == `HPC_REG_DOORBELL);
  assign sub_valid = doorbell && can_submit;
  assign ev_submit = sub_valid;
  always_comb begin
    sub_data = '0;
    for (int i = 0; i < 8; i++) sub_data[i*32 +: 32] = cmd_q[i];
    sub_data[`HPC_DESC_W +: 16] = submitted_q[15:0];
  end
  assign cplq_pop = wr && (rb_addr == `HPC_REG_CPL_POP) && cplq_valid;

  wire ctrl_wr  = wr && (rb_addr == `HPC_REG_CTRL);
  assign ctl_resume     = ctrl_wr && rb_wdata[`HPC_CTRL_RESUME];
  assign ctl_flush      = ctrl_wr && rb_wdata[`HPC_CTRL_FLUSH] && (sr_q == SR_IDLE);
  assign ctl_perf_clear = ctrl_wr && rb_wdata[`HPC_CTRL_PERF_CLEAR];
  wire   sr_start       = ctrl_wr && rb_wdata[`HPC_CTRL_SOFT_RESET] && (sr_q == SR_IDLE);

  assign cfg_halt_on_err = halt_en_q;
  assign cfg_perf_freeze = freeze_q;
  assign sr_quiesce      = (sr_q != SR_IDLE);
  assign sr_tile_rst_n   = sr_rst_n_q;
  assign irq             = |(is_q & ie_q);

  // ------------------------------------------------------------ read mux / errors
  wire [31:0] status = {cplq_level, cmdq_level, 5'd0, st_kernel, st_vec, st_dma, err_q, ovf_q,
                        cplq_valid, cmdq_full, (sr_q != SR_IDLE), st_flushing, st_halted, st_busy};
  wire [31:0] cpl_info = cplq_valid ?
      {1'b1, 3'd0, cplq_data[`HPC_CPL_STEP_LSB +: 3], cplq_data[`HPC_CPL_FLAGS_LSB +: 5],
       cplq_data[`HPC_CPL_DETAIL_LSB +: 4], cplq_data[`HPC_CPL_TYPE_LSB +: 4],
       cplq_data[`HPC_CPL_STATUS_LSB +: 4], cplq_data[`HPC_CPL_TAG_LSB +: 8]} : 32'd0;
  function automatic logic [31:0] cplf(input logic v, input logic [31:0] x);
    cplf = v ? x : 32'd0;
  endfunction
  wire [31:0] free_slots = 32'(CQ_DEPTH) - 32'(cmdq_level);

  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_sel) begin
      if (a_cmd) begin
        rb_rdata = cmd_q[cmd_idx];
      end else if (a_perf) begin
        rb_rdata = (PERF_EN != 0) ? perf_cnt[perf_idx*32 +: 32] : 32'd0;
        rb_err   = rb_we;
      end else begin
        case (rb_addr)
          `HPC_REG_ID:           begin rb_rdata = `HPC_TILE_ID;      rb_err = rb_we; end
          `HPC_REG_VERSION:      begin rb_rdata = `HPC_TILE_VERSION; rb_err = rb_we; end
          `HPC_REG_CONFIG0:      begin rb_rdata = CONFIG0;           rb_err = rb_we; end
          `HPC_REG_CONFIG1:      begin rb_rdata = CONFIG1;           rb_err = rb_we; end
          `HPC_REG_SPM_BASE:     begin rb_rdata = SPM_BASE;          rb_err = rb_we; end
          `HPC_REG_VL_MAX:       begin rb_rdata = VL_MAX;            rb_err = rb_we; end
          `HPC_REG_CTRL:         rb_rdata = 32'd0;
          `HPC_REG_CFG:          rb_rdata = {30'd0, freeze_q, halt_en_q};
          `HPC_REG_STATUS:       rb_rdata = status;                  // W1C [7:6]
          `HPC_REG_IRQ_EN:       rb_rdata = {29'd0, ie_q};
          `HPC_REG_IRQ_STATUS:   rb_rdata = {29'd0, is_q};
          `HPC_REG_SUBMITTED:    begin rb_rdata = submitted_q;       rb_err = rb_we; end
          `HPC_REG_CMDQ_FREE:    begin rb_rdata = free_slots;        rb_err = rb_we; end
          `HPC_REG_CPL_INFO:     begin rb_rdata = cpl_info;          rb_err = rb_we; end
          `HPC_REG_CPL_SEQ:      begin rb_rdata = cplf(cplq_valid, {16'd0, cplq_data[`HPC_CPL_SEQ_LSB +: 16]}); rb_err = rb_we; end
          `HPC_REG_CPL_COUNT:    begin rb_rdata = cplf(cplq_valid, cplq_data[`HPC_CPL_COUNT_LSB +: 32]);  rb_err = rb_we; end
          `HPC_REG_CPL_RESULT:   begin rb_rdata = cplf(cplq_valid, cplq_data[`HPC_CPL_RESULT_LSB +: 32]); rb_err = rb_we; end
          `HPC_REG_CPL_ERR_ADDR: begin rb_rdata = cplf(cplq_valid, cplq_data[`HPC_CPL_EADDR_LSB +: 32]);  rb_err = rb_we; end
          `HPC_REG_CPL_CYCLES:   begin rb_rdata = cplf(cplq_valid, cplq_data[`HPC_CPL_CYCLES_LSB +: 32]); rb_err = rb_we; end
          `HPC_REG_CPL_POP:      rb_rdata = 32'd0;
          `HPC_REG_DOORBELL:     rb_err = rb_we && !can_submit;     // reads return 0
          default:               rb_err = 1'b1;
        endcase
      end
    end
  end

  // ------------------------------------------------------------ registers
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 8; i++) cmd_q[i] <= '0;
      halt_en_q <= 1'b1; freeze_q <= 1'b0; ovf_q <= 1'b0; err_q <= 1'b0;
      ie_q <= '0; is_q <= '0; submitted_q <= '0;
      sr_q <= SR_IDLE; sr_cnt_q <= '0; sr_rst_n_q <= 1'b0;
    end else begin
      if (wr && a_cmd) cmd_q[cmd_idx] <= rb_wdata;
      if (wr && rb_addr == `HPC_REG_CFG) begin
        halt_en_q <= rb_wdata[`HPC_CFG_HALT_ON_ERROR];
        freeze_q  <= rb_wdata[`HPC_CFG_PERF_FREEZE];
      end
      if (wr && rb_addr == `HPC_REG_IRQ_EN) ie_q <= rb_wdata[2:0];
      if (sub_valid) submitted_q <= submitted_q + 1'b1;
      // sticky status bits: set by events, cleared by writing 1 (set wins)
      if (doorbell && !can_submit) ovf_q <= 1'b1;
      else if (wr && rb_addr == `HPC_REG_STATUS && rb_wdata[6]) ovf_q <= 1'b0;
      if (ev_cpl_err) err_q <= 1'b1;
      else if (wr && rb_addr == `HPC_REG_STATUS && rb_wdata[7]) err_q <= 1'b0;
      // interrupt status: set by events, write-1-to-clear (set wins)
      for (int i = 0; i < 3; i++) begin
        logic set;
        set = (i == `HPC_IRQ_CPL) ? ev_cpl_push : (i == `HPC_IRQ_ERR) ? ev_cpl_err : ev_halt_enter;
        if (set) is_q[i] <= 1'b1;
        else if (wr && rb_addr == `HPC_REG_IRQ_STATUS && rb_wdata[i]) is_q[i] <= 1'b0;
      end
      // soft-reset sequencer
      sr_rst_n_q <= (sr_q != SR_RESET);
      case (sr_q)
        SR_IDLE:    if (sr_start) sr_q <= SR_QUIESCE;
        SR_QUIESCE: if (sr_quiet) begin sr_q <= SR_RESET; sr_cnt_q <= '0; end
        SR_RESET:   begin sr_cnt_q <= sr_cnt_q + 1'b1; if (sr_cnt_q == 3'd3) sr_q <= SR_RELEASE; end
        default:    sr_q <= SR_IDLE;                 // SR_RELEASE: one cycle with the tile out of reset, still quiesced
      endcase
    end
  end
endmodule

`default_nettype wire
