// =============================================================================
// SilicaFlux-HPC Module 08 :: silicaflux_hpc_tile
// Complete SilicaFlux-HPC compute tile: commands in, data moved, vector
// arithmetic executed, results returned.  Aureom.AI | SilicaFlux-HPC.
// Primary source of Module 08.
//
//      register bus (SilicaFlux-V rb, one 4 KiB page)          host scratchpad window (SFB2 slave)
//              |                                                          |
//   +----------v-------------------------------------------------------+  |
//   | hpc_tile_regs  CMD staging, DOORBELL, CPL read-back, CTRL/CFG,    |  |
//   |                STATUS, IRQ, PERF read-back, soft-reset sequencer  |  |   always-on domain (rst_n)
//   | hpc_perf_counters (Module 07)                                     |  |
//   +----+------------------------------------------------^------------+  |
//        | push                                           | head / pop    |
//   +----v-------------------+                  +---------+----------+    |
//   | hpc_command_queue (M06)|                  | completion queue   |    |   tile domain
//   +----+-------------------+                  | (hpc_command_queue)|    |   (rst_n & soft reset)
//        v                                      +---------^----------+    |
//   +--------------------------------------------------------------+     |
//   | hpc_tile_sched  validate -> dispatch (hazard check) -> ROB    |     |
//   |                 KERNEL micro-sequencer, halt / flush          |     |
//   +------+--------------------------------------+-----------------+     |
//          | descriptors / completions            | jobs / done           |
//   +------v-----------------------+      +-------v------------------+    |
//   | hpc_dma_adapter (Module 05)  |      | hpc_tile_lsu             |    |
//   |  DataFabric DMA engine       |      |  loads / stores, beats   |    |
//   +--+-----------------------+---+      +--+---------------+-------+    |
//      | SPM port              | SFB2        | P SPM ports   | cmd/opnd/res/cpl
//      |                       | master      |       +-------v-------------+
//      |                       |             |       | hpc_vector_array    |
//      |                       |             |       | (Module 03, N lanes |
//      |                       |             |       |  of Module 02)      |
//      |                       |             |       +---------------------+
//   +--v-----------------------|-------------v--------------------------v---+
//   | hpc_scratchpad (Module 04): LSU ports 0..P-1, DMA port P, host P+1     |
//   |   NUM_BANKS 1RW banks, per-bank round robin, WRITE_ACK = 1              |
//   +------------------------------------------------------------------------+
//                              | SFB2 master (fab_*) -> DataFabric / host-visible memory
//
// One clock domain (clk).  Reset convention of SilicaFlux / DataFabric:
// rst_n active low, asynchronous assert, synchronous release (sfv_rst_sync
// upstream).  The tile domain is additionally reset by the soft-reset
// sequencer (registered, released synchronously) after it has quiesced the
// tile's bus ports (SFB2 R11).
//
// Generic: no FPGA device, vendor primitive or ASIC macro is instantiated
// here; the scratchpad BACKEND parameter selects GENERIC / FPGA inference /
// ASIC macros inside the SRAM Wrapper Library.
// Documentation: docs/01_architecture.md (overview), 02_commands.md,
// 03_register_map.md, 04_memory_and_ordering.md, 05_errors.md.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "hpc_spm_defs.svh"
`include "hpc_dma_defs.svh"
`include "hpc_tile_defs.svh"
`default_nettype none

module silicaflux_hpc_tile #(
  // ------------------------------------------------------------ brief parameters
  parameter int          NUM_LANES            = 4,          // 1, 2, 4, 8, 16 FP32 lanes
  parameter int          DATA_WIDTH           = 32,         // scratchpad / DMA / bus word: 32, 64, 128
  parameter int          SCRATCHPAD_BYTES     = 65536,      // power of two
  parameter int          NUM_BANKS            = 4,          // 1, 2, 4, 8, 16
  parameter int          CMD_QUEUE_DEPTH      = 8,          // 2..128, power of two
  parameter int          DMA_BUFFER_DEPTH     = 0,          // 0 = simple engine; 2..128 power of two = buffered engine
  parameter int          ENABLE_PERF_COUNTERS = 1,          // 0 / 1
  // ------------------------------------------------------------ secondary
  parameter logic [31:0] SPM_BASE             = 32'h2000_0000, // scratchpad window (DataFabric TSPM base)
  parameter int          CPL_QUEUE_DEPTH      = 8,          // 2..128, power of two
  parameter int          HOST_SPM_PORT        = 1,          // 1: host scratchpad window (hs_*)
  parameter int          LSU_MAX_PORTS        = 4,          // 1, 2, 4
  parameter int          SPM_READ_LATENCY     = 1,
  parameter int          SPM_ECC              = `HPC_SPM_ECC_NONE,
  parameter int          SPM_BACKEND          = `SRAM_BACKEND_GENERIC,
  parameter int          SPM_MACRO            = 0,
  // ------------------------------------------------------------ derived (never set)
  localparam int DW     = DATA_WIDTH,
  localparam int SB     = DW / 8,
  localparam int OFF    = $clog2(SB),
  localparam int CB     = $clog2(SCRATCHPAD_BYTES),
  localparam int EPW    = (DW >= 32) ? DW / 32 : 1,           // guarded: illegal widths are reported below
  localparam int LPW    = (NUM_LANES < EPW) ? NUM_LANES : EPW,
  localparam int WPB    = NUM_LANES / LPW,
  localparam int LSU_P  = (WPB < LSU_MAX_PORTS) ? WPB : LSU_MAX_PORTS,
  localparam int P_DMA  = LSU_P,
  localparam int P_HOST = LSU_P + 1,
  localparam int NPORTS = LSU_P + 1 + ((HOST_SPM_PORT != 0) ? 1 : 0),
  localparam int VL_MAX = SCRATCHPAD_BYTES / 4,
  localparam int VL_W   = $clog2(VL_MAX) + 1,
  localparam int KW     = ((WPB / LSU_P) > 1) ? $clog2(WPB / LSU_P) : 1,
  localparam int SGW    = ((EPW / LPW) > 1) ? $clog2(EPW / LPW) : 1,
  localparam int TAG_W  = (CB - OFF) + SGW + KW + 3,
  localparam int NPC    = `HPC_NUM_PC,
  localparam int PIW    = 24
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- host register bus (SilicaFlux-V rb)
  input  wire logic             rb_sel,
  input  wire logic             rb_we,
  input  wire logic [11:0]      rb_addr,
  input  wire logic [31:0]      rb_wdata,
  output logic [31:0]           rb_rdata,
  output logic                  rb_err,
  // ---------------------------------------------------------- host scratchpad window (SFB2 slave)
  input  wire logic             hs_req_valid,
  output logic                  hs_req_ready,
  input  wire logic             hs_req_write,
  input  wire logic [31:0]      hs_req_addr,
  input  wire logic [DW-1:0]    hs_req_wdata,
  input  wire logic [SB-1:0]    hs_req_wstrb,
  output logic                  hs_rsp_valid,
  input  wire logic             hs_rsp_ready,
  output logic [DW-1:0]         hs_rsp_rdata,
  output logic                  hs_rsp_error,
  // ---------------------------------------------------------- DMA master (SFB2) -> DataFabric / host-visible memory
  output logic                  fab_req_valid,
  input  wire logic             fab_req_ready,
  output logic                  fab_req_write,
  output logic [31:0]           fab_req_addr,
  output logic [DW-1:0]         fab_req_wdata,
  output logic [SB-1:0]         fab_req_wstrb,
  input  wire logic             fab_rsp_valid,
  output logic                  fab_rsp_ready,
  input  wire logic [DW-1:0]    fab_rsp_rdata,
  input  wire logic             fab_rsp_error,
  // ---------------------------------------------------------- interrupt / status
  output logic                  irq,
  output logic                  busy,
  output logic                  halted
);
  // ============================================================ configuration checks (elaboration)
  if (NUM_LANES != 1 && NUM_LANES != 2 && NUM_LANES != 4 && NUM_LANES != 8 && NUM_LANES != 16) begin : g_err_num_lanes
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: NUM_LANES must be 1, 2, 4, 8 or 16")
  end
  if (DATA_WIDTH != 32 && DATA_WIDTH != 64 && DATA_WIDTH != 128) begin : g_err_data_width
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: DATA_WIDTH must be 32, 64 or 128 (SFB2 widths)")
  end
  if (NUM_BANKS != 1 && NUM_BANKS != 2 && NUM_BANKS != 4 && NUM_BANKS != 8 && NUM_BANKS != 16) begin : g_err_num_banks
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: NUM_BANKS must be 1, 2, 4, 8 or 16")
  end
  if (SCRATCHPAD_BYTES < 1024 || SCRATCHPAD_BYTES > (1 << 24) || (SCRATCHPAD_BYTES & (SCRATCHPAD_BYTES - 1)) != 0 ||
      SCRATCHPAD_BYTES < 2 * NUM_BANKS * (DATA_WIDTH / 8)) begin : g_err_scratchpad_bytes
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: SCRATCHPAD_BYTES must be a power of two, 1 KiB..16 MiB, >= 2 words per bank")
  end
  if ((SPM_BASE & 32'(SCRATCHPAD_BYTES - 1)) != 32'd0) begin : g_err_spm_base
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: SPM_BASE must be aligned to SCRATCHPAD_BYTES")
  end
  if (CMD_QUEUE_DEPTH < 2 || CMD_QUEUE_DEPTH > 128 || (CMD_QUEUE_DEPTH & (CMD_QUEUE_DEPTH - 1)) != 0) begin : g_err_cmd_queue_depth
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: CMD_QUEUE_DEPTH must be a power of two 2..128")
  end
  if (CPL_QUEUE_DEPTH < 2 || CPL_QUEUE_DEPTH > 128 || (CPL_QUEUE_DEPTH & (CPL_QUEUE_DEPTH - 1)) != 0) begin : g_err_cpl_queue_depth
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: CPL_QUEUE_DEPTH must be a power of two 2..128")
  end
  if (DMA_BUFFER_DEPTH != 0 && (DMA_BUFFER_DEPTH < 2 || DMA_BUFFER_DEPTH > 128 ||
                                (DMA_BUFFER_DEPTH & (DMA_BUFFER_DEPTH - 1)) != 0)) begin : g_err_dma_buffer_depth
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: DMA_BUFFER_DEPTH must be 0 (simple engine) or a power of two 2..128")
  end
  if (ENABLE_PERF_COUNTERS != 0 && ENABLE_PERF_COUNTERS != 1) begin : g_err_enable_perf_counters
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: ENABLE_PERF_COUNTERS must be 0 or 1")
  end
  if (HOST_SPM_PORT != 0 && HOST_SPM_PORT != 1) begin : g_err_host_spm_port
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: HOST_SPM_PORT must be 0 or 1")
  end
  if (LSU_MAX_PORTS != 1 && LSU_MAX_PORTS != 2 && LSU_MAX_PORTS != 4) begin : g_err_lsu_max_ports
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: LSU_MAX_PORTS must be 1, 2 or 4")
  end
  if (TAG_W > 32) begin : g_err_tag_width
    `SRAM_CFG_FATAL("silicaflux_hpc_tile: scratchpad tag exceeds 32 bits (SCRATCHPAD_BYTES too large for this lane / width combination)")
  end

  // The datapath is elaborated only for a legal configuration, so an illegal one is always reported
  // by the checks above (never by a sub-module's own check).
  localparam bit CFG_OK =
    (NUM_LANES == 1 || NUM_LANES == 2 || NUM_LANES == 4 || NUM_LANES == 8 || NUM_LANES == 16) &&
    (DATA_WIDTH == 32 || DATA_WIDTH == 64 || DATA_WIDTH == 128) &&
    (NUM_BANKS == 1 || NUM_BANKS == 2 || NUM_BANKS == 4 || NUM_BANKS == 8 || NUM_BANKS == 16) &&
    SCRATCHPAD_BYTES >= 1024 && SCRATCHPAD_BYTES <= (1 << 24) && (SCRATCHPAD_BYTES & (SCRATCHPAD_BYTES - 1)) == 0 &&
    SCRATCHPAD_BYTES >= 2 * NUM_BANKS * (DATA_WIDTH / 8) && (SPM_BASE & 32'(SCRATCHPAD_BYTES - 1)) == 32'd0 &&
    CMD_QUEUE_DEPTH >= 2 && CMD_QUEUE_DEPTH <= 128 && (CMD_QUEUE_DEPTH & (CMD_QUEUE_DEPTH - 1)) == 0 &&
    CPL_QUEUE_DEPTH >= 2 && CPL_QUEUE_DEPTH <= 128 && (CPL_QUEUE_DEPTH & (CPL_QUEUE_DEPTH - 1)) == 0 &&
    (DMA_BUFFER_DEPTH == 0 || (DMA_BUFFER_DEPTH >= 2 && DMA_BUFFER_DEPTH <= 128 &&
                               (DMA_BUFFER_DEPTH & (DMA_BUFFER_DEPTH - 1)) == 0)) &&
    (ENABLE_PERF_COUNTERS == 0 || ENABLE_PERF_COUNTERS == 1) && (HOST_SPM_PORT == 0 || HOST_SPM_PORT == 1) &&
    (LSU_MAX_PORTS == 1 || LSU_MAX_PORTS == 2 || LSU_MAX_PORTS == 4) && TAG_W <= 32;

  if (!CFG_OK) begin : g_off
    // never simulated or built: elaboration has already stopped with the reason above
    assign rb_rdata = '0; assign rb_err = 1'b1;
    assign hs_req_ready = 1'b0; assign hs_rsp_valid = 1'b0; assign hs_rsp_rdata = '0; assign hs_rsp_error = 1'b0;
    assign fab_req_valid = 1'b0; assign fab_req_write = 1'b0; assign fab_req_addr = '0; assign fab_req_wdata = '0;
    assign fab_req_wstrb = '0; assign fab_rsp_ready = 1'b1;
    assign irq = 1'b0; assign busy = 1'b0; assign halted = 1'b0;
  end else begin : g_core
  // ============================================================ resets
  logic sr_tile_rst_n;
  wire  tile_rst_n = rst_n && sr_tile_rst_n;     // asynchronous assert (either), synchronous release (registered term)

  // ============================================================ wires
  // submission / queues
  logic                    sub_valid, sub_ready;
  logic [`HPC_QDESC_W-1:0] sub_data;
  logic                    cq_valid, cq_ready, cq_full, cq_empty_unused;
  logic [`HPC_QDESC_W-1:0] cq_data;
  logic [$clog2(CMD_QUEUE_DEPTH+1)-1:0] cq_level;
  logic                    cpl_valid, cpl_ready, cplq_valid, cplq_pop, cplq_full_unused, cplq_empty_unused;
  logic [`HPC_CPL_W-1:0]   cpl_data, cplq_data;
  logic [$clog2(CPL_QUEUE_DEPTH+1)-1:0] cplq_level;
  // control / status
  logic cfg_halt_on_err, cfg_perf_freeze, ctl_resume, ctl_flush, ctl_perf_clear, sr_quiesce, sr_quiet;
  logic st_busy, st_halted, st_flushing, st_kernel, st_dma_busy_unused, st_vec_busy_unused;
  logic ev_hazard_stall, ev_cplq_stall, ev_halt_enter, ev_submit;
  // DMA adapter
  logic        dma_cmd_valid, dma_cmd_ready, dma_cpl_valid, dma_cpl_ready, dma_cpl_err;
  logic [31:0] dma_cmd_src, dma_cmd_dst, dma_cmd_len, dma_cpl_err_addr, dma_cpl_bytes;
  logic [3:0]  dma_cpl_code;
  logic        dma_busy, dma_active;
  logic [7:0]  dma_ev_bytes_rd, dma_ev_bytes_wr;
  // LSU
  logic        job_valid, job_ready, job_red, done_valid, done_ready;
  logic [4:0]  job_op, done_flags;
  logic [2:0]  job_rm, job_bcast;
  logic [VL_W-1:0] job_vl;
  logic [31:0] job_scalar, job_a, job_b, job_c, job_d, done_err_addr, done_count, done_result;
  logic [3:0]  done_status, done_detail;
  logic        lsu_busy;
  logic [$clog2(LSU_P+1)-1:0] ev_loads, ev_stores;
  // scratchpad ports
  logic [NPORTS-1:0]          s_req_valid, s_req_ready, s_req_we, s_rsp_valid, s_rsp_ready, s_rsp_err, s_rsp_we;
  logic [NPORTS*32-1:0]       s_req_addr;
  logic [NPORTS*DW-1:0]       s_req_wdata, s_rsp_rdata;
  logic [NPORTS*SB-1:0]       s_req_wstrb;
  logic [NPORTS*TAG_W-1:0]    s_req_tag, s_rsp_tag;
  logic [NPORTS*3-1:0]        s_rsp_err_code;
  logic [NPORTS-1:0]          s_ev_conflict;

  // ============================================================ register block (always-on domain)
  localparam logic [31:0] CONFIG0 = {3'(LSU_P - 1), 1'(HOST_SPM_PORT), 1'(DMA_BUFFER_DEPTH != 0), 1'(ENABLE_PERF_COUNTERS),
                                     5'(NUM_BANKS), 5'(CB), 8'(SB), 8'(NUM_LANES)};
  localparam logic [31:0] CONFIG1 = {8'(NPC), 8'((DMA_BUFFER_DEPTH != 0) ? $clog2(DMA_BUFFER_DEPTH) : 0),
                                     8'(CPL_QUEUE_DEPTH), 8'(CMD_QUEUE_DEPTH)};
  logic [NPC*32-1:0] perf_cnt;
  wire  cpl_push = cpl_valid && cpl_ready;
  wire  [3:0] cpl_st  = cpl_data[`HPC_CPL_STATUS_LSB +: 4];
  wire  [3:0] cpl_typ = cpl_data[`HPC_CPL_TYPE_LSB +: 4];
  wire  cpl_is_err = (cpl_st != `HPC_ST_OK) && (cpl_st != `HPC_ST_CANCELLED);

  hpc_tile_regs #(
    .CONFIG0(CONFIG0), .CONFIG1(CONFIG1), .SPM_BASE(SPM_BASE), .VL_MAX(32'(VL_MAX)),
    .CQ_DEPTH(CMD_QUEUE_DEPTH), .NPC(NPC), .PERF_EN(ENABLE_PERF_COUNTERS)
  ) u_regs (
    .clk, .rst_n,
    .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err,
    .sub_valid, .sub_ready, .sub_data,
    .cplq_valid, .cplq_data, .cplq_pop,
    .cmdq_level(8'(cq_level)), .cplq_level(8'(cplq_level)), .cmdq_full(cq_full),
    .st_busy(busy), .st_halted, .st_flushing, .st_dma(dma_active), .st_vec(lsu_busy), .st_kernel,
    .cfg_halt_on_err, .cfg_perf_freeze, .ctl_resume, .ctl_flush, .ctl_perf_clear,
    .sr_quiesce, .sr_tile_rst_n, .sr_quiet,
    .ev_cpl_push(cpl_push), .ev_cpl_err(cpl_push && cpl_is_err), .ev_halt_enter, .ev_submit,
    .perf_cnt, .irq
  );

  // ============================================================ command and completion queues (tile domain)
  hpc_command_queue #(.WIDTH(`HPC_QDESC_W), .DEPTH(CMD_QUEUE_DEPTH)) u_cmdq (
    .clk, .rst_n(tile_rst_n),
    .in_valid(sub_valid), .in_ready(sub_ready), .in_data(sub_data),
    .out_valid(cq_valid), .out_ready(cq_ready), .out_data(cq_data),
    .level(cq_level), .full(cq_full), .empty(cq_empty_unused)
  );
  hpc_command_queue #(.WIDTH(`HPC_CPL_W), .DEPTH(CPL_QUEUE_DEPTH)) u_cplq (
    .clk, .rst_n(tile_rst_n),
    .in_valid(cpl_valid), .in_ready(cpl_ready), .in_data(cpl_data),
    .out_valid(cplq_valid), .out_ready(cplq_pop), .out_data(cplq_data),
    .level(cplq_level), .full(cplq_full_unused), .empty(cplq_empty_unused)
  );

  // ============================================================ scheduler
  logic sch_dma_cmd_valid;
  hpc_tile_sched #(
    .DW(DW), .SPM_BASE(SPM_BASE), .SPM_BYTES(SCRATCHPAD_BYTES), .VL_W(VL_W), .VL_MAX(VL_MAX),
    .EN_FCMP(1), .EN_INT(1), .RED_EN(1), .ROB_DEPTH(4), .PERF_EN(ENABLE_PERF_COUNTERS)
  ) u_sched (
    .clk, .rst_n(tile_rst_n),
    .cq_valid, .cq_ready, .cq_data,
    .cfg_halt_on_err, .ctl_resume, .ctl_flush, .quiesce(sr_quiesce),
    .st_busy, .st_halted, .st_flushing, .st_kernel, .st_dma_busy(st_dma_busy_unused), .st_vec_busy(st_vec_busy_unused),
    .ev_hazard_stall, .ev_cplq_stall, .ev_halt_enter,
    .dma_cmd_valid(sch_dma_cmd_valid), .dma_cmd_ready(dma_cmd_ready && !sr_quiesce),
    .dma_cmd_src, .dma_cmd_dst, .dma_cmd_len,
    .dma_cpl_valid, .dma_cpl_ready, .dma_cpl_err, .dma_cpl_code, .dma_cpl_err_addr, .dma_cpl_bytes,
    .job_valid, .job_ready, .job_op, .job_rm, .job_vl, .job_bcast, .job_scalar, .job_red,
    .job_a, .job_b, .job_c, .job_d,
    .done_valid, .done_ready, .done_status, .done_detail, .done_err_addr, .done_flags, .done_count, .done_result,
    .cpl_valid, .cpl_ready, .cpl_data
  );
  // no new descriptor reaches the adapter while a soft reset quiesces the tile
  assign dma_cmd_valid = sch_dma_cmd_valid && !sr_quiesce;
  assign halted = st_halted;
  assign busy   = st_busy || lsu_busy || dma_busy || cq_valid;

  // ============================================================ DMA adapter (Module 05) + DataFabric engine
  logic [0:0] a_fab_req_valid, a_fab_req_write, a_fab_rsp_ready;
  /* verilator lint_off PINCONNECTEMPTY */
  hpc_dma_adapter #(
    .DW(DW), .ENGINE((DMA_BUFFER_DEPTH != 0) ? 1 : 0), .FIFO_DEPTH((DMA_BUFFER_DEPTH != 0) ? DMA_BUFFER_DEPTH : 8),
    .BURST((DMA_BUFFER_DEPTH != 0) ? DMA_BUFFER_DEPTH : 8), .DUAL_PORT(0), .MAX_OUT(2), .MAX_LEN_LOG2(24),
    .SPM_BASE(SPM_BASE), .SPM_BYTES(SCRATCHPAD_BYTES), .SPM_TAG_W(TAG_W), .CMD_DEPTH(2), .CPL_DEPTH(2),
    .TAG_W(1), .FAB_SLICE(0), .PERF_EN(0), .CNT_W(32)
  ) u_dma (
    .clk, .rst_n(tile_rst_n),
    .cmd_valid(dma_cmd_valid), .cmd_ready(dma_cmd_ready), .cmd_src(dma_cmd_src), .cmd_dst(dma_cmd_dst),
    .cmd_len(dma_cmd_len), .cmd_tag(1'b0), .cmd_abort(sr_quiesce),
    .cpl_valid(dma_cpl_valid), .cpl_ready(dma_cpl_ready), .cpl_tag(), .cpl_err(dma_cpl_err), .cpl_code(dma_cpl_code),
    .cpl_err_addr(dma_cpl_err_addr), .cpl_bytes(dma_cpl_bytes),
    .busy(dma_busy), .active(dma_active), .cur_tag(), .ctl_state(), .eng_state(), .eng_bytes_done(), .fifo_level(),
    .spm_req_valid(s_req_valid[P_DMA]), .spm_req_ready(s_req_ready[P_DMA]), .spm_req_we(s_req_we[P_DMA]),
    .spm_req_addr(s_req_addr[P_DMA*32 +: 32]), .spm_req_wdata(s_req_wdata[P_DMA*DW +: DW]),
    .spm_req_wstrb(s_req_wstrb[P_DMA*SB +: SB]), .spm_req_tag(s_req_tag[P_DMA*TAG_W +: TAG_W]),
    .spm_rsp_valid(s_rsp_valid[P_DMA]), .spm_rsp_ready(s_rsp_ready[P_DMA]), .spm_rsp_rdata(s_rsp_rdata[P_DMA*DW +: DW]),
    .spm_rsp_err(s_rsp_err[P_DMA]), .spm_rsp_err_code(s_rsp_err_code[P_DMA*3 +: 3]), .spm_rsp_we(s_rsp_we[P_DMA]),
    .spm_rsp_tag(s_rsp_tag[P_DMA*TAG_W +: TAG_W]),
    .fab_req_valid(a_fab_req_valid), .fab_req_ready(fab_req_ready), .fab_req_write(a_fab_req_write),
    .fab_req_addr(fab_req_addr), .fab_req_wdata(fab_req_wdata), .fab_req_wstrb(fab_req_wstrb),
    .fab_rsp_valid(fab_rsp_valid), .fab_rsp_ready(a_fab_rsp_ready), .fab_rsp_rdata(fab_rsp_rdata),
    .fab_rsp_error(fab_rsp_error),
    .ev_cmd_accept(), .ev_start(), .ev_cpl(), .ev_cpl_err(), .ev_bytes_rd(dma_ev_bytes_rd), .ev_bytes_wr(dma_ev_bytes_wr),
    .ev_req_stall(), .ev_outstanding(), .ev_bus_err(), .ev_tag_err(),
    .perf_clear(1'b0), .perf_cnt()
  );
  /* verilator lint_on PINCONNECTEMPTY */
  assign fab_req_valid = a_fab_req_valid[0];
  assign fab_req_write = a_fab_req_write[0];
  assign fab_rsp_ready = a_fab_rsp_ready[0];

  // outstanding bus transactions of the tile (soft-reset quiesce condition)
  logic [1:0] fab_out_q, hs_out_q;
  wire hs_req_hs = hs_req_valid && hs_req_ready;
  wire hs_rsp_hs = hs_rsp_valid && hs_rsp_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fab_out_q <= '0; hs_out_q <= '0;
    end else begin
      fab_out_q <= fab_out_q + 2'(fab_req_valid && fab_req_ready) - 2'(fab_rsp_valid && fab_rsp_ready);
      hs_out_q  <= hs_out_q + 2'(hs_req_hs) - 2'(hs_rsp_hs);
    end
  end
  assign sr_quiet = !dma_busy && (fab_out_q == 2'd0) && !(fab_req_valid && fab_req_ready) &&
                    (hs_out_q == 2'd0) && !hs_req_hs;

  // ============================================================ vector unit: LSU + array (Modules 03 / 02)
  localparam int TID_W = 4;
  logic                 a_cmd_valid, a_cmd_ready, a_cmd_vm, a_cmd_red;
  logic [4:0]           a_cmd_op;
  logic [2:0]           a_cmd_rm, a_cmd_bcast;
  logic [VL_W-1:0]      a_cmd_vl;
  logic [31:0]          a_cmd_scalar;
  logic [TID_W-1:0]     a_cmd_tid, a_res_tid, a_cpl_tid;
  logic                 a_opnd_valid, a_opnd_ready, a_res_valid, a_res_ready, a_cpl_valid, a_cpl_ready;
  logic [NUM_LANES*32-1:0] a_opnd_a, a_opnd_b, a_opnd_c, a_res_data;
  logic [NUM_LANES-1:0] a_opnd_mask, a_res_mask;
  logic [NUM_LANES*5-1:0] a_res_flags_unused;
  logic [VL_W-1:0]      a_res_beat, a_cpl_count;
  logic                 a_res_last_unused, a_cpl_illegal, a_cpl_red_unused, a_busy_unused;
  logic [4:0]           a_cpl_flags;
  logic [31:0]          a_cpl_result;

  hpc_tile_lsu #(
    .N(NUM_LANES), .DW(DW), .VL_W(VL_W), .CB(CB), .SPM_BASE(SPM_BASE), .P(LSU_P), .TAG_W(TAG_W),
    .FD(2), .TID_W(TID_W)
  ) u_lsu (
    .clk, .rst_n(tile_rst_n),
    .job_valid, .job_ready, .job_op, .job_rm, .job_vl, .job_bcast, .job_scalar, .job_red,
    .job_a, .job_b, .job_c, .job_d,
    .done_valid, .done_ready, .done_status, .done_detail, .done_err_addr, .done_flags, .done_count, .done_result,
    .spm_req_valid(s_req_valid[LSU_P-1:0]), .spm_req_ready(s_req_ready[LSU_P-1:0]), .spm_req_we(s_req_we[LSU_P-1:0]),
    .spm_req_addr(s_req_addr[LSU_P*32-1:0]), .spm_req_wdata(s_req_wdata[LSU_P*DW-1:0]),
    .spm_req_wstrb(s_req_wstrb[LSU_P*SB-1:0]), .spm_req_tag(s_req_tag[LSU_P*TAG_W-1:0]),
    .spm_rsp_valid(s_rsp_valid[LSU_P-1:0]), .spm_rsp_ready(s_rsp_ready[LSU_P-1:0]),
    .spm_rsp_rdata(s_rsp_rdata[LSU_P*DW-1:0]), .spm_rsp_err(s_rsp_err[LSU_P-1:0]),
    .spm_rsp_err_code(s_rsp_err_code[LSU_P*3-1:0]), .spm_rsp_we(s_rsp_we[LSU_P-1:0]),
    .spm_rsp_tag(s_rsp_tag[LSU_P*TAG_W-1:0]),
    .arr_cmd_valid(a_cmd_valid), .arr_cmd_ready(a_cmd_ready), .arr_cmd_op(a_cmd_op), .arr_cmd_rm(a_cmd_rm),
    .arr_cmd_vl(a_cmd_vl), .arr_cmd_vm(a_cmd_vm), .arr_cmd_bcast(a_cmd_bcast), .arr_cmd_scalar(a_cmd_scalar),
    .arr_cmd_red(a_cmd_red), .arr_cmd_tid(a_cmd_tid),
    .arr_opnd_valid(a_opnd_valid), .arr_opnd_ready(a_opnd_ready), .arr_opnd_a(a_opnd_a), .arr_opnd_b(a_opnd_b),
    .arr_opnd_c(a_opnd_c), .arr_opnd_mask(a_opnd_mask),
    .arr_res_valid(a_res_valid), .arr_res_ready(a_res_ready), .arr_res_data(a_res_data), .arr_res_mask(a_res_mask),
    .arr_res_tid(a_res_tid), .arr_res_beat(a_res_beat),
    .arr_cpl_valid(a_cpl_valid), .arr_cpl_ready(a_cpl_ready), .arr_cpl_tid(a_cpl_tid), .arr_cpl_flags(a_cpl_flags),
    .arr_cpl_illegal(a_cpl_illegal), .arr_cpl_count(a_cpl_count), .arr_cpl_result(a_cpl_result),
    .busy(lsu_busy), .ev_loads, .ev_stores
  );

  /* verilator lint_off PINCONNECTEMPTY */
  hpc_vector_array #(
    .NUM_LANES(NUM_LANES), .VL_W(VL_W), .TID_W(TID_W), .CMD_DEPTH(2), .TRK_DEPTH(8), .CPL_DEPTH(2),
    .RED_EN(1'b1), .RED_LAT(3), .PERF_EN(1'b0), .PERF_CW(32)
  ) u_array (
    .clk_i(clk), .rst_ni(tile_rst_n),
    .cmd_valid_i(a_cmd_valid), .cmd_ready_o(a_cmd_ready), .cmd_op_i(a_cmd_op), .cmd_rm_i(a_cmd_rm),
    .cmd_vl_i(a_cmd_vl), .cmd_vm_i(a_cmd_vm), .cmd_bcast_i(a_cmd_bcast), .cmd_scalar_i(a_cmd_scalar),
    .cmd_red_i(a_cmd_red), .cmd_tid_i(a_cmd_tid),
    .opnd_valid_i(a_opnd_valid), .opnd_ready_o(a_opnd_ready), .opnd_a_i(a_opnd_a), .opnd_b_i(a_opnd_b),
    .opnd_c_i(a_opnd_c), .opnd_mask_i(a_opnd_mask),
    .res_valid_o(a_res_valid), .res_ready_i(a_res_ready), .res_data_o(a_res_data), .res_flags_o(a_res_flags_unused),
    .res_mask_o(a_res_mask), .res_tid_o(a_res_tid), .res_beat_o(a_res_beat), .res_last_o(a_res_last_unused),
    .cpl_valid_o(a_cpl_valid), .cpl_ready_i(a_cpl_ready), .cpl_tid_o(a_cpl_tid), .cpl_flags_o(a_cpl_flags),
    .cpl_illegal_o(a_cpl_illegal), .cpl_count_o(a_cpl_count), .cpl_red_o(a_cpl_red_unused),
    .cpl_result_o(a_cpl_result),
    .lane_hold_i('0), .busy_o(a_busy_unused), .perf_clear_i(1'b0), .perf_cnt_o()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  // ============================================================ host scratchpad window
  if (HOST_SPM_PORT != 0) begin : g_host
    logic hs_ready_raw, ev_tag_unused, ev_spm_unused;
    logic [2:0] code_unused;
    hpc_dma_spm_port #(.DW(DW), .AW(32), .SPM_TAG_W(TAG_W), .MAX_OUT(1)) u_hs (
      .clk, .rst_n(tile_rst_n),
      .req_valid(hs_req_valid && !sr_quiesce), .req_ready(hs_ready_raw), .req_write(hs_req_write),
      .req_addr(hs_req_addr), .req_wdata(hs_req_wdata), .req_wstrb(hs_req_wstrb),
      .rsp_valid(hs_rsp_valid), .rsp_ready(hs_rsp_ready), .rsp_rdata(hs_rsp_rdata), .rsp_error(hs_rsp_error),
      .spm_req_valid(s_req_valid[P_HOST]), .spm_req_ready(s_req_ready[P_HOST]), .spm_req_we(s_req_we[P_HOST]),
      .spm_req_addr(s_req_addr[P_HOST*32 +: 32]), .spm_req_wdata(s_req_wdata[P_HOST*DW +: DW]),
      .spm_req_wstrb(s_req_wstrb[P_HOST*SB +: SB]), .spm_req_tag(s_req_tag[P_HOST*TAG_W +: TAG_W]),
      .spm_rsp_valid(s_rsp_valid[P_HOST]), .spm_rsp_ready(s_rsp_ready[P_HOST]),
      .spm_rsp_rdata(s_rsp_rdata[P_HOST*DW +: DW]), .spm_rsp_err(s_rsp_err[P_HOST]),
      .spm_rsp_err_code(s_rsp_err_code[P_HOST*3 +: 3]), .spm_rsp_we(s_rsp_we[P_HOST]),
      .spm_rsp_tag(s_rsp_tag[P_HOST*TAG_W +: TAG_W]),
      .ev_tag_err(ev_tag_unused), .ev_spm_err(ev_spm_unused), .spm_err_code(code_unused)
    );
    assign hs_req_ready = hs_ready_raw && !sr_quiesce;
  end else begin : g_nohost
    // no window: every request is answered with an error one cycle later (SFB2 R5 / R8)
    logic rsp_v_q;
    assign hs_req_ready = !rsp_v_q || hs_rsp_ready;
    always_ff @(posedge clk or negedge rst_n)
      if (!rst_n) rsp_v_q <= 1'b0;
      else if (hs_req_ready) rsp_v_q <= hs_req_valid;
    assign hs_rsp_valid = rsp_v_q;
    assign hs_rsp_rdata = '0;
    assign hs_rsp_error = rsp_v_q;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_hs = ^{hs_req_write, hs_req_addr, hs_req_wdata, hs_req_wstrb};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ============================================================ banked scratchpad (Module 04)
  /* verilator lint_off PINCONNECTEMPTY */
  hpc_scratchpad #(
    .NUM_PORTS(NPORTS), .CAPACITY_BYTES(SCRATCHPAD_BYTES), .NUM_BANKS(NUM_BANKS), .DATA_WIDTH(DW), .ADDR_WIDTH(32),
    .BASE_ADDR({32'd0, SPM_BASE}), .READ_LATENCY(SPM_READ_LATENCY), .BYTE_WE(1), .PORT_MODE(`HPC_SPM_PORT_1RW),
    .MAP(`HPC_SPM_MAP_LOW), .ARB(`HPC_SPM_ARB_RR), .QUEUE_DEPTH(0), .RSP_FIFO_DEPTH(SPM_READ_LATENCY + 1),
    .WRITE_ACK(1), .TAG_W(TAG_W), .ECC_MODE(SPM_ECC), .BACKEND(SPM_BACKEND), .MACRO(SPM_MACRO),
    .PERF_EN(0), .CNT_W(32)
  ) u_spm (
    .clk, .rst_n(tile_rst_n),
    .req_valid(s_req_valid), .req_ready(s_req_ready), .req_we(s_req_we), .req_addr(s_req_addr),
    .req_wdata(s_req_wdata), .req_wstrb(s_req_wstrb), .req_tag(s_req_tag),
    .rsp_valid(s_rsp_valid), .rsp_ready(s_rsp_ready), .rsp_rdata(s_rsp_rdata), .rsp_err(s_rsp_err), .rsp_err_code(s_rsp_err_code),
    .rsp_we(s_rsp_we), .rsp_tag(s_rsp_tag), .rsp_ecc_syn(),
    .ev_accept(), .ev_issue(), .ev_conflict(s_ev_conflict), .ev_credit_stall(), .ev_error(), .ev_ecc_err(),
    .ev_bank_ops(), .ev_bank_conflict(),
    .perf_clear(1'b0), .perf_cycles(), .perf_accept(), .perf_issue(), .perf_complete(), .perf_conflict(),
    .perf_wait(), .perf_error(), .perf_bank_ops(), .perf_ecc_err(), .busy()
  );
  /* verilator lint_on PINCONNECTEMPTY */

  // ============================================================ performance counters (always-on domain)
  if (ENABLE_PERF_COUNTERS != 0) begin : g_perf
    logic [4:0] vop_q;
    always_ff @(posedge clk or negedge rst_n)
      if (!rst_n) vop_q <= '0; else if (job_valid && job_ready) vop_q <= job_op;
    wire done_hs = done_valid && done_ready;
    wire [1:0] fpe = (vop_q >= 5'h04 && vop_q <= 5'h07) ? 2'd2 : (vop_q >= 5'h01 && vop_q <= 5'h03) ? 2'd1 : 2'd0;
    logic [NPC*PIW-1:0] inc;
    function automatic logic [PIW-1:0] popc(input logic [NPORTS-1:0] v);
      logic [PIW-1:0] c;
      c = '0;
      for (int i = 0; i < NPORTS; i++) c = c + PIW'(v[i]);
      popc = c;
    endfunction
    always_comb begin
      inc = '0;
      inc[`HPC_PC_CYCLES       *PIW +: PIW] = PIW'(1);
      inc[`HPC_PC_BUSY         *PIW +: PIW] = PIW'(busy);
      inc[`HPC_PC_SUBMITTED    *PIW +: PIW] = PIW'(ev_submit);
      inc[`HPC_PC_COMPLETED    *PIW +: PIW] = PIW'(cpl_push);
      inc[`HPC_PC_ERRORS       *PIW +: PIW] = PIW'(cpl_push && cpl_is_err);
      inc[`HPC_PC_CANCELLED    *PIW +: PIW] = PIW'(cpl_push && cpl_st == `HPC_ST_CANCELLED);
      inc[`HPC_PC_DMA_ACTIVE   *PIW +: PIW] = PIW'(dma_active);
      inc[`HPC_PC_DMA_BYTES_RD *PIW +: PIW] = PIW'(dma_ev_bytes_rd);
      inc[`HPC_PC_DMA_BYTES_WR *PIW +: PIW] = PIW'(dma_ev_bytes_wr);
      inc[`HPC_PC_VEC_ACTIVE   *PIW +: PIW] = PIW'(lsu_busy);
      inc[`HPC_PC_VEC_ELEMS    *PIW +: PIW] = done_hs ? PIW'(done_count) : '0;
      inc[`HPC_PC_VEC_FLOPS    *PIW +: PIW] = done_hs ? PIW'(done_count) * PIW'(fpe) : '0;
      inc[`HPC_PC_LSU_LOADS    *PIW +: PIW] = PIW'(ev_loads);
      inc[`HPC_PC_LSU_STORES   *PIW +: PIW] = PIW'(ev_stores);
      inc[`HPC_PC_SPM_CONFLICTS*PIW +: PIW] = popc(s_ev_conflict);
      inc[`HPC_PC_OVERLAP      *PIW +: PIW] = PIW'(dma_active && lsu_busy);
      inc[`HPC_PC_HAZARD_STALL *PIW +: PIW] = PIW'(ev_hazard_stall);
      inc[`HPC_PC_HALTED       *PIW +: PIW] = PIW'(st_halted);
      inc[`HPC_PC_CMDQ_FULL    *PIW +: PIW] = PIW'(cq_full);
      inc[`HPC_PC_CPLQ_STALL   *PIW +: PIW] = PIW'(ev_cplq_stall);
      inc[`HPC_PC_HOST_SPM     *PIW +: PIW] = PIW'(hs_req_hs);
      inc[`HPC_PC_DMA_CMDS     *PIW +: PIW] = PIW'(cpl_push && cpl_st == `HPC_ST_OK && cpl_typ == `HPC_CT_DMA);
      inc[`HPC_PC_VEC_CMDS     *PIW +: PIW] = PIW'(cpl_push && cpl_st == `HPC_ST_OK && cpl_typ == `HPC_CT_VEC);
      inc[`HPC_PC_KERNEL_CMDS  *PIW +: PIW] = PIW'(cpl_push && cpl_st == `HPC_ST_OK && cpl_typ == `HPC_CT_KERNEL);
    end
    hpc_perf_counters #(.NUM(NPC), .CW(32), .IW(PIW)) u_perf (
      .clk, .rst_n, .clear(ctl_perf_clear), .enable(!cfg_perf_freeze), .inc, .cnt(perf_cnt)
    );
  end else begin : g_noperf
    // ENABLE_PERF_COUNTERS = 0: no counter is built; the events are left unobserved
    assign perf_cnt = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_perf = ^{ev_submit, ev_hazard_stall, ev_cplq_stall, ctl_perf_clear, cfg_perf_freeze, cpl_typ,
                         s_ev_conflict, ev_loads, ev_stores, dma_ev_bytes_rd, dma_ev_bytes_wr};
    /* verilator lint_on UNUSEDSIGNAL */
  end
  end   // g_core
endmodule

`default_nettype wire
