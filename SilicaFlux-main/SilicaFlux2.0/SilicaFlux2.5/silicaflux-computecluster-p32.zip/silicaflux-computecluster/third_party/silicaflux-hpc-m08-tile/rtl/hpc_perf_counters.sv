// =============================================================================
// SilicaFlux-HPC Module 07 (minimal) :: hpc_perf_counters
// Bank of NUM saturating event counters.  Aureom.AI | SilicaFlux-HPC.
//
// No hpc_perf_counters existed in the repository (Module 08 audit); the
// sub-modules each carry their own fixed counter sets (hpc_varray_perf,
// hpc_spm_perf, hpc_dma_perf).  This is the smallest legitimate generic bank
// the tile needs to count tile-level events, verified on its own
// (tb/tb_hpc_perf_counters.sv).
//
//   inc[i*IW +: IW]  amount added to counter i at the next edge (0 = no event)
//   clear            synchronous clear of every counter (wins over increments)
//   enable           0 = freeze: counters hold their value (clear still works)
//   cnt[i*CW +: CW]  counter i
//
// Counters never wrap: an addition that would exceed 2^CW - 1 leaves the
// counter at 2^CW - 1 (saturation), so a read value is always a lower bound.
// Reset: asynchronous assert, synchronous release; all counters 0.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module hpc_perf_counters #(
  parameter int NUM = 24,
  parameter int CW  = 32,
  parameter int IW  = 8
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  input  wire logic              clear,
  input  wire logic              enable,
  input  wire logic [NUM*IW-1:0] inc,
  output logic      [NUM*CW-1:0] cnt
);
  if (NUM < 1 || NUM > 256) begin : g_err_num
    `SRAM_CFG_FATAL("hpc_perf_counters: NUM must be 1..256")
  end
  if (CW < 2 || CW > 64 || IW < 1 || IW > CW) begin : g_err_width
    `SRAM_CFG_FATAL("hpc_perf_counters: need 2 <= CW <= 64 and 1 <= IW <= CW")
  end

  genvar gi;
  for (gi = 0; gi < NUM; gi++) begin : g_cnt
    logic [CW-1:0] c_q;
    wire  [CW:0]   sum = {1'b0, c_q} + {{(CW + 1 - IW){1'b0}}, inc[gi*IW +: IW]};
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n)                        c_q <= '0;
      else if (clear)                    c_q <= '0;
      else if (enable && inc[gi*IW +: IW] != '0)
        c_q <= sum[CW] ? {CW{1'b1}} : sum[CW-1:0];
    end
    assign cnt[gi*CW +: CW] = c_q;
  end
endmodule

`default_nettype wire
