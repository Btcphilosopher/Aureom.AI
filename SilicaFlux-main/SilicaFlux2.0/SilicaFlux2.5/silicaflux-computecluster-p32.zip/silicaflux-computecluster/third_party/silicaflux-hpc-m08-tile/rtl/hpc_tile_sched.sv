// =============================================================================
// SilicaFlux-HPC Module 08 :: hpc_tile_sched
// Command scheduler of the SilicaFlux-HPC compute tile.  Aureom.AI | SilicaFlux-HPC.
//
//   command queue head --> DCR (decoded command register) --> validate
//        --> dispatch (in order, one per cycle) --> DMA unit | vector unit | immediate
//        --> ROB (in-order retirement, ROB_DEPTH entries) --> completion queue
//
// ---------------------------------------------------------------- validation
// Every command is checked in the DCR BEFORE any side effect (docs/05_errors.md):
//   BAD_TYPE > BAD_RSVD > (VEC / KERNEL:) BAD_OP > BAD_VL > ALIGN > SPM_RANGE > OVERLAP
// The first failing rule gives the status.  A failing command is never sent
// to a unit: it becomes an immediate ROB entry and completes, in order, with
// its status.  BAD_OP uses the array's own rule (hpc_varray_pkg::cmd_legal),
// so no command the array would treat as illegal ever reaches it; the array's
// cpl_illegal is still mapped to ARRAY_ILL (defence in depth).
// DMA descriptors are validated by the reused DataFabric dma_validate inside
// the adapter (zero length, length, alignment, overflow, overlap) plus the
// adapter's REGION rule -- before any bus access -- and come back as DMA_ERR.
//
// ---------------------------------------------------------------- dispatch and ordering
//   * Commands leave the DCR strictly in queue order.
//   * NOP and failed commands: immediate entries (no execution).
//   * DMA: when the DMA unit is free and no address hazard exists against the
//     vector command in flight.  VEC: when the vector unit is free and no
//     hazard exists against the DMA in flight.  So one DMA and one VEC may
//     execute concurrently -- only if their address ranges are independent.
//     Hazard = any overlap of (new writes, old reads), (new reads, old writes)
//     or (new writes, old writes); ranges are exact byte intervals.
//   * KERNEL: only when nothing is in flight; it owns both units until it
//     retires (micro-steps LOAD_A, LOAD_B, LOAD_C, COMPUTE, STORE_D, each
//     waiting for the previous; the first failing step ends the kernel).
//   * FENCE: the command waits until every older command has retired.
//   * Completion records are produced strictly in submission order (ROB).
// ---------------------------------------------------------------- errors / halt
//   With CFG.HALT_ON_ERROR = 1 dispatch stops as soon as an older command is
//   KNOWN to have failed (its record is in the ROB or its unit reports an
//   error), and stays stopped (HALTED) after that record retires, until the
//   host writes RESUME or FLUSH.  A command that was dispatched while the
//   failing one was still executing is independent of it (hazard rule) and
//   completes with its own status.  FLUSH completes every not-yet-dispatched
//   command with CANCELLED, then clears HALTED.
//   quiesce (soft reset in progress): no dispatch, no new unit request.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "hpc_tile_defs.svh"
`default_nettype none

module hpc_tile_sched #(
  parameter int          DW        = 32,
  parameter logic [31:0] SPM_BASE  = 32'h2000_0000,
  parameter int          SPM_BYTES = 65536,
  parameter int          VL_W      = 15,
  parameter int          VL_MAX    = 16384,
  parameter int          EN_FCMP   = 1,
  parameter int          EN_INT    = 1,
  parameter int          RED_EN    = 1,
  parameter int          ROB_DEPTH = 4,
  parameter int          PERF_EN   = 1,
  localparam int SB  = DW / 8,
  localparam int OFF = $clog2(SB),
  localparam int RW  = (ROB_DEPTH > 1) ? $clog2(ROB_DEPTH) : 1,
  localparam int RCW = $clog2(ROB_DEPTH + 1)
) (
  input  wire logic                    clk,
  input  wire logic                    rst_n,
  // ---------------------------------------------------------- command queue head
  input  wire logic                    cq_valid,
  output logic                         cq_ready,
  input  wire logic [`HPC_QDESC_W-1:0] cq_data,
  // ---------------------------------------------------------- control
  input  wire logic                    cfg_halt_on_err,
  input  wire logic                    ctl_resume,
  input  wire logic                    ctl_flush,
  input  wire logic                    quiesce,
  // ---------------------------------------------------------- status
  output logic                         st_busy,
  output logic                         st_halted,
  output logic                         st_flushing,
  output logic                         st_kernel,
  output logic                         st_dma_busy,
  output logic                         st_vec_busy,
  output logic                         ev_hazard_stall,
  output logic                         ev_cplq_stall,
  output logic                         ev_halt_enter,
  // ---------------------------------------------------------- DMA adapter (descriptor / completion)
  output logic                         dma_cmd_valid,
  input  wire logic                    dma_cmd_ready,
  output logic [31:0]                  dma_cmd_src,
  output logic [31:0]                  dma_cmd_dst,
  output logic [31:0]                  dma_cmd_len,
  input  wire logic                    dma_cpl_valid,
  output logic                         dma_cpl_ready,
  input  wire logic                    dma_cpl_err,
  input  wire logic [3:0]              dma_cpl_code,
  input  wire logic [31:0]             dma_cpl_err_addr,
  input  wire logic [31:0]             dma_cpl_bytes,
  // ---------------------------------------------------------- vector unit (hpc_tile_lsu)
  output logic                         job_valid,
  input  wire logic                    job_ready,
  output logic [4:0]                   job_op,
  output logic [2:0]                   job_rm,
  output logic [VL_W-1:0]              job_vl,
  output logic [2:0]                   job_bcast,
  output logic [31:0]                  job_scalar,
  output logic                         job_red,
  output logic [31:0]                  job_a,
  output logic [31:0]                  job_b,
  output logic [31:0]                  job_c,
  output logic [31:0]                  job_d,
  input  wire logic                    done_valid,
  output logic                         done_ready,
  input  wire logic [3:0]              done_status,
  input  wire logic [3:0]              done_detail,
  input  wire logic [31:0]             done_err_addr,
  input  wire logic [4:0]              done_flags,
  input  wire logic [31:0]             done_count,
  input  wire logic [31:0]             done_result,
  // ---------------------------------------------------------- completion records
  output logic                         cpl_valid,
  input  wire logic                    cpl_ready,
  output logic [`HPC_CPL_W-1:0]        cpl_data
);
  if (ROB_DEPTH < 2 || ROB_DEPTH > 16 || (ROB_DEPTH & (ROB_DEPTH - 1)) != 0) begin : g_err_rob
    `SRAM_CFG_FATAL("hpc_tile_sched: ROB_DEPTH must be a power of two 2..16")
  end
  if (SPM_BYTES < 2 * SB || (SPM_BYTES & (SPM_BYTES - 1)) != 0 || (SPM_BASE & 32'(SPM_BYTES - 1)) != 32'd0) begin : g_err_spm
    `SRAM_CFG_FATAL("hpc_tile_sched: SPM_BYTES must be a power of two and SPM_BASE aligned to it")
  end

  // ============================================================ helpers
  function automatic logic [2:0] reads(input logic [4:0] op, input logic [2:0] bc);
    logic [2:0] r;
    r = 3'b001;
    if (op != 5'h00) r[1] = 1'b1;
    if (op >= 5'h04 && op <= 5'h07) r[2] = 1'b1;
    reads = r & ~bc;
  endfunction
  // [s1, s1+l1) and [s2, s2+l2) intersect (empty ranges never do)
  function automatic logic ovl(input logic [31:0] s1, input logic [35:0] l1,
                               input logic [31:0] s2, input logic [35:0] l2);
    ovl = (l1 != '0) && (l2 != '0) &&
          ({4'd0, s1} < {4'd0, s2} + l2) && ({4'd0, s2} < {4'd0, s1} + l1);
  endfunction
  localparam logic [35:0] SPM_LO = {4'd0, SPM_BASE};
  localparam logic [35:0] SPM_HI = {4'd0, SPM_BASE} + 36'(SPM_BYTES);
  function automatic logic in_spm(input logic [31:0] a, input logic [35:0] n);
    in_spm = ({4'd0, a} >= SPM_LO) && ({4'd0, a} + n <= SPM_HI);
  endfunction
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic aligned(input logic [31:0] a);
    aligned = (OFF == 0) || (a[(OFF > 0 ? OFF : 1)-1:0] == '0);
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */
  function automatic logic [31:0] w(input logic [`HPC_QDESC_W-1:0] d, input int i);
    w = d[i*32 +: 32];
  endfunction

  // ============================================================ DCR and decode
  logic                     dcr_v_q;
  logic [`HPC_QDESC_W-1:0]  dcr_q;
  wire [31:0] w0 = dcr_q[31:0];
  wire [3:0]  d_typ   = w0[3:0];
  wire [4:0]  d_vop   = w0[8:4];
  wire [2:0]  d_rm    = w0[11:9];
  wire [2:0]  d_bc    = w0[14:12];
  wire        d_red   = w0[15];
  wire [7:0]  d_tag   = w0[23:16];
  wire        d_fence = w0[24];
  wire [6:0]  d_rsvd  = w0[31:25];
  wire [31:0] d_w1 = w(dcr_q, 1), d_sc = w(dcr_q, 2), d_a = w(dcr_q, 3), d_b = w(dcr_q, 4);
  wire [31:0] d_c  = w(dcr_q, 5), d_d  = w(dcr_q, 6), d_stage = w(dcr_q, 7);
  wire [15:0] d_seq = dcr_q[`HPC_DESC_W +: 16];
  wire [2:0]  d_rd  = reads(d_vop, d_bc);
  wire [35:0] d_bytes = {2'd0, d_w1, 2'b00};                         // vl * 4
  wire [35:0] d_dbytes = d_red ? 36'd4 : d_bytes;                     // VEC destination bytes
  localparam logic [35:0] SBM1 = 36'(SB) - 36'd1;
  wire [35:0] d_str = (d_bytes + SBM1) & ~SBM1;                      // KERNEL region stride
  wire        d_legal = hpc_varray_pkg::cmd_legal(d_vop, d_rm, d_red, d_bc, 1'(EN_FCMP), 1'(EN_INT), 1'(RED_EN));
  wire        is_nop = (d_typ == `HPC_CT_NOP), is_dma = (d_typ == `HPC_CT_DMA);
  wire        is_vec = (d_typ == `HPC_CT_VEC), is_ker = (d_typ == `HPC_CT_KERNEL);

  logic [3:0] d_err;
  always_comb begin
    logic al_bad, rg_bad, ov_bad;
    al_bad = 1'b0; rg_bad = 1'b0; ov_bad = 1'b0;
    if (is_vec) begin
      al_bad = (d_rd[0] && !aligned(d_a)) || (d_rd[1] && !aligned(d_b)) || (d_rd[2] && !aligned(d_c)) || !aligned(d_d);
      rg_bad = (d_rd[0] && !in_spm(d_a, d_bytes)) || (d_rd[1] && !in_spm(d_b, d_bytes)) ||
               (d_rd[2] && !in_spm(d_c, d_bytes)) || !in_spm(d_d, d_dbytes);
      // elementwise: D must equal a source base exactly (in place) or be disjoint from it.
      // reduction: the single result word is stored after every load -> no rule.
      ov_bad = !d_red && ((d_rd[0] && d_d != d_a && ovl(d_d, d_bytes, d_a, d_bytes)) ||
                          (d_rd[1] && d_d != d_b && ovl(d_d, d_bytes, d_b, d_bytes)) ||
                          (d_rd[2] && d_d != d_c && ovl(d_d, d_bytes, d_c, d_bytes)));
    end else if (is_ker) begin
      al_bad = !aligned(d_stage) || (d_rd[0] && !aligned(d_a)) || (d_rd[1] && !aligned(d_b)) ||
               (d_rd[2] && !aligned(d_c)) || !aligned(d_d);
      rg_bad = !in_spm(d_stage, d_str << 2);                       // 4 regions
    end
    if (d_typ > `HPC_CT_LAST)                               d_err = `HPC_ST_BAD_TYPE;
    else if (d_rsvd != '0)                                  d_err = `HPC_ST_BAD_RSVD;
    else if ((is_vec || is_ker) && !d_legal)                d_err = `HPC_ST_BAD_OP;
    else if ((is_vec || is_ker) && (d_w1 == 32'd0 || d_w1 > 32'(VL_MAX))) d_err = `HPC_ST_BAD_VL;
    else if (al_bad)                                        d_err = `HPC_ST_ALIGN;
    else if (rg_bad)                                        d_err = `HPC_ST_SPM_RANGE;
    else if (ov_bad)                                        d_err = `HPC_ST_OVERLAP;
    else                                                    d_err = `HPC_ST_OK;
  end

  // ============================================================ units: request registers and in-flight state
  localparam logic OWN_DISP = 1'b0, OWN_KER = 1'b1;
  logic        dq_v_q;                              // DMA descriptor waiting for the adapter
  logic [31:0] dq_src_q, dq_dst_q, dq_len_q;
  logic        dma_busy_q, dma_own_q;               // a DMA transfer is in flight (until its record is consumed)
  logic        jq_v_q;                              // vector job waiting for the LSU
  logic [4:0]  jq_op_q;
  logic [2:0]  jq_rm_q, jq_bc_q;
  logic [VL_W-1:0] jq_vl_q;
  logic [31:0] jq_sc_q, jq_a_q, jq_b_q, jq_c_q, jq_d_q;
  logic        jq_red_q;
  logic        vec_busy_q, vec_own_q;
  // hazard view of the in-flight commands (dispatch-owned only; a kernel runs alone)
  logic [31:0] hz_dsrc_q, hz_ddst_q;
  logic [35:0] hz_dlen_q;
  logic [31:0] hz_va_q, hz_vb_q, hz_vc_q, hz_vd_q;
  logic [2:0]  hz_vrd_q;
  logic [35:0] hz_vbytes_q, hz_vdbytes_q;

  assign dma_cmd_valid = dq_v_q;
  assign dma_cmd_src   = dq_src_q;
  assign dma_cmd_dst   = dq_dst_q;
  assign dma_cmd_len   = dq_len_q;
  assign job_valid  = jq_v_q;
  assign job_op     = jq_op_q;
  assign job_rm     = jq_rm_q;
  assign job_vl     = jq_vl_q;
  assign job_bcast  = jq_bc_q;
  assign job_scalar = jq_sc_q;
  assign job_red    = jq_red_q;
  assign job_a      = jq_a_q;
  assign job_b      = jq_b_q;
  assign job_c      = jq_c_q;
  assign job_d      = jq_d_q;

  // ============================================================ ROB
  logic [1:0]  rob_kind [ROB_DEPTH];               // 0 IMM, 1 DMA, 2 VEC, 3 KERNEL
  logic [3:0]  rob_st   [ROB_DEPTH];               // IMM status
  logic [7:0]  rob_tag  [ROB_DEPTH];
  logic [3:0]  rob_typ  [ROB_DEPTH];
  logic [15:0] rob_seq  [ROB_DEPTH];
  logic [31:0] rob_ts   [ROB_DEPTH];
  logic [RW-1:0]  rh_q, rt_q;
  logic [RCW-1:0] rc_q;
  localparam logic [1:0] RK_IMM = 2'd0, RK_DMA = 2'd1, RK_VEC = 2'd2, RK_KER = 2'd3;
  wire rob_empty = (rc_q == '0);
  wire rob_free  = (rc_q < RCW'(ROB_DEPTH));

  // ============================================================ kernel sequencer state
  localparam logic [2:0] KS_IDLE = 3'd0, KS_LA = 3'd1, KS_LB = 3'd2, KS_LC = 3'd3, KS_CMP = 3'd4,
                         KS_SD = 3'd5, KS_FIN = 3'd6;
  logic [2:0]  ks_q;
  logic        k_iss_q;
  logic [4:0]  k_vop_q;
  logic [2:0]  k_rm_q, k_bc_q, k_rd_q;
  logic        k_red_q;
  logic [31:0] k_vl_q, k_sc_q, k_a_q, k_b_q, k_c_q, k_d_q, k_stage_q, k_str_q;
  logic [3:0]  k_st_q, k_det_q;
  logic [2:0]  k_step_q;
  logic [4:0]  k_fl_q;
  logic [31:0] k_cnt_q, k_res_q, k_ea_q;
  wire kernel_busy = (ks_q != KS_IDLE);

  // ============================================================ timestamps
  logic [31:0] ts_q;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) ts_q <= '0; else if (PERF_EN != 0) ts_q <= ts_q + 1'b1;

  // ============================================================ halt / flush state
  logic halted_q, flushing_q;
  // an older command is known to have failed (record in the ROB or waiting in a unit)
  logic err_known;
  always_comb begin
    err_known = 1'b0;
    for (int i = 0; i < ROB_DEPTH; i++)
      if (RCW'(i) < rc_q && rob_kind[RW'(rh_q + RW'(i))] == RK_IMM &&
          rob_st[RW'(rh_q + RW'(i))] != `HPC_ST_OK && rob_st[RW'(rh_q + RW'(i))] != `HPC_ST_CANCELLED)
        err_known = 1'b1;
    if (dma_busy_q && dma_own_q == OWN_DISP && dma_cpl_valid && dma_cpl_err) err_known = 1'b1;
    if (vec_busy_q && vec_own_q == OWN_DISP && done_valid && done_status != `HPC_ST_OK) err_known = 1'b1;
  end
  wire blocked = halted_q || (cfg_halt_on_err && err_known) || quiesce;

  // ============================================================ hazards against the in-flight other-unit command
  wire hz_dma = vec_busy_q && vec_own_q == OWN_DISP && (
                  (hz_vrd_q[0] && ovl(d_b, {4'd0, d_w1}, hz_va_q, hz_vbytes_q)) ||
                  (hz_vrd_q[1] && ovl(d_b, {4'd0, d_w1}, hz_vb_q, hz_vbytes_q)) ||
                  (hz_vrd_q[2] && ovl(d_b, {4'd0, d_w1}, hz_vc_q, hz_vbytes_q)) ||
                  ovl(d_b, {4'd0, d_w1}, hz_vd_q, hz_vdbytes_q) ||                 // WAW
                  ovl(d_a, {4'd0, d_w1}, hz_vd_q, hz_vdbytes_q));                   // RAW (DMA reads VEC's result)
  wire hz_vec = dma_busy_q && dma_own_q == OWN_DISP && (
                  ovl(d_d, d_dbytes, hz_dsrc_q, hz_dlen_q) ||                        // WAR
                  ovl(d_d, d_dbytes, hz_ddst_q, hz_dlen_q) ||                        // WAW
                  (d_rd[0] && ovl(d_a, d_bytes, hz_ddst_q, hz_dlen_q)) ||           // RAW
                  (d_rd[1] && ovl(d_b, d_bytes, hz_ddst_q, hz_dlen_q)) ||
                  (d_rd[2] && ovl(d_c, d_bytes, hz_ddst_q, hz_dlen_q)));

  // ============================================================ dispatch decision
  wire go_base  = dcr_v_q && rob_free && !kernel_busy && (!d_fence || rob_empty);
  wire d_cancel = dcr_v_q && rob_free && flushing_q && !quiesce;
  wire d_imm    = !flushing_q && !blocked && go_base && (d_err != `HPC_ST_OK || is_nop);
  wire d_dma    = !flushing_q && !blocked && go_base && d_err == `HPC_ST_OK && is_dma &&
                  !dma_busy_q && !dq_v_q && !hz_dma;
  wire d_vec    = !flushing_q && !blocked && go_base && d_err == `HPC_ST_OK && is_vec &&
                  !vec_busy_q && !jq_v_q && !hz_vec;
  wire d_ker    = !flushing_q && !blocked && go_base && d_err == `HPC_ST_OK && is_ker && rob_empty &&
                  !dma_busy_q && !vec_busy_q && !dq_v_q && !jq_v_q;
  wire dispatch = d_cancel || d_imm || d_dma || d_vec || d_ker;
  assign cq_ready = !quiesce && (!dcr_v_q || dispatch);
  assign ev_hazard_stall = !flushing_q && !blocked && go_base && d_err == `HPC_ST_OK &&
                           ((is_dma && !dma_busy_q && !dq_v_q && hz_dma) || (is_vec && !vec_busy_q && !jq_v_q && hz_vec));

  // ============================================================ retirement
  wire [1:0]  h_kind = rob_kind[rh_q];
  logic       h_ready;
  logic [3:0] r_st, r_det;
  logic [2:0] r_step;
  logic [4:0] r_fl;
  logic [31:0] r_cnt, r_res, r_ea;
  always_comb begin
    h_ready = 1'b0; r_st = rob_st[rh_q]; r_det = '0; r_step = `HPC_KS_NONE; r_fl = '0;
    r_cnt = '0; r_res = '0; r_ea = '0;
    case (h_kind)
      RK_IMM: h_ready = 1'b1;
      RK_DMA: begin
        h_ready = dma_busy_q && dma_own_q == OWN_DISP && dma_cpl_valid;
        r_st  = dma_cpl_err ? `HPC_ST_DMA_ERR : `HPC_ST_OK;
        r_det = dma_cpl_code; r_cnt = dma_cpl_bytes; r_ea = dma_cpl_err ? dma_cpl_err_addr : 32'd0;
      end
      RK_VEC: begin
        h_ready = vec_busy_q && vec_own_q == OWN_DISP && done_valid;
        r_st = done_status; r_det = done_detail; r_fl = done_flags; r_cnt = done_count;
        r_res = done_result; r_ea = done_err_addr;
      end
      default: begin
        h_ready = (ks_q == KS_FIN);
        r_st = k_st_q; r_det = k_det_q; r_step = k_step_q; r_fl = k_fl_q; r_cnt = k_cnt_q;
        r_res = k_res_q; r_ea = k_ea_q;
      end
    endcase
  end
  assign cpl_valid = !rob_empty && h_ready;
  wire retire = cpl_valid && cpl_ready;
  wire [31:0] r_cyc = (PERF_EN != 0) ? (ts_q - rob_ts[rh_q]) : 32'd0;
  always_comb begin
    cpl_data = '0;
    cpl_data[`HPC_CPL_TAG_LSB    +: 8]  = rob_tag[rh_q];
    cpl_data[`HPC_CPL_STATUS_LSB +: 4]  = r_st;
    cpl_data[`HPC_CPL_TYPE_LSB   +: 4]  = rob_typ[rh_q];
    cpl_data[`HPC_CPL_DETAIL_LSB +: 4]  = r_det;
    cpl_data[`HPC_CPL_FLAGS_LSB  +: 5]  = r_fl;
    cpl_data[`HPC_CPL_STEP_LSB   +: 3]  = r_step;
    cpl_data[`HPC_CPL_SEQ_LSB    +: 16] = rob_seq[rh_q];
    cpl_data[`HPC_CPL_COUNT_LSB  +: 32] = r_cnt;
    cpl_data[`HPC_CPL_RESULT_LSB +: 32] = r_res;
    cpl_data[`HPC_CPL_EADDR_LSB  +: 32] = r_ea;
    cpl_data[`HPC_CPL_CYCLES_LSB +: 32] = r_cyc;
  end
  assign ev_cplq_stall = !rob_empty && h_ready && !cpl_ready;
  wire ret_err = retire && r_st != `HPC_ST_OK && r_st != `HPC_ST_CANCELLED;
  assign ev_halt_enter = ret_err && cfg_halt_on_err && !halted_q;

  // unit records consumed: by retirement (dispatch-owned) or by the kernel sequencer
  wire k_dma_take = dma_busy_q && dma_own_q == OWN_KER && dma_cpl_valid;
  wire k_vec_take = vec_busy_q && vec_own_q == OWN_KER && done_valid;
  assign dma_cpl_ready = (retire && h_kind == RK_DMA) || k_dma_take;
  assign done_ready    = (retire && h_kind == RK_VEC) || k_vec_take;

  // ============================================================ status
  assign st_busy     = dcr_v_q || cq_valid || !rob_empty || dma_busy_q || vec_busy_q || kernel_busy || dq_v_q || jq_v_q;
  assign st_halted   = halted_q;
  assign st_flushing = flushing_q;
  assign st_kernel   = kernel_busy;
  assign st_dma_busy = dma_busy_q;
  assign st_vec_busy = vec_busy_q;

  // ============================================================ kernel next step
  function automatic logic [2:0] k_first(input logic [2:0] rd);
    k_first = rd[0] ? KS_LA : rd[1] ? KS_LB : rd[2] ? KS_LC : KS_CMP;
  endfunction
  /* verilator lint_off UNUSEDSIGNAL */
  function automatic logic [2:0] k_after(input logic [2:0] s, input logic [2:0] rd);
    case (s)
      KS_LA:   k_after = rd[1] ? KS_LB : rd[2] ? KS_LC : KS_CMP;
      KS_LB:   k_after = rd[2] ? KS_LC : KS_CMP;
      KS_LC:   k_after = KS_CMP;
      KS_CMP:  k_after = KS_SD;
      default: k_after = KS_FIN;
    endcase
  endfunction
  /* verilator lint_on UNUSEDSIGNAL */
  wire [2:0] k_step_code = (ks_q == KS_LA) ? `HPC_KS_LOAD_A : (ks_q == KS_LB) ? `HPC_KS_LOAD_B :
                           (ks_q == KS_LC) ? `HPC_KS_LOAD_C : (ks_q == KS_CMP) ? `HPC_KS_COMPUTE : `HPC_KS_STORE_D;
  wire k_dma_step = (ks_q == KS_LA) || (ks_q == KS_LB) || (ks_q == KS_LC) || (ks_q == KS_SD);
  wire k_issue_dma = k_dma_step && !k_iss_q && !quiesce && !dq_v_q && !dma_busy_q;
  wire k_issue_vec = (ks_q == KS_CMP) && !k_iss_q && !quiesce && !jq_v_q && !vec_busy_q;
  logic [31:0] k_src, k_dst, k_len;
  always_comb begin
    k_src = k_a_q; k_dst = k_stage_q; k_len = k_vl_q << 2;
    case (ks_q)
      KS_LB:   begin k_src = k_b_q; k_dst = k_stage_q + k_str_q; end
      KS_LC:   begin k_src = k_c_q; k_dst = k_stage_q + {k_str_q[30:0], 1'b0}; end
      KS_SD:   begin k_src = k_stage_q + {k_str_q[30:0], 1'b0} + k_str_q; k_dst = k_d_q;
                     k_len = k_red_q ? 32'd4 : (k_vl_q << 2); end
      default: ;
    endcase
  end

  // ============================================================ sequential
  always_ff @(posedge clk) begin
    if (dispatch) begin
      rob_kind[rt_q] <= d_dma ? RK_DMA : d_vec ? RK_VEC : d_ker ? RK_KER : RK_IMM;
      rob_st[rt_q]   <= d_cancel ? `HPC_ST_CANCELLED : d_err;
      rob_tag[rt_q]  <= d_tag;
      rob_typ[rt_q]  <= d_typ;
      rob_seq[rt_q]  <= d_seq;
      rob_ts[rt_q]   <= ts_q;
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      dcr_v_q <= 1'b0; dcr_q <= '0;
      rh_q <= '0; rt_q <= '0; rc_q <= '0;
      halted_q <= 1'b0; flushing_q <= 1'b0;
      dq_v_q <= 1'b0; dq_src_q <= '0; dq_dst_q <= '0; dq_len_q <= '0; dma_busy_q <= 1'b0; dma_own_q <= OWN_DISP;
      jq_v_q <= 1'b0; jq_op_q <= '0; jq_rm_q <= '0; jq_bc_q <= '0; jq_vl_q <= '0; jq_sc_q <= '0;
      jq_a_q <= '0; jq_b_q <= '0; jq_c_q <= '0; jq_d_q <= '0; jq_red_q <= 1'b0;
      vec_busy_q <= 1'b0; vec_own_q <= OWN_DISP;
      hz_dsrc_q <= '0; hz_ddst_q <= '0; hz_dlen_q <= '0;
      hz_va_q <= '0; hz_vb_q <= '0; hz_vc_q <= '0; hz_vd_q <= '0; hz_vrd_q <= '0; hz_vbytes_q <= '0; hz_vdbytes_q <= '0;
      ks_q <= KS_IDLE; k_iss_q <= 1'b0;
      k_vop_q <= '0; k_rm_q <= '0; k_bc_q <= '0; k_rd_q <= '0; k_red_q <= 1'b0;
      k_vl_q <= '0; k_sc_q <= '0; k_a_q <= '0; k_b_q <= '0; k_c_q <= '0; k_d_q <= '0; k_stage_q <= '0; k_str_q <= '0;
      k_st_q <= '0; k_det_q <= '0; k_step_q <= '0; k_fl_q <= '0; k_cnt_q <= '0; k_res_q <= '0; k_ea_q <= '0;
    end else begin
      // ---------------- DCR
      if (cq_ready) begin
        dcr_v_q <= cq_valid;
        if (cq_valid) dcr_q <= cq_data;
      end else if (dispatch) dcr_v_q <= 1'b0;
      // ---------------- ROB pointers
      if (dispatch) rt_q <= rt_q + 1'b1;
      if (retire)   rh_q <= rh_q + 1'b1;
      rc_q <= rc_q + RCW'(dispatch) - RCW'(retire);
      // ---------------- halt / flush
      if (ctl_flush) flushing_q <= 1'b1;
      else if (flushing_q && !dcr_v_q && !cq_valid) begin flushing_q <= 1'b0; halted_q <= 1'b0; end
      if (ret_err && cfg_halt_on_err) halted_q <= 1'b1;
      else if (ctl_resume) halted_q <= 1'b0;
      // ---------------- DMA unit
      if (dq_v_q && dma_cmd_ready) dq_v_q <= 1'b0;
      if (dma_cpl_valid && dma_cpl_ready) dma_busy_q <= 1'b0;
      if (d_dma) begin
        dq_v_q <= 1'b1; dq_src_q <= d_a; dq_dst_q <= d_b; dq_len_q <= d_w1;
        dma_busy_q <= 1'b1; dma_own_q <= OWN_DISP;
        hz_dsrc_q <= d_a; hz_ddst_q <= d_b; hz_dlen_q <= {4'd0, d_w1};
      end else if (k_issue_dma) begin
        dq_v_q <= 1'b1; dq_src_q <= k_src; dq_dst_q <= k_dst; dq_len_q <= k_len;
        dma_busy_q <= 1'b1; dma_own_q <= OWN_KER;
      end
      // ---------------- vector unit
      if (jq_v_q && job_ready) jq_v_q <= 1'b0;
      if (done_valid && done_ready) vec_busy_q <= 1'b0;
      if (d_vec) begin
        jq_v_q <= 1'b1; jq_op_q <= d_vop; jq_rm_q <= d_rm; jq_bc_q <= d_bc; jq_vl_q <= VL_W'(d_w1);
        jq_sc_q <= d_sc; jq_a_q <= d_a; jq_b_q <= d_b; jq_c_q <= d_c; jq_d_q <= d_d; jq_red_q <= d_red;
        vec_busy_q <= 1'b1; vec_own_q <= OWN_DISP;
        hz_va_q <= d_a; hz_vb_q <= d_b; hz_vc_q <= d_c; hz_vd_q <= d_d; hz_vrd_q <= d_rd;
        hz_vbytes_q <= d_bytes; hz_vdbytes_q <= d_dbytes;
      end else if (k_issue_vec) begin
        jq_v_q <= 1'b1; jq_op_q <= k_vop_q; jq_rm_q <= k_rm_q; jq_bc_q <= k_bc_q; jq_vl_q <= VL_W'(k_vl_q);
        jq_sc_q <= k_sc_q; jq_a_q <= k_stage_q; jq_b_q <= k_stage_q + k_str_q;
        jq_c_q <= k_stage_q + {k_str_q[30:0], 1'b0}; jq_d_q <= k_stage_q + {k_str_q[30:0], 1'b0} + k_str_q;
        jq_red_q <= k_red_q;
        vec_busy_q <= 1'b1; vec_own_q <= OWN_KER;
      end
      // ---------------- kernel sequencer
      case (ks_q)
        KS_IDLE: if (d_ker) begin
          k_vop_q <= d_vop; k_rm_q <= d_rm; k_bc_q <= d_bc; k_rd_q <= d_rd; k_red_q <= d_red;
          k_vl_q <= d_w1; k_sc_q <= d_sc; k_a_q <= d_a; k_b_q <= d_b; k_c_q <= d_c; k_d_q <= d_d;
          k_stage_q <= d_stage; k_str_q <= d_str[31:0];
          k_st_q <= `HPC_ST_OK; k_det_q <= '0; k_step_q <= `HPC_KS_NONE; k_fl_q <= '0;
          k_cnt_q <= '0; k_res_q <= '0; k_ea_q <= '0; k_iss_q <= 1'b0;
          ks_q <= k_first(d_rd);
        end
        KS_FIN: if (retire && h_kind == RK_KER) ks_q <= KS_IDLE;
        default: begin
          if (k_issue_dma || k_issue_vec) k_iss_q <= 1'b1;
          if (k_dma_take) begin
            k_iss_q <= 1'b0;
            if (dma_cpl_err) begin
              k_st_q <= `HPC_ST_DMA_ERR; k_det_q <= dma_cpl_code; k_ea_q <= dma_cpl_err_addr;
              k_step_q <= k_step_code; ks_q <= KS_FIN;
            end else ks_q <= k_after(ks_q, k_rd_q);
          end
          if (k_vec_take) begin
            k_iss_q <= 1'b0;
            k_fl_q <= done_flags; k_cnt_q <= done_count; k_res_q <= done_result;
            if (done_status != `HPC_ST_OK) begin
              k_st_q <= done_status; k_det_q <= done_detail; k_ea_q <= done_err_addr;
              k_step_q <= `HPC_KS_COMPUTE; ks_q <= KS_FIN;
            end else ks_q <= KS_SD;
          end
        end
      endcase
    end
  end

`ifdef HPC_TILE_ASSERT
  always_ff @(posedge clk) if (rst_n) begin
    if (dispatch && !rob_free) $fatal(1, "hpc_tile_sched: dispatch into a full ROB");
    if (retire && rob_empty)   $fatal(1, "hpc_tile_sched: retirement from an empty ROB");
    if ((d_dma && k_issue_dma) || (d_vec && k_issue_vec)) $fatal(1, "hpc_tile_sched: unit request conflict");
    if (dma_cpl_valid && !dma_busy_q) $fatal(1, "hpc_tile_sched: unsolicited DMA completion");
    if (done_valid && !vec_busy_q)    $fatal(1, "hpc_tile_sched: unsolicited vector completion");
    if ($onehot0({d_cancel, d_imm, d_dma, d_vec, d_ker}) == 1'b0) $fatal(1, "hpc_tile_sched: multiple dispatch");
  end
`endif
endmodule

`default_nettype wire
