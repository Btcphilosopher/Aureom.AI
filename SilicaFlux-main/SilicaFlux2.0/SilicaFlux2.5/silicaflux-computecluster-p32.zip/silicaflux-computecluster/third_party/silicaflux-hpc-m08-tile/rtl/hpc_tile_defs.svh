// =============================================================================
// SilicaFlux-HPC Module 08 :: hpc_tile_defs.svh
// Shared definitions of the SilicaFlux-HPC compute tile (silicaflux_hpc_tile):
// command-descriptor encoding, completion-record layout, status codes,
// register map and performance-counter map.  Aureom.AI | SilicaFlux-HPC.
//
// A `define header, not a package, for the reason given by DataFabric's
// dma_defs.svh and the SRAM Wrapper Library's sram_defs.svh: Yosys 0.33 cannot
// resolve package references in module parameter lists.  The C header
// sw/include/hpc_tile_regs.h and the Python model model/tile_defs.py are
// generated from this file by scripts/gen_headers.py (never edit them by hand)
// -- one source of truth for hardware, firmware and the reference model.
//
// Rules: never renumber, only append.
// =============================================================================
`ifndef HPC_TILE_DEFS_SVH
`define HPC_TILE_DEFS_SVH

// ------------------------------------------------------------ identification
`define HPC_TILE_ID            32'h5346_4854   // "SFHT"
`define HPC_TILE_VERSION       32'h0001_0000   // 1.0

// ------------------------------------------------------------ command descriptor
// A command is 8 little-endian 32-bit words W0..W7 (256 bits), written to the
// CMD0..CMD7 staging registers and submitted by a write to DOORBELL.
//
// W0  [3:0]   TYPE     command type (HPC_CT_*)
//     [8:4]   VOP      element operation (Module 02 hpc_vector_pkg encoding)
//     [11:9]  RM       rounding mode (RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4)
//     [14:12] BCAST    {c,b,a}: replace that operand of every element by SCALAR
//     [15]    RED      1 = sum-reduce the element results (Module 03 sec. 9.3)
//     [23:16] TAG      host tag, echoed in the completion record
//     [24]    FENCE    start only after every older command has completed
//     [31:25] reserved, must be 0
// W1  VL (elements; VEC, KERNEL)  |  LEN (bytes; DMA)
// W2  SCALAR (broadcast scalar; reduction initial value)
// W3  A   VEC: scratchpad address   KERNEL: host address   DMA: SRC
// W4  B   VEC: scratchpad address   KERNEL: host address   DMA: DST
// W5  C   VEC: scratchpad address   KERNEL: host address
// W6  D   VEC: scratchpad address   KERNEL: host address (result)
// W7  STAGE  KERNEL: scratchpad staging base (4 regions of STRIDE bytes)
// Words a command type does not use are ignored.
`define HPC_CT_NOP             4'd0
`define HPC_CT_DMA             4'd1
`define HPC_CT_VEC             4'd2
`define HPC_CT_KERNEL          4'd3
`define HPC_CT_LAST            4'd3            // TYPE > LAST -> BAD_TYPE

`define HPC_DESC_W             256
`define HPC_SEQ_W              16
`define HPC_QDESC_W            272             // {seq[15:0], W7..W0} in the command queue

// ------------------------------------------------------------ completion status (STATUS field, 4 bits)
//  0 OK          executed; every write of the command acknowledged by its target
//  1 BAD_TYPE    TYPE reserved                                   (nothing executed)
//  2 BAD_RSVD    W0 reserved bits not zero                       (nothing executed)
//  3 BAD_OP      VOP/RM/RED/BCAST combination illegal (hpc_varray_pkg::cmd_legal)
//  4 BAD_VL      VL = 0 or VL > VL_MAX                           (nothing executed)
//  5 SPM_RANGE   a scratchpad range outside the scratchpad window (nothing executed)
//  6 ALIGN       a vector base address not DATA_WIDTH/8 aligned   (nothing executed)
//  7 OVERLAP     VEC destination partially overlaps a source      (nothing executed)
//  8 DMA_ERR     a DMA transfer failed; DETAIL = DMA completion code (hpc_dma_defs.svh)
//  9 SPM_ERR     the scratchpad answered a vector access with an error; DETAIL = code
// 10 ARRAY_ILL   the vector array reported the command illegal (defence in depth;
//                unreachable while the scheduler's legality check is in place)
// 11 CANCELLED   discarded by FLUSH before execution
`define HPC_ST_OK              4'd0
`define HPC_ST_BAD_TYPE        4'd1
`define HPC_ST_BAD_RSVD        4'd2
`define HPC_ST_BAD_OP          4'd3
`define HPC_ST_BAD_VL          4'd4
`define HPC_ST_SPM_RANGE       4'd5
`define HPC_ST_ALIGN           4'd6
`define HPC_ST_OVERLAP         4'd7
`define HPC_ST_DMA_ERR         4'd8
`define HPC_ST_SPM_ERR         4'd9
`define HPC_ST_ARRAY_ILL       4'd10
`define HPC_ST_CANCELLED       4'd11

// KERNEL step that produced the final status (STEP field)
`define HPC_KS_NONE            3'd0
`define HPC_KS_LOAD_A          3'd1
`define HPC_KS_LOAD_B          3'd2
`define HPC_KS_LOAD_C          3'd3
`define HPC_KS_COMPUTE         3'd4
`define HPC_KS_STORE_D         3'd5

// ------------------------------------------------------------ completion record (internal, CPL queue entry)
`define HPC_CPL_TAG_LSB        0     // [7:0]
`define HPC_CPL_STATUS_LSB     8     // [11:8]
`define HPC_CPL_TYPE_LSB       12    // [15:12]
`define HPC_CPL_DETAIL_LSB     16    // [19:16]
`define HPC_CPL_FLAGS_LSB      20    // [24:20]  {NV,DZ,OF,UF,NX}
`define HPC_CPL_STEP_LSB       25    // [27:25]
`define HPC_CPL_SEQ_LSB        28    // [43:28]
`define HPC_CPL_COUNT_LSB      44    // [75:44]  elements (VEC/KERNEL) or bytes (DMA)
`define HPC_CPL_RESULT_LSB     76    // [107:76] reduction result
`define HPC_CPL_EADDR_LSB      108   // [139:108]
`define HPC_CPL_CYCLES_LSB     140   // [171:140] dispatch -> retirement, cycles
`define HPC_CPL_W              172

// ------------------------------------------------------------ register map (one 4 KiB register-bus page)
// SilicaFlux-V register bus (sfv_periph_bridge): 32-bit registers only.
// Unmapped offsets and writes to read-only registers answer rb_err = 1 and
// have no effect.  No read side effects anywhere.
`define HPC_REG_ID             12'h000   // RO  "SFHT"
`define HPC_REG_VERSION        12'h004   // RO
`define HPC_REG_CONFIG0        12'h008   // RO  [7:0] NUM_LANES [15:8] DATA_WIDTH/8 [20:16] log2(SCRATCHPAD_BYTES)
                                          //     [25:21] NUM_BANKS [26] PERF [27] DMA buffered [28] host SPM port
                                          //     [31:29] LSU ports - 1
`define HPC_REG_CONFIG1        12'h00C   // RO  [7:0] CMD_QUEUE_DEPTH [15:8] CPL_QUEUE_DEPTH
                                          //     [23:16] log2(DMA_BUFFER_DEPTH) (0 = simple engine) [31:24] perf counters
`define HPC_REG_SPM_BASE       12'h010   // RO  scratchpad window base (tile and host view)
`define HPC_REG_VL_MAX         12'h014   // RO  largest legal VL
`define HPC_REG_CTRL           12'h020   // WO  pulses: [0] SOFT_RESET [1] RESUME [2] FLUSH [3] PERF_CLEAR (reads 0)
`define HPC_REG_CFG            12'h024   // RW  [0] HALT_ON_ERROR (reset 1) [1] PERF_FREEZE (reset 0)
`define HPC_REG_STATUS         12'h028   // RO/W1C  [0] BUSY [1] HALTED [2] FLUSHING [3] SOFT_RESET
                                          //     [4] CMDQ_FULL [5] CPL_VALID [6] SUBMIT_OVF (W1C) [7] ERR (W1C)
                                          //     [8] DMA_ACTIVE [9] VEC_ACTIVE [10] KERNEL_ACTIVE
                                          //     [23:16] CMDQ level [31:24] CPLQ level
`define HPC_REG_IRQ_EN         12'h030   // RW  [0] CPL [1] ERR [2] HALT
`define HPC_REG_IRQ_STATUS     12'h034   // W1C [0] completion pushed [1] error completion pushed [2] halt entered
`define HPC_REG_SUBMITTED      12'h038   // RO  commands accepted since hard reset (= next SEQ, 16 LSBs)
`define HPC_REG_CMDQ_FREE      12'h03C   // RO  free command-queue slots
`define HPC_REG_CPL_INFO       12'h040   // RO  head record: [7:0] TAG [11:8] STATUS [15:12] TYPE [19:16] DETAIL
                                          //     [24:20] FFLAGS [27:25] STEP [31] VALID (0: queue empty, all fields 0)
`define HPC_REG_CPL_SEQ        12'h044   // RO  [15:0] SEQ
`define HPC_REG_CPL_COUNT      12'h048   // RO  elements (VEC/KERNEL) or bytes acknowledged (DMA)
`define HPC_REG_CPL_RESULT     12'h04C   // RO  reduction result
`define HPC_REG_CPL_ERR_ADDR   12'h050   // RO  failing address (DMA_ERR, SPM_ERR)
`define HPC_REG_CPL_CYCLES     12'h054   // RO  dispatch -> retirement cycles (0 with ENABLE_PERF_COUNTERS = 0)
`define HPC_REG_CPL_POP        12'h058   // WO  pop the head record (no effect when empty)
`define HPC_REG_CMD0           12'h080   // RW  CMD0..CMD7 staging = W0..W7 (0x080..0x09C)
`define HPC_REG_DOORBELL       12'h0A0   // WO  submit CMD0..7; queue full / soft reset -> rb_err, SUBMIT_OVF, not queued
`define HPC_REG_PERF0          12'h100   // RO  PERF[i] at 0x100 + 4 i

`define HPC_CTRL_SOFT_RESET    0
`define HPC_CTRL_RESUME        1
`define HPC_CTRL_FLUSH         2
`define HPC_CTRL_PERF_CLEAR    3
`define HPC_CFG_HALT_ON_ERROR  0
`define HPC_CFG_PERF_FREEZE    1
`define HPC_IRQ_CPL            0
`define HPC_IRQ_ERR            1
`define HPC_IRQ_HALT           2

// ------------------------------------------------------------ performance counters (PERF[i], 32-bit, saturating)
`define HPC_PC_CYCLES          0    // cycles since clear (not frozen-gated: counts while enabled)
`define HPC_PC_BUSY            1    // cycles STATUS.BUSY = 1
`define HPC_PC_SUBMITTED       2    // commands accepted by DOORBELL
`define HPC_PC_COMPLETED       3    // completion records pushed (every status)
`define HPC_PC_ERRORS          4    // completion records with STATUS not OK and not CANCELLED
`define HPC_PC_CANCELLED       5    // completion records with STATUS CANCELLED
`define HPC_PC_DMA_ACTIVE      6    // cycles the DMA engine executes a transfer
`define HPC_PC_DMA_BYTES_RD    7    // bytes read by error-free DMA read responses
`define HPC_PC_DMA_BYTES_WR    8    // bytes committed by error-free DMA write responses
`define HPC_PC_VEC_ACTIVE      9    // cycles the vector unit (LSU + array) holds a job
`define HPC_PC_VEC_ELEMS       10   // active elements computed (array completion count)
`define HPC_PC_VEC_FLOPS       11   // elements x {FADD/FSUB/FMUL: 1, FMA family: 2, other: 0}
`define HPC_PC_LSU_LOADS       12   // scratchpad load requests accepted from the LSU
`define HPC_PC_LSU_STORES      13   // scratchpad store requests accepted from the LSU
`define HPC_PC_SPM_CONFLICTS   14   // scratchpad port-cycles lost to bank arbitration (all ports)
`define HPC_PC_OVERLAP         15   // cycles DMA engine and vector unit are both active
`define HPC_PC_HAZARD_STALL    16   // cycles the next command waits only for an address hazard
`define HPC_PC_HALTED          17   // cycles the scheduler is halted
`define HPC_PC_CMDQ_FULL       18   // cycles the command queue is full
`define HPC_PC_CPLQ_STALL      19   // cycles retirement waits for completion-queue space
`define HPC_PC_HOST_SPM        20   // host scratchpad-port requests accepted
`define HPC_PC_DMA_CMDS        21   // DMA commands completed OK
`define HPC_PC_VEC_CMDS        22   // VEC commands completed OK
`define HPC_PC_KERNEL_CMDS     23   // KERNEL commands completed OK
`define HPC_NUM_PC             24

`endif // HPC_TILE_DEFS_SVH
