// =============================================================================
// SilicaFlux-HPC Module 06 (minimal) :: hpc_command_queue
// In-order valid/ready queue for tile command descriptors (and, reused with a
// different WIDTH, for completion records).  Aureom.AI | SilicaFlux-HPC.
//
// No hpc_command_queue existed in the repository (Module 08 audit,
// docs/00_repository_audit.md); this is the smallest legitimate implementation
// the tile needs, verified on its own (tb/tb_hpc_command_queue.sv) before the
// tile uses it.
//
//   in : in_valid / in_ready, in_data       push at an edge with in_valid && in_ready
//   out: out_valid / out_ready, out_data    pop  at an edge with out_valid && out_ready
//   level = entries held; full = (level == DEPTH); empty = (level == 0)
//
// Contract
//   * strictly first-in first-out; no entry is dropped, duplicated or reordered;
//   * first-word fall-through: out_data is the oldest entry whenever out_valid;
//   * in_ready = !full and out_valid = !empty are functions of registered state
//     only (no combinational path in_valid -> out_valid or out_ready -> in_ready);
//     a push and a pop in the same cycle are both performed when 0 < level < DEPTH;
//     a full queue accepts again from the cycle after a pop;
//   * out_data is held stable while out_valid && !out_ready;
//   * reset (asynchronous assert, synchronous release -- SilicaFlux convention)
//     empties the queue; the storage array itself is not reset (datapath rule)
//     and is never observable while empty.
// Storage is an array with one write port and an asynchronous read port, which
// FPGA tools map to distributed RAM and ASIC flows to flip-flops / a register
// file.  DEPTH is a power of two (2..256).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module hpc_command_queue #(
  parameter int WIDTH = 272,
  parameter int DEPTH = 8,
  localparam int AW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int CW   = $clog2(DEPTH + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             in_valid,
  output logic                  in_ready,
  input  wire logic [WIDTH-1:0] in_data,
  output logic                  out_valid,
  input  wire logic             out_ready,
  output logic [WIDTH-1:0]      out_data,
  output logic [CW-1:0]         level,
  output logic                  full,
  output logic                  empty
);
  if (DEPTH < 2 || DEPTH > 256 || (DEPTH & (DEPTH - 1)) != 0) begin : g_err_depth
    `SRAM_CFG_FATAL("hpc_command_queue: DEPTH must be a power of two 2..256")
  end
  if (WIDTH < 1) begin : g_err_width
    `SRAM_CFG_FATAL("hpc_command_queue: WIDTH must be >= 1")
  end

  logic [WIDTH-1:0] mem [DEPTH];
  logic [AW-1:0]    wp_q, rp_q;
  logic [CW-1:0]    cnt_q;

  assign full      = (cnt_q == CW'(DEPTH));
  assign empty     = (cnt_q == '0);
  assign in_ready  = !full;
  assign out_valid = !empty;
  assign level     = cnt_q;
  assign out_data  = mem[rp_q];

  wire push = in_valid && !full;
  wire pop  = out_ready && !empty;

  always_ff @(posedge clk) begin
    if (push) mem[wp_q] <= in_data;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      wp_q  <= '0;
      rp_q  <= '0;
      cnt_q <= '0;
    end else begin
      if (push) wp_q <= wp_q + 1'b1;
      if (pop)  rp_q <= rp_q + 1'b1;
      case ({push, pop})
        2'b10:   cnt_q <= cnt_q + 1'b1;
        2'b01:   cnt_q <= cnt_q - 1'b1;
        default: cnt_q <= cnt_q;
      endcase
    end
  end

`ifdef HPC_TILE_ASSERT
  always_ff @(posedge clk) begin
    if (rst_n && cnt_q > CW'(DEPTH)) $fatal(1, "hpc_command_queue: level %0d > DEPTH", cnt_q);
  end
`endif
endmodule

`default_nettype wire
