#!/usr/bin/env python3
"""Project 32 ComputeCluster lint / elaboration: legal configurations clean, illegal ones rejected.

Legal   : Verilator -Wall (warnings attributed to new RTL rtl/ must be 0; third_party is reported, not edited),
          Icarus -g2012 elaboration, Yosys 0.33 'hierarchy -check; proc' elaboration.
Illegal : every tool must refuse: Verilator lint exits non-zero, Icarus elaboration or its time-0 $fatal fails,
          Yosys hierarchy fails.
Writes reports/lint.json.
"""
from __future__ import annotations

import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, flist, rtl_hash, run, tool_versions, write_json  # noqa: E402

TOP = "silicaflux_compute_cluster"
LEGAL = {
    "hpc_default":     (TOP, {}),
    "min_1v1t":        (TOP, dict(NUM_VECTOR_CLUSTERS=1, NUM_TENSOR_CLUSTERS=1)),
    "max_8v4t":        (TOP, dict(NUM_VECTOR_CLUSTERS=8, NUM_TENSOR_CLUSTERS=4)),
    "vec_only":        (TOP, dict(NUM_VECTOR_CLUSTERS=2, NUM_TENSOR_CLUSTERS=0)),
    "ten_only":        (TOP, dict(NUM_VECTOR_CLUSTERS=0, NUM_TENSOR_CLUSTERS=1)),
    "w64_lm_slices":   (TOP, dict(XACT_WIDTH=64, LOCAL_MEM_EN=1, MEM_REQ_SLICE=1, MEM_RSP_SLICE=1, CMD_SLICE=1,
                                  CPL_SLICE=1)),
    "w128_l8_a8":      (TOP, dict(NUM_VECTOR_CLUSTERS=1, NUM_TENSOR_CLUSTERS=1, XACT_WIDTH=128, VEC_NUM_LANES=8,
                                  TEN_ARRAY_ROWS=8, TEN_ARRAY_COLS=8)),
    "quant_dbuf":      (TOP, dict(NUM_VECTOR_CLUSTERS=1, NUM_TENSOR_CLUSTERS=2, TEN_ENABLE_QUANTIZATION=1,
                                  TEN_ENABLE_DOUBLE_BUFFERING=1)),
    "vector_cluster":  ("silicaflux_vector_cluster", {}),
    "vector_no_spm":   ("silicaflux_vector_cluster", dict(SPM_PORT_EN=0, LOCAL_MEM_EN=1)),
    "tensor_cluster":  ("silicaflux_tensor_cluster", {}),
    "tensor_w128":     ("silicaflux_tensor_cluster", dict(XACT_WIDTH=128, MEM_REQ_SLICE=1)),
}
ILLEGAL = {
    "nv9":            (TOP, dict(NUM_VECTOR_CLUSTERS=9), "NUM_VECTOR_CLUSTERS"),
    "nt5":            (TOP, dict(NUM_TENSOR_CLUSTERS=5), "NUM_TENSOR_CLUSTERS"),
    "none":           (TOP, dict(NUM_VECTOR_CLUSTERS=0, NUM_TENSOR_CLUSTERS=0), "at least one cluster"),
    "xw48":           (TOP, dict(XACT_WIDTH=48), "XACT_WIDTH"),
    "spm_overlap":    (TOP, dict(VEC_SPM_STRIDE="32'h00008000"), "VEC_SPM_STRIDE"),
    "lm_stride":      (TOP, dict(LOCAL_MEM_EN=1, LOCAL_MEM_MASK="32'hFFFFF000", LOCAL_MEM_STRIDE="32'h00000800"),
                       "LOCAL_MEM_STRIDE"),
    "trk_depth12":    (TOP, dict(TRK_DEPTH=12), "TRK_DEPTH"),
    "tag_w33":        (TOP, dict(TAG_W=33), "TAG_W"),
    "drain30":        (TOP, dict(DRAIN_LOG2=30), "DRAIN_LOG2"),
    "rst0":           (TOP, dict(RST_CYCLES=0), "RST_CYCLES"),
    "lanes3":         (TOP, dict(VEC_NUM_LANES=3), "NUM_LANES"),
    "tensor5x5":      (TOP, dict(TEN_ARRAY_ROWS=5, TEN_ARRAY_COLS=5), "verified list"),
    "spm_port2":      ("silicaflux_vector_cluster", dict(SPM_PORT_EN=2), "SPM_PORT_EN"),
}


def srcs(synth=False):
    """Simulators get the SRAM macro black-box stubs (referenced by unused ASIC leaves); Yosys does not."""
    inc, files = flist(ROOT / "rtl/files.f")
    return inc, [f for f in files if not (synth and "stubs" in f)]


def vparam(v):
    return str(v) if isinstance(v, int) else v


def verilator(top, params, wall=True):
    inc, files = srcs()
    flags = ["-Wall", "-Wno-fatal"] if wall else ["-Wno-fatal", "-Werror-USERFATAL"]   # $fatal = USERFATAL
    cmd = (["verilator", "--lint-only"] + flags + ["-Wno-DECLFILENAME", "-Wno-MULTITOP", "--top-module", top]
           + [f"+incdir+{i}" for i in inc] + files + [f"-G{k}={vparam(v)}" for k, v in params.items()])
    return run(cmd, timeout=1800)


def icarus(name, top, params):
    inc, files = srcs()
    out = BUILD / "lint" / f"{name}.vvp"
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = (["iverilog", "-g2012", "-o", str(out), "-s", top] + [f"-I{i}" for i in inc] + files
           + [f"-P{top}.{k}={vparam(v)}" for k, v in params.items()])
    rc, o = run(cmd, timeout=1800)
    if rc == 0:   # elaboration-time checks are time-0 $fatal under Icarus
        rc2, o2 = run(["vvp", "-n", str(out)], timeout=600)
        fatal = "FATAL" in o2 or "fatal" in o2.lower()
        return (1 if fatal else 0), o + o2
    return rc, o


def yosys(name, top, params):
    inc, files = srcs(synth=True)
    d = BUILD / "lint"
    d.mkdir(parents=True, exist_ok=True)
    ch = " ".join(f"-chparam {k} {vparam(v)}" for k, v in params.items())
    script = ("read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{i}" for i in inc) + " " + " ".join(files)
              + f"\nhierarchy -check -top {top} {ch}\nproc\n")
    (d / f"{name}.ys").write_text(script)
    return run(["yosys", "-q", "-s", str(d / f"{name}.ys")], timeout=3600)


def classify(out: str):
    w = [l for l in out.splitlines() if l.startswith("%Warning")]
    new = [l for l in w if re.search(r"\brtl/", l) and "third_party" not in l]
    return new, len(w) - len(new)


def legal(name):
    top, p = LEGAL[name]
    rc, out = verilator(top, p)
    new, tp = classify(out)
    verr = [l for l in out.splitlines() if l.startswith("%Error") and "Exiting due to" not in l]
    irc, iout = icarus(name, top, p)
    yrc, yout = yosys(name, top, p)
    ok = not new and not verr and irc == 0 and yrc == 0
    return name, dict(ok=ok, top=top, params={k: vparam(v) for k, v in p.items()}, new_rtl_warnings=new[:20],
                      third_party_warnings=tp, verilator_errors=verr[:5], icarus_ok=irc == 0, yosys_ok=yrc == 0,
                      icarus_tail=iout[-600:] if irc else "", yosys_tail=yout[-600:] if yrc else "")


def illegal(name):
    top, p, key = ILLEGAL[name]
    rc, out = verilator(top, p, wall=False)
    v_ref = rc != 0 and "%Error" in out
    irc, iout = icarus(name, top, p)
    yrc, yout = yosys(name, top, p)
    msg = key.lower() in (out + iout).lower()
    return name, dict(ok=v_ref and irc != 0 and yrc != 0, top=top, params={k: vparam(v) for k, v in p.items()},
                      verilator_refused=v_ref, icarus_refused=irc != 0, yosys_refused=yrc != 0,
                      message_names_parameter=msg,
                      verilator_msg=[l for l in out.splitlines() if "%Error" in l][:2],
                      icarus_msg=[l for l in iout.splitlines() if "atal" in l or "rror" in l][:2])


def main():
    res = dict(rtl_hash=rtl_hash(), tools=tool_versions(), legal={}, illegal={})
    with ThreadPoolExecutor(max_workers=1) as ex:
        for n, r in ex.map(legal, LEGAL):
            res["legal"][n] = r
            print(f"legal   {n:16s}: {'OK' if r['ok'] else 'FAIL'}  new-RTL warnings {len(r['new_rtl_warnings'])}  "
                  f"third-party warnings {r['third_party_warnings']}  icarus {r['icarus_ok']}  yosys {r['yosys_ok']}",
                  flush=True)
        for n, r in ex.map(illegal, ILLEGAL):
            res["illegal"][n] = r
            print(f"illegal {n:16s}: {'REJECTED' if r['ok'] else 'NOT REJECTED'}  verilator {r['verilator_refused']} "
                  f"icarus {r['icarus_refused']} yosys {r['yosys_refused']}  message {r['message_names_parameter']}",
                  flush=True)
    res["summary"] = dict(legal_ok=sum(r["ok"] for r in res["legal"].values()), legal_total=len(LEGAL),
                          illegal_rejected=sum(r["ok"] for r in res["illegal"].values()), illegal_total=len(ILLEGAL))
    write_json(REPORTS / "lint.json", res)
    s = res["summary"]
    print(f"legal {s['legal_ok']}/{s['legal_total']} clean, illegal {s['illegal_rejected']}/{s['illegal_total']} rejected")
    return 0 if s["legal_ok"] == s["legal_total"] and s["illegal_rejected"] == s["illegal_total"] else 1


if __name__ == "__main__":
    sys.exit(main())
