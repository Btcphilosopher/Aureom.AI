#!/usr/bin/env python3
"""Project 32 ComputeCluster -- physical hierarchy constraints from the ACTUAL synthesized hierarchy.

Inputs : config/<cfg>.json (rows / edges / groups: a proposal), reports/synth/<target>/instances.json and the
         top module's own cells (reports/synth.json) written by syn/run_synth.py.
Outputs: constraints/<cfg>.groups.tcl      tool-neutral Tcl data: regions, relative boxes, instance prefixes, totals
         constraints/<cfg>.regions.tcl     OpenROAD / OpenDB: one placement region per cluster + the shell strip
         constraints/<cfg>.subregions.tcl  OpenROAD / OpenDB: one region per intra-cluster group (locality variant)
         reports/physical/<cfg>.json       accounting: every synthesized cell / memory assigned to exactly one region
         reports/physical/<cfg>_insts.txt  instance list for the offline Tcl check (scripts/check_physical.py)

Geometry is RELATIVE (fractions of the core box): the RTL holds no coordinates and nothing here is a placement.
Region areas are proportional to weight = generic cells + MEM_BIT_WEIGHT x memory bits.  MEM_BIT_WEIGHT is an
explicit assumption (see docs/05_PHYSICAL.md); the boxes must be re-derived from a mapped netlist with real SRAM
macros before they are used for anything but exploring the floorplan topology.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, ROOT, write_json  # noqa: E402

MEM_BIT_WEIGHT = 0.5      # generic-cell equivalents per SRAM bit (SKY130 basis, docs/05_PHYSICAL.md §4)
MIN_BAND = 0.08           # smallest sub-region band, fraction of the cluster box


def dot(p: str) -> str:
    """Instance path in the dotted form both naming styles reduce to ('/' module levels -> '.')."""
    return p.replace("/", ".")


def load(cfg_path: Path):
    cfg = json.loads(cfg_path.read_text())
    tgt = cfg.get("synth_target")
    if not tgt:
        raise SystemExit(f"{cfg_path.name}: no synth_target (configuration not synthesized): nothing generated")
    rows = json.loads((REPORTS / "synth" / tgt / "instances.json").read_text())
    synth = json.loads((REPORTS / "synth.json").read_text())["results"][tgt]
    return cfg, tgt, rows, synth


def regions_of(cfg, rows, synth):
    """Cluster regions (top-level slots) with weights from the synthesized totals."""
    top = {r["path"]: r for r in rows if r["depth"] == 0}
    regs = {}
    for name, r in top.items():
        slot = name.split(".")[0]                       # 'u_vector_0.u_cl' -> 'u_vector_0'
        regs[slot] = dict(slot=slot, root=name, module=r["module"], cells=r["cells"], ffs=r["ffs"],
                          mem_cells=r["mem_cells"], mem_bits=r["mem_bits"],
                          weight=r["cells"] + MEM_BIT_WEIGHT * r["mem_bits"])
    shell = synth.get("top_own", {})
    sh = dict(slot="shell", root="", module="(top-level shell)", cells=shell.get("own_cells", 0),
              ffs=shell.get("own_ffs", 0), mem_cells=len(shell.get("own_mems", [])),
              mem_bits=sum(m["width"] * m["depth"] for m in shell.get("own_mems", [])))
    sh["weight"] = sh["cells"] + MEM_BIT_WEIGHT * sh["mem_bits"]
    return regs, sh


def layout(cfg, regs):
    """Relative boxes: shell strip on the control edge (west), rows of cluster regions, a horizontal NoC channel
    between two rows (or along the south edge for one row).  Areas proportional to weights."""
    ph = cfg["physical"]
    rows = [[s for s in row if s in regs] for row in ph["rows"]]
    rows = [r for r in rows if r]
    missing = [s for s in regs if not any(s in r for r in rows)]
    if missing:
        rows[-1] += missing
    x0, ch = ph["shell_strip"], ph["channel"]
    hav = 1.0 - ch
    rw = [sum(regs[s]["weight"] for s in r) for r in rows]
    tot = sum(rw)
    boxes, chan_side = {}, {}
    y_top = 1.0
    for i, r in enumerate(rows):
        h = hav * rw[i] / tot
        if len(rows) == 1:
            yb, yt = ch, 1.0
            side = "south"
        elif i == 0:
            yb, yt = y_top - h, y_top
            y_top = yb - ch
            side = "south"                                # channel below the north row
        else:
            yb, yt = y_top - h, y_top
            y_top = yb
            side = "north"                                # channel above the south row(s)
        x = x0
        for s in r:
            w = (1.0 - x0) * regs[s]["weight"] / rw[i]
            boxes[s] = [round(x, 4) + 0.0, max(round(yb, 4), 0.0), round(x + w, 4), round(yt, 4)]
            chan_side[s] = side
            x += w
    boxes["shell"] = [0.0, 0.0, round(x0, 4), 1.0]
    channel = None
    if len(rows) == 1:
        channel = [round(x0, 4), 0.0, 1.0, round(ch, 4)]
    else:
        y_ch_top = min(boxes[s][1] for s in rows[0])
        channel = [round(x0, 4), round(y_ch_top - ch, 4), 1.0, round(y_ch_top, 4)]
    return boxes, chan_side, channel, rows


def group_accounting(cfg, rows, regs):
    """Assign every synthesized instance's OWN cells / memories to one intra-cluster group (longest prefix)."""
    acct = {}
    for slot, reg in regs.items():
        kind = "vector" if slot.startswith("u_vector") else "tensor"
        groups = cfg["groups"][kind]
        catch = "CTRL"
        pref = []
        for g, d in groups.items():
            for m in d["members"]:
                pref.append((dot(reg["root"] + "/" + m), g))
        pref.sort(key=lambda x: -len(x[0]))
        a = {g: dict(cells=0, ffs=0, mem_cells=0, mem_bits=0, members_found=[], memories=[]) for g in groups}
        root = dot(reg["root"])
        found = set()
        for r in rows:
            p = dot(r["path"])
            if not (p == root or p.startswith(root + ".")):
                continue
            g = next((gg for pp, gg in pref if p == pp or p.startswith(pp + ".")), catch)
            for pp, gg in pref:
                if p == pp:
                    found.add(pp)
            a[g]["cells"] += r["own_cells"]
            a[g]["ffs"] += r["own_ffs"]
            for m in r["own_mems"]:
                a[g]["mem_cells"] += 1
                a[g]["mem_bits"] += m["width"] * m["depth"]
                a[g]["memories"].append(dict(path=r["path"] + "/" + m["cell"], shape=f"{m['depth']}x{m['width']}"))
        for pp, gg in pref:
            (a[gg]["members_found"]).append(dict(prefix=pp, present=pp in found))
        for g in a:
            a[g]["weight"] = a[g]["cells"] + MEM_BIT_WEIGHT * a[g]["mem_bits"]
        acct[slot] = dict(kind=kind, groups=a, prefixes=[[pp, gg] for pp, gg in pref], catch_all=catch)
    return acct


def sub_boxes(box, side, kind, acct_slot, cfg):
    """Bands inside a cluster box, ordered from the NoC channel side outwards."""
    order = ["NOC_IF", "SPM", "COMPUTE", "CTRL"] if kind == "vector" else ["NOC_IF", "CORE", "CTRL"]
    order = [g for g in order if g in acct_slot["groups"]]
    w = [max(acct_slot["groups"][g]["weight"], 1.0) for g in order]
    tot = sum(w)
    fr = [max(MIN_BAND, x / tot) for x in w]
    s = sum(fr)
    fr = [f / s for f in fr]
    x0, y0, x1, y1 = box
    h = y1 - y0
    out = {}
    if side == "south":            # channel below: first band at the bottom
        y = y0
        for g, f in zip(order, fr):
            out[g] = [x0, round(y, 4), x1, round(y + f * h, 4)]
            y += f * h
    else:                          # channel above: first band at the top
        y = y1
        for g, f in zip(order, fr):
            out[g] = [x0, round(y - f * h, 4), x1, round(y, 4)]
            y -= f * h
    return out


TCL_LIB = r'''
# ---------------------------------------------------------------- matching (both netlist naming styles)
#   OpenROAD, hierarchical netlist linked:  u_vector_0.u_cl/u_engine/g_core.u_array/g_lane\[0\].u_lane/_123_
#   Yosys flattened netlist:                $flatten\u_vector_0.u_cl.u_engine.g_core.u_array.g_lane[0].u_lane.$abc$..
# Both reduce to a dotted path; a prefix matches at a '.' boundary; the longest prefix wins; no match -> shell.
proc sfx_cc::norm {n} {
  regsub {^\\?\$flatten\\?} $n {} n
  return [string map {/ . \\ {}} $n]
}
proc sfx_cc::region_of {n} {
  variable prefixes
  set n [norm $n]
  foreach pr $prefixes {
    lassign $pr p r
    if {$n eq $p || [string first "$p." $n] == 0} { return $r }
  }
  variable shell_region
  return $shell_region
}
proc sfx_cc::core_box {block} {
  if {[catch {set r [$block getCoreArea]}]} { set r [ord::get_db_core] }
  return [list [$r xMin] [$r yMin] [$r xMax] [$r yMax]]
}
proc sfx_cc::abs_box {core frac} {
  lassign $core cx0 cy0 cx1 cy1
  lassign $frac fx0 fy0 fx1 fy1
  set w [expr {$cx1 - $cx0}]; set h [expr {$cy1 - $cy0}]
  return [list [expr {int($cx0 + $fx0 * $w)}] [expr {int($cy0 + $fy0 * $h)}] \
               [expr {int($cx0 + $fx1 * $w)}] [expr {int($cy0 + $fy1 * $h)}]]
}
# Create one OpenDB region per entry of $regions, assign every instance, report the counts.
# Fails (utl::error) when a region matches nothing or this OpenROAD build lacks the region API.
proc sfx_cc::create {} {
  variable regions
  variable assigned
  set block [ord::get_db_block]
  set core [core_box $block]
  array unset assigned
  array set handle {}
  array set count {}
  foreach r $regions {
    lassign $r name frac
    if {[catch {set reg [odb::dbRegion_create $block $name]} e]} {
      utl::error SFX 1 "odb::dbRegion_create unavailable in this OpenROAD build: $e"
    }
    lassign [abs_box $core $frac] x0 y0 x1 y1
    if {[catch {odb::dbBox_create $reg $x0 $y0 $x1 $y1} e]} {
      utl::error SFX 2 "odb::dbBox_create (region boundary) failed: $e"
    }
    set handle($name) $reg
    set count($name) 0
    set ::sfx_cc::box($name) [list $x0 $y0 $x1 $y1]
  }
  foreach inst [$block getInsts] {
    set rn [region_of [$inst getName]]
    if {[catch {$handle($rn) addInst $inst} e]} {
      utl::error SFX 3 "dbRegion::addInst unavailable in this OpenROAD build: $e"
    }
    set assigned([$inst getName]) $rn
    incr count($rn)
  }
  foreach r $regions {
    set name [lindex $r 0]
    puts [format "SFX-CC: region %-24s %s  instances %d" $name $::sfx_cc::box($name) $count($name)]
    if {$count($name) == 0} { utl::error SFX 4 "region $name matched no instance (netlist not hierarchical?)" }
  }
}
# After global + detailed placement: every instance must lie inside its region box.
proc sfx_cc::check {} {
  variable assigned
  set block [ord::get_db_block]
  set bad 0
  set n 0
  foreach inst [$block getInsts] {
    set nm [$inst getName]
    if {![info exists assigned($nm)]} continue
    lassign $::sfx_cc::box($assigned($nm)) x0 y0 x1 y1
    set bb [$inst getBBox]
    incr n
    if {[$bb xMin] < $x0 || [$bb yMin] < $y0 || [$bb xMax] > $x1 || [$bb yMax] > $y1} {
      incr bad
      if {$bad <= 20} { puts "SFX-CC: OUTSIDE $nm (region $assigned($nm))" }
    }
  }
  puts "SFX-CC: region check: $n instances, $bad outside their region"
  return $bad
}
'''


def tcl_regions(cfg_name, src, regions, prefixes, shell_region, title):
    lines = [f"# {title}", f"# Generated by scripts/gen_physical.py from {src} -- do not edit.",
             "# Proposal: relative boxes (fractions of the core area).  No coordinate exists in the RTL.",
             "# Requires a hierarchy-preserving synthesis (ORFS: SYNTH_HIERARCHICAL=1 and the cluster modules kept),",
             "# so every cell name carries its region prefix.  Usage inside OpenROAD, after initialize_floorplan:",
             f"#   source constraints/{cfg_name}.{'regions' if 'sub' not in title.lower() else 'subregions'}.tcl",
             "#   sfx_cc::create   ;# then global_placement / detailed_placement",
             "#   sfx_cc::check    ;# returns the number of instances outside their region",
             "namespace eval sfx_cc {",
             f"  variable cfg {cfg_name}",
             "  # {name {fx0 fy0 fx1 fy1}}",
             "  variable regions {"]
    for name, box in regions:
        lines.append(f"    {{{name} {{{' '.join(f'{v:.4f}' for v in box)}}}}}")
    lines += ["  }", "  # {dotted instance prefix  region} -- longest prefix first", "  variable prefixes {"]
    for p, r in prefixes:
        lines.append(f"    {{{p} {r}}}")
    lines += ["  }", f"  variable shell_region {shell_region}", "}"]
    return "\n".join(lines) + "\n" + TCL_LIB


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="compute_hpc")
    a = ap.parse_args()
    cfg_path = ROOT / "config" / f"{a.config}.json"
    cfg, tgt, rows, synth = load(cfg_path)
    regs, sh = regions_of(cfg, rows, synth)
    boxes, side, channel, layout_rows = layout(cfg, regs)
    acct = group_accounting(cfg, rows, regs)
    src = f"reports/synth/{tgt}/instances.json"
    out_c = ROOT / "constraints"
    out_c.mkdir(exist_ok=True)

    # ---- cluster-level regions
    reg_list = [(f"R_{s}", boxes[s]) for s in regs] + [("R_shell", boxes["shell"])]
    pref = sorted([(dot(regs[s]["root"]), f"R_{s}") for s in regs], key=lambda x: -len(x[0]))
    (out_c / f"{a.config}.regions.tcl").write_text(
        tcl_regions(a.config, src, reg_list, pref, "R_shell",
                    f"SilicaFlux-HPC P32 ComputeCluster -- {a.config}: one placement region per compute cluster"))

    # ---- intra-cluster sub-regions (locality variant)
    sub_list, sub_pref, sub = [], [], {}
    for s in regs:
        sb = sub_boxes(boxes[s], side[s], acct[s]["kind"], acct[s], cfg)
        sub[s] = sb
        for g, b in sb.items():
            sub_list.append((f"R_{s}_{g}", b))
        for p, g in acct[s]["prefixes"]:
            sub_pref.append((p, f"R_{s}_{g}"))
        sub_pref.append((dot(regs[s]["root"]), f"R_{s}_{acct[s]['catch_all']}"))
    sub_list.append(("R_shell", boxes["shell"]))
    sub_pref.sort(key=lambda x: -len(x[0]))
    (out_c / f"{a.config}.subregions.tcl").write_text(
        tcl_regions(a.config, src, sub_list, sub_pref, "R_shell",
                    f"SilicaFlux-HPC P32 ComputeCluster -- {a.config}: Sub-regions (intra-cluster locality groups)"))

    # ---- tool-neutral data
    g = [f"# SilicaFlux-HPC P32 ComputeCluster -- {a.config}: proposed regions and instance groups (tool-neutral data)",
         f"# Generated by scripts/gen_physical.py from {src} -- do not edit.  Synthesis: Yosys generic, hierarchy kept.",
         f"# weight = cells + {MEM_BIT_WEIGHT} x memory bits (assumption, docs/05_PHYSICAL.md).  Boxes: fractions of the core.",
         "namespace eval sfx_cc_groups {",
         f"  variable noc_channel {{{' '.join(str(v) for v in channel)}}}",
         f"  variable control_edge {cfg['physical']['control_edge']}",
         "  # region  root-instance  module  cells  ffs  memories  memory_bits  box  channel_side"]
    g.append("  variable regions {")
    for s in regs:
        r = regs[s]
        g.append(f"    {{R_{s} {r['root']} {{{r['module']}}} {r['cells']} {r['ffs']} {r['mem_cells']} {r['mem_bits']} "
                 f"{{{' '.join(str(v) for v in boxes[s])}}} {side[s]}}}")
    g.append(f"    {{R_shell {{}} {{top-level shell}} {sh['cells']} {sh['ffs']} {sh['mem_cells']} {sh['mem_bits']} "
             f"{{{' '.join(str(v) for v in boxes['shell'])}}} -}}")
    g.append("  }")
    g.append("  # group  members (dotted instance prefixes, relative to the cluster root)  cells  memories  memory_bits  box")
    g.append("  variable groups {")
    for s in regs:
        for gn, ga in acct[s]["groups"].items():
            mem = " ".join(m["prefix"] for m in ga["members_found"] if m["present"])
            g.append(f"    {{R_{s}_{gn} {{{mem}}} {ga['cells']} {ga['mem_cells']} {ga['mem_bits']} "
                     f"{{{' '.join(str(v) for v in sub[s][gn])}}}}}")
    g.append("  }")
    g.append("}")
    (out_c / f"{a.config}.groups.tcl").write_text("\n".join(g) + "\n")

    # ---- instance list for the offline check (OpenROAD-style names: '/' between module levels, '[' escaped)
    ins = []
    sh_own = synth.get("top_own", {})
    ins.append(f"__shell_cells__ {sh_own.get('own_cells', 0)} 0")
    for r in rows:
        nm = r["path"].replace("[", "\\[").replace("]", "\\]")
        ins.append(f"{nm}/__cells__ {r['own_cells']} 0")
        for m in r["own_mems"]:
            ins.append(f"{nm}/{m['cell'].replace('[', chr(92) + '[').replace(']', chr(92) + ']')} 0 {m['width'] * m['depth']}")
    pdir = REPORTS / "physical"
    pdir.mkdir(parents=True, exist_ok=True)
    (pdir / f"{a.config}_insts.txt").write_text("\n".join(ins) + "\n")

    rep = dict(config=a.config, synth_target=tgt, mem_bit_weight=MEM_BIT_WEIGHT, rows=layout_rows, channel=channel,
               regions={s: dict(regs[s], box=boxes[s], channel_side=side[s]) for s in regs},
               shell=dict(sh, box=boxes["shell"]), groups={s: dict(acct[s], boxes=sub[s]) for s in regs})
    write_json(pdir / f"{a.config}.json", rep)
    tot_cells = sum(r["cells"] for r in regs.values()) + sh["cells"]
    print(f"{a.config}: {len(regs)} cluster regions + shell, {len(sub_list)} sub-regions; "
          f"cells {tot_cells} (synthesis {synth['totals']['cells']})")


if __name__ == "__main__":
    main()
