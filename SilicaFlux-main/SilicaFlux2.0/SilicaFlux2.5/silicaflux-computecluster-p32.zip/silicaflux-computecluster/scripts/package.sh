#!/usr/bin/env bash
# Package the project as a plain archive (nothing is committed): writes MANIFEST.sha256 over every shipped file,
# then ../silicaflux-computecluster-p32.zip.  build/ (regenerable) is not shipped.
set -euo pipefail
cd "$(dirname "$0")/.."
find . -type d -name __pycache__ -prune -exec rm -rf {} +
find . -type f ! -path './build/*' ! -name MANIFEST.sha256 | sed 's|^\./||' | LC_ALL=C sort | xargs sha256sum > MANIFEST.sha256
name=silicaflux-computecluster
out=../${name}-p32.zip
rm -f "$out"
(cd .. && zip -qr "${name}-p32.zip" "$name" -x "$name/build/*")
echo "wrote $(cd .. && pwd)/${name}-p32.zip ($(du -h "$out" | cut -f1)), $(wc -l < MANIFEST.sha256) files"
