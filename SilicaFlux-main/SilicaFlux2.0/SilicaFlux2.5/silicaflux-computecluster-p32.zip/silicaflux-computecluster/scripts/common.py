"""Shared helpers for the Project 32 ComputeCluster scripts (standard library only)."""
from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"


def run(cmd, cwd=None, timeout=None, env=None):
    """Run a command; return (returncode, combined stdout+stderr)."""
    try:
        p = subprocess.run(cmd, cwd=cwd or ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                           timeout=timeout, env=env)
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired as e:
        out = e.stdout.decode() if isinstance(e.stdout, bytes) else (e.stdout or "")
        return 124, out + "\n[timeout]"


def first_line(cmd):
    try:
        rc, out = run(cmd)
        return out.strip().splitlines()[0] if out.strip() else "?"
    except FileNotFoundError:
        return "not installed"


def tool_versions():
    return {
        "verilator": first_line(["verilator", "--version"]),
        "iverilog": first_line(["iverilog", "-V"]),
        "yosys": first_line(["yosys", "-V"]),
        "python": first_line(["python3", "--version"]),
    }


def rtl_hash() -> str:
    """sha256 over rtl/* (sorted) with // comments and blank space removed: identifies the logic that was run."""
    import hashlib
    h = hashlib.sha256()
    for f in sorted((ROOT / "rtl").iterdir()):
        for line in f.read_text().splitlines():
            code = line.split("//")[0].strip()
            if code:
                h.update(code.encode() + b"\n")
    return h.hexdigest()[:16]


def write_json(path: Path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=1, sort_keys=False) + "\n")


def flist(path: Path):
    """Parse a .f file: (+incdir list, source list), comments dropped."""
    inc, files = [], []
    for line in path.read_text().splitlines():
        line = line.split("//")[0].strip()
        if not line:
            continue
        if line.startswith("+incdir+"):
            inc.append(line[len("+incdir+"):])
        else:
            files.append(line)
    return inc, files


def stats(log: str) -> dict:
    """Parse the testbench STAT / RESULT lines."""
    d = {}
    m = re.search(r"^RESULT (PASS|FAIL) test=(\S+) seed=(\d+) errors=(\d+) cycles=(\d+)", log, re.M)
    if m:
        d.update(result=m[1], errors=int(m[4]), cycles=int(m[5]))
    m = re.search(r"^STAT completions (\d+) ok (\d+) engine_errors (\d+) shell (\d+) reset_abort (\d+)", log, re.M)
    if m:
        d.update(completions=int(m[1]), n_ok=int(m[2]), engine_errors=int(m[3]), shell=int(m[4]), reset_abort=int(m[5]))
    m = re.search(r"^STAT commands (\d+)", log, re.M)
    if m:
        d["commands"] = int(m[1])
    m = re.search(r"^STAT overlap_vector_tensor (\d+) overlap_vector_vector (\d+) overlap_tensor_tensor (\d+)", log, re.M)
    if m:
        d.update(ov_vt=int(m[1]), ov_vv=int(m[2]), ov_tt=int(m[3]))
    m = re.search(r"^STAT host_ops (\d+) host_read_checks (\d+) gated_cycles (\d+)", log, re.M)
    if m:
        d.update(host_ops=int(m[1]), host_read_checks=int(m[2]), gated_cycles=int(m[3]))
    m = re.search(r"^STAT src_switches (\d+)", log, re.M)
    if m:
        d["src_switches"] = int(m[1])
    cl = []
    for m in re.finditer(r"^STAT cluster (\d+) dest (\d+) (.*)$", log, re.M):
        kv = m[3].split()
        e = {kv[i]: int(kv[i + 1]) for i in range(0, len(kv) - 1, 2)}
        e.update(cluster=int(m[1]), dest=int(m[2]))
        cl.append(e)
    if cl:
        d["clusters"] = cl
    lat = {m[1]: int(m[2]) for m in re.finditer(r"^STAT latency (\S+) (\d+)", log, re.M)}
    if lat:
        d["latency"] = lat
    d["error_lines"] = [l for l in log.splitlines() if "ERROR" in l or "%Error" in l][:10]
    # $error / $fatal of the RTL or a checker (Icarus "ERROR: file:line", Verilator "%Error"): a failure even if the
    # testbench's own RESULT line says PASS
    d["assertion_errors"] = sum(1 for l in log.splitlines() if l.startswith("ERROR:") or l.startswith("%Error"))
    return d
