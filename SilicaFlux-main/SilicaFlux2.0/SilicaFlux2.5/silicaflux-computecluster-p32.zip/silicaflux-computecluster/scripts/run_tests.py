#!/usr/bin/env python3
"""Project 32 ComputeCluster regression: Verilator builds of tb/tb_cc.sv per configuration, every scenario and seed,
plus an Icarus cross-simulation subset.  Writes reports/regression.json and reports/logs/.

  python3 scripts/run_tests.py                      # everything
  python3 scripts/run_tests.py --configs min        # one configuration
  python3 scripts/run_tests.py --no-icarus --jobs 4
"""
from __future__ import annotations

import argparse
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, rtl_hash, run, stats, tool_versions, write_json  # noqa: E402

# Configuration parameters of tb_cc (defaults: NV=1 NT=1 XW=32 LM=0 MSLC=0 CSLC=0 TDIM=4 VLANES=4 DRAIN=10 GATE=0)
CONFIGS = {
    # minimum chip configuration: one vector + one tensor cluster, no slices, no local memory
    "min":       dict(params=dict(NV=1, NT=1),
                      tests={"smoke": [1], "single_vec": [1, 2], "single_ten": [1, 2], "multi": [1, 2, 3],
                             "mixed": [1], "contention": [1, 2], "backpressure": [1, 2, 3], "routing": [1, 2],
                             "reset": [1, 2, 3], "reset_drain": [1], "errors": [1], "csr": [1], "latency": [1]}),
    # default HPC configuration: u_vector_0..3, u_tensor_0..1
    "hpc":       dict(params=dict(NV=4, NT=2),
                      tests={"smoke": [1], "multi": [1, 2, 3], "mixed": [1, 2], "contention": [1, 2],
                             "backpressure": [1, 2], "routing": [1, 2], "reset": [1, 2], "reset_drain": [1],
                             "errors": [1], "csr": [1]}),
    # 64-bit transactions, local memory ports, every pipeline boundary on
    "w64_lm_slc": dict(params=dict(NV=2, NT=1, XW=64, LM=1, MSLC=1, CSLC=1),
                      tests={"smoke": [1], "single_vec": [1], "single_ten": [1], "multi": [1, 2], "localmem": [1, 2],
                             "backpressure": [1, 2], "routing": [1], "reset": [1, 2], "reset_drain": [1],
                             "errors": [1], "csr": [1], "latency": [1]}),
    # 128-bit transactions, 8 lanes, 8x8 systolic array
    "w128_l8_a8": dict(params=dict(NV=1, NT=1, XW=128, VLANES=8, TDIM=8),
                      tests={"smoke": [1], "single_vec": [1], "single_ten": [1], "multi": [1, 2],
                             "backpressure": [1], "reset": [1], "errors": [1]}),
    # one type only
    "vec_only":  dict(params=dict(NV=2, NT=0),
                      tests={"smoke": [1], "single_vec": [1], "multi": [1], "routing": [1], "reset": [1],
                             "reset_drain": [1], "errors": [1], "csr": [1]}),
    "ten_only":  dict(params=dict(NV=0, NT=2, TDIM=2),
                      tests={"smoke": [1], "single_ten": [1], "multi": [1], "routing": [1], "reset": [1],
                             "reset_drain": [1], "errors": [1], "csr": [1]}),
    # every slot built: u_vector_0..7, u_tensor_0..3.  Simulated with Icarus: its Verilator C++ build needs more
    # than the 15 GB of RAM available (one compile unit alone reached ~13 GB)
    "max":       dict(params=dict(NV=8, NT=4), sim="icarus",
                      tests={"smoke": [1], "multi": [1], "routing": [1]}),
    # clusters' clk_req drives a clock gate on the whole subsystem
    "min_gate":  dict(params=dict(NV=1, NT=1, GATE=1), tests={"clkgate": [1, 2]}),
}
ICARUS = ("min", ["smoke", "single_vec", "single_ten", "routing", "errors", "csr", "reset", "reset_drain"], 1)


def vbuild(cfg: str, jobs: int) -> dict:
    d = BUILD / f"v_{cfg}"
    d.mkdir(parents=True, exist_ok=True)
    g = [f"-G{k}={v}" for k, v in CONFIGS[cfg]["params"].items()]
    cmd = ["verilator", "--binary", "--timing", "-j", str(jobs), "-Wno-fatal", "-Wno-lint", "-Wno-style",
           "-Wno-TIMESCALEMOD", "-Wno-MULTIDRIVEN", "-Wno-INITIALDLY", "--top-module", "tb_cc",
           "-f", "rtl/files.f", "-f", "tb/files_tb.f", "--Mdir", str(d), "-o", "sim", "-CFLAGS", "-O1",
           "--output-split", "4000", "--output-split-cfuncs", "1000"] + g
    t0 = time.time()
    rc, out = run(cmd, timeout=7200)
    (REPORTS / "logs").mkdir(parents=True, exist_ok=True)
    (REPORTS / "logs" / f"build_{cfg}.log").write_text(" ".join(cmd) + "\n" + out[-30000:])
    errs = [l for l in out.splitlines() if l.startswith("%Error")]
    return dict(ok=(rc == 0 and (d / "sim").exists()), seconds=round(time.time() - t0, 1), errors=errs[:10])


def vrun(cfg: str, test: str, seed: int) -> dict:
    t0 = time.time()
    rc, out = run([str(BUILD / f"v_{cfg}" / "sim"), f"+TEST={test}", f"+SEED={seed}"], timeout=3600)
    (REPORTS / "logs" / f"{cfg}_{test}_s{seed}.log").write_text(out[-60000:])
    st = stats(out)
    ok = st.get("result") == "PASS" and rc == 0 and st.get("assertion_errors", 0) == 0
    return dict(cfg=cfg, test=test, seed=seed, sim="verilator", ok=ok, seconds=round(time.time() - t0, 1), **st)


def ibuild(cfg: str = "min") -> dict:
    d = BUILD / f"i_{cfg}"
    d.mkdir(parents=True, exist_ok=True)
    p = [f"-Ptb_cc.{k}={v}" for k, v in CONFIGS[cfg]["params"].items()]
    cmd = ["iverilog", "-g2012", "-o", str(d / "sim.vvp"), "-s", "tb_cc", "-c", "rtl/files.f", "-c", "tb/files_tb.f"] + p
    rc, out = run(cmd, timeout=3600)
    (REPORTS / "logs").mkdir(parents=True, exist_ok=True)
    (REPORTS / "logs" / f"build_icarus_{cfg}.log").write_text(" ".join(cmd) + "\n" + out[-30000:])
    return dict(ok=rc == 0, errors=[l for l in out.splitlines() if "error" in l.lower()][:10])


def irun(test: str, seed: int, cfg: str = "min") -> dict:
    t0 = time.time()
    rc, out = run(["vvp", "-n", str(BUILD / f"i_{cfg}" / "sim.vvp"), f"+TEST={test}", f"+SEED={seed}"], timeout=14400)
    (REPORTS / "logs" / f"icarus_{cfg}_{test}_s{seed}.log").write_text(out[-60000:])
    st = stats(out)
    return dict(cfg=cfg, test=test, seed=seed, sim="icarus",
                ok=st.get("result") == "PASS" and st.get("assertion_errors", 0) == 0,
                seconds=round(time.time() - t0, 1), **st)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default=",".join(CONFIGS))
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--build-jobs", type=int, default=2)
    ap.add_argument("--no-icarus", action="store_true")
    ap.add_argument("--out", default="regression")
    a = ap.parse_args()
    cfgs = [c for c in a.configs.split(",") if c]
    t0 = time.time()
    res = dict(rtl_hash=rtl_hash(), tools=tool_versions(), configs={c: CONFIGS[c]["params"] for c in cfgs}, builds={}, runs=[])
    # builds: one at a time (the large configurations need several GB per compiler process)
    with ThreadPoolExecutor(max_workers=1) as ex:
        futs = {c: ex.submit(ibuild, c) if CONFIGS[c].get("sim") == "icarus" else
                ex.submit(vbuild, c, CONFIGS[c].get("build_jobs", a.build_jobs)) for c in cfgs}
        if not a.no_icarus and ICARUS[0] in cfgs:
            futs["icarus"] = ex.submit(ibuild)
        for c, f in futs.items():
            res["builds"][c] = f.result()
            print(f"build {c}: {'ok' if res['builds'][c]['ok'] else 'FAILED'}", flush=True)
    jobs = [(c, t, s) for c in cfgs if res["builds"][c]["ok"] for t, seeds in CONFIGS[c]["tests"].items() for s in seeds]
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = [ex.submit(irun, t, s, c) if CONFIGS[c].get("sim") == "icarus" else ex.submit(vrun, c, t, s)
                for c, t, s in jobs]
        if not a.no_icarus and res["builds"].get("icarus", {}).get("ok"):
            futs += [ex.submit(irun, t, ICARUS[2]) for t in ICARUS[1]]
        for f in futs:
            r = f.result()
            res["runs"].append(r)
            print(f"{r['sim']:9s} {r['cfg']:11s} {r['test']:13s} seed {r['seed']}: {'PASS' if r['ok'] else 'FAIL'}"
                  f"  cycles {r.get('cycles', '-')}  ({r['seconds']} s)", flush=True)
    res["seconds"] = round(time.time() - t0, 1)
    prim = {c for c in cfgs if CONFIGS[c].get("sim") == "icarus"}
    v = [r for r in res["runs"] if r["sim"] == "verilator" or r["cfg"] in prim]
    i = [r for r in res["runs"] if r["sim"] == "icarus" and r["cfg"] not in prim]
    # cross-simulator agreement: same test/seed -> same RESULT, cycles and completion counts
    agree = []
    for r in i:
        m = [x for x in v if x["cfg"] == r["cfg"] and x["test"] == r["test"] and x["seed"] == r["seed"]]
        if m:
            keys = ["result", "cycles", "completions", "n_ok", "engine_errors", "shell", "reset_abort"]
            agree.append(dict(test=r["test"], seed=r["seed"], identical=all(m[0].get(k) == r.get(k) for k in keys),
                              verilator_cycles=m[0].get("cycles"), icarus_cycles=r.get("cycles")))
    res["cross_sim"] = agree
    res["summary"] = dict(verilator_pass=sum(r["ok"] for r in v), verilator_total=len(v),
                          icarus_pass=sum(r["ok"] for r in i), icarus_total=len(i),
                          cross_identical=sum(x["identical"] for x in agree), cross_total=len(agree),
                          commands=sum(r.get("commands", 0) for r in res["runs"]),
                          completions=sum(r.get("completions", 0) for r in res["runs"]))
    write_json(REPORTS / f"{a.out}.json", res)
    s = res["summary"]
    print(f"Verilator {s['verilator_pass']}/{s['verilator_total']}, Icarus {s['icarus_pass']}/{s['icarus_total']}, "
          f"cross-sim identical {s['cross_identical']}/{s['cross_total']}, {s['completions']} completions checked "
          f"({res['seconds']} s)")
    return 0 if s["verilator_pass"] == s["verilator_total"] and s["icarus_pass"] == s["icarus_total"] else 1


if __name__ == "__main__":
    sys.exit(main())
