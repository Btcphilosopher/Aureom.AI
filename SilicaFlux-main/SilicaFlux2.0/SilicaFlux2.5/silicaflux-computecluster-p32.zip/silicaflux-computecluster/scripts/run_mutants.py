#!/usr/bin/env python3
"""Mutation testing of the NEW RTL (rtl/): each mutant is a deliberate bug; the minimum-configuration testbench
must detect it (a test FAILS, or hangs into the watchdog).  Reused third-party RTL is never mutated.
Writes reports/mutation.json.
"""
from __future__ import annotations

import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, REPORTS, ROOT, rtl_hash, run, stats, write_json  # noqa: E402

# (name, file, original text, mutated text, tests that should catch it)
MUTANTS = [
    ("trk_no_reset_abort", "sfx_cl_cmd_port.sv",
     "if (trk_kind[i] == `SFX_CL_ST_ENGINE) trk_kind[i] <= `SFX_CL_ST_RESET_ABORT;",
     "if (1'b0) trk_kind[i] <= `SFX_CL_ST_RESET_ABORT;", ["reset"]),
    ("no_host_deny", "sfx_cl_cmd_port.sv",
     "wire h_deny   = h_sel && (eng_in_reset || (stream_en && h_owned));",
     "wire h_deny   = h_sel && eng_in_reset;", ["errors"]),
    ("no_length_check", "sfx_cl_cmd_port.sv",
     "(w_over || w_idx != IXW'(CMD_WORDS - 1)) ? `SFX_CL_ST_BAD_LENGTH : `SFX_CL_ST_ENGINE;",
     "(w_over) ? `SFX_CL_ST_BAD_LENGTH : `SFX_CL_ST_ENGINE;", ["routing"]),
    ("err_summary_zero", "sfx_cl_cmd_port.sv",
     "wire eng_err = (b_w[1][ERR_LSB +: ERR_W] != '0);",
     "wire eng_err = 1'b0;", ["errors"]),
    ("tag_from_tail", "sfx_cl_cmd_port.sv",
     "if (first_w) p_tag <= s_tag;",
     "p_tag <= s_tag ^ {{(TAG_W-1){1'b0}}, s_last};", ["smoke", "routing"]),
    ("no_drop", "sfx_cl_mem_port.sv",
     "if (force_drop)             drop_cnt <= out_cnt + OW'(d_hs) - OW'(r_hs) + OW'(cap_now || (cap_v && !d_hs));",
     "if (1'b0)                   drop_cnt <= out_cnt + OW'(d_hs) - OW'(r_hs) + OW'(cap_now || (cap_v && !d_hs));",
     ["reset_drain"]),
    ("no_quiesce", "sfx_cl_mem_port.sv",
     "wire           blk   = q_req || cap_v ||",
     "wire           blk   = cap_v ||", ["reset", "reset_drain"]),
    ("no_force", "sfx_cl_ctrl.sv",
     "wire                   do_force    = (st == `SFX_CL_RS_Q_MEM) && !ports_quiet && timeout;",
     "wire                   do_force    = 1'b0;", ["reset_drain"]),
    ("no_owe_error", "sfx_cl_slv_gate.sv",
     "if (force_err)                     owe_cnt <= out_cnt + OW'(req_hs) - OW'(rsp_hs) - OW'(cap_now);",
     "if (1'b0)                          owe_cnt <= out_cnt + OW'(req_hs) - OW'(rsp_hs) - OW'(cap_now);",
     ["reset", "reset_drain"]),
    ("no_rsp_capture", "sfx_cl_slv_gate.sv",
     "wire cap_now = force_err && !cap_v && !owing && t_rsp_valid && !x_rsp_ready;",
     "wire cap_now = 1'b0;", ["reset_drain"]),
    ("merge_no_lock", "silicaflux_compute_cluster.sv",
     "        lock_q <= 1'b1;                       // presented: hold the source until its last word",
     "        lock_q <= 1'b0;", ["routing", "multi"]),
    ("router_wrong_slot", "silicaflux_compute_cluster.sv",
     "    assign t_cmd_valid[k] = i_v && cur_ok && cur_dest[3] && (cur_dest[1:0] == 2'(k));",
     "    assign t_cmd_valid[k] = i_v && cur_ok && cur_dest[3] && (cur_dest[1:0] == 2'(k)) && !i_last;",
     ["smoke"]),
    ("no_init_write", "sfx_cl_cmd_port.sv",
     "  assign r_init = init_pend && !eng_in_reset;",
     "  assign r_init = 1'b0;", ["smoke", "errors"]),
]


def main():
    res = []
    t0 = time.time()
    for name, f, old, new, tests in MUTANTS:
        d = BUILD / "mut" / name
        if d.exists():
            shutil.rmtree(d)
        (d / "rtl").mkdir(parents=True)
        for src in (ROOT / "rtl").iterdir():
            shutil.copy(src, d / "rtl" / src.name)
        text = (d / "rtl" / f).read_text()
        if text.count(old) != 1:
            res.append(dict(name=name, file=f, applied=False, killed=False, note="pattern not found once"))
            print(f"{name}: NOT APPLIED", flush=True)
            continue
        (d / "rtl" / f).write_text(text.replace(old, new))
        # only the new RTL is redirected to the mutant copy; third_party paths stay relative to ROOT
        fl = []
        for line in (ROOT / "rtl/files.f").read_text().splitlines():
            if line.strip() == "+incdir+rtl":
                line = f"+incdir+{d}/rtl"
            elif line.startswith("rtl/"):
                line = f"{d}/{line}"
            fl.append(line)
        (d / "files.f").write_text("\n".join(fl) + "\n")
        # Icarus: seconds to compile, no multi-GB C++ build (the regression may be running in parallel)
        cmd = ["iverilog", "-g2012", "-o", str(d / "sim.vvp"), "-s", "tb_cc", "-c", str(d / "files.f"),
               "-c", "tb/files_tb.f", "-Ptb_cc.NV=1", "-Ptb_cc.NT=1"]
        rc, out = run(cmd, timeout=3600)
        if rc != 0:
            res.append(dict(name=name, file=f, applied=True, killed=True, by="build", tests={}))
            print(f"{name}: killed by build", flush=True)
            continue
        outcomes = {}
        killed = False
        for t in tests:
            rc, out = run(["vvp", "-n", str(d / "sim.vvp"), f"+TEST={t}", "+SEED=1", "+MAXCYC=30000"], timeout=3600)
            st = stats(out)
            failed = st.get("result") != "PASS" or st.get("assertion_errors", 0) > 0
            outcomes[t] = dict(result=st.get("result", "no RESULT (crash/stop)"), errors=st.get("errors"),
                               first_error=(st.get("error_lines") or [""])[0][:200])
            killed |= failed
        res.append(dict(name=name, file=f, applied=True, killed=killed, tests=outcomes))
        print(f"{name}: {'KILLED' if killed else 'SURVIVED'}  {outcomes}", flush=True)
        (d / "sim.vvp").unlink(missing_ok=True)
    s = dict(applied=sum(r["applied"] for r in res), killed=sum(r["killed"] for r in res), total=len(res),
             seconds=round(time.time() - t0, 1))
    write_json(REPORTS / "mutation.json", dict(rtl_hash=rtl_hash(), summary=s, mutants=res))
    print(f"mutants killed {s['killed']}/{s['applied']}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
