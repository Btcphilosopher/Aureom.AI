#!/usr/bin/env python3
"""Offline check of the generated region scripts (no OpenROAD needed).

Runs constraints/<cfg>.regions.tcl and .subregions.tcl in a plain tclsh with physical/mock_odb.tcl standing in for
the OpenDB objects, against the instance list derived from the ACTUAL synthesized hierarchy
(reports/physical/<cfg>_insts.txt, OpenROAD-style names), in two naming styles: OpenROAD after linking a
hierarchical netlist ('/' levels, escaped brackets) and a Yosys-flattened netlist ('$flatten\\', '.' levels).
Checks: every instance assigned exactly once; every region non-empty and inside the core; no two regions overlap;
the cells / memory bits each region receives equal the synthesis accounting (reports/physical/<cfg>.json).
What this does NOT show: that a particular OpenROAD build implements the OpenDB region API or that its placers
honour it -- physical/openroad_region_check.tcl is the script for that, and it was not run here.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, ROOT, run, write_json  # noqa: E402

TCLSH = "tclsh8.6"


def tcl_run(cfg: str, kind: str, style: str):
    drv = ROOT / "build" / f"chk_{cfg}_{kind}_{style}.tcl"
    drv.parent.mkdir(exist_ok=True)
    drv.write_text(f"source {ROOT / 'physical/mock_odb.tcl'}\n"
                   f"mock::load {REPORTS / 'physical' / (cfg + '_insts.txt')} {style}\n"
                   f"source {ROOT / 'constraints' / (cfg + '.' + kind + '.tcl')}\n"
                   f"sfx_cc::create\nmock::report\n")
    rc, out = run([TCLSH, str(drv)], timeout=1800)
    regs = {}
    for m in re.finditer(r"^MOCK region (\S+) box \{([^}]*)\} insts (\d+) cells (\d+) membits (\d+)", out, re.M):
        regs[m[1]] = dict(box=[int(x) for x in m[2].split()], insts=int(m[3]), cells=int(m[4]), membits=int(m[5]))
    tot = re.search(r"^MOCK instances (\d+) assigned (\d+)", out, re.M)
    ov = re.search(r"^MOCK overlaps (\d+)", out, re.M)
    return dict(rc=rc, regions=regs, instances=int(tot[1]) if tot else None, assigned=int(tot[2]) if tot else None,
                overlaps=int(ov[1]) if ov else None, tail=out[-1500:] if rc else "")


def expected(cfg: str):
    p = json.loads((REPORTS / "physical" / f"{cfg}.json").read_text())
    reg = {f"R_{s}": dict(cells=r["cells"], membits=r["mem_bits"]) for s, r in p["regions"].items()}
    reg["R_shell"] = dict(cells=p["shell"]["cells"], membits=p["shell"]["mem_bits"])
    sub = {"R_shell": reg["R_shell"]}
    for s, g in p["groups"].items():
        for gn, ga in g["groups"].items():
            sub[f"R_{s}_{gn}"] = dict(cells=ga["cells"], membits=ga["mem_bits"])
    return dict(regions=reg, subregions=sub)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--configs", default="compute_min,compute_hpc")
    a = ap.parse_args()
    out = {}
    ok_all = True
    for cfg in a.configs.split(","):
        exp = expected(cfg)
        out[cfg] = {}
        for kind in ("regions", "subregions"):
            for style in ("hier", "flat"):
                r = tcl_run(cfg, kind, style)
                e = exp[kind]
                mism = [n for n in e if n not in r["regions"] or r["regions"][n]["cells"] != e[n]["cells"]
                        or r["regions"][n]["membits"] != e[n]["membits"]]
                empty = [n for n, v in r["regions"].items() if v["insts"] == 0]
                ok = (r["rc"] == 0 and r["instances"] == r["assigned"] and r["overlaps"] == 0 and not mism
                      and not empty and set(r["regions"]) == set(e))
                ok_all &= ok
                out[cfg][f"{kind}_{style}"] = dict(ok=ok, accounting_mismatch=mism, empty=empty, **r)
                print(f"{cfg:12s} {kind:10s} {style:4s}: {'PASS' if ok else 'FAIL'}  instances {r['instances']} "
                      f"assigned {r['assigned']} regions {len(r['regions'])} overlaps {r['overlaps']}"
                      f"{'  mismatch ' + str(mism) if mism else ''}")
    write_json(REPORTS / "physical" / "check.json", out)
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
