#!/usr/bin/env python3
"""reports/*.md from the JSON results (regression, lint, synth, physical, mutation).  Every number in the
Markdown reports is copied from those JSON files; nothing is typed by hand."""
from __future__ import annotations

import hashlib
import json
import sys
from collections import OrderedDict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, ROOT  # noqa: E402


def j(name):
    p = REPORTS / name
    return json.loads(p.read_text()) if p.exists() else None


def fmt(n):
    return f"{n:,}".replace(",", " ") if isinstance(n, int) else str(n)


def regression():
    r = j("regression.json")
    if not r:
        return None
    extra = j("regression_max.json")          # configurations simulated separately (Icarus: max)
    if extra:
        r["configs"].update(extra["configs"])
        r["builds"].update(extra["builds"])
        r["runs"] += extra["runs"]
        for k in ("verilator_pass", "verilator_total", "completions", "commands"):
            r["summary"][k] += extra["summary"][k]
    L = ["# Regression (tb/tb_cc.sv)", "",
         f"Tools: {r['tools']['verilator']}; {r['tools']['iverilog']}.  Wall time {r['seconds']} s.  Logs: `reports/logs/`.", ""]
    s = r["summary"]
    L += [f"**Regression: {s['verilator_pass']} / {s['verilator_total']} runs pass (Verilator; the `max` configuration with "
          f"Icarus, see below).  Icarus cross-simulation of the minimum configuration: {s['icarus_pass']} / "
          f"{s['icarus_total']}.  Cross-simulator identical (RESULT, cycles, completion counts): {s['cross_identical']} / "
          f"{s['cross_total']}.  Completions checked: {fmt(s['completions'])}.**", ""]
    L += ["## Configurations", "", "| config | parameters | build |", "|---|---|---|"]
    for c, p in r["configs"].items():
        b = r["builds"].get(c, {})
        sim = "Icarus" if c == "max" else "Verilator"
        L.append(f"| {c} | {' '.join(f'{k}={v}' for k, v in p.items())} | {sim}: {'ok' if b.get('ok') else 'FAILED'} ({b.get('seconds', '-')} s) |")
    L += ["", "## Runs", "", "| sim | config | test | seed | result | cycles | commands | completions | OK | engine err | shell | reset-abort |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for x in sorted(r["runs"], key=lambda x: (x["sim"], list(r["configs"]).index(x["cfg"]) if x["cfg"] in r["configs"] else 0, x["test"], x["seed"])):
        L.append(f"| {x['sim']} | {x['cfg']} | {x['test']} | {x['seed']} | {'PASS' if x['ok'] else '**FAIL**'} | "
                 f"{fmt(x.get('cycles', '-'))} | {x.get('commands', '-')} | {x.get('completions', '-')} | {x.get('n_ok', '-')} | "
                 f"{x.get('engine_errors', '-')} | {x.get('shell', '-')} | {x.get('reset_abort', '-')} |")
    fails = [x for x in r["runs"] if not x["ok"]]
    if fails:
        L += ["", "## Failures", ""]
        for x in fails:
            L.append(f"* {x['sim']} {x['cfg']} {x['test']} seed {x['seed']}: {x.get('error_lines', [])[:3]}")
    if r.get("cross_sim"):
        L += ["", "## Icarus vs Verilator (same test, same seed)", "", "| test | seed | identical | Verilator cycles | Icarus cycles |", "|---|---|---|---|---|"]
        for x in r["cross_sim"]:
            L.append(f"| {x['test']} | {x['seed']} | {'yes' if x['identical'] else '**no**'} | {x['verilator_cycles']} | {x['icarus_cycles']} |")
    lat = [x for x in r["runs"] if x.get("latency") and x["sim"] == "verilator"]
    if lat:
        keys = list(lat[0]["latency"])
        L += ["", "## Round-trip latency of single commands (cycles, idle subsystem, 1-cycle memory)", "",
              "| config | " + " | ".join(keys) + " |", "|---|" + "---|" * len(keys)]
        for x in lat:
            L.append(f"| {x['cfg']} | " + " | ".join(str(x["latency"].get(k, "-")) for k in keys) + " |")
    ov = [x for x in r["runs"] if x["sim"] == "verilator" and x["test"] in ("mixed", "multi", "contention", "backpressure")]
    if ov:
        L += ["", "## Simultaneous activity and contention (cycles)", "",
              "| config | test | seed | vector+tensor busy | ≥2 vector busy | ≥2 tensor busy | NoC request stalls (all clusters) | host random ops |",
              "|---|---|---|---|---|---|---|---|"]
        for x in ov:
            st = sum(c.get("mem_stall", 0) for c in x.get("clusters", []))
            L.append(f"| {x['cfg']} | {x['test']} | {x['seed']} | {x.get('ov_vt', '-')} | {x.get('ov_vv', '-')} | "
                     f"{x.get('ov_tt', '-')} | {st} | {x.get('host_ops', '-')} |")
    rs = [x for x in r["runs"] if x["sim"] == "verilator" and x["test"] in ("reset", "reset_drain")]
    if rs:
        L += ["", "## Cluster reset", "", "| config | test | seed | RESET_ABORT completions | OK completions | cycles in reset (sum) |", "|---|---|---|---|---|---|"]
        for x in rs:
            L.append(f"| {x['cfg']} | {x['test']} | {x['seed']} | {x.get('reset_abort')} | {x.get('n_ok')} | "
                     f"{sum(c.get('reset', 0) for c in x.get('clusters', []))} |")
    (REPORTS / "regression.md").write_text("\n".join(L) + "\n")
    return s


def lint():
    r = j("lint.json")
    if not r:
        return None
    L = ["# Lint and elaboration", "", f"Tools: {r['tools']['verilator']}; {r['tools']['iverilog']}; {r['tools']['yosys']}.", "",
         "## Legal configurations", "", "| name | top | parameters | new-RTL warnings (Verilator -Wall) | third-party warnings | Icarus | Yosys |",
         "|---|---|---|---|---|---|---|"]
    for n, x in r["legal"].items():
        L.append(f"| {n} | {x['top']} | {' '.join(f'{k}={v}' for k, v in x['params'].items()) or 'defaults'} | "
                 f"{len(x['new_rtl_warnings'])} | {x['third_party_warnings']} | {'ok' if x['icarus_ok'] else 'FAIL'} | {'ok' if x['yosys_ok'] else 'FAIL'} |")
    L += ["", "Third-party warnings are in reused, unmodified files (mostly `TIMESCALEMOD` of the TENSORCORE / SRAM library "
          "sources); they are reported, not edited.", "",
          "## Illegal configurations (must be refused by every tool)", "",
          "| name | top | parameters | Verilator | Icarus | Yosys | message names the parameter |", "|---|---|---|---|---|---|---|"]
    for n, x in r["illegal"].items():
        L.append(f"| {n} | {x['top']} | {' '.join(f'{k}={v}' for k, v in x['params'].items())} | "
                 f"{'refused' if x['verilator_refused'] else '**accepted**'} | {'refused' if x['icarus_refused'] else '**accepted**'} | "
                 f"{'refused' if x['yosys_refused'] else '**accepted**'} | {'yes' if x['message_names_parameter'] else 'no'} |")
    s = r["summary"]
    L += ["", f"**Legal {s['legal_ok']}/{s['legal_total']} clean; illegal {s['illegal_rejected']}/{s['illegal_total']} refused by all three tools.**"]
    (REPORTS / "lint.md").write_text("\n".join(L) + "\n")
    return s


def synth():
    r = j("synth.json")
    if not r:
        return None
    L = ["# Synthesis (actual Yosys runs)", "",
         f"Tool: {r['tools']['yosys']}.  Flow: `syn/run_synth.py` — hierarchy kept, `synth -run coarse:fine` (memory -nomap), "
         "techmap, `abc -fast`, `check -assert`, latch check.  Raw logs, statistics and hierarchical netlists: "
         "`reports/synth/<target>/`.", "",
         "**Generic, technology-independent synthesis.** Cell counts are Yosys internal gates (`$_AND_`, `$_DFF_P_`, …), not "
         "standard cells; inferred memories stay one `$mem_v2` cell each (future SRAM macros) and are counted separately. "
         "**No area, timing or power is claimed from these numbers.**", "",
         "| target | top | parameters | result | latch-free | gates (excl. memories) | flip-flops | inferred memories | memory bits | modules | time |",
         "|---|---|---|---|---|---|---|---|---|---|---|"]
    for n, x in r["results"].items():
        t = x.get("totals", {})
        m = x.get("memories", {})
        L.append(f"| {n} | {x['top']} | {' '.join(f'{k}={v}' for k, v in x['params'].items()) or 'defaults'} | "
                 f"{'OK' if x['ok'] else 'FAILED'} | {'yes' if x.get('latch_free') else 'no'} | {fmt(t.get('cells', '-'))} | "
                 f"{fmt(t.get('ffs', '-'))} | {m.get('count', '-')} | {fmt(m.get('bits', '-'))} | {x.get('modules', '-')} | {x['seconds']} s |")
    for n, x in r["results"].items():
        if not x.get("top_instances"):
            continue
        L += ["", f"## {n}: top-level instances (each is an identifiable region in the netlist)", "",
              "| instance | module | gates | flip-flops | memories | memory bits | share of gates |", "|---|---|---|---|---|---|---|"]
        tot = x["totals"]["cells"] or 1
        for i in x["top_instances"]:
            L.append(f"| `{i['path']}` | `{i['module'].split(chr(92))[-1]}` | {fmt(i['cells'])} | {fmt(i['ffs'])} | {i['mem_cells']} | "
                     f"{fmt(i['mem_bits'])} | {100.0 * i['cells'] / tot:.1f} % |")
        if x.get("top_own"):
            o = x["top_own"]
            L.append(f"| (top-level own logic) | `{x['top']}` | {fmt(o['own_cells'])} | {fmt(o['own_ffs'])} | {len(o['own_mems'])} | - | "
                     f"{100.0 * o['own_cells'] / tot:.2f} % |")
        mem = REPORTS / "synth" / n / "memories.json"
        if mem.exists():
            ms = json.loads(mem.read_text())
            shapes = OrderedDict()
            for mm in ms:
                k = f"{mm['depth']} x {mm['width']}"
                shapes.setdefault(k, [0, 0, mm["path"]])
                shapes[k][0] += 1
                shapes[k][1] += mm["bits"]
            L += ["", f"Memory inference ({len(ms)} `$mem_v2` cells; full list with instance paths: "
                      f"`reports/synth/{n}/memories.json`):", "", "| depth x width | count | bits | example instance |", "|---|---|---|---|"]
            for k, (c, b, p) in sorted(shapes.items(), key=lambda kv: -kv[1][1]):
                L.append(f"| {k} | {c} | {fmt(b)} | `{p}` |")
    (REPORTS / "synth.md").write_text("\n".join(L) + "\n")
    return {n: dict(ok=x["ok"], cells=x.get("totals", {}).get("cells"), mems=x.get("memories", {}).get("count"))
            for n, x in r["results"].items()}


def physical():
    c = j("physical/check.json")
    L = ["# Physical hierarchy constraints", "",
         "Generated by `scripts/gen_physical.py` from the synthesized hierarchy; checked offline by "
         "`scripts/check_physical.py` (tclsh + `physical/mock_odb.tcl`).  OpenROAD was **not** run (docs/05 §6).", ""]
    for cfg in ("compute_min", "compute_hpc"):
        p = j(f"physical/{cfg}.json")
        if not p:
            continue
        L += [f"## {cfg}", "", f"Layout rows (north → south): {p['rows']}; NoC channel box {p['channel']}; "
              f"weight = gates + {p['mem_bit_weight']} × memory bits (assumption).", "",
              "| region | root instance | gates | flip-flops | memories | memory bits | box (fractions of the core) | NoC side |",
              "|---|---|---|---|---|---|---|---|"]
        for s, r in p["regions"].items():
            L.append(f"| R_{s} | `{r['root']}` | {fmt(r['cells'])} | {fmt(r['ffs'])} | {r['mem_cells']} | {fmt(r['mem_bits'])} | {r['box']} | {r['channel_side']} |")
        sh = p["shell"]
        L.append(f"| R_shell | (top level) | {fmt(sh['cells'])} | {fmt(sh['ffs'])} | {sh['mem_cells']} | {fmt(sh['mem_bits'])} | {sh['box']} | - |")
        L += ["", "Intra-cluster groups (sub-regions variant):", "", "| sub-region | gates | memories | memory bits | box |", "|---|---|---|---|---|"]
        for s, g in p["groups"].items():
            for gn, ga in g["groups"].items():
                L.append(f"| R_{s}_{gn} | {fmt(ga['cells'])} | {ga['mem_cells']} | {fmt(ga['mem_bits'])} | {g['boxes'][gn]} |")
        if c and cfg in c:
            L += ["", "Offline execution of the generated Tcl (OpenROAD-style and Yosys-flattened instance names):", "",
                  "| script | names | result | instances | assigned | regions | overlaps |", "|---|---|---|---|---|---|---|"]
            for k, v in c[cfg].items():
                kind, style = k.rsplit("_", 1)
                L.append(f"| {cfg}.{kind}.tcl | {style} | {'PASS' if v['ok'] else '**FAIL**'} | {v['instances']} | {v['assigned']} | "
                         f"{len(v['regions'])} | {v['overlaps']} |")
        L.append("")
    (REPORTS / "physical.md").write_text("\n".join(L) + "\n")
    if not c:
        return None
    return dict(checks=sum(len(v) for v in c.values()), passed=sum(x["ok"] for v in c.values() for x in v.values()))


SURVIVOR_ANALYSIS = {
    "no_owe_error": (
        "it disables the error responses the scratchpad gate owes for accesses the engine ACCEPTED but never "
        "answered when a reset is forced. With a working engine this state is unreachable: the gate blocks new "
        "accesses from the start of the drain, so every accepted access has had 2^DRAIN_LOG2 cycles to be answered, "
        "and the tile's window port (hpc_dma_spm_port, MAX_OUT = 1) holds at most one access, whose response is then "
        "the one presented to the stalled master -- the captured response, which the reset_drain test covers "
        "(mutant no_rsp_capture is killed there). The owed-error path is kept as defence for a hung engine; testing "
        "it needs an engine fault that this testbench cannot inject without modifying the reused tile."),
}


def mutation():
    r = j("mutation.json")
    if not r:
        return None
    L = ["# Mutation testing of the new RTL", "", "Each mutant is one deliberate bug in `rtl/` (reused RTL is never mutated), "
         "built for the minimum configuration (Icarus Verilog) and run against the listed tests; it is killed when a test fails.", "",
         "| mutant | file | killed | tests (result) |", "|---|---|---|---|"]
    for m in r["mutants"]:
        t = "; ".join(f"{k}: {v['result']}" for k, v in m.get("tests", {}).items()) or m.get("by", m.get("note", ""))
        L.append(f"| {m['name']} | {m['file']} | {'yes' if m['killed'] else '**no**'} | {t} |")
    s = r["summary"]
    L += ["", f"**{s['killed']} / {s['applied']} killed** ({s['seconds']} s)."]
    surv = [m for m in r["mutants"] if m["applied"] and not m["killed"]]
    for m in surv:
        L += ["", f"Survivor `{m['name']}` — analysis: {SURVIVOR_ANALYSIS.get(m['name'], 'not analysed')}"]
    (REPORTS / "mutation.md").write_text("\n".join(L) + "\n")
    return s


def main():
    reg, li, sy, ph, mu = regression(), lint(), synth(), physical(), mutation()
    from common import rtl_hash
    hashes = {n: (j(f) or {}).get("rtl_hash", "not recorded") for n, f in
              (("lint", "lint.json"), ("regression", "regression.json"), ("synthesis", "synth.json"), ("mutation", "mutation.json"))}
    L = ["# Summary of the final run", "",
         f"RTL logic hash now (sha256 over `rtl/*`, comments and blank space removed): `{rtl_hash()}`; recorded by the runs: "
         + ", ".join(f"{k} `{v}`" for k, v in hashes.items()), "",
         "| check | result | report |", "|---|---|---|"]
    if li:
        L.append(f"| Lint / elaboration, legal configurations (Verilator -Wall 0 new-RTL warnings, Icarus, Yosys) | "
                 f"**{li['legal_ok']} / {li['legal_total']}** | [lint](lint.md) |")
        L.append(f"| Illegal configurations refused by Verilator, Icarus and Yosys | **{li['illegal_rejected']} / {li['illegal_total']}** | [lint](lint.md) |")
    if reg:
        L.append(f"| Regression, 8 configurations (Verilator; `max` = 8 V + 4 T under Icarus) | **{reg['verilator_pass']} / {reg['verilator_total']}** | [regression](regression.md) |")
        L.append(f"| Icarus cross-simulation | **{reg['icarus_pass']} / {reg['icarus_total']}**, identical to Verilator "
                 f"{reg['cross_identical']} / {reg['cross_total']} | [regression](regression.md) |")
        L.append(f"| Completion packets checked (routing, tag, order, record) | {fmt(reg['completions'])} | [regression](regression.md) |")
    if mu:
        L.append(f"| Mutants of the new RTL killed | **{mu['killed']} / {mu['applied']}** | [mutation](mutation.md) |")
    if sy:
        for n, x in sy.items():
            L.append(f"| Yosys generic synthesis `{n}` | {'OK' if x['ok'] else 'FAILED'}: {fmt(x['cells'])} gates, {x['mems']} inferred memories | [synth](synth.md) |")
    if ph:
        L.append(f"| Generated region Tcl executed offline against synthesized names | **{ph['passed']} / {ph['checks']}** | [physical](physical.md) |")
    L.append("| OpenROAD placement-region support | **not run** (OpenROAD could not be installed here; `physical/openroad_region_check.tcl`) | [docs/05](../docs/05_PHYSICAL.md) |")
    (REPORTS / "SUMMARY.md").write_text("\n".join(L) + "\n")
    print((REPORTS / "SUMMARY.md").read_text())


if __name__ == "__main__":
    main()
