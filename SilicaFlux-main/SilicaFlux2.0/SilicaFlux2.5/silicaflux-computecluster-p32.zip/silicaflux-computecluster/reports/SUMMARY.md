# Summary of the final run

RTL logic hash now (sha256 over `rtl/*`, comments and blank space removed): `901d9c2ff32c9b7e`; recorded by the runs: lint `901d9c2ff32c9b7e`, regression `901d9c2ff32c9b7e`, synthesis `901d9c2ff32c9b7e`, mutation `901d9c2ff32c9b7e`

| check | result | report |
|---|---|---|
| Lint / elaboration, legal configurations (Verilator -Wall 0 new-RTL warnings, Icarus, Yosys) | **12 / 12** | [lint](lint.md) |
| Illegal configurations refused by Verilator, Icarus and Yosys | **13 / 13** | [lint](lint.md) |
| Regression, 8 configurations (Verilator; `max` = 8 V + 4 T under Icarus) | **85 / 85** | [regression](regression.md) |
| Icarus cross-simulation | **8 / 8**, identical to Verilator 7 / 8 | [regression](regression.md) |
| Completion packets checked (routing, tag, order, record) | 1 997 | [regression](regression.md) |
| Mutants of the new RTL killed | **12 / 13** | [mutation](mutation.md) |
| Yosys generic synthesis `vector_cluster` | OK: 160 274 gates, 34 inferred memories | [synth](synth.md) |
| Yosys generic synthesis `tensor_cluster` | OK: 118 779 gates, 39 inferred memories | [synth](synth.md) |
| Yosys generic synthesis `compute_min` | OK: 278 799 gates, 73 inferred memories | [synth](synth.md) |
| Yosys generic synthesis `compute_hpc` | OK: 880 094 gates, 214 inferred memories | [synth](synth.md) |
| Generated region Tcl executed offline against synthesized names | **8 / 8** | [physical](physical.md) |
| OpenROAD placement-region support | **not run** (OpenROAD could not be installed here; `physical/openroad_region_check.tcl`) | [docs/05](../docs/05_PHYSICAL.md) |
