# Regression (tb/tb_cc.sv)

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) ().  Wall time 2365.4 s.  Logs: `reports/logs/`.

**Regression: 85 / 85 runs pass (Verilator; the `max` configuration with Icarus, see below).  Icarus cross-simulation of the minimum configuration: 8 / 8.  Cross-simulator identical (RESULT, cycles, completion counts): 7 / 8.  Completions checked: 1 997.**

## Configurations

| config | parameters | build |
|---|---|---|
| min | NV=1 NT=1 | Verilator: ok (186.5 s) |
| hpc | NV=4 NT=2 | Verilator: ok (377.5 s) |
| w64_lm_slc | NV=2 NT=1 XW=64 LM=1 MSLC=1 CSLC=1 | Verilator: ok (299.5 s) |
| w128_l8_a8 | NV=1 NT=1 XW=128 VLANES=8 TDIM=8 | Verilator: ok (192.3 s) |
| vec_only | NV=2 NT=0 | Verilator: ok (271.0 s) |
| ten_only | NV=0 NT=2 TDIM=2 | Verilator: ok (224.4 s) |
| max | NV=8 NT=4 | Icarus: ok (- s) |
| min_gate | NV=1 NT=1 GATE=1 | Verilator: ok (199.3 s) |

## Runs

| sim | config | test | seed | result | cycles | commands | completions | OK | engine err | shell | reset-abort |
|---|---|---|---|---|---|---|---|---|---|---|---|
| icarus | min | csr | 1 | PASS | 5 929 | 4 | 4 | 3 | 0 | 1 | 0 |
| icarus | min | errors | 1 | PASS | 569 | 9 | 9 | 4 | 5 | 0 | 0 |
| icarus | min | reset | 1 | PASS | 4 418 | 11 | 11 | 2 | 0 | 0 | 9 |
| icarus | min | reset_drain | 1 | PASS | 3 585 | 3 | 3 | 2 | 0 | 0 | 1 |
| icarus | min | routing | 1 | PASS | 1 027 | 56 | 56 | 24 | 0 | 32 | 0 |
| icarus | min | single_ten | 1 | PASS | 27 088 | 6 | 6 | 6 | 0 | 0 | 0 |
| icarus | min | single_vec | 1 | PASS | 6 176 | 21 | 21 | 21 | 0 | 0 | 0 |
| icarus | min | smoke | 1 | PASS | 328 | 2 | 2 | 2 | 0 | 0 | 0 |
| icarus | max | multi | 1 | PASS | 14 568 | 76 | 76 | 76 | 0 | 0 | 0 |
| icarus | max | routing | 1 | PASS | 2 281 | 192 | 192 | 160 | 0 | 32 | 0 |
| icarus | max | smoke | 1 | PASS | 604 | 12 | 12 | 12 | 0 | 0 | 0 |
| verilator | min | backpressure | 1 | PASS | 11 164 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | min | backpressure | 2 | PASS | 10 698 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | min | backpressure | 3 | PASS | 10 222 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | min | contention | 1 | PASS | 11 658 | 10 | 10 | 10 | 0 | 0 | 0 |
| verilator | min | contention | 2 | PASS | 8 712 | 10 | 10 | 10 | 0 | 0 | 0 |
| verilator | min | csr | 1 | PASS | 5 929 | 4 | 4 | 3 | 0 | 1 | 0 |
| verilator | min | errors | 1 | PASS | 569 | 9 | 9 | 4 | 5 | 0 | 0 |
| verilator | min | latency | 1 | PASS | 738 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | min | mixed | 1 | PASS | 6 200 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | min | multi | 1 | PASS | 6 200 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | min | multi | 2 | PASS | 4 787 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | min | multi | 3 | PASS | 5 792 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | min | reset | 1 | PASS | 4 418 | 11 | 11 | 2 | 0 | 0 | 9 |
| verilator | min | reset | 2 | PASS | 4 415 | 11 | 11 | 2 | 0 | 0 | 9 |
| verilator | min | reset | 3 | PASS | 4 391 | 11 | 11 | 2 | 0 | 0 | 9 |
| verilator | min | reset_drain | 1 | PASS | 3 585 | 3 | 3 | 2 | 0 | 0 | 1 |
| verilator | min | routing | 1 | PASS | 1 056 | 56 | 56 | 24 | 0 | 32 | 0 |
| verilator | min | routing | 2 | PASS | 1 055 | 56 | 56 | 24 | 0 | 32 | 0 |
| verilator | min | single_ten | 1 | PASS | 27 088 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | min | single_ten | 2 | PASS | 27 088 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | min | single_vec | 1 | PASS | 6 176 | 21 | 21 | 21 | 0 | 0 | 0 |
| verilator | min | single_vec | 2 | PASS | 6 176 | 21 | 21 | 21 | 0 | 0 | 0 |
| verilator | min | smoke | 1 | PASS | 328 | 2 | 2 | 2 | 0 | 0 | 0 |
| verilator | hpc | backpressure | 1 | PASS | 26 835 | 40 | 40 | 40 | 0 | 0 | 0 |
| verilator | hpc | backpressure | 2 | PASS | 24 514 | 40 | 40 | 40 | 0 | 0 | 0 |
| verilator | hpc | contention | 1 | PASS | 27 053 | 30 | 30 | 30 | 0 | 0 | 0 |
| verilator | hpc | contention | 2 | PASS | 21 959 | 30 | 30 | 30 | 0 | 0 | 0 |
| verilator | hpc | csr | 1 | PASS | 6 031 | 8 | 8 | 7 | 0 | 1 | 0 |
| verilator | hpc | errors | 1 | PASS | 616 | 13 | 13 | 8 | 5 | 0 | 0 |
| verilator | hpc | mixed | 1 | PASS | 9 462 | 40 | 40 | 40 | 0 | 0 | 0 |
| verilator | hpc | mixed | 2 | PASS | 9 045 | 40 | 40 | 40 | 0 | 0 | 0 |
| verilator | hpc | multi | 1 | PASS | 9 462 | 40 | 40 | 40 | 0 | 0 | 0 |
| verilator | hpc | multi | 2 | PASS | 9 045 | 40 | 40 | 40 | 0 | 0 | 0 |
| verilator | hpc | multi | 3 | PASS | 6 979 | 40 | 40 | 40 | 0 | 0 | 0 |
| verilator | hpc | reset | 1 | PASS | 170 910 | 36 | 36 | 27 | 0 | 0 | 9 |
| verilator | hpc | reset | 2 | PASS | 170 769 | 36 | 36 | 27 | 0 | 0 | 9 |
| verilator | hpc | reset_drain | 1 | PASS | 3 585 | 3 | 3 | 2 | 0 | 0 | 1 |
| verilator | hpc | routing | 1 | PASS | 1 383 | 112 | 112 | 80 | 0 | 32 | 0 |
| verilator | hpc | routing | 2 | PASS | 1 442 | 112 | 112 | 80 | 0 | 32 | 0 |
| verilator | hpc | smoke | 1 | PASS | 383 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | w64_lm_slc | backpressure | 1 | PASS | 8 817 | 22 | 22 | 22 | 0 | 0 | 0 |
| verilator | w64_lm_slc | backpressure | 2 | PASS | 10 061 | 22 | 22 | 22 | 0 | 0 | 0 |
| verilator | w64_lm_slc | csr | 1 | PASS | 6 537 | 5 | 5 | 4 | 0 | 1 | 0 |
| verilator | w64_lm_slc | errors | 1 | PASS | 581 | 10 | 10 | 5 | 5 | 0 | 0 |
| verilator | w64_lm_slc | latency | 1 | PASS | 775 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | w64_lm_slc | localmem | 1 | PASS | 4 335 | 15 | 15 | 15 | 0 | 0 | 0 |
| verilator | w64_lm_slc | localmem | 2 | PASS | 3 457 | 15 | 15 | 15 | 0 | 0 | 0 |
| verilator | w64_lm_slc | multi | 1 | PASS | 4 792 | 22 | 22 | 22 | 0 | 0 | 0 |
| verilator | w64_lm_slc | multi | 2 | PASS | 5 132 | 22 | 22 | 22 | 0 | 0 | 0 |
| verilator | w64_lm_slc | reset | 1 | PASS | 25 197 | 18 | 18 | 9 | 0 | 0 | 9 |
| verilator | w64_lm_slc | reset | 2 | PASS | 25 256 | 18 | 18 | 9 | 0 | 0 | 9 |
| verilator | w64_lm_slc | reset_drain | 1 | PASS | 3 607 | 3 | 3 | 2 | 0 | 0 | 1 |
| verilator | w64_lm_slc | routing | 1 | PASS | 1 130 | 72 | 72 | 40 | 0 | 32 | 0 |
| verilator | w64_lm_slc | single_ten | 1 | PASS | 30 628 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | w64_lm_slc | single_vec | 1 | PASS | 5 196 | 21 | 21 | 21 | 0 | 0 | 0 |
| verilator | w64_lm_slc | smoke | 1 | PASS | 289 | 3 | 3 | 3 | 0 | 0 | 0 |
| verilator | w128_l8_a8 | backpressure | 1 | PASS | 5 573 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | w128_l8_a8 | errors | 1 | PASS | 555 | 9 | 9 | 4 | 5 | 0 | 0 |
| verilator | w128_l8_a8 | multi | 1 | PASS | 2 619 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | w128_l8_a8 | multi | 2 | PASS | 2 549 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | w128_l8_a8 | reset | 1 | PASS | 3 838 | 11 | 11 | 3 | 0 | 0 | 8 |
| verilator | w128_l8_a8 | single_ten | 1 | PASS | 12 612 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | w128_l8_a8 | single_vec | 1 | PASS | 2 055 | 21 | 21 | 21 | 0 | 0 | 0 |
| verilator | w128_l8_a8 | smoke | 1 | PASS | 249 | 2 | 2 | 2 | 0 | 0 | 0 |
| verilator | vec_only | csr | 1 | PASS | 689 | 3 | 3 | 2 | 0 | 1 | 0 |
| verilator | vec_only | errors | 1 | PASS | 564 | 6 | 6 | 3 | 3 | 0 | 0 |
| verilator | vec_only | multi | 1 | PASS | 5 257 | 16 | 16 | 16 | 0 | 0 | 0 |
| verilator | vec_only | reset | 1 | PASS | 36 687 | 14 | 14 | 8 | 0 | 0 | 6 |
| verilator | vec_only | reset_drain | 1 | PASS | 3 426 | 3 | 3 | 2 | 0 | 0 | 1 |
| verilator | vec_only | routing | 1 | PASS | 912 | 56 | 56 | 32 | 0 | 24 | 0 |
| verilator | vec_only | single_vec | 1 | PASS | 6 176 | 21 | 21 | 21 | 0 | 0 | 0 |
| verilator | vec_only | smoke | 1 | PASS | 335 | 2 | 2 | 2 | 0 | 0 | 0 |
| verilator | ten_only | csr | 1 | PASS | 16 164 | 3 | 3 | 3 | 0 | 0 | 0 |
| verilator | ten_only | errors | 1 | PASS | 896 | 5 | 5 | 3 | 2 | 0 | 0 |
| verilator | ten_only | multi | 1 | PASS | 11 123 | 12 | 12 | 12 | 0 | 0 | 0 |
| verilator | ten_only | reset | 1 | PASS | 345 519 | 8 | 8 | 5 | 0 | 0 | 3 |
| verilator | ten_only | reset_drain | 1 | PASS | 3 228 | 2 | 2 | 1 | 0 | 0 | 1 |
| verilator | ten_only | routing | 1 | PASS | 2 091 | 40 | 40 | 16 | 0 | 24 | 0 |
| verilator | ten_only | single_ten | 1 | PASS | 77 868 | 6 | 6 | 6 | 0 | 0 | 0 |
| verilator | ten_only | smoke | 1 | PASS | 467 | 2 | 2 | 2 | 0 | 0 | 0 |
| verilator | min_gate | clkgate | 1 | PASS | 792 | 4 | 4 | 4 | 0 | 0 | 0 |
| verilator | min_gate | clkgate | 2 | PASS | 792 | 4 | 4 | 4 | 0 | 0 | 0 |

## Icarus vs Verilator (same test, same seed)

| test | seed | identical | Verilator cycles | Icarus cycles |
|---|---|---|---|---|
| smoke | 1 | yes | 328 | 328 |
| single_vec | 1 | yes | 6176 | 6176 |
| single_ten | 1 | yes | 27088 | 27088 |
| routing | 1 | **no** | 1056 | 1027 |
| errors | 1 | yes | 569 | 569 |
| csr | 1 | yes | 5929 | 5929 |
| reset | 1 | yes | 4418 | 4418 |
| reset_drain | 1 | yes | 3585 | 3585 |

## Round-trip latency of single commands (cycles, idle subsystem, 1-cycle memory)

| config | vector_nop | vector_dma4 | vector_kernel1 | tensor_nop | tensor_gemm1 | tensor_gemm4 |
|---|---|---|---|---|---|---|
| min | 27 | 36 | 73 | 50 | 121 | 169 |
| w64_lm_slc | 29 | 42 | 81 | 52 | 129 | 180 |

## Simultaneous activity and contention (cycles)

| config | test | seed | vector+tensor busy | ≥2 vector busy | ≥2 tensor busy | NoC request stalls (all clusters) | host random ops |
|---|---|---|---|---|---|---|---|
| min | multi | 1 | 4327 | 0 | 0 | 434 | 0 |
| min | multi | 2 | 4552 | 0 | 0 | 484 | 0 |
| min | multi | 3 | 3567 | 0 | 0 | 341 | 0 |
| min | mixed | 1 | 4327 | 0 | 0 | 434 | 0 |
| min | contention | 1 | 8835 | 0 | 0 | 10498 | 1362 |
| min | contention | 2 | 6074 | 0 | 0 | 7527 | 1030 |
| min | backpressure | 1 | 10320 | 0 | 0 | 8642 | 0 |
| min | backpressure | 2 | 8288 | 0 | 0 | 8049 | 0 |
| min | backpressure | 3 | 8243 | 0 | 0 | 6907 | 0 |
| hpc | multi | 1 | 5762 | 4849 | 8357 | 10946 | 0 |
| hpc | multi | 2 | 5575 | 5305 | 7111 | 12104 | 0 |
| hpc | multi | 3 | 5043 | 4269 | 5108 | 7014 | 0 |
| hpc | mixed | 1 | 5762 | 4849 | 8357 | 10946 | 0 |
| hpc | mixed | 2 | 5575 | 5305 | 7111 | 12104 | 0 |
| hpc | contention | 1 | 15001 | 12944 | 22059 | 75052 | 2294 |
| hpc | contention | 2 | 15293 | 14177 | 15919 | 67734 | 1736 |
| hpc | backpressure | 1 | 17749 | 15861 | 24153 | 79042 | 0 |
| hpc | backpressure | 2 | 18382 | 17635 | 20553 | 81577 | 0 |
| w64_lm_slc | multi | 1 | 3875 | 3160 | 0 | 447 | 0 |
| w64_lm_slc | multi | 2 | 3519 | 1413 | 0 | 304 | 0 |
| w64_lm_slc | backpressure | 1 | 7750 | 5175 | 0 | 8176 | 0 |
| w64_lm_slc | backpressure | 2 | 5529 | 2371 | 0 | 6951 | 0 |
| w128_l8_a8 | multi | 1 | 1833 | 0 | 0 | 171 | 0 |
| w128_l8_a8 | multi | 2 | 1447 | 0 | 0 | 114 | 0 |
| w128_l8_a8 | backpressure | 1 | 3181 | 0 | 0 | 3727 | 0 |
| vec_only | multi | 1 | 0 | 4443 | 0 | 14 | 0 |
| ten_only | multi | 1 | 0 | 0 | 7415 | 778 | 0 |

## Cluster reset

| config | test | seed | RESET_ABORT completions | OK completions | cycles in reset (sum) |
|---|---|---|---|---|---|
| min | reset | 1 | 9 | 2 | 27 |
| min | reset | 2 | 9 | 2 | 23 |
| min | reset | 3 | 9 | 2 | 28 |
| min | reset_drain | 1 | 1 | 2 | 2068 |
| hpc | reset | 1 | 9 | 27 | 51 |
| hpc | reset | 2 | 9 | 27 | 46 |
| hpc | reset_drain | 1 | 1 | 2 | 2068 |
| w64_lm_slc | reset | 1 | 9 | 9 | 52 |
| w64_lm_slc | reset | 2 | 9 | 9 | 46 |
| w64_lm_slc | reset_drain | 1 | 1 | 2 | 2068 |
| w128_l8_a8 | reset | 1 | 8 | 3 | 26 |
| vec_only | reset | 1 | 6 | 8 | 10 |
| vec_only | reset_drain | 1 | 1 | 2 | 2068 |
| ten_only | reset | 1 | 3 | 5 | 17 |
| ten_only | reset_drain | 1 | 1 | 1 | 1034 |
