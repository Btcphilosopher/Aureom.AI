# Lint and elaboration

Tools: Verilator 5.020 2024-01-01 rev (Debian 5.020-1); Icarus Verilog version 12.0 (stable) (); Yosys 0.33 (git sha1 2584903a060).

## Legal configurations

| name | top | parameters | new-RTL warnings (Verilator -Wall) | third-party warnings | Icarus | Yosys |
|---|---|---|---|---|---|---|
| hpc_default | silicaflux_compute_cluster | defaults | 0 | 73 | ok | ok |
| min_1v1t | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=1 NUM_TENSOR_CLUSTERS=1 | 0 | 71 | ok | ok |
| max_8v4t | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=8 NUM_TENSOR_CLUSTERS=4 | 0 | 73 | ok | ok |
| vec_only | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=2 NUM_TENSOR_CLUSTERS=0 | 0 | 71 | ok | ok |
| ten_only | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=0 NUM_TENSOR_CLUSTERS=1 | 0 | 71 | ok | ok |
| w64_lm_slices | silicaflux_compute_cluster | XACT_WIDTH=64 LOCAL_MEM_EN=1 MEM_REQ_SLICE=1 MEM_RSP_SLICE=1 CMD_SLICE=1 CPL_SLICE=1 | 0 | 71 | ok | ok |
| w128_l8_a8 | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=1 NUM_TENSOR_CLUSTERS=1 XACT_WIDTH=128 VEC_NUM_LANES=8 TEN_ARRAY_ROWS=8 TEN_ARRAY_COLS=8 | 0 | 71 | ok | ok |
| quant_dbuf | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=1 NUM_TENSOR_CLUSTERS=2 TEN_ENABLE_QUANTIZATION=1 TEN_ENABLE_DOUBLE_BUFFERING=1 | 0 | 73 | ok | ok |
| vector_cluster | silicaflux_vector_cluster | defaults | 0 | 71 | ok | ok |
| vector_no_spm | silicaflux_vector_cluster | SPM_PORT_EN=0 LOCAL_MEM_EN=1 | 0 | 71 | ok | ok |
| tensor_cluster | silicaflux_tensor_cluster | defaults | 0 | 113 | ok | ok |
| tensor_w128 | silicaflux_tensor_cluster | XACT_WIDTH=128 MEM_REQ_SLICE=1 | 0 | 111 | ok | ok |

Third-party warnings are in reused, unmodified files (mostly `TIMESCALEMOD` of the TENSORCORE / SRAM library sources); they are reported, not edited.

## Illegal configurations (must be refused by every tool)

| name | top | parameters | Verilator | Icarus | Yosys | message names the parameter |
|---|---|---|---|---|---|---|
| nv9 | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=9 | refused | refused | refused | yes |
| nt5 | silicaflux_compute_cluster | NUM_TENSOR_CLUSTERS=5 | refused | refused | refused | yes |
| none | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=0 NUM_TENSOR_CLUSTERS=0 | refused | refused | refused | yes |
| xw48 | silicaflux_compute_cluster | XACT_WIDTH=48 | refused | refused | refused | yes |
| spm_overlap | silicaflux_compute_cluster | VEC_SPM_STRIDE=32'h00008000 | refused | refused | refused | yes |
| lm_stride | silicaflux_compute_cluster | LOCAL_MEM_EN=1 LOCAL_MEM_MASK=32'hFFFFF000 LOCAL_MEM_STRIDE=32'h00000800 | refused | refused | refused | yes |
| trk_depth12 | silicaflux_compute_cluster | TRK_DEPTH=12 | refused | refused | refused | yes |
| tag_w33 | silicaflux_compute_cluster | TAG_W=33 | refused | refused | refused | yes |
| drain30 | silicaflux_compute_cluster | DRAIN_LOG2=30 | refused | refused | refused | yes |
| rst0 | silicaflux_compute_cluster | RST_CYCLES=0 | refused | refused | refused | yes |
| lanes3 | silicaflux_compute_cluster | VEC_NUM_LANES=3 | refused | refused | refused | yes |
| tensor5x5 | silicaflux_compute_cluster | TEN_ARRAY_ROWS=5 TEN_ARRAY_COLS=5 | refused | refused | refused | yes |
| spm_port2 | silicaflux_vector_cluster | SPM_PORT_EN=2 | refused | refused | refused | yes |

**Legal 12/12 clean; illegal 13/13 refused by all three tools.**
