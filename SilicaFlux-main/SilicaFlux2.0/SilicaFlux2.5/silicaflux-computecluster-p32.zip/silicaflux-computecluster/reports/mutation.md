# Mutation testing of the new RTL

Each mutant is one deliberate bug in `rtl/` (reused RTL is never mutated), built for the minimum configuration (Icarus Verilog) and run against the listed tests; it is killed when a test fails.

| mutant | file | killed | tests (result) |
|---|---|---|---|
| trk_no_reset_abort | sfx_cl_cmd_port.sv | yes | reset: FAIL |
| no_host_deny | sfx_cl_cmd_port.sv | yes | errors: FAIL |
| no_length_check | sfx_cl_cmd_port.sv | yes | routing: FAIL |
| err_summary_zero | sfx_cl_cmd_port.sv | yes | errors: FAIL |
| tag_from_tail | sfx_cl_cmd_port.sv | yes | smoke: FAIL; routing: FAIL |
| no_drop | sfx_cl_mem_port.sv | yes | reset_drain: FAIL |
| no_quiesce | sfx_cl_mem_port.sv | yes | reset: FAIL; reset_drain: PASS |
| no_force | sfx_cl_ctrl.sv | yes | reset_drain: FAIL |
| no_owe_error | sfx_cl_slv_gate.sv | **no** | reset: PASS; reset_drain: PASS |
| no_rsp_capture | sfx_cl_slv_gate.sv | yes | reset_drain: FAIL |
| merge_no_lock | silicaflux_compute_cluster.sv | yes | routing: FAIL; multi: PASS |
| router_wrong_slot | silicaflux_compute_cluster.sv | yes | smoke: FAIL |
| no_init_write | sfx_cl_cmd_port.sv | yes | smoke: FAIL; errors: FAIL |

**12 / 13 killed** (255.1 s).

Survivor `no_owe_error` — analysis: it disables the error responses the scratchpad gate owes for accesses the engine ACCEPTED but never answered when a reset is forced. With a working engine this state is unreachable: the gate blocks new accesses from the start of the drain, so every accepted access has had 2^DRAIN_LOG2 cycles to be answered, and the tile's window port (hpc_dma_spm_port, MAX_OUT = 1) holds at most one access, whose response is then the one presented to the stalled master -- the captured response, which the reset_drain test covers (mutant no_rsp_capture is killed there). The owed-error path is kept as defence for a hung engine; testing it needs an engine fault that this testbench cannot inject without modifying the reused tile.
