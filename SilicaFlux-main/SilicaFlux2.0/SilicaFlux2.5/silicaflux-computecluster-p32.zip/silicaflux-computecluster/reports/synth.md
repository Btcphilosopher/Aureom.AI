# Synthesis (actual Yosys runs)

Tool: Yosys 0.33 (git sha1 2584903a060).  Flow: `syn/run_synth.py` — hierarchy kept, `synth -run coarse:fine` (memory -nomap), techmap, `abc -fast`, `check -assert`, latch check.  Raw logs, statistics and hierarchical netlists: `reports/synth/<target>/`.

**Generic, technology-independent synthesis.** Cell counts are Yosys internal gates (`$_AND_`, `$_DFF_P_`, …), not standard cells; inferred memories stay one `$mem_v2` cell each (future SRAM macros) and are counted separately. **No area, timing or power is claimed from these numbers.**

| target | top | parameters | result | latch-free | gates (excl. memories) | flip-flops | inferred memories | memory bits | modules | time |
|---|---|---|---|---|---|---|---|---|---|---|
| vector_cluster | silicaflux_vector_cluster | defaults | OK | yes | 160 274 | 11 661 | 34 | 530 484 | 61 | 57.8 s |
| tensor_cluster | silicaflux_tensor_cluster | defaults | OK | yes | 118 779 | 12 519 | 39 | 27 592 | 71 | 84.5 s |
| compute_min | silicaflux_compute_cluster | NUM_VECTOR_CLUSTERS=1 NUM_TENSOR_CLUSTERS=1 | OK | yes | 278 799 | 24 257 | 73 | 558 076 | 131 | 169.5 s |
| compute_hpc | silicaflux_compute_cluster | defaults | OK | yes | 880 094 | 71 761 | 214 | 2 177 120 | 171 | 285.0 s |

## vector_cluster: top-level instances (each is an identifiable region in the netlist)

| instance | module | gates | flip-flops | memories | memory bits | share of gates |
|---|---|---|---|---|---|---|
| `g_spm.u_spm_gate` | `sfx_cl_slv_gate` | 151 | 39 | 0 | 0 | 0.1 % |
| `u_cmd` | `sfx_cl_cmd_port` | 3 728 | 551 | 0 | 0 | 2.3 % |
| `u_ctrl` | `sfx_cl_ctrl` | 1 288 | 201 | 0 | 0 | 0.8 % |
| `u_engine` | `silicaflux_hpc_tile` | 154 855 | 10 793 | 34 | 530 484 | 96.6 % |
| `u_mem` | `sfx_cl_mem_port` | 213 | 77 | 0 | 0 | 0.1 % |
| (top-level own logic) | `silicaflux_vector_cluster` | 39 | 0 | 0 | - | 0.02 % |

Memory inference (34 `$mem_v2` cells; full list with instance paths: `reports/synth/vector_cluster/memories.json`):

| depth x width | count | bits | example instance |
|---|---|---|---|
| 4096 x 32 | 4 | 524 288 | `u_engine/g_core.u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` |
| 8 x 272 | 1 | 2 176 | `u_engine/g_core.u_cmdq/mem` |
| 8 x 172 | 1 | 1 376 | `u_engine/g_core.u_cplq/mem` |
| 2 x 96 | 4 | 768 | `u_engine/g_core.u_lsu/g_grp[0].ent` |
| 2 x 32 | 6 | 384 | `u_engine/g_core.u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_data` |
| 8 x 47 | 1 | 376 | `u_engine/g_core.u_array/u_trk/mem_q` |
| 2 x 22 | 6 | 264 | `u_engine/g_core.u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` |
| 2 x 97 | 1 | 194 | `u_engine/g_core.u_dma/g_core.g_cmdq.u_cmdq/mem` |
| 2 x 70 | 1 | 140 | `u_engine/g_core.u_dma/g_core.u_cplq/mem` |
| 2 x 64 | 1 | 128 | `u_engine/g_core.u_array/u_issue/u_cq/mem_q` |
| 4 x 32 | 1 | 128 | `u_engine/g_core.u_sched/rob_ts` |
| 2 x 61 | 1 | 122 | `u_engine/g_core.u_array/u_cplq/mem_q` |
| 4 x 16 | 1 | 64 | `u_engine/g_core.u_sched/rob_seq` |
| 4 x 4 | 2 | 32 | `u_engine/g_core.u_sched/rob_st` |
| 4 x 8 | 1 | 32 | `u_engine/g_core.u_sched/rob_tag` |
| 4 x 2 | 1 | 8 | `u_engine/g_core.u_sched/rob_kind` |
| 1 x 4 | 1 | 4 | `u_engine/g_core.u_dma/g_core.g_port[0].u_route/info_q` |

## tensor_cluster: top-level instances (each is an identifiable region in the netlist)

| instance | module | gates | flip-flops | memories | memory bits | share of gates |
|---|---|---|---|---|---|---|
| `u_cmd` | `sfx_cl_cmd_port` | 3 723 | 551 | 0 | 0 | 3.1 % |
| `u_ctrl` | `sfx_cl_ctrl` | 1 286 | 201 | 0 | 0 | 1.1 % |
| `u_engine` | `silicaflux_tensor_unit` | 113 519 | 11 690 | 39 | 27 592 | 95.6 % |
| `u_mem` | `sfx_cl_mem_port` | 213 | 77 | 0 | 0 | 0.2 % |
| (top-level own logic) | `silicaflux_tensor_cluster` | 38 | 0 | 0 | - | 0.03 % |

Memory inference (39 `$mem_v2` cells; full list with instance paths: `reports/synth/tensor_cluster/memories.json`):

| depth x width | count | bits | example instance |
|---|---|---|---|
| 64 x 32 | 4 | 8 192 | `u_engine/u_dp/u_tob/g_abank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` |
| 128 x 32 | 2 | 8 192 | `u_engine/u_dp/u_tob/g_bbank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` |
| 32 x 32 | 2 | 2 048 | `u_engine/u_dp/u_ob/u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` |
| 4 x 248 | 2 | 1 984 | `u_engine/u_dp/u_dma/u_ql/mem` |
| 4 x 192 | 2 | 1 536 | `u_engine/u_cplq/mem` |
| 4 x 384 | 1 | 1 536 | `u_engine/u_cq/mem` |
| 8 x 132 | 1 | 1 056 | `u_engine/u_dp/u_acc/u_store/mem` |
| 4 x 160 | 1 | 640 | `u_engine/u_dp/u_acc/u_acc/u_ofifo/mem` |
| 32 x 8 | 2 | 512 | `u_engine/u_dp/u_dma/u_ld/u_rl/mem` |
| 4 x 41 | 3 | 492 | `u_engine/u_dp/u_dma/u_obp/u_of/mem` |
| 2 x 32 | 6 | 384 | `u_engine/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_data` |
| 4 x 81 | 1 | 324 | `u_engine/u_dp/u_dma/u_cq/mem` |
| 8 x 13 | 2 | 208 | `u_engine/u_dp/u_ob/u_g0/u_pend/mem` |
| 4 x 33 | 1 | 132 | `u_engine/u_dp/u_dma/u_sfb/u_of/mem` |
| 4 x 32 | 1 | 128 | `u_engine/u_dp/u_tob/u_bstage/mem` |
| 2 x 36 | 1 | 72 | `u_engine/u_dp/u_tob/u_trsp/mem` |
| 4 x 12 | 1 | 48 | `u_engine/u_dp/u_tob/u_dma/u_rsp_fifo/mem` |
| 2 x 11 | 2 | 44 | `u_engine/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` |
| 4 x 5 | 2 | 40 | `u_engine/u_dp/u_dma/u_ld/u_rmeta/mem` |
| 4 x 3 | 2 | 24 | `u_engine/u_dp/u_dma/u_ld/u_wmeta/mem` |

## compute_min: top-level instances (each is an identifiable region in the netlist)

| instance | module | gates | flip-flops | memories | memory bits | share of gates |
|---|---|---|---|---|---|---|
| `u_tensor_0.u_cl` | `silicaflux_tensor_cluster` | 118 011 | 12 519 | 39 | 27 592 | 42.3 % |
| `u_vector_0.u_cl` | `silicaflux_vector_cluster` | 160 278 | 11 661 | 34 | 530 484 | 57.5 % |
| (top-level own logic) | `silicaflux_compute_cluster` | 510 | 77 | 0 | - | 0.18 % |

Memory inference (73 `$mem_v2` cells; full list with instance paths: `reports/synth/compute_min/memories.json`):

| depth x width | count | bits | example instance |
|---|---|---|---|
| 4096 x 32 | 4 | 524 288 | `u_vector_0.u_cl/u_engine/g_core.u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` |
| 64 x 32 | 4 | 8 192 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/g_abank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` |
| 128 x 32 | 2 | 8 192 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/g_bbank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` |
| 8 x 272 | 1 | 2 176 | `u_vector_0.u_cl/u_engine/g_core.u_cmdq/mem` |
| 32 x 32 | 2 | 2 048 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` |
| 4 x 248 | 2 | 1 984 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ql/mem` |
| 4 x 192 | 2 | 1 536 | `u_tensor_0.u_cl/u_engine/u_cplq/mem` |
| 4 x 384 | 1 | 1 536 | `u_tensor_0.u_cl/u_engine/u_cq/mem` |
| 8 x 172 | 1 | 1 376 | `u_vector_0.u_cl/u_engine/g_core.u_cplq/mem` |
| 8 x 132 | 1 | 1 056 | `u_tensor_0.u_cl/u_engine/u_dp/u_acc/u_store/mem` |
| 2 x 32 | 12 | 768 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_data` |
| 2 x 96 | 4 | 768 | `u_vector_0.u_cl/u_engine/g_core.u_lsu/g_grp[0].ent` |
| 4 x 160 | 1 | 640 | `u_tensor_0.u_cl/u_engine/u_dp/u_acc/u_acc/u_ofifo/mem` |
| 32 x 8 | 2 | 512 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ld/u_rl/mem` |
| 4 x 41 | 3 | 492 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_obp/u_of/mem` |
| 8 x 47 | 1 | 376 | `u_vector_0.u_cl/u_engine/g_core.u_array/u_trk/mem_q` |
| 4 x 81 | 1 | 324 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_cq/mem` |
| 2 x 22 | 6 | 264 | `u_vector_0.u_cl/u_engine/g_core.u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` |
| 4 x 32 | 2 | 256 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/u_bstage/mem` |
| 8 x 13 | 2 | 208 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_g0/u_pend/mem` |
| 2 x 97 | 1 | 194 | `u_vector_0.u_cl/u_engine/g_core.u_dma/g_core.g_cmdq.u_cmdq/mem` |
| 2 x 70 | 1 | 140 | `u_vector_0.u_cl/u_engine/g_core.u_dma/g_core.u_cplq/mem` |
| 4 x 33 | 1 | 132 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_sfb/u_of/mem` |
| 2 x 64 | 1 | 128 | `u_vector_0.u_cl/u_engine/g_core.u_array/u_issue/u_cq/mem_q` |
| 2 x 61 | 1 | 122 | `u_vector_0.u_cl/u_engine/g_core.u_array/u_cplq/mem_q` |
| 2 x 36 | 1 | 72 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/u_trsp/mem` |
| 4 x 16 | 1 | 64 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_seq` |
| 4 x 12 | 1 | 48 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/u_dma/u_rsp_fifo/mem` |
| 2 x 11 | 2 | 44 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` |
| 4 x 5 | 2 | 40 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ld/u_rmeta/mem` |
| 4 x 4 | 2 | 32 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_st` |
| 4 x 8 | 1 | 32 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_tag` |
| 4 x 3 | 2 | 24 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ld/u_wmeta/mem` |
| 4 x 2 | 1 | 8 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_kind` |
| 1 x 4 | 1 | 4 | `u_vector_0.u_cl/u_engine/g_core.u_dma/g_core.g_port[0].u_route/info_q` |

## compute_hpc: top-level instances (each is an identifiable region in the netlist)

| instance | module | gates | flip-flops | memories | memory bits | share of gates |
|---|---|---|---|---|---|---|
| `u_tensor_0.u_cl` | `silicaflux_tensor_cluster` | 118 422 | 12 519 | 39 | 27 592 | 13.5 % |
| `u_tensor_1.u_cl` | `silicaflux_tensor_cluster` | 118 427 | 12 519 | 39 | 27 592 | 13.5 % |
| `u_vector_0.u_cl` | `silicaflux_vector_cluster` | 160 485 | 11 661 | 34 | 530 484 | 18.2 % |
| `u_vector_1.u_cl` | `silicaflux_vector_cluster` | 160 556 | 11 661 | 34 | 530 484 | 18.2 % |
| `u_vector_2.u_cl` | `silicaflux_vector_cluster` | 160 542 | 11 661 | 34 | 530 484 | 18.2 % |
| `u_vector_3.u_cl` | `silicaflux_vector_cluster` | 160 546 | 11 661 | 34 | 530 484 | 18.2 % |
| (top-level own logic) | `silicaflux_compute_cluster` | 1 116 | 79 | 0 | - | 0.13 % |

Memory inference (214 `$mem_v2` cells; full list with instance paths: `reports/synth/compute_hpc/memories.json`):

| depth x width | count | bits | example instance |
|---|---|---|---|
| 4096 x 32 | 16 | 2 097 152 | `u_vector_0.u_cl/u_engine/g_core.u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` |
| 64 x 32 | 8 | 16 384 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/g_abank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` |
| 128 x 32 | 4 | 16 384 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/g_bbank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` |
| 8 x 272 | 4 | 8 704 | `u_vector_0.u_cl/u_engine/g_core.u_cmdq/mem` |
| 8 x 172 | 4 | 5 504 | `u_vector_0.u_cl/u_engine/g_core.u_cplq/mem` |
| 32 x 32 | 4 | 4 096 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` |
| 4 x 248 | 4 | 3 968 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ql/mem` |
| 4 x 192 | 4 | 3 072 | `u_tensor_0.u_cl/u_engine/u_cplq/mem` |
| 4 x 384 | 2 | 3 072 | `u_tensor_0.u_cl/u_engine/u_cq/mem` |
| 2 x 96 | 16 | 3 072 | `u_vector_0.u_cl/u_engine/g_core.u_lsu/g_grp[0].ent` |
| 2 x 32 | 36 | 2 304 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_data` |
| 8 x 132 | 2 | 2 112 | `u_tensor_0.u_cl/u_engine/u_dp/u_acc/u_store/mem` |
| 8 x 47 | 4 | 1 504 | `u_vector_0.u_cl/u_engine/g_core.u_array/u_trk/mem_q` |
| 4 x 160 | 2 | 1 280 | `u_tensor_0.u_cl/u_engine/u_dp/u_acc/u_acc/u_ofifo/mem` |
| 2 x 22 | 24 | 1 056 | `u_vector_0.u_cl/u_engine/g_core.u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` |
| 32 x 8 | 4 | 1 024 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ld/u_rl/mem` |
| 4 x 41 | 6 | 984 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_obp/u_of/mem` |
| 2 x 97 | 4 | 776 | `u_vector_0.u_cl/u_engine/g_core.u_dma/g_core.g_cmdq.u_cmdq/mem` |
| 4 x 32 | 6 | 768 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/u_bstage/mem` |
| 4 x 81 | 2 | 648 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_cq/mem` |
| 2 x 70 | 4 | 560 | `u_vector_0.u_cl/u_engine/g_core.u_dma/g_core.u_cplq/mem` |
| 2 x 64 | 4 | 512 | `u_vector_0.u_cl/u_engine/g_core.u_array/u_issue/u_cq/mem_q` |
| 2 x 61 | 4 | 488 | `u_vector_0.u_cl/u_engine/g_core.u_array/u_cplq/mem_q` |
| 8 x 13 | 4 | 416 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_g0/u_pend/mem` |
| 4 x 33 | 2 | 264 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_sfb/u_of/mem` |
| 4 x 16 | 4 | 256 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_seq` |
| 2 x 36 | 2 | 144 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/u_trsp/mem` |
| 4 x 4 | 8 | 128 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_st` |
| 4 x 8 | 4 | 128 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_tag` |
| 4 x 12 | 2 | 96 | `u_tensor_0.u_cl/u_engine/u_dp/u_tob/u_dma/u_rsp_fifo/mem` |
| 2 x 11 | 4 | 88 | `u_tensor_0.u_cl/u_engine/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` |
| 4 x 5 | 4 | 80 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ld/u_rmeta/mem` |
| 4 x 3 | 4 | 48 | `u_tensor_0.u_cl/u_engine/u_dp/u_dma/u_ld/u_wmeta/mem` |
| 4 x 2 | 4 | 32 | `u_vector_0.u_cl/u_engine/g_core.u_sched/rob_kind` |
| 1 x 4 | 4 | 16 | `u_vector_0.u_cl/u_engine/g_core.u_dma/g_core.g_port[0].u_route/info_q` |
