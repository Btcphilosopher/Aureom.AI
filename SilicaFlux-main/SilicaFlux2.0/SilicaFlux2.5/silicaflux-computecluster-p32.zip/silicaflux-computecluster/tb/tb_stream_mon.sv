// =============================================================================
// SilicaFlux-HPC Project 32 :: tb_stream_mon   (verification only)
// Valid/ready stream rules for the cluster command and completion streams:
//   S1 a word held (valid && !ready) stays valid with an unchanged payload;
//   S2 no X/Z on valid / ready after reset;
//   S3 packets are LEN words long when LEN > 0 (last exactly on word LEN).
// =============================================================================
`default_nettype none
module tb_stream_mon #(
  parameter int W    = 32,
  parameter int LEN  = 0,
  parameter     NAME = "stream"
) (
  input  wire logic         clk,
  input  wire logic         rst_n,
  input  wire logic         valid,
  input  wire logic         ready,
  input  wire logic [W-1:0] payload,
  input  wire logic         last,
  output int                violations,
  output int                packets
);
  logic         held;
  logic [W-1:0] p_q;
  int           cnt;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      held <= 1'b0; violations <= 0; packets <= 0; cnt <= 0;
    end else begin
      if ((valid !== 1'b0 && valid !== 1'b1) || (ready !== 1'b0 && ready !== 1'b1)) begin
        violations <= violations + 1; $display("ERROR [%s] X on valid/ready", NAME);
      end
      if (held && (!valid || payload !== p_q)) begin
        violations <= violations + 1; $display("ERROR [%s] S1: held word changed or withdrawn", NAME);
      end
      held <= valid && !ready;
      p_q  <= payload;
      if (valid && ready) begin
        if (last) begin
          packets <= packets + 1;
          if (LEN > 0 && cnt + 1 != LEN) begin
            violations <= violations + 1; $display("ERROR [%s] S3: packet of %0d words, expected %0d", NAME, cnt + 1, LEN);
          end
          cnt <= 0;
        end else begin
          cnt <= cnt + 1;
        end
      end
    end
  end
endmodule
`default_nettype wire
