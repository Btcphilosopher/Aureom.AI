// =============================================================================
// SilicaFlux-HPC Project 32 :: tb_sfb_mem   (verification only)
// Behavioural SFB2 memory with NP independent slave ports over ONE byte array,
// so the testbench scoreboard can compare every region (shared SRAM behind the
// DataFabric crossbar, one local memory per cluster) against its golden image.
//   port p: bus window [BUS_BASE[p], BUS_BASE[p] + BYTES[p]) -> store[ST_OFF[p] + ...]
//   * writes are performed at acceptance (SFB2 R7: the response follows later);
//   * reads sample at acceptance (in-order port: equivalent to SFB2 R5 order);
//   * response latency: lat + random 0..jit cycles, in order, QD in flight per port;
//   * req_ready randomly withheld (stall_pct); responses can be frozen (freeze[p]);
//   * outside the window, or misaligned: rsp_error = 1, rdata = 0 (R8), no write;
//   * write responses carry rdata = 0 (R8, checked by sfb_protocol_checker).
// Deterministic xorshift random streams (identical under Icarus and Verilator).
// =============================================================================
`default_nettype none
module tb_sfb_mem #(
  parameter int          NP          = 1,
  parameter int          DW          = 32,
  parameter int          STORE_BYTES = 1 << 20,
  parameter int          QD          = 8,
  parameter logic [NP*32-1:0] BUS_BASE = '0,
  parameter logic [NP*32-1:0] BYTES    = '0,
  parameter logic [NP*32-1:0] ST_OFF   = '0,
  localparam int SB = DW / 8
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic [31:0]      seed,
  input  wire logic [31:0]      lat,
  input  wire logic [31:0]      jit,
  input  wire logic [31:0]      stall_pct,
  input  wire logic [NP-1:0]    freeze,
  input  wire logic [NP-1:0]    req_valid,
  output logic      [NP-1:0]    req_ready,
  input  wire logic [NP-1:0]    req_write,
  input  wire logic [NP*32-1:0] req_addr,
  input  wire logic [NP*DW-1:0] req_wdata,
  input  wire logic [NP*SB-1:0] req_wstrb,
  output logic      [NP-1:0]    rsp_valid,
  input  wire logic [NP-1:0]    rsp_ready,
  output logic      [NP*DW-1:0] rsp_rdata,
  output logic      [NP-1:0]    rsp_error
);
  logic [7:0] store [STORE_BYTES];
  longint     cyc;
  // per-port response FIFO (internal: only this module reads it)
  logic [DW-1:0] q_d   [NP][QD];
  logic          q_e   [NP][QD];
  longint        q_t   [NP][QD];
  int            q_wp  [NP], q_rp [NP], q_n [NP];
  int unsigned   rs [NP];

  function automatic int unsigned xr(input int p);
    int unsigned x;
    x = rs[p]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[p] = x;
    return x;
  endfunction

  // Outputs are registers computed for the next cycle (no combinational logic over the FIFO arrays):
  // a presented response is held until accepted (R4); req_ready never depends on req_valid.
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cyc <= 0;
      req_ready <= '0; rsp_valid <= '0; rsp_rdata <= '0; rsp_error <= '0;
      for (int p = 0; p < NP; p++) begin
        q_wp[p] = 0; q_rp[p] = 0; q_n[p] = 0;
        rs[p] = seed ^ (32'h9E37_79B9 * (p + 1)); if (rs[p] == 0) rs[p] = 1;
      end
    end else begin
      cyc <= cyc + 1;
      for (int p = 0; p < NP; p++) begin
        logic [31:0] a, base, nb, off;
        logic [DW-1:0] d;
        logic e, pop, push;
        int extra, h;
        pop  = rsp_valid[p] && rsp_ready[p];
        push = req_valid[p] && req_ready[p];
        if (pop) begin q_rp[p] = (q_rp[p] + 1) % QD; q_n[p] = q_n[p] - 1; end
        if (push) begin
          a    = req_addr[p*32 +: 32];
          base = BUS_BASE[p*32 +: 32];
          nb   = BYTES[p*32 +: 32];
          off  = a - base;
          e    = (a < base) || (off >= nb) || ((a % SB) != 0);
          d    = '0;
          if (!e) begin
            for (int b = 0; b < SB; b++) begin
              if (req_write[p]) begin
                if (req_wstrb[p*SB + b]) store[ST_OFF[p*32 +: 32] + off + b] = req_wdata[p*DW + 8*b +: 8];
              end else begin
                d[8*b +: 8] = store[ST_OFF[p*32 +: 32] + off + b];
              end
            end
          end
          extra = (jit > 0) ? int'(xr(p) % (jit + 1)) : 0;
          q_d[p][q_wp[p]] = req_write[p] ? '0 : d;
          q_e[p][q_wp[p]] = e;
          q_t[p][q_wp[p]] = cyc + longint'(lat) + longint'(extra);
          q_wp[p] = (q_wp[p] + 1) % QD; q_n[p] = q_n[p] + 1;
        end
        // next-cycle outputs
        if (rsp_valid[p] && !rsp_ready[p]) begin
          // held response: unchanged
        end else begin
          h = q_rp[p];
          if (q_n[p] > 0 && !freeze[p] && (cyc + 1) >= q_t[p][h]) begin
            rsp_valid[p] <= 1'b1; rsp_rdata[p*DW +: DW] <= q_d[p][h]; rsp_error[p] <= q_e[p][h];
          end else begin
            rsp_valid[p] <= 1'b0; rsp_rdata[p*DW +: DW] <= '0; rsp_error[p] <= 1'b0;
          end
        end
        req_ready[p] <= (q_n[p] < QD) && !((stall_pct > 0) && ((xr(p) % 100) < stall_pct));
      end
    end
  end
endmodule
`default_nettype wire
