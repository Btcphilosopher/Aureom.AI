// testbench sources (after rtl/files.f)
+incdir+tb
third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv
tb/tb_sfb_mem.sv
tb/tb_sfb_throttle.sv
tb/tb_stream_mon.sv
tb/tb_cc.sv
