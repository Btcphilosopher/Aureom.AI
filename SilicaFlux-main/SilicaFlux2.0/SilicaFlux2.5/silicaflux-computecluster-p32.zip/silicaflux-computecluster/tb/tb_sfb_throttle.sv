// =============================================================================
// SilicaFlux-HPC Project 32 :: tb_sfb_throttle   (verification only)
// SFB2 back-pressure / stall injector between a master (s_*) and a slave (m_*).
//   * request channel: randomly withholds a request that has NOT been presented
//     yet (a presented request is never withdrawn: SFB2 R2 on the slave side);
//   * response channel: randomly withholds, or with freeze = 1 stops, responses
//     that have not been presented yet (a presented response stays: R4).
// Pure valid/ready gating; no storage, so ordering and payloads are untouched.
// =============================================================================
`default_nettype none
module tb_sfb_throttle #(
  parameter int  DW = 32,
  localparam int SB = DW / 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic [31:0]   seed,
  input  wire logic [31:0]   req_pct,
  input  wire logic [31:0]   rsp_pct,
  input  wire logic          freeze,
  input  wire logic          s_req_valid,
  output logic               s_req_ready,
  input  wire logic          s_req_write,
  input  wire logic [31:0]   s_req_addr,
  input  wire logic [DW-1:0] s_req_wdata,
  input  wire logic [SB-1:0] s_req_wstrb,
  output logic               s_rsp_valid,
  input  wire logic          s_rsp_ready,
  output logic [DW-1:0]      s_rsp_rdata,
  output logic               s_rsp_error,
  output logic               m_req_valid,
  input  wire logic          m_req_ready,
  output logic               m_req_write,
  output logic [31:0]        m_req_addr,
  output logic [DW-1:0]      m_req_wdata,
  output logic [SB-1:0]      m_req_wstrb,
  input  wire logic          m_rsp_valid,
  output logic               m_rsp_ready,
  input  wire logic [DW-1:0] m_rsp_rdata,
  input  wire logic          m_rsp_error
);
  logic        qblk, rblk, qpres, rpres;
  int unsigned rs;
  function automatic int unsigned xr();
    int unsigned x;
    x = rs; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs = x;
    return x;
  endfunction

  wire qgate = qblk && !qpres;
  wire rgate = (rblk || freeze) && !rpres;
  assign m_req_valid = s_req_valid && !qgate;
  assign s_req_ready = m_req_ready && !qgate;
  assign m_req_write = s_req_write;
  assign m_req_addr  = s_req_addr;
  assign m_req_wdata = s_req_wdata;
  assign m_req_wstrb = s_req_wstrb;
  assign s_rsp_valid = m_rsp_valid && !rgate;
  assign m_rsp_ready = s_rsp_ready && !rgate;
  assign s_rsp_rdata = m_rsp_rdata;
  assign s_rsp_error = m_rsp_error;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      qblk <= 1'b0; rblk <= 1'b0; qpres <= 1'b0; rpres <= 1'b0;
      rs = (seed == 0) ? 32'h1234_5678 : seed;
    end else begin
      qpres <= m_req_valid && !m_req_ready;
      rpres <= s_rsp_valid && !s_rsp_ready;
      qblk  <= (req_pct > 0) && ((xr() % 100) < req_pct);
      rblk  <= (rsp_pct > 0) && ((xr() % 100) < rsp_pct);
    end
  end
endmodule
`default_nettype wire
