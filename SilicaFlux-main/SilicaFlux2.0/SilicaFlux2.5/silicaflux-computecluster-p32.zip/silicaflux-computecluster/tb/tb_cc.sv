// =============================================================================
// SilicaFlux-HPC Project 32 :: tb_cc   (verification only)
// System testbench of silicaflux_compute_cluster.
//
//   tb command issuer ─► DUT cmd ─► u_vector_k / u_tensor_k ─► DUT cpl ─► scoreboard (order, routing, records)
//   DUT NoC ports ─► protocol checker ─► tb_sfb_throttle ─► DataFabric sfb_crossbar (the "NoC") ─┬─► shared SRAM
//   tb host master (random contention traffic / directed accesses) ───────────────────────────────┤
//                                                                                                 └─► vector k scratchpad windows
//   DUT local-memory ports ─► protocol checker ─► local SRAM per cluster (LM = 1)
//
// Memory is ONE byte array (tb_sfb_mem) with a golden image + care mask: inputs are the random initial
// contents (or written by the builder), expected outputs are computed when a command is built, and the
// whole image is compared at the end (regions of aborted / failed commands are excluded).
// Every completion is checked: routing (src), tag, per-cluster order, header, engine record status / echo.
// Tests (+TEST=): smoke single_vec single_ten multi mixed contention backpressure routing reset reset_drain
//                 errors csr clkgate localmem
// =============================================================================
`timescale 1ns/1ps
`include "sfx_cl_defs.svh"
`default_nettype none
module tb_cc;
  // ------------------------------------------------------------ configuration (scripts/run_tests.py)
  parameter int NV     = 1;
  parameter int NT     = 1;
  parameter int XW     = 32;
  parameter int LM     = 0;
  parameter int MSLC   = 0;
  parameter int CSLC   = 0;
  parameter int TDIM   = 4;
  parameter int VLANES = 4;
  parameter int DRAIN  = 10;
  parameter int GATE   = 0;      // 1: the whole DUT clock is gated by the clusters' clk_req (+ wake events)
  localparam int NC = NV + NT;
  localparam int VA = (NV > 0) ? NV : 1;
  localparam int TA = (NT > 0) ? NT : 1;
  localparam int SB = XW / 8;
  localparam int TAGW = 8;
  localparam int EW = `SFX_CL_ERR_W, PW = `SFX_CL_PEV_W;
  // ------------------------------------------------------------ memory map
  localparam logic [31:0] SRAM_BASE  = 32'h1000_0000;
  localparam int          SRAM_BYTES = 1 << 19;
  localparam int          PRIV_BYTES = 1 << 16;                       // host random-traffic window (top of SRAM)
  localparam logic [31:0] SPM_BASE   = 32'h2000_0000, SPM_STRIDE = 32'h0010_0000;
  localparam int          SPM_BYTES  = 65536;
  localparam logic [31:0] LM_BASE    = 32'h3000_0000, LM_STRIDE = 32'h0001_0000, LM_MASK = 32'hFFFF_0000;
  localparam int          LM_BYTES   = 16384;
  localparam logic [31:0] BAD_ADDR   = 32'h1F00_0000;                 // inside the tensor window, unmapped
  localparam int          STORE      = SRAM_BYTES + NC * LM_BYTES;
  localparam int          NM         = NC + 1;                        // crossbar masters: clusters + tb host
  localparam int          NS         = 1 + NV;                        // crossbar slaves: SRAM + scratchpads
  localparam int          NPM        = 1 + NC;                        // memory model ports: SRAM + local

  // ------------------------------------------------------------ clock, reset, counters
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 60) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end

  // independent xorshift streams: 0 command builder, 1 issuer, 2 completion receiver, 3 host master.  Every call
  // is unconditional or behind an explicit 'if' (no reliance on && short-circuit), so Icarus and Verilator draw
  // the same sequence.
  int unsigned rss [4];
  function automatic int unsigned rnds(input int k);
    int unsigned x;
    x = rss[k]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rss[k] = x; return x;
  endfunction
  function automatic int unsigned rnd(); return rnds(0); endfunction
  function automatic int urange(input int lo, input int hi);
    return lo + int'(rnd() % (hi - lo + 1));
  endfunction

  // ------------------------------------------------------------ run-time knobs (plusargs)
  string  test = "smoke";
  int     seed = 1, mem_lat = 1, mem_jit = 0, mem_stall = 0, thr_req = 0, thr_rsp = 0, cpl_stall = 0, cmd_gap = 0;
  int     host_pct = 0;
  longint max_cyc = 2000000;

  // ------------------------------------------------------------ DUT
  logic             cmd_valid, cmd_last, cmd_ready;
  logic [31:0]      cmd_data = '0;
  logic [TAGW-1:0]  cmd_tag = '0;
  logic [3:0]       cmd_dest = '0;
  logic             cpl_valid, cpl_ready = 1'b0, cpl_last, cpl_err;
  logic [31:0]      cpl_data;
  logic [TAGW-1:0]  cpl_tag;
  logic [3:0]       cpl_src;
  logic             csr_sel = 1'b0, csr_we = 1'b0, csr_err;
  logic [16:0]      csr_addr = '0;
  logic [31:0]      csr_wdata = '0, csr_rdata;
  logic [VA-1:0]    vec_rst_req = '0;
  logic [TA-1:0]    ten_rst_req = '0;

  // DUT memory ports in DUT order
  logic [VA-1:0]    vm_req_valid, vm_req_ready, vm_req_write, vm_rsp_valid, vm_rsp_ready, vm_rsp_error;
  logic [VA*32-1:0] vm_req_addr;
  logic [VA*XW-1:0] vm_req_wdata, vm_rsp_rdata;
  logic [VA*SB-1:0] vm_req_wstrb;
  logic [TA-1:0]    tm_req_valid, tm_req_ready, tm_req_write, tm_rsp_valid, tm_rsp_ready, tm_rsp_error;
  logic [TA*32-1:0] tm_req_addr;
  logic [TA*XW-1:0] tm_req_wdata, tm_rsp_rdata;
  logic [TA*SB-1:0] tm_req_wstrb;
  logic [VA-1:0]    vl_req_valid, vl_req_ready, vl_req_write, vl_rsp_valid, vl_rsp_ready, vl_rsp_error;
  logic [VA*32-1:0] vl_req_addr;
  logic [VA*XW-1:0] vl_req_wdata, vl_rsp_rdata;
  logic [VA*SB-1:0] vl_req_wstrb;
  logic [TA-1:0]    tl_req_valid, tl_req_ready, tl_req_write, tl_rsp_valid, tl_rsp_ready, tl_rsp_error;
  logic [TA*32-1:0] tl_req_addr;
  logic [TA*XW-1:0] tl_req_wdata, tl_rsp_rdata;
  logic [TA*SB-1:0] tl_req_wstrb;
  logic [VA-1:0]    sp_req_valid, sp_req_ready, sp_req_write, sp_rsp_valid, sp_rsp_ready, sp_rsp_error;
  logic [VA*32-1:0] sp_req_addr;
  logic [VA*XW-1:0] sp_req_wdata, sp_rsp_rdata;
  logic [VA*SB-1:0] sp_req_wstrb;
  logic [VA-1:0]    v_irq, v_err, v_busy, v_clk_req;
  logic [TA-1:0]    t_irq, t_err, t_busy, t_clk_req;
  logic [VA*EW-1:0] v_err_status;
  logic [TA*EW-1:0] t_err_status;
  logic [VA*PW-1:0] v_perf_ev;
  logic [TA*PW-1:0] t_perf_ev;
  logic             irq_any, err_any;

  // optional clock gating of the whole DUT by clk_req (test clkgate): latch-based ICG model
  logic dut_clk, gate_en, gate_en_l;
  wire  any_clk_req = (|v_clk_req) || (|t_clk_req);     // absent types are tied to 0 by the DUT
  assign gate_en = !rst_n || any_clk_req || cmd_valid || csr_sel || (|sp_req_valid) || (|vec_rst_req) || (|ten_rst_req);
  always @(clk or gate_en) if (!clk) gate_en_l <= gate_en;
  assign dut_clk = (GATE != 0) ? (clk && gate_en_l) : clk;
  longint gated_cycles = 0;
  always @(posedge clk) if (GATE != 0 && !gate_en_l) gated_cycles <= gated_cycles + 1;

  silicaflux_compute_cluster #(
    .NUM_VECTOR_CLUSTERS(NV), .NUM_TENSOR_CLUSTERS(NT), .VEC_NUM_LANES(VLANES), .VEC_SCRATCHPAD_BYTES(SPM_BYTES),
    .VEC_SPM_BASE(SPM_BASE), .VEC_SPM_STRIDE(SPM_STRIDE),
    .TEN_ARRAY_ROWS(TDIM), .TEN_ARRAY_COLS(TDIM), .TEN_MEM_LO(33'h0_1000_0000), .TEN_MEM_HI(33'h0_4000_0000),
    .XACT_WIDTH(XW), .LOCAL_MEM_EN(LM), .LOCAL_MEM_BASE(LM_BASE), .LOCAL_MEM_STRIDE(LM_STRIDE),
    .LOCAL_MEM_MASK(LM_MASK), .MEM_REQ_SLICE(MSLC), .MEM_RSP_SLICE(MSLC), .CMD_SLICE(CSLC), .CPL_SLICE(CSLC),
    .TAG_W(TAGW), .DRAIN_LOG2(DRAIN)
  ) dut (
    .clk(dut_clk), .rst_n(rst_n),
    .cmd_valid, .cmd_ready, .cmd_data, .cmd_last, .cmd_tag, .cmd_dest,
    .cpl_valid, .cpl_ready, .cpl_data, .cpl_last, .cpl_tag, .cpl_src, .cpl_err,
    .csr_sel, .csr_we, .csr_addr, .csr_wdata, .csr_rdata, .csr_err,
    .vec_rst_req, .ten_rst_req,
    .vec_mem_req_valid(vm_req_valid), .vec_mem_req_ready(vm_req_ready), .vec_mem_req_write(vm_req_write),
    .vec_mem_req_addr(vm_req_addr), .vec_mem_req_wdata(vm_req_wdata), .vec_mem_req_wstrb(vm_req_wstrb),
    .vec_mem_rsp_valid(vm_rsp_valid), .vec_mem_rsp_ready(vm_rsp_ready), .vec_mem_rsp_rdata(vm_rsp_rdata),
    .vec_mem_rsp_error(vm_rsp_error),
    .vec_lm_req_valid(vl_req_valid), .vec_lm_req_ready(vl_req_ready), .vec_lm_req_write(vl_req_write),
    .vec_lm_req_addr(vl_req_addr), .vec_lm_req_wdata(vl_req_wdata), .vec_lm_req_wstrb(vl_req_wstrb),
    .vec_lm_rsp_valid(vl_rsp_valid), .vec_lm_rsp_ready(vl_rsp_ready), .vec_lm_rsp_rdata(vl_rsp_rdata),
    .vec_lm_rsp_error(vl_rsp_error),
    .vec_spm_req_valid(sp_req_valid), .vec_spm_req_ready(sp_req_ready), .vec_spm_req_write(sp_req_write),
    .vec_spm_req_addr(sp_req_addr), .vec_spm_req_wdata(sp_req_wdata), .vec_spm_req_wstrb(sp_req_wstrb),
    .vec_spm_rsp_valid(sp_rsp_valid), .vec_spm_rsp_ready(sp_rsp_ready), .vec_spm_rsp_rdata(sp_rsp_rdata),
    .vec_spm_rsp_error(sp_rsp_error),
    .ten_mem_req_valid(tm_req_valid), .ten_mem_req_ready(tm_req_ready), .ten_mem_req_write(tm_req_write),
    .ten_mem_req_addr(tm_req_addr), .ten_mem_req_wdata(tm_req_wdata), .ten_mem_req_wstrb(tm_req_wstrb),
    .ten_mem_rsp_valid(tm_rsp_valid), .ten_mem_rsp_ready(tm_rsp_ready), .ten_mem_rsp_rdata(tm_rsp_rdata),
    .ten_mem_rsp_error(tm_rsp_error),
    .ten_lm_req_valid(tl_req_valid), .ten_lm_req_ready(tl_req_ready), .ten_lm_req_write(tl_req_write),
    .ten_lm_req_addr(tl_req_addr), .ten_lm_req_wdata(tl_req_wdata), .ten_lm_req_wstrb(tl_req_wstrb),
    .ten_lm_rsp_valid(tl_rsp_valid), .ten_lm_rsp_ready(tl_rsp_ready), .ten_lm_rsp_rdata(tl_rsp_rdata),
    .ten_lm_rsp_error(tl_rsp_error),
    .vec_irq(v_irq), .vec_err(v_err), .vec_err_status(v_err_status), .vec_busy(v_busy), .vec_clk_req(v_clk_req),
    .vec_perf_ev(v_perf_ev),
    .ten_irq(t_irq), .ten_err(t_err), .ten_err_status(t_err_status), .ten_busy(t_busy), .ten_clk_req(t_clk_req),
    .ten_perf_ev(t_perf_ev),
    .irq_any, .err_any
  );

  // ------------------------------------------------------------ per-cluster views (cluster index c: vectors, then tensors)
  logic [NC-1:0]    c_req_valid, c_req_ready, c_req_write, c_rsp_valid, c_rsp_ready, c_rsp_error;
  logic [NC*32-1:0] c_req_addr;
  logic [NC*XW-1:0] c_req_wdata, c_rsp_rdata;
  logic [NC*SB-1:0] c_req_wstrb;
  logic [NC-1:0]    l_req_valid, l_req_ready, l_req_write, l_rsp_valid, l_rsp_ready, l_rsp_error;
  logic [NC*32-1:0] l_req_addr;
  logic [NC*XW-1:0] l_req_wdata, l_rsp_rdata;
  logic [NC*SB-1:0] l_req_wstrb;
  logic [NC-1:0]    c_busy, c_err, c_irq, c_clk_req;
  logic [NC*EW-1:0] c_err_status;
  logic [NC*PW-1:0] c_perf_ev;
  for (genvar c = 0; c < NC; c++) begin : g_view
    if (c < NV) begin : g_v
      assign c_req_valid[c] = vm_req_valid[c];  assign vm_req_ready[c] = c_req_ready[c];
      assign c_req_write[c] = vm_req_write[c];  assign c_req_addr[c*32 +: 32] = vm_req_addr[c*32 +: 32];
      assign c_req_wdata[c*XW +: XW] = vm_req_wdata[c*XW +: XW]; assign c_req_wstrb[c*SB +: SB] = vm_req_wstrb[c*SB +: SB];
      assign vm_rsp_valid[c] = c_rsp_valid[c];  assign c_rsp_ready[c] = vm_rsp_ready[c];
      assign vm_rsp_rdata[c*XW +: XW] = c_rsp_rdata[c*XW +: XW]; assign vm_rsp_error[c] = c_rsp_error[c];
      assign l_req_valid[c] = vl_req_valid[c];  assign vl_req_ready[c] = l_req_ready[c];
      assign l_req_write[c] = vl_req_write[c];  assign l_req_addr[c*32 +: 32] = vl_req_addr[c*32 +: 32];
      assign l_req_wdata[c*XW +: XW] = vl_req_wdata[c*XW +: XW]; assign l_req_wstrb[c*SB +: SB] = vl_req_wstrb[c*SB +: SB];
      assign vl_rsp_valid[c] = l_rsp_valid[c];  assign l_rsp_ready[c] = vl_rsp_ready[c];
      assign vl_rsp_rdata[c*XW +: XW] = l_rsp_rdata[c*XW +: XW]; assign vl_rsp_error[c] = l_rsp_error[c];
      assign c_busy[c] = v_busy[c]; assign c_err[c] = v_err[c]; assign c_irq[c] = v_irq[c]; assign c_clk_req[c] = v_clk_req[c];
      assign c_err_status[c*EW +: EW] = v_err_status[c*EW +: EW]; assign c_perf_ev[c*PW +: PW] = v_perf_ev[c*PW +: PW];
    end else begin : g_t
      localparam int k = c - NV;
      assign c_req_valid[c] = tm_req_valid[k];  assign tm_req_ready[k] = c_req_ready[c];
      assign c_req_write[c] = tm_req_write[k];  assign c_req_addr[c*32 +: 32] = tm_req_addr[k*32 +: 32];
      assign c_req_wdata[c*XW +: XW] = tm_req_wdata[k*XW +: XW]; assign c_req_wstrb[c*SB +: SB] = tm_req_wstrb[k*SB +: SB];
      assign tm_rsp_valid[k] = c_rsp_valid[c];  assign c_rsp_ready[c] = tm_rsp_ready[k];
      assign tm_rsp_rdata[k*XW +: XW] = c_rsp_rdata[c*XW +: XW]; assign tm_rsp_error[k] = c_rsp_error[c];
      assign l_req_valid[c] = tl_req_valid[k];  assign tl_req_ready[k] = l_req_ready[c];
      assign l_req_write[c] = tl_req_write[k];  assign l_req_addr[c*32 +: 32] = tl_req_addr[k*32 +: 32];
      assign l_req_wdata[c*XW +: XW] = tl_req_wdata[k*XW +: XW]; assign l_req_wstrb[c*SB +: SB] = tl_req_wstrb[k*SB +: SB];
      assign tl_rsp_valid[k] = l_rsp_valid[c];  assign l_rsp_ready[c] = tl_rsp_ready[k];
      assign tl_rsp_rdata[k*XW +: XW] = l_rsp_rdata[c*XW +: XW]; assign tl_rsp_error[k] = l_rsp_error[c];
      assign c_busy[c] = t_busy[k]; assign c_err[c] = t_err[k]; assign c_irq[c] = t_irq[k]; assign c_clk_req[c] = t_clk_req[k];
      assign c_err_status[c*EW +: EW] = t_err_status[k*EW +: EW]; assign c_perf_ev[c*PW +: PW] = t_perf_ev[k*PW +: PW];
    end
  end
  if (NV == 0) begin : g_nov
    assign vm_req_ready = '0; assign vm_rsp_valid = '0; assign vm_rsp_rdata = '0; assign vm_rsp_error = '0;
    assign vl_req_ready = '0; assign vl_rsp_valid = '0; assign vl_rsp_rdata = '0; assign vl_rsp_error = '0;
  end
  if (NT == 0) begin : g_not
    assign tm_req_ready = '0; assign tm_rsp_valid = '0; assign tm_rsp_rdata = '0; assign tm_rsp_error = '0;
    assign tl_req_ready = '0; assign tl_rsp_valid = '0; assign tl_rsp_rdata = '0; assign tl_rsp_error = '0;
  end
  function automatic int dest_of(input int c); return (c < NV) ? c : 8 + (c - NV); endfunction
  function automatic int cl_of(input int d);   return (d < 8) ? d : NV + (d - 8); endfunction

  // ------------------------------------------------------------ throttles + crossbar ("NoC") + host master
  logic [NC-1:0]    freeze = '0;
  logic [NM-1:0]    x_req_valid, x_req_ready, x_req_write, x_rsp_valid, x_rsp_ready, x_rsp_error;
  logic [NM*32-1:0] x_req_addr;
  logic [NM*XW-1:0] x_req_wdata, x_rsp_rdata;
  logic [NM*SB-1:0] x_req_wstrb;
  for (genvar c = 0; c < NC; c++) begin : g_thr
    tb_sfb_throttle #(.DW(XW)) u_thr (
      .clk, .rst_n, .seed(32'(seed * 7919 + c * 104729 + 1)), .req_pct(32'(thr_req)), .rsp_pct(32'(thr_rsp)),
      .freeze(freeze[c]),
      .s_req_valid(c_req_valid[c]), .s_req_ready(c_req_ready[c]), .s_req_write(c_req_write[c]),
      .s_req_addr(c_req_addr[c*32 +: 32]), .s_req_wdata(c_req_wdata[c*XW +: XW]), .s_req_wstrb(c_req_wstrb[c*SB +: SB]),
      .s_rsp_valid(c_rsp_valid[c]), .s_rsp_ready(c_rsp_ready[c]), .s_rsp_rdata(c_rsp_rdata[c*XW +: XW]),
      .s_rsp_error(c_rsp_error[c]),
      .m_req_valid(x_req_valid[c]), .m_req_ready(x_req_ready[c]), .m_req_write(x_req_write[c]),
      .m_req_addr(x_req_addr[c*32 +: 32]), .m_req_wdata(x_req_wdata[c*XW +: XW]), .m_req_wstrb(x_req_wstrb[c*SB +: SB]),
      .m_rsp_valid(x_rsp_valid[c]), .m_rsp_ready(x_rsp_ready[c]), .m_rsp_rdata(x_rsp_rdata[c*XW +: XW]),
      .m_rsp_error(x_rsp_error[c])
    );
  end
  // tb host master on the last crossbar port
  logic             h_v_q = 1'b0;
  logic             h_rsp_hold = 1'b0;        // stall the host's response acceptance (reset_drain)
  logic             h_req_valid;
  assign h_req_valid = h_v_q;
  logic             h_req_write = 1'b0, h_req_ready, h_rsp_valid, h_rsp_error;
  logic [31:0]      h_req_addr = '0;
  logic [XW-1:0]    h_req_wdata = '0, h_rsp_rdata;
  logic [SB-1:0]    h_req_wstrb = '0;
  assign x_req_valid[NC] = h_req_valid; assign h_req_ready = x_req_ready[NC]; assign x_req_write[NC] = h_req_write;
  assign x_req_addr[NC*32 +: 32] = h_req_addr; assign x_req_wdata[NC*XW +: XW] = h_req_wdata;
  assign x_req_wstrb[NC*SB +: SB] = h_req_wstrb; assign h_rsp_valid = x_rsp_valid[NC];
  assign x_rsp_ready[NC] = !h_rsp_hold; assign h_rsp_rdata = x_rsp_rdata[NC*XW +: XW]; assign h_rsp_error = x_rsp_error[NC];

  function automatic logic [NS*32-1:0] slv_base();
    slv_base = '0;
    slv_base[31:0] = SRAM_BASE;
    for (int k = 0; k < NV; k++) slv_base[(k+1)*32 +: 32] = SPM_BASE + 32'(k) * SPM_STRIDE;
  endfunction
  function automatic logic [NS*32-1:0] slv_mask();
    slv_mask = '0;
    slv_mask[31:0] = ~32'(SRAM_BYTES - 1);
    for (int k = 0; k < NV; k++) slv_mask[(k+1)*32 +: 32] = ~32'(SPM_BYTES - 1);
  endfunction
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*32-1:0] s_req_addr;
  logic [NS*XW-1:0] s_req_wdata, s_rsp_rdata;
  logic [NS*SB-1:0] s_req_wstrb;
  logic             xe_evt, xe_write;
  logic [31:0]      xe_addr;
  logic [$clog2(NM)-1:0] xe_master;
  logic [NM-1:0]    xm_acc, xm_stall, xm_loss, xm_rstall;
  sfb_crossbar #(.NM(NM), .NS(NS), .AW(32), .DW(XW), .ARB_MODE(1), .CHECK_ALIGN(1),
                 .SLV_BASE(slv_base()), .SLV_MASK(slv_mask()), .MST_SLV_EN({(NM*NS){1'b1}})) u_xbar (
    .clk, .rst_n,
    .m_req_valid(x_req_valid), .m_req_ready(x_req_ready), .m_req_write(x_req_write), .m_req_addr(x_req_addr),
    .m_req_wdata(x_req_wdata), .m_req_wstrb(x_req_wstrb), .m_rsp_valid(x_rsp_valid), .m_rsp_ready(x_rsp_ready),
    .m_rsp_rdata(x_rsp_rdata), .m_rsp_error(x_rsp_error),
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(xe_evt), .err_addr(xe_addr), .err_master(xe_master), .err_write(xe_write),
    .ev_req_accept(xm_acc), .ev_req_stall(xm_stall), .ev_arb_loss(xm_loss), .ev_rsp_stall(xm_rstall)
  );
  // crossbar slaves 1..NV -> vector scratchpad windows
  for (genvar k = 0; k < NV; k++) begin : g_spm
    assign sp_req_valid[k] = s_req_valid[k+1]; assign s_req_ready[k+1] = sp_req_ready[k];
    assign sp_req_write[k] = s_req_write[k+1]; assign sp_req_addr[k*32 +: 32] = s_req_addr[(k+1)*32 +: 32];
    assign sp_req_wdata[k*XW +: XW] = s_req_wdata[(k+1)*XW +: XW]; assign sp_req_wstrb[k*SB +: SB] = s_req_wstrb[(k+1)*SB +: SB];
    assign s_rsp_valid[k+1] = sp_rsp_valid[k]; assign sp_rsp_ready[k] = s_rsp_ready[k+1];
    assign s_rsp_rdata[(k+1)*XW +: XW] = sp_rsp_rdata[k*XW +: XW]; assign s_rsp_error[k+1] = sp_rsp_error[k];
  end
  if (NV == 0) begin : g_nosp
    assign sp_req_valid = '0; assign sp_req_write = '0; assign sp_req_addr = '0; assign sp_req_wdata = '0;
    assign sp_req_wstrb = '0; assign sp_rsp_ready = '1;
  end

  // ------------------------------------------------------------ memory: SRAM (crossbar slave 0) + local memories
  function automatic logic [NPM*32-1:0] mp(input int which);     // constant function (no calls: Icarus)
    logic [NPM*32-1:0] r;
    int d;
    r = '0;
    for (int p = 0; p < NPM; p++) begin
      d = (p - 1 < NV) ? p - 1 : 8 + (p - 1 - NV);
      if (p == 0) r[31:0] = (which == 0) ? SRAM_BASE : (which == 1) ? SRAM_BYTES : 0;
      else        r[p*32 +: 32] = (which == 0) ? LM_BASE + d * LM_STRIDE :
                                  (which == 1) ? LM_BYTES : SRAM_BYTES + (p - 1) * LM_BYTES;
    end
    return r;
  endfunction
  logic [NPM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NPM*32-1:0] m_req_addr;
  logic [NPM*XW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NPM*SB-1:0] m_req_wstrb;
  logic [NPM-1:0]    m_freeze = '0;
  assign m_req_valid[0] = s_req_valid[0]; assign s_req_ready[0] = m_req_ready[0]; assign m_req_write[0] = s_req_write[0];
  assign m_req_addr[31:0] = s_req_addr[31:0]; assign m_req_wdata[XW-1:0] = s_req_wdata[XW-1:0];
  assign m_req_wstrb[SB-1:0] = s_req_wstrb[SB-1:0]; assign s_rsp_valid[0] = m_rsp_valid[0];
  assign m_rsp_ready[0] = s_rsp_ready[0]; assign s_rsp_rdata[XW-1:0] = m_rsp_rdata[XW-1:0];
  assign s_rsp_error[0] = m_rsp_error[0];
  assign m_req_valid[NPM-1:1] = l_req_valid; assign l_req_ready = m_req_ready[NPM-1:1];
  assign m_req_write[NPM-1:1] = l_req_write; assign m_req_addr[NPM*32-1:32] = l_req_addr;
  assign m_req_wdata[NPM*XW-1:XW] = l_req_wdata; assign m_req_wstrb[NPM*SB-1:SB] = l_req_wstrb;
  assign l_rsp_valid = m_rsp_valid[NPM-1:1]; assign m_rsp_ready[NPM-1:1] = l_rsp_ready;
  assign l_rsp_rdata = m_rsp_rdata[NPM*XW-1:XW]; assign l_rsp_error = m_rsp_error[NPM-1:1];

  tb_sfb_mem #(.NP(NPM), .DW(XW), .STORE_BYTES(STORE), .QD(8), .BUS_BASE(mp(0)), .BYTES(mp(1)), .ST_OFF(mp(2))) u_mem (
    .clk, .rst_n, .seed(32'(seed)), .lat(32'(mem_lat)), .jit(32'(mem_jit)), .stall_pct(32'(mem_stall)),
    .freeze(m_freeze),
    .req_valid(m_req_valid), .req_ready(m_req_ready), .req_write(m_req_write), .req_addr(m_req_addr),
    .req_wdata(m_req_wdata), .req_wstrb(m_req_wstrb), .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready),
    .rsp_rdata(m_rsp_rdata), .rsp_error(m_rsp_error)
  );

  // ------------------------------------------------------------ protocol checkers on every cluster port
  logic [31:0] pv_noc [NC], pv_lm [NC], pv_spm [VA], pv_host;
  logic [31:0] pn_req [NC], pn_rsp_u [NC], pn_out_u [NC];
  for (genvar c = 0; c < NC; c++) begin : g_chk
    logic [31:0] a_u, b_u, d_u, e_u, f_u;
    sfb_protocol_checker #(.DW(XW), .MAX_OUT(8), .NAME("cluster_noc")) u_noc (
      .clk(dut_clk), .rst_n,
      .req_valid(c_req_valid[c]), .req_ready(c_req_ready[c]), .req_write(c_req_write[c]),
      .req_addr(c_req_addr[c*32 +: 32]), .req_wdata(c_req_wdata[c*XW +: XW]), .req_wstrb(c_req_wstrb[c*SB +: SB]),
      .rsp_valid(c_rsp_valid[c]), .rsp_ready(c_rsp_ready[c]), .rsp_rdata(c_rsp_rdata[c*XW +: XW]),
      .rsp_error(c_rsp_error[c]), .violations(pv_noc[c]), .n_req(pn_req[c]), .n_rsp(pn_rsp_u[c]), .outstanding(pn_out_u[c]));
    sfb_protocol_checker #(.DW(XW), .MAX_OUT(8), .NAME("cluster_lm")) u_lm (
      .clk(dut_clk), .rst_n,
      .req_valid(l_req_valid[c]), .req_ready(l_req_ready[c]), .req_write(l_req_write[c]),
      .req_addr(l_req_addr[c*32 +: 32]), .req_wdata(l_req_wdata[c*XW +: XW]), .req_wstrb(l_req_wstrb[c*SB +: SB]),
      .rsp_valid(l_rsp_valid[c]), .rsp_ready(l_rsp_ready[c]), .rsp_rdata(l_rsp_rdata[c*XW +: XW]),
      .rsp_error(l_rsp_error[c]), .violations(pv_lm[c]), .n_req(a_u), .n_rsp(b_u), .outstanding(d_u));
  end
  for (genvar k = 0; k < VA; k++) begin : g_chks
    logic [31:0] a_u, b_u, d_u;
    sfb_protocol_checker #(.DW(XW), .MAX_OUT(8), .NAME("cluster_spm")) u_spm (
      .clk, .rst_n,
      .req_valid(sp_req_valid[k]), .req_ready(sp_req_ready[k]), .req_write(sp_req_write[k]),
      .req_addr(sp_req_addr[k*32 +: 32]), .req_wdata(sp_req_wdata[k*XW +: XW]), .req_wstrb(sp_req_wstrb[k*SB +: SB]),
      .rsp_valid(sp_rsp_valid[k]), .rsp_ready(sp_rsp_ready[k]), .rsp_rdata(sp_rsp_rdata[k*XW +: XW]),
      .rsp_error(sp_rsp_error[k]), .violations(pv_spm[k]), .n_req(a_u), .n_rsp(b_u), .outstanding(d_u));
  end
  logic [31:0] hc_a, hc_b, hc_d;
  sfb_protocol_checker #(.DW(XW), .MAX_OUT(1), .NAME("tb_host")) u_hchk (
    .clk, .rst_n, .req_valid(h_req_valid), .req_ready(h_req_ready), .req_write(h_req_write), .req_addr(h_req_addr),
    .req_wdata(h_req_wdata), .req_wstrb(h_req_wstrb), .rsp_valid(h_rsp_valid), .rsp_ready(!h_rsp_hold),
    .rsp_rdata(h_rsp_rdata), .rsp_error(h_rsp_error), .violations(pv_host), .n_req(hc_a), .n_rsp(hc_b), .outstanding(hc_d));
  int sv_cmd, sv_cpl, sp_cmd_u, sp_cpl;
  tb_stream_mon #(.W(36 + TAGW), .LEN(0), .NAME("cmd")) u_cmon (
    .clk, .rst_n, .valid(cmd_valid), .ready(cmd_ready), .payload({cmd_dest, cmd_tag, cmd_data}), .last(cmd_last),
    .violations(sv_cmd), .packets(sp_cmd_u));
  tb_stream_mon #(.W(37 + TAGW), .LEN(`SFX_CL_CPL_WORDS), .NAME("cpl")) u_pmon (
    .clk, .rst_n, .valid(cpl_valid), .ready(cpl_ready), .payload({cpl_src, cpl_err, cpl_tag, cpl_data}), .last(cpl_last),
    .violations(sv_cpl), .packets(sp_cpl));

  // ------------------------------------------------------------ white-box: no new memory transaction during a drain
  // While a cluster's reset sequencer holds its ports quiesced (u_ctrl.port_q: Q_MEM, RESET, RELEASE), a request
  // may appear at its NoC port only if it was already presented, un-accepted, in the previous cycle (SFB2 R2) --
  // including the request a forced reset captures.  Checked without memory slices (a slice may legitimately present
  // a request it accepted before the drain).
  logic [NC-1:0] pq, q_held;
`define TB_PQ_V(K) if (K < NV) begin : g_pqv``K assign pq[K] = dut.u_vector_``K.u_cl.port_q; end
`define TB_PQ_T(K) if (K < NT) begin : g_pqt``K assign pq[NV + K] = dut.u_tensor_``K.u_cl.port_q; end
  `TB_PQ_V(0) `TB_PQ_V(1) `TB_PQ_V(2) `TB_PQ_V(3) `TB_PQ_V(4) `TB_PQ_V(5) `TB_PQ_V(6) `TB_PQ_V(7)
  `TB_PQ_T(0) `TB_PQ_T(1) `TB_PQ_T(2) `TB_PQ_T(3)
`undef TB_PQ_V
`undef TB_PQ_T
  int quiesce_viol = 0;
  always @(posedge dut_clk) begin
    if (!rst_n) q_held <= '0;
    else begin
      for (int c = 0; c < NC; c++)
        if (MSLC == 0 && pq[c] && c_req_valid[c] && !q_held[c]) begin
          quiesce_viol++;
          if (quiesce_viol <= 5) $display("ERROR cyc=%0d: cluster %0d: new memory request while its ports are quiesced", cyc, c);
        end
      q_held <= c_req_valid & ~c_req_ready;
    end
  end

  // ------------------------------------------------------------ statistics
  longint pev_cnt [NC][PW];
  longint ov_vt = 0, ov_vv = 0, ov_tt = 0;           // cycles with vector+tensor / >=2 vector / >=2 tensor busy
  always @(posedge clk) if (rst_n) begin
    int nvb, ntb;
    nvb = 0; ntb = 0;
    for (int c = 0; c < NC; c++) begin
      for (int e = 0; e < PW; e++) if (c_perf_ev[c*PW + e]) pev_cnt[c][e] <= pev_cnt[c][e] + 1;
      if (c_busy[c]) begin if (c < NV) nvb++; else ntb++; end
    end
    if (nvb > 0 && ntb > 0) ov_vt <= ov_vt + 1;
    if (nvb > 1) ov_vv <= ov_vv + 1;
    if (ntb > 1) ov_tt <= ov_tt + 1;
  end

  // ============================================================ golden memory image
  logic [7:0] gold [STORE];
  bit         care [STORE];
  function automatic int st_idx(input logic [31:0] a);
    st_idx = -1;
    if (a >= SRAM_BASE && a < SRAM_BASE + 32'(SRAM_BYTES)) st_idx = int'(a - SRAM_BASE);
    for (int c = 0; c < NC; c++) begin
      logic [31:0] b;
      b = LM_BASE + 32'(dest_of(c)) * LM_STRIDE;
      if (a >= b && a < b + 32'(LM_BYTES)) st_idx = SRAM_BYTES + c * LM_BYTES + int'(a - b);
    end
  endfunction
  function automatic logic [7:0] g8(input logic [31:0] a); return gold[st_idx(a)]; endfunction
  function automatic logic [31:0] g32(input logic [31:0] a);
    return {gold[st_idx(a+3)], gold[st_idx(a+2)], gold[st_idx(a+1)], gold[st_idx(a)]};
  endfunction
  // builder writes: both the memory (inputs) and the golden image
  function automatic void put8(input logic [31:0] a, input logic [7:0] v);
    gold[st_idx(a)] = v; u_mem.store[st_idx(a)] = v;
  endfunction
  function automatic void put32(input logic [31:0] a, input logic [31:0] v);
    for (int b = 0; b < 4; b++) put8(a + 32'(b), v[8*b +: 8]);
  endfunction
  // expected outputs: golden image only
  function automatic void exp32(input logic [31:0] a, input logic [31:0] v);
    for (int b = 0; b < 4; b++) gold[st_idx(a + 32'(b))] = v[8*b +: 8];
  endfunction
  function automatic void dont_care(input logic [31:0] a, input int n);
    for (int i = 0; i < n; i++) if (st_idx(a + 32'(i)) >= 0) care[st_idx(a + 32'(i))] = 1'b0;
  endfunction
  // a command that must not touch its destination (validation error): expect the current contents
  function automatic void untouched(input logic [31:0] a, input int n);
    for (int i = 0; i < n; i++) if (st_idx(a + 32'(i)) >= 0) gold[st_idx(a + 32'(i))] = u_mem.store[st_idx(a + 32'(i))];
  endfunction

  // allocators: region 0 = shared SRAM, region c+1 = local memory of cluster c
  logic [31:0] ap [NC+1];
  logic [31:0] spm_ap [VA];
  int          stg [VA];
  function automatic logic [31:0] alloc(input int region, input int bytes);
    logic [31:0] r, lim;
    r   = (ap[region] + 32'd15) & ~32'd15;
    lim = (region == 0) ? SRAM_BASE + 32'(SRAM_BYTES - PRIV_BYTES) : LM_BASE + 32'(dest_of(region-1)) * LM_STRIDE + 32'(LM_BYTES);
    if (r + 32'(bytes) > lim) begin
      $display("FATAL: allocator region %0d exhausted", region); $finish;
    end
    ap[region] = r + 32'(bytes);
    return r;
  endfunction
  function automatic logic [31:0] spm_alloc(input int k, input int bytes);
    logic [31:0] r;
    r = (spm_ap[k] + 32'd15) & ~32'd15;
    if (r + 32'(bytes) > SPM_BASE + 32'(k) * SPM_STRIDE + 32'(SPM_BYTES)) begin
      r = SPM_BASE + 32'(k) * SPM_STRIDE + 32'h8000;     // wrap (FENCEd chains: earlier users are done)
    end
    spm_ap[k] = r + 32'(bytes);
    return r;
  endfunction

  // ============================================================ command table + scoreboard
  localparam int MAXC = 2048;
  localparam int K_OK = 0, K_ENGERR = 1, K_SHELL = 2, K_MAYABORT = 3;
  int          n_cmd = 0, n_rel = 0, n_iss = 0, n_cpl = 0;
  int          c_dest [MAXC], c_n [MAXC], c_kind [MAXC], c_code [MAXC], c_got [MAXC];
  logic [31:0] c_w [MAXC][16];
  logic [31:0] c_res [MAXC];
  bit          c_chkres [MAXC], c_odc [MAXC];
  logic [31:0] c_oa [MAXC];
  int          c_ol [MAXC];
  int          eq [16][MAXC];
  int          eq_h [16], eq_t [16];
  int          n_abort = 0, n_engerr = 0, n_shell = 0, n_ok = 0, n_reorder = 0;
  longint      t_first_cpl = 0, t_last_cpl = 0;
  int          last_src = -1;

  function automatic int new_cmd(input int dest, input int n, input int kind, input int code);
    int id;
    id = n_cmd; n_cmd++;
    if (n_cmd > MAXC) begin $display("FATAL: command table full"); $finish; end
    c_dest[id] = dest; c_n[id] = n; c_kind[id] = kind; c_code[id] = code; c_got[id] = -1;
    c_chkres[id] = 1'b0; c_odc[id] = 1'b0; c_oa[id] = '0; c_ol[id] = 0; c_res[id] = '0;
    for (int i = 0; i < 16; i++) c_w[id][i] = '0;
    return id;
  endfunction

  // ------------------------------------------------------------ vector command builders (HPC Module 08 ABI)
  function automatic logic [31:0] i2f(input int v);           // exact FP32 of a small integer (|v| < 2^24)
    logic [31:0] m; int e, s, a;
    if (v == 0) return 32'd0;
    s = (v < 0) ? 1 : 0; a = (v < 0) ? -v : v;
    e = 0; while ((a >> e) > 1) e++;
    m = 32'(a) << (23 - e);
    return {1'(s), 8'(127 + e), m[22:0]};
  endfunction
  function automatic logic [31:0] spm_of(input int k); return SPM_BASE + 32'(k) * SPM_STRIDE; endfunction

  // op: 'h10 IADD, 'h11 IMUL, 'h01 FADD, 'h03 FMUL, 'h04 FMADD;  red: sum-reduce into D[0] (+ record RESULT)
  function automatic int vkernel(input int k, input int op, input int vl, input int region, input bit red);
    int id; logic [31:0] A, B, C, D, stage, scalar, acc, w0;
    int s_bytes, s_int, acc_i; bit fp;
    id = new_cmd(k, 8, K_OK, 0);
    A = alloc(region, vl * 4); B = alloc(region, vl * 4); C = alloc(region, vl * 4);
    D = alloc(region, red ? 16 : vl * 4);
    s_bytes = ((vl * 4 + SB - 1) / SB) * SB;
    stage = spm_of(k) + 32'(stg[k] * 4096); stg[k] = (stg[k] + 1) % 8;
    s_int  = urange(-1000, 1000);
    fp     = (op != 'h10 && op != 'h11);
    scalar = !red ? 32'd0 : fp ? i2f(s_int) : 32'(s_int);
    acc    = scalar;
    acc_i  = s_int;
    for (int e = 0; e < vl; e++) begin
      int a, b, c, v; logic [31:0] r;
      a = urange(-100, 100); b = urange(-100, 100); c = urange(-1000, 1000);
      case (op)
        'h10: begin put32(A + 32'(4*e), rnd()); put32(B + 32'(4*e), rnd());
                    r = g32(A + 32'(4*e)) + g32(B + 32'(4*e)); end
        'h11: begin put32(A + 32'(4*e), rnd()); put32(B + 32'(4*e), rnd());
                    r = g32(A + 32'(4*e)) * g32(B + 32'(4*e)); end
        'h01: begin put32(A + 32'(4*e), i2f(a * 10)); put32(B + 32'(4*e), i2f(b * 10)); v = a * 10 + b * 10; r = i2f(v); end
        'h03: begin put32(A + 32'(4*e), i2f(a)); put32(B + 32'(4*e), i2f(b)); v = a * b; r = i2f(v);
                    if (v == 0 && ((a < 0) != (b < 0))) r = 32'h8000_0000; end      // IEEE: 0 x negative = -0
        default: begin put32(A + 32'(4*e), i2f(a)); put32(B + 32'(4*e), i2f(b)); put32(C + 32'(4*e), i2f(c));
                       v = a * b + c; r = i2f(v); end
      endcase
      if (red) begin acc = acc + r; acc_i = acc_i + v; end     // exact: |sum| < 2^24 for the FP operations
      else exp32(D + 32'(4*e), r);
    end
    if (red) begin
      if (fp) acc = i2f(acc_i);
      exp32(D, acc); c_chkres[id] = 1'b1; c_res[id] = acc;
    end
    w0 = 32'd3 | (32'(op) << 4) | (32'(red) << 15) | (32'(id & 8'hFF) << 16);
    c_w[id][0] = w0; c_w[id][1] = 32'(vl); c_w[id][2] = scalar; c_w[id][3] = A; c_w[id][4] = B;
    c_w[id][5] = C; c_w[id][6] = D; c_w[id][7] = stage;
    c_oa[id] = D; c_ol[id] = red ? 4 : vl * 4;
    if (s_bytes > 1024) $display("WARN vkernel vl too large for staging slot");
    return id;
  endfunction

  function automatic int vdma(input int k, input logic [31:0] src, input logic [31:0] dst, input int len, input bit fence);
    int id;
    id = new_cmd(k, 8, K_OK, 0);
    c_w[id][0] = 32'd1 | (32'(id & 8'hFF) << 16) | (32'(fence) << 24);
    c_w[id][1] = 32'(len); c_w[id][3] = src; c_w[id][4] = dst;
    c_oa[id] = dst; c_ol[id] = len;
    return id;
  endfunction

  // host -> host copy
  function automatic int vcopy(input int k, input int region, input int len);
    logic [31:0] S, D; int id;
    S = alloc(region, len); D = alloc(region, len);
    for (int i = 0; i < len; i++) gold[st_idx(D + 32'(i))] = gold[st_idx(S + 32'(i))];
    id = vdma(k, S, D, len, 1'b0);
    return id;
  endfunction

  // DMA host->scratchpad (A, B), VEC IADD on the scratchpad (FENCE), DMA scratchpad->host (FENCE): 4 commands
  function automatic int vchain(input int k, input int vl);
    logic [31:0] A, B, D, As, Bs, Ds; int id;
    A = alloc(0, vl * 4); B = alloc(0, vl * 4); D = alloc(0, vl * 4);
    As = spm_alloc(k, vl * 4); Bs = spm_alloc(k, vl * 4); Ds = spm_alloc(k, vl * 4);
    for (int e = 0; e < vl; e++) exp32(D + 32'(4*e), g32(A + 32'(4*e)) + g32(B + 32'(4*e)));
    id = vdma(k, A, As, vl * 4, 1'b1); c_oa[id] = '0; c_ol[id] = 0;
    id = vdma(k, B, Bs, vl * 4, 1'b0); c_oa[id] = '0; c_ol[id] = 0;
    id = new_cmd(k, 8, K_OK, 0);
    c_w[id][0] = 32'd2 | (32'h10 << 4) | (32'(id & 8'hFF) << 16) | (32'd1 << 24);
    c_w[id][1] = 32'(vl); c_w[id][3] = As; c_w[id][4] = Bs; c_w[id][6] = Ds;
    id = vdma(k, Ds, D, vl * 4, 1'b1);
    return id;
  endfunction

  function automatic int vnop(input int k);
    int id;
    id = new_cmd(k, 8, K_OK, 0);
    c_w[id][0] = 32'(id & 8'hFF) << 16;
    return id;
  endfunction

  // ------------------------------------------------------------ tensor command builder (TENSORCORE 08 ABI v2)
  function automatic int tgemm(input int k, input int m, input int n, input int kk, input int region);
    int id; logic [31:0] A, B, C;
    id = new_cmd(8 + k, 12, K_OK, 0);
    A = alloc(region, m * kk); B = alloc(region, kk * n); C = alloc(region, m * n * 4);
    for (int i = 0; i < m; i++)
      for (int j = 0; j < n; j++) begin
        int acc;
        acc = 0;
        for (int p = 0; p < kk; p++) acc += int'($signed(g8(A + 32'(i*kk + p)))) * int'($signed(g8(B + 32'(p*n + j))));
        exp32(C + 32'((i*n + j) * 4), 32'(acc));
      end
    c_w[id][0] = 32'h40 | (32'd2 << 8) | (32'(id & 8'hFF) << 24);
    c_w[id][1] = A; c_w[id][2] = B; c_w[id][3] = C;
    c_w[id][4] = 32'(m) | (32'(n) << 16); c_w[id][5] = 32'(kk);
    c_w[id][6] = 32'(kk); c_w[id][7] = 32'(n); c_w[id][8] = 32'(n * 4);
    c_oa[id] = C; c_ol[id] = m * n * 4;
    return id;
  endfunction

  // ------------------------------------------------------------ issuer: sends released commands in order
  // Clocked FSM: the handshake is evaluated on pre-edge values (always-block semantics are identical in
  // Icarus and Verilator; resumed @(posedge) coroutines are not).
  int iss_w = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      cmd_valid <= 1'b0; cmd_last <= 1'b0; iss_w = 0;
    end else begin
      bit hs, present;
      hs = cmd_valid && cmd_ready;
      if (hs) begin
        if (cmd_last) begin
          // expected completion order = acceptance order per destination
          eq[c_dest[n_iss]][eq_t[c_dest[n_iss]]] = n_iss; eq_t[c_dest[n_iss]]++;
          n_iss = n_iss + 1; iss_w = 0;
        end else begin
          iss_w = iss_w + 1;
        end
      end
      present = (n_iss < n_rel);
      if (cmd_gap > 0) begin
        if ((rnds(1) % 100) < cmd_gap) present = 1'b0;
      end
      if (cmd_valid && !hs) present = 1'b1;                    // a held word stays (stream rule S1)
      if (present) begin
        cmd_valid <= 1'b1;
        cmd_data  <= c_w[n_iss][iss_w % 16];
        cmd_last  <= (iss_w == c_n[n_iss] - 1);
        cmd_tag   <= TAGW'(n_iss);
        cmd_dest  <= 4'(c_dest[n_iss]);
      end else begin
        cmd_valid <= 1'b0; cmd_last <= 1'b0;
      end
    end
  end

  // ------------------------------------------------------------ completion receiver + checks
  logic [31:0] pk_w [8];
  int          pk_n = 0;
  logic [3:0]  pk_src;
  logic [TAGW-1:0] pk_tag;
  logic        pk_err;
  always @(posedge clk) begin
    if (!rst_n) cpl_ready <= 1'b0;
    else if (cpl_stall > 0) cpl_ready <= ((rnds(2) % 100) >= cpl_stall);
    else        cpl_ready <= 1'b1;
  end
  always @(posedge clk) if (rst_n && cpl_valid && cpl_ready) begin
    if (pk_n == 0) begin pk_src = cpl_src; pk_tag = cpl_tag; pk_err = cpl_err; end
    else if (cpl_src != pk_src || cpl_tag != pk_tag || cpl_err != pk_err) `ERR(("completion sidebands changed inside a packet"))
    if (pk_n < 8) pk_w[pk_n] = cpl_data;
    pk_n++;
    if (cpl_last) begin
      if (pk_n != `SFX_CL_CPL_WORDS) `ERR(("completion packet of %0d words", pk_n))
      else check_cpl();
      pk_n = 0;
    end
  end

  task automatic check_cpl();
    int src;
    src = int'(pk_src);
    if (eq_h[src] == eq_t[src]) `ERR(("unexpected completion from src %0d tag %0d", src, pk_tag))
    else begin
      check_rec(src, eq[src][eq_h[src]]);
      eq_h[src]++;
    end
  endtask

  task automatic check_rec(input int src, input int id);
    int st, eng_exp, ok_eng;
    logic [31:0] h, r0;
    bit e, eng_err;
    h = pk_w[0];
    n_cpl++;
    if (n_cpl == 1) t_first_cpl = cyc;
    t_last_cpl = cyc;
    if (last_src >= 0 && src != last_src) n_reorder++;
    last_src = src;
    st = int'(h[3:0]); e = h[4];
    c_got[id] = st;
    if (pk_tag != TAGW'(id)) `ERR(("cmd %0d: completion tag %0d", id, pk_tag))
    if (h[31:24] != `SFX_CL_ABI_VERSION || h[15:12] != 4'd6) `ERR(("cmd %0d: bad header %h", id, h))
    if (h[23:16] != 8'(src)) `ERR(("cmd %0d: header cluster %0d != src %0d", id, h[23:16], src))
    eng_exp = (src < 8) ? 1 : 2;
    if (st == `SFX_CL_ST_BAD_DEST) eng_exp = 0;
    if (int'(h[11:8]) != eng_exp) `ERR(("cmd %0d: header engine %0d", id, h[11:8]))
    if (e != pk_err) `ERR(("cmd %0d: cpl_err sideband %0d != header %0d", id, pk_err, e))
    // engine record
    r0 = pk_w[1];
    if (src < 8) begin
      eng_err = (r0[11:8] != 4'd0);
      ok_eng  = (st == `SFX_CL_ST_ENGINE) && (r0[31] == 1'b1) && (r0[7:0] == 8'(id & 8'hFF));
    end else begin
      eng_err = (r0[25:24] != 2'd0);
      ok_eng  = (st == `SFX_CL_ST_ENGINE) && (r0[7:0] == 8'(id & 8'hFF));
    end
    if (st != `SFX_CL_ST_ENGINE) begin
      for (int i = 1; i < 7; i++) if (pk_w[i] != 0) `ERR(("cmd %0d: shell record word %0d not zero", id, i))
      if (!e) `ERR(("cmd %0d: shell record without error summary", id))
    end else if (e != eng_err) `ERR(("cmd %0d: error summary %0d but engine status says %0d", id, e, eng_err))
    case (c_kind[id])
      K_OK: begin
        if (!(ok_eng && !e)) `ERR(("cmd %0d (dest %0d): expected OK, got CL_STATUS %0d err %0d rec %h", id, src, st, e, r0))
        else n_ok++;
        if (c_chkres[id] && pk_w[4] != c_res[id]) `ERR(("cmd %0d: reduction result %h, expected %h", id, pk_w[4], c_res[id]))
      end
      K_ENGERR: begin
        int code;
        code = (src < 8) ? int'(r0[11:8]) : int'(r0[23:16]);
        if (!(st == `SFX_CL_ST_ENGINE && e && code == c_code[id]))
          `ERR(("cmd %0d (dest %0d): expected engine error %h, got CL_STATUS %0d rec %h", id, src, c_code[id], st, r0))
        else n_engerr++;
        if (c_odc[id]) dont_care(c_oa[id], c_ol[id]);
      end
      K_SHELL: begin
        if (st != c_code[id]) `ERR(("cmd %0d (dest %0d): expected shell status %0d, got %0d", id, src, c_code[id], st))
        else n_shell++;
      end
      default: begin   // K_MAYABORT
        if (st == `SFX_CL_ST_RESET_ABORT) begin n_abort++; dont_care(c_oa[id], c_ol[id]); end
        else if (!(ok_eng && !e)) `ERR(("cmd %0d (dest %0d): expected OK or RESET_ABORT, got %0d rec %h", id, src, st, r0))
        else n_ok++;
      end
    endcase
    if (st == `SFX_CL_ST_RESET_ABORT && c_kind[id] != K_MAYABORT) `ERR(("cmd %0d: unexpected RESET_ABORT", id))
  endtask

  // ------------------------------------------------------------ CSR access (rb contract: response in the strobe cycle)
  task automatic csr(input bit we, input int slot, input logic [12:0] a, input logic [31:0] d,
                     output logic [31:0] q, output bit e);
    // drive after the falling edge, sample the combinational answer before the rising edge (the strobe cycle)
    @(negedge clk);
    csr_sel = 1'b1; csr_we = we; csr_addr = {4'(slot), a}; csr_wdata = d;
    #2;
    q = csr_rdata; e = csr_err;
    @(negedge clk);
    csr_sel = 1'b0; csr_we = 1'b0;
  endtask
  task automatic csr_wr(input int slot, input logic [12:0] a, input logic [31:0] d, input bit exp_err);
    logic [31:0] q; bit e;
    csr(1'b1, slot, a, d, q, e);
    if (e != exp_err) `ERR(("CSR write slot %0d addr %h: rb_err %0d, expected %0d", slot, a, e, exp_err))
  endtask
  task automatic csr_rd(input int slot, input logic [12:0] a, output logic [31:0] q);
    bit e;
    csr(1'b0, slot, a, 32'd0, q, e);
    if (e) `ERR(("CSR read slot %0d addr %h refused", slot, a))
  endtask

  // ------------------------------------------------------------ tb host master: directed list or random traffic
  int          hq_n = 0, hq_i = 0;
  bit          hq_we [64];
  logic [31:0] hq_a [64];
  logic [XW-1:0] hq_d [64], hq_rd [64];
  bit          hq_err [64];
  int          h_rd_checks = 0, h_ops = 0;
  logic        h_busy = 1'b0, h_dir = 1'b0;
  logic [31:0] h_exp_q;
  bit          h_chk_q;
  always @(posedge clk) begin
    if (!rst_n) begin
      h_v_q <= 1'b0; h_busy <= 1'b0;
    end else begin
      if (h_v_q && h_req_ready) h_v_q <= 1'b0;
      if (h_rsp_valid && !h_rsp_hold) begin
        h_busy <= 1'b0; h_ops <= h_ops + 1;
        if (h_dir) begin
          hq_rd[hq_i] = h_rsp_rdata; hq_err[hq_i] = h_rsp_error; hq_i = hq_i + 1;
        end else if (h_chk_q) begin
          h_rd_checks <= h_rd_checks + 1;
          if (h_rsp_error || h_rsp_rdata[31:0] != h_exp_q) `ERR(("host random read %h: %h, expected %h", h_req_addr, h_rsp_rdata[31:0], h_exp_q))
        end
      end
      if (!h_busy && !h_v_q && !(h_rsp_valid && !h_rsp_hold)) begin
        if (hq_i < hq_n) begin
          h_dir <= 1'b1; h_v_q <= 1'b1; h_busy <= 1'b1;
          h_req_write <= hq_we[hq_i]; h_req_addr <= hq_a[hq_i]; h_req_wdata <= hq_d[hq_i];
          h_req_wstrb <= hq_we[hq_i] ? {SB{1'b1}} : '0;
        end else if (host_pct > 0 && (rnds(3) % 100) < host_pct) begin
          logic [31:0] a; bit w;
          a = SRAM_BASE + 32'(SRAM_BYTES - PRIV_BYTES) + ((rnds(3) % 32'(PRIV_BYTES)) & ~32'(SB - 1));
          w = rnds(3) % 2;
          h_dir <= 1'b0; h_v_q <= 1'b1; h_busy <= 1'b1; h_req_write <= w; h_req_addr <= a;
          h_req_wstrb <= w ? {SB{1'b1}} : '0;
          if (w) begin
            logic [XW-1:0] d;
            for (int b = 0; b < SB; b += 4) d[8*b +: 32] = rnds(3);
            h_req_wdata <= d;
            for (int b = 0; b < SB; b++) gold[st_idx(a + 32'(b))] = d[8*b +: 8];
            h_chk_q <= 1'b0;
          end else begin
            h_chk_q <= 1'b1; h_exp_q <= g32(a);
          end
        end
      end
    end
  end
  task automatic host_run();
    do @(negedge clk); while (!(hq_i == hq_n && !h_busy && !h_v_q));
  endtask

  // ------------------------------------------------------------ helpers
  // initial-block code samples and publishes state at the falling edge: always blocks act at the rising edge, so
  // every simulator sees the same values (no rising-edge ordering race)
  task automatic release_all(); @(negedge clk); n_rel = n_cmd; endtask
  task automatic wait_done(input longint limit);
    longint t0;
    t0 = cyc;
    do @(negedge clk); while ((n_iss < n_rel || n_cpl < n_rel) && (cyc - t0) < limit);
    if (n_cpl < n_rel) `ERR(("timeout: %0d of %0d completions after %0d cycles", n_cpl, n_rel, cyc - t0))
  endtask
  task automatic idle(input int n); repeat (n) @(negedge clk); endtask
  function automatic int err_bits(input int c); return int'(c_err_status[c*EW +: EW]); endfunction
  function automatic bit err_bit(input int c, input int b); return c_err_status[c*EW + b]; endfunction

  // ============================================================ tests
  task automatic t_smoke();
    for (int c = 0; c < NC; c++) begin
      if (c < NV) void'(vkernel(c, 'h10, 16, 0, 1'b0));
      else        void'(tgemm(c - NV, 4, 4, 4, 0));
    end
    release_all(); wait_done(200000);
  endtask

  task automatic t_single_vec();
    void'(vnop(0));
    void'(vkernel(0, 'h10, 16, 0, 0)); void'(vkernel(0, 'h11, 33, 0, 0)); void'(vkernel(0, 'h01, 64, 0, 0));
    void'(vkernel(0, 'h03, 7, 0, 0));  void'(vkernel(0, 'h04, 100, 0, 0)); void'(vkernel(0, 'h10, 1, 0, 0));
    void'(vkernel(0, 'h01, 48, 0, 1)); void'(vkernel(0, 'h04, 20, 0, 1));   // FP reductions (Module 03 rule)
    void'(vcopy(0, 0, 4)); void'(vcopy(0, 0, 257)); void'(vcopy(0, 0, 1000));
    void'(vchain(0, 32)); void'(vchain(0, 5));
    void'(vnop(0));
    release_all(); wait_done(400000);
  endtask

  task automatic t_single_ten();
    int k;
    k = 0;
    void'(tgemm(k, 4, 4, 4, 0)); void'(tgemm(k, 8, 8, 16, 0)); void'(tgemm(k, 1, 1, 1, 0));
    void'(tgemm(k, 17, 13, 29, 0)); void'(tgemm(k, 32, 32, 64, 0)); void'(tgemm(k, 5, 9, 130, 0));
    release_all(); wait_done(1000000);
  endtask

  task automatic batch(input int nper, input int region_sel);
    // round-robin over clusters so the engines run simultaneously
    for (int r = 0; r < nper; r++)
      for (int c = 0; c < NC; c++) begin
        int region;
        region = (region_sel == 1) ? c + 1 : (region_sel == 2 && (r % 2 == 1)) ? c + 1 : 0;
        if (c < NV) begin
          case (urange(0, 5))
            0: void'(vkernel(c, 'h10, urange(1, 128), region, 0));
            1: void'(vkernel(c, 'h04, urange(1, 64), region, 0));
            2: void'(vkernel(c, 'h03, urange(1, 64), region, urange(0, 1)));
            3: void'(vcopy(c, region, urange(1, 600)));
            4: void'(vkernel(c, 'h11, urange(1, 96), region, 0));
            default: void'(vkernel(c, 'h01, urange(1, 96), region, 0));
          endcase
        end else begin
          void'(tgemm(c - NV, urange(1, 12), urange(1, 12), urange(1, 48), region));
        end
      end
  endtask

  task automatic t_multi();
    batch(6, 0);
    if (NV > 0) void'(vchain(0, 24));
    release_all(); wait_done(2000000);
  endtask

  task automatic t_contention();
    host_pct = 40;
    batch(5, 0);
    release_all(); wait_done(3000000);
    host_pct = 0;
    host_run();
  endtask

  task automatic t_routing();
    // short commands everywhere plus shell errors, interleaved; completions are checked for src/tag/order
    for (int r = 0; r < 8; r++) begin
      for (int c = 0; c < NC; c++) begin
        if (c < NV) begin void'(vnop(c)); void'(vkernel(c, 'h10, urange(1, 8), 0, 0)); end
        else        void'(tgemm(c - NV, urange(1, 4), urange(1, 4), urange(1, 4), 0));
      end
      // absent destinations: answered by the shell (BAD_DEST), never dropped
      begin int id; id = new_cmd((NV < 8) ? 7 : 15, 3, K_SHELL, `SFX_CL_ST_BAD_DEST); c_w[id][0] = 32'hDEAD_0000; end
      begin int id; id = new_cmd(12 + (r % 4), 1, K_SHELL, `SFX_CL_ST_BAD_DEST); end
      // wrong packet lengths: answered by the cluster (BAD_LENGTH), engine untouched
      if (NV > 0) begin int id; id = new_cmd(0, urange(1, 7), K_SHELL, `SFX_CL_ST_BAD_LENGTH); end
      if (NT > 0) begin int id; id = new_cmd(8, urange(13, 15), K_SHELL, `SFX_CL_ST_BAD_LENGTH); end
    end
    release_all(); wait_done(1000000);
  endtask

  task automatic t_reset();
    int v_before, t_before;
    logic [31:0] q;
    // long work on the clusters that will be reset, ordinary work everywhere else
    for (int c = 0; c < NC; c++) begin
      if (c < NV) for (int i = 0; i < 6; i++) begin int id; id = vkernel(c, 'h04, 200, 0, 0); if (c == 0) c_kind[id] = K_MAYABORT; end
      else        for (int i = 0; i < 3; i++) begin int id; id = tgemm(c - NV, 24, 24, 96, 0); if (c == NV) c_kind[id] = K_MAYABORT; end
    end
    release_all();
    // scratchpad-port traffic into vector 0 while it is reset
    if (NV > 0) begin
      @(negedge clk);
      hq_n = 0; hq_i = 0;
      for (int i = 0; i < 48; i++) begin
        hq_we[hq_n] = (i < 24); hq_a[hq_n] = spm_of(0) + 32'h0C000 + 32'(SB * (i % 24)); hq_d[hq_n] = XW'(i * 3 + 1); hq_n++;
      end
    end
    idle(3000);
    if (NT > 0) begin ten_rst_req[0] = 1'b1; idle(5); ten_rst_req[0] = 1'b0; end      // pin request (level, short)
    if (NV > 0) csr_wr(0, 13'h1000 | 13'(`SFX_CL_R_CTRL), 32'h3, 1'b0);              // CSR CL_CTRL.RESET (keeps STREAM_EN)
    wait_done(4000000);
    host_run();
    // every directed access was answered (data or error), none lost
    if (NV > 0 && hq_i != hq_n) `ERR(("scratchpad accesses answered %0d of %0d", hq_i, hq_n))
    // the reset clusters work again
    v_before = n_cmd;
    for (int c = 0; c < NC; c++) begin
      if (c < NV) void'(vkernel(c, 'h10, 40, 0, 0));
      else        void'(tgemm(c - NV, 8, 8, 8, 0));
    end
    release_all(); wait_done(1000000);
    if (NT > 0) begin
      csr_rd(8, 13'h1000 | 13'(`SFX_CL_R_RESETS), q); if (q != 32'd1) `ERR(("tensor 0 RESETS = %0d", q))
      if (!err_bit(NV, `SFX_CL_E_RESET_ABORT) && pev_cnt[NV][`SFX_CL_PEV_RESET] == 0) `ERR(("tensor 0 reset not observed"))
    end
    if (NV > 0) begin
      csr_rd(0, 13'h1000 | 13'(`SFX_CL_R_RESETS), q); if (q != 32'd1) `ERR(("vector 0 RESETS = %0d", q))
    end
    if (n_abort == 0) `ERR(("no command was destroyed by the resets (test did not hit running work)"))
    // a reset on a healthy NoC must drain normally: never forced
    if (NV > 0 && err_bit(0, `SFX_CL_E_DRAIN_TIMEOUT))  `ERR(("vector 0: reset forced (DRAIN_TIMEOUT) on a healthy NoC"))
    if (NT > 0 && err_bit(NV, `SFX_CL_E_DRAIN_TIMEOUT)) `ERR(("tensor 0: reset forced (DRAIN_TIMEOUT) on a healthy NoC"))
    t_before = 0;
  endtask

  task automatic t_reset_drain();
    logic [31:0] q;
    int c;
    // freeze the NoC responses of one cluster while it works, reset it, observe the forced drain
    c = (NT > 0) ? NV : 0;
    if (c >= NV) begin int id; id = tgemm(c - NV, 16, 16, 64, 0); c_kind[id] = K_MAYABORT; end
    else         begin int id; id = vkernel(c, 'h04, 200, 0, 0); c_kind[id] = K_MAYABORT; end
    release_all();
    do @(negedge clk); while (pn_req[c] < 20);
    freeze[c] = 1'b1;
    idle(50);
    if (c >= NV) begin ten_rst_req[0] = 1'b1; idle(3); ten_rst_req[0] = 1'b0; end
    else         begin vec_rst_req[0] = 1'b1; idle(3); vec_rst_req[0] = 1'b0; end
    // the drain times out (2^DRAIN cycles), the reset is forced while responses are still frozen
    idle((1 << DRAIN) + 200);
    csr_rd(dest_of(c), 13'h1000 | 13'(`SFX_CL_R_STATUS), q);
    if (!q[`SFX_CL_SB_DRAINING]) `ERR(("cluster %0d: not draining after the forced reset (status %h)", c, q))
    if (!err_bit(c, `SFX_CL_E_DRAIN_TIMEOUT)) `ERR(("cluster %0d: DRAIN_TIMEOUT not reported", c))
    freeze[c] = 1'b0;                                    // the late responses arrive and are dropped
    wait_done(500000);
    // the cluster works again afterwards
    if (c >= NV) void'(tgemm(c - NV, 8, 8, 16, 0)); else void'(vkernel(c, 'h10, 32, 0, 0));
    release_all(); wait_done(500000);
    csr_rd(dest_of(c), 13'h1000 | 13'(`SFX_CL_R_STATUS), q);
    if (q[`SFX_CL_SB_DRAINING]) `ERR(("cluster %0d: still draining", c))
    // phase 2: a scratchpad-window response held by a stalled master when vector 0's reset is forced.
    // It must reach the master unchanged (SFB2 R4) and as data, not as an error.
    if (NV > 0) begin
      @(negedge clk);
      hq_n = 0; hq_i = 0;
      hq_we[0] = 1'b1; hq_a[0] = spm_of(0) + 32'h0C040; hq_d[0] = XW'(32'h5AC3_0F96); hq_n = 1;
      host_run();
      h_rsp_hold = 1'b1;
      hq_we[1] = 1'b0; hq_a[1] = spm_of(0) + 32'h0C040; hq_d[1] = '0; hq_n = 2;
      do @(negedge clk); while (!sp_rsp_valid[0]);
      idle(20);
      vec_rst_req[0] = 1'b1; idle(3); vec_rst_req[0] = 1'b0;
      idle((1 << DRAIN) + 200);
      if (!err_bit(0, `SFX_CL_E_DRAIN_TIMEOUT)) `ERR(("vector 0: DRAIN_TIMEOUT not reported with a held scratchpad response"))
      h_rsp_hold = 1'b0;
      host_run();
      if (hq_err[1] || hq_rd[1][31:0] != 32'h5AC3_0F96)
        `ERR(("held scratchpad response delivered as error %0d data %h", hq_err[1], hq_rd[1][31:0]))
      void'(vkernel(0, 'h10, 16, 0, 0));
      release_all(); wait_done(200000);
    end
  endtask

  task automatic t_errors();
    logic [31:0] q;
    // engine validation / execution errors -> error completions + sticky CL_ERR + err / irq outputs
    if (NV > 0) begin
      int id;
      id = new_cmd(0, 8, K_ENGERR, 1); c_w[id][0] = 32'd7 | (32'(id & 8'hFF) << 16);            // BAD_TYPE
      id = vkernel(0, 'h10, 16, 0, 0); c_kind[id] = K_ENGERR; c_code[id] = 8; c_odc[id] = 1'b1;  // DMA_ERR: A unmapped
      c_w[id][3] = BAD_ADDR;
      id = vkernel(0, 'h10, 16, 0, 1); c_kind[id] = K_ENGERR; c_code[id] = 3;                   // BAD_OP: integer reduction
      c_chkres[id] = 1'b0; untouched(c_oa[id], c_ol[id]);
      void'(vkernel(0, 'h10, 16, 0, 0));                                                        // independent: still OK
      csr_wr(0, 13'h1000 | 13'(`SFX_CL_R_ERR_EN), 32'h1, 1'b0);                                 // irq on CPL_ERR
    end
    if (NT > 0) begin
      int id;
      id = tgemm(0, 4, 4, 4, 0); c_kind[id] = K_ENGERR; c_code[id] = 'h01; c_w[id][0][11:8] = 4'd3;    // VERSION
      untouched(c_oa[id], c_ol[id]);                                                                   // C untouched
      id = tgemm(0, 4, 4, 4, 0); c_kind[id] = K_ENGERR; c_code[id] = 'h18; c_odc[id] = 1'b1;           // DMA_READ
      c_w[id][1] = BAD_ADDR;
      void'(tgemm(0, 4, 4, 4, 0));
    end
    release_all(); wait_done(400000);
    idle(4);
    for (int c = 0; c < NC; c++) begin
      bit hit;
      hit = (c == 0 && NV > 0) || (c == NV && NT > 0);           // vector 0 and tensor 0 got the error commands
      if (hit) begin
        if (!c_err[c]) `ERR(("cluster %0d: err output low after error completions", c))
        if (!err_bit(c, `SFX_CL_E_CPL_ERR)) `ERR(("cluster %0d: CPL_ERR not set", c))
        if (!err_bit(c, `SFX_CL_E_MEM_ERR)) `ERR(("cluster %0d: MEM_ERR not set after a bus error", c))
      end else if (c_err[c] || err_bits(c) != 0) begin
        `ERR(("cluster %0d: error status %h although it received no erroneous command", c, err_bits(c)))
      end
    end
    if (!err_any) `ERR(("err_any low"))
    if (NV > 0 && !c_irq[0]) `ERR(("vector 0 irq low with CPL_ERR enabled"))
    // ownership rule: the adapter owns submission while streaming
    if (NV > 0) begin
      csr_wr(0, 13'h0A0, 32'h1, 1'b1);                // DOORBELL refused
      csr_wr(0, 13'h080, 32'h1, 1'b1);                // CMD0 refused
      csr_wr(0, 13'h020, 32'h1, 1'b1);                // SOFT_RESET refused (would destroy records)
      csr_wr(0, 13'h020, 32'h8, 1'b0);                // PERF_CLEAR allowed
      idle(2);
      if (!err_bit(0, `SFX_CL_E_CSR_DENIED)) `ERR(("CSR_DENIED not set"))
      // W1C clear, err drops
      csr_wr(0, 13'h1000 | 13'(`SFX_CL_R_ERR), 32'hFF, 1'b0);
      idle(3);
      if (c_err[0] || err_bits(0) != 0) `ERR(("vector 0 errors not cleared: %h", err_bits(0)))
      if (c_irq[0]) `ERR(("vector 0 irq still high"))
    end
    if (NT > 0) begin
      csr_wr(8, 13'h070, 32'h1, 1'b1);                // TSU DOORBELL refused
      csr_wr(8, 13'h098, 32'h1, 1'b1);                // TSU CPL_POP refused
    end
    // after all of this, the clusters still work
    for (int c = 0; c < NC; c++) if (c < NV) void'(vkernel(c, 'h10, 8, 0, 0)); else void'(tgemm(c - NV, 3, 3, 3, 0));
    release_all(); wait_done(200000);
  endtask

  task automatic t_csr();
    logic [31:0] q; bit e;
    for (int c = 0; c < NC; c++) begin
      int s;
      s = dest_of(c);
      csr_rd(s, 13'h1000 | 13'(`SFX_CL_R_ID), q);   if (q != `SFX_CL_ID_VALUE) `ERR(("slot %0d CL_ID %h", s, q))
      csr_rd(s, 13'h1000 | 13'(`SFX_CL_R_INFO), q);
      if (q[7:0] != 8'(s) || q[11:8] != ((c < NV) ? 4'd1 : 4'd2) || q[31:24] != 8'(XW / 8) || q[16] != 1'(LM))
        `ERR(("slot %0d CL_INFO %h", s, q))
      csr_rd(s, 13'h000, q);
      if (q != ((c < NV) ? 32'h5346_4854 : 32'h5346_5443)) `ERR(("slot %0d engine ID %h", s, q))
    end
    csr(1'b0, 7, 13'h1000, 32'd0, q, e);            if (NV < 8 && !e) `ERR(("absent slot 7 not refused"))
    csr(1'b0, 15, 13'h000, 32'd0, q, e);            if (!e) `ERR(("absent slot 15 not refused"))
    csr(1'b0, 0, 13'h1FFC, 32'd0, q, e);            if (NV > 0 && !e) `ERR(("unmapped cluster register not refused"))
    // legacy (CSR) submission path = minimum-chip compatibility: host drives the engine pages directly
    if (NV > 0) begin
      int id; logic [31:0] w [16];
      csr_wr(0, 13'h1000 | 13'(`SFX_CL_R_CTRL), 32'h0, 1'b0);                  // STREAM_EN = 0
      id = vkernel(0, 'h10, 24, 0, 0);
      n_cmd--;                                                                   // not streamed: host submits it
      for (int i = 0; i < 8; i++) csr_wr(0, 13'h080 + 13'(4 * i), c_w[id][i], 1'b0);
      csr_wr(0, 13'h0A0, 32'h1, 1'b0);
      do begin csr_rd(0, 13'h028, q); end while (!q[5]);
      csr_rd(0, 13'h040, q); if (q[11:8] != 0 || q[7:0] != 8'(id)) `ERR(("legacy vector record %h", q))
      csr_wr(0, 13'h058, 32'h1, 1'b0);
      // a streamed command while STREAM_EN = 0 is answered STREAM_OFF
      begin int j; j = vnop(0); c_kind[j] = K_SHELL; c_code[j] = `SFX_CL_ST_STREAM_OFF; end
      release_all(); wait_done(100000);
      csr_wr(0, 13'h1000 | 13'(`SFX_CL_R_CTRL), 32'h1, 1'b0);                  // STREAM_EN = 1 (idle: allowed)
    end
    if (NT > 0) begin
      int id;
      csr_wr(8, 13'h1000 | 13'(`SFX_CL_R_CTRL), 32'h0, 1'b0);
      id = tgemm(0, 6, 5, 7, 0);
      n_cmd--;
      for (int i = 0; i < 12; i++) csr_wr(8, 13'h040 + 13'(4 * i), c_w[id][i], 1'b0);
      csr_wr(8, 13'h070, 32'h1, 1'b0);
      do begin csr_rd(8, 13'h01C, q); end while (!q[4]);
      csr_rd(8, 13'h080, q); if (q[25:24] != 0 || q[7:0] != 8'(id)) `ERR(("legacy tensor record %h", q))
      csr_wr(8, 13'h098, 32'h1, 1'b0);
      csr_wr(8, 13'h1000 | 13'(`SFX_CL_R_CTRL), 32'h1, 1'b0);
    end
    // STREAM_EN cannot change while the adapter is busy
    if (NT > 0) begin
      int id;
      id = tgemm(0, 16, 16, 64, 0);
      release_all();
      do @(negedge clk); while (n_iss < n_rel);
      idle(20);
      csr_wr(8, 13'h1000 | 13'(`SFX_CL_R_CTRL), 32'h0, 1'b1);
      wait_done(200000);
    end
    // streamed commands after all CSR activity
    for (int c = 0; c < NC; c++) if (c < NV) void'(vkernel(c, 'h11, 12, 0, 0)); else void'(tgemm(c - NV, 4, 4, 8, 0));
    release_all(); wait_done(200000);
  endtask

  task automatic t_localmem();
    // operands and results in the cluster's local memory, mixed with shared-SRAM commands (target switching)
    batch(4, 2);
    for (int c = 0; c < NC; c++) if (c < NV) void'(vkernel(c, 'h10, 64, c + 1, 0)); else void'(tgemm(c - NV, 8, 8, 32, c + 1));
    release_all(); wait_done(2000000);
    for (int c = 0; c < NC; c++)
      if (pev_cnt[c][`SFX_CL_PEV_LM_REQ] == 0) `ERR(("cluster %0d: no local-memory request", c))
  endtask

  // round trip of single commands, issued one at a time on an idle subsystem (first command word accepted ->
  // last completion word delivered).  Used by docs/04_TIMING.md to state the latency the shell adds.
  longint lat_first [MAXC];
  always @(posedge clk) if (rst_n && cmd_valid && cmd_ready && iss_w == 0) lat_first[n_iss] <= cyc;
  task automatic one(input int id, input string what);
    longint t0;
    release_all();
    wait_done(100000);
    idle(30);
    $display("STAT latency %s %0d", what, t_last_cpl - lat_first[id]);
  endtask
  task automatic t_latency();
    if (NV > 0) begin
      one(vnop(0), "vector_nop");
      one(vcopy(0, 0, 4), "vector_dma4");
      one(vkernel(0, 'h10, 1, 0, 0), "vector_kernel1");
    end
    if (NT > 0) begin
      int id;
      id = new_cmd(8, 12, K_OK, 0); c_w[id][0] = 32'h0000_0200 | (32'(id & 8'hFF) << 24);
      one(id, "tensor_nop");
      one(tgemm(0, 1, 1, 1, 0), "tensor_gemm1");
      one(tgemm(0, 4, 4, 4, 0), "tensor_gemm4");
    end
  endtask

  // ============================================================ main
  initial begin
    void'($value$plusargs("TEST=%s", test));
    void'($value$plusargs("SEED=%d", seed));
    void'($value$plusargs("LAT=%d", mem_lat));
    void'($value$plusargs("JIT=%d", mem_jit));
    void'($value$plusargs("MSTALL=%d", mem_stall));
    void'($value$plusargs("TREQ=%d", thr_req));
    void'($value$plusargs("TRSP=%d", thr_rsp));
    void'($value$plusargs("CPLSTALL=%d", cpl_stall));
    void'($value$plusargs("CMDGAP=%d", cmd_gap));
    void'($value$plusargs("MAXCYC=%d", max_cyc));
    if (test == "backpressure") begin
      if (mem_stall == 0) mem_stall = 25; if (thr_req == 0) thr_req = 30; if (thr_rsp == 0) thr_rsp = 30;
      if (cpl_stall == 0) cpl_stall = 40; if (cmd_gap == 0) cmd_gap = 30; if (mem_jit == 0) mem_jit = 3;
    end
    if (test == "contention" && mem_lat == 1) begin mem_lat = 2; mem_jit = 2; end
    if (test == "reset" && mem_lat == 1) begin mem_lat = 3; mem_jit = 2; end      // responses slower than issue
    for (int k = 0; k < 4; k++) begin
      rss[k] = 32'(seed) * 32'h2545_F491 + 32'd7 + 32'(k) * 32'h9E37_79B9; if (rss[k] == 0) rss[k] = 1;
    end
    for (int r = 0; r <= NC; r++) ap[r] = (r == 0) ? SRAM_BASE : LM_BASE + 32'(dest_of(r - 1)) * LM_STRIDE;
    for (int k = 0; k < VA; k++) begin spm_ap[k] = SPM_BASE + 32'(k) * SPM_STRIDE + 32'h8000; stg[k] = 0; end
    for (int d = 0; d < 16; d++) begin eq_h[d] = 0; eq_t[d] = 0; end
    for (int c = 0; c < NC; c++) for (int e = 0; e < PW; e++) pev_cnt[c][e] = 0;
    for (int i = 0; i < STORE; i++) begin
      logic [7:0] b;
      b = 8'(rnd());
      u_mem.store[i] = b; gold[i] = b; care[i] = 1'b1;
    end
    $display("TB config NV=%0d NT=%0d XW=%0d LM=%0d MSLC=%0d CSLC=%0d TDIM=%0d VLANES=%0d GATE=%0d test=%s seed=%0d",
             NV, NT, XW, LM, MSLC, CSLC, TDIM, VLANES, GATE, test, seed);
    repeat (5) @(posedge clk);
    rst_n <= 1'b1;
    repeat (10) @(posedge clk);
    if      (test == "smoke")        t_smoke();
    else if (test == "single_vec")   t_single_vec();
    else if (test == "single_ten")   t_single_ten();
    else if (test == "multi")        t_multi();
    else if (test == "mixed")        t_multi();
    else if (test == "contention")   t_contention();
    else if (test == "backpressure") t_multi();
    else if (test == "routing")      t_routing();
    else if (test == "reset")        t_reset();
    else if (test == "reset_drain")  t_reset_drain();
    else if (test == "errors")       t_errors();
    else if (test == "csr")          t_csr();
    else if (test == "clkgate")      begin t_smoke(); idle(200); t_smoke(); end
    else if (test == "localmem")     t_localmem();
    else if (test == "latency")      t_latency();
    else `ERR(("unknown test %s", test))
    idle(50);
    finish_checks();
  end

  task automatic finish_checks();
    int mism, pv;
    // every built command completed exactly once
    for (int id = 0; id < n_cmd; id++) if (c_got[id] < 0) `ERR(("cmd %0d (dest %0d) never completed", id, c_dest[id]))
    for (int d = 0; d < 16; d++) if (eq_h[d] != eq_t[d]) `ERR(("dest %0d: %0d completions missing", d, eq_t[d] - eq_h[d]))
    // whole memory image
    mism = 0;
    for (int i = 0; i < STORE; i++) if (care[i] && u_mem.store[i] !== gold[i]) begin
      mism++;
      if (mism <= 10) `ERR(("memory byte %0d (addr %h): %h, expected %h", i,
                            (i < SRAM_BYTES) ? SRAM_BASE + 32'(i) : 32'hFFFF_FFFF, u_mem.store[i], gold[i]))
    end
    if (mism > 0) `ERR(("%0d memory bytes differ", mism))
    // protocol
    pv = int'(pv_host) + sv_cmd + sv_cpl;
    for (int c = 0; c < NC; c++) pv += int'(pv_noc[c]) + int'(pv_lm[c]);
    for (int k = 0; k < NV; k++) pv += int'(pv_spm[k]);
    if (pv != 0) `ERR(("%0d protocol violations", pv))
    if (quiesce_viol != 0) `ERR(("%0d memory requests started during a drain", quiesce_viol))
    if (test == "mixed" && NV > 0 && NT > 0 && ov_vt == 0) `ERR(("vector and tensor engines never busy together"))
    if ((test == "multi" || test == "mixed") && NV > 1 && ov_vv == 0) `ERR(("vector clusters never busy together"))
    if ((test == "multi" || test == "mixed") && NT > 1 && ov_tt == 0) `ERR(("tensor clusters never busy together"))
    if (GATE != 0 && gated_cycles == 0) `ERR(("clock never gated"))
    $display("STAT cycles %0d", cyc);
    $display("STAT commands %0d", n_cmd);
    $display("STAT completions %0d ok %0d engine_errors %0d shell %0d reset_abort %0d", n_cpl, n_ok, n_engerr, n_shell, n_abort);
    $display("STAT src_switches %0d", n_reorder);
    $display("STAT overlap_vector_tensor %0d overlap_vector_vector %0d overlap_tensor_tensor %0d", ov_vt, ov_vv, ov_tt);
    $display("STAT host_ops %0d host_read_checks %0d gated_cycles %0d", h_ops, h_rd_checks, gated_cycles);
    for (int c = 0; c < NC; c++)
      $display("STAT cluster %0d dest %0d mem_req %0d mem_stall %0d mem_rsp %0d mem_rsp_err %0d lm_req %0d spm_req %0d busy %0d db_retry %0d cmd_stall %0d cpl_stall %0d reset %0d clk_req %0d noc_req %0d",
               c, dest_of(c), pev_cnt[c][`SFX_CL_PEV_MEM_REQ], pev_cnt[c][`SFX_CL_PEV_MEM_STALL],
               pev_cnt[c][`SFX_CL_PEV_MEM_RSP], pev_cnt[c][`SFX_CL_PEV_MEM_RSP_ERR], pev_cnt[c][`SFX_CL_PEV_LM_REQ],
               pev_cnt[c][`SFX_CL_PEV_SPM_REQ], pev_cnt[c][`SFX_CL_PEV_ENG_BUSY], pev_cnt[c][`SFX_CL_PEV_DB_RETRY],
               pev_cnt[c][`SFX_CL_PEV_CMD_STALL], pev_cnt[c][`SFX_CL_PEV_CPL_STALL], pev_cnt[c][`SFX_CL_PEV_RESET],
               pev_cnt[c][`SFX_CL_PEV_CLK_REQ], pn_req[c]);
    $display("RESULT %s test=%s seed=%0d errors=%0d cycles=%0d", (errors == 0) ? "PASS" : "FAIL", test, seed, errors, cyc);
    $finish;
  endtask

  // watchdog
  always @(posedge clk) if (cyc > max_cyc) begin
    `ERR(("watchdog: %0d cycles", cyc))
    $display("RESULT FAIL test=%s seed=%0d errors=%0d cycles=%0d (watchdog)", test, seed, errors, cyc);
    $finish;
  end
endmodule
`default_nettype wire
