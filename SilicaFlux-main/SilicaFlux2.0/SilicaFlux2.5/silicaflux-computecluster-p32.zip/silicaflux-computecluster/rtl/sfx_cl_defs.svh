// =============================================================================
// SilicaFlux-HPC Project 32 :: ComputeCluster -- shared definitions (single source)
// Aureom.AI | SilicaFlux-HPC
//
// Cluster-level ABI that the vector and tensor clusters have in common: the
// completion header word, the cluster control page, the sticky error bits and
// the 1-bit performance events.  Engine ABIs are NOT redefined here: the vector
// tile (HPC Module 08, hpc_tile_defs.svh) and the tensor unit (TENSORCORE 08,
// tsu_defs.svh) keep their own descriptor / record formats unchanged.
// docs/02_INTERFACES.md documents these encodings; the testbench (tb/tb_cc.sv)
// includes this file, so the checks use the same definitions as the RTL.
// =============================================================================
`ifndef SFX_CL_DEFS_SVH
`define SFX_CL_DEFS_SVH

`define SFX_CL_ABI_VERSION      8'd1

// ------------------------------------------------------------ illegal configuration (elaboration)
// Same portability pattern as the SRAM Wrapper Library's SRAM_CFG_FATAL: Icarus 12 does not evaluate an
// elaboration-time $fatal, so it gets a time-0 $fatal; Yosys 0.33 aborts without printing the message, so every
// check sits in a generate block whose name states the reason (g_err_*).
`ifdef __ICARUS__
  `define SFX_CL_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SFX_CL_CFG_FATAL(msg) $fatal(1, msg);
`endif

// ------------------------------------------------------------ engine types (CL_INFO[11:8], header[11:8])
`define SFX_CL_ENG_NONE         4'd0     // shell-generated record (no engine)
`define SFX_CL_ENG_VECTOR       4'd1     // HPC Module 08 silicaflux_hpc_tile
`define SFX_CL_ENG_TENSOR       4'd2     // TENSORCORE 08 silicaflux_tensor_unit

// ------------------------------------------------------------ completion packet
// Every completion packet is SFX_CL_CPL_WORDS 32-bit words: one header word,
// then the engine's own 6-word completion record (zero for shell records).
`define SFX_CL_ENG_CPL_WORDS    6
`define SFX_CL_CPL_WORDS        7
// header word fields
`define SFX_CL_H_STATUS_LSB     0        // [3:0]  CL_STATUS
`define SFX_CL_H_ERR_BIT        4        // [4]    error summary (engine error status, or any shell status)
`define SFX_CL_H_ENGINE_LSB     8        // [11:8] engine type
`define SFX_CL_H_NWORDS_LSB     12       // [15:12] engine words that follow (6)
`define SFX_CL_H_CLUSTER_LSB    16       // [23:16] CLUSTER_ID of the producer
`define SFX_CL_H_ABI_LSB        24       // [31:24] SFX_CL_ABI_VERSION
// CL_STATUS
`define SFX_CL_ST_ENGINE        4'd0     // the engine executed (or rejected) the command; engine record follows
`define SFX_CL_ST_BAD_LENGTH    4'd1     // command packet length != engine descriptor length; not submitted
`define SFX_CL_ST_RESET_ABORT   4'd2     // accepted, then destroyed by a cluster reset before its record was read
`define SFX_CL_ST_STREAM_OFF    4'd3     // stream submission disabled (CL_CTRL.STREAM_EN = 0); not submitted
`define SFX_CL_ST_BAD_DEST      4'd4     // compute-cluster shell: cmd_dest names no cluster; not submitted

// ------------------------------------------------------------ cluster control page (CSR offset 0x1000 + reg)
`define SFX_CL_ID_VALUE         32'h5346_434C   // "SFCL"
`define SFX_CL_R_ID             12'h000  // RO  "SFCL"
`define SFX_CL_R_INFO           12'h004  // RO  [7:0] CLUSTER_ID [11:8] engine [15:12] ABI version (low 4 bits)
                                         //     [16] LOCAL_MEM_EN [17] SPM_PORT_EN [18] MEM_REQ_SLICE [19] MEM_RSP_SLICE
                                         //     [23:20] 0 [31:24] XACT_WIDTH/8
`define SFX_CL_R_CTRL           12'h008  // RW  [0] STREAM_EN (refused unless the adapter is idle) [2] CLKREQ_FORCE
                                         //     W1 pulse (reads 0): [1] RESET (cluster reset sequence)
`define SFX_CL_R_STATUS         12'h00C  // RO  see SFX_CL_SB_*
`define SFX_CL_R_ERR            12'h010  // W1C sticky error bits SFX_CL_E_*
`define SFX_CL_R_ERR_EN         12'h014  // RW  irq enable per error bit
`define SFX_CL_R_CMDS           12'h018  // RO  command packets accepted (saturating)
`define SFX_CL_R_CPLS           12'h01C  // RO  completion packets delivered (saturating)
`define SFX_CL_R_ABORTS         12'h020  // RO  RESET_ABORT completions generated (saturating)
`define SFX_CL_R_RESETS         12'h024  // RO  cluster reset sequences completed (saturating)
`define SFX_CL_R_MEMINFO        12'h028  // RO  [7:0] memory transactions outstanding [15:8] scratchpad-port outstanding
                                         //     [23:16] tracking entries
// CL_STATUS bits
`define SFX_CL_SB_BUSY          0        // anything in flight (engine, adapter, memory)
`define SFX_CL_SB_ENG_BUSY      1        // engine busy output
`define SFX_CL_SB_ENG_HALTED    2        // engine halted output
`define SFX_CL_SB_RESETTING     3        // reset sequence active (quiesce .. init)
`define SFX_CL_SB_ENG_IN_RESET  4        // engine reset asserted
`define SFX_CL_SB_STREAM_EN     5
`define SFX_CL_SB_ADAPTER_IDLE  6
`define SFX_CL_SB_CLK_REQ       7
`define SFX_CL_SB_DRAINING      8        // memory responses of a forced reset still being dropped
`define SFX_CL_SB_STATE_LSB     12       // [15:12] reset sequencer state

// ------------------------------------------------------------ sticky error bits (CL_ERR, err_status)
`define SFX_CL_ERR_W            8
`define SFX_CL_E_CPL_ERR        0        // an error completion was delivered (engine error or shell status)
`define SFX_CL_E_BAD_CMD        1        // bad-length packet, or a packet while STREAM_EN = 0
`define SFX_CL_E_MEM_ERR        2        // an SFB2 error response reached the cluster (NoC or local port)
`define SFX_CL_E_HALTED         3        // the engine entered HALTED
`define SFX_CL_E_RESET_ABORT    4        // a cluster reset destroyed accepted commands
`define SFX_CL_E_DRAIN_TIMEOUT  5        // a reset could not drain the memory port in time: responses dropped
`define SFX_CL_E_CSR_DENIED     6        // a host CSR write was refused by the ownership rule
`define SFX_CL_E_PROTOCOL       7        // unsolicited memory response / engine refused CPL_POP (should not happen)

// ------------------------------------------------------------ performance events (1 bit per cycle, registered)
`define SFX_CL_PEV_W            16
`define SFX_CL_PEV_CMD_ACCEPT   0        // command packet accepted (last word)
`define SFX_CL_PEV_CMD_SUBMIT   1        // doorbell accepted by the engine
`define SFX_CL_PEV_CMD_STALL    2        // cmd_valid && !cmd_ready
`define SFX_CL_PEV_CPL_DELIVER  3        // completion packet delivered (last word)
`define SFX_CL_PEV_CPL_ERR      4        // ... with the error summary set
`define SFX_CL_PEV_CPL_STALL    5        // cpl_valid && !cpl_ready
`define SFX_CL_PEV_ENG_BUSY     6        // engine busy
`define SFX_CL_PEV_MEM_REQ      7        // NoC-port request handshake
`define SFX_CL_PEV_MEM_STALL    8        // NoC-port request presented, not accepted
`define SFX_CL_PEV_MEM_RSP      9        // memory response accepted by the cluster (both ports)
`define SFX_CL_PEV_MEM_RSP_ERR  10       // ... with rsp_error
`define SFX_CL_PEV_LM_REQ       11       // local-memory-port request handshake
`define SFX_CL_PEV_SPM_REQ      12       // scratchpad-port (slave) request handshake
`define SFX_CL_PEV_RESET        13       // reset sequence active
`define SFX_CL_PEV_CLK_REQ      14       // clk_req asserted
`define SFX_CL_PEV_DB_RETRY     15       // doorbell refused (engine queue full), retried

// ------------------------------------------------------------ reset sequencer states (CL_STATUS[15:12])
`define SFX_CL_RS_RUN           4'd0
`define SFX_CL_RS_Q_CMD         4'd1     // adapter stops starting engine sequences, wait until safe
`define SFX_CL_RS_Q_MEM         4'd2     // memory / scratchpad ports block new requests, wait until quiet
`define SFX_CL_RS_RESET         4'd3     // engine reset asserted
`define SFX_CL_RS_RELEASE       4'd4     // engine reset released, settle
`define SFX_CL_RS_INIT          4'd5     // adapter writes the engine's stream configuration

`endif
