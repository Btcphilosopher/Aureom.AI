// =============================================================================
// SilicaFlux-HPC Project 32 :: sfx_cl_mem_port
// Memory boundary of one compute cluster (engine SFB2 master -> NoC / local
// memory ports).  Aureom.AI | SilicaFlux-HPC
//
//   engine SFB2 master (EW bits)
//      │
//   [gate]  quiesce for a cluster reset · MAX_OUT limit · target-switch interlock
//      │    outstanding counter · forced drain (responses of a destroyed engine dropped)
//   [up]    EW -> DW lane steering (only when EW < DW; tensor unit is 32-bit)
//      │
//   [split] address window LM_BASE/LM_MASK -> local memory port, else NoC port (LOCAL_EN)
//      │
//   [slice] DataFabric sfb_reg_slice per port (REQ_SLICE / RSP_SLICE: +1 cycle each)
//      ├──► n_*  NoC-facing SFB2 master
//      └──► l_*  local-memory SFB2 master (tied off when LOCAL_EN = 0)
//
// Protocol (DataFabric PROTOCOL.md, SFB2): requests pass in order; a request
// presented downstream is never withdrawn (R2: the gate only blocks requests it
// has not yet presented — hold_q); exactly one response per request, in order
// (R5): a new target is selected only when nothing is outstanding, so the
// responses of the two ports can never be reordered.  Every block here is in the
// cluster's shell (system-reset) domain: an engine reset never cuts a transaction
// on the NoC.  When the reset sequencer forces a reset with transactions still
// outstanding (drain timeout), their responses are accepted and dropped
// (drop_cnt) and no new request leaves until they are gone.  A request that is
// presented but not accepted at that moment is captured (cap_*) and kept on the
// port, unchanged, until the NoC accepts it; its response is dropped as well.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cl_defs.svh"
`default_nettype none

module sfx_cl_mem_port #(
  parameter int          EW        = 32,             // engine data width
  parameter int          DW        = 32,             // port data width (transaction width), >= EW
  parameter int          MAX_OUT   = 4,              // outstanding transactions allowed (power of two, 1..64)
  parameter int          LOCAL_EN  = 0,              // 1: local memory port for the LM window
  parameter logic [31:0] LM_BASE   = 32'h0000_0000,
  parameter logic [31:0] LM_MASK   = 32'hFFFF_0000,  // window: (addr & LM_MASK) == LM_BASE
  parameter int          REQ_SLICE = 0,              // sfb_reg_slice on the request channel of each port
  parameter int          RSP_SLICE = 0,              // sfb_reg_slice on the response channel of each port
  localparam int         ESB       = EW / 8,
  localparam int         SB        = DW / 8,
  localparam int         OW        = $clog2(MAX_OUT + 1)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // ---------------------------------------------------------- reset sequencer
  input  wire logic           q_req,          // block new requests
  input  wire logic           force_drop,     // pulse: drop the responses still outstanding
  output logic                quiet,          // nothing outstanding, nothing presented
  output logic                draining,       // dropping responses of a forced reset
  output logic [OW-1:0]       outstanding,
  // ---------------------------------------------------------- engine side (SFB2 slave)
  input  wire logic           e_req_valid,
  output logic                e_req_ready,
  input  wire logic           e_req_write,
  input  wire logic [31:0]    e_req_addr,
  input  wire logic [EW-1:0]  e_req_wdata,
  input  wire logic [ESB-1:0] e_req_wstrb,
  output logic                e_rsp_valid,
  input  wire logic           e_rsp_ready,
  output logic [EW-1:0]       e_rsp_rdata,
  output logic                e_rsp_error,
  // ---------------------------------------------------------- NoC port (SFB2 master)
  output logic                n_req_valid,
  input  wire logic           n_req_ready,
  output logic                n_req_write,
  output logic [31:0]         n_req_addr,
  output logic [DW-1:0]       n_req_wdata,
  output logic [SB-1:0]       n_req_wstrb,
  input  wire logic           n_rsp_valid,
  output logic                n_rsp_ready,
  input  wire logic [DW-1:0]  n_rsp_rdata,
  input  wire logic           n_rsp_error,
  // ---------------------------------------------------------- local memory port (SFB2 master)
  output logic                l_req_valid,
  input  wire logic           l_req_ready,
  output logic                l_req_write,
  output logic [31:0]         l_req_addr,
  output logic [DW-1:0]       l_req_wdata,
  output logic [SB-1:0]       l_req_wstrb,
  input  wire logic           l_rsp_valid,
  output logic                l_rsp_ready,
  input  wire logic [DW-1:0]  l_rsp_rdata,
  input  wire logic           l_rsp_error,
  // ---------------------------------------------------------- events
  output logic                ev_noc_req,
  output logic                ev_noc_stall,
  output logic                ev_lm_req,
  output logic                ev_rsp,
  output logic                ev_rsp_err,
  output logic                ev_unsol
);
  // ============================================================ configuration checks
  if (!(EW == 32 || EW == 64 || EW == 128) || !(DW == 32 || DW == 64 || DW == 128) || DW < EW) begin : g_err_w
    `SFX_CL_CFG_FATAL("sfx_cl_mem_port: EW, DW must be 32/64/128 with DW >= EW")
  end
  if (MAX_OUT < 1 || MAX_OUT > 64 || (MAX_OUT & (MAX_OUT - 1)) != 0) begin : g_err_mo
    `SFX_CL_CFG_FATAL("sfx_cl_mem_port: MAX_OUT must be a power of two 1..64")
  end
  if (LOCAL_EN != 0 && LOCAL_EN != 1) begin : g_err_le
    `SFX_CL_CFG_FATAL("sfx_cl_mem_port: LOCAL_EN must be 0 or 1")
  end
  if (LOCAL_EN != 0 && (LM_BASE & ~LM_MASK) != 32'd0) begin : g_err_lm
    `SFX_CL_CFG_FATAL("sfx_cl_mem_port: LM_BASE has bits outside LM_MASK")
  end

  // ============================================================ gate
  logic          hold_q, cur_tgt, cap_v;
  logic [OW-1:0] out_cnt, drop_cnt;
  wire           tgt   = (LOCAL_EN != 0) && ((e_req_addr & LM_MASK) == LM_BASE);
  wire           blk   = q_req || cap_v || (drop_cnt != '0) || (out_cnt == OW'(MAX_OUT)) ||
                         ((LOCAL_EN != 0) && (out_cnt != '0) && (tgt != cur_tgt));
  wire           block = blk && !hold_q;
  wire           g_valid = e_req_valid && !block && !cap_v;
  logic          d_ready;                    // from the selected port path
  assign e_req_ready = d_ready && !block && !cap_v;

  // ============================================================ width adaptation EW -> DW
  logic [31:0]   u_addr;
  logic [DW-1:0] u_wdata;
  logic [SB-1:0] u_wstrb;
  logic [DW-1:0] r_rdata_w;                  // selected port response data (DW)
  logic [EW-1:0] r_rdata;                    // engine-width response data
  logic          r_hs;                       // response handshake (forwarded or dropped)

  // downstream request: the engine's, or the one captured by a forced reset
  logic          cap_w, cap_t;
  logic [31:0]   cap_a;
  logic [DW-1:0] cap_d;
  logic [SB-1:0] cap_s;
  wire           d_valid = cap_v || g_valid;
  wire           d_write = cap_v ? cap_w : e_req_write;
  wire           d_tgt   = cap_v ? cap_t : tgt;
  wire  [31:0]   d_addr  = cap_v ? cap_a : u_addr;
  wire  [DW-1:0] d_wdata = cap_v ? cap_d : u_wdata;
  wire  [SB-1:0] d_wstrb = cap_v ? cap_s : u_wstrb;
  wire           d_hs    = d_valid && d_ready;

  if (EW == DW) begin : g_same
    assign u_addr  = e_req_addr;
    assign u_wdata = e_req_wdata;
    assign u_wstrb = e_req_wstrb;
    assign r_rdata = r_rdata_w;
  end else begin : g_up
    localparam int NL  = DW / EW;
    localparam int LW  = $clog2(NL);
    localparam int LO  = $clog2(ESB);        // lane index = addr[LO +: LW]
    localparam int FPW = (MAX_OUT > 1) ? $clog2(MAX_OUT) : 1;
    logic [LW-1:0]  lane_q [MAX_OUT];
    logic [FPW:0]   lwp, lrp;
    wire  [LW-1:0]  lane = e_req_addr[LO +: LW];
    assign u_addr  = {e_req_addr[31:LO+LW], {(LO+LW){1'b0}}};
    assign u_wdata = {NL{e_req_wdata}};
    assign u_wstrb = SB'(e_req_wstrb) << (ESB * lane);
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        lwp <= '0; lrp <= '0;
        for (int i = 0; i < MAX_OUT; i++) lane_q[i] <= '0;
      end else begin
        if (d_hs) begin                      // a captured request's response is dropped: its lane is irrelevant
          lane_q[(MAX_OUT > 1) ? lwp[FPW-1:0] : 0] <= lane;
          lwp <= lwp + 1'b1;
        end
        if (r_hs) lrp <= lrp + 1'b1;
      end
    end
    wire [LW-1:0] rl = lane_q[(MAX_OUT > 1) ? lrp[FPW-1:0] : 0];
    assign r_rdata = r_rdata_w[rl * EW +: EW];
  end

  // ============================================================ split + slices
  logic          ns_req_valid, ns_req_ready, ns_rsp_valid, ns_rsp_ready, ns_rsp_error;
  logic [DW-1:0] ns_rsp_rdata;
  logic          ls_req_valid, ls_req_ready, ls_rsp_valid, ls_rsp_ready, ls_rsp_error;
  logic [DW-1:0] ls_rsp_rdata;

  assign ns_req_valid = d_valid && !d_tgt;
  assign ls_req_valid = d_valid &&  d_tgt;
  assign d_ready      = d_tgt ? ls_req_ready : ns_req_ready;

  sfb_reg_slice #(.AW(32), .DW(DW), .REQ_SLICE(REQ_SLICE), .RSP_SLICE(RSP_SLICE)) u_noc_slice (
    .clk, .rst_n,
    .s_req_valid(ns_req_valid), .s_req_ready(ns_req_ready), .s_req_write(d_write), .s_req_addr(d_addr),
    .s_req_wdata(d_wdata), .s_req_wstrb(d_wstrb),
    .s_rsp_valid(ns_rsp_valid), .s_rsp_ready(ns_rsp_ready), .s_rsp_rdata(ns_rsp_rdata), .s_rsp_error(ns_rsp_error),
    .m_req_valid(n_req_valid), .m_req_ready(n_req_ready), .m_req_write(n_req_write), .m_req_addr(n_req_addr),
    .m_req_wdata(n_req_wdata), .m_req_wstrb(n_req_wstrb),
    .m_rsp_valid(n_rsp_valid), .m_rsp_ready(n_rsp_ready), .m_rsp_rdata(n_rsp_rdata), .m_rsp_error(n_rsp_error)
  );

  if (LOCAL_EN != 0) begin : g_lm
    sfb_reg_slice #(.AW(32), .DW(DW), .REQ_SLICE(REQ_SLICE), .RSP_SLICE(RSP_SLICE)) u_lm_slice (
      .clk, .rst_n,
      .s_req_valid(ls_req_valid), .s_req_ready(ls_req_ready), .s_req_write(d_write), .s_req_addr(d_addr),
      .s_req_wdata(d_wdata), .s_req_wstrb(d_wstrb),
      .s_rsp_valid(ls_rsp_valid), .s_rsp_ready(ls_rsp_ready), .s_rsp_rdata(ls_rsp_rdata), .s_rsp_error(ls_rsp_error),
      .m_req_valid(l_req_valid), .m_req_ready(l_req_ready), .m_req_write(l_req_write), .m_req_addr(l_req_addr),
      .m_req_wdata(l_req_wdata), .m_req_wstrb(l_req_wstrb),
      .m_rsp_valid(l_rsp_valid), .m_rsp_ready(l_rsp_ready), .m_rsp_rdata(l_rsp_rdata), .m_rsp_error(l_rsp_error)
    );
  end else begin : g_nolm
    assign l_req_valid  = 1'b0;
    assign l_req_write  = 1'b0;
    assign l_req_addr   = '0;
    assign l_req_wdata  = '0;
    assign l_req_wstrb  = '0;
    assign l_rsp_ready  = 1'b1;                // a stray response is absorbed (never expected)
    assign ls_req_ready = 1'b0;
    assign ls_rsp_valid = 1'b0;
    assign ls_rsp_rdata = '0;
    assign ls_rsp_error = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_lm = ^{ls_req_valid, ls_rsp_ready, l_req_ready, l_rsp_valid, l_rsp_rdata, l_rsp_error};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ============================================================ responses: current target, drop, unsolicited
  wire dropping = (drop_cnt != '0);
  wire have_out = (out_cnt != '0);
  wire c_valid  = cur_tgt ? ls_rsp_valid : ns_rsp_valid;          // current target
  wire o_valid  = cur_tgt ? ns_rsp_valid : ls_rsp_valid;          // the other one: never legitimate
  wire c_error  = cur_tgt ? ls_rsp_error : ns_rsp_error;
  assign r_rdata_w = cur_tgt ? ls_rsp_rdata : ns_rsp_rdata;

  wire c_ok      = c_valid && have_out;
  assign e_rsp_valid = c_ok && !dropping;
  assign e_rsp_rdata = r_rdata;
  assign e_rsp_error = c_error;
  wire c_ready   = !have_out || dropping || e_rsp_ready;           // unsolicited / dropped: consumed here
  assign r_hs    = c_ok && (dropping || e_rsp_ready);
  assign ns_rsp_ready = cur_tgt ? 1'b1 : c_ready;
  assign ls_rsp_ready = cur_tgt ? c_ready : 1'b1;

  // ============================================================ state
  // a request presented and not accepted when the reset is forced is kept on the port
  wire cap_now = force_drop && !cap_v && g_valid && !d_ready;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hold_q   <= 1'b0;
      cur_tgt  <= 1'b0;
      out_cnt  <= '0;
      drop_cnt <= '0;
      cap_v    <= 1'b0;
    end else begin
      hold_q  <= d_valid && !d_ready;
      if (d_hs) cur_tgt <= d_tgt;
      out_cnt <= out_cnt + OW'(d_hs) - OW'(r_hs);
      if (force_drop)             drop_cnt <= out_cnt + OW'(d_hs) - OW'(r_hs) + OW'(cap_now || (cap_v && !d_hs));
      else if (dropping && r_hs)  drop_cnt <= drop_cnt - 1'b1;
      if (cap_now)                cap_v <= 1'b1;
      else if (cap_v && d_hs)     cap_v <= 1'b0;
    end
  end
  always_ff @(posedge clk) begin
    if (cap_now) begin
      cap_w <= e_req_write; cap_t <= tgt; cap_a <= u_addr; cap_d <= u_wdata; cap_s <= u_wstrb;
    end
  end

  assign quiet       = !hold_q && !have_out && !dropping && !cap_v;
  assign draining    = dropping;
  assign outstanding = out_cnt;

  assign ev_noc_req   = n_req_valid && n_req_ready;
  assign ev_noc_stall = n_req_valid && !n_req_ready;
  assign ev_lm_req    = l_req_valid && l_req_ready;
  assign ev_rsp       = r_hs;
  assign ev_rsp_err   = r_hs && c_error;
  assign ev_unsol     = (c_valid && !have_out) || o_valid;
endmodule

`default_nettype wire
