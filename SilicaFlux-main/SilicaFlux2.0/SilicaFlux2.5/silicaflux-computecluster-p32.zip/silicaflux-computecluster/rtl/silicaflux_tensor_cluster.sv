// =============================================================================
// SilicaFlux-HPC Project 32 :: silicaflux_tensor_cluster
// One floorplan-friendly INT8 tensor compute region.  Aureom.AI | SilicaFlux-HPC
//
// The validated TENSORCORE 08 tensor unit (silicaflux_tensor_unit: TC02 systolic
// array, TC03 operand buffers, TC04 accumulator, TC05 quantiser, TC07 DMA adapter
// / output buffer / compute sequencer, scheduler, queues, counters) is
// instantiated UNMODIFIED as u_engine.  The cluster adds only a shell:
//
//   cmd ─► u_cmd (sfx_cl_cmd_port) ─rb─► ┌──────────────── u_engine ──────────────────┐
//   cpl ◄─                               │ u_dp.u_tob (operand buffers)  ─┐            │
//   csr ─► [12]=0 engine page             │ u_dp.u_arr (systolic array)   ─┤ compute    │
//          [12]=1 u_ctrl page             │ u_dp.u_acc (accumulator)      ─┤ core       │
//                                         │ u_dp.u_ob  (output buffer)    ─┘            │
//                                         │ u_dp.u_dma (TC07 DMA) ─ u_gate ─ m_* (32b)  │
//                                         └──────────────────────────────┼─────────────┘
//   mem_* (NoC master, XACT_WIDTH) ◄─ u_mem (sfx_cl_mem_port, 32 -> XACT_WIDTH lanes) ◄┘
//   lm_*  (local memory master, LOCAL_MEM_EN) ◄─┘
//   u_ctrl (sfx_cl_ctrl): reset sequencer, errors, irq, clk_req, perf events
//
// Physical intent: the systolic array sits between the operand buffers and the
// accumulator (u_dp.u_tob / u_arr / u_acc / u_ob as one compute core group); the
// TC07 DMA and u_mem face the NoC edge.  No coordinates in RTL.
// The tensor unit's SFB2 master is 32 bits wide (TC08 R10); with XACT_WIDTH 64 or
// 128 u_mem steers each 32-bit access onto its byte lanes (no packing, no bursts).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cl_defs.svh"
`include "sram_defs.svh"
`include "tsu_defs.svh"
`default_nettype none

module silicaflux_tensor_cluster #(
  parameter logic [7:0]  CLUSTER_ID              = 8'd0,
  // ------------------------------------------------------------ engine (TENSORCORE 08 tensor unit)
  parameter int          ARRAY_ROWS              = 4,
  parameter int          ARRAY_COLS              = 4,
  parameter int          TILE_K                  = 64,
  parameter int          OPERAND_BUFFER_BYTES    = 2048,
  parameter int          NUM_MEMORY_BANKS        = 4,
  parameter int          ENABLE_QUANTIZATION     = 0,
  parameter int          ENABLE_DOUBLE_BUFFERING = 0,
  parameter int          CMD_QUEUE_DEPTH         = 4,
  parameter int          CPL_QUEUE_DEPTH         = 4,
  parameter logic [32:0] MEM_LO                  = 33'h0_0000_0000,
  parameter logic [32:0] MEM_HI                  = 33'h1_0000_0000,
  parameter int          ENG_MAX_OUT             = 4,      // tensor unit SFB2 transactions in flight
  parameter int          PERF_EN                 = 1,
  parameter int          ALLOW_UNVERIFIED        = 0,
  parameter int          MEM_BACKEND             = `SRAM_BACKEND_GENERIC,
  // ------------------------------------------------------------ cluster shell
  parameter int          XACT_WIDTH              = 32,
  parameter int          LOCAL_MEM_EN            = 0,
  parameter logic [31:0] LOCAL_MEM_BASE          = 32'h3000_0000,
  parameter logic [31:0] LOCAL_MEM_MASK          = 32'hFFFF_0000,
  parameter int          MEM_REQ_SLICE           = 0,
  parameter int          MEM_RSP_SLICE           = 0,
  parameter int          TAG_W                   = 8,
  parameter int          TRK_DEPTH               = 16,
  parameter int          STREAM_DEFAULT          = 1,
  parameter int          RST_CYCLES              = 4,
  parameter int          DRAIN_LOG2              = 12,
  parameter int          IDLE_HYST               = 16,
  // ------------------------------------------------------------ derived
  localparam int DW  = XACT_WIDTH,
  localparam int SB  = DW / 8,
  localparam int TLW = $clog2(TRK_DEPTH + 1),
  localparam int MOW = $clog2(ENG_MAX_OUT + 1),
  localparam int NPC = `TSU_NUM_PC
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             rst_req,
  // ---------------------------------------------------------- command / completion streams
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [31:0]      cmd_data,
  input  wire logic             cmd_last,
  input  wire logic [TAG_W-1:0] cmd_tag,
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [31:0]           cpl_data,
  output logic                  cpl_last,
  output logic [TAG_W-1:0]      cpl_tag,
  output logic                  cpl_err,
  // ---------------------------------------------------------- CSR (rb contract, 8 KiB)
  input  wire logic             csr_sel,
  input  wire logic             csr_we,
  input  wire logic [12:0]      csr_addr,
  input  wire logic [31:0]      csr_wdata,
  output logic [31:0]           csr_rdata,
  output logic                  csr_err,
  // ---------------------------------------------------------- NoC memory master (SFB2)
  output logic                  mem_req_valid,
  input  wire logic             mem_req_ready,
  output logic                  mem_req_write,
  output logic [31:0]           mem_req_addr,
  output logic [DW-1:0]         mem_req_wdata,
  output logic [SB-1:0]         mem_req_wstrb,
  input  wire logic             mem_rsp_valid,
  output logic                  mem_rsp_ready,
  input  wire logic [DW-1:0]    mem_rsp_rdata,
  input  wire logic             mem_rsp_error,
  // ---------------------------------------------------------- local memory master (SFB2, LOCAL_MEM_EN)
  output logic                  lm_req_valid,
  input  wire logic             lm_req_ready,
  output logic                  lm_req_write,
  output logic [31:0]           lm_req_addr,
  output logic [DW-1:0]         lm_req_wdata,
  output logic [SB-1:0]         lm_req_wstrb,
  input  wire logic             lm_rsp_valid,
  output logic                  lm_rsp_ready,
  input  wire logic [DW-1:0]    lm_rsp_rdata,
  input  wire logic             lm_rsp_error,
  // ---------------------------------------------------------- interrupt / error / status / events (registered)
  output logic                  irq,
  output logic                  err,
  output logic [`SFX_CL_ERR_W-1:0] err_status,
  output logic                  busy,
  output logic                  clk_req,
  output logic [`SFX_CL_PEV_W-1:0] perf_ev
);
  localparam logic [31:0] INFO = {8'(XACT_WIDTH / 8), 4'd0, 1'(MEM_RSP_SLICE != 0), 1'(MEM_REQ_SLICE != 0),
                                  1'b0, 1'(LOCAL_MEM_EN != 0), 4'(`SFX_CL_ABI_VERSION),
                                  `SFX_CL_ENG_TENSOR, CLUSTER_ID};

  logic stream_en, quiesce, port_q, force_drop, eng_in_reset, eng_rst_n;
  logic ad_safe, ad_idle;
  logic [TLW-1:0] trk_level;
  logic m_quiet, m_draining;
  logic [MOW-1:0] m_out;
  logic e_busy, e_halted, e_irq;

  // ============================================================ CSR split
  wire h_sel = csr_sel && !csr_addr[12];
  wire c_sel = csr_sel &&  csr_addr[12];
  logic [31:0] h_rdata, c_rdata;
  logic        h_err, c_err;
  assign csr_rdata = csr_addr[12] ? c_rdata : h_rdata;
  assign csr_err   = csr_addr[12] ? c_err   : h_err;

  // ============================================================ command / completion adapter
  logic        e_sel, e_we, e_err;
  logic [11:0] e_addr;
  logic [31:0] e_wdata, e_rdata;
  logic ev_cmd_accept, ev_submit, ev_db_retry, ev_cpl_deliver, ev_cpl_err, ev_bad_cmd, ev_abort_cpl,
        ev_host_deny, ev_pop_err;

  sfx_cl_cmd_port #(
    .TAG_W(TAG_W), .CMD_WORDS(`TSU_DESC_WORDS), .R_CMD0(`TSU_R_DESC0), .R_DOORBELL(`TSU_R_DOORBELL),
    .R_STATUS(`TSU_R_STATUS), .SB_CPL_VALID(`TSU_SB_CPL_VALID), .R_CPL0(`TSU_R_CPL0), .R_CPL_POP(`TSU_R_CPL_POP),
    .ERR_LSB(24), .ERR_W(2),                                              // record word 0 [25:24] STATUS
    .INIT_EN(1), .R_INIT(`TSU_R_CTRL), .INIT_DATA(32'h0000_0001),        // ERR_CONT = 1: commands independent
    .R_SRST(`TSU_R_CTRL), .SRST_MASK(32'h0000_0000),                     // ABORT still produces records: allowed
    .TRK_DEPTH(TRK_DEPTH), .STREAM_DEFAULT(STREAM_DEFAULT), .CLUSTER_ID(CLUSTER_ID), .ENGINE(`SFX_CL_ENG_TENSOR)
  ) u_cmd (
    .clk, .rst_n,
    .stream_en, .quiesce, .eng_in_reset, .safe(ad_safe), .idle(ad_idle), .trk_level,
    .cmd_valid, .cmd_ready, .cmd_data, .cmd_last, .cmd_tag,
    .cpl_valid, .cpl_ready, .cpl_data, .cpl_last, .cpl_tag, .cpl_err,
    .h_sel, .h_we(csr_we), .h_addr(csr_addr[11:0]), .h_wdata(csr_wdata), .h_rdata, .h_err,
    .e_sel, .e_we, .e_addr, .e_wdata, .e_rdata, .e_err,
    .ev_cmd_accept, .ev_submit, .ev_db_retry, .ev_cpl_deliver, .ev_cpl_err, .ev_bad_cmd, .ev_abort_cpl,
    .ev_host_deny, .ev_pop_err
  );

  // ============================================================ engine: TENSORCORE 08 tensor unit, unmodified
  logic        a_req_valid, a_req_ready, a_req_write, a_rsp_valid, a_rsp_ready, a_rsp_error;
  logic [31:0] a_req_addr, a_req_wdata, a_rsp_rdata;
  logic [3:0]  a_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NPC*32-1:0] e_perf_ev;      // increments of the engine's own counters (readable on its PERF page)
  /* verilator lint_on UNUSEDSIGNAL */

  silicaflux_tensor_unit #(
    .ARRAY_ROWS(ARRAY_ROWS), .ARRAY_COLS(ARRAY_COLS), .TILE_K(TILE_K), .OPERAND_BUFFER_BYTES(OPERAND_BUFFER_BYTES),
    .NUM_MEMORY_BANKS(NUM_MEMORY_BANKS), .ENABLE_QUANTIZATION(ENABLE_QUANTIZATION),
    .ENABLE_DOUBLE_BUFFERING(ENABLE_DOUBLE_BUFFERING), .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH),
    .CPL_QUEUE_DEPTH(CPL_QUEUE_DEPTH), .MEM_LO(MEM_LO), .MEM_HI(MEM_HI), .MAX_OUT(ENG_MAX_OUT), .PERF_EN(PERF_EN),
    .ALLOW_UNVERIFIED(ALLOW_UNVERIFIED), .FAULT_INJ(0), .MEM_BACKEND(MEM_BACKEND)
  ) u_engine (
    .clk, .rst_n(eng_rst_n),
    .rb_sel(e_sel), .rb_we(e_we), .rb_addr(e_addr), .rb_wdata(e_wdata), .rb_rdata(e_rdata), .rb_err(e_err),
    .m_req_valid(a_req_valid), .m_req_ready(a_req_ready), .m_req_write(a_req_write), .m_req_addr(a_req_addr),
    .m_req_wdata(a_req_wdata), .m_req_wstrb(a_req_wstrb),
    .m_rsp_valid(a_rsp_valid), .m_rsp_ready(a_rsp_ready), .m_rsp_rdata(a_rsp_rdata), .m_rsp_error(a_rsp_error),
    .irq(e_irq), .busy(e_busy), .halted(e_halted), .perf_ev(e_perf_ev), .fi_mode(2'b00)
  );

  // ============================================================ memory boundary (NoC-facing), 32 -> XACT_WIDTH
  logic ev_mem_req, ev_mem_stall, ev_lm_req, ev_mem_rsp, ev_mem_rsp_err, ev_unsol;

  sfx_cl_mem_port #(
    .EW(32), .DW(DW), .MAX_OUT(ENG_MAX_OUT), .LOCAL_EN(LOCAL_MEM_EN), .LM_BASE(LOCAL_MEM_BASE),
    .LM_MASK(LOCAL_MEM_MASK), .REQ_SLICE(MEM_REQ_SLICE), .RSP_SLICE(MEM_RSP_SLICE)
  ) u_mem (
    .clk, .rst_n,
    .q_req(port_q), .force_drop, .quiet(m_quiet), .draining(m_draining), .outstanding(m_out),
    .e_req_valid(a_req_valid), .e_req_ready(a_req_ready), .e_req_write(a_req_write), .e_req_addr(a_req_addr),
    .e_req_wdata(a_req_wdata), .e_req_wstrb(a_req_wstrb),
    .e_rsp_valid(a_rsp_valid), .e_rsp_ready(a_rsp_ready), .e_rsp_rdata(a_rsp_rdata), .e_rsp_error(a_rsp_error),
    .n_req_valid(mem_req_valid), .n_req_ready(mem_req_ready), .n_req_write(mem_req_write), .n_req_addr(mem_req_addr),
    .n_req_wdata(mem_req_wdata), .n_req_wstrb(mem_req_wstrb),
    .n_rsp_valid(mem_rsp_valid), .n_rsp_ready(mem_rsp_ready), .n_rsp_rdata(mem_rsp_rdata), .n_rsp_error(mem_rsp_error),
    .l_req_valid(lm_req_valid), .l_req_ready(lm_req_ready), .l_req_write(lm_req_write), .l_req_addr(lm_req_addr),
    .l_req_wdata(lm_req_wdata), .l_req_wstrb(lm_req_wstrb),
    .l_rsp_valid(lm_rsp_valid), .l_rsp_ready(lm_rsp_ready), .l_rsp_rdata(lm_rsp_rdata), .l_rsp_error(lm_rsp_error),
    .ev_noc_req(ev_mem_req), .ev_noc_stall(ev_mem_stall), .ev_lm_req, .ev_rsp(ev_mem_rsp), .ev_rsp_err(ev_mem_rsp_err),
    .ev_unsol
  );

  // ============================================================ local control
  sfx_cl_ctrl #(
    .INFO(INFO), .STREAM_DEFAULT(STREAM_DEFAULT), .RST_CYCLES(RST_CYCLES), .DRAIN_LOG2(DRAIN_LOG2),
    .IDLE_HYST(IDLE_HYST), .TLW(TLW), .MOW(MOW), .SOW(1)
  ) u_ctrl (
    .clk, .rst_n,
    .c_sel, .c_we(csr_we), .c_addr(csr_addr[11:0]), .c_wdata(csr_wdata), .c_rdata, .c_err,
    .rst_req,
    .eng_busy(e_busy), .eng_halted(e_halted), .eng_irq(e_irq), .ad_idle, .ad_safe, .trk_level,
    .m_quiet, .m_draining, .m_out, .s_quiet(1'b1), .s_out(1'b0),
    .wake(cmd_valid || csr_sel),
    .ev_cmd_accept, .ev_submit, .ev_cmd_stall(cmd_valid && !cmd_ready), .ev_cpl_deliver, .ev_cpl_err,
    .ev_cpl_stall(cpl_valid && !cpl_ready), .ev_bad_cmd, .ev_abort_cpl, .ev_host_deny, .ev_pop_err, .ev_db_retry,
    .ev_mem_req, .ev_mem_stall, .ev_lm_req, .ev_mem_rsp, .ev_mem_rsp_err, .ev_unsol, .ev_spm_req(1'b0),
    .stream_en, .quiesce, .port_q, .force_drop, .eng_in_reset, .eng_rst_n,
    .irq, .err, .err_status, .clk_req, .perf_ev, .busy
  );
endmodule

`default_nettype wire
