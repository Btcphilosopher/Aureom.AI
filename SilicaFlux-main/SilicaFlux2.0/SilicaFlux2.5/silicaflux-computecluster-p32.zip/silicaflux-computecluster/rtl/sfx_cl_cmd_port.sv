// =============================================================================
// SilicaFlux-HPC Project 32 :: sfx_cl_cmd_port
// Command / completion stream adapter of one compute cluster.  Aureom.AI | SilicaFlux-HPC
//
// Turns a narrow, word-serial command stream into the engine's own register-
// page submission sequence (staging words + DOORBELL), and harvests the engine's
// completion records (STATUS.CPL_VALID, CPL words, CPL_POP) into a word-serial
// completion stream.  The engine is reused unmodified: this block only drives its
// existing SilicaFlux-V register bus (rb) page, exactly as the ControlCore
// firmware (Project 21) or a host does.  No arithmetic is duplicated.
//
//   cmd stream ─► skid ─► packet FSM ──┐                     ┌─► engine rb page
//                                      ├─ rb arbiter (host CSR has priority)
//   cpl stream ◄─ record buffer ◄─ harvest FSM ◄──────────────┘
//                         ▲
//                  tracking FIFO {tag, kind}: one entry per accepted packet, in order
//
// Guarantees (docs/02_INTERFACES.md):
//   * every accepted command packet produces exactly one completion packet, in
//     acceptance order, carrying its tag: the engine record (both engines produce
//     exactly one record per accepted command, in submission order), or a
//     shell record (BAD_LENGTH, STREAM_OFF, RESET_ABORT);
//   * a cluster reset converts every tracked command whose record was not yet
//     popped from the engine into a RESET_ABORT completion (none is lost);
//   * the host CSR port keeps access to the engine page, except the registers the
//     adapter owns while streaming (staging, DOORBELL, CPL_POP, and the engine
//     soft reset that would destroy records): those writes answer rb_err.
// Boundary: cmd_ready, cpl_valid and cpl_data come from registers.
// One clock domain; rst_n = shell (system) reset; asynchronous assert, synchronous release.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cl_defs.svh"
`default_nettype none

module sfx_cl_cmd_port #(
  parameter int          TAG_W        = 8,
  parameter int          CMD_WORDS    = 8,             // engine descriptor words
  parameter logic [11:0] R_CMD0       = 12'h080,       // first staging register
  parameter logic [11:0] R_DOORBELL   = 12'h0A0,
  parameter logic [11:0] R_STATUS     = 12'h028,
  parameter int          SB_CPL_VALID = 5,             // STATUS bit: a record is waiting
  parameter logic [11:0] R_CPL0       = 12'h040,       // first of the 6 record words
  parameter logic [11:0] R_CPL_POP    = 12'h058,
  parameter int          ERR_LSB      = 8,             // record word 0: error field [ERR_LSB +: ERR_W] != 0
  parameter int          ERR_W        = 4,
  parameter int          INIT_EN      = 1,             // write INIT_DATA to R_INIT after every engine reset
  parameter logic [11:0] R_INIT       = 12'h024,
  parameter logic [31:0] INIT_DATA    = 32'h0000_0000,
  parameter logic [11:0] R_SRST       = 12'h020,       // host write with (wdata & SRST_MASK) != 0 refused when streaming
  parameter logic [31:0] SRST_MASK    = 32'h0000_0001,
  parameter int          TRK_DEPTH    = 16,            // tracked commands (power of two, 2..256)
  parameter int          STREAM_DEFAULT = 1,           // reset value of the stream mode (init after power-up)
  parameter logic [7:0]  CLUSTER_ID   = 8'd0,
  parameter logic [3:0]  ENGINE       = 4'd1,
  localparam int         TLW          = $clog2(TRK_DEPTH + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- control (sfx_cl_ctrl)
  input  wire logic             stream_en,
  input  wire logic             quiesce,        // reset sequence: start no doorbell / harvest
  input  wire logic             eng_in_reset,   // engine reset asserted
  output logic                  safe,           // no harvest in progress (ctrl may reset the engine)
  output logic                  idle,           // nothing tracked / buffered / pending
  output logic [TLW-1:0]        trk_level,
  // ---------------------------------------------------------- command stream (cluster boundary)
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [31:0]      cmd_data,
  input  wire logic             cmd_last,
  input  wire logic [TAG_W-1:0] cmd_tag,        // sampled with the first word
  // ---------------------------------------------------------- completion stream (cluster boundary)
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [31:0]           cpl_data,
  output logic                  cpl_last,
  output logic [TAG_W-1:0]      cpl_tag,
  output logic                  cpl_err,
  // ---------------------------------------------------------- host access to the engine page (rb contract)
  input  wire logic             h_sel,
  input  wire logic             h_we,
  input  wire logic [11:0]      h_addr,
  input  wire logic [31:0]      h_wdata,
  output logic [31:0]           h_rdata,
  output logic                  h_err,
  // ---------------------------------------------------------- engine register page (rb master)
  output logic                  e_sel,
  output logic                  e_we,
  output logic [11:0]           e_addr,
  output logic [31:0]           e_wdata,
  input  wire logic [31:0]      e_rdata,
  input  wire logic             e_err,
  // ---------------------------------------------------------- events (one cycle)
  output logic                  ev_cmd_accept,
  output logic                  ev_submit,
  output logic                  ev_db_retry,
  output logic                  ev_cpl_deliver,
  output logic                  ev_cpl_err,
  output logic                  ev_bad_cmd,
  output logic                  ev_abort_cpl,
  output logic                  ev_host_deny,
  output logic                  ev_pop_err
);
  // ============================================================ configuration checks
  if (CMD_WORDS < 1 || CMD_WORDS > 64) begin : g_err_cw
    `SFX_CL_CFG_FATAL("sfx_cl_cmd_port: CMD_WORDS must be 1..64")
  end
  if (TRK_DEPTH < 2 || TRK_DEPTH > 256 || (TRK_DEPTH & (TRK_DEPTH - 1)) != 0) begin : g_err_td
    `SFX_CL_CFG_FATAL("sfx_cl_cmd_port: TRK_DEPTH must be a power of two 2..256")
  end
  if (TAG_W < 1 || TAG_W > 32) begin : g_err_tw
    `SFX_CL_CFG_FATAL("sfx_cl_cmd_port: TAG_W must be 1..32")
  end

  localparam int NCW = `SFX_CL_ENG_CPL_WORDS;          // engine record words
  localparam int TPW = $clog2(TRK_DEPTH);
  localparam int IXW = $clog2(CMD_WORDS + 1);

  // ============================================================ input skid buffer (registered boundary)
  logic             s_v, s_r, s_last;
  logic [31:0]      s_data;
  logic [TAG_W-1:0] s_tag;
  sfb_skid_buffer #(.WIDTH(33 + TAG_W)) u_cmd_skid (
    .clk, .rst_n,
    .s_valid(cmd_valid), .s_ready(cmd_ready), .s_data({cmd_last, cmd_tag, cmd_data}),
    .m_valid(s_v), .m_ready(s_r), .m_data({s_last, s_tag, s_data})
  );

  // ============================================================ tracking FIFO {tag, CL_STATUS}
  logic [TAG_W-1:0] trk_tag  [TRK_DEPTH];
  logic [3:0]       trk_kind [TRK_DEPTH];
  logic [TPW:0]     trk_wp, trk_rp;
  logic             trk_push, trk_pop;
  logic [TAG_W-1:0] trk_push_tag;
  logic [3:0]       trk_push_kind;
  wire  [TPW:0]     trk_cnt   = trk_wp - trk_rp;
  wire              trk_empty = (trk_cnt == '0);
  wire              trk_space = (trk_cnt != (TPW+1)'(TRK_DEPTH));
  wire [TPW-1:0]    trk_head  = trk_rp[TPW-1:0];
  assign trk_level = TLW'(trk_cnt);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      trk_wp <= '0;
      trk_rp <= '0;
    end else begin
      if (trk_push) trk_wp <= trk_wp + 1'b1;
      if (trk_pop)  trk_rp <= trk_rp + 1'b1;
    end
  end
  // storage: written on push; while the engine is in reset every ENGINE entry becomes RESET_ABORT
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < TRK_DEPTH; i++) begin
        trk_tag[i]  <= '0;
        trk_kind[i] <= `SFX_CL_ST_ENGINE;
      end
    end else begin
      if (eng_in_reset) begin
        for (int i = 0; i < TRK_DEPTH; i++)
          if (trk_kind[i] == `SFX_CL_ST_ENGINE) trk_kind[i] <= `SFX_CL_ST_RESET_ABORT;
      end
      if (trk_push) begin
        trk_tag[trk_wp[TPW-1:0]]  <= trk_push_tag;
        trk_kind[trk_wp[TPW-1:0]] <= trk_push_kind;
      end
    end
  end

  // ============================================================ register-bus arbitration
  // host CSR access has absolute priority (rb has no wait state); the adapter's
  // three requesters: init write > {command side, completion side} in round robin
  logic r_cmd, r_cpl, r_init, g_cmd, g_cpl, g_init, prio_cpl;
  logic [11:0] a_cmd_addr, a_cpl_addr;
  logic [31:0] a_cmd_wdata;
  logic        a_cpl_we;

  // host ownership rule
  wire h_in_cmd = (h_addr >= R_CMD0) && (h_addr < R_CMD0 + 12'(4 * CMD_WORDS));
  wire h_owned  = h_we && (h_in_cmd || h_addr == R_DOORBELL || h_addr == R_CPL_POP ||
                           (h_addr == R_SRST && (h_wdata & SRST_MASK) != 32'd0));
  wire h_deny   = h_sel && (eng_in_reset || (stream_en && h_owned));
  wire h_pass   = h_sel && !h_deny;

  always_comb begin
    g_init = 1'b0; g_cmd = 1'b0; g_cpl = 1'b0;
    if (!h_sel && !eng_in_reset) begin
      if (r_init)              g_init = 1'b1;
      else if (r_cmd && r_cpl) begin g_cpl = prio_cpl; g_cmd = !prio_cpl; end
      else if (r_cmd)          g_cmd = 1'b1;
      else if (r_cpl)          g_cpl = 1'b1;
    end
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)              prio_cpl <= 1'b0;
    else if (r_cmd && r_cpl && (g_cmd || g_cpl)) prio_cpl <= !prio_cpl;
  end

  always_comb begin
    e_sel = 1'b0; e_we = 1'b0; e_addr = '0; e_wdata = '0;
    if (h_pass) begin
      e_sel = 1'b1; e_we = h_we; e_addr = h_addr; e_wdata = h_wdata;
    end else if (g_init) begin
      e_sel = 1'b1; e_we = 1'b1; e_addr = R_INIT; e_wdata = INIT_DATA;
    end else if (g_cmd) begin
      e_sel = 1'b1; e_we = 1'b1; e_addr = a_cmd_addr; e_wdata = a_cmd_wdata;
    end else if (g_cpl) begin
      e_sel = 1'b1; e_we = a_cpl_we; e_addr = a_cpl_addr; e_wdata = '0;
    end
  end
  assign h_rdata      = h_pass ? e_rdata : 32'd0;
  assign h_err        = h_deny ? 1'b1 : (h_sel ? e_err : 1'b0);
  assign ev_host_deny = h_deny && h_we;

  // ============================================================ init after reset / stream enable
  logic init_pend, eir_q, sen_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      init_pend <= (INIT_EN != 0) && (STREAM_DEFAULT != 0);
      eir_q     <= 1'b0;
      sen_q     <= (STREAM_DEFAULT != 0);
    end else begin
      eir_q <= eng_in_reset;
      sen_q <= stream_en;
      if (INIT_EN != 0 && stream_en && ((eir_q && !eng_in_reset) || (!sen_q && stream_en))) init_pend <= 1'b1;
      else if (g_init || !stream_en)                                                       init_pend <= 1'b0;
    end
  end
  assign r_init = init_pend && !eng_in_reset;

  // ============================================================ command packet FSM
  logic             p_act;          // inside a packet (first word consumed, last not yet)
  logic [IXW-1:0]   p_idx;          // words consumed (saturates at CMD_WORDS)
  logic [TAG_W-1:0] p_tag;
  logic [3:0]       p_kind;         // ENGINE (normal) or the shell status it will complete with
  logic             db_pend;        // all words staged; doorbell outstanding
  logic             push_pend;      // shell record waiting for a tracking slot

  wire first_w   = !p_act;
  wire [IXW-1:0] w_idx = first_w ? '0 : p_idx;
  wire [3:0] w_kind = first_w ? (stream_en ? `SFX_CL_ST_ENGINE : `SFX_CL_ST_STREAM_OFF)
                              : ((eng_in_reset && p_kind == `SFX_CL_ST_ENGINE) ? `SFX_CL_ST_RESET_ABORT : p_kind);
  wire w_over    = (w_idx >= IXW'(CMD_WORDS));                 // packet longer than the descriptor
  wire w_stage   = (w_kind == `SFX_CL_ST_ENGINE) && !w_over;   // this word goes to a staging register
  // a new packet waits while the reset sequence runs or the init write is pending (stream mode)
  wire start_ok  = !stream_en || (!quiesce && !eng_in_reset && !init_pend);
  wire can_take  = !db_pend && !push_pend && (p_act || start_ok);

  assign r_cmd       = (s_v && can_take && w_stage) ||
                       (db_pend && !quiesce && !eng_in_reset && !init_pend && trk_space);
  assign a_cmd_addr  = db_pend ? R_DOORBELL : (R_CMD0 + 12'({w_idx, 2'b00}));
  assign a_cmd_wdata = db_pend ? 32'd1 : s_data;

  // a word is consumed when staged (granted) or discarded
  assign s_r = can_take && (w_stage ? (g_cmd && !db_pend) : 1'b1);
  wire take  = s_v && s_r;

  wire db_ok   = db_pend && g_cmd && !e_err;
  wire db_fail = db_pend && g_cmd &&  e_err;
  assign ev_db_retry = db_fail;
  assign ev_submit   = db_ok;

  // kind recorded at the last word
  wire [3:0] last_kind = (w_kind != `SFX_CL_ST_ENGINE) ? w_kind :
                         (w_over || w_idx != IXW'(CMD_WORDS - 1)) ? `SFX_CL_ST_BAD_LENGTH : `SFX_CL_ST_ENGINE;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      p_act <= 1'b0; p_idx <= '0; p_tag <= '0; p_kind <= `SFX_CL_ST_ENGINE;
      db_pend <= 1'b0; push_pend <= 1'b0;
    end else begin
      if (take) begin
        if (first_w) p_tag <= s_tag;
        if (s_last) begin
          p_act  <= 1'b0;
          p_idx  <= '0;
          p_kind <= last_kind;
          if (last_kind == `SFX_CL_ST_ENGINE) db_pend   <= 1'b1;
          else                                push_pend <= 1'b1;
        end else begin
          p_act  <= 1'b1;
          p_idx  <= w_over ? w_idx : w_idx + 1'b1;
          p_kind <= (w_over && w_kind == `SFX_CL_ST_ENGINE) ? `SFX_CL_ST_BAD_LENGTH : w_kind;
        end
      end else if (p_act && eng_in_reset && p_kind == `SFX_CL_ST_ENGINE) begin
        p_kind <= `SFX_CL_ST_RESET_ABORT;          // staging registers are gone: the rest is discarded
      end
      if (db_pend) begin
        if (eng_in_reset) begin                    // destroyed before submission
          db_pend   <= 1'b0;
          push_pend <= 1'b1;
          p_kind    <= `SFX_CL_ST_RESET_ABORT;
        end else if (db_ok) begin
          db_pend <= 1'b0;
        end
      end
      if (push_pend && trk_space) push_pend <= 1'b0;   // never together with db_pend (exclusive states)
    end
  end
  // the tracking FIFO takes at most one push per cycle (doorbell success or a shell record)
  assign trk_push      = db_ok || (push_pend && trk_space);
  assign trk_push_tag  = p_tag;
  assign trk_push_kind = db_ok ? `SFX_CL_ST_ENGINE : p_kind;

  assign ev_cmd_accept = take && s_last;
  assign ev_bad_cmd    = push_pend && trk_space &&
                         (p_kind == `SFX_CL_ST_BAD_LENGTH || p_kind == `SFX_CL_ST_STREAM_OFF);

  // ============================================================ completion harvest FSM
  localparam logic [1:0] HV_IDLE = 2'd0, HV_READ = 2'd1, HV_POP = 2'd2;
  logic [1:0]      hv;
  logic [2:0]      hv_i;
  logic            b_v;
  logic [2:0]      b_idx;
  logic [31:0]     b_w [`SFX_CL_CPL_WORDS];
  logic [TAG_W-1:0] b_tag;
  logic            b_err;

  wire [3:0] head_kind = trk_kind[trk_head];
  wire head_eng  = !trk_empty && head_kind == `SFX_CL_ST_ENGINE;
  wire head_syn  = !trk_empty && head_kind != `SFX_CL_ST_ENGINE;
  wire poll_req  = (hv == HV_IDLE) && !b_v && head_eng && !quiesce && !eng_in_reset && !init_pend;
  assign r_cpl      = poll_req || (hv == HV_READ) || (hv == HV_POP);
  assign a_cpl_we   = (hv == HV_POP);
  assign a_cpl_addr = (hv == HV_POP)  ? R_CPL_POP :
                      (hv == HV_READ) ? (R_CPL0 + {7'd0, hv_i, 2'b00}) : R_STATUS;

  wire poll_hit = poll_req && g_cpl && e_rdata[SB_CPL_VALID];
  wire pop_done = (hv == HV_POP) && g_cpl;
  wire syn_load = (hv == HV_IDLE) && !b_v && head_syn;
  assign trk_pop = pop_done || syn_load;
  assign ev_pop_err   = pop_done && e_err;
  assign ev_abort_cpl = syn_load && head_kind == `SFX_CL_ST_RESET_ABORT;
  assign safe = (hv == HV_IDLE);

  function automatic logic [31:0] header(input logic [3:0] st, input logic e);
    header = '0;
    header[`SFX_CL_H_STATUS_LSB +: 4]  = st;
    header[`SFX_CL_H_ERR_BIT]          = e;
    header[`SFX_CL_H_ENGINE_LSB +: 4]  = ENGINE;
    header[`SFX_CL_H_NWORDS_LSB +: 4]  = 4'(NCW);
    header[`SFX_CL_H_CLUSTER_LSB +: 8] = CLUSTER_ID;
    header[`SFX_CL_H_ABI_LSB +: 8]     = `SFX_CL_ABI_VERSION;
  endfunction

  wire eng_err = (b_w[1][ERR_LSB +: ERR_W] != '0);
  wire cpl_hs  = b_v && cpl_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hv <= HV_IDLE; hv_i <= '0;
      b_v <= 1'b0; b_idx <= '0; b_tag <= '0; b_err <= 1'b0;
      for (int i = 0; i < `SFX_CL_CPL_WORDS; i++) b_w[i] <= '0;
    end else begin
      case (hv)
        HV_IDLE: if (poll_hit) begin hv <= HV_READ; hv_i <= '0; end
        HV_READ: if (g_cpl) begin
                   b_w[hv_i + 3'd1] <= e_rdata;
                   if (hv_i == 3'(NCW - 1)) hv <= HV_POP;
                   else                     hv_i <= hv_i + 3'd1;
                 end
        HV_POP:  if (g_cpl) hv <= HV_IDLE;
        default: hv <= HV_IDLE;
      endcase
      if (pop_done) begin
        b_v   <= 1'b1;
        b_idx <= '0;
        b_tag <= trk_tag[trk_head];
        b_err <= eng_err;
        b_w[0] <= header(`SFX_CL_ST_ENGINE, eng_err);
      end else if (syn_load) begin
        b_v   <= 1'b1;
        b_idx <= '0;
        b_tag <= trk_tag[trk_head];
        b_err <= 1'b1;
        b_w[0] <= header(head_kind, 1'b1);
        for (int i = 1; i < `SFX_CL_CPL_WORDS; i++) b_w[i] <= '0;
      end else if (cpl_hs) begin
        if (b_idx == 3'(`SFX_CL_CPL_WORDS - 1)) begin
          b_v   <= 1'b0;
          b_idx <= '0;
        end else begin
          b_idx <= b_idx + 3'd1;
        end
      end
    end
  end

  assign cpl_valid = b_v;
  assign cpl_data  = b_w[b_idx];
  assign cpl_last  = (b_idx == 3'(`SFX_CL_CPL_WORDS - 1));
  assign cpl_tag   = b_tag;
  assign cpl_err   = b_err;
  assign ev_cpl_deliver = cpl_hs && cpl_last;
  assign ev_cpl_err     = cpl_hs && cpl_last && b_err;

  assign idle = !s_v && !p_act && !db_pend && !push_pend && trk_empty && !b_v && (hv == HV_IDLE) && !init_pend;
endmodule

`default_nettype wire
