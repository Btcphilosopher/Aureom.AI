// =============================================================================
// SilicaFlux-HPC Project 32 :: sfx_cl_slv_gate
// Reset gate of a cluster's SFB2 *slave* port (the vector tile's host
// scratchpad window, hs_*).  Aureom.AI | SilicaFlux-HPC
//
//   x_* (NoC / host master)  ──►  [gate]  ──►  t_* (engine slave port)
//
// * q_req: new requests wait (x_req_ready = 0) unless one is already presented
//   to the engine (hold_q, SFB2 R2), so the port drains before an engine reset.
// * force_err (pulse, drain timeout): the engine is reset with transactions still
//   outstanding.  A response the engine is presenting at that moment (held by a
//   slow master) is captured and kept on the port unchanged until accepted
//   (SFB2 R4: a held response never changes); every access the engine accepted
//   but has not answered yet is then answered by the gate itself with
//   rsp_error = 1, rdata = 0 (R5: exactly one response per accepted request,
//   R8: error responses carry zero data).
// * eng_in_reset: no request reaches the engine while it is held in reset (a
//   request presented to it before is withdrawn there only; the external
//   master still sees it un-accepted, so the NoC side stays R2-clean).
// * MAX_OUT bounds the transactions accepted by the engine and not yet answered.
// Shell (system-reset) domain.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cl_defs.svh"
`default_nettype none

module sfx_cl_slv_gate #(
  parameter int  DW      = 32,
  parameter int  MAX_OUT = 4,
  localparam int SB      = DW / 8,
  localparam int OW      = $clog2(MAX_OUT + 1)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          q_req,
  input  wire logic          force_err,
  input  wire logic          eng_in_reset,   // engine reset asserted: nothing reaches it
  output logic               quiet,
  output logic [OW-1:0]      outstanding,
  // ---------------------------------------------------------- external master side
  input  wire logic          x_req_valid,
  output logic               x_req_ready,
  input  wire logic          x_req_write,
  input  wire logic [31:0]   x_req_addr,
  input  wire logic [DW-1:0] x_req_wdata,
  input  wire logic [SB-1:0] x_req_wstrb,
  output logic               x_rsp_valid,
  input  wire logic          x_rsp_ready,
  output logic [DW-1:0]      x_rsp_rdata,
  output logic               x_rsp_error,
  // ---------------------------------------------------------- engine side
  output logic               t_req_valid,
  input  wire logic          t_req_ready,
  output logic               t_req_write,
  output logic [31:0]        t_req_addr,
  output logic [DW-1:0]      t_req_wdata,
  output logic [SB-1:0]      t_req_wstrb,
  input  wire logic          t_rsp_valid,
  output logic               t_rsp_ready,
  input  wire logic [DW-1:0] t_rsp_rdata,
  input  wire logic          t_rsp_error,
  output logic               ev_req
);
  if (MAX_OUT < 1 || MAX_OUT > 64) begin : g_err_mo
    `SFX_CL_CFG_FATAL("sfx_cl_slv_gate: MAX_OUT must be 1..64")
  end

  logic          hold_q, cap_v, cap_e;
  logic [DW-1:0] cap_d;
  logic [OW-1:0] out_cnt, owe_cnt;
  wire owing = (owe_cnt != '0);
  wire blk   = q_req || owing || cap_v || (out_cnt == OW'(MAX_OUT));
  wire block = (blk && !hold_q) || eng_in_reset;

  assign t_req_valid = x_req_valid && !block;
  assign x_req_ready = t_req_ready && !block;
  assign t_req_write = x_req_write;
  assign t_req_addr  = x_req_addr;
  assign t_req_wdata = x_req_wdata;
  assign t_req_wstrb = x_req_wstrb;

  // response order after a forced reset: the captured (oldest) response, then the owed error responses
  assign x_rsp_valid = cap_v ? 1'b1  : owing ? 1'b1 : t_rsp_valid;
  assign x_rsp_rdata = cap_v ? cap_d : owing ? '0   : t_rsp_rdata;
  assign x_rsp_error = cap_v ? cap_e : owing ? 1'b1 : t_rsp_error;
  assign t_rsp_ready = (cap_v || owing) ? 1'b1 : x_rsp_ready;   // engine in reset meanwhile: nothing to absorb

  wire req_hs = t_req_valid && t_req_ready;
  wire rsp_hs = x_rsp_valid && x_rsp_ready;
  // the engine presents a response the master has not accepted when the reset is forced: keep it
  wire cap_now = force_err && !cap_v && !owing && t_rsp_valid && !x_rsp_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      hold_q  <= 1'b0;
      out_cnt <= '0;
      owe_cnt <= '0;
      cap_v   <= 1'b0;
    end else begin
      hold_q  <= t_req_valid && !t_req_ready;
      out_cnt <= out_cnt + OW'(req_hs) - OW'(rsp_hs);
      if (force_err)                     owe_cnt <= out_cnt + OW'(req_hs) - OW'(rsp_hs) - OW'(cap_now);
      else if (owing && !cap_v && rsp_hs) owe_cnt <= owe_cnt - 1'b1;
      if (cap_now)                       cap_v <= 1'b1;
      else if (cap_v && rsp_hs)          cap_v <= 1'b0;
    end
  end
  always_ff @(posedge clk) begin
    if (cap_now) begin
      cap_d <= t_rsp_rdata;
      cap_e <= t_rsp_error;
    end
  end

  assign quiet       = !hold_q && (out_cnt == '0) && !owing && !cap_v;
  assign outstanding = out_cnt;
  assign ev_req      = req_hs;
endmodule

`default_nettype wire
