// =============================================================================
// SilicaFlux-HPC Project 32 :: silicaflux_vector_cluster
// One floorplan-friendly FP32 vector compute region.  Aureom.AI | SilicaFlux-HPC
//
// The validated HPC Module 08 tile (silicaflux_hpc_tile: Module 03 vector array
// of Module 02 lanes, Module 04 banked scratchpad, Module 05 DMA adapter,
// scheduler, queues, counters) is instantiated UNMODIFIED as u_engine.  The
// cluster adds only a shell around it:
//
//            cluster boundary (registered command / completion / status)
//   cmd ─► u_cmd (sfx_cl_cmd_port) ─rb─► ┌──────────────── u_engine ───────────────┐
//   cpl ◄─                               │ g_core.u_array  (vector lanes)          │
//   csr ─► [12]=0 engine page / [12]=1 u_ctrl page      g_core.u_lsu            │
//                                        │ g_core.u_spm    (scratchpad banks)      │
//   spm_* (NoC slave) ─► u_spm_gate ─hs─►│ g_core.g_host.u_hs                      │
//                                        │ g_core.u_dma ─fab─┐  g_core.u_sched ... │
//                                        └───────────────────┼─────────────────────┘
//   mem_* (NoC master) ◄─ u_mem (sfx_cl_mem_port) ◄──────────┘
//   lm_*  (local memory master, LOCAL_MEM_EN) ◄─┘
//   u_ctrl (sfx_cl_ctrl): reset sequencer, errors, irq, clk_req, perf events
//
// Physical intent (docs/05_PHYSICAL.md): the lanes (u_array) sit next to the
// scratchpad banks (u_spm) and the LSU; the DMA adapter and u_mem face the NoC
// edge; u_cmd / u_ctrl are small and face the control edge.  Locality is
// expressed by this hierarchy and by constraints/*.tcl, never by coordinates here.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cl_defs.svh"
`include "sram_defs.svh"
`include "hpc_spm_defs.svh"
`include "hpc_tile_defs.svh"
`default_nettype none

module silicaflux_vector_cluster #(
  parameter logic [7:0]  CLUSTER_ID       = 8'd0,
  // ------------------------------------------------------------ engine (HPC Module 08 tile)
  parameter int          NUM_LANES        = 4,
  parameter int          XACT_WIDTH       = 32,            // SFB2 data width of every port (tile DATA_WIDTH)
  parameter int          SCRATCHPAD_BYTES = 65536,
  parameter int          NUM_BANKS        = 4,
  parameter int          CMD_QUEUE_DEPTH  = 8,
  parameter int          CPL_QUEUE_DEPTH  = 8,
  parameter int          DMA_BUFFER_DEPTH = 0,
  parameter int          ENABLE_PERF_COUNTERS = 1,
  parameter logic [31:0] SPM_BASE         = 32'h2000_0000,
  parameter int          SPM_BACKEND      = `SRAM_BACKEND_GENERIC,
  parameter int          SPM_MACRO        = 0,
  // ------------------------------------------------------------ cluster shell
  parameter int          SPM_PORT_EN      = 1,             // scratchpad window as an SFB2 slave port (tile HOST_SPM_PORT)
  parameter int          LOCAL_MEM_EN     = 0,             // local memory master port for the LM window
  parameter logic [31:0] LOCAL_MEM_BASE   = 32'h3000_0000,
  parameter logic [31:0] LOCAL_MEM_MASK   = 32'hFFFF_0000,
  parameter int          MEM_REQ_SLICE    = 0,             // +1 cycle request latency on the memory ports
  parameter int          MEM_RSP_SLICE    = 0,             // +1 cycle response latency on the memory ports
  parameter int          MEM_MAX_OUT      = 4,
  parameter int          SPM_MAX_OUT      = 2,
  parameter int          TAG_W            = 8,
  parameter int          TRK_DEPTH        = 16,
  parameter int          STREAM_DEFAULT   = 1,
  parameter int          RST_CYCLES       = 4,
  parameter int          DRAIN_LOG2       = 12,
  parameter int          IDLE_HYST        = 16,
  // ------------------------------------------------------------ derived
  localparam int DW  = XACT_WIDTH,
  localparam int SB  = DW / 8,
  localparam int TLW = $clog2(TRK_DEPTH + 1),
  localparam int MOW = $clog2(MEM_MAX_OUT + 1),
  localparam int SOW = $clog2(SPM_MAX_OUT + 1)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,             // system reset (asynchronous assert, synchronous release)
  input  wire logic             rst_req,           // cluster reset request (level; sequenced)
  // ---------------------------------------------------------- command / completion streams
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [31:0]      cmd_data,
  input  wire logic             cmd_last,
  input  wire logic [TAG_W-1:0] cmd_tag,
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [31:0]           cpl_data,
  output logic                  cpl_last,
  output logic [TAG_W-1:0]      cpl_tag,
  output logic                  cpl_err,
  // ---------------------------------------------------------- CSR (rb contract, 8 KiB: engine page + cluster page)
  input  wire logic             csr_sel,
  input  wire logic             csr_we,
  input  wire logic [12:0]      csr_addr,
  input  wire logic [31:0]      csr_wdata,
  output logic [31:0]           csr_rdata,
  output logic                  csr_err,
  // ---------------------------------------------------------- NoC memory master (SFB2)
  output logic                  mem_req_valid,
  input  wire logic             mem_req_ready,
  output logic                  mem_req_write,
  output logic [31:0]           mem_req_addr,
  output logic [DW-1:0]         mem_req_wdata,
  output logic [SB-1:0]         mem_req_wstrb,
  input  wire logic             mem_rsp_valid,
  output logic                  mem_rsp_ready,
  input  wire logic [DW-1:0]    mem_rsp_rdata,
  input  wire logic             mem_rsp_error,
  // ---------------------------------------------------------- local memory master (SFB2, LOCAL_MEM_EN)
  output logic                  lm_req_valid,
  input  wire logic             lm_req_ready,
  output logic                  lm_req_write,
  output logic [31:0]           lm_req_addr,
  output logic [DW-1:0]         lm_req_wdata,
  output logic [SB-1:0]         lm_req_wstrb,
  input  wire logic             lm_rsp_valid,
  output logic                  lm_rsp_ready,
  input  wire logic [DW-1:0]    lm_rsp_rdata,
  input  wire logic             lm_rsp_error,
  // ---------------------------------------------------------- scratchpad window (SFB2 slave, SPM_PORT_EN)
  input  wire logic             spm_req_valid,
  output logic                  spm_req_ready,
  input  wire logic             spm_req_write,
  input  wire logic [31:0]      spm_req_addr,
  input  wire logic [DW-1:0]    spm_req_wdata,
  input  wire logic [SB-1:0]    spm_req_wstrb,
  output logic                  spm_rsp_valid,
  input  wire logic             spm_rsp_ready,
  output logic [DW-1:0]         spm_rsp_rdata,
  output logic                  spm_rsp_error,
  // ---------------------------------------------------------- interrupt / error / status / events (registered)
  output logic                  irq,
  output logic                  err,
  output logic [`SFX_CL_ERR_W-1:0] err_status,
  output logic                  busy,
  output logic                  clk_req,
  output logic [`SFX_CL_PEV_W-1:0] perf_ev
);
  if (SPM_PORT_EN != 0 && SPM_PORT_EN != 1) begin : g_err_sp
    `SFX_CL_CFG_FATAL("silicaflux_vector_cluster: SPM_PORT_EN must be 0 or 1")
  end

  localparam logic [31:0] INFO = {8'(XACT_WIDTH / 8), 4'd0, 1'(MEM_RSP_SLICE != 0), 1'(MEM_REQ_SLICE != 0),
                                  1'(SPM_PORT_EN != 0), 1'(LOCAL_MEM_EN != 0), 4'(`SFX_CL_ABI_VERSION),
                                  `SFX_CL_ENG_VECTOR, CLUSTER_ID};

  // ============================================================ control signals
  logic stream_en, quiesce, port_q, force_drop, eng_in_reset, eng_rst_n;
  logic ad_safe, ad_idle;
  logic [TLW-1:0] trk_level;
  logic m_quiet, m_draining, s_quiet;
  logic [MOW-1:0] m_out;
  logic [SOW-1:0] s_out;
  logic e_busy, e_halted, e_irq;

  // ============================================================ CSR split: engine page / cluster page
  wire h_sel = csr_sel && !csr_addr[12];
  wire c_sel = csr_sel &&  csr_addr[12];
  logic [31:0] h_rdata, c_rdata;
  logic        h_err, c_err;
  assign csr_rdata = csr_addr[12] ? c_rdata : h_rdata;
  assign csr_err   = csr_addr[12] ? c_err   : h_err;

  // ============================================================ command / completion adapter
  logic        e_sel, e_we, e_err;
  logic [11:0] e_addr;
  logic [31:0] e_wdata, e_rdata;
  logic ev_cmd_accept, ev_submit, ev_db_retry, ev_cpl_deliver, ev_cpl_err, ev_bad_cmd, ev_abort_cpl,
        ev_host_deny, ev_pop_err;

  sfx_cl_cmd_port #(
    .TAG_W(TAG_W), .CMD_WORDS(8), .R_CMD0(`HPC_REG_CMD0), .R_DOORBELL(`HPC_REG_DOORBELL),
    .R_STATUS(`HPC_REG_STATUS), .SB_CPL_VALID(5), .R_CPL0(`HPC_REG_CPL_INFO), .R_CPL_POP(`HPC_REG_CPL_POP),
    .ERR_LSB(`HPC_CPL_STATUS_LSB), .ERR_W(4),
    .INIT_EN(1), .R_INIT(`HPC_REG_CFG), .INIT_DATA(32'h0000_0000),        // HALT_ON_ERROR = 0: commands independent
    .R_SRST(`HPC_REG_CTRL), .SRST_MASK(32'h0000_0001),                    // SOFT_RESET would destroy records
    .TRK_DEPTH(TRK_DEPTH), .STREAM_DEFAULT(STREAM_DEFAULT), .CLUSTER_ID(CLUSTER_ID), .ENGINE(`SFX_CL_ENG_VECTOR)
  ) u_cmd (
    .clk, .rst_n,
    .stream_en, .quiesce, .eng_in_reset, .safe(ad_safe), .idle(ad_idle), .trk_level,
    .cmd_valid, .cmd_ready, .cmd_data, .cmd_last, .cmd_tag,
    .cpl_valid, .cpl_ready, .cpl_data, .cpl_last, .cpl_tag, .cpl_err,
    .h_sel, .h_we(csr_we), .h_addr(csr_addr[11:0]), .h_wdata(csr_wdata), .h_rdata, .h_err,
    .e_sel, .e_we, .e_addr, .e_wdata, .e_rdata, .e_err,
    .ev_cmd_accept, .ev_submit, .ev_db_retry, .ev_cpl_deliver, .ev_cpl_err, .ev_bad_cmd, .ev_abort_cpl,
    .ev_host_deny, .ev_pop_err
  );

  // ============================================================ engine: HPC Module 08 tile, unmodified
  logic          f_req_valid, f_req_ready, f_req_write, f_rsp_valid, f_rsp_ready, f_rsp_error;
  logic [31:0]   f_req_addr;
  logic [DW-1:0] f_req_wdata, f_rsp_rdata;
  logic [SB-1:0] f_req_wstrb;
  logic          t_req_valid, t_req_ready, t_req_write, t_rsp_valid, t_rsp_ready, t_rsp_error;
  logic [31:0]   t_req_addr;
  logic [DW-1:0] t_req_wdata, t_rsp_rdata;
  logic [SB-1:0] t_req_wstrb;

  silicaflux_hpc_tile #(
    .NUM_LANES(NUM_LANES), .DATA_WIDTH(XACT_WIDTH), .SCRATCHPAD_BYTES(SCRATCHPAD_BYTES), .NUM_BANKS(NUM_BANKS),
    .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .DMA_BUFFER_DEPTH(DMA_BUFFER_DEPTH), .ENABLE_PERF_COUNTERS(ENABLE_PERF_COUNTERS),
    .SPM_BASE(SPM_BASE), .CPL_QUEUE_DEPTH(CPL_QUEUE_DEPTH), .HOST_SPM_PORT(SPM_PORT_EN),
    .SPM_BACKEND(SPM_BACKEND), .SPM_MACRO(SPM_MACRO)
  ) u_engine (
    .clk, .rst_n(eng_rst_n),
    .rb_sel(e_sel), .rb_we(e_we), .rb_addr(e_addr), .rb_wdata(e_wdata), .rb_rdata(e_rdata), .rb_err(e_err),
    .hs_req_valid(t_req_valid), .hs_req_ready(t_req_ready), .hs_req_write(t_req_write), .hs_req_addr(t_req_addr),
    .hs_req_wdata(t_req_wdata), .hs_req_wstrb(t_req_wstrb),
    .hs_rsp_valid(t_rsp_valid), .hs_rsp_ready(t_rsp_ready), .hs_rsp_rdata(t_rsp_rdata), .hs_rsp_error(t_rsp_error),
    .fab_req_valid(f_req_valid), .fab_req_ready(f_req_ready), .fab_req_write(f_req_write), .fab_req_addr(f_req_addr),
    .fab_req_wdata(f_req_wdata), .fab_req_wstrb(f_req_wstrb),
    .fab_rsp_valid(f_rsp_valid), .fab_rsp_ready(f_rsp_ready), .fab_rsp_rdata(f_rsp_rdata), .fab_rsp_error(f_rsp_error),
    .irq(e_irq), .busy(e_busy), .halted(e_halted)
  );

  // ============================================================ memory boundary (NoC-facing)
  logic ev_mem_req, ev_mem_stall, ev_lm_req, ev_mem_rsp, ev_mem_rsp_err, ev_unsol, ev_spm_req;

  sfx_cl_mem_port #(
    .EW(DW), .DW(DW), .MAX_OUT(MEM_MAX_OUT), .LOCAL_EN(LOCAL_MEM_EN), .LM_BASE(LOCAL_MEM_BASE),
    .LM_MASK(LOCAL_MEM_MASK), .REQ_SLICE(MEM_REQ_SLICE), .RSP_SLICE(MEM_RSP_SLICE)
  ) u_mem (
    .clk, .rst_n,
    .q_req(port_q), .force_drop, .quiet(m_quiet), .draining(m_draining), .outstanding(m_out),
    .e_req_valid(f_req_valid), .e_req_ready(f_req_ready), .e_req_write(f_req_write), .e_req_addr(f_req_addr),
    .e_req_wdata(f_req_wdata), .e_req_wstrb(f_req_wstrb),
    .e_rsp_valid(f_rsp_valid), .e_rsp_ready(f_rsp_ready), .e_rsp_rdata(f_rsp_rdata), .e_rsp_error(f_rsp_error),
    .n_req_valid(mem_req_valid), .n_req_ready(mem_req_ready), .n_req_write(mem_req_write), .n_req_addr(mem_req_addr),
    .n_req_wdata(mem_req_wdata), .n_req_wstrb(mem_req_wstrb),
    .n_rsp_valid(mem_rsp_valid), .n_rsp_ready(mem_rsp_ready), .n_rsp_rdata(mem_rsp_rdata), .n_rsp_error(mem_rsp_error),
    .l_req_valid(lm_req_valid), .l_req_ready(lm_req_ready), .l_req_write(lm_req_write), .l_req_addr(lm_req_addr),
    .l_req_wdata(lm_req_wdata), .l_req_wstrb(lm_req_wstrb),
    .l_rsp_valid(lm_rsp_valid), .l_rsp_ready(lm_rsp_ready), .l_rsp_rdata(lm_rsp_rdata), .l_rsp_error(lm_rsp_error),
    .ev_noc_req(ev_mem_req), .ev_noc_stall(ev_mem_stall), .ev_lm_req, .ev_rsp(ev_mem_rsp), .ev_rsp_err(ev_mem_rsp_err),
    .ev_unsol
  );

  // ============================================================ scratchpad window (NoC slave)
  if (SPM_PORT_EN != 0) begin : g_spm
    sfx_cl_slv_gate #(.DW(DW), .MAX_OUT(SPM_MAX_OUT)) u_spm_gate (
      .clk, .rst_n, .q_req(port_q), .force_err(force_drop), .eng_in_reset, .quiet(s_quiet), .outstanding(s_out),
      .x_req_valid(spm_req_valid), .x_req_ready(spm_req_ready), .x_req_write(spm_req_write), .x_req_addr(spm_req_addr),
      .x_req_wdata(spm_req_wdata), .x_req_wstrb(spm_req_wstrb),
      .x_rsp_valid(spm_rsp_valid), .x_rsp_ready(spm_rsp_ready), .x_rsp_rdata(spm_rsp_rdata), .x_rsp_error(spm_rsp_error),
      .t_req_valid, .t_req_ready, .t_req_write, .t_req_addr, .t_req_wdata, .t_req_wstrb,
      .t_rsp_valid, .t_rsp_ready, .t_rsp_rdata, .t_rsp_error, .ev_req(ev_spm_req)
    );
  end else begin : g_nospm
    // no window: the port is not present; requests are never accepted
    assign spm_req_ready = 1'b0;
    assign spm_rsp_valid = 1'b0;
    assign spm_rsp_rdata = '0;
    assign spm_rsp_error = 1'b0;
    assign t_req_valid = 1'b0; assign t_req_write = 1'b0; assign t_req_addr = '0;
    assign t_req_wdata = '0;   assign t_req_wstrb = '0;   assign t_rsp_ready = 1'b1;
    assign s_quiet = 1'b1;     assign s_out = '0;         assign ev_spm_req = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_spm = ^{spm_req_valid, spm_req_write, spm_req_addr, spm_req_wdata, spm_req_wstrb, spm_rsp_ready,
                        t_req_ready, t_rsp_valid, t_rsp_rdata, t_rsp_error};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ============================================================ local control
  sfx_cl_ctrl #(
    .INFO(INFO), .STREAM_DEFAULT(STREAM_DEFAULT), .RST_CYCLES(RST_CYCLES), .DRAIN_LOG2(DRAIN_LOG2),
    .IDLE_HYST(IDLE_HYST), .TLW(TLW), .MOW(MOW), .SOW(SOW)
  ) u_ctrl (
    .clk, .rst_n,
    .c_sel, .c_we(csr_we), .c_addr(csr_addr[11:0]), .c_wdata(csr_wdata), .c_rdata, .c_err,
    .rst_req,
    .eng_busy(e_busy), .eng_halted(e_halted), .eng_irq(e_irq), .ad_idle, .ad_safe, .trk_level,
    .m_quiet, .m_draining, .m_out, .s_quiet, .s_out,
    .wake(cmd_valid || spm_req_valid || csr_sel),
    .ev_cmd_accept, .ev_submit, .ev_cmd_stall(cmd_valid && !cmd_ready), .ev_cpl_deliver, .ev_cpl_err,
    .ev_cpl_stall(cpl_valid && !cpl_ready), .ev_bad_cmd, .ev_abort_cpl, .ev_host_deny, .ev_pop_err, .ev_db_retry,
    .ev_mem_req, .ev_mem_stall, .ev_lm_req, .ev_mem_rsp, .ev_mem_rsp_err, .ev_unsol, .ev_spm_req,
    .stream_en, .quiesce, .port_q, .force_drop, .eng_in_reset, .eng_rst_n,
    .irq, .err, .err_status, .clk_req, .perf_ev, .busy
  );
endmodule

`default_nettype wire
