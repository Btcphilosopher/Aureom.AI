// =============================================================================
// SilicaFlux-HPC Project 32 :: silicaflux_compute_cluster   (primary source)
// Floorplan-aware compute subsystem: replicated vector and tensor regions.
// Aureom.AI | SilicaFlux-HPC
//
//                      cmd (32-bit words + tag + dest)          cpl (32-bit words + tag + src)
//                               │                                       ▲
//                       [CMD_SLICE skid]                         [CPL_SLICE skid]
//                               │                                       │
//                        u_cmd_router (packet demux)          u_cpl_merge (packet round robin)
//               ┌───────────┬───┴───────┬──────────┐   ┌────────────┬───┴──────┬───────────┐
//          u_vector_0 ... u_vector_7  u_tensor_0 ... u_tensor_3   (+ BAD_DEST sink)
//          (.u_cl = silicaflux_vector_cluster)   (.u_cl = silicaflux_tensor_cluster)
//               │ mem / lm / spm SFB2 ports            │ mem / lm SFB2 ports
//               ▼ (NoC-facing arrays, one port set per cluster)
//
// Stable physical names (docs/05_PHYSICAL.md): every replicated engine lives in a
// generate scope named u_vector_<k> (k = 0..NUM_VECTOR_CLUSTERS-1) or
// u_tensor_<k>, and the cluster instance inside it is u_cl.  The names do not
// depend on the number of clusters built, so u_tensor_0 is u_tensor_0 in every
// configuration; Yosys keeps them as "u_vector_0.u_cl...", which is what
// constraints/*.tcl match.  No physical coordinate appears in RTL.
//
// Addressing: cmd_dest / cpl_src / CSR slot = {type, index}: 0..7 vector k,
// 8..11 tensor k.  CSR: csr_addr[16:13] slot, [12] page (0 engine, 1 cluster
// control), [11:0] register.  A command for an absent slot is absorbed and
// answered with a BAD_DEST completion (never dropped, never stalled).
// Minimum chip configuration: NUM_VECTOR_CLUSTERS = 1, NUM_TENSOR_CLUSTERS = 1,
// no slices, no local memory: zero added latency on every memory port, the
// engines' register pages and ABIs unchanged (docs/02_INTERFACES.md §7).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cl_defs.svh"
`include "sram_defs.svh"
`default_nettype none

module silicaflux_compute_cluster #(
  parameter int          NUM_VECTOR_CLUSTERS     = 4,      // 0..8
  parameter int          NUM_TENSOR_CLUSTERS     = 2,      // 0..4
  // ------------------------------------------------------------ vector clusters (HPC Module 08 tile)
  parameter int          VEC_NUM_LANES           = 4,
  parameter int          VEC_SCRATCHPAD_BYTES    = 65536,
  parameter int          VEC_NUM_BANKS           = 4,
  parameter int          VEC_DMA_BUFFER_DEPTH    = 0,
  parameter int          VEC_CMD_QUEUE_DEPTH     = 8,
  parameter logic [31:0] VEC_SPM_BASE            = 32'h2000_0000,   // vector k window: base + k * stride
  parameter logic [31:0] VEC_SPM_STRIDE          = 32'h0010_0000,
  parameter int          VEC_SPM_PORT_EN         = 1,
  parameter int          VEC_SPM_BACKEND         = `SRAM_BACKEND_GENERIC,
  // ------------------------------------------------------------ tensor clusters (TENSORCORE 08 unit)
  parameter int          TEN_ARRAY_ROWS          = 4,
  parameter int          TEN_ARRAY_COLS          = 4,
  parameter int          TEN_TILE_K              = 64,
  parameter int          TEN_OPERAND_BUFFER_BYTES = 2048,
  parameter int          TEN_NUM_MEMORY_BANKS    = 4,
  parameter int          TEN_ENABLE_QUANTIZATION = 0,
  parameter int          TEN_ENABLE_DOUBLE_BUFFERING = 0,
  parameter int          TEN_CMD_QUEUE_DEPTH     = 4,
  parameter logic [32:0] TEN_MEM_LO              = 33'h0_0000_0000,
  parameter logic [32:0] TEN_MEM_HI              = 33'h1_0000_0000,
  parameter int          TEN_MAX_OUT             = 4,
  parameter int          TEN_ALLOW_UNVERIFIED    = 0,
  parameter int          TEN_MEM_BACKEND         = `SRAM_BACKEND_GENERIC,
  // ------------------------------------------------------------ common
  parameter int          XACT_WIDTH              = 32,     // SFB2 data width of every memory port: 32, 64, 128
  parameter int          LOCAL_MEM_EN            = 0,
  parameter logic [31:0] LOCAL_MEM_BASE          = 32'h3000_0000,   // slot s window: base + s * stride
  parameter logic [31:0] LOCAL_MEM_STRIDE        = 32'h0001_0000,
  parameter logic [31:0] LOCAL_MEM_MASK          = 32'hFFFF_0000,
  parameter int          MEM_REQ_SLICE           = 0,
  parameter int          MEM_RSP_SLICE           = 0,
  parameter int          CMD_SLICE               = 0,      // skid buffer on the subsystem command input
  parameter int          CPL_SLICE               = 0,      // skid buffer on the subsystem completion output
  parameter int          TAG_W                   = 8,
  parameter int          TRK_DEPTH               = 16,
  parameter int          STREAM_DEFAULT          = 1,
  parameter int          RST_CYCLES              = 4,
  parameter int          DRAIN_LOG2              = 12,
  parameter int          IDLE_HYST               = 16,
  // ------------------------------------------------------------ derived (never set)
  localparam int NV  = NUM_VECTOR_CLUSTERS,
  localparam int NT  = NUM_TENSOR_CLUSTERS,
  localparam int VA  = (NV > 0) ? NV : 1,                   // port array sizes (one dummy slot when absent)
  localparam int TA  = (NT > 0) ? NT : 1,
  localparam int DW  = XACT_WIDTH,
  localparam int SB  = DW / 8,
  localparam int EW  = `SFX_CL_ERR_W,
  localparam int PW  = `SFX_CL_PEV_W
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------------------------------------------------- command stream (to one cluster per packet)
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [31:0]      cmd_data,
  input  wire logic             cmd_last,
  input  wire logic [TAG_W-1:0] cmd_tag,
  input  wire logic [3:0]       cmd_dest,          // sampled with the first word
  // ---------------------------------------------------------- completion stream (merged)
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [31:0]           cpl_data,
  output logic                  cpl_last,
  output logic [TAG_W-1:0]      cpl_tag,
  output logic [3:0]            cpl_src,
  output logic                  cpl_err,
  // ---------------------------------------------------------- CSR (rb contract): [16:13] slot, [12:0] cluster window
  input  wire logic             csr_sel,
  input  wire logic             csr_we,
  input  wire logic [16:0]      csr_addr,
  input  wire logic [31:0]      csr_wdata,
  output logic [31:0]           csr_rdata,
  output logic                  csr_err,
  // ---------------------------------------------------------- per-cluster reset requests (level)
  input  wire logic [VA-1:0]    vec_rst_req,
  input  wire logic [TA-1:0]    ten_rst_req,
  // ---------------------------------------------------------- vector clusters: NoC memory masters
  output logic [VA-1:0]         vec_mem_req_valid,
  input  wire logic [VA-1:0]    vec_mem_req_ready,
  output logic [VA-1:0]         vec_mem_req_write,
  output logic [VA*32-1:0]      vec_mem_req_addr,
  output logic [VA*DW-1:0]      vec_mem_req_wdata,
  output logic [VA*SB-1:0]      vec_mem_req_wstrb,
  input  wire logic [VA-1:0]    vec_mem_rsp_valid,
  output logic [VA-1:0]         vec_mem_rsp_ready,
  input  wire logic [VA*DW-1:0] vec_mem_rsp_rdata,
  input  wire logic [VA-1:0]    vec_mem_rsp_error,
  // ---------------------------------------------------------- vector clusters: local memory masters
  output logic [VA-1:0]         vec_lm_req_valid,
  input  wire logic [VA-1:0]    vec_lm_req_ready,
  output logic [VA-1:0]         vec_lm_req_write,
  output logic [VA*32-1:0]      vec_lm_req_addr,
  output logic [VA*DW-1:0]      vec_lm_req_wdata,
  output logic [VA*SB-1:0]      vec_lm_req_wstrb,
  input  wire logic [VA-1:0]    vec_lm_rsp_valid,
  output logic [VA-1:0]         vec_lm_rsp_ready,
  input  wire logic [VA*DW-1:0] vec_lm_rsp_rdata,
  input  wire logic [VA-1:0]    vec_lm_rsp_error,
  // ---------------------------------------------------------- vector clusters: scratchpad window slaves
  input  wire logic [VA-1:0]    vec_spm_req_valid,
  output logic [VA-1:0]         vec_spm_req_ready,
  input  wire logic [VA-1:0]    vec_spm_req_write,
  input  wire logic [VA*32-1:0] vec_spm_req_addr,
  input  wire logic [VA*DW-1:0] vec_spm_req_wdata,
  input  wire logic [VA*SB-1:0] vec_spm_req_wstrb,
  output logic [VA-1:0]         vec_spm_rsp_valid,
  input  wire logic [VA-1:0]    vec_spm_rsp_ready,
  output logic [VA*DW-1:0]      vec_spm_rsp_rdata,
  output logic [VA-1:0]         vec_spm_rsp_error,
  // ---------------------------------------------------------- tensor clusters: NoC memory masters
  output logic [TA-1:0]         ten_mem_req_valid,
  input  wire logic [TA-1:0]    ten_mem_req_ready,
  output logic [TA-1:0]         ten_mem_req_write,
  output logic [TA*32-1:0]      ten_mem_req_addr,
  output logic [TA*DW-1:0]      ten_mem_req_wdata,
  output logic [TA*SB-1:0]      ten_mem_req_wstrb,
  input  wire logic [TA-1:0]    ten_mem_rsp_valid,
  output logic [TA-1:0]         ten_mem_rsp_ready,
  input  wire logic [TA*DW-1:0] ten_mem_rsp_rdata,
  input  wire logic [TA-1:0]    ten_mem_rsp_error,
  // ---------------------------------------------------------- tensor clusters: local memory masters
  output logic [TA-1:0]         ten_lm_req_valid,
  input  wire logic [TA-1:0]    ten_lm_req_ready,
  output logic [TA-1:0]         ten_lm_req_write,
  output logic [TA*32-1:0]      ten_lm_req_addr,
  output logic [TA*DW-1:0]      ten_lm_req_wdata,
  output logic [TA*SB-1:0]      ten_lm_req_wstrb,
  input  wire logic [TA-1:0]    ten_lm_rsp_valid,
  output logic [TA-1:0]         ten_lm_rsp_ready,
  input  wire logic [TA*DW-1:0] ten_lm_rsp_rdata,
  input  wire logic [TA-1:0]    ten_lm_rsp_error,
  // ---------------------------------------------------------- per-cluster interrupt / error / status / events
  output logic [VA-1:0]         vec_irq,
  output logic [VA-1:0]         vec_err,
  output logic [VA*EW-1:0]      vec_err_status,
  output logic [VA-1:0]         vec_busy,
  output logic [VA-1:0]         vec_clk_req,
  output logic [VA*PW-1:0]      vec_perf_ev,
  output logic [TA-1:0]         ten_irq,
  output logic [TA-1:0]         ten_err,
  output logic [TA*EW-1:0]      ten_err_status,
  output logic [TA-1:0]         ten_busy,
  output logic [TA-1:0]         ten_clk_req,
  output logic [TA*PW-1:0]      ten_perf_ev,
  // ---------------------------------------------------------- summaries (registered)
  output logic                  irq_any,
  output logic                  err_any
);
  // ============================================================ configuration checks
  if (NV < 0 || NV > 8) begin : g_err_nv
    `SFX_CL_CFG_FATAL("silicaflux_compute_cluster: NUM_VECTOR_CLUSTERS must be 0..8")
  end
  if (NT < 0 || NT > 4) begin : g_err_nt
    `SFX_CL_CFG_FATAL("silicaflux_compute_cluster: NUM_TENSOR_CLUSTERS must be 0..4")
  end
  if (NV + NT < 1) begin : g_err_none
    `SFX_CL_CFG_FATAL("silicaflux_compute_cluster: at least one cluster is required")
  end
  if (XACT_WIDTH != 32 && XACT_WIDTH != 64 && XACT_WIDTH != 128) begin : g_err_xw
    `SFX_CL_CFG_FATAL("silicaflux_compute_cluster: XACT_WIDTH must be 32, 64 or 128")
  end
  if (NV > 1 && (VEC_SPM_STRIDE < 32'(VEC_SCRATCHPAD_BYTES) ||
                 (VEC_SPM_STRIDE & 32'(VEC_SCRATCHPAD_BYTES - 1)) != 32'd0)) begin : g_err_stride
    `SFX_CL_CFG_FATAL("silicaflux_compute_cluster: VEC_SPM_STRIDE must be a multiple of VEC_SCRATCHPAD_BYTES (disjoint windows)")
  end
  if (LOCAL_MEM_EN != 0 && (LOCAL_MEM_STRIDE & LOCAL_MEM_MASK) != LOCAL_MEM_STRIDE) begin : g_err_lstride
    `SFX_CL_CFG_FATAL("silicaflux_compute_cluster: LOCAL_MEM_STRIDE must lie inside LOCAL_MEM_MASK (one window per slot)")
  end

  // ============================================================ command input (optional skid)
  logic             i_v, i_r, i_last;
  logic [31:0]      i_data;
  logic [TAG_W-1:0] i_tag;
  logic [3:0]       i_dest;
  if (CMD_SLICE != 0) begin : g_cmd_slice
    sfb_skid_buffer #(.WIDTH(37 + TAG_W)) u_cmd_skid (
      .clk, .rst_n,
      .s_valid(cmd_valid), .s_ready(cmd_ready), .s_data({cmd_last, cmd_dest, cmd_tag, cmd_data}),
      .m_valid(i_v), .m_ready(i_r), .m_data({i_last, i_dest, i_tag, i_data})
    );
  end else begin : g_cmd_wire
    assign i_v = cmd_valid; assign cmd_ready = i_r; assign i_last = cmd_last;
    assign i_dest = cmd_dest; assign i_tag = cmd_tag; assign i_data = cmd_data;
  end

  // ============================================================ command router (packet-locked demux)
  logic       r_act;
  logic [3:0] r_dest;
  wire  [3:0] cur_dest = r_act ? r_dest : i_dest;
  // slot code d is present when bit d of SLOT_MASK is set (0..7 vector k < NV, 8..11 tensor k < NT)
  function automatic logic [15:0] slot_mask(input int nv, input int nt);
    slot_mask = '0;
    for (int k = 0; k < 8; k++) if (k < nv) slot_mask[k] = 1'b1;
    for (int k = 0; k < 4; k++) if (k < nt) slot_mask[8 + k] = 1'b1;
  endfunction
  localparam logic [15:0] SLOT_MASK = slot_mask(NV, NT);
  wire        cur_ok = SLOT_MASK[cur_dest];

  wire  [VA-1:0] v_cmd_ready, v_cmd_valid;
  wire  [TA-1:0] t_cmd_ready, t_cmd_valid;
  logic          n_in_ready;                 // BAD_DEST sink
  for (genvar k = 0; k < VA; k++) begin : g_vsel
    assign v_cmd_valid[k] = i_v && cur_ok && !cur_dest[3] && (cur_dest[2:0] == 3'(k));
  end
  for (genvar k = 0; k < TA; k++) begin : g_tsel
    assign t_cmd_valid[k] = i_v && cur_ok && cur_dest[3] && (cur_dest[1:0] == 2'(k));
  end
  always_comb begin
    i_r = n_in_ready;
    for (int k = 0; k < VA; k++) if (cur_ok && cur_dest == 4'(k))     i_r = v_cmd_ready[k];
    for (int k = 0; k < TA; k++) if (cur_ok && cur_dest == 4'(8 + k)) i_r = t_cmd_ready[k];
  end
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_act <= 1'b0; r_dest <= '0;
    end else if (i_v && i_r) begin
      r_act  <= !i_last;
      if (!r_act) r_dest <= i_dest;
    end
  end

  // ---------------------------------------------------------- BAD_DEST sink: absorb, answer with a shell record
  localparam int NQD = 4;
  logic [TAG_W-1:0] nq_tag [NQD];
  logic [3:0]       nq_dst [NQD];
  logic [2:0]       nq_wp, nq_rp;
  wire              nq_full  = ((nq_wp - nq_rp) == 3'(NQD));
  wire              nq_empty = (nq_wp == nq_rp);
  logic [TAG_W-1:0] n_tag_q;
  logic             n_v;
  logic [2:0]       n_idx;
  wire              n_push = i_v && !cur_ok && i_last && !nq_full;
  assign n_in_ready = !(i_last && nq_full);
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      nq_wp <= '0; n_tag_q <= '0;
      for (int i = 0; i < NQD; i++) begin nq_tag[i] <= '0; nq_dst[i] <= '0; end
    end else begin
      if (i_v && !cur_ok && !r_act) n_tag_q <= i_tag;                    // tag of the first word
      if (n_push) begin
        nq_tag[nq_wp[1:0]] <= r_act ? n_tag_q : i_tag;
        nq_dst[nq_wp[1:0]] <= cur_dest;
        nq_wp <= nq_wp + 3'd1;
      end
    end
  end
  // sink output: SFX_CL_CPL_WORDS words per record
  logic n_cpl_ready;
  wire  n_hs = n_v && n_cpl_ready;
  assign n_v = !nq_empty;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      nq_rp <= '0; n_idx <= '0;
    end else if (n_hs) begin
      if (n_idx == 3'(`SFX_CL_CPL_WORDS - 1)) begin n_idx <= '0; nq_rp <= nq_rp + 3'd1; end
      else n_idx <= n_idx + 3'd1;
    end
  end
  wire [3:0]  n_dst = nq_dst[nq_rp[1:0]];
  wire [31:0] n_hdr = {`SFX_CL_ABI_VERSION, 4'd0, n_dst, 4'(`SFX_CL_ENG_CPL_WORDS), `SFX_CL_ENG_NONE,
                       3'd0, 1'b1, `SFX_CL_ST_BAD_DEST};
  wire [31:0] n_data = (n_idx == 3'd0) ? n_hdr : 32'd0;

  // ============================================================ per-cluster completion and CSR wiring
  wire  [VA-1:0]        v_cpl_valid, v_cpl_last, v_cpl_err, v_csr_err;
  wire  [TA-1:0]        t_cpl_valid, t_cpl_last, t_cpl_err, t_csr_err;
  wire  [VA*32-1:0]     v_cpl_data, v_csr_rdata;
  wire  [TA*32-1:0]     t_cpl_data, t_csr_rdata;
  wire  [VA*TAG_W-1:0]  v_cpl_tag;
  wire  [TA*TAG_W-1:0]  t_cpl_tag;
  logic [VA-1:0]        v_cpl_ready, v_csr_sel;
  logic [TA-1:0]        t_cpl_ready, t_csr_sel;

  wire [3:0] csr_slot = csr_addr[16:13];
  for (genvar k = 0; k < VA; k++) begin : g_vcsr
    assign v_csr_sel[k] = csr_sel && (csr_slot == 4'(k)) && (k < NV);
  end
  for (genvar k = 0; k < TA; k++) begin : g_tcsr
    assign t_csr_sel[k] = csr_sel && (csr_slot == 4'(8 + k)) && (k < NT);
  end
  always_comb begin
    csr_rdata = '0;
    csr_err   = csr_sel;                       // absent slot: refused
    for (int k = 0; k < VA; k++) if (v_csr_sel[k]) begin csr_rdata = v_csr_rdata[k*32 +: 32]; csr_err = v_csr_err[k]; end
    for (int k = 0; k < TA; k++) if (t_csr_sel[k]) begin csr_rdata = t_csr_rdata[k*32 +: 32]; csr_err = t_csr_err[k]; end
  end

  // ============================================================ replicated regions
  // One macro per slot so every region has a stable, bracket-free name.  A slot whose index is not
  // below the configured count is not elaborated.
`define SFX_CC_VECTOR_SLOT(K) \
  if (K < NV) begin : u_vector_``K \
    silicaflux_vector_cluster #( \
      .CLUSTER_ID(8'(K)), .NUM_LANES(VEC_NUM_LANES), .XACT_WIDTH(XACT_WIDTH), \
      .SCRATCHPAD_BYTES(VEC_SCRATCHPAD_BYTES), .NUM_BANKS(VEC_NUM_BANKS), .CMD_QUEUE_DEPTH(VEC_CMD_QUEUE_DEPTH), \
      .DMA_BUFFER_DEPTH(VEC_DMA_BUFFER_DEPTH), .SPM_BASE(VEC_SPM_BASE + 32'(K) * VEC_SPM_STRIDE), \
      .SPM_BACKEND(VEC_SPM_BACKEND), .SPM_PORT_EN(VEC_SPM_PORT_EN), .LOCAL_MEM_EN(LOCAL_MEM_EN), \
      .LOCAL_MEM_BASE(LOCAL_MEM_BASE + 32'(K) * LOCAL_MEM_STRIDE), .LOCAL_MEM_MASK(LOCAL_MEM_MASK), \
      .MEM_REQ_SLICE(MEM_REQ_SLICE), .MEM_RSP_SLICE(MEM_RSP_SLICE), .TAG_W(TAG_W), .TRK_DEPTH(TRK_DEPTH), \
      .STREAM_DEFAULT(STREAM_DEFAULT), .RST_CYCLES(RST_CYCLES), .DRAIN_LOG2(DRAIN_LOG2), .IDLE_HYST(IDLE_HYST) \
    ) u_cl ( \
      .clk(clk), .rst_n(rst_n), .rst_req(vec_rst_req[K]), \
      .cmd_valid(v_cmd_valid[K]), .cmd_ready(v_cmd_ready[K]), .cmd_data(i_data), .cmd_last(i_last), .cmd_tag(i_tag), \
      .cpl_valid(v_cpl_valid[K]), .cpl_ready(v_cpl_ready[K]), .cpl_data(v_cpl_data[K*32 +: 32]), \
      .cpl_last(v_cpl_last[K]), .cpl_tag(v_cpl_tag[K*TAG_W +: TAG_W]), .cpl_err(v_cpl_err[K]), \
      .csr_sel(v_csr_sel[K]), .csr_we(csr_we), .csr_addr(csr_addr[12:0]), .csr_wdata(csr_wdata), \
      .csr_rdata(v_csr_rdata[K*32 +: 32]), .csr_err(v_csr_err[K]), \
      .mem_req_valid(vec_mem_req_valid[K]), .mem_req_ready(vec_mem_req_ready[K]), .mem_req_write(vec_mem_req_write[K]), \
      .mem_req_addr(vec_mem_req_addr[K*32 +: 32]), .mem_req_wdata(vec_mem_req_wdata[K*DW +: DW]), \
      .mem_req_wstrb(vec_mem_req_wstrb[K*SB +: SB]), .mem_rsp_valid(vec_mem_rsp_valid[K]), \
      .mem_rsp_ready(vec_mem_rsp_ready[K]), .mem_rsp_rdata(vec_mem_rsp_rdata[K*DW +: DW]), \
      .mem_rsp_error(vec_mem_rsp_error[K]), \
      .lm_req_valid(vec_lm_req_valid[K]), .lm_req_ready(vec_lm_req_ready[K]), .lm_req_write(vec_lm_req_write[K]), \
      .lm_req_addr(vec_lm_req_addr[K*32 +: 32]), .lm_req_wdata(vec_lm_req_wdata[K*DW +: DW]), \
      .lm_req_wstrb(vec_lm_req_wstrb[K*SB +: SB]), .lm_rsp_valid(vec_lm_rsp_valid[K]), \
      .lm_rsp_ready(vec_lm_rsp_ready[K]), .lm_rsp_rdata(vec_lm_rsp_rdata[K*DW +: DW]), \
      .lm_rsp_error(vec_lm_rsp_error[K]), \
      .spm_req_valid(vec_spm_req_valid[K]), .spm_req_ready(vec_spm_req_ready[K]), .spm_req_write(vec_spm_req_write[K]), \
      .spm_req_addr(vec_spm_req_addr[K*32 +: 32]), .spm_req_wdata(vec_spm_req_wdata[K*DW +: DW]), \
      .spm_req_wstrb(vec_spm_req_wstrb[K*SB +: SB]), .spm_rsp_valid(vec_spm_rsp_valid[K]), \
      .spm_rsp_ready(vec_spm_rsp_ready[K]), .spm_rsp_rdata(vec_spm_rsp_rdata[K*DW +: DW]), \
      .spm_rsp_error(vec_spm_rsp_error[K]), \
      .irq(vec_irq[K]), .err(vec_err[K]), .err_status(vec_err_status[K*EW +: EW]), .busy(vec_busy[K]), \
      .clk_req(vec_clk_req[K]), .perf_ev(vec_perf_ev[K*PW +: PW]) \
    ); \
  end

`define SFX_CC_TENSOR_SLOT(K) \
  if (K < NT) begin : u_tensor_``K \
    silicaflux_tensor_cluster #( \
      .CLUSTER_ID(8'(8 + K)), .ARRAY_ROWS(TEN_ARRAY_ROWS), .ARRAY_COLS(TEN_ARRAY_COLS), .TILE_K(TEN_TILE_K), \
      .OPERAND_BUFFER_BYTES(TEN_OPERAND_BUFFER_BYTES), .NUM_MEMORY_BANKS(TEN_NUM_MEMORY_BANKS), \
      .ENABLE_QUANTIZATION(TEN_ENABLE_QUANTIZATION), .ENABLE_DOUBLE_BUFFERING(TEN_ENABLE_DOUBLE_BUFFERING), \
      .CMD_QUEUE_DEPTH(TEN_CMD_QUEUE_DEPTH), .MEM_LO(TEN_MEM_LO), .MEM_HI(TEN_MEM_HI), .ENG_MAX_OUT(TEN_MAX_OUT), \
      .ALLOW_UNVERIFIED(TEN_ALLOW_UNVERIFIED), .MEM_BACKEND(TEN_MEM_BACKEND), .XACT_WIDTH(XACT_WIDTH), \
      .LOCAL_MEM_EN(LOCAL_MEM_EN), .LOCAL_MEM_BASE(LOCAL_MEM_BASE + 32'(8 + K) * LOCAL_MEM_STRIDE), \
      .LOCAL_MEM_MASK(LOCAL_MEM_MASK), .MEM_REQ_SLICE(MEM_REQ_SLICE), .MEM_RSP_SLICE(MEM_RSP_SLICE), \
      .TAG_W(TAG_W), .TRK_DEPTH(TRK_DEPTH), .STREAM_DEFAULT(STREAM_DEFAULT), .RST_CYCLES(RST_CYCLES), \
      .DRAIN_LOG2(DRAIN_LOG2), .IDLE_HYST(IDLE_HYST) \
    ) u_cl ( \
      .clk(clk), .rst_n(rst_n), .rst_req(ten_rst_req[K]), \
      .cmd_valid(t_cmd_valid[K]), .cmd_ready(t_cmd_ready[K]), .cmd_data(i_data), .cmd_last(i_last), .cmd_tag(i_tag), \
      .cpl_valid(t_cpl_valid[K]), .cpl_ready(t_cpl_ready[K]), .cpl_data(t_cpl_data[K*32 +: 32]), \
      .cpl_last(t_cpl_last[K]), .cpl_tag(t_cpl_tag[K*TAG_W +: TAG_W]), .cpl_err(t_cpl_err[K]), \
      .csr_sel(t_csr_sel[K]), .csr_we(csr_we), .csr_addr(csr_addr[12:0]), .csr_wdata(csr_wdata), \
      .csr_rdata(t_csr_rdata[K*32 +: 32]), .csr_err(t_csr_err[K]), \
      .mem_req_valid(ten_mem_req_valid[K]), .mem_req_ready(ten_mem_req_ready[K]), .mem_req_write(ten_mem_req_write[K]), \
      .mem_req_addr(ten_mem_req_addr[K*32 +: 32]), .mem_req_wdata(ten_mem_req_wdata[K*DW +: DW]), \
      .mem_req_wstrb(ten_mem_req_wstrb[K*SB +: SB]), .mem_rsp_valid(ten_mem_rsp_valid[K]), \
      .mem_rsp_ready(ten_mem_rsp_ready[K]), .mem_rsp_rdata(ten_mem_rsp_rdata[K*DW +: DW]), \
      .mem_rsp_error(ten_mem_rsp_error[K]), \
      .lm_req_valid(ten_lm_req_valid[K]), .lm_req_ready(ten_lm_req_ready[K]), .lm_req_write(ten_lm_req_write[K]), \
      .lm_req_addr(ten_lm_req_addr[K*32 +: 32]), .lm_req_wdata(ten_lm_req_wdata[K*DW +: DW]), \
      .lm_req_wstrb(ten_lm_req_wstrb[K*SB +: SB]), .lm_rsp_valid(ten_lm_rsp_valid[K]), \
      .lm_rsp_ready(ten_lm_rsp_ready[K]), .lm_rsp_rdata(ten_lm_rsp_rdata[K*DW +: DW]), \
      .lm_rsp_error(ten_lm_rsp_error[K]), \
      .irq(ten_irq[K]), .err(ten_err[K]), .err_status(ten_err_status[K*EW +: EW]), .busy(ten_busy[K]), \
      .clk_req(ten_clk_req[K]), .perf_ev(ten_perf_ev[K*PW +: PW]) \
    ); \
  end

  `SFX_CC_VECTOR_SLOT(0)
  `SFX_CC_VECTOR_SLOT(1)
  `SFX_CC_VECTOR_SLOT(2)
  `SFX_CC_VECTOR_SLOT(3)
  `SFX_CC_VECTOR_SLOT(4)
  `SFX_CC_VECTOR_SLOT(5)
  `SFX_CC_VECTOR_SLOT(6)
  `SFX_CC_VECTOR_SLOT(7)
  `SFX_CC_TENSOR_SLOT(0)
  `SFX_CC_TENSOR_SLOT(1)
  `SFX_CC_TENSOR_SLOT(2)
  `SFX_CC_TENSOR_SLOT(3)
`undef SFX_CC_VECTOR_SLOT
`undef SFX_CC_TENSOR_SLOT

  // absent type: tie the one dummy port slot off
  if (NV == 0) begin : g_novec
    assign v_cmd_ready = '0; assign v_cpl_valid = '0; assign v_cpl_last = '0; assign v_cpl_err = '0;
    assign v_cpl_data = '0; assign v_cpl_tag = '0; assign v_csr_rdata = '0; assign v_csr_err = '1;
    assign vec_mem_req_valid = '0; assign vec_mem_req_write = '0; assign vec_mem_req_addr = '0;
    assign vec_mem_req_wdata = '0; assign vec_mem_req_wstrb = '0; assign vec_mem_rsp_ready = '1;
    assign vec_lm_req_valid = '0; assign vec_lm_req_write = '0; assign vec_lm_req_addr = '0;
    assign vec_lm_req_wdata = '0; assign vec_lm_req_wstrb = '0; assign vec_lm_rsp_ready = '1;
    assign vec_spm_req_ready = '0; assign vec_spm_rsp_valid = '0; assign vec_spm_rsp_rdata = '0;
    assign vec_spm_rsp_error = '0;
    assign vec_irq = '0; assign vec_err = '0; assign vec_err_status = '0; assign vec_busy = '0;
    assign vec_clk_req = '0; assign vec_perf_ev = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_v = ^{vec_rst_req, vec_mem_req_ready, vec_mem_rsp_valid, vec_mem_rsp_rdata, vec_mem_rsp_error,
                      vec_lm_req_ready, vec_lm_rsp_valid, vec_lm_rsp_rdata, vec_lm_rsp_error, vec_spm_req_valid,
                      vec_spm_req_write, vec_spm_req_addr, vec_spm_req_wdata, vec_spm_req_wstrb, vec_spm_rsp_ready,
                      v_cmd_valid, v_cpl_ready};
    /* verilator lint_on UNUSEDSIGNAL */
  end
  if (NT == 0) begin : g_noten
    assign t_cmd_ready = '0; assign t_cpl_valid = '0; assign t_cpl_last = '0; assign t_cpl_err = '0;
    assign t_cpl_data = '0; assign t_cpl_tag = '0; assign t_csr_rdata = '0; assign t_csr_err = '1;
    assign ten_mem_req_valid = '0; assign ten_mem_req_write = '0; assign ten_mem_req_addr = '0;
    assign ten_mem_req_wdata = '0; assign ten_mem_req_wstrb = '0; assign ten_mem_rsp_ready = '1;
    assign ten_lm_req_valid = '0; assign ten_lm_req_write = '0; assign ten_lm_req_addr = '0;
    assign ten_lm_req_wdata = '0; assign ten_lm_req_wstrb = '0; assign ten_lm_rsp_ready = '1;
    assign ten_irq = '0; assign ten_err = '0; assign ten_err_status = '0; assign ten_busy = '0;
    assign ten_clk_req = '0; assign ten_perf_ev = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_t = ^{ten_rst_req, ten_mem_req_ready, ten_mem_rsp_valid, ten_mem_rsp_rdata, ten_mem_rsp_error,
                      ten_lm_req_ready, ten_lm_rsp_valid, ten_lm_rsp_rdata, ten_lm_rsp_error, t_cmd_valid, t_cpl_ready};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ============================================================ completion merge (packet-locked round robin)
  // sources: vector slots 0..VA-1, tensor slots VA..VA+TA-1, BAD_DEST sink last
  localparam int NS  = VA + TA + 1;
  localparam int SW  = $clog2(NS);
  wire  [NS-1:0]       s_valid = {n_v, t_cpl_valid, v_cpl_valid};
  wire  [NS-1:0]       s_last  = {n_idx == 3'(`SFX_CL_CPL_WORDS - 1), t_cpl_last, v_cpl_last};
  wire  [NS-1:0]       s_err   = {1'b1, t_cpl_err, v_cpl_err};
  wire  [NS*32-1:0]    s_data  = {n_data, t_cpl_data, v_cpl_data};
  wire  [NS*TAG_W-1:0] s_tag   = {nq_tag[nq_rp[1:0]], t_cpl_tag, v_cpl_tag};
  logic [SW-1:0]       sel, gnt_q, ptr_q;
  logic                lock_q;
  logic                o_v, o_r;

  always_comb begin
    sel = gnt_q;
    if (!lock_q) begin
      sel = ptr_q;
      for (int j = NS - 1; j >= 0; j--) begin
        // first valid source at or after ptr_q (round robin); j counts down so the nearest wins
        if (s_valid[(32'(ptr_q) + j) % NS]) sel = SW'((32'(ptr_q) + j) % NS);
      end
    end
  end
  assign o_v = s_valid[sel];
  wire o_hs = o_v && o_r;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lock_q <= 1'b0; gnt_q <= '0; ptr_q <= '0;
    end else begin
      if (o_hs && s_last[sel]) begin
        lock_q <= 1'b0;
        ptr_q  <= (32'(sel) == NS - 1) ? '0 : sel + 1'b1;
      end else if (o_v) begin
        lock_q <= 1'b1;                       // presented: hold the source until its last word
        gnt_q  <= sel;
      end
    end
  end
  for (genvar k = 0; k < VA; k++) begin : g_vrdy
    assign v_cpl_ready[k] = o_r && (32'(sel) == k);
  end
  for (genvar k = 0; k < TA; k++) begin : g_trdy
    assign t_cpl_ready[k] = o_r && (32'(sel) == VA + k);
  end
  assign n_cpl_ready = o_r && (32'(sel) == NS - 1);

  // source code of the selected packet: {type, index}
  logic [3:0] o_src;
  always_comb begin
    if (32'(sel) < VA)            o_src = 4'(sel);
    else if (32'(sel) < VA + TA)  o_src = 4'(8 + 32'(sel) - VA);
    else                          o_src = n_dst;
  end

  if (CPL_SLICE != 0) begin : g_cpl_slice
    sfb_skid_buffer #(.WIDTH(38 + TAG_W)) u_cpl_skid (
      .clk, .rst_n,
      .s_valid(o_v), .s_ready(o_r),
      .s_data({s_last[sel], s_err[sel], o_src, s_tag[sel*TAG_W +: TAG_W], s_data[sel*32 +: 32]}),
      .m_valid(cpl_valid), .m_ready(cpl_ready), .m_data({cpl_last, cpl_err, cpl_src, cpl_tag, cpl_data})
    );
  end else begin : g_cpl_wire
    assign cpl_valid = o_v;
    assign o_r       = cpl_ready;
    assign cpl_last  = s_last[sel];
    assign cpl_err   = s_err[sel];
    assign cpl_src   = o_src;
    assign cpl_tag   = s_tag[sel*TAG_W +: TAG_W];
    assign cpl_data  = s_data[sel*32 +: 32];
  end

  // ============================================================ summaries
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      irq_any <= 1'b0; err_any <= 1'b0;
    end else begin
      irq_any <= (|vec_irq) || (|ten_irq);
      err_any <= (|vec_err) || (|ten_err);
    end
  end
endmodule

`default_nettype wire
