// =============================================================================
// SilicaFlux-HPC Project 32 :: sfx_cl_ctrl
// Local control of one compute cluster.  Aureom.AI | SilicaFlux-HPC
//
// * cluster control page (rb contract, 4 KiB; registers in sfx_cl_defs.svh)
// * reset sequencer: RUN -> Q_CMD (adapter stops starting engine sequences)
//     -> Q_MEM (memory / scratchpad ports drain) -> RESET (engine reset held
//     RST_CYCLES, longer while rst_req is high) -> RELEASE -> RUN.
//     If the ports do not drain within 2^DRAIN_LOG2 cycles (a stuck NoC), the
//     reset is forced: outstanding memory responses are dropped by the memory
//     port, outstanding scratchpad-port requests are answered with errors, and
//     DRAIN_TIMEOUT is reported.  A forced reset never withdraws a presented
//     memory request: the memory port captures it and keeps it on the NoC.
// * sticky error bits -> err_status / err / irq (registered, narrow)
// * clock-enable request (advisory, registered, IDLE_HYST cycles of hysteresis)
// * 1-bit performance events (registered)
// The engine reset is eng_rst_n = rst_n & !eng_rst_q (asynchronous assert by the
// system reset, otherwise a registered, glitch-free term -- the convention of the
// tensor unit's own datapath soft reset).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cl_defs.svh"
`default_nettype none

module sfx_cl_ctrl #(
  parameter logic [31:0] INFO           = 32'd0,   // CL_INFO value (built by the cluster wrapper)
  parameter int          STREAM_DEFAULT = 1,
  parameter int          RST_CYCLES     = 4,       // minimum engine-reset pulse (cycles)
  parameter int          DRAIN_LOG2     = 12,      // drain timeout 2^DRAIN_LOG2 cycles
  parameter int          IDLE_HYST      = 16,      // idle cycles before clk_req drops
  parameter int          TLW            = 5,
  parameter int          MOW            = 3,
  parameter int          SOW            = 3
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // ---------------------------------------------------------- cluster control page
  input  wire logic           c_sel,
  input  wire logic           c_we,
  input  wire logic [11:0]    c_addr,
  input  wire logic [31:0]    c_wdata,
  output logic [31:0]         c_rdata,
  output logic                c_err,
  // ---------------------------------------------------------- external reset request (level)
  input  wire logic           rst_req,
  // ---------------------------------------------------------- status in
  input  wire logic           eng_busy,
  input  wire logic           eng_halted,
  input  wire logic           eng_irq,
  input  wire logic           ad_idle,
  input  wire logic           ad_safe,
  input  wire logic [TLW-1:0] trk_level,
  input  wire logic           m_quiet,
  input  wire logic           m_draining,
  input  wire logic [MOW-1:0] m_out,
  input  wire logic           s_quiet,
  input  wire logic [SOW-1:0] s_out,
  input  wire logic           wake,          // a request is waiting at a cluster input
  // ---------------------------------------------------------- events in (one cycle)
  input  wire logic           ev_cmd_accept,
  input  wire logic           ev_submit,
  input  wire logic           ev_cmd_stall,
  input  wire logic           ev_cpl_deliver,
  input  wire logic           ev_cpl_err,
  input  wire logic           ev_cpl_stall,
  input  wire logic           ev_bad_cmd,
  input  wire logic           ev_abort_cpl,
  input  wire logic           ev_host_deny,
  input  wire logic           ev_pop_err,
  input  wire logic           ev_db_retry,
  input  wire logic           ev_mem_req,
  input  wire logic           ev_mem_stall,
  input  wire logic           ev_lm_req,
  input  wire logic           ev_mem_rsp,
  input  wire logic           ev_mem_rsp_err,
  input  wire logic           ev_unsol,
  input  wire logic           ev_spm_req,
  // ---------------------------------------------------------- control out
  output logic                stream_en,
  output logic                quiesce,       // adapter
  output logic                port_q,        // memory / scratchpad ports
  output logic                force_drop,    // pulse
  output logic                eng_in_reset,
  output logic                eng_rst_n,
  // ---------------------------------------------------------- cluster outputs (registered)
  output logic                irq,
  output logic                err,
  output logic [`SFX_CL_ERR_W-1:0] err_status,
  output logic                clk_req,
  output logic [`SFX_CL_PEV_W-1:0] perf_ev,
  output logic                busy
);
  if (RST_CYCLES < 1 || RST_CYCLES > 255) begin : g_err_rc
    `SFX_CL_CFG_FATAL("sfx_cl_ctrl: RST_CYCLES must be 1..255")
  end
  if (DRAIN_LOG2 < 4 || DRAIN_LOG2 > 24) begin : g_err_dl
    `SFX_CL_CFG_FATAL("sfx_cl_ctrl: DRAIN_LOG2 must be 4..24")
  end
  if (IDLE_HYST < 1 || IDLE_HYST > 255) begin : g_err_ih
    `SFX_CL_CFG_FATAL("sfx_cl_ctrl: IDLE_HYST must be 1..255")
  end

  // ============================================================ reset sequencer
  logic [3:0]            st;
  logic [DRAIN_LOG2:0]   tmr;
  logic [7:0]            rcnt;
  logic                  rst_pend, eng_rst_q;
  wire                   ports_quiet = m_quiet && s_quiet;
  wire                   timeout     = tmr[DRAIN_LOG2];
  wire                   do_force    = (st == `SFX_CL_RS_Q_MEM) && !ports_quiet && timeout;
  wire                   go_reset    = (st == `SFX_CL_RS_Q_MEM) && (ports_quiet || do_force);
  logic                  csr_rst;     // CL_CTRL.RESET pulse
  logic                  seq_done;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= `SFX_CL_RS_RUN; tmr <= '0; rcnt <= '0; rst_pend <= 1'b0; eng_rst_q <= 1'b0;
    end else begin
      if (csr_rst) rst_pend <= 1'b1;
      case (st)
        `SFX_CL_RS_RUN:     if (rst_req || rst_pend || csr_rst) begin st <= `SFX_CL_RS_Q_CMD; rst_pend <= 1'b0; end
        `SFX_CL_RS_Q_CMD:   if (ad_safe) begin st <= `SFX_CL_RS_Q_MEM; tmr <= '0; end
        `SFX_CL_RS_Q_MEM:   begin
                              if (!timeout) tmr <= tmr + 1'b1;
                              if (go_reset) begin
                                st <= `SFX_CL_RS_RESET; eng_rst_q <= 1'b1; rcnt <= 8'(RST_CYCLES);
                              end
                            end
        `SFX_CL_RS_RESET:   begin
                              if (rcnt != 8'd0) rcnt <= rcnt - 8'd1;
                              else if (!rst_req) begin st <= `SFX_CL_RS_RELEASE; eng_rst_q <= 1'b0; rcnt <= 8'd2; end
                            end
        `SFX_CL_RS_RELEASE: begin
                              if (rcnt != 8'd0) rcnt <= rcnt - 8'd1;
                              else st <= `SFX_CL_RS_RUN;
                            end
        default:            st <= `SFX_CL_RS_RUN;
      endcase
    end
  end
  assign seq_done     = (st == `SFX_CL_RS_RELEASE) && (rcnt == 8'd0);
  assign quiesce      = (st != `SFX_CL_RS_RUN);
  assign port_q       = (st == `SFX_CL_RS_Q_MEM) || (st == `SFX_CL_RS_RESET) || (st == `SFX_CL_RS_RELEASE);
  assign force_drop   = do_force;
  assign eng_in_reset = eng_rst_q;
  assign eng_rst_n    = rst_n && !eng_rst_q;

  // ============================================================ registers
  logic                     stream_q, clkf_q;
  logic [`SFX_CL_ERR_W-1:0] err_q, err_en_q, err_set;
  logic [31:0]              n_cmds, n_cpls, n_aborts, n_resets;
  logic                     halted_q;

  assign stream_en = stream_q;

  // ---------------------------------------------------------- CSR decode
  wire a_id = (c_addr == `SFX_CL_R_ID),     a_info = (c_addr == `SFX_CL_R_INFO);
  wire a_ctl = (c_addr == `SFX_CL_R_CTRL),  a_st   = (c_addr == `SFX_CL_R_STATUS);
  wire a_err = (c_addr == `SFX_CL_R_ERR),   a_een  = (c_addr == `SFX_CL_R_ERR_EN);
  wire a_cmd = (c_addr == `SFX_CL_R_CMDS),  a_cpl  = (c_addr == `SFX_CL_R_CPLS);
  wire a_abt = (c_addr == `SFX_CL_R_ABORTS), a_rst = (c_addr == `SFX_CL_R_RESETS);
  wire a_mi  = (c_addr == `SFX_CL_R_MEMINFO);
  wire a_any = a_id || a_info || a_ctl || a_st || a_err || a_een || a_cmd || a_cpl || a_abt || a_rst || a_mi;
  wire a_wr  = a_ctl || a_err || a_een;
  // STREAM_EN may only change while the adapter is idle and no reset sequence runs
  wire ctl_mode_chg = c_sel && c_we && a_ctl && (c_wdata[0] != stream_q);
  wire ctl_deny     = ctl_mode_chg && !(ad_idle && st == `SFX_CL_RS_RUN);
  assign c_err   = c_sel && (!a_any || (c_we && !a_wr) || ctl_deny);
  wire   wr_ok   = c_sel && c_we && !c_err;
  assign csr_rst = wr_ok && a_ctl && c_wdata[1];

  // sticky error sources
  always_comb begin
    err_set = '0;
    err_set[`SFX_CL_E_CPL_ERR]       = ev_cpl_err;
    err_set[`SFX_CL_E_BAD_CMD]       = ev_bad_cmd;
    err_set[`SFX_CL_E_MEM_ERR]       = ev_mem_rsp_err;
    err_set[`SFX_CL_E_HALTED]        = eng_halted && !halted_q;
    err_set[`SFX_CL_E_RESET_ABORT]   = ev_abort_cpl;
    err_set[`SFX_CL_E_DRAIN_TIMEOUT] = do_force;
    err_set[`SFX_CL_E_CSR_DENIED]    = ev_host_deny || ctl_deny;
    err_set[`SFX_CL_E_PROTOCOL]      = ev_unsol || ev_pop_err;
  end

  logic [31:0] status;
  always_comb begin
    status = '0;
    status[`SFX_CL_SB_BUSY]         = busy;
    status[`SFX_CL_SB_ENG_BUSY]     = eng_busy;
    status[`SFX_CL_SB_ENG_HALTED]   = eng_halted;
    status[`SFX_CL_SB_RESETTING]    = (st != `SFX_CL_RS_RUN);
    status[`SFX_CL_SB_ENG_IN_RESET] = eng_rst_q;
    status[`SFX_CL_SB_STREAM_EN]    = stream_q;
    status[`SFX_CL_SB_ADAPTER_IDLE] = ad_idle;
    status[`SFX_CL_SB_CLK_REQ]      = clk_req;
    status[`SFX_CL_SB_DRAINING]     = m_draining;
    status[`SFX_CL_SB_STATE_LSB +: 4] = st;
  end

  always_comb begin
    c_rdata = '0;
    if (c_sel && !c_we) begin
      if (a_id)   c_rdata = `SFX_CL_ID_VALUE;
      if (a_info) c_rdata = INFO;
      if (a_ctl)  c_rdata = {29'd0, clkf_q, 1'b0, stream_q};
      if (a_st)   c_rdata = status;
      if (a_err)  c_rdata = {{(32-`SFX_CL_ERR_W){1'b0}}, err_q};
      if (a_een)  c_rdata = {{(32-`SFX_CL_ERR_W){1'b0}}, err_en_q};
      if (a_cmd)  c_rdata = n_cmds;
      if (a_cpl)  c_rdata = n_cpls;
      if (a_abt)  c_rdata = n_aborts;
      if (a_rst)  c_rdata = n_resets;
      if (a_mi)   c_rdata = {8'd0, 8'(trk_level), 8'(s_out), 8'(m_out)};
    end
  end

  function automatic logic [31:0] sat_inc(input logic [31:0] v, input logic e);
    sat_inc = (e && v != 32'hFFFF_FFFF) ? v + 32'd1 : v;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      stream_q <= (STREAM_DEFAULT != 0);
      clkf_q   <= 1'b0;
      err_q    <= '0;
      err_en_q <= '0;
      halted_q <= 1'b0;
      n_cmds <= '0; n_cpls <= '0; n_aborts <= '0; n_resets <= '0;
    end else begin
      halted_q <= eng_halted;
      if (wr_ok && a_ctl) begin
        stream_q <= c_wdata[0];
        clkf_q   <= c_wdata[2];
      end
      if (wr_ok && a_een) err_en_q <= c_wdata[`SFX_CL_ERR_W-1:0];
      // W1C; a same-cycle set wins
      err_q <= ((wr_ok && a_err) ? (err_q & ~c_wdata[`SFX_CL_ERR_W-1:0]) : err_q) | err_set;
      n_cmds   <= sat_inc(n_cmds,   ev_cmd_accept);
      n_cpls   <= sat_inc(n_cpls,   ev_cpl_deliver);
      n_aborts <= sat_inc(n_aborts, ev_abort_cpl);
      n_resets <= sat_inc(n_resets, seq_done);
    end
  end

  // ============================================================ registered outputs
  wire busy_now = eng_busy || !ad_idle || (m_out != '0) || (s_out != '0) || m_draining || (st != `SFX_CL_RS_RUN);
  wire idle_now = !busy_now && !wake;
  logic [7:0] idle_cnt;
  logic [`SFX_CL_PEV_W-1:0] pev;

  always_comb begin
    pev = '0;
    pev[`SFX_CL_PEV_CMD_ACCEPT]  = ev_cmd_accept;
    pev[`SFX_CL_PEV_CMD_SUBMIT]  = ev_submit;
    pev[`SFX_CL_PEV_CMD_STALL]   = ev_cmd_stall;
    pev[`SFX_CL_PEV_CPL_DELIVER] = ev_cpl_deliver;
    pev[`SFX_CL_PEV_CPL_ERR]     = ev_cpl_err;
    pev[`SFX_CL_PEV_CPL_STALL]   = ev_cpl_stall;
    pev[`SFX_CL_PEV_ENG_BUSY]    = eng_busy;
    pev[`SFX_CL_PEV_MEM_REQ]     = ev_mem_req;
    pev[`SFX_CL_PEV_MEM_STALL]   = ev_mem_stall;
    pev[`SFX_CL_PEV_MEM_RSP]     = ev_mem_rsp;
    pev[`SFX_CL_PEV_MEM_RSP_ERR] = ev_mem_rsp_err;
    pev[`SFX_CL_PEV_LM_REQ]      = ev_lm_req;
    pev[`SFX_CL_PEV_SPM_REQ]     = ev_spm_req;
    pev[`SFX_CL_PEV_RESET]       = (st != `SFX_CL_RS_RUN);
    pev[`SFX_CL_PEV_CLK_REQ]     = clk_req;
    pev[`SFX_CL_PEV_DB_RETRY]    = ev_db_retry;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      irq      <= 1'b0;
      err      <= 1'b0;
      clk_req  <= 1'b1;
      idle_cnt <= '0;
      perf_ev  <= '0;
      busy     <= 1'b0;
    end else begin
      irq      <= eng_irq || ((err_q & err_en_q) != '0);
      err      <= (err_q != '0);
      idle_cnt <= idle_now ? ((idle_cnt == 8'(IDLE_HYST)) ? idle_cnt : idle_cnt + 8'd1) : 8'd0;
      clk_req  <= clkf_q || !idle_now || (idle_cnt != 8'(IDLE_HYST));
      perf_ev  <= pev;
      busy     <= busy_now;
    end
  end
  assign err_status = err_q;
  /* verilator lint_off UNUSEDSIGNAL */
  wire unused_wdata = ^c_wdata[31:`SFX_CL_ERR_W];
  /* verilator lint_on UNUSEDSIGNAL */
endmodule

`default_nettype wire
