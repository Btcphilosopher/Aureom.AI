# 04 — Interface timing, pipeline boundaries, latency

No timing is closed or claimed here: there is no PDK flow in this project (docs/07). This document identifies the
signals that will matter physically and states, for every optional pipeline boundary, what it costs and why
transaction correctness is preserved. Measured numbers come from `reports/regression.json` (`latency` test).

## 1. High-fanout signals

| Signal | Fanout (default 4 V + 2 T) | Treatment |
|---|---|---|
| `clk` | every flop of six regions + shell | clock tree (CTS). Per-region `clk_req` lets a power manager gate a region's branch; no gate cell in RTL |
| `rst_n` (system) | every flop | asynchronous assert, synchronous release upstream (`sfv_rst_sync` convention); buffered reset tree. Not pipelined: async assert must reach everything |
| `eng_rst_n` (per cluster) | one engine | local, registered term (`eng_rst_q`) ANDed with `rst_n`: stays inside its region |
| command bus `i_data[31:0]`, `i_last`, `i_tag` | broadcast to all 6 clusters (41 bits × 6 loads) | `CMD_SLICE` at the shell input; each cluster's input skid is the second register stage, so the broadcast wire runs register → register |
| `csr_addr[12:0]`, `csr_wdata[31:0]`, `csr_we` | broadcast to all clusters | **not registered**: the SilicaFlux-V rb contract answers in the strobe cycle (§3) |
| `port_q` / `quiesce` | inside one cluster (gates, adapter) | registered state decode, local |

## 2. Wide buses

| Bus | Width (default / max) | Where | Boundary option |
|---|---|---|---|
| memory request per cluster | 1 + 32 + `XACT_WIDTH` + `XACT_WIDTH`/8 = 69 / 177 bits | cluster → NoC | `MEM_REQ_SLICE` (+1 cycle) |
| memory response per cluster | `XACT_WIDTH` + 1 = 33 / 129 bits | NoC → cluster | `MEM_RSP_SLICE` (+1 cycle) |
| completion merge | 32 + `TAG_W` + 6 = 46 bits, (clusters + 1):1 mux | shell | `CPL_SLICE` (+1 cycle) |
| CSR read data | 32 bits, (clusters):1 mux | shell | none (§3) |
| tile lanes / scratchpad (inside the region) | `NUM_LANES` × 3 × 32 operand bits, `LSU_P` scratchpad ports | inside `u_engine` | none needed at the region boundary: kept inside the region by construction (docs/05) |
| systolic array operands / partial sums | `ARRAY_ROWS` × 8 + `ARRAY_COLS` × 8 in, `ARRAY_COLS` × 32 out | inside `u_engine.u_dp` | same |
| tensor `perf_ev` | 20 × 32 = 640 bits | **not exported**: the counters are on the engine's PERF page; the cluster exports 16 one-bit events |

## 3. Combinational paths that cross a region boundary

| Path | Why it stays combinational | Mitigation |
|---|---|---|
| `csr_addr` → engine register decode → `csr_rdata` | rb contract (`sfv_periph_bridge`): data in the strobe cycle; registering it is a protocol change | place the shell's CSR decode at the control edge (`R_shell`); a registered CSR bridge is listed in docs/07 |
| `cmd_valid` → router → cluster skid `s_valid` | the skid's `ready` is a register, so only the valid / data path crosses; with `CMD_SLICE = 1` it starts at a register | `CMD_SLICE` |
| cluster `cpl_valid` / data → merge mux → `cpl_*` | outputs come from the record buffer register; the merge mux and `cpl_ready` return are combinational | `CPL_SLICE` |
| memory request / response (zero-latency configuration) | `MEM_*_SLICE = 0` keeps the minimum chip's timing behaviour identical | `MEM_REQ_SLICE`, `MEM_RSP_SLICE` |

`irq`, `err`, `err_status`, `busy`, `clk_req`, `perf_ev` are flop outputs (narrow, registered: they cross the chip to
the ControlCore / power manager / RAS block).

## 4. Pipeline boundaries: correctness argument

All four boundaries reuse **verified DataFabric components** (`sfb_skid_buffer`, formally proven in DataFabric;
`sfb_reg_slice` built from it):

* in order, exactly one output per input, payload stable under back-pressure, full throughput;
* a memory slice holds up to one transaction per channel: the cluster may have that many more transactions in
  flight than the next crossbar port sees (DataFabric PROTOCOL §7). Both engines count their own outstanding
  transactions (M08 DMA `MAX_OUT = 2`, TC08 `MAX_OUT = 4`), and the cluster gate enforces its own `MAX_OUT`, so
  this is legal (and is exercised by the `w64_lm_slc` regression with throttled NoC ports);
* slices sit in the shell (system-reset) domain, behind the cluster reset gate: a cluster reset never drops a
  transaction held in a slice (the gate counts it as outstanding and drains or drops its response).

## 5. Added latency (measured)

Round trip of one command on an idle subsystem, first command word accepted → last completion word delivered,
1-cycle memory (`latency` test). Values are cycles.

| Command | `min` (no boundaries, 32-bit) | `w64_lm_slc` (all four boundaries, 64-bit) | added |
|---|---|---|---|
| vector NOP | 27 | 29 | +2 (command and completion skids) |
| vector DMA, 4 bytes | 36 | 42 | +6 |
| vector KERNEL, VL = 1 | 73 | 81 | +8 |
| tensor NOP | 50 | 52 | +2 |
| tensor GEMM 1×1×1 | 121 | 129 | +8 |
| tensor GEMM 4×4×4 | 169 | 180 | +11 |

A NOP touches no memory, so its +2 is exactly `CMD_SLICE` + `CPL_SLICE`; the remainder of each difference is the
request and response slices on every *sequential* memory transaction of the command (+2 per dependent round trip),
partly hidden by the engines' outstanding windows. Buffering added: one 2-entry skid per sliced channel per port
(request: 1 + 32 + `XACT_WIDTH` + `XACT_WIDTH`/8 bits per entry; response: `XACT_WIDTH` + 1 bits).

Fixed costs of the shell (by construction, cross-checked by the numbers):

| Stage | Cycles | Notes |
|---|---|---|
| command skid | 1 | registered `cmd_ready` |
| descriptor transfer | `CMD_WORDS` (8 vector, 12 tensor) | one staging write per accepted word, overlapped with the stream |
| DOORBELL | 1 | retried while the engine queue is full (`DB_RETRY` event) |
| harvest | ≥ 1 poll + 6 reads + 1 pop = 8 | rb cycles; the host's CSR accesses have priority |
| completion stream | 7 | one word per cycle |
| `CMD_SLICE`, `CPL_SLICE` | +1 each | once per packet |
| `MEM_REQ_SLICE`, `MEM_RSP_SLICE` | +1 each | per memory transaction (overlapped by the engines' outstanding window) |

For comparison, a host submitting through the register page (the minimum chip's legacy path) needs `CMD_WORDS` + 1
writes and 8 record accesses per command over the rb bus — the stream path performs the same accesses inside the
cluster, so the shell adds about 1 + 7 cycles (skid + completion streaming) per command and nothing per memory
transaction in `compute_min`.

## 6. Throughput limits introduced by the shell

* One completion harvest at a time: about 15 cycles per completion (8 rb cycles + 7 output words). For very short
  vector commands (NOP, tiny VL) this, not the engine, bounds the completion rate.
* One word per cycle on the shared subsystem command stream (all clusters together).
* Completions of different clusters are merged one packet at a time (round robin).
