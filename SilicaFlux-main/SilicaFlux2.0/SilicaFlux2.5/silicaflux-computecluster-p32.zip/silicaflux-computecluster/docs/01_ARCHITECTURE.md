# 01 — Architecture

## 1. Three modules, one rule

| Module | Role | Arithmetic inside |
|---|---|---|
| `rtl/silicaflux_vector_cluster.sv` | one FP32 vector region | the HPC Module 08 tile, **unmodified**, as `u_engine` |
| `rtl/silicaflux_tensor_cluster.sv` | one INT8 tensor region | the TENSORCORE 08 unit, **unmodified**, as `u_engine` |
| `rtl/silicaflux_compute_cluster.sv` | integration shell: replicated regions, command router, completion merge, CSR decode | none of its own |

The rule: **no arithmetic pipeline is duplicated or re-implemented.** Every cluster contains exactly one engine;
everything the cluster adds is plumbing (≈ 3–4 % of a cluster's generic cells, `reports/synth.md`).

## 2. A cluster

```
                    ┌──────────────────────── silicaflux_{vector,tensor}_cluster ─────────────────────────┐
 cmd (32b words) ──►│ u_cmd  sfx_cl_cmd_port   skid ─► packet FSM ─► staging words + DOORBELL ──┐         │
 cpl (32b words) ◄──│        record buffer ◄── harvest FSM (STATUS / CPL0..5 / CPL_POP) ◄───────┤ rb page │
 csr [12]=0 ───────►│        host access (priority, ownership rule) ────────────────────────────┤         │
                    │                                                                            ▼         │
                    │                                                    ┌──────── u_engine ──────────┐   │
 spm_* (slave) ────►│ g_spm.u_spm_gate (sfx_cl_slv_gate) ──── hs_* ────►│  M08 tile  /  TC08 unit     │   │
                    │                                                    │  (unmodified)              │   │
 mem_* (master) ◄───│ u_mem (sfx_cl_mem_port) ◄──────── fab_* / m_* ─────┤                            │   │
 lm_*  (master) ◄───│   gate · drain · [32→W lanes] · split · [slices]   └────────────────────────────┘   │
                    │                                                         ▲ eng_rst_n                 │
 csr [12]=1 ───────►│ u_ctrl (sfx_cl_ctrl): CSR page · reset sequencer · sticky errors · irq · clk_req ·   │
 rst_req ──────────►│        perf events (all outputs registered)                                         │
                    └──────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.1 `sfx_cl_cmd_port` — command and completion adapter

* **Command path.** Command words arrive through a two-entry skid buffer (DataFabric `sfb_skid_buffer`, so
  `cmd_ready` is a register output). The packet FSM writes word *i* to the engine's staging register *i*
  (M08 `CMD0..CMD7`, TC08 `DESC0..DESC11`), then writes DOORBELL. A refused DOORBELL (queue full) changes nothing
  in either engine and is retried. A successful DOORBELL pushes `{tag, ENGINE}` into the **tracking FIFO**.
* **Shell records.** A packet whose length differs from the engine's descriptor length (`BAD_LENGTH`), a packet
  while stream mode is off (`STREAM_OFF`), or a command destroyed by a cluster reset (`RESET_ABORT`) is pushed into
  the tracking FIFO as a shell record. So **every accepted packet produces exactly one completion, in order**.
* **Completion path.** When the FIFO head is an engine entry, the harvest FSM polls STATUS.CPL_VALID, reads the
  six record words into the record buffer, writes CPL_POP and pops the FIFO. The buffer is streamed out as a
  7-word completion packet (header + engine record). Order is correct because both engines produce exactly one
  record per accepted command, in submission order.
* **Register-bus arbitration.** Host CSR access has absolute priority (the rb contract has no wait state); the
  adapter's own accesses (init write > {command side, completion side} round robin) take the free cycles.
* **Ownership rule.** In stream mode the host may not write the staging registers, DOORBELL, CPL_POP, or the M08
  CTRL.SOFT_RESET bit (it would destroy records): such writes answer `rb_err` and set `CL_ERR.CSR_DENIED`.
  Everything else of the engine page (IDs, configuration, status, interrupts, counters, M08 RESUME / FLUSH,
  TC08 ABORT / ERR_CLEAR) stays available.
* **Init write.** After every engine reset (and when stream mode is enabled) the adapter writes the engine's
  "commands are independent" setting once: M08 `CFG = 0` (HALT_ON_ERROR off), TC08 `CTRL = 1` (ERR_CONT). Requests
  from different requesters then never block one another through stop-on-error.

### 2.2 `sfx_cl_mem_port` — memory boundary (NoC-facing)

`gate` (quiesce, MAX_OUT limit, target-switch interlock, outstanding counter, forced drain, captured request)
→ `up` (EW → DW lane steering, tensor unit only) → `split` (`LOCAL_MEM_EN`: the LM window goes to `lm_*`)
→ DataFabric `sfb_reg_slice` per port (`MEM_REQ_SLICE` / `MEM_RSP_SLICE`). With everything off it is wires plus
counters: **zero added latency** on the memory path of the minimum configuration.

### 2.3 `sfx_cl_slv_gate` — scratchpad window (vector clusters)

Pass-through for the NoC's accesses to the tile scratchpad (`hs_*`), with a quiesce gate. After a forced reset a
response the engine was presenting to a stalled master is captured and kept on the port unchanged (SFB2 R4), and any
access the engine accepted but never answered gets an error response from the gate (R5).

### 2.4 `sfx_cl_ctrl` — local control

Cluster CSR page, reset sequencer, sticky errors, `irq` / `err` / `err_status`, `clk_req`, `busy`, perf events.
The engine reset is `eng_rst_n = rst_n & !eng_rst_q`: asynchronous assertion by the system reset, otherwise a
registered, glitch-free term (the convention of TC08's own datapath soft reset).

**Reset sequence** (`cl_rst_req` pin, level; or `CL_CTRL.RESET`):

| State | What happens | Leaves when |
|---|---|---|
| RUN | normal | a request |
| Q_CMD | adapter starts no DOORBELL / harvest; new packets wait | the adapter is not inside a harvest (`safe`) |
| Q_MEM | memory and scratchpad ports accept nothing new; in-flight transactions complete normally | both ports quiet, or `2^DRAIN_LOG2` cycles (forced: `DRAIN_TIMEOUT`) |
| RESET | engine reset asserted ≥ `RST_CYCLES` (and while the pin is high); every tracked command becomes RESET_ABORT | count done and pin low |
| RELEASE | engine out of reset, 2 settle cycles; the adapter performs its init write | → RUN |

A forced reset never withdraws a presented request: the memory port keeps it on the NoC from a shell register
and drops its response (and every other late response); the scratchpad port delivers a held response unchanged
and answers any unanswered access with an error. Nothing in the shell (FIFOs, slices, counters, error bits) is reset by a cluster reset.

## 3. The integration shell

* **Slots.** One macro per slot creates generate scopes `u_vector_0 … u_vector_7` and `u_tensor_0 … u_tensor_3`,
  each holding the cluster instance `u_cl`; a slot whose index is not below `NUM_*_CLUSTERS` is not elaborated.
  Names never depend on the configuration (docs/05).
* **Addressing.** `cmd_dest`, `cpl_src`, CSR slot: `{type, index}` = 0..7 vector *k*, 8..11 tensor *k*.
* **Command router.** Packet-locked demultiplexer on the first word's `cmd_dest`; words of one packet are never
  split. An absent slot is answered by a small BAD_DEST sink (absorbs the packet, returns a shell record).
* **Completion merge.** Packet-locked round robin over the clusters and the sink; a source that has presented a
  word keeps the grant until its last word (stream rule S1).
* **CSR.** `csr_addr[16:13]` slot, `[12]` page (0 engine, 1 cluster control), `[11:0]` register; absent slot →
  `csr_err`.
* **Optional pipeline boundaries**: `CMD_SLICE`, `CPL_SLICE` (skid buffers at the subsystem stream ports),
  `MEM_REQ_SLICE`, `MEM_RSP_SLICE` (every cluster memory port). docs/04.

## 4. Parameters

| Parameter | Range | Default | Notes |
|---|---|---|---|
| `NUM_VECTOR_CLUSTERS` | 0..8 | 4 | slots `u_vector_0..7` |
| `NUM_TENSOR_CLUSTERS` | 0..4 | 2 | slots `u_tensor_0..3` |
| `VEC_NUM_LANES` | 1, 2, 4, 8, 16 | 4 | M08 `NUM_LANES` |
| `TEN_ARRAY_ROWS` × `TEN_ARRAY_COLS` | 2×2, 4×4, 8×8 (others need `TEN_ALLOW_UNVERIFIED`) | 4×4 | TC08 PE array |
| `VEC_SCRATCHPAD_BYTES`, `VEC_NUM_BANKS` | M08 rules | 65 536, 4 | scratchpad capacity |
| `TEN_OPERAND_BUFFER_BYTES`, `TEN_TILE_K`, `TEN_NUM_MEMORY_BANKS` | TC08 rules | 2048, 64, 4 | operand storage |
| `TEN_ENABLE_QUANTIZATION`, `TEN_ENABLE_DOUBLE_BUFFERING` | 0 / 1 | 0 | TC08 options |
| `XACT_WIDTH` | 32, 64, 128 | 32 | every memory port; tile `DATA_WIDTH`, tensor lanes steered |
| `LOCAL_MEM_EN`, `LOCAL_MEM_BASE / STRIDE / MASK` | 0 / 1 | 0 | per-slot local memory window |
| `VEC_SPM_PORT_EN`, `VEC_SPM_BASE / STRIDE` | | 1 | scratchpad window per vector slot |
| `MEM_REQ_SLICE`, `MEM_RSP_SLICE`, `CMD_SLICE`, `CPL_SLICE` | 0 / 1 | 0 | pipeline boundaries |
| `TAG_W`, `TRK_DEPTH` | 1..32, 2..256 (2^n) | 8, 16 | completion routing |
| `STREAM_DEFAULT`, `RST_CYCLES`, `DRAIN_LOG2`, `IDLE_HYST` | | 1, 4, 12, 16 | local control |

Illegal values stop elaboration in Verilator, Icarus and Yosys (`reports/lint.md`). The engines' own parameter
checks still apply unchanged.

## 5. What this architecture deliberately does not do

* No new compute: performance per engine is exactly TC08's / M08's (docs/07).
* No caches, no coherence: software owns data placement, as in TC08 doc 06.
* No clock gating cell: `clk_req` is a request for an external power manager (P27 POWERCLOCK style).
* No physical coordinate in RTL: regions are generated constraints (docs/05).
