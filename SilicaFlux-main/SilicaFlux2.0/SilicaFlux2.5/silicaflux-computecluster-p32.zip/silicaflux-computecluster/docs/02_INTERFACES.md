# 02 — Cluster interfaces

Single source of the encodings: `rtl/sfx_cl_defs.svh`. Engine descriptor and record formats are the engines' own,
unchanged: HPC Module 08 `third_party/silicaflux-hpc-m08-tile/docs/02_commands.md`, TENSORCORE 08
`third_party/silicaflux-tensorcore08/docs/02_COMMAND_ABI.md`.

## 1. Port groups of one cluster

Every cluster (`silicaflux_vector_cluster`, `silicaflux_tensor_cluster`) has the same groups; the shell
(`silicaflux_compute_cluster`) exposes them per slot as arrays (`vec_*`, `ten_*`) plus one merged stream pair.

| Group | Signals | Direction | Registered at the boundary? |
|---|---|---|---|
| Clock / reset | `clk`, `rst_n` (system: async assert, sync release), `rst_req` (cluster reset, level) | in | — |
| Command request | `cmd_valid`, `cmd_ready`, `cmd_data[31:0]`, `cmd_last`, `cmd_tag[TAG_W-1:0]` | in / out | `cmd_ready` yes (skid buffer) |
| Command completion | `cpl_valid`, `cpl_ready`, `cpl_data[31:0]`, `cpl_last`, `cpl_tag`, `cpl_err` | out / in | yes (record buffer) |
| CSR | `csr_sel`, `csr_we`, `csr_addr[12:0]`, `csr_wdata`, `csr_rdata`, `csr_err` (SilicaFlux-V rb contract) | in / out | no — combinational read by contract (docs/04 §3) |
| Memory (NoC) | `mem_req_*`, `mem_rsp_*` — SFB2 master, `XACT_WIDTH` data | out / in | with `MEM_REQ_SLICE` / `MEM_RSP_SLICE` |
| Local memory | `lm_req_*`, `lm_rsp_*` — SFB2 master (tied off when `LOCAL_MEM_EN = 0`) | out / in | same |
| Scratchpad window (vector) | `spm_req_*`, `spm_rsp_*` — SFB2 slave into the tile scratchpad | in / out | no (pass-through gate) |
| Interrupt / error | `irq`, `err`, `err_status[7:0]` | out | yes |
| Status | `busy`, `clk_req` | out | yes |
| Performance events | `perf_ev[15:0]`, one bit per event per cycle | out | yes |

## 2. Command stream

* valid/ready; a word transfers when `cmd_valid && cmd_ready` at a rising edge. **S1**: a presented word stays
  presented with unchanged payload until accepted. Packets are contiguous; `cmd_last` marks the final word.
* `cmd_tag` is sampled with the first word and returned with the completion; it is opaque to the cluster
  (uniqueness not required: completions are ordered per cluster).
* Packet = the engine descriptor, unchanged:

| Engine | Words | Content |
|---|---|---|
| vector (M08 tile) | 8 | W0..W7 of the M08 descriptor (TYPE / VOP / RM / BCAST / RED / TAG / FENCE, VL/LEN, SCALAR, A, B, C, D, STAGE) |
| tensor (TC08 unit) | 12 | DESC0..DESC11 of the TC08 v2 descriptor (OPCODE / VERSION / RM / FLAGS / TID, bases, M N K KC, strides, formats, quantisation) |

* At the shell: `cmd_dest[3:0]`, sampled with the first word, selects the cluster (0..7 vector *k*, 8..11 tensor
  *k*). The router never splits a packet.
* **No circular dependency allowed:** the requester must accept completions independently of whether it can
  send commands (`cpl_ready` must not wait for `cmd_ready`).

## 3. Completion stream

Every accepted command packet produces **exactly one** completion packet of 7 words, **in acceptance order per
cluster**. Across clusters, packets interleave (round robin) but are never split.

| Word | Content |
|---|---|
| 0 — header | `[3:0]` CL_STATUS, `[4]` ERR (error summary), `[11:8]` engine (1 vector, 2 tensor, 0 shell), `[15:12]` engine words (6), `[23:16]` CLUSTER_ID (= slot code), `[31:24]` cluster ABI version (1) |
| 1..6 | the engine's own record, unchanged (M08: CPL_INFO, SEQ, COUNT, RESULT, ERR_ADDR, CYCLES; TC08: CPL0..CPL5); zero for shell records |

| CL_STATUS | Name | Engine executed? | ERR |
|---|---|---|---|
| 0 | ENGINE | the engine accepted the command; its record tells OK / error | engine error field ≠ 0 (M08 STATUS ≠ OK, TC08 STATUS ≠ OK) |
| 1 | BAD_LENGTH | no (packet length ≠ descriptor length) | 1 |
| 2 | RESET_ABORT | maybe partially: destroyed by a cluster reset before its record was read | 1 |
| 3 | STREAM_OFF | no (stream mode disabled) | 1 |
| 4 | BAD_DEST | no (shell: no cluster at `cmd_dest`) | 1 |

`cpl_err` repeats header bit 4 on every word, so a requester can route errors without decoding the record.
At the shell `cpl_src[3:0]` names the producing slot.

## 4. CSR window (8 KiB per cluster; 128 KiB for the shell)

| `csr_addr` | Page |
|---|---|
| `[16:13]` (shell only) | slot code; absent slot → `csr_err` |
| `[12] = 0` | the engine's own 4 KiB register page, unchanged, with the ownership rule below |
| `[12] = 1` | cluster control page |

**Ownership rule (stream mode).** Writes to the staging registers, DOORBELL, CPL_POP and (M08) CTRL.SOFT_RESET
answer `csr_err` with no effect and set `CL_ERR.CSR_DENIED`. While the engine is held in reset every engine-page
access answers `csr_err`. With `CL_CTRL.STREAM_EN = 0` the engine page is fully the host's (legacy path, §7).

### Cluster control page

| Offset | Name | Access | Content |
|---|---|---|---|
| 0x000 | CL_ID | RO | `0x5346434C` "SFCL" |
| 0x004 | CL_INFO | RO | [7:0] CLUSTER_ID, [11:8] engine, [15:12] ABI, [16] LOCAL_MEM_EN, [17] SPM_PORT_EN, [18] MEM_REQ_SLICE, [19] MEM_RSP_SLICE, [31:24] XACT_WIDTH/8 |
| 0x008 | CL_CTRL | RW | [0] STREAM_EN (a change is refused unless the adapter is idle and no reset runs), [2] CLKREQ_FORCE; write-1 pulse [1] RESET |
| 0x00C | CL_STATUS | RO | [0] BUSY [1] ENG_BUSY [2] ENG_HALTED [3] RESETTING [4] ENG_IN_RESET [5] STREAM_EN [6] ADAPTER_IDLE [7] CLK_REQ [8] DRAINING [15:12] sequencer state |
| 0x010 | CL_ERR | W1C | sticky error bits (§5); a same-cycle set wins |
| 0x014 | CL_ERR_EN | RW | `irq` enable per error bit |
| 0x018 | CL_CMDS | RO | command packets accepted (saturating) |
| 0x01C | CL_CPLS | RO | completion packets delivered |
| 0x020 | CL_ABORTS | RO | RESET_ABORT completions |
| 0x024 | CL_RESETS | RO | reset sequences completed |
| 0x028 | CL_MEMINFO | RO | [7:0] memory transactions outstanding, [15:8] scratchpad-port outstanding, [23:16] tracked commands |

Unmapped offsets, writes to RO registers and refused STREAM_EN changes answer `csr_err`.

## 5. Interrupt and error status

| Bit | Name | Set by |
|---|---|---|
| 0 | CPL_ERR | a completion with ERR = 1 was delivered |
| 1 | BAD_CMD | BAD_LENGTH or STREAM_OFF packet |
| 2 | MEM_ERR | an SFB2 error response reached the cluster (NoC or local port) |
| 3 | HALTED | the engine entered HALTED (TC08: bus could not be drained; M08: halt-on-error) |
| 4 | RESET_ABORT | a reset destroyed accepted commands |
| 5 | DRAIN_TIMEOUT | a reset was forced: late responses are being dropped |
| 6 | CSR_DENIED | a host write refused by the ownership rule or a refused STREAM_EN change |
| 7 | PROTOCOL | unsolicited memory response, or the engine refused CPL_POP (never expected) |

`err_status` = CL_ERR (register), `err` = OR(CL_ERR) (registered), `irq` = registered OR of the engine's own `irq`
(its INT/IRQ registers, unchanged) and `CL_ERR & CL_ERR_EN`. The shell adds registered `err_any` / `irq_any`.

## 6. Performance events, busy, clock-enable request

`perf_ev` (registered, one cycle late): 0 CMD_ACCEPT, 1 CMD_SUBMIT, 2 CMD_STALL, 3 CPL_DELIVER, 4 CPL_ERR,
5 CPL_STALL, 6 ENG_BUSY, 7 MEM_REQ (NoC handshake), 8 MEM_STALL, 9 MEM_RSP, 10 MEM_RSP_ERR, 11 LM_REQ, 12 SPM_REQ,
13 RESET, 14 CLK_REQ, 15 DB_RETRY. The engines' detailed counters stay on their PERF pages (M08 24 counters, TC08 20
+ 18 DMA counters); the tensor unit's `perf_ev` bus is not exported (640 bits per cluster, docs/04).

`busy` = engine busy or anything tracked, buffered or outstanding, or a reset running.
`clk_req` (advisory, registered) drops after `IDLE_HYST` idle cycles. The cluster has **no clock gate**: an external
controller may gate its clock while `clk_req = 0`, and must ungate on its own on `cmd_valid`, `csr_sel`,
`spm_req_valid` or `rst_req` (the cluster cannot see them while gated). Verified by the `clkgate` test (docs/06).

## 7. Memory ports

SFB2 (DataFabric PROTOCOL.md) unchanged: R2 no withdrawal, R5 one in-order response per request, R7 write
completion, R8 error responses with zero data, R9 `XACT_WIDTH`-aligned addresses. The cluster keeps at most
`MEM_MAX_OUT` (vector) / `ENG_MAX_OUT` (tensor) transactions in flight and **never switches between the NoC and
the local port while a transaction is outstanding**, so the two ports cannot reorder responses. With slices the
cluster has more transactions in flight than a DataFabric crossbar port sees (PROTOCOL §7) — both engines track
their own outstanding count, so this is legal.

Tensor clusters at `XACT_WIDTH` 64 / 128: each 32-bit access is placed on its byte lanes (address aligned down,
data replicated, strobes shifted, read lane selected); one beat per access, no packing.

## 8. Compatibility with the minimum chip configuration

* Engines, register pages and descriptor / record ABIs are unchanged; with `CL_CTRL.STREAM_EN = 0` (or
  `STREAM_DEFAULT = 0`) the host / ControlCore firmware drives the engine page exactly as before (staging,
  DOORBELL, CPL, CPL_POP) — tested for both engines (`csr` test).
* `compute_min` adds **no latency** to the memory path (no slices, no local port) and leaves the engine's interrupt
  output in `irq`.
* What changes for an existing integrator: the engine page moves into the cluster's 8 KiB window (`[12] = 0`), and
  the engine sits behind `u_mem` (pass-through counters and a quiesce gate).
