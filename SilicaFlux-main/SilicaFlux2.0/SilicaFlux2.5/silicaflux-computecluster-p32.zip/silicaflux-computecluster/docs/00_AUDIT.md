# 00 — Audit of the compute RTL this project builds on

Everything below was inspected in the archives of `btcphilosopher/Aureom.AI` (`SilicaFlux-main/`,
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`) before any Project 32 RTL was written. Evidence files:
`reports/audit/`.

## 1. What exists and where

| Item in the brief | Found in | What it is | Interfaces relevant here |
|---|---|---|---|
| `hpc_vector_array.sv` | HPC Module 03 (`silicaflux-hpc-m03-vector-array.zip`), vendored unmodified by M08 | `NUM_LANES` Module 02 FP32/INT32 lanes, issue / collect / reduce, defined-order FP reduction | command / operand / result / completion valid-ready streams; **no bus port**: it lives inside the tile as `g_core.u_array` |
| `silicaflux_hpc_tile.sv` | HPC Module 08 (`silicaflux-hpc-m08-tile.zip`) | complete FP32 vector tile: register page, command + completion queues (M06), scheduler with ROB and hazard check, LSU, M03 array, M04 banked scratchpad, M05 DMA adapter (DataFabric DMA engine), M07 counters, soft-reset sequencer | SilicaFlux-V `rb` page (4 KiB, combinational read), SFB2 master `fab_*` (DMA), SFB2 slave `hs_*` (host scratchpad window), `irq` / `busy` / `halted`. **No performance-event port** (counters are read on the PERF page). |
| `silicaflux_tensor_unit.sv` | TENSORCORE 08 (`silicaflux-tensorcore08.zip`) | complete INT8 GEMM unit: TC02 systolic array, TC03 operand buffers, TC04 accumulator, TC05 quantiser, TC07 DMA / output buffer / sequencer, M08 queues + counters | `rb` page, one **32-bit** SFB2 master `m_*`, `irq` / `busy` / `halted`, `perf_ev` (20 × 32-bit increments) |
| TensorCore verification | TC08 `reports/` | stage 1–3 regression 111/111, Icarus vs Verilator 112/112, coexistence with the M08 tile 9/9, 25/26 mutants killed | — |
| Scratchpad interfaces | HPC Module 04 (`silicaflux-hpc-m04-scratchpad.zip`), inside the tile as `g_core.u_spm` | `NUM_PORTS` valid/ready ports (LSU ports, DMA port, host port), `NUM_BANKS` 1RW banks, per-bank round robin, `WRITE_ACK = 1`, banks from the SRAM Wrapper Library (GENERIC / FPGA / ASIC) | internal to the tile; reachable from outside only through the tile's `hs_*` window and DMA |
| DataFabric | `silicaflux-datafabric.zip` | SFB2 protocol (rules R1–R12), `sfb_crossbar` (one transaction per port, round robin), `sfb_reg_slice` / `sfb_skid_buffer` (formally proven skid), `sfb_sram_slave`, `sfb_protocol_checker` | SFB2 valid/ready request + response with back-pressure; **R11: reset cancels transactions in flight** — so a per-cluster reset needs a quiesce/drain gasket (this project) |
| Actual synthesis results | TC08 `reports/synth.md`, M08 `reports/synth.md`, FloorplanLab (P05) | TC08 baseline: ECP5 23 711 LUT4 / 10 620 FF; SKY130 smoke test 154 882 cells (buffers as flip-flops); M08 baseline: Xilinx 29 091 LUT / 10 136 FF, ECP5 41 610 LUT4; M08 notes that flattened generic ABC mapping took > 10 min and was cut; FloorplanLab: OpenROAD on IHP SG13G2 for SilicaFlux-V (a different, smaller design) | — |

## 2. Integration status found

* **Minimum chip configuration** = the system that every later project runs: ControlCore (P21) driving **one**
  M08 tile (4 lanes, 32-bit, 64 KiB scratchpad) and **one** TC08 unit (4 × 4), on the DataFabric crossbar; P22
  carries the same two engines unmodified on its NoC; the P30 runtime drives them through their register pages.
  This project's `compute_min` configuration (`NUM_VECTOR_CLUSTERS = 1`, `NUM_TENSOR_CLUSTERS = 1`) is that pair.
* No multi-instance compute subsystem exists in the repository: no project instantiates more than one tile or
  more than one tensor unit, no stable instance naming, no region constraints.
* The engines expose different command transports (8-word vs 12-word descriptors on their own register pages)
  and different perf interfaces (none vs `perf_ev`).

## 3. Byte identity of the reused RTL

`reports/audit/byte_identity.txt`: the tile and tensor-unit sources vendored by TC08, P21 (ControlCore) and P28
(SecureBoot) are byte-identical to the M08 / TC08 archives; the DataFabric files vendored here (`sfb_reg_slice`,
`sfb_skid_buffer`, crossbar, protocol checker) are byte-identical to the DataFabric archive. `third_party/` is a
byte-for-byte copy (`third_party/SHA256SUMS`, `third_party/PROVENANCE.md`).

## 4. Re-run of the components before any new code

Run in this environment (Ubuntu 24.04 packages: Verilator 5.020, Icarus 12, Yosys 0.33):

| Check | Result | Log |
|---|---|---|
| TC08 `make quick`: ABI check, lint of 11 legal configurations, 18 illegal configurations rejected, stage 1 | 11/11, 18/18, **2/2** | `reports/audit/tc08_make_quick.log` |
| TC08 `run_system.py`: M08 tile + tensor unit + host on the DataFabric crossbar, 3 seeds × 3 memory/traffic profiles | **9/9** | `reports/audit/tc08_system.log` |

## 5. Consequences for the design

1. **Reuse unmodified.** Both engines are wrapped, never edited; the arithmetic pipelines appear exactly once per
   cluster (`u_engine`).
2. **Command transport.** A uniform cluster command/completion stream is built on top of each engine's *existing*
   register-page ABI (staging words + DOORBELL; STATUS.CPL_VALID + CPL words + CPL_POP). Both engines guarantee one
   record per accepted command in submission order (M08 doc 02 §4, TC08 doc 02 §5), which makes an in-order tag
   FIFO a correct completion router.
3. **Per-cluster reset** must not cut SFB2 transactions on the NoC (R11 applies to the whole fabric only): the
   memory and scratchpad ports need a quiesce / drain gasket in the always-on shell, and commands destroyed by the
   reset must still complete (RESET_ABORT), because the engines produce no record for them.
4. **Width.** The tensor unit is 32-bit only (TC08 R10); with 64/128-bit transactions its port needs lane steering.
5. **Synthesis.** Flattened ABC mapping of a tile is slow (M08); keep the hierarchy (also needed so that every
   region keeps its name in the netlist) and keep inferred memories as `$mem_v2` cells (future SRAM macros).
6. **Physical names.** OpenROAD only sees region prefixes if the netlist is hierarchical when linked
   (FloorplanLab used ORFS `SYNTH_HIERARCHICAL=1`); ODB escapes `[` `]` in instance names.
