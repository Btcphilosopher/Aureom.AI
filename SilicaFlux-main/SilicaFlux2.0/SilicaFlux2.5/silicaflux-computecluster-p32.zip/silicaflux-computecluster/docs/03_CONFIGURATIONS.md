# 03 — Cluster configuration files

`config/<name>.json` describes one configuration of `silicaflux_compute_cluster`: the RTL parameters, the memory
map the testbench and the tensor windows assume, and the physical topology proposal that
`scripts/gen_physical.py` turns into region constraints. Nothing in a configuration file is a coordinate.

| File | Configuration | Synthesized (`syn/run_synth.py` target) | Regression configuration |
|---|---|---|---|
| `compute_min.json` | **minimum chip**: 1 vector (4 lanes, 64 KiB scratchpad) + 1 tensor (4×4), 32-bit, no slices, no local memory | `compute_min` | `min` (+ `min_gate` with the clock gated by `clk_req`) |
| `compute_hpc.json` | **default HPC**: `u_vector_0..3` + `u_tensor_0..1`, 32-bit | `compute_hpc` | `hpc` |
| `compute_wide.json` | HPC with 64-bit transactions, local memory ports and all four pipeline boundaries | not synthesized (no constraints generated) | `w64_lm_slc` covers the same features with 2 V + 1 T |

## Fields

| Field | Meaning |
|---|---|
| `params` | parameter overrides of `silicaflux_compute_cluster` (docs/01 §4) |
| `memory_map` | tensor legal window (`TEN_MEM_LO/HI`), vector scratchpad windows (`VEC_SPM_BASE + k · VEC_SPM_STRIDE`), local memory windows (`LOCAL_MEM_BASE + slot · LOCAL_MEM_STRIDE`, slot = 0..7 vector, 8..11 tensor) |
| `physical.rows` | slot names per row, north to south; a horizontal NoC channel runs between two rows (or along the south edge for one row) |
| `physical.shell_strip`, `physical.channel` | fractions of the core width / height for the shell strip (control edge) and the NoC channel |
| `physical.control_edge`, `physical.noc_edge` | which side faces the control plane / the NoC |
| `groups.vector`, `groups.tensor` | intra-cluster instance groups (COMPUTE, SPM, NOC_IF, CTRL / CORE, NOC_IF, CTRL): member instance prefixes relative to the cluster root, as named in the synthesized hierarchy; anything not listed falls into CTRL |

## Other parameter sets that were exercised

The regression and lint flows use further parameter sets directly (`scripts/run_tests.py`, `scripts/run_lint.py`):
8 V + 4 T (`max`), vector-only and tensor-only subsystems, 128-bit transactions with 8 lanes and an 8×8 array, TC08
quantisation and double buffering, a vector cluster without scratchpad port, a 128-bit tensor cluster with request
slices, and 13 illegal sets that must be refused.
