# 06 — Verification

Results: `reports/regression.md`, `reports/lint.md`, `reports/mutation.md`, `reports/SUMMARY.md`.

## 1. Testbench (`tb/tb_cc.sv`)

```
 issuer (clocked FSM) ─► DUT cmd ──► u_vector_k / u_tensor_k ──► DUT cpl ─► receiver + scoreboard
 DUT NoC ports ─► SFB2 protocol checker ─► tb_sfb_throttle ─► DataFabric sfb_crossbar ─┬─► shared SRAM (tb_sfb_mem)
 tb host master (random contention traffic, directed scratchpad accesses) ─────────────┤
                                                                                       └─► vector k scratchpad windows
 DUT local-memory ports ─► SFB2 protocol checker ─► local SRAM per cluster (tb_sfb_mem)
```

* **The NoC is the real DataFabric crossbar** (unmodified), one round-robin arbiter per slave, one transaction per
  port — every cluster contends for the one shared SRAM.
* **Golden memory image.** All memory (shared SRAM + every local memory) is one byte array. Inputs are random
  initial contents or written by the command builder; expected outputs are computed when a command is built
  (INT8 GEMM in INT32; integer vector ops; FP32 ops on small integers, which are exact; FP reductions exact below
  2^24; byte-exact DMA copies). **The whole image is compared at the end**; regions of commands that ended in a
  reset abort or a bus error are excluded, regions of commands rejected by validation must be *unchanged*.
* **Completion checks, every packet**: 7 words; constant `cpl_src` / `cpl_tag` / `cpl_err` inside the packet; the
  per-cluster order equals the acceptance order; tag; header ABI / engine / cluster id / word count; `cpl_err` equals
  header ERR; engine record: M08 VALID, TAG echo, STATUS; TC08 TID echo, STATUS, ERR_CODE; reduction RESULT; shell
  records all-zero.
* **Protocol checkers** (DataFabric `sfb_protocol_checker`, unmodified) on every cluster NoC port, local port,
  scratchpad port and the host port: R2, R4, R5, R6, R8, X. **Stream monitors** on the command and completion
  streams (S1 stability, S3 packet length, X).
* **White-box drain check**: while a cluster's ports are quiesced (`u_vector_k.u_cl.port_q` /
  `u_tensor_k.u_cl.port_q`, probed through the same slot names), a request may appear at its NoC port only if it
  was already presented, un-accepted, in the previous cycle.
* Any `$error` of the reused RTL or of a checker (e.g. the tensor unit's own "unsolicited SFB2 response") fails the
  run, even when the scoreboard is satisfied.
* **Back-pressure**: `tb_sfb_throttle` withholds requests / responses that have not been presented yet; memory
  `req_ready` withheld randomly; latency + jitter; random `cpl_ready`; random gaps in the command stream.
* Deterministic: one xorshift stream per testbench process (builder, issuer, receiver, host), each drawn
  unconditionally or behind an explicit `if`; clocked testbench processes act on the rising edge, the scenario code
  samples and publishes at the falling edge. Icarus and Verilator therefore see identical stimulus; the
  cross-simulation table in `reports/regression.md` compares cycle counts and completion counts.
* Golden FP32 results follow IEEE 754 including signed zeros (0 × negative = −0).

## 2. Scenarios versus the brief (§9)

| Brief item | Test(s) | What is checked |
|---|---|---|
| single-cluster operation | `smoke`, `single_vec`, `single_ten` | NOP, DMA (1 to 1000 bytes), KERNEL IADD / IMUL / FADD / FMUL / FMADD, FP reductions, scratchpad DMA→VEC→DMA chains with FENCE; GEMMs 1×1×1, 4×4×4, 8×8×16, 17×13×29, 32×32×64, 5×9×130 |
| multiple replicated clusters | `multi` in `hpc` (4 V + 2 T), `max` (8 V + 4 T, Icarus), `vec_only`, `ten_only` | interleaved batches on every slot; ≥ 2 vector and ≥ 2 tensor engines busy in the same cycle (required) |
| simultaneous vector and tensor commands | `mixed` | vector and tensor engines busy in the same cycle (required) |
| SRAM contention | `contention` | every cluster plus 40 % random host traffic on the one shared SRAM behind the crossbar, 2-cycle memory + jitter; host reads shadow-checked |
| back-pressure | `backpressure` | 30 % throttled NoC requests and responses, 25 % memory stalls, 40 % `cpl_ready` low, 30 % command gaps |
| completion routing | `routing` | short commands to every slot, absent destinations (BAD_DEST), wrong packet lengths (BAD_LENGTH), interleaved with real commands; src / tag / per-cluster order (completion back-pressure is exercised by `backpressure`) |
| cluster reset | `reset`, `reset_drain` | pin reset of tensor 0 and CSR reset of vector 0 during long commands (3-cycle memory with jitter, so requests outpace responses; the reset must drain without being forced), with scratchpad-port traffic into the cluster being reset; RESET_ABORT for destroyed commands, nothing lost, other clusters unaffected, the reset clusters work afterwards; forced drain with frozen NoC responses (DRAIN_TIMEOUT, captured request, late responses dropped); forced reset while a stalled master holds a scratchpad-window response (delivered unchanged as data, no R4 violation) |
| error propagation | `errors` | M08 BAD_TYPE, BAD_OP (integer reduction), DMA_ERR (unmapped address); TC08 VERSION, DMA_READ; independent commands still OK; `err`, `err_status`, `irq` with CL_ERR_EN, `err_any`; ownership-rule refusals; W1C clear |
| parameter configurations | 8 configurations | 32 / 64 / 128-bit transactions, 4 / 8 lanes, 2×2 / 4×4 / 8×8 arrays, local memory on / off, every slice on / off, 0..8 vector and 0..4 tensor slots |
| (extra) CSR and compatibility | `csr` | engine and cluster IDs on every slot; absent slot refused; legacy register-page submission with stream mode off, both engines; STREAM_OFF; STREAM_EN change refused while busy |
| (extra) clock-enable request | `clkgate` (`min_gate`) | the whole DUT clock gated by OR(`clk_req`) + wake events (latch-based ICG model); commands still complete correctly and the clock was gated |
| (extra) local memory | `localmem` | operands / results in each cluster's local SRAM mixed with shared-SRAM commands (target-switch interlock) |
| (extra) latency | `latency` | round trip of single commands, fed into docs/04 |

## 3. Other evidence

* **Lint / elaboration** of 12 legal configurations with 0 warnings in new RTL, and 13 illegal configurations
  refused by Verilator, Icarus and Yosys (`scripts/run_lint.py`).
* **Icarus cross-simulation** of the minimum configuration (8 scenarios): all pass in both simulators with the same
  completion counts and statuses; 7 of 8 are cycle-identical. In `routing` the cycle counts differ (Verilator 1056,
  Icarus 1027). Traced to the first divergence: at cycle 82 the reused, unmodified TENSORCORE 07 DMA inside the
  tensor unit reads one A word twice under Verilator and once under Icarus (re-reading a word shared by two short rows
  is legal, TC08 doc 02 §2); the Verilator run gives 1056 cycles with zero, one and random initialisation of every
  register, so it is not an initial-state dependence of two-state simulation. Left as an observation on the reused
  engine (four-state evaluation), not investigated further here.
* **`max` configuration (8 V + 4 T)** under Icarus: its Verilator build exceeds the machine's 15 GB RAM.
* **Mutation testing** (`scripts/run_mutants.py`, Icarus): 13 deliberate bugs in the new RTL (reset-abort
  conversion, ownership rule, length check, error summary, tag capture, drain / quiesce / force logic, owed error
  responses, held-response capture, merge lock, router slot decode, init write) must make a test fail. The first
  campaign left `no_owe_error` alive; analysing it exposed a real defect — a scratchpad response held by a stalled
  master at a forced reset would have been replaced by an error response (SFB2 R4 violation). The gate now captures
  such a response, `reset_drain` tests it, and the new `no_rsp_capture` mutant is killed by the DataFabric protocol
  checker. `no_owe_error` itself remains alive and is analysed as unreachable with a working engine
  (`reports/mutation.md`).
* **Offline execution of the generated constraint Tcl** against the synthesized names (docs/05 §6).

## 4. Not verified

* No formal proof of the new RTL (the reused skid buffer is formally proven in DataFabric).
* No gate-level simulation.
* The scratchpad windows of vector clusters are exercised by the tb host (directed and during reset); tile-to-tile
  DMA through the NoC is possible by construction but not tested.
* `TEN_ENABLE_QUANTIZATION` / `TEN_ENABLE_DOUBLE_BUFFERING` are elaborated and synthesized here but their behaviour
  is only TC08's own regression (stage 3, 49 / 49).
