# 07 — Known limitations and honest scope

## What is not claimed

* **No silicon area, frequency or power.** Synthesis is Yosys generic (technology-independent gates, inferred
  memories kept as `$mem_v2`). The gate counts are not standard cells and not µm².
* **No placed layout.** Region boxes are generated proposals in fractions of the core; they were never given to a
  placer here. OpenROAD was not run (docs/05 §6).
* **No illustration-scale performance.** Every cluster is exactly one TC08 tensor unit (4×4 INT8 by default) or one
  M08 tile (4 FP32 lanes by default). Six clusters are six of those engines, with their measured per-engine
  performance (TC08 `reports/perf.md`: 32×32×256 INT8 GEMM in 63 578 cycles sequential, single 32-bit SFB2 port
  bound), sharing whatever NoC and memory bandwidth the chip provides. Nothing here approaches large "TOPS"
  figures, and no such figure is implied.
* **No timing closure.** docs/04 lists the boundaries a timing-driven flow will need; the CSR read path stays
  combinational.

## Design limits

| Limit | Consequence | Possible follow-up |
|---|---|---|
| one completion harvest at a time per cluster (~15 cycles per record) | bounds the completion rate of very short vector commands | double-buffered record buffer |
| one subsystem command stream, one word per cycle | all clusters share it | per-row command ports from the NoC |
| completion merge one packet at a time | packets of busy clusters wait in their record buffers | wider merge or per-requester completion ports |
| CSR read is combinational (rb contract) | long path across the subsystem | registered CSR bridge (protocol change for `sfv_periph_bridge`) |
| tensor unit 32-bit at the NoC | 64 / 128-bit ports carry one 32-bit access per beat | packing would change TC08's DMA; out of scope |
| local memory and NoC never outstanding at the same time | a target switch waits for the other port to drain | ID-based reordering (DataFabric PROTOCOL §8) |
| forced reset needs the NoC to accept the captured request eventually | a permanently dead NoC leaves the cluster draining (reported) | NoC-level timeout / error injection |
| `TRK_DEPTH` (16) bounds commands in flight per cluster | more commands wait at `cmd_ready` | larger FIFO (parameter) |
| cluster reset resets the whole engine incl. its configuration registers | the adapter re-applies its stream setting; host settings (IRQ enables, counters) are lost | documented; host re-programs after `CL_RESETS` changes |
| no clock-gate cell | `clk_req` is only a request | integrate with the P27 power manager's ICGs |
| vector `perf_ev` derived at the boundary only | engine-internal events stay on the PERF page | export a selected subset |

## Verification limits

docs/06 §4: no formal proof of the new RTL, no gate-level simulation, tile-to-tile scratchpad DMA untested,
quantisation / double buffering behaviour covered only by TC08's own regression.

## Environment limits met in this project

* OpenROAD could not be installed (external toolchain download refused by the sandbox policy).
* 15 GB of RAM: the 4 V + 2 T Verilator testbench needs about 6 GB per compiler process, so builds run one at a time;
  the 8 V + 4 T (`max`) testbench could not be compiled by Verilator at all (one compile unit reached ~13 GB and was
  killed), so that configuration is simulated with Icarus Verilog (same testbench, same checks).
