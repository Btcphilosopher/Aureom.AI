# 05 — Floorplan hierarchy, physical locality, constraints

Nothing here is a placed layout. The regions below are *proposals* generated from the synthesized hierarchy, so
that a floorplanning tool can be told which cells belong together. Numbers: `reports/synth.md`,
`reports/physical.md`.

## 1. Stable instance names

| Region | Generate scope | Cluster instance | Present when |
|---|---|---|---|
| vector *k* | `u_vector_<k>` (k = 0..7) | `u_vector_<k>.u_cl` (`silicaflux_vector_cluster`) | k < `NUM_VECTOR_CLUSTERS` |
| tensor *k* | `u_tensor_<k>` (k = 0..3) | `u_tensor_<k>.u_cl` (`silicaflux_tensor_cluster`) | k < `NUM_TENSOR_CLUSTERS` |

The default HPC configuration therefore has exactly `u_vector_0`, `u_vector_1`, `u_vector_2`, `u_vector_3`,
`u_tensor_0`, `u_tensor_1`. Slot names are produced by one macro per slot (SystemVerilog cannot build an identifier
from a genvar; a generate loop would give `g[0]`-style names with brackets that every Tcl pattern must escape), and
they do not depend on how many clusters are built.

Inside every cluster the names are fixed too:

| Vector cluster | Tensor cluster | Content |
|---|---|---|
| `u_engine` | `u_engine` | the reused engine |
| `u_engine/g_core.u_array` | `u_engine/u_dp/u_arr` | vector lanes / systolic array |
| `u_engine/g_core.u_spm` (`g_core.g_bank[i].u_bank`) | `u_engine/u_dp/u_tob`, `u_dp/u_acc`, `u_dp/u_ob` | scratchpad banks / operand buffers, accumulator, output buffer |
| `u_engine/g_core.u_dma`, `g_core.g_host.u_hs` | `u_engine/u_dp/u_dma`, `u_gate` | DMA / bus side |
| `u_cmd`, `u_ctrl`, `u_mem`, `g_spm.u_spm_gate` | `u_cmd`, `u_ctrl`, `u_mem` | cluster shell |

`/` separates module levels (OpenROAD's divider after linking a hierarchical netlist); a generate scope stays part
of the instance name (`g_core.u_array`), as Yosys names the cell. In a Yosys-flattened netlist the same cells are
`$flatten\u_vector_0.u_cl.u_engine.g_core.u_array…`. The generated Tcl normalises both forms.

## 2. Every region identifiable in the synthesis netlist

`syn/run_synth.py` keeps the hierarchy: `reports/synth/compute_hpc/netlist.v.gz` contains the top module with the six
cluster instances by those names, and `instances.json` lists every module instance (full depth) with its total and
own cells, flip-flops and inferred memories. The constraint generator sums the *own* cells of every instance into
exactly one region and checks the sum against the synthesized total (`reports/physical.md`: the accounting closes to
the cell, for gates and for memory bits). Why the hierarchy must be kept: after a flat ABC mapping, combinational
cells are renamed (`$abc$…`, ORFS `_123_`) and lose their path; FloorplanLab used ORFS `SYNTH_HIERARCHICAL=1` for the
same reason (docs/00 §5).

## 3. Physical locality, expressed by hierarchy and constraints

| Intent (brief §6) | How it is expressed |
|---|---|
| vector engine next to its local scratchpad | lanes (`g_core.u_array`), LSU and the scratchpad banks (`g_core.u_spm`) are in one region and in adjacent sub-regions COMPUTE / SPM |
| tensor array next to operand / accumulator storage | `u_dp.u_tob`, `u_dp.u_arr`, `u_dp.u_acc`, `u_dp.u_ob` form one sub-region CORE |
| cluster interfaces facing the NoC | sub-region NOC_IF (DMA, scratchpad window, `u_mem`, gates) is the band of each cluster next to the NoC channel |
| control / error outputs narrow and registered | `u_ctrl` outputs are flops; sub-region CTRL is the band away from the channel; the shell (router, merge, CSR decode) is a strip on the control edge |
| no coordinates in RTL | none: boxes are fractions of the core box, generated into `constraints/` |

## 4. Region proposal

`config/<cfg>.json` gives the topology (which slots share a row, which edge faces the control side); the generator
sizes boxes in proportion to **weight = generic gates + 0.5 × memory bits**. The 0.5 is an explicit assumption for
proportions only, not a measurement: it reflects that in the SKY130 data points available to this project an SRAM bit
(OpenRAM 1RW1R macro, about 6 µm² per bit) costs roughly half the area of an average mapped standard cell of these
engines (TC08's SKY130 smoke test: about 10 µm² per cell). With 64 KiB scratchpads the vector regions are dominated by
their memories, so the default rows mix vector and tensor slots to balance row heights:

```
 north   ┌────────┬───────────────┬───────────────┬────────┐
         │        │  u_vector_0   │  u_vector_1   │u_tensor│   NOC_IF bands face the channel
         │ shell  ├───────────────┴───────────────┴────────┤
         │ strip  │            NoC channel (not assigned)  │
         │(router,├───────────────┬───────────────┬────────┤
         │ merge, │  u_vector_2   │  u_vector_3   │u_tensor│
 south   └────────┴───────────────┴───────────────┴────────┘
          control edge (west)
```

Actual boxes: `constraints/compute_hpc.groups.tcl` and `reports/physical.md`. They must be re-derived from a mapped
netlist with real SRAM macros (macro sizes, halos, channels) before being used for anything but topology studies.

## 5. Constraint files

| File | Purpose |
|---|---|
| `constraints/<cfg>.groups.tcl` | tool-neutral Tcl data: regions (root instance, totals, box, NoC side) and intra-cluster groups (member prefixes, totals, box) |
| `constraints/<cfg>.regions.tcl` | OpenROAD / OpenDB: one placement region per cluster + the shell strip; `sfx_cc::create`, `sfx_cc::check` |
| `constraints/<cfg>.subregions.tcl` | the same with one region per intra-cluster group (stronger locality, less placer freedom) |
| `physical/openroad_region_check.tcl` | the tool-support check: link a hierarchical mapped netlist, create the regions, place, verify containment |
| `physical/synth_for_openroad.ys` | template for that netlist (small scratchpad mapped to flip-flops) |
| `physical/mock_odb.tcl` | stand-in for the OpenDB objects so the generated scripts can be executed by a plain `tclsh` |

`<cfg>` = `compute_min`, `compute_hpc` (the synthesized configurations).

## 6. OpenROAD support: what was and was not checked

* **Not run.** OpenROAD is not packaged for Ubuntu; installing the litex-hub build that FloorplanLab (P05) used was
  not permitted in this build environment (downloading and executing an external toolchain was refused by the
  sandbox policy). No OpenROAD result is claimed.
* **What the generated scripts use**: `ord::get_db_block`, `odb::dbRegion_create`, `odb::dbBox_create`,
  `dbRegion::addInst`, `dbBlock::getCoreArea` (fallback `ord::get_db_core`), `dbInst::getName / getBBox`. Each call
  is wrapped so that a build lacking it stops with a clear `SFX-1..4` error instead of silently skipping a region.
  FloorplanLab's record of the pinned build lists `macro_placement` with fences, `global_placement`,
  `detailed_placement`, `check_placement` as present, and Hier-RTLMP as absent; it does not record whether
  `dbRegion` constraints are honoured by the placers — exactly what `physical/openroad_region_check.tcl` answers
  (Q1 API present, Q2 every region matched instances, Q3 placement completes, Q4 every instance inside its box).
* **What was checked here** (`scripts/check_physical.py`, `reports/physical.md`): the generated region scripts were
  *executed* in `tclsh 8.6` against the real synthesized instance names, in both naming styles: every instance is
  assigned to exactly one region, no region is empty, all boxes lie inside the core and do not overlap, and the
  gates and memory bits each region receives equal the synthesis accounting.

## 7. Memory inference (for macro planning)

Each inferred memory is one `$mem_v2` cell with its instance path in `reports/synth/<target>/memories.json`. In the
vector cluster the four scratchpad banks (`u_engine/g_core.u_spm/g_core.g_bank[i].u_bank/…`, 4096 × 32 each in the
default configuration) carry almost all memory bits; they are the SRAM macros of the SPM sub-region. The tensor
cluster's memories are small (operand buffers, accumulator and output-buffer banks, DMA FIFOs) and may stay in
flip-flops or become small macros in the CORE sub-region. Macro binding is the SRAM Wrapper Library's ASIC backend
(`SPM_BACKEND` / `MEM_BACKEND`), unchanged and not exercised here.
