# =============================================================================
# SilicaFlux-HPC Project 32 :: physical/openroad_region_check.tcl
# Does the selected OpenROAD build support the generated placement regions?
#
# NOT RUN in this project: OpenROAD could not be installed in the build environment (see
# docs/05_PHYSICAL.md section 6).  Run it where OpenROAD (e.g. the build FloorplanLab pinned,
# 2.0-12331-g6011bbe77, or a current one) and a platform are available:
#
#   export TECH_LEF=.../sky130_fd_sc_hd.tlef SC_LEF=.../sky130_fd_sc_hd_merged.lef \
#          LIB=.../sky130_fd_sc_hd__tt_025C_1v80.lib SITE=unithd HLAYER=met3 VLAYER=met2 \
#          NETLIST=build/or/compute_min_sky130.v TOP=silicaflux_compute_cluster CFG=compute_min
#   openroad -exit physical/openroad_region_check.tcl
#
# NETLIST must be a HIERARCHICAL gate netlist of the same configuration mapped to that platform
# (physical/synth_for_openroad.ys), so that linking keeps every region prefix in the instance names.
# Memories: map them to flip-flops (small scratchpad for this check) or to platform SRAM macros.
# The script answers four questions and prints one line each:
#   SFX-CC-Q1 region API  : odb::dbRegion_create / dbBox_create / dbRegion::addInst exist
#   SFX-CC-Q2 assignment  : every region matched instances (names carry the region prefix)
#   SFX-CC-Q3 placement   : global_placement + detailed_placement complete with the regions present
#   SFX-CC-Q4 containment : every assigned instance ends inside its region box (sfx_cc::check == 0)
# A "NO" on Q3 or Q4 means this OpenROAD build does not honour the regions: use them as a floorplan guide
# only (macro placement, manual grouping) and report that build as unsupported.
# =============================================================================
foreach v {TECH_LEF SC_LEF LIB SITE HLAYER VLAYER NETLIST TOP CFG} {
  if {![info exists ::env($v)]} { puts "SFX-CC: missing environment variable $v"; exit 2 }
}
set root [file dirname [file dirname [file normalize [info script]]]]
read_lef $::env(TECH_LEF)
read_lef $::env(SC_LEF)
read_liberty $::env(LIB)
read_verilog $::env(NETLIST)
link_design $::env(TOP)
initialize_floorplan -utilization 35 -aspect_ratio 1.0 -core_space 20 -site $::env(SITE)
make_tracks
place_pins -hor_layers $::env(HLAYER) -ver_layers $::env(VLAYER)
source $root/constraints/$::env(CFG).regions.tcl

set q1 [expr {[llength [info commands odb::dbRegion_create]] > 0 && [llength [info commands odb::dbBox_create]] > 0}]
puts "SFX-CC-Q1 region API  : [expr {$q1 ? {YES} : {NO}}]"
if {!$q1} { exit 1 }
if {[catch {sfx_cc::create} e]} { puts "SFX-CC-Q2 assignment  : NO ($e)"; exit 1 }
puts "SFX-CC-Q2 assignment  : YES"
if {[catch {global_placement -density 0.6; detailed_placement; check_placement -verbose} e]} {
  puts "SFX-CC-Q3 placement   : NO ($e)"; exit 1
}
puts "SFX-CC-Q3 placement   : YES"
set bad [sfx_cc::check]
puts "SFX-CC-Q4 containment : [expr {$bad == 0 ? {YES} : "NO ($bad instances outside)"}]"
exit [expr {$bad == 0 ? 0 : 1}]
