# =============================================================================
# SilicaFlux-HPC Project 32 :: physical/mock_odb.tcl   (offline check only)
# Minimal stand-in for the OpenROAD / OpenDB Tcl objects that constraints/*.regions.tcl uses, so the generated
# scripts can be EXECUTED by a plain tclsh against the real synthesized instance names
# (reports/physical/<cfg>_insts.txt).  It does not model placement and proves nothing about whether a given
# OpenROAD build accepts the region API: that is what physical/openroad_region_check.tcl is for.
# =============================================================================
namespace eval ord {}
namespace eval odb {}
namespace eval utl {}
namespace eval mock {
  variable core {0 0 1000000 1000000}
  variable names {}
  variable cells {}
  variable bits {}
  variable insts {}
  variable member
  variable boxes
}
proc utl::error {tool id msg} { error "$tool-$id $msg" }
proc ord::get_db_block {} { return mock_block }
proc ord::get_db_core {} { return mock_rect }
proc mock_block {method args} {
  switch -- $method {
    getCoreArea { return mock_rect }
    getInsts    { return $::mock::insts }
    default     { error "mock_block: unsupported method $method" }
  }
}
proc mock_rect {method} {
  lassign $::mock::core x0 y0 x1 y1
  switch -- $method { xMin { return $x0 } yMin { return $y0 } xMax { return $x1 } yMax { return $y1 } }
}
proc mock::inst {i method args} {
  switch -- $method {
    getName { return [lindex $::mock::names $i] }
    default { error "mock inst: unsupported method $method" }
  }
}
proc mock::region {name method args} {
  switch -- $method {
    addInst {
      set i [string range [lindex $args 0] 3 end]
      if {[info exists ::mock::owner($i)]} { error "instance $i added to $::mock::owner($i) and $name" }
      set ::mock::owner($i) $name
      lappend ::mock::member($name) $i
    }
    default { error "mock region: unsupported method $method" }
  }
}
proc odb::dbRegion_create {block name} {
  if {[info exists ::mock::boxes($name)]} { error "region $name created twice" }
  set ::mock::boxes($name) {}
  set ::mock::member($name) {}
  interp alias {} mreg_$name {} mock::region $name
  return mreg_$name
}
proc odb::dbBox_create {reg x0 y0 x1 y1} {
  set name [string range $reg 5 end]
  if {$x0 >= $x1 || $y0 >= $y1} { error "region $name: empty box" }
  lassign $::mock::core cx0 cy0 cx1 cy1
  if {$x0 < $cx0 || $y0 < $cy0 || $x1 > $cx1 || $y1 > $cy1} { error "region $name: box outside the core" }
  set ::mock::boxes($name) [list $x0 $y0 $x1 $y1]
}
# instance file: "<name> <own generic cells> <memory bits>" per line
proc mock::load {path {style hier}} {
  set f [open $path r]
  set i 0
  while {[gets $f line] >= 0} {
    if {$line eq ""} continue
    lassign [split $line " "] n c b
    if {$style eq "flat"} {
      # Yosys flattened naming: '$flatten\' prefix, '.' separators, brackets not escaped
      set n [string map {\\[ [ \\] ] / .} $n]
      set n "\$flatten\\$n"
    }
    lappend ::mock::names $n
    lappend ::mock::cells $c
    lappend ::mock::bits $b
    interp alias {} mi_$i {} mock::inst $i
    lappend ::mock::insts mi_$i
    incr i
  }
  close $f
}
proc mock::report {} {
  set total [llength $::mock::names]
  set owned [array size ::mock::owner]
  puts "MOCK instances $total assigned $owned"
  foreach name [lsort [array names ::mock::boxes]] {
    set c 0; set b 0
    foreach i $::mock::member($name) { incr c [lindex $::mock::cells $i]; incr b [lindex $::mock::bits $i] }
    puts "MOCK region $name box {$::mock::boxes($name)} insts [llength $::mock::member($name)] cells $c membits $b"
  }
  # pairwise overlap of region boxes (touching edges allowed)
  set names [lsort [array names ::mock::boxes]]
  set ov 0
  for {set a 0} {$a < [llength $names]} {incr a} {
    for {set b [expr {$a + 1}]} {$b < [llength $names]} {incr b} {
      lassign $::mock::boxes([lindex $names $a]) ax0 ay0 ax1 ay1
      lassign $::mock::boxes([lindex $names $b]) bx0 by0 bx1 by1
      if {$ax0 < $bx1 && $bx0 < $ax1 && $ay0 < $by1 && $by0 < $ay1} {
        incr ov
        puts "MOCK overlap [lindex $names $a] [lindex $names $b]"
      }
    }
  }
  puts "MOCK overlaps $ov"
}
