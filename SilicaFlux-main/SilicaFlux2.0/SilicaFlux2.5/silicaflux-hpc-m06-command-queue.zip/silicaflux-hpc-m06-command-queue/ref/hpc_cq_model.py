#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: hpc_cq_model -- reference command model

Independent of the RTL.  Executes a command stream SEQUENTIALLY, in program
order, on a model of the external-memory and scratchpad windows, and
produces for every command the completion record the hardware must return.
The hardware may overlap independent commands; the architectural result must
equal this sequential model (docs/02_ARCHITECTURE.md sec. 5).

Semantics implemented (docs/01_COMMAND_ABI.md, docs/04_ERRORS.md):
  * descriptor validation, first failing rule wins
    VERSION, OPCODE, FLAGS, RSVD, STRIDE, RM, LENGTH, ALIGN, RANGE, OVERLAP
  * DMA_LOAD / DMA_STORE as DataFabric dma_transfer_engine performs them:
    beat by beat (read word i, write word i), byte-accurate tail strobe,
    first failing beat ends the transfer (READ_BUS / WRITE_BUS at that
    address, COUNT = bytes of the completed beats, earlier beats written)
  * VECTOR_ADD / MUL / FMA element by element with the Module 02 bit-exact
    FP32 reference (third_party/silicaflux-hpc-m02-vector-lane/ref/fp32_ref.py),
    flags ORed into FFLAGS, D = A*B + D for FMA
  * stop-on-error (sticky, later commands SKIPPED / ERR_PRIOR until a clear)
    and continue-on-error modes; quarantined units (ERR_UNIT_DOWN)

Timing-dependent outcomes are represented explicitly instead of guessed:
  * a word whose final value depends on timing is UNDEFINED (care = 0);
    anything computed from an undefined word is undefined too
  * a record field that depends on timing is masked out of the comparison
  * in stop mode, a command younger than an EXECUTION error may have been
    issued before the error was detected (it was independent and on the
    other unit): it carries an alternative record (SKIPPED); the scoreboard
    accepts either, monotonically (once SKIPPED, all later ones SKIPPED)
"""
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "..", "third_party", "silicaflux-hpc-m02-vector-lane", "ref"))
import fp32_ref  # noqa: E402  (Module 02 reference, unmodified)
import hpc_cq_abi as A  # noqa: E402

M32 = 0xFFFFFFFF
REC_ALL = [M32, M32, M32, M32]


class Cfg:
    def __init__(self, ext_base=0x10000000, ext_log2=17, spm_base=0x20000000, spm_log2=16,
                 spm_phys_log2=None, dma_max_len_log2=24, vl_w=16, opset_full=True,
                 overlap_en=True, ext_err=(0, 0), ext_hang=(0, 0)):
        self.ext_base, self.ext_log2 = ext_base, ext_log2
        self.spm_base, self.spm_log2 = spm_base, spm_log2
        self.spm_phys_log2 = spm_log2 if spm_phys_log2 is None else spm_phys_log2
        self.dma_max_len = 1 << dma_max_len_log2
        self.vl_max = (1 << vl_w) - 1
        self.opset_full = opset_full
        self.overlap_en = overlap_en
        self.ext_err = ext_err        # [lo, hi) bus error on every access
        self.ext_hang = ext_hang      # [lo, hi) accepted, never answered

    @property
    def ext_size(self):
        return 1 << self.ext_log2

    @property
    def spm_size(self):
        return 1 << self.spm_log2

    def in_ext(self, a, n):
        return a >= self.ext_base and a + n <= self.ext_base + self.ext_size

    def in_spm(self, a, n):
        return a >= self.spm_base and a + n <= self.spm_base + self.spm_size

    def bus_error(self, a):
        """Address answered with an SFB2 error (the access has no effect)."""
        if self.ext_err[0] <= a < self.ext_err[1]:
            return True
        if self.spm_base <= a < self.spm_base + self.spm_size:
            return a >= self.spm_base + (1 << self.spm_phys_log2)   # scratchpad RANGE error
        return False

    def hangs(self, a):
        return self.ext_hang[0] <= a < self.ext_hang[1]


class Mem:
    """Word memory with a per-word 'defined' bit."""

    def __init__(self, base, nwords, init=None):
        self.base = base
        self.val = list(init) if init is not None else [0] * nwords
        self.ok = [True] * nwords

    def idx(self, a):
        return (a - self.base) >> 2

    def contains(self, a):
        return 0 <= self.idx(a) < len(self.val)

    def rd(self, a):
        i = self.idx(a)
        return self.val[i], self.ok[i]

    def wr(self, a, v, ok, strb=0xF):
        i = self.idx(a)
        if strb == 0xF:
            self.val[i], self.ok[i] = v & M32, ok
        else:
            m = 0
            for b in range(4):
                if strb >> b & 1:
                    m |= 0xFF << (8 * b)
            self.val[i] = (self.val[i] & ~m | v & m) & M32
            self.ok[i] = self.ok[i] and ok

    def undef(self, a, n):
        for w in range(a & ~3, a + n, 4):
            if self.contains(w):
                self.ok[self.idx(w)] = False


def isect(a0, a1, b0, b1):
    return a0 < b1 and b0 < a1 and a0 < a1 and b0 < b1


def validate(f, cfg):
    """Descriptor validation, ABI v1 rule order. Returns an ERR_* code."""
    op, L = f["op"], f["length"]
    sa, sb, d = f["sa"], f["sb"], f["dst"]
    if f["ver"] != A.ABI_VERSION:
        return A.ERR_VERSION
    supported = set(A.OPCODES) if cfg.opset_full else A.STAGE1_OPS
    if op not in supported:
        return A.ERR_OPCODE
    if f["flags"] & ~A.FLAGS_V1_MASK & 0xFF:
        return A.ERR_FLAGS
    rsvd = f["rsvd15"] or f["w6"] or f["w7"]
    if op in A.DMA_OPS and (sb or f["rm"]):
        rsvd = True
    if op in A.CTL_OPS and (sa or sb or d or L or f["stride"] or f["rm"]):
        rsvd = True
    if rsvd:
        return A.ERR_RSVD
    if op in A.DMA_OPS | A.VEC_OPS and f["stride"]:
        return A.ERR_STRIDE
    if op in A.VEC_OPS and f["rm"] > 4:
        return A.ERR_RM
    if op in A.DMA_OPS and not (1 <= L <= cfg.dma_max_len):
        return A.ERR_LENGTH
    if op in A.VEC_OPS and not (1 <= L <= cfg.vl_max):
        return A.ERR_LENGTH
    if op in A.DMA_OPS and (sa % 4 or d % 4):
        return A.ERR_ALIGN
    if op in A.VEC_OPS and (sa % 4 or sb % 4 or d % 4):
        return A.ERR_ALIGN
    if op == A.OP_DMA_LOAD and not (cfg.in_ext(sa, L) and cfg.in_spm(d, L)):
        return A.ERR_RANGE
    if op == A.OP_DMA_STORE and not (cfg.in_spm(sa, L) and cfg.in_ext(d, L)):
        return A.ERR_RANGE
    if op in A.VEC_OPS:
        n = 4 * L
        if not (cfg.in_spm(sa, n) and cfg.in_spm(sb, n) and cfg.in_spm(d, n)):
            return A.ERR_RANGE
        for s in (sa, sb):
            if s != d and isect(d, d + n, s, s + n):
                return A.ERR_OVERLAP
    return A.ERR_NONE


def footprint(f):
    """(reads, writes) byte intervals of a valid DMA / vector command."""
    op, L, sa, sb, d = f["op"], f["length"], f["sa"], f["sb"], f["dst"]
    if op in A.DMA_OPS:
        return [(sa, sa + ((L + 3) & ~3))], [(d, d + L)]
    if op in A.VEC_OPS:
        n = 4 * L
        rd = [(sa, sa + n), (sb, sb + n)] + ([(d, d + n)] if op == A.OP_VECTOR_FMA else [])
        return rd, [(d, d + n)]
    return [], []


def conflict(fa, fb):
    """RAW / WAR / WAW between two footprints."""
    ra, wa = fa
    rb, wb = fb
    for x in wa:
        for y in rb + wb:
            if isect(*x, *y):
                return True
    for x in ra:
        for y in wb:
            if isect(*x, *y):
                return True
    return False


def unit_of(op):
    if op in A.DMA_OPS:
        return "DMA"
    if op in A.VEC_OPS:
        return "VEC"
    return None


class Model:
    def __init__(self, cfg, ext_init, spm_init, cont=False):
        self.cfg = cfg
        self.ext = Mem(cfg.ext_base, cfg.ext_size // 4, ext_init)
        self.spm = Mem(cfg.spm_base, cfg.spm_size // 4, spm_init)
        self.cont = cont
        self.sticky = False
        self.dead = {"DMA": False, "VEC": False}
        self.seq = 0
        # stop-mode ambiguity window after an execution error
        self.amb_active = False      # younger commands may still run early
        self.amb_src = None          # (unit, footprint) of the failing job
        self.records = []            # (exp, mask, alt, altmask, alt_ok)
        self.counts_after_rst = None

    # --------------------------------------------------------------- memory helpers
    def mem_of(self, a):
        if self.ext.contains(a):
            return self.ext
        if self.spm.contains(a):
            return self.spm
        return None

    def rd(self, a):
        m = self.mem_of(a)
        return m.rd(a)

    def wr(self, a, v, ok, strb=0xF):
        self.mem_of(a).wr(a, v, ok, strb)

    # --------------------------------------------------------------- execution
    def _dma(self, f):
        sa, d, L = f["sa"], f["dst"], f["length"]
        cfg = self.cfg
        nbeat = (L + 3) // 4
        for i in range(nbeat):
            s, t = sa + 4 * i, d + 4 * i
            if cfg.hangs(s) or cfg.hangs(t):
                return A.ST_ERROR, A.ERR_TIMEOUT, 4 * i, 0, "hang"
            if cfg.bus_error(s):
                return A.ST_ERROR, A.ERR_DMA_READ, 4 * i, s, None
            v, ok = self.rd(s)
            if cfg.bus_error(t):
                return A.ST_ERROR, A.ERR_DMA_WRITE, 4 * i, t, None
            nb = min(4, L - 4 * i)
            self.wr(t, v, ok, (1 << nb) - 1)
        return A.ST_OK, A.ERR_NONE, L, 0, None

    def _vec(self, f):
        """Returns (st, err, count, eaddr, ff, ff_known, fault)."""
        op, rm, L, sa, sb, d = f["op"], f["rm"], f["length"], f["sa"], f["sb"], f["dst"]
        cfg = self.cfg
        rd_addrs = [sa, sb] + ([d] if op == A.OP_VECTOR_FMA else [])
        rd_fault = any(cfg.bus_error(x + 4 * e) for e in range(L) for x in rd_addrs)
        wr_fault = any(cfg.bus_error(d + 4 * e) for e in range(L))
        if rd_fault or wr_fault:
            # How many writes landed, the failing address and the flags depend
            # on timing.  Deterministic: a result computed from an operand
            # whose read FAILED is never written (the error is registered
            # before that result can reach write-back), so such a destination
            # word keeps its old value; every other destination word is
            # undefined.  With only the destination faulting, no read can
            # fail: the code is VEC_WRITE.
            for e in range(L):
                if not any(cfg.bus_error(x + 4 * e) for x in rd_addrs):
                    self.spm.undef(d + 4 * e, 4)
            return A.ST_ERROR, (None if rd_fault else A.ERR_VEC_WRITE), None, None, 0, False, True
        ff, known = 0, True
        for e in range(L):
            a, oka = self.spm.rd(sa + 4 * e)
            b, okb = self.spm.rd(sb + 4 * e)
            c, okc = self.spm.rd(d + 4 * e)
            if op == A.OP_VECTOR_ADD:
                r, fl = fp32_ref.fadd(a, b, rm)
                ok = oka and okb
            elif op == A.OP_VECTOR_MUL:
                r, fl = fp32_ref.fmul(a, b, rm)
                ok = oka and okb
            else:
                r, fl = fp32_ref.ffma(a, b, c, rm)
                ok = oka and okb and okc
            if not ok:
                known = False
            ff |= fl
            self.spm.wr(d + 4 * e, r, ok)
        return A.ST_OK, A.ERR_NONE, L, 0, ff, known, False

    # --------------------------------------------------------------- one command
    def step(self, words, hang_vec=False):
        """Model one command; returns the expected record.  hang_vec: the
        testbench stalls the vector array forever once this job is issued
        (watchdog test)."""
        f = A.desc_fields(words)
        seq = self.seq
        self.seq += 1
        op, tid, irq = f["op"], f["tid"], f["flags"] & 1
        mask = list(REC_ALL)
        alt = None

        def rec(st, err, cnt=0, ea=0, ff=0):
            return A.pack_rec(tid, op, err, st, irq, ff, cnt, ea, seq)

        skipped = rec(A.ST_SKIPPED, A.ERR_PRIOR)

        if self.sticky and not self.cont:
            if not (self.amb_active and self._may_run_early(f)):
                self.amb_active = False
                return self._push(skipped, mask, None, None)
            alt = skipped        # may have run before the older failure was seen

        altm = REC_ALL if alt is not None else None
        verr = validate(f, self.cfg)
        unit = unit_of(op)
        if verr or (unit and self.dead[unit]):
            err = verr if verr else A.ERR_UNIT_DOWN
            if not self.cont:
                if alt is not None:
                    self.amb_active = False   # resolving it sets the sticky bit anyway
                else:
                    self._set_sticky(exec_err=False)
            return self._push(rec(A.ST_ERROR, err), mask, alt, altm)
        if op in A.CTL_OPS:
            return self._push(rec(A.ST_OK, A.ERR_NONE), mask, alt, altm)

        if unit == "DMA":
            st, err, cnt, ea, how = self._dma(f)
            if how == "hang":
                self.dead["DMA"] = True
            r = rec(st, err, cnt, ea)
        elif hang_vec:
            self.dead["VEC"] = True
            self.spm.undef(f["dst"], 4 * f["length"])
            st = A.ST_ERROR
            r = rec(st, A.ERR_TIMEOUT)
            mask = [M32 & ~(0x1F << 27), 0, M32, M32]        # count / flags timing dependent
        else:
            st, err, cnt, ea, ff, known, fault = self._vec(f)
            if fault and err == A.ERR_VEC_WRITE:
                r = rec(st, A.ERR_VEC_WRITE)
                mask = [M32 & ~(0x1F << 27), 0, 0, M32]       # count / address / flags timing dependent
            elif fault:
                r = rec(st, A.ERR_VEC_READ)
                # which of READ / WRITE is seen first, the count, the address
                # and the flags depend on timing
                mask = [M32 & ~(0xFF << 16) & ~(0x1F << 27), 0, 0, M32]
            else:
                r = rec(st, err, cnt, ea, ff)
                if not known:
                    mask[0] &= ~(0x1F << 27)
        if alt is not None:
            # this command may or may not have executed: its writes are undefined
            for lo, hi in footprint(f)[1]:
                self.mem_of(lo).undef(lo, hi - lo)
        if st != A.ST_OK and not self.cont:
            self._set_sticky(exec_err=True, f=f)
        return self._push(r, mask, alt, altm)

    def _push(self, r, mask, alt, altmask):
        self.records.append((r, mask, alt, altmask))
        return r

    def _set_sticky(self, exec_err, f=None):
        if self.sticky:
            return
        self.sticky = True
        if exec_err:
            self.amb_active = True
            self.amb_src = (unit_of(f["op"]), footprint(f))
        else:
            self.amb_active = False

    def _may_run_early(self, f):
        """Could this command have left the decode slot before the failing
        job's error was detected?  Only if it waits for nothing the failing
        job holds: not a sync point, not the same unit, no dependency, and
        overlap enabled.  NOP / invalid commands resolve without waiting."""
        op = f["op"]
        unit_src, fp_src = self.amb_src
        flags = f["flags"]
        if validate(f, self.cfg):
            return True                          # resolves at decode without waiting
        if op in (A.OP_FENCE, A.OP_RESET_COUNTERS) or flags >> A.FL_BARRIER & 1:
            return False
        u = unit_of(op)
        if u is None:
            return True                          # NOP
        if u == unit_src:
            return False                         # waits for the failing unit itself
        if self.dead[u]:
            return True                          # UNIT_DOWN resolves at decode
        if not self.cfg.overlap_en:
            return False
        if conflict(footprint(f), fp_src):
            return False
        return True

    def clear(self):
        self.sticky = False
        self.amb_active = False
