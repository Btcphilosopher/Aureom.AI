#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: hpc_cq_abi -- command-queue ABI v1, Python half

Mirror of rtl/hpc_cq_pkg.sv and sw/hpc_cq_abi.h (scripts/check_abi.py proves
all three agree).  Pure data + descriptor / record pack/unpack helpers.
"""

ABI_VERSION = 1
DESC_WORDS = 8
REC_WORDS = 4

# descriptor words
W_HDR, W_SRC_A, W_SRC_B, W_DST, W_LEN, W_STRIDE, W_RSVD6, W_RSVD7 = range(8)
# header fields: (lsb, width)
H_OP = (0, 8)
H_VER = (8, 4)
H_RM = (12, 3)
H_RSVD_BIT = 15
H_FLAGS = (16, 8)
H_TID = (24, 8)

# opcodes
OP_NOP = 0x00
OP_DMA_LOAD = 0x01
OP_DMA_STORE = 0x02
OP_VECTOR_ADD = 0x10
OP_VECTOR_MUL = 0x11
OP_VECTOR_FMA = 0x12
OP_FENCE = 0x20
OP_RESET_COUNTERS = 0x30
OPCODES = {OP_NOP: "NOP", OP_DMA_LOAD: "DMA_LOAD", OP_DMA_STORE: "DMA_STORE",
           OP_VECTOR_ADD: "VECTOR_ADD", OP_VECTOR_MUL: "VECTOR_MUL", OP_VECTOR_FMA: "VECTOR_FMA",
           OP_FENCE: "FENCE", OP_RESET_COUNTERS: "RESET_COUNTERS"}
STAGE1_OPS = {OP_NOP, OP_DMA_LOAD, OP_VECTOR_ADD, OP_FENCE}
DMA_OPS = {OP_DMA_LOAD, OP_DMA_STORE}
VEC_OPS = {OP_VECTOR_ADD, OP_VECTOR_MUL, OP_VECTOR_FMA}
CTL_OPS = {OP_NOP, OP_FENCE, OP_RESET_COUNTERS}

# flags
FL_IRQ = 0
FL_BARRIER = 1
FLAGS_V1_MASK = 0x03

# rounding modes (Module 02 hpc_vector_pkg / RISC-V frm)
RM_RNE, RM_RTZ, RM_RDN, RM_RUP, RM_RMM = range(5)

# completion record word 0 fields: (lsb, width)
R_TID = (0, 8)
R_OP = (8, 8)
R_ERR = (16, 8)
R_STATUS = (24, 2)
R_IRQ_BIT = 26
R_FFLAGS = (27, 5)

ST_OK, ST_ERROR, ST_SKIPPED = 0, 1, 2

ERR_NONE = 0x00
ERR_VERSION = 0x01
ERR_OPCODE = 0x02
ERR_FLAGS = 0x03
ERR_RSVD = 0x04
ERR_STRIDE = 0x05
ERR_RM = 0x06
ERR_LENGTH = 0x07
ERR_ALIGN = 0x08
ERR_RANGE = 0x09
ERR_OVERLAP = 0x0A
ERR_DMA_BASE = 0x10
ERR_DMA_READ = 0x18
ERR_DMA_WRITE = 0x19
ERR_DMA_ABORTED = 0x1A
ERR_VEC_BASE = 0x20
ERR_VEC_READ = 0x21
ERR_VEC_WRITE = 0x22
ERR_VEC_ENGINE = 0x23
ERR_TIMEOUT = 0x30
ERR_UNIT_DOWN = 0x31
ERR_PRIOR = 0x40

# performance counters
PC_NAMES = ["CYCLES", "BUSY", "CMD_IN", "CMD_COMMIT", "CMD_ERR", "CMD_SKIP", "DMA_ISSUE",
            "VEC_ISSUE", "DMA_ACTIVE", "VEC_ACTIVE", "OVERLAP", "STALL_HAZARD", "STALL_UNIT",
            "STALL_SYNC", "STALL_ROB", "Q_FULL", "CPL_BP"]
PC = {n: i for i, n in enumerate(PC_NAMES)}
PC_N = len(PC_NAMES)

# MMIO register map (hpc_cq_mmio)
MMIO = dict(ID=0x000, INFO=0x004, CTRL=0x008, STATUS=0x00C, INT_ENABLE=0x010,
            INT_STATUS=0x014, SUBMITTED=0x018, DESC0=0x020, DOORBELL=0x040,
            CPL0=0x050, CPL_POP=0x060, PERF0=0x080)
MMIO_ID_VALUE = 0x53464351


def _fld(word, f):
    lsb, w = f
    return (word >> lsb) & ((1 << w) - 1)


def pack_desc(op, sa=0, sb=0, dst=0, length=0, flags=0, tid=0, rm=0, stride=0,
              ver=ABI_VERSION, rsvd15=0, w6=0, w7=0):
    """Descriptor as a list of 8 words."""
    w0 = ((op & 0xFF) | ((ver & 0xF) << 8) | ((rm & 7) << 12) | ((rsvd15 & 1) << 15) |
          ((flags & 0xFF) << 16) | ((tid & 0xFF) << 24))
    return [w0, sa & 0xFFFFFFFF, sb & 0xFFFFFFFF, dst & 0xFFFFFFFF, length & 0xFFFFFFFF,
            stride & 0xFFFFFFFF, w6 & 0xFFFFFFFF, w7 & 0xFFFFFFFF]


def desc_fields(words):
    w0 = words[0]
    return dict(op=_fld(w0, H_OP), ver=_fld(w0, H_VER), rm=_fld(w0, H_RM),
                rsvd15=(w0 >> H_RSVD_BIT) & 1, flags=_fld(w0, H_FLAGS), tid=_fld(w0, H_TID),
                sa=words[1], sb=words[2], dst=words[3], length=words[4], stride=words[5],
                w6=words[6], w7=words[7])


def pack_rec(tid, op, err, st, irq, ff, count, eaddr, seq):
    w0 = (tid & 0xFF) | ((op & 0xFF) << 8) | ((err & 0xFF) << 16) | ((st & 3) << 24) | \
         ((irq & 1) << 26) | ((ff & 0x1F) << 27)
    return [w0, count & 0xFFFFFFFF, eaddr & 0xFFFFFFFF, seq & 0xFFFFFFFF]


def rec_fields(words):
    w0 = words[0]
    return dict(tid=_fld(w0, R_TID), op=_fld(w0, R_OP), err=_fld(w0, R_ERR),
                st=_fld(w0, R_STATUS), irq=(w0 >> R_IRQ_BIT) & 1, ff=_fld(w0, R_FFLAGS),
                count=words[1], eaddr=words[2], seq=words[3])


def words_to_int(words):
    v = 0
    for i, w in enumerate(words):
        v |= (w & 0xFFFFFFFF) << (32 * i)
    return v
