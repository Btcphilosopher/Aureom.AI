#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: gen_prog -- command-program generator

Builds a command program for tb_hpc_command_queue from a named recipe, runs
it through the reference model (hpc_cq_model) and writes everything the
testbench needs into one directory:

  cmds.hex   N x 256-bit descriptors            ctl.hex   N x 32-bit TB control
  exp.hex    N x 128-bit expected records       expm.hex  compare masks
  alt.hex    N x alternative records            altm.hex  their masks (0 = none)
  ext_init.hex / ext_exp.hex / ext_care.hex     external memory, every word
  spm_init.hex  {addr, data} host-port writes before the program
  spm_chk.hex   {addr, data} host-port reads after the program (defined words)
  chk.hex       {cmd index, addr, data} checks at host sync points
  meta.json     counts and knobs (turned into plusargs by scripts/regress.py)

TB control word (ctl.hex):
  bit0 SYNC   after submitting the command, wait for its completion record
  bit1 CLEAR  after the sync, pulse ctrl_err_clear
  bit2 CHECK  after the sync, run the chk.hex entries of this command
  bit4 HOLD   when the command is issued to the vector unit, hold every lane forever
  bit5 MODE   after the sync, set ctrl_err_cont to bit6
"""
import argparse
import json
import os
import random
import struct
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import hpc_cq_abi as A  # noqa: E402
import hpc_cq_model as M  # noqa: E402

CTL_SYNC, CTL_CLEAR, CTL_CHECK, CTL_HOLD, CTL_MODE, CTL_MODE_VAL = 1, 2, 4, 16, 32, 64


# ============================================================================ FP data
def f2b(x):
    return struct.unpack("<I", struct.pack("<f", x))[0]


SPECIALS = [0x00000000, 0x80000000, 0x7F800000, 0xFF800000, 0x7FC00000, 0x7F800001, 0xFFC00001,
            0x00000001, 0x007FFFFF, 0x80000001, 0x00800000, 0x7F7FFFFF, 0xFF7FFFFF, 0x3F800000,
            0xBF800000, 0x33800000, 0x4B800000, 0x0D800000]


def rand_fp(rng, special_pct=4):
    r = rng.random() * 100
    if r < special_pct:
        return rng.choice(SPECIALS)
    if r < 45:
        return f2b(float(rng.randint(-64, 64)) * 0.25)                # exact-ish
    if r < 80:
        return f2b(rng.uniform(-1000.0, 1000.0))                       # inexact sums / products
    if r < 92:
        e = rng.randint(1, 254)
        return (rng.getrandbits(1) << 31) | (e << 23) | rng.getrandbits(23)   # full range
    return rng.getrandbits(32)                                           # anything


# ============================================================================ program
class Prog:
    def __init__(self, name, seed, cfg, cont=False, arena=8192, top=1024, stage1=False):
        self.name, self.seed, self.cfg = name, seed, cfg
        self.rng = random.Random(seed)
        self.stage1 = stage1
        sb = cfg.spm_base
        self.arena = (sb, sb + arena)
        self.top = (sb + cfg.spm_size - top, sb + cfg.spm_size)
        self.phys_end = sb + (1 << cfg.spm_phys_log2)
        # host-port traffic only: just above the arena, never used by any command
        self.scratch = (self.arena[1], self.arena[1] + 0x100)
        assert self.scratch[1] <= min(self.top[0], self.phys_end)
        rng = self.rng
        self.ext_init = [rand_fp(rng) for _ in range(cfg.ext_size // 4)]
        spm = [0] * (cfg.spm_size // 4)
        self.spm_init_list = []
        for lo, hi in (self.arena, self.top):
            for a in range(lo, min(hi, self.phys_end), 4):
                v = rand_fp(rng)
                spm[(a - sb) >> 2] = v
                self.spm_init_list.append((a, v))
        self.model = M.Model(cfg, self.ext_init, spm, cont=cont)
        # scratchpad words the testbench never initialises hold unknown data
        # (SRAM has no reset; X in 4-state simulation): undefined in the model
        inited = {(a - sb) >> 2 for a, _ in self.spm_init_list}
        for i in range(len(self.model.spm.ok)):
            if i not in inited:
                self.model.spm.ok[i] = False
        self.cont0 = cont
        self.cmds, self.ctl, self.checks = [], [], []
        self.tid = 0
        self.meta = {}

    # ------------------------------------------------------------------ commands
    def cmd(self, words, hold=False):
        self.cmds.append(words)
        self.ctl.append(CTL_HOLD if hold else 0)
        self.model.step(words, hang_vec=hold)

    def d(self, op, hold=False, **kw):
        """Build + add a descriptor (tid auto-increments unless given)."""
        if "tid" not in kw:
            kw["tid"] = self.tid
            self.tid = (self.tid + 1) & 0xFF
        self.cmd(A.pack_desc(op, **kw), hold=hold)

    def set_mode(self, cont):
        """Error mode from here on (a sync point, or the initial mode)."""
        if self.cmds:
            self.sync(mode=cont)
        else:
            self.cont0 = bool(cont)
            self.model.cont = bool(cont)

    def sync(self, check=(), clear=False, mode=None):
        """Host sync point after the last command: wait for its record, then
        (optionally) check memory words, clear the sticky error, set the mode."""
        i = len(self.cmds) - 1
        self.ctl[i] |= CTL_SYNC
        if check:
            self.ctl[i] |= CTL_CHECK
            for a in check:
                mem = self.model.mem_of(a)
                v, ok = mem.rd(a)
                if ok and not self.cfg.bus_error(a):
                    self.checks.append((i, a, v))
        if clear:
            self.ctl[i] |= CTL_CLEAR
            self.model.clear()
        if mode is not None:
            self.ctl[i] |= CTL_MODE | (CTL_MODE_VAL if mode else 0)
            self.model.cont = bool(mode)

    # ------------------------------------------------------------------ address helpers
    def spm_range(self, nbytes, region=None):
        lo, hi = region or self.arena
        nw = nbytes // 4 if nbytes % 4 == 0 else nbytes // 4 + 1
        span = (hi - lo) // 4 - nw
        return lo + 4 * self.rng.randint(0, max(span, 0))

    def ext_range(self, nbytes):
        """Random EXT range clear of the injected error / hang windows."""
        c = self.cfg
        nw = (nbytes + 3) // 4
        for _ in range(100):
            a = c.ext_base + 4 * self.rng.randint(0, c.ext_size // 4 - nw)
            if not any(M.isect(a, a + 4 * nw, lo, hi) for lo, hi in (c.ext_err, c.ext_hang)):
                return a
        return c.ext_base

    def vec(self, op=None, vl=None, maxvl=64, rm=None, flags=0, bufs=None, hold=False):
        rng = self.rng
        if op is None:
            op = A.OP_VECTOR_ADD if self.stage1 else rng.choice(sorted(A.VEC_OPS))
        vl = vl or rng.randint(1, maxvl)
        n = 4 * vl
        for _ in range(200):
            pick = (lambda: rng.choice(bufs)) if bufs and rng.random() < 0.7 else (lambda: self.spm_range(n))
            a, b = pick(), pick()
            r = rng.random()
            d = a if r < 0.2 else b if r < 0.3 else pick()
            ok = all(M.isect(d, d + n, s, s + n) is False or d == s for s in (a, b))
            inside = all(self.arena[0] <= x and x + n <= self.arena[1] for x in (a, b, d))
            if ok and inside:
                break
        else:
            a, b, d = self.arena[0], self.arena[0], self.arena[0]
            vl = min(vl, (self.arena[1] - self.arena[0]) // 4)
        rm = rng.randint(0, 4) if rm is None else rm
        self.d(op, sa=a, sb=b, dst=d, length=vl, rm=rm, flags=flags, hold=hold)
        return d, n

    def load(self, nbytes=None, maxb=512, dst=None, src=None, flags=0):
        rng = self.rng
        nbytes = nbytes or rng.randint(1, maxb)
        dst = self.spm_range(nbytes) if dst is None else dst
        src = self.ext_range(nbytes) if src is None else src
        self.d(A.OP_DMA_LOAD, sa=src, dst=dst, length=nbytes, flags=flags)
        return dst, nbytes

    def store(self, nbytes=None, maxb=512, dst=None, src=None, flags=0):
        rng = self.rng
        nbytes = nbytes or rng.randint(1, maxb)
        src = self.spm_range(nbytes) if src is None else src
        dst = self.ext_range(nbytes) if dst is None else dst
        self.d(A.OP_DMA_STORE, sa=src, dst=dst, length=nbytes, flags=flags)
        return dst, nbytes

    def nop(self, flags=0):
        self.d(A.OP_NOP, flags=flags)

    def fence(self, flags=0):
        self.d(A.OP_FENCE, flags=flags)

    def words_of(self, lo, n, k=8):
        """Up to k word addresses spread over [lo, lo+n)."""
        ws = list(range(lo & ~3, lo + n, 4))
        if len(ws) <= k:
            return ws
        return sorted(self.rng.sample(ws, k))

    # ------------------------------------------------------------------ output
    def write(self, outdir):
        os.makedirs(outdir, exist_ok=True)
        m = self.model
        n = len(self.cmds)

        def hexw(path, rows, width):
            with open(os.path.join(outdir, path), "w") as fh:
                for r in rows:
                    fh.write(f"{r:0{width // 4}x}\n")

        hexw("cmds.hex", [A.words_to_int(c) for c in self.cmds], 256)
        hexw("ctl.hex", self.ctl, 32)
        hexw("exp.hex", [A.words_to_int(r[0]) for r in m.records], 128)
        hexw("expm.hex", [A.words_to_int(r[1]) for r in m.records], 128)
        hexw("alt.hex", [A.words_to_int(r[2]) if r[2] else 0 for r in m.records], 128)
        hexw("altm.hex", [A.words_to_int(r[3]) if r[3] else 0 for r in m.records], 128)
        hexw("ext_init.hex", self.ext_init, 32)
        hexw("ext_exp.hex", m.ext.val, 32)
        hexw("ext_care.hex", [1 if ok else 0 for ok in m.ext.ok], 4)
        hexw("spm_init.hex", [(a << 32) | v for a, v in self.spm_init_list], 64)
        chk = []
        for lo, hi in (self.arena, self.top):
            for a in range(lo, min(hi, self.phys_end), 4):
                v, ok = m.spm.rd(a)
                if ok:
                    chk.append((a << 32) | v)
        hexw("spm_chk.hex", chk, 64)
        hexw("chk.hex", [(i << 64) | (a << 32) | v for i, a, v in self.checks], 96)
        # model-side statistics for the testbench's counter checks
        recs = [A.rec_fields(r[0]) for r in m.records]
        meta = dict(name=self.name, seed=self.seed, ncmd=n, nspmi=len(self.spm_init_list),
                    nspmc=len(chk), nchk=len(self.checks), cont0=int(self.cont0),
                    ext_err=list(self.cfg.ext_err), ext_hang=list(self.cfg.ext_hang),
                    n_alt=sum(1 for r in m.records if r[2]),
                    n_err=sum(1 for r in recs if r["st"] == A.ST_ERROR),
                    n_skip=sum(1 for r in recs if r["st"] == A.ST_SKIPPED),
                    scratch=list(self.scratch), **self.meta)
        _write_json(os.path.join(outdir, "meta.json"), meta)
        return meta


def _write_json(path, obj):
    """Atomic: readers never see a partially written file."""
    tmp = f"{path}.tmp{os.getpid()}"
    with open(tmp, "w") as fh:
        json.dump(obj, fh, indent=1)
    os.replace(tmp, path)


# ============================================================================ recipes
def r_smoke(p):
    """Stage 1: the brief's first four opcodes in their simplest sequence."""
    a, n = p.load(nbytes=37 * 4)
    b, _ = p.load(nbytes=37 * 4)
    p.nop()
    dd = p.spm_range(37 * 4)
    while M.isect(dd, dd + n, a, a + n) or M.isect(dd, dd + n, b, b + n):
        dd = p.spm_range(37 * 4)
    p.d(A.OP_VECTOR_ADD, sa=a, sb=b, dst=dd, length=37, rm=0)
    p.fence(flags=1)
    p.sync(check=p.words_of(dd, n, 37))
    p.nop()


def r_rand(p, n=120, maxvl=48, maxb=384):
    """Random mix over a few hot buffers (dependencies are frequent)."""
    rng = p.rng
    bufs = [p.arena[0] + 256 * k for k in range(16)]
    ops = ["nop", "load", "vec", "fence"] if p.stage1 else ["nop", "load", "store", "vec", "fence", "rst"]
    w = [1, 4, 5, 1] if p.stage1 else [1, 4, 3, 5, 1, 0.2]
    last_dst = []
    for i in range(n):
        op = rng.choices(ops, w)[0]
        fl = (1 if rng.random() < 0.15 else 0) | (2 if rng.random() < 0.08 else 0)
        if op == "nop":
            p.nop(flags=fl)
        elif op == "fence":
            p.fence(flags=fl)
            if rng.random() < 0.5 and last_dst:
                p.sync(check=[x for lo, nn in last_dst[-3:] for x in p.words_of(lo, nn, 4)])
        elif op == "rst":
            p.d(A.OP_RESET_COUNTERS, flags=fl & 1)
        elif op == "load":
            nb = rng.randint(1, maxb)
            dst = rng.choice(bufs) if rng.random() < 0.6 else None
            if dst is not None and dst + nb > p.arena[1]:
                dst = None
            last_dst.append(p.load(nbytes=nb, dst=dst, flags=fl))
        elif op == "store":
            nb = rng.randint(1, maxb)
            src = rng.choice(bufs) if rng.random() < 0.6 else None
            if src is not None and src + nb > p.arena[1]:
                src = None
            last_dst.append(p.store(nbytes=nb, src=src, flags=fl))
        else:
            last_dst.append(p.vec(maxvl=maxvl, flags=fl, bufs=bufs))
    p.fence()


def r_b2b(p, n=200):
    """Back-to-back control commands: decode / commit throughput, ROB / FIFO full."""
    rng = p.rng
    for i in range(n):
        r = rng.random()
        if r < 0.7:
            p.nop(flags=rng.randint(0, 3))
        elif r < 0.85:
            p.fence()
        else:
            p.d(rng.choice([0x05, 0x13, 0x21, 0x31, 0xFF]))      # reserved opcodes
            p.sync(clear=True)


def r_deps(p):
    """Directed RAW / WAR / WAW between DMA and vector jobs, byte-exact edges."""
    rng = p.rng
    base = p.arena[0]
    vl = 64
    n = 4 * vl
    A_, B_, D_ = base + 0x400, base + 0x800, base + 0x1000
    p.load(nbytes=n, dst=A_)
    p.load(nbytes=n, dst=B_)
    p.fence()
    for k in range(6):
        add = A.OP_VECTOR_ADD
        op = add if p.stage1 else rng.choice(sorted(A.VEC_OPS))
        # RAW: the vector op reads what the DMA just wrote (last word only overlaps)
        p.load(nbytes=n, dst=A_ - n + 4)          # writes [A-n+4, A+4): one word of A
        p.d(op, sa=A_, sb=B_, dst=D_, length=vl, rm=rng.randint(0, 4))
        # WAR: DMA overwrites a vector source while the vector op may still read it
        p.d(op, sa=A_, sb=B_, dst=D_ + 0x400, length=vl, rm=0)
        p.load(nbytes=8, dst=B_ + n - 8)          # last two words of B
        # WAW: DMA and vector write the same words
        p.d(op, sa=A_, sb=B_, dst=D_ + 0x800, length=vl, rm=0)
        p.load(nbytes=6, dst=D_ + 0x800 + 4 * rng.randint(0, vl - 2))   # tail strobe, 6 bytes
        # independent pair: must be allowed to overlap
        p.load(nbytes=n, dst=base)
        p.d(op, sa=A_, sb=B_, dst=D_ + 0xC00, length=vl, rm=0)
        # adjacent but disjoint (no conflict): DMA ends exactly where the vector source starts
        p.load(nbytes=n, dst=A_ - n)
        p.d(op, sa=A_, sb=B_, dst=D_ + 0x400, length=vl, rm=0)
        if not p.stage1:
            # store of a vector result (RAW across units), and a load into the source of that store (WAR)
            p.store(nbytes=n, src=D_)
            p.load(nbytes=n, dst=D_)
            # DMA rounded-up read footprint: STORE of 5 bytes reads the whole second word
            p.store(nbytes=5, src=D_ + 0xC00)
            p.d(op, sa=A_, sb=B_, dst=D_ + 0xC00 + 4, length=4, rm=0)
        p.fence()
        p.sync(check=p.words_of(D_, 0x1000, 24))


def r_dbuf(p, tiles=10, vl=96):
    """Double-buffered pipeline: load tile k+1 while computing tile k, then store."""
    n = 4 * vl
    base = p.arena[0]
    buf = [(base + 0x0000, base + 0x0800), (base + 0x1000, base + 0x1800)]
    out = [base + 0x0400, base + 0x1400]
    ext_out = p.cfg.ext_base + 0x10000
    p.load(nbytes=n, dst=buf[0][0])
    p.load(nbytes=n, dst=buf[0][1])
    for k in range(tiles):
        cur, nxt = k % 2, (k + 1) % 2
        if k + 1 < tiles:
            p.load(nbytes=n, dst=buf[nxt][0])
            p.load(nbytes=n, dst=buf[nxt][1])
        op = A.OP_VECTOR_ADD if p.stage1 else p.rng.choice(sorted(A.VEC_OPS))
        p.d(op, sa=buf[cur][0], sb=buf[cur][1], dst=out[cur], length=vl, rm=p.rng.randint(0, 4))
        if not p.stage1:
            p.store(nbytes=n, src=out[cur], dst=ext_out + k * n)
    p.fence()
    p.sync(check=p.words_of(out[0], n, 8) + p.words_of(out[1], n, 8))


def r_errors(p):
    """Every validation rule for every implemented opcode, continue then stop mode."""
    rng = p.rng
    c = p.cfg
    sb, eb = c.spm_base, c.ext_base
    se, ee = sb + c.spm_size, eb + c.ext_size
    ok_ops = A.STAGE1_OPS if p.stage1 else set(A.OPCODES)
    bad = []
    # VERSION / OPCODE / FLAGS / RSVD
    bad += [dict(op=A.OP_NOP, ver=0), dict(op=A.OP_NOP, ver=2), dict(op=A.OP_DMA_LOAD, ver=15)]
    bad += [dict(op=o) for o in (0x03, 0x0F, 0x13, 0x1F, 0x21, 0x2F, 0x31, 0x40, 0x80, 0xFF)]
    if p.stage1:
        bad += [dict(op=o) for o in (A.OP_DMA_STORE, A.OP_VECTOR_MUL, A.OP_VECTOR_FMA, A.OP_RESET_COUNTERS)]
    bad += [dict(op=A.OP_NOP, flags=0x04), dict(op=A.OP_FENCE, flags=0x80),
            dict(op=A.OP_DMA_LOAD, sa=eb, dst=sb, length=4, flags=0xFC)]
    bad += [dict(op=A.OP_NOP, rsvd15=1), dict(op=A.OP_NOP, w6=1), dict(op=A.OP_FENCE, w7=0x80000000),
            dict(op=A.OP_NOP, sa=4), dict(op=A.OP_FENCE, length=1), dict(op=A.OP_NOP, rm=1),
            dict(op=A.OP_NOP, stride=4), dict(op=A.OP_DMA_LOAD, sa=eb, sb=4, dst=sb, length=4),
            dict(op=A.OP_DMA_LOAD, sa=eb, dst=sb, length=4, rm=3)]
    # STRIDE / RM / LENGTH / ALIGN / RANGE / OVERLAP
    vadd = A.OP_VECTOR_ADD
    bad += [dict(op=A.OP_DMA_LOAD, sa=eb, dst=sb, length=4, stride=4),
            dict(op=vadd, sa=sb, sb=sb + 64, dst=sb + 128, length=4, stride=8),
            dict(op=vadd, sa=sb, sb=sb + 64, dst=sb + 128, length=4, rm=5),
            dict(op=vadd, sa=sb, sb=sb + 64, dst=sb + 128, length=4, rm=7),
            dict(op=A.OP_DMA_LOAD, sa=eb, dst=sb, length=0),
            dict(op=A.OP_DMA_LOAD, sa=eb, dst=sb, length=(1 << 24) + 1),
            dict(op=vadd, sa=sb, sb=sb, dst=sb, length=0),
            dict(op=vadd, sa=sb, sb=sb, dst=sb, length=1 << 16),
            dict(op=A.OP_DMA_LOAD, sa=eb + 2, dst=sb, length=4),
            dict(op=A.OP_DMA_LOAD, sa=eb, dst=sb + 1, length=4),
            dict(op=vadd, sa=sb + 4, sb=sb + 66, dst=sb + 128, length=4),
            dict(op=vadd, sa=sb, sb=sb + 64, dst=sb + 131, length=4),
            dict(op=A.OP_DMA_LOAD, sa=ee - 4, dst=sb, length=8),          # src crosses EXT end
            dict(op=A.OP_DMA_LOAD, sa=eb, dst=se - 4, length=5),          # dst crosses SPM end
            dict(op=A.OP_DMA_LOAD, sa=sb, dst=sb + 0x100, length=4),      # src not in EXT
            dict(op=A.OP_DMA_LOAD, sa=eb, dst=eb + 0x100, length=4),      # dst not in SPM
            dict(op=A.OP_DMA_LOAD, sa=0xFFFFFFFC, dst=sb, length=8),      # wraps
            dict(op=A.OP_DMA_LOAD, sa=eb - 4, dst=sb, length=8),          # starts below EXT
            dict(op=vadd, sa=se - 8, sb=sb, dst=sb + 0x200, length=4),    # A crosses SPM end
            dict(op=vadd, sa=sb, sb=eb, dst=sb + 0x200, length=4),        # B in EXT
            dict(op=vadd, sa=sb, sb=sb + 0x100, dst=sb - 0x10, length=4), # D below SPM
            dict(op=vadd, sa=sb, sb=sb + 0x100, dst=sb + 4, length=4),    # D partially overlaps A
            dict(op=vadd, sa=sb, sb=sb + 0x100, dst=sb + 0xF8, length=4)] # D partially overlaps B
    if not p.stage1:
        vm, vf = A.OP_VECTOR_MUL, A.OP_VECTOR_FMA
        bad += [dict(op=A.OP_DMA_STORE, sa=eb, dst=eb + 64, length=4),       # src not in SPM
                dict(op=A.OP_DMA_STORE, sa=sb, dst=sb + 64, length=4),       # dst not in EXT
                dict(op=A.OP_DMA_STORE, sa=sb, dst=ee - 2, length=4),        # dst crosses EXT end
                dict(op=A.OP_DMA_STORE, sa=sb, dst=eb, length=4, rm=1),
                dict(op=vm, sa=sb, sb=sb + 64, dst=sb + 128, length=4, rm=6),
                dict(op=vf, sa=sb, sb=sb + 64, dst=sb + 2, length=4),
                dict(op=vf, sa=sb, sb=sb + 0x40, dst=sb + 0x3C, length=4),  # partial overlap with B
                dict(op=A.OP_RESET_COUNTERS, sa=4), dict(op=A.OP_RESET_COUNTERS, flags=0x02 | 0x10)]
    rng.shuffle(bad)
    # continue mode: every error reported, valid commands in between still execute
    p.set_mode(1)
    for k, kw in enumerate(bad):
        tid = rng.randint(0, 255)
        p.cmd(A.pack_desc(tid=tid, **kw))
        if rng.random() < 0.4:
            p.vec(maxvl=16) if rng.random() < 0.5 else p.load(maxb=64)
    p.fence()
    p.sync(mode=0)
    # stop mode: the first error makes every later command SKIPPED until cleared
    for k in range(6):
        p.load(maxb=64)
        p.cmd(A.pack_desc(tid=rng.randint(0, 255), **rng.choice(bad)))
        for _ in range(rng.randint(1, 4)):
            r = rng.random()
            p.nop() if r < 0.3 else p.vec(maxvl=16) if r < 0.6 else p.load(maxb=64) if r < 0.8 else p.fence()
        p.sync(clear=True)
    p.vec(maxvl=8)
    p.fence()


def r_fp(p, n=40):
    """Vector FP coverage: every rounding mode, special operands, all flags."""
    rng = p.rng
    base = p.arena[0]
    # special-heavy operand area
    for k, a in enumerate(range(base, base + 0x800, 4)):
        v = SPECIALS[k % len(SPECIALS)] if rng.random() < 0.5 else rand_fp(rng, 30)
        p.model.spm.wr(a, v, True)
        p.spm_init_list = [(x, y) if x != a else (a, v) for x, y in p.spm_init_list]
    ops = [A.OP_VECTOR_ADD] if p.stage1 else sorted(A.VEC_OPS)
    for i in range(n):
        op = ops[i % len(ops)]
        vl = rng.randint(1, 64)
        nb = 4 * vl
        a = base + 4 * rng.randint(0, 0x200 - vl - 1)
        b = base + 4 * rng.randint(0, 0x200 - vl - 1)
        d = base + 0x800 + 4 * rng.randint(0, 0x100)
        p.d(op, sa=a, sb=b, dst=d, length=vl, rm=i % 5)
    p.fence()
    p.sync(check=p.words_of(base + 0x800, 0x500, 32))


def r_long(p):
    """Long vectors (up to the arena) and long DMA transfers."""
    rng = p.rng
    base = p.arena[0]
    arena_w = (p.arena[1] - p.arena[0]) // 4
    for k in range(4):
        vl = rng.randint(arena_w // 4, arena_w // 3)
        n = 4 * vl
        p.load(nbytes=n, dst=base)
        p.load(nbytes=n - rng.randint(0, 3), dst=base + n)
        op = A.OP_VECTOR_ADD if p.stage1 else rng.choice(sorted(A.VEC_OPS))
        p.d(op, sa=base, sb=base + n, dst=base + 2 * n, length=vl, rm=rng.randint(0, 4))
        if not p.stage1:
            p.store(nbytes=n, src=base + 2 * n, dst=p.cfg.ext_base + 0x8000)
        p.fence()
        p.sync(check=p.words_of(base + 2 * n, n, 16))


def r_dma_fault(p):
    """External-memory bus errors: READ_BUS (load), WRITE_BUS (store), both modes."""
    rng = p.rng
    c = p.cfg
    elo, ehi = c.ext_err
    for mode in (1, 0):
        p.set_mode(mode)
        for k in range(5):
            p.load(maxb=128)
            # a load whose source crosses into the error window: prefix copied, then READ_BUS
            nb = rng.randint(8, 128)
            p.load(nbytes=nb, src=elo - 4 * rng.randint(0, nb // 4 - 1))
            # independent vector op on the other unit: overlaps the failing DMA in stop mode
            p.vec(maxvl=16)
            p.nop()
            if not p.stage1:
                nb = rng.randint(8, 128)
                p.store(nbytes=nb, dst=ehi - 4 * rng.randint(1, nb // 4))
                p.vec(maxvl=8)
            p.fence()
            p.sync(clear=True)


def r_spm_fault(p):
    """Scratchpad RANGE errors (window larger than the physical scratchpad)."""
    rng = p.rng
    phys = p.phys_end
    for mode in (1, 0):
        p.set_mode(mode)
        for k in range(4):
            nb = rng.randint(8, 64)
            p.load(nbytes=nb, dst=phys - 4 * rng.randint(1, nb // 4))       # WRITE_BUS at phys end
            p.vec(maxvl=8)
            vl = rng.randint(2, 16)
            a = phys - 4 * rng.randint(1, vl - 1)                              # A crosses phys end
            p.d(A.OP_VECTOR_ADD, sa=a, sb=p.arena[0], dst=p.arena[0] + 0x400, length=vl)
            # destination crosses the physical end, sources fine: VEC_WRITE
            p.d(A.OP_VECTOR_ADD, sa=p.arena[0], sb=p.arena[0] + 0x100, dst=phys - 4 * rng.randint(1, vl - 1),
                length=vl)
            if not p.stage1:
                p.store(nbytes=nb, src=phys - 4 * rng.randint(1, nb // 4))  # READ_BUS
            p.load(maxb=32)
            p.fence()
            p.sync(clear=True)


def r_timeout_dma(p, cont):
    """DMA engine hangs (slave never answers): TIMEOUT, then UNIT_DOWN."""
    lo, hi = p.cfg.ext_hang
    p.set_mode(cont)
    p.load(maxb=64)
    p.vec(maxvl=8)
    p.load(nbytes=64, src=lo - 32)                 # hangs at its 9th beat
    p.vec(maxvl=8)                                 # independent: may overlap the hang
    p.nop()
    p.load(maxb=16)                                # unit down (continue) / skipped (stop)
    p.vec(maxvl=8)
    p.fence()
    p.sync(clear=True)
    p.load(maxb=16)                                # still down: quarantine lasts until reset
    p.vec(maxvl=8)
    p.fence()


def r_timeout_vec(p, cont):
    """Vector executor stalls (lanes held forever): TIMEOUT, then UNIT_DOWN."""
    p.set_mode(cont)
    p.load(maxb=64)
    p.vec(maxvl=8)
    p.fence()
    p.vec(vl=40, hold=True)
    p.load(maxb=32)
    p.vec(maxvl=8)
    p.fence()
    p.sync(clear=True)
    p.vec(maxvl=8)
    p.load(maxb=32)
    p.fence()


def r_rstcnt(p):
    """RESET_COUNTERS mid-stream; the TB checks the counters against the records."""
    r_rand(p, n=40)
    p.d(A.OP_RESET_COUNTERS)
    r_rand(p, n=40)
    p.meta["rstcnt"] = 1


def r_perf(p, kind):
    """Performance characterisation programs (one kind of command each)."""
    sb = p.arena[0]
    if kind == "nop":
        for _ in range(256):
            p.nop()
    elif kind == "fence":
        for _ in range(64):
            p.fence()
    elif kind.startswith("load"):
        n = int(kind[4:])
        p.load(nbytes=n, dst=sb, src=p.cfg.ext_base)
    elif kind.startswith("store"):
        n = int(kind[5:])
        p.store(nbytes=n, src=sb, dst=p.cfg.ext_base)
    elif kind[:4] in ("vadd", "vmul", "vfma"):
        vl = int(kind[4:])
        op = {"vadd": A.OP_VECTOR_ADD, "vmul": A.OP_VECTOR_MUL, "vfma": A.OP_VECTOR_FMA}[kind[:4]]
        p.d(op, sa=sb, sb=sb + 4 * vl, dst=sb + 8 * vl, length=vl, rm=0)
    elif kind == "pair_indep":       # a DMA and an independent vector job: should overlap
        p.load(nbytes=1024, dst=sb + 0x1000, src=p.cfg.ext_base)
        p.d(A.OP_VECTOR_ADD, sa=sb, sb=sb + 0x400, dst=sb + 0x800, length=256)
    elif kind == "pair_dep":         # the vector job reads what the DMA writes: must serialise
        p.load(nbytes=1024, dst=sb, src=p.cfg.ext_base)
        p.d(A.OP_VECTOR_ADD, sa=sb, sb=sb + 0x400, dst=sb + 0x800, length=256)


RECIPES = {
    "smoke": r_smoke, "rand": r_rand, "b2b": r_b2b, "deps": r_deps, "dbuf": r_dbuf,
    "errors": r_errors, "fp": r_fp, "long": r_long, "dma_fault": r_dma_fault,
    "spm_fault": r_spm_fault, "timeout_dma": lambda p: r_timeout_dma(p, p.cont0),
    "timeout_vec": lambda p: r_timeout_vec(p, p.cont0), "rstcnt": r_rstcnt,
}
for _k in ("nop", "fence", "load64", "load1024", "load4096", "store1024", "vadd16", "vadd256", "vadd1024",
           "vmul256", "vfma256", "pair_indep", "pair_dep"):
    RECIPES["perf_" + _k] = (lambda k: (lambda p: r_perf(p, k)))(_k)
STAGE1_RECIPES = ["smoke", "rand", "b2b", "deps", "dbuf", "errors", "fp", "long", "dma_fault"]


def build(recipe, seed, outdir, stage1=False, overlap=True, spm_phys_log2=16, cont=False, arena=8192):
    ext_err = (0, 0)
    ext_hang = (0, 0)
    if recipe == "dma_fault":
        lo = 0x10000000 + 0x4000 * random.Random(seed).randint(1, 6)
        ext_err = (lo, lo + 0x100)
    if recipe == "timeout_dma":
        ext_hang = (0x1001C000, 0x1001C004)
    cfg = M.Cfg(opset_full=not stage1, overlap_en=overlap, spm_phys_log2=spm_phys_log2,
                ext_err=ext_err, ext_hang=ext_hang)
    if recipe[:9] in ("perf_vadd", "perf_vmul", "perf_vfma"):
        need = 12 * int(recipe[9:])                      # A, B and D side by side
        while arena < need:
            arena *= 2
    p = Prog(recipe, seed, cfg, cont=cont, arena=arena, stage1=stage1)
    RECIPES[recipe](p)
    meta = p.write(outdir)
    meta.update(stage1=int(stage1), overlap=int(overlap), spm_phys_log2=spm_phys_log2)
    _write_json(os.path.join(outdir, "meta.json"), meta)
    return meta


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("recipe", choices=sorted(RECIPES))
    ap.add_argument("outdir")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--stage1", action="store_true")
    ap.add_argument("--no-overlap", action="store_true")
    ap.add_argument("--cont", action="store_true")
    ap.add_argument("--spm-phys-log2", type=int, default=16)
    a = ap.parse_args()
    meta = build(a.recipe, a.seed, a.outdir, a.stage1, not a.no_overlap, a.spm_phys_log2, a.cont)
    print(json.dumps(meta))


if __name__ == "__main__":
    main()
