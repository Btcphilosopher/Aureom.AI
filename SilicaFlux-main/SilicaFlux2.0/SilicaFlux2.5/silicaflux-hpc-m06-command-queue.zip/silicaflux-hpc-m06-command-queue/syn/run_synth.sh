#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Module 06 :: run_synth.sh -- Yosys 0.33 synthesis evidence
#
#   generic  synth -flatten, check -assert, no latches; cell / flip-flop counts
#            hpc_command_queue at QUEUE_DEPTH 4 / 8 / 16 (ROB 8), ROB 4 / 16,
#            OPSET_FULL 0, hpc_cq_vexec (N 2 / 4), hpc_cq_mmio, hpc_cq_tile (N 2)
#   ecp5     synth_ecp5 (LUT4 / FF counts) for the queue at each depth
#   struct   structural proof: no combinational path from any input of
#            hpc_command_queue to its handshake / control / status outputs
#            (the cone of each such output, cut at flip-flops, contains no
#            input), with a positive control
# Results: reports/synth/ (*.txt raw, summary.md)
# =============================================================================
set -u
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/reports/synth"
BLD="$ROOT/build/syn"
mkdir -p "$OUT" "$BLD"
cd "$ROOT"
JOBS="${JOBS:-4}"
INC="$(grep '^+incdir+' rtl/files.f | sed 's/^+incdir+/-I/' | tr '\n' ' ')"
SRC="$(grep -v '^//' rtl/files.f | grep -v '^+incdir' | grep -v '^$' | tr '\n' ' ') rtl/hpc_cq_mmio.sv"
STUB="$(grep -v '^//' rtl/files_sim_stubs.f | tr '\n' ' ')"
READ="read_verilog -defer -sv -DSYNTHESIS $INC $SRC; read_verilog -sv -lib $STUB"
LATCH='select -assert-none t:$dlatch t:$adlatch t:$dlatchsr t:$_DLATCH_* t:$_DLATCHSR_*'

job() {   # kind name top "chparams"
  local kind=$1 name=$2 top=$3 cp=$4 log="$OUT/${2}.log" t0=$SECONDS
  local hier="hierarchy -check -top $top $cp"
  case $kind in
    generic) yosys -q -p "$READ; $hier; synth -top $top -flatten; check -assert; $LATCH;
                tee -q -o $OUT/${name}_stat.txt stat" > "$log" 2>&1 ;;
    ecp5)    yosys -q -p "$READ; $hier; synth_ecp5 -top $top; check -assert; $LATCH;
                tee -q -o $OUT/${name}_stat.txt stat" > "$log" 2>&1 ;;
  esac
  echo "$name exit=$? $((SECONDS - t0)) s" | tee -a "$OUT/timing.txt"
}

: > "$OUT/timing.txt"
JOBLIST=(
  "generic|cq_qd4|hpc_command_queue|-chparam QUEUE_DEPTH 4"
  "generic|cq_qd8|hpc_command_queue|-chparam QUEUE_DEPTH 8"
  "generic|cq_qd16|hpc_command_queue|-chparam QUEUE_DEPTH 16"
  "generic|cq_qd8_rob4|hpc_command_queue|-chparam QUEUE_DEPTH 8 -chparam ROB_DEPTH 4"
  "generic|cq_qd8_rob16|hpc_command_queue|-chparam QUEUE_DEPTH 8 -chparam ROB_DEPTH 16"
  "generic|cq_qd8_stage1|hpc_command_queue|-chparam QUEUE_DEPTH 8 -chparam OPSET_FULL 0"
  "generic|cq_qd8_noperf|hpc_command_queue|-chparam QUEUE_DEPTH 8 -chparam PERF_EN 0"
  "generic|vexec_n2|hpc_cq_vexec|-chparam N 2"
  "generic|vexec_n4|hpc_cq_vexec|-chparam N 4"
  "generic|mmio|hpc_cq_mmio|"
  "ecp5|ecp5_cq_qd4|hpc_command_queue|-chparam QUEUE_DEPTH 4"
  "ecp5|ecp5_cq_qd8|hpc_command_queue|-chparam QUEUE_DEPTH 8"
  "ecp5|ecp5_cq_qd16|hpc_command_queue|-chparam QUEUE_DEPTH 16"
  "ecp5|ecp5_vexec_n2|hpc_cq_vexec|-chparam N 2"
  "ecp5|ecp5_mmio|hpc_cq_mmio|"
  "generic|tile_n2|hpc_cq_tile|-chparam NUM_LANES 2"
)
for j in "${JOBLIST[@]}"; do
  IFS='|' read -r kind name top cp <<< "$j"
  if [ -n "${ONLY:-}" ] && ! [[ "$name" =~ $ONLY ]]; then continue; fi
  while [ "$(jobs -rp | wc -l)" -ge "$JOBS" ]; do wait -n; done
  job "$kind" "$name" "$top" "$cp" &
done
wait
if grep -v "exit=0" "$OUT/timing.txt"; then echo "SYNTHESIS JOB FAILED"; exit 1; fi

# ----------------------------------------------------------------------------
# structural check
# ----------------------------------------------------------------------------
STOP=':-$dff:-$adff:-$dffe:-$adffe:-$sdff:-$sdffe:-$sdffce:-$aldff:-$aldffe:-$dffsr:-$dffsre'
OUTS='o:cmd_ready_o o:cpl_valid_o o:cpl_rec_o o:dma_start_o o:dma_abort_o o:dma_src_o o:dma_dst_o o:dma_len_o
      o:vec_start_o o:vec_op_o o:vec_rm_o o:vec_src_a_o o:vec_src_b_o o:vec_dst_o o:vec_vl_o o:vec_tid_o
      o:busy_o o:q_count_o o:q_full_o o:q_empty_o o:rob_count_o o:err_sticky_o o:dma_down_o o:vec_down_o
      o:ev_commit_o o:ev_commit_err_o o:ev_commit_irq_o o:perf_cnt_o'
OUTS="$(echo $OUTS | tr '\n' ' ')"
SC="$OUT/structural_check.txt"
: > "$SC"
for qd in 4 8 16; do
  yosys -q -p "$READ; hierarchy -check -top hpc_command_queue -chparam QUEUE_DEPTH $qd;
    proc; flatten; memory; opt -fast;
    select -set ins i:* i:clk_i i:rst_ni %d %d;
    select -set outs $OUTS;
    select -set cone @outs %ci*$STOP;
    tee -q -o $BLD/sc_qd$qd.txt select -list @cone @ins %i;
    select -set pc w:q_push %ci*$STOP;
    tee -q -o $BLD/pc_qd$qd.txt select -list @pc @ins %i" > "$BLD/struct_qd$qd.log" 2>&1
  viol=$(grep -c "hpc_command_queue/" "$BLD/sc_qd$qd.txt" || true)
  pc=$(grep -c "cmd_valid_i" "$BLD/pc_qd$qd.txt" || true)
  echo "QUEUE_DEPTH=$qd  inputs combinationally reaching the registered interface outputs: $viol" \
       " | positive control (FIFO push <- cmd_valid_i): $pc" >> "$SC"
  if [ "$viol" != 0 ] || [ "$pc" != 1 ]; then cat "$SC"; echo "STRUCTURAL CHECK FAILED"; exit 1; fi
done
cat "$SC"
python3 -I "$ROOT/scripts/synth_summary.py" "$OUT"
echo "== synthesis done"
