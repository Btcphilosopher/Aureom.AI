# Mutation testing

**36 / 37 injected design bugs detected; 1 proven equivalent (no behavioural difference exists); 0 undetected.**

Each mutant is one deliberate bug in the new RTL; quick regression runs are tried in order until one fails.

| id | file | injected bug | killed by | detail |
|---|---|---|---|---|
| M01 | `hpc_cq_sched.sv` | no dependency check for a DMA command against the running vector job | deps | sched.sv:476: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sched: hpc_cq_sched: dependent DMA and vector jobs |
| M02 | `hpc_cq_sched.sv` | vector command: WAR check against the DMA read footprint missing | deps | sched.sv:475: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sched: hpc_cq_sched: dependent DMA and vector jobs |
| M03 | `hpc_cq_sched.sv` | vector command: RAW check of source B against the DMA write missing | deps | sched.sv:475: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sched: hpc_cq_sched: dependent DMA and vector jobs |
| M04 | `hpc_cq_sched.sv` | FENCE does not wait for older commands | rand | TB_RESULT FAIL errors=13 cmds=121 prog_cycles=15203 cycles=10228 alt=0 overlap=2141 hazard_stall=393 unit_stall=1768 syn |
| M05 | `hpc_cq_sched.sv` | FL_BARRIER ignored | rand | TB_RESULT FAIL errors=4 cmds=121 prog_cycles=15042 cycles=10255 alt=0 overlap=2299 hazard_stall=404 unit_stall=1530 sync |
| M06 | `hpc_cq_sched.sv` | stop-on-error never skips younger commands | errors | TB_RESULT FAIL errors=62 cmds=109 prog_cycles=961 cycles=8087 alt=0 overlap=269 hazard_stall=0 unit_stall=368 sync_stall |
| M07 | `hpc_cq_sched.sv` | execution errors do not make the queue sticky | dma_fault | TB_RESULT FAIL errors=40 cmds=70 prog_cycles=1987 cycles=8927 alt=0 overlap=382 hazard_stall=0 unit_stall=1590 sync_stal |
| M08 | `hpc_cq_sched.sv` | DMA command issued while the DMA engine is busy | rand | initialised
[76285000] %Error: hpc_cq_sva.sv:46: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sva.a_dma_start |
| M09 | `hpc_cq_rob.sv` | records committed before the command completed | rand | TB_RESULT FAIL errors=96 cmds=121 prog_cycles=15404 cycles=10334 alt=0 overlap=2031 hazard_stall=415 unit_stall=1285 syn |
| M10 | `hpc_cq_rob.sv` | record SEQ taken from the wrong entry | rand | initialised
[71205000] %Error: hpc_cq_sva.sv:79: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sva.a_first_rec |
| M11 | `hpc_cq_validate.sv` | misaligned vector source B accepted | errors | TB_RESULT FAIL errors=1 cmds=109 prog_cycles=897 cycles=8023 alt=0 overlap=207 hazard_stall=0 unit_stall=368 sync_stall= |
| M12 | `hpc_cq_validate.sv` | partial destination / source overlap accepted | errors | TB_RESULT FAIL errors=13 cmds=109 prog_cycles=954 cycles=8080 alt=0 overlap=187 hazard_stall=0 unit_stall=479 sync_stall |
| M13 | `hpc_cq_validate.sv` | ALIGN / RANGE priority swapped | errors | TB_RESULT FAIL errors=1 cmds=109 prog_cycles=897 cycles=8023 alt=0 overlap=191 hazard_stall=0 unit_stall=368 sync_stall= |
| M14 | `hpc_cq_pkg.sv` | range check accepts one word past the window | errors | TB_RESULT FAIL errors=4 cmds=109 prog_cycles=918 cycles=8044 alt=0 overlap=190 hazard_stall=0 unit_stall=389 sync_stall= |
| M15 | `hpc_cq_validate.sv` | non-zero stride silently accepted | errors | TB_RESULT FAIL errors=7 cmds=109 prog_cycles=909 cycles=8035 alt=0 overlap=205 hazard_stall=0 unit_stall=433 sync_stall= |
| M16 | `hpc_command_queue.sv` | command accepted while the queue is full (overwrite) | b2b | initialised
[75165000] %Error: hpc_cq_sva.sv:37: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sva.a_full_not_ |
| M17 | `hpc_cq_vexec.sv` | vector job reported done before its writes are acknowledged | rl2 | pc_cq_vexec.sv:331: Assertion failed in TOP.tb_hpc_command_queue.dut.u_vx.g_lane[0]: hpc_cq_vexec lane 0: scratchpad res |
| M18 | `hpc_cq_vexec.sv` | FMA addend taken from A instead of D | fp | TB_RESULT FAIL errors=45 cmds=41 prog_cycles=2751 cycles=9974 alt=0 overlap=0 hazard_stall=0 unit_stall=2683 sync_stall= |
| M19 | `hpc_cq_vexec.sv` | rounding mode not passed to the array | fp | TB_RESULT FAIL errors=35 cmds=41 prog_cycles=2751 cycles=9974 alt=0 overlap=0 hazard_stall=0 unit_stall=2683 sync_stall= |
| M20 | `hpc_cq_vexec.sv` | tail lanes treated as active | rand | TB_RESULT FAIL errors=2081 cmds=121 prog_cycles=67905 cycles=75031 alt=0 overlap=608 hazard_stall=55 unit_stall=1422 syn |
| M21 | `hpc_cq_sched.sv` | DMA error code not mapped into the 0x1X class | dma_fault | TB_RESULT FAIL errors=16 cmds=70 prog_cycles=1890 cycles=8830 alt=0 overlap=342 hazard_stall=0 unit_stall=1556 sync_stal |
| M22 | `hpc_cq_sched.sv` | watchdog disabled (hung unit never reported) | tdma | TB_RESULT FAIL errors=2 global timeout at 40000000 cycles (received 2 of 11) |
| M23 | `hpc_cq_sched.sv` | timed-out DMA engine not quarantined | tdma | r: hpc_cq_sched.sv:460: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sched: hpc_cq_sched: dma_start while the |
| M24 | `hpc_cq_sched.sv` | RESET_COUNTERS does not clear the counters | rstcnt | TB_RESULT FAIL errors=1 cmds=83 prog_cycles=9551 cycles=16678 alt=0 overlap=1700 hazard_stall=446 unit_stall=4262 sync_s |
| M25 | `hpc_cq_validate.sv` | DMA read footprint not rounded up to the last whole word | equivalent |  |
| M26 | `hpc_cq_sched.sv` | OVERLAP_EN = 0 not honoured | ovl0 | r: hpc_cq_sched.sv:478: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sched: hpc_cq_sched: OVERLAP_EN = 0 but  |
| M27 | `hpc_cq_rob.sv` | commands resolved at decode never complete | smoke1 | TB_RESULT FAIL errors=5 cmds=6 prog_cycles=309 cycles=12007244 alt=0 overlap=0 hazard_stall=150 unit_stall=151 sync_stal |
| M28 | `hpc_cq_sched.sv` | sequence numbers skip | smoke1 | initialised
[72695000] %Error: hpc_cq_sva.sv:65: Assertion failed in TOP.tb_hpc_command_queue.dut.u_cq.u_sva.a_in_order_ |
| M29 | `hpc_cq_vexec.sv` | result beats taken without write-back queue space (lost writes) | w1n4 | [1].u_wbq: hpc_varray_fifo TOP.tb_hpc_command_queue.dut.u_vx.g_lane[1].u_wbq: push while full
%Error: third_party/silica |
| M30 | `hpc_cq_sched.sv` | RESET_COUNTERS does not wait for older commits | rstcnt | TB_RESULT FAIL errors=1 cmds=83 prog_cycles=9571 cycles=9020 alt=0 overlap=1709 hazard_stall=0 unit_stall=1109 sync_stal |
| M31 | `hpc_cq_vexec.sv` | results written after a vector read error | spm_fault | TB_RESULT FAIL errors=5 cmds=56 prog_cycles=1127 cycles=7437 alt=0 overlap=148 hazard_stall=320 unit_stall=459 sync_stal |
| M32 | `hpc_cq_sched.sv` | FENCE / BARRIER ignore an in-flight vector job | rand | TB_RESULT FAIL errors=5 cmds=121 prog_cycles=15263 cycles=10252 alt=0 overlap=2097 hazard_stall=394 unit_stall=1231 sync |
| M33 | `hpc_cq_mmio.sv` | MMIO: doorbell counted although the queue is full | mmio | TB_RESULT FAIL errors=1 |
| M34 | `hpc_cq_mmio.sv` | MMIO: CPL_POP with no record not refused | mmio | TB_RESULT FAIL errors=2 |
| M35 | `hpc_cq_mmio.sv` | MMIO: INT_STATUS does not hold events | mmio | TB_RESULT FAIL errors=3 |
| M37 | `hpc_cq_vexec.sv` | vector executor ignores scratchpad write errors | spm_fault | TB_RESULT FAIL errors=4 cmds=56 prog_cycles=1116 cycles=7426 alt=0 overlap=143 hazard_stall=335 unit_stall=447 sync_stal |
| M36 | `hpc_cq_mmio.sv` | MMIO: CPL1..3 read the wrong record word | mmio | TB_RESULT FAIL errors=1 |

## Equivalent mutants

* **M25**: Every vector footprint is word-aligned, so a vector range that touches the DMA's last (partially used) source word always also intersects the un-rounded range [SRC_A, SRC_A+LENGTH); and the bytes of that word beyond LENGTH are read but never written to the destination.  The round-up is kept as a defensive bound for future byte-granular units.
