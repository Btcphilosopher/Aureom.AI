# Regression `stage1`

**162 / 162 runs pass** (6 s wall clock, 11484 commands).

| recipe | simulator | runs | pass | commands | overlap cycles | timing-dependent records |
|---|---|---|---|---|---|---|
| b2b | verilator | 18 | 18 | 3600 | 0 | 0 |
| dbuf | verilator | 18 | 18 | 558 | 13453 | 0 |
| deps | verilator | 18 | 18 | 1242 | 12363 | 0 |
| dma_fault | verilator | 18 | 18 | 900 | 1647 | 0 |
| errors | verilator | 18 | 18 | 1872 | 1662 | 0 |
| fp | verilator | 18 | 18 | 738 | 0 | 0 |
| long | verilator | 18 | 18 | 288 | 0 | 0 |
| rand | verilator | 18 | 18 | 2178 | 13582 | 0 |
| smoke | verilator | 18 | 18 | 108 | 0 | 0 |

## All runs

| run | result | cycles | cmds | overlap | hazard stalls | sync stalls | s |
|---|---|---|---|---|---|---|---|
| `smoke_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 7623 | 6 | 0 | 150 | 68 | 0.4 |
| `rand_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 16884 | 121 | 1523 | 747 | 3254 | 0.4 |
| `b2b_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 7515 | 200 | 0 | 0 | 0 | 0.3 |
| `deps_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 14895 | 69 | 1416 | 2904 | 1807 | 0.4 |
| `dbuf_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 15096 | 31 | 1557 | 213 | 154 | 0.4 |
| `errors_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 8043 | 104 | 184 | 0 | 71 | 0.4 |
| `fp_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 9723 | 41 | 0 | 0 | 22 | 0.4 |
| `long_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 29839 | 16 | 0 | 9448 | 3585 | 0.5 |
| `dma_fault_s1_fast_verilator_N2_OPSET0_OVL1_QD4` | PASS | 8564 | 50 | 177 | 0 | 482 | 0.2 |
| `smoke_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 7779 | 6 | 0 | 225 | 67 | 0.1 |
| `rand_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 20996 | 121 | 1531 | 1148 | 4735 | 0.2 |
| `b2b_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 7792 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 17569 | 69 | 1372 | 3754 | 2707 | 0.1 |
| `dbuf_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 18968 | 31 | 1503 | 399 | 162 | 0.2 |
| `errors_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 8372 | 104 | 205 | 0 | 89 | 0.1 |
| `fp_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 9809 | 41 | 0 | 0 | 22 | 0.1 |
| `long_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 39636 | 16 | 0 | 14322 | 3759 | 0.3 |
| `dma_fault_s1_rand_verilator_N2_OPSET0_OVL1_QD4` | PASS | 9222 | 50 | 183 | 0 | 723 | 0.1 |
| `smoke_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 7990 | 6 | 0 | 353 | 68 | 0.1 |
| `rand_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 26924 | 121 | 1471 | 1691 | 6855 | 0.2 |
| `b2b_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 9066 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 21572 | 69 | 1320 | 4854 | 4073 | 0.1 |
| `dbuf_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 24728 | 31 | 1432 | 724 | 154 | 0.2 |
| `errors_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 9211 | 104 | 175 | 0 | 135 | 0.1 |
| `fp_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 9732 | 41 | 0 | 0 | 22 | 0.1 |
| `long_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 53478 | 16 | 0 | 21007 | 3585 | 0.3 |
| `dma_fault_s1_bp_verilator_N2_OPSET0_OVL1_QD4` | PASS | 10548 | 50 | 189 | 0 | 1095 | 0.1 |
| `smoke_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 7623 | 6 | 0 | 0 | 369 | 0.3 |
| `rand_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 18335 | 121 | 0 | 0 | 10789 | 0.2 |
| `b2b_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 7515 | 200 | 0 | 0 | 0 | 0.2 |
| `deps_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 16185 | 69 | 0 | 0 | 8522 | 0.2 |
| `dbuf_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 16491 | 31 | 0 | 0 | 9280 | 0.4 |
| `errors_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 8221 | 104 | 0 | 0 | 673 | 0.3 |
| `fp_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 9723 | 41 | 0 | 0 | 2454 | 0.4 |
| `long_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 29839 | 16 | 0 | 0 | 22481 | 0.3 |
| `dma_fault_s1_fast_verilator_N2_OPSET0_OVL0_QD4` | PASS | 8722 | 50 | 0 | 0 | 1460 | 0.2 |
| `smoke_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 7779 | 6 | 0 | 0 | 519 | 0.1 |
| `rand_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 22356 | 121 | 0 | 0 | 14773 | 0.2 |
| `b2b_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 7792 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 18944 | 69 | 0 | 0 | 11248 | 0.1 |
| `dbuf_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 20437 | 31 | 0 | 0 | 13223 | 0.1 |
| `errors_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 8628 | 104 | 0 | 0 | 902 | 0.1 |
| `fp_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 9809 | 41 | 0 | 0 | 2536 | 0.1 |
| `long_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 39636 | 16 | 0 | 0 | 32258 | 0.2 |
| `dma_fault_s1_rand_verilator_N2_OPSET0_OVL0_QD4` | PASS | 9389 | 50 | 0 | 0 | 2082 | 0.1 |
| `smoke_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 7990 | 6 | 0 | 0 | 715 | 0.1 |
| `rand_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 28460 | 121 | 0 | 0 | 20745 | 0.2 |
| `b2b_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 9066 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 22940 | 69 | 0 | 0 | 15195 | 0.2 |
| `dbuf_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 26163 | 31 | 0 | 0 | 18948 | 0.2 |
| `errors_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 9558 | 104 | 0 | 0 | 1140 | 0.1 |
| `fp_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 9732 | 41 | 0 | 0 | 2454 | 0.1 |
| `long_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 53478 | 16 | 0 | 0 | 46058 | 0.3 |
| `dma_fault_s1_bp_verilator_N2_OPSET0_OVL0_QD4` | PASS | 10626 | 50 | 0 | 0 | 3081 | 0.1 |
| `smoke_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 7623 | 6 | 0 | 150 | 68 | 0.1 |
| `rand_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 16884 | 121 | 1523 | 747 | 3254 | 0.1 |
| `b2b_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 7515 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 14895 | 69 | 1416 | 2904 | 1807 | 0.1 |
| `dbuf_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 15096 | 31 | 1557 | 213 | 154 | 0.1 |
| `errors_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 8043 | 104 | 184 | 0 | 71 | 0.1 |
| `fp_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 9723 | 41 | 0 | 0 | 22 | 0.1 |
| `long_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 29839 | 16 | 0 | 9448 | 3585 | 0.2 |
| `dma_fault_s1_fast_verilator_N2_OPSET0_OVL1_QD8` | PASS | 8564 | 50 | 177 | 0 | 482 | 0.1 |
| `smoke_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 7779 | 6 | 0 | 225 | 67 | 0.1 |
| `rand_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 20922 | 121 | 1534 | 1133 | 4715 | 0.2 |
| `b2b_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 7792 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 17603 | 69 | 1381 | 3740 | 2744 | 0.1 |
| `dbuf_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 18970 | 31 | 1488 | 399 | 162 | 0.2 |
| `errors_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 8371 | 104 | 199 | 0 | 90 | 0.1 |
| `fp_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 9820 | 41 | 0 | 0 | 25 | 0.1 |
| `long_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 39636 | 16 | 0 | 14322 | 3759 | 0.2 |
| `dma_fault_s1_rand_verilator_N2_OPSET0_OVL1_QD8` | PASS | 9222 | 50 | 183 | 0 | 723 | 0.1 |
| `smoke_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 7990 | 6 | 0 | 353 | 68 | 0.1 |
| `rand_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 27116 | 121 | 1477 | 1779 | 6927 | 0.2 |
| `b2b_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 8934 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 21632 | 69 | 1326 | 4889 | 4053 | 0.2 |
| `dbuf_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 24689 | 31 | 1433 | 749 | 154 | 0.2 |
| `errors_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 9211 | 104 | 169 | 0 | 129 | 0.1 |
| `fp_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 9732 | 41 | 0 | 0 | 22 | 0.1 |
| `long_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 53478 | 16 | 0 | 21007 | 3585 | 0.3 |
| `dma_fault_s1_bp_verilator_N2_OPSET0_OVL1_QD8` | PASS | 10548 | 50 | 189 | 0 | 1095 | 0.1 |
| `smoke_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 7623 | 6 | 0 | 0 | 369 | 0.1 |
| `rand_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 18335 | 121 | 0 | 0 | 10789 | 0.1 |
| `b2b_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 7515 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 16185 | 69 | 0 | 0 | 8522 | 0.1 |
| `dbuf_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 16491 | 31 | 0 | 0 | 9280 | 0.1 |
| `errors_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 8221 | 104 | 0 | 0 | 673 | 0.1 |
| `fp_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 9723 | 41 | 0 | 0 | 2454 | 0.1 |
| `long_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 29839 | 16 | 0 | 0 | 22481 | 0.2 |
| `dma_fault_s1_fast_verilator_N2_OPSET0_OVL0_QD8` | PASS | 8722 | 50 | 0 | 0 | 1460 | 0.1 |
| `smoke_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 7779 | 6 | 0 | 0 | 519 | 0.1 |
| `rand_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 22382 | 121 | 0 | 0 | 14794 | 0.2 |
| `b2b_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 7792 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 18956 | 69 | 0 | 0 | 11281 | 0.1 |
| `dbuf_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 20370 | 31 | 0 | 0 | 13156 | 0.1 |
| `errors_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 8628 | 104 | 0 | 0 | 905 | 0.1 |
| `fp_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 9820 | 41 | 0 | 0 | 2550 | 0.1 |
| `long_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 39636 | 16 | 0 | 0 | 32258 | 0.2 |
| `dma_fault_s1_rand_verilator_N2_OPSET0_OVL0_QD8` | PASS | 9389 | 50 | 0 | 0 | 2082 | 0.1 |
| `smoke_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 7990 | 6 | 0 | 0 | 715 | 0.1 |
| `rand_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 28444 | 121 | 0 | 0 | 20701 | 0.2 |
| `b2b_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 8934 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 22760 | 69 | 0 | 0 | 15018 | 0.2 |
| `dbuf_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 26085 | 31 | 0 | 0 | 18868 | 0.2 |
| `errors_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 9558 | 104 | 0 | 0 | 1065 | 0.1 |
| `fp_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 9732 | 41 | 0 | 0 | 2454 | 0.1 |
| `long_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 53478 | 16 | 0 | 0 | 46058 | 0.3 |
| `dma_fault_s1_bp_verilator_N2_OPSET0_OVL0_QD8` | PASS | 10626 | 50 | 0 | 0 | 3081 | 0.1 |
| `smoke_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 7623 | 6 | 0 | 150 | 68 | 0.1 |
| `rand_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 16884 | 121 | 1523 | 747 | 3254 | 0.1 |
| `b2b_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 7515 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 14895 | 69 | 1416 | 2904 | 1807 | 0.1 |
| `dbuf_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 15096 | 31 | 1557 | 213 | 154 | 0.1 |
| `errors_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 8043 | 104 | 184 | 0 | 71 | 0.1 |
| `fp_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 9723 | 41 | 0 | 0 | 22 | 0.1 |
| `long_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 29839 | 16 | 0 | 9448 | 3585 | 0.2 |
| `dma_fault_s1_fast_verilator_N2_OPSET0_OVL1_QD16` | PASS | 8564 | 50 | 177 | 0 | 482 | 0.1 |
| `smoke_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 7779 | 6 | 0 | 225 | 67 | 0.1 |
| `rand_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 20884 | 121 | 1524 | 1140 | 4672 | 0.2 |
| `b2b_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 7792 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 17585 | 69 | 1390 | 3738 | 2733 | 0.1 |
| `dbuf_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 18974 | 31 | 1489 | 399 | 162 | 0.1 |
| `errors_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 8399 | 104 | 202 | 0 | 92 | 0.1 |
| `fp_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 9823 | 41 | 0 | 0 | 23 | 0.1 |
| `long_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 39636 | 16 | 0 | 14322 | 3759 | 0.2 |
| `dma_fault_s1_rand_verilator_N2_OPSET0_OVL1_QD16` | PASS | 9222 | 50 | 183 | 0 | 723 | 0.1 |
| `smoke_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 7990 | 6 | 0 | 353 | 68 | 0.1 |
| `rand_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 27116 | 121 | 1476 | 1762 | 6927 | 0.2 |
| `b2b_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 9050 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 21632 | 69 | 1326 | 4868 | 4056 | 0.1 |
| `dbuf_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 24816 | 31 | 1437 | 713 | 154 | 0.2 |
| `errors_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 9211 | 104 | 160 | 0 | 129 | 0.1 |
| `fp_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 9732 | 41 | 0 | 0 | 22 | 0.1 |
| `long_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 53478 | 16 | 0 | 21007 | 3585 | 0.3 |
| `dma_fault_s1_bp_verilator_N2_OPSET0_OVL1_QD16` | PASS | 10548 | 50 | 189 | 0 | 1095 | 0.1 |
| `smoke_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 7623 | 6 | 0 | 0 | 369 | 0.1 |
| `rand_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 18335 | 121 | 0 | 0 | 10789 | 0.1 |
| `b2b_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 7515 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 16185 | 69 | 0 | 0 | 8522 | 0.1 |
| `dbuf_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 16491 | 31 | 0 | 0 | 9280 | 0.1 |
| `errors_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 8221 | 104 | 0 | 0 | 673 | 0.1 |
| `fp_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 9723 | 41 | 0 | 0 | 2454 | 0.1 |
| `long_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 29839 | 16 | 0 | 0 | 22481 | 0.2 |
| `dma_fault_s1_fast_verilator_N2_OPSET0_OVL0_QD16` | PASS | 8722 | 50 | 0 | 0 | 1460 | 0.1 |
| `smoke_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 7779 | 6 | 0 | 0 | 519 | 0.1 |
| `rand_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 22400 | 121 | 0 | 0 | 14804 | 0.2 |
| `b2b_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 7792 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 18957 | 69 | 0 | 0 | 11282 | 0.1 |
| `dbuf_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 20371 | 31 | 0 | 0 | 13157 | 0.1 |
| `errors_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 8627 | 104 | 0 | 0 | 905 | 0.1 |
| `fp_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 9823 | 41 | 0 | 0 | 2553 | 0.1 |
| `long_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 39636 | 16 | 0 | 0 | 32258 | 0.2 |
| `dma_fault_s1_rand_verilator_N2_OPSET0_OVL0_QD16` | PASS | 9389 | 50 | 0 | 0 | 2082 | 0.1 |
| `smoke_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 7990 | 6 | 0 | 0 | 715 | 0.1 |
| `rand_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 28444 | 121 | 0 | 0 | 20686 | 0.2 |
| `b2b_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 9050 | 200 | 0 | 0 | 0 | 0.1 |
| `deps_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 22760 | 69 | 0 | 0 | 15018 | 0.2 |
| `dbuf_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 26085 | 31 | 0 | 0 | 18868 | 0.2 |
| `errors_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 9364 | 104 | 0 | 0 | 1040 | 0.1 |
| `fp_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 9732 | 41 | 0 | 0 | 2454 | 0.1 |
| `long_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 53478 | 16 | 0 | 0 | 46058 | 0.3 |
| `dma_fault_s1_bp_verilator_N2_OPSET0_OVL0_QD16` | PASS | 10626 | 50 | 0 | 0 | 3081 | 0.1 |
