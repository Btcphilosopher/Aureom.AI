# Performance (RTL cycle counts)

Profile `fast`: external memory accepts every cycle with 1-cycle latency, the host takes every record at once, no lane holds.  Cycles are counted from the first command submission to the last completion record (testbench `prog_cycles`), so they include submission, decode, execution, commit and hand-over.  Every run is a passing self-checking test.

| measurement | result | cycles | per item | DMA/vector overlap cycles |
|---|---|---|---|---|
| NOP stream (256) | PASS | 261 | 1.02 cycles / command | 0 |
| FENCE stream (64), nothing in flight | PASS | 69 | 1.08 cycles / command | 0 |
| DMA_LOAD 64 B | PASS | 73 | 4.56 cycles / word | 0 |
| DMA_LOAD 1 KiB | PASS | 1033 | 4.04 cycles / word | 0 |
| DMA_LOAD 4 KiB | PASS | 4105 | 4.01 cycles / word | 0 |
| DMA_STORE 1 KiB | PASS | 1033 | 4.04 cycles / word | 0 |
| VECTOR_ADD 16, N=2 | PASS | 41 | 2.56 cycles / element | 0 |
| VECTOR_ADD 256, N=2 | PASS | 401 | 1.57 cycles / element | 0 |
| VECTOR_ADD 1024, N=2 | PASS | 1553 | 1.52 cycles / element | 0 |
| VECTOR_MUL 256, N=2 | PASS | 401 | 1.57 cycles / element | 0 |
| VECTOR_FMA 256, N=2 | PASS | 530 | 2.07 cycles / element | 0 |
| VECTOR_ADD 256, N=4 | PASS | 208 | 0.81 cycles / element | 0 |
| VECTOR_ADD 1024, N=4 | PASS | 784 | 0.77 cycles / element | 0 |
| VECTOR_FMA 256, N=4 | PASS | 274 | 1.07 cycles / element | 0 |
| independent DMA_LOAD 1 KiB + VECTOR_ADD 256, overlap on | PASS | 1034 | 1034.00 cycles / pair | 448 |
| independent DMA_LOAD 1 KiB + VECTOR_ADD 256, overlap off | PASS | 1429 | 1429.00 cycles / pair | 0 |
| dependent DMA_LOAD 1 KiB -> VECTOR_ADD 256, overlap on | PASS | 1429 | 1429.00 cycles / pair | 0 |
| double-buffer pipeline (10 tiles x 96), overlap on | PASS | 11646 | 1164.60 cycles / tile | 1854 |
| double-buffer pipeline (10 tiles x 96), overlap off | PASS | 13346 | 1334.60 cycles / tile | 0 |
