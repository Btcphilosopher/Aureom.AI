# Lint and elaboration checks

## Verilator 5.020 `--lint-only -Wall`

| top | parameters | errors | warnings in `rtl/` (new) | warnings in `third_party/` (reused) |
|---|---|---|---|---|
| `hpc_cq_tile` | defaults | 0 | 0 | 3 |
| `hpc_cq_tile` | QUEUE_DEPTH=4, NUM_LANES=1 | 0 | 0 | 3 |
| `hpc_cq_tile` | QUEUE_DEPTH=16, NUM_LANES=4, ROB_DEPTH=16 | 0 | 0 | 3 |
| `hpc_cq_tile` | NUM_LANES=8, ROB_DEPTH=2, OVERLAP_EN=0, OPSET_FULL=0 | 0 | 0 | 2 |
| `hpc_cq_tile` | NUM_LANES=16, WDOG_LOG2=0, PERF_EN=0 | 0 | 0 | 2 |
| `hpc_command_queue` | QUEUE_DEPTH=8 | 0 | 0 | 43 |
| `hpc_cq_mmio` | defaults | 0 | 0 | 43 |

## Icarus Verilog 12 elaboration

`hpc_cq_tile` + `hpc_cq_mmio`: exit 0, 0 errors (15 'sorry: constant selects in always_*' notes, all in sensitivity lists, also emitted for the reused DataFabric / Module 04 sources).

## Invalid parameter combinations (must fail elaboration)

| top | parameters | rejected | message |
|---|---|---|---|
| `hpc_command_queue` | QUEUE_DEPTH=5 | yes | `hpc_param_error_QUEUE_DEPTH_must_be_4_8_or_16` |
| `hpc_command_queue` | QUEUE_DEPTH=2 | yes | `hpc_param_error_QUEUE_DEPTH_must_be_4_8_or_16` |
| `hpc_command_queue` | QUEUE_DEPTH=32 | yes | `hpc_param_error_QUEUE_DEPTH_must_be_4_8_or_16` |
| `hpc_command_queue` | ROB_DEPTH=1 | yes | `hpc_param_error_ROB_DEPTH_must_be_2_to_64` |
| `hpc_command_queue` | EXT_BASE=32'h10001000 | yes | `hpc_param_error_window_base_not_aligned_to_size` |
| `hpc_command_queue` | SPM_BASE=32'h10010000 | yes | `hpc_param_error_EXT_and_SPM_windows_overlap` |
| `hpc_command_queue` | SPM_LOG2=2 | yes | `hpc_param_error_window_LOG2_must_be_3_to_31` |
| `hpc_command_queue` | WDOG_LOG2=40 | yes | `hpc_param_error_WDOG_LOG2_must_be_0_to_31` |
| `hpc_command_queue` | VL_W=29 | yes | `hpc_param_error_DMA_MAX_LEN_LOG2_or_VL_W_out_of_range` |
| `hpc_cq_tile` | SPM_PHYS_LOG2=17 | yes | `hpc_param_error_SPM_PHYS_LOG2_above_SPM_LOG2` |
| `hpc_cq_tile` | NUM_LANES=3 | yes | `hpc_param_error_NUM_LANES_must_be` |
| `hpc_cq_vexec` | N=3 | yes | `hpc_param_error_VEXEC_N_must_be_1_2_4_8_or_16` |
| `hpc_cq_vexec` | TAG_W=1 | yes | `hpc_param_error_VEXEC_TAG_W_below_2` |

**Result: PASS**
