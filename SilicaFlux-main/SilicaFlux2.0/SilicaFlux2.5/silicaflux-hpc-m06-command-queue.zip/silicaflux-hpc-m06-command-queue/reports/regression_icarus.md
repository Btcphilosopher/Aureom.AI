# Regression `icarus`

**32 / 32 runs pass** (108 s wall clock, 2264 commands).

| recipe | simulator | runs | pass | commands | overlap cycles | timing-dependent records |
|---|---|---|---|---|---|---|
| b2b | icarus | 2 | 2 | 400 | 0 | 0 |
| dbuf | icarus | 2 | 2 | 82 | 3694 | 0 |
| deps | icarus | 3 | 3 | 255 | 4566 | 0 |
| dma_fault | icarus | 2 | 2 | 140 | 661 | 0 |
| errors | icarus | 3 | 3 | 322 | 602 | 0 |
| fp | icarus | 2 | 2 | 82 | 0 | 0 |
| long | icarus | 2 | 2 | 40 | 0 | 0 |
| rand | icarus | 5 | 5 | 605 | 7375 | 0 |
| rstcnt | icarus | 2 | 2 | 166 | 3383 | 0 |
| smoke | icarus | 3 | 3 | 18 | 0 | 0 |
| spm_fault | icarus | 2 | 2 | 112 | 283 | 0 |
| timeout_dma | icarus | 2 | 2 | 22 | 102 | 0 |
| timeout_vec | icarus | 2 | 2 | 20 | 59 | 0 |

## All runs

| run | result | cycles | cmds | overlap | hazard stalls | sync stalls | s |
|---|---|---|---|---|---|---|---|
| `smoke_s1_fast_icarus_QD4` | PASS | 7623 | 6 | 0 | 150 | 68 | 8.2 |
| `smoke_s1_rand_icarus_QD4` | PASS | 7776 | 6 | 0 | 220 | 70 | 8.5 |
| `rand_s1_fast_icarus_QD4` | PASS | 9293 | 121 | 1971 | 261 | 941 | 14.9 |
| `rand_s1_rand_icarus_QD4` | PASS | 10267 | 121 | 2043 | 414 | 1362 | 17.4 |
| `b2b_s1_fast_icarus_QD4` | PASS | 7515 | 200 | 0 | 0 | 0 | 8.8 |
| `b2b_s1_rand_icarus_QD4` | PASS | 7765 | 200 | 0 | 0 | 0 | 8.6 |
| `deps_s1_fast_icarus_QD4` | PASS | 18501 | 93 | 1596 | 3168 | 376 | 15.9 |
| `deps_s1_rand_icarus_QD4` | PASS | 22801 | 93 | 1590 | 4021 | 495 | 17.7 |
| `dbuf_s1_fast_icarus_QD4` | PASS | 18821 | 41 | 1854 | 0 | 387 | 14.9 |
| `dbuf_s1_rand_icarus_QD4` | PASS | 24647 | 41 | 1840 | 0 | 602 | 17.8 |
| `errors_s1_fast_icarus_QD4` | PASS | 8023 | 109 | 191 | 0 | 31 | 8.4 |
| `errors_s1_rand_icarus_QD4` | PASS | 8382 | 109 | 207 | 0 | 30 | 8.5 |
| `fp_s1_fast_icarus_QD4` | PASS | 9974 | 41 | 0 | 0 | 22 | 10.3 |
| `fp_s1_rand_icarus_QD4` | PASS | 10110 | 41 | 0 | 0 | 22 | 10.8 |
| `long_s1_fast_icarus_QD4` | PASS | 41928 | 20 | 0 | 14654 | 9956 | 25.6 |
| `long_s1_rand_icarus_QD4` | PASS | 57414 | 20 | 0 | 20099 | 15037 | 34.5 |
| `dma_fault_s1_fast_icarus_QD4` | PASS | 8311 | 70 | 317 | 0 | 108 | 8.5 |
| `dma_fault_s1_rand_icarus_QD4` | PASS | 8850 | 70 | 344 | 0 | 109 | 9.2 |
| `rstcnt_s1_fast_icarus_QD4` | PASS | 8512 | 83 | 1655 | 0 | 520 | 12.2 |
| `rstcnt_s1_rand_icarus_QD4` | PASS | 9055 | 83 | 1728 | 0 | 798 | 14.0 |
| `spm_fault_s1_fast_icarus_PHYS15_QD8` | PASS | 7138 | 56 | 141 | 209 | 112 | 7.5 |
| `spm_fault_s1_rand_icarus_PHYS15_QD8` | PASS | 7396 | 56 | 142 | 340 | 165 | 7.7 |
| `timeout_dma_s1_fast_icarus_QD8_WDOG10` | PASS | 8223 | 11 | 51 | 0 | 0 | 7.9 |
| `timeout_dma_s1_rand_icarus_QD8_WDOG10` | PASS | 8257 | 11 | 51 | 0 | 0 | 8.6 |
| `timeout_vec_s1_fast_icarus_QD8_WDOG10` | PASS | 8100 | 10 | 29 | 0 | 38 | 8.2 |
| `timeout_vec_s1_rand_icarus_QD8_WDOG10` | PASS | 8138 | 10 | 30 | 0 | 63 | 8.3 |
| `rand_s7_bp_icarus_OVL0_QD16` | PASS | 20633 | 121 | 0 | 0 | 13258 | 19.8 |
| `rand_s3_rand_icarus_QD8_reset` | PASS | 9664 | 121 | 1834 | 0 | 1713 | 26.8 |
| `smoke_s1_rand_icarus_OPSET0_QD8` | PASS | 7776 | 6 | 0 | 220 | 70 | 9.0 |
| `rand_s1_rand_icarus_OPSET0_QD8` | PASS | 20994 | 121 | 1527 | 1172 | 4733 | 17.1 |
| `deps_s1_rand_icarus_OPSET0_QD8` | PASS | 17639 | 69 | 1380 | 3720 | 2722 | 15.8 |
| `errors_s1_rand_icarus_OPSET0_QD8` | PASS | 8401 | 104 | 204 | 0 | 88 | 8.8 |
