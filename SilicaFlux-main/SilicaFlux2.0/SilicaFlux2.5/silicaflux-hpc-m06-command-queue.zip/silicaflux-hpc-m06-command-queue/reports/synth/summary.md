# Synthesis summary (Yosys 0.33)

Generic: `synth -flatten` (technology-independent gates).  ECP5: `synth_ecp5` (Lattice LFE5U, the SilicaFlux FPGA prototype family).  Every job passes `check -assert` and contains no latch.  No timing or area in silicon is claimed.

| design | cells | flip-flops | LUT4 | CCU2C | MULT18 | RAM | Yosys s |
|---|---|---|---|---|---|---|---|
| `cq_qd16` | 21429 | 5587 |  |  |  |  | 16 |
| `cq_qd4` | 16660 | 3265 |  |  |  |  | 14 |
| `cq_qd8_noperf` | 15656 | 3496 |  |  |  |  | 12 |
| `cq_qd8_rob16` | 21853 | 5063 |  |  |  |  | 17 |
| `cq_qd8_rob4` | 16404 | 3525 |  |  |  |  | 14 |
| `cq_qd8_stage1` | 18298 | 4040 |  |  |  |  | 16 |
| `cq_qd8` | 18293 | 4040 |  |  |  |  | 15 |
| `ecp5_cq_qd16` | 7753 | 2115 | 3871 | 1249 |  | 61 | 16 |
| `ecp5_cq_qd4` | 7628 | 2109 | 3811 | 1246 |  | 61 | 16 |
| `ecp5_cq_qd8` | 7813 | 2112 | 3904 | 1246 |  | 61 | 16 |
| `ecp5_mmio` | 3322 | 293 | 1989 | 55 |  |  | 5 |
| `ecp5_vexec_n2` | 2988 | 709 | 1740 | 291 |  | 64 | 4 |
| `mmio` | 2171 | 293 |  |  |  |  | 4 |
| `tile_n2` | 1199659 | 533129 |  |  |  |  | 1662 |
| `vexec_n2` | 6625 | 1726 |  |  |  |  | 4 |
| `vexec_n4` | 12148 | 3183 |  |  |  |  | 7 |

Notes:

* `tile_n2` is the whole tile (queue + DMA engine + crossbar + 64 KiB scratchpad + executor + 2-lane FP32 array).  Generic `synth` has no memory library, so the scratchpad's 524,288 array bits become flip-flops; that, not the control plane, is where its flip-flop count comes from.  The scratchpad's real FPGA block-RAM / ASIC-macro mapping is Module 04's (`BACKEND = FPGA | ASIC`, its `reports/synth.md`); the array's FPGA results are Module 03's.
* ECP5 `RAM` = `TRELLIS_DPR16X4` distributed RAM: Yosys maps the command FIFO and the operand / write-back queues to it, which is why the ECP5 flip-flop counts are below the generic ones and QUEUE_DEPTH 4 / 8 / 16 cost almost the same (one 16-deep LUT RAM column either way).
* The generic queue flip-flop count is dominated by storage: FIFO entries (193 bits each), retirement records (128 bits each), the decode slot, 17 x 32-bit counters and the two job footprints.

## Structural check

```
QUEUE_DEPTH=4  inputs combinationally reaching the registered interface outputs: 0  | positive control (FIFO push <- cmd_valid_i): 1
QUEUE_DEPTH=8  inputs combinationally reaching the registered interface outputs: 0  | positive control (FIFO push <- cmd_valid_i): 1
QUEUE_DEPTH=16  inputs combinationally reaching the registered interface outputs: 0  | positive control (FIFO push <- cmd_valid_i): 1
```
