# Stimulus coverage

59 generated programs, 4813 commands; every record was compared with the reference model (26 records with a timing-dependent alternative).

## Opcode x status

| opcode | OK | ERROR | SKIPPED |
|---|---|---|---|
| NOP | 734 | 34 | 30 |
| DMA_LOAD | 1091 | 127 | 10 |
| DMA_STORE | 485 | 28 | 18 |
| VECTOR_ADD | 693 | 72 | 43 |
| VECTOR_MUL | 295 | 8 | 12 |
| VECTOR_FMA | 362 | 7 | 11 |
| FENCE | 504 | 12 | 50 |
| RESET_COUNTERS | 41 | 8 | 0 |
| reserved | 0 | 138 | 0 |

## Error codes in expected records

| code | records |
|---|---|
| `ERR_NONE` (0x00) | 4205 |
| `ERR_VERSION` (0x01) | 12 |
| `ERR_OPCODE` (0x02) | 146 |
| `ERR_FLAGS` (0x03) | 18 |
| `ERR_RSVD` (0x04) | 44 |
| `ERR_STRIDE` (0x05) | 8 |
| `ERR_RM` (0x06) | 12 |
| `ERR_LENGTH` (0x07) | 16 |
| `ERR_ALIGN` (0x08) | 22 |
| `ERR_RANGE` (0x09) | 46 |
| `ERR_OVERLAP` (0x0A) | 10 |
| `ERR_DMA_READ` (0x18) | 48 |
| `ERR_DMA_WRITE` (0x19) | 24 |
| `ERR_DMA_ABORTED` (0x1A) | 0 |
| `ERR_VEC_READ` (0x21) | 10 |
| `ERR_VEC_WRITE` (0x22) | 8 |
| `ERR_VEC_ENGINE` (0x23) | 0 |
| `ERR_TIMEOUT` (0x30) | 4 |
| `ERR_UNIT_DOWN` (0x31) | 6 |
| `ERR_PRIOR` (0x40) | 174 |

Never expected, by construction: `ERR_DMA_ABORTED` (an aborted job has already completed with TIMEOUT, its late outcome is ignored).  **Not exercised:** `ERR_VEC_ENGINE` -- the reused Module 03 array never returns an illegal or short completion record, and no fault can be injected into it without modifying it, so this guard is untested (docs/07 sec. 3).

## Executed commands: flags, rounding modes, tails, lengths, aliasing

| item | count |
|---|---|
| DMA_LOAD with FL_BARRIER | 75 |
| DMA_LOAD with FL_IRQ | 100 |
| DMA_STORE with FL_BARRIER | 37 |
| DMA_STORE with FL_IRQ | 48 |
| FENCE with FL_BARRIER | 9 |
| FENCE with FL_IRQ | 26 |
| NOP with FL_BARRIER | 268 |
| NOP with FL_IRQ | 309 |
| RESET_COUNTERS with FL_IRQ | 4 |
| VECTOR_ADD with FL_BARRIER | 38 |
| VECTOR_ADD with FL_IRQ | 78 |
| VECTOR_FMA with FL_BARRIER | 33 |
| VECTOR_FMA with FL_IRQ | 39 |
| VECTOR_MUL with FL_BARRIER | 11 |
| VECTOR_MUL with FL_IRQ | 48 |
| VECTOR_ADD RM=RNE | 210 |
| VECTOR_ADD RM=RTZ | 134 |
| VECTOR_ADD RM=RDN | 131 |
| VECTOR_ADD RM=RUP | 98 |
| VECTOR_ADD RM=RMM | 120 |
| VECTOR_FMA RM=RNE | 94 |
| VECTOR_FMA RM=RTZ | 61 |
| VECTOR_FMA RM=RDN | 59 |
| VECTOR_FMA RM=RUP | 74 |
| VECTOR_FMA RM=RMM | 74 |
| VECTOR_MUL RM=RNE | 63 |
| VECTOR_MUL RM=RTZ | 59 |
| VECTOR_MUL RM=RDN | 54 |
| VECTOR_MUL RM=RUP | 57 |
| VECTOR_MUL RM=RMM | 62 |
| DMA_LOAD LENGTH mod 4 = 0 | 451 |
| DMA_LOAD LENGTH mod 4 = 1 | 214 |
| DMA_LOAD LENGTH mod 4 = 2 | 238 |
| DMA_LOAD LENGTH mod 4 = 3 | 188 |
| DMA_STORE LENGTH mod 4 = 0 | 157 |
| DMA_STORE LENGTH mod 4 = 1 | 126 |
| DMA_STORE LENGTH mod 4 = 2 | 130 |
| DMA_STORE LENGTH mod 4 = 3 | 72 |
| vector LENGTH 1 | 29 |
| vector LENGTH 16..255 | 959 |
| vector LENGTH 2..15 | 346 |
| vector LENGTH >=256 | 16 |
| vector LENGTH vl mod 4 = 0 | 483 |
| vector LENGTH vl mod 4 = 1 | 280 |
| vector LENGTH vl mod 4 = 2 | 279 |
| vector LENGTH vl mod 4 = 3 | 308 |
| vector A == B | 39 |
| vector D == A | 239 |
| vector D == B | 114 |
| vector D disjoint | 997 |
