# SilicaFlux-HPC · Module 06 — Hardware Command Queue and Compute Scheduler

**Primary source:** `rtl/hpc_command_queue.sv` · Aureom.AI | SilicaFlux-HPC

A synthesizable command queue and in-order compute scheduler for the SilicaFlux-HPC compute tile.

* **Accept.** Versioned 256-bit command descriptors arrive on a ready/valid port into a configurable-depth FIFO
  (4 / 8 / 16).
* **Validate.** Each descriptor is checked against the ABI before anything happens.
* **Issue.** DMA work goes to the DataFabric DMA engine, vector work to the Module 03 vector array (through a new
  scratchpad-to-array executor). Issue is strictly in order.
* **Dependencies.** A DMA job and a vector job overlap only when their byte footprints have no RAW / WAR / WAW
  conflict.
* **Completion.** The scheduler waits for genuine completion: every write acknowledged.
* **Records.** Exactly one 128-bit completion record per command, strictly in order.

FENCE, a per-command BARRIER flag, RESET_COUNTERS, a full error taxonomy with stop / continue policies, a
no-progress watchdog, an MMIO register adapter, a C driver and a host example that runs on the RTL complete it.

Built as the brief asks:
1. Stage 1: **NOP, DMA_LOAD, VECTOR_ADD and FENCE** were brought up first (`OPSET_FULL = 0`) until end-to-end
   ordering was correct across every depth, overlap mode and timing profile.
2. Stage 2: only then was the set expanded to DMA_STORE, VECTOR_MUL, VECTOR_FMA and RESET_COUNTERS, plus errors,
   faults, the watchdog and reset.

## Results (final campaign on the frozen RTL; `reports/SUMMARY.md`)

| Check | Result |
|---|---|
| **Stage 1** — NOP / DMA_LOAD / VECTOR_ADD / FENCE only; QUEUE_DEPTH 4 / 8 / 16 × overlap on / off × 3 timing profiles × 9 recipes | **162 / 162** runs, 11,484 commands; every record and every memory word equal to the sequential reference |
| **Stage 2** — full v1 opcode set; 8 queue / ROB / lane / overlap configurations × 4 timing profiles; errors, bus faults, watchdog, reset during activity, minimum-depth executor queues | **460 / 460** runs, 34,782 commands, 284,899 cycles with a DMA and a vector job overlapping |
| Icarus 12 4-state cross-simulation | **32 / 32** runs |
| C host example (`sw/examples/cq_submit_demo.c`) on the RTL through the MMIO adapter | **PASS**: results bit-exact, records in order, error → skip → clear (`reports/cosim.log`) |
| MMIO adapter directed test (refusals, W1C, IRQ, ordering) | **PASS** |
| Mutation testing (37 injected design bugs) | **36 detected**, 1 proven equivalent, **0 undetected** |
| ABI consistency RTL ↔ C ↔ Python ↔ reused encodings | **117 / 117** items agree |
| Lint | Verilator `-Wall`: 0 warnings in new RTL (7 parameter sets); Icarus clean; 13 / 13 invalid parameter combinations rejected |
| Synthesis (Yosys 0.33) | no latches, `check -assert`; queue QD 4 / 8 / 16: 16.7 k / 18.3 k / 21.4 k generic cells; ECP5 ≈ 3.8–3.9 k LUT4, 2.1 k FF, 61 LUT-RAMs |
| Structural proof | no input reaches any handshake / control / status output of `hpc_command_queue` combinationally (QD 4 / 8 / 16) |
| Performance (RTL cycles, `reports/perf.md`) | one command per cycle; NOP record 4 cycles after acceptance; DMA 4.0 cycles / word; VECTOR_ADD N / 3 elements per cycle (0.66 at N = 2, 1.31 at N = 4); independent DMA + vector job overlap −28 %; dependent pair correctly serialised |

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Audit; reuse conventions; no second incompatible protocol | `docs/00_AUDIT.md`. No HPC command processor existed. Reused **unmodified**: DataFabric DMA engine + validator, SFB2 crossbar + protocol checker, Module 04 scratchpad, Module 03 array + FIFO, Module 02 encodings + FP reference (`third_party/`, SHA-256, `PROVENANCE.md`). DMA units, alignment, error codes, the register-bus contract and the driver style are all DataFabric's. |
| 2 | Versioned descriptor: opcode, src A / B, dst, length, stride, tid, flags, rounding mode; widths, units, alignment; NOP DMA_LOAD DMA_STORE VECTOR_ADD/MUL/FMA FENCE RESET_COUNTERS; reserved opcodes | `docs/01_COMMAND_ABI.md`, `rtl/hpc_cq_pkg.sv`, `sw/hpc_cq_abi.h`, `ref/hpc_cq_abi.py`. Three halves proved identical by `scripts/check_abi.py`. |
| 3 | FIFO 4 / 8 / 16; ready/valid; accept only on handshake; full / empty / dequeue / in-flight / completion / error responses; no overwrite | `rtl/hpc_command_queue.sv`, `rtl/hpc_cq_rob.sv`, `docs/02_ARCHITECTURE.md` §2–3 |
| 4 | Decode, validate, resources, issue, track, dependencies, genuine completion, completion record; in-order retirement; overlap only where safe; no speculation | `rtl/hpc_cq_sched.sv` (FSM + decision table), `rtl/hpc_cq_validate.sv`, `rtl/hpc_cq_vexec.sv`, docs/02 §3–4 |
| 5 | FENCE; what it waits for (DMA reads, DMA writes, vector results, scratchpad commits); semantics match the hardware | `docs/03_SYNCHRONISATION.md` |
| 6 | Invalid opcode / length / range / misalignment / resource failure / DMA error / unsupported flags; never execute malformed commands | `docs/04_ERRORS.md`; validation before issue; watchdog + quarantine |
| 7 | Clean host interface; stream and MMIO, one an adapter of the other; host example | stream = native; `rtl/hpc_cq_mmio.sv` = adapter; `sw/hpc_cq.{c,h}`, `sw/examples/cq_submit_demo.c` (runs on the RTL: `make cosim`); `docs/05_HOST_INTERFACE.md` |
| 8 | Overflow, underflow, back-to-back, mixed DMA / compute, FENCE, invalid commands, completion ordering, reset during activity, back-pressure, dependencies, error propagation; assertions; reference scoreboard | `docs/06_VERIFICATION.md`: model-based TB, scoreboard, independent monitors, SVA, mutation |
| 9 | `hpc_command_queue.sv`, descriptor package, scheduler FSM, unit tests, ABI doc, host example | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `hpc_command_queue.sv` | `rtl/hpc_command_queue.sv`: FIFO + scheduler + retirement + counters |
| Command descriptor package | `rtl/hpc_cq_pkg.sv` (+ `sw/hpc_cq_abi.h`, `ref/hpc_cq_abi.py`) |
| Scheduler FSM | `rtl/hpc_cq_sched.sv`, `rtl/hpc_cq_validate.sv`, `rtl/hpc_cq_rob.sv` |
| Execution integration | `rtl/hpc_cq_vexec.sv` (vector executor), `rtl/hpc_cq_tile.sv` (tile wiring), `rtl/hpc_cq_perf.sv` |
| Host interface | `rtl/hpc_cq_mmio.sv` (register adapter), `sw/hpc_cq.{c,h}` (driver) |
| Unit tests | `tb/tb_hpc_command_queue.sv` (model-based, all recipes), `tb/tb_hpc_cq_mmio.sv`, `tb/tb_smoke.sv`, `tb/tb_latency.sv`, `tb/hpc_cq_sva.sv`, `tb/tb_ext_mem.sv`, `tb/cosim/`; reference model and generator `ref/`; scripts `scripts/` |
| Command ABI documentation | `docs/01_COMMAND_ABI.md` |
| Host submission example | `sw/examples/cq_submit_demo.c` (co-simulated on the RTL, output in docs/05 §3) |
| Other documentation | `docs/00` audit, `02` architecture / FSM, `03` FENCE, `04` errors, `05` host interface, `06` verification, `07` performance / integration / limitations; `reports/` |

## Interface at a glance

```
hpc_command_queue #(QUEUE_DEPTH=8 (4|8|16), ROB_DEPTH=8, OPSET_FULL=1, OVERLAP_EN=1,
                    EXT_BASE=0x1000_0000, EXT_LOG2=17, SPM_BASE=0x2000_0000, SPM_LOG2=16,
                    DMA_MAX_LEN_LOG2=24, VL_W=16, WDOG_LOG2=16, PERF_EN=1, PERF_CW=32)
  clk_i, rst_ni
  cmd  : cmd_valid_i / cmd_ready_o   cmd_desc_i[255:0]                    (ABI v1 descriptor)
  cpl  : cpl_valid_o / cpl_ready_i   cpl_rec_o[127:0]                     (tid op err status irq fflags | count | err_addr | seq)
  ctrl : ctrl_err_cont_i  ctrl_err_clear_i  ctrl_perf_clear_i
  DMA  : dma_start_o dma_abort_o dma_src_o dma_dst_o dma_len_o  <-  dma_busy/done/fail/err_code/err_addr/bytes_done/progress
         (= DataFabric dma_transfer_engine control contract)
  VEC  : vec_start_o vec_op_o vec_rm_o vec_src_a/b_o vec_dst_o vec_vl_o vec_tid_o  <-  vec_busy/done/fail/err_code/err_addr/fflags/count/progress
  status: busy_o q_count_o q_full_o q_empty_o rob_count_o err_sticky_o dma_down_o vec_down_o
  events: ev_commit_o ev_commit_err_o ev_commit_irq_o     counters: perf_cnt_o[17*32]     trace: trc_*
```

| Opcode | | Opcode | |
|---|---|---|---|
| `0x00` NOP | | `0x10` VECTOR_ADD `D = A + B` | |
| `0x01` DMA_LOAD EXT → SPM | | `0x11` VECTOR_MUL `D = A × B` | |
| `0x02` DMA_STORE SPM → EXT | | `0x12` VECTOR_FMA `D = A × B + D` | |
| `0x20` FENCE | | `0x30` RESET_COUNTERS | everything else: reserved → `ERR_OPCODE` |

## Quick start

```bash
make abi          # RTL / C / Python ABI agree
make lint         # Verilator -Wall, Icarus, invalid parameters rejected
make smoke        # one stage-1 and one stage-2 run
make stage1       # bring-up regression (NOP / DMA_LOAD / VECTOR_ADD / FENCE)
make stage2       # full regression
make cosim        # the C host example on the RTL
make perf latency synth mutation
make all          # everything + reports/SUMMARY.md (several hours on 4 cores)
python3 scripts/regress.py one deps --cfg QD=4,OVL=1 --prof bp --seed 7
```

Tools: Verilator 5.020, Icarus Verilog 12, Yosys 0.33 (the SilicaFlux baseline, Ubuntu 24.04 packages), Python ≥ 3.10
(standard library only), gcc. The directory is self-contained; reused sources are in `third_party/`.

## Files

```
rtl/        hpc_command_queue.sv  hpc_cq_pkg.sv  hpc_cq_sched.sv  hpc_cq_validate.sv  hpc_cq_rob.sv  hpc_cq_perf.sv
            hpc_cq_vexec.sv  hpc_cq_tile.sv  hpc_cq_mmio.sv  files.f  files_sim_stubs.f
tb/         tb_hpc_command_queue.sv  hpc_cq_sva.sv  tb_ext_mem.sv  tb_hpc_cq_mmio.sv  tb_smoke.sv  tb_latency.sv
            cosim/cosim_top.sv  cosim/cosim_main.cpp
ref/        hpc_cq_abi.py  hpc_cq_model.py  gen_prog.py
sw/         hpc_cq_abi.h  hpc_cq.h  hpc_cq.c  examples/cq_submit_demo.c
scripts/    regress.py  run_all.sh  check_abi.py  lint.py  perf.py  mutate.py  coverage.py  make_report.py  synth_summary.py
syn/        run_synth.sh
docs/       00_AUDIT  01_COMMAND_ABI  02_ARCHITECTURE  03_SYNCHRONISATION  04_ERRORS  05_HOST_INTERFACE
            06_VERIFICATION  07_INTEGRATION_AND_LIMITATIONS
reports/    SUMMARY  regression_{stage1,stage2,icarus}  abi_check  lint  perf  latency  coverage  mutation  synth/
            cosim.log  mmio.log  run_all.log (generated)
third_party/ silicaflux-hpc-m02/m03/m04, silicaflux-datafabric subsets (unmodified)  SHA256SUMS  PROVENANCE.md
Makefile
```

## What is not claimed

* No clock frequency, silicon area or power.
* No formal proof, no gate-level simulation, no hardware run.
* Synthesis evidence is Yosys generic and ECP5 mapping only.
* `ERR_VEC_ENGINE` is an untested guard.

See `docs/07` §3 for the full list of limitations.
