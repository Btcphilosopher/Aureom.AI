// =============================================================================
// SilicaFlux-HPC :: hpc_cq_sched -- compute scheduler (in-order issue,
// out-of-order completion, in-order commit)
//
//   command FIFO head --pop--> DEC (decode slot, one command)
//                               | 1 decode + 2 validate (hpc_cq_validate)
//                               | 3 resources: ROB slot, unit free, unit alive
//                               | 4 issue -> DMA engine | vector executor
//                               |   or resolve at decode (NOP, FENCE, ...)
//                               v
//                        hpc_cq_rob: 5 track, 7 wait for genuine completion,
//                                    8 commit in order -> completion record
//   6 memory dependencies: a DMA job and a vector job may run concurrently
//     only when their byte footprints have no RAW / WAR / WAW conflict.
//
// Decode-slot decision, evaluated every cycle the slot is full (priority
// order; exactly one outcome):
//
//   ROB full                          -> stall (STALL_ROB)
//   sticky error && stop mode         -> resolve SKIPPED / ERR_PRIOR
//   validation error                  -> resolve ERROR / validation code
//   DMA/vector op, unit quarantined   -> resolve ERROR / ERR_UNIT_DOWN
//   sync needed && a job in flight    -> stall (STALL_SYNC)
//        sync = FENCE | RESET_COUNTERS | FL_BARRIER | (OVERLAP_EN = 0 and
//               the op is a DMA / vector op); RESET_COUNTERS also waits
//               until every older command has committed
//   NOP, FENCE                        -> resolve OK
//   RESET_COUNTERS                    -> resolve OK, clear the counters
//   DMA op: engine busy               -> stall (STALL_UNIT)
//           conflicts with vector job -> stall (STALL_HAZARD)
//           else                      -> issue on the DMA engine
//   vector op: executor busy          -> stall (STALL_UNIT)
//              conflicts with DMA job -> stall (STALL_HAZARD)
//              else                   -> issue on the vector executor
//
// Every decode-slot outcome other than a stall allocates one ROB entry.
// Issue is strictly in program order (the slot never lets a younger command
// pass); there is no speculation.  Because each unit runs one job at a time
// and a job completes only after all of its writes are acknowledged, the
// only concurrency is one DMA job alongside one vector job, and only when
// independent.
//
// Unit contract (both ports, identical; the DMA side is DataFabric
// dma_transfer_engine's control interface, unmodified): start is a one-cycle
// registered pulse sampled while the unit is idle; done / fail are one-cycle
// pulses after which the unit is idle again.
//
// Errors.  Stop mode (err_cont_i = 0, default): the first ERROR record makes
// the scheduler sticky; every command that has not been issued yet is then
// retired SKIPPED (one record each, nothing executed) until err_clear_i.
// Commands already issued when an execution error is detected run to
// completion: they are independent of the failing job by construction.
// Continue mode (err_cont_i = 1): errors are reported per command only.
//
// Watchdog (WDOG_LOG2 > 0): a unit job that shows no progress (no bus or
// stream handshake) for 2^WDOG_LOG2 - 1 consecutive cycles is completed with
// ERR_TIMEOUT and the unit is quarantined until reset: later commands for it
// complete with ERR_UNIT_DOWN, and its late done/fail pulses are ignored.
// A DMA timeout also pulses dma_abort_o.
// =============================================================================
`default_nettype none

module hpc_cq_sched #(
  parameter int          ROB_DEPTH        = 8,
  parameter bit          OPSET_FULL       = 1'b1,
  parameter bit          OVERLAP_EN       = 1'b1,
  parameter logic [31:0] EXT_BASE         = 32'h1000_0000,
  parameter int          EXT_LOG2         = 17,
  parameter logic [31:0] SPM_BASE         = 32'h2000_0000,
  parameter int          SPM_LOG2         = 16,
  parameter int          DMA_MAX_LEN_LOG2 = 24,
  parameter int          VL_W             = 16,
  parameter int          WDOG_LOG2        = 16,
  localparam int         IW               = (ROB_DEPTH > 1) ? $clog2(ROB_DEPTH) : 1,
  localparam int         RCW              = $clog2(ROB_DEPTH + 1),
  localparam int         WDW              = (WDOG_LOG2 > 0) ? WDOG_LOG2 : 1
) (
  input  wire logic                        clk_i,
  input  wire logic                        rst_ni,
  // ---------------------------------------------------------------- command FIFO head
  input  wire logic                        q_valid_i,
  input  wire logic [hpc_cq_pkg::QE_W-1:0] q_entry_i,
  output logic                             q_pop_o,
  // ---------------------------------------------------------------- control
  input  wire logic                        err_cont_i,
  input  wire logic                        err_clear_i,
  // ---------------------------------------------------------------- DMA engine
  output logic                             dma_start_o,
  output logic                             dma_abort_o,
  output logic [31:0]                      dma_src_o,
  output logic [31:0]                      dma_dst_o,
  output logic [31:0]                      dma_len_o,
  input  wire logic                        dma_busy_i,
  input  wire logic                        dma_done_i,
  input  wire logic                        dma_fail_i,
  input  wire logic [3:0]                  dma_err_code_i,
  input  wire logic [31:0]                 dma_err_addr_i,
  input  wire logic [31:0]                 dma_bytes_done_i,
  input  wire logic                        dma_progress_i,
  // ---------------------------------------------------------------- vector executor
  output logic                             vec_start_o,
  output logic [1:0]                       vec_op_o,
  output logic [2:0]                       vec_rm_o,
  output logic [31:0]                      vec_src_a_o,
  output logic [31:0]                      vec_src_b_o,
  output logic [31:0]                      vec_dst_o,
  output logic [VL_W-1:0]                  vec_vl_o,
  output logic [7:0]                       vec_tid_o,
  input  wire logic                        vec_busy_i,
  input  wire logic                        vec_done_i,
  input  wire logic                        vec_fail_i,
  input  wire logic [3:0]                  vec_err_code_i,
  input  wire logic [31:0]                 vec_err_addr_i,
  input  wire logic [4:0]                  vec_fflags_i,
  input  wire logic [31:0]                 vec_count_i,
  input  wire logic                        vec_progress_i,
  // ---------------------------------------------------------------- completion records
  output logic                             cpl_valid_o,
  input  wire logic                        cpl_ready_i,
  output logic [hpc_cq_pkg::REC_W-1:0]     cpl_rec_o,
  // ---------------------------------------------------------------- status
  output logic                             dec_valid_o,
  output logic [RCW-1:0]                   rob_count_o,
  output logic                             err_sticky_o,
  output logic                             dma_down_o,
  output logic                             vec_down_o,
  // ---------------------------------------------------------------- events
  output logic                             perf_clear_o,     // RESET_COUNTERS executed
  output logic                             ev_commit_o,
  output logic                             ev_commit_err_o,
  output logic                             ev_commit_skip_o,
  output logic                             ev_commit_irq_o,
  output logic                             ev_dma_issue_o,
  output logic                             ev_vec_issue_o,
  output logic                             ev_dma_active_o,
  output logic                             ev_vec_active_o,
  output logic                             ev_stall_hazard_o,
  output logic                             ev_stall_unit_o,
  output logic                             ev_stall_sync_o,
  output logic                             ev_stall_rob_o,
  // ---------------------------------------------------------------- trace (observability)
  output logic                             trc_resolve_o,    // decode slot left this cycle
  output logic [31:0]                      trc_seq_o,        // ... sequence number of that command
  output logic [31:0]                      trc_dma_seq_o,    // job on the DMA engine (valid: ev_dma_active_o)
  output logic [31:0]                      trc_vec_seq_o     // job on the vector executor
);
  // ================================================================ elaboration checks
  if (WDOG_LOG2 < 0 || WDOG_LOG2 > 31) begin : g_bad_wdog
    hpc_param_error_WDOG_LOG2_must_be_0_to_31 u_err ();
  end

  // ================================================================ decode slot
  logic                         dec_v_q;
  logic [hpc_cq_pkg::QE_W-1:0]  dec_q;
  logic [31:0]                  dec_seq_q, seq_q;

  /* verilator lint_off UNUSEDSIGNAL */  // VERSION / bit 15 are checked by hpc_cq_validate
  wire [31:0] d_w0  = dec_q[31:0];
  /* verilator lint_on UNUSEDSIGNAL */
  wire [31:0] d_sa  = dec_q[63:32];
  wire [31:0] d_sb  = dec_q[95:64];
  wire [31:0] d_da  = dec_q[127:96];
  wire [31:0] d_len = dec_q[159:128];
  wire [7:0]  d_op  = d_w0[7:0];
  wire [2:0]  d_rm  = d_w0[14:12];
  wire [7:0]  d_fl  = d_w0[23:16];
  wire [7:0]  d_tid = d_w0[31:24];

  logic [7:0]  v_err;
  logic [2:0]  v_cls;
  logic [32:0] f_rd_lo, f_rd_hi, f_rd2_lo, f_rd2_hi, f_wr_lo, f_wr_hi;

  hpc_cq_validate #(
    .OPSET_FULL(OPSET_FULL), .EXT_BASE(EXT_BASE), .EXT_LOG2(EXT_LOG2),
    .SPM_BASE(SPM_BASE), .SPM_LOG2(SPM_LOG2), .DMA_MAX_LEN_LOG2(DMA_MAX_LEN_LOG2), .VL_W(VL_W)
  ) u_val (
    .entry_i(dec_q), .err_o(v_err), .cls_o(v_cls),
    .rd_lo_o(f_rd_lo), .rd_hi_o(f_rd_hi), .rd2_lo_o(f_rd2_lo), .rd2_hi_o(f_rd2_hi),
    .wr_lo_o(f_wr_lo), .wr_hi_o(f_wr_hi)
  );

  // ================================================================ unit state
  logic        dma_act_q, dma_dead_q, dma_start_q, dma_abort_q;
  logic [IW-1:0] dma_idx_q;
  logic [31:0] dma_seq_q;
  logic [32:0] dr_lo_q, dr_hi_q, dw_lo_q, dw_hi_q;      // DMA job footprint
  logic [WDW-1:0] dma_wd_q;

  logic        vec_act_q, vec_dead_q, vec_start_q;
  logic [IW-1:0] vec_idx_q;
  logic [31:0] vec_seq_q;
  logic [32:0] va_lo_q, va_hi_q, vb_lo_q, vb_hi_q, vw_lo_q, vw_hi_q;  // vector job footprint
  logic [WDW-1:0] vec_wd_q;

  logic        sticky_q;

  // ================================================================ ROB
  logic          rob_alloc, rob_alloc_done, rob_full;
  logic [7:0]    rob_alloc_err;
  logic [1:0]    rob_alloc_st;
  logic [IW-1:0] rob_tail;
  logic [1:0]    rob_upd;
  logic [7:0]    upd0_err, upd1_err;
  logic [1:0]    upd0_st, upd1_st;
  logic [31:0]   upd0_cnt, upd1_cnt, upd0_ea, upd1_ea;
  logic [4:0]    upd1_ff;
  logic [RCW-1:0] rob_nal, rob_ncm;

  // ================================================================ decision
  wire skip      = sticky_q && !err_cont_i;
  wire is_dma    = (v_cls == hpc_cq_pkg::CL_DMA);
  wire is_vec    = (v_cls == hpc_cq_pkg::CL_VEC);
  wire need_sync = (v_cls == hpc_cq_pkg::CL_FENCE) || (v_cls == hpc_cq_pkg::CL_RSTCNT) ||
                   d_fl[hpc_cq_pkg::FL_BARRIER] || (!OVERLAP_EN && (is_dma || is_vec));
  wire older     = dma_act_q || vec_act_q;      // pending ROB entries == jobs in flight
  // RESET_COUNTERS additionally waits until every older command has
  // COMMITTED, so no older commit event can land after the clear.
  wire is_rstcnt = (v_cls == hpc_cq_pkg::CL_RSTCNT);
  wire sync_busy = older || (is_rstcnt && (rob_nal != rob_ncm));

  // dependency checks against the job running on the OTHER unit
  //   DMA cmd vs vector job : RAW rd/vw, WAR wr/va, wr/vb, WAW wr/vw (FMA's read of D = vw)
  //   vector cmd vs DMA job : RAW rd/dw, rd2/dw, (FMA: wr/dw), WAR wr/dr, WAW wr/dw
  wire haz_dma = vec_act_q &&
                 (hpc_cq_pkg::isect(f_rd_lo, f_rd_hi, vw_lo_q, vw_hi_q) ||
                  hpc_cq_pkg::isect(f_wr_lo, f_wr_hi, va_lo_q, va_hi_q) ||
                  hpc_cq_pkg::isect(f_wr_lo, f_wr_hi, vb_lo_q, vb_hi_q) ||
                  hpc_cq_pkg::isect(f_wr_lo, f_wr_hi, vw_lo_q, vw_hi_q));
  wire haz_vec = dma_act_q &&
                 (hpc_cq_pkg::isect(f_rd_lo,  f_rd_hi,  dw_lo_q, dw_hi_q) ||
                  hpc_cq_pkg::isect(f_rd2_lo, f_rd2_hi, dw_lo_q, dw_hi_q) ||
                  hpc_cq_pkg::isect(f_wr_lo,  f_wr_hi,  dr_lo_q, dr_hi_q) ||
                  hpc_cq_pkg::isect(f_wr_lo,  f_wr_hi,  dw_lo_q, dw_hi_q));

  logic act_resolve, act_issue_dma, act_issue_vec, act_rstcnt, act_set_sticky;
  logic st_rob, st_sync, st_unit, st_haz;
  logic [7:0] res_err;
  logic [1:0] res_st;

  always_comb begin
    act_resolve = 1'b0;  act_issue_dma = 1'b0;  act_issue_vec = 1'b0;
    act_rstcnt  = 1'b0;  act_set_sticky = 1'b0;
    st_rob = 1'b0;  st_sync = 1'b0;  st_unit = 1'b0;  st_haz = 1'b0;
    res_err = hpc_cq_pkg::ERR_NONE;
    res_st  = hpc_cq_pkg::ST_OK;
    if (dec_v_q) begin
      if (rob_full) begin
        st_rob = 1'b1;
      end else if (skip) begin
        act_resolve = 1'b1;
        res_st  = hpc_cq_pkg::ST_SKIPPED;
        res_err = hpc_cq_pkg::ERR_PRIOR;
      end else if (v_err != hpc_cq_pkg::ERR_NONE) begin
        act_resolve    = 1'b1;
        act_set_sticky = 1'b1;
        res_st  = hpc_cq_pkg::ST_ERROR;
        res_err = v_err;
      end else if ((is_dma && dma_dead_q) || (is_vec && vec_dead_q)) begin
        act_resolve    = 1'b1;
        act_set_sticky = 1'b1;
        res_st  = hpc_cq_pkg::ST_ERROR;
        res_err = hpc_cq_pkg::ERR_UNIT_DOWN;
      end else if (need_sync && sync_busy) begin
        st_sync = 1'b1;
      end else if (is_dma) begin
        if (dma_act_q)    st_unit = 1'b1;
        else if (haz_dma) st_haz  = 1'b1;
        else              act_issue_dma = 1'b1;
      end else if (is_vec) begin
        if (vec_act_q)    st_unit = 1'b1;
        else if (haz_vec) st_haz  = 1'b1;
        else              act_issue_vec = 1'b1;
      end else begin
        // NOP, FENCE, RESET_COUNTERS: complete at decode
        act_resolve = 1'b1;
        act_rstcnt  = is_rstcnt;
      end
    end
  end

  wire dec_leave = act_resolve || act_issue_dma || act_issue_vec;
  assign q_pop_o = q_valid_i && (!dec_v_q || dec_leave);

  // ROB allocation
  assign rob_alloc      = dec_leave;
  assign rob_alloc_done = act_resolve;
  assign rob_alloc_err  = res_err;
  assign rob_alloc_st   = res_st;

  // ================================================================ unit completion
  localparam logic [WDW-1:0] WD_MAX = {WDW{1'b1}};
  wire wd_en   = (WDOG_LOG2 > 0);
  wire dma_fin = dma_act_q && (dma_done_i || dma_fail_i);
  wire vec_fin = vec_act_q && (vec_done_i || vec_fail_i);
  wire dma_to  = wd_en && dma_act_q && !dma_fin && !dma_progress_i && (dma_wd_q == WD_MAX);
  wire vec_to  = wd_en && vec_act_q && !vec_fin && !vec_progress_i && (vec_wd_q == WD_MAX);

  always_comb begin
    rob_upd  = {vec_fin || vec_to, dma_fin || dma_to};
    // port 0: DMA
    upd0_st  = (dma_to || dma_fail_i) ? hpc_cq_pkg::ST_ERROR : hpc_cq_pkg::ST_OK;
    upd0_err = dma_to     ? hpc_cq_pkg::ERR_TIMEOUT :
               dma_fail_i ? (hpc_cq_pkg::ERR_DMA_BASE | {4'h0, dma_err_code_i}) : hpc_cq_pkg::ERR_NONE;
    upd0_cnt = dma_bytes_done_i;
    upd0_ea  = (!dma_to && dma_fail_i) ? dma_err_addr_i : 32'd0;
    // port 1: vector
    upd1_st  = (vec_to || vec_fail_i) ? hpc_cq_pkg::ST_ERROR : hpc_cq_pkg::ST_OK;
    upd1_err = vec_to     ? hpc_cq_pkg::ERR_TIMEOUT :
               vec_fail_i ? (hpc_cq_pkg::ERR_VEC_BASE | {4'h0, vec_err_code_i}) : hpc_cq_pkg::ERR_NONE;
    upd1_cnt = vec_count_i;
    upd1_ea  = (!vec_to && vec_fail_i) ? vec_err_addr_i : 32'd0;
    upd1_ff  = vec_fflags_i;
  end

  wire unit_err = (dma_fin && dma_fail_i) || dma_to || (vec_fin && vec_fail_i) || vec_to;

  // ================================================================ sequential state
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      dec_v_q     <= 1'b0;
      dec_seq_q   <= 32'd0;
      seq_q       <= 32'd0;
      sticky_q    <= 1'b0;
      dma_act_q   <= 1'b0;
      dma_dead_q  <= 1'b0;
      dma_start_q <= 1'b0;
      dma_abort_q <= 1'b0;
      dma_idx_q   <= '0;
      dma_seq_q   <= 32'd0;
      dma_wd_q    <= '0;
      vec_act_q   <= 1'b0;
      vec_dead_q  <= 1'b0;
      vec_start_q <= 1'b0;
      vec_idx_q   <= '0;
      vec_seq_q   <= 32'd0;
      vec_wd_q    <= '0;
    end else begin
      // decode slot
      if (q_pop_o) begin
        dec_v_q   <= 1'b1;
        dec_seq_q <= seq_q;
        seq_q     <= seq_q + 32'd1;
      end else if (dec_leave) begin
        dec_v_q   <= 1'b0;
      end

      // sticky error (set wins over a same-cycle clear)
      if ((act_set_sticky || unit_err) && !err_cont_i) sticky_q <= 1'b1;
      else if (err_clear_i)                             sticky_q <= 1'b0;

      // ---------------------------------------------------- DMA engine
      dma_start_q <= act_issue_dma;
      dma_abort_q <= dma_to;
      if (act_issue_dma) begin
        dma_act_q <= 1'b1;
        dma_idx_q <= rob_tail;
        dma_seq_q <= dec_seq_q;
        dma_wd_q  <= '0;
      end else if (dma_fin || dma_to) begin
        dma_act_q <= 1'b0;
      end else if (dma_act_q && wd_en) begin
        dma_wd_q <= dma_progress_i ? '0 : dma_wd_q + WDW'(1);
      end
      if (dma_to) dma_dead_q <= 1'b1;

      // ---------------------------------------------------- vector executor
      vec_start_q <= act_issue_vec;
      if (act_issue_vec) begin
        vec_act_q <= 1'b1;
        vec_idx_q <= rob_tail;
        vec_seq_q <= dec_seq_q;
        vec_wd_q  <= '0;
      end else if (vec_fin || vec_to) begin
        vec_act_q <= 1'b0;
      end else if (vec_act_q && wd_en) begin
        vec_wd_q <= vec_progress_i ? '0 : vec_wd_q + WDW'(1);
      end
      if (vec_to) vec_dead_q <= 1'b1;
    end
  end

  // datapath registers (qualified by dec_v_q / *_act_q; not reset)
  always_ff @(posedge clk_i) begin
    if (q_pop_o) dec_q <= q_entry_i;
    if (act_issue_dma) begin
      dma_src_o <= d_sa;
      dma_dst_o <= d_da;
      dma_len_o <= d_len;
      dr_lo_q <= f_rd_lo;  dr_hi_q <= f_rd_hi;
      dw_lo_q <= f_wr_lo;  dw_hi_q <= f_wr_hi;
    end
    if (act_issue_vec) begin
      vec_op_o    <= hpc_cq_pkg::vec_op(d_op);
      vec_rm_o    <= d_rm;
      vec_src_a_o <= d_sa;
      vec_src_b_o <= d_sb;
      vec_dst_o   <= d_da;
      vec_vl_o    <= d_len[VL_W-1:0];
      vec_tid_o   <= d_tid;
      va_lo_q <= f_rd_lo;   va_hi_q <= f_rd_hi;
      vb_lo_q <= f_rd2_lo;  vb_hi_q <= f_rd2_hi;
      vw_lo_q <= f_wr_lo;   vw_hi_q <= f_wr_hi;
    end
  end

  assign dma_start_o = dma_start_q;
  assign dma_abort_o = dma_abort_q;
  assign vec_start_o = vec_start_q;

  // ================================================================ retirement buffer
  hpc_cq_rob #(.DEPTH(ROB_DEPTH)) u_rob (
    .clk_i, .rst_ni,
    .alloc_i(rob_alloc), .alloc_done_i(rob_alloc_done),
    .alloc_tid_i(d_tid), .alloc_op_i(d_op), .alloc_irq_i(d_fl[hpc_cq_pkg::FL_IRQ]),
    .alloc_seq_i(dec_seq_q), .alloc_err_i(rob_alloc_err), .alloc_st_i(rob_alloc_st),
    .alloc_idx_o(rob_tail), .full_o(rob_full),
    .upd_i(rob_upd), .upd_idx_i({vec_idx_q, dma_idx_q}),
    .upd_err_i({upd1_err, upd0_err}), .upd_st_i({upd1_st, upd0_st}),
    .upd_ff_i({upd1_ff, 5'd0}), .upd_cnt_i({upd1_cnt, upd0_cnt}),
    .upd_eaddr_i({upd1_ea, upd0_ea}),
    .ev_commit_o, .ev_commit_err_o, .ev_commit_skip_o, .ev_commit_irq_o,
    .rec_valid_o(cpl_valid_o), .rec_ready_i(cpl_ready_i), .rec_o(cpl_rec_o),
    .n_alloc_o(rob_nal), .n_cmt_o(rob_ncm)
  );

  // ================================================================ status / events
  assign dec_valid_o       = dec_v_q;
  assign rob_count_o       = rob_nal;
  assign err_sticky_o      = sticky_q;
  assign dma_down_o        = dma_dead_q;
  assign vec_down_o        = vec_dead_q;
  assign perf_clear_o      = act_rstcnt;
  assign ev_dma_issue_o    = act_issue_dma;
  assign ev_vec_issue_o    = act_issue_vec;
  assign ev_dma_active_o   = dma_act_q;
  assign ev_vec_active_o   = vec_act_q;
  assign ev_stall_hazard_o = st_haz;
  assign ev_stall_unit_o   = st_unit;
  assign ev_stall_sync_o   = st_sync;
  assign ev_stall_rob_o    = st_rob;
  assign trc_resolve_o     = dec_leave;
  assign trc_seq_o         = dec_seq_q;
  assign trc_dma_seq_o     = dma_seq_q;
  assign trc_vec_seq_o     = vec_seq_q;

`ifndef SYNTHESIS
  // ================================================================ checks
  // DataFabric's own start-time rules, applied to every DMA job we issue:
  // a valid command must never fail the engine's validation (codes 1..7).
  logic [3:0] df_code;
  dma_validate #(.DW(32), .MAX_LEN_LOG2(DMA_MAX_LEN_LOG2)) u_df_val (
    .src(d_sa), .dst(d_da), .len(d_len), .code(df_code));

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
    end else begin
      if (act_issue_dma && df_code != 4'd0)
        $error("hpc_cq_sched: issued DMA job fails DataFabric dma_validate (code %0d)", df_code);
      if (dma_start_o && dma_busy_i)
        $error("hpc_cq_sched: dma_start while the DMA engine is busy");
      if (vec_start_o && vec_busy_i)
        $error("hpc_cq_sched: vec_start while the vector executor is busy");
      if ((dma_done_i || dma_fail_i) && !dma_act_q && !dma_dead_q)
        $error("hpc_cq_sched: DMA completion pulse without a job");
      if ((vec_done_i || vec_fail_i) && !vec_act_q && !vec_dead_q)
        $error("hpc_cq_sched: vector completion pulse without a job");
      if (dma_fin && dma_fail_i && dma_err_code_i >= 4'd1 && dma_err_code_i <= 4'd7)
        $error("hpc_cq_sched: DMA engine rejected a validated job (code %0d)", dma_err_code_i);
      if (act_issue_dma && act_issue_vec)
        $error("hpc_cq_sched: two issues in one cycle");
      if (dma_act_q && vec_act_q &&
          (hpc_cq_pkg::isect(dr_lo_q, dr_hi_q, vw_lo_q, vw_hi_q) ||
           hpc_cq_pkg::isect(dw_lo_q, dw_hi_q, va_lo_q, va_hi_q) ||
           hpc_cq_pkg::isect(dw_lo_q, dw_hi_q, vb_lo_q, vb_hi_q) ||
           hpc_cq_pkg::isect(dw_lo_q, dw_hi_q, vw_lo_q, vw_hi_q)))
        $error("hpc_cq_sched: dependent DMA and vector jobs in flight together");
      if (!OVERLAP_EN && dma_act_q && vec_act_q)
        $error("hpc_cq_sched: OVERLAP_EN = 0 but both units are busy");
    end
  end
`endif
endmodule

`default_nettype wire
