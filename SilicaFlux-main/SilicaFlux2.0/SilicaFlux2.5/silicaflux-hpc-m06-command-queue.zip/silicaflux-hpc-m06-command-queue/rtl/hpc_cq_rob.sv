// =============================================================================
// SilicaFlux-HPC :: hpc_cq_rob -- in-order retirement buffer
//
// Every command that leaves the scheduler's decode slot allocates exactly one
// entry, in program order, and produces exactly one completion record:
//
//   tail --alloc--> [ pending | complete ] --commit--> [ committed ] --pop--> head
//
//   * alloc     : at the tail.  Commands resolved at decode (NOP, FENCE,
//                 RESET_COUNTERS, invalid, skipped, unit-down) are allocated
//                 already complete; issued DMA / vector jobs are allocated
//                 pending and completed later through one of the two update
//                 ports (upd0 = DMA, upd1 = vector).
//   * commit    : the commit pointer advances over the oldest uncommitted
//                 entry once it is complete -- at most one entry per cycle,
//                 strictly in allocation order.  Commit is the architectural
//                 completion point: ev_commit_* pulse here.
//   * pop       : committed entries are presented at rec_* (valid/ready),
//                 oldest first.  The entry is freed on the handshake.
//
// Interface timing: rec_valid_o, rec_o, full_o and the counts are functions
// of registered state only.  While rec_valid_o = 0, rec_o = 0.
// Record payload storage is datapath (not reset); the done bits and pointers
// are control state (asynchronously reset).
// =============================================================================
`default_nettype none

module hpc_cq_rob #(
  parameter int DEPTH = 8,
  localparam int IW   = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam int CW   = $clog2(DEPTH + 1)
) (
  input  wire logic           clk_i,
  input  wire logic           rst_ni,
  // ---------------------------------------------------------------- allocate
  input  wire logic           alloc_i,
  input  wire logic           alloc_done_i,      // allocated complete (resolved at decode)
  input  wire logic [7:0]     alloc_tid_i,
  input  wire logic [7:0]     alloc_op_i,
  input  wire logic           alloc_irq_i,
  input  wire logic [31:0]    alloc_seq_i,
  input  wire logic [7:0]     alloc_err_i,       // used when alloc_done_i
  input  wire logic [1:0]     alloc_st_i,        // used when alloc_done_i
  output logic [IW-1:0]       alloc_idx_o,       // index the next alloc will use
  output logic                full_o,
  // ---------------------------------------------------------------- complete (2 ports)
  input  wire logic [1:0]     upd_i,
  input  wire logic [2*IW-1:0] upd_idx_i,
  input  wire logic [15:0]    upd_err_i,
  input  wire logic [3:0]     upd_st_i,
  input  wire logic [9:0]     upd_ff_i,
  input  wire logic [63:0]    upd_cnt_i,
  input  wire logic [63:0]    upd_eaddr_i,
  // ---------------------------------------------------------------- commit events
  output logic                ev_commit_o,
  output logic                ev_commit_err_o,
  output logic                ev_commit_skip_o,
  output logic                ev_commit_irq_o,
  // ---------------------------------------------------------------- record output
  output logic                rec_valid_o,
  input  wire logic           rec_ready_i,
  output logic [127:0]        rec_o,
  // ---------------------------------------------------------------- status
  output logic [CW-1:0]       n_alloc_o,         // allocated, not yet popped
  output logic [CW-1:0]       n_cmt_o            // committed, not yet popped
);
  if (DEPTH < 2 || DEPTH > 64) begin : g_bad_depth
    hpc_param_error_ROB_DEPTH_must_be_2_to_64 u_err ();
  end

  function automatic logic [IW-1:0] inc(input logic [IW-1:0] p);
    inc = (p == IW'(DEPTH - 1)) ? '0 : p + IW'(1);
  endfunction

  // ---------------------------------------------------------------- storage
  logic [DEPTH-1:0] done_q;
  logic [7:0]  r_tid   [0:DEPTH-1];
  logic [7:0]  r_op    [0:DEPTH-1];
  logic [7:0]  r_err   [0:DEPTH-1];
  logic [1:0]  r_st    [0:DEPTH-1];
  logic        r_irq   [0:DEPTH-1];
  logic [4:0]  r_ff    [0:DEPTH-1];
  logic [31:0] r_cnt   [0:DEPTH-1];
  logic [31:0] r_eaddr [0:DEPTH-1];
  logic [31:0] r_seq   [0:DEPTH-1];

  logic [IW-1:0] head_q, cmt_q, tail_q;
  logic [CW-1:0] nal_q, ncm_q;

  wire do_alloc  = alloc_i && !full_o;
  wire do_commit = (ncm_q < nal_q) && done_q[cmt_q];
  wire do_pop    = rec_valid_o && rec_ready_i;

  assign full_o      = (nal_q == CW'(DEPTH));
  assign alloc_idx_o = tail_q;
  assign n_alloc_o   = nal_q;
  assign n_cmt_o     = ncm_q;
  assign rec_valid_o = (ncm_q != '0);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      head_q <= '0;
      cmt_q  <= '0;
      tail_q <= '0;
      nal_q  <= '0;
      ncm_q  <= '0;
      done_q <= '0;
    end else begin
      if (do_alloc)  tail_q <= inc(tail_q);
      if (do_commit) cmt_q  <= inc(cmt_q);
      if (do_pop)    head_q <= inc(head_q);
      nal_q <= nal_q + CW'(do_alloc) - CW'(do_pop);
      ncm_q <= ncm_q + CW'(do_commit) - CW'(do_pop);
      // done bits: distinct indices by construction (tail is free, update
      // targets are pending, head is committed)
      if (do_pop)   done_q[head_q] <= 1'b0;
      if (upd_i[0]) done_q[upd_idx_i[0 +: IW]]  <= 1'b1;
      if (upd_i[1]) done_q[upd_idx_i[IW +: IW]] <= 1'b1;
      if (do_alloc) done_q[tail_q] <= alloc_done_i;
    end
  end

  always_ff @(posedge clk_i) begin
    if (do_alloc) begin
      r_tid[tail_q] <= alloc_tid_i;
      r_op[tail_q]  <= alloc_op_i;
      r_irq[tail_q] <= alloc_irq_i;
      r_seq[tail_q] <= alloc_seq_i;
      r_err[tail_q] <= alloc_err_i;
      r_st[tail_q]  <= alloc_st_i;
      r_ff[tail_q]  <= 5'd0;
      r_cnt[tail_q] <= 32'd0;
      r_eaddr[tail_q] <= 32'd0;
    end
    for (int p = 0; p < 2; p++) begin
      if (upd_i[p]) begin
        r_err[upd_idx_i[p*IW +: IW]]   <= upd_err_i[p*8 +: 8];
        r_st[upd_idx_i[p*IW +: IW]]    <= upd_st_i[p*2 +: 2];
        r_ff[upd_idx_i[p*IW +: IW]]    <= upd_ff_i[p*5 +: 5];
        r_cnt[upd_idx_i[p*IW +: IW]]   <= upd_cnt_i[p*32 +: 32];
        r_eaddr[upd_idx_i[p*IW +: IW]] <= upd_eaddr_i[p*32 +: 32];
      end
    end
  end

  // ---------------------------------------------------------------- commit events
  assign ev_commit_o      = do_commit;
  assign ev_commit_err_o  = do_commit && (r_st[cmt_q] == hpc_cq_pkg::ST_ERROR);
  assign ev_commit_skip_o = do_commit && (r_st[cmt_q] == hpc_cq_pkg::ST_SKIPPED);
  assign ev_commit_irq_o  = do_commit && r_irq[cmt_q];

  // ---------------------------------------------------------------- record output
  always_comb begin
    rec_o = 128'd0;
    if (rec_valid_o)
      rec_o = {r_seq[head_q], r_eaddr[head_q], r_cnt[head_q],
               hpc_cq_pkg::rec_w0(r_tid[head_q], r_op[head_q], r_err[head_q], r_st[head_q],
                                  r_irq[head_q], r_ff[head_q])};
  end

`ifndef SYNTHESIS
  // ---------------------------------------------------------------- checks
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
    end else begin
      if (alloc_i && full_o)
        $error("hpc_cq_rob %m: alloc while full");
      for (int p = 0; p < 2; p++)
        if (upd_i[p] && done_q[upd_idx_i[p*IW +: IW]])
          $error("hpc_cq_rob %m: update port %0d targets an entry that is already complete", p);
      if (upd_i[0] && upd_i[1] && (upd_idx_i[0 +: IW] == upd_idx_i[IW +: IW]))
        $error("hpc_cq_rob %m: both update ports target the same entry");
      if (do_alloc && upd_i[0] && (upd_idx_i[0 +: IW] == tail_q))
        $error("hpc_cq_rob %m: update targets the entry being allocated");
      if (do_alloc && upd_i[1] && (upd_idx_i[IW +: IW] == tail_q))
        $error("hpc_cq_rob %m: update targets the entry being allocated");
      if (ncm_q > nal_q)
        $error("hpc_cq_rob %m: committed count exceeds allocated count");
    end
  end
`endif
endmodule

`default_nettype wire
