// SilicaFlux-HPC Module 06 -- synthesizable file list (paths relative to the module root)
// include directories
+incdir+rtl
+incdir+third_party/silicaflux-hpc-m04-scratchpad/rtl
+incdir+third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem
+incdir+third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/asic
+incdir+third_party/silicaflux-datafabric/rtl/dma
// packages
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_vector_pkg.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/hpc_varray_pkg.sv
rtl/hpc_cq_pkg.sv
// Module 02 lane (as vendored by Module 03, unmodified)
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_lzc.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_pipe.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_fp32_round.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_fp32_add.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_fp32_mul.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_fp32_fma.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_fp32_misc.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_int32_mul.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_vector_lane.sv
// Module 03 vector array (unmodified)
third_party/silicaflux-hpc-m03-vector-array/rtl/hpc_varray_fifo.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/hpc_varray_issue.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/hpc_varray_collect.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/hpc_varray_reduce.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/hpc_varray_perf.sv
third_party/silicaflux-hpc-m03-vector-array/rtl/hpc_vector_array.sv
// Module 04 scratchpad + SRAM Wrapper Library + DataFabric dma_fifo (unmodified)
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/sram_backend_1r1w.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/sram_backend_2rw.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1r1w.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_2rw.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1rw.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_1r1w.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/fpga/sram_fpga_2rw.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_asic_array.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_sky130.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_gf180.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp1p.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/asic/sram_leaf_ihp2p.sv
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-datafabric/rtl/dma/dma_fifo.sv
third_party/silicaflux-hpc-m04-scratchpad/rtl/hpc_spm_addr_map.sv
third_party/silicaflux-hpc-m04-scratchpad/rtl/hpc_spm_bank_arb.sv
third_party/silicaflux-hpc-m04-scratchpad/rtl/hpc_spm_bank.sv
third_party/silicaflux-hpc-m04-scratchpad/rtl/hpc_spm_perf.sv
third_party/silicaflux-hpc-m04-scratchpad/rtl/hpc_scratchpad.sv
// DataFabric DMA engine + SFB2 crossbar (unmodified)
third_party/silicaflux-datafabric/rtl/dma/dma_validate.sv
third_party/silicaflux-datafabric/rtl/dma/dma_transfer_engine.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_addr_decoder.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_arbiter.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_error_slave.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_req_mux.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_rsp_router.sv
third_party/silicaflux-datafabric/rtl/interconnect/sfb_crossbar.sv
// Module 06 command queue
rtl/hpc_cq_validate.sv
rtl/hpc_cq_rob.sv
rtl/hpc_cq_perf.sv
rtl/hpc_cq_sched.sv
rtl/hpc_command_queue.sv
rtl/hpc_cq_vexec.sv
rtl/hpc_cq_tile.sv
