// =============================================================================
// SilicaFlux-HPC :: hpc_cq_vexec -- vector job executor (scratchpad <-> array)
//
// Runs one memory-to-memory vector job at a time on the Module 03 vector
// array (hpc_vector_array, streaming only) using N lane ports of the
// Module 04 scratchpad (hpc_scratchpad, WRITE_ACK = 1):
//
//   lane l owns elements e = l, l+N, l+2N, ...      (Module 03 beat layout)
//
//   port l  --read A[e], B[e] (, D[e] for FMA)-->  assembly --> opq[l]
//   beat g  = { opq[l] head : lanes active in g }   --> array opnd
//   array res beat --> wbq[l] (res_mask lanes)      --> port l: write D[e]
//   array cpl record + every write acknowledged     --> done / fail
//
//   op ADD : D = A + B      array FADD  (0x01)
//   op MUL : D = A * B      array FMUL  (0x03)
//   op FMA : D = A * B + D  array FMADD (0x04, one rounding), C read from D
//
// Control contract -- identical to DataFabric dma_transfer_engine:
//   start_i is sampled in IDLE; busy_o is high from the next cycle until the
//   terminal state; done_o / fail_o are one-cycle pulses (COMPLETE / ERROR
//   state) and the executor is IDLE in the following cycle.  err_code_o,
//   err_addr_o, fflags_o and count_o are valid with done / fail and held
//   until the next start.
//
// Genuine completion: done_o is raised only when (a) every operand beat has
// been handed to the array, (b) every result beat has been taken, (c) the
// array's completion record has been taken (it is presented only after its
// last result beat), and (d) every destination write has been answered by
// the scratchpad.  With WRITE_ACK = 1 an answer means the bank array has been
// written (Module 04 docs/01), so a following command -- on any port -- reads
// the new data.
//
// Ordering inside a job: element e is read and written only through port
// e mod N, in request order (Module 04: per-port in-order responses).  Its
// reads therefore precede its write.  Different elements touch different
// words, so D may be identical to A and/or B (in place) -- partial overlap is
// rejected by hpc_cq_validate before a job is ever started.
//
// Flow control: read requests of an element are issued only against a
// reserved operand-queue slot (per-lane credit counter), so the response
// channel never back-pressures (sp_rsp_ready_o = 1).  Write-back requests
// have priority over reads on a port.  A result beat is taken only when
// every lane's write-back queue has room.
//
// Errors (first one wins, recorded with its address):
//   READ   a read response with sp_rsp_err = 1 (rdata is 0 then)
//   WRITE  a write acknowledgement with sp_rsp_err = 1
//   ENGINE the array reported the command illegal or a count != vl
// After an error no further result is written (the remaining beats are still
// streamed and drained so that the array finishes the command and stays in
// step); the destination range is then partially written / undefined.
// count_o = number of destination elements whose write was acknowledged OK.
//
// Coding rules: SilicaFlux RTL subset.  Datapath registers are not reset.
// =============================================================================
`default_nettype none

module hpc_cq_vexec #(
  parameter int N         = 2,     // lanes = scratchpad lane ports (1, 2, 4, 8, 16)
  parameter int VL_W      = 16,    // vector length width (Module 03 VL_W)
  parameter int TAG_W     = 8,     // scratchpad request tag width (>= 2)
  parameter int OPQ_DEPTH = 4,     // per-lane operand queue, elements
  parameter int WBQ_DEPTH = 4,     // per-lane write-back queue, elements
  localparam int EW       = VL_W + 1
) (
  input  wire logic                 clk_i,
  input  wire logic                 rst_ni,
  // ---------------------------------------------------------------- job control
  input  wire logic                 start_i,
  input  wire logic [1:0]           op_i,
  input  wire logic [2:0]           rm_i,
  input  wire logic [31:0]          src_a_i,
  input  wire logic [31:0]          src_b_i,
  input  wire logic [31:0]          dst_i,
  input  wire logic [VL_W-1:0]      vl_i,
  input  wire logic [7:0]           tid_i,
  output logic                      busy_o,
  output logic                      done_o,
  output logic                      fail_o,
  output logic [3:0]                err_code_o,
  output logic [31:0]               err_addr_o,
  output logic [4:0]                fflags_o,
  output logic [31:0]               count_o,
  output logic                      progress_o,
  // ---------------------------------------------------------------- vector array: command
  output logic                      va_cmd_valid_o,
  input  wire logic                 va_cmd_ready_i,
  output logic [4:0]                va_cmd_op_o,
  output logic [2:0]                va_cmd_rm_o,
  output logic [VL_W-1:0]           va_cmd_vl_o,
  output logic [7:0]                va_cmd_tid_o,
  // ---------------------------------------------------------------- vector array: operand beats
  output logic                      va_opnd_valid_o,
  input  wire logic                 va_opnd_ready_i,
  output logic [N*32-1:0]           va_opnd_a_o,
  output logic [N*32-1:0]           va_opnd_b_o,
  output logic [N*32-1:0]           va_opnd_c_o,
  // ---------------------------------------------------------------- vector array: result beats
  input  wire logic                 va_res_valid_i,
  output logic                      va_res_ready_o,
  input  wire logic [N*32-1:0]      va_res_data_i,
  input  wire logic [N-1:0]         va_res_mask_i,
  input  wire logic                 va_res_last_i,
  // ---------------------------------------------------------------- vector array: completion
  input  wire logic                 va_cpl_valid_i,
  output logic                      va_cpl_ready_o,
  input  wire logic [4:0]           va_cpl_flags_i,
  input  wire logic                 va_cpl_illegal_i,
  input  wire logic [VL_W-1:0]      va_cpl_count_i,
  // ---------------------------------------------------------------- scratchpad lane ports
  output logic [N-1:0]              sp_req_valid_o,
  input  wire logic [N-1:0]         sp_req_ready_i,
  output logic [N-1:0]              sp_req_we_o,
  output logic [N*32-1:0]           sp_req_addr_o,
  output logic [N*32-1:0]           sp_req_wdata_o,
  output logic [N*4-1:0]            sp_req_wstrb_o,
  output logic [N*TAG_W-1:0]        sp_req_tag_o,
  input  wire logic [N-1:0]         sp_rsp_valid_i,
  output logic [N-1:0]              sp_rsp_ready_o,
  input  wire logic [N*32-1:0]      sp_rsp_rdata_i,
  input  wire logic [N-1:0]         sp_rsp_err_i,
  input  wire logic [N-1:0]         sp_rsp_we_i,
  /* verilator lint_off UNUSEDSIGNAL */  // only the kind bits are checked (simulation)
  input  wire logic [N*TAG_W-1:0]   sp_rsp_tag_i
  /* verilator lint_on UNUSEDSIGNAL */
);
  // ================================================================ elaboration checks
  if (!((N == 1) || (N == 2) || (N == 4) || (N == 8) || (N == 16))) begin : g_bad_n
    hpc_param_error_VEXEC_N_must_be_1_2_4_8_or_16 u_err ();
  end
  if (TAG_W < 2) begin : g_bad_tag
    hpc_param_error_VEXEC_TAG_W_below_2 u_err ();
  end
  if (OPQ_DEPTH < 1 || WBQ_DEPTH < 1) begin : g_bad_q
    hpc_param_error_VEXEC_queue_depth_below_1 u_err ();
  end

  localparam int LN   = (N > 1) ? $clog2(N) : 0;
  localparam int CRW  = $clog2(OPQ_DEPTH + 1);
  localparam int PCW  = $clog2(N + 1);
  localparam int WOW  = 8;   // outstanding-write counter (bounded by the scratchpad response credits)

  // tag kinds (low two tag bits)
  // (read tags carry the read phase 0 = A, 1 = B, 2 = C; writes carry K_W)
  localparam logic [1:0] K_W = 2'd3;

  // FSM
  localparam logic [1:0] S_IDLE = 2'd0, S_RUN = 2'd1, S_DONE = 2'd2, S_FAIL = 2'd3;
  logic [1:0] st_q;
  wire run = (st_q == S_RUN);

  // ================================================================ job registers
  logic [1:0]      op_q;
  logic [31:0]     a_q, b_q, d_q;
  logic [EW-1:0]   vl_q;          // zero-extended vl
  logic [EW-1:0]   nbeat_q;       // ceil(vl / N)
  logic [EW-1:0]   bo_q;          // operand beats handed to the array
  logic [EW-1:0]   ri_q;          // result beats taken
  logic            cmd_pend_q;
  logic            got_cpl_q;
  logic            jerr_q;
  logic [3:0]      ecode_q;
  logic [31:0]     eaddr_q;
  logic [4:0]      ff_q;
  logic [31:0]     cnt_q;
  wire  [1:0]      nph_m1 = (op_q == hpc_cq_pkg::VOP_FMA) ? 2'd2 : 2'd1;   // last read phase

  // ================================================================ per-lane state
  logic [N-1:0]        opq_push, opq_pop, opq_empty, opq_full;
  logic [N*96-1:0]     opq_wdata, opq_rdata;
  logic [N-1:0]        wbq_push, wbq_pop, wbq_empty, wbq_full;
  logic [N*32-1:0]     wbq_rdata;

  logic [N-1:0]        rd_done;       // every read response of the lane received
  logic [N-1:0]        wr_idle;       // no write queued, in the request register or outstanding
  logic [N-1:0]        rerr, werr;    // error responses this cycle
  logic [N*32-1:0]     rerr_addr, werr_addr;
  logic [N-1:0]        wack_ok;       // successful write acknowledgements this cycle
  logic [N-1:0]        lane_act;      // lane active in operand beat bo_q

  // beat bookkeeping shared by all lanes
  wire [EW-1:0] ebase      = bo_q << LN;                     // first element of beat bo_q
  wire          beats_left = (bo_q < nbeat_q);
  wire          opnd_hs    = va_opnd_valid_o && va_opnd_ready_i;
  wire          res_hs     = va_res_valid_i && va_res_ready_o;

  for (genvar l = 0; l < N; l++) begin : g_lane
    // ---------------------------------------------------- counters
    logic [EW-1:0]  re_q;       // next element to read
    logic [1:0]     rph_q;      // next read phase of that element
    logic [CRW-1:0] cred_q;     // free operand-queue slots not yet reserved
    logic [EW-1:0]  we_q;       // next element to write
    logic [EW-1:0]  rr_q;       // element of the next read response
    logic [1:0]     rrph_q;     // phase of the next read response
    logic [EW-1:0]  wa_q;       // element of the next write acknowledgement
    logic [WOW-1:0] wout_q;   // writes accepted, not yet acknowledged
    logic [31:0]    asm_a_q, asm_b_q;

    // request register (payload registered and held until accepted)
    logic           rq_v_q, rq_we_q;
    logic [31:0]    rq_addr_q, rq_wdata_q;
    logic [1:0]     rq_kind_q;

    wire rq_free  = !rq_v_q || sp_req_ready_i[l];
    wire rd_more  = run && (re_q < vl_q);
    wire rd_ok    = rd_more && ((rph_q != 2'd0) || (cred_q != '0));
    wire sel_w    = run && !wbq_empty[l];
    wire sel_r    = !sel_w && rd_ok;
    wire load     = rq_free && (sel_w || sel_r);
    wire rq_hs    = rq_v_q && sp_req_ready_i[l];

    wire [31:0] e4_rd  = 32'(re_q) << 2;
    wire [31:0] rd_base = (rph_q == 2'd0) ? a_q : (rph_q == 2'd1) ? b_q : d_q;
    wire [31:0] e4_wr  = 32'(we_q) << 2;

    // responses
    wire rsp_v   = sp_rsp_valid_i[l];
    wire rsp_rd  = rsp_v && !sp_rsp_we_i[l];
    wire rsp_wr  = rsp_v &&  sp_rsp_we_i[l];
    wire [31:0] rdata = sp_rsp_rdata_i[l*32 +: 32];
    wire rd_last = (rrph_q == nph_m1);
    wire [31:0] rr_base = (rrph_q == 2'd0) ? a_q : (rrph_q == 2'd1) ? b_q : d_q;

    assign opq_push[l]  = rsp_rd && rd_last;
    assign opq_wdata[l*96 +: 96] = {(rrph_q == 2'd2) ? rdata : 32'd0,      // c
                                    (rrph_q == 2'd1) ? rdata : asm_b_q,    // b
                                    asm_a_q};                              // a
    assign lane_act[l]  = (ebase + EW'(l)) < vl_q;
    assign opq_pop[l]   = opnd_hs && lane_act[l];
    assign wbq_push[l]  = res_hs && va_res_mask_i[l] && !jerr_q;
    assign wbq_pop[l]   = load && sel_w;

    assign rerr[l]      = rsp_rd && sp_rsp_err_i[l];
    assign werr[l]      = rsp_wr && sp_rsp_err_i[l];
    assign wack_ok[l]   = rsp_wr && !sp_rsp_err_i[l];
    assign rerr_addr[l*32 +: 32] = rr_base + (32'(rr_q) << 2);
    assign werr_addr[l*32 +: 32] = d_q + (32'(wa_q) << 2);

    assign rd_done[l]   = (rr_q >= vl_q);
    assign wr_idle[l]   = wbq_empty[l] && !(rq_v_q && rq_we_q) && (wout_q == '0);

    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        re_q   <= '0;  rph_q  <= 2'd0;  cred_q <= '0;
        we_q   <= '0;  rr_q   <= '0;    rrph_q <= 2'd0;
        wa_q   <= '0;  wout_q <= '0;
        rq_v_q <= 1'b0;
      end else if (st_q == S_IDLE) begin
        if (start_i) begin
          re_q   <= EW'(l);  rph_q  <= 2'd0;  cred_q <= CRW'(OPQ_DEPTH);
          we_q   <= EW'(l);  rr_q   <= EW'(l);  rrph_q <= 2'd0;
          wa_q   <= EW'(l);  wout_q <= '0;
        end
        rq_v_q <= 1'b0;
      end else begin
        // request register
        if (rq_free) rq_v_q <= load;
        if (load && sel_r) begin
          if (rph_q == 2'd0) cred_q <= cred_q - CRW'(1) + CRW'(opq_pop[l]);
          else               cred_q <= cred_q + CRW'(opq_pop[l]);
          if (rph_q == nph_m1) begin
            rph_q <= 2'd0;
            re_q  <= re_q + EW'(N);
          end else begin
            rph_q <= rph_q + 2'd1;
          end
        end else begin
          cred_q <= cred_q + CRW'(opq_pop[l]);
        end
        if (wbq_pop[l]) we_q <= we_q + EW'(N);
        // responses
        if (rsp_rd) begin
          if (rd_last) begin
            rrph_q <= 2'd0;
            rr_q   <= rr_q + EW'(N);
          end else begin
            rrph_q <= rrph_q + 2'd1;
          end
        end
        if (rsp_wr) wa_q <= wa_q + EW'(N);
        wout_q <= wout_q + WOW'(rq_hs && rq_we_q) - WOW'(rsp_wr);
      end
    end

    always_ff @(posedge clk_i) begin
      if (load) begin
        rq_we_q    <= sel_w;
        rq_addr_q  <= sel_w ? (d_q + e4_wr) : (rd_base + e4_rd);
        rq_wdata_q <= sel_w ? wbq_rdata[l*32 +: 32] : 32'd0;
        rq_kind_q  <= sel_w ? K_W : rph_q;
      end
      if (rsp_rd && rrph_q == 2'd0) asm_a_q <= rdata;
      if (rsp_rd && rrph_q == 2'd1) asm_b_q <= rdata;
    end

    assign sp_req_valid_o[l]              = rq_v_q;
    assign sp_req_we_o[l]                 = rq_v_q && rq_we_q;
    assign sp_req_addr_o[l*32 +: 32]      = rq_v_q ? rq_addr_q  : 32'd0;
    assign sp_req_wdata_o[l*32 +: 32]     = (rq_v_q && rq_we_q) ? rq_wdata_q : 32'd0;
    assign sp_req_wstrb_o[l*4 +: 4]       = (rq_v_q && rq_we_q) ? 4'hF : 4'h0;
    assign sp_req_tag_o[l*TAG_W +: TAG_W] = rq_v_q ? TAG_W'(rq_kind_q) : '0;
    assign sp_rsp_ready_o[l]              = 1'b1;

    /* verilator lint_off UNUSEDSIGNAL */
    logic [$clog2(OPQ_DEPTH+1)-1:0] opq_cnt;
    logic [$clog2(WBQ_DEPTH+1)-1:0] wbq_cnt;
    /* verilator lint_on UNUSEDSIGNAL */
    // operand queue: {c, b, a}
    hpc_varray_fifo #(.W(96), .DEPTH(OPQ_DEPTH)) u_opq (
      .clk_i, .rst_ni, .push_i(opq_push[l]), .wdata_i(opq_wdata[l*96 +: 96]),
      .pop_i(opq_pop[l]), .rdata_o(opq_rdata[l*96 +: 96]),
      .empty_o(opq_empty[l]), .full_o(opq_full[l]), .count_o(opq_cnt));

    // write-back queue: result data
    hpc_varray_fifo #(.W(32), .DEPTH(WBQ_DEPTH)) u_wbq (
      .clk_i, .rst_ni, .push_i(wbq_push[l]), .wdata_i(va_res_data_i[l*32 +: 32]),
      .pop_i(wbq_pop[l]), .rdata_o(wbq_rdata[l*32 +: 32]),
      .empty_o(wbq_empty[l]), .full_o(wbq_full[l]), .count_o(wbq_cnt));

    // operand beat payload: active lanes only (inactive positions are 0)
    assign va_opnd_a_o[l*32 +: 32] = lane_act[l] ? opq_rdata[l*96      +: 32] : 32'd0;
    assign va_opnd_b_o[l*32 +: 32] = lane_act[l] ? opq_rdata[l*96 + 32 +: 32] : 32'd0;
    assign va_opnd_c_o[l*32 +: 32] = lane_act[l] ? opq_rdata[l*96 + 64 +: 32] : 32'd0;

`ifndef SYNTHESIS
    always @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
      end else begin
        if (rsp_v && st_q != S_RUN)
          $error("hpc_cq_vexec lane %0d: scratchpad response outside a job", l);
        if (rsp_rd && sp_rsp_tag_i[l*TAG_W +: 2] != rrph_q)
          $error("hpc_cq_vexec lane %0d: read response tag %0d, expected phase %0d",
                 l, sp_rsp_tag_i[l*TAG_W +: 2], rrph_q);
        if (rsp_wr && sp_rsp_tag_i[l*TAG_W +: 2] != K_W)
          $error("hpc_cq_vexec lane %0d: write acknowledgement with a read tag", l);
        if (opq_push[l] && opq_full[l] && !opq_pop[l])
          $error("hpc_cq_vexec lane %0d: operand queue overflow (credit error)", l);
      end
    end
`endif
  end

  // ================================================================ beats, results, completion
  assign va_opnd_valid_o = run && beats_left && ((~lane_act | ~opq_empty) == {N{1'b1}});
  assign va_res_ready_o  = run && (jerr_q || (wbq_full == '0));
  assign va_cpl_ready_o  = run;
  assign va_cmd_valid_o  = run && cmd_pend_q;
  assign va_cmd_op_o     = (op_q == hpc_cq_pkg::VOP_MUL) ? hpc_vector_pkg::OP_FMUL :
                           (op_q == hpc_cq_pkg::VOP_FMA) ? hpc_vector_pkg::OP_FMADD :
                                                           hpc_vector_pkg::OP_FADD;
  logic [2:0]      rm_q;
  logic [7:0]      tid_q;
  assign va_cmd_rm_o  = rm_q;
  assign va_cmd_vl_o  = vl_q[VL_W-1:0];
  assign va_cmd_tid_o = tid_q;

  wire cpl_hs  = va_cpl_valid_i && va_cpl_ready_o;
  wire cpl_bad = va_cpl_illegal_i || (va_cpl_count_i != vl_q[VL_W-1:0]);

  // first error this cycle (lowest lane first; read before write before engine)
  logic        new_err;
  logic [3:0]  new_code;
  logic [31:0] new_addr;
  always_comb begin
    new_err  = 1'b0;
    new_code = hpc_cq_pkg::VX_ERR_NONE;
    new_addr = 32'd0;
    for (int l = N - 1; l >= 0; l--) begin
      if (werr[l]) begin new_err = 1'b1; new_code = hpc_cq_pkg::VX_ERR_WRITE; new_addr = werr_addr[l*32 +: 32]; end
    end
    for (int l = N - 1; l >= 0; l--) begin
      if (rerr[l]) begin new_err = 1'b1; new_code = hpc_cq_pkg::VX_ERR_READ;  new_addr = rerr_addr[l*32 +: 32]; end
    end
    if (!new_err && cpl_hs && cpl_bad) begin
      new_err = 1'b1; new_code = hpc_cq_pkg::VX_ERR_ENGINE; new_addr = 32'd0;
    end
  end

  logic [PCW-1:0] nack;
  always_comb begin
    nack = '0;
    for (int l = 0; l < N; l++) nack = nack + PCW'(wack_ok[l]);
  end

  wire all_done = !cmd_pend_q && (bo_q == nbeat_q) && (ri_q == nbeat_q) && got_cpl_q &&
                  (rd_done == {N{1'b1}}) && (wr_idle == {N{1'b1}});

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      st_q       <= S_IDLE;
      cmd_pend_q <= 1'b0;
      got_cpl_q  <= 1'b0;
      jerr_q     <= 1'b0;
      bo_q       <= '0;
      ri_q       <= '0;
      nbeat_q    <= '0;
      vl_q       <= '0;
      op_q       <= hpc_cq_pkg::VOP_ADD;
      ecode_q    <= hpc_cq_pkg::VX_ERR_NONE;
      eaddr_q    <= 32'd0;
      ff_q       <= 5'd0;
      cnt_q      <= 32'd0;
    end else begin
      case (st_q)
        S_IDLE: begin
          if (start_i) begin
            st_q       <= S_RUN;
            op_q       <= op_i;
            vl_q       <= {1'b0, vl_i};
            nbeat_q    <= ({1'b0, vl_i} + EW'(N - 1)) >> LN;
            bo_q       <= '0;
            ri_q       <= '0;
            cmd_pend_q <= 1'b1;
            got_cpl_q  <= 1'b0;
            jerr_q     <= 1'b0;
            ecode_q    <= hpc_cq_pkg::VX_ERR_NONE;
            eaddr_q    <= 32'd0;
            ff_q       <= 5'd0;
            cnt_q      <= 32'd0;
          end
        end
        S_RUN: begin
          if (va_cmd_valid_o && va_cmd_ready_i) cmd_pend_q <= 1'b0;
          if (opnd_hs) bo_q <= bo_q + EW'(1);
          if (res_hs)  ri_q <= ri_q + EW'(1);
          if (cpl_hs) begin
            got_cpl_q <= 1'b1;
            ff_q      <= va_cpl_flags_i;
          end
          cnt_q <= cnt_q + 32'(nack);
          if (new_err && !jerr_q) begin
            jerr_q  <= 1'b1;
            ecode_q <= new_code;
            eaddr_q <= new_addr;
          end
          if (all_done) st_q <= jerr_q ? S_FAIL : S_DONE;
        end
        default: st_q <= S_IDLE;     // S_DONE / S_FAIL last one cycle
      endcase
    end
  end

  always_ff @(posedge clk_i) begin
    if (st_q == S_IDLE && start_i) begin
      a_q   <= src_a_i;
      b_q   <= src_b_i;
      d_q   <= dst_i;
      rm_q  <= rm_i;
      tid_q <= tid_i;
    end
  end

  assign busy_o     = (st_q != S_IDLE);
  assign done_o     = (st_q == S_DONE);
  assign fail_o     = (st_q == S_FAIL);
  assign err_code_o = ecode_q;
  assign err_addr_o = eaddr_q;
  assign fflags_o   = ff_q;
  assign count_o    = cnt_q;
  assign progress_o = (|(sp_req_valid_o & sp_req_ready_i)) || (|sp_rsp_valid_i) ||
                      (va_cmd_valid_o && va_cmd_ready_i) || opnd_hs || res_hs || cpl_hs;

`ifndef SYNTHESIS
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
    end else begin
      if (res_hs && (va_res_last_i != (ri_q == nbeat_q - EW'(1))))
        $error("hpc_cq_vexec: result beat %0d of %0d has last = %0b", ri_q, nbeat_q, va_res_last_i);
      if (res_hs && ri_q >= nbeat_q)
        $error("hpc_cq_vexec: result beat beyond the job");
      if (cpl_hs && got_cpl_q)
        $error("hpc_cq_vexec: second completion record for one job");
      if ((va_res_valid_i || va_cpl_valid_i) && st_q != S_RUN)
        $error("hpc_cq_vexec: array output outside a job");
    end
  end
`endif
endmodule

`default_nettype wire
