// =============================================================================
// SilicaFlux-HPC :: hpc_command_queue -- hardware command queue and compute
// scheduler for the SilicaFlux-HPC compute tile
//
// Module 06.  Primary source.  Aureom.AI | SilicaFlux-HPC.
//
//   host --cmd (valid/ready, 256-bit descriptor, ABI v1)-->
//        [command FIFO, QUEUE_DEPTH = 4 | 8 | 16]           hpc_varray_fifo (M03, unmodified)
//            |  pop (in order)
//            v
//        [scheduler]  decode, validate, resources, dependencies, issue   hpc_cq_sched
//            |                      |
//            |  DMA control         |  vector-job control
//            v                      v
//        DataFabric dma_transfer_engine        hpc_cq_vexec -> hpc_vector_array (M03)
//        (SFB2 -> external memory / scratchpad)        -> hpc_scratchpad (M04)
//            |                      |
//            +---- done / fail -----+
//            v
//        [retirement buffer, ROB_DEPTH] in-order commit            hpc_cq_rob
//            |
//   host <--cpl (valid/ready, 128-bit completion record)
//
// Submission: a command is accepted ONLY at a rising edge with
// cmd_valid_i && cmd_ready_o.  cmd_ready_o = !FIFO-full is registered state;
// a full queue never accepts, so queued commands are never overwritten and
// nothing is dropped.  Every accepted command produces exactly one
// completion record, in acceptance order (SEQ = 0, 1, 2, ... after reset).
//
// Interface timing: cmd_ready_o, cpl_valid_o, cpl_rec_o, every status output
// and perf_cnt_o are functions of registered state only.  cpl_rec_o is held
// stable while cpl_valid_o && !cpl_ready_i, and is 0 while cpl_valid_o = 0.
//
// Reset (rst_ni, asynchronous assert / synchronous release): discards every
// queued, decoding, in-flight and committed command; no record is ever
// produced for a command accepted before the reset.  The attached units must
// share this reset (hpc_cq_tile does).
//
// Specification: docs/01_COMMAND_ABI.md (descriptor / record / codes),
// docs/02_ARCHITECTURE.md (queue, scheduler FSM, ordering),
// docs/03_SYNCHRONISATION.md (FENCE), docs/04_ERRORS.md.
// =============================================================================
`default_nettype none

module hpc_command_queue #(
  parameter int          QUEUE_DEPTH      = 8,              // 4, 8 or 16
  parameter int          ROB_DEPTH        = 8,              // 2 .. 64 records in flight / waiting
  parameter bit          OPSET_FULL       = 1'b1,           // 0: bring-up subset NOP/DMA_LOAD/VECTOR_ADD/FENCE
  parameter bit          OVERLAP_EN       = 1'b1,           // 0: one job in flight at a time
  parameter logic [31:0] EXT_BASE         = 32'h1000_0000,  // external-memory window (DMA side)
  parameter int          EXT_LOG2         = 17,             //   2^EXT_LOG2 bytes, base aligned
  parameter logic [31:0] SPM_BASE         = 32'h2000_0000,  // scratchpad window
  parameter int          SPM_LOG2         = 16,             //   2^SPM_LOG2 bytes, base aligned
  parameter int          DMA_MAX_LEN_LOG2 = 24,             // = DataFabric MAX_LEN_LOG2
  parameter int          VL_W             = 16,             // = Module 03 VL_W
  parameter int          WDOG_LOG2        = 16,             // no-progress watchdog, 0 = off
  parameter bit          PERF_EN          = 1'b1,
  parameter int          PERF_CW          = 32,
  localparam int         QCW              = $clog2(QUEUE_DEPTH + 1),
  localparam int         RCW              = $clog2(ROB_DEPTH + 1)
) (
  input  wire logic                                  clk_i,
  input  wire logic                                  rst_ni,
  // ---------------------------------------------------------------- command submission
  input  wire logic                                  cmd_valid_i,
  output logic                                       cmd_ready_o,
  input  wire logic [hpc_cq_pkg::DESC_W-1:0]         cmd_desc_i,
  // ---------------------------------------------------------------- completion records
  output logic                                       cpl_valid_o,
  input  wire logic                                  cpl_ready_i,
  output logic [hpc_cq_pkg::REC_W-1:0]               cpl_rec_o,
  // ---------------------------------------------------------------- control
  input  wire logic                                  ctrl_err_cont_i,    // 0 stop-on-error, 1 continue
  input  wire logic                                  ctrl_err_clear_i,   // pulse: clear the sticky error
  input  wire logic                                  ctrl_perf_clear_i,  // pulse: clear the counters
  // ---------------------------------------------------------------- DMA engine (dma_transfer_engine contract)
  output logic                                       dma_start_o,
  output logic                                       dma_abort_o,
  output logic [31:0]                                dma_src_o,
  output logic [31:0]                                dma_dst_o,
  output logic [31:0]                                dma_len_o,
  input  wire logic                                  dma_busy_i,
  input  wire logic                                  dma_done_i,
  input  wire logic                                  dma_fail_i,
  input  wire logic [3:0]                            dma_err_code_i,
  input  wire logic [31:0]                           dma_err_addr_i,
  input  wire logic [31:0]                           dma_bytes_done_i,
  input  wire logic                                  dma_progress_i,
  // ---------------------------------------------------------------- vector executor (same contract)
  output logic                                       vec_start_o,
  output logic [1:0]                                 vec_op_o,
  output logic [2:0]                                 vec_rm_o,
  output logic [31:0]                                vec_src_a_o,
  output logic [31:0]                                vec_src_b_o,
  output logic [31:0]                                vec_dst_o,
  output logic [VL_W-1:0]                            vec_vl_o,
  output logic [7:0]                                 vec_tid_o,
  input  wire logic                                  vec_busy_i,
  input  wire logic                                  vec_done_i,
  input  wire logic                                  vec_fail_i,
  input  wire logic [3:0]                            vec_err_code_i,
  input  wire logic [31:0]                           vec_err_addr_i,
  input  wire logic [4:0]                            vec_fflags_i,
  input  wire logic [31:0]                           vec_count_i,
  input  wire logic                                  vec_progress_i,
  // ---------------------------------------------------------------- status
  output logic                                       busy_o,        // a command accepted and not handed over
  output logic [QCW-1:0]                             q_count_o,     // commands waiting in the FIFO
  output logic                                       q_full_o,
  output logic                                       q_empty_o,
  output logic [RCW-1:0]                             rob_count_o,   // records in flight or waiting
  output logic                                       err_sticky_o,
  output logic                                       dma_down_o,
  output logic                                       vec_down_o,
  // ---------------------------------------------------------------- commit events (interrupt sources)
  output logic                                       ev_commit_o,
  output logic                                       ev_commit_err_o,   // STATUS = ERROR or SKIPPED
  output logic                                       ev_commit_irq_o,   // FL_IRQ command committed
  // ---------------------------------------------------------------- counters
  output logic [hpc_cq_pkg::PC_N*PERF_CW-1:0]        perf_cnt_o,
  // ---------------------------------------------------------------- trace (verification / debug)
  output logic                                       trc_resolve_o,
  output logic [31:0]                                trc_seq_o,
  output logic                                       trc_dma_act_o,
  output logic [31:0]                                trc_dma_seq_o,
  output logic                                       trc_vec_act_o,
  output logic [31:0]                                trc_vec_seq_o
);
  // ================================================================ elaboration checks
  if (!((QUEUE_DEPTH == 4) || (QUEUE_DEPTH == 8) || (QUEUE_DEPTH == 16))) begin : g_bad_qd
    hpc_param_error_QUEUE_DEPTH_must_be_4_8_or_16 u_err ();
  end
  if (EXT_LOG2 < 3 || EXT_LOG2 > 31 || SPM_LOG2 < 3 || SPM_LOG2 > 31) begin : g_bad_win
    hpc_param_error_window_LOG2_must_be_3_to_31 u_err ();
  end
  if (((EXT_BASE & ((32'd1 << EXT_LOG2) - 32'd1)) != 32'd0) ||
      ((SPM_BASE & ((32'd1 << SPM_LOG2) - 32'd1)) != 32'd0)) begin : g_bad_align
    hpc_param_error_window_base_not_aligned_to_size u_err ();
  end
  if (({1'b0, EXT_BASE} < {1'b0, SPM_BASE} + (33'd1 << SPM_LOG2)) &&
      ({1'b0, SPM_BASE} < {1'b0, EXT_BASE} + (33'd1 << EXT_LOG2))) begin : g_bad_overlap
    hpc_param_error_EXT_and_SPM_windows_overlap u_err ();
  end
  if (DMA_MAX_LEN_LOG2 < 2 || DMA_MAX_LEN_LOG2 > 31 || VL_W < 1 || VL_W > 28) begin : g_bad_len
    hpc_param_error_DMA_MAX_LEN_LOG2_or_VL_W_out_of_range u_err ();
  end

  // ================================================================ command FIFO
  // Entry = descriptor words 0..5 + OR(words 6, 7)  (hpc_cq_pkg::QE_W bits)
  wire [hpc_cq_pkg::QE_W-1:0] q_wdata = {(cmd_desc_i[255:192] != 64'd0), cmd_desc_i[191:0]};
  logic [hpc_cq_pkg::QE_W-1:0] q_rdata;
  logic q_full, q_empty, q_pop;
  wire  q_push = cmd_valid_i && cmd_ready_o;

  hpc_varray_fifo #(.W(hpc_cq_pkg::QE_W), .DEPTH(QUEUE_DEPTH)) u_fifo (
    .clk_i, .rst_ni,
    .push_i(q_push), .wdata_i(q_wdata),
    .pop_i(q_pop), .rdata_o(q_rdata),
    .empty_o(q_empty), .full_o(q_full), .count_o(q_count_o)
  );

  // cmd_ready_o depends only on the registered FIFO count: a full queue
  // refuses even when an entry is popped in the same cycle.
  logic rdy_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) rdy_q <= 1'b0;        // not ready during reset and the first cycle after
    else         rdy_q <= 1'b1;
  end
  assign cmd_ready_o = rdy_q && !q_full;
  assign q_full_o    = q_full;
  assign q_empty_o   = q_empty;

  // ================================================================ scheduler
  logic dec_v;
  logic perf_clr_cmd;
  logic ev_c, ev_ce, ev_cs, ev_ci, ev_di, ev_vi, ev_da, ev_va, ev_sh, ev_su, ev_ss, ev_sr;

  hpc_cq_sched #(
    .ROB_DEPTH(ROB_DEPTH), .OPSET_FULL(OPSET_FULL), .OVERLAP_EN(OVERLAP_EN),
    .EXT_BASE(EXT_BASE), .EXT_LOG2(EXT_LOG2), .SPM_BASE(SPM_BASE), .SPM_LOG2(SPM_LOG2),
    .DMA_MAX_LEN_LOG2(DMA_MAX_LEN_LOG2), .VL_W(VL_W), .WDOG_LOG2(WDOG_LOG2)
  ) u_sched (
    .clk_i, .rst_ni,
    .q_valid_i(!q_empty), .q_entry_i(q_rdata), .q_pop_o(q_pop),
    .err_cont_i(ctrl_err_cont_i), .err_clear_i(ctrl_err_clear_i),
    .dma_start_o, .dma_abort_o, .dma_src_o, .dma_dst_o, .dma_len_o,
    .dma_busy_i, .dma_done_i, .dma_fail_i, .dma_err_code_i, .dma_err_addr_i,
    .dma_bytes_done_i, .dma_progress_i,
    .vec_start_o, .vec_op_o, .vec_rm_o, .vec_src_a_o, .vec_src_b_o, .vec_dst_o,
    .vec_vl_o, .vec_tid_o,
    .vec_busy_i, .vec_done_i, .vec_fail_i, .vec_err_code_i, .vec_err_addr_i,
    .vec_fflags_i, .vec_count_i, .vec_progress_i,
    .cpl_valid_o, .cpl_ready_i, .cpl_rec_o,
    .dec_valid_o(dec_v), .rob_count_o, .err_sticky_o, .dma_down_o, .vec_down_o,
    .perf_clear_o(perf_clr_cmd),
    .ev_commit_o(ev_c), .ev_commit_err_o(ev_ce), .ev_commit_skip_o(ev_cs), .ev_commit_irq_o(ev_ci),
    .ev_dma_issue_o(ev_di), .ev_vec_issue_o(ev_vi), .ev_dma_active_o(ev_da), .ev_vec_active_o(ev_va),
    .ev_stall_hazard_o(ev_sh), .ev_stall_unit_o(ev_su), .ev_stall_sync_o(ev_ss), .ev_stall_rob_o(ev_sr),
    .trc_resolve_o, .trc_seq_o, .trc_dma_seq_o, .trc_vec_seq_o
  );

  assign busy_o          = !q_empty || dec_v || (rob_count_o != '0);
  assign ev_commit_o     = ev_c;
  assign ev_commit_err_o = ev_ce || ev_cs;
  assign ev_commit_irq_o = ev_ci;
  assign trc_dma_act_o   = ev_da;
  assign trc_vec_act_o   = ev_va;

  // ================================================================ counters
  logic [hpc_cq_pkg::PC_N-1:0] inc;
  always_comb begin
    inc = '0;
    inc[hpc_cq_pkg::PC_CYCLES]       = 1'b1;
    inc[hpc_cq_pkg::PC_BUSY]         = busy_o;
    inc[hpc_cq_pkg::PC_CMD_IN]       = q_push;
    inc[hpc_cq_pkg::PC_CMD_COMMIT]   = ev_c;
    inc[hpc_cq_pkg::PC_CMD_ERR]      = ev_ce;
    inc[hpc_cq_pkg::PC_CMD_SKIP]     = ev_cs;
    inc[hpc_cq_pkg::PC_DMA_ISSUE]    = ev_di;
    inc[hpc_cq_pkg::PC_VEC_ISSUE]    = ev_vi;
    inc[hpc_cq_pkg::PC_DMA_ACTIVE]   = ev_da;
    inc[hpc_cq_pkg::PC_VEC_ACTIVE]   = ev_va;
    inc[hpc_cq_pkg::PC_OVERLAP]      = ev_da && ev_va;
    inc[hpc_cq_pkg::PC_STALL_HAZARD] = ev_sh;
    inc[hpc_cq_pkg::PC_STALL_UNIT]   = ev_su;
    inc[hpc_cq_pkg::PC_STALL_SYNC]   = ev_ss;
    inc[hpc_cq_pkg::PC_STALL_ROB]    = ev_sr;
    inc[hpc_cq_pkg::PC_Q_FULL]       = cmd_valid_i && !cmd_ready_o;
    inc[hpc_cq_pkg::PC_CPL_BP]       = cpl_valid_o && !cpl_ready_i;
  end

  hpc_cq_perf #(.NC(hpc_cq_pkg::PC_N), .CW(PERF_CW), .PERF_EN(PERF_EN)) u_perf (
    .clk_i, .rst_ni, .clear_i(ctrl_perf_clear_i || perf_clr_cmd), .inc_i(inc), .cnt_o(perf_cnt_o)
  );

`ifndef SYNTHESIS
  // ================================================================ checks
  logic          hold_q;
  logic [127:0]  hold_rec_q;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      hold_q <= 1'b0;
    end else begin
      // completion channel: valid held with a stable payload until taken
      if (hold_q && !cpl_valid_o)
        $error("hpc_command_queue: cpl_valid_o dropped before the record was taken");
      if (hold_q && cpl_valid_o && cpl_rec_o != hold_rec_q)
        $error("hpc_command_queue: cpl_rec_o changed while held");
      hold_q     <= cpl_valid_o && !cpl_ready_i;
      hold_rec_q <= cpl_rec_o;
      if (!cpl_valid_o && cpl_rec_o != 128'd0)
        $error("hpc_command_queue: cpl_rec_o not zero while cpl_valid_o = 0");
      if (q_push && q_full)
        $error("hpc_command_queue: command accepted while the queue is full");
    end
  end
`endif
endmodule

`default_nettype wire
