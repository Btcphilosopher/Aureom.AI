// =============================================================================
// SilicaFlux-HPC :: hpc_cq_pkg -- command-queue ABI, version 1
//
// Module 06 (hardware command queue and compute scheduler).  Stateless
// package: the versioned command-descriptor layout, opcode / flag / status /
// error encodings, the completion-record layout, the performance-counter map
// and pure helper functions shared by hpc_command_queue, its sub-blocks, the
// MMIO adapter and the testbench.
//
// This file is the RTL half of the ABI.  The C half is sw/hpc_cq_abi.h and
// the Python half is ref/hpc_cq_abi.py; scripts/check_abi.py proves that the
// three agree value-by-value (docs/01_COMMAND_ABI.md is the prose spec).
//
// Values are part of the public contract: never renumber, only append into
// reserved code points.  A layout change requires a new ABI version.
//
// Encodings reused unchanged from earlier modules:
//   * rounding modes  = hpc_vector_pkg::RM_*  (Module 02, RISC-V frm 0..4)
//   * FP flags        = hpc_vector_pkg FLAG_* ({NV,DZ,OF,UF,NX}, RISC-V order)
//   * DMA error codes = DataFabric dma_defs.svh DMA_ERR_* (embedded as
//                       ERR_DMA_BASE | code)
//
// Coding rules: SilicaFlux RTL subset (Verilator 5.020 / Icarus 12 /
// Yosys 0.33): no `import`, no `return`, no `inside`, no structs/unions,
// functions assign to their own name.
// =============================================================================
`default_nettype none

package hpc_cq_pkg;
  /* verilator lint_off UNUSEDPARAM */   // the ABI is published in full

  // ===========================================================================
  // ABI version carried in every descriptor (HDR.VERSION).
  // ===========================================================================
  localparam logic [3:0] ABI_VERSION = 4'd1;

  // ===========================================================================
  // Command descriptor: 256 bits = 8 little-endian 32-bit words.
  // Word w occupies bits [32*w+31 : 32*w] of cmd_desc_i (and byte offsets
  // 4w..4w+3 of a descriptor in memory).
  // ===========================================================================
  localparam int DESC_W     = 256;
  localparam int DESC_WORDS = 8;

  localparam int W_HDR    = 0;   // header (below)
  localparam int W_SRC_A  = 1;   // source A byte address
  localparam int W_SRC_B  = 2;   // source B byte address
  localparam int W_DST    = 3;   // destination byte address
  localparam int W_LEN    = 4;   // length: bytes (DMA) or FP32 elements (vector)
  localparam int W_STRIDE = 5;   // element stride; v1 accepts 0 (packed) only
  localparam int W_RSVD6  = 6;   // reserved, must be 0
  localparam int W_RSVD7  = 7;   // reserved, must be 0

  // Header word fields (bit positions inside word 0)
  localparam int H_OP_LSB    = 0;   localparam int H_OP_W    = 8;   // [7:0]   OPCODE
  localparam int H_VER_LSB   = 8;   localparam int H_VER_W   = 4;   // [11:8]  VERSION
  localparam int H_RM_LSB    = 12;  localparam int H_RM_W    = 3;   // [14:12] RM
  localparam int H_RSVD_BIT  = 15;                                  // [15]    reserved, 0
  localparam int H_FLAGS_LSB = 16;  localparam int H_FLAGS_W = 8;   // [23:16] FLAGS
  localparam int H_TID_LSB   = 24;  localparam int H_TID_W   = 8;   // [31:24] TID

  // The command FIFO stores words 0..5 plus one bit: OR of words 6 and 7
  // (they only ever need a must-be-zero check, so they are not stored).
  localparam int QE_W = 6 * 32 + 1;

  // ===========================================================================
  // Opcodes (HDR.OPCODE).  Every code point not listed is RESERVED and is
  // rejected with ERR_OPCODE.  Classes: 0x0X DMA, 0x1X vector, 0x2X sync,
  // 0x3X control.
  // ===========================================================================
  localparam logic [7:0] OP_NOP            = 8'h00;
  localparam logic [7:0] OP_DMA_LOAD       = 8'h01;  // external memory -> scratchpad
  localparam logic [7:0] OP_DMA_STORE      = 8'h02;  // scratchpad -> external memory
  //                                         8'h03 .. 8'h0F reserved
  localparam logic [7:0] OP_VECTOR_ADD     = 8'h10;  // D[i] = A[i] + B[i]
  localparam logic [7:0] OP_VECTOR_MUL     = 8'h11;  // D[i] = A[i] * B[i]
  localparam logic [7:0] OP_VECTOR_FMA     = 8'h12;  // D[i] = A[i] * B[i] + D[i] (one rounding)
  //                                         8'h13 .. 8'h1F reserved
  localparam logic [7:0] OP_FENCE          = 8'h20;
  //                                         8'h21 .. 8'h2F reserved
  localparam logic [7:0] OP_RESET_COUNTERS = 8'h30;
  //                                         8'h31 .. 8'hFF reserved

  // Execution classes (internal)
  localparam int CL_W     = 3;
  localparam logic [2:0] CL_NOP    = 3'd0;
  localparam logic [2:0] CL_DMA    = 3'd1;
  localparam logic [2:0] CL_VEC    = 3'd2;
  localparam logic [2:0] CL_FENCE  = 3'd3;
  localparam logic [2:0] CL_RSTCNT = 3'd4;
  localparam logic [2:0] CL_BAD    = 3'd7;

  // ===========================================================================
  // Flags (HDR.FLAGS).  Bits not listed are reserved: a set reserved bit is
  // rejected with ERR_FLAGS.
  // ===========================================================================
  localparam int FL_IRQ     = 0;   // raise the commit interrupt event for this command
  localparam int FL_BARRIER = 1;   // issue only after every older command has completed
  localparam logic [7:0] FLAGS_V1_MASK = 8'h03;

  // ===========================================================================
  // Completion record: 128 bits = 4 little-endian 32-bit words.
  // ===========================================================================
  localparam int REC_W = 128;
  // word 0
  localparam int R_TID_LSB    = 0;    // [7:0]   TID (echo)
  localparam int R_OP_LSB     = 8;    // [15:8]  OPCODE (echo, even if invalid)
  localparam int R_ERR_LSB    = 16;   // [23:16] ERR_CODE
  localparam int R_STATUS_LSB = 24;   // [25:24] STATUS
  localparam int R_IRQ_BIT    = 26;   // [26]    FL_IRQ echo
  localparam int R_FFLAGS_LSB = 27;   // [31:27] FFLAGS {NV,DZ,OF,UF,NX}: NX = bit 27, NV = bit 31
  // word 1: COUNT    bytes (DMA) / elements (vector) completed and acknowledged
  // word 2: ERR_ADDR failing bus address for bus errors, else 0
  // word 3: SEQ      command sequence number (0 = first command after reset)

  localparam logic [1:0] ST_OK      = 2'd0;
  localparam logic [1:0] ST_ERROR   = 2'd1;
  localparam logic [1:0] ST_SKIPPED = 2'd2;   // not executed: an older command failed

  // ===========================================================================
  // Error codes (record ERR_CODE).  0x01..0x0F: descriptor validation,
  // detected before any side effect; first failing rule wins in this order.
  // ===========================================================================
  localparam logic [7:0] ERR_NONE        = 8'h00;
  localparam logic [7:0] ERR_VERSION     = 8'h01;  // HDR.VERSION != ABI_VERSION
  localparam logic [7:0] ERR_OPCODE      = 8'h02;  // reserved / unsupported opcode
  localparam logic [7:0] ERR_FLAGS       = 8'h03;  // reserved flag bit set
  localparam logic [7:0] ERR_RSVD        = 8'h04;  // reserved bit/word or unused field non-zero
  localparam logic [7:0] ERR_STRIDE      = 8'h05;  // unsupported stride (v1: only 0)
  localparam logic [7:0] ERR_RM          = 8'h06;  // rounding mode 5..7 on a vector op
  localparam logic [7:0] ERR_LENGTH      = 8'h07;  // length 0 or above the maximum
  localparam logic [7:0] ERR_ALIGN       = 8'h08;  // address not 4-byte aligned
  localparam logic [7:0] ERR_RANGE       = 8'h09;  // range outside its window (or wraps)
  localparam logic [7:0] ERR_OVERLAP     = 8'h0A;  // destination partially overlaps a source
  // 0x10 | DataFabric DMA_ERR_* : the DMA engine reported a failure
  localparam logic [7:0] ERR_DMA_BASE    = 8'h10;
  localparam logic [7:0] ERR_DMA_READ    = 8'h18;  // 0x10 | DMA_ERR_READ_BUS
  localparam logic [7:0] ERR_DMA_WRITE   = 8'h19;  // 0x10 | DMA_ERR_WRITE_BUS
  localparam logic [7:0] ERR_DMA_ABORTED = 8'h1A;  // 0x10 | DMA_ERR_ABORTED
  // 0x20 | vector-executor code
  localparam logic [7:0] ERR_VEC_BASE    = 8'h20;
  localparam logic [7:0] ERR_VEC_READ    = 8'h21;  // scratchpad read response error
  localparam logic [7:0] ERR_VEC_WRITE   = 8'h22;  // scratchpad write response error
  localparam logic [7:0] ERR_VEC_ENGINE  = 8'h23;  // vector array completion inconsistent
  // resource failures
  localparam logic [7:0] ERR_TIMEOUT     = 8'h30;  // unit made no progress for 2^WDOG_LOG2 cycles
  localparam logic [7:0] ERR_UNIT_DOWN   = 8'h31;  // required unit quarantined after a timeout
  // error propagation (status SKIPPED)
  localparam logic [7:0] ERR_PRIOR       = 8'h40;  // skipped: sticky error from an older command

  // Vector-executor error codes (hpc_cq_vexec err_code_o, 4 bits)
  localparam logic [3:0] VX_ERR_NONE   = 4'd0;
  localparam logic [3:0] VX_ERR_READ   = 4'd1;
  localparam logic [3:0] VX_ERR_WRITE  = 4'd2;
  localparam logic [3:0] VX_ERR_ENGINE = 4'd3;

  // Vector-executor operations (hpc_cq_vexec op_i)
  localparam logic [1:0] VOP_ADD = 2'd0;
  localparam logic [1:0] VOP_MUL = 2'd1;
  localparam logic [1:0] VOP_FMA = 2'd2;

  // ===========================================================================
  // Performance counters (hpc_cq_perf, perf_cnt_o[i*CW +: CW]); saturating.
  // ===========================================================================
  localparam int PC_CYCLES       = 0;   // clock cycles since clear
  localparam int PC_BUSY         = 1;   // cycles with >= 1 command accepted and not handed over
  localparam int PC_CMD_IN       = 2;   // commands accepted (cmd handshake)
  localparam int PC_CMD_COMMIT   = 3;   // commands committed (in-order completion)
  localparam int PC_CMD_ERR      = 4;   // committed with STATUS = ERROR
  localparam int PC_CMD_SKIP     = 5;   // committed with STATUS = SKIPPED
  localparam int PC_DMA_ISSUE    = 6;   // jobs started on the DMA engine
  localparam int PC_VEC_ISSUE    = 7;   // jobs started on the vector executor
  localparam int PC_DMA_ACTIVE   = 8;   // cycles with a DMA job in flight
  localparam int PC_VEC_ACTIVE   = 9;   // cycles with a vector job in flight
  localparam int PC_OVERLAP      = 10;  // cycles with both in flight
  localparam int PC_STALL_HAZARD = 11;  // head blocked only by a memory dependency
  localparam int PC_STALL_UNIT   = 12;  // head blocked by its busy unit
  localparam int PC_STALL_SYNC   = 13;  // FENCE / BARRIER / RESET_COUNTERS waiting
  localparam int PC_STALL_ROB    = 14;  // head blocked: retirement buffer full
  localparam int PC_Q_FULL       = 15;  // cmd_valid_i && !cmd_ready_o
  localparam int PC_CPL_BP       = 16;  // completion record presented, not taken
  localparam int PC_N            = 17;

  // ===========================================================================
  // Helper functions (pure)
  // ===========================================================================

  // Word w of a descriptor / queue entry
  function automatic logic [31:0] dword(input logic [DESC_W-1:0] d, input int w);
    dword = d[32*w +: 32];
  endfunction

  // Opcode is implemented.  full = 0 restricts the set to the bring-up
  // subset {NOP, DMA_LOAD, VECTOR_ADD, FENCE} (OPSET_FULL = 0).
  function automatic logic op_supported(input logic [7:0] op, input logic full);
    case (op)
      OP_NOP, OP_DMA_LOAD, OP_VECTOR_ADD, OP_FENCE:      op_supported = 1'b1;
      OP_DMA_STORE, OP_VECTOR_MUL, OP_VECTOR_FMA,
      OP_RESET_COUNTERS:                                 op_supported = full;
      default:                                           op_supported = 1'b0;
    endcase
  endfunction

  function automatic logic [2:0] op_class(input logic [7:0] op);
    case (op)
      OP_NOP:                                    op_class = CL_NOP;
      OP_DMA_LOAD, OP_DMA_STORE:                 op_class = CL_DMA;
      OP_VECTOR_ADD, OP_VECTOR_MUL, OP_VECTOR_FMA: op_class = CL_VEC;
      OP_FENCE:                                  op_class = CL_FENCE;
      OP_RESET_COUNTERS:                         op_class = CL_RSTCNT;
      default:                                   op_class = CL_BAD;
    endcase
  endfunction

  // Flags each opcode accepts (all v1 opcodes accept IRQ and BARRIER).
  function automatic logic [7:0] flags_allowed(input logic [7:0] op);
    flags_allowed = (op_class(op) == CL_BAD) ? 8'h00 : FLAGS_V1_MASK;
  endfunction

  function automatic logic [1:0] vec_op(input logic [7:0] op);
    case (op)
      OP_VECTOR_MUL: vec_op = VOP_MUL;
      OP_VECTOR_FMA: vec_op = VOP_FMA;
      default:       vec_op = VOP_ADD;
    endcase
  endfunction

  // Half-open byte intervals [alo, ahi) and [blo, bhi) intersect.  An empty
  // interval (lo == hi) never intersects anything.
  function automatic logic isect(input logic [32:0] alo, input logic [32:0] ahi,
                                 input logic [32:0] blo, input logic [32:0] bhi);
    isect = (alo < bhi) && (blo < ahi) && (alo < ahi) && (blo < bhi);
  endfunction

  // [lo, lo+len) lies inside the window [base, base+size) and does not wrap.
  function automatic logic in_window(input logic [31:0] lo, input logic [32:0] len,
                                     input logic [32:0] base, input logic [32:0] size);
    logic [33:0] hi;
    hi        = {2'b00, lo} + {1'b0, len};
    in_window = ({1'b0, lo} >= base) && (hi <= ({1'b0, base} + {1'b0, size}));
  endfunction

  // Build a completion record word 0
  function automatic logic [31:0] rec_w0(input logic [7:0] tid, input logic [7:0] op,
                                         input logic [7:0] err, input logic [1:0] st,
                                         input logic irq, input logic [4:0] ff);
    rec_w0 = {ff, irq, st, err, op, tid};
  endfunction

  /* verilator lint_on UNUSEDPARAM */
endpackage
