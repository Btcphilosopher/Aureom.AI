// =============================================================================
// SilicaFlux-HPC :: hpc_cq_validate -- command-descriptor validation (ABI v1)
//
// Combinational.  Checks one queue entry (descriptor words 0..5 plus the OR
// of words 6/7) BEFORE anything is issued.  First failing rule wins, in the
// order of hpc_cq_pkg ERR_* codes 0x01..0x0A (docs/01_COMMAND_ABI.md sec. 6):
//
//   VERSION  HDR.VERSION != 1
//   OPCODE   reserved opcode, or not in the configured set (OPSET_FULL)
//   FLAGS    a flag bit outside flags_allowed(opcode)
//   RSVD     HDR bit 15, words 6/7, or a field the opcode does not use is != 0
//            (DMA: SRC_B, RM; NOP/FENCE/RESET_COUNTERS: every field)
//   STRIDE   DMA / vector op with STRIDE != 0 (v1 implements packed only)
//   RM       vector op with RM in 5..7
//   LENGTH   0, or DMA > 2^DMA_MAX_LEN_LOG2 bytes, or vector > 2^VL_W-1 elements
//   ALIGN    any used address not 4-byte aligned
//   RANGE    a used range leaves its window or wraps:
//              DMA_LOAD  : SRC_A..+LEN in EXT, DST..+LEN in SPM
//              DMA_STORE : SRC_A..+LEN in SPM, DST..+LEN in EXT
//              vector    : A, B, D ..+4*LEN all in SPM
//   OVERLAP  vector op whose destination range partially overlaps source A
//            or source B (identical or disjoint ranges are legal)
//
// The DMA rules are a strict superset of DataFabric dma_validate (zero
// length, maximum length, alignment, wrap, overlap - the windows are
// disjoint, so a DMA source can never overlap its destination); a valid
// command therefore never fails the engine's own start-time validation
// (asserted in hpc_cq_sched).
//
// Footprint outputs (meaningful when err_o == 0), 33-bit half-open byte
// intervals used for dependency checks; empty = [0, 0):
//   DMA    : rd = [SRC_A, SRC_A + roundup4(LEN))  (the engine reads the last
//            source word in full), wr = [DST, DST + LEN)  (strobed tail)
//   vector : rd = A range, rd2 = B range, wr = D range (FMA also reads D;
//            that read is covered by wr in every hazard check)
// =============================================================================
`default_nettype none

module hpc_cq_validate #(
  parameter bit          OPSET_FULL       = 1'b1,
  parameter logic [31:0] EXT_BASE         = 32'h1000_0000,
  parameter int          EXT_LOG2         = 17,
  parameter logic [31:0] SPM_BASE         = 32'h2000_0000,
  parameter int          SPM_LOG2         = 16,
  parameter int          DMA_MAX_LEN_LOG2 = 24,
  parameter int          VL_W             = 16
) (
  input  wire logic [hpc_cq_pkg::QE_W-1:0] entry_i,
  output logic [7:0]                       err_o,
  output logic [2:0]                       cls_o,
  output logic [32:0]                      rd_lo_o,
  output logic [32:0]                      rd_hi_o,
  output logic [32:0]                      rd2_lo_o,
  output logic [32:0]                      rd2_hi_o,
  output logic [32:0]                      wr_lo_o,
  output logic [32:0]                      wr_hi_o
);
  localparam logic [32:0] EXT_B = {1'b0, EXT_BASE};
  localparam logic [32:0] EXT_S = 33'd1 << EXT_LOG2;
  localparam logic [32:0] SPM_B = {1'b0, SPM_BASE};
  localparam logic [32:0] SPM_S = 33'd1 << SPM_LOG2;
  localparam logic [32:0] DMA_MAX = 33'd1 << DMA_MAX_LEN_LOG2;
  localparam logic [32:0] VL_MAX  = (33'd1 << VL_W) - 33'd1;

  // ------------------------------------------------------------- fields
  /* verilator lint_off UNUSEDSIGNAL */  // TID is not validated
  wire [31:0] w0  = entry_i[31:0];
  /* verilator lint_on UNUSEDSIGNAL */
  wire [31:0] sa  = entry_i[63:32];
  wire [31:0] sb  = entry_i[95:64];
  wire [31:0] da  = entry_i[127:96];
  wire [31:0] len = entry_i[159:128];
  wire [31:0] str = entry_i[191:160];
  wire        r67 = entry_i[192];

  wire [7:0] op    = w0[7:0];
  wire [3:0] ver   = w0[11:8];
  wire [2:0] rm    = w0[14:12];
  wire       r15   = w0[15];
  wire [7:0] flags = w0[23:16];

  wire [2:0] cls     = hpc_cq_pkg::op_class(op);
  wire       is_dma  = (cls == hpc_cq_pkg::CL_DMA);
  wire       is_vec  = (cls == hpc_cq_pkg::CL_VEC);
  wire       is_ctl  = (cls == hpc_cq_pkg::CL_NOP) || (cls == hpc_cq_pkg::CL_FENCE) ||
                       (cls == hpc_cq_pkg::CL_RSTCNT);
  wire       is_load = (op == hpc_cq_pkg::OP_DMA_LOAD);

  // vector byte length (only meaningful once LENGTH passed: len <= VL_MAX)
  wire [32:0] vbytes = {len[30:0], 2'b00};
  wire [32:0] dlen   = {1'b0, len};
  wire [32:0] dlen_r = ({1'b0, len} + 33'd3) & ~33'd3;   // rounded up to whole words

  // ------------------------------------------------------------- rules
  logic e_ver, e_op, e_flags, e_rsvd, e_stride, e_rm, e_len, e_align, e_range, e_ovl;

  // package function results as wires (Icarus 12 cannot apply ! / ~ to a call)
  wire       op_ok  = hpc_cq_pkg::op_supported(op, OPSET_FULL);
  wire [7:0] fl_ok  = hpc_cq_pkg::flags_allowed(op);
  wire       rm_ok  = hpc_vector_pkg::rm_legal(rm);

  always_comb begin
    e_ver    = (ver != hpc_cq_pkg::ABI_VERSION);
    e_op     = !op_ok;
    e_flags  = ((flags & ~fl_ok) != 8'h00);
    e_rsvd   = r15 || r67 ||
               (is_dma && ((sb != 32'd0) || (rm != 3'd0))) ||
               (is_ctl && ((sa != 32'd0) || (sb != 32'd0) || (da != 32'd0) ||
                           (len != 32'd0) || (str != 32'd0) || (rm != 3'd0)));
    e_stride = (is_dma || is_vec) && (str != 32'd0);
    e_rm     = is_vec && !rm_ok;
    e_len    = (is_dma && ((len == 32'd0) || (dlen > DMA_MAX))) ||
               (is_vec && ((len == 32'd0) || (dlen > VL_MAX)));
    e_align  = (is_dma && ((sa[1:0] != 2'b00) || (da[1:0] != 2'b00))) ||
               (is_vec && ((sa[1:0] != 2'b00) || (sb[1:0] != 2'b00) || (da[1:0] != 2'b00)));
    e_range  = 1'b0;
    if (is_dma) begin
      if (is_load)
        e_range = !hpc_cq_pkg::in_window(sa, dlen, EXT_B, EXT_S) ||
                  !hpc_cq_pkg::in_window(da, dlen, SPM_B, SPM_S);
      else
        e_range = !hpc_cq_pkg::in_window(sa, dlen, SPM_B, SPM_S) ||
                  !hpc_cq_pkg::in_window(da, dlen, EXT_B, EXT_S);
    end else if (is_vec) begin
      e_range = !hpc_cq_pkg::in_window(sa, vbytes, SPM_B, SPM_S) ||
                !hpc_cq_pkg::in_window(sb, vbytes, SPM_B, SPM_S) ||
                !hpc_cq_pkg::in_window(da, vbytes, SPM_B, SPM_S);
    end
    e_ovl    = is_vec &&
               (((da != sa) && hpc_cq_pkg::isect({1'b0, da}, {1'b0, da} + vbytes,
                                                 {1'b0, sa}, {1'b0, sa} + vbytes)) ||
                ((da != sb) && hpc_cq_pkg::isect({1'b0, da}, {1'b0, da} + vbytes,
                                                 {1'b0, sb}, {1'b0, sb} + vbytes)));

    // first failing rule wins
    if      (e_ver)    err_o = hpc_cq_pkg::ERR_VERSION;
    else if (e_op)     err_o = hpc_cq_pkg::ERR_OPCODE;
    else if (e_flags)  err_o = hpc_cq_pkg::ERR_FLAGS;
    else if (e_rsvd)   err_o = hpc_cq_pkg::ERR_RSVD;
    else if (e_stride) err_o = hpc_cq_pkg::ERR_STRIDE;
    else if (e_rm)     err_o = hpc_cq_pkg::ERR_RM;
    else if (e_len)    err_o = hpc_cq_pkg::ERR_LENGTH;
    else if (e_align)  err_o = hpc_cq_pkg::ERR_ALIGN;
    else if (e_range)  err_o = hpc_cq_pkg::ERR_RANGE;
    else if (e_ovl)    err_o = hpc_cq_pkg::ERR_OVERLAP;
    else               err_o = hpc_cq_pkg::ERR_NONE;
  end

  assign cls_o = cls;

  // ------------------------------------------------------------- footprints
  always_comb begin
    rd_lo_o  = 33'd0;  rd_hi_o  = 33'd0;
    rd2_lo_o = 33'd0;  rd2_hi_o = 33'd0;
    wr_lo_o  = 33'd0;  wr_hi_o  = 33'd0;
    if (is_dma) begin
      rd_lo_o = {1'b0, sa};  rd_hi_o = {1'b0, sa} + dlen_r;
      wr_lo_o = {1'b0, da};  wr_hi_o = {1'b0, da} + dlen;
    end else if (is_vec) begin
      rd_lo_o  = {1'b0, sa};  rd_hi_o  = {1'b0, sa} + vbytes;
      rd2_lo_o = {1'b0, sb};  rd2_hi_o = {1'b0, sb} + vbytes;
      wr_lo_o  = {1'b0, da};  wr_hi_o  = {1'b0, da} + vbytes;
    end
  end
endmodule

`default_nettype wire
