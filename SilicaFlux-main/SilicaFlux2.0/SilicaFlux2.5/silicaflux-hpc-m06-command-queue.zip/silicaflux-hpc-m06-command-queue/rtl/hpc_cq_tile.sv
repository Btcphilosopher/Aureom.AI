// =============================================================================
// SilicaFlux-HPC :: hpc_cq_tile -- compute-tile control plane integration
//
// The command queue wired to the real execution hardware (all reused
// unmodified; third_party/ + SHA256SUMS):
//
//            cmd / cpl streams (hpc_command_queue)
//                    |
//      +-------------+---------------------------+
//      | DMA control                             | vector-job control
//      v                                         v
//   dma_transfer_engine (DataFabric)        hpc_cq_vexec ---cmd/opnd/res/cpl---> hpc_vector_array (M03)
//      | SFB2 master                             | N lane ports
//      v                                         v
//   sfb_crossbar (DataFabric) 2 x 2        hpc_scratchpad (M04), ports 0..N-1 = lanes,
//      m0 = host port (CPU data / debug)          port N = crossbar slave 1 (SFB2, Module 04 doc 08)
//      m1 = DMA engine
//      s0 = EXT window  -> ext_* SFB2 master port (external memory / DataFabric)
//      s1 = SPM window  -> hpc_scratchpad port N
//
// * DMA_LOAD / DMA_STORE copy between the EXT and SPM windows through the
//   crossbar; SFB2 R7 + scratchpad WRITE_ACK = 1 make the engine's `done`
//   imply that every destination write has been performed.
// * The host port reaches both windows (e.g. CPU loads/stores to the
//   scratchpad); it competes fairly (round robin) with the DMA engine.
// * SPM_PHYS_LOG2 < SPM_LOG2 is a fault-injection configuration: the queue
//   believes in a larger window than the scratchpad implements, so accesses
//   above the physical capacity get scratchpad RANGE errors (used by the
//   regression to exercise the DMA / vector bus-error paths end to end).
// * Single clock, one asynchronous active-low reset shared by every block.
// =============================================================================
`include "hpc_spm_defs.svh"
`default_nettype none

module hpc_cq_tile #(
  parameter int          QUEUE_DEPTH      = 8,
  parameter int          ROB_DEPTH        = 8,
  parameter bit          OPSET_FULL       = 1'b1,
  parameter bit          OVERLAP_EN       = 1'b1,
  parameter int          NUM_LANES        = 2,
  parameter logic [31:0] EXT_BASE         = 32'h1000_0000,
  parameter int          EXT_LOG2         = 17,
  parameter logic [31:0] SPM_BASE         = 32'h2000_0000,
  parameter int          SPM_LOG2         = 16,
  parameter int          SPM_PHYS_LOG2    = 16,
  parameter int          SPM_BANKS        = 4,
  parameter int          SPM_READ_LATENCY = 1,
  parameter int          SPM_BACKEND      = 0,       // `SRAM_BACKEND_GENERIC
  parameter int          DMA_MAX_LEN_LOG2 = 24,
  parameter int          WDOG_LOG2        = 16,
  parameter bit          PERF_EN          = 1'b1,
  parameter int          PERF_CW          = 32,
  parameter int          VX_OPQ_DEPTH     = 4,
  parameter int          VX_WBQ_DEPTH     = 4,
  localparam int         N                = NUM_LANES,
  localparam int         VL_W             = 16,
  localparam int         QCW              = $clog2(QUEUE_DEPTH + 1),
  localparam int         RCW              = $clog2(ROB_DEPTH + 1)
) (
  input  wire logic                                  clk_i,
  input  wire logic                                  rst_ni,
  // ---------------------------------------------------------------- command queue streams
  input  wire logic                                  cmd_valid_i,
  output logic                                       cmd_ready_o,
  input  wire logic [255:0]                          cmd_desc_i,
  output logic                                       cpl_valid_o,
  input  wire logic                                  cpl_ready_i,
  output logic [127:0]                               cpl_rec_o,
  input  wire logic                                  ctrl_err_cont_i,
  input  wire logic                                  ctrl_err_clear_i,
  input  wire logic                                  ctrl_perf_clear_i,
  // ---------------------------------------------------------------- status / events / counters
  output logic                                       busy_o,
  output logic [QCW-1:0]                             q_count_o,
  output logic                                       q_full_o,
  output logic                                       q_empty_o,
  output logic [RCW-1:0]                             rob_count_o,
  output logic                                       err_sticky_o,
  output logic                                       dma_down_o,
  output logic                                       vec_down_o,
  output logic                                       ev_commit_o,
  output logic                                       ev_commit_err_o,
  output logic                                       ev_commit_irq_o,
  output logic [hpc_cq_pkg::PC_N*PERF_CW-1:0]        perf_cnt_o,
  // ---------------------------------------------------------------- host SFB2 slave port (crossbar master 0)
  input  wire logic                                  host_req_valid_i,
  output logic                                       host_req_ready_o,
  input  wire logic                                  host_req_write_i,
  input  wire logic [31:0]                           host_req_addr_i,
  input  wire logic [31:0]                           host_req_wdata_i,
  input  wire logic [3:0]                            host_req_wstrb_i,
  output logic                                       host_rsp_valid_o,
  input  wire logic                                  host_rsp_ready_i,
  output logic [31:0]                                host_rsp_rdata_o,
  output logic                                       host_rsp_error_o,
  // ---------------------------------------------------------------- external memory SFB2 master port (crossbar slave 0)
  output logic                                       ext_req_valid_o,
  input  wire logic                                  ext_req_ready_i,
  output logic                                       ext_req_write_o,
  output logic [31:0]                                ext_req_addr_o,
  output logic [31:0]                                ext_req_wdata_o,
  output logic [3:0]                                 ext_req_wstrb_o,
  input  wire logic                                  ext_rsp_valid_i,
  output logic                                       ext_rsp_ready_o,
  input  wire logic [31:0]                           ext_rsp_rdata_i,
  input  wire logic                                  ext_rsp_error_i,
  // ---------------------------------------------------------------- stress / observability
  input  wire logic [N-1:0]                          lane_hold_i,   // Module 03 per-lane hold, tie 0
  output logic                                       trc_resolve_o,
  output logic [31:0]                                trc_seq_o,
  output logic                                       trc_dma_act_o,
  output logic [31:0]                                trc_dma_seq_o,
  output logic                                       trc_vec_act_o,
  output logic [31:0]                                trc_vec_seq_o
);
  if (SPM_PHYS_LOG2 > SPM_LOG2) begin : g_bad_phys
    hpc_param_error_SPM_PHYS_LOG2_above_SPM_LOG2 u_err ();
  end

  // ================================================================ command queue
  logic        dma_start, dma_abort, dma_busy, dma_done, dma_fail, dma_progress;
  logic [31:0] dma_src, dma_dst, dma_len, dma_err_addr, dma_bytes_done;
  logic [3:0]  dma_err_code;
  logic        vec_start, vec_busy, vec_done, vec_fail, vec_progress;
  logic [1:0]  vec_op;
  logic [2:0]  vec_rm;
  logic [31:0] vec_a, vec_b, vec_d, vec_err_addr, vec_count;
  logic [VL_W-1:0] vec_vl;
  logic [7:0]  vec_tid;
  logic [3:0]  vec_err_code;
  logic [4:0]  vec_fflags;

  hpc_command_queue #(
    .QUEUE_DEPTH(QUEUE_DEPTH), .ROB_DEPTH(ROB_DEPTH), .OPSET_FULL(OPSET_FULL),
    .OVERLAP_EN(OVERLAP_EN), .EXT_BASE(EXT_BASE), .EXT_LOG2(EXT_LOG2),
    .SPM_BASE(SPM_BASE), .SPM_LOG2(SPM_LOG2), .DMA_MAX_LEN_LOG2(DMA_MAX_LEN_LOG2),
    .VL_W(VL_W), .WDOG_LOG2(WDOG_LOG2), .PERF_EN(PERF_EN), .PERF_CW(PERF_CW)
  ) u_cq (
    .clk_i, .rst_ni,
    .cmd_valid_i, .cmd_ready_o, .cmd_desc_i,
    .cpl_valid_o, .cpl_ready_i, .cpl_rec_o,
    .ctrl_err_cont_i, .ctrl_err_clear_i, .ctrl_perf_clear_i,
    .dma_start_o(dma_start), .dma_abort_o(dma_abort), .dma_src_o(dma_src), .dma_dst_o(dma_dst),
    .dma_len_o(dma_len), .dma_busy_i(dma_busy), .dma_done_i(dma_done), .dma_fail_i(dma_fail),
    .dma_err_code_i(dma_err_code), .dma_err_addr_i(dma_err_addr),
    .dma_bytes_done_i(dma_bytes_done), .dma_progress_i(dma_progress),
    .vec_start_o(vec_start), .vec_op_o(vec_op), .vec_rm_o(vec_rm), .vec_src_a_o(vec_a),
    .vec_src_b_o(vec_b), .vec_dst_o(vec_d), .vec_vl_o(vec_vl), .vec_tid_o(vec_tid),
    .vec_busy_i(vec_busy), .vec_done_i(vec_done), .vec_fail_i(vec_fail),
    .vec_err_code_i(vec_err_code), .vec_err_addr_i(vec_err_addr), .vec_fflags_i(vec_fflags),
    .vec_count_i(vec_count), .vec_progress_i(vec_progress),
    .busy_o, .q_count_o, .q_full_o, .q_empty_o, .rob_count_o, .err_sticky_o,
    .dma_down_o, .vec_down_o, .ev_commit_o, .ev_commit_err_o, .ev_commit_irq_o,
    .perf_cnt_o,
    .trc_resolve_o, .trc_seq_o, .trc_dma_act_o, .trc_dma_seq_o, .trc_vec_act_o, .trc_vec_seq_o
  );

  // ================================================================ DMA engine (DataFabric, unmodified)
  logic        dm_req_valid, dm_req_ready, dm_req_write, dm_rsp_valid, dm_rsp_ready, dm_rsp_error;
  logic [31:0] dm_req_addr, dm_req_wdata, dm_rsp_rdata;
  logic [3:0]  dm_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */  // observability outputs of reused blocks, unused here
  logic [2:0]  dma_state;
  logic        dma_ev_stall;
  /* verilator lint_on UNUSEDSIGNAL */

  dma_transfer_engine #(.DW(32), .MAX_LEN_LOG2(DMA_MAX_LEN_LOG2)) u_dma (
    .clk(clk_i), .rst_n(rst_ni),
    .start(dma_start), .abort(dma_abort), .cfg_src(dma_src), .cfg_dst(dma_dst), .cfg_len(dma_len),
    .busy(dma_busy), .done(dma_done), .fail(dma_fail), .err_code(dma_err_code),
    .err_addr(dma_err_addr), .bytes_done(dma_bytes_done), .state(dma_state), .ev_stall(dma_ev_stall),
    .req_valid(dm_req_valid), .req_ready(dm_req_ready), .req_write(dm_req_write),
    .req_addr(dm_req_addr), .req_wdata(dm_req_wdata), .req_wstrb(dm_req_wstrb),
    .rsp_valid(dm_rsp_valid), .rsp_ready(dm_rsp_ready), .rsp_rdata(dm_rsp_rdata),
    .rsp_error(dm_rsp_error)
  );
  assign dma_progress = (dm_req_valid && dm_req_ready) || (dm_rsp_valid && dm_rsp_ready);

  // ================================================================ crossbar (DataFabric, unmodified)
  localparam logic [31:0] EXT_MASK = ~((32'd1 << EXT_LOG2) - 32'd1);
  localparam logic [31:0] SPM_MASK = ~((32'd1 << SPM_LOG2) - 32'd1);

  logic [1:0]  xs_req_valid, xs_req_ready, xs_req_write, xs_rsp_valid, xs_rsp_ready, xs_rsp_error;
  logic [63:0] xs_req_addr, xs_req_wdata, xs_rsp_rdata;
  logic [7:0]  xs_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        x_err_evt, x_err_write;
  logic [31:0] x_err_addr;
  logic        x_err_master;
  logic [1:0]  x_ev_acc, x_ev_stall, x_ev_loss, x_ev_rstall;
  /* verilator lint_on UNUSEDSIGNAL */

  sfb_crossbar #(
    .NM(2), .NS(2), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE({SPM_BASE, EXT_BASE}), .SLV_MASK({SPM_MASK, EXT_MASK}), .MST_SLV_EN(4'b1111)
  ) u_xbar (
    .clk(clk_i), .rst_n(rst_ni),
    .m_req_valid({dm_req_valid, host_req_valid_i}),
    .m_req_ready({dm_req_ready, host_req_ready_o}),
    .m_req_write({dm_req_write, host_req_write_i}),
    .m_req_addr ({dm_req_addr,  host_req_addr_i}),
    .m_req_wdata({dm_req_wdata, host_req_wdata_i}),
    .m_req_wstrb({dm_req_wstrb, host_req_wstrb_i}),
    .m_rsp_valid({dm_rsp_valid, host_rsp_valid_o}),
    .m_rsp_ready({dm_rsp_ready, host_rsp_ready_i}),
    .m_rsp_rdata({dm_rsp_rdata, host_rsp_rdata_o}),
    .m_rsp_error({dm_rsp_error, host_rsp_error_o}),
    .s_req_valid(xs_req_valid), .s_req_ready(xs_req_ready), .s_req_write(xs_req_write),
    .s_req_addr(xs_req_addr), .s_req_wdata(xs_req_wdata), .s_req_wstrb(xs_req_wstrb),
    .s_rsp_valid(xs_rsp_valid), .s_rsp_ready(xs_rsp_ready), .s_rsp_rdata(xs_rsp_rdata),
    .s_rsp_error(xs_rsp_error),
    .err_evt(x_err_evt), .err_addr(x_err_addr), .err_master(x_err_master), .err_write(x_err_write),
    .ev_req_accept(x_ev_acc), .ev_req_stall(x_ev_stall), .ev_arb_loss(x_ev_loss), .ev_rsp_stall(x_ev_rstall)
  );

  // slave 0 -> external port
  assign ext_req_valid_o = xs_req_valid[0];
  assign xs_req_ready[0] = ext_req_ready_i;
  assign ext_req_write_o = xs_req_write[0];
  assign ext_req_addr_o  = xs_req_addr[31:0];
  assign ext_req_wdata_o = xs_req_wdata[31:0];
  assign ext_req_wstrb_o = xs_req_wstrb[3:0];
  assign xs_rsp_valid[0] = ext_rsp_valid_i;
  assign ext_rsp_ready_o = xs_rsp_ready[0];
  assign xs_rsp_rdata[31:0] = ext_rsp_rdata_i;
  assign xs_rsp_error[0] = ext_rsp_error_i;

  // ================================================================ scratchpad (Module 04, unmodified)
  localparam int NP = N + 1;
  /* verilator lint_off UNUSEDSIGNAL */  // write flag / tag / code of the SFB2 port, ECC syndrome: unused
  logic [NP-1:0]      sp_req_valid, sp_req_ready, sp_req_we, sp_rsp_valid, sp_rsp_ready, sp_rsp_err, sp_rsp_we;
  logic [NP*32-1:0]   sp_req_addr, sp_req_wdata, sp_rsp_rdata;
  logic [NP*4-1:0]    sp_req_wstrb, sp_ecc_syn;
  logic [NP*8-1:0]    sp_req_tag, sp_rsp_tag;
  logic [NP*3-1:0]    sp_rsp_err_code;
  /* verilator lint_on UNUSEDSIGNAL */

  // port N: crossbar slave 1 (SFB2 -> scratchpad port, Module 04 doc 08 sec. 1)
  assign sp_req_valid[N]          = xs_req_valid[1];
  assign xs_req_ready[1]          = sp_req_ready[N];
  assign sp_req_we[N]             = xs_req_write[1];
  assign sp_req_addr[N*32 +: 32]  = xs_req_addr[63:32];
  assign sp_req_wdata[N*32 +: 32] = xs_req_wdata[63:32];
  assign sp_req_wstrb[N*4 +: 4]   = xs_req_wstrb[7:4];
  assign sp_req_tag[N*8 +: 8]     = 8'd0;                    // SFB2 rev 2.0 has no IDs; in order
  assign xs_rsp_valid[1]          = sp_rsp_valid[N];
  assign sp_rsp_ready[N]          = xs_rsp_ready[1];
  assign xs_rsp_rdata[63:32]      = sp_rsp_rdata[N*32 +: 32]; // 0 on errors (SFB2 R8)
  assign xs_rsp_error[1]          = sp_rsp_err[N];

  /* verilator lint_off UNUSEDSIGNAL */  // scratchpad events / counters (PERF_EN = 0): unused
  logic [NP-1:0] ev_acc, ev_iss, ev_cfl, ev_cst, ev_err, ev_ecc;
  logic [SPM_BANKS*2-1:0] ev_bops;
  logic [SPM_BANKS-1:0]   ev_bcfl;
  logic [31:0] pc_cycles, pc_ecc;
  logic [NP*32-1:0] pc_acc, pc_iss, pc_cpl, pc_cfl, pc_wait, pc_err;
  logic [SPM_BANKS*32-1:0] pc_bops;
  logic sp_busy;
  /* verilator lint_on UNUSEDSIGNAL */

  hpc_scratchpad #(
    .NUM_PORTS(NP), .CAPACITY_BYTES(1 << SPM_PHYS_LOG2), .NUM_BANKS(SPM_BANKS), .DATA_WIDTH(32),
    .ADDR_WIDTH(32), .BASE_ADDR({32'd0, SPM_BASE}), .READ_LATENCY(SPM_READ_LATENCY), .BYTE_WE(1),
    .PORT_MODE(`HPC_SPM_PORT_1RW), .MAP(`HPC_SPM_MAP_LOW), .ARB(`HPC_SPM_ARB_RR), .QUEUE_DEPTH(0),
    .RSP_FIFO_DEPTH(SPM_READ_LATENCY + 1), .WRITE_ACK(1), .TAG_W(8), .ECC_MODE(`HPC_SPM_ECC_NONE),
    .BACKEND(SPM_BACKEND), .MACRO(0), .PERF_EN(0), .CNT_W(32)
  ) u_spm (
    .clk(clk_i), .rst_n(rst_ni),
    .req_valid(sp_req_valid), .req_ready(sp_req_ready), .req_we(sp_req_we), .req_addr(sp_req_addr),
    .req_wdata(sp_req_wdata), .req_wstrb(sp_req_wstrb), .req_tag(sp_req_tag),
    .rsp_valid(sp_rsp_valid), .rsp_ready(sp_rsp_ready), .rsp_rdata(sp_rsp_rdata), .rsp_err(sp_rsp_err),
    .rsp_err_code(sp_rsp_err_code), .rsp_we(sp_rsp_we), .rsp_tag(sp_rsp_tag), .rsp_ecc_syn(sp_ecc_syn),
    .ev_accept(ev_acc), .ev_issue(ev_iss), .ev_conflict(ev_cfl), .ev_credit_stall(ev_cst),
    .ev_error(ev_err), .ev_ecc_err(ev_ecc), .ev_bank_ops(ev_bops), .ev_bank_conflict(ev_bcfl),
    .perf_clear(1'b0), .perf_cycles(pc_cycles), .perf_accept(pc_acc), .perf_issue(pc_iss),
    .perf_complete(pc_cpl), .perf_conflict(pc_cfl), .perf_wait(pc_wait), .perf_error(pc_err),
    .perf_bank_ops(pc_bops), .perf_ecc_err(pc_ecc), .busy(sp_busy)
  );

  // ================================================================ vector executor
  logic            va_cmd_valid, va_cmd_ready, va_opnd_valid, va_opnd_ready;
  logic            va_res_valid, va_res_ready, va_res_last, va_cpl_valid, va_cpl_ready;
  logic            va_cpl_illegal;
  /* verilator lint_off UNUSEDSIGNAL */  // array outputs the executor does not need
  logic            va_cpl_red;
  logic [VL_W-1:0] va_res_beat;
  logic [7:0]      va_res_tid, va_cpl_tid;
  logic [N*5-1:0]  va_res_flags;
  logic [31:0]     va_cpl_result;
  logic            va_busy;
  logic [hpc_varray_pkg::PC_N*32-1:0] va_perf;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [4:0]      va_cmd_op, va_cpl_flags;
  logic [2:0]      va_cmd_rm;
  logic [VL_W-1:0] va_cmd_vl, va_cpl_count;
  logic [7:0]      va_cmd_tid;
  logic [N*32-1:0] va_a, va_b, va_c, va_res_data;
  logic [N-1:0]    va_res_mask;

  hpc_cq_vexec #(.N(N), .VL_W(VL_W), .TAG_W(8), .OPQ_DEPTH(VX_OPQ_DEPTH), .WBQ_DEPTH(VX_WBQ_DEPTH)) u_vx (
    .clk_i, .rst_ni,
    .start_i(vec_start), .op_i(vec_op), .rm_i(vec_rm), .src_a_i(vec_a), .src_b_i(vec_b),
    .dst_i(vec_d), .vl_i(vec_vl), .tid_i(vec_tid),
    .busy_o(vec_busy), .done_o(vec_done), .fail_o(vec_fail), .err_code_o(vec_err_code),
    .err_addr_o(vec_err_addr), .fflags_o(vec_fflags), .count_o(vec_count), .progress_o(vec_progress),
    .va_cmd_valid_o(va_cmd_valid), .va_cmd_ready_i(va_cmd_ready), .va_cmd_op_o(va_cmd_op),
    .va_cmd_rm_o(va_cmd_rm), .va_cmd_vl_o(va_cmd_vl), .va_cmd_tid_o(va_cmd_tid),
    .va_opnd_valid_o(va_opnd_valid), .va_opnd_ready_i(va_opnd_ready),
    .va_opnd_a_o(va_a), .va_opnd_b_o(va_b), .va_opnd_c_o(va_c),
    .va_res_valid_i(va_res_valid), .va_res_ready_o(va_res_ready), .va_res_data_i(va_res_data),
    .va_res_mask_i(va_res_mask), .va_res_last_i(va_res_last),
    .va_cpl_valid_i(va_cpl_valid), .va_cpl_ready_o(va_cpl_ready), .va_cpl_flags_i(va_cpl_flags),
    .va_cpl_illegal_i(va_cpl_illegal), .va_cpl_count_i(va_cpl_count),
    .sp_req_valid_o(sp_req_valid[N-1:0]), .sp_req_ready_i(sp_req_ready[N-1:0]),
    .sp_req_we_o(sp_req_we[N-1:0]), .sp_req_addr_o(sp_req_addr[N*32-1:0]),
    .sp_req_wdata_o(sp_req_wdata[N*32-1:0]), .sp_req_wstrb_o(sp_req_wstrb[N*4-1:0]),
    .sp_req_tag_o(sp_req_tag[N*8-1:0]),
    .sp_rsp_valid_i(sp_rsp_valid[N-1:0]), .sp_rsp_ready_o(sp_rsp_ready[N-1:0]),
    .sp_rsp_rdata_i(sp_rsp_rdata[N*32-1:0]), .sp_rsp_err_i(sp_rsp_err[N-1:0]),
    .sp_rsp_we_i(sp_rsp_we[N-1:0]), .sp_rsp_tag_i(sp_rsp_tag[N*8-1:0])
  );

  // ================================================================ vector array (Module 03, unmodified)

  hpc_vector_array #(
    .NUM_LANES(N), .VL_W(VL_W), .TID_W(8), .CMD_DEPTH(2), .TRK_DEPTH(8), .CPL_DEPTH(2),
    .RED_EN(1'b0), .PERF_EN(1'b0), .PERF_CW(32),
    .EN_FCMP(1'b0), .EN_INT(1'b0)
  ) u_va (
    .clk_i, .rst_ni,
    .cmd_valid_i(va_cmd_valid), .cmd_ready_o(va_cmd_ready), .cmd_op_i(va_cmd_op), .cmd_rm_i(va_cmd_rm),
    .cmd_vl_i(va_cmd_vl), .cmd_vm_i(1'b0), .cmd_bcast_i(3'b000), .cmd_scalar_i(32'd0),
    .cmd_red_i(1'b0), .cmd_tid_i(va_cmd_tid),
    .opnd_valid_i(va_opnd_valid), .opnd_ready_o(va_opnd_ready),
    .opnd_a_i(va_a), .opnd_b_i(va_b), .opnd_c_i(va_c), .opnd_mask_i({N{1'b1}}),
    .res_valid_o(va_res_valid), .res_ready_i(va_res_ready), .res_data_o(va_res_data),
    .res_flags_o(va_res_flags), .res_mask_o(va_res_mask), .res_tid_o(va_res_tid),
    .res_beat_o(va_res_beat), .res_last_o(va_res_last),
    .cpl_valid_o(va_cpl_valid), .cpl_ready_i(va_cpl_ready), .cpl_tid_o(va_cpl_tid),
    .cpl_flags_o(va_cpl_flags), .cpl_illegal_o(va_cpl_illegal), .cpl_count_o(va_cpl_count),
    .cpl_red_o(va_cpl_red), .cpl_result_o(va_cpl_result),
    .lane_hold_i, .busy_o(va_busy), .perf_clear_i(1'b0), .perf_cnt_o(va_perf)
  );
endmodule

`default_nettype wire
