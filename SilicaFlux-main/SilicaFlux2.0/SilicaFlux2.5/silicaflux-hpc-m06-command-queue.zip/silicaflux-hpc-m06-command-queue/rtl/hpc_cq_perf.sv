// =============================================================================
// SilicaFlux-HPC :: hpc_cq_perf -- command-queue performance counters
//
// NC saturating counters of CW bits (map: hpc_cq_pkg::PC_*), one increment
// bit each per cycle, exposed as one flat read-only vector.  Same house
// pattern as hpc_varray_perf (Module 03) / sfb_perf_counters (DataFabric):
// counters saturate at all-ones (no silent wrap), clear_i zeroes them
// synchronously (clear wins over a same-cycle increment).  PERF_EN = 0
// removes the counters (outputs 0).
// =============================================================================
`default_nettype none

module hpc_cq_perf #(
  parameter int NC      = 17,
  parameter int CW      = 32,
  parameter bit PERF_EN = 1'b1
) (
  input  wire logic           clk_i,
  input  wire logic           rst_ni,
  input  wire logic           clear_i,
  input  wire logic [NC-1:0]  inc_i,
  output logic [NC*CW-1:0]    cnt_o
);
  if (PERF_EN) begin : g_on
    for (genvar i = 0; i < NC; i++) begin : g_cnt
      logic [CW-1:0] c_q;
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni)                         c_q <= '0;
        else if (clear_i)                    c_q <= '0;
        else if (inc_i[i] && (c_q != '1))    c_q <= c_q + CW'(1);
      end
      assign cnt_o[i*CW +: CW] = c_q;
    end
  end else begin : g_off
    assign cnt_o = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused = ^{clk_i, rst_ni, clear_i, inc_i};
    /* verilator lint_on UNUSEDSIGNAL */
  end
endmodule

`default_nettype wire
