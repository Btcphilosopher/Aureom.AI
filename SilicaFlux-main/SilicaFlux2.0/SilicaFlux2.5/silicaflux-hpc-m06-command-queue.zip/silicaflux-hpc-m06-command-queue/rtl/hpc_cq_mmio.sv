// =============================================================================
// SilicaFlux-HPC :: hpc_cq_mmio -- memory-mapped register adapter for the
// command queue
//
// The command queue's native host interface is the ready/valid command /
// completion stream of hpc_command_queue.  This block is a thin ADAPTER onto
// that stream for a CPU on the SilicaFlux-V register bus (sfv_periph_bridge
// page, same bus contract as DataFabric dma_control_regs): rb_sel one-cycle
// strobe, rb_we, rb_addr[11:0], rb_wdata; rb_rdata / rb_err answered
// combinationally in the strobe cycle; side effects at the end of it.
//
//   0x000 ID          RO   0x5346_4351 ("SFCQ")
//   0x004 INFO        RO   [3:0] ABI version, [15:8] QUEUE_DEPTH, [23:16] ROB_DEPTH,
//                          [24] OPSET_FULL, [25] OVERLAP_EN, [26] PERF_EN
//   0x008 CTRL        RW   [0] ERR_CONT (0 stop-on-error, 1 continue)
//                          [1] ERR_CLEAR  (write 1: clear the sticky error; reads 0)
//                          [2] PERF_CLEAR (write 1: clear the counters; reads 0)
//   0x00C STATUS      RO   [0] BUSY [1] ERR_STICKY [2] Q_FULL [3] Q_EMPTY [4] CPL_VALID
//                          [5] DMA_DOWN [6] VEC_DOWN [15:8] Q_COUNT [23:16] ROB_COUNT
//                          [31:24] Q_FREE (doorbells that will be accepted now)
//   0x010 INT_ENABLE  RW   [0] IRQ (an FL_IRQ command committed) [1] ERR (ERROR/SKIPPED committed)
//   0x014 INT_STATUS  W1C  same bits; set by the event (set wins over a same-cycle clear)
//   0x018 SUBMITTED   RO   doorbells accepted since reset (= SEQ of the next command when
//                          this adapter is the queue's only submitter)
//   0x020..0x03C DESC0..DESC7  RW  descriptor staging words 0..7
//   0x040 DOORBELL    WO   submit the staged descriptor (one cmd handshake).
//                          Queue full: refused with rb_err = 1, nothing submitted.
//   0x050..0x05C CPL0..CPL3    RO  head completion record words (0 if none)
//   0x060 CPL_POP     WO   release the head record; rb_err = 1 if there is none
//   0x080 + 4*i PERF[i] RO  counter i (hpc_cq_pkg::PC_*), i < PC_N
//
// Writes to RO registers, reads of nothing and unmapped offsets return
// rb_err = 1 with no effect; reads have no side effects (DOORBELL / CPL_POP
// read as 0).  irq_o = |(INT_STATUS & INT_ENABLE), level.
//
// Ordering: a DOORBELL that returns without error has submitted exactly one
// command; the command's record will carry SEQ = SUBMITTED-before-the-write.
// =============================================================================
`default_nettype none

module hpc_cq_mmio #(
  parameter int QUEUE_DEPTH = 8,
  parameter int ROB_DEPTH   = 8,
  parameter bit OPSET_FULL  = 1'b1,
  parameter bit OVERLAP_EN  = 1'b1,
  parameter bit PERF_EN     = 1'b1,
  parameter int PERF_CW     = 32,
  localparam int QCW        = $clog2(QUEUE_DEPTH + 1),
  localparam int RCW        = $clog2(ROB_DEPTH + 1)
) (
  input  wire logic                               clk_i,
  input  wire logic                               rst_ni,
  // ---------------------------------------------------------------- register bus slave
  input  wire logic                               rb_sel,
  input  wire logic                               rb_we,
  input  wire logic [11:0]                        rb_addr,
  input  wire logic [31:0]                        rb_wdata,
  output logic [31:0]                             rb_rdata,
  output logic                                    rb_err,
  output logic                                    irq_o,
  // ---------------------------------------------------------------- command queue stream side
  output logic                                    cmd_valid_o,
  input  wire logic                               cmd_ready_i,
  output logic [255:0]                            cmd_desc_o,
  input  wire logic                               cpl_valid_i,
  output logic                                    cpl_ready_o,
  input  wire logic [127:0]                       cpl_rec_i,
  output logic                                    ctrl_err_cont_o,
  output logic                                    ctrl_err_clear_o,
  output logic                                    ctrl_perf_clear_o,
  // ---------------------------------------------------------------- status / events
  input  wire logic                               busy_i,
  input  wire logic [QCW-1:0]                     q_count_i,
  input  wire logic                               q_full_i,
  input  wire logic                               q_empty_i,
  input  wire logic [RCW-1:0]                     rob_count_i,
  input  wire logic                               err_sticky_i,
  input  wire logic                               dma_down_i,
  input  wire logic                               vec_down_i,
  input  wire logic                               ev_commit_err_i,
  input  wire logic                               ev_commit_irq_i,
  input  wire logic [hpc_cq_pkg::PC_N*PERF_CW-1:0] perf_cnt_i
);
  localparam logic [31:0] ID_VALUE = 32'h5346_4351;   // "SFCQ"
  localparam logic [31:0] INFO = {5'd0, PERF_EN, OVERLAP_EN, OPSET_FULL, 8'(ROB_DEPTH),
                                  8'(QUEUE_DEPTH), 4'd0, hpc_cq_pkg::ABI_VERSION};

  localparam logic [11:0] A_ID = 12'h000, A_INFO = 12'h004, A_CTRL = 12'h008, A_STATUS = 12'h00C,
                          A_IE = 12'h010, A_IS = 12'h014, A_SUBM = 12'h018,
                          A_DESC0 = 12'h020, A_DOORBELL = 12'h040, A_CPL0 = 12'h050,
                          A_CPLPOP = 12'h060, A_PERF0 = 12'h080;

  logic [31:0] desc_q [0:7];
  logic        cont_q;
  logic [1:0]  ie_q, is_q;
  logic [31:0] subm_q;

  wire wr = rb_sel && rb_we;

  wire is_desc  = (rb_addr >= A_DESC0) && (rb_addr < A_DESC0 + 12'd32) && (rb_addr[1:0] == 2'b00);
  wire is_cpl   = (rb_addr >= A_CPL0)  && (rb_addr < A_CPL0 + 12'd16)  && (rb_addr[1:0] == 2'b00);
  wire is_perf  = (rb_addr >= A_PERF0) && (rb_addr < A_PERF0 + 12'(4 * hpc_cq_pkg::PC_N)) &&
                  (rb_addr[1:0] == 2'b00);
  wire [2:0] desc_i = rb_addr[4:2];
  wire [1:0] cpl_i  = rb_addr[3:2];
  /* verilator lint_off UNUSEDSIGNAL */
  wire [11:0] perf_off = rb_addr - A_PERF0;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [5:0]  perf_i   = perf_off[7:2];

  // ---------------------------------------------------------------- stream side
  assign cmd_valid_o = wr && (rb_addr == A_DOORBELL) && cmd_ready_i;
  assign cpl_ready_o = wr && (rb_addr == A_CPLPOP) && cpl_valid_i;
  for (genvar w = 0; w < 8; w++) begin : g_desc
    assign cmd_desc_o[w*32 +: 32] = desc_q[w];
  end
  assign ctrl_err_cont_o   = cont_q;
  assign ctrl_err_clear_o  = wr && (rb_addr == A_CTRL) && rb_wdata[1];
  assign ctrl_perf_clear_o = wr && (rb_addr == A_CTRL) && rb_wdata[2];

  // ---------------------------------------------------------------- read mux / errors
  wire [7:0] qfree = 8'(QUEUE_DEPTH) - 8'(q_count_i);
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_sel) begin
      if (is_desc) begin
        rb_rdata = desc_q[desc_i];
      end else if (is_cpl) begin
        rb_rdata = cpl_rec_i[32*cpl_i +: 32];
        rb_err   = rb_we;
      end else if (is_perf) begin
        rb_rdata = 32'(perf_cnt_i[PERF_CW*perf_i +: PERF_CW]);   // low 32 bits
        rb_err   = rb_we;
      end else begin
        case (rb_addr)
          A_ID:       begin rb_rdata = ID_VALUE; rb_err = rb_we; end
          A_INFO:     begin rb_rdata = INFO;     rb_err = rb_we; end
          A_CTRL:     rb_rdata = {31'd0, cont_q};
          A_STATUS:   begin
                        rb_rdata = {qfree, 8'(rob_count_i), 8'(q_count_i), 1'b0, vec_down_i, dma_down_i,
                                    cpl_valid_i, q_empty_i, q_full_i, err_sticky_i, busy_i};
                        rb_err   = rb_we;
                      end
          A_IE:       rb_rdata = {30'd0, ie_q};
          A_IS:       rb_rdata = {30'd0, is_q};
          A_SUBM:     begin rb_rdata = subm_q; rb_err = rb_we; end
          A_DOORBELL: rb_err = rb_we && !cmd_ready_i;     // refused while the queue is full
          A_CPLPOP:   rb_err = rb_we && !cpl_valid_i;     // nothing to release
          default:    rb_err = 1'b1;
        endcase
      end
    end
  end

  // ---------------------------------------------------------------- registers
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cont_q <= 1'b0;
      ie_q   <= 2'b00;
      is_q   <= 2'b00;
      subm_q <= 32'd0;
      for (int w = 0; w < 8; w++) desc_q[w] <= 32'd0;
    end else begin
      if (wr && is_desc)                 desc_q[desc_i] <= rb_wdata;
      if (wr && rb_addr == A_CTRL)       cont_q <= rb_wdata[0];
      if (wr && rb_addr == A_IE)         ie_q   <= rb_wdata[1:0];
      if (cmd_valid_o)                   subm_q <= subm_q + 32'd1;
      // interrupt status: event sets, write-one clears, set wins
      is_q <= (is_q & ~((wr && rb_addr == A_IS) ? rb_wdata[1:0] : 2'b00)) |
              {ev_commit_err_i, ev_commit_irq_i};
    end
  end

  assign irq_o = |(is_q & ie_q);

endmodule

`default_nettype wire
