// ASIC macro black boxes for simulation / lint only (not synthesizable RTL)
third_party/silicaflux-hpc-m04-scratchpad/third_party/silicaflux-sramlib/rtl/mem/backends/asic/stubs/sram_macro_blackboxes.sv
