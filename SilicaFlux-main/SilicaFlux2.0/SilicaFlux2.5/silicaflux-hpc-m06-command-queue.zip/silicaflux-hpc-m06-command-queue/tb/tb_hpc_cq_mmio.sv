// =============================================================================
// SilicaFlux-HPC Module 06 :: tb_hpc_cq_mmio -- directed test of the MMIO adapter
//
// hpc_cq_mmio in front of the real hpc_cq_tile (QUEUE_DEPTH = 4, ROB_DEPTH = 2).
// Register-bus master modelled on the SilicaFlux-V bridge: one-cycle strobe,
// rb_rdata / rb_err sampled in the strobe cycle.  Checks:
//   ID / INFO, CTRL / INT_ENABLE read-back, DESC staging read-back;
//   writes to RO registers, writes to CPL / PERF / STATUS, unmapped offsets
//   and misaligned offsets answer rb_err = 1 with no effect;
//   doorbells beyond capacity (ROB 2 + decode 1 + FIFO 4 = 7 commands without
//   CPL_POP) are refused with rb_err and submit nothing; SUBMITTED counts only
//   accepted doorbells; Q_FREE tracks the FIFO;
//   CPL_POP with no record is refused; records pop in order (SEQ 0, 1, ...);
//   INT_STATUS is set by FL_IRQ / error commits, cleared by writing 1, and
//   irq_o follows INT_STATUS & INT_ENABLE; CTRL.ERR_CLEAR releases a sticky
//   error; CTRL.PERF_CLEAR zeroes the counters.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_hpc_cq_mmio;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic        rb_sel = 0, rb_we = 0, rb_err, irq;
  logic [11:0] rb_addr = 0;
  logic [31:0] rb_wdata = 0, rb_rdata;
  int errors = 0;

  cosim_dut u (.clk, .rst_n, .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq);

  task automatic wr(input logic [11:0] a, input logic [31:0] v, output bit err);
    @(posedge clk); #1;
    rb_sel = 1; rb_we = 1; rb_addr = a; rb_wdata = v;
    @(negedge clk); err = rb_err;
    @(posedge clk); #1;
    rb_sel = 0; rb_we = 0;
  endtask

  task automatic rd(input logic [11:0] a, output logic [31:0] v, output bit err);
    @(posedge clk); #1;
    rb_sel = 1; rb_we = 0; rb_addr = a;
    @(negedge clk); v = rb_rdata; err = rb_err;
    @(posedge clk); #1;
    rb_sel = 0;
  endtask

  task automatic expect_rd(input logic [11:0] a, input logic [31:0] exp, input logic [31:0] mask,
                           input bit exp_err, input string what);
    logic [31:0] v; bit e;
    rd(a, v, e);
    if (e !== exp_err || ((v ^ exp) & mask) != 0) begin
      errors++; $display("ERROR %s: read %03h = %08h err %0b (expected %08h/%08h err %0b)", what, a, v, e, exp, mask, exp_err);
    end
  endtask

  task automatic expect_wr(input logic [11:0] a, input logic [31:0] v, input bit exp_err, input string what);
    bit e;
    wr(a, v, e);
    if (e !== exp_err) begin errors++; $display("ERROR %s: write %03h err %0b, expected %0b", what, a, e, exp_err); end
  endtask

  task automatic stage_nop(input logic [7:0] tid, input logic [7:0] flags);
    expect_wr(12'h020, {tid, flags, 4'd0, 4'd1, 8'h00}, 0, "DESC0");
    for (int i = 1; i < 8; i++) expect_wr(12'h020 + 12'(4 * i), 32'd0, 0, "DESCn");
  endtask

  initial begin
    logic [31:0] v; bit e; int acc;
    repeat (4) @(posedge clk);
    rst_n = 1;
    repeat (3) @(posedge clk);
    // identification
    expect_rd(12'h000, 32'h5346_4351, '1, 0, "ID");
    expect_rd(12'h004, 32'h0702_0401, 32'h07FF_FF0F, 0, "INFO (ABI 1, QD 4, ROB 2, full, overlap, perf)");
    // RO / unmapped / misaligned
    expect_wr(12'h000, 1, 1, "write ID");
    expect_wr(12'h004, 1, 1, "write INFO");
    expect_wr(12'h00C, 1, 1, "write STATUS");
    expect_wr(12'h018, 1, 1, "write SUBMITTED");
    expect_wr(12'h050, 1, 1, "write CPL0");
    expect_wr(12'h080, 1, 1, "write PERF0");
    expect_rd(12'h01C, 0, 0, 1, "read unmapped 0x01C");
    expect_rd(12'h100, 0, 0, 1, "read unmapped 0x100");
    expect_wr(12'h022, 1, 1, "write misaligned DESC");
    expect_rd(12'h0C4, 0, 0, 1, "read beyond PERF");
    // nothing to pop
    expect_wr(12'h060, 1, 1, "CPL_POP when empty");
    expect_rd(12'h00C, 32'h0400_0008, 32'hFFFF_FFFF, 0, "STATUS idle (Q_FREE=4, Q_EMPTY)");
    // staging read-back
    expect_wr(12'h03C, 32'hA5A5_5A5A, 0, "DESC7");
    expect_rd(12'h03C, 32'hA5A5_5A5A, '1, 0, "DESC7 read-back");
    // CTRL / INT_ENABLE read-back
    expect_wr(12'h010, 32'h3, 0, "INT_ENABLE");
    expect_rd(12'h010, 32'h3, '1, 0, "INT_ENABLE read-back");
    expect_wr(12'h008, 32'h1, 0, "CTRL cont");
    expect_rd(12'h008, 32'h1, '1, 0, "CTRL read-back");
    expect_wr(12'h008, 32'h0, 0, "CTRL stop");
    // fill: no CPL_POP -> ROB (2) + decode slot (1) + FIFO (4) = 7 accepted, then refused
    acc = 0;
    for (int i = 0; i < 10; i++) begin
      stage_nop(8'(i), (i == 0) ? 8'h01 : 8'h00);   // first one requests an IRQ
      repeat (4) @(posedge clk);
      wr(12'h040, 1, e);
      if (!e) acc++;
    end
    if (acc != 7) begin errors++; $display("ERROR %0d doorbells accepted with no CPL_POP, expected 7", acc); end
    expect_rd(12'h018, 7, '1, 0, "SUBMITTED counts accepted doorbells only");
    expect_rd(12'h00C, 32'h0000_0014 | 32'h0000_0400 | 32'h0002_0000 | 32'h0000_0001, 32'hFFFF_FFFD, 0,
              "STATUS full (Q_FREE=0 Q_COUNT=4 ROB=2 CPL_VALID BUSY Q_FULL)");
    // IRQ: the FL_IRQ NOP has committed
    expect_rd(12'h014, 32'h1, 32'h1, 0, "INT_STATUS.IRQ set");
    if (!irq) begin errors++; $display("ERROR irq_o low with INT_STATUS.IRQ & INT_ENABLE"); end
    expect_wr(12'h014, 32'h1, 0, "INT_STATUS W1C");
    expect_rd(12'h014, 32'h0, 32'h1, 0, "INT_STATUS.IRQ cleared");
    if (irq) begin errors++; $display("ERROR irq_o still high after W1C"); end
    // pop all 7 in order
    for (int i = 0; i < 7; i++) begin
      int t; t = 0;
      do begin rd(12'h00C, v, e); t++; end while (!v[4] && t < 1000);
      expect_rd(12'h05C, i, '1, 0, "CPL3 = SEQ");
      expect_rd(12'h050, {5'd0, (i == 0), 2'd0, 8'h00, 8'h00, 8'(i)}, '1, 0, "CPL0");
      expect_wr(12'h060, 1, 0, "CPL_POP");
    end
    repeat (10) @(posedge clk);
    expect_wr(12'h060, 1, 1, "CPL_POP after draining");
    // sticky error, ERR interrupt, clear
    expect_wr(12'h020, {8'd50, 8'h00, 4'd0, 4'd1, 8'h77}, 0, "DESC0 bad opcode");
    expect_wr(12'h040, 1, 0, "DOORBELL bad");
    stage_nop(8'd51, 8'h00);
    expect_wr(12'h040, 1, 0, "DOORBELL nop");
    repeat (20) @(posedge clk);
    expect_rd(12'h00C, 32'h0000_0002, 32'h0000_0002, 0, "STATUS.ERR_STICKY");
    expect_rd(12'h014, 32'h2, 32'h2, 0, "INT_STATUS.ERR set");
    expect_rd(12'h050, {5'd0, 1'b0, 2'd1, 8'h02, 8'h77, 8'd50}, '1, 0, "error record");
    expect_wr(12'h060, 1, 0, "pop");
    expect_rd(12'h050, {5'd0, 1'b0, 2'd2, 8'h40, 8'h00, 8'd51}, '1, 0, "skipped record");
    expect_wr(12'h060, 1, 0, "pop");
    expect_wr(12'h008, 32'h2, 0, "CTRL.ERR_CLEAR");
    expect_rd(12'h00C, 32'h0, 32'h0000_0002, 0, "sticky cleared");
    expect_rd(12'h008, 32'h0, '1, 0, "ERR_CLEAR reads 0");
    // counters and their clear
    expect_rd(12'h080 + 4 * hpc_cq_pkg::PC_CMD_COMMIT, 9, '1, 0, "PERF CMD_COMMIT");
    expect_rd(12'h080 + 4 * hpc_cq_pkg::PC_CMD_SKIP, 1, '1, 0, "PERF CMD_SKIP");
    expect_wr(12'h008, 32'h4, 0, "CTRL.PERF_CLEAR");
    expect_rd(12'h080 + 4 * hpc_cq_pkg::PC_CMD_COMMIT, 0, '1, 0, "PERF cleared");
    $display("TB_RESULT %s errors=%0d", errors ? "FAIL" : "PASS", errors);
    $finish;
  end

  initial begin #2_000_000; $display("TB_RESULT FAIL timeout"); $finish; end
endmodule

// adapter + tile + external memory, register bus only (QUEUE_DEPTH 4, ROB_DEPTH 2)
module cosim_dut (
  input  wire logic        clk, rst_n, rb_sel, rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err, irq
);
  localparam int QD = 4, RD = 2;
  logic         cmd_valid, cmd_ready, cpl_valid, cpl_ready, err_cont, err_clear, perf_clear;
  logic [255:0] cmd_desc;
  logic [127:0] cpl_rec;
  logic         busy, q_full, q_empty, sticky, dma_down, vec_down, ev_c, ev_ce, ev_ci;
  logic [$clog2(QD+1)-1:0] q_count;
  logic [$clog2(RD+1)-1:0] rob_count;
  logic [hpc_cq_pkg::PC_N*32-1:0] perf;
  logic e_req_valid, e_req_write, e_rsp_ready;
  logic [31:0] e_req_addr, e_req_wdata;
  logic [3:0]  e_req_wstrb;

  hpc_cq_mmio #(.QUEUE_DEPTH(QD), .ROB_DEPTH(RD)) u_mmio (
    .clk_i(clk), .rst_ni(rst_n), .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_o(irq),
    .cmd_valid_o(cmd_valid), .cmd_ready_i(cmd_ready), .cmd_desc_o(cmd_desc),
    .cpl_valid_i(cpl_valid), .cpl_ready_o(cpl_ready), .cpl_rec_i(cpl_rec),
    .ctrl_err_cont_o(err_cont), .ctrl_err_clear_o(err_clear), .ctrl_perf_clear_o(perf_clear),
    .busy_i(busy), .q_count_i(q_count), .q_full_i(q_full), .q_empty_i(q_empty), .rob_count_i(rob_count),
    .err_sticky_i(sticky), .dma_down_i(dma_down), .vec_down_i(vec_down),
    .ev_commit_err_i(ev_ce), .ev_commit_irq_i(ev_ci), .perf_cnt_i(perf)
  );
  hpc_cq_tile #(.QUEUE_DEPTH(QD), .ROB_DEPTH(RD)) u_tile (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_desc_i(cmd_desc),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_rec_o(cpl_rec),
    .ctrl_err_cont_i(err_cont), .ctrl_err_clear_i(err_clear), .ctrl_perf_clear_i(perf_clear),
    .busy_o(busy), .q_count_o(q_count), .q_full_o(q_full), .q_empty_o(q_empty), .rob_count_o(rob_count),
    .err_sticky_o(sticky), .dma_down_o(dma_down), .vec_down_o(vec_down),
    .ev_commit_o(ev_c), .ev_commit_err_o(ev_ce), .ev_commit_irq_o(ev_ci), .perf_cnt_o(perf),
    .host_req_valid_i(1'b0), .host_req_ready_o(), .host_req_write_i(1'b0), .host_req_addr_i(32'd0),
    .host_req_wdata_i(32'd0), .host_req_wstrb_i(4'd0), .host_rsp_valid_o(), .host_rsp_ready_i(1'b1),
    .host_rsp_rdata_o(), .host_rsp_error_o(),
    .ext_req_valid_o(e_req_valid), .ext_req_ready_i(1'b1), .ext_req_write_o(e_req_write),
    .ext_req_addr_o(e_req_addr), .ext_req_wdata_o(e_req_wdata), .ext_req_wstrb_o(e_req_wstrb),
    .ext_rsp_valid_i(1'b0), .ext_rsp_ready_o(e_rsp_ready), .ext_rsp_rdata_i(32'd0), .ext_rsp_error_i(1'b0),
    .lane_hold_i(2'b00),
    .trc_resolve_o(), .trc_seq_o(), .trc_dma_act_o(), .trc_dma_seq_o(), .trc_vec_act_o(), .trc_vec_seq_o()
  );
endmodule

`default_nettype wire
