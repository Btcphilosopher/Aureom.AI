// =============================================================================
// SilicaFlux-HPC Module 06 :: tb_hpc_command_queue -- self-checking testbench
//
// DUT: hpc_cq_tile (command queue + DataFabric DMA engine + SFB2 crossbar +
// Module 04 scratchpad + vector executor + Module 03 array), external memory
// model tb_ext_mem, DataFabric sfb_protocol_checker on every SFB2 port.
//
// A program (ref/gen_prog.py -> +PROG=<dir>) is a command stream plus the
// reference model's expectations.  The testbench:
//   * submits the commands with random gaps (+GAP) through the ready/valid
//     command port, honouring host sync points (SYNC / CLEAR / CHECK / MODE);
//   * consumes completion records with random back-pressure (+CPLRDY) and
//     compares them IN ORDER against the reference records (scoreboard),
//     accepting the model's alternative record only where the model says
//     the outcome is timing dependent, and then only monotonically;
//   * monitors, every cycle, independently of the RTL:
//       - in-order issue (the decode slot releases SEQ 0, 1, 2, ...),
//       - FENCE / BARRIER / RESET_COUNTERS / OVERLAP_EN = 0 never leave the
//         decode slot while an older job is in flight,
//       - a DMA job and a vector job in flight together never conflict
//         (RAW / WAR / WAW on their byte footprints),
//       - commit-interrupt and error events match the records;
//   * randomises external-memory latency / back-pressure (+XRDY +LATMIN
//     +LATMAX), Module 03 lane holds (+HOLD) and host-port traffic to a
//     scratch area (+HOST);
//   * at the end checks: every record received, nothing extra, the queue
//     idle, the external memory (every defined word), the scratchpad
//     (every defined word of the used regions, via the host port), the
//     scratch area, the performance counters and the protocol checkers.
//   * +RESET_AT=k: asserts reset at a random time after submitting command
//     k of program A, checks that no stale record ever appears, then runs
//     program B (+PROGB=<dir>) from scratch.
// Output: one "TB_RESULT PASS|FAIL ..." line (scripts/regress.py).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_hpc_command_queue #(
  parameter int QD    = 8,      // QUEUE_DEPTH
  parameter int RD    = 8,      // ROB_DEPTH
  parameter int N     = 2,      // NUM_LANES
  parameter bit OVL   = 1'b1,   // OVERLAP_EN
  parameter bit OPSET = 1'b1,   // OPSET_FULL
  parameter int PHYS  = 16,     // SPM_PHYS_LOG2
  parameter int WDOG  = 16,     // WDOG_LOG2
  parameter int SPMRL = 1,      // scratchpad READ_LATENCY
  parameter int OPQ   = 4,      // vector executor operand-queue depth
  parameter int WBQ   = 4       // vector executor write-back-queue depth
);
  localparam logic [31:0] EXT_BASE = 32'h1000_0000;
  localparam int          EXT_LOG2 = 17;
  localparam logic [31:0] SPM_BASE = 32'h2000_0000;
  localparam int          SPM_LOG2 = 16;
  localparam int MAXC = 4096, MAXS = 20000, MAXK = 4096, EXTW = 1 << (EXT_LOG2 - 2);
  localparam int PCN  = hpc_cq_pkg::PC_N;

  // ------------------------------------------------------------------ clock / reset
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ------------------------------------------------------------------ DUT
  logic         cmd_valid, cmd_ready, cpl_valid, cpl_ready;
  logic [255:0] cmd_desc;
  logic [127:0] cpl_rec;
  logic         err_cont, err_clear, perf_clear;
  logic         busy, q_full, q_empty, sticky, dma_down, vec_down, ev_c, ev_ce, ev_ci;
  logic [$clog2(QD+1)-1:0] q_count;
  logic [$clog2(RD+1)-1:0] rob_count;
  logic [PCN*32-1:0] perf;
  logic h_req_valid, h_req_ready, h_req_write, h_rsp_valid, h_rsp_ready, h_rsp_error;
  logic [31:0] h_req_addr, h_req_wdata, h_rsp_rdata;
  logic [3:0]  h_req_wstrb;
  logic e_req_valid, e_req_ready, e_req_write, e_rsp_valid, e_rsp_ready, e_rsp_error;
  logic [31:0] e_req_addr, e_req_wdata, e_rsp_rdata;
  logic [3:0]  e_req_wstrb;
  logic [N-1:0] lane_hold;
  logic        t_res, t_da, t_va;
  logic [31:0] t_seq, t_dseq, t_vseq;

  hpc_cq_tile #(
    .QUEUE_DEPTH(QD), .ROB_DEPTH(RD), .OPSET_FULL(OPSET), .OVERLAP_EN(OVL), .NUM_LANES(N),
    .EXT_BASE(EXT_BASE), .EXT_LOG2(EXT_LOG2), .SPM_BASE(SPM_BASE), .SPM_LOG2(SPM_LOG2),
    .SPM_PHYS_LOG2(PHYS), .SPM_BANKS(4), .SPM_READ_LATENCY(SPMRL), .WDOG_LOG2(WDOG),
    .VX_OPQ_DEPTH(OPQ), .VX_WBQ_DEPTH(WBQ)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_desc_i(cmd_desc),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_rec_o(cpl_rec),
    .ctrl_err_cont_i(err_cont), .ctrl_err_clear_i(err_clear), .ctrl_perf_clear_i(perf_clear),
    .busy_o(busy), .q_count_o(q_count), .q_full_o(q_full), .q_empty_o(q_empty),
    .rob_count_o(rob_count), .err_sticky_o(sticky), .dma_down_o(dma_down), .vec_down_o(vec_down),
    .ev_commit_o(ev_c), .ev_commit_err_o(ev_ce), .ev_commit_irq_o(ev_ci), .perf_cnt_o(perf),
    .host_req_valid_i(h_req_valid), .host_req_ready_o(h_req_ready), .host_req_write_i(h_req_write),
    .host_req_addr_i(h_req_addr), .host_req_wdata_i(h_req_wdata), .host_req_wstrb_i(h_req_wstrb),
    .host_rsp_valid_o(h_rsp_valid), .host_rsp_ready_i(h_rsp_ready), .host_rsp_rdata_o(h_rsp_rdata),
    .host_rsp_error_o(h_rsp_error),
    .ext_req_valid_o(e_req_valid), .ext_req_ready_i(e_req_ready), .ext_req_write_o(e_req_write),
    .ext_req_addr_o(e_req_addr), .ext_req_wdata_o(e_req_wdata), .ext_req_wstrb_o(e_req_wstrb),
    .ext_rsp_valid_i(e_rsp_valid), .ext_rsp_ready_o(e_rsp_ready), .ext_rsp_rdata_i(e_rsp_rdata),
    .ext_rsp_error_i(e_rsp_error),
    .lane_hold_i(lane_hold),
    .trc_resolve_o(t_res), .trc_seq_o(t_seq), .trc_dma_act_o(t_da), .trc_dma_seq_o(t_dseq),
    .trc_vec_act_o(t_va), .trc_vec_seq_o(t_vseq)
  );

  // ------------------------------------------------------------------ external memory
  int unsigned k_xrdy = 100, k_latmin = 1, k_latmax = 1;
  logic [31:0] k_err_lo = 0, k_err_hi = 0, k_hang_lo = 0, k_hang_hi = 0;
  logic [31:0] e_nr, e_nw;
  logic        e_hung;

  tb_ext_mem #(.BASE(EXT_BASE), .LOG2(EXT_LOG2)) u_ext (
    .clk, .rst_n, .ready_pct_i(8'(k_xrdy)), .lat_min_i(8'(k_latmin)), .lat_max_i(8'(k_latmax)),
    .err_lo_i(k_err_lo), .err_hi_i(k_err_hi), .hang_lo_i(k_hang_lo), .hang_hi_i(k_hang_hi),
    .req_valid(e_req_valid), .req_ready(e_req_ready), .req_write(e_req_write), .req_addr(e_req_addr),
    .req_wdata(e_req_wdata), .req_wstrb(e_req_wstrb), .rsp_valid(e_rsp_valid), .rsp_ready(e_rsp_ready),
    .rsp_rdata(e_rsp_rdata), .rsp_error(e_rsp_error), .n_reads(e_nr), .n_writes(e_nw), .hung(e_hung)
  );

  // ------------------------------------------------------------------ SFB2 protocol checkers (DataFabric)
  logic [31:0] pv_ext, pv_host, pv_dma, pn0, pn1, pn2, pn3, pn4, pn5, po0, po1, po2;
  sfb_protocol_checker #(.NAME("ext")) u_pc_ext (
    .clk, .rst_n, .req_valid(e_req_valid), .req_ready(e_req_ready), .req_write(e_req_write),
    .req_addr(e_req_addr), .req_wdata(e_req_wdata), .req_wstrb(e_req_wstrb), .rsp_valid(e_rsp_valid),
    .rsp_ready(e_rsp_ready), .rsp_rdata(e_rsp_rdata), .rsp_error(e_rsp_error),
    .violations(pv_ext), .n_req(pn0), .n_rsp(pn1), .outstanding(po0));
  sfb_protocol_checker #(.NAME("host"), .CHECK_RDATA_ZERO(0)) u_pc_host (
    .clk, .rst_n, .req_valid(h_req_valid), .req_ready(h_req_ready), .req_write(h_req_write),
    .req_addr(h_req_addr), .req_wdata(h_req_wdata), .req_wstrb(h_req_wstrb), .rsp_valid(h_rsp_valid),
    .rsp_ready(h_rsp_ready), .rsp_rdata(h_rsp_rdata), .rsp_error(h_rsp_error),
    .violations(pv_host), .n_req(pn2), .n_rsp(pn3), .outstanding(po1));
  sfb_protocol_checker #(.NAME("dma"), .CHECK_RDATA_ZERO(0)) u_pc_dma (
    .clk, .rst_n, .req_valid(dut.dm_req_valid), .req_ready(dut.dm_req_ready),
    .req_write(dut.dm_req_write), .req_addr(dut.dm_req_addr), .req_wdata(dut.dm_req_wdata),
    .req_wstrb(dut.dm_req_wstrb), .rsp_valid(dut.dm_rsp_valid), .rsp_ready(dut.dm_rsp_ready),
    .rsp_rdata(dut.dm_rsp_rdata), .rsp_error(dut.dm_rsp_error),
    .violations(pv_dma), .n_req(pn4), .n_rsp(pn5), .outstanding(po2));

  // ------------------------------------------------------------------ program storage
  logic [255:0] cmds [0:MAXC-1];
  logic [31:0]  ctl  [0:MAXC-1];
  logic [127:0] expr [0:MAXC-1], expm [0:MAXC-1], altr [0:MAXC-1], altm [0:MAXC-1];
  logic [63:0]  spmi [0:MAXS-1], spmc [0:MAXS-1];
  logic [95:0]  chk  [0:MAXK-1];
  logic [31:0]  ext_init [0:EXTW-1], ext_exp [0:EXTW-1];
  logic [3:0]   ext_care [0:EXTW-1];
  int ncmd, nspmi, nspmc, nchk;

  // ------------------------------------------------------------------ knobs
  int unsigned k_gap = 0, k_cplrdy = 100, k_hold = 0;
  int unsigned k_host = 0;
  int errors = 0;
  string prog_dir;
  bit dbg = 0;
  initial dbg = $test$plusargs("DBG");

  // ------------------------------------------------------------------ helpers: descriptor decode (TB-side)
  function automatic bit is_dma(input logic [7:0] op); is_dma = (op == 8'h01) || (op == 8'h02); endfunction
  function automatic bit is_vec(input logic [7:0] op); is_vec = (op == 8'h10) || (op == 8'h11) || (op == 8'h12); endfunction

  function automatic bit ov(input longint a0, input longint a1, input longint b0, input longint b1);
    ov = (a0 < b1) && (b0 < a1) && (a0 < a1) && (b0 < b1);
  endfunction

  // byte footprint of a valid DMA / vector descriptor: interval k (0..3) of
  // kind 0..2 = reads (A, B, FMA's D), 3 = write.  Empty = [0, 0).
  function automatic longint fp_lo(input logic [255:0] d, input int k);
    longint sa, sb, da;
    sa = longint'(d[63:32]); sb = longint'(d[95:64]); da = longint'(d[127:96]);
    fp_lo = 0;
    if (is_dma(d[7:0])) begin
      if (k == 0) fp_lo = sa;
      if (k == 3) fp_lo = da;
    end else if (is_vec(d[7:0])) begin
      if (k == 0) fp_lo = sa;
      if (k == 1) fp_lo = sb;
      if (k == 2 && d[7:0] == 8'h12) fp_lo = da;
      if (k == 3) fp_lo = da;
    end
  endfunction

  function automatic longint fp_hi(input logic [255:0] d, input int k);
    longint L;
    L = longint'(d[159:128]);
    fp_hi = 0;
    if (is_dma(d[7:0])) begin
      if (k == 0) fp_hi = fp_lo(d, 0) + ((L + 3) / 4) * 4;
      if (k == 3) fp_hi = fp_lo(d, 3) + L;
    end else if (is_vec(d[7:0])) begin
      if (k == 0 || k == 1 || k == 3 || (k == 2 && d[7:0] == 8'h12)) fp_hi = fp_lo(d, k) + 4 * L;
    end
  endfunction

  // RAW / WAR / WAW between two footprints
  function automatic bit conflict(input logic [255:0] x, input logic [255:0] y);
    bit c;
    c = ov(fp_lo(x, 3), fp_hi(x, 3), fp_lo(y, 3), fp_hi(y, 3));
    for (int k = 0; k < 3; k++) begin
      c = c || ov(fp_lo(x, 3), fp_hi(x, 3), fp_lo(y, k), fp_hi(y, k))
            || ov(fp_lo(y, 3), fp_hi(y, 3), fp_lo(x, k), fp_hi(x, k));
    end
    conflict = c;
  endfunction

  function automatic bit is_sync(input logic [255:0] d);
    logic [7:0] op;
    op = d[7:0];
    is_sync = (op == 8'h20) || (op == 8'h30) || d[17] || (!OVL && (is_dma(op) || is_vec(op)));
  endfunction

  // ------------------------------------------------------------------ scoreboard
  int rcv = 0;                      // records received for the current program
  longint prog_start_cyc = 0, last_rec_cyc = 0;
  bit skip_run = 0;                 // inside an ambiguity window, alternatives seen
  bit sb_en = 0;                    // program loaded
  int n_rec_err = 0, n_rec_skip = 0, n_rec_irq = 0, n_rec_ce = 0, n_alt_taken = 0;
  int n_dma_exec = 0, n_vec_exec = 0;
  int rst_seq = -1;                 // SEQ of the last executed RESET_COUNTERS
  logic [MAXC-1:0] synced_active;   // sync-type command left decode with an older job in flight
  int base_err = 0, base_skip = 0, base_dma = 0, base_vec = 0, base_irq = 0;

  function automatic string rec_str(input logic [127:0] r);
    rec_str = $sformatf("seq=%0d tid=%0d op=%02h st=%0d err=%02h irq=%0d ff=%02h cnt=%0d ea=%08h",
                        r[127:96], r[7:0], r[15:8], r[25:24], r[23:16], r[26], r[31:27], r[63:32], r[95:64]);
  endfunction

  always @(posedge clk) begin
    if (rst_n && cpl_valid && cpl_ready) begin
      logic [127:0] r;
      bit pm, am;
      r = cpl_rec;
      if (!sb_en || rcv >= ncmd) begin
        errors++;
        $display("[%0d] ERROR unexpected completion record %s", cyc, rec_str(r));
      end else begin
        pm = (((r ^ expr[rcv]) & expm[rcv]) == 128'd0);
        am = (altm[rcv] != 128'd0) && (((r ^ altr[rcv]) & altm[rcv]) == 128'd0);
        if (altm[rcv] == 128'd0) skip_run = 0;
        if (skip_run && altm[rcv] != 128'd0 && !am) begin
          errors++;
          $display("[%0d] ERROR record %0d: executed after a skipped one (non-monotonic): %s", cyc, rcv, rec_str(r));
        end else if (!pm && !am) begin
          errors++;
          $display("[%0d] ERROR record %0d mismatch\n   got %s\n   exp %s  mask %h%s", cyc, rcv,
                   rec_str(r), rec_str(expr[rcv]), expm[rcv],
                   altm[rcv] != 0 ? $sformatf("\n   alt %s", rec_str(altr[rcv])) : "");
        end
        if (am && !pm) begin skip_run = 1; n_alt_taken++; end
        // a masked error code must still be an execution-error code
        if (expm[rcv][23:16] == 8'h00 && r[25:24] == 2'd1 && r[23:16] < 8'h10) begin
          errors++;
          $display("[%0d] ERROR record %0d: execution error expected, got code %02h", cyc, rcv, r[23:16]);
        end
        if (r[25:24] == 2'd0 && synced_active[rcv]) begin
          errors++;
          $display("[%0d] ERROR command %0d (sync type) left decode while an older job was in flight", cyc, rcv);
        end
        if (r[25:24] == 2'd1) n_rec_err++;
        if (r[25:24] == 2'd2) n_rec_skip++;
        if (r[25:24] != 2'd0) n_rec_ce++;
        if (r[26]) n_rec_irq++;
        if (is_dma(r[15:8]) && (r[25:24] == 2'd0 || (r[23:16] >= 8'h11 && r[23:16] <= 8'h1A) || r[23:16] == 8'h30))
          n_dma_exec++;
        if (is_vec(r[15:8]) && (r[25:24] == 2'd0 || (r[23:16] >= 8'h21 && r[23:16] <= 8'h23) || r[23:16] == 8'h30))
          n_vec_exec++;
        if (r[15:8] == 8'h30 && r[25:24] == 2'd0) begin
          rst_seq = rcv;
          base_err = n_rec_err; base_skip = n_rec_skip; base_dma = n_dma_exec; base_vec = n_vec_exec;
        end
        rcv++;
        last_rec_cyc = cyc;
      end
    end
  end

  // ------------------------------------------------------------------ monitors
  int next_res = 0;
  int n_ev_irq = 0, n_ev_err = 0;
  longint hs_total = 0;
  longint hs_at_res [0:MAXC-1];
  longint overlap_cycles = 0;
  bit hold_forever = 0;

  always @(posedge clk) begin
    if (rst_n && sb_en) begin
      if (cmd_valid && cmd_ready) hs_total++;
      if (t_res) begin
        if (int'(t_seq) != next_res) begin
          errors++;
          $display("[%0d] ERROR decode released SEQ %0d, expected %0d (out of order)", cyc, t_seq, next_res);
        end
        next_res = int'(t_seq) + 1;
        if (t_seq < MAXC) begin
          hs_at_res[t_seq] = hs_total;
          synced_active[t_seq] = is_sync(cmds[t_seq]) && (t_da || t_va);
        end
      end
      if (t_da && t_va) begin
        overlap_cycles++;
        if (!OVL) begin
          errors++;
          $display("[%0d] ERROR OVERLAP_EN = 0 but DMA job %0d and vector job %0d in flight", cyc, t_dseq, t_vseq);
        end
        if (conflict(cmds[t_dseq], cmds[t_vseq])) begin
          errors++;
          $display("[%0d] ERROR dependent jobs in flight together: DMA SEQ %0d, vector SEQ %0d", cyc, t_dseq, t_vseq);
        end
      end
      if (t_va && ctl[t_vseq][4]) hold_forever = 1;
      if (ev_ci) n_ev_irq++;
      if (ev_ce) n_ev_err++;
    end
  end

  // lane holds (Module 03 stress): random, or forever once a HOLD job is issued
  always @(posedge clk) begin
    for (int l = 0; l < N; l++) lane_hold[l] <= hold_forever || (($urandom % 100) < k_hold);
  end

  // ------------------------------------------------------------------ host port (mutex-protected)
  bit host_lock = 0;
  // Driving / sampling discipline (race-free in Verilator and Icarus):
  // inputs change 1 ns after a rising edge; ready / valid are sampled at the
  // falling edge, when the combinational logic has settled; the handshake
  // happens at the following rising edge.
  task automatic host_acc(input bit we, input logic [31:0] a, input logic [31:0] wd,
                          output logic [31:0] rd, output bit err);
    while (host_lock) @(posedge clk);
    host_lock = 1;
    @(posedge clk); #1;
    h_req_valid = 1'b1; h_req_write = we; h_req_addr = a; h_req_wdata = wd; h_req_wstrb = 4'hF;
    @(negedge clk);
    while (!h_req_ready) begin
      if (dbg) $display("[%0d] host wait ready: a=%h", cyc, h_req_addr);
      @(negedge clk);
    end
    @(posedge clk); #1;                   // request handshake done
    h_req_valid = 1'b0;
    @(negedge clk);
    while (!h_rsp_valid) @(negedge clk);
    rd = h_rsp_rdata;                     // response handshake at the next rising edge
    err = h_rsp_error;
    @(posedge clk); #1;
    host_lock = 0;
  endtask

  // background host traffic on the scratch area (never touched by commands)
  logic [31:0] scratch_shadow [0:63];
  bit host_run = 0;
  logic [31:0] scr_base;
  initial begin
    for (int i = 0; i < 64; i++) scratch_shadow[i] = 32'hDEAD_0000 + i;
    forever begin
      @(posedge clk);
      if (host_run && k_host && ($urandom % 100) < 20) begin
        logic [31:0] rd, a, wd; bit err; int i;
        i  = $urandom % 64;
        a  = scr_base + 4 * i;
        if ($urandom % 2) begin
          wd = $urandom;
          host_acc(1'b1, a, wd, rd, err);
          if (err) begin errors++; $display("[%0d] ERROR host write %08h error", cyc, a); end
          scratch_shadow[i] = wd;
        end else begin
          host_acc(1'b0, a, 0, rd, err);
          if (err || rd !== scratch_shadow[i]) begin
            errors++; $display("[%0d] ERROR host read %08h = %08h, expected %08h", cyc, a, rd, scratch_shadow[i]);
          end
        end
      end
    end
  end

  // ------------------------------------------------------------------ program load / init / run
  task automatic load_prog(input string dir);
    int fd;
    $readmemh({dir, "/cmds.hex"}, cmds, 0, ncmd - 1);
    $readmemh({dir, "/ctl.hex"},  ctl,  0, ncmd - 1);
    $readmemh({dir, "/exp.hex"},  expr, 0, ncmd - 1);
    $readmemh({dir, "/expm.hex"}, expm, 0, ncmd - 1);
    $readmemh({dir, "/alt.hex"},  altr, 0, ncmd - 1);
    $readmemh({dir, "/altm.hex"}, altm, 0, ncmd - 1);
    $readmemh({dir, "/ext_init.hex"}, ext_init);
    $readmemh({dir, "/ext_exp.hex"},  ext_exp);
    $readmemh({dir, "/ext_care.hex"}, ext_care);
    if (nspmi > 0) $readmemh({dir, "/spm_init.hex"}, spmi, 0, nspmi - 1);
    if (nspmc > 0) $readmemh({dir, "/spm_chk.hex"},  spmc, 0, nspmc - 1);
    if (nchk  > 0) $readmemh({dir, "/chk.hex"},      chk,  0, nchk - 1);
  endtask

  task automatic init_memories();
    logic [31:0] rd; bit err;
    for (int i = 0; i < EXTW; i++) u_ext.mem_q[i] = ext_init[i];
    for (int i = 0; i < nspmi; i++) begin
      host_acc(1'b1, spmi[i][63:32], spmi[i][31:0], rd, err);
      if (err) begin errors++; $display("ERROR spm init write %08h", spmi[i][63:32]); end
    end
    for (int i = 0; i < 64; i++) begin
      host_acc(1'b1, scr_base + 4 * i, scratch_shadow[i], rd, err);
    end
  endtask

  task automatic run_checks(input int ci);
    logic [31:0] rd; bit err;
    for (int k = 0; k < nchk; k++) begin
      if (int'(chk[k][95:64]) == ci) begin
        logic [31:0] a, v;
        a = chk[k][63:32]; v = chk[k][31:0];
        if (a >= SPM_BASE) host_acc(1'b0, a, 0, rd, err);
        else begin rd = u_ext.mem_q[(a - EXT_BASE) >> 2]; err = 0; end
        if (err || rd !== v) begin
          errors++;
          $display("[%0d] ERROR sync check after command %0d: [%08h] = %08h, expected %08h", cyc, ci, a, rd, v);
        end
      end
    end
  endtask

  task automatic wait_record(input int i, input int limit);
    int t;
    t = 0;
    while (rcv <= i && t < limit) begin @(posedge clk); t++; end
    if (rcv <= i) begin
      errors++;
      $display("[%0d] ERROR timeout waiting for the record of command %0d (received %0d)", cyc, i, rcv);
    end
  endtask

  // returns 1 if the run was cut by reset
  // Back-to-back submission: after a handshake edge the next command is
  // presented at once (cmd_valid stays high), so with no gap the queue can
  // accept one command per cycle.
  task automatic run_prog(input int reset_at);
    int i;
    i = 0;
    @(posedge clk); #1;
    while (i < ncmd) begin
      if (($urandom % 100) < k_gap) begin
        int g;
        g = $urandom % 8;
        if (g != 0) begin
          cmd_valid = 1'b0; cmd_desc = '0;
          repeat (g) @(posedge clk);
          #1;
        end
      end
      cmd_desc  = cmds[i];
      cmd_valid = 1'b1;
      @(negedge clk);
      while (!cmd_ready) @(negedge clk);
      @(posedge clk); #1;                 // command i accepted at this edge
      if (i == reset_at || ctl[i][0] || i == ncmd - 1) begin
        cmd_valid = 1'b0;
        cmd_desc  = '0;
      end
      if (i == reset_at) begin
        repeat ($urandom % 300) @(posedge clk);
        i = ncmd;                         // cut here: the caller asserts reset
      end else begin
        if (ctl[i][0]) begin
          wait_record(i, 4_000_000);
          if (ctl[i][2]) run_checks(i);
          if (ctl[i][1]) begin @(posedge clk); #1; err_clear = 1'b1; @(posedge clk); #1; err_clear = 1'b0; end
          if (ctl[i][5]) begin @(posedge clk); #1; err_cont = ctl[i][6]; end
          @(posedge clk); #1;
        end
        i++;
      end
    end
  endtask

  task automatic final_checks();
    logic [31:0] rd; bit err;
    int bad_ext, bad_spm;
    wait_record(ncmd - 1, 8_000_000);
    repeat (20) @(posedge clk);
    host_run = 0;
    while (host_lock) @(posedge clk);
    if (busy || !q_empty || rob_count != 0 || cpl_valid) begin
      errors++;
      $display("ERROR queue not idle at the end: busy=%0b q_empty=%0b rob=%0d cpl_valid=%0b", busy, q_empty, rob_count, cpl_valid);
    end
    bad_ext = 0;
    for (int i = 0; i < EXTW; i++) begin
      if (ext_care[i][0] && u_ext.mem_q[i] !== ext_exp[i]) begin
        bad_ext++;
        if (bad_ext <= 8) $display("ERROR ext[%08h] = %08h, expected %08h", EXT_BASE + 4 * i, u_ext.mem_q[i], ext_exp[i]);
      end
    end
    bad_spm = 0;
    for (int i = 0; i < nspmc; i++) begin
      host_acc(1'b0, spmc[i][63:32], 0, rd, err);
      if (err || rd !== spmc[i][31:0]) begin
        bad_spm++;
        if (bad_spm <= 8) $display("ERROR spm[%08h] = %08h, expected %08h (err %0b)", spmc[i][63:32], rd, spmc[i][31:0], err);
      end
    end
    for (int i = 0; i < 64; i++) begin
      host_acc(1'b0, scr_base + 4 * i, 0, rd, err);
      if (err || rd !== scratch_shadow[i]) begin
        bad_spm++; $display("ERROR scratch[%0d] = %08h, expected %08h", i, rd, scratch_shadow[i]);
      end
    end
    errors += bad_ext + bad_spm;
    if (rcv != ncmd) begin errors++; $display("ERROR received %0d records, expected %0d", rcv, ncmd); end
    // commit events vs records
    if (n_ev_irq != n_rec_irq) begin errors++; $display("ERROR %0d IRQ commit events, %0d IRQ records", n_ev_irq, n_rec_irq); end
    if (n_ev_err != n_rec_ce)  begin errors++; $display("ERROR %0d error commit events, %0d error records", n_ev_err, n_rec_ce); end
    // performance counters (since the last executed RESET_COUNTERS)
    begin
      longint c_in, c_cm, c_er, c_sk, c_di, c_vi, c_ov, c_cy;
      longint x_in, x_cm;
      c_cy = perf[hpc_cq_pkg::PC_CYCLES*32 +: 32];
      c_in = perf[hpc_cq_pkg::PC_CMD_IN*32 +: 32];
      c_cm = perf[hpc_cq_pkg::PC_CMD_COMMIT*32 +: 32];
      c_er = perf[hpc_cq_pkg::PC_CMD_ERR*32 +: 32];
      c_sk = perf[hpc_cq_pkg::PC_CMD_SKIP*32 +: 32];
      c_di = perf[hpc_cq_pkg::PC_DMA_ISSUE*32 +: 32];
      c_vi = perf[hpc_cq_pkg::PC_VEC_ISSUE*32 +: 32];
      c_ov = perf[hpc_cq_pkg::PC_OVERLAP*32 +: 32];
      x_in = (rst_seq < 0) ? longint'(ncmd) : hs_total - hs_at_res[rst_seq];
      // RESET_COUNTERS clears when it leaves decode; its own commit comes later and is counted
      x_cm = (rst_seq < 0) ? longint'(ncmd) : longint'(ncmd - rst_seq);
      if (c_in != x_in || c_cm != x_cm || c_er != n_rec_err - base_err || c_sk != n_rec_skip - base_skip ||
          c_di != n_dma_exec - base_dma || c_vi != n_vec_exec - base_vec || (!OVL && c_ov != 0) ||
          (rst_seq < 0 && c_ov != overlap_cycles)) begin
        errors++;
        $display("ERROR counters: in %0d/%0d commit %0d/%0d err %0d/%0d skip %0d/%0d dma %0d/%0d vec %0d/%0d ovl %0d/%0d",
                 c_in, x_in, c_cm, x_cm, c_er, n_rec_err - base_err, c_sk, n_rec_skip - base_skip,
                 c_di, n_dma_exec - base_dma, c_vi, n_vec_exec - base_vec, c_ov, overlap_cycles);
      end
      for (int i = 1; i < PCN; i++)
        if (perf[i*32 +: 32] > c_cy) begin errors++; $display("ERROR counter %0d exceeds CYCLES", i); end
    end
    if (pv_ext != 0 || pv_host != 0 || pv_dma != 0) begin
      errors++; $display("ERROR SFB2 protocol violations: ext %0d host %0d dma %0d", pv_ext, pv_host, pv_dma);
    end
  endtask

  task automatic do_reset(input int cycles);
    #3 rst_n = 1'b0;                      // asynchronous assertion, mid-cycle
    sb_en = 0;                            // program A ends here: nothing more may arrive
    repeat (cycles) @(posedge clk);
    #1 rst_n = 1'b1;                      // synchronous release
    @(posedge clk);
  endtask

  task automatic start_prog(input string dir, input int cont0);
    rcv = 0; skip_run = 0; next_res = 0; hs_total = 0; overlap_cycles = 0; rst_seq = -1;
    n_rec_err = 0; n_rec_skip = 0; n_rec_irq = 0; n_rec_ce = 0; n_dma_exec = 0; n_vec_exec = 0;
    base_err = 0; base_skip = 0; base_dma = 0; base_vec = 0;
    n_ev_irq = 0; n_ev_err = 0; hold_forever = 0;
    synced_active = '0;
    load_prog(dir);
    @(posedge clk); #1; err_cont = 1'(cont0);
    $display("[%0d] program %s: %0d commands, %0d scratchpad init words", cyc, dir, ncmd, nspmi);
    init_memories();
    $display("[%0d] memories initialised", cyc);
    @(posedge clk); #1; perf_clear = 1'b1; @(posedge clk); #1; perf_clear = 1'b0; @(posedge clk);
    // counters were cleared after init traffic; restart the TB-side handshake count
    hs_total = 0;
    sb_en = 1;
    host_run = 1;
    prog_start_cyc = cyc;
  endtask

  // ------------------------------------------------------------------ main
  initial begin
    int seed, reset_at, cont0, ncmd_b, nspmi_b, nspmc_b, nchk_b, cont_b;
    string dir_b;
    cmd_valid = 0; cmd_desc = '0; err_cont = 0; err_clear = 0; perf_clear = 0;
    h_req_valid = 0; h_req_write = 0; h_req_addr = 0; h_req_wdata = 0; h_req_wstrb = 0; h_rsp_ready = 1;
    cpl_ready = 0;
    scr_base = SPM_BASE + 32'h2000;
    void'($value$plusargs("SCRATCH=%h", scr_base));
    if (!$value$plusargs("PROG=%s", prog_dir)) $fatal(1, "+PROG=<dir> required");
    if (!$value$plusargs("NCMD=%d", ncmd)) $fatal(1, "+NCMD required");
    void'($value$plusargs("NSPMI=%d", nspmi));
    void'($value$plusargs("NSPMC=%d", nspmc));
    void'($value$plusargs("NCHK=%d", nchk));
    cont0 = 0; void'($value$plusargs("CONT0=%d", cont0));
    seed = 1; void'($value$plusargs("SEED=%d", seed));
    void'($urandom(seed));
    void'($value$plusargs("GAP=%d", k_gap));
    void'($value$plusargs("CPLRDY=%d", k_cplrdy));
    void'($value$plusargs("XRDY=%d", k_xrdy));
    void'($value$plusargs("LATMIN=%d", k_latmin));
    void'($value$plusargs("LATMAX=%d", k_latmax));
    void'($value$plusargs("HOLD=%d", k_hold));
    k_host = 0; void'($value$plusargs("HOST=%d", k_host));
    void'($value$plusargs("ERR_LO=%h", k_err_lo));
    void'($value$plusargs("ERR_HI=%h", k_err_hi));
    void'($value$plusargs("HANG_LO=%h", k_hang_lo));
    void'($value$plusargs("HANG_HI=%h", k_hang_hi));
    reset_at = -1; void'($value$plusargs("RESET_AT=%d", reset_at));

    repeat (5) @(posedge clk);
    rst_n <= 1'b1;
    @(posedge clk);

    start_prog(prog_dir, cont0);
    run_prog(reset_at);
    if (reset_at >= 0) begin
      // ---------------------------------------------------- reset during activity
      int seen;
      // records keep being checked against program A until reset is really asserted
      host_run = 0;
      while (host_lock) @(posedge clk);
      do_reset(3);
      $display("[%0d] reset was asserted after command %0d (received %0d records of program A)", cyc, reset_at, rcv);
      seen = 0;
      repeat (200) begin
        @(posedge clk);
        if (cpl_valid || busy || !q_empty || rob_count != 0) seen++;
      end
      if (seen != 0) begin errors++; $display("ERROR state survived the reset (%0d cycles)", seen); end
      if (!$value$plusargs("PROGB=%s", dir_b)) $fatal(1, "+PROGB required with +RESET_AT");
      void'($value$plusargs("NCMDB=%d", ncmd_b));
      void'($value$plusargs("NSPMIB=%d", nspmi_b));
      void'($value$plusargs("NSPMCB=%d", nspmc_b));
      void'($value$plusargs("NCHKB=%d", nchk_b));
      cont_b = 0; void'($value$plusargs("CONTB=%d", cont_b));
      void'($value$plusargs("SCRATCHB=%h", scr_base));
      ncmd = ncmd_b; nspmi = nspmi_b; nspmc = nspmc_b; nchk = nchk_b;
      start_prog(dir_b, cont_b);
      run_prog(-1);
    end
    final_checks();
    $display("TB_RESULT %s errors=%0d cmds=%0d prog_cycles=%0d cycles=%0d alt=%0d overlap=%0d hazard_stall=%0d unit_stall=%0d sync_stall=%0d rob_stall=%0d qfull=%0d ext_r=%0d ext_w=%0d",
             errors ? "FAIL" : "PASS", errors, ncmd, last_rec_cyc - prog_start_cyc,
             perf[hpc_cq_pkg::PC_CYCLES*32 +: 32], n_alt_taken,
             overlap_cycles, perf[hpc_cq_pkg::PC_STALL_HAZARD*32 +: 32], perf[hpc_cq_pkg::PC_STALL_UNIT*32 +: 32],
             perf[hpc_cq_pkg::PC_STALL_SYNC*32 +: 32], perf[hpc_cq_pkg::PC_STALL_ROB*32 +: 32],
             perf[hpc_cq_pkg::PC_Q_FULL*32 +: 32], e_nr, e_nw);
    $finish;
  end

  // completion back-pressure
  always @(posedge clk) cpl_ready <= (($urandom % 100) < k_cplrdy);

  // global watchdog
  initial begin
    longint lim;
    lim = 40_000_000;
    void'($value$plusargs("MAXCYC=%d", lim));
    while (cyc < lim) @(posedge clk);
    $display("TB_RESULT FAIL errors=%0d global timeout at %0d cycles (received %0d of %0d)", errors + 1, cyc, rcv, ncmd);
    $finish;
  end
endmodule

`default_nettype wire
