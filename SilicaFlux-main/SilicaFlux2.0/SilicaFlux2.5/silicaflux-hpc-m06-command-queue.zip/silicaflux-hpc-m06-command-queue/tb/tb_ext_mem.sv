// =============================================================================
// SilicaFlux-HPC Module 06 :: tb_ext_mem -- external-memory SFB2 slave model
//
// Verification only.  A word-addressed memory behind an SFB2 slave port
// (DataFabric docs/datafabric/PROTOCOL.md) with:
//   * random request back-pressure      (READY_PCT % of cycles req_ready = 1)
//   * random response latency           (LAT_MIN .. LAT_MAX cycles, >= 1, in order)
//   * error injection                   (accesses in [err_lo_i, err_hi_i) answer
//                                        rsp_error = 1, rdata = 0, no side effect)
//   * hang injection                    (the first access in [hang_lo_i, hang_hi_i)
//                                        is accepted and never answered)
// Writes are performed when the request is accepted, the response follows
// later (SFB2 R7).  Out-of-window addresses answer an error.  Backdoor
// access for the testbench: mem_q[] (word index = (addr - BASE) / 4).
// =============================================================================
`default_nettype none

module tb_ext_mem #(
  parameter logic [31:0] BASE  = 32'h1000_0000,
  parameter int          LOG2  = 17,
  parameter int          QD    = 4
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  // knobs
  input  wire logic [7:0]  ready_pct_i,
  input  wire logic [7:0]  lat_min_i,
  input  wire logic [7:0]  lat_max_i,
  input  wire logic [31:0] err_lo_i,
  input  wire logic [31:0] err_hi_i,
  input  wire logic [31:0] hang_lo_i,
  input  wire logic [31:0] hang_hi_i,
  // SFB2 slave
  input  wire logic        req_valid,
  output logic             req_ready,
  input  wire logic        req_write,
  input  wire logic [31:0] req_addr,
  input  wire logic [31:0] req_wdata,
  input  wire logic [3:0]  req_wstrb,
  output logic             rsp_valid,
  input  wire logic        rsp_ready,
  output logic [31:0]      rsp_rdata,
  output logic             rsp_error,
  // statistics
  output logic [31:0]      n_reads,
  output logic [31:0]      n_writes,
  output logic             hung
);
  localparam int WORDS = 1 << (LOG2 - 2);
  logic [31:0] mem_q [0:WORDS-1];

  // response queue
  logic [31:0] q_data [0:QD-1];
  logic        q_err  [0:QD-1];
  logic [31:0] q_due  [0:QD-1];
  int          q_wr, q_rd, q_n;
  logic [31:0] now;
  logic        rdy_q;

  wire in_win  = (req_addr >= BASE) && ((req_addr - BASE) < (32'd1 << LOG2));
  wire [31:0] widx = (req_addr - BASE) >> 2;
  wire is_err  = !in_win || (req_addr >= err_lo_i && req_addr < err_hi_i);
  wire is_hang = (req_addr >= hang_lo_i && req_addr < hang_hi_i);

  assign req_ready = rdy_q && (q_n < QD) && !hung;
  wire acc = req_valid && req_ready;

  assign rsp_valid = (q_n > 0) && (q_due[q_rd] <= now);
  assign rsp_rdata = rsp_valid ? q_data[q_rd] : 32'd0;
  assign rsp_error = rsp_valid ? q_err[q_rd]  : 1'b0;

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_wr <= 0; q_rd <= 0; q_n <= 0; now <= 0; rdy_q <= 1'b0;
      n_reads <= 0; n_writes <= 0; hung <= 1'b0;
    end else begin
      int lat;
      logic [31:0] d;
      now   <= now + 1;
      rdy_q <= (($urandom % 100) < ready_pct_i);
      if (acc) begin
        if (is_hang) begin
          hung <= 1'b1;                                // accepted, never answered
        end else begin
          lat = int'(lat_min_i);
          if (lat_max_i > lat_min_i) lat = lat + int'($urandom % (lat_max_i - lat_min_i + 1));
          if (lat < 1) lat = 1;
          d = 32'd0;
          if (!is_err) begin
            if (req_write) begin
              d = mem_q[widx];
              for (int b = 0; b < 4; b++) if (req_wstrb[b]) d[8*b +: 8] = req_wdata[8*b +: 8];
              mem_q[widx] <= d;
              d = 32'd0;                               // write responses carry rdata = 0
              n_writes <= n_writes + 1;
            end else begin
              d = mem_q[widx];
              n_reads <= n_reads + 1;
            end
          end
          q_data[q_wr] <= d;
          q_err[q_wr]  <= is_err;
          // responses stay in order: never due before the previous one
          q_due[q_wr]  <= now + 32'(lat);
          q_wr <= (q_wr + 1) % QD;
        end
      end
      if (rsp_valid && rsp_ready) q_rd <= (q_rd + 1) % QD;
      q_n <= q_n + ((acc && !is_hang) ? 1 : 0) - ((rsp_valid && rsp_ready) ? 1 : 0);
    end
  end
endmodule

`default_nettype wire
