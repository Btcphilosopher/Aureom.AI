// =============================================================================
// SilicaFlux-HPC Module 06 :: hpc_cq_sva -- concurrent assertions (bind)
//
// Bound onto every hpc_command_queue instance in the Verilator regression
// (verilator --assert).  Interface and scheduler properties, checked every
// cycle out of reset; complementary to the procedural checks inside the RTL
// (`ifndef SYNTHESIS) and to the testbench's independent monitors.
// =============================================================================
`default_nettype none

module hpc_cq_sva (
  input wire logic         clk_i,
  input wire logic         rst_ni,
  input wire logic         cmd_valid_i,
  input wire logic         cmd_ready_o,
  input wire logic         cpl_valid_o,
  input wire logic         cpl_ready_i,
  input wire logic [127:0] cpl_rec_o,
  input wire logic         q_full_o,
  input wire logic         q_empty_o,
  input wire logic         busy_o,
  input wire logic         dma_start_o,
  input wire logic         dma_done_i,
  input wire logic         dma_fail_i,
  input wire logic         vec_start_o,
  input wire logic         vec_done_i,
  input wire logic         vec_fail_i,
  input wire logic         trc_dma_act_o,
  input wire logic         trc_vec_act_o,
  input wire logic         trc_resolve_o,
  input wire logic [31:0]  trc_seq_o,
  input wire logic         ev_commit_o
);
  default clocking cb @(posedge clk_i); endclocking

  // queue overflow prevention: a full queue never offers ready
  a_full_not_ready:   assert property (disable iff (!rst_ni) q_full_o |-> !cmd_ready_o);
  // completion channel: a presented record is held, unchanged, until taken
  a_cpl_hold:         assert property (disable iff (!rst_ni) cpl_valid_o && !cpl_ready_i |=> cpl_valid_o && $stable(cpl_rec_o));
  a_cpl_zero:         assert property (disable iff (!rst_ni) !cpl_valid_o |-> cpl_rec_o == 128'd0);
  // completion underflow prevention: no record without an accepted command
  a_cpl_needs_busy:   assert property (disable iff (!rst_ni) cpl_valid_o |-> busy_o);
  // unit start pulses are single-cycle and only while the unit is free
  a_dma_start_pulse:  assert property (disable iff (!rst_ni) dma_start_o |=> !dma_start_o);
  a_vec_start_pulse:  assert property (disable iff (!rst_ni) vec_start_o |=> !vec_start_o);
  a_dma_start_free:   assert property (disable iff (!rst_ni) dma_start_o |-> trc_dma_act_o && $past(!trc_dma_act_o));
  a_vec_start_free:   assert property (disable iff (!rst_ni) vec_start_o |-> trc_vec_act_o && $past(!trc_vec_act_o));
  // a job completes at most once and the unit is free in the next cycle
  a_dma_fin_once:     assert property (disable iff (!rst_ni) (dma_done_i || dma_fail_i) && trc_dma_act_o |=> !trc_dma_act_o);
  a_vec_fin_once:     assert property (disable iff (!rst_ni) (vec_done_i || vec_fail_i) && trc_vec_act_o |=> !trc_vec_act_o);
  a_dma_not_both:     assert property (disable iff (!rst_ni) !(dma_done_i && dma_fail_i));
  a_vec_not_both:     assert property (disable iff (!rst_ni) !(vec_done_i && vec_fail_i));
  // in-order issue: consecutive decode releases carry consecutive SEQ
  logic [31:0] last_seq;
  logic        have_seq;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      have_seq <= 1'b0;
      last_seq <= 32'd0;
    end else if (trc_resolve_o) begin
      have_seq <= 1'b1;
      last_seq <= trc_seq_o;
    end
  end
  a_in_order_issue:   assert property (disable iff (!rst_ni) trc_resolve_o && have_seq |-> trc_seq_o == last_seq + 32'd1);
  // in-order completion: consecutive records carry consecutive SEQ
  logic [31:0] last_rec_seq;
  logic        have_rec;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      have_rec     <= 1'b0;
      last_rec_seq <= 32'd0;
    end else if (cpl_valid_o && cpl_ready_i) begin
      have_rec     <= 1'b1;
      last_rec_seq <= cpl_rec_o[127:96];
    end
  end
  a_in_order_retire:  assert property (disable iff (!rst_ni) cpl_valid_o && cpl_ready_i && have_rec |-> cpl_rec_o[127:96] == last_rec_seq + 32'd1);
  a_first_rec_seq0:   assert property (disable iff (!rst_ni) cpl_valid_o && cpl_ready_i && !have_rec |-> cpl_rec_o[127:96] == 32'd0);

  c_overlap:          cover property (disable iff (!rst_ni) trc_dma_act_o && trc_vec_act_o);
  c_queue_full:       cover property (disable iff (!rst_ni) cmd_valid_i && q_full_o);
  c_cpl_bp:           cover property (disable iff (!rst_ni) cpl_valid_o && !cpl_ready_i);
endmodule

bind hpc_command_queue hpc_cq_sva u_sva (
  .clk_i, .rst_ni, .cmd_valid_i, .cmd_ready_o, .cpl_valid_o, .cpl_ready_i, .cpl_rec_o,
  .q_full_o, .q_empty_o, .busy_o, .dma_start_o, .dma_done_i, .dma_fail_i,
  .vec_start_o, .vec_done_i, .vec_fail_i, .trc_dma_act_o, .trc_vec_act_o,
  .trc_resolve_o, .trc_seq_o, .ev_commit_o
);

`default_nettype wire
