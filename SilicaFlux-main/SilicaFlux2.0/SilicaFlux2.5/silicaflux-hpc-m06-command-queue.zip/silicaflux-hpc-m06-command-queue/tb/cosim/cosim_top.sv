// =============================================================================
// SilicaFlux-HPC Module 06 :: cosim_top -- host co-simulation top
//
// Register bus (driven by the C host program through tb/cosim/cosim_main.cpp)
//   -> hpc_cq_mmio -> hpc_cq_tile -> tb_ext_mem (external memory, backdoor
//   access for the program through DPI: cosim_mem_wr / cosim_mem_rd).
// The CPU-to-scratchpad host port of the tile is idle (tied off).
// =============================================================================
`default_nettype none

module cosim_top (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  output logic             irq
);
  localparam int QD = 4, RD = 8;
  logic         cmd_valid, cmd_ready, cpl_valid, cpl_ready, err_cont, err_clear, perf_clear;
  logic [255:0] cmd_desc;
  logic [127:0] cpl_rec;
  logic         busy, q_full, q_empty, sticky, dma_down, vec_down, ev_c, ev_ce, ev_ci;
  logic [$clog2(QD+1)-1:0] q_count;
  logic [$clog2(RD+1)-1:0] rob_count;
  logic [hpc_cq_pkg::PC_N*32-1:0] perf;
  logic e_req_valid, e_req_ready, e_req_write, e_rsp_valid, e_rsp_ready, e_rsp_error;
  logic [31:0] e_req_addr, e_req_wdata, e_rsp_rdata, e_nr, e_nw;
  logic [3:0]  e_req_wstrb;
  logic        e_hung;

  hpc_cq_mmio #(.QUEUE_DEPTH(QD), .ROB_DEPTH(RD)) u_mmio (
    .clk_i(clk), .rst_ni(rst_n), .rb_sel, .rb_we, .rb_addr, .rb_wdata, .rb_rdata, .rb_err, .irq_o(irq),
    .cmd_valid_o(cmd_valid), .cmd_ready_i(cmd_ready), .cmd_desc_o(cmd_desc),
    .cpl_valid_i(cpl_valid), .cpl_ready_o(cpl_ready), .cpl_rec_i(cpl_rec),
    .ctrl_err_cont_o(err_cont), .ctrl_err_clear_o(err_clear), .ctrl_perf_clear_o(perf_clear),
    .busy_i(busy), .q_count_i(q_count), .q_full_i(q_full), .q_empty_i(q_empty), .rob_count_i(rob_count),
    .err_sticky_i(sticky), .dma_down_i(dma_down), .vec_down_i(vec_down),
    .ev_commit_err_i(ev_ce), .ev_commit_irq_i(ev_ci), .perf_cnt_i(perf)
  );

  hpc_cq_tile #(.QUEUE_DEPTH(QD), .ROB_DEPTH(RD), .NUM_LANES(2)) u_tile (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_desc_i(cmd_desc),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_rec_o(cpl_rec),
    .ctrl_err_cont_i(err_cont), .ctrl_err_clear_i(err_clear), .ctrl_perf_clear_i(perf_clear),
    .busy_o(busy), .q_count_o(q_count), .q_full_o(q_full), .q_empty_o(q_empty), .rob_count_o(rob_count),
    .err_sticky_o(sticky), .dma_down_o(dma_down), .vec_down_o(vec_down),
    .ev_commit_o(ev_c), .ev_commit_err_o(ev_ce), .ev_commit_irq_o(ev_ci), .perf_cnt_o(perf),
    .host_req_valid_i(1'b0), .host_req_ready_o(), .host_req_write_i(1'b0), .host_req_addr_i(32'd0),
    .host_req_wdata_i(32'd0), .host_req_wstrb_i(4'd0), .host_rsp_valid_o(), .host_rsp_ready_i(1'b1),
    .host_rsp_rdata_o(), .host_rsp_error_o(),
    .ext_req_valid_o(e_req_valid), .ext_req_ready_i(e_req_ready), .ext_req_write_o(e_req_write),
    .ext_req_addr_o(e_req_addr), .ext_req_wdata_o(e_req_wdata), .ext_req_wstrb_o(e_req_wstrb),
    .ext_rsp_valid_i(e_rsp_valid), .ext_rsp_ready_o(e_rsp_ready), .ext_rsp_rdata_i(e_rsp_rdata),
    .ext_rsp_error_i(e_rsp_error),
    .lane_hold_i(2'b00),
    .trc_resolve_o(), .trc_seq_o(), .trc_dma_act_o(), .trc_dma_seq_o(), .trc_vec_act_o(), .trc_vec_seq_o()
  );

  tb_ext_mem #(.BASE(32'h1000_0000), .LOG2(17)) u_ext (
    .clk, .rst_n, .ready_pct_i(8'd100), .lat_min_i(8'd2), .lat_max_i(8'd2),
    .err_lo_i(32'd0), .err_hi_i(32'd0), .hang_lo_i(32'd0), .hang_hi_i(32'd0),
    .req_valid(e_req_valid), .req_ready(e_req_ready), .req_write(e_req_write), .req_addr(e_req_addr),
    .req_wdata(e_req_wdata), .req_wstrb(e_req_wstrb), .rsp_valid(e_rsp_valid), .rsp_ready(e_rsp_ready),
    .rsp_rdata(e_rsp_rdata), .rsp_error(e_rsp_error), .n_reads(e_nr), .n_writes(e_nw), .hung(e_hung)
  );

  export "DPI-C" function cosim_mem_wr;
  export "DPI-C" function cosim_mem_rd;
  function void cosim_mem_wr(input int unsigned a, input int unsigned v);
    u_ext.mem_q[(a - 32'h1000_0000) >> 2] = v;
  endfunction
  function int unsigned cosim_mem_rd(input int unsigned a);
    return u_ext.mem_q[(a - 32'h1000_0000) >> 2];
  endfunction
endmodule

`default_nettype wire
