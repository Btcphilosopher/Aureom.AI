// =============================================================================
// SilicaFlux-HPC Module 06 :: cosim_main -- runs the host example on the RTL
//
// Implements the driver's register hooks (HPC_CQ_COSIM) as real register-bus
// cycles on cosim_top: a write / read is a one-cycle rb_sel strobe; rb_rdata
// and rb_err are sampled in the strobe cycle (combinational, as on the
// SilicaFlux-V bus); the hardware keeps running between accesses.
// =============================================================================
#include <cstdarg>
#include <cstdio>
#include <cstdint>
#include "Vcosim_top.h"
#include "Vcosim_top__Dpi.h"
#include "svdpi.h"
#include "verilated.h"

static Vcosim_top *top;
static uint64_t cycles;

static void tick() {
  top->clk = 0; top->eval();
  top->clk = 1; top->eval();
  cycles++;
}

extern "C" int cosim_wr32(uint32_t off, uint32_t v) {
  top->rb_sel = 1; top->rb_we = 1; top->rb_addr = off & 0xFFF; top->rb_wdata = v;
  top->clk = 0; top->eval();
  int err = top->rb_err;
  top->clk = 1; top->eval(); cycles++;
  top->rb_sel = 0; top->rb_we = 0;
  return err;
}

extern "C" uint32_t cosim_rd32(uint32_t off) {
  top->rb_sel = 1; top->rb_we = 0; top->rb_addr = off & 0xFFF;
  top->clk = 0; top->eval();
  uint32_t v = top->rb_rdata;
  top->clk = 1; top->eval(); cycles++;
  top->rb_sel = 0;
  return v;
}

static void set_scope() { svSetScope(svGetScopeFromName("TOP.cosim_top")); }

extern "C" void demo_mem_wr32(uint32_t a, uint32_t v) { set_scope(); cosim_mem_wr(a, v); }
extern "C" uint32_t demo_mem_rd32(uint32_t a) { set_scope(); return cosim_mem_rd(a); }
extern "C" void demo_log(const char *fmt, ...) {
  va_list ap; va_start(ap, fmt); vprintf(fmt, ap); va_end(ap); fflush(stdout);
}
extern "C" int cq_demo(void);

int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);
  top = new Vcosim_top;
  top->rst_n = 0; top->rb_sel = 0; top->rb_we = 0; top->rb_addr = 0; top->rb_wdata = 0;
  for (int i = 0; i < 4; i++) tick();
  top->rst_n = 1;
  for (int i = 0; i < 2; i++) tick();
  int fails = cq_demo();
  printf("co-simulation: %llu cycles\n", (unsigned long long)cycles);
  top->final();
  delete top;
  return fails ? 1 : 0;
}
