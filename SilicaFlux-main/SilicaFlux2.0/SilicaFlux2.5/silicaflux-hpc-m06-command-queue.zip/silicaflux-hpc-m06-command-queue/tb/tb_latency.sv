// =============================================================================
// SilicaFlux-HPC Module 06 :: tb_latency -- pipeline timing probe
//
// Measures, on the real tile, the cycle at which each stage happens relative
// to the command-acceptance edge t (= 0): decode-slot entry, decode release
// (trc_resolve), unit start pulse, record valid.  Also the steady-state rate
// of back-to-back NOPs.  Prints LAT lines (docs/02 sec. 3.6, reports/perf.md).
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_latency;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  logic         cmd_valid = 0, cmd_ready, cpl_valid, cpl_ready = 1;
  logic [255:0] cmd_desc = '0;
  logic [127:0] cpl_rec;
  logic         t_res;
  logic [31:0]  t_seq;
  logic e_req_valid, e_req_write, e_rsp_ready;
  logic [31:0] e_req_addr, e_req_wdata;
  logic [3:0]  e_req_wstrb;
  logic        rsp_v = 1'b0;

  hpc_cq_tile #(.QUEUE_DEPTH(8)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_desc_i(cmd_desc),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_rec_o(cpl_rec),
    .ctrl_err_cont_i(1'b0), .ctrl_err_clear_i(1'b0), .ctrl_perf_clear_i(1'b0),
    .busy_o(), .q_count_o(), .q_full_o(), .q_empty_o(), .rob_count_o(), .err_sticky_o(),
    .dma_down_o(), .vec_down_o(), .ev_commit_o(), .ev_commit_err_o(), .ev_commit_irq_o(), .perf_cnt_o(),
    .host_req_valid_i(1'b0), .host_req_ready_o(), .host_req_write_i(1'b0), .host_req_addr_i(32'd0),
    .host_req_wdata_i(32'd0), .host_req_wstrb_i(4'd0), .host_rsp_valid_o(), .host_rsp_ready_i(1'b1),
    .host_rsp_rdata_o(), .host_rsp_error_o(),
    .ext_req_valid_o(e_req_valid), .ext_req_ready_i(1'b1), .ext_req_write_o(e_req_write),
    .ext_req_addr_o(e_req_addr), .ext_req_wdata_o(e_req_wdata), .ext_req_wstrb_o(e_req_wstrb),
    .ext_rsp_valid_i(rsp_v), .ext_rsp_ready_o(e_rsp_ready), .ext_rsp_rdata_i(32'd0), .ext_rsp_error_i(1'b0),
    .lane_hold_i(2'b00),
    .trc_resolve_o(t_res), .trc_seq_o(t_seq), .trc_dma_act_o(), .trc_dma_seq_o(), .trc_vec_act_o(), .trc_vec_seq_o()
  );
  // 1-cycle external memory: answer every accepted request in the next cycle
  always @(posedge clk) rsp_v <= e_req_valid;

  function automatic logic [255:0] d(input logic [7:0] op, input logic [31:0] sa, input logic [31:0] da,
                                     input logic [31:0] len);
    d = {32'd0, 32'd0, 32'd0, len, da, 32'd0, sa, {8'd0, 8'd0, 4'd0, 4'd1, op}};
  endfunction

  longint t_acc, t_res_c, t_start, t_cpl;
  always @(posedge clk) begin
    if (t_res && t_res_c < 0) t_res_c = cyc - t_acc;
    if (dut.dma_start && t_start < 0) t_start = cyc - t_acc;
    if (cpl_valid && t_cpl < 0) t_cpl = cyc - t_acc;
  end

  task automatic one(input logic [255:0] x, input string what);
    t_res_c = -1; t_start = -1; t_cpl = -1;
    @(posedge clk); #1 cmd_desc = x; cmd_valid = 1;
    @(negedge clk); while (!cmd_ready) @(negedge clk);
    @(posedge clk); t_acc = cyc; #1 cmd_valid = 0;
    while (t_cpl < 0) @(posedge clk);
    repeat (5) @(posedge clk);
    $display("LAT %-28s decode-release t+%0d  unit-start %s  record-valid t+%0d", what, t_res_c,
             t_start < 0 ? "-" : $sformatf("t+%0d", t_start), t_cpl);
  endtask

  initial begin
    longint t0, t1;
    int n;
    repeat (3) @(posedge clk);
    rst_n = 1;
    repeat (3) @(posedge clk);
    one(d(8'h00, 0, 0, 0), "NOP");
    one(d(8'h20, 0, 0, 0), "FENCE");
    one(d(8'h01, 32'h1000_0000, 32'h2000_0000, 4), "DMA_LOAD 4 B");
    one(d(8'h01, 32'h1000_0000, 32'h2000_0000, 64), "DMA_LOAD 64 B");
    one(d(8'h77, 0, 0, 0), "invalid opcode (last: sticky)");
    // back-to-back NOP rate: valid held high for 64 commands
    n = 0;
    @(posedge clk); #1 cmd_desc = d(8'h00, 0, 0, 0); cmd_valid = 1;
    t0 = cyc;
    while (n < 64) begin @(negedge clk); if (cmd_ready) n++; @(posedge clk); end
    #1 cmd_valid = 0;
    t1 = cyc;
    $display("LAT back-to-back NOP: 64 commands accepted in %0d cycles", t1 - t0);
    $finish;
  end
endmodule

`default_nettype wire
