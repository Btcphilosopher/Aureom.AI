// =============================================================================
// SilicaFlux-HPC Module 06 :: tb_smoke -- directed stage-1 bring-up test
//
// NOP, DMA_LOAD, VECTOR_ADD and FENCE end to end on hpc_cq_tile:
//   ext A, B --DMA_LOAD--> SPM --VECTOR_ADD--> SPM D --FENCE--> host reads D
// FP operands are small integers (exact sums), so the check needs no FP model.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_smoke;
  localparam int N = 2;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;

  logic         cmd_valid, cmd_ready, cpl_valid, cpl_ready;
  logic [255:0] cmd_desc;
  logic [127:0] cpl_rec;
  logic h_req_valid, h_req_ready, h_req_write, h_rsp_valid, h_rsp_ready, h_rsp_error;
  logic [31:0] h_req_addr, h_req_wdata, h_rsp_rdata;
  logic [3:0]  h_req_wstrb;
  logic e_req_valid, e_req_ready, e_req_write, e_rsp_valid, e_rsp_ready, e_rsp_error;
  logic [31:0] e_req_addr, e_req_wdata, e_rsp_rdata;
  logic [3:0]  e_req_wstrb;
  logic [31:0] e_nr, e_nw;
  logic        e_hung;

  hpc_cq_tile #(.QUEUE_DEPTH(4), .NUM_LANES(N)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_desc_i(cmd_desc),
    .cpl_valid_o(cpl_valid), .cpl_ready_i(cpl_ready), .cpl_rec_o(cpl_rec),
    .ctrl_err_cont_i(1'b0), .ctrl_err_clear_i(1'b0), .ctrl_perf_clear_i(1'b0),
    .busy_o(), .q_count_o(), .q_full_o(), .q_empty_o(), .rob_count_o(), .err_sticky_o(),
    .dma_down_o(), .vec_down_o(), .ev_commit_o(), .ev_commit_err_o(), .ev_commit_irq_o(),
    .perf_cnt_o(),
    .host_req_valid_i(h_req_valid), .host_req_ready_o(h_req_ready), .host_req_write_i(h_req_write),
    .host_req_addr_i(h_req_addr), .host_req_wdata_i(h_req_wdata), .host_req_wstrb_i(h_req_wstrb),
    .host_rsp_valid_o(h_rsp_valid), .host_rsp_ready_i(h_rsp_ready), .host_rsp_rdata_o(h_rsp_rdata),
    .host_rsp_error_o(h_rsp_error),
    .ext_req_valid_o(e_req_valid), .ext_req_ready_i(e_req_ready), .ext_req_write_o(e_req_write),
    .ext_req_addr_o(e_req_addr), .ext_req_wdata_o(e_req_wdata), .ext_req_wstrb_o(e_req_wstrb),
    .ext_rsp_valid_i(e_rsp_valid), .ext_rsp_ready_o(e_rsp_ready), .ext_rsp_rdata_i(e_rsp_rdata),
    .ext_rsp_error_i(e_rsp_error),
    .lane_hold_i('0),
    .trc_resolve_o(), .trc_seq_o(), .trc_dma_act_o(), .trc_dma_seq_o(), .trc_vec_act_o(), .trc_vec_seq_o()
  );

  tb_ext_mem #(.BASE(32'h1000_0000), .LOG2(17)) u_ext (
    .clk, .rst_n, .ready_pct_i(8'd70), .lat_min_i(8'd1), .lat_max_i(8'd3),
    .err_lo_i(32'd0), .err_hi_i(32'd0), .hang_lo_i(32'd0), .hang_hi_i(32'd0),
    .req_valid(e_req_valid), .req_ready(e_req_ready), .req_write(e_req_write), .req_addr(e_req_addr),
    .req_wdata(e_req_wdata), .req_wstrb(e_req_wstrb), .rsp_valid(e_rsp_valid), .rsp_ready(e_rsp_ready),
    .rsp_rdata(e_rsp_rdata), .rsp_error(e_rsp_error), .n_reads(e_nr), .n_writes(e_nw), .hung(e_hung)
  );

  function automatic logic [255:0] desc(input logic [7:0] op, input logic [7:0] fl, input logic [7:0] tid,
                                        input logic [2:0] rm, input logic [31:0] sa, input logic [31:0] sb,
                                        input logic [31:0] d, input logic [31:0] len);
    desc = {32'd0, 32'd0, 32'd0, len, d, sb, sa, {tid, fl, 1'b0, rm, 4'd1, op}};
  endfunction

  function automatic logic [31:0] i2f(input int v);   // small non-negative integer -> FP32
    logic [31:0] f; int e;
    if (v == 0) begin i2f = 32'd0; end
    else begin
      e = 0; while ((v >> (e + 1)) != 0) e++;
      f = {1'b0, 8'(127 + e), 23'((v << (23 - e)) & 32'h7F_FFFF)};
      i2f = f;
    end
  endfunction

  int errors = 0;
  logic [127:0] recs [0:31];
  int nrec = 0;
  always @(posedge clk) if (cpl_valid && cpl_ready) begin recs[nrec] <= cpl_rec; nrec <= nrec + 1; end

  task automatic submit(input logic [255:0] d);
    cmd_desc  <= d;
    cmd_valid <= 1'b1;
    @(posedge clk);
    while (!cmd_ready) @(posedge clk);
    cmd_valid <= 1'b0;
  endtask

  task automatic host_read(input logic [31:0] a, output logic [31:0] v);
    h_req_valid <= 1'b1; h_req_write <= 1'b0; h_req_addr <= a; h_req_wstrb <= 4'hF;
    @(posedge clk);
    while (!h_req_ready) @(posedge clk);
    h_req_valid <= 1'b0;
    while (!h_rsp_valid) @(posedge clk);
    v = h_rsp_rdata;
    @(posedge clk);
  endtask

  localparam int VL = 37;
  initial begin
    logic [31:0] v;
    cmd_valid = 1'b0; cmd_desc = '0; cpl_ready = 1'b1;
    h_req_valid = 1'b0; h_req_write = 1'b0; h_req_addr = '0; h_req_wdata = '0; h_req_wstrb = '0;
    h_rsp_ready = 1'b1;
    for (int i = 0; i < VL; i++) begin
      u_ext.mem_q[i]       = i2f(i);           // A at 0x1000_0000
      u_ext.mem_q[256 + i] = i2f(3 * i + 1);   // B at 0x1000_0400
    end
    repeat (3) @(posedge clk);
    rst_n = 1'b1;
    repeat (2) @(posedge clk);
    submit(desc(8'h00, 8'h00, 8'd1, 3'd0, 0, 0, 0, 0));                                     // NOP
    submit(desc(8'h01, 8'h00, 8'd2, 3'd0, 32'h1000_0000, 0, 32'h2000_0000, VL * 4));         // A -> SPM
    submit(desc(8'h01, 8'h00, 8'd3, 3'd0, 32'h1000_0400, 0, 32'h2000_1000, VL * 4));         // B -> SPM
    submit(desc(8'h10, 8'h00, 8'd4, 3'd0, 32'h2000_0000, 32'h2000_1000, 32'h2000_2000, VL)); // D = A + B
    submit(desc(8'h20, 8'h01, 8'd5, 3'd0, 0, 0, 0, 0));                                     // FENCE (irq)
    submit(desc(8'h77, 8'h00, 8'd6, 3'd0, 0, 0, 0, 0));                                     // bad opcode
    submit(desc(8'h00, 8'h00, 8'd7, 3'd0, 0, 0, 0, 0));                                     // NOP (skipped)
    begin
      int t; t = 0;
      while (nrec < 7 && t < 20000) begin @(posedge clk); t++; end
      if (nrec < 7) begin $display("TIMEOUT"); errors++; end
    end
    for (int i = 0; i < nrec; i++)
      $display("rec %0d: seq=%0d tid=%0d op=%02h st=%0d err=%02h cnt=%0d ea=%08h ff=%02h", i,
               recs[i][127:96], recs[i][7:0], recs[i][15:8], recs[i][25:24], recs[i][23:16],
               recs[i][63:32], recs[i][95:64], recs[i][31:27]);
    for (int i = 0; i < VL; i++) begin
      host_read(32'h2000_2000 + 4 * i, v);
      if (v !== i2f(4 * i + 1)) begin
        errors++; $display("D[%0d] = %08h, expected %08h", i, v, i2f(4 * i + 1));
      end
    end
    if (recs[0][25:24] != 0 || recs[1][25:24] != 0 || recs[2][25:24] != 0 || recs[3][25:24] != 0 ||
        recs[4][25:24] != 0) errors++;
    if (recs[1][63:32] != VL * 4 || recs[3][63:32] != VL) errors++;
    if (recs[5][25:24] != 1 || recs[5][23:16] != 8'h02) errors++;
    if (recs[6][25:24] != 2 || recs[6][23:16] != 8'h40) errors++;
    for (int i = 0; i < 7; i++) if (recs[i][127:96] != i || recs[i][7:0] != i + 1) errors++;
    $display("%s: %0d errors, ext reads %0d writes %0d", errors ? "FAIL" : "PASS", errors, e_nr, e_nw);
    $finish;
  end
endmodule

`default_nettype wire
