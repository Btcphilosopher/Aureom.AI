/* =============================================================================
 * SilicaFlux-HPC Module 06 -- command-queue host driver (bare metal, no libc)
 * See hpc_cq.h.
 * ===========================================================================*/
#include "hpc_cq.h"

static void desc_clear(hpc_cq_desc_t *d) {
  for (unsigned i = 0; i < HPC_CQ_DESC_WORDS; i++) d->w[i] = 0;
}

static uint32_t hdr(uint32_t op, uint32_t tid, uint32_t flags, uint32_t rm) {
  return (op << HPC_CQ_H_OP_LSB) | (HPC_CQ_ABI_VERSION << HPC_CQ_H_VER_LSB) |
         ((rm & 7u) << HPC_CQ_H_RM_LSB) | ((flags & 0xFFu) << HPC_CQ_H_FLAGS_LSB) |
         ((tid & 0xFFu) << HPC_CQ_H_TID_LSB);
}

void hpc_cq_desc_nop(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags) {
  desc_clear(d);
  d->w[HPC_CQ_W_HDR] = hdr(HPC_CQ_OP_NOP, tid, flags, 0);
}

void hpc_cq_desc_fence(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags) {
  desc_clear(d);
  d->w[HPC_CQ_W_HDR] = hdr(HPC_CQ_OP_FENCE, tid, flags, 0);
}

void hpc_cq_desc_reset_counters(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags) {
  desc_clear(d);
  d->w[HPC_CQ_W_HDR] = hdr(HPC_CQ_OP_RESET_COUNTERS, tid, flags, 0);
}

void hpc_cq_desc_dma_load(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags,
                          uint32_t ext_src, uint32_t spm_dst, uint32_t bytes) {
  desc_clear(d);
  d->w[HPC_CQ_W_HDR]   = hdr(HPC_CQ_OP_DMA_LOAD, tid, flags, 0);
  d->w[HPC_CQ_W_SRC_A] = ext_src;
  d->w[HPC_CQ_W_DST]   = spm_dst;
  d->w[HPC_CQ_W_LEN]   = bytes;
}

void hpc_cq_desc_dma_store(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags,
                           uint32_t spm_src, uint32_t ext_dst, uint32_t bytes) {
  desc_clear(d);
  d->w[HPC_CQ_W_HDR]   = hdr(HPC_CQ_OP_DMA_STORE, tid, flags, 0);
  d->w[HPC_CQ_W_SRC_A] = spm_src;
  d->w[HPC_CQ_W_DST]   = ext_dst;
  d->w[HPC_CQ_W_LEN]   = bytes;
}

void hpc_cq_desc_vector(hpc_cq_desc_t *d, uint8_t opcode, uint8_t tid, uint8_t flags,
                        uint8_t rm, uint32_t a, uint32_t b, uint32_t dst, uint32_t n) {
  desc_clear(d);
  d->w[HPC_CQ_W_HDR]   = hdr(opcode, tid, flags, rm);
  d->w[HPC_CQ_W_SRC_A] = a;
  d->w[HPC_CQ_W_SRC_B] = b;
  d->w[HPC_CQ_W_DST]   = dst;
  d->w[HPC_CQ_W_LEN]   = n;
}

/* ------------------------------------------------------------------ pre-check */
static int in_win(uint32_t lo, uint64_t len, uint32_t base, uint32_t size) {
  return lo >= base && (uint64_t)lo + len <= (uint64_t)base + size;
}

static int part_overlap(uint32_t d, uint32_t s, uint64_t n) {
  return d != s && (uint64_t)d < (uint64_t)s + n && (uint64_t)s < (uint64_t)d + n;
}

int hpc_cq_check(const hpc_cq_desc_t *d) {
  uint32_t w0 = d->w[HPC_CQ_W_HDR];
  uint32_t op = (w0 >> HPC_CQ_H_OP_LSB) & 0xFFu, ver = (w0 >> HPC_CQ_H_VER_LSB) & 0xFu;
  uint32_t rm = (w0 >> HPC_CQ_H_RM_LSB) & 7u, fl = (w0 >> HPC_CQ_H_FLAGS_LSB) & 0xFFu;
  uint32_t sa = d->w[HPC_CQ_W_SRC_A], sb = d->w[HPC_CQ_W_SRC_B], da = d->w[HPC_CQ_W_DST];
  uint32_t len = d->w[HPC_CQ_W_LEN], st = d->w[HPC_CQ_W_STRIDE];
  int dma = op == HPC_CQ_OP_DMA_LOAD || op == HPC_CQ_OP_DMA_STORE;
  int vec = op == HPC_CQ_OP_VECTOR_ADD || op == HPC_CQ_OP_VECTOR_MUL || op == HPC_CQ_OP_VECTOR_FMA;
  int ctl = op == HPC_CQ_OP_NOP || op == HPC_CQ_OP_FENCE || op == HPC_CQ_OP_RESET_COUNTERS;
  uint64_t nb = (uint64_t)len * 4u;

  if (ver != HPC_CQ_ABI_VERSION) return HPC_CQ_ERR_VERSION;
  if (!dma && !vec && !ctl) return HPC_CQ_ERR_OPCODE;
  if (fl & ~HPC_CQ_FLAGS_V1_MASK) return HPC_CQ_ERR_FLAGS;
  if ((w0 >> HPC_CQ_H_RSVD_BIT) & 1u || d->w[HPC_CQ_W_RSVD6] || d->w[HPC_CQ_W_RSVD7] ||
      (dma && (sb || rm)) || (ctl && (sa || sb || da || len || st || rm)))
    return HPC_CQ_ERR_RSVD;
  if ((dma || vec) && st) return HPC_CQ_ERR_STRIDE;
  if (vec && rm > HPC_CQ_RM_RMM) return HPC_CQ_ERR_RM;
  if (dma && (len == 0 || len > HPC_CQ_DMA_MAX)) return HPC_CQ_ERR_LENGTH;
  if (vec && (len == 0 || len > HPC_CQ_VL_MAX)) return HPC_CQ_ERR_LENGTH;
  if (dma && ((sa | da) & 3u)) return HPC_CQ_ERR_ALIGN;
  if (vec && ((sa | sb | da) & 3u)) return HPC_CQ_ERR_ALIGN;
  if (op == HPC_CQ_OP_DMA_LOAD &&
      !(in_win(sa, len, HPC_CQ_EXT_BASE, HPC_CQ_EXT_SIZE) && in_win(da, len, HPC_CQ_SPM_BASE, HPC_CQ_SPM_SIZE)))
    return HPC_CQ_ERR_RANGE;
  if (op == HPC_CQ_OP_DMA_STORE &&
      !(in_win(sa, len, HPC_CQ_SPM_BASE, HPC_CQ_SPM_SIZE) && in_win(da, len, HPC_CQ_EXT_BASE, HPC_CQ_EXT_SIZE)))
    return HPC_CQ_ERR_RANGE;
  if (vec && !(in_win(sa, nb, HPC_CQ_SPM_BASE, HPC_CQ_SPM_SIZE) && in_win(sb, nb, HPC_CQ_SPM_BASE, HPC_CQ_SPM_SIZE) &&
               in_win(da, nb, HPC_CQ_SPM_BASE, HPC_CQ_SPM_SIZE)))
    return HPC_CQ_ERR_RANGE;
  if (vec && (part_overlap(da, sa, nb) || part_overlap(da, sb, nb))) return HPC_CQ_ERR_OVERLAP;
  return HPC_CQ_ERR_NONE;
}

/* ------------------------------------------------------------------ device */
int hpc_cq_init(void) {
  if (HPC_CQ_RD32(HPC_CQ_REG_ID) != HPC_CQ_ID_VALUE) return HPC_CQ_ENODEV;
  if ((HPC_CQ_RD32(HPC_CQ_REG_INFO) & 0xFu) != HPC_CQ_ABI_VERSION) return HPC_CQ_ENODEV;
  (void)HPC_CQ_WR32(HPC_CQ_REG_INT_ENABLE, 0);
  (void)HPC_CQ_WR32(HPC_CQ_REG_INT_STATUS, HPC_CQ_INT_IRQ | HPC_CQ_INT_ERR);
  (void)HPC_CQ_WR32(HPC_CQ_REG_CTRL, 0);              /* stop on error */
  return 0;
}

uint32_t hpc_cq_status(void) { return HPC_CQ_RD32(HPC_CQ_REG_STATUS); }

uint32_t hpc_cq_free_slots(void) { return HPC_CQ_STATUS_Q_FREE(hpc_cq_status()); }

int hpc_cq_submit(const hpc_cq_desc_t *d) {
  if (hpc_cq_free_slots() == 0) return HPC_CQ_EBUSY;
  for (unsigned i = 0; i < HPC_CQ_DESC_WORDS; i++)
    if (HPC_CQ_WR32(HPC_CQ_REG_DESC0 + 4u * i, d->w[i])) return HPC_CQ_EBUS;
  /* the doorbell is the only write with an effect on the queue: exactly one
   * command is accepted, or the write is refused and nothing happens */
  if (HPC_CQ_WR32(HPC_CQ_REG_DOORBELL, 1u)) return HPC_CQ_EBUSY;
  return 0;
}

int hpc_cq_poll(hpc_cq_cpl_t *c) {
  uint32_t w[HPC_CQ_REC_WORDS];
  if (!(hpc_cq_status() & HPC_CQ_STATUS_CPL_VALID)) return 0;
  for (unsigned i = 0; i < HPC_CQ_REC_WORDS; i++) w[i] = HPC_CQ_RD32(HPC_CQ_REG_CPL0 + 4u * i);
  (void)HPC_CQ_WR32(HPC_CQ_REG_CPL_POP, 1u);
  c->tid      = (uint8_t)(w[0] >> HPC_CQ_R_TID_LSB);
  c->op       = (uint8_t)(w[0] >> HPC_CQ_R_OP_LSB);
  c->err      = (uint8_t)(w[0] >> HPC_CQ_R_ERR_LSB);
  c->status   = (uint8_t)((w[0] >> HPC_CQ_R_STATUS_LSB) & 3u);
  c->irq      = (uint8_t)((w[0] >> HPC_CQ_R_IRQ_BIT) & 1u);
  c->fflags   = (uint8_t)((w[0] >> HPC_CQ_R_FFLAGS_LSB) & 0x1Fu);
  c->count    = w[1];
  c->err_addr = w[2];
  c->seq      = w[3];
  return 1;
}

int hpc_cq_wait(hpc_cq_cpl_t *c, uint32_t max_polls) {
  for (uint32_t i = 0; i < max_polls; i++)
    if (hpc_cq_poll(c)) return 0;
  return HPC_CQ_ETIMEDOUT;
}

void hpc_cq_set_continue_on_error(int cont) { (void)HPC_CQ_WR32(HPC_CQ_REG_CTRL, cont ? HPC_CQ_CTRL_ERR_CONT : 0u); }

void hpc_cq_clear_error(void) {
  uint32_t mode = HPC_CQ_RD32(HPC_CQ_REG_CTRL) & HPC_CQ_CTRL_ERR_CONT;
  (void)HPC_CQ_WR32(HPC_CQ_REG_CTRL, mode | HPC_CQ_CTRL_ERR_CLEAR);
}

void hpc_cq_clear_counters(void) {
  uint32_t mode = HPC_CQ_RD32(HPC_CQ_REG_CTRL) & HPC_CQ_CTRL_ERR_CONT;
  (void)HPC_CQ_WR32(HPC_CQ_REG_CTRL, mode | HPC_CQ_CTRL_PERF_CLEAR);
}

uint32_t hpc_cq_counter(uint32_t i) { return HPC_CQ_RD32(HPC_CQ_REG_PERF0 + 4u * i); }

void hpc_cq_enable_interrupt(uint32_t mask) { (void)HPC_CQ_WR32(HPC_CQ_REG_INT_ENABLE, mask); }

uint32_t hpc_cq_pending_interrupt(void) { return HPC_CQ_RD32(HPC_CQ_REG_INT_STATUS); }

void hpc_cq_ack_interrupt(uint32_t mask) { (void)HPC_CQ_WR32(HPC_CQ_REG_INT_STATUS, mask); }

const char *hpc_cq_err_name(uint32_t e) {
  switch (e) {
    case HPC_CQ_ERR_NONE:        return "NONE";
    case HPC_CQ_ERR_VERSION:     return "VERSION";
    case HPC_CQ_ERR_OPCODE:      return "OPCODE";
    case HPC_CQ_ERR_FLAGS:       return "FLAGS";
    case HPC_CQ_ERR_RSVD:        return "RSVD";
    case HPC_CQ_ERR_STRIDE:      return "STRIDE";
    case HPC_CQ_ERR_RM:          return "RM";
    case HPC_CQ_ERR_LENGTH:      return "LENGTH";
    case HPC_CQ_ERR_ALIGN:       return "ALIGN";
    case HPC_CQ_ERR_RANGE:       return "RANGE";
    case HPC_CQ_ERR_OVERLAP:     return "OVERLAP";
    case HPC_CQ_ERR_DMA_READ:    return "DMA_READ";
    case HPC_CQ_ERR_DMA_WRITE:   return "DMA_WRITE";
    case HPC_CQ_ERR_DMA_ABORTED: return "DMA_ABORTED";
    case HPC_CQ_ERR_VEC_READ:    return "VEC_READ";
    case HPC_CQ_ERR_VEC_WRITE:   return "VEC_WRITE";
    case HPC_CQ_ERR_VEC_ENGINE:  return "VEC_ENGINE";
    case HPC_CQ_ERR_TIMEOUT:     return "TIMEOUT";
    case HPC_CQ_ERR_UNIT_DOWN:   return "UNIT_DOWN";
    case HPC_CQ_ERR_PRIOR:       return "PRIOR";
    default:                     return "?";
  }
}

const char *hpc_cq_op_name(uint32_t op) {
  switch (op) {
    case HPC_CQ_OP_NOP:            return "NOP";
    case HPC_CQ_OP_DMA_LOAD:       return "DMA_LOAD";
    case HPC_CQ_OP_DMA_STORE:      return "DMA_STORE";
    case HPC_CQ_OP_VECTOR_ADD:     return "VECTOR_ADD";
    case HPC_CQ_OP_VECTOR_MUL:     return "VECTOR_MUL";
    case HPC_CQ_OP_VECTOR_FMA:     return "VECTOR_FMA";
    case HPC_CQ_OP_FENCE:          return "FENCE";
    case HPC_CQ_OP_RESET_COUNTERS: return "RESET_COUNTERS";
    default:                       return "reserved";
  }
}
