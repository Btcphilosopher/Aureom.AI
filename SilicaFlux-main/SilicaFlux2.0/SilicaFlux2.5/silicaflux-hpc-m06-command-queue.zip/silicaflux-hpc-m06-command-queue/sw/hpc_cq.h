/* =============================================================================
 * SilicaFlux-HPC Module 06 -- command-queue host driver (bare metal, no libc)
 *
 * Hardware: rtl/hpc_cq_mmio.sv on the SilicaFlux-V register bus (proposed page
 * 0x4000_8000), in front of rtl/hpc_command_queue.sv.  Constants: hpc_cq_abi.h.
 *
 * Register access goes through two macros so the same driver runs on a CPU
 * (volatile MMIO, the default) and in RTL co-simulation (tb/cosim):
 *   HPC_CQ_WR32(off, v)   returns 0, or non-zero if the bus answered an error
 *   HPC_CQ_RD32(off)
 * On a CPU a refused register write is a store access fault; the driver never
 * issues one in normal operation (it checks STATUS.Q_FREE / CPL_VALID first).
 *
 * Return convention (as the DataFabric DMA driver): 0 = success,
 * > 0 = hardware ERR_CODE, < 0 = driver error (HPC_CQ_E*).
 * ===========================================================================*/
#ifndef HPC_CQ_H
#define HPC_CQ_H
#include <stdint.h>
#include "hpc_cq_abi.h"

#ifdef __cplusplus
extern "C" {
#endif

#if defined(HPC_CQ_COSIM)          /* RTL co-simulation: tb/cosim/cosim_main.cpp */
int      cosim_wr32(uint32_t off, uint32_t v);
uint32_t cosim_rd32(uint32_t off);
#define HPC_CQ_WR32(off, v) cosim_wr32((off), (v))
#define HPC_CQ_RD32(off)    cosim_rd32((off))
#endif

#ifndef HPC_CQ_WR32
#define HPC_CQ_WR32(off, v) \
  ((*(volatile uint32_t *)(uintptr_t)(HPC_CQ_BASE + (off)) = (uint32_t)(v)), 0)
#define HPC_CQ_RD32(off) (*(volatile uint32_t *)(uintptr_t)(HPC_CQ_BASE + (off)))
#endif

/* driver errors (negative) */
#define HPC_CQ_EBUSY     (-1)   /* queue full: try again after draining records     */
#define HPC_CQ_ENODEV    (-2)   /* ID / ABI version mismatch                         */
#define HPC_CQ_ETIMEDOUT (-3)   /* poll budget exhausted                             */
#define HPC_CQ_EBUS      (-4)   /* register access refused by the hardware           */

/* windows the hardware validates against (match the hpc_command_queue parameters) */
#ifndef HPC_CQ_EXT_BASE
#define HPC_CQ_EXT_BASE  0x10000000u
#define HPC_CQ_EXT_SIZE  0x00020000u
#define HPC_CQ_SPM_BASE  0x20000000u
#define HPC_CQ_SPM_SIZE  0x00010000u
#define HPC_CQ_DMA_MAX   (1u << 24)
#define HPC_CQ_VL_MAX    0xFFFFu
#endif

typedef struct { uint32_t w[HPC_CQ_DESC_WORDS]; } hpc_cq_desc_t;

typedef struct {
  uint8_t  tid, op, err, status, irq, fflags;
  uint32_t count;      /* bytes (DMA) / elements (vector) completed and acknowledged */
  uint32_t err_addr;   /* failing bus address (bus errors), else 0                   */
  uint32_t seq;        /* command sequence number                                    */
} hpc_cq_cpl_t;

/* descriptor builders (all reserved fields zero) */
void hpc_cq_desc_nop(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags);
void hpc_cq_desc_fence(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags);
void hpc_cq_desc_reset_counters(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags);
void hpc_cq_desc_dma_load(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags,
                          uint32_t ext_src, uint32_t spm_dst, uint32_t bytes);
void hpc_cq_desc_dma_store(hpc_cq_desc_t *d, uint8_t tid, uint8_t flags,
                           uint32_t spm_src, uint32_t ext_dst, uint32_t bytes);
void hpc_cq_desc_vector(hpc_cq_desc_t *d, uint8_t opcode, uint8_t tid, uint8_t flags,
                        uint8_t rm, uint32_t a, uint32_t b, uint32_t dst, uint32_t n);

/* software pre-check: the hardware's validation rules in the same order;
 * returns the ERR_CODE the hardware would report (0 = valid). */
int      hpc_cq_check(const hpc_cq_desc_t *d);

int      hpc_cq_init(void);                        /* ID + ABI check, stop mode, interrupts off */
uint32_t hpc_cq_status(void);
uint32_t hpc_cq_free_slots(void);
int      hpc_cq_submit(const hpc_cq_desc_t *d);    /* 0, HPC_CQ_EBUSY or HPC_CQ_EBUS           */
int      hpc_cq_poll(hpc_cq_cpl_t *c);             /* 1 = a record was taken, 0 = none         */
int      hpc_cq_wait(hpc_cq_cpl_t *c, uint32_t max_polls);  /* 0 or HPC_CQ_ETIMEDOUT        */
void     hpc_cq_set_continue_on_error(int cont);
void     hpc_cq_clear_error(void);
void     hpc_cq_clear_counters(void);
uint32_t hpc_cq_counter(uint32_t i);
void     hpc_cq_enable_interrupt(uint32_t mask);   /* HPC_CQ_INT_IRQ | HPC_CQ_INT_ERR          */
uint32_t hpc_cq_pending_interrupt(void);
void     hpc_cq_ack_interrupt(uint32_t mask);

const char *hpc_cq_err_name(uint32_t err);
const char *hpc_cq_op_name(uint32_t op);

#ifdef __cplusplus
}
#endif
#endif /* HPC_CQ_H */
