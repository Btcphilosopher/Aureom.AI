/* =============================================================================
 * SilicaFlux-HPC Module 06 -- command-queue ABI, version 1 (C half)
 *
 * Mirror of rtl/hpc_cq_pkg.sv (and ref/hpc_cq_abi.py); scripts/check_abi.py
 * proves the three agree value by value.  Prose specification:
 * docs/01_COMMAND_ABI.md.  Register map of the MMIO adapter: rtl/hpc_cq_mmio.sv,
 * docs/05_HOST_INTERFACE.md.
 *
 * Values are part of the public contract: never renumber, only append into
 * reserved code points; a layout change requires a new ABI version.
 * ===========================================================================*/
#ifndef HPC_CQ_ABI_H
#define HPC_CQ_ABI_H
#include <stdint.h>

#define HPC_CQ_ABI_VERSION        1u

/* ---------------------------------------------------------------- descriptor
 * 8 little-endian 32-bit words (32 bytes).                                    */
#define HPC_CQ_DESC_WORDS         8u
#define HPC_CQ_W_HDR              0u   /* header                                   */
#define HPC_CQ_W_SRC_A            1u   /* source A byte address                    */
#define HPC_CQ_W_SRC_B            2u   /* source B byte address                    */
#define HPC_CQ_W_DST              3u   /* destination byte address                 */
#define HPC_CQ_W_LEN              4u   /* bytes (DMA) or FP32 elements (vector)    */
#define HPC_CQ_W_STRIDE           5u   /* v1: must be 0 (packed)                   */
#define HPC_CQ_W_RSVD6            6u   /* must be 0                                */
#define HPC_CQ_W_RSVD7            7u   /* must be 0                                */

/* header word fields */
#define HPC_CQ_H_OP_LSB           0u   /* [7:0]   OPCODE                            */
#define HPC_CQ_H_VER_LSB          8u   /* [11:8]  VERSION                           */
#define HPC_CQ_H_RM_LSB           12u  /* [14:12] RM                                */
#define HPC_CQ_H_RSVD_BIT         15u  /* [15]    reserved, 0                       */
#define HPC_CQ_H_FLAGS_LSB        16u  /* [23:16] FLAGS                             */
#define HPC_CQ_H_TID_LSB          24u  /* [31:24] TID                               */

/* opcodes -- every other code point is reserved (ERR_OPCODE) */
#define HPC_CQ_OP_NOP             0x00u
#define HPC_CQ_OP_DMA_LOAD        0x01u  /* external memory -> scratchpad            */
#define HPC_CQ_OP_DMA_STORE       0x02u  /* scratchpad -> external memory            */
#define HPC_CQ_OP_VECTOR_ADD      0x10u  /* D[i] = A[i] + B[i]                        */
#define HPC_CQ_OP_VECTOR_MUL      0x11u  /* D[i] = A[i] * B[i]                        */
#define HPC_CQ_OP_VECTOR_FMA      0x12u  /* D[i] = A[i] * B[i] + D[i], one rounding   */
#define HPC_CQ_OP_FENCE           0x20u
#define HPC_CQ_OP_RESET_COUNTERS  0x30u

/* flags */
#define HPC_CQ_FL_IRQ             0u   /* bit: raise the commit interrupt event     */
#define HPC_CQ_FL_BARRIER         1u   /* bit: issue after every older command completed */
#define HPC_CQ_FLAGS_V1_MASK      0x03u

/* rounding modes (Module 02 / RISC-V frm) */
#define HPC_CQ_RM_RNE             0u
#define HPC_CQ_RM_RTZ             1u
#define HPC_CQ_RM_RDN             2u
#define HPC_CQ_RM_RUP             3u
#define HPC_CQ_RM_RMM             4u

/* ---------------------------------------------------------------- completion record
 * 4 little-endian 32-bit words (16 bytes).                                     */
#define HPC_CQ_REC_WORDS          4u
#define HPC_CQ_R_TID_LSB          0u   /* w0 [7:0]   TID                            */
#define HPC_CQ_R_OP_LSB           8u   /* w0 [15:8]  OPCODE                         */
#define HPC_CQ_R_ERR_LSB          16u  /* w0 [23:16] ERR_CODE                       */
#define HPC_CQ_R_STATUS_LSB       24u  /* w0 [25:24] STATUS                         */
#define HPC_CQ_R_IRQ_BIT          26u  /* w0 [26]    FL_IRQ echo                    */
#define HPC_CQ_R_FFLAGS_LSB       27u  /* w0 [31:27] FFLAGS {NV,DZ,OF,UF,NX}        */
/* w1 COUNT (bytes / elements completed), w2 ERR_ADDR, w3 SEQ */

#define HPC_CQ_ST_OK              0u
#define HPC_CQ_ST_ERROR           1u
#define HPC_CQ_ST_SKIPPED         2u

/* error codes */
#define HPC_CQ_ERR_NONE           0x00u
#define HPC_CQ_ERR_VERSION        0x01u
#define HPC_CQ_ERR_OPCODE         0x02u
#define HPC_CQ_ERR_FLAGS          0x03u
#define HPC_CQ_ERR_RSVD           0x04u
#define HPC_CQ_ERR_STRIDE         0x05u
#define HPC_CQ_ERR_RM             0x06u
#define HPC_CQ_ERR_LENGTH         0x07u
#define HPC_CQ_ERR_ALIGN          0x08u
#define HPC_CQ_ERR_RANGE          0x09u
#define HPC_CQ_ERR_OVERLAP        0x0Au
#define HPC_CQ_ERR_DMA_BASE       0x10u  /* | DataFabric DMA_ERR_*                   */
#define HPC_CQ_ERR_DMA_READ       0x18u
#define HPC_CQ_ERR_DMA_WRITE      0x19u
#define HPC_CQ_ERR_DMA_ABORTED    0x1Au
#define HPC_CQ_ERR_VEC_BASE       0x20u
#define HPC_CQ_ERR_VEC_READ       0x21u
#define HPC_CQ_ERR_VEC_WRITE      0x22u
#define HPC_CQ_ERR_VEC_ENGINE     0x23u
#define HPC_CQ_ERR_TIMEOUT        0x30u
#define HPC_CQ_ERR_UNIT_DOWN      0x31u
#define HPC_CQ_ERR_PRIOR          0x40u

/* performance counters */
#define HPC_CQ_PC_CYCLES          0u
#define HPC_CQ_PC_BUSY            1u
#define HPC_CQ_PC_CMD_IN          2u
#define HPC_CQ_PC_CMD_COMMIT      3u
#define HPC_CQ_PC_CMD_ERR         4u
#define HPC_CQ_PC_CMD_SKIP        5u
#define HPC_CQ_PC_DMA_ISSUE       6u
#define HPC_CQ_PC_VEC_ISSUE       7u
#define HPC_CQ_PC_DMA_ACTIVE      8u
#define HPC_CQ_PC_VEC_ACTIVE      9u
#define HPC_CQ_PC_OVERLAP         10u
#define HPC_CQ_PC_STALL_HAZARD    11u
#define HPC_CQ_PC_STALL_UNIT      12u
#define HPC_CQ_PC_STALL_SYNC      13u
#define HPC_CQ_PC_STALL_ROB       14u
#define HPC_CQ_PC_Q_FULL          15u
#define HPC_CQ_PC_CPL_BP          16u
#define HPC_CQ_PC_N               17u

/* ---------------------------------------------------------------- MMIO adapter (hpc_cq_mmio)
 * Proposed peripheral page 8 of the SilicaFlux-V register bus: 0x4000_8000
 * (unused in memmap/silicaflux_v_datafabric.yaml; docs/05_HOST_INTERFACE.md). */
#ifndef HPC_CQ_BASE
#define HPC_CQ_BASE               0x40008000u
#endif
#define HPC_CQ_REG_ID             0x000u   /* RO  0x5346_4351 "SFCQ"                 */
#define HPC_CQ_REG_INFO           0x004u   /* RO                                     */
#define HPC_CQ_REG_CTRL           0x008u   /* RW  [0] ERR_CONT [1] ERR_CLEAR [2] PERF_CLEAR */
#define HPC_CQ_REG_STATUS         0x00Cu   /* RO                                     */
#define HPC_CQ_REG_INT_ENABLE     0x010u   /* RW  [0] IRQ [1] ERR                    */
#define HPC_CQ_REG_INT_STATUS     0x014u   /* W1C                                    */
#define HPC_CQ_REG_SUBMITTED      0x018u   /* RO                                     */
#define HPC_CQ_REG_DESC0          0x020u   /* RW  DESC0..DESC7 at +4*i               */
#define HPC_CQ_REG_DOORBELL       0x040u   /* WO  submit (refused when full)         */
#define HPC_CQ_REG_CPL0           0x050u   /* RO  CPL0..CPL3 at +4*i                 */
#define HPC_CQ_REG_CPL_POP        0x060u   /* WO  release the head record            */
#define HPC_CQ_REG_PERF0          0x080u   /* RO  PERF[i] at +4*i                    */
#define HPC_CQ_ID_VALUE           0x53464351u

#define HPC_CQ_CTRL_ERR_CONT      (1u << 0)
#define HPC_CQ_CTRL_ERR_CLEAR     (1u << 1)
#define HPC_CQ_CTRL_PERF_CLEAR    (1u << 2)
#define HPC_CQ_STATUS_BUSY        (1u << 0)
#define HPC_CQ_STATUS_ERR_STICKY  (1u << 1)
#define HPC_CQ_STATUS_Q_FULL      (1u << 2)
#define HPC_CQ_STATUS_Q_EMPTY     (1u << 3)
#define HPC_CQ_STATUS_CPL_VALID   (1u << 4)
#define HPC_CQ_STATUS_DMA_DOWN    (1u << 5)
#define HPC_CQ_STATUS_VEC_DOWN    (1u << 6)
#define HPC_CQ_STATUS_Q_FREE(s)   (((s) >> 24) & 0xFFu)
#define HPC_CQ_INT_IRQ            (1u << 0)
#define HPC_CQ_INT_ERR            (1u << 1)

#endif /* HPC_CQ_ABI_H */
