/* =============================================================================
 * SilicaFlux-HPC Module 06 -- host-side command submission example
 *
 *   y = a .* x + y        (VECTOR_FMA, in place)
 *   z = y + x             (VECTOR_ADD)
 *
 * 1. place a, x, y in external memory (ordinary CPU stores)
 * 2. submit DMA_LOAD x3, VECTOR_FMA, VECTOR_ADD, DMA_STORE x2, FENCE(IRQ)
 *    -- no host synchronisation between them: the queue's scheduler orders
 *    the dependent commands and overlaps the independent ones
 * 3. drain the completion records (in order, one per command) and check them
 * 4. read y and z back from external memory and compare with a host reference
 * 5. error handling: a malformed command is rejected (ERR_ALIGN), the next one
 *    is SKIPPED (stop-on-error), the host clears the error and continues
 *
 * Platform: mem_wr32 / mem_rd32 / log are provided by the environment (plain
 * pointer accesses / UART on a SilicaFlux-V CPU; tb/cosim on the RTL).
 * Values are chosen so that every result is exact in FP32 (any rounding
 * mode gives the same bits), so the host reference needs no FP library.
 * ===========================================================================*/
#include "hpc_cq.h"

#ifdef __cplusplus
extern "C" {
#endif
extern void     demo_mem_wr32(uint32_t addr, uint32_t v);
extern uint32_t demo_mem_rd32(uint32_t addr);
extern void     demo_log(const char *fmt, ...);
int             cq_demo(void);
#ifdef __cplusplus
}
#endif

#define N        100u
#define EXT_A    0x10000000u
#define EXT_X    0x10000400u
#define EXT_Y    0x10000800u
#define EXT_YOUT 0x10001000u
#define EXT_ZOUT 0x10001400u
#define SPM_A    0x20000000u
#define SPM_X    0x20000400u
#define SPM_Y    0x20000800u
#define SPM_Z    0x20000C00u

typedef union { float f; uint32_t u; } fbits_t;
static uint32_t f2u(float f) { fbits_t b; b.f = f; return b.u; }

static hpc_cq_cpl_t recs[32];
static unsigned nrec;

/* submit; while the queue is full, drain completion records */
static int submit(const hpc_cq_desc_t *d) {
  int rc;
  int sw = hpc_cq_check(d);
  while ((rc = hpc_cq_submit(d)) == HPC_CQ_EBUSY) {
    if (nrec < 32 && hpc_cq_poll(&recs[nrec])) nrec++;
  }
  if (rc == 0 && sw) demo_log("  (software pre-check predicts ERR %s)\n", hpc_cq_err_name((uint32_t)sw));
  return rc;
}

static void drain(unsigned upto) {
  while (nrec < upto) {
    if (hpc_cq_wait(&recs[nrec], 1000000u) != 0) { demo_log("timeout waiting for record %u\n", nrec); return; }
    nrec++;
  }
}

static void show(const hpc_cq_cpl_t *c) {
  static const char *st[] = {"OK", "ERROR", "SKIPPED", "?"};
  demo_log("  seq %2u tid %2u %-10s %-7s err %-8s count %4u ff %02x%s\n", c->seq, c->tid,
           hpc_cq_op_name(c->op), st[c->status & 3u], hpc_cq_err_name(c->err), c->count, c->fflags,
           c->irq ? " irq" : "");
}

int cq_demo(void) {
  hpc_cq_desc_t d;
  int fails = 0;
  unsigned i;

  if (hpc_cq_init() != 0) { demo_log("command queue not found\n"); return 1; }
  demo_log("SilicaFlux-HPC command queue: INFO %08x, %u free slots\n",
           HPC_CQ_RD32(HPC_CQ_REG_INFO), hpc_cq_free_slots());

  /* 1. inputs (exact FP32 arithmetic) */
  for (i = 0; i < N; i++) {
    demo_mem_wr32(EXT_A + 4u * i, f2u((float)((int)(i % 7u) - 3)));
    demo_mem_wr32(EXT_X + 4u * i, f2u(0.5f * (float)i));
    demo_mem_wr32(EXT_Y + 4u * i, f2u(1.0f + (float)i));
  }

  /* 2. command stream */
  hpc_cq_desc_dma_load(&d, 0, 0, EXT_A, SPM_A, 4u * N);  submit(&d);
  hpc_cq_desc_dma_load(&d, 1, 0, EXT_X, SPM_X, 4u * N);  submit(&d);
  hpc_cq_desc_dma_load(&d, 2, 0, EXT_Y, SPM_Y, 4u * N);  submit(&d);
  hpc_cq_desc_vector(&d, HPC_CQ_OP_VECTOR_FMA, 3, 0, HPC_CQ_RM_RNE, SPM_A, SPM_X, SPM_Y, N); submit(&d);
  hpc_cq_desc_vector(&d, HPC_CQ_OP_VECTOR_ADD, 4, 0, HPC_CQ_RM_RNE, SPM_Y, SPM_X, SPM_Z, N); submit(&d);
  hpc_cq_desc_dma_store(&d, 5, 0, SPM_Y, EXT_YOUT, 4u * N); submit(&d);
  hpc_cq_desc_dma_store(&d, 6, 0, SPM_Z, EXT_ZOUT, 4u * N); submit(&d);
  hpc_cq_desc_fence(&d, 7, 1u << HPC_CQ_FL_IRQ);            submit(&d);

  /* 3. completion records: in order, one per command */
  drain(8);
  demo_log("completion records:\n");
  for (i = 0; i < 8; i++) {
    show(&recs[i]);
    if (recs[i].status != HPC_CQ_ST_OK || recs[i].seq != i || recs[i].tid != i) fails++;
  }
  if (recs[0].count != 4u * N || recs[3].count != N || recs[5].count != 4u * N) fails++;
  if (!(hpc_cq_pending_interrupt() & HPC_CQ_INT_IRQ)) { demo_log("FENCE IRQ event missing\n"); fails++; }
  hpc_cq_ack_interrupt(HPC_CQ_INT_IRQ);

  /* 4. results (visible to the host once the FENCE record has arrived) */
  for (i = 0; i < N; i++) {
    float a = (float)((int)(i % 7u) - 3), x = 0.5f * (float)i, y = 1.0f + (float)i;
    float y2 = a * x + y, z = y2 + x;
    if (demo_mem_rd32(EXT_YOUT + 4u * i) != f2u(y2) || demo_mem_rd32(EXT_ZOUT + 4u * i) != f2u(z)) {
      if (fails < 8) demo_log("  element %u: y %08x (exp %08x) z %08x (exp %08x)\n", i,
                              demo_mem_rd32(EXT_YOUT + 4u * i), f2u(y2), demo_mem_rd32(EXT_ZOUT + 4u * i), f2u(z));
      fails++;
    }
  }
  demo_log("results: %s\n", fails ? "MISMATCH" : "y = a*x + y and z = y + x correct for all elements");

  /* 5. error handling */
  demo_log("error handling (stop-on-error):\n");
  hpc_cq_desc_dma_load(&d, 8, 0, EXT_A, SPM_A + 2u, 16u);   submit(&d);   /* misaligned */
  hpc_cq_desc_nop(&d, 9, 0);                                 submit(&d);   /* skipped    */
  drain(10);
  show(&recs[8]); show(&recs[9]);
  if (recs[8].status != HPC_CQ_ST_ERROR || recs[8].err != HPC_CQ_ERR_ALIGN) fails++;
  if (recs[9].status != HPC_CQ_ST_SKIPPED || recs[9].err != HPC_CQ_ERR_PRIOR) fails++;
  if (!(hpc_cq_status() & HPC_CQ_STATUS_ERR_STICKY)) fails++;
  hpc_cq_clear_error();
  hpc_cq_desc_nop(&d, 10, 0);                                submit(&d);
  drain(11);
  show(&recs[10]);
  if (recs[10].status != HPC_CQ_ST_OK) fails++;

  demo_log("counters: cycles %u, committed %u, DMA jobs %u, vector jobs %u, DMA/vector overlap %u cycles, "
           "hazard stalls %u\n", hpc_cq_counter(HPC_CQ_PC_CYCLES), hpc_cq_counter(HPC_CQ_PC_CMD_COMMIT),
           hpc_cq_counter(HPC_CQ_PC_DMA_ISSUE), hpc_cq_counter(HPC_CQ_PC_VEC_ISSUE),
           hpc_cq_counter(HPC_CQ_PC_OVERLAP), hpc_cq_counter(HPC_CQ_PC_STALL_HAZARD));
  demo_log("DEMO %s (%d failures)\n", fails ? "FAIL" : "PASS", fails);
  return fails;
}
