#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC Module 06 :: run_all.sh -- complete verification campaign
#   ABI check -> lint -> stage 1 (bring-up subset) -> stage 2 (full set)
#   -> Icarus cross-simulation -> MMIO directed test -> C host co-simulation
#   -> latency probe -> performance -> synthesis + structural proof -> mutation testing
#   -> stimulus coverage -> reports/SUMMARY.md
# Several hours on 4 cores.  JOBS (default 4), MUT_JOBS (default 3).
# =============================================================================
set -u
cd "$(dirname "$0")/.."
JOBS="${JOBS:-4}"
MUT_JOBS="${MUT_JOBS:-3}"
mkdir -p reports build
log() { echo "== $(date +%H:%M:%S) $*" | tee -a reports/run_all.log; }
: > reports/run_all.log
step() { local name=$1; shift; log "$name"; "$@" > "build/$name.log" 2>&1; local rc=$?; log "$name exit=$rc"; return 0; }
step abi      python3 scripts/check_abi.py
step lint     python3 scripts/lint.py
step stage1   python3 scripts/regress.py stage1 --jobs "$JOBS"
step stage2   python3 scripts/regress.py stage2 --jobs "$JOBS"
step icarus   python3 scripts/regress.py icarus --jobs "$JOBS"
step mmio     python3 scripts/regress.py mmio
step cosim    python3 scripts/regress.py cosim
step latency  make latency
step perf     python3 scripts/perf.py
step synth    env JOBS="$JOBS" bash syn/run_synth.sh
step mutation python3 scripts/mutate.py --jobs "$MUT_JOBS"
step coverage python3 scripts/coverage.py
step summary  python3 scripts/make_report.py
cat reports/run_all.log
