#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: perf -- cycle measurements of the command queue

Runs the perf_* programs (ref/gen_prog.py) and the double-buffer pipeline on
the RTL with the "fast" profile (external memory ready every cycle, 1-cycle
latency, host always ready) and reports the cycles from the first submission
to the last completion record (TB prog_cycles).  Every run is also a fully
self-checking test.  Report: reports/perf.md / .json.
"""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "scripts"))
import regress  # noqa: E402

RUNS = [
    # (label, recipe, cfg, items, unit)
    ("NOP stream (256)", "perf_nop", dict(QD=8), 256, "commands"),
    ("FENCE stream (64), nothing in flight", "perf_fence", dict(QD=8), 64, "commands"),
    ("DMA_LOAD 64 B", "perf_load64", dict(QD=8), 16, "words"),
    ("DMA_LOAD 1 KiB", "perf_load1024", dict(QD=8), 256, "words"),
    ("DMA_LOAD 4 KiB", "perf_load4096", dict(QD=8), 1024, "words"),
    ("DMA_STORE 1 KiB", "perf_store1024", dict(QD=8), 256, "words"),
    ("VECTOR_ADD 16, N=2", "perf_vadd16", dict(QD=8, N=2), 16, "elements"),
    ("VECTOR_ADD 256, N=2", "perf_vadd256", dict(QD=8, N=2), 256, "elements"),
    ("VECTOR_ADD 1024, N=2", "perf_vadd1024", dict(QD=8, N=2), 1024, "elements"),
    ("VECTOR_MUL 256, N=2", "perf_vmul256", dict(QD=8, N=2), 256, "elements"),
    ("VECTOR_FMA 256, N=2", "perf_vfma256", dict(QD=8, N=2), 256, "elements"),
    ("VECTOR_ADD 256, N=4", "perf_vadd256", dict(QD=8, N=4), 256, "elements"),
    ("VECTOR_ADD 1024, N=4", "perf_vadd1024", dict(QD=8, N=4), 1024, "elements"),
    ("VECTOR_FMA 256, N=4", "perf_vfma256", dict(QD=8, N=4), 256, "elements"),
    ("independent DMA_LOAD 1 KiB + VECTOR_ADD 256, overlap on", "perf_pair_indep", dict(QD=8, OVL=1), 1, "pair"),
    ("independent DMA_LOAD 1 KiB + VECTOR_ADD 256, overlap off", "perf_pair_indep", dict(QD=8, OVL=0), 1, "pair"),
    ("dependent DMA_LOAD 1 KiB -> VECTOR_ADD 256, overlap on", "perf_pair_dep", dict(QD=8, OVL=1), 1, "pair"),
    ("double-buffer pipeline (10 tiles x 96), overlap on", "dbuf", dict(QD=8, OVL=1), 10, "tiles"),
    ("double-buffer pipeline (10 tiles x 96), overlap off", "dbuf", dict(QD=8, OVL=0), 10, "tiles"),
]


def main():
    out = []
    for label, recipe, cfg, items, unit in RUNS:
        r = regress.run_one(dict(recipe=recipe, seed=1, stage1=False, cfg=cfg, prof="fast", sim="verilator"))
        cyc = int(r["stats"].get("prog_cycles", 0))
        out.append(dict(label=label, recipe=recipe, cfg=cfg, ok=r["ok"], cycles=cyc, items=items, unit=unit,
                        overlap=int(r["stats"].get("overlap", 0)), line=r["line"]))
        print(f"{'PASS' if r['ok'] else 'FAIL'} {label}: {cyc} cycles", flush=True)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(out, open(os.path.join(ROOT, "reports", "perf.json"), "w"), indent=1)
    lines = ["# Performance (RTL cycle counts)", "",
             "Profile `fast`: external memory accepts every cycle with 1-cycle latency, the host takes every "
             "record at once, no lane holds.  Cycles are counted from the first command submission to the last "
             "completion record (testbench `prog_cycles`), so they include submission, decode, execution, "
             "commit and hand-over.  Every run is a passing self-checking test.", "",
             "| measurement | result | cycles | per item | DMA/vector overlap cycles |", "|---|---|---|---|---|"]
    for o in out:
        per = f"{o['cycles'] / o['items']:.2f} cycles / {o['unit'][:-1] if o['items'] > 1 else o['unit']}"
        lines.append(f"| {o['label']} | {'PASS' if o['ok'] else 'FAIL'} | {o['cycles']} | {per} | {o['overlap']} |")
    open(os.path.join(ROOT, "reports", "perf.md"), "w").write("\n".join(lines) + "\n")
    sys.exit(0 if all(o["ok"] for o in out) else 1)


if __name__ == "__main__":
    main()
