#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: mutate -- mutation testing of the command queue

Each mutant is one deliberate design bug in the new RTL (rtl/hpc_cq_*.sv,
rtl/hpc_command_queue.sv).  For every mutant the module is copied, the bug
is injected, and a list of quick regression runs is executed until one of
them fails ("killed").  A mutant that survives every run means the
verification has a hole.  Report: reports/mutation.md / .json.

  python3 scripts/mutate.py [--jobs 4] [--only M07]
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MUT = os.path.join(ROOT, "build", "mut")

# quick runs (recipe, cfg, profile, extra flags)
R = dict(
    rand=("rand", "QD=4", "rand", []), deps=("deps", "QD=4", "rand", []), dbuf=("dbuf", "QD=4", "rand", []),
    errors=("errors", "QD=4", "fast", []), fp=("fp", "QD=4", "fast", []), b2b=("b2b", "QD=4", "bp", []),
    dma_fault=("dma_fault", "QD=4", "rand", []), spm_fault=("spm_fault", "QD=4,PHYS=15", "rand", []),
    tdma=("timeout_dma", "QD=4,WDOG=10", "rand", ["--cont"]), tvec=("timeout_vec", "QD=4,WDOG=10", "rand", []),
    rstcnt=("rstcnt", "QD=4", "rand", []), ovl0=("rand", "QD=4,OVL=0", "rand", []),
    reset=("rand", "QD=4", "rand", ["--reset", "20"]), long=("long", "QD=4", "fast", []),
    smoke1=("smoke", "QD=4,OPSET=0", "fast", ["--stage1"]), rand_fast=("rand", "QD=4", "fast", []),
    mmio=("@mmio", "", "", []), cosim=("@cosim", "", "", []),
    rl2=("rand", "QD=4,SPMRL=2", "rand", []), rl2_dbuf=("dbuf", "QD=4,SPMRL=2", "fast", []),
    q1=("dbuf", "QD=4,OPQ=1,WBQ=1", "rand", []), q1_long=("long", "QD=4,OPQ=1,WBQ=1", "fast", []),
    q1_rand=("rand", "QD=4,OPQ=1,WBQ=1", "slow", []),
    w1n4=("rand", "QD=4,N=4,OPQ=4,WBQ=1", "slow", []), w1n4_dbuf=("dbuf", "QD=4,N=4,OPQ=4,WBQ=1", "rand", []),
    w1n4_deps=("deps", "QD=4,N=4,OPQ=4,WBQ=1", "rand", []),
)

# Mutants proven behaviourally equivalent (cannot be killed by any test);
# reported separately with the argument.
EQUIVALENT = {
    "M25": "Every vector footprint is word-aligned, so a vector range that touches the DMA's last (partially "
           "used) source word always also intersects the un-rounded range [SRC_A, SRC_A+LENGTH); and the bytes "
           "of that word beyond LENGTH are read but never written to the destination.  The round-up is kept "
           "as a defensive bound for future byte-granular units.",
}
DEFAULT_RUNS = ["rand", "deps", "errors", "dbuf", "dma_fault", "rstcnt", "fp", "b2b"]

# id, file, original, mutant, description, runs to try (None = default list)
MUTANTS = [
    ("M01", "hpc_cq_sched.sv", "wire haz_dma = vec_act_q &&", "wire haz_dma = 1'b0 && vec_act_q &&",
     "no dependency check for a DMA command against the running vector job", ["deps", "dbuf", "rand"]),
    ("M02", "hpc_cq_sched.sv", "                  hpc_cq_pkg::isect(f_wr_lo,  f_wr_hi,  dr_lo_q, dr_hi_q) ||\n",
     "", "vector command: WAR check against the DMA read footprint missing", ["deps", "dbuf", "rand"]),
    ("M03", "hpc_cq_sched.sv", "                  hpc_cq_pkg::isect(f_rd2_lo, f_rd2_hi, dw_lo_q, dw_hi_q) ||\n",
     "", "vector command: RAW check of source B against the DMA write missing", ["deps", "rand", "dbuf"]),
    ("M04", "hpc_cq_sched.sv", "wire need_sync = (v_cls == hpc_cq_pkg::CL_FENCE) ||", "wire need_sync = 1'b0 ||",
     "FENCE does not wait for older commands", None),
    ("M05", "hpc_cq_sched.sv", "                   d_fl[hpc_cq_pkg::FL_BARRIER] ||", "                   1'b0 ||",
     "FL_BARRIER ignored", None),
    ("M06", "hpc_cq_sched.sv", "wire skip      = sticky_q && !err_cont_i;", "wire skip      = 1'b0;",
     "stop-on-error never skips younger commands", ["errors", "dma_fault"]),
    ("M07", "hpc_cq_sched.sv", "if ((act_set_sticky || unit_err) && !err_cont_i) sticky_q <= 1'b1;",
     "if (act_set_sticky && !err_cont_i) sticky_q <= 1'b1;", "execution errors do not make the queue sticky",
     ["dma_fault", "spm_fault", "errors"]),
    ("M08", "hpc_cq_sched.sv", "        if (dma_act_q)    st_unit = 1'b1;", "        if (1'b0)    st_unit = 1'b1;",
     "DMA command issued while the DMA engine is busy", None),
    ("M09", "hpc_cq_rob.sv", "wire do_commit = (ncm_q < nal_q) && done_q[cmt_q];", "wire do_commit = (ncm_q < nal_q);",
     "records committed before the command completed", None),
    ("M10", "hpc_cq_rob.sv", "rec_o = {r_seq[head_q], r_eaddr[head_q], r_cnt[head_q],",
     "rec_o = {r_seq[cmt_q], r_eaddr[head_q], r_cnt[head_q],", "record SEQ taken from the wrong entry", None),
    ("M11", "hpc_cq_validate.sv", "(is_vec && ((sa[1:0] != 2'b00) || (sb[1:0] != 2'b00) || (da[1:0] != 2'b00)));",
     "(is_vec && ((sa[1:0] != 2'b00) || (da[1:0] != 2'b00)));", "misaligned vector source B accepted", ["errors"]),
    ("M12", "hpc_cq_validate.sv", "    e_ovl    = is_vec &&", "    e_ovl    = 1'b0 && is_vec &&",
     "partial destination / source overlap accepted", ["errors"]),
    ("M13", "hpc_cq_validate.sv", "    else if (e_align)  err_o = hpc_cq_pkg::ERR_ALIGN;\n    else if (e_range)  err_o = hpc_cq_pkg::ERR_RANGE;",
     "    else if (e_range)  err_o = hpc_cq_pkg::ERR_RANGE;\n    else if (e_align)  err_o = hpc_cq_pkg::ERR_ALIGN;",
     "ALIGN / RANGE priority swapped", ["errors"]),
    ("M14", "hpc_cq_pkg.sv", "    in_window = ({1'b0, lo} >= base) && (hi <= ({1'b0, base} + {1'b0, size}));",
     "    in_window = ({1'b0, lo} >= base) && (hi <= ({1'b0, base} + {1'b0, size} + 34'd4));",
     "range check accepts one word past the window", ["errors"]),
    ("M15", "hpc_cq_validate.sv", "e_stride = (is_dma || is_vec) && (str != 32'd0);", "e_stride = 1'b0;",
     "non-zero stride silently accepted", ["errors"]),
    ("M16", "hpc_command_queue.sv", "assign cmd_ready_o = rdy_q && !q_full;", "assign cmd_ready_o = rdy_q;",
     "command accepted while the queue is full (overwrite)", ["b2b", "rand"]),
    ("M17", "hpc_cq_vexec.sv", "    assign wr_idle[l]   = wbq_empty[l] && !(rq_v_q && rq_we_q) && (wout_q == '0);",
     "    assign wr_idle[l]   = wbq_empty[l] && !(rq_v_q && rq_we_q);",
     "vector job reported done before its writes are acknowledged", ["rl2", "rl2_dbuf", "spm_fault", "deps"]),
    ("M18", "hpc_cq_vexec.sv", "    assign opq_wdata[l*96 +: 96] = {(rrph_q == 2'd2) ? rdata : 32'd0,      // c",
     "    assign opq_wdata[l*96 +: 96] = {(rrph_q == 2'd2) ? asm_a_q : 32'd0,      // c",
     "FMA addend taken from A instead of D", ["fp", "rand", "dbuf"]),
    ("M19", "hpc_cq_vexec.sv", "  assign va_cmd_rm_o  = rm_q;", "  assign va_cmd_rm_o  = 3'd0;",
     "rounding mode not passed to the array", ["fp", "rand"]),
    ("M20", "hpc_cq_vexec.sv", "    assign lane_act[l]  = (ebase + EW'(l)) < vl_q;", "    assign lane_act[l]  = (ebase < vl_q);",
     "tail lanes treated as active", ["rand", "fp", "deps"]),
    ("M21", "hpc_cq_sched.sv", "(hpc_cq_pkg::ERR_DMA_BASE | {4'h0, dma_err_code_i})", "({4'h0, dma_err_code_i})",
     "DMA error code not mapped into the 0x1X class", ["dma_fault", "spm_fault"]),
    ("M22", "hpc_cq_sched.sv", "  wire wd_en   = (WDOG_LOG2 > 0);", "  wire wd_en   = 1'b0;",
     "watchdog disabled (hung unit never reported)", ["tdma", "tvec"]),
    ("M23", "hpc_cq_sched.sv", "      if (dma_to) dma_dead_q <= 1'b1;", "",
     "timed-out DMA engine not quarantined", ["tdma"]),
    ("M24", "hpc_cq_sched.sv", "  assign perf_clear_o      = act_rstcnt;", "  assign perf_clear_o      = 1'b0;",
     "RESET_COUNTERS does not clear the counters", ["rstcnt", "rand"]),
    ("M25", "hpc_cq_validate.sv", "  wire [32:0] dlen_r = ({1'b0, len} + 33'd3) & ~33'd3;   // rounded up to whole words",
     "  wire [32:0] dlen_r = {1'b0, len};", "DMA read footprint not rounded up to the last whole word",
     ["deps", "rand", "dbuf"]),
    ("M26", "hpc_cq_sched.sv", "                   d_fl[hpc_cq_pkg::FL_BARRIER] || (!OVERLAP_EN && (is_dma || is_vec));",
     "                   d_fl[hpc_cq_pkg::FL_BARRIER];", "OVERLAP_EN = 0 not honoured", ["ovl0"]),
    ("M27", "hpc_cq_rob.sv", "      if (do_alloc) done_q[tail_q] <= alloc_done_i;", "      if (do_alloc) done_q[tail_q] <= 1'b0;",
     "commands resolved at decode never complete", ["smoke1", "rand"]),
    ("M28", "hpc_cq_sched.sv", "        seq_q     <= seq_q + 32'd1;", "        seq_q     <= seq_q + 32'd2;",
     "sequence numbers skip", ["smoke1"]),
    ("M29", "hpc_cq_vexec.sv", "  assign va_res_ready_o  = run && (jerr_q || (wbq_full == '0));",
     "  assign va_res_ready_o  = run;", "result beats taken without write-back queue space (lost writes)",
     ["w1n4", "w1n4_dbuf", "w1n4_deps", "q1", "q1_long", "q1_rand"]),
    ("M30", "hpc_cq_sched.sv", "  wire sync_busy = older || (is_rstcnt && (rob_nal != rob_ncm));", "  wire sync_busy = older;",
     "RESET_COUNTERS does not wait for older commits", ["rstcnt"]),
    ("M31", "hpc_cq_vexec.sv", "    assign wbq_push[l]  = res_hs && va_res_mask_i[l] && !jerr_q;",
     "    assign wbq_push[l]  = res_hs && va_res_mask_i[l];", "results written after a vector read error",
     ["spm_fault"]),
    ("M32", "hpc_cq_sched.sv", "  wire older     = dma_act_q || vec_act_q;", "  wire older     = dma_act_q;",
     "FENCE / BARRIER ignore an in-flight vector job", None),
    ("M33", "hpc_cq_mmio.sv", "  assign cmd_valid_o = wr && (rb_addr == A_DOORBELL) && cmd_ready_i;",
     "  assign cmd_valid_o = wr && (rb_addr == A_DOORBELL);", "MMIO: doorbell counted although the queue is full",
     ["mmio"]),
    ("M34", "hpc_cq_mmio.sv", "          A_CPLPOP:   rb_err = rb_we && !cpl_valid_i;     // nothing to release",
     "          A_CPLPOP:   rb_err = 1'b0;", "MMIO: CPL_POP with no record not refused", ["mmio"]),
    ("M35", "hpc_cq_mmio.sv", "      is_q <= (is_q & ~((wr && rb_addr == A_IS) ? rb_wdata[1:0] : 2'b00)) |",
     "      is_q <= 2'b00 |", "MMIO: INT_STATUS does not hold events", ["mmio", "cosim"]),
    ("M37", "hpc_cq_vexec.sv", "    assign werr[l]      = rsp_wr && sp_rsp_err_i[l];", "    assign werr[l]      = 1'b0;",
     "vector executor ignores scratchpad write errors", ["spm_fault"]),
    ("M36", "hpc_cq_mmio.sv", "        rb_rdata = cpl_rec_i[32*cpl_i +: 32];", "        rb_rdata = cpl_rec_i[31:0];",
     "MMIO: CPL1..3 read the wrong record word", ["mmio", "cosim"]),
]

COPY_DIRS = ["rtl", "tb", "ref", "scripts", "third_party", "sw"]


def run(cmd, cwd, timeout=3600):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    return p.returncode, p.stdout


def do_mutant(m):
    mid, fname, orig, new, desc, runs = m
    d = os.path.join(MUT, mid)
    if os.path.exists(d):
        shutil.rmtree(d)
    os.makedirs(d)
    for x in COPY_DIRS:
        shutil.copytree(os.path.join(ROOT, x), os.path.join(d, x))
    p = os.path.join(d, "rtl", fname)
    s = open(p).read()
    if s.count(orig) != 1:
        return dict(id=mid, desc=desc, file=fname, killed=False, by=None, note="pattern not found exactly once")
    open(p, "w").write(s.replace(orig, new))
    t0 = time.time()
    tried = []
    for r in (runs or DEFAULT_RUNS):
        recipe, cfg, prof, extra = R[r]
        if recipe.startswith("@"):
            cmd = [sys.executable, "scripts/regress.py", recipe[1:]]
        else:
            cmd = [sys.executable, "scripts/regress.py", "one", recipe, "--cfg", cfg, "--prof", prof] + extra
        try:
            rc, out = run(cmd, d, timeout=1800)
        except subprocess.TimeoutExpired:
            rc, out = 1, "TIMEOUT"
        line = next((x for x in out.splitlines() if x.startswith("TB_RESULT") or x.startswith("EXCEPTION")), out[-200:])
        tried.append(r)
        if rc != 0:
            shutil.rmtree(os.path.join(d, "build"), ignore_errors=True)
            return dict(id=mid, desc=desc, file=fname, killed=True, by=r, tried=tried, line=line[:200],
                        secs=round(time.time() - t0))
    return dict(id=mid, desc=desc, file=fname, killed=False, by=None, tried=tried, secs=round(time.time() - t0))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    ms = [m for m in MUTANTS if not a.only or m[0] in a.only.split(",")]
    os.makedirs(MUT, exist_ok=True)
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(do_mutant, ms))
    for r in res:
        print(f"{r['id']} {'KILLED by ' + r['by'] if r['killed'] else 'SURVIVED'}: {r['desc']}")
    for r in res:
        r["equivalent"] = (not r["killed"]) and r["id"] in EQUIVALENT
    k = sum(r["killed"] for r in res)
    eq = sum(r["equivalent"] for r in res)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "mutation.json"), "w"), indent=1)
    lines = ["# Mutation testing", "", f"**{k} / {len(res)} injected design bugs detected"
             f"{f'; {eq} proven equivalent (no behavioural difference exists)' if eq else ''}; "
             f"{len(res) - k - eq} undetected.**", "",
             "Each mutant is one deliberate bug in the new RTL; quick regression runs are tried in order until "
             "one fails.", "", "| id | file | injected bug | killed by | detail |", "|---|---|---|---|---|"]
    for r in res:
        lines.append(f"| {r['id']} | `{r['file']}` | {r['desc']} | "
                     f"{r['by'] or ('equivalent' if r['equivalent'] else '**SURVIVED**')} | "
                     f"{(r.get('line') or r.get('note') or '').replace('|', '/')[:120]} |")
    if eq:
        lines += ["", "## Equivalent mutants", ""] + [f"* **{m}**: {EQUIVALENT[m]}" for m in sorted(EQUIVALENT)
                                                      if any(r['id'] == m and r['equivalent'] for r in res)]
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(lines) + "\n")
    print(f"mutation: {k}/{len(res)} killed")
    sys.exit(0 if k + eq == len(res) else 1)


if __name__ == "__main__":
    main()
