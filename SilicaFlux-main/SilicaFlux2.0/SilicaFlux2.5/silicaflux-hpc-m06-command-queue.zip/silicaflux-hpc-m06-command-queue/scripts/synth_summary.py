#!/usr/bin/env python3
"""SilicaFlux-HPC Module 06 :: synth_summary -- reports/synth/summary.md from Yosys stat files."""
import os
import re
import sys

out = sys.argv[1]
rows = []
for f in sorted(os.listdir(out)):
    if not f.endswith("_stat.txt"):
        continue
    name = f[:-9]
    s = open(os.path.join(out, f)).read()
    # last (top-level / flattened) block
    blocks = s.split("=== ")
    top = blocks[-1]
    cells = re.search(r"Number of cells:\s+(\d+)", top)
    ff = sum(int(n) for k, n in re.findall(r"\$_(S?DFF\w*|DFF\w*|ALDFF\w*)_?\w*\s+(\d+)", top))
    ff += sum(int(n) for n in re.findall(r"TRELLIS_FF\s+(\d+)", top))
    lut = sum(int(n) for n in re.findall(r"LUT4\s+(\d+)", top))
    ccu = sum(int(n) for n in re.findall(r"CCU2C\s+(\d+)", top))
    mul = sum(int(n) for n in re.findall(r"MULT18X18D\s+(\d+)", top))
    ram = sum(int(n) for n in re.findall(r"(?:DP16KD|TRELLIS_DPR16X4)\s+(\d+)", top))
    rows.append((name, int(cells.group(1)) if cells else 0, ff, lut, ccu, mul, ram))
t = {}
for line in open(os.path.join(out, "timing.txt")):
    m = re.match(r"(\S+) exit=(\d+) (\d+) s", line)
    if m:
        t[m.group(1)] = (int(m.group(2)), int(m.group(3)))
lines = ["# Synthesis summary (Yosys 0.33)", "",
         "Generic: `synth -flatten` (technology-independent gates).  ECP5: `synth_ecp5` "
         "(Lattice LFE5U, the SilicaFlux FPGA prototype family).  Every job passes `check -assert` "
         "and contains no latch.  No timing or area in silicon is claimed.", "",
         "| design | cells | flip-flops | LUT4 | CCU2C | MULT18 | RAM | Yosys s |", "|---|---|---|---|---|---|---|---|"]
for name, c, ff, lut, ccu, mul, ram in rows:
    lines.append(f"| `{name}` | {c} | {ff} | {lut or ''} | {ccu or ''} | {mul or ''} | {ram or ''} | {t.get(name, ('', ''))[1]} |")
lines += ["", "Notes:", "",
          "* `tile_n2` is the whole tile (queue + DMA engine + crossbar + 64 KiB scratchpad + executor + 2-lane "
          "FP32 array).  Generic `synth` has no memory library, so the scratchpad's 524,288 array bits become "
          "flip-flops; that, not the control plane, is where its flip-flop count comes from.  The scratchpad's "
          "real FPGA block-RAM / ASIC-macro mapping is Module 04's (`BACKEND = FPGA | ASIC`, its "
          "`reports/synth.md`); the array's FPGA results are Module 03's.",
          "* ECP5 `RAM` = `TRELLIS_DPR16X4` distributed RAM: Yosys maps the command FIFO and the operand / "
          "write-back queues to it, which is why the ECP5 flip-flop counts are below the generic ones and "
          "QUEUE_DEPTH 4 / 8 / 16 cost almost the same (one 16-deep LUT RAM column either way).",
          "* The generic queue flip-flop count is dominated by storage: FIFO entries (193 bits each), "
          "retirement records (128 bits each), the decode slot, 17 x 32-bit counters and the two job "
          "footprints."]
sc = os.path.join(out, "structural_check.txt")
if os.path.exists(sc):
    lines += ["", "## Structural check", "", "```", open(sc).read().strip(), "```"]
open(os.path.join(out, "summary.md"), "w").write("\n".join(lines) + "\n")
print("\n".join(lines))
