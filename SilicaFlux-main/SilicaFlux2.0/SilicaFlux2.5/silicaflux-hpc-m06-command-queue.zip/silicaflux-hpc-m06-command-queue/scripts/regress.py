#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: regress -- staged regression of the command queue

  python3 scripts/regress.py stage1          # bring-up: NOP / DMA_LOAD / VECTOR_ADD / FENCE
  python3 scripts/regress.py stage2          # full v1 opcode set, errors, faults, timeouts, reset
  python3 scripts/regress.py all [--icarus] [--seeds N] [--jobs J]
  python3 scripts/regress.py one RECIPE [--stage1] [--cfg QD=4,N=2,...] [--prof rand] [--seed S]

Each run: ref/gen_prog.py builds a program + reference expectations, the
Verilator (or Icarus) build of tb/tb_hpc_command_queue.sv for the requested
parameters executes it under a timing profile, and the "TB_RESULT" line is
collected.  Reports: reports/regression_<stage>.md / .json.
"""
import argparse
import hashlib
import itertools
import json
import os
import re
import subprocess
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "ref"))
import gen_prog  # noqa: E402

BUILD = os.path.join(ROOT, "build")
REPORTS = os.path.join(ROOT, "reports")
TB_FILES = ["third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv",
            "tb/tb_ext_mem.sv", "tb/tb_hpc_command_queue.sv"]
SVA_FILES = ["tb/hpc_cq_sva.sv"]
DEFAULT_CFG = dict(QD=8, RD=8, N=2, OVL=1, OPSET=1, PHYS=16, WDOG=16, SPMRL=1, OPQ=4, WBQ=4)

PROFILES = {
    "fast": dict(GAP=0, CPLRDY=100, XRDY=100, LATMIN=1, LATMAX=1, HOLD=0, HOST=0),
    "rand": dict(GAP=30, CPLRDY=60, XRDY=70, LATMIN=1, LATMAX=4, HOLD=5, HOST=1),
    "bp":   dict(GAP=0, CPLRDY=10, XRDY=40, LATMIN=1, LATMAX=8, HOLD=0, HOST=0),
    "slow": dict(GAP=50, CPLRDY=90, XRDY=30, LATMIN=2, LATMAX=12, HOLD=20, HOST=1),
}


def sh(cmd, log=None, timeout=None, cwd=ROOT):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       text=True, timeout=timeout)
    if log:
        with open(log, "w") as fh:
            fh.write(" ".join(cmd) + "\n" + p.stdout)
    return p.returncode, p.stdout


def cfg_key(cfg, sim):
    return sim + "_" + "_".join(f"{k}{cfg[k]}" for k in sorted(cfg))


_BUILD_LOCK = threading.Lock()
_PREBUILT = {}


def build(cfg, sim="verilator"):
    """Build (or reuse) the simulator for cfg.  Serialised; during a regression
    run the executables built in the pre-build phase are reused as they are
    (sources edited mid-run do not trigger a rebuild)."""
    key = cfg_key(cfg, sim)
    with _BUILD_LOCK:
        if key in _PREBUILT:
            return _PREBUILT[key]
        exe = _build(cfg, sim)
        _PREBUILT[key] = exe
        return exe


def _build(cfg, sim):
    d = os.path.join(BUILD, "sim_" + cfg_key(cfg, sim))
    exe = os.path.join(d, "sim" if sim == "verilator" else "sim.vvp")
    srcs = [os.path.join(ROOT, f) for f in TB_FILES]
    stamp = hashlib.sha1("".join(open(f).read() for f in
                                 srcs + [os.path.join(ROOT, "rtl", x) for x in os.listdir(os.path.join(ROOT, "rtl"))
                                         if x.endswith(".sv")]).encode()).hexdigest()[:12]
    if os.path.exists(exe) and open(os.path.join(d, "stamp")).read() == stamp:
        return exe
    os.makedirs(d, exist_ok=True)
    if sim == "verilator":
        cmd = ["verilator", "--binary", "--timing", "--assert", "-j", "4", "--timescale", "1ns/1ps",
               "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN",
               "-DHPC_SPM_ASSERT", "-DSRAMLIB_ASSERT", "-Mdir", d, "-o", "sim",
               "--top-module", "tb_hpc_command_queue"]
        cmd += [f"-G{k}={v}" for k, v in cfg.items()]
        cmd += ["-f", "rtl/files.f", "-f", "rtl/files_sim_stubs.f"] + TB_FILES + SVA_FILES
    else:
        files = []
        incs = []
        for f in ("rtl/files.f", "rtl/files_sim_stubs.f"):
            for line in open(os.path.join(ROOT, f)):
                line = line.split("//")[0].strip()
                if line.startswith("+incdir+"):
                    incs.append("-I" + line[8:])
                elif line:
                    files.append(line)
        cmd = ["iverilog", "-g2012", "-DHPC_SPM_ASSERT", "-DSRAMLIB_ASSERT", "-o", exe,
               "-s", "tb_hpc_command_queue"] + incs + [f"-Ptb_hpc_command_queue.{k}={v}" for k, v in cfg.items()]
        cmd += files + TB_FILES
    rc, out = sh(cmd, log=os.path.join(d, "build.log"), timeout=3600)
    if rc != 0 or not os.path.exists(exe):
        raise RuntimeError(f"build failed ({cfg_key(cfg, sim)}), see {d}/build.log")
    with open(os.path.join(d, "stamp"), "w") as fh:
        fh.write(stamp)
    return exe


_GEN_LOCKS = {}
_GEN_LOCKS_GUARD = threading.Lock()


def gen(recipe, seed, stage1, cfg, cont=False):
    """Generate (once) the program; jobs sharing a program wait for its generation."""
    tag = f"{recipe}_s{seed}_{'s1' if stage1 else 's2'}_o{cfg['OVL']}_p{cfg['PHYS']}_c{int(cont)}"
    d = os.path.join(BUILD, "progs", tag)
    with _GEN_LOCKS_GUARD:
        lock = _GEN_LOCKS.setdefault(tag, threading.Lock())
    with lock:
        if not os.path.exists(os.path.join(d, "meta.json")):
            gen_prog.build(recipe, seed, d, stage1=stage1, overlap=bool(cfg["OVL"]),
                           spm_phys_log2=cfg["PHYS"], cont=cont)
        return d, json.load(open(os.path.join(d, "meta.json")))


def plusargs(d, m, suffix=""):
    a = [f"+PROG{suffix}={d}", f"+NCMD{suffix}={m['ncmd']}", f"+NSPMI{suffix}={m['nspmi']}",
         f"+NSPMC{suffix}={m['nspmc']}", f"+NCHK{suffix}={m['nchk']}"]
    a.append(f"+CONT0={m['cont0']}" if not suffix else f"+CONTB={m['cont0']}")
    a.append(f"+SCRATCH{suffix}={m['scratch'][0]:x}")
    if not suffix:
        a += [f"+ERR_LO={m['ext_err'][0]:x}", f"+ERR_HI={m['ext_err'][1]:x}",
              f"+HANG_LO={m['ext_hang'][0]:x}", f"+HANG_HI={m['ext_hang'][1]:x}"]
    return a


def run_one(job):
    """job: dict(recipe, seed, stage1, cfg, prof, sim, cont, reset)"""
    t0 = time.time()
    cfg = dict(DEFAULT_CFG, **job["cfg"])
    try:
        exe = build(cfg, job["sim"])
        d, m = gen(job["recipe"], job["seed"], job["stage1"], cfg, job.get("cont", False))
        args = plusargs(d, m) + [f"+{k}={v}" for k, v in PROFILES[job["prof"]].items()]
        args.append(f"+SEED={job['seed'] * 7919 + 13}")
        if job.get("reset") is not None:
            db, mb = gen("rand" if not job["stage1"] else "rand", job["seed"] + 1000, job["stage1"], cfg)
            args += [f"+RESET_AT={job['reset']}"] + plusargs(db, mb, "B")
        if m.get("ext_hang", [0, 0])[1]:
            args = [a for a in args if not a.startswith("+HOST=")] + ["+HOST=0"]
        if job["sim"] == "verilator":
            cmd = [exe] + args
        else:
            cmd = ["vvp", "-n", exe] + args
        rc, out = sh(cmd, timeout=job.get("timeout", 3600))
        line = next((x for x in out.splitlines() if x.startswith("TB_RESULT")), None)
        ok = bool(line) and " PASS " in line
        if not ok:
            os.makedirs(os.path.join(BUILD, "fail"), exist_ok=True)
            with open(os.path.join(BUILD, "fail", f"{job_name(job)}.log"), "w") as fh:
                fh.write(" ".join(cmd) + "\n" + out)
        stats = dict(re.findall(r"(\w+)=(-?\d+)", line or ""))
        return dict(job, ok=ok, line=line or "(no TB_RESULT) " + out[-400:], stats=stats,
                    secs=round(time.time() - t0, 1), ncmd=m["ncmd"])
    except Exception as e:  # noqa: BLE001
        return dict(job, ok=False, line=f"EXCEPTION {e}", stats={}, secs=round(time.time() - t0, 1), ncmd=0)


def job_name(j):
    c = ",".join(f"{k}={v}" for k, v in sorted(j["cfg"].items()))
    return f"{j['recipe']}_s{j['seed']}_{j['prof']}_{j['sim']}_{c}{'_cont' if j.get('cont') else ''}" \
           f"{'_reset' if j.get('reset') is not None else ''}".replace("=", "").replace(",", "_")


# ============================================================================ job lists
def stage1_jobs(seeds, sim):
    jobs = []
    for qd, ovl, n, prof, seed in itertools.product((4, 8, 16), (1, 0), (2,), ("fast", "rand", "bp"), range(1, seeds + 1)):
        for r in gen_prog.STAGE1_RECIPES:
            jobs.append(dict(recipe=r, seed=seed, stage1=True, cfg=dict(QD=qd, OVL=ovl, N=n, OPSET=0),
                             prof=prof, sim=sim))
    return jobs


STAGE2_RECIPES = ["smoke", "rand", "b2b", "deps", "dbuf", "errors", "fp", "long", "dma_fault", "rstcnt"]


def stage2_jobs(seeds, sim):
    jobs = []
    cfgs = [dict(QD=qd, OVL=ovl, N=n, RD=rd) for qd, ovl, n, rd in
            [(4, 1, 2, 8), (8, 1, 2, 8), (16, 1, 2, 8), (4, 0, 2, 8), (16, 0, 2, 4), (8, 1, 4, 4), (16, 1, 4, 16),
             (8, 1, 2, 2)]]
    for c, prof, seed in itertools.product(cfgs, ("fast", "rand", "bp", "slow"), range(1, seeds + 1)):
        for r in STAGE2_RECIPES:
            jobs.append(dict(recipe=r, seed=seed, stage1=False, cfg=dict(c), prof=prof, sim=sim))
    # scratchpad fault configuration (window larger than the physical scratchpad)
    for c, prof, seed in itertools.product(cfgs[:4], ("fast", "rand", "bp"), range(1, seeds + 1)):
        jobs.append(dict(recipe="spm_fault", seed=seed, stage1=False, cfg=dict(c, PHYS=15), prof=prof, sim=sim))
    # watchdog / quarantine
    for c, prof, seed, cont in itertools.product(cfgs[:3], ("fast", "rand"), range(1, seeds + 1), (False, True)):
        for r in ("timeout_dma", "timeout_vec"):
            jobs.append(dict(recipe=r, seed=seed, stage1=False, cfg=dict(c, WDOG=10), prof=prof, sim=sim, cont=cont))
    # reset during activity
    for c, prof, seed in itertools.product(cfgs[:4], ("fast", "rand", "bp"), range(1, seeds + 1)):
        for at in (3, 20, 60):
            jobs.append(dict(recipe="rand", seed=seed + 50 * at, stage1=False, cfg=dict(c), prof=prof, sim=sim,
                             reset=at))
    # scratchpad read latency 2
    for prof, seed in itertools.product(("fast", "rand"), range(1, seeds + 1)):
        for r in ("rand", "deps", "dbuf", "spm_fault"):
            cfg = dict(SPMRL=2, PHYS=15) if r == "spm_fault" else dict(SPMRL=2)
            jobs.append(dict(recipe=r, seed=seed, stage1=False, cfg=cfg, prof=prof, sim=sim))
    # vector-executor flow control at minimum depth (operand / write-back queues of 1)
    for c, prof, seed in itertools.product([dict(OPQ=1, WBQ=1), dict(OPQ=4, WBQ=1, N=4), dict(OPQ=2, WBQ=1, N=4),
                                            dict(OPQ=1, WBQ=2)],
                                           ("fast", "rand", "slow"), range(1, seeds + 1)):
        for r in ("rand", "dbuf", "deps", "long", "fp"):
            jobs.append(dict(recipe=r, seed=seed, stage1=False, cfg=dict(c), prof=prof, sim=sim))
    return jobs


def icarus_jobs(seeds):
    """4-state cross-simulation: every stage-2 recipe, faults, watchdogs, reset, plus the stage-1 subset."""
    jobs = []
    for r, cfg in [(r, dict(QD=4)) for r in STAGE2_RECIPES] + [("spm_fault", dict(QD=8, PHYS=15)),
                                                              ("timeout_dma", dict(QD=8, WDOG=10)),
                                                              ("timeout_vec", dict(QD=8, WDOG=10))]:
        for prof, seed in itertools.product(("fast", "rand"), range(1, seeds + 1)):
            jobs.append(dict(recipe=r, seed=seed, stage1=False, cfg=cfg, prof=prof, sim="icarus"))
    jobs.append(dict(recipe="rand", seed=7, stage1=False, cfg=dict(QD=16, OVL=0), prof="bp", sim="icarus"))
    jobs.append(dict(recipe="rand", seed=3, stage1=False, cfg=dict(QD=8), prof="rand", sim="icarus", reset=20))
    for r in ["smoke", "rand", "deps", "errors"]:
        jobs.append(dict(recipe=r, seed=1, stage1=True, cfg=dict(QD=8, OPSET=0), prof="rand", sim="icarus"))
    return jobs


def run_extra(kind):
    """Directed MMIO-adapter test (tb_hpc_cq_mmio) or the C host co-simulation."""
    d = os.path.join(BUILD, kind)
    os.makedirs(d, exist_ok=True)
    base = ["verilator", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN",
            "-DHPC_SPM_ASSERT", "-DSRAMLIB_ASSERT", "-Mdir", d, "-f", "rtl/files.f", "-f", "rtl/files_sim_stubs.f",
            "rtl/hpc_cq_mmio.sv"]
    if kind == "mmio":
        cmd = base + ["--binary", "--timing", "--assert", "--timescale", "1ns/1ps", "-o", "sim",
                      "--top-module", "tb_hpc_cq_mmio", "tb/hpc_cq_sva.sv", "tb/tb_hpc_cq_mmio.sv"]
        exe, ok_pat = [os.path.join(d, "sim")], "TB_RESULT PASS"
    else:
        cmd = base + ["--cc", "--exe", "--build", "-o", "cosim", "--top-module", "cosim_top",
                      "-CFLAGS", f"-DHPC_CQ_COSIM -I{ROOT}/sw -O1", "tb/tb_ext_mem.sv", "tb/cosim/cosim_top.sv",
                      f"{ROOT}/tb/cosim/cosim_main.cpp", f"{ROOT}/sw/hpc_cq.c", f"{ROOT}/sw/examples/cq_submit_demo.c"]
        exe, ok_pat = [os.path.join(d, "cosim")], "DEMO PASS"
    with _BUILD_LOCK:
        rc, out = sh(cmd, log=os.path.join(d, "build.log"), timeout=3600)
    if rc != 0:
        return False, f"build failed, see {d}/build.log"
    rc, out = sh(exe, timeout=1200)
    with open(os.path.join(d, "run.log"), "w") as fh:
        fh.write(out)
    return (rc == 0 and ok_pat in out), out


def report(name, results, t0):
    os.makedirs(REPORTS, exist_ok=True)
    npass = sum(r["ok"] for r in results)
    with open(os.path.join(REPORTS, f"regression_{name}.json"), "w") as fh:
        json.dump(results, fh, indent=1)
    lines = [f"# Regression `{name}`", "",
             f"**{npass} / {len(results)} runs pass** ({time.time() - t0:.0f} s wall clock, "
             f"{sum(r['ncmd'] for r in results)} commands).", ""]
    # per recipe summary
    by = {}
    for r in results:
        k = (r["recipe"], r["sim"])
        b = by.setdefault(k, [0, 0, 0, 0, 0])
        b[0] += 1
        b[1] += r["ok"]
        b[2] += r["ncmd"]
        b[3] += int(r["stats"].get("overlap", 0))
        b[4] += int(r["stats"].get("alt", 0))
    lines += ["| recipe | simulator | runs | pass | commands | overlap cycles | timing-dependent records |",
              "|---|---|---|---|---|---|---|"]
    for (rec, sim), b in sorted(by.items()):
        lines.append(f"| {rec} | {sim} | {b[0]} | {b[1]} | {b[2]} | {b[3]} | {b[4]} |")
    fails = [r for r in results if not r["ok"]]
    if fails:
        lines += ["", "## Failures", ""]
        for r in fails[:50]:
            lines.append(f"* `{job_name(r)}`: {r['line'][:300]}")
    lines += ["", "## All runs", "", "| run | result | cycles | cmds | overlap | hazard stalls | sync stalls | s |",
              "|---|---|---|---|---|---|---|---|"]
    for r in results:
        s = r["stats"]
        lines.append(f"| `{job_name(r)}` | {'PASS' if r['ok'] else 'FAIL'} | {s.get('cycles', '')} | {r['ncmd']} | "
                     f"{s.get('overlap', '')} | {s.get('hazard_stall', '')} | {s.get('sync_stall', '')} | {r['secs']} |")
    with open(os.path.join(REPORTS, f"regression_{name}.md"), "w") as fh:
        fh.write("\n".join(lines) + "\n")
    return npass


def run_jobs(name, jobs, nproc):
    t0 = time.time()
    # build every configuration first (serially: verilator is parallel itself)
    seen = set()
    for j in jobs:
        k = cfg_key(dict(DEFAULT_CFG, **j["cfg"]), j["sim"])
        if k not in seen:
            seen.add(k)
            print(f"build {k}", flush=True)
            build(dict(DEFAULT_CFG, **j["cfg"]), j["sim"])
    results = []
    with ThreadPoolExecutor(max_workers=nproc) as ex:
        for r in ex.map(run_one, jobs):
            results.append(r)
            if not r["ok"]:
                print(f"FAIL {job_name(r)}: {r['line'][:200]}", flush=True)
            if len(results) % 25 == 0:
                print(f"  {len(results)}/{len(jobs)} done, {sum(x['ok'] for x in results)} pass", flush=True)
    n = report(name, results, t0)
    print(f"{name}: {n}/{len(results)} pass")
    return n == len(results)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("what", choices=["stage1", "stage2", "icarus", "all", "one", "mmio", "cosim"])
    ap.add_argument("recipe", nargs="?")
    ap.add_argument("--seeds", type=int, default=1)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--stage1", action="store_true")
    ap.add_argument("--cfg", default="")
    ap.add_argument("--prof", default="rand")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--sim", default="verilator")
    ap.add_argument("--cont", action="store_true")
    ap.add_argument("--reset", type=int, default=None)
    ap.add_argument("--rerun-failed", action="store_true",
                    help="stage1/stage2/icarus: re-run only the runs that failed in reports/regression_<stage>.json")
    a = ap.parse_args()
    if a.what in ("mmio", "cosim"):
        ok, out = run_extra(a.what)
        print(out[-3000:])
        print(f"{a.what}: {'PASS' if ok else 'FAIL'}")
        sys.exit(0 if ok else 1)
    if a.what == "one":
        cfg = {k: int(v) for k, v in (x.split("=") for x in a.cfg.split(",") if x)}
        if a.stage1:
            cfg.setdefault("OPSET", 0)
        r = run_one(dict(recipe=a.recipe, seed=a.seed, stage1=a.stage1, cfg=cfg, prof=a.prof, sim=a.sim,
                         cont=a.cont, reset=a.reset))
        print(r["line"])
        sys.exit(0 if r["ok"] else 1)
    ok = True
    if a.rerun_failed:
        prev = json.load(open(os.path.join(REPORTS, f"regression_{a.what}.json")))
        keep = [r for r in prev if r["ok"]]
        redo = [{k: r[k] for k in ("recipe", "seed", "stage1", "cfg", "prof", "sim") if k in r} |
                {k: r[k] for k in ("cont", "reset") if k in r} for r in prev if not r["ok"]]
        print(f"re-running {len(redo)} failed runs of {a.what}")
        t0 = time.time()
        with ThreadPoolExecutor(max_workers=a.jobs) as ex:
            new = list(ex.map(run_one, redo))
        for r in new:
            r["rerun"] = True
        n = report(a.what, keep + new, t0)
        print(f"{a.what}: {n}/{len(keep) + len(new)} pass after re-run")
        sys.exit(0 if n == len(keep) + len(new) else 1)
    if a.what in ("stage1", "all"):
        ok &= run_jobs("stage1", stage1_jobs(a.seeds, "verilator"), a.jobs)
    if a.what in ("stage2", "all"):
        ok &= run_jobs("stage2", stage2_jobs(a.seeds, "verilator"), a.jobs)
    if a.what in ("icarus", "all"):
        ok &= run_jobs("icarus", icarus_jobs(a.seeds), a.jobs)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
