#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: coverage -- stimulus coverage of the regression

Every regression run compares every completion record with the reference
model, so what the programs contain is what was checked.  This script reads
all generated programs (build/progs/*/cmds.hex + exp.hex) and reports which
opcodes, statuses, error codes, flags, rounding modes, DMA tail lengths,
vector length classes and aliasing cases were exercised, and how often.
Report: reports/coverage.md
"""
import collections
import glob
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "ref"))
import hpc_cq_abi as A  # noqa: E402

ERR_NAMES = {v: k for k, v in vars(A).items() if k.startswith("ERR_") and isinstance(v, int)
             and k not in ("ERR_DMA_BASE", "ERR_VEC_BASE")}


def words(line, n):
    v = int(line, 16)
    return [(v >> (32 * i)) & 0xFFFFFFFF for i in range(n)]


def main():
    progs = sorted(glob.glob(os.path.join(ROOT, "build", "progs", "*")))
    c_op_st = collections.Counter()
    c_err = collections.Counter()
    c_flags = collections.Counter()
    c_rm = collections.Counter()
    c_tail = collections.Counter()
    c_vl = collections.Counter()
    c_alias = collections.Counter()
    c_alt = 0
    n = 0
    for p in progs:
        try:
            cmds = [words(x, 8) for x in open(os.path.join(p, "cmds.hex")).read().split()]
            exps = [words(x, 4) for x in open(os.path.join(p, "exp.hex")).read().split()]
            alts = [int(x, 16) for x in open(os.path.join(p, "altm.hex")).read().split()]
        except FileNotFoundError:
            continue
        for d, e, am in zip(cmds, exps, alts):
            n += 1
            f = A.desc_fields(d)
            r = A.rec_fields(e)
            op = A.OPCODES.get(f["op"], "reserved")
            st = {0: "OK", 1: "ERROR", 2: "SKIPPED"}[r["st"]]
            c_op_st[(op, st)] += 1
            c_err[ERR_NAMES.get(r["err"], hex(r["err"]))] += 1
            c_alt += am != 0
            if r["st"] == A.ST_OK:
                for b, name in ((0, "IRQ"), (1, "BARRIER")):
                    if f["flags"] >> b & 1:
                        c_flags[(op, name)] += 1
                if f["op"] in A.VEC_OPS:
                    c_rm[(op, f["rm"])] += 1
                    L = f["length"]
                    c_vl["1" if L == 1 else "2..15" if L < 16 else "16..255" if L < 256 else ">=256"] += 1
                    c_vl[f"vl mod 4 = {L % 4}"] += 1
                    c_alias["D == A" if f["dst"] == f["sa"] else "D == B" if f["dst"] == f["sb"] else "D disjoint"] += 1
                    if f["sa"] == f["sb"]:
                        c_alias["A == B"] += 1
                if f["op"] in A.DMA_OPS:
                    c_tail[(op, f["length"] % 4)] += 1
    out = ["# Stimulus coverage", "",
           f"{len(progs)} generated programs, {n} commands; every record was compared with the reference model "
           f"({c_alt} records with a timing-dependent alternative).", "",
           "## Opcode x status", "", "| opcode | OK | ERROR | SKIPPED |", "|---|---|---|---|"]
    for op in list(A.OPCODES.values()) + ["reserved"]:
        out.append(f"| {op} | {c_op_st[(op, 'OK')]} | {c_op_st[(op, 'ERROR')]} | {c_op_st[(op, 'SKIPPED')]} |")
    out += ["", "## Error codes in expected records", "", "| code | records |", "|---|---|"]
    for k in sorted(ERR_NAMES.values(), key=lambda x: getattr(A, x)):
        out.append(f"| `{k}` (0x{getattr(A, k):02X}) | {c_err[k]} |")
    out += ["", "Never expected, by construction: `ERR_DMA_ABORTED` (an aborted job has already completed with "
            "TIMEOUT, its late outcome is ignored).  **Not exercised:** `ERR_VEC_ENGINE` -- the reused Module 03 array "
            "never returns an illegal or short completion record, and no fault can be injected into it without "
            "modifying it, so this guard is untested (docs/07 sec. 3).", "",
            "## Executed commands: flags, rounding modes, tails, lengths, aliasing", "",
            "| item | count |", "|---|---|"]
    for k, v in sorted(c_flags.items()):
        out.append(f"| {k[0]} with FL_{k[1]} | {v} |")
    for k, v in sorted(c_rm.items()):
        out.append(f"| {k[0]} RM={['RNE', 'RTZ', 'RDN', 'RUP', 'RMM'][k[1]]} | {v} |")
    for k, v in sorted(c_tail.items()):
        out.append(f"| {k[0]} LENGTH mod 4 = {k[1]} | {v} |")
    for k, v in sorted(c_vl.items()):
        out.append(f"| vector LENGTH {k} | {v} |")
    for k, v in sorted(c_alias.items()):
        out.append(f"| vector {k} | {v} |")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "coverage.md"), "w").write("\n".join(out) + "\n")
    print("\n".join(out))


if __name__ == "__main__":
    main()
