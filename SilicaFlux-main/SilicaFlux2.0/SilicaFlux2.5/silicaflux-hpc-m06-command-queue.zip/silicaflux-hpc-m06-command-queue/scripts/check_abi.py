#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: check_abi -- the three halves of ABI v1 agree

Compares, value by value:
  rtl/hpc_cq_pkg.sv      (RTL)       <->  sw/hpc_cq_abi.h (C)  <->  ref/hpc_cq_abi.py (Python)
  rtl/hpc_cq_mmio.sv     register offsets / ID  <-> C <-> Python
  reused encodings       rounding modes = Module 02 hpc_vector_pkg RM_*,
                         ERR_DMA_* = 0x10 | DataFabric dma_defs.svh DMA_ERR_*
Writes reports/abi_check.md; exit status 1 on any mismatch.
"""
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "ref"))
import hpc_cq_abi as PY  # noqa: E402


def sv_value(txt):
    txt = txt.strip()
    txt = re.sub(r"(\d+)?'([hdb])([0-9a-fA-F_]+)",
                 lambda m: str(int(m.group(3).replace("_", ""), {"h": 16, "d": 10, "b": 2}[m.group(2)])), txt)
    try:
        return int(eval(txt, {"__builtins__": {}}))  # noqa: S307 -- simple arithmetic on literals only
    except Exception:  # noqa: BLE001
        return None


def sv_params(path):
    s = open(path).read()
    s = re.sub(r"//.*", "", s)
    out = {}
    for m in re.finditer(r"localparam\s+(?:logic\s*(?:\[[^\]]*\])?|int|bit)?\s*(\w+\s*=[^;]+);", s):
        for item in m.group(1).split(","):          # localparam A = 1, B = 2;
            if "=" in item:
                k, v = item.split("=", 1)
                v = sv_value(v)
                if v is not None:
                    out[k.strip()] = v
    return out


def sv_defines(path):
    out = {}
    for m in re.finditer(r"`define\s+(\w+)\s+([0-9]+'[hdb][0-9a-fA-F_]+|\d+)", open(path).read()):
        out[m.group(1)] = sv_value(m.group(2))
    return out


def c_defines(path):
    out = {}
    for m in re.finditer(r"#define\s+HPC_CQ_(\w+)\s+\(?(0x[0-9A-Fa-f]+|\d+)u?\)?\s", open(path).read()):
        out[m.group(1)] = int(m.group(2), 0)
    return out


def main():
    pkg = sv_params(os.path.join(ROOT, "rtl/hpc_cq_pkg.sv"))
    mmio = sv_params(os.path.join(ROOT, "rtl/hpc_cq_mmio.sv"))
    vpkg = sv_params(os.path.join(ROOT, "third_party/silicaflux-hpc-m03-vector-array/rtl/lane/hpc_vector_pkg.sv"))
    dma = sv_defines(os.path.join(ROOT, "third_party/silicaflux-datafabric/rtl/dma/dma_defs.svh"))
    c = c_defines(os.path.join(ROOT, "sw/hpc_cq_abi.h"))
    rows, bad = [], 0

    def chk(name, *vals):
        nonlocal bad
        ok = all(v is not None for v in vals) and len(set(vals)) == 1
        bad += not ok
        rows.append((name, vals, ok))

    names = [n for n in pkg if re.match(r"(OP_|ERR_|ST_|FL_|PC_|W_)", n) and n not in ("PC_N",)]
    names += ["ABI_VERSION", "FLAGS_V1_MASK", "PC_N", "DESC_WORDS"]
    for n in sorted(set(names)):
        py = PY.PC.get(n[3:]) if n.startswith("PC_") and n != "PC_N" else getattr(PY, n, None)
        chk(n, pkg.get(n), c.get(n), None if isinstance(py, tuple) else py)
    # header / record field positions
    for sv, py in (("H_OP_LSB", "H_OP"), ("H_VER_LSB", "H_VER"), ("H_RM_LSB", "H_RM"), ("H_FLAGS_LSB", "H_FLAGS"),
                   ("H_TID_LSB", "H_TID"), ("R_TID_LSB", "R_TID"), ("R_OP_LSB", "R_OP"), ("R_ERR_LSB", "R_ERR"),
                   ("R_STATUS_LSB", "R_STATUS"), ("R_FFLAGS_LSB", "R_FFLAGS")):
        chk(sv, pkg.get(sv), c.get(sv), getattr(PY, py)[0])
    chk("H_RSVD_BIT", pkg.get("H_RSVD_BIT"), c.get("H_RSVD_BIT"), PY.H_RSVD_BIT)
    chk("R_IRQ_BIT", pkg.get("R_IRQ_BIT"), c.get("R_IRQ_BIT"), PY.R_IRQ_BIT)
    chk("REC_WORDS (=REC_W/32)", pkg["REC_W"] // 32, c.get("REC_WORDS"), PY.REC_WORDS)
    chk("DESC_W/32", pkg["DESC_W"] // 32, c.get("DESC_WORDS"), PY.DESC_WORDS)
    # performance-counter names in order
    for i, n in enumerate(PY.PC_NAMES):
        chk(f"PC_{n} (Python order)", pkg.get("PC_" + n), c.get("PC_" + n), i)
    # MMIO
    mm = dict(ID="A_ID", INFO="A_INFO", CTRL="A_CTRL", STATUS="A_STATUS", INT_ENABLE="A_IE", INT_STATUS="A_IS",
              SUBMITTED="A_SUBM", DESC0="A_DESC0", DOORBELL="A_DOORBELL", CPL0="A_CPL0", CPL_POP="A_CPLPOP",
              PERF0="A_PERF0")
    for k, sv in mm.items():
        chk(f"REG_{k}", mmio.get(sv), c.get("REG_" + k), PY.MMIO[k])
    chk("ID_VALUE", mmio.get("ID_VALUE"), c.get("ID_VALUE"), PY.MMIO_ID_VALUE)
    # reused encodings
    for r in ("RNE", "RTZ", "RDN", "RUP", "RMM"):
        chk(f"RM_{r} (= Module 02 hpc_vector_pkg)", vpkg.get("RM_" + r), c.get("RM_" + r), getattr(PY, "RM_" + r))
    for cq, df in (("ERR_DMA_READ", "DMA_ERR_READ_BUS"), ("ERR_DMA_WRITE", "DMA_ERR_WRITE_BUS"),
                   ("ERR_DMA_ABORTED", "DMA_ERR_ABORTED")):
        chk(f"{cq} (= 0x10 | DataFabric {df})", pkg.get(cq), c.get(cq), 0x10 | dma[df])
    chk("FFLAGS order NV (= Module 02 FLAG_NV)", vpkg.get("FLAG_NV"), 4, 4)

    lines = ["# ABI v1 consistency check", "",
             f"**{len(rows) - bad} / {len(rows)} items agree** across `rtl/hpc_cq_pkg.sv`, `rtl/hpc_cq_mmio.sv`, "
             "`sw/hpc_cq_abi.h`, `ref/hpc_cq_abi.py` and the reused Module 02 / DataFabric encodings.", "",
             "| item | RTL | C | Python / reference | |", "|---|---|---|---|---|"]
    for n, vals, ok in rows:
        lines.append(f"| `{n}` | " + " | ".join("—" if v is None else hex(v) for v in vals) + f" | {'ok' if ok else '**MISMATCH**'} |")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, "reports", "abi_check.md"), "w") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"ABI check: {len(rows) - bad}/{len(rows)} agree")
    for n, vals, ok in rows:
        if not ok:
            print("  MISMATCH", n, vals)
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
