#!/usr/bin/env python3
"""
SilicaFlux-HPC Module 06 :: lint -- static checks of the new RTL

  1. Verilator 5.020 --lint-only -Wall on hpc_cq_tile and hpc_cq_mmio for
     several parameter sets: zero warnings in rtl/ (the new code) required;
     warnings inside third_party/ (reused, unmodified) are counted only.
  2. Icarus 12 elaboration of hpc_cq_tile + hpc_cq_mmio (4-state compiler).
  3. Invalid parameter combinations must FAIL elaboration (hpc_param_error_*).
Report: reports/lint.md
"""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FL = ["-f", "rtl/files.f", "-f", "rtl/files_sim_stubs.f", "rtl/hpc_cq_mmio.sv"]


def sh(cmd):
    p = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return p.returncode, p.stdout


def verilator(top, params):
    return sh(["verilator", "--lint-only", "-Wall", "-Wno-fatal", "--top-module", top] +
              [f"-G{k}={v}" for k, v in params.items()] + FL)


def main():
    lines = ["# Lint and elaboration checks", ""]
    ok = True
    # ------------------------------------------------------------------ 1. Verilator -Wall
    sets = [("hpc_cq_tile", dict()), ("hpc_cq_tile", dict(QUEUE_DEPTH=4, NUM_LANES=1)),
            ("hpc_cq_tile", dict(QUEUE_DEPTH=16, NUM_LANES=4, ROB_DEPTH=16)),
            ("hpc_cq_tile", dict(NUM_LANES=8, ROB_DEPTH=2, OVERLAP_EN=0, OPSET_FULL=0)),
            ("hpc_cq_tile", dict(NUM_LANES=16, WDOG_LOG2=0, PERF_EN=0)),
            ("hpc_command_queue", dict(QUEUE_DEPTH=8)), ("hpc_cq_mmio", dict())]
    lines += ["## Verilator 5.020 `--lint-only -Wall`", "",
              "| top | parameters | errors | warnings in `rtl/` (new) | warnings in `third_party/` (reused) |",
              "|---|---|---|---|---|"]
    for top, prm in sets:
        rc, out = verilator(top, prm)
        errs = len(re.findall(r"^%Error", out, re.M))
        own = [x for x in out.splitlines() if x.startswith("%Warning") and " rtl/" in x]
        tp = [x for x in out.splitlines() if x.startswith("%Warning") and "third_party/" in x]
        lines.append(f"| `{top}` | {', '.join(f'{k}={v}' for k, v in prm.items()) or 'defaults'} | {errs} | "
                     f"{len(own)} | {len(tp)} |")
        if errs or own:
            ok = False
            lines += ["", "```", *own[:20], "```", ""]
    # ------------------------------------------------------------------ 2. Icarus
    files, incs = [], []
    for f in ("rtl/files.f", "rtl/files_sim_stubs.f"):
        for line in open(os.path.join(ROOT, f)):
            line = line.split("//")[0].strip()
            if line.startswith("+incdir+"):
                incs.append("-I" + line[8:])
            elif line:
                files.append(line)
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    rc, out = sh(["iverilog", "-g2012", "-o", "build/lint_ivl.vvp", "-s", "hpc_cq_tile", "-s", "hpc_cq_mmio"]
                 + incs + files + ["rtl/hpc_cq_mmio.sv"])
    errs = [x for x in out.splitlines() if re.search(r": error:|^error:|internal error|assert", x)]
    lines += ["", "## Icarus Verilog 12 elaboration", "",
              f"`hpc_cq_tile` + `hpc_cq_mmio`: exit {rc}, {len(errs)} errors "
              f"({out.count('sorry:')} 'sorry: constant selects in always_*' notes, all in sensitivity lists, "
              "also emitted for the reused DataFabric / Module 04 sources)."]
    ok &= rc == 0 and not errs
    # ------------------------------------------------------------------ 3. negative elaboration
    neg = [("hpc_command_queue", dict(QUEUE_DEPTH=5), "QUEUE_DEPTH_must_be_4_8_or_16"),
           ("hpc_command_queue", dict(QUEUE_DEPTH=2), "QUEUE_DEPTH_must_be_4_8_or_16"),
           ("hpc_command_queue", dict(QUEUE_DEPTH=32), "QUEUE_DEPTH_must_be_4_8_or_16"),
           ("hpc_command_queue", dict(ROB_DEPTH=1), "ROB_DEPTH_must_be_2_to_64"),
           ("hpc_command_queue", dict(EXT_BASE="32'h10001000"), "window_base_not_aligned_to_size"),
           ("hpc_command_queue", dict(SPM_BASE="32'h10010000"), "EXT_and_SPM_windows_overlap"),
           ("hpc_command_queue", dict(SPM_LOG2=2), "window_LOG2_must_be_3_to_31"),
           ("hpc_command_queue", dict(WDOG_LOG2=40), "WDOG_LOG2_must_be_0_to_31"),
           ("hpc_command_queue", dict(VL_W=29), "DMA_MAX_LEN_LOG2_or_VL_W_out_of_range"),
           ("hpc_cq_tile", dict(SPM_PHYS_LOG2=17), "SPM_PHYS_LOG2_above_SPM_LOG2"),
           ("hpc_cq_tile", dict(NUM_LANES=3), "NUM_LANES_must_be"),
           ("hpc_cq_vexec", dict(N=3), "VEXEC_N_must_be_1_2_4_8_or_16"),
           ("hpc_cq_vexec", dict(TAG_W=1), "VEXEC_TAG_W_below_2")]
    lines += ["", "## Invalid parameter combinations (must fail elaboration)", "",
              "| top | parameters | rejected | message |", "|---|---|---|---|"]
    for top, prm, pat in neg:
        rc, out = sh(["verilator", "--lint-only", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", top] +
                     [f"-G{k}={v}" for k, v in prm.items()] + FL)
        rej = rc != 0 and pat in out
        ok &= rej
        lines.append(f"| `{top}` | {', '.join(f'{k}={v}' for k, v in prm.items())} | {'yes' if rej else '**NO**'} | "
                     f"`hpc_param_error_{pat}` |")
    lines += ["", f"**Result: {'PASS' if ok else 'FAIL'}**"]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "lint.md"), "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
