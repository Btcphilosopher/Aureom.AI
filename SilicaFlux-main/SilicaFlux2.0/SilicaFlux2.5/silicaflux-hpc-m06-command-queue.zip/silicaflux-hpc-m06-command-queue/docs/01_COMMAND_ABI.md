# 01 — Command ABI, version 1

The command descriptor and completion record shared by the hardware, host software and the verification model.
One ABI, three mechanically-checked halves:

| Half | File |
|---|---|
| RTL | `rtl/hpc_cq_pkg.sv` |
| C | `sw/hpc_cq_abi.h` (+ `sw/hpc_cq.h` builders, `hpc_cq_check()`) |
| Python (reference model) | `ref/hpc_cq_abi.py` |

`scripts/check_abi.py` compares every opcode, flag, field position, status / error code, counter index and MMIO
offset across the three, plus the encodings reused from earlier modules. It passes **117 / 117** items
(`reports/abi_check.md`).

Values are frozen once published. New operations may only take reserved code points. A layout change needs a new
`VERSION`.

## 1. Conventions reused, not reinvented

| Field | Encoding | Source |
|---|---|---|
| Rounding mode `RM` | RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4; 5–7 illegal | Module 02 `hpc_vector_pkg::RM_*` = RISC-V `frm` |
| FP exception flags `FFLAGS` | `{NV, DZ, OF, UF, NX}`, NV most significant | Module 02 / RISC-V `fflags` |
| DMA failure codes | `0x10 \| DMA_ERR_*` | DataFabric `dma_defs.svh` |
| DMA length unit, alignment, tail behaviour | bytes, 4-byte aligned addresses, byte-accurate tail strobe | DataFabric `silicaflux_dma` (`docs/datafabric/DMA.md` §2) |
| Vector length unit | FP32 elements | Module 03 `cmd_vl_i` |
| Transaction id | 8 bits, echoed, uniqueness not required | Module 03 `TID_W = 8` |
| Byte order | little-endian words | SFB2 / SilicaFlux-V |

## 2. Command descriptor (256 bits = 8 × 32-bit words)

Word *w* is bits `[32w+31 : 32w]` of `cmd_desc_i`, and byte offsets `4w … 4w+3` of a descriptor in memory.

| Word | Name | Bits | Meaning |
|---|---|---|---|
| 0 | `HDR` | `[7:0]` `OPCODE` | §3 |
|   |       | `[11:8]` `VERSION` | must be **1** |
|   |       | `[14:12]` `RM` | rounding mode (vector ops); must be 0 otherwise |
|   |       | `[15]` | reserved, must be 0 |
|   |       | `[23:16]` `FLAGS` | §4 |
|   |       | `[31:24]` `TID` | transaction id, echoed in the record |
| 1 | `SRC_A` | 32 | source A byte address |
| 2 | `SRC_B` | 32 | source B byte address |
| 3 | `DST` | 32 | destination byte address |
| 4 | `LENGTH` | 32 | **bytes** for DMA ops; **FP32 elements** for vector ops; 0 otherwise |
| 5 | `STRIDE` | 32 | element stride. v1 implements packed data only: must be 0 |
| 6 | — | 32 | reserved, must be 0 (future: source C) |
| 7 | — | 32 | reserved, must be 0 |

The command FIFO stores words 0–5 plus a single "word 6 or 7 non-zero" bit (`hpc_cq_pkg::QE_W = 193` bits per
entry). Nothing a v1 command can use is lost.

## 3. Opcodes

| Code | Name | Operation | Uses |
|---|---|---|---|
| `0x00` | `NOP` | nothing; completes in order | — |
| `0x01` | `DMA_LOAD` | copy `LENGTH` bytes `EXT[SRC_A] → SPM[DST]` | `SRC_A`, `DST`, `LENGTH` |
| `0x02` | `DMA_STORE` | copy `LENGTH` bytes `SPM[SRC_A] → EXT[DST]` | `SRC_A`, `DST`, `LENGTH` |
| `0x10` | `VECTOR_ADD` | `D[i] = A[i] + B[i]`, i < `LENGTH` | `SRC_A`, `SRC_B`, `DST`, `LENGTH`, `RM` |
| `0x11` | `VECTOR_MUL` | `D[i] = A[i] × B[i]` | as above |
| `0x12` | `VECTOR_FMA` | `D[i] = A[i] × B[i] + D[i]`, one rounding (D is read, then written) | as above |
| `0x20` | `FENCE` | barrier (docs/03) | — |
| `0x30` | `RESET_COUNTERS` | clear the performance counters at a defined point (docs/03 §4) | — |
| `0x03`–`0x0F`, `0x13`–`0x1F`, `0x21`–`0x2F`, `0x31`–`0xFF` | reserved | rejected: `ERR_OPCODE` | |

* **Classes.** `0x0X` DMA, `0x1X` vector, `0x2X` synchronisation, `0x3X` control. New opcodes go into their class.
* **Bring-up subset.** With `OPSET_FULL = 0` only `NOP`, `DMA_LOAD`, `VECTOR_ADD` and `FENCE` are implemented. The other
  four v1 opcodes are then rejected with `ERR_OPCODE`, like reserved ones. This is the stage-1 configuration of the
  regression (docs/06 §1).
* **FP semantics** are those of the Module 03 array (Module 02 `docs/FP_SEMANTICS.md`):
  * IEEE 754-2019 binary32;
  * RISC-V canonical NaN;
  * tininess after rounding;
  * subnormals supported.

  `VECTOR_ADD` / `MUL` / `FMA` run the array's `FADD` (0x01) / `FMUL` (0x03) / `FMADD` (0x04) operations.

## 4. Flags

| Bit | Name | Meaning |
|---|---|---|
| 0 | `FL_IRQ` | when this command **commits**, pulse `ev_commit_irq_o` (MMIO: `INT_STATUS.IRQ`). Echoed in the record. |
| 1 | `FL_BARRIER` | do not issue before every older command has completed (an implicit FENCE in front of this command) |
| 2–7 | reserved | rejected: `ERR_FLAGS` |

Every v1 opcode accepts `IRQ` and `BARRIER` (`hpc_cq_pkg::flags_allowed`). Later versions may restrict flags per opcode.

## 5. Address windows, units and alignment

The queue validates every address against two windows, set by parameters. The defaults are the
SilicaFlux-V / DataFabric map.

| Window | Parameter | Default | Contents |
|---|---|---|---|
| EXT | `EXT_BASE`, `EXT_LOG2` | `0x1000_0000`, 128 KiB | external memory (SRAM banks 0–3) |
| SPM | `SPM_BASE`, `SPM_LOG2` | `0x2000_0000`, 64 KiB | tile scratchpad (Module 04) |

Window rules, checked at elaboration:
* each size is a power of two;
* each base is aligned to its size;
* the two windows are disjoint.

| Command | Range checked | Unit of `LENGTH` | Max `LENGTH` | Alignment |
|---|---|---|---|---|
| `DMA_LOAD` | `[SRC_A, SRC_A+LENGTH)` ⊂ EXT, `[DST, DST+LENGTH)` ⊂ SPM | bytes | 2^24 (`DMA_MAX_LEN_LOG2`) | `SRC_A`, `DST` 4-byte aligned. `LENGTH` need not be a multiple of 4: the final partial word is written with a byte strobe, bytes beyond `LENGTH` are never modified. |
| `DMA_STORE` | `[SRC_A, …)` ⊂ SPM, `[DST, …)` ⊂ EXT | bytes | 2^24 | as above |
| vector | `[X, X + 4·LENGTH)` ⊂ SPM for X = A, B, D | FP32 elements | 2^16 − 1 (`VL_W`), and the window | A, B, D 4-byte aligned |
| others | all fields 0 | — | — | — |

A range that wraps past 2^32 always fails. **Aliasing rule for vector ops:** the destination range must be either
*identical to* or *disjoint from* each source range. In-place operation (`D = A`) is legal. A partial overlap is
rejected (`ERR_OVERLAP`) because its result would depend on execution order. Sources may overlap each other freely.

## 6. Validation (before any side effect)

The first failing rule wins, in this order. A failing command has **no** side effect.

| # | Rule | Code |
|---|---|---|
| 1 | `VERSION ≠ 1` | `0x01 ERR_VERSION` |
| 2 | opcode reserved, or not in the configured set | `0x02 ERR_OPCODE` |
| 3 | a flag outside `flags_allowed(opcode)` | `0x03 ERR_FLAGS` |
| 4 | `HDR[15]`, word 6 or word 7 ≠ 0; DMA with `SRC_B ≠ 0` or `RM ≠ 0`; NOP / FENCE / RESET_COUNTERS with any field ≠ 0 | `0x04 ERR_RSVD` |
| 5 | DMA or vector op with `STRIDE ≠ 0` | `0x05 ERR_STRIDE` |
| 6 | vector op with `RM` ∈ {5, 6, 7} | `0x06 ERR_RM` |
| 7 | `LENGTH = 0`, or above its maximum | `0x07 ERR_LENGTH` |
| 8 | a used address not 4-byte aligned | `0x08 ERR_ALIGN` |
| 9 | a range outside its window, or wrapping | `0x09 ERR_RANGE` |
| 10 | vector destination partially overlaps source A or B | `0x0A ERR_OVERLAP` |

The DMA rules are a strict superset of DataFabric `dma_validate`. Every DMA job the queue issues is therefore one the
engine accepts. The scheduler checks this in simulation with the engine's own `dma_validate` instance.
`hpc_cq_check()` in the C driver implements the same rules for host-side pre-checking.

## 7. Completion record (128 bits = 4 × 32-bit words)

| Word | Bits | Field | Meaning |
|---|---|---|---|
| 0 | `[7:0]` | `TID` | echo of the descriptor's TID |
|   | `[15:8]` | `OPCODE` | echo (also for rejected opcodes) |
|   | `[23:16]` | `ERR_CODE` | §8; 0 when `STATUS = OK` |
|   | `[25:24]` | `STATUS` | 0 `OK`, 1 `ERROR`, 2 `SKIPPED`, 3 reserved |
|   | `[26]` | `IRQ` | echo of `FL_IRQ` |
|   | `[31:27]` | `FFLAGS` | vector ops: OR of `{NV,DZ,OF,UF,NX}` over all elements (bit 31 = NV); 0 otherwise |
| 1 | 32 | `COUNT` | DMA: bytes written **and acknowledged** (contiguous prefix, DataFabric `BYTES_DONE`); vector: destination elements written and acknowledged; 0 otherwise |
| 2 | 32 | `ERR_ADDR` | bus address of the failing access for DMA / vector bus errors; 0 otherwise |
| 3 | 32 | `SEQ` | sequence number: the *n*-th command accepted after reset has `SEQ = n − 1` |

**Guarantees.**
* Exactly one record per accepted command.
* Records come strictly in acceptance order, `SEQ` = 0, 1, 2, … — whatever the opcode, the error, the execution
  overlap or the back-pressure.
* A record is presented only after the command has **committed**: it and every older command have completed.

## 8. Error codes

| Code | Name | Raised | Status |
|---|---|---|---|
| `0x00` | `NONE` | | OK |
| `0x01`–`0x0A` | validation (§6) | at decode, nothing executed | ERROR |
| `0x18` | `DMA_READ` | the DMA engine got an SFB2 error on a source read (unmapped, protected, scratchpad RANGE, poisoned) | ERROR |
| `0x19` | `DMA_WRITE` | … on a destination write | ERROR |
| `0x1A` | `DMA_ABORTED` | the engine was aborted after a watchdog timeout and then finished | (not reported: the job already completed `TIMEOUT`) |
| `0x11`–`0x17` | DataFabric start-time codes | never: the queue's validation is a superset (asserted) | |
| `0x21` | `VEC_READ` | a scratchpad read of a vector job answered with an error | ERROR |
| `0x22` | `VEC_WRITE` | a scratchpad write of a vector job answered with an error | ERROR |
| `0x23` | `VEC_ENGINE` | the vector array reported the command illegal, or an element count ≠ `LENGTH` (resource failure) | ERROR |
| `0x30` | `TIMEOUT` | the unit made no progress for 2^`WDOG_LOG2` − 1 cycles. The unit is quarantined. | ERROR |
| `0x31` | `UNIT_DOWN` | the command needs a quarantined unit (resource failure) | ERROR |
| `0x40` | `PRIOR` | not executed: an older command failed and the queue is in stop-on-error mode | SKIPPED |

Error semantics, recovery and the stop / continue policies: docs/04.

## 9. Examples

```
DMA_LOAD   256 B  EXT 0x1000_0400 -> SPM 0x2000_1000, tid 7, IRQ:
  w0 = 0x07_01_01_01   (TID 07, FLAGS 01, RM 0, VER 1, OP 01)
  w1 = 0x1000_0400   w2 = 0   w3 = 0x2000_1000   w4 = 0x0000_0100   w5..w7 = 0

VECTOR_FMA 100 elements, RUP:  D(0x2000_0800) = A(0x2000_0000) * B(0x2000_0400) + D
  w0 = 0x03_00_31_12   (TID 03, FLAGS 00, RM 3 -> bits 14:12 = 011, VER 1, OP 12)
  w1 = 0x2000_0000   w2 = 0x2000_0400   w3 = 0x2000_0800   w4 = 100   w5..w7 = 0
```

C: `hpc_cq_desc_dma_load(&d, 7, 1u << HPC_CQ_FL_IRQ, 0x10000400, 0x20001000, 256);`
