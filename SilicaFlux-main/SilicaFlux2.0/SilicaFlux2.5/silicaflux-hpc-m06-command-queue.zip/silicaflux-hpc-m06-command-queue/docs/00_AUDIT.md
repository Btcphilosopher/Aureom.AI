# 00 — Repository audit

Brief §1: inspect the existing command processors, control registers, DMA descriptors, vector controllers and
software APIs, reuse their conventions, and do not invent a second, incompatible protocol.

## 1. What exists

| Area | Found | Verdict |
|---|---|---|
| **Command processor / queue** | None in SilicaFlux-HPC (Modules 01–04 cover the FP32 FMA, vector lane, vector array and scratchpad). `silicaflux-ai` (ML accelerator) has `rtl/command/README.md` and `rtl/scheduler/README.md` stubs: "not yet implemented". `silicaflux.zip` has a v0 `scheduler.sv`: a struct-based dataflow token scheduler for a different tile, outside the RTL subset. | **Nothing to stay compatible with.** A new protocol is needed, built from the conventions below. |
| **DMA** | DataFabric `silicaflux_dma` (`silicaflux-datafabric.zip`), verified:<br>• register-programmed (`SRC_ADDR` / `DST_ADDR` / `LENGTH` bytes, `CONTROL.START`);<br>• internal engine contract `start, cfg_src, cfg_dst, cfg_len → busy, done, fail, err_code, err_addr, bytes_done`;<br>• error codes 1–10; SFB2 master. | **Reused unmodified.** The scheduler drives `dma_transfer_engine` through exactly that internal contract, bypassing the register block (one DMA owner per tile). DMA lengths stay in bytes, alignment and tail rules stay identical, and engine codes are embedded as `0x10 \| code`. `dma_validate` doubles as a simulation cross-check. |
| **DMA descriptors** | DataFabric has none: one register-programmed transfer at a time. The descriptor fields (src, dst, length) are the template for DMA_LOAD / DMA_STORE. | The ABI uses the same three fields with the same units. |
| **Bus protocol** | SFB2 (DataFabric `PROTOCOL.md`), an extension of SilicaFlux-V SFB. `sfb_crossbar`, `sfb_protocol_checker`. | **Reused.** Crossbar in the tile; protocol checkers on every SFB2 port in the testbench. |
| **Vector controller** | Module 03 `hpc_vector_array`: streaming `cmd` (op, rm, vl, tid) / `opnd` / `res` / `cpl` interfaces, no memory port ("no VRF reader or DMA adapter is included"). SilicaFlux-V release 1 `VE` (integer, register-programmed, memory-to-memory on the TSPM). | **Reused unmodified.** Opcodes, rounding modes, flags and the beat layout come from Modules 02 / 03. The missing memory-to-memory adapter is the new `hpc_cq_vexec`. |
| **Scratchpad** | Module 04 `hpc_scratchpad`: ready/valid ports with tag, in-order per-port responses, `WRITE_ACK` after the array write. The integration doc states that lanes and the DataFabric DMA each take a port, and that the SFB2 port maps directly. | **Reused unmodified**, wired exactly as Module 04 doc 08 §1 prescribes. |
| **Control registers** | SilicaFlux-V register bus page convention (`rb_sel/rb_we/rb_addr[11:0]/rb_wdata → rb_rdata/rb_err`, combinational response, refused writes return `rb_err`). Accelerator conventions: `CTRL[0]` START; `STATUS` BUSY / DONE / ERR; illegal commands set ERR and are not executed. | **Reused.** `hpc_cq_mmio` is a register-bus page with the same bus contract as `dma_control_regs`: refused writes (doorbell when full, CPL_POP when empty, RO registers) answer `rb_err`. |
| **Memory map** | `memmap/silicaflux_v_datafabric.yaml`: SRAM `0x1000_0000`–`0x1001_FFFF`, TSPM `0x2000_0000`, peripheral pages 0–7 and 16–17 used. | Default windows EXT = SRAM banks 0–3, SPM = TSPM grown to 64 KiB (Module 04 recommendation). Proposed new entries: page 8 (`0x4000_8000`) for the queue, INTC source 9 (docs/05 §4). |
| **Software API** | DataFabric `firmware/drivers/silicaflux_dma.{c,h}`: bare metal, no libc. Return convention 0 / > 0 hardware code / < 0 driver error; `dma_check()` software pre-validation. | **Same style**: `sw/hpc_cq.{c,h}` with `hpc_cq_check()`. |
| **Coding rules** | SilicaFlux-V `RTL_CODING_RULES.md` and the M02/M03/M04 subset. | Followed (§2). |
| **Tool baseline** | Verilator 5.020, Icarus 12, Yosys 0.33 (Ubuntu 24.04 packages). | Same versions installed and used. |

## 2. Conventions followed

* **RTL subset.** Every new RTL file is accepted unchanged by Verilator 5.020, Icarus 12 and Yosys 0.33. It uses:
  * no `import`, no `return`, no `inside`;
  * no structs, unions or interfaces;
  * no unpacked-array ports;
  * functions that assign to their own name;
  * `default_nettype none`.
* **Reset.** Asynchronous active-low assert, synchronous release. Control state is reset; datapath registers
  qualified by valid state are not (SilicaFlux rule 4).
* **Simulation-only code** is enclosed in `` `ifndef SYNTHESIS ``.
* **Parameters.** Illegal parameter combinations fail elaboration through an undefined `hpc_param_error_*` module
  (the Module 03 idiom), checked by `scripts/lint.py`.
* **Names.** `clk_i` / `rst_ni`, `*_i` / `*_o` (Modules 02/03); `hpc_` prefix; ready/valid handshakes.
* **Registered-state-only interface outputs.** Proved structurally with Yosys, the Module 03 method.

## 3. Gaps found while integrating

These are recorded here, not fixed in the owning modules:

1. **Module 03 has no memory port.** `hpc_cq_vexec` supplies one. Throughput is bounded by one scratchpad port per
   lane (docs/07 §1).
2. **DataFabric DMA has no descriptor queue.** It is a single channel behind registers. The command queue provides
   the queue and drives the engine directly. The engine's register block is not instantiated in the tile.
3. **Module 04 doc 08 lists an "SFB2 port wrapper" as a next step.** The tile wires the SFB2 crossbar slave port
   directly to a scratchpad port, as that document describes. The DMA path is exercised against the real scratchpad
   under the DataFabric protocol checker, which partly closes that open item.
