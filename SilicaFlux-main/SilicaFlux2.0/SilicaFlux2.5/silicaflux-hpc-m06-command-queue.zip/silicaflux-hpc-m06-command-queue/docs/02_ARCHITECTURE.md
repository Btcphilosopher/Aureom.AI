# 02 — Architecture: queue, scheduler FSM, ordering

## 1. Block diagram

```
                     host (CPU via hpc_cq_mmio, or any ready/valid master)
                       | cmd: valid/ready, 256-bit descriptor        ^ cpl: valid/ready, 128-bit record
  hpc_command_queue    v                                             |
  +--------------------------------------------------------------------------------------------+
  |  command FIFO  (hpc_varray_fifo, Module 03, unmodified; QUEUE_DEPTH 4 | 8 | 16)             |
  |      | pop, in order                                                                       |
  |      v                                                                                     |
  |  hpc_cq_sched                                                                              |
  |    DEC  decode slot -- hpc_cq_validate (ABI rules, footprints)                             |
  |      |  resolve at decode: NOP FENCE RESET_COUNTERS / invalid / skipped / unit down ---+   |
  |      |  issue: DMA job -> DMA port         vector job -> vector port                   |   |
  |      |  unit state: active, ROB index, SEQ, byte footprint, watchdog, quarantine      |   |
  |      v                                                                                 v   |
  |    hpc_cq_rob  retirement buffer (ROB_DEPTH): alloc in order, complete in any order,      |
  |                commit in order, present the record, free on hand-over                      |
  |  hpc_cq_perf  17 saturating counters                                                       |
  +--------------------------------------------------------------------------------------------+
        | start / src / dst / len                 | start / op / rm / a / b / d / vl / tid
        v   done / fail / code / addr / bytes     v   done / fail / code / addr / flags / count
  dma_transfer_engine (DataFabric)           hpc_cq_vexec ---- cmd / opnd / res / cpl ----> hpc_vector_array (M03)
        | SFB2                                    | N lane ports
        v                                         v
  sfb_crossbar (DataFabric)  ---- s1 ---->   hpc_scratchpad (M04): ports 0..N-1 = lanes, port N = SFB2
    m0 host port   m1 DMA   s0 -> EXT port (external memory)
                                                         hpc_cq_tile = everything below the queue, wired
```

Every block below `hpc_command_queue` is a verified earlier deliverable reused **unmodified** (`third_party/`, SHA-256
in `third_party/SHA256SUMS`). Two are new:
* `hpc_cq_vexec` — the memory-to-memory adapter the Module 03 array lacked (its README lists "no VRF reader or DMA
  adapter is included");
* `hpc_cq_tile` — the wiring.

## 2. Command FIFO

* `hpc_varray_fifo` (Module 03), `W = 193`, `DEPTH = QUEUE_DEPTH` ∈ {4, 8, 16}. Any other depth fails elaboration.
* **Acceptance.** A command is accepted **only** at a rising edge with `cmd_valid_i && cmd_ready_o`.
  * `cmd_ready_o = !full` is a register output. When the FIFO is full it is 0, even if an entry leaves in the same
    cycle. A full queue therefore never accepts.
  * Nothing is overwritten or dropped (SVA `a_full_not_ready`, and the FIFO's own push-while-full `$fatal`).
* **Underflow.** The scheduler pops only when the FIFO is non-empty (the FIFO's pop-while-empty `$fatal`). No record
  can exist without an accepted command (SVA `a_cpl_needs_busy`, and the scoreboard's "unexpected record" check).
* `cmd_ready_o` is 0 during reset and in the first cycle after it.

## 3. Scheduler FSM

### 3.1 Life of a command

```
  ACCEPTED --pop--> DECODE --+-- resolve (complete at decode) ------------------+
   (FIFO)          (DEC slot)|                                                  v
                             +-- issue --> EXECUTING (DMA engine | vector) --> COMPLETE --commit--> COMMITTED --hand-over--> retired
                             +-- stall (stays in DECODE)                         (ROB)    (in order)   (record presented)
```

* **Decode slot.** One command; strictly in program order. A stalled command blocks every younger one: in-order issue,
  no reordering, no speculation.
* **Throughput.** The slot is reloaded in the cycle it is vacated. Commands that resolve at decode go through at one
  per cycle, as do commits and record hand-overs.

### 3.2 Decision table (every cycle the slot is full; first match wins)

| # | Condition | Outcome | Counter |
|---|---|---|---|
| 1 | ROB full | stall | `STALL_ROB` |
| 2 | sticky error and stop mode | resolve **SKIPPED** / `ERR_PRIOR` | |
| 3 | validation error | resolve **ERROR** / code; set sticky (stop mode) | |
| 4 | DMA / vector op whose unit is quarantined | resolve **ERROR** / `ERR_UNIT_DOWN`; set sticky | |
| 5 | sync needed and a job in flight | stall | `STALL_SYNC` |
| 6 | `NOP`, `FENCE` | resolve **OK** | |
| 7 | `RESET_COUNTERS` | resolve **OK**, clear the counters | |
| 8 | DMA op, DMA engine busy | stall | `STALL_UNIT` |
| 9 | DMA op, conflicts with the running vector job | stall | `STALL_HAZARD` |
| 10 | DMA op otherwise | **issue** on the DMA engine | `DMA_ISSUE` |
| 11–13 | vector op: same as 8–10 against the DMA job | stall / stall / **issue** | `VEC_ISSUE` |

*Sync needed* means any of:
* `FENCE` or `RESET_COUNTERS`;
* `FL_BARRIER` set;
* `OVERLAP_EN = 0` and the command is a DMA / vector op.

`RESET_COUNTERS` additionally waits until every older command has committed (docs/03 §4).

Every outcome other than a stall allocates **one** ROB entry, in program order:
* allocated complete, for "resolve";
* allocated pending, for "issue".

### 3.3 Unit contract

Both execution ports use the control interface of DataFabric `dma_transfer_engine`, unchanged.
`hpc_cq_vexec` implements the same contract.

* `start` is a one-cycle **registered** pulse. It is raised only while the queue holds no job for that unit. The
  unit samples it while idle (asserted: `start → !busy`).
* `done` / `fail` are one-cycle pulses. The unit is idle in the next cycle.
* Code, address, count and flags are valid with the pulse.
* Unit state in the scheduler (per unit):
  * `active`;
  * the ROB index and `SEQ` of the job;
  * its byte footprint;
  * a no-progress watchdog counter;
  * a `dead` (quarantined) bit.

### 3.4 Memory dependencies (step 6 of the brief)

Each unit runs **one job at a time**, and a job completes only after **all of its writes are acknowledged**:
* DMA: `done` follows the last write response (SFB2 R7);
* vector: the executor waits for every scratchpad write acknowledgement (Module 04, `WRITE_ACK = 1`).

Hence:
* two jobs on the same unit are ordered;
* a completed job can never conflict with anything later.

The only possible concurrency is **one DMA job with one vector job**. It is allowed only if their byte footprints
have no conflict:

| | reads | writes |
|---|---|---|
| DMA job | `[SRC_A, SRC_A + roundup4(LENGTH))` (the engine reads whole words) | `[DST, DST + LENGTH)` |
| vector job | A range, B range (and, for FMA, D range) | D range |

* **Test for a DMA command against the running vector job** (four interval intersections):
  * RAW: DMA read vs vector write;
  * WAR: DMA write vs vector reads A and B;
  * WAW: DMA write vs vector write (this also covers FMA's read of D).
* **Test for a vector command against the running DMA job** (four intersections):
  * RAW: vector reads A, B vs DMA write;
  * WAR: vector write vs DMA read;
  * WAW: vector write vs DMA write.
* Intervals are 33-bit half-open byte ranges. "Adjacent" never counts as a conflict.

**Consequence (architectural contract).** The final memory state and every completion record equal those of
executing the commands **one at a time in program order**. This is exactly what the reference model computes and the
regression checks.

### 3.5 Retirement (`hpc_cq_rob`)

* **Allocation.** At the tail, in order. Completion: an update port per unit writes status, code, count, address and
  flags into the job's entry.
* **Commit pointer.** Advances over the oldest uncommitted entry once it is complete, at most one per cycle, strictly
  in order. Commit is the architectural completion point:
  * `ev_commit_o`, `ev_commit_err_o` and `ev_commit_irq_o` pulse here;
  * the counters count here.
* **Presentation.** Committed entries are presented oldest first on `cpl_*`. `cpl_rec_o` is held stable while
  `cpl_valid_o && !cpl_ready_i`, and is 0 while not valid.
* **Back-pressure.** A host that does not take records fills the ROB, which stalls the decode slot (`STALL_ROB`),
  which fills the FIFO, which drops `cmd_ready_o`. Nothing is lost at any stage.
* **Depth.** `ROB_DEPTH` (2…64, default 8) bounds commands between decode and hand-over. Two entries are enough for
  correctness. More let the queue keep running while the host is slow to take records.

### 3.6 Interface timing

`cmd_ready_o`, `cpl_valid_o`, `cpl_rec_o`, every unit-port output, every status output, the commit events and
`perf_cnt_o` are functions of **registered state only**. This is proved structurally by `syn/run_synth.sh`: the cone of
every such output, cut at flip-flops, contains no input, at QUEUE_DEPTH 4, 8 and 16, with a positive control. The
`trc_*` observability outputs are combinational from decode state and are meant for monitors only.

| Event | Cycle (accept edge = t, no stalls, host always ready) |
|---|---|
| command enters the decode slot | t + 1 |
| resolved at decode (NOP / FENCE / invalid) and allocated | t + 2 |
| committed | t + 3 |
| record presented / handed over | t + 4 |
| DMA / vector `start` pulse | t + 3 (issued at t + 2) |

Steady state is one command per cycle for decode-resolved commands (`reports/perf.md`).

## 4. Vector executor (`hpc_cq_vexec`)

Turns one vector job into Module 03 array traffic and Module 04 scratchpad accesses. Lane *l* owns elements
*e ≡ l (mod N)*, the Module 03 beat layout, and uses scratchpad port *l*.

1. **Command.** The array command (`FADD` / `FMUL` / `FMADD`, `rm`, `vl`, `tid`) is presented at job start.
2. **Operand reads.** Per lane: A[e], B[e] (and D[e] for FMA), in order, through the lane's port, each tagged with its
   phase. Reads of an element start only against a reserved operand-queue slot, so the response path never stalls
   (`rsp_ready = 1`).
3. **Beats.** A beat is handed to the array when every lane active in it has its operands. Tail lanes are inactive and
   carry zeros (Module 03 ignores them).
4. **Write-back.** Result beats go to per-lane write-back queues, taken only when every queue has room. Writes have
   priority over reads on a port.
5. **Genuine completion.** `done` requires all of:
   * every beat handed over;
   * every result beat taken;
   * the array's completion record taken (Module 03 presents it only after the last result beat);
   * every destination write acknowledged.

   The array's record is checked too: not illegal, count = `vl`. Otherwise the job fails `VEC_ENGINE`.

Ordering inside a job:
* element *e* is read and written only through port *e mod N*, whose responses are in order (Module 04);
* each element's reads precede its write;
* different elements touch different words.

So `D = A` or `D = B` (in place) is exact. Partial overlap never reaches the executor (`ERR_OVERLAP`).

**Throughput.** Per lane, an element costs 3 port transactions (ADD / MUL) or 4 (FMA). The executor uses one port per
lane and issues at most one transaction per port per cycle, so it is bound by scratchpad port bandwidth, not by the
array (`reports/perf.md`).

## 5. Tile integration (`hpc_cq_tile`)

* **Crossbar.** DataFabric `sfb_crossbar`, 2 masters × 2 slaves:
  * masters: host, DMA;
  * slaves: EXT window → `ext_*` port, SPM window → scratchpad port N (Module 04 doc 08 §1);
  * `SLV_MASK` from `EXT_LOG2` / `SPM_LOG2`; round robin; alignment check on.
* **Scratchpad.** `NUM_PORTS = N + 1`, `WRITE_ACK = 1`, `QUEUE_DEPTH = 0`, `BYTE_WE = 1` (the DMA tail strobe), LOW map,
  4 banks by default.
* **Vector array.** The lean build: `EN_FCMP = 0`, `EN_INT = 0`, `RED_EN = 0`, `PERF_EN = 0`, since only FADD / FMUL /
  FMADD are used. `lane_hold_i` is brought out for stress testing.
* **`SPM_PHYS_LOG2 < SPM_LOG2`** is a fault-injection configuration: the queue validates against a larger window than
  the scratchpad implements, so scratchpad RANGE errors reach the DMA and vector error paths end to end.
* **Clock and reset.** One clock; one asynchronous active-low reset shared by every block. Reset discards everything
  in flight and produces no record for any command accepted before it (docs/04 §5).
