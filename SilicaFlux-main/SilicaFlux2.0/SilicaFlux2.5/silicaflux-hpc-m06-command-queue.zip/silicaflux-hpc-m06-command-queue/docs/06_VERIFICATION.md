# 06 — Verification

## 1. Staged bring-up (as the brief requires)

1. **Stage 1 — bring-up subset.**
   * Configuration: `OPSET_FULL = 0`, so only `NOP`, `DMA_LOAD`, `VECTOR_ADD` and `FENCE` are implemented. Every other
     v1 opcode must be rejected with `ERR_OPCODE`, and is tested for it.
   * Coverage: 9 recipes × QUEUE_DEPTH 4 / 8 / 16 × overlap on / off × 3 timing profiles.
   * Requirement: end-to-end ordering correct, i.e. every record and every memory word matches the sequential
     reference.
2. **Stage 2 — full v1 set.** Only after stage 1 was green:
   * `DMA_STORE`, `VECTOR_MUL`, `VECTOR_FMA`, `RESET_COUNTERS`;
   * the full error matrix, external-memory and scratchpad bus faults, both watchdogs, and reset during activity;
   * eight queue / ROB / lane / overlap configurations and four timing profiles;
   * scratchpad read latency 2;
   * the vector executor's flow control at minimum queue depths: operand / write-back queues of 1–2 entries, also
     with 4 lanes. This is the only way to drive the write-back queue full, because results arrive at most every
     2 cycles per lane while writes drain at 1 per cycle.
3. **Cross-checks.**
   * Icarus 4-state simulation;
   * MMIO directed test;
   * the C host example on the RTL;
   * performance runs (self-checking too);
   * mutation testing.

`scripts/run_all.sh` runs everything on the frozen RTL. Results: §8 and `reports/`.

## 2. Method

```
 ref/gen_prog.py  recipe + seed --> command program --> ref/hpc_cq_model.py (sequential reference)
                                          |                       | expected records (+ masks, alternatives),
                                          v                       v expected final memory (+ care bits), sync checks
 tb/tb_hpc_command_queue.sv:  driver --> hpc_cq_tile --> records --> in-order SCOREBOARD
                              (gaps,         |  |                  monitors: issue order, FENCE / BARRIER,
                               syncs,        |  +-- ext port --> tb_ext_mem (latency, back-pressure, error / hang injection)
                               clear,        +----- host port <-- init / checks / random scratch traffic
                               mode)         lane holds, completion back-pressure
                              sfb_protocol_checker x 3 (DataFabric) + hpc_cq_sva (bind) + RTL checks
```

### 2.1 Reference model (`ref/hpc_cq_model.py`)

Written independently of the RTL, in a different style: a straight-line interpreter of the ABI document.

* **Validation.** The ten rules in ABI order.
* **DMA.** Beat-level, exactly as DataFabric documents its engine: read word *i*, write word *i* with the tail strobe,
  and stop at the first failing beat, giving `COUNT` = bytes of the completed beats and `ERR_ADDR` = the failing
  address.
* **Vector ops.** Element by element through the Module 02 exact-arithmetic FP32 reference (`fp32_ref.py`, reused
  unmodified, cross-validated there against SoftFloat and the host FPU), all five rounding modes, flags ORed.
* **Policies.** Stop / continue; quarantine after a timeout.
* **One at a time.** Every command runs to completion before the next. This is the architectural contract the
  hardware must meet despite overlap.

The C driver's `hpc_cq_check()` is a third implementation of the validation rules. The co-simulation compares its
prediction with the hardware's record.

### 2.2 Exactness, and where timing legitimately matters

Records are compared field by field with a mask. All records are exact except these cases:

| Case | What is relaxed | Why |
|---|---|---|
| vector job with a scratchpad error | `COUNT`, `ERR_ADDR`, `FFLAGS`; and the code (READ or WRITE) when a source faults. The destination word of every element whose operand read failed **must keep its old value** (checked exactly); the other destination words are undefined. | which lane's access fails first depends on arbitration; with only the destination faulting the code is checked exactly (`VEC_WRITE`) |
| vector watchdog timeout | `COUNT`, `FFLAGS` | the stall point depends on lane holds |
| stop mode, a command younger than an **execution** error that is independent of the failing job and on the other unit | either its executed record or `SKIPPED`, **monotonically**: once one is SKIPPED, all later ones must be | it may legitimately have been issued before the error was detected (docs/04 §2) |
| memory written by such a command, or by a failed vector job | that word is "undefined" (not compared); anything computed from it is undefined too | |

Everything else is exact, including:
* every validation code;
* every DMA bus error with its exact `COUNT` prefix and `ERR_ADDR`;
* every skipped command;
* `SEQ`, `TID` and the IRQ echo;
* FP results and flags bit-exact.

### 2.3 Checks, independent of the RTL

| Check | Where |
|---|---|
| every record matches its expectation (or a permitted alternative), in order; nothing extra, nothing missing | scoreboard |
| a masked error code is still an execution-error code | scoreboard |
| decode releases SEQ 0, 1, 2, … (in-order issue) | trace monitor + SVA |
| FENCE, RESET_COUNTERS, FL_BARRIER and (with `OVERLAP_EN = 0`) every DMA / vector op leave decode only with no older job in flight | trace monitor |
| a DMA job and a vector job in flight together never conflict (RAW / WAR / WAW on byte footprints recomputed by the TB) | hazard monitor |
| with `OVERLAP_EN = 0`, never two jobs in flight | hazard monitor + RTL check |
| at host sync points, memory written by older commands is visible through the host port | sync checks |
| final external memory, every defined word; final scratchpad, every defined word of the used regions (via the host port) | end of test |
| host-port scratch area traffic is unharmed by concurrent commands | end of test |
| commit IRQ / error events = records with IRQ / ERROR or SKIPPED | end of test |
| counters `CMD_IN`, `CMD_COMMIT`, `CMD_ERR`, `CMD_SKIP`, `DMA_ISSUE`, `VEC_ISSUE` equal the TB's own counts since the last RESET_COUNTERS; `OVERLAP` equals the TB-observed overlap; no counter exceeds `CYCLES` | end of test |
| queue idle at the end (`busy`, FIFO, ROB, no record pending) | end of test |
| SFB2 rules R2 / R4 / R5 / R6 / R8 on the external, host and DMA ports | DataFabric `sfb_protocol_checker` ×3 |

### 2.4 Assertions

* **Concurrent SVA** (`tb/hpc_cq_sva.sv`, bound to every `hpc_command_queue`, Verilator `--assert`):
  * full ⇒ not ready;
  * a held record is stable; no record while invalid; no record without busy;
  * start pulses are single-cycle and only on a free unit;
  * each job completes once, never both done and fail;
  * in-order issue; in-order retirement starting at SEQ 0;
  * covers: overlap, queue full, record back-pressure.
* **RTL simulation checks** (`` `ifndef SYNTHESIS ``):
  * every issued DMA job passes DataFabric's own `dma_validate`;
  * the engine never reports a start-time code;
  * no start while busy; no completion without a job;
  * dependent jobs never in flight together;
  * ROB: alloc while full, double update, update of an allocating entry;
  * executor: response outside a job, tag / phase mismatch, operand-queue overflow, wrong `last`, second completion
    record;
  * queue: record stability / zero-when-invalid, accept-while-full.
* **Reused**:
  * FIFO push-full / pop-empty `$fatal`;
  * Module 04 `HPC_SPM_ASSERT` and SRAM-library `SRAMLIB_ASSERT`;
  * Module 03's internal lane-legality assertion.

## 3. Recipes (`ref/gen_prog.py`)

| Recipe | Content | Brief §8 items |
|---|---|---|
| `smoke` | the four bring-up opcodes in sequence, FENCE with IRQ, sync check | back-to-back, FENCE |
| `rand` | 120 random commands over 16 hot buffers: frequent dependencies, random lengths and tails, IRQ / BARRIER flags, FENCEs with sync checks (stage 2: all opcodes, RESET_COUNTERS) | mixed DMA / compute, dependency handling, completion ordering |
| `b2b` | 200 control commands with no gaps, reserved opcodes with clears | back-to-back, overflow / underflow (with profile `bp`) |
| `deps` | directed RAW / WAR / WAW between DMA and vector jobs with one-word overlaps, 6-byte tail strobes, adjacent-but-disjoint ranges that must overlap, the rounded-up DMA read footprint | dependency handling |
| `dbuf` | double-buffered pipeline: load tile k+1 while computing tile k, then store | mixed DMA / compute, overlap |
| `errors` | every validation rule for every opcode (≈ 60 malformed descriptors), in continue mode, then stop mode with skips and clears | invalid commands, error propagation |
| `fp` | vector ops with all five rounding modes on special-heavy operands (NaN, sNaN, ±inf, subnormals, ±0, max) | (data path through the queue) |
| `long` | vectors of 512–680 elements, multi-KiB DMAs | |
| `dma_fault` | external-memory error window: READ_BUS on loads, WRITE_BUS on stores, exact prefix and address; continue mode, then stop mode with independent overlap | DMA error, error propagation |
| `spm_fault` | window larger than the physical scratchpad: DMA WRITE_BUS / READ_BUS, vector READ and WRITE errors | resource failure, error propagation |
| `timeout_dma` / `timeout_vec` | a slave that never answers / lanes held forever: TIMEOUT, then UNIT_DOWN, the other unit still works; stop and continue modes | resource failure |
| `rstcnt` | RESET_COUNTERS mid-stream; counters checked exactly | |
| `rand` + `RESET_AT` | reset 0–300 cycles after command 3 / 20 / 60 of a busy program, no stale record, then a fresh program | reset during activity |

**Timing profiles.**

| Profile | Command gaps | Record ready | External memory ready / latency | Lane holds | Host traffic |
|---|---|---|---|---|---|
| `fast` | 0 | 100 % | 100 % / 1 | 0 | off |
| `rand` | 30 % | 60 % | 70 % / 1–4 | 5 % | on |
| `bp` | 0 | **10 %** | 40 % / 1–8 | 0 | off |
| `slow` | 50 % | 90 % | 30 % / 2–12 | 20 % | on |

`bp` is the queue-full / back-pressure profile. The host can barely keep up with records, so the ROB and the FIFO run
full and the command port is refused most of the time.

## 4. Results (final pass; `reports/SUMMARY.md`)

| Campaign | Result |
|---|---|
| Stage 1 — bring-up subset (`OPSET_FULL = 0`), QUEUE_DEPTH 4 / 8 / 16 × overlap on / off × profiles fast / rand / bp × 9 recipes | **162 / 162** runs, 11,484 commands, 42,707 DMA/vector overlap cycles |
| Stage 2 — full v1 set: 8 queue / ROB / lane / overlap configurations × 4 profiles × 10 recipes, plus scratchpad faults, watchdogs (both units, both modes), reset during activity, read latency 2, minimum-depth executor queues | **460 / 460** runs, 34,782 commands, 284,899 overlap cycles; 20 stop-mode records took the permitted SKIPPED alternative |
| Icarus 12, 4-state: every stage-2 recipe, faults, watchdogs, reset, stage-1 subset | **32 / 32** runs, 2,264 commands |
| MMIO adapter directed test | **PASS** (`reports/mmio.log`) |
| C host example on the RTL | **PASS** (`reports/cosim.log`) |
| Performance programs (self-checking) | **19 / 19** (`reports/perf.md`) |
| Pipeline timing probe | decode release t+2, unit start t+3, record t+4; 64 commands in 64 cycles (`reports/latency.txt`) |
| Mutation testing | **36 / 37** injected bugs detected; **1 proven equivalent**; 0 undetected (`reports/mutation.md`) |
| Stimulus coverage | 59 distinct programs, 4,813 commands: every opcode × {OK, ERROR, SKIPPED}; every validation code; DMA read / write errors; vector read / write errors; TIMEOUT; UNIT_DOWN; PRIOR; every flag on every opcode; 5 rounding modes × 3 vector ops; all 4 DMA tail residues in both directions; in-place and aliased vector operands (`reports/coverage.md`) |
| Static | ABI 117 / 117; Verilator `-Wall` 0 warnings in new RTL over 7 parameter sets; Icarus clean; 13 / 13 invalid parameter combinations rejected (`reports/lint.md`); Yosys: no latches, `check -assert`, structural proof 0 / 0 / 0 at QUEUE_DEPTH 4 / 8 / 16 (`reports/synth/`) |

## 5. Mutation testing

Each of 37 mutants is one deliberate bug in the new RTL:
* scheduler dependency, FENCE, BARRIER, sticky-error, unit-busy, watchdog, quarantine and counter logic;
* ROB commit / record selection;
* every class of validation rule;
* FIFO overflow protection;
* executor completion, flow control, FP operand routing, rounding mode, tail masking and error handling;
* the MMIO adapter.

Quick regression runs are tried until one fails. **36 are detected.** The first pass detected 33, and the four
survivors were each resolved on its merits rather than by tuning the test to the mutant:

| Mutant | First pass | Resolution |
|---|---|---|
| M17 executor reports done before writes are acknowledged | survived | With scratchpad `READ_LATENCY = 1` the acknowledgement arrives in the very cycle the mutant reports done, so no difference is observable there. Added `READ_LATENCY = 2` runs: killed (the executor sees a response outside a job). |
| M29 results accepted without write-back space | survived | **Coverage hole**: no test ever filled a write-back queue. Results arrive at most every 2 cycles per lane while writes drain at 1 per cycle, so the gate only matters under port contention. Added minimum-depth (1-entry) queue configurations with 4 lanes to stage 2: killed. |
| M31 results written after a read error | survived | **Specification hole**: the model called the whole destination of a failed vector job undefined. The spec now states the deterministic rule the RTL already obeys: a result computed from a failed read is never written (docs/04 §1). Killed. |
| M25 DMA read footprint not rounded up | survived | **Proven equivalent.** Vector footprints are word-aligned, so any vector range touching the DMA's partially used last source word also intersects the un-rounded range. The extra bytes are read but never written. The round-up is kept as a defensive bound. |

Two further holes were found by inspecting coverage, not by mutation:
* the vector **write**-error path was not exercised (recipe added);
* `ERR_VEC_ENGINE` cannot be exercised without modifying the reused array. It is stated as an untested guard.

## 6. What verification found during development

No functional RTL defect was found by the regression after the first bring-up run. Every failure seen during the
campaigns was in the verification environment, and each is fixed:

| Found | Kind | Fix |
|---|---|---|
| host-port / command-port handshakes sampled after the clock edge (race with the DUT's flip-flops) | testbench | drive 1 ns after a rising edge, sample at the falling edge |
| counter expectation after RESET_COUNTERS excluded the command's own commit | testbench | expectation corrected (the RTL behaviour is the documented one) |
| host scratch area overlapped the scratchpad-fault boundary; a perf destination ran into the scratch area | generator | scratch area placed above the arena, perf arenas sized; both caught by the TB's scratch-area integrity check |
| scoreboard disabled before reset was actually asserted (a legitimate record arrived in between) | testbench | checking continues until the reset edge |
| uninitialised scratchpad words assumed to be 0 | model | found by Icarus (4-state: uninitialised SRAM is X); such words are now undefined |
| concurrent rebuilds and program generation by parallel jobs | scripts | build lock, per-program lock, atomic file writes |

Design refinements made while defining the checks (before any test failed):
* RESET_COUNTERS waits for older commits, so the counter clear point is exact.
* Package function calls are hoisted into wires for Icarus 12.
