# 04 — Error handling

## 1. Detection

Every error has a code, a detection point and a defined effect on memory. A malformed command is never executed.

| Brief §6 item | Detected | Code(s) | When | Memory effect |
|---|---|---|---|---|
| Invalid opcode | reserved code point, or outside `OPSET_FULL` | `0x02 OPCODE` | decode, before issue | none |
| Unsupported flags | reserved flag bit | `0x03 FLAGS` | decode | none |
| Malformed descriptor | wrong `VERSION`; reserved bit / word / unused field ≠ 0; `STRIDE ≠ 0`; `RM` 5–7 | `0x01`, `0x04`, `0x05`, `0x06` | decode | none |
| Invalid length | `LENGTH = 0` or above the maximum | `0x07 LENGTH` | decode | none |
| Misalignment | an address not 4-byte aligned | `0x08 ALIGN` | decode | none |
| Address out of range | a range outside its window, or wrapping | `0x09 RANGE` | decode | none |
| Unsafe aliasing | vector destination partially overlaps a source | `0x0A OVERLAP` | decode | none |
| DMA error | SFB2 error response on a source read / destination write | `0x18 DMA_READ` / `0x19 DMA_WRITE`, `ERR_ADDR` = failing address | execution | destination: the first `COUNT` bytes are written; the rest is untouched (the engine stops at the failing beat; an errored write has no effect) |
| Vector memory error | scratchpad error response on a read / write of a vector job | `0x21 VEC_READ` / `0x22 VEC_WRITE`, `ERR_ADDR` = first failing address seen | execution | a result computed from an operand whose read **failed is never written** (that destination word keeps its old value); other destination words are undefined (partially written); `COUNT` = elements acknowledged |
| Resource failure: engine inconsistency | the vector array reports the command illegal, or a count ≠ `LENGTH` | `0x23 VEC_ENGINE` | execution | destination undefined |
| Resource failure: hung unit | no bus / stream handshake for 2^`WDOG_LOG2` − 1 cycles | `0x30 TIMEOUT` | execution (watchdog) | job's destination undefined; unit quarantined |
| Resource failure: unit unavailable | command needs a quarantined unit | `0x31 UNIT_DOWN` | decode | none |

Notes:
* **Validation precedence** is fixed (docs/01 §6).
* **Duplicate checks.** The DataFabric engine's own start-time checks (codes `0x11`–`0x17`) can never fire: the
  queue's checks are a strict superset. This is asserted in simulation with the engine's own `dma_validate`.
* **Region legality.** As in DataFabric, the DMA engine does not know which regions exist. The queue's window checks
  catch out-of-window addresses at decode. Anything inside a window that a slave still refuses (an unmapped hole, a
  poisoned word, a smaller physical scratchpad) comes back as a bus error during execution.
* **Watchdog.** "Progress" means any handshake on the unit's ports. A slow slave is therefore not a failure; only a
  silent one is. `WDOG_LOG2 = 0` disables the watchdog, which is DataFabric's choice for its own engine. A DMA
  timeout also pulses `abort` to the engine, which stops at the next beat boundary if the slave ever answers.

## 2. Policies (`ctrl_err_cont_i`, MMIO `CTRL.ERR_CONT`)

**Stop on error (0, default).**
1. The first ERROR record sets the sticky bit (`err_sticky_o`, `STATUS.ERR_STICKY`).
2. Every command that has not left the decode slot yet then completes **SKIPPED** with `ERR_PRIOR`. It still gets its
   own record: one per command, in order. Nothing is executed.
3. This lasts until `ctrl_err_clear_i` (MMIO `CTRL.ERR_CLEAR`). If a new error and a clear happen in the same cycle,
   the error wins.

Precision of stop mode:

* **Validation and UNIT_DOWN errors are precise.** They are detected at decode, in order, before anything younger has
  issued. Every younger command is skipped.
* **Execution errors** (DMA, vector, TIMEOUT) are detected when the job ends. A younger command may already be running
  on the other unit, but only if it was **independent** of the failing job: no RAW / WAR / WAW with its footprint
  (docs/02 §3.4). Such a command finishes normally and reports OK. Its result is correct, because it never touched
  what the failing job wrote. Everything not yet issued is skipped.
* Which independent younger commands were in flight is a matter of timing. The record says exactly what happened, per
  command, and the reference model accepts either outcome (docs/06 §2.3).
* For a deterministic cut, put `FL_BARRIER` (or a FENCE) after a command whose failure must stop everything behind it.

**Continue (1).** Every command is validated and executed independently; errors are reported only in their own record.
Software must then not consume a failed command's destination.

## 3. Recovery

| Situation | Recovery |
|---|---|
| ERROR / SKIPPED records (stop mode) | read the records, fix the cause, `CTRL.ERR_CLEAR`, resubmit the skipped commands |
| `TIMEOUT` | The unit is quarantined: later commands for it complete with `UNIT_DOWN`, and its late `done` / `fail` pulses are ignored. The other unit keeps working. The unit's state and the timed-out job's destination are undefined. The only full recovery is a **reset** of the tile. |
| Queue full / records not drained | not an error: back-pressure, nothing lost (docs/02 §3.5) |

## 4. Error propagation to the host

| Channel | Content |
|---|---|
| Completion record | `STATUS`, `ERR_CODE`, `ERR_ADDR`, `COUNT` (bytes / elements actually completed), `FFLAGS` |
| Commit event | `ev_commit_err_o` for every ERROR or SKIPPED commit → MMIO `INT_STATUS.ERR` → `irq_o` when enabled |
| Status | `err_sticky_o`, `dma_down_o`, `vec_down_o` (MMIO `STATUS`) |
| Counters | `CMD_ERR`, `CMD_SKIP` |

FP exception flags are not errors. They are reported in `FFLAGS` with `STATUS = OK` (RISC-V `fflags` model: OR them in
completion order).

## 5. Reset during activity

`rst_ni` (asynchronous assert, synchronous release) discards all of the following, and **no record is ever produced
for a command accepted before the reset**:
* queued commands;
* the decode slot;
* jobs in flight;
* committed records not yet taken.

Verified by the `reset` runs (docs/06): reset at a random point of a busy program, then 200 quiet cycles, then a new
program with `SEQ` restarting at 0.

Memory state after a reset:
* Writes already performed stay.
* An SFB2 write in flight may or may not have been performed (DataFabric R11).
* Scratchpad writes still queued are dropped (Module 04).
* Software must therefore treat the destinations of commands in flight at the reset as undefined.

The external-memory slave and every other block share the same reset.
