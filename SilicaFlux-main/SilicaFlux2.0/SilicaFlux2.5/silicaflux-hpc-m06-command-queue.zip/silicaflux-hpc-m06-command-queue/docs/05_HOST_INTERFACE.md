# 05 — Host interface

The brief allows a ready/valid stream, a memory-mapped register interface, or both "if one is an adapter to the
other". Here:

* **The native interface is the stream.** `hpc_command_queue` exposes `cmd` (256-bit descriptor) and `cpl` (128-bit
  record), both valid/ready, plus control inputs.
* **The register interface is an adapter onto it.** `hpc_cq_mmio` is a SilicaFlux-V register-bus page that turns a
  doorbell write into exactly one `cmd` handshake and a `CPL_POP` write into exactly one `cpl` handshake. It adds no
  queueing and no semantics of its own.

## 1. Stream interface (`hpc_command_queue`, `hpc_cq_tile`)

| Port | Dir | Width | Description |
|---|---|---|---|
| `cmd_valid_i` / `cmd_ready_o` | in / out | 1 | Accepted at a rising edge with both high. `cmd_ready_o` is registered (`!FIFO full`); 0 in reset and the cycle after. |
| `cmd_desc_i` | in | 256 | Descriptor, sampled at the handshake (docs/01 §2) |
| `cpl_valid_o` / `cpl_ready_i` | out / in | 1 | One record per command, in order. Held stable until taken. |
| `cpl_rec_o` | out | 128 | Completion record (docs/01 §7); 0 while not valid |
| `ctrl_err_cont_i` | in | 1 | 0 stop-on-error, 1 continue (docs/04 §2); level, may change at any time |
| `ctrl_err_clear_i` | in | 1 | pulse: clear the sticky error |
| `ctrl_perf_clear_i` | in | 1 | pulse: clear the counters |
| `busy_o`, `q_count_o`, `q_full_o`, `q_empty_o`, `rob_count_o`, `err_sticky_o`, `dma_down_o`, `vec_down_o` | out | | status, registered |
| `ev_commit_o`, `ev_commit_err_o`, `ev_commit_irq_o` | out | 1 | one-cycle commit events (any / ERROR or SKIPPED / FL_IRQ) |
| `perf_cnt_o` | out | 17 × `PERF_CW` | counters, map `hpc_cq_pkg::PC_*` |

Producer rules:
* `cmd_valid_i` may depend on anything; `cmd_ready_o` never depends on `cmd_valid_i`.
* A consumer may hold `cpl_ready_i` low indefinitely. The queue then stops accepting once the retirement buffer and
  the FIFO are full. Nothing is lost.

## 2. Register interface (`hpc_cq_mmio`)

Bus contract: the one of DataFabric `dma_control_regs`.
* One-cycle `rb_sel` strobe with `rb_we`, `rb_addr[11:0]`, `rb_wdata`.
* `rb_rdata` / `rb_err` answered combinationally in the strobe cycle.
* Side effects happen at the end of the strobe cycle.
* `rb_err = 1` means the access was refused and had **no effect** (a CPU store or load access fault).

| Offset | Register | Access | Fields |
|---|---|---|---|
| `0x000` | `ID` | RO | `0x5346_4351` ("SFCQ") |
| `0x004` | `INFO` | RO | `[3:0]` ABI version, `[15:8]` QUEUE_DEPTH, `[23:16]` ROB_DEPTH, `[24]` OPSET_FULL, `[25]` OVERLAP_EN, `[26]` PERF_EN |
| `0x008` | `CTRL` | RW | `[0]` ERR_CONT; `[1]` ERR_CLEAR (write 1, reads 0); `[2]` PERF_CLEAR (write 1, reads 0) |
| `0x00C` | `STATUS` | RO | `[0]` BUSY `[1]` ERR_STICKY `[2]` Q_FULL `[3]` Q_EMPTY `[4]` CPL_VALID `[5]` DMA_DOWN `[6]` VEC_DOWN `[15:8]` Q_COUNT `[23:16]` ROB_COUNT `[31:24]` Q_FREE |
| `0x010` | `INT_ENABLE` | RW | `[0]` IRQ (an `FL_IRQ` command committed), `[1]` ERR (an ERROR / SKIPPED command committed) |
| `0x014` | `INT_STATUS` | W1C | same bits. Set by the commit event; the set wins over a same-cycle clear. `irq_o = \|(INT_STATUS & INT_ENABLE)`, level. |
| `0x018` | `SUBMITTED` | RO | accepted doorbells since reset (= `SEQ` of the next command when this adapter is the only submitter) |
| `0x020`–`0x03C` | `DESC0`–`DESC7` | RW | descriptor staging words 0–7, kept after a doorbell |
| `0x040` | `DOORBELL` | WO | submit the staged descriptor: exactly one command. **Refused** (`rb_err`) while the queue is full. |
| `0x050`–`0x05C` | `CPL0`–`CPL3` | RO | head completion record (0 if none) |
| `0x060` | `CPL_POP` | WO | release the head record. **Refused** if there is none. |
| `0x080` + 4·*i* | `PERF[i]` | RO | counter *i* (low 32 bits), *i* < 17 |

Rules:
* Writes to RO registers, any access to an unmapped or misaligned offset, and reads of nothing all answer `rb_err` and
  have no effect.
* Reads have no side effects. `DOORBELL` and `CPL_POP` read as 0.
* Every rule in this section is checked by `tb/tb_hpc_cq_mmio.sv`.

### Programming sequence

1. `ID` and `INFO.ABI` check; `INT_ENABLE = 0`; clear `INT_STATUS`; `CTRL = 0` (stop on error).
2. Submit: if `STATUS.Q_FREE` > 0, write `DESC0`–`DESC7`, then `DOORBELL`. The doorbell is the only write with a
   queue side effect: either exactly one command is accepted or nothing happens. That makes a refused doorbell safe
   to retry.
3. Complete: poll `STATUS.CPL_VALID`, or take the interrupt. Read `CPL0`–`CPL3`, then write `CPL_POP`. Records come in
   submission order.
4. On an ERROR record (stop mode):
   1. drain the SKIPPED records;
   2. fix the cause;
   3. write `CTRL.ERR_CLEAR`;
   4. resubmit.

Cost per command over the register bus: 9 writes (8 descriptor words + doorbell) and 5 accesses per record. A
hardware master, such as a future descriptor-ring fetcher, uses the stream port directly at one command per cycle.

## 3. Host driver and example

`sw/hpc_cq.{h,c}` is a bare-metal driver with no libc, in the style of the DataFabric DMA driver. It returns 0,
a hardware code (> 0), or a driver error (< 0).

| Function | Purpose |
|---|---|
| `hpc_cq_desc_nop / _fence / _reset_counters / _dma_load / _dma_store / _vector` | build descriptors, all reserved fields 0 |
| `hpc_cq_check(d)` | the hardware's validation rules in the same order. Returns the code the hardware would report. |
| `hpc_cq_init()` | ID + ABI version check, stop mode, interrupts off |
| `hpc_cq_submit(d)` | `HPC_CQ_EBUSY` when there is no free slot; never rings a full queue |
| `hpc_cq_poll(c)` / `hpc_cq_wait(c, n)` | take one record |
| `hpc_cq_set_continue_on_error`, `hpc_cq_clear_error`, `hpc_cq_clear_counters`, `hpc_cq_counter(i)`, `hpc_cq_*_interrupt` | control, status, counters, interrupts |

Register access goes through `HPC_CQ_WR32` / `HPC_CQ_RD32`:
* by default, volatile MMIO at `HPC_CQ_BASE` (`0x4000_8000`);
* with `-DHPC_CQ_COSIM`, the co-simulation hooks.

**Example: `sw/examples/cq_submit_demo.c`.** A three-stage pipeline with no host synchronisation inside it:
```
DMA_LOAD a, x, y  ->  VECTOR_FMA y = a*x + y (in place)  ->  VECTOR_ADD z = y + x  ->  DMA_STORE y, z  ->  FENCE(IRQ)
```
It then shows the error path:
```
misaligned DMA_LOAD -> ALIGN    NOP -> SKIPPED    ERR_CLEAR    NOP -> OK
```

The example runs **on the RTL**. `tb/cosim/cosim_main.cpp` implements the register hooks as real register-bus cycles
on `hpc_cq_mmio` + `hpc_cq_tile` + external memory (`make cosim`). Output of the final run (`reports/cosim.log`):

```
SilicaFlux-HPC command queue: INFO 07080401, 4 free slots
completion records:
  seq  0 tid  0 DMA_LOAD   OK      err NONE     count  400 ff 00
  seq  1 tid  1 DMA_LOAD   OK      err NONE     count  400 ff 00
  seq  2 tid  2 DMA_LOAD   OK      err NONE     count  400 ff 00
  seq  3 tid  3 VECTOR_FMA OK      err NONE     count  100 ff 00
  seq  4 tid  4 VECTOR_ADD OK      err NONE     count  100 ff 00
  seq  5 tid  5 DMA_STORE  OK      err NONE     count  400 ff 00
  seq  6 tid  6 DMA_STORE  OK      err NONE     count  400 ff 00
  seq  7 tid  7 FENCE      OK      err NONE     count    0 ff 00 irq
results: y = a*x + y and z = y + x correct for all elements
error handling (stop-on-error):
  (software pre-check predicts ERR ALIGN)
  seq  8 tid  8 DMA_LOAD   ERROR   err ALIGN    count    0 ff 00
  seq  9 tid  9 NOP        SKIPPED err PRIOR    count    0 ff 00
  seq 10 tid 10 NOP        OK      err NONE     count    0 ff 00
counters: cycles 2828, committed 11, DMA jobs 5, vector jobs 2, DMA/vector overlap 174 cycles, hazard stalls 503
DEMO PASS (0 failures)
```

The eight commands are submitted into a depth-4 queue without waiting. `hpc_cq_submit` reports `EBUSY` when the queue
is full, and the example drains records meanwhile. The hardware itself serialises the dependent stages (503 hazard
stall cycles) and overlaps the independent ones (174 cycles with a DMA and a vector job in flight together).

## 4. Proposed SoC memory-map entries

The page and interrupt numbers are unused in `memmap/silicaflux_v_datafabric.yaml`. They are proposed, not applied,
because the YAML belongs to DataFabric and is the single source of truth there.

```yaml
pages:
  - {name: CQ, index: 8, parent: PERIPH, new: true, block: cq}     # 0x4000_8000, hpc_cq_mmio
interrupts:
  - {name: CQ, index: 9, new: true}                                  # hpc_cq_mmio irq_o
masters:   # if the tile is attached to the SoC crossbar instead of using its internal one
  - {name: TILE_DMA, index: 4, deny: [PERIPH], new: true}
```

Window parameters for that integration:
* `EXT_BASE = 0x1000_0000`, `EXT_LOG2 = 17` (SRAM banks 0–3);
* `SPM_BASE = 0x2000_0000`, `SPM_LOG2 = 16` (TSPM grown to 64 KiB, the one-line YAML change Module 04 describes).
