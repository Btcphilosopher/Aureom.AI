# 07 — Performance, integration, limitations, next steps

## 1. Performance (RTL cycle counts; `reports/perf.md`, `reports/latency.txt`)

The figures come from cycle-accurate RTL simulation of `hpc_cq_tile`:
* 2 lanes unless stated;
* external memory with 1-cycle latency, always ready;
* host always ready.

Every run is also a passing self-checking test.

| Measurement | Result |
|---|---|
| Decode-resolved command (NOP / FENCE / invalid): acceptance → record valid | 4 cycles (decode release t+2, record t+4; `latency.txt`) |
| Back-to-back NOP stream, 256 commands | 261 cycles = 1.02 cycles / command (one per cycle + pipeline fill) |
| Acceptance → DMA / vector `start` pulse | 3 cycles |
| DMA_LOAD 64 B / 1 KiB / 4 KiB | 73 / 1033 / 4105 cycles (4.01 cycles / word asymptotically = the DataFabric simple engine) |
| DMA_STORE 1 KiB | 1033 cycles |
| VECTOR_ADD 256 / 1024 elements, 2 lanes | 401 / 1553 cycles = 0.66 elements / cycle (N / 3) |
| VECTOR_ADD 256 / 1024 elements, 4 lanes | 208 / 784 cycles = 1.31 elements / cycle (N / 3) |
| VECTOR_MUL 256, 2 lanes | 401 cycles (same as ADD: 3 port transactions per element) |
| VECTOR_FMA 256, 2 / 4 lanes | 530 / 274 cycles = 0.48 / 0.93 elements / cycle (N / 4: D is read too) |
| Independent DMA_LOAD 1 KiB + VECTOR_ADD 256: overlap on / off | 1034 / 1429 cycles (−28 %; the vector job is hidden under the DMA) |
| Dependent DMA_LOAD → VECTOR_ADD (reads what the DMA writes), overlap on | 1429 cycles — correctly serialised (= the overlap-off figure) |
| Double-buffered pipeline, 10 tiles × 96 elements (2 loads + op + store per tile): overlap on / off | 11646 / 13346 cycles (−13 %; DMA-bound: 3 × 96 words × 4 cycles per tile vs ≈ 150 vector cycles) |

What limits what:

* **Queue and scheduler.**
  * One command per cycle through decode, commit and hand-over.
  * Decode-resolved commands: record valid 4 cycles after acceptance.
  * A unit `start` pulse 3 cycles after acceptance.
  * Neither the queue nor the scheduler is ever the bottleneck for DMA or vector work.
* **DMA.** The DataFabric simple engine (`ENGINE = 0`, its production candidate) moves one word per 4 cycles: read
  handshake + response, write handshake + response. The queue adds a fixed ≈ 7 cycles per job (start, validate,
  complete, commit, record).
* **Vector.** The executor needs 3 scratchpad transactions per element (ADD / MUL: read A, read B, write D), or 4 for
  FMA. It has one Module 04 port per lane, so it is port-bound at about N/3 elements per cycle. The Module 03 array
  could take N per cycle.
* **Overlap.** An independent DMA job and vector job run concurrently, which pays off directly in the double-buffered
  pipeline. With `OVERLAP_EN = 0`, or when the jobs are dependent, they serialise and the cycle counts add up.

## 2. Integration

* **Stand-alone tile.** `hpc_cq_tile` exposes:
  * the command / record streams;
  * an SFB2 master port to external memory;
  * an SFB2 slave port for CPU access to the scratchpad.

  Put `hpc_cq_mmio` in front for a CPU on the SilicaFlux-V register bus. Proposed page 8 and INTC source 9:
  docs/05 §4.
* **In the SilicaFlux-V / DataFabric SoC.** Two options:
  * keep the tile crossbar and connect `ext_*` to a new SoC crossbar master port;
  * or drop the tile crossbar, make the DMA engine a SoC crossbar master, and make the scratchpad SFB2 port a SoC
    slave. Either way the queue is unchanged: it only needs the windows (`EXT_*`, `SPM_*`) to match the SoC map.
* **Other front ends.** A hardware descriptor-ring fetcher, or a RISC-V coprocessor interface, would connect to the
  stream port. The 32-byte descriptor is laid out for memory rings.

## 3. Limitations (stated, not hidden)

* **In-order issue, one job per unit.**
  * At most two jobs are in flight: one DMA, one vector.
  * A stalled command blocks every younger one (head-of-line blocking).
  * This is the brief's "start strictly in order", with overlap only where it is provably safe. There is no
    out-of-order issue, no second DMA channel and no speculation.
* **Executor bandwidth.** Port-bound, as described in §1. Ways to lift it:
  * a beat-wide scratchpad port (Module 04 `DATA_WIDTH = N·32`);
  * two ports per lane;
  * the DataFabric buffered DMA engine (`dma_burst_engine`, same control contract) for the DMA side.

  None of these is evaluated here.
* **v1 ABI scope.** The following are reserved, not implemented:
  * `STRIDE` (packed data only);
  * source C (word 6);
  * scalar broadcast, reductions and the other Module 03 operations (code points `0x13`–`0x1F` are reserved for them).
* **Stop-mode precision.** Execution errors are imprecise with respect to independent younger commands that were
  already running. They are harmless by construction, and a BARRIER / FENCE gives a precise cut (docs/04 §2).
* **Timeout recovery** needs a reset of the tile. There is no per-unit soft reset. After a timeout, the timed-out
  unit's footprint is no longer tracked for dependencies; stop mode, the default, prevents further execution until
  software intervenes.
* **Records are not written to memory.** The host reads them through the stream or the MMIO adapter: 5 register
  accesses per record.
* **Untested guard.** `ERR_VEC_ENGINE` (the array returns an illegal or short completion record) cannot be provoked
  without modifying the reused Module 03 array, so that check is not exercised by any test (`reports/coverage.md`).
* **Verification limits.** Simulation, assertions, mutation, structural proof and co-simulation only:
  * no formal proof of the scheduler;
  * no gate-level simulation;
  * nothing run on hardware.
* **Physical results.** No clock frequency, silicon area or power is claimed. Synthesis evidence is Yosys generic
  gates and an ECP5 mapping only (`reports/synth/summary.md`).

## 4. Prioritised next steps

1. **Formal.** Bounded proofs (SymbiYosys / yosys-smtbmc, as DataFabric did) of the scheduler's properties already
   asserted in simulation:
   * no conflicting jobs in flight;
   * in-order issue and commit;
   * one record per command;
   * FENCE waits.
2. **Executor bandwidth.** A beat-wide scratchpad read path, then measure against Module 03's N elements per cycle.
3. **DMA throughput.** Evaluate `dma_burst_engine` behind the same control contract.
4. **Descriptor ring.** A hardware fetcher (host writes a tail pointer; the queue fetches 32-byte descriptors by DMA
   and writes 16-byte records back), removing the register-bus cost of §1.
5. **ABI v1.x additions** in reserved code points: scalar-broadcast ops (AXPY), sum / dot reduction (Module 03
   `red`), strided DMA.
6. **SoC integration.** Add the proposed page / IRQ / master to the DataFabric YAML and regenerate the derived files.
   Then run the DataFabric SoC regression with the tile attached.
