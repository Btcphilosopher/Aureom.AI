# 03 — Synchronisation: ordering, FENCE, BARRIER, RESET_COUNTERS

## 1. The ordering model

| Property | Guarantee | How |
|---|---|---|
| Issue order | strictly program order. A command never starts before an older one has left the decode slot. | single decode slot, no reordering (SVA `a_in_order_issue`) |
| Memory semantics | final memory and every record **equal executing the commands one at a time in program order** | one job per unit; jobs complete only after all writes are acknowledged; a DMA and a vector job overlap only if their byte footprints do not conflict (docs/02 §3.4) |
| Completion order | records strictly in acceptance order, `SEQ` 0, 1, 2, … | in-order commit (SVA `a_in_order_retire`) |
| Host visibility | when the host receives the record of command *k*, every memory effect of commands 0 … *k* is visible to any later reader: host port, DMA or vector unit | commit only after the command and all older ones completed; completion means written **and acknowledged** |

The last row already makes every record a synchronisation point for the **host**. FENCE adds what records alone
cannot: it stops **younger commands** from starting until the older ones have completed.

## 2. FENCE (opcode 0x20)

A FENCE leaves the decode slot only when **no older job is in flight**. No younger command can be decoded or issued
before that. The FENCE then completes and commits like a NOP. With `FL_IRQ` it raises the commit interrupt.

### What a FENCE waits for

| Item | Waits? | Why that matches the hardware |
|---|---|---|
| **DMA reads** of older commands | **yes** | The DMA engine issues each write only after the read of the same beat returned, and pulses `done` only after the last write response. A completed DMA job has no read outstanding. |
| **DMA writes** of older commands | **yes** | `done` follows the last write **response**. SFB2 rule R7: the response is issued only after the target performed the write. The scratchpad answers after the bank write (`WRITE_ACK = 1`). External memory answers after the write by the same rule. |
| **Vector results** of older commands | **yes** | The executor completes only after the array's completion record. Module 03 presents that only after the command's last result beat. |
| **Scratchpad commits** of older DMA and vector jobs | **yes** | Every scratchpad write of a completed job has been acknowledged. Module 04: a write commits at its issue edge, and any read issued later, from any port, returns the new data. |
| Older **validation errors / SKIPPED** commands | trivially | they complete at decode with no side effect |
| Older commands' **records handed to the host** | no | not needed for memory ordering; the FENCE's own record comes after theirs anyway |
| Memory traffic **outside** the queue (host-port CPU accesses, other masters) | no | the queue cannot see it. The host orders its own accesses by waiting for a record (§1, last row). |
| A job whose unit **timed out** | no | the job already completed with `ERR_TIMEOUT`. Its unit is quarantined, its memory effects are undefined, and the unit stays down until reset (docs/04 §3). |

### When software needs a FENCE

Dependencies between commands are tracked by hardware, so correctness never needs a FENCE between two commands of the
queue. FENCE is for:

1. **Precise error behaviour.** Nothing after the FENCE starts until everything before it has completed. In stop
   mode, a failure before the FENCE therefore skips every command after it, deterministically (docs/04 §2).
2. **Phase boundaries.** For example, timing a phase, or an `FL_IRQ` on the FENCE as an "everything so far is done,
   and nothing new has started" interrupt.
3. **Interaction with agents the queue cannot see.** A CPU or another master that will touch memory written by
   younger commands.
4. **Bring-up and debug.** Serialising a command stream without rebuilding with `OVERLAP_EN = 0`.

## 3. FL_BARRIER (flag bit 1)

A command with `FL_BARRIER` waits at decode exactly like a FENCE: until no older job is in flight. Then it is decoded
normally. "FENCE; X" behaves like "X with FL_BARRIER", minus one record. BARRIER works on every opcode.

## 4. RESET_COUNTERS (opcode 0x30)

1. **Wait.** It waits until every older command has completed **and committed**. It is the only command that waits for
   commits.
2. **Clear.** It clears all 17 performance counters in the cycle it leaves the decode slot.
3. **Commit.** It commits after the clear, so its own commit is counted.

Counter content afterwards:

* `CMD_COMMIT`, `CMD_ERR`, `CMD_SKIP`, `DMA_ISSUE` and `VEC_ISSUE` count exactly the RESET_COUNTERS command and the
  commands after it. Waiting for commits guarantees that no commit of an older command lands after the clear. The
  testbench checks these exactly.
* `CMD_IN` counts the commands accepted at the input after the clear cycle. Commands already queued behind the
  RESET_COUNTERS were accepted before it and are not counted.
* Cycle-type counters (`CYCLES`, `BUSY`, `*_ACTIVE`, `OVERLAP`, stalls, `Q_FULL`, `CPL_BP`) restart at the clear.

The `ctrl_perf_clear_i` input (MMIO `CTRL.PERF_CLEAR`) clears immediately, unordered with respect to commands.

## 5. Overlap control

| Configuration | Behaviour |
|---|---|
| `OVERLAP_EN = 1` (default) | one DMA job and one independent vector job may run concurrently |
| `OVERLAP_EN = 0` | every DMA / vector command waits like a BARRIER: one job in flight at a time. Results and records are identical; only the timing differs (`reports/perf.md`). |

Decode-resolved commands (NOP, FENCE, invalid, skipped) never occupy a unit. They keep flowing at one per cycle up to
the next command that has to wait.
