# 06 — FPGA backend and board self-test

## Backend

`BACKEND = SRAM_BACKEND_FPGA` selects `sram_fpga_{1rw,1r1w,2rw}`: inference templates, no vendor IP cores.

| Item | Behaviour |
|---|---|
| Single port | per-lane write loop + read only when not writing ("no change"): the write cycle returns no read data by contract |
| Simple dual port (1R1W) | write and read in separate processes → read-during-write at the same address returns the **old** word (RTL semantics; an inferring tool must preserve them, adding bypass logic if the primitive cannot) — hence `COLLISION=READ_OLD` is allowed here |
| True dual port | both ports in one process; same-address write involvement prevented by `sram_tdp` (STALL) or forbidden (FORBID) |
| Latency | 1 = BRAM output latch; 2 = BRAM + output register (no reset, absorbable); ≥3 adds fabric registers |
| Initial content | `INIT_FILE` (`$readmemh`) — the only backend that accepts it |

## Inference evidence (Yosys only — `reports/mem/synth.md`)

Yosys `synth_xilinx -family xc7`, `synth_ice40`, `synth_ecp5` map every FPGA-backend memory to RAM primitives with
no `$mem` cell left (asserted), e.g. `sram_sp` 32×1024 → 1 × RAMB36E1, 64×4096 / 128×2048 (32 KiB) → 8 ×
RAMB36E1, 32×131072 (512 KiB) → 128 × RAMB36E1, `sram_1r1w` 32×512 → 1 × RAMB18E1, `sram_tdp` 32×1024 → 1 ×
RAMB36E1; iCE40 → SB_RAM40_4K; ECP5 → DP16KD.  Exact counts and the remaining LUT/FF usage are in the report.

**Not done:** Vivado / Quartus / Radiant runs (not installed), timing closure, bitstream generation, and any test on
hardware.  No FPGA validation is claimed.

## Standalone memory test (`rtl/mem/fpga/`)

`sram_fpga_selftest_top` (default 32 b × 4096 = 16 KiB, latency 2) writes and reads back eight pattern passes —
zeros, ones, checkerboard, walking one, walking zero, address-in-data, address hash, byte-mask (write ones, clear
lane `addr % lanes` with a masked write) — stops at the first miscompare and reports:

* LEDs: `led[0]` heartbeat / done, `led[1]` done, `led[2]` PASS, `led[3]` FAIL;
* UART 8N1 (default 115200 baud at 100 MHz): `SFX SRAM PASS\r\n` or `SFX SRAM FAIL P<pass> A<addr hex>\r\n`.

Simulated by `tb_sram_fpga_selftest` with an independent UART receiver: fault-free run → `SFX SRAM PASS`,
LEDs `0111`; with a stuck-at-0 injected at word 77 bit 3 → `SFX SRAM FAIL P1 A004D`, LEDs `1011` (Verilator and
Icarus).  Synthesised for xc7 with Yosys (4 × RAMB36E1).

Constraints for the Digilent Arty A7-100T (`xc7a100tcsg324-1`, the board of the repository's existing Vivado
flow): `rtl/mem/fpga/constraints/arty_a7_100t_sram_selftest.xdc` (clock E3, reset C2, LEDs H5/J5/T9/T10, UART TX
D10 — verify against Digilent's master XDC for your board revision).

To run on a board (not done here):

```
# Vivado (example, non-project mode)
read_verilog -sv [glob rtl/mem/backends/generic/*.sv rtl/mem/backends/fpga/*.sv rtl/mem/backends/asic/*.sv \
                       rtl/mem/backends/asic/stubs/*.sv rtl/mem/sram_*.sv rtl/mem/fpga/*.sv]
set_property include_dirs {rtl/mem rtl/mem/backends/asic} [current_fileset]
read_xdc rtl/mem/fpga/constraints/arty_a7_100t_sram_selftest.xdc
synth_design -top sram_fpga_selftest_top -part xc7a100tcsg324-1 -verilog_define SYNTHESIS
opt_design; place_design; route_design; write_bitstream selftest.bit
```

then open the USB-UART at 115200 8N1 and press the red reset button.
