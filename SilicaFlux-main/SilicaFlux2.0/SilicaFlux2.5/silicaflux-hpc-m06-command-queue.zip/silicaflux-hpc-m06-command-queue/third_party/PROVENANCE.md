# third_party — reused sources (unmodified)

Every file below is a byte-identical copy of a file from an earlier SilicaFlux deliverable in the Aureom.AI
repository. Byte identity was checked with `cmp` against the source archives when this module was built:
60 files, 0 differences. `SHA256SUMS` records each file's digest. None of these files may be edited; a change
belongs in the owning module.

| Directory | Source archive (repository path) | Files used | Role here |
|---|---|---|---|
| `silicaflux-hpc-m03-vector-array/rtl/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m03-vector-array.zip` | `hpc_vector_array.sv`, `hpc_varray_*.sv` | the vector engine; `hpc_varray_fifo` is also the command FIFO |
| `silicaflux-hpc-m03-vector-array/rtl/lane/` | same archive (Module 03's own unmodified copy of the Module 02 lane; identical to `silicaflux-hpc-m02-vector-lane.zip` `rtl/`) | `hpc_vector_lane.sv`, `hpc_fp32_*.sv`, `hpc_vector_pkg.sv`, … | FP32 lanes; `hpc_vector_pkg` rounding-mode / flag encodings |
| `silicaflux-hpc-m02-vector-lane/ref/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m02-vector-lane.zip` | `fp32_ref.py` | bit-exact FP32 reference used by the command model |
| `silicaflux-hpc-m04-scratchpad/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m04-scratchpad.zip` | `rtl/*`, `third_party/` (SRAM Wrapper Library subset, DataFabric `dma_fifo.sv`) | tile scratchpad |
| `silicaflux-datafabric/rtl/dma/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-datafabric.zip` (identical to `SilicaFlux-main/silicaflux-datafabric.zip`) | `dma_transfer_engine.sv`, `dma_validate.sv`, `dma_defs.svh` | DMA engine; its validator is the scheduler's cross-check |
| `silicaflux-datafabric/rtl/interconnect/` | same | `sfb_crossbar.sv` and its five sub-blocks | SFB2 crossbar in the tile |
| `silicaflux-datafabric/tb/common/` | same | `sfb_protocol_checker.sv` | SFB2 protocol monitor (verification only) |

Licensing follows the Aureom.AI repository. Berkeley SoftFloat, used by earlier modules' references, is not needed
here: the Module 02 Python model is exact-arithmetic and self-contained.
