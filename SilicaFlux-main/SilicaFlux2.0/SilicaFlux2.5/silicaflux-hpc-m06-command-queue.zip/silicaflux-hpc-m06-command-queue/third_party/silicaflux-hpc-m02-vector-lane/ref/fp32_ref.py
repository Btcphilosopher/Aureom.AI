#!/usr/bin/env python3
"""
SilicaFlux-HPC :: fp32_ref -- exact-arithmetic IEEE-754 binary32 reference model

Independent of the RTL: every finite operand is decoded to an exact dyadic
rational  (-1)^s * M * 2^E  (Python arbitrary-precision integers), the
operation is computed EXACTLY (no guard/sticky approximations, no alignment
frame), and the exact result is rounded once by `round_pack`.

Semantics implemented (docs/FP_SEMANTICS.md):
  * IEEE 754-2019 arithmetic, all five rounding attributes
    (RNE, RTZ, RDN, RUP, RMM = RISC-V frm 0..4)
  * default exception handling, flags {NV,DZ,OF,UF,NX} (RISC-V fflags order)
  * tininess detected AFTER rounding; UF = tiny AND inexact
  * NaN results are the RISC-V canonical quiet NaN 0x7FC00000
  * FMA: inf*0 raises NV even when the addend is a quiet NaN (RISC-V)
  * FMIN/FMAX = minimumNumber/maximumNumber, -0 < +0, sNaN raises NV
  * FEQ quiet, FLT/FLE signaling
This model is cross-validated against the host CPU's hardware FPU
(fp32_hwref.c) for every vector/rounding mode the hardware supports.
"""

QNAN = 0x7FC00000
RNE, RTZ, RDN, RUP, RMM = 0, 1, 2, 3, 4
NV, DZ, OF, UF, NX = 16, 8, 4, 2, 1

# opcodes (rtl/hpc_vector_pkg.sv)
OP_FMV, OP_FADD, OP_FSUB, OP_FMUL = 0x00, 0x01, 0x02, 0x03
OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD = 0x04, 0x05, 0x06, 0x07
OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE = 0x08, 0x09, 0x0A, 0x0B, 0x0C
OP_IADD, OP_IMUL = 0x10, 0x11

ROUNDING_OPS = {OP_FADD, OP_FSUB, OP_FMUL, OP_FMADD, OP_FMSUB, OP_FNMSUB, OP_FNMADD}
FCMP_OPS = {OP_FMIN, OP_FMAX, OP_FEQ, OP_FLT, OP_FLE}
INT_OPS = {OP_IADD, OP_IMUL}
OP_NAMES = {OP_FMV: "FMV", OP_FADD: "FADD", OP_FSUB: "FSUB", OP_FMUL: "FMUL",
            OP_FMADD: "FMADD", OP_FMSUB: "FMSUB", OP_FNMSUB: "FNMSUB", OP_FNMADD: "FNMADD",
            OP_FMIN: "FMIN", OP_FMAX: "FMAX", OP_FEQ: "FEQ", OP_FLT: "FLT", OP_FLE: "FLE",
            OP_IADD: "IADD", OP_IMUL: "IMUL"}
RM_NAMES = {RNE: "RNE", RTZ: "RTZ", RDN: "RDN", RUP: "RUP", RMM: "RMM"}


# ----------------------------------------------------------------- decoding
def is_nan(x):  return (x & 0x7F800000) == 0x7F800000 and (x & 0x7FFFFF) != 0
def is_snan(x): return is_nan(x) and not (x & 0x400000)
def is_inf(x):  return (x & 0x7FFFFFFF) == 0x7F800000
def is_zero(x): return (x & 0x7FFFFFFF) == 0
def sign(x):    return (x >> 31) & 1


def finite(x):
    """Exact value of a finite encoding as (sign, M, E): (-1)^s * M * 2^E."""
    e = (x >> 23) & 0xFF
    f = x & 0x7FFFFF
    if e == 0:
        return sign(x), f, -149
    return sign(x), f | (1 << 23), e - 150


# ----------------------------------------------------------------- rounding
def _rnd(M, E, lsb_exp, rm, s):
    """Round M*2^E (M > 0) to an integer multiple of 2^lsb_exp.
    Returns (q, inexact, tie) with result value q * 2^lsb_exp."""
    shift = lsb_exp - E
    if shift <= 0:
        return M << (-shift), False, False
    q = M >> shift
    rem = M - (q << shift)
    half = 1 << (shift - 1)
    inexact = rem != 0
    tie = rem == half
    if rm == RNE:
        up = rem > half or (tie and (q & 1) == 1)
    elif rm == RTZ:
        up = False
    elif rm == RDN:
        up = inexact and s == 1
    elif rm == RUP:
        up = inexact and s == 0
    elif rm == RMM:
        up = rem >= half
    else:
        raise ValueError("bad rounding mode")
    return q + (1 if up else 0), inexact, tie


def round_pack(s, M, E, rm, info=None):
    """Round the exact non-zero value (-1)^s * M * 2^E to binary32.
    Returns (bits, flags)."""
    assert M > 0
    lead = E + M.bit_length() - 1                # exponent of the leading bit
    # tininess after rounding: round to 24 bits with unbounded exponent range
    qu, _, _ = _rnd(M, E, lead - 23, rm, s)
    tiny = (lead - 23 + qu.bit_length() - 1) < -126
    # actual rounding: 24 significant bits, but never below the subnormal LSB
    lsb_exp = max(lead - 23, -149)
    q, inexact, tie = _rnd(M, E, lsb_exp, rm, s)
    if info is not None:
        info["tie"] = tie
        info["tiny"] = tiny
    flags = 0
    if q == 0:                                   # underflow to zero
        return (s << 31), (UF | NX)
    rlead = lsb_exp + q.bit_length() - 1
    if rlead > 127:                              # overflow
        to_inf = {RNE: True, RMM: True, RTZ: False,
                  RDN: s == 1, RUP: s == 0}[rm]
        mag = 0x7F800000 if to_inf else 0x7F7FFFFF
        return (s << 31) | mag, (OF | NX)
    if inexact:
        flags |= NX
        if tiny:
            flags |= UF
    if rlead >= -126:                            # normal
        sh = lsb_exp - (rlead - 23)              # -1 after a rounding carry
        m = q << sh if sh >= 0 else q >> (-sh)   # exact: carry gives q = 2^24
        assert m >> 23 == 1
        bits = ((rlead + 127) << 23) | (m - (1 << 23))
    else:                                        # subnormal (lsb_exp == -149)
        assert lsb_exp == -149
        bits = q
    return (s << 31) | bits, flags


# ----------------------------------------------------------------- operations
def _exact_zero_sign(sx, sy, rm):
    """Sign of an exact zero sum of terms with signs sx, sy (IEEE 754 6.3)."""
    if sx == sy:
        return sx
    return 1 if rm == RDN else 0


def _add_exact(sx, Mx, Ex, sy, My, Ey, rm, info):
    if Mx == 0 and My == 0:
        return _exact_zero_sign(sx, sy, rm) << 31, 0
    E = min(Ex, Ey)
    S = (-1 if sx else 1) * (Mx << (Ex - E)) + (-1 if sy else 1) * (My << (Ey - E))
    if S == 0:
        return _exact_zero_sign(sx, sy, rm) << 31, 0
    return round_pack(1 if S < 0 else 0, abs(S), E, rm, info)


def fadd(a, b, rm, negb=False, info=None):
    sb = sign(b) ^ (1 if negb else 0)
    if is_nan(a) or is_nan(b):
        return QNAN, (NV if (is_snan(a) or is_snan(b)) else 0)
    if is_inf(a) and is_inf(b):
        if sign(a) != sb:
            return QNAN, NV
        return a, 0
    if is_inf(a):
        return a, 0
    if is_inf(b):
        return (sb << 31) | 0x7F800000, 0
    sa_, Ma, Ea = finite(a)
    _, Mb, Eb = finite(b)
    return _add_exact(sa_, Ma, Ea, sb, Mb, Eb, rm, info)


def fmul(a, b, rm, info=None):
    sp = sign(a) ^ sign(b)
    if is_nan(a) or is_nan(b):
        return QNAN, (NV if (is_snan(a) or is_snan(b)) else 0)
    if (is_inf(a) and is_zero(b)) or (is_zero(a) and is_inf(b)):
        return QNAN, NV
    if is_inf(a) or is_inf(b):
        return (sp << 31) | 0x7F800000, 0
    _, Ma, Ea = finite(a)
    _, Mb, Eb = finite(b)
    if Ma == 0 or Mb == 0:
        return sp << 31, 0
    return round_pack(sp, Ma * Mb, Ea + Eb, rm, info)


def ffma(a, b, c, rm, negp=False, negc=False, info=None):
    sp = sign(a) ^ sign(b) ^ (1 if negp else 0)
    sc = sign(c) ^ (1 if negc else 0)
    inv_mul = (is_inf(a) and is_zero(b)) or (is_zero(a) and is_inf(b))
    if is_nan(a) or is_nan(b) or is_nan(c):
        nv = is_snan(a) or is_snan(b) or is_snan(c) or inv_mul
        return QNAN, (NV if nv else 0)
    if inv_mul:
        return QNAN, NV
    if is_inf(a) or is_inf(b):
        if is_inf(c) and sc != sp:
            return QNAN, NV
        return (sp << 31) | 0x7F800000, 0
    if is_inf(c):
        return (sc << 31) | 0x7F800000, 0
    _, Ma, Ea = finite(a)
    _, Mb, Eb = finite(b)
    _, Mc, Ec = finite(c)
    return _add_exact(sp, Ma * Mb, Ea + Eb, sc, Mc, Ec, rm, info)


def _lt_mm(a, b):
    """a < b for non-NaN encodings with -0 < +0."""
    if sign(a) != sign(b):
        return sign(a) == 1
    if sign(a) == 0:
        return (a & 0x7FFFFFFF) < (b & 0x7FFFFFFF)
    return (a & 0x7FFFFFFF) > (b & 0x7FFFFFFF)


def _num_lt(a, b):
    if is_zero(a) and is_zero(b):
        return False
    return _lt_mm(a, b)


def _num_eq(a, b):
    return a == b or (is_zero(a) and is_zero(b))


def fminmax(a, b, is_max):
    nv = NV if (is_snan(a) or is_snan(b)) else 0
    if is_nan(a) and is_nan(b):
        return QNAN, nv
    if is_nan(a):
        return b, nv
    if is_nan(b):
        return a, nv
    lt = _lt_mm(a, b)
    if is_max:
        return (b if lt else a), nv
    return (a if lt else b), nv


def fcmp(op, a, b):
    anynan = is_nan(a) or is_nan(b)
    if op == OP_FEQ:
        nv = NV if (is_snan(a) or is_snan(b)) else 0
        return (0 if anynan else int(_num_eq(a, b))), nv
    nv = NV if anynan else 0
    if anynan:
        return 0, nv
    if op == OP_FLT:
        return int(_num_lt(a, b)), nv
    return int(_num_lt(a, b) or _num_eq(a, b)), nv


def execute(op, rm, a, b, c, en_fcmp=True, en_int=True, info=None):
    """Lane-level reference: returns (result, flags, illegal)."""
    if op in ROUNDING_OPS and rm > RMM:
        return 0, 0, 1
    if op == OP_FMV:
        return a, 0, 0
    if op == OP_FADD:
        return (*fadd(a, b, rm, False, info), 0)
    if op == OP_FSUB:
        return (*fadd(a, b, rm, True, info), 0)
    if op == OP_FMUL:
        return (*fmul(a, b, rm, info), 0)
    if op == OP_FMADD:
        return (*ffma(a, b, c, rm, False, False, info), 0)
    if op == OP_FMSUB:
        return (*ffma(a, b, c, rm, False, True, info), 0)
    if op == OP_FNMSUB:
        return (*ffma(a, b, c, rm, True, False, info), 0)
    if op == OP_FNMADD:
        return (*ffma(a, b, c, rm, True, True, info), 0)
    if op in FCMP_OPS:
        if not en_fcmp:
            return 0, 0, 1
        if op == OP_FMIN:
            return (*fminmax(a, b, False), 0)
        if op == OP_FMAX:
            return (*fminmax(a, b, True), 0)
        return (*fcmp(op, a, b), 0)
    if op in INT_OPS:
        if not en_int:
            return 0, 0, 1
        if op == OP_IADD:
            return (a + b) & 0xFFFFFFFF, 0, 0
        return (a * b) & 0xFFFFFFFF, 0, 0
    return 0, 0, 1


# ----------------------------------------------------------------- self test
def _selftest():
    import struct
    def f2b(f): return struct.unpack("<I", struct.pack("<f", f))[0]
    one, two, three = f2b(1.0), f2b(2.0), f2b(3.0)
    assert fadd(one, two, RNE) == (three, 0)
    assert fadd(one, one, RNE, negb=True) == (0, 0)
    assert fadd(one, one, RDN, negb=True) == (0x80000000, 0)
    assert fadd(0x80000000, 0x80000000, RNE) == (0x80000000, 0)
    # 1 + 2^-24 is a tie: RNE -> 1, RMM -> 1+ulp
    h = f2b(2.0 ** -24)
    assert fadd(one, h, RNE) == (one, NX)
    assert fadd(one, h, RMM) == (one + 1, NX)
    assert fmul(0x7F7FFFFF, two, RNE) == (0x7F800000, OF | NX)
    assert fmul(0x7F7FFFFF, two, RTZ) == (0x7F7FFFFF, OF | NX)
    assert fmul(0x00000001, f2b(0.5), RNE) == (0x00000000, UF | NX)   # tie to even 0
    assert fmul(0x00000001, f2b(0.5), RMM) == (0x00000001, UF | NX)
    assert fmul(0x7F800000, 0, RNE) == (QNAN, NV)
    assert ffma(0x7F800000, 0, QNAN, RNE) == (QNAN, NV)
    assert ffma(one, one, one, RNE) == (two, 0)
    # tininess after rounding: exact (2^24-1)*2^-150 has 24 significant bits,
    # so unbounded-exponent rounding leaves it below 2^-126 (tiny), while the
    # subnormal-grid rounding (tie, odd) carries to the smallest normal.
    v = _add_exact(0, 0x7FFFFF * 2 + 1, -150, 0, 0, 0, RNE, None)
    assert v == (0x00800000, UF | NX), v
    # exact (2^25-1)*2^-151 rounds (24-bit, unbounded) up to 2^-126: not tiny
    v = _add_exact(0, (1 << 25) - 1, -151, 0, 0, 0, RNE, None)
    assert v == (0x00800000, NX), v
    assert fminmax(0x80000000, 0, False) == (0x80000000, 0)
    assert fminmax(0x80000000, 0, True) == (0, 0)
    assert fminmax(0x7F800001, one, False) == (one, NV)
    assert fcmp(OP_FEQ, QNAN, one) == (0, 0)
    assert fcmp(OP_FLT, QNAN, one) == (0, NV)
    assert fcmp(OP_FLE, 0x80000000, 0) == (1, 0)
    print("fp32_ref selftest passed")


if __name__ == "__main__":
    _selftest()
