#!/usr/bin/env python3
"""Mutation check: break the RTL on purpose, one line at a time, and require that the regression notices.

  mutate.py [--only M01,M05] [--keep-going]

Each mutant is applied to the working tree, the selected checks run, and the file is restored.  A mutant is KILLED when at least
one selected check fails.  A SURVIVOR is a test gap and is listed in reports/mutation.md.
"""
import argparse, os, re, shutil, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.join(ROOT, "tests", "keystone"))

A = "rtl/albion/"
MUTANTS = [
    # name, file, old, new, checks, description
    ("M01", A + "sf_keystone_interrupts.sv", "if (cand[i] && prio_q[i] >= win_prio)", "if (cand[i] && prio_q[i] > win_prio)", ["unit:intc", "sys:boot"],
     "equal priority: the HIGHEST id wins instead of the lowest"),
    ("M02", A + "sf_keystone_interrupts.sv", "    for (int i = 1; i <= N; i++) if (type_q[i] && edge_ev[i]) latch_n[i] = 1'b1;\n", "", ["unit:intc"],
     "a rising edge is dropped (the original edge-vs-PEND_CLR hazard, taken to its extreme)"),
    ("M03", A + "sf_keystone_interrupts.sv", "(prio_q[i] > thresh_q)", "(prio_q[i] >= thresh_q)", ["unit:intc", "sys:boot"],
     "priority threshold off by one"),
    ("M04", A + "sf_keystone_sram.sv", "assign b_err    = rb_rd_q && any_ue;", "assign b_err    = 1'b0;", ["unit:sram_ecc", "sys:boot"],
     "uncorrectable data-side error is not reported as a bus error"),
    ("M05", A + "sf_keystone_sram.sv", "assign ev_ce    = any_ce && !any_ue;", "assign ev_ce    = 1'b0;", ["unit:sram_ecc", "sys:boot"],
     "corrected errors are not reported to RAS"),
    ("M06", A + "sf_keystone_cmd.sv", "end else if (priv_q < op_minpriv(op_q)) begin", "end else if (1'b0) begin", ["sys:boot"],
     "hardware privilege check removed"),
    ("M07", A + "sf_keystone_cmd.sv", "        if (busy) begin\n          sec_pulse[KS_SEC_BUSY_WRITE] <= 1'b1; sec_info <= op_q;\n        end else begin\n          case (off)\n            KS_CMD_OP:", "        if (1'b0) begin\n          sec_pulse[KS_SEC_BUSY_WRITE] <= 1'b1; sec_info <= op_q;\n        end else begin\n          case (off)\n            KS_CMD_OP:", ["sys:boot"],
     "staging registers writable while a command is BUSY"),
    ("M08", A + "sf_keystone_cmd.sv", "wire        tmo_hit   = running && timeout_q != 32'd0 && to_cnt_q >= timeout_q;", "wire        tmo_hit   = 1'b0;", ["sys:boot"],
     "command timeout never fires"),
    ("M09", A + "sf_keystone_cmd.sv", "        end else if (!armed_q) begin\n          done_q <= 1'b1;", "        end else if (1'b0) begin\n          done_q <= 1'b1;", ["sys:boot"],
     "GO accepted without the submission key"),
    ("M10", A + "sf_keystone_mmio.sv", "else if (we && d_acc == KS_ACC_RO)           begin d_ok = 1'b0; d_reason = 3'(KS_BADACC_RO_WRITE); end", "", ["sys:boot", "sys:regs"],
     "writes to read-only registers are not refused"),
    ("M11", A + "sf_keystone_dma_glue.sv", "assign cmd_domain = disp_domain;                   // hardware-bound domain", "assign cmd_domain = disp_arg2[7:4];", ["sys:boot"],
     "DMA domain taken from a software argument instead of the hardware tenant binding"),
    ("M12", A + "sf_keystone_timer.sv", "            rst_req <= rst_en_q;", "            rst_req <= 1'b0;", ["sys:wdt"],
     "watchdog bite does not request a reset"),
    ("M13", A + "sf_keystone_sys.sv", "  assign boot_seq_ev = wr_boot_report && !rep_legal;", "  assign boot_seq_ev = 1'b0;\n  wire unused_mut = rep_legal;", ["sys:boot"],
     "boot-stage order violations are not flagged"),
    ("M14", A + "sf_keystone_host.sv", "    if ((h_is_in || h_is_out || h_is_ctrl || host_addr == KS_H_IRQ_EN) && host_priv < 2'(KS_PRIV_TENANT)) h_priv_ok = 1'b0;", "", ["sys:boot"],
     "a GUEST may use the host mailbox"),
    ("M15", A + "sf_keystone_ras.sv", "any_ue = 1'b1; d_ue = d_ue | !mem_ev_iport[m];", "any_ue = 1'b1; d_ue = 1'b1;", ["sys:boot"],
     "instruction-side ECC errors raise the RAS interrupt class (fetch livelock policy removed)"),
    ("M16", A + "sf_keystone_sys.sv", "if (rep_st == 8'(KS_BSTAT_OK))\n        rep_legal = (bst_q[rep_stage[2:0]] == 8'(KS_BSTAT_RUNNING));", "if (rep_st == 8'(KS_BSTAT_OK))\n        rep_legal = 1'b1;", ["sys:boot"],
     "a stage can be reported OK without having started"),
    ("M17", A + "sf_keystone_engmodel.sv", "else if (q_ten[qid] != disp_tenant) begin d_fail = 1'b1; d_code = 8'd4; d_viol = 1'b1; end", "", ["sys:boot"],
     "queue ownership not enforced (a tenant may ring another tenant's doorbell)"),
]


def run(cmd, timeout=1800):
    return subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)


def check_unit(name):
    spec = {"intc": ("tb_intc", ["rtl/albion/generated/sf_keystone_regs_pkg.sv", "rtl/albion/sf_keystone_interrupts.sv"]),
            "sram_ecc": ("tb_sram_ecc", ["third_party/silicaflux-ras-p26/rtl/sfras_secded_enc.sv", "third_party/silicaflux-ras-p26/rtl/sfras_secded_dec.sv", "rtl/albion/sf_keystone_sram.sv"])}[name]
    top, files = spec
    mdir = f"build/mut/unit_{name}"
    os.makedirs(os.path.join(ROOT, mdir), exist_ok=True)
    b = run(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-WIDTHEXPAND", "-CFLAGS", "-O1",
             "-Ithird_party/silicaflux-ras-p26/rtl", "--top-module", top] + files + [f"tests/keystone/unit/tb_{name}.sv", "-Mdir", mdir, "-o", top])
    if b.returncode:
        return False, "build error (counts as a kill: the mutant is not valid RTL)"
    r = run([f"{mdir}/{top}"])
    m = re.search(r"UNIT (PASS|FAIL)", r.stdout)
    return bool(m and m.group(1) == "PASS"), (m.group(0) if m else "no result")


_sim_ready = {}


def build_sim():
    simdir = "build/mut/sim"
    os.makedirs(os.path.join(ROOT, simdir), exist_ok=True)
    img = "firmware/keystone/build/gnu/rom.bin"
    run([sys.executable, "scripts/mkrom.py", img, f"{simdir}/sf_keystone_bootrom_image.sv"])
    flist = open(os.path.join(ROOT, "rtl/files_sys.f")).read()
    flist = flist.replace("-f rtl/files.f", open(os.path.join(ROOT, "rtl/files.f")).read())
    flist = flist.replace("rtl/albion/generated/sf_keystone_bootrom_image.sv", f"{simdir}/sf_keystone_bootrom_image.sv")
    open(os.path.join(ROOT, simdir, "files.f"), "w").write(flist)
    b = run(["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-WIDTHEXPAND", "--x-assign", "0",
             "--x-initial", "0", "-CFLAGS", "-O1", "-Itests/keystone/sim", "--top-module", "tb_keystone", "-f", f"{simdir}/files.f",
             "tests/keystone/sim/tb_keystone.sv", "-Mdir", f"{simdir}/obj", "-o", "tb_keystone"])
    return b.returncode == 0, f"{simdir}/obj/tb_keystone"


def check_sys(scen):
    if "sim" not in _sim_ready:
        _sim_ready["sim"] = build_sim()                      # one Verilator build per mutant
    ok, exe = _sim_ready["sim"]
    if not ok:
        return False, "build error (counts as a kill)"
    fw = {"boot": "selftest", "wdt": "wdt", "regs": "regs"}[scen]
    r = run([exe, f"+scenario={scen}", f"+fw=firmware/keystone/build/gnu/{fw}/fw_image.hex", "+maxcyc=40000000"])
    m = re.search(r"TB RESULT: (PASS|FAIL) checks=(\d+) errors=(\d+)", r.stdout)
    fails = re.findall(r"(FAIL [^\n]{0,70}|TB FAIL: [^\n]{0,70})", r.stdout)
    return bool(m and m.group(1) == "PASS"), (m.group(0) if m else "no result") + ((" | first: " + fails[0]) if fails else "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    only = set(x for x in a.only.split(",") if x)
    # the baseline must pass first, otherwise "killed" means nothing
    base = []
    for chk in ("unit:intc", "unit:sram_ecc", "sys:boot", "sys:wdt", "sys:regs"):
        kind, nm = chk.split(":")
        ok, d = (check_unit if kind == "unit" else check_sys)(nm)
        base.append((chk, ok, d))
        print(f"baseline {chk:14s} {'PASS' if ok else 'FAIL'}  {d}", flush=True)
    if not all(b[1] for b in base):
        print("baseline is not green: refusing to run the mutation campaign")
        return 2
    rows = []
    for name, fn, old, new, checks, desc in MUTANTS:
        if only and name not in only:
            continue
        path = os.path.join(ROOT, fn)
        orig = open(path).read()
        if orig.count(old) != 1:
            rows.append((name, desc, "NOT APPLICABLE", f"pattern occurs {orig.count(old)}x"))
            print(f"{name}: pattern not found exactly once", flush=True)
            continue
        open(path, "w").write(orig.replace(old, new))
        _sim_ready.clear()
        try:
            killed_by = None
            detail = ""
            for chk in checks:
                kind, nm = chk.split(":")
                ok, d = (check_unit if kind == "unit" else check_sys)(nm)
                if not ok:
                    killed_by, detail = chk, d
                    break
        finally:
            open(path, "w").write(orig)
            _sim_ready.clear()
        rows.append((name, desc, f"KILLED by {killed_by}" if killed_by else "**SURVIVED**", detail))
        print(f"{name}: {'KILLED by ' + killed_by if killed_by else 'SURVIVED'}  ({desc})  {detail[:100]}", flush=True)
    killed = sum(1 for r in rows if r[2].startswith("KILLED"))
    rep = os.path.join(ROOT, "reports", "mutation.md")
    os.makedirs(os.path.dirname(rep), exist_ok=True)
    with open(rep, "w") as f:
        f.write("# Mutation check\n\nEach mutant is a deliberate one-line RTL defect. KILLED = a regression check failed (the defect is detected); "
                "SURVIVED = a test gap.\n\nBaseline (unmutated) checks used: " + ", ".join(b[0] for b in base) + " -- all PASS.\n\n")
        f.write(f"**{killed} / {len(rows)} mutants killed.**\n\n| Mutant | Defect | Result | Evidence |\n|---|---|---|---|\n")
        for n, d, r, e in rows:
            f.write(f"| {n} | {d} | {r} | {e.replace('|', '/')} |\n")
    print(f"\n{killed}/{len(rows)} mutants killed -> reports/mutation.md")
    return 0 if killed == len(rows) else 1


if __name__ == "__main__":
    sys.exit(main())
