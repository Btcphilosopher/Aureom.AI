#!/usr/bin/env python3
"""Prove the vendored SilicaFlux sources are unmodified.

  check_vendor.py                      verify third_party/ against third_party/SHA256SUMS
  check_vendor.py --repo <SilicaFlux-main dir>   ALSO compare every file byte-for-byte with its member in the original archive
  check_vendor.py --write              (re)write SHA256SUMS and PROVENANCE.md (needs --repo)
"""
import argparse, hashlib, os, sys, zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
TP = os.path.join(ROOT, "third_party")
A25 = "SilicaFlux2.0/SilicaFlux2.5/"
# vendored directory -> (archive path inside the repo, member prefix inside the archive)
SOURCES = {
    "silicaflux-mcu-i":      (A25 + "silicaflux-mcu-i.zip",      "silicaflux-mcu-i/"),
    "silicaflux-ras-p26":    (A25 + "silicaflux-ras-project26.zip", "silicaflux-ras/"),
    "silicaflux-clouddma-p64": (A25 + "silicaflux-clouddma-p64.zip", "silicaflux-clouddma-p64/"),
}


def sha(b):
    return hashlib.sha256(b).hexdigest()


def files():
    out = []
    for d, _, fs in os.walk(TP):
        for f in fs:
            if f in ("SHA256SUMS", "PROVENANCE.md"):
                continue
            out.append(os.path.relpath(os.path.join(d, f), TP))
    return sorted(out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo")
    ap.add_argument("--write", action="store_true")
    a = ap.parse_args()
    bad = 0
    rows = []
    zips = {}
    if a.repo:
        for k, (zp, pre) in SOURCES.items():
            full = os.path.join(a.repo, zp)
            zips[k] = (zipfile.ZipFile(full), pre, hashlib.sha256(open(full, "rb").read()).hexdigest(), zp)
    for rel in files():
        data = open(os.path.join(TP, rel), "rb").read()
        top = rel.split(os.sep)[0]
        member = None
        if top in zips:
            z, pre, ahash, zp = zips[top]
            sub = rel.split(os.sep, 1)[1]
            member = pre + sub.replace(os.sep, "/")
            try:
                if z.read(member) != data:
                    print(f"MODIFIED vs archive: {rel}")
                    bad += 1
            except KeyError:
                print(f"not in archive: {rel} ({member})")
                bad += 1
        rows.append((rel, sha(data), member))
    if a.write:
        with open(os.path.join(TP, "SHA256SUMS"), "w") as f:
            for rel, h, _ in rows:
                f.write(f"{h}  {rel}\n")
        with open(os.path.join(TP, "PROVENANCE.md"), "w") as f:
            f.write("# Provenance of `third_party/`\n\n")
            f.write("Every file below is copied **byte-for-byte** from an archive of the repository `btcphilosopher/Aureom.AI` and is **never edited**.\n")
            f.write("`scripts/check_vendor.py --repo <SilicaFlux-main>` re-proves this against the archives; `check_vendor.py` alone checks SHA256SUMS.\n\n")
            f.write("| Vendored tree | Source archive (repository path) | Archive SHA-256 | Why it is here |\n|---|---|---|---|\n")
            why = {"silicaflux-mcu-i": "RV32IM_Zicsr CPU `mcu_cpu` (MCU-I, derived from SilicaFlux-V); the verified CPU Keystone reuses",
                   "silicaflux-ras-p26": "SECDED extended-Hamming encoder / decoder used per byte lane by the local ECC SRAM",
                   "silicaflux-clouddma-p64": "CloudDMA (Project 64): the REAL peripheral configured and driven by the firmware (+ its 2 vendored FIFO / arbiter helpers)"}
            for k, (z, pre, ahash, zp) in zips.items():
                f.write(f"| `{k}/` | `SilicaFlux-main/{zp}` | `{ahash}` | {why[k]} |\n")
            f.write("\n**License:** no license file exists in the repository; none is carried here. An owner must decide before external distribution.\n\n")
            f.write("| File | Archive member | SHA-256 |\n|---|---|---|\n")
            for rel, h, member in rows:
                f.write(f"| `{rel}` | `{member}` | `{h}` |\n")
        print(f"wrote SHA256SUMS and PROVENANCE.md ({len(rows)} files)")
        return 0
    # SHA256SUMS check
    sums = {}
    p = os.path.join(TP, "SHA256SUMS")
    if os.path.exists(p):
        for line in open(p):
            h, rel = line.strip().split("  ", 1)
            sums[rel] = h
        for rel, h, _ in rows:
            if sums.get(rel) != h:
                print(f"hash mismatch / unlisted: {rel}")
                bad += 1
        for rel in sums:
            if rel not in [r[0] for r in rows]:
                print(f"listed but missing: {rel}")
                bad += 1
    else:
        print("SHA256SUMS missing")
        bad += 1
    print(f"vendor check: {len(rows)} files, {'ALL byte-identical' + (' to the repository archives' if zips else '') if not bad else str(bad) + ' PROBLEM(S)'}")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
