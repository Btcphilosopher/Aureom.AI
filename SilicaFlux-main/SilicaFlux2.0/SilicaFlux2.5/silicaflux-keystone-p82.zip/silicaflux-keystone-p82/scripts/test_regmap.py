#!/usr/bin/env python3
"""Tests for the register-map generator/validator: the real map must pass, and every illegal
mutation below must be rejected.  Also checks the generated files are current."""
import copy, os, sys
sys.path.insert(0, os.path.dirname(__file__))
import gen_regs as g

m0 = g.load()
g.validate(m0)                      # the real map must be legal
fails = 0
total = 0


def expect_reject(name, mut):
    global fails, total
    total += 1
    m = copy.deepcopy(m0)
    mut(m)
    try:
        g.validate(m)
    except g.MapError:
        print(f"  ok   reject: {name}")
        return
    except Exception as e:           # a crash is not a rejection
        print(f"  FAIL {name}: validator crashed: {e!r}")
        fails += 1
        return
    print(f"  FAIL {name}: illegal map accepted")
    fails += 1


def blk(m, n):
    return next(b for b in m["blocks"] if b["name"] == n)


def reg(b, n):
    return next(r for r in b["regs"] if r["name"] == n)


expect_reject("duplicate offset in a block", lambda m: reg(blk(m, "SYS"), "VENDOR_ID").__setitem__("ofs", 0x000))
expect_reject("misaligned offset", lambda m: reg(blk(m, "SYS"), "VENDOR_ID").__setitem__("ofs", 0x006))
expect_reject("offset beyond block size", lambda m: reg(blk(m, "SYS"), "VENDOR_ID").__setitem__("ofs", 0x1000))
expect_reject("duplicate register name", lambda m: reg(blk(m, "SYS"), "VENDOR_ID").__setitem__("name", "DEV_ID"))
expect_reject("overlapping blocks", lambda m: blk(m, "TMR").__setitem__("base", 0x40000000))
expect_reject("unaligned block", lambda m: blk(m, "TMR").__setitem__("base", 0x40001800))
expect_reject("block outside MMIO container", lambda m: blk(m, "TMR").__setitem__("base", 0x50000000))
expect_reject("field overlap", lambda m: reg(blk(m, "CMD"), "STATUS")["fields"].append({"name": "X", "lsb": 0, "w": 2}))
expect_reject("field beyond bit 31", lambda m: reg(blk(m, "CMD"), "STATUS")["fields"].append({"name": "X", "lsb": 31, "w": 4}))
expect_reject("bad access type", lambda m: reg(blk(m, "SYS"), "DEV_ID").__setitem__("acc", "rwx"))
expect_reject("rw reset outside mask", lambda m: reg(blk(m, "CMD"), "OP").__setitem__("rst", 0x100))
expect_reject("ro test without reset value", lambda m: reg(blk(m, "SYS"), "SCRATCH0").__setitem__("acc", "ro"))
expect_reject("rw test on a ro register", lambda m: reg(blk(m, "SYS"), "DEV_ID").__setitem__("test", "rw"))
expect_reject("region not power of two", lambda m: m["regions"][1].__setitem__("size", 0x6000))
expect_reject("region unaligned", lambda m: m["regions"][1].__setitem__("base", 0x00104000))
expect_reject("regions overlap", lambda m: m["regions"][2].__setitem__("base", 0x00100000))
expect_reject("engine overlaps a block", lambda m: m["engines"][1].__setitem__("base", 0x40002000))
expect_reject("duplicate engine index", lambda m: m["engines"][1].__setitem__("idx", 0))
expect_reject("engine enum mismatch", lambda m: m["enums"]["KS_ENG"].__setitem__("VIO", 7))
expect_reject("enum duplicate value", lambda m: m["enums"]["KS_IRQ"].__setitem__("PKT", 1))
expect_reject("glue overlapping the shell", lambda m: m["glue"]["DMA"][0].__setitem__("ofs", 0x010))
expect_reject("shell register beyond shell", lambda m: m["engine_shell"]["regs"][0].__setitem__("ofs", 0x200))
expect_reject("host offset misaligned", lambda m: m["host"]["regs"][1].__setitem__("ofs", 0x005))
expect_reject("array overlapping a register", lambda m: reg(blk(m, "INTC"), "COUNT").__setitem__("ofs", 0x020))

# generated files must be current
total += 1
stale = []
for rel, text in g.generate(m0).items():
    p = os.path.join(g.ROOT, rel)
    if not os.path.exists(p) or open(p).read() != text:
        stale.append(rel)
if stale:
    print("  FAIL generated files stale:", stale)
    fails += 1
else:
    print("  ok   generated files are up to date")

print(f"regmap tests: {total - fails}/{total} passed")
sys.exit(1 if fails else 0)
