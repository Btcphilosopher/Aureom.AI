#!/usr/bin/env python3
"""Build the firmware-store image: 32-byte header + payload (CRC32 integrity only -- NOT authentication).

  mkimage.py fw.bin out.bin out.hex --load 0x00100000 [--entry 0x00100000] [--version 0x00010000]

out.hex holds one 32-bit little-endian word per line (header first) for $readmemh of the
firmware-store model.  Header layout: firmware/keystone/include/ks_hal.h (ks_fw_hdr_t).
"""
import argparse, struct, sys, zlib

ap = argparse.ArgumentParser()
ap.add_argument("payload")
ap.add_argument("out_bin")
ap.add_argument("out_hex")
ap.add_argument("--load", type=lambda x: int(x, 0), default=0x00100000)
ap.add_argument("--entry", type=lambda x: int(x, 0), default=None)
ap.add_argument("--version", type=lambda x: int(x, 0), default=0x00010000)
a = ap.parse_args()

pl = open(a.payload, "rb").read()
if len(pl) % 4:
    pl += b"\0" * (4 - len(pl) % 4)
entry = a.load if a.entry is None else a.entry
hdr7 = struct.pack("<7I", 0x5746534B, 1, a.load, len(pl), entry, a.version, zlib.crc32(pl) & 0xFFFFFFFF)
hdr = hdr7 + struct.pack("<I", zlib.crc32(hdr7[:28]) & 0xFFFFFFFF)
img = hdr + pl
open(a.out_bin, "wb").write(img)
words = struct.unpack("<%dI" % (len(img) // 4), img)
open(a.out_hex, "w").write("\n".join(f"{w:08x}" for w in words) + "\n")
print(f"{a.out_bin}: payload {len(pl)} bytes, crc32 {zlib.crc32(pl) & 0xFFFFFFFF:08x}, load {a.load:#x}, entry {entry:#x}")
