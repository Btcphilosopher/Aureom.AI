#!/usr/bin/env python3
"""Keystone register-map generator and validator.

Reads config/keystone_regs.yaml (single source of truth) and writes
  rtl/albion/generated/sf_keystone_regs_pkg.sv
  firmware/keystone/include/generated/keystone_regs.h
  firmware/keystone/common/ks_mem_rom.ld, ks_mem_fw.ld
  tests/keystone/sim/ks_regtest_tbl.svh
  docs/keystone/MEMORY_MAP.md, docs/keystone/REGISTER_MAP.md

  gen_regs.py            regenerate
  gen_regs.py --check    fail if any generated file is stale or the map is illegal
"""
import argparse, copy, os, sys
import yaml

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
YAML = os.path.join(ROOT, "config", "keystone_regs.yaml")

OUT = {
    "pkg":   "rtl/albion/generated/sf_keystone_regs_pkg.sv",
    "hdr":   "firmware/keystone/include/generated/keystone_regs.h",
    "ldrom": "firmware/keystone/common/ks_mem_rom.ld",
    "ldfw":  "firmware/keystone/common/ks_mem_fw.ld",
    "rtbl":  "tests/keystone/sim/ks_regtest_tbl.svh",
    "ctbl":  "firmware/keystone/app/generated/ks_regtest_tbl.h",
    "memmd": "docs/keystone/MEMORY_MAP.md",
    "regmd": "docs/keystone/REGISTER_MAP.md",
}

ACC_CLASS = {"ro": 1, "rw": 2, "w1c": 2, "w1s": 2, "rc": 2, "wo": 3}   # 0 = unmapped
ACC_NAME = {0: "NONE", 1: "RO", 2: "RW", 3: "WO"}


class MapError(Exception):
    pass


# ----------------------------------------------------------------------------- model helpers
def load(path=YAML):
    with open(path) as f:
        return yaml.safe_load(f)


def expand(regs):
    """Expand array registers -> flat list of (name, off, reg-dict)."""
    out = []
    for r in regs:
        arr = r.get("array")
        if arr:
            for k in range(arr["count"]):
                idx = arr.get("first", 0) + k
                out.append((f"{r['name']}_{idx}", r["ofs"] + arr["stride"] * idx, r, idx))
        else:
            out.append((r["name"], r["ofs"], r, None))
    return out


def all_engine_regs(m, eng):
    """Shell + glue registers of one engine as flat list."""
    regs = expand(m["engine_shell"]["regs"])
    regs += expand(m.get("glue", {}).get(eng["name"], []))
    return regs


# ----------------------------------------------------------------------------- validation
def validate(m):
    errs = []

    def err(msg):
        errs.append(msg)

    # --- regions
    names = set()
    spans = []
    containers = []
    for r in m["regions"]:
        if r["name"] in names:
            err(f"duplicate region {r['name']}")
        names.add(r["name"])
        if r["size"] & (r["size"] - 1) or r["size"] == 0:
            err(f"region {r['name']}: size 0x{r['size']:x} is not a power of two")
        if r["base"] % r["size"]:
            err(f"region {r['name']}: base 0x{r['base']:08x} not aligned to its size")
        if r["base"] + r["size"] > 1 << 32:
            err(f"region {r['name']}: exceeds 32-bit space")
        if r.get("container"):
            containers.append((r["base"], r["base"] + r["size"]))
        else:
            spans.append((r["base"], r["base"] + r["size"], f"region {r['name']}"))

    def inside(lo, hi, what):
        if not any(c0 <= lo and hi <= c1 for c0, c1 in containers):
            err(f"{what} [{lo:#x},{hi:#x}) is not inside the MMIO container region")

    # --- blocks
    bnames = set()
    for b in m["blocks"]:
        if b["name"] in bnames:
            err(f"duplicate block {b['name']}")
        bnames.add(b["name"])
        if b["base"] % b["size"] or b["size"] & (b["size"] - 1):
            err(f"block {b['name']}: base/size not aligned / power of two")
        _check_regs(b["name"], expand(b["regs"]), b["size"], err)
        inside(b["base"], b["base"] + b["size"], f"block {b['name']}")
        spans.append((b["base"], b["base"] + b["size"], f"block {b['name']}"))
    # --- engines
    enames = set()
    idxs = set()
    for e in m["engines"]:
        if e["name"] in enames or e["idx"] in idxs:
            err(f"duplicate engine {e['name']}/{e['idx']}")
        enames.add(e["name"])
        idxs.add(e["idx"])
        if e["base"] % e["size"] or e["size"] & (e["size"] - 1):
            err(f"engine {e['name']}: base/size not aligned / power of two")
        spans.append((e["base"], e["base"] + e["size"], f"engine {e['name']}"))
        inside(e["base"], e["base"] + e["size"], f"engine {e['name']}")
        regs = all_engine_regs(m, e)
        _check_regs(f"engine {e['name']}", regs, e["size"], err)
        for n, off, r, _ in expand(m["engine_shell"]["regs"]):
            if off >= m["engine_shell"]["size"]:
                err(f"engine shell register {n} beyond shell size")
        for n, off, r, _ in expand(m.get("glue", {}).get(e["name"], [])):
            if off < m["engine_shell"]["size"]:
                err(f"engine {e['name']} glue register {n} overlaps the shell")
    if sorted(idxs) != list(range(len(idxs))):
        err("engine indices must be 0..N-1")
    # --- host space
    _check_regs("host", expand(m["host"]["regs"]), 0x10000, err)

    # --- overlaps between all spans
    spans.sort()
    for (a0, a1, an), (b0, b1, bn) in zip(spans, spans[1:]):
        if b0 < a1:
            err(f"address overlap: {an} [{a0:#x},{a1:#x}) and {bn} [{b0:#x},{b1:#x})")

    # --- enums
    for ename, vals in m["enums"].items():
        seen = {}
        for k, v in vals.items():
            if v in seen and ename not in ("KS_BSTAT",):
                err(f"enum {ename}: value {v} used by {seen[v]} and {k}")
            seen[v] = k
    if m["enums"]["KS_ENG"] != {e["name"]: e["idx"] for e in m["engines"]}:
        err("KS_ENG enum disagrees with engines list")
    if errs:
        raise MapError("\n".join(errs))


def _check_regs(owner, regs, size, err):
    used = {}
    names = set()
    for name, off, r, _ in regs:
        if name in names:
            err(f"{owner}: duplicate register {name}")
        names.add(name)
        if off % 4:
            err(f"{owner}.{name}: offset 0x{off:x} not word aligned")
        if off + 4 > size:
            err(f"{owner}.{name}: offset 0x{off:x} beyond size 0x{size:x}")
        if off in used:
            err(f"{owner}.{name}: offset 0x{off:x} already used by {used[off]}")
        used[off] = name
        if r["acc"] not in ACC_CLASS:
            err(f"{owner}.{name}: bad access type {r['acc']}")
        mask = r.get("mask", 0xFFFFFFFF)
        rst = r.get("rst", 0)
        if not (0 <= rst < 1 << 32) or not (0 <= mask < 1 << 32):
            err(f"{owner}.{name}: rst/mask out of 32-bit range")
        if r["acc"] == "rw" and r.get("test") == "rw" and "rst" in r and (rst & ~mask & 0xFFFFFFFF):
            err(f"{owner}.{name}: reset value 0x{rst:x} has bits outside mask 0x{mask:x}")
        if r.get("test") not in ("rw", "ro", "skip"):
            err(f"{owner}.{name}: test must be rw|ro|skip")
        if r.get("test") == "rw" and r["acc"] != "rw":
            err(f"{owner}.{name}: test rw needs acc rw")
        if r.get("test") == "ro" and "rst" not in r:
            err(f"{owner}.{name}: test ro needs a reset value")
        bits = 0
        for f in r.get("fields", []):
            if f["lsb"] < 0 or f["w"] < 1 or f["lsb"] + f["w"] > 32:
                err(f"{owner}.{name}.{f['name']}: field outside 32 bits")
                continue
            fm = ((1 << f["w"]) - 1) << f["lsb"]
            if bits & fm:
                err(f"{owner}.{name}.{f['name']}: overlaps another field")
            bits |= fm
    return used


# ----------------------------------------------------------------------------- generation
def hx(v, w=8):
    return f"{v:0{w}x}"


def sv_pkg(m):
    L = []
    a = L.append
    a("// =============================================================================")
    a("// GENERATED by scripts/gen_regs.py from config/keystone_regs.yaml -- DO NOT EDIT")
    a(f"// Keystone register map version {m['version']['major']}.{m['version']['minor']}")
    a("// =============================================================================")
    a("`default_nettype none")
    a("package sf_keystone_regs_pkg;")
    a("  /* verilator lint_off UNUSEDPARAM */")
    a(f"  localparam int KS_MAP_VERSION_MAJOR = {m['version']['major']};")
    a(f"  localparam int KS_MAP_VERSION_MINOR = {m['version']['minor']};")
    a("")
    a("  // access classes returned by the ks_acc_* functions")
    a("  localparam logic [1:0] KS_ACC_NONE = 2'd0;   // unmapped -> bus error")
    a("  localparam logic [1:0] KS_ACC_RO   = 2'd1;   // write -> bus error")
    a("  localparam logic [1:0] KS_ACC_RW   = 2'd2;")
    a("  localparam logic [1:0] KS_ACC_WO   = 2'd3;   // read returns 0")
    a("")
    a("  // ---- memory regions")
    for r in m["regions"]:
        a(f"  localparam logic [31:0] KS_{r['name']}_BASE = 32'h{hx(r['base'])};")
        a(f"  localparam logic [31:0] KS_{r['name']}_SIZE = 32'h{hx(r['size'])};")
    a("")
    a("  // ---- enumerations")
    for en, vals in m["enums"].items():
        for k, v in vals.items():
            a(f"  localparam int {en}_{k} = {v};")
    a(f"  localparam int KS_NUM_ENG = {len(m['engines'])};")
    a(f"  localparam int KS_NUM_IRQ = {max(m['enums']['KS_IRQ'].values())};")
    a("")
    a("  // ---- magic values")
    a("  localparam logic [31:0] KS_KEY_CMD   = 32'h4B455953;  // 'KEYS'  CMD.KEY")
    a("  localparam logic [31:0] KS_KEY_WDT   = 32'h4B49434B;  // 'KICK'  WDT.KICK")
    a("  localparam logic [15:0] KS_KEY_RESET = 16'hB007;      //         SYS.RESET_CTRL.KEY")
    a("  localparam logic [31:0] KS_FW_MAGIC  = 32'h5746534B;  // 'KSFW'  firmware image header")
    a("")

    def emit_regs(prefix, regs, offw=16):
        for name, off, r, idx in regs:
            a(f"  localparam logic [{offw-1}:0] {prefix}_{name} = {offw}'h{off:0{offw//4}x};")
            if "rst" in r:
                a(f"  localparam logic [31:0] {prefix}_{name}_RST = 32'h{hx(r['rst'])};")
            if idx is None:
                for f in r.get("fields", []):
                    a(f"  localparam int {prefix}_{name}_{f['name']}_LSB = {f['lsb']};")
                    a(f"  localparam int {prefix}_{name}_{f['name']}_W = {f['w']};")

    for b in m["blocks"]:
        a(f"  // ---- block {b['name']}: {b['desc']}")
        a(f"  localparam logic [31:0] KS_{b['name']}_BASE = 32'h{hx(b['base'])};")
        a(f"  localparam logic [31:0] KS_{b['name']}_SIZE = 32'h{hx(b['size'])};")
        emit_regs(f"KS_{b['name']}", expand(b["regs"]))
        a("")
    a("  // ---- engine windows")
    for e in m["engines"]:
        a(f"  localparam logic [31:0] KS_{e['name']}_BASE = 32'h{hx(e['base'])};")
        a(f"  localparam logic [31:0] KS_{e['name']}_SIZE = 32'h{hx(e['size'])};")
        a(f"  localparam logic [31:0] KS_{e['name']}_ID   = 32'h{hx(e['id'])};")
    for fn, key in (("ks_eng_base", "base"), ("ks_eng_id", "id")):
        a(f"  function automatic logic [31:0] {fn}(input int e);")
        a("    case (e)")
        for e in m["engines"]:
            a(f"      {e['idx']}: {fn} = 32'h{hx(e[key])};")
        a(f"      default: {fn} = 32'h0;")
        a("    endcase")
        a("  endfunction")
    a(f"  localparam logic [15:0] KS_ESH_SIZE = 16'h{m['engine_shell']['size']:04x};")
    a("  localparam logic [15:0] KS_ENG_PASS_OFF = 16'h1000;   // engine register page pass-through")
    emit_regs("KS_ESH", expand(m["engine_shell"]["regs"]))
    for e in m["engines"]:
        g = m.get("glue", {}).get(e["name"])
        if g:
            emit_regs(f"KS_{e['name']}", expand(g))
    a("")
    a("  // ---- host management port")
    emit_regs("KS_H", expand(m["host"]["regs"]))
    a("")

    def acc_fn(fname, regs, offw):
        a(f"  function automatic logic [1:0] {fname}(input logic [{offw-1}:0] off);")
        a("    case (off)")
        for name, off, r, _ in regs:
            a(f"      {offw}'h{off:0{offw//4}x}: {fname} = KS_ACC_{ACC_NAME[ACC_CLASS[r['acc']]]};")
        a(f"      default: {fname} = KS_ACC_NONE;")
        a("    endcase")
        a("  endfunction")

    for b in m["blocks"]:
        acc_fn(f"ks_acc_{b['name'].lower()}", expand(b["regs"]), 16)
    acc_fn("ks_acc_esh", expand(m["engine_shell"]["regs"]), 16)
    acc_fn("ks_acc_host", expand(m["host"]["regs"]), 16)
    a("  /* verilator lint_on UNUSEDPARAM */")
    a("endpackage")
    a("`default_nettype wire")
    return "\n".join(L) + "\n"


def c_hdr(m):
    L = []
    a = L.append
    a("/* GENERATED by scripts/gen_regs.py from config/keystone_regs.yaml -- DO NOT EDIT */")
    a(f"/* Keystone register map version {m['version']['major']}.{m['version']['minor']} */")
    a("#ifndef KEYSTONE_REGS_H")
    a("#define KEYSTONE_REGS_H")
    a("")
    a("/* usable from C and from assembly (.S): integer-suffix macro */")
    a("#ifdef __ASSEMBLER__")
    a("#define KS_U(x) x")
    a("#else")
    a("#define KS_U(x) x##u")
    a("#endif")
    a("")
    a(f"#define KS_MAP_VERSION_MAJOR {m['version']['major']}u")
    a(f"#define KS_MAP_VERSION_MINOR {m['version']['minor']}u")
    a("")
    a("/* ---- memory regions */")
    for r in m["regions"]:
        a(f"#define KS_{r['name']}_BASE 0x{hx(r['base'])}u")
        a(f"#define KS_{r['name']}_SIZE 0x{hx(r['size'])}u")
    a("")
    a("/* ---- enumerations */")
    for en, vals in m["enums"].items():
        for k, v in vals.items():
            a(f"#define {en}_{k} {v}u")
    a(f"#define KS_NUM_ENG {len(m['engines'])}u")
    a(f"#define KS_NUM_IRQ {max(m['enums']['KS_IRQ'].values())}u")
    a("")
    a("#define KS_KEY_CMD   0x4B455953u /* 'KEYS' */")
    a("#define KS_KEY_WDT   0x4B49434Bu /* 'KICK' */")
    a("#define KS_KEY_RESET 0xB007u")
    a("#define KS_FW_MAGIC  0x5746534Bu /* 'KSFW' */")
    a("")

    def emit(prefix, base_expr, regs):
        done_arr = set()
        for name, off, r, idx in regs:
            if idx is None:
                a(f"#define {prefix}_{name} ({base_expr} + 0x{off:x}u)")
                if "rst" in r:
                    a(f"#define {prefix}_{name}_RST 0x{hx(r['rst'])}u")
                for f in r.get("fields", []):
                    mk = ((1 << f["w"]) - 1) << f["lsb"]
                    a(f"#define {prefix}_{name}_{f['name']}_SHIFT {f['lsb']}u")
                    a(f"#define {prefix}_{name}_{f['name']}_MASK 0x{hx(mk)}u")
            else:
                arr = r["array"]
                if r["name"] in done_arr:
                    continue
                done_arr.add(r["name"])
                a(f"#define {prefix}_{r['name']}(n) ({base_expr} + 0x{r['ofs']:x}u + {arr['stride']}u * (n))")
                if "rst" in r:
                    a(f"#define {prefix}_{r['name']}_RST 0x{hx(r['rst'])}u")
                for f in r.get("fields", []):
                    mk = ((1 << f["w"]) - 1) << f["lsb"]
                    a(f"#define {prefix}_{r['name']}_{f['name']}_SHIFT {f['lsb']}u")
                    a(f"#define {prefix}_{r['name']}_{f['name']}_MASK 0x{hx(mk)}u")

    for b in m["blocks"]:
        a(f"/* ---- {b['name']}: {b['desc']} */")
        a(f"#define KS_{b['name']}_BASE 0x{hx(b['base'])}u")
        emit(f"KS_{b['name']}", f"KS_{b['name']}_BASE", expand(b["regs"]))
        a("")
    a("/* ---- engine windows (64 KiB each): shell @+0x000, glue @+0x100, engine page @+0x1000 */")
    for e in m["engines"]:
        a(f"#define KS_{e['name']}_BASE 0x{hx(e['base'])}u")
        a(f"#define KS_{e['name']}_ID   0x{hx(e['id'])}u")
    a("#define KS_ENG_BASE(e) (0x40010000u + 0x10000u * (e))")
    a("#define KS_ENG_PASS_OFF 0x1000u")
    a("/* common shell, per engine: KS_ESH(e, REG) e.g. KS_ESH(KS_ENG_DMA, KS_ESH_IRQ_STAT) -- the REG macros below are offsets */")
    a("#define KS_ESH(e, off) (KS_ENG_BASE(e) + (off))")
    for name, off, r, idx in expand(m["engine_shell"]["regs"]):
        a(f"#define KS_ESH_{name} 0x{off:x}u")
        for f in r.get("fields", []):
            mk = ((1 << f["w"]) - 1) << f["lsb"]
            a(f"#define KS_ESH_{name}_{f['name']}_SHIFT {f['lsb']}u")
            a(f"#define KS_ESH_{name}_{f['name']}_MASK 0x{hx(mk)}u")
        if "rst" in r:
            a(f"#define KS_ESH_{name}_RST 0x{hx(r['rst'])}u")
    a("")
    for e in m["engines"]:
        g = m.get("glue", {}).get(e["name"])
        if g:
            a(f"/* ---- {e['name']} glue registers (absolute addresses) */")
            emit(f"KS_{e['name']}", f"KS_{e['name']}_BASE", expand(g))
            a("")
    a("/* ---- host management port offsets (host_addr[15:0]) */")
    for name, off, r, idx in expand(m["host"]["regs"]):
        a(f"#define KS_H_{name} 0x{off:x}u")
    for r in m["host"]["regs"]:
        for f in r.get("fields", []):
            mk = ((1 << f["w"]) - 1) << f["lsb"]
            a(f"#define KS_H_{r['name']}_{f['name']}_SHIFT {f['lsb']}u")
            a(f"#define KS_H_{r['name']}_{f['name']}_MASK 0x{hx(mk)}u")
    a("")
    a("#endif /* KEYSTONE_REGS_H */")
    import re
    body = "\n".join(L) + "\n"
    head, sep, tail = body.partition("/* ---- memory regions */")
    tail = re.sub(r"\b(0x[0-9a-fA-F]+|[0-9]+)u\b", r"KS_U(\1)", tail)
    return head + sep + tail


def ld_files(m):
    R = {r["name"]: r for r in m["regions"]}
    hdr = "/* GENERATED by scripts/gen_regs.py -- DO NOT EDIT */\n"

    def mem(name, attr, r):
        return f"  {name:5s} ({attr}) : ORIGIN = 0x{r['base']:08x}, LENGTH = 0x{r['size']:x}\n"

    rom = hdr + "MEMORY\n{\n" + mem("BROM", "rx", R["BROM"]) + mem("DRAM", "rw", R["DRAM"]) + mem("SHM", "rw", R["SHM"]) + "}\n"
    fw = hdr + "MEMORY\n{\n" + mem("IRAM", "rwx", R["IRAM"]) + mem("DRAM", "rw", R["DRAM"]) + mem("SHM", "rw", R["SHM"]) + "}\n"
    return rom, fw


def rtl_table(m):
    L = []
    a = L.append
    a("// GENERATED by scripts/gen_regs.py -- DO NOT EDIT. Included inside a testbench task body.")
    a("// rt_add(addr, kind, acc, reset, mask, name)   kind: 0 skip 1 ro 2 rw ; acc: 1 ro 2 rw 3 wo")
    a("// ht_add(...) the same for the host port (offset only)")
    KIND = {"skip": 0, "ro": 1, "rw": 2}

    def lines(fn, base, regs, id_override=None):
        for name, off, r, idx in regs:
            if r.get("test", "skip") == "skip":
                continue
            rst = r.get("rst", 0)
            if id_override is not None and name == "ID":
                rst = id_override
            a(f'    {fn}(32\'h{hx(base+off)}, {KIND[r["test"]]}, {ACC_CLASS[r["acc"]]}, 32\'h{hx(rst)}, 32\'h{hx(r.get("mask", 0xFFFFFFFF))}, "{name}");')

    for b in m["blocks"]:
        a(f"    // {b['name']}")
        lines("rt_add", b["base"], expand(b["regs"]))
    for e in m["engines"]:
        a(f"    // engine {e['name']} shell + glue")
        lines("rt_add", e["base"], expand(m["engine_shell"]["regs"]), id_override=e["id"])
        lines("rt_add", e["base"], expand(m.get("glue", {}).get(e["name"], [])))
    a("    // host")
    lines("ht_add", 0, expand(m["host"]["regs"]))
    return "\n".join(L) + "\n"


def c_regtest(m):
    """C tables for the firmware register walker (scenario regs): testable registers and, per block, the mapped offsets."""
    L = ["/* GENERATED by scripts/gen_regs.py -- DO NOT EDIT */", "#ifndef KS_REGTEST_TBL_H", "#define KS_REGTEST_TBL_H", "#include <stdint.h>", "",
         "typedef struct { uint32_t addr, kind, acc, rst, mask, vol; } ks_rt_t;   /* kind: 1 ro, 2 rw ; acc: 1 ro, 2 rw, 3 wo ; vol: changes as a side effect of bus errors */",
         "static const ks_rt_t ks_rt[] = {"]
    KIND = {"ro": 1, "rw": 2}
    n = 0

    def add(base, regs, id_override=None):
        nonlocal n
        for name, off, r, idx in regs:
            if r.get("test", "skip") == "skip":
                continue
            rst = r.get("rst", 0)
            if id_override is not None and name == "ID":
                rst = id_override
            L.append(f"    {{0x{hx(base+off)}u, {KIND[r['test']]}, {ACC_CLASS[r['acc']]}, 0x{hx(rst)}u, 0x{hx(r.get('mask', 0xFFFFFFFF))}u, {1 if r.get('vol') else 0}}},   /* {name} */")
            n += 1

    for b in m["blocks"]:
        add(b["base"], expand(b["regs"]))
    for e in m["engines"]:
        add(e["base"], expand(m["engine_shell"]["regs"]), id_override=e["id"])
        add(e["base"], expand(m.get("glue", {}).get(e["name"], [])))
    L.append("};")
    L.append(f"#define KS_RT_N {n}u")
    L.append("")
    L.append("/* mapped word offsets below 0x100 of each 4 KiB block (everything else in 0x000..0x0FF must fault) */")
    L.append("typedef struct { uint32_t base; const uint16_t *mapped; uint32_t n; } ks_mapped_t;")
    entries = []
    for b in m["blocks"]:
        offs = sorted({off for _, off, r, _ in expand(b["regs"]) if off < 0x100})
        L.append(f"static const uint16_t ks_mapped_{b['name'].lower()}[] = {{" + ", ".join(f"0x{o:03x}" for o in offs) + "};")
        entries.append(f"    {{0x{hx(b['base'])}u, ks_mapped_{b['name'].lower()}, {len(offs)}u}},")
    offs = sorted({off for _, off, r, _ in expand(m["engine_shell"]["regs"])})
    L.append("static const uint16_t ks_mapped_esh[] = {" + ", ".join(f"0x{o:03x}" for o in offs) + "};")
    for e in m["engines"]:
        entries.append(f"    {{0x{hx(e['base'])}u, ks_mapped_esh, {len(offs)}u}},")
    L.append("static const ks_mapped_t ks_mapped[] = {")
    L += entries
    L.append("};")
    L.append(f"#define KS_MAPPED_N {len(entries)}u")
    L.append("#endif")
    return "\n".join(L) + "\n"


def md_memory(m):
    L = ["# Keystone memory map", "", "_Generated by `scripts/gen_regs.py` from `config/keystone_regs.yaml`. Do not edit._", ""]
    L += ["## CPU address space regions", "", "| Region | Base | Size | Attr | Description |", "|---|---|---|---|---|"]
    for r in m["regions"]:
        L.append(f"| {r['name']} | `0x{hx(r['base'])}` | {r['size']//1024} KiB | {r['attr']} | {r['desc']} |")
    L += ["", "## MMIO blocks", "", "| Block | Base | Size | Description |", "|---|---|---|---|"]
    for b in m["blocks"]:
        L.append(f"| {b['name']} | `0x{hx(b['base'])}` | {b['size']//1024} KiB | {b['desc']} |")
    L += ["", "## Engine windows (64 KiB each)", "", "| Engine | Index | Base | ESH_ID | Implementation | Description |", "|---|---|---|---|---|---|"]
    for e in m["engines"]:
        L.append(f"| {e['name']} | {e['idx']} | `0x{hx(e['base'])}` | `0x{hx(e['id'])}` | {'REAL' if e['real'] else 'model/absent'} | {e['desc']} |")
    L += ["", "Window layout: `+0x000..0x0FF` common shell (inside Keystone), `+0x100..0xFFF` engine glue registers, `+0x1000..0xFFFF` pass-through to the engine's own register page. Offsets beyond what the engine implements return a bus error.", ""]
    L += ["## Interrupt sources", "", "| Id | Source |", "|---|---|"] + [f"| {v} | {k} |" for k, v in sorted(m["enums"]["KS_IRQ"].items(), key=lambda kv: kv[1])]
    return "\n".join(L) + "\n"


def md_regs(m):
    L = ["# Keystone register reference", "", "_Generated by `scripts/gen_regs.py` from `config/keystone_regs.yaml`. Do not edit._", "",
         "Access: `ro` read-only; `rw` read/write; `w1c`/`w1s` write-1-to-clear/set; `wo` write-only (reads 0); `rc` read has side effect. MMIO is word oriented: registers are 32-bit and word aligned. Unmapped offsets, writes to read-only registers and byte/halfword **stores** return a bus error (load/store access fault; `BAD_ADDR`/`BAD_INFO` record the access) and change nothing. **Byte/halfword loads cannot be told apart from word loads at the bus** (the reused CPU always requests a full word for loads, `d_be = 4'hF`), so they behave as a word read and extract the lane: firmware must use 32-bit accesses, in particular never a sub-word load of a read-clear register (`INTC.CLAIM`).", ""]

    def table(title, base_txt, regs):
        L.append(f"## {title}")
        L.append("")
        L.append(f"Base: {base_txt}")
        L.append("")
        L.append("| Offset | Name | Acc | Reset | Description |")
        L.append("|---|---|---|---|---|")
        seen = set()
        for r in regs:
            arr = r.get("array")
            if arr:
                f0 = arr.get("first", 0)
                lo = r["ofs"] + arr["stride"] * f0; hi = r["ofs"] + arr["stride"] * (f0 + arr["count"] - 1)
                nm = f"{r['name']}[{arr.get('first',0)}..{arr.get('first',0)+arr['count']-1}]"
                off = f"`0x{lo:03x}`..`0x{hi:03x}`"
            else:
                nm = r["name"]
                off = f"`0x{r['ofs']:03x}`"
            rst = f"`0x{hx(r['rst'])}`" if "rst" in r else "-"
            L.append(f"| {off} | **{nm}** | {r['acc']} | {rst} | {r['desc']} |")
            for f in r.get("fields", []):
                rng = f"[{f['lsb']+f['w']-1}:{f['lsb']}]" if f["w"] > 1 else f"[{f['lsb']}]"
                L.append(f"| | &nbsp;&nbsp;{f['name']} | | {rng} | |")
        L.append("")

    for b in m["blocks"]:
        table(f"{b['name']}", f"`0x{hx(b['base'])}` ({b['desc']})", b["regs"])
    table("Engine common shell (offset within each engine window)", "engine window base", m["engine_shell"]["regs"])
    for e in m["engines"]:
        g = m.get("glue", {}).get(e["name"])
        if g:
            table(f"{e['name']} glue registers", f"`0x{hx(e['base'])}` (offsets within the window)", g)
    table("Host management port (`host_addr[15:0]`)", "separate address space", m["host"]["regs"])
    L.append("## Enumerations")
    L.append("")
    for en, vals in m["enums"].items():
        L.append(f"**{en}**: " + ", ".join(f"`{k}`={v if v < 16 else hex(v)}" for k, v in vals.items()))
        L.append("")
    return "\n".join(L) + "\n"


def generate(m):
    rom, fw = ld_files(m)
    return {
        OUT["pkg"]: sv_pkg(m), OUT["hdr"]: c_hdr(m), OUT["ldrom"]: rom, OUT["ldfw"]: fw,
        OUT["rtbl"]: rtl_table(m), OUT["ctbl"]: c_regtest(m), OUT["memmd"]: md_memory(m), OUT["regmd"]: md_regs(m),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--yaml", default=YAML)
    args = ap.parse_args()
    m = load(args.yaml)
    try:
        validate(m)
    except MapError as e:
        print("register map INVALID:\n" + str(e), file=sys.stderr)
        return 2
    outs = generate(m)
    bad = 0
    for rel, text in outs.items():
        p = os.path.join(ROOT, rel)
        if args.check:
            cur = open(p).read() if os.path.exists(p) else None
            if cur != text:
                print(f"STALE: {rel}")
                bad += 1
        else:
            os.makedirs(os.path.dirname(p), exist_ok=True)
            with open(p, "w") as f:
                f.write(text)
            print(f"wrote {rel}")
    if args.check:
        print("register map OK, generated files up to date" if not bad else f"{bad} generated file(s) stale: run make regs")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
