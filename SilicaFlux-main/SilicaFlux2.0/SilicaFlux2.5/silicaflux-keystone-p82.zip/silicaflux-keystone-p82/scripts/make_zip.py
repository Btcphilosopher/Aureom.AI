#!/usr/bin/env python3
"""Package the deliverable zip (sources, firmware, tests, docs, reports) -- never build outputs.  Nothing is committed anywhere."""
import os, sys, zipfile, hashlib

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
NAME = "silicaflux-keystone-p82"
OUT = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(ROOT), f"{NAME}.zip")
SKIP_DIRS = {"build", "__pycache__", ".git", "obj_dir"}
SKIP_SUFFIX = (".o", ".d", ".pyc", ".elf", ".map")
files = []
for d, dirs, fs in os.walk(ROOT):
    dirs[:] = sorted(x for x in dirs if x not in SKIP_DIRS)
    for f in sorted(fs):
        if f.endswith(SKIP_SUFFIX) or f in (".DS_Store",):
            continue
        files.append(os.path.join(d, f))
manifest = []
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files:
        rel = os.path.relpath(p, ROOT)
        data = open(p, "rb").read()
        manifest.append(f"{hashlib.sha256(data).hexdigest()}  {rel}")
        zi = zipfile.ZipInfo(f"{NAME}/{rel}", date_time=(2026, 11, 15, 0, 0, 0))
        zi.compress_type = zipfile.ZIP_DEFLATED
        zi.external_attr = (0o755 if os.access(p, os.X_OK) else 0o644) << 16
        z.writestr(zi, data)
    z.writestr(f"{NAME}/MANIFEST.sha256", "\n".join(manifest) + "\n")
print(f"{OUT}: {len(files)} files + MANIFEST.sha256, {os.path.getsize(OUT)//1024} KiB")
