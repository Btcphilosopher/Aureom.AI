# 01 — Architecture

Keystone is the embedded control subsystem of the SilicaFlux Albion cloud device. It boots the device, executes management firmware,
configures the cloud engines, runs a protected management command engine, takes interrupts and exposes a **safe, register-level host
management interface**. It is **not** a Linux application CPU: machine mode only, no MMU, no caches, no user mode, no PMP.

```
                    host management port (register level, host_priv asserted by the platform)
                                   │  identity / boot status / mailbox / reset request
 firmware store ──(read-only)──┐   ▼
 (external boot flash)         │ ┌──────────┐
                               ▼ │  HOST    │──INTC.HOST        ┌────────── engine windows (64 KiB each) ──────────┐
      ┌──────┐  I  ┌────────┐   │ │ mailbox  │                   │ DMA  PKT  MPL  CPW  VIO                          │
      │ BROM │◄────│        │   │ └──────────┘                   │ shell(+0x000) glue(+0x100) engine page(+0x1000)  │
      │ 8 KiB│     │ I/D    │   │                                └───▲──────────────────────────────┬───────────────┘
      └──────┘     │ fabric │   │   ┌─────────┐  rb strobes        │ eng_req/rvalid               │ dispatch (1 command)
      ┌──────┐     │        │◄──┘   │  MMIO   │──► SYS TMR INTC WDT CMD RAS TEL MBX + 5 engine shells
      │ IRAM │◄───►│        │──────►│ bridge  │──────────────────────┘                              ▼
      │32 KiB│ECC  │ mcu_cpu│  D    └─────────┘                                         ┌─────────────────────┐
      ├──────┤     │RV32IM  │                                                           │ command engine (CMD)│
      │ DRAM │◄───►│Zicsr   │──irq_ext(INTC) irq_timer irq_soft (TMR)                   │ key • validate •    │
      │16 KiB│ECC  └────────┘                                                           │ privilege • tenant  │
      ├──────┤                                                                          │ dispatch • timeout  │
      │ SHM  │◄─── AXI4 slave (64-bit) ◄──── CloudDMA memory master (REAL, P64)         └─────────────────────┘
      │16 KiB│
      └──────┘
```

## 1. Files

| Block | File | Notes |
|---|---|---|
| Top | `rtl/albion/sf_keystone_control.sv` | CPU wrapper, I/D fabric, wiring, interrupt routing |
| CPU | `third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv` | reused unmodified |
| Boot ROM | `sf_keystone_bootrom.sv` + generated `generated/sf_keystone_bootrom_image.sv` | image built from `firmware/keystone/bootrom` by `scripts/mkrom.py` |
| Local SRAM | `sf_keystone_sram.sv` | SECDED (13,8) per byte lane, init sweep, I/D arbitration, fault injection |
| Shared buffer | `sf_keystone_shm.sv` | CPU port + AXI4 slave port, round-robin, no ECC |
| MMIO bridge | `sf_keystone_mmio.sv` | access checks from the generated tables |
| System block | `sf_keystone_sys.sv` | identity, caps, boot status, reset network, power, security status |
| Timer / watchdog | `sf_keystone_timer.sv` | `sf_keystone_timer` + `sf_keystone_wdt` |
| Interrupt controller | `sf_keystone_interrupts.sv` | 10 sources, priority, claim / complete |
| Command engine | `sf_keystone_cmd.sv` | protected, one command at a time |
| RAS / telemetry | `sf_keystone_ras.sv`, `sf_keystone_tel.sv` | |
| Host port | `sf_keystone_host.sv` | mailbox + read-only status view |
| Engine shell | `sf_keystone_engshell.sv` | common view of every engine |
| DMA glue | `sf_keystone_dma_glue.sv` | Keystone ↔ CloudDMA |
| Models | `sf_keystone_engmodel.sv` | ComputeWorks / Virtual I/O stand-ins |
| System | `sf_keystone_albion_sys.sv` | control + CloudDMA + models (the simulated system) |
| Register map | `config/keystone_regs.yaml` → `generated/sf_keystone_regs_pkg.sv`, `keystone_regs.h`, … | single source of truth |

## 2. Clock and reset

One clock `clk`. `rst_n` is the power-on reset: asynchronous assert, **synchronous release inside** `sf_keystone_sys` (2-flop). Three
reset scopes:

* **POR** (`por_rst_n`): everything. After POR a hardware init sweep zeroes the ECC SRAMs (valid codewords); no SRAM access is granted until it ends.
* **Warm** (`core_rst_n`): watchdog bite, `SYS.RESET_CTRL.SYS_WARM` (key `0xB007`), or a host reset request. Resets the CPU, timer, watchdog, interrupt controller, command engine, mailbox, engine shells, telemetry **and all engines**. **Retained**: SRAM contents, `RESET_CAUSE`, the security record, RAS counters / last event, `SCRATCH`, the power request, the boot counter.
* **Engine** (`eng_rst_n[e]`): `ENG_RESET` command or `RESET_CTRL.ENG_MASK`; ~8 clocks; `RESET_DONE` sticky bit.

## 3. Address map

See the generated [MEMORY_MAP.md](MEMORY_MAP.md) and [REGISTER_MAP.md](REGISTER_MAP.md). Summary: ROM `0x0000_0000` (8 KiB, reset vector) ·
IRAM `0x0010_0000` (32 KiB) · DRAM `0x0020_0000` (16 KiB) · SHM `0x0030_0000` (16 KiB) · firmware store `0x1000_0000` (64 KiB, read-only,
external) · MMIO `0x4000_0000` (SYS, TMR, INTC, WDT, CMD, RAS, TEL, MBX at 4 KiB spacing; five 64 KiB engine windows from `0x4001_0000`).
Instruction fetch is possible from ROM and IRAM only; a fetch anywhere else is an instruction access fault.

## 4. Engine windows

Each engine window is 64 KiB: **shell** `+0x000..0x0FF` (inside Keystone: identity, presence, REAL/MODEL, status, sticky `EVENT/FAULT/VIOL`
causes with enables, counters, last fault code, IRQ-inject test aid), **glue** `+0x100..0xFFF` (engine-specific management registers),
**engine page** `+0x1000..0xFFFF` (pass-through to the engine's own register page). `SYS.CAPS0` and `ESH_CAPS.REAL` say what is real:

| Engine | Index | In this release |
|---|---|---|
| DMA | 0 | **REAL** CloudDMA P64 (glue: completion record, permission-table programming; page: CloudDMA CSRs) |
| PKT (PacketForge) | 1 | absent (`PRESENT = 0`); reserved |
| MPL (MemoryPool) | 2 | absent; reserved |
| CPW (ComputeWorks) | 3 | **MODEL** |
| VIO (Virtual I/O) | 4 | **MODEL** |

## 5. Where each requirement of the brief lives

| Brief | Where |
|---|---|
| CPU integration wrapper, boot ROM, local SRAM, MMIO bridge | `sf_keystone_control.sv`, `sf_keystone_bootrom.sv`, `sf_keystone_sram.sv`, `sf_keystone_mmio.sv` |
| Timer, interrupt controller, watchdog | `sf_keystone_timer.sv`, `sf_keystone_interrupts.sv` — `04_INTERRUPTS.md` |
| Management command engine | `sf_keystone_cmd.sv` — `05_COMMAND_ENGINE.md` |
| Boot flow with per-stage status/error | `03_BOOT.md`, `sf_keystone_sys.sv`, `firmware/keystone/bootrom` |
| Registers (identity, version, caps, DMA, PacketForge, MemoryPool, ComputeWorks, Virtual I/O, RAS, telemetry, reset/power) | generated map; `SYS`, engine windows, `RAS`, `TEL` |
| Firmware (startup, linker, headers, ISRs, init, command submission, self-test, fault reporting, management routines) | `firmware/keystone` — `06_FIRMWARE.md` |
| Verification | `tests/keystone`, `07_VERIFICATION.md` |
