# 02 — Processor: exactly what is implemented

CPU: `third_party/silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv`, **unmodified** (hash-proven, `third_party/PROVENANCE.md`), instantiated with
`RV32M = 1`, `BOOT_ADDR = 0x0000_0000`, `HART_ID = 0`, `MIMPID = 0x0082_0001`. Design notes: the MCU-I `docs/CPU.md` (in the archive).

## 1. ISA

| Item | Configuration |
|---|---|
| Base | RV32I (32 × 32-bit registers, `x0 = 0`) |
| Extensions | **M** (iterative: every MUL / MULH* / DIV* / REM* takes 35 cycles, data independent), **Zicsr**, **Zifencei** (`FENCE.I` flushes the 2-entry prefetch buffer) |
| Not implemented | C, A, F, D, Zb\*, PMP, S / U modes, MMU, debug module / triggers, hardware misaligned access |
| `misa` | `0x4000_1100` (MXL = 32, I, M) — **checked by the firmware self-test on the RTL** |
| `mimpid` | `0x0082_0001` — checked; `mvendorid = marchid = mhartid = 0` — checked |
| Toolchain target | `-march=rv32im_zicsr_zifencei -mabi=ilp32` |
| `FENCE` | executes as a NOP (in-order, blocking loads / stores, no caches) |

## 2. Privilege

Machine mode only. CSRs: `mstatus` (MIE, MPIE; MPP = M), `misa`, `mie`, `mip`, `mtvec` (direct or vectored; firmware uses direct),
`mscratch`, `mepc`, `mcause`, `mtval`, `mcountinhibit`, `mcycle[h]`, `minstret[h]` (+ read-only user aliases), `mvendorid`, `marchid`,
`mimpid`, `mhartid`, `mconfigptr`.

**Software privilege.** Because the CPU is machine-mode only, "privilege" in Keystone is a *management* concept (`KS_PRIV_GUEST / TENANT /
OPERATOR / FIRMWARE`) carried by every management command, captured by hardware for host requests and re-checked by the command engine
(`05_COMMAND_ENGINE.md`). It is **not** a CPU privilege level.

## 3. Memory model

* **Little endian.** Loads / stores must be naturally aligned: a misaligned access raises a misaligned exception (cause 4 / 6, `mtval` = address) and is **not** sent to the bus (tested with real `lw` / `sw`).
* Reset vector `0x0000_0000` (boot ROM); `mtvec` resets to the reset vector.
* **Loads always request a full word.** The CPU drives `d_be = 4'hF` for every load (`d_be = is_store ? st_be : 4'b1111`). Consequence for MMIO: byte / halfword **stores** are refused (reason `SUBWORD`), byte / halfword **loads** cannot be distinguished from word loads and execute as a word read with the lane extracted. Firmware must use 32-bit accesses, never a sub-word load of a read-clear register (`INTC.CLAIM`). This is a property of the reused CPU, documented in `REGISTER_MAP.md`, and checked by the self-test.

## 4. Traps and interrupts

* Exceptions (precise, `mepc` = faulting instruction): 0 instruction misaligned, 1 instruction access fault (bus error on fetch: unmapped region, ECC UE, execute from MMIO), 2 illegal instruction (`mtval` = instruction), 3 breakpoint, 4 / 6 load / store misaligned, 5 / 7 load / store access fault (decode error, refused MMIO access, ECC UE, engine timeout), 11 ecall from M-mode. **All of these are exercised by the self-test on the RTL** (`t_exceptions`, `t_mmio`, `t_ras`, `t_regs`).
* Interrupts: MEI (11, from the Keystone INTC), MSI (3, `TMR.MSIP`), MTI (7, `mtime ≥ mtimecmp`); priority MEI > MSI > MTI; taken at an instruction boundary that is not inside a bus access. A MUL / DIV in progress is abandoned and re-executed after `MRET`. WFI wake-up by the timer is tested.
* Firmware trap path (`firmware/keystone/common/trap_entry.S`, `app/platform.c`): save `x1, x3..x31`, `mepc`, `mcause`, `mtval`, `mstatus` in a 144-byte frame, dispatch (MEI → INTC claim loop, MTI, MSI, exceptions), restore, `mret`. An exception that a test armed ("expected trap") is recorded and skipped (`mepc + 4`; all instructions are 4 bytes without C) or resumed at the saved `ra`; any other exception is fatal: console message, `BOOT_REPORT(FAILED, FW_FATAL_TRAP)`, halt.

## 5. Evidence — and what is **not** claimed

| Evidence | Where |
|---|---|
| riscv-tests rv32ui / um / mi 63/63 on this CPU (3 bus profiles × 2 seeds), formal equivalence to `sfv_cpu` | **Recorded by MCU-I and re-run by Project 21; NOT re-run in Project 82.** |
| In this project: compiled C (GNU 13.2 and LLVM 18) and hand-written assembly run on the RTL CPU for ~4 million cycles per boot; every exception cause above is exercised; interrupts, WFI, CSR reads, M-extension use by compiled code | `reports/regression.md`, `07_VERIFICATION.md` |

**No RISC-V compliance claim.** The RISC-V International architectural test suite (riscv-arch-test) has not been run on this core, by this
project or, to this audit's knowledge, by any project in the repository.

## 6. A lesson inherited from ControlCore and kept

A RAS interrupt for a failing **instruction fetch** would be taken *before* the fetch's own exception and the re-fetch after `MRET` would
raise it again (livelock). Keystone therefore **counts and logs** instruction-side ECC events but does not set an interrupt class for them;
the fetch still raises an instruction access fault. This is tested (`t_ras`, instruction-side block) and a mutant that removes the policy is
killed (`reports/mutation.md`, M15).
