# Hardware / software interface (summary)

The authoritative definitions are generated from `config/keystone_regs.yaml`: [REGISTER_MAP.md](REGISTER_MAP.md), [MEMORY_MAP.md](MEMORY_MAP.md),
`rtl/albion/generated/sf_keystone_regs_pkg.sv` (RTL) and `firmware/keystone/include/generated/keystone_regs.h` (C). `make check-regs` fails when any
generated file is stale, and 25 negative tests prove the generator rejects illegal maps (overlaps, misalignment, field overlap, …).

## Access rules (all MMIO)

32-bit word accesses at word-aligned addresses. Unmapped offsets, writes to read-only registers and byte / halfword **stores** → bus error
(load / store access fault) and no state change; `SYS.BAD_ADDR / BAD_INFO` record the access (address, direction, reason, count). Byte / halfword
**loads** behave as word loads (CPU property). An engine page that does not answer within 4096 clocks ends the access with a bus error
(`ENG_TIMEOUT`) so a hung engine cannot hang the management CPU.

## Typical flows

* **Bring-up a tenant DMA**: `ks_tenant_setup` → `ks_engine_enable(DMA)` → `ks_dma_init` (enable CloudDMA) → `ks_dma_map` (domain table) → build descriptors in SHM → `DMA_SUBMIT` (command engine, tenant → domain) → DMA interrupt → `ks_dma_wait` (reads `DMA.CPL_*`, pops the record) → verify.
* **Compute / virtual-I/O queue**: `Q_CREATE` → `Q_DOORBELL` → engine EVENT interrupt → read `Q_HEAD / Q_DONE`.
* **Fault handling**: RAS / SEC / engine FAULT interrupts → handlers read and W1C-clear the cause, log to the fault ring → recovery routine if required.
* **Host**: read identity / status; mailbox request → firmware executes → response; reset request with key and privilege.
