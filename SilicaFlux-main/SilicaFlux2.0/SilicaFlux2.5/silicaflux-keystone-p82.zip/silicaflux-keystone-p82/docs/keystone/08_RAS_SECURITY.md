# 08 — RAS and security

## 1. Local-memory ECC

`sf_keystone_sram.sv` (IRAM 32 KiB, DRAM 16 KiB): each 32-bit word is stored as **four independent byte lanes, each a SECDED (13,8)
extended-Hamming codeword** → 52 stored bits per word. The encoder / decoder is the SilicaFlux RAS (P26) codec, vendored unmodified (its own
evidence: exhaustive for K = 8 / 11). Per-lane coding means a byte / halfword store never needs a read-modify-write.

* **Single-bit error** in any of the 13 stored bits of a lane (data, check or overall parity): **corrected on the way out**; reported as `CE`. The stored word is **not** rewritten (no scrub engine): the next read corrects and counts again until software rewrites the word (`t_ras` shows the scrub). Evidence: unit test, **all 52** (lane × bit) single errors corrected; firmware: one error per lane across the bit classes.
* **Double-bit error in a lane**: detected, never returned as data. Data side: **load access fault** (`mcause 5`), `UE` event, `BAD_INFO.REASON = ECC_UE`. Instruction side: **instruction access fault** (`mcause 1`). Evidence: unit test, **all 312** (lane × bit-pair) double errors detected; firmware: UE → trap.
* Errors of three or more bits in one lane can alias to a correction (a property of every distance-4 code).
* **Initialisation**: after POR a hardware sweep writes zero codewords; no SRAM grant until it finishes (`SYS_STATUS.MEM_INIT_*`). The shared buffer SHM has **no** ECC.
* **Fault injection**: `RAS.INJ_ADDR` + `RAS.INJ_CTRL` — while ARM is set, the next write covering the chosen byte lane of the chosen word gets the mask XORed into that lane's stored bits (1 bit → CE, 2 bits → UE). Used by the firmware tests; also lets a platform exercise its RAS path.

## 2. RAS block (`sf_keystone_ras.sv`)

Sources: IRAM / DRAM ECC events (address, lane, syndrome, port), CPU data-side bus errors, engine fault pulses, engine and command timeouts, shared-buffer AXI errors, external RAS events (MemoryPool port, unconnected here).
Sticky class flags in `RAS.STATUS` (W1C), enables in `RAS.IE`, saturating counters (`CE_COUNT`, `UE_COUNT`, `BUS_COUNT`), a last-event record (`LAST_ADDR / INFO / TIME`) and the `RAS` interrupt (source 3).
**Instruction-side events are counted and logged but do not set an interrupt class** (see `02_CPU.md` §6). RAS state is in the always-on domain: it **survives a warm reset** (tested).

## 3. Security model — what is protected

| Asset | Protection | Tested |
|---|---|---|
| Boot status | hardware-enforced stage order; first error latched; `DEVICE_READY` only from a legal sequence | yes (firmware + mutants) |
| Management command path | key-armed submission, busy protection, hardware privilege table, tenant binding, validation before dispatch (`05_COMMAND_ENGINE.md`) | yes |
| Tenant isolation on DMA | the CloudDMA command **domain is bound by hardware from the tenant table**, never from software; CloudDMA checks every transaction against its permission table; a descriptor that claims another domain, or touches memory not mapped for its domain, completes with an **error and a violation event** that raises the security interrupt; the destination is left untouched | yes (`t_dma`, mutant M11) |
| Queue ownership (model engines) | a tenant cannot ring another tenant's doorbell (fault + violation) | yes (M17) |
| Reset / watchdog | reset request needs a key (`0xB007`); watchdog kick needs a key (`'KICK'`); a **locked** watchdog cannot be disabled or re-timed until reset | yes |
| Host interface | read-only status for any privilege; mailbox and reset request need privilege; hardware-captured privilege; busy / not-ready refusals; **no access to memory or engines** | yes (host tests, M14) |
| Security record | `SEC_STATUS` flags, `SEC_COUNT`, `SEC_LAST`, security interrupt; always-on (survives warm reset) | yes |

Violations that raise `SEC` flags: `PRIV_VIOL`, `BAD_KEY`, `BUSY_WRITE`, `DMA_VIOL`, `ENG_VIOL`, `BOOT_SEQ`, `HOST_PRIV`, `WDT_KEY`, `MBX_WRITE`.

## 4. Security model — what is **not** claimed

* **No authenticated secure boot, no measured boot, no secure debug.** Firmware integrity is CRC-32 (accidental corruption only). `SYS.CAPS2` reports the three bits as 0 and the self-test asserts it. SecureBoot (P28) is not connected.
* **The CPU is trusted.** Machine mode only; a malicious firmware image could do anything: the privilege check, the key and the busy protection defend against a misbehaving *requester* and accidents, not against the management CPU itself.
* **`host_priv` is an input.** It must be driven by the platform from an authenticated source (PCIe function, BMC authentication). Keystone does not authenticate the host.
* **The DMA permission table is CloudDMA's *simulation* IOMMU model** (a verified model, not a hardware IOMMU); its own documentation says so. A real IOMMU on `USE_EXT_IOMMU = 1` is a platform item.
* **No side-channel claims.** The shared buffer and the AXI slave are shared resources; arbitration is round-robin and observable.
* No physical attack (glitch, probing) resistance, no secure storage, no key handling.
