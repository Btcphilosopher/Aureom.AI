# 04 — Interrupts

`sf_keystone_interrupts.sv` — ten sources, priority 0..7, threshold, PLIC-style claim / complete. Its single output drives the CPU machine
external interrupt (MEI). The machine timer (`MTI`) and software interrupt (`MSI`) come from `sf_keystone_timer.sv` and go straight to the CPU.

## 1. Sources and default priorities (7 = highest)

| Id | Source | Meaning | Default priority | Type at reset |
|---|---|---|---|---|
| 1 | WDT | watchdog BARK (stage 1 expired) | 7 | level |
| 2 | SEC | security violation (`SYS.SEC_STATUS & SEC_IE`) | 7 | level |
| 3 | RAS | ECC / bus / engine fault classes (`RAS.STATUS & RAS.IE`) | 6 | level |
| 4 | CMD | management command DONE (`CMD.IE`) | 5 | level |
| 5 | HOST | host mailbox request pending (`MBX.IRQ_EN`) | 5 | level |
| 6 | DMA | DMA engine shell EVENT / FAULT / VIOL | 4 | level |
| 7 | CPW | compute completion (ComputeWorks) | 3 | level |
| 8 | VIO | virtual I/O completion | 3 | level |
| 9 | PKT | packet events (PacketForge) — *reserved, engine absent* | 2 | level |
| 10 | MPL | MemoryPool event — *reserved, engine absent* | 4 | level |

The seven sources the brief asks for are DMA completion, packet events, Virtual I/O completion, compute completion, ECC/RAS errors, security
violations and watchdog; **CMD, HOST and MPL are additions**. Priorities and types are programmable (`INTC.PRIO[n]`, `INTC.TYPE`); all
sources are disabled at reset.

## 2. Gateway, arbitration, acknowledgement

* **Level** source: pending follows the line. **Edge** source: a rising edge is latched until it is claimed (or `PEND_CLR`). `PEND_SET` latches pending for either type (a test aid that injects an event into the real routing path).
* A source that is **in service** (claimed, not yet completed) is masked: a level source does not retrigger before its handler completes; an edge during service is latched and re-pends after `COMPLETE`.
* Arbitration (every cycle): candidates = pending ∧ enabled ∧ ¬in-service ∧ (priority > `THRESH`). The winner is the highest priority; **equal priority → lowest source id**. `irq_out` = any candidate.
* **Claim**: reading `INTC.CLAIM` returns the winner id (0 = none), marks it in service, consumes its edge latch, counts the claim. **Complete**: writing the id to `INTC.CLAIM` ends service (a write for a source that is not in service is ignored).
* **Handler protocol (the "acknowledgement")**: claim → **clear the cause at its source** (`ESH_IRQ_STAT` W1C, `SEC_STATUS` W1C, `RAS.STATUS` W1C, `CMD_CTRL.CLEAR`, …) → complete. Completing before clearing a level source re-delivers it (tested). The platform's MEI handler loops claim → handler → complete until `CLAIM` returns 0 (`app/platform.c`).
* No nesting is configured: handlers run with `mstatus.MIE = 0`; priorities decide order at claim time.

## 3. Simultaneous events

Ten simultaneous events are delivered one at a time in strict priority order, none lost and none twice. Evidence:

| Test | What |
|---|---|
| Unit `tb_intc` | **60 000 random steps** against an independent cycle-accurate reference model (random source toggling, claims, completes, enable / type / threshold / priority writes, `PEND_SET` / `PEND_CLR`): 72 170 checks, 3 451 claims, ≥ 5 sources pending at once; plus the directed ten-source test (order `1 2 3 4 5 6 10 7 8 9`) and the edge-vs-register-write hazard test |
| Firmware `t_intc` | all ten sources pending, then delivered through the CPU: order checked; re-prioritisation (PKT → 7 follows WDT and SEC); threshold; disabled source; claim / complete / in-service masking; level vs edge on a real shell line |
| Firmware `t_simul` | **real concurrent events**: a DMA completion (real CloudDMA), a compute and a virtual-I/O completion, a watchdog bark, a security violation, a corrected ECC error and a command completion are all started with interrupts globally off; once all are pending they are delivered in the order WDT, SEC, RAS, CMD, DMA, CPW, VIO |

A real defect was found and fixed during this work: in the first version a rising edge on an edge-type source in the **same cycle** as a
`PEND_SET` / `PEND_CLR` write could be lost (two assignments to the same vector in one block). The next-latch value is now computed in one
place with a defined priority (a new edge is never lost); the directed unit test covers it and mutant M02 removes it.

## 4. Host interrupt

`host_irq` (output pin) is asserted while the mailbox response is valid (`H_IRQ_EN[0]`) and/or while the device is ready (`H_IRQ_EN[1]`);
cleared by `ACK`. Tested.
