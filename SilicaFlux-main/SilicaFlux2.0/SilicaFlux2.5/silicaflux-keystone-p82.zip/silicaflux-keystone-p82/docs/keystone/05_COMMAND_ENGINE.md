# 05 — Protected management command engine and device management

`sf_keystone_cmd.sv`, register block `CMD` (`0x4000_4000`). **One command at a time.**

```
 stage OP / TARGET / TENANT / PRIV / ARG0..3   (writable only while idle)
 write KEY = 'KEYS' (0x4B455953)               arms ONE submission
 write CTRL.GO ──► ACCEPT ──► VALIDATE ──► DISPATCH ──► WAIT ──► DONE (OK | error | timeout | aborted)
                    key?      opcode, priv,   engine      busy       STATUS.DONE, ERRCODE, RES0/1, interrupt (CMD.IE)
                              target, tenant,  accepts
                              args, enable
```

## 1. Protection

| Mechanism | Behaviour | Violation |
|---|---|---|
| Submission key | `CMD.KEY` must hold `0x4B455953` when `GO` is written; the key is **consumed** by `GO`. | GO without key, or wrong key → error `BAD_KEY`, `SEC.BAD_KEY` |
| Busy protection | `OP … ARG3`, `TIMEOUT`, `KEY` and a second `GO` are **ignored while BUSY** (the running command cannot be altered). | `SEC.BUSY_WRITE` |
| Hardware privilege check | every opcode has a minimum privilege; `CMD.PRIV` below it is refused. | error `PRIV`, `SEC.PRIV_VIOL` |
| Tenant binding | engine commands need a valid tenant that has access to the target engine; the **DMA domain is taken from the tenant table**, never from an argument. | `BAD_TENANT`, `NO_ACCESS` |
| Parameter validation | opcode, target range and presence, argument ranges / alignment, engine enabled, engine not in reset — all **before** anything is dispatched. | `BAD_OPCODE`, `BAD_TARGET`, `BAD_ARG`, `ENG_DISABLED`, `ENG_RESET` |
| Timeout | `CMD.TIMEOUT` clocks from dispatch to completion (reset value `0x40000`, `0` disables) | error `TIMEOUT`, `STATUS.TIMEOUT`, `TIMEOUTS++`, RAS `ENG_TIMEOUT` |
| Abort | `CTRL.ABORT` terminates a BUSY command (a late engine answer is ignored) | `STATUS.ABORTED`, error `ABORTED` |

**What the privilege check is, honestly.** `CMD.PRIV` is supplied by the requester path. For **host** requests it is the privilege the host port
asserted at the doorbell, captured by hardware into `MBX.STATUS.REQ_PRIV` and passed on by firmware (`ks_mbx_service`); the request words
cannot change it. For firmware-originated commands it is `KS_PRIV_FIRMWARE`. The CPU is **trusted**: a malicious firmware could write any
`PRIV`, so this is a consistency / defence-in-depth check against a misbehaving *requester*, not a boundary against the CPU.

## 2. Opcodes

| Op | Name | Min privilege | Target | Arguments | Executed by |
|---|---|---|---|---|---|
| `0x00` | NOP | GUEST | — | — | engine |
| `0x01` | ECHO | GUEST | — | `RES0 = ARG0 ^ ARG1`, `RES1 = ARG2 + ARG3` | engine (datapath self-test) |
| `0x10` | ENG_RESET | OPERATOR | engine | — | reset unit; completes when the engine leaves reset |
| `0x11` | ENG_ENABLE | OPERATOR | engine | `ARG0` = 0 / 1 | command engine (engine gate) |
| `0x20` | TENANT_SET | OPERATOR | — (`TENANT` = id) | `ARG0` domain (0..15), `ARG1` engine mask | command engine (tenant table) |
| `0x21` | TENANT_CLR | OPERATOR | — | — | command engine |
| `0x30` | DMA_SUBMIT | TENANT | DMA | `ARG0/1` descriptor head (64-byte aligned), `ARG2` ASID (0..15) | CloudDMA command port (via the glue) |
| `0x40` | Q_CREATE | OPERATOR | CPW or VIO | `ARG0` queue id (< 8), `ARG1` base (word aligned), `ARG2` depth (power of two, 2..256) | queue engine |
| `0x41` | Q_DESTROY | OPERATOR | CPW or VIO | `ARG0` queue id | queue engine |
| `0x42` | Q_DOORBELL | TENANT | CPW or VIO | `ARG0` queue id, `ARG1` new tail (running index) | queue engine |
| `0x60` | PERF_SNAP | GUEST | — | atomic telemetry snapshot | telemetry |

Validation order: opcode known → privilege → (engine ops) target → presence → tenant valid → tenant has access → arguments → engine enabled →
engine not in reset.

## 3. Error codes (`CMD.STATUS.ERRCODE`)

`0 OK` · `1 BAD_OPCODE` · `2 BAD_TARGET` · `3 BAD_TENANT` · `4 BAD_ARG` · `5 PRIV` · `6 ENG_DISABLED` · `7 NO_ACCESS` · `8 ENG_REJECT` (the engine refused at
accept; detail in `CMD.ENG_ERR`) · `9 ENG_FAIL` (the engine failed after accepting) · `10 TIMEOUT` · `11 ABORTED` · `12 BAD_KEY` · `13 ENG_RESET` ·
`14 BUSY` (firmware-side: the previous command did not finish).

## 4. Dispatch interface to an engine (`disp_*`)

`disp_valid` with `{disp_sel (one-hot), op, tenant, domain, arg0..3}` is held until `disp_ready[e]` (accept). `disp_done[e]` may coincide
with `ready`; `disp_err`, `disp_code`, `disp_res` qualify it. A rejection at accept (`done ∧ err` with `ready`) is `ENG_REJECT`; a failure
later is `ENG_FAIL`. The real CloudDMA's glue accepts when CloudDMA's command FIFO has room and completes the *management* command at
acceptance; the **DMA's own completion** arrives later as the DMA interrupt.

## 5. Device-management firmware routines (`firmware/keystone/app/mgmt.c`)

| Brief item | Routine |
|---|---|
| Capability discovery | `ks_discover()` — presence / REAL masks, limits, features, engine ids, enabled mask, RAS counters |
| Tenant context setup | `ks_tenant_setup(t, domain, engmask)`, `ks_tenant_clear(t)`; for DMA also `ks_dma_map()` programs the (simulation) IOMMU table for the tenant's domain |
| Queue creation | `ks_queue_create / destroy / doorbell(eng, tenant, qid, …)` |
| Engine reset | `ks_engine_reset(eng)` (privileged command; clears `RESET_DONE`) |
| Error recovery | `ks_recover_engine(eng)` — abort a stuck command, drop stale causes, reset, re-enable; `ks_dma_recover()` adds CloudDMA re-initialisation. Demonstrated after a command timeout and after a DMA bus error |
| Performance snapshots | `ks_perf_snapshot(&p)` — one atomic hardware capture (`PERF_SNAP` command), then reads |
| Privilege-check sensitive operations | `ks_mgmt_exec(cmd, caller_priv, &rsp)` — **software check first** (`ks_min_priv`, logged as a security fault, never reaches the hardware), then the hardware re-checks |

## 6. Host mailbox (`sf_keystone_host.sv`)

Request words (`MBX_IN`, 8 × 32 bits, written by the host while idle): `IN[0]` opcode, `IN[1]` = `target | tenant << 8`, `IN[2..5]` = `ARG0..3`.
Doorbell (`H_MBX_CTRL.DOORBELL`) needs privilege ≥ TENANT, no pending request and a **ready** device; the hardware captures `host_priv`.
Firmware services it (`INTC.HOST`), executes through `ks_mgmt_exec(…, REQ_PRIV)`, writes `MBX_OUT[0] = 0x8000_0000 | error`, `[1] RES0`, `[2] RES1`,
`[3] REQ_PRIV`, `[4]` sequence, and signals `MBX.CTRL.COMPLETE`. The host reads `MBX_OUT` and writes `ACK`. Firmware-only opcode `0xF0` (INFO)
returns the firmware version and the present / enabled engine masks. Host rules: GUEST can read status but not touch the mailbox; the reset
request (`H_RESET_REQ`) needs OPERATOR **and** the key `0xB007`; every refusal is a bus error on the host port and a security violation.
