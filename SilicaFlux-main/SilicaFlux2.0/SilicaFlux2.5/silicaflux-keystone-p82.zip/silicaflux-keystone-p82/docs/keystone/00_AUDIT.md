# 00 — Repository audit (Project 82, Keystone)

Audited: `btcphilosopher/Aureom.AI`, working tree at `9138b90`. The SilicaFlux work lives almost entirely inside zip archives under
`SilicaFlux-main/` and `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`; nothing is checked in as loose RTL. Every archive that could
contain a control processor, bus, boot ROM, timer, interrupt or cloud-engine block was extracted into a scratch directory
(untrusted data) and read; the ones that matter are cited below. **Nothing was committed to the repository.**

## 1. The names in the brief

A text search of all archive member names and of every extracted README / doc found **no** `Albion`, `Keystone`, `PacketForge` or
`ComputeWorks` (the only "Albion" hit is an unrelated mobile-game archive). They are therefore *new code names* in the brief. They are
mapped to the real SilicaFlux blocks as follows, and the mapping is stated wherever it matters:

| Brief name | Real block in the repository | Used here as |
|---|---|---|
| Albion (device) | the SilicaFlux **CloudDPU** family (Projects 61–65) | the SoC context of Keystone |
| Keystone | new (Project 82); **Project 21 ControlCore** is its closest ancestor (HPC variant) | this project |
| PacketForge | **PacketCore (P62)** `silicaflux_packet_engine` | window reserved, engine **not integrated** |
| MemoryPool | **MemoryPool (P65)** `silicaflux_memory_pool` | window reserved, engine **not integrated** |
| ComputeWorks | CloudDPU command/compute queues (P61) / ComputeCluster | **behavioural model** (`sf_keystone_engmodel`) |
| Virtual I/O | **VirtualIO (P63)** | **behavioural model** (same model, second instance) |
| DMA | **CloudDMA (P64)** `silicaflux_cloud_dma` | **REAL, unmodified, integrated and driven** |
| RAS | **RAS (P26)** | its SECDED codec is reused; Keystone has its own small RAS block |
| Security module | **SecureBoot (P28)** | **not connected** (see `08_RAS_SECURITY.md`) |

## 2. What exists, and the decision for each

| Area | Found (archive) | Evidence recorded *by that project* | Decision |
|---|---|---|---|
| **RISC-V CPU** | `silicaflux-mcu-i.zip` → `rtl/cpu/mcu_cpu.sv`: RV32I[M]_Zicsr_Zifencei, machine mode, 2-stage, precise traps, MEI/MSI/MTI, OBI-style I/D ports; derived from SilicaFlux-V `sfv_cpu` | riscv-tests rv32ui/um/mi 63/63 (RV32M=1) under 3 bus profiles × 2 seeds; Yosys equivalence `mcu_cpu(RV32M=0)` = `sfv_cpu`; **explicitly no compliance claim** | **Reused unmodified** (`RV32M = 1`). Those riscv-tests were **not re-run in this project** (see `02_CPU.md`). |
| Other CPUs | `RISC-V CPU.zip` (`rv32i_core.sv`), `cpu_core.zip` (5-stage RV32I), `pipelined_cpu.zip` | P21's audit records: no CSRs / traps / interrupts, no ISA test suite | **Not used.** Listed, not re-audited in depth here. |
| **ControlCore (P21)** | `silicaflux-controlcore.zip`: RV32IM_Zicsr + ROM + SRAM + INTC + WDT + DMA + mailbox for the HPC vector/tensor engines | 231 firmware checks, 63/63 riscv-tests re-run, FPGA place-and-route estimates | Read as the **design precedent** (same CPU, same "no pretended authentication" stance, the instruction-fetch RAS livelock lesson). Its top level is HPC-specific (vector / tensor engines), so Keystone is a new top rather than a fork. |
| **CloudDMA (P64)** | `silicaflux-clouddma-p64.zip` | 45/45 + 12/12 simulation runs, 29/29 mutants killed, simulation only | **Reused unmodified** as the real peripheral (vendored, hash-proven). |
| PacketCore (P62) | `silicaflux-packetcore-p62.zip`: AXI-S packet engine, register page with tenant isolation | verified in simulation against a software model; does not meet 50 MHz on ECP5 | Interface read (`rb_*` 16-bit + `rb_tenant`, `x_*` punt port). **Not integrated** — windows and interrupt source are reserved so integration is additive. |
| MemoryPool (P65) | `silicaflux-memorypool-p65.zip`: 4 KiB `rb_*` + `rb_priv` page, `irq_event` / `irq_fault`, RAS event port | verified in simulation | Interface read (its `rb_priv` convention is what Keystone's privilege model mirrors). **Not integrated.** |
| VirtualIO (P63), CloudDPU (P61), Telemetry, SecureBoot (P28), HPC command queue (M06) | present | various | Read for ABI conventions (tenant domains, queue ABIs). **SecureBoot is not connected.** |
| RAS (P26) | `silicaflux-ras-project26.zip` | SECDED exhaustively tested (K = 8, 11), 22/22 mutants killed | **SECDED encoder/decoder reused unmodified** (K = 8, per byte lane). |
| Boot ROM mechanism | SilicaFlux-V / MCU-I `sfv_bootrom` + `gen_rom.py` | used by MCU-I and P21 | Mechanism re-implemented (`mkrom.py` + `sf_keystone_bootrom`); ROM *code* is new. |
| Timer / INTC / WDT | MCU-I `mcu_intc`, `mcu_wdt`, `sfv` CLINT | formal + cocotb in MCU-I | **New** blocks with the brief's names and an Albion-specific source list (10 sources, priorities, two-stage watchdog). Not reused because the source list, claim protocol and reset integration differ. |

## 3. Decision: verified CPU exists → reuse

A RISC-V CPU with recorded evidence exists, so no core was written and no interim controller was invented. Keystone instantiates
`mcu_cpu` as **RV32IM_Zicsr_Zifencei**, machine mode only, `BOOT_ADDR = 0`, `MIMPID = 0x0082_0001`.

## 4. What is new in this project

`rtl/albion/*` (control top, ROM wrapper + generated image, ECC SRAM, shared-buffer SRAM with AXI4 slave, SYS block, MMIO bridge, timer,
watchdog, interrupt controller, command engine, RAS, telemetry, host port + mailbox, engine shell, DMA glue, queue-engine model, simulation
system top), the register map and generator, the boot ROM and management firmware, all testbenches, and the documentation.

## 5. Gaps found that this project does **not** close

* Authenticated boot / firmware signature check (P28 not integrated) — reported as **absent** in hardware (`SYS.CAPS2`).
* PacketForge (P62) and MemoryPool (P65) are not integrated; ComputeWorks and Virtual I/O are models.
* No RISC-V External Debug Module anywhere in the repository.
* No FPGA board results, no synthesis / timing / area / power result for Keystone (none was run here).
* No licence file in the repository (see `third_party/PROVENANCE.md`).
