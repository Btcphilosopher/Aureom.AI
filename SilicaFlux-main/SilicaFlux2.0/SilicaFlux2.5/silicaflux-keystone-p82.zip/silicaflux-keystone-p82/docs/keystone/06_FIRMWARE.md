# 06 — Firmware

```
firmware/keystone/
  Makefile                 GNU or LLVM build of the boot ROM and the firmware (SCENARIO = selftest | wdt | regs)
  include/ks_hal.h         MMIO / CSR / console helpers, boot-report helpers, image header, CRC-32
  include/generated/keystone_regs.h   GENERATED from config/keystone_regs.yaml (addresses, fields, enums)
  common/                  crt0.S (firmware start), rom_start.S (ROM start + ROM trap), trap_entry.S, string.c,
                           rom.ld.in / fw.ld.in + GENERATED ks_mem_rom.ld / ks_mem_fw.ld
  bootrom/rom_main.c       the boot ROM (stages 1..4)
  app/                     main.c, platform.c (traps, MEI dispatch, time), cmdq.c (command submission), mgmt.c (management
                           routines, host mailbox, production ISRs), dma.c (CloudDMA driver), fault.c (fault ring),
                           selftest.c + t_*.c (self-test groups)
```

## 1. Cross-compilation — the commands that were actually run

Target: **RV32IM_Zicsr_Zifencei, ilp32**, no C extension (the CPU does not implement it), freestanding, no libc.

**GNU** (`riscv64-unknown-elf-gcc` 13.2.0, Ubuntu 24.04 package `gcc-riscv64-unknown-elf`):

```bash
cd firmware/keystone
make TOOLCHAIN=gnu                     # boot ROM + selftest firmware     (build/gnu/rom.bin, build/gnu/selftest/fw_image.hex)
make TOOLCHAIN=gnu fw SCENARIO=wdt     # watchdog-reset scenario image
make TOOLCHAIN=gnu fw SCENARIO=regs    # register-map conformance image
```

which expands to (per C file, then link, then image):

```bash
riscv64-unknown-elf-gcc -march=rv32im_zicsr_zifencei -mabi=ilp32 -Os -g -std=gnu11 -ffreestanding -fno-builtin -fno-strict-aliasing \
    -fno-delete-null-pointer-checks -fno-pic -fno-stack-protector -ffunction-sections -fdata-sections -Wall -Wextra -Wshadow \
    -Wno-unused-parameter -Wno-array-bounds -Ifirmware/keystone/include -Ifirmware/keystone/app -Ifirmware/keystone/common \
    -DKS_SCENARIO_selftest=1 -c firmware/keystone/app/t_dma.c -o build/gnu/selftest/app/t_dma.c.o
riscv64-unknown-elf-gcc -march=rv32im_zicsr_zifencei -mabi=ilp32 -nostdlib -nostartfiles -Wl,--gc-sections \
    -Wl,-T,build/gnu/selftest/fw.ld -Wl,-Map,build/gnu/selftest/fw.map  <objects>  -o build/gnu/selftest/fw.elf
riscv64-unknown-elf-objcopy -O binary build/gnu/selftest/fw.elf build/gnu/selftest/fw.bin
python3 scripts/mkimage.py build/gnu/selftest/fw.bin build/gnu/selftest/fw_image.bin build/gnu/selftest/fw_image.hex --load 0x00100000
```

**LLVM** (`clang` 18.1.3 with `--target=riscv32`, `ld.lld`, `llvm-objcopy`; Ubuntu packages `clang lld llvm`):

```bash
make TOOLCHAIN=llvm
#   clang --target=riscv32 -march=rv32im_zicsr_zifencei -mabi=ilp32 -Os … -c app/t_dma.c      (same flags as above)
#   clang --target=riscv32 -march=rv32im_zicsr_zifencei -mabi=ilp32 -nostdlib -fuse-ld=lld -static -Wl,--gc-sections \
#         -Wl,-T,build/llvm/selftest/fw.ld … -o build/llvm/selftest/fw.elf
#   llvm-objcopy -O binary build/llvm/selftest/fw.elf build/llvm/selftest/fw.bin
```

Both toolchains build all three images with **0 compiler warnings** and both boot the RTL through every scenario (`reports/regression.md`).
Sizes (text bytes): boot ROM 2005 (GNU) / 2400 (LLVM) of 8192; selftest firmware 29 132 (GNU) / 30 864 (LLVM) of 32 768 — **the LLVM image has
about 1.9 KiB of IRAM headroom**; to add test groups, build with the stringified-check text off (the default) and consider splitting groups into
a second image (the `regs` and `wdt` scenarios already do).

Notes: `-fno-delete-null-pointer-checks` is required because address 0 is the boot ROM (GCC otherwise turns a read of address 0 into `ebreak`);
`string.c` supplies `memcpy / memset / memcmp` because compilers may emit calls to them even when freestanding; the Makefile tracks header
dependencies (`-MMD -MP`).

## 2. Startup and linking

* **Boot ROM** (`rom_start.S`): `sp` = top of DRAM, `mtvec` → ROM trap (reports `FAILED(ROM_TRAP)` for the stage in `mscratch`), `call rom_main`. Linked into BROM; no `.data` / `.bss`.
* **Firmware** (`crt0.S`): `gp`, `sp`, `mtvec` → `ks_trap_entry`, copy `.data` (load address in IRAM → DRAM), zero `.bss`, `call ks_main`. Linker script: `.text` / `.rodata` in IRAM (`0x0010_0000`, entry first), `.data` / `.bss` / stack in DRAM; the memory regions come from the **generated** `ks_mem_*.ld`, so ROM, firmware and RTL agree.
* `ks_frame_t` (the trap frame) is `static_assert`-ed against the layout in `trap_entry.S` (a mismatch here was a real bug during bring-up).

## 3. What `ks_main` does

1. report `MGMT_FW = RUNNING`; 2. `ks_discover()`; 3. `ks_irq_init()` (production ISRs, priorities from hardware defaults, shell / SEC / RAS / mailbox enables, `mie`, `mstatus.MIE`);
4. run the self-test (or the scenario); 5. report `MGMT_FW = OK`, `READY = RUNNING`, `READY = OK`; 6. **service loop**: handle host mailbox requests, otherwise `WFI`.

## 4. Self-test groups (`app/t_*.c`, run on the RTL after every boot)

| Group | Checks (what) |
|---|---|
| identity | device / vendor / versions, `FW_VERSION` written by the ROM, caps and **no AUTH_BOOT / SECURE_DEBUG / MEASURED_BOOT**, memory sizes, stage bytes, `misa` / `mimpid` / `mhartid`, **boot-sequence enforcement** (illegal reports ignored and flagged) |
| mmio | read / write registers, write to RO, unmapped offset, byte / halfword **stores** refused, loads act as word reads, no-target region, ROM and firmware-store writes refused, sub-word RAM access, SHM |
| exceptions | ecall, ebreak, illegal instruction, misaligned load / store (real `lw` / `sw`), instruction access fault (unmapped, MMIO), continuation after each |
| timer | tick rate, coherent 64-bit read, MTI, MSI, prescaler, disable, WFI wake-up |
| intc | defaults, ten simultaneous sources in order, re-prioritise, threshold, enable gating, claim / complete / in-service, level vs edge on a real shell line, reserved bits |
| cmd | provisioning, acceptance / completion / results, ~20 validation errors, **privilege refusals + SEC**, submission key, busy protection + abort, timeout (both hang modes), recovery, completion by IRQ, counters |
| engine | shell identity / REAL vs MODEL / absent engine window, engine reset, key-protected `RESET_CTRL`, reset status / done, power request / good, IRQ-inject routing |
| queue (CPW, VIO) | create, read-back, duplicate refused (fault + IRQ), doorbell → work → **one** completion interrupt, depth overflow, foreign tenant (violation), destroy while busy, destroy |
| dma | **real CloudDMA**: CSR identity / access rules, permission table (incl. refused entries), unaligned copy with CRC (vs independent software CRC), completion record, completion interrupt, scatter-gather, **tenant isolation** (PERM_DST, DOMAIN_MISMATCH → security interrupt), malformed descriptor, command-engine refusals, AXI bus error → `BUS_WR` + RAS, recovery |
| ras / ecc | single-bit errors in every lane and in data / check / parity positions (corrected), scrub, sub-word stores, uncorrectable → load fault, IRAM, instruction-side policy, masking |
| watchdog | kicking, wrong key, BARK interrupt, stage 2, prescaler, disable |
| simultaneous real events | seven real sources pending together, delivered in priority order |
| telemetry | atomic snapshots, counters, stability between snapshots, clear |
| fault reporting | ring of the latest 16 faults, newest-entry check, dump |

Scenario images: **`wdt`** (watchdog lock, bark, bite, warm reset, retained-state checks) and **`regs`** (generated register tables, see `07_VERIFICATION.md`).

## 5. Fault reporting

`ks_fault_report(src, code, a0, a1)` (`fault.c`) appends `{time, source, code, arg0, arg1}` to a 16-entry ring; sources: firmware, command, engine, RAS,
security, watchdog. Fatal traps print and report `FAILED(FW_FATAL_TRAP)` to the boot status (visible to the host). `ks_fault_dump()` prints the ring.
Failed self-test checks print `file:line` and, for equality checks, `got / want` (build with `EXTRA=-DKS_CHECK_TEXT=1` to add the expression text).
