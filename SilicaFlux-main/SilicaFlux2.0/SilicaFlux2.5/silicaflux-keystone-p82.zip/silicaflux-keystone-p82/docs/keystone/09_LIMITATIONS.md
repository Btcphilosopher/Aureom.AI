# 09 — Limitations and status (read this before relying on anything)

**Evidence level: RTL simulation only** — Verilator 5.020 (system model and unit benches). A second tool, Icarus Verilog 12, **elaborates** the control
subsystem and the full system (no Icarus *simulation* was run). No FPGA, no synthesis, no place-and-route, no timing / area / power result, no silicon. Nothing here ran on a board.

## What is real, model, absent

| | Status |
|---|---|
| CPU `mcu_cpu` RV32IM_Zicsr | **real RTL, unmodified**, runs compiled firmware (GNU and LLVM images) |
| CloudDMA (P64) | **real RTL, unmodified**, configured and driven by the firmware; its completion reaches the CPU as an interrupt |
| Local ECC SRAM, shared buffer SRAM, boot ROM, MMIO, SYS, timer, watchdog, INTC, command engine, RAS, telemetry, host port, engine shell, DMA glue | new RTL, verified in simulation |
| ComputeWorks (CPW), Virtual I/O (VIO) | **behavioural MODELS** (`sf_keystone_engmodel`): `ESH_CAPS.REAL = 0`, `SYS.CAPS0.REAL_* = 0`; no compute, no data movement |
| **PacketForge (PacketCore P62), MemoryPool (P65)** | **NOT integrated.** Windows, interrupt sources (9, 10) and shell exist; `PRESENT = 0`. Their configuration registers named in the brief therefore exist only as reserved windows — there is nothing behind them in this release. Integration is additive (`rb_*` adapters in the engine window, an `ENG_PRESENT` bit, a glue block) |
| Firmware store (boot flash) | simulation model (testbench memory behind an OBI port) |
| Power controller | interface only: `PWR_CTRL` drives `eng_pwr_en`; power-good is a 4-clock delay model |
| Host transport (PCIe / BMC link) | not implemented: the host port is a bare register port |

## Boot and security

* **No authenticated secure boot**, no measured boot, no secure debug (see `08_RAS_SECURITY.md`). CRC-32 integrity only.
* The management CPU is trusted; `PRIV` and `host_priv` are asserted by the requester path / platform.

## CPU

* **No RISC-V compliance claim.** riscv-tests are not re-run here (inherited evidence only); riscv-arch-test was never run.
* Machine mode only: no PMP, no user mode, no MMU, no C extension, no debug module, no hardware misaligned access.
* MUL / DIV take 35 cycles; interrupt latency is bounded by the longest bus access, not by a divide.
* **Byte / halfword loads to MMIO cannot be detected** (the CPU always requests a word for loads); stores can. Firmware uses word accesses.

## Memories

* ECC SRAM corrects on read but has **no write-back scrub** and no background scrubber; errors of ≥ 3 bits in a lane can miscorrect. The shared buffer has **no ECC**. SRAM contents are retained across a warm reset and are not scrubbed.
* IRAM is 32 KiB; the LLVM self-test image uses ~30.9 KB of it.
* The shared-buffer AXI slave moves **one beat in flight** (≈ 1 beat per 3 cycles), ignores AWLEN (a write burst ends with WLAST), supports INCR size-8 bursts only and does not interleave read / write bursts.

## Management

* One command at a time (by design). A command whose engine never answers ends by timeout; late answers are ignored.
* The tenant table has 8 entries, domains 0..15, queue ids 0..7 (model engines).
* `ENG_RESET` holds the engine in reset for ~8 clocks; the CloudDMA permission table and CSR configuration are **lost** by it (hard reset) and must be re-programmed (`ks_dma_recover()` + `ks_dma_map()` do).
* Watchdog and timer live in the warm domain: after a bite the watchdog is disabled again until firmware re-arms it (the ROM does not arm it; a boot-hang protection is future work).

## Verification gaps (honest list)

* No formal proof; no coverage measurement (line / toggle); no randomised system-level test beyond the INTC and SRAM benches; one seed per random bench.
* Fault injection by hardware (the `RAS.INJ_*` path) is exercised; **testbench backdoor flips of stored bits** and double faults across lanes in one word are covered only by the unit bench.
* The host port is driven by one master at a time in the testbench; concurrent CPU / host access to the mailbox is covered by the protocol rules, not by a stress test.
* The mutation campaign (`reports/mutation.md`) is 17 hand-picked defects, not exhaustive.
* No CDC (single clock) and no power-intent verification.
