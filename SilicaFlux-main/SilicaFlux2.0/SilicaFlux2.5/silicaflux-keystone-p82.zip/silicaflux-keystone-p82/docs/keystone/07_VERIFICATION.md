# 07 — Verification

Evidence level: **RTL simulation** (Verilator 5.020). Exact counts for the last full run are in [10_RESULTS.md](10_RESULTS.md) (generated from
`reports/regression.md` and `reports/mutation.md`); logs are in `reports/logs/`.

```bash
make regress        # map tests, vendor check, lint, 3 unit benches, GNU + LLVM x (build + 7 system scenarios)   ~2.5 min
python3 scripts/mutate.py    # 17 deliberate RTL defects, each must be caught                                      ~25 min
```

## 1. The brief's list (§9) → tests

| Item | Test(s) | What is checked |
|---|---|---|
| **Boot ROM execution** | scenario `boot` (+ `nofw badcrc badhdr badrange`) | ROM runs from `0x0` on the RTL CPU, reports every stage through hardware-checked `BOOT_REPORT`, memory-inits (ECC sweep + patterns + byte lanes), discovers engines, validates / copies / re-verifies the image, jumps; the four failure modes latch the right code and the ROM halts safely; the testbench observes the stages **through the host port while booting** |
| **Firmware instruction execution** | every scenario; `t_exceptions`, `t_identity` | ~4 M cycles of compiled C per boot (GNU and LLVM), `misa` / `mimpid`, M-extension, every exception cause, ecall / ebreak / illegal, interrupts + WFI |
| **MMIO read / write** | `t_mmio`, `regs` scenario, host table walk | generated tables: **reset values, RW masks, RO write refusal for every testable register** (85 RO + 53 RW), `SCRATCH` patterns |
| **Invalid register accesses** | `t_mmio`, `regs` scenario, host tests | unmapped offsets (every undefined word offset below `0x100` of every block and engine shell: 601 holes), RO writes, byte / halfword stores, no-target region, ROM / firmware-store writes, absent-engine window, undefined CloudDMA CSR, **host** refusals (privilege, unmapped, RO) — each is a bus error with **no state change** and an access record |
| **Interrupt routing** | `t_intc`, `t_simul`, `tb_intc`, `t_queue`, `t_dma`, host tests | every source reaches the CPU through the INTC with the right id and priority; level / edge; claim / complete / in-service; threshold; the real DMA / compute / VIO completions, watchdog, RAS, SEC, CMD and HOST sources; **simultaneous events** (unit: random vs reference model; firmware: ten injected, seven real) |
| **Watchdog** | `t_wdt`, scenario `wdt` | kick, wrong key, bark interrupt, stage 2, prescaler, disable; **bite → warm reset**, lock (cannot disable / re-time), what survives a warm reset (reset cause, security record, RAS, scratch, SRAM) and what does not (watchdog, INTC) |
| **Command dispatch** | `t_cmd`, `t_queue`, `t_dma`, host mailbox | acceptance, validation (~20 error cases), dispatch to the real DMA and to the queue models, busy, completion, abort, timeout, error status, one-at-a-time protection, submission key, privilege |
| **Peripheral reset** | `t_engine`, `t_cmd` (recovery), `t_dma` (recovery), host-requested warm reset | `ENG_RESET` command and key-protected `RESET_CTRL`, reset status / done, engine state cleared (queues, CloudDMA configuration), warm reset resets **all engines** |
| **Completion** | `t_dma`, `t_queue`, `t_simul` | **DMA completion record + interrupt** with data, CRC and byte count checked; one interrupt per queue batch; command completion by IRQ |
| **Firmware error handling** | `t_dma` (D, F, G), `t_cmd` (timeout / recovery), `t_ras`, `t_fault`, fatal-trap path | bad descriptor, AXI bus error, engine timeout → `ks_recover_engine`, ECC UE → access fault, fault ring, fatal trap → `FAILED(FW_FATAL_TRAP)` |

## 2. System scenarios (`tests/keystone/sim/tb_keystone.sv`, run for GNU and LLVM)

| Scenario | Firmware | Flow |
|---|---|---|
| `boot` | selftest | full boot + 15 firmware test groups; **host-port tests** (identity, generated host table, privilege refusals, mailbox with hardware-captured privilege, host IRQ, host-requested **warm reset**) and a **complete second boot** and self-test |
| `nofw` `badcrc` `badhdr` `badrange` | selftest | ROM failure paths (codes `0x30 0x33 0x31 0x32`) |
| `wdt` | wdt | lock → bark → bite → warm reset → second boot observes the retained state |
| `regs` | regs | generated register-map walker (reset values, RW masks, RO refusal, 601 unmapped offsets) |

## 3. Unit benches (`tests/keystone/unit`)

| Bench | Technique |
|---|---|
| `tb_sram_ecc` | every byte value in every lane; **all 52 single-bit errors corrected, all 312 double-bit errors detected**; injection only fires when its lane is written; 6 000 random byte-enable operations vs a byte-accurate reference; arbitration (B over A) and exact 1-cycle response; init sweep (no grant before it ends) |
| `tb_intc` | independent cycle-accurate **reference model**, 60 000 random steps (see `04_INTERRUPTS.md`), directed ten-source order, directed edge-vs-register-write hazard |
| `tb_shm_axi` | AXI4 slave vs a reference memory: random INCR bursts (1..16 beats, random strobes, random gaps, random R back-pressure) **concurrent with random CPU traffic**; IDs; B after the last write; SLVERR for bad size / burst / out-of-window with no state change |

## 3a. Generated, single-source checks

* `scripts/test_regmap.py`: the real map passes; **24 deliberately illegal maps** (duplicate / misaligned / overlapping registers and blocks, field overlap, bad reset, enum clashes, …) are each rejected; every generated file is current (25 / 25).
* `scripts/check_vendor.py`: 23 / 23 vendored files are byte-identical to their members in the repository archives.
* Lint: Verilator `-Wall`, **0 warnings** on the control subsystem and on the full system (waivers: `rtl/lint.vlt`, each justified in the file).
* Second tool: **Icarus Verilog 12 elaborates** the control subsystem and the full system including the real CloudDMA (0 errors). Elaboration only — no Icarus simulation was run (the system testbench uses Verilator-specific scheduling assumptions that were deliberately removed from the handshakes, but it was not ported). Getting Icarus to parse the RTL needed three portability edits (unpacked-array `localparam`s → functions / a packed vector, a ternary over enum values); they are behaviour-neutral and the whole regression and the mutation campaign were re-run on the final RTL.
* The boot-ROM image shipped in `rtl/albion/generated` is checked against a fresh GNU build of the ROM source (`make rom-image` regenerates it).

## 4. Mutation check (`reports/mutation.md`)

17 one-line RTL defects (INTC tie-break, dropped edge, threshold; ECC error not reported / not corrected; privilege check, busy protection, key,
timeout removed; RO-write check removed; DMA domain from a software argument; watchdog bite; boot-order checks; host mailbox privilege; fetch-side RAS
policy; queue ownership). Each must be killed by at least one check; survivors are test gaps and are listed.

## 5. Defects found by this verification (and fixed)

| # | Defect | Found by | Class |
|---|---|---|---|
| 1 | `dev_ready` was used before `sys_dev_ready` was declared → the host block saw a different, undriven net → the mailbox permanently refused doorbells | system testbench (host mailbox) | **RTL** |
| 2 | INTC: a rising edge in the same cycle as a `PEND_SET` / `PEND_CLR` write could be lost (two assignments to one vector) | code review while debugging the reference-model bench; now a directed test + mutant | **RTL** |
| 3 | Boot ROM compared **absolute** RAS counters, so a **warm** boot failed `MEMINIT_ECC` | the host-requested-reset second boot | **ROM** |
| 4 | `ks_frame_t` had a pad word → "resume at `ra`" resumed at `sp` → endless trap loop | bring-up; now `_Static_assert`-ed against `trap_entry.S` | firmware |
| 5 | `Makefile` did not track header dependencies → a stale object hid a fix | bring-up; `-MMD -MP` | build |
| 6 | Self-test expectations that assumed zero counters (`INJ_DONE`, INTC enable at entry) were wrong on a warm boot | second boot / `wdt` scenario | test |
| 7 | Assumptions disproved by the evidence: sub-word **loads** cannot be detected (CPU drives `d_be = F`); the compiler splits a constant misaligned access into bytes (tests now use raw `lw` / `sw`); GCC turns a read of address 0 into `ebreak` (`-fno-delete-null-pointer-checks`); the stringified check text overflowed the 32 KiB IRAM (now off by default) | simulation / link | test & doc |
| 8 | Testbench races (Verilator applies a non-blocking assignment before the DUT samples at the same edge; a function calling a time-consuming task silently did not wait) → drive on the falling edge, sample on the falling edge | host / unit benches | test |
| 9 | The register-map validator rejected my first map (the MMIO region was a container, the per-engine ID register needed a placeholder reset) | `scripts/gen_regs.py` | map |
| 10 | Not a defect but a result: with the fetch-side RAS policy removed (mutant M15) the system **livelocks** and only the cycle limit ends the run — the ControlCore lesson reproduced | mutation campaign | evidence |

## 6. What this does not show

See [09_LIMITATIONS.md](09_LIMITATIONS.md): simulation only, one simulator, no coverage measurement, no formal proof, riscv-tests not re-run, 17 hand-picked mutants,
PacketForge / MemoryPool not integrated.
