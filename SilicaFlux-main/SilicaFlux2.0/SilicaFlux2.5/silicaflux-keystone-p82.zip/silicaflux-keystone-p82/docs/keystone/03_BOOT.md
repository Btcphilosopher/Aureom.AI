# 03 — Boot

```
RESET ─► BOOT ROM ─► MEMORY INITIALISATION ─► DEVICE DISCOVERY ─► FIRMWARE LOAD ─► MANAGEMENT FIRMWARE ─► DEVICE READY
 stage 0   stage 1        stage 2                  stage 3             stage 4            stage 5              stage 6
```

Every stage reports `RUNNING`, then `OK` or `FAILED(code)` through `SYS.BOOT_REPORT`. **The hardware enforces the order** (stage *n* may
start only when stage *n−1* is OK and *n* is NOT_STARTED; OK / FAILED only from RUNNING); an illegal report is ignored and flagged
`SEC.BOOT_SEQ` (tested, mutant M13 / M16). The first failure latches `BOOT_ERR` and the `FAULT` flag; `DEVICE_READY` is set only by
`READY = OK`, which the order rule makes impossible unless stages 1–5 are OK and no error is latched.

## 1. Observability

| Register | Meaning |
|---|---|
| `SYS.BOOT_STAGE` | `STAGE[3:0]` current stage, `COUNT[15:8]` number of releases of the warm reset since POR, `FAULT[16]` |
| `SYS.BOOT_ST_LO / HI` | one status byte per stage 0..7: `0` not started, `1` running, `2` OK, `0x80 \| code` failed |
| `SYS.BOOT_ERR` | `VALID[31]`, `STAGE[11:8]`, `CODE[7:0]` of the **first** failure |
| `SYS.SYS_STATUS` | `DEVICE_READY`, `FAULT`, `MEM_INIT_IRAM / DRAM`, `CPU_SLEEPING`, `FW_VER_SET`, `HOST_IRQ` |
| `SYS.RESET_CAUSE` | sticky: POR, WDT, SW, HOST |
| console | `SYS.CONSOLE` → `console_valid / console_byte` pins (`[ROM] …`, `[FW] …`) |

The **host** reads the same status through `H_BOOT_STAGE / H_BOOT_ST_LO / H_BOOT_ST_HI / H_BOOT_ERR / H_SYS_STATUS / H_RESET_CAUSE`
(`host_priv` may be GUEST). The testbench samples the boot stage through the host port *while the device boots* and checks it never goes
backwards.

## 2. The stages (boot ROM, `firmware/keystone/bootrom/rom_main.c`, 2005 bytes GNU / 2400 bytes LLVM of 8192)

| # | Stage | What happens | Failure codes |
|---|---|---|---|
| 0 | RESET | hardware: reset released, status byte 0 = OK, init sweep of IRAM / DRAM running | — |
| 1 | ROM | ROM starts at `0x0000_0000`, prints the reset cause | `0x01 ROM_TRAP` (any exception inside the ROM is reported against the current stage via `mscratch`) |
| 2 | MEMINIT | waits (bounded) for the hardware ECC init sweep of IRAM and DRAM; data-pattern and **byte-lane** test of 2 KiB of DRAM and 1 KiB of IRAM; zeroes the shared buffer (SHM has no hardware init); requires the RAS CE / UE counters unchanged | `0x10 MEMINIT_TIMEOUT`, `0x11 MEMINIT_PATTERN`, `0x12 MEMINIT_ECC` |
| 3 | DISCOVERY | reads `SYS.CAPS0` and every engine shell: presence must agree, `ESH_ID` must match; at least one engine must be present | `0x20 DISC_NO_ENGINE`, `0x21 DISC_BAD_ID` |
| 4 | FWLOAD | validates and copies the management firmware from the firmware store (below), verifies the copy, writes `SYS.FW_VERSION`, `fence.i`, jumps to the entry | `0x30 FW_NO_IMAGE`, `0x31 FW_BAD_HDR`, `0x32 FW_BAD_RANGE`, `0x33 FW_BAD_CRC`, `0x34 FW_COPY_VERIFY` |
| 5 | MGMT_FW | the firmware reports RUNNING at entry, runs discovery, interrupt set-up and the self-test, reports OK or `FAILED(0x41 FW_SELFTEST_FAIL)` | `0x40 FW_INIT_FAIL` (ROM: firmware returned), `0x41`, `0x42 FW_FATAL_TRAP` |
| 6 | READY | RUNNING then OK → `DEVICE_READY` | `0x50 READY_PRECOND` (reserved) |

Reserved but not produced by this release: `0x22 DISC_TIMEOUT`, `0x35 FW_STORE_ERR` (a bus error while reading the store is an exception and is
reported as `ROM_TRAP`).

On any failure the ROM prints the stage and code, reports `FAILED`, and **halts in a WFI loop with interrupts disabled**; the error is
visible to the host. Tested with four corrupted-store scenarios (`nofw`, `badcrc`, `badhdr`, `badrange`): the right code is latched, the device
is **not** ready, later stages stay NOT_STARTED, the CPU sleeps, the host can read the error, and a host doorbell is refused.

## 3. Firmware image (firmware store, `0x1000_0000`)

```
 0x00 magic 'KSFW' (0x5746534B)   0x04 header version (1)   0x08 load address (IRAM)   0x0C payload bytes (multiple of 4)
 0x10 entry (inside the payload)  0x14 firmware version     0x18 payload CRC-32       0x1C header CRC-32 (of words 0..6)
 0x20 payload ...
```

Built by `scripts/mkimage.py`. The ROM checks magic, header CRC and version, word alignment, that the load range lies inside IRAM, that the
entry lies inside the payload, that the payload fits the store window, the **payload CRC-32 read directly from the store**, then copies and
re-verifies the CRC of the copy.

## 4. What is **not** claimed

* **No authenticated secure boot.** The image check is **CRC-32 integrity only**: it detects accidental corruption, it does not stop a
  malicious image (a CRC is trivially recomputed). No signature is verified, no key is held, nothing is measured. `SYS.CAPS2` reports
  `AUTH_BOOT = 0`, `SECURE_DEBUG = 0`, `MEASURED_BOOT = 0`, and the self-test asserts those bits are 0. SecureBoot (P28) is **not connected**;
  when it is, the ROM stage 4 is where a verified-boot hook belongs.
* The firmware store is a **simulation model** (testbench memory behind an OBI port); no flash controller exists in this project.

## 5. Warm boot

A warm reset (`WDT` bite, `RESET_CTRL.SYS_WARM`, host reset request) restarts at stage 0 and runs the **whole** flow again: the ROM re-checks
memory (relative to the retained RAS counters), re-discovers, **re-loads and re-verifies** the firmware image (IRAM contents were retained but
are not trusted). `BOOT_STAGE.COUNT` increments, `RESET_CAUSE` records the cause, the security record and RAS counters survive. Tested: a
host-requested warm reset followed by a complete second boot and self-test, and the watchdog bite scenario.
