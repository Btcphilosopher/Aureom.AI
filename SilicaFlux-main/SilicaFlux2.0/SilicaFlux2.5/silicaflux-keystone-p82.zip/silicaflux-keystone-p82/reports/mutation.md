# Mutation check

Each mutant is a deliberate one-line RTL defect. KILLED = a regression check failed (the defect is detected); SURVIVED = a test gap.

Baseline (unmutated) checks used: unit:intc, unit:sram_ecc, sys:boot, sys:wdt, sys:regs -- all PASS.

**17 / 17 mutants killed.**

| Mutant | Defect | Result | Evidence |
|---|---|---|---|
| M01 | equal priority: the HIGHEST id wins instead of the lowest | KILLED by unit:intc | UNIT FAIL |
| M02 | a rising edge is dropped (the original edge-vs-PEND_CLR hazard, taken to its extreme) | KILLED by unit:intc | UNIT FAIL |
| M03 | priority threshold off by one | KILLED by unit:intc | UNIT FAIL |
| M04 | uncorrectable data-side error is not reported as a bus error | KILLED by unit:sram_ecc | UNIT FAIL |
| M05 | corrected errors are not reported to RAS | KILLED by unit:sram_ecc | UNIT FAIL |
| M06 | hardware privilege check removed | KILLED by sys:boot | TB RESULT: FAIL checks=111996 errors=58 / first: FAIL t_cmd.c:72  (got 0x00000000, want 0x00000005) |
| M07 | staging registers writable while a command is BUSY | KILLED by sys:boot | TB RESULT: FAIL checks=49459 errors=57 / first: FAIL t_cmd.c:123  (got 0x00000010, want 0x00000042) |
| M08 | command timeout never fires | KILLED by sys:boot | TB RESULT: FAIL checks=59423 errors=57 / first: FAIL t_cmd.c:147 |
| M09 | GO accepted without the submission key | KILLED by sys:boot | TB RESULT: FAIL checks=49460 errors=57 / first: FAIL t_cmd.c:92  (got 0x00000000, want 0x0000000c) |
| M10 | writes to read-only registers are not refused | KILLED by sys:boot | TB RESULT: FAIL checks=49464 errors=57 / first: FAIL t_basic.c:70 |
| M11 | DMA domain taken from a software argument instead of the hardware tenant binding | KILLED by sys:boot | TB RESULT: FAIL checks=49476 errors=57 / first: FAIL t_dma.c:69  (got 0x00000001, want 0x00000000) |
| M12 | watchdog bite does not request a reset | KILLED by sys:wdt | TB RESULT: FAIL checks=7 errors=4 / first: TB FAIL: the watchdog bite caused a warm reset |
| M13 | boot-stage order violations are not flagged | KILLED by sys:boot | TB RESULT: FAIL checks=49452 errors=57 / first: FAIL t_basic.c:54 |
| M14 | a GUEST may use the host mailbox | KILLED by sys:boot | TB RESULT: FAIL checks=6063 errors=12 / first: TB FAIL: GUEST: reading MBX_OUT is refused |
| M15 | instruction-side ECC errors raise the RAS interrupt class (fetch livelock policy removed) | KILLED by sys:boot | TB RESULT: FAIL checks=99747 errors=1 / first: TB FAIL: simulation timeout |
| M16 | a stage can be reported OK without having started | KILLED by sys:boot | TB RESULT: FAIL checks=49459 errors=63 / first: FAIL t_basic.c:51  (got 0x00020102, want 0x00000102) |
| M17 | queue ownership not enforced (a tenant may ring another tenant's doorbell) | KILLED by sys:boot | TB RESULT: FAIL checks=49466 errors=57 / first: FAIL t_cmd.c:267  (got 0x00000000, want 0x00000008) |
