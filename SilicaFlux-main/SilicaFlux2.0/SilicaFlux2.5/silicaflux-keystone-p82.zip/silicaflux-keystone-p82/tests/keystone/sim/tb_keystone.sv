// =============================================================================
// Keystone system testbench (Verilator --binary --timing)
//
//   DUT: sf_keystone_albion_sys  (Keystone control + REAL CloudDMA + CPW/VIO models)
//
//   +fw=<hex>         firmware-store image (word per line, header first)
//   +scenario=<name>  boot | nofw | badcrc | badhdr | badrange | wdt
//   +maxcyc=<n>       cycle limit            +fws_lat=<n> firmware-store latency (default 2)
//   +axitrace         print the CloudDMA memory-port transactions
//
//   boot      full boot, firmware self-test (14+ groups), host-port tests (identity, boot-stage observation,
//             privilege refusals, mailbox with hardware-captured privilege, host IRQ), host-requested warm reset
//             and a second complete boot.
//   nofw ...  ROM failure paths: the right boot error is latched, the device is NOT ready, the ROM halts safely.
//   wdt       watchdog bark / bite -> warm reset -> second boot, checks what survives a warm reset.
//
//   Final line:  "TB RESULT: PASS|FAIL checks=N errors=M"
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_keystone;
  import sf_keystone_regs_pkg::*;

  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  int errors = 0;
  int checks = 0;
  task automatic check(input bit cond, input string msg);
    checks++;
    if (!cond) begin errors++; $display("TB FAIL: %s", msg); end
  endtask
  task automatic check_eq(input logic [31:0] got, input logic [31:0] want, input string msg);
    checks++;
    if (got !== want) begin errors++; $display("TB FAIL: %s (got 0x%08x, want 0x%08x)", msg, got, want); end
  endtask

  // ------------------------------------------------------------------ DUT
  logic        fws_req, fws_gnt, fws_rvalid, fws_err;
  logic [31:0] fws_addr, fws_rdata;
  logic        console_valid, core_rst_n, cpu_sleeping;
  logic [7:0]  console_byte;
  logic        rt_valid, rt_trap;
  logic [31:0] rt_pc, rt_cause;

  logic        host_req = 1'b0, host_we = 1'b0, host_rvalid, host_err, host_irq;
  logic [15:0] host_addr = '0;
  logic [31:0] host_wdata = '0, host_rdata;
  logic [1:0]  host_priv = '0;

  sf_keystone_albion_sys dut (
    .clk, .rst_n, .chip_uid(64'h0123_4567_89AB_CDEF),
    .fws_req, .fws_gnt, .fws_addr, .fws_rvalid, .fws_rdata, .fws_err,
    .console_valid, .console_byte,
    .host_req, .host_we, .host_addr, .host_wdata, .host_priv, .host_rvalid, .host_rdata, .host_err, .host_irq,
    .core_rst_n_o(core_rst_n), .cpu_sleeping,
    .dbg_rt_valid(rt_valid), .dbg_rt_pc(rt_pc), .dbg_rt_trap(rt_trap), .dbg_rt_cause(rt_cause)
  );

  // ------------------------------------------------------------------ firmware-store model (read only, OBI)
  localparam int FWS_WORDS = 16384;
  logic [31:0] fws_mem [FWS_WORDS];
  int          fws_lat = 2;
  int          fws_cnt;
  logic        fws_busy;
  logic [31:0] fws_a_q;

  assign fws_gnt = !fws_busy;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin fws_busy <= 1'b0; fws_cnt <= 0; fws_rvalid <= 1'b0; fws_rdata <= '0; fws_err <= 1'b0; fws_a_q <= '0; end
    else begin
      fws_rvalid <= 1'b0; fws_rdata <= '0; fws_err <= 1'b0;
      if (fws_req && fws_gnt) begin
        fws_busy <= 1'b1; fws_cnt <= fws_lat; fws_a_q <= fws_addr;
      end else if (fws_busy) begin
        if (fws_cnt <= 1) begin
          fws_busy <= 1'b0; fws_rvalid <= 1'b1;
          fws_rdata <= fws_mem[fws_a_q[15:2]];
        end else fws_cnt <= fws_cnt - 1;
      end
    end
  end

  // ------------------------------------------------------------------ console monitor
  string line = "";
  int    ready_cnt = 0, pass_cnt = 0, fail_cnt = 0, fatal_cnt = 0, line_fails = 0, wdt_obs = 0;
  always @(negedge clk) begin                       // sample on the falling edge: race-free against the DUT's registered pulse
    if (console_valid) begin
      if (console_byte == 8'h0A) begin
        $display("  [console] %s", line);
        if (line.len() >= 12 && line.substr(line.len() - 12, line.len() - 1) == "DEVICE READY") ready_cnt++;
        if (line.len() >= 15 && line.substr(0, 14) == "[FW] SELFTEST P") pass_cnt++;
        if (line.len() >= 15 && line.substr(0, 14) == "[FW] SELFTEST F") fail_cnt++;
        if (line.len() >= 10 && line.substr(0, 9) == "[FW]   FAI") line_fails++;
        if (line.len() >= 10 && line.substr(0, 9) == "[FW] FATAL") fatal_cnt++;
        if (line.len() >= 22 && line.substr(0, 21) == "[FW] WDT RESET OBSERVE") wdt_obs++;
        line = "";
      end else line = {line, string'(console_byte)};
    end
  end

  bit hosttrace = 0;
  initial hosttrace = $test$plusargs("hosttrace");
  always @(posedge clk) if (hosttrace && (host_req || host_rvalid))
    $display("  [host] t=%0t req=%b we=%b addr=%04x priv=%0d | rvalid=%b rdata=%08x err=%b", $time, host_req, host_we, host_addr, host_priv, host_rvalid, host_rdata, host_err);

  // ------------------------------------------------------------------ optional AXI trace of the CloudDMA memory port (+axitrace)
  bit axitrace = 0;
  initial axitrace = $test$plusargs("axitrace");
  always @(posedge clk) if (axitrace) begin
    if (dut.ar_valid && dut.ar_ready) $display("  [axi] AR id=%0d addr=%08x len=%0d", dut.ar_id, dut.ar_addr, dut.ar_len);
    if (dut.aw_valid && dut.aw_ready) $display("  [axi] AW id=%0d addr=%08x len=%0d size=%0d burst=%0d", dut.aw_id, dut.aw_addr, dut.aw_len, dut.aw_size, dut.aw_burst);
    if (dut.b_valid && dut.b_ready)   $display("  [axi] B  id=%0d resp=%0d", dut.b_id, dut.b_resp);
    if (dut.done_valid && dut.done_ready) $display("  [dma] done status=%0d err=%02x fault=%0d bytes=%0d txn=%04x", dut.done_status, dut.done_err, dut.done_fault, dut.done_bytes, dut.done_txn);
  end

  // ------------------------------------------------------------------ retirement trace ring (printed on a timeout)
  logic [31:0] pc_ring [32];
  logic [31:0] cause_ring [32];
  int          pc_wr = 0;
  int          trap_total = 0;
  always @(posedge clk) begin
    if (rt_valid) begin pc_ring[pc_wr % 32] <= rt_pc; cause_ring[pc_wr % 32] <= rt_trap ? rt_cause : 32'hFFFF_FFFF; pc_wr <= pc_wr + 1; end
    if (rt_valid && rt_trap) trap_total <= trap_total + 1;
  end
  task automatic dump_trace();
    $display("TB: last retired PCs (oldest first), traps so far %0d:", trap_total);
    for (int i = 0; i < 32; i++) begin
      int k = (pc_wr + i) % 32;
      $display("   pc=%08x %s", pc_ring[k], (cause_ring[k] != 32'hFFFF_FFFF) ? $sformatf("TRAP cause=%08x", cause_ring[k]) : "");
    end
  endtask

  always @(dut.u_ks.u_sys.ready_q) if (hosttrace) $display("  [dbg] t=%0t ready_q -> %b (core_rst_n=%b boot_count=%0d)", $time, dut.u_ks.u_sys.ready_q, core_rst_n, dut.u_ks.u_sys.boot_count_q);
  always @(core_rst_n) if (hosttrace) $display("  [dbg] t=%0t core_rst_n -> %b", $time, core_rst_n);

  // ------------------------------------------------------------------ backdoor views
  function automatic logic [7:0] stage_status(input int s);  return dut.u_ks.u_sys.bst_q[s]; endfunction
  function automatic bit ready();     return dut.u_ks.u_sys.ready_q;  endfunction
  function automatic bit fault();     return dut.u_ks.u_sys.fault_q;  endfunction
  function automatic logic [6:0] err_code();  return dut.u_ks.u_sys.err_code_q; endfunction
  function automatic logic [3:0] err_stage(); return dut.u_ks.u_sys.err_stage_q; endfunction

  // ------------------------------------------------------------------ host port driver
  // Race-free handshake: inputs are driven on the falling edge, the DUT samples them on the next rising edge, and the
  // registered response (valid for exactly that one cycle after the strobe) is sampled on the following falling edge.
  task automatic host_xfer(input bit we, input logic [15:0] addr, input logic [31:0] wdata, input logic [1:0] priv,
                           output logic [31:0] rdata, output bit err);
    @(negedge clk);
    host_req = 1'b1; host_we = we; host_addr = addr; host_wdata = wdata; host_priv = priv;
    @(negedge clk);                      // one rising edge in between: the DUT sampled the strobe, response is now valid
    if (hosttrace) $display("  [hostchk] t=%0t addr=%04x we=%b priv=%0d rvalid=%b rdata=%08x err=%b | ok=%b priv_ok=%b busy_ref=%b notrdy=%b pend=%b ready=%b", $time, addr, we, priv, host_rvalid, host_rdata, host_err,
      dut.u_ks.u_host.h_ok, dut.u_ks.u_host.h_priv_ok, dut.u_ks.u_host.h_busy_refuse, dut.u_ks.u_host.h_notready_refuse, dut.u_ks.u_host.pend_q, dut.u_ks.u_host.dev_ready); if (hosttrace) $display("  [dbg] sys.ready_q=%b sys.dev_ready=%b ks.sys_dev_ready=%b ks.dev_ready=%b host.dev_ready=%b", dut.u_ks.u_sys.ready_q, dut.u_ks.u_sys.dev_ready, dut.u_ks.sys_dev_ready, dut.u_ks.dev_ready, dut.u_ks.u_host.dev_ready);
    check(host_rvalid === 1'b1, "host port: response exactly one cycle after the request");
    rdata = host_rdata;
    err   = host_err;
    host_req = 1'b0; host_we = 1'b0; host_wdata = '0;
  endtask
  logic [31:0] hv; bit he;
  task automatic hrd(input logic [15:0] a, input logic [1:0] p);
    logic [31:0] d; bit er;
    host_xfer(1'b0, a, 32'd0, p, d, er);
    hv = d; he = er;
  endtask
  task automatic hwr(input logic [15:0] a, input logic [31:0] d, input logic [1:0] p);
    logic [31:0] tmp; bit er; host_xfer(1'b1, a, d, p, tmp, er); he = er;
  endtask

  // mailbox transaction: returns the response words in resp[0..4]; priv is what the host port asserts
  logic [31:0] resp [5];
  bit          mbx_ok;
  task automatic mbx_cmd(input logic [1:0] priv, input logic [31:0] w0, input logic [31:0] w1, input logic [31:0] w2,
                         input logic [31:0] w3, input logic [31:0] w4, input logic [31:0] w5);
    int tmo;
    mbx_ok = 1'b0;
    hwr(KS_H_MBX_IN_0 + 16'd0,  w0, priv); check(!he, "mailbox: write IN0");
    hwr(KS_H_MBX_IN_0 + 16'd4,  w1, priv);
    hwr(KS_H_MBX_IN_0 + 16'd8,  w2, priv);
    hwr(KS_H_MBX_IN_0 + 16'd12, w3, priv);
    hwr(KS_H_MBX_IN_0 + 16'd16, w4, priv);
    hwr(KS_H_MBX_IN_0 + 16'd20, w5, priv);
    hwr(KS_H_MBX_CTRL, 32'd1, priv);                       // DOORBELL
    check(!he, "mailbox: doorbell accepted");
    tmo = 0;
    do begin hrd(KS_H_MBX_STATUS, priv); tmo++; repeat (20) @(posedge clk); end while (!hv[KS_H_MBX_STATUS_RSP_VALID_LSB] && tmo < 4000);
    if (tmo >= 4000) begin check(1'b0, "mailbox: response timeout"); return; end
    for (int i = 0; i < 5; i++) begin hrd(KS_H_MBX_OUT_0 + 16'(4*i), priv); resp[i] = hv; end
    hwr(KS_H_MBX_CTRL, 32'd2, priv);                       // ACK
    mbx_ok = 1'b1;
  endtask

  // ------------------------------------------------------------------ helpers
  string scenario = "boot";
  string fwfile;
  int    maxcyc = 12_000_000;
  int    cyc = 0;
  bit    done_flag;

  task automatic wait_cycles(input int n); repeat (n) @(posedge clk); endtask
  task automatic wait_until_ready(input int target_count, input int limit);
    int t = 0;
    while (ready_cnt < target_count && fail_cnt == 0 && fatal_cnt == 0 && t < limit) begin @(posedge clk); t++; end
  endtask

  function automatic int unsigned crc32_hdr();
    int unsigned c = 32'hFFFF_FFFF;
    for (int w = 0; w < 7; w++)
      for (int b = 0; b < 4; b++) begin
        c ^= (fws_mem[w] >> (8*b)) & 32'hFF;
        for (int k = 0; k < 8; k++) c = (c >> 1) ^ ((c & 1) ? 32'hEDB88320 : 32'd0);
      end
    return ~c;
  endfunction

  // global cycle counter / timeout
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (cyc > maxcyc && !done_flag) begin
      $display("TB: TIMEOUT after %0d cycles", cyc);
      dump_trace();
      check(1'b0, "simulation timeout");
      finish_run();
    end
  end

  // ------------------------------------------------------------------ generated register tables (host side)
  logic [15:0] ht_a [64]; logic [31:0] ht_rst [64]; logic [31:0] ht_mask [64]; int ht_kind [64]; int ht_acc [64]; string ht_name [64];
  int ht_n = 0;
  task automatic ht_add(input logic [31:0] addr, input int kind, input int acc, input logic [31:0] rst, input logic [31:0] mask, input string name);
    ht_a[ht_n] = addr[15:0]; ht_kind[ht_n] = kind; ht_acc[ht_n] = acc; ht_rst[ht_n] = rst; ht_mask[ht_n] = mask; ht_name[ht_n] = name; ht_n++;
  endtask
  task automatic rt_add(input logic [31:0] addr, input int kind, input int acc, input logic [31:0] rst, input logic [31:0] mask, input string name);
  endtask
  task automatic regtest_fill();
    ht_n = 0;
`include "ks_regtest_tbl.svh"
  endtask

  task automatic host_regtable_tests();
    logic [31:0] pat [4];
    pat[0] = 32'h0; pat[1] = 32'hFFFFFFFF; pat[2] = 32'hA5A5A5A5; pat[3] = 32'h5A5A5A5A;
    regtest_fill();
    $display("TB: host register table (%0d registers)", ht_n);
    check(ht_n >= 4, "host register table is not empty");
    for (int i = 0; i < ht_n; i++) begin
      hrd(ht_a[i], 2'd3);
      check_eq(hv, ht_rst[i], {"host reset value ", ht_name[i]});
      if (ht_kind[i] == 1) begin
        hwr(ht_a[i], ~ht_rst[i], 2'd3);   check(he, {"host: read-only register refuses writes: ", ht_name[i]});
        hrd(ht_a[i], 2'd3);               check_eq(hv, ht_rst[i], {"host: read-only register unchanged: ", ht_name[i]});
      end else if (ht_kind[i] == 2) begin
        for (int p = 0; p < 4; p++) begin
          hwr(ht_a[i], pat[p], 2'd3);
          hrd(ht_a[i], 2'd3);             check_eq(hv, pat[p] & ht_mask[i], {"host rw mask: ", ht_name[i]});
        end
        hwr(ht_a[i], ht_rst[i], 2'd3);
      end
    end
    // every word offset below 0x100 that is not a register is refused
    begin
      int holes = 0;
      for (int off = 0; off < 256; off += 4) begin
        hrd(16'(off), 2'd3);
        if (he) holes++;
      end
      check(holes >= 20, "host: undefined offsets below 0x100 are refused");
    end
  endtask

  // ------------------------------------------------------------------ host tests (device ready)
  task automatic host_identity_tests();
    $display("TB: host identity / status");
    hrd(KS_H_DEV_ID, 2'd0);      check_eq(hv, 32'h53464B53, "host DEV_ID");          check(!he, "host DEV_ID no error");
    hrd(KS_H_VENDOR_ID, 2'd0);   check_eq(hv, 32'h41555245, "host VENDOR_ID");
    hrd(KS_H_HW_VERSION, 2'd0);  check_eq(hv, 32'h01000000, "host HW_VERSION");
    hrd(KS_H_FW_VERSION, 2'd0);  check_eq(hv, 32'h00010000, "host FW_VERSION (written by the ROM from the image header)");
    hrd(KS_H_CAPS0, 2'd0);       check_eq(hv, 32'h00000119, "host CAPS0: DMA+CPW+VIO present, DMA real");
    hrd(KS_H_CAPS1, 2'd0);       check_eq(hv, 32'h5_0A_08_08,  "host CAPS1 (5 engines, 10 irq, 8 queues, 8 tenants)");
    hrd(KS_H_CAPS2, 2'd0);       check_eq(hv, 32'h0000003F, "host CAPS2: no AUTH_BOOT / SECURE_DEBUG / MEASURED_BOOT");
    hrd(KS_H_MEM_CAPS, 2'd0);    check_eq(hv, 32'h10102008, "host MEM_CAPS");
    hrd(KS_H_BOOT_ST_LO, 2'd0);  check_eq(hv, 32'h02020202, "host BOOT_ST_LO: RESET ROM MEMINIT DISCOVERY OK");
    hrd(KS_H_BOOT_ST_HI, 2'd0);  check_eq(hv, 32'h00020202, "host BOOT_ST_HI: FWLOAD MGMT_FW READY OK");
    hrd(KS_H_BOOT_ERR, 2'd0);    check_eq(hv, 32'h0, "host BOOT_ERR empty");
    hrd(KS_H_SYS_STATUS, 2'd0);  check(hv[0] && !hv[1], "host SYS_STATUS: ready, no fault");
    hrd(KS_H_RESET_CAUSE, 2'd0); check_eq(hv & 32'hF, 32'h1, "host RESET_CAUSE: power-on");
    hrd(KS_H_PWR_STATUS, 2'd0);  check_eq(hv & 32'h1F, 32'h1F, "host PWR_STATUS: engines powered");
    // writes to read-only registers and unmapped offsets are refused
    hwr(KS_H_DEV_ID, 32'd0, 2'd3);     check(he, "host: write to a read-only register is refused");
    hrd(16'h0FF0, 2'd3);               check(he, "host: unmapped offset is refused");
    hrd(16'hF000, 2'd3);               check(he, "host: unmapped high offset is refused");
    hrd(KS_H_DEV_ID, 2'd0);            check_eq(hv, 32'h53464B53, "host DEV_ID unchanged");
  endtask

  task automatic host_priv_tests();
    logic [31:0] sc0, sc1;
    $display("TB: host privilege / protection");
    hrd(KS_H_SEC_COUNT, 2'd3); sc0 = hv;
    // GUEST (0): cannot touch the mailbox
    hrd(KS_H_MBX_OUT_0, 2'd0);            check(he, "GUEST: reading MBX_OUT is refused");
    hwr(KS_H_MBX_IN_0, 32'h1, 2'd0);       check(he, "GUEST: writing MBX_IN is refused");
    hwr(KS_H_MBX_CTRL, 32'h1, 2'd0);       check(he, "GUEST: doorbell is refused");
    hwr(KS_H_IRQ_EN, 32'h1, 2'd0);         check(he, "GUEST: IRQ_EN write is refused");
    hrd(KS_H_MBX_STATUS, 2'd0);            check(!he, "GUEST may read the mailbox status");
    check_eq(hv & 32'h3, 32'h0, "no request pending");
    hrd(KS_H_SEC_COUNT, 2'd3); sc1 = hv;
    check(sc1 >= sc0 + 4, "refusals were counted as security violations");
    check(dut.u_ks.u_sys.sec_last_q[7:0] == 8'(KS_SEC_HOST_PRIV), "SEC_LAST names HOST_PRIV");
    // reset request: privilege and key
    hwr(KS_H_RESET_REQ, {KS_KEY_RESET, 16'h0}, 2'd1);   check(he, "TENANT: reset request refused (needs OPERATOR)");
    hrd(KS_H_SEC_COUNT, 2'd3); sc0 = hv;
    hwr(KS_H_RESET_REQ, {16'hDEAD, 16'h0}, 2'd2);       check(he, "OPERATOR: reset request with a wrong key refused");
    hrd(KS_H_SEC_COUNT, 2'd3);                           check(hv == sc0 + 1, "wrong key counted as a security violation");
    check(dut.u_ks.u_sys.sec_last_q[7:0] == 8'(KS_SEC_BAD_KEY), "SEC_LAST names BAD_KEY");
    check(core_rst_n === 1'b1, "no reset happened");
  endtask

  task automatic host_mailbox_tests();
    $display("TB: host mailbox");
    // ECHO at TENANT privilege
    mbx_cmd(2'd1, KS_OP_ECHO, 32'h0, 32'hA5A5A5A5, 32'h0F0F0F0F, 32'd5, 32'd7);
    check(mbx_ok, "mailbox ECHO completed");
    check_eq(resp[0], 32'h80000000, "ECHO status OK");
    check_eq(resp[1], 32'hAAAAAAAA, "ECHO res0");
    check_eq(resp[2], 32'd12, "ECHO res1");
    check_eq(resp[3], 32'd1, "firmware saw the hardware-captured privilege (TENANT)");
    // INFO answered by firmware
    mbx_cmd(2'd1, 32'hF0, 32'h0, 32'h0, 32'h0, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000, "INFO status OK");
    check_eq(resp[1], 32'h00010000, "INFO fw version");
    check_eq(resp[2] & 32'hFF, 32'h19, "INFO present engines");
    // the lowest privilege that may use the mailbox is TENANT; NOP and PERF_SNAP need nothing more
    mbx_cmd(2'd1, KS_OP_NOP, 32'h0, 32'h0, 32'h0, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000, "TENANT NOP accepted");
    mbx_cmd(2'd1, KS_OP_PERF_SNAP, 32'h0, 32'h0, 32'h0, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000, "TENANT PERF_SNAP accepted");
    // the host cannot forge privilege: a TENANT asks for an OPERATOR operation
    begin
      logic [31:0] acc0 = dut.u_ks.u_cmd.n_acc_q;
      mbx_cmd(2'd1, KS_OP_ENG_RESET, KS_ENG_CPW, 32'h3, 32'h3, 32'h3, 32'h3);      // words claim "priv 3"; hardware ignores them
      check_eq(resp[0], 32'h80000000 | KS_CERR_PRIV, "TENANT ENG_RESET refused (PRIV)");
      check_eq(resp[3], 32'd1, "privilege stays what the port asserted");
      check_eq(dut.u_ks.u_cmd.n_acc_q, acc0, "the refused command never reached the command engine");
    end
    mbx_cmd(2'd1, KS_OP_TENANT_SET, 32'h0400, 32'd9, 32'h18, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000 | KS_CERR_PRIV, "TENANT TENANT_SET refused");
    check(!dut.u_ks.u_cmd.ten_valid_q[4], "tenant 4 was not created");
    // OPERATOR may
    mbx_cmd(2'd2, KS_OP_TENANT_SET, 32'h0400, 32'd9, 32'h18, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000, "OPERATOR TENANT_SET accepted");
    check(dut.u_ks.u_cmd.ten_valid_q[4], "tenant 4 created");
    check_eq(dut.u_ks.u_cmd.ten_dom_q[4], 32'd9, "tenant 4 domain");
    mbx_cmd(2'd2, KS_OP_TENANT_CLR, 32'h0400, 32'd0, 32'd0, 32'h0, 32'h0);
    check(!dut.u_ks.u_cmd.ten_valid_q[4], "tenant 4 cleared");
    mbx_cmd(2'd2, KS_OP_ENG_RESET, KS_ENG_CPW, 32'h0, 32'h0, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000, "OPERATOR ENG_RESET accepted");
    mbx_cmd(2'd2, KS_OP_ENG_ENABLE, KS_ENG_CPW, 32'h1, 32'h0, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000, "OPERATOR ENG_ENABLE accepted");
    // hardware validation reaches the host as an error code
    mbx_cmd(2'd3, 32'h77, 32'h0, 32'h0, 32'h0, 32'h0, 32'h0);
    check_eq(resp[0], 32'h80000000 | KS_CERR_BAD_OPCODE, "unknown opcode reported");
    // mailbox is exclusive while a request is pending
    begin
      logic [31:0] sc0;
      hrd(KS_H_SEC_COUNT, 2'd3); sc0 = hv;
      hwr(KS_H_MBX_IN_0, KS_OP_NOP, 2'd1);
      hwr(KS_H_MBX_CTRL, 32'd1, 2'd1);                      check(!he, "request submitted");
      hwr(KS_H_MBX_CTRL, 32'd1, 2'd1);                      check(he, "a second doorbell while pending is refused");
      hwr(KS_H_MBX_IN_0 + 16'd8, 32'hDEAD, 2'd1);           check(he, "MBX_IN is locked while a request is pending");
      hrd(KS_H_SEC_COUNT, 2'd3);                            check(hv >= sc0 + 2, "mailbox misuse counted as security violations");
      repeat (3000) @(posedge clk);
      hrd(KS_H_MBX_STATUS, 2'd1);                           check(hv[KS_H_MBX_STATUS_RSP_VALID_LSB], "the pending request completed");
      hwr(KS_H_MBX_CTRL, 32'd2, 2'd1);
    end
    // host interrupt
    hwr(KS_H_IRQ_EN, 32'h1, 2'd1);
    check(!host_irq, "host_irq low");
    hwr(KS_H_MBX_IN_0, KS_OP_NOP, 2'd1);
    hwr(KS_H_MBX_CTRL, 32'd1, 2'd1);
    begin int t = 0; while (!host_irq && t < 4000) begin @(posedge clk); t++; end end
    check(host_irq, "host_irq asserted on response");
    hwr(KS_H_MBX_CTRL, 32'd2, 2'd1);
    @(negedge clk); @(negedge clk);
    check(!host_irq, "host_irq cleared by ACK");
    hwr(KS_H_IRQ_EN, 32'h0, 2'd1);
  endtask

  // ------------------------------------------------------------------ scenarios
  task automatic run_boot();
    int sample_prev = 0, sample_n = 0, mono = 1;
    bit [15:0] seen_stage;
    seen_stage = '0;
    // observe the boot through the host port while it happens
    wait_cycles(3000);
    hwr(KS_H_MBX_CTRL, 32'd1, 2'd1);   check(he, "doorbell before the device is ready is refused");
    while (ready_cnt < 1 && fail_cnt == 0 && fatal_cnt == 0 && cyc < maxcyc) begin
      hrd(KS_H_BOOT_STAGE, 2'd0);
      begin
        int st = int'(hv[3:0]);
        if (st < sample_prev) mono = 0;
        sample_prev = st; seen_stage[st] = 1'b1; sample_n++;
      end
      wait_cycles(400);
    end
    check(mono == 1, "boot stage observed through the host port never goes backwards");
    check(sample_n > 20, "boot was sampled many times");
    check(seen_stage[1] && seen_stage[2] && seen_stage[3] && seen_stage[4], "ROM, MEMINIT, DISCOVERY and FWLOAD stages were observed");
    wait_until_ready(1, maxcyc);
    check(ready_cnt >= 1 && pass_cnt >= 1, "firmware reported DEVICE READY after a passing self-test");
    check(fail_cnt == 0 && fatal_cnt == 0 && line_fails == 0, "no self-test failure, fatal trap or failed firmware check");
    check(ready() && !fault(), "SYS: device ready, no fault");
    for (int s = 0; s <= 6; s++) check(stage_status(s) == 8'd2, $sformatf("stage %0d status OK", s));
    check(err_code() == 0, "no boot error latched");
    wait_cycles(200);
    host_identity_tests();
    host_regtable_tests();
    host_priv_tests();
    host_mailbox_tests();

    // host-requested warm reset, then a complete second boot
    $display("TB: host-requested warm reset");
    check(dut.u_ks.u_sys.boot_count_q == 8'd1, "boot counter is 1");
    hwr(KS_H_RESET_REQ, {KS_KEY_RESET, 16'h0}, 2'd2);
    check(!he, "OPERATOR reset request with the key is accepted");
    begin
      int t = 0; bit saw_reset = 0, saw_eng_reset = 0;
      while (!saw_reset && t < 200) begin @(posedge clk); t++; if (!core_rst_n) saw_reset = 1; end
      check(saw_reset, "warm reset asserted");
      t = 0;
      while (core_rst_n === 1'b0 && t < 200) begin @(posedge clk); t++; if (dut.eng_rst_n === 5'b0) saw_eng_reset = 1; end
      check(saw_eng_reset, "all engines were reset with the system");
      check(core_rst_n === 1'b1, "warm reset released");
    end
    wait_until_ready(2, maxcyc);
    check(ready_cnt == 2 && pass_cnt == 2, "second boot reached DEVICE READY with a passing self-test");
    hrd(KS_H_RESET_CAUSE, 2'd0);  check_eq(hv & 32'hF, 32'h9, "RESET_CAUSE: power-on (retained) + host");
    hrd(KS_H_BOOT_STAGE, 2'd0);   check_eq(hv[15:8], 32'd2, "boot counter is 2");
    hrd(KS_H_SEC_COUNT, 2'd0);    check(hv > 0, "security record survived the warm reset");
    check(fail_cnt == 0 && fatal_cnt == 0 && line_fails == 0, "second boot: no failures");
  endtask

  task automatic run_wdt();
    int t;
    wait_until_ready(1, maxcyc);
    check(ready_cnt == 1, "first boot reached DEVICE READY");
    check(dut.u_ks.u_wdt.lock_q === 1'b1, "watchdog is locked");
    check(dut.u_ks.u_wdt.en_q === 1'b1 && dut.u_ks.u_wdt.rst_en_q === 1'b1, "watchdog is enabled with reset on bite");
    t = 0;
    while (core_rst_n === 1'b1 && t < 100000) begin @(posedge clk); t++; end
    check(core_rst_n === 1'b0, "the watchdog bite caused a warm reset");
    check(t < 20000, $sformatf("bite arrived within the programmed window (%0d clocks after READY)", t));
    t = 0;
    while (core_rst_n === 1'b0 && t < 100) begin @(posedge clk); t++; end
    check_eq(dut.u_ks.u_sys.cause_q, 32'h3, "reset cause recorded: POR + WDT");
    wait_until_ready(2, maxcyc);
    check(ready_cnt == 2, "second boot reached DEVICE READY");
    check(wdt_obs == 1, "firmware observed the watchdog reset and what survived it");
    check(fail_cnt == 0 && fatal_cnt == 0 && line_fails == 0, "no failed firmware checks in either boot");
    hrd(KS_H_RESET_CAUSE, 2'd0);  check_eq(hv & 32'hF, 32'h0, "reset cause was cleared by the firmware");
  endtask

  task automatic run_regs();
    wait_until_ready(1, maxcyc);
    check(ready_cnt == 1 && pass_cnt == 1, "register walker finished and the device reported READY");
    check(fail_cnt == 0 && fatal_cnt == 0 && line_fails == 0, "no register-map violation");
  endtask

  task automatic run_fail_scenario(input int stage, input int code);
    int t = 0;
    while (!(cpu_sleeping && fault()) && t < maxcyc) begin @(posedge clk); t++; end
    wait_cycles(200);
    check(!ready(), "device is NOT ready after a failed boot");
    check(fault(), "FAULT flag set");
    check(int'(err_stage()) == stage, $sformatf("error stage == %0d (got %0d)", stage, err_stage()));
    check(int'(err_code()) == code, $sformatf("error code == 0x%0x (got 0x%0x)", code, err_code()));
    check(stage_status(stage) == (8'h80 | 8'(code)), "failed stage byte = FAILED|code");
    check(stage_status(stage + 1) == 8'd0, "later stages not started");
    check(cpu_sleeping, "ROM halted in the safe WFI loop");
    // the failure is visible to the host
    hrd(KS_H_BOOT_ERR, 2'd0);      check_eq(hv, {1'b1, 19'd0, 4'(stage), 1'b0, 7'(code)}, "host BOOT_ERR");
    hrd(KS_H_SYS_STATUS, 2'd0);    check(!hv[0] && hv[1], "host SYS_STATUS: not ready, fault");
    hrd(KS_H_BOOT_STAGE, 2'd0);    check(hv[16], "host BOOT_STAGE.FAULT");
    // and a host cannot start work on a failed device
    hwr(KS_H_MBX_CTRL, 32'd1, 2'd3);   check(he, "doorbell refused while the device is not ready");
  endtask

  // ------------------------------------------------------------------ main
  task automatic finish_run();
    if (done_flag) return;
    done_flag = 1;
    $display("TB: cycles=%0d", cyc);
    $display("TB RESULT: %s checks=%0d errors=%0d", (errors == 0) ? "PASS" : "FAIL", checks, errors);
    $finish;
  endtask

  initial begin
    if (!$value$plusargs("scenario=%s", scenario)) scenario = "boot";
    if (!$value$plusargs("maxcyc=%d", maxcyc)) maxcyc = 12_000_000;
    if (!$value$plusargs("fws_lat=%d", fws_lat)) fws_lat = 2;
    for (int i = 0; i < FWS_WORDS; i++) fws_mem[i] = 32'd0;
    if ($value$plusargs("fw=%s", fwfile) && scenario != "nofw") $readmemh(fwfile, fws_mem);
    // image corruption scenarios: flip bits in the firmware store before reset release
    if (scenario == "badcrc")   fws_mem[40] = fws_mem[40] ^ 32'h0000_0100;      // payload bit
    if (scenario == "badhdr")   fws_mem[3]  = fws_mem[3]  ^ 32'h0000_0004;      // header (size) -> header CRC mismatch
    if (scenario == "badrange") begin fws_mem[2] = 32'h0020_0000; fws_mem[7] = 32'(crc32_hdr()); end   // consistent header, load address outside IRAM
    $display("TB: scenario=%s fw=%s", scenario, fwfile);
    repeat (20) @(posedge clk);
    rst_n = 1'b1;
    case (scenario)
      "boot":     run_boot();
      "wdt":      run_wdt();
      "regs":     run_regs();
      "nofw":     run_fail_scenario(KS_STAGE_FWLOAD, KS_BERR_FW_NO_IMAGE);
      "badcrc":   run_fail_scenario(KS_STAGE_FWLOAD, KS_BERR_FW_BAD_CRC);
      "badhdr":   run_fail_scenario(KS_STAGE_FWLOAD, KS_BERR_FW_BAD_HDR);
      "badrange": run_fail_scenario(KS_STAGE_FWLOAD, KS_BERR_FW_BAD_RANGE);
      default:    check(1'b0, "unknown scenario");
    endcase
    finish_run();
  end
endmodule
`default_nettype wire
