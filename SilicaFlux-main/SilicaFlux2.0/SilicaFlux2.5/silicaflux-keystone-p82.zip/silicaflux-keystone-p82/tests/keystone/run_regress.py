#!/usr/bin/env python3
"""Keystone regression: everything that backs a claim in docs/keystone, in one command.

  run_regress.py [--toolchains gnu,llvm] [--jobs N] [--report reports/regression.md] [--quick]

Steps (each is a PASS/FAIL row in the report):
  regs     register-map generator tests, generated files current
  vendor   third_party/ hashes
  lint     Verilator -Wall, control subsystem and full system, zero warnings required
  unit     SRAM ECC (exhaustive), interrupt controller vs reference model, AXI shared buffer
  for each toolchain (GNU riscv64-unknown-elf-gcc, LLVM clang+lld):
    build    boot ROM + three firmware images (selftest, wdt, regs), ROM image -> RTL, Verilator simulation
    sim      boot, nofw, badcrc, badhdr, badrange, wdt, regs
"""
import argparse, concurrent.futures as cf, os, re, shutil, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))
FW = os.path.join(ROOT, "firmware", "keystone")
BUILD = os.path.join(ROOT, "build")
LOGS = os.path.join(ROOT, "reports", "logs")
VERILATOR_FLAGS = ["--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-WIDTHEXPAND",
                   "--x-assign", "0", "--x-initial", "0", "-CFLAGS", "-O1"]
results = []          # (step, name, ok, detail)


def run(cmd, log, cwd=ROOT, timeout=3600):
    os.makedirs(os.path.dirname(log), exist_ok=True)
    t = time.time()
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    with open(log, "w") as f:                                  # keep logs portable: no absolute paths of the machine that ran them
        f.write((f"$ {' '.join(cmd)}\n\n{p.stdout}").replace(ROOT, "<project>"))
    return p.returncode, p.stdout, time.time() - t


def record(step, name, ok, detail=""):
    results.append((step, name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {step:8s} {name:34s} {detail}", flush=True)


def tool_ok(tc):
    return shutil.which("riscv64-unknown-elf-gcc") if tc == "gnu" else (shutil.which("clang") and shutil.which("ld.lld") and shutil.which("llvm-objcopy"))


def step_static():
    rc, out, _ = run([sys.executable, "scripts/test_regmap.py"], f"{LOGS}/regmap.log")
    m = re.search(r"regmap tests: (\d+)/(\d+)", out)
    record("regs", "register map validator + generated files", rc == 0, m.group(0) if m else "")
    rc, out, _ = run([sys.executable, "scripts/check_vendor.py"], f"{LOGS}/vendor.log")
    record("vendor", "third_party hashes", rc == 0, out.strip().splitlines()[-1] if out.strip() else "")
    for name, top, flist, extra in (("control subsystem", "sf_keystone_control", "rtl/files.f", []),
                                    ("full system + real CloudDMA", "sf_keystone_albion_sys", "rtl/files_sys.f",
                                     ["third_party/silicaflux-clouddma-p64/rtl/lint.vlt"])):
        rc, out, _ = run(["verilator", "--lint-only", "-Wall", "rtl/lint.vlt"] + extra + ["--top-module", top, "-f", flist], f"{LOGS}/lint_{top}.log")
        n = len(re.findall(r"%Warning", out))
        record("lint", name, rc == 0 and n == 0, f"{n} warnings")


def step_icarus():
    """Second-tool check: Icarus Verilog 12 ELABORATES the RTL (no Icarus simulation is run)."""
    if not shutil.which("iverilog"):
        record("elab", "Icarus Verilog", False, "iverilog not installed")
        return
    os.makedirs(BUILD, exist_ok=True)
    def files(f):
        return [l.strip() for l in open(os.path.join(ROOT, f)) if l.strip() and not l.startswith("#") and not l.startswith("-")]
    base = files("rtl/files.f")
    full = base + [x for x in files("rtl/files_sys.f")]
    for name, top, fl in (("control subsystem", "sf_keystone_control", base), ("full system + real CloudDMA", "sf_keystone_albion_sys", full)):
        rc, out, _ = run(["iverilog", "-g2012", "-s", top, "-o", f"{BUILD}/{top}.vvp", "-Ithird_party/silicaflux-ras-p26/rtl",
                          "-Ithird_party/silicaflux-clouddma-p64/rtl"] + fl, f"{LOGS}/iverilog_{top}.log")
        errs = len(re.findall(r"error", out))
        record("elab", f"Icarus 12: {name}", rc == 0 and errs == 0, f"{errs} errors (elaboration only)")


def step_unit():
    units = [("sram_ecc", "tb_sram_ecc", ["third_party/silicaflux-ras-p26/rtl/sfras_secded_enc.sv", "third_party/silicaflux-ras-p26/rtl/sfras_secded_dec.sv", "rtl/albion/sf_keystone_sram.sv"]),
             ("intc", "tb_intc", ["rtl/albion/generated/sf_keystone_regs_pkg.sv", "rtl/albion/sf_keystone_interrupts.sv"]),
             ("shm_axi", "tb_shm_axi", ["rtl/albion/sf_keystone_shm.sv"])]

    def one(u):
        name, top, files = u
        mdir = f"{BUILD}/unit/{name}"
        os.makedirs(mdir, exist_ok=True)
        rc, out, _ = run(["verilator"] + VERILATOR_FLAGS + ["-Ithird_party/silicaflux-ras-p26/rtl", "--top-module", top] + files +
                         [f"tests/keystone/unit/tb_{name}.sv", "-Mdir", mdir, "-o", top], f"{LOGS}/unit_{name}_build.log")
        if rc:
            return name, False, "build failed"
        rc, out, _ = run([f"{mdir}/{top}"], f"{LOGS}/unit_{name}.log")
        m = re.search(r"UNIT (PASS|FAIL) \S+ checks=(\d+) errors=(\d+)", out)
        return name, bool(m and m.group(1) == "PASS" and rc == 0), (f"checks={m.group(2)} errors={m.group(3)}" if m else "no result line")

    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        for name, ok, detail in ex.map(one, units):
            record("unit", name, ok, detail)


def step_toolchain(tc):
    if not tool_ok(tc):
        record("build", f"[{tc}] toolchain", False, "not installed")
        return
    fwb = f"{FW}/build/{tc}"
    shutil.rmtree(fwb, ignore_errors=True)                       # always a clean, reproducible build
    ok = True
    rc_rom = 0
    for scen in ("selftest", "wdt", "regs"):
        rc, out, _ = run(["make", "-C", FW, f"TOOLCHAIN={tc}", "all" if scen == "selftest" else "fw", f"SCENARIO={scen}"], f"{LOGS}/fw_{tc}_{scen}.log")
        warn = len(re.findall(r"warning:", out))
        sz = re.search(r"^\s*(\d+)\s+\d+\s+\d+\s+\d+\s+[0-9a-f]+\s+\S*fw\.elf", out, re.M)
        record("build", f"[{tc}] firmware {scen}", rc == 0 and warn == 0, f"{sz.group(1) + ' bytes text of 32768, ' if sz else ''}{warn} compiler warnings")
        ok &= rc == 0
        if scen == "selftest":
            rsz = re.search(r"^\s*(\d+)\s+\d+\s+\d+\s+\d+\s+[0-9a-f]+\s+\S*rom\.elf", out, re.M)
            record("build", f"[{tc}] boot ROM", rc == 0 and os.path.exists(f"{fwb}/rom.bin"), f"{rsz.group(1)} of 8192 bytes" if rsz else "")
    if not ok:
        return
    simdir = f"{BUILD}/sim_{tc}"
    os.makedirs(simdir, exist_ok=True)
    img = f"{simdir}/sf_keystone_bootrom_image.sv"
    run([sys.executable, "scripts/mkrom.py", f"{fwb}/rom.bin", img], f"{LOGS}/mkrom_{tc}.log")
    if tc == "gnu":                                                # the ROM image shipped in rtl/albion/generated is the GNU build
        same = open(img).read() == open(f"{ROOT}/rtl/albion/generated/sf_keystone_bootrom_image.sv").read()
        record("build", "[gnu] shipped ROM image == fresh build", same, "rtl/albion/generated/sf_keystone_bootrom_image.sv" if same else "STALE: run `make rom-image`")
    flist = open(f"{ROOT}/rtl/files_sys.f").read().replace("rtl/albion/generated/sf_keystone_bootrom_image.sv", img)
    # files_sys.f includes files.f by reference: expand it so the ROM image path can be substituted
    flist = flist.replace("-f rtl/files.f", open(f"{ROOT}/rtl/files.f").read().replace("rtl/albion/generated/sf_keystone_bootrom_image.sv", img))
    with open(f"{simdir}/files.f", "w") as f:
        f.write(flist)
    rc, out, dt = run(["verilator"] + VERILATOR_FLAGS + ["-Itests/keystone/sim", "--top-module", "tb_keystone", "-f", f"{simdir}/files.f",
                      "tests/keystone/sim/tb_keystone.sv", "-Mdir", f"{simdir}/obj", "-o", "tb_keystone"], f"{LOGS}/simbuild_{tc}.log")
    record("build", f"[{tc}] Verilator system model", rc == 0, f"{dt:.0f} s")
    if rc:
        return
    exe = f"{simdir}/obj/tb_keystone"
    scen = [("boot", "selftest", 40_000_000), ("nofw", "selftest", 3_000_000), ("badcrc", "selftest", 3_000_000),
            ("badhdr", "selftest", 3_000_000), ("badrange", "selftest", 3_000_000), ("wdt", "wdt", 10_000_000), ("regs", "regs", 10_000_000)]

    def one(s):
        name, fwn, maxc = s
        rc, out, dt = run([exe, f"+scenario={name}", f"+fw={fwb}/{fwn}/fw_image.hex", f"+maxcyc={maxc}"], f"{LOGS}/sim_{tc}_{name}.log")
        m = re.search(r"TB RESULT: (PASS|FAIL) checks=(\d+) errors=(\d+)", out)
        fwm = re.findall(r"SELFTEST PASSED checks=(\d+)", out)
        cyc = re.search(r"TB: cycles=(\d+)", out)
        extra = f" fw-checks={'+'.join(fwm)}" if fwm else ""
        return name, bool(m and m.group(1) == "PASS" and rc == 0), (f"tb-checks={m.group(2)}{extra} cycles={cyc.group(1) if cyc else '?'}" if m else "no result line")

    with cf.ThreadPoolExecutor(max_workers=3) as ex:
        for name, ok, detail in ex.map(one, scen):
            record("sim", f"[{tc}] scenario {name}", ok, detail)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--toolchains", default="gnu,llvm")
    ap.add_argument("--report", default="reports/regression.md")
    ap.add_argument("--no-static", action="store_true")
    ap.add_argument("--no-unit", action="store_true")
    a = ap.parse_args()
    os.makedirs(LOGS, exist_ok=True)
    t0 = time.time()
    if not a.no_static:
        step_static()
        step_icarus()
    if not a.no_unit:
        step_unit()
    for tc in a.toolchains.split(","):
        if tc:
            step_toolchain(tc.strip())
    npass = sum(1 for r in results if r[2])
    rep = os.path.join(ROOT, a.report)
    os.makedirs(os.path.dirname(rep), exist_ok=True)
    with open(rep, "w") as f:
        f.write("# Keystone regression report\n\n")
        f.write(f"Generated by `tests/keystone/run_regress.py` in {time.time() - t0:.0f} s. **{npass} / {len(results)} steps passed.**\n\n")
        f.write("| Step | Check | Result | Detail |\n|---|---|---|---|\n")
        for step, name, ok, detail in results:
            f.write(f"| {step} | {name} | {'PASS' if ok else '**FAIL**'} | {detail} |\n")
        f.write("\nLogs: `reports/logs/`. Evidence level: RTL simulation (Verilator 5.020), no FPGA, no silicon.\n")
    print(f"\n{npass}/{len(results)} steps passed -> {a.report}")
    return 0 if npass == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
