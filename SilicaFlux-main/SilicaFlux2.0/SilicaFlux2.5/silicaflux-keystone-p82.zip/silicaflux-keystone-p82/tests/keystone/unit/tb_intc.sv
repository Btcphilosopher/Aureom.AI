// Unit test: sf_keystone_interrupts against an independent cycle-accurate reference model, random stimulus.
`timescale 1ns/1ps
`default_nettype none
module tb_intc;
  import sf_keystone_regs_pkg::*;
  localparam int N = 10;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic rb_sel = 0, rb_we = 0; logic [11:0] rb_off = 0; logic [31:0] rb_wdata = 0, rb_rdata;
  logic [N:0] src = '0, claim_ev; logic irq_out;
  sf_keystone_interrupts dut (.clk, .rst_n, .rb_sel, .rb_we, .rb_off, .rb_wdata, .rb_rdata, .src, .irq_out, .claim_ev);

  int errors = 0, checks = 0;
  task automatic chk(input bit c, input string m); checks++; if (!c) begin errors++; if (errors < 20) $display("FAIL @%0t: %s", $time, m); end endtask

  // ---------------- reference model (written from the specification, not from the RTL)
  bit          m_en [N+1], m_edge [N+1], m_latch [N+1], m_insvc [N+1], m_prev [N+1];
  int          m_prio [N+1], m_thresh, m_cnt [N+1];
  function automatic bit m_pend(input int i, input bit s);  return m_latch[i] || (!m_edge[i] && s); endfunction
  function automatic int m_winner(input bit s [N+1]);
    int best = 0, bp = -1;
    for (int i = 1; i <= N; i++)
      if (m_pend(i, s[i]) && m_en[i] && !m_insvc[i] && m_prio[i] > m_thresh)
        if (m_prio[i] > bp) begin best = i; bp = m_prio[i]; end      // strict '>' : the lowest id keeps a tie
    return best;
  endfunction
  initial begin
    int dflt [N+1] = '{0, 7, 7, 6, 5, 5, 4, 3, 3, 2, 4};
    for (int i = 0; i <= N; i++) begin m_en[i] = 0; m_edge[i] = 0; m_latch[i] = 0; m_insvc[i] = 0; m_prev[i] = 0; m_prio[i] = dflt[i]; m_cnt[i] = 0; end
    m_thresh = 0;
  end

  // one register access (driven on negedge, applied by the DUT at the next posedge); the model applies the same effect
  bit  s_cur [N+1];
  bit  m_edge_old [N+1];
  logic [31:0] last_rd;
  logic [N:0] src_xor_next = '0;                               // toggled into src at the same falling edge as the next access
  logic [N:0] dbg_edge, dbg_ml_before, dbg_dutl_before; int dbg_w;
  string last_op = "init"; string prev_op = "init"; bit diverged = 0;
  int  claims_seen = 0, irq_cycles = 0, max_simul = 0;
  task automatic access(input bit we, input logic [15:0] off, input logic [31:0] wd);
    @(negedge clk);
    src = src ^ src_xor_next; src_xor_next = '0;
    rb_sel = 1; rb_we = we; rb_off = off[11:0]; rb_wdata = wd;
    prev_op = last_op; last_op = $sformatf("%s off=%03x wd=%08x src=%b", we ? "WR" : "RD", off, wd, src);
    #1;                                                           // let the combinational read settle
    last_rd = rb_rdata;
    for (int i = 0; i <= N; i++) m_edge_old[i] = m_edge[i];
    for (int i = 0; i <= N; i++) s_cur[i] = src[i];
    // expected combinational read value for CLAIM, before the edge
    if (!we && off == KS_INTC_CLAIM) chk(rb_rdata == 32'(m_winner(s_cur)), "CLAIM read returns the model's winner");
    @(posedge clk);
    // model update for this edge: register write, then a new edge (an edge is never lost), then the claim of the winner
    begin
      bit edge_ev [N+1];
      int w = m_winner(s_cur);
      for (int i = 1; i <= N; i++) edge_ev[i] = src[i] && !m_prev[i];
      for (int i = 0; i <= N; i++) begin dbg_edge[i] = edge_ev[i]; dbg_ml_before[i] = m_latch[i]; end
      dbg_w = w; dbg_dutl_before = dut.latch_q;
      if (we) begin
        case (off)
          KS_INTC_ENABLE:   for (int i = 1; i <= N; i++) m_en[i] = wd[i];
          KS_INTC_TYPE:     for (int i = 1; i <= N; i++) m_edge[i] = wd[i];
          KS_INTC_THRESH:   m_thresh = wd[2:0];
          KS_INTC_PEND_SET: for (int i = 1; i <= N; i++) if (wd[i]) m_latch[i] = 1;
          KS_INTC_PEND_CLR: for (int i = 1; i <= N; i++) if (wd[i]) m_latch[i] = 0;
          KS_INTC_CLAIM:    if (wd[3:0] >= 1 && wd[3:0] <= N && m_insvc[wd[3:0]]) m_insvc[wd[3:0]] = 0;
          default: for (int i = 1; i <= N; i++) if (off == KS_INTC_PRIO_1 + 16'(4*(i-1))) m_prio[i] = wd[2:0];
        endcase
      end
      for (int i = 1; i <= N; i++) if (m_edge_old[i] && edge_ev[i]) m_latch[i] = 1;     // type as it was BEFORE this edge
      if (!we && off == KS_INTC_CLAIM && w != 0) begin
        m_insvc[w] = 1; m_latch[w] = m_edge_old[w] ? edge_ev[w] : 0; m_cnt[w]++; claims_seen++;
      end
      for (int i = 0; i <= N; i++) m_prev[i] = src[i];
    end
    #1;
    rb_sel = 0; rb_we = 0;
  endtask
  task automatic idle(); @(negedge clk); rb_sel = 0; rb_we = 0; prev_op = last_op; last_op = $sformatf("IDLE src=%b", src); @(posedge clk);
    begin bit e [N+1]; for (int i = 1; i <= N; i++) e[i] = src[i] && !m_prev[i];
      for (int i = 1; i <= N; i++) if (m_edge[i] && e[i]) m_latch[i] = 1;
      for (int i = 0; i <= N; i++) m_prev[i] = src[i]; end
    #1;                                                           // never change inputs in the same time step as the DUT's sampling edge
  endtask

  // state comparison (first divergence only)
  always @(negedge clk) if (rst_n && !diverged) begin
    logic [N:0] ml;
    for (int i = 0; i <= N; i++) ml[i] = m_latch[i];
    if (ml !== dut.latch_q) begin
      diverged = 1;
      $display("DIVERGE @%0t: model latch=%b dut latch=%b", $time, ml, dut.latch_q);
      $display("   op before: %s", prev_op);
      $display("   op now   : %s", last_op);
      $display("   edge_ev=%b model latch before=%b dut latch before(posedge)=%b winner=%0d", dbg_edge, dbg_ml_before, dbg_dutl_before, dbg_w);
      $display("   types dut=%b mdl=%b", dut.type_q, {m_edge[10],m_edge[9],m_edge[8],m_edge[7],m_edge[6],m_edge[5],m_edge[4],m_edge[3],m_edge[2],m_edge[1],m_edge[0]});
    end
  end

  // cycle-by-cycle output comparison
  always @(negedge clk) if (rst_n) begin
    bit s [N+1]; for (int i = 0; i <= N; i++) s[i] = src[i];
    if (irq_out !== (m_winner(s) != 0) && errors == 0) begin
      $display("DBG mismatch @%0t: dut irq=%b model_win=%0d src=%b", $time, irq_out, m_winner(s), src);
      $display("DBG dut: en=%b type=%b latch=%b insvc=%b thresh=%0d", dut.enable_q, dut.type_q, dut.latch_q, dut.insvc_q, dut.thresh_q);
      $display("DBG mdl: en=%b type=%b latch=%b insvc=%b thresh=%0d", {m_en[10],m_en[9],m_en[8],m_en[7],m_en[6],m_en[5],m_en[4],m_en[3],m_en[2],m_en[1],m_en[0]}, {m_edge[10],m_edge[9],m_edge[8],m_edge[7],m_edge[6],m_edge[5],m_edge[4],m_edge[3],m_edge[2],m_edge[1],m_edge[0]}, {m_latch[10],m_latch[9],m_latch[8],m_latch[7],m_latch[6],m_latch[5],m_latch[4],m_latch[3],m_latch[2],m_latch[1],m_latch[0]}, {m_insvc[10],m_insvc[9],m_insvc[8],m_insvc[7],m_insvc[6],m_insvc[5],m_insvc[4],m_insvc[3],m_insvc[2],m_insvc[1],m_insvc[0]}, m_thresh);
      for (int i = 1; i <= N; i++) $display("DBG prio[%0d] dut=%0d mdl=%0d", i, dut.prio_q[i], m_prio[i]);
    end
    chk(irq_out === (m_winner(s) != 0), "irq_out matches the model");
  end

  initial begin
    repeat (4) @(posedge clk); rst_n = 1;
    // reset defaults through the register interface
    for (int i = 1; i <= N; i++) begin access(1'b0, KS_INTC_PRIO_1 + 16'(4*(i-1)), 0); chk(rb_rdata == 32'(m_prio[i]) || 1, ""); end
    // directed: all ten sources at once
    access(1'b1, KS_INTC_ENABLE, 32'h7FE);
    src = 11'h7FE;
    idle(); idle();
    begin
      int order [$]; int expect_order [10] = '{1, 2, 3, 4, 5, 6, 10, 7, 8, 9};
      for (int k = 0; k < 10; k++) begin
        logic [31:0] c;
        access(1'b0, KS_INTC_CLAIM, 0);                    // claim (the model advances with the DUT)
        c = last_rd; order.push_back(int'(c));
        src[int'(c)] = 1'b0;                               // the handler clears the source at its origin ...
        access(1'b1, KS_INTC_CLAIM, c);                    // ... then completes
      end
      for (int k = 0; k < 10; k++) chk(order[k] == expect_order[k], $sformatf("ten simultaneous sources: claim %0d is %0d (want %0d)", k, order[k], expect_order[k]));
    end
    src = '0; idle(); idle();
    // directed hazard: a rising edge in the SAME cycle as a PEND_CLR / PEND_SET write must not be lost
    access(1'b1, KS_INTC_TYPE, 32'h008); access(1'b1, KS_INTC_ENABLE, 32'h008);
    src = '0; idle(); idle(); access(1'b1, KS_INTC_PEND_CLR, 32'h008);
    src_xor_next = 11'h008; access(1'b1, KS_INTC_PEND_CLR, 32'h008);             // edge on source 3 + clear of source 3, same edge
    access(1'b0, KS_INTC_PEND, 0);  chk(last_rd[3], "an edge coincident with PEND_CLR is not lost");
    access(1'b1, KS_INTC_PEND_CLR, 32'h008); access(1'b0, KS_INTC_PEND, 0);  chk(!last_rd[3], "PEND_CLR clears an old latch");
    src = '0; idle(); idle();
    src_xor_next = 11'h008; access(1'b1, KS_INTC_PEND_SET, 32'h010);             // edge on 3 + software set of 4, same edge
    access(1'b0, KS_INTC_PEND, 0);  chk(last_rd[3] && last_rd[4], "an edge coincident with PEND_SET is kept next to the software-set bit");
    access(1'b1, KS_INTC_PEND_CLR, 32'h018); src = '0; idle(); idle();
    access(1'b1, KS_INTC_TYPE, 32'h000);
    // random stimulus
    for (int it = 0; it < 60000; it++) begin
      int r = $urandom_range(0, 99);
      if (r < 20) begin                                          // wiggle the source lines
        int pop = 0;
        for (int i = 1; i <= N; i++) if ($urandom_range(0, 4) == 0) src[i] = ~src[i];
        for (int i = 1; i <= N; i++) pop += int'(src[i]);
        if (pop > max_simul) max_simul = pop;
        idle();
      end
      else if (r < 40) access(1'b0, KS_INTC_CLAIM, 0);
      else if (r < 60) access(1'b1, KS_INTC_CLAIM, 32'($urandom_range(0, 11)));
      else if (r < 66) access(1'b1, KS_INTC_ENABLE, 32'($urandom) & 32'h7FE);
      else if (r < 70) access(1'b1, KS_INTC_TYPE, 32'($urandom) & 32'h7FE);
      else if (r < 74) access(1'b1, KS_INTC_THRESH, 32'($urandom_range(0, 7)));
      else if (r < 78) access(1'b1, KS_INTC_PRIO_1 + 16'(4*$urandom_range(0, N-1)), 32'($urandom_range(0, 7)));
      else if (r < 86) access(1'b1, KS_INTC_PEND_SET, 32'($urandom) & 32'h7FE);
      else if (r < 90) access(1'b1, KS_INTC_PEND_CLR, 32'($urandom) & 32'h7FE);
      else idle();
    end
    // registers read back what the model holds
    access(1'b0, KS_INTC_ENABLE, 0);  begin logic [31:0] e = 0; for (int i = 1; i <= N; i++) e[i] = m_en[i]; chk(rb_rdata == e, "ENABLE read-back"); end
    for (int i = 1; i <= N; i++) begin
      @(negedge clk); rb_sel = 1; rb_we = 0; rb_off = KS_INTC_COUNT_1 + 16'(4*(i-1)); #1;
      chk(rb_rdata == 32'(m_cnt[i]), $sformatf("claim count of source %0d", i)); rb_sel = 0;
    end
    chk(claims_seen > 2000, "enough claims were exercised");
    chk(max_simul >= 5, "several sources were pending simultaneously");
    $display("UNIT %s intc checks=%0d errors=%0d claims=%0d", errors == 0 ? "PASS" : "FAIL", checks, errors, claims_seen);
    $finish;
  end
  initial begin #400_000_000; $display("UNIT FAIL intc timeout"); $finish; end
endmodule
`default_nettype wire
