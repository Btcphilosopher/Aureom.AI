// Unit test: sf_keystone_shm -- AXI4 slave burst behaviour against a reference memory, with concurrent CPU traffic.
`timescale 1ns/1ps
`default_nettype none
module tb_shm_axi;
  localparam int ID_W = 4;
  localparam logic [31:0] BASE = 32'h0030_0000;
  localparam int DEPTH64 = 256;                       // 2 KiB
  logic clk = 0, rst_n = 0; always #5 clk = ~clk;
  logic c_req = 0, c_gnt, c_we = 0, c_rvalid, c_err; logic [3:0] c_be = 0; logic [31:0] c_addr = 0, c_wdata = 0, c_rdata;
  logic ar_valid = 0, ar_ready; logic [ID_W-1:0] ar_id = 0; logic [31:0] ar_addr = 0; logic [7:0] ar_len = 0; logic [2:0] ar_size = 3; logic [1:0] ar_burst = 1;
  logic r_valid, r_ready = 1, r_last; logic [ID_W-1:0] r_id; logic [63:0] r_data; logic [1:0] r_resp;
  logic aw_valid = 0, aw_ready; logic [ID_W-1:0] aw_id = 0; logic [31:0] aw_addr = 0; logic [7:0] aw_len = 0; logic [2:0] aw_size = 3; logic [1:0] aw_burst = 1;
  logic w_valid = 0, w_ready; logic [63:0] w_data = 0; logic [7:0] w_strb = 0; logic w_last = 0;
  logic b_valid, b_ready = 1; logic [ID_W-1:0] b_id; logic [1:0] b_resp; logic axi_err_ev;
  sf_keystone_shm #(.DEPTH64(DEPTH64), .ID_W(ID_W), .BASE(BASE)) dut (
    .clk, .rst_n, .c_req, .c_gnt, .c_we, .c_be, .c_addr, .c_wdata, .c_rvalid, .c_rdata, .c_err,
    .s_ar_valid(ar_valid), .s_ar_ready(ar_ready), .s_ar_id(ar_id), .s_ar_addr(ar_addr), .s_ar_len(ar_len), .s_ar_size(ar_size), .s_ar_burst(ar_burst),
    .s_r_valid(r_valid), .s_r_ready(r_ready), .s_r_id(r_id), .s_r_data(r_data), .s_r_resp(r_resp), .s_r_last(r_last),
    .s_aw_valid(aw_valid), .s_aw_ready(aw_ready), .s_aw_id(aw_id), .s_aw_addr(aw_addr), .s_aw_len(aw_len), .s_aw_size(aw_size), .s_aw_burst(aw_burst),
    .s_w_valid(w_valid), .s_w_ready(w_ready), .s_w_data(w_data), .s_w_strb(w_strb), .s_w_last(w_last),
    .s_b_valid(b_valid), .s_b_ready(b_ready), .s_b_id(b_id), .s_b_resp(b_resp), .axi_err_ev);
  int errors = 0, checks = 0;
  task automatic chk(input bit c, input string m); checks++; if (!c) begin errors++; if (errors < 20) $display("FAIL @%0t: %s", $time, m); end endtask

  logic [7:0] ref_mem [DEPTH64*8];
  int err_events = 0;
  always @(negedge clk) if (axi_err_ev) err_events++;
  bit b_seen = 0; logic [ID_W-1:0] b_id_q; logic [1:0] b_resp_q;
  always @(negedge clk) if (b_valid && b_ready) begin b_seen = 1; b_id_q = b_id; b_resp_q = b_resp; end

  // CPU traffic runs concurrently on its own addresses (upper half of the memory)
  logic [7:0] cpu_ref [256];
  bit cpu_run = 0;
  // ready/grant are combinational on state: sample them at the falling edge; the following rising edge completes the transfer
  task automatic cpu_wait_gnt();
    #1; while (!c_gnt) begin @(negedge clk); #1; end
    @(posedge clk);
  endtask
  initial begin
    for (int i = 0; i < 256; i++) cpu_ref[i] = 0;
    forever begin
      @(negedge clk);
      if (cpu_run) begin
        int a = $urandom_range(0, 63);
        c_addr = BASE + 32'(DEPTH64*8 - 256 + 4*a); c_req = 1;
        if ($urandom_range(0, 1)) begin
          logic [31:0] w = $urandom; logic [3:0] be = 4'($urandom_range(1, 15));
          c_we = 1; c_be = be; c_wdata = w;
          cpu_wait_gnt();
          for (int b = 0; b < 4; b++) if (be[b]) cpu_ref[4*a+b] = w[8*b +: 8];
          @(negedge clk); c_req = 0; c_we = 0;
        end else begin
          c_we = 0; c_be = 4'hF;
          cpu_wait_gnt();
          @(negedge clk); c_req = 0;
          chk(c_rvalid && c_rdata == {cpu_ref[4*a+3], cpu_ref[4*a+2], cpu_ref[4*a+1], cpu_ref[4*a]}, "CPU read matches the reference");
        end
      end else begin c_req = 0; end
    end
  end

  task automatic axi_write(input int id, input logic [31:0] addr, input int beats, input bit expect_ok);
    logic [7:0] data [64][8];
    int errs0 = err_events;
    b_seen = 0;
    @(negedge clk); aw_valid = 1; aw_id = ID_W'(id); aw_addr = addr; aw_len = 8'(beats - 1);
    #1; while (!aw_ready) begin @(negedge clk); #1; end
    @(posedge clk); @(negedge clk); aw_valid = 0;
    for (int k = 0; k < beats; k++) begin
      logic [63:0] d = {$urandom, $urandom}; logic [7:0] s = 8'($urandom);
      w_valid = 1; w_data = d; w_strb = s; w_last = (k == beats - 1);
      if (expect_ok) for (int b = 0; b < 8; b++) if (s[b]) ref_mem[(addr - BASE) + 8*k + b] = d[8*b +: 8];
      #1; while (!w_ready) begin @(negedge clk); #1; end
      @(posedge clk); @(negedge clk); w_valid = 0; w_last = 0;
      if ($urandom_range(0, 3) == 0) repeat ($urandom_range(1, 3)) @(negedge clk);     // gaps between beats
    end
    while (!b_seen) @(negedge clk);
    chk(b_id_q == ID_W'(id), "B id echoed");
    chk(expect_ok ? (b_resp_q == 2'b00) : (b_resp_q == 2'b10), expect_ok ? "OKAY write response" : "SLVERR write response");
    if (!expect_ok) chk(err_events > errs0, "error event pulsed");
    @(negedge clk);
  endtask

  bit skip_data = 0;                                    // the last 256 bytes belong to the CPU traffic: the AXI reference does not track them
  int ok_beats_override = -1;                           // >= 0: only the first N beats are inside the window
  task automatic axi_read(input int id, input logic [31:0] addr, input int beats, input bit expect_ok);
    int got = 0;
    int okb = (ok_beats_override >= 0) ? ok_beats_override : (expect_ok ? beats : 0);
    @(negedge clk); ar_valid = 1; ar_id = ID_W'(id); ar_addr = addr; ar_len = 8'(beats - 1);
    #1; while (!ar_ready) begin @(negedge clk); #1; end
    @(posedge clk); @(negedge clk); ar_valid = 0;
    while (got < beats) begin
      @(negedge clk);
      r_ready = $urandom_range(0, 3) != 0;                      // back-pressure on R
      if (r_valid && r_ready) begin
        chk(r_id == ID_W'(id), "R id echoed");
        chk(r_last == (got == beats - 1), "RLAST on the final beat only");
        if (got < okb) begin
          chk(r_resp == 2'b00, "OKAY read response");
          if (!skip_data) for (int b = 0; b < 8; b++) chk(r_data[8*b +: 8] == ref_mem[(addr - BASE) + 8*got + b], "AXI read data matches the reference");
        end else chk(r_resp == 2'b10 && r_data == 0, "SLVERR read beat with zero data");
        got++;
      end
    end
    r_ready = 1; @(negedge clk);
  endtask

  initial begin
    for (int i = 0; i < DEPTH64*8; i++) ref_mem[i] = 0;
    repeat (4) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);
    // zero the memory through AXI (full strobes) so the reference matches
    for (int k = 0; k < (DEPTH64*8 - 256)/64; k++) begin
      b_seen = 0;
      @(negedge clk); aw_valid = 1; aw_addr = BASE + 32'(64*k); aw_len = 7; aw_id = 0;
      #1; while (!aw_ready) begin @(negedge clk); #1; end
      @(posedge clk); @(negedge clk); aw_valid = 0;
      for (int b = 0; b < 8; b++) begin w_valid = 1; w_data = 0; w_strb = 8'hFF; w_last = (b == 7); #1; while (!w_ready) begin @(negedge clk); #1; end @(posedge clk); @(negedge clk); w_valid = 0; w_last = 0; end
      while (!b_seen) @(negedge clk); @(negedge clk);
    end
    // directed: single beat, 16-beat burst, IDs
    axi_write(3, BASE + 32'h40, 1, 1);
    axi_read(3, BASE + 32'h40, 1, 1);
    axi_write(9, BASE + 32'h100, 16, 1);
    axi_read(9, BASE + 32'h100, 16, 1);
    cpu_run = 1;
    // random bursts with the CPU hammering the same memory
    for (int i = 0; i < 400; i++) begin
      int beats = $urandom_range(1, 16);
      logic [31:0] a = BASE + 32'(8 * $urandom_range(0, (DEPTH64*8 - 256)/8 - 16));
      if ($urandom_range(0, 1)) axi_write($urandom_range(0, 15), a, beats, 1);
      else                      axi_read($urandom_range(0, 15), a, beats, 1);
    end
    cpu_run = 0; repeat (6) @(negedge clk);
    // protocol / range errors answer SLVERR for every beat and change nothing
    ar_size = 2; axi_read(1, BASE, 3, 0); ar_size = 3;
    ar_burst = 0; axi_read(2, BASE, 2, 0); ar_burst = 1;
    ok_beats_override = 1; skip_data = 1; axi_read(5, BASE + 32'(DEPTH64*8) - 8, 4, 0); ok_beats_override = -1; skip_data = 0;   // beat 0 is inside the window, beats 1..3 run off its end
    axi_read(6, 32'h0040_0000, 2, 0);                                // outside the window
    aw_size = 1; axi_write(7, BASE + 32'h200, 2, 0); aw_size = 3;
    axi_write(8, 32'h0040_0000, 3, 0);
    axi_read(4, BASE + 32'h200, 2, 1);                                // the refused writes changed nothing
    chk(err_events >= 6, "error events counted");
    $display("UNIT %s shm_axi checks=%0d errors=%0d", errors == 0 ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
  initial begin #80_000_000; $display("UNIT FAIL shm_axi timeout"); $finish; end
endmodule
`default_nettype wire
