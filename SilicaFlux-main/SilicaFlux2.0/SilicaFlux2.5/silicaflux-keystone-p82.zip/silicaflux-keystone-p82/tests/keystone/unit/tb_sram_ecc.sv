// Unit test: sf_keystone_sram -- SECDED per byte lane, initialisation, arbitration, injection, byte-accurate reference.
`timescale 1ns/1ps
`default_nettype none
module tb_sram_ecc;
  localparam int DEPTH = 64;
  logic clk = 0, por_rst_n = 0, rst_n = 0;
  always #5 clk = ~clk;
  // port A / B
  logic a_req = 0, a_gnt, a_rvalid, a_err; logic [31:0] a_addr = 0, a_rdata;
  logic b_req = 0, b_gnt, b_we = 0, b_rvalid, b_err; logic [3:0] b_be = 0; logic [31:0] b_addr = 0, b_wdata = 0, b_rdata;
  logic init_done, ev_valid, ev_ce, ev_ue, ev_iport, inj_fired;
  logic [31:0] ev_addr; logic [1:0] ev_lane; logic [4:0] ev_synd;
  logic inj_arm = 0; logic [31:0] inj_addr = 0; logic [1:0] inj_lane = 0; logic [12:0] inj_mask = 0;

  sf_keystone_sram #(.DEPTH(DEPTH)) dut (.*);

  int errors = 0, checks = 0;
  task automatic chk(input bit c, input string m); checks++; if (!c) begin errors++; $display("FAIL: %s", m); end endtask

  int n_ce, n_ue; logic last_iport; logic [1:0] last_lane;
  always @(negedge clk) if (ev_valid) begin
    if (ev_ce) n_ce++;
    if (ev_ue) n_ue++;
    last_iport = ev_iport; last_lane = ev_lane;
  end

  // ---- drive on the falling edge, sample the registered response on the next falling edge (race free)
  logic [31:0] rd_data; bit rd_err;
  task automatic bwrite(input logic [31:0] addr, input logic [31:0] data, input logic [3:0] be);
    @(negedge clk); b_req = 1; b_we = 1; b_addr = addr; b_wdata = data; b_be = be;
    @(negedge clk); chk(b_rvalid, "write response one cycle after the grant"); b_req = 0; b_we = 0; #1;
  endtask
  task automatic bread(input logic [31:0] addr);
    @(negedge clk); b_req = 1; b_we = 0; b_addr = addr;
    @(negedge clk); chk(b_rvalid, "read response one cycle after the grant"); rd_data = b_rdata; rd_err = b_err; b_req = 0; #1;
  endtask
  task automatic aread(input logic [31:0] addr);
    @(negedge clk); a_req = 1; a_addr = addr;
    @(negedge clk); chk(a_rvalid, "port A response one cycle after the grant"); rd_data = a_rdata; rd_err = a_err; a_req = 0; #1;
  endtask
  task automatic inject(input logic [31:0] addr, input int lane, input logic [12:0] mask);
    @(negedge clk); inj_addr = addr; inj_lane = 2'(lane); inj_mask = mask; inj_arm = 1;
  endtask
  task automatic disarm(); @(negedge clk); inj_arm = 0; endtask

  logic [31:0] ref_mem [DEPTH];
  initial begin
    // ---- initialisation sweep
    repeat (3) @(posedge clk);
    por_rst_n = 1; rst_n = 1;
    chk(!init_done, "init not done right after reset");
    b_req = 1; @(posedge clk); #1; chk(!b_gnt, "no grant during the init sweep"); b_req = 0;
    while (!init_done) @(posedge clk);
    chk(1, "init completes");
    for (int i = 0; i < DEPTH; i++) begin bread(32'(4*i)); chk(rd_data == 0 && !rd_err, "memory reads as zero after the sweep"); ref_mem[i] = 0; end
    chk(n_ce == 0 && n_ue == 0, "no ECC events after init");

    // ---- every byte value in every lane round-trips
    for (int l = 0; l < 4; l++) for (int v = 0; v < 256; v++) begin
      logic [31:0] w = $urandom; w[8*l +: 8] = 8'(v);
      bwrite(32'h10, w, 4'hF); bread(32'h10);
      chk(rd_data == w && !rd_err, "byte value round trip");
    end
    chk(n_ce == 0 && n_ue == 0, "no ECC events for clean data");

    // ---- every single-bit error (13 stored bits x 4 lanes) is corrected
    for (int l = 0; l < 4; l++) for (int j = 0; j < 13; j++) begin
      logic [31:0] w = $urandom; int ce0 = n_ce;
      inject(32'h20, l, 13'(1 << j));
      bwrite(32'h20, w, 4'hF);
      disarm();
      bread(32'h20);
      chk(rd_data == w, $sformatf("single-bit error lane %0d bit %0d corrected", l, j));
      chk(!rd_err, "no error response for a correctable error");
      chk(n_ce == ce0 + 1 && last_lane == 2'(l) && !last_iport, "CE event reported with the right lane");
      bwrite(32'h20, w, 4'hF);
    end
    // ---- every double-bit error in a lane is detected, never silently returned as data
    for (int l = 0; l < 4; l++) for (int i = 0; i < 13; i++) for (int j = i + 1; j < 13; j++) begin
      logic [31:0] w = $urandom; int ue0 = n_ue, ce0 = n_ce;
      inject(32'h24, l, 13'((1 << i) | (1 << j)));
      bwrite(32'h24, w, 4'hF);
      disarm();
      bread(32'h24);
      chk(rd_err, $sformatf("double-bit error lane %0d bits %0d,%0d detected", l, i, j));
      chk(n_ue == ue0 + 1 && n_ce == ce0, "UE event, no CE event");
      bwrite(32'h24, 32'h0, 4'hF);
    end
    // ---- an injection only fires when the write covers its lane
    begin
      int ce0 = n_ce, ue0 = n_ue;
      inject(32'h28, 2, 13'h3);
      bwrite(32'h28, 32'h11111111, 4'b0001);               // lane 0 only: not covered
      bread(32'h28); chk(rd_data[7:0] == 8'h11 && !rd_err, "uncovered lane: no corruption");
      chk(n_ce == ce0 && n_ue == ue0, "no event");
      bwrite(32'h28, 32'h22222222, 4'b0100);               // lane 2: fires
      disarm();
      bread(32'h28); chk(rd_err, "the armed injection fired on the covered lane");
      bwrite(32'h28, 32'h0, 4'hF);
    end

    // ---- randomised byte-accurate comparison against a reference
    for (int i = 0; i < DEPTH; i++) begin bwrite(32'(4*i), 32'h0, 4'hF); ref_mem[i] = 0; end
    for (int i = 0; i < 6000; i++) begin
      int a = $urandom_range(0, DEPTH - 1);
      if ($urandom_range(0, 1)) begin
        logic [31:0] w = $urandom; logic [3:0] be = 4'($urandom_range(1, 15));
        bwrite(32'(4*a), w, be);
        for (int b = 0; b < 4; b++) if (be[b]) ref_mem[a][8*b +: 8] = w[8*b +: 8];
      end else begin
        bread(32'(4*a));
        chk(rd_data == ref_mem[a] && !rd_err, "random read matches the reference");
      end
    end
    // ---- arbitration: B wins, A is granted when B is idle; both responses exactly one cycle later
    @(negedge clk); a_req = 1; a_addr = 32'h8; b_req = 1; b_we = 0; b_addr = 32'hC;
    #1; chk(b_gnt && !a_gnt, "port B has priority");
    @(negedge clk); chk(b_rvalid && !a_rvalid, "only B responds");
    b_req = 0; #1; chk(a_gnt, "port A is granted once B is idle");
    @(negedge clk); chk(a_rvalid && a_rdata == ref_mem[2], "A response"); a_req = 0;
    // ---- instruction-side events are labelled
    begin
      int ue0 = n_ue;
      inject(32'h2C, 1, 13'h5); bwrite(32'h2C, 32'hFFFF, 4'hF); disarm();
      aread(32'h2C); chk(rd_err, "port A sees the uncorrectable error");
      chk(n_ue == ue0 + 1 && last_iport, "event flagged as instruction port");
    end
    $display("UNIT %s sram_ecc checks=%0d errors=%0d", errors == 0 ? "PASS" : "FAIL", checks, errors);
    $finish;
  end
  initial begin #50_000_000; $display("UNIT FAIL sram_ecc timeout"); $finish; end
endmodule
`default_nettype wire
