# Provenance of `third_party/`

Every file below is copied **byte-for-byte** from an archive of the repository `btcphilosopher/Aureom.AI` and is **never edited**.
`scripts/check_vendor.py --repo <SilicaFlux-main>` re-proves this against the archives; `check_vendor.py` alone checks SHA256SUMS.

| Vendored tree | Source archive (repository path) | Archive SHA-256 | Why it is here |
|---|---|---|---|
| `silicaflux-mcu-i/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-mcu-i.zip` | `f2dd5bdac590883a3949c38a1973f32a8651c42bdc46569fee9f4d29f5013c23` | RV32IM_Zicsr CPU `mcu_cpu` (MCU-I, derived from SilicaFlux-V); the verified CPU Keystone reuses |
| `silicaflux-ras-p26/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-ras-project26.zip` | `0a49d1a08232edbc913341ca73f138aef92e8e2d270d4b4c17f3e4f1a7114943` | SECDED extended-Hamming encoder / decoder used per byte lane by the local ECC SRAM |
| `silicaflux-clouddma-p64/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-clouddma-p64.zip` | `0c51df9ce2ebfc99138714cfeb74fdc20903ad422eaedf6e281690391df2a794` | CloudDMA (Project 64): the REAL peripheral configured and driven by the firmware (+ its 2 vendored FIFO / arbiter helpers) |

**License:** no license file exists in the repository; none is carried here. An owner must decide before external distribution.

| File | Archive member | SHA-256 |
|---|---|---|
| `silicaflux-clouddma-p64/rtl/filelist.f` | `silicaflux-clouddma-p64/rtl/filelist.f` | `51010425b69416f9d4900d6e282dbe6506f9966524d44dee27fe05d62832abf0` |
| `silicaflux-clouddma-p64/rtl/lint.vlt` | `silicaflux-clouddma-p64/rtl/lint.vlt` | `fa2ff46c12d723d526314be0eeb258b65d3ddca615c71d7999d59c701578bcf7` |
| `silicaflux-clouddma-p64/rtl/sfdma_axi_mux.sv` | `silicaflux-clouddma-p64/rtl/sfdma_axi_mux.sv` | `9733a524a08d5c2926aef51b55a5c4c78b7961451f842562ad66c1333c0a9f0a` |
| `silicaflux-clouddma-p64/rtl/sfdma_burst_ctrl.sv` | `silicaflux-clouddma-p64/rtl/sfdma_burst_ctrl.sv` | `9be2284e81a543a11bd1bf0db77f1abafe5cbc4e7eacfb3c44bffbf5aa3ae780` |
| `silicaflux-clouddma-p64/rtl/sfdma_burst_plan.sv` | `silicaflux-clouddma-p64/rtl/sfdma_burst_plan.sv` | `7d5d542c299c8c3526e4bf6cb790dab2a8107eda1c50643807b3e3af8db21777` |
| `silicaflux-clouddma-p64/rtl/sfdma_bytebuf.sv` | `silicaflux-clouddma-p64/rtl/sfdma_bytebuf.sv` | `1c6be5d39572b2a63d35b2cc535e5efd245d7765b6e1a1c2fc787e3a7398e54c` |
| `silicaflux-clouddma-p64/rtl/sfdma_channel.sv` | `silicaflux-clouddma-p64/rtl/sfdma_channel.sv` | `fe3f13c707076f9977da0bb996b535591e509ced10ab4a1750558f70073308e7` |
| `silicaflux-clouddma-p64/rtl/sfdma_crc.sv` | `silicaflux-clouddma-p64/rtl/sfdma_crc.sv` | `52036cd313c4cf4459b0f552819798f3f9909d536f45a8fefd3334944842a154` |
| `silicaflux-clouddma-p64/rtl/sfdma_csr.sv` | `silicaflux-clouddma-p64/rtl/sfdma_csr.sv` | `e86701fa27e10824add0962725dc23bc19835f979035082b8d79578ec572b54e` |
| `silicaflux-clouddma-p64/rtl/sfdma_desc_walker.sv` | `silicaflux-clouddma-p64/rtl/sfdma_desc_walker.sv` | `b3c7cdc4262afc5ea613c0976d1b8519da4f89565815033dd1e924b556bc572f` |
| `silicaflux-clouddma-p64/rtl/sfdma_perf.sv` | `silicaflux-clouddma-p64/rtl/sfdma_perf.sv` | `89cdf7425c839f0517d829fe3a18beb3f32ce7f1f74ad3ae3349bcaa05bdfab4` |
| `silicaflux-clouddma-p64/rtl/sfdma_perm_checker.sv` | `silicaflux-clouddma-p64/rtl/sfdma_perm_checker.sv` | `6e09223c5c3d6e285533b400dc769f817a34005706d81399da9fafd36f5df9d1` |
| `silicaflux-clouddma-p64/rtl/sfdma_perm_table.sv` | `silicaflux-clouddma-p64/rtl/sfdma_perm_table.sv` | `faa3251f3dfe666546f6bfb3ae4069e2a7a5e464759ad85604c21e6080d155f1` |
| `silicaflux-clouddma-p64/rtl/sfdma_trace.sv` | `silicaflux-clouddma-p64/rtl/sfdma_trace.sv` | `2508726e4fb461db42d08264e70707ea6383eece7d371f8851da2a3351a80b9a` |
| `silicaflux-clouddma-p64/rtl/silicaflux_cloud_dma.sv` | `silicaflux-clouddma-p64/rtl/silicaflux_cloud_dma.sv` | `10fd4462ed80f82c8c8691e9feccf9b5a60ab6752828c26cc693d4139ec9b72e` |
| `silicaflux-clouddma-p64/rtl/silicaflux_dma_pkg.sv` | `silicaflux-clouddma-p64/rtl/silicaflux_dma_pkg.sv` | `62812fa7a9df2235b798f5dbf84cbf612807466495e73dddf9ec3d6e6d966ed8` |
| `silicaflux-clouddma-p64/third_party/p61-clouddpu/rtl/sfd_fifo.sv` | `silicaflux-clouddma-p64/third_party/p61-clouddpu/rtl/sfd_fifo.sv` | `2ed30198724e40893d6ac778dcd6b3b1d51023a87f729291612304ae5c657ddb` |
| `silicaflux-clouddma-p64/third_party/p61-clouddpu/rtl/sfd_rr_arb.sv` | `silicaflux-clouddma-p64/third_party/p61-clouddpu/rtl/sfd_rr_arb.sv` | `91eb468276ce73e3ac91ffb36ac56729d2fa16da3732b5ef33c17eb92a48344a` |
| `silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv` | `silicaflux-mcu-i/rtl/cpu/mcu_cpu.sv` | `8b8f42f36c7976b9453b2a4c5f9cd2ab72672f67ad371a773da68cbc12739230` |
| `silicaflux-ras-p26/rtl/sfras_defs.svh` | `silicaflux-ras/rtl/sfras_defs.svh` | `af06beb45166e3f75e2b0e56a9d54f0cf7eb33e94584859428f0c4db59e980ac` |
| `silicaflux-ras-p26/rtl/sfras_ecc_funcs.svh` | `silicaflux-ras/rtl/sfras_ecc_funcs.svh` | `b34b9d923e5f6422391826fa8da4f684b647ccc2c41680e455e61cead424e780` |
| `silicaflux-ras-p26/rtl/sfras_secded_dec.sv` | `silicaflux-ras/rtl/sfras_secded_dec.sv` | `571840dcb0f9c494f6f1c4b95699e9241d669552415aa47ca117e619bb1b4e42` |
| `silicaflux-ras-p26/rtl/sfras_secded_enc.sv` | `silicaflux-ras/rtl/sfras_secded_enc.sv` | `19cae462eb4c9b7fd5de565ea561a9c3d198d7356018db9d5411f8791d0b0693` |
