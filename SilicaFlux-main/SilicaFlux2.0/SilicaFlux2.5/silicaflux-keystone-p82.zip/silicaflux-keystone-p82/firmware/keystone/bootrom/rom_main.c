/* Keystone boot ROM.  RESET -> ROM -> MEMORY INIT -> DEVICE DISCOVERY -> FIRMWARE LOAD -> (management firmware).
 *
 * Every stage reports RUNNING and then OK or FAILED(code) through SYS.BOOT_REPORT; the hardware enforces the
 * order and latches the first error.  On failure the ROM stops in a safe WFI loop with the error visible to the host.
 *
 * Firmware integrity: header CRC32 + payload CRC32 + copy verification.  This is an INTEGRITY check against
 * accidental corruption.  It is NOT authentication: no signature is verified (SYS.CAPS2.AUTH_BOOT = 0). */
#include "ks_hal.h"

#define LOG(s) ks_puts(s)

static void rom_fail(uint32_t stage, uint32_t code)
{
    LOG("[ROM] FAIL stage=");
    ks_putdec(stage);
    LOG(" code=0x");
    ks_puthex(code);
    ks_putc('\n');
    ks_boot_fail(stage, code);
    for (;;) ks_wfi();
}

static void stage_begin(uint32_t stage)
{
    KS_CSRW(mscratch, stage);               /* the trap handler reports against this stage */
    ks_boot_report(stage, KS_BSTAT_RUNNING);
}

static void stage_ok(uint32_t stage, const char *name)
{
    ks_boot_report(stage, KS_BSTAT_OK);
    LOG("[ROM] ");
    LOG(name);
    LOG(" ok\n");
}

/* ---- MEMORY INITIALISATION */
static void memory_init(void)
{
    stage_begin(KS_STAGE_MEMINIT);
    /* RAS counters are always-on state: they survive a warm reset, so compare against the value on entry */
    const uint32_t ue_in = ks_rd(KS_RAS_UE_COUNT), ce_in = ks_rd(KS_RAS_CE_COUNT);
    const uint32_t need = KS_SYS_SYS_STATUS_MEM_INIT_IRAM_MASK | KS_SYS_SYS_STATUS_MEM_INIT_DRAM_MASK;
    uint32_t i;
    for (i = 0; i < 400000u; i++)
        if ((ks_rd(KS_SYS_SYS_STATUS) & need) == need) break;
    if (i == 400000u) rom_fail(KS_STAGE_MEMINIT, KS_BERR_MEMINIT_TIMEOUT);

    /* data-pattern + byte-lane test of the first 2 KiB of DRAM and 1 KiB of IRAM, then clear it */
    volatile uint32_t *d = (volatile uint32_t *)(uintptr_t)KS_DRAM_BASE;
    volatile uint32_t *c = (volatile uint32_t *)(uintptr_t)KS_IRAM_BASE;
    for (i = 0; i < 512u; i++) d[i] = 0xA5A5A5A5u ^ (i * 0x01010101u);
    for (i = 0; i < 512u; i++)
        if (d[i] != (0xA5A5A5A5u ^ (i * 0x01010101u))) rom_fail(KS_STAGE_MEMINIT, KS_BERR_MEMINIT_PATTERN);
    for (i = 0; i < 512u; i++) d[i] = ~d[i];
    for (i = 0; i < 512u; i++)
        if (d[i] != ~(0xA5A5A5A5u ^ (i * 0x01010101u))) rom_fail(KS_STAGE_MEMINIT, KS_BERR_MEMINIT_PATTERN);
    volatile uint8_t *db = (volatile uint8_t *)(uintptr_t)KS_DRAM_BASE;
    for (i = 0; i < 4u; i++) db[i] = (uint8_t)(0x11u * (i + 1u));       /* byte stores into one word */
    if (d[0] != 0x44332211u) rom_fail(KS_STAGE_MEMINIT, KS_BERR_MEMINIT_PATTERN);
    for (i = 0; i < 256u; i++) c[i] = 0x5A5AA5A5u + i;
    for (i = 0; i < 256u; i++)
        if (c[i] != 0x5A5AA5A5u + i) rom_fail(KS_STAGE_MEMINIT, KS_BERR_MEMINIT_PATTERN);
    for (i = 0; i < 512u; i++) d[i] = 0;
    for (i = 0; i < 256u; i++) c[i] = 0;
    volatile uint32_t *s = (volatile uint32_t *)(uintptr_t)KS_SHM_BASE;   /* shared buffer: no hardware init */
    for (i = 0; i < KS_SHM_SIZE / 4u; i++) s[i] = 0;
    /* ECC must have been quiet during the test */
    if (ks_rd(KS_RAS_UE_COUNT) != ue_in || ks_rd(KS_RAS_CE_COUNT) != ce_in) rom_fail(KS_STAGE_MEMINIT, KS_BERR_MEMINIT_ECC);
    stage_ok(KS_STAGE_MEMINIT, "meminit");
}

/* ---- DEVICE DISCOVERY */
static uint32_t discover(void)
{
    stage_begin(KS_STAGE_DISCOVERY);
    static const uint32_t ids[KS_NUM_ENG] = {KS_DMA_ID, KS_PKT_ID, KS_MPL_ID, KS_CPW_ID, KS_VIO_ID};
    uint32_t present = 0;
    const uint32_t caps0 = ks_rd(KS_SYS_CAPS0);
    for (uint32_t e = 0; e < KS_NUM_ENG; e++) {
        const uint32_t sh = ks_rd(KS_ESH(e, KS_ESH_CAPS));
        const uint32_t p = sh & KS_ESH_CAPS_PRESENT_MASK;
        if (p != ((caps0 >> e) & 1u)) rom_fail(KS_STAGE_DISCOVERY, KS_BERR_DISC_BAD_ID);   /* SYS.CAPS0 and shell disagree */
        if (ks_rd(KS_ESH(e, KS_ESH_ID)) != ids[e]) rom_fail(KS_STAGE_DISCOVERY, KS_BERR_DISC_BAD_ID);
        if (p) present |= 1u << e;
    }
    if (!present) rom_fail(KS_STAGE_DISCOVERY, KS_BERR_DISC_NO_ENGINE);
    LOG("[ROM] engines=0x");
    ks_puthex(present);
    ks_putc('\n');
    stage_ok(KS_STAGE_DISCOVERY, "discovery");
    return present;
}

/* ---- FIRMWARE LOAD: header + payload CRC32, bounds, copy to IRAM, read-back verify */
static void load_firmware(void)
{
    stage_begin(KS_STAGE_FWLOAD);
    const volatile ks_fw_hdr_t *h = (const volatile ks_fw_hdr_t *)(uintptr_t)KS_FWST_BASE;
    ks_fw_hdr_t hd;
    for (uint32_t i = 0; i < 8u; i++) ((uint32_t *)&hd)[i] = ((const volatile uint32_t *)h)[i];

    if (hd.magic != KS_FW_MAGIC) rom_fail(KS_STAGE_FWLOAD, KS_BERR_FW_NO_IMAGE);
    if (~ks_crc32_update(0xFFFFFFFFu, (const uint8_t *)&hd, 28u) != hd.hdr_crc || hd.hdr_version != KS_FW_HDR_VERSION)
        rom_fail(KS_STAGE_FWLOAD, KS_BERR_FW_BAD_HDR);
    const uint32_t sz = hd.size;
    if ((hd.load_addr & 3u) || (sz & 3u) || sz == 0u || hd.load_addr < KS_IRAM_BASE || hd.load_addr > KS_IRAM_BASE + KS_IRAM_SIZE ||
        sz > KS_IRAM_BASE + KS_IRAM_SIZE - hd.load_addr || sz > KS_FWST_SIZE - KS_FW_HDR_BYTES || hd.entry < hd.load_addr ||
        hd.entry >= hd.load_addr + sz || (hd.entry & 3u))
        rom_fail(KS_STAGE_FWLOAD, KS_BERR_FW_BAD_RANGE);

    const volatile uint32_t *src = (const volatile uint32_t *)(uintptr_t)(KS_FWST_BASE + KS_FW_HDR_BYTES);
    uint32_t crc = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < sz / 4u; i++) {
        uint32_t w = src[i];
        crc = ks_crc32_update(crc, (const uint8_t *)&w, 4u);
    }
    if (~crc != hd.payload_crc) rom_fail(KS_STAGE_FWLOAD, KS_BERR_FW_BAD_CRC);

    volatile uint32_t *dst = (volatile uint32_t *)(uintptr_t)hd.load_addr;
    for (uint32_t i = 0; i < sz / 4u; i++) dst[i] = src[i];
    crc = 0xFFFFFFFFu;
    for (uint32_t i = 0; i < sz / 4u; i++) {
        uint32_t w = dst[i];
        crc = ks_crc32_update(crc, (const uint8_t *)&w, 4u);
    }
    if (~crc != hd.payload_crc) rom_fail(KS_STAGE_FWLOAD, KS_BERR_FW_COPY_VERIFY);
    ks_wr(KS_SYS_FW_VERSION, hd.fw_version);
    stage_ok(KS_STAGE_FWLOAD, "fwload");
    LOG("[ROM] jump 0x");
    ks_puthex(hd.entry);
    ks_putc('\n');
    ks_fence_i();
    ((void (*)(void))(uintptr_t)hd.entry)();
}

void rom_main(void)
{
    stage_begin(KS_STAGE_ROM);
    LOG("[ROM] Keystone boot ROM cause=0x");
    ks_puthex(ks_rd(KS_SYS_RESET_CAUSE));
    ks_putc('\n');
    stage_ok(KS_STAGE_ROM, "rom");
    memory_init();
    (void)discover();
    load_firmware();
    stage_begin(KS_STAGE_MGMT_FW);                      /* firmware returned: should never happen */
    rom_fail(KS_STAGE_MGMT_FW, KS_BERR_FW_INIT_FAIL);
}
