/* Keystone management firmware: shared declarations. */
#ifndef KS_FW_H
#define KS_FW_H

#include "ks_hal.h"

#define KS_FW_VERSION_WORD 0x00010000u    /* must match mkimage --version */

/* ============================================================== platform.c: traps, interrupts, time */
typedef struct {
    uint32_t mepc, mcause, mtval, mstatus;
    uint32_t x[32];                        /* x[n] at byte offset 16 + 4n: x[1] = ra, x[2] = sp (x[0] slot unused) */
} ks_frame_t;

/* the trap_entry.S frame: 144 bytes, mepc@0 mcause@4 mtval@8 mstatus@12 x1@20 ... x31@140 */
_Static_assert(sizeof(ks_frame_t) == 144u, "ks_frame_t must match common/trap_entry.S");
_Static_assert(__builtin_offsetof(ks_frame_t, x[1]) == 20u, "x1 (ra) must be at offset 20");

#define KS_CAUSE_INSN_MISALIGNED  0u
#define KS_CAUSE_INSN_FAULT       1u
#define KS_CAUSE_ILLEGAL          2u
#define KS_CAUSE_BREAKPOINT       3u
#define KS_CAUSE_LOAD_MISALIGNED  4u
#define KS_CAUSE_LOAD_FAULT       5u
#define KS_CAUSE_STORE_MISALIGNED 6u
#define KS_CAUSE_STORE_FAULT      7u
#define KS_CAUSE_ECALL_M          11u

void ks_trap_handler(ks_frame_t *f);
/* Arm an expected exception: it is recorded, then execution resumes after the faulting instruction
 * (resume_ra = 0) or at the saved ra (resume_ra = 1). Any other exception is fatal. */
void ks_expect_trap(uint32_t cause, int resume_ra);
int  ks_trap_hit(void);                    /* 1 if the armed trap occurred; disarms */
uint32_t ks_trap_mtval(void);
uint32_t ks_trap_mepc(void);
void ks_fatal(const char *why);

typedef void (*ks_isr_t)(uint32_t src);
void ks_irq_init(void);                    /* install handlers, set priorities, enable MEI/MTI/MSI sources */
void ks_irq_register(uint32_t src, ks_isr_t fn);
extern volatile uint32_t ks_irq_count[KS_NUM_IRQ + 1];   /* handler invocations per source */
extern volatile uint32_t ks_irq_order[16];               /* claim order log (source ids) */
extern volatile uint32_t ks_irq_order_n;
extern volatile uint32_t ks_mti_count, ks_msi_count;
extern volatile uint32_t ks_spurious;                    /* claims that returned 0 inside the handler loop */
void ks_irq_order_reset(void);

uint32_t ks_now(void);                     /* mtime[31:0] */
/* Poll until *flag != 0 or the timeout (clock cycles) expires; returns 1 on success. */
int  ks_wait_flag(volatile uint32_t *flag, uint32_t timeout_cycles);
void ks_delay(uint32_t cycles);

/* ============================================================== cmdq.c: protected command submission */
typedef struct {
    uint32_t op, target, tenant, priv;
    uint32_t arg[4];
} ks_cmd_t;

typedef struct {
    uint32_t err;                          /* KS_CERR_*  (KS_CERR_OK = 0) */
    uint32_t status;                       /* raw CMD.STATUS at completion */
    uint32_t res0, res1;
    uint32_t eng_err;                      /* CMD.ENG_ERR (engine-reported code) */
} ks_cmd_rsp_t;

#define KS_CMD_DEFAULT_WAIT 2000000u       /* clocks */
uint32_t ks_cmd_submit(const ks_cmd_t *c, ks_cmd_rsp_t *r);          /* polled; returns r->err */
uint32_t ks_cmd_submit_irq(const ks_cmd_t *c, ks_cmd_rsp_t *r);      /* completes via the CMD interrupt */
extern volatile uint32_t ks_cmd_irq_flag;

/* ============================================================== mgmt.c: device management */
typedef struct {
    uint32_t present, real, enabled;       /* engine masks */
    uint32_t num_tenants, num_queues;
    uint32_t eng_id[KS_NUM_ENG];
    uint32_t hw_version, fw_version, caps2;
    uint32_t ras_ce, ras_ue;
} ks_device_t;

extern ks_device_t ks_dev;
uint32_t ks_min_priv(uint32_t op);                                   /* software copy of the privilege table */
uint32_t ks_mgmt_exec(const ks_cmd_t *c, uint32_t caller_priv, ks_cmd_rsp_t *r);   /* privilege-checked command */
void     ks_discover(void);                                          /* capability discovery */
uint32_t ks_engine_enable(uint32_t eng, uint32_t on);
uint32_t ks_engine_reset(uint32_t eng);
uint32_t ks_tenant_setup(uint32_t tenant, uint32_t domain, uint32_t engmask);
uint32_t ks_tenant_clear(uint32_t tenant);
uint32_t ks_queue_create(uint32_t eng, uint32_t tenant, uint32_t qid, uint32_t base, uint32_t depth);
uint32_t ks_queue_destroy(uint32_t eng, uint32_t tenant, uint32_t qid);
uint32_t ks_queue_doorbell(uint32_t eng, uint32_t tenant, uint32_t qid, uint32_t tail);
typedef struct {
    uint64_t cycles, instret;
    uint32_t sleep, mmio_rd, mmio_wr, bus_err, exc, intr, cmd_acc, cmd_err, ras_ce, ras_ue, wdt_kicks, sec_viol;
    uint32_t eng_evt[KS_NUM_ENG], eng_flt[KS_NUM_ENG], irq_claims[KS_NUM_IRQ + 1];
    uint32_t seq;
} ks_perf_t;
uint32_t ks_perf_snapshot(ks_perf_t *p);                             /* atomic hardware snapshot */
uint32_t ks_recover_engine(uint32_t eng);                            /* abort, reset, re-enable */
void     ks_mbx_service(void);                                       /* handle one pending host mailbox request */
extern volatile uint32_t ks_mbx_flag;
extern volatile uint32_t ks_mbx_served;
extern volatile uint32_t ks_eng_events[KS_NUM_ENG];       /* OR of shell IRQ_STAT bits seen by the ISR (EVENT|FAULT|VIOL) */
extern volatile uint32_t ks_sec_seen, ks_ras_seen, ks_wdt_barks;
void     ks_default_isrs(void);                                      /* register the production ISRs */
#define KS_HOST_OP_INFO 0xF0u                                        /* host mailbox opcode handled by firmware (no hardware command) */

/* ============================================================== fault.c: fault reporting */
#define KS_FAULT_SRC_FW   0u
#define KS_FAULT_SRC_CMD  1u
#define KS_FAULT_SRC_ENG  2u
#define KS_FAULT_SRC_RAS  3u
#define KS_FAULT_SRC_SEC  4u
#define KS_FAULT_SRC_WDT  5u
typedef struct { uint32_t when, src, code, arg0, arg1; } ks_fault_t;
void ks_fault_report(uint32_t src, uint32_t code, uint32_t a0, uint32_t a1);
uint32_t ks_fault_count(void);
const ks_fault_t *ks_fault_get(uint32_t index_from_oldest);
void ks_fault_dump(void);

/* ============================================================== dma.c: CloudDMA driver */
#define KS_DMA_ENABLE_BIT 1u
#define KS_DMA_CSR(off)   (KS_DMA_BASE + KS_ENG_PASS_OFF + (off))
/* descriptor (64 bytes), CloudDMA ABI 1.0 (docs/02_DESCRIPTOR_FORMAT.md) */
typedef struct {
    uint32_t w0, w1, w2, length;
    uint32_t src_lo, src_hi, dst_lo, dst_hi;
    uint32_t next_lo, next_hi, cpl_lo, cpl_hi;
    uint32_t seq, rsv[3];
} __attribute__((aligned(64))) ks_dma_desc_t;
#define KS_DMA_F_LAST  (1u << 0)
#define KS_DMA_F_ARRAY (1u << 1)
#define KS_DMA_F_HEAD  (1u << 2)
#define KS_DMA_F_ORDERED (1u << 3)
#define KS_DMA_F_CPL_EN (1u << 4)
#define KS_DMA_F_CRC_EN (1u << 5)
typedef struct { uint32_t status, err, fault, txn, domain, bytes, crc; } ks_dma_cpl_t;
extern volatile uint32_t ks_dma_done_flag;
uint32_t ks_dma_init(void);                                          /* enable CloudDMA, set timeout */
uint32_t ks_dma_map(uint32_t idx, uint32_t domain, uint32_t base, uint32_t size, uint32_t pa, uint32_t perm);
uint32_t ks_dma_unmap(uint32_t idx);
void     ks_dma_desc(ks_dma_desc_t *d, uint32_t pos, uint32_t flags, uint32_t txn, uint32_t domain_claim,
                     uint32_t src, uint32_t dst, uint32_t len);
uint32_t ks_dma_submit(uint32_t tenant, uint32_t priv, uint32_t head, ks_cmd_rsp_t *r);
int      ks_dma_wait(ks_dma_cpl_t *c, uint32_t timeout);            /* wait for the completion interrupt, pop the record */
uint32_t ks_dma_copy(uint32_t tenant, uint32_t domain, uint32_t src, uint32_t dst, uint32_t len, ks_dma_cpl_t *c);
uint32_t ks_dma_recover(void);

/* ============================================================== self-test framework (selftest.c) */
extern uint32_t ks_checks, ks_fails;
/* A failed check prints file:line (and the values for _EQ).  The stringified expression is only compiled in with
 * -DKS_CHECK_TEXT=1 (make EXTRA=-DKS_CHECK_TEXT=1): it costs several KiB of the 32 KiB IRAM. */
#ifdef KS_CHECK_TEXT
#define KS_TXT(s) s
#else
#define KS_TXT(s) ""
#endif
void ks_check(int ok, const char *file, uint32_t line, const char *what);
void ks_check_eq(uint32_t a, uint32_t b, const char *file, uint32_t line, const char *what);
#define KS_CHECK(c) ks_check(!!(c), __FILE_NAME__, __LINE__, KS_TXT(#c))
#define KS_CHECK_EQ(a, b) ks_check_eq((uint32_t)(a), (uint32_t)(b), __FILE_NAME__, __LINE__, KS_TXT(#a " == " #b))
void ks_group(const char *name);
int  ks_selftest_run(void);

void t_identity(void);
void t_mmio(void);
void t_exceptions(void);
void t_timer(void);
void t_intc(void);
void t_cmd(void);
void t_engine(void);
void t_queue(void);
void t_dma(void);
void t_ras(void);
void t_wdt(void);
void t_telemetry(void);
void t_fault(void);
void t_simul(void);
void t_regs(void);

#endif
