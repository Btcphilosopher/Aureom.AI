/* Firmware self-test: runs on the RTL CPU after boot.  Failures are printed with the line number. */
#include "ks_fw.h"

uint32_t ks_checks, ks_fails;
static uint32_t g_group_fails;

static void fail_head(const char *file, uint32_t line, const char *what)
{
    ks_fails++;
    g_group_fails++;
    ks_puts("[FW]   FAIL ");
    ks_puts(file);
    ks_putc(':');
    ks_putdec(line);
    if (what[0]) { ks_puts(": "); ks_puts(what); }
}

void ks_check(int ok, const char *file, uint32_t line, const char *what)
{
    ks_checks++;
    if (!ok) { fail_head(file, line, what); ks_putc('\n'); }
}

void ks_check_eq(uint32_t a, uint32_t b, const char *file, uint32_t line, const char *what)
{
    ks_checks++;
    if (a != b) {
        fail_head(file, line, what);
        ks_puts("  (got 0x");
        ks_puthex(a);
        ks_puts(", want 0x");
        ks_puthex(b);
        ks_puts(")\n");
    }
}

void ks_group(const char *name)
{
    ks_puts("[FW] group ");
    ks_puts(name);
    ks_putc('\n');
    g_group_fails = 0;
}

int ks_selftest_run(void)
{
    t_identity();
    t_mmio();
    t_exceptions();
    t_timer();
    t_intc();
    t_cmd();
    t_engine();
    t_queue();
    t_dma();
    t_ras();
    t_wdt();
    t_simul();
    t_telemetry();
    t_fault();
    return ks_fails == 0;
}
