/* Self-test groups: protected command engine, engine control, queues (CPW / VIO models). */
#include "ks_fw.h"

#define ALL_ENG (KS_BIT(KS_ENG_DMA) | KS_BIT(KS_ENG_CPW) | KS_BIT(KS_ENG_VIO))

/* raw submission: bypasses the firmware privilege check so the HARDWARE checks are what is tested */
static uint32_t cmd(uint32_t op, uint32_t tgt, uint32_t ten, uint32_t priv, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3,
                    ks_cmd_rsp_t *r)
{
    ks_cmd_t c = {op, tgt, ten, priv, {a0, a1, a2, a3}};
    ks_cmd_rsp_t rr;
    ks_cmd_submit(&c, r ? r : &rr);
    return (r ? r : &rr)->err;
}
static void settle(void) { ks_delay(400); }                           /* let interrupt handlers run */
#define SEC_BIT(n) KS_BIT(n)

void t_cmd(void)
{
    ks_group("cmd");
    ks_cmd_rsp_t r;
    KS_CHECK_EQ(ks_rd(KS_CMD_STATUS) & 0xFFu, 0u);
    KS_CHECK_EQ(ks_rd(KS_CMD_TIMEOUT), 0x40000u);

    /* provisioning through the command engine (firmware privilege) */
    KS_CHECK_EQ(ks_tenant_setup(1, 3, ALL_ENG), KS_CERR_OK);
    KS_CHECK_EQ(ks_tenant_setup(2, 5, KS_BIT(KS_ENG_DMA)), KS_CERR_OK);
    KS_CHECK_EQ(ks_tenant_setup(3, 7, KS_BIT(KS_ENG_CPW)), KS_CERR_OK);
    KS_CHECK_EQ(ks_rd(KS_CMD_TENANT_TBL(1)), (ALL_ENG << 16) | (3u << 4) | 1u);
    KS_CHECK_EQ(ks_rd(KS_CMD_TENANT_TBL(5)), 0u);
    KS_CHECK_EQ(ks_engine_enable(KS_ENG_CPW, 1), KS_CERR_OK);
    KS_CHECK_EQ(ks_engine_enable(KS_ENG_VIO, 1), KS_CERR_OK);
    KS_CHECK_EQ(ks_engine_enable(KS_ENG_DMA, 1), KS_CERR_OK);
    KS_CHECK_EQ(ks_rd(KS_CMD_ENG_EN), ALL_ENG);

    uint32_t acc = ks_rd(KS_CMD_ACCEPTED), rej = ks_rd(KS_CMD_REJECTED), ok = ks_rd(KS_CMD_COMPLETED);

    /* acceptance, completion, results */
    KS_CHECK_EQ(cmd(KS_OP_NOP, 0, 0, KS_PRIV_GUEST, 0, 0, 0, 0, &r), KS_CERR_OK);
    KS_CHECK(r.status & KS_CMD_STATUS_DONE_MASK);
    KS_CHECK(!(r.status & KS_CMD_STATUS_BUSY_MASK));
    KS_CHECK_EQ(cmd(KS_OP_ECHO, 0, 0, KS_PRIV_GUEST, 0xF0F0F0F0u, 0x0FF00FF0u, 100u, 23u, &r), KS_CERR_OK);
    KS_CHECK_EQ(r.res0, 0xFF00FF00u);
    KS_CHECK_EQ(r.res1, 123u);
    const uint32_t seq0 = (r.status >> 16) & 0xFFFFu;
    KS_CHECK_EQ(cmd(KS_OP_NOP, 0, 0, KS_PRIV_GUEST, 0, 0, 0, 0, &r), KS_CERR_OK);
    KS_CHECK_EQ(((r.status >> 16) & 0xFFFFu), (seq0 + 1u) & 0xFFFFu);       /* sequence number advances per command */

    /* parameter validation (hardware) */
    KS_CHECK_EQ(cmd(0x77, 0, 0, KS_PRIV_FIRMWARE, 0, 0, 0, 0, &r), KS_CERR_BAD_OPCODE);
    KS_CHECK_EQ(cmd(KS_OP_ENG_ENABLE, 7, 0, KS_PRIV_FIRMWARE, 1, 0, 0, 0, &r), KS_CERR_BAD_TARGET);       /* no such engine */
    KS_CHECK_EQ(cmd(KS_OP_ENG_ENABLE, KS_ENG_PKT, 0, KS_PRIV_FIRMWARE, 1, 0, 0, 0, &r), KS_CERR_BAD_TARGET); /* engine absent */
    KS_CHECK_EQ(cmd(KS_OP_ENG_ENABLE, KS_ENG_CPW, 0, KS_PRIV_FIRMWARE, 2, 0, 0, 0, &r), KS_CERR_BAD_ARG);
    KS_CHECK_EQ(cmd(KS_OP_TENANT_SET, 0, 4, KS_PRIV_FIRMWARE, 16, 1, 0, 0, &r), KS_CERR_BAD_ARG);           /* domain > 15 */
    KS_CHECK_EQ(cmd(KS_OP_TENANT_SET, 0, 4, KS_PRIV_FIRMWARE, 1, 0x100, 0, 0, &r), KS_CERR_BAD_ARG);        /* unknown engine bit */
    KS_CHECK_EQ(cmd(KS_OP_DMA_SUBMIT, KS_ENG_CPW, 1, KS_PRIV_TENANT, 0x300000, 0, 0, 0, &r), KS_CERR_BAD_TARGET);
    KS_CHECK_EQ(cmd(KS_OP_DMA_SUBMIT, KS_ENG_DMA, 6, KS_PRIV_TENANT, 0x300000, 0, 0, 0, &r), KS_CERR_BAD_TENANT);   /* tenant 6 not set up */
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 2, KS_PRIV_OPERATOR, 0, 0x300000, 8, 0, &r), KS_CERR_NO_ACCESS);   /* tenant 2: DMA only */
    KS_CHECK_EQ(cmd(KS_OP_DMA_SUBMIT, KS_ENG_DMA, 1, KS_PRIV_TENANT, 0x300020, 0, 0, 0, &r), KS_CERR_BAD_ARG);     /* head not 64-byte aligned */
    KS_CHECK_EQ(cmd(KS_OP_DMA_SUBMIT, KS_ENG_DMA, 1, KS_PRIV_TENANT, 0x300000, 0, 16, 0, &r), KS_CERR_BAD_ARG);    /* asid > 15 */
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 1, KS_PRIV_OPERATOR, 8, 0x300000, 8, 0, &r), KS_CERR_BAD_ARG);     /* queue id 8 */
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 1, KS_PRIV_OPERATOR, 0, 0x300000, 3, 0, &r), KS_CERR_BAD_ARG);     /* depth not a power of 2 */
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 1, KS_PRIV_OPERATOR, 0, 0x300000, 1, 0, &r), KS_CERR_BAD_ARG);
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 1, KS_PRIV_OPERATOR, 0, 0x300000, 512, 0, &r), KS_CERR_BAD_ARG);
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 1, KS_PRIV_OPERATOR, 0, 0x300002, 8, 0, &r), KS_CERR_BAD_ARG);     /* base not word aligned */
    KS_CHECK_EQ(ks_engine_enable(KS_ENG_CPW, 0), KS_CERR_OK);
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 1, KS_PRIV_OPERATOR, 0, 0x300000, 8, 0, &r), KS_CERR_ENG_DISABLED);
    KS_CHECK_EQ(ks_engine_enable(KS_ENG_CPW, 1), KS_CERR_OK);

    /* privilege: the hardware table is enforced and every refusal is a security violation */
    ks_sec_seen = 0;
    KS_CHECK_EQ(cmd(KS_OP_ENG_RESET, KS_ENG_CPW, 0, KS_PRIV_TENANT, 0, 0, 0, 0, &r), KS_CERR_PRIV);
    KS_CHECK_EQ(cmd(KS_OP_TENANT_SET, 0, 4, KS_PRIV_TENANT, 1, 1, 0, 0, &r), KS_CERR_PRIV);
    KS_CHECK_EQ(cmd(KS_OP_DMA_SUBMIT, KS_ENG_DMA, 1, KS_PRIV_GUEST, 0x300000, 0, 0, 0, &r), KS_CERR_PRIV);
    KS_CHECK_EQ(cmd(KS_OP_Q_CREATE, KS_ENG_CPW, 1, KS_PRIV_TENANT, 0, 0x300000, 8, 0, &r), KS_CERR_PRIV);
    KS_CHECK_EQ(cmd(KS_OP_NOP, 0, 0, KS_PRIV_GUEST, 0, 0, 0, 0, &r), KS_CERR_OK);                 /* NOP needs no privilege */
    settle();
    KS_CHECK(ks_sec_seen & SEC_BIT(KS_SEC_PRIV_VIOL));
    KS_CHECK_EQ(ks_rd(KS_CMD_TENANT_TBL(4)), 0u);                                                   /* the refused TENANT_SET changed nothing */
    /* the firmware-level check refuses before the hardware is touched */
    ks_cmd_t pc = {KS_OP_ENG_RESET, KS_ENG_CPW, 0, KS_PRIV_GUEST, {0, 0, 0, 0}};
    const uint32_t acc_pre = ks_rd(KS_CMD_ACCEPTED);
    KS_CHECK_EQ(ks_mgmt_exec(&pc, KS_PRIV_TENANT, &r), KS_CERR_PRIV);
    KS_CHECK_EQ(ks_rd(KS_CMD_ACCEPTED), acc_pre);

    /* submission key */
    ks_sec_seen = 0;
    ks_wr(KS_CMD_OP, KS_OP_NOP); ks_wr(KS_CMD_PRIV, KS_PRIV_FIRMWARE);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);                                                        /* GO without the key */
    KS_CHECK(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_DONE_MASK);
    KS_CHECK_EQ((ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ERRCODE_MASK) >> 8, KS_CERR_BAD_KEY);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_CMD_KEY, 0x12345678u);                                                                 /* wrong key */
    KS_CHECK(!(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ARMED_MASK));
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);
    KS_CHECK_EQ((ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ERRCODE_MASK) >> 8, KS_CERR_BAD_KEY);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_CMD_KEY, KS_KEY_CMD);
    KS_CHECK(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ARMED_MASK);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);
    ks_delay(40);
    KS_CHECK((ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_DONE_MASK) && !(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ERR_MASK));
    KS_CHECK(!(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ARMED_MASK));                                   /* the key was consumed */
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);                                                        /* second GO: no key any more */
    KS_CHECK_EQ((ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ERRCODE_MASK) >> 8, KS_CERR_BAD_KEY);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    settle();
    KS_CHECK(ks_sec_seen & SEC_BIT(KS_SEC_BAD_KEY));

    /* BUSY: protected registers, abort */
    KS_CHECK_EQ(ks_queue_create(KS_ENG_CPW, 1, 0, KS_SHM_BASE + 0x3000u, 8), KS_CERR_OK);
    ks_wr(KS_CPW_MODEL_CTRL, 0x0401u);                                                              /* HANG_DONE */
    ks_sec_seen = 0;
    ks_wr(KS_CMD_OP, KS_OP_Q_DOORBELL); ks_wr(KS_CMD_TARGET, KS_ENG_CPW); ks_wr(KS_CMD_TENANT, 1);
    ks_wr(KS_CMD_PRIV, KS_PRIV_TENANT); ks_wr(KS_CMD_ARG0, 0); ks_wr(KS_CMD_ARG1, 1);
    ks_wr(KS_CMD_KEY, KS_KEY_CMD);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);
    ks_delay(60);
    KS_CHECK(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_BUSY_MASK);                                       /* accepted by the engine, never completes */
    ks_wr(KS_CMD_OP, KS_OP_ENG_RESET);                                                              /* protected while busy */
    KS_CHECK_EQ(ks_rd(KS_CMD_OP), KS_OP_Q_DOORBELL);
    ks_wr(KS_CMD_ARG0, 5);
    KS_CHECK_EQ(ks_rd(KS_CMD_ARG0), 0u);
    ks_wr(KS_CMD_KEY, KS_KEY_CMD);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);                                                        /* a second GO is ignored */
    KS_CHECK(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_BUSY_MASK);
    settle();
    KS_CHECK(ks_sec_seen & SEC_BIT(KS_SEC_BUSY_WRITE));
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_ABORT_MASK);
    ks_delay(20);
    KS_CHECK(!(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_BUSY_MASK));
    KS_CHECK(ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ABORTED_MASK);
    KS_CHECK_EQ((ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_ERRCODE_MASK) >> 8, KS_CERR_ABORTED);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_CPW_MODEL_CTRL, 0x0400u);

    /* timeout: engine accepts but never completes; then engine never accepts */
    const uint32_t tmo0 = ks_rd(KS_CMD_TIMEOUTS);
    ks_wr(KS_CMD_TIMEOUT, 3000u);
    ks_wr(KS_CPW_MODEL_CTRL, 0x0401u);
    ks_ras_seen = 0;
    const uint32_t t0 = ks_now();
    KS_CHECK_EQ(cmd(KS_OP_Q_DOORBELL, KS_ENG_CPW, 1, KS_PRIV_TENANT, 0, 2, 0, 0, &r), KS_CERR_TIMEOUT);
    const uint32_t el = ks_now() - t0;
    KS_CHECK(el >= 3000u && el < 8000u);                              /* not early, and nowhere near the 0x40000 default (handlers run meanwhile) */
    KS_CHECK(r.status & KS_CMD_STATUS_TIMEOUT_MASK);
    ks_wr(KS_CPW_MODEL_CTRL, 0x0402u);                                                              /* HANG_ACCEPT */
    KS_CHECK_EQ(cmd(KS_OP_Q_DOORBELL, KS_ENG_CPW, 1, KS_PRIV_TENANT, 0, 2, 0, 0, &r), KS_CERR_TIMEOUT);
    KS_CHECK_EQ(ks_rd(KS_CMD_TIMEOUTS), tmo0 + 2u);
    settle();
    KS_CHECK(ks_ras_seen & KS_BIT(KS_RAS_ENG_TIMEOUT));                                             /* reported to RAS */
    /* recovery: abort / reset / re-enable restores a working engine (model state is cleared) */
    KS_CHECK_EQ(ks_recover_engine(KS_ENG_CPW), KS_CERR_OK);
    KS_CHECK_EQ(ks_rd(KS_CPW_MODEL_CTRL), 0x0400u);
    KS_CHECK_EQ(ks_rd(KS_CPW_Q_COUNT), 0u);
    ks_wr(KS_CMD_TIMEOUT, 0x40000u);

    /* completion by interrupt */
    const uint32_t irqs = ks_irq_count[KS_IRQ_CMD];
    ks_cmd_t nc = {KS_OP_ECHO, 0, 0, KS_PRIV_GUEST, {3, 5, 7, 11}};
    KS_CHECK_EQ(ks_cmd_submit_irq(&nc, &r), KS_CERR_OK);
    KS_CHECK_EQ(r.res0, 6u);
    KS_CHECK_EQ(r.res1, 18u);
    KS_CHECK(ks_irq_count[KS_IRQ_CMD] > irqs);

    /* counters agree with what was submitted */
    KS_CHECK(ks_rd(KS_CMD_ACCEPTED) > acc);
    KS_CHECK(ks_rd(KS_CMD_REJECTED) > rej);
    KS_CHECK(ks_rd(KS_CMD_COMPLETED) > ok);
    KS_CHECK_EQ(ks_tenant_clear(3), KS_CERR_OK);
    KS_CHECK_EQ(ks_rd(KS_CMD_TENANT_TBL(3)), 0u);
}

void t_engine(void)
{
    ks_group("engine");
    /* shell identity / presence / implementation level */
    KS_CHECK_EQ(ks_rd(KS_ESH(KS_ENG_DMA, KS_ESH_ID)), KS_DMA_ID);
    KS_CHECK_EQ(ks_rd(KS_ESH(KS_ENG_DMA, KS_ESH_CAPS)) & 7u, 7u);                  /* present, REAL, pass-through */
    KS_CHECK_EQ(ks_rd(KS_ESH(KS_ENG_CPW, KS_ESH_CAPS)) & 7u, 5u);                  /* present, MODEL, pass-through */
    KS_CHECK_EQ(ks_rd(KS_ESH(KS_ENG_PKT, KS_ESH_CAPS)) & 1u, 0u);                  /* absent */
    KS_CHECK_EQ(ks_dev.present, 0x19u);
    KS_CHECK_EQ(ks_dev.real, 0x01u);
    KS_CHECK(ks_rd(KS_ESH(KS_ENG_CPW, KS_ESH_STATUS)) & 1u);                       /* enabled */
    KS_CHECK(ks_rd(KS_ESH(KS_ENG_CPW, KS_ESH_STATUS)) & 8u);                       /* power good */
    /* an absent engine's pass-through window is a bus error */
    ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
    (void)ks_rd(KS_PKT_BASE + 0x1000u);
    KS_CHECK(ks_trap_hit());
    /* engine reset through the privileged command */
    KS_CHECK_EQ(ks_queue_create(KS_ENG_VIO, 1, 2, KS_SHM_BASE + 0x3000u, 4), KS_CERR_OK);
    KS_CHECK_EQ(ks_rd(KS_VIO_Q_COUNT), 1u);
    KS_CHECK_EQ(ks_engine_reset(KS_ENG_VIO), KS_CERR_OK);
    KS_CHECK_EQ(ks_rd(KS_VIO_Q_COUNT), 0u);                                         /* engine state was reset */
    KS_CHECK_EQ(ks_rd(KS_SYS_RESET_STATUS) & 0x1Fu, 0u);
    /* SYS reset control: key protected */
    ks_sec_seen = 0;
    ks_wr(KS_SYS_RESET_CTRL, KS_BIT(KS_ENG_CPW));                                  /* no key */
    KS_CHECK_EQ(ks_rd(KS_SYS_RESET_STATUS) & 0x1Fu, 0u);
    ks_delay(300);
    KS_CHECK(ks_sec_seen & KS_BIT(KS_SEC_BAD_KEY));
    ks_wr(KS_SYS_RESET_DONE, 0x1Fu);
    ks_wr(KS_SYS_RESET_CTRL, (KS_KEY_RESET << 16) | KS_BIT(KS_ENG_CPW));
    KS_CHECK(ks_rd(KS_SYS_RESET_STATUS) & KS_BIT(KS_ENG_CPW));                      /* held in reset */
    ks_delay(60);
    KS_CHECK_EQ(ks_rd(KS_SYS_RESET_STATUS) & 0x1Fu, 0u);
    KS_CHECK(ks_rd(KS_SYS_RESET_DONE) & KS_BIT(KS_ENG_CPW));                        /* sticky completion */
    ks_wr(KS_SYS_RESET_DONE, 0x1Fu);
    KS_CHECK_EQ(ks_rd(KS_SYS_RESET_DONE), 0u);
    /* power request / good */
    ks_wr(KS_SYS_PWR_CTRL, 0x1Eu);
    ks_delay(40);
    KS_CHECK_EQ(ks_rd(KS_SYS_PWR_STATUS) & 1u, 0u);
    KS_CHECK(!(ks_rd(KS_ESH(KS_ENG_DMA, KS_ESH_STATUS)) & 8u));
    ks_wr(KS_SYS_PWR_CTRL, 0x1Fu);
    ks_delay(40);
    KS_CHECK_EQ(ks_rd(KS_SYS_PWR_STATUS) & 0x1Fu, 0x1Fu);
    /* the shell IRQ-inject aid reaches the interrupt controller through the normal path */
    ks_eng_events[KS_ENG_VIO] = 0;
    const uint32_t c0 = ks_irq_count[KS_IRQ_VIO];
    ks_wr(KS_ESH(KS_ENG_VIO, KS_ESH_IRQ_SET), 1u);
    ks_delay(300);
    KS_CHECK(ks_irq_count[KS_IRQ_VIO] > c0);
    KS_CHECK(ks_eng_events[KS_ENG_VIO] & 1u);
    KS_CHECK_EQ(ks_rd(KS_ESH(KS_ENG_VIO, KS_ESH_IRQ_STAT)), 0u);                    /* the handler acknowledged at the source */
}

static void queue_scenario(uint32_t eng, uint32_t irq)
{
    const uint32_t qbase = KS_SHM_BASE + 0x3000u;
    ks_cmd_rsp_t r;
    ks_eng_events[eng] = 0;
    KS_CHECK_EQ(ks_queue_create(eng, 1, 0, qbase, 8), KS_CERR_OK);
    ks_wr(KS_ESH(eng, KS_ESH_IRQ_STAT), 7u);
    ks_wr(KS_CPW_Q_SEL + (eng - KS_ENG_CPW) * 0x10000u, 0u);
    const uint32_t qs = ks_rd(KS_CPW_Q_STATE + (eng - KS_ENG_CPW) * 0x10000u);
    KS_CHECK(qs & 1u);
    KS_CHECK_EQ((qs >> 4) & 7u, 1u);                                                 /* owner tenant */
    KS_CHECK_EQ((qs >> 8) & 15u, 3u);                                                /* depth 8 */
    KS_CHECK_EQ(ks_rd(KS_CPW_Q_BASE + (eng - KS_ENG_CPW) * 0x10000u), qbase);
    /* duplicate create is refused by the engine and reported as a fault */
    ks_cmd_t dup = {KS_OP_Q_CREATE, eng, 1, KS_PRIV_FIRMWARE, {0, qbase, 8, 0}};
    KS_CHECK_EQ(ks_cmd_submit(&dup, &r), KS_CERR_ENG_REJECT);
    KS_CHECK_EQ(r.eng_err, 1u);
    ks_delay(300);
    KS_CHECK(ks_eng_events[eng] & KS_ESH_IRQ_STAT_FAULT_MASK);
    KS_CHECK_EQ(ks_rd(KS_ESH(eng, KS_ESH_ERR_CODE)), 1u);
    /* doorbell -> work -> completion interrupt */
    ks_eng_events[eng] = 0;
    const uint32_t cnt0 = ks_irq_count[irq], done0 = ks_rd(KS_CPW_Q_DONE + (eng - KS_ENG_CPW) * 0x10000u);
    KS_CHECK_EQ(ks_queue_doorbell(eng, 1, 0, 4), KS_CERR_OK);
    ks_delay(400);
    KS_CHECK(ks_eng_events[eng] & KS_ESH_IRQ_STAT_EVENT_MASK);
    KS_CHECK_EQ(ks_irq_count[irq], cnt0 + 1u);                                       /* ONE interrupt for the whole batch */
    KS_CHECK_EQ(ks_rd(KS_CPW_Q_DONE + (eng - KS_ENG_CPW) * 0x10000u), done0 + 4u);
    KS_CHECK_EQ(ks_rd(KS_CPW_Q_HEAD + (eng - KS_ENG_CPW) * 0x10000u), 4u);
    /* tail beyond the queue depth */
    ks_cmd_t over = {KS_OP_Q_DOORBELL, eng, 1, KS_PRIV_TENANT, {0, 4u + 9u, 0, 0}};
    KS_CHECK_EQ(ks_cmd_submit(&over, &r), KS_CERR_ENG_REJECT);
    KS_CHECK_EQ(r.eng_err, 5u);
    /* another tenant that may use the engine but does not own the queue: refused, isolation violation */
    ks_sec_seen = 0;
    KS_CHECK_EQ(ks_tenant_setup(3, 7, KS_BIT(eng)), KS_CERR_OK);
    ks_cmd_t foreign = {KS_OP_Q_DOORBELL, eng, 3, KS_PRIV_TENANT, {0, 5, 0, 0}};
    KS_CHECK_EQ(ks_cmd_submit(&foreign, &r), KS_CERR_ENG_REJECT);
    KS_CHECK_EQ(r.eng_err, 4u);
    ks_delay(400);
    KS_CHECK(ks_sec_seen & KS_BIT(KS_SEC_ENG_VIOL));
    KS_CHECK_EQ(ks_tenant_clear(3), KS_CERR_OK);
    /* a queue with pending work cannot be destroyed */
    ks_wr(KS_CPW_MODEL_CTRL + (eng - KS_ENG_CPW) * 0x10000u, 0xFF00u);              /* latency 255 clocks per entry */
    KS_CHECK_EQ(ks_queue_doorbell(eng, 1, 0, 10), KS_CERR_OK);                       /* 6 entries: about 1500 clocks of work */
    ks_cmd_t des = {KS_OP_Q_DESTROY, eng, 1, KS_PRIV_OPERATOR, {0, 0, 0, 0}};
    KS_CHECK_EQ(ks_cmd_submit(&des, &r), KS_CERR_ENG_REJECT);
    KS_CHECK_EQ(r.eng_err, 3u);
    ks_delay(2000);
    KS_CHECK_EQ(ks_queue_destroy(eng, 1, 0), KS_CERR_OK);
    KS_CHECK_EQ(ks_rd(KS_CPW_Q_COUNT + (eng - KS_ENG_CPW) * 0x10000u), 0u);
    ks_wr(KS_CPW_MODEL_CTRL + (eng - KS_ENG_CPW) * 0x10000u, 0x0400u);
    KS_CHECK_EQ(ks_queue_destroy(eng, 1, 0), KS_CERR_ENG_REJECT);                    /* already gone */
}

void t_queue(void)
{
    ks_group("queue (CPW model)");
    queue_scenario(KS_ENG_CPW, KS_IRQ_CPW);
    ks_group("queue (VIO model)");
    queue_scenario(KS_ENG_VIO, KS_IRQ_VIO);
}
