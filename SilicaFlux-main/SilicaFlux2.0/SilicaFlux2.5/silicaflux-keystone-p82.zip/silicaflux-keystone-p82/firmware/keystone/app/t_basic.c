/* Self-test groups: identity, MMIO access rules, exceptions. */
#include "ks_fw.h"

#define BAD_COUNT() (ks_rd(KS_SYS_BAD_INFO) >> KS_SYS_BAD_INFO_COUNT_SHIFT)
#define BAD_REASON() ((ks_rd(KS_SYS_BAD_INFO) & KS_SYS_BAD_INFO_REASON_MASK) >> KS_SYS_BAD_INFO_REASON_SHIFT)
#define BAD_WRITE() (ks_rd(KS_SYS_BAD_INFO) & KS_SYS_BAD_INFO_WRITE_MASK)

void t_identity(void)
{
    ks_group("identity");
    KS_CHECK_EQ(ks_rd(KS_SYS_DEV_ID), 0x53464B53u);
    KS_CHECK_EQ(ks_rd(KS_SYS_VENDOR_ID), 0x41555245u);
    KS_CHECK_EQ(ks_rd(KS_SYS_HW_VERSION), 0x01000000u);
    KS_CHECK_EQ(ks_rd(KS_SYS_ROM_VERSION), 0x01000000u);
    KS_CHECK_EQ(ks_rd(KS_SYS_FW_VERSION), KS_FW_VERSION_WORD);        /* written by the ROM from the image header */
    const uint32_t caps2 = ks_rd(KS_SYS_CAPS2);
    KS_CHECK(caps2 & KS_SYS_CAPS2_ECC_SRAM_MASK);
    KS_CHECK(caps2 & KS_SYS_CAPS2_CMD_ENGINE_MASK);
    KS_CHECK(!(caps2 & KS_SYS_CAPS2_AUTH_BOOT_MASK));                 /* no authenticated boot is claimed */
    KS_CHECK(!(caps2 & KS_SYS_CAPS2_SECURE_DEBUG_MASK));
    KS_CHECK(!(caps2 & KS_SYS_CAPS2_MEASURED_BOOT_MASK));
    const uint32_t mem = ks_rd(KS_SYS_MEM_CAPS);
    KS_CHECK_EQ(mem & 0xFFu, KS_BROM_SIZE / 1024u);
    KS_CHECK_EQ((mem >> 8) & 0xFFu, KS_IRAM_SIZE / 1024u);
    KS_CHECK_EQ((mem >> 16) & 0xFFu, KS_DRAM_SIZE / 1024u);
    KS_CHECK_EQ((mem >> 24) & 0xFFu, KS_SHM_SIZE / 1024u);
    /* boot status: stages 0..4 OK, stage 5 (this firmware) running */
    const uint32_t lo = ks_rd(KS_SYS_BOOT_ST_LO), hi = ks_rd(KS_SYS_BOOT_ST_HI);
    KS_CHECK_EQ(lo, 0x02020202u | 0u);                                /* RESET, ROM, MEMINIT, DISCOVERY = OK */
    KS_CHECK_EQ(hi & 0xFFFFu, 0x0102u);                               /* FWLOAD = OK, MGMT_FW = RUNNING */
    KS_CHECK(!(ks_rd(KS_SYS_SYS_STATUS) & KS_SYS_SYS_STATUS_DEVICE_READY_MASK));
    KS_CHECK_EQ(ks_rd(KS_SYS_BOOT_STAGE) & KS_SYS_BOOT_STAGE_STAGE_MASK, KS_STAGE_MGMT_FW);
    KS_CHECK_EQ(ks_rd(KS_SYS_BOOT_ERR), 0u);
    KS_CHECK(ks_rd(KS_SYS_RESET_CAUSE) & 1u);                         /* power-on reset recorded */
    /* CPU identity: RV32IM, machine mode */
    KS_CHECK_EQ(KS_CSRR(misa), 0x40001100u);
    KS_CHECK_EQ(KS_CSRR(mhartid), 0u);
    KS_CHECK_EQ(KS_CSRR(mimpid), 0x00820001u);
    KS_CHECK_EQ(KS_CSRR(mvendorid), 0u);

    /* the stage order is enforced by the hardware: illegal reports are ignored and flagged SEC.BOOT_SEQ */
    ks_sec_seen = 0;
    const uint32_t lo0 = ks_rd(KS_SYS_BOOT_ST_LO), hi0 = ks_rd(KS_SYS_BOOT_ST_HI);
    ks_boot_report(KS_STAGE_READY, KS_BSTAT_OK);                         /* READY never started */
    ks_boot_report(KS_STAGE_DISCOVERY, KS_BSTAT_RUNNING);                /* already OK */
    ks_boot_report(KS_STAGE_READY, KS_BSTAT_RUNNING);                    /* MGMT_FW is not OK yet */
    ks_boot_fail(KS_STAGE_ROM, KS_BERR_FW_FATAL_TRAP);                   /* a finished stage cannot fail */
    ks_boot_report(7u, KS_BSTAT_RUNNING);                                /* no such stage */
    ks_delay(500);
    KS_CHECK_EQ(ks_rd(KS_SYS_BOOT_ST_LO), lo0);
    KS_CHECK_EQ(ks_rd(KS_SYS_BOOT_ST_HI), hi0);
    KS_CHECK(!(ks_rd(KS_SYS_SYS_STATUS) & (KS_SYS_SYS_STATUS_DEVICE_READY_MASK | KS_SYS_SYS_STATUS_FAULT_MASK)));
    KS_CHECK_EQ(ks_rd(KS_SYS_BOOT_ERR), 0u);
    KS_CHECK(ks_sec_seen & KS_BIT(KS_SEC_BOOT_SEQ));
}

void t_mmio(void)
{
    ks_group("mmio");
    /* read/write registers */
    static const uint32_t pat[4] = {0xDEADBEEFu, 0x00000000u, 0xFFFFFFFFu, 0x5A5A5A5Au};
    for (int i = 0; i < 4; i++) ks_wr(KS_SYS_SCRATCH0 + 4u * (uint32_t)i, pat[i]);
    for (int i = 0; i < 4; i++) KS_CHECK_EQ(ks_rd(KS_SYS_SCRATCH0 + 4u * (uint32_t)i), pat[i]);
    for (int i = 0; i < 4; i++) ks_wr(KS_SYS_SCRATCH0 + 4u * (uint32_t)i, 0);

    /* write to a read-only register: bus error, register unchanged, access recorded */
    uint32_t n0 = BAD_COUNT();
    ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
    ks_wr(KS_SYS_DEV_ID, 0x12345678u);
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(ks_rd(KS_SYS_DEV_ID), 0x53464B53u);
    KS_CHECK_EQ(BAD_COUNT(), n0 + 1u);
    KS_CHECK_EQ(BAD_REASON(), KS_BADACC_RO_WRITE);
    KS_CHECK(BAD_WRITE());
    KS_CHECK_EQ(ks_rd(KS_SYS_BAD_ADDR), KS_SYS_DEV_ID);

    /* unmapped offset inside a block */
    ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
    (void)ks_rd(KS_SYS_BASE + 0xFF0u);
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(BAD_REASON(), KS_BADACC_UNMAPPED);
    KS_CHECK(!BAD_WRITE());
    KS_CHECK_EQ(ks_rd(KS_SYS_BAD_ADDR), KS_SYS_BASE + 0xFF0u);

    /* unmapped store must not change anything */
    ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
    ks_wr(KS_SYS_BASE + 0xFF0u, 1u);
    KS_CHECK(ks_trap_hit());

    /* byte / halfword STORE to MMIO is refused and changes nothing.  (Sub-word LOADS cannot be distinguished at the
     * bus: the CPU always requests a full word for loads, so they execute as word reads -- documented behaviour.) */
    ks_wr(KS_SYS_SCRATCH1, 0xFFFFFFFFu);
    ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
    *(volatile uint16_t *)(uintptr_t)KS_SYS_SCRATCH1 = 0;
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(BAD_REASON(), KS_BADACC_SUBWORD);
    ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
    *(volatile uint8_t *)(uintptr_t)KS_SYS_SCRATCH1 = 0;
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(ks_rd(KS_SYS_SCRATCH1), 0xFFFFFFFFu);                 /* the sub-word stores changed nothing */
    ks_wr(KS_SYS_SCRATCH0, 0xDEADBEEFu);
    KS_CHECK_EQ(*(volatile uint8_t *)(uintptr_t)KS_SYS_SCRATCH0, 0xEFu);     /* loads: full-word read, lane extracted */
    KS_CHECK_EQ(*(volatile uint16_t *)(uintptr_t)(KS_SYS_SCRATCH0 + 2u), 0xDEADu);
    ks_wr(KS_SYS_SCRATCH0, 0);
    ks_wr(KS_SYS_SCRATCH1, 0);

    /* region with no target at all */
    ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
    (void)ks_rd(0x50000000u);
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(BAD_REASON(), KS_BADACC_DECODE);

    /* ROM and firmware store are read only */
    ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
    ks_wr(KS_BROM_BASE + 0x100u, 0u);
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(BAD_REASON(), KS_BADACC_RO_WRITE);
    ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
    ks_wr(KS_FWST_BASE + 0x100u, 0u);
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(BAD_REASON(), KS_BADACC_RO_WRITE);

    /* sub-word access to RAM is fine; word access to the firmware store and ROM reads work */
    volatile uint8_t *b = (volatile uint8_t *)(uintptr_t)(KS_DRAM_BASE + 0x3000u);
    ks_wr(KS_DRAM_BASE + 0x3000u, 0u);
    b[0] = 0xA1; b[1] = 0xB2; b[2] = 0xC3; b[3] = 0xD4;
    KS_CHECK_EQ(ks_rd(KS_DRAM_BASE + 0x3000u), 0xD4C3B2A1u);
    *(volatile uint16_t *)(uintptr_t)(KS_DRAM_BASE + 0x3000u) = 0x1234u;
    KS_CHECK_EQ(ks_rd(KS_DRAM_BASE + 0x3000u), 0xD4C31234u);
    KS_CHECK_EQ(ks_rd(KS_FWST_BASE), KS_FW_MAGIC);
    KS_CHECK(ks_rd(KS_BROM_BASE + 0x10u) != 0u);
    /* shared buffer */
    ks_wr(KS_SHM_BASE + 0x100u, 0x01234567u);
    KS_CHECK_EQ(ks_rd(KS_SHM_BASE + 0x100u), 0x01234567u);
    ks_wr(KS_SHM_BASE + 0x100u, 0u);
    ks_wr(KS_DRAM_BASE + 0x3000u, 0u);
}

/* raw word accesses: the compiler would split a constant misaligned access into byte accesses */
static inline uint32_t lw_raw(uint32_t addr) { uint32_t v; __asm__ volatile("lw %0, 0(%1)" : "=r"(v) : "r"(addr)); return v; }
static inline void sw_raw(uint32_t addr, uint32_t v) { __asm__ volatile("sw %1, 0(%0)" ::"r"(addr), "r"(v) : "memory"); }
static volatile uint32_t g_sink;

void t_exceptions(void)
{
    ks_group("exceptions");
    /* ecall from M mode */
    ks_expect_trap(KS_CAUSE_ECALL_M, 0);
    __asm__ volatile("ecall");
    KS_CHECK(ks_trap_hit());
    /* ebreak */
    ks_expect_trap(KS_CAUSE_BREAKPOINT, 0);
    __asm__ volatile("ebreak");
    KS_CHECK(ks_trap_hit());
    /* illegal instruction: all-zero word; mtval = the instruction */
    ks_expect_trap(KS_CAUSE_ILLEGAL, 0);
    __asm__ volatile(".word 0x00000000");
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(ks_trap_mtval(), 0u);
    /* misaligned load / store: not sent to the bus, mtval = address */
    ks_expect_trap(KS_CAUSE_LOAD_MISALIGNED, 0);
    g_sink = lw_raw(KS_DRAM_BASE + 0x3001u);
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(ks_trap_mtval(), KS_DRAM_BASE + 0x3001u);
    ks_expect_trap(KS_CAUSE_STORE_MISALIGNED, 0);
    sw_raw(KS_DRAM_BASE + 0x3002u, 1u);
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(ks_trap_mtval(), KS_DRAM_BASE + 0x3002u);
    /* instruction access fault: jump to a region that does not exist; resume at ra */
    ks_expect_trap(KS_CAUSE_INSN_FAULT, 1);
    ((void (*)(void))(uintptr_t)0x50000000u)();
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(ks_trap_mepc(), 0x50000000u);
    /* instruction fetch from MMIO space is also an access fault */
    ks_expect_trap(KS_CAUSE_INSN_FAULT, 1);
    ((void (*)(void))(uintptr_t)KS_SYS_BASE)();
    KS_CHECK(ks_trap_hit());
    /* the firmware keeps running after every recovered exception */
    KS_CHECK_EQ(ks_rd(KS_SYS_DEV_ID), 0x53464B53u);
}
