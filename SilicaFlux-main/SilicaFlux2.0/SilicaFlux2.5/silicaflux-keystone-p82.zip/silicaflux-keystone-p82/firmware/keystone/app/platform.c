/* Platform layer: exceptions, interrupt dispatch (INTC claim/complete), time. */
#include "ks_fw.h"

static volatile struct {
    uint32_t armed, cause, resume_ra, hit, mtval, mepc;
} g_exp;

void ks_expect_trap(uint32_t cause, int resume_ra)
{
    g_exp.cause = cause;
    g_exp.resume_ra = (uint32_t)resume_ra;
    g_exp.hit = 0;
    g_exp.armed = 1;
}

int ks_trap_hit(void)
{
    int h = (int)g_exp.hit;
    g_exp.armed = 0;
    g_exp.hit = 0;
    return h;
}
uint32_t ks_trap_mtval(void) { return g_exp.mtval; }
uint32_t ks_trap_mepc(void) { return g_exp.mepc; }

void ks_fatal(const char *why)
{
    ks_puts("[FW] FATAL: ");
    ks_puts(why);
    ks_putc('\n');
    ks_boot_fail(KS_STAGE_MGMT_FW, KS_BERR_FW_FATAL_TRAP);
    for (;;) ks_wfi();
}

/* ------------------------------------------------------------------ interrupts */
volatile uint32_t ks_irq_count[KS_NUM_IRQ + 1];
volatile uint32_t ks_irq_order[16];
volatile uint32_t ks_irq_order_n;
volatile uint32_t ks_mti_count, ks_msi_count, ks_spurious;
static ks_isr_t g_isr[KS_NUM_IRQ + 1];

void ks_irq_register(uint32_t src, ks_isr_t fn) { g_isr[src] = fn; }
void ks_irq_order_reset(void) { ks_irq_order_n = 0; }

/* Machine external interrupt: claim -> handler -> complete, until nothing is pending. */
static void ks_mei(void)
{
    for (;;) {
        const uint32_t id = ks_rd(KS_INTC_CLAIM);
        if (id == 0u) break;
        ks_irq_count[id]++;
        if (ks_irq_order_n < 16u) ks_irq_order[ks_irq_order_n++] = id;
        if (g_isr[id]) g_isr[id](id);
        ks_wr(KS_INTC_CLAIM, id);                      /* complete */
    }
}

void ks_trap_handler(ks_frame_t *f)
{
    const uint32_t cause = f->mcause;
    if (cause & 0x80000000u) {                       /* interrupt */
        switch (cause & 0x7FFFFFFFu) {
        case 11u: ks_mei(); break;
        case 7u:  ks_mti_count++; ks_wr(KS_TMR_MTIMECMP_HI, 0xFFFFFFFFu); ks_wr(KS_TMR_MTIMECMP_LO, 0xFFFFFFFFu); break;
        case 3u:  ks_msi_count++; ks_wr(KS_TMR_MSIP, 0u); break;
        default:  ks_fatal("unknown interrupt");
        }
        return;
    }
    if (g_exp.armed && g_exp.cause == cause) {
        g_exp.mtval = f->mtval;
        g_exp.mepc = f->mepc;
        g_exp.hit = 1;
        f->mepc = g_exp.resume_ra ? f->x[1] : f->mepc + 4u;   /* all instructions are 4 bytes (no C extension) */
        return;
    }
    ks_puts("[FW] unexpected exception cause=");
    ks_putdec(cause);
    ks_puts(" mepc=0x");
    ks_puthex(f->mepc);
    ks_puts(" mtval=0x");
    ks_puthex(f->mtval);
    ks_putc('\n');
    ks_fatal("trap");
}

/* ------------------------------------------------------------------ time */
uint32_t ks_now(void) { return ks_rd(KS_TMR_MTIME_LO); }

int ks_wait_flag(volatile uint32_t *flag, uint32_t timeout_cycles)
{
    const uint32_t t0 = ks_now();
    while (!*flag) {
        if ((ks_now() - t0) > timeout_cycles) return 0;
    }
    return 1;
}

void ks_delay(uint32_t cycles)
{
    const uint32_t t0 = ks_now();
    while ((ks_now() - t0) < cycles) { }
}
