/* Register-map conformance walker (SCENARIO=regs).  Everything here is driven by tables GENERATED from
 * config/keystone_regs.yaml, so the RTL, the firmware headers and this test cannot drift apart:
 *   pass 1  every testable register reads its documented reset value
 *   pass 2  read-only registers refuse writes (bus error) and keep their value; read/write registers keep exactly
 *           the bits of their write mask for several patterns and are restored
 *   pass 3  every word offset below 0x100 of every block that is NOT a register faults on read and on write */
#ifdef KS_SCENARIO_regs
#include "ks_fw.h"
#include "generated/ks_regtest_tbl.h"

void t_regs(void)
{
    ks_group("register map (generated tables)");
    static const uint32_t pat[4] = {0x00000000u, 0xFFFFFFFFu, 0xA5A5A5A5u, 0x5A5A5A5Au};

    for (uint32_t i = 0; i < KS_RT_N; i++) {                                    /* pass 1: reset values */
        const uint32_t v = ks_rd(ks_rt[i].addr);
        if (v != ks_rt[i].rst) {
            ks_puts("[FW]   reset value of 0x"); ks_puthex(ks_rt[i].addr); ks_puts(" is 0x"); ks_puthex(v);
            ks_puts(" want 0x"); ks_puthex(ks_rt[i].rst); ks_putc('\n');
        }
        KS_CHECK_EQ(v, ks_rt[i].rst);
    }
    uint32_t n_ro = 0, n_rw = 0;
    for (uint32_t i = 0; i < KS_RT_N; i++) {                                    /* pass 2: access rules */
        const uint32_t a = ks_rt[i].addr, rst = ks_rt[i].rst, mask = ks_rt[i].mask;
        if (ks_rt[i].kind == 1u) {
            n_ro++;
            ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
            ks_wr(a, ~rst);
            KS_CHECK(ks_trap_hit());
            if (!ks_rt[i].vol) KS_CHECK_EQ(ks_rd(a), rst);                       /* (RAS event record legitimately logs the bus error) */
        } else {
            n_rw++;
            for (int p = 0; p < 4; p++) {
                ks_wr(a, pat[p]);
                const uint32_t got = ks_rd(a);
                if (got != (pat[p] & mask)) { ks_puts("[FW]   rw mismatch at 0x"); ks_puthex(a); ks_putc('\n'); }
                KS_CHECK_EQ(got, pat[p] & mask);
            }
            ks_wr(a, rst);
            KS_CHECK_EQ(ks_rd(a), rst);
        }
    }
    uint32_t n_unmapped = 0;
    for (uint32_t b = 0; b < KS_MAPPED_N; b++) {                                /* pass 3: holes */
        for (uint32_t off = 0; off < 0x100u; off += 4u) {
            int mapped = 0;
            for (uint32_t k = 0; k < ks_mapped[b].n; k++) if (ks_mapped[b].mapped[k] == off) { mapped = 1; break; }
            if (mapped) continue;
            n_unmapped++;
            ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
            (void)ks_rd(ks_mapped[b].base + off);
            KS_CHECK(ks_trap_hit());
            ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
            ks_wr(ks_mapped[b].base + off, 0xFFFFFFFFu);
            KS_CHECK(ks_trap_hit());
        }
    }
    ks_puts("[FW] regwalk: ro="); ks_putdec(n_ro);
    ks_puts(" rw="); ks_putdec(n_rw);
    ks_puts(" unmapped="); ks_putdec(n_unmapped);
    ks_putc('\n');
    KS_CHECK(n_ro > 60u && n_rw > 40u && n_unmapped > 300u);
}
#endif
