/* Self-test group: the REAL SilicaFlux CloudDMA (Project 64) driven through the Keystone command engine. */
#include "ks_fw.h"

#define SHM_DESC   (KS_SHM_BASE + 0x0000u)
#define SHM_CPL    (KS_SHM_BASE + 0x0400u)
#define SHM_SRC    (KS_SHM_BASE + 0x1000u)
#define SHM_DST    (KS_SHM_BASE + 0x2000u)
#define SHM_D5     (KS_SHM_BASE + 0x3000u)           /* the only region domain 5 may read */

static uint32_t lfsr = 0x1234ABCDu;
static uint8_t rnd8(void) { lfsr ^= lfsr << 13; lfsr ^= lfsr >> 17; lfsr ^= lfsr << 5; return (uint8_t)(lfsr >> 11); }

static void fill_rand(uint32_t addr, uint32_t n) { volatile uint8_t *p = (volatile uint8_t *)(uintptr_t)addr; for (uint32_t i = 0; i < n; i++) p[i] = rnd8(); }
static void fill_const(uint32_t addr, uint32_t n, uint8_t v) { volatile uint8_t *p = (volatile uint8_t *)(uintptr_t)addr; for (uint32_t i = 0; i < n; i++) p[i] = v; }
static int same(uint32_t a, uint32_t b, uint32_t n)
{
    const volatile uint8_t *x = (const volatile uint8_t *)(uintptr_t)a, *y = (const volatile uint8_t *)(uintptr_t)b;
    for (uint32_t i = 0; i < n; i++) if (x[i] != y[i]) return 0;
    return 1;
}
static int all_eq(uint32_t a, uint32_t n, uint8_t v)
{
    const volatile uint8_t *x = (const volatile uint8_t *)(uintptr_t)a;
    for (uint32_t i = 0; i < n; i++) if (x[i] != v) return 0;
    return 1;
}
static uint32_t crc_of(uint32_t addr, uint32_t n) { return ~ks_crc32_update(0xFFFFFFFFu, (const uint8_t *)(uintptr_t)addr, n); }

static void provision(void)
{
    KS_CHECK_EQ(ks_dma_init(), 0u);
    KS_CHECK_EQ(ks_dma_map(0, 3, KS_SHM_BASE, KS_SHM_SIZE, KS_SHM_BASE, 3u), 0u);        /* domain 3: whole SHM, read + write */
    KS_CHECK_EQ(ks_dma_map(1, 5, SHM_D5, 0x1000u, SHM_D5, 1u), 0u);                       /* domain 5: 4 KiB, read only */
}

void t_dma(void)
{
    ks_group("dma (real CloudDMA)");
    ks_dma_cpl_t c;
    ks_cmd_rsp_t r;

    /* management plane visibility: CSR page pass-through, identity, access rules */
    KS_CHECK_EQ(ks_rd(KS_DMA_CSR(0x000)), 0x5346444Du);                                   /* 'SFDM' */
    KS_CHECK_EQ(ks_rd(KS_DMA_CSR(0x004)), 0x00010000u);
    KS_CHECK_EQ(ks_rd(KS_DMA_CSR(0x008)) & 0xFFu, 1u);                                    /* one channel */
    ks_expect_trap(KS_CAUSE_STORE_FAULT, 0);
    ks_wr(KS_DMA_CSR(0x000), 0u);                                                         /* CloudDMA refuses a write to a RO CSR */
    KS_CHECK(ks_trap_hit());
    ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
    (void)ks_rd(KS_DMA_CSR(0x0F0));                                                       /* undefined CSR offset */
    KS_CHECK(ks_trap_hit());
    ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
    (void)ks_rd(KS_DMA_BASE + 0x0800u);                                                   /* hole between glue and CSR page */
    KS_CHECK(ks_trap_hit());
    KS_CHECK_EQ(ks_rd(KS_DMA_CSR(0x010)) & 1u, 0u);                                       /* disabled out of reset */

    provision();
    KS_CHECK_EQ(ks_dma_map(5, 3, KS_SHM_BASE + 0x800u, 0x1000u, KS_SHM_BASE, 3u), 1u);     /* unaligned entry is refused by the table */
    KS_CHECK_EQ(ks_dma_map(5, 3, KS_SHM_BASE, 0u, KS_SHM_BASE, 3u), 1u);                   /* zero size is refused */

    /* ---- A: unaligned copy, CRC, completion record, completion interrupt */
    const uint32_t len = 1000u, soff = 3u, doff = 5u;
    fill_rand(SHM_SRC, len + 16u);
    fill_const(SHM_DST - 16u, len + 96u, 0xEE);
    for (uint32_t i = 0; i < 8u; i++) ks_wr(SHM_CPL + 4u * i, 0u);
    const uint32_t irq0 = ks_irq_count[KS_IRQ_DMA], sub0 = ks_rd(KS_DMA_SUBMITTED);
    ks_eng_events[KS_ENG_DMA] = 0;
    KS_CHECK_EQ(ks_dma_copy(1, 3, SHM_SRC + soff, SHM_DST + doff, len, &c), 0u);
    KS_CHECK_EQ(c.status, 0u);                                                            /* OK */
    KS_CHECK_EQ(c.bytes, len);
    KS_CHECK_EQ(c.domain, 3u);
    KS_CHECK_EQ(c.txn, 0x101u);
    KS_CHECK(same(SHM_SRC + soff, SHM_DST + doff, len));                                  /* data arrived intact */
    KS_CHECK(all_eq(SHM_DST - 16u, 16u + doff, 0xEE));                                    /* nothing written before the destination ... */
    KS_CHECK(all_eq(SHM_DST + doff + len, 32u, 0xEE));                                    /* ... or after it */
    KS_CHECK_EQ(c.crc, crc_of(SHM_SRC + soff, len));                                      /* CRC-32 of the moved stream */
    KS_CHECK_EQ(ks_rd(SHM_CPL) & 0xFu, 0u);                                               /* completion record: OK */
    KS_CHECK_EQ(ks_rd(SHM_CPL) >> 16, 0x101u);
    KS_CHECK_EQ(ks_rd(SHM_CPL + 8u), len);
    KS_CHECK_EQ(ks_rd(SHM_CPL + 28u) >> 16, 0xD0C1u);                                     /* record magic */
    KS_CHECK_EQ(ks_irq_count[KS_IRQ_DMA], irq0 + 1u);                                     /* exactly one completion interrupt */
    KS_CHECK(ks_eng_events[KS_ENG_DMA] & KS_ESH_IRQ_STAT_EVENT_MASK);
    KS_CHECK_EQ(ks_rd(KS_DMA_SUBMITTED), sub0 + 1u);
    KS_CHECK_EQ(ks_rd(KS_DMA_CPL_STAT) & 1u, 0u);                                         /* record consumed */
    KS_CHECK(!(ks_rd(KS_ESH(KS_ENG_DMA, KS_ESH_STATUS)) & 2u));                           /* engine idle again */

    /* ---- B: scatter-gather, array mode, three elements gathered into one buffer */
    fill_const(SHM_DST, 400u, 0xEE);
    ks_dma_desc_t *d = (ks_dma_desc_t *)(uintptr_t)SHM_DESC;
    ks_dma_desc(&d[0], 0, KS_DMA_F_HEAD | KS_DMA_F_ARRAY | KS_DMA_F_CPL_EN | KS_DMA_F_CRC_EN, 0x77u, 3u, SHM_SRC + 0u, SHM_DST + 0u, 100u);
    ks_dma_desc(&d[1], 1, KS_DMA_F_ARRAY, 0x77u, 3u, SHM_SRC + 512u, SHM_DST + 100u, 33u);
    ks_dma_desc(&d[2], 2, KS_DMA_F_LAST, 0x77u, 3u, SHM_SRC + 1024u, SHM_DST + 133u, 200u);
    KS_CHECK_EQ(ks_dma_submit(1, KS_PRIV_TENANT, SHM_DESC, &r), KS_CERR_OK);
    KS_CHECK(ks_dma_wait(&c, 4000000u));
    KS_CHECK_EQ(c.status, 0u);
    KS_CHECK_EQ(c.bytes, 333u);
    KS_CHECK(same(SHM_SRC + 0u, SHM_DST + 0u, 100u));
    KS_CHECK(same(SHM_SRC + 512u, SHM_DST + 100u, 33u));
    KS_CHECK(same(SHM_SRC + 1024u, SHM_DST + 133u, 200u));
    KS_CHECK(all_eq(SHM_DST + 333u, 32u, 0xEE));
    {   /* CRC over the concatenated stream */
        uint32_t crc = 0xFFFFFFFFu;
        crc = ks_crc32_update(crc, (const uint8_t *)(uintptr_t)(SHM_SRC + 0u), 100u);
        crc = ks_crc32_update(crc, (const uint8_t *)(uintptr_t)(SHM_SRC + 512u), 33u);
        crc = ks_crc32_update(crc, (const uint8_t *)(uintptr_t)(SHM_SRC + 1024u), 200u);
        KS_CHECK_EQ(c.crc, ~crc);
    }

    /* ---- C: tenant isolation.  Domain 5 may only read SHM+0x3000.. : its copy to SHM+0x2000 is an isolation violation */
    ks_sec_seen = 0;
    fill_rand(SHM_D5 + 0x100u, 64u);
    fill_const(SHM_DST, 64u, 0xEE);
    ks_dma_desc_t *d5 = (ks_dma_desc_t *)(uintptr_t)SHM_D5;
    ks_dma_desc(d5, 0, KS_DMA_F_HEAD | KS_DMA_F_LAST, 0x55u, 5u, SHM_D5 + 0x100u, SHM_DST, 64u);
    KS_CHECK_EQ(ks_dma_submit(2, KS_PRIV_TENANT, SHM_D5, &r), KS_CERR_OK);               /* tenant 2 -> hardware-bound domain 5 */
    KS_CHECK(ks_dma_wait(&c, 4000000u));
    KS_CHECK_EQ(c.status, 1u);                                                            /* ERROR */
    KS_CHECK_EQ(c.err, 0x23u);                                                            /* PERM_DST */
    KS_CHECK(all_eq(SHM_DST, 64u, 0xEE));                                                 /* nothing was written */
    ks_delay(500);
    KS_CHECK(ks_sec_seen & KS_BIT(KS_SEC_DMA_VIOL));                                      /* isolation violation -> security interrupt */
    KS_CHECK(ks_eng_events[KS_ENG_DMA] & KS_ESH_IRQ_STAT_VIOL_MASK);
    /* descriptor claims another domain than the hardware binding */
    ks_sec_seen = 0;
    ks_dma_desc(d, 0, KS_DMA_F_HEAD | KS_DMA_F_LAST, 0x56u, 5u, SHM_SRC, SHM_DST, 64u);   /* tenant 1 is domain 3, desc says 5 */
    KS_CHECK_EQ(ks_dma_submit(1, KS_PRIV_TENANT, SHM_DESC, &r), KS_CERR_OK);
    KS_CHECK(ks_dma_wait(&c, 4000000u));
    KS_CHECK_EQ(c.status, 1u);
    KS_CHECK_EQ(c.err, 0x20u);                                                            /* DOMAIN_MISMATCH */
    ks_delay(500);
    KS_CHECK(ks_sec_seen & KS_BIT(KS_SEC_DMA_VIOL));

    /* ---- D: a malformed descriptor is an error completion, not a violation */
    ks_sec_seen = 0;
    ks_dma_desc(d, 0, KS_DMA_F_HEAD | KS_DMA_F_LAST, 0x57u, 3u, SHM_SRC, SHM_DST, 64u);
    ks_wr(SHM_DESC, (ks_rd(SHM_DESC) & ~0xFFu) | 3u);                                     /* VERSION 1 -> 3 */
    KS_CHECK_EQ(ks_dma_submit(1, KS_PRIV_TENANT, SHM_DESC, &r), KS_CERR_OK);
    KS_CHECK(ks_dma_wait(&c, 4000000u));
    KS_CHECK_EQ(c.status, 1u);
    KS_CHECK_EQ(c.err, 0x02u);                                                            /* DESC_VERSION */
    ks_delay(500);
    KS_CHECK(!(ks_sec_seen & KS_BIT(KS_SEC_DMA_VIOL)));

    /* ---- E: refusals by the command engine, before anything reaches CloudDMA */
    const uint32_t sub1 = ks_rd(KS_DMA_SUBMITTED);
    KS_CHECK_EQ(ks_engine_enable(KS_ENG_DMA, 0), KS_CERR_OK);
    KS_CHECK_EQ(ks_dma_submit(1, KS_PRIV_TENANT, SHM_DESC, &r), KS_CERR_ENG_DISABLED);
    KS_CHECK_EQ(ks_engine_enable(KS_ENG_DMA, 1), KS_CERR_OK);
    KS_CHECK_EQ(ks_dma_submit(1, KS_PRIV_GUEST, SHM_DESC, &r), KS_CERR_PRIV);
    KS_CHECK_EQ(ks_dma_submit(6, KS_PRIV_TENANT, SHM_DESC, &r), KS_CERR_BAD_TENANT);
    KS_CHECK_EQ(ks_rd(KS_DMA_SUBMITTED), sub1);                                           /* nothing was submitted */

    /* ---- F: a bus error on the DMA's memory port is reported (AXI SLVERR -> BUS_WR) */
    ks_ras_seen = 0;
    KS_CHECK_EQ(ks_dma_map(2, 3, 0x00400000u, 0x1000u, 0x00400000u, 3u), 0u);              /* maps to PA outside the SHM window */
    ks_dma_desc(d, 0, KS_DMA_F_HEAD | KS_DMA_F_LAST, 0x58u, 3u, SHM_SRC, 0x00400000u, 64u);
    KS_CHECK_EQ(ks_dma_submit(1, KS_PRIV_TENANT, SHM_DESC, &r), KS_CERR_OK);
    KS_CHECK(ks_dma_wait(&c, 4000000u));
    KS_CHECK_EQ(c.status, 1u);
    KS_CHECK_EQ(c.err, 0x32u);                                                            /* BUS_WR */
    ks_delay(500);
    KS_CHECK(ks_ras_seen & KS_BIT(KS_RAS_ENG_FAULT));

    /* ---- G: recovery: engine reset (CloudDMA hard reset), re-provision, and a good copy works again */
    KS_CHECK_EQ(ks_dma_recover(), 0u);
    KS_CHECK_EQ(ks_rd(KS_DMA_SUBMITTED), 0u);                                             /* glue state restarted too */
    provision();
    fill_rand(SHM_SRC, 128u);
    fill_const(SHM_DST, 160u, 0xEE);
    KS_CHECK_EQ(ks_dma_copy(1, 3, SHM_SRC, SHM_DST, 128u, &c), 0u);
    KS_CHECK_EQ(c.status, 0u);
    KS_CHECK(same(SHM_SRC, SHM_DST, 128u));
    KS_CHECK(all_eq(SHM_DST + 128u, 32u, 0xEE));
    KS_CHECK_EQ(c.crc, crc_of(SHM_SRC, 128u));
}
