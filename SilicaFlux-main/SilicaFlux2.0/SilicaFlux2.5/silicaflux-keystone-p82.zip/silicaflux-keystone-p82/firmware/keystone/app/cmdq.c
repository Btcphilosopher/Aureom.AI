/* Protected management command submission: stage -> arm key -> GO -> wait -> read result. */
#include "ks_fw.h"

volatile uint32_t ks_cmd_irq_flag;

static void cmd_stage(const ks_cmd_t *c)
{
    ks_wr(KS_CMD_OP, c->op);
    ks_wr(KS_CMD_TARGET, c->target);
    ks_wr(KS_CMD_TENANT, c->tenant);
    ks_wr(KS_CMD_PRIV, c->priv);
    ks_wr(KS_CMD_ARG0, c->arg[0]);
    ks_wr(KS_CMD_ARG1, c->arg[1]);
    ks_wr(KS_CMD_ARG2, c->arg[2]);
    ks_wr(KS_CMD_ARG3, c->arg[3]);
}

static uint32_t cmd_collect(ks_cmd_rsp_t *r, int completed)
{
    const uint32_t st = ks_rd(KS_CMD_STATUS);
    r->status = st;
    r->res0 = ks_rd(KS_CMD_RES0);
    r->res1 = ks_rd(KS_CMD_RES1);
    r->eng_err = ks_rd(KS_CMD_ENG_ERR);
    if (!completed) r->err = KS_CERR_TIMEOUT;
    else r->err = (st & KS_CMD_STATUS_ERRCODE_MASK) >> KS_CMD_STATUS_ERRCODE_SHIFT;
    if (r->err != KS_CERR_OK) ks_fault_report(KS_FAULT_SRC_CMD, r->err, ks_rd(KS_CMD_OP), r->eng_err);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    return r->err;
}

static void cmd_go(void)
{
    ks_wr(KS_CMD_KEY, KS_KEY_CMD);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);
}

uint32_t ks_cmd_submit(const ks_cmd_t *c, ks_cmd_rsp_t *r)
{
    /* the staging registers are write-protected while BUSY: wait for the previous command */
    const uint32_t t0 = ks_now();
    while (ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_BUSY_MASK)
        if ((ks_now() - t0) > KS_CMD_DEFAULT_WAIT) { r->err = KS_CERR_BUSY; return r->err; }
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    cmd_stage(c);
    cmd_go();
    const uint32_t t1 = ks_now();
    int done = 0;
    while ((ks_now() - t1) < KS_CMD_DEFAULT_WAIT) {
        if (ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_DONE_MASK) { done = 1; break; }
    }
    return cmd_collect(r, done);
}

static void cmd_isr(uint32_t src)
{
    (void)src;
    ks_wr(KS_CMD_IE, 0u);                              /* level source: disarm until the waiter re-arms */
    ks_cmd_irq_flag = 1;
}

uint32_t ks_cmd_submit_irq(const ks_cmd_t *c, ks_cmd_rsp_t *r)
{
    const uint32_t t0 = ks_now();
    while (ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_BUSY_MASK)
        if ((ks_now() - t0) > KS_CMD_DEFAULT_WAIT) { r->err = KS_CERR_BUSY; return r->err; }
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_cmd_irq_flag = 0;
    ks_irq_register(KS_IRQ_CMD, cmd_isr);
    cmd_stage(c);
    ks_wr(KS_CMD_IE, 1u);
    cmd_go();
    const int done = ks_wait_flag(&ks_cmd_irq_flag, KS_CMD_DEFAULT_WAIT);
    return cmd_collect(r, done);
}
