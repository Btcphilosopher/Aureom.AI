/* Device management: discovery, privilege-checked command execution, tenants, queues, engine reset / recovery,
 * performance snapshots, host mailbox service, production interrupt handlers. */
#include "ks_fw.h"

ks_device_t ks_dev;
volatile uint32_t ks_mbx_flag, ks_mbx_served;
volatile uint32_t ks_eng_events[KS_NUM_ENG];
volatile uint32_t ks_sec_seen, ks_ras_seen, ks_wdt_barks;

/* ---------------------------------------------------------------- privilege model */
/* Software copy of the hardware opcode table (sf_keystone_cmd.sv op_minpriv); the hardware re-checks every command. */
uint32_t ks_min_priv(uint32_t op)
{
    switch (op) {
    case KS_OP_NOP: case KS_OP_ECHO: case KS_OP_PERF_SNAP: return KS_PRIV_GUEST;
    case KS_OP_DMA_SUBMIT: case KS_OP_Q_DOORBELL:          return KS_PRIV_TENANT;
    default:                                               return KS_PRIV_OPERATOR;   /* reset, enable, tenant, queue create/destroy */
    }
}

uint32_t ks_mgmt_exec(const ks_cmd_t *c, uint32_t caller_priv, ks_cmd_rsp_t *r)
{
    if (caller_priv < ks_min_priv(c->op)) {                       /* fail fast: never reach the hardware */
        ks_fault_report(KS_FAULT_SRC_SEC, KS_CERR_PRIV, c->op, caller_priv);
        r->err = KS_CERR_PRIV; r->status = 0; r->res0 = r->res1 = r->eng_err = 0;
        return r->err;
    }
    ks_cmd_t k = *c;
    k.priv = caller_priv;                                         /* the hardware checks it again */
    return ks_cmd_submit(&k, r);
}

static uint32_t fw_cmd(uint32_t op, uint32_t target, uint32_t tenant, uint32_t a0, uint32_t a1, uint32_t a2, uint32_t a3,
                       ks_cmd_rsp_t *rr)
{
    ks_cmd_t c = {op, target, tenant, KS_PRIV_FIRMWARE, {a0, a1, a2, a3}};
    ks_cmd_rsp_t r;
    ks_mgmt_exec(&c, KS_PRIV_FIRMWARE, &r);
    if (rr) *rr = r;
    return r.err;
}

/* ---------------------------------------------------------------- capability discovery */
void ks_discover(void)
{
    const uint32_t caps0 = ks_rd(KS_SYS_CAPS0), caps1 = ks_rd(KS_SYS_CAPS1);
    ks_dev.present = caps0 & 0x1Fu;
    ks_dev.real = (caps0 >> 8) & 0x1Fu;
    ks_dev.num_tenants = caps1 & 0xFFu;
    ks_dev.num_queues = (caps1 >> 8) & 0xFFu;
    ks_dev.caps2 = ks_rd(KS_SYS_CAPS2);
    ks_dev.hw_version = ks_rd(KS_SYS_HW_VERSION);
    ks_dev.fw_version = ks_rd(KS_SYS_FW_VERSION);
    ks_dev.enabled = ks_rd(KS_CMD_ENG_EN);
    for (uint32_t e = 0; e < KS_NUM_ENG; e++) ks_dev.eng_id[e] = ks_rd(KS_ESH(e, KS_ESH_ID));
    ks_dev.ras_ce = ks_rd(KS_RAS_CE_COUNT);
    ks_dev.ras_ue = ks_rd(KS_RAS_UE_COUNT);
}

/* ---------------------------------------------------------------- engines, tenants, queues */
uint32_t ks_engine_enable(uint32_t eng, uint32_t on) { return fw_cmd(KS_OP_ENG_ENABLE, eng, 0, on, 0, 0, 0, 0); }

uint32_t ks_engine_reset(uint32_t eng)
{
    const uint32_t e = fw_cmd(KS_OP_ENG_RESET, eng, 0, 0, 0, 0, 0, 0);
    if (e == KS_CERR_OK) ks_wr(KS_SYS_RESET_DONE, 1u << eng);   /* acknowledge the sticky completion bit */
    return e;
}

uint32_t ks_tenant_setup(uint32_t t, uint32_t domain, uint32_t mask) { return fw_cmd(KS_OP_TENANT_SET, 0, t, domain, mask, 0, 0, 0); }
uint32_t ks_tenant_clear(uint32_t t) { return fw_cmd(KS_OP_TENANT_CLR, 0, t, 0, 0, 0, 0, 0); }

uint32_t ks_queue_create(uint32_t eng, uint32_t t, uint32_t qid, uint32_t base, uint32_t depth)
{
    return fw_cmd(KS_OP_Q_CREATE, eng, t, qid, base, depth, 0, 0);
}
uint32_t ks_queue_destroy(uint32_t eng, uint32_t t, uint32_t qid) { return fw_cmd(KS_OP_Q_DESTROY, eng, t, qid, 0, 0, 0, 0); }
uint32_t ks_queue_doorbell(uint32_t eng, uint32_t t, uint32_t qid, uint32_t tail)
{
    return fw_cmd(KS_OP_Q_DOORBELL, eng, t, qid, tail, 0, 0, 0);
}

/* ---------------------------------------------------------------- performance snapshot */
uint32_t ks_perf_snapshot(ks_perf_t *p)
{
    ks_cmd_rsp_t r;
    const uint32_t e = fw_cmd(KS_OP_PERF_SNAP, 0, 0, 0, 0, 0, 0, &r);   /* all counters captured in one cycle */
    if (e != KS_CERR_OK) return e;
    p->cycles = ((uint64_t)ks_rd(KS_TEL_CYCLES_HI) << 32) | ks_rd(KS_TEL_CYCLES_LO);
    p->instret = ((uint64_t)ks_rd(KS_TEL_INSTRET_HI) << 32) | ks_rd(KS_TEL_INSTRET_LO);
    p->sleep = ks_rd(KS_TEL_SLEEP);   p->mmio_rd = ks_rd(KS_TEL_MMIO_RD); p->mmio_wr = ks_rd(KS_TEL_MMIO_WR);
    p->bus_err = ks_rd(KS_TEL_BUS_ERR); p->exc = ks_rd(KS_TEL_EXC); p->intr = ks_rd(KS_TEL_INTR);
    p->cmd_acc = ks_rd(KS_TEL_CMD_ACC); p->cmd_err = ks_rd(KS_TEL_CMD_ERR);
    p->ras_ce = ks_rd(KS_TEL_RAS_CE); p->ras_ue = ks_rd(KS_TEL_RAS_UE);
    p->wdt_kicks = ks_rd(KS_TEL_WDT_KICKS); p->sec_viol = ks_rd(KS_TEL_SEC_VIOL);
    for (uint32_t i = 0; i < KS_NUM_ENG; i++) { p->eng_evt[i] = ks_rd(KS_TEL_ENG_EVT(i)); p->eng_flt[i] = ks_rd(KS_TEL_ENG_FLT(i)); }
    for (uint32_t i = 1; i <= KS_NUM_IRQ; i++) p->irq_claims[i] = ks_rd(KS_TEL_IRQ_CNT(i));
    p->seq = ks_rd(KS_TEL_SEQ);
    return KS_CERR_OK;
}

/* ---------------------------------------------------------------- error recovery */
/* Bring an engine back to a known state: abort a stuck command, reset the engine, re-enable it. */
uint32_t ks_recover_engine(uint32_t eng)
{
    if (ks_rd(KS_CMD_STATUS) & KS_CMD_STATUS_BUSY_MASK) {
        ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_ABORT_MASK);
        ks_delay(8);
    }
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_ESH(eng, KS_ESH_IRQ_STAT), 0x7u);                    /* drop stale causes */
    ks_eng_events[eng] = 0;
    uint32_t e = ks_engine_reset(eng);
    if (e != KS_CERR_OK) return e;
    e = ks_engine_enable(eng, 1u);
    ks_fault_report(KS_FAULT_SRC_ENG, 0xE0u | eng, e, 0);        /* recovery performed */
    return e;
}

/* ---------------------------------------------------------------- host mailbox */
void ks_mbx_service(void)
{
    if (!(ks_rd(KS_MBX_STATUS) & KS_MBX_STATUS_REQ_PENDING_MASK)) { ks_mbx_flag = 0; return; }
    const uint32_t st = ks_rd(KS_MBX_STATUS);
    const uint32_t priv = (st & KS_MBX_STATUS_REQ_PRIV_MASK) >> KS_MBX_STATUS_REQ_PRIV_SHIFT;   /* hardware-captured */
    const uint32_t seq = (st & KS_MBX_STATUS_SEQ_MASK) >> KS_MBX_STATUS_SEQ_SHIFT;
    uint32_t in[8];
    for (uint32_t i = 0; i < 8u; i++) in[i] = ks_rd(KS_MBX_IN(i));
    ks_cmd_rsp_t r = {0, 0, 0, 0, 0};
    if ((in[0] & 0xFFu) == KS_HOST_OP_INFO) {
        r.res0 = ks_dev.fw_version; r.res1 = ks_dev.present | (ks_dev.enabled << 8);
    } else {
        ks_cmd_t c = {in[0] & 0xFFu, in[1] & 7u, (in[1] >> 8) & 7u, priv, {in[2], in[3], in[4], in[5]}};
        ks_mgmt_exec(&c, priv, &r);
    }
    ks_wr(KS_MBX_OUT(0), 0x80000000u | r.err);
    ks_wr(KS_MBX_OUT(1), r.res0);
    ks_wr(KS_MBX_OUT(2), r.res1);
    ks_wr(KS_MBX_OUT(3), priv);
    ks_wr(KS_MBX_OUT(4), seq);
    ks_wr(KS_MBX_CTRL, KS_MBX_CTRL_COMPLETE_MASK);
    ks_mbx_flag = 0;
    ks_mbx_served++;
    ks_wr(KS_INTC_ENABLE, ks_rd(KS_INTC_ENABLE) | KS_BIT(KS_IRQ_HOST));   /* re-arm */
}

/* ---------------------------------------------------------------- production interrupt handlers */
static void isr_wdt(uint32_t s) { (void)s; ks_wdt_barks++; ks_fault_report(KS_FAULT_SRC_WDT, 1u, ks_rd(KS_WDT_COUNT), 0); ks_wr(KS_WDT_STATUS, KS_WDT_STATUS_BARK_MASK); }
static void isr_sec(uint32_t s)
{
    (void)s;
    const uint32_t st = ks_rd(KS_SYS_SEC_STATUS);
    ks_sec_seen |= st;
    ks_fault_report(KS_FAULT_SRC_SEC, st, ks_rd(KS_SYS_SEC_LAST), 0);
    ks_wr(KS_SYS_SEC_STATUS, st);
}
static void isr_ras(uint32_t s)
{
    (void)s;
    const uint32_t st = ks_rd(KS_RAS_STATUS);
    ks_ras_seen |= st;
    ks_fault_report(KS_FAULT_SRC_RAS, st, ks_rd(KS_RAS_LAST_ADDR), ks_rd(KS_RAS_LAST_INFO));
    ks_wr(KS_RAS_STATUS, st);
}
static void isr_host(uint32_t s) { (void)s; ks_wr(KS_INTC_ENABLE, ks_rd(KS_INTC_ENABLE) & ~KS_BIT(KS_IRQ_HOST)); ks_mbx_flag = 1; }
static void isr_eng(uint32_t s)
{
    uint32_t e;
    switch (s) {
    case KS_IRQ_DMA: e = KS_ENG_DMA; break;
    case KS_IRQ_CPW: e = KS_ENG_CPW; break;
    case KS_IRQ_VIO: e = KS_ENG_VIO; break;
    case KS_IRQ_PKT: e = KS_ENG_PKT; break;
    default:         e = KS_ENG_MPL; break;
    }
    const uint32_t st = ks_rd(KS_ESH(e, KS_ESH_IRQ_STAT));
    ks_wr(KS_ESH(e, KS_ESH_IRQ_STAT), st);                       /* W1C: acknowledge at the source before completing */
    ks_eng_events[e] |= st;
    if (st & KS_ESH_IRQ_STAT_FAULT_MASK) ks_fault_report(KS_FAULT_SRC_ENG, ks_rd(KS_ESH(e, KS_ESH_ERR_CODE)), e, st);
    if (e == KS_ENG_DMA && (st & KS_ESH_IRQ_STAT_EVENT_MASK)) ks_dma_done_flag = 1;
}

void ks_default_isrs(void)
{
    ks_irq_register(KS_IRQ_WDT, isr_wdt);
    ks_irq_register(KS_IRQ_SEC, isr_sec);
    ks_irq_register(KS_IRQ_RAS, isr_ras);
    ks_irq_register(KS_IRQ_HOST, isr_host);
    ks_irq_register(KS_IRQ_DMA, isr_eng);
    ks_irq_register(KS_IRQ_CPW, isr_eng);
    ks_irq_register(KS_IRQ_VIO, isr_eng);
    ks_irq_register(KS_IRQ_PKT, isr_eng);
    ks_irq_register(KS_IRQ_MPL, isr_eng);
}

void ks_irq_init(void)
{
    ks_default_isrs();
    ks_wr(KS_INTC_THRESH, 0u);
    for (uint32_t e = 0; e < KS_NUM_ENG; e++)
        if (ks_dev.present & KS_BIT(e)) ks_wr(KS_ESH(e, KS_ESH_IRQ_EN), 0x7u);
    ks_wr(KS_SYS_SEC_IE, 0x1FFu);
    ks_wr(KS_RAS_IE, KS_BIT(KS_RAS_SRAM_CE) | KS_BIT(KS_RAS_SRAM_UE) | KS_BIT(KS_RAS_BUS_ERR) | KS_BIT(KS_RAS_ENG_FAULT) | KS_BIT(KS_RAS_ENG_TIMEOUT));
    ks_wr(KS_MBX_IRQ_EN, 1u);
    uint32_t en = 0;
    for (uint32_t s = 1; s <= KS_NUM_IRQ; s++) en |= KS_BIT(s);
    ks_wr(KS_INTC_ENABLE, en);
    KS_CSRW(mie, KS_MIE_MEIE | KS_MIE_MTIE | KS_MIE_MSIE);
    ks_irq_global_enable();
}
