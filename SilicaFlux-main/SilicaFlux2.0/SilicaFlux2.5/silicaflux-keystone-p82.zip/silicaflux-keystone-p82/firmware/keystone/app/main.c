/* Keystone management firmware entry. */
#include "ks_fw.h"

#ifdef KS_SCENARIO_wdt
static uint32_t g_intc_enable_at_entry, g_sec_count_at_entry;
/* Watchdog reset scenario: configure and LOCK the watchdog, prove kicking works, then stop kicking:
 * BARK interrupt, then BITE -> warm reset -> the ROM boots again and this code reports what survived. */
static void wdt_scenario(void)
{
    const uint32_t cause = ks_rd(KS_SYS_RESET_CAUSE);
    const uint32_t boots = (ks_rd(KS_SYS_BOOT_STAGE) & KS_SYS_BOOT_STAGE_COUNT_MASK) >> KS_SYS_BOOT_STAGE_COUNT_SHIFT;
    ks_puts("[FW] wdt scenario boot=");
    ks_putdec(boots);
    ks_puts(" cause=0x");
    ks_puthex(cause);
    ks_putc('\n');
    if (cause & KS_BIT(KS_RSTCAUSE_WDT)) {                       /* second boot: after the watchdog bite */
        KS_CHECK_EQ(boots, 2u);
        KS_CHECK_EQ(cause, KS_BIT(KS_RSTCAUSE_POR) | KS_BIT(KS_RSTCAUSE_WDT));   /* POR from the first boot is still recorded */
        KS_CHECK_EQ(ks_rd(KS_WDT_CTRL), 0u);                     /* watchdog (and its LOCK) are back in their reset state */
        KS_CHECK_EQ(ks_rd(KS_WDT_LOAD), 0x100000u);
        KS_CHECK_EQ(g_intc_enable_at_entry, 0u);                 /* the warm reset cleared the interrupt controller ... */
        KS_CHECK(g_sec_count_at_entry > 0u);                  /* ... but the always-on security record survived */
        KS_CHECK_EQ(ks_rd(KS_SYS_SCRATCH2), 0x600DF00Du);        /* ... and so did SCRATCH (always-on) */
        KS_CHECK_EQ(ks_rd(KS_RAS_BUS_COUNT) > 0u, 1u);           /* RAS counters survived */
        KS_CHECK_EQ(ks_rd(KS_DRAM_BASE + 0x3000u), 0x1BADB002u); /* SRAM contents are retained across a warm reset */
        ks_wr(KS_SYS_RESET_CAUSE, 0xFu);
        KS_CHECK_EQ(ks_rd(KS_SYS_RESET_CAUSE), 0u);
        ks_puts("[FW] WDT RESET OBSERVED\n");
        return;
    }
    ks_wr(KS_SYS_SCRATCH2, 0x600DF00Du);
    ks_wr(KS_DRAM_BASE + 0x3000u, 0x1BADB002u);
    ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
    (void)ks_rd(0x50000000u);                                    /* leave a RAS bus-error count behind */
    KS_CHECK(ks_trap_hit());
    ks_wr(KS_CMD_KEY, 0x1u);                                     /* and a security violation */
    /* configure: BARK after 4000 clocks, BITE 3000 clocks later, reset on bite, then LOCK */
    ks_wr(KS_WDT_LOAD, 4000u);
    ks_wr(KS_WDT_BITE, 3000u);
    ks_wr(KS_WDT_CTRL, KS_WDT_CTRL_EN_MASK | KS_WDT_CTRL_IRQ_EN_MASK | KS_WDT_CTRL_RST_EN_MASK);
    ks_wr(KS_WDT_CTRL, KS_WDT_CTRL_EN_MASK | KS_WDT_CTRL_IRQ_EN_MASK | KS_WDT_CTRL_RST_EN_MASK | KS_WDT_CTRL_LOCK_MASK);
    ks_wr(KS_WDT_CTRL, KS_WDT_CTRL_IRQ_EN_MASK);                 /* a locked watchdog cannot be disabled ... */
    KS_CHECK_EQ(ks_rd(KS_WDT_CTRL) & 0x7u, 0x7u);
    ks_wr(KS_WDT_LOAD, 0x7FFFFFFFu);                             /* ... or re-timed */
    KS_CHECK_EQ(ks_rd(KS_WDT_LOAD), 4000u);
    ks_wdt_barks = 0;
    for (int i = 0; i < 3; i++) { ks_delay(2500); ks_wr(KS_WDT_KICK, KS_KEY_WDT); }   /* kicking keeps the system alive */
    KS_CHECK_EQ(ks_wdt_barks, 0u);
    KS_CHECK_EQ(ks_rd(KS_WDT_KICKS), 3u);
}
#endif

void ks_main(void)
{
    ks_puts("[FW] Keystone management firmware v");
    ks_puthex(KS_FW_VERSION_WORD);
    ks_putc('\n');
    ks_boot_report(KS_STAGE_MGMT_FW, KS_BSTAT_RUNNING);
#ifdef KS_SCENARIO_wdt
    g_intc_enable_at_entry = ks_rd(KS_INTC_ENABLE);              /* sampled before ks_irq_init() */
    g_sec_count_at_entry = ks_rd(KS_SYS_SEC_COUNT);
#endif
    ks_discover();
#ifndef KS_SCENARIO_regs
    ks_irq_init();                                             /* the register walker runs with interrupts off */
#endif

#ifdef KS_SCENARIO_wdt
    wdt_scenario();
    const int ok = (ks_fails == 0);
#elif defined(KS_SCENARIO_regs)
    t_regs();
    const int ok = (ks_fails == 0);
#else
    const int ok = ks_selftest_run();
#endif
    if (!ok) {
        ks_puts("[FW] SELFTEST FAILED checks=");
        ks_putdec(ks_checks);
        ks_puts(" fails=");
        ks_putdec(ks_fails);
        ks_putc('\n');
        ks_boot_fail(KS_STAGE_MGMT_FW, KS_BERR_FW_SELFTEST_FAIL);
        for (;;) ks_wfi();
    }
    ks_boot_report(KS_STAGE_MGMT_FW, KS_BSTAT_OK);
    ks_boot_report(KS_STAGE_READY, KS_BSTAT_RUNNING);
    ks_boot_report(KS_STAGE_READY, KS_BSTAT_OK);
    ks_puts("[FW] SELFTEST PASSED checks=");
    ks_putdec(ks_checks);
    ks_puts(" fails=0\n[FW] DEVICE READY\n");

#ifdef KS_SCENARIO_wdt
    if (!(ks_rd(KS_SYS_RESET_CAUSE) & KS_BIT(KS_RSTCAUSE_WDT)) && ks_rd(KS_SYS_RESET_CAUSE) != 0u) {
        for (;;) ks_wfi();                                   /* first boot: stop kicking and wait for the watchdog */
    }
#endif
    /* service loop: host mailbox requests arrive as INTC.HOST interrupts */
    for (;;) {
        if (ks_mbx_flag) ks_mbx_service();
        else ks_wfi();
    }
}
