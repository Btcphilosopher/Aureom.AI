/* Fault reporting: a small ring of the most recent faults, plus console output. */
#include "ks_fw.h"

#define N_FAULTS 16u
static ks_fault_t g_faults[N_FAULTS];
static uint32_t g_nfaults;

static const char *const src_name[] = {"fw", "cmd", "eng", "ras", "sec", "wdt"};

void ks_fault_report(uint32_t src, uint32_t code, uint32_t a0, uint32_t a1)
{
    ks_fault_t *f = &g_faults[g_nfaults % N_FAULTS];
    f->when = ks_now();
    f->src = src;
    f->code = code;
    f->arg0 = a0;
    f->arg1 = a1;
    g_nfaults++;
}

uint32_t ks_fault_count(void) { return g_nfaults; }

const ks_fault_t *ks_fault_get(uint32_t i)
{
    const uint32_t first = (g_nfaults > N_FAULTS) ? g_nfaults - N_FAULTS : 0u;
    if (first + i >= g_nfaults) return (const ks_fault_t *)0;
    return &g_faults[(first + i) % N_FAULTS];
}

void ks_fault_dump(void)
{
    ks_puts("[FW] fault log (");
    ks_putdec(g_nfaults);
    ks_puts(")\n");
    for (uint32_t i = 0;; i++) {
        const ks_fault_t *f = ks_fault_get(i);
        if (!f) break;
        ks_puts("[FW]   ");
        ks_puts(f->src < 6u ? src_name[f->src] : "?");
        ks_puts(" code=0x");
        ks_puthex(f->code);
        ks_puts(" a0=0x");
        ks_puthex(f->arg0);
        ks_puts(" a1=0x");
        ks_puthex(f->arg1);
        ks_putc('\n');
    }
}
