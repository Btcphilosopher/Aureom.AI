/* Self-test groups: machine timer and interrupt controller. */
#include "ks_fw.h"

static void tmr_set_cmp(uint32_t lo)
{
    ks_wr(KS_TMR_MTIMECMP_HI, 0xFFFFFFFFu);        /* safe 64-bit update: HI=max, LO, HI */
    ks_wr(KS_TMR_MTIMECMP_LO, lo);
    ks_wr(KS_TMR_MTIMECMP_HI, 0u);
}

void t_timer(void)
{
    ks_group("timer");
    KS_CHECK_EQ(ks_rd(KS_TMR_CLK_HZ), 100000000u);
    KS_CHECK(ks_rd(KS_TMR_CTRL) & 1u);
    KS_CHECK_EQ(ks_rd(KS_TMR_MTIMECMP_LO), 0xFFFFFFFFu);
    KS_CHECK_EQ(ks_rd(KS_TMR_MTIMECMP_HI), 0xFFFFFFFFu);

    /* time advances one tick per clock */
    uint32_t a = ks_now();
    ks_delay(100);
    uint32_t b = ks_now();
    KS_CHECK(b - a >= 100u && b - a < 140u);
    /* coherent 64-bit read: LO read latches HI */
    (void)ks_rd(KS_TMR_MTIME_LO);
    KS_CHECK_EQ(ks_rd(KS_TMR_MTIME_HI), 0u);
    KS_CHECK(!(ks_rd(KS_TMR_STATUS) & KS_TMR_STATUS_MTIP_MASK));

    /* machine timer interrupt */
    ks_mti_count = 0;
    tmr_set_cmp(ks_now() + 400u);
    KS_CHECK(ks_wait_flag(&ks_mti_count, 20000u));
    KS_CHECK_EQ(ks_mti_count, 1u);
    KS_CHECK(!(ks_rd(KS_TMR_STATUS) & KS_TMR_STATUS_MTIP_MASK));       /* the handler moved mtimecmp away */

    /* software interrupt */
    ks_msi_count = 0;
    ks_wr(KS_TMR_MSIP, 1u);
    KS_CHECK(ks_wait_flag(&ks_msi_count, 20000u));
    KS_CHECK_EQ(ks_msi_count, 1u);
    KS_CHECK_EQ(ks_rd(KS_TMR_MSIP), 0u);

    /* prescaler: PRESC = 3 -> one tick per 4 clocks */
    ks_wr(KS_TMR_CTRL, 1u | (3u << 8));
    const uint32_t c0 = KS_CSRR(mcycle), t0 = ks_now();
    while ((KS_CSRR(mcycle) - c0) < 800u) { }
    const uint32_t dt = ks_now() - t0;
    KS_CHECK(dt >= 195u && dt <= 205u);
    ks_wr(KS_TMR_CTRL, 1u);

    /* a disabled timer stops counting */
    ks_wr(KS_TMR_CTRL, 0u);
    const uint32_t f0 = ks_now();
    ks_delay(0);
    for (volatile int i = 0; i < 50; i++) { }
    KS_CHECK(ks_now() - f0 <= 1u);
    ks_wr(KS_TMR_CTRL, 1u);

    /* WFI is woken by the timer */
    ks_mti_count = 0;
    tmr_set_cmp(ks_now() + 3000u);
    const uint32_t w0 = ks_now();
    while (!ks_mti_count) ks_wfi();
    KS_CHECK(ks_now() - w0 >= 2900u);
}

/* ---------------------------------------------------------------- interrupt controller */
static void rec_isr(uint32_t s) { (void)s; }

static void intc_all_isrs(ks_isr_t fn)
{
    for (uint32_t s = 1; s <= KS_NUM_IRQ; s++) ks_irq_register(s, fn);
}

static void intc_quiet(void)
{
    ks_irq_global_disable();
    ks_wr(KS_INTC_PEND_CLR, 0x7FFu);
    for (;;) {                                            /* drain anything still claimable */
        const uint32_t id = ks_rd(KS_INTC_CLAIM);
        if (!id) break;
        ks_wr(KS_INTC_CLAIM, id);
    }
}

static int order_is(const uint32_t *exp, uint32_t n)
{
    if (ks_irq_order_n != n) return 0;
    for (uint32_t i = 0; i < n; i++) if (ks_irq_order[i] != exp[i]) return 0;
    return 1;
}

void t_intc(void)
{
    ks_group("intc");
    intc_quiet();
    /* reset-value priorities and defaults */
    static const uint32_t prio[KS_NUM_IRQ + 1] = {0, 7, 7, 6, 5, 5, 4, 3, 3, 2, 4};
    for (uint32_t s = 1; s <= KS_NUM_IRQ; s++) KS_CHECK_EQ(ks_rd(KS_INTC_PRIO(s)), prio[s]);
    KS_CHECK_EQ(ks_rd(KS_INTC_TYPE), 0u);
    KS_CHECK_EQ(ks_rd(KS_INTC_THRESH), 0u);
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), 0u);                                      /* nothing pending: claim returns 0 */

    intc_all_isrs(rec_isr);

    /* (1) ten simultaneous events are delivered one by one in priority order, none lost, none twice */
    ks_irq_order_reset();
    ks_wr(KS_INTC_PEND_SET, 0x7FEu);
    KS_CHECK_EQ(ks_rd(KS_INTC_PEND), 0x7FEu);
    KS_CHECK_EQ(ks_rd(KS_INTC_IRQ_OUT), 1u);
    KS_CHECK_EQ(ks_rd(KS_INTC_TOP) & 0xFu, 1u);                                 /* WDT wins (priority 7, lowest id) */
    ks_irq_global_enable();                                                     /* the pending MEI is taken here */
    ks_irq_global_disable();
    static const uint32_t ord1[10] = {1, 2, 3, 4, 5, 6, 10, 7, 8, 9};
    KS_CHECK(order_is(ord1, 10));
    KS_CHECK_EQ(ks_rd(KS_INTC_PEND), 0u);
    KS_CHECK_EQ(ks_rd(KS_INTC_INSVC), 0u);
    for (uint32_t s = 1; s <= KS_NUM_IRQ; s++) KS_CHECK(ks_irq_count[s] >= 1u);

    /* (2) re-prioritise: PKT becomes priority 7 -> it follows WDT and SEC (lowest id first among equals) */
    ks_wr(KS_INTC_PRIO(9), 7u);
    ks_irq_order_reset();
    ks_wr(KS_INTC_PEND_SET, 0x7FEu);
    ks_irq_global_enable(); ks_irq_global_disable();
    static const uint32_t ord2[10] = {1, 2, 9, 3, 4, 5, 6, 10, 7, 8};
    KS_CHECK(order_is(ord2, 10));
    ks_wr(KS_INTC_PRIO(9), 2u);

    /* (3) threshold: only priorities above THRESH are delivered, the rest stay pending */
    ks_wr(KS_INTC_THRESH, 4u);
    ks_irq_order_reset();
    ks_wr(KS_INTC_PEND_SET, 0x7FEu);
    ks_irq_global_enable(); ks_irq_global_disable();
    static const uint32_t ord3[5] = {1, 2, 3, 4, 5};
    KS_CHECK(order_is(ord3, 5));
    KS_CHECK_EQ(ks_rd(KS_INTC_PEND), 0x7C0u);                                   /* sources 6..10 still pending */
    ks_wr(KS_INTC_THRESH, 0u);
    ks_irq_order_reset();
    ks_irq_global_enable(); ks_irq_global_disable();
    static const uint32_t ord4[5] = {6, 10, 7, 8, 9};
    KS_CHECK(order_is(ord4, 5));
    KS_CHECK_EQ(ks_rd(KS_INTC_PEND), 0u);

    /* (4) a disabled source is not delivered, an enabled one is */
    const uint32_t en = ks_rd(KS_INTC_ENABLE);
    ks_wr(KS_INTC_ENABLE, en & ~KS_BIT(KS_IRQ_DMA));
    ks_irq_order_reset();
    ks_wr(KS_INTC_PEND_SET, KS_BIT(KS_IRQ_DMA));
    KS_CHECK_EQ(ks_rd(KS_INTC_IRQ_OUT), 0u);
    ks_irq_global_enable(); ks_irq_global_disable();
    KS_CHECK_EQ(ks_irq_order_n, 0u);
    ks_wr(KS_INTC_ENABLE, en);
    KS_CHECK_EQ(ks_rd(KS_INTC_IRQ_OUT), 1u);
    ks_irq_global_enable(); ks_irq_global_disable();
    KS_CHECK_EQ(ks_irq_order_n, 1u);
    KS_CHECK_EQ(ks_irq_order[0], KS_IRQ_DMA);

    /* (5) claim / complete: in-service masking, spurious complete ignored */
    intc_quiet();
    ks_wr(KS_INTC_PEND_SET, KS_BIT(KS_IRQ_DMA));
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), KS_IRQ_DMA);
    KS_CHECK_EQ(ks_rd(KS_INTC_INSVC), KS_BIT(KS_IRQ_DMA));
    KS_CHECK_EQ(ks_rd(KS_INTC_IRQ_OUT), 0u);
    ks_wr(KS_INTC_PEND_SET, KS_BIT(KS_IRQ_DMA));                                /* a new event while in service ... */
    KS_CHECK_EQ(ks_rd(KS_INTC_IRQ_OUT), 0u);                                    /* ... is masked */
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), 0u);
    ks_wr(KS_INTC_CLAIM, KS_IRQ_WDT);                                           /* completing a source that is not in service */
    KS_CHECK_EQ(ks_rd(KS_INTC_INSVC), KS_BIT(KS_IRQ_DMA));                      /* ... changes nothing */
    ks_wr(KS_INTC_CLAIM, KS_IRQ_DMA);                                           /* complete */
    KS_CHECK_EQ(ks_rd(KS_INTC_INSVC), 0u);
    KS_CHECK_EQ(ks_rd(KS_INTC_IRQ_OUT), 1u);                                    /* the held event is delivered now */
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), KS_IRQ_DMA);
    ks_wr(KS_INTC_CLAIM, KS_IRQ_DMA);
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), 0u);
    const uint32_t cnt = ks_rd(KS_INTC_COUNT(KS_IRQ_DMA));
    KS_CHECK(cnt >= 3u);

    /* (6) level gateway: a real source line (CPW shell) re-pends until it is cleared AT THE SOURCE */
    const uint32_t cpw = KS_ENG_CPW;
    intc_quiet();
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_EN), 1u);
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_STAT), 7u);
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_SET), 1u);
    KS_CHECK(ks_rd(KS_INTC_RAW) & KS_BIT(KS_IRQ_CPW));
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), KS_IRQ_CPW);
    ks_wr(KS_INTC_CLAIM, KS_IRQ_CPW);
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), KS_IRQ_CPW);                              /* still asserted: delivered again */
    ks_wr(KS_INTC_CLAIM, KS_IRQ_CPW);
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_STAT), 1u);                                    /* clear at the source */
    KS_CHECK(!(ks_rd(KS_INTC_RAW) & KS_BIT(KS_IRQ_CPW)));
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), 0u);

    /* (7) edge gateway: one delivery per rising edge even though the line stays high */
    ks_wr(KS_INTC_TYPE, KS_BIT(KS_IRQ_CPW));
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_SET), 1u);
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), KS_IRQ_CPW);
    ks_wr(KS_INTC_CLAIM, KS_IRQ_CPW);
    KS_CHECK(ks_rd(KS_INTC_RAW) & KS_BIT(KS_IRQ_CPW));                          /* line still high */
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), 0u);                                      /* but no second delivery */
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_STAT), 1u);
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_SET), 1u);                                     /* a new edge */
    KS_CHECK_EQ(ks_rd(KS_INTC_CLAIM), KS_IRQ_CPW);
    ks_wr(KS_INTC_CLAIM, KS_IRQ_CPW);
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_STAT), 7u);
    ks_wr(KS_ESH(cpw, KS_ESH_IRQ_EN), 7u);
    ks_wr(KS_INTC_TYPE, 0u);

    /* (8) registers reject writes to reserved bits */
    ks_wr(KS_INTC_ENABLE, 0xFFFFFFFFu);
    KS_CHECK_EQ(ks_rd(KS_INTC_ENABLE), 0x7FEu);
    ks_wr(KS_INTC_ENABLE, en);

    intc_quiet();
    ks_default_isrs();
    ks_irq_global_enable();
}

/* ---------------------------------------------------------------- concurrent REAL events */
#define SHM_SRC (KS_SHM_BASE + 0x1000u)
#define SHM_DST (KS_SHM_BASE + 0x2000u)

void t_simul(void)
{
    ks_group("simultaneous real events");
    ks_irq_global_disable();
    ks_wr(KS_INTC_PEND_CLR, 0x7FFu);
    for (;;) { const uint32_t id = ks_rd(KS_INTC_CLAIM); if (!id) break; ks_wr(KS_INTC_CLAIM, id); }

    /* prepare: queues on CPW and VIO, a DMA copy, all with short latency */
    KS_CHECK_EQ(ks_queue_create(KS_ENG_CPW, 1, 1, KS_SHM_BASE + 0x3000u, 8), KS_CERR_OK);
    KS_CHECK_EQ(ks_queue_create(KS_ENG_VIO, 1, 1, KS_SHM_BASE + 0x3000u, 8), KS_CERR_OK);
    KS_CHECK_EQ(ks_dma_init(), 0u);
    KS_CHECK_EQ(ks_dma_map(0, 3, KS_SHM_BASE, KS_SHM_SIZE, KS_SHM_BASE, 3u), 0u);
    ks_wr(KS_CPW_MODEL_CTRL, 0x0800u);
    ks_wr(KS_VIO_MODEL_CTRL, 0x0800u);
    ks_irq_order_reset();
    for (uint32_t i = 0; i < 4u; i++) ks_irq_count[i] = 0;
    for (uint32_t i = 1; i <= KS_NUM_IRQ; i++) ks_irq_count[i] = 0;

    /* start everything while interrupts are globally off: the events pile up in the controller */
    ks_dma_done_flag = 0;
    ks_dma_desc_t *d = (ks_dma_desc_t *)(uintptr_t)KS_SHM_BASE;
    ks_dma_desc(d, 0, KS_DMA_F_HEAD | KS_DMA_F_LAST, 0x42u, 3u, SHM_SRC, SHM_DST, 256u);
    ks_cmd_rsp_t r;
    KS_CHECK_EQ(ks_dma_submit(1, KS_PRIV_TENANT, KS_SHM_BASE, &r), KS_CERR_OK);             /* DMA completion in flight */
    KS_CHECK_EQ(ks_queue_doorbell(KS_ENG_CPW, 1, 1, 2), KS_CERR_OK);                         /* compute completion in flight */
    KS_CHECK_EQ(ks_queue_doorbell(KS_ENG_VIO, 1, 1, 2), KS_CERR_OK);                         /* virtual I/O completion in flight */
    ks_wr(KS_WDT_LOAD, 600u);
    ks_wr(KS_WDT_CTRL, KS_WDT_CTRL_EN_MASK | KS_WDT_CTRL_IRQ_EN_MASK);                       /* watchdog bark soon */
    ks_wr(KS_SYS_SEC_IE, 0x1FFu);
    ks_wr(KS_CMD_KEY, 0x0BADu);                                                              /* a security violation (bad key) */
    ks_wr(KS_CMD_IE, 1u);                                                                    /* a command whose completion is left pending */
    ks_wr(KS_CMD_OP, KS_OP_NOP); ks_wr(KS_CMD_PRIV, KS_PRIV_FIRMWARE);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_CMD_KEY, KS_KEY_CMD);
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_GO_MASK);
    ks_ras_seen = 0;
    ks_wr(KS_RAS_INJ_ADDR, KS_DRAM_BASE + 0x3200u);                                           /* a corrected ECC error */
    ks_wr(KS_RAS_INJ_CTRL, 1u | (1u << 1) | (4u << 16));
    ks_wr(KS_DRAM_BASE + 0x3200u, 7u);
    (void)ks_rd(KS_DRAM_BASE + 0x3200u);

    /* wait until all expected sources are pending, with interrupts still off */
    const uint32_t want = KS_BIT(KS_IRQ_WDT) | KS_BIT(KS_IRQ_SEC) | KS_BIT(KS_IRQ_RAS) | KS_BIT(KS_IRQ_CMD) |
                          KS_BIT(KS_IRQ_DMA) | KS_BIT(KS_IRQ_CPW) | KS_BIT(KS_IRQ_VIO);
    const uint32_t t0 = ks_now();
    while ((ks_rd(KS_INTC_PEND) & want) != want && (ks_now() - t0) < 20000u) { }
    KS_CHECK_EQ(ks_rd(KS_INTC_PEND) & want, want);
    KS_CHECK_EQ(ks_irq_order_n, 0u);                                                         /* nothing was delivered yet */

    /* now let them all through: strictly by priority, each exactly once */
    ks_irq_global_enable();
    ks_irq_global_disable();
    static const uint32_t exp[7] = {KS_IRQ_WDT, KS_IRQ_SEC, KS_IRQ_RAS, KS_IRQ_CMD, KS_IRQ_DMA, KS_IRQ_CPW, KS_IRQ_VIO};
    KS_CHECK_EQ(ks_irq_order_n, 7u);
    for (uint32_t i = 0; i < 7u && i < ks_irq_order_n; i++) KS_CHECK_EQ(ks_irq_order[i], exp[i]);
    KS_CHECK(ks_dma_done_flag);
    ks_dma_cpl_t c;
    KS_CHECK(ks_dma_wait(&c, 100000u));
    KS_CHECK_EQ(c.status, 0u);
    KS_CHECK_EQ(c.bytes, 256u);
    KS_CHECK_EQ(ks_rd(KS_INTC_PEND) & want, 0u);                                             /* all causes were cleared at their sources */
    ks_wr(KS_CMD_CTRL, KS_CMD_CTRL_CLEAR_MASK);
    ks_wr(KS_CMD_IE, 0u);
    ks_wr(KS_WDT_CTRL, 0u);
    ks_wr(KS_WDT_LOAD, 0x100000u);
    ks_wr(KS_CPW_MODEL_CTRL, 0x0400u);
    ks_wr(KS_VIO_MODEL_CTRL, 0x0400u);
    ks_irq_global_enable();
}
