/* CloudDMA (Project 64) driver. Descriptors and the completion record live in the shared buffer SRAM (SHM),
 * which is the memory the DMA master reads and writes. Layout: descriptors @SHM+0x000..0x3FF, record @SHM+0x400. */
#include "ks_fw.h"

volatile uint32_t ks_dma_done_flag;

#define CSR_CTRL      0x010u
#define CSR_TIMEOUT   0x020u
#define CSR_CH_CTRL   0x100u
#define CSR_CH_STATUS 0x104u
#define DESC_BASE     (KS_SHM_BASE + 0x000u)
#define CPL_BASE      (KS_SHM_BASE + 0x400u)

uint32_t ks_dma_init(void)
{
    if (ks_rd(KS_DMA_CSR(0)) != 0x5346444Du) return 1u;                 /* 'SFDM' */
    ks_wr(KS_DMA_CSR(CSR_TIMEOUT), 400000u);
    ks_wr(KS_DMA_CSR(CSR_CTRL), KS_DMA_ENABLE_BIT);
    ks_wr(KS_DMA_PTBL_STATUS, 1u);
    return (ks_rd(KS_DMA_CSR(CSR_CTRL)) & 1u) ? 0u : 2u;
}

uint32_t ks_dma_map(uint32_t idx, uint32_t domain, uint32_t base, uint32_t size, uint32_t pa, uint32_t perm)
{
    ks_wr(KS_DMA_PTBL_IDX, idx);
    ks_wr(KS_DMA_PTBL_CFG, 1u | (domain << KS_DMA_PTBL_CFG_DOMAIN_SHIFT) | (perm << KS_DMA_PTBL_CFG_PERM_SHIFT));
    ks_wr(KS_DMA_PTBL_BASE_LO, base); ks_wr(KS_DMA_PTBL_BASE_HI, 0);
    ks_wr(KS_DMA_PTBL_SIZE_LO, size); ks_wr(KS_DMA_PTBL_SIZE_HI, 0);
    ks_wr(KS_DMA_PTBL_PA_LO, pa);     ks_wr(KS_DMA_PTBL_PA_HI, 0);
    ks_wr(KS_DMA_PTBL_CTRL, 1u);
    ks_delay(16);
    const uint32_t rej = ks_rd(KS_DMA_PTBL_STATUS) & 1u;
    if (rej) ks_wr(KS_DMA_PTBL_STATUS, 1u);
    return rej;
}

uint32_t ks_dma_unmap(uint32_t idx)
{
    ks_wr(KS_DMA_PTBL_IDX, idx);
    ks_wr(KS_DMA_PTBL_CFG, 0u);
    ks_wr(KS_DMA_PTBL_CTRL, 1u);
    ks_delay(16);
    return 0;
}

void ks_dma_desc(ks_dma_desc_t *d, uint32_t pos, uint32_t flags, uint32_t txn, uint32_t domain_claim,
                 uint32_t src, uint32_t dst, uint32_t len)
{
    volatile uint32_t *w = (volatile uint32_t *)d;
    for (int i = 0; i < 16; i++) w[i] = 0;
    w[0] = 1u | (0u << 8) | (flags << 16);                    /* VERSION 1, OPCODE 0 (COPY) */
    w[1] = (txn & 0xFFFFu) | (domain_claim << 16);
    w[2] = 0;                                                  /* SRC/DST/CPL ASID 0 */
    w[3] = len;
    w[4] = src; w[6] = dst;
    if (flags & KS_DMA_F_CPL_EN) w[10] = CPL_BASE;
    w[12] = pos;
}

uint32_t ks_dma_submit(uint32_t tenant, uint32_t priv, uint32_t head, ks_cmd_rsp_t *r)
{
    ks_cmd_t c = {KS_OP_DMA_SUBMIT, KS_ENG_DMA, tenant, priv, {head, 0, 0, 0}};
    ks_dma_done_flag = 0;
    return ks_cmd_submit(&c, r);
}

int ks_dma_wait(ks_dma_cpl_t *c, uint32_t timeout)
{
    if (!ks_wait_flag(&ks_dma_done_flag, timeout)) return 0;
    const uint32_t st = ks_rd(KS_DMA_CPL_STAT);
    c->status = (st & KS_DMA_CPL_STAT_STATUS_MASK) >> KS_DMA_CPL_STAT_STATUS_SHIFT;
    c->err = (st & KS_DMA_CPL_STAT_ERR_MASK) >> KS_DMA_CPL_STAT_ERR_SHIFT;
    c->fault = (st & KS_DMA_CPL_STAT_FAULT_MASK) >> KS_DMA_CPL_STAT_FAULT_SHIFT;
    c->txn = ks_rd(KS_DMA_CPL_TXN);
    c->domain = ks_rd(KS_DMA_CPL_DOMAIN);
    c->bytes = ks_rd(KS_DMA_CPL_BYTES);
    c->crc = ks_rd(KS_DMA_CPL_CRC);
    ks_wr(KS_DMA_CPL_POP, 1u);                                 /* consume: lets CloudDMA retire the event */
    ks_dma_done_flag = 0;
    return (st & KS_DMA_CPL_STAT_VALID_MASK) ? 1 : 0;
}

/* One-element COPY with CRC and completion record. */
uint32_t ks_dma_copy(uint32_t tenant, uint32_t domain, uint32_t src, uint32_t dst, uint32_t len, ks_dma_cpl_t *c)
{
    ks_dma_desc_t *d = (ks_dma_desc_t *)(uintptr_t)DESC_BASE;
    ks_dma_desc(d, 0, KS_DMA_F_HEAD | KS_DMA_F_LAST | KS_DMA_F_CPL_EN | KS_DMA_F_CRC_EN, 0x100u + tenant, domain, src, dst, len);
    ks_cmd_rsp_t r;
    uint32_t e = ks_dma_submit(tenant, KS_PRIV_TENANT, DESC_BASE, &r);
    if (e != KS_CERR_OK) return 0x100u | e;
    if (!ks_dma_wait(c, 4000000u)) return 0x200u;
    return 0;
}

/* Recovery after a failed transfer: pop any stale record, soft-reset CloudDMA through the engine reset, re-initialise. */
uint32_t ks_dma_recover(void)
{
    ks_wr(KS_DMA_CPL_POP, 1u);
    ks_dma_done_flag = 0;
    uint32_t e = ks_recover_engine(KS_ENG_DMA);
    if (e) return e;
    return ks_dma_init();
}
