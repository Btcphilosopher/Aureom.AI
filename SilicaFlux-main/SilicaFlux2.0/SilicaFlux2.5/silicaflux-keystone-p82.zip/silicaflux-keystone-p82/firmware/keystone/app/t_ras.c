/* Self-test groups: RAS / ECC, watchdog, telemetry, fault reporting. */
#include "ks_fw.h"

static void settle(void) { ks_delay(500); }

/* corrupt the next write to `addr` (byte lane `lane`) by XORing `mask` into the lane's 13 stored bits */
static void inject(uint32_t addr, uint32_t lane, uint32_t mask)
{
    ks_wr(KS_RAS_INJ_ADDR, addr);
    ks_wr(KS_RAS_INJ_CTRL, 1u | (lane << 1) | (mask << 16));
}

static uint32_t lw(uint32_t a) { return ks_rd(a); }

void t_ras(void)
{
    ks_group("ras / ecc");
    const uint32_t D = KS_DRAM_BASE + 0x3100u;
    /* RAS state is always-on (it survives a warm reset): every expectation below is relative to the values on entry */
    const uint32_t ce0 = ks_rd(KS_RAS_CE_COUNT), ue0 = ks_rd(KS_RAS_UE_COUNT), ev0 = ks_rd(KS_RAS_EVENTS), inj0 = ks_rd(KS_RAS_INJ_DONE);
    KS_CHECK(ks_rd(KS_RAS_BUS_COUNT) > 0u);                                   /* the earlier invalid accesses were counted */

    /* ---- correctable error in each byte lane, in data / check / overall-parity bit positions: data is corrected */
    static const uint8_t lane[4] = {0, 1, 2, 3};
    static const uint16_t mask[4] = {1u << 2, 1u << 6, 1u << 9, 1u << 12};   /* data, data, check, overall parity */
    for (int i = 0; i < 4; i++) {
        const uint32_t v = 0x11223344u * (uint32_t)(i + 1);
        ks_ras_seen = 0;
        inject(D, lane[i], mask[i]);
        ks_wr(D, v);
        KS_CHECK_EQ(ks_rd(KS_RAS_INJ_DONE), inj0 + (uint32_t)(i + 1));
        KS_CHECK_EQ(ks_rd(KS_RAS_INJ_CTRL) & 1u, 0u);                          /* the injection was consumed */
        KS_CHECK_EQ(lw(D), v);                                                 /* corrected on the way out */
        settle();
        KS_CHECK_EQ(ks_rd(KS_RAS_CE_COUNT), ce0 + (uint32_t)(i + 1));
        KS_CHECK(ks_ras_seen & KS_BIT(KS_RAS_SRAM_CE));                        /* CE interrupt reached the handler */
        KS_CHECK_EQ(ks_rd(KS_RAS_LAST_ADDR), D);
        const uint32_t li = ks_rd(KS_RAS_LAST_INFO);
        KS_CHECK_EQ(li & 0xFu, 1u);                                            /* source: DRAM */
        KS_CHECK((li >> 4) & 1u);                                              /* CE */
        KS_CHECK_EQ((li >> 8) & 3u, (uint32_t)lane[i]);
        KS_CHECK(!((li >> 24) & 1u));                                          /* data-side */
    }
    /* the stored word stays corrupted until it is scrubbed: a second read corrects (and counts) again */
    const uint32_t c1 = ks_rd(KS_RAS_CE_COUNT);
    KS_CHECK_EQ(lw(D), 0x11223344u * 4u);
    KS_CHECK_EQ(ks_rd(KS_RAS_CE_COUNT), c1 + 1u);
    ks_wr(D, 0x11223344u * 4u);                                                /* software scrub: rewrite the corrected value */
    KS_CHECK_EQ(lw(D), 0x11223344u * 4u);
    KS_CHECK_EQ(ks_rd(KS_RAS_CE_COUNT), c1 + 1u);                              /* clean now */

    /* ---- sub-word stores re-encode only their own lane */
    ks_wr(D + 8u, 0xAABBCCDDu);
    *(volatile uint8_t *)(uintptr_t)(D + 9u) = 0x5A;
    *(volatile uint16_t *)(uintptr_t)(D + 10u) = 0x1234u;
    KS_CHECK_EQ(lw(D + 8u), 0x12345ADDu);
    KS_CHECK_EQ(ks_rd(KS_RAS_CE_COUNT), c1 + 1u);

    /* ---- uncorrectable (two bits in one lane): the load FAILS with an access fault, never wrong data */
    ks_ras_seen = 0;
    inject(D + 16u, 1, (1u << 1) | (1u << 4));
    ks_wr(D + 16u, 0xCAFEF00Du);
    ks_expect_trap(KS_CAUSE_LOAD_FAULT, 0);
    (void)lw(D + 16u);
    KS_CHECK(ks_trap_hit());
    settle();
    KS_CHECK_EQ(ks_rd(KS_RAS_UE_COUNT), ue0 + 1u);
    KS_CHECK(ks_ras_seen & KS_BIT(KS_RAS_SRAM_UE));
    KS_CHECK((ks_rd(KS_RAS_LAST_INFO) >> 5) & 1u);                             /* UE flag */
    KS_CHECK_EQ(ks_rd(KS_SYS_BAD_INFO) & KS_SYS_BAD_INFO_REASON_MASK, KS_BADACC_ECC_UE << KS_SYS_BAD_INFO_REASON_SHIFT);
    ks_wr(D + 16u, 0xCAFEF00Du);                                               /* rewriting repairs it */
    KS_CHECK_EQ(lw(D + 16u), 0xCAFEF00Du);

    /* ---- IRAM data region: same behaviour */
    const uint32_t I = KS_IRAM_BASE + KS_IRAM_SIZE - 0x100u;
    inject(I, 0, 1u << 5);
    ks_wr(I, 0x0BADC0DEu);
    const uint32_t ce2 = ks_rd(KS_RAS_CE_COUNT);
    KS_CHECK_EQ(lw(I), 0x0BADC0DEu);
    KS_CHECK_EQ(ks_rd(KS_RAS_CE_COUNT), ce2 + 1u);
    KS_CHECK_EQ(ks_rd(KS_RAS_LAST_INFO) & 0xFu, 0u);                           /* source: IRAM */

    /* ---- instruction-side: a corrupted code word raises an instruction access fault, counted and logged, but does NOT
     *      raise the RAS interrupt (it would be taken before the fetch exception and re-fire after MRET: livelock) */
    volatile uint32_t *code = (volatile uint32_t *)(uintptr_t)(KS_IRAM_BASE + KS_IRAM_SIZE - 0x80u);
    code[0] = 0x00700513u;                                                     /* li  a0, 7 */
    code[1] = 0x00008067u;                                                     /* ret       */
    ks_fence_i();
    uint32_t (*fn)(void) = (uint32_t (*)(void))(uintptr_t)code;
    KS_CHECK_EQ(fn(), 7u);
    ks_ras_seen = 0;
    const uint32_t ue1 = ks_rd(KS_RAS_UE_COUNT);
    inject((uint32_t)(uintptr_t)code, 0, (1u << 0) | (1u << 8));
    code[0] = 0x00700513u;
    ks_fence_i();
    ks_expect_trap(KS_CAUSE_INSN_FAULT, 1);
    (void)fn();
    KS_CHECK(ks_trap_hit());
    settle();
    KS_CHECK_EQ(ks_rd(KS_RAS_UE_COUNT), ue1 + 1u);
    KS_CHECK((ks_rd(KS_RAS_LAST_INFO) >> 24) & 1u);                            /* instruction port */
    KS_CHECK(!(ks_ras_seen & KS_BIT(KS_RAS_SRAM_UE)));                         /* no interrupt class for fetch errors */
    code[0] = 0x00700513u;                                                     /* repair */
    ks_fence_i();
    KS_CHECK_EQ(fn(), 7u);
    code[0] = 0; code[1] = 0;

    /* ---- counters / event log */
    KS_CHECK(ks_rd(KS_RAS_EVENTS) >= ev0 + 7u);
    KS_CHECK(ks_rd(KS_RAS_STATUS) == 0u || ks_rd(KS_RAS_STATUS) != 0xFFFFFFFFu);
    KS_CHECK_EQ(ks_rd(KS_RAS_INJ_DONE), inj0 + 7u);
    /* a masked class does not interrupt */
    ks_wr(KS_RAS_IE, 0u);
    const uint32_t rc = ks_irq_count[KS_IRQ_RAS];
    inject(D + 32u, 2, 1u << 3);
    ks_wr(D + 32u, 5u);
    (void)lw(D + 32u);
    settle();
    KS_CHECK_EQ(ks_irq_count[KS_IRQ_RAS], rc);
    KS_CHECK(ks_rd(KS_RAS_STATUS) & KS_BIT(KS_RAS_SRAM_CE));                   /* sticky flag still set */
    ks_wr(KS_RAS_STATUS, 0x7Fu);
    KS_CHECK_EQ(ks_rd(KS_RAS_STATUS), 0u);
    ks_wr(KS_RAS_IE, KS_BIT(KS_RAS_SRAM_CE) | KS_BIT(KS_RAS_SRAM_UE) | KS_BIT(KS_RAS_BUS_ERR) | KS_BIT(KS_RAS_ENG_FAULT) | KS_BIT(KS_RAS_ENG_TIMEOUT));
    ks_wr(D + 32u, 0u);
}

void t_wdt(void)
{
    ks_group("watchdog");
    KS_CHECK_EQ(ks_rd(KS_WDT_CTRL), 0u);                                      /* disabled out of reset */
    KS_CHECK_EQ(ks_rd(KS_WDT_LOAD), 0x100000u);
    /* no bark while it is kicked */
    ks_wr(KS_WDT_LOAD, 3000u);
    ks_wr(KS_WDT_BITE, 0x100000u);
    ks_wr(KS_WDT_CTRL, KS_WDT_CTRL_EN_MASK | KS_WDT_CTRL_IRQ_EN_MASK);
    ks_wdt_barks = 0;
    const uint32_t k0 = ks_rd(KS_WDT_KICKS);
    for (int i = 0; i < 4; i++) {
        ks_delay(1500);
        ks_wr(KS_WDT_KICK, KS_KEY_WDT);
    }
    KS_CHECK_EQ(ks_wdt_barks, 0u);
    KS_CHECK_EQ(ks_rd(KS_WDT_KICKS), k0 + 4u);
    /* a wrong key neither reloads nor is silent */
    ks_sec_seen = 0;
    ks_wr(KS_WDT_KICK, 0u);
    KS_CHECK_EQ(ks_rd(KS_WDT_KICKS), k0 + 4u);
    settle();
    KS_CHECK(ks_sec_seen & KS_BIT(KS_SEC_WDT_KEY));
    /* stage 1 expires: BARK interrupt, stage 2 starts */
    ks_wr(KS_WDT_KICK, KS_KEY_WDT);
    KS_CHECK(ks_wait_flag(&ks_wdt_barks, 9000u));
    KS_CHECK_EQ(ks_wdt_barks, 1u);
    KS_CHECK(ks_rd(KS_WDT_STATUS) & KS_WDT_STATUS_STAGE2_MASK);              /* the bite countdown is running */
    KS_CHECK_EQ(ks_rd(KS_WDT_STATUS) & KS_WDT_STATUS_BARK_MASK, 0u);          /* the handler cleared the flag */
    ks_wr(KS_WDT_KICK, KS_KEY_WDT);                                          /* a kick in stage 2 restarts from stage 1 */
    KS_CHECK(!(ks_rd(KS_WDT_STATUS) & KS_WDT_STATUS_STAGE2_MASK));
    /* prescaler slows it down: 10 clocks per tick -> no bark within 9000 clocks of a 3000-tick load */
    ks_wr(KS_WDT_CTRL, 0u);
    ks_wr(KS_WDT_PRESC, 9u);
    ks_wr(KS_WDT_CTRL, KS_WDT_CTRL_EN_MASK | KS_WDT_CTRL_IRQ_EN_MASK);
    ks_wdt_barks = 0;
    ks_delay(9000);
    KS_CHECK_EQ(ks_wdt_barks, 0u);
    KS_CHECK(ks_wait_flag(&ks_wdt_barks, 30000u));
    /* disabled: no more barks, counter reloaded */
    ks_wr(KS_WDT_CTRL, 0u);
    ks_wr(KS_WDT_PRESC, 0u);
    ks_wdt_barks = 0;
    ks_delay(5000);
    KS_CHECK_EQ(ks_wdt_barks, 0u);
    KS_CHECK_EQ(ks_rd(KS_WDT_COUNT), ks_rd(KS_WDT_LOAD));
    ks_wr(KS_WDT_LOAD, 0x100000u);
}

void t_telemetry(void)
{
    ks_group("telemetry");
    ks_perf_t a, b;
    KS_CHECK_EQ(ks_perf_snapshot(&a), KS_CERR_OK);
    KS_CHECK(a.cycles > 1000u && a.instret > 1000u);
    KS_CHECK(a.instret < a.cycles);                                          /* CPI > 1 */
    KS_CHECK(a.mmio_rd > 100u && a.mmio_wr > 100u);
    KS_CHECK(a.exc > 5u);                                                    /* expected traps taken earlier */
    KS_CHECK(a.intr > 5u);
    KS_CHECK(a.bus_err > 5u);
    KS_CHECK(a.cmd_acc > 20u && a.cmd_err > 5u);
    KS_CHECK(a.eng_evt[KS_ENG_DMA] >= 4u);
    KS_CHECK(a.eng_flt[KS_ENG_DMA] >= 3u);
    KS_CHECK(a.eng_evt[KS_ENG_CPW] >= 1u && a.eng_evt[KS_ENG_VIO] >= 1u);
    KS_CHECK(a.ras_ce >= 5u && a.ras_ue >= 2u);
    KS_CHECK(a.wdt_kicks >= 5u);
    KS_CHECK(a.sec_viol >= 5u);
    for (uint32_t s = 1; s <= KS_NUM_IRQ; s++)
        if (s != KS_IRQ_PKT && s != KS_IRQ_MPL) KS_CHECK(a.irq_claims[s] >= 1u);
    /* the shadow registers are stable between snapshots even though the live counters run */
    const uint32_t x = ks_rd(KS_TEL_CYCLES_LO);
    ks_delay(200);
    KS_CHECK_EQ(ks_rd(KS_TEL_CYCLES_LO), x);
    KS_CHECK_EQ(ks_perf_snapshot(&b), KS_CERR_OK);
    KS_CHECK_EQ(b.seq, a.seq + 1u);
    KS_CHECK(b.cycles > a.cycles + 200u);
    KS_CHECK(b.instret > a.instret);
    KS_CHECK(b.mmio_wr > a.mmio_wr);
    KS_CHECK_EQ(b.cmd_acc, a.cmd_acc + 1u);                                  /* the PERF_SNAP command itself */
    /* direct snapshot / clear through the register */
    ks_wr(KS_TEL_CTRL, 2u);                                                  /* CLEAR */
    ks_wr(KS_TEL_CTRL, 1u);                                                  /* SNAP */
    KS_CHECK(ks_rd(KS_TEL_CYCLES_LO) < 200u);
    KS_CHECK_EQ(ks_rd(KS_TEL_CYCLES_HI), 0u);
    KS_CHECK(ks_rd(KS_TEL_INSTRET_LO) < 200u);
    KS_CHECK_EQ(ks_rd(KS_TEL_CMD_ACC), 0u);
}

void t_fault(void)
{
    ks_group("fault reporting");
    KS_CHECK(ks_fault_count() > 16u);                                        /* more faults were logged than the ring holds */
    ks_cmd_t bad = {0x7Eu, 0, 0, KS_PRIV_FIRMWARE, {0, 0, 0, 0}};            /* provoke one command fault: it must be the newest entry */
    ks_cmd_rsp_t rsp;
    KS_CHECK_EQ(ks_cmd_submit(&bad, &rsp), KS_CERR_BAD_OPCODE);
    const uint32_t n = ks_fault_count();
    const ks_fault_t *newest = ks_fault_get(15u);
    KS_CHECK(newest != (const ks_fault_t *)0);
    if (newest) { KS_CHECK_EQ(newest->src, KS_FAULT_SRC_CMD); KS_CHECK_EQ(newest->code, KS_CERR_BAD_OPCODE); KS_CHECK_EQ(newest->arg0, 0x7Eu); }
    uint32_t seen = 0;
    for (uint32_t i = 0;; i++) {
        const ks_fault_t *f = ks_fault_get(i);
        if (!f) break;
        seen |= 1u << f->src;
    }
    KS_CHECK(seen & KS_BIT(KS_FAULT_SRC_CMD));
    KS_CHECK(seen & (KS_BIT(KS_FAULT_SRC_ENG) | KS_BIT(KS_FAULT_SRC_RAS) | KS_BIT(KS_FAULT_SRC_SEC) | KS_BIT(KS_FAULT_SRC_WDT)));
    ks_fault_report(KS_FAULT_SRC_FW, 0xABCDu, 1u, 2u);
    KS_CHECK_EQ(ks_fault_count(), n + 1u);
    const ks_fault_t *last = ks_fault_get(15u);                              /* newest of the 16-entry ring */
    KS_CHECK(last != (const ks_fault_t *)0);
    if (last) { KS_CHECK_EQ(last->code, 0xABCDu); KS_CHECK_EQ(last->arg1, 2u); }
    KS_CHECK((const ks_fault_t *)0 == ks_fault_get(16u));
    ks_fault_dump();
}
