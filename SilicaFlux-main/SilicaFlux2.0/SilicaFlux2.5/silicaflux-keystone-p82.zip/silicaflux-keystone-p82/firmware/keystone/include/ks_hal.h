/* Keystone hardware abstraction: MMIO access, CSR access, console. Shared by boot ROM and firmware. */
#ifndef KS_HAL_H
#define KS_HAL_H

#include <stdint.h>
#include <stddef.h>
#include "generated/keystone_regs.h"

#define KS_BIT(n) (1u << (n))

static inline uint32_t ks_rd(uint32_t addr) { return *(volatile uint32_t *)(uintptr_t)addr; }
static inline void     ks_wr(uint32_t addr, uint32_t v) { *(volatile uint32_t *)(uintptr_t)addr = v; }

#define KS_CSRR(name) ({ uint32_t _v; __asm__ volatile("csrr %0, " #name : "=r"(_v)); _v; })
#define KS_CSRW(name, v) __asm__ volatile("csrw " #name ", %0" ::"r"((uint32_t)(v)))
#define KS_CSRS(name, v) __asm__ volatile("csrs " #name ", %0" ::"r"((uint32_t)(v)))
#define KS_CSRC(name, v) __asm__ volatile("csrc " #name ", %0" ::"r"((uint32_t)(v)))

#define KS_MSTATUS_MIE 0x8u
#define KS_MIE_MSIE    (1u << 3)
#define KS_MIE_MTIE    (1u << 7)
#define KS_MIE_MEIE    (1u << 11)

static inline void ks_irq_global_enable(void)  { KS_CSRS(mstatus, KS_MSTATUS_MIE); }
static inline void ks_irq_global_disable(void) { KS_CSRC(mstatus, KS_MSTATUS_MIE); }
static inline void ks_wfi(void) { __asm__ volatile("wfi"); }
static inline void ks_fence_i(void) { __asm__ volatile("fence.i" ::: "memory"); }

/* ---- console (SYS.CONSOLE -> console_valid / console_byte pins) */
static inline void ks_putc(char c) { ks_wr(KS_SYS_CONSOLE, (uint32_t)(uint8_t)c); }
static inline void ks_puts(const char *s) { while (*s) ks_putc(*s++); }
static inline void ks_puthex(uint32_t v)
{
    static const char hx[] = "0123456789abcdef";
    for (int i = 28; i >= 0; i -= 4) ks_putc(hx[(v >> i) & 0xFu]);
}
static inline void ks_putdec(uint32_t v)
{
    char b[11]; int n = 0;
    if (!v) { ks_putc('0'); return; }
    while (v) { b[n++] = (char)('0' + (v % 10u)); v /= 10u; }
    while (n) ks_putc(b[--n]);
}

/* ---- boot status reporting (hardware enforces the stage order) */
static inline void ks_boot_report(uint32_t stage, uint32_t status)
{
    ks_wr(KS_SYS_BOOT_REPORT, (stage << KS_SYS_BOOT_REPORT_STAGE_SHIFT) | status);
}
static inline void ks_boot_fail(uint32_t stage, uint32_t code)
{
    ks_boot_report(stage, KS_BSTAT_FAILED | code);
}

/* ---- firmware image header (stored in the firmware store at KS_FWST_BASE) */
typedef struct {
    uint32_t magic;        /* KS_FW_MAGIC 'KSFW' */
    uint32_t hdr_version;  /* 1 */
    uint32_t load_addr;    /* IRAM address of the payload */
    uint32_t size;         /* payload bytes, multiple of 4 */
    uint32_t entry;        /* entry point (inside the payload) */
    uint32_t fw_version;
    uint32_t payload_crc;  /* CRC-32 (IEEE, reflected) of the payload */
    uint32_t hdr_crc;      /* CRC-32 of the first 7 words */
} ks_fw_hdr_t;
#define KS_FW_HDR_BYTES 32u
#define KS_FW_HDR_VERSION 1u

/* CRC-32 (IEEE 802.3, reflected, init/xorout 0xFFFFFFFF), nibble-table implementation */
static inline uint32_t ks_crc32_update(uint32_t crc, const uint8_t *p, uint32_t n)
{
    static const uint32_t t[16] = {
        0x00000000u, 0x1DB71064u, 0x3B6E20C8u, 0x26D930ACu, 0x76DC4190u, 0x6B6B51F4u, 0x4DB26158u, 0x5005713Cu,
        0xEDB88320u, 0xF00F9344u, 0xD6D6A3E8u, 0xCB61B38Cu, 0x9B64C2B0u, 0x86D3D2D4u, 0xA00AE278u, 0xBDBDF21Cu};
    while (n--) {
        crc ^= *p++;
        crc = (crc >> 4) ^ t[crc & 0xFu];
        crc = (crc >> 4) ^ t[crc & 0xFu];
    }
    return crc;
}

#endif /* KS_HAL_H */
