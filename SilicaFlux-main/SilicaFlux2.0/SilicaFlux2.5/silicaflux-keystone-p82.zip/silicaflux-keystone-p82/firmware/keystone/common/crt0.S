/* Management firmware startup (runs from IRAM after the boot ROM has loaded and verified the image). */
    .section .text.start, "ax"
    .globl _start
_start:
    .option push
    .option norelax
    la      gp, __global_pointer$
    la      sp, _estack
    .option pop
    la      t0, ks_trap_entry
    csrw    mtvec, t0
    /* copy .data (LMA in IRAM -> VMA in DRAM) */
    la      a0, _sdata
    la      a1, _edata
    la      a2, _sidata
1:  bgeu    a0, a1, 2f
    lw      t0, 0(a2)
    sw      t0, 0(a0)
    addi    a0, a0, 4
    addi    a2, a2, 4
    j       1b
2:  /* zero .bss */
    la      a0, _sbss
    la      a1, _ebss
3:  bgeu    a0, a1, 4f
    sw      zero, 0(a0)
    addi    a0, a0, 4
    j       3b
4:  call    ks_main
5:  wfi
    j       5b
