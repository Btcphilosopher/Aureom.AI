#include "generated/keystone_regs.h"
/* Boot ROM entry: reset vector 0x0000_0000. Stack in DRAM (the SRAM init sweep stalls the first access). */
    .section .text.start, "ax"
    .globl _rom_start
_rom_start:
    .option push
    .option norelax
    la      sp, _estack
    .option pop
    la      t0, _rom_trap
    csrw    mtvec, t0
    csrwi   mscratch, 1          /* current boot stage = ROM */
    call    rom_main
1:  wfi
    j       1b

    .align 2
_rom_trap:
    /* any exception in the ROM: report FAILED(ROM_TRAP) for the stage held in mscratch, then halt */
    csrr    t0, mscratch
    slli    t0, t0, 8
    ori     t0, t0, (KS_BSTAT_FAILED | KS_BERR_ROM_TRAP)
    li      t1, KS_SYS_BOOT_REPORT
    sw      t0, 0(t1)
1:  wfi
    j       1b
