/* Machine trap entry: save all registers, call ks_trap_handler(frame), restore, mret.
   frame[0] = mepc, frame[1] = mcause, frame[2] = mtval, frame[3] = mstatus, frame[4..34] = x1..x31 */
    .section .text.trap, "ax"
    .align 4
    .globl ks_trap_entry
ks_trap_entry:
    addi    sp, sp, -144
    sw      x1,  20(sp)
    sw      x3,  28(sp)
    sw      x4,  32(sp)
    sw      x5,  36(sp)
    sw      x6,  40(sp)
    sw      x7,  44(sp)
    sw      x8,  48(sp)
    sw      x9,  52(sp)
    sw      x10, 56(sp)
    sw      x11, 60(sp)
    sw      x12, 64(sp)
    sw      x13, 68(sp)
    sw      x14, 72(sp)
    sw      x15, 76(sp)
    sw      x16, 80(sp)
    sw      x17, 84(sp)
    sw      x18, 88(sp)
    sw      x19, 92(sp)
    sw      x20, 96(sp)
    sw      x21, 100(sp)
    sw      x22, 104(sp)
    sw      x23, 108(sp)
    sw      x24, 112(sp)
    sw      x25, 116(sp)
    sw      x26, 120(sp)
    sw      x27, 124(sp)
    sw      x28, 128(sp)
    sw      x29, 132(sp)
    sw      x30, 136(sp)
    sw      x31, 140(sp)
    addi    t0, sp, 144
    sw      t0,  24(sp)           /* original sp (x2) */
    csrr    t0, mepc
    sw      t0,  0(sp)
    csrr    t0, mcause
    sw      t0,  4(sp)
    csrr    t0, mtval
    sw      t0,  8(sp)
    csrr    t0, mstatus
    sw      t0,  12(sp)
    mv      a0, sp
    call    ks_trap_handler
    lw      t0,  0(sp)
    csrw    mepc, t0
    lw      t0,  12(sp)
    csrw    mstatus, t0
    lw      x1,  20(sp)
    lw      x3,  28(sp)
    lw      x4,  32(sp)
    lw      x5,  36(sp)
    lw      x6,  40(sp)
    lw      x7,  44(sp)
    lw      x8,  48(sp)
    lw      x9,  52(sp)
    lw      x10, 56(sp)
    lw      x11, 60(sp)
    lw      x12, 64(sp)
    lw      x13, 68(sp)
    lw      x14, 72(sp)
    lw      x15, 76(sp)
    lw      x16, 80(sp)
    lw      x17, 84(sp)
    lw      x18, 88(sp)
    lw      x19, 92(sp)
    lw      x20, 96(sp)
    lw      x21, 100(sp)
    lw      x22, 104(sp)
    lw      x23, 108(sp)
    lw      x24, 112(sp)
    lw      x25, 116(sp)
    lw      x26, 120(sp)
    lw      x27, 124(sp)
    lw      x28, 128(sp)
    lw      x29, 132(sp)
    lw      x30, 136(sp)
    lw      x31, 140(sp)
    addi    sp, sp, 144
    mret
