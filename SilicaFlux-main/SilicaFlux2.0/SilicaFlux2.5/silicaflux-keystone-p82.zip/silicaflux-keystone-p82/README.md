# SilicaFlux Albion — Project 82 · Keystone: embedded cloud control processor

**Primary RTL:** `rtl/albion/sf_keystone_control.sv` · Aureom.AI / SilicaFlux Albion · delivered as this archive — **nothing was committed to GitHub**.

Keystone boots the device, executes management firmware, configures cloud accelerators, runs a protected management command engine, takes
interrupts and exposes a safe host management interface. It is **not** a Linux application CPU: an RV32IM_Zicsr machine-mode controller
(the verified SilicaFlux `mcu_cpu`, reused unmodified), a boot ROM, ECC local SRAM, an MMIO bridge, timer, interrupt controller, watchdog,
command engine, RAS, telemetry and a host mailbox.

> **Status — read this first.** Everything below is **RTL simulation** (Verilator 5.020). No FPGA, synthesis, timing, area or silicon result exists.
> **Authenticated secure boot is NOT implemented** (CRC-32 integrity only; no security module is connected). RISC-V compliance is **not**
> claimed. Of the engines, only **CloudDMA (P64) is the real SilicaFlux RTL**; ComputeWorks and Virtual I/O are **behavioural models**; **PacketForge
> (P62) and MemoryPool (P65) are not integrated** (windows reserved, `PRESENT = 0`). Details: [docs/keystone/09_LIMITATIONS.md](docs/keystone/09_LIMITATIONS.md).

## Definition of done — met in RTL simulation

> *The RISC-V ControlCore executes compiled firmware in RTL simulation, configures at least one real SilicaFlux peripheral and receives its
> completion interrupt.*

The CPU boots from the ROM, loads and CRC-verifies the C management firmware, which discovers the engines, provisions a tenant, programs the
**real CloudDMA** (enable, permission table, descriptors in the shared SRAM), submits a copy through the protected command engine, and takes the
DMA **completion interrupt** (CloudDMA `done` → Keystone shell → INTC → CPU MEI → ISR → completion record). Data, CRC and the completion record are
checked bit-exact against an independent software reference — with both the GNU and the LLVM toolchain. See `reports/regression.md`.

## Quick start

```bash
sudo apt-get install -y verilator gcc-riscv64-unknown-elf clang lld llvm python3-yaml      # Verilator 5.020, GNU 13.2, LLVM 18
make check-regs                 # register map generator: 25 negative tests + generated files current
make regress                    # everything: lint, unit tests, both toolchains x 7 system scenarios  (~2.5 minutes)
make run                        # one boot + self-test on the RTL with the firmware console
make fw TOOLCHAIN=llvm          # cross-compile with LLVM instead of GNU
python3 scripts/mutate.py       # mutation check (17 deliberate RTL defects; ~25 minutes; edits RTL in place and restores it)
```

Firmware cross-compilation commands: [docs/keystone/06_FIRMWARE.md](docs/keystone/06_FIRMWARE.md).

## Layout

```
rtl/albion/              sf_keystone_control.sv (TOP) · _interrupts · _timer (+watchdog) · _bootrom (+generated image) · _sram · _shm · _sys · _mmio
                         _cmd · _ras · _tel · _host · _engshell · _dma_glue · _engmodel (MODEL) · _albion_sys (simulated system) · generated/
rtl/files.f files_sys.f lint.vlt     file lists and lint waivers
firmware/keystone/       boot ROM, startup, linker scripts, HAL, interrupt handlers, command submission, management routines, self-test
tests/keystone/          sim/ system testbench · unit/ SRAM-ECC, INTC (vs reference model), AXI buffer benches · run_regress.py
config/keystone_regs.yaml  the single source of truth for the memory / register map
scripts/                 gen_regs.py (generator + validator) · test_regmap.py · mkrom.py · mkimage.py · check_vendor.py · mutate.py · make_zip.py
third_party/             unmodified SilicaFlux sources (CPU, SECDED, CloudDMA) with SHA-256 + provenance (23/23 byte-identical to the repo archives)
docs/keystone/           00 audit … 09 limitations, HW_SW_INTERFACE, generated MEMORY_MAP / REGISTER_MAP, 10 results
reports/                 regression.md, mutation.md, logs/
```

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit, reuse of a verified CPU | `docs/keystone/00_AUDIT.md`, `third_party/PROVENANCE.md` |
| 2 | Exact ISA / traps / privilege; wrapper, ROM, SRAM, MMIO bridge, timer, INTC, watchdog, command engine | `02_CPU.md`, `01_ARCHITECTURE.md`, `rtl/albion/` |
| 3 | Boot flow with per-stage status / error; no pretended authentication | `03_BOOT.md`, `rom_main.c`, `sf_keystone_sys.sv` |
| 4 | Registers: identity, version, caps, DMA, PacketForge†, MemoryPool†, ComputeWorks, Virtual I/O, RAS, telemetry, reset / power; **shared generated map** | `config/keystone_regs.yaml` → SV package + C header + docs (†windows reserved, engines absent) |
| 5 | Protected command queue (accept, validate, dispatch, busy, completion, timeout, error; one at a time) | `sf_keystone_cmd.sv`, `05_COMMAND_ENGINE.md` |
| 6 | Interrupts: seven required sources + priorities + acknowledgement + simultaneous-event tests | `04_INTERRUPTS.md`, `tb_intc.sv`, `t_intc` / `t_simul` |
| 7 | C firmware: startup, linker, headers, ISRs, init, command submission, self-test, fault reporting, **actual cross-compile commands** | `firmware/keystone`, `06_FIRMWARE.md` |
| 8 | Management routines: queue creation, engine reset, tenant setup, discovery, recovery, snapshots, privilege checks | `app/mgmt.c`, `05_COMMAND_ENGINE.md` §5 |
| 9 | Verification: ROM, firmware execution, MMIO, invalid accesses, interrupt routing, watchdog, dispatch, reset, completion, error handling | `07_VERIFICATION.md`, `reports/regression.md` |
