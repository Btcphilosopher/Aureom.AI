// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_engmodel -- BEHAVIOURAL MODEL of a queue engine
//
//   *** THIS IS A SIMULATION MODEL, NOT A SILICAFLUX ENGINE. ***  It stands in for ComputeWorks and
//   Virtual I/O so the management path (queue creation, doorbell, completion interrupt, fault,
//   tenant ownership, engine reset, command timeout) can be exercised end to end.  It reports
//   ESH_CAPS.REAL = 0 and SYS.CAPS0.REAL_* = 0.  It does no compute and moves no data.
//
//   Queue ABI (dispatched by the command engine; tenant ownership is enforced here):
//     Q_CREATE  arg0 = queue id, arg1 = base, arg2 = depth (power of two), arg3 = flags
//     Q_DESTROY arg0 = queue id (refused while entries are pending)
//     Q_DOORBELL arg0 = queue id, arg1 = new tail (running index); work items are consumed one per
//                LAT clocks; when the queue drains one EVENT pulse (completion interrupt) is raised.
//   Failure codes (disp_code): 1 queue exists, 2 queue not valid, 3 queue busy, 4 tenant mismatch (also
//     raises VIOL), 5 tail beyond depth, 6 bad queue id.
//   Test controls (MODEL_CTRL): HANG_DONE accepts but never completes; HANG_ACCEPT never accepts; LAT.
//   Glue registers +0x100..0x120: config/keystone_regs.yaml (glue CPW / VIO).
//
// Classification: SIMULATION MODEL (synthesizable code, but not an engine)
// =============================================================================
`default_nettype none

module sf_keystone_engmodel
  import sf_keystone_regs_pkg::*;
#(
  parameter int NQ = 8
) (
  input  wire logic        clk,
  input  wire logic        rst_n,                 // eng_rst_n[ENG_IDX]
  // window (offsets >= 0x100)
  input  wire logic        eng_req,
  input  wire logic        eng_we,
  input  wire logic [15:0] eng_addr,
  input  wire logic [31:0] eng_wdata,
  output logic             eng_rvalid,
  output logic [31:0]      eng_rdata,
  output logic             eng_err,
  // dispatch
  input  wire logic        disp_valid,
  input  wire logic        disp_sel,
  input  wire logic [7:0]  disp_op,
  input  wire logic [2:0]  disp_tenant,
  input  wire logic [31:0] disp_arg0,
  input  wire logic [31:0] disp_arg1,
  input  wire logic [31:0] disp_arg2,
  output logic             disp_ready,
  output logic             disp_done,
  output logic             disp_err,
  output logic [7:0]       disp_code,
  output logic [31:0]      disp_res,
  // status / events
  output logic             evt,
  output logic             fault,
  output logic             viol,
  output logic [7:0]       fcode,
  output logic             busy
);
  logic        q_valid [NQ];
  logic [2:0]  q_ten   [NQ];
  logic [3:0]  q_dl2   [NQ];
  logic [31:0] q_base  [NQ];
  logic [15:0] q_head  [NQ], q_tail [NQ];
  logic [31:0] done_total_q;
  logic [2:0]  qsel_q;
  logic [7:0]  lat_q, lat_cnt_q;
  logic        hang_done_q, hang_acc_q;
  logic        drain_evt_pending_q [NQ];

  function automatic logic [3:0] log2f(input logic [31:0] v);
    log2f = 4'd0;
    for (int i = 0; i < 9; i++) if ((32'd1 << i) <= v) log2f = 4'(i);
  endfunction

  // ---------------------------------------------------------------- dispatch
  wire sel = disp_valid && disp_sel;
  assign disp_ready = sel && !hang_acc_q;
  logic [7:0]  d_code;
  logic        d_fail, d_viol;
  wire [2:0]   qid = disp_arg0[2:0];
  wire         qid_ok = (disp_arg0 < 32'(NQ));
  always_comb begin
    d_fail = 1'b0; d_code = 8'd0; d_viol = 1'b0;
    if (!qid_ok) begin d_fail = 1'b1; d_code = 8'd6; end
    else case (disp_op)
      8'(KS_OP_Q_CREATE):   if (q_valid[qid]) begin d_fail = 1'b1; d_code = 8'd1; end
      8'(KS_OP_Q_DESTROY):  if (!q_valid[qid]) begin d_fail = 1'b1; d_code = 8'd2; end
                            else if (q_head[qid] != q_tail[qid]) begin d_fail = 1'b1; d_code = 8'd3; end
      8'(KS_OP_Q_DOORBELL): if (!q_valid[qid]) begin d_fail = 1'b1; d_code = 8'd2; end
                            else if (q_ten[qid] != disp_tenant) begin d_fail = 1'b1; d_code = 8'd4; d_viol = 1'b1; end
                            else if (16'(disp_arg1 - 32'(q_head[qid])) > 16'(32'd1 << q_dl2[qid])) begin d_fail = 1'b1; d_code = 8'd5; end
      default: begin d_fail = 1'b1; d_code = 8'd7; end
    endcase
  end
  assign disp_done = disp_ready && !hang_done_q;
  assign disp_err  = disp_done && d_fail;
  assign disp_code = d_code;
  assign disp_res  = {29'd0, qid};

  // ---------------------------------------------------------------- window registers
  typedef enum logic [0:0] {W_IDLE, W_RSP} wst_t;
  wst_t        wst_q;
  logic [31:0] w_rdata_q;
  logic        w_err_q;
  assign eng_rvalid = (wst_q == W_RSP);
  assign eng_rdata  = w_rdata_q;
  assign eng_err    = w_err_q;

  logic [31:0] w_rd;
  logic        w_ok_rd, w_ok_wr;
  always_comb begin
    w_rd = 32'd0; w_ok_rd = 1'b1; w_ok_wr = 1'b0;
    case (eng_addr)
      KS_CPW_Q_SEL:    begin w_rd = {29'd0, qsel_q}; w_ok_wr = 1'b1; end
      KS_CPW_Q_STATE:  w_rd = {19'd0, (q_head[qsel_q] != q_tail[qsel_q]), q_dl2[qsel_q], 1'b0, q_ten[qsel_q], 3'd0, q_valid[qsel_q]};
      KS_CPW_Q_BASE:   w_rd = q_base[qsel_q];
      KS_CPW_Q_HEAD:   w_rd = {16'd0, q_head[qsel_q]};
      KS_CPW_Q_TAIL:   w_rd = {16'd0, q_tail[qsel_q]};
      KS_CPW_Q_DONE:   w_rd = done_total_q;
      KS_CPW_Q_COUNT:  begin w_rd = 32'd0; for (int i = 0; i < NQ; i++) w_rd = w_rd + 32'(q_valid[i]); end
      KS_CPW_MODEL_CTRL: begin w_rd = {16'd0, lat_q, 6'd0, hang_acc_q, hang_done_q}; w_ok_wr = 1'b1; end
      default: w_ok_rd = 1'b0;
    endcase
  end

  // ---------------------------------------------------------------- state
  logic any_pending;
  always_comb begin
    any_pending = 1'b0;
    for (int i = 0; i < NQ; i++) if (q_head[i] != q_tail[i]) any_pending = 1'b1;
  end
  assign busy = any_pending;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NQ; i++) begin
        q_valid[i] <= 1'b0; q_ten[i] <= '0; q_dl2[i] <= '0; q_base[i] <= '0; q_head[i] <= '0; q_tail[i] <= '0;
        drain_evt_pending_q[i] <= 1'b0;
      end
      done_total_q <= '0; qsel_q <= '0; lat_q <= 8'd4; lat_cnt_q <= '0; hang_done_q <= 1'b0; hang_acc_q <= 1'b0;
      wst_q <= W_IDLE; w_rdata_q <= '0; w_err_q <= 1'b0;
      evt <= 1'b0; fault <= 1'b0; viol <= 1'b0; fcode <= '0;
    end else begin
      evt <= 1'b0; fault <= 1'b0; viol <= 1'b0;

      // ---- command execution (on completion of the dispatch handshake)
      if (disp_done) begin
        if (d_fail) begin
          fault <= 1'b1; fcode <= d_code; viol <= d_viol;
        end else begin
          case (disp_op)
            8'(KS_OP_Q_CREATE): begin
              q_valid[qid] <= 1'b1; q_ten[qid] <= disp_tenant; q_dl2[qid] <= log2f(disp_arg2); q_base[qid] <= disp_arg1;
              q_head[qid] <= '0; q_tail[qid] <= '0;
            end
            8'(KS_OP_Q_DESTROY): q_valid[qid] <= 1'b0;
            8'(KS_OP_Q_DOORBELL): begin
              q_tail[qid] <= 16'(disp_arg1);
              if (16'(disp_arg1) != q_head[qid]) drain_evt_pending_q[qid] <= 1'b1;
              else evt <= 1'b1;                                   // nothing to do: completes immediately
            end
            default: ;
          endcase
        end
      end

      // ---- work: one entry per lat_q clocks across all queues (lowest queue first)
      if (any_pending) begin
        if (lat_cnt_q >= lat_q) begin
          lat_cnt_q <= '0;
          begin : pick
            logic done_one;
            done_one = 1'b0;
            for (int i = 0; i < NQ; i++) begin
              if (!done_one && q_head[i] != q_tail[i]) begin
                q_head[i] <= q_head[i] + 16'd1;
                done_total_q <= done_total_q + 32'd1;
                if (q_head[i] + 16'd1 == q_tail[i] && drain_evt_pending_q[i]) begin
                  drain_evt_pending_q[i] <= 1'b0; evt <= 1'b1;
                end
                done_one = 1'b1;
              end
            end
          end
        end else lat_cnt_q <= lat_cnt_q + 8'd1;
      end else lat_cnt_q <= '0;

      // ---- window
      case (wst_q)
        W_IDLE: if (eng_req) begin
          w_err_q   <= eng_we ? !w_ok_wr : !w_ok_rd;
          w_rdata_q <= (eng_we || !w_ok_rd) ? 32'd0 : w_rd;
          if (eng_we && w_ok_wr) begin
            if (eng_addr == KS_CPW_Q_SEL)      qsel_q <= eng_wdata[2:0];
            if (eng_addr == KS_CPW_MODEL_CTRL) begin hang_done_q <= eng_wdata[0]; hang_acc_q <= eng_wdata[1]; lat_q <= eng_wdata[15:8]; end
          end
          wst_q <= W_RSP;
        end
        W_RSP: wst_q <= W_IDLE;
        default: wst_q <= W_IDLE;
      endcase
    end
  end
  wire unused_ok = ^{eng_wdata[31:16], eng_wdata[7:2], disp_arg2[31:9]};
endmodule
`default_nettype wire
