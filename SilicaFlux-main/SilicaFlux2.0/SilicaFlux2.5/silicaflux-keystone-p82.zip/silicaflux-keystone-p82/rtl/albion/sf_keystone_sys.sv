// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_sys -- system block
//
//   Device identity, versions, capabilities, boot-stage status (hardware-enforced
//   order), reset network (power-on / warm / per-engine), power request / status,
//   security-violation status, invalid-access record, debug console, scratch.
//   Register layout: config/keystone_regs.yaml (block SYS).
//
//   Reset domains
//     por_rst_n   external power-on reset (asynchronous assert, synchronised release here)
//     core_rst_n  warm reset = POR | WDT bite | software request.  Resets CPU and every
//                 block except this block's always-on state (RESET_CAUSE, security record,
//                 scratch, power request, boot counter) and the SRAM contents.
//     eng_rst_n   per engine: warm reset | ENG_RESET command | RESET_CTRL.ENG_MASK
//
//   Boot-stage rule (BOOT_REPORT): stage n may start (RUNNING) only when stage n-1 is
//   OK and n is NOT_STARTED; OK or FAILED only from RUNNING.  Anything else is ignored
//   and flagged SEC.BOOT_SEQ.  READY=OK sets DEVICE_READY.  The first FAILED stage latches
//   BOOT_ERR and the FAULT flag.  This block does NOT authenticate firmware (see CAPS2).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_rstsync (
  input  wire logic clk,
  input  wire logic arst_n,           // asynchronous assert
  output logic      srst_n            // synchronous release
);
  logic s1, s2;
  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) begin s1 <= 1'b0; s2 <= 1'b0; end
    else         begin s1 <= 1'b1; s2 <= s1;   end
  end
  assign srst_n = s2;
endmodule

module sf_keystone_sys
  import sf_keystone_regs_pkg::*;
#(
  parameter logic [31:0]           ROM_VERSION = 32'h0100_0000,
  parameter logic [KS_NUM_ENG-1:0] ENG_PRESENT = '1,
  parameter logic [KS_NUM_ENG-1:0] ENG_REAL    = '0,
  parameter int                    NUM_TENANTS = 8,
  parameter int                    NUM_QUEUES  = 8,
  parameter int                    ROM_KIB     = 8,
  parameter int                    IRAM_KIB    = 32,
  parameter int                    DRAM_KIB    = 16,
  parameter int                    SHM_KIB     = 16,
  parameter int                    RST_HOLD    = 8
) (
  input  wire logic                   clk,
  input  wire logic                   por_rst_n_in,
  output logic                        por_rst_n,        // synchronised power-on reset
  output logic                        core_rst_n,       // warm reset (synchronised release)
  output logic [KS_NUM_ENG-1:0]       eng_rst_n,
  output logic [KS_NUM_ENG-1:0]       eng_in_reset,
  // register bus (access cycle strobe)
  input  wire logic                   rb_sel,
  input  wire logic                   rb_we,
  input  wire logic [11:0]            rb_off,
  input  wire logic [31:0]            rb_wdata,
  output logic [31:0]                 rb_rdata,
  // second, read-only, side-effect-free port (host view)
  input  wire logic [11:0]            ro_off,
  output logic [31:0]                 ro_rdata,
  // strap / status inputs
  input  wire logic [63:0]            chip_uid,
  input  wire logic                   iram_init_done,
  input  wire logic                   dram_init_done,
  input  wire logic                   cpu_sleeping,
  input  wire logic [KS_NUM_ENG-1:0]  eng_pwr_good,
  input  wire logic                   host_irq_lvl,
  // events
  input  wire logic [8:0]             sec_ev_in,        // KS_SEC_* pulses
  input  wire logic [7:0]             sec_info,
  input  wire logic                   bad_ev,
  input  wire logic [31:0]            bad_addr,
  input  wire logic                   bad_wr,
  input  wire logic [2:0]             bad_reason,
  input  wire logic                   wdt_rst_req,
  input  wire logic                   host_rst_req,
  input  wire logic [KS_NUM_ENG-1:0]  cmd_eng_rst,      // pulses from the command engine
  // outputs
  output logic                        sec_irq,
  output logic [8:0]                  sec_status_o,
  output logic [31:0]                 sec_count_o,
  output logic [KS_NUM_ENG-1:0]       pwr_en,
  output logic                        dev_ready,
  output logic                        console_valid,
  output logic [7:0]                  console_byte
);
  // ------------------------------------------------------------------ register write decode
  wire [15:0] off = {4'd0, rb_off};
  wire        wr  = rb_sel && rb_we;
  wire        wr_boot_report = wr && off == KS_SYS_BOOT_REPORT;
  wire        wr_reset_ctrl  = wr && off == KS_SYS_RESET_CTRL;

  // ------------------------------------------------------------------ reset network
  logic por_s_n;
  sf_keystone_rstsync u_por_sync (.clk, .arst_n(por_rst_n_in), .srst_n(por_s_n));
  assign por_rst_n = por_s_n;

  logic                      sw_rst_req;
  logic                      warm_active_q;
  logic [3:0]                warm_cnt_q;
  logic [KS_NUM_ENG-1:0]     eng_rst_req;
  logic [3:0]                eng_hold_q [KS_NUM_ENG];
  logic [KS_NUM_ENG-1:0]     reset_done_q;
  logic [3:0]                cause_q;
  logic [7:0]                boot_count_q;

  wire warm_req = wdt_rst_req | sw_rst_req | host_rst_req;

  always_ff @(posedge clk or negedge por_s_n) begin
    if (!por_s_n) begin
      warm_active_q <= 1'b0;
      warm_cnt_q    <= '0;
    end else if (warm_active_q) begin
      if (warm_cnt_q == 4'd0) warm_active_q <= 1'b0;
      else                    warm_cnt_q    <= warm_cnt_q - 1'b1;
    end else if (warm_req) begin
      warm_active_q <= 1'b1;
      warm_cnt_q    <= 4'(RST_HOLD);
    end
  end

  wire core_a_n = por_s_n & ~warm_active_q;
  sf_keystone_rstsync u_core_sync (.clk, .arst_n(core_a_n), .srst_n(core_rst_n));

  for (genvar e = 0; e < KS_NUM_ENG; e++) begin : g_eng_rst
    always_ff @(posedge clk or negedge por_s_n) begin
      if (!por_s_n) begin
        eng_hold_q[e]   <= '0;
        reset_done_q[e] <= 1'b0;
      end else begin
        if (eng_rst_req[e])           eng_hold_q[e] <= 4'(RST_HOLD);
        else if (eng_hold_q[e] != 0)  eng_hold_q[e] <= eng_hold_q[e] - 1'b1;
        // sticky "reset completed" (cleared by W1C below)
        if (eng_hold_q[e] == 4'd1 && !eng_rst_req[e]) reset_done_q[e] <= 1'b1;
        else if (rb_sel && rb_we && {4'd0, rb_off} == KS_SYS_RESET_DONE && rb_wdata[e]) reset_done_q[e] <= 1'b0;
      end
    end
    assign eng_in_reset[e] = (eng_hold_q[e] != 4'd0) || warm_active_q;
    assign eng_rst_n[e]    = por_s_n && !eng_in_reset[e];
  end

  // boot counter: counts releases of the warm reset (first POR release = 1)
  logic core_rst_prev_q;
  always_ff @(posedge clk or negedge por_s_n) begin
    if (!por_s_n) begin
      core_rst_prev_q <= 1'b0;
      boot_count_q    <= 8'd0;
    end else begin
      core_rst_prev_q <= core_rst_n;
      if (core_rst_n && !core_rst_prev_q && boot_count_q != 8'hFF) boot_count_q <= boot_count_q + 1'b1;
    end
  end

  // ------------------------------------------------------------------ always-on state (POR domain)
  logic [31:0] scratch_q [4];
  logic [4:0]  pwr_q;
  logic [8:0]  sec_status_q, sec_ie_q;
  logic [31:0] sec_count_q;
  logic [15:0] sec_last_q;
  logic [31:0] bad_addr_q;
  logic [23:0] bad_cnt_q;
  logic        bad_wr_q;
  logic [2:0]  bad_reason_q;
  logic        key_bad_ev, boot_seq_ev;

  wire [8:0] sec_ev = sec_ev_in
                    | (key_bad_ev  ? (9'd1 << KS_SEC_BAD_KEY)  : 9'd0)
                    | (boot_seq_ev ? (9'd1 << KS_SEC_BOOT_SEQ) : 9'd0);
  logic [7:0] sec_idx;
  always_comb begin
    sec_idx = 8'd0;
    for (int i = 8; i >= 0; i--) if (sec_ev[i]) sec_idx = 8'(i);
  end

  assign sw_rst_req  = wr_reset_ctrl && rb_wdata[31:16] == KS_KEY_RESET && rb_wdata[8];
  assign eng_rst_req = cmd_eng_rst | ((wr_reset_ctrl && rb_wdata[31:16] == KS_KEY_RESET) ? rb_wdata[KS_NUM_ENG-1:0] : '0);
  assign key_bad_ev  = wr_reset_ctrl && rb_wdata[31:16] != KS_KEY_RESET;

  always_ff @(posedge clk or negedge por_s_n) begin
    if (!por_s_n) begin
      cause_q       <= 4'b0001;                       // POR
      sec_status_q  <= '0;
      sec_ie_q      <= '0;
      sec_count_q   <= '0;
      sec_last_q    <= '0;
      pwr_q         <= '1;
      bad_addr_q    <= '0;
      bad_cnt_q     <= '0;
      bad_wr_q      <= 1'b0;
      bad_reason_q  <= '0;
      console_valid <= 1'b0;
      console_byte  <= '0;
      for (int i = 0; i < 4; i++) scratch_q[i] <= '0;
    end else begin
      // reset cause: set on request, clear by W1C
      if (wr && off == KS_SYS_RESET_CAUSE) cause_q <= cause_q & ~rb_wdata[3:0];
      if (!warm_active_q) begin
        if (wdt_rst_req)  cause_q[KS_RSTCAUSE_WDT]  <= 1'b1;
        if (sw_rst_req)   cause_q[KS_RSTCAUSE_SW]   <= 1'b1;
        if (host_rst_req) cause_q[KS_RSTCAUSE_HOST] <= 1'b1;
      end
      // security record
      sec_status_q <= (sec_status_q | sec_ev) & ~((wr && off == KS_SYS_SEC_STATUS) ? rb_wdata[8:0] : 9'd0);
      if (wr && off == KS_SYS_SEC_IE) sec_ie_q <= rb_wdata[8:0];
      if (|sec_ev) begin
        if (sec_count_q != 32'hFFFF_FFFF) sec_count_q <= sec_count_q + 1'b1;
        sec_last_q <= {sec_info, sec_idx};
      end
      // invalid access record
      if (bad_ev) begin
        bad_addr_q   <= bad_addr;
        bad_wr_q     <= bad_wr;
        bad_reason_q <= bad_reason;
        if (bad_cnt_q != 24'hFF_FFFF) bad_cnt_q <= bad_cnt_q + 1'b1;
      end
      // plain registers
      if (wr && off == KS_SYS_PWR_CTRL) pwr_q <= rb_wdata[4:0];
      if (wr) begin
        case (off)
          KS_SYS_SCRATCH0: scratch_q[0] <= rb_wdata;
          KS_SYS_SCRATCH1: scratch_q[1] <= rb_wdata;
          KS_SYS_SCRATCH2: scratch_q[2] <= rb_wdata;
          KS_SYS_SCRATCH3: scratch_q[3] <= rb_wdata;
          default: ;
        endcase
      end
      console_valid <= wr && off == KS_SYS_CONSOLE;
      if (wr && off == KS_SYS_CONSOLE) console_byte <= rb_wdata[7:0];
    end
  end

  // ------------------------------------------------------------------ boot status (warm domain)
  logic [7:0]  bst_q [8];
  logic [3:0]  cur_stage_q;
  logic        fault_q, ready_q, err_valid_q;
  logic [6:0]  err_code_q;
  logic [3:0]  err_stage_q;
  logic [31:0] fw_ver_q, fw_build_q;
  logic        fw_ver_set_q, fw_build_set_q;

  wire [3:0] rep_stage = rb_wdata[11:8];
  wire [7:0] rep_st    = rb_wdata[7:0];
  logic      rep_legal;
  always_comb begin
    rep_legal = 1'b0;
    if (rep_stage <= 4'(KS_STAGE_READY)) begin
      if (rep_st == 8'(KS_BSTAT_RUNNING))
        rep_legal = (bst_q[rep_stage[2:0]] == 8'(KS_BSTAT_NOT_STARTED)) && (rep_stage != 4'd0)
                    && (bst_q[3'(rep_stage - 4'd1)] == 8'(KS_BSTAT_OK));
      else if (rep_st == 8'(KS_BSTAT_OK))
        rep_legal = (bst_q[rep_stage[2:0]] == 8'(KS_BSTAT_RUNNING));
      else if (rep_st[7])
        rep_legal = (bst_q[rep_stage[2:0]] == 8'(KS_BSTAT_RUNNING));
    end
  end
  assign boot_seq_ev = wr_boot_report && !rep_legal;

  always_ff @(posedge clk or negedge core_rst_n) begin
    if (!core_rst_n) begin
      for (int i = 0; i < 8; i++) bst_q[i] <= 8'(KS_BSTAT_NOT_STARTED);
      bst_q[0]       <= 8'(KS_BSTAT_OK);              // RESET stage completed
      cur_stage_q    <= 4'(KS_STAGE_RESET);
      fault_q        <= 1'b0;
      ready_q        <= 1'b0;
      err_valid_q    <= 1'b0;
      err_code_q     <= '0;
      err_stage_q    <= '0;
      fw_ver_q       <= '0;
      fw_build_q     <= '0;
      fw_ver_set_q   <= 1'b0;
      fw_build_set_q <= 1'b0;
    end else begin
      if (wr_boot_report && rep_legal) begin
        bst_q[rep_stage[2:0]] <= rep_st;
        cur_stage_q <= rep_stage;
        if (rep_st[7]) begin
          fault_q <= 1'b1;
          if (!err_valid_q) begin
            err_valid_q <= 1'b1;
            err_code_q  <= rep_st[6:0];
            err_stage_q <= rep_stage;
          end
        end
        if (rep_stage == 4'(KS_STAGE_READY) && rep_st == 8'(KS_BSTAT_OK) && !fault_q) ready_q <= 1'b1;
      end
      if (wr && off == KS_SYS_FW_VERSION && !fw_ver_set_q)   begin fw_ver_q   <= rb_wdata; fw_ver_set_q   <= 1'b1; end
      if (wr && off == KS_SYS_FW_BUILD   && !fw_build_set_q) begin fw_build_q <= rb_wdata; fw_build_set_q <= 1'b1; end
    end
  end

  // ------------------------------------------------------------------ read mux
  wire [31:0] caps0 = {19'd0, ENG_REAL, 3'd0, ENG_PRESENT};
  wire [31:0] caps1 = {4'd0, 4'(KS_NUM_ENG), 8'(KS_NUM_IRQ), 8'(NUM_QUEUES), 8'(NUM_TENANTS)};
  wire [31:0] caps2 = 32'((1 << KS_SYS_CAPS2_ECC_SRAM_LSB) | (1 << KS_SYS_CAPS2_WDT_LSB) | (1 << KS_SYS_CAPS2_CMD_ENGINE_LSB)
                        | (1 << KS_SYS_CAPS2_HOST_MBX_LSB) | (1 << KS_SYS_CAPS2_PRIV_HW_CHECK_LSB) | (1 << KS_SYS_CAPS2_FW_CRC_LSB));
  wire [31:0] memc  = {8'(SHM_KIB), 8'(DRAM_KIB), 8'(IRAM_KIB), 8'(ROM_KIB)};
  wire [31:0] st_lo = {bst_q[3], bst_q[2], bst_q[1], bst_q[0]};
  wire [31:0] st_hi = {bst_q[7], bst_q[6], bst_q[5], bst_q[4]};
  wire        warm_pending = warm_active_q;
  wire [1:0]  pwr_state = (|eng_in_reset || warm_pending) ? 2'd2 : (cpu_sleeping ? 2'd1 : 2'd0);

  function automatic logic [31:0] rd(input logic [15:0] o);
    case (o)
      KS_SYS_DEV_ID:      rd = KS_SYS_DEV_ID_RST;
      KS_SYS_VENDOR_ID:   rd = KS_SYS_VENDOR_ID_RST;
      KS_SYS_HW_VERSION:  rd = KS_SYS_HW_VERSION_RST;
      KS_SYS_ROM_VERSION: rd = ROM_VERSION;
      KS_SYS_FW_VERSION:  rd = fw_ver_q;
      KS_SYS_FW_BUILD:    rd = fw_build_q;
      KS_SYS_CHIP_UID_LO: rd = chip_uid[31:0];
      KS_SYS_CHIP_UID_HI: rd = chip_uid[63:32];
      KS_SYS_CAPS0:       rd = caps0;
      KS_SYS_CAPS1:       rd = caps1;
      KS_SYS_CAPS2:       rd = caps2;
      KS_SYS_MEM_CAPS:    rd = memc;
      KS_SYS_BOOT_STAGE:  rd = {15'd0, fault_q, boot_count_q, 4'd0, cur_stage_q};
      KS_SYS_BOOT_ST_LO:  rd = st_lo;
      KS_SYS_BOOT_ST_HI:  rd = st_hi;
      KS_SYS_BOOT_ERR:    rd = {err_valid_q, 19'd0, err_stage_q, 1'b0, err_code_q};
      KS_SYS_SYS_STATUS:  rd = {25'd0, host_irq_lvl, fw_ver_set_q, cpu_sleeping, dram_init_done, iram_init_done, fault_q, ready_q};
      KS_SYS_RESET_CAUSE: rd = {28'd0, cause_q};
      KS_SYS_RESET_STATUS:rd = {23'd0, warm_pending, 3'd0, eng_in_reset};
      KS_SYS_RESET_DONE:  rd = {27'd0, reset_done_q};
      KS_SYS_PWR_CTRL:    rd = {27'd0, pwr_q};
      KS_SYS_PWR_STATUS:  rd = {18'd0, pwr_state, 3'd0, cpu_sleeping, 3'd0, eng_pwr_good};
      KS_SYS_SCRATCH0:    rd = scratch_q[0];
      KS_SYS_SCRATCH1:    rd = scratch_q[1];
      KS_SYS_SCRATCH2:    rd = scratch_q[2];
      KS_SYS_SCRATCH3:    rd = scratch_q[3];
      KS_SYS_BAD_ADDR:    rd = bad_addr_q;
      KS_SYS_BAD_INFO:    rd = {bad_cnt_q, 4'd0, bad_reason_q, bad_wr_q};
      KS_SYS_SEC_STATUS:  rd = {23'd0, sec_status_q};
      KS_SYS_SEC_IE:      rd = {23'd0, sec_ie_q};
      KS_SYS_SEC_COUNT:   rd = sec_count_q;
      KS_SYS_SEC_LAST:    rd = {16'd0, sec_last_q};
      default:            rd = 32'd0;
    endcase
  endfunction

  assign rb_rdata = rd({4'd0, rb_off});
  assign ro_rdata = rd({4'd0, ro_off});

  assign sec_irq      = |(sec_status_q & sec_ie_q);
  assign sec_status_o = sec_status_q;
  assign sec_count_o  = sec_count_q;
  assign pwr_en       = pwr_q;
  assign dev_ready    = ready_q;
endmodule
`default_nettype wire
