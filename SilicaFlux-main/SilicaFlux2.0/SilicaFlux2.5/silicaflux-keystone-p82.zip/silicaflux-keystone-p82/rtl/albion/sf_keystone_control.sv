// =============================================================================
// SilicaFlux Albion / Keystone (Project 82) :: sf_keystone_control -- TOP LEVEL
//
//   Embedded cloud control processor: boots the device, executes management firmware,
//   configures the cloud engines, runs a protected management command engine, takes
//   interrupts and exposes a safe host management interface.  NOT a Linux application CPU.
//
//   CPU      mcu_cpu (SilicaFlux MCU-I), RV32IM_Zicsr_Zifencei, machine mode only -- reused
//            UNMODIFIED from third_party/ (see docs/keystone/00_AUDIT.md, 02_CPU.md).
//   Memory   Boot ROM 8 KiB @0x0000_0000 (reset vector) | IRAM 32 KiB @0x0010_0000 (ECC) |
//            DRAM 16 KiB @0x0020_0000 (ECC) | SHM 16 KiB @0x0030_0000 | firmware store
//            window @0x1000_0000 (external, read only) | MMIO @0x4000_0000.
//   Clock/reset  one clock; rst_n = power-on reset.  Warm resets (watchdog bite, software)
//            are generated inside sf_keystone_sys.
//
//   Bus protocol on the CPU ports: OBI-style req/gnt with rvalid one or more cycles later
//   (see third_party/silicaflux-mcu-i).  Every target answers exactly one outstanding
//   access per port; the CPU is blocking.
//
//   NOT claimed: authenticated secure boot (no security module is connected; firmware
//   integrity is CRC32 only -- SYS.CAPS2.AUTH_BOOT = 0).
//
// Classification: SYNTHESIZABLE (retirement trace outputs are verification-only)
// =============================================================================
`default_nettype none

module sf_keystone_control
  import sf_keystone_regs_pkg::*;
#(
  parameter int                    CLK_HZ      = 100_000_000,
  parameter logic [31:0]           ROM_VERSION = 32'h0100_0000,
  parameter logic [KS_NUM_ENG-1:0] ENG_PRESENT = 5'b11001,   // DMA, CPW, VIO
  parameter logic [KS_NUM_ENG-1:0] ENG_REAL    = 5'b00001,   // DMA is the real CloudDMA
  parameter int                    ENG_TIMEOUT_CYC = 4096,
  parameter int                    AXI_ID_W    = 4
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,               // power-on reset
  input  wire logic [63:0]            chip_uid,
  // ---- firmware store (external boot flash window, read only)
  output logic                        fws_req,
  input  wire logic                   fws_gnt,
  output logic [31:0]                 fws_addr,
  input  wire logic                   fws_rvalid,
  input  wire logic [31:0]            fws_rdata,
  input  wire logic                   fws_err,
  // ---- debug console
  output logic                        console_valid,
  output logic [7:0]                  console_byte,
  // ---- host management port (safe interface; see sf_keystone_host)
  input  wire logic                   host_req,
  input  wire logic                   host_we,
  input  wire logic [15:0]            host_addr,
  input  wire logic [31:0]            host_wdata,
  input  wire logic [1:0]             host_priv,
  output logic                        host_rvalid,
  output logic [31:0]                 host_rdata,
  output logic                        host_err,
  output logic                        host_irq,
  // ---- shared buffer SRAM: AXI4 slave for the DMA engine's memory master
  input  wire logic                   s_ar_valid,
  output logic                        s_ar_ready,
  input  wire logic [AXI_ID_W-1:0]    s_ar_id,
  input  wire logic [31:0]            s_ar_addr,
  input  wire logic [7:0]             s_ar_len,
  input  wire logic [2:0]             s_ar_size,
  input  wire logic [1:0]             s_ar_burst,
  output logic                        s_r_valid,
  input  wire logic                   s_r_ready,
  output logic [AXI_ID_W-1:0]         s_r_id,
  output logic [63:0]                 s_r_data,
  output logic [1:0]                  s_r_resp,
  output logic                        s_r_last,
  input  wire logic                   s_aw_valid,
  output logic                        s_aw_ready,
  input  wire logic [AXI_ID_W-1:0]    s_aw_id,
  input  wire logic [31:0]            s_aw_addr,
  input  wire logic [7:0]             s_aw_len,
  input  wire logic [2:0]             s_aw_size,
  input  wire logic [1:0]             s_aw_burst,
  input  wire logic                   s_w_valid,
  output logic                        s_w_ready,
  input  wire logic [63:0]            s_w_data,
  input  wire logic [7:0]             s_w_strb,
  input  wire logic                   s_w_last,
  output logic                        s_b_valid,
  input  wire logic                   s_b_ready,
  output logic [AXI_ID_W-1:0]         s_b_id,
  output logic [1:0]                  s_b_resp,
  // ---- engine register windows (offsets >= 0x100 of each 64 KiB window)
  output logic [KS_NUM_ENG-1:0]       eng_req,
  output logic                        eng_we,
  output logic [15:0]                 eng_addr,
  output logic [31:0]                 eng_wdata,
  input  wire logic [KS_NUM_ENG-1:0]  eng_rvalid,
  input  wire logic [KS_NUM_ENG*32-1:0] eng_rdata,
  input  wire logic [KS_NUM_ENG-1:0]  eng_err,
  // ---- engine status / events (pulses unless noted)
  input  wire logic [KS_NUM_ENG-1:0]  eng_evt,
  input  wire logic [KS_NUM_ENG-1:0]  eng_fault,
  input  wire logic [KS_NUM_ENG-1:0]  eng_viol,
  input  wire logic [KS_NUM_ENG*8-1:0] eng_fcode,
  input  wire logic [KS_NUM_ENG-1:0]  eng_busy,             // level
  input  wire logic [KS_NUM_ENG-1:0]  eng_pwr_good,         // level
  input  wire logic                   ext_ras_valid,        // external RAS event (MemoryPool)
  input  wire logic [31:0]            ext_ras_addr,
  // ---- engine controls
  output logic [KS_NUM_ENG-1:0]       eng_rst_n,
  output logic [KS_NUM_ENG-1:0]       eng_en,
  output logic [KS_NUM_ENG-1:0]       eng_pwr_en,
  // ---- management command dispatch (one command at a time)
  output logic                        disp_valid,
  output logic [KS_NUM_ENG-1:0]       disp_sel,
  output logic [7:0]                  disp_op,
  output logic [2:0]                  disp_tenant,
  output logic [3:0]                  disp_domain,
  output logic [31:0]                 disp_arg0,
  output logic [31:0]                 disp_arg1,
  output logic [31:0]                 disp_arg2,
  output logic [31:0]                 disp_arg3,
  input  wire logic [KS_NUM_ENG-1:0]  disp_ready,
  input  wire logic [KS_NUM_ENG-1:0]  disp_done,
  input  wire logic [KS_NUM_ENG-1:0]  disp_err,
  input  wire logic [KS_NUM_ENG*8-1:0] disp_code,
  input  wire logic [KS_NUM_ENG*32-1:0] disp_res,
  // ---- status
  output logic                        core_rst_n_o,
  output logic                        cpu_sleeping,
  // ---- verification-only retirement trace
  output logic                        dbg_rt_valid,
  output logic [31:0]                 dbg_rt_pc,
  output logic                        dbg_rt_trap,
  output logic [31:0]                 dbg_rt_cause
);
  // ------------------------------------------------------------------ resets
  logic por_rst_n, core_rst_n;
  logic [KS_NUM_ENG-1:0] eng_in_reset;
  assign core_rst_n_o = core_rst_n;

  // ------------------------------------------------------------------ CPU
  logic        i_req, i_gnt, i_rvalid, i_err;
  logic [31:0] i_addr, i_rdata;
  logic        d_req, d_gnt, d_we, d_rvalid, d_err;
  logic [3:0]  d_be;
  logic [31:0] d_addr, d_wdata, d_rdata;
  logic        irq_ext, irq_timer, irq_soft, bus_idle;

  mcu_cpu #(
    .BOOT_ADDR(32'h0000_0000), .RV32E(1'b0), .RV32M(1), .HART_ID(32'h0), .MIMPID(32'h0082_0001)
  ) u_cpu (
    .clk, .rst_n(core_rst_n),
    .i_req, .i_gnt, .i_addr, .i_rvalid, .i_rdata, .i_err,
    .d_req, .d_gnt, .d_addr, .d_we, .d_be, .d_wdata, .d_rvalid, .d_rdata, .d_err,
    .irq_ext, .irq_timer, .irq_soft,
    .sleeping(cpu_sleeping), .bus_idle,
    .rt_valid(dbg_rt_valid), .rt_pc(dbg_rt_pc), .rt_insn(), .rt_trap(dbg_rt_trap), .rt_cause(dbg_rt_cause),
    .rt_rd(), .rt_rd_wdata(), .rt_rd_we()
  );
  wire unused_cpu = bus_idle;

  // ------------------------------------------------------------------ address decode helpers
  function automatic logic in_reg(input logic [31:0] a, input logic [31:0] base, input logic [31:0] size);
    in_reg = ((a & ~(size - 32'd1)) == base);
  endfunction

  // ------------------------------------------------------------------ instruction side
  typedef enum logic [1:0] {I_ROM, I_IRAM, I_ERR} itgt_t;
  itgt_t i_sel;
  always_comb begin
    if      (in_reg(i_addr, KS_BROM_BASE, KS_BROM_SIZE)) i_sel = I_ROM;
    else if (in_reg(i_addr, KS_IRAM_BASE, KS_IRAM_SIZE)) i_sel = I_IRAM;
    else                                                 i_sel = I_ERR;
  end

  logic        rom_a_gnt, rom_a_rv, rom_a_err; logic [31:0] rom_a_rd;
  logic        iram_a_gnt, iram_a_rv, iram_a_err; logic [31:0] iram_a_rd;
  logic        ierr_rv_q;

  assign i_gnt = (i_sel == I_ROM) ? rom_a_gnt : (i_sel == I_IRAM) ? iram_a_gnt : 1'b1;
  always_ff @(posedge clk or negedge core_rst_n) begin
    if (!core_rst_n) ierr_rv_q <= 1'b0;
    else             ierr_rv_q <= i_req && (i_sel == I_ERR);
  end
  assign i_rvalid = rom_a_rv | iram_a_rv | ierr_rv_q;
  assign i_rdata  = ({32{rom_a_rv}} & rom_a_rd) | ({32{iram_a_rv}} & iram_a_rd);
  assign i_err    = (rom_a_rv & rom_a_err) | (iram_a_rv & iram_a_err) | ierr_rv_q;

  // ------------------------------------------------------------------ data side
  typedef enum logic [2:0] {D_ROM, D_IRAM, D_DRAM, D_SHM, D_FWST, D_MMIO, D_ERR} dtgt_t;
  dtgt_t d_sel;
  always_comb begin
    if      (in_reg(d_addr, KS_BROM_BASE, KS_BROM_SIZE)) d_sel = D_ROM;
    else if (in_reg(d_addr, KS_IRAM_BASE, KS_IRAM_SIZE)) d_sel = D_IRAM;
    else if (in_reg(d_addr, KS_DRAM_BASE, KS_DRAM_SIZE)) d_sel = D_DRAM;
    else if (in_reg(d_addr, KS_SHM_BASE,  KS_SHM_SIZE))  d_sel = D_SHM;
    else if (in_reg(d_addr, KS_FWST_BASE, KS_FWST_SIZE)) begin if (d_we) d_sel = D_ERR; else d_sel = D_FWST; end   // read only
    else if (in_reg(d_addr, KS_MMIO_BASE, KS_MMIO_SIZE)) d_sel = D_MMIO;
    else                                                 d_sel = D_ERR;
  end

  logic        rom_b_gnt, rom_b_rv, rom_b_err; logic [31:0] rom_b_rd;
  logic        iram_b_gnt, iram_b_rv, iram_b_err; logic [31:0] iram_b_rd;
  logic        dram_b_gnt, dram_b_rv, dram_b_err; logic [31:0] dram_b_rd;
  logic        shm_gnt, shm_rv, shm_err; logic [31:0] shm_rd;
  logic        mmio_gnt, mmio_rv, mmio_err; logic [31:0] mmio_rd;
  logic        derr_rv_q;

  // firmware-store window (external)
  assign fws_req  = d_req && (d_sel == D_FWST);
  assign fws_addr = d_addr;

  always_comb begin
    case (d_sel)
      D_ROM:   d_gnt = rom_b_gnt;
      D_IRAM:  d_gnt = iram_b_gnt;
      D_DRAM:  d_gnt = dram_b_gnt;
      D_SHM:   d_gnt = shm_gnt;
      D_FWST:  d_gnt = fws_gnt;
      D_MMIO:  d_gnt = mmio_gnt;
      default: d_gnt = 1'b1;
    endcase
  end

  logic [31:0] d_addr_q;
  logic        d_we_q;
  always_ff @(posedge clk or negedge core_rst_n) begin
    if (!core_rst_n) begin
      derr_rv_q <= 1'b0; d_addr_q <= '0; d_we_q <= 1'b0;
    end else begin
      derr_rv_q <= d_req && d_gnt && (d_sel == D_ERR);
      if (d_req && d_gnt) begin d_addr_q <= d_addr; d_we_q <= d_we; end
    end
  end

  assign d_rvalid = rom_b_rv | iram_b_rv | dram_b_rv | shm_rv | fws_rvalid | mmio_rv | derr_rv_q;
  assign d_rdata  = ({32{rom_b_rv}}  & rom_b_rd)  | ({32{iram_b_rv}} & iram_b_rd) | ({32{dram_b_rv}} & dram_b_rd)
                  | ({32{shm_rv}}    & shm_rd)    | ({32{fws_rvalid}} & fws_rdata) | ({32{mmio_rv}} & mmio_rd);
  assign d_err    = (rom_b_rv & rom_b_err) | (iram_b_rv & iram_b_err) | (dram_b_rv & dram_b_err) | (shm_rv & shm_err)
                  | (fws_rvalid & fws_err) | (mmio_rv & mmio_err) | derr_rv_q;

  // reason for fabric-detected (non-MMIO) data errors
  logic        fab_bad_ev;
  logic [2:0]  fab_bad_reason;
  always_comb begin
    fab_bad_ev     = 1'b0;
    fab_bad_reason = '0;
    if (derr_rv_q) begin
      fab_bad_ev = 1'b1;
      fab_bad_reason = (d_addr_q >= KS_FWST_BASE && d_addr_q < KS_FWST_BASE + KS_FWST_SIZE) ? 3'(KS_BADACC_RO_WRITE) : 3'(KS_BADACC_DECODE);
    end else if (rom_b_rv && rom_b_err) begin
      fab_bad_ev = 1'b1; fab_bad_reason = d_we_q ? 3'(KS_BADACC_RO_WRITE) : 3'(KS_BADACC_DECODE);
    end else if ((iram_b_rv && iram_b_err) || (dram_b_rv && dram_b_err)) begin
      fab_bad_ev = 1'b1; fab_bad_reason = 3'(KS_BADACC_ECC_UE);
    end else if (fws_rvalid && fws_err) begin
      fab_bad_ev = 1'b1; fab_bad_reason = 3'(KS_BADACC_DECODE);
    end
  end

  // ------------------------------------------------------------------ memories
  logic iram_init_done, dram_init_done;
  logic        mem_ev_valid [2], mem_ev_ce [2], mem_ev_ue [2], mem_ev_iport [2];
  logic [31:0] mem_ev_addr  [2];
  logic [1:0]  mem_ev_lane  [2];
  logic [4:0]  mem_ev_synd  [2];
  logic        inj_arm, inj_fired_i, inj_fired_d;
  logic [31:0] inj_addr;
  logic [1:0]  inj_lane;
  logic [12:0] inj_mask;

  sf_keystone_bootrom #(.WORDS(KS_BROM_SIZE / 4)) u_rom (
    .clk, .rst_n(core_rst_n),
    .a_req(i_req && i_sel == I_ROM), .a_gnt(rom_a_gnt), .a_addr(i_addr), .a_rvalid(rom_a_rv), .a_rdata(rom_a_rd), .a_err(rom_a_err),
    .b_req(d_req && d_sel == D_ROM), .b_gnt(rom_b_gnt), .b_we(d_we), .b_addr(d_addr), .b_rvalid(rom_b_rv), .b_rdata(rom_b_rd), .b_err(rom_b_err)
  );

  sf_keystone_sram #(.DEPTH(KS_IRAM_SIZE / 4)) u_iram (
    .clk, .por_rst_n, .rst_n(core_rst_n),
    .a_req(i_req && i_sel == I_IRAM), .a_gnt(iram_a_gnt), .a_addr(i_addr), .a_rvalid(iram_a_rv), .a_rdata(iram_a_rd), .a_err(iram_a_err),
    .b_req(d_req && d_sel == D_IRAM), .b_gnt(iram_b_gnt), .b_we(d_we), .b_be(d_be), .b_addr(d_addr), .b_wdata(d_wdata),
    .b_rvalid(iram_b_rv), .b_rdata(iram_b_rd), .b_err(iram_b_err),
    .init_done(iram_init_done),
    .ev_valid(mem_ev_valid[0]), .ev_ce(mem_ev_ce[0]), .ev_ue(mem_ev_ue[0]), .ev_iport(mem_ev_iport[0]),
    .ev_addr(mem_ev_addr[0]), .ev_lane(mem_ev_lane[0]), .ev_synd(mem_ev_synd[0]),
    .inj_arm, .inj_addr, .inj_lane, .inj_mask, .inj_fired(inj_fired_i)
  );

  sf_keystone_sram #(.DEPTH(KS_DRAM_SIZE / 4)) u_dram (
    .clk, .por_rst_n, .rst_n(core_rst_n),
    .a_req(1'b0), .a_gnt(), .a_addr(32'd0), .a_rvalid(), .a_rdata(), .a_err(),
    .b_req(d_req && d_sel == D_DRAM), .b_gnt(dram_b_gnt), .b_we(d_we), .b_be(d_be), .b_addr(d_addr), .b_wdata(d_wdata),
    .b_rvalid(dram_b_rv), .b_rdata(dram_b_rd), .b_err(dram_b_err),
    .init_done(dram_init_done),
    .ev_valid(mem_ev_valid[1]), .ev_ce(mem_ev_ce[1]), .ev_ue(mem_ev_ue[1]), .ev_iport(mem_ev_iport[1]),
    .ev_addr(mem_ev_addr[1]), .ev_lane(mem_ev_lane[1]), .ev_synd(mem_ev_synd[1]),
    .inj_arm, .inj_addr, .inj_lane, .inj_mask, .inj_fired(inj_fired_d)
  );

  logic shm_axi_err;
  sf_keystone_shm #(.DEPTH64(KS_SHM_SIZE / 8), .ID_W(AXI_ID_W), .BASE(KS_SHM_BASE)) u_shm (
    .clk, .rst_n(core_rst_n),
    .c_req(d_req && d_sel == D_SHM), .c_gnt(shm_gnt), .c_we(d_we), .c_be(d_be), .c_addr(d_addr), .c_wdata(d_wdata),
    .c_rvalid(shm_rv), .c_rdata(shm_rd), .c_err(shm_err),
    .s_ar_valid, .s_ar_ready, .s_ar_id, .s_ar_addr, .s_ar_len, .s_ar_size, .s_ar_burst,
    .s_r_valid, .s_r_ready, .s_r_id, .s_r_data, .s_r_resp, .s_r_last,
    .s_aw_valid, .s_aw_ready, .s_aw_id, .s_aw_addr, .s_aw_len, .s_aw_size, .s_aw_burst,
    .s_w_valid, .s_w_ready, .s_w_data, .s_w_strb, .s_w_last,
    .s_b_valid, .s_b_ready, .s_b_id, .s_b_resp,
    .axi_err_ev(shm_axi_err)
  );

  // ------------------------------------------------------------------ MMIO bridge
  logic [12:0]  rb_sel;
  logic         rb_we;
  logic [11:0]  rb_off;
  logic [31:0]  rb_wdata;
  logic [13*32-1:0] rb_rdata;
  logic         mmio_bad_ev, mmio_bad_wr, mmio_rd_pulse, mmio_wr_pulse;
  logic [31:0]  mmio_bad_addr;
  logic [2:0]   mmio_bad_reason;

  sf_keystone_mmio #(.ENG_TIMEOUT_CYC(ENG_TIMEOUT_CYC)) u_mmio (
    .clk, .rst_n(core_rst_n),
    .req(d_req && d_sel == D_MMIO), .gnt(mmio_gnt), .we(d_we), .be(d_be), .addr(d_addr), .wdata(d_wdata),
    .rvalid(mmio_rv), .rdata(mmio_rd), .err(mmio_err),
    .rb_sel, .rb_we, .rb_off, .rb_wdata, .rb_rdata,
    .eng_present(ENG_PRESENT), .eng_req, .eng_we, .eng_addr, .eng_wdata, .eng_rvalid, .eng_rdata, .eng_err,
    .bad_ev(mmio_bad_ev), .bad_addr(mmio_bad_addr), .bad_wr(mmio_bad_wr), .bad_reason(mmio_bad_reason),
    .rd_pulse(mmio_rd_pulse), .wr_pulse(mmio_wr_pulse)
  );

  // invalid-access record: fabric errors or bridge rejections
  wire        bad_ev     = fab_bad_ev | mmio_bad_ev;
  wire [31:0] bad_addr   = fab_bad_ev ? d_addr_q : mmio_bad_addr;
  wire        bad_wr     = fab_bad_ev ? d_we_q   : mmio_bad_wr;
  wire [2:0]  bad_reason = fab_bad_ev ? fab_bad_reason : mmio_bad_reason;
  wire        mmio_eng_to_ev = mmio_bad_ev && mmio_bad_reason == 3'(KS_BADACC_ENG_TIMEOUT);
  wire        ibus_err_ev = i_rvalid && i_err;

  // ------------------------------------------------------------------ engine shells
  logic [KS_NUM_ENG-1:0] sh_irq, sh_evt, sh_flt, sh_viol;
  logic [KS_NUM_ENG-1:0] cmd_eng_en;
  for (genvar e = 0; e < KS_NUM_ENG; e++) begin : g_esh
    sf_keystone_engshell #(.ID(ks_eng_id(e)), .PRESENT(ENG_PRESENT[e]), .IS_REAL(ENG_REAL[e]), .PASSTHRU(1'b1)) u_sh (
      .clk, .rst_n(core_rst_n),
      .rb_sel(rb_sel[8+e]), .rb_we, .rb_off(rb_off[7:0]), .rb_wdata, .rb_rdata(rb_rdata[(8+e)*32 +: 32]),
      .evt(eng_evt[e]), .fault(eng_fault[e]), .viol(eng_viol[e]), .fcode(eng_fcode[e*8 +: 8]),
      .busy(eng_busy[e]), .enabled(cmd_eng_en[e]), .in_reset(eng_in_reset[e]), .pwr_good(eng_pwr_good[e]),
      .irq(sh_irq[e]), .evt_ev(sh_evt[e]), .fault_ev(sh_flt[e]), .viol_ev(sh_viol[e])
    );
  end
  assign eng_en = cmd_eng_en;

  // ------------------------------------------------------------------ SYS
  logic [31:0] sys_rdata, sys_ro_rdata;
  logic [11:0] sys_ro_off;
  logic        sec_irq, wdt_rst_req, host_rst_req;
  logic [KS_NUM_ENG-1:0] cmd_eng_rst;
  logic [8:0]  cmd_sec_ev, host_sec_ev, sec_ev_all;
  logic [7:0]  cmd_sec_info, host_sec_info;
  logic        wdt_key_bad;
  logic        sys_dev_ready;
  wire         dev_ready = sys_dev_ready;

  always_comb begin
    sec_ev_all = cmd_sec_ev | host_sec_ev;
    for (int e = 0; e < KS_NUM_ENG; e++)
      if (sh_viol[e]) sec_ev_all[(e == KS_ENG_DMA) ? KS_SEC_DMA_VIOL : KS_SEC_ENG_VIOL] = 1'b1;
    if (wdt_key_bad) sec_ev_all[KS_SEC_WDT_KEY] = 1'b1;
  end

  sf_keystone_sys #(.ROM_VERSION(ROM_VERSION), .ENG_PRESENT(ENG_PRESENT), .ENG_REAL(ENG_REAL)) u_sys (
    .clk, .por_rst_n_in(rst_n), .por_rst_n, .core_rst_n, .eng_rst_n, .eng_in_reset,
    .rb_sel(rb_sel[0]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(sys_rdata),
    .ro_off(sys_ro_off), .ro_rdata(sys_ro_rdata),
    .chip_uid, .iram_init_done, .dram_init_done, .cpu_sleeping, .eng_pwr_good, .host_irq_lvl(host_irq),
    .sec_ev_in(sec_ev_all), .sec_info(cmd_sec_info | host_sec_info),
    .bad_ev, .bad_addr, .bad_wr, .bad_reason,
    .wdt_rst_req, .host_rst_req, .cmd_eng_rst,
    .sec_irq, .sec_status_o(), .sec_count_o(), .pwr_en(eng_pwr_en),
    .console_valid, .console_byte, .dev_ready(sys_dev_ready)
  );
  assign rb_rdata[0*32 +: 32] = sys_rdata;

  // ------------------------------------------------------------------ timer, interrupts, watchdog
  logic [KS_NUM_IRQ:0] irq_src, irq_claim;
  logic wdt_irq, ras_irq, cmd_irq, mbx_irq;

  sf_keystone_timer #(.CLK_HZ(CLK_HZ)) u_timer (
    .clk, .rst_n(core_rst_n), .rb_sel(rb_sel[1]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(rb_rdata[1*32 +: 32]),
    .irq_timer, .irq_soft
  );

  always_comb begin
    irq_src = '0;
    irq_src[KS_IRQ_WDT]  = wdt_irq;
    irq_src[KS_IRQ_SEC]  = sec_irq;
    irq_src[KS_IRQ_RAS]  = ras_irq;
    irq_src[KS_IRQ_CMD]  = cmd_irq;
    irq_src[KS_IRQ_HOST] = mbx_irq;
    irq_src[KS_IRQ_DMA]  = sh_irq[KS_ENG_DMA];
    irq_src[KS_IRQ_CPW]  = sh_irq[KS_ENG_CPW];
    irq_src[KS_IRQ_VIO]  = sh_irq[KS_ENG_VIO];
    irq_src[KS_IRQ_PKT]  = sh_irq[KS_ENG_PKT];
    irq_src[KS_IRQ_MPL]  = sh_irq[KS_ENG_MPL];
  end

  sf_keystone_interrupts u_intc (
    .clk, .rst_n(core_rst_n), .rb_sel(rb_sel[2]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(rb_rdata[2*32 +: 32]),
    .src(irq_src), .irq_out(irq_ext), .claim_ev(irq_claim)
  );

  logic wdt_kick_ev;
  sf_keystone_wdt u_wdt (
    .clk, .rst_n(core_rst_n), .rb_sel(rb_sel[3]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(rb_rdata[3*32 +: 32]),
    .irq(wdt_irq), .rst_req(wdt_rst_req), .kick_ev(wdt_kick_ev), .key_bad_ev(wdt_key_bad)
  );

  // ------------------------------------------------------------------ management command engine
  logic cmd_tel_snap, cmd_acc_ev, cmd_err_ev, cmd_timeout_ev;
  sf_keystone_cmd u_cmd (
    .clk, .rst_n(core_rst_n), .rb_sel(rb_sel[4]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(rb_rdata[4*32 +: 32]),
    .eng_present(ENG_PRESENT), .eng_in_reset, .eng_en(cmd_eng_en), .eng_rst_req(cmd_eng_rst),
    .disp_valid, .disp_sel, .disp_op, .disp_tenant, .disp_domain, .disp_arg0, .disp_arg1, .disp_arg2, .disp_arg3,
    .disp_ready, .disp_done, .disp_err, .disp_code, .disp_res,
    .tel_snap(cmd_tel_snap), .cmd_irq, .sec_ev(cmd_sec_ev), .sec_info(cmd_sec_info),
    .acc_ev(cmd_acc_ev), .err_ev(cmd_err_ev), .timeout_ev(cmd_timeout_ev)
  );

  // ------------------------------------------------------------------ RAS and telemetry
  logic ras_ce_ev, ras_ue_ev;
  logic [31:0] cycle_lo;
  sf_keystone_ras u_ras (
    .clk, .rst_n(por_rst_n), .rb_sel(rb_sel[5]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(rb_rdata[5*32 +: 32]),
    .mem_ev_valid({mem_ev_valid[1], mem_ev_valid[0]}), .mem_ev_ce({mem_ev_ce[1], mem_ev_ce[0]}),
    .mem_ev_ue({mem_ev_ue[1], mem_ev_ue[0]}), .mem_ev_iport({mem_ev_iport[1], mem_ev_iport[0]}),
    .mem_ev_addr({mem_ev_addr[1], mem_ev_addr[0]}), .mem_ev_lane({mem_ev_lane[1], mem_ev_lane[0]}),
    .mem_ev_synd({mem_ev_synd[1], mem_ev_synd[0]}),
    .bus_err_ev(bad_ev), .bus_err_addr(bad_addr), .ibus_err_ev,
    .eng_fault_ev(|sh_flt | shm_axi_err), .eng_timeout_ev(cmd_timeout_ev | mmio_eng_to_ev),
    .ext_ev_valid(ext_ras_valid), .ext_ev_addr(ext_ras_addr), .cycle_lo,
    .inj_arm, .inj_addr, .inj_lane, .inj_mask, .inj_fired(inj_fired_i | inj_fired_d),
    .irq(ras_irq), .ce_ev(ras_ce_ev), .ue_ev(ras_ue_ev)
  );

  sf_keystone_tel u_tel (
    .clk, .rst_n(core_rst_n), .rb_sel(rb_sel[6]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(rb_rdata[6*32 +: 32]),
    .snap_cmd(cmd_tel_snap),
    .instret(dbg_rt_valid), .sleeping(cpu_sleeping), .mmio_rd(mmio_rd_pulse), .mmio_wr(mmio_wr_pulse), .bus_err(bad_ev),
    .exc(dbg_rt_trap && !dbg_rt_cause[31]), .intr(dbg_rt_trap && dbg_rt_cause[31]),
    .cmd_acc(cmd_acc_ev), .cmd_err(cmd_err_ev), .eng_evt(sh_evt), .eng_flt(sh_flt), .irq_claim,
    .ras_ce(ras_ce_ev), .ras_ue(ras_ue_ev), .wdt_kick(wdt_kick_ev), .sec_viol(|sec_ev_all), .cycle_lo
  );

  // ------------------------------------------------------------------ host mailbox / management port
  sf_keystone_host u_host (
    .clk, .rst_n(core_rst_n), .rb_sel(rb_sel[7]), .rb_we, .rb_off, .rb_wdata, .rb_rdata(rb_rdata[7*32 +: 32]),
    .req_irq(mbx_irq),
    .host_req, .host_we, .host_addr, .host_wdata, .host_priv, .host_rvalid, .host_rdata, .host_err, .host_irq,
    .sys_ro_off, .sys_ro_rdata, .dev_ready, .sec_ev(host_sec_ev), .sec_info(host_sec_info), .host_rst_req
  );

  wire unused_ok = ^{bus_idle, shm_axi_err, rb_sel[12:8] == 5'd0 && 1'b0};
endmodule
`default_nettype wire
