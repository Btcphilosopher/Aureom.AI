// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_host -- host management port and mailbox
//
//   The SAFE management interface towards the host / BMC / PCIe function.  The host has NO access
//   to memories or engines: it can only
//     * read identity, version, capabilities, boot status, reset cause, power status (side-effect free),
//     * exchange a request / response through an 8-word mailbox,
//     * request a warm reset (privilege >= OPERATOR and key).
//   The host path asserts its privilege on host_priv (KS_PRIV_*; set by the platform from the PCIe
//   function / authentication, outside this block).  Hardware captures host_priv at the DOORBELL into
//   MBX.STATUS.REQ_PRIV; firmware passes it on to the command engine.
//
//   Protocol:  host writes MBX_IN[0..7] -> DOORBELL -> (firmware: INTC.HOST, reads MBX.IN, executes,
//              writes MBX.OUT, MBX.CTRL.COMPLETE) -> RSP_VALID / host_irq -> host reads MBX_OUT -> ACK.
//   Refusals (bus error, no state change):  privilege too low for the register (SEC.HOST_PRIV), writing
//   MBX_IN / DOORBELL while a request is pending (SEC.MBX_WRITE), DOORBELL while the device is not ready.
//
//   Host port timing: request strobe with host_req for ONE cycle; response (host_rvalid, host_rdata,
//   host_err) exactly one cycle later.
//
//   Register layouts: config/keystone_regs.yaml (block MBX = CPU side, "host" = host side).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_host
  import sf_keystone_regs_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,               // warm reset (mailbox state is cleared by a warm reset)
  // CPU side (MBX block)
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_off,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             req_irq,             // level -> INTC.HOST
  // host side
  input  wire logic        host_req,
  input  wire logic        host_we,
  input  wire logic [15:0] host_addr,
  input  wire logic [31:0] host_wdata,
  input  wire logic [1:0]  host_priv,
  output logic             host_rvalid,
  output logic [31:0]      host_rdata,
  output logic             host_err,
  output logic             host_irq,
  // SYS read-only view
  output logic [11:0]      sys_ro_off,
  input  wire logic [31:0] sys_ro_rdata,
  input  wire logic        dev_ready,
  // events
  output logic [8:0]       sec_ev,
  output logic [7:0]       sec_info,
  output logic             host_rst_req
);
  logic [31:0] in_q [8], out_q [8];
  logic        pend_q, rspv_q, cpu_ie_q;
  logic [1:0]  rpriv_q;
  logic [7:0]  seq_q;
  logic [1:0]  hie_q;

  // ---------------------------------------------------------------- CPU side
  wire [15:0] off = {4'd0, rb_off};
  wire        wr  = rb_sel && rb_we;
  wire        cpu_complete = wr && off == KS_MBX_CTRL && rb_wdata[KS_MBX_CTRL_COMPLETE_LSB] && pend_q;

  // ---------------------------------------------------------------- host side decode (combinational, request cycle)
  logic [1:0]  h_acc;
  logic        h_priv_ok, h_ok;
  logic [11:0] h_sys_off;
  logic        h_is_in, h_is_out, h_is_ctrl, h_is_rst;
  logic        h_busy_refuse, h_notready_refuse;
  always_comb begin
    h_acc = ks_acc_host(host_addr);
    h_is_in   = (host_addr <= KS_H_MBX_IN_7) && (host_addr >= KS_H_MBX_IN_0);
    h_is_out  = (host_addr >= KS_H_MBX_OUT_0) && (host_addr <= KS_H_MBX_OUT_7);
    h_is_ctrl = (host_addr == KS_H_MBX_CTRL);
    h_is_rst  = (host_addr == KS_H_RESET_REQ);
    // privilege needed: mailbox data / control / irq enable: TENANT; reset request: OPERATOR; status reads: any
    h_priv_ok = 1'b1;
    if ((h_is_in || h_is_out || h_is_ctrl || host_addr == KS_H_IRQ_EN) && host_priv < 2'(KS_PRIV_TENANT)) h_priv_ok = 1'b0;
    if (h_is_rst && host_priv < 2'(KS_PRIV_OPERATOR)) h_priv_ok = 1'b0;
    h_busy_refuse = host_we && ((h_is_in && pend_q) || (h_is_ctrl && host_wdata[KS_H_MBX_CTRL_DOORBELL_LSB] && pend_q));
    h_notready_refuse = host_we && h_is_ctrl && host_wdata[KS_H_MBX_CTRL_DOORBELL_LSB] && !pend_q && !dev_ready;
    h_ok = (h_acc != KS_ACC_NONE) && !(host_we && h_acc == KS_ACC_RO) && h_priv_ok && !h_busy_refuse && !h_notready_refuse;
    // SYS view offsets
    case (host_addr)
      KS_H_DEV_ID:      h_sys_off = 12'(KS_SYS_DEV_ID);
      KS_H_VENDOR_ID:   h_sys_off = 12'(KS_SYS_VENDOR_ID);
      KS_H_HW_VERSION:  h_sys_off = 12'(KS_SYS_HW_VERSION);
      KS_H_FW_VERSION:  h_sys_off = 12'(KS_SYS_FW_VERSION);
      KS_H_CAPS0:       h_sys_off = 12'(KS_SYS_CAPS0);
      KS_H_CAPS1:       h_sys_off = 12'(KS_SYS_CAPS1);
      KS_H_CAPS2:       h_sys_off = 12'(KS_SYS_CAPS2);
      KS_H_MEM_CAPS:    h_sys_off = 12'(KS_SYS_MEM_CAPS);
      KS_H_BOOT_STAGE:  h_sys_off = 12'(KS_SYS_BOOT_STAGE);
      KS_H_BOOT_ST_LO:  h_sys_off = 12'(KS_SYS_BOOT_ST_LO);
      KS_H_BOOT_ST_HI:  h_sys_off = 12'(KS_SYS_BOOT_ST_HI);
      KS_H_BOOT_ERR:    h_sys_off = 12'(KS_SYS_BOOT_ERR);
      KS_H_SYS_STATUS:  h_sys_off = 12'(KS_SYS_SYS_STATUS);
      KS_H_RESET_CAUSE: h_sys_off = 12'(KS_SYS_RESET_CAUSE);
      KS_H_PWR_STATUS:  h_sys_off = 12'(KS_SYS_PWR_STATUS);
      KS_H_SEC_COUNT:   h_sys_off = 12'(KS_SYS_SEC_COUNT);
      default:          h_sys_off = 12'hFFF;
    endcase
  end
  assign sys_ro_off = h_sys_off;

  logic [31:0] h_rd;
  always_comb begin
    h_rd = 32'd0;
    if (h_sys_off != 12'hFFF) h_rd = sys_ro_rdata;
    else if (host_addr == KS_H_MBX_STATUS) h_rd = {16'd0, seq_q, 1'b0, 1'b0, rpriv_q, 1'b0, dev_ready, rspv_q, pend_q};
    else if (host_addr == KS_H_IRQ_EN)     h_rd = {30'd0, hie_q};
    else if (h_is_out) h_rd = out_q[host_addr[4:2]];
    else if (h_is_in)  h_rd = in_q[host_addr[4:2]];
  end

  // ---------------------------------------------------------------- sequential
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < 8; i++) begin in_q[i] <= '0; out_q[i] <= '0; end
      pend_q <= 1'b0; rspv_q <= 1'b0; cpu_ie_q <= 1'b0; rpriv_q <= '0; seq_q <= '0; hie_q <= '0;
      host_rvalid <= 1'b0; host_rdata <= '0; host_err <= 1'b0; sec_ev <= '0; sec_info <= '0; host_rst_req <= 1'b0;
    end else begin
      host_rvalid <= 1'b0; host_err <= 1'b0; host_rdata <= '0; sec_ev <= '0; host_rst_req <= 1'b0;

      // ---- CPU side
      if (wr && off == KS_MBX_IRQ_EN) cpu_ie_q <= rb_wdata[0];
      if (wr) begin
        for (int i = 0; i < 8; i++) if (off == KS_MBX_OUT_0 + 16'(4 * i)) out_q[i] <= rb_wdata;
      end
      if (cpu_complete) begin pend_q <= 1'b0; rspv_q <= 1'b1; end

      // ---- host side
      if (host_req) begin
        host_rvalid <= 1'b1;
        if (h_ok) begin
          host_rdata <= host_we ? 32'd0 : h_rd;
          if (host_we) begin
            if (h_is_in) in_q[host_addr[4:2]] <= host_wdata;
            if (host_addr == KS_H_IRQ_EN) hie_q <= host_wdata[1:0];
            if (h_is_ctrl) begin
              if (host_wdata[KS_H_MBX_CTRL_DOORBELL_LSB]) begin pend_q <= 1'b1; rspv_q <= 1'b0; rpriv_q <= host_priv; seq_q <= seq_q + 1'b1; end
              if (host_wdata[KS_H_MBX_CTRL_ACK_LSB]) rspv_q <= 1'b0;
            end
            if (h_is_rst) begin
              if (host_wdata[31:16] == KS_KEY_RESET) host_rst_req <= 1'b1;
              else begin sec_ev[KS_SEC_BAD_KEY] <= 1'b1; sec_info <= 8'h80; host_err <= 1'b1; host_rdata <= '0; end
            end
          end
        end else begin
          host_err <= 1'b1;
          if (!h_priv_ok && h_acc != KS_ACC_NONE) begin sec_ev[KS_SEC_HOST_PRIV] <= 1'b1; sec_info <= {6'd0, host_priv}; end
          else if (h_busy_refuse)                 begin sec_ev[KS_SEC_MBX_WRITE] <= 1'b1; sec_info <= 8'h40; end
        end
      end
    end
  end

  assign rb_rdata = (off == KS_MBX_STATUS) ? {16'd0, seq_q, 2'd0, rpriv_q, 2'd0, rspv_q, pend_q}
                  : (off == KS_MBX_IRQ_EN) ? {31'd0, cpu_ie_q}
                  : (off <= KS_MBX_IN_7)  ? in_q[rb_off[4:2]]
                  : (off >= KS_MBX_OUT_0 && off <= KS_MBX_OUT_7) ? out_q[rb_off[4:2]]
                  : 32'd0;
  assign req_irq  = cpu_ie_q && pend_q;
  assign host_irq = (hie_q[0] && rspv_q) || (hie_q[1] && dev_ready);
endmodule
`default_nettype wire
