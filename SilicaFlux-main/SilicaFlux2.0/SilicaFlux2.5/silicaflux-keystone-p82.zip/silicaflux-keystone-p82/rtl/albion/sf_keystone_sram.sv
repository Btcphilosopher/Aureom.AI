// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_sram -- ECC-protected local SRAM
//
//   * 32-bit words, stored as four independent byte lanes, each an extended-Hamming
//     SECDED (13,8) codeword (reused SilicaFlux RAS P26 codec sfras_secded_*, unmodified).
//     Per-lane coding means a byte / halfword store never needs a read-modify-write.
//   * Single memory port, two requesters: port A (read only, instruction fetch) and
//     port B (read / write, data).  Port B has priority; port A is granted when B is idle.
//   * Responses: exactly one cycle after the grant (rvalid, rdata, err).  Single-bit
//     errors are corrected on the way out (the stored word is NOT rewritten: software
//     scrubs by rewriting the word); an uncorrectable lane returns err = 1.
//   * Hardware initialisation sweep after power-on reset (all words = valid zero
//     codewords).  No grant is given until init_done = 1.  A warm reset does not
//     re-initialise (contents are retained) but does drop in-flight responses.
//   * ev_* : one RAS event pulse per access that saw a corrected / uncorrectable lane.
//   * inj_* : fault injection.  While inj_arm is held, the first write that covers
//     byte lane inj_lane of word inj_addr has inj_mask XORed into that lane's stored
//     13 bits (one bit -> correctable, two bits -> uncorrectable).  inj_fired pulses.
//
// Classification: SYNTHESIZABLE (memory array infers a single-port RAM per lane)
// =============================================================================
`default_nettype none

module sf_keystone_sram #(
  parameter int DEPTH = 8192                 // words
) (
  input  wire logic        clk,
  input  wire logic        por_rst_n,        // power-on reset: memory initialisation FSM
  input  wire logic        rst_n,            // warm reset: port response state
  // port A: instruction (read only)
  input  wire logic        a_req,
  output logic             a_gnt,
  input  wire logic [31:0] a_addr,
  output logic             a_rvalid,
  output logic [31:0]      a_rdata,
  output logic             a_err,
  // port B: data
  input  wire logic        b_req,
  output logic             b_gnt,
  input  wire logic        b_we,
  input  wire logic [3:0]  b_be,
  input  wire logic [31:0] b_addr,
  input  wire logic [31:0] b_wdata,
  output logic             b_rvalid,
  output logic [31:0]      b_rdata,
  output logic             b_err,
  // status
  output logic             init_done,
  // RAS events (one pulse per access with an ECC finding)
  output logic             ev_valid,
  output logic             ev_ce,
  output logic             ev_ue,
  output logic             ev_iport,
  output logic [31:0]      ev_addr,
  output logic [1:0]       ev_lane,
  output logic [4:0]       ev_synd,
  // fault injection
  input  wire logic        inj_arm,
  input  wire logic [31:0] inj_addr,
  input  wire logic [1:0]  inj_lane,
  input  wire logic [12:0] inj_mask,
  output logic             inj_fired
);
  localparam int AWD = $clog2(DEPTH);
  localparam int CW  = 13;                    // stored bits per byte lane

  if (DEPTH < 4 || (DEPTH & (DEPTH - 1)) != 0) begin : g_bad_depth
    $error("sf_keystone_sram: DEPTH must be a power of two >= 4");
  end

  // ------------------------------------------------------------- initialisation sweep
  logic [AWD:0] init_ctr_q;
  always_ff @(posedge clk or negedge por_rst_n) begin
    if (!por_rst_n) begin
      init_ctr_q <= '0;
      init_done  <= 1'b0;
    end else if (!init_done) begin
      if (init_ctr_q == (AWD+1)'(DEPTH - 1)) init_done <= 1'b1;
      init_ctr_q <= init_ctr_q + 1'b1;
    end
  end

  // ------------------------------------------------------------- arbitration
  assign b_gnt = init_done && b_req;
  assign a_gnt = init_done && a_req && !b_req;

  wire unused_ok = ^{inj_addr[1:0]};
  wire [AWD-1:0] b_idx = b_addr[AWD+1:2];
  wire [AWD-1:0] a_idx = a_addr[AWD+1:2];
  wire [AWD-1:0] r_idx = b_gnt ? b_idx : a_idx;
  wire           wr_en = b_gnt && b_we;
  wire           rd_en = (b_gnt && !b_we) || a_gnt;

  // ------------------------------------------------------------- encoders (write path)
  logic [CW-1:0] enc_cw [4];
  for (genvar l = 0; l < 4; l++) begin : g_enc
    sfras_secded_enc #(.K(8), .INV(0)) u_enc (.data_i(b_wdata[8*l +: 8]), .cw_o(enc_cw[l]));
  end

  // injection hit
  wire inj_hit = inj_arm && wr_en && (b_addr[31:2] == inj_addr[31:2]) && b_be[inj_lane];

  // ------------------------------------------------------------- storage
  logic [CW-1:0] mem [4][DEPTH];
  logic [CW-1:0] rd_cw_q [4];

  always_ff @(posedge clk) begin
    for (int l = 0; l < 4; l++) begin
      if (!init_done) begin
        mem[l][init_ctr_q[AWD-1:0]] <= '0;                       // valid zero codeword
      end else if (wr_en && b_be[l]) begin
        mem[l][b_idx] <= enc_cw[l] ^ ((inj_hit && inj_lane == 2'(l)) ? inj_mask : '0);
      end
      if (rd_en) rd_cw_q[l] <= mem[l][r_idx];
    end
  end

  // ------------------------------------------------------------- response bookkeeping
  logic        ra_q, rb_rd_q, rb_wr_q;
  logic [31:0] raddr_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ra_q      <= 1'b0;
      rb_rd_q   <= 1'b0;
      rb_wr_q   <= 1'b0;
      raddr_q   <= '0;
      inj_fired <= 1'b0;
    end else begin
      ra_q      <= a_gnt;
      rb_rd_q   <= b_gnt && !b_we;
      rb_wr_q   <= b_gnt && b_we;
      raddr_q   <= b_gnt ? b_addr : a_addr;
      inj_fired <= inj_hit;
    end
  end

  // ------------------------------------------------------------- decoders (read path)
  logic [7:0]    dec_data [4];
  logic [3:0]    dec_ce, dec_ue;
  logic [4:0]    dec_syn [4];
  for (genvar l = 0; l < 4; l++) begin : g_dec
    /* verilator lint_off UNUSEDSIGNAL */
    logic [CW-1:0] cw_corr;
    logic          none, inval, cdata;
    logic [3:0]    eidx;
    /* verilator lint_on UNUSEDSIGNAL */
    sfras_secded_dec #(.K(8), .INV(0)) u_dec (
      .cw_i(rd_cw_q[l]), .data_o(dec_data[l]), .cw_corr_o(cw_corr),
      .none_o(none), .ce_o(dec_ce[l]), .ue_o(dec_ue[l]), .ue_inval_o(inval),
      .ce_data_o(cdata), .err_idx_o(eidx), .syn_o(dec_syn[l]));
  end

  wire [31:0] rword = {dec_data[3], dec_data[2], dec_data[1], dec_data[0]};
  wire        any_ue = |dec_ue;
  wire        any_ce = |dec_ce;

  assign a_rvalid = ra_q;
  assign a_rdata  = ra_q ? rword : 32'd0;
  assign a_err    = ra_q && any_ue;
  assign b_rvalid = rb_rd_q | rb_wr_q;
  assign b_rdata  = rb_rd_q ? rword : 32'd0;
  assign b_err    = rb_rd_q && any_ue;

  // ------------------------------------------------------------- RAS event
  wire rd_resp = ra_q | rb_rd_q;
  assign ev_valid = rd_resp && (any_ue || any_ce);
  assign ev_ue    = any_ue;
  assign ev_ce    = any_ce && !any_ue;
  assign ev_iport = ra_q;
  assign ev_addr  = raddr_q;
  always_comb begin
    logic [3:0] flagged;
    flagged = any_ue ? dec_ue : dec_ce;
    ev_lane = 2'd0;
    ev_synd = dec_syn[0];
    if (flagged[0])      begin ev_lane = 2'd0; ev_synd = dec_syn[0]; end
    else if (flagged[1]) begin ev_lane = 2'd1; ev_synd = dec_syn[1]; end
    else if (flagged[2]) begin ev_lane = 2'd2; ev_synd = dec_syn[2]; end
    else if (flagged[3]) begin ev_lane = 2'd3; ev_synd = dec_syn[3]; end
  end
endmodule
`default_nettype wire
