// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_engshell -- common engine shell
//
//   One per engine window (+0x000..0x0FF).  Gives every engine the same management view:
//   identity, presence / implementation level (REAL RTL vs behavioural MODEL), status,
//   sticky EVENT / FAULT / VIOL interrupt causes with enables, event and fault counters,
//   last fault code, and a software IRQ-inject test aid.
//   The engine's own registers live behind the shell (glue @+0x100, page @+0x1000) and
//   are reached through the engine port of sf_keystone_control.
//   Register layout: config/keystone_regs.yaml (engine_shell).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_engshell
  import sf_keystone_regs_pkg::*;
#(
  parameter logic [31:0] ID       = 32'h0,
  parameter bit          PRESENT  = 1'b1,
  parameter bit          IS_REAL  = 1'b0,
  parameter bit          PASSTHRU = 1'b1
) (
  input  wire logic        clk,
  input  wire logic        rst_n,              // warm reset
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [7:0]  rb_off,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  // engine-side inputs
  input  wire logic        evt,                // completion / event pulse
  input  wire logic        fault,              // fault pulse
  input  wire logic        viol,               // isolation / security violation pulse
  input  wire logic [7:0]  fcode,              // fault code (valid with fault)
  input  wire logic        busy,
  input  wire logic        enabled,            // from the command engine (ENG_ENABLE)
  input  wire logic        in_reset,
  input  wire logic        pwr_good,
  // outputs
  output logic             irq,                // level to the interrupt controller
  output logic             evt_ev,             // filtered pulses (for telemetry / RAS)
  output logic             fault_ev,
  output logic             viol_ev
);
  logic [2:0]  stat_q, ien_q;
  logic [31:0] evt_cnt_q, flt_cnt_q;
  logic [7:0]  code_q;

  wire [15:0] off = {8'd0, rb_off};
  wire        wr  = rb_sel && rb_we;

  wire unused_ok = ^{rb_wdata[31:3]};
  assign evt_ev   = PRESENT && evt;
  assign fault_ev = PRESENT && fault;
  assign viol_ev  = PRESENT && viol;

  wire [2:0] set_bits = {viol_ev, fault_ev, evt_ev} | ((wr && off == KS_ESH_IRQ_SET) ? rb_wdata[2:0] : 3'd0);
  wire [2:0] clr_bits = (wr && off == KS_ESH_IRQ_STAT) ? rb_wdata[2:0] : 3'd0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      stat_q <= '0; ien_q <= '0; evt_cnt_q <= '0; flt_cnt_q <= '0; code_q <= '0;
    end else begin
      stat_q <= (stat_q | set_bits) & ~(clr_bits & ~set_bits);
      if (wr && off == KS_ESH_IRQ_EN) ien_q <= rb_wdata[2:0];
      if (evt_ev   && evt_cnt_q != 32'hFFFF_FFFF) evt_cnt_q <= evt_cnt_q + 1'b1;
      if (fault_ev) begin
        if (flt_cnt_q != 32'hFFFF_FFFF) flt_cnt_q <= flt_cnt_q + 1'b1;
        code_q <= fcode;
      end
    end
  end

  assign irq = |(stat_q & ien_q);

  always_comb begin
    case (off)
      KS_ESH_ID:        rb_rdata = ID;
      KS_ESH_VERSION:   rb_rdata = KS_ESH_VERSION_RST;
      KS_ESH_CAPS:      rb_rdata = {29'd0, PASSTHRU, IS_REAL, PRESENT};
      KS_ESH_STATUS:    rb_rdata = {27'd0, stat_q[1], pwr_good, in_reset, busy, enabled};
      KS_ESH_IRQ_STAT:  rb_rdata = {29'd0, stat_q};
      KS_ESH_IRQ_EN:    rb_rdata = {29'd0, ien_q};
      KS_ESH_EVT_COUNT: rb_rdata = evt_cnt_q;
      KS_ESH_FLT_COUNT: rb_rdata = flt_cnt_q;
      KS_ESH_ERR_CODE:  rb_rdata = {24'd0, code_q};
      default:          rb_rdata = 32'd0;
    endcase
  end
endmodule
`default_nettype wire
