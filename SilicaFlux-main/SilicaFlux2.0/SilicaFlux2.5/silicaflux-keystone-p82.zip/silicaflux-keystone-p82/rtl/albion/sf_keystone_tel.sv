// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_tel -- telemetry / performance counters
//
//   Free-running live counters (cycles, retired instructions, sleep cycles, MMIO reads / writes,
//   bus errors, exceptions, interrupts, commands, per-engine events / faults, per-source
//   interrupt claims, ECC events, watchdog kicks, security violations).
//   SNAP (register TEL.CTRL or the PERF_SNAP management command) captures ALL counters in the same
//   cycle into read-only shadow registers, so software reads a consistent set.  CLEAR zeroes the
//   live counters.  Register layout: config/keystone_regs.yaml (block TEL).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_tel
  import sf_keystone_regs_pkg::*;
(
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  input  wire logic                   rb_sel,
  input  wire logic                   rb_we,
  input  wire logic [11:0]            rb_off,
  input  wire logic [31:0]            rb_wdata,
  output logic [31:0]                 rb_rdata,
  input  wire logic                   snap_cmd,              // PERF_SNAP command
  // counted events (pulses / levels)
  input  wire logic                   instret,
  input  wire logic                   sleeping,
  input  wire logic                   mmio_rd,
  input  wire logic                   mmio_wr,
  input  wire logic                   bus_err,
  input  wire logic                   exc,
  input  wire logic                   intr,
  input  wire logic                   cmd_acc,
  input  wire logic                   cmd_err,
  input  wire logic [KS_NUM_ENG-1:0]  eng_evt,
  input  wire logic [KS_NUM_ENG-1:0]  eng_flt,
  input  wire logic [KS_NUM_IRQ:0]    irq_claim,
  input  wire logic                   ras_ce,
  input  wire logic                   ras_ue,
  input  wire logic                   wdt_kick,
  input  wire logic                   sec_viol,
  output logic [31:0]                 cycle_lo
);
  localparam int NIRQ = KS_NUM_IRQ;
  localparam int NENG = KS_NUM_ENG;

  logic [63:0] cyc_q, ret_q;
  logic [31:0] sleep_q, rd_q, wr_q, berr_q, exc_q, intr_q, cacc_q, cerr_q, rce_q, rue_q, kick_q, sec_q;
  logic [31:0] evt_q [NENG], flt_q [NENG], irq_q [NIRQ+1];

  logic [63:0] s_cyc, s_ret;
  logic [31:0] s_sleep, s_rd, s_wr, s_berr, s_exc, s_intr, s_cacc, s_cerr, s_rce, s_rue, s_kick, s_sec;
  logic [31:0] s_evt [NENG], s_flt [NENG], s_irq [NIRQ+1];
  logic [31:0] seq_q;
  logic        snapped_q;

  wire [15:0] off = {4'd0, rb_off};
  wire        wr  = rb_sel && rb_we;
  wire        snap  = (wr && off == KS_TEL_CTRL && rb_wdata[0]) || snap_cmd;
  wire        clear = (wr && off == KS_TEL_CTRL && rb_wdata[1]);

  assign cycle_lo = cyc_q[31:0];
  wire unused_ok = ^{rb_wdata[31:2]};

  function automatic logic [31:0] inc(input logic [31:0] v, input logic en);
    inc = (en && v != 32'hFFFF_FFFF) ? v + 32'd1 : v;
  endfunction

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      cyc_q <= '0; ret_q <= '0; sleep_q <= '0; rd_q <= '0; wr_q <= '0; berr_q <= '0; exc_q <= '0; intr_q <= '0;
      cacc_q <= '0; cerr_q <= '0; rce_q <= '0; rue_q <= '0; kick_q <= '0; sec_q <= '0;
      for (int i = 0; i < NENG; i++) begin evt_q[i] <= '0; flt_q[i] <= '0; end
      for (int i = 0; i <= NIRQ; i++) irq_q[i] <= '0;
      s_cyc <= '0; s_ret <= '0; s_sleep <= '0; s_rd <= '0; s_wr <= '0; s_berr <= '0; s_exc <= '0; s_intr <= '0;
      s_cacc <= '0; s_cerr <= '0; s_rce <= '0; s_rue <= '0; s_kick <= '0; s_sec <= '0;
      for (int i = 0; i < NENG; i++) begin s_evt[i] <= '0; s_flt[i] <= '0; end
      for (int i = 0; i <= NIRQ; i++) s_irq[i] <= '0;
      seq_q <= '0; snapped_q <= 1'b0;
    end else begin
      if (clear) begin
        cyc_q <= '0; ret_q <= '0; sleep_q <= '0; rd_q <= '0; wr_q <= '0; berr_q <= '0; exc_q <= '0; intr_q <= '0;
        cacc_q <= '0; cerr_q <= '0; rce_q <= '0; rue_q <= '0; kick_q <= '0; sec_q <= '0;
        for (int i = 0; i < NENG; i++) begin evt_q[i] <= '0; flt_q[i] <= '0; end
        for (int i = 0; i <= NIRQ; i++) irq_q[i] <= '0;
      end else begin
        cyc_q   <= cyc_q + 64'd1;
        ret_q   <= ret_q + {63'd0, instret};
        sleep_q <= inc(sleep_q, sleeping);
        rd_q    <= inc(rd_q, mmio_rd);
        wr_q    <= inc(wr_q, mmio_wr);
        berr_q  <= inc(berr_q, bus_err);
        exc_q   <= inc(exc_q, exc);
        intr_q  <= inc(intr_q, intr);
        cacc_q  <= inc(cacc_q, cmd_acc);
        cerr_q  <= inc(cerr_q, cmd_err);
        rce_q   <= inc(rce_q, ras_ce);
        rue_q   <= inc(rue_q, ras_ue);
        kick_q  <= inc(kick_q, wdt_kick);
        sec_q   <= inc(sec_q, sec_viol);
        for (int i = 0; i < NENG; i++) begin evt_q[i] <= inc(evt_q[i], eng_evt[i]); flt_q[i] <= inc(flt_q[i], eng_flt[i]); end
        for (int i = 1; i <= NIRQ; i++) irq_q[i] <= inc(irq_q[i], irq_claim[i]);
      end
      if (snap) begin
        s_cyc <= cyc_q; s_ret <= ret_q; s_sleep <= sleep_q; s_rd <= rd_q; s_wr <= wr_q; s_berr <= berr_q;
        s_exc <= exc_q; s_intr <= intr_q; s_cacc <= cacc_q; s_cerr <= cerr_q; s_rce <= rce_q; s_rue <= rue_q;
        s_kick <= kick_q; s_sec <= sec_q;
        for (int i = 0; i < NENG; i++) begin s_evt[i] <= evt_q[i]; s_flt[i] <= flt_q[i]; end
        for (int i = 0; i <= NIRQ; i++) s_irq[i] <= irq_q[i];
        seq_q <= seq_q + 1'b1; snapped_q <= 1'b1;
      end
    end
  end

  always_comb begin
    rb_rdata = 32'd0;
    case (off)
      KS_TEL_SEQ:        rb_rdata = seq_q;
      KS_TEL_STATUS:     rb_rdata = {31'd0, snapped_q};
      KS_TEL_CYCLES_LO:  rb_rdata = s_cyc[31:0];
      KS_TEL_CYCLES_HI:  rb_rdata = s_cyc[63:32];
      KS_TEL_INSTRET_LO: rb_rdata = s_ret[31:0];
      KS_TEL_INSTRET_HI: rb_rdata = s_ret[63:32];
      KS_TEL_SLEEP:      rb_rdata = s_sleep;
      KS_TEL_MMIO_RD:    rb_rdata = s_rd;
      KS_TEL_MMIO_WR:    rb_rdata = s_wr;
      KS_TEL_BUS_ERR:    rb_rdata = s_berr;
      KS_TEL_EXC:        rb_rdata = s_exc;
      KS_TEL_INTR:       rb_rdata = s_intr;
      KS_TEL_CMD_ACC:    rb_rdata = s_cacc;
      KS_TEL_CMD_ERR:    rb_rdata = s_cerr;
      KS_TEL_RAS_CE:     rb_rdata = s_rce;
      KS_TEL_RAS_UE:     rb_rdata = s_rue;
      KS_TEL_WDT_KICKS:  rb_rdata = s_kick;
      KS_TEL_SEC_VIOL:   rb_rdata = s_sec;
      default: begin
        for (int i = 0; i < NENG; i++) begin
          if (off == KS_TEL_ENG_EVT_0 + 16'(4 * i)) rb_rdata = s_evt[i];
          if (off == KS_TEL_ENG_FLT_0 + 16'(4 * i)) rb_rdata = s_flt[i];
        end
        for (int i = 1; i <= NIRQ; i++)
          if (off == KS_TEL_IRQ_CNT_1 + 16'(4 * (i - 1))) rb_rdata = s_irq[i];
      end
    endcase
  end
endmodule
`default_nettype wire
