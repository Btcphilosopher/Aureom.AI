// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_interrupts -- interrupt controller
//
//   10 sources (ids 1..10; bit n of every mask = source n; bit 0 unused):
//     1 WDT   2 SEC   3 RAS   4 CMD   5 HOST   6 DMA   7 CPW   8 VIO   9 PKT   10 MPL
//   Output: one level, irq_out, to the CPU machine external interrupt (MEI).
//
//   Gateway (per source)
//     level type : pending follows the source line (OR the software latch)
//     edge type  : a rising edge latches pending until it is claimed (or PEND_CLR)
//     Software PEND_SET latches pending for either type (test aid, same routing path).
//     A source that is IN SERVICE (claimed, not yet completed) is masked: a level source
//     does not retrigger before the handler completes; an edge during service is latched
//     and becomes pending again after COMPLETE.
//
//   Arbitration (combinational, every cycle)
//     candidates = pending & enable & ~in-service & (priority > THRESH)
//     winner     = highest priority (0..7); equal priority -> lowest source id
//     irq_out    = candidates != 0
//
//   Claim / complete (PLIC style, register CLAIM)
//     read  : returns the winner id (0 = none), marks it in service, clears its edge latch,
//             counts the claim.  Exactly one source per read; simultaneous events are
//             delivered one after another in priority order, none is lost.
//     write : source id -> clears in-service (a write for a source that is not in service
//             is ignored).
//
//   Reset defaults: all sources disabled, level type, threshold 0, priorities
//     WDT 7, SEC 7, RAS 6, CMD 5, HOST 5, DMA 4, MPL 4, CPW 3, VIO 3, PKT 2.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_interrupts
  import sf_keystone_regs_pkg::*;
(
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  rb_sel,
  input  wire logic                  rb_we,
  input  wire logic [11:0]           rb_off,
  input  wire logic [31:0]           rb_wdata,
  output logic [31:0]                rb_rdata,
  input  wire logic [KS_NUM_IRQ:0]   src,            // raw source lines (bit 0 ignored)
  output logic                       irq_out,        // -> CPU MEI
  output logic [KS_NUM_IRQ:0]        claim_ev        // one-hot pulse when a source is claimed
);
  localparam int N = KS_NUM_IRQ;                       // 10
  // reset priorities, index = source id (packed: 3 bits per source), id 0 unused:  WDT 7 SEC 7 RAS 6 CMD 5 HOST 5 DMA 4 CPW 3 VIO 3 PKT 2 MPL 4
  localparam logic [3*(N+1)-1:0] PRIO_RST = {3'd4, 3'd2, 3'd3, 3'd3, 3'd4, 3'd5, 3'd5, 3'd6, 3'd7, 3'd7, 3'd0};

  logic [N:0] enable_q, type_q, latch_q, insvc_q, src_prev_q;
  logic [2:0] prio_q [N+1];
  logic [2:0] thresh_q;
  logic [31:0] cnt_q [N+1];

  wire [15:0] off = {4'd0, rb_off};
  wire        wr  = rb_sel && rb_we;
  wire        rd  = rb_sel && !rb_we;

  // ---------------------------------------------------------------- gateway
  wire [N:0] edge_ev = src & ~src_prev_q;
  logic [N:0] pend;
  always_comb begin
    pend = '0;
    for (int i = 1; i <= N; i++) pend[i] = latch_q[i] | (~type_q[i] & src[i]);
  end

  // ---------------------------------------------------------------- arbitration
  logic [N:0]  cand;
  logic [3:0]  win_id;
  logic [2:0]  win_prio;
  always_comb begin
    cand = '0;
    win_id = 4'd0;
    win_prio = 3'd0;
    for (int i = 1; i <= N; i++) cand[i] = pend[i] && enable_q[i] && !insvc_q[i] && (prio_q[i] > thresh_q);
    for (int i = N; i >= 1; i--) begin                  // ascending id wins ties: iterate downwards, later (lower id) overrides on >=
      if (cand[i] && prio_q[i] >= win_prio) begin win_id = 4'(i); win_prio = prio_q[i]; end
    end
  end
  assign irq_out = |cand;
  wire unused_ok = ^{rb_wdata[31:11]};

  // ---------------------------------------------------------------- register access
  wire claim_rd = rd && off == KS_INTC_CLAIM;
  wire [3:0] comp_id = rb_wdata[3:0];
  wire claim_wr = wr && off == KS_INTC_CLAIM;

  // Next value of the pending latch, computed in ONE place so that simultaneous causes cannot overwrite each other:
  //   software PEND_SET / PEND_CLR, a new rising edge (an edge is never lost, it wins over a same-cycle PEND_CLR),
  //   and the claim of the winner (which consumes its latch, but a new edge in the same cycle re-latches).
  logic [N:0] latch_n;
  always_comb begin
    latch_n = latch_q;
    if (wr && off == KS_INTC_PEND_CLR) latch_n = latch_n & ~rb_wdata[N:0];
    if (wr && off == KS_INTC_PEND_SET) latch_n = latch_n | (rb_wdata[N:0] & ~(KS_NUM_IRQ+1)'(1));
    for (int i = 1; i <= N; i++) if (type_q[i] && edge_ev[i]) latch_n[i] = 1'b1;
    if (claim_rd && win_id != 4'd0) latch_n[win_id] = type_q[win_id] ? edge_ev[win_id] : 1'b0;
    latch_n[0] = 1'b0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      enable_q <= '0; type_q <= '0; latch_q <= '0; insvc_q <= '0; src_prev_q <= '0; thresh_q <= '0;
      claim_ev <= '0;
      for (int i = 0; i <= N; i++) begin prio_q[i] <= PRIO_RST[3*i +: 3]; cnt_q[i] <= '0; end
    end else begin
      src_prev_q <= src;
      claim_ev   <= '0;
      latch_q    <= latch_n;
      // register writes
      if (wr) begin
        case (off)
          KS_INTC_ENABLE:   enable_q <= rb_wdata[N:0] & ~(KS_NUM_IRQ+1)'(1);
          KS_INTC_TYPE:     type_q   <= rb_wdata[N:0] & ~(KS_NUM_IRQ+1)'(1);
          KS_INTC_THRESH:   thresh_q <= rb_wdata[2:0];
          default: ;
        endcase
        for (int i = 1; i <= N; i++)
          if (off == KS_INTC_PRIO_1 + 16'(4 * (i - 1))) prio_q[i] <= rb_wdata[2:0];
      end
      // complete: end of service
      if (claim_wr && comp_id >= 4'd1 && comp_id <= 4'(N) && insvc_q[comp_id]) insvc_q[comp_id] <= 1'b0;
      // claim: the winner goes in service
      if (claim_rd && win_id != 4'd0) begin
        insvc_q[win_id]  <= 1'b1;
        claim_ev[win_id] <= 1'b1;
        if (cnt_q[win_id] != 32'hFFFF_FFFF) cnt_q[win_id] <= cnt_q[win_id] + 1'b1;
      end
    end
  end

  always_comb begin
    rb_rdata = 32'd0;
    case (off)
      KS_INTC_PEND:   rb_rdata = 32'(pend);
      KS_INTC_ENABLE: rb_rdata = 32'(enable_q);
      KS_INTC_TYPE:   rb_rdata = 32'(type_q);
      KS_INTC_RAW:    rb_rdata = 32'(src) & ~32'd1;
      KS_INTC_INSVC:  rb_rdata = 32'(insvc_q);
      KS_INTC_THRESH: rb_rdata = {29'd0, thresh_q};
      KS_INTC_CLAIM:  rb_rdata = {28'd0, win_id};
      KS_INTC_TOP:    rb_rdata = {21'd0, win_prio, 4'd0, win_id};
      KS_INTC_IRQ_OUT:rb_rdata = {31'd0, irq_out};
      default: begin
        for (int i = 1; i <= N; i++) begin
          if (off == KS_INTC_PRIO_1  + 16'(4 * (i - 1))) rb_rdata = {29'd0, prio_q[i]};
          if (off == KS_INTC_COUNT_1 + 16'(4 * (i - 1))) rb_rdata = cnt_q[i];
        end
      end
    endcase
  end
endmodule
`default_nettype wire
