// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_mmio -- MMIO bridge
//
//   CPU data-port slave for the MMIO region (0x4000_0000 + 1 MiB).  One access at a time.
//   Checks every access against the generated access tables BEFORE it reaches a block:
//     * unmapped offset / absent engine window      -> bus error (reason UNMAPPED)
//     * write to a read-only register               -> bus error (reason RO_WRITE)
//     * byte / halfword STORE                       -> bus error (reason SUBWORD).  Sub-word LOADS cannot be
//       detected: the reused mcu_cpu always drives d_be = 4'hF for loads, so they act as word reads.
//     * engine page that does not answer in time    -> bus error (reason ENG_TIMEOUT)
//   A rejected access never changes any register.  Every rejection raises bad_ev with the
//   address, direction and reason (recorded by SYS.BAD_ADDR / BAD_INFO).
//
//   Local blocks (SYS, TMR, INTC, WDT, CMD, RAS, TEL, MBX) and the 5 engine shells use a
//   one-cycle register strobe: rb_sel[n] with rb_we / rb_off / rb_wdata, read data is
//   combinational from the block (read side effects take place in the strobe cycle).
//   Engine glue / engine pages (window offset >= 0x100) are forwarded to the engine port
//   (req held until rvalid).
//
//   Latency: grant -> (strobe) -> response = 3 cycles for local blocks.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_mmio
  import sf_keystone_regs_pkg::*;
#(
  parameter int ENG_TIMEOUT_CYC = 4096
) (
  input  wire logic                   clk,
  input  wire logic                   rst_n,
  // CPU data port (OBI style)
  input  wire logic                   req,
  output logic                        gnt,
  input  wire logic                   we,
  input  wire logic [3:0]             be,
  input  wire logic [31:0]            addr,
  input  wire logic [31:0]            wdata,
  output logic                        rvalid,
  output logic [31:0]                 rdata,
  output logic                        err,
  // local register strobes: [0..7] SYS TMR INTC WDT CMD RAS TEL MBX, [8..12] engine shells
  output logic [12:0]                 rb_sel,
  output logic                        rb_we,
  output logic [11:0]                 rb_off,
  output logic [31:0]                 rb_wdata,
  input  wire logic [13*32-1:0]       rb_rdata,
  // engine windows
  input  wire logic [KS_NUM_ENG-1:0]  eng_present,
  output logic [KS_NUM_ENG-1:0]       eng_req,
  output logic                        eng_we,
  output logic [15:0]                 eng_addr,
  output logic [31:0]                 eng_wdata,
  input  wire logic [KS_NUM_ENG-1:0]  eng_rvalid,
  input  wire logic [KS_NUM_ENG*32-1:0] eng_rdata,
  input  wire logic [KS_NUM_ENG-1:0]  eng_err,
  // invalid-access record and telemetry
  output logic                        bad_ev,
  output logic [31:0]                 bad_addr,
  output logic                        bad_wr,
  output logic [2:0]                  bad_reason,
  output logic                        rd_pulse,
  output logic                        wr_pulse
);
  typedef enum logic [1:0] {M_IDLE, M_ACC, M_ENG, M_RSP} mst_t;
  mst_t        st_q;

  logic [31:0] addr_q, wd_q;
  logic        we_q;
  logic [3:0]  sel_q;                // 0..12 local strobe index
  logic [2:0]  eidx_q;               // engine index for forwarded access
  logic        fwd_q;                // forwarded to an engine
  logic [31:0] rsp_data_q;
  logic        rsp_err_q;
  logic [2:0]  reason_q;
  logic [$clog2(ENG_TIMEOUT_CYC+1)-1:0] to_q;

  // ------------------------------------------------------------- decode (at grant)
  logic        d_ok, d_fwd;
  logic [3:0]  d_sel;
  logic [2:0]  d_eidx, d_reason;
  logic [1:0]  d_acc;

  always_comb begin
    logic [3:0]  hi, mid;
    logic [2:0]  ei;
    hi = addr[19:16];
    mid = addr[15:12];
    ei = 3'(hi - 4'd1);
    d_ok = 1'b1; d_fwd = 1'b0; d_sel = 4'd0; d_eidx = 3'd0; d_reason = 3'd0; d_acc = KS_ACC_NONE;
    if (hi == 4'd0 && mid <= 4'd7) begin
      d_sel = mid;
      case (mid[2:0])
        3'd0: d_acc = ks_acc_sys ({4'd0, addr[11:0]});
        3'd1: d_acc = ks_acc_tmr ({4'd0, addr[11:0]});
        3'd2: d_acc = ks_acc_intc({4'd0, addr[11:0]});
        3'd3: d_acc = ks_acc_wdt ({4'd0, addr[11:0]});
        3'd4: d_acc = ks_acc_cmd ({4'd0, addr[11:0]});
        3'd5: d_acc = ks_acc_ras ({4'd0, addr[11:0]});
        3'd6: d_acc = ks_acc_tel ({4'd0, addr[11:0]});
        default: d_acc = ks_acc_mbx({4'd0, addr[11:0]});
      endcase
    end else if (hi >= 4'd1 && hi <= 4'(KS_NUM_ENG)) begin
      d_eidx = ei;
      if (addr[15:0] < KS_ESH_SIZE) begin
        d_sel = 4'd8 + 4'(ei);
        d_acc = ks_acc_esh(addr[15:0]);
      end else if (eng_present[ei]) begin
        d_fwd = 1'b1;
        d_acc = KS_ACC_RW;
      end
    end
    if (d_acc == KS_ACC_NONE)                    begin d_ok = 1'b0; d_reason = 3'(KS_BADACC_UNMAPPED); end
    else if (be != 4'hF)                         begin d_ok = 1'b0; d_reason = 3'(KS_BADACC_SUBWORD);  end
    else if (we && d_acc == KS_ACC_RO)           begin d_ok = 1'b0; d_reason = 3'(KS_BADACC_RO_WRITE); end
  end

  assign gnt = (st_q == M_IDLE) && req;

  // ------------------------------------------------------------- FSM
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= M_IDLE; addr_q <= '0; wd_q <= '0; we_q <= 1'b0; sel_q <= '0; eidx_q <= '0;
      fwd_q <= 1'b0; rsp_data_q <= '0; rsp_err_q <= 1'b0; reason_q <= '0; to_q <= '0;
      bad_ev <= 1'b0; bad_addr <= '0; bad_wr <= 1'b0; bad_reason <= '0; rd_pulse <= 1'b0; wr_pulse <= 1'b0;
    end else begin
      bad_ev <= 1'b0; rd_pulse <= 1'b0; wr_pulse <= 1'b0;
      case (st_q)
        M_IDLE: if (req) begin
          addr_q <= addr; wd_q <= wdata; we_q <= we; sel_q <= d_sel; eidx_q <= d_eidx; fwd_q <= d_fwd;
          if (!d_ok) begin
            rsp_err_q <= 1'b1; rsp_data_q <= '0; reason_q <= d_reason;
            bad_ev <= 1'b1; bad_addr <= addr; bad_wr <= we; bad_reason <= d_reason;
            st_q <= M_RSP;
          end else begin
            rsp_err_q <= 1'b0;
            to_q <= '0;
            st_q <= d_fwd ? M_ENG : M_ACC;
          end
        end
        M_ACC: begin
          rsp_data_q <= we_q ? 32'd0 : rb_rdata[sel_q*32 +: 32];
          if (we_q) wr_pulse <= 1'b1; else rd_pulse <= 1'b1;
          st_q <= M_RSP;
        end
        M_ENG: begin
          if (eng_rvalid[eidx_q]) begin
            rsp_data_q <= we_q ? 32'd0 : eng_rdata[eidx_q*32 +: 32];
            rsp_err_q  <= eng_err[eidx_q];
            if (eng_err[eidx_q]) begin
              bad_ev <= 1'b1; bad_addr <= addr_q; bad_wr <= we_q; bad_reason <= 3'(KS_BADACC_UNMAPPED);
            end else if (we_q) wr_pulse <= 1'b1; else rd_pulse <= 1'b1;
            st_q <= M_RSP;
          end else if (32'(to_q) == (ENG_TIMEOUT_CYC - 1)) begin
            rsp_data_q <= '0; rsp_err_q <= 1'b1;
            bad_ev <= 1'b1; bad_addr <= addr_q; bad_wr <= we_q; bad_reason <= 3'(KS_BADACC_ENG_TIMEOUT);
            st_q <= M_RSP;
          end else to_q <= to_q + 1'b1;
        end
        M_RSP: st_q <= M_IDLE;
        default: st_q <= M_IDLE;
      endcase
    end
  end

  assign rvalid = (st_q == M_RSP);
  assign rdata  = rsp_data_q;
  assign err    = (st_q == M_RSP) && rsp_err_q;

  // ------------------------------------------------------------- strobes
  always_comb begin
    rb_sel   = '0;
    if (st_q == M_ACC) rb_sel[sel_q] = 1'b1;
    rb_we    = we_q;
    rb_off   = addr_q[11:0];
    rb_wdata = wd_q;
    eng_req  = '0;
    if (st_q == M_ENG) eng_req[eidx_q] = 1'b1;
    eng_we    = we_q;
    eng_addr  = addr_q[15:0];
    eng_wdata = wd_q;
  end
  wire unused_ok = ^{reason_q, fwd_q};
endmodule
`default_nettype wire
