// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_timer.sv
//
//   sf_keystone_timer  machine timer (CLINT style): 64-bit mtime, 64-bit mtimecmp, msip.
//                      MTI = (mtime >= mtimecmp), MSI = msip.  Optional prescaler.
//   sf_keystone_wdt    two-stage watchdog: BARK (interrupt) after LOAD ticks, BITE (request a
//                      warm reset) BITE ticks later, unless kicked with the key.
//
//   Register layouts: config/keystone_regs.yaml (blocks TMR and WDT).
//   Both live in the warm-reset domain: a watchdog bite therefore returns the watchdog to
//   its disabled reset state; the cause is kept in SYS.RESET_CAUSE.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_timer
  import sf_keystone_regs_pkg::*;
#(
  parameter int CLK_HZ = 100_000_000
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_off,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             irq_timer,         // MTI
  output logic             irq_soft           // MSI
);
  logic        en_q, msip_q, mti_q;
  logic [7:0]  presc_q, psc_cnt_q;
  logic [63:0] mtime_q, mtimecmp_q;
  logic [31:0] hi_shadow_q;

  wire [15:0] off = {4'd0, rb_off};
  wire        wr  = rb_sel && rb_we;
  wire        rd  = rb_sel && !rb_we;
  wire        tick = en_q && (psc_cnt_q == presc_q);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q        <= KS_TMR_CTRL_RST[0];
      presc_q     <= '0;
      psc_cnt_q   <= '0;
      msip_q      <= 1'b0;
      mtime_q     <= '0;
      mtimecmp_q  <= '1;
      hi_shadow_q <= '0;
      mti_q       <= 1'b0;
    end else begin
      // prescaler and counter
      if (!en_q || tick || psc_cnt_q > presc_q) psc_cnt_q <= '0;
      else                                      psc_cnt_q <= psc_cnt_q + 1'b1;
      if (tick) mtime_q <= mtime_q + 64'd1;
      // register writes (a write wins over the increment)
      if (wr) begin
        case (off)
          KS_TMR_CTRL:        begin en_q <= rb_wdata[0]; presc_q <= rb_wdata[15:8]; end
          KS_TMR_MSIP:        msip_q <= rb_wdata[0];
          KS_TMR_MTIMECMP_LO: mtimecmp_q[31:0]  <= rb_wdata;
          KS_TMR_MTIMECMP_HI: mtimecmp_q[63:32] <= rb_wdata;
          KS_TMR_MTIME_LO:    mtime_q[31:0]  <= rb_wdata;
          KS_TMR_MTIME_HI:    mtime_q[63:32] <= rb_wdata;
          default: ;
        endcase
      end
      // coherent 64-bit read: reading LO captures HI
      if (rd && off == KS_TMR_MTIME_LO) hi_shadow_q <= mtime_q[63:32];
      mti_q <= (mtime_q >= mtimecmp_q);
    end
  end

  always_comb begin
    case (off)
      KS_TMR_CTRL:        rb_rdata = {16'd0, presc_q, 7'd0, en_q};
      KS_TMR_MSIP:        rb_rdata = {31'd0, msip_q};
      KS_TMR_MTIMECMP_LO: rb_rdata = mtimecmp_q[31:0];
      KS_TMR_MTIMECMP_HI: rb_rdata = mtimecmp_q[63:32];
      KS_TMR_MTIME_LO:    rb_rdata = mtime_q[31:0];
      KS_TMR_MTIME_HI:    rb_rdata = hi_shadow_q;
      KS_TMR_STATUS:      rb_rdata = {30'd0, msip_q, mti_q};
      KS_TMR_CLK_HZ:      rb_rdata = 32'(CLK_HZ);
      default:            rb_rdata = 32'd0;
    endcase
  end

  assign irq_timer = mti_q;
  assign irq_soft  = msip_q;
endmodule

// -----------------------------------------------------------------------------
module sf_keystone_wdt
  import sf_keystone_regs_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_off,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             irq,              // level: BARK pending and IRQ_EN
  output logic             rst_req,          // one-cycle pulse: BITE with RST_EN
  output logic             kick_ev,          // valid kick (telemetry)
  output logic             key_bad_ev        // wrong key (security violation)
);
  logic        en_q, irq_en_q, rst_en_q, lock_q;
  logic [31:0] load_q, bite_q, cnt_q, kicks_q;
  logic [15:0] presc_q, psc_cnt_q;
  logic        bark_q, bite_flag_q, stage2_q, done_q;

  wire [15:0] off = {4'd0, rb_off};
  wire        wr  = rb_sel && rb_we;
  wire        kick_wr = wr && off == KS_WDT_KICK;
  wire        kick_ok = kick_wr && rb_wdata == KS_KEY_WDT;
  assign kick_ev    = kick_ok;
  assign key_bad_ev = kick_wr && rb_wdata != KS_KEY_WDT;

  wire tick = en_q && (psc_cnt_q == presc_q);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      en_q <= 1'b0; irq_en_q <= 1'b0; rst_en_q <= 1'b0; lock_q <= 1'b0;
      load_q <= KS_WDT_LOAD_RST; bite_q <= KS_WDT_BITE_RST; presc_q <= '0; psc_cnt_q <= '0;
      cnt_q <= KS_WDT_LOAD_RST; kicks_q <= '0;
      bark_q <= 1'b0; bite_flag_q <= 1'b0; stage2_q <= 1'b0; done_q <= 1'b0; rst_req <= 1'b0;
    end else begin
      rst_req <= 1'b0;
      // ---- register writes
      if (wr) begin
        case (off)
          KS_WDT_CTRL: begin
            irq_en_q <= rb_wdata[1];
            if (!lock_q) begin en_q <= rb_wdata[0]; rst_en_q <= rb_wdata[2]; end
            if (rb_wdata[3]) lock_q <= 1'b1;               // write-1 sets, never clears
          end
          KS_WDT_LOAD:  if (!lock_q) load_q  <= rb_wdata;
          KS_WDT_BITE:  if (!lock_q) bite_q  <= rb_wdata;
          KS_WDT_PRESC: if (!lock_q) presc_q <= rb_wdata[15:0];
          KS_WDT_STATUS: if (rb_wdata[0]) bark_q <= 1'b0;
          default: ;
        endcase
      end
      // ---- prescaler
      if (!en_q || tick || psc_cnt_q > presc_q) psc_cnt_q <= '0;
      else                                      psc_cnt_q <= psc_cnt_q + 1'b1;
      // ---- counter
      if (!en_q) begin
        cnt_q <= load_q; stage2_q <= 1'b0; done_q <= 1'b0;
      end else if (kick_ok) begin
        cnt_q <= load_q; stage2_q <= 1'b0; done_q <= 1'b0; kicks_q <= kicks_q + 1'b1;
      end else if (tick && !done_q) begin
        if (cnt_q <= 32'd1) begin
          if (!stage2_q) begin
            bark_q <= 1'b1; stage2_q <= 1'b1; cnt_q <= bite_q;
          end else begin
            bite_flag_q <= 1'b1; done_q <= 1'b1;
            rst_req <= rst_en_q;
          end
        end else cnt_q <= cnt_q - 1'b1;
      end
    end
  end

  assign irq = bark_q && irq_en_q;

  always_comb begin
    case (off)
      KS_WDT_CTRL:   rb_rdata = {28'd0, lock_q, rst_en_q, irq_en_q, en_q};
      KS_WDT_LOAD:   rb_rdata = load_q;
      KS_WDT_BITE:   rb_rdata = bite_q;
      KS_WDT_PRESC:  rb_rdata = {16'd0, presc_q};
      KS_WDT_COUNT:  rb_rdata = cnt_q;
      KS_WDT_STATUS: rb_rdata = {27'd0, stage2_q, 2'd0, bite_flag_q, bark_q};
      KS_WDT_KICKS:  rb_rdata = kicks_q;
      default:       rb_rdata = 32'd0;
    endcase
  end
endmodule
`default_nettype wire
