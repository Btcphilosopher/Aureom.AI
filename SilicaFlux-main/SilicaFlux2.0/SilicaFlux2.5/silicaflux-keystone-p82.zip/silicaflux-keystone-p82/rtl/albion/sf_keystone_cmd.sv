// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_cmd -- protected management command engine
//
//   ONE command at a time:  stage -> arm (KEY) -> GO -> VALIDATE -> DISPATCH -> WAIT -> done
//
//   Protection
//     * submission needs an armed key (CMD.KEY = 'KEYS') immediately before GO; the key is
//       consumed by GO.  A wrong key, or GO without the key, is rejected and flagged SEC.BAD_KEY.
//     * the staging registers (OP, TARGET, TENANT, PRIV, ARG0..3, TIMEOUT) are write-protected
//       while a command is BUSY: such a write, a second GO or a KEY write is ignored and flagged
//       SEC.BUSY_WRITE.
//     * hardware privilege check: every opcode has a minimum privilege (KS_PRIV_*).  A command
//       whose PRIV is lower is rejected with ERR PRIV and flagged SEC.PRIV_VIOL.  PRIV is
//       supplied by the requester path (firmware copies the hardware-captured MBX.REQ_PRIV for
//       host requests); it is a consistency check, not a defence against a malicious CPU.
//     * tenant binding: engine commands need a valid tenant that has access to the target
//       engine; the DMA domain is taken from the tenant table (hardware), never from arguments.
//   Parameter validation: opcode, target (range + presence), tenant, argument ranges /
//   alignment, engine enabled, engine not in reset -- all before anything is dispatched.
//   Timeout: from dispatch until completion, CMD.TIMEOUT clocks (0 = disabled).
//   Abort: CMD.CTRL.ABORT terminates a BUSY command (a late engine answer is ignored).
//
//   Operations executed inside this block: NOP, ECHO, ENG_RESET, ENG_ENABLE, TENANT_SET,
//   TENANT_CLR, PERF_SNAP.  DMA_SUBMIT, Q_CREATE, Q_DESTROY, Q_DOORBELL are dispatched to the
//   engine named by TARGET through the dispatch port.
//
//   Register layout: config/keystone_regs.yaml (block CMD).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_cmd
  import sf_keystone_regs_pkg::*;
#(
  parameter int NUM_TENANTS = 8,
  parameter int NUM_QUEUES  = 8
) (
  input  wire logic                       clk,
  input  wire logic                       rst_n,
  input  wire logic                       rb_sel,
  input  wire logic                       rb_we,
  input  wire logic [11:0]                rb_off,
  input  wire logic [31:0]                rb_wdata,
  output logic [31:0]                     rb_rdata,
  // engine state
  input  wire logic [KS_NUM_ENG-1:0]      eng_present,
  input  wire logic [KS_NUM_ENG-1:0]      eng_in_reset,
  output logic [KS_NUM_ENG-1:0]           eng_en,
  output logic [KS_NUM_ENG-1:0]           eng_rst_req,      // pulses
  // dispatch port
  output logic                            disp_valid,
  output logic [KS_NUM_ENG-1:0]           disp_sel,
  output logic [7:0]                      disp_op,
  output logic [2:0]                      disp_tenant,
  output logic [3:0]                      disp_domain,
  output logic [31:0]                     disp_arg0,
  output logic [31:0]                     disp_arg1,
  output logic [31:0]                     disp_arg2,
  output logic [31:0]                     disp_arg3,
  input  wire logic [KS_NUM_ENG-1:0]      disp_ready,       // accepted
  input  wire logic [KS_NUM_ENG-1:0]      disp_done,        // completed (may coincide with ready)
  input  wire logic [KS_NUM_ENG-1:0]      disp_err,
  input  wire logic [KS_NUM_ENG*8-1:0]    disp_code,
  input  wire logic [KS_NUM_ENG*32-1:0]   disp_res,
  // events
  output logic                            tel_snap,         // PERF_SNAP pulse
  output logic                            cmd_irq,          // level
  output logic [8:0]                      sec_ev,           // KS_SEC_* pulses (PRIV_VIOL, BAD_KEY, BUSY_WRITE)
  output logic [7:0]                      sec_info,
  output logic                            acc_ev,
  output logic                            err_ev,
  output logic                            timeout_ev
);
  typedef enum logic [2:0] {C_IDLE, C_VALIDATE, C_DISPATCH, C_WAIT, C_RESET_WAIT} cst_t;
  cst_t st_q;

  // ---------------------------------------------------------------- state
  logic [7:0]  op_q;
  logic [2:0]  tgt_q, ten_q;
  logic [1:0]  priv_q;
  logic [31:0] arg_q [4];
  logic [31:0] res0_q, res1_q, timeout_q, to_cnt_q;
  logic        ie_q, armed_q, done_q, err_q, tmo_q, abort_q;
  logic [7:0]  errcode_q;
  logic [15:0] seq_q;
  logic [31:0] n_acc_q, n_ok_q, n_rej_q, n_tmo_q, eng_err_q;
  logic        ten_valid_q [NUM_TENANTS];
  logic [3:0]  ten_dom_q   [NUM_TENANTS];
  logic [KS_NUM_ENG-1:0] ten_mask_q [NUM_TENANTS];
  logic [KS_NUM_ENG-1:0] sel_q;
  logic        accepted_q;                  // engine accepted the dispatched command

  wire [15:0] off  = {4'd0, rb_off};
  wire        wr   = rb_sel && rb_we;
  wire        busy = (st_q != C_IDLE);

  // ---------------------------------------------------------------- opcode table
  function automatic logic op_known(input logic [7:0] o);
    case (o)
      8'(KS_OP_NOP), 8'(KS_OP_ECHO), 8'(KS_OP_ENG_RESET), 8'(KS_OP_ENG_ENABLE), 8'(KS_OP_TENANT_SET), 8'(KS_OP_TENANT_CLR),
      8'(KS_OP_DMA_SUBMIT), 8'(KS_OP_Q_CREATE), 8'(KS_OP_Q_DESTROY), 8'(KS_OP_Q_DOORBELL), 8'(KS_OP_PERF_SNAP): op_known = 1'b1;
      default: op_known = 1'b0;
    endcase
  endfunction

  function automatic logic [1:0] op_minpriv(input logic [7:0] o);
    case (o)
      8'(KS_OP_NOP), 8'(KS_OP_ECHO), 8'(KS_OP_PERF_SNAP):         op_minpriv = 2'(KS_PRIV_GUEST);
      8'(KS_OP_DMA_SUBMIT), 8'(KS_OP_Q_DOORBELL):                 op_minpriv = 2'(KS_PRIV_TENANT);
      default:                                                    op_minpriv = 2'(KS_PRIV_OPERATOR);
    endcase
  endfunction

  // ---------------------------------------------------------------- validation (combinational on the staged command)
  logic [7:0]            v_err;
  logic                  v_priv_viol;
  logic [KS_NUM_ENG-1:0] v_sel;
  logic                  v_tgt_in_range, v_tgt_queue_eng, v_ten_ok;

  always_comb begin
    v_err = 8'(KS_CERR_OK);
    v_priv_viol = 1'b0;
    v_sel = '0;
    v_tgt_in_range  = (tgt_q < 3'(KS_NUM_ENG));
    v_tgt_queue_eng = (tgt_q == 3'(KS_ENG_CPW)) || (tgt_q == 3'(KS_ENG_VIO));
    v_ten_ok        = ten_valid_q[ten_q];
    if (v_tgt_in_range) v_sel[tgt_q] = 1'b1;

    if (!op_known(op_q)) begin
      v_err = 8'(KS_CERR_BAD_OPCODE);
    end else if (priv_q < op_minpriv(op_q)) begin
      v_err = 8'(KS_CERR_PRIV);
      v_priv_viol = 1'b1;
    end else begin
      case (op_q)
        8'(KS_OP_ENG_RESET), 8'(KS_OP_ENG_ENABLE): begin
          if (!v_tgt_in_range || !(|(eng_present & v_sel))) v_err = 8'(KS_CERR_BAD_TARGET);
          else if (op_q == 8'(KS_OP_ENG_ENABLE) && arg_q[0] > 32'd1) v_err = 8'(KS_CERR_BAD_ARG);
        end
        8'(KS_OP_TENANT_SET): begin
          if (arg_q[0] > 32'd15 || (arg_q[1] >> KS_NUM_ENG) != 32'd0) v_err = 8'(KS_CERR_BAD_ARG);
        end
        8'(KS_OP_DMA_SUBMIT), 8'(KS_OP_Q_CREATE), 8'(KS_OP_Q_DESTROY), 8'(KS_OP_Q_DOORBELL): begin
          if (op_q == 8'(KS_OP_DMA_SUBMIT) ? (tgt_q != 3'(KS_ENG_DMA)) : !v_tgt_queue_eng) v_err = 8'(KS_CERR_BAD_TARGET);
          else if (!(|(eng_present & v_sel)))                                              v_err = 8'(KS_CERR_BAD_TARGET);
          else if (!v_ten_ok)                                                              v_err = 8'(KS_CERR_BAD_TENANT);
          else if (!(|(ten_mask_q[ten_q] & v_sel)))                                        v_err = 8'(KS_CERR_NO_ACCESS);
          else begin
            case (op_q)
              8'(KS_OP_DMA_SUBMIT):  if (arg_q[2] > 32'd15 || arg_q[0][5:0] != 6'd0) v_err = 8'(KS_CERR_BAD_ARG);
              8'(KS_OP_Q_CREATE):    if (arg_q[0] >= 32'(NUM_QUEUES) || arg_q[2] < 32'd2 || arg_q[2] > 32'd256 ||
                                         (arg_q[2] & (arg_q[2] - 32'd1)) != 32'd0 || arg_q[1][1:0] != 2'd0) v_err = 8'(KS_CERR_BAD_ARG);
              8'(KS_OP_Q_DESTROY),
              8'(KS_OP_Q_DOORBELL):  if (arg_q[0] >= 32'(NUM_QUEUES)) v_err = 8'(KS_CERR_BAD_ARG);
              default: ;
            endcase
            if (v_err == 8'(KS_CERR_OK)) begin
              if (!(|(eng_en & v_sel)))             v_err = 8'(KS_CERR_ENG_DISABLED);
              else if (|(eng_in_reset & v_sel))     v_err = 8'(KS_CERR_ENG_RESET);
            end
          end
        end
        default: ;                                   // NOP, ECHO, TENANT_CLR, PERF_SNAP: nothing to check
      endcase
    end
  end

  // ---------------------------------------------------------------- dispatch outputs
  assign disp_valid  = (st_q == C_DISPATCH);
  assign disp_sel    = sel_q;
  assign disp_op     = op_q;
  assign disp_tenant = ten_q;
  assign disp_domain = ten_dom_q[ten_q];
  assign disp_arg0   = arg_q[0];
  assign disp_arg1   = arg_q[1];
  assign disp_arg2   = arg_q[2];
  assign disp_arg3   = arg_q[3];

  logic        e_done, e_err, e_ready;
  logic [7:0]  e_code;
  logic [31:0] e_res;
  always_comb begin
    e_done = |(disp_done & sel_q);
    e_err  = |(disp_err  & sel_q);
    e_ready = |(disp_ready & sel_q);
    e_code = 8'd0;
    e_res  = 32'd0;
    for (int i = 0; i < KS_NUM_ENG; i++) if (sel_q[i]) begin e_code = disp_code[i*8 +: 8]; e_res = disp_res[i*32 +: 32]; end
  end

  // ---------------------------------------------------------------- main FSM / registers
  wire go_wr     = wr && off == KS_CMD_CTRL && rb_wdata[KS_CMD_CTRL_GO_LSB];
  wire abort_wr  = wr && off == KS_CMD_CTRL && rb_wdata[KS_CMD_CTRL_ABORT_LSB];
  wire clear_wr  = wr && off == KS_CMD_CTRL && rb_wdata[KS_CMD_CTRL_CLEAR_LSB];
  wire key_wr    = wr && off == KS_CMD_KEY;
  wire stage_wr  = wr && (off == KS_CMD_OP || off == KS_CMD_TARGET || off == KS_CMD_TENANT || off == KS_CMD_PRIV ||
                          off == KS_CMD_ARG0 || off == KS_CMD_ARG1 || off == KS_CMD_ARG2 || off == KS_CMD_ARG3 || off == KS_CMD_TIMEOUT);

  logic [8:0] sec_pulse;
  wire        running   = (st_q == C_DISPATCH || st_q == C_WAIT || st_q == C_RESET_WAIT);
  wire        tmo_hit   = running && timeout_q != 32'd0 && to_cnt_q >= timeout_q;
  wire        abort_hit = abort_wr && busy;

  // common completion
  task automatic finish(input logic [7:0] code, input logic tmo, input logic ab);
    st_q       <= C_IDLE;
    done_q     <= 1'b1;
    errcode_q  <= code;
    err_q      <= (code != 8'(KS_CERR_OK));
    tmo_q      <= tmo;
    abort_q    <= ab;
    sel_q      <= '0;
    if (code == 8'(KS_CERR_OK) && n_ok_q != 32'hFFFF_FFFF) n_ok_q <= n_ok_q + 1'b1;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= C_IDLE; op_q <= '0; tgt_q <= '0; ten_q <= '0; priv_q <= '0;
      for (int i = 0; i < 4; i++) arg_q[i] <= '0;
      res0_q <= '0; res1_q <= '0; timeout_q <= KS_CMD_TIMEOUT_RST; to_cnt_q <= '0;
      ie_q <= 1'b0; armed_q <= 1'b0; done_q <= 1'b0; err_q <= 1'b0; tmo_q <= 1'b0; abort_q <= 1'b0; errcode_q <= '0;
      seq_q <= '0; n_acc_q <= '0; n_ok_q <= '0; n_rej_q <= '0; n_tmo_q <= '0; eng_err_q <= '0;
      for (int i = 0; i < NUM_TENANTS; i++) begin ten_valid_q[i] <= 1'b0; ten_dom_q[i] <= '0; ten_mask_q[i] <= '0; end
      sel_q <= '0; accepted_q <= 1'b0; eng_en <= '0; eng_rst_req <= '0; tel_snap <= 1'b0;
      sec_pulse <= '0; acc_ev <= 1'b0; err_ev <= 1'b0; timeout_ev <= 1'b0; sec_info <= '0;
    end else begin
      eng_rst_req <= '0; tel_snap <= 1'b0; sec_pulse <= '0; acc_ev <= 1'b0; err_ev <= 1'b0; timeout_ev <= 1'b0;

      // ---- registers that may change at any time
      if (wr && off == KS_CMD_IE) ie_q <= rb_wdata[0];

      // ---- protected staging registers
      if (stage_wr) begin
        if (busy) begin
          sec_pulse[KS_SEC_BUSY_WRITE] <= 1'b1; sec_info <= op_q;
        end else begin
          case (off)
            KS_CMD_OP:      op_q   <= rb_wdata[7:0];
            KS_CMD_TARGET:  tgt_q  <= rb_wdata[2:0];
            KS_CMD_TENANT:  ten_q  <= rb_wdata[2:0];
            KS_CMD_PRIV:    priv_q <= rb_wdata[1:0];
            KS_CMD_ARG0:    arg_q[0] <= rb_wdata;
            KS_CMD_ARG1:    arg_q[1] <= rb_wdata;
            KS_CMD_ARG2:    arg_q[2] <= rb_wdata;
            KS_CMD_ARG3:    arg_q[3] <= rb_wdata;
            KS_CMD_TIMEOUT: timeout_q <= rb_wdata;
            default: ;
          endcase
        end
      end

      // ---- key
      if (key_wr) begin
        if (busy) begin
          sec_pulse[KS_SEC_BUSY_WRITE] <= 1'b1; sec_info <= op_q;
        end else if (rb_wdata == KS_KEY_CMD) armed_q <= 1'b1;
        else begin armed_q <= 1'b0; sec_pulse[KS_SEC_BAD_KEY] <= 1'b1; sec_info <= 8'h01; end
      end

      // ---- clear sticky status
      if (clear_wr && !busy) begin done_q <= 1'b0; err_q <= 1'b0; tmo_q <= 1'b0; abort_q <= 1'b0; errcode_q <= '0; end

      // ---- GO
      if (go_wr) begin
        if (busy) begin
          sec_pulse[KS_SEC_BUSY_WRITE] <= 1'b1; sec_info <= op_q;
          if (n_rej_q != 32'hFFFF_FFFF) n_rej_q <= n_rej_q + 1'b1;
        end else if (!armed_q) begin
          done_q <= 1'b1; err_q <= 1'b1; tmo_q <= 1'b0; abort_q <= 1'b0; errcode_q <= 8'(KS_CERR_BAD_KEY);
          sec_pulse[KS_SEC_BAD_KEY] <= 1'b1; sec_info <= op_q; err_ev <= 1'b1;
          if (n_rej_q != 32'hFFFF_FFFF) n_rej_q <= n_rej_q + 1'b1;
        end else begin
          armed_q <= 1'b0; st_q <= C_VALIDATE; seq_q <= seq_q + 1'b1;
          done_q <= 1'b0; err_q <= 1'b0; tmo_q <= 1'b0; abort_q <= 1'b0; errcode_q <= '0; res0_q <= '0; res1_q <= '0;
          if (n_acc_q != 32'hFFFF_FFFF) n_acc_q <= n_acc_q + 1'b1;
          acc_ev <= 1'b1; to_cnt_q <= '0; accepted_q <= 1'b0;
        end
      end

      // ---- command execution (timeout and abort take priority over normal completion)
      if (tmo_hit) begin
        finish(8'(KS_CERR_TIMEOUT), 1'b1, 1'b0);
        if (n_tmo_q != 32'hFFFF_FFFF) n_tmo_q <= n_tmo_q + 1'b1;
        timeout_ev <= 1'b1; err_ev <= 1'b1;
      end else if (abort_hit) begin
        finish(8'(KS_CERR_ABORTED), 1'b0, 1'b1);
        err_ev <= 1'b1;
      end else case (st_q)
        C_VALIDATE: begin
          if (v_err != 8'(KS_CERR_OK)) begin
            finish(v_err, 1'b0, 1'b0);
            err_ev <= 1'b1;
            if (n_rej_q != 32'hFFFF_FFFF) n_rej_q <= n_rej_q + 1'b1;
            if (v_priv_viol) begin sec_pulse[KS_SEC_PRIV_VIOL] <= 1'b1; sec_info <= op_q; end
          end else begin
            case (op_q)
              8'(KS_OP_NOP): finish(8'(KS_CERR_OK), 1'b0, 1'b0);
              8'(KS_OP_ECHO): begin
                res0_q <= arg_q[0] ^ arg_q[1]; res1_q <= arg_q[2] + arg_q[3];
                finish(8'(KS_CERR_OK), 1'b0, 1'b0);
              end
              8'(KS_OP_PERF_SNAP): begin tel_snap <= 1'b1; finish(8'(KS_CERR_OK), 1'b0, 1'b0); end
              8'(KS_OP_ENG_ENABLE): begin
                eng_en[tgt_q] <= arg_q[0][0];
                finish(8'(KS_CERR_OK), 1'b0, 1'b0);
              end
              8'(KS_OP_TENANT_SET): begin
                ten_valid_q[ten_q] <= 1'b1; ten_dom_q[ten_q] <= arg_q[0][3:0]; ten_mask_q[ten_q] <= arg_q[1][KS_NUM_ENG-1:0];
                finish(8'(KS_CERR_OK), 1'b0, 1'b0);
              end
              8'(KS_OP_TENANT_CLR): begin
                ten_valid_q[ten_q] <= 1'b0; ten_dom_q[ten_q] <= '0; ten_mask_q[ten_q] <= '0;
                finish(8'(KS_CERR_OK), 1'b0, 1'b0);
              end
              8'(KS_OP_ENG_RESET): begin
                eng_rst_req[tgt_q] <= 1'b1; sel_q <= v_sel; to_cnt_q <= '0; st_q <= C_RESET_WAIT;
              end
              default: begin                                  // engine command
                sel_q <= v_sel; to_cnt_q <= '0; accepted_q <= 1'b0; st_q <= C_DISPATCH;
              end
            endcase
          end
        end

        C_DISPATCH: begin
          to_cnt_q <= to_cnt_q + 1'b1;
          if (e_ready) begin
            accepted_q <= 1'b1;
            st_q <= C_WAIT;
            if (e_done) begin
              res0_q <= e_res;
              if (e_err) begin eng_err_q <= 32'(e_code); finish(8'(KS_CERR_ENG_REJECT), 1'b0, 1'b0); err_ev <= 1'b1; end
              else finish(8'(KS_CERR_OK), 1'b0, 1'b0);
            end
          end
        end

        C_WAIT: begin
          to_cnt_q <= to_cnt_q + 1'b1;
          if (e_done) begin
            res0_q <= e_res;
            if (e_err) begin eng_err_q <= 32'(e_code); finish(8'(KS_CERR_ENG_FAIL), 1'b0, 1'b0); err_ev <= 1'b1; end
            else finish(8'(KS_CERR_OK), 1'b0, 1'b0);
          end
        end

        C_RESET_WAIT: begin                                   // ENG_RESET completes when the engine has left reset
          to_cnt_q <= to_cnt_q + 1'b1;
          if (to_cnt_q >= 32'd2 && !(|(eng_in_reset & sel_q))) finish(8'(KS_CERR_OK), 1'b0, 1'b0);
        end

        default: ;
      endcase

    end
  end

  assign sec_ev  = sec_pulse;
  assign cmd_irq = ie_q && done_q;

  // ---------------------------------------------------------------- read
  always_comb begin
    rb_rdata = 32'd0;
    case (off)
      KS_CMD_STATUS:   rb_rdata = {seq_q, errcode_q, 2'd0, abort_q, armed_q, tmo_q, err_q, done_q, busy};
      KS_CMD_OP:       rb_rdata = {24'd0, op_q};
      KS_CMD_TARGET:   rb_rdata = {29'd0, tgt_q};
      KS_CMD_TENANT:   rb_rdata = {29'd0, ten_q};
      KS_CMD_PRIV:     rb_rdata = {30'd0, priv_q};
      KS_CMD_ARG0:     rb_rdata = arg_q[0];
      KS_CMD_ARG1:     rb_rdata = arg_q[1];
      KS_CMD_ARG2:     rb_rdata = arg_q[2];
      KS_CMD_ARG3:     rb_rdata = arg_q[3];
      KS_CMD_RES0:     rb_rdata = res0_q;
      KS_CMD_RES1:     rb_rdata = res1_q;
      KS_CMD_TIMEOUT:  rb_rdata = timeout_q;
      KS_CMD_IE:       rb_rdata = {31'd0, ie_q};
      KS_CMD_ACCEPTED: rb_rdata = n_acc_q;
      KS_CMD_COMPLETED:rb_rdata = n_ok_q;
      KS_CMD_REJECTED: rb_rdata = n_rej_q;
      KS_CMD_TIMEOUTS: rb_rdata = n_tmo_q;
      KS_CMD_ENG_EN:   rb_rdata = 32'(eng_en);
      KS_CMD_ENG_ERR:  rb_rdata = eng_err_q;
      default: begin
        for (int t = 0; t < NUM_TENANTS; t++)
          if (off == KS_CMD_TENANT_TBL_0 + 16'(4 * t))
            rb_rdata = {11'd0, ten_mask_q[t], 8'd0, ten_dom_q[t], 3'd0, ten_valid_q[t]};
      end
    endcase
  end

  wire unused_ok = ^{accepted_q, rb_wdata[31:3]};
endmodule
`default_nettype wire
