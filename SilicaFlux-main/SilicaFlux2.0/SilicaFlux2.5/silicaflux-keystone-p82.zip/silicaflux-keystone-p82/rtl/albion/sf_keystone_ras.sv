// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_ras -- RAS aggregation, log and fault injection
//
//   Sources
//     SRAM ECC events (IRAM, DRAM): corrected (CE) / uncorrectable (UE), with address, byte lane,
//       syndrome and which port (instruction / data) saw it.
//     CPU data-side bus errors, engine faults, engine / command timeouts, external RAS events
//     (e.g. MemoryPool ras_ev_*).
//   Behaviour
//     * every event is counted (CE_COUNT, UE_COUNT, BUS_COUNT) and recorded in LAST_* (the most
//       severe event of a cycle wins: UE > CE > engine > bus).
//     * STATUS holds sticky class flags (write 1 to clear); irq = |(STATUS & IE).
//     * INSTRUCTION-SIDE events (ECC on a fetch) are counted and logged but do NOT set STATUS:
//       an interrupt for a failing fetch would be taken before the fetch's own exception and the
//       re-fetch after MRET would raise it again (livelock found in ControlCore, Project 21).
//       The fetch itself still raises an instruction access fault.
//   Fault injection (INJ_ADDR / INJ_CTRL): while ARM is set, the next write that covers byte lane
//     LANE of word INJ_ADDR gets MASK XORed into that lane's stored 13 bits (see sf_keystone_sram).
//
//   Register layout: config/keystone_regs.yaml (block RAS).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_ras
  import sf_keystone_regs_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [11:0] rb_off,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  // SRAM events: [0] IRAM, [1] DRAM
  input  wire logic [1:0]  mem_ev_valid,
  input  wire logic [1:0]  mem_ev_ce,
  input  wire logic [1:0]  mem_ev_ue,
  input  wire logic [1:0]  mem_ev_iport,
  input  wire logic [63:0] mem_ev_addr,
  input  wire logic [3:0]  mem_ev_lane,
  input  wire logic [9:0]  mem_ev_synd,
  // other events (pulses)
  input  wire logic        bus_err_ev,          // CPU data-side bus error
  input  wire logic [31:0] bus_err_addr,
  input  wire logic        ibus_err_ev,         // CPU instruction-side bus error (counted, no STATUS)
  input  wire logic        eng_fault_ev,        // any engine fault pulse
  input  wire logic        eng_timeout_ev,      // command-engine or engine-page timeout
  input  wire logic        ext_ev_valid,        // external RAS event (MemoryPool)
  input  wire logic [31:0] ext_ev_addr,
  input  wire logic [31:0] cycle_lo,
  // injection
  output logic             inj_arm,
  output logic [31:0]      inj_addr,
  output logic [1:0]       inj_lane,
  output logic [12:0]      inj_mask,
  input  wire logic        inj_fired,
  // outputs
  output logic             irq,
  output logic             ce_ev,               // pulses for telemetry
  output logic             ue_ev
);
  logic [6:0]  stat_q, ie_q;
  logic [31:0] ce_cnt_q, ue_cnt_q, bus_cnt_q, last_addr_q, last_info_q, last_time_q, inj_done_q, events_q;
  logic [31:0] inj_addr_q;
  logic [1:0]  inj_lane_q;
  logic [12:0] inj_mask_q;
  logic        inj_arm_q;

  wire [15:0] off = {4'd0, rb_off};
  wire        wr  = rb_sel && rb_we;

  // ---- per-cycle event decode (data-side events set STATUS; instruction-side only count / log)
  logic        any_ue, any_ce, d_ue, d_ce;
  logic [31:0] ev_addr;
  logic [31:0] ev_info;
  always_comb begin
    any_ue = 1'b0; any_ce = 1'b0; d_ue = 1'b0; d_ce = 1'b0;
    ev_addr = 32'd0; ev_info = 32'd0;
    // lowest severity first so higher severity overrides
    if (bus_err_ev || ibus_err_ev) begin
      ev_addr = bus_err_addr; ev_info = {7'd0, ibus_err_ev && !bus_err_ev, 24'd0} | 32'(KS_RASSRC_BUS);
    end
    if (ext_ev_valid || eng_fault_ev || eng_timeout_ev) begin
      ev_addr = ext_ev_addr; ev_info = 32'(KS_RASSRC_ENG);
    end
    for (int m = 0; m < 2; m++) begin
      if (mem_ev_valid[m] && mem_ev_ce[m]) begin
        any_ce = 1'b1; d_ce = d_ce | !mem_ev_iport[m];
        ev_addr = mem_ev_addr[m*32 +: 32];
        ev_info = {7'd0, mem_ev_iport[m], 3'd0, mem_ev_synd[m*5 +: 5], 6'd0, mem_ev_lane[m*2 +: 2], 2'd0, 1'b0, 1'b1, 4'(m)};
      end
    end
    for (int m = 0; m < 2; m++) begin
      if (mem_ev_valid[m] && mem_ev_ue[m]) begin
        any_ue = 1'b1; d_ue = d_ue | !mem_ev_iport[m];
        ev_addr = mem_ev_addr[m*32 +: 32];
        ev_info = {7'd0, mem_ev_iport[m], 3'd0, mem_ev_synd[m*5 +: 5], 6'd0, mem_ev_lane[m*2 +: 2], 2'd0, 1'b1, 1'b0, 4'(m)};
      end
    end
  end
  assign ce_ev = any_ce;
  assign ue_ev = any_ue;

  wire any_ev = any_ue | any_ce | bus_err_ev | ibus_err_ev | eng_fault_ev | eng_timeout_ev | ext_ev_valid;

  wire [6:0] set_bits = (d_ce ? 7'(1 << KS_RAS_SRAM_CE) : 7'd0) | (d_ue ? 7'(1 << KS_RAS_SRAM_UE) : 7'd0)
                      | (bus_err_ev ? 7'(1 << KS_RAS_BUS_ERR) : 7'd0)
                      | ((eng_fault_ev || ext_ev_valid) ? 7'(1 << KS_RAS_ENG_FAULT) : 7'd0)
                      | (eng_timeout_ev ? 7'(1 << KS_RAS_ENG_TIMEOUT) : 7'd0)
                      | (inj_fired ? 7'(1 << KS_RAS_INJECT) : 7'd0);
  wire [6:0] clr_bits = (wr && off == KS_RAS_STATUS) ? rb_wdata[6:0] : 7'd0;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      stat_q <= '0; ie_q <= '0; ce_cnt_q <= '0; ue_cnt_q <= '0; bus_cnt_q <= '0; last_addr_q <= '0; last_info_q <= '0;
      last_time_q <= '0; inj_done_q <= '0; events_q <= '0;
      inj_addr_q <= '0; inj_lane_q <= '0; inj_mask_q <= '0; inj_arm_q <= 1'b0;
    end else begin
      stat_q <= (stat_q | set_bits) & ~(clr_bits & ~set_bits);
      if (wr && off == KS_RAS_IE) ie_q <= rb_wdata[6:0];
      if (any_ce && ce_cnt_q != 32'hFFFF_FFFF) ce_cnt_q <= ce_cnt_q + 1'b1;
      if (any_ue && ue_cnt_q != 32'hFFFF_FFFF) ue_cnt_q <= ue_cnt_q + 1'b1;
      if ((bus_err_ev || ibus_err_ev) && bus_cnt_q != 32'hFFFF_FFFF) bus_cnt_q <= bus_cnt_q + 1'b1;
      if (any_ev) begin
        last_addr_q <= ev_addr; last_info_q <= ev_info; last_time_q <= cycle_lo;
        if (events_q != 32'hFFFF_FFFF) events_q <= events_q + 1'b1;
      end
      // injection control
      if (wr && off == KS_RAS_INJ_ADDR) inj_addr_q <= rb_wdata & 32'hFFFF_FFFC;
      if (wr && off == KS_RAS_INJ_CTRL) begin
        inj_lane_q <= rb_wdata[2:1]; inj_mask_q <= rb_wdata[28:16]; inj_arm_q <= rb_wdata[0];
      end else if (inj_fired) inj_arm_q <= 1'b0;
      if (inj_fired && inj_done_q != 32'hFFFF_FFFF) inj_done_q <= inj_done_q + 1'b1;
    end
  end

  assign inj_arm  = inj_arm_q;
  assign inj_addr = inj_addr_q;
  assign inj_lane = inj_lane_q;
  assign inj_mask = inj_mask_q;
  assign irq      = |(stat_q & ie_q);

  always_comb begin
    case (off)
      KS_RAS_STATUS:    rb_rdata = {25'd0, stat_q};
      KS_RAS_IE:        rb_rdata = {25'd0, ie_q};
      KS_RAS_CE_COUNT:  rb_rdata = ce_cnt_q;
      KS_RAS_UE_COUNT:  rb_rdata = ue_cnt_q;
      KS_RAS_BUS_COUNT: rb_rdata = bus_cnt_q;
      KS_RAS_LAST_ADDR: rb_rdata = last_addr_q;
      KS_RAS_LAST_INFO: rb_rdata = last_info_q;
      KS_RAS_LAST_TIME: rb_rdata = last_time_q;
      KS_RAS_INJ_ADDR:  rb_rdata = inj_addr_q;
      KS_RAS_INJ_CTRL:  rb_rdata = {3'd0, inj_mask_q, 13'd0, inj_lane_q, inj_arm_q};
      KS_RAS_INJ_DONE:  rb_rdata = inj_done_q;
      KS_RAS_EVENTS:    rb_rdata = events_q;
      default:          rb_rdata = 32'd0;
    endcase
  end
endmodule
`default_nettype wire
