// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_dma_glue -- Keystone <-> CloudDMA (Project 64) glue
//
//   Maps the REAL SilicaFlux CloudDMA (silicaflux_cloud_dma, unmodified) into the Keystone engine ABI:
//     window +0x100..0x1FF  glue registers: completion record, permission-table programming
//     window +0x1000..0x1FFF  CloudDMA CSR page pass-through (privileged management plane)
//     dispatch  DMA_SUBMIT  -> CloudDMA command port.  The command DOMAIN is the one the command engine
//                             took from the TENANT table (hardware binding) -- never from the arguments
//                             (CloudDMA docs/04_INTEGRATION.md section 4).  Head = {ARG1, ARG0}, ASID = ARG2.
//     completion  done_*    -> latched into the CPL_* record, EVENT (and FAULT if status != OK).  The
//                             record is consumed with CPL_POP; a second completion waits (done_ready low).
//     isolation   viol_evt  -> VIOL (SEC.DMA_VIOL)
//   Permission table: the SIMULATION IOMMU model inside CloudDMA (USE_EXT_IOMMU = 0) is programmed through
//   PTBL_*.  Everything it implies (it is a model, not an IOMMU) is documented in docs/keystone/09_LIMITATIONS.md.
//   AW = 32 in this integration: *_HI words must be 0 (SIZE_HI bit 0 = size bit 32 is honoured).
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_dma_glue
  import sf_keystone_regs_pkg::*;
(
  input  wire logic        clk,
  input  wire logic        rst_n,                 // eng_rst_n[DMA]
  // Keystone engine window (offsets >= 0x100)
  input  wire logic        eng_req,
  input  wire logic        eng_we,
  input  wire logic [15:0] eng_addr,
  input  wire logic [31:0] eng_wdata,
  output logic             eng_rvalid,
  output logic [31:0]      eng_rdata,
  output logic             eng_err,
  // dispatch
  input  wire logic        disp_valid,
  input  wire logic        disp_sel,
  input  wire logic [7:0]  disp_op,
  input  wire logic [3:0]  disp_domain,
  input  wire logic [31:0] disp_arg0,
  input  wire logic [31:0] disp_arg1,
  input  wire logic [31:0] disp_arg2,
  output logic             disp_ready,
  output logic             disp_done,
  output logic             disp_err,
  output logic [7:0]       disp_code,
  output logic [31:0]      disp_res,
  // status / events to the Keystone shell
  output logic             evt,
  output logic             fault,
  output logic             viol,
  output logic [7:0]       fcode,
  output logic             busy,
  // CloudDMA CSR port
  output logic             csr_req_valid,
  input  wire logic        csr_req_ready,
  output logic             csr_req_write,
  output logic [11:0]      csr_req_addr,
  output logic [31:0]      csr_req_wdata,
  input  wire logic        csr_rsp_valid,
  input  wire logic [31:0] csr_rsp_rdata,
  input  wire logic        csr_rsp_err,
  // CloudDMA command / completion (one channel)
  output logic             cmd_valid,
  input  wire logic        cmd_ready,
  output logic [63:0]      cmd_head,
  output logic [3:0]       cmd_domain,
  output logic [3:0]       cmd_asid,
  input  wire logic        done_valid,
  output logic             done_ready,
  input  wire logic [15:0] done_txn,
  input  wire logic [3:0]  done_status,
  input  wire logic [7:0]  done_err,
  input  wire logic [3:0]  done_fault,
  input  wire logic [3:0]  done_domain,
  input  wire logic [31:0] done_bytes,
  input  wire logic [31:0] done_crc,
  input  wire logic        viol_evt,
  // CloudDMA permission-table programming port (AW = 32)
  output logic             ptbl_en,
  output logic [3:0]       ptbl_idx,
  output logic             ptbl_valid,
  output logic [3:0]       ptbl_domain,
  output logic [3:0]       ptbl_asid,
  output logic [31:0]      ptbl_base,
  output logic [32:0]      ptbl_size,
  output logic [31:0]      ptbl_pa,
  output logic [1:0]       ptbl_perm,
  input  wire logic        ptbl_rej
);
  // ---------------------------------------------------------------- dispatch -> command port
  wire is_submit = (disp_op == 8'(KS_OP_DMA_SUBMIT));
  assign cmd_valid  = disp_valid && disp_sel && is_submit;
  assign cmd_head   = {disp_arg1, disp_arg0};
  assign cmd_domain = disp_domain;                   // hardware-bound domain
  assign cmd_asid   = disp_arg2[3:0];
  assign disp_ready = disp_valid && disp_sel && (is_submit ? cmd_ready : 1'b1);
  assign disp_done  = disp_ready;                    // acceptance completes the management command; the DMA completes later
  assign disp_err   = disp_valid && disp_sel && !is_submit;
  assign disp_code  = is_submit ? 8'd0 : 8'h01;      // 0x01: opcode not supported by the DMA engine
  logic [31:0] submitted_q;
  assign disp_res   = submitted_q + 32'd1;           // sequence number of this submission

  // ---------------------------------------------------------------- completion record
  logic        cpl_valid_q;
  logic [3:0]  cpl_status_q, cpl_fault_q, cpl_dom_q;
  logic [7:0]  cpl_err_q;
  logic [15:0] cpl_txn_q;
  logic [31:0] cpl_bytes_q, cpl_crc_q;
  logic [7:0]  outstanding_q;

  assign done_ready = !cpl_valid_q;
  wire   cpl_take   = done_valid && done_ready;

  assign busy = (outstanding_q != 8'd0);

  localparam logic [31:0] PTBL_CFG_WMASK = 32'h030F0F01;     // VALID, DOMAIN, ASID, PERM (config/keystone_regs.yaml)

  // ---------------------------------------------------------------- register window FSM
  typedef enum logic [1:0] {G_IDLE, G_CSR, G_RSP} gst_t;
  gst_t        st_q;
  logic [31:0] rdata_q;
  logic        err_q;
  logic [3:0]  p_idx_q;
  logic [31:0] p_cfg_q, p_base_lo_q, p_base_hi_q, p_size_lo_q, p_size_hi_q, p_pa_lo_q, p_pa_hi_q;
  logic        p_rej_q;

  wire [15:0] a = eng_addr;
  wire        is_csr = (a >= KS_ENG_PASS_OFF) && (a < KS_ENG_PASS_OFF + 16'h1000);
  wire [11:0] csr_a = a[11:0];

  // glue register read
  logic [31:0] g_rd;
  logic        g_ok_rd, g_ok_wr;
  always_comb begin
    g_rd = 32'd0; g_ok_rd = 1'b1; g_ok_wr = 1'b0;
    case (a)
      KS_DMA_CPL_STAT:   begin g_rd = {12'd0, cpl_fault_q, cpl_err_q, cpl_status_q, 3'd0, cpl_valid_q}; end
      KS_DMA_CPL_TXN:    g_rd = {16'd0, cpl_txn_q};
      KS_DMA_CPL_DOMAIN: g_rd = {28'd0, cpl_dom_q};
      KS_DMA_CPL_BYTES:  g_rd = cpl_bytes_q;
      KS_DMA_CPL_CRC:    g_rd = cpl_crc_q;
      KS_DMA_CPL_POP:    begin g_rd = 32'd0; g_ok_wr = 1'b1; end
      KS_DMA_SUBMITTED:  g_rd = submitted_q;
      KS_DMA_PTBL_IDX:      begin g_rd = {28'd0, p_idx_q}; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_CFG:      begin g_rd = p_cfg_q; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_BASE_LO:  begin g_rd = p_base_lo_q; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_BASE_HI:  begin g_rd = p_base_hi_q; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_SIZE_LO:  begin g_rd = p_size_lo_q; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_SIZE_HI:  begin g_rd = p_size_hi_q; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_PA_LO:    begin g_rd = p_pa_lo_q; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_PA_HI:    begin g_rd = p_pa_hi_q; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_CTRL:     begin g_rd = 32'd0; g_ok_wr = 1'b1; end
      KS_DMA_PTBL_STATUS:   begin g_rd = {31'd0, p_rej_q}; g_ok_wr = 1'b1; end
      default: begin g_ok_rd = 1'b0; end
    endcase
    // read-only registers refuse writes
    if (a == KS_DMA_CPL_STAT || a == KS_DMA_CPL_TXN || a == KS_DMA_CPL_DOMAIN || a == KS_DMA_CPL_BYTES ||
        a == KS_DMA_CPL_CRC || a == KS_DMA_SUBMITTED) g_ok_wr = 1'b0;
    if (a == KS_DMA_CPL_POP) g_ok_rd = 1'b1;
  end

  assign csr_req_valid = (st_q == G_IDLE) && eng_req && is_csr;
  assign csr_req_write = eng_we;
  assign csr_req_addr  = csr_a;
  assign csr_req_wdata = eng_wdata;

  // permission table port
  assign ptbl_idx    = p_idx_q;
  assign ptbl_valid  = p_cfg_q[KS_DMA_PTBL_CFG_VALID_LSB];
  assign ptbl_domain = p_cfg_q[KS_DMA_PTBL_CFG_DOMAIN_LSB +: 4];
  assign ptbl_asid   = p_cfg_q[KS_DMA_PTBL_CFG_ASID_LSB +: 4];
  assign ptbl_perm   = p_cfg_q[KS_DMA_PTBL_CFG_PERM_LSB +: 2];
  assign ptbl_base   = p_base_lo_q;
  assign ptbl_size   = {p_size_hi_q[0], p_size_lo_q};
  assign ptbl_pa     = p_pa_lo_q;

  assign eng_rvalid = (st_q == G_RSP);
  assign eng_rdata  = rdata_q;
  assign eng_err    = err_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_q <= G_IDLE; rdata_q <= '0; err_q <= 1'b0;
      cpl_valid_q <= 1'b0; cpl_status_q <= '0; cpl_fault_q <= '0; cpl_dom_q <= '0; cpl_err_q <= '0; cpl_txn_q <= '0;
      cpl_bytes_q <= '0; cpl_crc_q <= '0; outstanding_q <= '0; submitted_q <= '0;
      p_idx_q <= '0; p_cfg_q <= '0; p_base_lo_q <= '0; p_base_hi_q <= '0; p_size_lo_q <= '0; p_size_hi_q <= '0;
      p_pa_lo_q <= '0; p_pa_hi_q <= '0; p_rej_q <= 1'b0;
      ptbl_en <= 1'b0; evt <= 1'b0; fault <= 1'b0; viol <= 1'b0; fcode <= '0;
    end else begin
      ptbl_en <= 1'b0; evt <= 1'b0; fault <= 1'b0; viol <= viol_evt;

      // ---- command accepted by CloudDMA
      if (cmd_valid && cmd_ready) begin
        submitted_q <= submitted_q + 32'd1;
      end
      // outstanding = accepted commands whose completion has not been taken yet
      outstanding_q <= outstanding_q + {7'd0, (cmd_valid && cmd_ready)} - {7'd0, (cpl_take && outstanding_q != 8'd0)};
      // ---- completion record
      if (cpl_take) begin
        cpl_valid_q <= 1'b1; cpl_status_q <= done_status; cpl_fault_q <= done_fault; cpl_dom_q <= done_domain;
        cpl_err_q <= done_err; cpl_txn_q <= done_txn; cpl_bytes_q <= done_bytes; cpl_crc_q <= done_crc;
        evt <= 1'b1;
        if (done_status != 4'd0) begin fault <= 1'b1; fcode <= done_err; end
      end
      if (ptbl_rej) p_rej_q <= 1'b1;

      // ---- window access
      case (st_q)
        G_IDLE: if (eng_req) begin
          if (is_csr) begin
            if (csr_req_ready) st_q <= G_CSR;
          end else begin
            err_q <= eng_we ? !g_ok_wr : !g_ok_rd;
            rdata_q <= (eng_we || !g_ok_rd) ? 32'd0 : g_rd;
            if (eng_we && g_ok_wr) begin
              case (a)
                KS_DMA_CPL_POP:      if (eng_wdata[0]) cpl_valid_q <= 1'b0;
                KS_DMA_PTBL_IDX:     p_idx_q <= eng_wdata[3:0];
                KS_DMA_PTBL_CFG:     p_cfg_q <= eng_wdata & PTBL_CFG_WMASK;
                KS_DMA_PTBL_BASE_LO: p_base_lo_q <= eng_wdata;
                KS_DMA_PTBL_BASE_HI: p_base_hi_q <= eng_wdata;
                KS_DMA_PTBL_SIZE_LO: p_size_lo_q <= eng_wdata;
                KS_DMA_PTBL_SIZE_HI: p_size_hi_q <= eng_wdata;
                KS_DMA_PTBL_PA_LO:   p_pa_lo_q <= eng_wdata;
                KS_DMA_PTBL_PA_HI:   p_pa_hi_q <= eng_wdata;
                KS_DMA_PTBL_CTRL:    if (eng_wdata[0]) ptbl_en <= 1'b1;
                KS_DMA_PTBL_STATUS:  if (eng_wdata[0]) p_rej_q <= 1'b0;
                default: ;
              endcase
            end
            st_q <= G_RSP;
          end
        end
        G_CSR: if (csr_rsp_valid) begin
          rdata_q <= csr_rsp_rdata; err_q <= csr_rsp_err; st_q <= G_RSP;
        end
        G_RSP: st_q <= G_IDLE;
        default: st_q <= G_IDLE;
      endcase
    end
  end
  wire unused_ok = ^{disp_arg2[31:4], done_txn[15:0], p_base_hi_q, p_pa_hi_q, a[15:12]};
endmodule
`default_nettype wire
