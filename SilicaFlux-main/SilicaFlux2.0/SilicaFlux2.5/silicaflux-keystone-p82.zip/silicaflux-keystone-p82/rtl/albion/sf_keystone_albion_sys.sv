// =============================================================================
// SilicaFlux Albion :: sf_keystone_albion_sys -- Keystone control subsystem + engines (simulation system)
//
//   sf_keystone_control (the control processor)  +
//     DMA  : the REAL SilicaFlux CloudDMA (Project 64, unmodified) behind sf_keystone_dma_glue; its AXI4
//            memory master reads / writes the Keystone shared buffer SRAM (SHM) through the Keystone AXI slave
//     CPW  : BEHAVIOURAL MODEL (sf_keystone_engmodel) -- ComputeWorks stand-in
//     VIO  : BEHAVIOURAL MODEL (sf_keystone_engmodel) -- Virtual I/O stand-in
//     PKT, MPL : not present in this release (SYS.CAPS0 says so; their windows answer with the shell only)
//   Engine power-good is modelled as the power request delayed by 4 clocks (the SoC power controller is
//   outside Project 82).
//
// Classification: SIMULATION SYSTEM (contains models)
// =============================================================================
`default_nettype none

module sf_keystone_albion_sys
  import sf_keystone_regs_pkg::*;
#(
  parameter int CLK_HZ = 100_000_000
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic [63:0] chip_uid,
  // firmware store
  output logic             fws_req,
  input  wire logic        fws_gnt,
  output logic [31:0]      fws_addr,
  input  wire logic        fws_rvalid,
  input  wire logic [31:0] fws_rdata,
  input  wire logic        fws_err,
  output logic             console_valid,
  output logic [7:0]       console_byte,
  // host management port
  input  wire logic        host_req,
  input  wire logic        host_we,
  input  wire logic [15:0] host_addr,
  input  wire logic [31:0] host_wdata,
  input  wire logic [1:0]  host_priv,
  output logic             host_rvalid,
  output logic [31:0]      host_rdata,
  output logic             host_err,
  output logic             host_irq,
  // status / verification trace
  output logic             core_rst_n_o,
  output logic             cpu_sleeping,
  output logic             dbg_rt_valid,
  output logic [31:0]      dbg_rt_pc,
  output logic             dbg_rt_trap,
  output logic [31:0]      dbg_rt_cause
);
  localparam int N = KS_NUM_ENG;
  localparam logic [N-1:0] ENG_PRESENT = 5'b11001;       // DMA, CPW, VIO
  localparam logic [N-1:0] ENG_REAL    = 5'b00001;       // DMA only
  localparam int ID_W = 4;                                // CloudDMA: log2(NUM_CH)=1 + (log2(4)+1)

  // ------------------------------------------------------------------ Keystone <-> engines
  logic [N-1:0] eng_req, eng_rvalid, eng_err, eng_evt, eng_fault, eng_viol, eng_busy, eng_pwr_good;
  logic         eng_we;
  logic [15:0]  eng_addr;
  logic [31:0]  eng_wdata;
  logic [N*32-1:0] eng_rdata;
  logic [N*8-1:0]  eng_fcode;
  logic [N-1:0] eng_rst_n, eng_en, eng_pwr_en;
  logic         disp_valid;
  logic [N-1:0] disp_sel, disp_ready, disp_done, disp_err;
  logic [7:0]   disp_op;
  logic [2:0]   disp_tenant;
  logic [3:0]   disp_domain;
  logic [31:0]  disp_arg0, disp_arg1, disp_arg2, disp_arg3;
  logic [N*8-1:0]  disp_code;
  logic [N*32-1:0] disp_res;

  // AXI between CloudDMA and the Keystone shared SRAM
  logic            ar_valid, ar_ready, r_valid, r_ready, r_last, aw_valid, aw_ready, w_valid, w_ready, w_last, b_valid, b_ready;
  logic [ID_W-1:0] ar_id, r_id, aw_id, b_id;
  logic [31:0]     ar_addr, aw_addr;
  logic [7:0]      ar_len, aw_len;
  logic [2:0]      ar_size, aw_size;
  logic [1:0]      ar_burst, aw_burst, r_resp, b_resp;
  logic [63:0]     r_data, w_data;
  logic [7:0]      w_strb;

  sf_keystone_control #(
    .CLK_HZ(CLK_HZ), .ENG_PRESENT(ENG_PRESENT), .ENG_REAL(ENG_REAL), .AXI_ID_W(ID_W)
  ) u_ks (
    .clk, .rst_n, .chip_uid,
    .fws_req, .fws_gnt, .fws_addr, .fws_rvalid, .fws_rdata, .fws_err,
    .console_valid, .console_byte,
    .host_req, .host_we, .host_addr, .host_wdata, .host_priv, .host_rvalid, .host_rdata, .host_err, .host_irq,
    .s_ar_valid(ar_valid), .s_ar_ready(ar_ready), .s_ar_id(ar_id), .s_ar_addr(ar_addr), .s_ar_len(ar_len), .s_ar_size(ar_size), .s_ar_burst(ar_burst),
    .s_r_valid(r_valid), .s_r_ready(r_ready), .s_r_id(r_id), .s_r_data(r_data), .s_r_resp(r_resp), .s_r_last(r_last),
    .s_aw_valid(aw_valid), .s_aw_ready(aw_ready), .s_aw_id(aw_id), .s_aw_addr(aw_addr), .s_aw_len(aw_len), .s_aw_size(aw_size), .s_aw_burst(aw_burst),
    .s_w_valid(w_valid), .s_w_ready(w_ready), .s_w_data(w_data), .s_w_strb(w_strb), .s_w_last(w_last),
    .s_b_valid(b_valid), .s_b_ready(b_ready), .s_b_id(b_id), .s_b_resp(b_resp),
    .eng_req, .eng_we, .eng_addr, .eng_wdata, .eng_rvalid, .eng_rdata, .eng_err,
    .eng_evt, .eng_fault, .eng_viol, .eng_fcode, .eng_busy, .eng_pwr_good,
    .ext_ras_valid(1'b0), .ext_ras_addr(32'd0),
    .eng_rst_n, .eng_en, .eng_pwr_en,
    .disp_valid, .disp_sel, .disp_op, .disp_tenant, .disp_domain, .disp_arg0, .disp_arg1, .disp_arg2, .disp_arg3,
    .disp_ready, .disp_done, .disp_err, .disp_code, .disp_res,
    .core_rst_n_o, .cpu_sleeping, .dbg_rt_valid, .dbg_rt_pc, .dbg_rt_trap, .dbg_rt_cause
  );

  // ------------------------------------------------------------------ power-good model
  logic [3:0] pg_sh [N];
  for (genvar e = 0; e < N; e++) begin : g_pg
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) pg_sh[e] <= 4'hF;
      else        pg_sh[e] <= {pg_sh[e][2:0], eng_pwr_en[e]};
    end
    assign eng_pwr_good[e] = pg_sh[e][3];
  end

  // ------------------------------------------------------------------ DMA: real CloudDMA + glue
  localparam int E = KS_ENG_DMA;
  logic        csr_req_valid, csr_req_ready, csr_req_write, csr_rsp_valid, csr_rsp_err, dma_irq;
  logic [11:0] csr_req_addr;
  logic [31:0] csr_req_wdata, csr_rsp_rdata;
  logic        cmd_valid, cmd_ready, done_valid, done_ready, viol_evt;
  logic [63:0] cmd_head;
  logic [3:0]  cmd_domain, cmd_asid, done_status, done_fault, done_domain;
  logic [15:0] done_txn;
  logic [7:0]  done_err;
  logic [31:0] done_bytes, done_crc;
  logic        ptbl_en, ptbl_valid, ptbl_rej;
  logic [3:0]  ptbl_idx, ptbl_domain, ptbl_asid;
  logic [31:0] ptbl_base, ptbl_pa;
  logic [32:0] ptbl_size;
  logic [1:0]  ptbl_perm;

  sf_keystone_dma_glue u_dma_glue (
    .clk, .rst_n(eng_rst_n[E]),
    .eng_req(eng_req[E]), .eng_we, .eng_addr, .eng_wdata,
    .eng_rvalid(eng_rvalid[E]), .eng_rdata(eng_rdata[E*32 +: 32]), .eng_err(eng_err[E]),
    .disp_valid, .disp_sel(disp_sel[E]), .disp_op, .disp_domain, .disp_arg0, .disp_arg1, .disp_arg2,
    .disp_ready(disp_ready[E]), .disp_done(disp_done[E]), .disp_err(disp_err[E]), .disp_code(disp_code[E*8 +: 8]), .disp_res(disp_res[E*32 +: 32]),
    .evt(eng_evt[E]), .fault(eng_fault[E]), .viol(eng_viol[E]), .fcode(eng_fcode[E*8 +: 8]), .busy(eng_busy[E]),
    .csr_req_valid, .csr_req_ready, .csr_req_write, .csr_req_addr, .csr_req_wdata, .csr_rsp_valid, .csr_rsp_rdata, .csr_rsp_err,
    .cmd_valid, .cmd_ready, .cmd_head, .cmd_domain, .cmd_asid,
    .done_valid, .done_ready, .done_txn, .done_status, .done_err, .done_fault, .done_domain, .done_bytes, .done_crc, .viol_evt,
    .ptbl_en, .ptbl_idx, .ptbl_valid, .ptbl_domain, .ptbl_asid, .ptbl_base, .ptbl_size, .ptbl_pa, .ptbl_perm, .ptbl_rej
  );

  silicaflux_cloud_dma #(
    .NUM_CH(1), .DW(64), .AW(32), .DOM_W(4), .MAX_BURST_BEATS(16), .RD_OUT(4), .WR_OUT(4), .BUF_BYTES(1024),
    .CRC_ON(1'b1), .USE_EXT_IOMMU(1'b0), .PERM_ENTRIES(16)
  ) u_cloud_dma (
    .clk, .rst_n(eng_rst_n[E]),
    .csr_req_valid, .csr_req_ready, .csr_req_write, .csr_req_addr, .csr_req_wdata,
    .csr_rsp_valid, .csr_rsp_rdata, .csr_rsp_err, .irq(dma_irq),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_head(cmd_head), .cmd_domain(cmd_domain), .cmd_asid(cmd_asid),
    .done_valid(done_valid), .done_ready(done_ready), .done_txn(done_txn), .done_status(done_status), .done_err(done_err),
    .done_fault(done_fault), .done_domain(done_domain), .done_bytes(done_bytes), .done_crc(done_crc), .viol_evt(viol_evt),
    .m_ar_valid(ar_valid), .m_ar_ready(ar_ready), .m_ar_id(ar_id), .m_ar_addr(ar_addr), .m_ar_len(ar_len), .m_ar_size(ar_size),
    .m_ar_burst(ar_burst), .m_ar_asid(), .m_ar_domain(),
    .m_r_valid(r_valid), .m_r_ready(r_ready), .m_r_id(r_id), .m_r_data(r_data), .m_r_resp(r_resp), .m_r_last(r_last),
    .m_aw_valid(aw_valid), .m_aw_ready(aw_ready), .m_aw_id(aw_id), .m_aw_addr(aw_addr), .m_aw_len(aw_len), .m_aw_size(aw_size),
    .m_aw_burst(aw_burst), .m_aw_asid(), .m_aw_domain(),
    .m_w_valid(w_valid), .m_w_ready(w_ready), .m_w_data(w_data), .m_w_strb(w_strb), .m_w_last(w_last),
    .m_b_valid(b_valid), .m_b_ready(b_ready), .m_b_id(b_id), .m_b_resp(b_resp),
    .iommu_req_valid(), .iommu_req_ready(1'b0), .iommu_req_domain(), .iommu_req_asid(), .iommu_req_write(), .iommu_req_addr(),
    .iommu_req_bytes(), .iommu_req_id(), .iommu_rsp_valid(1'b0), .iommu_rsp_ready(), .iommu_rsp_id('0), .iommu_rsp_ok(1'b0),
    .iommu_rsp_fault(4'd0), .iommu_rsp_pa(32'd0),
    .ptbl_en, .ptbl_idx, .ptbl_valid, .ptbl_domain, .ptbl_asid, .ptbl_base, .ptbl_size, .ptbl_pa, .ptbl_perm, .ptbl_rej
  );

  // ------------------------------------------------------------------ CPW / VIO behavioural models
  for (genvar m = 0; m < 2; m++) begin : g_model
    localparam int EI = (m == 0) ? KS_ENG_CPW : KS_ENG_VIO;
    sf_keystone_engmodel u_model (
      .clk, .rst_n(eng_rst_n[EI]),
      .eng_req(eng_req[EI]), .eng_we, .eng_addr, .eng_wdata,
      .eng_rvalid(eng_rvalid[EI]), .eng_rdata(eng_rdata[EI*32 +: 32]), .eng_err(eng_err[EI]),
      .disp_valid, .disp_sel(disp_sel[EI]), .disp_op, .disp_tenant, .disp_arg0, .disp_arg1, .disp_arg2,
      .disp_ready(disp_ready[EI]), .disp_done(disp_done[EI]), .disp_err(disp_err[EI]), .disp_code(disp_code[EI*8 +: 8]), .disp_res(disp_res[EI*32 +: 32]),
      .evt(eng_evt[EI]), .fault(eng_fault[EI]), .viol(eng_viol[EI]), .fcode(eng_fcode[EI*8 +: 8]), .busy(eng_busy[EI])
    );
  end

  // ------------------------------------------------------------------ absent engines (PKT, MPL)
  for (genvar a = 0; a < 2; a++) begin : g_absent
    localparam int EI = (a == 0) ? KS_ENG_PKT : KS_ENG_MPL;
    assign eng_rvalid[EI] = 1'b0;
    assign eng_rdata[EI*32 +: 32] = 32'd0;
    assign eng_err[EI]    = 1'b0;
    assign eng_evt[EI]    = 1'b0;
    assign eng_fault[EI]  = 1'b0;
    assign eng_viol[EI]   = 1'b0;
    assign eng_fcode[EI*8 +: 8] = 8'd0;
    assign eng_busy[EI]   = 1'b0;
    assign disp_ready[EI] = 1'b0;
    assign disp_done[EI]  = 1'b0;
    assign disp_err[EI]   = 1'b0;
    assign disp_code[EI*8 +: 8] = 8'd0;
    assign disp_res[EI*32 +: 32] = 32'd0;
  end

  wire unused_ok = ^{dma_irq, eng_en, disp_arg3};
endmodule
`default_nettype wire
