// =============================================================================
// SilicaFlux Albion / Keystone :: sf_keystone_shm -- shared buffer SRAM
//
//   64-bit storage, no ECC (documented limitation; data buffers are protected end to end by the DMA
//   CRC), two access paths into ONE memory port:
//     * CPU port  : 32-bit OBI-style (req/gnt, rvalid one cycle after the grant)
//     * AXI4 slave: 64-bit, INCR bursts, one outstanding read burst and one write burst, ONE beat in
//                   flight (control-plane DMA; throughput is not a goal: about one beat per 3 cycles).
//                   For the CloudDMA memory master (silicaflux_cloud_dma, DW = 64, AW = 32).
//   Arbitration: round robin over {CPU, AXI read beat, AXI write beat}.
//   AXI behaviour
//     * size must be 3 (8 bytes) and burst INCR (1); anything else returns SLVERR for every beat
//       (all beats are still consumed / produced so the master never hangs).
//     * beats outside the SHM window return SLVERR (reads: data 0) and writes are dropped.
//     * B is returned only after the last write beat has been written to the memory.
//     * IDs are returned unchanged.  axi_err_ev pulses once per errored beat.
//
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none

module sf_keystone_shm #(
  parameter int          DEPTH64 = 2048,                 // 64-bit words (16 KiB)
  parameter int          ID_W    = 4,
  parameter logic [31:0] BASE    = 32'h0030_0000
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // CPU port
  input  wire logic            c_req,
  output logic                 c_gnt,
  input  wire logic            c_we,
  input  wire logic [3:0]      c_be,
  input  wire logic [31:0]     c_addr,
  input  wire logic [31:0]     c_wdata,
  output logic                 c_rvalid,
  output logic [31:0]          c_rdata,
  output logic                 c_err,
  // AXI4 slave
  input  wire logic            s_ar_valid,
  output logic                 s_ar_ready,
  input  wire logic [ID_W-1:0] s_ar_id,
  input  wire logic [31:0]     s_ar_addr,
  input  wire logic [7:0]      s_ar_len,
  input  wire logic [2:0]      s_ar_size,
  input  wire logic [1:0]      s_ar_burst,
  output logic                 s_r_valid,
  input  wire logic            s_r_ready,
  output logic [ID_W-1:0]      s_r_id,
  output logic [63:0]          s_r_data,
  output logic [1:0]           s_r_resp,
  output logic                 s_r_last,
  input  wire logic            s_aw_valid,
  output logic                 s_aw_ready,
  input  wire logic [ID_W-1:0] s_aw_id,
  input  wire logic [31:0]     s_aw_addr,
  input  wire logic [7:0]      s_aw_len,
  input  wire logic [2:0]      s_aw_size,
  input  wire logic [1:0]      s_aw_burst,
  input  wire logic            s_w_valid,
  output logic                 s_w_ready,
  input  wire logic [63:0]     s_w_data,
  input  wire logic [7:0]      s_w_strb,
  input  wire logic            s_w_last,
  output logic                 s_b_valid,
  input  wire logic            s_b_ready,
  output logic [ID_W-1:0]      s_b_id,
  output logic [1:0]           s_b_resp,
  output logic                 axi_err_ev
);
  localparam int AW64 = $clog2(DEPTH64);
  localparam logic [31:0] SIZE = 32'(DEPTH64 * 8);

  function automatic logic in_range(input logic [31:0] a);
    in_range = (a >= BASE) && (a < BASE + SIZE);
  endfunction

  // ---------------------------------------------------------------- storage (single port)
  logic [63:0] mem [DEPTH64];
  logic [63:0] mem_q;
  logic        mem_ce, mem_we;
  logic [7:0]  mem_be;
  logic [AW64-1:0] mem_a;
  logic [63:0] mem_d;

  always_ff @(posedge clk) begin
    if (mem_ce) begin
      if (mem_we) begin
        for (int b = 0; b < 8; b++) if (mem_be[b]) mem[mem_a][8*b +: 8] <= mem_d[8*b +: 8];
      end
      mem_q <= mem[mem_a];
    end
  end

  // ---------------------------------------------------------------- AXI read / write state
  logic              rd_active_q, rd_pend_q, rd_last_q, rd_perr_q;
  logic [ID_W-1:0]   rd_id_q;
  logic [31:0]       rd_addr_q;
  logic [8:0]        rd_left_q;
  logic              wr_active_q, wr_perr_q, wr_err_q;
  logic [ID_W-1:0]   wr_id_q;
  logic [31:0]       wr_addr_q;
  logic [1:0]        rr_q;

  wire rd_beat_err = rd_perr_q || !in_range(rd_addr_q);
  wire wr_beat_err = wr_perr_q || !in_range(wr_addr_q);
  wire rd_free     = rd_active_q && !rd_pend_q && !s_r_valid;

  logic [2:0] rq, gnt;
  always_comb begin
    rq[0] = c_req;
    rq[1] = rd_free && !rd_beat_err;
    rq[2] = wr_active_q && s_w_valid && !wr_beat_err;
    gnt = 3'b000;
    for (int i = 0; i < 3; i++) begin
      logic [1:0] idx;
      idx = 2'((int'(rr_q) + 1 + i) % 3);
      if (rq[idx] && gnt == 3'b000) gnt[idx] = 1'b1;
    end
  end
  assign c_gnt = gnt[0];
  wire g_rd = gnt[1];
  wire g_wr = gnt[2];

  // memory port mux
  always_comb begin
    mem_ce = 1'b0; mem_we = 1'b0; mem_be = 8'd0; mem_a = '0; mem_d = 64'd0;
    if (gnt[0]) begin
      mem_ce = 1'b1; mem_we = c_we;
      mem_a  = c_addr[AW64+2:3];
      mem_d  = {c_wdata, c_wdata};
      mem_be = c_addr[2] ? {c_be, 4'b0000} : {4'b0000, c_be};
    end else if (g_rd) begin
      mem_ce = 1'b1; mem_a = rd_addr_q[AW64+2:3];
    end else if (g_wr) begin
      mem_ce = 1'b1; mem_we = 1'b1; mem_a = wr_addr_q[AW64+2:3]; mem_d = s_w_data; mem_be = s_w_strb;
    end
  end

  // ---------------------------------------------------------------- CPU response
  logic c_rd_q, c_wr_q, c_hi_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin c_rd_q <= 1'b0; c_wr_q <= 1'b0; c_hi_q <= 1'b0; end
    else begin c_rd_q <= gnt[0] && !c_we; c_wr_q <= gnt[0] && c_we; c_hi_q <= c_addr[2]; end
  end
  assign c_rvalid = c_rd_q | c_wr_q;
  assign c_rdata  = c_rd_q ? (c_hi_q ? mem_q[63:32] : mem_q[31:0]) : 32'd0;
  assign c_err    = 1'b0;

  // ---------------------------------------------------------------- AXI channels
  assign s_ar_ready = !rd_active_q && !s_r_valid;
  assign s_aw_ready = !wr_active_q && !s_b_valid;
  assign s_w_ready  = wr_active_q && s_w_valid && (wr_beat_err || g_wr);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rd_active_q <= 1'b0; rd_pend_q <= 1'b0; rd_last_q <= 1'b0; rd_perr_q <= 1'b0; rd_id_q <= '0; rd_addr_q <= '0; rd_left_q <= '0;
      wr_active_q <= 1'b0; wr_perr_q <= 1'b0; wr_err_q <= 1'b0; wr_id_q <= '0; wr_addr_q <= '0;
      s_r_valid <= 1'b0; s_r_id <= '0; s_r_data <= '0; s_r_resp <= '0; s_r_last <= 1'b0;
      s_b_valid <= 1'b0; s_b_id <= '0; s_b_resp <= '0; rr_q <= 2'd2; axi_err_ev <= 1'b0;
    end else begin
      axi_err_ev <= 1'b0;
      if (|gnt) rr_q <= gnt[0] ? 2'd0 : gnt[1] ? 2'd1 : 2'd2;

      // ---- read address
      if (s_ar_valid && s_ar_ready) begin
        rd_active_q <= 1'b1; rd_id_q <= s_ar_id; rd_addr_q <= s_ar_addr; rd_left_q <= {1'b0, s_ar_len} + 9'd1;
        rd_perr_q <= (s_ar_size != 3'd3) || (s_ar_burst != 2'b01);
      end
      // ---- read beat issued to the memory
      if (g_rd) begin
        rd_pend_q <= 1'b1; rd_last_q <= (rd_left_q == 9'd1);
        rd_addr_q <= rd_addr_q + 32'd8; rd_left_q <= rd_left_q - 9'd1;
      end
      // ---- read data returns from the memory
      if (rd_pend_q) begin
        s_r_valid <= 1'b1; s_r_id <= rd_id_q; s_r_data <= mem_q; s_r_resp <= 2'b00; s_r_last <= rd_last_q;
        rd_pend_q <= 1'b0;
        if (rd_last_q) rd_active_q <= 1'b0;
      end
      // ---- errored read beat (no memory access)
      if (rd_free && rd_beat_err) begin
        s_r_valid <= 1'b1; s_r_id <= rd_id_q; s_r_data <= 64'd0; s_r_resp <= 2'b10; s_r_last <= (rd_left_q == 9'd1);
        rd_addr_q <= rd_addr_q + 32'd8; rd_left_q <= rd_left_q - 9'd1; axi_err_ev <= 1'b1;
        if (rd_left_q == 9'd1) rd_active_q <= 1'b0;
      end
      if (s_r_valid && s_r_ready) s_r_valid <= 1'b0;

      // ---- write address
      if (s_aw_valid && s_aw_ready) begin
        wr_active_q <= 1'b1; wr_id_q <= s_aw_id; wr_addr_q <= s_aw_addr; wr_err_q <= 1'b0;
        wr_perr_q <= (s_aw_size != 3'd3) || (s_aw_burst != 2'b01);
      end
      // ---- write data beat accepted
      if (s_w_valid && s_w_ready) begin
        wr_addr_q <= wr_addr_q + 32'd8;
        if (wr_beat_err) begin wr_err_q <= 1'b1; axi_err_ev <= 1'b1; end
        if (s_w_last) begin
          wr_active_q <= 1'b0; s_b_valid <= 1'b1; s_b_id <= wr_id_q;
          s_b_resp <= (wr_err_q || wr_beat_err) ? 2'b10 : 2'b00;
        end
      end
      if (s_b_valid && s_b_ready) s_b_valid <= 1'b0;
    end
  end
  // AWLEN is not used: a write burst ends with WLAST (the master is trusted to be consistent; a protocol check is future work)
  wire unused_ok = ^{s_ar_addr[2:0], s_aw_addr[2:0], s_aw_len, c_addr[31:AW64+3], c_addr[1:0]};
endmodule
`default_nettype wire
