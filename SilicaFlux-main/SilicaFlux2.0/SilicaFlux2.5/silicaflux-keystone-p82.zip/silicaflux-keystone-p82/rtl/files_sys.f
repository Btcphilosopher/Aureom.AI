# Keystone simulation system: control subsystem + CloudDMA (real) + models
-f rtl/files.f
-Ithird_party/silicaflux-clouddma-p64/rtl
third_party/silicaflux-clouddma-p64/rtl/silicaflux_dma_pkg.sv
third_party/silicaflux-clouddma-p64/third_party/p61-clouddpu/rtl/sfd_fifo.sv
third_party/silicaflux-clouddma-p64/third_party/p61-clouddpu/rtl/sfd_rr_arb.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_burst_plan.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_bytebuf.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_crc.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_perm_table.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_perm_checker.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_desc_walker.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_burst_ctrl.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_channel.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_perf.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_trace.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_csr.sv
third_party/silicaflux-clouddma-p64/rtl/sfdma_axi_mux.sv
third_party/silicaflux-clouddma-p64/rtl/silicaflux_cloud_dma.sv
rtl/albion/sf_keystone_dma_glue.sv
rtl/albion/sf_keystone_engmodel.sv
rtl/albion/sf_keystone_albion_sys.sv
