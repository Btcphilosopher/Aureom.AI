# 05 — Timing

Cycle *t* is the clock period that ends with rising edge *t*. Every number in this document is **measured** in RTL
simulation (`tb/tb_hpc_dma_adapter.sv +test=trace` and `+test=perf`, idle system, 1-cycle slaves); the raw traces are
in `reports/cycles.md`. No clock frequency is claimed (doc 07).

## 1. Baseline (ENGINE = 0), external → scratchpad, 8 bytes (2 beats), measured trace

`ctl`: 0 IDLE, 1 CHECK, 2 RUN. `eng`: 0 IDLE, 1 VALIDATE, 2 ISSUE_READ, 3 WAIT_READ, 4 ISSUE_WRITE, 5 WAIT_WRITE,
6 COMPLETE. `fab_req` / `spm_req` = `{valid, ready, write}`.

| Cycle | Descriptor | ctl | eng | Fabric (MEM0, `sfb_sram_slave`) | Scratchpad (Module 04, RL 1) | Completion |
|---|---|---|---|---|---|---|
| 5 | `cmd_valid && cmd_ready` → **accepted at edge 5** | IDLE | IDLE | | | |
| 6 | in descriptor queue; `busy = 1`; taken at edge 6 | IDLE | IDLE | | | |
| 7 | latched; validation + REGION check; `start` | CHECK | IDLE | | | |
| 8 | | RUN | VALIDATE | | | |
| 9 | | RUN | ISSUE_READ | read beat 0 **accepted (edge 9)** | | |
| 10 | | RUN | WAIT_READ | read response | | |
| 11 | | RUN | ISSUE_WRITE | | write beat 0 accepted, **committed at edge 11** | |
| 12 | | RUN | WAIT_WRITE | | write acknowledgement (RL 1) | |
| 13–16 | | RUN | beat 1: 2, 3, 4, 5 | read 13, response 14 | write committed 15, ack 16 | |
| 17 | | RUN | COMPLETE | | | record pushed at edge 17 |
| 18 | `busy = 0` | IDLE | IDLE | | | **`cpl_valid = 1`** |

Scratchpad → external is the mirror image (read on the scratchpad, write on the fabric; same cycle numbers).
A descriptor queued behind another starts its CHECK two cycles after the previous record was pushed (trace 3 in
`reports/cycles.md`: COMPLETE in cycle 49, next CHECK in 51, its first request in 53).

## 2. Latency formulas (baseline, measured; RL = scratchpad READ_LATENCY, L = external slave latency)

| Quantity | Value | Composition |
|---|---|---|
| descriptor accept → first bus request | **4 cycles** | queue → IDLE (1) → CHECK (1) → engine VALIDATE (1) → request registered (1) |
| per beat, ext ↔ SPM | **2 + L + RL cycles** (4 with L = RL = 1) | issue read, wait L, issue write, wait RL (each issue takes the accept cycle) |
| last write acknowledgement → `cpl_valid` | **2 cycles** | engine COMPLETE (1), record visible (1) |
| total, *n* beats | **4 + n·(2 + L + RL) + 1** cycles from the accept edge to the first edge at which the record can be consumed | 9 cycles for 1 beat, 4101 for 4096 B (`reports/cycles.md`) |
| back-to-back descriptors | +5 cycles between the last acknowledgement of one and the first request of the next | COMPLETE, IDLE, CHECK, VALIDATE, request |
| fabric register slice (`FAB_SLICE = 1`) | +2 cycles per fabric transaction | one cycle per sliced direction (`sfb_reg_slice`) |

Measured steady-state cost per beat (`reports/cycles.md`, difference method): 4.00 cycles (RL 1), 5.00 (RL 2),
6.00 with the fabric slice on ext ↔ SPM, 8.00 ext → ext through two slices.

## 3. Buffered engine (ENGINE = 1)

* Same 4-cycle descriptor → first request latency and 2-cycle acknowledgement → record latency (measured).
* **Dual port**: one beat per cycle in every direction once the pipeline is full (measured 1.00 cycle/beat; 3.98
  B/cycle at DW = 32, 7.92 B/cycle at DW = 64 for 6 KiB transfers, fixed costs included).
* **Single port**: READ and WRITE phases of up to `BURST` beats; the phase changes only when nothing is
  outstanding, so each phase pays a pipeline drain. Measured 2.50 cycles/beat with `BURST = 8`, `MAX_OUT = 2`.
* **`MAX_OUT` versus latency.** The reused engine registers `req_valid`, so with `MAX_OUT = 1` a request follows the
  previous response one cycle later (measured: single port, RL 1: 4.25 cycles/beat; dual port, RL 3: 4.00). Full rate to a
  target of response latency *R* needs **`MAX_OUT ≥ R + 1`**: dual port, RL 3 — 4.00 cycles/beat with `MAX_OUT = 1`,
  1.00 with `MAX_OUT = 4`.
* The fabric side never benefits from `MAX_OUT > 1` behind `sfb_crossbar` rev 2.0 (one outstanding per port), except
  through the register slice (one more in flight).

## 4. Interface timing of the adapter

| Path | Type |
|---|---|
| `cmd_ready` | register function (queue count / FSM state); independent of `cmd_valid` |
| `cpl_valid`, `cpl_*` | register outputs (queue head) |
| `fab_req_valid` / `spm_req_valid` | engine register **AND** router hold condition; the hold condition depends combinationally on the owning target's `rsp_valid` (a response retiring this cycle frees its slot — same rule as `sfb_crossbar`) |
| `fab_req_ready` → engine | combinational through the router (target ready AND not held) |
| scratchpad `req_ready` | combinational in the scratchpad (grant, Module 04 H3) → through the router to the engine |
| responses → engine | combinational through the router (owner mux) and the scratchpad adapter (tag compare) |
| `rsp_ready` → targets | constant / registered in the engines, gated by ownership |
| `FAB_SLICE = 1` | registers valid, data and ready of both fabric channels (cuts the adapter ↔ crossbar path) |

No combinational loop exists: every target's `rsp_valid` is registered relative to its own request (SFB2 R5,
Module 04 READ_LATENCY ≥ 1), and the engines register `req_valid` (SFB2 R3). Verilator reports no `UNOPTFLAT`
(combinational loop) warning in any simulation build of any configuration (`build/vl/*/build.log`).
