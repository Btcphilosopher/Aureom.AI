# 00 — Repository audit and reuse decisions

Repository: `btcphilosopher/Aureom.AI`, branch `claude/practical-ritchie-84qkxu` (HEAD `ec432be`). The SilicaFlux
material lives in `SilicaFlux-main/` as archives (`.zip`, `.tar.gz`) and loose `.sf` files. Every archive used below
was extracted into a scratch directory and read; **nothing in the repository was modified** and nothing was committed.

## 1. What exists (the brief's audit list)

| Brief item | Found | Where | Verdict for Module 05 |
|---|---|---|---|
| **Existing DMA RTL** | yes | DataFabric `rtl/dma/`: `silicaflux_dma` (register block + IRQ) around two engines with an identical control contract — `dma_transfer_engine` (simple: one transaction in flight, 4 cycles/word) and `dma_burst_engine` (buffered: `FIFO_DEPTH`, `BURST`, `MAX_OUT`, single or dual port) — plus `dma_validate` and `dma_fifo` | **Reused unmodified.** A DMA engine exists, so no reference engine was written; the adapter instantiates the engine directly through its `start/abort/cfg → busy/done/fail/err/bytes_done` contract and adds what the tile needs (section 2) |
| **DataFabric** | yes | DataFabric `rtl/interconnect/`: `sfb_crossbar` (per-master decoder + access matrix + error slave, per-slave arbiter with grant lock, response router), `sfb_reg_slice`, `sfb_v1_slave_adapter`; SoC `rtl/soc/sfv_soc_df.sv` | The adapter is a crossbar **master** (one port, two for the dual-port engine). The crossbar is used unmodified in both testbenches |
| **Bus protocol** | yes — **SFB2, not AXI** | DataFabric `docs/datafabric/PROTOCOL.md` (vendored): valid/ready request (`req_write/addr/wdata/wstrb`), valid/ready response (`rsp_rdata/error`), one beat per transaction, **no native bursts, no IDs, at most one outstanding transaction per crossbar port (rev 2.0)**, write response only after the write was performed (R7), error responses carry zero data (R8), DW-aligned addresses (R9) | Every port of the adapter that touches the fabric speaks SFB2 exactly. No AXI concept (bursts, 4 KiB boundaries, IDs, WLAST, B channel) was introduced: SFB2 has no burst-boundary rule to enforce, and a "burst" is a sequence of single-beat transactions (R10) |
| **SRAM wrappers** | yes | SRAM Wrapper Library (`sram_sp`, `sram_rsp_path`, raw backends GENERIC / FPGA / ASIC); DataFabric `sfb_sram_slave` puts an SFB2 slave on `sram_sp` | External memory in both testbenches is the real `sfb_sram_slave` (plus, in the unit TB, a fault-injecting SFB2 slave model) |
| **Tile local memory** | yes | Module 04 `hpc_scratchpad`: N ready/valid ports with **tags**, banked, per-bank RR arbitration, in-order tagged responses with back-pressure, write acknowledgement after commit (`WRITE_ACK = 1`), RANGE / ALIGN / STROBE / PARITY error codes | The adapter drives one scratchpad port per engine port through `hpc_dma_spm_port` (SFB2 → scratchpad protocol). Module 04 doc 08 §3 lists exactly this wrapper as its first open item |
| **Address decoder** | yes (two) | crossbar `sfb_addr_decoder` (mask decode, access matrix, alignment); scratchpad `hpc_spm_addr_map` (window + bank/row) | The adapter needs a third, tiny decode — scratchpad window vs. everything else — in `hpc_dma_route`; legality of external addresses stays with the crossbar decoder (decode error), legality of scratchpad addresses with the scratchpad (RANGE) |
| **Memory map** | yes | DataFabric `memmap/silicaflux_v_datafabric.yaml` → `MEMORY_MAP.md` (vendored): SRAM banks `0x1000_0000…0x1001_FFFF`, **TSPM (tile scratchpad) `0x2000_0000`**, peripherals `0x4000_0000` (DMA denied by the access matrix) | `SPM_BASE` defaults to the TSPM base, so the scratchpad keeps the address software already uses |
| **Clock / reset domains** | one each | DataFabric ARCHITECTURE.md §3: one functional clock for fabric, DMA, SRAM; asynchronous assert / synchronous release (`sfv_rst_sync`) in the shared `sys_rst_n`, the precondition of SFB2 R11 | The adapter adds **no clock domain and no CDC**; it is in the same clock and reset as the fabric and the scratchpad (doc 03 §8) |
| **Hardware verification** | yes | DataFabric `tb/dma/tb_dma.sv` (expected-memory model, write monitor), `sfb_protocol_checker`, formal (crossbar unbounded, DMA bounded); Module 04 testbench with array backdoor and mutation testing | Protocol checker reused unmodified on every SFB2 link; the backdoor and mutation techniques of Module 04 reused in the new testbenches |
| **Compute consumer** | yes, stream-only | Module 03 `hpc_vector_array` (N × Module 02 lanes): command / operand-beat / result-beat / completion valid/ready interfaces; README: "no VRF reader or DMA adapter is included" | Used unmodified in the integration test. Because it has no memory port, a minimal reference sequencer `hpc_tile_vseq` (scratchpad ↔ array) was written for the test (doc 08 §2) |

Not found: a register front end for an HPC tile, a VRF / vector load-store unit, any multiple-outstanding SFB2
extension (planned in PROTOCOL.md §8, not implemented), any second clock domain.

## 2. Reuse decisions

| Need | Decision | Why |
|---|---|---|
| Moving data, byte-accurate lengths, tails, validation, abort, error capture, "done only after the last write response" | **Reused unmodified**: `dma_transfer_engine` (baseline, `ENGINE = 0`) and `dma_burst_engine` (`ENGINE = 1`) with `dma_validate` | Verified (DataFabric unit / formal / GLS / SoC firmware), already implements the brief's §3–§4 semantics on SFB2; re-implementing it would duplicate the production candidate |
| Register block (`dma_control_regs`) | **Not used** | The tile-side interface is a descriptor stream with tags and a completion stream; the existing block is single-descriptor, untagged and refuses writes while busy. A register front end for host firmware is listed in doc 08 §3 |
| Two address spaces behind one engine port | **New** `hpc_dma_route` | Nothing existing routes one SFB2 master to a scratchpad port *and* a crossbar port with response ownership |
| SFB2 → scratchpad port | **New** `hpc_dma_spm_port` (wires + tag/ownership check) | Module 04 doc 08 §3 item 1 |
| Descriptor and completion queues | **Reused unmodified**: DataFabric `dma_fifo` | verified FWFT FIFO, push/pop-under-credit contract |
| Fabric timing slice | **Reused unmodified**: `sfb_reg_slice` (`FAB_SLICE = 1`) | PROTOCOL.md §7: legal for masters that track their own outstanding count (the router does) |
| Performance counters | **New** `hpc_dma_perf` (saturating, counter map in `hpc_dma_defs.svh`) | brief §6 events are not all available from the engine (bytes committed, outstanding, response wait) |
| Integration consumer | **New, reference only** `hpc_tile_vseq` | Module 03 has no memory port |
| Verification IP | **Reused**: `sfb_protocol_checker`, `sfb_crossbar`, `sfb_sram_slave`, `hpc_scratchpad` as real components; **new** testbenches | real components wherever they exist, so integration behaviour (arbitration, back-pressure, latencies) is the silicon behaviour, not a model's |

All reused files are byte-identical to their archives (`third_party/SHA256SUMS`, `third_party/PROVENANCE.md`).

## 3. Tools in this environment

Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33, Python 3.13 with numpy (installed from Ubuntu packages for this
work — the same versions the DataFabric and Module 04 reports were produced with). **Not available:** SymbiYosys,
a PDK / Liberty flow, OpenROAD, vendor FPGA tools. Consequences: no formal proof of the new RTL (the reused engines and
crossbar carry DataFabric's proofs), no timing / area claims (doc 07 and `reports/synth.md` give logic-size
indications only).
