# 08 — Integration in the compute tile and the SoC, open items

## 1. Connecting the adapter

```
                         SilicaFlux-HPC compute tile
   +-------------------------------------------------------------------------------+
   |  vector array (Module 03) <-> load/store unit (future; hpc_tile_vseq in tests)  |
   |                                   | scratchpad ports 0 .. L-1                   |
   |                                   v                                             |
   |                     hpc_scratchpad (Module 04) 0x2000_0000                      |
   |                                   ^ port L (+L+1 for the dual-port engine)      |
   |                                   |                                             |
   |   descriptors / completions --> hpc_dma_adapter (Module 05)                     |
   +----------------------------------------|--------------------------------------+
                                            | SFB2 master port(s)
                                            v
                      sfb_crossbar (DataFabric): SRAM banks, ROM, ... ; host CPU masters
```

* **Scratchpad.** One `hpc_scratchpad` port per engine port; `DATA_WIDTH = DW`, `ADDR_WIDTH = 32`,
  `BASE_ADDR = SPM_BASE`, `CAPACITY_BYTES = SPM_BYTES`, `TAG_W = SPM_TAG_W`, and **`WRITE_ACK = 1`** (required:
  completion is built on write acknowledgements). Any bank count, map, port model, read latency or request queue is
  supported (verified with 1, 2, 4, 8 banks; 1RW, 1R1W, 2RW; RL 1–3; queue 0–4; byte parity). `RSP_FIFO_DEPTH` default
  (RL + 1) is enough: the adapter never back-pressures responses.
* **Fabric.** Each fabric port is one `sfb_crossbar` master port (in `sfv_soc_df` the DataFabric DMA is master 3; the
  adapter can take that slot, or a new one). Keep the access matrix denying the peripheral window to the DMA master
  (MMIO side effects not reviewed — same reason as DataFabric). The crossbar's TSPM slave port is not needed for DMA
  traffic: the adapter decodes the scratchpad window itself.
* **Clock / reset.** The SoC functional clock and `sys_rst_n` (asynchronous assert, synchronous release by
  `sfv_rst_sync`), shared with the crossbar and the scratchpad (SFB2 R11).
* **Control.** The descriptor / completion streams are meant for a tile sequencer or a register front end (§3).

## 2. The integration sequencer `hpc_tile_vseq`

Module 03 deliberately has no memory port. `hpc_tile_vseq` is a minimal, serial, synthesizable reference that loads
operand words from the scratchpad, presents operand beats, stores result beats and waits for write acknowledgements
— enough for the integration test to prove the data path end to end and to create real vector-versus-DMA bank
contention. It is about 25 times slower than the array itself (measured: FMADD on 1 000 elements in about 6 250
cycles with 4 lanes, against the array's ⌈vl/N⌉ = 250) and is **not** a proposal for the production load/store unit.

## 3. Open items and prioritised next actions

1. **Register front end** for host firmware (the DataFabric `dma_control_regs` style: SRC / DST / LENGTH / TAG /
   CONTROL / STATUS / completion pop / INT_ENABLE / INT_STATUS / counters on a peripheral page), plus a firmware test
   on the SilicaFlux-V CPU like DataFabric's D8 scenario.
2. **Formal**: bounded proofs of the router (ownership, hold, MAX_OUT) and of the adapter's queue reservation, with
   yosys-smtbmc as DataFabric did (SymbiYosys was not available here).
3. **Vector load/store unit** that streams N words per cycle from N scratchpad ports into Module 03 (replacing
   `hpc_tile_vseq`); measured target: the dual-port DMA already supplies one word per cycle.
4. **Multiple channels / descriptor chaining** if workloads need DMA-in and DMA-out of different tiles in flight at
   the same time (today: one channel, queued descriptors).
5. **Unaligned source / destination** (byte-shifting datapath) — currently rejected, as in the DataFabric DMA.
6. **SFB2 rev 2.1 (IDs, multiple outstanding per crossbar port)** — PROTOCOL.md §8; the router already supports
   `MAX_OUT` per port and the scratchpad tags are already checked, so the adapter side is ready.
7. **Gate-level simulation and timing** of the adapter in the SilicaFlux flow (`FAB_SLICE = 1` is the timing option
   for the adapter ↔ crossbar path).
