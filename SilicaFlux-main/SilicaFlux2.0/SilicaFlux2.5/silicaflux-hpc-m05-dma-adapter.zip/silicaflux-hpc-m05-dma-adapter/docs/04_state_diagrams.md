# 04 — Transfer state diagrams

State encodings are those visible on the status outputs: `ctl_state` = `HPC_DMA_AST_*` (`rtl/hpc_dma_defs.svh`),
`eng_state` = `DMA_ST_*` (DataFabric `dma_defs.svh`).

## 1. Adapter control FSM (`hpc_dma_adapter`)

```
                    desc available && completion slot free
          +-------+ (pop / latch src dst len tag)            +-------+
  reset ->| IDLE  |----------------------------------------->| CHECK |  dma_validate(d_*) and REGION rule
          |  (0)  |<---------+                               |  (1)  |  evaluated combinationally this cycle
          +-------+          |                               +-------+
              ^              | REGION violation               |   |
              |              | (rules 1-7 passed):            |   | otherwise: start = 1
              |              | push {tag, err, 11,            |   | (engine samples it in its IDLE state;
              |              |  boundary, 0}                  |   |  rules 1-7 failures are reported by the
              |              +--------------------------------+   |  engine in its VALIDATE state)
              |                                                   v
              |   engine done || fail:                         +-------+
              +------------------------------------------------|  RUN  |  cmd_abort -> engine abort
                  push {tag, fail, code, err_addr, bytes}      |  (2)  |
                                                               +-------+
```

* `busy = (ctl_state != IDLE) || descriptor queue not empty`.
* The completion push happens in the engine's terminal cycle; the engine returns to IDLE on the same edge as the
  adapter, so the next descriptor's `start` (CHECK, at the earliest one cycle later) always finds the engine idle.
* Per descriptor the adapter adds 2 cycles before the engine (IDLE→CHECK, CHECK→RUN), measured in doc 05.

## 2. Simple engine (`dma_transfer_engine`, DataFabric, unmodified) — ENGINE = 0

```
 IDLE --start--> VALIDATE --ok--> ISSUE_READ --accept--> WAIT_READ --rsp ok--> ISSUE_WRITE
  (0)              (1) |  bad       (2)  ^                 (3)  | rsp err        (4)  | accept
   ^                   v                 |                      v                     v
   +------ ERROR (7) <-+-----------------+--(abort at beat)-- ERROR (7)          WAIT_WRITE (5)
   +------ COMPLETE (6) <--- last beat written OK --------------------------------- | rsp ok
                                         next beat: ISSUE_READ <-------------------+ (rsp err -> ERROR)
```

One transaction outstanding at any time; request outputs registered and held until accepted; `rsp_ready` = 1 in
the two WAIT states. A write is issued only with data from an error-free read of the same beat; its strobe masks the
bytes beyond `len` on the last beat.

## 3. Buffered engine (`dma_burst_engine`, DataFabric, unmodified) — ENGINE = 1

```
 S_IDLE --start--> S_VAL --bad / abort--> S_END (err) --> S_IDLE
                     | ok
                     v
                   S_RUN : read issuer and write issuer run concurrently around dma_fifo
                     |      can_rd = !rd_stop && reads < total && reads-writes < FIFO_DEPTH && rd_out < MAX_OUT
                     |      can_wr = !wr_stop && writes < limit && fifo not empty && wr_out < MAX_OUT
                     |      single port: phase READ (<= BURST reads) <-> phase WRITE (<= BURST writes),
                     |                   phase changes only when nothing is outstanding
                     |      dual port  : port 0 reads, port 1 writes, both every cycle
                     |      errors / abort: stop issuing, drain every outstanding response
                     | finished = nothing presented, nothing outstanding, no further beat can be written
                     v
                   S_END (done or fail decoded) --> S_IDLE
```

`eng_state` maps S_RUN to ISSUE_READ / ISSUE_WRITE (phase), S_END to COMPLETE / ERROR.

## 4. Router ownership state (`hpc_dma_route`, one per engine port)

```
            req to T accepted                     req to T accepted (cnt < MAX_OUT)
  +-----------+ --------------> +------------------+ -------+
  |  cnt = 0  |                 |  cnt = n, tgt = T |<-------+
  | (no owner)| <-------------- |  responses only   |
  +-----------+  last response  |  from T           |----+ request to the other target:
                 accepted       +------------------+    | HELD (req_ready = 0, nothing presented)
                                         ^              | until cnt reaches 0 (a response retiring
                                         +--------------+ in the same cycle counts)
```

## 5. Scratchpad port tag counters (`hpc_dma_spm_port`)

```
 iss_seq: +1 on every accepted request; request tag = {write, iss_seq}
 rsp_seq: +1 on every accepted response; expected tag = {rsp_we, rsp_seq}
 mismatch -> rsp_error = 1, rsp_rdata = 0, ev_tag_err
```

## 6. Descriptor life cycle (whole adapter)

```
 cmd handshake --> descriptor queue --> CHECK --> engine VALIDATE --> beats (reads / writes, acknowledgements)
       |                (CMD_DEPTH)       |  REGION             |
       |                                  +--> completion       +--> terminal state --> completion queue --> cpl handshake
       +-- reset at any point: dropped, no completion                                    (CPL_DEPTH)
```

## 7. Integration sequencer (`hpc_tile_vseq`, reference only)

```
 IDLE --job--> CMD --cmd_ready--> LOAD (operand words a/b/c of beat g, one request per cycle, tagged {0,operand,lane})
                 \ vl = 0                |  all issued and answered
                  \                      v
                   \                    OPND --opnd_ready--> RES --res_valid--> STORE (res_mask'ed words, tagged
                    \                                                            {1,-,lane}; wait every write ack)
                     \                                                              | more beats: g+1 -> LOAD
                      +----------------------------------------------> CPL <-------+ last beat
                                                                         | cpl_valid
                                                                       DONE --done_ready--> IDLE
```
