# 02 — Address spaces of the implemented system

The adapter sees a single 32-bit byte-address space, little-endian, split into exactly **two** spaces. There is no
address translation, no aliasing and no third space.

## 1. The two spaces

| Space | Addresses | Reached through | Legality decided by | Error when illegal |
|---|---|---|---|---|
| **SPM** — tile scratchpad (Module 04) | `[SPM_BASE, SPM_BASE + SPM_BYTES)`, default `0x2000_0000 … 0x2000_FFFF` (64 KiB) | `hpc_dma_spm_port` → `hpc_scratchpad` requester port, **never** through the fabric | the window decode in `hpc_dma_route` (an aligned power-of-two window: all upper address bits compared, so no alias) and the scratchpad's own range check | cannot occur for an accepted descriptor (REGION rule); a scratchpad PARITY error on a read gives READ_BUS |
| **External / host-visible** | every other address | `fab_req_*` → DataFabric `sfb_crossbar` master port | the crossbar decoder and access matrix (SoC memory map) | decode error → READ_BUS / WRITE_BUS with the failing address, no side effect (SFB2 R8) |

The decode is `sel_fab = (addr[31:log2(SPM_BYTES)] != SPM_BASE[31:log2(SPM_BYTES)])` — one comparator, no table.
The adapter does **not** know which external addresses exist: that is the fabric's job, exactly as for the
DataFabric DMA (DMA.md §2 "Region legality is not known to the DMA").

## 2. Region rule (validated before any bus access)

A descriptor's source range `[src, src+len)` and destination range `[dst, dst+len)` must each lie **entirely in one
space**. A range that starts in one space and ends in the other is rejected with `REGION` (code 11) and
`cpl_err_addr` = the boundary it crosses (`SPM_BASE` when it enters the window from below, `SPM_BASE + SPM_BYTES`
when it leaves it). Reasons:

* a single beat never has to be split between two targets (SFB2 has no transaction splitting, the engines issue whole
  DW words);
* the scratchpad window is not adjacent to memory in the SoC map (TSPM is followed by unmapped space), so such a
  transfer could only end in a bus error half way;
* the router's ownership logic would have to hold at the boundary (it does — doc 03 §6 — but a well-formed transfer
  never needs it).

The rule is applied only after the engine's rules 1–7 pass (doc 01 §5), so existing DataFabric error codes keep
their priority.

## 3. Directions

| Direction | Source space | Destination space | Engine ports used |
|---|---|---|---|
| external → SPM | external | SPM | read: fabric; write: scratchpad |
| SPM → external | SPM | external | read: scratchpad; write: fabric |
| SPM → SPM | SPM | SPM | both on the scratchpad (dual port: two scratchpad ports) |
| external → external | external | external | both on the fabric (the DataFabric DMA's case; allowed, not the adapter's purpose) |

All four are verified (doc 06). SPM → SPM is meaningful for re-layout inside the tile (e.g. gathering a result block
next to its operands) without crossing the fabric.

## 4. The SoC map this connects to (DataFabric `MEMORY_MAP.md`, vendored)

| Region | Base | Size | Notes for the adapter |
|---|---|---|---|
| BOOT_ROM | `0x0000_0000` | 4 KiB | source only (writes are bus errors) |
| SRAM_BANK0..3 | `0x1000_0000` | 4 × 32 KiB | external memory: host-visible operands and results |
| **TSPM** | `0x2000_0000` | 16 KiB in SilicaFlux-V release 1 | the HPC tile scratchpad window; Module 04 notes the size is a one-line YAML change (64 / 128 / 256 KiB). With this adapter the window is decoded by the adapter, so the crossbar's TSPM slave port is not used by the DMA |
| PERIPH | `0x4000_0000` | 128 KiB | denied to the DMA master by the access matrix (decode error) |

The testbenches use this map: the integration test has SRAM_BANK0/1 at `0x1000_0000 / 0x1000_8000` (32 KiB each)
and a 64 KiB scratchpad at `0x2000_0000`; the unit test uses 16 KiB memories at `0x1000_0000`, `0x1001_0000` and
`0x2000_0000`, everything else unmapped (decode error).

## 5. Alignment, partial words, tails

* `src` and `dst` must be DW-aligned (engine rule SRC_ALIGN / DST_ALIGN): there is no byte-shifting datapath, the same
  limitation as the DataFabric DMA version 1.
* `len` is byte-accurate. The last destination word is written with a strobe covering only bytes `< len`, so bytes
  after the end are never modified (checked for every length 1 .. 3·DW/8+1 in every direction, and at the end of a
  12 KiB transfer).
* The last **source** word is read in full (it is inside the same aligned word, hence inside the same space).
* The scratchpad is little-endian with byte lane *k* = address + *k* (Module 04 doc 02), identical to SFB2; no byte
  swapping happens anywhere.
