# 01 — Architecture, parameters and interface

`rtl/hpc_dma_adapter.sv` connects the SilicaFlux-HPC compute tile to the **existing** DataFabric DMA engine, the
DataFabric SFB2 interconnect and the Module 04 scratchpad, so that data moves between external (host-visible)
memory and the tile's local memory without the CPU copying words.

## 1. Block diagram

```
            tile / host control                                    hpc_dma_adapter
 cmd  valid/ready src dst len tag ──► [descriptor queue: dma_fifo, CMD_DEPTH] ─┐
 cmd_abort ───────────────────────────────────────────────────────────┐       │
                                                                       │       ▼
                          ┌── control FSM (IDLE → CHECK → RUN) ◄── dma_validate (reused) + REGION rule
                          │        start / cfg_src / cfg_dst / cfg_len │ abort
                          ▼
     ENGINE = 0 : dma_transfer_engine   (DataFabric, unmodified)  1 transaction in flight
     ENGINE = 1 : dma_burst_engine      (DataFabric, unmodified)  FIFO_DEPTH, BURST, MAX_OUT, DUAL_PORT
                          │ SFB2 master port(s): NP = 1, or 2 (dual port: [0] reads, [1] writes)
          ┌───────────────┴──────────────── per engine port p ─────────────────────────┐
          ▼                                                                             │
   hpc_dma_route  (SPM window → target 0, any other address → target 1;                │
                   ≤ MAX_OUT outstanding, all to ONE target; hold on target switch)    │
          │ target 0 (SFB2)                              │ target 1 (SFB2)              │
          ▼                                              ▼                              │
   hpc_dma_spm_port                               [sfb_reg_slice if FAB_SLICE]          │
   SFB2 → scratchpad port, tag = {write, seq},           │                              │
   ownership check on every response                     │                              │
          ▼                                              ▼                              │
   spm_req_* / spm_rsp_*[p]  ──► hpc_scratchpad     fab_req_* / fab_rsp_*[p] ──► sfb_crossbar master port
          (Module 04 requester port)                    (DataFabric)                    │
                                                                                        │
 cpl  valid/ready tag err code err_addr bytes ◄── [completion queue: dma_fifo, CPL_DEPTH]◄┘
 status: busy active cur_tag ctl_state eng_state eng_bytes_done fifo_level
 events ev_* (one-cycle values)      counters perf_cnt (hpc_dma_perf, 16 x CNT_W, saturating)
```

## 2. Parameters

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `DW` | 32 | 32, 64, 128 | data width of both targets (SFB2 widths); must equal the scratchpad `DATA_WIDTH` and the fabric `DW` |
| `ENGINE` | 0 | 0, 1 | 0 = DataFabric simple engine (baseline, production candidate), 1 = buffered engine |
| `FIFO_DEPTH` | 8 | power of two 2..256 | buffered: data FIFO beats (credit: a read is issued only with a reserved slot) |
| `BURST` | 8 | 1..`FIFO_DEPTH` | buffered, single port: beats per READ / WRITE phase |
| `DUAL_PORT` | 0 | 0, 1 | buffered: separate read port and write port (two scratchpad ports, two fabric ports) |
| `MAX_OUT` | 2 | 1..16 | buffered: requests outstanding per port (the simple engine always has 1) |
| `MAX_LEN_LOG2` | 24 | 1..31 | maximum length 2^MAX_LEN_LOG2 bytes (DataFabric rule `LENGTH`) |
| `SPM_BASE` | `0x2000_0000` | aligned to `SPM_BYTES` | scratchpad window base (DataFabric TSPM) = scratchpad `BASE_ADDR` |
| `SPM_BYTES` | 65536 | power of two ≥ 2 words | scratchpad window size = scratchpad `CAPACITY_BYTES` |
| `SPM_TAG_W` | 8 | 2..32, 2^(SPM_TAG_W−1) > outstanding | = scratchpad `TAG_W` |
| `CMD_DEPTH` | 2 | 0, 2, 4, 8, 16 | descriptor queue (0: `cmd_ready` only when idle) |
| `CPL_DEPTH` | 2 | 2, 4, 8, 16 | completion queue |
| `TAG_W` | 8 | 1..32 | descriptor tag width |
| `FAB_SLICE` | 0 | 0, 1 | `sfb_reg_slice` (request + response) on each fabric port: cuts the long combinational path into the crossbar, +2 cycles per fabric transaction |
| `PERF_EN`, `CNT_W` | 1, 32 | 0/1, 8..64 | performance counters |

Every illegal value stops elaboration with a message from `hpc_dma_adapter` itself; the datapath is elaborated only
for a legal configuration (16 negative elaboration tests, Verilator and Icarus: `reports/lint.md`).

## 3. Ports

Flat vectors (engine port *p* uses slice *p*), following the SilicaFlux RTL coding rules (no interfaces, structs or
package imports in synthesizable RTL).

| Group | Signal | Width | Dir | Meaning |
|---|---|---|---|---|
| descriptor | `cmd_valid` / `cmd_ready` | 1 | in / out | descriptor handshake (`cmd_ready` is a register function: queue not full) |
| | `cmd_src`, `cmd_dst` | 32 | in | byte addresses (DW-aligned) |
| | `cmd_len` | 32 | in | length in **bytes** (1 .. 2^MAX_LEN_LOG2) |
| | `cmd_tag` | `TAG_W` | in | transaction tag, returned with the completion |
| | `cmd_abort` | 1 | in | stop the **active** transfer at the next beat boundary (ignored when none is active) |
| completion | `cpl_valid` / `cpl_ready` | 1 | out / in | one record per accepted descriptor, in descriptor order |
| | `cpl_tag` | `TAG_W` | out | the descriptor's tag |
| | `cpl_err`, `cpl_code` | 1, 4 | out | `cpl_code != 0`; codes in §5 |
| | `cpl_err_addr` | 32 | out | failing bus address (READ_BUS / WRITE_BUS) or crossed window boundary (REGION); 0 otherwise |
| | `cpl_bytes` | 32 | out | bytes written **and acknowledged** — a contiguous prefix of the transfer |
| status | `busy` | 1 | out | a descriptor is queued or in progress (completions waiting in the queue do not count) |
| | `active` | 1 | out | the engine is executing a transfer |
| | `cur_tag`, `ctl_state`, `eng_state` | | out | tag in progress; adapter FSM (`HPC_DMA_AST_*`); engine FSM (`DMA_ST_*`, DataFabric encoding) |
| | `eng_bytes_done`, `fifo_level` | 32, 8 | out | live acknowledged bytes; buffered-engine FIFO occupancy |
| scratchpad | `spm_req_valid/ready/we/addr/wdata/wstrb/tag` | NP × … | out/in | Module 04 requester port protocol |
| | `spm_rsp_valid/ready/rdata/err/err_code/we/tag` | NP × … | in/out | |
| fabric | `fab_req_valid/ready/write/addr/wdata/wstrb` | NP × … | out/in | SFB2 master (crossbar master port) |
| | `fab_rsp_valid/ready/rdata/error` | NP × … | in/out | |
| events | `ev_cmd_accept`, `ev_start`, `ev_cpl`, `ev_cpl_err` | 1 | out | descriptor accepted / started / completion produced / … with error |
| | `ev_bytes_rd`, `ev_bytes_wr` | 8 | out | bytes read / committed this cycle |
| | `ev_req_stall`, `ev_outstanding`, `ev_bus_err`, `ev_tag_err` | 1, 8, 1, 1 | out | doc 07 |
| counters | `perf_clear`, `perf_cnt` | 1, 16·CNT_W | in, out | doc 07 |

## 4. Handshake rules

| # | Rule |
|---|---|
| A1 | Descriptor transfers at an edge with `cmd_valid && cmd_ready`; completion with `cpl_valid && cpl_ready`. The producer holds `cmd_*` stable until accepted. |
| A2 | `cmd_ready` never depends combinationally on `cmd_valid` (queue count, or FSM state when `CMD_DEPTH = 0`). `cpl_valid` is a register function (queue not empty). |
| A3 | Exactly one completion per accepted descriptor, in acceptance order, carrying its tag. Descriptors execute one at a time (single channel). |
| A4 | A descriptor is started only when a completion slot is free: a stalled completion consumer back-pressures `cmd_ready` and never blocks the engine in the middle of a transfer. |
| A5 | Fabric ports obey SFB2 R1–R12 as a master (checked by `sfb_protocol_checker` on every link in both testbenches). Scratchpad ports obey Module 04 H1–H7 as a requester. |
| A6 | Reset (asynchronous assert): queued and active descriptors and completion records are discarded; no request is presented in reset or afterwards until a new descriptor arrives. |

## 5. Completion codes

| Code | Name | Cause | Bus access |
|---|---|---|---|
| 0 | NONE | every write acknowledged OK | — |
| 1 | ZERO_LENGTH | `len == 0` | none |
| 2 | LENGTH | `len > 2^MAX_LEN_LOG2` | none |
| 3 / 4 | SRC_ALIGN / DST_ALIGN | address not DW-aligned | none |
| 5 / 6 | SRC_OVERFLOW / DST_OVERFLOW | range wraps past 2^32 | none |
| 7 | OVERLAP | source and destination ranges intersect (including src == dst) | none |
| 8 | READ_BUS | a read was answered with an error | stops; `cpl_err_addr` = address |
| 9 | WRITE_BUS | a write was answered with an error | stops; `cpl_err_addr` = address |
| 10 | ABORTED | `cmd_abort` | stops at a beat boundary |
| 11 | REGION (adapter) | a range is neither entirely inside nor entirely outside the scratchpad window | none; `cpl_err_addr` = crossed boundary |

Codes 1–10 are produced by the reused engine with the DataFabric meaning (`dma_defs.svh`); rules 1–7 are checked
first, in that order, then REGION.
