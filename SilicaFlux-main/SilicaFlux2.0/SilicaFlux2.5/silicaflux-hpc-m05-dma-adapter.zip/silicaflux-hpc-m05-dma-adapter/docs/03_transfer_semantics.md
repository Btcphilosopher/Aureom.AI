# 03 — Transfer semantics, buffering, completion, errors, concurrency

## 1. Requests and responses

| Item | Fabric target (SFB2) | Scratchpad target (Module 04 port) |
|---|---|---|
| read request | `req_write = 0`, DW-aligned `req_addr`, one beat | `req_we = 0`, same address, tag `{0, seq}` |
| read response | `rsp_rdata`, `rsp_error` (R8: data 0 on error) | `rsp_rdata`, `rsp_err/err_code`, tag echoed, `rsp_we = 0` |
| write request | `req_write = 1`, `req_wdata`, `req_wstrb` (tail mask on the last beat) | `req_we = 1`, same data / strobe, tag `{1, seq}` |
| write acknowledgement | **always**: one response per write, issued only after the write was performed (R7) | **always** (scratchpad `WRITE_ACK = 1` required): response `READ_LATENCY` cycles after the commit edge |
| back-pressure, request | `req_ready` (crossbar arbitration, slave busy) | `req_ready` (bank arbitration, response credits) |
| back-pressure, response | `rsp_ready` — the engines never apply it (`rsp_ready = 1` whenever a response can arrive) | same |
| outstanding | ≤ 1 per crossbar port (rev 2.0 rule, enforced by the crossbar) | ≤ `MAX_OUT` (router), ≤ scratchpad credits |

Write acknowledgements are therefore available on both targets, and the adapter **uses them**: they are what
completion is built on (§3).

## 2. Buffering

* **ENGINE = 0 (baseline):** one data register (the write-data register of `dma_transfer_engine`); exactly one
  transaction in flight; `READ → wait → WRITE → wait` per beat.
* **ENGINE = 1:** read issuer → `dma_fifo` (`FIFO_DEPTH` beats) → write issuer. **Overflow is prevented by
  construction**: a read is issued only when a FIFO slot is reserved for its data (`reads issued − writes issued <
  FIFO_DEPTH`), so a read response can never find the FIFO full and the response path never stalls. Writes are issued
  only when the FIFO holds data. Measured peak occupancy reaches exactly `FIFO_DEPTH` with a slow destination in
  dual-port mode and exactly `BURST` in single-port mode (the engine alternates READ / WRITE phases of at most
  `BURST` beats) — `buffull` test.
* **Adapter queues:** descriptor queue (`CMD_DEPTH`) and completion queue (`CPL_DEPTH`), both `dma_fifo`;
  `cmd_ready` = queue not full; a descriptor starts only with a free completion slot, so the completion queue can never
  overflow (`cplfull` test, mutant M10 shows the overflow when the reservation is removed).
* **Fabric slice** (`FAB_SLICE = 1`): one request and one response of buffering per fabric port; legal because the
  router counts outstanding requests itself (PROTOCOL.md §7).

SFB2 has **no native bursts and no burst-boundary or page rules** (R10): a "burst" is `BURST` single-beat
transactions issued back to back. No AXI-style 4 KiB rule exists to enforce, and none was invented. The only boundary
in the system is the scratchpad window (doc 02 §2).

## 3. Completion semantics

A completion record with code 0 means: **every write of the transfer has been acknowledged without error by its
target**, and each target acknowledges a write only after performing it. Concretely:

1. The reused engines raise `done` only in their terminal state, entered on the edge on which the **last write
   response** is accepted (simple: `WAIT_WRITE → COMPLETE`; buffered: `finished` requires no request presented, nothing
   outstanding and `wr_rsp == total`). Issuing the final read, or even the final write request, is not enough.
2. The adapter pushes the record in that terminal cycle; `cpl_valid` is visible from the next cycle.
3. Fabric writes: SFB2 R7 — the slave answers after the array write / register side effect.
4. Scratchpad writes: committed at the issue edge, acknowledged `READ_LATENCY` cycles later; a vector-lane read
   issued at any later edge returns the new data (Module 04 doc 01 §6).

So a consumer that waits for `cpl_valid` observes the data in memory. Verified three ways: the TB compares the whole
memory (backdoor) at the moment the record is produced while the fabric slave model performs writes only at its
response handshake with 8–20 cycles of latency (`finalwrite`); the TB counts acknowledged writes per transfer and
requires all of them before the record (`DONE but k/n writes acknowledged` — mutant M19 is killed this way); and the
integration test's vector array reads the DMA'd data right after the completion.

`cpl_bytes` counts bytes whose writes were acknowledged OK, always a contiguous prefix.

## 4. Errors

| Event | Effect |
|---|---|
| descriptor rule 1–7 or REGION | completion with the code, `cpl_bytes = 0`, **no bus access** (TB checks zero requests) |
| read answered with an error | no write for that beat; simple engine: nothing after it; buffered: the beats before it are still written (same final memory) — `READ_BUS`, `cpl_err_addr` = read address |
| write answered with an error | the failing write has no side effect (SFB2 R8 / scratchpad rule); no further request; buffered with `MAX_OUT > 1`: up to `MAX_OUT − 1` later beats may already have been written — `WRITE_BUS`, `cpl_err_addr` = write address, `cpl_bytes` = prefix before it |
| scratchpad response with a wrong tag / direction (misrouted, duplicated, reordered) | converted by `hpc_dma_spm_port` into an error response with zero data → READ_BUS / WRITE_BUS; never written as data (`tagerr` test, mutants M02 / M05) |
| scratchpad PARITY error on a read | READ_BUS (`spmerr` test) |

A transfer always ends; there is no watchdog (as in DataFabric): a target that never answers keeps the transfer
active, visible in `active`, `eng_state` and the `RSP_WAIT` counter.

## 5. Abort

`cmd_abort` (one cycle is enough) is forwarded to the engine only while the adapter is in RUN. The engine stops at the
next beat boundary, after the outstanding transaction's response (it never withdraws a presented request), and
reports `ABORTED` with the acknowledged prefix; if the abort races the final beat and every write completed, the
transfer reports `NONE`. Queued descriptors are not affected. The `abort` test requires `ABORTED` whenever the abort
was sampled while the engine was active with more than `MAX_OUT + 2` beats whose writes were not yet issued (mutant
M14 — abort ignored — is killed by this).

## 6. Response ownership and ordering

Three mechanisms, each verified on its own:

1. **Per target, in order**: SFB2 R5 (crossbar: one outstanding per port, owner register per slave) and Module 04 H5
   (per-port in-order responses).
2. **Across targets — `hpc_dma_route`**: all outstanding requests of an engine port go to one target; a request to the
   other target is held until every outstanding response is accepted. The router unit testbench drives alternating
   targets with a 1-cycle scratchpad and a 4–12-cycle fabric: removing the hold (mutant M24) delivers a fast response
   ahead of a slow one and is caught as wrong data. Responses are only taken from the owning target; an unsolicited
   response is never forwarded and raises `ev_tag_err` (mutant M21).
3. **Scratchpad tags — `hpc_dma_spm_port`**: tag `{write, seq}` checked on every response (mutant M02).

Descriptor ↔ completion association: in order, carrying the tag (mutant M13 is killed by `consec`).

## 7. Concurrency (what the real interconnect permits)

| Resource | Concurrent users | Arbitration | Guarantee |
|---|---|---|---|
| DataFabric crossbar | CPU / host masters, the adapter's fabric port(s) | per slave, round robin with grant lock (DataFabric, proven bounded waiting ≤ N−1) | different slaves in parallel; same slave serialised; one outstanding per port |
| Scratchpad banks | vector lanes (other ports), the adapter's scratchpad port(s) | per bank, round robin (Module 04); 1RW / 1R1W / 2RW port models | different banks in parallel; a lost bank re-arbitrates next cycle with the request held |
| Adapter | one descriptor at a time (single channel); dual-port engine reads and writes concurrently | — | in-order completion |

Prevention of the brief's failure modes:

| Failure | Prevented by | Evidence |
|---|---|---|
| dropped transfer | one completion per descriptor; reserved completion slot; no request withdrawal (R2) | `consec`, `cplfull`, protocol checkers, M10 / M17 |
| duplicate write | engine issues each beat once; TB per-beat write bitmap | monitor in every test |
| response misrouting | §6 | router unit TB, `tagerr`, M02 / M21 / M24 |
| deadlock (supported traffic) | below | watchdog in every test; `contention`, `bp`, integration phase B |
| silent memory corruption | strobes, tags, error responses with no side effect, region rule | byte-exact memory compare after every transfer |

Deadlock freedom (assumption: every accepted request is answered — SFB2 R5 — in finite time):
* the engines accept every response (`rsp_ready = 1` when a response can arrive), so outstanding requests always
  retire, so the router's hold always releases;
* the buffered engine's read side waits only for FIFO credit, released by writes; its write side waits only for FIFO
  data, produced by reads — a one-directional dependency, no cycle;
* the engine never waits for the completion consumer (slot reserved before start);
* crossbar and scratchpad arbitration are round robin (no starvation of the DMA by a busy vector lane or CPU).

Visibility between DMA and vector traffic on the scratchpad: there is **no ordering between different scratchpad
ports** except through issue edges (Module 04 doc 01 §6). Software must not let a vector job and an active DMA
transfer touch the same scratchpad bytes; the DMA completion record is the synchronisation point (the integration
test's double buffering does exactly this).

## 8. Clock and reset

One clock (`clk`) shared with the fabric and the scratchpad; no CDC. Asynchronous active-low reset, synchronous
release by the SoC's `sfv_rst_sync`, shared with the fabric and the scratchpad (SFB2 R11). Effect of reset during a
transfer: queued and active descriptors and pending completion records are discarded; no completion is produced for
them; each beat of the interrupted transfer is either entirely written or not at all; bytes outside `[dst, dst+len)`
are untouched; no request is presented during reset or afterwards until a new descriptor (`reset` test: 30 resets at
random points per run, each followed by a byte-exact memory check and a new transfer).
