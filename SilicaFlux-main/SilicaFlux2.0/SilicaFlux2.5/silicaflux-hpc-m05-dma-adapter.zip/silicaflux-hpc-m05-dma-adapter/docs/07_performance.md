# 07 — Performance events, counters and measured results

## 1. Events (one-cycle values, `ev_*`) and counters (`perf_cnt`)

The counter map is `HPC_DMA_PC_*` in `rtl/hpc_dma_defs.svh`; counter *i* is `perf_cnt[i*CNT_W +: CNT_W]`. Counters
saturate at 2^CNT_W − 1 (never wrap), are cleared by reset or `perf_clear`, and are removed by `PERF_EN = 0`.

| # | Counter | Brief §6 item | Definition |
|---|---|---|---|
| 0 | CYCLES | — | cycles since reset / clear |
| 1 | ACTIVE | **active cycles** | cycles the engine was busy (VALIDATE … terminal state) |
| 2 | BYTES_RD | **bytes read** | DW/8 per error-free read response (the engine reads whole words) |
| 3 | BYTES_WR | **bytes written** | strobe bytes of error-free **write acknowledgements** (bytes committed, not requested) |
| 4 / 5 | READS / WRITES | — | requests accepted, all ports |
| 6 | REQ_STALL | **stall cycles** | cycles in which ≥ 1 engine port presented a request that was not accepted (crossbar arbitration, slave busy, bank conflict, scratchpad credits, router hold) |
| 7 | RSP_WAIT | stall cycles (latency) | cycles with requests outstanding and no response on any port |
| 8 | OUT_SUM | **outstanding requests** | Σ over cycles of the outstanding count — OUT_SUM / (READS + WRITES) is the mean request → response latency (Little's law) |
| 9 | OUT_MAX | outstanding requests | maximum observed |
| 10 / 11 | CPL_OK / CPL_ERR | **completion events / error events** | completion records produced without / with an error code |
| 12 | BUS_ERR | error events | error responses received |
| 13 | TAG_ERR | error events | response-ownership violations (scratchpad tag/type mismatch, unsolicited response) |
| 14 / 15 | SPM_REQ / FAB_REQ | — | requests accepted per target |

Events: `ev_bytes_rd`, `ev_bytes_wr` (per cycle), `ev_req_stall`, `ev_outstanding` (current count), `ev_cmd_accept`,
`ev_start`, `ev_cpl`, `ev_cpl_err`, `ev_bus_err`, `ev_tag_err`. Every counter is cross-checked against the testbench's
own totals at the end of every unit test, and mutants M07 / M08 / M20 show that wrong counting is detected.

## 2. Measured results (RTL simulation cycles; details in `reports/cycles.md` and `reports/integration.md`)

Idle system, 1-cycle slaves, DW = 32 (bytes per cycle for 4 KiB, fixed costs included):

| Engine | ext → SPM | SPM → ext | SPM → SPM | ext → ext | Steady state |
|---|---|---|---|---|---|
| simple (baseline) | 1.00 B/cycle | 1.00 | 1.00 | 1.00 | 4 cycles / beat (2 + L + RL) |
| buffered, single port, BURST 8, MAX_OUT 2 | 1.60 | 1.60 | 1.60 | 1.60 | 2.5 cycles / beat |
| buffered, dual port, MAX_OUT 2 | 3.97 | 3.97 | 3.97 | 3.97 | 1 cycle / beat |
| buffered, dual port, DW = 64 | 7.88 | 7.88 | 7.86 | 7.88 | 1 cycle / beat |

Integration test (4-lane vector array, real SRAM slaves, contention from the vector sequencer and the host):

<!-- BEGIN INTEG_TABLE -->
| Engine | DMA in 3 × 4000 B | DMA out 4000 + 3997 + 4000 B | Phase B total (serialised sum) | Both busy |
|---|---|---|---|---|
| simple | 12014 | 12014 | 18897 (27046) | 8183 |
| buffered single port | 7511 | 7511 | 15111 (22497) | 7419 |
| buffered dual port | 3023 | 3023 | 10073 (16570) | 6516 |

(generated from `reports/integration.md` by `scripts/fill_readme.py`)
<!-- END INTEG_TABLE -->

Observations from the measurements:

* The simple engine is bounded by its strict read → wait → write → wait sequence (DataFabric's documented
  4 cycles/word). Fixed costs are 4 cycles before the first request and 2 after the last acknowledgement (doc 05 §2);
  of these the adapter itself adds 2 per descriptor (descriptor queue + CHECK state) and nothing per beat.
* The dual-port engine reaches one beat per cycle in every direction because reads and writes go to different
  ports and every target accepts one request per cycle.
* Behind `sfb_crossbar` rev 2.0 a fabric port carries one transaction at a time: `MAX_OUT > 1` helps only on the
  scratchpad side (latency > 1) or with the register slice; full rate needs `MAX_OUT ≥ RL + 1` (doc 05 §3).
* In the integration run the DMA's fabric port loses round-robin arbitration to the host whenever both target the
  same SRAM bank, and the vector sequencer loses bank arbitration to the DMA — both measured, both expected
  round-robin behaviour, neither starving.

## 3. Compared with the CPU

DataFabric measured a 4 KiB SRAM copy at 4 334 cycles with its DMA (including driver setup) against 9 219 cycles for
the CPU's word loop, with the CPU free during the DMA (DataFabric DMA.md §8). The adapter's baseline costs the same
per beat as that DMA (it *is* that engine) and frees the CPU in the same way; the dual-port configuration moves 4 KiB
in 1 032 cycles.

## 4. Not claimed

No clock frequency, bandwidth in GB/s, area or power: there is no timing-closed implementation. Cycle counts are
RTL-simulation measurements.
