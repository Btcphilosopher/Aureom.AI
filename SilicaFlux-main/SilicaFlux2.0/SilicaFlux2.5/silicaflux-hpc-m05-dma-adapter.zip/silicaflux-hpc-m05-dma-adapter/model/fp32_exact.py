"""Exact IEEE 754 binary32 reference (round to nearest, ties to even) from rational arithmetic.

Used by the integration test to compute bit-exact expected results of the Module 03 vector array:
FMADD has a single rounding of the exact a*b + c, which no native float type computes; the
exact value is formed with fractions.Fraction and rounded once here.  `selftest()` checks the
rounding against numpy's native (hardware, correctly rounded) float32 add and multiply,
including subnormal results, before the module is trusted for FMA.
"""
from __future__ import annotations

import random
import struct
from fractions import Fraction


def bits_to_frac(b: int) -> Fraction:
    s, e, m = b >> 31, (b >> 23) & 0xFF, b & 0x7FFFFF
    if e == 0xFF:
        raise ValueError("inf/NaN has no rational value")
    v = Fraction(m, 1 << 149) if e == 0 else Fraction((1 << 23) | m) * (Fraction(2) ** (e - 150))
    return -v if s else v


def frac_to_bits(q: Fraction) -> int:
    """Round an exact rational to binary32 (RNE). Exact zero -> +0 (callers avoid exact zeros)."""
    if q == 0:
        return 0
    sign = 1 if q < 0 else 0
    q = -q if sign else q
    n, d = q.numerator, q.denominator
    e = n.bit_length() - d.bit_length()           # 2^e <= q < 2^(e+1) after adjustment
    if Fraction(2) ** e > q:
        e -= 1
    elif Fraction(2) ** (e + 1) <= q:
        e += 1
    qe = (e - 23) if e >= -126 else -149          # exponent of the unit in the last place
    m = q / (Fraction(2) ** qe)
    mi = m.numerator // m.denominator
    r = m - mi
    if r > Fraction(1, 2) or (r == Fraction(1, 2) and (mi & 1)):
        mi += 1
    if e >= -126:
        if mi == (1 << 24):                        # rounding carried into the next binade
            mi, e = 1 << 23, e + 1
        if e > 127:
            return (sign << 31) | 0x7F800000      # overflow -> infinity (RNE)
        return (sign << 31) | ((e + 127) << 23) | (mi - (1 << 23))
    return (sign << 31) | mi                       # subnormal (mi == 2^23 encodes the minimum normal)


def fadd(a: int, b: int) -> int:
    return frac_to_bits(bits_to_frac(a) + bits_to_frac(b))


def fmul(a: int, b: int) -> int:
    return frac_to_bits(bits_to_frac(a) * bits_to_frac(b))


def fmadd(a: int, b: int, c: int) -> int:
    return frac_to_bits(bits_to_frac(a) * bits_to_frac(b) + bits_to_frac(c))


def rand_fp32(rng: random.Random, emin: int = -12, emax: int = 12) -> int:
    e = rng.randint(emin, emax) + 127
    return (rng.getrandbits(1) << 31) | (e << 23) | rng.getrandbits(23)


def selftest(n: int = 50000, seed: int = 1) -> int:
    import numpy as np
    rng = random.Random(seed)
    bad = 0
    for i in range(n):
        lo = -140 if i % 5 == 0 else -20            # every 5th sample: results near / in the subnormal range
        a, b = rand_fp32(rng, lo // 2, 20), rand_fp32(rng, lo // 2, 20)
        fa, fb = np.array([a, b], dtype=np.uint32).view(np.float32)
        with np.errstate(all="ignore"):
            ref_add = int(np.array([fa + fb], dtype=np.float32).view(np.uint32)[0])
            ref_mul = int(np.array([fa * fb], dtype=np.float32).view(np.uint32)[0])
        if bits_to_frac(a) + bits_to_frac(b) != 0 and fadd(a, b) != ref_add:
            bad += 1
        if fmul(a, b) != ref_mul:
            bad += 1
    return bad


if __name__ == "__main__":
    bad = selftest()
    print(f"fp32_exact selftest: {bad} mismatches vs numpy float32 add/mul (100000 operations)")
    raise SystemExit(1 if bad else 0)
