// =============================================================================
// SilicaFlux-HPC Module 05 :: tb_hpc_dma_route -- router unit testbench
//
// Drives hpc_dma_route directly with traffic the DMA engines never produce:
// up to MAX_OUT outstanding requests whose targets ALTERNATE between the
// scratchpad window and the fabric, with very different per-target latencies
// (a response from the fast target would overtake the slow one's without the
// router's hold rule), random back-pressure on every channel, and (+unsol=1)
// a misbehaving target that presents UNSOLICITED responses.
//
// Each target answers reads with data = hash(addr, target salt), so a
// response delivered from the wrong target or out of order is detected.
// Checks: in-order responses with the expected data / error / write type;
// every request reaches the target that owns its address (never aliased);
// <= MAX_OUT outstanding; unsolicited responses never forwarded and flagged;
// full throughput (1 accept per cycle) for back-to-back same-target traffic
// with 1-cycle targets (retire-and-issue); event outputs consistent.
// Result line: "TB_HPC_ROUTE RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_hpc_dma_route #(
  parameter int MAX_OUT = 2
);
  localparam int DW = 32, SB = 4;
  localparam logic [31:0] WB = 32'h2000_0000;
  localparam int WS = 4096;
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int unsigned cyc = 0, errors = 0, seed = 1, nreq = 20000, unsol = 0;
  always @(posedge clk) cyc <= cyc + 1;
  task automatic err(input string m);
    errors++;
    if (errors <= 20) $display("TB_HPC_ROUTE ERROR cyc=%0d: %s", cyc, m);
  endtask
  function automatic int unsigned xs(input int unsigned r);
    int unsigned t;
    t = r ^ (r << 13); t = t ^ (t >> 17); t = t ^ (t << 5);
    return t;
  endfunction
  function automatic logic [31:0] hash(input logic [31:0] a, input int salt);
    return xs(a ^ (32'(salt) * 32'h9E37_79B9)) ^ 32'h5A5A_0000;
  endfunction
  function automatic bit in_win(input logic [31:0] a);
    return (a & ~32'(WS - 1)) == WB;
  endfunction
  function automatic bit is_err(input logic [31:0] a, input int t);   // per-target error addresses
    return ((a >> 2) % 23) == ((t == 0) ? 5 : 11);
  endfunction

  // ---------------------------------------------------------- DUT
  logic          req_valid = 0, req_ready, req_write = 0, rsp_valid, rsp_ready = 0, rsp_error;
  logic [31:0]   req_addr = '0;
  logic [DW-1:0] req_wdata = '0, rsp_rdata;
  logic [SB-1:0] req_wstrb = '0;
  logic [1:0]    t_req_valid, t_req_ready, t_req_write, t_rsp_valid, t_rsp_ready, t_rsp_error;
  logic [63:0]   t_req_addr;
  logic [2*DW-1:0] t_req_wdata, t_rsp_rdata;
  logic [2*SB-1:0] t_req_wstrb;
  logic ev_rd, ev_wr, ev_spm, ev_fab, ev_stall, ev_rsp, ev_rsp_err, ev_rd_ok, ev_unsol;
  logic [2:0] ev_wr_bytes;
  logic [$clog2(MAX_OUT + 1)-1:0] outstanding;

  hpc_dma_route #(.DW(DW), .SPM_BASE(WB), .SPM_BYTES(WS), .MAX_OUT(MAX_OUT)) dut (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_write, .req_addr, .req_wdata, .req_wstrb,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_error,
    .spm_req_valid(t_req_valid[0]), .spm_req_ready(t_req_ready[0]), .spm_req_write(t_req_write[0]),
    .spm_req_addr(t_req_addr[31:0]), .spm_req_wdata(t_req_wdata[31:0]), .spm_req_wstrb(t_req_wstrb[3:0]),
    .spm_rsp_valid(t_rsp_valid[0]), .spm_rsp_ready(t_rsp_ready[0]), .spm_rsp_rdata(t_rsp_rdata[31:0]),
    .spm_rsp_error(t_rsp_error[0]),
    .fab_req_valid(t_req_valid[1]), .fab_req_ready(t_req_ready[1]), .fab_req_write(t_req_write[1]),
    .fab_req_addr(t_req_addr[63:32]), .fab_req_wdata(t_req_wdata[63:32]), .fab_req_wstrb(t_req_wstrb[7:4]),
    .fab_rsp_valid(t_rsp_valid[1]), .fab_rsp_ready(t_rsp_ready[1]), .fab_rsp_rdata(t_rsp_rdata[63:32]),
    .fab_rsp_error(t_rsp_error[1]),
    .ev_req_rd(ev_rd), .ev_req_wr(ev_wr), .ev_req_spm(ev_spm), .ev_req_fab(ev_fab), .ev_req_stall(ev_stall),
    .ev_rsp(ev_rsp), .ev_rsp_err(ev_rsp_err), .ev_rd_ok(ev_rd_ok), .ev_wr_bytes(ev_wr_bytes),
    .ev_unsolicited(ev_unsol), .outstanding);

  // ---------------------------------------------------------- target models: in-order queues, own latency ranges
  int unsigned lat_lo [0:1], lat_hi [0:1], bp_t = 30, n_unsol_inj = 0, n_unsol_ev = 0;
  for (genvar t = 0; t < 2; t++) begin : g_t
    logic [31:0] q_d [0:15];
    logic        q_e [0:15];
    logic [31:0] q_due [0:15];
    int unsigned n = 0, rp = 0, wp = 0, rng;
    logic rdy = 1'b0, uv = 1'b0;
    logic [31:0] hd = '0, hdue = '0;
    logic he = 1'b0;
    logic [31:0] nv = '0;
    assign t_req_ready[t] = rdy && (nv < 16) && !uv;      // no acceptance while presenting an unsolicited response
    assign t_rsp_valid[t] = ((nv != 0) && (32'(cyc) >= hdue)) || uv;
    assign t_rsp_rdata[t*DW +: DW] = (nv != 0) ? hd : 32'hDEAD_BEEF;
    assign t_rsp_error[t] = (nv != 0) ? he : 1'b0;
    initial rng = 32'h777 + 991 * t;
    always @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin n = 0; rp = 0; wp = 0; rdy <= 1'b0; uv <= 1'b0; nv = 0; end
      else begin
        rng = xs(rng); rdy <= (rng % 100) >= bp_t;
        if (t_rsp_valid[t] && t_rsp_ready[t]) begin
          if (nv == 0) err($sformatf("target %0d: an unsolicited response was consumed", t));
          else begin rp = (rp + 1) % 16; n--; end
        end
        if (t_req_valid[t] && t_req_ready[t]) begin
          logic [31:0] a;
          int unsigned due;
          a = t_req_addr[t*32 +: 32];
          if (in_win(a) != (t == 0)) err($sformatf("address %h delivered to target %0d", a, t));
          rng = xs(rng);
          due = cyc + lat_lo[t] + ((lat_hi[t] > lat_lo[t]) ? rng % (lat_hi[t] - lat_lo[t] + 1) : 0);
          if (n != 0 && q_due[(wp + 15) % 16] > due) due = q_due[(wp + 15) % 16];
          q_due[wp] = due;
          q_e[wp] = is_err(a, t);
          q_d[wp] = (t_req_write[t] || is_err(a, t)) ? 32'd0 : hash(a, t);
          wp = (wp + 1) % 16; n++;
        end
        nv = n;
        hd = q_d[rp]; he = q_e[rp]; hdue = q_due[rp];
        // misbehaving target: a one-cycle unsolicited response while it owns nothing
        uv <= 1'b0;
        rng = xs(rng);
        if (unsol != 0 && n == 0 && (rng % 97) == 3) begin uv <= 1'b1; n_unsol_inj++; end
      end
    end
  end
  int unsigned n_unsol_cyc = 0;                             // cycles with >= 1 unsolicited response (ev is one bit)
  always @(posedge clk) if (rst_n) begin
    if (ev_unsol) n_unsol_ev++;
    if (g_t[0].uv || g_t[1].uv) n_unsol_cyc++;
    if ((g_t[0].uv || g_t[1].uv) != ev_unsol) err("ev_unsolicited disagrees with the injected unsolicited responses");
  end

  // ---------------------------------------------------------- master: random mixed-target traffic, in-order checker
  logic [31:0] e_d [0:63];
  logic        e_e [0:63];
  logic        e_w [0:63];
  int unsigned e_rp = 0, e_wp = 0, n_issued = 0, n_done = 0, mrng = 3, sw = 0, n_switch = 0, n_overtake = 0;
  int unsigned last_tgt = 0, n_wrb = 0, ev_wrb = 0, ev_rdok = 0, rdok = 0;
  logic [31:0] mode = 0;                                   // 0 random, 1 same-target burst (throughput)
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin req_valid <= 1'b0; rsp_ready <= 1'b0; end
    else begin
      // registered DUT count (pre-edge) vs TB count before this edge's handshakes
      if (32'(outstanding) != (e_wp - e_rp)) err("outstanding output disagrees with the TB count");
      mrng = xs(mrng);
      rsp_ready <= (mode == 1) ? 1'b1 : ((mrng % 100) >= 25);
      if (rsp_valid && rsp_ready) begin
        if (e_rp == e_wp) err("response without an outstanding request");
        else begin
          if (rsp_error !== e_e[e_rp % 64] || rsp_rdata !== e_d[e_rp % 64])
            err($sformatf("response %0d: data %h err %0d, expected %h err %0d (misrouted / reordered)",
                          e_rp, rsp_rdata, rsp_error, e_d[e_rp % 64], e_e[e_rp % 64]));
          if (!rsp_error && !e_w[e_rp % 64]) rdok++;
          e_rp++; n_done++;
        end
      end
      if (req_valid && req_ready) begin
        e_d[e_wp % 64] = (req_write || is_err(req_addr, in_win(req_addr) ? 0 : 1)) ? 32'd0 : hash(req_addr, in_win(req_addr) ? 0 : 1);
        e_e[e_wp % 64] = is_err(req_addr, in_win(req_addr) ? 0 : 1);
        e_w[e_wp % 64] = req_write;
        if (req_write && !e_e[e_wp % 64]) n_wrb += $countones(req_wstrb);
        if ((in_win(req_addr) ? 0 : 1) != last_tgt) n_switch++;
        last_tgt = in_win(req_addr) ? 0 : 1;
        e_wp++; n_issued++;
      end
      if (e_wp - e_rp > MAX_OUT) err($sformatf("%0d requests outstanding > MAX_OUT", e_wp - e_rp));
      if (!req_valid || req_ready) begin                    // new request (held otherwise: SFB2 R2)
        mrng = xs(mrng);
        if (n_issued + 1 < nreq && (mode == 1 || (mrng % 100) < 80)) begin
          logic [31:0] a;
          mrng = xs(mrng);
          if (mode == 1) a = WB + 32'((mrng % (WS / 4)) * 4);
          else case (mrng % 6)
            0, 1: a = WB + 32'((mrng >> 8) % (WS / 4)) * 4;           // inside the window
            2:    a = WB + 32'(WS - 4);                                // last word inside
            3:    a = WB + 32'(WS);                                    // first word above: fabric
            4:    a = WB - 32'd4;                                      // last word below: fabric
            default: a = 32'h1000_0000 + 32'((mrng >> 8) % 4096) * 4; // fabric
          endcase
          req_valid <= 1'b1; req_addr <= a;
          mrng = xs(mrng); req_write <= mrng[4]; req_wdata <= mrng; req_wstrb <= 4'(mrng >> 7);
        end else req_valid <= 1'b0;
      end
    end
  end
  always @(posedge clk) if (rst_n) begin
    if (ev_rd_ok) ev_rdok++;
    ev_wrb += ev_wr_bytes;
  end

  initial begin
    int unsigned c0, a0, u_mode;
    void'($value$plusargs("seed=%d", seed));
    void'($value$plusargs("n=%d", nreq));
    void'($value$plusargs("unsol=%d", unsol));
    mrng = seed * 7 + 1;
    // scratchpad fast (1 cycle), fabric slow (4..12): without the hold rule fabric responses would be overtaken
    lat_lo[0] = 1; lat_hi[0] = 1; lat_lo[1] = 4; lat_hi[1] = 12;
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    wait (n_issued + 1 >= nreq);
    req_valid <= 1'b0;
    u_mode = unsol; unsol = 0;                               // stop injecting, then let the last one be flagged
    repeat (200) @(posedge clk);
    if (n_done != n_issued) err($sformatf("%0d requests, %0d responses", n_issued, n_done));
    if (n_switch < nreq / 10) err("too few target switches: test is not exercising the hold rule");
    if (ev_rdok != rdok) err($sformatf("ev_rd_ok %0d vs %0d", ev_rdok, rdok));
    if (ev_wrb != n_wrb) err($sformatf("ev_wr_bytes %0d vs %0d", ev_wrb, n_wrb));
    if (u_mode != 0 && (n_unsol_inj == 0 || n_unsol_ev != n_unsol_cyc))
      err($sformatf("unsolicited responses: %0d cycles injected, %0d flagged", n_unsol_cyc, n_unsol_ev));
    // phase 2: throughput -- 1-cycle targets, no back-pressure, same target: one accept per cycle (retire-and-issue)
    unsol = 0; bp_t = 0; lat_lo[1] = 1; lat_hi[1] = 1;
    mode = 1; nreq = n_issued + 2001;
    @(posedge clk);
    c0 = cyc; a0 = n_issued;
    wait (n_issued + 1 >= nreq);
    begin
      real rate;
      rate = real'(n_issued - a0) / real'(cyc - c0);
      $display("TB_HPC_ROUTE INFO same-target throughput %0.3f accepts/cycle (MAX_OUT %0d)", rate, MAX_OUT);
      if (rate < 0.99) err($sformatf("throughput %0.3f < 1 accept/cycle with 1-cycle targets", rate));
    end
    req_valid <= 1'b0;
    repeat (50) @(posedge clk);
    if (n_done != n_issued) err("phase 2: responses missing");
    $display("TB_HPC_ROUTE STATS requests=%0d target_switches=%0d unsolicited_injected=%0d flagged=%0d",
             n_issued, n_switch, n_unsol_inj, n_unsol_ev);
    if (errors == 0) $display("TB_HPC_ROUTE RESULT PASS seed=%0d", seed);
    else             $display("TB_HPC_ROUTE RESULT FAIL seed=%0d errors=%0d", seed, errors);
    $finish;
  end
  initial begin #50ms; $display("TB_HPC_ROUTE RESULT FAIL timeout"); $finish; end
endmodule

`default_nettype wire
