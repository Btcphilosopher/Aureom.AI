// =============================================================================
// SilicaFlux-HPC Module 05 :: tb_hpc_dma_adapter -- self-checking unit testbench
//
// DUT: hpc_dma_adapter (reused DataFabric engine inside) in a real system:
//
//   host BFM (SFB2 master) ---+
//                             +--> sfb_crossbar (DataFabric, RR) --+--> MEM0 0x1000_0000 16 KiB: sfb_sram_slave
//   DUT fabric port(s) -------+                                    |    (DataFabric slave on SRAM Wrapper Library sram_sp)
//                                                                  +--> MEM1 0x1001_0000 16 KiB: TB slave model
//                                                                  |    (random req back-pressure, latency LMIN..LMAX,
//                                                                  |     poison word -> error, write commit at accept
//                                                                  |     or at response = latest legal point, SFB2 R7)
//                                                                  +--> everything else: crossbar decode error
//   DUT scratchpad port(s) --> hpc_scratchpad (Module 04) 0x2000_0000 16 KiB, ports [NVEC +: NP]
//   NVEC vector-lane BFMs  --> hpc_scratchpad ports [0 +: NVEC]  (random traffic, response back-pressure)
//
// Address use: the first SCR bytes of MEM0, MEM1 and the scratchpad are BFM
// scratch (host / vector traffic, checked by the BFMs' own shadow copies);
// DMA transfers use the rest.
//
// Independent checks (none trusts the DUT's own bookkeeping):
//   * byte-accurate reference memory refm[] of all three memories; the effect
//     of every transfer is applied when its completion is PRODUCED and the
//     three memories are compared byte by byte (backdoor) against refm at that
//     moment -> a completion reported before its last write was performed is
//     caught (MEM1 can commit writes only at the response handshake);
//   * request monitors on every DUT output port: no request without an active
//     descriptor or in/after reset; reads only inside [src, src+len) words;
//     writes only inside [dst, dst+len) words, strobe = tail mask on the last
//     beat, data = source bytes, no duplicate beat, scratchpad addresses only
//     on scratchpad ports and fabric addresses only on fabric ports;
//   * response attribution per port (TB FIFOs): at completion every request
//     of the transfer has been answered and every beat's write was
//     acknowledged OK (OK completions);
//   * completion records: order, tag, code, err_addr, bytes vs. the TB's own
//     prediction (validation rules, region rule, decode errors, poison);
//   * sfb_protocol_checker (DataFabric) on engine ports, scratchpad-adapter
//     ports, fabric master ports and slave ports;
//   * BFM read data vs. shadow memories (scratchpad and fabric under DMA load);
//   * performance counters vs. TB totals; deadlock watchdog.
// Tests: +test=smoke|len1|tails|aligned|long|consec|bp|contention|reset|invalid|
//        buserr|tagerr|buffull|cplfull|finalwrite|abort|random|perf
// Knobs: +seed +n +bp +lmin +lmax +wcommit +host +vec +vbp +cbp +gap
// Result line: "TB_HPC_DMA RESULT PASS|FAIL ..."
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_dma_defs.svh"

module tb_hpc_dma_adapter #(
  parameter int DW         = 32,
  parameter int ENGINE     = 0,
  parameter int FIFO_DEPTH = 8,
  parameter int BURST      = 8,
  parameter int DUAL_PORT  = 0,
  parameter int MAX_OUT    = 2,
  parameter int CMD_DEPTH  = 2,
  parameter int CPL_DEPTH  = 2,
  parameter int FAB_SLICE  = 0,
  parameter int SPM_NB     = 4,
  parameter int SPM_RL     = 1,
  parameter int SPM_QD     = 0,
  parameter int SPM_PMODE  = 0,
  parameter int NVEC       = 2,
  parameter int ARB        = 1,
  parameter int SPM_ECC    = 0                            // 1: scratchpad with byte parity (spmerr test)
);
  localparam int SB   = DW / 8;
  localparam int OFF  = $clog2(SB);
  localparam int NP   = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1;
  localparam int RMO  = (ENGINE != 0) ? MAX_OUT : 1;
  localparam int EXTB = 16384;                           // bytes of MEM0 and of MEM1
  localparam int SPMB = 16384;                           // scratchpad bytes
  localparam int SCR  = 2048;                            // BFM scratch at the bottom of each memory
  localparam int TOT  = 2 * EXTB + SPMB;
  localparam logic [31:0] M0_BASE  = 32'h1000_0000;
  localparam logic [31:0] M1_BASE  = 32'h1001_0000;
  localparam logic [31:0] SPM_BASE = 32'h2000_0000;
  localparam int NM   = NP + 1;                           // fabric masters: DUT port(s) + host
  localparam int NS   = 2;
  localparam int TAGW = 8;
  localparam int STW  = 8;                                // scratchpad tag width
  localparam int MLL  = 16;                               // MAX_LEN_LOG2 (64 KiB)
  localparam int NSP  = NVEC + NP;                        // scratchpad ports
  localparam int SPM_ROWS = SPMB / SB / SPM_NB;
  localparam int MAXD = 8192;                             // descriptors per reset epoch
  localparam int MAXBEAT = 65536 / SB + 1;
  localparam int PARB = (SPM_ECC != 0) ? 1 : 0;
  localparam int LANEW = 8 + PARB;
  localparam int SWW  = SB * LANEW;                       // bank word width (data + parity)
  localparam int VSL  = (SCR / ((NVEC > 0) ? NVEC : 1)) / SB * SB;   // vector scratch slice bytes (word aligned)

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  // ============================================================== knobs / state
  int unsigned seed = 1, n_trans = 200, bp = 0, lmin = 1, lmax = 3, wcommit = 0, host_act = 0, vec_act = 0;
  int unsigned vbp = 0, cbp = 0, gap = 0, hbp = 0;
  int unsigned errors = 0;
  logic [8*16-1:0] test = "smoke";                         // packed (portable plusarg string)

  function automatic int unsigned xs(input int unsigned r);
    int unsigned t;
    t = r ^ (r << 13); t = t ^ (t >> 17); t = t ^ (t << 5);
    return t;
  endfunction
  int unsigned trng = 1;
  function automatic int unsigned rnd(input int unsigned n);   // 0 .. n-1
    trng = xs(trng);
    return (n == 0) ? 0 : (trng % n);
  endfunction

  task automatic err(input string msg);
    errors++;
    if (errors <= 30) $display("TB_HPC_DMA ERROR cyc=%0d: %s", cyc, msg);
  endtask

  // ============================================================== fabric
  wire  [NM-1:0]    m_req_valid, m_req_write, m_rsp_ready;      // driven by the DUT and the host BFM
  wire  [NM*32-1:0] m_req_addr;
  wire  [NM*DW-1:0] m_req_wdata;
  wire  [NM*SB-1:0] m_req_wstrb;
  logic [NM-1:0]    m_req_ready, m_rsp_valid, m_rsp_error;
  logic [NM*DW-1:0] m_rsp_rdata;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [NS*32-1:0] s_req_addr;
  logic [NS*DW-1:0] s_req_wdata, s_rsp_rdata;
  logic [NS*SB-1:0] s_req_wstrb;
  logic [NM-1:0]    x_acc, x_stall, x_loss, x_rstall;
  logic             x_err_evt, x_err_write;
  logic [31:0]      x_err_addr;
  logic [((NM > 1) ? $clog2(NM) : 1)-1:0] x_err_master;
  localparam logic [NS*32-1:0] SLV_BASE = {M1_BASE, M0_BASE};
  localparam logic [NS*32-1:0] SLV_MASK = {~32'(EXTB - 1), ~32'(EXTB - 1)};

  sfb_crossbar #(.NM(NM), .NS(NS), .AW(32), .DW(DW), .ARB_MODE(ARB), .CHECK_ALIGN(1),
                 .SLV_BASE(SLV_BASE), .SLV_MASK(SLV_MASK)) u_xbar (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(x_err_evt), .err_addr(x_err_addr), .err_master(x_err_master), .err_write(x_err_write),
    .ev_req_accept(x_acc), .ev_req_stall(x_stall), .ev_arb_loss(x_loss), .ev_rsp_stall(x_rstall));

  // MEM0: the real DataFabric SRAM slave (SRAM Wrapper Library sram_sp, READ_LATENCY 1)
  logic [DW-1:0] m0_tst_rdata;
  sfb_sram_slave #(.DW(DW), .DEPTH(EXTB / SB), .READ_LATENCY(1)) u_mem0 (
    .clk, .rst_n,
    .req_valid(s_req_valid[0]), .req_ready(s_req_ready[0]), .req_write(s_req_write[0]), .req_addr(s_req_addr[31:0]),
    .req_wdata(s_req_wdata[DW-1:0]), .req_wstrb(s_req_wstrb[SB-1:0]),
    .rsp_valid(s_rsp_valid[0]), .rsp_ready(s_rsp_ready[0]), .rsp_rdata(s_rsp_rdata[DW-1:0]), .rsp_error(s_rsp_error[0]),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(m0_tst_rdata));

  // MEM1: TB slave model
  logic [7:0] m1 [0:EXTB-1];
  int         poison = -1;                                   // MEM1 byte offset of a poisoned word (-1: none)
  localparam int QD1 = 4;
  logic [DW-1:0] q1_d [0:QD1-1];
  logic [DW-1:0] q1_wd [0:QD1-1];
  logic [SB-1:0] q1_ws [0:QD1-1];
  int            q1_wo [0:QD1-1];
  logic          q1_e [0:QD1-1];
  logic          q1_w [0:QD1-1];
  logic [31:0]   q1_due [0:QD1-1];
  int unsigned   q1_n = 0, q1_rd = 0, q1_wr = 0, s1rng = 7;
  logic          s1_rdy = 1'b0;
  // queue head mirrored into scalars (Icarus 12 cannot take unpacked arrays in continuous assigns / @*)
  logic [31:0]   h1_due = '0;
  logic [DW-1:0] h1_d = '0;
  logic          h1_e = 1'b0;
  logic [31:0]   q1_nv = '0;
  assign s_req_ready[1]        = s1_rdy && (q1_nv < QD1);
  assign s_rsp_valid[1]        = (q1_nv != 0) && (32'(cyc) >= h1_due);
  assign s_rsp_rdata[DW +: DW] = s_rsp_valid[1] ? h1_d : '0;
  assign s_rsp_error[1]        = s_rsp_valid[1] && h1_e;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q1_n = 0; q1_rd = 0; q1_wr = 0; s1_rdy <= 1'b0; q1_nv = 0;
    end else begin : s1
      int unsigned n, due, lat, ix;
      int o;
      logic pe;
      logic [DW-1:0] d;
      n = q1_n;
      s1rng = xs(s1rng);
      s1_rdy <= (s1rng % 100) >= bp;
      if (s_rsp_valid[1] && s_rsp_ready[1]) begin
        if (q1_w[q1_rd] && !q1_e[q1_rd] && wcommit != 0)             // commit at the response (R7: not later)
          for (int b = 0; b < SB; b++) if (q1_ws[q1_rd][b]) m1[q1_wo[q1_rd] + b] = q1_wd[q1_rd][b*8 +: 8];
        q1_rd = (q1_rd + 1) % QD1; n = n - 1;
      end
      if (s_req_valid[1] && s_req_ready[1]) begin
        o  = int'(s_req_addr[32 +: 32] - M1_BASE) & (EXTB - 1) & ~(SB - 1);
        pe = (poison >= 0) && (o == poison);
        for (int b = 0; b < SB; b++) d[b*8 +: 8] = m1[o + b];
        if (s_req_write[1] && !pe && wcommit == 0)
          for (int b = 0; b < SB; b++) if (s_req_wstrb[SB + b]) m1[o + b] = s_req_wdata[DW + b*8 +: 8];
        s1rng = xs(s1rng);
        lat = lmin + ((lmax > lmin) ? (s1rng % (lmax - lmin + 1)) : 0);
        due = cyc + lat;
        ix  = (q1_wr + QD1 - 1) % QD1;
        if (n != 0 && q1_due[ix] > due) due = q1_due[ix];
        q1_due[q1_wr] = due;
        q1_e[q1_wr]   = pe;
        q1_w[q1_wr]   = s_req_write[1];
        q1_wd[q1_wr]  = s_req_wdata[DW +: DW];
        q1_ws[q1_wr]  = s_req_wstrb[SB +: SB];
        q1_wo[q1_wr]  = o;
        q1_d[q1_wr]   = (s_req_write[1] || pe) ? '0 : d;
        q1_wr = (q1_wr + 1) % QD1;
        n = n + 1;
      end
      q1_n = n;
      q1_nv = n;
      h1_due = q1_due[q1_rd]; h1_d = q1_d[q1_rd]; h1_e = q1_e[q1_rd];
    end
  end

  // ============================================================== scratchpad (Module 04)
  wire  [NSP-1:0]       p_req_valid, p_req_we, p_rsp_ready;      // driven by the DUT and the vector BFMs
  wire  [NSP*32-1:0]    p_req_addr;
  wire  [NSP*DW-1:0]    p_req_wdata;
  wire  [NSP*SB-1:0]    p_req_wstrb;
  wire  [NSP*STW-1:0]   p_req_tag;
  logic [NSP-1:0]       p_req_ready, p_rsp_valid, p_rsp_err, p_rsp_we;
  logic [NSP*DW-1:0]    p_rsp_rdata;
  logic [NSP*SB-1:0]    p_rsp_syn;
  logic [NSP*STW-1:0]   p_rsp_tag;
  logic [NSP*3-1:0]     p_rsp_code;
  logic [NSP-1:0]       sp_ev_acc, sp_ev_iss, sp_ev_conf, sp_ev_cstall, sp_ev_err, sp_ev_ecc;
  logic [SPM_NB*2-1:0]  sp_ev_bops;
  logic [SPM_NB-1:0]    sp_ev_bconf;
  logic [31:0]          sp_cycles, sp_ecc;
  logic [NSP*32-1:0]    sp_acc, sp_iss, sp_cpl, sp_conf, sp_wait, sp_errc;
  logic [SPM_NB*32-1:0] sp_bops;
  logic                 sp_busy;

  hpc_scratchpad #(.NUM_PORTS(NSP), .CAPACITY_BYTES(SPMB), .NUM_BANKS(SPM_NB), .DATA_WIDTH(DW), .ADDR_WIDTH(32),
                   .BASE_ADDR(64'(SPM_BASE)), .READ_LATENCY(SPM_RL), .PORT_MODE(SPM_PMODE), .QUEUE_DEPTH(SPM_QD),
                   .WRITE_ACK(1), .TAG_W(STW), .ECC_MODE(SPM_ECC)) u_spm (
    .clk, .rst_n,
    .req_valid(p_req_valid), .req_ready(p_req_ready), .req_we(p_req_we), .req_addr(p_req_addr),
    .req_wdata(p_req_wdata), .req_wstrb(p_req_wstrb), .req_tag(p_req_tag),
    .rsp_valid(p_rsp_valid), .rsp_ready(p_rsp_ready), .rsp_rdata(p_rsp_rdata), .rsp_err(p_rsp_err),
    .rsp_err_code(p_rsp_code), .rsp_we(p_rsp_we), .rsp_tag(p_rsp_tag), .rsp_ecc_syn(p_rsp_syn),
    .ev_accept(sp_ev_acc), .ev_issue(sp_ev_iss), .ev_conflict(sp_ev_conf), .ev_credit_stall(sp_ev_cstall),
    .ev_error(sp_ev_err), .ev_ecc_err(sp_ev_ecc), .ev_bank_ops(sp_ev_bops), .ev_bank_conflict(sp_ev_bconf),
    .perf_clear(1'b0), .perf_cycles(sp_cycles), .perf_accept(sp_acc), .perf_issue(sp_iss), .perf_complete(sp_cpl),
    .perf_conflict(sp_conf), .perf_wait(sp_wait), .perf_error(sp_errc), .perf_bank_ops(sp_bops),
    .perf_ecc_err(sp_ecc), .busy(sp_busy));

  // ============================================================== DUT
  logic             cmd_valid = 1'b0, cmd_ready, cmd_abort = 1'b0, cpl_valid, cpl_ready = 1'b0, cpl_err;
  logic [31:0]      cmd_src = '0, cmd_dst = '0, cmd_len = '0, cpl_err_addr, cpl_bytes, eng_bytes;
  logic [TAGW-1:0]  cmd_tag = '0, cpl_tag, cur_tag;
  logic [3:0]       cpl_code;
  logic             busy, active, ev_cmd_accept, ev_start, ev_cpl, ev_cpl_err, ev_stall, ev_berr, ev_terr;
  logic [1:0]       ctl_state;
  logic [2:0]       eng_state;
  logic [7:0]       fifo_level, ev_brd, ev_bwr, ev_out;
  logic             perf_clear = 1'b0;
  logic [`HPC_DMA_NUM_PC*32-1:0] perf_cnt;
  // DUT scratchpad port(s) with a fault injector on the returned tag (response-misrouting test)
  logic [NP*STW-1:0] d_rsp_tag;
  logic [31:0]       inj_at = 32'hFFFF_FFFF;
  logic [31:0]       inj_port = '0;
  logic [NP*32-1:0]  spm_rsp_cnt_v;                // scratchpad responses seen per DUT port (this epoch)
  logic [NP-1:0]     inj_now;
  for (genvar p = 0; p < NP; p++) begin : g_inj
    logic [31:0] rcnt = '0;
    assign spm_rsp_cnt_v[p*32 +: 32] = rcnt;
    assign inj_now[p] = p_rsp_valid[NVEC + p] && (inj_port == p) && (rcnt == inj_at);
    assign d_rsp_tag[p*STW +: STW] = p_rsp_tag[(NVEC + p)*STW +: STW] ^ STW'(inj_now[p]);
    always @(posedge clk or negedge rst_n)
      if (!rst_n) rcnt <= '0;
      else if (p_rsp_valid[NVEC + p] && p_rsp_ready[NVEC + p]) rcnt <= rcnt + 1;
  end
  function automatic int unsigned spm_rsp_cnt(input int p);
    return spm_rsp_cnt_v[p*32 +: 32];
  endfunction

  hpc_dma_adapter #(.DW(DW), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .BURST(BURST), .DUAL_PORT(DUAL_PORT),
                    .MAX_OUT(MAX_OUT), .MAX_LEN_LOG2(MLL), .SPM_BASE(SPM_BASE), .SPM_BYTES(SPMB), .SPM_TAG_W(STW),
                    .CMD_DEPTH(CMD_DEPTH), .CPL_DEPTH(CPL_DEPTH), .TAG_W(TAGW), .FAB_SLICE(FAB_SLICE),
                    .PERF_EN(1), .CNT_W(32)) dut (
    .clk, .rst_n,
    .cmd_valid, .cmd_ready, .cmd_src, .cmd_dst, .cmd_len, .cmd_tag, .cmd_abort,
    .cpl_valid, .cpl_ready, .cpl_tag, .cpl_err, .cpl_code, .cpl_err_addr, .cpl_bytes,
    .busy, .active, .cur_tag, .ctl_state, .eng_state, .eng_bytes_done(eng_bytes), .fifo_level,
    .spm_req_valid(p_req_valid[NVEC +: NP]), .spm_req_ready(p_req_ready[NVEC +: NP]), .spm_req_we(p_req_we[NVEC +: NP]),
    .spm_req_addr(p_req_addr[NVEC*32 +: NP*32]), .spm_req_wdata(p_req_wdata[NVEC*DW +: NP*DW]),
    .spm_req_wstrb(p_req_wstrb[NVEC*SB +: NP*SB]), .spm_req_tag(p_req_tag[NVEC*STW +: NP*STW]),
    .spm_rsp_valid(p_rsp_valid[NVEC +: NP]), .spm_rsp_ready(p_rsp_ready[NVEC +: NP]),
    .spm_rsp_rdata(p_rsp_rdata[NVEC*DW +: NP*DW]), .spm_rsp_err(p_rsp_err[NVEC +: NP]),
    .spm_rsp_err_code(p_rsp_code[NVEC*3 +: NP*3]), .spm_rsp_we(p_rsp_we[NVEC +: NP]), .spm_rsp_tag(d_rsp_tag),
    .fab_req_valid(m_req_valid[NP-1:0]), .fab_req_ready(m_req_ready[NP-1:0]), .fab_req_write(m_req_write[NP-1:0]),
    .fab_req_addr(m_req_addr[NP*32-1:0]), .fab_req_wdata(m_req_wdata[NP*DW-1:0]), .fab_req_wstrb(m_req_wstrb[NP*SB-1:0]),
    .fab_rsp_valid(m_rsp_valid[NP-1:0]), .fab_rsp_ready(m_rsp_ready[NP-1:0]), .fab_rsp_rdata(m_rsp_rdata[NP*DW-1:0]),
    .fab_rsp_error(m_rsp_error[NP-1:0]),
    .ev_cmd_accept, .ev_start, .ev_cpl, .ev_cpl_err, .ev_bytes_rd(ev_brd), .ev_bytes_wr(ev_bwr), .ev_req_stall(ev_stall),
    .ev_outstanding(ev_out), .ev_bus_err(ev_berr), .ev_tag_err(ev_terr),
    .perf_clear, .perf_cnt);
  function automatic int unsigned pc(input int i);
    return perf_cnt[i*32 +: 32];
  endfunction

  // ============================================================== protocol checkers (DataFabric sfb_protocol_checker)
  logic [31:0] viol [0:3*NP+NM+NS-1];
  genvar g;
  for (g = 0; g < NP; g++) begin : g_pc
    logic [31:0] a0, b0, c0, a1, b1, c1;
    sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(RMO), .NAME("engine")) u_eng (
      .clk, .rst_n, .req_valid(dut.g_core.m_req_valid[g]), .req_ready(dut.g_core.m_req_ready[g]), .req_write(dut.g_core.m_req_write[g]),
      .req_addr(dut.g_core.m_req_addr[g*32 +: 32]), .req_wdata(dut.g_core.m_req_wdata[g*DW +: DW]), .req_wstrb(dut.g_core.m_req_wstrb[g*SB +: SB]),
      .rsp_valid(dut.g_core.m_rsp_valid[g]), .rsp_ready(dut.g_core.m_rsp_ready[g]), .rsp_rdata(dut.g_core.m_rsp_rdata[g*DW +: DW]),
      .rsp_error(dut.g_core.m_rsp_error[g]), .violations(viol[3*g]), .n_req(a0), .n_rsp(b0), .outstanding(c0));
    sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(RMO), .NAME("spm_sfb2")) u_spm (
      .clk, .rst_n, .req_valid(dut.g_core.g_port[g].s_req_valid), .req_ready(dut.g_core.g_port[g].s_req_ready),
      .req_write(dut.g_core.g_port[g].s_req_write), .req_addr(dut.g_core.g_port[g].s_req_addr), .req_wdata(dut.g_core.g_port[g].s_req_wdata),
      .req_wstrb(dut.g_core.g_port[g].s_req_wstrb), .rsp_valid(dut.g_core.g_port[g].s_rsp_valid), .rsp_ready(dut.g_core.g_port[g].s_rsp_ready),
      .rsp_rdata(dut.g_core.g_port[g].s_rsp_rdata), .rsp_error(dut.g_core.g_port[g].s_rsp_error), .violations(viol[3*g+1]),
      .n_req(a1), .n_rsp(b1), .outstanding(c1));
    logic [31:0] a2, b2, c2;
    sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(RMO), .NAME("fab_route")) u_fr (
      .clk, .rst_n, .req_valid(dut.g_core.g_port[g].f_req_valid), .req_ready(dut.g_core.g_port[g].f_req_ready),
      .req_write(dut.g_core.g_port[g].f_req_write), .req_addr(dut.g_core.g_port[g].f_req_addr), .req_wdata(dut.g_core.g_port[g].f_req_wdata),
      .req_wstrb(dut.g_core.g_port[g].f_req_wstrb), .rsp_valid(dut.g_core.g_port[g].f_rsp_valid), .rsp_ready(dut.g_core.g_port[g].f_rsp_ready),
      .rsp_rdata(dut.g_core.g_port[g].f_rsp_rdata), .rsp_error(dut.g_core.g_port[g].f_rsp_error), .violations(viol[3*g+2]),
      .n_req(a2), .n_rsp(b2), .outstanding(c2));
  end
  for (g = 0; g < NM; g++) begin : g_cm
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(1), .NAME("xbar_master")) u_c (
      .clk, .rst_n, .req_valid(m_req_valid[g]), .req_ready(m_req_ready[g]), .req_write(m_req_write[g]),
      .req_addr(m_req_addr[g*32 +: 32]), .req_wdata(m_req_wdata[g*DW +: DW]), .req_wstrb(m_req_wstrb[g*SB +: SB]),
      .rsp_valid(m_rsp_valid[g]), .rsp_ready(m_rsp_ready[g]), .rsp_rdata(m_rsp_rdata[g*DW +: DW]),
      .rsp_error(m_rsp_error[g]), .violations(viol[3*NP+g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  for (g = 0; g < NS; g++) begin : g_cs
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(DW), .MAX_OUT(1), .NAME("xbar_slave")) u_c (
      .clk, .rst_n, .req_valid(s_req_valid[g]), .req_ready(s_req_ready[g]), .req_write(s_req_write[g]),
      .req_addr(s_req_addr[g*32 +: 32]), .req_wdata(s_req_wdata[g*DW +: DW]), .req_wstrb(s_req_wstrb[g*SB +: SB]),
      .rsp_valid(s_rsp_valid[g]), .rsp_ready(s_rsp_ready[g]), .rsp_rdata(s_rsp_rdata[g*DW +: DW]),
      .rsp_error(s_rsp_error[g]), .violations(viol[3*NP+NM+g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  function automatic int unsigned viol_total();
    int unsigned v;
    v = 0;
    for (int i = 0; i < 3*NP+NM+NS; i++) v += viol[i];
    return v;
  endfunction

  // ============================================================== reference memory and address helpers
  logic [7:0] refm [0:TOT-1];
  // global byte offset: [0,EXTB) MEM0, [EXTB,2EXTB) MEM1, [2EXTB,TOT) scratchpad; -1 unmapped
  function automatic int goff(input logic [31:0] a);
    if ((a & ~32'(EXTB - 1)) == M0_BASE)       return int'(a - M0_BASE);
    else if ((a & ~32'(EXTB - 1)) == M1_BASE)  return EXTB + int'(a - M1_BASE);
    else if ((a & ~32'(SPMB - 1)) == SPM_BASE) return 2 * EXTB + int'(a - SPM_BASE);
    return -1;
  endfunction
  function automatic bit in_spm(input logic [31:0] a);
    return (a & ~32'(SPMB - 1)) == SPM_BASE;
  endfunction
  function automatic bit is_scratch(input int o);
    return (o >= 0 && o < SCR) || (o >= EXTB && o < EXTB + SCR) || (o >= 2*EXTB && o < 2*EXTB + SCR);
  endfunction
  // a DMA access to this word succeeds (mapped, not poisoned)
  function automatic bit acc_ok(input logic [31:0] a);
    int o;
    o = goff(a);
    if (o < 0) return 1'b0;
    if (poison >= 0 && o == EXTB + poison) return 1'b0;
    return 1'b1;
  endfunction
  function automatic logic [SB-1:0] strb_of(input int k, input int nb, input logic [31:0] len);
    logic [SB-1:0] s;
    s = '1;
    if (k == nb - 1 && (len % SB) != 0) for (int b = 0; b < SB; b++) s[b] = (b < int'(len % SB));
    return s;
  endfunction

  // ---------------------------------------------------------- backdoors
  // MEM0 (sram_sp generic array) and MEM1 (TB array): direct; scratchpad banks: per-bank processes (M04 technique)
  logic [7:0] spm_dump [0:SPMB-1];
  logic [7:0] spm_load [0:SPMB-1];
  int  bd_seq = 0, bd_cmd = 0, bd_word = 0, bd_bit = 0;
  logic [SPM_NB-1:0] bd_ack;
  for (g = 0; g < SPM_NB; g++) begin : g_bd
    int ack_seq = 0;
    assign bd_ack[g] = (ack_seq == bd_seq);
    always @(bd_seq) begin
      if (bd_seq != 0) begin
        if (bd_cmd == 3) begin                              // flip one stored bit of global word bd_word
          if (bd_word % SPM_NB == g)
            u_spm.g_core.g_bank[g].u_bank.g_ram.u_ram.g_generic.u_mem.mem[bd_word / SPM_NB][bd_bit] =
              ~u_spm.g_core.g_bank[g].u_bank.g_ram.u_ram.g_generic.u_mem.mem[bd_word / SPM_NB][bd_bit];
        end else
        for (int r = 0; r < SPM_ROWS; r++) begin
          int w;
          logic [SWW-1:0] v;
          w = r * SPM_NB + g;
          if (bd_cmd == 1) begin                            // lane l = {odd parity (if any), byte}
            for (int b = 0; b < SB; b++)
              if (PARB != 0) v[b*LANEW +: LANEW] = SWW'({~^spm_load[w*SB + b], spm_load[w*SB + b]});
              else           v[b*LANEW +: LANEW] = SWW'(spm_load[w*SB + b]);
            u_spm.g_core.g_bank[g].u_bank.g_ram.u_ram.g_generic.u_mem.mem[r] = v;
          end else begin
            v = u_spm.g_core.g_bank[g].u_bank.g_ram.u_ram.g_generic.u_mem.mem[r];
            for (int b = 0; b < SB; b++) spm_dump[w*SB + b] = v[b*LANEW +: 8];
          end
        end
        ack_seq = bd_seq;
      end
    end
  end
  task automatic bd_do(input int c);
    bd_cmd = c;
    bd_seq = bd_seq + 1;
    #0.001;
    wait (bd_ack == {SPM_NB{1'b1}});
  endtask
  function automatic logic [7:0] m0_byte(input int o);
    logic [DW-1:0] v;
    v = u_mem0.u_sram.u_array.g_generic.u_mem.mem[o / SB];
    return v[(o % SB)*8 +: 8];
  endfunction
  // actual byte at a global offset (spm_dump must be fresh)
  function automatic logic [7:0] act(input int o);
    if (o < EXTB) return m0_byte(o);
    else if (o < 2 * EXTB) return m1[o - EXTB];
    return spm_dump[o - 2 * EXTB];
  endfunction
  task automatic mem_init();
    logic [DW-1:0] v;
    for (int o = 0; o < TOT; o++) refm[o] = 8'(rnd(256));
    for (int w = 0; w < EXTB / SB; w++) begin
      for (int b = 0; b < SB; b++) v[b*8 +: 8] = refm[w*SB + b];
      u_mem0.u_sram.u_array.g_generic.u_mem.mem[w] = v;
    end
    for (int o = 0; o < EXTB; o++) m1[o] = refm[EXTB + o];
    for (int o = 0; o < SPMB; o++) spm_load[o] = refm[2*EXTB + o];
    bd_do(1);
  endtask

  // ---------------------------------------------------------- uncertain beats (old or new, beat-atomic)
  int unc_n = 0;
  int unc_d [0:4095];
  int unc_s [0:4095];
  logic [SB-1:0] unc_m [0:4095];
  task automatic add_unc(input int d, input int s, input logic [SB-1:0] m);
    if (unc_n < 4096) begin unc_d[unc_n] = d; unc_s[unc_n] = s; unc_m[unc_n] = m; unc_n++; end
  endtask

  int unsigned n_checks = 0, n_unc_new = 0, n_unc_old = 0;
  task automatic check_mem(input string why);
    int mism;
    bd_do(2);
    // resolve uncertain beats first
    for (int u = 0; u < unc_n; u++) begin
      bit is_old, is_new;
      is_old = 1'b1; is_new = 1'b1;
      for (int b = 0; b < SB; b++) if (unc_m[u][b]) begin
        if (act(unc_d[u] + b) !== refm[unc_d[u] + b]) is_old = 1'b0;
        if (unc_s[u] < 0 || act(unc_d[u] + b) !== refm[unc_s[u] + b]) is_new = 1'b0;
      end
      if (!is_old && !is_new) err($sformatf("uncertain beat at goff %0d is neither old nor new data (%s)", unc_d[u], why));
      if (is_new && !is_old) n_unc_new++; else n_unc_old++;
      for (int b = 0; b < SB; b++) if (unc_m[u][b]) refm[unc_d[u] + b] = act(unc_d[u] + b);
    end
    unc_n = 0;
    mism = 0;
    for (int o = 0; o < TOT; o++) begin
      if (!is_scratch(o) && act(o) !== refm[o]) begin
        mism++;
        if (mism <= 4) err($sformatf("memory mismatch (%s) goff %0d: got %02h exp %02h", why, o, act(o), refm[o]));
      end
    end
    if (mism > 4) err($sformatf("... %0d mismatching bytes in total (%s)", mism, why));
    n_checks++;
  endtask

  // ============================================================== descriptor book-keeping (one reset epoch)
  logic [31:0] d_src [0:MAXD-1];
  logic [31:0] d_dst [0:MAXD-1];
  logic [31:0] d_len [0:MAXD-1];
  logic [7:0]  d_tag [0:MAXD-1];
  int          d_code [0:MAXD-1];
  logic [31:0] d_eaddr [0:MAXD-1];
  int          d_bytes [0:MAXD-1];
  bit          d_fuzzy [0:MAXD-1];
  int          d_pbytes [0:MAXD-1];              // bytes when produced (fuzzy outcome)
  int unsigned d_t_acc [0:MAXD-1];
  int unsigned d_t_cpl [0:MAXD-1];
  int unsigned d_t_req [0:MAXD-1];
  int          d_wr_ok [0:MAXD-1];
  int          d_rd [0:MAXD-1];
  int          d_wr [0:MAXD-1];
  int n_sub = 0, n_prod = 0, n_cpl = 0;          // submitted / produced / consumed in this epoch
  int unsigned tag_ctr = 0;
  int unsigned tot_xfer = 0, tot_bytes = 0, tot_err_cpl = 0;
  bit   wseen [0:MAXBEAT-1];
  // per-port response attribution FIFOs: 0..NP-1 scratchpad side, NP..2NP-1 fabric side
  int   af_idx [0:2*NP-1][0:31];
  bit   af_w   [0:2*NP-1][0:31];
  int   af_nb  [0:2*NP-1][0:31];
  int   af_rp [0:2*NP-1], af_wp [0:2*NP-1];
  // TB totals for the performance-counter cross-check (reset epoch)
  int unsigned t_reads = 0, t_writes = 0, t_spm = 0, t_fab = 0, t_brd = 0, t_bwr = 0, t_berr = 0, t_terr = 0;
  int unsigned t_cok = 0, t_cerr = 0, t_cyc0 = 0, inj_hits = 0;

  function automatic int nbeats(input logic [31:0] len);
    return int'((len + SB - 1) / SB);
  endfunction

  // TB re-implementation of the validation rules (DataFabric DMA.md sec. 2 + REGION)
  function automatic bit range_ok(input logic [31:0] a, input logic [31:0] n);
    longint lo, hi, wl, wh;
    lo = longint'(a); hi = lo + longint'(n); wl = longint'(SPM_BASE); wh = wl + SPMB;
    return (lo >= wl && hi <= wh) || (hi <= wl || lo >= wh);
  endfunction
  task automatic predict(input int i);
    longint s, d, n;
    int code, bytes, nb;
    logic [31:0] ea;
    s = longint'(d_src[i]); d = longint'(d_dst[i]); n = longint'(d_len[i]);
    code = 0; bytes = 0; ea = '0;
    if (n == 0) code = 1;
    else if (n > (longint'(1) << MLL)) code = 2;
    else if ((s % SB) != 0) code = 3;
    else if ((d % SB) != 0) code = 4;
    else if (s + n > 64'h1_0000_0000) code = 5;
    else if (d + n > 64'h1_0000_0000) code = 6;
    else if (s < d + n && d < s + n) code = 7;
    else if (!range_ok(d_src[i], d_len[i]) || !range_ok(d_dst[i], d_len[i])) begin
      code = 11;
      if (!range_ok(d_src[i], d_len[i])) ea = in_spm(d_src[i]) ? SPM_BASE + SPMB : SPM_BASE;
      else                               ea = in_spm(d_dst[i]) ? SPM_BASE + SPMB : SPM_BASE;
    end
    if (code == 0) begin
      nb = nbeats(d_len[i]);
      bytes = int'(n);
      for (int k = 0; k < nb && code == 0; k++) begin       // first failing access in beat order
        if (!acc_ok(d_src[i] + 32'(k * SB)))      begin code = 8; ea = d_src[i] + 32'(k * SB); bytes = k * SB; end
        else if (!acc_ok(d_dst[i] + 32'(k * SB))) begin code = 9; ea = d_dst[i] + 32'(k * SB); bytes = k * SB; end
      end
    end
    d_code[i] = code; d_eaddr[i] = ea; d_bytes[i] = bytes;
  endtask

  // ============================================================== command driver / completion consumer
  // Handshakes are detected ONLY by this edge-triggered monitor (pre-edge values).  Tasks wait for its
  // counter instead of sampling cmd_ready after @(posedge clk), whose value is post-edge in Verilator
  // --timing coroutines (found by the cplfull test: a full queue made the task re-present a descriptor).
  int unsigned n_cmd_hs = 0, cmd_hs_cyc = 0, dbg = 0;
  always @(posedge clk) if (rst_n && cmd_valid && cmd_ready) begin
    n_cmd_hs++;
    cmd_hs_cyc = cyc;
    if (dbg != 0) $display("DBG cyc=%0d cmd handshake #%0d", cyc, n_cmd_hs);
  end
  // present one descriptor; returns 1 when it was accepted, 0 after `limit` cycles without acceptance
  task automatic present(input logic [31:0] src, input logic [31:0] dst, input logic [31:0] len, input logic [7:0] tag,
                         input int unsigned limit, output bit ok);
    int unsigned k, t0;
    k = n_cmd_hs; t0 = cyc;
    cmd_valid <= 1'b1; cmd_src <= src; cmd_dst <= dst; cmd_len <= len; cmd_tag <= tag;
    while (n_cmd_hs == k && (cyc - t0) < limit) @(posedge clk or negedge clk);
    cmd_valid <= 1'b0;
    if (n_cmd_hs == k) @(negedge clk);                 // an acceptance on the very last edge is still counted
    ok = (n_cmd_hs != k);
  endtask
  task automatic submit(input logic [31:0] src, input logic [31:0] dst, input logic [31:0] len, input bit fuzzy);
    int i;
    i = n_sub;
    d_src[i] = src; d_dst[i] = dst; d_len[i] = len; d_tag[i] = 8'(tag_ctr); d_fuzzy[i] = fuzzy;
    d_wr_ok[i] = 0; d_rd[i] = 0; d_wr[i] = 0; d_t_req[i] = 0; d_abort_must[i] = 1'b0;
    tag_ctr++;
    predict(i);
    n_sub++;
    begin
      bit ok;
      present(src, dst, len, d_tag[i], 32'hFFFF_FFFF, ok);
    end
    d_t_acc[i] = cmd_hs_cyc;
    if (gap != 0) repeat (rnd(gap + 1)) @(posedge clk);
  endtask

  int unsigned cpl_rng = 99;
  always @(posedge clk) begin
    cpl_rng = xs(cpl_rng);
    cpl_ready <= (cpl_rng % 100) >= cbp;
  end
  logic cpl_valid_q = 1'b0;
  always @(posedge clk) cpl_valid_q <= cpl_valid;

  // completion records (consumer side)
  always @(posedge clk) if (rst_n && cpl_valid && cpl_ready) begin : cpl_chk
    int i;
    i = n_cpl;
    if (i >= n_prod) err($sformatf("completion record %0d consumed before it was produced", i));
    else begin
      if (cpl_tag !== d_tag[i]) err($sformatf("completion %0d: tag %0d, expected %0d (order/ownership)", i, cpl_tag, d_tag[i]));
      if (cpl_err !== (cpl_code != 0)) err("cpl_err inconsistent with cpl_code");
      if (d_fuzzy[i]) begin
        if (!(cpl_code == 0 && cpl_bytes == d_len[i]) && !(cpl_code == 10 && cpl_bytes < d_len[i]))
          err($sformatf("aborted transfer %0d: code %0d bytes %0d (len %0d)", i, cpl_code, cpl_bytes, d_len[i]));
        if (d_abort_must[i] && cpl_code != 10)
          err($sformatf("transfer %0d: abort sampled with %0d of %0d beats written, but it completed with code %0d",
                        i, d_wr[i], nbeats(d_len[i]), cpl_code));
        if (d_abort_must[i]) n_abort_must++;
      end else begin
        if (int'(cpl_code) != d_code[i]) err($sformatf("transfer %0d (src %h dst %h len %0d): code %0d, expected %0d",
                                                       i, d_src[i], d_dst[i], d_len[i], cpl_code, d_code[i]));
        if (int'(cpl_bytes) != d_bytes[i]) err($sformatf("transfer %0d: bytes %0d, expected %0d", i, cpl_bytes, d_bytes[i]));
        if ((d_code[i] == 8 || d_code[i] == 9 || d_code[i] == 11) && cpl_err_addr !== d_eaddr[i])
          err($sformatf("transfer %0d: err_addr %h, expected %h", i, cpl_err_addr, d_eaddr[i]));
      end
      if (int'(cpl_bytes) != d_pbytes[i] && d_code[i] != 11) err("cpl_bytes differs from the engine count at production");
      if (cpl_code != 0) tot_err_cpl++;
    end
    n_cpl++;
  end

  // production: completion record pushed (ev_cpl) -> apply expected effect, check write acknowledgements
  logic chk_req = 1'b0;
  int   chk_idx = 0;
  always @(posedge clk) if (rst_n && ev_cpl) begin : prod
    int i, nb, code, bytes, dgo, sgo;
    i = n_prod;
    if (i >= n_sub) err("completion produced without a submitted descriptor");
    else begin
      d_t_cpl[i] = cyc + 1;                              // cpl_valid can be seen from the next cycle
      d_pbytes[i] = int'(eng_bytes);
      nb = nbeats(d_len[i]);
      code  = d_fuzzy[i] ? ((int'(eng_bytes) == int'(d_len[i])) ? 0 : 10) : d_code[i];
      bytes = d_fuzzy[i] ? int'(eng_bytes) : d_bytes[i];
      if (d_code[i] == 11) begin bytes = 0; d_pbytes[i] = 0; end
      // every request of the transfer answered
      for (int q = 0; q < 2*NP; q++) if (af_rp[q] != af_wp[q]) err($sformatf("transfer %0d produced with responses pending", i));
      if (code == 0 && (d_wr_ok[i] != nb || d_wr[i] != nb))
        err($sformatf("transfer %0d DONE but %0d/%0d writes acknowledged (%0d issued)", i, d_wr_ok[i], nb, d_wr[i]));
      if (code == 0 && d_rd[i] != nb) err($sformatf("transfer %0d DONE with %0d reads for %0d beats", i, d_rd[i], nb));
      if ((code >= 1 && code <= 7) || code == 11) if (d_rd[i] != 0 || d_wr[i] != 0)
        err($sformatf("transfer %0d rejected (code %0d) but issued bus requests", i, code));
      // expected memory effect
      dgo = goff(d_dst[i]); sgo = goff(d_src[i]);
      if (bytes > 0 && dgo >= 0 && sgo >= 0) for (int b = 0; b < bytes; b++) refm[dgo + b] = refm[sgo + b];
      if (code == 9 && RMO > 1) begin                     // buffered: up to MAX_OUT-1 later beats may have been written
        int k0;
        k0 = int'(d_eaddr[i] - d_dst[i]) / SB;
        for (int k = k0 + 1; k < nb && k <= k0 + RMO - 1; k++)
          if (acc_ok(d_dst[i] + 32'(k*SB))) add_unc(dgo + k*SB, sgo + k*SB, strb_of(k, nb, d_len[i]));
      end
      if (inj_hits != 0 && code == 9) begin              // tag-injected write: performed by the scratchpad, ack corrupted
        int k0;
        k0 = int'(d_eaddr[i] - d_dst[i]) / SB;
        if (dgo >= 0) add_unc(dgo + k0*SB, sgo + k0*SB, strb_of(k0, nb, d_len[i]));
      end
      if (code == 0) begin tot_xfer++; tot_bytes += int'(d_len[i]); t_cok++; end else t_cerr++;
      for (int k = 0; k < nb && k < MAXBEAT; k++) wseen[k] = 1'b0;
      chk_idx = i;
      chk_req = 1'b1;
    end
    n_prod++;
  end
  // memory comparison right after the production edge (non-blocking updates of that edge applied)
  initial forever begin
    @(posedge clk);
    if (chk_req) begin
      #0.002;
      check_mem($sformatf("after transfer %0d", chk_idx));
      chk_req = 1'b0;
    end
  end

  // ============================================================== DMA request / response monitors
  task automatic mon_req(input int q, input bit is_spm_port, input logic w, input logic [31:0] a,
                         input logic [DW-1:0] wd, input logic [SB-1:0] ws);
    int i;
    i = n_prod;
    if (i >= n_sub) err($sformatf("spurious DMA request a=%h (no active descriptor)", a));
    else mon_req_body(q, i, is_spm_port, w, a, wd, ws);
  endtask
  task automatic mon_req_body(input int q, input int i, input bit is_spm_port, input logic w, input logic [31:0] a,
                              input logic [DW-1:0] wd, input logic [SB-1:0] ws);
    int nb, k, sgo;
    if (d_t_req[i] == 0) d_t_req[i] = cyc;
    if (is_spm_port != in_spm(a)) err($sformatf("request a=%h on the wrong target (spm port=%0d)", a, is_spm_port));
    nb = nbeats(d_len[i]);
    if (!w) begin
      d_rd[i]++; t_reads++;
      if (a < d_src[i] || a >= d_src[i] + 32'(nb * SB) || (a % SB) != 0)
        err($sformatf("transfer %0d: read a=%h outside [%h, +%0d)", i, a, d_src[i], d_len[i]));
    end else begin
      d_wr[i]++; t_writes++;
      k = int'(a - d_dst[i]) / SB;
      if (a < d_dst[i] || k >= nb || (a % SB) != 0)
        err($sformatf("transfer %0d: write a=%h outside [%h, +%0d)", i, a, d_dst[i], d_len[i]));
      else begin
        if (wseen[k]) err($sformatf("transfer %0d: duplicate write of beat %0d", i, k));
        wseen[k] = 1'b1;
        if (ws !== strb_of(k, nb, d_len[i])) err($sformatf("transfer %0d beat %0d: strobe %b", i, k, ws));
        sgo = goff(d_src[i]) + k * SB;
        for (int b = 0; b < SB; b++)
          if (ws[b] && wd[b*8 +: 8] !== refm[sgo + b])
            err($sformatf("transfer %0d beat %0d byte %0d: wrote %02h, source %02h", i, k, b, wd[b*8 +: 8], refm[sgo + b]));
      end
    end
    if (is_spm_port) t_spm++; else t_fab++;
    af_idx[q][af_wp[q] % 32] = i; af_w[q][af_wp[q] % 32] = w;
    af_nb[q][af_wp[q] % 32] = $countones(ws);
    af_wp[q]++;
  endtask
  task automatic mon_rsp(input int q, input logic e);
    int i;
    if (af_rp[q] == af_wp[q]) err("DMA response without an outstanding request");
    else begin
      i = af_idx[q][af_rp[q] % 32];
      if (e) t_berr++;
      else if (af_w[q][af_rp[q] % 32]) begin d_wr_ok[i]++; t_bwr += af_nb[q][af_rp[q] % 32]; end
      else t_brd += SB;
      af_rp[q]++;
    end
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      for (int p = 0; p < NP; p++) if (p_req_valid[NVEC + p] === 1'b1 || m_req_valid[p] === 1'b1)
        if (cyc > 2) err("DMA request presented during reset");
    end else begin
      for (int p = 0; p < NP; p++) begin
        if (p_rsp_valid[NVEC + p] && p_rsp_ready[NVEC + p]) begin
          mon_rsp(p, p_rsp_err[NVEC + p] || inj_now[p]);
          if (inj_now[p]) begin inj_hits++; t_terr++; end
        end
        if (m_rsp_valid[p] && m_rsp_ready[p]) mon_rsp(NP + p, m_rsp_error[p]);
        if (p_req_valid[NVEC + p] && p_req_ready[NVEC + p])
          mon_req(p, 1'b1, p_req_we[NVEC + p], p_req_addr[(NVEC + p)*32 +: 32], p_req_wdata[(NVEC + p)*DW +: DW],
                  p_req_wstrb[(NVEC + p)*SB +: SB]);
        if (m_req_valid[p] && m_req_ready[p])
          mon_req(NP + p, 1'b0, m_req_write[p], m_req_addr[p*32 +: 32], m_req_wdata[p*DW +: DW], m_req_wstrb[p*SB +: SB]);
      end
    end
  end

  // ============================================================== host BFM (fabric master NP): scratch of MEM0/MEM1
  logic [7:0] hsh [0:2*SCR-1];                          // host shadow: [0,SCR) MEM0 scratch, [SCR,2SCR) MEM1 scratch
  logic        h_v = 1'b0, h_w = 1'b0, h_rr = 1'b0;
  logic [31:0] h_a = '0;
  logic [DW-1:0] h_d = '0;
  logic [SB-1:0] h_s = '0;
  int unsigned h_rng = 5, h_ops = 0;
  logic [DW-1:0] h_exp [0:3];
  bit          h_isw [0:3];
  int          h_rp = 0, h_wp = 0;
  assign m_req_valid[NP] = h_v;
  assign m_req_write[NP] = h_w;
  assign m_req_addr[NP*32 +: 32] = h_a;
  assign m_req_wdata[NP*DW +: DW] = h_d;
  assign m_req_wstrb[NP*SB +: SB] = h_s;
  assign m_rsp_ready[NP] = h_rr;
  function automatic int hoff(input logic [31:0] a);
    return ((a & ~32'(EXTB - 1)) == M1_BASE) ? SCR + int'(a - M1_BASE) : int'(a - M0_BASE);
  endfunction
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      h_v <= 1'b0; h_rr <= 1'b0; h_rp = 0; h_wp = 0;
    end else begin
      h_rng = xs(h_rng); h_rr <= (h_rng % 100) >= hbp;
      if (m_rsp_valid[NP] && m_rsp_ready[NP]) begin
        if (h_rp == h_wp) err("host: response without request");
        else begin
          if (m_rsp_error[NP]) err("host: error response in its scratch region");
          if (!h_isw[h_rp % 4] && m_rsp_rdata[NP*DW +: DW] !== h_exp[h_rp % 4])
            err($sformatf("host: read data %h, expected %h", m_rsp_rdata[NP*DW +: DW], h_exp[h_rp % 4]));
          h_rp++;
        end
      end
      if (h_v && m_req_ready[NP]) begin
        logic [DW-1:0] e;
        int o;
        o = hoff(h_a);
        for (int b = 0; b < SB; b++) e[b*8 +: 8] = hsh[o + b];
        if (h_w) for (int b = 0; b < SB; b++) if (h_s[b]) hsh[o + b] = h_d[b*8 +: 8];
        h_exp[h_wp % 4] = e; h_isw[h_wp % 4] = h_w; h_wp++; h_ops++;
      end
      if (!h_v || m_req_ready[NP]) begin
        h_rng = xs(h_rng);
        if ((h_rng % 100) < host_act) begin
          h_v <= 1'b1;
          h_rng = xs(h_rng); h_w <= h_rng[3];
          h_rng = xs(h_rng);
          h_a <= (h_rng[7] ? M1_BASE : M0_BASE) + 32'(((h_rng >> 8) % (SCR / SB)) * SB);
          for (int k = 0; k < SB; k++) begin h_rng = xs(h_rng); h_d[k*8 +: 8] <= h_rng[15:8]; end
          h_rng = xs(h_rng); h_s <= (h_rng % 3 == 0) ? SB'(h_rng >> 4) : '1;
        end else h_v <= 1'b0;
      end
    end
  end

  // ============================================================== vector-lane BFMs on scratchpad ports 0..NVEC-1
  logic [7:0] vsh [0:SCR-1];
  int unsigned vec_ops = 0;
  for (g = 0; g < NVEC; g++) begin : g_vec
    logic          v_v = 1'b0, v_w = 1'b0, v_rr = 1'b0;
    logic [31:0]   v_a = '0;
    logic [DW-1:0] v_d = '0;
    logic [SB-1:0] v_s = '0;
    logic [STW-1:0] v_t = '0;
    int unsigned   v_rng;
    logic [DW-1:0] v_exp [0:31];
    bit            v_isw [0:31];
    logic [STW-1:0] v_etag [0:31];
    int            v_rp = 0, v_wp = 0;
    assign p_req_valid[g] = v_v;
    assign p_req_we[g] = v_w;
    assign p_req_addr[g*32 +: 32] = v_a;
    assign p_req_wdata[g*DW +: DW] = v_d;
    assign p_req_wstrb[g*SB +: SB] = v_s;
    assign p_req_tag[g*STW +: STW] = v_t;
    assign p_rsp_ready[g] = v_rr;
    initial v_rng = 32'h1234_5 + 77 * g;
    always @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        v_v <= 1'b0; v_rr <= 1'b0; v_rp = 0; v_wp = 0;
      end else begin
        v_rng = xs(v_rng); v_rr <= (v_rng % 100) >= vbp;
        if (p_rsp_valid[g] && p_rsp_ready[g]) begin
          if (v_rp == v_wp) err("vector: response without request");
          else begin
            if (p_rsp_err[g]) err("vector: error response");
            if (p_rsp_tag[g*STW +: STW] !== v_etag[v_rp % 32]) err("vector: response tag out of order");
            if (!v_isw[v_rp % 32] && p_rsp_rdata[g*DW +: DW] !== v_exp[v_rp % 32])
              err($sformatf("vector %0d: read %h expected %h", g, p_rsp_rdata[g*DW +: DW], v_exp[v_rp % 32]));
            v_rp++;
          end
        end
        if (v_v && p_req_ready[g]) begin
          logic [DW-1:0] e;
          int o;
          o = int'(v_a - SPM_BASE);
          for (int b = 0; b < SB; b++) e[b*8 +: 8] = vsh[o + b];
          if (v_w) for (int b = 0; b < SB; b++) if (v_s[b]) vsh[o + b] = v_d[b*8 +: 8];
          v_exp[v_wp % 32] = e; v_isw[v_wp % 32] = v_w; v_etag[v_wp % 32] = v_t; v_wp++; vec_ops++;
          v_t <= v_t + 1'b1;
        end
        if ((!v_v || p_req_ready[g]) && (v_wp - v_rp) < 24) begin
          v_rng = xs(v_rng);
          if ((v_rng % 100) < vec_act) begin
            v_v <= 1'b1;
            v_rng = xs(v_rng); v_w <= v_rng[5];
            v_rng = xs(v_rng);
            v_a <= SPM_BASE + 32'(g * VSL) + 32'(((v_rng >> 4) % (VSL / SB)) * SB);
            for (int k = 0; k < SB; k++) begin v_rng = xs(v_rng); v_d[k*8 +: 8] <= v_rng[23:16]; end
            v_rng = xs(v_rng); v_s <= (v_rng % 4 == 0) ? SB'(v_rng >> 4) : '1;
          end else v_v <= 1'b0;
        end else if (v_v && !p_req_ready[g]) begin
          // hold (SPM H2)
        end else v_v <= 1'b0;
      end
    end
  end


  // ============================================================== watchdog
  int unsigned last_prog = 0;
  always @(posedge clk) begin
    if (ev_cmd_accept || ev_cpl || (cpl_valid && cpl_ready) || |(m_req_valid[NP-1:0] & m_req_ready[NP-1:0]) ||
        |(p_req_valid[NVEC +: NP] & p_req_ready[NVEC +: NP]) || !busy) last_prog = cyc;
    if (cyc - last_prog > 30000) begin
      err("deadlock: no DMA progress for 30000 cycles");
      last_prog = cyc;
    end
  end

  // ============================================================== reset handling
  task automatic resync_shadows();
    bd_do(2);
    for (int o = 0; o < SCR; o++) begin hsh[o] = act(o); hsh[SCR + o] = act(EXTB + o); vsh[o] = act(2*EXTB + o); end
  endtask
  task automatic epoch_reset();
    n_sub = 0; n_prod = 0; n_cpl = 0;
    for (int q = 0; q < 2*NP; q++) begin af_rp[q] = 0; af_wp[q] = 0; end
    t_reads = 0; t_writes = 0; t_spm = 0; t_fab = 0; t_brd = 0; t_bwr = 0; t_berr = 0; t_terr = 0;
    t_cok = 0; t_cerr = 0; inj_hits = 0;
    for (int k = 0; k < MAXBEAT; k++) wseen[k] = 1'b0;
  endtask
  task automatic do_reset(input int cycles);
    int i;
    // the transfer in progress may have written any of its beats
    i = n_prod;
    if (i < n_sub && d_code[i] != 11 && !(d_code[i] >= 1 && d_code[i] <= 7)) begin
      int nb, dg, sg;
      nb = nbeats(d_len[i]); dg = goff(d_dst[i]); sg = goff(d_src[i]);
      if (dg >= 0 && sg >= 0)
        for (int k = 0; k < nb; k++) if (acc_ok(d_dst[i] + 32'(k*SB))) add_unc(dg + k*SB, sg + k*SB, strb_of(k, nb, d_len[i]));
    end
    @(negedge clk);
    rst_n = 1'b0;
    cmd_valid <= 1'b0;
    repeat (cycles) @(negedge clk);
    epoch_reset();
    rst_n = 1'b1;
    @(posedge clk);
    t_cyc0 = cyc;
    check_mem("after reset");
    resync_shadows();
  endtask

  // ============================================================== waits and checks
  task automatic drain(input string what);
    int unsigned t0;
    t0 = cyc;
    while (n_cpl < n_sub && cyc - t0 < 400000) @(posedge clk);
    if (n_cpl < n_sub) err($sformatf("%s: %0d of %0d transfers never completed", what, n_sub - n_cpl, n_sub));
    repeat (4) @(posedge clk);
    if (busy) err($sformatf("%s: adapter busy after all completions", what));
  endtask
  task automatic check_perf(input string what);
    int unsigned c;
    c = cyc - t_cyc0;
    if (pc(`HPC_DMA_PC_READS) != t_reads)     err($sformatf("%s perf READS %0d vs TB %0d", what, pc(`HPC_DMA_PC_READS), t_reads));
    if (pc(`HPC_DMA_PC_WRITES) != t_writes)   err($sformatf("%s perf WRITES %0d vs TB %0d", what, pc(`HPC_DMA_PC_WRITES), t_writes));
    if (pc(`HPC_DMA_PC_SPM_REQ) != t_spm)     err($sformatf("%s perf SPM_REQ %0d vs TB %0d", what, pc(`HPC_DMA_PC_SPM_REQ), t_spm));
    if (pc(`HPC_DMA_PC_FAB_REQ) != t_fab)     err($sformatf("%s perf FAB_REQ %0d vs TB %0d", what, pc(`HPC_DMA_PC_FAB_REQ), t_fab));
    if (pc(`HPC_DMA_PC_BYTES_RD) != t_brd)    err($sformatf("%s perf BYTES_RD %0d vs TB %0d", what, pc(`HPC_DMA_PC_BYTES_RD), t_brd));
    if (pc(`HPC_DMA_PC_BYTES_WR) != t_bwr)    err($sformatf("%s perf BYTES_WR %0d vs TB %0d", what, pc(`HPC_DMA_PC_BYTES_WR), t_bwr));
    if (pc(`HPC_DMA_PC_BUS_ERR) != t_berr)    err($sformatf("%s perf BUS_ERR %0d vs TB %0d", what, pc(`HPC_DMA_PC_BUS_ERR), t_berr));
    if (pc(`HPC_DMA_PC_TAG_ERR) != t_terr)    err($sformatf("%s perf TAG_ERR %0d vs TB %0d", what, pc(`HPC_DMA_PC_TAG_ERR), t_terr));
    if (pc(`HPC_DMA_PC_CPL_OK) != t_cok)      err($sformatf("%s perf CPL_OK %0d vs TB %0d", what, pc(`HPC_DMA_PC_CPL_OK), t_cok));
    if (pc(`HPC_DMA_PC_CPL_ERR) != t_cerr)    err($sformatf("%s perf CPL_ERR %0d vs TB %0d", what, pc(`HPC_DMA_PC_CPL_ERR), t_cerr));
    if (pc(`HPC_DMA_PC_OUT_MAX) > NP * RMO)   err($sformatf("%s perf OUT_MAX %0d > %0d", what, pc(`HPC_DMA_PC_OUT_MAX), NP * RMO));
    if (pc(`HPC_DMA_PC_CYCLES) + 2 < c || pc(`HPC_DMA_PC_CYCLES) > c + 2)
      err($sformatf("%s perf CYCLES %0d vs TB %0d", what, pc(`HPC_DMA_PC_CYCLES), c));
    if (pc(`HPC_DMA_PC_ACTIVE) > pc(`HPC_DMA_PC_CYCLES)) err("perf ACTIVE > CYCLES");
  endtask

  // ============================================================== stimulus helpers
  // regions usable by the DMA: 0 = MEM0, 1 = MEM1, 2 = scratchpad; each [base+SCR, base+size)
  function automatic logic [31:0] rbase(input int r);
    return (r == 0) ? M0_BASE : (r == 1) ? M1_BASE : SPM_BASE;
  endfunction
  // random non-overlapping (src, dst) for a length, in regions rs / rd (word aligned)
  task automatic pick(input int rs, input int rd, input int len, output logic [31:0] s, output logic [31:0] d);
    int span, tries;
    span = EXTB - SCR;
    tries = 0;
    do begin
      s = rbase(rs) + 32'(SCR) + 32'(rnd((span - len) / SB + 1) * SB);
      d = rbase(rd) + 32'(SCR) + 32'(rnd((span - len) / SB + 1) * SB);
      tries++;
    end while (rs == rd && (longint'(s) < longint'(d) + len && longint'(d) < longint'(s) + len) && tries < 1000);
  endtask
  task automatic xfer(input int rs, input int rd, input int len);
    logic [31:0] s, d;
    pick(rs, rd, len, s, d);
    submit(s, d, 32'(len), 1'b0);
  endtask
  // the four directions: E->S, S->E, S->S, E->E with random external bank
  task automatic xfer_dir(input int dir, input int len);
    int e1, e2;
    e1 = rnd(2); e2 = rnd(2);
    case (dir)
      0: xfer(e1, 2, len);
      1: xfer(2, e1, len);
      2: xfer(2, 2, len);
      default: xfer(e1, e2, len);
    endcase
  endtask

  // ============================================================== tests
  int unsigned max_fifo = 0, max_out_seen = 0, n_abort_must = 0;
  always @(posedge clk) begin
    if (int'(fifo_level) > max_fifo) max_fifo = fifo_level;
    if (int'(ev_out) > max_out_seen) max_out_seen = ev_out;
  end

  task automatic t_smoke();
    for (int dir = 0; dir < 4; dir++) begin xfer_dir(dir, 64); xfer_dir(dir, 13); end
    drain("smoke");
  endtask
  task automatic t_len1();
    for (int dir = 0; dir < 4; dir++) repeat (6) xfer_dir(dir, 1);
    drain("len1");
  endtask
  task automatic t_tails();
    for (int dir = 0; dir < 4; dir++)
      for (int len = 1; len <= 3 * SB + 1; len++) xfer_dir(dir, len);
    drain("tails");
  endtask
  task automatic t_aligned();
    for (int dir = 0; dir < 4; dir++)
      for (int k = 1; k <= 9; k++) xfer_dir(dir, k * SB);
    drain("aligned");
  endtask
  task automatic t_long();
    for (int dir = 0; dir < 4; dir++) xfer_dir(dir, 12288);
    xfer(0, 2, EXTB - SCR);  xfer(2, 1, EXTB - SCR);
    drain("long");
  endtask
  task automatic t_consec();
    for (int t = 0; t < n_trans; t++) xfer_dir(rnd(4), 1 + rnd(300));
    drain("consec");
  endtask
  task automatic t_random();
    for (int t = 0; t < n_trans; t++) begin
      int c;
      c = rnd(100);
      if (c < 3)       submit(rbase(rnd(3)) + 32'(SCR + rnd(64) * SB), rbase(rnd(3)) + 32'(SCR + rnd(64) * SB) + 32'(rnd(2)), 32'(rnd(40)), 1'b0);
      else if (c < 6)  submit(32'h3000_0000 + 32'(rnd(16) * SB), rbase(2) + 32'(SCR), 32'(1 + rnd(64)), 1'b0);
      else if (c < 8)  submit(rbase(2) + 32'(SPMB - 16), rbase(0) + 32'(SCR), 32'(17 + rnd(40)), 1'b0);
      else             xfer_dir(rnd(4), (rnd(10) == 0) ? 1 + rnd(4096) : 1 + rnd(200));
    end
    drain("random");
  endtask
  task automatic t_invalid();
    logic [31:0] s, d;
    pick(0, 2, 64, s, d);
    submit(s, d, 32'd0, 1'b0);                                           // ZERO_LENGTH
    submit(s, d, 32'((1 << MLL) + 1), 1'b0);                             // LENGTH
    submit(s + 32'd1, d, 32'd8, 1'b0);                                   // SRC_ALIGN
    submit(s, d + 32'd2, 32'd8, 1'b0);                                   // DST_ALIGN
    submit(32'hFFFF_FFF0, d, 32'h20, 1'b0);                              // SRC_OVERFLOW
    submit(s, 32'hFFFF_FFF0, 32'h20, 1'b0);                              // DST_OVERFLOW
    submit(SPM_BASE + 32'(SCR), SPM_BASE + 32'(SCR + 8), 32'd16, 1'b0);  // OVERLAP
    submit(SPM_BASE + 32'(SCR), SPM_BASE + 32'(SCR), 32'd4, 1'b0);       // OVERLAP (src == dst)
    submit(SPM_BASE + 32'(SPMB - 8), s, 32'd16, 1'b0);                   // REGION: source leaves the window
    submit(s, SPM_BASE - 32'd8, 32'd16, 1'b0);                           // REGION: destination enters it
    submit(SPM_BASE - 32'd8, d, 32'd4, 1'b0);                            // outside, next to the window: decode error (READ_BUS)
    submit(32'h3000_0000, d, 32'd64, 1'b0);                              // unmapped source -> READ_BUS, no write
    submit(s, 32'h3000_0000, 32'd64, 1'b0);                              // unmapped destination -> WRITE_BUS
    submit(SPM_BASE + 32'(SPMB), d, 32'd8, 1'b0);                        // just above the window: fabric decode error
    submit(M0_BASE + 32'(EXTB - 40), SPM_BASE + 32'(SCR), 32'd100, 1'b0); // runs off MEM0 into unmapped space
    submit(SPM_BASE + 32'(SCR + 64), M1_BASE + 32'(EXTB - 24), 32'd60, 1'b0); // writes off the end of MEM1
    drain("invalid");
  endtask
  task automatic t_buserr();
    for (int t = 0; t < 24; t++) begin
      logic [31:0] s, d;
      int len, k, side;
      len  = 4 + rnd(200);
      side = rnd(2);                                                     // 0: poison in the source, 1: in the destination
      if (side == 0) pick(1, rnd(2) == 0 ? 2 : 0, len, s, d); else pick(rnd(2) == 0 ? 2 : 0, 1, len, s, d);
      k = rnd(nbeats(32'(len)));
      poison = int'(((side == 0) ? s : d) - M1_BASE) + k * SB;
      submit(s, d, 32'(len), 1'b0);
      drain("buserr");
      poison = -1;
    end
  endtask
  task automatic t_tagerr();
    for (int t = 0; t < 12; t++) begin
      int len, k, nb;
      len = 8 + rnd(120);
      nb = nbeats(32'(len));
      k = rnd(nb);
      inj_port = (t % 2 == 0) ? NP - 1 : 0;                         // write port for E->S, read port for S->E
      inj_at = spm_rsp_cnt(inj_port) + 32'(k);
      if (t % 2 == 0) xfer(rnd(2), 2, len); else xfer(2, rnd(2), len);
      // predicted outcome: the k-th scratchpad response of this transfer fails the ownership check
      if (t % 2 == 0) begin d_code[n_sub-1] = 9; d_eaddr[n_sub-1] = d_dst[n_sub-1] + 32'(k * SB); end
      else            begin d_code[n_sub-1] = 8; d_eaddr[n_sub-1] = d_src[n_sub-1] + 32'(k * SB); end
      d_bytes[n_sub-1] = k * SB;
      drain("tagerr");
      inj_at = 32'hFFFF_FFFF;
    end
  endtask
  task automatic t_spmerr();
    // byte-parity scratchpad: a corrupted source word makes the DMA read fail with PARITY -> READ_BUS
    if (SPM_ECC == 0) err("spmerr needs SPM_ECC = 1");
    for (int t = 0; t < 16; t++) begin
      logic [31:0] s, d;
      int len, k, o;
      len = 4 + rnd(200);
      pick(2, rnd(2), len, s, d);
      k = rnd(nbeats(32'(len)));
      o = int'(s - SPM_BASE) + k * SB;                     // corrupted word: byte offset in the scratchpad
      bd_word = o / SB; bd_bit = rnd(SB) * LANEW + rnd(8); // flip a DATA bit: stored byte changes, parity fails
      bd_do(3);
      refm[2*EXTB + o + bd_bit / LANEW] = refm[2*EXTB + o + bd_bit / LANEW] ^ (8'd1 << (bd_bit % LANEW));
      submit(s, d, 32'(len), 1'b0);
      d_code[n_sub-1] = 8; d_eaddr[n_sub-1] = s + 32'(k * SB); d_bytes[n_sub-1] = k * SB;
      drain("spmerr");
      for (int b = 0; b < SPMB; b++) spm_load[b] = refm[2*EXTB + b];      // repair the parity
      bd_do(1);
    end
    if (pc(`HPC_DMA_PC_BUS_ERR) != 16) err($sformatf("spmerr: %0d bus errors counted, expected 16", pc(`HPC_DMA_PC_BUS_ERR)));
  endtask
  task automatic t_buffull();
    // fast source (scratchpad), slow destination (MEM1: heavy back-pressure and latency)
    bp = 70; lmin = 4; lmax = 12;
    xfer(2, 1, 4096); xfer(2, 1, 1000);
    drain("buffull");
    // single port: READ/WRITE phases of at most BURST beats -> the FIFO can only fill to min(BURST, FIFO_DEPTH);
    // dual port: reads run ahead of the slow writes until the credit (FIFO_DEPTH) is exhausted
    if (ENGINE != 0 && max_fifo != ((DUAL_PORT != 0 || BURST > FIFO_DEPTH) ? FIFO_DEPTH : BURST))
      err($sformatf("buffull: FIFO peaked at %0d (FIFO_DEPTH %0d, BURST %0d, DUAL_PORT %0d)", max_fifo, FIFO_DEPTH, BURST, DUAL_PORT));
    if (ENGINE != 0 && max_fifo > FIFO_DEPTH) err("buffull: FIFO occupancy above its depth");
    $display("TB_HPC_DMA INFO fifo_max=%0d of %0d", max_fifo, FIFO_DEPTH);
    bp = 0; lmin = 1; lmax = 3;
  endtask
  task automatic t_cplfull();
    // completion consumer stalled: the adapter must stop taking descriptors, lose nothing, deadlock nowhere
    int acc;
    bit stop;
    cbp = 100;
    repeat (2) @(posedge clk);
    acc = 0;
    stop = 1'b0;
    for (int t = 0; t < CPL_DEPTH + CMD_DEPTH + 3 && !stop; t++) begin
      logic [31:0] s, d;
      pick(0, 2, 32, s, d);
      d_src[n_sub] = s; d_dst[n_sub] = d; d_len[n_sub] = 32'd32; d_tag[n_sub] = 8'(tag_ctr); d_fuzzy[n_sub] = 1'b0;
      d_wr_ok[n_sub] = 0; d_rd[n_sub] = 0; d_wr[n_sub] = 0; d_t_req[n_sub] = 0;
      predict(n_sub);
      begin
        bit ok;
        present(s, d, 32'd32, 8'(tag_ctr), 400, ok);
        if (!ok) stop = 1'b1;
      end
      if (!stop) begin
        d_t_acc[n_sub] = cmd_hs_cyc; n_sub++; tag_ctr++; acc++;
        @(posedge clk);
      end
    end
    cmd_valid <= 1'b0;
    repeat (300) @(posedge clk);
    if (acc != CPL_DEPTH + CMD_DEPTH)
      err($sformatf("cplfull: %0d descriptors accepted while completions stalled, expected %0d", acc, CPL_DEPTH + CMD_DEPTH));
    if (n_prod != CPL_DEPTH) err($sformatf("cplfull: %0d completions produced into a %0d-entry queue", n_prod, CPL_DEPTH));
    if (cmd_ready && CMD_DEPTH > 0) err("cplfull: cmd_ready high with a full descriptor queue");
    cbp = 0;
    drain("cplfull");
  endtask
  task automatic t_finalwrite();
    // writes are performed only at the response handshake, responses are late: DONE must wait for the last one
    wcommit = 1; lmin = 8; lmax = 20; bp = 30;
    for (int t = 0; t < 40; t++) begin
      xfer(rnd(2) == 0 ? 2 : 0, 1, 1 + rnd(256));
      if (t % 4 == 0) drain("finalwrite");
    end
    drain("finalwrite");
    wcommit = 0; lmin = 1; lmax = 3; bp = 0;
  endtask
  // an abort sampled while the engine runs, with more than RMO+2 beats still unwritten, MUST end ABORTED
  bit d_abort_must [0:MAXD-1];
  always @(posedge clk) if (rst_n && cmd_abort && active && n_prod < n_sub)
    if (d_wr[n_prod] + RMO + 2 < nbeats(d_len[n_prod])) d_abort_must[n_prod] = 1'b1;
  task automatic t_abort();
    for (int t = 0; t < 60; t++) begin
      logic [31:0] s, d;
      int len, dir, e;
      len = 4 + rnd(600); dir = rnd(4); e = rnd(2);
      case (dir) 0: pick(e, 2, len, s, d); 1: pick(2, e, len, s, d); 2: pick(2, 2, len, s, d); default: pick(e, 1 - e, len, s, d); endcase
      fork
        submit(s, d, 32'(len), 1'b1);
        begin
          repeat (rnd(len + len / 2 + 40)) @(posedge clk);     // early, mid, racing the last beat, or after the end
          cmd_abort <= 1'b1; @(posedge clk); cmd_abort <= 1'b0;
        end
      join
      drain("abort");
    end
  endtask
  task automatic t_reset();
    for (int t = 0; t < 30; t++) begin
      int len;
      len = 64 + rnd(2000);
      xfer_dir(rnd(4), len);
      if (rnd(2) == 0) xfer_dir(rnd(4), 1 + rnd(100));             // a queued one too (dropped by the reset)
      repeat (3 + rnd(len / 2)) @(posedge clk);
      do_reset(1 + rnd(4));
      // nothing may move after the reset until a new descriptor arrives
      repeat (40) @(posedge clk);
      if (busy || cpl_valid) err("reset: adapter busy or completion visible after reset");
      xfer_dir(rnd(4), 1 + rnd(200));
      drain("after reset");
    end
  endtask

  // trace: cycle-by-cycle view of short transfers on an idle system (source of docs/05_timing.md)
  int unsigned trace_on = 0;
  always @(posedge clk) if (trace_on != 0)
    $display("TRACE cyc=%0d cmd_v=%0d cmd_r=%0d ctl=%0d eng=%0d spm_req=%0d%0d%0d fab_req=%0d%0d%0d spm_rsp=%0d fab_rsp=%0d cpl_v=%0d busy=%0d active=%0d out=%0d",
             cyc, cmd_valid, cmd_ready, ctl_state, eng_state,
             p_req_valid[NVEC], p_req_ready[NVEC], p_req_we[NVEC], m_req_valid[0], m_req_ready[0], m_req_write[0],
             p_rsp_valid[NVEC], m_rsp_valid[0], cpl_valid, busy, active, ev_out);
  task automatic t_trace();
    bp = 0; lmin = 1; lmax = 1;
    repeat (2) @(posedge clk);
    $display("TRACE_BEGIN E2S len=8 (MEM0 -> scratchpad)");
    trace_on = 1; xfer(0, 2, 8); drain("trace"); trace_on = 0;
    $display("TRACE_BEGIN S2E len=8 (scratchpad -> MEM1, 1-cycle slave)");
    trace_on = 1; xfer(2, 1, 8); drain("trace"); trace_on = 0;
    $display("TRACE_BEGIN E2S len=1 queued behind S2E len=4");
    trace_on = 1; xfer(2, 0, 4); xfer(0, 2, 1); drain("trace"); trace_on = 0;
  endtask

  // perf: directed transfers on an otherwise idle system; cycles from descriptor accept to cpl_valid
  task automatic t_perf();
    int lens [0:5];
    string dn [0:3];
    // 6144 B max: two disjoint ranges must fit in the 14 KiB DMA area of one memory (SPM->SPM)
    lens[0] = 4; lens[1] = 64; lens[2] = 256; lens[3] = 1024; lens[4] = 4096; lens[5] = 6144;
    dn[0] = "EXT->SPM"; dn[1] = "SPM->EXT"; dn[2] = "SPM->SPM"; dn[3] = "EXT->EXT";
    bp = 0; lmin = 1; lmax = 1;                                   // deterministic: every slave answers in 1 cycle
    for (int dir = 0; dir < 4; dir++)
      for (int li = 0; li < 6; li++) begin
        int i;
        if (dir == 0) xfer(0, 2, lens[li]); else if (dir == 1) xfer(2, 0, lens[li]);
        else if (dir == 2) xfer(2, 2, lens[li]); else xfer(0, 1, lens[li]);
        i = n_sub - 1;
        drain("perf");
        if (d_code[i] != 0) err($sformatf("perf transfer %s len %0d was not a successful transfer (code %0d)", dn[dir], lens[li], d_code[i]));
        $display("TB_HPC_DMA PERF dir=%s len=%0d accept_to_first_req=%0d accept_to_cpl=%0d bytes_per_cycle=%0.3f",
                 dn[dir], lens[li], d_t_req[i] - d_t_acc[i], d_t_cpl[i] - d_t_acc[i],
                 real'(lens[li]) / real'(d_t_cpl[i] - d_t_acc[i]));
      end
  endtask

  // ============================================================== main
  initial begin
    void'($value$plusargs("test=%s", test));
    void'($value$plusargs("seed=%d", seed));
    void'($value$plusargs("n=%d", n_trans));
    void'($value$plusargs("bp=%d", bp));
    void'($value$plusargs("lmin=%d", lmin));
    void'($value$plusargs("lmax=%d", lmax));
    void'($value$plusargs("wcommit=%d", wcommit));
    void'($value$plusargs("host=%d", host_act));
    void'($value$plusargs("vec=%d", vec_act));
    void'($value$plusargs("vbp=%d", vbp));
    void'($value$plusargs("hbp=%d", hbp));
    void'($value$plusargs("cbp=%d", cbp));
    void'($value$plusargs("gap=%d", gap));
    void'($value$plusargs("dbg=%d", dbg));
    trng = seed * 32'h9E37_79B9 + 1;
    s1rng = seed * 7 + 3; h_rng = seed * 13 + 5; cpl_rng = seed * 17 + 9;
    if (test == "contention") begin host_act = 70; vec_act = 70; vbp = 30; hbp = 20; end
    if (test == "bp") begin bp = 60; lmin = 1; lmax = 9; cbp = 60; gap = 6; vbp = 50; end
    epoch_reset();
    #1;
    mem_init();
    for (int o = 0; o < SCR; o++) begin hsh[o] = refm[o]; hsh[SCR + o] = refm[EXTB + o]; vsh[o] = refm[2*EXTB + o]; end
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    @(posedge clk);
    t_cyc0 = cyc;
    if (test == "smoke") t_smoke();
    else if (test == "len1") t_len1();
    else if (test == "tails") t_tails();
    else if (test == "aligned") t_aligned();
    else if (test == "long") t_long();
    else if (test == "consec") t_consec();
    else if (test == "bp") t_consec();
    else if (test == "contention") t_consec();
    else if (test == "random") t_random();
    else if (test == "invalid") t_invalid();
    else if (test == "buserr") t_buserr();
    else if (test == "tagerr") t_tagerr();
    else if (test == "buffull") t_buffull();
    else if (test == "spmerr") t_spmerr();
    else if (test == "cplfull") t_cplfull();
    else if (test == "finalwrite") t_finalwrite();
    else if (test == "abort") t_abort();
    else if (test == "reset") t_reset();
    else if (test == "perf") t_perf();
    else if (test == "trace") t_trace();
    else err($sformatf("unknown test %0s", test));
    repeat (20) @(posedge clk);
    if (test != "reset") check_perf(test);
    if (test == "contention" && (h_ops == 0 || (NVEC > 0 && vec_ops == 0))) err("contention: background traffic did not run");
    if (viol_total() != 0) err($sformatf("%0d SFB2 protocol violations", viol_total()));
    $display("TB_HPC_DMA STATS test=%0s abort_must=%0d transfers_ok=%0d bytes=%0d err_cpl=%0d mem_checks=%0d unc_new=%0d unc_old=%0d host_ops=%0d vec_ops=%0d fifo_max=%0d out_max=%0d cycles=%0d active=%0d stall=%0d rsp_wait=%0d out_sum=%0d",
             test, n_abort_must, tot_xfer, tot_bytes, tot_err_cpl, n_checks, n_unc_new, n_unc_old, h_ops, vec_ops, max_fifo, max_out_seen,
             pc(`HPC_DMA_PC_CYCLES), pc(`HPC_DMA_PC_ACTIVE), pc(`HPC_DMA_PC_REQ_STALL), pc(`HPC_DMA_PC_RSP_WAIT), pc(`HPC_DMA_PC_OUT_SUM));
    if (errors == 0) $display("TB_HPC_DMA RESULT PASS test=%0s seed=%0d errors=0", test, seed);
    else             $display("TB_HPC_DMA RESULT FAIL test=%0s seed=%0d errors=%0d", test, seed, errors);
    $finish;
  end
  initial begin
    #200ms;
    $display("TB_HPC_DMA ERROR global timeout");
    $display("TB_HPC_DMA RESULT FAIL test=%0s seed=%0d errors=%0d", test, seed, errors + 1);
    $finish;
  end
endmodule

`default_nettype wire
