// =============================================================================
// SilicaFlux-HPC Module 05 :: tb_hpc_tile -- integration test
//   host writes operands -> DMA into the scratchpad -> vector array computes ->
//   DMA results out -> the testbench compares the final memory contents.
//
//   host BFM ----------------+
//                            +--> sfb_crossbar (DataFabric) --> SRAM0 0x1000_0000 32 KiB (sfb_sram_slave)
//   hpc_dma_adapter fabric --+                              --> SRAM1 0x1000_8000 32 KiB (sfb_sram_slave)
//   hpc_dma_adapter spm  --> hpc_scratchpad 0x2000_0000 64 KiB, 4 banks (Module 04), port 1 (+2)
//   hpc_tile_vseq        --> hpc_scratchpad port 0 ;  hpc_tile_vseq <--> hpc_vector_array (Module 03, N lanes)
//
// Data: scripts/gen_integ.py (exact FP32 expectations), files read from the
// current directory.  Phase A (sequential, measured step by step):
//   host writes A, B, C (front door, through the crossbar) -> 3 DMA descriptors
//   ext->SPM -> D = A*B+C (FMADD), E = A + s (FADD, broadcast b), F = A*B (IMUL)
//   -> 3 DMA descriptors SPM->ext (E with a partial final word).
// Phase B (concurrent): 6 tiles of AXPY Z = alpha*X + Y, double-buffered in the
//   scratchpad: DMA-in of tile k+1, compute of tile k and DMA-out of tile k-1
//   overlap, while the host runs random traffic in its own SRAM scratch region.
// Final checks: host front-door read-back of every result word, then the whole
//   external memory (except the host scratch) and the whole scratchpad compared
//   byte by byte with the expected images; adapter counters; vector completion
//   records (count, illegal, scratchpad errors).
// Result line: "TB_HPC_TILE RESULT PASS|FAIL".
// =============================================================================
`timescale 1ns/1ps
`default_nettype none
`include "hpc_dma_defs.svh"

module tb_hpc_tile #(
  parameter int ENGINE     = 0,
  parameter int DUAL_PORT  = 0,
  parameter int FIFO_DEPTH = 8,
  parameter int MAX_OUT    = 2,
  parameter int CMD_DEPTH  = 4
);
  `include "integ_cfg.svh"
  localparam int N    = IG_LANES;
  localparam int NP   = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1;
  localparam int NM   = NP + 1;
  localparam int NSP  = 1 + NP;
  localparam int EXTB = 65536, SPMB = 65536;
  localparam logic [31:0] EXT_BASE = 32'h1000_0000, SPM_BASE = 32'h2000_0000;

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int unsigned cyc = 0, errors = 0;
  always @(posedge clk) cyc <= cyc + 1;
  task automatic err(input string m);
    errors++;
    if (errors <= 25) $display("TB_HPC_TILE ERROR cyc=%0d: %s", cyc, m);
  endtask
  function automatic int unsigned xs(input int unsigned r);
    int unsigned t;
    t = r ^ (r << 13); t = t ^ (t >> 17); t = t ^ (t << 5);
    return t;
  endfunction

  // ============================================================ fabric + external SRAM
  wire  [NM-1:0]    m_req_valid, m_req_write, m_rsp_ready;
  wire  [NM*32-1:0] m_req_addr;
  wire  [NM*32-1:0] m_req_wdata;
  wire  [NM*4-1:0]  m_req_wstrb;
  logic [NM-1:0]    m_req_ready, m_rsp_valid, m_rsp_error;
  logic [NM*32-1:0] m_rsp_rdata;
  logic [1:0]       s_req_valid, s_req_ready, s_req_write, s_rsp_valid, s_rsp_ready, s_rsp_error;
  logic [63:0]      s_req_addr, s_req_wdata, s_rsp_rdata;
  logic [7:0]       s_req_wstrb;
  logic [NM-1:0]    x_acc, x_stall, x_loss, x_rstall;
  logic             x_eevt, x_ewr;
  logic [31:0]      x_eaddr;
  logic [((NM > 1) ? $clog2(NM) : 1)-1:0] x_emst;
  sfb_crossbar #(.NM(NM), .NS(2), .AW(32), .DW(32), .ARB_MODE(1), .CHECK_ALIGN(1),
                 .SLV_BASE({32'h1000_8000, 32'h1000_0000}), .SLV_MASK({32'hFFFF_8000, 32'hFFFF_8000})) u_xbar (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_write, .m_req_addr, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_error,
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error,
    .err_evt(x_eevt), .err_addr(x_eaddr), .err_master(x_emst), .err_write(x_ewr),
    .ev_req_accept(x_acc), .ev_req_stall(x_stall), .ev_arb_loss(x_loss), .ev_rsp_stall(x_rstall));
  for (genvar s = 0; s < 2; s++) begin : g_sram
    logic [31:0] tr;
    sfb_sram_slave #(.DW(32), .DEPTH(8192), .READ_LATENCY(1)) u_m (
      .clk, .rst_n,
      .req_valid(s_req_valid[s]), .req_ready(s_req_ready[s]), .req_write(s_req_write[s]), .req_addr(s_req_addr[s*32 +: 32]),
      .req_wdata(s_req_wdata[s*32 +: 32]), .req_wstrb(s_req_wstrb[s*4 +: 4]),
      .rsp_valid(s_rsp_valid[s]), .rsp_ready(s_rsp_ready[s]), .rsp_rdata(s_rsp_rdata[s*32 +: 32]), .rsp_error(s_rsp_error[s]),
      .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr('0), .tst_wdata('0), .tst_rdata(tr));
  end

  // ============================================================ scratchpad
  wire  [NSP-1:0]     p_req_valid, p_req_we, p_rsp_ready;
  wire  [NSP*32-1:0]  p_req_addr, p_req_wdata;
  wire  [NSP*4-1:0]   p_req_wstrb;
  wire  [NSP*8-1:0]   p_req_tag;
  logic [NSP-1:0]     p_req_ready, p_rsp_valid, p_rsp_err, p_rsp_we;
  logic [NSP*32-1:0]  p_rsp_rdata;
  logic [NSP*8-1:0]   p_rsp_tag;
  logic [NSP*3-1:0]   p_rsp_code;
  logic [NSP*4-1:0]   p_rsp_syn;
  logic [NSP-1:0]     sp_acc, sp_iss, sp_conf, sp_cst, sp_err, sp_ecc;
  logic [7:0]         sp_bops;
  logic [3:0]         sp_bconf;
  logic [31:0]        sp_cyc, sp_eccn;
  logic [NSP*32-1:0]  sp_pacc, sp_piss, sp_pcpl, sp_pconf, sp_pwait, sp_perr;
  logic [127:0]       sp_pbops;
  logic               sp_busy;
  hpc_scratchpad #(.NUM_PORTS(NSP), .CAPACITY_BYTES(SPMB), .NUM_BANKS(4), .DATA_WIDTH(32), .ADDR_WIDTH(32),
                   .BASE_ADDR(64'(SPM_BASE)), .READ_LATENCY(1), .WRITE_ACK(1), .TAG_W(8)) u_spm (
    .clk, .rst_n,
    .req_valid(p_req_valid), .req_ready(p_req_ready), .req_we(p_req_we), .req_addr(p_req_addr),
    .req_wdata(p_req_wdata), .req_wstrb(p_req_wstrb), .req_tag(p_req_tag),
    .rsp_valid(p_rsp_valid), .rsp_ready(p_rsp_ready), .rsp_rdata(p_rsp_rdata), .rsp_err(p_rsp_err),
    .rsp_err_code(p_rsp_code), .rsp_we(p_rsp_we), .rsp_tag(p_rsp_tag), .rsp_ecc_syn(p_rsp_syn),
    .ev_accept(sp_acc), .ev_issue(sp_iss), .ev_conflict(sp_conf), .ev_credit_stall(sp_cst), .ev_error(sp_err),
    .ev_ecc_err(sp_ecc), .ev_bank_ops(sp_bops), .ev_bank_conflict(sp_bconf),
    .perf_clear(1'b0), .perf_cycles(sp_cyc), .perf_accept(sp_pacc), .perf_issue(sp_piss), .perf_complete(sp_pcpl),
    .perf_conflict(sp_pconf), .perf_wait(sp_pwait), .perf_error(sp_perr), .perf_bank_ops(sp_pbops),
    .perf_ecc_err(sp_eccn), .busy(sp_busy));

  // ============================================================ DMA adapter
  logic        cmd_valid = 1'b0, cmd_ready, cpl_valid, cpl_err;
  logic [31:0] cmd_src = '0, cmd_dst = '0, cmd_len = '0, cpl_err_addr, cpl_bytes, eng_bytes;
  logic [7:0]  cmd_tag = '0, cpl_tag, cur_tag;
  logic [3:0]  cpl_code;
  logic        d_busy, d_active, ev_cmd, ev_start, ev_cpl, ev_cpl_err, ev_stall, ev_berr, ev_terr;
  logic [1:0]  ctl_state;
  logic [2:0]  eng_state;
  logic [7:0]  fifo_level, ev_brd, ev_bwr, ev_out;
  logic [`HPC_DMA_NUM_PC*32-1:0] perf_cnt;
  hpc_dma_adapter #(.DW(32), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .BURST(FIFO_DEPTH), .DUAL_PORT(DUAL_PORT),
                    .MAX_OUT(MAX_OUT), .SPM_BASE(SPM_BASE), .SPM_BYTES(SPMB), .SPM_TAG_W(8), .CMD_DEPTH(CMD_DEPTH),
                    .CPL_DEPTH(4), .TAG_W(8)) u_dma (
    .clk, .rst_n,
    .cmd_valid, .cmd_ready, .cmd_src, .cmd_dst, .cmd_len, .cmd_tag, .cmd_abort(1'b0),
    .cpl_valid, .cpl_ready(1'b1), .cpl_tag, .cpl_err, .cpl_code, .cpl_err_addr, .cpl_bytes,
    .busy(d_busy), .active(d_active), .cur_tag, .ctl_state, .eng_state, .eng_bytes_done(eng_bytes), .fifo_level,
    .spm_req_valid(p_req_valid[1 +: NP]), .spm_req_ready(p_req_ready[1 +: NP]), .spm_req_we(p_req_we[1 +: NP]),
    .spm_req_addr(p_req_addr[32 +: NP*32]), .spm_req_wdata(p_req_wdata[32 +: NP*32]), .spm_req_wstrb(p_req_wstrb[4 +: NP*4]),
    .spm_req_tag(p_req_tag[8 +: NP*8]), .spm_rsp_valid(p_rsp_valid[1 +: NP]), .spm_rsp_ready(p_rsp_ready[1 +: NP]),
    .spm_rsp_rdata(p_rsp_rdata[32 +: NP*32]), .spm_rsp_err(p_rsp_err[1 +: NP]), .spm_rsp_err_code(p_rsp_code[3 +: NP*3]),
    .spm_rsp_we(p_rsp_we[1 +: NP]), .spm_rsp_tag(p_rsp_tag[8 +: NP*8]),
    .fab_req_valid(m_req_valid[NP-1:0]), .fab_req_ready(m_req_ready[NP-1:0]), .fab_req_write(m_req_write[NP-1:0]),
    .fab_req_addr(m_req_addr[NP*32-1:0]), .fab_req_wdata(m_req_wdata[NP*32-1:0]), .fab_req_wstrb(m_req_wstrb[NP*4-1:0]),
    .fab_rsp_valid(m_rsp_valid[NP-1:0]), .fab_rsp_ready(m_rsp_ready[NP-1:0]), .fab_rsp_rdata(m_rsp_rdata[NP*32-1:0]),
    .fab_rsp_error(m_rsp_error[NP-1:0]),
    .ev_cmd_accept(ev_cmd), .ev_start, .ev_cpl, .ev_cpl_err, .ev_bytes_rd(ev_brd), .ev_bytes_wr(ev_bwr),
    .ev_req_stall(ev_stall), .ev_outstanding(ev_out), .ev_bus_err(ev_berr), .ev_tag_err(ev_terr),
    .perf_clear(1'b0), .perf_cnt);
  function automatic int unsigned pc(input int i);
    return perf_cnt[i*32 +: 32];
  endfunction

  // ============================================================ vector sequencer + vector array (Module 03)
  logic        job_valid = 1'b0, job_ready, done_valid, done_illegal, done_err;
  logic [4:0]  job_op = '0, done_flags;
  logic [2:0]  job_rm = '0, job_bcast = '0;
  logic [15:0] job_vl = '0, done_count;
  logic [31:0] job_scalar = '0, job_a = '0, job_b = '0, job_c = '0, job_d = '0;
  logic [7:0]  job_tid = '0, done_tid;
  logic        v_busy;
  logic        c_valid, c_ready, o_valid, o_ready, r_valid, r_ready, k_valid, k_ready;
  logic [4:0]  c_op, k_flags;
  logic [2:0]  c_rm, c_bc;
  logic [15:0] c_vl, r_beat, k_count;
  logic [31:0] c_sc, k_result;
  logic [7:0]  c_tid, r_tid, k_tid;
  logic [N*32-1:0] o_a, o_b, o_c, r_data;
  logic [N*5-1:0]  r_flags;
  logic [N-1:0]    r_mask;
  logic            r_last, k_ill, k_red, va_busy;
  logic [hpc_varray_pkg::PC_N*32-1:0] va_perf;
  hpc_tile_vseq #(.N(N), .VL_W(16), .TID_W(8), .SPM_TAG_W(8)) u_vseq (
    .clk, .rst_n,
    .job_valid, .job_ready, .job_op, .job_rm, .job_vl, .job_bcast, .job_scalar, .job_a, .job_b, .job_c, .job_d, .job_tid,
    .done_valid, .done_ready(1'b1), .done_tid, .done_flags, .done_illegal, .done_count, .done_err,
    .spm_req_valid(p_req_valid[0]), .spm_req_ready(p_req_ready[0]), .spm_req_we(p_req_we[0]), .spm_req_addr(p_req_addr[31:0]),
    .spm_req_wdata(p_req_wdata[31:0]), .spm_req_wstrb(p_req_wstrb[3:0]), .spm_req_tag(p_req_tag[7:0]),
    .spm_rsp_valid(p_rsp_valid[0]), .spm_rsp_ready(p_rsp_ready[0]), .spm_rsp_rdata(p_rsp_rdata[31:0]),
    .spm_rsp_err(p_rsp_err[0]), .spm_rsp_tag(p_rsp_tag[7:0]),
    .cmd_valid(c_valid), .cmd_ready(c_ready), .cmd_op(c_op), .cmd_rm(c_rm), .cmd_vl(c_vl), .cmd_bcast(c_bc),
    .cmd_scalar(c_sc), .cmd_tid(c_tid), .opnd_valid(o_valid), .opnd_ready(o_ready), .opnd_a(o_a), .opnd_b(o_b),
    .opnd_c(o_c), .res_valid(r_valid), .res_ready(r_ready), .res_data(r_data), .res_mask(r_mask),
    .cpl_valid(k_valid), .cpl_ready(k_ready), .cpl_flags(k_flags), .cpl_illegal(k_ill), .cpl_count(k_count),
    .busy(v_busy));
  hpc_vector_array #(.NUM_LANES(N), .VL_W(16), .TID_W(8)) u_va (
    .clk_i(clk), .rst_ni(rst_n),
    .cmd_valid_i(c_valid), .cmd_ready_o(c_ready), .cmd_op_i(c_op), .cmd_rm_i(c_rm), .cmd_vl_i(c_vl), .cmd_vm_i(1'b0),
    .cmd_bcast_i(c_bc), .cmd_scalar_i(c_sc), .cmd_red_i(1'b0), .cmd_tid_i(c_tid),
    .opnd_valid_i(o_valid), .opnd_ready_o(o_ready), .opnd_a_i(o_a), .opnd_b_i(o_b), .opnd_c_i(o_c), .opnd_mask_i({N{1'b1}}),
    .res_valid_o(r_valid), .res_ready_i(r_ready), .res_data_o(r_data), .res_flags_o(r_flags), .res_mask_o(r_mask),
    .res_tid_o(r_tid), .res_beat_o(r_beat), .res_last_o(r_last),
    .cpl_valid_o(k_valid), .cpl_ready_i(k_ready), .cpl_tid_o(k_tid), .cpl_flags_o(k_flags), .cpl_illegal_o(k_ill),
    .cpl_count_o(k_count), .cpl_red_o(k_red), .cpl_result_o(k_result),
    .lane_hold_i('0), .busy_o(va_busy), .perf_clear_i(1'b0), .perf_cnt_o(va_perf));

  // ============================================================ protocol checkers on every SFB2 link
  logic [31:0] viol [0:NM+1];
  for (genvar g = 0; g < NM; g++) begin : g_cm
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(1), .NAME("tile_xbar_master")) u_c (
      .clk, .rst_n, .req_valid(m_req_valid[g]), .req_ready(m_req_ready[g]), .req_write(m_req_write[g]),
      .req_addr(m_req_addr[g*32 +: 32]), .req_wdata(m_req_wdata[g*32 +: 32]), .req_wstrb(m_req_wstrb[g*4 +: 4]),
      .rsp_valid(m_rsp_valid[g]), .rsp_ready(m_rsp_ready[g]), .rsp_rdata(m_rsp_rdata[g*32 +: 32]),
      .rsp_error(m_rsp_error[g]), .violations(viol[g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  for (genvar g = 0; g < 2; g++) begin : g_cs
    logic [31:0] a, b, c;
    sfb_protocol_checker #(.AW(32), .DW(32), .MAX_OUT(1), .NAME("tile_xbar_slave")) u_c (
      .clk, .rst_n, .req_valid(s_req_valid[g]), .req_ready(s_req_ready[g]), .req_write(s_req_write[g]),
      .req_addr(s_req_addr[g*32 +: 32]), .req_wdata(s_req_wdata[g*32 +: 32]), .req_wstrb(s_req_wstrb[g*4 +: 4]),
      .rsp_valid(s_rsp_valid[g]), .rsp_ready(s_rsp_ready[g]), .rsp_rdata(s_rsp_rdata[g*32 +: 32]),
      .rsp_error(s_rsp_error[g]), .violations(viol[NM+g]), .n_req(a), .n_rsp(b), .outstanding(c));
  end

  // ============================================================ memory images and backdoors
  logic [31:0] ext_init [0:EXTB/4-1];
  logic [31:0] spm_init [0:SPMB/4-1];
  logic [31:0] exp_ext  [0:EXTB/4-1];
  logic [31:0] exp_spm  [0:SPMB/4-1];
  logic [63:0] host_ops [0:IG_NOPS-1];
  int  bd_seq = 0, bd_cmd = 0;
  logic [3:0] bd_ack;
  logic [31:0] spm_dump [0:SPMB/4-1];
  for (genvar b = 0; b < 4; b++) begin : g_bd
    int ack_seq = 0;
    assign bd_ack[b] = (ack_seq == bd_seq);
    always @(bd_seq) if (bd_seq != 0) begin
      for (int r = 0; r < SPMB / 16; r++)
        if (bd_cmd == 1) u_spm.g_core.g_bank[b].u_bank.g_ram.u_ram.g_generic.u_mem.mem[r] = spm_init[r*4 + b];
        else spm_dump[r*4 + b] = u_spm.g_core.g_bank[b].u_bank.g_ram.u_ram.g_generic.u_mem.mem[r];
      ack_seq = bd_seq;
    end
  end
  task automatic bd_do(input int c);
    bd_cmd = c; bd_seq = bd_seq + 1; #0.001; wait (bd_ack == 4'hF);
  endtask
  function automatic logic [31:0] ext_word(input int w);
    if (w < 8192) return g_sram[0].u_m.u_sram.u_array.g_generic.u_mem.mem[w];
    return g_sram[1].u_m.u_sram.u_array.g_generic.u_mem.mem[w - 8192];
  endfunction

  // ============================================================ host BFM (crossbar master NP), monitor-counted handshakes
  logic        h_v = 1'b0, h_w = 1'b0;
  logic [31:0] h_a = '0, h_d = '0;
  logic [3:0]  h_s = '0;
  assign m_req_valid[NP] = h_v;
  assign m_req_write[NP] = h_w;
  assign m_req_addr[NP*32 +: 32] = h_a;
  assign m_req_wdata[NP*32 +: 32] = h_d;
  assign m_req_wstrb[NP*4 +: 4] = h_s;
  assign m_rsp_ready[NP] = 1'b1;
  int unsigned h_req_n = 0, h_rsp_n = 0;
  logic [31:0] h_rdata = '0;
  logic        h_rerr = 1'b0;
  always @(posedge clk) if (rst_n) begin
    if (h_v && m_req_ready[NP]) h_req_n++;
    if (m_rsp_valid[NP]) begin h_rsp_n++; h_rdata = m_rsp_rdata[NP*32 +: 32]; h_rerr = m_rsp_error[NP]; end
  end
  task automatic host_access(input logic w, input logic [31:0] a, input logic [31:0] d, input logic [3:0] s,
                             output logic [31:0] rd);
    int unsigned k, r;
    k = h_req_n; r = h_rsp_n;
    h_v <= 1'b1; h_w <= w; h_a <= a; h_d <= d; h_s <= s;
    while (h_req_n == k) @(posedge clk or negedge clk);
    h_v <= 1'b0;
    while (h_rsp_n == r) @(posedge clk or negedge clk);
    if (h_rerr) err($sformatf("host access %h answered with an error", a));
    rd = h_rdata;
  endtask

  // ============================================================ DMA driver + completion collector (by tag)
  int unsigned d_hs_n = 0, n_cpl = 0, bytes_moved = 0;
  bit          cpl_seen [0:255];
  logic [31:0] cpl_len  [0:255];
  int unsigned cpl_cyc  [0:255];
  int unsigned dma_tag = 0;
  always @(posedge clk) if (rst_n && cmd_valid && cmd_ready) d_hs_n++;
  always @(posedge clk) if (rst_n && cpl_valid) begin
    if (cpl_seen[cpl_tag]) err($sformatf("duplicate completion for tag %0d", cpl_tag));
    if (cpl_code != 0) err($sformatf("DMA tag %0d failed: code %0d at %h", cpl_tag, cpl_code, cpl_err_addr));
    if (cpl_bytes != cpl_len[cpl_tag]) err($sformatf("DMA tag %0d: %0d bytes of %0d", cpl_tag, cpl_bytes, cpl_len[cpl_tag]));
    cpl_seen[cpl_tag] = 1'b1; cpl_cyc[cpl_tag] = cyc; n_cpl++; bytes_moved += cpl_bytes;
  end
  bit dma_lock = 1'b0;                                  // the descriptor channel is shared by the phase-B threads
  task automatic dma(input logic [31:0] s, input logic [31:0] d, input logic [31:0] n, output int unsigned tag);
    int unsigned k;
    while (dma_lock) @(posedge clk);
    dma_lock = 1'b1;
    tag = dma_tag % 256; dma_tag++;
    cpl_seen[tag] = 1'b0; cpl_len[tag] = n;
    k = d_hs_n;
    cmd_valid <= 1'b1; cmd_src <= s; cmd_dst <= d; cmd_len <= n; cmd_tag <= 8'(tag);
    while (d_hs_n == k) @(posedge clk or negedge clk);
    cmd_valid <= 1'b0;
    @(negedge clk);
    dma_lock = 1'b0;
  endtask
  task automatic dma_wait(input int unsigned tag);
    while (!cpl_seen[tag]) @(posedge clk);
  endtask

  // ============================================================ vector job driver
  int unsigned j_hs_n = 0, j_done_n = 0;
  logic [7:0]  j_last_tid;
  always @(posedge clk) if (rst_n && job_valid && job_ready) j_hs_n++;
  always @(posedge clk) if (rst_n && done_valid) begin
    j_done_n++; j_last_tid = done_tid;
    if (done_err) err($sformatf("vector job %0d: scratchpad error", done_tid));
    if (done_illegal) err($sformatf("vector job %0d: illegal command", done_tid));
  end
  task automatic vjob(input logic [4:0] op, input logic [2:0] bc, input logic [31:0] sc, input logic [31:0] a,
                      input logic [31:0] b, input logic [31:0] c, input logic [31:0] d, input int vl, input logic [7:0] tid);
    int unsigned k, dn;
    k = j_hs_n; dn = j_done_n;
    job_valid <= 1'b1; job_op <= op; job_rm <= 3'd0; job_vl <= 16'(vl); job_bcast <= bc; job_scalar <= sc;
    job_a <= a; job_b <= b; job_c <= c; job_d <= d; job_tid <= tid;
    while (j_hs_n == k) @(posedge clk or negedge clk);
    job_valid <= 1'b0;
    while (j_done_n == dn) @(posedge clk);
    if (j_last_tid !== tid) err("vector done record out of order");
    if (int'(done_count) != vl) err($sformatf("vector job %0d: %0d elements computed of %0d", tid, done_count, vl));
  endtask

  // ============================================================ phase B: host background traffic in its scratch
  bit          bg_run = 1'b0;
  int unsigned bg_ops = 0;
  logic [31:0] bg_sh [0:IG_HSCR_BYTES/4-1];
  task automatic host_background();
    int unsigned r;
    logic [31:0] rd;
    r = 32'h1357;
    for (int i = 0; i < IG_HSCR_BYTES / 4; i++) bg_sh[i] = ext_word(int'(IG_HSCR - EXT_BASE) / 4 + i);
    while (bg_run) begin
      int w;
      r = xs(r); w = int'(r % (IG_HSCR_BYTES / 4));
      r = xs(r);
      if (r[0]) begin host_access(1'b1, IG_HSCR + 32'(w * 4), r, 4'hF, rd); bg_sh[w] = r; end
      else begin
        host_access(1'b0, IG_HSCR + 32'(w * 4), '0, 4'h0, rd);
        if (rd !== bg_sh[w]) err($sformatf("host background read %h = %h, expected %h", IG_HSCR + 32'(w*4), rd, bg_sh[w]));
      end
      bg_ops++;
    end
  endtask

  // ============================================================ phase B threads (double buffering)
  bit in_done [0:15];
  bit comp_done [0:15];
  bit out_done [0:15];
  task automatic th_in();
    for (int k = 0; k < IG_K; k++) begin
      int unsigned tx, ty;
      if (k >= 2) while (!comp_done[k-2]) @(posedge clk);          // X/Y buffer k%2 free once tile k-2 computed
      dma(IG_X + 32'(k * IG_TILE_STRIDE), IG_SX + 32'((k % 2) * IG_TILE_STRIDE), 32'(4 * IG_T), tx);
      dma(IG_Y + 32'(k * IG_TILE_STRIDE), IG_SY + 32'((k % 2) * IG_TILE_STRIDE), 32'(4 * IG_T), ty);
      dma_wait(tx); dma_wait(ty);
      in_done[k] = 1'b1;
    end
  endtask
  task automatic th_comp();
    for (int k = 0; k < IG_K; k++) begin
      while (!in_done[k]) @(posedge clk);
      if (k >= 2) while (!out_done[k-2]) @(posedge clk);           // Z buffer k%2 free once tile k-2 written out
      vjob(5'h04, 3'b001, IG_ALPHA, 32'd0, IG_SX + 32'((k % 2) * IG_TILE_STRIDE), IG_SY + 32'((k % 2) * IG_TILE_STRIDE),
           IG_SZ + 32'((k % 2) * IG_TILE_STRIDE), IG_T, 8'(16 + k));
      comp_done[k] = 1'b1;
    end
  endtask
  task automatic th_out();
    for (int k = 0; k < IG_K; k++) begin
      int unsigned tz;
      while (!comp_done[k]) @(posedge clk);
      dma(IG_SZ + 32'((k % 2) * IG_TILE_STRIDE), IG_Z + 32'(k * IG_TILE_STRIDE), 32'(4 * IG_T), tz);
      dma_wait(tz);
      out_done[k] = 1'b1;
    end
  endtask
  // contention evidence, measured independently of the adapter's counters
  int unsigned c_dma_spm_wait = 0, c_dma_fab_wait = 0, c_host_wait = 0, c_xbar_loss_dma = 0, c_xbar_loss_host = 0;
  int unsigned c_spm_conf_dma = 0, c_spm_conf_vec = 0, c_vec_wait = 0;
  always @(posedge clk) if (rst_n) begin
    for (int p = 0; p < NP; p++) begin
      if (p_req_valid[1 + p] && !p_req_ready[1 + p]) c_dma_spm_wait++;
      if (m_req_valid[p] && !m_req_ready[p]) c_dma_fab_wait++;
      if (x_loss[p]) c_xbar_loss_dma++;
      if (sp_conf[1 + p]) c_spm_conf_dma++;
    end
    if (h_v && !m_req_ready[NP]) c_host_wait++;
    if (x_loss[NP]) c_xbar_loss_host++;
    if (sp_conf[0]) c_spm_conf_vec++;
    if (p_req_valid[0] && !p_req_ready[0]) c_vec_wait++;
  end
  // overlap measurement: cycles in which the DMA engine and the vector sequencer are both busy
  int unsigned ov_both = 0, ov_dma = 0, ov_vec = 0, ov_on = 0;
  always @(posedge clk) if (ov_on) begin
    if (d_active) ov_dma++;
    if (v_busy) ov_vec++;
    if (d_active && v_busy) ov_both++;
  end

  // ============================================================ main
  initial begin
    int unsigned t0, t1, t2, t3, t4, t5, ta, tb, tc, td, te, tf, tg, th;
    logic [31:0] rd;
    $readmemh("ext_init.hex", ext_init);
    $readmemh("spm_init.hex", spm_init);
    $readmemh("exp_ext.hex", exp_ext);
    $readmemh("exp_spm.hex", exp_spm);
    $readmemh("host_ops.hex", host_ops);
    #1;
    for (int w = 0; w < 8192; w++) begin
      g_sram[0].u_m.u_sram.u_array.g_generic.u_mem.mem[w] = ext_init[w];
      g_sram[1].u_m.u_sram.u_array.g_generic.u_mem.mem[w] = ext_init[8192 + w];
    end
    bd_do(1);
    for (int i = 0; i < 256; i++) cpl_seen[i] = 1'b0;
    for (int i = 0; i < 16; i++) begin in_done[i] = 0; comp_done[i] = 0; out_done[i] = 0; end
    repeat (3) @(negedge clk);
    rst_n = 1'b1;
    @(posedge clk);

    // ---------------------------------------------------------- 1. host-side test logic writes the operands
    t0 = cyc;
    for (int i = 0; i < IG_NOPS; i++) host_access(1'b1, host_ops[i][63:32], host_ops[i][31:0], 4'hF, rd);
    t1 = cyc;
    // ---------------------------------------------------------- 2. DMA operands into the scratchpad (queued back to back)
    begin
      int unsigned qa, qb, qc;
      dma(IG_A, IG_SA, 32'(4 * IG_VA), qa); dma(IG_B, IG_SB, 32'(4 * IG_VA), qb); dma(IG_C, IG_SC, 32'(4 * IG_VA), qc);
      dma_wait(qa); dma_wait(qb); dma_wait(qc);
    end
    t2 = cyc;
    // ---------------------------------------------------------- 3. compute from the scratchpad
    vjob(5'h04, 3'b000, 32'd0, IG_SA, IG_SB, IG_SC, IG_SD, IG_VA, 8'd1);          // D = A*B + C  (FMADD, fused)
    ta = cyc;
    vjob(5'h01, 3'b010, IG_SCALAR, IG_SA, 32'd0, 32'd0, IG_SE, IG_VA, 8'd2);     // E = A + s    (FADD, b broadcast)
    tb = cyc;
    vjob(5'h11, 3'b000, 32'd0, IG_SA, IG_SB, 32'd0, IG_SF, IG_VA, 8'd3);         // F = A*B mod 2^32 (IMUL)
    t3 = cyc;
    // ---------------------------------------------------------- 4. DMA results out
    begin
      int unsigned qd, qe, qf;
      dma(IG_SD, IG_D, 32'(4 * IG_VA), qd); dma(IG_SE, IG_E, 32'(IG_E_LEN), qe); dma(IG_SF, IG_F, 32'(4 * IG_VA), qf);
      dma_wait(qd); dma_wait(qe); dma_wait(qf);
    end
    t4 = cyc;
    // ---------------------------------------------------------- phase B: concurrent host / DMA / vector activity
    ov_on = 1; bg_run = 1'b1;
    tc = cyc;
    fork
      th_in();
      th_comp();
      th_out();
      host_background();
      begin while (!out_done[IG_K - 1]) @(posedge clk); bg_run = 1'b0; end
    join
    td = cyc;
    ov_on = 0;
    // ---------------------------------------------------------- 5. compare final memory contents
    // (a) host front-door read-back of every result word through the fabric
    te = cyc;
    for (int i = 0; i < IG_VA; i++) begin
      host_access(1'b0, IG_D + 32'(4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[int'(IG_D - EXT_BASE)/4 + i]) err($sformatf("D[%0d] = %h, expected %h", i, rd, exp_ext[int'(IG_D - EXT_BASE)/4 + i]));
      host_access(1'b0, IG_E + 32'(4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[int'(IG_E - EXT_BASE)/4 + i]) err($sformatf("E[%0d] = %h, expected %h", i, rd, exp_ext[int'(IG_E - EXT_BASE)/4 + i]));
      host_access(1'b0, IG_F + 32'(4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[int'(IG_F - EXT_BASE)/4 + i]) err($sformatf("F[%0d] = %h, expected %h", i, rd, exp_ext[int'(IG_F - EXT_BASE)/4 + i]));
    end
    for (int k = 0; k < IG_K; k++) for (int i = 0; i < IG_T; i++) begin
      int w;
      w = int'(IG_Z - EXT_BASE) / 4 + k * IG_TILE_STRIDE / 4 + i;
      host_access(1'b0, IG_Z + 32'(k * IG_TILE_STRIDE + 4*i), '0, 4'h0, rd);
      if (rd !== exp_ext[w]) err($sformatf("Z[%0d][%0d] = %h, expected %h", k, i, rd, exp_ext[w]));
    end
    tf = cyc;
    // (b) whole external memory and whole scratchpad, byte-exact (host scratch excluded: checked by its shadow)
    begin
      int me, ms;
      me = 0; ms = 0;
      for (int w = 0; w < EXTB / 4; w++) begin
        bit hscr;
        hscr = (w >= int'(IG_HSCR - EXT_BASE) / 4 && w < int'(IG_HSCR - EXT_BASE + IG_HSCR_BYTES) / 4);
        if (!hscr && ext_word(w) !== exp_ext[w]) begin
          me++;
          if (me <= 5) err($sformatf("external word %h = %h, expected %h", EXT_BASE + 32'(4*w), ext_word(w), exp_ext[w]));
        end
      end
      bd_do(2);
      for (int w = 0; w < SPMB / 4; w++) if (spm_dump[w] !== exp_spm[w]) begin
        ms++;
        if (ms <= 5) err($sformatf("scratchpad word %h = %h, expected %h", SPM_BASE + 32'(4*w), spm_dump[w], exp_spm[w]));
      end
      $display("TB_HPC_TILE INFO compared %0d external bytes and %0d scratchpad bytes: %0d / %0d mismatching words",
               EXTB - IG_HSCR_BYTES, SPMB, me, ms);
    end
    // (c) adapter counters and protocol checkers
    if (pc(`HPC_DMA_PC_BYTES_WR) != bytes_moved) err($sformatf("adapter BYTES_WR %0d vs %0d", pc(`HPC_DMA_PC_BYTES_WR), bytes_moved));
    if (pc(`HPC_DMA_PC_CPL_OK) != n_cpl || pc(`HPC_DMA_PC_CPL_ERR) != 0 || pc(`HPC_DMA_PC_BUS_ERR) != 0 || pc(`HPC_DMA_PC_TAG_ERR) != 0)
      err("adapter completion / error counters inconsistent");
    for (int i = 0; i < NM + 2; i++) if (viol[i] != 0) err($sformatf("SFB2 protocol violations on link %0d: %0d", i, viol[i]));
    if (bg_ops == 0) err("host background traffic did not run");
    if (ov_both == 0) err("phase B: DMA and vector compute never overlapped");
    $display("TB_HPC_TILE CYCLES engine=%0d dual=%0d lanes=%0d host_write_operands=%0d dma_in_12000B=%0d fmadd_1000=%0d fadd_bcast_1000=%0d imul_1000=%0d dma_out_11997B=%0d",
             ENGINE, DUAL_PORT, N, t1 - t0, t2 - t1, ta - t2, tb - ta, t3 - tb, t4 - t3);
    $display("TB_HPC_TILE PHASEB tiles=%0d total=%0d dma_active=%0d vseq_busy=%0d both_busy=%0d serial_sum=%0d host_bg_ops=%0d",
             IG_K, td - tc, ov_dma, ov_vec, ov_both, ov_dma + ov_vec, bg_ops);
    $display("TB_HPC_TILE PERF transfers=%0d bytes_written=%0d bytes_read=%0d active=%0d req_stall=%0d rsp_wait=%0d out_max=%0d spm_req=%0d fab_req=%0d readback=%0d",
             pc(`HPC_DMA_PC_CPL_OK), pc(`HPC_DMA_PC_BYTES_WR), pc(`HPC_DMA_PC_BYTES_RD), pc(`HPC_DMA_PC_ACTIVE),
             pc(`HPC_DMA_PC_REQ_STALL), pc(`HPC_DMA_PC_RSP_WAIT), pc(`HPC_DMA_PC_OUT_MAX), pc(`HPC_DMA_PC_SPM_REQ),
             pc(`HPC_DMA_PC_FAB_REQ), tf - te);
    $display("TB_HPC_TILE CONTENTION dma_spm_wait=%0d dma_fab_wait=%0d host_wait=%0d xbar_arb_loss_dma=%0d xbar_arb_loss_host=%0d spm_conflict_dma=%0d spm_conflict_vec=%0d vec_wait=%0d",
             c_dma_spm_wait, c_dma_fab_wait, c_host_wait, c_xbar_loss_dma, c_xbar_loss_host, c_spm_conf_dma, c_spm_conf_vec, c_vec_wait);
    if (c_dma_spm_wait + c_dma_fab_wait != pc(`HPC_DMA_PC_REQ_STALL) && NP == 1)
      err($sformatf("adapter REQ_STALL %0d vs measured %0d", pc(`HPC_DMA_PC_REQ_STALL), c_dma_spm_wait + c_dma_fab_wait));
    if (errors == 0) $display("TB_HPC_TILE RESULT PASS engine=%0d dual=%0d", ENGINE, DUAL_PORT);
    else             $display("TB_HPC_TILE RESULT FAIL engine=%0d dual=%0d errors=%0d", ENGINE, DUAL_PORT, errors);
    $finish;
  end
  initial begin #100ms; $display("TB_HPC_TILE RESULT FAIL timeout"); $finish; end
endmodule

`default_nettype wire
