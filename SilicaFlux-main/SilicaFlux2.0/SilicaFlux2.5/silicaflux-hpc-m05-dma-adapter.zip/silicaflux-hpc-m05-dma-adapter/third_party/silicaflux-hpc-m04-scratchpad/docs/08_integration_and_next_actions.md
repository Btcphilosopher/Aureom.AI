# 08 — Integration in the compute tile, recommended configurations, open items

## 1. Connecting the vector array and the DMA engine

```
                      +--------------------------------------------+
 vector lane 0 -----> | port 0                                     |
 vector lane 1 -----> | port 1         hpc_scratchpad              |
   ...                |   ...          NUM_BANKS banks             |
 vector lane L-1 ---> | port L-1       (BACKEND per target)        |
 DMA (DataFabric) --> | port L         <- SFB2, direct wiring      |
                      +--------------------------------------------+
```

* **Vector lanes.** Each lane (Module 02 `hpc_vector_lane` uses the same valid/ready + tag convention) drives one
  port. Unit-stride vector loads with the LOW map put consecutive elements in consecutive banks, so L lanes reading
  L consecutive words hit L different banks (no conflict when L ≤ NUM_BANKS). The tag returns the lane's element
  index / ROB slot. With `QUEUE_DEPTH = 0` a lane sees its data READ_LATENCY cycles after the request is accepted.
* **DMA engine.** DataFabric's SFB2 protocol maps directly onto a scratchpad port: `req_valid/req_ready/req_write/
  req_addr/req_wdata/req_wstrb` → `req_valid/req_ready/req_we/req_addr/req_wdata/req_wstrb`; `rsp_valid/rsp_ready/
  rsp_rdata/rsp_error` ← `rsp_valid/rsp_ready/rsp_rdata/rsp_err`; tie `req_tag` (SFB2 rev 2.0 has no IDs; it is in
  order, which the scratchpad guarantees). Every SFB2 rule holds: write responses only after the array write (R7 —
  `WRITE_ACK = 1`), `rsp_rdata = 0` on errors (R8), misaligned addresses are errors (R9), `rsp_valid` never depends on
  `rsp_ready` (R4). Use `ADDR_WIDTH = 32` and `BASE_ADDR` = the scratchpad's window base so the scratchpad itself
  rejects anything outside its window instead of relying on the crossbar decode. A dedicated wrapper module and an SFB2
  protocol-checker run (DataFabric `tb/common/sfb_protocol_checker.sv`) are listed below as the first integration step.
* **Memory map.** DataFabric's single-source map already reserves the tile scratchpad window `TSPM` at
  `0x2000_0000` (16 KiB in SilicaFlux-V release 1). Growing it to 64 / 128 / 256 KiB is a one-line change of `size`
  in `memmap/silicaflux_v_datafabric.yaml` (power-of-two size, base aligned to size — the same rule `BASE_ADDR`
  enforces) plus regeneration of the derived files; stage 2 of the regression already runs the scratchpad at
  `BASE_ADDR = 0x2000_0000`.
* **Clock / reset.** Single clock, asynchronous active-low reset with synchronous release (as in DataFabric's
  `sfv_rst_sync`).

## 2. Recommended starting configurations

| Use | Configuration | Why |
|---|---|---|
| First integration (FPGA, Arty A7-100T) | 64 KiB, 4 banks, 4 ports (3 lanes + DMA), 32 bit, 1RW, LOW, RR, RL 1, `QUEUE_DEPTH` 0, `BACKEND = FPGA` | 16 RAMB36E1, ≈ 1.9 k LUTs with counters at 2 ports; unit-stride and DMA streams conflict-free (doc 07) |
| Higher lane count | 8 banks for ≤ 8 ports, `MAP = XOR` if stride-2/4 vector accesses are common | doc 07 stride results |
| Timing-critical lane interface | `QUEUE_DEPTH = 2` | registered `req_ready`, +1 cycle latency |
| ASIC (open PDK, IHP SG13G2) | 64 KiB, 4 banks, IHP 1P 2048×32, `READ_LATENCY` = macro latency | 8 macros; integrity: byte parity needs a 36-bit macro (doc 04) |

## 3. Open items and prioritised next actions

1. **SFB2 port wrapper + protocol-checker regression** for the DMA side; connect DataFabric's `silicaflux_dma` and
   run its DMA test against the scratchpad.
2. **Formal**: bounded proofs (SymbiYosys or yosys-smtbmc, as the library and DataFabric did) of the arbiter
   properties already asserted in simulation: one grant per slot, port-model limits, no same-row write pair, RR bound.
3. **MBIST**: route the library's `sram_mbist_adapter` / TestCore `sftc_mbist_bank_mux` to the banks (the raw
   backends have no test port; `sram_bank_controller` shows the muxing).
4. **SECDED** for `BYTE_WE = 0` configurations, reusing MemoryFlow's `sf_ecc_secded_enc/dec` (doc 05 §3).
5. **Vendor FPGA run** (Vivado on the Arty A7-100T): confirm the Yosys BRAM counts, close timing, measure Fmax.
6. **ASIC**: Liberty-based synthesis and STA with the IHP SG13G2 macros' timing views; decide a 36/40-bit macro for
   parity / SECDED.
7. **Output register option** on the response path (registered `rsp_*`) if the SRAM-to-port path limits timing (the
   response FIFO is bypassed when empty, so read data leaves combinationally from the array output).
