# 01 — Architecture, parameters, interface and timing

`rtl/hpc_scratchpad.sv` is a synthesizable, parameterised, banked scratchpad SRAM for the SilicaFlux-HPC compute
tile. It gives `NUM_PORTS` requesters (the vector array's lanes and the DMA engine) predictable local memory access
with a fixed, documented latency and deterministic arbitration.

## 1. Block diagram

```
 port 0 .. NUM_PORTS-1                                    (one column per port)
   req: valid/ready, we, addr (byte), wdata, wstrb, tag
        |
        |   QUEUE_DEPTH = 0: the request itself is the head     QUEUE_DEPTH > 0: dma_fifo (DataFabric, unmodified)
        v
   hpc_spm_addr_map ------------------> error code (RANGE / ALIGN / STROBE) -> no bank access
        | bank, row                                                                 |
        v                                                                           |
   +---------------- per bank b: hpc_spm_bank_arb ---------------+                  |
   |  eligible = head valid & decoded OK & response credit free  |                  |
   |  RR or fixed priority; <= 1 (1RW) / 1R+1W (1R1W) / 2 (2RW)  |                  |
   |  grants per cycle; never two same-row accesses with a write |                  |
   +------------------------------+------------------------------+                  |
                                  v                                                 |
   hpc_spm_bank b: byte-parity encode (optional) + sram_backend_1rw / _1r1w / _2rw  |
                   (SRAM Wrapper Library, unmodified: GENERIC / FPGA BRAM / ASIC)   |
                                  |  read data exactly READ_LATENCY cycles later    |
                                  v                                                 |
   owner pipelines (READ_LATENCY deep, per bank slot) route data to the issuing port|
                                  v                                                 v
   per port: parity check -> sram_rsp_path (SRAM Wrapper Library, unmodified):
             tag pipeline, response credits, response FIFO, strict in-order delivery
        |
        v
   rsp: valid/ready, rdata, err, err_code[2:0], we, tag, ecc_syn
   events (ev_*) and saturating counters (perf_*)
```

## 2. Parameters

| Parameter | Default | Legal values | Meaning |
|---|---|---|---|
| `NUM_PORTS` | 2 | 1..8 | requester ports |
| `CAPACITY_BYTES` | 65536 | power of two, ≥ 2 × `NUM_BANKS` × word bytes | total capacity (64 / 128 / 256 KiB explored) |
| `NUM_BANKS` | 2 | 1, 2, 4, 8, 16 | independent banks; bank depth = capacity / (banks × word bytes) |
| `DATA_WIDTH` | 32 | 8..1024, power of two | word = port data width = bank width (before check bits) |
| `ADDR_WIDTH` | 32 | log2(capacity)..64 | byte-address width of the ports |
| `BASE_ADDR` | 0 | capacity-aligned, < 2^`ADDR_WIDTH` | base of the scratchpad window |
| `READ_LATENCY` | 1 | 1..8 | issue edge → response cycle (1 = BRAM/macro latch, 2 = + output register) |
| `BYTE_WE` | 1 | 0 / 1 | 1: byte write enables; 0: word-write memory (partial strobes rejected) |
| `PORT_MODE` | 1RW (0) | 1RW, 1R1W (1), 2RW (2) | memory-port model of every bank |
| `MAP` | LOW (0) | LOW, XOR (1), HIGH (2) | byte address → bank/row mapping (doc 02) |
| `ARB` | RR (0) | RR, FIXED (1) | per-bank arbitration (doc 03) |
| `QUEUE_DEPTH` | 0 | 0, 2, 4, 8, 16 | per-port request queue (0 = direct issue) |
| `RSP_FIFO_DEPTH` | `READ_LATENCY`+1 | 0..64 | per-port response credits; 0 = no response back-pressure allowed |
| `WRITE_ACK` | 1 | 0 / 1 | 1: every write is answered; 0: posted (only failed writes answered) |
| `TAG_W` | 8 | 1..32 | request tag echoed on the response |
| `ECC_MODE` | NONE (0) | NONE, BYTE_PARITY (1); SECDED (2) **reserved, rejected** | integrity (doc 05) |
| `BACKEND` | GENERIC (0) | GENERIC, FPGA (1), ASIC (2) | bank implementation (doc 04) |
| `MACRO` | 0 | sramlib catalogue id | ASIC macro (required for ASIC) |
| `PERF_EN`, `CNT_W` | 1, 32 | 0/1, 8..64 | event counters |

Every illegal value or combination stops elaboration with a message naming the rule (27 negative elaboration tests in
`reports/regression.md`). The datapath is only elaborated when the configuration is valid, so the message always
comes from `hpc_scratchpad` itself, never from a sub-module. Configurations the brief asks to explore and which
combinations are valid: `python3 model/hpc_spm_map.py check` (all 15 capacity × bank-count points of 64/128/256 KiB ×
1/2/4/8/16 banks are valid with 32-bit words).

## 3. Ports

Flat vectors (port *p* uses slice *p*), following the SilicaFlux RTL coding rules (no interfaces / structs / package
imports in synthesizable RTL, see `third_party/silicaflux-datafabric` provenance in doc 00).

| Group | Signal | Width | Dir | Meaning |
|---|---|---|---|---|
| request | `req_valid` | P | in | request valid |
| | `req_ready` | P | out | request accepted at this edge |
| | `req_we` | P | in | 1 = write |
| | `req_addr` | P×AW | in | byte address |
| | `req_wdata` | P×DW | in | write data (little-endian: byte lane *k* = address + *k*) |
| | `req_wstrb` | P×DW/8 | in | byte write enables (writes only) |
| | `req_tag` | P×TAG_W | in | transaction tag |
| response | `rsp_valid` | P | out | response valid |
| | `rsp_ready` | P | in | response taken at this edge |
| | `rsp_rdata` | P×DW | out | read data; 0 for writes and every error |
| | `rsp_err` | P | out | `rsp_err_code != 0` |
| | `rsp_err_code` | P×3 | out | 0 OK, 1 RANGE, 2 ALIGN, 3 STROBE, 4 PARITY, 5 reserved (ECC uncorrectable), 6-7 reserved |
| | `rsp_we` | P | out | the response belongs to a write |
| | `rsp_tag` | P×TAG_W | out | tag of the request |
| | `rsp_ecc_syn` | P×DW/8 | out | integrity syndrome: byte lanes that failed the parity check (0 without ECC) |
| events | `ev_accept`, `ev_issue`, `ev_conflict`, `ev_credit_stall`, `ev_error`, `ev_ecc_err` | P each | out | one-cycle pulses (doc 03 §5) |
| | `ev_bank_ops` | B×2 | out | accesses performed by bank *b* this cycle |
| | `ev_bank_conflict` | B | out | bank *b* left an eligible requester unserved |
| counters | `perf_*`, `perf_clear` | | | saturating counters (doc 07) |
| status | `busy` | 1 | out | a request is queued or a response outstanding |

## 4. Handshake rules

| # | Rule |
|---|---|
| H1 | A request transfers at a rising edge with `req_valid && req_ready`; a response with `rsp_valid && rsp_ready`. |
| H2 | The requester holds `req_valid` and the payload stable until accepted (no withdrawal) and never drives `req_valid` in reset. |
| H3 | `QUEUE_DEPTH = 0`: `req_ready` = "granted this cycle" — combinational from `req_valid` / `req_addr` / `req_we` and registered state, **never from `rsp_ready`**. `QUEUE_DEPTH > 0`: `req_ready` is a register output (queue not full). |
| H4 | `rsp_valid`, `rsp_*` hold stable while `rsp_valid && !rsp_ready` (the response FIFO of `sram_rsp_path`). |
| H5 | Exactly one response per read, per acknowledged write (`WRITE_ACK = 1`) and per failed request — strictly in acceptance order per port, carrying the request's tag; never dropped, duplicated or unsolicited. |
| H6 | Response credits: at most `RSP_FIFO_DEPTH` responses outstanding per port; a port whose consumer stalls back-pressures only its own requests (`ev_credit_stall`), never another port's banks. `RSP_FIFO_DEPTH = 0`: `rsp_ready` must be held 1 (assertion). |
| H7 | `req_ready = 0` in reset and in the first cycle after it. |

## 5. Exact timing

Cycle *t* is the clock period that ends with rising edge *t*. RL = `READ_LATENCY`.

| Event | `QUEUE_DEPTH = 0` | `QUEUE_DEPTH > 0` |
|---|---|---|
| request presented | cycle *t* | cycle *t* |
| accepted | edge *t*, if granted (else held, re-arbitrated next cycle) | edge *t*, if the queue is not full |
| issued to the bank (or error path) | **edge *t*** (accept = issue) | edge *i* ≥ *t*+1, when the queue head is granted |
| **write commits** (array written) | edge *t* | edge *i* |
| read samples the array | edge *t* | edge *i* |
| **response valid** (read data, write ack, error) | cycle *t* + RL, if the port's response channel is free | cycle *i* + RL, likewise |
| later | stays valid, in order, until `rsp_ready` | same |
| best-case read latency (present → data) | RL cycles | RL + 1 cycles |
| sustained rate per port, no conflict | 1 access / cycle (`RSP_FIFO_DEPTH ≥ RL + 1`) | 1 access / cycle (`QUEUE_DEPTH ≥ 2`) |

`QUEUE_DEPTH = 0`, `READ_LATENCY = 1`, two ports, both targeting bank 0 in cycle 0 (port 0 wins RR), port 0 writes A,
port 1 reads A:

```
cycle            0        1        2        3
p0 req_valid   ‾‾‾‾‾‾‾‾\________________________   write A (tag 5)
p0 req_ready   ‾‾‾‾‾‾‾‾\________________________   granted cycle 0, accepted + issued + array written at edge 0
p1 req_valid   ‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾‾\________________   read A (tag 9), presented cycle 0
p1 req_ready   ________/‾‾‾‾‾‾‾\________________   lost bank 0 in cycle 0 (ev_conflict[1] = 1), granted cycle 1
p0 rsp_valid   ________/‾‾‾‾‾‾‾\________________   write ack (tag 5) in cycle 1 = 0 + RL
p1 rsp_valid   ________________/‾‾‾‾‾‾‾\________   read data (tag 9) in cycle 2 = 1 + RL: returns the NEW value of A
```

Had port 1 won cycle 0, its read would have been issued at edge 0 and returned the OLD value; the write would follow at
edge 1. Either way the outcome is the one implied by the issue order, which the testbench's reference model reproduces
for every transaction.

## 6. Read-during-write and ordering semantics

* **Commit point.** A write is architecturally complete at its issue edge: any read *issued at a later edge* — from any
  port — returns the new data (lanes with `wstrb = 0` keep their old bytes).
* **Same edge.** A read and a write (or two writes) to the *same row of the same bank* are never issued at the same
  edge: the bank arbiter stalls the lower-priority one (1RW: structurally impossible; 1R1W / 2RW: hazard rule). The
  arrays therefore never see a same-cycle same-row collision, and the result never depends on a backend's
  read-during-write mode (doc 04 §4 lists those modes).
* **Different rows / banks** at the same edge are independent.
* **Per port** everything (reads, writes, errors) completes in acceptance order. **Across ports** there is no ordering
  beyond the issue edges: software that needs "my write is visible to the other port" uses `WRITE_ACK = 1` and waits
  for the acknowledgement (which is only delivered after the commit edge).
* **Errors** never touch a bank: an out-of-range, unaligned or strobe-violating request is answered (in order) with
  `rsp_err = 1`, its code and zero data, and changes nothing.

## 7. Reset

Asynchronous assertion (`rst_n` low) clears every control register: the request queues, the RR pointers, the owner
pipelines and the response paths. Consequences, all checked by the `reset` test:

* requests presented, queued or in flight are discarded; **no response is ever delivered for them**;
* writes already *issued* before the reset are in the array; writes still *queued* are dropped;
* the arrays are **not** reset (an ASIC SRAM has no reset) — software initialises the scratchpad before reading it
  (with `ECC_MODE = BYTE_PARITY`, reading never-written words reports parity errors on real silicon);
* `busy = 0` and `req_ready = 0` in the first cycle after release; normal operation from the second.
