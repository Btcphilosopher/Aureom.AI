# `hpc_vector_array` — interface specification

SilicaFlux-HPC Module 03 · source `rtl/hpc_vector_array.sv` · shared definitions
`rtl/hpc_varray_pkg.sv` (array) and `rtl/lane/hpc_vector_pkg.sv` (element operations, Module 02).

## 1. Parameters

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `NUM_LANES` | 2 | 1, 2, 4, 8, 16 | Lanes = elements per beat. Any other value fails elaboration. |
| `VL_W` | 16 | `clog2(NUM_LANES)` < `VL_W` ≤ 31 | Width of `cmd_vl_i`, `res_beat_o` and `cpl_count_o`. Vector length 0 … 2^VL_W − 1. |
| `TID_W` | 8 | ≥ 1 | Transaction-id width. |
| `CMD_DEPTH` | 4 | ≥ 1 | Command queue: commands accepted but not yet started. |
| `TRK_DEPTH` | 8 | ≥ 1 | Beat-tracking queue: beats issued to the lanes but not yet collected. Full throughput needs `TRK_DEPTH ≥ max lane latency + 2` (`docs/MICROARCHITECTURE.md` §6). |
| `CPL_DEPTH` | 4 | ≥ 1 | Completion queue, which is also the credit pool of the reduction unit. |
| `RED_EN` | 1 | 0/1 | Sum-reduction unit present. When 0, every reduction command is illegal. |
| `RED_LAT` | 3 | ≥ 2 | Latency of each reduction adder (`hpc_fp32_add` `LAT`). |
| `PERF_EN` | 1 | 0/1 | Performance counters present. When 0, `perf_cnt_o` = 0. |
| `PERF_CW` | 32 | ≥ 1 | Counter width (counters saturate). |
| `LANE_ROB_DEPTH`, `LAT_FADD`, `LAT_FMUL`, `LAT_FMA`, `LAT_MISC`, `LAT_IMUL`, `EN_FCMP`, `EN_INT` | 8, 3, 3, 4, 1, 2, 1, 1 | as Module 02 | Passed unchanged to every `hpc_vector_lane` (Module 02 `docs/LANE_INTERFACE.md` §1). |

## 2. Ports

| Port | Dir | Width | Description |
|---|---|---|---|
| `clk_i`, `rst_ni` | in | 1 | Clock. Active-low reset: asynchronous assert, synchronous de-assert (§11). |
| **command** | | | |
| `cmd_valid_i` / `cmd_ready_o` | in / out | 1 | Command handshake. |
| `cmd_op_i` | in | 5 | Element operation, encoded as in `hpc_vector_pkg` (§4). |
| `cmd_rm_i` | in | 3 | Rounding mode: RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4. |
| `cmd_vl_i` | in | `VL_W` | Vector length in elements (§5). |
| `cmd_vm_i` | in | 1 | 1 = use the per-beat element mask `opnd_mask_i`; 0 = every element below vl is active. |
| `cmd_bcast_i` | in | 3 | `{c, b, a}`: a set bit replaces that operand of every element by `cmd_scalar_i`. |
| `cmd_scalar_i` | in | 32 | Broadcast scalar. For a reduction, it is the accumulator's initial value. |
| `cmd_red_i` | in | 1 | 1 = sum-reduce the element results (§9.3). |
| `cmd_tid_i` | in | `TID_W` | Transaction id, returned with every result beat and the completion record. |
| **operand beats** | | | |
| `opnd_valid_i` / `opnd_ready_o` | in / out | 1 | Operand-beat handshake. |
| `opnd_a_i`, `opnd_b_i`, `opnd_c_i` | in | `NUM_LANES*32` | Lane *l* operand in bits `[l*32 +: 32]`. |
| `opnd_mask_i` | in | `NUM_LANES` | Element mask of this beat (used when `cmd_vm_i` = 1). |
| **result beats** | | | |
| `res_valid_o` / `res_ready_i` | out / in | 1 | Result-beat handshake. |
| `res_data_o` | out | `NUM_LANES*32` | Lane *l* result in `[l*32 +: 32]`; 0 for inactive positions. |
| `res_flags_o` | out | `NUM_LANES*5` | Lane *l* flags `{NV,DZ,OF,UF,NX}` in `[l*5 +: 5]`; 0 for inactive positions. |
| `res_mask_o` | out | `NUM_LANES` | Bit *l* = position *l* carries a computed result (use as a write enable). |
| `res_tid_o` | out | `TID_W` | Transaction id of the command. |
| `res_beat_o` | out | `VL_W` | Beat index *g* within the command: elements *gN … gN+N−1*. |
| `res_last_o` | out | 1 | Last beat of the command. |
| **completion** | | | |
| `cpl_valid_o` / `cpl_ready_i` | out / in | 1 | Completion handshake: one record per command. |
| `cpl_tid_o` | out | `TID_W` | Transaction id. |
| `cpl_flags_o` | out | 5 | OR of the flags of every active element. For a reduction it also includes every reduction add (§9.2). |
| `cpl_illegal_o` | out | 1 | The command was illegal (§4.3). |
| `cpl_count_o` | out | `VL_W` | Number of active elements computed. 0 for illegal commands. |
| `cpl_red_o` | out | 1 | The command was a reduction. |
| `cpl_result_o` | out | 32 | Reduction result. 0 for elementwise and illegal commands. |
| **control / status** | | | |
| `lane_hold_i` | in | `NUM_LANES` | Per-lane issue hold (§12). Tie to 0 if unused. |
| `busy_o` | out | 1 | At least one accepted command has not produced its completion record yet, or a record is waiting (§13). |
| `perf_clear_i` | in | 1 | Synchronous clear of all performance counters. |
| `perf_cnt_o` | out | `16*PERF_CW` | Performance counters (§14). |

## 3. Commands and operand framing

* A command is accepted at a rising edge where `cmd_valid_i && cmd_ready_o`. All `cmd_*` fields
  are sampled at that edge. Up to `CMD_DEPTH` commands can be queued ahead of the one being
  issued.
* **Framing rule.** Command *k* consumes exactly **ceil(vl_k / NUM_LANES)** operand beats,
  immediately after the beats of command *k − 1*. This holds whatever the operation, the
  broadcast bits, the mask or the command's legality. A command with vl = 0 consumes no beat. The
  producer therefore needs only vl to frame the stream. It never needs to know whether a command
  is legal or which operands an operation reads.
* Operand words of tail positions, masked positions, broadcast operands and operands the
  operation does not read are **ignored**. They never influence a result or a flag. The
  testbench fills them with random NaNs and signalling NaNs to check this.
* **Independence.** The command and operand channels are independent valid/ready streams. A
  producer must not make `cmd_valid_i` wait for `opnd_ready_o`, because operand beats are only
  accepted while their command is being issued.

## 4. Operations

### 4.1 Element operations

`cmd_op_i` uses the Module 02 encoding (`hpc_vector_pkg`, Module 02 `docs/LANE_INTERFACE.md` §3).
Every lane operation is available on every element.

| Code | Op | Element result | | Code | Op | Element result |
|---|---|---|---|---|---|---|
| 0x00 | FMV | a (bit-exact) | | 0x08 | FMIN | minimumNumber(a, b) |
| **0x01** | **FADD** | **a + b** | | 0x09 | FMAX | maximumNumber(a, b) |
| 0x02 | FSUB | a − b | | 0x0A | FEQ | a = b ? 1 : 0 |
| **0x03** | **FMUL** | **a × b** | | 0x0B | FLT | a < b ? 1 : 0 |
| **0x04** | **FMADD** | **(a × b) + c, one rounding** | | 0x0C | FLE | a ≤ b ? 1 : 0 |
| 0x05 | FMSUB | (a × b) − c | | 0x10 | IADD | a + b mod 2³² |
| 0x06 | FNMSUB | −(a × b) + c | | 0x11 | IMUL | a × b mod 2³² |
| 0x07 | FNMADD | −(a × b) − c | | | | |

The three operations the brief makes mandatory are in bold. IEEE 754-2019 semantics are those of
Module 02 `docs/FP_SEMANTICS.md`:

* RISC-V canonical NaN;
* tininess detected after rounding;
* full subnormal support.

### 4.2 Sum reduction (`cmd_red_i` = 1)

The command's element operation is computed for every active element, and the element results
are summed in the order defined in `docs/REDUCTION.md`, starting from `cmd_scalar_i`:

* `op = FMV` gives the vector sum Σ aᵢ;
* `op = FMUL` gives the (unfused) dot product Σ aᵢbᵢ;
* any of FADD, FSUB and the FMA family can also be reduced.

A reduction emits **no result beats**. Its result is `cpl_result_o`.

### 4.3 Legality

A command is **illegal** if any of the following holds:

* its opcode is reserved;
* its opcode is removed by `EN_FCMP = 0` or `EN_INT = 0`;
* it is a rounding operation (codes 0x01–0x07) with `cmd_rm_i` ∈ {5, 6, 7};
* it is a reduction (`cmd_red_i` = 1) and **any** of the following holds:
  * `RED_EN` = 0;
  * the opcode is not 0x00–0x07;
  * `cmd_rm_i` > 4 (reductions always round, even for FMV);
  * `cmd_bcast_i` ≠ 0.

Legality does not depend on vl. An illegal command:

* still consumes its ceil(vl/N) operand beats (framing rule);
* executes nothing — no lane ever sees it (a simulation assertion checks that lanes never report
  an illegal operation);
* if elementwise, still produces its ceil(vl/N) result beats, each with `res_mask_o` = 0,
  data 0 and flags 0;
* completes in order with `cpl_illegal_o` = 1, `cpl_flags_o` = 0, `cpl_count_o` = 0 and
  `cpl_result_o` = 0.

## 5. Vector length and element-to-lane mapping

```
element e (0 <= e < vl)  ->  beat g = floor(e / N),  lane l = e mod N
beats per command        =  ceil(vl / N)        (0 for vl = 0)
```

* Beat *g* carries elements *gN … gN + N − 1* in lanes *0 … N − 1*, in the operand stream and
  in the result stream alike. This is the "beat = N consecutive elements" layout of
  `sfv_vec_engine` and BandwidthLab, so a row of N word-interleaved SRAM banks maps to one beat.
* **Vectors longer than N** are processed as consecutive beats, one per cycle at full rate. The
  only limit is 2^VL_W − 1 elements per command. **Nothing is ever truncated.** The testbench
  runs vl = 65 535 on every array size.
* **Tail.** In the last beat, positions with *gN + l ≥ vl* are inactive. When vl is a multiple
  of N there is no tail.

## 6. Operand sources

| Source | Supported | Notes |
|---|---|---|
| Per-lane operands through a streaming interface | **yes** | `opnd_a/b/c_i`, one beat per handshake. |
| Broadcast scalar | **yes** | `cmd_bcast_i` replaces operand a, b and/or c of every element by `cmd_scalar_i`, e.g. AXPY y = αx + y with `op = FMADD`, `bcast = 001`. The beat is still consumed (framing rule). |
| Gathered from SRAM | **no** | The array has no memory port. An upstream DMA / VRF reader forms beats (§10). |
| Cache-coherent interface | **no** | None exists or is implied. |

## 7. Masking

```
active(e) = legal  &  (e < vl)  &  (cmd_vm_i == 0  |  mask_g[l] == 1)
```

An **inactive** element (tail, masked or illegal command):

* is not executed: tail positions are not sent to the lane, and masked positions are sent with
  the lane's `lane_en_i` = 0, which the lane consumes without decoding, executing or producing
  anything (Module 02 `LANE_INTERFACE.md` §8);
* appears in its result beat with **data 0, flags 0 and `res_mask_o` bit 0**;
* contributes **nothing** to `cpl_flags_o`, `cpl_count_o` or a reduction;
* cannot disturb an active element, whatever its operand values.

Merge or undisturbed policies are the consumer's choice. Use `res_mask_o` as the write enable to
keep old destination values. Writing the zeros gives a zeroing policy.

## 8. Result beats

* Elementwise commands produce **exactly one result beat per operand beat**, in command order and
  beat order. `res_beat_o` counts 0 … ceil(vl/N) − 1, and `res_last_o` marks the last beat.
* `res_tid_o` is the command's transaction id. Association does not rely on ids being unique,
  because order is preserved.
* Reductions and vl = 0 commands produce no result beats.

## 9. Completion records

### 9.1 Ordering guarantees

1. **Exactly one** completion record per accepted command, in **command acceptance order**,
   whatever the operation, the latencies, the stalls or the backpressure.
2. A command's completion record is presented only **after its last result beat has been handed
   over** (`res_valid_o && res_ready_i`). A consumer that sees completion *k* has received all of
   command *k*'s data.
3. Result beats of command *k + 1* may be handed over before completion *k*. The two channels are
   only ordered as stated in item 2.
4. **Deadlock rule for consumers.** `res_ready_i` must not wait for `cpl_valid_o`. A completion
   waits for its last result beat, so a consumer that waits the other way round deadlocks.

### 9.2 Exception aggregation

* `cpl_flags_o` is the OR of the `{NV,DZ,OF,UF,NX}` flags of every active element of the
  command.
* For a reduction it also includes the flags of every tree and accumulator add.
* Flags of inactive elements are never included.
* DZ is never set, because there is no division.
* The per-element flags of an elementwise command are also delivered in `res_flags_o`.

This matches the RISC-V `fflags` model: OR `cpl_flags_o` into `fflags` in completion order.

### 9.3 Reduction result

`cpl_result_o` is the FP32 sum defined in `docs/REDUCTION.md`. A reduction with no active
element returns `cmd_scalar_i` unchanged, with no flags.

## 10. Timing and handshake contract

* `cmd_ready_o`, `opnd_ready_o`, `res_valid_o`, every `res_*` payload, `cpl_valid_o`, every
  `cpl_*` payload, `busy_o` and `perf_cnt_o` are **functions of registered state only**. There is
  no combinational path from any input to them. This is proved structurally for every
  `NUM_LANES`: `syn/run_synth.sh` takes the input cone of every such output, cut at flip-flops,
  and finds no input, with positive controls (`reports/synth/structural_check.txt`).
* `res_ready_i` and `cpl_ready_i` fan only into internal state. `opnd_valid_i` fans
  combinationally into the lanes' `in_valid` (allowed: a lane's `in_ready` never depends on its
  `in_valid`).
* While `res_valid_o && !res_ready_i`, the result payload is held constant and `res_valid_o`
  stays high. The same applies to `cpl_*`. While not valid, every payload output is 0, so the
  interface is deterministic and X-free.
* Operand beats are accepted at most one per cycle. Result beats and completion records are
  presented at most one per cycle each. Measured latencies and throughput: `docs/PERFORMANCE.md`.

### Integration notes

* **VRF (`register_bank.sf`, 16 x 128 b).** With `NUM_LANES = 4`, a VRF entry is one beat. A
  sequencer reads v[rs1], v[rs2], v[rs3] into `opnd_a/b/c_i` and the mask register into
  `opnd_mask_i`. It writes `res_data_o` to v[rd] with `res_mask_o` as the per-lane write enable.
* **DMA / DataFabric.** A stream adapter packs memory words into beats in element order (§5).
  Bandwidth needs: `docs/PERFORMANCE.md` §5.
* **`fflags`.** OR `cpl_flags_o` in completion order. Illegal commands report through
  `cpl_illegal_o`, in order.

## 11. Reset

* Asserting `rst_ni` (asynchronously, at any time) immediately forces:
  * `cmd_ready_o = opnd_ready_o = res_valid_o = cpl_valid_o = busy_o = 0`;
  * every payload output to 0;
  * every counter to 0.
* **Everything in flight is discarded**: queued commands, partially issued beats, lane
  operations, collected beats, reductions and pending completion records. No output is ever
  produced for a command accepted before the reset.
* All inputs are ignored during reset. After de-assertion, `cmd_ready_o` stays 0 during the first
  cycle, so the first command can be accepted at the second rising edge.
* Control state is reset to constants. Datapath registers are not reset (SilicaFlux rule 4) and
  are never observable. This is checked by 4-state simulation of the RTL and of the netlist.

## 12. Per-lane hold (`lane_hold_i`)

* `lane_hold_i[l]` is registered inside the array. While the registered bit is set, lane *l* is
  offered no new element.
* Elements already accepted continue, and results are collected normally.
* The other lanes keep taking their elements of the current beat. The beat is released upstream
  once every live lane has taken its element, so a held lane delays the stream but never
  corrupts or reorders it.

Uses:

* verification of mixed-lane stalls, which the testbench drives with five patterns, including
  out-of-phase holds;
* future throttling or isolation of individual lanes (thermal, power, a faulty lane).

## 13. `busy_o`

`busy_o` is 1 while any of the following holds:

* a command is queued or being issued;
* a beat is in the tracking queue;
* any lane is busy;
* a result beat is presented;
* the reduction unit holds an item;
* a completion record is waiting.

It is 0 when the array is idle. The testbench checks that it is never 0 while a command is
outstanding.

## 14. Performance counters (`perf_cnt_o`, map `hpc_varray_pkg::PC_*`)

Counter *i* is `perf_cnt_o[i*PERF_CW +: PERF_CW]`. Counters saturate, reset with `rst_ni` and
clear with `perf_clear_i`. Definitions: `docs/PERFORMANCE.md` §1.

| i | name | i | name |
|---|---|---|---|
| 0 | CYCLES | 8 | STALL_LANE |
| 1 | BUSY | 9 | STALL_TRK |
| 2 | CMD_IN | 10 | LANE_STALL |
| 3 | CMD_DONE | 11 | OPND_STARVE |
| 4 | BEAT_IN | 12 | RES_BP |
| 5 | BEAT_OUT | 13 | COLL_WAIT |
| 6 | ELEM_IN | 14 | RED_WAIT |
| 7 | ELEM_OUT | 15 | CPL_BP |
