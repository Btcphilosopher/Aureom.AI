# Third-party (SilicaFlux in-repo) sources -- vendored UNMODIFIED

Origin: repository `btcphilosopher/Aureom.AI`, branch snapshot at commit `ec432be`. Every file below is
byte-identical to the member of the named archive; verify with `cd third_party && sha256sum -c SHA256SUMS`.

| Directory | Origin archive (path in the repository) | Archive SHA-256 |
|---|---|---|
| `silicaflux-datafabric/` | `SilicaFlux-main/silicaflux-datafabric.zip` (identical copy also in `SilicaFlux2.0/SilicaFlux2.5/`) | `9f1f37357c8e25e00c214227894bca37c45e18ae9d7a993f87039a7679b665fb` |
| `silicaflux-sramlib/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` | `13b1cee1f913d7b5821f338ce0d12a038e02a1062538c66e4917cae2599beb16` |
| `silicaflux-hpc-m04-scratchpad/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m04-scratchpad.zip` | `1457466c57542c8c76c20b2d5ec5b466865fbe3fdecfd19d6d8f7955c5d5b524` |
| `silicaflux-hpc-m03-vector-array/` | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-hpc-m03-vector-array.zip` | `c1b6d2946c5bb56b22bcaeb1da6940f61c9a07defa21a2ea40a532138d021f3d` |

Subsets copied (only what Module 05 builds against, plus the interface documents it cites):

* **DataFabric**: `rtl/dma/` (`dma_defs.svh`, `dma_validate`, `dma_transfer_engine`, `dma_burst_engine`, `dma_fifo`),
  `rtl/interconnect/` (`sfb_crossbar` and its decoder / arbiter / request mux / response router / error slave,
  `sfb_reg_slice`, `sfb_skid_buffer`), `rtl/mem/sfb_sram_slave.sv`, `tb/common/sfb_protocol_checker.sv`,
  `docs/datafabric/{PROTOCOL,DMA,MEMORY_MAP}.md`.
* **SRAM Wrapper Library**: `sram_sp`, `sram_rsp_path`, the three raw backends and their GENERIC / FPGA / ASIC
  implementations, `sram_defs.svh`, macro id / function headers and pin-only macro black boxes (the ASIC files are
  needed only for elaboration of the generate branches; this module's simulations use the GENERIC backend).
  The DataFabric archive vendors the same library files; their hashes are identical.
* **Module 04 scratchpad**: `rtl/` (`hpc_scratchpad` and its sub-modules, `hpc_spm_defs.svh`) and docs 01 / 08.
* **Module 03 vector array**: `rtl/` (array + `rtl/lane/` = Module 02 lane, itself vendored unmodified by Module 03)
  and `docs/ARRAY_INTERFACE.md`.

Nothing here is edited. Module 05's own RTL is in `rtl/`; where it needed behaviour the reused modules do not have,
it wraps them (see `docs/00_repository_audit.md` section 2).
