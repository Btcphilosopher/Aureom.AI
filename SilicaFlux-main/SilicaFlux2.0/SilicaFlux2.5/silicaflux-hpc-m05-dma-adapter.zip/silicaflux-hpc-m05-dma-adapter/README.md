# SilicaFlux-HPC · Module 05 — HPC DMA Adapter and DataFabric Integration

**Primary source:** `rtl/hpc_dma_adapter.sv` · Aureom.AI | SilicaFlux-HPC

The hardware interface that connects the SilicaFlux-HPC compute tile to the **existing** DataFabric DMA engine, the
DataFabric SFB2 interconnect and the Module 04 scratchpad, so data moves between host-visible memory and the tile's
local memory without the CPU copying words.

* **Reuses, unmodified, the DataFabric DMA engines** (`dma_transfer_engine` = baseline, one transaction in flight;
  `dma_burst_engine` = buffered, single or dual port) — a DMA engine exists, so none was re-invented.
* **Speaks the real bus protocol, SFB2** (valid/ready request and response, one beat per transaction, no bursts, no
  IDs, write responses only after the write is performed). No AXI concept was introduced.
* **Adds what the tile needs**: a tagged descriptor stream and completion stream with queues, a two-space address
  router (scratchpad window vs. DataFabric) with response ownership, an SFB2 → scratchpad-port adapter with a tag
  check, a region rule, and performance counters.
* **Completion = every write acknowledged by its target** — verified by comparing all memory at the instant the
  completion is produced while the fabric slave commits writes only at its (late) response.

## Results (all from `reports/`, final run on the frozen RTL)

<!-- BEGIN RESULTS_TABLE -->
| Check | Result | Report |
|---|---|---|
| Unit regression, stage 1 (simple engine, baseline) | **207 / 207** | [regression.md](reports/regression.md) |
| Unit regression, stage 2 (buffered, single port) | **153 / 153** | [regression.md](reports/regression.md) |
| Unit regression, stage 3 (buffered, dual port, concurrency) | **207 / 207** | [regression.md](reports/regression.md) |
| Icarus cross-simulation (4-state) | **99 / 99** | [regression.md](reports/regression.md) |
| Router unit test (ownership, hold, unsolicited, throughput) | **18 / 18** | [regression.md](reports/regression.md) |
| Mutation testing (injected bugs in the new RTL detected) | **24 / 24** | [mutation.md](reports/mutation.md) |
| Integration: host -> DMA -> vector array -> DMA -> byte-exact memory compare | **4 / 4** | [integration.md](reports/integration.md) |
| Lint (Verilator -Wall, Icarus) + illegal-parameter rejection | **29 / 29** | [lint.md](reports/lint.md) |
| Yosys synthesis, latch-free (generic + Xilinx 7-series mapping) | **7 / 7** | [synth.md](reports/synth.md) |
| Measured cycle runs (self-checking) | **12 / 12 configurations, 288 transfers** | [cycles.md](reports/cycles.md) |
<!-- END RESULTS_TABLE -->

Headline measurements (RTL simulation cycles, `reports/cycles.md`, `reports/integration.md`):

<!-- BEGIN HEADLINE_TABLE -->
| Measurement | Simple engine (baseline) | Buffered, single port | Buffered, dual port |
|---|---|---|---|
| 4 KiB external → scratchpad, idle, 1-cycle slaves | 4101 cycles (1.00 B/cycle) | 2564 cycles (1.60 B/cycle) | 1032 cycles (3.97 B/cycle) |
| 4 KiB scratchpad → external | 4101 cycles (1.00 B/cycle) | 2564 cycles (1.60 B/cycle) | 1032 cycles (3.97 B/cycle) |
| Integration: DMA 3 × 4000 B into the scratchpad (with contention) | 12014 cycles | 7511 cycles | 3023 cycles |
| Integration: 6 double-buffered AXPY tiles, DMA overlapped with compute (serialised sum) | 18897 (27046) | 15111 (22497) | 10073 (16570) |
| Descriptor accepted → first bus request / last write ack → `cpl_valid` | 4 / 2 cycles | 4 / 2 | 4 / 2 |
<!-- END HEADLINE_TABLE -->

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit: DMA RTL, DataFabric, bus protocol, SRAM wrappers, decoder, clock/reset, verification; actual protocol (SFB2, not AXI); existing DMA reused | `docs/00_repository_audit.md`; `third_party/` (unmodified, SHA-256, `PROVENANCE.md`) |
| 2 | src / dst / length (bytes) / start / busy / completion / error / tag; ext → SPM, SPM → ext, SPM → SPM; exact address spaces | `rtl/hpc_dma_adapter.sv`, `docs/01_architecture_and_interface.md`, `docs/02_address_spaces.md` |
| 3 | Read / write requests and responses, write acknowledgements, back-pressure, buffering, completion tracking; completion = writes committed | `docs/03_transfer_semantics.md` §1–§3; `finalwrite` test; mutants M18 / M19 |
| 4 | Configurable buffering, bursts as the protocol defines them, tails, partial words, alignment, boundaries, overflow prevention, response ownership | `ENGINE / FIFO_DEPTH / BURST / MAX_OUT / DUAL_PORT / CMD_DEPTH / CPL_DEPTH / FAB_SLICE`; doc 02 §2, §5; doc 03 §2, §6 |
| 5 | Concurrent CPU / vector / DMA activity, arbitration, back-pressure; no dropped transfers, duplicate writes, misrouting, deadlock, silent corruption | doc 03 §7; `contention`, `bp` tests; router unit test; integration phase B |
| 6 | Bytes read / written, active cycles, stall cycles, outstanding requests, completion events, error events | `rtl/hpc_dma_perf.sv`, `docs/07_performance.md` §1 |
| 7 | 1-byte, aligned, non-multiple, long, consecutive, back-pressure, contention, reset, invalid addresses, bus errors, buffer-full, final-write completion; byte-accurate scoreboard | `tb/tb_hpc_dma_adapter.sv`, `docs/06_verification.md` §2, `reports/regression.md` |
| 8 | Host writes operands → DMA → compute → DMA → compare final memory | `tb/tb_hpc_tile.sv`, `scripts/gen_integ.py`, `reports/integration.md` |
| 9 | `hpc_dma_adapter.sv`, protocol adapters, unit and integration tests, state diagrams, timing documentation, measured cycle reports | table below |
| — | Start with a single outstanding transfer; add buffering and concurrency only after the baseline is verified | `scripts/run_regress.py` stages 1 → 2 → 3 (a failing stage stops the run); doc 06 |

## Deliverables

| Deliverable | Files |
|---|---|
| `hpc_dma_adapter.sv` | `rtl/hpc_dma_adapter.sv` (+ `rtl/hpc_dma_defs.svh`, `rtl/hpc_dma_perf.sv`) |
| Protocol adapters | `rtl/hpc_dma_route.sv` (SFB2 → scratchpad / DataFabric, response ownership), `rtl/hpc_dma_spm_port.sv` (SFB2 → Module 04 port, tag check); `sfb_reg_slice` reused for the fabric |
| Unit tests | `tb/tb_hpc_dma_adapter.sv` (18 tests), `tb/tb_hpc_dma_route.sv`; `scripts/run_regress.py`, `scripts/run_mutants.py`, `scripts/run_lint.py` |
| Integration test | `tb/tb_hpc_tile.sv`, `rtl/hpc_tile_vseq.sv` (reference sequencer), `scripts/gen_integ.py`, `model/fp32_exact.py`, `scripts/run_integ.py` |
| Transfer state diagrams | `docs/04_state_diagrams.md` |
| Timing documentation | `docs/05_timing.md` (built from measured cycle traces) |
| Measured simulation-cycle reports | `reports/cycles.md` (12 configurations × 4 directions × 6 lengths, traces), `reports/integration.md` |
| Other reports | `reports/SUMMARY.md`, `regression.md`, `mutation.md`, `lint.md`, `synth.md` (+ `.json`) |

## Interface at a glance

```
hpc_dma_adapter #(DW=32, ENGINE=0|1, FIFO_DEPTH=8, BURST=8, DUAL_PORT=0, MAX_OUT=2, MAX_LEN_LOG2=24,
                  SPM_BASE=32'h2000_0000, SPM_BYTES=65536, SPM_TAG_W=8, CMD_DEPTH=2, CPL_DEPTH=2, TAG_W=8,
                  FAB_SLICE=0, PERF_EN=1, CNT_W=32)
  clk, rst_n
  descriptor : cmd_valid/cmd_ready  cmd_src cmd_dst cmd_len(bytes) cmd_tag      cmd_abort
  completion : cpl_valid/cpl_ready  cpl_tag cpl_err cpl_code[3:0] cpl_err_addr cpl_bytes
  status     : busy active cur_tag ctl_state eng_state eng_bytes_done fifo_level
  scratchpad : spm_req_{valid,ready,we,addr,wdata,wstrb,tag}  spm_rsp_{valid,ready,rdata,err,err_code,we,tag}  (NP ports)
  DataFabric : fab_req_{valid,ready,write,addr,wdata,wstrb}   fab_rsp_{valid,ready,rdata,error}               (NP ports)
  events     : ev_cmd_accept ev_start ev_cpl ev_cpl_err ev_bytes_rd ev_bytes_wr ev_req_stall ev_outstanding ev_bus_err ev_tag_err
  counters   : perf_clear, perf_cnt[16*CNT_W]
```

Address spaces: `[SPM_BASE, SPM_BASE + SPM_BYTES)` → scratchpad port; everything else → DataFabric. Each range of a
descriptor must lie in one space (else `REGION`, no bus access). Completion codes 0–10 are the DataFabric DMA codes;
11 = REGION.

## Quick start

```bash
make dma-quick      # lint + stage 1 (baseline engine), one seed
```

```bash
make dma-test       # staged regression 1 -> 2 -> 3, Icarus cross-simulation, router unit test
```

```bash
make dma-integ      # host -> DMA -> vector array -> DMA -> compare
```

```bash
make dma-all        # everything, then reports/SUMMARY.md
```

```bash
make dma-sim TEST=finalwrite CFG='ENGINE=1 DUAL_PORT=1' ARGS='+seed=7'
```

Tools: Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python ≥ 3.10 with numpy. The directory is self-contained
(`third_party/` holds every reused source).

## Files

```
rtl/        hpc_dma_adapter.sv  hpc_dma_route.sv  hpc_dma_spm_port.sv  hpc_dma_perf.sv  hpc_dma_defs.svh  hpc_tile_vseq.sv
tb/         tb_hpc_dma_adapter.sv  tb_hpc_dma_route.sv  tb_hpc_tile.sv
model/      fp32_exact.py
scripts/    files.py common.py run_regress.py run_mutants.py run_lint.py run_integ.py gen_integ.py run_perf.py
            run_synth.py make_report.py fill_readme.py package.sh
docs/       00_repository_audit 01_architecture_and_interface 02_address_spaces 03_transfer_semantics
            04_state_diagrams 05_timing 06_verification 07_performance 08_integration_and_next_actions
reports/    SUMMARY regression mutation integration cycles lint synth (.md + .json, generated)
third_party/ silicaflux-datafabric  silicaflux-sramlib  silicaflux-hpc-m04-scratchpad  silicaflux-hpc-m03-vector-array
            (unmodified subsets) SHA256SUMS PROVENANCE.md
Makefile
```

## What is not claimed

No clock frequency, area or power (no timing closure, no PDK flow); no formal proof of the new RTL; no gate-level
simulation; no FPGA or silicon run; no firmware test (the register front end for host software is the first open
item). Synthesis numbers are Yosys logic-size indications. See `docs/06_verification.md` §7 and
`docs/08_integration_and_next_actions.md` §3.
