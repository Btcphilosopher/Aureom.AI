#!/usr/bin/env bash
# Package the module as silicaflux-hpc-m05-dma-adapter.zip (sources, docs, reports; no build products).
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
name="$(basename "$here")"
out="${1:-$(dirname "$here")/$name.zip}"
cd "$(dirname "$here")"
rm -f "$out"
zip -qr "$out" "$name" -x "$name/build/*" "$name/**/__pycache__/*" "$name/**/*.pyc"
echo "$out"
