"""File lists for the SilicaFlux-HPC Module 05 builds (single source for every script)."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TP = ROOT / "third_party"
DF = TP / "silicaflux-datafabric"
SL = TP / "silicaflux-sramlib/rtl/mem"
SPM = TP / "silicaflux-hpc-m04-scratchpad/rtl"
VA = TP / "silicaflux-hpc-m03-vector-array"

SRAMLIB = [SL / f for f in [
    "sram_rsp_path.sv", "sram_backend_1rw.sv", "sram_backend_1r1w.sv", "sram_backend_2rw.sv", "sram_sp.sv",
    "backends/generic/sram_generic_1rw.sv", "backends/generic/sram_generic_1r1w.sv", "backends/generic/sram_generic_2rw.sv",
    "backends/fpga/sram_fpga_1rw.sv", "backends/fpga/sram_fpga_1r1w.sv", "backends/fpga/sram_fpga_2rw.sv",
    "backends/asic/sram_asic_array.sv", "backends/asic/sram_leaf_sky130.sv", "backends/asic/sram_leaf_gf180.sv",
    "backends/asic/sram_leaf_ihp1p.sv", "backends/asic/sram_leaf_ihp2p.sv", "backends/asic/stubs/sram_macro_blackboxes.sv"]]
DMA = [DF / "rtl/dma" / f for f in ["dma_fifo.sv", "dma_validate.sv", "dma_transfer_engine.sv", "dma_burst_engine.sv"]]
XBAR = [DF / "rtl/interconnect" / f for f in [
    "sfb_addr_decoder.sv", "sfb_arbiter.sv", "sfb_req_mux.sv", "sfb_rsp_router.sv", "sfb_error_slave.sv",
    "sfb_crossbar.sv", "sfb_skid_buffer.sv", "sfb_reg_slice.sv"]]
SFB_MEM = [DF / "rtl/mem/sfb_sram_slave.sv"]
SCRATCHPAD = [SPM / f for f in ["hpc_spm_addr_map.sv", "hpc_spm_bank_arb.sv", "hpc_spm_bank.sv", "hpc_spm_perf.sv",
                                "hpc_scratchpad.sv"]]
VARRAY = [VA / l.strip() for l in (VA / "rtl/files.f").read_text().split() if l.strip()] if (VA / "rtl/files.f").exists() else \
         [VA / p for p in ["rtl/lane/hpc_vector_pkg.sv", "rtl/hpc_varray_pkg.sv", "rtl/lane/hpc_pipe.sv", "rtl/lane/hpc_lzc.sv",
                           "rtl/lane/hpc_fp32_round.sv", "rtl/lane/hpc_fp32_add.sv", "rtl/lane/hpc_fp32_mul.sv",
                           "rtl/lane/hpc_fp32_fma.sv", "rtl/lane/hpc_fp32_misc.sv", "rtl/lane/hpc_int32_mul.sv",
                           "rtl/lane/hpc_vector_lane.sv", "rtl/hpc_varray_fifo.sv", "rtl/hpc_varray_issue.sv",
                           "rtl/hpc_varray_collect.sv", "rtl/hpc_varray_reduce.sv", "rtl/hpc_varray_perf.sv",
                           "rtl/hpc_vector_array.sv"]]
ADAPTER = [ROOT / "rtl" / f for f in ["hpc_dma_perf.sv", "hpc_dma_spm_port.sv", "hpc_dma_route.sv", "hpc_dma_adapter.sv"]]
CHECKER = [DF / "tb/common/sfb_protocol_checker.sv"]
INCDIRS = [ROOT / "rtl", DF / "rtl/dma", SL, SL / "backends/asic", SPM]

UNIT_FILES = SRAMLIB + DMA + XBAR + SFB_MEM + SCRATCHPAD + ADAPTER + CHECKER + [ROOT / "tb/tb_hpc_dma_adapter.sv"]
SIM_DEFINES = ["HPC_DMA_ASSERT", "HPC_SPM_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"]

ROUTE_FILES = [ROOT / "rtl/hpc_dma_route.sv", ROOT / "tb/tb_hpc_dma_route.sv"]
ROUTE_DEFINES: list[str] = []          # the TB checks unsolicited responses itself (the RTL assertion would stop the run)

INTEG_DIR = ROOT / "build/integ"
TILE_FILES = SRAMLIB + DMA + XBAR + SFB_MEM + SCRATCHPAD + VARRAY + ADAPTER + [ROOT / "rtl/hpc_tile_vseq.sv"] + CHECKER + \
             [ROOT / "tb/tb_hpc_tile.sv"]
