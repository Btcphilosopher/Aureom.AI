#!/usr/bin/env python3
"""Fill README.md's results / headline tables and docs/07's integration table from the JSON reports
(between the BEGIN/END markers, so the documents cannot drift from the measured data)."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
R = ROOT / "reports"


def kv(line: str) -> dict:
    return {k: int(v) for k, v in re.findall(r"(\w+)=(\d+)", line)}


def put(path: Path, tag: str, body: str) -> None:
    s = path.read_text()
    a, b = f"<!-- BEGIN {tag} -->", f"<!-- END {tag} -->"
    if tag in s and a not in s:
        s = s.replace(tag, f"{a}\n{body}\n{b}")
    else:
        s = re.sub(re.escape(a) + r".*?" + re.escape(b), lambda _: f"{a}\n{body}\n{b}", s, flags=re.S)
    path.write_text(s)


def main() -> int:
    summ = (R / "SUMMARY.md").read_text().split("| Check | Result | Report |", 1)[1]
    results = "| Check | Result | Report |\n" + "\n".join(
        l.replace("](", "](reports/") for l in summ.strip().splitlines())
    put(ROOT / "README.md", "RESULTS_TABLE", results)

    cy = json.loads((R / "cycles.json").read_text())["results"]
    ig = json.loads((R / "integration.json").read_text())["results"]
    def rate(label, d, n=4096):
        x = next(x for x in cy if x["label"] == label)
        r = next(r for r in x["rows"] if r["dir"] == d and r["len"] == n)
        return f"{r['cpl']} cycles ({r['bpc']:.2f} B/cycle)"
    hl = ["| Measurement | Simple engine (baseline) | Buffered, single port | Buffered, dual port |", "|---|---|---|---|",
          "| 4 KiB external → scratchpad, idle, 1-cycle slaves | " + " | ".join(
              rate(l, "EXT->SPM") for l in ["E0 simple, SPM RL1", "E1 buffered 1-port FIFO8 BURST8 MAX_OUT2",
                                             "E1 buffered 2-port FIFO8 MAX_OUT2"]) + " |",
          "| 4 KiB scratchpad → external | " + " | ".join(
              rate(l, "SPM->EXT") for l in ["E0 simple, SPM RL1", "E1 buffered 1-port FIFO8 BURST8 MAX_OUT2",
                                             "E1 buffered 2-port FIFO8 MAX_OUT2"]) + " |"]
    v = {r["cfg"].get("ENGINE", 0) * 2 + r["cfg"].get("DUAL_PORT", 0): r for r in ig if r["sim"] == "verilator"}
    c = {k: kv(r["lines"]["CYCLES"]) for k, r in v.items()}
    p = {k: kv(r["lines"]["PHASEB"]) for k, r in v.items()}
    order = [0, 2, 3]
    hl += ["| Integration: DMA 3 × 4000 B into the scratchpad (with contention) | " +
           " | ".join(f"{c[k]['dma_in_12000B']} cycles" for k in order) + " |",
           "| Integration: 6 double-buffered AXPY tiles, DMA overlapped with compute (serialised sum) | " +
           " | ".join(f"{p[k]['total']} ({p[k]['serial_sum']})" for k in order) + " |",
           "| Descriptor accepted → first bus request / last write ack → `cpl_valid` | 4 / 2 cycles | 4 / 2 | 4 / 2 |"]
    put(ROOT / "README.md", "HEADLINE_TABLE", "\n".join(hl))

    names = {0: "simple", 2: "buffered single port", 3: "buffered dual port"}
    t = ["| Engine | DMA in 3 × 4000 B | DMA out 4000 + 3997 + 4000 B | Phase B total (serialised sum) | Both busy |",
         "|---|---|---|---|---|"]
    t += [f"| {names[k]} | {c[k]['dma_in_12000B']} | {c[k]['dma_out_11997B']} | {p[k]['total']} ({p[k]['serial_sum']}) | "
          f"{p[k]['both_busy']} |" for k in order]
    d7 = ROOT / "docs/07_performance.md"
    s = d7.read_text()
    old = re.search(r"\| Engine \| DMA in 3 × 4000 B \| DMA out 3 × ~4000 B.*?drift from the\nreport.\)", s, re.S)
    if old:
        s = s.replace(old.group(0), "INTEG_TABLE")
        d7.write_text(s)
    put(d7, "INTEG_TABLE", "\n".join(t) + "\n\n(generated from `reports/integration.md` by `scripts/fill_readme.py`)")
    print("README.md and docs/07_performance.md updated")
    return 0


if __name__ == "__main__":
    sys.exit(main())
