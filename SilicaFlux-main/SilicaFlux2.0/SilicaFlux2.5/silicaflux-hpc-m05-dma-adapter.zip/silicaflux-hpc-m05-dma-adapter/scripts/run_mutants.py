#!/usr/bin/env python3
"""Mutation testing of the NEW Module 05 RTL: every mutant is a deliberate design bug; the unit testbench must
detect each one (a test reports FAIL).  Reused DataFabric / Module 04 RTL is not mutated (it carries its own
mutation evidence).  usage: run_mutants.py [--jobs J] [--only M03]"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import shutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import files as F  # noqa: E402
from common import BUILD, run_sim, verilator_build, write_report  # noqa: E402

S0 = dict(ENGINE=0)
B1 = dict(ENGINE=1)
DP = dict(ENGINE=1, DUAL_PORT=1, MAX_OUT=4)
PAR = dict(ENGINE=0, SPM_ECC=1)
# id, file, old, new, description, config, tests to try (in order)
MUTANTS = [
 ("M01", "hpc_dma_spm_port.sv", "assign spm_req_wstrb = req_wstrb;", "assign spm_req_wstrb = '1;",
  "scratchpad writes ignore the byte strobe (tail bytes overwritten)", S0, ["tails", "len1"]),
 ("M02", "hpc_dma_spm_port.sv", "wire tag_bad = spm_rsp_valid &&", "wire tag_bad = 1'b0 &&",
  "response-ownership (tag) check removed", S0, ["tagerr"]),
 ("M03", "hpc_dma_spm_port.sv", "assign rsp_error     = spm_rsp_err || tag_bad;", "assign rsp_error     = tag_bad;",
  "scratchpad error responses (PARITY) not forwarded", PAR, ["spmerr"]),
 ("M04", "hpc_dma_spm_port.sv", "assign spm_req_tag   = {req_write, iss_seq_q};", "assign spm_req_tag   = {req_write, {SQW{1'b0}}};",
  "request tags not numbered", S0, ["smoke"]),
 ("M05", "hpc_dma_spm_port.sv", "assign rsp_rdata     = (spm_rsp_err || tag_bad) ? '0 : spm_rsp_rdata;",
  "assign rsp_rdata     = spm_rsp_rdata;", "read data not zeroed on a failed ownership check (SFB2 R8)", S0, ["tagerr"]),
 ("M06", "hpc_dma_route.sv", "wire sel_fab = (req_addr[31:CB] != SPM_BASE[31:CB]);",
  "wire sel_fab = (req_addr[31:CB+1] != SPM_BASE[31:CB+1]);", "scratchpad window decoded twice as large (aliasing)", S0,
  ["invalid", "random"]),
 ("M07", "hpc_dma_route.sv", "always_ff @(posedge clk) if (req_hs) info_q[wp_q] <= {req_write, req_write ? nbytes : BCW'(0)};",
  "always_ff @(posedge clk) if (req_hs) info_q[wp_q] <= {req_write, req_write ? BCW'(SB) : BCW'(0)};",
  "committed-byte events count full words instead of strobe bytes", S0, ["tails"]),
 ("M08", "hpc_dma_route.sv", "assign ev_rd_ok       = rsp_hs && !rsp_error && !head[BCW];",
  "assign ev_rd_ok       = rsp_hs && !head[BCW];", "bytes-read counter includes failed reads", S0, ["buserr", "invalid"]),
 ("M09", "hpc_dma_route.sv", "wire allow   = (cnt_eff == '0) || ((tgt_q == sel_fab) && (cnt_eff < CW'(MAX_OUT)));",
  "wire allow   = 1'b1;", "outstanding limit and target-switch hold removed", DP, ["smoke", "consec", "contention"]),
 ("M23", "hpc_dma_route.sv", "  wire [CW-1:0] cnt_eff = cnt_q - CW'(rsp_hs);", "  wire [CW-1:0] cnt_eff = cnt_q;",
  "no retire-and-issue: one bubble per transaction (performance bug)", S0, ["smoke"]),
 ("M24", "hpc_dma_route.sv", "  wire allow   = (cnt_eff == '0) || ((tgt_q == sel_fab) && (cnt_eff < CW'(MAX_OUT)));",
  "  wire allow   = (cnt_eff < CW'(MAX_OUT));", "target-switch hold removed (outstanding limit kept)", DP, ["smoke"]),
 ("M10", "hpc_dma_adapter.sv", "  assign desc_take     = (st_q == `HPC_DMA_AST_IDLE) && desc_avail && cpl_space;",
  "  assign desc_take     = (st_q == `HPC_DMA_AST_IDLE) && desc_avail;", "no completion-slot reservation", S0, ["cplfull"]),
 ("M11", "hpc_dma_adapter.sv", "  wire reg_fail = (st_q == `HPC_DMA_AST_CHECK) && (vcode == `DMA_ERR_NONE) && !(src_ok && dst_ok);",
  "  wire reg_fail = 1'b0;", "region (address-space crossing) check removed", S0, ["invalid", "random"]),
 ("M12", "hpc_dma_adapter.sv", "cpl_wdata = {d_tag, e_fail, e_fail ? e_code : `DMA_ERR_NONE, e_fail ? e_addr : 32'd0, e_bytes};",
  "cpl_wdata = {d_tag, e_fail, e_fail ? e_code : `DMA_ERR_NONE, e_fail ? e_addr : 32'd0, d_len};",
  "completion reports the requested length instead of the acknowledged bytes", S0, ["buserr", "invalid"]),
 ("M13", "hpc_dma_adapter.sv", "cpl_wdata = {d_tag, e_fail, e_fail ? e_code : `DMA_ERR_NONE, e_fail ? e_addr : 32'd0, e_bytes};",
  "cpl_wdata = {q_tag, e_fail, e_fail ? e_code : `DMA_ERR_NONE, e_fail ? e_addr : 32'd0, e_bytes};",
  "completion carries the queue head's tag (wrong association)", S0, ["consec"]),
 ("M14", "hpc_dma_adapter.sv", "  wire e_abort  = cmd_abort && (st_q == `HPC_DMA_AST_RUN);", "  wire e_abort  = 1'b0;",
  "abort ignored", S0, ["abort"]),
 ("M15", "hpc_dma_adapter.sv", "        `HPC_DMA_AST_RUN:   if (e_done || e_fail) st_q <= `HPC_DMA_AST_IDLE;",
  "        `HPC_DMA_AST_RUN:   if (e_done) st_q <= `HPC_DMA_AST_IDLE;", "failed transfers never leave RUN (hang)", S0,
  ["invalid"]),
 ("M16", "hpc_dma_adapter.sv", "    boundary = (a_hi == SPM_BASE[31:CB]) ? W_HI[31:0] : SPM_BASE;",
  "    boundary = (a_hi == SPM_BASE[31:CB]) ? SPM_BASE : W_HI[31:0];", "REGION error reports the wrong boundary", S0,
  ["invalid"]),
 ("M17", "hpc_dma_adapter.sv", "    assign cmd_ready  = (cmd_count < (CQW+1)'(CMD_DEPTH));", "    assign cmd_ready  = 1'b1;",
  "descriptor queue overflow (cmd_ready ignores fullness)", S0, ["cplfull", "consec"]),
 ("M18", "hpc_dma_adapter.sv", "        `HPC_DMA_AST_RUN:   if (e_done || e_fail) st_q <= `HPC_DMA_AST_IDLE;",
  "        `HPC_DMA_AST_RUN:   if (e_done || e_fail || (eng_state == `DMA_ST_ISSUE_WRITE && (fab_req_ready[0] || spm_req_ready[0]) && "
  "e_bytes + 32'(SB) >= d_len)) st_q <= `HPC_DMA_AST_IDLE;",
  "EARLY COMPLETION: done when the final write is ISSUED, not acknowledged", S0, ["finalwrite", "smoke"]),
 ("M19", "hpc_dma_adapter.sv", "      cpl_wdata = {d_tag, e_fail, e_fail ? e_code : `DMA_ERR_NONE, e_fail ? e_addr : 32'd0, e_bytes};\n    end",
  "      cpl_wdata = {d_tag, e_fail, e_fail ? e_code : `DMA_ERR_NONE, e_fail ? e_addr : 32'd0, e_bytes};\n    end\n"
  "    else if (st_q == `HPC_DMA_AST_RUN && eng_state == `DMA_ST_ISSUE_WRITE && (fab_req_ready[0] || spm_req_ready[0]) && e_bytes + 32'(SB) >= d_len) begin\n"
  "      cpl_push = 1'b1; cpl_wdata = {d_tag, 1'b0, `DMA_ERR_NONE, 32'd0, d_len};\n    end",
  "EARLY COMPLETION record (pushed at final write issue, FSM unchanged)", S0, ["finalwrite", "smoke"]),
 ("M20", "hpc_dma_perf.sv", "        end else              c_q[i] <= sum[CNT_W] ? {CNT_W{1'b1}} : sum[CNT_W-1:0];",
  "        end else              c_q[i] <= sum[CNT_W-1:0] + CNT_W'(i == `HPC_DMA_PC_CPL_ERR && inc[i] != 0);",
  "error-completion counter double counts", S0, ["invalid"]),
 ("M21", "hpc_dma_route.sv", "  assign rsp_valid     = own && (tgt_q ? fab_rsp_valid : spm_rsp_valid);",
  "  assign rsp_valid     = (tgt_q ? fab_rsp_valid : spm_rsp_valid);", "router forwards responses without ownership", S0,
  ["contention", "consec"]),
 ("M22", "hpc_dma_adapter.sv", "  wire e_start  = (st_q == `HPC_DMA_AST_CHECK) && !reg_fail;",
  "  wire e_start  = (st_q == `HPC_DMA_AST_CHECK);", "engine started although the region check failed", S0, ["invalid"]),
]


def build_mutant(m):
    mid, fname, old, new, *_ = m
    d = BUILD / "mut" / mid
    if d.exists():
        shutil.rmtree(d)
    (d / "rtl").mkdir(parents=True)
    for f in (F.ROOT / "rtl").iterdir():
        shutil.copy(f, d / "rtl" / f.name)
    src = (d / "rtl" / fname).read_text()
    if src.count(old) != 1:
        raise RuntimeError(f"{mid}: pattern found {src.count(old)} times in {fname}")
    (d / "rtl" / fname).write_text(src.replace(old, new))
    files = [d / "rtl" / f.name if f.parent == F.ROOT / "rtl" else f for f in F.UNIT_FILES]
    return files, d


def run_route(m, d):
    mid, fname, old, new, desc, cfg, tests = m
    files = [d / "rtl/hpc_dma_route.sv", F.ROOT / "tb/tb_hpc_dma_route.sv"]
    for mo in (2, 1):
        exe = verilator_build("tb_hpc_dma_route", files, dict(MAX_OUT=mo), tag=f"mut_{mid}_{mo}", defines=F.ROUTE_DEFINES,
                              extra=[f"-I{d / 'rtl'}"])
        for un in (0, 1):
            ok, log, _ = run_sim("verilator", exe, ["+seed=1", f"+unsol={un}"], timeout=600)
            if not ok:
                first = next((l for l in log.splitlines() if "ERROR" in l or "FAIL" in l), "")
                return dict(id=mid, desc=desc, killed=True, by=f"router unit TB (MAX_OUT {mo}, unsol {un})",
                            note=first.strip()[:160])
    return None


def run_one(m):
    mid, fname, old, new, desc, cfg, tests = m
    files, d = build_mutant(m)
    if fname == "hpc_dma_route.sv":
        r = run_route(m, d)
        if r:
            return r
    try:
        exe = verilator_build("tb_hpc_dma_adapter", files, cfg, tag="mut_" + mid,
                              extra=[f"-I{d / 'rtl'}"])
    except RuntimeError as e:
        return dict(id=mid, desc=desc, killed=True, by="build/elaboration", note=str(e))
    for t in tests:
        for seed in (1, 2):
            ok, log, _ = run_sim("verilator", exe, [f"+test={t}", f"+seed={seed}", "+n=120"], timeout=900)
            if not ok:
                first = next((l for l in log.splitlines() if "ERROR" in l or "%Error" in l or "TIMEOUT" in l), "")
                return dict(id=mid, desc=desc, killed=True, by=f"{t} (seed {seed})", note=first.strip()[:160])
    return dict(id=mid, desc=desc, killed=False, by="-", note="SURVIVED")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    ms = [m for m in MUTANTS if not a.only or m[0] == a.only]
    t0 = time.time()
    with cf.ThreadPoolExecutor(a.jobs) as ex:
        res = sorted(ex.map(run_one, ms), key=lambda r: r["id"])
    for r in res:
        print(f"{r['id']} {'KILLED' if r['killed'] else 'SURVIVED'} by {r['by']}: {r['desc']} | {r['note']}")
    k = sum(r["killed"] for r in res)
    md = ["# Mutation testing -- new Module 05 RTL", "",
          f"Generated by `scripts/run_mutants.py` ({time.strftime('%Y-%m-%d %H:%M')}, {time.time() - t0:.0f} s). "
          "Each mutant is one deliberate bug in `rtl/`; reused DataFabric / Module 04 RTL is not mutated.", "",
          f"**{k} / {len(res)} mutants killed.**", "", "| Id | Injected bug | Killed by | First failure |", "|---|---|---|---|"]
    md += [f"| {r['id']} | {r['desc']} | {r['by']} | {r['note'].replace('|', '/')} |" for r in res]
    write_report("mutation", "\n".join(md) + "\n", dict(killed=k, total=len(res), results=res))
    return 0 if k == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
