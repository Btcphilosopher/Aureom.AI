#!/usr/bin/env python3
"""Staged unit regression of hpc_dma_adapter (tb/tb_hpc_dma_adapter.sv).

Stage 1  baseline: simple engine (one transaction in flight) -- must pass before stage 2 is run
Stage 2  buffered engine, single port (FIFO_DEPTH / BURST / MAX_OUT), queue depths, register slice
Stage 3  buffered dual-port engine + concurrency (1R1W banks, scratchpad request queues, 64-bit)
Icarus   cross-simulation of one configuration per stage (4-state)

usage: run_regress.py [--stage 1|2|3|all] [--seeds N] [--jobs J] [--quick] [--no-icarus]
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import json
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import files as F  # noqa: E402
from common import icarus_build, run_sim, tool_versions, verilator_build, write_report  # noqa: E402

TESTS = ["smoke", "len1", "tails", "aligned", "long", "consec", "bp", "contention", "random", "invalid", "buserr",
         "tagerr", "buffull", "cplfull", "finalwrite", "abort", "reset", "spmerr"]
NEEDS = {"spmerr": "SPM_ECC"}          # tests that only apply to configurations with this parameter set

STAGES = {
    1: [
        ("S1a simple, CMD2 CPL2, SPM 4 banks RL1", dict(ENGINE=0)),
        ("S1b simple, no cmd queue, SPM RL2 + request queue 2", dict(ENGINE=0, CMD_DEPTH=0, SPM_RL=2, SPM_QD=2)),
        ("S1c simple, fabric reg slice, 1 bank, fixed-priority fabric, CMD8 CPL4",
         dict(ENGINE=0, FAB_SLICE=1, SPM_NB=1, NVEC=1, ARB=0, CMD_DEPTH=8, CPL_DEPTH=4)),
        ("S1d simple, byte-parity scratchpad", dict(ENGINE=0, SPM_ECC=1)),
    ],
    2: [
        ("S2a buffered FIFO8 BURST8 MAX_OUT2", dict(ENGINE=1)),
        ("S2b buffered FIFO2 BURST1 MAX_OUT1", dict(ENGINE=1, FIFO_DEPTH=2, BURST=1, MAX_OUT=1)),
        ("S2c buffered FIFO16 BURST4 MAX_OUT4, SPM RL3, reg slice, CMD4 CPL4",
         dict(ENGINE=1, FIFO_DEPTH=16, BURST=4, MAX_OUT=4, SPM_RL=3, FAB_SLICE=1, CMD_DEPTH=4, CPL_DEPTH=4)),
    ],
    3: [
        ("S3a dual-port FIFO8 MAX_OUT2", dict(ENGINE=1, DUAL_PORT=1)),
        ("S3b dual-port FIFO4 MAX_OUT4, 2 banks 1R1W, SPM queue 4, reg slice",
         dict(ENGINE=1, DUAL_PORT=1, FIFO_DEPTH=4, BURST=4, MAX_OUT=4, SPM_NB=2, SPM_PMODE=1, SPM_QD=4, FAB_SLICE=1)),
        ("S3c dual-port 64-bit, 8 banks 2RW, 3 vector ports", dict(ENGINE=1, DUAL_PORT=1, DW=64, SPM_NB=8, SPM_PMODE=2, NVEC=3)),
        ("S3d dual-port MAX_OUT4, byte-parity scratchpad", dict(ENGINE=1, DUAL_PORT=1, MAX_OUT=4, SPM_ECC=1)),
    ],
}
ICARUS = [("S1a", dict(ENGINE=0)), ("S2a", dict(ENGINE=1)), ("S3a", dict(ENGINE=1, DUAL_PORT=1))]
ICARUS_TESTS = ["smoke", "tails", "consec", "contention", "invalid", "buserr", "tagerr", "cplfull", "finalwrite", "abort", "reset"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage", default="all")
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--no-icarus", action="store_true")
    a = ap.parse_args()
    stages = [1, 2, 3] if a.stage == "all" else [int(a.stage)]
    seeds = list(range(1, (1 if a.quick else a.seeds) + 1))
    results, t0 = [], time.time()

    def run_cfg(label, cfg, sim, tests):
        exe = (verilator_build if sim == "verilator" else icarus_build)("tb_hpc_dma_adapter", F.UNIT_FILES, cfg)
        jobs = [(t, s) for t in tests for s in seeds]
        out = []
        with cf.ThreadPoolExecutor(a.jobs) as ex:
            futs = {ex.submit(run_sim, sim, exe, [f"+test={t}", f"+seed={s}", "+n=150"]): (t, s) for t, s in jobs}
            for f in cf.as_completed(futs):
                t, s = futs[f]
                ok, log, dt = f.result()
                st = re.search(r"TB_HPC_DMA STATS (.*)", log)
                out.append(dict(config=label, cfg=cfg, sim=sim, test=t, seed=s, ok=ok, secs=round(dt, 1),
                                stats=st.group(1) if st else "",
                                errors=[l for l in log.splitlines() if "ERROR" in l or "%Error" in l][:6]))
                if not ok:
                    print(f"  FAIL {label} {sim} {t} seed {s}", *out[-1]["errors"], sep="\n    ")
        return out

    for st in stages:
        print(f"== stage {st}")
        stage_ok = True
        for label, cfg in STAGES[st]:
            r = run_cfg(label, cfg, "verilator", [t for t in TESTS if t not in NEEDS or cfg.get(NEEDS[t])])
            n_ok = sum(x["ok"] for x in r)
            print(f"  {label}: {n_ok}/{len(r)}")
            stage_ok &= n_ok == len(r)
            results += [dict(x, stage=st) for x in r]
        if not stage_ok:
            print(f"stage {st} failed -- later stages not run (baseline first)")
            break
    if not a.no_icarus and all(x["ok"] for x in results):
        print("== icarus cross-simulation")
        for label, cfg in ICARUS:
            if int(label[1]) not in stages:
                continue
            r = run_cfg(label, cfg, "icarus", ICARUS_TESTS)
            print(f"  {label}: {sum(x['ok'] for x in r)}/{len(r)}")
            results += [dict(x, stage="icarus") for x in r]

    if all(x["ok"] for x in results):
        print("== router unit test (tb_hpc_dma_route)")
        for mo in (1, 2, 4):
            exe = verilator_build("tb_hpc_dma_route", F.ROUTE_FILES, dict(MAX_OUT=mo), defines=F.ROUTE_DEFINES)
            for un in (0, 1):
                for s in seeds:
                    ok, log, dt = run_sim("verilator", exe, [f"+seed={s}", f"+unsol={un}"])
                    st = re.search(r"TB_HPC_ROUTE STATS (.*)", log)
                    results.append(dict(stage="route", config=f"router MAX_OUT={mo}", cfg=dict(MAX_OUT=mo),
                                        sim="verilator", test="route_unsol" if un else "route", seed=s, ok=ok,
                                        secs=round(dt, 1), stats=st.group(1) if st else "",
                                        errors=[l for l in log.splitlines() if "ERROR" in l][:6]))
            print(f"  MAX_OUT={mo}: {sum(x['ok'] for x in results if x['stage'] == 'route' and x['cfg'] == dict(MAX_OUT=mo))}"
                  f"/{2 * len(seeds)}")
    total, passed = len(results), sum(x["ok"] for x in results)
    md = ["# Unit regression -- hpc_dma_adapter", "",
          f"Generated by `scripts/run_regress.py` ({time.strftime('%Y-%m-%d %H:%M')}, {time.time() - t0:.0f} s wall).",
          f"Seeds per test: {len(seeds)}. Testbench: `tb/tb_hpc_dma_adapter.sv`. Tools: " +
          ", ".join(f"{k} = {v}" for k, v in tool_versions().items()), "",
          f"**Total: {passed} / {total} runs pass.**", "",
          "| Stage | Configuration | Simulator | Runs | Pass |", "|---|---|---|---|---|"]
    keys = []
    for x in results:
        k = (x["stage"], x["config"], x["sim"])
        if k not in keys:
            keys.append(k)
    for k in keys:
        rs = [x for x in results if (x["stage"], x["config"], x["sim"]) == k]
        md.append(f"| {k[0]} | {k[1]} | {k[2]} | {len(rs)} | {sum(x['ok'] for x in rs)} |")
    md += ["", "## Per test (all configurations and seeds)", "", "| Test | Runs | Pass |", "|---|---|---|"]
    for t in TESTS + ["route", "route_unsol"]:
        rs = [x for x in results if x["test"] == t]
        if rs:
            md.append(f"| {t} | {len(rs)} | {sum(x['ok'] for x in rs)} |")
    fails = [x for x in results if not x["ok"]]
    if fails:
        md += ["", "## Failures", ""] + [f"* {x['config']} {x['sim']} {x['test']} seed {x['seed']}: " +
                                         "; ".join(x["errors"]) for x in fails]
    md += ["", "## Run statistics (seed 1, from the testbench's STATS line)", "",
           "| Configuration | Sim | Test | Statistics |", "|---|---|---|---|"]
    order = TESTS + ["route", "route_unsol"]
    for x in sorted(results, key=lambda x: (str(x["stage"]), x["config"], x["sim"], order.index(x["test"]))):
        if x["seed"] == 1:
            md.append(f"| {x['config']} | {x['sim']} | {x['test']} | `{x['stats']}` |")
    write_report("regression", "\n".join(md) + "\n", dict(total=total, passed=passed, results=results))
    print(f"TOTAL {passed}/{total}")
    return 0 if passed == total else 1


if __name__ == "__main__":
    sys.exit(main())
