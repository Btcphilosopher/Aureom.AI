#!/usr/bin/env python3
"""Generate the integration-test data for tb/tb_hpc_tile.sv (host -> DMA -> vector compute -> DMA -> compare).

Writes into <out>/:
  integ_cfg.svh   layout, lengths, scalars (single source shared with the testbench)
  ext_init.hex    64 KiB background of external SRAM (SRAM0 + SRAM1), 32-bit little-endian words
  spm_init.hex    64 KiB background of the scratchpad
  host_ops.hex    host front-door writes {addr[31:0], data[31:0]} of every operand word
  exp_ext.hex     expected final external memory image (every byte)
  exp_spm.hex     expected final scratchpad image (every byte)
Expected FP32 results are exact (model/fp32_exact.py: single rounding of the exact rational value).
usage: gen_integ.py <out_dir> [--seed S] [--lanes N]
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "model"))
import fp32_exact as fx  # noqa: E402

EXT_BASE, EXT_BYTES = 0x1000_0000, 0x1_0000          # SRAM0 0x1000_0000 + SRAM1 0x1000_8000, 32 KiB each
SPM_BASE, SPM_BYTES = 0x2000_0000, 0x1_0000
VA = 1000                                            # phase A vector length (not a multiple of the lanes)
K, T = 6, 256                                        # phase B: tiles x elements
L = dict(
    A=0x1000_0000, B=0x1000_1000, C=0x1000_2000, X=0x1000_3000, Y=0x1000_4800, HSCR=0x1000_7000,
    D=0x1000_8000, E=0x1000_9000, F=0x1000_A000, Z=0x1000_B000,
    SA=0x2000_0000, SB=0x2000_1000, SC=0x2000_2000, SD=0x2000_3000, SE=0x2000_4000, SF=0x2000_5000,
    SX=0x2000_8000, SY=0x2000_8800, SZ=0x2000_9000,
)
HSCR_BYTES = 0x1000
TILE_STRIDE = 0x400
E_LEN = 4 * VA - 3                                   # E is copied out with a partial final word


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("--seed", type=int, default=2026)
    ap.add_argument("--lanes", type=int, default=4)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    ext = bytearray(rng.getrandbits(8) for _ in range(EXT_BYTES))
    spm = bytearray(rng.getrandbits(8) for _ in range(SPM_BYTES))
    (out / "ext_init.hex").write_text("".join(f"{int.from_bytes(ext[i:i + 4], 'little'):08x}\n" for i in range(0, EXT_BYTES, 4)))
    (out / "spm_init.hex").write_text("".join(f"{int.from_bytes(spm[i:i + 4], 'little'):08x}\n" for i in range(0, SPM_BYTES, 4)))
    exp_ext, exp_spm = bytearray(ext), bytearray(spm)

    def put(img, base, addr, words, nbytes=None):
        bs = b"".join(w.to_bytes(4, "little") for w in words)
        bs = bs[:nbytes] if nbytes is not None else bs
        o = addr - base
        img[o:o + len(bs)] = bs

    def operands(i):
        # every 37th element: tiny a, b (2^-70..2^-64) and a SUBNORMAL c, so a*b + c rounds in the subnormal range
        if i % 37 == 5:
            return fx.rand_fp32(rng, -70, -64), fx.rand_fp32(rng, -70, -64), (rng.getrandbits(1) << 31) | rng.getrandbits(23)
        return fx.rand_fp32(rng, -12, 12), fx.rand_fp32(rng, -12, 12), fx.rand_fp32(rng, -12, 12)

    def nonzero_fma(x, y, z):
        return fx.bits_to_frac(x) * fx.bits_to_frac(y) + fx.bits_to_frac(z) != 0

    # ---------------------------------------------------------- phase A: D = A*B + C (fused), E = A + s, F = A*B (int)
    s_bits = fx.rand_fp32(rng, -3, 3)
    A, B, C = [], [], []
    for i in range(VA):
        while True:                                  # no exact-zero results (their sign is a separate rule)
            x, y, z = operands(i)
            if nonzero_fma(x, y, z) and fx.bits_to_frac(x) + fx.bits_to_frac(s_bits) != 0:
                break
        A.append(x); B.append(y); C.append(z)
    D = [fx.fmadd(A[i], B[i], C[i]) for i in range(VA)]
    E = [fx.fadd(A[i], s_bits) for i in range(VA)]
    F = [(A[i] * B[i]) & 0xFFFF_FFFF for i in range(VA)]
    n_sub = sum(1 for d in D if (d >> 23) & 0xFF == 0)
    # ---------------------------------------------------------- phase B: Z_k = alpha * X_k + Y_k (AXPY, alpha broadcast)
    alpha = fx.rand_fp32(rng, -2, 2)
    X = [[fx.rand_fp32(rng) for _ in range(T)] for _ in range(K)]
    Y = [[fx.rand_fp32(rng) for _ in range(T)] for _ in range(K)]
    Z = [[fx.fmadd(alpha, X[k][i], Y[k][i]) for i in range(T)] for k in range(K)]

    # host front-door operand writes
    ops = [(L["A"] + 4 * i, A[i]) for i in range(VA)] + [(L["B"] + 4 * i, B[i]) for i in range(VA)] + \
          [(L["C"] + 4 * i, C[i]) for i in range(VA)]
    for k in range(K):
        ops += [(L["X"] + k * TILE_STRIDE + 4 * i, X[k][i]) for i in range(T)]
        ops += [(L["Y"] + k * TILE_STRIDE + 4 * i, Y[k][i]) for i in range(T)]
    (out / "host_ops.hex").write_text("".join(f"{ad:08x}{d:08x}\n" for ad, d in ops))
    for ad, d in ops:
        put(exp_ext, EXT_BASE, ad, [d])

    # expected scratchpad: operand copies, full results, last two tiles of each double buffer
    put(exp_spm, SPM_BASE, L["SA"], A); put(exp_spm, SPM_BASE, L["SB"], B); put(exp_spm, SPM_BASE, L["SC"], C)
    put(exp_spm, SPM_BASE, L["SD"], D); put(exp_spm, SPM_BASE, L["SE"], E); put(exp_spm, SPM_BASE, L["SF"], F)
    for k in range(K):
        put(exp_spm, SPM_BASE, L["SX"] + (k % 2) * TILE_STRIDE, X[k])
        put(exp_spm, SPM_BASE, L["SY"] + (k % 2) * TILE_STRIDE, Y[k])
        put(exp_spm, SPM_BASE, L["SZ"] + (k % 2) * TILE_STRIDE, Z[k])
    # expected external results (E with a partial final word: bytes >= E_LEN untouched)
    put(exp_ext, EXT_BASE, L["D"], D); put(exp_ext, EXT_BASE, L["E"], E, E_LEN); put(exp_ext, EXT_BASE, L["F"], F)
    for k in range(K):
        put(exp_ext, EXT_BASE, L["Z"] + k * TILE_STRIDE, Z[k])
    (out / "exp_ext.hex").write_text("".join(f"{int.from_bytes(exp_ext[i:i + 4], 'little'):08x}\n" for i in range(0, EXT_BYTES, 4)))
    (out / "exp_spm.hex").write_text("".join(f"{int.from_bytes(exp_spm[i:i + 4], 'little'):08x}\n" for i in range(0, SPM_BYTES, 4)))

    cfg = [f"// GENERATED by scripts/gen_integ.py --seed {a.seed} -- do not edit",
           f"localparam int IG_LANES = {a.lanes};", f"localparam int IG_VA = {VA};", f"localparam int IG_K = {K};",
           f"localparam int IG_T = {T};", f"localparam int IG_E_LEN = {E_LEN};", f"localparam int IG_NOPS = {len(ops)};",
           f"localparam int IG_TILE_STRIDE = 32'h{TILE_STRIDE:x};", f"localparam int IG_HSCR_BYTES = 32'h{HSCR_BYTES:x};",
           f"localparam logic [31:0] IG_SCALAR = 32'h{s_bits:08x};", f"localparam logic [31:0] IG_ALPHA = 32'h{alpha:08x};"]
    cfg += [f"localparam logic [31:0] IG_{k} = 32'h{v:08x};" for k, v in L.items()]
    (out / "integ_cfg.svh").write_text("\n".join(cfg) + "\n")
    print(f"gen_integ: {len(ops)} host writes, phase A vl={VA} ({n_sub} subnormal FMA results), "
          f"phase B {K} tiles x {T}, alpha={alpha:08x}, scalar={s_bits:08x}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
