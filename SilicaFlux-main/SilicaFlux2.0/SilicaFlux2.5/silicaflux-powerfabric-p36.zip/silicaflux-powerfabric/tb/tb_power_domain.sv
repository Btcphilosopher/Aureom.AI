// =============================================================================
// SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
// tb_power_domain : self-checking testbench for silicaflux_power_domain
//
// Builds:  (default) BASE   - single supply domain, clock-enable control only
//          +define+FUTURE   - VEC, TNS, SRAM switchable (SIMULATION ONLY; the
//                             target technology has no switch / iso cells)
// Run:     +TEST=<name>|all   +SEED=<n>   +CYCLES=<n> (random test)
// Every check increments n_chk; every failure increments n_err and prints
// "FAIL".  The run ends with "RESULT: PASS|FAIL test=... checks=... errors=...".
// =============================================================================
`timescale 1ns/1ps
module tb_power_domain;
  import sf_pd_pkg::*;

  localparam int NR = 7;
  localparam int CTRL = 0, VEC = 1, TNS = 2, SRAM = 3, FAB = 4, EXT = 5, AON = 6;

`ifdef FUTURE
  localparam logic [NR-1:0] P_CLK   = 7'b0111110;
  localparam logic [NR-1:0] P_SW    = 7'b0001110;
  localparam logic [NR-1:0] P_LRET  = 7'b0000100;
  localparam logic [NR-1:0] P_SRAM  = 7'b0001010;
  localparam logic [NR-1:0] P_SRET  = 7'b0001000;
  localparam logic [NR-1:0] P_MUST  = 7'b0001000;
  localparam logic [NR-1:0] P_MBIST = 7'b0000010;
  localparam logic [NR-1:0] P_ABORT = 7'b0000110;
  localparam string BUILD = "FUTURE";
`else
  localparam logic [NR-1:0] P_CLK   = 7'b0111110;
  localparam logic [NR-1:0] P_SW    = 7'b0000000;
  localparam logic [NR-1:0] P_LRET  = 7'b0000000;
  localparam logic [NR-1:0] P_SRAM  = 7'b0001000;
  localparam logic [NR-1:0] P_SRET  = 7'b0000000;
  localparam logic [NR-1:0] P_MUST  = 7'b0001000;
  localparam logic [NR-1:0] P_MBIST = 7'b0000000;
  localparam logic [NR-1:0] P_ABORT = 7'b0000000;
  localparam string BUILD = "BASE";
`endif
  localparam logic [NR-1:0] P_THERM = 7'b0000110;
  // P_DEP[u][t]: region u uses region t (same as the DUT default DEP)
  // recovery orders: users first (EXTIF, TNS, VEC, SRAM, FABRIC) / providers first
  function automatic int users_first(input int i);
    case (i) 0: return 5; 1: return 2; 2: return 1; 3: return 3; default: return 4; endcase
  endfunction
  function automatic int providers_first(input int i);
    case (i) 0: return 4; 1: return 3; 2: return 1; 3: return 2; default: return 5; endcase
  endfunction
  localparam logic [NR*NR-1:0] P_DEP = {7'b0000000, 7'b0010000, 7'b0000000, 7'b0000000, 7'b0011000, 7'b0011000, 7'b0000000};

  // ---------------------------------------------------------------- clock / reset
  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  int unsigned cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;

  pd_cfg_t cfg;
  initial begin
    cfg = '0;
    cfg.quiesce_timeout = 16'd200;
    cfg.abort_timeout   = 16'd60;
    cfg.clk_ack_timeout = 8'd8;
    cfg.pgood_timeout   = 16'd120;
    cfg.pgood_stable    = 8'd4;
    cfg.iso_settle      = 4'd2;
    cfg.rst_hold        = 8'd4;
    cfg.rst_release     = 8'd2;
    cfg.ret_pulse       = 4'd2;
    cfg.sram_timeout    = 20'd400;
    cfg.drain_stable    = 4'd2;
  end

  // ---------------------------------------------------------------- DUT
  logic          cmd_valid = 1'b0;
  logic [2:0]    cmd_region = '0;
  pd_target_e    cmd_target = T_ACTIVE;
  logic          cmd_retain = 1'b0, cmd_allow_loss = 1'b0, cmd_abort_ok = 1'b0;
  logic          cmd_ready, rsp_valid, rsp_final;
  logic [2:0]    rsp_region;
  pd_evt_e       rsp_code;
  logic [NR-1:0] err_clr = '0;
  logic          supply_err_clr = 1'b0, therm = 1'b0, supply_pg = 1'b1, test_mode = 1'b0;

  wire  [NR-1:0] busy, q_ack, dma_pend, acc_pend, abort_ack, clk_ack, pgood, mret_ack, minit_done, mbd, mbf;
  wire  [NR-1:0] clk_en, quiesce, abort_r, iso, iso_pm, rst_r, pwr_en, ret_save, ret_hold, ret_restore;
  wire  [NR-1:0] mem_ret, mem_inv, mem_reinit, mem_ecc_clr, mbist_req, mbist_allow, done;
  wire  [NR-1:0][3:0] done_code;
  wire  [NR-1:0][1:0] done_src;
  pd_status_t [NR-1:0] status;
  wire  [NR-1:0][NUM_ERR-1:0] err;
  wire  supply_err, irq;

  silicaflux_power_domain #(
    .NR(NR), .CAP_CLK_GATE(P_CLK), .CAP_SWITCH(P_SW), .CAP_LOGIC_RET(P_LRET), .CAP_SRAM(P_SRAM),
    .CAP_SRAM_RET(P_SRET), .CAP_MUST_RETAIN(P_MUST), .CAP_MBIST_PWRUP(P_MBIST), .CAP_ABORT(P_ABORT),
    .CAP_BOOT_ON(7'b1111111), .THERM_MASK(P_THERM), .SUPPLY_MON(1'b1)
  ) dut (
    .clk_i(clk), .rst_ni(rst_n), .test_mode_i(test_mode), .cfg_i(cfg),
    .cmd_valid_i(cmd_valid), .cmd_ready_o(cmd_ready), .cmd_region_i(cmd_region), .cmd_target_i(cmd_target),
    .cmd_retain_i(cmd_retain), .cmd_allow_loss_i(cmd_allow_loss), .cmd_abort_ok_i(cmd_abort_ok),
    .rsp_valid_o(rsp_valid), .rsp_region_o(rsp_region), .rsp_code_o(rsp_code), .rsp_final_o(rsp_final),
    .err_clr_i(err_clr), .supply_err_clr_i(supply_err_clr),
    .therm_throttle_i(therm), .supply_pgood_i(supply_pg),
    .busy_i(busy), .q_ack_i(q_ack), .dma_wr_pend_i(dma_pend), .acc_op_pend_i(acc_pend),
    .abort_ack_i(abort_ack), .clk_ack_i(clk_ack), .pgood_i(pgood), .mem_ret_ack_i(mret_ack),
    .mem_reinit_done_i(minit_done), .mbist_done_i(mbd), .mbist_fail_i(mbf),
    .clk_en_o(clk_en), .quiesce_o(quiesce), .abort_o(abort_r), .iso_o(iso), .iso_pm_o(iso_pm),
    .rst_o(rst_r), .pwr_en_o(pwr_en), .ret_save_o(ret_save), .ret_hold_o(ret_hold),
    .ret_restore_o(ret_restore), .mem_ret_o(mem_ret), .mem_inv_o(mem_inv), .mem_reinit_o(mem_reinit),
    .mem_ecc_clr_o(mem_ecc_clr), .mbist_req_o(mbist_req), .mbist_allow_o(mbist_allow),
    .done_o(done), .done_code_o(done_code), .done_src_o(done_src), .status_o(status), .err_o(err),
    .supply_err_o(supply_err), .irq_o(irq)
  );

  // ---------------------------------------------------------------- region models
  logic [NR-1:0] submit = '0, dma_inj = '0, f_no_pg = '0, f_pg_stuck = '0, f_glitch = '0, f_cack = '0;
  logic [NR-1:0] f_mbf = '0, f_rhang = '0, f_busy = '0, f_stale = '0, f_noab = '0, flush = '0;
  logic [7:0]    job_len [NR];
  logic [15:0]   dma_lat [NR];
  wire  [NR-1:0] rail, out_valid, mem_ok, inv_seen;
  wire  [NR-1:0][7:0] out_data;
  wire  [NR-1:0][31:0] ret_reg, plain_reg;
  int   jobs_done [NR], jobs_ab [NR], gedges [NR], ecc_clr_cnt [NR], reinit_cnt [NR];
  initial for (int r = 0; r < NR; r++) begin job_len[r] = 8'd8; dma_lat[r] = 16'd20; end

  wire [NR-1:0] m_run;
  for (genvar r = 0; r < NR; r++) begin : g_m
    wire gclk;
    assign m_run[r] = (u_m.running === 1'b1);
    sf_pd_region_model #(.ID(r), .SWITCHABLE(P_SW[r]), .HAS_SRAM(P_SRAM[r]), .SRAM_RET(P_SRET[r]),
                         .LOGIC_RET(P_LRET[r])) u_m (
      .clk_i(clk), .rst_ni(rst_n),
      .clk_en_i(clk_en[r]), .quiesce_i(quiesce[r]), .abort_i(abort_r[r]), .iso_i(iso[r]), .iso_pm_i(iso_pm[r]),
      .rst_req_i(rst_r[r]), .pwr_en_i(pwr_en[r]), .ret_save_i(ret_save[r]), .ret_hold_i(ret_hold[r]),
      .ret_restore_i(ret_restore[r]), .mem_ret_i(mem_ret[r]), .mem_inv_i(mem_inv[r]), .mem_reinit_i(mem_reinit[r]),
      .mem_ecc_clr_i(mem_ecc_clr[r]), .mbist_req_i(mbist_req[r]),
      .busy_o(busy[r]), .q_ack_o(q_ack[r]), .abort_ack_o(abort_ack[r]), .clk_ack_o(clk_ack[r]), .pgood_o(pgood[r]),
      .mem_ret_ack_o(mret_ack[r]), .mem_reinit_done_o(minit_done[r]), .mbist_done_o(mbd[r]), .mbist_fail_o(mbf[r]),
      .dma_wr_pend_o(dma_pend[r]), .acc_op_pend_o(acc_pend[r]),
      .out_valid_o(out_valid[r]), .out_data_o(out_data[r]),
      .submit_job_i(submit[r]), .flush_i(flush[r]), .job_len_i(job_len[r]), .dma_inject_i(dma_inj[r]), .dma_lat_i(dma_lat[r]),
      .f_no_pgood_i(f_no_pg[r]), .f_pgood_stuck_i(f_pg_stuck[r]), .f_glitch_i(f_glitch[r]),
      .f_clkack_stuck_i(f_cack[r]), .f_mbist_fail_i(f_mbf[r]), .f_reinit_hang_i(f_rhang[r]),
      .f_busy_stuck_i(f_busy[r]), .f_stale_ack_i(f_stale[r]), .f_no_abort_ack_i(f_noab[r]),
      .rail_o(rail[r]), .gclk_o(gclk), .ret_reg_o(ret_reg[r]), .plain_reg_o(plain_reg[r]),
      .mem_all_valid_o(mem_ok[r]), .jobs_done_o(jobs_done[r]), .jobs_aborted_o(jobs_ab[r]),
      .gclk_edges_o(gedges[r]), .inv_seen_o(inv_seen[r]), .ecc_clr_cnt_o(ecc_clr_cnt[r]),
      .reinit_cnt_o(reinit_cnt[r]));
  end

  // ---------------------------------------------------------------- bookkeeping
  int n_chk = 0, n_err = 0;
  string cur_test = "";
  task automatic check(input bit cond, input string msg);
    n_chk++;
    if (!cond) begin
      n_err++;
      $display("FAIL [%0t] %s: %s", $time, cur_test, msg);
    end
  endtask

  // completion counters: done_cnt / last_code count REQUEST completions only
  // (source 1); th_cnt / th_code count thermal-policy completions (source 2).
  int  done_cnt [NR], th_cnt [NR];
  logic [3:0] last_code [NR], th_code [NR];
  initial for (int r = 0; r < NR; r++) begin done_cnt[r] = 0; last_code[r] = 4'hF; th_cnt[r] = 0; th_code[r] = 4'hF; end
  always @(posedge clk) begin
    for (int r = 0; r < NR; r++) if (rst_n && done[r] === 1'b1) begin
      if (done_src[r] == 2'd1) begin done_cnt[r] <= done_cnt[r] + 1; last_code[r] <= done_code[r]; end
      if (done_src[r] == 2'd2) begin th_cnt[r]   <= th_cnt[r] + 1;   th_code[r]   <= done_code[r]; end
    end
  end

  function automatic pd_state_e st_of(input int r);
    pd_status_t s;
    s = status[r];
    return s.state;
  endfunction
  function automatic logic lost_of(input int r);
    pd_status_t x; x = status[r]; return x.mem_lost;
  endfunction
  function automatic logic trans_of(input int r);
    pd_status_t x; x = status[r]; return x.transition;
  endfunction
  function automatic logic thold_of(input int r);
    pd_status_t x; x = status[r]; return x.therm_hold;
  endfunction
  function automatic pd_arch_e archst(input int r);
    pd_status_t x; x = status[r]; return x.arch;
  endfunction
  function automatic string sname(input int r);
    pd_state_e x; x = st_of(r); return x.name();
  endfunction

  // xorshift32 PRNG (identical in every simulator)
  int unsigned rng = 32'h1234_5678;
  function automatic int unsigned rnd();
    rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
    return rng;
  endfunction
  function automatic int unsigned rndr(input int unsigned lo, input int unsigned hi);
    return lo + (rnd() % (hi - lo + 1));
  endfunction

  // ---------------------------------------------------------------- invariant checker
  bit chk_en = 1'b0;
  logic [NR-1:0] p_iso, p_isopm, p_rst, p_pwr, p_clk, p_q, p_abort_seen, brown;
  initial begin p_abort_seen = '0; brown = '0; end
  // brown-out window: from an injected glitch until the controller has isolated PM status
  always @(posedge clk) for (int r = 0; r < NR; r++) begin
    if (f_glitch[r]) brown[r] <= 1'b1;
    else if (iso_pm[r] === 1'b1 && iso[r] === 1'b1) brown[r] <= 1'b0;
  end
  always @(negedge clk) begin
    if (chk_en) begin
      int npu;
      // X / Z on any controller output
      if ((^{clk_en, quiesce, abort_r, iso, iso_pm, rst_r, pwr_en, ret_save, ret_hold, ret_restore,
             mem_ret, mem_inv, mem_reinit, mem_ecc_clr, mbist_req, mbist_allow, done, irq, rsp_valid}) === 1'bx)
        check(0, "X/Z on a controller output");
      if ((^status) === 1'bx || (^err) === 1'bx) check(0, "X/Z in status / error registers");
      npu = 0;
      for (int r = 0; r < NR; r++) begin
        pd_state_e s;
        s = st_of(r);
        if (s == S_POWER_UP) npu++;
        // controller inputs from the region must never be X (isolation clamps them)
        if (!brown[r] && (^{busy[r], q_ack[r], abort_ack[r], minit_done[r], mbd[r], mbf[r]}) === 1'bx)
          check(0, $sformatf("r%0d: X reached the controller through PM status", r));
        // always-on side of the data boundary
        if (!brown[r] && (^{out_valid[r], out_data[r]}) === 1'bx)
          check(0, $sformatf("r%0d: X reached the always-on side of the data boundary", r));
        if (iso[r] && out_valid[r] !== 1'b0) check(0, $sformatf("r%0d: isolated output not clamped", r));
        // always-on regions
        if ((r == CTRL || r == AON) && (clk_en[r] !== 1'b1 || quiesce[r] !== 1'b0))
          check(0, $sformatf("r%0d: always-on region gated or quiesced", r));
        if (P_SW[r]) begin
          if (!rail[r] && !brown[r] && !(iso[r] && iso_pm[r] && rst_r[r]))
            check(0, $sformatf("r%0d: unpowered region not isolated + reset", r));
          if (!pwr_en[r] && !(iso[r] && iso_pm[r] && rst_r[r]))
            check(0, $sformatf("r%0d: switch open without iso/iso_pm/reset", r));
          if (p_pwr[r] && !pwr_en[r] && s != S_FAULT) begin       // normal power-down
            if (!(p_iso[r] && p_isopm[r] && p_rst[r] && !p_clk[r] && p_q[r]))
              check(0, $sformatf("r%0d: switch opened before iso/iso_pm/reset/clock-stop", r));
            if (!p_abort_seen[r] && (m_run[r] || dma_pend[r] || acc_pend[r]))
              check(0, $sformatf("r%0d: power removed with work outstanding and no abort", r));
          end
          if (p_iso[r] && !iso[r] && !(rail[r] && pgood[r] && !rst_r[r] && clk_ack[r] && !lost_of(r)))
            check(0, $sformatf("r%0d: de-isolated before power/reset/clock/memory ready", r));
          if (p_isopm[r] && !iso_pm[r] && !(rail[r] && !rst_r[r]))
            check(0, $sformatf("r%0d: PM status de-isolated before power + reset release", r));
          if (ret_save[r] && !(clk_ack[r] == 1'b0 && iso[r])) check(0, $sformatf("r%0d: retention save with clock running", r));
          if (ret_restore[r] && !(rail[r] && clk_ack[r] == 1'b0)) check(0, $sformatf("r%0d: restore without power or with clock", r));
          if (mem_reinit[r] && !(iso[r] && !rst_r[r] && rail[r])) check(0, $sformatf("r%0d: SRAM reinit outside isolated, powered, released region", r));
          if (mbist_req[r] && !iso[r]) check(0, $sformatf("r%0d: MBIST not under isolation", r));
        end else begin
          if (iso[r] || iso_pm[r] || rst_r[r] || !pwr_en[r])
            check(0, $sformatf("r%0d: non-switchable region drives iso/reset/switch", r));
        end
        if (p_clk[r] && !clk_en[r]) begin
          if (!quiesce[r]) check(0, $sformatf("r%0d: clock stopped without quiesce", r));
          if (s != S_FAULT && !p_abort_seen[r] && s != S_RESTORE &&
              (m_run[r] || dma_pend[r] || acc_pend[r]))
            check(0, $sformatf("r%0d: clock stopped with work outstanding", r));
        end
        if (p_q[r] && !quiesce[r] && !clk_en[r]) check(0, $sformatf("r%0d: quiesce released with clock stopped", r));
        if (mbist_allow[r] && s != S_ACTIVE) check(0, $sformatf("r%0d: MBIST allowed outside ACTIVE", r));
      end
      if (npu > 1) check(0, "more than one region ramping its supply (inrush)");
      // dependency invariant: a user is ACTIVE only while each provider it uses is ACTIVE
      // (a provider in FAULT is excluded: that is an external event such as a brown-out)
      for (int u = 0; u < NR; u++) for (int t = 0; t < NR; t++)
        if (P_DEP[u*NR + t] && st_of(u) == S_ACTIVE && !(st_of(t) == S_ACTIVE || st_of(t) == S_FAULT))
          check(0, $sformatf("r%0d ACTIVE while the region it uses (r%0d) is %s", u, t, sname(t)));
      n_chk++;
    end
    for (int r = 0; r < NR; r++) begin
      if (abort_r[r] === 1'b1) p_abort_seen[r] <= 1'b1;
      else if (st_of(r) == S_ACTIVE || st_of(r) == S_OFF && !dma_pend[r] && !acc_pend[r]) p_abort_seen[r] <= 1'b0;
    end
    p_iso <= iso; p_isopm <= iso_pm; p_rst <= rst_r; p_pwr <= pwr_en; p_clk <= clk_en; p_q <= quiesce;
  end

  // error-rise trace (always on: shows when and in which state each sticky error appeared)
  logic [NR-1:0][NUM_ERR-1:0] p_err;
  always @(negedge clk) begin
    if (rst_n) for (int r = 0; r < NR; r++)
      if ((err[r] & ~p_err[r]) != '0)
        $display("  [%0t] r%0d error bits %b set in state %s (pgood %b dma %b acc %b)", $time, r,
                 err[r] & ~p_err[r], sname(r), pgood[r], dma_pend[r], acc_pend[r]);
    p_err <= err;
  end

  // ---------------------------------------------------------------- driver tasks
  // bounded wait: a condition that never comes true is a FAIL, never a hang
  int guard;
  task automatic guard_tick(input string what);
    guard++;
    if (guard > 200000) begin check(0, {"timeout waiting for ", what}); guard = 0; end
    @(negedge clk);
  endtask
  task automatic tick(input int n = 1);
    repeat (n) @(negedge clk);
  endtask

  // issue one request; returns the registered response
  task automatic req(input int r, input pd_target_e t, input bit retain, input bit loss, input bit abt,
                     output pd_evt_e code, output bit fin);
    @(negedge clk);
    cmd_valid = 1'b1; cmd_region = 3'(r); cmd_target = t;
    cmd_retain = retain; cmd_allow_loss = loss; cmd_abort_ok = abt;
    @(negedge clk);
    cmd_valid = 1'b0; cmd_retain = 1'b0; cmd_allow_loss = 1'b0; cmd_abort_ok = 1'b0;
    code = rsp_code; fin = rsp_final;
    if (rsp_valid !== 1'b1 || rsp_region !== 3'(r)) check(0, "response channel did not answer");
  endtask

  task automatic wait_done(input int r, input int base, input int maxc, output logic [3:0] code);
    int n;
    n = 0;
    while (done_cnt[r] == base && n < maxc) begin @(negedge clk); n++; end
    if (done_cnt[r] == base) begin code = 4'hF; check(0, $sformatf("r%0d: no completion within %0d cycles", r, maxc)); end
    else code = last_code[r];
  endtask
  task automatic wait_th(input int r, input int base, input int maxc, output logic [3:0] code);
    int n;
    n = 0;
    while (th_cnt[r] == base && n < maxc) begin @(negedge clk); n++; end
    if (th_cnt[r] == base) begin code = 4'hF; check(0, $sformatf("r%0d: no thermal completion within %0d cycles", r, maxc)); end
    else code = th_code[r];
  endtask

  // request + expect immediate response code; if accepted, wait for completion code
  task automatic go(input int r, input pd_target_e t, input pd_evt_e exp_rsp, input logic [3:0] exp_done,
                    input bit retain = 0, input bit loss = 0, input bit abt = 0, input int maxc = 3000);
    pd_evt_e c; bit fin; logic [3:0] dc; int base;
    base = done_cnt[r];
    req(r, t, retain, loss, abt, c, fin);
    check(c == exp_rsp, $sformatf("r%0d -> %s: response %s, expected %s", r, t.name(), c.name(), exp_rsp.name()));
    if (!fin) begin
      wait_done(r, base, maxc, dc);
      check(dc == exp_done, $sformatf("r%0d -> %s: completion %0d, expected %0d", r, t.name(), dc, exp_done));
    end else if (exp_done != 4'hE) begin
      check(0, $sformatf("r%0d -> %s: expected a completion event, got a final response", r, t.name()));
    end
  endtask
  localparam logic [3:0] NONE = 4'hE;   // "no completion expected"

  task automatic clear_faults();
    flush = '0;
    submit = '0; dma_inj = '0; f_no_pg = '0; f_pg_stuck = '0; f_glitch = '0; f_cack = '0;
    f_mbf = '0; f_rhang = '0; f_busy = '0; f_stale = '0; f_noab = '0; therm = 1'b0;
  endtask

  task automatic clr_err(input int r);
    @(negedge clk); err_clr[r] = 1'b1; @(negedge clk); err_clr[r] = 1'b0;
  endtask

  task automatic expect_err(input int r, input int bitn, input string what);
    logic [NR*NUM_ERR-1:0] flat;
    flat = err;
    check(flat[r*NUM_ERR + bitn] === 1'b1, $sformatf("r%0d: expected error %s", r, what));
  endtask

  task automatic expect_no_err(input string where);
    for (int r = 0; r < NR; r++)
      if (err[r] !== '0) check(0, $sformatf("%s: r%0d unexpected error bits %b", where, r, err[r]));
    check(supply_err === 1'b0, {where, ": supply error"});
  endtask

  task automatic wait_state(input int r, input pd_state_e s, input int maxc);
    int n; n = 0;
    while (st_of(r) != s && n < maxc) begin @(negedge clk); n++; end
    check(st_of(r) == s, $sformatf("r%0d: state %s not reached (is %s)", r, s.name(), sname(r)));
  endtask

  task automatic all_settled(input int maxc);
    int n; bit busyq;
    n = 0;
    do begin
      busyq = 0;
      for (int r = 0; r < NR; r++) if (trans_of(r)) busyq = 1;
      if (busyq) @(negedge clk);
      n++;
    end while (busyq && n < maxc);
    check(!busyq, "regions did not settle");
  endtask

  task automatic do_reset();
    chk_en = 1'b0;
    clear_faults();
    @(negedge clk); rst_n = 1'b0;
    tick(5);
    rst_n = 1'b1;
    tick(3);
    chk_en = 1'b1;
    // switchable regions boot (power-down confirm -> off -> power-up -> active)
    for (int r = 0; r < NR; r++) wait_state(r, S_ACTIVE, 3000);
    all_settled(100);
    check(irq === 1'b0, "IRQ after reset");
  endtask

  task automatic run_jobs(input int r, input int n, input int len);
    for (int i = 0; i < n; i++) begin
      @(negedge clk); job_len[r] = 8'(len); submit[r] = 1'b1;
      @(negedge clk); submit[r] = 1'b0;
    end
  endtask
  task automatic dma(input int r, input int lat);
    @(negedge clk); dma_lat[r] = 16'(lat); dma_inj[r] = 1'b1;
    @(negedge clk); dma_inj[r] = 1'b0;
  endtask

  // ============================================================================
  // TESTS
  // ============================================================================
  // T0 reset defaults + unsupported / illegal requests
  task automatic t_reset_defaults();
    pd_evt_e c; bit fin;
    cur_test = "reset_defaults";
    do_reset();
    for (int r = 0; r < NR; r++) begin
      check(st_of(r) == S_ACTIVE, $sformatf("r%0d not ACTIVE after reset", r));
      check(clk_en[r] && !quiesce[r] && !iso[r] && !iso_pm[r] && !rst_r[r] && pwr_en[r],
            $sformatf("r%0d controls not in the ACTIVE pattern after reset", r));
    end
    for (int r = 0; r < NR; r++) if (!P_SW[r]) go(r, T_OFF, E_REJ_UNSUPPORTED, NONE);
    go(CTRL, T_IDLE, E_REJ_UNSUPPORTED, NONE);
    go(AON,  T_IDLE, E_REJ_UNSUPPORTED, NONE);
    go(CTRL, T_ACTIVE, E_OK, NONE);
    go(VEC,  T_ACTIVE, E_OK, NONE);                // already there: final OK
    go(VEC,  T_RSVD, E_REJ_BAD_REQ, NONE);
    req(7, T_IDLE, 0, 0, 0, c, fin);
    check(c == E_REJ_BAD_REQ && fin, "out-of-range region not refused");
    if (!P_SW[TNS]) go(TNS, T_OFF, E_REJ_UNSUPPORTED, NONE, 1);
    expect_no_err("reset_defaults");
  endtask

  // T1/T2 active -> idle -> active, state kept, clock really stopped
  task automatic t_active_idle_active();
    int e0, jd; logic [31:0] rr;
    cur_test = "active_idle_active";
    do_reset();
    jd = jobs_done[VEC];
    run_jobs(VEC, 3, 10);
    tick(4);
    go(VEC, T_IDLE, E_OK, E_OK);
    check(jobs_done[VEC] == jd + 3, "work lost or not drained before clock stop");
    check(st_of(VEC) == S_IDLE && archst(VEC) == A_IDLE, "VEC not IDLE");
    check(clk_ack[VEC] == 1'b0 && quiesce[VEC] == 1'b1, "VEC clock not gated / not quiesced");
    e0 = gedges[VEC]; rr = ret_reg[VEC];
    tick(50);
    check(gedges[VEC] == e0, "gated clock still toggling in IDLE");
    check(ret_reg[VEC] == rr, "state changed while IDLE");
    go(VEC, T_IDLE, E_OK, NONE);                   // no-op
    go(VEC, T_ACTIVE, E_OK, E_OK);
    check(gedges[VEC] > e0, "clock did not restart");
    check(ret_reg[VEC] == rr, "state not preserved across IDLE");
    jd = jobs_done[VEC];
    run_jobs(VEC, 2, 5);
    tick(40);
    check(jobs_done[VEC] == jd + 2, "work does not resume after wake");
    // every clock-gated region can idle and wake
    for (int r = 1; r <= 5; r++) if (r != FAB && r != SRAM) go(r, T_IDLE, E_OK, E_OK);
    go(SRAM, T_IDLE, E_OK, E_OK);
    go(FAB, T_IDLE, E_OK, E_OK);
    go(FAB, T_ACTIVE, E_OK, E_OK);
    go(SRAM, T_ACTIVE, E_OK, E_OK);
    for (int r = 1; r <= 5; r++) if (r != FAB && r != SRAM) go(r, T_ACTIVE, E_OK, E_OK);
    expect_no_err("active_idle_active");
  endtask

  // T3 quiesce: drain of running work + in-flight DMA writes; stale ack detection
  task automatic t_quiesce();
    int t0, base; logic [3:0] dc; pd_evt_e c; bit fin;
    cur_test = "quiesce";
    do_reset();
    run_jobs(VEC, 2, 30);
    dma(VEC, 120);
    t0 = cyc;
    base = done_cnt[VEC];
    req(VEC, T_IDLE, 0, 0, 0, c, fin);
    check(c == E_OK && !fin, "IDLE not accepted");
    tick(5);
    check(st_of(VEC) == S_QUIESCE && quiesce[VEC], "not in QUIESCE while work outstanding");
    check(clk_en[VEC] == 1'b1, "clock stopped during drain");
    // a second request while sequencing is refused
    go(VEC, T_ACTIVE, E_REJ_IN_TRANS, NONE);
    wait_done(VEC, base, 1000, dc);
    check(dc == E_OK, "drained IDLE did not complete OK");
    check(cyc - t0 >= 118, "clock stopped before the DMA write retired");
    check(!dma_pend[VEC], "DMA write still pending at IDLE");
    go(VEC, T_ACTIVE, E_OK, E_OK);
    expect_no_err("quiesce/drain");
    // stale / unsolicited quiesce ack is a protocol error
    @(negedge clk); f_stale[VEC] = 1'b1; @(negedge clk); @(negedge clk); f_stale[VEC] = 1'b0;
    tick(2);
    expect_err(VEC, ERR_PROTOCOL, "PROTOCOL (stale ack)");
    clr_err(VEC);
    // activity in a gated region is a protocol error
    go(EXT, T_IDLE, E_OK, E_OK);
    @(negedge clk); submit[EXT] = 1'b1; @(negedge clk); submit[EXT] = 1'b0;
    tick(3);
    expect_err(EXT, ERR_PROTOCOL, "PROTOCOL (work submitted to an IDLE region)");
    go(EXT, T_ACTIVE, E_OK, E_OK);                 // the queued job then runs
    tick(30);
    clr_err(EXT);
    expect_no_err("quiesce/end");
  endtask

  // T4 busy-domain shutdown rejection (and OFF rejection without abort)
  task automatic t_busy_reject();
    int jd;
    cur_test = "busy_reject";
    do_reset();
    dma(VEC, 1000);                                // longer than the quiesce timeout
    run_jobs(VEC, 1, 20);
    go(VEC, T_IDLE, E_OK, E_REJ_BUSY);
    check(st_of(VEC) == S_ACTIVE && clk_en[VEC] && !quiesce[VEC], "VEC not back to ACTIVE after refused drain");
    expect_err(VEC, ERR_QUIESCE_TO, "QUIESCE_TO");
    check(dma_pend[VEC], "DMA write was dropped");
    jd = jobs_done[VEC];
    run_jobs(VEC, 1, 5); tick(30);
    check(jobs_done[VEC] == jd + 1, "region not operational after refused shutdown");
    clr_err(VEC);
    if (P_SW[VEC]) begin
      int pf;
      pf = 0;
      go(VEC, T_OFF, E_OK, E_REJ_BUSY);            // no abort policy requested
      check(pwr_en[VEC] && rail[VEC], "power removed with a DMA write outstanding");
      clr_err(VEC);
      // OFF of a region holding SRAM that must be retained, without retention / loss acceptance
      go(VEC, T_IDLE, E_OK, E_REJ_BUSY);           // DMA still pending
      clr_err(VEC);
    end
    guard = 0; while (dma_pend[VEC] && guard < 200000) guard_tick("DMA drain");
    expect_no_err("busy_reject");
  endtask

  // T5 dependency ordering
  task automatic t_dependency();
    cur_test = "dependency";
    do_reset();
    go(FAB,  T_IDLE, E_REJ_DEPENDENCY, NONE);
    go(SRAM, T_IDLE, E_REJ_DEPENDENCY, NONE);
    go(VEC, T_IDLE, E_OK, E_OK);
    go(TNS, T_IDLE, E_OK, E_OK);
    go(FAB, T_IDLE, E_REJ_DEPENDENCY, NONE);       // EXTIF still uses the fabric
    go(EXT, T_IDLE, E_OK, E_OK);
    go(SRAM, T_IDLE, E_OK, E_OK);
    go(FAB, T_IDLE, E_OK, E_OK);
    go(VEC, T_ACTIVE, E_REJ_DEPENDENCY, NONE);
    go(FAB, T_ACTIVE, E_OK, E_OK);
    go(VEC, T_ACTIVE, E_REJ_DEPENDENCY, NONE);     // SRAM still idle
    go(SRAM, T_ACTIVE, E_OK, E_OK);
    go(VEC, T_ACTIVE, E_OK, E_OK);
    go(TNS, T_ACTIVE, E_OK, E_OK);
    go(EXT, T_ACTIVE, E_OK, E_OK);
    expect_no_err("dependency");
  endtask

  // T6 thermal throttling request
  task automatic t_thermal();
    int b1, b2, dcnt; logic [3:0] dc;
    cur_test = "thermal";
    do_reset();
    run_jobs(VEC, 2, 20); run_jobs(TNS, 2, 20);
    b1 = th_cnt[VEC]; b2 = th_cnt[TNS];
    @(negedge clk); therm = 1'b1;
    wait_th(VEC, b1, 2000, dc); check(dc == E_OK_THERMAL, "VEC thermal idle code");
    wait_th(TNS, b2, 2000, dc); check(dc == E_OK_THERMAL, "TNS thermal idle code");
    check(st_of(VEC) == S_IDLE && st_of(TNS) == S_IDLE, "throttle-eligible regions not idled");
    check(thold_of(VEC), "therm_hold status not set");
    check(st_of(EXT) == S_ACTIVE && st_of(SRAM) == S_ACTIVE, "non-eligible region affected");
    go(VEC, T_ACTIVE, E_REJ_THERMAL, NONE);
    go(EXT, T_IDLE, E_OK, E_OK);                   // other requests still served
    go(EXT, T_ACTIVE, E_OK, E_OK);
    b1 = th_cnt[VEC]; b2 = th_cnt[TNS];
    @(negedge clk); therm = 1'b0;
    wait_th(VEC, b1, 2000, dc); check(dc == E_OK_THERMAL, "VEC auto-restore code");
    wait_th(TNS, b2, 2000, dc); check(dc == E_OK_THERMAL, "TNS auto-restore code");
    check(st_of(VEC) == S_ACTIVE && st_of(TNS) == S_ACTIVE, "not restored after throttle release");
    expect_no_err("thermal");
    // a region that cannot drain is NOT forced off: refused, no retry storm
    @(negedge clk); f_busy[VEC] = 1'b1;
    b1 = th_cnt[VEC]; b2 = th_cnt[TNS];
    @(negedge clk); therm = 1'b1;
    wait_th(VEC, b1, 2000, dc); check(dc == E_REJ_BUSY, "stuck region: thermal quiesce must be refused");
    wait_th(TNS, b2, 2000, dc); check(dc == E_OK_THERMAL, "TNS still idles");
    dcnt = th_cnt[VEC];
    tick(3 * 200);
    check(th_cnt[VEC] == dcnt, "thermal policy retried while the hold persisted");
    check(st_of(VEC) == S_ACTIVE, "stuck region not left ACTIVE");
    @(negedge clk); f_busy[VEC] = 1'b0; therm = 1'b0;
    b2 = th_cnt[TNS];
    wait_th(TNS, b2, 2000, dc); check(dc == E_OK_THERMAL, "TNS restore");
    clr_err(VEC);
    expect_no_err("thermal/end");
    // collision: thermal auto-restore of VEC/TNS and a request idling their provider FABRIC in the SAME cycle
    b1 = th_cnt[VEC];
    @(negedge clk); therm = 1'b1;
    wait_th(VEC, b1, 2000, dc);
    guard = 0; while (st_of(TNS) != S_IDLE && guard < 200000) guard_tick("TNS thermal idle");
    go(EXT, T_IDLE, E_OK, E_OK);                   // FABRIC's last other user
    @(negedge clk);
    therm = 1'b0;                                  // releases the hold ...
    cmd_valid = 1'b1; cmd_region = 3'(FAB); cmd_target = T_IDLE;   // ... in the same cycle as this request
    @(negedge clk); cmd_valid = 1'b0;
    check(rsp_code == E_OK, "FABRIC idle request refused");
    tick(400);
    check(st_of(FAB) == S_IDLE, "FABRIC did not idle");
    check(st_of(VEC) == S_IDLE && st_of(TNS) == S_IDLE, "user woke while its provider was idling (race)");
    go(FAB, T_ACTIVE, E_OK, E_OK);                 // provider back: the pending restores proceed
    tick(200);
    check(st_of(VEC) == S_ACTIVE && st_of(TNS) == S_ACTIVE, "thermal restore not completed after the provider returned");
    go(EXT, T_ACTIVE, E_OK, E_OK);
    expect_no_err("thermal/collision");
  endtask

  // T7 reset during a transition
  task automatic t_reset_mid();
    pd_evt_e c; bit fin;
    cur_test = "reset_mid_transition";
    do_reset();
    dma(VEC, 150);
    req(VEC, T_IDLE, 0, 0, 0, c, fin);
    tick(20);
    check(st_of(VEC) == S_QUIESCE, "not mid-QUIESCE");
    #2 rst_n = 1'b0;                               // asynchronous, between clock edges
    if (P_SW[VEC])
      #1 check(st_of(VEC) == S_POWER_DOWN && !pwr_en[VEC] && iso[VEC] && iso_pm[VEC] && rst_r[VEC] && quiesce[VEC],
               "async reset did not force the switchable region safe (iso, reset, switch open)");
    else
      #1 check(st_of(VEC) == S_ACTIVE && quiesce[VEC] == 1'b0, "async reset did not restore the safe pattern");
    chk_en = 1'b0;
    tick(3); rst_n = 1'b1; tick(3); chk_en = 1'b1;
    for (int r = 0; r < NR; r++) wait_state(r, S_ACTIVE, 3000);
    guard = 0; while (dma_pend[VEC] && guard < 200000) guard_tick("DMA drain");
    if (P_SW[VEC]) begin
      // reset while the switch is open / while ramping / during SRAM re-init
      go(VEC, T_OFF, E_OK, E_OK);
      go(VEC, T_ACTIVE, E_OK, E_OK);
      req(VEC, T_OFF, 0, 0, 0, c, fin);
      wait_state(VEC, S_POWER_DOWN, 500);
      tick(cfg.iso_settle + 3);
      #2 rst_n = 1'b0;
      #1 check(!pwr_en[VEC] && iso[VEC] && iso_pm[VEC] && rst_r[VEC], "reset in POWER_DOWN: unsafe outputs");
      chk_en = 1'b0; tick(3); rst_n = 1'b1; tick(2); chk_en = 1'b1;
      for (int r = 0; r < NR; r++) wait_state(r, S_ACTIVE, 3000);
      req(VEC, T_OFF, 0, 0, 0, c, fin); wait_state(VEC, S_OFF, 2000);
      req(VEC, T_ACTIVE, 0, 0, 0, c, fin); wait_state(VEC, S_POWER_UP, 500);
      tick(3);
      #2 rst_n = 1'b0;
      #1 check(!pwr_en[VEC] && iso[VEC] && iso_pm[VEC] && rst_r[VEC], "reset in POWER_UP: switch not opened");
      chk_en = 1'b0; tick(3); rst_n = 1'b1; tick(2); chk_en = 1'b1;
      for (int r = 0; r < NR; r++) wait_state(r, S_ACTIVE, 3000);
      req(VEC, T_OFF, 0, 0, 0, c, fin); wait_state(VEC, S_OFF, 2000);
      req(VEC, T_ACTIVE, 0, 0, 0, c, fin);
      guard = 0; while (!(st_of(VEC) == S_RESTORE && mem_reinit[VEC]) && guard < 200000) guard_tick("RESTORE re-init");
      tick(5);
      #2 rst_n = 1'b0;
      #1 check(!pwr_en[VEC] && iso[VEC] && iso_pm[VEC] && rst_r[VEC] && !mem_reinit[VEC], "reset in RESTORE: unsafe outputs");
      chk_en = 1'b0; tick(3); rst_n = 1'b1; tick(2); chk_en = 1'b1;
      for (int r = 0; r < NR; r++) wait_state(r, S_ACTIVE, 3000);
      check(mem_ok[VEC], "SRAM not re-initialised after the interrupted power-up");
      check(!lost_of(VEC), "mem_lost still set");
    end
    all_settled(100);
    expect_no_err("reset_mid_transition");
  endtask

  // T8 control timeout: clock gate ack, resume ack
  task automatic t_timeouts();
    cur_test = "control_timeout";
    do_reset();
    @(negedge clk); f_cack[EXT] = 1'b1;
    go(EXT, T_IDLE, E_OK, E_ERR_TIMEOUT);
    check(st_of(EXT) == S_FAULT && archst(EXT) == A_FAULT, "EXT not in FAULT after clock-ack timeout");
    check(quiesce[EXT] && !clk_en[EXT], "FAULT pattern (quiesced, clock off) not held");
    expect_err(EXT, ERR_CLKACK_TO, "CLKACK_TO");
    check(irq === 1'b1, "no IRQ on error");
    go(EXT, T_ACTIVE, E_REJ_FAULT, NONE);
    @(negedge clk); f_cack[EXT] = 1'b0;
    clr_err(EXT);
    go(EXT, T_ACTIVE, E_OK, E_OK);
    // resume never acknowledged (quiesce ack stuck high)
    go(EXT, T_IDLE, E_OK, E_OK);
    @(negedge clk); f_stale[EXT] = 1'b1;
    go(EXT, T_ACTIVE, E_OK, E_ERR_TIMEOUT);
    expect_err(EXT, ERR_QUIESCE_TO, "QUIESCE_TO (resume)");
    @(negedge clk); f_stale[EXT] = 1'b0;
    clr_err(EXT);
    go(EXT, T_ACTIVE, E_OK, E_OK);
    tick(5);
    check(irq === 1'b0, "IRQ not cleared");
    // supply power-good monitor
    @(negedge clk); supply_pg = 1'b0; tick(4); supply_pg = 1'b1; tick(2);
    check(supply_err === 1'b1 && irq === 1'b1, "supply power-good loss not reported");
    @(negedge clk); supply_err_clr = 1'b1; @(negedge clk); supply_err_clr = 1'b0;
    expect_no_err("control_timeout");
  endtask

  // ------------------------------------------------------------------ FUTURE-only tests
  // T9 full OFF/ON sequence with ordering trace
  task automatic t_off_on_sequence();
    int tq, tcs, tiso, tinv, tpm, trst, tpw, tpg, tpw1, tpg1, tc1, tr1, tpm1, tmb, tri_, tec, tiso1, tq1;
    int base; logic [3:0] dc; pd_evt_e c; bit fin;
    cur_test = "isolation_sequencing";
    do_reset();
    tq = -1; tcs = -1; tiso = -1; tinv = -1; tpm = -1; trst = -1; tpw = -1; tpg = -1;
    tpw1 = -1; tpg1 = -1; tc1 = -1; tr1 = -1; tpm1 = -1; tmb = -1; tri_ = -1; tec = -1; tiso1 = -1; tq1 = -1;
    run_jobs(VEC, 2, 12);
    base = done_cnt[VEC];
    req(VEC, T_OFF, 0, 0, 0, c, fin);
    check(c == E_OK && !fin, "OFF not accepted");
    guard = 0;
    while (done_cnt[VEC] == base && guard < 200000) begin
      guard_tick("OFF completion");
      if (tq   < 0 && quiesce[VEC])  tq   = cyc;
      if (tcs  < 0 && !clk_en[VEC])  tcs  = cyc;
      if (tiso < 0 && iso[VEC])      tiso = cyc;
      if (tinv < 0 && mem_inv[VEC])  tinv = cyc;
      if (tpm  < 0 && iso_pm[VEC])   tpm  = cyc;
      if (trst < 0 && rst_r[VEC])    trst = cyc;
      if (tpw  < 0 && !pwr_en[VEC])  tpw  = cyc;
      if (tpg  < 0 && !pgood[VEC])   tpg  = cyc;
    end
    check(last_code[VEC] == E_OK && st_of(VEC) == S_OFF && archst(VEC) == A_POWER_OFF, "OFF not reached");
    check(tq < tcs && tcs < tiso && tiso <= tinv && tinv < tpm && tpm == trst && trst < tpw && tpw < tpg,
          $sformatf("power-down order q%0d clk%0d iso%0d inv%0d pm%0d rst%0d pwr%0d pg%0d", tq, tcs, tiso, tinv, tpm, trst, tpw, tpg));
    check(inv_seen[VEC], "SRAM invalidation not signalled");
    check(lost_of(VEC), "mem_lost not reported while OFF");
    check(!rail[VEC] && out_valid[VEC] === 1'b0, "OFF region not clamped");
    base = done_cnt[VEC];
    req(VEC, T_ACTIVE, 0, 0, 0, c, fin);
    guard = 0;
    while (done_cnt[VEC] == base && guard < 200000) begin
      guard_tick("ON completion");
      if (tpw1 < 0 && pwr_en[VEC])    tpw1 = cyc;
      if (tpg1 < 0 && pgood[VEC])     tpg1 = cyc;
      if (tc1  < 0 && tpg1 >= 0 && clk_en[VEC]) tc1 = cyc;
      if (tr1  < 0 && tc1 >= 0 && !rst_r[VEC])  tr1 = cyc;
      if (tpm1 < 0 && !iso_pm[VEC])   tpm1 = cyc;
      if (tmb  < 0 && mbist_req[VEC]) tmb  = cyc;
      if (tri_ < 0 && mem_reinit[VEC]) tri_ = cyc;
      if (tec  < 0 && mem_ecc_clr[VEC]) tec = cyc;
      if (tiso1 < 0 && !iso[VEC])     tiso1 = cyc;
      if (tq1  < 0 && !quiesce[VEC])  tq1  = cyc;
    end
    check(last_code[VEC] == E_OK && st_of(VEC) == S_ACTIVE, "power-up did not complete");
    check(tpw1 < tpg1 && tpg1 < tc1 && tc1 < tr1 && tr1 < tpm1 && tpm1 < tmb && tmb < tri_ && tri_ < tec &&
          tec < tiso1 && tiso1 < tq1,
          $sformatf("power-up order pwr%0d pg%0d clk%0d rstrel%0d pm%0d mbist%0d init%0d ecc%0d iso%0d q%0d",
                    tpw1, tpg1, tc1, tr1, tpm1, tmb, tri_, tec, tiso1, tq1));
    check(mem_ok[VEC] && !lost_of(VEC), "SRAM not valid after re-init");
    check(plain_reg[VEC] !== 32'hx && mbist_allow[VEC], "region not usable after power-up");
    expect_no_err("isolation_sequencing");
  endtask

  // T10 abort policy + fence, abort timeout
  task automatic t_abort();
    int ja; logic [3:0] dc; pd_evt_e c; bit fin; int base;
    cur_test = "abort_policy";
    do_reset();
    ja = jobs_ab[VEC];
    run_jobs(VEC, 4, 60);
    dma(VEC, 350);                                 // > quiesce timeout, drains within the fence bound
    go(VEC, T_OFF, E_OK, E_OK_ABORTED, 0, 0, 1);
    check(st_of(VEC) == S_OFF, "abort did not reach OFF");
    expect_err(VEC, ERR_ABORTED, "ABORTED (informational)");
    check(jobs_ab[VEC] > ja, "no work recorded as aborted");
    check(dma_pend[VEC], "test premise: DMA write still in flight (fenced)");
    // power-up is held until the fence has drained the in-flight write
    base = done_cnt[VEC];
    req(VEC, T_ACTIVE, 0, 0, 0, c, fin);
    tick(20);
    check(!pwr_en[VEC] && st_of(VEC) == S_OFF, "power-up while fenced transactions outstanding");
    wait_done(VEC, base, 2000, dc);
    check(dc == E_OK && !dma_pend[VEC], "power-up after fence drain");
    check(err[VEC][ERR_PROTOCOL] == 1'b0, "fence traffic flagged as protocol error");
    clr_err(VEC);
    // abort never acknowledged: nothing powered off, back to ACTIVE
    @(negedge clk); f_noab[VEC] = 1'b1;
    dma(VEC, 700);
    go(VEC, T_OFF, E_OK, E_REJ_BUSY, 0, 0, 1);
    check(st_of(VEC) == S_ACTIVE && pwr_en[VEC], "abort timeout must leave the region ACTIVE");
    expect_err(VEC, ERR_ABORT_TO, "ABORT_TO");
    @(negedge clk); f_noab[VEC] = 1'b0;
    guard = 0; while (dma_pend[VEC] && guard < 200000) guard_tick("DMA drain");
    clr_err(VEC);
    // a region without the abort policy ignores abort_ok
    go(EXT, T_OFF, E_REJ_UNSUPPORTED, NONE, 0, 0, 1);
    expect_no_err("abort_policy");
  endtask

  // T11 missing / stuck / lost power-good
  task automatic t_pgood();
    int b; logic [3:0] dc;
    cur_test = "missing_power_good";
    do_reset();
    go(VEC, T_OFF, E_OK, E_OK);
    @(negedge clk); f_no_pg[VEC] = 1'b1;
    go(VEC, T_ACTIVE, E_OK, E_ERR_PGOOD);
    check(st_of(VEC) == S_FAULT && !pwr_en[VEC] && iso[VEC] && rst_r[VEC], "missing power-good: switch not re-opened / not isolated");
    expect_err(VEC, ERR_PGOOD_ON_TO, "PGOOD_ON_TO");
    check(irq === 1'b1, "IRQ");
    go(VEC, T_ACTIVE, E_REJ_FAULT, NONE);
    @(negedge clk); f_no_pg[VEC] = 1'b0;
    clr_err(VEC);
    go(VEC, T_ACTIVE, E_OK, E_OK);
    // stuck on at power-down
    @(negedge clk); f_pg_stuck[VEC] = 1'b1;
    go(VEC, T_OFF, E_OK, E_ERR_PGOOD);
    expect_err(VEC, ERR_PGOOD_OFF_TO, "PGOOD_OFF_TO");
    check(st_of(VEC) == S_FAULT && iso[VEC] && iso_pm[VEC] && rst_r[VEC], "stuck switch: region not held safe");
    @(negedge clk); f_pg_stuck[VEC] = 1'b0;
    clr_err(VEC);
    go(VEC, T_OFF, E_OK, E_OK);                    // FAULT -> confirm off -> OFF
    go(VEC, T_ACTIVE, E_OK, E_OK);
    // brown-out while ACTIVE
    b = done_cnt[VEC];
    run_jobs(VEC, 2, 30);
    @(negedge clk); f_glitch[VEC] = 1'b1; @(negedge clk); f_glitch[VEC] = 1'b0;
    tick(6);
    check(st_of(VEC) == S_FAULT && iso[VEC] && iso_pm[VEC] && rst_r[VEC] && !pwr_en[VEC], "power-good loss: not isolated within 6 cycles");
    expect_err(VEC, ERR_PGOOD_LOST, "PGOOD_LOST");
    check(done_cnt[VEC] == b, "spurious completion event on unsolicited fault");
    // work issued to the region was lost with its supply: the dispatcher cancels it
    @(negedge clk); flush[VEC] = 1'b1; @(negedge clk); flush[VEC] = 1'b0;
    clr_err(VEC);
    guard = 0; while (dma_pend[VEC] && guard < 200000) guard_tick("DMA drain");
    go(VEC, T_ACTIVE, E_OK, E_OK);
    check(mem_ok[VEC], "SRAM not re-initialised after brown-out recovery");
    tick(20);
    clr_err(VEC);
    expect_no_err("missing_power_good");
  endtask

  // T12 retention protocol: logic retention (TNS), SRAM retention (SRAM), unsupported
  task automatic t_retention();
    logic [31:0] v; int rc, ec;
    cur_test = "memory_retention";
    do_reset();
    run_jobs(TNS, 3, 15); tick(60);
    go(TNS, T_OFF, E_OK, E_OK, 1);
    v = g_m[TNS].u_m.balloon;
    check(v != 0, "retention save captured nothing");
    check(ret_reg[TNS] === 32'hx || !rail[TNS], "main latch should be unpowered in OFF");
    go(TNS, T_ACTIVE, E_OK, E_OK);
    check(ret_reg[TNS] == v, $sformatf("retained state %0h != saved %0h", ret_reg[TNS], v));
    check(plain_reg[TNS] == 0, "non-retained state not reset");
    go(TNS, T_OFF, E_OK, E_OK, 0);
    go(TNS, T_ACTIVE, E_OK, E_OK);
    check(ret_reg[TNS] == 0, "state survived an OFF without retention");
    // VEC has SRAM without a retention mode: retention must be refused
    go(VEC, T_OFF, E_REJ_UNSUPPORTED, NONE, 1);
    // SRAM region: MUST_RETAIN, macros (hypothetically) with a retention mode
    go(VEC, T_IDLE, E_OK, E_OK); go(TNS, T_IDLE, E_OK, E_OK);
    g_m[SRAM].u_m.mem_fill(16'hA5C3);
    rc = reinit_cnt[SRAM]; ec = ecc_clr_cnt[SRAM];
    go(SRAM, T_OFF, E_REJ_RET_UNAVAIL, NONE);
    go(SRAM, T_OFF, E_OK, E_OK, 1);
    check(mret_ack[SRAM] && !rail[SRAM], "SRAM retention mode not entered before power-off");
    check(!lost_of(SRAM), "retained SRAM reported lost");
    go(SRAM, T_ACTIVE, E_OK, E_OK);
    check(g_m[SRAM].u_m.mem_check(16'hA5C3), "retained SRAM contents corrupted");
    check(reinit_cnt[SRAM] == rc && ecc_clr_cnt[SRAM] == ec, "retained SRAM was re-initialised / ECC cleared");
    // loss explicitly accepted: invalidate -> re-init -> ECC state cleared
    go(SRAM, T_OFF, E_OK, E_OK, 0, 1);
    check(inv_seen[SRAM] && lost_of(SRAM), "invalidate not signalled");
    go(SRAM, T_ACTIVE, E_OK, E_OK);
    check(reinit_cnt[SRAM] == rc + 1 && ecc_clr_cnt[SRAM] == ec + 1, "re-init / ECC clear missing");
    check(mem_ok[SRAM] && !g_m[SRAM].u_m.mem_check(16'hA5C3), "contents not re-initialised");
    go(VEC, T_ACTIVE, E_OK, E_OK); go(TNS, T_ACTIVE, E_OK, E_OK);
    expect_no_err("memory_retention");
  endtask

  // T13 power-up MBIST failure, SRAM re-init hang
  task automatic t_sram_faults();
    cur_test = "sram_faults";
    do_reset();
    go(VEC, T_OFF, E_OK, E_OK);
    @(negedge clk); f_mbf[VEC] = 1'b1;
    go(VEC, T_ACTIVE, E_OK, E_ERR_MBIST);
    expect_err(VEC, ERR_MBIST_FAIL, "MBIST_FAIL");
    check(st_of(VEC) == S_FAULT && !pwr_en[VEC] && iso[VEC], "MBIST failure: region not powered off and isolated");
    @(negedge clk); f_mbf[VEC] = 1'b0; clr_err(VEC);
    @(negedge clk); f_rhang[VEC] = 1'b1;
    go(VEC, T_ACTIVE, E_OK, E_ERR_TIMEOUT);
    expect_err(VEC, ERR_SRAM_TO, "SRAM_TO");
    @(negedge clk); f_rhang[VEC] = 1'b0; clr_err(VEC);
    go(VEC, T_ACTIVE, E_OK, E_OK);
    check(mem_ok[VEC], "SRAM invalid after recovery");
    expect_no_err("sram_faults");
  endtask

  // T14 inrush: two regions requested ON back-to-back power up one at a time
  task automatic t_inrush();
    int b1, b2; logic [3:0] dc; pd_evt_e c; bit fin; int up1, up2;
    cur_test = "inrush";
    do_reset();
    go(VEC, T_OFF, E_OK, E_OK); go(TNS, T_OFF, E_OK, E_OK);
    b1 = done_cnt[VEC]; b2 = done_cnt[TNS];
    req(VEC, T_ACTIVE, 0, 0, 0, c, fin);
    req(TNS, T_ACTIVE, 0, 0, 0, c, fin);
    up1 = -1; up2 = -1;
    while (done_cnt[VEC] == b1 || done_cnt[TNS] == b2) begin
      @(negedge clk);
      if (up1 < 0 && pwr_en[VEC]) up1 = cyc;
      if (up2 < 0 && pwr_en[TNS]) up2 = cyc;
      if (cyc > 100000) begin check(0, "inrush: timeout"); b1 = -1; b2 = -1; end
    end
    check(up1 > 0 && up2 > 0 && (up2 - up1) >= cfg.pgood_stable, "second switch closed while the first was still ramping");
    check(st_of(VEC) == S_ACTIVE && st_of(TNS) == S_ACTIVE, "both regions ACTIVE");
    expect_no_err("inrush");
  endtask


  // T16 boot order: after reset, providers ramp their supply before the regions that use them
  task automatic t_boot_order();
    int first_up [NR];
    cur_test = "boot_order";
    for (int r = 0; r < NR; r++) first_up[r] = -1;
    chk_en = 1'b0; clear_faults();
    @(negedge clk); rst_n = 1'b0; tick(5); rst_n = 1'b1; tick(3); chk_en = 1'b1;
    begin
      bit all_active;
      all_active = 1'b0;
      guard = 0;
      while (!all_active && guard < 20000) begin
        all_active = 1'b1;
        for (int r = 0; r < NR; r++) begin
          if (first_up[r] < 0 && st_of(r) == S_POWER_UP) first_up[r] = cyc;
          if (st_of(r) != S_ACTIVE) all_active = 1'b0;
        end
        if (!all_active) guard_tick("boot");
      end
    end
    for (int u = 0; u < NR; u++) for (int t = 0; t < NR; t++)
      if (P_DEP[u*NR + t] && P_SW[u] && P_SW[t])
        check(first_up[t] >= 0 && first_up[u] > first_up[t],
              $sformatf("boot order: r%0d ramped at %0d, before / with its provider r%0d at %0d", u, first_up[u], t, first_up[t]));
    for (int r = 0; r < NR; r++) check(st_of(r) == S_ACTIVE, $sformatf("r%0d not ACTIVE after boot", r));
    expect_no_err("boot_order");
  endtask

  // T17 a faulted provider cannot be restarted while its users are in use; recovery order works
  task automatic t_provider_fault();
    cur_test = "provider_fault";
    do_reset();
    @(negedge clk); f_glitch[SRAM] = 1'b1; @(negedge clk); f_glitch[SRAM] = 1'b0;
    tick(8);
    check(st_of(SRAM) == S_FAULT, "SRAM not in FAULT after brown-out");
    check(st_of(VEC) == S_ACTIVE && st_of(TNS) == S_ACTIVE, "users should still be ACTIVE (external fault)");
    clr_err(SRAM);
    go(SRAM, T_ACTIVE, E_REJ_DEPENDENCY, NONE);    // users in use: restart refused
    go(SRAM, T_OFF, E_REJ_DEPENDENCY, NONE, 0, 1);  // loss accepted: the dependency check refuses it
    check(st_of(SRAM) == S_FAULT, "faulted provider left FAULT while users in use");
    go(VEC, T_IDLE, E_OK, E_OK);
    go(TNS, T_IDLE, E_OK, E_OK);
    go(SRAM, T_ACTIVE, E_OK, E_OK, 0, 1);          // restart (contents were lost: allow_loss not needed for ACTIVE)
    check(mem_ok[SRAM], "SRAM not re-initialised after the restart");
    go(VEC, T_ACTIVE, E_OK, E_OK);
    go(TNS, T_ACTIVE, E_OK, E_OK);
    expect_no_err("provider_fault");
  endtask

  // T15 random stress with the invariant checker
  task automatic t_random(input int ncyc);
    int accepted [NR], completed [NR], b [NR];
    pd_evt_e c; bit fin;
    cur_test = "random";
    do_reset();
    for (int r = 0; r < NR; r++) begin accepted[r] = 0; completed[r] = 0; end
    for (int i = 0; i < ncyc; i++) begin
      @(negedge clk);
      submit = '0; dma_inj = '0; f_glitch = '0;
      for (int r = 0; r < NR; r++) begin
        b[r] = done_cnt[r];
        if (st_of(r) == S_ACTIVE && !quiesce[r]) begin
          if (rndr(0, 15) == 0) begin job_len[r] = 8'(rndr(1, 40)); submit[r] = 1'b1; end
          if (rndr(0, 40) == 0) begin dma_lat[r] = 16'(rndr(1, 260)); dma_inj[r] = 1'b1; end
        end
        if (P_SW[r] && rndr(0, 6000) == 0 && st_of(r) == S_ACTIVE) f_glitch[r] = 1'b1;
        flush[r] = (st_of(r) == S_FAULT);             // dispatcher cancels work of a faulted region
      end
      if (rndr(0, 700) == 0) therm = ~therm;
      if (rndr(0, 300) == 0) err_clr = '1; else err_clr = '0;
      if (rndr(0, 9) == 0) begin
        int r; pd_target_e t;
        r = rndr(0, NR - 1);
        t = pd_target_e'(rndr(0, 2));
        cmd_valid = 1'b1; cmd_region = 3'(r); cmd_target = t;
        cmd_retain = (rndr(0, 3) == 0); cmd_allow_loss = (rndr(0, 1) == 0); cmd_abort_ok = (rndr(0, 1) == 0);
        @(negedge clk);
        cmd_valid = 1'b0; submit = '0; dma_inj = '0; f_glitch = '0;
        if (rsp_code == E_OK && !rsp_final) accepted[r]++;
        check(rsp_valid === 1'b1, "random: response missing");
      end
    end
    @(negedge clk); submit = '0; dma_inj = '0; therm = 1'b0; err_clr = '1;
    @(negedge clk); err_clr = '0;
    all_settled(5000);
    // recovery as software would do it: idle the users, restart faulted providers, then bring
    // everything back up providers first
    for (int k = 0; k < 6; k++) for (int i = 0; i < 5; i++) begin
      int r; r = users_first(i);
      if (st_of(r) == S_ACTIVE) begin
        guard = 0; while ((dma_pend[r] || acc_pend[r]) && guard < 200000) guard_tick("outstanding work");
        req(r, T_IDLE, 0, 0, 0, c, fin);
        if (!fin) begin int n; n = 0; while (trans_of(r) && n < 4000) begin tick(1); n++; end end
      end
    end
    for (int k = 0; k < 3; k++) for (int i = 0; i < 5; i++) begin
      int r; r = providers_first(i);
      if (st_of(r) != S_ACTIVE) begin
        guard = 0; while ((dma_pend[r] || acc_pend[r]) && guard < 200000) guard_tick("outstanding work");
        if (st_of(r) == S_FAULT) clr_err(r);
        req(r, T_ACTIVE, 0, 0, 0, c, fin);
        if (!fin) wait_state(r, S_ACTIVE, 4000);
      end
    end
    for (int r = 0; r < NR; r++) check(st_of(r) == S_ACTIVE, $sformatf("random: r%0d not recoverable to ACTIVE", r));
    $display("random: %0d cycles, accepted per region %0d %0d %0d %0d %0d %0d %0d", ncyc,
             accepted[0], accepted[1], accepted[2], accepted[3], accepted[4], accepted[5], accepted[6]);
  endtask

  // ---------------------------------------------------------------- completion accounting
  // every accepted request (rsp OK, not final) is followed by exactly one completion
  int outstanding [NR];
  initial for (int r = 0; r < NR; r++) outstanding[r] = 0;
  always @(posedge clk) begin
    if (!rst_n) for (int r = 0; r < NR; r++) outstanding[r] <= 0;
    else begin
      for (int r = 0; r < NR; r++) begin
        int d;
        d = 0;
        if (rsp_valid && rsp_region == 3'(r) && rsp_code == E_OK && !rsp_final) d++;
        if (done[r] === 1'b1 && done_src[r] == 2'd1) d--;
        if (done[r] === 1'b1 && done_src[r] == 2'd0) begin n_err++; $display("FAIL [%0t] r%0d: completion without a source", $time, r); end
        outstanding[r] <= outstanding[r] + d;
        if (outstanding[r] + d > 1 || outstanding[r] + d < -1)
          begin n_err++; $display("FAIL [%0t] r%0d: request / completion accounting broken (%0d)", $time, r, outstanding[r] + d); end
      end
    end
  end

  // ---------------------------------------------------------------- main
  initial begin
    string test; int seed, ncyc;
    if (!$value$plusargs("TEST=%s", test)) test = "all";
    if (!$value$plusargs("SEED=%d", seed)) seed = 1;
    if (!$value$plusargs("CYCLES=%d", ncyc)) ncyc = 20000;
    rng = 32'h9E37_79B9 ^ 32'(seed);
    if (rng == 0) rng = 1;
    $display("tb_power_domain build=%s test=%s seed=%0d", BUILD, test, seed);
    if (test == "all" || test == "reset_defaults")       t_reset_defaults();
    if (test == "all" || test == "active_idle_active")   t_active_idle_active();
    if (test == "all" || test == "quiesce")              t_quiesce();
    if (test == "all" || test == "busy_reject")          t_busy_reject();
    if (test == "all" || test == "dependency")           t_dependency();
    if (test == "all" || test == "thermal")              t_thermal();
    if (test == "all" || test == "reset_mid_transition") t_reset_mid();
    if (test == "all" || test == "control_timeout")      t_timeouts();
    if (P_SW[VEC]) begin
      if (test == "all" || test == "isolation_sequencing") t_off_on_sequence();
      if (test == "all" || test == "abort_policy")         t_abort();
      if (test == "all" || test == "missing_power_good")   t_pgood();
      if (test == "all" || test == "memory_retention")     t_retention();
      if (test == "all" || test == "sram_faults")          t_sram_faults();
      if (test == "all" || test == "inrush")               t_inrush();
      if (test == "all" || test == "boot_order")           t_boot_order();
      if (test == "all" || test == "provider_fault")       t_provider_fault();
    end
    if (test == "all" || test == "random")               t_random(ncyc);
    tick(5);
    $display("RESULT: %s build=%s test=%s seed=%0d checks=%0d errors=%0d",
             (n_err == 0) ? "PASS" : "FAIL", BUILD, test, seed, n_chk, n_err);
    $finish;
  end

  // watchdog: the whole suite is ~0.33 ms of simulated time; anything 15x longer is a hang (+WATCHDOG_US=<n>)
  initial begin
    int wd_us;
    if (!$value$plusargs("WATCHDOG_US=%d", wd_us)) wd_us = 5000;
    #(wd_us * 1us);
    $display("RESULT: FAIL build=%s watchdog after %0d us (hang)", BUILD, wd_us);
    $finish;
  end
endmodule
