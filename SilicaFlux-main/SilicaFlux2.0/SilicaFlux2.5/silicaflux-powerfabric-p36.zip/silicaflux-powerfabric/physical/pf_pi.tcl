# =============================================================================
# SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
# pf_pi.tcl : power-integrity run on a PLACED database (openroad -exit pf_pi.tcl)
#
#   1. rip up the PDN in the database and rebuild it with variant $VARIANT
#      (pdn/sf_pdn.tcl + physical/pdn_params_$VARIANT.tcl), then the post-PDN
#      checks / exports of pdn/sf_post_pdn.tcl  ->  $OUT/pdn/
#   2. per-instance power at a REFERENCE activity (OpenSTA, typ liberty) plus
#      location -> $OUT/instances_ref.csv ; again at the STRESS activity
#   3. OpenROAD PDNSim (analyze_power_grid) static IR + EM on VDD and VSS with
#      sources on the top layer at the C4 pitch -> $OUT/psm_*.rpt
#   4. write_pg_spice of both nets -> $OUT/<net>.sp (input to scripts/powergrid.py)
# Environment: PF_ROOT VARIANT ODB SDC OUT ORFS_FLOW IHP_SRAM
#              [REF_ACT=0.1] [STRESS_ACT=0.5] [BUMP_PITCH_UM=200]
# =============================================================================
proc env_or {n d} { if {[info exists ::env($n)] && $::env($n) != ""} { return $::env($n) }; return $d }
set pf_root $::env(PF_ROOT)
set variant $::env(VARIANT)
set out     $::env(OUT)
set ref_act    [env_or REF_ACT 0.1]
set stress_act [env_or STRESS_ACT 0.5]
set pitch_um   [env_or BUMP_PITCH_UM 200]
file mkdir $out

set P $::env(ORFS_FLOW)/platforms/ihp-sg13g2
read_lef $P/lef/sg13g2_tech.lef
read_lef $P/lef/sg13g2_stdcell.lef
foreach s {2048 1024 512 256} { read_lef $::env(IHP_SRAM)/lef/RM_IHPSG13_1P_${s}x64_c2_bm_bist.lef }
read_liberty $P/lib/sg13g2_stdcell_typ_1p20V_25C.lib
foreach s {2048 1024 512 256} { read_liberty $::env(IHP_SRAM)/lib/RM_IHPSG13_1P_${s}x64_c2_bm_bist_typ_1p20V_25C.lib }
read_db $::env(ODB)
read_sdc $::env(SDC)
source $P/setRC.tcl
set block [ord::get_db_block]
set dbu [[$block getTech] getDbUnitsPerMicron]

# ---------------------------------------------------------------- 1. PDN variant
pdngen -ripup
set ::env(SF_PDN_PARAMS) $pf_root/physical/pdn_params_$variant.tcl
source $pf_root/pdn/sf_pdn.tcl
pdngen
set ::env(SF_PDN_OUT) $out/pdn
source $pf_root/pdn/sf_post_pdn.tcl

# ---------------------------------------------------------------- 2. instance power
proc dump_instances {fname} {
  global block dbu
  set corner [sta::cmd_corner]
  set fh [open $fname w]
  puts $fh "inst,master,kind,x_um,y_um,w_um,h_um,p_int_w,p_sw_w,p_leak_w,p_total_w"
  set tot 0.0
  foreach c [get_cells -hierarchical *] {
    if {![$c is_leaf]} continue
    set di [sta::sta_to_db_inst $c]
    if {$di == "NULL"} continue
    set b [$di getBBox]; set m [$di getMaster]
    set kind [expr {[$m getType] == "BLOCK" ? "macro" : "stdcell"}]
    lassign [sta::instance_power $c $corner] pi ps pl pt
    set tot [expr {$tot + $pt}]
    puts $fh [format "\"%s\",%s,%s,%.3f,%.3f,%.3f,%.3f,%.6e,%.6e,%.6e,%.6e" [$di getName] [$m getName] $kind \
      [expr {([$b xMin]+[$b xMax])/2.0/$dbu}] [expr {([$b yMin]+[$b yMax])/2.0/$dbu}] \
      [expr {([$b xMax]-[$b xMin])/double($dbu)}] [expr {([$b yMax]-[$b yMin])/double($dbu)}] $pi $ps $pl $pt]
  }
  close $fh
  return $tot
}
set_power_activity -global -activity $ref_act -duty 0.5
report_power > $out/power_ref.rpt
set p_ref [dump_instances $out/instances_ref.csv]
puts "SF-PI: reference activity $ref_act total [format %.4e $p_ref] W"

# ---------------------------------------------------------------- 3. PDNSim (OpenROAD) cross-check
# -dx/-dy are given in database units in this OpenROAD build (200 => 0.2 um).
set pitch_dbu [expr {int($pitch_um * $dbu)}]
set psm {}
foreach {net v} {VDD 1.2 VSS 0.0} {
  set_pdnsim_net_voltage -net $net -voltage $v
  set t [clock milliseconds]
  set rc [catch {analyze_power_grid -net $net -dx $pitch_dbu -dy $pitch_dbu -outfile $out/psm_${net}_voltage.rpt \
                   -enable_em -em_outfile $out/psm_${net}_em.rpt -error_file $out/psm_${net}_errors.rpt} msg]
  puts "SF-PI: analyze_power_grid $net rc=$rc ([expr {[clock milliseconds]-$t}] ms) $msg"
  write_pg_spice -net $net -dx $pitch_dbu -dy $pitch_dbu -outfile $out/$net.sp
}

# ---------------------------------------------------------------- stress activity (upper bound)
set_power_activity -global -activity $stress_act -duty 0.5
report_power > $out/power_stress.rpt
set p_st [dump_instances $out/instances_stress.csv]
puts "SF-PI: stress activity $stress_act total [format %.4e $p_st] W"
puts "SF-PI: done ($variant)"
