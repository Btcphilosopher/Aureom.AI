#!/usr/bin/env bash
# =============================================================================
# SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
# run_flow.sh : the complete physical power-distribution flow, end to end.
#
#   0. inputs     unpack FloorplanLab / PackageTwin / ThermalLab from the repository archives (ext/)
#   1. params     scripts/pdn_params.py  (validate PDN parameters against the tech / std-cell / SRAM LEFs,
#                 PackageTwin bump map)  -> physical/pdn_params_<variant>.tcl
#   2. ORFS       synth -> floorplan (2_1..2_5) -> PDN 2_6 with pdn/sf_pdn.tcl + pdn/sf_post_pdn.tcl -> place 3_*
#   3. PI         physical/pf_pi.tcl per PDN variant on the placed database (rip-up + rebuild, checks,
#                 instance power, PDNSim IR/EM, PG SPICE)  -> scripts/powergrid.py, pdn_check.py
#   4. UPF        upf/validate_upf.tcl (OpenROAD read_upf on the placed design) -> scripts/upf_check.py
#   5. reports    region_placement, IR map, PowerGrid import check, connectivity / scenario / package reports
#
# Tools: the pinned FloorplanLab stack (env/install_toolchain.sh of silicaflux-floorplanlab: OpenROAD
# 2.0-12331-g6011bbe77, Yosys 0.38+92, ORFS ab2aaf0f, IHP SRAM collateral d0e5b3c) + Python 3 with
# numpy, scipy, PyYAML, matplotlib.  Runtime about 15 minutes on 4 cores.
# =============================================================================
set -euo pipefail
PF_ROOT=$(cd "$(dirname "$0")/.." && pwd)
REPO=${REPO:-$(cd "$PF_ROOT/../.." 2>/dev/null && pwd)}           # Aureom.AI checkout
EDA_ROOT=${EDA_ROOT:-/opt/eda}
export ORFS_FLOW=${ORFS_FLOW:-$EDA_ROOT/orfs/flow}
export IHP_SRAM=${IHP_SRAM:-$EDA_ROOT/collateral/ihp-sg13g2-sram-d0e5b3c}
OPENROAD=${OPENROAD_EXE:-$EDA_ROOT/env/bin/openroad}
YOSYS=${YOSYS_EXE:-$EDA_ROOT/env/bin/yosys}
WORK=${WORK:-$PF_ROOT/work}
EXT=${EXT:-$PF_ROOT/ext}
B25="$REPO/SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5"
STEP=${1:-all}
mkdir -p "$WORK" "$EXT"

# ---------------------------------------------------------------- 0. inputs
unpack() {  # zip, member dir, destination
  [ -d "$3" ] || { mkdir -p "$EXT/tmp" && unzip -q -o "$1" -d "$EXT/tmp" && mv "$EXT/tmp/$2" "$3"; rm -rf "$EXT/tmp"; }
}
unpack "$B25/silicaflux-floorplanlab.zip" silicaflux-floorplanlab "$EXT/floorplanlab"
unpack "$REPO/SilicaFlux-main/silicaflux-packagetwin-v0.1.0.zip" silicaflux-packagetwin "$EXT/packagetwin"
if [ ! -d "$EXT/thermallab" ]; then
  mkdir -p "$EXT/tl" && unzip -q -o "$B25/SilicaFlux ThermalLab (1).zip" -d "$EXT/tl" && unzip -q -o "$EXT/tl/silicaflux-thermallab-0.1.0.zip" -d "$EXT/tl"
  mv "$EXT/tl/asic/thermallab" "$EXT/thermallab"; rm -rf "$EXT/tl"
fi
export FLP_ROOT="$EXT/floorplanlab" PACKAGETWIN_ROOT="$EXT/packagetwin" THERMALLAB_ROOT="$EXT/thermallab"
export PF_ROOT PF_INPUTS="$PF_ROOT/physical/inputs"
R="$WORK/orfs/results/ihp-sg13g2/silicaflux_v/base"

# ---------------------------------------------------------------- 1. params
if [[ $STEP == all || $STEP == params ]]; then
  for v in powerfabric floorplanlab; do python3 "$PF_ROOT/scripts/pdn_params.py" --variant $v; done
fi

# ---------------------------------------------------------------- 2. ORFS
orfs() { make -C "$ORFS_FLOW" DESIGN_CONFIG="$WORK/config.mk" WORK_HOME="$WORK/orfs" FLOW_VARIANT=base \
              OPENROAD_EXE="$OPENROAD" YOSYS_CMD="$YOSYS" "$@"; }
if [[ $STEP == all || $STEP == orfs ]]; then
  cp "$PF_ROOT/physical/config.mk.tmpl" "$WORK/config.mk"
  export SF_PDN_PARAMS="$PF_ROOT/physical/pdn_params_powerfabric.tcl" SF_PDN_OUT="$WORK/orfs_pdn"
  orfs synth                                                                   > "$WORK/synth.log" 2>&1
  orfs do-2_1_floorplan do-2_2_floorplan_io do-2_3_floorplan_tdms do-2_4_floorplan_macro do-2_5_floorplan_tapcell \
                                                                               > "$WORK/floorplan.log" 2>&1
  orfs do-2_6_floorplan_pdn do-2_floorplan                                     > "$WORK/pdn.log" 2>&1
  orfs do-3_1_place_gp_skip_io do-3_2_place_iop do-3_3_place_gp do-3_4_place_resized do-3_5_place_dp do-3_place \
                                                                               > "$WORK/place.log" 2>&1
  python3 "$PF_ROOT/scripts/pdn_check.py" --data "$WORK/orfs_pdn" --variant powerfabric --tag orfs_floorplan_powerfabric || true
fi

# ---------------------------------------------------------------- 3. PI
if [[ $STEP == all || $STEP == pi ]]; then
  for v in powerfabric floorplanlab; do
    PF_ROOT="$PF_ROOT" VARIANT=$v ODB="$R/3_place.odb" SDC="$R/2_floorplan.sdc" OUT="$WORK/pi/$v" \
      "$OPENROAD" -no_init -exit "$PF_ROOT/physical/pf_pi.tcl" > "$WORK/pi_$v.log" 2>&1
    python3 "$PF_ROOT/scripts/pdn_check.py" --data "$WORK/pi/$v/pdn" --variant $v --tag placed_$v
    python3 "$PF_ROOT/scripts/powergrid.py" --run "$WORK/pi/$v" --variant $v
  done
fi

# ---------------------------------------------------------------- 4. UPF
if [[ $STEP == all || $STEP == upf ]]; then
  python3 "$PF_ROOT/scripts/gen_power_config.py"
  mkdir -p "$PF_ROOT/reports/upf/openroad"
  for u in silicaflux_pf_baseline.openroad silicaflux_pf_future.openroad silicaflux_pf_baseline silicaflux_pf_future; do
    ODB="$R/3_place.odb" OUT="$PF_ROOT/reports/upf/openroad" UPF="$PF_ROOT/upf/$u.upf" \
      "$OPENROAD" -no_init -exit "$PF_ROOT/upf/validate_upf.tcl" > "$WORK/upf_$u.log" 2>&1 || true
  done
  python3 "$PF_ROOT/scripts/upf_check.py" "$PF_ROOT/reports/upf/openroad"
  python3 "$PF_ROOT/scripts/upf_check_selftest.py" > "$PF_ROOT/reports/upf/upf_check_selftest.txt"
fi

# ---------------------------------------------------------------- 5. reports
if [[ $STEP == all || $STEP == reports ]]; then
  python3 "$PF_ROOT/scripts/tech_audit.py"
  python3 "$PF_ROOT/scripts/region_placement.py" --run "$WORK/pi/powerfabric"
  python3 "$PF_ROOT/scripts/plot_ir.py" "$WORK/pi"
  python3 "$PF_ROOT/scripts/import_check.py" "$PF_ROOT/reports/pi/powerfabric/powergrid_export_mixed_VDD" "$PACKAGETWIN_ROOT" "$THERMALLAB_ROOT"
  python3 "$PF_ROOT/scripts/report_physical.py" "$WORK/pi" "$PACKAGETWIN_ROOT"
fi
echo "run_flow.sh: $STEP done"
