# =============================================================================
# SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
# sf_post_pdn.tcl : ORFS POST_PDN_TCL hook (also sourced by physical/pf_pi.tcl)
#
# Runs OpenROAD's own connectivity check (check_power_grid) and exports the
# raw power-grid data that scripts/pdn_check.py checks against the LEF rules:
#   $SF_PDN_OUT/check_power_grid.json   check_power_grid per supply net
#   $SF_PDN_OUT/pdn_shapes.csv          every special wire / via of VDD and VSS
#   $SF_PDN_OUT/macro_pg_pins.csv       every hard-macro PG pin shape (die coords) + its net
#   $SF_PDN_OUT/pg_iterms.json          PG-pin connection of EVERY instance
# A failing check is RECORDED; it is never turned into a pass here.
# =============================================================================
set pf_out [expr {[info exists ::env(SF_PDN_OUT)] ? $::env(SF_PDN_OUT) : [file join $::env(RESULTS_DIR) pf_pdn]}]
file mkdir $pf_out
set block [ord::get_db_block]
set dbu [[$block getTech] getDbUnitsPerMicron]
proc um {v} { global dbu; return [format %.4f [expr {double($v) / $dbu}]] }

# ---------------------------------------------------------------- check_power_grid
set cpg {}
foreach net [$block getNets] {
  set t [$net getSigType]
  if {$t != "POWER" && $t != "GROUND"} { continue }
  set name [$net getName]
  set errf $pf_out/unconnected_$name.rpt
  file delete -force $errf
  set rc [catch {check_power_grid -net $name -error_file $errf} msg]
  set n_unc 0
  if {[file exists $errf]} {
    set fh [open $errf r]; set txt [read $fh]; close $fh
    set n_unc [regexp -all -line {^\S} $txt]
  }
  puts "SF-PDN: check_power_grid -net $name -> rc=$rc result=$msg unconnected_lines=$n_unc"
  lappend cpg "{\"net\": \"$name\", \"type\": \"$t\", \"rc\": $rc, \"result\": \"[string map {\" '} $msg]\", \"unconnected_lines\": $n_unc}"
}
set fh [open $pf_out/check_power_grid.json w]; puts $fh "\[[join $cpg ,\n]\]"; close $fh

# ---------------------------------------------------------------- PG shapes
set fh [open $pf_out/pdn_shapes.csv w]
puts $fh "net,kind,layer,top_layer,shape,x0,y0,x1,y1"
foreach net [$block getNets] {
  set t [$net getSigType]
  if {$t != "POWER" && $t != "GROUND"} { continue }
  foreach sw [$net getSWires] {
    foreach w [$sw getWires] {
      set st [$w getWireShapeType]
      if {[$w isVia]} {
        set bl ""; set tl ""
        catch { set v [$w getBlockVia]; if {$v != "NULL"} { set bl [[$v getBottomLayer] getName]; set tl [[$v getTopLayer] getName] } }
        if {$bl == ""} { catch { set v [$w getTechVia]; if {$v != "NULL"} { set bl [[$v getBottomLayer] getName]; set tl [[$v getTopLayer] getName] } } }
        puts $fh "[$net getName],via,$bl,$tl,$st,[um [$w xMin]],[um [$w yMin]],[um [$w xMax]],[um [$w yMax]]"
      } else {
        puts $fh "[$net getName],wire,[[$w getTechLayer] getName],,$st,[um [$w xMin]],[um [$w yMin]],[um [$w xMax]],[um [$w yMax]]"
      }
    }
  }
}
close $fh

# ---------------------------------------------------------------- macro PG pins (die coordinates)
proc pf_xform {inst x1 y1 x2 y2} {
  set b [$inst getBBox]; set m [$inst getMaster]
  set W [$m getWidth]; set H [$m getHeight]
  set bx [$b xMin]; set by [$b yMin]
  switch [$inst getOrient] {
    R0   { return [list [expr {$bx+$x1}] [expr {$by+$y1}] [expr {$bx+$x2}] [expr {$by+$y2}]] }
    MX   { return [list [expr {$bx+$x1}] [expr {$by+$H-$y2}] [expr {$bx+$x2}] [expr {$by+$H-$y1}]] }
    MY   { return [list [expr {$bx+$W-$x2}] [expr {$by+$y1}] [expr {$bx+$W-$x1}] [expr {$by+$y2}]] }
    R180 { return [list [expr {$bx+$W-$x2}] [expr {$by+$H-$y2}] [expr {$bx+$W-$x1}] [expr {$by+$H-$y1}]] }
    default { return {} }
  }
}
set fh [open $pf_out/macro_pg_pins.csv w]
puts $fh "inst,master,pin,net,layer,x0,y0,x1,y1"
foreach inst [$block getInsts] {
  set m [$inst getMaster]
  if {[$m getType] != "BLOCK"} { continue }
  foreach it [$inst getITerms] {
    set mt [$it getMTerm]
    set st [$mt getSigType]
    if {$st != "POWER" && $st != "GROUND"} { continue }
    set net [$it getNet]
    set nn [expr {$net == "NULL" ? "" : [$net getName]}]
    foreach mp [$mt getMPins] {
      foreach g [$mp getGeometry] {
        set r [pf_xform $inst [$g xMin] [$g yMin] [$g xMax] [$g yMax]]
        if {$r == ""} { continue }
        lassign $r a b c d
        puts $fh "\"[$inst getName]\",[$m getName],[$mt getName],$nn,[[$g getTechLayer] getName],[um $a],[um $b],[um $c],[um $d]"
      }
    }
  }
}
close $fh

# ---------------------------------------------------------------- PG pin connection of every instance
array set pgc {}
set unconnected {}
foreach inst [$block getInsts] {
  set m [$inst getMaster]
  set kind [expr {[$m getType] == "BLOCK" ? "macro" : "stdcell"}]
  foreach it [$inst getITerms] {
    set mt [$it getMTerm]
    set st [$mt getSigType]
    if {$st != "POWER" && $st != "GROUND"} { continue }
    set net [$it getNet]
    set ok [expr {$net != "NULL" && [$net getSigType] == $st}]
    set key "$kind,$st,$ok"
    if {![info exists pgc($key)]} { set pgc($key) 0 }
    incr pgc($key)
    if {!$ok && [llength $unconnected] < 50} { lappend unconnected "\"[$inst getName]/[$mt getName]\"" }
  }
}
set items {}
foreach k [lsort [array names pgc]] {
  lassign [split $k ,] kind st ok
  lappend items "{\"kind\": \"$kind\", \"sig\": \"$st\", \"connected\": $ok, \"count\": $pgc($k)}"
}
set fh [open $pf_out/pg_iterms.json w]
puts $fh "{\"counts\": \[[join $items ,]\], \"unconnected_examples\": \[[join $unconnected ,]\]}"
close $fh
puts "SF-PDN: exported PDN data to $pf_out"
