# =============================================================================
# SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
# sf_pdn.tcl : parameterised OpenROAD pdngen script (ORFS PDN_TCL hook)
#
# Every layer name, width, pitch and offset comes from the parameter file
# $SF_PDN_PARAMS (physical/pdn_params_<variant>.tcl), which
# scripts/pdn_params.py generates from config/power_regions.yaml AFTER
# validating each value against the technology LEF (layer exists, routing
# direction, min width / max width, same-layer spacing, manufacturing grid,
# density limits) and the macro LEFs (PG pin layers and stripe lengths).
# No foundry rule is encoded here; this script only expresses topology.
#
# Topology (variant "powerfabric"):
#   Metal1 follow-pin rails  -> Metal5 straps (via stack Via1..Via4)
#   Metal5 straps            -> TopMetal1 straps (TopVia1)
#   TopMetal1 straps         -> TopMetal2 straps (TopVia2) = C4 bump layer
#   TopMetal1 / TopMetal2 core ring
#   SRAM macros: VDD!, VDDARRAY!, VSS! (vertical Metal4 stripes) connected UP
#   to the TopMetal1 straps that cross the macros (macro grid, no own straps)
# Variant "floorplanlab" reproduces the FloorplanLab A_baseline PDN (no
# TopMetal2) for comparison.
# =============================================================================
if {![info exists ::env(SF_PDN_PARAMS)]} {
  error "sf_pdn.tcl: SF_PDN_PARAMS is not set (generate it with scripts/pdn_params.py)"
}
source $::env(SF_PDN_PARAMS)
puts "SF-PDN: variant $pf(variant)  params $::env(SF_PDN_PARAMS)"

# ---------------------------------------------------------------- global connections
# standard cells (pin names from sg13g2_stdcell.lef) and SRAM macros (RM_IHPSG13 LEF)
foreach {net pins type} $pf(global_connect) {
  foreach p $pins {
    add_global_connection -net $net -inst_pattern {.*} -pin_pattern "^${p}\$" $type
  }
}
global_connect

set_voltage_domain -name $pf(domain) -power $pf(power_net) -ground $pf(ground_net)

# ---------------------------------------------------------------- core grid
define_pdn_grid -name core_grid -voltage_domains $pf(domain)
set ext {}
if {$pf(ring) } {
  add_pdn_ring -grid core_grid -layers $pf(ring_layers) -widths $pf(ring_widths) \
               -spacings $pf(ring_spacings) -core_offsets $pf(ring_offsets)
  set ext {-extend_to_core_ring}
}
add_pdn_stripe -grid core_grid -layer $pf(rail_layer) -width $pf(rail_width) -followpins {*}$ext
foreach s $pf(straps) {
  lassign $s layer width pitch offset spacing
  add_pdn_stripe -grid core_grid -layer $layer -width $width -pitch $pitch -offset $offset \
                 -spacing $spacing {*}$ext
}
foreach c $pf(connects) {
  add_pdn_connect -grid core_grid -layers $c
}

# ---------------------------------------------------------------- SRAM macro grid
set srams {}
foreach inst [[ord::get_db_block] getInsts] {
  set m [$inst getMaster]
  if {[$m getType] == "BLOCK" && [string match $pf(macro_pattern) [$m getName]]} {
    if {[lsearch $srams [$m getName]] < 0} { lappend srams [$m getName] }
  }
}
if {[llength $srams] > 0} {
  set h $pf(macro_halo)
  define_pdn_grid -name sram_grid -voltage_domains $pf(domain) -macro -cells $srams \
    -halo [list $h $h $h $h] -grid_over_boundary
  add_pdn_connect -grid sram_grid -layers $pf(macro_connect)
  puts "SF-PDN: macro grid for [llength $srams] master(s): $srams (connect $pf(macro_connect))"
} else {
  puts "SF-PDN: no hard macros match $pf(macro_pattern)"
}
