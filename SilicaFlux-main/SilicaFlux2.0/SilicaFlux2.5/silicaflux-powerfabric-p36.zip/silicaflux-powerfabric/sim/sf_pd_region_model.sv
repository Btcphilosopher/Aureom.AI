// =============================================================================
// SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
// sf_pd_region_model : SIMULATION-ONLY model of one power region.
//
// NOT synthesisable and NOT a model of any real SilicaFlux block's timing.
// It exists to exercise the controller's protocol:
//   * power switch with ramp delays and fault injection (no power-good, power-
//     good stuck, brown-out glitch) - an abstraction of a switch ack chain;
//   * region logic that goes to X when unpowered (Icarus) so a missing
//     isolation clamp or an early de-isolation propagates X to the checkers;
//   * workload: a dispatcher queue (always-on), a running job (region clock),
//     DMA writes in flight in the fabric (always-on clock);
//   * 4-phase quiesce handshake, explicit abort with a response fence;
//   * retention registers (balloon latch) - only meaningful if LOGIC_RET;
//   * SRAM: contents + ECC-valid bit per word, invalidate, 4-phase re-init
//     sweep, power-up MBIST (destroys contents), retention mode if SRAM_RET.
// Data and PM-status outputs leave the region through sf_pd_boundary
// functional isolation models (clamp: valid 0, busy 0, ack 1, ...).
// =============================================================================
`timescale 1ns/1ps
module sf_pd_region_model #(
  parameter int ID         = 0,
  parameter bit SWITCHABLE = 1'b0,
  parameter bit HAS_SRAM   = 1'b0,
  parameter bit SRAM_RET   = 1'b0,
  parameter bit LOGIC_RET  = 1'b0,
  parameter int MEM_WORDS  = 32,
  parameter int PG_RISE    = 12,
  parameter int PG_FALL    = 9,
  parameter int MBIST_CYC  = 40
) (
  input  logic        clk_i,
  input  logic        rst_ni,
  // controller -> region
  input  logic        clk_en_i,
  input  logic        quiesce_i,
  input  logic        abort_i,
  input  logic        iso_i,
  input  logic        iso_pm_i,
  input  logic        rst_req_i,
  input  logic        pwr_en_i,
  input  logic        ret_save_i,
  input  logic        ret_hold_i,
  input  logic        ret_restore_i,
  input  logic        mem_ret_i,
  input  logic        mem_inv_i,
  input  logic        mem_reinit_i,
  input  logic        mem_ecc_clr_i,
  input  logic        mbist_req_i,
  // region -> controller
  output logic        busy_o,
  output logic        q_ack_o,
  output logic        abort_ack_o,
  output logic        clk_ack_o,
  output logic        pgood_o,
  output logic        mem_ret_ack_o,
  output logic        mem_reinit_done_o,
  output logic        mbist_done_o,
  output logic        mbist_fail_o,
  output logic        dma_wr_pend_o,
  output logic        acc_op_pend_o,
  // region data boundary as seen by the always-on side
  output logic        out_valid_o,
  output logic [7:0]  out_data_o,
  // testbench controls
  input  logic        submit_job_i,
  input  logic        flush_i,         // dispatcher cancels everything issued (after a FAULT)
  input  logic [7:0]  job_len_i,
  input  logic        dma_inject_i,
  input  logic [15:0] dma_lat_i,
  input  logic        f_no_pgood_i,
  input  logic        f_pgood_stuck_i,
  input  logic        f_glitch_i,
  input  logic        f_clkack_stuck_i,
  input  logic        f_mbist_fail_i,
  input  logic        f_reinit_hang_i,
  input  logic        f_busy_stuck_i,
  input  logic        f_stale_ack_i,
  input  logic        f_no_abort_ack_i,
  // observation
  output logic        rail_o,
  output logic        gclk_o,
  output logic [31:0] ret_reg_o,      // a retention register (balloon-latch backed if LOGIC_RET)
  output logic [31:0] plain_reg_o,    // an ordinary register
  output logic        mem_all_valid_o,
  output int          jobs_done_o,
  output int          jobs_aborted_o,
  output int          gclk_edges_o,
  output logic        inv_seen_o,
  output int          ecc_clr_cnt_o,
  output int          reinit_cnt_o
);
  // ---------------------------------------------------------------- power switch
  logic rail, pgood, glitch;
  int   ramp;
  initial begin rail = !SWITCHABLE; pgood = !SWITCHABLE; ramp = 0; glitch = 1'b0; end
  always @(posedge clk_i) begin
    if (!SWITCHABLE) begin
      rail <= 1'b1; pgood <= 1'b1;
    end else begin
      if (pwr_en_i && !rail) begin
        ramp <= ramp + 1;
        if (ramp >= PG_RISE) begin rail <= 1'b1; ramp <= 0; end
      end else if (!pwr_en_i && rail && !f_pgood_stuck_i) begin
        ramp <= ramp + 1;
        if (ramp >= PG_FALL) begin rail <= 1'b0; ramp <= 0; end
      end else ramp <= 0;
      if (f_glitch_i) rail <= 1'b0;                         // brown-out: rail collapses
      pgood <= rail && !f_no_pgood_i && !f_glitch_i;
    end
  end
  assign pgood_o = pgood;
  assign rail_o  = rail;

  // ---------------------------------------------------------------- clock gate (always-on side)
  logic gclk, cack;
  sf_pd_icg u_icg (.clk_i, .rst_ni, .en_i(clk_en_i), .test_en_i(1'b0), .gclk_o(gclk), .en_ack_o(cack));
  assign gclk_o    = gclk;
  assign clk_ack_o = f_clkack_stuck_i ? 1'b1 : cack;
  initial gclk_edges_o = 0;
  always @(posedge gclk) gclk_edges_o <= gclk_edges_o + 1;

  // ---------------------------------------------------------------- dispatcher + fabric (always-on)
  int  q_jobs;
  // operations issued by the dispatcher travel to the region's input queue for
  // TRANSIT cycles: during that time the REGION cannot see them (its quiesce ack
  // does not cover them) - only the dispatcher's outstanding flag does.
  localparam int TRANSIT = 5;
  logic [7:0][3:0] tr_t;   // up to 8 operations in transit
  logic [15:0][15:0] dma_t;   // packed: remaining latency of up to 16 in-flight writes
  logic job_pull, job_fin, abort_cancel;
  int  q_aborted, run_aborted;
  initial begin q_jobs = 0; jobs_done_o = 0; q_aborted = 0; run_aborted = 0; end
  assign jobs_aborted_o = q_aborted + run_aborted;
  always @(posedge clk_i) begin
    begin : transit
      int arrive;
      bit placed;
      arrive = 0; placed = 1'b0;
      for (int i = 0; i < 8; i++) begin
        if (tr_t[i] == 4'd1) arrive++;
        if (tr_t[i] != 4'd0) tr_t[i] <= tr_t[i] - 4'd1;
      end
      if (submit_job_i)
        for (int i = 0; i < 8; i++) if (!placed && tr_t[i] == 4'd0) begin tr_t[i] <= 4'(TRANSIT); placed = 1'b1; end
      q_jobs <= q_jobs + arrive - (job_pull ? 1 : 0);
      if (abort_cancel || flush_i) begin q_aborted <= q_aborted + q_jobs + arrive; q_jobs <= 0; tr_t <= '0; end
    end
    if (!rst_ni) begin q_jobs <= 0; tr_t <= '0; end   // global reset clears the dispatcher
    // DMA writes in flight: complete after their latency regardless of the region clock
    for (int i = 0; i < 16; i++) if (dma_t[i] != 16'd0) dma_t[i] <= dma_t[i] - 16'd1;
    if (!rst_ni) dma_t <= '0;                         // ... and the fabric
    if (dma_inject_i || job_fin) begin : alloc
      bit placed;
      placed = 1'b0;
      for (int i = 0; i < 16; i++) if (!placed && dma_t[i] == 0) begin
        dma_t[i] <= (dma_inject_i ? dma_lat_i : 16'd6); placed = 1'b1;
      end
    end
  end
  initial dma_t = '0;
  initial tr_t = '0;
  assign dma_wr_pend_o = (dma_t != '0);

  // ---------------------------------------------------------------- region logic (switched supply)
  logic        running, qack, abt_ack, rst_eff;
  logic [7:0]  run_left;
  logic [31:0] ret_reg, plain_reg, balloon;
  logic        in_ret;     // retention flops holding (ignore clock / reset)
  assign rst_eff = rst_req_i || !rst_ni;
  assign in_ret  = LOGIC_RET && ret_hold_i;
  initial balloon = 32'h0;

  // quiesce = drain: the dispatcher accepts no new submissions (testbench
  // contract), the region keeps executing work that was already submitted.
  assign job_pull     = rail && !rst_eff && !running && !abort_i && (q_jobs > 0) && clk_en_i && cack;
  assign job_fin      = rail && !rst_eff && running && (run_left == 8'd1) && cack;
  assign abort_cancel = rail && abort_i && !abt_ack;

  always @(posedge gclk or posedge rst_eff or negedge rail or posedge ret_restore_i) begin
    if (!rail) begin
      running <= 1'bx; run_left <= 8'hxx; qack <= 1'bx; abt_ack <= 1'bx; plain_reg <= 32'hxxxx_xxxx;
      ret_reg <= 32'hxxxx_xxxx;                         // retention MAIN latch loses power too
    end else if (LOGIC_RET && ret_restore_i) begin
      ret_reg <= balloon;                               // restore overrides the main latch
    end else if (rst_eff) begin
      running <= 1'b0; run_left <= 8'd0; qack <= 1'b0; abt_ack <= 1'b0; plain_reg <= 32'd0;
      if (!in_ret) ret_reg <= 32'd0;
    end else begin
      // job execution
      if (abort_i) begin
        running <= 1'b0; run_left <= 8'd0;              // running job cancelled
        if (running) run_aborted <= run_aborted + 1;
      end else if (running) begin
        if (run_left == 8'd1) begin running <= 1'b0; jobs_done_o <= jobs_done_o + 1; end
        run_left <= run_left - 8'd1;
      end else if (job_pull) begin
        running <= 1'b1; run_left <= (job_len_i == 0) ? 8'd1 : job_len_i;
      end
      if (!in_ret && running) ret_reg <= ret_reg + 32'd1;
      if (running) plain_reg <= plain_reg + 32'd3;
      qack    <= quiesce_i && !(running && !abort_i) && !(job_pull || (q_jobs > 0 && !abort_i)) && !f_busy_stuck_i;
      abt_ack <= abort_i && !f_no_abort_ack_i;
    end
  end
  // retention save / restore (balloon latch on the always-on supply)
  always @(posedge clk_i) begin
    if (LOGIC_RET && ret_save_i) balloon <= ret_reg;
  end
  assign ret_reg_o   = ret_reg;
  assign plain_reg_o = plain_reg;

  logic busy_raw, qack_raw, abt_raw;
  assign busy_raw = rail ? ((running === 1'b1) || f_busy_stuck_i) : 1'bx;
  assign qack_raw = rail ? (f_stale_ack_i ? 1'b1 : qack) : 1'bx;
  assign abt_raw  = rail ? abt_ack : 1'bx;
  assign acc_op_pend_o = (tr_t != '0) || (q_jobs > 0) || (running === 1'b1);   // dispatcher view (always-on)

  // ---------------------------------------------------------------- SRAM
  logic [MEM_WORDS-1:0] valid;
  logic [15:0] mem [0:MEM_WORDS-1];
  logic        in_mret, mret_ack, init_busy, init_done, mb_busy, mb_done, mb_fail;
  int          init_ptr, mb_cnt, mret_cnt;
  initial begin valid = '0; in_mret = 1'b0; mret_ack = 1'b0; init_busy = 0; init_done = 0;
                mb_busy = 0; mb_done = 0; mb_fail = 0; init_ptr = 0; mb_cnt = 0; mret_cnt = 0;
                inv_seen_o = 0; ecc_clr_cnt_o = 0; reinit_cnt_o = 0; end
  if (HAS_SRAM) begin : g_sram
    // retention mode handshake (array kept on its own supply; only if SRAM_RET)
    always @(posedge clk_i) begin
      if (SRAM_RET) begin
        if (mem_ret_i != mret_ack) begin
          mret_cnt <= mret_cnt + 1;
          if (mret_cnt >= 3) begin mret_ack <= mem_ret_i; in_mret <= mem_ret_i; mret_cnt <= 0; end
        end else mret_cnt <= 0;
      end
    end
    // contents are lost when the rail drops, unless in retention mode
    always @(negedge rail) if (!in_mret) begin valid <= '0; for (int i = 0; i < MEM_WORDS; i++) mem[i] <= 16'hxxxx; end
    always @(posedge clk_i) if (mem_inv_i) inv_seen_o <= 1'b1;
    always @(posedge clk_i) if (mem_ecc_clr_i) ecc_clr_cnt_o <= ecc_clr_cnt_o + 1;
    // re-init sweep and MBIST run on the region clock, need power and no reset
    always @(posedge gclk) begin
      if (rail && !rst_eff) begin
        if (mem_reinit_i && !init_busy && !init_done) begin init_busy <= 1'b1; init_ptr <= 0; end
        else if (init_busy && !f_reinit_hang_i) begin
          mem[init_ptr] <= 16'h0000; valid[init_ptr] <= 1'b1;
          if (init_ptr == MEM_WORDS-1) begin init_busy <= 1'b0; init_done <= 1'b1; reinit_cnt_o <= reinit_cnt_o + 1; end
          init_ptr <= init_ptr + 1;
        end
        if (!mem_reinit_i) init_done <= 1'b0;
        if (mbist_req_i && !mb_busy && !mb_done) begin mb_busy <= 1'b1; mb_cnt <= 0; end
        else if (mb_busy) begin
          mb_cnt <= mb_cnt + 1;
          valid  <= '0;                                // March patterns overwrite the array
          if (mb_cnt >= MBIST_CYC) begin mb_busy <= 1'b0; mb_done <= 1'b1; mb_fail <= f_mbist_fail_i; end
        end
        if (!mbist_req_i) begin mb_done <= 1'b0; mb_fail <= 1'b0; end
      end
    end
    always @(negedge rail) begin init_busy <= 1'b0; init_done <= 1'b0; mb_busy <= 1'b0; mb_done <= 1'b0; end
  end
  assign mem_all_valid_o   = HAS_SRAM ? (&valid) : 1'b1;
  assign mem_ret_ack_o     = mret_ack;

  // TB backdoor write / check of the SRAM
  task automatic mem_fill(input logic [15:0] seed);
    for (int i = 0; i < MEM_WORDS; i++) begin mem[i] = seed ^ 16'(i); valid[i] = 1'b1; end
  endtask
  function automatic bit mem_check(input logic [15:0] seed);
    for (int i = 0; i < MEM_WORDS; i++) if (mem[i] !== (seed ^ 16'(i)) || !valid[i]) return 1'b0;
    return 1'b1;
  endfunction

  // ---------------------------------------------------------------- outputs through isolation
  logic [5:0] pm_raw, pm_iso;
  assign pm_raw = {busy_raw, qack_raw, abt_raw,
                   rail ? init_done : 1'bx, rail ? mb_done : 1'bx, rail ? mb_fail : 1'bx};
  sf_pd_boundary #(.W(6), .CLAMP(6'b010000)) u_pm_iso (.d_i(pm_raw), .iso_i(iso_pm_i), .q_o(pm_iso));
  assign {busy_o, q_ack_o, abort_ack_o, mem_reinit_done_o, mbist_done_o, mbist_fail_o} = pm_iso;

  logic [8:0] dat_raw, dat_iso;
  assign dat_raw = rail ? {running === 1'b1, plain_reg[7:0]} : 9'bx_xxxx_xxxx;
  sf_pd_boundary #(.W(9), .CLAMP(9'h000)) u_dat_iso (.d_i(dat_raw), .iso_i(iso_i), .q_o(dat_iso));
  assign {out_valid_o, out_data_o} = dat_iso;
endmodule
