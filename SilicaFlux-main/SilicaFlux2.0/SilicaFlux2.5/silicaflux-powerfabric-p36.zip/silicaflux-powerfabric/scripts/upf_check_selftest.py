#!/usr/bin/env python3
"""Mutation self-test of scripts/upf_check.py: each seeded defect in a copy of the FUTURE UPF must be caught."""
from __future__ import annotations

import re
import sys
import tempfile
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import upf_check as U  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    cfg = yaml.safe_load((ROOT / "config/power_regions.yaml").read_text())
    src = (ROOT / "upf/silicaflux_pf_future.upf").read_text()
    muts = {
        "isolation strategy of a switched domain removed": re.sub(r"set_isolation ISO_TNS[^\n]*\\\n[^\n]*\n", "", src),
        "isolation signal not declared": src.replace("-isolation_signal pd_iso_vec", "-isolation_signal pd_iso_vecX"),
        "power state references an undeclared supply set": src.replace("SS_TNS == OFF}}", "SS_FOO == OFF}}"),
        "power state references an undeclared state": src.replace("SS_VEC == OFF && SS_TNS == OFF", "SS_VEC == SLEEP && SS_TNS == OFF"),
        "switch output is not the domain primary supply": src.replace("-output_supply_port {vout VDD_TNS}", "-output_supply_port {vout VDD}"),
        "non-1801 command": src.replace("set_scope .", "set_scope .\nmake_it_low_power"),
        "supply set uses an undeclared net": src.replace("-function {power VDD_VEC}", "-function {power VDD_VECX}"),
        "domain primary supply set undeclared": src.replace("-supply {primary SS_TNS}", "-supply {primary SS_TNSX}"),
    }
    missed = 0
    with tempfile.TemporaryDirectory() as d:
        tmp = Path(d) / "mut.upf"
        for name, text in muts.items():
            assert text != src, f"mutation did not apply: {name}"
            tmp.write_text(text)
            rows, _ = U.check(tmp, None, cfg, "future")
            fails = [r["item"] for r in rows if r["status"] == "FAIL"]
            print(f"{'CAUGHT' if fails else 'MISSED'}  {name}" + (f"  ({fails[0]})" if fails else ""))
            missed += not fails
    print(f"upf_check self-test: {len(muts) - missed}/{len(muts)} seeded defects caught")
    return 1 if missed else 0


if __name__ == "__main__":
    sys.exit(main())
