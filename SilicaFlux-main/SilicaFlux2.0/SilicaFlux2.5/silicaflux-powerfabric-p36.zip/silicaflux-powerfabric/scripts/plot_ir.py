#!/usr/bin/env python3
"""IR-drop maps (Metal1 rail nodes, 'mixed' scenario, VDD) for the PDN variants, side by side."""
from __future__ import annotations

import csv
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main(run_root: str) -> int:
    variants = ["powerfabric", "floorplanlab"]
    data = {v: np.load(ROOT / f"reports/pi/{v}/mixed_VDD_drop.npy") for v in variants}
    vmax = max(d[d[:, 2] == 1, 3].max() for d in data.values()) * 1e3
    fig, axs = plt.subplots(1, 2, figsize=(12, 5.6), constrained_layout=True)
    for ax, v in zip(axs, variants):
        d = data[v]; m = d[:, 2] == 1
        sc = ax.scatter(d[m, 0], d[m, 1], c=d[m, 3] * 1e3, s=0.6, cmap="viridis", vmin=0, vmax=vmax, rasterized=True)
        rows = list(csv.DictReader(open(Path(run_root) / v / "instances_ref.csv")))
        for r in rows:
            if r["kind"] == "macro":
                x, y, w, h = (float(r[k]) for k in ("x_um", "y_um", "w_um", "h_um"))
                ax.add_patch(plt.Rectangle((x - w / 2, y - h / 2), w, h, fill=False, ec="#d0d0d0", lw=0.6))
        b = [r for r in csv.DictReader(open(ROOT / f"physical/bumps_{v}.csv")) if r["net"] == "VDD"]
        ax.plot([float(r["x_um"]) for r in b], [float(r["y_um"]) for r in b], "o", ms=3.5, mfc="none", mec="#ff6060", mew=0.8)
        ax.set_title(f"{v}: VDD static IR drop, 'mixed' (max {d[m, 3].max() * 1e3:.2f} mV)", fontsize=10)
        ax.set_aspect("equal"); ax.set_xlabel("x (um)"); ax.set_ylabel("y (um)")
    cb = fig.colorbar(sc, ax=axs, shrink=0.85)
    cb.set_label("IR drop at Metal1 rail nodes (mV)")
    fig.suptitle("sfv_soc_df on IHP SG13G2 - grey: SRAM macros, red circles: VDD C4 bumps (PackageTwin)", fontsize=10)
    out = ROOT / "reports/pi/ir_map_mixed_vdd.png"
    fig.savefig(out, dpi=130)
    print("wrote", out)
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
