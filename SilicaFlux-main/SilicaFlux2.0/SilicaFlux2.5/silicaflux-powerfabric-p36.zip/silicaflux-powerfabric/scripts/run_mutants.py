#!/usr/bin/env python3
"""RTL mutation testing: each mutant is ONE deliberate design defect in a copy of rtl/; the regression
(FUTURE build first, then BASE) must FAIL on it ("killed").  Writes reports/rtl/mutation.md."""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
F = "sf_pd_region_fsm.sv"
T = "silicaflux_power_domain.sv"
MUTANTS = [
    ("M01", "drain ignores outstanding DMA writes", F,
     "assign drained = q_ack && !busy && !dma_wr_pend_i && !acc_op_pend_i;", "assign drained = q_ack && !busy && !acc_op_pend_i;"),
    ("M02", "drain ignores outstanding accelerator ops", F,
     "assign drained = q_ack && !busy && !dma_wr_pend_i && !acc_op_pend_i;", "assign drained = q_ack && !busy && !dma_wr_pend_i;"),
    ("M03", "abort used without the explicit abort policy", F,
     "if (tgt_q == T_OFF && abort_ok_q) begin", "if (tgt_q == T_OFF) begin"),
    ("M04", "power-up does not wait for power-good", F,
     "if (pgood_i && stab_q >= cfg_i.pgood_stable) begin", "if (1'b1) begin"),
    ("M05", "data isolation released during RESTORE", F,
     "                      c_iso   = 1'b1;\n                      c_clk   = (sub_d != R_CSTOP);", "                      c_iso   = (sub_d < R_PMISO);\n                      c_clk   = (sub_d != R_CSTOP);"),
    ("M06", "switch opened together with PM isolation / reset", F,
     "c_pwr = (sub_d == 4'd0);", "c_pwr = 1'b0;"),
    ("M07", "power-good loss not supervised", F,
     "if (need_power && !pgood_i && state_d != S_FAULT) begin", "if (1'b0 && need_power && !pgood_i && state_d != S_FAULT) begin"),
    ("M08", "dependency (users still active) ignored when leaving ACTIVE", F,
     "else if (leaving && !dep_leave_ok_i)", "else if (1'b0)"),
    ("M09", "wake allowed during thermal hold", F,
     "else if (cmd_tgt_i == T_ACTIVE && therm_hold_i && state_q != S_ACTIVE)", "else if (1'b0)"),
    ("M10", "clock stop does not wait for the gate acknowledge", F,
     "S_CLK_STOP: begin\n        if (!clk_ack_i) begin", "S_CLK_STOP: begin\n        if (1'b1) begin"),
    ("M11", "inrush arbiter grants every requester", T,
     "if (!any_pwrup) begin\n      if (|pwrup_ready) begin", "pwrup_grant = pwrup_req; if (1'b0) begin\n      if (|pwrup_ready) begin"),
    ("M21", "power-up arbiter ignores dependencies (boot order by index)", T,
     "if (DEP[r*NR + t] && (pwrup_req[t] || ramping[t])) pwrup_ready[r] = 1'b0;", "if (1'b0) pwrup_ready[r] = 1'b0;"),
    ("M22", "user releases quiesce before its providers are ACTIVE", F,
     "end else if (dep_enter_ok_i) begin\n            state_d = S_RESUME;", "end else if (1'b1) begin\n            state_d = S_RESUME;"),
    ("M24", "region restarted from FAULT while its users are in use", F,
     "(state_q == S_IDLE && cmd_tgt_i == T_OFF) ||\n               (state_q == S_FAULT);", "(state_q == S_IDLE && cmd_tgt_i == T_OFF);"),
    ("M23", "thermal auto-restore not deferred while a request is accepted", F,
     "trest_q && dep_enter_ok_i && !auto_block_i) begin", "trest_q && dep_enter_ok_i) begin"),
    ("M12", "SRAM re-initialisation not awaited", F,
     "R_INIT:  if (reinit_done) begin", "R_INIT:  if (1'b1) begin"),
    ("M13", "retention restore skipped", F,
     "sub_d = ret_f_q ? R_CSTOP : R_PMISO;", "sub_d = R_PMISO;"),
    ("M14", "MUST_RETAIN memory powered off without retention / loss acceptance", F,
     "!cmd_retain_i && !cmd_allow_loss_i)", "1'b0)"),
    ("M15", "stale / unsolicited quiesce ack not detected", F,
     "if (q_ack || abort_ack) err_set[ERR_PROTOCOL] = 1'b1;", "if (1'b0) err_set[ERR_PROTOCOL] = 1'b1;"),
    ("M16", "power-good synchroniser resets to 0 (the defect found during development)", T,
     "sf_pd_sync #(.W(NR), .RV('1)) u_sync_pg", "sf_pd_sync #(.W(NR), .RV('0)) u_sync_pg"),
    ("M17", "FAULT does not hold a switchable region isolated", F,
     "if (SWITCHABLE) begin c_iso = 1'b1; c_isopm = 1'b1; c_rst = 1'b1; c_pwr = 1'b0; end",
     "if (SWITCHABLE) begin c_iso = 1'b0; c_isopm = 1'b1; c_rst = 1'b1; c_pwr = 1'b0; end"),
    ("M18", "quiesce timeout not bounded (waits forever)", F,
     "end else if (tmo_q) begin\n          err_set[ERR_QUIESCE_TO] = 1'b1;\n          if (tgt_q == T_OFF",
     "end else if (1'b0) begin\n          err_set[ERR_QUIESCE_TO] = 1'b1;\n          if (tgt_q == T_OFF"),
    ("M19", "SRAM contents not invalidated before power removal", F,
     "c_minv = (sub_d == 4'd2) && HAS_SRAM && !mret_f_d;", "c_minv = 1'b0;"),
    ("M20", "unsupported OFF accepted on a non-switchable region", F,
     "else if (cmd_tgt_i == T_OFF && !SWITCHABLE)                  rsp = E_REJ_UNSUPPORTED;", ""),
]
SRC = ["rtl/sf_pd_pkg.sv", "rtl/sf_pd_prims.sv", "rtl/sf_pd_boundary.sv", "rtl/sf_pd_region_fsm.sv",
       "rtl/silicaflux_power_domain.sv", "sim/sf_pd_region_model.sv", "tb/tb_power_domain.sv"]


def run(d: Path, future: bool) -> tuple[bool, str]:
    exe = d / ("f.vvp" if future else "b.vvp")
    cmd = ["iverilog", "-g2012", "-o", str(exe), "-s", "tb_power_domain"] + (["-DFUTURE"] if future else []) + [str(d / s) for s in SRC]
    c = subprocess.run(cmd, capture_output=True, text=True)
    if c.returncode:
        return True, "compile error"
    try:
        r = subprocess.run(["vvp", "-n", str(exe), "+TEST=all", "+SEED=1", "+CYCLES=8000"], capture_output=True, text=True, timeout=600)
        out = r.stdout
    except subprocess.TimeoutExpired:
        return True, "hang (killed by timeout)"
    res = [l for l in out.splitlines() if l.startswith("RESULT")]
    fails = [l for l in out.splitlines() if l.startswith("FAIL")]
    killed = not res or "PASS" not in res[-1]
    return killed, (fails[0][:110] if fails else (res[-1] if res else "no result"))


def main() -> int:
    rows, survived = [], 0
    for mid, desc, f, old, new in MUTANTS:
        with tempfile.TemporaryDirectory() as td:
            d = Path(td)
            for s in SRC:
                (d / s).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(ROOT / s, d / s)
            p = d / "rtl" / f
            txt = p.read_text()
            if txt.count(old) != 1:
                rows.append((mid, desc, "NOT APPLIED", f"pattern found {txt.count(old)} times")); survived += 1; continue
            p.write_text(txt.replace(old, new))
            killed, why = run(d, True)
            build = "FUTURE"
            if not killed:
                killed, why = run(d, False); build = "BASE"
            rows.append((mid, desc, "KILLED" if killed else "SURVIVED", f"{build}: {why}"))
            survived += not killed
            print(f"{mid} {rows[-1][2]:9s} {desc}")
    md = ["# RTL mutation testing", "", "Each mutant is one deliberate defect in a copy of `rtl/`; the full regression (FUTURE build, "
          "then BASE) must fail.  `scripts/run_mutants.py`.", "", "| Id | Defect | Result | First failure |", "|---|---|---|---|"]
    md += [f"| {a} | {b} | {c} | `{e}` |" for a, b, c, e in rows]
    md += ["", f"**{len(rows) - survived}/{len(rows)} killed.**"]
    out = ROOT / "reports/rtl"; out.mkdir(parents=True, exist_ok=True)
    (out / "mutation.md").write_text("\n".join(md) + "\n")
    print(f"mutation: {len(rows) - survived}/{len(rows)} killed")
    return 1 if survived else 0


if __name__ == "__main__":
    sys.exit(main())
