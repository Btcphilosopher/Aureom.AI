#!/usr/bin/env python3
"""Synthesis and elaboration checks for silicaflux_power_domain -> reports/rtl/synthesis.md

  S1 Yosys (ORFS 0.38) generic synthesis, BASELINE parameters: no latches, cell statistics
     (apt Yosys 0.33 cannot parse a packed array of a package struct in a port list)
  S2 Yosys (ORFS 0.38) mapped to the IHP SG13G2 typ Liberty: no latches, cell area (um2)
  S3 FUTURE parameters, simulation build (ASIC_IMPL=0): elaborates (switchable regions are legal in simulation)
  S4 sf_pd_icg with SF_PD_IHP_ICG: maps to the real IHP clock gate sg13g2_slgcp_1
  N1 ASIC_IMPL=1 + CAP_SWITCH != 0  -> must FAIL to elaborate (Yosys and Verilator)
  N2 ASIC_IMPL=1 + CAP_LOGIC_RET != 0 -> must FAIL
  N3 sf_pd_boundary with ALLOW_FUNCTIONAL=0 (no tech isolation cells) -> must FAIL
  P1 ASIC_IMPL=1 BASELINE -> must elaborate
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTL = ["rtl/sf_pd_pkg.sv", "rtl/sf_pd_prims.sv", "rtl/sf_pd_boundary.sv", "rtl/sf_pd_region_fsm.sv", "rtl/silicaflux_power_domain.sv"]
# Yosys reads the mechanically qualified copy (scripts/yosys_prep.py; regression-checked); Verilator reads rtl/
YRTL = [f.replace("rtl/", "build/yosys/") for f in RTL]
LIB = os.path.expandvars("${ORFS_FLOW}/platforms/ihp-sg13g2/lib/sg13g2_stdcell_typ_1p20V_25C.lib")
YOSYS_ORFS = os.environ.get("YOSYS_EXE", "/opt/eda/env/bin/yosys")
FUT = "-chparam CAP_SWITCH 7'b0000110 -chparam CAP_SRAM 7'b0001010 -chparam CAP_MBIST_PWRUP 7'b0000010 -chparam CAP_ABORT 7'b0000110"


def ys(script: str, exe=YOSYS_ORFS):
    r = subprocess.run([exe, "-q", "-p", script], capture_output=True, text=True, cwd=ROOT)
    return r.returncode, r.stdout + r.stderr


def vl(params: list[str], top="silicaflux_power_domain", files=RTL):
    r = subprocess.run(["verilator", "--lint-only", "-Wall", "-sv", "--top-module", top] + params + files,
                       capture_output=True, text=True, cwd=ROOT)
    return r.returncode, r.stdout + r.stderr


def main() -> int:
    rows, ok_all = [], True
    subprocess.run([sys.executable, str(ROOT / "scripts/yosys_prep.py")], check=True, capture_output=True)
    rd = " ".join(f"read_verilog -sv {f};" for f in YRTL)

    def add(cid, what, ok, detail):
        nonlocal ok_all
        ok_all &= ok
        rows.append((cid, what, "PASS" if ok else "FAIL", detail))

    # S1 generic
    rc, out = ys(f"{rd} hierarchy -top silicaflux_power_domain; synth -top silicaflux_power_domain -flatten; "
                 f"select -assert-none t:$dlatch t:$_DLATCH_* t:$_SR_*; tee -o build/synth_generic_stat.txt stat")
    stat = (ROOT / "build/synth_generic_stat.txt").read_text() if rc == 0 else out
    cells = re.search(r"Number of cells:\s+(\d+)", stat)
    ffs = sum(int(n) for n in re.findall(r"\$_DFF\w*_\s+(\d+)", stat)) if rc == 0 else 0
    add("S1", "Yosys 0.38 (ORFS) generic synthesis, baseline, latch-free", rc == 0, f"cells {cells.group(1) if cells else '?'}, flip-flops {ffs}" if rc == 0 else out[-300:])
    # S2 IHP mapped
    rc, out = ys(f"{rd} hierarchy -top silicaflux_power_domain; synth -top silicaflux_power_domain -flatten; "
                 f"dfflibmap -liberty {LIB}; abc -liberty {LIB}; opt_clean; "
                 f"select -assert-none t:$dlatch t:$_DLATCH_*; tee -o build/synth_ihp_stat.txt stat -liberty {LIB}", exe=YOSYS_ORFS)
    st = (ROOT / "build/synth_ihp_stat.txt").read_text() if rc == 0 else out
    area = re.search(r"Chip area for (?:top )?module '\\?silicaflux_power_domain'?:\s+([\d.]+)", st)
    ncell = re.search(r"Number of cells:\s+(\d+)", st)
    add("S2", "IHP SG13G2 mapping (ORFS Yosys 0.38, typ Liberty), latch-free", rc == 0,
        f"{ncell.group(1) if ncell else '?'} cells, {area.group(1) if area else '?'} um2 (pre-placement, std cells only)" if rc == 0 else out[-300:])
    # S3 future in simulation
    rc, out = ys(f"{rd} hierarchy -top silicaflux_power_domain {FUT}; synth -top silicaflux_power_domain -flatten; "
                 f"select -assert-none t:$dlatch t:$_DLATCH_* t:$_SR_*; tee -o build/synth_future_stat.txt stat")
    fs = (ROOT / "build/synth_future_stat.txt").read_text() if rc == 0 else ""
    fc = re.search(r"Number of cells:\s+(\d+)", fs)
    add("S3", "FUTURE parameters (CAP_SWITCH VEC/TNS) synthesise latch-free with ASIC_IMPL=0", rc == 0,
        f"cells {fc.group(1) if fc else '?'} (simulation configuration; refused with ASIC_IMPL=1, see N1)" if rc == 0 else out[-300:])
    # S4 ICG mapping
    rc, out = ys(f"read_liberty -lib {LIB}; read_verilog -sv -DSF_PD_IHP_ICG build/yosys/sf_pd_prims.sv; hierarchy -top sf_pd_icg; synth -top sf_pd_icg; "
                 f"select -assert-count 1 t:sg13g2_slgcp_1; select -assert-none t:$dlatch t:$_DLATCH_*", exe=YOSYS_ORFS)
    add("S4", "sf_pd_icg (SF_PD_IHP_ICG) maps to the IHP clock gate sg13g2_slgcp_1", rc == 0, "1 x sg13g2_slgcp_1, no latch" if rc == 0 else out[-300:])
    # negative / positive elaboration
    for cid, what, chp, vparams, must_fail in [
        ("N1", "ASIC_IMPL=1 with switchable regions is refused", "-chparam ASIC_IMPL 1 -chparam CAP_SWITCH 7'b0000110",
         ["-GASIC_IMPL=1'b1", "-GCAP_SWITCH=7'b0000110"], "CAP_SWITCH needs power-switch"),
        ("N2", "ASIC_IMPL=1 with logic retention is refused", "-chparam ASIC_IMPL 1 -chparam CAP_SWITCH 7'b0000100 -chparam CAP_LOGIC_RET 7'b0000100 -chparam TECH_SWITCH_CELLS 1 -chparam TECH_ISO_CELLS 1",
         ["-GASIC_IMPL=1'b1", "-GCAP_SWITCH=7'b0000100", "-GCAP_LOGIC_RET=7'b0000100", "-GTECH_SWITCH_CELLS=1'b1", "-GTECH_ISO_CELLS=1'b1"], "CAP_LOGIC_RET needs retention cells"),
        ("P1", "ASIC_IMPL=1 baseline elaborates", "-chparam ASIC_IMPL 1", ["-GASIC_IMPL=1'b1"], None)]:
        rc_y, out_y = ys(f"{rd} hierarchy -top silicaflux_power_domain {chp}")
        rc_v, out_v = vl(vparams)
        # a refusal only counts if it is OUR guard that fired (message match), not any other error
        ok = (rc_y != 0 and rc_v != 0 and must_fail in out_y and must_fail in out_v) if must_fail else (rc_y == 0 and rc_v == 0)
        msg = (re.search(r"ERROR: (.*)", out_y) or re.search(r"(.{0,90})$", out_y)).group(1)[:140] if must_fail else ("Yosys and Verilator: elaborated" if ok else (out_y + out_v)[-200:])
        add(cid, what, ok, f"Yosys rc={rc_y}, Verilator rc={rc_v}: {msg}")
    rc_y, out_y = ys("read_verilog -sv build/yosys/sf_pd_boundary.sv; hierarchy -top sf_pd_boundary -chparam ALLOW_FUNCTIONAL 0")
    rc_v, out_v = vl(["-GALLOW_FUNCTIONAL=1'b0"], top="sf_pd_boundary", files=["rtl/sf_pd_boundary.sv"])
    m = re.search(r"ERROR: (.*)", out_y)
    key = "functional isolation model used where a physical isolation cell is required"
    add("N3", "functional isolation model refused where a physical cell is required", rc_y != 0 and rc_v != 0 and key in out_y and key in out_v,
        f"Yosys rc={rc_y}, Verilator rc={rc_v}: {m.group(1)[:120] if m else ''}")
    md = ["# Synthesis and elaboration checks", "", "`scripts/run_synth.py`.  Pre-placement numbers only; no timing is claimed.", "",
          "| Id | Check | Result | Detail |", "|---|---|---|---|"] + [f"| {a} | {b} | {c} | {d} |" for a, b, c, d in rows]
    md += ["", f"**{sum(r[2] == 'PASS' for r in rows)}/{len(rows)} PASS.**"]
    (ROOT / "reports/rtl").mkdir(parents=True, exist_ok=True)
    (ROOT / "reports/rtl/synthesis.md").write_text("\n".join(md) + "\n")
    for r in rows:
        print(" | ".join(r))
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
