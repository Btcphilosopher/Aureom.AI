"""Minimal, dependency-free LEF readers for POWERFABRIC (text parsing only; nothing is executed).

parse_tech_lef(path)   -> {"grid": float, "layers": {name: {...}}, "order": [names], "sites": {...}}
parse_macro_lef(path)  -> {name: {"size": (w,h), "class": str, "pins": {pin: {"use", "direction", "rects": [(layer,x0,y0,x1,y1)]}},
                                  "obs_layers": [...]}}
Only the statements POWERFABRIC needs are interpreted; everything else is skipped.
"""
from __future__ import annotations

import re
from pathlib import Path


def _tokens(text: str):
    text = re.sub(r"#[^\n]*", "", text)
    return text.replace(";", " ; ").split()


def parse_tech_lef(path: str | Path) -> dict:
    tok = _tokens(Path(path).read_text())
    out = {"grid": None, "layers": {}, "order": [], "sites": {}, "dbu": None}
    i = 0
    n = len(tok)
    while i < n:
        t = tok[i]
        if t == "MANUFACTURINGGRID":
            out["grid"] = float(tok[i + 1]); i += 3; continue
        if t == "DATABASE" and tok[i + 1] == "MICRONS":
            out["dbu"] = int(tok[i + 2]); i += 4; continue
        if t == "SITE":
            name = tok[i + 1]; j = i + 2; site = {}
            while not (tok[j] == "END" and tok[j + 1] == name):
                if tok[j] == "SIZE":
                    site["size"] = (float(tok[j + 1]), float(tok[j + 3])); j += 5; continue
                j += 1
            out["sites"][name] = site; i = j + 2; continue
        if t == "PROPERTYDEFINITIONS":
            while not (tok[i] == "END" and tok[i + 1] == "PROPERTYDEFINITIONS"): i += 1
            i += 2; continue
        if t == "MACRO":
            break                                   # tech section ends where cells begin
        if t == "LAYER" and i + 1 < n and tok[i + 2] != ";" and tok[i + 1] not in ("contactLimit", "routingPitch", "routingGrid"):
            name = tok[i + 1]; j = i + 2; L = {"name": name}
            while not (tok[j] == "END" and tok[j + 1] == name):
                k = tok[j]
                if k == "TYPE": L["type"] = tok[j + 1]; j += 3; continue
                if k == "DIRECTION": L["direction"] = tok[j + 1]; j += 3; continue
                if k in ("MINIMUMCUT", "ENCLOSURE", "ANTENNACUMDIFFAREARATIO", "ANTENNADIFFAREARATIO", "AREA", "MINENCLOSEDAREA"):
                    while tok[j] != ";": j += 1           # skip the whole statement
                    j += 1; continue
                if k in ("WIDTH", "MAXWIDTH", "PITCH", "OFFSET", "THICKNESS", "MINIMUMDENSITY", "MAXIMUMDENSITY", "HEIGHT") and tok[j + 2] == ";":
                    L.setdefault(k.lower(), float(tok[j + 1])); j += 3; continue
                if k == "SPACING" and tok[j + 2] == ";" and "spacing" not in L:
                    L["spacing"] = float(tok[j + 1]); j += 3; continue
                if k == "SPACINGTABLE":
                    # PARALLELRUNLENGTH p0 p1 ... WIDTH w0 s.. WIDTH w1 s.. ;
                    j += 2  # SPACINGTABLE PARALLELRUNLENGTH
                    prl = []
                    while tok[j] != "WIDTH":
                        prl.append(float(tok[j])); j += 1
                    rows = []
                    while tok[j] == "WIDTH":
                        w = float(tok[j + 1]); s = [float(x) for x in tok[j + 2:j + 2 + len(prl)]]
                        rows.append((w, s)); j += 2 + len(prl)
                    L["spacing_table"] = {"prl": prl, "rows": rows}
                    if tok[j] == ";": j += 1
                    continue
                if k == "RESISTANCE" and tok[j + 1] == "RPERSQ":
                    L["rpersq"] = float(tok[j + 2]); j += 4; continue
                if k == "RESISTANCE" and tok[j + 2] == ";":
                    L["r_cut"] = float(tok[j + 1]); j += 3; continue
                if k == "DCCURRENTDENSITY" and tok[j + 1] == "AVERAGE":
                    L["jdc_avg"] = float(tok[j + 2]); j += 4; continue
                j += 1
            out["layers"][name] = L; out["order"].append(name); i = j + 2; continue
        i += 1
    return out


def min_spacing(layer: dict, width: float, prl: float = 1e9) -> float:
    """Required same-layer spacing for a wire of `width` running in parallel for `prl` (LEF SPACINGTABLE)."""
    st = layer.get("spacing_table")
    if not st:
        return layer.get("spacing", 0.0)
    col = max(i for i, p in enumerate(st["prl"]) if prl >= p)
    req = 0.0
    for w, s in st["rows"]:
        if width >= w:
            req = s[col]
    return req


def parse_macro_lef(path: str | Path) -> dict:
    tok = _tokens(Path(path).read_text())
    macros = {}
    i, n = 0, len(tok)
    while i < n:
        if tok[i] == "PROPERTYDEFINITIONS":
            while not (tok[i] == "END" and tok[i + 1] == "PROPERTYDEFINITIONS"): i += 1
            i += 2; continue
        if tok[i] == "MACRO":
            name = tok[i + 1]; j = i + 2
            M = {"pins": {}, "obs_layers": [], "class": None, "size": None}
            while not (tok[j] == "END" and tok[j + 1] == name):
                if tok[j] == "CLASS": M["class"] = tok[j + 1]; j += 2; continue
                if tok[j] == "SIZE": M["size"] = (float(tok[j + 1]), float(tok[j + 3])); j += 5; continue
                if tok[j] == "PIN":
                    pin = tok[j + 1]; k = j + 2; P = {"use": "SIGNAL", "direction": None, "rects": []}; layer = None
                    while not (tok[k] == "END" and tok[k + 1] == pin):
                        if tok[k] == "USE": P["use"] = tok[k + 1]
                        elif tok[k] == "DIRECTION": P["direction"] = tok[k + 1]
                        elif tok[k] == "LAYER": layer = tok[k + 1]
                        elif tok[k] == "RECT":
                            P["rects"].append((layer, *map(float, tok[k + 1:k + 5]))); k += 5; continue
                        k += 1
                    M["pins"][pin] = P; j = k + 2; continue
                if tok[j] == "OBS":
                    k = j + 1
                    while tok[k] != "END":
                        if tok[k] == "LAYER" and tok[k + 1] not in M["obs_layers"]:
                            M["obs_layers"].append(tok[k + 1])
                        k += 1
                    j = k + 1; continue
                j += 1
            macros[name] = M; i = j + 2; continue
        i += 1
    return macros
