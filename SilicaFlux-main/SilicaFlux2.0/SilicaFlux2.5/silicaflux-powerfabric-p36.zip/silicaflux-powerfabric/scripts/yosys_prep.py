#!/usr/bin/env python3
"""Make a Yosys-readable copy of the RTL in build/yosys/ (mechanical, no hand edits).

Yosys' built-in SystemVerilog frontend (0.33 and ORFS 0.38) has no `import` and mis-resolves enum constants
referenced inside package functions.  This script:
  * copies sf_pd_pkg.sv without its functions,
  * removes `import sf_pd_pkg::*;` from the modules and qualifies every package identifier (sf_pd_pkg::X),
  * inlines the package functions into each module that uses them (qualified the same way).
The transformed files are simulated with the full regression (scripts/regress.py --prepped) to show they
behave identically to the source.
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "build/yosys"


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    pkg = (ROOT / "rtl/sf_pd_pkg.sv").read_text()
    funcs = re.findall(r"(  function automatic .*?endfunction\n)", pkg, re.S)
    fnames = [re.search(r"function automatic \S+ (\w+)\(", f).group(1) for f in funcs]
    ids = set(re.findall(r"localparam int (\w+)", pkg))
    ids |= set(re.findall(r"\}\s*(\w+)\s*;", pkg))                       # typedef names
    for body in re.findall(r"typedef enum[^{]*\{(.*?)\}", pkg, re.S):
        ids |= set(re.findall(r"\b([A-Z]_[A-Z_0-9]+)\s*=", body))
    ids |= set(fnames)
    pat = re.compile(r"(?<![\w:.'$`])(" + "|".join(sorted(ids, key=len, reverse=True)) + r")\b")
    nopkg = pkg
    for f in funcs:
        nopkg = nopkg.replace(f, "")
    (OUT / "sf_pd_pkg.sv").write_text(nopkg)

    def qualify(text: str) -> str:
        out = []
        for line in text.splitlines(keepends=True):
            code, sep, com = line.partition("//")
            out.append(pat.sub(r"sf_pd_pkg::\1", code) + sep + com)
        return "".join(out)
    local_funcs = qualify("".join(funcs)).replace("sf_pd_pkg::arch_of", "arch_of").replace("sf_pd_pkg::in_use", "in_use")
    for f in ("sf_pd_region_fsm.sv", "silicaflux_power_domain.sv"):
        s = (ROOT / "rtl" / f).read_text()
        s = s.replace("  import sf_pd_pkg::*;\n", "")
        s = qualify(s)
        for fn in fnames:                                                   # call the module-local copy
            s = s.replace(f"sf_pd_pkg::{fn}(", f"{fn}(")
        used = [fn for fn in fnames if re.search(rf"\b{fn}\(", s)]
        if used:
            m = re.search(r"\n\);\n", s)                                    # end of the port list
            s = s[:m.end()] + "  // package functions, inlined by scripts/yosys_prep.py\n" + local_funcs + s[m.end():]
        (OUT / f).write_text(s)
    for f in ("sf_pd_prims.sv", "sf_pd_boundary.sv"):
        (OUT / f).write_text((ROOT / "rtl" / f).read_text())
    print(f"yosys_prep: {len(ids)} package identifiers qualified, functions inlined: {fnames} -> {OUT}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
