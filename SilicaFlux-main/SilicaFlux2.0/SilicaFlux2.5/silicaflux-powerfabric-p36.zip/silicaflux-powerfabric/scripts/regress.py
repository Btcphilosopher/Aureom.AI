#!/usr/bin/env python3
"""Full RTL regression -> reports/rtl/regression.md (+ logs in build/logs).

  * Verilator -Wall lint: baseline and FUTURE parameter sets
  * every test individually, BASE and FUTURE builds, Icarus 12 and Verilator 5 (seed 1)
  * the whole suite (incl. the random test) with seeds 1..N on both simulators and builds
  * the Yosys-prepped RTL (build/yosys, scripts/yosys_prep.py) through the same suite on Icarus
"""
from __future__ import annotations

import argparse
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTL = ["rtl/sf_pd_pkg.sv", "rtl/sf_pd_prims.sv", "rtl/sf_pd_boundary.sv", "rtl/sf_pd_region_fsm.sv", "rtl/silicaflux_power_domain.sv"]
TB = ["sim/sf_pd_region_model.sv", "tb/tb_power_domain.sv"]
BASE_TESTS = ["reset_defaults", "active_idle_active", "quiesce", "busy_reject", "dependency", "thermal",
              "reset_mid_transition", "control_timeout", "random"]
FUT_TESTS = BASE_TESTS[:-1] + ["isolation_sequencing", "abort_policy", "missing_power_good", "memory_retention",
                               "sram_faults", "inrush", "boot_order", "provider_fault", "random"]
BRIEF = {"reset_defaults": "unsupported / illegal requests", "active_idle_active": "idle-to-active, active-to-idle",
         "quiesce": "quiesce (drain of running work and in-flight DMA writes; stale ack)",
         "busy_reject": "busy-domain shutdown rejection", "dependency": "dependency ordering",
         "thermal": "thermal throttling request", "reset_mid_transition": "reset during transition",
         "control_timeout": "control timeout (clock ack, resume ack), supply power-good",
         "isolation_sequencing": "isolation sequencing (full OFF / ON order trace)", "abort_policy": "explicit abort policy + fence",
         "missing_power_good": "missing / stuck / lost power-good", "memory_retention": "memory retention protocol (logic + SRAM)",
         "sram_faults": "MBIST failure, re-init timeout", "inrush": "one supply ramp at a time", "boot_order": "providers ramp before their users after reset",
         "provider_fault": "faulted provider not restarted while its users are in use", "random": "random stress + invariants"}
LOGS = ROOT / "build/logs"


def sh(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT, **kw)


def result(out: str):
    m = re.search(r"RESULT: (\w+) .*checks=(\d+) errors=(\d+)", out)
    return (m.group(1), int(m.group(2)), int(m.group(3))) if m else ("NO-RESULT", 0, 0)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", type=int, default=3)
    ap.add_argument("--sweep", type=int, default=50)
    a = ap.parse_args()
    LOGS.mkdir(parents=True, exist_ok=True)
    (ROOT / "build").mkdir(exist_ok=True)
    md, bad = ["# RTL regression", ""], 0

    # lint
    md += ["## Lint (Verilator 5.020 -Wall)", "", "| Configuration | Result |", "|---|---|"]
    for name, extra in [("baseline", []), ("FUTURE (VEC/TNS/SRAM switchable)", ["-GCAP_SWITCH=7'b0001110", "-GCAP_SRAM=7'b0001010",
                         "-GCAP_SRAM_RET=7'b0001000", "-GCAP_LOGIC_RET=7'b0000100", "-GCAP_MBIST_PWRUP=7'b0000010", "-GCAP_ABORT=7'b0000110"])]:
        r = sh(["verilator", "--lint-only", "-Wall", "-sv", "--top-module", "silicaflux_power_domain"] + extra + RTL)
        ok = r.returncode == 0 and "%Warning" not in r.stderr
        bad += not ok
        md.append(f"| {name} | {'clean' if ok else 'FAIL: ' + r.stderr.splitlines()[0]} |")

    # builds
    subprocess.run([sys.executable, str(ROOT / "scripts/yosys_prep.py")], check=True, capture_output=True)
    prep = [f.replace("rtl/", "build/yosys/") for f in RTL]
    builds = {}
    for b, dfl in (("BASE", []), ("FUTURE", ["-DFUTURE"])):
        exe = f"build/tb_{b.lower()}.vvp"
        r = sh(["iverilog", "-g2012", "-o", exe, "-s", "tb_power_domain"] + dfl + RTL + TB)
        assert r.returncode == 0, r.stderr
        builds[("icarus", b)] = ["vvp", "-n", exe]
        exe = f"build/tb_{b.lower()}_prep.vvp"
        r = sh(["iverilog", "-g2012", "-o", exe, "-s", "tb_power_domain"] + dfl + prep + TB)
        assert r.returncode == 0, r.stderr
        builds[("icarus-prepped", b)] = ["vvp", "-n", exe]
        mdir = f"build/vl/{b.lower()}"
        r = sh(["verilator", "--binary", "--timing", "-j", "4", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-MULTIDRIVEN",
                "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "--top-module", "tb_power_domain", "-Mdir", mdir, "-o", "tb"] + dfl + RTL + TB)
        assert r.returncode == 0, r.stderr[-2000:]
        builds[("verilator", b)] = [f"{mdir}/tb"]

    # per-test table
    md += ["", "## Per test (seed 1)", "", "| Test | Brief item | Build | Icarus checks | Verilator checks | Result |", "|---|---|---|---|---|---|"]
    tot_runs = 0
    for b, tests in (("BASE", BASE_TESTS), ("FUTURE", FUT_TESTS)):
        for t in tests:
            res = {}
            for sim in ("icarus", "verilator"):
                r = sh(builds[(sim, b)] + [f"+TEST={t}", "+SEED=1"], timeout=1200)
                (LOGS / f"{sim}_{b}_{t}.log").write_text(r.stdout)
                res[sim] = result(r.stdout); tot_runs += 1
            ok = all(v[0] == "PASS" for v in res.values())
            bad += not ok
            md.append(f"| {t} | {BRIEF[t]} | {b} | {res['icarus'][1]} | {res['verilator'][1]} | {'PASS' if ok else 'FAIL'} |")

    # seeds
    md += ["", f"## Whole suite, seeds 1..{a.seeds}", "", "| Simulator | Build | Seed | Checks | Errors | Result |", "|---|---|---|---|---|---|"]
    for sim in ("icarus", "verilator", "icarus-prepped"):
        for b in ("BASE", "FUTURE"):
            for seed in range(1, a.seeds + 1):
                if sim == "icarus-prepped" and seed > 1:
                    continue
                r = sh(builds[(sim, b)] + ["+TEST=all", f"+SEED={seed}"], timeout=1800)
                (LOGS / f"{sim}_{b}_all_s{seed}.log").write_text(r.stdout)
                st, ch, er = result(r.stdout); tot_runs += 1
                bad += st != "PASS"
                md.append(f"| {sim} | {b} | {seed} | {ch} | {er} | {st} |")
    # random sweep (Verilator is fast): many independent stimulus streams through the invariant checker
    md += ["", f"## Random sweep, Verilator, seeds 1..{a.sweep} (test `random`, 20 000 cycles each)", "",
           "| Build | Runs | Failing seeds | Total checks |", "|---|---|---|---|"]
    for b in ("BASE", "FUTURE"):
        fails, tot_ch = [], 0
        for seed in range(1, a.sweep + 1):
            r = sh(builds[("verilator", b)] + ["+TEST=random", f"+SEED={seed}"], timeout=600)
            st, ch, er = result(r.stdout); tot_runs += 1; tot_ch += ch
            if st != "PASS":
                fails.append(seed); (LOGS / f"sweep_{b}_s{seed}.log").write_text(r.stdout)
        bad += len(fails)
        md.append(f"| {b} | {a.sweep} | {fails or 'none'} | {tot_ch} |")
    md += ["", f"**{tot_runs} simulation runs, {bad} failing items.**  `icarus-prepped` is the Yosys input "
           "(`build/yosys/`, generated by `scripts/yosys_prep.py`) run through the same suite: it is functionally the "
           "same design.  Icarus and Verilator agree on every verdict; check counts differ by one or two samples at the "
           "asynchronous-reset / `$finish` boundaries, and the random test's stimulus diverges because it samples state from a "
           "4-state (Icarus) vs a 2-state (Verilator) simulator.  X-propagation checks (isolation clamps, unpowered logic) are "
           "only meaningful on Icarus."]
    (ROOT / "reports/rtl").mkdir(parents=True, exist_ok=True)
    (ROOT / "reports/rtl/regression.md").write_text("\n".join(md) + "\n")
    print("\n".join(l for l in md if "FAIL" in l) or "no failures")
    print(f"regress: {tot_runs} runs, {bad} failing items")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
