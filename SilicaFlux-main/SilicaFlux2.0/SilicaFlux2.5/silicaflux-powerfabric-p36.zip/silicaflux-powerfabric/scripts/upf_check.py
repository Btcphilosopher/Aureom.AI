#!/usr/bin/env python3
"""Structural checker for the POWERFABRIC IEEE 1801 files + summary of the OpenROAD read_upf validation.

This is NOT a substitute for a commercial low-power checker (Synopsys VC LP, Cadence Conformal LP): it checks
command names, declaration-before-use of every referenced supply port / net / set, logic port, domain and
power state, required strategies (a switched domain must have isolation), element resolution in the real
netlist (taken from upf/validate_upf.tcl, which ran inside OpenROAD on the placed database), consistency of the
full files with their OpenROAD-loadable subsets, and consistency with config/power_regions.yaml.
Writes reports/upf/upf_validation.{md,json}; exit 1 on any FAIL.
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
UPF_2013 = {"upf_version", "set_design_top", "set_scope", "create_supply_port", "create_supply_net", "connect_supply_net",
            "create_supply_set", "create_power_domain", "add_power_state", "create_logic_port", "create_power_switch",
            "set_isolation", "set_level_shifter", "set_retention", "set_domain_supply_net", "map_power_switch",
            "use_interface_cell", "set_port_attributes", "create_pst", "add_pst_state", "load_upf", "set_design_attributes"}


def tcl_words(s: str):
    words, cur, depth = [], "", 0
    for ch in s:
        if ch == "{":
            depth += 1
            if depth == 1:
                continue
        elif ch == "}":
            depth -= 1
            if depth == 0:
                words.append(cur); cur = ""; continue
        if depth == 0 and ch.isspace():
            if cur:
                words.append(cur); cur = ""
            continue
        cur += ch
    if cur:
        words.append(cur)
    return words


def commands(path: Path):
    text = re.sub(r"\\\n", " ", path.read_text())
    out = []
    for ln, line in enumerate(text.splitlines(), 1):
        s = line.strip()
        if not s or s.startswith("#"):
            continue
        w = tcl_words(s)
        opts, pos, i = {}, [], 1
        while i < len(w):
            if w[i].startswith("-") and not re.match(r"^-\d", w[i]) and not re.search(r"\s", w[i]):   # braced words are positional
                key = w[i]
                if i + 1 < len(w) and not w[i + 1].startswith("-"):
                    opts.setdefault(key, []).append(w[i + 1]); i += 2
                else:
                    opts.setdefault(key, []).append(True); i += 1
            else:
                pos.append(w[i]); i += 1
        out.append({"line": ln, "cmd": w[0], "pos": pos, "opts": opts})
    return out


def check(full: Path, subset_json: Path | None, yaml_cfg: dict, kind: str):
    rows = []
    def add(item, ok, detail=""):
        rows.append({"file": full.name, "item": item, "status": "PASS" if ok else "FAIL", "detail": detail})
    cmds = commands(full)
    ports, nets, sets, doms, lports, states = set(), set(), {}, {}, set(), {}
    switched_nets, isolated, retained, switches = {}, set(), set(), []
    unknown = [c["cmd"] for c in cmds if c["cmd"] not in UPF_2013]
    add("all commands are IEEE 1801-2013 commands", not unknown, ", ".join(sorted(set(unknown))))
    for c in cmds:
        o, p, cmd = c["opts"], c["pos"], c["cmd"]
        where = f"line {c['line']}"
        if cmd == "create_supply_port":
            ports.add(p[0])
        elif cmd == "create_supply_net":
            nets.add(p[0])
        elif cmd == "connect_supply_net":
            add(f"{where}: connect_supply_net {p[0]}: net declared", p[0] in nets)
            for pt in o.get("-ports", []):
                add(f"{where}: port {pt} declared", pt in ports)
            if "-domain" in o:
                add(f"{where}: domain {o['-domain'][0]} declared", o["-domain"][0] in doms)
        elif cmd == "create_supply_set":
            fn = {}
            for f in o.get("-function", []):
                k, n = f.split()
                fn[k] = n
                add(f"{where}: supply set {p[0]} function {k} -> net {n} declared", n in nets)
            sets[p[0]] = fn
        elif cmd == "create_logic_port":
            lports.add(p[0])
        elif cmd == "create_power_domain":
            sup = {}
            for s in o.get("-supply", []):
                k, v = s.split()
                sup[k] = v
                add(f"{where}: domain {p[0]} supply {k} -> set {v} declared", v in sets)
            add(f"{where}: domain {p[0]} has a primary supply", "primary" in sup)
            doms[p[0]] = {"supply": sup, "elements": o.get("-elements", [""])[0].split() if "-elements" in o else [],
                          "scope": "-include_scope" in o}
        elif cmd == "create_power_switch":
            d = o["-domain"][0]
            add(f"{where}: switch {p[0]} domain {d} declared", d in doms)
            vin = o["-input_supply_port"][0].split(); vout = o["-output_supply_port"][0].split()
            add(f"{where}: switch {p[0]} input net {vin[1]} declared", vin[1] in nets)
            add(f"{where}: switch {p[0]} output net {vout[1]} declared", vout[1] in nets)
            ctrl = o["-control_port"][0].split()
            add(f"{where}: switch {p[0]} control {ctrl[1]} is a declared logic port", ctrl[1] in lports)
            for ack in o.get("-ack_port", []):
                add(f"{where}: switch {p[0]} ack {ack.split()[1]} is a declared logic port", ack.split()[1] in lports)
            on = o.get("-on_state", [""])[0].split()
            add(f"{where}: switch {p[0]} on_state uses its input port", len(on) >= 2 and on[1] == vin[0])
            switched_nets[vout[1]] = d
            switches.append(p[0])
        elif cmd == "set_isolation":
            d = o["-domain"][0]
            add(f"{where}: isolation {p[0]} domain declared", d in doms)
            add(f"{where}: isolation {p[0]} supply declared", o.get("-isolation_supply", ["?"])[0] in sets)
            add(f"{where}: isolation {p[0]} signal is a declared logic port", o.get("-isolation_signal", ["?"])[0] in lports)
            add(f"{where}: isolation {p[0]} clamp value legal", o.get("-clamp_value", ["?"])[0] in ("0", "1", "latch", "any", "Z"))
            isolated.add(d)
        elif cmd == "set_retention":
            d = o["-domain"][0]
            add(f"{where}: retention {p[0]} domain declared", d in doms)
            add(f"{where}: retention {p[0]} supply declared", o.get("-retention_supply", ["?"])[0] in sets)
            for k in ("-save_signal", "-restore_signal"):
                add(f"{where}: retention {p[0]} {k} declared", o.get(k, ["? x"])[0].split()[0] in lports)
            retained.add(d)
        elif cmd == "set_level_shifter":
            add(f"{where}: level shifter {p[0]} domain declared", o["-domain"][0] in doms)
        elif cmd == "add_power_state":
            obj = p[0]
            add(f"{where}: power state object {obj} declared", obj in sets or obj in doms)
            st = o.get("-state", [None])[0]
            # states are written as  -state NAME {expr}: the expression is the next positional word
            expr = " ".join(p[1:])
            for ref, sname in re.findall(r"(\w+)\s*==\s*(\w+)", expr):
                if ref in ("power", "ground"):
                    continue
                add(f"{where}: state {obj}.{st} references {ref}=={sname} (declared)", ref in sets and sname in states.get(ref, set()))
            states.setdefault(obj, set()).add(st)
    for net, d in switched_nets.items():
        prim = doms[d]["supply"].get("primary")
        add(f"switched domain {d}: primary supply is the switch output", prim in sets and sets[prim].get("power") == net)
        add(f"switched domain {d}: has an isolation strategy", d in isolated)
    vdd = yaml_cfg["technology"]["vdd_v"]["value"]
    vstr = re.findall(r"FULL_ON,\s*([\d.]+)", full.read_text())
    add("supply voltages equal config vdd_v", all(abs(float(v) - vdd) < 1e-9 for v in vstr if float(v) > 0), str(sorted(set(vstr))))
    if kind == "baseline":
        add("baseline: exactly one power domain", len(doms) == 1, str(list(doms)))
        add("baseline: no switch / isolation / retention", not switches and not isolated and not retained)
    else:
        want = {r["name"] for r in yaml_cfg["regions"] if r.get("future", {}).get("switchable") is True}
        have = {d[3:] for d in switched_nets.values()}
        add("future: switched domains == regions with future.switchable: true", want == have, f"yaml {sorted(want)} upf {sorted(have)}")
    if subset_json and subset_json.exists():
        sj = json.loads(subset_json.read_text())
        add("OpenROAD read_upf of the subset file", sj["read_upf_rc"] == 0, sj["read_upf_msg"])
        odoms = {d["name"]: [e["element"] for e in d["elements"]] for d in sj["domains"]}
        fdoms = {k: v["elements"] for k, v in doms.items()}
        add("subset domains/elements == full UPF domains/elements", odoms == fdoms, f"subset {odoms} full {fdoms}")
        for d in sj["domains"]:
            for e in d["elements"]:
                add(f"element {e['element']} exists in the netlist (dbModInst)", e["modinst_found"] == 1, f"{e['leaf_instances']} leaf instances")
        add("OpenROAD switches == full UPF switches", sorted(s["name"] for s in sj["switches"]) == sorted(switches))
        add("OpenROAD isolation strategies cover the same domains", len(sj["isolations"]) == len(isolated))
    return rows, {"domains": doms, "switches": switches, "isolated": sorted(isolated), "retained": sorted(retained)}


def main() -> int:
    cfg = yaml.safe_load((ROOT / "config/power_regions.yaml").read_text())
    vdir = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "reports/upf/openroad"
    allrows, info = [], {}
    for kind in ("baseline", "future"):
        r, i = check(ROOT / f"upf/silicaflux_pf_{kind}.upf", vdir / f"silicaflux_pf_{kind}.openroad.json", cfg, kind)
        allrows += r; info[kind] = i
    lib = json.loads((vdir / "silicaflux_pf_future.openroad.json").read_text())
    full_rc = {}
    for kind in ("baseline", "future"):
        j = vdir / f"silicaflux_pf_{kind}.json"
        if j.exists():
            full_rc[kind] = json.loads(j.read_text())["read_upf_msg"]
    out = ROOT / "reports/upf"; out.mkdir(parents=True, exist_ok=True)
    (out / "upf_validation.json").write_text(json.dumps({"rows": allrows, "info": info, "openroad_full_file_result": full_rc,
                                                         "library_scan": lib["liberty_scan"]}, indent=1, default=str))
    nf = sum(r["status"] == "FAIL" for r in allrows)
    md = ["# Power-intent (UPF) validation", "",
          "## What was run", "",
          "1. **OpenROAD 2.0-12331 `read_upf`** on the placed `sfv_soc_df` database (`upf/validate_upf.tcl`) for the two",
          "   `*.openroad.upf` subset files: objects read back from ODB, every `-elements` path resolved against the",
          "   design hierarchy (OpenROAD itself accepts a non-existent element silently - checked with a deliberately",
          "   bogus path), library searched for isolation / switch / level-shifter / retention cells.",
          "2. **The full IEEE 1801 files** were also given to OpenROAD: it rejects them at the first standard command",
          f"   it does not implement (`{full_rc.get('baseline', '?')}`).",
          "3. **`scripts/upf_check.py`**: structural checks of the full files (below).", "",
          "## Not available here (limitation)", "",
          "No commercial or open-source tool in this environment performs full 1801 semantic verification (supply-state",
          "reachability, isolation completeness on every domain-crossing net, retention coverage, power-state table",
          "legality).  Those checks are required before the FUTURE intent could be implemented, and it cannot be",
          "implemented on IHP SG13G2 anyway (library scan below).", "",
          "## Library scan (Liberty text, ORFS ab2aaf0f)", "",
          "| File | is_isolation_cell | switch_cell_type | is_level_shifter | retention_cell | always_on | pg_pin |", "|---|---|---|---|---|---|---|"]
    for s in lib["liberty_scan"]:
        md.append(f"| {s['file']} | {s['is_isolation_cell']} | {s['switch_cell_type']} | {s['is_level_shifter']} | {s['retention_cell']} | {s['always_on']} | {s['pg_pin']} |")
    md += ["", "## Structural checks", "", "| File | Check | Status | Detail |", "|---|---|---|---|"]
    md += [f"| {r['file']} | {r['item']} | {r['status']} | {r['detail']} |" for r in allrows]
    md += ["", f"**{len(allrows) - nf} PASS, {nf} FAIL.**"]
    (out / "upf_validation.md").write_text("\n".join(md) + "\n")
    print(f"upf_check: {len(allrows)} checks, {nf} FAIL")
    for r in allrows:
        if r["status"] == "FAIL":
            print("  FAIL", r["file"], r["item"], r["detail"])
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
