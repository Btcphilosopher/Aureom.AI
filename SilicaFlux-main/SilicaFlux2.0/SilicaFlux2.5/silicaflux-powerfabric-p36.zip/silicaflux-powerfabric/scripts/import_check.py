#!/usr/bin/env python3
"""PowerGrid integration check: feed the POWERFABRIC export to the importers of PackageTwin (Project 29) and
ThermalLab (Project 09/2.5) - their own code, unmodified - and record what they read.
Usage: import_check.py <export_dir> <packagetwin_root> <thermallab_root>  -> <export_dir>/../import_check.txt"""
import json
import subprocess
import sys
from pathlib import Path

ex, pt, tl = (Path(p).resolve() for p in sys.argv[1:4])
lines = [f"export: {ex}"]
r = subprocess.run([sys.executable, str(pt / "silicaflux_package_twin.py"), "powergrid-import", "--dir", str(ex)],
                   capture_output=True, text=True, cwd="/")
lines += ["== PackageTwin powergrid-import (rc %d)" % r.returncode, r.stdout.strip() or r.stderr.strip()[-500:]]
code = ("import sys; sys.path.insert(0, %r)\nfrom thermallab.powergrid_adapter import load_powergrid_export\n"
        "e = load_powergrid_export(%r)\nprint(len(e.nodes), len(e.segments), e.total_dissipation_w, e.total_load_power_w)") % (str(tl / "python"), str(ex))
r2 = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True, cwd="/")
lines += ["== ThermalLab powergrid_adapter.load_powergrid_export (rc %d)" % r2.returncode]
if r2.returncode == 0:
    n, s, d, p = r2.stdout.split()
    lines += [f"nodes {n}, segments {s}, grid dissipation {float(d):.4e} W, load power {float(p):.4e} W"]
else:
    lines += [r2.stderr[-500:]]
ok = r.returncode == 0 and r2.returncode == 0
lines.append(f"RESULT: {'PASS' if ok else 'FAIL'}")
out = ex.parent / "import_check.txt"
out.write_text("\n".join(lines) + "\n")
print("\n".join(lines))
sys.exit(0 if ok else 1)
