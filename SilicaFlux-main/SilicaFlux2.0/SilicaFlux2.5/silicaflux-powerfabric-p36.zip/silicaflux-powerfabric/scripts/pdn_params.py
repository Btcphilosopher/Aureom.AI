#!/usr/bin/env python3
"""Generate and VALIDATE OpenROAD pdngen parameters for POWERFABRIC.

Inputs : config/power_regions.yaml (pdn + package sections), the technology LEF, the standard-cell LEF,
         the SRAM macro LEFs, the die / core rectangle, and PackageTwin's bump_map() (package interface).
Outputs: physical/pdn_params_<variant>.tcl   (sourced by pdn/sf_pdn.tcl)
         reports/pdn/param_validation_<variant>.{json,md}
         physical/bumps_<variant>.csv          (C4 sites with nets, for PDNSim sources and checks)

Every rule below is read from the LEF files; nothing is hard-coded about the foundry process.
A FAIL makes the script exit non-zero and no parameter file is written.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import lef_tech  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]

# FloorplanLab A_baseline PDN (platforms/ihp_sg13g2/profile.yaml, reproduced for comparison)
FLOORPLANLAB = {
    "rails": {"layer": "Metal1", "width": 0.44, "pitch": 7.56},
    "straps": [{"layer": "Metal5", "width": 2.2, "pitch": 75.6, "offset": 13.6},
               {"layer": "TopMetal1", "width": 1.8, "pitch": 30.24, "offset": 13.57}],
    "ring": {"layers": ["Metal5", "TopMetal1"], "width": 5.0, "spacing": 2.0, "core_offset": 4.5},
    "connects": [["Metal1", "Metal5"], ["Metal5", "TopMetal1"]],
    "macro_grid": {"cells": "RM_IHPSG13_*", "connect": ["Metal4", "TopMetal1"], "halo": 0},
}


def expand(p: str) -> str:
    return os.path.expandvars(p)


def on_grid(v: float, g: float) -> bool:
    return abs(round(v / g) * g - v) < 1e-6


class Report:
    def __init__(self):
        self.rows = []

    def add(self, item, value, rule, ok, source):
        self.rows.append({"item": item, "value": value, "rule": rule, "status": "PASS" if ok is True else ("INFO" if ok is None else "FAIL"), "source": source})

    @property
    def failed(self):
        return [r for r in self.rows if r["status"] == "FAIL"]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=str(ROOT / "config/power_regions.yaml"))
    ap.add_argument("--variant", choices=["powerfabric", "floorplanlab"], default="powerfabric")
    ap.add_argument("--die", default="0 0 2819.04 2823.66")
    ap.add_argument("--core", default="40.32 41.58 2778.72 2782.08")
    ap.add_argument("--packagetwin", default=os.environ.get("PACKAGETWIN_ROOT", ""))
    ap.add_argument("--outdir", default=str(ROOT))
    a = ap.parse_args()

    cfg = yaml.safe_load(Path(a.config).read_text())
    tech_cfg, pdn_cfg, pkg = cfg["technology"], cfg["pdn"], cfg["package"]
    P = FLOORPLANLAB if a.variant == "floorplanlab" else pdn_cfg
    tech = lef_tech.parse_tech_lef(expand(tech_cfg["tech_lef"]))
    sc = lef_tech.parse_tech_lef(expand(tech_cfg["stdcell_lef"]))
    cells = lef_tech.parse_macro_lef(expand(tech_cfg["stdcell_lef"]))
    sram = {}
    for f in sorted(Path(expand(tech_cfg["sram_lef_dir"])).glob("RM_IHPSG13_*.lef")):
        sram.update(lef_tech.parse_macro_lef(f))
    die = [float(x) for x in a.die.split()]
    core = [float(x) for x in a.core.split()]
    grid = tech["grid"]
    R = Report()
    L = tech["layers"]
    src_t = f"tech LEF {Path(expand(tech_cfg['tech_lef'])).name}"

    def check_wire(tag, layer, width, pitch=None, offset=None, prl=1e9):
        lay = L.get(layer)
        R.add(f"{tag}: layer {layer}", layer, "exists, TYPE ROUTING", bool(lay and lay.get("type") == "ROUTING"), src_t)
        if not lay:
            return None
        R.add(f"{tag}: width", width, f">= WIDTH {lay['width']}", width >= lay["width"] - 1e-9, src_t)
        if "maxwidth" in lay:
            R.add(f"{tag}: width", width, f"<= MAXWIDTH {lay['maxwidth']}", width <= lay["maxwidth"] + 1e-9, src_t)
        for nm, v in (("width", width), ("pitch", pitch), ("offset", offset)):
            if v is not None:
                R.add(f"{tag}: {nm} on manufacturing grid", v, f"multiple of {grid}", on_grid(v, grid), src_t)
        if pitch:
            gap = pitch / 2 - width
            need = lef_tech.min_spacing(lay, width, prl)
            R.add(f"{tag}: VDD-VSS gap (pitch/2 - width)", round(gap, 4), f">= spacing {need} (SPACINGTABLE / SPACING, long parallel run)", gap >= need - 1e-9, src_t)
            dens = 2 * width / pitch
            if "maximumdensity" in lay:
                R.add(f"{tag}: PDN metal density", f"{dens*100:.1f}%", f"<= MAXIMUMDENSITY {lay['maximumdensity']}%", dens * 100 <= lay["maximumdensity"], src_t)
                R.add(f"{tag}: PDN metal density vs MINIMUMDENSITY", f"{dens*100:.1f}%", f"MINIMUMDENSITY {lay['minimumdensity']}% (fill / signal routing must make up any shortfall)", None, src_t)
            R.add(f"{tag}: EM capacity per strap", f"{lay.get('jdc_avg', 0) * width:.1f} mA", f"DCCURRENTDENSITY AVERAGE {lay.get('jdc_avg')} mA/um x width", None, src_t)
        return lay

    # ---------------------------------------------------------------- rails vs standard-cell LEF
    rails = P["rails"]
    site = sc["sites"].get("CoreSite")
    inv = cells.get("sg13g2_inv_1")
    rail_w = None
    if inv:
        vdd = [r for r in inv["pins"]["VDD"]["rects"] if r[0] == rails["layer"] and abs(r[1]) < 1e-9 and r[3] - r[1] == inv["size"][0]]
        if vdd:
            rail_w = round(vdd[0][4] - vdd[0][2], 4)
    check_wire("rails", rails["layer"], rails["width"])
    R.add("rails: width = std-cell VDD/VSS rail", rails["width"], f"== {rail_w} (sg13g2_stdcell.lef, sg13g2_inv_1 VDD Metal1 rect)", rail_w is not None and abs(rails["width"] - rail_w) < 1e-6, "stdcell LEF")
    if site:
        R.add("rails: same-net pitch = 2 x row height", rails["pitch"], f"== 2 x {site['size'][1]} (SITE CoreSite)", abs(rails["pitch"] - 2 * site["size"][1]) < 1e-6, "stdcell LEF")

    # ---------------------------------------------------------------- straps
    straps = []
    for s in P["straps"]:
        lay = check_wire(f"strap {s['layer']}", s["layer"], s["width"], s["pitch"], s["offset"])
        spacing = round(s["pitch"] / 2 - s["width"], 4)
        straps.append((s["layer"], s["width"], s["pitch"], s["offset"], spacing, lay.get("direction") if lay else "?"))
        R.add(f"strap {s['layer']}: direction", lay.get("direction") if lay else "?", "LEF preferred direction (pdngen draws straps along it)", None, src_t)

    # ---------------------------------------------------------------- ring
    ring = P["ring"]
    margin = min(core[0] - die[0], core[1] - die[1], die[2] - core[2], die[3] - core[3])
    need = ring["core_offset"] + 2 * ring["width"] + ring["spacing"]
    for lyr in ring["layers"]:
        check_wire(f"ring {lyr}", lyr, ring["width"])
        R.add(f"ring {lyr}: spacing", ring["spacing"], f">= {lef_tech.min_spacing(L[lyr], ring['width'])}", ring["spacing"] >= lef_tech.min_spacing(L[lyr], ring["width"]) - 1e-9, src_t)
    dirs = {L[x].get("direction") for x in ring["layers"]}
    R.add("ring: one horizontal + one vertical layer", ring["layers"], "{HORIZONTAL, VERTICAL}", dirs == {"HORIZONTAL", "VERTICAL"}, src_t)
    R.add("ring: fits between core and die edge", f"{need:.2f} um", f"<= min die-core margin {margin:.2f} um", need <= margin + 1e-9, "DIE_AREA / CORE_AREA")

    # ---------------------------------------------------------------- connections
    order = [n for n in tech["order"] if L[n].get("type") == "ROUTING"]
    for lo, hi in P["connects"]:
        ok = lo in order and hi in order and order.index(lo) < order.index(hi)
        R.add(f"connect {lo}->{hi}", f"{lo}->{hi}", "both routing layers, bottom below top (pdngen builds the via stack)", ok, src_t)
    R.add("connect chain reaches the rails", P["connects"][0][0], f"== rail layer {rails['layer']}", P["connects"][0][0] == rails["layer"], "")

    # ---------------------------------------------------------------- macro power pins
    mg = P["macro_grid"]
    pin_layer, up_layer = mg["connect"]
    up = next((s for s in straps if s[0] == up_layer), None)
    for name, M in sorted(sram.items()):
        pg = {p: d for p, d in M["pins"].items() if d["use"] in ("POWER", "GROUND")}
        layers = {r[0] for d in pg.values() for r in d["rects"]}
        R.add(f"{name}: PG pin layer", sorted(layers), f"== macro connect bottom layer {pin_layer}", layers == {pin_layer}, f"{name}.lef")
        R.add(f"{name}: obstruction layers", M["obs_layers"], f"{up_layer} and the straps above must not be obstructed", up_layer not in M["obs_layers"] and all(s[0] not in M["obs_layers"] for s in straps if order.index(s[0]) > order.index(pin_layer)), f"{name}.lef")
        for pin, d in sorted(pg.items()):
            vert = [r for r in d["rects"] if (r[4] - r[2]) > (r[3] - r[1])]
            if up and L[up_layer]["direction"] == "HORIZONTAL" and vert:
                shortest = min(r[4] - r[2] for r in vert)
                ok = up[2] + up[1] <= shortest + 1e-9
                R.add(f"{name}: {pin} stripes crossed by a same-net {up_layer} strap", f"pitch {up[2]} + width {up[1]}",
                      f"<= shortest {pin} stripe {shortest:.3f} um", ok, f"{name}.lef")

    # ---------------------------------------------------------------- package interface (PackageTwin bump map)
    bumps = []
    if a.packagetwin:
        sys.path.insert(0, a.packagetwin)
        import silicaflux_package_twin as pt  # noqa: E402
        UM = pt.UM
        bm = pt.bump_map(pt.Rect(die[0] * UM, die[1] * UM, die[2] * UM, die[3] * UM), pkg["bump_pitch_um"]["value"] * UM,
                         pkg["bump_keepout_um"]["value"] * UM, int(pkg["bump_signal_rings"]["value"]), int(pkg["n_signals"]),
                         int(pkg["io_power_per_signals"]), pattern=pkg["bump_pattern"])
        bumps = [(s["net"], round(s["x_mm"] * 1000, 3), round(s["y_mm"] * 1000, 3), s["ring"]) for s in bm["sites"]]
        R.add("package: bump array", f"{bm['nx']}x{bm['ny']} @ {bm['pitch_um']} um", "PackageTwin bump_map()", None, "PackageTwin")
        R.add("package: core supply bumps", bm["counts"], "VDD/VSS from PackageTwin checkerboard", bm["counts"]["VDD"] > 0 and bm["counts"]["VSS"] > 0, "PackageTwin")
        R.add("package: signals placed", bm["signals_placed"], f"== {pkg['n_signals']} required", bm["signal_shortfall"] == 0, "PackageTwin")
        top = straps[-1]
        if a.variant == "powerfabric":
            # bump centre -> nearest same-net top-strap centre.  pdngen convention observed with this
            # OpenROAD build (reports/pdn/pdn_check_*.md C11 confirms it on the real geometry): the first
            # stripe, centred at core origin + offset, carries the GROUND net; power is half a pitch later.
            pad_r = 50.0
            worst = {"VDD": 0.0, "VSS": 0.0}
            for net, x, y, _ in bumps:
                if net not in worst:
                    continue
                base = core[0] + top[3] + (top[2] / 2 if net == "VDD" else 0.0)
                k = round((x - base) / top[2])
                worst[net] = max(worst[net], abs(x - (base + k * top[2])))
            for net, w in worst.items():
                R.add(f"package: {net} bump -> nearest {net} {top[0]} strap", f"{w:.2f} um", f"<= bump pad radius {pad_r} um (planning; pad/RDL not drawn)", w <= pad_r, "PackageTwin + params")
        n_vdd = sum(1 for b in bumps if b[0] == "VDD")
        i_max = pkg["bump_i_max_a"]["value"]
        R.add("package: VDD bump EM capacity", f"{n_vdd} x {i_max} A = {n_vdd * i_max:.2f} A", "compared with analysed currents in reports/pi", None, "PackageTwin (published range)")

    # ---------------------------------------------------------------- outputs
    out = Path(a.outdir)
    rep_dir = out / "reports/pdn"
    rep_dir.mkdir(parents=True, exist_ok=True)
    (rep_dir / f"param_validation_{a.variant}.json").write_text(json.dumps(R.rows, indent=1))
    lines = [f"# PDN parameter validation - variant `{a.variant}`", "",
             f"Technology: {tech_cfg['name']} - {src_t}, manufacturing grid {grid} um. Die {die}, core {core}.", "",
             "| Item | Value | Rule | Status | Source |", "|---|---|---|---|---|"]
    for r in R.rows:
        lines.append(f"| {r['item']} | {r['value']} | {r['rule']} | {r['status']} | {r['source']} |")
    nf = len(R.failed)
    lines += ["", f"**{sum(r['status']=='PASS' for r in R.rows)} PASS, {nf} FAIL, {sum(r['status']=='INFO' for r in R.rows)} INFO.**"]
    (rep_dir / f"param_validation_{a.variant}.md").write_text("\n".join(lines) + "\n")
    if nf:
        for r in R.failed:
            print("FAIL:", r["item"], r["value"], r["rule"])
        return 1

    gc = pdn_cfg["global_connect"]
    vdd_pins = gc["stdcell"]["VDD"] + gc["sram"]["VDD"]
    vss_pins = gc["stdcell"]["VSS"] + gc["sram"]["VSS"]
    tcl = [f"# generated by scripts/pdn_params.py from {Path(a.config).name} - variant {a.variant} - DO NOT EDIT",
           "# every value below passed reports/pdn/param_validation_%s.md" % a.variant,
           "array set pf {}",
           f"set pf(variant) {a.variant}",
           f"set pf(domain) {pdn_cfg['voltage_domain']}",
           f"set pf(power_net) {pdn_cfg['nets']['power']}",
           f"set pf(ground_net) {pdn_cfg['nets']['ground']}",
           "set pf(global_connect) {%s {%s} -power %s {%s} -ground}" % (pdn_cfg['nets']['power'], " ".join(vdd_pins), pdn_cfg['nets']['ground'], " ".join(vss_pins)),
           "set pf(ring) 1",
           "set pf(ring_layers) {%s}" % " ".join(ring["layers"]),
           "set pf(ring_widths) {%s}" % " ".join([str(ring["width"])] * 2),
           "set pf(ring_spacings) {%s}" % " ".join([str(ring["spacing"])] * 2),
           "set pf(ring_offsets) {%s}" % " ".join([str(ring["core_offset"])] * 4),
           f"set pf(rail_layer) {rails['layer']}",
           f"set pf(rail_width) {rails['width']}",
           "set pf(straps) {%s}" % " ".join("{%s %s %s %s %s}" % s[:5] for s in straps),
           "set pf(connects) {%s}" % " ".join("{%s %s}" % tuple(c) for c in P["connects"]),
           f"set pf(macro_pattern) {mg['cells']}",
           "set pf(macro_connect) {%s %s}" % tuple(mg["connect"]),
           f"set pf(macro_halo) {mg['halo']}"]
    (out / "physical").mkdir(exist_ok=True)
    (out / f"physical/pdn_params_{a.variant}.tcl").write_text("\n".join(tcl) + "\n")
    if bumps:
        with (out / f"physical/bumps_{a.variant}.csv").open("w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["net", "x_um", "y_um", "ring"])
            w.writerows(bumps)
    print(f"pdn_params: {a.variant}: {len(R.rows)} checks, 0 FAIL -> physical/pdn_params_{a.variant}.tcl")
    return 0


if __name__ == "__main__":
    sys.exit(main())
