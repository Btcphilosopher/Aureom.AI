#!/usr/bin/env python3
"""Are the power regions consistent with the placement?  (brief section 11)

BASELINE (single supply): every placed instance must belong to exactly one logical region and to the one
power domain PD_CORE; every region must be fed by the core grid (checked by pdn_check C1/C2).
FUTURE (switchable VEC / TNS): a power-gated region needs a contiguous area (UPF set_domain_area / a
placement fence) with its own switched rails.  This script measures how far the CURRENT placement is from
that: the region's bounding box, how much of that box is occupied by cells of OTHER regions, and the
density-based compact area the region would need.  It does not move anything.
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from powergrid import REGION, group_of  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True)
    ap.add_argument("--out", default=str(ROOT / "reports/physical"))
    a = ap.parse_args()
    cfg = yaml.safe_load((ROOT / "config/power_regions.yaml").read_text())
    rows = list(csv.DictReader(open(Path(a.run) / "instances_ref.csv")))
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    reg = defaultdict(list)
    unmapped = 0
    for r in rows:
        if r["kind"] == "macro":
            n = r["inst"].replace("\\", "")
            rg = "VEC" if n.startswith("u_tile/") else "SRAM"
        else:
            g = group_of(r["inst"])
            rg = REGION.get(g)
            if rg is None:
                unmapped += 1; continue
        reg[rg].append((float(r["x_um"]), float(r["y_um"]), float(r["w_um"]) * float(r["h_um"]), r["kind"]))
    names = [x["name"] for x in cfg["regions"]]
    res = {"instances": len(rows), "unmapped": unmapped, "regions": {}}
    allpts = {k: np.array([(x, y, ar) for x, y, ar, _ in v]) for k, v in reg.items()}
    for rg in names:
        P = allpts.get(rg)
        if P is None or len(P) == 0:
            res["regions"][rg] = {"cells": 0}
            continue
        x0, y0, x1, y1 = P[:, 0].min(), P[:, 1].min(), P[:, 0].max(), P[:, 1].max()
        bb = (x1 - x0) * (y1 - y0)
        own = P[:, 2].sum()
        foreign = 0.0
        for k, Q in allpts.items():
            if k == rg:
                continue
            m = (Q[:, 0] >= x0) & (Q[:, 0] <= x1) & (Q[:, 1] >= y0) & (Q[:, 1] <= y1)
            foreign += Q[m, 2].sum()
        # compact core: smallest box holding 90 % of the region's cell area around its median
        cx, cy = np.median(P[:, 0]), np.median(P[:, 1])
        d = np.maximum(np.abs(P[:, 0] - cx), np.abs(P[:, 1] - cy))
        order = np.argsort(d); cum = np.cumsum(P[order, 2])
        r90 = float(d[order][np.searchsorted(cum, 0.9 * own)])
        res["regions"][rg] = {"cells": int(len(P)), "cell_area_um2": float(own), "bbox_um": [float(x0), float(y0), float(x1), float(y1)],
                              "bbox_area_um2": float(bb), "own_area_fraction_of_bbox": float(own / bb) if bb else None,
                              "foreign_area_in_bbox_um2": float(foreign),
                              "foreign_to_own_ratio": float(foreign / own) if own else None,
                              "box90_half_side_um": r90,
                              "power_domain_baseline": "PD_CORE"}
    (out / "region_placement.json").write_text(json.dumps(res, indent=1))
    md = ["# Power regions vs placement (sfv_soc_df, ORFS 3_place.odb)", "",
          f"Instances: {res['instances']}, not mapped to a region: **{unmapped}**. Baseline: every region is in the single power domain "
          "PD_CORE, fed by the core grid (connectivity in `reports/pdn/pdn_check_placed_powerfabric.md`).", "",
          "| Region | Cells | Cell area (um2) | Placed bounding box (um) | Own area / bbox | Foreign cell area in bbox / own | 90 % area box half-side (um) |",
          "|---|---|---|---|---|---|---|"]
    for rg in names:
        v = res["regions"][rg]
        if not v.get("cells"):
            md.append(f"| {rg} | 0 | - | - | - | - | - |"); continue
        b = v["bbox_um"]
        md.append(f"| {rg} | {v['cells']} | {v['cell_area_um2']:.0f} | ({b[0]:.0f}, {b[1]:.0f})-({b[2]:.0f}, {b[3]:.0f}) | "
                  f"{v['own_area_fraction_of_bbox']:.3f} | {v['foreign_to_own_ratio']:.2f} | {v['box90_half_side_um']:.0f} |")
    md += ["", "**Reading.** In the baseline this placement is consistent by construction (one domain). For the FUTURE switchable "
           "VEC / TNS regions it is not: their cells are spread across most of the core and interleaved with other regions "
           "(foreign/own ratio > 1), so power gating would need placement fences (`set_domain_area`), separate switched rails "
           "and switch cells along them - a new floorplan, not a script change."]
    (out / "region_placement.md").write_text("\n".join(md) + "\n")
    print("\n".join(md[4:4 + len(names) + 2]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
