#!/usr/bin/env python3
"""Audit the target technology for power-management cells (brief section 1) -> reports/tech_cell_audit.md

Reads the Liberty files of the IHP SG13G2 standard-cell library at the ORFS revision the physical flow uses
(ab2aaf0f) and, through `git show`, at the newer revision the SRAM collateral comes from (d0e5b3c), plus the
SRAM macro Liberty and LEF.  Looks for the Liberty attributes that identify power-management cells and for
cell-name patterns, and reports what exists.  Nothing is inferred from names alone when attributes exist.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ORFS = Path(os.environ.get("ORFS_FLOW", "/opt/eda/orfs/flow")).parent
SRAM = Path(os.environ.get("IHP_SRAM", "/opt/eda/collateral/ihp-sg13g2-sram-d0e5b3c"))
ATTR = {"isolation": r"is_isolation_cell\s*:\s*true", "level_shifter": r"is_level_shifter\s*:\s*true",
        "power_switch": r"switch_cell_type", "retention": r"retention_cell|retention_pin", "always_on": r"always_on\s*:\s*true",
        "clock_gate": r"clock_gating_integrated_cell", "pg_pin": r"\bpg_pin\s*\(", "power_down_function": r"power_down_function"}
NAMES = {"isolation": r"iso", "level_shifter": r"lsbuf|levelshift|_ls", "power_switch": r"head|foot|psw|switch",
         "retention": r"ret|rsdf|balloon", "always_on": r"aon|lpflow"}


def cells_of(text: str):
    return re.findall(r'^\s*cell\s*\(\s*"?([A-Za-z0-9_]+)', text, re.M)


def per_cell_attr(text: str):
    out = {}
    parts = re.split(r'^\s*cell\s*\(\s*"?([A-Za-z0-9_]+)"?\s*\)', text, flags=re.M)
    for i in range(1, len(parts), 2):
        body = parts[i + 1]
        out[parts[i]] = {k: bool(re.search(p, body)) for k, p in ATTR.items()}
    return out


def main() -> int:
    libs = []
    p = ORFS / "flow/platforms/ihp-sg13g2/lib/sg13g2_stdcell_typ_1p20V_25C.lib"
    libs.append(("ORFS ab2aaf0f (physical flow)", p.name, p.read_text()))
    for rev, f in (("d0e5b3c13e4bb9bdbd33493d5e87656dcae66384", "sg13g2_stdcell_typ_1p20V_25C.lib"),
                   ("d0e5b3c13e4bb9bdbd33493d5e87656dcae66384", "sg13g2_io_typ_1p2V_3p3V_25C.lib")):
        r = subprocess.run(["git", "-C", str(ORFS), "show", f"{rev}:flow/platforms/ihp-sg13g2/lib/{f}"], capture_output=True, text=True)
        if r.returncode == 0:
            libs.append((f"ORFS d0e5b3c (SRAM collateral revision)", f, r.stdout))
    for f in sorted(SRAM.glob("lib/*typ*.lib")):
        libs.append(("IHP SRAM macro (d0e5b3c)", f.name, f.read_text()))
    md = ["# Technology power-management cell audit (IHP SG13G2)", "",
          "`scripts/tech_audit.py`: Liberty attributes searched per cell; cell-name patterns as a second, weaker signal.", "",
          "| Library | File | Cells | Isolation | Level shifter | Power switch | Retention | Always-on | Clock gate | Cells with pg_pin | power_down_function |",
          "|---|---|---|---|---|---|---|---|---|---|---|"]
    found = {k: [] for k in ATTR}
    for src, name, txt in libs:
        attrs = per_cell_attr(txt)
        cnt = {k: [c for c, a in attrs.items() if a[k]] for k in ATTR}
        for k in ATTR:
            found[k] += [f"{c} ({name})" for c in cnt[k]]
        md.append(f"| {src} | {name} | {len(attrs)} | {len(cnt['isolation'])} | {len(cnt['level_shifter'])} | {len(cnt['power_switch'])} | "
                  f"{len(cnt['retention'])} | {len(cnt['always_on'])} | {', '.join(cnt['clock_gate']) or 0} | {len(cnt['pg_pin'])} | {len(cnt['power_down_function'])} |")
    std = per_cell_attr(libs[0][2])
    hints = {k: [c for c in std if re.search(p, c, re.I)] for k, p in NAMES.items()}
    sram_lib = next((t for s, n, t in libs if "1024x64" in n or "2048x64" in n), "")
    vmap = re.findall(r"voltage_map\s*\(\s*(\w+)\s*,\s*([\d.]+)", sram_lib)
    pgt = re.findall(r"pg_pin\s*\(\s*(\w+)\s*\)\s*\{\s*pg_type\s*:\s*(\w+)", sram_lib)
    io = next((t for s, n, t in libs if n.startswith("sg13g2_io")), "")
    md += ["", "## Findings", "",
           f"* **Isolation, level-shifter, power-switch, retention and always-on cells: none** in either standard-cell revision "
           f"(Liberty attributes); cell-name patterns in the ab2aaf0f library: {({k: v for k, v in hints.items() if v}) or 'none'}.",
           f"* **Clock gates exist**: {', '.join(c for c, a in std.items() if a['clock_gate'])} (both marked `dont_use` by the ORFS platform; "
           "POWERFABRIC instantiates `sg13g2_slgcp_1` explicitly in `sf_pd_icg`, as SilicaFlux-V's `sfv_clkgate` does).",
           "* The standard-cell Liberty has **no `pg_pin` / `voltage_map`** data: it is not power-aware, so no UPF-driven "
           "implementation tool could reason about supply connections from it.",
           f"* SRAM macros: `voltage_map` {vmap}; `pg_pin` types {pgt}.  `VDDARRAY` is a **primary** supply, not a backup / "
           "retention supply, and no retention or `power_down_function` attribute exists: **no retention mode can be claimed**.",
           f"* IO library (d0e5b3c): {', '.join(sorted(set(cells_of(io))))} - the pads contain the only real 1.2 V core / 3.3 V IO "
           "voltage crossing on the die; they are not in the ab2aaf0f platform used by the physical flow.",
           "", "**Consequence:** the implemented configuration is ONE supply domain with clock-enable control.  Power gating, "
           "isolation, retention and voltage islands remain FUTURE configurations (simulation models only) until a library "
           "that provides those cells is adopted."]
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports/tech_cell_audit.md").write_text("\n".join(md) + "\n")
    print("\n".join(md[4:4 + len(libs) + 1]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
