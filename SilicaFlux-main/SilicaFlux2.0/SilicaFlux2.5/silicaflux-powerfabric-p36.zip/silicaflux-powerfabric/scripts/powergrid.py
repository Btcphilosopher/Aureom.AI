#!/usr/bin/env python3
"""POWERFABRIC PowerGrid: static (DC) IR drop, current concentration and EM screening on the REAL extracted
power grid, with package-accurate sources and explicit activity scenarios.

Network  : OpenROAD PDNSim `write_pg_spice` netlist of each supply net (every metal segment and via array
           of the generated PDN, resistances from the tech LEF RPERSQ / via RESISTANCE).  Node names are
           <NET>_<x_dbu>_<y_dbu>_<routing level>.
Sources  : PDNSim's own sources are removed.  Each C4 bump of the net from PackageTwin's bump_map()
           (physical/bumps_<variant>.csv) feeds the nearest top-layer node through R_bump = contact +
           pad/RDL resistance (PackageTwin assumptions) from an ideal VDD (or 0 V) source.
Loads    : per-instance currents.  Spatial distribution = OpenSTA per-instance power (instances_ref.csv);
           magnitude per logical class = PackageTwin workload model (outputs/results/workload_power.csv,
           data/power_model.json); SRAM macros = explicit access-energy x accesses/cycle x f + leakage
           (the IHP SRAM Liberty carries no usable power data - OpenSTA reports 0 W for the macros).
           'stress_bound' = OpenSTA at the stress activity, ungated, every SRAM accessed every cycle at the
           top of the PackageTwin energy range.  All of these are ESTIMATES, not measured switching data.
Outputs  : reports/pi/<variant>/summary.json, scenarios.md, per-macro / per-region tables, EM tables,
           PowerGrid exchange export (nodes.csv / resistors.csv) for ThermalLab and PackageTwin,
           and a validation of this solver against PDNSim on PDNSim's own sources and loads.
"""
from __future__ import annotations

import argparse
import csv
import json
import math
import os
import re
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
import yaml
from scipy.spatial import cKDTree

sys.path.insert(0, str(Path(__file__).resolve().parent))
import lef_tech  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
NODE = re.compile(r"^(\w+?)_(-?\d+)_(-?\d+)_(\d+)$")

# FloorplanLab configs/silicaflux_v/design.yaml logical_groups (order matters: first match wins)
GROUPS = [("cpu", ["u_cpu/"]), ("vector", ["u_tile/u_ve/"]), ("tensor", ["u_tile/u_te/"]), ("tile", ["u_tile/"]),
          ("dma", ["u_dma/"]), ("fabric", ["u_xbar/", "g_v1", "u_pbr/"]), ("sram_ctrl", ["g_sram"]), ("mbist", ["u_mbist/"]),
          ("rom", ["u_rom/"]), ("debug", ["u_dbg/"]),
          ("periph", ["u_uart/", "u_spi/", "u_gpio/", "u_timer/", "u_intc/", "u_sysctrl/", "u_st"]), ("reset", ["u_rs_"])]
# PackageTwin power_model.json group_class
CLASS = {"cpu": "ControlCore", "rom": "ControlCore", "debug": "ControlCore", "vector": "VectorEngine",
         "tensor": "TensorCore", "tile": "DataFabric", "fabric": "DataFabric", "dma": "DataFabric",
         "sram_ctrl": "SRAM", "mbist": "SRAM", "periph": "IO", "reset": "ClockAndGlue", "top": "ClockAndGlue"}
# POWERFABRIC regions (config/power_regions.yaml) for reporting
REGION = {"cpu": "CTRL", "rom": "CTRL", "debug": "CTRL", "vector": "VEC", "tensor": "TNS", "tile": "VEC",
          "dma": "FABRIC", "fabric": "FABRIC", "sram_ctrl": "SRAM", "mbist": "SRAM", "periph": "EXTIF",
          "reset": "AON", "top": "AON"}


def group_of(name: str) -> str:
    n = name.replace("\\", "")
    for g, pats in GROUPS:
        if any(n.startswith(p) for p in pats):
            return g
    return "top"


def parse_spice(path: Path):
    R, I, V = [], [], []
    for line in path.read_text().splitlines():
        if not line or line[0] not in "RIV":
            continue
        t = line.split()
        if line[0] == "R":
            R.append((t[1], t[2], float(t[3])))
        elif line[0] == "I":
            I.append((t[1], float(t[3])))
        else:
            V.append((t[1], float(t[3])))
    return R, I, V


class Grid:
    def __init__(self, sp_path: Path, dbu: int):
        self.R, self.I0, self.V0 = parse_spice(sp_path)
        names = sorted({n for a, b, _ in self.R for n in (a, b)} | {n for n, _ in self.I0} | {n for n, _ in self.V0})
        self.idx = {n: i for i, n in enumerate(names)}
        self.names = names
        xyz = np.array([[int(m.group(2)), int(m.group(3)), int(m.group(4))] for m in map(NODE.match, names)])
        self.x = xyz[:, 0] / dbu
        self.y = xyz[:, 1] / dbu
        self.lvl = xyz[:, 2]
        self.n = len(names)
        a = np.array([self.idx[r[0]] for r in self.R]); b = np.array([self.idx[r[1]] for r in self.R])
        g = 1.0 / np.array([r[2] for r in self.R])
        self.ra, self.rb, self.rg = a, b, g
        self.G = sp.coo_matrix((np.concatenate([g, g, -g, -g]),
                                (np.concatenate([a, b, a, b]), np.concatenate([a, b, b, a]))), shape=(self.n, self.n)).tocsr()

    def solve(self, load_a: np.ndarray, src_nodes, src_r, v_src: float):
        """Nodal analysis: G v = -load + sum_k (v_src - v_k)/r_k  (load = current drawn from the node)."""
        Gs = self.G.copy().tolil() if False else self.G
        diag = np.zeros(self.n)
        rhs = -load_a.copy()
        for nd, r in zip(src_nodes, src_r):
            diag[nd] += 1.0 / r
            rhs[nd] += v_src / r
        A = (Gs + sp.diags(diag)).tocsc()
        v = spla.spsolve(A, rhs)
        return v

    def solve_ideal(self, load_a, fixed: dict):
        """Ideal voltage sources at nodes (PDNSim style)."""
        fi = np.array(sorted(fixed)); fv = np.array([fixed[k] for k in fi])
        free = np.setdiff1d(np.arange(self.n), fi)
        A = self.G.tocsr()
        Aff = A[free][:, free].tocsc()
        Afs = A[free][:, fi]
        v = np.zeros(self.n); v[fi] = fv
        v[free] = spla.spsolve(Aff, -load_a[free] - Afs @ fv)
        return v


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", required=True, help="pf_pi.tcl output directory (VDD.sp, VSS.sp, instances_*.csv)")
    ap.add_argument("--variant", required=True)
    ap.add_argument("--packagetwin", default=os.environ.get("PACKAGETWIN_ROOT", ""))
    ap.add_argument("--out", default=None)
    ap.add_argument("--config", default=str(ROOT / "config/power_regions.yaml"))
    a = ap.parse_args()
    run = Path(a.run)
    out = Path(a.out or ROOT / f"reports/pi/{a.variant}")
    out.mkdir(parents=True, exist_ok=True)
    cfg = yaml.safe_load(Path(a.config).read_text())
    tech = lef_tech.parse_tech_lef(os.path.expandvars(cfg["technology"]["tech_lef"]))
    dbu = tech["dbu"]
    routing = [n for n in tech["order"] if tech["layers"][n].get("type") == "ROUTING"]
    cuts = [n for n in tech["order"] if tech["layers"][n].get("type") == "CUT" and n != "Cont"]
    lvl_name = {i + 1: n for i, n in enumerate(routing)}
    vdd = cfg["technology"]["vdd_v"]["value"]
    pkg = cfg["package"]
    r_bump = pkg["bump_r_contact_ohm"]["value"] + 0.01          # + pad / RDL (PackageTwin bump_pad_redistribution_ohm)
    i_bump_max = pkg["bump_i_max_a"]["value"]
    budget_v = pkg["ir_budget_fraction"]["value"] * vdd

    # ------------------------------------------------------------ instances and scenarios
    def load_inst(p):
        rows = list(csv.DictReader(open(p)))
        for r in rows:
            r["group"] = "macro" if r["kind"] == "macro" else group_of(r["inst"])
            for k in ("x_um", "y_um", "w_um", "h_um", "p_total_w"):
                r[k] = float(r[k])
        return rows
    inst = load_inst(run / "instances_ref.csv")
    inst_st = {r["inst"]: r for r in load_inst(run / "instances_stress.csv")}
    pt = Path(a.packagetwin)
    pm = json.loads((pt / "data/power_model.json").read_text())
    wl = {r["workload"]: r for r in csv.DictReader(open(pt / "outputs/results/workload_power.csv"))}
    f_clk = pm["technology"]["f_clk_hz"]["value"]
    E = {k: v["value"] for k, v in pm["coefficients"]["sram_e_access_j"].items()}
    E_hi = {k: v["range"][1] for k, v in pm["coefficients"]["sram_e_access_j"].items()}
    LK = {k: v["value"] for k, v in pm["coefficients"]["sram_leak_w"].items()}
    macros = [r for r in inst if r["kind"] == "macro"]
    n_main = sum(1 for m in macros if "2048x64" in m["master"])
    n_tspm = sum(1 for m in macros if "512x64" in m["master"])

    ref_class = defaultdict(float)
    for r in inst:
        if r["kind"] != "macro":
            ref_class[CLASS[r["group"]]] += r["p_total_w"]

    def scenario_power(name):
        """per-instance power (W) for one scenario + bookkeeping."""
        p = np.zeros(len(inst))
        if name == "stress_bound":
            for i, r in enumerate(inst):
                if r["kind"] == "macro":
                    e = E_hi[r["master"]]
                    p[i] = e * f_clk + LK[r["master"]]          # one access every cycle, top of range
                else:
                    p[i] = inst_st[r["inst"]]["p_total_w"]
            return p, {"source": f"OpenSTA stress activity, ungated; SRAM 1 access/cycle at {E_hi}"}
        w = wl[name]; spec = pm["workloads"][name]["sram"]
        acc = {"main": spec.get("main_sram", 0.0), "tspm": spec.get("tspm", 0.0)}
        macro_w = 0.0
        for i, r in enumerate(inst):
            if r["kind"] == "macro":
                grp = "main" if "2048x64" in r["master"] else "tspm"
                n = n_main if grp == "main" else n_tspm
                p[i] = acc[grp] / n * E[r["master"]] * f_clk + LK[r["master"]]
                macro_w += p[i]
        target = {c: float(w[f"class_{c}_mw"]) * 1e-3 for c in ("ControlCore", "DataFabric", "SRAM", "IO", "TensorCore", "ClockAndGlue", "VectorEngine")}
        target["IO"] -= float(w["comp_io_mw"]) * 1e-3            # pad ring is on VDDIO, not core VDD
        target["SRAM"] -= macro_w                                 # macros carried explicitly
        scale = {c: max(target[c], 0.0) / ref_class[c] if ref_class[c] > 0 else 0.0 for c in target}
        for i, r in enumerate(inst):
            if r["kind"] != "macro":
                p[i] = r["p_total_w"] * scale[CLASS[r["group"]]]
        return p, {"packagetwin_core_mw": float(w["core_w"]) * 1e3, "class_target_mw": {k: v * 1e3 for k, v in target.items()},
                   "macro_mw": macro_w * 1e3, "description": w["description"]}

    scenarios = [s for s in cfg["scenarios"]] + ["stress_bound"]

    # ------------------------------------------------------------ grids
    bumps = list(csv.DictReader(open(ROOT / f"physical/bumps_{a.variant}.csv")))
    summary = {"variant": a.variant, "vdd_v": vdd, "budget_v": budget_v, "r_bump_ohm": r_bump, "scenarios": {}, "validation": {}}
    grids = {}
    for net in ("VDD", "VSS"):
        G = Grid(run / f"{net}.sp", dbu)
        grids[net] = G
        top = G.lvl.max()
        topn = np.where(G.lvl == top)[0]
        tree_top = cKDTree(np.c_[G.x[topn], G.y[topn]])
        src, dist = [], []
        for b in bumps:
            if b["net"] != net:
                continue
            d, k = tree_top.query([float(b["x_um"]), float(b["y_um"])])
            src.append(topn[k]); dist.append(d)
        G.src = np.array(src); G.src_dist = np.array(dist)
        # load attachment: std cells -> nearest Metal1 node (row-weighted), macros -> their pin-layer nodes
        m1 = np.where(G.lvl == 1)[0]
        tree_m1 = cKDTree(np.c_[G.x[m1], G.y[m1] * 8.0])
        att = np.zeros(len(inst), dtype=int)
        macro_nodes = {}
        for i, r in enumerate(inst):
            if r["kind"] == "macro":
                x0, x1 = r["x_um"] - r["w_um"] / 2, r["x_um"] + r["w_um"] / 2
                y0, y1 = r["y_um"] - r["h_um"] / 2, r["y_um"] + r["h_um"] / 2
                nodes = np.where((G.lvl == 4) & (G.x >= x0) & (G.x <= x1) & (G.y >= y0) & (G.y <= y1))[0]
                macro_nodes[r["inst"]] = nodes
                att[i] = -1
            else:
                _, k = tree_m1.query([r["x_um"], r["y_um"] * 8.0])
                att[i] = m1[k]
        G.att, G.macro_nodes = att, macro_nodes
        # connectivity: every node must reach a source
        ncomp, lab = sp.csgraph.connected_components(G.G, directed=False)
        src_lab = set(lab[G.src])
        floating = int(sum(1 for i in range(G.n) if lab[i] not in src_lab))
        summary["validation"][f"{net}_nodes"] = G.n
        summary["validation"][f"{net}_resistors"] = len(G.R)
        summary["validation"][f"{net}_floating_nodes"] = floating
        summary["validation"][f"{net}_bumps"] = len(src)
        summary["validation"][f"{net}_bump_to_node_max_um"] = float(np.max(dist)) if dist else None
        summary["validation"][f"{net}_macros_without_pin_nodes"] = [k for k, v in macro_nodes.items() if len(v) == 0]

        # -------- solver validation against PDNSim: PDNSim's own ideal sources and loads
        load0 = np.zeros(G.n)
        for nd, val in G.I0:
            load0[G.idx[nd]] += val
        fixed = {G.idx[nd]: val for nd, val in G.V0}
        v0 = G.solve_ideal(load0 if net == "VDD" else -load0, fixed)
        drop0 = (vdd - v0.min()) if net == "VDD" else v0.max()
        psm, cmp_ = None, {}
        rpt = run / f"psm_{net}_voltage.rpt"
        if rpt.exists():
            pts = []
            for l in rpt.read_text().splitlines()[1:]:
                t = l.rsplit(",", 3)
                if len(t) == 4:
                    pts.append((float(t[1]), float(t[2]), float(t[3])))
            if pts:
                P = np.array(pts)
                psm = (vdd - P[:, 2].min()) if net == "VDD" else P[:, 2].max()
                # node-by-node: PDNSim reports the voltage of the grid node each instance is tied to
                tree_all = cKDTree(np.c_[G.x, G.y])
                d, k = tree_all.query(P[:, :2], k=8)
                best = np.abs(v0[k] - P[:, 2:3]).min(axis=1)      # several layers share an (x, y): take the closest match
                ok = d[:, 0] < 0.01
                rel = best[ok] / max(drop0, 1e-12)
                cmp_ = {"points_compared": int(ok.sum()), "max_abs_diff_mv": float(best[ok].max() * 1e3),
                        "p99_abs_diff_mv": float(np.percentile(best[ok], 99) * 1e3),
                        "max_diff_rel_to_worst_drop": float(rel.max()),
                        "note": "PDNSim prints voltages to 3 significant digits (1.20e+00 V resolution in the summary); per-node values in the report"}
        summary["validation"][f"{net}_solver_vs_pdnsim"] = {"this_solver_worst_drop_v": drop0, "pdnsim_report_worst_drop_v": psm,
                                                            "pdnsim_sources": len(fixed), "pdnsim_total_load_a": float(load0.sum()), **cmp_}

    # ------------------------------------------------------------ scenarios
    lines_md = []
    region_names = ["CTRL", "VEC", "TNS", "SRAM", "FABRIC", "EXTIF", "AON"]
    for s in scenarios:
        p, info = scenario_power(s)
        cur = p / vdd
        res = {"info": info, "core_power_mw": float(p.sum() * 1e3), "core_current_ma": float(cur.sum() * 1e3), "nets": {}}
        for net, G in grids.items():
            load = np.zeros(G.n)
            for i, r in enumerate(inst):
                if G.att[i] >= 0:
                    load[G.att[i]] += cur[i]
                else:
                    nodes = G.macro_nodes[r["inst"]]
                    if len(nodes):
                        load[nodes] += cur[i] / len(nodes)
            sign = 1.0 if net == "VDD" else -1.0                     # VSS: current flows into the grid
            v = G.solve(sign * load, G.src, [r_bump] * len(G.src), vdd if net == "VDD" else 0.0)
            drop = (vdd - v) if net == "VDD" else v
            # branch currents and EM
            ib = (v[G.ra] - v[G.rb]) * G.rg
            same = G.lvl[G.ra] == G.lvl[G.rb]
            em = {}
            for lv in np.unique(G.lvl):
                lname = lvl_name[int(lv)]
                lay = tech["layers"][lname]
                sel = same & (G.lvl[G.ra] == lv)
                if not sel.any():
                    continue
                L = np.hypot(G.x[G.ra[sel]] - G.x[G.rb[sel]], G.y[G.ra[sel]] - G.y[G.rb[sel]])
                width = lay["rpersq"] * L / (1.0 / G.rg[sel])        # w = Rsq * L / R
                ok = width > 0
                j = np.zeros(sel.sum()); j[ok] = np.abs(ib[sel][ok]) * 1e3 / width[ok]   # mA/um
                em[lname] = {"max_ma_per_um": float(j.max()), "limit_ma_per_um": lay.get("jdc_avg"),
                             "ratio": float(j.max() / lay["jdc_avg"]) if lay.get("jdc_avg") else None,
                             "max_branch_ma": float(np.abs(ib[sel]).max() * 1e3)}
            for lo in np.unique(G.lvl):
                sel = (~same) & (np.minimum(G.lvl[G.ra], G.lvl[G.rb]) == lo)
                if not sel.any():
                    continue
                cut = cuts[int(lo) - 1] if int(lo) - 1 < len(cuts) else None
                if not cut:
                    continue
                cl = tech["layers"][cut]
                ncut = np.maximum(np.round(cl["r_cut"] * G.rg[sel]), 1)
                ipc = np.abs(ib[sel]) * 1e3 / ncut                   # mA per cut
                em[cut] = {"max_ma_per_cut": float(ipc.max()), "limit_ma_per_cut": cl.get("jdc_avg"),
                           "ratio": float(ipc.max() / cl["jdc_avg"]) if cl.get("jdc_avg") else None}
            ibump = np.abs((vdd if net == "VDD" else 0.0) - v[G.src]) / r_bump
            # per region / per macro
            reg = defaultdict(float)
            for i, r in enumerate(inst):
                if G.att[i] >= 0:
                    rg = REGION.get(r["group"], "AON")
                    reg[rg] = max(reg[rg], float(drop[G.att[i]]))
            mac = {}
            for k, nodes in G.macro_nodes.items():
                mac[k] = {"worst_drop_mv": float(drop[nodes].max() * 1e3) if len(nodes) else None, "pin_nodes": int(len(nodes))}
            k = int(np.argmax(drop))
            res["nets"][net] = {"worst_drop_mv": float(drop.max() * 1e3), "avg_drop_mv": float(drop[G.lvl == 1].mean() * 1e3),
                                "worst_at_um": [float(G.x[k]), float(G.y[k])], "worst_layer": lvl_name[int(G.lvl[k])],
                                "bump_current_max_ma": float(ibump.max() * 1e3), "bump_current_sum_ma": float(ibump.sum() * 1e3),
                                "em": em, "region_worst_drop_mv": {rg: reg.get(rg, 0.0) * 1e3 for rg in region_names},
                                "macro": mac}
            if s == "mixed" and net == "VDD":
                # PowerGrid exchange export (ThermalLab powergrid_adapter / PackageTwin powergrid-import schema)
                ex = out / "powergrid_export_mixed_VDD"
                ex.mkdir(exist_ok=True)
                with open(ex / "nodes.csv", "w", newline="") as f:
                    wr = csv.writer(f); wr.writerow(["node", "x_um", "y_um", "load_current_a", "voltage_v"])
                    for i in range(G.n):
                        wr.writerow([G.names[i], f"{G.x[i]:.3f}", f"{G.y[i]:.3f}", f"{load[i]:.6e}", f"{v[i]:.9f}"])
                with open(ex / "resistors.csv", "w", newline="") as f:
                    wr = csv.writer(f); wr.writerow(["n1", "n2", "r_ohm", "layer", "dissipation_w"])
                    for (n1, n2, r_), ia, ibb in zip(G.R, G.ra, G.rb):
                        la, lb = G.lvl[ia], G.lvl[ibb]
                        lname = lvl_name[int(la)] if la == lb else f"{lvl_name[int(min(la, lb))]}-{lvl_name[int(max(la, lb))]}"
                        wr.writerow([n1, n2, f"{r_:.6g}", lname, f"{(v[ia] - v[ibb]) ** 2 / r_:.6e}"])
                np.save(out / "mixed_VDD_drop.npy", np.c_[G.x, G.y, G.lvl, drop])
        tot = res["nets"]["VDD"]["worst_drop_mv"] + res["nets"]["VSS"]["worst_drop_mv"]
        res["vdd_plus_vss_worst_mv"] = tot
        res["budget_mv"] = budget_v * 1e3
        res["headroom_ir_x"] = budget_v * 1e3 / tot if tot > 0 else None
        em_ratio = max([e["ratio"] for net in res["nets"].values() for e in net["em"].values() if e.get("ratio")] or [0])
        res["em_worst_ratio"] = em_ratio
        res["headroom_em_x"] = 1.0 / em_ratio if em_ratio else None
        bmax = max(res["nets"][n]["bump_current_max_ma"] for n in res["nets"])
        res["headroom_bump_x"] = i_bump_max * 1e3 / bmax if bmax else None
        summary["scenarios"][s] = res
        print(f"{a.variant:12s} {s:16s} core {res['core_power_mw']:7.2f} mW {res['core_current_ma']:7.2f} mA | "
              f"VDD {res['nets']['VDD']['worst_drop_mv']:.4f} mV VSS {res['nets']['VSS']['worst_drop_mv']:.4f} mV | "
              f"EM {em_ratio:.4f} | IR headroom {res['headroom_ir_x']:.0f}x")
    (out / "summary.json").write_text(json.dumps(summary, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
