#!/usr/bin/env python3
"""Package the deliverable: stage the project without build products, replace absolute local paths in text
files by <placeholders>, write MANIFEST.sha256, zip.   package.py <out.zip>"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SKIP_DIRS = {"build", "work", "ext", "__pycache__", ".pytest_cache"}
SKIP_EXT = {".npy", ".pyc", ".vvp"}
TEXT_EXT = {".md", ".txt", ".json", ".log", ".rpt", ".tcl", ".csv", ".py", ".sv", ".svh", ".upf", ".yaml", ".sh", ".tmpl", ".f", ""}


def main(out: str) -> int:
    subs = [(re.escape(str(ROOT.parent)) + r"/pf_work", "<work>"), (re.escape(str(ROOT.parent)) + r"/audit/[^/\s\"]+/", "<ext>/"),
            (re.escape(str(ROOT)), "<powerfabric>"), (re.escape(str(ROOT.parent)), "<scratch>")]
    if os.environ.get("REPO"):
        subs.append((re.escape(os.environ["REPO"]), "<repo>"))
    with tempfile.TemporaryDirectory() as td:
        stage = Path(td) / "silicaflux-powerfabric"
        for dp, dns, fns in os.walk(ROOT):
            dns[:] = [d for d in dns if d not in SKIP_DIRS]
            for fn in fns:
                src = Path(dp) / fn
                if src.suffix in SKIP_EXT:
                    continue
                dst = stage / src.relative_to(ROOT)
                dst.parent.mkdir(parents=True, exist_ok=True)
                if src.suffix in TEXT_EXT and src.stat().st_size < 20_000_000 and "powergrid_export" not in str(src):
                    t = src.read_text(errors="replace")
                    for a, b in subs:
                        t = re.sub(a, b, t)
                    dst.write_text(t)
                else:
                    shutil.copy2(src, dst)
        lines = []
        for p in sorted(stage.rglob("*")):
            if p.is_file():
                lines.append(f"{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(stage)}")
        (stage / "MANIFEST.sha256").write_text("\n".join(lines) + "\n")
        with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            for p in sorted(stage.rglob("*")):
                if p.is_file():
                    z.write(p, p.relative_to(stage.parent))
    print(f"package: {len(lines) + 1} files -> {out} ({Path(out).stat().st_size / 1e6:.1f} MB)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1]))
