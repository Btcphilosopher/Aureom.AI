#!/usr/bin/env python3
"""Physical power-grid checks on the data exported by pdn/sf_post_pdn.tcl (brief section 11).

Checks (each PASS / FAIL with the measured value):
  C1  check_power_grid passes for every supply net (OpenROAD connectivity)
  C2  every PG pin of every instance (standard cells and macros) is on a supply net of the right type
  C3  every hard-macro PG pin NAME receives vias from the grid; and every vertical PG stripe of it (per stripe count)
  C4  every wire is on a layer the configuration declares for the PDN
  C5  wire widths: >= LEF WIDTH, <= LEF MAXWIDTH, == the declared width (rails / straps / ring)
  C6  every coordinate on the LEF manufacturing grid
  C7  every shape inside the die area
  C8  no VDD/VSS short and VDD-VSS spacing >= LEF spacing (SPACINGTABLE with width and parallel run length)
  C9  PDN metal density per LEF DENSITYCHECKWINDOW / STEP <= MAXIMUMDENSITY (MINIMUMDENSITY reported: fill)
  C10 ring closed on both nets (two horizontal + two vertical pieces per net)
  C11 package interface: every VDD (VSS) C4 bump lies within the pad radius of a VDD (VSS) top-layer strap
Writes reports/pdn/pdn_check_<variant>.{json,md}.  Exit status 1 if any check FAILs.
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from collections import defaultdict
from pathlib import Path

import numpy as np
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
import lef_tech  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


def load_params(tcl: Path) -> dict:
    """Read the generated pdn_params_<variant>.tcl (simple 'set pf(key) value' lines)."""
    p = {}
    for line in tcl.read_text().splitlines():
        if line.startswith("set pf("):
            k = line[7:line.index(")")]
            v = line[line.index(")") + 2:].strip()
            p[k] = v
    def lst(s):
        s = s.strip()
        if s.startswith("{") and s.endswith("}"):
            s = s[1:-1]
        out, depth, cur = [], 0, ""
        for ch in s:
            if ch == "{":
                depth += 1
                if depth == 1:
                    cur = ""; continue
            if ch == "}":
                depth -= 1
                if depth == 0:
                    out.append(cur.split()); cur = ""; continue
            if depth >= 1:
                cur += ch
            elif ch == " ":
                if cur.strip(): out.append(cur.strip())
                cur = ""
            else:
                cur += ch
        if cur.strip(): out.append(cur.strip())
        return out
    straps = [(s[0], float(s[1]), float(s[2]), float(s[3]), float(s[4])) for s in lst(p["straps"])]
    return {"variant": p["variant"], "rail_layer": p["rail_layer"], "rail_width": float(p["rail_width"]),
            "ring_layers": lst(p["ring_layers"]), "ring_width": float(lst(p["ring_widths"])[0]),
            "straps": straps, "macro_connect": lst(p["macro_connect"])}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", required=True, help="directory written by sf_post_pdn.tcl")
    ap.add_argument("--variant", default="powerfabric")
    ap.add_argument("--die", default="0 0 2819.04 2823.66")
    ap.add_argument("--config", default=str(ROOT / "config/power_regions.yaml"))
    ap.add_argument("--outdir", default=str(ROOT / "reports/pdn"))
    ap.add_argument("--tag", default="")
    a = ap.parse_args()
    d = Path(a.data)
    cfg = yaml.safe_load(Path(a.config).read_text())
    tech = lef_tech.parse_tech_lef(os.path.expandvars(cfg["technology"]["tech_lef"]))
    L, grid = tech["layers"], tech["grid"]
    prm = load_params(ROOT / f"physical/pdn_params_{a.variant}.tcl")
    die = [float(x) for x in a.die.split()]
    rows = []

    def add(cid, item, value, rule, ok):
        rows.append({"check": cid, "item": item, "value": value, "rule": rule,
                     "status": "PASS" if ok is True else ("INFO" if ok is None else "FAIL")})

    # C1
    for r in json.loads((d / "check_power_grid.json").read_text()):
        add("C1", f"check_power_grid {r['net']}", f"rc={r['rc']} result={r['result']} unconnected={r['unconnected_lines']}",
            "OpenROAD reports the grid connected", r["rc"] == 0 and r["result"] == "true" and r["unconnected_lines"] == 0)
    # C2
    pg = json.loads((d / "pg_iterms.json").read_text())
    for c in pg["counts"]:
        add("C2", f"{c['kind']} {c['sig']} pins {'connected' if c['connected'] else 'NOT connected'}", c["count"],
            "every PG pin on a supply net of its type", bool(c["connected"]) or c["count"] == 0)
    # shapes
    W = defaultdict(list)   # (net, layer) -> wires
    V = defaultdict(list)   # (net, bottom) -> vias
    allc = []
    with (d / "pdn_shapes.csv").open() as f:
        for r in csv.DictReader(f):
            box = tuple(float(r[k]) for k in ("x0", "y0", "x1", "y1"))
            allc.extend(box)
            if r["kind"] == "wire":
                W[(r["net"], r["layer"])].append((box, r["shape"]))
            else:
                V[(r["net"], r["layer"])].append(box)
    # C3 macro PG pins
    pins = defaultdict(list)
    with (d / "macro_pg_pins.csv").open() as f:
        for r in csv.DictReader(f):
            pins[(r["inst"], r["pin"], r["net"], r["layer"])].append(tuple(float(r[k]) for k in ("x0", "y0", "x1", "y1")))
    missing_name, stripes_tot, stripes_hit, per_pin = 0, 0, 0, defaultdict(lambda: [0, 0])
    for (inst, pin, net, layer), rects in pins.items():
        vias = np.array(V.get((net, layer), []) or [(0, 0, 0, 0)])
        hit_any = False
        for (x0, y0, x1, y1) in rects:
            ov = (vias[:, 0] < x1) & (vias[:, 2] > x0) & (vias[:, 1] < y1) & (vias[:, 3] > y0)
            n = int(ov.sum())
            hit_any |= n > 0
            if (y1 - y0) > (x1 - x0):           # vertical stripe
                stripes_tot += 1; stripes_hit += n > 0
                per_pin[pin][0] += 1; per_pin[pin][1] += n > 0
        if not hit_any:
            missing_name += 1
    add("C3", "macro PG pins (instance x pin name) with no via", f"{missing_name} of {len(pins)}", "== 0", missing_name == 0)
    for pin, (t, h) in sorted(per_pin.items()):
        add("C3", f"macro {pin} vertical stripes reached by >= 1 via", f"{h} / {t}", "all stripes", h == t)
    # C4..C7
    declared = {prm["rail_layer"]} | {s[0] for s in prm["straps"]} | set(prm["ring_layers"])
    layers = {k[1] for k in W}
    add("C4", "wire layers", sorted(layers), f"subset of declared PDN layers {sorted(declared)}", layers <= declared)
    off_grid = sum(1 for v in allc if abs(round(v / grid) * grid - v) > 1e-6)
    add("C6", "coordinates off the manufacturing grid", off_grid, f"0 (grid {grid} um)", off_grid == 0)
    outside = 0
    for k, ws in W.items():
        for (x0, y0, x1, y1), _ in ws:
            if x0 < die[0] - 1e-6 or y0 < die[1] - 1e-6 or x1 > die[2] + 1e-6 or y1 > die[3] + 1e-6:
                outside += 1
    add("C7", "wires outside the die area", outside, "0", outside == 0)
    strap_w = {s[0]: s[1] for s in prm["straps"]}
    for lay in sorted(layers):
        lef = L[lay]
        ws = [w for (n, l), lst in W.items() if l == lay for w in lst]
        widths = []
        for (x0, y0, x1, y1), shape in ws:
            if shape == "FOLLOWPIN":
                widths.append(("rail", round(y1 - y0, 4)))
            elif shape == "STRIPE":
                vert = lef.get("direction") == "VERTICAL"
                widths.append(("strap", round((x1 - x0) if vert else (y1 - y0), 4)))
            elif shape == "RING":
                widths.append(("ring", round(min(x1 - x0, y1 - y0), 4)))
        for kind in ("rail", "strap", "ring"):
            ww = sorted({w for k, w in widths if k == kind})
            if not ww:
                continue
            want = prm["rail_width"] if kind == "rail" else (prm["ring_width"] if kind == "ring" else strap_w.get(lay))
            ok = all(w >= lef["width"] - 1e-6 for w in ww) and all(w <= lef.get("maxwidth", 1e9) + 1e-6 for w in ww)
            add("C5", f"{lay} {kind} widths", ww, f">= {lef['width']}, <= {lef.get('maxwidth', '-')}, declared {want}",
                ok and all(abs(w - want) < 1e-3 for w in ww))
    # C8 shorts and spacing between VDD and VSS on each layer
    for lay in sorted(layers):
        a_ = np.array([b for b, _ in W.get(("VDD", lay), [])] or np.zeros((0, 4)))
        b_ = np.array([b for b, _ in W.get(("VSS", lay), [])] or np.zeros((0, 4)))
        if len(a_) == 0 or len(b_) == 0:
            continue
        worst, shorts, viol = 1e9, 0, 0
        for i in range(0, len(a_), 256):
            A = a_[i:i + 256, None, :]
            dx = np.maximum(b_[None, :, 0] - A[..., 2], A[..., 0] - b_[None, :, 2])
            dy = np.maximum(b_[None, :, 1] - A[..., 3], A[..., 1] - b_[None, :, 3])
            dist = np.maximum(dx, dy)                         # <0 overlap, 0 touch
            shorts += int(((dx < 0) & (dy < 0)).sum() + ((dx <= 0) & (dy <= 0) & ((dx == 0) | (dy == 0))).sum())
            near = (dist < 5.0)
            if near.any():
                ii, jj = np.nonzero(near)
                for p, q in zip(ii, jj):
                    s1 = A[p, 0]; s2 = b_[q]
                    side_x = dx[p, q] > dy[p, q]                 # separated along x -> parallel run along y
                    prl = min(s1[3], s2[3]) - max(s1[1], s2[1]) if side_x else min(s1[2], s2[2]) - max(s1[0], s2[0])
                    wmax = max(min(s1[2] - s1[0], s1[3] - s1[1]), min(s2[2] - s2[0], s2[3] - s2[1]))
                    need = lef_tech.min_spacing(L[lay], wmax, max(prl, 0.0))
                    if dist[p, q] < need - 1e-6:
                        viol += 1
                    worst = min(worst, dist[p, q])
            else:
                worst = min(worst, float(dist.min()))
        add("C8", f"{lay}: VDD/VSS shorts", shorts, "0", shorts == 0)
        add("C8", f"{lay}: VDD-VSS spacing violations", f"{viol} (closest {worst:.3f} um)", "0 below LEF spacing", viol == 0)
    # C9 density (PDN metal only)
    for lay in sorted(layers):
        lef = L[lay]
        if "maximumdensity" not in lef:
            continue
        win, step = 200.0, 100.0
        boxes = np.array([b for (n, l), lst in W.items() if l == lay for b, _ in lst])
        xs = np.arange(die[0], die[2] - win + 1e-6, step); ys = np.arange(die[1], die[3] - win + 1e-6, step)
        dens = np.zeros((len(xs), len(ys)))
        for i, x in enumerate(xs):
            ox = np.clip(np.minimum(boxes[:, 2], x + win) - np.maximum(boxes[:, 0], x), 0, None)
            for j, y in enumerate(ys):
                oy = np.clip(np.minimum(boxes[:, 3], y + win) - np.maximum(boxes[:, 1], y), 0, None)
                dens[i, j] = (ox * oy).sum() / (win * win) * 100
        add("C9", f"{lay}: PDN density max over {win:.0f}x{win:.0f} windows", f"{dens.max():.1f}%",
            f"<= MAXIMUMDENSITY {lef['maximumdensity']}%", bool(dens.max() <= lef["maximumdensity"]))
        add("C9", f"{lay}: PDN density min", f"{dens.min():.1f}%", f"MINIMUMDENSITY {lef['minimumdensity']}%: shortfall is for routing / metal fill", None)
    # C10 ring
    for net in ("VDD", "VSS"):
        ring = [(b, l) for (n, l), lst in W.items() if n == net for b, s in lst if s == "RING"]
        hor = sum(1 for (x0, y0, x1, y1), l in ring if (x1 - x0) > (y1 - y0))
        ver = len(ring) - hor
        add("C10", f"{net} ring pieces", f"{hor} horizontal + {ver} vertical", "2 + 2 (closed ring)", hor == 2 and ver == 2)
    # C11 package
    bump_csv = ROOT / f"physical/bumps_{a.variant}.csv"
    top = prm["straps"][-1][0]
    if bump_csv.exists():
        with bump_csv.open() as f:
            bumps = [r for r in csv.DictReader(f) if r["net"] in ("VDD", "VSS")]
        for net in ("VDD", "VSS"):
            st = [b for b, s in W.get((net, top), []) if s == "STRIPE"]
            worst = 0.0
            for b in bumps:
                if b["net"] != net:
                    continue
                x, y = float(b["x_um"]), float(b["y_um"])
                dmin = min(max(abs(x - (s[0] + s[2]) / 2) - (s[2] - s[0]) / 2, 0) + max(s[1] - y, 0, y - s[3]) for s in st) if st else 1e9
                worst = max(worst, dmin)
            add("C11", f"{net} bumps: distance to nearest {net} {top} strap edge", f"{worst:.2f} um", "<= 50 um (C4 pad radius, PackageTwin 100 um bump)", bool(worst <= 50.0))
    out = Path(a.outdir); out.mkdir(parents=True, exist_ok=True)
    tag = a.tag or a.variant
    (out / f"pdn_check_{tag}.json").write_text(json.dumps(rows, indent=1))
    md = [f"# Physical power-grid checks - `{tag}`", "", f"Data: `{d.name}/` exported by `pdn/sf_post_pdn.tcl`; rules from the tech LEF.", "",
          "| Check | Item | Value | Rule | Status |", "|---|---|---|---|---|"]
    md += [f"| {r['check']} | {r['item']} | {r['value']} | {r['rule']} | {r['status']} |" for r in rows]
    nf = sum(r["status"] == "FAIL" for r in rows)
    md += ["", f"**{sum(r['status'] == 'PASS' for r in rows)} PASS, {nf} FAIL, {sum(r['status'] == 'INFO' for r in rows)} INFO.**"]
    (out / f"pdn_check_{tag}.md").write_text("\n".join(md) + "\n")
    print(f"pdn_check {tag}: {len(rows)} checks, {nf} FAIL")
    for r in rows:
        if r["status"] == "FAIL":
            print("  FAIL", r["check"], r["item"], r["value"], r["rule"])
    return 1 if nf else 0


if __name__ == "__main__":
    sys.exit(main())
