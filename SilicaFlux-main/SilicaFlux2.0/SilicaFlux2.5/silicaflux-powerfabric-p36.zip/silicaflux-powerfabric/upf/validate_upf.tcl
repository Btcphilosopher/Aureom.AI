# =============================================================================
# SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
# validate_upf.tcl : load the OpenROAD-subset UPF files into the real design and
# report what OpenROAD built (openroad -exit validate_upf.tcl).
#
# This OpenROAD build (2.0-12331) implements only part of IEEE 1801 and does not
# check that -elements exist (a bogus path is accepted silently - verified).
# So, after read_upf, this script itself:
#   * reads back every power domain / switch / isolation / logic port from ODB,
#   * resolves each element against the design hierarchy (dbModInst) and counts
#     the leaf instances underneath,
#   * looks for library cells usable by use_interface_cell / map_power_switch
#     (Liberty is_isolation_cell / switch_cell_type / level-shifter), and
#   * writes $OUT/<name>.json for scripts/upf_check.py.
# Env: ODB ORFS_FLOW IHP_SRAM PF_ROOT OUT UPF (one file per OpenROAD run: power-intent objects persist in ODB)
# =============================================================================
set P $::env(ORFS_FLOW)/platforms/ihp-sg13g2
set out $::env(OUT)
file mkdir $out
read_lef $P/lef/sg13g2_tech.lef
read_lef $P/lef/sg13g2_stdcell.lef
foreach s {2048 1024 512 256} { read_lef $::env(IHP_SRAM)/lef/RM_IHPSG13_1P_${s}x64_c2_bm_bist.lef }
read_liberty $P/lib/sg13g2_stdcell_typ_1p20V_25C.lib
read_db $::env(ODB)
set block [ord::get_db_block]

proc jstr {s} { return "\"[string map {\\ \\\\ \" \\\"} $s]\"" }

# hierarchy: module instance full paths -> leaf instance counts
array set leaf {}
foreach inst [$block getInsts] {
  set n [string map {\\ {}} [$inst getName]]
  set parts [split $n /]
  for {set i 1} {$i < [llength $parts]} {incr i} {
    set pfx [join [lrange $parts 0 [expr {$i-1}]] /]
    if {![info exists leaf($pfx)]} { set leaf($pfx) 0 }
    incr leaf($pfx)
  }
}
set modpaths {}
foreach mi [$block getModInsts] { lappend modpaths [string map {\\ {}} [$mi getHierarchicalName]] }

# library cells usable as power-management interface cells
set iso_cells {}; set sw_cells {}; set ls_cells {}; set ret_cells {}
foreach c [get_lib_cells */*] {
  if {1} {
    set name [get_name $c]
    foreach {attr var} {is_isolation_cell iso_cells switch_cell_type sw_cells is_level_shifter ls_cells retention_cell ret_cells} {
      if {![catch {get_property $c $attr} v] && $v != "" && $v != "0" && $v != "false"} { lappend $var $name }
    }
  }
}
# independent text scan of the Liberty files (get_property may not expose every attribute)
set lib_scan {}
foreach f [glob $P/lib/*.lib] {
  set fh [open $f r]; set txt [read $fh]; close $fh
  lappend lib_scan "{\"file\": [jstr [file tail $f]], \"is_isolation_cell\": [regexp -all {is_isolation_cell} $txt], \"switch_cell_type\": [regexp -all {switch_cell_type} $txt], \"is_level_shifter\": [regexp -all {is_level_shifter} $txt], \"retention_cell\": [regexp -all {retention_cell} $txt], \"always_on\": [regexp -all {always_on} $txt], \"pg_pin\": [regexp -all {pg_pin} $txt]}"
}

foreach upf [list $::env(UPF)] {
  set name [file rootname [file tail $upf]]
  set rc [catch {read_upf -file $upf} msg]
  puts "SF-UPF: read_upf $upf -> rc=$rc $msg"
  set doms {}
  foreach pd [$block getPowerDomains] {
    set els {}
    foreach e [$pd getElements] {
      set e2 [string map {\\ {}} $e]
      set found [expr {[lsearch -exact $modpaths $e2] >= 0}]
      set n [expr {[info exists leaf($e2)] ? $leaf($e2) : 0}]
      lappend els "{\"element\": [jstr $e2], \"modinst_found\": $found, \"leaf_instances\": $n}"
    }
    lappend doms "{\"name\": [jstr [$pd getName]], \"elements\": \[[join $els ,]\]}"
  }
  set sws {}
  foreach ps [$block getPowerSwitches] {
    lappend sws "{\"name\": [jstr [$ps getName]], \"control\": [jstr [$ps getControlPorts]], \"in\": [jstr [$ps getInputSupplyPorts]], \"out\": [jstr [$ps getOutputSupplyPorts]], \"lib_cell\": \"not mapped (dbPowerSwitch::getLibCell segfaults in this build when no cell is mapped; the library has no switch cell)\"}"
  }
  set isos {}
  foreach is [$block getIsolations] {
    set fields "\"name\": [jstr [$is getName]]"
    foreach m {getIsolationSignal getClampValue getIsolationSense getLocation getAppliesTo} {
      if {![catch {$is $m} v]} { append fields ", \"[string range $m 3 end]\": [jstr $v]" }
    }
    lappend isos "{$fields}"
  }
  set lps {}
  foreach lp [$block getLogicPorts] { lappend lps "{\"name\": [jstr [$lp getName]], \"direction\": [jstr [$lp getDirection]]}" }
  set fh [open $out/$name.json w]
  puts $fh "{\"upf\": [jstr $upf], \"read_upf_rc\": $rc, \"read_upf_msg\": [jstr $msg], \"domains\": \[[join $doms ,]\], \"switches\": \[[join $sws ,]\], \"isolations\": \[[join $isos ,]\], \"logic_ports\": \[[join $lps ,]\], \"lib_iso_cells\": [jstr $iso_cells], \"lib_switch_cells\": [jstr $sw_cells], \"lib_ls_cells\": [jstr $ls_cells], \"lib_ret_cells\": [jstr $ret_cells], \"liberty_scan\": \[[join $lib_scan ,]\], \"modinsts\": [llength $modpaths], \"leaf_total\": [llength [$block getInsts]]}"
  close $fh
}
