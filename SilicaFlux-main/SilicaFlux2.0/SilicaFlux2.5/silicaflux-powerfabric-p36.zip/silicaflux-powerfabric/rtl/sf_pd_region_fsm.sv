// =============================================================================
// SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
// sf_pd_region_fsm : power-state sequencer for ONE logical power region
//
// A target-seeking sequencer: software (or the thermal policy, or boot) sets a
// target (ACTIVE / IDLE / OFF); from every stable state the FSM walks the safe
// path towards it.  Every wait is on an ACKNOWLEDGED condition and is bounded
// by a runtime timeout (pd_cfg_t).  See docs/02_STATE_MACHINE.md.
//
// Capabilities are parameters because they are hardware facts:
//   CLK_GATE    clock-enable control exists (ICG in front of the region clock)
//   SWITCHABLE  power switch + isolation + power-good exist        (FUTURE)
//   LOGIC_RET   retention registers exist                          (FUTURE)
//   HAS_SRAM    region holds SRAM behind the SRAM PM interface
//   SRAM_RET    the SRAM macros have a characterised retention mode
//   MUST_RETAIN SRAM contents must survive OFF unless loss is accepted
//   MBIST_PWRUP run MBIST after power-up, before re-initialisation
//   ABORT_OK    region implements the explicit abort policy
//   BOOT_ON     switchable region is powered up automatically after reset
//   THERM_RESTORE  return to ACTIVE when a thermal hold that idled it clears
// A region with CLK_GATE = 0 and SWITCHABLE = 0 is ALWAYS-ON: status only.
//
// Physical-control outputs are registered (no decode glitches reach ICG or
// isolation enables).  Safety outputs (iso, iso_pm, rst, pwr_en, quiesce) are
// ASYNCHRONOUSLY forced to their safe values by rst_ni; the clock enable is
// SYNCHRONOUSLY reset so a reset can never truncate a gated-clock pulse.
// =============================================================================
module sf_pd_region_fsm #(
  parameter bit CLK_GATE      = 1'b1,
  parameter bit SWITCHABLE    = 1'b0,
  parameter bit LOGIC_RET     = 1'b0,
  parameter bit HAS_SRAM      = 1'b0,
  parameter bit SRAM_RET      = 1'b0,
  parameter bit MUST_RETAIN   = 1'b0,
  parameter bit MBIST_PWRUP   = 1'b0,
  parameter bit ABORT_OK      = 1'b0,
  parameter bit BOOT_ON       = 1'b1,
  parameter bit THERM_RESTORE = 1'b1,
  parameter int NERR          = 10          // == sf_pd_pkg::NUM_ERR (checked below)
) (
  input  logic          clk_i,
  input  logic          rst_ni,          // async assert, release synchronised by the top
  input  sf_pd_pkg::pd_cfg_t       cfg_i,

  // ---------------- command (one-cycle strobe, decoded by the top) ----------
  input  logic          cmd_i,
  input  sf_pd_pkg::pd_target_e    cmd_tgt_i,
  input  logic          cmd_retain_i,     // preserve logic + memory state across OFF
  input  logic          cmd_allow_loss_i, // accept loss of MUST_RETAIN memory contents
  input  logic          cmd_abort_ok_i,   // allow the explicit abort policy for this OFF
  output sf_pd_pkg::pd_evt_e       cmd_rsp_o,        // response to cmd_i (combinational)
  output logic          cmd_done_o,       // 1: nothing further will happen (reject / no-op)
  input  logic          err_clr_i,

  // ---------------- global context ----------------------------------------
  input  logic          dep_leave_ok_i,   // no region that uses this one is in use
  input  logic          dep_enter_ok_i,   // every region this one uses is ACTIVE
  input  logic          therm_hold_i,     // thermal policy wants this region idle
  input  logic          auto_block_i,     // a request is being accepted this cycle: defer autonomous wake-ups
  output logic          pwrup_req_o,      // wants to close its power switch
  input  logic          pwrup_grant_i,    // inrush token (one region powers up at a time)

  // ---------------- region status (synchronous to clk_i) -------------------
  input  logic          busy_i,           // any in-flight state inside the region
  input  logic          q_ack_i,          // quiesce acknowledge (4-phase with quiesce_o)
  input  logic          dma_wr_pend_i,    // fabric: DMA write outstanding to/from region
  input  logic          acc_op_pend_i,    // dispatcher: accelerator op outstanding
  input  logic          abort_ack_i,      // abort complete (queued work cancelled, responses fenced)
  input  logic          clk_ack_i,        // ICG has taken the enable (gated clock state)
  input  logic          pgood_i,          // synchronised power-good (tie 1 if not switchable)
  input  logic          mem_ret_ack_i,    // SRAM in / out of retention
  input  logic          mem_reinit_done_i,// SRAM re-initialisation sweep complete (4-phase)
  input  logic          mbist_done_i,     // power-up MBIST complete (4-phase)
  input  logic          mbist_fail_i,     // qualified by mbist_done_i

  // ---------------- controls ------------------------------------------------
  output logic          clk_en_o,
  output logic          quiesce_o,
  output logic          abort_o,
  output logic          iso_o,            // data-path isolation enable (clamp)
  output logic          iso_pm_o,         // PM-status isolation enable
  output logic          rst_o,            // region reset request
  output logic          pwr_en_o,         // power-switch enable
  output logic          ret_save_o,
  output logic          ret_hold_o,
  output logic          ret_restore_o,
  output logic          mem_ret_o,        // request SRAM retention mode
  output logic          mem_inv_o,        // pulse: SRAM contents invalid (power is being removed)
  output logic          mem_reinit_o,     // request SRAM re-initialisation (4-phase)
  output logic          mem_ecc_clr_o,    // pulse: clear ECC log / scrub state of the region
  output logic          mbist_req_o,      // power-up MBIST request (4-phase)
  output logic          mbist_allow_o,    // external (TestCore) MBIST access permitted

  // ---------------- reporting -----------------------------------------------
  output logic          done_o,           // a commanded / forced transition finished
  output sf_pd_pkg::pd_evt_e       done_code_o,
  output logic [1:0]    done_src_o,       // 1 CMD, 2 THERMAL, 3 BOOT (see W_* below)
  output sf_pd_pkg::pd_status_t    status_o,
  output logic [NERR-1:0] err_o
);
  import sf_pd_pkg::*;
  if (NERR != NUM_ERR) begin : g_err_nerr
    $error("sf_pd_region_fsm: NERR must equal sf_pd_pkg::NUM_ERR");
  end
  // ===========================================================================
  // elaboration checks: capability combinations that cannot be built
  // ===========================================================================
  localparam bit ALWAYS_ON = !CLK_GATE && !SWITCHABLE;
`ifndef SYNTHESIS
  initial begin
    if (SWITCHABLE && !CLK_GATE)
      $fatal(1, "sf_pd_region_fsm: a SWITCHABLE region needs CLK_GATE (clock must stop before isolation)");
    if (LOGIC_RET && !SWITCHABLE)
      $fatal(1, "sf_pd_region_fsm: LOGIC_RET without SWITCHABLE is meaningless");
    if (SRAM_RET && !HAS_SRAM)
      $fatal(1, "sf_pd_region_fsm: SRAM_RET without HAS_SRAM");
    if ((MUST_RETAIN || MBIST_PWRUP) && !HAS_SRAM)
      $fatal(1, "sf_pd_region_fsm: MUST_RETAIN / MBIST_PWRUP need HAS_SRAM");
    if (ABORT_OK && !SWITCHABLE)
      $fatal(1, "sf_pd_region_fsm: the abort policy only applies to power-off (SWITCHABLE)");
  end
`endif
  if (SWITCHABLE && !CLK_GATE) begin : g_err_switch_no_cg
    $error("sf_pd_region_fsm: a SWITCHABLE region needs CLK_GATE");
  end
  if (LOGIC_RET && !SWITCHABLE) begin : g_err_ret
    $error("sf_pd_region_fsm: LOGIC_RET without SWITCHABLE");
  end
  if ((SRAM_RET || MUST_RETAIN || MBIST_PWRUP) && !HAS_SRAM) begin : g_err_sram
    $error("sf_pd_region_fsm: SRAM_RET / MUST_RETAIN / MBIST_PWRUP need HAS_SRAM");
  end
  if (ABORT_OK && !SWITCHABLE) begin : g_err_abort
    $error("sf_pd_region_fsm: ABORT_OK needs SWITCHABLE");
  end

  // RESTORE micro-steps
  localparam logic [3:0] R_CLK = 4'd0, R_RST = 4'd1, R_RREL = 4'd2, R_CSTOP = 4'd3, R_CRUN = 4'd4,
                         R_PMISO = 4'd5, R_MRET = 4'd6, R_MBIST = 4'd7, R_INIT = 4'd8, R_ECC = 4'd9;
  // why a transition is in progress
  localparam logic [1:0] W_NONE = 2'd0, W_CMD = 2'd1, W_THERM = 2'd2, W_BOOT = 2'd3;

  // ===========================================================================
  // state
  // ===========================================================================
  pd_state_e  state_q, state_d;
  logic [3:0] sub_q, sub_d;
  logic [19:0] tmr_q, tmr_d;
  logic [7:0] stab_q, stab_d;
  pd_target_e tgt_q, tgt_d;
  logic [1:0] why_q, why_d;
  logic       retain_q, retain_d;      // this OFF preserves state (logic + SRAM)
  logic       abort_ok_q, abort_ok_d;
  logic       aborted_q, aborted_d;
  logic       busyrej_q, busyrej_d;     // returning to ACTIVE after a failed drain
  logic       deprej_q, deprej_d;       // providers never became ACTIVE: settled in IDLE instead
  logic       ret_f_q, ret_f_d;         // logic retention currently holds state
  logic       mret_f_q, mret_f_d;       // SRAM retention currently holds contents
  logic       lost_q, lost_d;           // SRAM contents invalid
  logic       trest_q, trest_d;         // thermal hold idled this region: restore later
  logic       tfail_q, tfail_d;         // thermal quiesce failed: no retry until hold drops
  logic       fence_q, fence_d;         // abort used: outstanding flags may linger until the fence drains
  logic [NUM_ERR-1:0] err_q, err_set;
  logic       done_d;
  pd_evt_e    done_code_d;
  logic [1:0] done_src_d;

  // registered controls
  logic clk_en_q, quiesce_q, abort_q, iso_q, iso_pm_q, rst_q, pwr_en_q;
  logic ret_save_q, ret_hold_q, ret_restore_q, mem_ret_q, mem_inv_q, mem_reinit_q, mem_ecc_clr_q, mbist_req_q;

  // ===========================================================================
  // helpers
  // ===========================================================================
  function automatic pd_state_e stable_of(pd_target_e t);
    case (t)
      T_IDLE:  stable_of = S_IDLE;
      T_OFF:   stable_of = S_OFF;
      default: stable_of = S_ACTIVE;
    endcase
  endfunction

  logic at_target, stable, in_trans;
  assign at_target = (state_q == stable_of(tgt_q));
  assign stable    = at_target || (state_q == S_FAULT);
  assign in_trans  = !stable;

  // region-internal status is meaningless while PM isolation is on
  logic st_valid;
  assign st_valid = !(SWITCHABLE && iso_pm_q);
  logic busy, q_ack, abort_ack, reinit_done, mb_done, mb_fail;
  assign busy        = st_valid && busy_i;
  assign q_ack       = st_valid && q_ack_i;
  assign abort_ack   = st_valid && abort_ack_i;
  assign reinit_done = st_valid && mem_reinit_done_i;
  assign mb_done     = st_valid && mbist_done_i;
  assign mb_fail     = st_valid && mbist_fail_i;

  logic drained;
  assign drained = q_ack && !busy && !dma_wr_pend_i && !acc_op_pend_i;

  // states in which a switchable region must be powered
  logic need_power;
  assign need_power = SWITCHABLE && !(state_q == S_OFF || state_q == S_POWER_UP || state_q == S_FAULT ||
                                      (state_q == S_POWER_DOWN && sub_q != 4'd0));

  logic tmo_q, tmo_abort, tmo_clk, tmo_pg, tmo_sram;
  assign tmo_q     = tmr_q >= {4'd0, cfg_i.quiesce_timeout};
  assign tmo_abort = tmr_q >= {4'd0, cfg_i.abort_timeout};
  assign tmo_clk   = tmr_q >= {12'd0, cfg_i.clk_ack_timeout};
  assign tmo_pg    = tmr_q >= {4'd0, cfg_i.pgood_timeout};
  assign tmo_sram  = tmr_q >= cfg_i.sram_timeout;
  logic tm_iso, tm_rhold, tm_rrel, tm_ret;
  assign tm_iso   = tmr_q >= {16'd0, cfg_i.iso_settle};
  assign tm_rhold = tmr_q >= {12'd0, cfg_i.rst_hold};
  assign tm_rrel  = tmr_q >= {12'd0, cfg_i.rst_release};
  assign tm_ret   = tmr_q >= {16'd0, cfg_i.ret_pulse};

  // ===========================================================================
  // command decode (pure function of registered state + inputs)
  // ===========================================================================
  logic    leaving;
  pd_evt_e rsp;
  logic    rsp_done, accept;
  always_comb begin
    // restarting a region from FAULT also counts as leaving: it passes through non-ACTIVE states,
    // so no region that uses it may be in use (software idles the users first)
    leaving  = (state_q == S_ACTIVE && cmd_tgt_i != T_ACTIVE) || (state_q == S_IDLE && cmd_tgt_i == T_OFF) ||
               (state_q == S_FAULT);
    rsp      = E_OK;
    rsp_done = 1'b1;
    accept   = 1'b0;
    if (cmd_tgt_i == T_RSVD)                                     rsp = E_REJ_BAD_REQ;
    else if (ALWAYS_ON && cmd_tgt_i == T_ACTIVE)                 rsp = E_OK;
    else if (ALWAYS_ON)                                          rsp = E_REJ_UNSUPPORTED;
    else if (cmd_tgt_i == T_OFF && !SWITCHABLE)                  rsp = E_REJ_UNSUPPORTED;
    else if (cmd_tgt_i == T_OFF && cmd_retain_i &&
             (HAS_SRAM ? !SRAM_RET : !LOGIC_RET))                rsp = E_REJ_UNSUPPORTED;
    else if (in_trans)                                           rsp = E_REJ_IN_TRANS;
    else if (state_q == S_FAULT && |err_q)                       rsp = E_REJ_FAULT;
    else if (cmd_tgt_i == T_OFF && HAS_SRAM && MUST_RETAIN &&
             !cmd_retain_i && !cmd_allow_loss_i)                 rsp = E_REJ_RET_UNAVAIL;
    else if (cmd_tgt_i == T_ACTIVE && therm_hold_i && state_q != S_ACTIVE)
                                                                 rsp = E_REJ_THERMAL;
    else if (leaving && !dep_leave_ok_i)                         rsp = E_REJ_DEPENDENCY;
    else if (cmd_tgt_i == T_ACTIVE && state_q != S_ACTIVE && !dep_enter_ok_i)
                                                                 rsp = E_REJ_DEPENDENCY;
    else if (state_q == stable_of(cmd_tgt_i))                    rsp = E_OK;   // already there
    else begin
      accept   = 1'b1;
      rsp_done = 1'b0;
    end
  end
  assign cmd_rsp_o  = rsp;
  assign cmd_done_o = rsp_done;

  // ===========================================================================
  // next state
  // ===========================================================================
  always_comb begin
    state_d   = state_q;   sub_d   = sub_q;
    tmr_d     = (tmr_q == 20'hFFFFF) ? tmr_q : tmr_q + 20'd1;
    stab_d    = stab_q;
    tgt_d     = tgt_q;     why_d   = why_q;
    retain_d  = retain_q;  abort_ok_d = abort_ok_q;
    aborted_d = aborted_q; busyrej_d  = busyrej_q; deprej_d = deprej_q;
    ret_f_d   = ret_f_q;   mret_f_d   = mret_f_q;   lost_d = lost_q;
    trest_d   = trest_q;   tfail_d    = tfail_q;
    fence_d   = fence_q && (dma_wr_pend_i || acc_op_pend_i);
    err_set   = '0;
    done_d    = 1'b0;      done_code_d = E_OK;  done_src_d = why_q;

    if (!therm_hold_i) tfail_d = 1'b0;

    // ---------------- accepted command / thermal policy (stable states only)
    if (cmd_i && accept) begin
      tgt_d      = cmd_tgt_i;
      why_d      = W_CMD;
      retain_d   = cmd_retain_i && (cmd_tgt_i == T_OFF);
      abort_ok_d = cmd_abort_ok_i && ABORT_OK && (cmd_tgt_i == T_OFF);
      aborted_d  = 1'b0;
      busyrej_d  = 1'b0;
      deprej_d   = 1'b0;
      trest_d    = 1'b0;
    end else if (!ALWAYS_ON && stable && state_q == S_ACTIVE && tgt_q == T_ACTIVE &&
                 therm_hold_i && !tfail_q && dep_leave_ok_i) begin
      tgt_d     = T_IDLE;        // thermal hold: drain and stop the clock
      why_d     = W_THERM;
      retain_d  = 1'b0; abort_ok_d = 1'b0; aborted_d = 1'b0; busyrej_d = 1'b0;
      trest_d   = THERM_RESTORE;
    end else if (!ALWAYS_ON && stable && state_q == S_IDLE && tgt_q == T_IDLE &&
                 !therm_hold_i && trest_q && dep_enter_ok_i && !auto_block_i) begin
      tgt_d     = T_ACTIVE;      // thermal hold cleared: restore
      why_d     = W_THERM;
      trest_d   = 1'b0;
    end

    // ---------------- sequencer
    case (state_q)
      // ------------------------------------------------------------- ACTIVE
      S_ACTIVE: begin
        if (q_ack || abort_ack) err_set[ERR_PROTOCOL] = 1'b1;  // unsolicited / stale ack
        if (tgt_d != T_ACTIVE && !ALWAYS_ON) begin
          state_d = S_QUIESCE; tmr_d = '0; stab_d = '0;
        end
      end
      // ------------------------------------------------------------ QUIESCE
      S_QUIESCE: begin
        stab_d = drained ? ((stab_q == 8'hFF) ? stab_q : stab_q + 8'd1) : 8'd0;
        if (drained && stab_q >= {4'd0, cfg_i.drain_stable}) begin
          state_d = S_CLK_STOP; tmr_d = '0;
        end else if (tmo_q) begin
          err_set[ERR_QUIESCE_TO] = 1'b1;
          if (tgt_q == T_OFF && abort_ok_q) begin
            state_d = S_ABORT; tmr_d = '0;               // explicit abort policy
          end else begin
            tgt_d = T_ACTIVE; busyrej_d = 1'b1;           // nothing lost: back to ACTIVE
            if (why_q == W_THERM) tfail_d = 1'b1;
            state_d = S_RESUME; tmr_d = '0;
          end
        end
      end
      // -------------------------------------------------------------- ABORT
      S_ABORT: begin
        // abort_ack certifies: queued / running accelerator work cancelled and
        // every in-flight fabric transaction either retired or fenced.
        if (abort_ack && q_ack && !busy) begin
          aborted_d = 1'b1; fence_d = 1'b1; err_set[ERR_ABORTED] = 1'b1;
          state_d = S_CLK_STOP; tmr_d = '0;
        end else if (tmo_abort) begin
          err_set[ERR_ABORT_TO] = 1'b1;
          tgt_d = T_ACTIVE; busyrej_d = 1'b1;
          state_d = S_RESUME; tmr_d = '0;
        end
      end
      // ----------------------------------------------------------- CLK_STOP
      S_CLK_STOP: begin
        if (!clk_ack_i) begin
          state_d = S_IDLE; tmr_d = '0;
        end else if (tmo_clk) begin
          err_set[ERR_CLKACK_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0;
        end
      end
      // --------------------------------------------------------------- IDLE
      S_IDLE: begin
        if (busy || !q_ack || (!fence_q && (dma_wr_pend_i || acc_op_pend_i)))
          err_set[ERR_PROTOCOL] = 1'b1;                  // activity in a gated region
        if (tgt_d == T_ACTIVE) begin
          state_d = S_WAKE; tmr_d = '0;
        end else if (tgt_d == T_OFF) begin
          state_d = S_ISOLATE; sub_d = 4'd0; tmr_d = '0;
          mret_f_d = 1'b0;
        end
      end
      // --------------------------------------------------------------- WAKE
      S_WAKE: begin
        if (clk_ack_i) begin
          state_d = S_RESUME; tmr_d = '0;
        end else if (tmo_clk) begin
          err_set[ERR_CLKACK_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0;
        end
      end
      // ------------------------------------------------------------- RESUME
      S_RESUME: begin
        if (!q_ack) begin
          state_d = S_ACTIVE; tmr_d = '0;
        end else if (tmo_q) begin
          err_set[ERR_QUIESCE_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0;
        end
      end
      // ------------------------------------------------------------ ISOLATE
      S_ISOLATE: begin
        case (sub_q)
          4'd0: if (tm_iso) begin sub_d = 4'd1; tmr_d = '0; end
          4'd1: begin                                    // SRAM retention entry (if used)
            if (!(HAS_SRAM && SRAM_RET && retain_q)) begin
              sub_d = 4'd2; tmr_d = '0;
            end else if (mem_ret_ack_i) begin
              mret_f_d = 1'b1; sub_d = 4'd2; tmr_d = '0;
            end else if (tmo_sram) begin
              err_set[ERR_SRAM_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0;
            end
          end
          default: begin                                 // mem_inv pulse issued in this cycle
            if (HAS_SRAM && !mret_f_q) lost_d = 1'b1;
            if (LOGIC_RET && retain_q) begin
              state_d = S_RET_SAVE; sub_d = 4'd0; tmr_d = '0;
            end else begin
              state_d = S_POWER_DOWN; sub_d = 4'd0; tmr_d = '0;
            end
          end
        endcase
      end
      // ----------------------------------------------------------- RET_SAVE
      S_RET_SAVE: begin
        if (sub_q == 4'd0) begin
          if (tm_ret) begin sub_d = 4'd1; tmr_d = '0; ret_f_d = 1'b1; end
        end else if (tm_ret) begin
          state_d = S_POWER_DOWN; sub_d = 4'd0; tmr_d = '0;
        end
      end
      // --------------------------------------------------------- POWER_DOWN
      S_POWER_DOWN: begin
        if (sub_q == 4'd0) begin                         // PM iso + reset settle, switch still on
          if (tm_iso) begin sub_d = 4'd1; tmr_d = '0; end
        end else begin                                   // switch open: wait power-good low
          if (!pgood_i) begin
            state_d = S_OFF; sub_d = 4'd0; tmr_d = '0;
          end else if (tmo_pg) begin
            err_set[ERR_PGOOD_OFF_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0;
          end
        end
      end
      // ---------------------------------------------------------------- OFF
      S_OFF: begin
        if (pgood_i || (!fence_q && (dma_wr_pend_i || acc_op_pend_i))) err_set[ERR_PROTOCOL] = 1'b1;
        if (tgt_d == T_OFF) begin
          tmr_d = '0;                                    // parked
        end else if (dma_wr_pend_i || acc_op_pend_i) begin
          if (tmo_q) begin                               // stale transactions never drained
            err_set[ERR_PROTOCOL] = 1'b1; state_d = S_FAULT; tmr_d = '0;
          end
        end else if (pwrup_grant_i) begin
          state_d = S_POWER_UP; tmr_d = '0; stab_d = '0;
        end
      end
      // ----------------------------------------------------------- POWER_UP
      S_POWER_UP: begin
        if (dma_wr_pend_i || acc_op_pend_i) err_set[ERR_PROTOCOL] = 1'b1;
        stab_d = pgood_i ? ((stab_q == 8'hFF) ? stab_q : stab_q + 8'd1) : 8'd0;
        if (pgood_i && stab_q >= cfg_i.pgood_stable) begin
          state_d = S_RESTORE; sub_d = R_CLK; tmr_d = '0;
        end else if (tmo_pg) begin
          err_set[ERR_PGOOD_ON_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0;   // switch re-opened
        end
      end
      // -------------------------------------------------------- RET_RESTORE
      S_RET_RESTORE: begin
        if (sub_q == 4'd0) begin
          if (tm_ret) begin sub_d = 4'd1; tmr_d = '0; end
        end else if (tm_ret) begin
          ret_f_d = 1'b0; retain_d = 1'b0;
          state_d = S_RESTORE; sub_d = R_CRUN; tmr_d = '0;
        end
      end
      // ------------------------------------------------------------ RESTORE
      S_RESTORE: begin
        case (sub_q)
          R_CLK:   if (clk_ack_i) begin sub_d = R_RST; tmr_d = '0; end
                   else if (tmo_clk) begin err_set[ERR_CLKACK_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0; end
          R_RST:   if (tm_rhold) begin sub_d = R_RREL; tmr_d = '0; end
          R_RREL:  if (tm_rrel) begin sub_d = ret_f_q ? R_CSTOP : R_PMISO; tmr_d = '0; end
          R_CSTOP: if (!clk_ack_i) begin state_d = S_RET_RESTORE; sub_d = 4'd0; tmr_d = '0; end
                   else if (tmo_clk) begin err_set[ERR_CLKACK_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0; end
          R_CRUN:  if (clk_ack_i) begin sub_d = R_PMISO; tmr_d = '0; end
                   else if (tmo_clk) begin err_set[ERR_CLKACK_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0; end
          R_PMISO: if (tm_iso) begin
                     tmr_d = '0;
                     if (!HAS_SRAM)          state_d = S_DEISOLATE;
                     else if (mret_f_q)      sub_d = R_MRET;
                     else if (MBIST_PWRUP)   sub_d = R_MBIST;
                     else                    sub_d = R_INIT;
                   end
          R_MRET:  if (!mem_ret_ack_i) begin mret_f_d = 1'b0; state_d = S_DEISOLATE; tmr_d = '0; end
                   else if (tmo_sram) begin err_set[ERR_SRAM_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0; end
          R_MBIST: if (mb_done) begin
                     tmr_d = '0;
                     if (mb_fail) begin err_set[ERR_MBIST_FAIL] = 1'b1; state_d = S_FAULT; end
                     else sub_d = R_INIT;
                   end else if (tmo_sram) begin err_set[ERR_SRAM_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0; end
          R_INIT:  if (reinit_done) begin sub_d = R_ECC; tmr_d = '0; end
                   else if (tmo_sram) begin err_set[ERR_SRAM_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0; end
          default: begin                                 // R_ECC: ecc-clear pulse this cycle
                     lost_d = 1'b0; state_d = S_DEISOLATE; tmr_d = '0;
                   end
        endcase
      end
      // ---------------------------------------------------------- DEISOLATE
      S_DEISOLATE: begin
        // the 4-phase SRAM handshakes must have returned to idle before use
        // A region becoming ACTIVE releases quiesce only once every region it uses is ACTIVE.
        // Requests were dependency-checked when accepted (and a provider cannot leave while a
        // user is in use); this matters for BOOT power-ups, where providers boot too.
        if (tm_iso && !reinit_done && !mb_done) begin
          if (tgt_q != T_ACTIVE) begin
            state_d = S_CLK_STOP; tmr_d = '0;              // IDLE (or OFF re-requested later)
          end else if (dep_enter_ok_i) begin
            state_d = S_RESUME; tmr_d = '0;
          end else if (tmr_q >= {4'd0, cfg_i.quiesce_timeout} + {16'd0, cfg_i.iso_settle}) begin
            tgt_d = T_IDLE; deprej_d = 1'b1;              // providers never came: settle in IDLE
            state_d = S_CLK_STOP; tmr_d = '0;
          end
        end else if (tmo_sram) begin                     // SRAM handshake never returned to idle
          err_set[ERR_SRAM_TO] = 1'b1; state_d = S_FAULT; tmr_d = '0;
        end
      end
      // -------------------------------------------------------------- FAULT
      default: begin  // S_FAULT
        trest_d = 1'b0;
        if (cmd_i && accept) begin                       // a new command after err_clr
          tmr_d = '0;
          if (SWITCHABLE) begin
            state_d = S_POWER_DOWN; sub_d = 4'd1;        // make sure power is really off
            ret_f_d = 1'b0; mret_f_d = 1'b0; lost_d = HAS_SRAM;
          end else if (tgt_d == T_ACTIVE) state_d = S_WAKE;
          else                            state_d = S_IDLE;
        end
      end
    endcase

    // ---------------- power-good supervision (switchable regions)
    if (need_power && !pgood_i && state_d != S_FAULT) begin
      err_set[ERR_PGOOD_LOST] = 1'b1;
      state_d = S_FAULT; tmr_d = '0;
    end

    // ---------------- completion / failure reporting
    if (state_d != state_q || sub_d != sub_q) stab_d = (state_d == state_q) ? stab_d : 8'd0;
    if (state_d == S_FAULT && state_q != S_FAULT) begin
      ret_f_d = 1'b0; mret_f_d = 1'b0;
      if (SWITCHABLE && HAS_SRAM) lost_d = 1'b1;
      if (why_q != W_NONE || why_d != W_NONE) begin
        done_d = 1'b1;
        done_src_d = (why_d != W_NONE) ? why_d : why_q;
        if (err_set[ERR_PGOOD_ON_TO] || err_set[ERR_PGOOD_OFF_TO] || err_set[ERR_PGOOD_LOST])
          done_code_d = E_ERR_PGOOD;
        else if (err_set[ERR_MBIST_FAIL])
          done_code_d = E_ERR_MBIST;
        else
          done_code_d = E_ERR_TIMEOUT;
      end
      why_d = W_NONE; tgt_d = (SWITCHABLE ? T_OFF : T_IDLE);
      aborted_d = 1'b0; busyrej_d = 1'b0; deprej_d = 1'b0; trest_d = 1'b0;
    end else if (state_d != state_q && state_d == stable_of(tgt_d) && why_d != W_NONE) begin
      done_d      = 1'b1;
      done_src_d  = why_d;
      if (busyrej_d)            done_code_d = E_REJ_BUSY;
      else if (deprej_d)        done_code_d = E_REJ_DEPENDENCY;
      else if (aborted_d)       done_code_d = E_OK_ABORTED;
      else if (why_d == W_THERM) done_code_d = E_OK_THERMAL;
      else                      done_code_d = E_OK;
      why_d = W_NONE; aborted_d = 1'b0; busyrej_d = 1'b0; deprej_d = 1'b0;
    end

    if (ALWAYS_ON) begin
      state_d = S_ACTIVE; tgt_d = T_ACTIVE; why_d = W_NONE; done_d = 1'b0;
    end
  end

  // ===========================================================================
  // registered control outputs: pure function of the NEXT state
  // ===========================================================================
  logic c_clk, c_q, c_ab, c_iso, c_isopm, c_rst, c_pwr, c_rsave, c_rhold, c_rrest;
  logic c_mret, c_minv, c_minit, c_mecc, c_mbist;
  always_comb begin
    c_clk = 1'b0; c_q = 1'b1; c_ab = 1'b0; c_iso = 1'b0; c_isopm = 1'b0; c_rst = 1'b0; c_pwr = 1'b1;
    c_rsave = 1'b0; c_rhold = 1'b0; c_rrest = 1'b0;
    c_mret = 1'b0; c_minv = 1'b0; c_minit = 1'b0; c_mecc = 1'b0; c_mbist = 1'b0;
    case (state_d)
      S_ACTIVE:     begin c_clk = 1'b1; c_q = 1'b0; end
      S_QUIESCE:    begin c_clk = 1'b1; end
      S_ABORT:      begin c_clk = 1'b1; c_ab = 1'b1; end
      S_CLK_STOP, S_IDLE: ;
      S_WAKE:       begin c_clk = 1'b1; end
      S_RESUME:     begin c_clk = 1'b1; c_q = 1'b0; end
      S_ISOLATE:    begin
                      c_iso  = 1'b1;
                      c_mret = (sub_d != 4'd0) && HAS_SRAM && SRAM_RET && retain_d;
                      c_minv = (sub_d == 4'd2) && HAS_SRAM && !mret_f_d;
                    end
      S_RET_SAVE:   begin c_iso = 1'b1; c_rsave = (sub_d == 4'd0); c_rhold = (sub_d != 4'd0); c_mret = mret_f_d; end
      S_POWER_DOWN: begin c_iso = 1'b1; c_isopm = 1'b1; c_rst = 1'b1; c_pwr = (sub_d == 4'd0);
                          c_rhold = ret_f_d; c_mret = mret_f_d; end
      S_OFF:        begin c_iso = 1'b1; c_isopm = 1'b1; c_rst = 1'b1; c_pwr = 1'b0; c_rhold = ret_f_d; c_mret = mret_f_d; end
      S_POWER_UP:   begin c_iso = 1'b1; c_isopm = 1'b1; c_rst = 1'b1; c_rhold = ret_f_d; c_mret = mret_f_d; end
      S_RET_RESTORE:begin c_iso = 1'b1; c_isopm = 1'b1; c_rrest = (sub_d == 4'd0); c_rhold = (sub_d == 4'd0);
                          c_mret = mret_f_d; end
      S_RESTORE:    begin
                      c_iso   = 1'b1;
                      c_clk   = (sub_d != R_CSTOP);
                      c_rst   = (sub_d == R_CLK) || (sub_d == R_RST);
                      c_isopm = (sub_d <= R_CRUN);
                      c_rhold = ret_f_d && (sub_d <= R_CSTOP);
                      c_mret  = mret_f_d && (sub_d < R_MRET);
                      c_mbist = (sub_d == R_MBIST);
                      c_minit = (sub_d == R_INIT);
                      c_mecc  = (sub_d == R_ECC);
                    end
      S_DEISOLATE:  begin c_clk = 1'b1; end
      default:      begin  // S_FAULT
                      if (SWITCHABLE) begin c_iso = 1'b1; c_isopm = 1'b1; c_rst = 1'b1; c_pwr = 1'b0; end
                    end
    endcase
    if (!SWITCHABLE) begin  // single supply: these do not exist
      c_iso = 1'b0; c_isopm = 1'b0; c_rst = 1'b0; c_pwr = 1'b1; c_rsave = 1'b0; c_rhold = 1'b0; c_rrest = 1'b0;
      c_mret = 1'b0; c_minv = 1'b0; c_minit = 1'b0; c_mecc = 1'b0; c_mbist = 1'b0;
    end
    if (!CLK_GATE) c_clk = 1'b1;
    if (ALWAYS_ON) c_q = 1'b0;
  end

  // ===========================================================================
  // registers
  // ===========================================================================
  localparam pd_state_e RST_STATE = SWITCHABLE ? S_POWER_DOWN : S_ACTIVE;
  localparam pd_target_e RST_TGT  = (SWITCHABLE && !BOOT_ON) ? T_OFF : T_ACTIVE;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q   <= RST_STATE;
      sub_q     <= SWITCHABLE ? 4'd1 : 4'd0;   // POWER_DOWN.1: confirm power is off
      tmr_q     <= '0;  stab_q <= '0;
      tgt_q     <= RST_TGT;
      why_q     <= SWITCHABLE ? W_BOOT : W_NONE;
      retain_q  <= 1'b0; abort_ok_q <= 1'b0; aborted_q <= 1'b0; busyrej_q <= 1'b0; deprej_q <= 1'b0;
      ret_f_q   <= 1'b0; mret_f_q <= 1'b0; lost_q <= HAS_SRAM && SWITCHABLE;
      trest_q   <= 1'b0; tfail_q <= 1'b0; fence_q <= 1'b0;
      err_q     <= '0;
      done_o    <= 1'b0; done_code_o <= E_OK; done_src_o <= W_NONE;
      // safety outputs: asynchronously safe
      quiesce_q <= SWITCHABLE;
      abort_q   <= 1'b0;
      iso_q     <= SWITCHABLE;  iso_pm_q <= SWITCHABLE;  rst_q <= SWITCHABLE;
      pwr_en_q  <= !SWITCHABLE;
      ret_save_q <= 1'b0; ret_hold_q <= 1'b0; ret_restore_q <= 1'b0;
      mem_ret_q <= 1'b0; mem_inv_q <= 1'b0; mem_reinit_q <= 1'b0; mem_ecc_clr_q <= 1'b0; mbist_req_q <= 1'b0;
    end else begin
      state_q   <= state_d;  sub_q <= sub_d;  tmr_q <= tmr_d;  stab_q <= stab_d;
      tgt_q     <= tgt_d;    why_q <= why_d;
      retain_q  <= retain_d; abort_ok_q <= abort_ok_d; aborted_q <= aborted_d; busyrej_q <= busyrej_d;
      deprej_q  <= deprej_d;
      ret_f_q   <= ret_f_d;  mret_f_q <= mret_f_d; lost_q <= lost_d;
      trest_q   <= trest_d;  tfail_q <= tfail_d;  fence_q <= fence_d;
      err_q     <= (err_clr_i ? '0 : err_q) | err_set;
      done_o    <= done_d;   done_code_o <= done_code_d;  done_src_o <= done_src_d;
      quiesce_q <= c_q;      abort_q <= c_ab;
      iso_q     <= c_iso;    iso_pm_q <= c_isopm;  rst_q <= c_rst;  pwr_en_q <= c_pwr;
      ret_save_q <= c_rsave; ret_hold_q <= c_rhold; ret_restore_q <= c_rrest;
      mem_ret_q <= c_mret;   mem_inv_q <= c_minv;  mem_reinit_q <= c_minit; mem_ecc_clr_q <= c_mecc;
      mbist_req_q <= c_mbist;
    end
  end

  // ICG enable: synchronous reset (never changes asynchronously w.r.t. clk_i)
  /* verilator lint_off SYNCASYNCNET */
  always_ff @(posedge clk_i) begin
    if (!rst_ni) clk_en_q <= !SWITCHABLE;
    else         clk_en_q <= c_clk;
  end
  /* verilator lint_on SYNCASYNCNET */

  // ===========================================================================
  // outputs
  // ===========================================================================
  assign clk_en_o      = clk_en_q;
  assign quiesce_o     = quiesce_q;
  assign abort_o       = abort_q;
  assign iso_o         = iso_q;
  assign iso_pm_o      = iso_pm_q;
  assign rst_o         = rst_q;
  assign pwr_en_o      = pwr_en_q;
  assign ret_save_o    = ret_save_q;
  assign ret_hold_o    = ret_hold_q;
  assign ret_restore_o = ret_restore_q;
  assign mem_ret_o     = mem_ret_q;
  assign mem_inv_o     = mem_inv_q;
  assign mem_reinit_o  = mem_reinit_q;
  assign mem_ecc_clr_o = mem_ecc_clr_q;
  assign mbist_req_o   = mbist_req_q;
  assign mbist_allow_o = (state_q == S_ACTIVE) && !lost_q;
  assign pwrup_req_o   = SWITCHABLE && (state_q == S_OFF) && (tgt_q != T_OFF) && !dma_wr_pend_i && !acc_op_pend_i;
  assign err_o         = err_q;

  always_comb begin
    status_o            = '0;
    status_o.state      = state_q;
    status_o.arch       = arch_of(state_q);
    status_o.target     = tgt_q;
    status_o.clk_on     = clk_ack_i;
    status_o.pwr_on     = SWITCHABLE ? pgood_i : 1'b1;
    status_o.iso        = iso_q;
    status_o.iso_pm     = iso_pm_q;
    status_o.rst        = rst_q;
    status_o.quiesce    = quiesce_q;
    status_o.ret_hold   = ret_hold_q;
    status_o.mem_lost   = lost_q;
    status_o.therm_hold = therm_hold_i;
    status_o.transition = in_trans;
    status_o.err        = |err_q;
  end
endmodule
