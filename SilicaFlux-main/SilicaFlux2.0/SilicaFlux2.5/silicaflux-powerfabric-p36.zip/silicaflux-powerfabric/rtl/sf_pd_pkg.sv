// =============================================================================
// SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
// sf_pd_pkg : types shared by the power-region controller
//
// Vocabulary
//   region      a logical power region (ControlCore, vector clusters, ...).
//               In the baseline every region shares ONE physical supply (VDD,
//               1.2 V on IHP SG13G2) and differs only in its clock enable.
//   switchable  a region with a real power switch, isolation cells and a
//               power-good ack.  OPTIONAL FUTURE configuration: the target
//               technology (IHP SG13G2) has no switch / isolation / retention /
//               level-shifter cells, so switchable regions exist here only as
//               simulation models (see docs/04 and docs/00_AUDIT.md).
// =============================================================================
package sf_pd_pkg;

  // ---------------------------------------------------------------------------
  // Sequencer state (detailed).  Architectural mapping in arch_of().
  //   forward : ACTIVE -> QUIESCE (-> ABORT) -> CLK_STOP -> IDLE -> ISOLATE
  //             (-> RET_SAVE) -> POWER_DOWN -> OFF
  //   reverse : OFF -> POWER_UP (-> RET_RESTORE) -> RESTORE -> DEISOLATE
  //             -> [CLK_STOP -> IDLE] | [RESUME -> ACTIVE];  IDLE -> WAKE -> RESUME -> ACTIVE
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    S_OFF         = 4'd0,   // POWER_OFF: switch open, power-good low, iso + reset held
    S_POWER_UP    = 4'd1,   // switch closed, waiting for stable power-good
    S_RET_RESTORE = 4'd2,   // retention restore pulse (only where retention exists)
    S_RESTORE     = 4'd3,   // clock on under isolation: reset, PM-iso release, SRAM MBIST/reinit
    S_DEISOLATE   = 4'd4,   // data isolation released, settle
    S_IDLE        = 4'd5,   // powered, quiesced, clock gated
    S_WAKE        = 4'd6,   // clock enabling, waiting for clock ack
    S_RESUME      = 4'd7,   // quiesce released, waiting for quiesce-ack to drop
    S_ACTIVE      = 4'd8,   // powered, clocked, accepting work
    S_QUIESCE     = 4'd9,   // quiesce requested, waiting for complete drain
    S_ABORT       = 4'd10,  // explicit abort policy: waiting for abort ack
    S_CLK_STOP    = 4'd11,  // clock disabling, waiting for clock ack
    S_ISOLATE     = 4'd12,  // data isolation asserted, settle; SRAM retention / invalidate
    S_RET_SAVE    = 4'd13,  // retention save pulse (only where retention exists)
    S_POWER_DOWN  = 4'd14,  // PM isolation + reset asserted, switch opening, wait power-good low
    S_FAULT       = 4'd15   // safe hold after an error (see docs/02 sec. 6)
  } pd_state_e;

  // Architectural (software-visible) states, brief section 4.
  typedef enum logic [2:0] {
    A_ACTIVE     = 3'd0,
    A_QUIESCE    = 3'd1,
    A_IDLE       = 3'd2,
    A_ISOLATE    = 3'd3,
    A_POWER_DOWN = 3'd4,
    A_POWER_OFF  = 3'd5,
    A_POWER_UP   = 3'd6,   // any step of the reverse sequence before IDLE/ACTIVE
    A_FAULT      = 3'd7
  } pd_arch_e;

  // Requested target state of a region.
  typedef enum logic [1:0] {
    T_ACTIVE = 2'd0,
    T_IDLE   = 2'd1,   // clock gated, powered, state kept
    T_OFF    = 2'd2,   // power removed (switchable regions only)
    T_RSVD   = 2'd3
  } pd_target_e;

  // Per-request completion / rejection codes (evt_code_o).
  typedef enum logic [3:0] {
    E_OK              = 4'd0,   // target reached
    E_REJ_UNSUPPORTED = 4'd1,   // op not supported by this region / technology
    E_REJ_IN_TRANS    = 4'd2,   // region already sequencing
    E_REJ_DEPENDENCY  = 4'd3,   // a dependency would be violated
    E_REJ_BUSY        = 4'd4,   // drain did not complete; no abort -> back to ACTIVE, nothing lost
    E_REJ_RET_UNAVAIL = 4'd5,   // memory must retain but no retention exists; loss not accepted
    E_REJ_THERMAL     = 4'd6,   // wake refused while thermal hold is active
    E_REJ_FAULT       = 4'd7,   // region in FAULT with errors still latched
    E_ERR_TIMEOUT     = 4'd8,   // clock-ack / SRAM / abort timeout -> FAULT
    E_ERR_PGOOD       = 4'd9,   // power-good missing, stuck or lost -> FAULT / OFF
    E_OK_ABORTED      = 4'd10,  // target reached using the explicit abort policy
    E_OK_THERMAL      = 4'd11,  // thermal-forced (or auto-restore) transition completed
    E_ERR_MBIST       = 4'd12,  // power-up MBIST failed -> FAULT
    E_REJ_BAD_REQ     = 4'd13   // reserved target encoding
  } pd_evt_e;

  // Sticky error causes (per region).
  localparam int ERR_QUIESCE_TO   = 0;   // quiesce/drain did not complete in time
  localparam int ERR_CLKACK_TO    = 1;   // clock gate did not acknowledge
  localparam int ERR_PGOOD_ON_TO  = 2;   // power-good never arrived at power-up
  localparam int ERR_PGOOD_OFF_TO = 3;   // power-good stuck high at power-down
  localparam int ERR_PGOOD_LOST   = 4;   // power-good dropped while powered
  localparam int ERR_SRAM_TO      = 5;   // SRAM MBIST / reinit / retention ack timeout
  localparam int ERR_MBIST_FAIL   = 6;
  localparam int ERR_PROTOCOL     = 7;   // activity in a gated/off region, stale/unsolicited ack
  localparam int ERR_ABORTED      = 8;   // informational: abort policy was used
  localparam int ERR_ABORT_TO     = 9;   // abort ack never came
  localparam int NUM_ERR          = 10;

  // Runtime timing configuration (cycles of clk_i).  Every wait in the
  // sequencer is on an acknowledged condition AND bounded by one of these.
  typedef struct packed {
    logic [15:0] quiesce_timeout;  // ACTIVE->QUIESCE drain bound
    logic [15:0] abort_timeout;    // abort ack bound
    logic [7:0]  clk_ack_timeout;  // clock gate ack bound
    logic [15:0] pgood_timeout;    // power-good rise / fall bound
    logic [7:0]  pgood_stable;     // consecutive cycles of power-good before use
    logic [3:0]  iso_settle;       // cycles after an isolation change
    logic [7:0]  rst_hold;         // region reset held with clock running
    logic [7:0]  rst_release;      // cycles after reset release (region reset sync)
    logic [3:0]  ret_pulse;        // retention save / restore pulse width
    logic [19:0] sram_timeout;     // MBIST / reinit / SRAM retention ack bound
    logic [3:0]  drain_stable;     // drained condition must hold this many cycles
  } pd_cfg_t;

  // Region status word (software-visible, see docs/register_map in docs/02).
  typedef struct packed {
    pd_state_e  state;       // detailed sequencer state
    pd_arch_e   arch;        // architectural state
    pd_target_e target;      // current target
    logic       clk_on;      // clock enable acknowledged
    logic       pwr_on;      // synchronised power-good (1 for non-switchable)
    logic       iso;         // data isolation asserted
    logic       iso_pm;      // PM-status isolation asserted
    logic       rst;         // region reset requested
    logic       quiesce;     // quiesce requested
    logic       ret_hold;    // logic retention holding state
    logic       mem_lost;    // memory contents invalid (power lost, not yet reinitialised)
    logic       therm_hold;  // thermal hold active for this region
    logic       transition;  // sequencing in progress
    logic       err;         // any sticky error
  } pd_status_t;

  function automatic pd_arch_e arch_of(pd_state_e s);
    case (s)
      S_ACTIVE:                                  arch_of = A_ACTIVE;
      S_QUIESCE, S_ABORT, S_RESUME:              arch_of = A_QUIESCE;
      S_CLK_STOP, S_IDLE, S_WAKE:                arch_of = A_IDLE;
      S_ISOLATE, S_RET_SAVE:                     arch_of = A_ISOLATE;
      S_POWER_DOWN:                              arch_of = A_POWER_DOWN;
      S_OFF:                                     arch_of = A_POWER_OFF;
      S_POWER_UP, S_RET_RESTORE, S_RESTORE,
      S_DEISOLATE:                               arch_of = A_POWER_UP;
      default:                                   arch_of = A_FAULT;
    endcase
  endfunction

  // A region "in use" may be generating or receiving traffic.  Only IDLE, OFF
  // and FAULT are not in use (FAULT holds quiesce + clock off, or iso + reset).
  function automatic logic in_use(pd_state_e s);
    in_use = !(s == S_IDLE || s == S_OFF || s == S_FAULT);
  endfunction

endpackage
