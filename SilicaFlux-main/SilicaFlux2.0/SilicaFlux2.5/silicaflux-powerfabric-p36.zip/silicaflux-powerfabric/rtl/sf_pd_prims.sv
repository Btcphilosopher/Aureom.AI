// =============================================================================
// SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
// sf_pd_prims : synchroniser, reset synchroniser and the clock-gate wrapper
// =============================================================================

/* verilator lint_off DECLFILENAME */
// 2-flop synchroniser for LEVEL signals (each bit independently).  Multi-bit
// values must not be passed through this cell; the controller only crosses
// independent level flags (busy, ack, pending, power-good).
module sf_pd_sync #(
  parameter int           W  = 1,
  parameter logic [W-1:0] RV = '0
) (
  input  logic         clk_i,
  input  logic         rst_ni,
  input  logic [W-1:0] d_i,
  output logic [W-1:0] q_o
);
  (* async_reg = "true" *) logic [W-1:0] s1, s2;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin s1 <= RV; s2 <= RV; end
    else         begin s1 <= d_i; s2 <= s1; end
  end
  assign q_o = s2;
endmodule

// Reset synchroniser: asynchronous assertion, synchronous release.
module sf_pd_rst_sync (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic test_mode_i,
  output logic rst_no
);
  logic r1, r2;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin r1 <= 1'b0; r2 <= 1'b0; end
    else         begin r1 <= 1'b1; r2 <= r1;  end
  end
  assign rst_no = test_mode_i ? rst_ni : r2;
endmodule

// -----------------------------------------------------------------------------
// sf_pd_icg : the only clock-gating point used by POWERFABRIC.
//   SF_PD_IHP_ICG defined : IHP SG13G2 sg13g2_slgcp_1 (latch_posedge_precontrol,
//                           the cell SilicaFlux-V already uses in sfv_clkgate).
//   otherwise              : behavioural latch-based model (simulation / FPGA
//                           prototyping must map this to a BUFGCE).
// en_ack_o is the enable as taken by the gate at the last rising edge of
// clk_i (same clock root as the controller in the baseline).
// -----------------------------------------------------------------------------
module sf_pd_icg (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic en_i,
  input  logic test_en_i,
  output logic gclk_o,
  output logic en_ack_o
);
`ifdef SF_PD_IHP_ICG
  sg13g2_slgcp_1 u_icg (.CLK(clk_i), .GATE(en_i), .SCE(test_en_i), .GCLK(gclk_o));
`else
  logic en_l;
  /* verilator lint_off LATCH */
  always_latch begin
    if (!clk_i) en_l = en_i | test_en_i;
  end
  /* verilator lint_on LATCH */
  assign gclk_o = clk_i & en_l;
`endif
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) en_ack_o <= 1'b0;
    else         en_ack_o <= en_i | test_en_i;
  end
endmodule
