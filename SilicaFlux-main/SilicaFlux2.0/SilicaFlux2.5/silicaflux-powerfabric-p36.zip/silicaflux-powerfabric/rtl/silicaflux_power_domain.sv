// =============================================================================
// SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
// silicaflux_power_domain : power-region controller (power-state requests,
// clock-enable requests, quiesce handshake, isolation / retention requests,
// power-good monitoring, error detection) for the SilicaFlux die.
//
// BASELINE (default parameters): ONE physical supply domain (VDD, 1.2 V on IHP
// SG13G2) with independent clock-enable control per region.  Supported states
// per clock-gated region: ACTIVE <-> QUIESCE <-> IDLE.  OFF requests are refused
// with E_REJ_UNSUPPORTED.  Isolation, reset, switch and retention outputs are
// constants (no such cells exist in the target technology - docs/00_AUDIT.md).
//
// FUTURE (CAP_SWITCH bits set): the full ACTIVE -> QUIESCE -> IDLE -> ISOLATE ->
// POWER_DOWN -> POWER_OFF sequence and its reverse, with isolation, PM-status
// isolation, region reset, power-switch enable, power-good, logic / SRAM
// retention requests, SRAM invalidate / reinit / ECC clear and power-up MBIST.
// This configuration is verified in SIMULATION ONLY against labelled models;
// with ASIC_IMPL = 1 it refuses to elaborate unless the technology declares
// real switch and isolation cells (TECH_* parameters).
//
// Default region map (config/power_regions.yaml is the source of truth):
//   0 CTRL    ControlCore           always-on (status only; it runs the PMU firmware)
//   1 VEC     vector clusters       clock-gated, thermal-throttle eligible
//   2 TNS     tensor clusters       clock-gated, thermal-throttle eligible
//   3 SRAM    shared SRAM           clock-gated, contents MUST be retained
//   4 FABRIC  DataFabric / DMA      clock-gated, only after all its users are idle
//   5 EXTIF   external interfaces   clock-gated
//   6 AON     this controller + reset/clock/thermal control: always-on
// =============================================================================
module silicaflux_power_domain #(
  parameter int          NR              = 7,
  parameter logic [NR-1:0] CAP_CLK_GATE  = 7'b0111110,
  parameter logic [NR-1:0] CAP_SWITCH    = 7'b0000000,
  parameter logic [NR-1:0] CAP_LOGIC_RET = 7'b0000000,
  parameter logic [NR-1:0] CAP_SRAM      = 7'b0001000,
  parameter logic [NR-1:0] CAP_SRAM_RET  = 7'b0000000,
  parameter logic [NR-1:0] CAP_MUST_RETAIN = 7'b0001000,
  parameter logic [NR-1:0] CAP_MBIST_PWRUP = 7'b0000000,
  parameter logic [NR-1:0] CAP_ABORT     = 7'b0000000,
  parameter logic [NR-1:0] CAP_BOOT_ON   = 7'b1111111,
  parameter logic [NR-1:0] THERM_MASK    = 7'b0000110,
  // DEP[u*NR + t] = 1 : region u uses region t (t must be ACTIVE while u is in use)
  parameter logic [NR*NR-1:0] DEP        = {7'b0000000,   // 6 AON
                                            7'b0010000,   // 5 EXTIF  -> FABRIC
                                            7'b0000000,   // 4 FABRIC
                                            7'b0000000,   // 3 SRAM
                                            7'b0011000,   // 2 TNS    -> FABRIC, SRAM
                                            7'b0011000,   // 1 VEC    -> FABRIC, SRAM
                                            7'b0000000},  // 0 CTRL
  parameter bit          THERM_RESTORE   = 1'b1,
  parameter bit          SYNC_STATUS     = 1'b0,  // region status on another clock root
  parameter bit          SUPPLY_MON      = 1'b0,  // a real supply power-good source is wired
  // technology facts (IHP SG13G2 ORFS platform: none of these cells exist)
  parameter bit          TECH_SWITCH_CELLS = 1'b0,
  parameter bit          TECH_ISO_CELLS    = 1'b0,
  parameter bit          TECH_RET_CELLS    = 1'b0,
  parameter bit          ASIC_IMPL         = 1'b0,
  parameter int          NERR              = 10,   // == sf_pd_pkg::NUM_ERR (checked below)
  localparam int         RW = (NR > 1) ? $clog2(NR) : 1
) (
  input  logic                 clk_i,           // always-on control clock
  input  logic                 rst_ni,          // POR / controller reset (async)
  input  logic                 test_mode_i,     // scan: bypass reset synchroniser
  input  sf_pd_pkg::pd_cfg_t              cfg_i,

  // ---------------- power-state request port (one request per cycle) -------
  input  logic                 cmd_valid_i,
  output logic                 cmd_ready_o,
  input  logic [RW-1:0]        cmd_region_i,
  input  sf_pd_pkg::pd_target_e           cmd_target_i,
  input  logic                 cmd_retain_i,
  input  logic                 cmd_allow_loss_i,
  input  logic                 cmd_abort_ok_i,
  output logic                 rsp_valid_o,     // registered response to each request
  output logic [RW-1:0]        rsp_region_o,
  output sf_pd_pkg::pd_evt_e              rsp_code_o,
  output logic                 rsp_final_o,     // 1: no completion event will follow
  input  logic [NR-1:0]        err_clr_i,
  input  logic                 supply_err_clr_i,

  // ---------------- policy inputs ------------------------------------------
  input  logic                 therm_throttle_i, // e.g. POWERCLOCK throttle_active
  input  logic                 supply_pgood_i,   // async (PMIC / supply monitor), tie 1 if none

  // ---------------- region status ------------------------------------------
  input  logic [NR-1:0]        busy_i,
  input  logic [NR-1:0]        q_ack_i,
  input  logic [NR-1:0]        dma_wr_pend_i,
  input  logic [NR-1:0]        acc_op_pend_i,
  input  logic [NR-1:0]        abort_ack_i,
  input  logic [NR-1:0]        clk_ack_i,
  input  logic [NR-1:0]        pgood_i,          // async, per switchable region
  input  logic [NR-1:0]        mem_ret_ack_i,
  input  logic [NR-1:0]        mem_reinit_done_i,
  input  logic [NR-1:0]        mbist_done_i,
  input  logic [NR-1:0]        mbist_fail_i,

  // ---------------- region controls ----------------------------------------
  output logic [NR-1:0]        clk_en_o,
  output logic [NR-1:0]        quiesce_o,
  output logic [NR-1:0]        abort_o,
  output logic [NR-1:0]        iso_o,
  output logic [NR-1:0]        iso_pm_o,
  output logic [NR-1:0]        rst_o,
  output logic [NR-1:0]        pwr_en_o,
  output logic [NR-1:0]        ret_save_o,
  output logic [NR-1:0]        ret_hold_o,
  output logic [NR-1:0]        ret_restore_o,
  output logic [NR-1:0]        mem_ret_o,
  output logic [NR-1:0]        mem_inv_o,
  output logic [NR-1:0]        mem_reinit_o,
  output logic [NR-1:0]        mem_ecc_clr_o,
  output logic [NR-1:0]        mbist_req_o,
  output logic [NR-1:0]        mbist_allow_o,

  // ---------------- reporting -----------------------------------------------
  output logic [NR-1:0]        done_o,
  output logic [NR-1:0][3:0]   done_code_o,
  output logic [NR-1:0][1:0]   done_src_o,      // 1 request, 2 thermal policy, 3 boot
  output sf_pd_pkg::pd_status_t [NR-1:0]  status_o,
  output logic [NR-1:0][NERR-1:0]  err_o,
  output logic                 supply_err_o,
  output logic                 irq_o
);
  import sf_pd_pkg::*;
  if (NERR != NUM_ERR) begin : g_err_nerr
    $error("silicaflux_power_domain: NERR must equal sf_pd_pkg::NUM_ERR");
  end
  // ===========================================================================
  // elaboration checks
  // ===========================================================================
`ifndef SYNTHESIS
  initial begin
    for (int u = 0; u < NR; u++)
      if (DEP[u*NR + u]) $fatal(1, "silicaflux_power_domain: region %0d depends on itself", u);
    if (|(CAP_SWITCH & ~CAP_CLK_GATE))
      $fatal(1, "silicaflux_power_domain: switchable regions must be clock-gated");
    if (ASIC_IMPL && |CAP_SWITCH && !(TECH_SWITCH_CELLS && TECH_ISO_CELLS))
      $fatal(1, "silicaflux_power_domain: CAP_SWITCH set but the technology declares no power-switch/isolation cells (IHP SG13G2 has none). Power gating is a FUTURE configuration: simulation only.");
    if (ASIC_IMPL && |CAP_LOGIC_RET && !TECH_RET_CELLS)
      $fatal(1, "silicaflux_power_domain: CAP_LOGIC_RET set but the technology declares no retention cells");
    if (|(CAP_SRAM_RET & ~CAP_SRAM))
      $fatal(1, "silicaflux_power_domain: CAP_SRAM_RET without CAP_SRAM");
  end
`endif

  // elaboration-time guards (Verilator / Yosys stop here; Icarus relies on the
  // initial-block $fatal above at time 0)
  if (ASIC_IMPL && |CAP_SWITCH && !(TECH_SWITCH_CELLS && TECH_ISO_CELLS)) begin : g_err_no_switch_cells
    $error("silicaflux_power_domain: CAP_SWITCH needs power-switch and isolation cells; the technology declares none (IHP SG13G2). Power gating is a FUTURE, simulation-only configuration.");
  end
  if (ASIC_IMPL && |CAP_LOGIC_RET && !TECH_RET_CELLS) begin : g_err_no_ret_cells
    $error("silicaflux_power_domain: CAP_LOGIC_RET needs retention cells; the technology declares none");
  end
  if (|(CAP_SWITCH & ~CAP_CLK_GATE)) begin : g_err_switch_without_clock_gate
    $error("silicaflux_power_domain: switchable regions must be clock-gated");
  end

  // ===========================================================================
  // reset: async assert, synchronous release
  // ===========================================================================
  logic rst_n;
  sf_pd_rst_sync u_rst (.clk_i, .rst_ni, .test_mode_i, .rst_no(rst_n));

  // ===========================================================================
  // synchronisers
  // ===========================================================================
  // power-good resets to 1 ("may still be powered"): after a reset the
  // controller must observe a genuine power-good LOW before it treats a
  // region as off (a 0 reset value made a decaying rail look off - found by
  // the reset_mid_transition test).
  logic [NR-1:0] pgood_s;
  sf_pd_sync #(.W(NR), .RV('1)) u_sync_pg (.clk_i, .rst_ni(rst_n), .d_i(pgood_i), .q_o(pgood_s));

  logic supply_pg_s;
  sf_pd_sync #(.W(1), .RV(1'b1)) u_sync_sup (.clk_i, .rst_ni(rst_n), .d_i(supply_pgood_i), .q_o(supply_pg_s));

  logic [NR-1:0] busy_s, q_ack_s, dma_s, acc_s, ab_s, cack_s, mret_s, minit_s, mbd_s, mbf_s;
  if (SYNC_STATUS) begin : g_sync
    sf_pd_sync #(.W(10*NR), .RV('0)) u_sync_st (.clk_i, .rst_ni(rst_n),
      .d_i({busy_i, q_ack_i, dma_wr_pend_i, acc_op_pend_i, abort_ack_i, clk_ack_i,
            mem_ret_ack_i, mem_reinit_done_i, mbist_done_i, mbist_fail_i}),
      .q_o({busy_s, q_ack_s, dma_s, acc_s, ab_s, cack_s, mret_s, minit_s, mbd_s, mbf_s}));
  end else begin : g_nosync
    assign {busy_s, q_ack_s, dma_s, acc_s, ab_s, cack_s, mret_s, minit_s, mbd_s, mbf_s} =
           {busy_i, q_ack_i, dma_wr_pend_i, acc_op_pend_i, abort_ack_i, clk_ack_i,
            mem_ret_ack_i, mem_reinit_done_i, mbist_done_i, mbist_fail_i};
  end

  // ===========================================================================
  // request decode
  // ===========================================================================
  logic          cmd_ok_region;
  logic [NR-1:0] cmd_hit;
  assign cmd_ready_o   = 1'b1;
  assign cmd_ok_region = (32'(cmd_region_i) < NR);
  always_comb begin
    cmd_hit = '0;
    if (cmd_valid_i && cmd_ok_region) cmd_hit[cmd_region_i] = 1'b1;
  end

  // ===========================================================================
  // dependencies and inrush arbitration (from registered region states)
  // ===========================================================================
  pd_status_t [NR-1:0] st;
  logic [NR-1:0] r_in_use, r_active, dep_leave_ok, dep_enter_ok, pwrup_req, pwrup_grant;
  always_comb begin
    for (int r = 0; r < NR; r++) begin
      r_in_use[r] = in_use(st[r].state);
      r_active[r] = (st[r].state == S_ACTIVE);
    end
    for (int t = 0; t < NR; t++) begin
      dep_leave_ok[t] = 1'b1;
      dep_enter_ok[t] = 1'b1;
      for (int u = 0; u < NR; u++) begin
        if (DEP[u*NR + t] && r_in_use[u]) dep_leave_ok[t] = 1'b0;   // a user of t is in use
        if (DEP[t*NR + u] && !r_active[u]) dep_enter_ok[t] = 1'b0;  // t needs u ACTIVE
      end
    end
  end

  // one power-up at a time (inrush).  Providers first: a requester is "ready" when no region it
  // uses is itself waiting to power up or ramping; the lowest-index ready requester wins, and if
  // none is ready the lowest-index requester wins (never deadlocks).
  logic any_pwrup;
  logic [NR-1:0] pwrup_ready, ramping;
  always_comb begin
    any_pwrup   = 1'b0;
    for (int r = 0; r < NR; r++) begin
      ramping[r] = (st[r].state == S_POWER_UP);
      if (ramping[r]) any_pwrup = 1'b1;
    end
    for (int r = 0; r < NR; r++) begin
      pwrup_ready[r] = pwrup_req[r];
      for (int t = 0; t < NR; t++)
        if (DEP[r*NR + t] && (pwrup_req[t] || ramping[t])) pwrup_ready[r] = 1'b0;
    end
    pwrup_grant = '0;
    if (!any_pwrup) begin
      if (|pwrup_ready) begin
        for (int r = NR-1; r >= 0; r--) if (pwrup_ready[r]) pwrup_grant = NR'(1) << r;
      end else begin
        for (int r = NR-1; r >= 0; r--) if (pwrup_req[r]) pwrup_grant = NR'(1) << r;
      end
    end
  end

  // ===========================================================================
  // regions
  // ===========================================================================
  pd_evt_e [NR-1:0] rsp_r;
  logic    [NR-1:0] rsp_done_r;
  pd_evt_e [NR-1:0] done_code_r;

  for (genvar r = 0; r < NR; r++) begin : g_reg
    sf_pd_region_fsm #(
      .CLK_GATE(CAP_CLK_GATE[r]), .SWITCHABLE(CAP_SWITCH[r]), .LOGIC_RET(CAP_LOGIC_RET[r]),
      .HAS_SRAM(CAP_SRAM[r]), .SRAM_RET(CAP_SRAM_RET[r]), .MUST_RETAIN(CAP_MUST_RETAIN[r]),
      .MBIST_PWRUP(CAP_MBIST_PWRUP[r]), .ABORT_OK(CAP_ABORT[r]), .BOOT_ON(CAP_BOOT_ON[r]),
      .THERM_RESTORE(THERM_RESTORE)
    ) u_fsm (
      .clk_i, .rst_ni(rst_n), .cfg_i,
      .cmd_i(cmd_hit[r]), .cmd_tgt_i(cmd_target_i), .cmd_retain_i, .cmd_allow_loss_i,
      .cmd_abort_ok_i, .cmd_rsp_o(rsp_r[r]), .cmd_done_o(rsp_done_r[r]), .err_clr_i(err_clr_i[r]),
      .dep_leave_ok_i(dep_leave_ok[r]), .dep_enter_ok_i(dep_enter_ok[r]),
      .therm_hold_i(therm_throttle_i && THERM_MASK[r]),
      // Autonomous (thermal auto-restore) wake-ups are deferred by one cycle whenever a request is
      // accepted: both check dependencies against REGISTERED states, so a restore of a user and a
      // request idling its provider in the same cycle would each see the other's old state.
      .auto_block_i(cmd_valid_i),
      .pwrup_req_o(pwrup_req[r]), .pwrup_grant_i(pwrup_grant[r]),
      .busy_i(busy_s[r]), .q_ack_i(q_ack_s[r]), .dma_wr_pend_i(dma_s[r]), .acc_op_pend_i(acc_s[r]),
      .abort_ack_i(ab_s[r]), .clk_ack_i(cack_s[r]),
      .pgood_i(CAP_SWITCH[r] ? pgood_s[r] : 1'b1),
      .mem_ret_ack_i(mret_s[r]), .mem_reinit_done_i(minit_s[r]),
      .mbist_done_i(mbd_s[r]), .mbist_fail_i(mbf_s[r]),
      .clk_en_o(clk_en_o[r]), .quiesce_o(quiesce_o[r]), .abort_o(abort_o[r]),
      .iso_o(iso_o[r]), .iso_pm_o(iso_pm_o[r]), .rst_o(rst_o[r]), .pwr_en_o(pwr_en_o[r]),
      .ret_save_o(ret_save_o[r]), .ret_hold_o(ret_hold_o[r]), .ret_restore_o(ret_restore_o[r]),
      .mem_ret_o(mem_ret_o[r]), .mem_inv_o(mem_inv_o[r]), .mem_reinit_o(mem_reinit_o[r]),
      .mem_ecc_clr_o(mem_ecc_clr_o[r]), .mbist_req_o(mbist_req_o[r]), .mbist_allow_o(mbist_allow_o[r]),
      .done_o(done_o[r]), .done_code_o(done_code_r[r]), .done_src_o(done_src_o[r]),
      .status_o(st[r]), .err_o(err_o[r])
    );
    assign done_code_o[r] = done_code_r[r];
  end
  assign status_o = st;

  // ===========================================================================
  // response channel (registered; never collides with completion events)
  // ===========================================================================
  always_ff @(posedge clk_i or negedge rst_n) begin
    if (!rst_n) begin
      rsp_valid_o  <= 1'b0;
      rsp_region_o <= '0;
      rsp_code_o   <= E_OK;
      rsp_final_o  <= 1'b0;
    end else begin
      rsp_valid_o  <= cmd_valid_i;
      if (cmd_valid_i) begin
        rsp_region_o <= cmd_region_i;
        rsp_code_o   <= cmd_ok_region ? rsp_r[cmd_region_i] : E_REJ_BAD_REQ;
        rsp_final_o  <= cmd_ok_region ? rsp_done_r[cmd_region_i] : 1'b1;
      end
    end
  end

  // ===========================================================================
  // supply monitor and interrupt
  // ===========================================================================
  always_ff @(posedge clk_i or negedge rst_n) begin
    if (!rst_n)                             supply_err_o <= 1'b0;
    else if (SUPPLY_MON && !supply_pg_s)    supply_err_o <= 1'b1;
    else if (supply_err_clr_i)              supply_err_o <= 1'b0;
  end

  logic any_err;
  always_comb begin
    any_err = supply_err_o;
    for (int r = 0; r < NR; r++) any_err = any_err | (|err_o[r]);
  end
  assign irq_o = any_err;
endmodule
