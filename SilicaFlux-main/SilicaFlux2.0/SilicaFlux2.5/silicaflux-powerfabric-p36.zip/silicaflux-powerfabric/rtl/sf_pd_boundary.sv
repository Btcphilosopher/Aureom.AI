// =============================================================================
// SilicaFlux-HPC | Project 36 POWERFABRIC | Aureom.AI
// sf_pd_boundary : isolation and level-shifter wrappers for a region boundary
//
// READ THIS FIRST.  A Boolean "iso ? clamp : d" is NOT a physical isolation
// cell.  A real isolation cell
//   * is powered from the RECEIVING (always-on) supply,
//   * has an input stage that tolerates a floating / unpowered driver without
//     crowbar current,
//   * is placed in the always-on domain (or is a dual-rail cell) and its
//     enable is routed on always-on supply,
//   * is characterised (Liberty is_isolation_cell / isolation_cell_enable_pin,
//     pg_pin related supplies) so implementation and UPF checks recognise it.
// Synthesising the functional model would produce an ordinary AND/OR gate on
// whatever supply it is placed on - electrically meaningless once the driving
// region is unpowered.  The IHP SG13G2 standard-cell library (ORFS ab2aaf0f and
// d0e5b3c, 78 / 84 cells) has NO isolation, level-shifter, power-switch,
// retention or always-on cells (reports/tech_cell_audit.md).  Therefore:
//
//   SF_PD_TECH_ISO / SF_PD_TECH_LS defined : instantiate the integrator-written
//       technology wrappers sf_pd_iso_lib_cell / sf_pd_ls_lib_cell (black boxes
//       here; they must map to characterised cells of a library that has them).
//   otherwise : FUNCTIONAL MODEL for simulation.  With ALLOW_FUNCTIONAL = 0
//       (ASIC implementation of a switchable region) elaboration fails.
// =============================================================================

/* verilator lint_off DECLFILENAME */
module sf_pd_iso_cell #(
  parameter bit CLAMP            = 1'b0,   // value driven while isolated
  parameter bit ALLOW_FUNCTIONAL = 1'b1
) (
  input  logic d_i,      // from the switchable (possibly unpowered) region
  input  logic iso_i,    // isolation enable, always-on, active high
  output logic q_o       // to the always-on side
);
`ifdef SF_PD_TECH_ISO
  sf_pd_iso_lib_cell #(.CLAMP(CLAMP)) u_cell (.d_i, .iso_i, .q_o);
`else
`ifndef SYNTHESIS
  initial if (!ALLOW_FUNCTIONAL)
    $fatal(1, "sf_pd_iso_cell: functional isolation model used where a physical isolation cell is required (no isolation cells in this technology)");
`endif
  if (!ALLOW_FUNCTIONAL) begin : g_err_functional_iso
    $error("sf_pd_iso_cell: functional isolation model used where a physical isolation cell is required (no isolation cells in this technology)");
  end
  // FUNCTIONAL MODEL - not a physical isolation cell (see header).
  assign q_o = iso_i ? CLAMP : d_i;
`endif
endmodule

module sf_pd_level_shifter #(
  parameter bit ALLOW_FUNCTIONAL = 1'b1
) (
  input  logic d_i,      // source-voltage domain
  output logic q_o       // destination-voltage domain
);
`ifdef SF_PD_TECH_LS
  sf_pd_ls_lib_cell u_cell (.d_i, .q_o);
`else
`ifndef SYNTHESIS
  initial if (!ALLOW_FUNCTIONAL)
    $fatal(1, "sf_pd_level_shifter: functional model used where a voltage crossing exists (no level-shifter cells in this technology)");
`endif
  if (!ALLOW_FUNCTIONAL) begin : g_err_functional_ls
    $error("sf_pd_level_shifter: functional model used where a voltage crossing exists (no level-shifter cells in this technology)");
  end
  // FUNCTIONAL MODEL: a wire.  The baseline is single-voltage (1.2 V); the only
  // real voltage crossings on the die are inside the sg13g2_IOPad* cells
  // (1.2 V core / 3.3 V IO), which already contain their level shifters.
  assign q_o = d_i;
`endif
endmodule

// A bank of boundary cells for one region's outputs.  Optional level shifting
// (NEEDS_LS) is placed BEFORE isolation in the source domain order
// "region -> LS -> ISO -> always-on", matching a UPF  -location parent  rule.
module sf_pd_boundary #(
  parameter int           W                = 8,
  parameter logic [W-1:0] CLAMP            = '0,
  parameter bit           NEEDS_LS         = 1'b0,
  parameter bit           ALLOW_FUNCTIONAL = 1'b1
) (
  input  logic [W-1:0] d_i,
  input  logic         iso_i,
  output logic [W-1:0] q_o
);
  for (genvar i = 0; i < W; i++) begin : g_bit
    logic ls;
    if (NEEDS_LS) begin : g_ls
      sf_pd_level_shifter #(.ALLOW_FUNCTIONAL(ALLOW_FUNCTIONAL)) u_ls (.d_i(d_i[i]), .q_o(ls));
    end else begin : g_nols
      assign ls = d_i[i];
    end
    sf_pd_iso_cell #(.CLAMP(CLAMP[i]), .ALLOW_FUNCTIONAL(ALLOW_FUNCTIONAL)) u_iso (
      .d_i(ls), .iso_i, .q_o(q_o[i]));
  end
endmodule
