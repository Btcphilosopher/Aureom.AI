# 02 — Power-state controller: interface, state machine, safe transitions (brief §3, §4)

`rtl/silicaflux_power_domain.sv` (top) instantiates one `rtl/sf_pd_region_fsm.sv` per region. All control logic runs
on the always-on clock `clk_i`. Region status inputs are synchronous to it by default (`SYNC_STATUS = 0`: region
clocks are gated copies of the same root, as in DieTop); with `SYNC_STATUS = 1` every status flag passes a 2-flop
synchroniser (they are independent level flags, never multi-bit values). `pgood_i` (async) and `supply_pgood_i` are
always synchronised.

## 1. Interface

| Group | Signals (per region `[NR-1:0]` unless noted) | Meaning |
|---|---|---|
| Power-state request | `cmd_valid_i`, `cmd_region_i`, `cmd_target_i` {ACTIVE, IDLE, OFF}, `cmd_retain_i`, `cmd_allow_loss_i`, `cmd_abort_ok_i`; `cmd_ready_o` = 1 | one request per cycle (a PMU register write) |
| Response | `rsp_valid_o`, `rsp_region_o`, `rsp_code_o`, `rsp_final_o` (registered, next cycle) | accepted (`E_OK`, final = 0 → a completion event follows), no-op (`E_OK`, final = 1) or rejected |
| Completion events | `done_o`, `done_code_o`, `done_src_o` {1 request, 2 thermal policy, 3 boot} | never collide with responses (separate channel) |
| Clock-enable | `clk_en_o` → `sf_pd_icg`; `clk_ack_i` ← its `en_ack_o` | registered, **synchronously** reset (a reset can never truncate a gated-clock pulse) |
| Quiesce handshake | `quiesce_o` / `q_ack_i` (4-phase); `busy_i`; `dma_wr_pend_i` (fabric); `acc_op_pend_i` (dispatcher) | drain = `q_ack ∧ ¬busy ∧ ¬dma_wr_pend ∧ ¬acc_op_pend` for `drain_stable` cycles |
| Abort | `abort_o` / `abort_ack_i` | explicit abort policy (OFF only, `CAP_ABORT` and `cmd_abort_ok_i`) |
| Isolation | `iso_o` (data outputs), `iso_pm_o` (PM-status outputs) | FUTURE only; constant 0 in the baseline |
| Region reset / switch | `rst_o`, `pwr_en_o`, `pgood_i` | FUTURE only; `pwr_en_o` = 1, `rst_o` = 0 in the baseline |
| Retention | `ret_save_o`, `ret_hold_o`, `ret_restore_o` | FUTURE + `CAP_LOGIC_RET` only |
| SRAM | `mem_ret_o`/`mem_ret_ack_i`, `mem_inv_o`, `mem_reinit_o`/`mem_reinit_done_i`, `mem_ecc_clr_o`, `mbist_req_o`/`mbist_done_i`/`mbist_fail_i`, `mbist_allow_o` | doc 03 |
| Policy | `therm_throttle_i`, `supply_pgood_i` | thermal hold for `THERM_MASK` regions; supply monitor (`SUPPLY_MON`) |
| Status / errors | `status_o` (`pd_status_t`: state, arch state, target, clk_on, pwr_on, iso, iso_pm, rst, quiesce, ret_hold, mem_lost, therm_hold, transition, err), `err_o` (sticky causes), `supply_err_o`, `irq_o`; `err_clr_i`, `supply_err_clr_i` | |
| Timing | `cfg_i` (`pd_cfg_t`): quiesce / abort / clock-ack / power-good / SRAM timeouts, power-good stable count, isolation settle, reset hold / release, retention pulse, drain-stable count | every wait is bounded |

## 2. States

| Detailed state | Architectural | Clock | Quiesce | Iso | Iso PM | Reset | Switch |
|---|---|---|---|---|---|---|---|
| ACTIVE | ACTIVE | on | 0 | 0 | 0 | 0 | on |
| QUIESCE / ABORT | QUIESCE | on | 1 | 0 | 0 | 0 | on |
| CLK_STOP, IDLE, WAKE | IDLE | off (WAKE: on) | 1 | 0 | 0 | 0 | on |
| RESUME | QUIESCE | on | 0 | 0 | 0 | 0 | on |
| ISOLATE, RET_SAVE | ISOLATE | off | 1 | 1 | 0 | 0 | on |
| POWER_DOWN | POWER_DOWN | off | 1 | 1 | 1 | 1 | on → off |
| OFF | POWER_OFF | off | 1 | 1 | 1 | 1 | off |
| POWER_UP, RET_RESTORE, RESTORE, DEISOLATE | POWER_UP | (see below) | 1 | 1 | 1 → 0 | 1 → 0 | on |
| FAULT | FAULT | off | 1 | 1 (switchable) | 1 | 1 | off (switchable) |

Every physical control is a **registered** function of the *next* state (no decode glitch reaches an ICG or isolation
enable). Safety outputs (iso, iso_pm, rst, pwr_en, quiesce) are **asynchronously** forced safe by reset.

## 3. Forward sequence (ACTIVE → POWER_OFF)

1. **QUIESCE** — `quiesce_o` = 1; wait for the drained condition for `drain_stable` cycles. On `quiesce_timeout`:
   with `target = OFF`, `abort_ok` and `CAP_ABORT` → **ABORT**; otherwise **back to ACTIVE** (`E_REJ_BUSY`, `ERR_QUIESCE_TO`,
   nothing lost).
2. **ABORT** — `abort_o` = 1; wait `abort_ack ∧ q_ack ∧ ¬busy`. `abort_ack` certifies that queued / running operations are
   cancelled and every in-flight fabric transaction is retired or **fenced** (DieTop `die_sfb_rst_fence`). The
   controller then tolerates `dma_wr_pend`/`acc_op_pend` (fence flag) and **refuses to power the region up again until
   they have drained**. Timeout → back to ACTIVE (`E_REJ_BUSY`, `ERR_ABORT_TO`).
3. **CLK_STOP → IDLE** — clock enable low, wait for the gate acknowledge (timeout → FAULT).
4. **ISOLATE** — data isolation on, settle; SRAM retention entry (`mem_ret`/`ack`) if retained, else `mem_inv` pulse.
5. **RET_SAVE** (logic retention only) — save pulse with the clock stopped, then `ret_hold`.
6. **POWER_DOWN** — PM-status isolation and region reset on, settle, *then* the switch opens; wait for power-good low
   (timeout → FAULT `ERR_PGOOD_OFF_TO`).
7. **OFF**.

**A power-off never happens while DMA writes or accelerator operations are outstanding** unless step 2 (explicit,
per-request, per-region abort policy) was taken — checked continuously by the testbench invariant checker and by
mutants M01/M02/M03 (doc 08).

## 4. Reverse sequence (POWER_OFF → ACTIVE)

1. **OFF** — wait for the power-up token (one region ramps at a time) and for any fenced traffic to drain.
2. **POWER_UP** — switch on (isolation and reset still on); wait for power-good stable `pgood_stable` cycles (timeout →
   FAULT, switch re-opened, `E_ERR_PGOOD`).
3. **RESTORE** — clock on → reset held `rst_hold` → reset released → [retained: clock off → **RET_RESTORE** → clock on] →
   PM-status isolation off → SRAM: [retained: leave retention] or [MBIST (optional) → re-initialisation sweep → ECC
   clear]. Each wait bounded (clock-ack / SRAM timeouts → FAULT).
4. **DEISOLATE** — data isolation off, settle, 4-phase SRAM handshakes back to idle; for target ACTIVE, wait until every
   region this one uses is ACTIVE (boot ordering). If the providers do not come within `quiesce_timeout`, the region
   settles in IDLE and reports `E_REJ_DEPENDENCY`.
5. **RESUME** — quiesce released; wait for the quiesce ack to drop → **ACTIVE**. (Target IDLE: CLK_STOP → IDLE.)

The power-up token is granted **providers first** (doc 01), and autonomous wake-ups are deferred in any cycle in which a
request is accepted (`auto_block_i`).

## 5. Faults, errors and reset

* Power-good lost while a switchable region needs power → immediately FAULT (isolated, reset, switch off),
  `ERR_PGOOD_LOST`, IRQ. Region status is ignored while PM isolation is on.
* `FAULT` is left only by a new request after `err_clr`, and only when no region that uses this one is in use
  (software idles the users first); switchable regions first re-confirm power is off.
* Protocol errors (`ERR_PROTOCOL`): quiesce/abort ack while not requested; busy / outstanding work / missing quiesce ack
  while IDLE; outstanding unfenced traffic or power-good high while OFF.
* **Reset** (`rst_ni`) is the die's global reset (the dispatcher and fabric reset with it). Non-switchable regions come
  out ACTIVE with their clock enabled; switchable regions come out in POWER_DOWN with the switch open and wait for a
  genuine power-good low before OFF → boot power-up. The power-good synchroniser resets to **1** ("may still be
  powered") — a 0 reset value made a decaying rail look off right after reset (found by the `reset_mid_transition`
  test, kept as mutant M16).

## 6. Response / completion codes

`E_OK`, `E_REJ_UNSUPPORTED` (OFF on a non-switchable region, any change of an always-on region, retention where the
technology has none), `E_REJ_IN_TRANS`, `E_REJ_DEPENDENCY`, `E_REJ_BUSY`, `E_REJ_RET_UNAVAIL`, `E_REJ_THERMAL`,
`E_REJ_FAULT`, `E_ERR_TIMEOUT`, `E_ERR_PGOOD`, `E_OK_ABORTED`, `E_OK_THERMAL`, `E_ERR_MBIST`, `E_REJ_BAD_REQ`.
Sticky error causes: `ERR_QUIESCE_TO`, `ERR_CLKACK_TO`, `ERR_PGOOD_ON_TO`, `ERR_PGOOD_OFF_TO`, `ERR_PGOOD_LOST`,
`ERR_SRAM_TO`, `ERR_MBIST_FAIL`, `ERR_PROTOCOL`, `ERR_ABORTED` (informational), `ERR_ABORT_TO`.

## 7. Integration notes

* `busy_i` must cover *all* in-flight state of the region (PowerClock contract); `q_ack_i` is the region's own
  "quiesced" (no accepted work left); `acc_op_pend_i` comes from the dispatcher and covers operations **issued but not
  yet visible to the region** (in transit) — the testbench models this transit latency, and mutant M02 shows the check
  is needed; `dma_wr_pend_i` comes from the fabric and covers writes *to or from* the region.
* `clk_ack_i` comes from `sf_pd_icg.en_ack_o` (the enable as taken by the gate at the last edge).
* The controller does **not** replace PowerClock or the ControlCore PMU: PowerClock keeps issue-rate throttling and
  DVFS status; the PMU firmware drives this controller's request port.
