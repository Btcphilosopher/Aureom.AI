# 03 — SRAM retention, re-initialisation, invalidation, ECC, MBIST (brief §5)

## What the technology provides

The IHP `RM_IHPSG13_1P_*_c2_bm_bist` macros have three supply pins — `VDD!` (periphery), `VDDARRAY!` (array), `VSS!` —
but their Liberty declares **both `VDD` and `VDDARRAY` as `primary_power`**, with no retention / `power_down_function`
attribute, and SRAMGrid records "no macro has sleep / retention / repair pins". A separate array supply pin is not a
characterised retention mode. **No SRAM retention is claimed**: `CAP_SRAM_RET = 0` for every region on this technology,
and `VDDARRAY!` is tied to `VDD` in both the UPF and the PDN (doc 05, 06).

## Policy per memory

| Memory | Policy | Behaviour of the controller |
|---|---|---|
| Shared SRAM (`MUST_RETAIN`) | must retain | OFF is refused with `E_REJ_RET_UNAVAIL` unless the request carries `retain` (only possible with `CAP_SRAM_RET`) or `allow_loss`. In the baseline the region is not switchable at all (OFF → `E_REJ_UNSUPPORTED`). |
| Vector SPM, tensor buffers | discard | invalidated on power-down, re-initialised on power-up. |
| ControlCore RAM | must retain | region is always-on. |

## Interface (`HAS_SRAM` regions)

| Signal | Protocol | When |
|---|---|---|
| `mem_ret_o` / `mem_ret_ack_i` | level request / ack | enter SRAM retention in ISOLATE (only with `CAP_SRAM_RET` and `retain`); leave it in RESTORE |
| `mem_inv_o` | 1-cycle pulse | ISOLATE, before power is removed, when contents will be lost: software-visible "contents invalid", cache / tag valid bits cleared; `status.mem_lost` = 1 until re-initialised |
| `mbist_req_o` / `mbist_done_i`, `mbist_fail_i` | 4-phase | RESTORE, optional (`CAP_MBIST_PWRUP`), **before** re-init (MBIST destroys contents); failure → FAULT, `E_ERR_MBIST` |
| `mem_reinit_o` / `mem_reinit_done_i` | 4-phase | RESTORE: the init sweep writes valid codewords. Mandatory: with RAS check-bit inversion an all-zero (or random) word decodes as an uncorrectable error |
| `mem_ecc_clr_o` | 1-cycle pulse | after re-init: ECC error log / counters / scrub pointer of the region reset (they referred to lost data) |
| `mbist_allow_o` | level | external (TestCore) MBIST access only while the region is ACTIVE and its contents are valid |

PM-status isolation is released *before* the SRAM handshakes so their acknowledges are visible, while the data outputs
stay isolated until the memory is valid (testbench invariant: de-isolation only with `mem_lost = 0`).

## Verified (doc 08)

`memory_retention`: MUST_RETAIN OFF refused; with (simulation-only) SRAM retention the contents survive OFF, no re-init,
no ECC clear; with `allow_loss` the contents are invalidated, re-initialised once, ECC cleared once. `isolation_sequencing`
traces the order `iso → mem_inv → iso_pm/rst → switch off …  pgood → clock → reset release → iso_pm off → MBIST →
re-init → ECC clear → iso off → quiesce off`. `sram_faults`: MBIST failure and re-init hang → FAULT. Mutants M12 (re-init
not awaited) and M19 (no invalidation) are killed.
