# 09 — Physical checks (brief §11)

Generated report: `reports/physical/power_connectivity.md` (both variants, after placement), plus
`reports/pdn/pdn_check_*.md` and `reports/pi/package_consistency.md`.

| Brief item | How it is checked | Result (powerfabric, placed) |
|---|---|---|
| **Every physical power pin is connected** | C1 OpenROAD `check_power_grid` per supply net; C2 every PG pin of every instance on a supply net of its type (ODB iterms) | VDD and VSS connected, 0 unconnected; 90 994 std-cell VDD + 90 994 VSS pins, 24 macro power + 12 macro ground pins: all connected |
| **PDN straps do not violate declared geometry** | C4 only declared layers; C5 widths ≥ LEF `WIDTH`, ≤ `MAXWIDTH`, = declared; C6 on manufacturing grid; C7 inside die; C8 no VDD/VSS short and VDD–VSS spacing ≥ LEF `SPACINGTABLE` (width, parallel run); C9 PDN density ≤ `MAXIMUMDENSITY` per 200 µm window / 100 µm step; C10 closed ring on both nets | all PASS (39 checks, 0 FAIL); closest VDD–VSS 3.0 µm (TM1/TM2/M5), 3.34 µm (M1) |
| **Power domains are consistent with placement** | `scripts/region_placement.py`: every placed instance mapped to exactly one region; baseline has one domain (`PD_CORE`), every region fed by the core grid; for the FUTURE switchable regions, bounding box, foreign cell area inside it, compact-area estimate | 0 unmapped; baseline consistent by construction. FUTURE: VEC and TNS are **interleaved** with other regions (foreign/own area 0.60 and 3.17) — power gating would need placement fences (`set_domain_area`), switched rails and switch cells: a new floorplan |
| **Hard macros receive appropriate supply connections** | macro PG pin → expected net (`VDD!`, `VDDARRAY!` → VDD, `VSS!` → VSS); C3 vias landing on every vertical PG stripe of every macro (pin geometry transformed by orientation) | 0 of 36 pins without vias; 816 / 816 `VDD!`, 768 / 768 `VDDARRAY!`, 816 / 816 `VSS!` stripes reached; per-macro via counts and worst IR in the report |
| **Power-grid assumptions match the package model** | `reports/pi/package_consistency.md`: supply voltage, bump array (PackageTwin's own function), bumps on same-net straps (C11), total current vs PackageTwin, bump current vs EM limit, IR budget, PowerGrid import | all MATCH; one ACTION: PackageTwin's homogenised on-die grid lacks the TopMetal2 straps — it should read this PowerGrid export |

## Self-check of the checker

`pdn_check.py` first reported four density FAILs that were a bug in the checker (a numpy boolean compared with `is
True`); the values were within limits. Fixed and recorded here because it is exactly the kind of false result the
rules of this project forbid hiding.
