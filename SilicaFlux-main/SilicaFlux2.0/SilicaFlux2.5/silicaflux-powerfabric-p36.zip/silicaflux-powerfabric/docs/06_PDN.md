# 06 — Physical power grid: OpenROAD PDN generation (brief §8)

## Flow

`physical/run_flow.sh` (≈ 15 min on 4 cores; every step logged):

1. `scripts/pdn_params.py` — reads `config/power_regions.yaml`, **validates every PDN value against the tech LEF**
   (layer exists and is ROUTING; width ≥ `WIDTH`, ≤ `MAXWIDTH`; width / pitch / offset on the 0.005 µm manufacturing
   grid; VDD–VSS gap ≥ the `SPACINGTABLE` spacing for that width at long parallel run; PDN density ≤ `MAXIMUMDENSITY`;
   preferred direction), the **std-cell LEF** (rail width = the cells' Metal1 VDD / VSS rail, rail pitch = 2 × `CoreSite`
   height), the **SRAM LEFs** (PG pin layer = macro-connect bottom layer; strap layers not obstructed; a same-net
   TopMetal1 strap crosses even the shortest 38.825 µm `VDD!` stripe: pitch + width ≤ 38.825), the die / core margins
   (ring fits) and **PackageTwin's `bump_map()`** (every core bump within its pad radius of a same-net top strap). Any
   FAIL stops generation. `reports/pdn/param_validation_<variant>.md`: **76 / 63 checks, 0 FAIL**.
2. ORFS `ab2aaf0f`: synthesis (Yosys 0.38) → floorplan, I/O, macro placement, tapcell → **PDN with `PDN_TCL =
   pdn/sf_pdn.tcl`, `POST_PDN_TCL = pdn/sf_post_pdn.tcl`** → placement (`physical/config.mk.tmpl`, FloorplanLab
   A_baseline values, sources read unmodified from the FloorplanLab archive).
3. `physical/pf_pi.tcl` on the placed database, per variant: `pdngen -ripup`, rebuild, checks, analysis (doc 07).

`pdn/sf_pdn.tcl` contains **no layer rule**: it only expresses topology from the validated parameter file.

## Variants

| | `powerfabric` (this project) | `floorplanlab` (reference, Project 05) |
|---|---|---|
| Rails | Metal1 0.44 µm follow-pins | same |
| Straps | Metal5 2.2 / 75.6 µm (V); **TopMetal1 4.0 / 30.24 µm** (H); **TopMetal2 14 / 100 µm (V)** | Metal5 2.2 / 75.6; TopMetal1 1.8 / 30.24 |
| Connects | M1→M5, M5→TM1, **TM1→TM2** | M1→M5, M5→TM1 |
| Ring | **TopMetal1 + TopMetal2**, 12 µm, 3 µm, offset 4 µm | Metal5 + TopMetal1, 5 µm |
| SRAM macros | macro grid: Metal4 PG stripes → TopMetal1 via stacks (`-grid_over_boundary`) | same |
| Package | TopMetal2 = C4 layer: a VDD and a VSS strap 25 µm either side of every bump column (offset 94.2 µm) | none |

Global connections: std-cell `VDD/VDDPE/VDDCE → VDD`, `VSS/VSSE → VSS`; SRAM `VDD!`, `VDDARRAY! → VDD`, `VSS! → VSS`.

## pdngen convention discovered

With an explicit `-spacing`, this pdngen places the **ground** net on the first stripe, centred at core origin +
offset, and power half a pitch later (measured on the generated geometry). The parameter model encodes it and check C11
confirms the bump alignment on the real shapes (18 µm edge distance = 25 µm centre distance, as designed).

## Results

* `check_power_grid` **passes for VDD and VSS** in the ORFS PDN stage and after placement for both variants.
* PDN-0110 warnings (≈ 500): pdngen skips vias where a strap only partly overlaps a pin or strap end (cannot meet
  enclosure). Coverage is verified independently: **every one of the 2 400 SRAM PG stripes receives vias** (C3).
* Full geometry check in doc 09 / `reports/physical/power_connectivity.md`.

## Planning notes (not done, not claimed)

* Bump pads / RDL are **not drawn**: PDNSim / PowerGrid sources are attached to the nearest same-net top-layer node
  (≤ 29 µm away) through bump contact + pad resistance (PackageTwin values).
* TopMetal1 / TopMetal2 densities of the PDN alone are 23.6–32 % (min windows below the 25 % minimum density in places):
  metal fill must make up the rest; maximum densities are respected.
* No DRC / LVS of the grid was run (KLayout decks exist but need detailed routing / GDS, out of scope).
