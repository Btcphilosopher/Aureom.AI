# 07 — Power integrity: PowerGrid, IR drop, current concentration, EM (brief §9)

Full tables: `reports/pi/scenarios.md`; per-variant machine output `reports/pi/<variant>/summary.json`; map
`reports/pi/ir_map_mixed_vdd.png`.

## Method

| Step | Tool | Data |
|---|---|---|
| Network | OpenROAD PDNSim `write_pg_spice` | every metal segment and via array of the generated PDN, resistance from the tech LEF (`RPERSQ`, via `RESISTANCE`): ~93 000 nodes, ~101 000 resistors per net |
| Sources | `scripts/powergrid.py` | PDNSim's sources removed; **37 VDD / 35 VSS C4 bumps from PackageTwin `bump_map()`**, each to the nearest top-layer node through 18 mΩ (contact 8 mΩ + pad / RDL 10 mΩ, PackageTwin) |
| Loads | OpenSTA + PackageTwin | per-instance power from OpenSTA (typ Liberty, reference activity 0.1) gives the **spatial** distribution; the **magnitude** of each logical class (ControlCore, VectorEngine, TensorCore, DataFabric, SRAM logic, IO core logic, clock / glue) is set to PackageTwin's workload (`workload_power.csv`); SRAM macros get **explicit** current = accesses / cycle × access energy × f + leakage (PackageTwin `power_model.json`) because the IHP SRAM Liberty gives 0 W |
| Solve | scipy sparse (nodal analysis) | static DC, both nets |
| EM | tech LEF | metal: current / width (width = `RPERSQ × L / R`) vs `DCCURRENTDENSITY AVERAGE` (mA/µm); via arrays: current per cut (cuts = `R_cut / R`) vs the via layer limit |
| Cross-check | OpenROAD `analyze_power_grid` | same network with PDNSim's own sources and loads |

Scenarios: PackageTwin `idle`, `control`, `vector`, `tensor`, `memory`, `mixed`, `max_simultaneous` (a screening bound)
and **`stress_bound`** (OpenSTA at activity 0.5 everywhere, ungated, every SRAM accessed every cycle at the top of
PackageTwin's energy range). These are **explicit estimates**; no gate-level switching data (SAIF / VCD) exists.

## Results (static, typical corner)

| Scenario | Core power | PowerFabric VDD + VSS worst | FloorplanLab PDN | Budget | PowerFabric worst EM ratio |
|---|---|---|---|---|---|
| idle | 6.25 mW | 0.43 mV | 0.61 mV | 36 mV | 0.031 (Metal1) |
| mixed | 18.20 mW | **0.90 mV** | 2.55 mV | 36 mV | 0.046 (Metal1) |
| max_simultaneous | 34.07 mW | 1.29 mV | 5.18 mV | 36 mV | 0.067 (Metal1) |
| stress_bound | 63.51 mW | **1.74 mV** | 10.34 mV | 36 mV | 0.057 (Metal1) |

* **DC IR drop**: ≤ 1.74 mV (4.8 % of the 36 mV budget) even in the stress bound; static IR headroom 40× (mixed) / 21×
  (stress) — the grid would carry roughly that multiple of today's current before the 3 % budget is reached, the
  number that matters when SilicaFlux-HPC scales the compute (more tiles, higher clock).
* **TopMetal2 matters**: the reference grid's drop is 2.8× (mixed) to 6× (stress) higher, concentrated in the
  bottom-right TensorCore corner, which is ~600 µm from the nearest core VDD bump because PackageTwin reserves the
  three outer bump rings for signals (map). That is a **package / floorplan finding**: TNS logic sits under the signal
  rings.
* **Current concentration**: worst branch density is on the Metal1 rails (≤ 6.7 % of the LEF limit); worst bump
  4.63 mA of 150 mA in the stress bound; per-region and per-macro worst drops in `scenarios.md` /
  `power_connectivity.md`.
* **PDN connectivity**: 0 floating nodes on either net; every macro has pin nodes in the network.
* **Macro supply continuity**: every SRAM macro is reached by the grid on all three PG pins (2 400 / 2 400 stripes,
  per-macro via counts and worst drop in `power_connectivity.md`).

## Solver validation

On PDNSim's own sources and loads the solver reproduces `analyze_power_grid` node-by-node over ~104 000 points:
max |ΔV| 0.037 mV, p99 0.029 mV (worst drop 0.644 vs 0.610 mV on VDD, 0.325 vs 0.300 mV on VSS). The residual is a
systematic ~6 % (VDD) / 11 % (VSS) of a sub-millivolt drop; it was not traced further and is far below every margin.
PDNSim itself (C4-pitch source lattice) gives 0.61 / 0.30 mV for PowerFabric vs 3.15 / 3.58 mV for the reference at
the 44.7 mW reference load.

## PowerGrid integration

`reports/pi/powerfabric/powergrid_export_mixed_VDD/{nodes,resistors}.csv` (92 880 nodes, 101 290 resistors) is read by
**PackageTwin `powergrid-import`** (total load 15.167 mA = PackageTwin's own mixed core current) and **ThermalLab
`load_powergrid_export`** (load power 18.20 mW) — their own code, unmodified (`reports/pi/powerfabric/import_check.txt`).

## Not done

* **EM sign-off**: the LEF `DCCURRENTDENSITY AVERAGE` values are the only current-density rules available; they have
  no temperature dependence or lifetime basis here. Real EM needs the PDK's temperature-dependent rules and RMS / peak
  limits — the ratios above are a screen, not a sign-off.
* No dynamic IR / di/dt / decap analysis (PackageTwin's lumped model already notes its PDN misses target impedance for
  the hypothetical scenario B), no extraction-based signal-net coupling, no multi-corner (ORFS ab2aaf0f ships only the
  typical std-cell corner).
