# Generated region tables

| Id | Region | Contents | Clock gate | Switchable (baseline) | Future | Thermal | Depends on | SRAM policy | Instances (sfv_soc_df) |
|---|---|---|---|---|---|---|---|---|---|
| 0 | CTRL | ControlCore (RV32IM, boot ROM, mailbox, PMU, RAS) | no (always-on) | no | no | - | - | - | u_cpu, u_rom, u_dbg, u_sysctrl, u_intc |
| 1 | VEC | Vector compute clusters | yes | no | switchable (sim only) | yes | FABRIC, SRAM | discard | u_tile/u_ve, u_tile/g_bank, u_tile |
| 2 | TNS | TensorCore clusters | yes | no | switchable (sim only) | yes | FABRIC, SRAM | discard | u_tile/u_te |
| 3 | SRAM | Shared SRAM (banked macros) | yes | no | hypothetical | - | - | must_retain | g_sram, u_mbist |
| 4 | FABRIC | DataFabric interconnect + DMA | yes | no | no | - | - | - | u_xbar, u_dma, u_pbr, g_v1 |
| 5 | EXTIF | External interfaces (host link, ext-mem bridge, UART/SPI/GPIO) | yes | no | no | - | FABRIC | - | u_uart, u_spi, u_gpio, u_timer |
| 6 | AON | Always-on control (this controller, reset / clock / thermal control) | no (always-on) | no | no | - | - | - | - |

## Memories

| Memory | Region | Kind | Must retain | Retention in technology | On power loss |
|---|---|---|---|---|---|
| boot_rom | CTRL | rom | n/a | n/a | none (ROM) |
| controlcore_ram | CTRL | sram | True | none | region is always-on: never powered off |
| vector_spm | VEC | sram | False | none | invalidate -> MBIST (optional) -> re-init -> ECC log clear |
| tensor_buffers | TNS | flops_or_sram | False | none | reset / re-init |
| shared_sram | SRAM | sram | True | none | NOT ALLOWED unless software accepts loss (allow_loss) -> then invalidate + re-init |
| fabric_fifos | FABRIC | flops | False | none | drained before IDLE; reset |

## RTL parameters

| Parameter | Value (bit i = region i) |
|---|---|
| CAP_CLK_GATE | `7'b0111110` |
| CAP_SWITCH | `7'b0000000` |
| CAP_LOGIC_RET | `7'b0000000` |
| CAP_SRAM | `7'b0001000` |
| CAP_SRAM_RET | `7'b0000000` |
| CAP_MUST_RETAIN | `7'b0001000` |
| CAP_MBIST_PWRUP | `7'b0000000` |
| CAP_ABORT | `7'b0000000` |
| CAP_BOOT_ON | `7'b1111111` |
| THERM_MASK | `7'b0000110` |
| DEP | `{7'b0000000, 7'b0010000, 7'b0000000, 7'b0000000, 7'b0011000, 7'b0011000, 7'b0000000}` |
