# 05 — Power intent (UPF) (brief §7)

All four files are generated from `config/power_regions.yaml` by `scripts/gen_power_config.py`.

| File | Content | Loads in OpenROAD 2.0-12331? |
|---|---|---|
| `upf/silicaflux_pf_baseline.upf` | IEEE 1801 (UPF 2.1 syntax): supply ports / nets VDD, VSS; supply set `SS_CORE`; **one domain `PD_CORE`** (`-include_scope`); SRAM `primary_power` pins (VDD, VDDARRAY) → VDD; power states ON / OFF; region→instance map as comments | No — rejects `upf_version` (first standard command it does not implement) |
| `upf/silicaflux_pf_future.upf` | FUTURE: `PD_AON` + switchable `PD_VEC` (`u_tile/u_ve`) and `PD_TNS` (`u_tile/u_te`) with their own switched supply sets, power switches (control + ack ports), `set_isolation` (clamp 0, `-location parent`, isolation supply `SS_AON`), `set_level_shifter -no_shift`, a **hypothetical** `set_retention` for TNS, power states and the legal system-state table. Header: **NOT IMPLEMENTABLE on IHP SG13G2** | No (same reason) |
| `upf/silicaflux_pf_baseline.openroad.upf` | the subset OpenROAD implements | **Yes** |
| `upf/silicaflux_pf_future.openroad.upf` | subset: domains, logic ports, switches, isolation | **Yes** |

## Validation actually performed

1. **OpenROAD `read_upf`** on the placed `sfv_soc_df` database (`upf/validate_upf.tcl`): both subset files load
   (rc 0). Objects read back from ODB: `PD_VEC → u_tile/u_ve` (**22 963** leaf instances) and `PD_TNS → u_tile/u_te`
   (**25 290**), both resolved as real `dbModInst`s; switches `SW_VEC`, `SW_TNS` with their control / supply ports;
   isolation strategies (signal, clamp 0, sense high, location parent, applies-to outputs); 4 logic ports.
   * OpenROAD **does not check elements**: a deliberately bogus `-elements {no_such_inst}` was accepted silently — so
     the script resolves every element itself.
   * `dbPowerSwitch::getLibCell` **segfaults** in this build when no switch cell is mapped (there is none to map);
     the script avoids the call and records "not mapped".
   * Library scan (Liberty text): 0 isolation / switch / level-shifter / retention / always-on cells, 0 `pg_pin`.
2. **`scripts/upf_check.py`** on the full 1801 files: **109 checks, 0 FAIL** — every command is an IEEE 1801-2013
   command; every supply port / net / set, logic port, domain, strategy and power state is declared before use; power-
   state expressions reference declared sets and states; every switched domain's primary supply is the switch output
   and it has an isolation strategy; voltages equal the YAML; baseline = exactly one domain with no switch / isolation /
   retention; FUTURE switched domains = the YAML's `future.switchable: true` regions; the full files and their OpenROAD
   subsets declare the same domains, elements, switches and isolation coverage.
3. **Checker self-test** (`scripts/upf_check_selftest.py`): **8 / 8** seeded defects caught (isolation removed,
   undeclared isolation signal, undeclared supply set / state in a power state, switch output not the primary,
   non-1801 command, undeclared supply net, undeclared primary set). A first version missed power-state references
   (braced words parsed as options) — found by this self-test and fixed.

## Limitation

No tool here performs full 1801 semantic verification (supply-state reachability, isolation completeness on every
domain-crossing net, retention coverage, PST legality). VC LP / Conformal LP class checking is required before the
FUTURE intent could be implemented — and it cannot be implemented on this library anyway.
