# 04 — Isolation and voltage crossing (brief §6)

## A Boolean isolation signal is not a power domain

`iso ? clamp : d` in RTL does not make a region physically power-gateable. A real isolation cell is powered from the
**receiving (always-on) supply**, tolerates a floating input without crowbar current, sits in the always-on domain (or is
a dual-rail cell), has its enable routed on always-on supply, and is characterised (`is_isolation_cell`,
`isolation_cell_enable_pin`, `pg_pin`) so implementation and UPF checks recognise it. Synthesising the Boolean model
gives an ordinary AND / OR gate on whatever supply it is placed on — meaningless once its input region is unpowered.

## What this project provides

`rtl/sf_pd_boundary.sv`:

| Module | Technology build (`SF_PD_TECH_ISO` / `SF_PD_TECH_LS`) | Otherwise |
|---|---|---|
| `sf_pd_iso_cell #(CLAMP)` | instantiates the integrator-written `sf_pd_iso_lib_cell` (must map to a characterised cell) | **FUNCTIONAL MODEL** (labelled in the source); `ALLOW_FUNCTIONAL = 0` → elaboration error in Verilator and Yosys, `$fatal` in simulation |
| `sf_pd_level_shifter` | `sf_pd_ls_lib_cell` | functional wire; same guard |
| `sf_pd_boundary #(W, CLAMP, NEEDS_LS)` | bank: region → LS → ISO → always-on (UPF `-location parent`) | |

Two isolation controls per switchable region: **`iso_o`** for data / fabric outputs (clamp 0 = no valid, no ready) and
**`iso_pm_o`** for the PM-status outputs the controller itself reads (clamp: ack 1, busy 0, done 0). PM status is
released earlier on power-up (after reset release) so re-init / MBIST acknowledges are visible while the data path is
still clamped.

The controller additionally guards at the top level: with `ASIC_IMPL = 1`, `CAP_SWITCH ≠ 0` requires
`TECH_SWITCH_CELLS ∧ TECH_ISO_CELLS`, and `CAP_LOGIC_RET ≠ 0` requires `TECH_RET_CELLS` — otherwise elaboration stops
with a message (checks N1–N3 in `reports/rtl/synthesis.md`, verified to fire **for that reason**, not any other error).

## Voltage crossings on this die

The baseline is single-voltage (1.2 V): **no level shifter is needed**. The only real crossings are inside the IHP
`sg13g2_IOPad*` cells (1.2 V core / 3.3 V IO), which contain their own level shifters. The FUTURE UPF declares
`set_level_shifter … -no_shift` for the switchable domains (same voltage).

## Verification (doc 08)

The region model drives **X** on every output while unpowered (Icarus, 4-state). The invariant checker fails on any X
reaching the always-on side or the controller, any isolated output not clamped, any unpowered region not isolated and
reset, de-isolation before power / reset release / clock / memory validity, and PM de-isolation before power and reset
release. During an injected brown-out the region outputs are *random* (not X) until isolation catches up — a real
brown-out produces undefined but binary values — so the controller is not credited with X-freedom it cannot have.
Mutants M05 (data isolation released during RESTORE) and M17 (FAULT not isolating) are killed.
