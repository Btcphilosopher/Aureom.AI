# 01 — Power architecture (brief §2)

![power-domain diagram](power_domain_diagram.svg)

## One supply domain, seven logical regions

`config/power_regions.yaml` is the single source of truth; `scripts/gen_power_config.py` derives the RTL parameter
package (`rtl/sf_pd_cfg_pkg.sv`), the UPF files and `docs/generated/regions.md`, and **fails if the defaults hard-coded
in `silicaflux_power_domain.sv` differ from the YAML**.

| Id | Region | Contents | Baseline control | FUTURE option | Thermal | Uses |
|---|---|---|---|---|---|---|
| 0 | CTRL | ControlCore (RV32IM, ROM, mailbox, PMU, RAS) | **always-on**, status only (it runs the PMU firmware; its own WFI sleep) | — | — | — |
| 1 | VEC | vector clusters (+ tile scratchpad in `sfv_soc_df`) | clock enable | switchable, abort policy | yes | FABRIC, SRAM |
| 2 | TNS | TensorCore clusters | clock enable | switchable, abort, (hypothetical) logic retention | yes | FABRIC, SRAM |
| 3 | SRAM | shared SRAM banks | clock enable | hypothetical | — | — |
| 4 | FABRIC | DataFabric interconnect + DMA | clock enable, only when all users are idle | — | — | — |
| 5 | EXTIF | host link, ext-mem bridge, UART/SPI/GPIO | clock enable | — | — | FABRIC |
| 6 | AON | this controller, reset / clock / thermal control | always-on | — | — | — |

All regions are in **one UPF power domain `PD_CORE`** (supply set `{VDD, VSS}`, 1.2 V). A region is a clock-enable
group, not a power domain.

## Why these rules

* **CTRL is never gated by this controller**: the firmware that issues the requests runs there.
* **Dependencies** (`DEP` matrix, region u *uses* region t): a provider may leave ACTIVE only when none of its users is
  in use (state not IDLE/OFF/FAULT); a user may wake only when every provider is ACTIVE. One request is accepted per
  cycle, and **autonomous wake-ups (thermal auto-restore) are deferred by one cycle whenever a request is accepted**, so
  a provider and a user can never cross each other's checks in the same cycle (both check *registered* states — the
  collision was a real defect, see doc 10). A region becoming ACTIVE releases quiesce only once its providers are
  ACTIVE (matters at boot, when providers power up too); the testbench checks "user ACTIVE ⇒ provider ACTIVE" every
  cycle.
* **Thermal hold** (from PowerClock's throttle level) idles VEC and TNS through the *normal* drain sequence — it never
  cuts in-flight work — and refuses wake requests while held; it restores them when the hold clears
  (`THERM_RESTORE`). A region that cannot drain is left ACTIVE (reported) and not retried until the hold drops.
* **Inrush**: in the FUTURE configuration only one region may ramp its supply at a time (power-up token), and the
  token goes to **providers first** (a requester whose providers are still waiting to power up is not ready; if none
  is ready the lowest index wins, so it cannot deadlock).

## Memory classification (brief §5)

| Memory | Region | Must retain | Retention in the technology | On power loss |
|---|---|---|---|---|
| Boot ROM | CTRL | n/a | n/a | — |
| ControlCore RAM | CTRL | yes | none | region is always-on: never powered off |
| Vector scratchpad (SPM) | VEC | no | none | invalidate → MBIST (optional) → re-init → ECC log clear |
| Tensor operand / accumulator buffers | TNS | no | none | reset / re-init |
| **Shared SRAM** | SRAM | **yes** | **none** (IHP macros) | **refused** (`E_REJ_RET_UNAVAIL`) unless software sets `allow_loss` |
| Fabric FIFOs | FABRIC | no | none | drained before IDLE |

## Physical mapping

On `sfv_soc_df` (doc 06): CTRL = `u_cpu u_rom u_dbg u_sysctrl u_intc`; VEC = `u_tile/u_ve` (+ tile glue and the four
512×64 SPM macros); TNS = `u_tile/u_te`; SRAM = `g_sram*` (eight 2048×64 macros) + `u_mbist`; FABRIC = `u_xbar u_dma
u_pbr g_v1*`; EXTIF = `u_uart u_spi u_gpio u_timer`; AON = top-level glue. Placement consistency: doc 09.
