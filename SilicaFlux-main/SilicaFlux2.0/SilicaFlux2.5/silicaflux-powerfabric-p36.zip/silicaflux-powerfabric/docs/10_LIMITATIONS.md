# 10 — Limitations, open issues, defects found

## Not claimed

* **No power gating, isolation, retention or voltage island is implemented in silicon.** IHP SG13G2 has none of the
  cells (`reports/tech_cell_audit.md`). Those features exist as interfaces + simulation models, and synthesis refuses
  them with `ASIC_IMPL = 1`.
* **No SRAM retention.** The IHP macros' `VDDARRAY!` pin is a primary supply, not a characterised retention mode.
* **No sign-off**: no dynamic IR, no EM sign-off (LEF average current density only, no temperature / lifetime basis),
  no DRC / LVS of the grid, no STA of the controller, no multi-corner (typical only), no gate-level simulation.
* **No measured switching data**: every current is an explicit estimate (OpenSTA distribution × PackageTwin workload
  classes, SRAM access-energy assumptions). The absolute IR numbers are therefore planning numbers; the *ratios*
  (variant comparison, headroom) are the robust result.
* **Bump pads / RDL not drawn**; the package values are PackageTwin assumptions (no package drawing exists).
* **Full UPF semantic verification not available** (no VC LP / Conformal LP); OpenROAD reads only a subset.
* The physical testcase is `sfv_soc_df` (SilicaFlux-V), not the SilicaFlux-HPC die (DieTop has no PDK mapping).
* The controller is **not integrated** into DieTop / ControlCore in this delivery; the integration contract is doc 02 §7.

## Tool limitations met (and how they were handled)

| Issue | Handling |
|---|---|
| Yosys (0.33 and ORFS 0.38) has no `import`, mis-resolves enum constants inside package functions, cannot cast to package types; 0.33 cannot parse a packed array of a package struct in a port | `scripts/yosys_prep.py` makes a mechanically qualified copy; the full regression on that copy gives **identical check counts** to the source |
| OpenROAD `read_upf` accepts a non-existent `-elements` path silently | elements resolved by `upf/validate_upf.tcl` itself |
| `dbPowerSwitch::getLibCell` segfaults with no mapped cell | call avoided, recorded |
| `analyze_power_grid -dx/-dy` are not in µm in this build (200 → 30 M sources) | pitch passed in DBU |
| PDNSim `-vsrc` file format undocumented here (several guesses rejected) | PowerGrid solver places exact bump sources instead; PDNSim used as cross-check with a C4-pitch lattice |
| Icarus ignores elaboration-time `$error` | guards duplicated as `initial $fatal` (simulation) |
| The first ORFS run used an interim TopMetal2 offset (37.2 µm; final 94.2 µm) | the analysed PDN is always rebuilt on the placed database by `pdngen -ripup` (`pf_pi.tcl`); the whole flow was then re-run from scratch with the final parameters and every report came out byte-identical (`reports/REPRODUCTION.md`) |

## Defects found by the verification (all fixed, all kept as regressions)

1. **Power-good synchroniser reset to 0** → right after a reset a decaying rail looked off and the post-reset
   power-off confirmation completed prematurely. Found by `reset_mid_transition`; fixed (reset value 1); mutant M16.
2. Region model did not keep draining queued work under quiesce (testbench defect) — fixed to drain semantics.
3. Region model hid the dispatcher's in-transit operations inside the region's ack, so the controller's
   `acc_op_pend` check was untested (mutant M02 survived). Transit latency added; M02 killed.
4. `upf_check.py` did not inspect power-state expressions — found by its own self-test.
5. `pdn_check.py` density comparison bug (false FAILs).
6. Synthesis negative tests initially "passed" on a syntax error — they now require the guard's own message.
7. **Same-cycle dependency race**: a thermal auto-restore of VEC/TNS and a request idling their provider FABRIC could be
   accepted in the same cycle (each checked the other's registered, old state), leaving a user ACTIVE on an idle
   provider. Found by design review; reproduced by a directed collision test; fixed by deferring autonomous wake-ups
   while a request is accepted (`auto_block_i`); mutant M23.
8. **Boot order**: the power-up token was granted by region index, so in the FUTURE configuration TNS booted to ACTIVE
   before the switchable SRAM it uses. Found by the new "user ACTIVE ⇒ provider ACTIVE" invariant; fixed with a
   providers-first arbiter plus a bounded dependency wait before quiesce release; mutants M21, M22.
9. **Restart from FAULT ignored dependencies**: a provider that had faulted (injected brown-out of the switchable SRAM)
   could be restarted while its user VEC stayed ACTIVE, passing through POWER_DOWN / OFF / POWER_UP. Found by the random
   test (one stream: Verilator, FUTURE, seed 2) through the dependency invariant; fixed — restarting from FAULT counts
   as leaving, so the users must be idle first (software recovery order); mutant M24. A 50-seed random sweep per build
   was added to the regression as a result.

## Open

* Integrate `silicaflux_power_domain` into DieTop behind the ControlCore PMU page; map `busy_i` / `q_ack_i` /
  `dma_wr_pend_i` / `acc_op_pend_i` onto the ComputeCluster, TensorCore and DataFabric-NoC signals listed in doc 00.
* Feed this PowerGrid export into PackageTwin instead of its homogenised die grid; rerun ThermalLab electrothermal.
* Re-plan the bump map so the TensorCore corner is not under the signal rings, or move TNS (largest local drop).
* Before any power gating: choose a library with switch / isolation / retention cells, characterise inrush, add fences.
