# 08 — Verification (brief §10)

## Environment

`tb/tb_power_domain.sv` drives `silicaflux_power_domain` with seven `sim/sf_pd_region_model.sv` instances
(simulation-only): power switch with ramp delays and fault injection (no power-good, stuck, brown-out), region logic
that goes **X** when unpowered, a dispatcher with **in-transit** operations (invisible to the region's quiesce ack), a
fabric with DMA writes of arbitrary latency, 4-phase quiesce, abort with fence, retention balloon latch, SRAM with
contents / ECC-valid bits / invalidation / re-init sweep / MBIST / retention mode, outputs through `sf_pd_boundary`
functional isolation. Two builds: **BASE** (the implemented single-domain configuration) and **FUTURE** (VEC, TNS, SRAM
switchable; SIMULATION ONLY).

## Continuous invariant checker (every cycle, every test)

No X/Z on any controller output, status or error register; no X reaching the controller through PM status or the
always-on side of a data boundary (outside an injected brown-out window); isolated outputs clamped; always-on regions
never gated or quiesced; an unpowered region is isolated, PM-isolated and reset; the switch opens only after isolation,
PM isolation, reset, clock stop and quiesce; **no power removal with work outstanding unless an abort was granted**;
de-isolation only with power-good, reset released, clock running and memory valid; PM de-isolation only after power
and reset release; retention save only with the clock stopped and isolated; restore only powered with the clock
stopped; SRAM re-init only isolated, powered and out of reset; MBIST only isolated; clock stop only quiesced and
drained (or aborted / faulted); quiesce released only with the clock running; MBIST access allowed only when ACTIVE;
at most one region ramping its supply; **a user region is ACTIVE only while every region it uses is ACTIVE** (or faulted
by an injected brown-out); every accepted request gets exactly one completion (per-source accounting).

## Tests ↔ brief §10

| Brief item | Test(s) |
|---|---|
| Idle-to-active / active-to-idle | `active_idle_active` (work drained before the clock stops, gated clock has no edges, state preserved, every gateable region) |
| Quiesce | `quiesce` (running jobs + 120-cycle DMA write: clock stops only after it retires; request during sequencing refused; stale ack → PROTOCOL; work submitted to an IDLE region → PROTOCOL) |
| Busy-domain shutdown rejection | `busy_reject` (IDLE and OFF with a DMA write longer than the timeout → `E_REJ_BUSY`, back to ACTIVE, nothing lost, power never removed) |
| Reset during transition | `reset_mid_transition` (asynchronous reset mid-QUIESCE; FUTURE: in POWER_DOWN, POWER_UP and during SRAM re-init → immediate safe outputs, clean boot, SRAM re-initialised) |
| Thermal throttling request | `thermal` (VEC/TNS idled with `E_OK_THERMAL`, wake refused, others served, auto-restore; a region that cannot drain is left ACTIVE and not retried while held; **the hold released in the same cycle as a request idling their provider FABRIC: the users must not wake**) |
| Memory retention protocol | `memory_retention` (logic retention save / restore; MUST_RETAIN refused without retention / loss acceptance; SRAM retention keeps contents without re-init; accepted loss → invalidate, re-init, ECC clear; retention refused where unsupported) |
| Missing power-good | `missing_power_good` (no power-good at power-up → FAULT, switch re-opened, isolated; stuck at power-down; brown-out while ACTIVE → isolated within 6 cycles, no spurious completion; recovery) |
| Isolation sequencing | `isolation_sequencing` (full OFF and ON order traced cycle by cycle) + the invariant checker in every test |
| Control timeout | `control_timeout` (clock-gate ack, resume ack, supply power-good), `sram_faults` (MBIST failure, re-init hang), `abort_policy` (abort ack timeout) |
| Also | `reset_defaults` (unsupported / illegal requests), `dependency`, `abort_policy` (explicit abort, fence drain before power-up), `inrush` (one ramp at a time), `boot_order` (providers ramp before their users after reset), `provider_fault` (a faulted provider is not restarted while its users are in use; the recovery order users-idle → provider → users works), `random` (20 000 cycles of random requests, work, DMA, thermal toggles, brown-outs, error clears) |

## Results

* `reports/rtl/regression.md`: **166 simulation runs, 0 failures** — Verilator `-Wall` clean (baseline and FUTURE
  parameters); every test on both builds in **Icarus 12 and Verilator 5**; whole suite with seeds 1–3 on both
  simulators (BASE ≈ 28 000, FUTURE ≈ 35 300 checks per run); the Yosys-prepped RTL through the same suite
  (identical check counts to the source); and a **random sweep of 50 seeds per build** on Verilator (2.4 M checks).
  Four real controller defects were found during development (doc 10): the power-good synchroniser reset value
  (directed test), boot order (dependency invariant), restart from FAULT (random test + invariant), and a same-cycle
  dependency race (design review, then reproduced by a directed collision test). All are fixed and kept as mutants.
* `reports/rtl/mutation.md`: one deliberate design defect per mutant (drain ignoring DMA writes / accelerator ops, abort
  without policy, power-up without power-good, early de-isolation, switch opened with isolation, power-good loss
  unsupervised, dependency ignored, wake during thermal hold, clock stop without ack, inrush, re-init not awaited,
  retention restore skipped, MUST_RETAIN bypass, stale ack, power-good synchroniser reset, FAULT not isolating,
  unbounded quiesce, no invalidation, OFF on a non-switchable region, power-up arbiter ignoring dependencies, quiesce
  released before providers are ACTIVE, thermal auto-restore not deferred, restart from FAULT with users in use):
  **24 / 24 killed**. Two mutants (M21, M24) first survived and exposed test gaps; the `boot_order` and
  `provider_fault` tests were added and kill them.
* `reports/rtl/synthesis.md`: **8 / 8** — latch-free generic synthesis (baseline and FUTURE), IHP SG13G2 mapping
  **5 336 cells, 61 552 µm²** (pre-placement), `sf_pd_icg` → `sg13g2_slgcp_1`, and the ASIC guards refuse switchable
  regions, logic retention and the functional isolation model **with their own messages**.

## What the simulation cannot show

Functional models only: real isolation / switch / retention cell behaviour, rush current, power-good timing, and CDC
metastability are outside it. X-propagation checks are meaningful on Icarus (4-state) only.
