# 00 — Audit (brief §1)

Everything below was **inspected** in the Aureom.AI repository (`SilicaFlux-main/…` archives, unpacked read-only) or in
the installed technology collateral. Nothing in the repository was modified.

## Projects inspected

| Item | Where | What it gives POWERFABRIC | Status |
|---|---|---|---|
| **PowerClock** (Project 27) | `SilicaFlux-main/silicaflux-powerclock.zip` | Clock-enable / reset / thermal-throttle manager with APB registers, CDC, `sf_clock_gate` (BUFGCE / ASIC ICG / model). Explicitly **no voltage control and no power switching** (`CAP.DVFS = CAP.VOLTAGE_CTRL = CAP.POWER_SWITCHING = 0`). | Reused as a *source*: its `throttle_active` drives `therm_throttle_i`; its "unit busy covers all in-flight state" contract is kept. Not modified, not duplicated. |
| **PowerGrid** (Project 08) | not in the repository | — | **Missing.** ThermalLab and PackageTwin both define its exchange format (`nodes.csv`, `resistors.csv`) and say the real exporter was not available. POWERFABRIC's `scripts/powergrid.py` *is* a PowerGrid implementation emitting that format, verified with both importers (doc 07). |
| **ThermalLab** (Project 09 / 2.5) | `SilicaFlux ThermalLab (1).zip` | `powergrid_adapter.load_powergrid_export`, a reference resistive PDN, electrothermal loop. | Integration verified: our export loads (92 880 nodes, 18.20 mW load). |
| **FloorplanLab** (Project 05) | `silicaflux-floorplanlab.zip` | Pinned OpenROAD/ORFS/IHP toolchain installer, the `sfv_soc_df` RTL (vendored, SHA-256), A_baseline floorplan (die 2819 × 2824 µm, 12 SRAM macros), its PDN (Metal1/Metal5/TopMetal1, `post_pdn.tcl` checks), logical groups. | Toolchain reproduced (`/opt/eda`); synthesis reproduced bit-for-bit in cell count and area (95 096 cells, 5 701 826.53 µm²); its PDN is the comparison variant `floorplanlab`. |
| **PackageTwin** (Project 29) | `silicaflux-packagetwin-v0.1.0.zip` | C4 bump map (`bump_map()`), bump EM / contact assumptions, 3 % static IR budget, workload power model (`data/power_model.json`, `workload_power.csv`), PowerGrid importer. | Its own functions are called for the bump plan; its workloads set the IR scenarios; consistency report in doc 09. |
| **DieTop** (Project 31) | `silicaflux-dietop-p31.zip` | The HPC die hierarchy (ControlCore, vector / tensor clusters, shared SRAM, DataFabric-NoC, DMA, ext-mem, host); ControlCore PMU (`cc_pmu`: `ACC_CTRL.CLK_EN/RST/ISO`, busy-qualified clock enable); `die_sfb_dom_gate` (clock request + refusal into a gated domain), `die_sfb_rst_fence` (orphan-response fence). | Region list and the abort-fence contract come from here. DieTop has no PDK mapping, so the physical flow uses `sfv_soc_df` (below). |
| **SRAMGrid** (P33) / SRAM library | `silicaflux-sramgrid-p33.zip`, `silicaflux-sramlib.zip` | Real IHP macro abstracts; SECDED with check-bit inversion (all-zero reads decode UE → re-init mandatory after power loss); MBIST collar bus; `init_after_test`; "**No macro has sleep / retention / repair pins**". | Basis of the SRAM retention / re-init / ECC / MBIST interface (doc 03). |
| ComputeCluster, TensorCore, DataFabric-NoC, ControlCore, ExtMem, HostLink | various | `busy`, `quiesce`/`g_quiesced`, `e_outstanding`, `m_id_idle`, `any_inflight` signals exist in the blocks. | The controller's `busy_i`, `q_ack_i`, `dma_wr_pend_i`, `acc_op_pend_i` map onto them at integration (doc 02 §5). |

## Clock gating that already exists

* `sfv_soc_df` (SilicaFlux-V): exactly **2 ICGs** (`u_tile/u_cg_ve`, `u_tile/u_cg_te`, cell `sg13g2_slgcp_1` via `sfv_clkgate`); every other group is clocked every cycle (PackageTwin power model, synthesis).
* DieTop: ControlCore PMU gates the whole accelerator clock (`acc_clk`).
* PowerClock: unit clock enables (vector / tensor) with busy interlock.

## Physical design facts (installed technology, read directly)

| Item | Finding |
|---|---|
| Technology | IHP SG13G2 130 nm, ORFS `ab2aaf0f` platform; SRAM collateral ORFS `d0e5b3c` (hash-verified by FloorplanLab's installer). |
| Supply | Single core supply **1.2 V** (Liberty `nom_voltage`, SRAM `voltage_map VDD/VDDARRAY 1.20`). |
| Power-management cells | **None**: no isolation, level-shifter, power-switch, retention or always-on cells in either standard-cell revision (78 / 84 cells); Liberty has **no `pg_pin`**. Clock gates `sg13g2_lgcp_1`, `sg13g2_slgcp_1` exist. → `reports/tech_cell_audit.md`. |
| Voltage crossings | Only inside the `sg13g2_IOPad*` cells (1.2 V core / 3.3 V IO, ORFS d0e5b3c). |
| SRAM power pins | `VDD!` (periphery), `VDDARRAY!` (array), `VSS!` — vertical **Metal4** stripes; shortest `VDD!` stripe 38.825 µm. Liberty: `VDD` and `VDDARRAY` both `primary_power` → no retention mode is characterised. SRAM Liberty carries **no usable power data** (OpenSTA reports 0 W for the macros). |
| Std-cell rails | Metal1, 0.44 µm, at the row edge; row 3.78 µm → same-net rail pitch 7.56 µm. |
| Tech LEF | 7 routing layers Metal1–5, TopMetal1–2; per-layer `RESISTANCE RPERSQ`, `DCCURRENTDENSITY AVERAGE` (mA/µm, per cut for vias), `SPACINGTABLE`, `MINIMUM/MAXIMUMDENSITY` (window 200 µm, step 100 µm), manufacturing grid 0.005 µm. |
| Package | PackageTwin scenario A FCBGA: C4 200 µm pitch, 120 µm keep-out, 3 outer signal rings, checkerboard core P/G, 0.15 A per bump (published range), 8 mΩ contact, 3 % static IR budget. **No real package drawing or bump plan exists** (PackageTwin: all package values are assumptions). |

## Tools

Installed and used: OpenROAD 2.0-12331-g6011bbe77 (pdngen, PDNSim `analyze_power_grid`, `check_power_grid`,
`write_pg_spice`, a **subset** of UPF via `read_upf`), Yosys 0.38+92 (ORFS) and 0.33 (apt), Verilator 5.020,
Icarus 12, Python 3.13 (numpy, scipy, PyYAML, matplotlib). Not available: any full IEEE 1801 checker
(VC LP / Conformal LP), sign-off EM/IR (Voltus / RedHawk), formal tools.

## Consequence for the architecture

Start — and stay, on this technology — with **one physical supply domain and clock-enable control**. Power gating,
isolation, retention and voltage islands are implemented as capability-gated interfaces and verified with labelled
simulation models only; synthesis refuses them unless real cells are declared (doc 04, `reports/rtl/synthesis.md`).

## Physical testcase

The SilicaFlux-HPC die (DieTop) has no technology mapping or floorplan. The only SilicaFlux design with a real PDK
mapping, real SRAM macros and a validated floorplan is **`sfv_soc_df`** (SilicaFlux-V + DataFabric DMA) from
FloorplanLab. The physical flow therefore uses it; its instances map onto the same logical regions
(`config/power_regions.yaml` `rtl_scope`).
