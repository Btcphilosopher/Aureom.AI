# Power regions vs placement (sfv_soc_df, ORFS 3_place.odb)

Instances: 91006, not mapped to a region: **0**. Baseline: every region is in the single power domain PD_CORE, fed by the core grid (connectivity in `reports/pdn/pdn_check_placed_powerfabric.md`).

| Region | Cells | Cell area (um2) | Placed bounding box (um) | Own area / bbox | Foreign cell area in bbox / own | 90 % area box half-side (um) |
|---|---|---|---|---|---|---|
| CTRL | 14874 | 227428 | (869, 747)-(2772, 2243) | 0.080 | 6.86 | 1372 |
| VEC | 24627 | 876989 | (888, 51)-(2701, 1287) | 0.391 | 0.60 | 694 |
| TNS | 25290 | 296038 | (1900, 104)-(2777, 1831) | 0.195 | 3.17 | 722 |
| SRAM | 2197 | 3959347 | (66, 51)-(2730, 2449) | 0.620 | 0.42 | 1086 |
| FABRIC | 10173 | 126527 | (1231, 773)-(2291, 1438) | 0.179 | 2.08 | 476 |
| EXTIF | 3249 | 57609 | (1687, 1038)-(2772, 2776) | 0.031 | 21.91 | 1040 |
| AON | 10596 | 97321 | (49, 43)-(2777, 2780) | 0.013 | 56.97 | 972 |

**Reading.** In the baseline this placement is consistent by construction (one domain). For the FUTURE switchable VEC / TNS regions it is not: their cells are spread across most of the core and interleaved with other regions (foreign/own ratio > 1), so power gating would need placement fences (`set_domain_area`), separate switched rails and switch cells along them - a new floorplan, not a script change.
