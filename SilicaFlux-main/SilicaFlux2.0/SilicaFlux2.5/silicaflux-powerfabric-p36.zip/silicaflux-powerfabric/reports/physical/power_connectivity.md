# Physical power-connectivity report

Design `sfv_soc_df` (SilicaFlux-V + DataFabric DMA, 91 006 placed instances, 12 IHP SRAM macros) on IHP SG13G2, ORFS `ab2aaf0f` / OpenROAD 2.0-12331, FloorplanLab A_baseline floorplan, placed (`3_place.odb`).  For each PDN variant the grid was ripped up and rebuilt by `pdn/sf_pdn.tcl` (`physical/pf_pi.tcl`) and exported by `pdn/sf_post_pdn.tcl`; `scripts/pdn_check.py` checks the exported geometry against the tech LEF.

## Summary

| Check | powerfabric | floorplanlab |
|---|---|---|
| C1 check_power_grid VSS | rc=0 result=true unconnected=0 (PASS) | rc=0 result=true unconnected=0 (PASS) |
| C1 check_power_grid VDD | rc=0 result=true unconnected=0 (PASS) | rc=0 result=true unconnected=0 (PASS) |
| C2 macro GROUND pins connected | 12 (PASS) | 12 (PASS) |
| C2 macro POWER pins connected | 24 (PASS) | 24 (PASS) |
| C2 stdcell GROUND pins connected | 90994 (PASS) | 90994 (PASS) |
| C2 stdcell POWER pins connected | 90994 (PASS) | 90994 (PASS) |
| C3 macro PG pins (instance x pin name) with no via | 0 of 36 (PASS) | 0 of 36 (PASS) |
| C3 macro VDD! vertical stripes reached by >= 1 via | 816 / 816 (PASS) | 816 / 816 (PASS) |
| C3 macro VDDARRAY! vertical stripes reached by >= 1 via | 768 / 768 (PASS) | 768 / 768 (PASS) |
| C3 macro VSS! vertical stripes reached by >= 1 via | 816 / 816 (PASS) | 816 / 816 (PASS) |
| C4 wire layers | ['Metal1', 'Metal5', 'TopMetal1', 'TopMetal2'] (PASS) | ['Metal1', 'Metal5', 'TopMetal1'] (PASS) |
| C6 coordinates off the manufacturing grid | 0 (PASS) | 0 (PASS) |
| C7 wires outside the die area | 0 (PASS) | 0 (PASS) |
| C5 Metal1 rail widths | [0.44] (PASS) | [0.44] (PASS) |
| C5 Metal5 strap widths | [2.2] (PASS) | [2.2] (PASS) |
| C5 TopMetal1 strap widths | [4.0] (PASS) | [1.8] (PASS) |
| C5 TopMetal1 ring widths | [12.0] (PASS) | [5.0] (PASS) |
| C5 TopMetal2 strap widths | [14.0] (PASS) | - |
| C5 TopMetal2 ring widths | [12.0] (PASS) | - |
| C8 Metal1: VDD/VSS shorts | 0 (PASS) | 0 (PASS) |
| C8 Metal1: VDD-VSS spacing violations | 0 (closest 3.340 um) (PASS) | 0 (closest 3.340 um) (PASS) |
| C8 Metal5: VDD/VSS shorts | 0 (PASS) | 0 (PASS) |
| C8 Metal5: VDD-VSS spacing violations | 0 (closest 3.000 um) (PASS) | 0 (closest 2.000 um) (PASS) |
| C8 TopMetal1: VDD/VSS shorts | 0 (PASS) | 0 (PASS) |
| C8 TopMetal1: VDD-VSS spacing violations | 0 (closest 3.000 um) (PASS) | 0 (closest 2.000 um) (PASS) |
| C8 TopMetal2: VDD/VSS shorts | 0 (PASS) | - |
| C8 TopMetal2: VDD-VSS spacing violations | 0 (closest 3.000 um) (PASS) | - |
| C9 Metal1: PDN density max over 200x200 windows | 11.7% (PASS) | 11.7% (PASS) |
| C9 Metal1: PDN density min | 0.0% (INFO) | 0.0% (INFO) |
| C9 Metal5: PDN density max over 200x200 windows | 6.6% (PASS) | 10.5% (PASS) |
| C9 Metal5: PDN density min | 0.0% (INFO) | 0.0% (INFO) |
| C9 TopMetal1: PDN density max over 200x200 windows | 32.0% (PASS) | 15.8% (PASS) |
| C9 TopMetal1: PDN density min | 23.7% (INFO) | 10.1% (INFO) |
| C9 TopMetal2: PDN density max over 200x200 windows | 28.1% (PASS) | - |
| C9 TopMetal2: PDN density min | 23.6% (INFO) | - |
| C10 VDD ring pieces | 2 horizontal + 2 vertical (PASS) | 2 horizontal + 2 vertical (PASS) |
| C10 VSS ring pieces | 2 horizontal + 2 vertical (PASS) | 2 horizontal + 2 vertical (PASS) |
| C11 VDD bumps: distance to nearest VDD TopMetal2 strap edge | 18.00 um (PASS) | - |
| C11 VSS bumps: distance to nearest VSS TopMetal2 strap edge | 18.00 um (PASS) | - |

**powerfabric: 35 PASS, 0 FAIL** (parameter validation before generation: 65 PASS, 0 FAIL).

**floorplanlab: 31 PASS, 0 FAIL** (parameter validation before generation: 55 PASS, 0 FAIL).

## Hard-macro supply connections (powerfabric)

Per macro instance: PG pin -> net, vias landing on that pin from the grid (`macro_pg_pins.csv` x `pdn_shapes.csv`), worst static IR drop at its pin nodes in the `mixed` scenario.

| Macro instance | Master | VDD! vias | VDDARRAY! vias | VSS! vias | worst VDD drop (mV) | worst VSS bounce (mV) |
|---|---|---|---|---|---|---|
| `g_sram[0].g_sfv.u_bank/u_ram/u_macro/g_m[0].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 147 | 1271 | 1428 | 0.0224 | 0.0232 |
| `g_sram[0].g_sfv.u_bank/u_ram/u_macro/g_m[1].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 148 | 1216 | 1417 | 0.0456 | 0.0582 |
| `g_sram[1].g_sfv.u_bank/u_ram/u_macro/g_m[0].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 148 | 1272 | 1428 | 0.0138 | 0.0198 |
| `g_sram[1].g_sfv.u_bank/u_ram/u_macro/g_m[1].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 148 | 1272 | 1428 | 0.0946 | 0.0875 |
| `g_sram[2].g_sfv.u_bank/u_ram/u_macro/g_m[0].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 144 | 1216 | 1428 | 0.1772 | 0.1562 |
| `g_sram[2].g_sfv.u_bank/u_ram/u_macro/g_m[1].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 144 | 1216 | 1428 | 0.0186 | 0.0176 |
| `g_sram[3].g_sfv.u_bank/u_ram/u_macro/g_m[0].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 148 | 1216 | 1360 | 0.0855 | 0.0983 |
| `g_sram[3].g_sfv.u_bank/u_ram/u_macro/g_m[1].g2k.u_mac` | RM_IHPSG13_1P_2048x64_c2_bm_bist | 144 | 1216 | 1428 | 0.0195 | 0.0304 |
| `u_tile/g_bank[0].u_ram/u_macro/g_m[0].genblk1.genblk1.g512.u_mac` | RM_IHPSG13_1P_512x64_c2_bm_bist | 91 | 311 | 408 | 0.1493 | 0.1658 |
| `u_tile/g_bank[1].u_ram/u_macro/g_m[0].genblk1.genblk1.g512.u_mac` | RM_IHPSG13_1P_512x64_c2_bm_bist | 88 | 320 | 476 | 0.1347 | 0.1548 |
| `u_tile/g_bank[2].u_ram/u_macro/g_m[0].genblk1.genblk1.g512.u_mac` | RM_IHPSG13_1P_512x64_c2_bm_bist | 146 | 320 | 408 | 0.0969 | 0.1219 |
| `u_tile/g_bank[3].u_ram/u_macro/g_m[0].genblk1.genblk1.g512.u_mac` | RM_IHPSG13_1P_512x64_c2_bm_bist | 92 | 312 | 408 | 0.3225 | 0.3222 |

## Power regions vs placement

Instances: 91006, not mapped to a region: **0**. Baseline: every region is in the single power domain PD_CORE, fed by the core grid (connectivity in `reports/pdn/pdn_check_placed_powerfabric.md`).

| Region | Cells | Cell area (um2) | Placed bounding box (um) | Own area / bbox | Foreign cell area in bbox / own | 90 % area box half-side (um) |
|---|---|---|---|---|---|---|
| CTRL | 14874 | 227428 | (869, 747)-(2772, 2243) | 0.080 | 6.86 | 1372 |
| VEC | 24627 | 876989 | (888, 51)-(2701, 1287) | 0.391 | 0.60 | 694 |
| TNS | 25290 | 296038 | (1900, 104)-(2777, 1831) | 0.195 | 3.17 | 722 |
| SRAM | 2197 | 3959347 | (66, 51)-(2730, 2449) | 0.620 | 0.42 | 1086 |
| FABRIC | 10173 | 126527 | (1231, 773)-(2291, 1438) | 0.179 | 2.08 | 476 |
| EXTIF | 3249 | 57609 | (1687, 1038)-(2772, 2776) | 0.031 | 21.91 | 1040 |
| AON | 10596 | 97321 | (49, 43)-(2777, 2780) | 0.013 | 56.97 | 972 |

**Reading.** In the baseline this placement is consistent by construction (one domain). For the FUTURE switchable VEC / TNS regions it is not: their cells are spread across most of the core and interleaved with other regions (foreign/own ratio > 1), so power gating would need placement fences (`set_domain_area`), separate switched rails and switch cells along them - a new floorplan, not a script change.

