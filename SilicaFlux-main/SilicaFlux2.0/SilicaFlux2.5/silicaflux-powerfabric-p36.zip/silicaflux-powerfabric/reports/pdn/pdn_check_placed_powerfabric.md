# Physical power-grid checks - `placed_powerfabric`

Data: `pdn/` exported by `pdn/sf_post_pdn.tcl`; rules from the tech LEF.

| Check | Item | Value | Rule | Status |
|---|---|---|---|---|
| C1 | check_power_grid VSS | rc=0 result=true unconnected=0 | OpenROAD reports the grid connected | PASS |
| C1 | check_power_grid VDD | rc=0 result=true unconnected=0 | OpenROAD reports the grid connected | PASS |
| C2 | macro GROUND pins connected | 12 | every PG pin on a supply net of its type | PASS |
| C2 | macro POWER pins connected | 24 | every PG pin on a supply net of its type | PASS |
| C2 | stdcell GROUND pins connected | 90994 | every PG pin on a supply net of its type | PASS |
| C2 | stdcell POWER pins connected | 90994 | every PG pin on a supply net of its type | PASS |
| C3 | macro PG pins (instance x pin name) with no via | 0 of 36 | == 0 | PASS |
| C3 | macro VDD! vertical stripes reached by >= 1 via | 816 / 816 | all stripes | PASS |
| C3 | macro VDDARRAY! vertical stripes reached by >= 1 via | 768 / 768 | all stripes | PASS |
| C3 | macro VSS! vertical stripes reached by >= 1 via | 816 / 816 | all stripes | PASS |
| C4 | wire layers | ['Metal1', 'Metal5', 'TopMetal1', 'TopMetal2'] | subset of declared PDN layers ['Metal1', 'Metal5', 'TopMetal1', 'TopMetal2'] | PASS |
| C6 | coordinates off the manufacturing grid | 0 | 0 (grid 0.005 um) | PASS |
| C7 | wires outside the die area | 0 | 0 | PASS |
| C5 | Metal1 rail widths | [0.44] | >= 0.16, <= 30.0, declared 0.44 | PASS |
| C5 | Metal5 strap widths | [2.2] | >= 0.2, <= -, declared 2.2 | PASS |
| C5 | TopMetal1 strap widths | [4.0] | >= 1.64, <= -, declared 4.0 | PASS |
| C5 | TopMetal1 ring widths | [12.0] | >= 1.64, <= -, declared 12.0 | PASS |
| C5 | TopMetal2 strap widths | [14.0] | >= 2.0, <= -, declared 14.0 | PASS |
| C5 | TopMetal2 ring widths | [12.0] | >= 2.0, <= -, declared 12.0 | PASS |
| C8 | Metal1: VDD/VSS shorts | 0 | 0 | PASS |
| C8 | Metal1: VDD-VSS spacing violations | 0 (closest 3.340 um) | 0 below LEF spacing | PASS |
| C8 | Metal5: VDD/VSS shorts | 0 | 0 | PASS |
| C8 | Metal5: VDD-VSS spacing violations | 0 (closest 3.000 um) | 0 below LEF spacing | PASS |
| C8 | TopMetal1: VDD/VSS shorts | 0 | 0 | PASS |
| C8 | TopMetal1: VDD-VSS spacing violations | 0 (closest 3.000 um) | 0 below LEF spacing | PASS |
| C8 | TopMetal2: VDD/VSS shorts | 0 | 0 | PASS |
| C8 | TopMetal2: VDD-VSS spacing violations | 0 (closest 3.000 um) | 0 below LEF spacing | PASS |
| C9 | Metal1: PDN density max over 200x200 windows | 11.7% | <= MAXIMUMDENSITY 60.0% | PASS |
| C9 | Metal1: PDN density min | 0.0% | MINIMUMDENSITY 35.0%: shortfall is for routing / metal fill | INFO |
| C9 | Metal5: PDN density max over 200x200 windows | 6.6% | <= MAXIMUMDENSITY 60.0% | PASS |
| C9 | Metal5: PDN density min | 0.0% | MINIMUMDENSITY 35.0%: shortfall is for routing / metal fill | INFO |
| C9 | TopMetal1: PDN density max over 200x200 windows | 32.0% | <= MAXIMUMDENSITY 70.0% | PASS |
| C9 | TopMetal1: PDN density min | 23.7% | MINIMUMDENSITY 25.0%: shortfall is for routing / metal fill | INFO |
| C9 | TopMetal2: PDN density max over 200x200 windows | 28.1% | <= MAXIMUMDENSITY 70.0% | PASS |
| C9 | TopMetal2: PDN density min | 23.6% | MINIMUMDENSITY 25.0%: shortfall is for routing / metal fill | INFO |
| C10 | VDD ring pieces | 2 horizontal + 2 vertical | 2 + 2 (closed ring) | PASS |
| C10 | VSS ring pieces | 2 horizontal + 2 vertical | 2 + 2 (closed ring) | PASS |
| C11 | VDD bumps: distance to nearest VDD TopMetal2 strap edge | 18.00 um | <= 50 um (C4 pad radius, PackageTwin 100 um bump) | PASS |
| C11 | VSS bumps: distance to nearest VSS TopMetal2 strap edge | 18.00 um | <= 50 um (C4 pad radius, PackageTwin 100 um bump) | PASS |

**35 PASS, 0 FAIL, 4 INFO.**
