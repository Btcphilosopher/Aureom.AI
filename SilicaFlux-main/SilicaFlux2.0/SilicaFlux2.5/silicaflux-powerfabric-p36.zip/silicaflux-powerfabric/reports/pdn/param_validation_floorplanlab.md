# PDN parameter validation - variant `floorplanlab`

Technology: IHP SG13G2 (130 nm SiGe:C BiCMOS, open PDK) - tech LEF sg13g2_tech.lef, manufacturing grid 0.005 um. Die [0.0, 0.0, 2819.04, 2823.66], core [40.32, 41.58, 2778.72, 2782.08].

| Item | Value | Rule | Status | Source |
|---|---|---|---|---|
| rails: layer Metal1 | Metal1 | exists, TYPE ROUTING | PASS | tech LEF sg13g2_tech.lef |
| rails: width | 0.44 | >= WIDTH 0.16 | PASS | tech LEF sg13g2_tech.lef |
| rails: width | 0.44 | <= MAXWIDTH 30.0 | PASS | tech LEF sg13g2_tech.lef |
| rails: width on manufacturing grid | 0.44 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| rails: width = std-cell VDD/VSS rail | 0.44 | == 0.44 (sg13g2_stdcell.lef, sg13g2_inv_1 VDD Metal1 rect) | PASS | stdcell LEF |
| rails: same-net pitch = 2 x row height | 7.56 | == 2 x 3.78 (SITE CoreSite) | PASS | stdcell LEF |
| strap Metal5: layer Metal5 | Metal5 | exists, TYPE ROUTING | PASS | tech LEF sg13g2_tech.lef |
| strap Metal5: width | 2.2 | >= WIDTH 0.2 | PASS | tech LEF sg13g2_tech.lef |
| strap Metal5: width on manufacturing grid | 2.2 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| strap Metal5: pitch on manufacturing grid | 75.6 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| strap Metal5: offset on manufacturing grid | 13.6 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| strap Metal5: VDD-VSS gap (pitch/2 - width) | 35.6 | >= spacing 0.24 (SPACINGTABLE / SPACING, long parallel run) | PASS | tech LEF sg13g2_tech.lef |
| strap Metal5: PDN metal density | 5.8% | <= MAXIMUMDENSITY 60.0% | PASS | tech LEF sg13g2_tech.lef |
| strap Metal5: PDN metal density vs MINIMUMDENSITY | 5.8% | MINIMUMDENSITY 35.0% (fill / signal routing must make up any shortfall) | INFO | tech LEF sg13g2_tech.lef |
| strap Metal5: EM capacity per strap | 4.4 mA | DCCURRENTDENSITY AVERAGE 2.0 mA/um x width | INFO | tech LEF sg13g2_tech.lef |
| strap Metal5: direction | VERTICAL | LEF preferred direction (pdngen draws straps along it) | INFO | tech LEF sg13g2_tech.lef |
| strap TopMetal1: layer TopMetal1 | TopMetal1 | exists, TYPE ROUTING | PASS | tech LEF sg13g2_tech.lef |
| strap TopMetal1: width | 1.8 | >= WIDTH 1.64 | PASS | tech LEF sg13g2_tech.lef |
| strap TopMetal1: width on manufacturing grid | 1.8 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| strap TopMetal1: pitch on manufacturing grid | 30.24 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| strap TopMetal1: offset on manufacturing grid | 13.57 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| strap TopMetal1: VDD-VSS gap (pitch/2 - width) | 13.32 | >= spacing 1.64 (SPACINGTABLE / SPACING, long parallel run) | PASS | tech LEF sg13g2_tech.lef |
| strap TopMetal1: PDN metal density | 11.9% | <= MAXIMUMDENSITY 70.0% | PASS | tech LEF sg13g2_tech.lef |
| strap TopMetal1: PDN metal density vs MINIMUMDENSITY | 11.9% | MINIMUMDENSITY 25.0% (fill / signal routing must make up any shortfall) | INFO | tech LEF sg13g2_tech.lef |
| strap TopMetal1: EM capacity per strap | 27.0 mA | DCCURRENTDENSITY AVERAGE 15.0 mA/um x width | INFO | tech LEF sg13g2_tech.lef |
| strap TopMetal1: direction | HORIZONTAL | LEF preferred direction (pdngen draws straps along it) | INFO | tech LEF sg13g2_tech.lef |
| ring Metal5: layer Metal5 | Metal5 | exists, TYPE ROUTING | PASS | tech LEF sg13g2_tech.lef |
| ring Metal5: width | 5.0 | >= WIDTH 0.2 | PASS | tech LEF sg13g2_tech.lef |
| ring Metal5: width on manufacturing grid | 5.0 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| ring Metal5: spacing | 2.0 | >= 0.24 | PASS | tech LEF sg13g2_tech.lef |
| ring TopMetal1: layer TopMetal1 | TopMetal1 | exists, TYPE ROUTING | PASS | tech LEF sg13g2_tech.lef |
| ring TopMetal1: width | 5.0 | >= WIDTH 1.64 | PASS | tech LEF sg13g2_tech.lef |
| ring TopMetal1: width on manufacturing grid | 5.0 | multiple of 0.005 | PASS | tech LEF sg13g2_tech.lef |
| ring TopMetal1: spacing | 2.0 | >= 1.64 | PASS | tech LEF sg13g2_tech.lef |
| ring: one horizontal + one vertical layer | ['Metal5', 'TopMetal1'] | {HORIZONTAL, VERTICAL} | PASS | tech LEF sg13g2_tech.lef |
| ring: fits between core and die edge | 16.50 um | <= min die-core margin 40.32 um | PASS | DIE_AREA / CORE_AREA |
| connect Metal1->Metal5 | Metal1->Metal5 | both routing layers, bottom below top (pdngen builds the via stack) | PASS | tech LEF sg13g2_tech.lef |
| connect Metal5->TopMetal1 | Metal5->TopMetal1 | both routing layers, bottom below top (pdngen builds the via stack) | PASS | tech LEF sg13g2_tech.lef |
| connect chain reaches the rails | Metal1 | == rail layer Metal1 | PASS |  |
| RM_IHPSG13_1P_1024x64_c2_bm_bist: PG pin layer | ['Metal4'] | == macro connect bottom layer Metal4 | PASS | RM_IHPSG13_1P_1024x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_1024x64_c2_bm_bist: obstruction layers | ['Metal1', 'Metal2', 'Metal3', 'Metal4'] | TopMetal1 and the straps above must not be obstructed | PASS | RM_IHPSG13_1P_1024x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_1024x64_c2_bm_bist: VDD! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDD! stripe 38.825 um | PASS | RM_IHPSG13_1P_1024x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_1024x64_c2_bm_bist: VDDARRAY! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDDARRAY! stripe 290.995 um | PASS | RM_IHPSG13_1P_1024x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_1024x64_c2_bm_bist: VSS! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VSS! stripe 336.460 um | PASS | RM_IHPSG13_1P_1024x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_2048x64_c2_bm_bist: PG pin layer | ['Metal4'] | == macro connect bottom layer Metal4 | PASS | RM_IHPSG13_1P_2048x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_2048x64_c2_bm_bist: obstruction layers | ['Metal1', 'Metal2', 'Metal3', 'Metal4'] | TopMetal1 and the straps above must not be obstructed | PASS | RM_IHPSG13_1P_2048x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_2048x64_c2_bm_bist: VDD! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDD! stripe 38.825 um | PASS | RM_IHPSG13_1P_2048x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_2048x64_c2_bm_bist: VDDARRAY! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDDARRAY! stripe 581.235 um | PASS | RM_IHPSG13_1P_2048x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_2048x64_c2_bm_bist: VSS! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VSS! stripe 626.700 um | PASS | RM_IHPSG13_1P_2048x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_256x64_c2_bm_bist: PG pin layer | ['Metal4'] | == macro connect bottom layer Metal4 | PASS | RM_IHPSG13_1P_256x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_256x64_c2_bm_bist: obstruction layers | ['Metal1', 'Metal2', 'Metal3', 'Metal4'] | TopMetal1 and the straps above must not be obstructed | PASS | RM_IHPSG13_1P_256x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_256x64_c2_bm_bist: VDD! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDD! stripe 38.825 um | PASS | RM_IHPSG13_1P_256x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_256x64_c2_bm_bist: VDDARRAY! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDDARRAY! stripe 73.315 um | PASS | RM_IHPSG13_1P_256x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_256x64_c2_bm_bist: VSS! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VSS! stripe 118.780 um | PASS | RM_IHPSG13_1P_256x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_512x64_c2_bm_bist: PG pin layer | ['Metal4'] | == macro connect bottom layer Metal4 | PASS | RM_IHPSG13_1P_512x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_512x64_c2_bm_bist: obstruction layers | ['Metal1', 'Metal2', 'Metal3', 'Metal4'] | TopMetal1 and the straps above must not be obstructed | PASS | RM_IHPSG13_1P_512x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_512x64_c2_bm_bist: VDD! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDD! stripe 38.825 um | PASS | RM_IHPSG13_1P_512x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_512x64_c2_bm_bist: VDDARRAY! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VDDARRAY! stripe 145.875 um | PASS | RM_IHPSG13_1P_512x64_c2_bm_bist.lef |
| RM_IHPSG13_1P_512x64_c2_bm_bist: VSS! stripes crossed by a same-net TopMetal1 strap | pitch 30.24 + width 1.8 | <= shortest VSS! stripe 191.340 um | PASS | RM_IHPSG13_1P_512x64_c2_bm_bist.lef |
| package: bump array | 13x13 @ 200.0 um | PackageTwin bump_map() | INFO | PackageTwin |
| package: core supply bumps | {'VDD': 37, 'VSS': 35, 'SIG': 73, 'VDDIO': 12, 'VSSIO': 12, 'SPARE': 0} | VDD/VSS from PackageTwin checkerboard | PASS | PackageTwin |
| package: signals placed | 73 | == 73 required | PASS | PackageTwin |
| package: VDD bump EM capacity | 37 x 0.15 A = 5.55 A | compared with analysed currents in reports/pi | INFO | PackageTwin (published range) |

**55 PASS, 0 FAIL, 8 INFO.**
