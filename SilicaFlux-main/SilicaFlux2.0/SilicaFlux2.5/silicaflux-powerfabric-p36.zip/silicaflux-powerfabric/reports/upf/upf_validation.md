# Power-intent (UPF) validation

## What was run

1. **OpenROAD 2.0-12331 `read_upf`** on the placed `sfv_soc_df` database (`upf/validate_upf.tcl`) for the two
   `*.openroad.upf` subset files: objects read back from ODB, every `-elements` path resolved against the
   design hierarchy (OpenROAD itself accepts a non-existent element silently - checked with a deliberately
   bogus path), library searched for isolation / switch / level-shifter / retention cells.
2. **The full IEEE 1801 files** were also given to OpenROAD: it rejects them at the first standard command
   it does not implement (`Error: silicaflux_pf_baseline.upf, 11 invalid command name "upf_version"`).
3. **`scripts/upf_check.py`**: structural checks of the full files (below).

## Not available here (limitation)

No commercial or open-source tool in this environment performs full 1801 semantic verification (supply-state
reachability, isolation completeness on every domain-crossing net, retention coverage, power-state table
legality).  Those checks are required before the FUTURE intent could be implemented, and it cannot be
implemented on IHP SG13G2 anyway (library scan below).

## Library scan (Liberty text, ORFS ab2aaf0f)

| File | is_isolation_cell | switch_cell_type | is_level_shifter | retention_cell | always_on | pg_pin |
|---|---|---|---|---|---|---|
| sg13g2_stdcell_typ_1p20V_25C.lib | 0 | 0 | 0 | 0 | 0 | 0 |

## Structural checks

| File | Check | Status | Detail |
|---|---|---|---|
| silicaflux_pf_baseline.upf | all commands are IEEE 1801-2013 commands | PASS |  |
| silicaflux_pf_baseline.upf | line 19: connect_supply_net VDD: net declared | PASS |  |
| silicaflux_pf_baseline.upf | line 19: port VDD declared | PASS |  |
| silicaflux_pf_baseline.upf | line 20: connect_supply_net VSS: net declared | PASS |  |
| silicaflux_pf_baseline.upf | line 20: port VSS declared | PASS |  |
| silicaflux_pf_baseline.upf | line 21: supply set SS_CORE function power -> net VDD declared | PASS |  |
| silicaflux_pf_baseline.upf | line 21: supply set SS_CORE function ground -> net VSS declared | PASS |  |
| silicaflux_pf_baseline.upf | line 23: domain PD_CORE supply primary -> set SS_CORE declared | PASS |  |
| silicaflux_pf_baseline.upf | line 23: domain PD_CORE has a primary supply | PASS |  |
| silicaflux_pf_baseline.upf | line 28: connect_supply_net VDD: net declared | PASS |  |
| silicaflux_pf_baseline.upf | line 28: domain PD_CORE declared | PASS |  |
| silicaflux_pf_baseline.upf | line 29: connect_supply_net VSS: net declared | PASS |  |
| silicaflux_pf_baseline.upf | line 29: domain PD_CORE declared | PASS |  |
| silicaflux_pf_baseline.upf | line 31: power state object SS_CORE declared | PASS |  |
| silicaflux_pf_baseline.upf | line 32: power state object SS_CORE declared | PASS |  |
| silicaflux_pf_baseline.upf | line 33: power state object PD_CORE declared | PASS |  |
| silicaflux_pf_baseline.upf | line 33: state PD_CORE.RUN references SS_CORE==ON (declared) | PASS |  |
| silicaflux_pf_baseline.upf | line 34: power state object PD_CORE declared | PASS |  |
| silicaflux_pf_baseline.upf | line 34: state PD_CORE.OFF references SS_CORE==OFF (declared) | PASS |  |
| silicaflux_pf_baseline.upf | supply voltages equal config vdd_v | PASS | ['0.0', '1.20'] |
| silicaflux_pf_baseline.upf | baseline: exactly one power domain | PASS | ['PD_CORE'] |
| silicaflux_pf_baseline.upf | baseline: no switch / isolation / retention | PASS |  |
| silicaflux_pf_baseline.upf | OpenROAD read_upf of the subset file | PASS |  |
| silicaflux_pf_baseline.upf | subset domains/elements == full UPF domains/elements | PASS | subset {'PD_CORE': []} full {'PD_CORE': []} |
| silicaflux_pf_baseline.upf | OpenROAD switches == full UPF switches | PASS |  |
| silicaflux_pf_baseline.upf | OpenROAD isolation strategies cover the same domains | PASS |  |
| silicaflux_pf_future.upf | all commands are IEEE 1801-2013 commands | PASS |  |
| silicaflux_pf_future.upf | line 21: connect_supply_net VDD: net declared | PASS |  |
| silicaflux_pf_future.upf | line 21: port VDD declared | PASS |  |
| silicaflux_pf_future.upf | line 22: connect_supply_net VSS: net declared | PASS |  |
| silicaflux_pf_future.upf | line 22: port VSS declared | PASS |  |
| silicaflux_pf_future.upf | line 23: supply set SS_AON function power -> net VDD declared | PASS |  |
| silicaflux_pf_future.upf | line 23: supply set SS_AON function ground -> net VSS declared | PASS |  |
| silicaflux_pf_future.upf | line 24: domain PD_AON supply primary -> set SS_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 24: domain PD_AON has a primary supply | PASS |  |
| silicaflux_pf_future.upf | line 25: connect_supply_net VDD: net declared | PASS |  |
| silicaflux_pf_future.upf | line 25: domain PD_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 26: connect_supply_net VSS: net declared | PASS |  |
| silicaflux_pf_future.upf | line 26: domain PD_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 27: power state object SS_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 35: supply set SS_VEC function power -> net VDD_VEC declared | PASS |  |
| silicaflux_pf_future.upf | line 35: supply set SS_VEC function ground -> net VSS declared | PASS |  |
| silicaflux_pf_future.upf | line 36: domain PD_VEC supply primary -> set SS_VEC declared | PASS |  |
| silicaflux_pf_future.upf | line 36: domain PD_VEC supply default_isolation -> set SS_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 36: domain PD_VEC has a primary supply | PASS |  |
| silicaflux_pf_future.upf | line 37: switch SW_VEC domain PD_VEC declared | PASS |  |
| silicaflux_pf_future.upf | line 37: switch SW_VEC input net VDD declared | PASS |  |
| silicaflux_pf_future.upf | line 37: switch SW_VEC output net VDD_VEC declared | PASS |  |
| silicaflux_pf_future.upf | line 37: switch SW_VEC control pd_pwr_en_vec is a declared logic port | PASS |  |
| silicaflux_pf_future.upf | line 37: switch SW_VEC ack pd_pgood_vec is a declared logic port | PASS |  |
| silicaflux_pf_future.upf | line 37: switch SW_VEC on_state uses its input port | PASS |  |
| silicaflux_pf_future.upf | line 38: isolation ISO_VEC domain declared | PASS |  |
| silicaflux_pf_future.upf | line 38: isolation ISO_VEC supply declared | PASS |  |
| silicaflux_pf_future.upf | line 38: isolation ISO_VEC signal is a declared logic port | PASS |  |
| silicaflux_pf_future.upf | line 38: isolation ISO_VEC clamp value legal | PASS |  |
| silicaflux_pf_future.upf | line 42: level shifter LS_VEC domain declared | PASS |  |
| silicaflux_pf_future.upf | line 44: power state object SS_VEC declared | PASS |  |
| silicaflux_pf_future.upf | line 45: power state object SS_VEC declared | PASS |  |
| silicaflux_pf_future.upf | line 53: supply set SS_TNS function power -> net VDD_TNS declared | PASS |  |
| silicaflux_pf_future.upf | line 53: supply set SS_TNS function ground -> net VSS declared | PASS |  |
| silicaflux_pf_future.upf | line 54: domain PD_TNS supply primary -> set SS_TNS declared | PASS |  |
| silicaflux_pf_future.upf | line 54: domain PD_TNS supply default_isolation -> set SS_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 54: domain PD_TNS supply default_retention -> set SS_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 54: domain PD_TNS has a primary supply | PASS |  |
| silicaflux_pf_future.upf | line 55: switch SW_TNS domain PD_TNS declared | PASS |  |
| silicaflux_pf_future.upf | line 55: switch SW_TNS input net VDD declared | PASS |  |
| silicaflux_pf_future.upf | line 55: switch SW_TNS output net VDD_TNS declared | PASS |  |
| silicaflux_pf_future.upf | line 55: switch SW_TNS control pd_pwr_en_tns is a declared logic port | PASS |  |
| silicaflux_pf_future.upf | line 55: switch SW_TNS ack pd_pgood_tns is a declared logic port | PASS |  |
| silicaflux_pf_future.upf | line 55: switch SW_TNS on_state uses its input port | PASS |  |
| silicaflux_pf_future.upf | line 56: isolation ISO_TNS domain declared | PASS |  |
| silicaflux_pf_future.upf | line 56: isolation ISO_TNS supply declared | PASS |  |
| silicaflux_pf_future.upf | line 56: isolation ISO_TNS signal is a declared logic port | PASS |  |
| silicaflux_pf_future.upf | line 56: isolation ISO_TNS clamp value legal | PASS |  |
| silicaflux_pf_future.upf | line 60: level shifter LS_TNS domain declared | PASS |  |
| silicaflux_pf_future.upf | line 64: retention RET_TNS domain declared | PASS |  |
| silicaflux_pf_future.upf | line 64: retention RET_TNS supply declared | PASS |  |
| silicaflux_pf_future.upf | line 64: retention RET_TNS -save_signal declared | PASS |  |
| silicaflux_pf_future.upf | line 64: retention RET_TNS -restore_signal declared | PASS |  |
| silicaflux_pf_future.upf | line 65: power state object SS_TNS declared | PASS |  |
| silicaflux_pf_future.upf | line 66: power state object SS_TNS declared | PASS |  |
| silicaflux_pf_future.upf | line 69: power state object PD_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 69: state PD_AON.ALL_ON references SS_AON==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 69: state PD_AON.ALL_ON references SS_VEC==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 69: state PD_AON.ALL_ON references SS_TNS==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 70: power state object PD_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 70: state PD_AON.VEC_OFF references SS_AON==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 70: state PD_AON.VEC_OFF references SS_VEC==OFF (declared) | PASS |  |
| silicaflux_pf_future.upf | line 70: state PD_AON.VEC_OFF references SS_TNS==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 71: power state object PD_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 71: state PD_AON.TNS_OFF references SS_AON==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 71: state PD_AON.TNS_OFF references SS_VEC==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 71: state PD_AON.TNS_OFF references SS_TNS==OFF (declared) | PASS |  |
| silicaflux_pf_future.upf | line 72: power state object PD_AON declared | PASS |  |
| silicaflux_pf_future.upf | line 72: state PD_AON.ACC_OFF references SS_AON==ON (declared) | PASS |  |
| silicaflux_pf_future.upf | line 72: state PD_AON.ACC_OFF references SS_VEC==OFF (declared) | PASS |  |
| silicaflux_pf_future.upf | line 72: state PD_AON.ACC_OFF references SS_TNS==OFF (declared) | PASS |  |
| silicaflux_pf_future.upf | switched domain PD_VEC: primary supply is the switch output | PASS |  |
| silicaflux_pf_future.upf | switched domain PD_VEC: has an isolation strategy | PASS |  |
| silicaflux_pf_future.upf | switched domain PD_TNS: primary supply is the switch output | PASS |  |
| silicaflux_pf_future.upf | switched domain PD_TNS: has an isolation strategy | PASS |  |
| silicaflux_pf_future.upf | supply voltages equal config vdd_v | PASS | ['0.0', '1.20'] |
| silicaflux_pf_future.upf | future: switched domains == regions with future.switchable: true | PASS | yaml ['TNS', 'VEC'] upf ['TNS', 'VEC'] |
| silicaflux_pf_future.upf | OpenROAD read_upf of the subset file | PASS |  |
| silicaflux_pf_future.upf | subset domains/elements == full UPF domains/elements | PASS | subset {'PD_AON': [], 'PD_VEC': ['u_tile/u_ve'], 'PD_TNS': ['u_tile/u_te']} full {'PD_AON': [], 'PD_VEC': ['u_tile/u_ve'], 'PD_TNS': ['u_tile/u_te']} |
| silicaflux_pf_future.upf | element u_tile/u_ve exists in the netlist (dbModInst) | PASS | 22963 leaf instances |
| silicaflux_pf_future.upf | element u_tile/u_te exists in the netlist (dbModInst) | PASS | 25290 leaf instances |
| silicaflux_pf_future.upf | OpenROAD switches == full UPF switches | PASS |  |
| silicaflux_pf_future.upf | OpenROAD isolation strategies cover the same domains | PASS |  |

**109 PASS, 0 FAIL.**
