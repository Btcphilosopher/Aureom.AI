# Reproduction of the physical flow

The complete physical flow was re-run **from scratch** in a fresh work directory, starting from the archives in the
Aureom.AI repository (FloorplanLab, PackageTwin, ThermalLab), with the final parameters:

```bash
REPO=<repo> WORK=<fresh>/work EXT=<fresh>/ext bash physical/run_flow.sh all
```

* Runtime: **14 min 34 s** (4 cores), exit status 0.
* ORFS synthesis: 95 096 cells, 5 701 826.53 um2 - identical to the first run and to FloorplanLab's recorded synthesis.
* ORFS PDN stage (`do-2_6_floorplan_pdn`, `PDN_TCL = pdn/sf_pdn.tcl`): `check_power_grid` VDD / VSS pass;
  `reports/pdn/pdn_check_orfs_floorplan_powerfabric.md` (35 PASS, 0 FAIL, before placement).
* Every generated report is **byte-identical** (after removing local absolute paths) to the one shipped in this
  archive:

| Report | Identical |
|---|---|
| `reports/pi/scenarios.md` | yes |
| `reports/pi/package_consistency.md` | yes |
| `reports/physical/power_connectivity.md` | yes |
| `reports/physical/region_placement.md` | yes |
| `reports/pdn/param_validation_powerfabric.md` | yes |
| `reports/pdn/pdn_check_placed_powerfabric.md` | yes |
| `reports/pdn/pdn_check_placed_floorplanlab.md` | yes |
| `reports/upf/upf_validation.md` | yes |
| `reports/tech_cell_audit.md` | yes |

The shipped ORFS logs (`reports/orfs/`) come from this reproduction run.
