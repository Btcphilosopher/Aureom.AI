# Synthesis and elaboration checks

`scripts/run_synth.py`.  Pre-placement numbers only; no timing is claimed.

| Id | Check | Result | Detail |
|---|---|---|---|
| S1 | Yosys 0.38 (ORFS) generic synthesis, baseline, latch-free | PASS | cells 16427, flip-flops 331 |
| S2 | IHP SG13G2 mapping (ORFS Yosys 0.38, typ Liberty), latch-free | PASS | 5336 cells, 61552.121400 um2 (pre-placement, std cells only) |
| S3 | FUTURE parameters (CAP_SWITCH VEC/TNS) synthesise latch-free with ASIC_IMPL=0 | PASS | cells 17074 (simulation configuration; refused with ASIC_IMPL=1, see N1) |
| S4 | sf_pd_icg (SF_PD_IHP_ICG) maps to the IHP clock gate sg13g2_slgcp_1 | PASS | 1 x sg13g2_slgcp_1, no latch |
| N1 | ASIC_IMPL=1 with switchable regions is refused | PASS | Yosys rc=1, Verilator rc=1: silicaflux_power_domain: CAP_SWITCH needs power-switch and isolation cells; the technology declares none (IHP SG13G2). Power gating is a FUT |
| N2 | ASIC_IMPL=1 with logic retention is refused | PASS | Yosys rc=1, Verilator rc=1: silicaflux_power_domain: CAP_LOGIC_RET needs retention cells; the technology declares none. |
| P1 | ASIC_IMPL=1 baseline elaborates | PASS | Yosys rc=0, Verilator rc=0: Yosys and Verilator: elaborated |
| N3 | functional isolation model refused where a physical cell is required | PASS | Yosys rc=1, Verilator rc=1: sf_pd_iso_cell: functional isolation model used where a physical isolation cell is required (no isolation cells in this  |

**8/8 PASS.**
