# RTL mutation testing

Each mutant is one deliberate defect in a copy of `rtl/`; the full regression (FUTURE build, then BASE) must fail.  `scripts/run_mutants.py`.

| Id | Defect | Result | First failure |
|---|---|---|---|
| M01 | drain ignores outstanding DMA writes | KILLED | `FUTURE: FAIL [3700000] active_idle_active: r1: clock stopped with work outstanding` |
| M02 | drain ignores outstanding accelerator ops | KILLED | `FUTURE: FAIL [149600000] random: r2: clock stopped with work outstanding` |
| M03 | abort used without the explicit abort policy | KILLED | `FUTURE: FAIL [15440000] busy_reject: r1 -> T_OFF: completion 10, expected 4` |
| M04 | power-up does not wait for power-good | KILLED | `FUTURE: FAIL [30090000] reset_defaults: r1: state S_ACTIVE not reached (is S_FAULT)` |
| M05 | data isolation released during RESTORE | KILLED | `FUTURE: FAIL [430000] reset_defaults: r3: de-isolated before power/reset/clock/memory ready` |
| M06 | switch opened together with PM isolation / reset | KILLED | `FUTURE: FAIL [43570000] reset_mid_transition: r1: switch opened before iso/iso_pm/reset/clock-stop` |
| M07 | power-good loss not supervised | KILLED | `FUTURE: FAIL [79230000] missing_power_good: power-good loss: not isolated within 6 cycles` |
| M08 | dependency (users still active) ignored when leaving ACTIVE | KILLED | `FUTURE: FAIL [22280000] dependency: r4 -> T_IDLE: response E_OK, expected E_REJ_DEPENDENCY` |
| M09 | wake allowed during thermal hold | KILLED | `FUTURE: FAIL [25380000] thermal: r1 -> T_ACTIVE: response E_OK, expected E_REJ_THERMAL` |
| M10 | clock stop does not wait for the gate acknowledge | KILLED | `FUTURE: FAIL [52210000] control_timeout: r5 -> T_IDLE: completion 0, expected 8` |
| M11 | inrush arbiter grants every requester | KILLED | `FUTURE: FAIL [120000] reset_defaults: more than one region ramping its supply (inrush)` |
| M21 | power-up arbiter ignores dependencies (boot order by index) | KILLED | `FUTURE: FAIL [97790000] boot_order: boot order: r1 ramped at 9658, before / with its provider r3 at 9702` |
| M22 | user releases quiesce before its providers are ACTIVE | KILLED | `FUTURE: FAIL [46110000] reset_mid_transition: r2 ACTIVE while the region it uses (r3) is S_RESTORE` |
| M24 | region restarted from FAULT while its users are in use | KILLED | `FUTURE: FAIL [102460000] provider_fault: r3 -> T_ACTIVE: response E_OK, expected E_REJ_DEPENDENCY` |
| M23 | thermal auto-restore not deferred while a request is accepted | KILLED | `FUTURE: FAIL [34000000] thermal: r1 ACTIVE while the region it uses (r4) is S_CLK_STOP` |
| M12 | SRAM re-initialisation not awaited | KILLED | `FUTURE: FAIL [46820000] reset_mid_transition: SRAM not re-initialised after the interrupted power-up` |
| M13 | retention restore skipped | KILLED | `FUTURE: FAIL [83730000] memory_retention: retained state xxxxxxxx != saved 2d` |
| M14 | MUST_RETAIN memory powered off without retention / loss acceptance | KILLED | `FUTURE: FAIL [84800000] memory_retention: r3 -> T_OFF: response E_OK, expected E_REJ_RET_UNAVAIL` |
| M15 | stale / unsolicited quiesce ack not detected | KILLED | `FUTURE: FAIL [8600000] quiesce: r1: expected error PROTOCOL (stale ack)` |
| M16 | power-good synchroniser resets to 0 (the defect found during development) | KILLED | `FUTURE: FAIL [3020000] active_idle_active: IRQ after reset` |
| M17 | FAULT does not hold a switchable region isolated | KILLED | `FUTURE: FAIL [75010000] missing_power_good: r1: X reached the always-on side of the data boundary` |
| M18 | quiesce timeout not bounded (waits forever) | KILLED | `FUTURE: FAIL [20770000] busy_reject: r1 -> T_IDLE: completion 0, expected 4` |
| M19 | SRAM contents not invalidated before power removal | KILLED | `FUTURE: FAIL [57250000] isolation_sequencing: power-down order q5664 clk5699 iso5702 inv-1 pm5707 rst5707 pwr5710 pg57` |
| M20 | unsupported OFF accepted on a non-switchable region | KILLED | `FUTURE: FAIL [1550000] reset_defaults: r4 -> T_OFF: response E_REJ_DEPENDENCY, expected E_REJ_UNSUPPORTED` |

**24/24 killed.**
