# Technology power-management cell audit (IHP SG13G2)

`scripts/tech_audit.py`: Liberty attributes searched per cell; cell-name patterns as a second, weaker signal.

| Library | File | Cells | Isolation | Level shifter | Power switch | Retention | Always-on | Clock gate | Cells with pg_pin | power_down_function |
|---|---|---|---|---|---|---|---|---|---|---|
| ORFS ab2aaf0f (physical flow) | sg13g2_stdcell_typ_1p20V_25C.lib | 78 | 0 | 0 | 0 | 0 | 0 | sg13g2_lgcp_1, sg13g2_slgcp_1 | 0 | 0 |
| ORFS d0e5b3c (SRAM collateral revision) | sg13g2_stdcell_typ_1p20V_25C.lib | 84 | 0 | 0 | 0 | 0 | 0 | sg13g2_lgcp_1, sg13g2_slgcp_1 | 0 | 0 |
| ORFS d0e5b3c (SRAM collateral revision) | sg13g2_io_typ_1p2V_3p3V_25C.lib | 22 | 0 | 0 | 0 | 0 | 0 | 0 | 22 | 0 |
| IHP SRAM macro (d0e5b3c) | RM_IHPSG13_1P_1024x64_c2_bm_bist_typ_1p20V_25C.lib | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| IHP SRAM macro (d0e5b3c) | RM_IHPSG13_1P_2048x64_c2_bm_bist_typ_1p20V_25C.lib | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| IHP SRAM macro (d0e5b3c) | RM_IHPSG13_1P_256x64_c2_bm_bist_typ_1p20V_25C.lib | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| IHP SRAM macro (d0e5b3c) | RM_IHPSG13_1P_512x64_c2_bm_bist_typ_1p20V_25C.lib | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |

## Findings

* **Isolation, level-shifter, power-switch, retention and always-on cells: none** in either standard-cell revision (Liberty attributes); cell-name patterns in the ab2aaf0f library: none.
* **Clock gates exist**: sg13g2_lgcp_1, sg13g2_slgcp_1 (both marked `dont_use` by the ORFS platform; POWERFABRIC instantiates `sg13g2_slgcp_1` explicitly in `sf_pd_icg`, as SilicaFlux-V's `sfv_clkgate` does).
* The standard-cell Liberty has **no `pg_pin` / `voltage_map`** data: it is not power-aware, so no UPF-driven implementation tool could reason about supply connections from it.
* SRAM macros: `voltage_map` [('VDD', '1.20'), ('VDDARRAY', '1.20'), ('VSS', '0.000000')]; `pg_pin` types [('VDD', 'primary_power'), ('VDDARRAY', 'primary_power'), ('VSS', 'primary_ground')].  `VDDARRAY` is a **primary** supply, not a backup / retention supply, and no retention or `power_down_function` attribute exists: **no retention mode can be claimed**.
* IO library (d0e5b3c): sg13g2_Corner, sg13g2_Filler1000, sg13g2_Filler10000, sg13g2_Filler200, sg13g2_Filler2000, sg13g2_Filler400, sg13g2_Filler4000, sg13g2_IOPadAnalog, sg13g2_IOPadIOVdd, sg13g2_IOPadIOVss, sg13g2_IOPadIn, sg13g2_IOPadInOut16mA, sg13g2_IOPadInOut30mA, sg13g2_IOPadInOut4mA, sg13g2_IOPadOut16mA, sg13g2_IOPadOut30mA, sg13g2_IOPadOut4mA, sg13g2_IOPadTriOut16mA, sg13g2_IOPadTriOut30mA, sg13g2_IOPadTriOut4mA, sg13g2_IOPadVdd, sg13g2_IOPadVss - the pads contain the only real 1.2 V core / 3.3 V IO voltage crossing on the die; they are not in the ab2aaf0f platform used by the physical flow.

**Consequence:** the implemented configuration is ONE supply domain with clock-enable control.  Power gating, isolation, retention and voltage islands remain FUTURE configurations (simulation models only) until a library that provides those cells is adopted.
