# Do the power-grid assumptions match the package model?

PackageTwin v0.1.0 (`scenario_A_fcbga_forced_air`) vs POWERFABRIC.

| Item | POWERFABRIC | PackageTwin | Status |
|---|---|---|---|
| Core supply voltage | 1.2 V | 1.2 V (power_model technology.vdd_v) | MATCH |
| Bump array / pitch / keep-out / signal rings / pattern | 200.0 um, 120.0 um, 3, checkerboard | 200.0 um, 120.0 um, 3, checkerboard | MATCH |
| Bump sites used as PDN sources | 37 VDD + 35 VSS (PackageTwin bump_map() on this die) | same function, same die | MATCH |
| Every core P/G bump lands on a same-net top strap | C11 in the connectivity report | <= 50 um pad radius | MATCH |
| Core current, mixed workload | 15.167 mA (sum of bump currents) | 15.167 mA (workload_power.csv) | MATCH |
| Max current per bump vs EM limit | 1.91 mA | 150 mA (published C4 range) | MATCH |
| Static IR budget | die VDD+VSS 0.90 mV | 36 mV (3 % of 1.2 V) | MATCH |
| PowerGrid export accepted by PackageTwin powergrid-import and ThermalLab load_powergrid_export | nodes.csv / resistors.csv (mixed, VDD) | both importers ran (reports/pi/powerfabric/import_check.txt) | MATCH |
| PackageTwin's own on-die grid model | PowerFabric adds TopMetal2 straps (14 um / 100 um) under the C4 array | PackageTwin models Metal1 / Metal5 / TopMetal1 from FloorplanLab (m5 2.2 um / 75.6 um) - update PackageTwin to read this PowerGrid export instead of its homogenised grid | ACTION |
