# Power integrity: static IR drop, current concentration, EM screening

`scripts/powergrid.py` on PDNSim's extracted network of each PDN variant, PackageTwin C4 bumps as sources (R_bump = 0.018 ohm), loads = OpenSTA per-instance power distribution scaled to the PackageTwin workload classes + explicit SRAM access power.  Budget: static VDD drop + VSS bounce <= 36 mV (3 % of 1.2 V, PackageTwin).  EM ratio = worst current density / LEF `DCCURRENTDENSITY AVERAGE` (metals per um width, vias per cut).  These are estimates, not signoff.

| Variant | Scenario | Core power (mW) | Core current (mA) | VDD worst drop (mV) | VSS worst bounce (mV) | Sum / budget | IR headroom | Worst EM ratio (layer) | Max bump current (mA) / limit |
|---|---|---|---|---|---|---|---|---|---|
| powerfabric | idle | 6.25 | 5.21 | 0.299 | 0.135 | 0.43 / 36 | 83x | 0.0312 (Metal1) | 0.39 / 150 |
| powerfabric | control | 7.71 | 6.42 | 0.336 | 0.151 | 0.49 / 36 | 74x | 0.0351 (Metal1) | 0.51 / 150 |
| powerfabric | vector | 13.41 | 11.17 | 0.425 | 0.207 | 0.63 / 36 | 57x | 0.0403 (Metal1) | 1.09 / 150 |
| powerfabric | tensor | 17.89 | 14.91 | 0.482 | 0.430 | 0.91 / 36 | 39x | 0.0416 (Metal1) | 2.01 / 150 |
| powerfabric | memory | 8.68 | 7.23 | 0.448 | 0.200 | 0.65 / 36 | 56x | 0.0473 (Metal1) | 0.49 / 150 |
| powerfabric | mixed | 18.20 | 15.17 | 0.518 | 0.384 | 0.90 / 36 | 40x | 0.0458 (Metal1) | 1.91 / 150 |
| powerfabric | max_simultaneous | 34.07 | 28.39 | 0.752 | 0.533 | 1.29 / 36 | 28x | 0.0668 (Metal1) | 2.72 / 150 |
| powerfabric | stress_bound | 63.51 | 52.93 | 0.871 | 0.871 | 1.74 / 36 | 21x | 0.0565 (Metal1) | 4.63 / 150 |
| floorplanlab | idle | 6.25 | 5.21 | 0.388 | 0.222 | 0.61 / 36 | 59x | 0.0314 (Metal1) | 0.40 / 150 |
| floorplanlab | control | 7.71 | 6.42 | 0.437 | 0.285 | 0.72 / 36 | 50x | 0.0354 (Metal1) | 0.53 / 150 |
| floorplanlab | vector | 13.41 | 11.17 | 0.817 | 1.056 | 1.87 / 36 | 19x | 0.0413 (Metal1) | 1.32 / 150 |
| floorplanlab | tensor | 17.89 | 14.91 | 1.354 | 1.664 | 3.02 / 36 | 12x | 0.0491 (TopVia1) | 2.02 / 150 |
| floorplanlab | memory | 8.68 | 7.23 | 0.573 | 0.399 | 0.97 / 36 | 37x | 0.0476 (Metal1) | 0.55 / 150 |
| floorplanlab | mixed | 18.20 | 15.17 | 1.156 | 1.395 | 2.55 / 36 | 14x | 0.0482 (Metal1) | 1.92 / 150 |
| floorplanlab | max_simultaneous | 34.07 | 28.39 | 2.279 | 2.906 | 5.18 / 36 | 7x | 0.0757 (TopVia1) | 3.11 / 150 |
| floorplanlab | stress_bound | 63.51 | 52.93 | 4.720 | 5.619 | 10.34 / 36 | 3x | 0.1366 (TopVia1) | 5.61 / 150 |

## Per-region worst VDD drop, `mixed` (mV)

| Variant | CTRL | VEC | TNS | SRAM | FABRIC | EXTIF | AON |
|---|---|---|---|---|---|---|---|
| powerfabric | 0.172 | 0.518 | 0.425 | 0.184 | 0.425 | 0.298 | 0.518 |
| floorplanlab | 0.519 | 1.119 | 1.144 | 0.919 | 0.749 | 0.704 | 1.138 |

## EM by layer, `stress_bound`, powerfabric VDD

| Layer | worst | LEF limit | ratio |
|---|---|---|---|
| Metal1 | 0.0565 mA/um | 1.0 mA/um | 0.0565 |
| Metal5 | 0.0234 mA/um | 2.0 mA/um | 0.0117 |
| TopMetal1 | 0.2870 mA/um | 15.0 mA/um | 0.0191 |
| TopMetal2 | 0.2878 mA/um | 16.0 mA/um | 0.0180 |
| Via1 | 0.0022 mA/cut | 0.4 mA/cut | 0.0055 |
| Via2 | 0.0022 mA/cut | 0.4 mA/cut | 0.0055 |
| Via3 | 0.0022 mA/cut | 0.4 mA/cut | 0.0055 |
| Via4 | 0.0022 mA/cut | 0.4 mA/cut | 0.0055 |
| TopVia1 | 0.0048 mA/cut | 1.4 mA/cut | 0.0034 |
| TopVia2 | 0.0075 mA/cut | 10.0 mA/cut | 0.0008 |

## Solver validation against OpenROAD PDNSim

Same network, PDNSim's own ideal sources and loads (from `write_pg_spice`), node-by-node comparison with `analyze_power_grid`'s voltage report:

| Net | nodes | points compared | this solver worst drop | PDNSim worst drop | max abs diff | p99 abs diff |
|---|---|---|---|---|---|---|
| VDD | 92880 | 103740 | 0.6438 mV | 0.6100 mV | 0.0365 mV | 0.0286 mV |
| VSS | 93982 | 104039 | 0.3249 mV | 0.2996 mV | 0.0348 mV | 0.0276 mV |

The residual (about 6 % of the VDD and 11 % of the VSS sub-millivolt worst drop) is systematic and was not traced further; it is far below every margin above.  Floating nodes: VDD 0, VSS 0.  ![IR map](ir_map_mixed_vdd.png)
