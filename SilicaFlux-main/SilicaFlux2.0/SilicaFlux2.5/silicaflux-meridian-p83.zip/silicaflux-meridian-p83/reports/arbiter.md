# Arbiter: differential test against the verified sfn_qos_arbiter, and starvation bound

`sf_meridian_arbiter` vs `third_party/p22/sfn_qos_arbiter.sv` (Project 22, unmodified, stall = 0), compared every cycle on grant / index / valid /
urgent under random requests, classes and downstream `en` (tests/meridian/tb/tb_arb_diff.sv). RR mode is compared with STARVE = 0.
The longest observed wait of a continuously requesting requester is compared with the bound (QOS: STARVE + N - 1; RR: N - 1).

| N | mode | STARVE | result | cycles compared | longest wait | bound |
|---|---|---|---|---|---|---|
| 2 | RR | 0 | PASS | 300000 | 1 | 1 |
| 3 | RR | 0 | PASS | 300000 | 2 | 2 |
| 4 | RR | 0 | PASS | 300000 | 3 | 3 |
| 5 | RR | 0 | PASS | 300000 | 4 | 4 |
| 7 | RR | 0 | PASS | 300000 | 6 | 6 |
| 8 | RR | 0 | PASS | 300000 | 7 | 7 |
| 2 | QOS | 0 | PASS | 300000 | 1 | 1 |
| 2 | QOS | 1 | PASS | 300000 | 1 | 2 |
| 2 | QOS | 3 | PASS | 300000 | 3 | 4 |
| 2 | QOS | 8 | PASS | 300000 | 8 | 9 |
| 3 | QOS | 0 | PASS | 300000 | 2 | 2 |
| 3 | QOS | 1 | PASS | 300000 | 2 | 3 |
| 3 | QOS | 3 | PASS | 300000 | 4 | 5 |
| 3 | QOS | 8 | PASS | 300000 | 9 | 10 |
| 4 | QOS | 0 | PASS | 300000 | 3 | 3 |
| 4 | QOS | 1 | PASS | 300000 | 3 | 4 |
| 4 | QOS | 3 | PASS | 300000 | 5 | 6 |
| 4 | QOS | 8 | PASS | 300000 | 10 | 11 |
| 5 | QOS | 0 | PASS | 300000 | 4 | 4 |
| 5 | QOS | 1 | PASS | 300000 | 4 | 5 |
| 5 | QOS | 3 | PASS | 300000 | 6 | 7 |
| 5 | QOS | 8 | PASS | 300000 | 11 | 12 |
| 7 | QOS | 0 | PASS | 300000 | 6 | 6 |
| 7 | QOS | 1 | PASS | 300000 | 6 | 7 |
| 7 | QOS | 3 | PASS | 300000 | 8 | 9 |
| 7 | QOS | 8 | PASS | 300000 | 13 | 14 |
| 1 | QOS | 2 | PASS | 300000 | 0 | 2 |
| 8 | QOS | 12 | PASS | 300000 | 18 | 19 |

**28 / 28 configurations passed.**
