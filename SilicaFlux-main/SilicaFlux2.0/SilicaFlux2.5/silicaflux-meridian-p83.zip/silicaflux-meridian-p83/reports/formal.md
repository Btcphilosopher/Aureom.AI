# Formal verification (SymbiYosys: Yosys + smtbmc + z3)

`bmc` = bounded model check to the stated depth (a bounded proof: no counterexample within that many cycles). `prove` = BMC base case plus
k-induction: PASS means an UNBOUNDED proof; UNKNOWN means induction did not close at that depth (the property was still checked by BMC to the depth;
it is NOT counted as proved). `mutant` jobs run the same harness on a deliberately broken copy of the RTL and must FAIL (counterexample found):
they show the properties are not vacuous.

| job | harness | mode | depth | expected | result | as expected | time |
|---|---|---|---|---|---|---|---|
| fifo_d1_prove | fv_fifo {"W": 4, "DEPTH": 1} | prove | 14 | PASS | PASS | yes | 1.1 s |
| fifo_d2_bmc | fv_fifo {"W": 4, "DEPTH": 2} | bmc | 16 | PASS | PASS | yes | 3.7 s |
| fifo_d3_bmc | fv_fifo {"W": 4, "DEPTH": 3} | bmc | 20 | PASS | PASS | yes | 144.5 s |
| fifo_d4_bmc | fv_fifo {"W": 4, "DEPTH": 4} | bmc | 16 | PASS | PASS | yes | 63.7 s |
| slice_s1_bmc | fv_slice {"W": 3, "STAGES": 1} | bmc | 16 | PASS | PASS | yes | 11.4 s |
| slice_s1_latency | fv_slice {"W": 3, "STAGES": 1, "LAT": 1} | bmc | 18 | PASS | PASS | yes | 4.0 s |
| slice_s2_bmc | fv_slice {"W": 3, "STAGES": 2} | bmc | 16 | PASS | PASS | yes | 98.2 s |
| slice_s2_latency | fv_slice {"W": 3, "STAGES": 2, "LAT": 1} | bmc | 18 | PASS | PASS | yes | 13.8 s |
| slice_s3_bmc | fv_slice {"W": 3, "STAGES": 3} | bmc | 16 | PASS | PASS | yes | 287.7 s |
| slice_s3_latency | fv_slice {"W": 3, "STAGES": 3, "LAT": 1} | bmc | 18 | PASS | PASS | yes | 28.6 s |
| arb_n2_qos_s3_bmc | fv_arbiter {"N": 2, "MODE": 1, "STARVE": 3} | bmc | 26 | PASS | PASS | yes | 27.1 s |
| arb_n3_qos_s2_bmc | fv_arbiter {"N": 3, "MODE": 1, "STARVE": 2} | bmc | 24 | PASS | PASS | yes | 146.1 s |
| arb_n4_qos_s1_bmc | fv_arbiter {"N": 4, "MODE": 1, "STARVE": 1} | bmc | 18 | PASS | PASS | yes | 139.0 s |
| arb_n3_rr_bmc | fv_arbiter {"N": 3, "MODE": 0, "STARVE": 0} | bmc | 24 | PASS | PASS | yes | 5.9 s |
| arb_n4_rr_bmc | fv_arbiter {"N": 4, "MODE": 0, "STARVE": 0} | bmc | 20 | PASS | PASS | yes | 12.0 s |
| decoder_bmc | fv_decoder {} | bmc | 2 | PASS | PASS | yes | 1.4 s |
| fabric_adv0_tsl0_bmc | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 0} | bmc | 10 | PASS | PASS | yes | 226.4 s |
| fabric_adv0_tsl1_bmc | fv_fabric {"ADV": 0, "TSL": 1, "TMO": 0} | bmc | 11 | PASS | PASS | yes | 247.9 s |
| fabric_adv1_tsl0_bmc | fv_fabric {"ADV": 1, "TSL": 0, "TMO": 0} | bmc | 10 | PASS | PASS | yes | 57.9 s |
| fabric_adv1_tsl1_bmc | fv_fabric {"ADV": 1, "TSL": 1, "TMO": 0} | bmc | 11 | PASS | PASS | yes | 87.5 s |
| fabric_tmo_bmc | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 3} | bmc | 11 | PASS | PASS | yes | 357.0 s |
| fabric_cover | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 0} | cover | 11 | PASS | PASS | yes | 11.5 s |
| mut_fifo_overflow | fv_fifo {"W": 4, "DEPTH": 3} | bmc | 12 | FAIL | FAIL | yes | 1.5 s |
| mut_fifo_underflow | fv_fifo {"W": 4, "DEPTH": 3} | bmc | 12 | FAIL | FAIL | yes | 1.7 s |
| mut_slice_loss | fv_slice {"W": 3, "STAGES": 2} | bmc | 12 | FAIL | FAIL | yes | 1.6 s |
| mut_arb_ptr | fv_arbiter {"N": 3, "MODE": 0, "STARVE": 0} | bmc | 20 | FAIL | FAIL | yes | 1.4 s |
| mut_arb_aging | fv_arbiter {"N": 3, "MODE": 1, "STARVE": 2} | bmc | 26 | FAIL | FAIL | yes | 1.9 s |
| mut_arb_ignore_req | fv_arbiter {"N": 3, "MODE": 0, "STARVE": 0} | bmc | 6 | FAIL | FAIL | yes | 1.8 s |
| mut_dec_lowest | fv_decoder {} | bmc | 2 | FAIL | FAIL | yes | 1.6 s |
| mut_fab_ignore_citadel | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 0} | bmc | 10 | FAIL | FAIL | yes | 8.4 s |
| mut_fab_no_domain_bind | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 0} | bmc | 10 | FAIL | FAIL | yes | 6.3 s |
| mut_fab_src_stamp | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 0} | bmc | 10 | FAIL | FAIL | yes | 11.4 s |
| mut_fab_tag_lost | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 0} | bmc | 10 | FAIL | FAIL | yes | 9.5 s |
| mut_fab_steer | fv_fabric {"ADV": 0, "TSL": 0, "TMO": 0} | bmc | 10 | FAIL | FAIL | yes | 21.3 s |

**34 / 34 jobs as expected, 0 not as expected, 0 induction attempts did not close; 1 unbounded proofs.**

