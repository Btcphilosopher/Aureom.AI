# Mutation check of the simulation regression

Each mutant is one deliberate RTL defect on a private copy of the sources (scripts/mutate.py); the named configuration of tb_meridian
(all tests, seed 1) must FAIL. KILLED = some check noticed; SURVIVED = blind spot.

| mutant | defect | configuration | result | first failing check | s |
|---|---|---|---|---|---|
| M01_ignore_citadel | Citadel verdict ignored | ref_2x2 | **KILLED** | FAIL @208 [domain_protection] target 0 received a request the oracle says must be answered locally (src 0 tag 1, status 3) | 56 |
| M02_no_domain_binding | domain-binding check removed | ref_2x2 | **KILLED** | FAIL @227 [domain_protection] target 0 received a request the oracle says must be answered locally (src 0 tag 9, status 3) | 56 |
| M03_citadel_fail_open | Citadel outage fails OPEN (orphan state permits) | ref_2x2 | **KILLED** | FAIL @431 [citadel_failclosed] target 0 received a request the oracle says must be answered locally (src 0 tag 9, status 3) | 59 |
| M04_denial_wrong_status | denial reported as decode error | ref_2x2 | **KILLED** | FAIL @207 [domain_protection] master 0 tag 1: local error status 2, expected 3 | 52 |
| M05_src_stamp | source stamp always 0 | ref_2x2 | **KILLED** | FAIL @59 [routes] target 0 received (src 0, tag 11) that is not outstanding | 62 |
| M06_tag_lost | tag not forwarded | ref_2x2 | **KILLED** | FAIL @23 [routes] target 0 received (src 0, tag 0) that is not outstanding | 65 |
| M07_domain_lost | domain not forwarded | ref_2x2 | **KILLED** | FAIL @59 [routes] request domain changed in the fabric | 56 |
| M08_priv_lost | privilege not forwarded | ref_2x2 | **KILLED** | FAIL @131 [invalid_and_protocol] request priv changed in the fabric | 56 |
| M09_steer_all | responses steered to every master | ref_2x2 | **KILLED** | FAIL @96 [routes] counter m0.V_ORPHAN: DUT 4, mirror 0 | 55 |
| M10_wdata_corrupt | write data bit flipped | ref_2x2 | **KILLED** | FAIL @23 [routes] request write data changed in the fabric | 53 |
| M11_strobe_corrupt | strobes inverted | ref_2x2 | **KILLED** | FAIL @23 [routes] request write strobes changed in the fabric | 56 |
| M12_arb_ptr_frozen | round-robin pointer frozen | stress_4x2_rr | **KILLED** | FAIL @424 [domain_protection] arbitration bound 3 exceeded at target 0 for master 3 (6 transfers of others) | 82 |
| M13_arb_no_aging | aging disabled: starvation | stress_4x2_s30 | **KILLED** | FAIL @1133 [simultaneous_n200_bad10] arbitration bound 33 exceeded at target 0 for master 2 (35 transfers of others) | 75 |
| M14_arb_ignore_class | class levels ignored | stress_4x2_s30 | **KILLED** | FAIL @11038 [qos_classes] class levels have no effect on latency (STARVE >= 16) | 72 |
| M15_pop_ignores_ready | request popped although the egress stage is full (loss) | stress_4x2 | **KILLED** | FAIL @401510 [random_backpressure] wait_quiet: system did not drain in 400000 cycles (pend=7,8) | 76 |
| M16_push_ignores_full | request pushed into a full buffer (loss) | stress_4x2 | **KILLED** | FAIL @200763 [simultaneous_n120_bad0] wait_quiet: system did not drain in 200000 cycles (pend=6,5) | 75 |
| M17_fifo_overflow | vendored FIFO accepts when full | stress_4x2 | **KILLED** | FAIL @776 [simultaneous_n120_bad0] target 1 received (src 0, tag 2) that is not outstanding | 75 |
| M18_tag_reuse_accepted | illegal tag reuse not rejected | m3t2_ooo | **KILLED** | FAIL @13478 [tag_reuse_rejected] target 1 received a request twice (src 0 tag 5) | 39 |
| M19_inorder_broken | in-order delivery not enforced | m3t2_ooo | **KILLED** | FAIL @237 [domain_protection] master 0: response order violated (got tag 6, oldest outstanding 1) | 41 |
| M20_echo_unchecked | response echo not checked | ref_2x2 | **KILLED** | FAIL @9976 [faults_dup_echo_badsrc] master 0 tag 6: status 0, target answered 5 | 43 |
| M21_no_timeout | response timeout never fires | m2t2_tmo | **KILLED** | FAIL @16451 [timeout_isolation] wait_quiet_ign: system did not drain in 5800 cycles | 48 |
| M22_zombie_freed_early | timed-out slot freed at once (tag reusable before the late response) | m2t2_tmo | **KILLED** | FAIL @11172 [timeout_isolation] isolation not cleared by the late response | 46 |
| M23_no_isolation | timeout does not isolate the target | m2t2_tmo | **KILLED** | FAIL @10961 [timeout_isolation] target not isolated after the timeout | 42 |
| M24_hol_never_cancels | head-of-line request never cancelled (isolation off: only the watchdog can help) | m2t2_tmo_noiso | **KILLED** | FAIL @17575 [timeout_isolation] wait_quiet_ign: system did not drain in 6400 cycles | 42 |
| M25_perf_cplerr | error-completion counter counts every completion | ref_2x2 | **KILLED** | FAIL @94 [routes] counter m0.CPLERR: DUT 4, mirror 0 | 35 |
| M26_reset_slots | slot state not cleared by reset | ref_2x2 | **KILLED** | FAIL @12324 [reset_under_load] slots not free after reset | 37 |
| M27_alignment_unchecked | misaligned addresses accepted | ref_2x2 | **KILLED** | FAIL @123 [invalid_and_protocol] target 0 received a request the oracle says must be answered locally (src 0 tag 8, status 5) | 38 |
| M28_reach_ignores_conn | topology connectivity ignored | m4t3_mixed | **KILLED** | FAIL @4113 [routes] wait_quiet: system did not drain in 4000 cycles (pend=0,2) | 57 |
| M29_deny_still_forwards_domain | requests denied for the domain still forwarded | ref_2x2 | **KILLED** | FAIL @223 [domain_protection] target 0 received a request the oracle says must be answered locally (src 0 tag 5, status 3) | 37 |
| M31_duplicate_accepted | a completed slot accepts a second response | ref_2x2 | **KILLED** | FAIL @12166 [faults_dup_echo_badsrc] counter m0.V_ORPHAN: DUT 0, mirror 17 | 34 |
| M30_slot_status_lost | target error status replaced by OKAY | ref_2x2 | **KILLED** | FAIL @2616 [random_backpressure] master 0 tag 1: status 0, target answered 1 | 33 |

**31 / 31 mutants killed.**
