// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_fabric   (PRIMARY RTL)
//
// Common on-chip communication fabric of the SilicaFlux Albion cloud device: a registered, crosspoint-buffered
// NM x NT crossbar with per-master protection (domain binding + Citadel permission check), tags and slots,
// round-robin / class-aware arbitration, configurable outstanding transactions, register slices for distant regions,
// fault handling and performance counters.  Reference configuration: 2 masters x 2 targets, one outstanding
// transaction per master.  Everything scales by parameters (docs/meridian/01_ARCHITECTURE.md).
//
//   master side:  m_req_*  / m_rsp_*   valid/ready channels, flat vectors indexed by master
//   target side:  t_req_*  / t_rsp_*   valid/ready channels, flat vectors indexed by target
//   Citadel:      cit_*                check port per master (CITADEL_MODE = CIT_EXT) + pol_* policy port (CIT_REF)
//   management:   iso_clear, zomb_flush, elog_*, perf_* ports
//
// Reset: rst_n asynchronous assert, synchronous release expected from the platform (Keystone SYS reset network);
// every buffer, slot, arbiter pointer, counter and log is cleared: no transaction survives reset.
// Transaction format and rules: docs/meridian/02_PROTOCOL.md.  Master rules: a master must not wait for ready
// before asserting valid, and must hold valid and every field stable until ready.
// Target rules: a target echoes {src, tag, dom, op} of every request it answers and answers each request exactly once, with
// status OKAY or SLVERR, in any order (ports with OOO = 0 re-order; violations are detected and contained, 02_PROTOCOL.md sec. 2).
//
// Pipeline latency (empty fabric, MST_SLICE = TGT_SLICE = 0): request accepted at cycle 0 -> target sees it at cycle 2;
// target response at cycle r -> master sees it at cycle r + 1.  Each slice stage adds 1 cycle in its direction.
// =============================================================================
`default_nettype none

module sf_meridian_fabric #(
  parameter int                          NM            = 2,
  parameter int                          NT            = 2,
  parameter int                          AW            = 32,
  parameter int                          DW            = 64,
  parameter int                          TAGW          = 4,
  parameter int                          DOMW          = 3,
  // ---- address map and topology
  parameter logic [NT*AW-1:0]            TGT_BASE      = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0]            TGT_MASK      = {(NT*AW){1'b0}},
  parameter logic [NM*NT-1:0]            CONN          = {(NM*NT){1'b1}},     // bit m*NT + t: master m can reach target t
  parameter int                          REQ_DEPTH     = 2,                   // crosspoint buffer entries (>= 2: full rate)
  // ---- per-master configuration
  parameter logic [NM*8-1:0]             MST_MAXO      = {NM{8'd1}},          // outstanding transactions per master (1..16)
  parameter logic [NM-1:0]               MST_OOO       = {NM{1'b0}},          // 1: out-of-order completion delivery
  parameter logic [NM*(1<<DOMW)-1:0]     MST_DOM_ALLOW = {(NM*(1<<DOMW)){1'b1}},   // domains each port may present
  // ---- physical pipelining (stages per direction)
  parameter logic [NM*4-1:0]             MST_SLICE     = {(NM*4){1'b0}},
  parameter logic [NT*4-1:0]             TGT_SLICE     = {(NT*4){1'b0}},
  // ---- arbitration
  parameter int                          ARB_MODE      = 1,                   // 0 round robin, 1 class levels + aging
  parameter int                          STARVE        = 8,
  // ---- access control
  parameter int                          CITADEL_MODE  = 1,                   // 0 off (bring-up), 1 reference table, 2 external
  parameter int                          CIT_NENT      = 8,
  parameter int                          CIT_LAT       = 0,
  parameter int                          CHK_TMO       = 32,
  // ---- fault handling
  parameter int                          TMO           = 0,                   // request / response timeout cycles, 0 = off
  parameter int                          ISOLATE       = 1,
  // ---- counters
  parameter int                          LATW          = 16,
  parameter int                          CW            = 32,
  localparam int                         NDOM          = 1 << DOMW,
  localparam int                         SRCW          = sf_meridian_pkg::clog2c(NM),
  localparam int                         TW            = sf_meridian_pkg::clog2c(NT),
  localparam int                         RQW           = 2 + TAGW + DOMW + 1 + 3 + AW + DW + DW / 8,
  localparam int                         MRW           = TAGW + DOMW + 2 + 3 + DW,
  localparam int                         BW            = sf_meridian_pkg::clog2c(DW / 8 + 1),
  localparam int                         NCNT          = sf_meridian_pkg::pf_n(NM, NT),
  localparam int                         RSW           = sf_meridian_pkg::clog2c(NCNT),
  localparam int                         CITIW         = sf_meridian_pkg::clog2c(CIT_NENT),
  localparam int                         OW            = sf_meridian_pkg::clog2c(NM * REQ_DEPTH + 1)
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,

  // ---------------- master side
  input  wire logic [NM-1:0]        m_req_valid,
  output logic      [NM-1:0]        m_req_ready,
  input  wire logic [NM*2-1:0]      m_req_op,
  input  wire logic [NM*TAGW-1:0]   m_req_tag,
  input  wire logic [NM*DOMW-1:0]   m_req_dom,
  input  wire logic [NM-1:0]        m_req_priv,
  input  wire logic [NM*3-1:0]      m_req_tc,
  input  wire logic [NM*AW-1:0]     m_req_addr,
  input  wire logic [NM*DW-1:0]     m_req_wdata,
  input  wire logic [NM*DW/8-1:0]   m_req_wstrb,
  output logic      [NM-1:0]        m_rsp_valid,
  input  wire logic [NM-1:0]        m_rsp_ready,
  output logic      [NM*TAGW-1:0]   m_rsp_tag,
  output logic      [NM*DOMW-1:0]   m_rsp_dom,
  output logic      [NM*2-1:0]      m_rsp_op,
  output logic      [NM*3-1:0]      m_rsp_status,
  output logic      [NM*DW-1:0]     m_rsp_rdata,

  // ---------------- target side
  output logic      [NT-1:0]        t_req_valid,
  input  wire logic [NT-1:0]        t_req_ready,
  output logic      [NT*SRCW-1:0]   t_req_src,
  output logic      [NT*2-1:0]      t_req_op,
  output logic      [NT*TAGW-1:0]   t_req_tag,
  output logic      [NT*DOMW-1:0]   t_req_dom,
  output logic      [NT-1:0]        t_req_priv,
  output logic      [NT*3-1:0]      t_req_tc,
  output logic      [NT*AW-1:0]     t_req_addr,
  output logic      [NT*DW-1:0]     t_req_wdata,
  output logic      [NT*DW/8-1:0]   t_req_wstrb,
  input  wire logic [NT-1:0]        t_rsp_valid,
  output logic      [NT-1:0]        t_rsp_ready,
  input  wire logic [NT*SRCW-1:0]   t_rsp_src,
  input  wire logic [NT*TAGW-1:0]   t_rsp_tag,
  input  wire logic [NT*DOMW-1:0]   t_rsp_dom,
  input  wire logic [NT*2-1:0]      t_rsp_op,
  input  wire logic [NT*3-1:0]      t_rsp_status,
  input  wire logic [NT*DW-1:0]     t_rsp_rdata,

  // ---------------- Citadel: external check ports (CIT_EXT) -- queries are visible in every mode
  output logic      [NM-1:0]        cit_req_valid,
  input  wire logic [NM-1:0]        cit_req_ready,
  output logic      [NM*DOMW-1:0]   cit_req_dom,
  output logic      [NM-1:0]        cit_req_priv,
  output logic      [NM-1:0]        cit_req_write,
  output logic      [NM*AW-1:0]     cit_req_addr,
  input  wire logic [NM-1:0]        cit_rsp_valid,
  input  wire logic [NM-1:0]        cit_rsp_ok,
  input  wire logic [NM*4-1:0]      cit_rsp_fault,
  // ---------------- Citadel: reference policy port (CIT_REF) and verification hook
  input  wire logic                 pol_we,
  input  wire logic [CITIW-1:0]     pol_idx,
  input  wire logic                 pol_valid,
  input  wire logic [NM-1:0]        pol_src,
  input  wire logic [NDOM-1:0]      pol_dom,
  input  wire logic                 pol_priv,
  input  wire logic [AW-1:0]        pol_base,
  input  wire logic [AW-1:0]        pol_mask,
  input  wire logic                 pol_rd,
  input  wire logic                 pol_wr,
  input  wire logic [NM-1:0]        tst_cit_stall,

  // ---------------- management
  input  wire logic [NT-1:0]        iso_clear,
  input  wire logic                 zomb_flush,
  output logic      [NM*NT-1:0]     o_iso,               // [m*NT + t] target isolated for master port m
  output logic      [NM-1:0]        o_cit_orphan,
  // ---------------- error log (first fault, sticky until elog_clear) and event pulses
  input  wire logic                 elog_clear,
  output logic                      elog_valid,
  output logic      [SRCW-1:0]      elog_src,
  output logic      [2:0]           elog_status,
  output logic      [3:0]           elog_fault,
  output logic      [AW-1:0]        elog_addr,
  output logic      [DOMW-1:0]      elog_dom,
  output logic      [TAGW-1:0]      elog_tag,
  output logic      [TW-1:0]        elog_tgt,
  output logic      [CW-1:0]        elog_count,
  output logic                      evt_err,             // an error response was created this cycle
  output logic                      evt_sec,             // a request was DENIED this cycle (security event)
  // ---------------- performance counters
  input  wire logic                 perf_clear,
  input  wire logic                 perf_freeze,
  input  wire logic [RSW-1:0]       perf_sel,
  output logic      [CW-1:0]        perf_data
);

`ifndef SYNTHESIS
  initial begin
    if (NM < 1 || NT < 1)       $error("sf_meridian_fabric: NM and NT must be >= 1");
    if (REQ_DEPTH < 2)          $warning("sf_meridian_fabric: REQ_DEPTH < 2 halves the per-crosspoint rate");
    if (TAGW < 1 || DOMW < 1)   $error("sf_meridian_fabric: TAGW / DOMW must be >= 1");
    if (DW < 8 || (DW & (DW - 1)) != 0 || DW > 256) $error("sf_meridian_fabric: DW must be a power of two in 8..256");
    for (int m = 0; m < NM; m++)
      if (MST_MAXO[m*8 +: 8] < 8'd1 || MST_MAXO[m*8 +: 8] > 8'd16) $error("sf_meridian_fabric: MST_MAXO[%0d] must be 1..16", m);
    for (int i = 0; i < NT; i++)
      for (int j = i + 1; j < NT; j++)
        if (((TGT_BASE[i*AW +: AW] ^ TGT_BASE[j*AW +: AW]) & TGT_MASK[i*AW +: AW] & TGT_MASK[j*AW +: AW]) == '0)
          $error("sf_meridian_fabric: address windows of targets %0d and %0d overlap", i, j);
  end
`endif

  // ------------------------------------------------------------ Citadel wiring
  logic [NM-1:0]      c_req_valid, c_req_ready, c_rsp_valid, c_rsp_ok;
  logic [NM*4-1:0]    c_rsp_fault;
  logic [NM*DOMW-1:0] c_req_dom;
  logic [NM-1:0]      c_req_priv, c_req_write;
  logic [NM*AW-1:0]   c_req_addr;

  assign cit_req_valid = c_req_valid;
  assign cit_req_dom   = c_req_dom;
  assign cit_req_priv  = c_req_priv;
  assign cit_req_write = c_req_write;
  assign cit_req_addr  = c_req_addr;

  generate
    if (CITADEL_MODE == 1) begin : g_cit_ref
      sf_meridian_citadel_ref #(.NM(NM), .DOMW(DOMW), .AW(AW), .NENT(CIT_NENT), .LAT(CIT_LAT)) u_cit (
        .clk, .rst_n,
        .pol_we, .pol_idx, .pol_valid, .pol_src, .pol_dom, .pol_priv, .pol_base, .pol_mask, .pol_rd, .pol_wr,
        .cit_req_valid(c_req_valid), .cit_req_ready(c_req_ready),
        .cit_req_dom(c_req_dom), .cit_req_priv(c_req_priv), .cit_req_write(c_req_write), .cit_req_addr(c_req_addr),
        .cit_rsp_valid(c_rsp_valid), .cit_rsp_ok(c_rsp_ok), .cit_rsp_fault(c_rsp_fault),
        .tst_stall(tst_cit_stall));
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_ext = (^cit_req_ready) ^ (^cit_rsp_valid) ^ (^cit_rsp_ok) ^ (^cit_rsp_fault);
      /* verilator lint_on UNUSEDSIGNAL */
    end else if (CITADEL_MODE == 2) begin : g_cit_ext
      assign c_req_ready  = cit_req_ready;
      assign c_rsp_valid  = cit_rsp_valid;
      assign c_rsp_ok     = cit_rsp_ok;
      assign c_rsp_fault  = cit_rsp_fault;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_pol = pol_we ^ pol_valid ^ pol_priv ^ pol_rd ^ pol_wr ^ (^pol_idx) ^ (^pol_src) ^ (^pol_dom) ^
                        (^pol_base) ^ (^pol_mask) ^ (^tst_cit_stall);
      /* verilator lint_on UNUSEDSIGNAL */
    end else begin : g_cit_off
      assign c_req_ready = '1;
      assign c_rsp_valid = '0;
      assign c_rsp_ok    = '0;
      assign c_rsp_fault = '0;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_off = pol_we ^ pol_valid ^ pol_priv ^ pol_rd ^ pol_wr ^ (^pol_idx) ^ (^pol_src) ^ (^pol_dom) ^
                        (^pol_base) ^ (^pol_mask) ^ (^tst_cit_stall) ^ (^cit_req_ready) ^ (^cit_rsp_valid) ^
                        (^cit_rsp_ok) ^ (^cit_rsp_fault);
      /* verilator lint_on UNUSEDSIGNAL */
    end
  endgenerate

  // ------------------------------------------------------------ master ports
  logic [NM*NT-1:0]   xp_valid, xp_ready;
  logic [NM*RQW-1:0]  xp_word;
  logic [NM*NT-1:0]   mr_valid;
  logic [NM*NT*TAGW-1:0] mr_tag;
  logic [NM*NT*DOMW-1:0] mr_dom;
  logic [NM*NT*2-1:0] mr_op;
  logic [NM*NT*3-1:0] mr_status;
  logic [NM*NT*DW-1:0] mr_rdata;

  logic [NM-1:0]      p_acc, p_stall, p_dlv, p_dlv_wr;
  logic [NM*3-1:0]    p_dlv_status;
  logic [NM*BW-1:0]   p_dlv_bytes;
  logic [NM*LATW-1:0] p_dlv_lat;
  logic [NM*4-1:0]    p_viol;
  logic [NM*8-1:0]    p_orph, p_echo, p_late, p_pend;
  logic [NM-1:0]      lg_v;
  logic [NM*3-1:0]    lg_status;
  logic [NM*4-1:0]    lg_fault;
  logic [NM*AW-1:0]   lg_addr;
  logic [NM*DOMW-1:0] lg_dom;
  logic [NM*TAGW-1:0] lg_tag;
  logic [NM*TW-1:0]   lg_tgt;
  logic [NM-1:0]      lgt_v;
  logic [NM*DOMW-1:0] lgt_dom;
  logic [NM*TAGW-1:0] lgt_tag;
  logic [NM*TW-1:0]   lgt_tgt;

  generate
    for (genvar m = 0; m < NM; m++) begin : g_mp
      localparam int MAXO_M = int'(MST_MAXO[m*8 +: 8]);
      localparam int CWM    = sf_meridian_pkg::clog2c(MAXO_M + NT + 1);
      localparam int ST_M   = int'(MST_SLICE[m*4 +: 4]);

      // ---- master-side slice (request direction)
      logic              q_valid, q_ready;
      logic [RQW-1:0]    q_in, q_out;
      assign q_in = {m_req_op[m*2 +: 2], m_req_tag[m*TAGW +: TAGW], m_req_dom[m*DOMW +: DOMW], m_req_priv[m],
                     m_req_tc[m*3 +: 3], m_req_addr[m*AW +: AW], m_req_wdata[m*DW +: DW], m_req_wstrb[m*(DW/8) +: DW/8]};
      sf_meridian_slice #(.W(RQW), .STAGES(ST_M)) u_qs (
        .clk, .rst_n,
        .in_valid(m_req_valid[m]), .in_ready(m_req_ready[m]), .in_data(q_in),
        .out_valid(q_valid), .out_ready(q_ready), .out_data(q_out));

      // ---- port
      logic              rs_valid, rs_ready;
      logic [TAGW-1:0]   rs_tag;
      logic [DOMW-1:0]   rs_dom;
      logic [1:0]        rs_op;
      logic [2:0]        rs_status;
      logic [DW-1:0]     rs_rdata;
      logic [CWM-1:0]    o_pend_m, o_orph_m, o_echo_m, o_late_m;

      sf_meridian_mport #(
        .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW),
        .MAXO(MAXO_M), .OOO(int'(MST_OOO[m])), .TMO(TMO), .ISOLATE(ISOLATE), .LATW(LATW),
        .CITADEL_EN((CITADEL_MODE != 0) ? 1 : 0), .CHK_TMO(CHK_TMO),
        .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .CONN(CONN[m*NT +: NT]),
        .DOM_ALLOW(MST_DOM_ALLOW[m*NDOM +: NDOM])
      ) u_port (
        .clk, .rst_n,
        .rq_valid(q_valid), .rq_ready(q_ready),
        .rq_op(q_out[RQW-1 -: 2]), .rq_tag(q_out[RQW-3 -: TAGW]), .rq_dom(q_out[RQW-3-TAGW -: DOMW]),
        .rq_priv(q_out[RQW-3-TAGW-DOMW]), .rq_tc(q_out[DW/8 + DW + AW +: 3]), .rq_addr(q_out[DW/8 + DW +: AW]),
        .rq_wdata(q_out[DW/8 +: DW]), .rq_wstrb(q_out[0 +: DW/8]),
        .rs_valid, .rs_ready, .rs_tag, .rs_dom, .rs_op, .rs_status, .rs_rdata,
        .xp_valid(xp_valid[m*NT +: NT]), .xp_ready(xp_ready[m*NT +: NT]), .xp_word(xp_word[m*RQW +: RQW]),
        .tr_valid(mr_valid[m*NT +: NT]), .tr_tag(mr_tag[m*NT*TAGW +: NT*TAGW]), .tr_dom(mr_dom[m*NT*DOMW +: NT*DOMW]),
        .tr_op(mr_op[m*NT*2 +: NT*2]), .tr_status(mr_status[m*NT*3 +: NT*3]), .tr_rdata(mr_rdata[m*NT*DW +: NT*DW]),
        .cit_req_valid(c_req_valid[m]), .cit_req_ready(c_req_ready[m]), .cit_req_dom(c_req_dom[m*DOMW +: DOMW]),
        .cit_req_priv(c_req_priv[m]), .cit_req_write(c_req_write[m]), .cit_req_addr(c_req_addr[m*AW +: AW]),
        .cit_rsp_valid(c_rsp_valid[m]), .cit_rsp_ok(c_rsp_ok[m]), .cit_rsp_fault(c_rsp_fault[m*4 +: 4]),
        .iso_clear, .zomb_flush,
        .ev_acc(p_acc[m]), .ev_stall_in(p_stall[m]), .ev_dlv(p_dlv[m]), .ev_dlv_status(p_dlv_status[m*3 +: 3]),
        .ev_dlv_wr(p_dlv_wr[m]), .ev_dlv_bytes(p_dlv_bytes[m*BW +: BW]), .ev_dlv_lat(p_dlv_lat[m*LATW +: LATW]),
        .ev_viol(p_viol[m*4 +: 4]), .ev_orph_n(o_orph_m), .ev_echo_n(o_echo_m), .ev_late_n(o_late_m),
        .o_pend(o_pend_m), .o_iso(o_iso[m*NT +: NT]), .o_cit_orphan(o_cit_orphan[m]),
        .lg_valid(lg_v[m]), .lg_status(lg_status[m*3 +: 3]), .lg_fault(lg_fault[m*4 +: 4]),
        .lg_addr(lg_addr[m*AW +: AW]), .lg_dom(lg_dom[m*DOMW +: DOMW]), .lg_tag(lg_tag[m*TAGW +: TAGW]),
        .lg_tgt(lg_tgt[m*TW +: TW]),
        .lgt_valid(lgt_v[m]), .lgt_dom(lgt_dom[m*DOMW +: DOMW]), .lgt_tag(lgt_tag[m*TAGW +: TAGW]), .lgt_tgt(lgt_tgt[m*TW +: TW]));
      assign p_pend[m*8 +: 8] = 8'(o_pend_m);
      assign p_orph[m*8 +: 8] = 8'(o_orph_m);
      assign p_echo[m*8 +: 8] = 8'(o_echo_m);
      assign p_late[m*8 +: 8] = 8'(o_late_m);

      // ---- master-side slice (response direction)
      logic [MRW-1:0] r_in, r_out;
      assign r_in = {rs_tag, rs_dom, rs_op, rs_status, rs_rdata};
      sf_meridian_slice #(.W(MRW), .STAGES(ST_M)) u_rs (
        .clk, .rst_n,
        .in_valid(rs_valid), .in_ready(rs_ready), .in_data(r_in),
        .out_valid(m_rsp_valid[m]), .out_ready(m_rsp_ready[m]), .out_data(r_out));
      assign m_rsp_tag[m*TAGW +: TAGW]    = r_out[MRW-1 -: TAGW];
      assign m_rsp_dom[m*DOMW +: DOMW]    = r_out[MRW-TAGW-1 -: DOMW];
      assign m_rsp_op[m*2 +: 2]           = r_out[MRW-TAGW-DOMW-1 -: 2];
      assign m_rsp_status[m*3 +: 3]       = r_out[DW +: 3];
      assign m_rsp_rdata[m*DW +: DW]      = r_out[0 +: DW];
    end
  endgenerate

  // ------------------------------------------------------------ crossbar
  logic [NT*(sf_meridian_pkg::clog2c(NM + 1))-1:0] r_arb_stall;
  logic [NT*OW-1:0]   r_occ;
  logic [NT-1:0]      r_badsrc;

  sf_meridian_router #(
    .NM(NM), .NT(NT), .AW(AW), .DW(DW), .TAGW(TAGW), .DOMW(DOMW), .REQ_DEPTH(REQ_DEPTH),
    .ARB_MODE(ARB_MODE), .STARVE(STARVE), .CONN(CONN), .TGT_SLICE(TGT_SLICE)
  ) u_router (
    .clk, .rst_n,
    .xp_valid, .xp_ready, .xp_word,
    .t_req_valid, .t_req_ready, .t_req_src, .t_req_op, .t_req_tag, .t_req_dom, .t_req_priv, .t_req_tc,
    .t_req_addr, .t_req_wdata, .t_req_wstrb,
    .t_rsp_valid, .t_rsp_ready, .t_rsp_src, .t_rsp_tag, .t_rsp_dom, .t_rsp_op, .t_rsp_status, .t_rsp_rdata,
    .mr_valid, .mr_tag, .mr_dom, .mr_op, .mr_status, .mr_rdata,
    .ev_arb_stall(r_arb_stall), .ev_occ(r_occ), .ev_badsrc(r_badsrc));

  // ------------------------------------------------------------ error log
  // First fault is kept (sticky until elog_clear).  Priority inside a cycle: an error response created at acceptance (lg_*,
  // lowest master first) before a response timeout (lgt_*).  elog_count counts EVERY event of both channels.
  logic       any_lg, any_lgt;
  logic [SRCW-1:0] first_m, first_t;
  logic [CW-1:0]   n_lg;
  always_comb begin
    any_lg  = |lg_v;
    any_lgt = |lgt_v;
    first_m = '0;
    first_t = '0;
    for (int m = NM - 1; m >= 0; m--) begin
      if (lg_v[m])  first_m = SRCW'(m);
      if (lgt_v[m]) first_t = SRCW'(m);
    end
    n_lg = '0;
    for (int m = 0; m < NM; m++) n_lg = n_lg + CW'(lg_v[m]) + CW'(lgt_v[m]);
  end
  assign evt_err = any_lg || any_lgt;
  always_comb begin
    evt_sec = 1'b0;
    for (int m = 0; m < NM; m++) if (lg_v[m] && lg_status[m*3 +: 3] == sf_meridian_pkg::ST_DENIED) evt_sec = 1'b1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      elog_valid <= 1'b0; elog_src <= '0; elog_status <= '0; elog_fault <= '0; elog_addr <= '0;
      elog_dom <= '0; elog_tag <= '0; elog_tgt <= '0; elog_count <= '0;
    end else begin
      if (elog_clear) begin
        elog_valid <= 1'b0; elog_count <= '0;
      end else begin
        if (any_lg && !elog_valid) begin
          elog_valid  <= 1'b1;
          elog_src    <= first_m;
          elog_status <= lg_status[first_m*3 +: 3];
          elog_fault  <= lg_fault[first_m*4 +: 4];
          elog_addr   <= lg_addr[first_m*AW +: AW];
          elog_dom    <= lg_dom[first_m*DOMW +: DOMW];
          elog_tag    <= lg_tag[first_m*TAGW +: TAGW];
          elog_tgt    <= lg_tgt[first_m*TW +: TW];
        end else if (any_lgt && !elog_valid) begin
          elog_valid  <= 1'b1;
          elog_src    <= first_t;
          elog_status <= sf_meridian_pkg::ST_TIMEOUT;
          elog_fault  <= sf_meridian_pkg::F_RSPTMO;
          elog_addr   <= '0;
          elog_dom    <= lgt_dom[first_t*DOMW +: DOMW];
          elog_tag    <= lgt_tag[first_t*TAGW +: TAGW];
          elog_tgt    <= lgt_tgt[first_t*TW +: TW];
        end
        if (elog_count != '1) elog_count <= ((elog_count + n_lg) < elog_count) ? '1 : elog_count + n_lg;
      end
    end
  end

  // ------------------------------------------------------------ counters
  logic [NT-1:0]        tx;
  logic [NT*BW-1:0]     tx_bytes;
  always_comb begin
    for (int t = 0; t < NT; t++) begin
      tx[t] = t_req_valid[t] && t_req_ready[t];
      tx_bytes[t*BW +: BW] = (t_req_op[t*2 +: 2] == sf_meridian_pkg::OP_WRITE) ? BW'(sf_meridian_pkg::popc32(32'(t_req_wstrb[t*(DW/8) +: DW/8]))) : BW'(DW / 8);
    end
  end

  sf_meridian_perf #(.NM(NM), .NT(NT), .DW(DW), .LATW(LATW), .CW(CW), .OW(OW)) u_perf (
    .clk, .rst_n, .ctl_clear(perf_clear), .ctl_freeze(perf_freeze),
    .m_acc(p_acc), .m_stall_in(p_stall), .m_dlv(p_dlv), .m_dlv_status(p_dlv_status), .m_dlv_wr(p_dlv_wr),
    .m_dlv_bytes(p_dlv_bytes), .m_dlv_lat(p_dlv_lat), .m_viol(p_viol),
    .m_orph_n(p_orph), .m_echo_n(p_echo), .m_late_n(p_late), .m_pend(p_pend),
    .t_tx(tx), .t_tx_src(t_req_src), .t_tx_bytes(tx_bytes), .t_arb_stall(r_arb_stall), .t_occ(r_occ),
    .t_blocked(t_req_valid & ~t_req_ready), .t_badsrc(r_badsrc),
    .rd_sel(perf_sel), .rd_data(perf_data));
endmodule

`default_nettype wire
