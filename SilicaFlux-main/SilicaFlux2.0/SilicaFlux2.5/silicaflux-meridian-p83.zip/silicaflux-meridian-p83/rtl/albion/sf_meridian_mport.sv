// =============================================================================
// SilicaFlux Albion -- Project 83 -- Meridian :: sf_meridian_mport
//
// One MASTER PORT.  Everything that is decided per master happens here, BEFORE a request touches any shared
// resource (crosspoint buffer, arbiter, target):
//
//   1. protocol checks      reserved opcode, misaligned address, illegal tag reuse
//   2. domain binding       the presented protection domain must be bound to this port (DOM_ALLOW) -- a domain
//                           number is a label a master can lie about; the port, not the label, is trusted
//   3. address decode       sf_meridian_decoder: unmapped / no route
//   4. Citadel check        (dom, priv, read/write, addr, src = this port) -> permit / deny, fail closed
//   5. slot allocation      one slot per outstanding transaction (MAXO slots), identity = (tag, dom, op, target)
//   6. push                 a permitted request is pushed to the crosspoint buffer of its target
//   7. response collection  responses from the targets are matched to their slot (tag + target), echo-checked,
//                           stored in the slot (capacity is reserved by the outstanding limit => the response
//                           network never back-pressures a target), and delivered to the master
//
// Denied / undecodable / protocol-violating / timed-out requests are answered HERE with an error response carrying
// the master's own tag, domain and opcode.  They never reach a crosspoint buffer, an arbiter or a target.
//
// MAXO = 1 is the reference configuration (one outstanding request per master).  MAXO > 1:
//   OOO = 0 : responses are delivered to the master in request order (even when targets answer in another order:
//             a completed slot waits until every older slot has been delivered -- bounded by MAXO slots);
//   OOO = 1 : responses are delivered as they complete, tags preserved.
//   Both: a request whose tag is still outstanding (incl. a timed-out slot not yet reclaimed) is REJECTED:
//   consumed, V_TAGREUSE event, NO response (a response would be ambiguous with the first transaction's).
//
// Timeout (TMO > 0 cycles; 0 = off) and fault isolation (ISOLATE):
//   * a request that is permitted but cannot enter its crosspoint buffer for TMO cycles is answered ST_TIMEOUT (F_HOL)
//     and was never issued: a stalled target cannot hold this master's other traffic for longer than TMO;
//   * a transaction without response for TMO cycles is answered ST_TIMEOUT (F_RSPTMO); its slot becomes a ZOMBIE that
//     keeps tag and slot reserved until the late response arrives (it is swallowed, V_LATE) or zomb_flush; this
//     is what makes tag reuse after a timeout safe;
//   * Citadel failure (no verdict within CHK_TMO cycles): the request is DENIED (F_CITTMO, fail closed) and the port stays
//     fail-closed -- further requests are denied at once -- until a verdict arrives, or until PROBE = 8 x CHK_TMO cycles
//     have passed, when the next request is allowed to query again (it pays CHK_TMO if the Citadel is still dead).
//   * ISOLATE = 1: either event marks that target isolated for this port: new requests to it fail at once with
//     ST_TIMEOUT / F_ISO instead of queueing behind a dead endpoint; cleared by a late response from it or iso_clear.
// =============================================================================
`default_nettype none

module sf_meridian_mport #(
  parameter int               NT         = 2,
  parameter int               AW         = 32,
  parameter int               DW         = 64,
  parameter int               TAGW       = 4,
  parameter int               DOMW       = 3,
  parameter int               MAXO       = 1,
  parameter int               OOO        = 0,
  parameter int               TMO        = 0,
  parameter int               ISOLATE    = 1,
  parameter int               LATW       = 16,
  parameter int               CITADEL_EN = 1,
  parameter int               CHK_TMO    = 32,
  parameter logic [NT*AW-1:0] TGT_BASE   = {(NT*AW){1'b0}},
  parameter logic [NT*AW-1:0] TGT_MASK   = {(NT*AW){1'b0}},
  parameter logic [NT-1:0]    CONN       = {NT{1'b1}},
  parameter logic [(1<<DOMW)-1:0] DOM_ALLOW = {(1<<DOMW){1'b1}},
  localparam int              TW         = sf_meridian_pkg::clog2c(NT),
  localparam int              SIW        = sf_meridian_pkg::clog2c(MAXO),
  localparam int              SQW        = sf_meridian_pkg::clog2c(MAXO) + 1,
  localparam int              BW         = sf_meridian_pkg::clog2c(DW / 8 + 1),
  localparam int              CW         = sf_meridian_pkg::clog2c(MAXO + NT + 1),     // event counts reach MAXO or NT
  localparam int              RQW        = 2 + TAGW + DOMW + 1 + 3 + AW + DW + DW / 8
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,

  // ---- master request channel
  input  wire logic                 rq_valid,
  output logic                      rq_ready,
  input  wire logic [1:0]           rq_op,
  input  wire logic [TAGW-1:0]      rq_tag,
  input  wire logic [DOMW-1:0]      rq_dom,
  input  wire logic                 rq_priv,
  input  wire logic [2:0]           rq_tc,
  input  wire logic [AW-1:0]        rq_addr,
  input  wire logic [DW-1:0]        rq_wdata,
  input  wire logic [DW/8-1:0]      rq_wstrb,

  // ---- master response channel
  output logic                      rs_valid,
  input  wire logic                 rs_ready,
  output logic      [TAGW-1:0]      rs_tag,
  output logic      [DOMW-1:0]      rs_dom,
  output logic      [1:0]           rs_op,
  output logic      [2:0]           rs_status,
  output logic      [DW-1:0]        rs_rdata,

  // ---- push into the crosspoint buffers (one target per cycle)
  output logic      [NT-1:0]        xp_valid,
  input  wire logic [NT-1:0]        xp_ready,
  output logic      [RQW-1:0]       xp_word,

  // ---- responses steered to this master by the router (one per target; always accepted)
  input  wire logic [NT-1:0]        tr_valid,
  input  wire logic [NT*TAGW-1:0]   tr_tag,
  input  wire logic [NT*DOMW-1:0]   tr_dom,
  input  wire logic [NT*2-1:0]      tr_op,
  input  wire logic [NT*3-1:0]      tr_status,
  input  wire logic [NT*DW-1:0]     tr_rdata,

  // ---- Citadel check port
  output logic                      cit_req_valid,
  input  wire logic                 cit_req_ready,
  output logic      [DOMW-1:0]      cit_req_dom,
  output logic                      cit_req_priv,
  output logic                      cit_req_write,
  output logic      [AW-1:0]        cit_req_addr,
  input  wire logic                 cit_rsp_valid,
  input  wire logic                 cit_rsp_ok,
  input  wire logic [3:0]           cit_rsp_fault,

  // ---- management
  input  wire logic [NT-1:0]        iso_clear,
  input  wire logic                 zomb_flush,

  // ---- observability
  output logic                      ev_acc,          // request accepted into a slot (incl. local errors)
  output logic                      ev_stall_in,     // request presented and not accepted this cycle
  output logic                      ev_dlv,          // response delivered to the master
  output logic      [2:0]           ev_dlv_status,
  output logic                      ev_dlv_wr,
  output logic      [BW-1:0]        ev_dlv_bytes,
  output logic      [LATW-1:0]      ev_dlv_lat,      // cycles from acceptance to delivery
  output logic      [3:0]           ev_viol,         // {V_SPOOF, V_TAGREUSE, V_MISALIGN, V_BADOP} pulses
  output logic      [CW-1:0]        ev_orph_n,       // orphan responses consumed this cycle
  output logic      [CW-1:0]        ev_echo_n,       // echo mismatches this cycle
  output logic      [CW-1:0]        ev_late_n,       // late responses swallowed this cycle
  output logic      [CW-1:0]        o_pend,          // transactions accepted and not yet delivered
  output logic      [NT-1:0]        o_iso,           // targets currently isolated
  output logic                      o_cit_orphan,    // Citadel unresponsive: failing closed
  output logic                      lg_valid,        // an error response was created this cycle
  output logic      [2:0]           lg_status,
  output logic      [3:0]           lg_fault,
  output logic      [AW-1:0]        lg_addr,
  output logic      [DOMW-1:0]      lg_dom,
  output logic      [TAGW-1:0]      lg_tag,
  output logic      [TW-1:0]        lg_tgt,
  output logic                      lgt_valid,       // a response timeout happened this cycle (own channel: never lost behind lg_*)
  output logic      [DOMW-1:0]      lgt_dom,
  output logic      [TAGW-1:0]      lgt_tag,
  output logic      [TW-1:0]        lgt_tgt
);

  localparam logic [2:0] S_FREE = 3'd0, S_ISS = 3'd1, S_DONE = 3'd2, S_ZOMB = 3'd3;
  localparam logic [1:0] Q_IDLE = 2'd0, Q_WAIT = 2'd1, Q_DONE = 2'd2;
  localparam int         NDOM = 1 << DOMW;
  localparam int         PROBE = ((CHK_TMO * 8) < (1 << LATW) - 2) ? CHK_TMO * 8 : (1 << LATW) - 2;

  // ---------------------------------------------------------------- slot storage
  logic [MAXO*3-1:0]       s_st;
  logic [MAXO*TAGW-1:0]    s_tag;
  logic [MAXO*DOMW-1:0]    s_dom;
  logic [MAXO*2-1:0]       s_op;
  logic [MAXO*TW-1:0]      s_tgt;
  logic [MAXO*BW-1:0]      s_bytes;
  logic [MAXO*SQW-1:0]     s_seq;
  logic [MAXO*LATW-1:0]    s_age;
  logic [MAXO*3-1:0]       s_status;
  logic [MAXO*DW-1:0]      s_rdata;
  logic [MAXO-1:0]         s_zf;
  logic [SQW-1:0]          seq_q;

  logic [NT-1:0]           iso_q;
  logic [1:0]              q_st;
  logic                    q_ok_q;
  logic [3:0]              q_fault_q;
  logic [LATW-1:0]         q_cnt;
  logic                    cit_orphan_q;
  logic [LATW-1:0]         orphan_cnt;
  logic [LATW-1:0]         hol_cnt;
  logic                    hold_q;
  logic [SIW-1:0]          sel_q;
  logic [SIW-1:0]          dptr_q;

  // ---------------------------------------------------------------- request classification (combinational)
  logic          d_hit, d_reach, d_misal;
  logic [TW-1:0] d_tgt;
  sf_meridian_decoder #(.NT(NT), .AW(AW), .DW(DW), .CHECK_ALIGN(1),
                        .TGT_BASE(TGT_BASE), .TGT_MASK(TGT_MASK), .CONN(CONN)) u_dec (
    .addr(rq_addr), .hit(d_hit), .tgt(d_tgt), .reach(d_reach), .misaligned(d_misal));

  wire bad_op    = rq_op[1];
  wire dom_bound = DOM_ALLOW[rq_dom];
  wire iso_hit   = (ISOLATE != 0) && (TMO != 0) && d_reach && iso_q[d_tgt];
  wire pre_err   = bad_op || d_misal || !dom_bound || !d_hit || !d_reach || iso_hit;

  logic [2:0] pre_status;
  logic [3:0] pre_fault;
  always_comb begin
    pre_status = sf_meridian_pkg::ST_OKAY;
    pre_fault  = sf_meridian_pkg::F_NONE;
    if (bad_op)          begin pre_status = sf_meridian_pkg::ST_PROTO;   pre_fault = sf_meridian_pkg::F_BADOP;    end
    else if (d_misal)    begin pre_status = sf_meridian_pkg::ST_PROTO;   pre_fault = sf_meridian_pkg::F_MISALIGN; end
    else if (!dom_bound) begin pre_status = sf_meridian_pkg::ST_DENIED;  pre_fault = sf_meridian_pkg::F_SPOOF;    end
    else if (!d_hit)     begin pre_status = sf_meridian_pkg::ST_DECERR;  pre_fault = sf_meridian_pkg::F_UNMAPPED; end
    else if (!d_reach)   begin pre_status = sf_meridian_pkg::ST_DECERR;  pre_fault = sf_meridian_pkg::F_NOROUTE;  end
    else if (iso_hit)    begin pre_status = sf_meridian_pkg::ST_TIMEOUT; pre_fault = sf_meridian_pkg::F_ISO;      end
  end

  // ---------------------------------------------------------------- slot status (combinational)
  logic              slot_free, tag_busy;
  logic [SIW-1:0]    free_idx;
  logic [MAXO-1:0]   pend;                 // ISS or DONE: accepted, not yet delivered
  logic [CW-1:0]     pend_n;
  always_comb begin
    slot_free = 1'b0;
    free_idx  = '0;
    tag_busy  = 1'b0;
    pend_n    = '0;
    for (int i = MAXO - 1; i >= 0; i--) begin
      if (s_st[i*3 +: 3] == S_FREE) begin slot_free = 1'b1; free_idx = SIW'(i); end
    end
    for (int i = 0; i < MAXO; i++) begin
      if (s_st[i*3 +: 3] != S_FREE && s_tag[i*TAGW +: TAGW] == rq_tag) tag_busy = 1'b1;
      pend[i] = (s_st[i*3 +: 3] == S_ISS) || (s_st[i*3 +: 3] == S_DONE);
      if (pend[i]) pend_n = pend_n + CW'(1);
    end
  end

  // ---------------------------------------------------------------- Citadel verdict
  logic       vd_valid, vd_ok;
  logic [3:0] vd_fault;
  wire        need_q = (CITADEL_EN != 0) && rq_valid && slot_free && !tag_busy && !pre_err;
  assign cit_req_valid = need_q && (q_st == Q_IDLE) && !cit_orphan_q;
  assign cit_req_dom   = rq_dom;
  assign cit_req_priv  = rq_priv;
  assign cit_req_write = (rq_op == sf_meridian_pkg::OP_WRITE);
  assign cit_req_addr  = rq_addr;
  always_comb begin
    vd_valid = 1'b0; vd_ok = 1'b0; vd_fault = sf_meridian_pkg::F_NONE;
    if (CITADEL_EN == 0) begin
      vd_valid = 1'b1; vd_ok = 1'b1;
    end else if (cit_orphan_q) begin
      vd_valid = 1'b1; vd_ok = 1'b0; vd_fault = sf_meridian_pkg::F_CITTMO;            // fail closed, at once
    end else if (q_st == Q_DONE) begin
      vd_valid = 1'b1; vd_ok = q_ok_q; vd_fault = q_fault_q;
    end else if (q_st == Q_IDLE && cit_req_valid && cit_req_ready && cit_rsp_valid) begin
      vd_valid = 1'b1; vd_ok = cit_rsp_ok; vd_fault = cit_rsp_fault;  // verdict in the query cycle (LAT = 0)
    end else if (q_st == Q_WAIT && cit_rsp_valid) begin
      vd_valid = 1'b1; vd_ok = cit_rsp_ok; vd_fault = cit_rsp_fault;
    end
  end

  // ---------------------------------------------------------------- decision
  wire decide  = slot_free && !tag_busy && (pre_err || vd_valid);
  wire permit  = !pre_err && vd_ok;
  wire fwd     = decide && permit;
  wire blocked = fwd && !xp_ready[d_tgt];
  wire hol_exp = blocked && (TMO != 0) && (hol_cnt >= LATW'(TMO - 1));

  assign rq_ready = rq_valid && slot_free && (tag_busy || (decide && (!fwd || xp_ready[d_tgt] || hol_exp)));

  wire acc      = rq_valid && rq_ready;
  wire acc_drop = acc && tag_busy;                       // illegal tag reuse: consumed, no slot, no response
  wire acc_new  = acc && !tag_busy;
  wire acc_fwd  = acc_new && fwd && !hol_exp;
  wire acc_err  = acc_new && !acc_fwd;

  logic [2:0] err_status;
  logic [3:0] err_fault;
  always_comb begin
    if (pre_err)       begin err_status = pre_status; err_fault = pre_fault; end
    else if (hol_exp)  begin err_status = sf_meridian_pkg::ST_TIMEOUT; err_fault = sf_meridian_pkg::F_HOL;     end
    else               begin err_status = sf_meridian_pkg::ST_DENIED;  err_fault = vd_fault;  end
  end

  // push word: {op, tag, dom, priv, tc, addr, wdata, wstrb}
  assign xp_word = {rq_op, rq_tag, rq_dom, rq_priv, rq_tc, rq_addr, rq_wdata, rq_wstrb};
  always_comb begin
    xp_valid = '0;
    if (acc_fwd) xp_valid[d_tgt] = 1'b1;
  end

  wire [BW-1:0] req_bytes = (rq_op == sf_meridian_pkg::OP_WRITE) ? BW'(sf_meridian_pkg::popc32(32'(rq_wstrb))) : BW'(DW / 8);

  // ---------------------------------------------------------------- response matching
  logic [MAXO*NT-1:0] mhit;
  logic [NT-1:0]      t_hit_any;
  always_comb begin
    mhit      = '0;
    t_hit_any = '0;
    for (int i = 0; i < MAXO; i++)
      for (int t = 0; t < NT; t++)
        if (tr_valid[t] && (s_st[i*3 +: 3] == S_ISS || s_st[i*3 +: 3] == S_ZOMB) &&
            s_tgt[i*TW +: TW] == TW'(t) && s_tag[i*TAGW +: TAGW] == tr_tag[t*TAGW +: TAGW]) begin
          mhit[i*NT + t] = 1'b1;
          t_hit_any[t]   = 1'b1;
        end
  end

  // per-slot response view (target index selects the response lane)
  logic [MAXO-1:0]   r_hit;
  logic [MAXO-1:0]   r_echo_ok;
  logic [MAXO*3-1:0] r_status;
  logic [MAXO*DW-1:0] r_rdata;
  always_comb begin
    for (int i = 0; i < MAXO; i++) begin
      int tt;
      tt = int'(s_tgt[i*TW +: TW]);
      r_hit[i]  = |mhit[i*NT +: NT];
      r_echo_ok[i] = (tr_dom[tt*DOMW +: DOMW] == s_dom[i*DOMW +: DOMW]) &&
                     (tr_op[tt*2 +: 2] == s_op[i*2 +: 2]) &&
                     (tr_status[tt*3 +: 3] <= sf_meridian_pkg::ST_SLVERR);
      r_status[i*3 +: 3]   = r_echo_ok[i] ? tr_status[tt*3 +: 3] : sf_meridian_pkg::ST_PROTO;
      r_rdata[i*DW +: DW]  = (r_echo_ok[i] && tr_status[tt*3 +: 3] == sf_meridian_pkg::ST_OKAY && s_op[i*2 +: 2] == sf_meridian_pkg::OP_READ)
                             ? tr_rdata[tt*DW +: DW] : '0;
    end
  end

  // events from the response side
  always_comb begin
    ev_orph_n = '0; ev_echo_n = '0; ev_late_n = '0;
    for (int t = 0; t < NT; t++)
      if (tr_valid[t] && !t_hit_any[t]) ev_orph_n = ev_orph_n + CW'(1);
    for (int i = 0; i < MAXO; i++) begin
      if (r_hit[i] && s_st[i*3 +: 3] == S_ISS && !r_echo_ok[i]) ev_echo_n = ev_echo_n + CW'(1);
      if (r_hit[i] && s_st[i*3 +: 3] == S_ZOMB)                 ev_late_n = ev_late_n + CW'(1);
    end
  end

  // ---------------------------------------------------------------- in-order bookkeeping and delivery selection
  logic [MAXO-1:0] older_pend;       // some older pending slot exists
  logic [MAXO-1:0] elig;
  logic            any_elig;
  logic [SIW-1:0]  pick;
  logic [SIW-1:0]  sel;
  always_comb begin
    for (int i = 0; i < MAXO; i++) begin
      older_pend[i] = 1'b0;
      for (int j = 0; j < MAXO; j++) begin
        logic [SQW-1:0] dd;
        dd = s_seq[i*SQW +: SQW] - s_seq[j*SQW +: SQW];
        if (j != i && pend[j] && dd != '0 && !dd[SQW-1]) older_pend[i] = 1'b1;
      end
      elig[i] = (s_st[i*3 +: 3] == S_DONE) && ((OOO != 0) || !older_pend[i]);
    end
    any_elig = |elig;
    pick = '0;
    begin
      logic got;
      got = 1'b0;
      for (int i = MAXO - 1; i >= 0; i--) if (elig[i] && i >= int'(dptr_q)) begin pick = SIW'(i); got = 1'b1; end
      if (!got) for (int i = MAXO - 1; i >= 0; i--) if (elig[i]) pick = SIW'(i);
    end
    sel = hold_q ? sel_q : pick;
  end

  assign rs_valid  = hold_q || any_elig;
  assign rs_tag    = s_tag[sel*TAGW +: TAGW];
  assign rs_dom    = s_dom[sel*DOMW +: DOMW];
  assign rs_op     = s_op[sel*2 +: 2];
  assign rs_status = s_status[sel*3 +: 3];
  assign rs_rdata  = s_rdata[sel*DW +: DW];
  wire   dlv       = rs_valid && rs_ready;

  assign ev_acc        = acc_new;
  assign ev_stall_in   = rq_valid && !rq_ready;
  assign ev_dlv        = dlv;
  assign ev_dlv_status = rs_status;
  assign ev_dlv_wr     = (rs_op == sf_meridian_pkg::OP_WRITE);
  assign ev_dlv_bytes  = s_bytes[sel*BW +: BW];
  assign ev_dlv_lat    = s_age[sel*LATW +: LATW];
  assign ev_viol       = {acc_err && pre_err && pre_fault == sf_meridian_pkg::F_SPOOF,
                          acc_drop,
                          acc_err && pre_err && pre_fault == sf_meridian_pkg::F_MISALIGN,
                          acc_err && pre_err && pre_fault == sf_meridian_pkg::F_BADOP};
  assign o_pend        = pend_n;
  assign o_iso         = iso_q;
  assign o_cit_orphan  = cit_orphan_q;

  // slot-timeout detection (combinational view for the log and the isolation set)
  logic [MAXO-1:0] tmo_hit;
  always_comb begin
    for (int i = 0; i < MAXO; i++)
      tmo_hit[i] = (TMO != 0) && (s_st[i*3 +: 3] == S_ISS) && !r_hit[i] && (s_age[i*LATW +: LATW] >= LATW'(TMO));
  end
  logic              tmo_any;
  logic [SIW-1:0]    tmo_idx;
  always_comb begin
    tmo_any = |tmo_hit;
    tmo_idx = '0;
    for (int i = MAXO - 1; i >= 0; i--) if (tmo_hit[i]) tmo_idx = SIW'(i);
  end

  // error log pulses.  lg_*  : an error response was created at acceptance (decode, domain, Citadel, protocol, fast failure,
  //                             head-of-line timeout) -- security relevant, one per cycle at most;
  //                  lgt_* : an issued transaction timed out (F_RSPTMO) -- separate channel so the two can coincide
  //                          without either being lost (the lowest timed-out slot is reported; slots time out in distinct cycles
  //                          because acceptances are one per cycle).
  assign lg_valid  = acc_err;
  assign lg_status = err_status;
  assign lg_fault  = err_fault;
  assign lg_addr   = rq_addr;
  assign lg_dom    = rq_dom;
  assign lg_tag    = rq_tag;
  assign lg_tgt    = d_tgt;
  assign lgt_valid = tmo_any;
  assign lgt_dom   = s_dom[tmo_idx*DOMW +: DOMW];
  assign lgt_tag   = s_tag[tmo_idx*TAGW +: TAGW];
  assign lgt_tgt   = s_tgt[tmo_idx*TW +: TW];

  // ---------------------------------------------------------------- sequential state
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s_st <= '0; s_tag <= '0; s_dom <= '0; s_op <= '0; s_tgt <= '0; s_bytes <= '0; s_seq <= '0;
      s_age <= '0; s_status <= '0; s_rdata <= '0; s_zf <= '0; seq_q <= '0;
      iso_q <= '0; q_st <= Q_IDLE; q_ok_q <= 1'b0; q_fault_q <= sf_meridian_pkg::F_NONE; q_cnt <= '0; cit_orphan_q <= 1'b0; orphan_cnt <= '0;
      hol_cnt <= '0; hold_q <= 1'b0; sel_q <= '0; dptr_q <= '0;
    end else begin
      // ---- Citadel query state machine
      case (q_st)
        Q_IDLE: if (cit_req_valid && cit_req_ready) begin
          if (cit_rsp_valid) begin
            if (!acc) begin q_st <= Q_DONE; q_ok_q <= cit_rsp_ok; q_fault_q <= cit_rsp_fault; end
          end else begin
            q_st <= Q_WAIT; q_cnt <= '0;
          end
        end
        Q_WAIT: begin
          if (cit_rsp_valid) begin
            if (rq_valid && !acc) begin q_st <= Q_DONE; q_ok_q <= cit_rsp_ok; q_fault_q <= cit_rsp_fault; end
            else                  q_st <= Q_IDLE;
          end else if (q_cnt >= LATW'(CHK_TMO - 1)) begin
            q_st <= Q_IDLE; cit_orphan_q <= 1'b1; orphan_cnt <= '0;     // fail closed: the orphan state denies this request (F_CITTMO) and the next ones at once
          end else begin
            q_cnt <= q_cnt + LATW'(1);
          end
        end
        default: if (acc || !rq_valid) q_st <= Q_IDLE;                                      // Q_DONE
      endcase
      if (cit_orphan_q) begin
        if (cit_rsp_valid)                    cit_orphan_q <= 1'b0;                            // late verdict: Citadel alive
        else if (orphan_cnt >= LATW'(PROBE))  cit_orphan_q <= 1'b0;                            // probe: let the next request query
        else                                  orphan_cnt <= orphan_cnt + LATW'(1);
      end

      // ---- head-of-line watchdog
      if (rq_valid && blocked && !hol_exp) hol_cnt <= (hol_cnt == '1) ? hol_cnt : hol_cnt + LATW'(1);
      else                                 hol_cnt <= '0;

      // ---- isolation
      for (int t = 0; t < NT; t++) begin
        if (iso_clear[t]) iso_q[t] <= 1'b0;
        for (int i = 0; i < MAXO; i++)
          if (mhit[i*NT + t] && s_st[i*3 +: 3] == S_ZOMB) iso_q[t] <= 1'b0;                // late response: alive
      end
      if (ISOLATE != 0) begin
        if (hol_exp && acc_new) iso_q[d_tgt] <= 1'b1;
        for (int i = 0; i < MAXO; i++)
          if (tmo_hit[i]) iso_q[s_tgt[i*TW +: TW]] <= 1'b1;
      end

      // ---- delivery lock
      if (dlv) begin hold_q <= 1'b0; dptr_q <= (sel == SIW'(MAXO - 1)) ? '0 : sel + SIW'(1); end
      else if (rs_valid) begin hold_q <= 1'b1; sel_q <= sel; end

      // ---- slots
      for (int i = 0; i < MAXO; i++) begin
        if (s_st[i*3 +: 3] == S_ISS || s_st[i*3 +: 3] == S_DONE)
          if (s_age[i*LATW +: LATW] != '1) s_age[i*LATW +: LATW] <= s_age[i*LATW +: LATW] + LATW'(1);

        case (s_st[i*3 +: 3])
          S_ISS: begin
            if (r_hit[i]) begin
              s_st[i*3 +: 3]       <= S_DONE;
              s_status[i*3 +: 3]   <= r_status[i*3 +: 3];
              s_rdata[i*DW +: DW]  <= r_rdata[i*DW +: DW];
            end else if (tmo_hit[i]) begin
              s_st[i*3 +: 3]       <= S_DONE;
              s_status[i*3 +: 3]   <= sf_meridian_pkg::ST_TIMEOUT;
              s_rdata[i*DW +: DW]  <= '0;
              s_zf[i]              <= 1'b1;
            end
          end
          S_DONE: begin
            if (dlv && sel == SIW'(i)) begin
              s_st[i*3 +: 3] <= s_zf[i] ? S_ZOMB : S_FREE;
              s_zf[i]        <= 1'b0;
            end
          end
          S_ZOMB: begin
            if (r_hit[i] || zomb_flush) s_st[i*3 +: 3] <= S_FREE;                            // late response swallowed
          end
          default: ;
        endcase

        if (acc_new && free_idx == SIW'(i)) begin
          s_st[i*3 +: 3]      <= acc_fwd ? S_ISS : S_DONE;
          s_tag[i*TAGW +: TAGW] <= rq_tag;
          s_dom[i*DOMW +: DOMW] <= rq_dom;
          s_op[i*2 +: 2]      <= rq_op;
          s_tgt[i*TW +: TW]   <= d_tgt;
          s_bytes[i*BW +: BW] <= acc_fwd ? req_bytes : '0;
          s_seq[i*SQW +: SQW] <= seq_q;
          s_age[i*LATW +: LATW] <= LATW'(1);                                          // age == cycles since acceptance
          s_status[i*3 +: 3]  <= acc_fwd ? sf_meridian_pkg::ST_OKAY : err_status;
          s_rdata[i*DW +: DW] <= '0;
          s_zf[i]             <= 1'b0;
        end
      end
      if (acc_new) seq_q <= seq_q + SQW'(1);
    end
  end

`ifdef FORMAL
  // invariants (the formal harness proves them as part of the routing-safety jobs)
  always_comb if (rst_n) begin
    assert (pend_n <= CW'(MAXO));
    assert (!(acc_fwd && acc_err));
    assert (!(acc_fwd && !permit));                         // nothing is pushed without a permit
    assert (!(acc_fwd && pre_err));                         // ... nor with a local error
    assert ((xp_valid & ~(NT'(1) << d_tgt)) == '0);         // pushes go only to the decoded target
    assert (!(xp_valid != '0) || (xp_valid == (NT'(1) << d_tgt)));
  end
`endif
endmodule

`default_nettype wire
