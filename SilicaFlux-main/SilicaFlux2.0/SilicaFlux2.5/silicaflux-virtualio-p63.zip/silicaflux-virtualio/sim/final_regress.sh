#!/usr/bin/env bash
# Final verification run from clean sources; logs go to reports/.
set -uo pipefail
cd "$(dirname "$0")/.."
REF=refmodel/target/release/sfv-refcheck
make lint > reports/lint.log 2>&1; echo "lint rc=$?" > reports/final_summary.txt
(cd refmodel && cargo test --release --offline) > reports/refmodel_unit.log 2>&1; echo "refmodel unit rc=$?" >> reports/final_summary.txt
make hostlib > reports/hostlib.log 2>&1; echo "hostlib (gcc -std=c99 -Wall -Wextra -Werror) rc=$?" >> reports/final_summary.txt
rm -rf build/sim_default build/sim_small
make sim > reports/sim_build.log 2>&1; echo "sim build rc=$?" >> reports/final_summary.txt
mkdir -p build/regress build/regress_small
build/sim_default/tests --outdir build/regress --refcheck $REF > reports/directed_default.log 2>&1; echo "directed default rc=$?" >> reports/final_summary.txt
build/sim_small/tests --outdir build/regress_small --refcheck $REF > reports/directed_small.log 2>&1; echo "directed small rc=$?" >> reports/final_summary.txt
build/sim_default/tests --outdir build/regress --refcheck $REF --only random --seed 1 --iters 1000 > reports/regress_random_default.log 2>&1; echo "random default (1000 seeds) rc=$?" >> reports/final_summary.txt
build/sim_small/tests --outdir build/regress_small --refcheck $REF --only random --seed 5000 --iters 400 > reports/regress_random_small.log 2>&1; echo "random small (400 seeds) rc=$?" >> reports/final_summary.txt
echo FINAL_DONE >> reports/final_summary.txt
