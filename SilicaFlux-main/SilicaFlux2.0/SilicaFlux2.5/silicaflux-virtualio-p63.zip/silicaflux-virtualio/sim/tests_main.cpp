// tests_main.cpp — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Co-simulation test suite for silicaflux_virtio_engine.
// Every test drives the RTL through the C host library (the simulated VM
// driver) and/or raw guest-memory writes, checks expectations inline, checks
// the independent DMA-permission monitor, and — unless marked NOCHECK —
// replays its op-log through the Rust reference model (sfv-refcheck), which
// must predict guest memory, storage, status and counters byte-for-byte.
#include <algorithm>
#include <chrono>
#include <cstdio>
#include <cstring>
#include <functional>
#include <stdexcept>
#include <string>
#include <vector>

#include "sim_env.h"
#include "verilated.h"

// ---------------------------------------------------------------------------
// options / framework
// ---------------------------------------------------------------------------
struct Opt {
  std::string outdir = "build/regress";
  std::string refcheck;
  std::string only;
  uint64_t seed = 1;
  int iters = 0;
  bool skip_long = false;
  std::string perf_out;
} O;

struct TestFail : std::runtime_error {
  using std::runtime_error::runtime_error;
};
#define REQUIRE(c, ...)                                                                          \
  do {                                                                                           \
    if (!(c)) {                                                                                  \
      char _b[512];                                                                              \
      snprintf(_b, sizeof _b, __VA_ARGS__);                                                      \
      throw TestFail(std::string("REQUIRE(" #c ") failed: ") + _b + " [line " +                 \
                     std::to_string(__LINE__) + "]");                                            \
    }                                                                                            \
  } while (0)

static Env::Cfg cfg(const std::string &name, int ndev = 1, uint64_t seed = 1) {
  Env::Cfg c;
  c.ndev = ndev;
  c.seed = seed;
  c.memsize = 1u << 20;
  c.outdir = O.outdir;
  c.name = name;
  return c;
}

static const uint64_t RBASE[2] = {0x10000, 0x70000};
static const uint64_t RSIZE = 0x50000;
static const uint64_t UNMAPPED = 0xc0000;   // inside physical memory, outside every tenant window
static const uint64_t REQUIRED = SFV_FEAT(VIRTIO_F_VERSION_1) | SFV_FEAT(VIRTIO_F_ACCESS_PLATFORM);
static const uint64_t WANTED_ALL = REQUIRED | SFV_FEAT(VIRTIO_BLK_F_SEG_MAX) | SFV_FEAT(VIRTIO_BLK_F_FLUSH);

static void hv_setup(Env &e, int d, uint16_t dom) {
  e.set_region(d, RBASE[d], RSIZE);
  sfv_hv_bind_domain(e.mg(d), dom);
  sfv_hv_set_window(e.mg(d), 0, dom, RBASE[d], RBASE[d] + RSIZE - 1, 1, 1);
}

static void done(Env &e) {
  REQUIRE(e.monitor_errors() == 0, "DMA permission monitor: %d escapes, first: %s", e.monitor_errors(),
          e.monitor_first().c_str());
  int rc = e.finish(O.refcheck);
  REQUIRE(rc == 0, "reference model mismatch (see sfv-refcheck output above)");
}

// open (or re-open after a reset) a blk device through the host library
static void open_blk(Env &e, int d, sfv_blk_t &b, uint16_t q, uint64_t wanted = WANTED_ALL) {
  if (b.vq.next) sfv_blk_close(&b);
  e.set_region(d, RBASE[d], RSIZE);
  if (wanted == WANTED_ALL) {
    int r = sfv_blk_open(&b, e.tr(d), q);
    REQUIRE(r == 0, "sfv_blk_open: %s", sfv_strerror(r));
    return;
  }
  memset(&b, 0, sizeof b);
  REQUIRE(sfv_dev_probe(&b.dev, e.tr(d)) == 0, "probe");
  REQUIRE(sfv_dev_reset(&b.dev) == 0, "reset");
  int r = sfv_dev_negotiate(&b.dev, wanted, REQUIRED);
  REQUIRE(r == 0, "negotiate: %s", sfv_strerror(r));
  b.has_flush = (b.dev.drv_features & SFV_FEAT(VIRTIO_BLK_F_FLUSH)) != 0;
  b.capacity = e.capacity;
  REQUIRE(sfv_vq_setup(&b.dev, &b.vq, 0, q) == 0, "vq setup");
  REQUIRE(e.dma_alloc(d, 32u * q, 8, &b.pool_iova) == 0, "pool");
  REQUIRE(sfv_dev_driver_ok(&b.dev) == 0, "driver ok");
}

static uint64_t balloc(Env &e, int d, size_t n, size_t align = 8) {
  uint64_t a;
  REQUIRE(e.dma_alloc(d, n ? n : 1, align, &a) == 0, "tenant DMA region exhausted (%zu bytes)", n);
  return a;
}

// ---------------------------------------------------------------------------
// request builder with arbitrary descriptor layouts (message framing, 2.6.4)
// ---------------------------------------------------------------------------
struct Req {
  std::vector<sfv_sg_t> sg;
  uint64_t status_addr = 0, data_addr = 0;
  uint32_t wlen = 0, dlen = 0, type = 0;
  uint64_t sector = 0;
  uint16_t head = 0;
  int exp = -1;        // expected status, -1 = don't care
  uint8_t status = 0xff;
  std::vector<uint8_t> out;   // OUT payload
};
struct Layout {
  int hdr_pieces = 1;
  int data_pieces = 1;
  bool merge_status = false;
  int misalign = 0;
  uint32_t hdr_len = 16;      // < 16 => short header
};

static std::vector<uint32_t> split(std::mt19937_64 &r, uint32_t total, int k) {
  std::vector<uint32_t> out;
  if (total == 0) return out;
  k = std::max(1, std::min<int>(k, (int)std::min<uint32_t>(total, 64)));
  std::vector<uint32_t> cuts;
  while ((int)cuts.size() < k - 1) {
    uint32_t c = 1 + (uint32_t)(r() % (total - 1));
    if (std::find(cuts.begin(), cuts.end(), c) == cuts.end()) cuts.push_back(c);
  }
  std::sort(cuts.begin(), cuts.end());
  uint32_t prev = 0;
  for (uint32_t c : cuts) { out.push_back(c - prev); prev = c; }
  out.push_back(total - prev);
  return out;
}

static bool data_writable(uint32_t type) { return type == VIRTIO_BLK_T_IN || type == VIRTIO_BLK_T_GET_ID; }

static Req make_req(Env &e, int d, std::mt19937_64 &r, uint32_t type, uint64_t sector, uint32_t dlen,
                    const Layout &L, uint64_t data_override = 0) {
  Req q;
  q.type = type;
  q.sector = sector;
  q.dlen = dlen;
  bool dw = data_writable(type);
  uint64_t h = balloc(e, d, 16 + L.misalign, 8) + L.misalign;
  uint8_t hdr[16] = {0};
  for (int i = 0; i < 4; i++) hdr[i] = (uint8_t)(type >> (8 * i));
  for (int i = 0; i < 8; i++) hdr[8 + i] = (uint8_t)(sector >> (8 * i));
  e.mem_wr(h, hdr, 16);
  uint32_t off = 0;
  for (uint32_t p : split(r, L.hdr_len, L.hdr_pieces)) { q.sg.push_back({h + off, p, 0}); off += p; }
  bool merge = L.merge_status && dw && dlen > 0;
  uint64_t da = data_override;
  if (!da && dlen) {
    da = balloc(e, d, dlen + 1 + L.misalign, 8) + L.misalign;
    if (dw) {
      std::vector<uint8_t> f(dlen, 0xcc);
      e.mem_wr(da, f.data(), dlen);
    } else {
      q.out.resize(dlen);
      for (auto &x : q.out) x = (uint8_t)r();
      e.mem_wr(da, q.out.data(), dlen);
    }
  }
  q.data_addr = da;
  auto pcs = split(r, dlen, L.data_pieces);
  off = 0;
  for (size_t i = 0; i < pcs.size(); i++) {
    uint32_t len = pcs[i] + ((merge && i + 1 == pcs.size()) ? 1 : 0);
    q.sg.push_back({da + off, len, (uint8_t)dw});
    if (dw) q.wlen += len;
    off += pcs[i];
  }
  if (merge) {
    q.status_addr = da + dlen;
  } else {
    q.status_addr = balloc(e, d, 1, 1);
    q.sg.push_back({q.status_addr, 1, 1});
    q.wlen += 1;
  }
  uint8_t sent = 0xa5;
  e.mem_wr(q.status_addr, &sent, 1);
  return q;
}

static void submit(sfv_blk_t &b, Req &q) {
  int r = sfv_vq_add(&b.vq, q.sg.data(), (unsigned)q.sg.size(), nullptr, &q.head);
  REQUIRE(r == 0, "sfv_vq_add: %s", sfv_strerror(r));
}

// wait for qs to complete, in submission order, with correct used length/status
static void drain(Env &e, int d, sfv_blk_t &b, std::vector<Req> &qs, uint64_t budget = 20000000) {
  size_t got = 0;
  uint64_t t0 = e.cycle();
  while (got < qs.size()) {
    uint16_t h;
    uint32_t len;
    void *ck;
    int r = sfv_vq_get_used(&b.vq, &h, &len, &ck);
    REQUIRE(r >= 0, "used ring protocol violation");
    if (r == 1) {
      Req &q = qs[got];
      REQUIRE(h == q.head, "completion order: got head %u expected %u (#%zu)", h, q.head, got);
      REQUIRE(len == q.wlen, "used len %u expected %u (head %u)", len, q.wlen, h);
      e.mem_rd(q.status_addr, &q.status, 1);
      if (q.exp >= 0)
        REQUIRE(q.status == q.exp, "status %u expected %d (type %u sector %llu dlen %u)", q.status, q.exp,
                q.type, (unsigned long long)q.sector, q.dlen);
      got++;
      continue;
    }
    if (e.irq(d)) {
      uint32_t s = sfv_dev_ack_interrupt(&b.dev);
      REQUIRE(!(s & VIRTIO_MMIO_INT_CONFIG), "unexpected config-change interrupt (fatal %s)",
              sfv_fatal_cause_name(sfv_hv_fatal_cause(e.mg(d))));
    } else {
      e.tick(16);
    }
    REQUIRE(e.cycle() - t0 < budget, "drain timeout (%zu/%zu)", got, qs.size());
  }
}

static uint8_t run1(Env &e, int d, sfv_blk_t &b, Req q) {
  std::vector<Req> v{q};
  submit(b, v[0]);
  sfv_vq_kick(&b.vq);
  drain(e, d, b, v);
  return v[0].status;
}

static void expect_fatal(Env &e, int d, sfv_blk_t &b, int cause) {
  uint64_t t0 = e.cycle();
  while (!(sfv_dev_status(&b.dev) & VIRTIO_STATUS_DEVICE_NEEDS_RESET)) {
    e.tick(16);
    REQUIRE(e.cycle() - t0 < 500000, "expected fatal %s did not occur", sfv_fatal_cause_name(cause));
  }
  uint8_t c = sfv_hv_fatal_cause(e.mg(d));
  REQUIRE(c == cause, "fatal cause %s, expected %s", sfv_fatal_cause_name(c), sfv_fatal_cause_name(cause));
  REQUIRE(e.irq(d), "config-change interrupt not raised");
  REQUIRE(sfv_dev_ack_interrupt(&b.dev) & VIRTIO_MMIO_INT_CONFIG, "INT_CONFIG bit not set");
}

static void raw_desc(Env &e, sfv_vq_t &vq, uint16_t i, uint64_t addr, uint32_t len, uint16_t flags, uint16_t next) {
  uint8_t b[16];
  for (int k = 0; k < 8; k++) b[k] = (uint8_t)(addr >> (8 * k));
  for (int k = 0; k < 4; k++) b[8 + k] = (uint8_t)(len >> (8 * k));
  b[12] = (uint8_t)flags; b[13] = (uint8_t)(flags >> 8);
  b[14] = (uint8_t)next;  b[15] = (uint8_t)(next >> 8);
  e.mem_wr(vq.desc_iova + 16ull * i, b, 16);
}
static void raw_publish(Env &e, sfv_vq_t &vq, uint16_t head) {
  uint8_t b[2] = {(uint8_t)head, (uint8_t)(head >> 8)};
  e.mem_wr(vq.avail_iova + 4 + 2ull * (vq.avail_idx & (vq.size - 1)), b, 2);
  vq.avail_idx++;
  uint8_t c[2] = {(uint8_t)vq.avail_idx, (uint8_t)(vq.avail_idx >> 8)};
  e.mem_wr(vq.avail_iova + 2, c, 2);
  sfv_vq_kick(&vq);
}

static Req good_flush(Env &e, int d, std::mt19937_64 &r) {
  Req q = make_req(e, d, r, VIRTIO_BLK_T_FLUSH, 0, 0, Layout{});
  q.exp = VIRTIO_BLK_S_OK;
  return q;
}

// recover after a fatal: reset + full re-init, then prove the device works
static void recover(Env &e, int d, sfv_blk_t &b, uint16_t q, std::mt19937_64 &r) {
  open_blk(e, d, b, q);
  REQUIRE(!(sfv_dev_status(&b.dev) & VIRTIO_STATUS_DEVICE_NEEDS_RESET), "NEEDS_RESET survived reset");
  REQUIRE(run1(e, d, b, good_flush(e, d, r)) == VIRTIO_BLK_S_OK, "post-recovery flush");
}

// ===========================================================================
// 1. initialisation, feature negotiation, versioned register interfaces
// ===========================================================================
static void t_init_negotiation() {
  Env e(cfg("init_negotiation"));
  hv_setup(e, 0, 1);
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_MAGIC_VALUE) == VIRTIO_MMIO_MAGIC, "magic");
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_VERSION) == 2, "version");
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_DEVICE_ID) == VIRTIO_ID_BLOCK, "device id");
  e.mmio_wr(0, VIRTIO_MMIO_DEVICE_FEATURES_SEL, 0);
  uint64_t f = e.mmio_rd(0, VIRTIO_MMIO_DEVICE_FEATURES);
  e.mmio_wr(0, VIRTIO_MMIO_DEVICE_FEATURES_SEL, 1);
  f |= (uint64_t)e.mmio_rd(0, VIRTIO_MMIO_DEVICE_FEATURES) << 32;
  e.mmio_wr(0, VIRTIO_MMIO_DEVICE_FEATURES_SEL, 2);
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_DEVICE_FEATURES) == 0, "feature word 2 must be 0");
  REQUIRE(f == WANTED_ALL, "offered features %llx", (unsigned long long)f);
  REQUIRE(!(f & SFV_FEAT(VIRTIO_F_RING_PACKED)) && !(f & SFV_FEAT(VIRTIO_F_INDIRECT_DESC)) &&
              !(f & SFV_FEAT(VIRTIO_F_EVENT_IDX)) && !(f & SFV_FEAT(VIRTIO_BLK_F_MQ)),
          "unimplemented feature offered");
  e.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_QUEUE_NUM_MAX) == e.max_qsz, "QueueNumMax");
  e.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 1);
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_QUEUE_NUM_MAX) == 0, "queue 1 must not exist");
  e.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_CONFIG_GENERATION) == 0, "config generation");
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_SHM_LEN_LOW) == 0xffffffffu, "no shared memory regions");
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_CONFIG + 0) == (uint32_t)e.capacity, "capacity");
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_CONFIG + 0xc) == e.max_chain - 2, "seg_max");

  auto neg = [&](uint64_t drv) {
    e.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
    e.mmio_wr(0, VIRTIO_MMIO_STATUS, 1);
    e.mmio_wr(0, VIRTIO_MMIO_STATUS, 3);
    e.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 0);
    e.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, (uint32_t)drv);
    e.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 1);
    e.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, (uint32_t)(drv >> 32));
    e.mmio_wr(0, VIRTIO_MMIO_STATUS, 3 | VIRTIO_STATUS_FEATURES_OK);
    return (e.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_FEATURES_OK) != 0;
  };
  REQUIRE(!neg(WANTED_ALL | SFV_FEAT(VIRTIO_F_RING_PACKED)), "accepted un-offered RING_PACKED");
  REQUIRE(!neg(WANTED_ALL | SFV_FEAT(VIRTIO_F_INDIRECT_DESC)), "accepted un-offered INDIRECT_DESC");
  REQUIRE(!neg(SFV_FEAT(VIRTIO_F_VERSION_1)), "accepted driver without ACCESS_PLATFORM");
  REQUIRE(!neg(SFV_FEAT(VIRTIO_F_ACCESS_PLATFORM)), "accepted legacy (no VERSION_1) driver");
  REQUIRE(neg(REQUIRED), "refused minimal valid feature set");
  // driver cannot clear bits or set NEEDS_RESET
  e.mmio_wr(0, VIRTIO_MMIO_STATUS, VIRTIO_STATUS_DRIVER | VIRTIO_STATUS_DEVICE_NEEDS_RESET);
  uint32_t st = e.mmio_rd(0, VIRTIO_MMIO_STATUS);
  REQUIRE((st & 0x4b) == 0x0b, "status bits after illegal write: %x", st);
  // feature writes after FEATURES_OK are ignored
  e.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES_SEL, 0);
  e.mmio_wr(0, VIRTIO_MMIO_DRIVER_FEATURES, 0xffffffffu);

  // management window: identity, version, capabilities
  uint32_t ver, caps0;
  REQUIRE(sfv_hv_probe(e.mg(0), &ver, &caps0) == 0, "hv probe");
  REQUIRE(ver == 0x00010000, "engine version %x", ver);
  REQUIRE((caps0 & 0xff) == 1 && ((caps0 >> 24) & 1) && !((caps0 >> 25) & 1) && !((caps0 >> 26) & 1) &&
              !((caps0 >> 27) & 1) && !((caps0 >> 28) & 1) && ((caps0 >> 29) & 1),
          "caps0 %x", caps0);

  sfv_blk_t b{};
  std::mt19937_64 r(11);
  open_blk(e, 0, b, 16);
  REQUIRE(b.dev.drv_features == WANTED_ALL, "library negotiated %llx", (unsigned long long)b.dev.drv_features);
  char id[21];
  REQUIRE(sfv_blk_get_id_sync(&b, id) == 0 && !strcmp(id, "SILICAFLUX-VBLK-0001"), "GET_ID '%s'", id);
  done(e);
}

// ===========================================================================
// 2. single descriptor
// ===========================================================================
static void t_single_descriptor() {
  Env e(cfg("single_descriptor"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(2);
  open_blk(e, 0, b, 8);
  // a chain of ONE device-writable descriptor: no header -> IOERR, whole
  // writable stream written, used.len == 1
  uint64_t s = balloc(e, 0, 1, 1);
  Req q;
  q.sg.push_back({s, 1, 1});
  q.status_addr = s;
  q.wlen = 1;
  q.exp = VIRTIO_BLK_S_IOERR;
  run1(e, 0, b, q);
  // one 600-byte writable descriptor: zero-filled, status in the final byte
  uint64_t w = balloc(e, 0, 600, 8);
  std::vector<uint8_t> fill(600, 0xcc);
  e.mem_wr(w, fill.data(), 600);
  Req q2;
  q2.sg.push_back({w, 600, 1});
  q2.status_addr = w + 599;
  q2.wlen = 600;
  q2.exp = VIRTIO_BLK_S_IOERR;
  run1(e, 0, b, q2);
  std::vector<uint8_t> got(600);
  e.mem_rd(w, got.data(), 600);
  for (int i = 0; i < 599; i++) REQUIRE(got[i] == 0, "byte %d not zero-filled", i);
  // minimal valid request: header + status (FLUSH)
  run1(e, 0, b, good_flush(e, 0, r));
  done(e);
}

// ===========================================================================
// 3. chained descriptors and arbitrary message framing
// ===========================================================================
static void t_chained() {
  Env e(cfg("chained"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(3);
  open_blk(e, 0, b, 64);
  int segmax = (int)e.max_chain - 2;
  for (int it = 0; it < 24; it++) {
    Layout L;
    L.hdr_pieces = 1 + it % 3;
    L.data_pieces = 1 + (it * 5) % segmax;
    if (L.hdr_pieces + L.data_pieces + 1 > (int)e.max_chain) L.data_pieces = (int)e.max_chain - 1 - L.hdr_pieces;
    L.misalign = it % 4 == 3 ? (int)(r() % 8) : 0;
    uint32_t n = 1 + it % 8;
    uint64_t sec = (it * 37) % (e.capacity - 8);
    Req w = make_req(e, 0, r, VIRTIO_BLK_T_OUT, sec, n * 512, L);
    w.exp = 0;
    run1(e, 0, b, w);
    L.merge_status = it % 2;
    Req rd = make_req(e, 0, r, VIRTIO_BLK_T_IN, sec, n * 512, L);
    rd.exp = 0;
    run1(e, 0, b, rd);
    std::vector<uint8_t> got(n * 512);
    e.mem_rd(rd.data_addr, got.data(), got.size());
    REQUIRE(got == w.out, "read-back mismatch it=%d (hdr %d pcs, data %d pcs, merged %d)", it, L.hdr_pieces,
            L.data_pieces, (int)L.merge_status);
  }
  // maximum: header in 1, seg_max data segments, status
  Layout L;
  L.data_pieces = segmax;
  Req w = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 3, 16 * 512, L);
  w.exp = 0;
  run1(e, 0, b, w);
  done(e);
}

// ===========================================================================
// 4. ring wraparound (slot wrap and 16-bit index wrap)
// ===========================================================================
static void t_ring_wrap_slots() {
  Env e(cfg("ring_wrap_slots"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(4);
  open_blk(e, 0, b, 4);
  uint64_t mark = e.dev(0).alloc_ptr;
  for (int i = 0; i < 40; i++) {
    e.dev(0).alloc_ptr = mark;
    Req w = make_req(e, 0, r, VIRTIO_BLK_T_OUT, i, 512, Layout{});
    w.exp = 0;
    run1(e, 0, b, w);
    Req rd = make_req(e, 0, r, VIRTIO_BLK_T_IN, i, 512, Layout{});
    rd.exp = 0;
    run1(e, 0, b, rd);
    std::vector<uint8_t> got(512);
    e.mem_rd(rd.data_addr, got.data(), 512);
    REQUIRE(got == w.out, "mismatch at %d", i);
  }
  REQUIRE(sfv_vq_device_used_idx(&b.vq) == 80, "used idx %u", sfv_vq_device_used_idx(&b.vq));
  done(e);
}

static void t_ring_wrap_idx16() {
  Env e(cfg("ring_wrap_idx16"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  uint16_t q = (uint16_t)std::min<uint32_t>(256, e.max_qsz);
  open_blk(e, 0, b, q);
  const uint32_t total = 65536 + 3 * q;
  uint32_t sent = 0, got = 0;
  std::vector<uint16_t> heads;
  while (got < total) {
    heads.clear();
    while (sent < total && b.vq.num_free >= 2) {
      uint16_t h;
      REQUIRE(sfv_blk_submit(&b, VIRTIO_BLK_T_FLUSH, 0, nullptr, 0, nullptr, &h) == 0, "submit");
      heads.push_back(h);
      sent++;
    }
    sfv_vq_kick(&b.vq);
    size_t k = 0;
    while (k < heads.size()) {
      sfv_blk_completion_t c;
      int rr = sfv_blk_poll(&b, &c);
      REQUIRE(rr >= 0, "poll");
      if (rr == 0) { e.tick(64); continue; }
      REQUIRE(c.head == heads[k] && c.status == 0 && c.used_len == 1, "completion %u", got);
      k++;
      got++;
    }
    if (e.irq(0)) sfv_dev_ack_interrupt(&b.dev);
  }
  REQUIRE(sfv_vq_device_used_idx(&b.vq) == (uint16_t)total, "used idx %u expected %u",
          sfv_vq_device_used_idx(&b.vq), (uint16_t)total);
  REQUIRE(sfv_hv_perf32(e.mg(0), SFV_PERF_REQ) == total, "req counter");
  printf("      %u requests, used.idx wrapped through 0 -> %u, %llu cycles\n", total, (unsigned)(uint16_t)total,
         (unsigned long long)e.cycle());
  done(e);
}

// ===========================================================================
// 5. queue full / empty / exhaustion / index jump
// ===========================================================================
static void t_queue_full_empty() {
  Env e(cfg("queue_full_empty"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(5);
  open_blk(e, 0, b, 8);
  // empty: a notification with nothing available is a no-op
  sfv_vq_kick(&b.vq);
  e.wait_idle(0);
  REQUIRE(sfv_hv_perf32(e.mg(0), SFV_PERF_REQ) == 0, "processed from an empty ring");
  REQUIRE(sfv_dev_check(&b.dev) == 0, "empty notify caused NEEDS_RESET");
  // full: all 8 avail entries outstanding at once (avail.idx - last == QueueSize)
  std::vector<Req> qs;
  for (int i = 0; i < 8; i++) {
    uint64_t s = balloc(e, 0, 1, 1);
    Req q;
    q.sg.push_back({s, 1, 1});
    q.status_addr = s;
    q.wlen = 1;
    q.exp = VIRTIO_BLK_S_IOERR;
    qs.push_back(q);
    submit(b, qs.back());
  }
  REQUIRE(b.vq.num_free == 0, "ring not full");
  uint16_t h;
  sfv_sg_t one = {balloc(e, 0, 1, 1), 1, 1};
  REQUIRE(sfv_vq_add(&b.vq, &one, 1, nullptr, &h) == SFV_E_NOSPC, "library must report NOSPC");
  sfv_vq_kick(&b.vq);
  drain(e, 0, b, qs);
  REQUIRE(sfv_hv_perf32(e.mg(0), SFV_PERF_QD_MAX) == 8, "queue depth max %u", sfv_hv_perf32(e.mg(0), SFV_PERF_QD_MAX));
  // repeat full twice more to cross the slot boundary while full
  for (int rep = 0; rep < 2; rep++) {
    qs.clear();
    for (int i = 0; i < 4; i++) { qs.push_back(good_flush(e, 0, r)); submit(b, qs.back()); }
    sfv_vq_kick(&b.vq);
    drain(e, 0, b, qs);
  }
  // avail.idx jumping more than QueueSize ahead is fatal
  e.wait_idle(0);
  uint16_t bogus = (uint16_t)(b.vq.avail_idx + 9);
  uint8_t c[2] = {(uint8_t)bogus, (uint8_t)(bogus >> 8)};
  e.mem_wr(b.vq.avail_iova + 2, c, 2);
  sfv_vq_kick(&b.vq);
  expect_fatal(e, 0, b, SFV_FC_AVAIL_IDX_JUMP);
  recover(e, 0, b, 8, r);
  done(e);
}

// ===========================================================================
// 6. invalid descriptor flags
// ===========================================================================
static void t_invalid_flags() {
  Env e(cfg("invalid_flags"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(6);
  const uint16_t bad[] = {VIRTQ_DESC_F_INDIRECT, VIRTQ_DESC_F_INDIRECT | VIRTQ_DESC_F_NEXT, 0x8, 0x8000,
                          VIRTQ_DESC_F_WRITE | 0x10};
  for (uint16_t f : bad) {
    open_blk(e, 0, b, 8);
    uint64_t t = balloc(e, 0, 64, 16);
    raw_desc(e, b.vq, 0, t, 16, f, 1);
    raw_desc(e, b.vq, 1, t + 32, 1, VIRTQ_DESC_F_WRITE, 0);
    raw_publish(e, b.vq, 0);
    expect_fatal(e, 0, b, SFV_FC_DESC_FLAGS);
  }
  recover(e, 0, b, 8, r);
  done(e);
}

// ===========================================================================
// 7. invalid lengths and request-level errors
// ===========================================================================
static void t_invalid_lengths() {
  Env e(cfg("invalid_lengths"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(7);
  open_blk(e, 0, b, 16);
  const uint64_t cap = e.capacity;
  struct Case { uint32_t type; uint64_t sector; uint32_t dlen; uint8_t exp; Layout L; };
  Layout shorth;
  shorth.hdr_len = 10;
  std::vector<Case> cases = {
      {VIRTIO_BLK_T_IN, 0, 100, VIRTIO_BLK_S_IOERR, {}},          // not a multiple of 512
      {VIRTIO_BLK_T_OUT, 0, 513, VIRTIO_BLK_S_IOERR, {}},
      {VIRTIO_BLK_T_OUT, 4, 0, VIRTIO_BLK_S_OK, {}},              // zero-length write is valid
      {VIRTIO_BLK_T_IN, 4, 0, VIRTIO_BLK_S_OK, {}},
      {VIRTIO_BLK_T_IN, 0, 512, VIRTIO_BLK_S_IOERR, shorth},      // header shorter than 16 bytes
      {VIRTIO_BLK_T_IN, cap, 512, VIRTIO_BLK_S_IOERR, {}},        // first sector past the end
      {VIRTIO_BLK_T_IN, cap - 1, 1024, VIRTIO_BLK_S_IOERR, {}},   // runs past the end
      {VIRTIO_BLK_T_OUT, cap - 1, 512, VIRTIO_BLK_S_OK, {}},      // last sector
      {VIRTIO_BLK_T_IN, cap, 0, VIRTIO_BLK_S_OK, {}},             // zero sectors at the end
      {VIRTIO_BLK_T_IN, 1ull << 63, 512, VIRTIO_BLK_S_IOERR, {}}, // overflow-safe range check
      {VIRTIO_BLK_T_IN, ~0ull, 512, VIRTIO_BLK_S_IOERR, {}},
      {VIRTIO_BLK_T_GET_ID, 0, 8, VIRTIO_BLK_S_OK, {}},           // truncated ID
      {VIRTIO_BLK_T_GET_ID, 0, 32, VIRTIO_BLK_S_OK, {}},          // ID + zero padding
      {VIRTIO_BLK_T_DISCARD, 0, 0, VIRTIO_BLK_S_UNSUPP, {}},
      {VIRTIO_BLK_T_WRITE_ZEROES, 0, 0, VIRTIO_BLK_S_UNSUPP, {}},
      {99, 0, 512, VIRTIO_BLK_S_UNSUPP, {}},
      {0xffffffffu, 0, 0, VIRTIO_BLK_S_UNSUPP, {}},
  };
  for (auto &c : cases) {
    Req q = make_req(e, 0, r, c.type, c.sector, c.dlen, c.L);
    q.exp = c.exp;
    run1(e, 0, b, q);
    if (data_writable(c.type) && c.dlen) {
      std::vector<uint8_t> got(c.dlen);
      e.mem_rd(q.data_addr, got.data(), c.dlen);
      if (c.exp != 0)
        for (uint32_t i = 0; i < c.dlen; i++) REQUIRE(got[i] == 0, "error completion not zero-filled");
      if (c.type == VIRTIO_BLK_T_GET_ID) {
        const char *id = "SILICAFLUX-VBLK-0001";
        for (uint32_t i = 0; i < c.dlen; i++) REQUIRE(got[i] == (i < 20 ? (uint8_t)id[i] : 0), "GET_ID byte %u", i);
      }
    }
  }
  // total chain length >= 2^32 is a malformed chain
  uint64_t t = balloc(e, 0, 64, 16);
  sfv_sg_t sg[3] = {{t, 16, 0}, {t + 16, 0xfffffff0u, 0}, {t + 40, 1, 1}};
  REQUIRE(sfv_vq_add(&b.vq, sg, 3, nullptr, nullptr) == 0, "add");
  sfv_vq_kick(&b.vq);
  expect_fatal(e, 0, b, SFV_FC_CHAIN_LEN_OVF);
  recover(e, 0, b, 16, r);
  done(e);
}

// ===========================================================================
// 8. malformed chains
// ===========================================================================
static void t_malformed_chains() {
  Env e(cfg("malformed_chains"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(8);
  const uint16_t Q = 32;
  auto fresh = [&]() { open_blk(e, 0, b, Q); return balloc(e, 0, 256, 16); };
  uint64_t t;
  // next index out of range
  t = fresh();
  raw_desc(e, b.vq, 0, t, 16, VIRTQ_DESC_F_NEXT, Q);
  raw_publish(e, b.vq, 0);
  expect_fatal(e, 0, b, SFV_FC_DESC_IDX_OOR);
  // head out of range
  t = fresh();
  raw_publish(e, b.vq, Q + 3);
  expect_fatal(e, 0, b, SFV_FC_DESC_IDX_OOR);
  // self loop
  t = fresh();
  raw_desc(e, b.vq, 5, t, 16, VIRTQ_DESC_F_NEXT, 5);
  raw_publish(e, b.vq, 5);
  expect_fatal(e, 0, b, SFV_FC_CHAIN_LOOP);
  // 3-cycle
  t = fresh();
  raw_desc(e, b.vq, 0, t, 16, VIRTQ_DESC_F_NEXT, 1);
  raw_desc(e, b.vq, 1, t, 16, VIRTQ_DESC_F_NEXT, 2);
  raw_desc(e, b.vq, 2, t, 16, VIRTQ_DESC_F_NEXT, 0);
  raw_publish(e, b.vq, 0);
  expect_fatal(e, 0, b, SFV_FC_CHAIN_LOOP);
  // longer than MAX_CHAIN (no loop)
  t = fresh();
  {
    std::vector<sfv_sg_t> sg;
    sg.push_back({t, 16, 0});
    for (uint32_t i = 0; i < e.max_chain - 1; i++) sg.push_back({t + 16, 8, 0});
    sg.push_back({t + 64, 1, 1});
    REQUIRE(sfv_vq_add(&b.vq, sg.data(), (unsigned)sg.size(), nullptr, nullptr) == 0, "add");
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_CHAIN_TOO_LONG);
  }
  // device-readable after device-writable (2.7.4.2)
  t = fresh();
  {
    sfv_sg_t sg[3] = {{t, 16, 0}, {t + 32, 1, 1}, {t + 64, 512, 0}};
    REQUIRE(sfv_vq_add(&b.vq, sg, 3, nullptr, nullptr) == 0, "add");
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_CHAIN_ORDER);
  }
  // no device-writable byte for the status
  t = fresh();
  {
    sfv_sg_t sg[2] = {{t, 16, 0}, {t + 32, 512, 0}};
    REQUIRE(sfv_vq_add(&b.vq, sg, 2, nullptr, nullptr) == 0, "add");
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_NO_STATUS);
  }
  // zero-length descriptors are legal and contribute nothing
  open_blk(e, 0, b, Q);
  {
    Req w = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 9, 512, Layout{});
    Req q;
    q.sg = {w.sg[0], {w.data_addr, 0, 0}, w.sg[1], {w.status_addr, 0, 1}, w.sg[2]};
    q.status_addr = w.status_addr;
    q.wlen = 1;
    q.exp = VIRTIO_BLK_S_OK;
    run1(e, 0, b, q);
    REQUIRE(!memcmp(&e.dev(0).stor[9 * 512], w.out.data(), 512), "zero-length descs corrupted payload");
  }
  recover(e, 0, b, Q, r);
  done(e);
}

// ===========================================================================
// 9. DMA permission enforcement (tenant isolation, single engine)
// ===========================================================================
static void t_dma_permission() {
  Env e(cfg("dma_permission"));
  const uint16_t DOM = 5;
  hv_setup(e, 0, DOM);
  sfv_blk_t b{};
  std::mt19937_64 r(9);
  open_blk(e, 0, b, 16);
  auto stor_snapshot = e.dev(0).stor;

  // (a) readable payload outside the tenant -> IOERR, nothing read or stored
  {
    Req q = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 20, 512, Layout{}, UNMAPPED);
    q.exp = VIRTIO_BLK_S_IOERR;
    uint32_t v0 = sfv_hv_perf32(e.mg(0), SFV_PERF_VIOL);
    run1(e, 0, b, q);
    REQUIRE(sfv_hv_perf32(e.mg(0), SFV_PERF_VIOL) == v0 + 1, "violation not counted");
    REQUIRE(e.mgmt_rd(0, SFV_MGMT_FAULT_LO) == (uint32_t)UNMAPPED, "fault address");
    REQUIRE(!memcmp(&e.dev(0).stor[20 * 512], &stor_snapshot[20 * 512], 512), "storage modified");
  }
  // (b) another domain's window over the buffer does not help (tag mismatch)
  {
    e.wait_idle(0);
    sfv_hv_set_window(e.mg(0), 1, DOM + 1, UNMAPPED, UNMAPPED + 0xffff, 1, 1);
    Req q = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 21, 512, Layout{}, UNMAPPED);
    q.exp = VIRTIO_BLK_S_IOERR;
    run1(e, 0, b, q);
    sfv_hv_clear_window(e.mg(0), 1);
  }
  // (c) a buffer straddling two adjacent windows is denied (single-window rule)
  {
    e.wait_idle(0);
    uint64_t mid = RBASE[0] + 0x30000;
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], mid - 1, 1, 1);
    sfv_hv_set_window(e.mg(0), 1, DOM, mid, RBASE[0] + RSIZE - 1, 1, 1);
    Req q = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 22, 512, Layout{}, mid - 256);
    q.exp = VIRTIO_BLK_S_IOERR;
    run1(e, 0, b, q);
    Req ok = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 22, 512, Layout{}, mid);
    ok.exp = VIRTIO_BLK_S_OK;
    run1(e, 0, b, ok);
    e.wait_idle(0);
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], RBASE[0] + RSIZE - 1, 1, 1);
    sfv_hv_clear_window(e.mg(0), 1);
  }
  // (d) domain binding is locked while the queue is enabled
  {
    e.mgmt_wr_noshadow(0, SFV_MGMT_Q0_DOMAIN, 0x80000000u | 9);
    REQUIRE((e.mgmt_rd(0, SFV_MGMT_Q0_DOMAIN) & 0xffff) == DOM, "binding changed while live");
    REQUIRE(e.mgmt_rd(0, SFV_MGMT_ENGINE_STATUS) & 8, "lock violation flag not set");
    e.mgmt_wr(0, SFV_MGMT_PERF_CTRL, 2);
    REQUIRE(!(e.mgmt_rd(0, SFV_MGMT_ENGINE_STATUS) & 8), "flag not cleared");
    run1(e, 0, b, good_flush(e, 0, r));   // still tagged with DOM (monitor)
  }
  // (e) writable payload outside the tenant -> fatal, memory untouched
  {
    uint8_t before[512], after[512];
    e.mem_rd(UNMAPPED, before, 512);
    Req q = make_req(e, 0, r, VIRTIO_BLK_T_IN, 0, 512, Layout{}, UNMAPPED);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_WRITABLE_PERM);
    e.mem_rd(UNMAPPED, after, 512);
    REQUIRE(!memcmp(before, after, 512), "foreign memory written");
  }
  // (f) used ring write-protected -> fatal on the used-ring update
  {
    open_blk(e, 0, b, 16);
    e.wait_idle(0);
    uint64_t u0 = b.vq.used_iova, u1 = u0 + 6 + 8 * 16 - 1;
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], u0 - 1, 1, 1);
    sfv_hv_set_window(e.mg(0), 1, DOM, u0, u1, 1, 0);
    sfv_hv_set_window(e.mg(0), 2, DOM, u1 + 1, RBASE[0] + RSIZE - 1, 1, 1);
    Req q = good_flush(e, 0, r);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_RING_DMA);
    uint8_t st;
    e.mem_rd(q.status_addr, &st, 1);
    REQUIRE(st == 0, "request executed before the used write failed");
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], RBASE[0] + RSIZE - 1, 1, 1);
    sfv_hv_clear_window(e.mg(0), 1);
    sfv_hv_clear_window(e.mg(0), 2);
  }
  // (g) descriptor table outside the tenant -> fatal on descriptor fetch
  {
    open_blk(e, 0, b, 16);
    e.wait_idle(0);
    uint64_t d0 = b.vq.desc_iova;
    sfv_hv_set_window(e.mg(0), 0, DOM, d0 + 16 * 16, RBASE[0] + RSIZE - 1, 1, 1);  // excludes desc table
    sfv_hv_set_window(e.mg(0), 1, DOM, RBASE[0], d0 - 1, 1, 1);
    Req q = good_flush(e, 0, r);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_RING_DMA);
    REQUIRE(e.mgmt_rd(0, SFV_MGMT_FAULT_LO) == (uint32_t)(d0 + 16 * q.head), "fault address %x",
            e.mgmt_rd(0, SFV_MGMT_FAULT_LO));
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], RBASE[0] + RSIZE - 1, 1, 1);
    sfv_hv_clear_window(e.mg(0), 1);
  }
  // (h) all windows revoked -> the very first ring access is denied
  {
    open_blk(e, 0, b, 16);
    e.wait_idle(0);
    sfv_hv_clear_window(e.mg(0), 0);
    Req q = good_flush(e, 0, r);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_RING_DMA);
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], RBASE[0] + RSIZE - 1, 1, 1);
  }
  // (i) no protected domain bound -> refuse to process at all
  {
    sfv_dev_reset(&b.dev);
    sfv_hv_unbind_domain(e.mg(0));
    open_blk(e, 0, b, 16);
    Req q = good_flush(e, 0, r);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_NO_DOMAIN);
    sfv_dev_reset(&b.dev);
    sfv_hv_bind_domain(e.mg(0), DOM);
  }
  recover(e, 0, b, 16, r);
  done(e);
}

// ===========================================================================
// 9b. exact permission-window boundaries (inclusive base/limit, both paths)
// ===========================================================================
static void t_window_boundaries() {
  Env e(cfg("window_boundaries"));
  const uint16_t DOM = 3;
  hv_setup(e, 0, DOM);
  sfv_blk_t b{};
  std::mt19937_64 r(31);
  open_blk(e, 0, b, 8);
  // an isolated window with byte-granular, non-aligned bounds outside the tenant region
  const uint64_t X = UNMAPPED + 0x1003, Y = UNMAPPED + 0x3005;   // inclusive
  e.wait_idle(0);
  sfv_hv_set_window(e.mg(0), 1, DOM, X, Y, 1, 1);
  struct C { uint64_t addr; uint32_t type; int exp; } cs[] = {
      {X, VIRTIO_BLK_T_OUT, VIRTIO_BLK_S_OK},             // first byte == base
      {Y - 511, VIRTIO_BLK_T_OUT, VIRTIO_BLK_S_OK},       // last byte == limit
      {X - 1, VIRTIO_BLK_T_OUT, VIRTIO_BLK_S_IOERR},      // one byte below base
      {Y - 510, VIRTIO_BLK_T_OUT, VIRTIO_BLK_S_IOERR},    // one byte above limit
      {X, VIRTIO_BLK_T_IN, VIRTIO_BLK_S_OK},
      {Y - 511, VIRTIO_BLK_T_IN, VIRTIO_BLK_S_OK},
  };
  for (auto &c : cs) {
    Req q = make_req(e, 0, r, c.type, 40, 512, Layout{}, c.addr);
    q.exp = c.exp;
    run1(e, 0, b, q);
  }
  { // writable payload one byte past the limit -> fatal
    Req q = make_req(e, 0, r, VIRTIO_BLK_T_IN, 40, 512, Layout{}, Y - 510);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_WRITABLE_PERM);
  }
  { // writable payload one byte below the base -> fatal
    open_blk(e, 0, b, 8);
    Req q = make_req(e, 0, r, VIRTIO_BLK_T_IN, 40, 512, Layout{}, X - 1);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    expect_fatal(e, 0, b, SFV_FC_WRITABLE_PERM);
  }
  // per-beat DMA gate: a window that ends one byte inside avail.idx must deny
  // the 2-byte idx read; ending on its last byte must allow it
  for (int pass = 0; pass < 2; pass++) {
    open_blk(e, 0, b, 8);
    e.wait_idle(0);
    uint64_t a = b.vq.avail_iova;
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], a + 2 + pass, 1, 1);
    sfv_hv_set_window(e.mg(0), 2, DOM, a + 4, RBASE[0] + RSIZE - 1, 1, 1);
    Req q = good_flush(e, 0, r);
    if (pass == 0) {
      submit(b, q);
      sfv_vq_kick(&b.vq);
      expect_fatal(e, 0, b, SFV_FC_RING_DMA);
      REQUIRE(e.mgmt_rd(0, SFV_MGMT_FAULT_LO) == (uint32_t)(a + 2), "gate fault address");
    } else {
      run1(e, 0, b, q);
    }
    e.wait_idle(0);
    sfv_hv_set_window(e.mg(0), 0, DOM, RBASE[0], RBASE[0] + RSIZE - 1, 1, 1);
    sfv_hv_clear_window(e.mg(0), 2);
  }
  sfv_hv_clear_window(e.mg(0), 1);
  recover(e, 0, b, 8, r);
  done(e);
}

// ===========================================================================
// 10. reset (mid-flight abort, queue disable, after fatal)
// ===========================================================================
static void t_reset_midflight() {
  Env e(cfg("reset_midflight"));
  e.log_nocheck("abort point is timing dependent");
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(10);
  for (int round = 0; round < 6; round++) {
    open_blk(e, 0, b, 16);
    e.dev(0).k = Knobs{50, 2, 9, 30, 1, 6};
    Layout L;
    L.data_pieces = 6;
    Req q = make_req(e, 0, r, round % 2 ? VIRTIO_BLK_T_IN : VIRTIO_BLK_T_OUT, 0, 64 * 512, L);
    submit(b, q);
    sfv_vq_kick(&b.vq);
    e.tick(500 + 700 * round);
    if (round < 3) {
      sfv_dev_reset(&b.dev);   // Status <- 0 is held off until the engine has drained
      REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_STATUS) == 0, "status after reset");
      REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY) == 0, "queue ready after reset");
      REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS) == 0, "interrupt status after reset");
    } else {
      e.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
      e.mmio_wr(0, VIRTIO_MMIO_QUEUE_READY, 0);   // queue disable, also quiesced
      REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY) == 0, "queue still ready");
    }
    REQUIRE(!e.engine_busy(0), "engine busy after quiesce");
    uint64_t beats = e.dev(0).dma_beats, ops = e.dev(0).sc_ops;
    e.tick(5000);
    REQUIRE(e.dev(0).dma_beats == beats && e.dev(0).sc_ops == ops, "DMA/storage activity after reset");
    e.dev(0).k = Knobs{};
    sfv_dev_reset(&b.dev);
    recover(e, 0, b, 16, r);
  }
  done(e);
}

static void t_reset_after_fatal() {
  Env e(cfg("reset_after_fatal"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(12);
  for (int i = 0; i < 3; i++) {
    open_blk(e, 0, b, 8);
    raw_publish(e, b.vq, 100);
    expect_fatal(e, 0, b, SFV_FC_DESC_IDX_OOR);
    REQUIRE(sfv_dev_status(&b.dev) & VIRTIO_STATUS_DEVICE_NEEDS_RESET, "NEEDS_RESET");
    // the halted queue ignores further notifications
    sfv_vq_kick(&b.vq);
    e.wait_idle(0);
    sfv_dev_reset(&b.dev);
    REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_STATUS) == 0, "status not cleared by reset");
    recover(e, 0, b, 8, r);
  }
  done(e);
}

// ===========================================================================
// 11. backpressure
// ===========================================================================
static void t_backpressure() {
  Env e(cfg("backpressure"));
  hv_setup(e, 0, 1);
  e.dev(0).k = Knobs{70, 1, 12, 70, 1, 20};
  sfv_blk_t b{};
  std::mt19937_64 r(13);
  open_blk(e, 0, b, 32);
  uint64_t mark = e.dev(0).alloc_ptr;
  for (int round = 0; round < 8; round++) {
    e.dev(0).alloc_ptr = mark;
    std::vector<Req> qs;
    for (int i = 0; i < 5; i++) {
      Layout L;
      L.data_pieces = 1 + (int)(r() % 4);
      L.misalign = (int)(r() % 8);
      Req q = make_req(e, 0, r, VIRTIO_BLK_T_OUT, round * 40 + i * 8, (1 + i) * 512, L);
      q.exp = 0;
      qs.push_back(q);
      submit(b, qs.back());
    }
    sfv_vq_kick(&b.vq);
    drain(e, 0, b, qs);
    std::vector<Req> rs;
    for (int i = 0; i < 5; i++) {
      Layout L;
      L.merge_status = r() & 1;
      L.data_pieces = 1 + (int)(r() % 4);
      Req q = make_req(e, 0, r, VIRTIO_BLK_T_IN, round * 40 + i * 8, (1 + i) * 512, L);
      q.exp = 0;
      rs.push_back(q);
      submit(b, rs.back());
    }
    sfv_vq_kick(&b.vq);
    drain(e, 0, b, rs);
    for (int i = 0; i < 5; i++) {
      std::vector<uint8_t> got(rs[i].dlen);
      e.mem_rd(rs[i].data_addr, got.data(), got.size());
      REQUIRE(got == qs[i].out, "data mismatch under backpressure round %d req %d", round, i);
    }
  }
  REQUIRE(sfv_hv_perf32(e.mg(0), SFV_PERF_STALL) > 0, "no stalls recorded under backpressure");
  done(e);
}

// ===========================================================================
// 12. completion ordering
// ===========================================================================
static void t_completion_ordering() {
  Env e(cfg("completion_ordering"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(14);
  open_blk(e, 0, b, 64);
  std::vector<Req> qs;
  for (int i = 0; i < 20; i++) {
    uint32_t types[] = {VIRTIO_BLK_T_OUT, VIRTIO_BLK_T_IN, VIRTIO_BLK_T_FLUSH, VIRTIO_BLK_T_GET_ID, 77};
    uint32_t t = types[i % 5];
    uint32_t dlen = t == VIRTIO_BLK_T_FLUSH || t == 77 ? 0 : (t == VIRTIO_BLK_T_GET_ID ? 20 : (20 - i) * 512);
    Req q = make_req(e, 0, r, t, (i * 32) % (e.capacity - 32), dlen, Layout{});
    q.exp = t == 77 ? VIRTIO_BLK_S_UNSUPP : 0;
    qs.push_back(q);
    submit(b, qs.back());
  }
  sfv_vq_kick(&b.vq);
  drain(e, 0, b, qs);   // asserts used-ring order == avail order
  done(e);
}

// ===========================================================================
// 13. multiple tenant domains (two engines, shared host memory)
// ===========================================================================
static void t_multi_tenant() {
  Env e(cfg("multi_tenant", 2));
  hv_setup(e, 0, 1);
  hv_setup(e, 1, 2);
  e.dev(0).k = Knobs{20, 1, 4, 10, 1, 3};
  e.dev(1).k = Knobs{30, 1, 6, 20, 1, 5};
  sfv_blk_t A{}, B{};
  std::mt19937_64 r(15);
  open_blk(e, 0, A, 32);
  open_blk(e, 1, B, 32);
  for (int round = 0; round < 4; round++) {
    std::vector<Req> qa, qb;
    for (int i = 0; i < 6; i++) {
      Req a = make_req(e, 0, r, VIRTIO_BLK_T_OUT, round * 50 + i, 1024, Layout{});
      a.exp = 0;
      qa.push_back(a);
      submit(A, qa.back());
      Req bb = make_req(e, 1, r, VIRTIO_BLK_T_OUT, round * 50 + i, 1536, Layout{});
      bb.exp = 0;
      qb.push_back(bb);
      submit(B, qb.back());
    }
    sfv_vq_kick(&A.vq);
    sfv_vq_kick(&B.vq);
    drain(e, 0, A, qa);
    drain(e, 1, B, qb);
  }
  auto b_stor = e.dev(1).stor;
  std::vector<uint8_t> b_mem(RSIZE), b_mem2(RSIZE);
  e.wait_all_idle();
  e.mem_rd(RBASE[1], b_mem.data(), RSIZE);
  // attack 1: tenant A reads tenant B's memory as an OUT payload -> IOERR
  {
    Req a = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 7, 512, Layout{}, RBASE[1] + 0x40000);
    a.exp = VIRTIO_BLK_S_IOERR;
    run1(e, 0, A, a);
  }
  // attack 2: A's table even holds a window over B's memory tagged with B's domain
  {
    e.wait_idle(0);
    sfv_hv_set_window(e.mg(0), 1, 2, RBASE[1], RBASE[1] + RSIZE - 1, 1, 1);
    Req a = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 8, 512, Layout{}, RBASE[1] + 0x41000);
    a.exp = VIRTIO_BLK_S_IOERR;
    run1(e, 0, A, a);
  }
  // attack 3: A tries to DMA-write into B's memory -> fatal on A only
  {
    Req a = make_req(e, 0, r, VIRTIO_BLK_T_IN, 0, 4096, Layout{}, RBASE[1] + 0x42000);
    submit(A, a);
    sfv_vq_kick(&A.vq);
    // B keeps working while A is being attacked
    std::vector<Req> qb;
    for (int i = 0; i < 4; i++) {
      Req bb = make_req(e, 1, r, VIRTIO_BLK_T_IN, i, 512, Layout{});
      bb.exp = 0;
      qb.push_back(bb);
      submit(B, qb.back());
    }
    sfv_vq_kick(&B.vq);
    expect_fatal(e, 0, A, SFV_FC_WRITABLE_PERM);
    drain(e, 1, B, qb);
    REQUIRE(sfv_dev_check(&B.dev) == 0, "tenant B affected by tenant A fault");
  }
  e.wait_all_idle();
  e.mem_rd(RBASE[1], b_mem2.data(), RSIZE);
  // the attacked ranges lie in a part of B's region that B itself never uses
  REQUIRE(e.dev(1).alloc_ptr < RBASE[1] + 0x40000, "test layout: B allocations reach the attacked range");
  REQUIRE(!memcmp(&b_mem[0x40000], &b_mem2[0x40000], 0x2000) && !memcmp(&b_mem[0x42000], &b_mem2[0x42000], 4096),
          "tenant B memory written by tenant A");
  REQUIRE(!memcmp(&b_stor[7 * 512], &e.dev(1).stor[7 * 512], 1024), "tenant B storage disturbed");
  sfv_hv_clear_window(e.mg(0), 1);
  recover(e, 0, A, 32, r);
  done(e);
}

// ===========================================================================
// 14. interrupt / notification suppression
// ===========================================================================
static void t_irq_suppression() {
  Env e(cfg("irq_suppression"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(16);
  open_blk(e, 0, b, 16);
  sfv_vq_set_no_interrupt(&b.vq, 1);
  std::vector<Req> qs;
  for (int i = 0; i < 5; i++) { qs.push_back(good_flush(e, 0, r)); submit(b, qs.back()); }
  sfv_vq_kick(&b.vq);
  for (int i = 0; i < 3000; i++) { REQUIRE(!e.irq(0), "interrupt raised while suppressed"); e.tick(); }
  drain(e, 0, b, qs);
  e.wait_idle(0);
  REQUIRE(!e.irq(0), "interrupt raised while suppressed");
  REQUIRE(sfv_hv_perf32(e.mg(0), SFV_PERF_IRQ_SUP) == 5 && sfv_hv_perf32(e.mg(0), SFV_PERF_IRQ) == 0, "irq counters");
  sfv_vq_set_no_interrupt(&b.vq, 0);
  Req q = good_flush(e, 0, r);
  submit(b, q);
  sfv_vq_kick(&b.vq);
  uint64_t t0 = e.cycle();
  while (!e.irq(0)) { e.tick(); REQUIRE(e.cycle() - t0 < 100000, "interrupt not raised"); }
  REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_INTERRUPT_STATUS) == VIRTIO_MMIO_INT_VRING, "InterruptStatus");
  e.mmio_wr(0, VIRTIO_MMIO_INTERRUPT_ACK, VIRTIO_MMIO_INT_VRING);
  REQUIRE(!e.irq(0), "irq line still high after ACK");
  std::vector<Req> v{q};
  drain(e, 0, b, v);
  done(e);
}

// ===========================================================================
// 15. misaligned buffers and rings
// ===========================================================================
static void t_misaligned() {
  Env e(cfg("misaligned"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(17);
  open_blk(e, 0, b, 32);   // allocator places avail at 6 mod 8 and used at 4 mod 8
  REQUIRE((b.vq.avail_iova & 7) == 6 && (b.vq.used_iova & 7) == 4, "ring placement avail=%llx used=%llx",
          (unsigned long long)b.vq.avail_iova, (unsigned long long)b.vq.used_iova);
  for (int it = 0; it < 32; it++) {
    Layout L;
    L.misalign = it % 8;
    L.hdr_pieces = 1 + it % 4;
    L.data_pieces = 1 + it % 7;
    L.merge_status = it & 1;
    L.data_pieces = std::min(L.data_pieces, (int)e.max_chain - 1 - L.hdr_pieces);   // respect seg_max
    uint32_t n = 1 + it % 3;
    Req w = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 100 + it * 3, n * 512, L);
    w.exp = 0;
    run1(e, 0, b, w);
    L.misalign = (it * 3) % 8;
    Req rd = make_req(e, 0, r, VIRTIO_BLK_T_IN, 100 + it * 3, n * 512, L);
    rd.exp = 0;
    run1(e, 0, b, rd);
    std::vector<uint8_t> got(n * 512);
    e.mem_rd(rd.data_addr, got.data(), got.size());
    REQUIRE(got == w.out, "misaligned mismatch it=%d", it);
  }
  done(e);
}

// ===========================================================================
// 16. storage backend errors
// ===========================================================================
static void t_storage_errors() {
  Env e(cfg("storage_errors"));
  hv_setup(e, 0, 1);
  e.add_bad_sector(0, 100);
  sfv_blk_t b{};
  std::mt19937_64 r(18);
  open_blk(e, 0, b, 16);
  auto s0 = e.dev(0).stor;
  Req w = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 98, 4 * 512, Layout{});
  w.exp = VIRTIO_BLK_S_IOERR;
  run1(e, 0, b, w);
  REQUIRE(!memcmp(&e.dev(0).stor[98 * 512], w.out.data(), 1024), "sectors before the bad one not written");
  REQUIRE(!memcmp(&e.dev(0).stor[101 * 512], &s0[101 * 512], 512), "sector after the bad one written");
  Req rd = make_req(e, 0, r, VIRTIO_BLK_T_IN, 98, 4 * 512, Layout{});
  rd.exp = VIRTIO_BLK_S_IOERR;
  run1(e, 0, b, rd);
  std::vector<uint8_t> got(2048);
  e.mem_rd(rd.data_addr, got.data(), 2048);
  REQUIRE(!memcmp(got.data(), w.out.data(), 1024), "good prefix not returned");
  for (int i = 1024; i < 2048; i++) REQUIRE(got[i] == 0, "tail after failure not zero-filled");
  Req ok = make_req(e, 0, r, VIRTIO_BLK_T_IN, 101, 512, Layout{});
  ok.exp = 0;
  run1(e, 0, b, ok);
  done(e);
}

// ===========================================================================
// 17. FLUSH not negotiated
// ===========================================================================
static void t_flush_not_negotiated() {
  Env e(cfg("flush_not_negotiated"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(19);
  open_blk(e, 0, b, 8, REQUIRED | SFV_FEAT(VIRTIO_BLK_F_SEG_MAX));
  Req f = make_req(e, 0, r, VIRTIO_BLK_T_FLUSH, 0, 0, Layout{});
  f.exp = VIRTIO_BLK_S_UNSUPP;
  run1(e, 0, b, f);
  REQUIRE(e.dev(0).flushes == 0, "backend flushed although FLUSH was not negotiated");
  Req g = make_req(e, 0, r, VIRTIO_BLK_T_GET_ID, 0, 20, Layout{});
  g.exp = 0;
  run1(e, 0, b, g);
  done(e);
}

// ===========================================================================
// 18. invalid queue configuration
// ===========================================================================
static void t_queue_cfg_invalid() {
  Env e(cfg("queue_cfg_invalid"));
  hv_setup(e, 0, 1);
  struct C { uint32_t num; uint64_t desc, drv, dev; } cs[] = {
      {3, 0x20000, 0x21000, 0x22000},                   // not a power of two
      {e.max_qsz * 2, 0x20000, 0x21000, 0x22000},       // above QueueNumMax
      {0, 0x20000, 0x21000, 0x22000},                   // zero
      {8, 0x20008, 0x21000, 0x22000},                   // desc not 16-aligned
      {8, 0x20000, 0x21001, 0x22000},                   // avail not 2-aligned
      {8, 0x20000, 0x21000, 0x22002},                   // used not 4-aligned
  };
  for (auto &c : cs) {
    e.mmio_wr(0, VIRTIO_MMIO_STATUS, 0);
    e.mmio_wr(0, VIRTIO_MMIO_STATUS, 3);
    e.mmio_wr(0, VIRTIO_MMIO_QUEUE_SEL, 0);
    e.mmio_wr(0, VIRTIO_MMIO_QUEUE_NUM, c.num);
    e.mmio_wr(0, VIRTIO_MMIO_QUEUE_DESC_LOW, (uint32_t)c.desc);
    e.mmio_wr(0, VIRTIO_MMIO_QUEUE_DRIVER_LOW, (uint32_t)c.drv);
    e.mmio_wr(0, VIRTIO_MMIO_QUEUE_DEVICE_LOW, (uint32_t)c.dev);
    e.mmio_wr(0, VIRTIO_MMIO_QUEUE_READY, 1);
    REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_QUEUE_READY) == 0, "invalid queue %u enabled", c.num);
    REQUIRE(e.mmio_rd(0, VIRTIO_MMIO_STATUS) & VIRTIO_STATUS_DEVICE_NEEDS_RESET, "NEEDS_RESET not set");
    REQUIRE(sfv_hv_fatal_cause(e.mg(0)) == SFV_FC_QUEUE_CFG, "cause");
  }
  sfv_blk_t b{};
  std::mt19937_64 r(20);
  recover(e, 0, b, 8, r);
  done(e);
}

// ===========================================================================
// 19. host bus errors (address permitted but not backed by memory)
// ===========================================================================
static void t_bus_error() {
  Env e(cfg("bus_error"));
  hv_setup(e, 0, 1);
  const uint64_t top = e.memsize();
  sfv_hv_set_window(e.mg(0), 1, 1, top - 0x1000, top + 0xffff, 1, 1);   // window beyond memory
  sfv_blk_t b{};
  std::mt19937_64 r(21);
  open_blk(e, 0, b, 8);
  Req w = make_req(e, 0, r, VIRTIO_BLK_T_OUT, 30, 512, Layout{}, top - 8);
  w.exp = VIRTIO_BLK_S_IOERR;
  run1(e, 0, b, w);
  Req rd = make_req(e, 0, r, VIRTIO_BLK_T_IN, 30, 512, Layout{}, top - 16);
  submit(b, rd);
  sfv_vq_kick(&b.vq);
  expect_fatal(e, 0, b, SFV_FC_DATA_WRITE_DMA);
  recover(e, 0, b, 8, r);
  done(e);
}

// ===========================================================================
// 20. performance counters
// ===========================================================================
static void t_perf_counters() {
  Env e(cfg("perf_counters"));
  hv_setup(e, 0, 1);
  sfv_blk_t b{};
  std::mt19937_64 r(22);
  open_blk(e, 0, b, 32);
  e.wait_idle(0);
  e.mgmt_wr(0, SFV_MGMT_PERF_CTRL, 1);
  std::vector<Req> qs;
  for (int i = 0; i < 10; i++) {
    Req q = make_req(e, 0, r, VIRTIO_BLK_T_OUT, i * 8, 4096, Layout{});
    q.exp = 0;
    qs.push_back(q);
    submit(b, qs.back());
  }
  sfv_vq_kick(&b.vq);
  drain(e, 0, b, qs);
  e.wait_idle(0);
  auto P32 = [&](uint32_t o) { return sfv_hv_perf32(e.mg(0), o); };
  auto P64 = [&](uint32_t o) { return sfv_hv_perf64(e.mg(0), o); };
  REQUIRE(P32(SFV_PERF_REQ) == 10 && P32(SFV_PERF_DESC) == 30, "req/desc %u/%u", P32(SFV_PERF_REQ), P32(SFV_PERF_DESC));
  REQUIRE(P64(SFV_PERF_RD_BYTES) >= 10 * (4096 + 16 + 48), "rd bytes");
  REQUIRE(P64(SFV_PERF_WR_BYTES) == 10 * (1 + 12), "wr bytes %llu", (unsigned long long)P64(SFV_PERF_WR_BYTES));
  REQUIRE(P32(SFV_PERF_QD_MAX) == 10 && P32(SFV_PERF_QD_N) == 10, "queue depth max %u", P32(SFV_PERF_QD_MAX));
  REQUIRE(P32(SFV_PERF_CLAT_MAX) > 0 && P64(SFV_PERF_CLAT_SUM) >= P32(SFV_PERF_CLAT_MAX), "latency");
  REQUIRE(P32(SFV_PERF_WLAT_MAX) > 0, "walk latency");
  REQUIRE(P64(SFV_PERF_BUSY) <= P64(SFV_PERF_TOTAL), "busy <= total");
  REQUIRE(P32(SFV_PERF_NOTIFY) == 1 && P32(SFV_PERF_VIOL) == 0, "notify/viol");
  done(e);
}

// ===========================================================================
// performance sweep (reported, not pass/fail beyond sanity)
// ===========================================================================
static void t_perf_sweep() {
  FILE *out = O.perf_out.empty() ? nullptr : fopen(O.perf_out.c_str(), "w");
  auto both = [&](const char *fmt, auto... a) {
    printf(fmt, a...);
    if (out) fprintf(out, fmt, a...);
  };
  both("%-6s %-8s %-6s %-4s %-6s | %10s %10s %10s %10s\n", "dir", "bytes", "segs", "mis", "dmalat", "clat_avg",
       "wlat_avg", "B/cycle", "beats/req");
  for (int lat : {1, 16}) {
    for (int dir = 0; dir < 2; dir++) {
      for (uint32_t bytes : {512u, 4096u, 16384u, 65536u}) {
        for (int mis : {0, 3}) {
          for (int segs : {1, 8}) {
            Env::Cfg c = cfg("perf");
            c.outdir.clear();
            Env e(c);
            hv_setup(e, 0, 1);
            e.dev(0).k = Knobs{0, lat, lat, 0, 2, 2};
            sfv_blk_t b{};
            std::mt19937_64 r(23);
            open_blk(e, 0, b, 64);
            const int N = 6;
            e.wait_idle(0);
            e.mgmt_wr(0, SFV_MGMT_PERF_CTRL, 1);
            uint64_t beats0 = e.dev(0).dma_beats;
            uint64_t mark = e.dev(0).alloc_ptr;
            for (int i = 0; i < N; i++) {
              e.dev(0).alloc_ptr = mark;   // recycle the request buffers
              Layout L;
              L.misalign = mis;
              L.data_pieces = segs;
              Req q = make_req(e, 0, r, dir ? VIRTIO_BLK_T_IN : VIRTIO_BLK_T_OUT, 0, bytes, L);
              q.exp = 0;
              run1(e, 0, b, q);
            }
            uint64_t cl = sfv_hv_perf64(e.mg(0), SFV_PERF_CLAT_SUM);
            uint64_t wl = sfv_hv_perf64(e.mg(0), SFV_PERF_WLAT_SUM);
            both("%-6s %-8u %-6d %-4d %-6d | %10.1f %10.1f %10.3f %10.1f\n", dir ? "IN" : "OUT", bytes, segs, mis, lat,
                 (double)cl / N, (double)wl / N, (double)bytes * N / cl, (double)(e.dev(0).dma_beats - beats0) / N);
          }
        }
      }
    }
  }
  if (out) fclose(out);
}

// ===========================================================================
// 21. randomized regression (reference-model checked)
// ===========================================================================
static void random_scenario(uint64_t seed) {
  std::mt19937_64 r(seed * 7919 + 13);
  int ndev = (r() % 3 == 0) ? 2 : 1;
  Env e(cfg("rand_" + std::to_string(seed), ndev, seed));
  struct DS {
    sfv_blk_t b{};
    uint16_t q = 8;
    bool flush = true;
    std::set<uint64_t> bad;
  };
  std::vector<DS> ds(ndev);
  for (int d = 0; d < ndev; d++) {
    DS &S = ds[d];
    e.dev(d).k = Knobs{(int)(r() % 60), 1, 1 + (int)(r() % 10), (int)(r() % 60), 1, 1 + (int)(r() % 10)};
    hv_setup(e, d, (uint16_t)(1 + d + (r() % 50) * 2));
    if (r() % 3 == 0)
      for (int k = 0; k < 2; k++) {
        uint64_t s = r() % e.capacity;
        S.bad.insert(s);
        e.add_bad_sector(d, s);
      }
    S.q = (uint16_t)(1u << (2 + r() % 7));
    if (S.q > e.max_qsz) S.q = (uint16_t)e.max_qsz;
    S.flush = r() % 5 != 0;
    open_blk(e, d, S.b, S.q, S.flush ? WANTED_ALL : REQUIRED);
  }
  std::vector<uint64_t> mark(ndev);
  for (int d = 0; d < ndev; d++) mark[d] = e.dev(d).alloc_ptr;
  int rounds = 5 + (int)(r() % 8);
  for (int round = 0; round < rounds; round++) {
    std::vector<std::vector<Req>> inflight(ndev);
    for (int d = 0; d < ndev; d++) {
      DS &S = ds[d];
      e.dev(d).alloc_ptr = mark[d];
      if (r() % 8 == 0) sfv_vq_set_no_interrupt(&S.b.vq, (int)(r() & 1));   // device is idle here
      if (r() % 18 == 0) {
        // malformed chain on its own -> fatal -> full recovery
        uint16_t kind = (uint16_t)(r() % 4);
        uint64_t t = balloc(e, d, 64, 16);
        uint16_t h = S.b.vq.free_head;
        if (kind == 0) raw_desc(e, S.b.vq, h, t, 16, VIRTQ_DESC_F_NEXT, h);                // loop
        if (kind == 1) raw_desc(e, S.b.vq, h, t, 16, VIRTQ_DESC_F_INDIRECT, 0);            // flags
        if (kind == 2) raw_desc(e, S.b.vq, h, t, 16, VIRTQ_DESC_F_NEXT, (uint16_t)S.q);    // OOR
        if (kind == 3) raw_desc(e, S.b.vq, h, t, 16, 0, 0);                                 // no status
        raw_publish(e, S.b.vq, h);
        const int causes[] = {SFV_FC_CHAIN_LOOP, SFV_FC_DESC_FLAGS, SFV_FC_DESC_IDX_OOR, SFV_FC_NO_STATUS};
        expect_fatal(e, d, S.b, causes[kind]);
        open_blk(e, d, S.b, S.q, S.flush ? WANTED_ALL : REQUIRED);
        mark[d] = e.dev(d).alloc_ptr;
        continue;
      }
      int n = 1 + (int)(r() % std::min<int>(8, S.q / 2));
      for (int i = 0; i < n; i++) {
        uint32_t pick = (uint32_t)(r() % 100), type;
        int variant = 0;   // 0 normal, 1 bad len, 2 OOR sector, 3 short header, 4 foreign payload
        if (pick < 34) type = VIRTIO_BLK_T_IN;
        else if (pick < 68) type = VIRTIO_BLK_T_OUT;
        else if (pick < 76) type = VIRTIO_BLK_T_FLUSH;
        else if (pick < 83) type = VIRTIO_BLK_T_GET_ID;
        else if (pick < 88) { const uint32_t u[] = {2, 3, 11, 13, 14, 99, 0xffffffffu}; type = u[r() % 7]; }
        else { type = (r() & 1) ? VIRTIO_BLK_T_IN : VIRTIO_BLK_T_OUT; variant = 1 + (int)(r() % 4); }
        if (variant == 4 && type == VIRTIO_BLK_T_IN) type = VIRTIO_BLK_T_OUT;   // writable foreign = fatal
        uint32_t nsec = (uint32_t)(r() % 9);
        if (variant == 4 && nsec == 0) nsec = 1;      // a foreign payload needs a payload descriptor
        uint32_t dlen = nsec * 512;
        uint64_t sector = r() % (e.capacity - 8);
        if (type == VIRTIO_BLK_T_FLUSH || (type != VIRTIO_BLK_T_IN && type != VIRTIO_BLK_T_OUT && type != VIRTIO_BLK_T_GET_ID)) dlen = 0;
        if (type == VIRTIO_BLK_T_GET_ID) dlen = (uint32_t)(r() % 40);
        if (variant == 1) dlen = 1 + (uint32_t)(r() % 2000), dlen += (dlen % 512 == 0);
        if (variant == 2) sector = e.capacity - (r() % 2), dlen = 1024;
        Layout L;
        L.misalign = (r() % 3 == 0) ? (int)(r() % 8) : 0;
        L.hdr_pieces = 1 + (int)(r() % 3);
        L.data_pieces = 1 + (int)(r() % 5);
        L.merge_status = r() & 1;
        if (variant == 3) L.hdr_len = 1 + (uint32_t)(r() % 15);
        int budget = (int)std::min<uint32_t>(e.max_chain, S.b.vq.num_free);
        int need = std::min<int>(L.hdr_pieces, (int)L.hdr_len) + (dlen ? std::min<int>(L.data_pieces, (int)dlen) : 0) + 1;
        while (need > budget && (L.data_pieces > 1 || L.hdr_pieces > 1)) {
          if (L.data_pieces > 1) L.data_pieces--; else L.hdr_pieces--;
          need = std::min<int>(L.hdr_pieces, (int)L.hdr_len) + (dlen ? std::min<int>(L.data_pieces, (int)dlen) : 0) + 1;
        }
        if (need > budget) break;
        uint64_t foreign = 0;
        if (variant == 4) foreign = (ndev == 2) ? RBASE[1 - d] + (r() % 0x10000) : UNMAPPED + (r() % 0x10000);
        Req q = make_req(e, d, r, type, sector, dlen, L, foreign);
        // harness-side expected status
        bool rw = type == VIRTIO_BLK_T_IN || type == VIRTIO_BLK_T_OUT;
        if (variant == 3 && type == VIRTIO_BLK_T_OUT) q.exp = -1;   // framing: header runs into payload (2.6.4); model decides
        else if (variant) q.exp = VIRTIO_BLK_S_IOERR;
        else if (rw) {
          q.exp = VIRTIO_BLK_S_OK;
          for (uint32_t s = 0; s < nsec; s++) if (S.bad.count(sector + s)) q.exp = VIRTIO_BLK_S_IOERR;
        } else if (type == VIRTIO_BLK_T_FLUSH) q.exp = S.flush ? 0 : VIRTIO_BLK_S_UNSUPP;
        else if (type == VIRTIO_BLK_T_GET_ID) q.exp = 0;
        else q.exp = VIRTIO_BLK_S_UNSUPP;
        inflight[d].push_back(q);
        submit(S.b, inflight[d].back());
      }
    }
    for (int d = 0; d < ndev; d++) sfv_vq_kick(&ds[d].b.vq);
    for (int d = 0; d < ndev; d++) drain(e, d, ds[d].b, inflight[d]);
    e.wait_all_idle();
    if (r() % 12 == 0) {
      int d = (int)(r() % ndev);
      open_blk(e, d, ds[d].b, ds[d].q, ds[d].flush ? WANTED_ALL : REQUIRED);
      mark[d] = e.dev(d).alloc_ptr;
    }
  }
  done(e);
}

// ===========================================================================
int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    auto nxt = [&]() { return std::string(argv[++i]); };
    if (a == "--outdir") O.outdir = nxt();
    else if (a == "--refcheck") O.refcheck = nxt();
    else if (a == "--only") O.only = nxt();
    else if (a == "--seed") O.seed = std::stoull(nxt());
    else if (a == "--iters") O.iters = std::stoi(nxt());
    else if (a == "--skip-long") O.skip_long = true;
    else if (a == "--perf-out") O.perf_out = nxt();
  }
  std::vector<std::pair<std::string, std::function<void()>>> tests = {
      {"init_negotiation", t_init_negotiation},     {"single_descriptor", t_single_descriptor},
      {"chained", t_chained},                       {"ring_wrap_slots", t_ring_wrap_slots},
      {"ring_wrap_idx16", t_ring_wrap_idx16},       {"queue_full_empty", t_queue_full_empty},
      {"invalid_flags", t_invalid_flags},           {"invalid_lengths", t_invalid_lengths},
      {"malformed_chains", t_malformed_chains},     {"dma_permission", t_dma_permission},
      {"reset_midflight", t_reset_midflight},       {"reset_after_fatal", t_reset_after_fatal},
      {"backpressure", t_backpressure},             {"completion_ordering", t_completion_ordering},
      {"multi_tenant", t_multi_tenant},             {"window_boundaries", t_window_boundaries},             {"irq_suppression", t_irq_suppression},
      {"misaligned", t_misaligned},                 {"storage_errors", t_storage_errors},
      {"flush_not_negotiated", t_flush_not_negotiated}, {"queue_cfg_invalid", t_queue_cfg_invalid},
      {"bus_error", t_bus_error},                   {"perf_counters", t_perf_counters},
  };
  if (O.only == "perf_sweep") tests = {{"perf_sweep", t_perf_sweep}};
  for (int i = 0; i < O.iters; i++) {
    uint64_t s = O.seed + i;
    tests.push_back({"random_" + std::to_string(s), [s]() { random_scenario(s); }});
  }
  int pass = 0, fail = 0;
  auto T0 = std::chrono::steady_clock::now();
  for (auto &t : tests) {
    if (!O.only.empty() && O.only != "perf_sweep" && O.only != "random" && t.first != O.only) continue;
    if (O.only == "random" && t.first.rfind("random_", 0) != 0) continue;
    if (O.skip_long && t.first == "ring_wrap_idx16") continue;
    auto t0 = std::chrono::steady_clock::now();
    try {
      t.second();
      double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      printf("PASS  %-24s %7.2fs\n", t.first.c_str(), s);
      pass++;
    } catch (std::exception &ex) {
      printf("FAIL  %-24s %s\n", t.first.c_str(), ex.what());
      fail++;
    }
    fflush(stdout);
  }
  double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - T0).count();
  printf("\n%d passed, %d failed (%.1fs)\n", pass, fail, s);
  return fail ? 1 : 0;
}
