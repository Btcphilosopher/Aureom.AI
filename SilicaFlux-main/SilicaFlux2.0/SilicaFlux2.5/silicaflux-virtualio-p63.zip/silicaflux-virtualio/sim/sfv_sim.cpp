// sfv_sim.cpp — C ABI wrapper over Env (see sfv_sim.h)
#include "sfv_sim.h"
#include "sim_env.h"
struct sfv_sim { Env *e; };
extern "C" {
sfv_sim_t *sfv_sim_create(int ndev, uint64_t memsize, uint64_t seed) {
  Env::Cfg c;
  c.ndev = ndev;
  c.memsize = memsize;
  c.seed = seed;
  return new sfv_sim{new Env(c)};
}
void sfv_sim_destroy(sfv_sim_t *s) { delete s->e; delete s; }
const sfv_transport_t *sfv_sim_transport(sfv_sim_t *s, int d) { return s->e->tr(d); }
const sfv_mgmt_transport_t *sfv_sim_mgmt(sfv_sim_t *s, int d) { return s->e->mg(d); }
void sfv_sim_set_region(sfv_sim_t *s, int d, uint64_t base, uint64_t size) { s->e->set_region(d, base, size); }
void sfv_sim_set_latency(sfv_sim_t *s, int d, int dl, int sl) {
  s->e->dev(d).k.dma_lat_min = s->e->dev(d).k.dma_lat_max = dl;
  s->e->dev(d).k.sc_lat_min = s->e->dev(d).k.sc_lat_max = sl;
}
uint64_t sfv_sim_cycles(sfv_sim_t *s) { return s->e->cycle(); }
int sfv_sim_dma_escapes(sfv_sim_t *s) { return s->e->monitor_errors(); }
}
