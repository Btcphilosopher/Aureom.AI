// sim_env.cpp — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
#include "sim_env.h"

#include <cstdarg>
#include <cstdlib>
#include <cstring>
#include <stdexcept>

#include "Vsilicaflux_virtio_engine.h"
#include "verilated.h"

// ---------------------------------------------------------------------------
// deterministic storage initial contents (mirrored in refmodel/src/lib.rs)
// ---------------------------------------------------------------------------
static uint64_t splitmix64(uint64_t x) {
  x += 0x9e3779b97f4a7c15ull;
  x = (x ^ (x >> 30)) * 0xbf58476d1ce4e5b9ull;
  x = (x ^ (x >> 27)) * 0x94d049bb133111ebull;
  return x ^ (x >> 31);
}
uint8_t Env::stor_init_byte(uint64_t seed, int dev, uint64_t i) {
  uint64_t w = splitmix64(seed ^ ((uint64_t)(dev + 1) << 48) ^ (i >> 3));
  return (uint8_t)(w >> (8 * (i & 7)));
}

// ---------------------------------------------------------------------------
// transport callbacks (C ABI for the host library)
// ---------------------------------------------------------------------------
static uint32_t t_mmio_rd(void *c, uint32_t off) { Dev *D = (Dev *)c; return D->env->mmio_rd(D->idx, off); }
static void t_mmio_wr(void *c, uint32_t off, uint32_t v) { Dev *D = (Dev *)c; D->env->mmio_wr(D->idx, off, v); }
static int t_alloc(void *c, size_t size, size_t align, uint64_t *iova) {
  Dev *D = (Dev *)c;
  return D->env->dma_alloc(D->idx, size, align, iova);
}
static void t_mem_wr(void *c, uint64_t a, const void *p, size_t n) { ((Dev *)c)->env->mem_wr(a, p, n); }
static void t_mem_rd(void *c, uint64_t a, void *p, size_t n) { ((Dev *)c)->env->mem_rd(a, p, n); }
static void t_mb(void *) {}
static int t_wait_irq(void *c, uint32_t budget) {
  Dev *D = (Dev *)c;
  for (uint32_t i = 0; i < budget; i++) {
    if (D->env->irq(D->idx)) return 1;
    D->env->tick();
  }
  return D->env->irq(D->idx);
}
static uint32_t m_rd(void *c, uint32_t off) { Dev *D = (Dev *)c; return D->env->mgmt_rd(D->idx, off); }
static void m_wr(void *c, uint32_t off, uint32_t v) { Dev *D = (Dev *)c; D->env->mgmt_wr(D->idx, off, v); }

// ---------------------------------------------------------------------------
Env::Env(const Cfg &c) : cfg_(c), rng(c.seed * 0x9e3779b97f4a7c15ull + 7) {
  ctx_ = std::make_unique<VerilatedContext>();
  ctx_->randReset(0);
  mem_.assign(c.memsize, 0);
  for (int d = 0; d < c.ndev; d++) {
    auto D = std::make_unique<Dev>();
    D->m = std::make_unique<Vsilicaflux_virtio_engine>(ctx_.get());
    D->env = this;
    D->idx = d;
    D->tr = {D.get(), t_mmio_rd, t_mmio_wr, t_alloc, t_mem_wr, t_mem_rd, t_mb, t_wait_irq};
    D->mg = {D.get(), m_rd, m_wr};
    devs_.push_back(std::move(D));
  }
  // reset
  for (auto &D : devs_) {
    auto *m = D->m.get();
    m->rst_n = 0;
    m->clk = 0;
    m->mmio_req_valid = 0;
    m->mgmt_req_valid = 0;
    m->dma_req_ready = 0;
    m->dma_resp_valid = 0;
    m->sc_req_ready = 0;
    m->sc_resp_valid = 0;
    m->eval();
  }
  tick(4);
  for (auto &D : devs_) D->m->rst_n = 1;
  tick(2);

  // discover build parameters through the management window
  uint32_t caps0 = mgmt_rd(0, SFV_MGMT_CAPS0), caps1 = mgmt_rd(0, SFV_MGMT_CAPS1);
  max_chain = (caps0 >> 8) & 0xff;
  n_win = (caps0 >> 16) & 0xff;
  max_qsz = caps1 & 0xffff;
  capacity = mgmt_rd(0, SFV_MGMT_CAP_LO) | ((uint64_t)mgmt_rd(0, SFV_MGMT_CAP_HI) << 32);
  for (auto &D : devs_) {
    D->stor.resize(capacity * 512);
    for (uint64_t i = 0; i < D->stor.size(); i++) D->stor[i] = stor_init_byte(c.seed, D->idx, i);
  }

  if (!c.outdir.empty()) {
    std::string p = c.outdir + "/" + c.name + ".oplog";
    log_ = fopen(p.c_str(), "w");
    if (!log_) throw std::runtime_error("cannot open " + p);
    logf("SFVLOG 1\n");
    logf("PARAM ndev %d\nPARAM memsize %llu\nPARAM max_qsz %u\nPARAM max_chain %u\n"
         "PARAM n_win %u\nPARAM capacity %llu\nPARAM seed %llu\n",
         c.ndev, (unsigned long long)c.memsize, max_qsz, max_chain, n_win,
         (unsigned long long)capacity, (unsigned long long)c.seed);
  }
}

Env::~Env() {
  if (log_) fclose(log_);
  for (auto &D : devs_) D->m->final();
}

void Env::logf(const char *fmt, ...) {
  if (!log_) return;
  va_list ap;
  va_start(ap, fmt);
  vfprintf(log_, fmt, ap);
  va_end(ap);
}

void Env::log_nocheck(const char *why) { nocheck_ = true; logf("NOCHECK %s\n", why); }

// ---------------------------------------------------------------------------
// clock
// ---------------------------------------------------------------------------
void Env::tick(int n) {
  const size_t N = devs_.size();
  std::vector<char> dresp(N), sresp(N), bushs(N);
  while (n-- > 0) {
    for (size_t i = 0; i < N; i++) {
      Dev &D = *devs_[i];
      auto *m = D.m.get();
      m->dma_req_ready = !D.dma_busy && (int)(rng() % 100) >= D.k.dma_bp;
      dresp[i] = D.dma_busy && cyc_ >= D.dma_due;
      m->dma_resp_valid = dresp[i];
      m->dma_resp_rdata = dresp[i] ? D.dma_rdata : 0;
      m->dma_resp_err = dresp[i] && D.dma_err;
      m->sc_req_ready = !D.sc_busy && (int)(rng() % 100) >= D.k.sc_bp;
      sresp[i] = D.sc_busy && cyc_ >= D.sc_due;
      m->sc_resp_valid = sresp[i];
      m->sc_resp_rdata = sresp[i] ? D.sc_rdata : 0;
      m->sc_resp_err = sresp[i] && D.sc_err;
      bool bv = D.bus_active && !D.bus_acc;
      m->mmio_req_valid = bv && !D.bus_mgmt;
      m->mgmt_req_valid = bv && D.bus_mgmt;
      m->mmio_req_we = D.bus_we;
      m->mgmt_req_we = D.bus_we;
      m->mmio_req_addr = D.bus_addr & 0xfff;
      m->mgmt_req_addr = D.bus_addr & 0xfff;
      m->mmio_req_wdata = D.bus_wdata;
      m->mgmt_req_wdata = D.bus_wdata;
      m->mmio_req_be = 0xf;
      m->clk = 0;
      m->eval();
    }
    for (size_t i = 0; i < N; i++) {
      Dev &D = *devs_[i];
      auto *m = D.m.get();
      // ---- DMA request ----
      if (m->dma_req_valid && m->dma_req_ready) {
        uint64_t a = m->dma_req_addr;
        uint8_t be = m->dma_req_be;
        bool we = m->dma_req_we;
        monitor_check(D, a, be, we, m->dma_req_domain);
        D.dma_beats++;
        D.dma_err = (a & 7) || a + 8 > mem_.size();
        D.dma_rdata = 0;
        if (!D.dma_err) {
          for (int b = 0; b < 8; b++) {
            if (!((be >> b) & 1)) continue;
            if (we) mem_[a + b] = (uint8_t)(m->dma_req_wdata >> (8 * b));
            else D.dma_rdata |= (uint64_t)mem_[a + b] << (8 * b);
          }
        }
        D.dma_busy = true;
        D.dma_due = cyc_ + D.k.dma_lat_min +
                    (D.k.dma_lat_max > D.k.dma_lat_min ? rng() % (D.k.dma_lat_max - D.k.dma_lat_min + 1) : 0);
      }
      // ---- StorageCore request ----
      if (m->sc_req_valid && m->sc_req_ready) {
        uint32_t a = m->sc_req_addr;
        uint8_t be = m->sc_req_be;
        int op = m->sc_req_op;
        D.sc_ops++;
        D.sc_rdata = 0;
        D.sc_err = false;
        if (op == 2) {
          D.flushes++;
        } else if ((a & 7) || (uint64_t)a + 8 > D.stor.size() || D.bad.count(a / 512)) {
          D.sc_err = true;
        } else {
          for (int b = 0; b < 8; b++) {
            if (op == 1) {
              if ((be >> b) & 1) D.stor[a + b] = (uint8_t)(m->sc_req_wdata >> (8 * b));
            } else {
              D.sc_rdata |= (uint64_t)D.stor[a + b] << (8 * b);
            }
          }
        }
        D.sc_busy = true;
        D.sc_due = cyc_ + D.k.sc_lat_min +
                   (D.k.sc_lat_max > D.k.sc_lat_min ? rng() % (D.k.sc_lat_max - D.k.sc_lat_min + 1) : 0);
      }
      bushs[i] = D.bus_active && !D.bus_acc &&
                 (D.bus_mgmt ? (m->mgmt_req_valid && m->mgmt_req_ready)
                             : (m->mmio_req_valid && m->mmio_req_ready));
    }
    for (size_t i = 0; i < N; i++) {
      devs_[i]->m->clk = 1;
      devs_[i]->m->eval();
    }
    for (size_t i = 0; i < N; i++) {
      Dev &D = *devs_[i];
      auto *m = D.m.get();
      if (dresp[i]) D.dma_busy = false;
      if (sresp[i]) D.sc_busy = false;
      if (bushs[i]) {
        D.bus_acc = true;
        bool rv = D.bus_mgmt ? m->mgmt_resp_valid : m->mmio_resp_valid;
        if (!rv) throw std::runtime_error("bus protocol: no response one cycle after accept");
        D.bus_rdata = D.bus_mgmt ? m->mgmt_resp_rdata : m->mmio_resp_rdata;
        D.bus_done = true;
      }
    }
    cyc_++;
  }
}

// ---------------------------------------------------------------------------
// buses
// ---------------------------------------------------------------------------
void Env::bus(int d, bool mgmt, bool we, uint32_t addr, uint32_t wdata, uint32_t *rdata) {
  Dev &D = *devs_[d];
  D.bus_active = true;
  D.bus_mgmt = mgmt;
  D.bus_we = we;
  D.bus_addr = addr;
  D.bus_wdata = wdata;
  D.bus_acc = false;
  D.bus_done = false;
  uint64_t t0 = cyc_;
  while (!D.bus_done) {
    tick();
    if (cyc_ - t0 > 2000000) throw std::runtime_error("bus timeout");
  }
  D.bus_active = false;
  D.bus_acc = false;
  tick();   // idle cycle between accesses
  if (rdata) *rdata = D.bus_rdata;
}

uint32_t Env::mmio_rd(int d, uint32_t off) { uint32_t v; bus(d, false, false, off, 0, &v); return v; }
void Env::mmio_wr(int d, uint32_t off, uint32_t v) {
  logf("MMIO %d %x %x\n", d, off, v);
  bus(d, false, true, off, v, nullptr);
}
uint32_t Env::mgmt_rd(int d, uint32_t off) { uint32_t v; bus(d, true, false, off, 0, &v); return v; }
void Env::mgmt_wr(int d, uint32_t off, uint32_t v) {
  logf("MGMT %d %x %x\n", d, off, v);
  shadow_mgmt_write(*devs_[d], off, v);
  bus(d, true, true, off, v, nullptr);
}

void Env::mgmt_wr_noshadow(int d, uint32_t off, uint32_t v) {
  logf("MGMT %d %x %x\n", d, off, v);
  bus(d, true, true, off, v, nullptr);
}

bool Env::irq(int d) { return devs_[d]->m->irq; }

bool Env::engine_busy(int d) { return mgmt_rd(d, SFV_MGMT_ENGINE_STATUS) & 1; }

void Env::wait_idle(int d, uint64_t max_cycles) {
  uint64_t t0 = cyc_;
  while (engine_busy(d)) {
    tick(8);
    if (cyc_ - t0 > max_cycles) throw std::runtime_error("wait_idle timeout");
  }
}
void Env::wait_all_idle() { for (int d = 0; d < ndev(); d++) wait_idle(d); }

// ---------------------------------------------------------------------------
// memory
// ---------------------------------------------------------------------------
void Env::mem_wr(uint64_t a, const void *p, size_t n) {
  if (a + n > mem_.size()) throw std::runtime_error("host mem_wr out of range");
  memcpy(&mem_[a], p, n);
  if (log_ && n) {
    const uint8_t *b = (const uint8_t *)p;
    fprintf(log_, "W %llx ", (unsigned long long)a);
    for (size_t i = 0; i < n; i++) fprintf(log_, "%02x", b[i]);
    fputc('\n', log_);
  }
}
void Env::mem_rd(uint64_t a, void *p, size_t n) const {
  if (a + n > mem_.size()) throw std::runtime_error("host mem_rd out of range");
  memcpy(p, &mem_[a], n);
}

void Env::set_region(int d, uint64_t base, uint64_t size) {
  Dev &D = *devs_[d];
  D.region_base = base;
  D.region_size = size;
  D.alloc_ptr = base;
}

int Env::dma_alloc(int d, size_t size, size_t align, uint64_t *iova) {
  Dev &D = *devs_[d];
  if (align == 0) align = 1;
  uint64_t p = (D.alloc_ptr + align - 1) & ~(uint64_t)(align - 1);
  // tight alignment: honour exactly the required alignment and no more, so
  // that lane handling for 2/4-byte aligned rings is exercised
  if (D.tight_align && align < 8)
    while ((p & 7) != (8 - align) % 8) p += align;
  if (p + size > D.region_base + D.region_size) return -1;
  D.alloc_ptr = p + size;
  *iova = p;
  return 0;
}

void Env::add_bad_sector(int d, uint64_t s) {
  devs_[d]->bad.insert(s);
  logf("SFAULT %d %llx\n", d, (unsigned long long)s);
}

// ---------------------------------------------------------------------------
// independent DMA permission monitor
// ---------------------------------------------------------------------------
void Env::shadow_mgmt_write(Dev &D, uint32_t off, uint32_t v) {
  if (off == SFV_MGMT_Q0_DOMAIN) {
    // the shadow holds the hypervisor's INTENDED binding; tests that probe the
    // lock-while-enabled rule use mgmt_wr_noshadow()
    D.dom = v & 0xffff;
    D.dom_valid = (v >> 31) & 1;
    return;
  }
  if (off >= 0x40 && off < 0x40 + 0x20 * n_win) {
    unsigned w = (off - 0x40) / 0x20, f = ((off - 0x40) % 0x20) / 4;
    ShadowWin &W = D.win[w];
    switch (f) {
      case 0: W.valid = v & 1; W.r = (v >> 1) & 1; W.w = (v >> 2) & 1; break;
      case 1: W.dom = v & 0xffff; break;
      case 2: W.base = (W.base & ~0xffffffffull) | v; break;
      case 3: W.base = (W.base & 0xffffffffull) | ((uint64_t)v << 32); break;
      case 4: W.limit = (W.limit & ~0xffffffffull) | v; break;
      case 5: W.limit = (W.limit & 0xffffffffull) | ((uint64_t)v << 32); break;
    }
  }
}

void Env::monitor_check(Dev &D, uint64_t a, uint8_t be, bool we, uint16_t dom) {
  if (monitor_lenient) return;
  auto fail = [&](const char *why) {
    if (!mon_err_) {
      char b[256];
      snprintf(b, sizeof b, "dev%d cyc%llu %s addr=%llx be=%02x we=%d dom=%u", D.idx,
               (unsigned long long)cyc_, why, (unsigned long long)a, be, we, dom);
      mon_first_ = b;
    }
    mon_err_++;
  };
  if (!D.dom_valid) return fail("DMA with no bound domain");
  if (dom != D.dom) return fail("DMA domain tag mismatch");
  if (be == 0) return fail("empty byte enable");
  int lo = __builtin_ctz(be), hi = 31 - __builtin_clz(be);
  uint64_t blo = a + lo, bhi = a + hi;
  for (unsigned i = 0; i < n_win; i++) {
    const ShadowWin &W = D.win[i];
    if (W.valid && W.dom == D.dom && blo >= W.base && bhi <= W.limit && (we ? W.w : W.r)) return;
  }
  fail("DMA outside tenant permission");
}

// ---------------------------------------------------------------------------
// finish: dumps + reference-model check
// ---------------------------------------------------------------------------
int Env::finish(const std::string &refcheck) {
  if (cfg_.outdir.empty()) return 0;
  wait_all_idle();
  std::string base = cfg_.outdir + "/" + cfg_.name;
  logf("END\n");
  fclose(log_);
  log_ = nullptr;
  std::vector<std::string> files = {base + ".oplog", base + ".mem.bin", base + ".actual"};
  {
    FILE *f = fopen((base + ".mem.bin").c_str(), "wb");
    fwrite(mem_.data(), 1, mem_.size(), f);
    fclose(f);
  }
  FILE *a = fopen((base + ".actual").c_str(), "w");
  fprintf(a, "SFVACT 1\nMEM %s.mem.bin\n", cfg_.name.c_str());
  for (int d = 0; d < ndev(); d++) {
    std::string sp = base + ".stor" + std::to_string(d) + ".bin";
    FILE *f = fopen(sp.c_str(), "wb");
    fwrite(devs_[d]->stor.data(), 1, devs_[d]->stor.size(), f);
    fclose(f);
    files.push_back(sp);
    fprintf(a, "STOR %d %s.stor%d.bin\n", d, cfg_.name.c_str(), d);
    fprintf(a, "DEV %d status %x\n", d, mmio_rd(d, VIRTIO_MMIO_STATUS));
    fprintf(a, "DEV %d engine_status %x\n", d, mgmt_rd(d, SFV_MGMT_ENGINE_STATUS));
    const struct { const char *n; uint32_t o; } cnt[] = {
        {"desc", SFV_PERF_DESC},     {"req", SFV_PERF_REQ},       {"viol", SFV_PERF_VIOL},
        {"fatal", SFV_PERF_FATAL},   {"ioerr", SFV_PERF_IOERR},   {"unsupp", SFV_PERF_UNSUPP},
        {"irq", SFV_PERF_IRQ},       {"irq_sup", SFV_PERF_IRQ_SUP}, {"notify", SFV_PERF_NOTIFY}};
    for (auto &c : cnt) fprintf(a, "DEV %d cnt %s %u\n", d, c.n, mgmt_rd(d, SFV_MGMT_PERF(c.o)));
    fprintf(a, "DEV %d flushes %llu\n", d, (unsigned long long)devs_[d]->flushes);
  }
  fclose(a);
  if (nocheck_ || refcheck.empty()) {
    for (auto &f : files) remove(f.c_str());
    return 0;
  }
  std::string cmd = refcheck + " " + base + ".oplog " + base + ".actual";
  int rc = system(cmd.c_str());
  if (rc == 0)
    for (auto &f : files) remove(f.c_str());
  return rc == 0 ? 0 : 1;
}
