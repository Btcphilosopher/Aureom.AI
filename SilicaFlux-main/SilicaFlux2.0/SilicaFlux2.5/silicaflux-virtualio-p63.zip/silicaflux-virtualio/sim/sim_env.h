// sim_env.h — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Co-simulation platform for silicaflux_virtio_engine (Verilator):
//   * host physical memory shared by all simulated devices
//   * per-device DMA responder (random backpressure + latency, bus error
//     beyond memory)
//   * per-device StorageCore model (random backpressure + latency, injectable
//     bad sectors, flush)
//   * blocking MMIO / management bus drivers used by the C host library
//   * an INDEPENDENT DMA-permission monitor: every beat leaving the engine is
//     re-checked against a shadow copy of the permission table decoded from
//     the management writes; any escape is a test failure
//   * an operation log replayed by the Rust reference model (refmodel/)
#pragma once
#include <cstdint>
#include <cstdio>
#include <memory>
#include <random>
#include <set>
#include <string>
#include <vector>

#include "sfvirtio.h"

class Vsilicaflux_virtio_engine;
class VerilatedContext;

struct Knobs {
  int dma_bp = 0;          // % of cycles dma_req_ready is low
  int dma_lat_min = 1, dma_lat_max = 1;
  int sc_bp = 0;
  int sc_lat_min = 1, sc_lat_max = 1;
};

struct ShadowWin {
  bool valid = false, r = false, w = false;
  uint16_t dom = 0;
  uint64_t base = 0, limit = 0;
};

class Env;

struct Dev {
  std::unique_ptr<Vsilicaflux_virtio_engine> m;
  Env *env = nullptr;
  int idx = 0;
  Knobs k;
  // DMA responder
  bool dma_busy = false;
  uint64_t dma_due = 0, dma_rdata = 0;
  bool dma_err = false;
  // storage responder
  std::vector<uint8_t> stor;
  std::set<uint64_t> bad;
  bool sc_busy = false;
  uint64_t sc_due = 0, sc_rdata = 0;
  bool sc_err = false;
  uint64_t flushes = 0;
  // bus driver
  bool bus_active = false, bus_mgmt = false, bus_we = false, bus_acc = false, bus_done = false;
  uint32_t bus_addr = 0, bus_wdata = 0, bus_rdata = 0;
  // shadow permission state (monitor)
  ShadowWin win[64];
  uint16_t dom = 0;
  bool dom_valid = false;
  // tenant DMA allocator
  uint64_t region_base = 0, region_size = 0, alloc_ptr = 0;
  bool tight_align = true;
  // stats
  uint64_t dma_beats = 0, sc_ops = 0;
  // transports
  sfv_transport_t tr{};
  sfv_mgmt_transport_t mg{};
};

class Env {
 public:
  struct Cfg {
    int ndev = 1;
    uint64_t memsize = 1u << 20;
    uint64_t seed = 1;
    std::string outdir;      // empty => no op-log / dumps
    std::string name = "test";
  };
  explicit Env(const Cfg &c);
  ~Env();

  void tick(int n = 1);
  uint64_t cycle() const { return cyc_; }

  uint32_t mmio_rd(int d, uint32_t off);
  void mmio_wr(int d, uint32_t off, uint32_t v);
  uint32_t mgmt_rd(int d, uint32_t off);
  void mgmt_wr(int d, uint32_t off, uint32_t v);
  void mgmt_wr_noshadow(int d, uint32_t off, uint32_t v);

  void mem_wr(uint64_t a, const void *p, size_t n);
  void mem_rd(uint64_t a, void *p, size_t n) const;
  uint64_t memsize() const { return mem_.size(); }

  Dev &dev(int d) { return *devs_[d]; }
  int ndev() const { return (int)devs_.size(); }
  bool irq(int d);
  int dma_alloc(int d, size_t size, size_t align, uint64_t *iova);
  void set_region(int d, uint64_t base, uint64_t size);
  void add_bad_sector(int d, uint64_t s);
  void wait_idle(int d, uint64_t max_cycles = 2000000);
  void wait_all_idle();
  bool engine_busy(int d);

  sfv_transport_t *tr(int d) { return &devs_[d]->tr; }
  sfv_mgmt_transport_t *mg(int d) { return &devs_[d]->mg; }

  // configuration read from the engine
  uint32_t max_qsz = 0, max_chain = 0, n_win = 0;
  uint64_t capacity = 0;

  // monitor
  int monitor_errors() const { return mon_err_; }
  std::string monitor_first() const { return mon_first_; }
  bool monitor_lenient = false;   // set while a test revokes windows under traffic

  // op-log control
  void log_nocheck(const char *why);
  // finish: write dumps, run reference model if configured; returns 0 on pass
  int finish(const std::string &refcheck_bin);

  std::mt19937_64 rng;
  static uint8_t stor_init_byte(uint64_t seed, int dev, uint64_t i);

 private:
  void bus(int d, bool mgmt, bool we, uint32_t addr, uint32_t wdata, uint32_t *rdata);
  void monitor_check(Dev &D, uint64_t addr, uint8_t be, bool we, uint16_t dom);
  void shadow_mgmt_write(Dev &D, uint32_t off, uint32_t v);
  void logf(const char *fmt, ...);

  Cfg cfg_;
  std::unique_ptr<VerilatedContext> ctx_;
  std::vector<std::unique_ptr<Dev>> devs_;
  std::vector<uint8_t> mem_;
  uint64_t cyc_ = 0;
  int mon_err_ = 0;
  std::string mon_first_;
  FILE *log_ = nullptr;
  bool nocheck_ = false;
};
