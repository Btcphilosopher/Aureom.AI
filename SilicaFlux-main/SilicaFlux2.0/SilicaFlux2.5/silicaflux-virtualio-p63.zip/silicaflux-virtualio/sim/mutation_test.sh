#!/usr/bin/env bash
# Mutation testing: inject known faults into a copy of the RTL and require the
# verification suite (directed + random, reference-model checked) to fail.
set -u
ROOT=$(cd "$(dirname "$0")/.." && pwd)
WORK=${WORK:-/tmp/sfv_mut}
REF=$ROOT/refmodel/target/release/sfv-refcheck
LIST=${1:-all}
declare -A MUT FILE
FILE[M01]=silicaflux_virtio_desc_walker.sv;    MUT[M01]="end else if (visited[idx[VW-1:0]]) begin|end else if (1'b0) begin"
FILE[M02]=silicaflux_virtio_domain_perm.sv;    MUT[M02]="(wd[i] == dom)|(1'b1)"
FILE[M03]=silicaflux_virtio_domain_perm.sv;    MUT[M03]="(hi <= wl[i])|(hi <= wl[i] + 64'd1)"
FILE[M04]=silicaflux_virtio_blk_backend.sv;    MUT[M04]="used_len <= w_len;|used_len <= w_len - 32'd1;"
FILE[M05]=silicaflux_virtio_queue_ctrl.sv;     MUT[M05]="if (rd16[0]) irq_suppressed_pulse <= 1'b1;|if (1'b0) irq_suppressed_pulse <= 1'b1;"
FILE[M06]=silicaflux_virtio_mmio_transport.sv; MUT[M06]="if (wd[3] \&\& !feat_ok_bit \&\& !feat_ok) nv[3] = 1'b0;|"
FILE[M07]=silicaflux_virtio_desc_walker.sv;    MUT[M07]="end else if (!d_flags[1] \&\& seen_w) begin|end else if (1'b0) begin"
FILE[M08]=silicaflux_virtio_blk_backend.sv;    MUT[M08]="(nsec <= (CAP - sector))|(nsec <= (CAP - sector + 64'd1))"
FILE[M09]=silicaflux_virtio_mmio_transport.sv; MUT[M09]="assign mmio_req_ready = !needs_quiesce|assign mmio_req_ready = 1'b1; wire unused_m09 = !needs_quiesce"
FILE[M10]=silicaflux_virtio_desc_walker.sv;    MUT[M10]="if ((d_len != 32'd0) \&\& !chk_ok) begin       // readable, not permitted|if (1'b0) begin"
FILE[M11]=silicaflux_virtio_queue_ctrl.sv;     MUT[M11]="if ((rd16 - last_avail) > q_size) begin|if ((rd16 - last_avail) > (q_size + 16'd1)) begin"
FILE[M12]=silicaflux_virtio_blk_backend.sv;    MUT[M12]="PH_ID:     start_phase(PH_ZERO, in_len - wpos);|PH_ID:     start_phase(PH_STATUS, 32'd1);"
FILE[M13]=silicaflux_virtio_desc_walker.sv;    MUT[M13]="end else if (count == CW'(MAX_CHAIN)) begin|end else if (count == CW'(MAX_CHAIN + 1)) begin"
FILE[M14]=silicaflux_virtio_mmio_transport.sv; MUT[M14]="(q_desc_q[3:0] == 4'd0)|(q_desc_q[2:0] == 3'd0)"
FILE[M15]=silicaflux_virtio_domain_perm.sv;    MUT[M15]="(lo >= wb[i])|(lo + 64'd1 >= wb[i])"
FILE[M16]=silicaflux_virtio_domain_perm.sv;    MUT[M16]="g_hi      = {h_addr[63:3], be_hi};|g_hi      = {h_addr[63:3], be_lo};"
keys=$(printf "%s\n" "${!MUT[@]}" | sort)
[ "$LIST" != all ] && keys="$LIST"
killed=0; survived=0
for k in $keys; do
  rm -rf "$WORK/$k"; mkdir -p "$WORK/$k"; cp -r "$ROOT/rtl" "$WORK/$k/rtl"
  f="$WORK/$k/rtl/${FILE[$k]}"; from="${MUT[$k]%%|*}"; to="${MUT[$k]#*|}"
  python3 - "$f" "$from" "$to" <<'PY'
import sys
p, a, b = sys.argv[1], sys.argv[2].replace('\\',''), sys.argv[3].replace('\\','')
s = open(p).read()
assert s.count(a) == 1, f"mutation anchor not unique/found in {p}: {a!r}"
open(p, 'w').write(s.replace(a, b))
PY
  [ $? -ne 0 ] && { echo "$k ANCHOR-ERROR"; continue; }
  RTL=$(sed "s|^|$WORK/$k/rtl/|" "$ROOT/rtl/filelist.f")
  verilator --cc --exe --build -j 2 -O1 -Wno-fatal --top-module silicaflux_virtio_engine \
    -CFLAGS "-I$ROOT/host/include -I$ROOT/sim -O1 -std=c++17" -Mdir "$WORK/$k/obj" $RTL \
    "$ROOT/sim/sim_env.cpp" "$ROOT/sim/tests_main.cpp" "$ROOT/host/src/sfv_core.c" "$ROOT/host/src/sfv_blk.c" -o tests >/dev/null 2>&1 \
    || { echo "$k BUILD-ERROR"; continue; }
  mkdir -p "$WORK/$k/out"
  "$WORK/$k/obj/tests" --outdir "$WORK/$k/out" --refcheck "$REF" --skip-long > "$WORK/$k/directed.log" 2>&1; d=$?
  "$WORK/$k/obj/tests" --outdir "$WORK/$k/out" --refcheck "$REF" --only random --seed 1 --iters 40 > "$WORK/$k/random.log" 2>&1; r=$?
  first=$(grep -m1 -E "^FAIL" "$WORK/$k/directed.log" "$WORK/$k/random.log" | sed 's/.*FAIL *//' | cut -c1-110)
  if [ $d -ne 0 ] || [ $r -ne 0 ]; then killed=$((killed+1)); echo "$k KILLED   ${FILE[$k]}: $first"
  else survived=$((survived+1)); echo "$k SURVIVED ${FILE[$k]}"; fi
done
echo "mutants killed: $killed, survived: $survived"
