/* sfv_sim.h — C ABI for the simulated transport backend (Verilator model of
 * silicaflux_virtio_engine + simulated host memory and StorageCore). Used when
 * no physical PCIe/MMIO path exists. */
#ifndef SFV_SIM_H
#define SFV_SIM_H
#include <stddef.h>
#include <stdint.h>
#include "sfvirtio.h"
#ifdef __cplusplus
extern "C" {
#endif
typedef struct sfv_sim sfv_sim_t;
sfv_sim_t *sfv_sim_create(int ndev, uint64_t memsize, uint64_t seed);
void sfv_sim_destroy(sfv_sim_t *s);
const sfv_transport_t *sfv_sim_transport(sfv_sim_t *s, int dev);
const sfv_mgmt_transport_t *sfv_sim_mgmt(sfv_sim_t *s, int dev);
void sfv_sim_set_region(sfv_sim_t *s, int dev, uint64_t base, uint64_t size);
void sfv_sim_set_latency(sfv_sim_t *s, int dev, int dma_lat, int sc_lat);
uint64_t sfv_sim_cycles(sfv_sim_t *s);
int sfv_sim_dma_escapes(sfv_sim_t *s);
#ifdef __cplusplus
}
#endif
#endif
