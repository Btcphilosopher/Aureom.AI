// =============================================================================
// silicaflux_virtio_pkg.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// VirtIO protocol package.
//
// Normative reference: OASIS "Virtual I/O Device (VIRTIO) Version 1.2",
// Committee Specification 01 (virtio-v1.2-cs01). Section numbers below refer
// to that document. Every constant marked [SPEC] is copied from the
// specification; constants marked [SFV] are SilicaFlux-internal and are never
// exposed to a guest as if they were part of VirtIO.
//
// Byte order: VirtIO 1.x structures are little-endian (spec 1.4). All DMA data
// lanes in this design are little-endian: lane i (bits 8i+7:8i) of a 64-bit
// data word carries the byte at address (word_address + i).
// =============================================================================
/* verilator lint_off UNUSEDPARAM */
package silicaflux_virtio_pkg;

  // ---------------------------------------------------------------------------
  // [SPEC] 2.1 Device Status Field
  // ---------------------------------------------------------------------------
  localparam logic [7:0] VIRTIO_STATUS_ACKNOWLEDGE        = 8'd1;
  localparam logic [7:0] VIRTIO_STATUS_DRIVER             = 8'd2;
  localparam logic [7:0] VIRTIO_STATUS_DRIVER_OK          = 8'd4;
  localparam logic [7:0] VIRTIO_STATUS_FEATURES_OK        = 8'd8;
  localparam logic [7:0] VIRTIO_STATUS_DEVICE_NEEDS_RESET = 8'd64;
  localparam logic [7:0] VIRTIO_STATUS_FAILED             = 8'd128;

  // ---------------------------------------------------------------------------
  // [SPEC] 6 Reserved Feature Bits (device-independent)
  // ---------------------------------------------------------------------------
  localparam int VIRTIO_F_INDIRECT_DESC     = 28;
  localparam int VIRTIO_F_EVENT_IDX         = 29;
  localparam int VIRTIO_F_VERSION_1         = 32;
  localparam int VIRTIO_F_ACCESS_PLATFORM   = 33;
  localparam int VIRTIO_F_RING_PACKED       = 34;
  localparam int VIRTIO_F_IN_ORDER          = 35;
  localparam int VIRTIO_F_ORDER_PLATFORM    = 36;
  localparam int VIRTIO_F_SR_IOV            = 37;
  localparam int VIRTIO_F_NOTIFICATION_DATA = 38;
  localparam int VIRTIO_F_NOTIF_CONFIG_DATA = 39;
  localparam int VIRTIO_F_RING_RESET        = 40;

  // ---------------------------------------------------------------------------
  // [SPEC] 5.2.3 Block device feature bits
  // ---------------------------------------------------------------------------
  localparam int VIRTIO_BLK_F_SIZE_MAX     = 1;
  localparam int VIRTIO_BLK_F_SEG_MAX      = 2;
  localparam int VIRTIO_BLK_F_GEOMETRY     = 4;
  localparam int VIRTIO_BLK_F_RO           = 5;
  localparam int VIRTIO_BLK_F_BLK_SIZE     = 6;
  localparam int VIRTIO_BLK_F_FLUSH        = 9;
  localparam int VIRTIO_BLK_F_TOPOLOGY     = 10;
  localparam int VIRTIO_BLK_F_CONFIG_WCE   = 11;
  localparam int VIRTIO_BLK_F_MQ           = 12;
  localparam int VIRTIO_BLK_F_DISCARD      = 13;
  localparam int VIRTIO_BLK_F_WRITE_ZEROES = 14;
  localparam int VIRTIO_BLK_F_LIFETIME     = 15;
  localparam int VIRTIO_BLK_F_SECURE_ERASE = 16;

  // ---------------------------------------------------------------------------
  // [SPEC] 2.7.5 The Virtqueue Descriptor Table (split virtqueue)
  //   struct virtq_desc { le64 addr; le32 len; le16 flags; le16 next; }  16 B
  // [SPEC] 2.7.6 The Virtqueue Available Ring
  //   struct virtq_avail { le16 flags; le16 idx; le16 ring[N]; le16 used_event; }
  // [SPEC] 2.7.8 The Virtqueue Used Ring
  //   struct virtq_used { le16 flags; le16 idx; struct virtq_used_elem ring[N];
  //                       le16 avail_event; }
  //   struct virtq_used_elem { le32 id; le32 len; }  8 B
  // [SPEC] 2.7.2 Alignment: descriptor table 16, available ring 2, used ring 4
  // ---------------------------------------------------------------------------
  localparam logic [15:0] VIRTQ_DESC_F_NEXT          = 16'd1;
  localparam logic [15:0] VIRTQ_DESC_F_WRITE         = 16'd2;
  localparam logic [15:0] VIRTQ_DESC_F_INDIRECT      = 16'd4;
  localparam logic [15:0] VIRTQ_AVAIL_F_NO_INTERRUPT = 16'd1;
  localparam logic [15:0] VIRTQ_USED_F_NO_NOTIFY     = 16'd1;
  localparam int          VIRTQ_DESC_BYTES           = 16;
  localparam int          VIRTQ_USED_ELEM_BYTES      = 8;
  localparam int          VIRTQ_SPLIT_MAX_SIZE       = 32768;  // 2.7: max Queue Size

  // ---------------------------------------------------------------------------
  // [SPEC] 5.2 Block Device
  //   struct virtio_blk_req { le32 type; le32 reserved; le64 sector;
  //                           u8 data[]; u8 status; }
  // ---------------------------------------------------------------------------
  localparam logic [31:0] VIRTIO_BLK_T_IN           = 32'd0;
  localparam logic [31:0] VIRTIO_BLK_T_OUT          = 32'd1;
  localparam logic [31:0] VIRTIO_BLK_T_FLUSH        = 32'd4;
  localparam logic [31:0] VIRTIO_BLK_T_GET_ID       = 32'd8;
  localparam logic [31:0] VIRTIO_BLK_T_GET_LIFETIME = 32'd10;
  localparam logic [31:0] VIRTIO_BLK_T_DISCARD      = 32'd11;
  localparam logic [31:0] VIRTIO_BLK_T_WRITE_ZEROES = 32'd13;
  localparam logic [31:0] VIRTIO_BLK_T_SECURE_ERASE = 32'd14;
  localparam logic [7:0]  VIRTIO_BLK_S_OK           = 8'd0;
  localparam logic [7:0]  VIRTIO_BLK_S_IOERR        = 8'd1;
  localparam logic [7:0]  VIRTIO_BLK_S_UNSUPP       = 8'd2;
  localparam int          VIRTIO_BLK_ID_BYTES       = 20;
  localparam int          VIRTIO_BLK_SECTOR_BYTES   = 512;  // 5.2.6: always 512
  localparam int          VIRTIO_BLK_REQ_HDR_BYTES  = 16;
  localparam logic [31:0] VIRTIO_ID_BLOCK           = 32'd2;  // 5 Device Types

  // ---------------------------------------------------------------------------
  // [SPEC] 4.2.2 MMIO Device Register Layout (virtio-mmio, Version 2)
  // ---------------------------------------------------------------------------
  localparam logic [31:0] VIRTIO_MMIO_MAGIC   = 32'h7472_6976;  // "virt"
  localparam logic [31:0] VIRTIO_MMIO_VERSION = 32'd2;

  localparam logic [11:0] MMIO_MAGIC_VALUE         = 12'h000;
  localparam logic [11:0] MMIO_VERSION             = 12'h004;
  localparam logic [11:0] MMIO_DEVICE_ID           = 12'h008;
  localparam logic [11:0] MMIO_VENDOR_ID           = 12'h00c;
  localparam logic [11:0] MMIO_DEVICE_FEATURES     = 12'h010;
  localparam logic [11:0] MMIO_DEVICE_FEATURES_SEL = 12'h014;
  localparam logic [11:0] MMIO_DRIVER_FEATURES     = 12'h020;
  localparam logic [11:0] MMIO_DRIVER_FEATURES_SEL = 12'h024;
  localparam logic [11:0] MMIO_QUEUE_SEL           = 12'h030;
  localparam logic [11:0] MMIO_QUEUE_NUM_MAX       = 12'h034;
  localparam logic [11:0] MMIO_QUEUE_NUM           = 12'h038;
  localparam logic [11:0] MMIO_QUEUE_READY         = 12'h044;
  localparam logic [11:0] MMIO_QUEUE_NOTIFY        = 12'h050;
  localparam logic [11:0] MMIO_INTERRUPT_STATUS    = 12'h060;
  localparam logic [11:0] MMIO_INTERRUPT_ACK       = 12'h064;
  localparam logic [11:0] MMIO_STATUS              = 12'h070;
  localparam logic [11:0] MMIO_QUEUE_DESC_LOW      = 12'h080;
  localparam logic [11:0] MMIO_QUEUE_DESC_HIGH     = 12'h084;
  localparam logic [11:0] MMIO_QUEUE_DRIVER_LOW    = 12'h090;
  localparam logic [11:0] MMIO_QUEUE_DRIVER_HIGH   = 12'h094;
  localparam logic [11:0] MMIO_QUEUE_DEVICE_LOW    = 12'h0a0;
  localparam logic [11:0] MMIO_QUEUE_DEVICE_HIGH   = 12'h0a4;
  localparam logic [11:0] MMIO_SHM_SEL             = 12'h0ac;
  localparam logic [11:0] MMIO_SHM_LEN_LOW         = 12'h0b0;
  localparam logic [11:0] MMIO_SHM_LEN_HIGH        = 12'h0b4;
  localparam logic [11:0] MMIO_SHM_BASE_LOW        = 12'h0b8;
  localparam logic [11:0] MMIO_SHM_BASE_HIGH       = 12'h0bc;
  localparam logic [11:0] MMIO_QUEUE_RESET         = 12'h0c0;
  localparam logic [11:0] MMIO_CONFIG_GENERATION   = 12'h0fc;
  localparam logic [11:0] MMIO_CONFIG              = 12'h100;

  // [SPEC] 4.2.2 InterruptStatus bits
  localparam int VIRTIO_MMIO_INT_VRING  = 0;  // Used Buffer Notification
  localparam int VIRTIO_MMIO_INT_CONFIG = 1;  // Configuration Change Notification

  // [SPEC] 5.2.4 struct virtio_blk_config field offsets (relative to 0x100)
  localparam logic [11:0] BLK_CFG_CAPACITY = 12'h000;  // le64
  localparam logic [11:0] BLK_CFG_SIZE_MAX = 12'h008;  // le32
  localparam logic [11:0] BLK_CFG_SEG_MAX  = 12'h00c;  // le32

  // ---------------------------------------------------------------------------
  // [SFV] SilicaFlux engine identity and versioned management interface
  // ---------------------------------------------------------------------------
  localparam logic [31:0] SFV_ENGINE_ID      = 32'h5346_5649;  // "SFVI"
  localparam logic [7:0]  SFV_VER_MAJOR      = 8'd1;
  localparam logic [7:0]  SFV_VER_MINOR      = 8'd0;
  localparam logic [7:0]  SFV_VER_PATCH      = 8'd0;
  localparam logic [31:0] SFV_VIRTIO_VENDOR  = 32'h5846_4c53;  // "SLFX" (mmio VendorID, free-form)

  // Fatal (DEVICE_NEEDS_RESET) cause codes, reported in the management window.
  localparam logic [7:0] FC_NONE           = 8'd0;
  localparam logic [7:0] FC_QUEUE_CFG      = 8'd1;   // invalid queue config at QueueReady=1
  localparam logic [7:0] FC_NO_DOMAIN      = 8'd2;   // processing requested, no protected domain bound
  localparam logic [7:0] FC_AVAIL_IDX_JUMP = 8'd3;   // avail.idx advanced by more than Queue Size
  localparam logic [7:0] FC_RING_DMA       = 8'd4;   // permission/bus fault on desc table / avail / used ring
  localparam logic [7:0] FC_DESC_IDX_OOR   = 8'd5;   // head or next index >= Queue Size
  localparam logic [7:0] FC_CHAIN_LOOP     = 8'd6;   // descriptor revisited within one chain
  localparam logic [7:0] FC_CHAIN_TOO_LONG = 8'd7;   // more than MAX_CHAIN descriptors
  localparam logic [7:0] FC_DESC_FLAGS     = 8'd8;   // INDIRECT (not negotiated) or reserved flag bits
  localparam logic [7:0] FC_CHAIN_ORDER    = 8'd9;   // device-readable after device-writable (2.7.4.2)
  localparam logic [7:0] FC_CHAIN_LEN_OVF  = 8'd10;  // total chain length >= 2^32 (2.7.13.1)
  localparam logic [7:0] FC_WRITABLE_PERM  = 8'd11;  // device-writable buffer outside tenant permission
  localparam logic [7:0] FC_NO_STATUS      = 8'd12;  // no device-writable byte for virtio-blk status
  localparam logic [7:0] FC_DATA_WRITE_DMA = 8'd13;  // DMA fault while writing device-writable buffer

  // StorageCore backend operation codes [SFV]
  localparam logic [1:0] SC_OP_READ  = 2'd0;
  localparam logic [1:0] SC_OP_WRITE = 2'd1;
  localparam logic [1:0] SC_OP_FLUSH = 2'd2;

  // ---------------------------------------------------------------------------
  // Helpers
  // ---------------------------------------------------------------------------
  // Contiguous byte-enable mask of n (1..8) bytes starting at lane `lane`.
  function automatic logic [7:0] sfv_be(input logic [3:0] n, input logic [2:0] lane);
    logic [7:0] m;
    for (int i = 0; i < 8; i++) m[i] = (4'(i) < n);
    return m << lane;
  endfunction

  function automatic logic [3:0] sfv_min4(input logic [3:0] a, input logic [3:0] b);
    return (a < b) ? a : b;
  endfunction

endpackage
/* verilator lint_on UNUSEDPARAM */
