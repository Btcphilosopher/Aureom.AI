// =============================================================================
// silicaflux_virtio_mgmt.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Privileged management window (ControlCore / hypervisor side, never mapped to
// a guest). Provides:
//   * versioned engine identity and capability registers
//   * queue -> protected-domain binding (locked while the queue is enabled)
//   * access to the domain permission table
//   * fatal-cause / fault capture
//   * performance counters
// Register map: docs/02_register_map.md (kept in sync with sfvirtio_regs.h).
// =============================================================================
module silicaflux_virtio_mgmt
  import silicaflux_virtio_pkg::*;
#(
  parameter int N_WIN            = 8,
  parameter int MAX_QSZ          = 256,
  parameter int MAX_CHAIN        = 16,
  parameter int CAPACITY_SECTORS = 2048,
  localparam int WW = $clog2(N_WIN)
) (
  input  logic          clk,
  input  logic          rst_n,

  input  logic          mgmt_req_valid,
  output logic          mgmt_req_ready,
  input  logic          mgmt_req_we,
  input  logic [11:0]   mgmt_req_addr,
  input  logic [31:0]   mgmt_req_wdata,
  output logic          mgmt_resp_valid,
  output logic [31:0]   mgmt_resp_rdata,

  input  logic          q_ready,
  output logic [15:0]   domain,
  output logic          domain_valid,

  output logic          cfg_we,
  output logic [WW-1:0] cfg_win,
  output logic [2:0]    cfg_field,
  output logic [31:0]   cfg_wdata,
  output logic [WW-1:0] cfg_rwin,
  output logic [2:0]    cfg_rfield,
  input  logic [31:0]   cfg_rdata,

  input  logic          engine_busy,
  input  logic          dev_active,
  input  logic          needs_reset,
  input  logic [7:0]    dev_status,
  input  logic          fatal_pulse,
  input  logic [7:0]    fatal_cause,
  input  logic          viol_dma_pulse,
  input  logic [63:0]   viol_dma_addr,
  input  logic          viol_dma_write,
  input  logic          viol_walk_pulse,
  input  logic [63:0]   viol_walk_addr,

  input  logic          desc_pulse,
  input  logic          req_done_pulse,
  input  logic          head_pulse,
  input  logic [16:0]   head_depth,
  input  logic          walk_busy,
  input  logic          dma_rd_beat,
  input  logic          dma_wr_beat,
  input  logic [3:0]    dma_beat_bytes,
  input  logic          irq_raised_pulse,
  input  logic          irq_suppressed_pulse,
  input  logic          notify_pulse,
  input  logic          stall,
  input  logic          ioerr_pulse,
  input  logic          unsupp_pulse
);

  // ---------------------------------------------------------------------------
  // Register offsets
  // ---------------------------------------------------------------------------
  localparam logic [11:0] R_ENGINE_ID     = 12'h000;
  localparam logic [11:0] R_ENGINE_VER    = 12'h004;
  localparam logic [11:0] R_CAPS0         = 12'h008;
  localparam logic [11:0] R_CAPS1         = 12'h00c;
  localparam logic [11:0] R_Q0_DOMAIN     = 12'h010;
  localparam logic [11:0] R_ENGINE_STATUS = 12'h014;
  localparam logic [11:0] R_FAULT_LO      = 12'h018;
  localparam logic [11:0] R_FAULT_HI      = 12'h01c;
  localparam logic [11:0] R_FAULT_INFO    = 12'h020;
  localparam logic [11:0] R_CAP_LO        = 12'h024;
  localparam logic [11:0] R_CAP_HI        = 12'h028;
  localparam logic [11:0] R_PERF_CTRL     = 12'h030;
  localparam logic [11:0] R_WIN_BASE      = 12'h040;   // + 0x20*i + 4*field
  localparam logic [11:0] R_PERF_BASE     = 12'h200;

  // ---------------------------------------------------------------------------
  // Domain binding
  // ---------------------------------------------------------------------------
  logic        dom_wr_ignored;
  logic [7:0]  last_cause;
  logic [63:0] fault_addr;
  logic        fault_write, fault_valid;

  // ---------------------------------------------------------------------------
  // Performance counters
  // ---------------------------------------------------------------------------
  logic [31:0] c_desc, c_req, c_irq, c_irq_sup, c_stall_lo, c_viol, c_qd_max, c_qd_n;
  logic [31:0] c_notify, c_fatal, c_ioerr, c_unsupp, c_clat_max, c_wlat_max;
  logic [63:0] c_rd_bytes, c_wr_bytes, c_clat_sum, c_wlat_sum, c_qd_sum, c_busy, c_total;
  logic [31:0] cur_clat, cur_wlat;
  logic        in_req, walk_busy_d;

  wire wr = mgmt_req_valid && mgmt_req_we;
  wire [11:0] a = mgmt_req_addr;
  wire in_win = (a >= R_WIN_BASE) && (a < (R_WIN_BASE + 12'(32 * N_WIN)));
  wire [11:0] wofs = a - R_WIN_BASE;

  assign mgmt_req_ready = 1'b1;

  assign cfg_we     = wr && in_win && (wofs[4:2] <= 3'd5);
  assign cfg_win    = WW'(wofs >> 5);
  assign cfg_field  = wofs[4:2];
  assign cfg_wdata  = mgmt_req_wdata;
  assign cfg_rwin   = WW'(wofs >> 5);
  assign cfg_rfield = wofs[4:2];

  logic [31:0] rdata;
  always_comb begin
    rdata = 32'd0;
    if (in_win) begin
      rdata = cfg_rdata;
    end else begin
      case (a)
        R_ENGINE_ID:     rdata = SFV_ENGINE_ID;
        R_ENGINE_VER:    rdata = {8'd0, SFV_VER_MAJOR, SFV_VER_MINOR, SFV_VER_PATCH};
        // CAPS0: [7:0] queues, [15:8] MAX_CHAIN, [23:16] N_WIN, [24] split ring,
        //        [25] packed ring, [26] indirect, [27] event_idx, [28] multiqueue,
        //        [29] permission table, [30] external IOMMU port
        R_CAPS0:         rdata = {1'b0, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1,
                                  8'(N_WIN), 8'(MAX_CHAIN), 8'd1};
        R_CAPS1:         rdata = {VIRTIO_ID_BLOCK[7:0], 8'd0, 16'(MAX_QSZ)};
        R_Q0_DOMAIN:     rdata = {domain_valid, 15'd0, domain};
        // [0] busy [1] active [2] needs_reset [3] domain write ignored
        // [15:8] last fatal cause [23:16] device status
        R_ENGINE_STATUS: rdata = {8'd0, dev_status, last_cause, 4'd0, dom_wr_ignored, needs_reset, dev_active, engine_busy};
        R_FAULT_LO:      rdata = fault_addr[31:0];
        R_FAULT_HI:      rdata = fault_addr[63:32];
        R_FAULT_INFO:    rdata = {16'd0, 14'd0, fault_valid, fault_write};
        R_CAP_LO:        rdata = 32'(CAPACITY_SECTORS);
        R_CAP_HI:        rdata = 32'd0;
        R_PERF_BASE + 12'h000: rdata = c_desc;
        R_PERF_BASE + 12'h004: rdata = c_req;
        R_PERF_BASE + 12'h008: rdata = c_rd_bytes[31:0];
        R_PERF_BASE + 12'h00c: rdata = c_rd_bytes[63:32];
        R_PERF_BASE + 12'h010: rdata = c_wr_bytes[31:0];
        R_PERF_BASE + 12'h014: rdata = c_wr_bytes[63:32];
        R_PERF_BASE + 12'h018: rdata = c_clat_sum[31:0];
        R_PERF_BASE + 12'h01c: rdata = c_clat_sum[63:32];
        R_PERF_BASE + 12'h020: rdata = c_clat_max;
        R_PERF_BASE + 12'h024: rdata = c_wlat_sum[31:0];
        R_PERF_BASE + 12'h028: rdata = c_wlat_sum[63:32];
        R_PERF_BASE + 12'h02c: rdata = c_wlat_max;
        R_PERF_BASE + 12'h030: rdata = c_irq;
        R_PERF_BASE + 12'h034: rdata = c_irq_sup;
        R_PERF_BASE + 12'h038: rdata = c_stall_lo;
        R_PERF_BASE + 12'h03c: rdata = c_viol;
        R_PERF_BASE + 12'h040: rdata = c_qd_sum[31:0];
        R_PERF_BASE + 12'h044: rdata = c_qd_sum[63:32];
        R_PERF_BASE + 12'h048: rdata = c_qd_max;
        R_PERF_BASE + 12'h04c: rdata = c_qd_n;
        R_PERF_BASE + 12'h050: rdata = c_notify;
        R_PERF_BASE + 12'h054: rdata = c_fatal;
        R_PERF_BASE + 12'h058: rdata = c_busy[31:0];
        R_PERF_BASE + 12'h05c: rdata = c_busy[63:32];
        R_PERF_BASE + 12'h060: rdata = c_total[31:0];
        R_PERF_BASE + 12'h064: rdata = c_total[63:32];
        R_PERF_BASE + 12'h068: rdata = c_ioerr;
        R_PERF_BASE + 12'h06c: rdata = c_unsupp;
        default:         rdata = 32'd0;
      endcase
    end
  end

  wire perf_clear = wr && (a == R_PERF_CTRL) && mgmt_req_wdata[0];
  wire flag_clear = wr && (a == R_PERF_CTRL) && mgmt_req_wdata[1];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mgmt_resp_valid <= 1'b0;
      mgmt_resp_rdata <= '0;
      domain          <= '0;
      domain_valid    <= 1'b0;
      dom_wr_ignored  <= 1'b0;
      last_cause      <= FC_NONE;
      fault_addr      <= '0;
      fault_write     <= 1'b0;
      fault_valid     <= 1'b0;
    end else begin
      mgmt_resp_valid <= mgmt_req_valid;
      mgmt_resp_rdata <= (mgmt_req_valid && !mgmt_req_we) ? rdata : 32'd0;

      if (wr && (a == R_Q0_DOMAIN)) begin
        if (!q_ready) begin
          domain       <= mgmt_req_wdata[15:0];
          domain_valid <= mgmt_req_wdata[31];
        end else begin
          dom_wr_ignored <= 1'b1;     // binding is locked while the queue is live
        end
      end
      if (flag_clear) dom_wr_ignored <= 1'b0;

      if (fatal_pulse) last_cause <= fatal_cause;
      if (viol_dma_pulse) begin
        fault_addr  <= viol_dma_addr;
        fault_write <= viol_dma_write;
        fault_valid <= 1'b1;
      end else if (viol_walk_pulse) begin
        fault_addr  <= viol_walk_addr;
        fault_write <= 1'b0;
        fault_valid <= 1'b1;
      end
      if (flag_clear) fault_valid <= 1'b0;
    end
  end

  // ---------------------------------------------------------------------------
  // Counters
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      {c_desc, c_req, c_irq, c_irq_sup, c_stall_lo, c_viol, c_qd_max, c_qd_n} <= '0;
      {c_notify, c_fatal, c_ioerr, c_unsupp, c_clat_max, c_wlat_max}          <= '0;
      {c_rd_bytes, c_wr_bytes, c_clat_sum, c_wlat_sum, c_qd_sum, c_busy, c_total} <= '0;
      cur_clat    <= '0;
      cur_wlat    <= '0;
      in_req      <= 1'b0;
      walk_busy_d <= 1'b0;
    end else if (perf_clear) begin
      {c_desc, c_req, c_irq, c_irq_sup, c_stall_lo, c_viol, c_qd_max, c_qd_n} <= '0;
      {c_notify, c_fatal, c_ioerr, c_unsupp, c_clat_max, c_wlat_max}          <= '0;
      {c_rd_bytes, c_wr_bytes, c_clat_sum, c_wlat_sum, c_qd_sum, c_busy, c_total} <= '0;
      cur_clat    <= '0;
      cur_wlat    <= '0;
      in_req      <= 1'b0;
      walk_busy_d <= 1'b0;
    end else begin
      c_total <= c_total + 64'd1;
      if (engine_busy) c_busy <= c_busy + 64'd1;
      if (stall)       c_stall_lo <= c_stall_lo + 32'd1;
      if (desc_pulse)  c_desc <= c_desc + 32'd1;
      if (req_done_pulse) c_req <= c_req + 32'd1;
      if (irq_raised_pulse)     c_irq     <= c_irq + 32'd1;
      if (irq_suppressed_pulse) c_irq_sup <= c_irq_sup + 32'd1;
      if (notify_pulse) c_notify <= c_notify + 32'd1;
      if (fatal_pulse)  c_fatal  <= c_fatal + 32'd1;
      if (ioerr_pulse)  c_ioerr  <= c_ioerr + 32'd1;
      if (unsupp_pulse) c_unsupp <= c_unsupp + 32'd1;
      c_viol <= c_viol + {31'd0, viol_dma_pulse} + {31'd0, viol_walk_pulse};
      if (dma_rd_beat) c_rd_bytes <= c_rd_bytes + {60'd0, dma_beat_bytes};
      if (dma_wr_beat) c_wr_bytes <= c_wr_bytes + {60'd0, dma_beat_bytes};

      // queue depth observed at each head fetch
      if (head_pulse) begin
        c_qd_sum <= c_qd_sum + {47'd0, head_depth};
        c_qd_n   <= c_qd_n + 32'd1;
        if ({15'd0, head_depth} > c_qd_max) c_qd_max <= {15'd0, head_depth};
      end

      // completion latency: head fetched -> used.idx published
      if (head_pulse) begin
        in_req   <= 1'b1;
        cur_clat <= 32'd1;
      end else if (in_req) begin
        cur_clat <= cur_clat + 32'd1;
      end
      if (req_done_pulse && in_req) begin
        in_req     <= 1'b0;
        c_clat_sum <= c_clat_sum + {32'd0, cur_clat};
        if (cur_clat > c_clat_max) c_clat_max <= cur_clat;
      end
      if (fatal_pulse) in_req <= 1'b0;

      // descriptor-walk latency
      walk_busy_d <= walk_busy;
      if (walk_busy) begin
        cur_wlat   <= cur_wlat + 32'd1;
        c_wlat_sum <= c_wlat_sum + 64'd1;
      end else if (walk_busy_d) begin
        if (cur_wlat > c_wlat_max) c_wlat_max <= cur_wlat;
        cur_wlat <= '0;
      end
    end
  end

endmodule
