// =============================================================================
// silicaflux_virtio_engine.sv               (PRIMARY RTL — SilicaFlux Project 63)
// Aureom.AI | SilicaFlux-CLOUD | VIRTUALIO — Virtual Machine I/O Acceleration
//
// Synthesizable VirtIO block-device engine for the SilicaFlux CloudDPU.
//
//   guest driver --MMIO--> [mmio_transport] --q cfg / notify--> [queue_ctrl]
//                                                                 |   |
//                                         [desc_walker] <--head---+   +--> [blk_backend] --> StorageCore
//                                              |  (pre-check)                  |
//   host memory <-- [domain_perm gate] <-- [dma_arb] <-- qc / walker / backend
//   hypervisor  --MGMT--> [mgmt] : domain binding, permission table, counters
//
// Scope of v1.0 (see docs/03_conformance_checklist.md):
//   * virtio-blk (device ID 2) over virtio-mmio v2, one split virtqueue
//   * offered features: VERSION_1, ACCESS_PLATFORM, BLK_F_SEG_MAX, BLK_F_FLUSH
//   * NOT offered: RING_PACKED, INDIRECT_DESC, EVENT_IDX, IN_ORDER, MQ, ...
//   * every host-memory access is checked against the tenant permission table
// =============================================================================
module silicaflux_virtio_engine
  import silicaflux_virtio_pkg::*;
#(
  parameter int           MAX_QSZ          = 256,    // QueueNumMax (power of two, <= 32768)
  parameter int           MAX_CHAIN        = 16,     // descriptors per chain (power of two)
  parameter int           N_WIN            = 8,      // permission windows (power of two)
  parameter int           CAPACITY_SECTORS = 2048,   // exported capacity, 512-byte sectors
  parameter int           SADDR_W          = 32,     // StorageCore byte-address width
  parameter logic [159:0] BLK_ID           = "SILICAFLUX-VBLK-0001"
) (
  input  logic               clk,
  input  logic               rst_n,

  // ---- guest-visible VirtIO MMIO window (4 KiB) ---------------------------------
  input  logic               mmio_req_valid,
  output logic               mmio_req_ready,
  input  logic               mmio_req_we,
  input  logic [11:0]        mmio_req_addr,
  input  logic [31:0]        mmio_req_wdata,
  input  logic [3:0]         mmio_req_be,
  output logic               mmio_resp_valid,
  output logic [31:0]        mmio_resp_rdata,
  output logic               irq,

  // ---- privileged management window (ControlCore / hypervisor) ------------------
  input  logic               mgmt_req_valid,
  output logic               mgmt_req_ready,
  input  logic               mgmt_req_we,
  input  logic [11:0]        mgmt_req_addr,
  input  logic [31:0]        mgmt_req_wdata,
  output logic               mgmt_resp_valid,
  output logic [31:0]        mgmt_resp_rdata,

  // ---- host-memory DMA master (already permission-checked) ----------------------
  output logic               dma_req_valid,
  input  logic               dma_req_ready,
  output logic [63:0]        dma_req_addr,
  output logic               dma_req_we,
  output logic [63:0]        dma_req_wdata,
  output logic [7:0]         dma_req_be,
  output logic [15:0]        dma_req_domain,
  input  logic               dma_resp_valid,
  input  logic [63:0]        dma_resp_rdata,
  input  logic               dma_resp_err,

  // ---- StorageCore backend port ---------------------------------------------------
  output logic               sc_req_valid,
  input  logic               sc_req_ready,
  output logic [1:0]         sc_req_op,
  output logic [SADDR_W-1:0] sc_req_addr,
  output logic [63:0]        sc_req_wdata,
  output logic [7:0]         sc_req_be,
  input  logic               sc_resp_valid,
  input  logic [63:0]        sc_resp_rdata,
  input  logic               sc_resp_err
);

  localparam int SW = $clog2(MAX_CHAIN);
  localparam int CW = $clog2(MAX_CHAIN + 1);
  localparam int WW = $clog2(N_WIN);

  // synthesis-time parameter checks
  initial begin
    if ((MAX_QSZ & (MAX_QSZ - 1)) != 0 || MAX_QSZ > VIRTQ_SPLIT_MAX_SIZE || MAX_QSZ < 2)
      $error("MAX_QSZ must be a power of two in [2, 32768]");
    if ((MAX_CHAIN & (MAX_CHAIN - 1)) != 0 || MAX_CHAIN < 4)
      $error("MAX_CHAIN must be a power of two >= 4");
    if ((N_WIN & (N_WIN - 1)) != 0 || N_WIN < 2)
      $error("N_WIN must be a power of two >= 2");
    if (64'(CAPACITY_SECTORS) * 512 > (64'd1 << SADDR_W))
      $error("CAPACITY_SECTORS*512 must fit in SADDR_W bits");
  end

  // ---------------------------------------------------------------------------
  // Interconnect
  // ---------------------------------------------------------------------------
  logic        abort, engine_idle, eng_fatal_pulse, cfg_fatal_pulse, reset_pulse;
  logic        q_ready, dev_active, notify_pulse, needs_reset;
  logic [15:0] q_size;
  logic [63:0] q_desc, q_driver, q_device, drv_features;
  logic [7:0]  dev_status;
  logic [15:0] domain;
  logic        domain_valid;

  // queue controller <-> walker/backend
  logic        walk_start, walk_busy, walk_done, walk_fatal;
  logic [15:0] walk_head;
  logic [7:0]  walk_cause;
  logic        exec_start, exec_busy, exec_done, exec_fatal;
  logic [7:0]  exec_cause;
  logic [31:0] exec_used_len;
  logic [7:0]  exec_status;
  logic        qc_idle, qc_fatal_pulse;
  logic [7:0]  qc_fatal_cause;
  logic        used_irq_pulse, irq_sup_pulse, req_done_pulse, head_pulse, ring_fault_pulse;
  logic [16:0] head_depth;

  // walker results
  logic [CW-1:0] n_r, n_w;
  logic [31:0]   r_len, w_len;
  logic          r_fault;
  logic [SW-1:0] seg_rd_idx;
  logic [63:0]   seg_rd_addr;
  logic [31:0]   seg_rd_len;
  logic [63:0]   chk_addr;
  logic [31:0]   chk_len;
  logic          chk_write, chk_ok;
  logic          walk_viol_pulse, desc_pulse, walk_fault_pulse;
  logic [63:0]   walk_fault_addr;

  // DMA clients: 0 = queue ctrl, 1 = walker, 2 = backend
  logic [2:0]        c_req_valid, c_req_ready, c_req_we, c_resp_valid;
  logic [3*64-1:0]   c_req_addr, c_req_wdata;
  logic [3*8-1:0]    c_req_be;
  logic [63:0]       c_resp_rdata;
  logic              c_resp_err;
  logic              arb_busy;

  logic              m_req_valid, m_req_ready, m_req_we, m_resp_valid, m_resp_err;
  logic [63:0]       m_req_addr, m_req_wdata, m_resp_rdata;
  logic [7:0]        m_req_be;

  // permission table cfg
  logic          cfg_we;
  logic [WW-1:0] cfg_win, cfg_rwin;
  logic [2:0]    cfg_field, cfg_rfield;
  logic [31:0]   cfg_wdata, cfg_rdata;
  logic          viol_dma_pulse, viol_dma_write;
  logic [63:0]   viol_dma_addr;

  // ---------------------------------------------------------------------------
  // Transport
  // ---------------------------------------------------------------------------
  silicaflux_virtio_mmio_transport #(
    .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN), .CAPACITY_SECTORS(CAPACITY_SECTORS)
  ) u_transport (
    .clk, .rst_n,
    .mmio_req_valid, .mmio_req_ready, .mmio_req_we, .mmio_req_addr, .mmio_req_wdata,
    .mmio_req_be, .mmio_resp_valid, .mmio_resp_rdata, .irq,
    .engine_idle, .abort, .eng_fatal_pulse, .used_irq_pulse, .cfg_fatal_pulse, .reset_pulse,
    .q_ready, .q_size, .q_desc, .q_driver, .q_device, .dev_active, .notify_pulse,
    .drv_features, .needs_reset, .dev_status
  );

  // ---------------------------------------------------------------------------
  // Queue controller
  // ---------------------------------------------------------------------------
  silicaflux_virtio_queue_ctrl u_qc (
    .clk, .rst_n,
    .q_ready, .q_size, .q_driver, .q_device, .dev_active, .domain_valid,
    .notify(notify_pulse), .abort,
    .idle(qc_idle), .fatal_pulse(qc_fatal_pulse), .fatal_cause(qc_fatal_cause),
    .walk_start, .walk_head, .walk_busy, .walk_done, .walk_fatal, .walk_cause,
    .exec_start, .exec_busy, .exec_done, .exec_fatal, .exec_cause, .exec_used_len,
    .used_irq_pulse, .irq_suppressed_pulse(irq_sup_pulse), .req_done_pulse,
    .head_pulse, .head_depth, .ring_fault_pulse,
    .dma_req_valid (c_req_valid[0]),       .dma_req_ready (c_req_ready[0]),
    .dma_req_addr  (c_req_addr[0*64 +: 64]), .dma_req_we  (c_req_we[0]),
    .dma_req_wdata (c_req_wdata[0*64 +: 64]), .dma_req_be (c_req_be[0*8 +: 8]),
    .dma_resp_valid(c_resp_valid[0]),      .dma_resp_rdata(c_resp_rdata),
    .dma_resp_err  (c_resp_err)
  );

  // ---------------------------------------------------------------------------
  // Descriptor walker
  // ---------------------------------------------------------------------------
  silicaflux_virtio_desc_walker #(.MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN)) u_walker (
    .clk, .rst_n,
    .start(walk_start), .head(walk_head), .q_size, .q_desc, .abort,
    .busy(walk_busy), .done(walk_done), .fatal(walk_fatal), .cause(walk_cause),
    .n_r, .n_w, .r_len, .w_len, .r_fault,
    .seg_rd_idx, .seg_rd_addr, .seg_rd_len,
    .chk_addr, .chk_len, .chk_write, .chk_ok,
    .perm_viol_pulse(walk_viol_pulse), .desc_pulse,
    .fault_pulse(walk_fault_pulse), .fault_addr(walk_fault_addr),
    .dma_req_valid (c_req_valid[1]),       .dma_req_ready (c_req_ready[1]),
    .dma_req_addr  (c_req_addr[1*64 +: 64]), .dma_req_we  (c_req_we[1]),
    .dma_req_wdata (c_req_wdata[1*64 +: 64]), .dma_req_be (c_req_be[1*8 +: 8]),
    .dma_resp_valid(c_resp_valid[1]),      .dma_resp_rdata(c_resp_rdata),
    .dma_resp_err  (c_resp_err)
  );

  // ---------------------------------------------------------------------------
  // virtio-blk backend
  // ---------------------------------------------------------------------------
  silicaflux_virtio_blk_backend #(
    .MAX_CHAIN(MAX_CHAIN), .CAPACITY_SECTORS(CAPACITY_SECTORS), .SADDR_W(SADDR_W), .BLK_ID(BLK_ID)
  ) u_backend (
    .clk, .rst_n,
    .start(exec_start), .abort, .feat_flush(drv_features[VIRTIO_BLK_F_FLUSH]),
    .busy(exec_busy), .done(exec_done), .fatal(exec_fatal), .cause(exec_cause),
    .used_len(exec_used_len), .status_out(exec_status),
    .n_r, .n_w, .r_len, .w_len, .r_fault, .seg_rd_idx, .seg_rd_addr, .seg_rd_len,
    .dma_req_valid (c_req_valid[2]),       .dma_req_ready (c_req_ready[2]),
    .dma_req_addr  (c_req_addr[2*64 +: 64]), .dma_req_we  (c_req_we[2]),
    .dma_req_wdata (c_req_wdata[2*64 +: 64]), .dma_req_be (c_req_be[2*8 +: 8]),
    .dma_resp_valid(c_resp_valid[2]),      .dma_resp_rdata(c_resp_rdata),
    .dma_resp_err  (c_resp_err),
    .sc_req_valid, .sc_req_ready, .sc_req_op, .sc_req_addr, .sc_req_wdata, .sc_req_be,
    .sc_resp_valid, .sc_resp_rdata, .sc_resp_err
  );

  // ---------------------------------------------------------------------------
  // DMA arbiter and domain permission gate
  // ---------------------------------------------------------------------------
  silicaflux_virtio_dma_arb #(.N(3)) u_arb (
    .clk, .rst_n,
    .c_req_valid, .c_req_ready, .c_req_addr, .c_req_we, .c_req_wdata, .c_req_be,
    .c_resp_valid, .c_resp_rdata, .c_resp_err,
    .m_req_valid, .m_req_ready, .m_req_addr, .m_req_we, .m_req_wdata, .m_req_be,
    .m_resp_valid, .m_resp_rdata, .m_resp_err,
    .busy(arb_busy)
  );

  silicaflux_virtio_domain_perm #(.N_WIN(N_WIN)) u_perm (
    .clk, .rst_n,
    .cfg_we, .cfg_win, .cfg_field, .cfg_wdata, .cfg_rwin, .cfg_rfield, .cfg_rdata,
    .domain, .domain_valid,
    .chk_addr, .chk_len, .chk_write, .chk_ok,
    .up_req_valid(m_req_valid), .up_req_ready(m_req_ready), .up_req_addr(m_req_addr),
    .up_req_we(m_req_we), .up_req_wdata(m_req_wdata), .up_req_be(m_req_be),
    .up_resp_valid(m_resp_valid), .up_resp_rdata(m_resp_rdata), .up_resp_err(m_resp_err),
    .dn_req_valid(dma_req_valid), .dn_req_ready(dma_req_ready), .dn_req_addr(dma_req_addr),
    .dn_req_we(dma_req_we), .dn_req_wdata(dma_req_wdata), .dn_req_be(dma_req_be),
    .dn_req_domain(dma_req_domain),
    .dn_resp_valid(dma_resp_valid), .dn_resp_rdata(dma_resp_rdata), .dn_resp_err(dma_resp_err),
    .viol_pulse(viol_dma_pulse), .viol_addr(viol_dma_addr), .viol_write(viol_dma_write)
  );

  // ---------------------------------------------------------------------------
  // Engine-level status
  // ---------------------------------------------------------------------------
  assign engine_idle     = qc_idle && !walk_busy && !exec_busy && !arb_busy && !c_req_valid[0];
  assign eng_fatal_pulse = qc_fatal_pulse;   // walker/backend fatals are routed through qc

  // the selected fatal cause for the management window
  wire        any_fatal   = qc_fatal_pulse || cfg_fatal_pulse;
  wire [7:0]  any_cause   = qc_fatal_pulse ? qc_fatal_cause : FC_QUEUE_CFG;

  // DMA beat accounting at the protected (downstream) interface
  logic [3:0] beat_bytes;
  always_comb begin
    beat_bytes = 4'd0;
    for (int i = 0; i < 8; i++) beat_bytes = beat_bytes + {3'd0, dma_req_be[i]};
  end
  wire dn_acc = dma_req_valid && dma_req_ready;

  wire stall = (dma_req_valid && !dma_req_ready) || (sc_req_valid && !sc_req_ready);

  silicaflux_virtio_mgmt #(
    .N_WIN(N_WIN), .MAX_QSZ(MAX_QSZ), .MAX_CHAIN(MAX_CHAIN), .CAPACITY_SECTORS(CAPACITY_SECTORS)
  ) u_mgmt (
    .clk, .rst_n,
    .mgmt_req_valid, .mgmt_req_ready, .mgmt_req_we, .mgmt_req_addr, .mgmt_req_wdata,
    .mgmt_resp_valid, .mgmt_resp_rdata,
    .q_ready, .domain, .domain_valid,
    .cfg_we, .cfg_win, .cfg_field, .cfg_wdata, .cfg_rwin, .cfg_rfield, .cfg_rdata,
    .engine_busy(!engine_idle), .dev_active, .needs_reset, .dev_status,
    .fatal_pulse(any_fatal), .fatal_cause(any_cause),
    .viol_dma_pulse, .viol_dma_addr, .viol_dma_write,
    .viol_walk_pulse(walk_viol_pulse), .viol_walk_addr(walk_fault_addr),
    .desc_pulse, .req_done_pulse, .head_pulse, .head_depth, .walk_busy,
    .dma_rd_beat(dn_acc && !dma_req_we), .dma_wr_beat(dn_acc && dma_req_we),
    .dma_beat_bytes(beat_bytes),
    .irq_raised_pulse(used_irq_pulse), .irq_suppressed_pulse(irq_sup_pulse),
    .notify_pulse, .stall,
    .ioerr_pulse (req_done_pulse && (exec_status == VIRTIO_BLK_S_IOERR)),
    .unsupp_pulse(req_done_pulse && (exec_status == VIRTIO_BLK_S_UNSUPP))
  );

  // unused observability taps
  logic unused_ok;
  assign unused_ok = ^{reset_pulse, ring_fault_pulse, walk_fault_pulse};

endmodule
