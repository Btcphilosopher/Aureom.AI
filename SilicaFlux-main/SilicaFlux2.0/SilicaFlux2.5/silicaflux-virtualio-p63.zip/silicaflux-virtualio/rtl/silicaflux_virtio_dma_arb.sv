// =============================================================================
// silicaflux_virtio_dma_arb.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Fixed-priority DMA arbiter (client 0 highest). Exactly one request may be
// outstanding at a time; the response is routed back to the client that owns
// it. Single-outstanding is deliberate for v1: it makes response ordering and
// reset draining trivially correct. Throughput impact is measured by the
// performance counters and documented in docs/06_performance.md.
//
// Client buses are flattened: client i occupies bits [i*W +: W].
// =============================================================================
module silicaflux_virtio_dma_arb #(
  parameter int N = 3
) (
  input  logic              clk,
  input  logic              rst_n,

  input  logic [N-1:0]      c_req_valid,
  output logic [N-1:0]      c_req_ready,
  input  logic [N*64-1:0]   c_req_addr,
  input  logic [N-1:0]      c_req_we,
  input  logic [N*64-1:0]   c_req_wdata,
  input  logic [N*8-1:0]    c_req_be,
  output logic [N-1:0]      c_resp_valid,
  output logic [63:0]       c_resp_rdata,   // broadcast; qualified by c_resp_valid
  output logic              c_resp_err,

  output logic              m_req_valid,
  input  logic              m_req_ready,
  output logic [63:0]       m_req_addr,
  output logic              m_req_we,
  output logic [63:0]       m_req_wdata,
  output logic [7:0]        m_req_be,
  input  logic              m_resp_valid,
  input  logic [63:0]       m_resp_rdata,
  input  logic              m_resp_err,

  output logic              busy             // a request is outstanding
);

  localparam int IW = (N > 1) ? $clog2(N) : 1;

  logic          outstanding;
  logic [IW-1:0] owner;
  logic [IW-1:0] gnt;
  logic          any;

  always_comb begin
    any = 1'b0;
    gnt = '0;
    for (int i = N - 1; i >= 0; i--) begin
      if (c_req_valid[i]) begin
        any = 1'b1;
        gnt = IW'(i);
      end
    end
  end

  assign m_req_valid = any && !outstanding;
  assign m_req_addr  = c_req_addr [gnt*64 +: 64];
  assign m_req_we    = c_req_we   [gnt];
  assign m_req_wdata = c_req_wdata[gnt*64 +: 64];
  assign m_req_be    = c_req_be   [gnt*8 +: 8];

  always_comb begin
    c_req_ready = '0;
    if (!outstanding && any) c_req_ready[gnt] = m_req_ready;
    c_resp_valid = '0;
    if (outstanding) c_resp_valid[owner] = m_resp_valid;
  end
  assign c_resp_rdata = m_resp_rdata;
  assign c_resp_err   = m_resp_err;
  assign busy         = outstanding;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      outstanding <= 1'b0;
      owner       <= '0;
    end else begin
      if (!outstanding && m_req_valid && m_req_ready) begin
        outstanding <= 1'b1;
        owner       <= gnt;
      end else if (outstanding && m_resp_valid) begin
        outstanding <= 1'b0;
      end
    end
  end

endmodule
