// =============================================================================
// silicaflux_virtio_blk_backend.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// virtio-blk request execution (spec 5.2.6) over the StorageCore port.
//
// Message framing (spec 2.6.4 / 2.7.4): the device makes no assumption about
// how the driver splits a request across descriptors. The chain is treated as
// two byte streams:
//   R = concatenation of device-readable segments
//       [ 0..15 ] struct virtio_blk_req header  { le32 type; le32 reserved; le64 sector; }
//       [16.. ) ] OUT payload
//   W = concatenation of device-writable segments
//       [ 0..W-2] IN payload / GET_ID string
//       [ W-1   ] status byte
//
// Completion contract (spec 2.7.8.2: "the device MUST write at least len
// bytes ... beginning at the first device-writable buffer"): the backend
// always writes the WHOLE writable stream before completing — payload where
// there is payload, zeros elsewhere, status in the final byte — so the
// reported used length is exactly W for every completion, success or error.
//
// Supported request types: IN, OUT, FLUSH (only if VIRTIO_BLK_F_FLUSH was
// negotiated), GET_ID. Every other type completes with VIRTIO_BLK_S_UNSUPP.
//
// Copy engine: one step moves n <= 8 bytes and never crosses a guest segment
// boundary, a guest 8-byte word, or a storage 8-byte word. Arbitrary buffer
// alignment is therefore handled by lane shifting, at the cost of extra beats
// for misaligned buffers (measured in docs/06_performance.md).
// =============================================================================
module silicaflux_virtio_blk_backend
  import silicaflux_virtio_pkg::*;
#(
  parameter int           MAX_CHAIN        = 16,
  parameter int           CAPACITY_SECTORS = 2048,
  parameter int           SADDR_W          = 32,
  parameter logic [159:0] BLK_ID           = "SILICAFLUX-VBLK-0001",
  localparam int SW = $clog2(MAX_CHAIN),
  localparam int CW = $clog2(MAX_CHAIN + 1)
) (
  input  logic               clk,
  input  logic               rst_n,

  input  logic               start,
  input  logic               abort,
  input  logic               feat_flush,

  output logic               busy,
  output logic               done,
  output logic               fatal,
  output logic [7:0]         cause,
  output logic [31:0]        used_len,
  output logic [7:0]         status_out,

  input  logic [CW-1:0]      n_r,
  input  logic [CW-1:0]      n_w,
  input  logic [31:0]        r_len,
  input  logic [31:0]        w_len,
  input  logic               r_fault,
  output logic [SW-1:0]      seg_rd_idx,
  input  logic [63:0]        seg_rd_addr,
  input  logic [31:0]        seg_rd_len,

  output logic               dma_req_valid,
  input  logic               dma_req_ready,
  output logic [63:0]        dma_req_addr,
  output logic               dma_req_we,
  output logic [63:0]        dma_req_wdata,
  output logic [7:0]         dma_req_be,
  input  logic               dma_resp_valid,
  input  logic [63:0]        dma_resp_rdata,
  input  logic               dma_resp_err,

  output logic               sc_req_valid,
  input  logic               sc_req_ready,
  output logic [1:0]         sc_req_op,
  output logic [SADDR_W-1:0] sc_req_addr,
  output logic [63:0]        sc_req_wdata,
  output logic [7:0]         sc_req_be,
  input  logic               sc_resp_valid,
  input  logic [63:0]        sc_resp_rdata,
  input  logic               sc_resp_err
);

  localparam logic [63:0] CAP = 64'(CAPACITY_SECTORS);

  // ---------------------------------------------------------------------------
  // Phases and step states
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {PH_HDR, PH_OUT, PH_IN, PH_ID, PH_ZERO, PH_STATUS} phase_t;
  typedef enum logic [3:0] {
    B_IDLE, B_START, B_DECODE, B_FLUSH,
    X_CALC, X_SRC_DMA, X_SRC_SC, X_DST, X_DST_DMA, X_DST_SC, X_ADV
  } bstate_t;

  bstate_t       st;
  phase_t        ph;
  logic          dwait, swait;

  logic [CW-1:0] ridx, widx;          // segment cursors
  logic [31:0]   roff, woff;          // offset within current segment
  logic [31:0]   rem;                 // bytes left in phase
  logic [31:0]   k;                   // byte offset within phase (HDR / ID)
  logic [31:0]   wpos;                // bytes of W already written
  logic [SADDR_W-1:0] saddr;          // storage byte address
  /* verilator lint_off UNUSEDSIGNAL */
  logic [127:0]  hdr;                 // [63:32] 'reserved' header field is ignored
  /* verilator lint_on UNUSEDSIGNAL */
  logic [7:0]    status_q;

  // step registers
  logic [3:0]    n;
  logic [63:0]   gaddr;
  logic [63:0]   dbuf;                // payload of the step, at lane 0

  wire r_side = (ph == PH_HDR) || (ph == PH_OUT);
  /* verilator lint_off UNUSEDSIGNAL */
  wire [CW-1:0] cur_idx = r_side ? ridx : widx;   // MSB only set once the stream is exhausted
  /* verilator lint_on UNUSEDSIGNAL */
  assign seg_rd_idx = cur_idx[SW-1:0];
  wire [31:0] cur_off   = r_side ? roff : woff;

  // ---------------------------------------------------------------------------
  // Step size: min(rem, bytes to end of segment, bytes to end of guest word,
  //                bytes to end of storage word if storage is involved)
  // ---------------------------------------------------------------------------
  wire [63:0] g_now     = seg_rd_addr + {32'd0, cur_off};
  wire [31:0] seg_left  = seg_rd_len - cur_off;
  wire [3:0]  g_word    = 4'd8 - {1'b0, g_now[2:0]};
  wire [3:0]  s_word    = 4'd8 - {1'b0, saddr[2:0]};
  wire        uses_sc   = (ph == PH_OUT) || (ph == PH_IN);
  wire [3:0]  rem8      = (rem      < 32'd8) ? rem[3:0]      : 4'd8;
  wire [3:0]  seg8      = (seg_left < 32'd8) ? seg_left[3:0] : 4'd8;
  wire [3:0]  n_calc    = sfv_min4(sfv_min4(rem8, seg8), sfv_min4(g_word, uses_sc ? s_word : 4'd8));

  // ID-string bytes [k .. k+7] (zero past VIRTIO_BLK_ID_BYTES)
  function automatic logic [7:0] id_byte(input logic [31:0] j);
    if (j < 32'(VIRTIO_BLK_ID_BYTES)) return BLK_ID[(19 - j[4:0]) * 8 +: 8];
    return 8'd0;
  endfunction
  logic [63:0] id_word;
  always_comb begin
    for (int i = 0; i < 8; i++) id_word[i*8 +: 8] = id_byte(k + 32'(i));
  end

  // ---------------------------------------------------------------------------
  // Request decode helpers
  // ---------------------------------------------------------------------------
  wire [31:0] h_type   = hdr[31:0];
  wire [63:0] h_sector = hdr[127:64];
  wire [31:0] in_len   = w_len - 32'd1;
  wire [31:0] out_len  = r_len - 32'd16;
  function automatic logic range_ok(input logic [63:0] sector, input logic [31:0] len);
    logic [63:0] nsec;
    nsec = {41'd0, len[31:9]};
    return (len[8:0] == 9'd0) && (sector <= CAP) && (nsec <= (CAP - sector));
  endfunction
  wire [31:0] id_len   = (in_len < 32'(VIRTIO_BLK_ID_BYTES)) ? in_len : 32'(VIRTIO_BLK_ID_BYTES);

  // ---------------------------------------------------------------------------
  // Port drive
  // ---------------------------------------------------------------------------
  assign busy = (st != B_IDLE);

  assign dma_req_valid = ((st == X_SRC_DMA) || (st == X_DST_DMA)) && !dwait;
  assign dma_req_addr  = {gaddr[63:3], 3'b000};
  assign dma_req_we    = (st == X_DST_DMA);
  assign dma_req_be    = sfv_be(n, gaddr[2:0]);
  assign dma_req_wdata = dbuf << {gaddr[2:0], 3'b000};

  assign sc_req_valid  = ((st == X_SRC_SC) || (st == X_DST_SC) || (st == B_FLUSH)) && !swait;
  assign sc_req_op     = (st == B_FLUSH) ? SC_OP_FLUSH : ((st == X_DST_SC) ? SC_OP_WRITE : SC_OP_READ);
  assign sc_req_addr   = (st == B_FLUSH) ? '0 : {saddr[SADDR_W-1:3], 3'b000};
  assign sc_req_be     = (st == B_FLUSH) ? 8'h00 : sfv_be(n, saddr[2:0]);
  assign sc_req_wdata  = dbuf << {saddr[2:0], 3'b000};

  wire dresp = dwait && dma_resp_valid;
  wire sresp = swait && sc_resp_valid;

  assign status_out = status_q;

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  task automatic start_phase(input phase_t p, input logic [31:0] len);
    ph  <= p;
    rem <= len;
    k   <= '0;
    st  <= X_CALC;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st       <= B_IDLE;
      ph       <= PH_HDR;
      dwait    <= 1'b0;
      swait    <= 1'b0;
      ridx     <= '0;
      widx     <= '0;
      roff     <= '0;
      woff     <= '0;
      rem      <= '0;
      k        <= '0;
      wpos     <= '0;
      saddr    <= '0;
      hdr      <= '0;
      status_q <= VIRTIO_BLK_S_OK;
      n        <= '0;
      gaddr    <= '0;
      dbuf     <= '0;
      done     <= 1'b0;
      fatal    <= 1'b0;
      cause    <= FC_NONE;
      used_len <= '0;
    end else begin
      done <= 1'b0;

      if (dma_req_valid && dma_req_ready) dwait <= 1'b1;
      if (dresp) dwait <= 1'b0;
      if (sc_req_valid && sc_req_ready) swait <= 1'b1;
      if (sresp) swait <= 1'b0;

      case (st)
        // ---------------------------------------------------------------------
        B_IDLE: if (start) begin
          ridx     <= '0;
          widx     <= n_r;
          roff     <= '0;
          woff     <= '0;
          wpos     <= '0;
          hdr      <= '0;
          fatal    <= 1'b0;
          cause    <= FC_NONE;
          status_q <= VIRTIO_BLK_S_OK;
          st       <= B_START;
        end

        B_START: begin
          if (abort) begin
            st <= B_IDLE;
          end else if (n_w == '0) begin
            fatal <= 1'b1; cause <= FC_NO_STATUS; done <= 1'b1; st <= B_IDLE;
          end else if (r_fault || (r_len < 32'd16)) begin
            status_q <= VIRTIO_BLK_S_IOERR;
            start_phase(PH_ZERO, w_len - 32'd1);
          end else begin
            start_phase(PH_HDR, 32'd16);
          end
        end

        // ---------------------------------------------------------------------
        B_DECODE: begin
          if (abort) begin
            st <= B_IDLE;
          end else if (h_type == VIRTIO_BLK_T_IN) begin
            if (range_ok(h_sector, in_len)) begin
              saddr <= SADDR_W'(h_sector << 9);
              start_phase(PH_IN, in_len);
            end else begin
              status_q <= VIRTIO_BLK_S_IOERR;
              start_phase(PH_ZERO, in_len);
            end
          end else if (h_type == VIRTIO_BLK_T_OUT) begin
            if (range_ok(h_sector, out_len)) begin
              saddr <= SADDR_W'(h_sector << 9);
              start_phase(PH_OUT, out_len);
            end else begin
              status_q <= VIRTIO_BLK_S_IOERR;
              start_phase(PH_ZERO, in_len);
            end
          end else if (h_type == VIRTIO_BLK_T_FLUSH) begin
            if (feat_flush) begin
              st <= B_FLUSH;
            end else begin
              status_q <= VIRTIO_BLK_S_UNSUPP;
              start_phase(PH_ZERO, in_len);
            end
          end else if (h_type == VIRTIO_BLK_T_GET_ID) begin
            start_phase(PH_ID, id_len);
          end else begin
            status_q <= VIRTIO_BLK_S_UNSUPP;
            start_phase(PH_ZERO, in_len);
          end
        end

        B_FLUSH: if (sresp) begin
          if (sc_resp_err) status_q <= VIRTIO_BLK_S_IOERR;
          if (abort) st <= B_IDLE;
          else       start_phase(PH_ZERO, in_len);
        end

        // ---------------------------------------------------------------------
        // Copy-engine step
        // ---------------------------------------------------------------------
        X_CALC: begin
          if (abort) begin
            st <= B_IDLE;
          end else if (rem == 32'd0) begin
            // phase complete
            case (ph)
              PH_HDR:    st <= B_DECODE;
              PH_OUT,
              PH_IN,
              PH_ID:     start_phase(PH_ZERO, in_len - wpos);
              PH_ZERO:   start_phase(PH_STATUS, 32'd1);
              PH_STATUS: begin
                used_len <= w_len;
                done     <= 1'b1;
                st       <= B_IDLE;
              end
              default:   st <= B_IDLE;
            endcase
          end else begin
            n     <= n_calc;
            gaddr <= g_now;
            case (ph)
              PH_HDR, PH_OUT: st <= X_SRC_DMA;
              PH_IN:          st <= X_SRC_SC;
              PH_ID:     begin dbuf <= id_word;              st <= X_DST; end
              PH_ZERO:   begin dbuf <= 64'd0;                st <= X_DST; end
              PH_STATUS: begin dbuf <= {56'd0, status_q};    st <= X_DST; end
              default:   st <= B_IDLE;
            endcase
          end
        end

        X_SRC_DMA: if (dresp) begin
          if (dma_resp_err || abort) begin
            // readable stream unreadable: IOERR, finish the writable stream
            status_q <= VIRTIO_BLK_S_IOERR;
            if (abort) st <= B_IDLE;
            else       start_phase(PH_ZERO, in_len - wpos);
          end else begin
            dbuf <= dma_resp_rdata >> {gaddr[2:0], 3'b000};
            st   <= X_DST;
          end
        end

        X_SRC_SC: if (sresp) begin
          if (sc_resp_err || abort) begin
            status_q <= VIRTIO_BLK_S_IOERR;
            if (abort) st <= B_IDLE;
            else       start_phase(PH_ZERO, in_len - wpos);
          end else begin
            dbuf <= sc_resp_rdata >> {saddr[2:0], 3'b000};
            st   <= X_DST;
          end
        end

        X_DST: begin
          case (ph)
            PH_HDR: begin
              for (int i = 0; i < 8; i++)
                if (4'(i) < n) hdr[(k[3:0] + 4'(i)) * 8 +: 8] <= dbuf[i*8 +: 8];
              st <= X_ADV;
            end
            PH_OUT:  st <= X_DST_SC;
            default: st <= X_DST_DMA;    // IN, ID, ZERO, STATUS -> writable stream
          endcase
        end

        X_DST_DMA: if (dresp) begin
          if (dma_resp_err) begin
            fatal <= 1'b1; cause <= FC_DATA_WRITE_DMA; done <= 1'b1; st <= B_IDLE;
          end else if (abort) begin
            st <= B_IDLE;
          end else begin
            st <= X_ADV;
          end
        end

        X_DST_SC: if (sresp) begin
          if (abort) begin
            st <= B_IDLE;
          end else if (sc_resp_err) begin
            status_q <= VIRTIO_BLK_S_IOERR;
            start_phase(PH_ZERO, in_len - wpos);
          end else begin
            st <= X_ADV;
          end
        end

        X_ADV: begin
          rem   <= rem - {28'd0, n};
          k     <= k + {28'd0, n};
          saddr <= saddr + SADDR_W'(n);
          if (r_side) begin
            if ((roff + {28'd0, n}) == seg_rd_len) begin
              ridx <= ridx + 1'b1;
              roff <= '0;
            end else begin
              roff <= roff + {28'd0, n};
            end
          end else begin
            wpos <= wpos + {28'd0, n};
            if ((woff + {28'd0, n}) == seg_rd_len) begin
              widx <= widx + 1'b1;
              woff <= '0;
            end else begin
              woff <= woff + {28'd0, n};
            end
          end
          st <= X_CALC;
        end

        default: st <= B_IDLE;
      endcase
    end
  end

endmodule
