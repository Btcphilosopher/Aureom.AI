// =============================================================================
// silicaflux_virtio_desc_walker.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Split-virtqueue descriptor chain walker (spec 2.7.5, 2.7.4).
//
// For each descriptor, in this exact order (the reference model mirrors it):
//   CHECK  idx >= QueueSize                 -> fatal FC_DESC_IDX_OOR
//          idx already visited in chain      -> fatal FC_CHAIN_LOOP
//          MAX_CHAIN descriptors already     -> fatal FC_CHAIN_TOO_LONG
//   FETCH  two 8-byte reads (addr | len,flags,next); DMA error -> FC_RING_DMA
//   EVAL   flags & ~(NEXT|WRITE) != 0       -> fatal FC_DESC_FLAGS
//            (INDIRECT is rejected: VIRTIO_F_INDIRECT_DESC is not offered)
//          device-readable after writable    -> fatal FC_CHAIN_ORDER
//          running total + len >= 2^32       -> fatal FC_CHAIN_LEN_OVF
//          len > 0 and range not permitted:
//            writable -> fatal FC_WRITABLE_PERM
//            readable -> r_fault (request completes with IOERR, nothing read)
//          len > 0: append {addr,len} to the scatter-gather list
//          NEXT ? follow next : done
//
// Termination is guaranteed: a chain is bounded by MAX_CHAIN descriptors and
// by the visited bitmap (exact cycle detection within one chain).
// The SG list stores readable segments first, then writable segments
// (guaranteed by the ordering rule), exposed through a combinational read port.
// =============================================================================
module silicaflux_virtio_desc_walker
  import silicaflux_virtio_pkg::*;
#(
  parameter int MAX_QSZ   = 256,
  parameter int MAX_CHAIN = 16,
  localparam int SW = $clog2(MAX_CHAIN),
  localparam int CW = $clog2(MAX_CHAIN + 1),
  localparam int VW = $clog2(MAX_QSZ)
) (
  input  logic          clk,
  input  logic          rst_n,

  input  logic          start,
  input  logic [15:0]   head,
  input  logic [15:0]   q_size,
  input  logic [63:0]   q_desc,
  input  logic          abort,

  output logic          busy,
  output logic          done,
  output logic          fatal,
  output logic [7:0]    cause,

  output logic [CW-1:0] n_r,
  output logic [CW-1:0] n_w,
  output logic [31:0]   r_len,
  output logic [31:0]   w_len,
  output logic          r_fault,

  input  logic [SW-1:0] seg_rd_idx,
  output logic [63:0]   seg_rd_addr,
  output logic [31:0]   seg_rd_len,

  output logic [63:0]   chk_addr,
  output logic [31:0]   chk_len,
  output logic          chk_write,
  input  logic          chk_ok,

  output logic          perm_viol_pulse,
  output logic          desc_pulse,
  output logic          fault_pulse,     // ring (descriptor table) DMA fault
  output logic [63:0]   fault_addr,      // descriptor range that failed the pre-check

  output logic          dma_req_valid,
  input  logic          dma_req_ready,
  output logic [63:0]   dma_req_addr,
  output logic          dma_req_we,
  output logic [63:0]   dma_req_wdata,
  output logic [7:0]    dma_req_be,
  input  logic          dma_resp_valid,
  input  logic [63:0]   dma_resp_rdata,
  input  logic          dma_resp_err
);

  typedef enum logic [2:0] {W_IDLE, W_CHECK, W_RD0, W_RD1, W_EVAL} wstate_t;

  wstate_t       st;
  logic          dwait;
  logic [15:0]   idx;
  logic [CW-1:0] count;
  logic [MAX_QSZ-1:0] visited;
  logic          seen_w;

  logic [63:0]   d_addr;
  logic [31:0]   d_len;
  logic [15:0]   d_flags;
  logic [15:0]   d_next;

  logic [63:0]   seg_addr [MAX_CHAIN];
  logic [31:0]   seg_len  [MAX_CHAIN];

  assign seg_rd_addr = seg_addr[seg_rd_idx];
  assign seg_rd_len  = seg_len[seg_rd_idx];

  // descriptor address: q_desc + 16*idx (+8 for the second word)
  wire [63:0] desc_base = q_desc + {44'd0, idx, 4'b0000};

  assign dma_req_valid = ((st == W_RD0) || (st == W_RD1)) && !dwait;
  assign dma_req_addr  = (st == W_RD1) ? (desc_base + 64'd8) : desc_base;
  assign dma_req_we    = 1'b0;
  assign dma_req_wdata = 64'd0;
  assign dma_req_be    = 8'hff;

  wire resp = dwait && dma_resp_valid;

  assign chk_addr  = d_addr;
  assign chk_len   = d_len;
  assign chk_write = d_flags[1];

  assign busy = (st != W_IDLE);

  /* verilator lint_off UNUSEDSIGNAL */
  wire [32:0] total_next = {1'b0, r_len} + {1'b0, w_len} + {1'b0, d_len};  // only carry used
  wire [CW-1:0] n_seg    = n_r + n_w;   // < MAX_CHAIN whenever a segment is stored
  /* verilator lint_on UNUSEDSIGNAL */

  localparam logic [15:0] ALLOWED_FLAGS = VIRTQ_DESC_F_NEXT | VIRTQ_DESC_F_WRITE;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st              <= W_IDLE;
      dwait           <= 1'b0;
      idx             <= '0;
      count           <= '0;
      visited         <= '0;
      seen_w          <= 1'b0;
      d_addr          <= '0;
      d_len           <= '0;
      d_flags         <= '0;
      d_next          <= '0;
      n_r             <= '0;
      n_w             <= '0;
      r_len           <= '0;
      w_len           <= '0;
      r_fault         <= 1'b0;
      done            <= 1'b0;
      fatal           <= 1'b0;
      cause           <= FC_NONE;
      perm_viol_pulse <= 1'b0;
      desc_pulse      <= 1'b0;
      fault_pulse     <= 1'b0;
      fault_addr      <= '0;
      for (int i = 0; i < MAX_CHAIN; i++) begin
        seg_addr[i] <= '0;
        seg_len[i]  <= '0;
      end
    end else begin
      done            <= 1'b0;
      perm_viol_pulse <= 1'b0;
      desc_pulse      <= 1'b0;
      fault_pulse     <= 1'b0;

      if (dma_req_valid && dma_req_ready) dwait <= 1'b1;
      if (resp) dwait <= 1'b0;

      case (st)
        W_IDLE: if (start) begin
          idx     <= head;
          count   <= '0;
          visited <= '0;
          seen_w  <= 1'b0;
          n_r     <= '0;
          n_w     <= '0;
          r_len   <= '0;
          w_len   <= '0;
          r_fault <= 1'b0;
          fatal   <= 1'b0;
          cause   <= FC_NONE;
          st      <= W_CHECK;
        end

        W_CHECK: begin
          if (abort) begin
            st <= W_IDLE;
          end else if (idx >= q_size) begin
            fatal <= 1'b1; cause <= FC_DESC_IDX_OOR; done <= 1'b1; st <= W_IDLE;
          end else if (visited[idx[VW-1:0]]) begin
            fatal <= 1'b1; cause <= FC_CHAIN_LOOP;   done <= 1'b1; st <= W_IDLE;
          end else if (count == CW'(MAX_CHAIN)) begin
            fatal <= 1'b1; cause <= FC_CHAIN_TOO_LONG; done <= 1'b1; st <= W_IDLE;
          end else begin
            visited[idx[VW-1:0]] <= 1'b1;
            count <= count + 1'b1;
            st    <= W_RD0;
          end
        end

        W_RD0: if (resp) begin
          if (dma_resp_err) begin
            fatal <= 1'b1; cause <= FC_RING_DMA; done <= 1'b1; fault_pulse <= 1'b1; st <= W_IDLE;
          end else if (abort) begin
            st <= W_IDLE;
          end else begin
            d_addr <= dma_resp_rdata;
            st     <= W_RD1;
          end
        end

        W_RD1: if (resp) begin
          if (dma_resp_err) begin
            fatal <= 1'b1; cause <= FC_RING_DMA; done <= 1'b1; fault_pulse <= 1'b1; st <= W_IDLE;
          end else if (abort) begin
            st <= W_IDLE;
          end else begin
            d_len      <= dma_resp_rdata[31:0];
            d_flags    <= dma_resp_rdata[47:32];
            d_next     <= dma_resp_rdata[63:48];
            desc_pulse <= 1'b1;
            st         <= W_EVAL;
          end
        end

        W_EVAL: begin
          if (abort) begin
            st <= W_IDLE;
          end else if ((d_flags & ~ALLOWED_FLAGS) != 16'd0) begin
            fatal <= 1'b1; cause <= FC_DESC_FLAGS;    done <= 1'b1; st <= W_IDLE;
          end else if (!d_flags[1] && seen_w) begin
            fatal <= 1'b1; cause <= FC_CHAIN_ORDER;   done <= 1'b1; st <= W_IDLE;
          end else if (total_next[32]) begin
            fatal <= 1'b1; cause <= FC_CHAIN_LEN_OVF; done <= 1'b1; st <= W_IDLE;
          end else if ((d_len != 32'd0) && !chk_ok && d_flags[1]) begin
            fatal <= 1'b1; cause <= FC_WRITABLE_PERM; done <= 1'b1;
            perm_viol_pulse <= 1'b1; fault_addr <= d_addr; st <= W_IDLE;
          end else begin
            if ((d_len != 32'd0) && !chk_ok) begin       // readable, not permitted
              r_fault         <= 1'b1;
              perm_viol_pulse <= 1'b1;
              fault_addr      <= d_addr;
            end
            if (d_len != 32'd0) begin
              seg_addr[n_seg[SW-1:0]] <= d_addr;
              seg_len [n_seg[SW-1:0]] <= d_len;
              if (d_flags[1]) begin
                n_w   <= n_w + 1'b1;
                w_len <= w_len + d_len;
              end else begin
                n_r   <= n_r + 1'b1;
                r_len <= r_len + d_len;
              end
            end
            seen_w <= seen_w | d_flags[1];
            if (d_flags[0]) begin
              idx <= d_next;
              st  <= W_CHECK;
            end else begin
              done <= 1'b1;
              st   <= W_IDLE;
            end
          end
        end

        default: st <= W_IDLE;
      endcase
    end
  end

endmodule
