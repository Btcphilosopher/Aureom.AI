// =============================================================================
// silicaflux_virtio_domain_perm.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Domain permission adapter (tenant DMA protection).
//
// Every host-memory access issued by the VirtIO engine passes through this
// block. A request is forwarded to host memory only if the exact byte range it
// touches lies entirely inside ONE valid window that
//   (a) is tagged with the protected domain bound to the queue, AND
//   (b) grants the access direction (read or write).
// The domain tag alone never authorises anything: a matching domain with a
// non-covering window is denied. Denied requests are never forwarded; the
// requester receives an error response and a violation pulse is raised.
//
// The table is programmed ONLY through the privileged management window
// (ControlCore / hypervisor). The guest-visible VirtIO register space has no
// path to it. Addresses are IOVAs used 1:1 (no translation). A platform IOMMU
// can be placed downstream: dn_req_domain is exported so that it can apply its
// own translation/check as a second, independent line of defence.
//
// Window semantics: base and limit are inclusive byte addresses. A window with
// base > limit matches nothing. Ranges that wrap past 2^64 are always denied.
//
// Upstream protocol: valid/ready request, one response per accepted request,
// and the upstream (silicaflux_virtio_dma_arb) never has more than one request
// outstanding. Downstream is identical.
// =============================================================================
module silicaflux_virtio_domain_perm #(
  parameter int N_WIN = 8
) (
  input  logic                     clk,
  input  logic                     rst_n,

  // ---- table programming (management window only) -------------------------
  input  logic                     cfg_we,
  input  logic [$clog2(N_WIN)-1:0] cfg_win,
  input  logic [2:0]               cfg_field,   // 0 ctrl 1 domain 2 base_lo 3 base_hi 4 limit_lo 5 limit_hi
  input  logic [31:0]              cfg_wdata,
  input  logic [$clog2(N_WIN)-1:0] cfg_rwin,
  input  logic [2:0]               cfg_rfield,
  output logic [31:0]              cfg_rdata,

  // ---- protected domain bound to the queue ---------------------------------
  input  logic [15:0]              domain,
  input  logic                     domain_valid,

  // ---- range pre-check port (combinational) used by the descriptor walker --
  input  logic [63:0]              chk_addr,
  input  logic [31:0]              chk_len,
  input  logic                     chk_write,
  output logic                     chk_ok,

  // ---- upstream DMA (from arbiter) ------------------------------------------
  input  logic                     up_req_valid,
  output logic                     up_req_ready,
  input  logic [63:0]              up_req_addr,    // 8-byte aligned
  input  logic                     up_req_we,
  input  logic [63:0]              up_req_wdata,
  input  logic [7:0]               up_req_be,
  output logic                     up_resp_valid,
  output logic [63:0]              up_resp_rdata,
  output logic                     up_resp_err,

  // ---- downstream DMA (to host memory / platform IOMMU) ---------------------
  output logic                     dn_req_valid,
  input  logic                     dn_req_ready,
  output logic [63:0]              dn_req_addr,
  output logic                     dn_req_we,
  output logic [63:0]              dn_req_wdata,
  output logic [7:0]               dn_req_be,
  output logic [15:0]              dn_req_domain,
  input  logic                     dn_resp_valid,
  input  logic [63:0]              dn_resp_rdata,
  input  logic                     dn_resp_err,

  // ---- violation reporting --------------------------------------------------
  output logic                     viol_pulse,      // one cycle per denied access (DMA path)
  output logic [63:0]              viol_addr,
  output logic                     viol_write
);

  // ---------------------------------------------------------------------------
  // Permission table
  // ---------------------------------------------------------------------------
  logic [N_WIN-1:0]        win_valid, win_r, win_w;
  logic [15:0]             win_dom   [N_WIN];
  logic [63:0]             win_base  [N_WIN];
  logic [63:0]             win_limit [N_WIN];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      win_valid <= '0;
      win_r     <= '0;
      win_w     <= '0;
      for (int i = 0; i < N_WIN; i++) begin
        win_dom[i]   <= '0;
        win_base[i]  <= '0;
        win_limit[i] <= '0;
      end
    end else if (cfg_we) begin
      case (cfg_field)
        3'd0: begin
          win_valid[cfg_win] <= cfg_wdata[0];
          win_r[cfg_win]     <= cfg_wdata[1];
          win_w[cfg_win]     <= cfg_wdata[2];
        end
        3'd1: win_dom[cfg_win]           <= cfg_wdata[15:0];
        3'd2: win_base[cfg_win][31:0]    <= cfg_wdata;
        3'd3: win_base[cfg_win][63:32]   <= cfg_wdata;
        3'd4: win_limit[cfg_win][31:0]   <= cfg_wdata;
        3'd5: win_limit[cfg_win][63:32]  <= cfg_wdata;
        default: ;
      endcase
    end
  end

  always_comb begin
    case (cfg_rfield)
      3'd0:    cfg_rdata = {29'd0, win_w[cfg_rwin], win_r[cfg_rwin], win_valid[cfg_rwin]};
      3'd1:    cfg_rdata = {16'd0, win_dom[cfg_rwin]};
      3'd2:    cfg_rdata = win_base[cfg_rwin][31:0];
      3'd3:    cfg_rdata = win_base[cfg_rwin][63:32];
      3'd4:    cfg_rdata = win_limit[cfg_rwin][31:0];
      3'd5:    cfg_rdata = win_limit[cfg_rwin][63:32];
      default: cfg_rdata = '0;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Range check: [lo, hi] inclusive, wrap flag => deny.
  // ---------------------------------------------------------------------------
  function automatic logic range_allowed(
      input logic [63:0] lo, input logic [63:0] hi, input logic wrap,
      input logic is_write,
      input logic [N_WIN-1:0] v, input logic [N_WIN-1:0] r, input logic [N_WIN-1:0] w,
      input logic [15:0] dom, input logic dom_valid,
      input logic [15:0] wd [N_WIN], input logic [63:0] wb [N_WIN], input logic [63:0] wl [N_WIN]);
    logic ok;
    ok = 1'b0;
    if (dom_valid && !wrap) begin
      for (int i = 0; i < N_WIN; i++) begin
        if (v[i] && (wd[i] == dom) && (lo >= wb[i]) && (hi <= wl[i]) &&
            (is_write ? w[i] : r[i]))
          ok = 1'b1;
      end
    end
    return ok;
  endfunction

  // ---- pre-check port --------------------------------------------------------
  logic [64:0] chk_end;   // addr + len - 1 with carry
  always_comb begin
    chk_end = {1'b0, chk_addr} + {33'd0, chk_len} - 65'd1;
    chk_ok  = (chk_len != 32'd0) &&
              range_allowed(chk_addr, chk_end[63:0], chk_end[64], chk_write,
                            win_valid, win_r, win_w, domain, domain_valid,
                            win_dom, win_base, win_limit);
  end

  // ---------------------------------------------------------------------------
  // DMA gate. States: EMPTY -> HOLD (check, registered) -> ISSUE | DENY
  //                  ISSUE -> WAIT -> EMPTY ; DENY -> EMPTY
  // The allow decision is registered in HOLD so that dn_req_valid is stable
  // while ISSUE waits for dn_req_ready, even if the table is reprogrammed.
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {G_EMPTY, G_HOLD, G_ISSUE, G_WAIT, G_DENY} gstate_t;
  gstate_t gst;

  logic [63:0] h_addr, h_wdata;
  logic        h_we;
  logic [7:0]  h_be;

  // first / last enabled lane of the held byte-enable (contiguous by contract;
  // a non-contiguous or empty mask is denied below)
  logic [2:0]  be_lo, be_hi;
  logic        be_ok;
  always_comb begin
    be_lo = 3'd0;
    be_hi = 3'd0;
    for (int i = 7; i >= 0; i--) if (h_be[i]) be_lo = 3'(i);
    for (int i = 0; i < 8; i++)  if (h_be[i]) be_hi = 3'(i);
    // contiguous iff mask == ones(be_hi-be_lo+1) << be_lo
    be_ok = (h_be != 8'd0) &&
            (h_be == sfv_mask(be_lo, be_hi));
  end

  function automatic logic [7:0] sfv_mask(input logic [2:0] lo, input logic [2:0] hi);
    logic [7:0] m;
    for (int i = 0; i < 8; i++) m[i] = (3'(i) >= lo) && (3'(i) <= hi);
    return m;
  endfunction

  logic [63:0] g_lo, g_hi;
  logic        g_allowed;
  always_comb begin
    g_lo      = {h_addr[63:3], be_lo};
    g_hi      = {h_addr[63:3], be_hi};
    g_allowed = be_ok && (h_addr[2:0] == 3'd0) &&
                range_allowed(g_lo, g_hi, 1'b0, h_we,
                              win_valid, win_r, win_w, domain, domain_valid,
                              win_dom, win_base, win_limit);
  end

  assign up_req_ready  = (gst == G_EMPTY);
  assign dn_req_valid  = (gst == G_ISSUE);
  assign dn_req_addr   = h_addr;
  assign dn_req_we     = h_we;
  assign dn_req_wdata  = h_wdata;
  assign dn_req_be     = h_be;
  assign dn_req_domain = domain;

  assign up_resp_valid = ((gst == G_WAIT) && dn_resp_valid) || (gst == G_DENY);
  assign up_resp_rdata = (gst == G_WAIT) ? dn_resp_rdata : 64'd0;
  assign up_resp_err   = (gst == G_DENY) ? 1'b1 : dn_resp_err;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      gst        <= G_EMPTY;
      h_addr     <= '0;
      h_wdata    <= '0;
      h_we       <= 1'b0;
      h_be       <= '0;
      viol_pulse <= 1'b0;
      viol_addr  <= '0;
      viol_write <= 1'b0;
    end else begin
      viol_pulse <= 1'b0;
      case (gst)
        G_EMPTY: if (up_req_valid) begin
          h_addr  <= up_req_addr;
          h_wdata <= up_req_wdata;
          h_we    <= up_req_we;
          h_be    <= up_req_be;
          gst     <= G_HOLD;
        end
        G_HOLD: begin
          if (g_allowed) begin
            gst <= G_ISSUE;
          end else begin
            gst        <= G_DENY;
            viol_pulse <= 1'b1;
            viol_addr  <= g_lo;
            viol_write <= h_we;
          end
        end
        G_ISSUE: if (dn_req_ready) gst <= G_WAIT;
        G_WAIT:  if (dn_resp_valid) gst <= G_EMPTY;
        G_DENY:  gst <= G_EMPTY;
        default: gst <= G_EMPTY;
      endcase
    end
  end

endmodule
