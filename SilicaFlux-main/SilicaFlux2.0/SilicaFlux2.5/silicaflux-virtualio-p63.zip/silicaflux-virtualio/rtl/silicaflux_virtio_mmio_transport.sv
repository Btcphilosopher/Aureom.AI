// =============================================================================
// silicaflux_virtio_mmio_transport.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Guest-visible VirtIO transport: "Virtio Over MMIO", Version 2 (spec 4.2).
//
//  * Feature negotiation (spec 2.2, 3.1.1): the device offers ONLY features it
//    implements. FEATURES_OK is withheld when the driver accepts a feature that
//    was not offered or omits a feature this device requires.
//  * Device status (spec 2.1): bits can only be set by the driver; writing 0
//    resets the device. DEVICE_NEEDS_RESET is device-owned.
//  * Reset and queue disable are quiesced: the bus write is back-pressured
//    (mmio_req_ready=0) until every in-flight DMA/storage operation of the
//    engine has drained, so no device write can land after the driver observes
//    the reset as complete.
//  * One virtqueue (index 0), split layout only.
//
// Bus protocol: valid/ready request; exactly one response, one cycle after the
// request is accepted (writes return rdata=0).
// =============================================================================
module silicaflux_virtio_mmio_transport
  import silicaflux_virtio_pkg::*;
#(
  parameter int MAX_QSZ          = 256,
  parameter int MAX_CHAIN        = 16,
  parameter int CAPACITY_SECTORS = 2048
) (
  input  logic        clk,
  input  logic        rst_n,

  // ---- guest-visible register bus --------------------------------------------
  input  logic        mmio_req_valid,
  output logic        mmio_req_ready,
  input  logic        mmio_req_we,
  input  logic [11:0] mmio_req_addr,
  input  logic [31:0] mmio_req_wdata,
  input  logic [3:0]  mmio_req_be,
  output logic        mmio_resp_valid,
  output logic [31:0] mmio_resp_rdata,
  output logic        irq,

  // ---- engine interface --------------------------------------------------------
  input  logic        engine_idle,
  output logic        abort,             // drain request for reset / queue disable
  input  logic        eng_fatal_pulse,   // fatal error detected by the datapath
  input  logic        used_irq_pulse,    // used buffer notification
  output logic        cfg_fatal_pulse,   // invalid queue configuration at QueueReady=1
  output logic        reset_pulse,       // device reset performed (Status <- 0)

  output logic        q_ready,
  output logic [15:0] q_size,
  output logic [63:0] q_desc,
  output logic [63:0] q_driver,
  output logic [63:0] q_device,
  output logic        dev_active,
  output logic        notify_pulse,
  output logic [63:0] drv_features,
  output logic        needs_reset,
  output logic [7:0]  dev_status
);

  // ---------------------------------------------------------------------------
  // Offered / required features. Only what is implemented is offered.
  // ---------------------------------------------------------------------------
  localparam logic [63:0] DEV_FEATURES =
      (64'd1 << VIRTIO_F_VERSION_1)       |
      (64'd1 << VIRTIO_F_ACCESS_PLATFORM) |
      (64'd1 << VIRTIO_BLK_F_SEG_MAX)     |
      (64'd1 << VIRTIO_BLK_F_FLUSH);
  // VERSION_1: modern-only device. ACCESS_PLATFORM: every buffer address is an
  // IOVA checked against the tenant's permission table; a driver that refuses
  // this contract is not operated (spec 6.1: device MAY fail to operate).
  localparam logic [63:0] REQ_FEATURES =
      (64'd1 << VIRTIO_F_VERSION_1)       |
      (64'd1 << VIRTIO_F_ACCESS_PLATFORM);

  localparam logic [63:0] CAPACITY = 64'(CAPACITY_SECTORS);
  localparam logic [31:0] SEG_MAX  = 32'(MAX_CHAIN - 2);  // data segments (excl. header + status)

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  logic [7:0]  status_q;
  logic        needs_reset_q;
  logic [31:0] dev_feat_sel, drv_feat_sel, queue_sel;
  logic [63:0] drv_feat_q;
  logic [31:0] q_num;
  logic        q_ready_q;
  logic [63:0] q_desc_q, q_driver_q, q_device_q;
  logic [1:0]  int_status;
  logic        abort_q;

  wire [11:0] a  = mmio_req_addr;
  wire [31:0] wd = mmio_req_wdata;

  wire sel0 = (queue_sel == 32'd0);

  wire is_reset_wr   = mmio_req_we && (a == MMIO_STATUS) && (wd == 32'd0);
  wire is_qdisable   = mmio_req_we && (a == MMIO_QUEUE_READY) && (wd[0] == 1'b0) && sel0 && q_ready_q;
  wire needs_quiesce = is_reset_wr || is_qdisable;

  assign mmio_req_ready = !needs_quiesce || (abort_q && engine_idle);
  assign abort          = abort_q;
  wire   acc            = mmio_req_valid && mmio_req_ready;

  // feature acceptance (spec 3.1.1 step 5)
  wire feat_ok = ((drv_feat_q & ~DEV_FEATURES) == 64'd0) &&
                 ((drv_feat_q & REQ_FEATURES) == REQ_FEATURES);

  // queue configuration validity (spec 2.7: power of two, <= QueueNumMax;
  // 2.7.2 alignment: desc 16, driver(avail) 2, device(used) 4)
  wire qnum_pow2 = (q_num != 32'd0) && ((q_num & (q_num - 32'd1)) == 32'd0);
  wire qcfg_ok   = qnum_pow2 && (q_num <= 32'(MAX_QSZ)) &&
                   (q_desc_q[3:0] == 4'd0) && (q_driver_q[0] == 1'b0) &&
                   (q_device_q[1:0] == 2'd0);

  wire driver_ok_bit = status_q[2];
  wire feat_ok_bit   = status_q[3];
  wire failed_bit    = status_q[7];

  // ---------------------------------------------------------------------------
  // Read mux
  // ---------------------------------------------------------------------------
  logic [31:0] rdata;
  always_comb begin
    rdata = 32'd0;
    case (a)
      MMIO_MAGIC_VALUE:       rdata = VIRTIO_MMIO_MAGIC;
      MMIO_VERSION:           rdata = VIRTIO_MMIO_VERSION;
      MMIO_DEVICE_ID:         rdata = VIRTIO_ID_BLOCK;
      MMIO_VENDOR_ID:         rdata = SFV_VIRTIO_VENDOR;
      MMIO_DEVICE_FEATURES:   rdata = (dev_feat_sel == 32'd0) ? DEV_FEATURES[31:0]  :
                                      (dev_feat_sel == 32'd1) ? DEV_FEATURES[63:32] : 32'd0;
      MMIO_QUEUE_NUM_MAX:     rdata = sel0 ? 32'(MAX_QSZ) : 32'd0;
      MMIO_QUEUE_READY:       rdata = {31'd0, sel0 && q_ready_q};
      MMIO_INTERRUPT_STATUS:  rdata = {30'd0, int_status};
      MMIO_STATUS:            rdata = {24'd0, status_q | (needs_reset_q ? VIRTIO_STATUS_DEVICE_NEEDS_RESET : 8'd0)};
      MMIO_SHM_LEN_LOW,
      MMIO_SHM_LEN_HIGH,
      MMIO_SHM_BASE_LOW,
      MMIO_SHM_BASE_HIGH:     rdata = 32'hffff_ffff;   // no shared memory regions
      MMIO_CONFIG_GENERATION: rdata = 32'd0;           // config space is static
      MMIO_CONFIG + BLK_CFG_CAPACITY:         rdata = CAPACITY[31:0];
      MMIO_CONFIG + BLK_CFG_CAPACITY + 12'd4: rdata = CAPACITY[63:32];
      MMIO_CONFIG + BLK_CFG_SIZE_MAX:         rdata = 32'd0;     // SIZE_MAX not offered
      MMIO_CONFIG + BLK_CFG_SEG_MAX:          rdata = SEG_MAX;
      default:                rdata = 32'd0;
    endcase
  end

  // ---------------------------------------------------------------------------
  // Sequential
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      status_q        <= '0;
      needs_reset_q   <= 1'b0;
      dev_feat_sel    <= '0;
      drv_feat_sel    <= '0;
      queue_sel       <= '0;
      drv_feat_q      <= '0;
      q_num           <= 32'(MAX_QSZ);
      q_ready_q       <= 1'b0;
      q_desc_q        <= '0;
      q_driver_q      <= '0;
      q_device_q      <= '0;
      int_status      <= '0;
      abort_q         <= 1'b0;
      mmio_resp_valid <= 1'b0;
      mmio_resp_rdata <= '0;
      cfg_fatal_pulse <= 1'b0;
      notify_pulse    <= 1'b0;
      reset_pulse     <= 1'b0;
    end else begin
      mmio_resp_valid <= acc;
      mmio_resp_rdata <= (acc && !mmio_req_we) ? rdata : 32'd0;
      cfg_fatal_pulse <= 1'b0;
      notify_pulse    <= 1'b0;
      reset_pulse     <= 1'b0;

      // drain request: held while a quiescing write waits for the engine
      abort_q <= mmio_req_valid && needs_quiesce && !acc;

      // datapath events
      if (used_irq_pulse) int_status[VIRTIO_MMIO_INT_VRING] <= 1'b1;
      if (eng_fatal_pulse) begin
        needs_reset_q <= 1'b1;
        if (driver_ok_bit) int_status[VIRTIO_MMIO_INT_CONFIG] <= 1'b1;  // spec 2.1.2
      end

      if (acc && mmio_req_we) begin
        case (a)
          MMIO_DEVICE_FEATURES_SEL: dev_feat_sel <= wd;
          MMIO_DRIVER_FEATURES_SEL: drv_feat_sel <= wd;
          MMIO_DRIVER_FEATURES: if (!feat_ok_bit) begin
            if (drv_feat_sel == 32'd0) drv_feat_q[31:0]  <= wd;
            if (drv_feat_sel == 32'd1) drv_feat_q[63:32] <= wd;
          end
          MMIO_QUEUE_SEL:        queue_sel <= wd;
          MMIO_QUEUE_NUM:        if (sel0 && !q_ready_q) q_num <= wd;
          MMIO_QUEUE_DESC_LOW:   if (sel0 && !q_ready_q) q_desc_q[31:0]    <= wd;
          MMIO_QUEUE_DESC_HIGH:  if (sel0 && !q_ready_q) q_desc_q[63:32]   <= wd;
          MMIO_QUEUE_DRIVER_LOW: if (sel0 && !q_ready_q) q_driver_q[31:0]  <= wd;
          MMIO_QUEUE_DRIVER_HIGH:if (sel0 && !q_ready_q) q_driver_q[63:32] <= wd;
          MMIO_QUEUE_DEVICE_LOW: if (sel0 && !q_ready_q) q_device_q[31:0]  <= wd;
          MMIO_QUEUE_DEVICE_HIGH:if (sel0 && !q_ready_q) q_device_q[63:32] <= wd;
          MMIO_QUEUE_READY: if (sel0) begin
            if (wd[0] && !q_ready_q) begin
              if (qcfg_ok) begin
                q_ready_q <= 1'b1;
              end else begin
                cfg_fatal_pulse <= 1'b1;
                needs_reset_q   <= 1'b1;
                if (driver_ok_bit) int_status[VIRTIO_MMIO_INT_CONFIG] <= 1'b1;
              end
            end else if (!wd[0]) begin
              q_ready_q <= 1'b0;   // quiesced by the ready gating above
            end
          end
          MMIO_QUEUE_NOTIFY: if (wd == 32'd0 && q_ready_q) notify_pulse <= 1'b1;
          MMIO_INTERRUPT_ACK: int_status <= int_status & ~wd[1:0];
          MMIO_STATUS: begin
            if (wd == 32'd0) begin
              // ---- device reset (spec 2.1, 4.2.2.1) ----
              status_q      <= '0;
              needs_reset_q <= 1'b0;
              dev_feat_sel  <= '0;
              drv_feat_sel  <= '0;
              queue_sel     <= '0;
              drv_feat_q    <= '0;
              q_num         <= 32'(MAX_QSZ);
              q_ready_q     <= 1'b0;
              q_desc_q      <= '0;
              q_driver_q    <= '0;
              q_device_q    <= '0;
              int_status    <= '0;
              reset_pulse   <= 1'b1;
            end else begin
              // driver may only set bits; NEEDS_RESET is device-owned
              logic [7:0] nv;
              nv = status_q | (wd[7:0] & ~VIRTIO_STATUS_DEVICE_NEEDS_RESET);
              if (wd[3] && !feat_ok_bit && !feat_ok) nv[3] = 1'b0;  // refuse FEATURES_OK
              status_q <= nv;
            end
          end
          default: ;
        endcase
      end
    end
  end

  // ---------------------------------------------------------------------------
  // Outputs
  // ---------------------------------------------------------------------------
  assign irq          = |int_status;
  assign q_ready      = q_ready_q;
  assign q_size       = q_num[15:0];
  assign q_desc       = q_desc_q;
  assign q_driver     = q_driver_q;
  assign q_device     = q_device_q;
  assign drv_features = drv_feat_q;
  assign needs_reset  = needs_reset_q;
  assign dev_status   = status_q;
  // spec 3.1.1 / 2.1.2: no buffers consumed before DRIVER_OK, none after
  // FAILED or while NEEDS_RESET is set; FEATURES_OK is a precondition.
  assign dev_active   = driver_ok_bit && feat_ok_bit && !failed_bit && !needs_reset_q;

  // byte enables are accepted but registers are 32-bit (spec 4.2.2.2: driver
  // MUST use 32-bit accesses for registers); config space is read-only.
  logic unused_be;
  assign unused_be = ^mmio_req_be;

endmodule
