// =============================================================================
// silicaflux_virtio_queue_ctrl.sv
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Split-virtqueue controller (spec 2.7). Owns last_avail_idx and used_idx,
// fetches heads from the available ring, sequences the descriptor walker and
// the device backend, and publishes completions on the used ring.
//
// Completion order (spec 2.7.8, 2.7.13):
//   1. backend finishes the request completely (all writable bytes + status)
//   2. used.ring[used_idx % N] = { id = head, len = used_len }   (two le32)
//   3. used.{flags,idx} = { 0, used_idx + 1 }                    (one le32)
//   4. re-read avail.flags; raise a used-buffer notification unless
//      VIRTQ_AVAIL_F_NO_INTERRUPT is set (EVENT_IDX is not offered).
// All DMA is single-outstanding and in order, so step 2 is globally visible
// before step 3 (the platform's memory interface is required to be in order
// for one requester; see docs/01_architecture.md).
//
// Indices are free-running 16-bit counters; ring slots are idx & (N-1).
// =============================================================================
module silicaflux_virtio_queue_ctrl
  import silicaflux_virtio_pkg::*;
(
  input  logic        clk,
  input  logic        rst_n,

  input  logic        q_ready,
  input  logic [15:0] q_size,
  input  logic [63:0] q_driver,
  input  logic [63:0] q_device,
  input  logic        dev_active,
  input  logic        domain_valid,
  input  logic        notify,
  input  logic        abort,

  output logic        idle,
  output logic        fatal_pulse,
  output logic [7:0]  fatal_cause,

  output logic        walk_start,
  output logic [15:0] walk_head,
  input  logic        walk_busy,
  input  logic        walk_done,
  input  logic        walk_fatal,
  input  logic [7:0]  walk_cause,

  output logic        exec_start,
  input  logic        exec_busy,
  input  logic        exec_done,
  input  logic        exec_fatal,
  input  logic [7:0]  exec_cause,
  input  logic [31:0] exec_used_len,

  output logic        used_irq_pulse,
  output logic        irq_suppressed_pulse,
  output logic        req_done_pulse,
  output logic        head_pulse,
  output logic [16:0] head_depth,
  output logic        ring_fault_pulse,    // ring access error (for fault capture)

  output logic        dma_req_valid,
  input  logic        dma_req_ready,
  output logic [63:0] dma_req_addr,
  output logic        dma_req_we,
  output logic [63:0] dma_req_wdata,
  output logic [7:0]  dma_req_be,
  input  logic        dma_resp_valid,
  input  logic [63:0] dma_resp_rdata,
  input  logic        dma_resp_err
);

  typedef enum logic [3:0] {
    Q_IDLE, Q_RD_IDX, Q_RD_RING, Q_WALK_GO, Q_WALK, Q_EXEC_GO, Q_EXEC,
    Q_WR_ID, Q_WR_LEN, Q_WR_IDX, Q_RD_FLAGS, Q_HALT
  } qstate_t;

  qstate_t     st;
  logic        dwait;          // DMA request accepted, waiting for response
  logic        pending;        // notification received, not yet serviced
  logic [15:0] last_avail;     // next avail entry to consume
  logic [15:0] used_idx;       // next used entry to publish
  logic [15:0] avail_cache;    // last observed avail.idx
  logic [15:0] head_q;
  logic [31:0] used_len_q;

  wire [15:0] qmask     = q_size - 16'd1;
  wire [15:0] avail_gap = avail_cache - last_avail;

  // ---------------------------------------------------------------------------
  // DMA request generation (address/lane by state)
  // ---------------------------------------------------------------------------
  logic [63:0] acc_addr;     // exact byte address of the access
  logic [3:0]  acc_bytes;
  logic [31:0] acc_wval;
  always_comb begin
    acc_addr  = 64'd0;
    acc_bytes = 4'd2;
    acc_wval  = 32'd0;
    case (st)
      Q_RD_IDX:   begin acc_addr = q_driver + 64'd2;                                       acc_bytes = 4'd2; end
      Q_RD_RING:  begin acc_addr = q_driver + 64'd4 + {47'd0, (last_avail & qmask), 1'b0}; acc_bytes = 4'd2; end
      Q_WR_ID:    begin acc_addr = q_device + 64'd4 + {45'd0, (used_idx & qmask), 3'b000};
                        acc_bytes = 4'd4; acc_wval = {16'd0, head_q}; end
      Q_WR_LEN:   begin acc_addr = q_device + 64'd8 + {45'd0, (used_idx & qmask), 3'b000};
                        acc_bytes = 4'd4; acc_wval = used_len_q; end
      Q_WR_IDX:   begin acc_addr = q_device;  acc_bytes = 4'd4;
                        acc_wval = {used_idx + 16'd1, 16'd0}; end   // flags=0, idx (le16,le16)
      Q_RD_FLAGS: begin acc_addr = q_driver;  acc_bytes = 4'd2; end
      default: ;
    endcase
  end

  wire is_dma_state = (st == Q_RD_IDX) || (st == Q_RD_RING) || (st == Q_WR_ID) ||
                      (st == Q_WR_LEN) || (st == Q_WR_IDX) || (st == Q_RD_FLAGS);
  wire is_wr_state  = (st == Q_WR_ID) || (st == Q_WR_LEN) || (st == Q_WR_IDX);

  assign dma_req_valid = is_dma_state && !dwait;
  assign dma_req_addr  = {acc_addr[63:3], 3'b000};
  assign dma_req_we    = is_wr_state;
  assign dma_req_be    = sfv_be(acc_bytes, acc_addr[2:0]);
  assign dma_req_wdata = {32'd0, acc_wval} << {acc_addr[2:0], 3'b000};

  wire [15:0] rd16   = 16'(dma_resp_rdata >> {acc_addr[2:0], 3'b000});
  wire        resp   = dwait && dma_resp_valid;

  assign walk_head = head_q;
  assign walk_start = (st == Q_WALK_GO);
  assign exec_start = (st == Q_EXEC_GO);
  assign idle       = (st == Q_IDLE) || (st == Q_HALT);

  // ---------------------------------------------------------------------------
  // FSM
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st                   <= Q_IDLE;
      dwait                <= 1'b0;
      pending              <= 1'b0;
      last_avail           <= '0;
      used_idx             <= '0;
      avail_cache          <= '0;
      head_q               <= '0;
      used_len_q           <= '0;
      fatal_pulse          <= 1'b0;
      fatal_cause          <= FC_NONE;
      used_irq_pulse       <= 1'b0;
      irq_suppressed_pulse <= 1'b0;
      req_done_pulse       <= 1'b0;
      head_pulse           <= 1'b0;
      head_depth           <= '0;
      ring_fault_pulse     <= 1'b0;
    end else begin
      fatal_pulse          <= 1'b0;
      used_irq_pulse       <= 1'b0;
      irq_suppressed_pulse <= 1'b0;
      req_done_pulse       <= 1'b0;
      head_pulse           <= 1'b0;
      ring_fault_pulse     <= 1'b0;

      if (notify) pending <= 1'b1;

      if (dma_req_valid && dma_req_ready) dwait <= 1'b1;
      if (resp) dwait <= 1'b0;

      case (st)
        // ---------------------------------------------------------------------
        Q_IDLE: begin
          if (!q_ready) begin
            last_avail  <= '0;
            used_idx    <= '0;
            avail_cache <= '0;
            pending     <= 1'b0;
          end else if (pending && dev_active && !abort) begin
            if (!domain_valid) begin
              fatal_pulse <= 1'b1;
              fatal_cause <= FC_NO_DOMAIN;
              st          <= Q_HALT;
            end else begin
              pending <= notify;   // a notify in this very cycle stays pending
              st      <= Q_RD_IDX;
            end
          end
        end
        // ---------------------------------------------------------------------
        Q_RD_IDX: if (resp) begin
          if (dma_resp_err) begin
            fatal_pulse <= 1'b1; fatal_cause <= FC_RING_DMA; ring_fault_pulse <= 1'b1;
            st <= Q_HALT;
          end else if (abort) begin
            st <= Q_IDLE;
          end else begin
            avail_cache <= rd16;
            if ((rd16 - last_avail) > q_size) begin       // spec 2.7.13.3: idx never runs ahead > N
              fatal_pulse <= 1'b1; fatal_cause <= FC_AVAIL_IDX_JUMP;
              st <= Q_HALT;
            end else if (rd16 == last_avail) begin
              st <= Q_IDLE;                               // caught up
            end else begin
              st <= Q_RD_RING;
            end
          end
        end
        // ---------------------------------------------------------------------
        Q_RD_RING: if (resp) begin
          if (dma_resp_err) begin
            fatal_pulse <= 1'b1; fatal_cause <= FC_RING_DMA; ring_fault_pulse <= 1'b1;
            st <= Q_HALT;
          end else if (abort) begin
            st <= Q_IDLE;
          end else begin
            head_q     <= rd16;
            head_pulse <= 1'b1;
            head_depth <= {1'b0, avail_gap};
            st         <= Q_WALK_GO;
          end
        end
        // ---------------------------------------------------------------------
        Q_WALK_GO: st <= Q_WALK;
        Q_WALK: begin
          if (walk_done) begin
            if (walk_fatal) begin
              fatal_pulse <= 1'b1; fatal_cause <= walk_cause;
              st <= Q_HALT;
            end else if (abort) begin
              st <= Q_IDLE;
            end else begin
              st <= Q_EXEC_GO;
            end
          end else if (!walk_busy) begin
            st <= Q_IDLE;                                 // walker aborted
          end
        end
        Q_EXEC_GO: st <= Q_EXEC;
        Q_EXEC: begin
          if (exec_done) begin
            if (exec_fatal) begin
              fatal_pulse <= 1'b1; fatal_cause <= exec_cause;
              st <= Q_HALT;
            end else if (abort) begin
              st <= Q_IDLE;
            end else begin
              used_len_q <= exec_used_len;
              st <= Q_WR_ID;
            end
          end else if (!exec_busy) begin
            st <= Q_IDLE;                                 // backend aborted
          end
        end
        // ---------------------------------------------------------------------
        Q_WR_ID, Q_WR_LEN, Q_WR_IDX: if (resp) begin
          if (dma_resp_err) begin
            fatal_pulse <= 1'b1; fatal_cause <= FC_RING_DMA; ring_fault_pulse <= 1'b1;
            st <= Q_HALT;
          end else if (abort) begin
            st <= Q_IDLE;
          end else if (st == Q_WR_ID) begin
            st <= Q_WR_LEN;
          end else if (st == Q_WR_LEN) begin
            st <= Q_WR_IDX;
          end else begin
            used_idx       <= used_idx + 16'd1;
            last_avail     <= last_avail + 16'd1;
            req_done_pulse <= 1'b1;
            st             <= Q_RD_FLAGS;
          end
        end
        // ---------------------------------------------------------------------
        Q_RD_FLAGS: if (resp) begin
          if (dma_resp_err) begin
            fatal_pulse <= 1'b1; fatal_cause <= FC_RING_DMA; ring_fault_pulse <= 1'b1;
            st <= Q_HALT;
          end else begin
            if (rd16[0]) irq_suppressed_pulse <= 1'b1;    // VIRTQ_AVAIL_F_NO_INTERRUPT
            else         used_irq_pulse       <= 1'b1;
            if (abort)                         st <= Q_IDLE;
            else if (avail_cache != last_avail) st <= Q_RD_RING;
            else                               st <= Q_RD_IDX;
          end
        end
        // ---------------------------------------------------------------------
        Q_HALT: if (!q_ready) st <= Q_IDLE;               // only a reset leaves HALT
        default: st <= Q_IDLE;
      endcase
    end
  end

endmodule
