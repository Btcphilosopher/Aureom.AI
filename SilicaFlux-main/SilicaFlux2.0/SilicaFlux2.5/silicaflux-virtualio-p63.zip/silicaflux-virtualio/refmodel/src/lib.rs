//! sfv-refmodel — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//!
//! Independent transaction-level reference model of the SilicaFlux VirtIO
//! block engine, written directly from OASIS VirtIO 1.2 (virtio-v1.2-cs01)
//! plus the device policies documented in docs/03_conformance_checklist.md.
//! It shares no code with the RTL or the C host library.
//!
//! The model is driven by the co-simulation op-log (driver memory writes,
//! MMIO writes, management writes) and predicts the final guest memory,
//! storage contents, device status and deterministic counters.

use std::collections::{BTreeSet, HashSet};

// ---------------------------------------------------------------------------
// spec constants
// ---------------------------------------------------------------------------
pub const ST_ACK: u32 = 1;
pub const ST_DRIVER: u32 = 2;
pub const ST_DRIVER_OK: u32 = 4;
pub const ST_FEATURES_OK: u32 = 8;
pub const ST_NEEDS_RESET: u32 = 64;
pub const ST_FAILED: u32 = 128;

pub const F_VERSION_1: u32 = 32;
pub const F_ACCESS_PLATFORM: u32 = 33;
pub const BLK_F_SEG_MAX: u32 = 2;
pub const BLK_F_FLUSH: u32 = 9;

pub const DESC_F_NEXT: u16 = 1;
pub const DESC_F_WRITE: u16 = 2;

pub const BLK_T_IN: u32 = 0;
pub const BLK_T_OUT: u32 = 1;
pub const BLK_T_FLUSH: u32 = 4;
pub const BLK_T_GET_ID: u32 = 8;
pub const BLK_S_OK: u8 = 0;
pub const BLK_S_IOERR: u8 = 1;
pub const BLK_S_UNSUPP: u8 = 2;

pub const BLK_ID: &[u8; 20] = b"SILICAFLUX-VBLK-0001";

/// fatal (DEVICE_NEEDS_RESET) cause codes — management window ENGINE_STATUS[15:8]
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
pub enum Fatal {
    QueueCfg = 1,
    NoDomain = 2,
    AvailIdxJump = 3,
    RingDma = 4,
    DescIdxOor = 5,
    ChainLoop = 6,
    ChainTooLong = 7,
    DescFlags = 8,
    ChainOrder = 9,
    ChainLenOvf = 10,
    WritablePerm = 11,
    NoStatus = 12,
    DataWriteDma = 13,
}

pub fn dev_features() -> u64 {
    (1u64 << F_VERSION_1) | (1u64 << F_ACCESS_PLATFORM) | (1u64 << BLK_F_SEG_MAX) | (1u64 << BLK_F_FLUSH)
}
pub fn req_features() -> u64 {
    (1u64 << F_VERSION_1) | (1u64 << F_ACCESS_PLATFORM)
}

// ---------------------------------------------------------------------------
// storage initial pattern (mirrors sim/sim_env.cpp)
// ---------------------------------------------------------------------------
pub fn splitmix64(mut x: u64) -> u64 {
    x = x.wrapping_add(0x9e3779b97f4a7c15);
    x = (x ^ (x >> 30)).wrapping_mul(0xbf58476d1ce4e5b9);
    x = (x ^ (x >> 27)).wrapping_mul(0x94d049bb133111eb);
    x ^ (x >> 31)
}
pub fn stor_init_byte(seed: u64, dev: usize, i: u64) -> u8 {
    let w = splitmix64(seed ^ (((dev as u64) + 1) << 48) ^ (i >> 3));
    (w >> (8 * (i & 7))) as u8
}

// ---------------------------------------------------------------------------
// permission table
// ---------------------------------------------------------------------------
#[derive(Clone, Copy, Default, Debug)]
pub struct Window {
    pub valid: bool,
    pub r: bool,
    pub w: bool,
    pub dom: u16,
    pub base: u64,
    pub limit: u64,
}

/// Is the inclusive byte range [lo, hi] permitted for `dom` in direction `write`?
pub fn perm_allows(wins: &[Window], dom_valid: bool, dom: u16, lo: u64, hi: u64, write: bool) -> bool {
    if !dom_valid || hi < lo {
        return false;
    }
    wins.iter().any(|w| w.valid && w.dom == dom && lo >= w.base && hi <= w.limit && if write { w.w } else { w.r })
}

/// Range pre-check used for descriptors: [addr, addr+len-1], len > 0, no wrap.
pub fn range_allows(wins: &[Window], dom_valid: bool, dom: u16, addr: u64, len: u32, write: bool) -> bool {
    if len == 0 {
        return false;
    }
    match addr.checked_add(len as u64 - 1) {
        Some(hi) => perm_allows(wins, dom_valid, dom, addr, hi, write),
        None => false,
    }
}

// ---------------------------------------------------------------------------
// counters compared against the RTL
// ---------------------------------------------------------------------------
#[derive(Clone, Copy, Default, Debug, PartialEq, Eq)]
pub struct Counters {
    pub desc: u32,
    pub req: u32,
    pub viol: u32,
    pub fatal: u32,
    pub ioerr: u32,
    pub unsupp: u32,
    pub irq: u32,
    pub irq_sup: u32,
    pub notify: u32,
}

#[derive(Debug)]
enum AccErr {
    Perm,
    Bus,
}

/// A validated descriptor chain: readable then writable segments.
#[derive(Debug, Default, Clone)]
pub struct Chain {
    pub rsegs: Vec<(u64, u32)>,
    pub wsegs: Vec<(u64, u32)>,
    pub r_len: u64,
    pub w_len: u64,
    pub r_fault: bool,
}

// ---------------------------------------------------------------------------
// device
// ---------------------------------------------------------------------------
pub struct Device {
    pub idx: usize,
    pub max_qsz: u32,
    pub max_chain: u32,
    pub capacity: u64,
    // transport
    pub status: u32,
    pub needs_reset: bool,
    pub dev_sel: u32,
    pub drv_sel: u32,
    pub drv_feat: u64,
    pub queue_sel: u32,
    pub q_num: u32,
    pub q_ready: bool,
    pub q_desc: u64,
    pub q_driver: u64,
    pub q_device: u64,
    pub int_status: u32,
    // queue
    pub pending: bool,
    pub halted: bool,
    pub last_avail: u16,
    pub used_idx: u16,
    // privileged
    pub dom: u16,
    pub dom_valid: bool,
    pub wins: Vec<Window>,
    pub last_cause: u8,
    // backend
    pub stor: Vec<u8>,
    pub bad: BTreeSet<u64>,
    pub flushes: u64,
    pub cnt: Counters,
}

pub struct Platform {
    pub mem: Vec<u8>,
    pub devs: Vec<Device>,
}

impl Device {
    pub fn new(idx: usize, max_qsz: u32, max_chain: u32, n_win: u32, capacity: u64, seed: u64) -> Self {
        let stor = (0..capacity * 512).map(|i| stor_init_byte(seed, idx, i)).collect();
        Device {
            idx,
            max_qsz,
            max_chain,
            capacity,
            status: 0,
            needs_reset: false,
            dev_sel: 0,
            drv_sel: 0,
            drv_feat: 0,
            queue_sel: 0,
            q_num: max_qsz,
            q_ready: false,
            q_desc: 0,
            q_driver: 0,
            q_device: 0,
            int_status: 0,
            pending: false,
            halted: false,
            last_avail: 0,
            used_idx: 0,
            dom: 0,
            dom_valid: false,
            wins: vec![Window::default(); n_win as usize],
            last_cause: 0,
            stor,
            bad: BTreeSet::new(),
            flushes: 0,
            cnt: Counters::default(),
        }
    }

    pub fn status_reg(&self) -> u32 {
        self.status | if self.needs_reset { ST_NEEDS_RESET } else { 0 }
    }

    fn active(&self) -> bool {
        self.status & ST_DRIVER_OK != 0
            && self.status & ST_FEATURES_OK != 0
            && self.status & ST_FAILED == 0
            && !self.needs_reset
    }

    fn fatal(&mut self, f: Fatal) {
        self.needs_reset = true;
        if self.status & ST_DRIVER_OK != 0 {
            self.int_status |= 2; // configuration change notification (2.1.2)
        }
        self.last_cause = f as u8;
        self.cnt.fatal += 1;
        self.halted = true;
    }

    fn queue_reset_state(&mut self) {
        self.last_avail = 0;
        self.used_idx = 0;
        self.pending = false;
        self.halted = false;
    }

    fn qcfg_ok(&self) -> bool {
        let n = self.q_num;
        n != 0 && n.is_power_of_two() && n <= self.max_qsz && self.q_desc % 16 == 0 && self.q_driver % 2 == 0
            && self.q_device % 4 == 0
    }

    fn feat_ok(&self) -> bool {
        (self.drv_feat & !dev_features()) == 0 && (self.drv_feat & req_features()) == req_features()
    }
}

impl Platform {
    // ---- guest-visible transport -------------------------------------------------
    pub fn mmio_write(&mut self, d: usize, off: u32, v: u32) {
        let dv = &mut self.devs[d];
        let sel0 = dv.queue_sel == 0;
        match off {
            0x014 => dv.dev_sel = v,
            0x024 => dv.drv_sel = v,
            0x020 => {
                if dv.status & ST_FEATURES_OK == 0 {
                    if dv.drv_sel == 0 {
                        dv.drv_feat = (dv.drv_feat & !0xffff_ffff) | v as u64;
                    } else if dv.drv_sel == 1 {
                        dv.drv_feat = (dv.drv_feat & 0xffff_ffff) | ((v as u64) << 32);
                    }
                }
            }
            0x030 => dv.queue_sel = v,
            0x038 if sel0 && !dv.q_ready => dv.q_num = v,
            0x080 if sel0 && !dv.q_ready => dv.q_desc = (dv.q_desc & !0xffff_ffff) | v as u64,
            0x084 if sel0 && !dv.q_ready => dv.q_desc = (dv.q_desc & 0xffff_ffff) | ((v as u64) << 32),
            0x090 if sel0 && !dv.q_ready => dv.q_driver = (dv.q_driver & !0xffff_ffff) | v as u64,
            0x094 if sel0 && !dv.q_ready => dv.q_driver = (dv.q_driver & 0xffff_ffff) | ((v as u64) << 32),
            0x0a0 if sel0 && !dv.q_ready => dv.q_device = (dv.q_device & !0xffff_ffff) | v as u64,
            0x0a4 if sel0 && !dv.q_ready => dv.q_device = (dv.q_device & 0xffff_ffff) | ((v as u64) << 32),
            0x044 if sel0 => {
                if v & 1 == 1 && !dv.q_ready {
                    if dv.qcfg_ok() {
                        dv.q_ready = true;
                    } else {
                        dv.fatal(Fatal::QueueCfg);
                        dv.halted = false; // the queue never started; NEEDS_RESET gates it
                    }
                } else if v & 1 == 0 && dv.q_ready {
                    dv.q_ready = false;
                    dv.queue_reset_state();
                }
            }
            0x050 => {
                if v == 0 && dv.q_ready {
                    dv.cnt.notify += 1;
                    dv.pending = true;
                    self.try_process(d);
                }
            }
            0x064 => dv.int_status &= !(v & 3),
            0x070 => {
                if v == 0 {
                    dv.status = 0;
                    dv.needs_reset = false;
                    dv.dev_sel = 0;
                    dv.drv_sel = 0;
                    dv.queue_sel = 0;
                    dv.drv_feat = 0;
                    dv.q_num = dv.max_qsz;
                    dv.q_ready = false;
                    dv.q_desc = 0;
                    dv.q_driver = 0;
                    dv.q_device = 0;
                    dv.int_status = 0;
                    dv.queue_reset_state();
                } else {
                    let mut nv = dv.status | (v & 0xff & !ST_NEEDS_RESET);
                    if v & ST_FEATURES_OK != 0 && dv.status & ST_FEATURES_OK == 0 && !dv.feat_ok() {
                        nv &= !ST_FEATURES_OK;
                    }
                    dv.status = nv;
                    self.try_process(d);
                }
            }
            _ => {}
        }
    }

    // ---- privileged management window -------------------------------------------------
    pub fn mgmt_write(&mut self, d: usize, off: u32, v: u32) {
        let dv = &mut self.devs[d];
        let nwin = dv.wins.len() as u32;
        if off == 0x010 {
            if !dv.q_ready {
                dv.dom = (v & 0xffff) as u16;
                dv.dom_valid = v >> 31 == 1;
            }
        } else if off == 0x030 {
            if v & 1 != 0 {
                dv.cnt = Counters::default();
            }
        } else if (0x40..0x40 + 0x20 * nwin).contains(&off) {
            let w = ((off - 0x40) / 0x20) as usize;
            let f = ((off - 0x40) % 0x20) / 4;
            let win = &mut dv.wins[w];
            match f {
                0 => {
                    win.valid = v & 1 != 0;
                    win.r = v & 2 != 0;
                    win.w = v & 4 != 0;
                }
                1 => win.dom = (v & 0xffff) as u16,
                2 => win.base = (win.base & !0xffff_ffff) | v as u64,
                3 => win.base = (win.base & 0xffff_ffff) | ((v as u64) << 32),
                4 => win.limit = (win.limit & !0xffff_ffff) | v as u64,
                5 => win.limit = (win.limit & 0xffff_ffff) | ((v as u64) << 32),
                _ => {}
            }
        }
    }

    // ---- DMA through the domain gate (ring structures) --------------------------------
    fn gate_read(&mut self, d: usize, addr: u64, n: u64) -> Result<u64, AccErr> {
        let dv = &mut self.devs[d];
        if !perm_allows(&dv.wins, dv.dom_valid, dv.dom, addr, addr + n - 1, false) {
            dv.cnt.viol += 1;
            return Err(AccErr::Perm);
        }
        if (addr & !7) + 8 > self.mem.len() as u64 {
            return Err(AccErr::Bus);
        }
        let mut v = 0u64;
        for i in 0..n {
            v |= (self.mem[(addr + i) as usize] as u64) << (8 * i);
        }
        Ok(v)
    }

    fn gate_write(&mut self, d: usize, addr: u64, n: u64, val: u64) -> Result<(), AccErr> {
        let dv = &mut self.devs[d];
        if !perm_allows(&dv.wins, dv.dom_valid, dv.dom, addr, addr + n - 1, true) {
            dv.cnt.viol += 1;
            return Err(AccErr::Perm);
        }
        if (addr & !7) + 8 > self.mem.len() as u64 {
            return Err(AccErr::Bus);
        }
        for i in 0..n {
            self.mem[(addr + i) as usize] = (val >> (8 * i)) as u8;
        }
        Ok(())
    }

    // data-stream byte access (permission was pre-checked by the walk)
    fn data_byte_ok(&self, addr: u64) -> bool {
        addr < self.mem.len() as u64
    }

    // ---- queue processing ---------------------------------------------------------------
    fn try_process(&mut self, d: usize) {
        {
            let dv = &self.devs[d];
            if !(dv.q_ready && dv.active() && dv.pending && !dv.halted) {
                return;
            }
        }
        if !self.devs[d].dom_valid {
            self.devs[d].fatal(Fatal::NoDomain);
            return;
        }
        self.devs[d].pending = false;
        if let Err(f) = self.run_queue(d) {
            self.devs[d].fatal(f);
        }
    }

    fn run_queue(&mut self, d: usize) -> Result<(), Fatal> {
        loop {
            let (drv, qsz) = (self.devs[d].q_driver, self.devs[d].q_num as u16);
            let idx = self.gate_read(d, drv + 2, 2).map_err(|_| Fatal::RingDma)? as u16;
            let gap = idx.wrapping_sub(self.devs[d].last_avail);
            if gap as u32 > qsz as u32 {
                return Err(Fatal::AvailIdxJump);
            }
            if gap == 0 {
                return Ok(());
            }
            while self.devs[d].last_avail != idx {
                let slot = (self.devs[d].last_avail & (qsz.wrapping_sub(1))) as u64;
                let head = self.gate_read(d, drv + 4 + 2 * slot, 2).map_err(|_| Fatal::RingDma)? as u16;
                let chain = self.walk(d, head)?;
                let (status, used_len) = self.exec(d, &chain)?;
                let dev_base = self.devs[d].q_device;
                let uslot = (self.devs[d].used_idx & (qsz.wrapping_sub(1))) as u64;
                self.gate_write(d, dev_base + 4 + 8 * uslot, 4, head as u64).map_err(|_| Fatal::RingDma)?;
                self.gate_write(d, dev_base + 8 + 8 * uslot, 4, used_len as u64).map_err(|_| Fatal::RingDma)?;
                let nu = self.devs[d].used_idx.wrapping_add(1);
                self.gate_write(d, dev_base, 4, (nu as u64) << 16).map_err(|_| Fatal::RingDma)?;
                {
                    let dv = &mut self.devs[d];
                    dv.used_idx = nu;
                    dv.last_avail = dv.last_avail.wrapping_add(1);
                    dv.cnt.req += 1;
                    match status {
                        BLK_S_IOERR => dv.cnt.ioerr += 1,
                        BLK_S_UNSUPP => dv.cnt.unsupp += 1,
                        _ => {}
                    }
                }
                let flags = self.gate_read(d, drv, 2).map_err(|_| Fatal::RingDma)? as u16;
                let dv = &mut self.devs[d];
                if flags & 1 != 0 {
                    dv.cnt.irq_sup += 1;
                } else {
                    dv.cnt.irq += 1;
                    dv.int_status |= 1;
                }
            }
        }
    }

    /// Descriptor chain walk (spec 2.7.5 / 2.7.4 + device policy).
    pub fn walk(&mut self, d: usize, head: u16) -> Result<Chain, Fatal> {
        let qsz = self.devs[d].q_num;
        let max_chain = self.devs[d].max_chain;
        let desc_base = self.devs[d].q_desc;
        let mut c = Chain::default();
        let mut idx = head as u32;
        let mut visited = HashSet::new();
        let mut count = 0u32;
        let mut seen_w = false;
        loop {
            if idx >= qsz {
                return Err(Fatal::DescIdxOor);
            }
            if visited.contains(&idx) {
                return Err(Fatal::ChainLoop);
            }
            if count == max_chain {
                return Err(Fatal::ChainTooLong);
            }
            visited.insert(idx);
            count += 1;
            let a = desc_base + 16 * idx as u64;
            let w0 = self.gate_read(d, a, 8).map_err(|_| Fatal::RingDma)?;
            let w1 = self.gate_read(d, a + 8, 8).map_err(|_| Fatal::RingDma)?;
            self.devs[d].cnt.desc += 1;
            let addr = w0;
            let len = w1 as u32;
            let flags = (w1 >> 32) as u16;
            let next = (w1 >> 48) as u16;
            let write = flags & DESC_F_WRITE != 0;
            if flags & !(DESC_F_NEXT | DESC_F_WRITE) != 0 {
                return Err(Fatal::DescFlags);
            }
            if !write && seen_w {
                return Err(Fatal::ChainOrder);
            }
            if c.r_len + c.w_len + len as u64 >= 1u64 << 32 {
                return Err(Fatal::ChainLenOvf);
            }
            if len > 0 {
                let dv = &mut self.devs[d];
                if !range_allows(&dv.wins, dv.dom_valid, dv.dom, addr, len, write) {
                    dv.cnt.viol += 1;
                    if write {
                        return Err(Fatal::WritablePerm);
                    }
                    c.r_fault = true;
                }
                if write {
                    c.wsegs.push((addr, len));
                    c.w_len += len as u64;
                } else {
                    c.rsegs.push((addr, len));
                    c.r_len += len as u64;
                }
            }
            seen_w |= write;
            if flags & DESC_F_NEXT != 0 {
                idx = next as u32;
            } else {
                return Ok(c);
            }
        }
    }

    /// virtio-blk execution (spec 5.2.6 + device policy: the whole writable
    /// stream is always written; used length == writable length).
    #[allow(unused_assignments)]
    pub fn exec(&mut self, d: usize, c: &Chain) -> Result<(u8, u32), Fatal> {
        if c.wsegs.is_empty() {
            return Err(Fatal::NoStatus);
        }
        let rbytes: Vec<u64> = c.rsegs.iter().flat_map(|&(a, l)| (0..l as u64).map(move |i| a + i)).collect();
        let wbytes: Vec<u64> = c.wsegs.iter().flat_map(|&(a, l)| (0..l as u64).map(move |i| a + i)).collect();
        let w_len = wbytes.len();
        let data_w = w_len - 1;
        let mut wpos = 0usize;
        let mut status = BLK_S_OK;

        // writer for the W stream
        macro_rules! wput {
            ($b:expr) => {{
                let a = wbytes[wpos];
                if !self.data_byte_ok(a) {
                    return Err(Fatal::DataWriteDma);
                }
                self.mem[a as usize] = $b;
                wpos += 1;
            }};
        }

        if c.r_fault || rbytes.len() < 16 {
            status = BLK_S_IOERR;
        } else {
            // header
            let mut hdr = [0u8; 16];
            let mut hdr_ok = true;
            for i in 0..16 {
                if !self.data_byte_ok(rbytes[i]) {
                    hdr_ok = false;
                    break;
                }
                hdr[i] = self.mem[rbytes[i] as usize];
            }
            if !hdr_ok {
                status = BLK_S_IOERR;
            } else {
                let typ = u32::from_le_bytes(hdr[0..4].try_into().unwrap());
                let sector = u64::from_le_bytes(hdr[8..16].try_into().unwrap());
                let cap = self.devs[d].capacity;
                let range_ok = |len: u64| -> bool { len % 512 == 0 && sector <= cap && len / 512 <= cap - sector };
                match typ {
                    BLK_T_IN => {
                        if range_ok(data_w as u64) {
                            let s0 = sector * 512;
                            for i in 0..data_w {
                                let sa = s0 + i as u64;
                                if self.devs[d].bad.contains(&(sa / 512)) {
                                    status = BLK_S_IOERR;
                                    break;
                                }
                                let b = self.devs[d].stor[sa as usize];
                                wput!(b);
                            }
                        } else {
                            status = BLK_S_IOERR;
                        }
                    }
                    BLK_T_OUT => {
                        let out_len = rbytes.len() - 16;
                        if range_ok(out_len as u64) {
                            let s0 = sector * 512;
                            for i in 0..out_len {
                                let ga = rbytes[16 + i];
                                if !self.data_byte_ok(ga) {
                                    status = BLK_S_IOERR;
                                    break;
                                }
                                let sa = s0 + i as u64;
                                if self.devs[d].bad.contains(&(sa / 512)) {
                                    status = BLK_S_IOERR;
                                    break;
                                }
                                let b = self.mem[ga as usize];
                                self.devs[d].stor[sa as usize] = b;
                            }
                        } else {
                            status = BLK_S_IOERR;
                        }
                    }
                    BLK_T_FLUSH => {
                        if self.devs[d].drv_feat & (1 << BLK_F_FLUSH) != 0 {
                            self.devs[d].flushes += 1;
                        } else {
                            status = BLK_S_UNSUPP;
                        }
                    }
                    BLK_T_GET_ID => {
                        let n = data_w.min(20);
                        for i in 0..n {
                            wput!(BLK_ID[i]);
                        }
                    }
                    _ => status = BLK_S_UNSUPP,
                }
            }
        }
        while wpos < data_w {
            wput!(0);
        }
        wput!(status);
        Ok((status, w_len as u32))
    }
}

// ---------------------------------------------------------------------------
// unit tests of the model itself
// ---------------------------------------------------------------------------
#[cfg(test)]
mod tests {
    use super::*;

    fn platform() -> Platform {
        let mut p = Platform { mem: vec![0; 1 << 20], devs: vec![Device::new(0, 256, 16, 8, 64, 1)] };
        p.mgmt_write(0, 0x010, 0x8000_0001);
        for (o, v) in [(0x44u32, 1u32), (0x48, 0), (0x4c, 0), (0x50, 0xfffff), (0x54, 0), (0x40, 7)] {
            p.mgmt_write(0, o, v);
        }
        p
    }

    fn put_desc(p: &mut Platform, base: u64, i: u64, addr: u64, len: u32, flags: u16, next: u16) {
        let a = (base + 16 * i) as usize;
        p.mem[a..a + 8].copy_from_slice(&addr.to_le_bytes());
        p.mem[a + 8..a + 12].copy_from_slice(&len.to_le_bytes());
        p.mem[a + 12..a + 14].copy_from_slice(&flags.to_le_bytes());
        p.mem[a + 14..a + 16].copy_from_slice(&next.to_le_bytes());
    }

    fn bring_up(p: &mut Platform, qsz: u32) {
        p.mmio_write(0, 0x070, ST_ACK);
        p.mmio_write(0, 0x070, ST_ACK | ST_DRIVER);
        p.mmio_write(0, 0x024, 1);
        p.mmio_write(0, 0x020, 3);
        p.mmio_write(0, 0x070, ST_ACK | ST_DRIVER | ST_FEATURES_OK);
        assert!(p.devs[0].status & ST_FEATURES_OK != 0);
        p.mmio_write(0, 0x038, qsz);
        p.mmio_write(0, 0x080, 0x1000);
        p.mmio_write(0, 0x090, 0x2000);
        p.mmio_write(0, 0x0a0, 0x3000);
        p.mmio_write(0, 0x044, 1);
        p.mmio_write(0, 0x070, ST_ACK | ST_DRIVER | ST_FEATURES_OK | ST_DRIVER_OK);
    }

    #[test]
    fn features_ok_refused_without_access_platform() {
        let mut p = platform();
        p.mmio_write(0, 0x070, ST_ACK | ST_DRIVER);
        p.mmio_write(0, 0x024, 1);
        p.mmio_write(0, 0x020, 1); // VERSION_1 only
        p.mmio_write(0, 0x070, ST_ACK | ST_DRIVER | ST_FEATURES_OK);
        assert_eq!(p.devs[0].status & ST_FEATURES_OK, 0);
    }

    #[test]
    fn write_then_read_roundtrip() {
        let mut p = platform();
        bring_up(&mut p, 8);
        // OUT: hdr @0x5000, data @0x6000 (512 B), status @0x7000
        p.mem[0x5000..0x5004].copy_from_slice(&BLK_T_OUT.to_le_bytes());
        p.mem[0x5008..0x5010].copy_from_slice(&3u64.to_le_bytes());
        for i in 0..512 {
            p.mem[0x6000 + i] = (i * 3) as u8;
        }
        put_desc(&mut p, 0x1000, 0, 0x5000, 16, DESC_F_NEXT, 1);
        put_desc(&mut p, 0x1000, 1, 0x6000, 512, DESC_F_NEXT, 2);
        put_desc(&mut p, 0x1000, 2, 0x7000, 1, DESC_F_WRITE, 0);
        p.mem[0x2004..0x2006].copy_from_slice(&0u16.to_le_bytes());
        p.mem[0x2002..0x2004].copy_from_slice(&1u16.to_le_bytes());
        p.mmio_write(0, 0x050, 0);
        assert!(!p.devs[0].needs_reset);
        assert_eq!(p.mem[0x7000], BLK_S_OK);
        assert_eq!(&p.devs[0].stor[3 * 512..3 * 512 + 4], &[0, 3, 6, 9]);
        assert_eq!(u16::from_le_bytes([p.mem[0x3002], p.mem[0x3003]]), 1);
        assert_eq!(u32::from_le_bytes(p.mem[0x3008..0x300c].try_into().unwrap()), 1);
    }

    #[test]
    fn loop_detected() {
        let mut p = platform();
        bring_up(&mut p, 8);
        put_desc(&mut p, 0x1000, 0, 0x5000, 16, DESC_F_NEXT, 1);
        put_desc(&mut p, 0x1000, 1, 0x5000, 16, DESC_F_NEXT, 0);
        p.mem[0x2002] = 1;
        p.mmio_write(0, 0x050, 0);
        assert!(p.devs[0].needs_reset);
        assert_eq!(p.devs[0].last_cause, Fatal::ChainLoop as u8);
    }

    #[test]
    fn perm_ranges() {
        let w = [Window { valid: true, r: true, w: false, dom: 3, base: 0x100, limit: 0x1ff }];
        assert!(range_allows(&w, true, 3, 0x100, 0x100, false));
        assert!(!range_allows(&w, true, 3, 0x100, 0x101, false));
        assert!(!range_allows(&w, true, 4, 0x100, 1, false));
        assert!(!range_allows(&w, true, 3, 0x100, 1, true));
        assert!(!range_allows(&w, false, 3, 0x100, 1, false));
        assert!(!range_allows(&w, true, 3, u64::MAX, 2, false));
    }

    #[test]
    fn avail_jump_is_fatal() {
        let mut p = platform();
        bring_up(&mut p, 8);
        p.mem[0x2002] = 9; // 9 > queue size 8
        p.mmio_write(0, 0x050, 0);
        assert_eq!(p.devs[0].last_cause, Fatal::AvailIdxJump as u8);
    }
}
