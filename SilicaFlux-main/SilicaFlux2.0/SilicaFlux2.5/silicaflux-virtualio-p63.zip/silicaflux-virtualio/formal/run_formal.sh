#!/usr/bin/env bash
# Formal verification of the domain permission gate (yosys-smtbmc + z3).
#   1. BMC from reset, depth 6 (bounded proof of A1..A6 over all inputs)
#   2. cover: denial and forwarded-write traces are reachable
#   3. k-induction attempt, depth 4 (unbounded proof; see docs/04 §4)
set -uo pipefail
cd "$(dirname "$0")"
mkdir -p out
sv2v ../rtl/silicaflux_virtio_pkg.sv ../rtl/silicaflux_virtio_domain_perm.sv > out/dp.v
yosys -q -l out/yosys.log -p "read_verilog -formal out/dp.v; read_verilog -formal -sv fv_domain_perm.sv; \
  prep -top fv_domain_perm; async2sync; dffunmap; write_smt2 out/fv.smt2"
echo "== BMC depth 6 =="; yosys-smtbmc -s z3 -t 6 --dump-vcd out/bmc_fail.vcd out/fv.smt2 > out/bmc.log 2>&1; echo "rc=$?"; tail -1 out/bmc.log
echo "== cover depth 6 =="; yosys-smtbmc -s z3 -c -t 6 out/fv.smt2 > out/cover.log 2>&1; echo "rc=$?"; grep -E "Reached cover|PASSED|FAILED|Unreached" out/cover.log | tail -4
echo "== k-induction depth 4 =="; yosys-smtbmc -s z3 -i -t 4 --dump-vcd out/ind_fail.vcd out/fv.smt2 > out/induction.log 2>&1; echo "rc=$?"; tail -3 out/induction.log
echo FORMAL_DONE
