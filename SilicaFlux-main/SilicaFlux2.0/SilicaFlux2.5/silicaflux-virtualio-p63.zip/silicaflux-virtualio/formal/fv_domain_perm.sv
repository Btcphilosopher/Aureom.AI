// fv_domain_perm.sv — formal harness for silicaflux_virtio_domain_perm
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Proves, for all input sequences (N_WIN = 2, full 64-bit addresses):
//   A1  every downstream request lies entirely inside ONE valid window whose
//       domain tag equals the bound domain and which grants the direction
//       (checked against an independent shadow table built from cfg writes)
//   A2  downstream requests are byte-exact copies of the accepted upstream
//       request (no widening of address / byte enables / direction / data)
//   A3  the downstream domain tag equals the bound domain
//   A4  exactly one upstream response per accepted request, never spurious
//   A5  no false denials: a denied request (error without forwarding) was
//       NOT permitted by the shadow table
//   A6  the walker pre-check port (chk_ok) is sound: it only reports ok for
//       non-empty, non-wrapping ranges inside one matching window
// Environment assumptions (guaranteed by the engine, see docs/01):
//   E1 the upstream issues at most one request at a time (dma_arb)
//   E2 the permission table and domain binding do not change while a request
//      is in the gate (hypervisor quiesce rule, docs/01 §6)
//   E3 downstream responses only answer an outstanding downstream request
module fv_domain_perm (
  input clk,
  input rst_n,
  input cfg_we, input cfg_win, input [2:0] cfg_field, input [31:0] cfg_wdata,
  input cfg_rwin, input [2:0] cfg_rfield,
  input [15:0] domain, input domain_valid,
  input [63:0] chk_addr, input [31:0] chk_len, input chk_write,
  input up_req_valid, input [63:0] up_req_addr, input up_req_we, input [63:0] up_req_wdata, input [7:0] up_req_be,
  input dn_req_ready, input dn_resp_valid, input [63:0] dn_resp_rdata, input dn_resp_err
);
  wire up_req_ready, up_resp_valid, up_resp_err, dn_req_valid, dn_req_we, chk_ok, viol_pulse, viol_write;
  wire [63:0] up_resp_rdata, dn_req_addr, dn_req_wdata, viol_addr;
  wire [7:0] dn_req_be;
  wire [15:0] dn_req_domain;
  wire [31:0] cfg_rdata;

  silicaflux_virtio_domain_perm #(.N_WIN(2)) dut (
    .clk(clk), .rst_n(rst_n), .cfg_we(cfg_we), .cfg_win(cfg_win), .cfg_field(cfg_field), .cfg_wdata(cfg_wdata),
    .cfg_rwin(cfg_rwin), .cfg_rfield(cfg_rfield), .cfg_rdata(cfg_rdata), .domain(domain), .domain_valid(domain_valid),
    .chk_addr(chk_addr), .chk_len(chk_len), .chk_write(chk_write), .chk_ok(chk_ok),
    .up_req_valid(up_req_valid), .up_req_ready(up_req_ready), .up_req_addr(up_req_addr), .up_req_we(up_req_we),
    .up_req_wdata(up_req_wdata), .up_req_be(up_req_be), .up_resp_valid(up_resp_valid), .up_resp_rdata(up_resp_rdata),
    .up_resp_err(up_resp_err), .dn_req_valid(dn_req_valid), .dn_req_ready(dn_req_ready), .dn_req_addr(dn_req_addr),
    .dn_req_we(dn_req_we), .dn_req_wdata(dn_req_wdata), .dn_req_be(dn_req_be), .dn_req_domain(dn_req_domain),
    .dn_resp_valid(dn_resp_valid), .dn_resp_rdata(dn_resp_rdata), .dn_resp_err(dn_resp_err),
    .viol_pulse(viol_pulse), .viol_addr(viol_addr), .viol_write(viol_write));

  // ---- reset: low in the first cycle, high afterwards --------------------------
  reg init = 1'b1;
  always @(posedge clk) init <= 1'b0;
  always @(*) begin
    if (init) assume(!rst_n);
    else assume(rst_n);
  end

  // ---- independent shadow permission table -------------------------------------
  reg        sv [0:1], sr [0:1], sw [0:1];
  reg [15:0] sd [0:1];
  reg [63:0] sb [0:1], sl [0:1];
  integer i;
  always @(posedge clk) begin
    if (!rst_n) begin
      for (i = 0; i < 2; i = i + 1) begin sv[i] <= 0; sr[i] <= 0; sw[i] <= 0; sd[i] <= 0; sb[i] <= 0; sl[i] <= 0; end
    end else if (cfg_we) begin
      case (cfg_field)
        3'd0: begin sv[cfg_win] <= cfg_wdata[0]; sr[cfg_win] <= cfg_wdata[1]; sw[cfg_win] <= cfg_wdata[2]; end
        3'd1: sd[cfg_win] <= cfg_wdata[15:0];
        3'd2: sb[cfg_win][31:0] <= cfg_wdata;
        3'd3: sb[cfg_win][63:32] <= cfg_wdata;
        3'd4: sl[cfg_win][31:0] <= cfg_wdata;
        3'd5: sl[cfg_win][63:32] <= cfg_wdata;
        default: ;
      endcase
    end
  end
  function shadow_ok(input [63:0] lo, input [63:0] hi, input wr);
    integer k;
    begin
      shadow_ok = 1'b0;
      for (k = 0; k < 2; k = k + 1)
        if (domain_valid && sv[k] && sd[k] == domain && lo <= hi && lo >= sb[k] && hi <= sl[k] && (wr ? sw[k] : sr[k]))
          shadow_ok = 1'b1;
    end
  endfunction
  function [2:0] first_lane(input [7:0] be);
    integer k;
    begin first_lane = 0; for (k = 7; k >= 0; k = k - 1) if (be[k]) first_lane = k; end
  endfunction
  function [2:0] last_lane(input [7:0] be);
    integer k;
    begin last_lane = 0; for (k = 0; k < 8; k = k + 1) if (be[k]) last_lane = k; end
  endfunction

  // ---- upstream / downstream bookkeeping ---------------------------------------
  reg        busy, fwd;          // request inside the gate / already forwarded
  reg        dn_out;             // downstream request outstanding
  reg [63:0] c_addr, c_wdata;
  reg        c_we;
  reg [7:0]  c_be;
  wire up_acc = up_req_valid && up_req_ready;
  wire dn_acc = dn_req_valid && dn_req_ready;
  always @(posedge clk) begin
    if (!rst_n) begin
      busy <= 0; fwd <= 0; dn_out <= 0; c_addr <= 0; c_wdata <= 0; c_we <= 0; c_be <= 0;
    end else begin
      if (up_acc) begin busy <= 1; fwd <= 0; c_addr <= up_req_addr; c_wdata <= up_req_wdata; c_we <= up_req_we; c_be <= up_req_be; end
      if (dn_acc) begin fwd <= 1; dn_out <= 1; end
      if (dn_resp_valid) dn_out <= 0;
      if (up_resp_valid) busy <= 0;
    end
  end

  // ---- environment assumptions ---------------------------------------------------
  always @(*) if (rst_n && !init) begin
    if (busy) assume(!up_req_valid);                                     // E1
    if (busy || up_req_valid) assume(!cfg_we);                           // E2 (table)
    if (!dn_out) assume(!dn_resp_valid);                                 // E3
  end
  reg [15:0] p_dom; reg p_dv;
  always @(posedge clk) begin p_dom <= domain; p_dv <= domain_valid; end
  always @(*) if (rst_n && !init && busy) assume(domain == p_dom && domain_valid == p_dv);   // E2 (binding)

  // ---- properties --------------------------------------------------------------------
  wire [63:0] dlo = {dn_req_addr[63:3], first_lane(dn_req_be)};
  wire [63:0] dhi = {dn_req_addr[63:3], last_lane(dn_req_be)};
  wire [64:0] cend = {1'b0, chk_addr} + {33'd0, chk_len} - 65'd1;
  always @(*) if (rst_n && !init) begin
    if (dn_req_valid) begin
      assert(shadow_ok(dlo, dhi, dn_req_we));                                         // A1
      assert(dn_req_be != 8'd0 && dn_req_addr[2:0] == 3'd0);
      assert(busy && dn_req_addr == c_addr && dn_req_be == c_be && dn_req_we == c_we && dn_req_wdata == c_wdata); // A2
      assert(dn_req_domain == domain);                                                // A3
    end
    if (up_resp_valid) assert(busy);                                                  // A4
    if (busy) assert(!up_req_ready);
    if (up_resp_valid && up_resp_err && !fwd)                                          // A5
      assert(!(c_be != 0 && c_addr[2:0] == 0 && c_be == ((8'hff >> (7 - last_lane(c_be))) & (8'hff << first_lane(c_be)))
               && shadow_ok({c_addr[63:3], first_lane(c_be)}, {c_addr[63:3], last_lane(c_be)}, c_we)));
    if (chk_ok)                                                                         // A6
      assert(chk_len != 0 && !cend[64] && shadow_ok(chk_addr, cend[63:0], chk_write));
  end
  // the gate can always make progress: a held request is resolved within 2 cycles
  // (reachability cover, checked by BMC)
  always @(*) if (rst_n && !init) cover(up_resp_valid && up_resp_err && !fwd);
  always @(*) if (rst_n && !init) cover(dn_acc && dn_req_we);
endmodule
