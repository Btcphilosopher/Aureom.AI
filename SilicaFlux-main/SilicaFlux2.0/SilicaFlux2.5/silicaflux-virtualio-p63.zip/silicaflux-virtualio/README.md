# SilicaFlux Project 63 — VIRTUALIO

### Virtual-machine I/O acceleration · Aureom.AI | SilicaFlux-CLOUD

A synthesizable VirtIO block-device engine for the SilicaFlux CloudDPU. A guest's virtio driver submits requests on a **split virtqueue**. The engine walks and validates the descriptors and executes the request against a StorageCore port. Every host-memory access is checked against a **tenant permission table**. The engine then publishes the completion on the used ring.

**Primary RTL:** `rtl/silicaflux_virtio_engine.sv` · **Normative reference:** OASIS VirtIO 1.2 (cs01)

## What v1.0 implements and what it deliberately doesn't

| | |
|---|---|
| Device | virtio-blk (ID 2), one requestq |
| Transport | virtio-mmio version 2 (spec §4.2) |
| Ring | split virtqueue, Queue Size ≤ 256 (parameter, up to 32768) |
| Offered features | VERSION_1, ACCESS_PLATFORM, BLK_F_SEG_MAX, BLK_F_FLUSH |
| Requests | IN, OUT, FLUSH, GET_ID; everything else returns VIRTIO_BLK_S_UNSUPP |
| **Not offered** | packed rings, indirect descriptors, EVENT_IDX, multiqueue, NOTIFICATION_DATA, RING_RESET, DISCARD/WRITE_ZEROES; virtio-pci transport |
| Protection | each queue is bound to a domain by the hypervisor only; every DMA beat must fall inside one window with the matching domain and the right direction; the domain tag alone grants nothing |

The full clause-by-clause mapping is in `docs/03_conformance_checklist.md`.

## Results

| | |
|---|---|
| Directed co-simulation | 23/23 pass on two parameterisations, Rust-model checked |
| Random regression | 1,400 scenarios, ≈ 49,000 completions, byte-exact against the model |
| Mutation testing | 16/16 injected RTL faults detected |
| Pure-SV testbench | 21/21 checks |
| Definition of done | `make example`: VM driver → engine → protected backend → correct completion; out-of-domain buffer refused |
| Synthesis | ECP5-85F: 45.9k LUT4 (54 %), 6.1k FF; **not timing-closed** (≈ 20 MHz post-placement) |
| Throughput | ≈ 0.8 B/cycle aligned, single outstanding DMA (baseline; roadmap in `docs/06`) |

## Layout

```
rtl/         SystemVerilog engine (9 files, filelist.f)
host/        C host library libsfvirtio (driver + hypervisor helpers)
sim/         Verilator co-simulation: platform models, tests, monitor, mutation script, C-ABI sim transport
refmodel/    Rust independent reference model + sfv-refcheck
tb/sv/       self-checking pure-SystemVerilog testbench
examples/    host_example.c (definition-of-done demonstration)
formal/      formal harness for the permission gate (yosys-smtbmc + z3)
synth/       synthesis + P&R scripts, OOC wrapper
docs/        audit, architecture, register map, conformance, verification, synthesis, performance
reports/     logs from the final runs
```

## Quick start

Requirements: Verilator ≥ 5.0, a C/C++ compiler, Rust/cargo, and for `synth`/`formal` also sv2v, Yosys, nextpnr-ecp5 and z3.

```
make lint          # Verilator -Wall on the RTL
make hostlib       # libsfvirtio.a, strict C99
make refmodel      # build + unit-test the Rust model
make test          # directed suite, default config, model-checked
make regress ITERS=1000
make regress-small # second parameterisation
make example       # definition-of-done demo
make svtb          # pure-SystemVerilog testbench
make perf          # performance sweep -> reports/perf_sweep.txt
make formal        # permission-gate formal run
make synth         # Yosys + nextpnr-ecp5
bash sim/mutation_test.sh   # mutation testing (slow: one rebuild per mutant)
```

## Honest limits

- No CloudDPU, PCIe, StorageCore or NetworkCore sources existed to integrate with, so the engine defines those interfaces (`docs/00_repository_audit.md`).
- It has not been run against a production guest driver (Linux `virtio_blk`). That needs hardware or a VMM bridge.
- It is not timing-closed, and throughput is a functional baseline. Both have concrete plans in `docs/05` and `docs/06`.
- The formal status of the permission gate is stated in `docs/04_verification.md` §5.
