/*
 * sfv_blk.c — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
 *
 * virtio-blk driver layer (spec 5.2) on top of sfv_core.c, plus hypervisor
 * helpers for the privileged management window.
 */
#include <string.h>
#include "sfvirtio.h"

#define SLOT_BYTES 32u   /* per head: 16-byte header @0, status byte @16, ID scratch @20.. */

static uint64_t slot_iova(sfv_blk_t *b, uint16_t head) { return b->pool_iova + (uint64_t)SLOT_BYTES * head; }

int sfv_blk_open(sfv_blk_t *b, const sfv_transport_t *t, uint16_t qsize) {
  memset(b, 0, sizeof *b);
  int r = sfv_dev_probe(&b->dev, t);
  if (r) return r;
  if (b->dev.device_id != VIRTIO_ID_BLOCK) return SFV_E_NODEV;
  if ((r = sfv_dev_reset(&b->dev))) return r;

  const uint64_t wanted = SFV_FEAT(VIRTIO_F_VERSION_1) | SFV_FEAT(VIRTIO_F_ACCESS_PLATFORM) |
                          SFV_FEAT(VIRTIO_BLK_F_SEG_MAX) | SFV_FEAT(VIRTIO_BLK_F_FLUSH);
  const uint64_t required = SFV_FEAT(VIRTIO_F_VERSION_1) | SFV_FEAT(VIRTIO_F_ACCESS_PLATFORM);
  if ((r = sfv_dev_negotiate(&b->dev, wanted, required))) return r;
  b->has_flush = (b->dev.drv_features & SFV_FEAT(VIRTIO_BLK_F_FLUSH)) != 0;

  /* 4.2.2: read multi-word config consistently using ConfigGeneration */
  uint32_t g0, g1, lo, hi;
  do {
    g0 = t->mmio_read32(t->ctx, VIRTIO_MMIO_CONFIG_GENERATION);
    lo = sfv_dev_config_read32(&b->dev, VIRTIO_BLK_CFG_CAPACITY);
    hi = sfv_dev_config_read32(&b->dev, VIRTIO_BLK_CFG_CAPACITY + 4);
    g1 = t->mmio_read32(t->ctx, VIRTIO_MMIO_CONFIG_GENERATION);
  } while (g0 != g1);
  b->capacity = ((uint64_t)hi << 32) | lo;
  if (b->dev.drv_features & SFV_FEAT(VIRTIO_BLK_F_SEG_MAX))
    b->seg_max = sfv_dev_config_read32(&b->dev, VIRTIO_BLK_CFG_SEG_MAX);

  if ((r = sfv_vq_setup(&b->dev, &b->vq, 0, qsize))) return r;
  if (t->dma_alloc(t->ctx, (size_t)SLOT_BYTES * qsize, 8, &b->pool_iova)) return SFV_E_NOMEM;
  return sfv_dev_driver_ok(&b->dev);
}

void sfv_blk_close(sfv_blk_t *b) { sfv_vq_destroy(&b->vq); }

int sfv_blk_status_to_err(uint8_t s) {
  switch (s) {
    case VIRTIO_BLK_S_OK: return SFV_OK;
    case VIRTIO_BLK_S_IOERR: return SFV_E_IO;
    case VIRTIO_BLK_S_UNSUPP: return SFV_E_UNSUPP;
    default: return SFV_E_PROTOCOL;
  }
}

int sfv_blk_submit(sfv_blk_t *b, uint32_t type, uint64_t sector,
                   const sfv_sg_t *data, unsigned ndata, void *cookie, uint16_t *head) {
  const sfv_transport_t *t = b->dev.t;
  if (b->seg_max && ndata > b->seg_max) return SFV_E_INVAL;
  if (ndata + 2 > b->vq.num_free) return SFV_E_NOSPC;
  if (ndata + 2 > 64) return SFV_E_INVAL;

  uint16_t h = b->vq.free_head;            /* head the chain will start at */
  uint8_t hdr[16];
  memset(hdr, 0, sizeof hdr);
  for (int i = 0; i < 4; i++) hdr[i] = (uint8_t)(type >> (8 * i));
  for (int i = 0; i < 8; i++) hdr[8 + i] = (uint8_t)(sector >> (8 * i));
  t->mem_write(t->ctx, slot_iova(b, h), hdr, 16);
  uint8_t sentinel = 0xa5;                 /* detects a device that never writes status */
  t->mem_write(t->ctx, slot_iova(b, h) + 16, &sentinel, 1);

  sfv_sg_t sg[64];
  unsigned n = 0;
  sg[n++] = (sfv_sg_t){slot_iova(b, h), 16, 0};
  for (unsigned i = 0; i < ndata; i++) sg[n++] = data[i];
  sg[n++] = (sfv_sg_t){slot_iova(b, h) + 16, 1, 1};
  return sfv_vq_add(&b->vq, sg, n, cookie, head);
}

int sfv_blk_poll(sfv_blk_t *b, sfv_blk_completion_t *c) {
  const sfv_transport_t *t = b->dev.t;
  uint16_t h;
  uint32_t len;
  void *ck;
  int r = sfv_vq_get_used(&b->vq, &h, &len, &ck);
  if (r <= 0) return r;
  uint8_t st;
  t->mem_read(t->ctx, slot_iova(b, h) + 16, &st, 1);
  c->head = h;
  c->used_len = len;
  c->status = st;
  c->cookie = ck;
  return 1;
}

int sfv_blk_wait(sfv_blk_t *b, sfv_blk_completion_t *c, uint32_t budget) {
  const sfv_transport_t *t = b->dev.t;
  for (;;) {
    int r = sfv_blk_poll(b, c);
    if (r != 0) return r;
    if (sfv_dev_check(&b->dev)) return SFV_E_NEEDS_RESET;
    if (budget == 0) return SFV_E_TIMEOUT;
    uint32_t step = budget < 64 ? budget : 64;
    if (t->wait_irq(t->ctx, step)) sfv_dev_ack_interrupt(&b->dev);
    budget -= step;
  }
}

static int sync_req(sfv_blk_t *b, uint32_t type, uint64_t sector, const sfv_sg_t *sg,
                    unsigned n, uint8_t *status) {
  uint16_t h;
  sfv_blk_completion_t c;
  int r = sfv_blk_submit(b, type, sector, sg, n, NULL, &h);
  if (r) return r;
  sfv_vq_kick(&b->vq);
  r = sfv_blk_wait(b, &c, 50u * 1000u * 1000u);
  if (r < 0) return r;
  if (c.head != h) return SFV_E_PROTOCOL;   /* single outstanding: must match */
  if (status) *status = c.status;
  return sfv_blk_status_to_err(c.status);
}

int sfv_blk_rw_sync(sfv_blk_t *b, int write, uint64_t sector, uint64_t buf, uint32_t len,
                    uint8_t *status) {
  sfv_sg_t sg = {buf, len, (uint8_t)(write ? 0 : 1)};
  return sync_req(b, write ? VIRTIO_BLK_T_OUT : VIRTIO_BLK_T_IN, sector, &sg, len ? 1 : 0, status);
}

int sfv_blk_flush_sync(sfv_blk_t *b, uint8_t *status) {
  return sync_req(b, VIRTIO_BLK_T_FLUSH, 0, NULL, 0, status);
}

int sfv_blk_get_id_sync(sfv_blk_t *b, char id[VIRTIO_BLK_ID_BYTES + 1]) {
  const sfv_transport_t *t = b->dev.t;
  uint64_t buf;
  if (t->dma_alloc(t->ctx, VIRTIO_BLK_ID_BYTES, 4, &buf)) return SFV_E_NOMEM;
  sfv_sg_t sg = {buf, VIRTIO_BLK_ID_BYTES, 1};
  uint8_t st;
  int r = sync_req(b, VIRTIO_BLK_T_GET_ID, 0, &sg, 1, &st);
  if (r) return r;
  t->mem_read(t->ctx, buf, id, VIRTIO_BLK_ID_BYTES);
  id[VIRTIO_BLK_ID_BYTES] = 0;
  return SFV_OK;
}

/* ---- hypervisor helpers ------------------------------------------------------------ */
int sfv_hv_probe(const sfv_mgmt_transport_t *m, uint32_t *version, uint32_t *caps0) {
  if (m->read32(m->ctx, SFV_MGMT_ENGINE_ID) != 0x53465649u) return SFV_E_NODEV;
  uint32_t v = m->read32(m->ctx, SFV_MGMT_ENGINE_VER);
  if (((v >> 16) & 0xff) != 1) return SFV_E_VERSION;     /* major version gate */
  if (version) *version = v;
  if (caps0) *caps0 = m->read32(m->ctx, SFV_MGMT_CAPS0);
  return SFV_OK;
}

void sfv_hv_bind_domain(const sfv_mgmt_transport_t *m, uint16_t domain) {
  m->write32(m->ctx, SFV_MGMT_Q0_DOMAIN, 0x80000000u | domain);
}

void sfv_hv_unbind_domain(const sfv_mgmt_transport_t *m) {
  m->write32(m->ctx, SFV_MGMT_Q0_DOMAIN, 0);
}

void sfv_hv_set_window(const sfv_mgmt_transport_t *m, unsigned w, uint16_t domain,
                       uint64_t base, uint64_t limit, int rdp, int wrp) {
  /* invalidate first so a half-programmed window is never live */
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_CTRL), 0);
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_DOMAIN), domain);
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_BASE_LO), (uint32_t)base);
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_BASE_HI), (uint32_t)(base >> 32));
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_LIMIT_LO), (uint32_t)limit);
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_LIMIT_HI), (uint32_t)(limit >> 32));
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_CTRL), 1u | (rdp ? 2u : 0u) | (wrp ? 4u : 0u));
}

void sfv_hv_clear_window(const sfv_mgmt_transport_t *m, unsigned w) {
  m->write32(m->ctx, SFV_MGMT_WIN(w, SFV_WIN_CTRL), 0);
}

uint32_t sfv_hv_perf32(const sfv_mgmt_transport_t *m, uint32_t off) {
  return m->read32(m->ctx, SFV_MGMT_PERF(off));
}

uint64_t sfv_hv_perf64(const sfv_mgmt_transport_t *m, uint32_t off) {
  uint32_t hi0, lo, hi1;
  do {   /* tolerate a carry between the two halves */
    hi0 = m->read32(m->ctx, SFV_MGMT_PERF(off + 4));
    lo  = m->read32(m->ctx, SFV_MGMT_PERF(off));
    hi1 = m->read32(m->ctx, SFV_MGMT_PERF(off + 4));
  } while (hi0 != hi1);
  return ((uint64_t)hi1 << 32) | lo;
}

uint8_t sfv_hv_fatal_cause(const sfv_mgmt_transport_t *m) {
  return (uint8_t)(m->read32(m->ctx, SFV_MGMT_ENGINE_STATUS) >> 8);
}
