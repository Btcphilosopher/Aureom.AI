/*
 * sfvirtio.h — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
 *
 * Minimal host integration library for the SilicaFlux VirtIO engine.
 *
 *  - Guest side (the "VM driver"): virtio-mmio v2 transport, feature
 *    negotiation (spec 3.1.1), one split virtqueue, virtio-blk requests.
 *  - Hypervisor side (sfv_hv_*): domain binding, permission windows and
 *    performance counters through the privileged management window.
 *
 * The library never touches hardware directly. All register and memory
 * accesses go through an sfv_transport_t, so the same code runs against the
 * Verilator co-simulation (sim/sfv_sim_transport.cpp) or a real platform
 * transport (MMIO mapping + DMA-coherent memory).
 */
#ifndef SFVIRTIO_H
#define SFVIRTIO_H

#include <stddef.h>
#include <stdint.h>
#include "sfv_regs.h"

#ifdef __cplusplus
extern "C" {
#endif

/* ---- error codes ------------------------------------------------------------ */
enum {
  SFV_OK            = 0,
  SFV_E_NODEV       = -1,   /* bad magic / device id                        */
  SFV_E_VERSION     = -2,   /* not virtio-mmio version 2                    */
  SFV_E_FEATURES    = -3,   /* required feature missing / FEATURES_OK refused */
  SFV_E_QUEUE       = -4,   /* queue unavailable / bad size                 */
  SFV_E_NOSPC       = -5,   /* not enough free descriptors                  */
  SFV_E_NEEDS_RESET = -6,   /* device reported DEVICE_NEEDS_RESET            */
  SFV_E_TIMEOUT     = -7,
  SFV_E_INVAL       = -8,
  SFV_E_NOMEM       = -9,
  SFV_E_IO          = -10,  /* request completed with VIRTIO_BLK_S_IOERR     */
  SFV_E_UNSUPP      = -11,  /* request completed with VIRTIO_BLK_S_UNSUPP    */
  SFV_E_PROTOCOL    = -12   /* device violated the protocol (bad used entry) */
};

/* ---- transport ----------------------------------------------------------------- */
typedef struct sfv_transport {
  void *ctx;
  /* guest-visible virtio-mmio window */
  uint32_t (*mmio_read32)(void *ctx, uint32_t off);
  void     (*mmio_write32)(void *ctx, uint32_t off, uint32_t val);
  /* guest memory (IOVA space shared with the device) */
  int      (*dma_alloc)(void *ctx, size_t size, size_t align, uint64_t *iova);
  void     (*mem_write)(void *ctx, uint64_t iova, const void *src, size_t len);
  void     (*mem_read)(void *ctx, uint64_t iova, void *dst, size_t len);
  void     (*mb)(void *ctx);                 /* full barrier between driver and device views */
  /* wait for the interrupt line or until `budget` transport units elapse;
     returns non-zero if the interrupt line is asserted */
  int      (*wait_irq)(void *ctx, uint32_t budget);
} sfv_transport_t;

/* privileged management window (hypervisor / ControlCore) */
typedef struct sfv_mgmt_transport {
  void *ctx;
  uint32_t (*read32)(void *ctx, uint32_t off);
  void     (*write32)(void *ctx, uint32_t off, uint32_t val);
} sfv_mgmt_transport_t;

/* ---- scatter-gather element ----------------------------------------------------- */
typedef struct sfv_sg {
  uint64_t addr;            /* IOVA                                  */
  uint32_t len;
  uint8_t  device_writable; /* 1 => VIRTQ_DESC_F_WRITE              */
} sfv_sg_t;

/* ---- split virtqueue (driver side) ---------------------------------------------- */
typedef struct sfv_vq {
  struct sfv_dev *dev;
  uint16_t index;
  uint16_t size;
  uint64_t desc_iova, avail_iova, used_iova;
  uint16_t avail_idx;    /* next avail.idx to publish            */
  uint16_t last_used;    /* next used entry to consume           */
  uint16_t free_head;
  uint16_t num_free;
  uint16_t *next;        /* driver-private free list / chain links (size entries) */
  uint16_t *chain_len;   /* descriptors per in-flight head                       */
  void    **cookie;      /* caller cookie per in-flight head                     */
  uint16_t avail_flags;
} sfv_vq_t;

typedef struct sfv_dev {
  const sfv_transport_t *t;
  uint32_t device_id, vendor_id;
  uint64_t dev_features;
  uint64_t drv_features;
  sfv_vq_t *vq;
} sfv_dev_t;

/* ---- device lifecycle (spec 3.1.1) ------------------------------------------------ */
int      sfv_dev_probe(sfv_dev_t *d, const sfv_transport_t *t);
int      sfv_dev_reset(sfv_dev_t *d);
int      sfv_dev_negotiate(sfv_dev_t *d, uint64_t wanted, uint64_t required);
int      sfv_vq_setup(sfv_dev_t *d, sfv_vq_t *vq, uint16_t qidx, uint16_t size);
void     sfv_vq_destroy(sfv_vq_t *vq);
int      sfv_dev_driver_ok(sfv_dev_t *d);
uint8_t  sfv_dev_status(sfv_dev_t *d);
int      sfv_dev_check(sfv_dev_t *d);         /* SFV_E_NEEDS_RESET if set */
uint32_t sfv_dev_ack_interrupt(sfv_dev_t *d); /* returns InterruptStatus  */
uint32_t sfv_dev_config_read32(sfv_dev_t *d, uint32_t off);

/* ---- virtqueue operations ----------------------------------------------------------- */
int  sfv_vq_add(sfv_vq_t *vq, const sfv_sg_t *sg, unsigned nsg, void *cookie, uint16_t *head);
void sfv_vq_kick(sfv_vq_t *vq);
int  sfv_vq_get_used(sfv_vq_t *vq, uint16_t *head, uint32_t *len, void **cookie);
void sfv_vq_set_no_interrupt(sfv_vq_t *vq, int suppress);
uint16_t sfv_vq_device_used_idx(sfv_vq_t *vq);

/* ---- virtio-blk ------------------------------------------------------------------------ */
typedef struct sfv_blk {
  sfv_dev_t dev;
  sfv_vq_t  vq;
  uint64_t  capacity;       /* sectors */
  uint32_t  seg_max;        /* data segments per request (0 if not offered) */
  uint64_t  pool_iova;      /* per-head header(16) + status(1) slots, 32 B each */
  int       has_flush;
} sfv_blk_t;

typedef struct sfv_blk_completion {
  uint16_t head;
  uint32_t used_len;
  uint8_t  status;
  void    *cookie;
} sfv_blk_completion_t;

int sfv_blk_open(sfv_blk_t *b, const sfv_transport_t *t, uint16_t qsize);
void sfv_blk_close(sfv_blk_t *b);
int sfv_blk_submit(sfv_blk_t *b, uint32_t type, uint64_t sector,
                   const sfv_sg_t *data, unsigned ndata, void *cookie, uint16_t *head);
int sfv_blk_poll(sfv_blk_t *b, sfv_blk_completion_t *c);   /* 1 = got one, 0 = none, <0 error */
int sfv_blk_wait(sfv_blk_t *b, sfv_blk_completion_t *c, uint32_t budget);
int sfv_blk_rw_sync(sfv_blk_t *b, int write, uint64_t sector, uint64_t buf, uint32_t len,
                    uint8_t *status);
int sfv_blk_flush_sync(sfv_blk_t *b, uint8_t *status);
int sfv_blk_get_id_sync(sfv_blk_t *b, char id[VIRTIO_BLK_ID_BYTES + 1]);
int sfv_blk_status_to_err(uint8_t status);

/* ---- hypervisor helpers ---------------------------------------------------------------- */
int      sfv_hv_probe(const sfv_mgmt_transport_t *m, uint32_t *version, uint32_t *caps0);
void     sfv_hv_bind_domain(const sfv_mgmt_transport_t *m, uint16_t domain);
void     sfv_hv_unbind_domain(const sfv_mgmt_transport_t *m);
void     sfv_hv_set_window(const sfv_mgmt_transport_t *m, unsigned win, uint16_t domain,
                           uint64_t base, uint64_t limit_incl, int rd, int wr);
void     sfv_hv_clear_window(const sfv_mgmt_transport_t *m, unsigned win);
uint64_t sfv_hv_perf64(const sfv_mgmt_transport_t *m, uint32_t off);
uint32_t sfv_hv_perf32(const sfv_mgmt_transport_t *m, uint32_t off);
uint8_t  sfv_hv_fatal_cause(const sfv_mgmt_transport_t *m);
const char *sfv_fatal_cause_name(unsigned cause);
const char *sfv_strerror(int err);

#ifdef __cplusplus
}
#endif

#endif /* SFVIRTIO_H */
