/*
 * sfv_regs.h — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
 *
 * VirtIO 1.2 constants used by the host library (mirrors rtl/silicaflux_virtio_pkg.sv)
 * and the SilicaFlux privileged management register map.
 * Normative reference: OASIS virtio-v1.2-cs01.
 */
#ifndef SFV_REGS_H
#define SFV_REGS_H

#include <stdint.h>

/* ---- 2.1 device status ---------------------------------------------------- */
#define VIRTIO_STATUS_ACKNOWLEDGE        0x01u
#define VIRTIO_STATUS_DRIVER             0x02u
#define VIRTIO_STATUS_DRIVER_OK          0x04u
#define VIRTIO_STATUS_FEATURES_OK        0x08u
#define VIRTIO_STATUS_DEVICE_NEEDS_RESET 0x40u
#define VIRTIO_STATUS_FAILED             0x80u

/* ---- 6 reserved feature bits ---------------------------------------------- */
#define VIRTIO_F_INDIRECT_DESC     28
#define VIRTIO_F_EVENT_IDX         29
#define VIRTIO_F_VERSION_1         32
#define VIRTIO_F_ACCESS_PLATFORM   33
#define VIRTIO_F_RING_PACKED       34
#define VIRTIO_F_IN_ORDER          35
#define VIRTIO_F_NOTIFICATION_DATA 38
#define VIRTIO_F_RING_RESET        40

/* ---- 5.2.3 block feature bits --------------------------------------------- */
#define VIRTIO_BLK_F_SIZE_MAX      1
#define VIRTIO_BLK_F_SEG_MAX       2
#define VIRTIO_BLK_F_RO            5
#define VIRTIO_BLK_F_BLK_SIZE      6
#define VIRTIO_BLK_F_FLUSH         9
#define VIRTIO_BLK_F_MQ            12
#define VIRTIO_BLK_F_DISCARD       13
#define VIRTIO_BLK_F_WRITE_ZEROES  14

#define SFV_FEAT(b) (1ull << (b))

/* ---- 2.7 split virtqueue ---------------------------------------------------- */
#define VIRTQ_DESC_F_NEXT          1u
#define VIRTQ_DESC_F_WRITE         2u
#define VIRTQ_DESC_F_INDIRECT      4u
#define VIRTQ_AVAIL_F_NO_INTERRUPT 1u
#define VIRTQ_USED_F_NO_NOTIFY     1u

/* ---- 5.2.6 virtio-blk requests ---------------------------------------------- */
#define VIRTIO_BLK_T_IN            0u
#define VIRTIO_BLK_T_OUT           1u
#define VIRTIO_BLK_T_FLUSH         4u
#define VIRTIO_BLK_T_GET_ID        8u
#define VIRTIO_BLK_T_DISCARD       11u
#define VIRTIO_BLK_T_WRITE_ZEROES  13u
#define VIRTIO_BLK_S_OK            0u
#define VIRTIO_BLK_S_IOERR         1u
#define VIRTIO_BLK_S_UNSUPP        2u
#define VIRTIO_BLK_ID_BYTES        20u
#define VIRTIO_BLK_SECTOR_SIZE     512u
#define VIRTIO_ID_BLOCK            2u

/* ---- 4.2.2 virtio-mmio v2 registers ----------------------------------------- */
#define VIRTIO_MMIO_MAGIC_VALUE         0x000
#define VIRTIO_MMIO_VERSION             0x004
#define VIRTIO_MMIO_DEVICE_ID           0x008
#define VIRTIO_MMIO_VENDOR_ID           0x00c
#define VIRTIO_MMIO_DEVICE_FEATURES     0x010
#define VIRTIO_MMIO_DEVICE_FEATURES_SEL 0x014
#define VIRTIO_MMIO_DRIVER_FEATURES     0x020
#define VIRTIO_MMIO_DRIVER_FEATURES_SEL 0x024
#define VIRTIO_MMIO_QUEUE_SEL           0x030
#define VIRTIO_MMIO_QUEUE_NUM_MAX       0x034
#define VIRTIO_MMIO_QUEUE_NUM           0x038
#define VIRTIO_MMIO_QUEUE_READY         0x044
#define VIRTIO_MMIO_QUEUE_NOTIFY        0x050
#define VIRTIO_MMIO_INTERRUPT_STATUS    0x060
#define VIRTIO_MMIO_INTERRUPT_ACK       0x064
#define VIRTIO_MMIO_STATUS              0x070
#define VIRTIO_MMIO_QUEUE_DESC_LOW      0x080
#define VIRTIO_MMIO_QUEUE_DESC_HIGH     0x084
#define VIRTIO_MMIO_QUEUE_DRIVER_LOW    0x090
#define VIRTIO_MMIO_QUEUE_DRIVER_HIGH   0x094
#define VIRTIO_MMIO_QUEUE_DEVICE_LOW    0x0a0
#define VIRTIO_MMIO_QUEUE_DEVICE_HIGH   0x0a4
#define VIRTIO_MMIO_SHM_SEL             0x0ac
#define VIRTIO_MMIO_SHM_LEN_LOW         0x0b0
#define VIRTIO_MMIO_QUEUE_RESET         0x0c0
#define VIRTIO_MMIO_CONFIG_GENERATION   0x0fc
#define VIRTIO_MMIO_CONFIG              0x100
#define VIRTIO_MMIO_MAGIC               0x74726976u
#define VIRTIO_MMIO_INT_VRING           0x1u
#define VIRTIO_MMIO_INT_CONFIG          0x2u

/* 5.2.4 virtio_blk_config */
#define VIRTIO_BLK_CFG_CAPACITY         0x00
#define VIRTIO_BLK_CFG_SIZE_MAX         0x08
#define VIRTIO_BLK_CFG_SEG_MAX          0x0c

/* ---- SilicaFlux privileged management window -------------------------------- */
#define SFV_MGMT_ENGINE_ID      0x000   /* "SFVI" */
#define SFV_MGMT_ENGINE_VER     0x004   /* [23:16] major [15:8] minor [7:0] patch */
#define SFV_MGMT_CAPS0          0x008
#define SFV_MGMT_CAPS1          0x00c
#define SFV_MGMT_Q0_DOMAIN      0x010   /* [15:0] domain, [31] valid; locked while QueueReady */
#define SFV_MGMT_ENGINE_STATUS  0x014
#define SFV_MGMT_FAULT_LO       0x018
#define SFV_MGMT_FAULT_HI       0x01c
#define SFV_MGMT_FAULT_INFO     0x020
#define SFV_MGMT_CAP_LO         0x024
#define SFV_MGMT_CAP_HI         0x028
#define SFV_MGMT_PERF_CTRL      0x030   /* bit0 clear counters, bit1 clear sticky flags */
#define SFV_MGMT_WIN(i, f)      (0x040 + 0x20 * (i) + 4 * (f))
#define SFV_WIN_CTRL     0     /* [0] valid [1] read [2] write */
#define SFV_WIN_DOMAIN   1
#define SFV_WIN_BASE_LO  2
#define SFV_WIN_BASE_HI  3
#define SFV_WIN_LIMIT_LO 4
#define SFV_WIN_LIMIT_HI 5
#define SFV_MGMT_PERF(o)        (0x200 + (o))
#define SFV_PERF_DESC           0x000
#define SFV_PERF_REQ            0x004
#define SFV_PERF_RD_BYTES       0x008   /* 64-bit lo/hi */
#define SFV_PERF_WR_BYTES       0x010   /* 64-bit */
#define SFV_PERF_CLAT_SUM       0x018   /* 64-bit */
#define SFV_PERF_CLAT_MAX       0x020
#define SFV_PERF_WLAT_SUM       0x024   /* 64-bit */
#define SFV_PERF_WLAT_MAX       0x02c
#define SFV_PERF_IRQ            0x030
#define SFV_PERF_IRQ_SUP        0x034
#define SFV_PERF_STALL          0x038
#define SFV_PERF_VIOL           0x03c
#define SFV_PERF_QD_SUM         0x040   /* 64-bit */
#define SFV_PERF_QD_MAX         0x048
#define SFV_PERF_QD_N           0x04c
#define SFV_PERF_NOTIFY         0x050
#define SFV_PERF_FATAL          0x054
#define SFV_PERF_BUSY           0x058   /* 64-bit */
#define SFV_PERF_TOTAL          0x060   /* 64-bit */
#define SFV_PERF_IOERR          0x068
#define SFV_PERF_UNSUPP         0x06c

/* fatal cause codes (ENGINE_STATUS[15:8]) */
enum sfv_fatal_cause {
  SFV_FC_NONE = 0, SFV_FC_QUEUE_CFG = 1, SFV_FC_NO_DOMAIN = 2, SFV_FC_AVAIL_IDX_JUMP = 3,
  SFV_FC_RING_DMA = 4, SFV_FC_DESC_IDX_OOR = 5, SFV_FC_CHAIN_LOOP = 6,
  SFV_FC_CHAIN_TOO_LONG = 7, SFV_FC_DESC_FLAGS = 8, SFV_FC_CHAIN_ORDER = 9,
  SFV_FC_CHAIN_LEN_OVF = 10, SFV_FC_WRITABLE_PERM = 11, SFV_FC_NO_STATUS = 12,
  SFV_FC_DATA_WRITE_DMA = 13
};

#endif /* SFV_REGS_H */
