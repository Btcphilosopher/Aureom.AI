// =============================================================================
// tb_silicaflux_virtio_engine.sv — self-checking pure-SystemVerilog testbench
// Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
//
// Tool-portable companion to the Verilator/C++ co-simulation (sim/). Contains
// its own host memory, DMA responder (LFSR backpressure + latency), StorageCore
// model and a task-based VirtIO driver. Scenario:
//   hypervisor binds domain + window -> spec 3.1.1 init -> split queue setup
//   -> OUT 2 sectors -> IN read-back compare -> GET_ID -> FLUSH
//   -> readable buffer outside window (IOERR) -> descriptor loop (NEEDS_RESET,
//   cause CHAIN_LOOP, config interrupt) -> reset -> re-init -> OUT/IN again.
// Run: make svtb   (verilator --binary --timing)
// =============================================================================
module tb_silicaflux_virtio_engine;
  import silicaflux_virtio_pkg::*;

  localparam int CAP = 64;                    // sectors
  localparam int MEMSZ = 65536;
  localparam logic [15:0] DOM = 16'h0042;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT ports
  logic mmio_req_valid = 0, mmio_req_we = 0; logic [11:0] mmio_req_addr = 0; logic [31:0] mmio_req_wdata = 0;
  logic mmio_req_ready, mmio_resp_valid, irq; logic [31:0] mmio_resp_rdata;
  logic mgmt_req_valid = 0, mgmt_req_we = 0; logic [11:0] mgmt_req_addr = 0; logic [31:0] mgmt_req_wdata = 0;
  logic mgmt_req_ready, mgmt_resp_valid; logic [31:0] mgmt_resp_rdata;
  logic dma_req_valid, dma_req_ready, dma_req_we, dma_resp_valid, dma_resp_err;
  logic [63:0] dma_req_addr, dma_req_wdata, dma_resp_rdata; logic [7:0] dma_req_be; logic [15:0] dma_req_domain;
  logic sc_req_valid, sc_req_ready, sc_resp_valid, sc_resp_err; logic [1:0] sc_req_op;
  logic [31:0] sc_req_addr; logic [63:0] sc_req_wdata, sc_resp_rdata; logic [7:0] sc_req_be;

  silicaflux_virtio_engine #(.CAPACITY_SECTORS(CAP)) dut (.*, .mmio_req_be(4'hf));

  // ------------------------------------------------------- platform models
  logic [7:0] mem  [MEMSZ];
  logic [7:0] stor [CAP*512];
  logic [15:0] lfsr = 16'hace1;
  always @(posedge clk) lfsr <= {lfsr[14:0], lfsr[15] ^ lfsr[13] ^ lfsr[12] ^ lfsr[10]};

  logic dpend = 0, spend = 0; int dcnt, scnt; logic [63:0] drd, srd; logic derr, serr;
  int dma_beats = 0, perm_escapes = 0;
  assign dma_req_ready = !dpend && lfsr[0];
  assign sc_req_ready  = !spend && lfsr[3];
  always @(posedge clk) begin
    dma_resp_valid <= 1'b0;
    sc_resp_valid  <= 1'b0;
    if (dpend) begin
      if (dcnt == 0) begin dma_resp_valid <= 1; dma_resp_rdata <= drd; dma_resp_err <= derr; dpend <= 0; end
      else dcnt <= dcnt - 1;
    end
    if (spend) begin
      if (scnt == 0) begin sc_resp_valid <= 1; sc_resp_rdata <= srd; sc_resp_err <= serr; spend <= 0; end
      else scnt <= scnt - 1;
    end
    if (dma_req_valid && dma_req_ready) begin
      dma_beats++;
      if (dma_req_domain != DOM) perm_escapes++;
      // independent check: the only window granted is [0x1000, 0xBFFF]
      for (int b = 0; b < 8; b++)
        if (dma_req_be[b] && (dma_req_addr + b < 64'h1000 || dma_req_addr + b > 64'hbfff)) perm_escapes++;
      derr = (dma_req_addr + 8 > MEMSZ);
      drd = '0;
      if (!derr) for (int b = 0; b < 8; b++) begin
        if (dma_req_be[b]) begin
          if (dma_req_we) mem[dma_req_addr + b] = dma_req_wdata[8*b +: 8];
          else drd[8*b +: 8] = mem[dma_req_addr + b];
        end
      end
      dpend <= 1; dcnt <= int'(lfsr[2:1]);
    end
    if (sc_req_valid && sc_req_ready) begin
      serr = 0; srd = '0;
      if (sc_req_op != SC_OP_FLUSH) for (int b = 0; b < 8; b++)
        if (sc_req_op == SC_OP_WRITE) begin if (sc_req_be[b]) stor[sc_req_addr + b] = sc_req_wdata[8*b +: 8]; end
        else srd[8*b +: 8] = stor[sc_req_addr + b];
      spend <= 1; scnt <= int'(lfsr[5:4]);
    end
  end

  // ------------------------------------------------------------ bus tasks
  task automatic bus(input bit mg, input bit we, input logic [11:0] a, input logic [31:0] d, output logic [31:0] q);
    @(negedge clk);
    if (mg) begin mgmt_req_valid = 1; mgmt_req_we = we; mgmt_req_addr = a; mgmt_req_wdata = d; end
    else    begin mmio_req_valid = 1; mmio_req_we = we; mmio_req_addr = a; mmio_req_wdata = d; end
    #1;                                   // let ready settle against this request
    forever begin
      if (mg ? mgmt_req_ready : mmio_req_ready) break;
      @(negedge clk); #1;
    end
    @(posedge clk); #1;                   // handshake edge; response is registered there
    if (!(mg ? mgmt_resp_valid : mmio_resp_valid)) $fatal(1, "no bus response");
    q = mg ? mgmt_resp_rdata : mmio_resp_rdata;
    mgmt_req_valid = 0; mmio_req_valid = 0;
  endtask
  task automatic mw(input logic [11:0] a, input logic [31:0] d); logic [31:0] q; bus(0, 1, a, d, q); endtask
  task automatic mr(input logic [11:0] a, output logic [31:0] q); bus(0, 0, a, 0, q); endtask
  task automatic gw(input logic [11:0] a, input logic [31:0] d); logic [31:0] q; bus(1, 1, a, d, q); endtask
  task automatic gr(input logic [11:0] a, output logic [31:0] q); bus(1, 0, a, 0, q); endtask

  // ------------------------------------------------------- guest memory helpers
  task automatic put(input int a, input int n, input logic [63:0] v);
    for (int i = 0; i < n; i++) mem[a + i] = v[8*i +: 8];
  endtask
  function automatic logic [63:0] get(input int a, input int n);
    logic [63:0] v = '0; for (int i = 0; i < n; i++) v[8*i +: 8] = mem[a + i]; return v;
  endfunction
  localparam int DESC = 16'h1000, AVAIL = 16'h1206, USED = 16'h1304;   // tight ring alignment
  int avail_idx = 0, used_seen = 0, errors = 0;

  task automatic desc(input int i, input logic [63:0] a, input int len, input int fl, input int nx);
    put(DESC + 16*i, 8, a); put(DESC + 16*i + 8, 4, len); put(DESC + 16*i + 12, 2, fl); put(DESC + 16*i + 14, 2, nx);
  endtask
  task automatic publish(input int head);
    put(AVAIL + 4 + 2*(avail_idx % 8), 2, head); avail_idx++; put(AVAIL + 2, 2, avail_idx);
    mw(MMIO_QUEUE_NOTIFY, 0);
  endtask
  task automatic wait_used(output int id, output int len);
    int guard = 0; logic [31:0] q;
    forever begin
      if (get(USED + 2, 2) != 64'(16'(used_seen))) break;
      @(negedge clk);
      guard++;
      if (guard > 200000) $fatal(1, "completion timeout");
    end
    id = int'(get(USED + 4 + 8*(used_seen % 8), 4)); len = int'(get(USED + 8 + 8*(used_seen % 8), 4));
    used_seen++;
    if (irq) begin mr(MMIO_INTERRUPT_STATUS, q); mw(MMIO_INTERRUPT_ACK, q); end
  endtask
  task automatic check(input bit c, input string what);
    if (!c) begin errors++; $display("  FAIL: %s", what); end else $display("  ok:   %s", what);
  endtask
  task automatic blk_req(input int type_, input int sector, input int data, input int dlen, input bit dw,
                         input int expect_status, input string what);
    int id, len;
    put(16'h4000, 4, type_); put(16'h4004, 4, 0); put(16'h4008, 8, sector); mem[16'h6000] = 8'ha5;
    if (dlen > 0) begin
      desc(0, 64'h4000, 16, VIRTQ_DESC_F_NEXT, 1);
      desc(1, data, dlen, VIRTQ_DESC_F_NEXT | (dw ? VIRTQ_DESC_F_WRITE : 0), 2);
      desc(2, 64'h6000, 1, VIRTQ_DESC_F_WRITE, 0);
    end else begin
      desc(0, 64'h4000, 16, VIRTQ_DESC_F_NEXT, 2);
      desc(2, 64'h6000, 1, VIRTQ_DESC_F_WRITE, 0);
    end
    publish(0);
    wait_used(id, len);
    check(id == 0 && len == (dw ? dlen : 0) + 1 && mem[16'h6000] == 8'(expect_status), what);
  endtask

  task automatic init_device();
    logic [31:0] q;
    mw(MMIO_STATUS, 0);
    mw(MMIO_STATUS, 1); mw(MMIO_STATUS, 3);
    mw(MMIO_DRIVER_FEATURES_SEL, 0); mw(MMIO_DRIVER_FEATURES, 32'h0000_0204);   // SEG_MAX | FLUSH
    mw(MMIO_DRIVER_FEATURES_SEL, 1); mw(MMIO_DRIVER_FEATURES, 32'h0000_0003);   // VERSION_1 | ACCESS_PLATFORM
    mw(MMIO_STATUS, 11); mr(MMIO_STATUS, q);
    check(q[3], "FEATURES_OK accepted");
    for (int a = DESC; a < 16'h1400; a++) mem[a] = 0;
    avail_idx = 0; used_seen = 0;
    mw(MMIO_QUEUE_SEL, 0); mw(MMIO_QUEUE_NUM, 8);
    mw(MMIO_QUEUE_DESC_LOW, DESC); mw(MMIO_QUEUE_DRIVER_LOW, AVAIL); mw(MMIO_QUEUE_DEVICE_LOW, USED);
    mw(MMIO_QUEUE_READY, 1); mr(MMIO_QUEUE_READY, q);
    check(q == 1, "queue enabled");
    mw(MMIO_STATUS, 15);
  endtask

  initial begin
    logic [31:0] q;
    int id, len;
    for (int i = 0; i < MEMSZ; i++) mem[i] = 8'(i * 13);
    for (int i = 0; i < CAP*512; i++) stor[i] = 8'(i ^ 8'h5a);
    repeat (4) @(posedge clk);
    rst_n = 1;
    $display("[tb] SilicaFlux VIRTUALIO engine — pure SystemVerilog testbench");
    mr(MMIO_MAGIC_VALUE, q); check(q == 32'h74726976, "magic 'virt'");
    mr(MMIO_DEVICE_ID, q);   check(q == 2, "device id = block");
    gr(12'h004, q);          check(q == 32'h0001_0000, "engine version 1.0.0");
    // hypervisor: bind domain, one RW window [0x1000, 0xBFFF]
    gw(12'h010, 32'h8000_0000 | DOM);
    gw(12'h040 + 4, DOM); gw(12'h040 + 8, 32'h1000); gw(12'h040 + 12, 0);
    gw(12'h040 + 16, 32'hbfff); gw(12'h040 + 20, 0); gw(12'h040, 32'h7);
    init_device();
    // OUT 2 sectors from 0x8000 to sector 5, read back to 0xA000
    for (int i = 0; i < 1024; i++) mem[16'h8000 + i] = 8'(i * 7 + 1);
    blk_req(VIRTIO_BLK_T_OUT, 5, 16'h8000, 1024, 0, 0, "OUT 2 sectors completes OK");
    begin bit same = 1; for (int i = 0; i < 1024; i++) if (stor[5*512 + i] != mem[16'h8000 + i]) same = 0;
      check(same, "storage holds written data"); end
    blk_req(VIRTIO_BLK_T_IN, 5, 16'hA000, 1024, 1, 0, "IN 2 sectors completes OK");
    begin bit same = 1; for (int i = 0; i < 1024; i++) if (mem[16'hA000 + i] != mem[16'h8000 + i]) same = 0;
      check(same, "read-back matches"); end
    blk_req(VIRTIO_BLK_T_GET_ID, 0, 16'hA000, 20, 1, 0, "GET_ID completes OK");
    check(mem[16'hA000] == "S" && mem[16'hA000 + 19] == "1", "GET_ID string");
    blk_req(VIRTIO_BLK_T_FLUSH, 0, 0, 0, 0, 0, "FLUSH completes OK");
    blk_req(VIRTIO_BLK_T_OUT, 6, 16'hC000, 512, 0, VIRTIO_BLK_S_IOERR, "buffer outside window -> IOERR");
    // malformed: descriptor loop
    desc(3, 64'h4000, 16, VIRTQ_DESC_F_NEXT, 3);
    publish(3);
    repeat (300) @(negedge clk);
    mr(MMIO_STATUS, q); check(q[6], "loop -> DEVICE_NEEDS_RESET");
    gr(12'h014, q);     check(q[15:8] == FC_CHAIN_LOOP, "fatal cause CHAIN_LOOP");
    mr(MMIO_INTERRUPT_STATUS, q); check(q[1], "configuration-change interrupt");
    init_device();      // writes Status=0 first (reset), then full re-init
    mr(MMIO_STATUS, q); check(q == 15 && !q[6], "recovered after reset");
    blk_req(VIRTIO_BLK_T_IN, 5, 16'hA400, 512, 1, 0, "IN after recovery");
    check(perm_escapes == 0, $sformatf("no DMA outside the tenant window (%0d beats checked)", dma_beats));
    if (errors == 0) $display("[tb] PASS"); else $display("[tb] FAIL (%0d errors)", errors);
    $finish;
  end
  initial begin #20ms; $fatal(1, "global timeout"); end
endmodule
