/*
 * host_example.c — Aureom.AI | SilicaFlux-CLOUD | Project 63 VIRTUALIO
 *
 * Definition-of-done demonstration: a simulated virtual-machine driver submits
 * VirtIO block requests, the DPU engine executes them through its protected
 * backend, and the driver receives correct completions.
 *
 *   hypervisor (sfv_hv_*)  : probe engine, bind domain, grant one DMA window
 *   VM driver  (sfv_blk_*) : spec 3.1.1 init, write / read-back / flush / GET_ID,
 *                            16 requests in flight, then a request whose buffer
 *                            lies outside the VM's memory (must be refused)
 *
 * Transport: the simulated backend in sim/sfv_sim.h (Verilator model of the
 * RTL + simulated host memory + StorageCore). On hardware, only the
 * sfv_transport_t implementation changes.
 */
#include <stdio.h>
#include <string.h>
#include "sfv_sim.h"
#include "sfvirtio.h"

#define GUEST_BASE 0x10000ull
#define GUEST_SIZE 0x80000ull
#define DOMAIN     0x0042

static int fails = 0;
static void check(int ok, const char *what) {
  printf("  [%s] %s\n", ok ? " ok " : "FAIL", what);
  if (!ok) fails++;
}

int main(void) {
  sfv_sim_t *sim = sfv_sim_create(1, 1u << 20, 63);
  const sfv_transport_t *t = sfv_sim_transport(sim, 0);
  const sfv_mgmt_transport_t *hv = sfv_sim_mgmt(sim, 0);
  sfv_sim_set_latency(sim, 0, 8, 4);   /* 8-cycle host memory, 4-cycle StorageCore */

  /* ---- hypervisor / ControlCore ---------------------------------------- */
  uint32_t ver, caps;
  check(sfv_hv_probe(hv, &ver, &caps) == SFV_OK, "engine identified (SFVI)");
  printf("       engine v%u.%u.%u, queues=%u, max chain=%u, windows=%u, split=%u packed=%u\n",
         (ver >> 16) & 0xff, (ver >> 8) & 0xff, ver & 0xff, caps & 0xff, (caps >> 8) & 0xff,
         (caps >> 16) & 0xff, (caps >> 24) & 1, (caps >> 25) & 1);
  sfv_hv_bind_domain(hv, DOMAIN);
  sfv_hv_set_window(hv, 0, DOMAIN, GUEST_BASE, GUEST_BASE + GUEST_SIZE - 1, 1, 1);
  sfv_sim_set_region(sim, 0, GUEST_BASE, GUEST_SIZE);

  /* ---- VM driver ----------------------------------------------------------- */
  sfv_blk_t blk;
  int r = sfv_blk_open(&blk, t, 64);   /* 16 in flight x 3 descriptors */
  check(r == SFV_OK, "virtio-blk device initialised (ACK, DRIVER, FEATURES_OK, DRIVER_OK)");
  if (r) return 1;
  printf("       negotiated features 0x%llx, capacity %llu sectors, seg_max %u\n",
         (unsigned long long)blk.dev.drv_features, (unsigned long long)blk.capacity, blk.seg_max);

  uint64_t wbuf, rbuf;
  t->dma_alloc(t->ctx, 8 * 512, 8, &wbuf);
  t->dma_alloc(t->ctx, 8 * 512, 8, &rbuf);
  uint8_t pattern[8 * 512], back[8 * 512];
  for (unsigned i = 0; i < sizeof pattern; i++) pattern[i] = (uint8_t)(i * 31 + 7);
  t->mem_write(t->ctx, wbuf, pattern, sizeof pattern);

  uint8_t st = 0xff;
  uint64_t c0 = sfv_sim_cycles(sim);
  check(sfv_blk_rw_sync(&blk, 1, 128, wbuf, sizeof pattern, &st) == SFV_OK && st == 0, "write 4 KiB at sector 128");
  check(sfv_blk_rw_sync(&blk, 0, 128, rbuf, sizeof back, &st) == SFV_OK && st == 0, "read 4 KiB back");
  t->mem_read(t->ctx, rbuf, back, sizeof back);
  check(memcmp(pattern, back, sizeof back) == 0, "read-back data matches");
  check(sfv_blk_flush_sync(&blk, &st) == SFV_OK, "flush");
  char id[VIRTIO_BLK_ID_BYTES + 1];
  check(sfv_blk_get_id_sync(&blk, id) == SFV_OK, "GET_ID");
  printf("       device id \"%s\", %llu cycles so far\n", id, (unsigned long long)(sfv_sim_cycles(sim) - c0));

  /* ---- 16 requests in flight ---------------------------------------------- */
  uint64_t bufs[16];
  for (int i = 0; i < 16; i++) {
    t->dma_alloc(t->ctx, 512, 8, &bufs[i]);
    t->mem_write(t->ctx, bufs[i], pattern + 64 * i, 512);
    sfv_sg_t sg = {bufs[i], 512, 0};
    r = sfv_blk_submit(&blk, VIRTIO_BLK_T_OUT, 200 + i, &sg, 1, (void *)(uintptr_t)(i + 1), NULL);
    if (r) { check(0, "submit"); break; }
  }
  sfv_vq_kick(&blk.vq);
  int done = 0, in_order = 1;
  while (done < 16) {
    sfv_blk_completion_t c;
    r = sfv_blk_wait(&blk, &c, 1000000);
    if (r < 0) { check(0, sfv_strerror(r)); break; }
    if ((uintptr_t)c.cookie != (uintptr_t)(done + 1) || c.status != 0) in_order = 0;
    done++;
  }
  check(done == 16 && in_order, "16 concurrent writes completed, in order, status OK");

  /* ---- protection: buffer outside the VM's memory --------------------------- */
  sfv_sg_t evil = {0xc0000, 512, 0};   /* hypervisor memory, not granted to this VM */
  uint16_t h;
  sfv_blk_completion_t c;
  sfv_blk_submit(&blk, VIRTIO_BLK_T_OUT, 7, &evil, 1, NULL, &h);
  sfv_vq_kick(&blk.vq);
  r = sfv_blk_wait(&blk, &c, 1000000);
  check(r == 1 && c.status == VIRTIO_BLK_S_IOERR, "out-of-domain buffer refused with VIRTIO_BLK_S_IOERR");
  printf("       permission violations %u, fault address 0x%x\n", sfv_hv_perf32(hv, SFV_PERF_VIOL),
         hv->read32(hv->ctx, SFV_MGMT_FAULT_LO));
  check(sfv_sim_dma_escapes(sim) == 0, "independent monitor: zero DMA beats outside the tenant window");

  /* ---- performance counters --------------------------------------------------- */
  uint32_t reqs = sfv_hv_perf32(hv, SFV_PERF_REQ);
  printf("       requests %u, descriptors %u, DMA rd %llu B, wr %llu B, avg completion %llu cyc, "
         "max queue depth %u, irqs %u\n",
         reqs, sfv_hv_perf32(hv, SFV_PERF_DESC), (unsigned long long)sfv_hv_perf64(hv, SFV_PERF_RD_BYTES),
         (unsigned long long)sfv_hv_perf64(hv, SFV_PERF_WR_BYTES),
         (unsigned long long)(sfv_hv_perf64(hv, SFV_PERF_CLAT_SUM) / (reqs ? reqs : 1)),
         sfv_hv_perf32(hv, SFV_PERF_QD_MAX), sfv_hv_perf32(hv, SFV_PERF_IRQ));

  sfv_blk_close(&blk);
  sfv_sim_destroy(sim);
  printf("%s\n", fails ? "HOST EXAMPLE: FAIL" : "HOST EXAMPLE: PASS");
  return fails ? 1 : 0;
}
