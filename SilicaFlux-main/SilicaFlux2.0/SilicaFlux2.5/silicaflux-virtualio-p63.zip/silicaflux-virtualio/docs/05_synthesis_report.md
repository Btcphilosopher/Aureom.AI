# 05 — Synthesis report

**Flow** (`synth/run_synth.sh`, `synth/run_pnr.sh`): open-source tools only.

| Tool | Version | Role |
|---|---|---|
| sv2v | 0.0.12 | SystemVerilog → Verilog front-end (Yosys 0.33 cannot parse sized casts) |
| Yosys | 0.33 | generic synthesis (`synth`), ECP5 mapping (`synth_ecp5`) |
| nextpnr-ecp5 | 0.6 | place & route, LFE5UM-85F, CABGA381, 100 MHz target |

No ASIC standard-cell library or foundry PDK is used, so **no ASIC area or timing is claimed**. The transistor count is Yosys' generic CMOS estimate.

## 1. Generic synthesis (default parameters: QSZ 256, CHAIN 16, WIN 8)

Totals, flattened: **53,070 cells, 5,561 flip-flops, ≈ 321,700 transistors** (Yosys `stat -tech cmos` estimate).

Per module (hierarchical `synth`, before flattening):

| Module | Cells | Flip-flops | Dominant structures |
|---|---|---|---|
| domain_perm | 19,835 | 1,382 | 8 windows × (64-bit base + limit) table; 2 × 8 × two 64-bit comparators (pre-check port + DMA gate) |
| blk_backend | 12,332 | 477 | 64-bit lane shifters (×4), 64-bit address adders, step-size logic |
| desc_walker | 8,410 | 2,094 | 16 × 96-bit SG list, 256-bit visited bitmap, descriptor registers |
| mgmt | 7,433 | 1,072 | 7 × 64-bit + 13 × 32-bit counters, read mux |
| queue_ctrl | 3,274 | 132 | ring address arithmetic |
| mmio_transport | 1,145 | 415 | register file |
| dma_arb | 461 | 3 | |

Source: `reports/synth/generic_stat.txt`, `reports/synth/generic_flat_stat.txt`.

## 2. FPGA implementation (Lattice ECP5 LFE5UM-85F)

The engine has about 560 ports, which no package can bond. `synth/synth_ooc_wrap.sv` therefore drives every input from a register in a shift chain and registers every output into an XOR fold. All engine logic stays live and every engine I/O path is register-to-register. The wrapper adds about 631 flip-flops; those are included in the "with wrapper" numbers below.

| Resource | Engine alone (`synth_ecp5`) | With OOC wrapper, after placement | Device |
|---|---|---|---|
| LUT4 | 41,666 | 45,924 (54 %) | 83,640 |
| Flip-flops | 5,564 | 6,104 (7 %) | 83,640 |
| CCU2C (carry) | 2,739 | 2,739 | |
| Block RAM / DSP | 0 / 0 | 0 / 0 | 208 / 156 |

**Timing.** Post-placement Fmax estimate is **20.24 MHz**, which **fails** the 100 MHz target.

**Post-route: not completed.** Routing (147,980 arcs) was still running when the single-core 4 GB build session ended, and nextpnr never wrote a post-route report. So the **20.24 MHz figure is nextpnr's post-placement estimate, not a signoff number**. To get post-route timing and the critical-path report, run `make synth` on a multi-core host (`reports/synth/nextpnr.log` holds the placement log).

## 3. Assessment

The engine is synthesizable and implementable, but **v1 is not timing-closed** for a production clock. It is also larger than it needs to be. Three costs dominate, and all three follow from design choices made for correctness first:

1. **Full 64-bit byte-granular permission compares in one cycle.** There are 8 windows × 2 comparators × 2 enforcement paths (the walker's range pre-check and the per-beat DMA gate). The pre-check also computes `addr + len − 1` (65-bit) in the same cycle.
2. **Single-cycle 64-bit address arithmetic in the copy engine.** `seg_addr[idx] + off` feeds the step-size `min()` chain, and 64-bit barrel shifters do lane alignment.
3. **The SG list held in flip-flops** (1.5 kbit) with a 16:1 read mux, plus the 256-bit visited bitmap.

These are candidate critical paths by construction. The post-route critical-path report in `reports/synth/nextpnr.log` is the authoritative source.

## 4. Closure plan (no functional change, re-run the full regression and mutation suite after each)

| Step | Change | Expected effect |
|---|---|---|
| T1 | Register `addr + len − 1` and split the window compare into a 2-stage pipeline (the walker already waits a cycle in EVAL) | removes the longest compare chain |
| T2 | Page-granular windows (4 KiB, 52-bit compares), as an option with the byte-granular mode kept for verification | about 20 % of compare logic |
| T3 | Share one comparator bank between the pre-check and the gate (they are never active in the same cycle) | about half of domain_perm compare area |
| T4 | Register `g_now` / `seg_left` in the backend (one extra cycle per step, recovered by P2 bursts) | address path |
| T5 | SG list and visited bitmap in distributed RAM | flip-flops and mux area |
| T6 | 48-bit counters, or a sampled counter bank | mgmt area |

## 5. Reproduce

```
make synth                 # generic + ECP5 mapping + nextpnr (≈ 30 min on 1 core)
```
