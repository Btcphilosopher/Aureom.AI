# 04 — Verification

## 1. Strategy

Three independent oracles check every simulated transaction:

1. **Inline expectations.** Each test checks completion order, `used.len`, status codes, data read-back and fatal causes.
2. **An independent DMA-permission monitor** (`sim/sim_env.cpp`). It rebuilds the permission table from the hypervisor's management writes and re-checks every DMA beat that leaves the engine: byte range, direction and domain tag. Any escape fails the test.
3. **An independent Rust reference model** (`refmodel/`, shares no code with the RTL or the C library). It replays each test's operation log (driver memory writes, MMIO writes, management writes) from the spec semantics. It must predict **final guest memory and storage byte-for-byte**, plus device status, NEEDS_RESET, the last fatal cause, flush count and nine counters.

The only test exempt from oracle 3 is `reset_midflight`, where the abort point depends on timing. It checks quiescence directly instead.

The VM driver in every test is the shipped C host library, so the library is verified too. Malformed rings are injected with raw guest-memory writes.

## 2. Brief §10 coverage

| §10 item | Test(s) |
|---|---|
| Single descriptor | `single_descriptor` (1-descriptor chains: 1 B and 600 B writable, IOERR, zero-fill, len = W), minimal FLUSH |
| Chained descriptors | `chained` (header split 1–3 ways, up to seg_max payload segments, status merged with payload), `misaligned` |
| Ring wraparound | `ring_wrap_slots` (Queue Size 4, 80 completions), `ring_wrap_idx16` (**66,304** completions, used.idx wraps through 0) |
| Queue full / empty | `queue_full_empty` (empty notify is a no-op; all N entries outstanding; library NOSPC; idx jump → fatal) |
| Invalid flags | `invalid_flags` (INDIRECT, INDIRECT\|NEXT, reserved 0x8, 0x8000, WRITE\|0x10) |
| Invalid lengths | `invalid_lengths` (non-512 multiples, 0-length, short header, capacity edges, sector 2⁶³ and 2⁶⁴−1, GET_ID truncation/padding, ≥ 2³² chain) |
| Malformed chains | `malformed_chains` (next OOR, head OOR, self loop, 3-cycle, > MAX_CHAIN, order, no status, zero-length descriptors legal) |
| DMA permission failure | `dma_permission` (readable/writable payload, other-domain window, straddling windows, used ring write-protected, descriptor table outside, all windows revoked, no domain bound, domain rebind locked), `window_boundaries` (exact inclusive base/limit on both enforcement paths), `bus_error` |
| Reset | `reset_midflight` (Status=0 and QueueReady=0 under load; no DMA/storage activity afterwards), `reset_after_fatal` |
| Backpressure | `backpressure` (70 % ready-low on DMA and StorageCore, latency 1–20), plus random knobs in every random scenario |
| Completion ordering | `completion_ordering` (20 mixed requests in one batch); every `drain()` asserts used order = avail order |
| Multiple tenant domains | `multi_tenant` (two engines, shared host memory, concurrent traffic; cross-tenant read/write attacks, foreign-domain window; B unaffected while A faults) |
| (extra) | `init_negotiation`, `irq_suppression`, `storage_errors`, `flush_not_negotiated`, `queue_cfg_invalid`, `perf_counters` |

## 3. Results (final run from clean sources; logs in `reports/`)

| Suite | Configuration | Result |
|---|---|---|
| Verilator lint `-Wall` | RTL | clean |
| Host library, `gcc -std=c99 -Wall -Wextra -Werror` | C | clean |
| Reference-model unit tests | Rust | 5/5 |
| Directed suite | default (QSZ 256, CHAIN 16, WIN 8, 2048 sectors) | **23/23 pass**, all model-checked except reset_midflight |
| Directed suite | small (QSZ 64, CHAIN 8, WIN 4, 512 sectors) | **23/23 pass** |
| Random regression | default, seeds 1–1000 | **1000/1000 pass**, 34734 completions, all model-checked |
| Random regression | small, seeds 5000–5399 | **400/400 pass**, 14175 completions |
| Pure-SystemVerilog testbench (`make svtb`) | default | **21/21 checks**, 412 DMA beats independently confirmed in-window |
| Host example (`make example`) | default | **PASS**: definition of done (below) |

Random scenarios vary:
- 1 or 2 engines, queue size 4–256 and backpressure/latency per device;
- bad sectors, and whether FLUSH is negotiated;
- request types (IN/OUT/FLUSH/GET_ID/unknown), payload 0–8 sectors, header split, payload split, merged status and misalignment 0–7;
- error variants (bad length, out-of-range sector, short header, foreign payload);
- interrupt suppression toggles, injected malformed chains with recovery, and device resets.

**Definition of done.** `examples/host_example.c`:
- The hypervisor binds domain 0x42 and grants one window.
- The VM driver negotiates features and writes 4 KiB, reads it back (identical), flushes, reads GET_ID, and completes 16 concurrent writes in order.
- A request whose buffer lies outside the VM's memory is refused with VIRTIO_BLK_S_IOERR, with zero DMA beats outside the window.

## 4. Mutation testing (`sim/mutation_test.sh`)

Each mutant is a deliberate RTL fault. It counts as killed if the directed suite or 40 random seeds fail.

| Mutant | Fault injected | Result |
|---|---|---|
| M01 | walker: loop detection removed | KILLED |
| M02 | gate: domain tag ignored | KILLED |
| M03 | gate: window limit +1 byte | SURVIVED first run → KILLED after adding `window_boundaries` |
| M04 | backend: used.len = W−1 | KILLED |
| M05 | queue: NO_INTERRUPT ignored | KILLED |
| M06 | transport: FEATURES_OK always granted | KILLED |
| M07 | walker: readable-after-writable allowed | KILLED |
| M08 | backend: capacity check off by one sector | KILLED |
| M09 | transport: reset not quiesced | KILLED |
| M10 | walker: readable pre-check disabled | KILLED |
| M11 | queue: avail jump bound +1 | KILLED |
| M12 | backend: GET_ID skips zero-fill | KILLED |
| M13 | walker: MAX_CHAIN +1 | KILLED |
| M14 | transport: desc alignment 8 not 16 | KILLED |
| M15 | gate: window base −1 byte | KILLED |
| M16 | gate: per-beat check uses first byte only | KILLED |

**Score: 16/16 killed.** On its first run M03 **survived**. That was a real verification gap: no test exercised the exact inclusive window limit, and an off-by-one there would let a tenant touch one byte beyond its grant. `window_boundaries` was added, and it now kills M03, M15 and M16.

M10 is caught even though the gate would still deny the beats (defence in depth). The violation counter and fault address then differ from the model's prediction.

## 5. Formal verification of the permission gate (`formal/`)

`fv_domain_perm.sv` states six properties over all input sequences, with `N_WIN=2` and full 64-bit addresses:

- **A1** every forwarded beat lies inside one matching window of an independent shadow table.
- **A2** forwarded beats are byte-exact copies of the accepted request.
- **A3** the domain tag is correct.
- **A4** exactly one response per request.
- **A5** no false denials.
- **A6** the pre-check port is sound.

**Status: not completed, so there is no verdict.** Every attempt ended with the z3 solver being terminated: BMC at depths 20, 12, 10 and 6, a cover run, and k-induction at depth 4. Out-of-memory kills of z3 at about 2.8 GB resident were observed in the kernel log of the 4 GB build machine; the solver pipe then breaks (`reports/formal/`). **No counterexample was produced and no proof was obtained.** The harness, the six properties and `run_formal.sh` are delivered unchanged.

A final dedicated attempt ran **BMC at depth 4 on an otherwise idle machine**. z3 still grew to **3.4 GB resident** before being killed. A 4-cycle unrolling of one 2-window gate should need a small fraction of that, so the blow-up points to a pathological SMT encoding produced by the harness, not to solver depth. The likely sources are the loop-based helper functions (`shadow_ok`, `first_lane`, `last_lane`) and the A5 mask expression. Next steps:
1. Inspect the formal netlist size (`yosys stat` after `prep`).
2. Replace the loop functions with explicit per-window and per-lane wires.
3. Retry with a bit-vector-specialised solver (Bitwuzla or Boolector).

The unbounded proof needs more than memory. k-induction will also need a strengthening invariant that ties the harness' shadow table to the DUT's table, through a hierarchical reference or a formal-only debug port. Otherwise an arbitrary induction start state can have the two diverge permanently.

Until a run completes, the evidence for the gate is:
- the independent per-beat monitor on every simulated DMA beat (zero escapes in every run);
- the exact-boundary tests;
- mutants M02, M03, M10, M15 and M16 all being killed.

## 6. Bugs found during the build

| Found by | Defect | Where | Fix |
|---|---|---|---|
| mutation M03 | missing exact-boundary coverage of permission windows | test suite | `window_boundaries` |
| random regression | oracle expected IOERR for "foreign payload" with 0 sectors (no payload descriptor exists) | test generator | variant forces ≥ 1 sector |
| random regression | oracle expected IOERR for a short header on OUT. By spec 2.6.4 the device sees one readable stream, so the header continues into payload bytes and may decode as an unknown type (UNSUPP). The device was right. | test generator | leave to the reference model |
| directed (small config) | test built 12-descriptor chains with MAX_CHAIN=8; device correctly returned CHAIN_TOO_LONG | test | respect seg_max |
| directed | multi-tenant "attacked" range overlapped B's own descriptor table | test | attack an unused range |
| SV testbench | bus task sampled `ready` before combinational settle (race on the quiesced reset write) | testbench | settle delay |
| host example | 16 × 3 descriptors on a 32-entry queue; library correctly returned NOSPC | example | queue size 64 |
| synthesis | OOC wrapper input chain one bit short (Yosys warning) | synth wrapper | width fixed |

No functional RTL defect was found after the first smoke test. The mutation score is what gives that statement weight: the suite demonstrably detects the classes of fault listed above.

## 7. Not yet verified

- Interoperability with production guest drivers (Linux `virtio_blk` over virtio-mmio, Windows viostor). This needs an FPGA or a VMM co-simulation bridge.
- The virtio-pci transport (not implemented).
- Timing closure (see `05_synthesis_report.md`).
- Gate-level simulation of the synthesized netlist.
