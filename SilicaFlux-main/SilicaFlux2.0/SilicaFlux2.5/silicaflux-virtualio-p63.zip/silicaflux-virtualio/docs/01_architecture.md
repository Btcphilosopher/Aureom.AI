# 01 — Architecture

## 1. Block diagram

```
                 guest (VM driver)                       hypervisor / ControlCore
                        │ virtio-mmio v2 (mmio_*, irq)            │ mgmt_*
             ┌──────────▼───────────┐                  ┌──────────▼──────────┐
             │ mmio_transport       │                  │ mgmt                │
             │  features, status,   │                  │  version/caps, Q0   │
             │  queue cfg, reset    │                  │  domain bind, perf  │
             │  quiesce, irq        │                  │  counters, faults   │
             └───┬──────────────────┘                  └───────┬─────────────┘
       q cfg,    │ notify, abort                window table   │ domain
       active    ▼                                      ┌──────▼──────────────────────┐
             ┌──────────────────────┐   head    ┌───────┤ domain_perm                 │
             │ queue_ctrl           ├──────────►│walker │  range pre-check (chk_*)    │
             │  last_avail, used_idx│◄──────────┤       │  DMA gate (per beat)        │
             │  avail/used rings    │ SG list   └───┬───┤                             │
             │  completion, irq     ├────────►┌─────▼───┴──┐                          │
             └─────────┬────────────┘ exec    │ blk_backend├──► sc_* StorageCore    │
                       │                      └─────┬──────┘                          │
                       │ client 0     client 1 │     │ client 2                       │
                       └──────────►┌───────────▼─────▼┐                               │
                                   │ dma_arb (1 outst.)├──────► gate ──► dma_* host memory
                                   └───────────────────┘                (dma_req_domain)
```

| File | Role |
|---|---|
| `silicaflux_virtio_engine.sv` | top level; parameter checks; engine-idle logic; counter taps |
| `silicaflux_virtio_pkg.sv` | spec constants (VirtIO 1.2), MMIO offsets, fatal codes, helpers |
| `silicaflux_virtio_mmio_transport.sv` | guest register file, negotiation, status state machine, reset/disable quiesce |
| `silicaflux_virtio_queue_ctrl.sv` | split-ring indices, head fetch, sequencing, used-ring publication, irq suppression |
| `silicaflux_virtio_desc_walker.sv` | bounded chain walk, all descriptor validation, SG list |
| `silicaflux_virtio_blk_backend.sv` | virtio-blk decode and the byte-stream copy engine |
| `silicaflux_virtio_domain_perm.sv` | permission table, pre-check port, per-beat DMA gate |
| `silicaflux_virtio_dma_arb.sv` | fixed-priority single-outstanding arbiter |
| `silicaflux_virtio_mgmt.sv` | privileged window and performance counters |

## 2. Request lifecycle

1. **Notify.** The driver writes QueueNotify=0, and `queue_ctrl` sets `pending`. Processing starts only when all of these hold: QueueReady, DRIVER_OK, FEATURES_OK, not FAILED, not NEEDS_RESET, and a domain is bound (spec 3.1.1: no buffers are consumed before DRIVER_OK).
2. **Available ring.** The controller reads `avail.idx` (2 B). If `idx − last_avail > QueueSize` it is fatal (AVAIL_IDX_JUMP). Otherwise it reads `avail.ring[last_avail & (N−1)]`. The cached idx is reused until caught up, then re-read.
3. **Walk.** The walker validates each descriptor in a fixed order (§4) and builds a scatter-gather list. Readable segments come before writable ones, and zero-length descriptors are dropped. Each non-empty segment is range-checked against the tenant's windows *before* any data moves.
4. **Execute** (virtio-blk). The chain is treated as two byte streams, R and W (spec 2.6.4 message framing: no assumption about descriptor layout). The header is the first 16 bytes of R and the status is the last byte of W. The copy engine moves ≤ 8 bytes per step and never crosses a guest segment, a guest 8-byte word or a storage 8-byte word. This handles any alignment by lane shifting.
5. **Complete.** The **whole writable stream** is written: payload, zeros wherever there is no payload, and the status in the final byte. Then:
   1. `used.ring[slot] = {id = head, len = W}` is written as two le32 writes.
   2. `used.{flags=0, idx+1}` is written as one le32 write.
   3. `avail.flags` is re-read. A used-buffer notification is raised unless VIRTQ_AVAIL_F_NO_INTERRUPT is set.

Because the whole writable stream is always written, `used.len` is truthful for every completion, including errors. This satisfies spec 2.7.8.2 ("the device MUST write at least len bytes … beginning at the first device-writable buffer").

## 3. Error policy

| Situation | Response |
|---|---|
| Malformed ring or chain: OOR index, loop, too long, bad flags, order, length overflow, no status byte, avail.idx jump, invalid queue config | **DEVICE_NEEDS_RESET**, configuration-change interrupt if DRIVER_OK, queue halted until reset (spec 2.1.2) |
| Permission or bus fault on the descriptor table, avail or used ring | DEVICE_NEEDS_RESET (RING_DMA) |
| Device-*writable* payload outside the tenant's permission | DEVICE_NEEDS_RESET (WRITABLE_PERM). Nothing is written, and the request can't be completed truthfully. |
| Device-*readable* payload outside the tenant's permission | Request completes with **VIRTIO_BLK_S_IOERR**. Nothing is read, nothing is stored, and the violation is counted. |
| Header < 16 bytes, length not a multiple of 512, sector range past capacity (overflow-safe) | VIRTIO_BLK_S_IOERR |
| StorageCore error | VIRTIO_BLK_S_IOERR. For IN, the bytes after the failure are zero-filled. |
| Unknown request type; FLUSH without negotiated VIRTIO_BLK_F_FLUSH | VIRTIO_BLK_S_UNSUPP |

A fault can only halt the faulting tenant's own queue. Other engines and tenants are unaffected (tested in `multi_tenant`).

## 4. Descriptor validation order

The RTL and the Rust reference model use exactly this order. For each descriptor:

1. `idx ≥ QueueSize` → DESC_IDX_OOR.
2. Already visited in this chain → CHAIN_LOOP. A `MAX_QSZ`-bit visited bitmap gives exact cycle detection.
3. MAX_CHAIN descriptors already taken → CHAIN_TOO_LONG.
4. Fetch two 8-byte words; a DMA error → RING_DMA.
5. `flags & ~(NEXT|WRITE)` → DESC_FLAGS.
6. Readable after writable → CHAIN_ORDER.
7. Running total ≥ 2³² → CHAIN_LEN_OVF.
8. If len > 0, range pre-check. A writable denial → WRITABLE_PERM; a readable denial → IOERR later.

Termination is guaranteed by steps 2 and 3, independent of guest memory contents.

## 5. DMA, ordering and the platform contract

- The engine has **one DMA request outstanding** (`dma_arb`) and issues the next only after the previous response. This gives trivially correct response routing, ordering and reset draining, at a throughput cost (`06_performance.md`).
- **Platform requirement:** a write response on `dma_*` must imply that the write is visible to the host CPU. The used element is written and acknowledged before the used.idx write is issued, which provides the 2.7.8 "element before index" ordering.
- Every request carries `dma_req_domain`.

## 6. Tenant isolation model

- Each queue is bound to a **protected domain** through the management window only. The guest has no register that names a domain or a window. The binding is **locked while QueueReady=1**, and an attempted rebind is ignored and flagged.
- **Two independent enforcement points** both consult the same table:
  - The walker pre-checks each descriptor's whole range, which gives all-or-nothing payload access.
  - The DMA gate checks the exact byte range of **every beat**: ring accesses, descriptor fetches and payload beats alike.
- **A domain tag never authorises anything on its own.** An access is permitted only if its exact byte range lies inside **one** window that is valid, carries the bound domain and grants the direction. Ranges that straddle two windows, or wrap past 2⁶⁴, are denied.
- **Revocation.** A window write takes effect for every access whose check starts after the write. At most one already-authorised beat can complete. Before re-assigning revoked memory, the hypervisor must either see ENGINE_STATUS.busy = 0 or reset the device. Formal property A1 is proved under this quiesce assumption (E2 in `formal/fv_domain_perm.sv`).

## 7. Reset and queue disable

Writing Status=0, or QueueReady=0 while enabled, raises `abort`. The bus write is **held off** (`mmio_req_ready=0`) until every block is idle and the DMA/StorageCore request in flight has returned. So when the driver's reset write completes, no device write can still land. This is tested by `reset_midflight`, which checks that no DMA or storage activity follows, and by mutation M09.

## 8. Parameters

| Parameter | Default | Constraint |
|---|---|---|
| MAX_QSZ | 256 | power of two, 2…32768 |
| MAX_CHAIN | 16 | power of two ≥ 4; seg_max = MAX_CHAIN−2 |
| N_WIN | 8 | power of two ≥ 2 |
| CAPACITY_SECTORS | 2048 | CAPACITY·512 ≤ 2^SADDR_W |
| SADDR_W | 32 | StorageCore byte-address width |
| BLK_ID | "SILICAFLUX-VBLK-0001" | 20-byte GET_ID string |

Two configurations are regression-tested: 256/16/8/2048 and 64/8/4/512.
