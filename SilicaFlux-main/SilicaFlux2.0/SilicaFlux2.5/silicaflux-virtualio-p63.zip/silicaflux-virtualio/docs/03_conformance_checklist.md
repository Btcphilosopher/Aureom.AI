# 03 — VirtIO conformance checklist

Normative reference: **OASIS Virtual I/O Device (VIRTIO) Version 1.2**, cs01. Section numbers below are from that document.

**What this is, and what it isn't.** OASIS publishes no executable conformance suite. This checklist maps each applicable clause to the implementation and to the test that exercises it.

Every "Implemented" row is checked by the co-simulation suite. The Rust reference model independently predicts guest memory, storage, status and counters byte-for-byte from the spec text.

The device has **not** been run against a production guest driver such as Linux `virtio_blk` or the Windows `viostor` driver; no kernel or VMM was available in the build environment. That is the next validation step (`04_verification.md` §7).

Legend: **Implemented** · **Not offered** (the feature bit is never advertised and the behaviour is rejected or not negotiable) · **Policy** (the spec leaves the device's behaviour open, and this documents the choice made) · **N/A**.

## Device status, features, reset (§2.1, §2.2, §2.4, §3.1)

| Clause | Requirement | Status | Evidence |
|---|---|---|---|
| 2.1 | ACKNOWLEDGE / DRIVER / FEATURES_OK / DRIVER_OK / FAILED / DEVICE_NEEDS_RESET bits | Implemented | `init_negotiation`, svtb |
| 2.1.2 | Device sets NEEDS_RESET on unrecoverable error; config-change notification if DRIVER_OK | Implemented | `expect_fatal()` in every fatal test checks INT_CONFIG |
| 2.1.2 | Driver cannot clear bits; NEEDS_RESET is device-owned | Implemented | `init_negotiation` |
| 2.2.1 | Device offers only features it implements | Implemented | `init_negotiation` checks the exact offered set |
| 3.1.1 / 2.2.2 | Device refuses FEATURES_OK if the driver accepts an un-offered feature | Implemented | RING_PACKED and INDIRECT_DESC refused |
| 6.1 | VIRTIO_F_VERSION_1 required (modern-only device) | Implemented | legacy driver refused |
| 6.1 | VIRTIO_F_ACCESS_PLATFORM: "device MAY fail to operate" if not accepted | Policy: required | refused without it; all addresses are permission-checked IOVAs |
| 2.4 | Reset by writing 0 to Status; device returns to initial state | Implemented | `reset_midflight`, `reset_after_fatal` |
| 2.4 (hardening) | No device writes after the reset write completes | Implemented (reset write back-pressured until drained) | `reset_midflight`, mutation M09 |
| 3.1.1 | No buffers consumed before DRIVER_OK | Implemented | gating in `queue_ctrl` |

## Configuration space (§2.5, §5.2.4)

| Clause | Requirement | Status | Evidence |
|---|---|---|---|
| 2.5 | ConfigGeneration consistent multi-word reads | Implemented (static config, generation 0) | library reads capacity with a generation loop |
| 5.2.4 | `capacity` (le64, 512-byte sectors) | Implemented | `init_negotiation` |
| 5.2.4 | `seg_max` valid when VIRTIO_BLK_F_SEG_MAX is offered | Implemented (MAX_CHAIN−2) | `init_negotiation`, `chained` |
| 5.2.4 | other fields | 0; their feature bits are not offered | |

## Split virtqueues (§2.6, §2.7)

| Clause | Requirement | Status | Evidence |
|---|---|---|---|
| 2.7 | Queue Size power of two, ≤ 32768 | Implemented (validated at QueueReady) | `queue_cfg_invalid` |
| 2.7.2 | Alignment: desc 16, avail 2, used 4 | Implemented (validated) | `queue_cfg_invalid`, `misaligned` (avail ≡ 6, used ≡ 4 mod 8) |
| 2.7.5 | Descriptor format le64/le32/le16/le16 | Implemented | all tests |
| 2.6.4 / 2.7.4 | Message framing: device makes no assumption about descriptor layout | Implemented (R/W byte streams) | `chained`, `misaligned`, random |
| 2.7.4.2 | Readable descriptors precede writable ones (driver MUST) | Policy: a violation is a malformed chain → NEEDS_RESET | `malformed_chains`, mutation M07 |
| 2.7.5.3 | Indirect descriptors | **Not offered**; the INDIRECT flag is rejected as malformed | `invalid_flags` |
| 2.7.6 | avail.flags NO_INTERRUPT honoured (EVENT_IDX not negotiated) | Implemented | `irq_suppression`, mutation M05 |
| 2.7.6 / 2.7.10 | used_event / avail_event | N/A: EVENT_IDX **not offered** | |
| 2.7.8 | used element {id, len}; element visible before idx | Implemented (element write acked before idx write) | `completion_ordering`, every drain |
| 2.7.8.2 | Device writes at least `len` bytes from the first writable byte | Implemented (whole writable stream always written; len = W) | `single_descriptor`, `invalid_lengths`, mutation M04 |
| 2.7.8 | used.flags NO_NOTIFY | Policy: never set (device always wants notifications) | |
| 2.7.13 | Indices are free-running 16-bit | Implemented | `ring_wrap_idx16` (66,304 completions across the wrap) |
| 2.7.13.1 | Chain length ≤ 2³² bytes total | Implemented (≥ 2³² → fatal) | `invalid_lengths` |
| 2.7.13 (robustness) | Loops / out-of-range / over-long chains cannot hang the device | Implemented (visited bitmap + MAX_CHAIN bound) | `malformed_chains`, mutations M01, M13 |
| 2.7.13.3 | avail.idx never more than Queue Size ahead | Implemented (violation → fatal) | `queue_full_empty`, mutation M11 |
| 2.8 | Packed virtqueues | **Not offered** (VIRTIO_F_RING_PACKED never advertised; refused if the driver tries) | `init_negotiation` |
| 2.9 | In-order (VIRTIO_F_IN_ORDER) | Not offered (the device happens to complete in order) | |

## virtio-mmio transport (§4.2)

| Clause | Requirement | Status | Evidence |
|---|---|---|---|
| 4.2.2 | Register layout, Version 2 | Implemented | `02_register_map.md`, `init_negotiation` |
| 4.2.2 | QueueNumMax = 0 for an unavailable queue | Implemented | `init_negotiation` |
| 4.2.2 | Shared-memory regions: length −1 when absent | Implemented | `init_negotiation` |
| 4.2.2 | InterruptStatus / InterruptACK | Implemented | `irq_suppression` |
| 4.2.2.1 | Upon reset, clear InterruptStatus and QueueReady | Implemented | `reset_midflight` |
| 4.2.3.4 | Notification value = queue index (NOTIFICATION_DATA not negotiated) | Implemented | |
| 4.2.2 QueueReset | VIRTIO_F_RING_RESET | Not offered | |
| 4.1 | virtio over PCI capability layout | **Not implemented**; no CloudDPU PCIe block exists (`00_repository_audit.md`) | |

## Block device (§5.2)

| Clause | Requirement | Status | Evidence |
|---|---|---|---|
| 5.2.1 | Device ID 2 | Implemented | |
| 5.2.2 | Exactly one requestq (without MQ) | Implemented | |
| 5.2.3 | Offered: SEG_MAX, FLUSH | Implemented | |
| 5.2.3 | RO, BLK_SIZE, TOPOLOGY, CONFIG_WCE, MQ, DISCARD, WRITE_ZEROES, LIFETIME, SECURE_ERASE, SIZE_MAX, GEOMETRY | **Not offered** | |
| 5.2.6 | Request header {le32 type, le32 reserved, le64 sector} | Implemented (reserved ignored) | |
| 5.2.6 | VIRTIO_BLK_T_IN / OUT | Implemented | all data tests |
| 5.2.6 | VIRTIO_BLK_T_FLUSH | Implemented when negotiated; UNSUPP otherwise | `flush_not_negotiated` |
| 5.2.6 | VIRTIO_BLK_T_GET_ID (20 bytes, truncated to the buffer) | Implemented | `invalid_lengths` (8 B and 32 B buffers) |
| 5.2.6 | Other types (DISCARD, WRITE_ZEROES, GET_LIFETIME, …) → VIRTIO_BLK_S_UNSUPP | Implemented | `invalid_lengths`, random |
| 5.2.6 | Sector unit is always 512 bytes | Implemented | |
| 5.2.6.1 | Payload length a multiple of 512; out-of-range requests fail | Policy: IOERR, range check overflow-safe for sector = 2⁶⁴−1 | `invalid_lengths`, mutation M08 |
| 5.2.6.1 | Status written last (final byte of the writable stream) | Implemented | all |

## Not offered — gated on formal and regression results (per brief)

Packed rings, indirect descriptors, EVENT_IDX, multiqueue (VIRTIO_BLK_F_MQ), NOTIFICATION_DATA, RING_RESET, DISCARD/WRITE_ZEROES. Each of these is a separate, testable extension. The brief requires single-queue split-ring formal and regression testing first. That evidence is in `04_verification.md`.
