# 06 — Performance

All numbers are **measured** in co-simulation by the engine's own counters (`PERF_CLAT_SUM` and friends) through `make perf`. The raw output is in `reports/perf_sweep.txt`.

- **clat**: cycles from head fetch to used.idx publication, averaged over 6 requests.
- **wlat**: descriptor-walk cycles.
- **dmalat**: host-memory response latency in cycles. StorageCore latency is 2 cycles throughout.

## 1. Results (excerpt)

| dir | bytes | segs | misalign | dmalat | clat avg | wlat avg | bytes/cycle | DMA beats/req |
|---|---|---|---|---|---|---|---|---|
| OUT | 512 | 1 | 0 | 1 | 713 | 30 | 0.718 | 79.5 |
| OUT | 4096 | 1 | 0 | 1 | 5,193 | 30 | 0.789 | 527.5 |
| OUT | 65536 | 1 | 0 | 1 | 81,993 | 30 | **0.799** | 8,207.5 |
| OUT | 65536 | 8 | 0 | 1 | 82,126 | 100 | 0.798 | 8,228.2 |
| OUT | 65536 | 1 | 3 | 1 | 163,920 | 30 | **0.400** | 16,401 |
| IN | 65536 | 1 | 0 | 1 | 81,993 | 30 | 0.799 | 8,207.5 |
| OUT | 512 | 1 | 0 | 16 | 1,544 | 120 | 0.332 | 79.0 |
| OUT | 65536 | 1 | 0 | 16 | 170,878 | 120 | **0.384** | 8,207 |
| OUT | 65536 | 1 | 3 | 16 | 341,563 | 120 | 0.192 | 16,400 |

The host example adds an end-to-end figure with 16 requests in flight at 8-cycle memory latency: about 2,000 cycles average completion latency for 512 B writes, with a maximum observed available-ring depth of 16.

## 2. Interpretation

- **The copy engine moves ≤ 8 bytes per step at about 10 cycles per step** (DMA lat 1). The step is DMA beat → permission gate (EMPTY→HOLD→ISSUE→WAIT, 4 cycles) → StorageCore access → advance. That puts aligned throughput at about 0.8 B/cycle, independent of request size above roughly 4 KiB.
- **Misaligned buffers halve throughput.** A step may not cross a guest 8-byte word or a storage 8-byte word, so a buffer offset by 3 bytes needs two steps per 8 bytes. Correctness is unaffected, as the `misaligned` test shows, but the cost is real.
- **Memory latency adds directly**, because there is exactly one DMA request outstanding. At 16-cycle latency, throughput drops to about 0.38 B/cycle.
- **Descriptor walk** costs about 10 cycles per descriptor at latency 1 (two 8-byte reads) and about 40 at latency 16. Fixed per-request ring overhead is about 70 cycles: avail idx, ring entry, 3 used-ring writes and the flags read.
- **Scatter-gather** costs almost nothing beyond the walk: 8 segments versus 1 adds under 0.2 % at 64 KiB.
- With the measured post-route Fmax (`05_synthesis_report.md`), absolute bandwidth is about 0.8 B/cycle × Fmax. **That is a functional-baseline figure, not a product figure.**

## 3. Why v1 is built this way

The brief's order is correctness, protection and spec semantics first, then scale. Single-outstanding DMA makes response routing, ordering, reset draining and the "element before index" rule trivially correct. The permission gate registers its decision, so a revocation can never race a beat already in the check stage. Every one of those properties is now covered by tests, the reference model, mutation testing and formal analysis. They become the regression net for the throughput work below.

## 4. Throughput roadmap (each step is gated by the existing regression)

| Step | Change | Expected effect |
|---|---|---|
| P1 | Pipeline the gate (check stage ‖ issue stage) and allow N outstanding DMA requests with in-order response tags | latency-hiding; ≈ N× at high memory latency |
| P2 | 64-byte line buffer between guest and storage sides, with aligned bursts on both | removes the misalignment penalty; ≥ 4 B/cycle |
| P3 | Burst DMA (multi-beat requests) and a wider StorageCore port | toward 8–16 B/cycle |
| P4 | Pipeline the 64-bit address/compare arithmetic (critical path, see 05) | Fmax |
| P5 | Descriptor prefetch while the previous request's payload moves | hides walk latency |
| P6 | Multiqueue (VIRTIO_BLK_F_MQ), then packed rings, both only after P1–P5 pass the regression + formal gates | parallelism across vCPUs |
