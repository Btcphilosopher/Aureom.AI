# 02 — Register map

## A. Guest-visible VirtIO window: virtio-mmio version 2 (OASIS VirtIO 1.2 §4.2.2)

The guest accesses these registers with 32-bit accesses.

| Offset | Name | R/W | Value / behaviour in this device |
|---|---|---|---|
| 0x000 | MagicValue | R | `0x74726976` ("virt") |
| 0x004 | Version | R | `2` |
| 0x008 | DeviceID | R | `2` (block) |
| 0x00c | VendorID | R | `0x58464c53` |
| 0x010 | DeviceFeatures | R | sel 0: `0x00000204` (SEG_MAX, FLUSH); sel 1: `0x00000003` (VERSION_1, ACCESS_PLATFORM); other sel: 0 |
| 0x014 | DeviceFeaturesSel | W | |
| 0x020 | DriverFeatures | W | ignored once FEATURES_OK is set |
| 0x024 | DriverFeaturesSel | W | |
| 0x030 | QueueSel | W | only queue 0 exists |
| 0x034 | QueueNumMax | R | `MAX_QSZ` (default 256) for queue 0, else 0 |
| 0x038 | QueueNum | W | ignored while QueueReady=1; reset value `MAX_QSZ` |
| 0x044 | QueueReady | RW | write 1 validates the configuration (see below); write 0 = quiesced queue disable |
| 0x050 | QueueNotify | W | value 0 notifies queue 0 (NOTIFICATION_DATA not offered) |
| 0x060 | InterruptStatus | R | bit0 used-buffer notification, bit1 configuration change |
| 0x064 | InterruptACK | W | clears written bits |
| 0x070 | Status | RW | driver can only set bits; writing 0 = device reset (bus held off until the engine drains); bit 6 DEVICE_NEEDS_RESET is device-owned |
| 0x080/0x084 | QueueDescLow/High | W | 16-byte alignment required |
| 0x090/0x094 | QueueDriverLow/High | W | 2-byte alignment required |
| 0x0a0/0x0a4 | QueueDeviceLow/High | W | 4-byte alignment required |
| 0x0ac | SHMSel | W | |
| 0x0b0–0x0bc | SHMLen/SHMBase | R | `0xffffffff` (no shared-memory regions) |
| 0x0c0 | QueueReset | RW | reads 0 (RING_RESET not offered) |
| 0x0fc | ConfigGeneration | R | `0` (configuration space is static) |
| 0x100 | config: capacity[31:0] | R | `CAPACITY_SECTORS` |
| 0x104 | config: capacity[63:32] | R | |
| 0x108 | config: size_max | R | 0 (SIZE_MAX not offered) |
| 0x10c | config: seg_max | R | `MAX_CHAIN − 2` (default 14) |

**QueueReady = 1 validation.** The device accepts the queue only if all of these hold:
- QueueNum is a power of two, non-zero and ≤ QueueNumMax.
- desc % 16 = 0, driver % 2 = 0 and device % 4 = 0.

Otherwise the queue stays disabled, DEVICE_NEEDS_RESET is set and the fatal cause is `QUEUE_CFG`.

## B. Privileged management window (SilicaFlux, never guest-visible)

| Offset | Name | R/W | Description |
|---|---|---|---|
| 0x000 | ENGINE_ID | R | `0x53465649` ("SFVI") |
| 0x004 | ENGINE_VER | R | `[23:16]` major, `[15:8]` minor, `[7:0]` patch, currently 1.0.0. The host library refuses any major ≠ 1. |
| 0x008 | CAPS0 | R | `[7:0]` queues=1, `[15:8]` MAX_CHAIN, `[23:16]` N_WIN, `[24]` split ring=1, `[25]` packed=0, `[26]` indirect=0, `[27]` event_idx=0, `[28]` multiqueue=0, `[29]` permission table=1, `[30]` external IOMMU port=0 |
| 0x00c | CAPS1 | R | `[15:0]` MAX_QSZ, `[31:24]` device id |
| 0x010 | Q0_DOMAIN | RW | `[15:0]` domain, `[31]` valid. **Writes are ignored while QueueReady=1**, and the attempt sets ENGINE_STATUS bit 3. |
| 0x014 | ENGINE_STATUS | R | `[0]` busy, `[1]` active, `[2]` needs_reset, `[3]` domain write ignored (sticky), `[15:8]` last fatal cause, `[23:16]` device status |
| 0x018/0x01c | FAULT_ADDR lo/hi | R | first byte of the last denied access |
| 0x020 | FAULT_INFO | R | `[0]` write, `[1]` valid |
| 0x024/0x028 | CAPACITY lo/hi | R | sectors |
| 0x030 | PERF_CTRL | W | bit0 clears counters, bit1 clears sticky flags |
| 0x040 + 0x20·i | WIN_CTRL | RW | `[0]` valid, `[1]` read, `[2]` write |
| +0x04 | WIN_DOMAIN | RW | `[15:0]` |
| +0x08/+0x0c | WIN_BASE lo/hi | RW | inclusive |
| +0x10/+0x14 | WIN_LIMIT lo/hi | RW | inclusive |
| 0x200 | PERF_DESC | R | descriptors fetched |
| 0x204 | PERF_REQ | R | completions published |
| 0x208/0x20c | PERF_RD_BYTES | R | 64-bit, bytes read over DMA |
| 0x210/0x214 | PERF_WR_BYTES | R | 64-bit, bytes written over DMA |
| 0x218/0x21c | PERF_CLAT_SUM | R | 64-bit, Σ cycles from head fetch to used.idx publication |
| 0x220 | PERF_CLAT_MAX | R | |
| 0x224/0x228 | PERF_WLAT_SUM | R | 64-bit, Σ descriptor-walk cycles |
| 0x22c | PERF_WLAT_MAX | R | |
| 0x230 | PERF_IRQ | R | used-buffer notifications raised |
| 0x234 | PERF_IRQ_SUP | R | notifications suppressed by VIRTQ_AVAIL_F_NO_INTERRUPT |
| 0x238 | PERF_STALL | R | cycles with a DMA or StorageCore request back-pressured |
| 0x23c | PERF_VIOL | R | permission violations (descriptor pre-check + DMA gate) |
| 0x240/0x244 | PERF_QD_SUM | R | 64-bit, Σ avail-ring depth sampled at each head fetch |
| 0x248 | PERF_QD_MAX | R | |
| 0x24c | PERF_QD_N | R | samples (= heads fetched) |
| 0x250 | PERF_NOTIFY | R | notifications received |
| 0x254 | PERF_FATAL | R | DEVICE_NEEDS_RESET events |
| 0x258/0x25c | PERF_BUSY | R | 64-bit, engine busy cycles |
| 0x260/0x264 | PERF_TOTAL | R | 64-bit, cycles since clear (utilisation = BUSY/TOTAL) |
| 0x268 | PERF_IOERR | R | completions with VIRTIO_BLK_S_IOERR |
| 0x26c | PERF_UNSUPP | R | completions with VIRTIO_BLK_S_UNSUPP |

**Window programming rule.** The host library follows this rule (`sfv_hv_set_window`):
1. Clear `WIN_CTRL.valid`.
2. Write the domain, base and limit.
3. Set `WIN_CTRL`.

A half-programmed window is therefore never live.

### Fatal cause codes (ENGINE_STATUS[15:8])

| Code | Name | Trigger |
|---|---|---|
| 1 | QUEUE_CFG | invalid queue configuration at QueueReady=1 |
| 2 | NO_DOMAIN | queue processing requested with no protected domain bound |
| 3 | AVAIL_IDX_JUMP | avail.idx − last_avail_idx > QueueSize |
| 4 | RING_DMA | permission or bus fault on the descriptor table, available ring or used ring |
| 5 | DESC_IDX_OOR | head or next index ≥ QueueSize |
| 6 | CHAIN_LOOP | descriptor revisited within one chain |
| 7 | CHAIN_TOO_LONG | more than MAX_CHAIN descriptors |
| 8 | DESC_FLAGS | INDIRECT (not negotiated) or reserved flag bits |
| 9 | CHAIN_ORDER | device-readable descriptor after a device-writable one |
| 10 | CHAIN_LEN_OVF | total chain length ≥ 2³² |
| 11 | WRITABLE_PERM | device-writable buffer outside the tenant's permission |
| 12 | NO_STATUS | chain has no device-writable byte for the status |
| 13 | DATA_WRITE_DMA | DMA fault while writing a device-writable buffer |
