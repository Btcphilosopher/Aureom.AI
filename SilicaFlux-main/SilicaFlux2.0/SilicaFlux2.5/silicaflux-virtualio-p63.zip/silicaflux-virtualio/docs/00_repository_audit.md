# 00 — Repository audit

**Project 63 VIRTUALIO · Aureom.AI | SilicaFlux-CLOUD**

The brief asks for an audit of the CloudDPU, ControlCore, DMA, memory management, PCIe interfaces, StorageCore, NetworkCore and the existing host runtime before building.

## Finding

No SilicaFlux CloudDPU repository was provided with this build. The workspace started empty and nothing was uploaded. None of the eight subsystems named in the brief exists in source form here. So nothing was reused, and nothing in this deliverable claims compatibility with an existing implementation of those blocks.

| Subsystem | Present? | What this build does instead |
|---|---|---|
| CloudDPU top level | No | `silicaflux_virtio_engine` is a self-contained IP block with four explicit interfaces (below), intended to be instantiated by the CloudDPU top. |
| ControlCore | No | It programs the engine through the **privileged management window** (`mgmt_*` port): domain binding, permission windows, counters. |
| DMA engine | No | The engine is its own DMA master (`dma_*` port: 64-bit, byte-enabled, one request outstanding). Every beat leaving the engine has already passed the tenant permission gate. |
| Memory management / IOMMU | No | It is replaced by a **verified permission-table model** (`silicaflux_virtio_domain_perm`), as the brief allows. `dma_req_domain` is exported so that a platform IOMMU, when one exists, can add translation and a second independent check downstream. |
| PCIe interface | No | The guest-visible transport is **virtio-mmio version 2** (OASIS spec §4.2), a flat 4 KiB register window. Mapping it behind a PCIe BAR, or implementing the virtio-pci capability layout (§4.1), is integration work for when the CloudDPU PCIe block exists. A simulated transport backend is provided (`sim/`, `sim/sfv_sim.h`). |
| StorageCore | No | Defined as the `sc_*` port: 64-bit byte-enabled read/write plus flush, one request outstanding, with an error response. Simulation models live in `sim/sim_env.cpp` and `tb/sv/`. |
| NetworkCore | No | Not used. See the device-type decision below. |
| Host runtime | No | It is new: `host/` (C library `libsfvirtio`) plus `sim/sfv_sim.h` (simulated backend). |

## Device-type decision: virtio-blk

The brief says: *"Prefer VirtIO network or block-device operations depending on the actual available backend."* No NetworkCore or StorageCore exists, so the choice rested on which device gives the most protocol coverage at the lowest semantic risk.

**virtio-blk (device ID 2)** won for four reasons:

1. Its request/completion contract is fully defined by the specification (§5.2.6): a header, a payload and a status byte. This made an independent reference model possible that predicts every byte.
2. It exercises both directions of DMA (OUT reads guest memory, IN writes it) plus device-writable status. Those are exactly the paths where tenant protection matters.
3. It needs one virtqueue (`requestq`). The brief's "one queue pair" maps to that queue's available ring (submission) and used ring (completion). virtio-net would need a receive/transmit queue pair plus packet-buffer semantics with no backend to validate against.
4. A real StorageCore can replace the RAM model behind the same `sc_*` port without changing the VirtIO side.

virtio-net remains a natural follow-on. The split-ring machinery (queue controller, walker, permission gate) is device-independent; only `silicaflux_virtio_blk_backend` is block-specific.

## Interfaces defined by this build (integration contract)

| Port | Direction | Protocol | Notes |
|---|---|---|---|
| `mmio_*`, `irq` | guest → engine | valid/ready, one response 1 cycle after accept | virtio-mmio v2 register map, 12-bit offset |
| `mgmt_*` | ControlCore → engine | same | privileged; must never be mapped into a guest |
| `dma_*` | engine → host memory | valid/ready request, 1 response per request, 1 outstanding | 8-byte aligned, `be` byte lanes, `dma_req_domain` tag |
| `sc_*` | engine → StorageCore | same | byte address, `op` = READ/WRITE/FLUSH |

The ordering requirement the platform must meet is in `01_architecture.md` §5.
