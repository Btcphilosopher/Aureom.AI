#!/usr/bin/env bash
# Synthesis flow for silicaflux_virtio_engine (open-source tools):
#   1. sv2v front-end (Yosys 0.33's SystemVerilog parser lacks sized casts)
#   2. Yosys generic synthesis, hierarchical -> per-module cell/flop counts
#   3. Yosys synth_ecp5 + nextpnr-ecp5 place & route of an OOC wrapper -> Fmax
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p out
RTL=$(sed 's|^|../rtl/|' ../rtl/filelist.f)
sv2v --top=silicaflux_virtio_engine $RTL > out/engine.v
sv2v --top=synth_ooc_wrap $RTL synth_ooc_wrap.sv > out/ooc.v
yosys -q -l out/yosys_generic.log -p "read_verilog out/engine.v; hierarchy -check -top silicaflux_virtio_engine; \
  synth -top silicaflux_virtio_engine; tee -o out/generic_stat.txt stat; check -assert" 
yosys -q -l out/yosys_generic_flat.log -p "read_verilog out/engine.v; synth -flatten -top silicaflux_virtio_engine; \
  tee -o out/generic_flat_stat.txt stat -tech cmos"
yosys -q -l out/yosys_ecp5_engine.log -p "read_verilog out/engine.v; synth_ecp5 -top silicaflux_virtio_engine; \
  tee -o out/ecp5_engine_stat.txt stat"
yosys -q -l out/yosys_ecp5_ooc.log -p "read_verilog out/ooc.v; synth_ecp5 -top synth_ooc_wrap -json out/ooc.json; \
  tee -o out/ecp5_ooc_stat.txt stat"
nextpnr-ecp5 --85k --package CABGA381 --json out/ooc.json --freq 100 --seed 1 \
  --report out/nextpnr_report.json --log out/nextpnr.log --quiet || true
grep -E "Max frequency|Info: Device utilisation" -A12 out/nextpnr.log | grep -E "MHz|TRELLIS_SLICE|TRELLIS_FF|TRELLIS_COMB|DP16KD|LUT" | head -20 || true
