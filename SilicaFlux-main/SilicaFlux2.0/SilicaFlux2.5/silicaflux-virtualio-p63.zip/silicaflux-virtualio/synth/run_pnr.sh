#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
RTL=$(sed 's|^|../rtl/|' ../rtl/filelist.f)
sv2v --top=synth_ooc_wrap $RTL synth_ooc_wrap.sv > out/ooc.v
yosys -q -l out/yosys_ecp5_ooc.log -p "read_verilog out/ooc.v; synth_ecp5 -top synth_ooc_wrap -json out/ooc.json; tee -o out/ecp5_ooc_stat.txt stat"
nextpnr-ecp5 --85k --package CABGA381 --json out/ooc.json --freq 100 --seed 1 --report out/nextpnr_report.json --log out/nextpnr.log --quiet
echo PNR_DONE
