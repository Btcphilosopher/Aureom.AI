// synth_ooc_wrap.sv — out-of-context timing wrapper (synthesis/P&R only).
// The engine has ~560 ports; no FPGA package can bond them. Every engine input
// is driven from a register in a serial shift chain and every output is
// registered and XOR-folded into one pin, so all engine logic stays live and
// every engine I/O path is register-to-register. The wrapper's own flops are
// reported separately in docs/05_synthesis_report.md.
module synth_ooc_wrap (input logic clk, input logic rst_n, input logic sin, output logic sout);
  localparam int NI = 230;   // 50 mmio + 46 mgmt + 67 dma + 67 sc input bits
  logic [NI-1:0] ish;
  always_ff @(posedge clk) ish <= {ish[NI-2:0], sin};
  logic mmio_req_ready, mmio_resp_valid, irq, mgmt_req_ready, mgmt_resp_valid;
  logic [31:0] mmio_resp_rdata, mgmt_resp_rdata;
  logic dma_req_valid, dma_req_we, sc_req_valid;
  logic [63:0] dma_req_addr, dma_req_wdata, sc_req_wdata;
  logic [7:0] dma_req_be, sc_req_be;
  logic [15:0] dma_req_domain;
  logic [1:0] sc_req_op;
  logic [31:0] sc_req_addr;
  int unsigned p;
  silicaflux_virtio_engine u (
    .clk, .rst_n,
    .mmio_req_valid(ish[0]), .mmio_req_ready, .mmio_req_we(ish[1]), .mmio_req_addr(ish[13:2]),
    .mmio_req_wdata(ish[45:14]), .mmio_req_be(ish[49:46]), .mmio_resp_valid, .mmio_resp_rdata, .irq,
    .mgmt_req_valid(ish[50]), .mgmt_req_ready, .mgmt_req_we(ish[51]), .mgmt_req_addr(ish[63:52]),
    .mgmt_req_wdata(ish[95:64]), .mgmt_resp_valid, .mgmt_resp_rdata,
    .dma_req_valid, .dma_req_ready(ish[96]), .dma_req_addr, .dma_req_we, .dma_req_wdata, .dma_req_be,
    .dma_req_domain, .dma_resp_valid(ish[97]), .dma_resp_rdata(ish[161:98]), .dma_resp_err(ish[162]),
    .sc_req_valid, .sc_req_ready(ish[163]), .sc_req_op, .sc_req_addr, .sc_req_wdata, .sc_req_be,
    .sc_resp_valid(ish[164]), .sc_resp_rdata(ish[228:165]), .sc_resp_err(ish[229]));
  logic [399:0] o, oq;
  assign o = {mmio_req_ready, mmio_resp_valid, irq, mmio_resp_rdata, mgmt_req_ready, mgmt_resp_valid,
              mgmt_resp_rdata, dma_req_valid, dma_req_we, dma_req_addr, dma_req_wdata, dma_req_be,
              dma_req_domain, sc_req_valid, sc_req_op, sc_req_addr, sc_req_wdata, sc_req_be, 33'd0};
  always_ff @(posedge clk) begin oq <= o; sout <= ^oq; end
endmodule
