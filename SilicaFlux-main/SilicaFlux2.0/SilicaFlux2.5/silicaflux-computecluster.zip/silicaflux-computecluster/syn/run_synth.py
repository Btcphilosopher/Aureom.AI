#!/usr/bin/env python3
"""SilicaFlux Project 32 synthesis: independent build targets for one vector cluster, one tensor cluster and the
full compute subsystem (Yosys 0.33, technology-independent).

Flow per target (syn/<target>/synth.ys, log and netlists in build/synth/<target>/):
  read_verilog -defer -sv (rtl/files.f) -> hierarchy -check -top T [-chparam ...] -> proc -> check -assert
  -> synth -run begin:fine (coarse: memory inference, memory -nomap)
  -> opt -fast -full; techmap; opt -fast; abc -fast; opt -fast       (= synth "fine" WITHOUT memory_map)
  -> latch check, check -assert, stat, write_json / write_verilog (hierarchy kept, NOT flattened)
Memories are kept as inferred $mem_v2 cells and reported (width x depth, ports): on silicon they are SRAM macros
(SRAM Wrapper Library ASIC backend), not flip-flops, so mapping them to gates would only distort the logic count.

Reports (reports/synth/): per target cell counts by type, flip-flops, inferred memories, per-region totals for every
top-level instance (u_vector_*, u_tensor_*, u_noc, ...) computed from the hierarchical netlist, the instance-name
check (every populated slot present under its fixed name) and a fanout analysis (leaf sink pins reached by each
top-level input / internal net).  Technology-independent: generic gates are not silicon area.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from collections import Counter, defaultdict
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "build" / "synth"
REP = ROOT / "reports" / "synth"

TARGETS = {
    # name: (top, chparams, description)
    "vector_cluster": ("silicaflux_vector_cluster", {}, "one vector cluster, defaults: 4 FP32 lanes, 32-bit, 64 KiB SPM"),
    "tensor_cluster": ("silicaflux_tensor_cluster", {}, "one tensor cluster, defaults: 4x4 INT8, 2 KiB operand buffers"),
    "compute_min": ("silicaflux_compute_cluster", {}, "compute subsystem, minimum configuration: 1 vector + 1 tensor"),
    "compute_hpc": ("silicaflux_compute_cluster", dict(NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2),
                    "compute subsystem, HPC shape: 4 vector + 2 tensor"),
    "compute_hpc_piped": ("silicaflux_compute_cluster",
                          dict(NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2, MEM_PIPE=1, LM_PIPE=1, EXT_PIPE=1,
                               CMD_PIPE=1),
                          "compute subsystem, HPC shape with every NoC-facing register slice"),
}


def files():
    f = (ROOT / "rtl" / "files.f").read_text().split()
    inc = [str(ROOT / x[len("+incdir+"):]) for x in f if x.startswith("+incdir+")]
    src = [str(ROOT / x) for x in f if not x.startswith("+")]
    return inc, src


def script(top: str, chp: dict) -> str:
    inc, src = files()
    rd = "read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{i}" for i in inc) + " " + " ".join(src)
    ch = " ".join(f"-chparam {k} {v}" for k, v in chp.items())
    return "\n".join([
        rd,
        f"hierarchy -check -top {top} {ch}",
        "proc",
        "opt_clean",
        "check -assert",
        f"synth -top {top} -run begin:fine",
        "tee -o mem_inferred.txt select -list t:$mem_v2 %m",
        "opt -fast -full",
        "techmap",
        "opt -fast",
        "abc -fast",
        "opt -fast",
        "opt_clean -purge",
        "select -assert-none t:$dlatch t:$_DLATCH_* t:$_DLATCH*_ t:$_SR_*",
        "hierarchy -check",
        "check -assert",
        f"tee -o stat.txt stat -top {top}",
        "write_json netlist.json",
        "write_verilog -noattr netlist.v",
    ]) + "\n"


def run_target(name: str) -> dict:
    top, chp, desc = TARGETS[name]
    d = BUILD / name
    d.mkdir(parents=True, exist_ok=True)
    (d / "synth.ys").write_text(script(top, chp))
    t0 = time.time()
    p = subprocess.run(["yosys", "-q", "-l", "yosys.log", "-s", "synth.ys"], cwd=d,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    secs = time.time() - t0
    res = dict(target=name, top=top, chparams=chp, desc=desc, ok=p.returncode == 0, secs=round(secs, 1),
               rc=p.returncode, tail=p.stdout[-2000:])
    if res["ok"]:
        res.update(analyse(d, top, chp))
    return res


# ============================================================================ netlist analysis
FF_RE = re.compile(r"^\$_(DFF|DFFE|SDFF|SDFFE|SDFFCE|ADFF|ADFFE|DFFSR|DFFSRE|ALDFF|ALDFFE)_")


def analyse(d: Path, top: str, chp: dict) -> dict:
    nl = json.loads((d / "netlist.json").read_text())
    mods = nl["modules"]
    memo: dict[str, dict] = {}

    def totals(m: str) -> dict:
        if m in memo:
            return memo[m]
        t = dict(cells=0, ffs=0, mem_bits=0, mems=0, types=Counter())
        for cn, c in mods[m]["cells"].items():
            ty = c["type"]
            if ty in mods:
                sub = totals(ty)
                for k in ("cells", "ffs", "mem_bits", "mems"):
                    t[k] += sub[k]
                t["types"].update(sub["types"])
            elif ty == "$mem_v2":
                pr = c["parameters"]
                w, n = int(pr["WIDTH"], 2), int(pr["SIZE"], 2)
                t["mem_bits"] += w * n
                t["mems"] += 1
            else:
                t["cells"] += 1
                t["types"][ty] += 1
                if FF_RE.match(ty):
                    t["ffs"] += 1
        memo[m] = t
        return t

    # top module name after chparam is "$paramod..."; find the module marked top
    topm = next((n for n, m in mods.items() if m.get("attributes", {}).get("top") in ("00000000000000000000000000000001", 1, "1")), None)
    if topm is None:
        topm = next(n for n in mods if n.endswith(top) or top in n)
    tt = totals(topm)

    # memories inferred, with their instance path
    mems = []

    def walk(m: str, path: str):
        for cn, c in mods[m]["cells"].items():
            ty = c["type"]
            p = f"{path}/{cn}" if path else cn
            if ty in mods:
                walk(ty, p)
            elif ty == "$mem_v2":
                pr = c["parameters"]
                mems.append(dict(path=p, width=int(pr["WIDTH"], 2), depth=int(pr["SIZE"], 2),
                                 rd_ports=int(pr["RD_PORTS"], 2), wr_ports=int(pr["WR_PORTS"], 2),
                                 bits=int(pr["WIDTH"], 2) * int(pr["SIZE"], 2)))
    walk(topm, "")

    # per top-level instance (floorplan regions)
    regions = []
    for cn, c in mods[topm]["cells"].items():
        ty = c["type"]
        if ty in mods:
            t = totals(ty)
            regions.append(dict(instance=cn, module=ty, cells=t["cells"], ffs=t["ffs"], mem_bits=t["mem_bits"],
                                mems=t["mems"]))
    glue = dict(instance="(top-level glue)", module=topm,
                cells=tt["cells"] - sum(r["cells"] for r in regions), ffs=tt["ffs"] - sum(r["ffs"] for r in regions),
                mem_bits=tt["mem_bits"] - sum(r["mem_bits"] for r in regions), mems=0)
    regions.sort(key=lambda r: r["instance"])

    # leaf fanout: number of leaf cell input pins reached by each top-module net (through the hierarchy)
    pin_memo: dict[tuple[str, str], list[int]] = {}

    def port_loads(m: str, port: str) -> list[int]:
        """leaf input-pin loads of every bit of input port `port` of module m"""
        key = (m, port)
        if key in pin_memo:
            return pin_memo[key]
        mod = mods[m]
        bits = mod["ports"][port]["bits"]
        loads = net_loads(m)
        res = [loads.get(b, 0) for b in bits]
        pin_memo[key] = res
        return res

    net_memo: dict[str, dict] = {}

    def net_loads(m: str) -> dict:
        if m in net_memo:
            return net_memo[m]
        mod = mods[m]
        loads: dict = defaultdict(int)
        for cn, c in mod["cells"].items():
            ty = c["type"]
            dirs = c.get("port_directions", {})
            for pn, bits in c["connections"].items():
                if ty in mods:
                    if mods[ty]["ports"].get(pn, {}).get("direction") != "input":
                        continue
                    sub = port_loads(ty, pn)
                    for b, n in zip(bits, sub):
                        if isinstance(b, int):
                            loads[b] += n
                else:
                    if dirs.get(pn) != "input":
                        continue
                    for b in bits:
                        if isinstance(b, int):
                            loads[b] += 1
        net_memo[m] = loads
        return loads

    loads = net_loads(topm)
    names: dict[int, str] = {}
    for nn, n in mods[topm]["netnames"].items():
        if nn.startswith("$"):
            continue
        for i, b in enumerate(n["bits"]):
            if isinstance(b, int) and b not in names:
                names[b] = nn if len(n["bits"]) == 1 else f"{nn}[{i}]"
    fan = sorted(((loads[b], names.get(b, f"bit{b}")) for b in loads), reverse=True)
    top_fan = [dict(net=n, leaf_loads=c) for c, n in fan[:25]]

    # wide buses at the top level (port and inter-instance)
    buses = []
    for nn, n in mods[topm]["netnames"].items():
        if nn.startswith("$") or len(n["bits"]) < 64:
            continue
        buses.append(dict(net=nn, width=len(n["bits"]),
                          max_bit_loads=max((loads.get(b, 0) for b in n["bits"] if isinstance(b, int)), default=0)))
    buses.sort(key=lambda x: -x["width"])

    # stable-name check: populated slots under fixed instance names
    names_top = set(mods[topm]["cells"])
    expect = []
    if top == "silicaflux_compute_cluster":
        nv, nt = chp.get("NUM_VECTOR_CLUSTERS", 1), chp.get("NUM_TENSOR_CLUSTERS", 1)
        expect = [f"u_vector_{k}" for k in range(8)] + [f"u_tensor_{j}" for j in range(4)] + \
                 ["u_noc", "u_cmd_route", "u_cpl_arb", "u_regs", "u_ext_slice"]
        populated = {f"u_vector_{k}" for k in range(nv)} | {f"u_tensor_{j}" for j in range(nt)}
        for r in regions:
            r["populated"] = r["instance"] in populated or not r["instance"].startswith(("u_vector_", "u_tensor_"))
    elif top == "silicaflux_vector_cluster":
        expect = ["g_cl.u_tile", "g_cl.u_ctrl", "g_cl.u_rst", "g_cl.u_mem_slice", "g_cl.g_lm.u_lm_slice"]
    else:
        expect = ["g_cl.u_tsu", "g_cl.u_ctrl", "g_cl.u_rst", "g_cl.u_mem_slice", "g_cl.u_upsize"]
    missing = [e for e in expect if e not in names_top]
    types = dict(tt["types"].most_common())
    return dict(module=topm, cells=tt["cells"], ffs=tt["ffs"], mem_bits=tt["mem_bits"], mems=tt["mems"],
                cell_types=types, memories=mems, regions=regions + [glue], fanout=top_fan, wide_buses=buses[:20],
                expected_instances=expect, missing_instances=missing)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--jobs", type=int, default=3)
    a = ap.parse_args()
    names = [n for n in TARGETS if not a.only or n in a.only.split(",")]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(run_target, names))
    REP.mkdir(parents=True, exist_ok=True)
    for r in res:
        (REP / f"{r['target']}.json").write_text(json.dumps(r, indent=1))
        # keep the raw tool outputs next to the summary
        d = BUILD / r["target"]
        for f in ("synth.ys", "yosys.log", "stat.txt", "mem_inferred.txt"):
            if (d / f).exists():
                (REP / r["target"]).mkdir(exist_ok=True)
                (REP / r["target"] / f).write_bytes((d / f).read_bytes())
        print(f"{r['target']:18s} ok={r['ok']} {r['secs']}s cells={r.get('cells')} ffs={r.get('ffs')} "
              f"mem_bits={r.get('mem_bits')} missing={r.get('missing_instances')}")
    sys.exit(0 if all(r["ok"] for r in res) else 1)


if __name__ == "__main__":
    main()
