# Regression (RTL simulation, Verilator 5.020)

**30 / 30 runs pass.**  Every run is checked by `model/cc_check.py` against independent references (TENSORCORE 08 `tsu_ref.py` for GEMM, binary64-rounded FP32 for FADD / FMUL): every completion record field incl. SEQ and source ID, the error flag, the whole 1 MiB shared-memory image, LOST after every cluster reset, SFB2 protocol checkers on every crossbar port and the shared-memory port, and the coverage items each scenario must hit.

| stage | run | config | scenario | mode | commands | records checked | destroyed by reset | sim s | result |
|---|---|---|---|---|---|---|---|---|---|
| 1 | `s1_vec_basic` | v1 | basic | fast | 6 | 6 | 0 | 2.0 | PASS |
| 1 | `s1_vec_errors` | v1 | errors | fast | 6 | 6 | 0 | 2.4 | PASS |
| 1 | `s1_vec_reset` | v1 | reset | bp | 5 | 3 | 2 | 1.7 | PASS |
| 1 | `s1_vec_bp` | v1 | mixed | slow | 13 | 13 | 0 | 2.9 | PASS |
| 1 | `s1_tsu_basic` | t1 | basic | fast | 5 | 5 | 0 | 1.5 | PASS |
| 1 | `s1_tsu_errors` | t1 | errors | fast | 6 | 6 | 0 | 2.1 | PASS |
| 1 | `s1_tsu_reset` | t1 | reset | bp | 4 | 2 | 2 | 1.3 | PASS |
| 1 | `s1_tsu_bp` | t1 | mixed | slow | 5 | 5 | 0 | 1.3 | PASS |
| 2 | `s2_min_basic` | min | basic | fast | 11 | 11 | 0 | 1.7 | PASS |
| 2 | `s2_min_mixed` | min | mixed | fast | 19 | 19 | 0 | 2.2 | PASS |
| 2 | `s2_min_mixed_bp` | min | mixed | bp | 17 | 17 | 0 | 3.4 | PASS |
| 2 | `s2_min_mixed_slow` | min | mixed | slow | 18 | 18 | 0 | 3.7 | PASS |
| 2 | `s2_min_errors` | min | errors | bp | 12 | 12 | 0 | 1.6 | PASS |
| 2 | `s2_min_reset` | min | reset | bp | 12 | 8 | 4 | 2.9 | PASS |
| 2 | `s2_min_reset_hold` | min_hold | reset | fast | 12 | 8 | 4 | 2.4 | PASS |
| 2 | `s2_legacy_basic` | min_legacy | basic | fast | 11 | 11 | 0 | 1.1 | PASS |
| 2 | `s2_legacy_mixed` | min_legacy | mixed | bp | 18 | 18 | 0 | 2.0 | PASS |
| 3 | `s3_hpc_mixed` | hpc | mixed | fast | 59 | 59 | 0 | 5.7 | PASS |
| 3 | `s3_hpc_mixed_bp` | hpc | mixed | bp | 64 | 64 | 0 | 18.6 | PASS |
| 3 | `s3_hpc_errors` | hpc | errors | bp | 28 | 28 | 0 | 3.5 | PASS |
| 3 | `s3_hpc_reset` | hpc | reset | bp | 28 | 24 | 4 | 12.6 | PASS |
| 3 | `s3_p64_mixed` | p64 | mixed | bp | 25 | 25 | 0 | 4.6 | PASS |
| 3 | `s3_p64_reset` | p64 | reset | slow | 16 | 12 | 4 | 3.1 | PASS |
| 3 | `s3_p64_basic` | p64 | basic | fast | 17 | 17 | 0 | 2.7 | PASS |
| 3 | `s3_p128_mixed` | p128 | mixed | bp | 34 | 34 | 0 | 8.2 | PASS |
| 3 | `s3_p128_errors` | p128 | errors | fast | 20 | 20 | 0 | 2.1 | PASS |
| 3 | `s3_phys_mixed` | phys | mixed | bp | 60 | 60 | 0 | 3.8 | PASS |
| 3 | `s3_phys_reset` | phys | reset | bp | 28 | 24 | 4 | 2.8 | PASS |
| 3 | `s3_max_mixed` | max | mixed | bp | 118 | 118 | 0 | 24.4 | PASS |
| 3 | `s3_max_reset` | max | reset | fast | 52 | 48 | 4 | 3.8 | PASS |

## Configurations

| config | parameters |
|---|---|
| hpc | nv=4, nt=2, w=32, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=1, local_mem=1, vec_lanes=4, vec_spm=65536, vec_banks=4, vec_dma_buf=0, tsu_rows=4, tsu_cols=4, tsu_tile_k=64, tsu_opbuf=2048, tsu_banks=4, tsu_quant=0, tsu_dbuf=0, rst_hold=64, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| max | nv=8, nt=4, w=32, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=1, local_mem=1, vec_lanes=1, vec_spm=4096, vec_banks=4, vec_dma_buf=0, tsu_rows=2, tsu_cols=2, tsu_tile_k=64, tsu_opbuf=512, tsu_banks=2, tsu_quant=0, tsu_dbuf=0, rst_hold=64, rb_aw=17, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| min | nv=1, nt=1, w=32, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=1, local_mem=1, vec_lanes=4, vec_spm=65536, vec_banks=4, vec_dma_buf=0, tsu_rows=4, tsu_cols=4, tsu_tile_k=64, tsu_opbuf=2048, tsu_banks=4, tsu_quant=0, tsu_dbuf=0, rst_hold=8, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| min_hold | nv=1, nt=1, w=32, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=1, local_mem=1, vec_lanes=4, vec_spm=65536, vec_banks=4, vec_dma_buf=0, tsu_rows=4, tsu_cols=4, tsu_tile_k=64, tsu_opbuf=2048, tsu_banks=4, tsu_quant=0, tsu_dbuf=0, rst_hold=64, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| min_legacy | nv=1, nt=1, w=32, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=0, local_mem=1, vec_lanes=4, vec_spm=65536, vec_banks=4, vec_dma_buf=0, tsu_rows=4, tsu_cols=4, tsu_tile_k=64, tsu_opbuf=2048, tsu_banks=4, tsu_quant=0, tsu_dbuf=0, rst_hold=8, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| p128 | nv=2, nt=2, w=128, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=1, local_mem=0, vec_lanes=8, vec_spm=16384, vec_banks=4, vec_dma_buf=0, tsu_rows=8, tsu_cols=8, tsu_tile_k=64, tsu_opbuf=4096, tsu_banks=8, tsu_quant=1, tsu_dbuf=1, rst_hold=64, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| p64 | nv=2, nt=1, w=64, mem_pipe=1, lm_pipe=1, ext_pipe=1, cmd_pipe=1, cmd_if=1, local_mem=1, vec_lanes=4, vec_spm=65536, vec_banks=4, vec_dma_buf=0, tsu_rows=4, tsu_cols=4, tsu_tile_k=64, tsu_opbuf=2048, tsu_banks=4, tsu_quant=0, tsu_dbuf=0, rst_hold=64, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| phys | nv=4, nt=2, w=32, mem_pipe=1, lm_pipe=1, ext_pipe=1, cmd_pipe=1, cmd_if=1, local_mem=1, vec_lanes=1, vec_spm=1024, vec_banks=2, vec_dma_buf=0, tsu_rows=2, tsu_cols=2, tsu_tile_k=64, tsu_opbuf=512, tsu_banks=2, tsu_quant=0, tsu_dbuf=0, rst_hold=64, rb_aw=16, vec_cmdq=2, vec_perf=0, tsu_cmdq=2, tsu_perf=0, shell_perf=0 |
| t1 | nv=0, nt=1, w=32, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=1, local_mem=1, vec_lanes=4, vec_spm=65536, vec_banks=4, vec_dma_buf=0, tsu_rows=4, tsu_cols=4, tsu_tile_k=64, tsu_opbuf=2048, tsu_banks=4, tsu_quant=0, tsu_dbuf=0, rst_hold=64, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |
| v1 | nv=1, nt=0, w=32, mem_pipe=0, lm_pipe=0, ext_pipe=0, cmd_pipe=0, cmd_if=1, local_mem=1, vec_lanes=4, vec_spm=65536, vec_banks=4, vec_dma_buf=0, tsu_rows=4, tsu_cols=4, tsu_tile_k=64, tsu_opbuf=2048, tsu_banks=4, tsu_quant=0, tsu_dbuf=0, rst_hold=64, rb_aw=16, vec_cmdq=8, vec_perf=1, tsu_cmdq=4, tsu_perf=1, shell_perf=1 |

## Contention, concurrency and coverage (from each run's stats.txt)

**s1_vec_basic**
```
master0 accepted 10 stall_cycles 0 arb_losses 0
master1 accepted 1934 stall_cycles 0 arb_losses 0
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 0
mem_transactions 1934 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s1_vec_errors**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 391 stall_cycles 0 arb_losses 0
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 0
mem_transactions 391 mem_errors 1
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s1_vec_reset**
```
master0 accepted 511 stall_cycles 1579 arb_losses 77
master1 accepted 509 stall_cycles 1747 arb_losses 59
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 509
mem_transactions 1018 mem_errors 0
cover iso_req_captured 1 iso_rsp_captured 0 iso_error_responses 1 iso_responses_sunk 1
```
**s1_vec_bp**
```
master0 accepted 5013 stall_cycles 37346 arb_losses 1415
master1 accepted 4931 stall_cycles 39270 arb_losses 1325
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 5013
mem_transactions 9944 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s1_tsu_basic**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 6186 stall_cycles 6015 arb_losses 0
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 0
mem_transactions 6186 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s1_tsu_errors**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 1720 stall_cycles 1655 arb_losses 0
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 0
mem_transactions 1720 mem_errors 3
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s1_tsu_reset**
```
master0 accepted 1535 stall_cycles 5092 arb_losses 177
master1 accepted 1700 stall_cycles 15522 arb_losses 1869
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 1535
mem_transactions 3235 mem_errors 0
cover iso_req_captured 1 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 1
```
**s1_tsu_bp**
```
master0 accepted 6764 stall_cycles 49605 arb_losses 1975
master1 accepted 6441 stall_cycles 117622 arb_losses 12316
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 6764
mem_transactions 13205 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s2_min_basic**
```
master0 accepted 10 stall_cycles 0 arb_losses 0
master1 accepted 1934 stall_cycles 0 arb_losses 0
master2 accepted 6420 stall_cycles 6249 arb_losses 0
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 0
mem_transactions 8354 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s2_min_mixed**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 4339 stall_cycles 3186 arb_losses 26
master2 accepted 11410 stall_cycles 17424 arb_losses 3124
vector_and_tensor_busy_cycles 26224
max_clusters_busy 2
host_transactions 0
mem_transactions 15749 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s2_min_mixed_bp**
```
master0 accepted 11172 stall_cycles 60310 arb_losses 16740
master1 accepted 4830 stall_cycles 42362 arb_losses 18810
master2 accepted 12254 stall_cycles 146190 arb_losses 40575
vector_and_tensor_busy_cycles 84932
max_clusters_busy 2
host_transactions 11172
mem_transactions 28256 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s2_min_mixed_slow**
```
master0 accepted 8107 stall_cycles 98065 arb_losses 33563
master1 accepted 3926 stall_cycles 69095 arb_losses 33859
master2 accepted 7834 stall_cycles 182314 arb_losses 52436
vector_and_tensor_busy_cycles 117477
max_clusters_busy 2
host_transactions 8107
mem_transactions 19867 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s2_min_errors**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 184 stall_cycles 357 arb_losses 8
master2 accepted 1719 stall_cycles 8518 arb_losses 112
vector_and_tensor_busy_cycles 1247
max_clusters_busy 2
host_transactions 0
mem_transactions 1903 mem_errors 3
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s2_min_reset**
```
master0 accepted 4370 stall_cycles 20139 arb_losses 4314
master1 accepted 1319 stall_cycles 10977 arb_losses 4697
master2 accepted 4752 stall_cycles 51776 arb_losses 11703
vector_and_tensor_busy_cycles 21410
max_clusters_busy 2
host_transactions 4367
mem_transactions 10438 mem_errors 0
cover iso_req_captured 2 iso_rsp_captured 1 iso_error_responses 0 iso_responses_sunk 2
```
**s2_min_reset_hold**
```
master0 accepted 2 stall_cycles 0 arb_losses 0
master1 accepted 1069 stall_cycles 739 arb_losses 50
master2 accepted 4746 stall_cycles 5998 arb_losses 684
vector_and_tensor_busy_cycles 5921
max_clusters_busy 2
host_transactions 0
mem_transactions 5815 mem_errors 0
cover iso_req_captured 2 iso_rsp_captured 0 iso_error_responses 1 iso_responses_sunk 2
```
**s2_legacy_basic**
```
master0 accepted 10 stall_cycles 0 arb_losses 0
master1 accepted 2609 stall_cycles 0 arb_losses 0
master2 accepted 6441 stall_cycles 6270 arb_losses 0
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 0
mem_transactions 9050 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s2_legacy_mixed**
```
master0 accepted 6605 stall_cycles 45961 arb_losses 17462
master1 accepted 5185 stall_cycles 45874 arb_losses 20695
master2 accepted 6748 stall_cycles 97086 arb_losses 36557
vector_and_tensor_busy_cycles 91500
max_clusters_busy 2
host_transactions 6605
mem_transactions 18538 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_hpc_mixed**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 4300 stall_cycles 22240 arb_losses 17942
master2 accepted 2250 stall_cycles 14639 arb_losses 12387
master3 accepted 4057 stall_cycles 21982 arb_losses 17931
master4 accepted 3847 stall_cycles 21528 arb_losses 17684
master5 accepted 7264 stall_cycles 42647 arb_losses 30285
master6 accepted 5893 stall_cycles 40567 arb_losses 29656
vector_and_tensor_busy_cycles 45127
max_clusters_busy 6
host_transactions 0
mem_transactions 27611 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_hpc_mixed_bp**
```
master0 accepted 7413 stall_cycles 145109 arb_losses 109999
master1 accepted 4632 stall_cycles 130457 arb_losses 107584
master2 accepted 3107 stall_cycles 100251 arb_losses 84819
master3 accepted 4376 stall_cycles 126873 arb_losses 105172
master4 accepted 2978 stall_cycles 96835 arb_losses 82260
master5 accepted 7000 stall_cycles 198927 arb_losses 133803
master6 accepted 7264 stall_cycles 202052 arb_losses 135225
vector_and_tensor_busy_cycles 171261
max_clusters_busy 6
host_transactions 7413
mem_transactions 36770 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_hpc_errors**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 508 stall_cycles 5056 arb_losses 3709
master2 accepted 259 stall_cycles 4984 arb_losses 3744
master3 accepted 157 stall_cycles 3639 arb_losses 2864
master4 accepted 82 stall_cycles 2104 arb_losses 1686
master5 accepted 1700 stall_cycles 20564 arb_losses 6042
master6 accepted 1687 stall_cycles 20401 arb_losses 6011
vector_and_tensor_busy_cycles 7273
max_clusters_busy 6
host_transactions 0
mem_transactions 4393 mem_errors 8
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_hpc_reset**
```
master0 accepted 6159 stall_cycles 73431 arb_losses 46410
master1 accepted 1809 stall_cycles 43895 arb_losses 34985
master2 accepted 1716 stall_cycles 43829 arb_losses 35345
master3 accepted 555 stall_cycles 17579 arb_losses 14763
master4 accepted 1275 stall_cycles 32102 arb_losses 25949
master5 accepted 6169 stall_cycles 120209 arb_losses 63807
master6 accepted 4765 stall_cycles 106517 arb_losses 62438
vector_and_tensor_busy_cycles 68574
max_clusters_busy 6
host_transactions 6157
mem_transactions 22446 mem_errors 0
cover iso_req_captured 2 iso_rsp_captured 0 iso_error_responses 1 iso_responses_sunk 2
```
**s3_p64_mixed**
```
master0 accepted 11336 stall_cycles 92411 arb_losses 35445
master1 accepted 2679 stall_cycles 49249 arb_losses 30613
master2 accepted 3147 stall_cycles 54318 arb_losses 32451
master3 accepted 11638 stall_cycles 206543 arb_losses 54888
vector_and_tensor_busy_cycles 97017
max_clusters_busy 3
host_transactions 11336
mem_transactions 28800 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_p64_reset**
```
master0 accepted 5035 stall_cycles 56726 arb_losses 13643
master1 accepted 459 stall_cycles 13911 arb_losses 8824
master2 accepted 972 stall_cycles 22798 arb_losses 12381
master3 accepted 4767 stall_cycles 122039 arb_losses 20501
vector_and_tensor_busy_cycles 38579
max_clusters_busy 3
host_transactions 5033
mem_transactions 11231 mem_errors 0
cover iso_req_captured 1 iso_rsp_captured 0 iso_error_responses 1 iso_responses_sunk 4
```
**s3_p64_basic**
```
master0 accepted 20 stall_cycles 0 arb_losses 0
master1 accepted 1496 stall_cycles 0 arb_losses 0
master2 accepted 1766 stall_cycles 0 arb_losses 0
master3 accepted 6431 stall_cycles 18780 arb_losses 0
vector_and_tensor_busy_cycles 0
max_clusters_busy 1
host_transactions 0
mem_transactions 9693 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_p128_mixed**
```
master0 accepted 6404 stall_cycles 50634 arb_losses 23534
master1 accepted 894 stall_cycles 18400 arb_losses 13884
master2 accepted 1014 stall_cycles 20324 arb_losses 15286
master3 accepted 3569 stall_cycles 69151 arb_losses 35405
master4 accepted 7248 stall_cycles 104360 arb_losses 40285
vector_and_tensor_busy_cycles 29674
max_clusters_busy 4
host_transactions 6404
mem_transactions 19129 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_p128_errors**
```
master0 accepted 0 stall_cycles 0 arb_losses 0
master1 accepted 79 stall_cycles 45 arb_losses 14
master2 accepted 34 stall_cycles 25 arb_losses 7
master3 accepted 1006 stall_cycles 2723 arb_losses 901
master4 accepted 923 stall_cycles 2609 arb_losses 873
vector_and_tensor_busy_cycles 388
max_clusters_busy 4
host_transactions 0
mem_transactions 2042 mem_errors 7
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_phys_mixed**
```
master0 accepted 9327 stall_cycles 108081 arb_losses 51464
master1 accepted 656 stall_cycles 24572 arb_losses 19979
master2 accepted 610 stall_cycles 23937 arb_losses 19606
master3 accepted 503 stall_cycles 20818 arb_losses 17313
master4 accepted 558 stall_cycles 22677 arb_losses 18723
master5 accepted 7336 stall_cycles 174936 arb_losses 75940
master6 accepted 8871 stall_cycles 194690 arb_losses 76923
vector_and_tensor_busy_cycles 34745
max_clusters_busy 6
host_transactions 9327
mem_transactions 27861 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_phys_reset**
```
master0 accepted 5744 stall_cycles 58722 arb_losses 25442
master1 accepted 276 stall_cycles 10472 arb_losses 8512
master2 accepted 303 stall_cycles 10970 arb_losses 8884
master3 accepted 234 stall_cycles 9330 arb_losses 7750
master4 accepted 282 stall_cycles 8027 arb_losses 6469
master5 accepted 3923 stall_cycles 92110 arb_losses 38717
master6 accepted 5376 stall_cycles 111048 arb_losses 39922
vector_and_tensor_busy_cycles 15431
max_clusters_busy 6
host_transactions 5742
mem_transactions 16136 mem_errors 0
cover iso_req_captured 1 iso_rsp_captured 0 iso_error_responses 1 iso_responses_sunk 4
```
**s3_max_mixed**
```
master0 accepted 12896 stall_cycles 256974 arb_losses 197235
master1 accepted 1396 stall_cycles 93149 arb_losses 86250
master2 accepted 1469 stall_cycles 96580 arb_losses 89292
master3 accepted 1336 stall_cycles 89840 arb_losses 83123
master4 accepted 1262 stall_cycles 85308 arb_losses 79142
master5 accepted 1462 stall_cycles 96344 arb_losses 89267
master6 accepted 1702 stall_cycles 105555 arb_losses 97112
master7 accepted 1943 stall_cycles 112336 arb_losses 102734
master8 accepted 1796 stall_cycles 108586 arb_losses 99748
master9 accepted 10368 stall_cycles 326345 arb_losses 230811
master10 accepted 9054 stall_cycles 307672 arb_losses 223864
master11 accepted 7004 stall_cycles 262912 arb_losses 198477
master12 accepted 12782 stall_cycles 349165 arb_losses 233836
vector_and_tensor_busy_cycles 131092
max_clusters_busy 12
host_transactions 12896
mem_transactions 64470 mem_errors 0
cover iso_req_captured 0 iso_rsp_captured 0 iso_error_responses 0 iso_responses_sunk 0
```
**s3_max_reset**
```
master0 accepted 2 stall_cycles 0 arb_losses 0
master1 accepted 594 stall_cycles 9640 arb_losses 9047
master2 accepted 924 stall_cycles 13104 arb_losses 12194
master3 accepted 576 stall_cycles 9804 arb_losses 9186
master4 accepted 573 stall_cycles 9712 arb_losses 9139
master5 accepted 912 stall_cycles 13172 arb_losses 12261
master6 accepted 735 stall_cycles 11740 arb_losses 11005
master7 accepted 1053 stall_cycles 13818 arb_losses 12777
master8 accepted 679 stall_cycles 9032 arb_losses 8449
master9 accepted 3925 stall_cycles 34071 arb_losses 26642
master10 accepted 3937 stall_cycles 34696 arb_losses 27111
master11 accepted 3927 stall_cycles 35104 arb_losses 27398
master12 accepted 5348 stall_cycles 35330 arb_losses 26488
vector_and_tensor_busy_cycles 20585
max_clusters_busy 12
host_transactions 0
mem_transactions 23183 mem_errors 0
cover iso_req_captured 2 iso_rsp_captured 0 iso_error_responses 1 iso_responses_sunk 2
```
