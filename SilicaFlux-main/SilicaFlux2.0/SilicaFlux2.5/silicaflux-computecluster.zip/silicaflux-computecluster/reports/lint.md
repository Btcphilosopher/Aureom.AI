# Lint and elaboration sweep

**24 / 24 checks pass.**  Legal configurations: Verilator 5.020 `--lint-only -Wall` with **zero warnings in the new RTL** (`rtl/`), Icarus 12 elaboration + time-0 run, Yosys 0.33 `hierarchy -check -chparam; proc; check -assert`.  Illegal configurations: all three tools must refuse, and Verilator's refusal must be an elaboration `$fatal` of the design's own parameter checks (USERFATAL).

| kind | name | parameters | Verilator | new-RTL warnings | 3rd-party warnings (unmodified RTL) | Icarus | Yosys | result |
|---|---|---|---|---|---|---|---|---|
| legal | min | (defaults) | ok | 0 | 72 | ok | ok | PASS |
| legal | v1_only | NUM_VECTOR_CLUSTERS=1, NUM_TENSOR_CLUSTERS=0 | ok | 0 | 72 | ok | ok | PASS |
| legal | t1_only | NUM_VECTOR_CLUSTERS=0, NUM_TENSOR_CLUSTERS=1 | ok | 0 | 72 | ok | ok | PASS |
| legal | hpc | NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2 | ok | 0 | 72 | ok | ok | PASS |
| legal | hpc_piped | NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2, MEM_PIPE=1, LM_PIPE=1, EXT_PIPE=1, CMD_PIPE=1 | ok | 0 | 70 | ok | ok | PASS |
| legal | w64 | NUM_VECTOR_CLUSTERS=2, NUM_TENSOR_CLUSTERS=1, TRANSACTION_WIDTH=64 | ok | 0 | 72 | ok | ok | PASS |
| legal | w128_nolm | NUM_VECTOR_CLUSTERS=2, NUM_TENSOR_CLUSTERS=2, TRANSACTION_WIDTH=128, LOCAL_MEM_PORT=0, VEC_NUM_LANES=8, VEC_SCRATCHPAD_BYTES=16384, TSU_ARRAY_ROWS=8, TSU_ARRAY_COLS=8, TSU_NUM_MEMORY_BANKS=8, TSU_OPERAND_BUFFER_BYTES=4096, TSU_QUANT=1, TSU_DBUF=1 | ok | 0 | 72 | ok | ok | PASS |
| legal | legacy | CMD_IF=0 | ok | 0 | 72 | ok | ok | PASS |
| legal | lanes16 | NUM_VECTOR_CLUSTERS=1, NUM_TENSOR_CLUSTERS=0, VEC_NUM_LANES=16, TRANSACTION_WIDTH=128 | ok | 0 | 72 | ok | ok | PASS |
| legal | max_slots | NUM_VECTOR_CLUSTERS=8, NUM_TENSOR_CLUSTERS=4, RB_AW=17, VEC_NUM_LANES=1, VEC_SCRATCHPAD_BYTES=4096, TSU_ARRAY_ROWS=2, TSU_ARRAY_COLS=2, TSU_NUM_MEMORY_BANKS=2, TSU_OPERAND_BUFFER_BYTES=512 | ok | 0 | 72 | ok | ok | PASS |
| legal | phys_hpc | NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2, VEC_NUM_LANES=1, VEC_SCRATCHPAD_BYTES=1024, VEC_NUM_BANKS=2, VEC_CMD_QUEUE_DEPTH=2, VEC_CPL_QUEUE_DEPTH=2, VEC_PERF=0, TSU_ARRAY_ROWS=2, TSU_ARRAY_COLS=2, TSU_OPERAND_BUFFER_BYTES=512, TSU_NUM_MEMORY_BANKS=2, TSU_CMD_QUEUE_DEPTH=2, TSU_PERF=0, SHELL_PERF=0, MEM_PIPE=1, LM_PIPE=1, EXT_PIPE=1, CMD_PIPE=1 | ok | 0 | 70 | ok | ok | PASS |
| legal | noclkreq_noperf | ENABLE_CLK_REQ=0, SHELL_PERF=0 | ok | 0 | 72 | ok | ok | PASS |
| illegal | no_cluster | NUM_VECTOR_CLUSTERS=0, NUM_TENSOR_CLUSTERS=0 | refused | 0 | 67 | refused | refused | PASS |
| illegal | too_many_vec | NUM_VECTOR_CLUSTERS=9 | refused | 0 | 67 | refused | refused | PASS |
| illegal | too_many_tsu | NUM_TENSOR_CLUSTERS=5 | refused | 0 | 67 | refused | refused | PASS |
| illegal | bad_width | TRANSACTION_WIDTH=48 | refused | 0 | 68 | refused | refused | PASS |
| illegal | pages_overflow | NUM_VECTOR_CLUSTERS=8, NUM_TENSOR_CLUSTERS=4 | refused | 0 | 67 | refused | refused | PASS |
| illegal | shell_page_overlap | SHELL_PAGE=8 | refused | 0 | 67 | refused | refused | PASS |
| illegal | mem_not_pow2 | MEM_BYTES=3145728 | refused | 0 | 67 | refused | refused | PASS |
| illegal | mem_misaligned | MEM_BASE=268959744 | refused | 0 | 67 | refused | refused | PASS |
| illegal | spm_overlaps_mem | VEC_SPM_BASE=268435456 | refused | 0 | 67 | refused | refused | PASS |
| illegal | bad_flag | MEM_PIPE=2 | refused | 0 | 67 | refused | refused | PASS |
| illegal | bad_lanes | VEC_NUM_LANES=3 | refused | 0 | 68 | refused | refused | PASS |
| illegal | bad_tsu_shape | TSU_ARRAY_ROWS=3, TSU_ARRAY_COLS=3 | refused | 0 | 68 | refused | refused | PASS |
