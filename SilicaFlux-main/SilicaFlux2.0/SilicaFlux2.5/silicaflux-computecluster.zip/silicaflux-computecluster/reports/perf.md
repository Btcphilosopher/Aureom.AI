# Measured latency of the control path and of the pipeline boundaries

Minimum configuration without and with every register slice (MEM_PIPE = LM_PIPE = EXT_PIPE = CMD_PIPE = 1); each command alone, no back-pressure, shared-memory latency 1 and 8 cycles (`scripts/run_perf.py`). End-to-end = command accepted at the shell boundary -> completion delivered at the shell boundary. `unit` = the unit's own CYCLES field (dispatch -> retirement).

## shared-memory latency 1 cycle(s)

| command | end-to-end, no slices | end-to-end, all slices | added | ratio | unit, no slices | unit, all slices |
|---|---|---|---|---|---|---|
| vec NOP | 23 | 24 | +1 | x1.043 | 1 | 1 |
| vec KERNEL FADD vl=64 | 1062 | 1831 | +769 | x1.724 | 1040 | 1808 |
| vec KERNEL FMUL vl=512 | 8118 | 14263 | +6145 | x1.757 | 8096 | 14240 |
| vec DMA 1 KiB in | 1308 | 2333 | +1025 | x1.784 | 1286 | 2310 |
| tsu GEMM 4x4x4 | 197 | 260 | +63 | x1.32 | 172 | 234 |
| tsu GEMM 16x16x64 | 9107 | 15860 | +6753 | x1.742 | 9082 | 15834 |
| tsu GEMM 32x32x128 | 68403 | 121268 | +52865 | x1.773 | 68378 | 121242 |

## shared-memory latency 8 cycle(s)

| command | end-to-end, no slices | end-to-end, all slices | added | ratio | unit, no slices | unit, all slices |
|---|---|---|---|---|---|---|
| vec NOP | 23 | 24 | +1 | x1.043 | 1 | 1 |
| vec KERNEL FADD vl=64 | 2406 | 3175 | +769 | x1.32 | 2384 | 3152 |
| vec KERNEL FMUL vl=512 | 18870 | 25015 | +6145 | x1.326 | 18848 | 24992 |
| vec DMA 1 KiB in | 3100 | 4125 | +1025 | x1.331 | 3078 | 4102 |
| tsu GEMM 4x4x4 | 393 | 456 | +63 | x1.16 | 368 | 430 |
| tsu GEMM 16x16x64 | 32403 | 39156 | +6753 | x1.208 | 32378 | 39130 |
| tsu GEMM 32x32x128 | 251187 | 304052 | +52865 | x1.21 | 251162 | 304026 |

