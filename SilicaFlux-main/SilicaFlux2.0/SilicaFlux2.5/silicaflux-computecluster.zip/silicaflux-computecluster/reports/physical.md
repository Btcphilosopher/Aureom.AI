# Physical-integration experiment (OpenROAD, exploratory)

**Reduced configuration (`configs/phys_hpc.json`), memories as flip-flops, sky130hd typical corner, pre-CTS (ideal clock), no routing.** Not a floorplan sign-off and not an area result. Every coordinate and count below was read back from the OpenROAD database or log; tool: OpenROAD 2.0-12331-g6011bbe77 (FloorplanLab's pinned build), ORFS ab2aaf0f sky130hd platform.

Configuration: NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2, VEC_NUM_LANES=1, VEC_SCRATCHPAD_BYTES=1024, VEC_NUM_BANKS=2, VEC_CMD_QUEUE_DEPTH=2, VEC_CPL_QUEUE_DEPTH=2, VEC_PERF=0, TSU_ARRAY_ROWS=2, TSU_ARRAY_COLS=2, TSU_OPERAND_BUFFER_BYTES=512, TSU_NUM_MEMORY_BANKS=2, TSU_CMD_QUEUE_DEPTH=2, TSU_PERF=0, SHELL_PERF=0, MEM_PIPE=1, LM_PIPE=1, EXT_PIPE=1, CMD_PIPE=1

Mapped standard-cell area (Yosys 0.33 `stat -liberty`): **5,494,881 um^2**.

## 1. Mapped area per region

| instance | cells | cell area um^2 |
|---|---|---|
| `(top-level glue)` | 270 | 1,680.4 |
| `u_cmd_route` | 2,063 | 30,291.6 |
| `u_cpl_arb` | 4,729 | 38,205.4 |
| `u_ext_slice` | 526 | 7,692.4 |
| `u_noc` | 4,611 | 29,331.9 |
| `u_regs` | 2,565 | 23,757.8 |
| `u_tensor_0` | 105,367 | 1,122,251.3 |
| `u_tensor_1` | 105,367 | 1,122,251.3 |
| `u_vector_0` | 74,328 | 779,865.5 |
| `u_vector_1` | 74,150 | 779,707.8 |
| `u_vector_2` | 74,313 | 779,761.6 |
| `u_vector_3` | 74,512 | 780,084.4 |

Proposed floorplan (generated): die [0, 0, 3535.08, 3537.92] um, core [20.0, 20.0, 3515.08, 3517.92] um, region utilization target 0.45.

| region | prefixes | box um | cell area um^2 |
|---|---|---|---|
| SFX_VEC0 | `u_vector_0/` | [20.0, 20.0, 1011.76, 1766.24] | 779,865.5 |
| SFX_VEC2 | `u_vector_2/` | [20.0, 1766.24, 1011.76, 3515.2] | 779,761.6 |
| SFX_VEC1 | `u_vector_1/` | [2522.4, 20.0, 3514.62, 1766.24] | 779,707.8 |
| SFX_VEC3 | `u_vector_3/` | [2522.4, 1766.24, 3514.62, 3515.2] | 780,084.4 |
| SFX_TSU0 | `u_tensor_0/` | [1011.76, 1864.16, 2522.4, 3515.2] | 1,122,251.3 |
| SFX_CTRL | `u_regs/ u_cmd_route/ u_cpl_arb/` | [1011.76, 1671.04, 1767.08, 1864.16] | 92,254.8 |
| SFX_NOC | `u_noc/ u_ext_slice/` | [1767.08, 1671.04, 2522.4, 1864.16] | 37,024.3 |
| SFX_TSU1 | `u_tensor_1/` | [1011.76, 20.0, 2522.4, 1671.04] | 1,122,251.3 |

## 2. The constraints load on the real instance names

`physical/apply_constraints.tcl` on the mapped netlist (no placement): ['SFX_CONSTRAINTS regions 8 groups 18'], applied in ['3407'] ms, regions without members: none; DEF REGIONS / GROUPS written (`reports/physical/phys_hpc_regions_groups.def`).

| region | members |  | group | members |
|---|---|---|---|---|
| SFX_VEC0 | 74328 |  | TSU0_ARRAY_BUFFERS | 43152 |
| SFX_VEC2 | 74313 |  | TSU0_DMA_NOCIF | 41770 |
| SFX_VEC1 | 74150 |  | TSU0_CTRL | 19536 |
| SFX_VEC3 | 74512 |  | TSU1_ARRAY_BUFFERS | 43152 |
| SFX_TSU0 | 105367 |  | TSU1_DMA_NOCIF | 41770 |
| SFX_CTRL | 9357 |  | TSU1_CTRL | 19536 |
| SFX_NOC | 5137 |  | VEC0_LANES_SPM | 55134 |
| SFX_TSU1 | 105367 |  | VEC0_DMA_NOCIF | 5632 |
|  |  |  | VEC0_CTRL | 13460 |
|  |  |  | VEC1_LANES_SPM | 55134 |
|  |  |  | VEC1_DMA_NOCIF | 5646 |
|  |  |  | VEC1_CTRL | 13268 |
|  |  |  | VEC2_LANES_SPM | 55136 |
|  |  |  | VEC2_DMA_NOCIF | 5636 |
|  |  |  | VEC2_CTRL | 13439 |
|  |  |  | VEC3_LANES_SPM | 55134 |
|  |  |  | VEC3_DMA_NOCIF | 5637 |
|  |  |  | VEC3_CTRL | 13639 |

## 3. Does this OpenROAD build honour placement regions? (controlled test)

Two copies of the mapped completion arbiter (2 x 4 729 cells, `reports/physical/region_support_test/`), one region per copy in OPPOSITE corners of a 600 x 600 um die; containment measured after global and after detailed placement.

| mechanism | inside after global placement (block A / block B) | inside after detailed placement (A / B) | avg / max displacement um | check_placement |
|---|---|---|---|---|
| odb dbRegion (INCLUSIVE) + addInst | 0/0 of 4729/4729 | 0/0 | 2.2 / 9.5 | ok=1 |
| create_voltage_domain + group addInst | 0/0 of 4729/4729 | 4729/4729 | 568.4 / 1003.4 | FAILED DPL-0003 DPL-0033 |
| no constraint (control) | 0/0 of 4729/4729 | 0/0 | 2.2 / 9.5 | ok=1 |
| odb dbRegion + region-less PHYSICAL_CLUSTER dbGroup | 0/0 of 4729/4729 | — | — / — | detailed placement unfinished after 600 s (bounded run) |
| members seeded at the region centre, global_placement -skip_initial_place | 0/0 of 4729/4729 | 0/0 | 2.2 / 9.5 | ok=1 |

## 4. Full reduced design placed WITHOUT constraints (control)

check_placement passed; global placement overflow 0.099189; legalized HPWL 17308221.2 um; average detailed-placement displacement 2.6 um. Containment of each cluster in its *proposed* box, and the bounding box its instances actually occupy:

| region | members | inside proposed box | inside % | other instances in the box | members' bbox um^2 | region um^2 | centroid um |
|---|---|---|---|---|---|---|---|
| SFX_VEC0 | 74,328 | 604 | 0.81 | 53,522 | 8,718,987.2 | 1,731,851.0 | [1506.8, 1886.2] |
| SFX_VEC2 | 74,313 | 12,517 | 16.84 | 37,867 | 5,997,877.4 | 1,734,548.6 | [1190.2, 1287.4] |
| SFX_VEC1 | 74,150 | 22,346 | 30.14 | 40,886 | 5,972,131.5 | 1,732,654.3 | [1971.9, 1414.2] |
| SFX_VEC3 | 74,512 | 0 | 0.0 | 67,587 | 5,942,539.4 | 1,735,353.1 | [1638.9, 922.6] |
| SFX_TSU0 | 105,367 | 24,534 | 23.28 | 103,480 | 11,633,227.2 | 2,494,127.1 | [2455.6, 2203.8] |
| SFX_CTRL | 9,357 | 2 | 0.02 | 8,431 | 6,210,189.8 | 145,867.4 | [1052.6, 2301.3] |
| SFX_NOC | 5,137 | 0 | 0.0 | 10,266 | 8,642,468.8 | 145,867.4 | [1611.2, 1321.4] |
| SFX_TSU1 | 105,367 | 4,576 | 4.34 | 134,140 | 11,998,707.7 | 2,494,127.1 | [2056.8, 2379.7] |

Picture: `reports/physical/phys_hpc_placement_no_regions.svg` (1 in 25 placed instances, coloured by cluster; dashed boxes = proposal).

Full design WITH the regions and groups applied: stopped in detailed_placement after 44 CPU-minutes (Opendp::place -> mapMove -> diamondSearch, gdb stack sample); regions + region-less PHYSICAL_CLUSTER groups applied before placement; the small test odb_region_groups reproduces the same exhaustive detailed placement.

## 5. Pre-CTS timing after buffering: are the NoC-facing slices required?

`physical/post_sta.py` on each placed design: dont_use sky130 low-power / delay cells, `repair_design`, re-legalization, placement parasitics, ideal clock, 20 ns reference period (a reference, not a target). Worst path through each region-boundary interface (`report_checks -through` the shell's nets):

| interface | all_slices: slack ns (arrival ns), start -> end region | no_slices: slack ns (arrival ns), start -> end region |
|---|---|---|
| cluster_mem_req | 11.041 (8.831), SFX_VEC0 -> SFX_TSU1 | -3.267 (23.173), SFX_VEC3 -> SFX_TSU0 |
| cluster_mem_rsp | 11.041 (8.831), SFX_VEC0 -> SFX_TSU1 | -3.267 (23.173), SFX_VEC3 -> SFX_TSU0 |
| command | 13.508 (6.364), SFX_VEC2 -> SFX_CTRL | 14.953 (4.916), TOP -> SFX_TSU0 |
| completion | 9.013 (10.859), SFX_VEC3 -> SFX_CTRL | 8.784 (11.09), SFX_VEC0 -> SFX_CTRL |
| csr | 6.937 (12.909), TOP -> SFX_TSU0 | 7.45 (12.55), TOP -> TOP |
| local_mem_req | 11.853 (8.02), SFX_VEC0 -> SFX_VEC3 | -3.267 (23.173), SFX_VEC3 -> SFX_TSU0 |
| local_mem_rsp | 11.378 (8.494), SFX_NOC -> SFX_TSU1 | -0.778 (20.684), TOP -> SFX_TSU0 |

**all_slices**: WNS -3.323 ns, TNS -276.614 ns, check_placement after buffering passed; Design area 7052254 u^2 58% utilization.; repair_design: Using max wire length 2103um.; Found 41442 slew violations.; Found 2762 capacitance violations.; Found 876 long wires.; Inserted 14060 buffers in 42068 nets.; Resized 161389 instances..

Worst data paths: -3.323 ns SFX_TSU0->SFX_TSU0 (`u_tensor_0/g_cl.u_tsu/u_dp/u_tob/u_agu/_10392_` → `u_tensor_0/g_cl.u_tsu/u_dp/u_tob/u_agu/_10711_`); -3.319 ns SFX_TSU0->SFX_TSU0 (`u_tensor_0/g_cl.u_tsu/u_dp/u_tob/u_agu/_10392_` → `u_tensor_0/g_cl.u_tsu/u_dp/u_tob/u_agu/_10710_`); -3.259 ns SFX_TSU1->SFX_TSU1 (`u_tensor_1/g_cl.u_tsu/u_dp/u_tob/u_agu/_10393_` → `u_tensor_1/g_cl.u_tsu/u_dp/u_tob/u_agu/_10710_`); -3.251 ns SFX_TSU1->SFX_TSU1 (`u_tensor_1/g_cl.u_tsu/u_dp/u_tob/u_agu/_10393_` → `u_tensor_1/g_cl.u_tsu/u_dp/u_tob/u_agu/_10711_`)

**no_slices**: WNS -5.083 ns, TNS -1208.175 ns, check_placement after buffering passed; Design area 6946082 u^2 58% utilization.; repair_design: Using max wire length 2103um.; Found 41660 slew violations.; Found 2637 capacitance violations.; Found 877 long wires.; Inserted 13358 buffers in 42277 nets.; Resized 162125 instances..

Worst data paths: -5.083 ns SFX_TSU1->SFX_TSU1 (`u_tensor_1/g_cl.u_tsu/u_dp/u_dma/_9011_` → `u_tensor_1/g_cl.u_tsu/u_dp/u_dma/u_ql/_2469_`); -5.082 ns SFX_TSU1->SFX_TSU1 (`u_tensor_1/g_cl.u_tsu/u_dp/u_dma/_9011_` → `u_tensor_1/g_cl.u_tsu/u_dp/u_dma/u_qs/_2717_`); -5.077 ns SFX_TSU1->SFX_TSU1 (`u_tensor_1/g_cl.u_tsu/u_dp/u_dma/_9011_` → `u_tensor_1/g_cl.u_tsu/u_dp/u_dma/u_qs/_3213_`); -5.075 ns SFX_TSU1->SFX_TSU1 (`u_tensor_1/g_cl.u_tsu/u_dp/u_dma/_9011_` → `u_tensor_1/g_cl.u_tsu/u_dp/u_dma/u_qs/_2469_`)

