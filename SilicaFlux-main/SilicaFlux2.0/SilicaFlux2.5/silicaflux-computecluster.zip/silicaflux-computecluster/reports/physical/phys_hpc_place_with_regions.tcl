
read_lef /opt/eda/orfs/flow/platforms/sky130hd/lef/sky130_fd_sc_hd.tlef
read_lef /opt/eda/orfs/flow/platforms/sky130hd/lef/sky130_fd_sc_hd_merged.lef
read_liberty /opt/eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog /tmp/claude-0/-home-user-Aureom-AI/a8ee2cbd-19e4-52af-bdf4-8a65337ebcc5/scratchpad/silicaflux-computecluster/build/phys/phys_hpc/netlist.v
link_design silicaflux_compute_cluster
initialize_floorplan -die_area {0 0 3535.08 3537.92} -core_area {20.0 20.0 3515.08 3517.92} -site unithd
source /opt/eda/orfs/flow/platforms/sky130hd/make_tracks.tcl
place_pins -hor_layers met3 -ver_layers met2 -random
set block [ord::get_db_block]
source /tmp/claude-0/-home-user-Aureom-AI/a8ee2cbd-19e4-52af-bdf4-8a65337ebcc5/scratchpad/silicaflux-computecluster/build/phys/phys_hpc/regions.tcl
source /tmp/claude-0/-home-user-Aureom-AI/a8ee2cbd-19e4-52af-bdf4-8a65337ebcc5/scratchpad/silicaflux-computecluster/build/phys/phys_hpc/groups.tcl
sfx_apply_regions $block
sfx_apply_groups $block
global_placement -density 0.6 -skip_io
detailed_placement
set ok [catch {check_placement -verbose} msg]
puts "SFX_CHECK_PLACEMENT ok=[expr {!$ok}] $msg"
# ------------------------------------------------------------- measurements from the placed database
set fp [open /tmp/claude-0/-home-user-Aureom-AI/a8ee2cbd-19e4-52af-bdf4-8a65337ebcc5/scratchpad/silicaflux-computecluster/build/phys/phys_hpc/with_regions/placement.txt w]
foreach inst [$block getInsts] {
  set bb [$inst getBBox]
  set r [$inst getRegion]
  set rn [expr {$r eq "NULL" ? "-" : [$r getName]}]
  puts $fp "[$inst getName] [$bb xMin] [$bb yMin] [$bb xMax] [$bb yMax] [[$inst getMaster] getName] $rn"
}
close $fp
write_def /tmp/claude-0/-home-user-Aureom-AI/a8ee2cbd-19e4-52af-bdf4-8a65337ebcc5/scratchpad/silicaflux-computecluster/build/phys/phys_hpc/with_regions/placed.def
report_design_area
# ------------------------------------------------------------- pre-CTS timing, placement-estimated parasitics
create_clock -name clk -period 20.0 [get_ports clk]
set_input_delay  0 -clock clk [delete_from_list [all_inputs] [get_ports clk]]
set_output_delay 0 -clock clk [all_outputs]
source /opt/eda/orfs/flow/platforms/sky130hd/setRC.tcl
estimate_parasitics -placement
puts "SFX_TIMING_BEGIN"
report_checks -path_delay max -group_count 8 -endpoint_count 1 -digits 3
report_worst_slack -max -digits 3
report_tns -digits 3
puts "SFX_TIMING_END"
