# Synthesis (Yosys 0.33, technology-independent, hierarchy preserved)

**Not silicon area.**  Generic Yosys cells (`$_AND_`, `$_MUX_`, `$_DFF_*` ...) after `abc -fast`; memories are left as inferred `$mem_v2` (reported in bits, never mapped to gates: on silicon they are SRAM macros from the SRAM Wrapper Library ASIC backend).  Raw logs (gzip), scripts and `stat` output: `reports/synth/<target>/`.

## Build targets

| target | top | parameters | result | Yosys s | generic cells | flip-flops | inferred memories | memory bits |
|---|---|---|---|---|---|---|---|---|
| `vector_cluster` | `silicaflux_vector_cluster` | (defaults) | OK | 58.1 | 156,963 | 11,393 | 34 | 530,484 |
| `tensor_cluster` | `silicaflux_tensor_cluster` | (defaults) | OK | 92.3 | 116,013 | 12,373 | 39 | 27,592 |
| `compute_min` | `silicaflux_compute_cluster` | (defaults) | OK | 182.6 | 284,706 | 25,193 | 73 | 558,076 |
| `compute_hpc` | `silicaflux_compute_cluster` | NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2 | OK | 294.0 | 885,953 | 72,842 | 214 | 2,177,120 |
| `compute_hpc_piped` | `silicaflux_compute_cluster` | NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2, MEM_PIPE=1, LM_PIPE=1, EXT_PIPE=1, CMD_PIPE=1 | OK | 292.5 | 890,773 | 75,908 | 214 | 2,177,120 |

## `vector_cluster` — one vector cluster, defaults: 4 FP32 lanes, 32-bit, 64 KiB SPM

Instance-name check: expected `g_cl.u_tile, g_cl.u_ctrl, g_cl.u_rst, g_cl.u_mem_slice, g_cl.g_lm.u_lm_slice` -> all present.

| region (instance) | cells | flip-flops | memory bits | memories | populated |
|---|---|---|---|---|---|
| `g_cl.g_lm.u_lm_slice` | 0 | 0 | 0 | 0 | yes |
| `g_cl.u_ctrl` | 2,188 | 461 | 0 | 0 | yes |
| `g_cl.u_mem_slice` | 0 | 0 | 0 | 0 | yes |
| `g_cl.u_rst` | 398 | 124 | 0 | 0 | yes |
| `g_cl.u_tile` | 154,309 | 10,793 | 530,484 | 34 | yes |
| `(top-level glue)` | 68 | 15 | 0 | 0 | yes |

Inferred memories:

| instance path | width | depth | bits | R/W ports | class |
|---|---|---|---|---|---|
| `g_cl.u_tile/g_core.u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` | 32 | 4096 | 131,072 | 1R/1W | SRAM-macro candidate |
| `g_cl.u_tile/g_core.u_spm/g_core.g_bank[1].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` | 32 | 4096 | 131,072 | 1R/1W | SRAM-macro candidate |
| `g_cl.u_tile/g_core.u_spm/g_core.g_bank[2].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` | 32 | 4096 | 131,072 | 1R/1W | SRAM-macro candidate |
| `g_cl.u_tile/g_core.u_spm/g_core.g_bank[3].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` | 32 | 4096 | 131,072 | 1R/1W | SRAM-macro candidate |
| `g_cl.u_tile/g_core.u_cmdq/mem` | 272 | 8 | 2,176 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_cplq/mem` | 172 | 8 | 1,376 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_array/u_trk/mem_q` | 47 | 8 | 376 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_dma/g_core.g_cmdq.u_cmdq/mem` | 97 | 2 | 194 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_lsu/g_grp[0].ent` | 96 | 2 | 192 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_lsu/g_grp[1].ent` | 96 | 2 | 192 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_lsu/g_grp[2].ent` | 96 | 2 | 192 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_lsu/g_grp[3].ent` | 96 | 2 | 192 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_dma/g_core.u_cplq/mem` | 70 | 2 | 140 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_array/u_issue/u_cq/mem_q` | 64 | 2 | 128 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_sched/rob_ts` | 32 | 4 | 128 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_array/u_cplq/mem_q` | 61 | 2 | 122 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_sched/rob_seq` | 16 | 4 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[1].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[2].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[3].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[4].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[5].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` | 22 | 2 | 44 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[1].u_rsp/g_fifo.f_id` | 22 | 2 | 44 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[2].u_rsp/g_fifo.f_id` | 22 | 2 | 44 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[3].u_rsp/g_fifo.f_id` | 22 | 2 | 44 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[4].u_rsp/g_fifo.f_id` | 22 | 2 | 44 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_spm/g_core.g_rsp[5].u_rsp/g_fifo.f_id` | 22 | 2 | 44 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_sched/rob_tag` | 8 | 4 | 32 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_sched/rob_st` | 4 | 4 | 16 | 4R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_sched/rob_typ` | 4 | 4 | 16 | 1R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_sched/rob_kind` | 2 | 4 | 8 | 4R/1W | register file / flip-flops |
| `g_cl.u_tile/g_core.u_dma/g_core.g_port[0].u_route/info_q` | 4 | 1 | 4 | 1R/1W | register file / flip-flops |

Highest leaf fanout (leaf cell input pins reached through the hierarchy):

| net | leaf loads |
|---|---|
| `clk` | 11,431 |
| `g_cl.local_rst_n` | 1,543 |
| `g_cl.u_addr[8]` | 770 |
| `g_cl.u_addr[2]` | 388 |
| `g_cl.u_addr[3]` | 196 |
| `g_cl.u_addr[4]` | 105 |
| `g_cl.u_addr[5]` | 70 |
| `g_cl.iso` | 43 |
| `rst_n` | 38 |
| `g_cl.u_addr[7]` | 37 |
| `g_cl.u_addr[6]` | 35 |
| `g_cl.u_sel` | 34 |

Widest nets of the top module (>= 64 bits):

| net | width | max loads per bit |
|---|---|---|
| `cmd_data` | 256 | 1 |
| `cpl_data` | 192 | 0 |

Most frequent cell types: `$_ANDNOT_` 37,595, `$_MUX_` 28,466, `$_OR_` 23,803, `$_XOR_` 16,896, `$_NAND_` 7,755, `$_NOR_` 7,360, `$_AND_` 7,163, `$_DFFE_PP_` 7,020, `$_XNOR_` 6,492, `$_NOT_` 6,197

## `tensor_cluster` — one tensor cluster, defaults: 4x4 INT8, 2 KiB operand buffers

Instance-name check: expected `g_cl.u_tsu, g_cl.u_ctrl, g_cl.u_rst, g_cl.u_mem_slice, g_cl.u_upsize` -> all present.

| region (instance) | cells | flip-flops | memory bits | memories | populated |
|---|---|---|---|---|---|
| `g_cl.u_ctrl` | 2,439 | 589 | 0 | 0 | yes |
| `g_cl.u_mem_slice` | 0 | 0 | 0 | 0 | yes |
| `g_cl.u_rst` | 247 | 86 | 0 | 0 | yes |
| `g_cl.u_tsu` | 113,226 | 11,683 | 27,592 | 39 | yes |
| `g_cl.u_upsize` | 0 | 0 | 0 | 0 | yes |
| `(top-level glue)` | 101 | 15 | 0 | 0 | yes |

Inferred memories:

| instance path | width | depth | bits | R/W ports | class |
|---|---|---|---|---|---|
| `g_cl.u_tsu/u_dp/u_tob/g_bbank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` | 32 | 128 | 4,096 | 1R/1W | SRAM-macro candidate |
| `g_cl.u_tsu/u_dp/u_tob/g_bbank[1].u_bank/g_ram.u_ram/g_generic.u_mem/mem` | 32 | 128 | 4,096 | 1R/1W | SRAM-macro candidate |
| `g_cl.u_tsu/u_dp/u_tob/g_abank[0].u_bank/g_ram.u_ram/g_generic.u_mem/mem` | 32 | 64 | 2,048 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/g_abank[1].u_bank/g_ram.u_ram/g_generic.u_mem/mem` | 32 | 64 | 2,048 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/g_abank[2].u_bank/g_ram.u_ram/g_generic.u_mem/mem` | 32 | 64 | 2,048 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/g_abank[3].u_bank/g_ram.u_ram/g_generic.u_mem/mem` | 32 | 64 | 2,048 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_cq/mem` | 384 | 4 | 1,536 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_acc/u_store/mem` | 132 | 8 | 1,056 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_spm/g_core.g_bank[0].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` | 32 | 32 | 1,024 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_spm/g_core.g_bank[1].u_bank/genblk3.g_ram.u_ram/g_generic.u_mem/mem` | 32 | 32 | 1,024 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_ql/mem` | 248 | 4 | 992 | 6R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_qs/mem` | 248 | 4 | 992 | 6R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_cplq/mem` | 192 | 4 | 768 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_acc/u_acc/u_hfifo/mem` | 192 | 4 | 768 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_acc/u_acc/u_ofifo/mem` | 160 | 4 | 640 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_cq/mem` | 81 | 4 | 324 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_ld/u_rl/mem` | 8 | 32 | 256 | 4R/4W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_st/u_rl/mem` | 8 | 32 | 256 | 4R/4W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_obp/u_of/mem` | 41 | 4 | 164 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_opp/u_of/mem` | 41 | 4 | 164 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_wport/u_of/mem` | 41 | 4 | 164 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_sfb/u_of/mem` | 33 | 4 | 132 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/u_bstage/mem` | 32 | 4 | 128 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_g0/u_pend/mem` | 13 | 8 | 104 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_g1/u_pend/mem` | 13 | 8 | 104 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/u_trsp/mem` | 36 | 2 | 72 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_spm/g_core.g_rsp[1].u_rsp/g_fifo.f_data` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/g_lane[0].u_stage/mem` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/g_lane[1].u_stage/mem` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/g_lane[2].u_stage/mem` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/g_lane[3].u_stage/mem` | 32 | 2 | 64 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_tob/u_dma/u_rsp_fifo/mem` | 12 | 4 | 48 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_spm/g_core.g_rsp[0].u_rsp/g_fifo.f_id` | 11 | 2 | 22 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_ob/u_spm/g_core.g_rsp[1].u_rsp/g_fifo.f_id` | 11 | 2 | 22 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_ld/u_rmeta/mem` | 5 | 4 | 20 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_st/u_rmeta/mem` | 5 | 4 | 20 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_ld/u_wmeta/mem` | 3 | 4 | 12 | 1R/1W | register file / flip-flops |
| `g_cl.u_tsu/u_dp/u_dma/u_st/u_wmeta/mem` | 3 | 4 | 12 | 1R/1W | register file / flip-flops |

Highest leaf fanout (leaf cell input pins reached through the hierarchy):

| net | leaf loads |
|---|---|
| `clk` | 12,429 |
| `g_cl.local_rst_n` | 3,145 |
| `g_cl.u_addr[8]` | 1,219 |
| `g_cl.u_addr[2]` | 708 |
| `g_cl.u_addr[3]` | 389 |
| `g_cl.u_addr[4]` | 229 |
| `g_cl.u_addr[5]` | 133 |
| `g_cl.u_addr[7]` | 69 |
| `g_cl.u_addr[6]` | 67 |
| `g_cl.iso` | 43 |
| `g_cl.u_sel` | 35 |
| `rst_n` | 33 |

Widest nets of the top module (>= 64 bits):

| net | width | max loads per bit |
|---|---|---|
| `g_cl.t_perf_ev` | 640 | 1 |
| `cmd_data` | 384 | 1 |
| `cpl_data` | 192 | 0 |

Most frequent cell types: `$_ANDNOT_` 32,562, `$_XOR_` 15,447, `$_OR_` 15,210, `$_MUX_` 9,975, `$_NOR_` 6,491, `$_XNOR_` 6,226, `$_NAND_` 5,838, `$_DFFE_PN0P_` 5,462, `$_ORNOT_` 4,198, `$_AND_` 3,912

## `compute_min` — compute subsystem, minimum configuration: 1 vector + 1 tensor

Instance-name check: expected `u_vector_0, u_vector_1, u_vector_2, u_vector_3, u_vector_4, u_vector_5, u_vector_6, u_vector_7, u_tensor_0, u_tensor_1, u_tensor_2, u_tensor_3, u_noc, u_cmd_route, u_cpl_arb, u_regs, u_ext_slice` -> all present.

| region (instance) | cells | flip-flops | memory bits | memories | populated |
|---|---|---|---|---|---|
| `u_cmd_route` | 88 | 38 | 0 | 0 | yes |
| `u_cpl_arb` | 3,423 | 405 | 0 | 0 | yes |
| `u_ext_slice` | 0 | 0 | 0 | 0 | yes |
| `u_noc` | 1,405 | 24 | 0 | 0 | yes |
| `u_regs` | 7,308 | 958 | 0 | 0 | yes |
| `u_tensor_0` | 115,407 | 12,373 | 27,592 | 39 | yes |
| `u_tensor_1` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_tensor_2` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_tensor_3` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_0` | 156,955 | 11,393 | 530,484 | 34 | yes |
| `u_vector_1` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_2` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_3` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_4` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_5` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_6` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_7` | 0 | 0 | 0 | 0 | no (empty slot) |
| `(top-level glue)` | 120 | 2 | 0 | 0 | yes |

Highest leaf fanout (leaf cell input pins reached through the hierarchy):

| net | leaf loads |
|---|---|
| `clk` | 25,287 |
| `rst_n` | 1,104 |
| `sl_lm_rsp_valid[0]` | 103 |
| `xs_rsp_valid[0]` | 39 |
| `sl_csr_sel[8]` | 37 |
| `sl_csr_sel[0]` | 37 |
| `shell_sel` | 34 |
| `bit1054` | 34 |
| `rb_addr[7]` | 15 |
| `rb_addr[5]` | 14 |
| `rb_addr[4]` | 13 |
| `rb_we` | 11 |

Widest nets of the top module (>= 64 bits):

| net | width | max loads per bit |
|---|---|---|
| `sl_cpl_data` | 2304 | 1 |
| `cmd_data` | 384 | 1 |
| `sl_cmd_data` | 384 | 2 |
| `sl_csr_rdata` | 384 | 1 |
| `sm_req_addr` | 384 | 4 |
| `sm_req_wdata` | 384 | 2 |
| `sl_lm_rsp_rdata` | 256 | 3 |
| `cpl_data` | 192 | 0 |
| `cl_perf_ev` | 96 | 3 |
| `xm_rsp_rdata` | 96 | 0 |
| `xs_req_addr` | 64 | 0 |
| `xs_req_wdata` | 64 | 0 |

Most frequent cell types: `$_ANDNOT_` 71,931, `$_MUX_` 41,574, `$_OR_` 40,978, `$_XOR_` 33,068, `$_NAND_` 14,134, `$_NOR_` 14,098, `$_XNOR_` 12,924, `$_AND_` 12,089, `$_NOT_` 10,461, `$_DFFE_PN0P_` 9,843

## `compute_hpc` — compute subsystem, HPC shape: 4 vector + 2 tensor

Instance-name check: expected `u_vector_0, u_vector_1, u_vector_2, u_vector_3, u_vector_4, u_vector_5, u_vector_6, u_vector_7, u_tensor_0, u_tensor_1, u_tensor_2, u_tensor_3, u_noc, u_cmd_route, u_cpl_arb, u_regs, u_ext_slice` -> all present.

| region (instance) | cells | flip-flops | memory bits | memories | populated |
|---|---|---|---|---|---|
| `u_cmd_route` | 89 | 38 | 0 | 0 | yes |
| `u_cpl_arb` | 3,423 | 405 | 0 | 0 | yes |
| `u_ext_slice` | 0 | 0 | 0 | 0 | yes |
| `u_noc` | 8,059 | 89 | 0 | 0 | yes |
| `u_regs` | 14,316 | 1,986 | 0 | 0 | yes |
| `u_tensor_0` | 115,813 | 12,373 | 27,592 | 39 | yes |
| `u_tensor_1` | 115,813 | 12,373 | 27,592 | 39 | yes |
| `u_tensor_2` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_tensor_3` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_0` | 156,996 | 11,393 | 530,484 | 34 | yes |
| `u_vector_1` | 157,059 | 11,393 | 530,484 | 34 | yes |
| `u_vector_2` | 157,056 | 11,393 | 530,484 | 34 | yes |
| `u_vector_3` | 157,048 | 11,393 | 530,484 | 34 | yes |
| `u_vector_4` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_5` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_6` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_7` | 0 | 0 | 0 | 0 | no (empty slot) |
| `(top-level glue)` | 281 | 6 | 0 | 0 | yes |

Highest leaf fanout (leaf cell input pins reached through the hierarchy):

| net | leaf loads |
|---|---|
| `clk` | 73,106 |
| `rst_n` | 2,348 |
| `sl_lm_rsp_valid[3]` | 239 |
| `sl_lm_rsp_valid[2]` | 239 |
| `sl_lm_rsp_valid[1]` | 239 |
| `sl_lm_rsp_valid[0]` | 239 |
| `xs_rsp_valid[0]` | 47 |
| `sl_csr_sel[9]` | 37 |
| `sl_csr_sel[8]` | 37 |
| `sl_csr_sel[3]` | 37 |
| `sl_csr_sel[2]` | 37 |
| `sl_csr_sel[1]` | 37 |

Widest nets of the top module (>= 64 bits):

| net | width | max loads per bit |
|---|---|---|
| `sl_cpl_data` | 2304 | 1 |
| `cmd_data` | 384 | 1 |
| `sl_cmd_data` | 384 | 6 |
| `sl_csr_rdata` | 384 | 1 |
| `sm_req_addr` | 384 | 7 |
| `sm_req_wdata` | 384 | 5 |
| `sl_lm_rsp_rdata` | 256 | 7 |
| `xm_rsp_rdata` | 224 | 0 |
| `cpl_data` | 192 | 0 |
| `xs_req_addr` | 160 | 0 |
| `xs_req_wdata` | 160 | 0 |
| `xs_rsp_rdata` | 160 | 7 |

Most frequent cell types: `$_ANDNOT_` 220,215, `$_MUX_` 139,067, `$_OR_` 131,141, `$_XOR_` 99,701, `$_NAND_` 44,394, `$_NOR_` 42,428, `$_AND_` 39,824, `$_XNOR_` 39,147, `$_NOT_` 33,229, `$_DFFE_PP_` 30,614

## `compute_hpc_piped` — compute subsystem, HPC shape with every NoC-facing register slice

Instance-name check: expected `u_vector_0, u_vector_1, u_vector_2, u_vector_3, u_vector_4, u_vector_5, u_vector_6, u_vector_7, u_tensor_0, u_tensor_1, u_tensor_2, u_tensor_3, u_noc, u_cmd_route, u_cpl_arb, u_regs, u_ext_slice` -> all present.

| region (instance) | cells | flip-flops | memory bits | memories | populated |
|---|---|---|---|---|---|
| `u_cmd_route` | 1,263 | 816 | 0 | 0 | yes |
| `u_cpl_arb` | 3,423 | 405 | 0 | 0 | yes |
| `u_ext_slice` | 326 | 208 | 0 | 0 | yes |
| `u_noc` | 8,059 | 89 | 0 | 0 | yes |
| `u_regs` | 14,319 | 1,986 | 0 | 0 | yes |
| `u_tensor_0` | 116,143 | 12,581 | 27,592 | 39 | yes |
| `u_tensor_1` | 116,143 | 12,581 | 27,592 | 39 | yes |
| `u_tensor_2` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_tensor_3` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_0` | 157,661 | 11,809 | 530,484 | 34 | yes |
| `u_vector_1` | 157,722 | 11,809 | 530,484 | 34 | yes |
| `u_vector_2` | 157,718 | 11,809 | 530,484 | 34 | yes |
| `u_vector_3` | 157,715 | 11,809 | 530,484 | 34 | yes |
| `u_vector_4` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_5` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_6` | 0 | 0 | 0 | 0 | no (empty slot) |
| `u_vector_7` | 0 | 0 | 0 | 0 | no (empty slot) |
| `(top-level glue)` | 281 | 6 | 0 | 0 | yes |

Highest leaf fanout (leaf cell input pins reached through the hierarchy):

| net | leaf loads |
|---|---|
| `clk` | 76,172 |
| `rst_n` | 2,394 |
| `sl_lm_rsp_valid[3]` | 239 |
| `sl_lm_rsp_valid[2]` | 239 |
| `sl_lm_rsp_valid[1]` | 239 |
| `sl_lm_rsp_valid[0]` | 239 |
| `xs_rsp_valid[0]` | 47 |
| `sl_csr_sel[9]` | 37 |
| `sl_csr_sel[8]` | 37 |
| `sl_csr_sel[3]` | 37 |
| `sl_csr_sel[2]` | 37 |
| `sl_csr_sel[1]` | 37 |

Widest nets of the top module (>= 64 bits):

| net | width | max loads per bit |
|---|---|---|
| `sl_cpl_data` | 2304 | 1 |
| `cmd_data` | 384 | 2 |
| `sl_cmd_data` | 384 | 6 |
| `sl_csr_rdata` | 384 | 1 |
| `sm_req_addr` | 384 | 7 |
| `sm_req_wdata` | 384 | 5 |
| `sl_lm_rsp_rdata` | 256 | 7 |
| `xm_rsp_rdata` | 224 | 2 |
| `cpl_data` | 192 | 0 |
| `xs_req_addr` | 160 | 2 |
| `xs_req_wdata` | 160 | 2 |
| `xs_rsp_rdata` | 160 | 7 |

Most frequent cell types: `$_ANDNOT_` 220,115, `$_MUX_` 140,590, `$_OR_` 131,340, `$_XOR_` 99,688, `$_NAND_` 44,438, `$_NOR_` 42,478, `$_AND_` 39,850, `$_XNOR_` 39,225, `$_DFFE_PP_` 33,530, `$_NOT_` 33,235
