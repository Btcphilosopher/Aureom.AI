"""Program generator and expectation model for tb/tb_compute_cluster.sv (SilicaFlux Project 32).

A CCProg owns a random 1 MiB shared-memory image, places operands in it, emits host operations (prog.txt) and
records what every cluster must return (expect.json):

  * per cluster ID, a list of EPOCHS (a cluster reset starts a new one); each epoch is the ordered list of the
    commands sent to that cluster, with the record fields the reference predicts:
      vector (HPC Module 08 tile): TAG, STATUS, TYPE, STEP, COUNT, SEQ  (record word 0 = CPL_INFO, word 1 = SEQ)
      tensor (TENSORCORE 08):      TID, OPCODE, ERR_CODE, STATUS, COUNT, TILES, SAT, SEQ (tsu_ref.rec_fields)
      shell (absent destination):  word 0 = {"SE", BAD_DEST}, word 1 = the command's word 0
  * per command, the bytes it writes when it completes OK and its footprint (don't-care when it was destroyed by a
    reset or failed during execution)
  * register-read expectations that need the record stream (LOST after a cluster reset)

Expected results come from independent references, never from the RTL:
  * GEMM: TENSORCORE 08 model/tsu_ref.py (exact INT32 with Python integers; INT8 through TENSORCORE 05 tq_ref)
  * FP32 FADD / FMUL: computed in binary64 and rounded once to binary32 (round to nearest even).  For + and x on
    binary32 operands this double rounding is innocuous (53 >= 2*24 + 2), so the expectation is exact; operands are
    normal numbers well inside the range (method of TENSORCORE 08 model/gen_system.py).
"""
from __future__ import annotations

import json
import random
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TP = ROOT / "third_party"
sys.path[:0] = [str(TP / "silicaflux-tensorcore08" / "model"), str(TP / "silicaflux-tensorcore05" / "model")]
import tsu_abi as A  # noqa: E402
from tsu_ref import Gemm, HwCfg, gemm_result, traffic, validate  # noqa: E402

MEM_BASE = 0x1000_0000
MEM_BYTES = 1 << 20
SPM_BASE = 0x2000_0000
SHELL = 0x7000
TSU_ID0 = 8

# vector tile (hpc_tile_defs.svh)
CT_NOP, CT_DMA, CT_VEC, CT_KERNEL = 0, 1, 2, 3
ST_OK, ST_BAD_TYPE, ST_ALIGN, ST_DMA_ERR = 0, 1, 6, 8
VOP = {"FADD": 0x01, "FMUL": 0x03}


@dataclass
class Cfg:
    nv: int = 1
    nt: int = 1
    w: int = 32
    mem_pipe: int = 0
    lm_pipe: int = 0
    ext_pipe: int = 0
    cmd_pipe: int = 0
    cmd_if: int = 1
    local_mem: int = 1
    vec_lanes: int = 4
    vec_spm: int = 65536
    vec_banks: int = 4
    vec_dma_buf: int = 0
    tsu_rows: int = 4
    tsu_cols: int = 4
    tsu_tile_k: int = 64
    tsu_opbuf: int = 2048
    tsu_banks: int = 4
    tsu_quant: int = 0
    tsu_dbuf: int = 0
    rst_hold: int = 8
    rb_aw: int = 16
    vec_cmdq: int = 8
    vec_perf: int = 1
    tsu_cmdq: int = 4
    tsu_perf: int = 1
    shell_perf: int = 1

    def gparams(self) -> list[str]:
        m = dict(NV=self.nv, NT=self.nt, W=self.w, MEM_PIPE=self.mem_pipe, LM_PIPE=self.lm_pipe,
                 EXT_PIPE=self.ext_pipe, CMD_PIPE=self.cmd_pipe, CMD_IF=self.cmd_if, LOCAL_MEM_PORT=self.local_mem,
                 VEC_LANES=self.vec_lanes, VEC_SPM_BYTES=self.vec_spm, VEC_BANKS=self.vec_banks,
                 VEC_DMA_BUF=self.vec_dma_buf, TSU_ROWS=self.tsu_rows, TSU_COLS=self.tsu_cols,
                 TSU_TILE_K=self.tsu_tile_k, TSU_OPBUF=self.tsu_opbuf, TSU_BANKS=self.tsu_banks,
                 TSU_QUANT=self.tsu_quant, TSU_DBUF=self.tsu_dbuf, RST_HOLD=self.rst_hold, RB_AW=self.rb_aw,
                 VEC_CMDQ=self.vec_cmdq, VEC_PERF=self.vec_perf, TSU_CMDQ=self.tsu_cmdq, TSU_PERF=self.tsu_perf,
                 SHELL_PERF=self.shell_perf)
        return [f"-G{k}={v}" for k, v in m.items()]

    def hw(self) -> HwCfg:
        return HwCfg(rows=self.tsu_rows, cols=self.tsu_cols, tile_k=self.tsu_tile_k, opbuf=self.tsu_opbuf,
                     banks=self.tsu_banks, quant=self.tsu_quant, dbuf=self.tsu_dbuf, mem_lo=MEM_BASE,
                     cmdq=self.tsu_cmdq, cplq=self.tsu_cmdq,
                     mem_hi=MEM_BASE + MEM_BYTES)

    def vec_ids(self) -> list[int]:
        return list(range(self.nv))

    def tsu_ids(self) -> list[int]:
        return [TSU_ID0 + j for j in range(self.nt)]

    def page(self, cid: int) -> int:
        return (8 + cid if cid < 8 else 8 + self.nv + cid - TSU_ID0) << 12

    def spm(self, cid: int) -> int:
        return SPM_BASE + cid * self.vec_spm


def f32(x: float) -> float:
    return struct.unpack("<f", struct.pack("<f", x))[0]


def f32_bytes(x: float) -> bytes:
    return struct.pack("<f", x)


class CCProg:
    def __init__(self, cfg: Cfg, seed: int):
        self.cfg = cfg
        self.hw = cfg.hw()
        self.rng = random.Random(seed)
        self.init = bytearray(self.rng.getrandbits(8) for _ in range(MEM_BYTES))
        self.top = MEM_BASE + 0x100
        self.ops: list[str] = []
        self.cmds: list[dict] = []                      # every command, in program order
        self.epochs: dict[int, list[list[int]]] = {}    # cluster ID -> epochs -> indices into self.cmds
        self.shell_recs: list[dict] = []                # expected shell-generated records (bad destination)
        self.dontcare: list[list[int]] = []
        self.lost_checks: list[dict] = []
        self.plus: dict = {}
        self.ntag: dict[int, int] = {}
        self.err_win: list[int] | None = None
        self.cover: list[str] = []                       # coverage items the run must hit (stats.txt "cover")

    # ------------------------------------------------------------------ memory
    def alloc(self, size: int, align: int = 4) -> int:
        a = self.top + self.rng.randrange(0, 61)
        a = (a + align - 1) // align * align
        self.top = a + size
        assert self.top <= MEM_BASE + MEM_BYTES - 64, "test does not fit in the shared memory"
        return a

    def fill(self, addr: int, data: bytes):
        o = addr - MEM_BASE
        self.init[o:o + len(data)] = data

    def word(self, addr: int) -> int:
        o = addr - MEM_BASE
        return int.from_bytes(self.init[o:o + 4], "little")

    def error_window(self, size: int = 4096) -> list[int]:
        """A region of the shared memory that answers every access with rsp_error (memory-model plusargs)."""
        if self.err_win is None:
            lo = self.alloc(size, 4096)
            self.err_win = [lo, lo + size]
            self.plus["err_lo"] = f"{lo:x}"
            self.plus["err_hi"] = f"{lo + size:x}"
        return self.err_win

    # ------------------------------------------------------------------ bookkeeping
    def _tag(self, cid: int) -> int:
        n = self.ntag.get(cid, 0)
        self.ntag[cid] = n + 1
        return (cid * 37 + n) & 0xFF

    def _send(self, cid: int, words: list[int], exp: dict, writes: dict | None = None, fp=None,
              executes_ok: bool = True):
        words = list(words) + [0] * (12 - len(words))
        self.ops.append(f"C {cid} " + " ".join(f"{w & 0xFFFFFFFF:08x}" for w in words))
        ep = self.epochs.setdefault(cid, [[]])
        exp["seq"] = len(ep[-1])
        self.cmds.append(dict(cid=cid, exp=exp, writes=sorted((writes or {}).items()), fp=fp or [],
                              ok=executes_ok))
        ep[-1].append(len(self.cmds) - 1)

    def op(self, s: str):
        self.ops.append(s)

    # ------------------------------------------------------------------ vector cluster commands
    def vec_kernel(self, cid: int, vl: int, op: str | None = None, a_err: bool = False, misalign: bool = False):
        op = op or self.rng.choice(["FADD", "FMUL"])
        al = max(16, self.cfg.w // 8)
        if a_err:
            lo, hi = self.error_window()
            a = lo + 16 * self.rng.randrange(0, (hi - lo - 4 * vl) // 16)
        else:
            a = self.alloc(4 * vl, al)
        b, d = self.alloc(4 * vl, al), self.alloc(4 * vl, al)
        av = [f32(self.rng.uniform(-1000, 1000) * 2.0 ** self.rng.randrange(-20, 20)) for _ in range(vl)]
        bv = [f32(self.rng.uniform(-1000, 1000) * 2.0 ** self.rng.randrange(-20, 20)) for _ in range(vl)]
        if not a_err:
            self.fill(a, b"".join(map(f32_bytes, av)))
        self.fill(b, b"".join(map(f32_bytes, bv)))
        out = b"".join(f32_bytes(x + y if op == "FADD" else x * y) for x, y in zip(av, bv))
        tag = self._tag(cid)
        dd = d + (2 if misalign else 0)
        w0 = CT_KERNEL | (VOP[op] << 4) | (tag << 16)
        words = [w0, vl, 0, a, b, 0, dd, self.cfg.spm(cid)]
        if misalign:
            self._send(cid, words, dict(kind="v", tag=tag, status=ST_ALIGN, type=CT_KERNEL, count=0, step=0))
        elif a_err:
            self._send(cid, words, dict(kind="v", tag=tag, status=ST_DMA_ERR, type=CT_KERNEL, step=1),
                       fp=[[d, d + 4 * vl]], executes_ok=False)
        else:
            self._send(cid, words, dict(kind="v", tag=tag, status=ST_OK, type=CT_KERNEL, count=vl, step=0),
                       writes={d + i: v for i, v in enumerate(out)}, fp=[[d, d + 4 * vl]])

    def vec_dma_in(self, cid: int, nbytes: int, spm_off: int = 0) -> tuple[int, bytes]:
        """DMA nbytes from the shared memory into the cluster scratchpad at spm_off; returns (spm addr, data)."""
        al = max(16, self.cfg.w // 8)
        src = self.alloc(nbytes, al)
        data = bytes(self.rng.getrandbits(8) for _ in range(nbytes))
        self.fill(src, data)
        dst = self.cfg.spm(cid) + spm_off
        tag = self._tag(cid)
        self._send(cid, [CT_DMA | (tag << 16), nbytes, 0, src, dst],
                   dict(kind="v", tag=tag, status=ST_OK, type=CT_DMA, count=nbytes, step=0))
        return dst, data

    def vec_dma_out(self, cid: int, spm_addr: int, data: bytes):
        """DMA a scratchpad range back to a fresh shared-memory region (expected content: data)."""
        al = max(16, self.cfg.w // 8)
        dst = self.alloc(len(data), al)
        tag = self._tag(cid)
        self._send(cid, [CT_DMA | (tag << 16), len(data), 0, spm_addr, dst],
                   dict(kind="v", tag=tag, status=ST_OK, type=CT_DMA, count=len(data), step=0),
                   writes={dst + i: v for i, v in enumerate(data)}, fp=[[dst, dst + len(data)]])

    def vec_bad_type(self, cid: int):
        tag = self._tag(cid)
        self._send(cid, [0xF | (tag << 16)], dict(kind="v", tag=tag, status=ST_BAD_TYPE, type=0xF, count=0))

    def vec_nop(self, cid: int):
        tag = self._tag(cid)
        self._send(cid, [CT_NOP | (tag << 16)], dict(kind="v", tag=tag, status=ST_OK, type=CT_NOP, count=0))

    # ------------------------------------------------------------------ tensor cluster commands
    def gemm(self, cid: int, M: int, N: int, K: int, flags: int = 0, ofmt: int = A.OFMT_INT32, b_err: bool = False,
             raw: dict | None = None, **kw):
        esz = 1 if ofmt == A.OFMT_INT8 else 4
        a = self.alloc(M * K, 1)
        if b_err:
            lo, hi = self.error_window()
            b = lo + self.rng.randrange(0, hi - lo - K * N)
        else:
            b = self.alloc(K * N, 1)
        c = self.alloc(M * N * esz, 4)
        self.fill(a, bytes(self.rng.getrandbits(8) for _ in range(M * K)))
        if not b_err:
            self.fill(b, bytes(self.rng.getrandbits(8) for _ in range(K * N)))
        g = Gemm(a, b, c, M, N, K, K, N, N * esz, flags=flags, ofmt=ofmt, raw=raw or {}, **kw)
        g.tid = self._tag(cid)
        w = g.words()
        code = validate(w, self.hw)
        exp = dict(kind="t", tid=g.tid, op=w[0] & 0xFF, err=code, status=A.ST_OK if code == A.E_NONE else A.ST_ERROR,
                   count=0, tiles=0)
        fp = [[c + r * g.ldc, c + r * g.ldc + N * esz] for r in range(M)]
        if code == A.E_NONE and b_err:
            exp.update(err=A.E_DMA_READ, status=A.ST_ERROR, count=None, tiles=None)
            self._send(cid, w, exp, fp=fp, executes_ok=False)
        elif code == A.E_NONE:
            res, sat = gemm_result(self.init, MEM_BASE, g)
            t = traffic(g, self.hw)
            exp.update(count=M * N * esz, tiles=t["tiles"], sat=int(sat))
            self._send(cid, w, exp, writes=dict(res), fp=fp)
        else:
            self._send(cid, w, exp)

    # ------------------------------------------------------------------ shell / control
    def bad_dest(self, dest: int):
        tag = 0xA5
        w0 = CT_NOP | (tag << 16)
        self.ops.append(f"C {dest} {w0:08x} " + " ".join(["00000000"] * 11))
        self.shell_recs.append(dict(dest=dest, w1=w0))

    def reset(self, cid: int, hold_check: bool = True, after_x: list[str] | None = None):
        """Reset cluster cid (shell CL_RESET); commands not yet completed are destroyed (prefix semantics)."""
        self.op(f"X {cid}")
        for o in after_x or []:
            self.op(o)
        if hold_check and cid < 8 and self.cfg.local_mem:
            self.op(f"HE {self.cfg.spm(cid):x}")         # local-memory window answers errors while in reset
        self.op(f"XW {cid}")                             # (the X operation itself logs LOST[cid])
        self.lost_checks.append(dict(cid=cid, epoch=len(self.epochs.setdefault(cid, [[]])) - 1))
        self.epochs[cid].append([])

    # ------------------------------------------------------------------ output
    def write(self, out: Path, meta: dict | None = None):
        out.mkdir(parents=True, exist_ok=True)
        with open(out / "mem_init.hex", "w") as f:
            for i in range(0, MEM_BYTES, 16):
                f.write(" ".join(f"{b:02x}" for b in self.init[i:i + 16]) + "\n")
        (out / "prog.txt").write_text("\n".join(self.ops + ["Q"]) + "\n")
        exp = dict(base=MEM_BASE, mem_bytes=MEM_BYTES, cmds=self.cmds,
                   epochs={str(k): v for k, v in self.epochs.items()}, shell_recs=self.shell_recs,
                   dontcare=self.dontcare, lost_checks=self.lost_checks, plus=self.plus, cfg=self.cfg.__dict__,
                   cover=self.cover,
                   meta=meta or {})
        (out / "expect.json").write_text(json.dumps(exp))
