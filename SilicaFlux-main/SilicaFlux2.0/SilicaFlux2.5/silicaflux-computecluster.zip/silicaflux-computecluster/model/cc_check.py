#!/usr/bin/env python3
"""Check one tb_compute_cluster run directory against its expect.json (SilicaFlux Project 32).

  * the simulator log reports RESULT PASS and no ERROR line (protocol checkers, shadow checks, register checks)
  * completion routing: every record carries a valid source ID, the right error flag, and the records of each
    cluster arrive in that cluster's command order with exactly the fields the reference predicts (incl. SEQ);
    an epoch ended by a cluster reset may be a prefix (destroyed commands produce no record), the last epoch must
    be complete
  * shell records for commands to absent clusters (source ID, error flag, magic / code, echoed word 0)
  * LOST[cid] read after each reset equals the number of commands of that epoch that produced no record
  * the WHOLE final shared-memory image: initial image + the bytes of every command that completed OK; only the
    footprints of destroyed / execution-failed commands and the declared don't-care windows are excluded
Prints one JSON line; exit status 0 on PASS.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import cc_prog  # noqa: E402,F401  (sets the reference-model import path)
from tsu_ref import rec_fields  # noqa: E402

SHELL = 0x7000


def vec_fields(w: list[int]) -> dict:
    w0 = w[0]
    return dict(tag=w0 & 0xFF, status=(w0 >> 8) & 0xF, type=(w0 >> 12) & 0xF, detail=(w0 >> 16) & 0xF,
                step=(w0 >> 25) & 7, valid=w0 >> 31, seq=w[1] & 0xFFFF, count=w[2], result=w[3], err_addr=w[4],
                cycles=w[5])


def load_mem(path: Path, n: int) -> bytearray:
    out = bytearray()
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("//"):
            out.extend(int(x, 16) for x in line.split())
    assert len(out) == n, f"{path.name}: {len(out)} bytes, expected {n}"
    return out


def check(d: Path) -> dict:
    exp = json.loads((d / "expect.json").read_text())
    fails: list[str] = []
    log = (d / "sim.log").read_text(errors="replace") if (d / "sim.log").exists() else ""
    if "RESULT PASS" not in log:
        fails.append("testbench did not report RESULT PASS")
    for line in log.splitlines():
        if ("ERROR" in line or "%Error" in line) and "RESULT" not in line:
            fails.append("log: " + line.strip()[:200])
            break
    if not (d / "records.txt").exists():
        return dict(ok=False, fails=fails + ["no records.txt"])

    recs: dict[int, list[tuple[int, list[int]]]] = {}
    logs: list[tuple[int, int]] = []
    shell_seen: list[tuple[int, int, list[int]]] = []
    tsu0 = cc_prog.TSU_ID0
    nv, nt = exp["cfg"]["nv"], exp["cfg"]["nt"]
    present = set(range(nv)) | {tsu0 + j for j in range(nt)}
    for line in (d / "records.txt").read_text().splitlines():
        t = line.split()
        if not t:
            continue
        if t[0] == "P":
            src, err, w = int(t[1]), int(t[2]), [int(x, 16) for x in t[3:9]]
            if w[0] >> 16 == 0x5345 and (src not in present):
                shell_seen.append((src, err, w))
            elif src not in present:
                fails.append(f"record from absent / unknown source {src}: {t}")
            else:
                recs.setdefault(src, []).append((err, w))
        elif t[0] == "L":
            logs.append((int(t[1], 16), int(t[2], 16)))

    cmds = exp["cmds"]
    completed_ok = [False] * len(cmds)
    destroyed = [False] * len(cmds)
    n_checked = 0
    lost_by_epoch: dict[tuple[int, int], int] = {}
    for cid_s, epochs in exp["epochs"].items():
        cid = int(cid_s)
        got = recs.get(cid, [])
        pos = 0
        for ei, ep in enumerate(epochs):
            last = ei == len(epochs) - 1
            j = 0
            while j < len(ep) and pos < len(got):
                c = cmds[ep[j]]
                e = c["exp"]
                err, w = got[pos]
                f = vec_fields(w) if e["kind"] == "v" else rec_fields(w)
                bad = [k for k, v in e.items() if k != "kind" and v is not None and f.get(k) != v]
                if bad:
                    if not last and j >= 0 and f.get("seq") == 0 and ei + 1 < len(epochs):
                        break                                   # first record of the next epoch
                    fails.append(f"cluster {cid} epoch {ei} cmd {j}: " +
                                 ", ".join(f"{k} got {f.get(k)} expected {e[k]}" for k in bad))
                    break
                exp_err = int(f["status"] != 0)
                if err != exp_err:
                    fails.append(f"cluster {cid} epoch {ei} cmd {j}: cpl_err {err}, record status {f['status']}")
                completed_ok[ep[j]] = f["status"] == 0
                pos += 1
                j += 1
                n_checked += 1
            for k in range(j, len(ep)):
                destroyed[ep[k]] = True
            lost_by_epoch[(cid, ei)] = len(ep) - j
            if last and j != len(ep):
                fails.append(f"cluster {cid}: {j} of {len(ep)} records in the final epoch")
        if pos != len(got):
            fails.append(f"cluster {cid}: {len(got) - pos} unexpected / unmatched records")
    for cid in recs:
        if str(cid) not in exp["epochs"]:
            fails.append(f"cluster {cid}: {len(recs[cid])} records, no command was sent to it")

    # shell records (absent destination)
    if len(shell_seen) != len(exp["shell_recs"]):
        fails.append(f"{len(shell_seen)} shell records, expected {len(exp['shell_recs'])}")
    for (src, err, w), x in zip(shell_seen, exp["shell_recs"]):
        if src != x["dest"] or err != 1 or w[0] != 0x5345_0001 or w[1] != x["w1"] or any(w[2:]):
            fails.append(f"shell record {src} {err} {[hex(v) for v in w]} expected dest {x['dest']} word1 {x['w1']:#x}")

    # LOST registers
    lost_logs = {}
    for a, v in logs:
        if SHELL + 0x080 <= a < SHELL + 0x080 + 4 * 12:
            lost_logs.setdefault((a - SHELL - 0x080) // 4, []).append(v)
    seen_idx: dict[int, int] = {}
    for lc in exp["lost_checks"]:
        cid, ei = lc["cid"], lc["epoch"]
        k = seen_idx.get(cid, 0)
        seen_idx[cid] = k + 1
        vals = lost_logs.get(cid, [])
        if k >= len(vals):
            fails.append(f"LOST[{cid}] not read")
            continue
        want = lost_by_epoch.get((cid, ei))
        if want is not None and exp["cfg"]["cmd_if"] and vals[k] != want:
            fails.append(f"LOST[{cid}] = {vals[k]}, {want} commands of epoch {ei} produced no record")

    # memory
    base, nbytes = exp["base"], exp["mem_bytes"]
    init = load_mem(d / "mem_init.hex", nbytes)
    if not (d / "mem_final.hex").exists():
        return dict(ok=False, fails=fails + ["no mem_final.hex (simulation did not finish)"], records=n_checked,
                    shell_records=len(shell_seen), destroyed=sum(destroyed), stats="")
    final = load_mem(d / "mem_final.hex", nbytes)
    expm = bytearray(init)
    care = bytearray([1]) * nbytes
    for lo, hi in exp["dontcare"]:
        care[lo - base:hi - base] = bytes(hi - lo)
    for i, c in enumerate(cmds):
        if completed_ok[i] and c["ok"]:
            for a, v in c["writes"]:
                expm[a - base] = v
        elif destroyed[i] or not c["ok"]:
            for lo, hi in c["fp"]:
                care[lo - base:hi - base] = bytes(hi - lo)
    bad = [i for i in range(nbytes) if care[i] and final[i] != expm[i]]
    if bad:
        i = bad[0]
        fails.append(f"memory: {len(bad)} bytes differ; first at {base + i:#x}: got {final[i]:#04x} expected "
                     f"{expm[i]:#04x}")
    stats = (d / "stats.txt").read_text() if (d / "stats.txt").exists() else ""
    cov = {}
    for line in stats.splitlines():
        t = line.split()
        if t and t[0] == "cover":
            cov = {t[i]: int(t[i + 1]) for i in range(1, len(t) - 1, 2)}
    for item in exp.get("cover", []):
        if cov.get(item, 0) == 0:
            fails.append(f"coverage item not hit: {item}")
    return dict(ok=not fails, fails=fails, records=n_checked, shell_records=len(shell_seen),
                destroyed=sum(destroyed), stats=stats)


if __name__ == "__main__":
    r = check(Path(sys.argv[1]))
    print(json.dumps({k: v for k, v in r.items() if k != "stats"}))
    sys.exit(0 if r["ok"] else 1)
