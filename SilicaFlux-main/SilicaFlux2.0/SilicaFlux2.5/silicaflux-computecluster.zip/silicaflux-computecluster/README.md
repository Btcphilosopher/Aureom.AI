# SilicaFlux Project 32 — ComputeCluster: floorplan-aware vector and tensor regions

**Primary RTL:** [`rtl/silicaflux_compute_cluster.sv`](rtl/silicaflux_compute_cluster.sv) · Aureom.AI | SilicaFlux-HPC

The verified SilicaFlux engines (the HPC Module 08 FP32 vector tile and the TENSORCORE 08 INT8 tensor unit) are
organised into **repeatable, identifiable compute regions**. Each region is one cluster wrapper with its own local
control, reset, status, performance events and NoC-facing ports. An integration shell replicates them on the
DataFabric crossbar under **stable instance names** (`u_vector_0 … u_vector_7`, `u_tensor_0 … u_tensor_3`). The
engines are reused **byte for byte**: no arithmetic pipeline is duplicated or modified.

> **Status.** RTL simulation, Yosys synthesis and an exploratory OpenROAD placement of a reduced configuration.
> No silicon area, timing closure, power or tape-out readiness is claimed. Generic synthesis cells are not area.
> The placed design is a reduced configuration with memories as flip-flops, pre-CTS, unrouted. The performance
> figures of the SilicaFlux illustrations are not used anywhere. Delivered as an archive, not committed.

## Definition of done

| Requirement | Evidence |
|---|---|
| The minimum configuration works | defaults = 1 vector + 1 tensor cluster (the TENSORCORE 08 coexistence shape and page map); stage 2 of the regression: stream and legacy command paths, mixed traffic, back-pressure, errors, cluster reset — `reports/regression.md` |
| The HPC cluster hierarchy elaborates | Verilator, Icarus and Yosys elaborate 12 legal configurations up to 8 + 4 clusters; 12 illegal ones are refused by the design's own checks — `reports/lint.md`; 4 + 2 and 8 + 4 simulated |
| Every compute region identifiable in a synthesis netlist | hierarchical Yosys netlists contain `u_vector_k` / `u_tensor_j` (and `u_noc`, `u_regs`, …) for every target, checked by script; sky130hd netlist flattened by OpenROAD keeps `u_vector_k/…` prefixes, used by the region Tcl — `reports/synth.md`, `reports/physical.md` |
| Start with one vector and one tensor cluster, then multiple | regression stages 1 → 2 → 3 |

## Results (final runs; every number is from `reports/`)

See [`reports/SUMMARY.md`](reports/SUMMARY.md). Key figures:

| Check | Result | Report |
|---|---|---|
| **Stage 1** — one vector cluster, one tensor cluster (each alone in the shell): basic, errors, reset, back-pressure | **8 / 8** | [regression](reports/regression.md) |
| **Stage 2** — minimum configuration 1 + 1: mixed traffic in 3 memory / back-pressure modes, errors, reset (×2), legacy register-page path (×2) | **9 / 9** | [regression](reports/regression.md) |
| **Stage 3** — multiple instances: 4 + 2 (6 clusters busy at once), 2 + 1 at 64-bit with every pipeline boundary, 2 + 2 at 128-bit (8 lanes, 8×8 + quant + double buffering, no local-memory port), reduced 4 + 2 of the placement experiment, 8 + 4 (every slot) | **13 / 13** | [regression](reports/regression.md) |
| Regression total (completion records, whole 1 MiB memory image, SFB2 protocol checkers on every fabric port, LOST, coverage) | **30 / 30** | [regression](reports/regression.md) |
| Lint / elaboration: Verilator `-Wall` (0 warnings in new RTL), Icarus, Yosys on 12 legal configurations; 12 illegal configurations refused by the design's own checks in all three tools | **24 / 24** | [lint](reports/lint.md) |
| Synthesis, one vector cluster (Yosys, generic, hierarchy kept) | 156 963 cells, 11 393 FF, 530 484 memory bits inferred | [synth](reports/synth.md) |
| Synthesis, one tensor cluster | 116 013 cells, 12 373 FF, 27 592 memory bits | [synth](reports/synth.md) |
| Synthesis, subsystem 1 + 1 / 4 + 2 / 4 + 2 with all slices | 284 706 / 885 953 / 890 773 cells; every `u_vector_k` / `u_tensor_j` present by name | [synth](reports/synth.md) |
| Control-path latency (NOP, command in → completion out) | 23 cycles (24 with the command slice) | [perf](reports/perf.md) |
| Cost of the NoC-facing slices on DMA-bound commands | ×1.72–1.78 at 1-cycle memory, ×1.21–1.33 at 8-cycle memory (one transaction per crossbar port) | [perf](reports/perf.md) |
| Region / group constraints on the real netlist | 8 regions + 18 locality groups applied to the mapped reduced 4 + 2 sky130hd netlist (≈ 520 k instances, 5.49 mm² cells) in 3.4 s; every region and group has members; DEF REGIONS / GROUPS exported | [physical](reports/physical.md) |
| Does OpenROAD 2.0-12331 honour regions? (controlled test) | **No, not usable for placement in this build:** global placement honours no mechanism; detailed placement ignores odb regions, forces voltage-domain members but then fails `check_placement`; region-less groups make detailed placement exhaustive (full design stopped after 44 CPU-min) | [physical](reports/physical.md) |
| Unconstrained placement of the reduced 4 + 2 | legal; clusters interleave (0–30 % of each cluster inside its proposed box, cluster bounding boxes 3.4–7× the region): locality must be constrained | [physical](reports/physical.md) |
| Pre-CTS timing after buffering, 20 ns reference | with the NoC-facing slices: WNS −3.32 ns, critical paths inside the tensor regions, every boundary interface ≥ +6.9 ns; without slices: WNS −5.08 ns, the cluster-memory interface fails (−3.27 ns) | [physical](reports/physical.md) |

## Layout

```
rtl/        silicaflux_compute_cluster.sv (shell), silicaflux_vector_cluster.sv, silicaflux_tensor_cluster.sv,
            sfx_cluster_ctrl.sv (local control), sfx_cluster_rst_iso.sv (cluster reset / isolation),
            sfx_sfb_upsizer.sv, sfx_cmd_router.sv, sfx_cpl_arbiter.sv, sfx_shell_regs.sv, sfx_cluster_defs.svh, files.f
tb/         tb_compute_cluster.sv (program-driven system testbench, any configuration)
model/      cc_prog.py (programs + expectations from independent references), cc_check.py (checker)
scripts/    run_tests.py (regression), run_lint.py, run_perf.py, make_report.py
syn/        run_synth.py (Yosys build targets: vector cluster, tensor cluster, subsystem)
physical/   gen_regions.py (region / group generator), phys_hpc/regions.tcl, groups.tcl, plan.json (generated proposal),
            apply_constraints.tcl, run_phys.py, export_constraints.py, region_support_test.py, post_sta.py, summarize.py
configs/    min, hpc, hpc_piped, wide128, max_slots, phys_hpc, phys_hpc_noslice (.json: parameters, resolved set, address map)
docs/       00 audit, 01 architecture, 02 cluster interface, 03 parameters, 04 timing and locality,
            05 verification, 06 synthesis, 07 physical integration, 08 known limitations
reports/    regression, lint, perf, synth (+ raw logs), physical (+ OpenROAD logs, DEF excerpt), SUMMARY
third_party/ reused RTL / models, byte-identical (SHA256SUMS, PROVENANCE.md, PROVENANCE_P32.md)
env/        install_openroad.sh (pinned OpenROAD build + ORFS sky130hd platform)
```

## Quick start

```bash
sudo apt-get install -y iverilog yosys verilator
```

```bash
make lint
```

```bash
make stage1 && make stage2 && make stage3
```

```bash
make perf
```

```bash
make synth-vector synth-tensor synth-subsystem
```

```bash
env/install_openroad.sh && make phys
```

```bash
make report
```

Tools used: Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33 (Ubuntu 24.04), OpenROAD 2.0-12331-g6011bbe77 with
ORFS ab2aaf0f sky130hd (FloorplanLab's pinned build), Python 3.13 (standard library only).

## Deliverables

| Brief deliverable | Files |
|---|---|
| `silicaflux_compute_cluster.sv` | `rtl/silicaflux_compute_cluster.sv` + `sfx_cmd_router.sv`, `sfx_cpl_arbiter.sv`, `sfx_shell_regs.sv` |
| `silicaflux_vector_cluster.sv` | `rtl/silicaflux_vector_cluster.sv` (+ `sfx_cluster_ctrl.sv`, `sfx_cluster_rst_iso.sv`) |
| `silicaflux_tensor_cluster.sv` | `rtl/silicaflux_tensor_cluster.sv` (+ `sfx_sfb_upsizer.sv`) |
| Cluster configuration files | `configs/*.json` |
| Physical hierarchy constraints | `physical/phys_hpc/regions.tcl`, `groups.tcl`, `plan.json`, `physical/apply_constraints.tcl`; DEF REGIONS / GROUPS `reports/physical/phys_hpc_regions_groups.def`; generator `physical/gen_regions.py` |
| Tests | `tb/`, `model/`, `scripts/run_tests.py`, `scripts/run_lint.py`, `scripts/run_perf.py` |
| Actual synthesis reports | `reports/synth.md`, `reports/synth/<target>/` (scripts, logs, `stat`), `reports/physical.md` |
| Cluster interface documentation | `docs/02_CLUSTER_INTERFACE.md` (+ docs/01, 03, 04) |

## What is not claimed

No silicon area, frequency, power or floorplan validation. No FPGA or silicon run. No formal proof or gate-level
simulation of the new RTL. Full list: [`docs/08_KNOWN_LIMITATIONS.md`](docs/08_KNOWN_LIMITATIONS.md).
