"""Test catalogue for the TENSORCORE 08 integration regression (tb/tb_tsu.sv).

Each test function builds a Prog (model/prog.py) for a hardware configuration and returns it with the memory /
fabric plusargs of the run.  Stages follow the brief: the 4x4 INT8 / INT32 baseline (sequential DMA, one operand
set) is brought up and proven first (stages 1, 2); double buffering, quantisation and other array shapes are
enabled only afterwards (stage 3).
"""
from __future__ import annotations

from fractions import Fraction

import tsu_abi as A
from prog import BASE, Prog
from tsu_ref import Gemm, HwCfg, schedule

# ----------------------------------------------------------------------------- hardware configurations
CFG = {
    "base":   HwCfg(),                                                   # brief baseline: 4x4, sequential, INT32
    "mo1":    HwCfg(max_out=1),                                          # one SFB2 transaction in flight
    "dbuf":   HwCfg(dbuf=1),                                             # double buffering (PREFETCH)
    "quant":  HwCfg(quant=1),                                            # INT8 requantised output
    "full":   HwCfg(quant=1, dbuf=1),                                    # both advanced features
    "a8":     HwCfg(rows=8, cols=8, banks=8, opbuf=4096, quant=1, dbuf=1),
    "a2":     HwCfg(rows=2, cols=2, banks=2, opbuf=512, quant=1),
    "tk16":   HwCfg(tile_k=16, opbuf=512, k_max=4096, cmdq=2, cplq=2),
    "fi":     HwCfg(fault=1, dbuf=1, quant=1),
    "wd":     HwCfg(wdog=10),
}

MEMS = {
    "lat1": {},
    "lat8": dict(lat_min=8, lat_max=8),
    "rand": dict(lat_min=1, lat_max=24, bp=30, rsp_bp=20),
}

FL_PF = 1 << A.FL_PREFETCH
FL_NM = 1 << A.FL_NMAJOR
FL_IRQ = 1 << A.FL_IRQ


def P(cfg, seed):
    return Prog(CFG[cfg] if isinstance(cfg, str) else cfg, seed)


# ============================================================================= stage 1: one command
def t_g4x4x4(cfg, seed):
    p = P(cfg, seed)
    p.gemm(4, 4, 4)
    return p, {}


def t_g1x1x1(cfg, seed):
    p = P(cfg, seed)
    p.gemm(1, 1, 1)
    return p, {}


# ============================================================================= stage 2: baseline coverage
def shapes(p: Prog, flags=0):
    """The brief's GEMMs plus boundary shapes: one tile, many tiles, partial tiles, K chunks, odd strides."""
    p.gemm(4, 4, 4, flags=flags)
    p.gemm(8, 8, 8, flags=flags)                                                   # 4 output tiles
    p.gemm(17, 13, 29, lda=29, ldb=13, ldc=13 * 4 + 8, flags=flags)                 # 20 boundary-heavy tiles
    p.gemm(17, 13, 29, lda=31, ldb=17, ldc=13 * 4 + 12, a_align=1, flags=flags)     # odd strides, odd bases
    p.gemm(8, 8, 200, lda=203, flags=flags)                                         # 4 K chunks (64, 64, 64, 8)
    p.gemm(5, 6, 130, kc=17 if p.cfg.tile_k > 17 else p.cfg.tile_k - 3, flags=flags)  # custom KC chunks
    p.gemm(5, 7, 3, flags=flags)
    p.gemm(37, 1, 5, lda=7, ldb=3, flags=flags)
    p.gemm(1, 37, 5, ldb=41, flags=flags)


def t_shapes(cfg, seed):
    p = P(cfg, seed)
    shapes(p)
    return p, {}


def t_shapes_nmajor(cfg, seed):
    p = P(cfg, seed)
    shapes(p, flags=FL_NM)
    p.gemm(64, 16, 64, flags=FL_NM)
    return p, {}


def t_tiles_large(cfg, seed):
    p = P(cfg, seed)
    p.gemm(32, 32, 64)                                                              # 64 tiles
    p.gemm(32, 32, 256)                                                             # 64 tiles x 4 chunks
    return p, {}


def t_kchunk_long(cfg, seed):
    p = P(cfg, seed)
    p.gemm(4, 4, 1000)                                                              # 16 chunks
    p.gemm(3, 5, 777, kc=1 if p.cfg.tile_k < 2 else p.cfg.tile_k // 2 + 1)
    return p, {}


def t_extreme(cfg, seed):
    """Accumulation extremes: every product +16384, K = 131071 (the exact INT32 bound), and mixed signs."""
    p = P(cfg, seed)
    p.gemm(4, 4, 64, a_mode="min", b_mode="min")
    p.gemm(4, 4, 64, a_mode="min", b_mode="max")
    p.gemm(4, 4, 64, a_mode="max", b_mode="max")
    k = min(p.cfg.k_max, 131071)
    p.gemm(1, 2, k, a_mode="min", b_mode="min")                                    # 131071 * 16384 = 2^31 - 16384
    p.gemm(1, 1, k, a_mode="min", b_mode="max")                                    # most negative reachable sum
    return p, dict(maxcyc=40_000_000)


def t_b2b(cfg, seed):
    """Back-to-back commands without waiting: queue-full doorbell refusals, NOPs, and a RAW chain (the A of a
    command is the C of the previous one, read as INT8 bytes) that only in-order execution gets right."""
    p = P(cfg, seed)
    g1 = p.gemm(6, 5, 20)
    for _ in range(3):
        p.nop()
    p.gemm(9, 4, 33)
    a2 = Gemm(g1.c, 0, 0, g1.m, 7, 4 * g1.n, g1.ldc, 7, 28)                         # A = C of g1 (INT32 bytes)
    a2.b = p.matrix_i8(a2.k, 7, 7)
    a2.c = p.alloc((a2.m - 1) * 28 + 28, 4)
    p.submit(a2)
    p.gemm(4, 4, 4)
    p.nop(flags=FL_IRQ)
    p.gemm(13, 3, 70)
    p.gemm(1, 1, 1)
    p.gemm(8, 8, 8)
    return p, {}


def t_invalid(cfg, seed):
    """Every validation rule, with boundary cases.  Nothing may touch memory or the bus: the whole memory and the
    exact SFB2 word counts are checked.  A valid GEMM at the end proves the unit is still healthy."""
    c = CFG[cfg] if isinstance(cfg, str) else cfg
    p = P(c, seed)
    p.op("E 1")                                                                    # continue on error
    g = p.gemm(5, 6, 7, submit=False)
    kw = dict(a=g.a, b=g.b, c=g.c, m=5, n=6, k=7, lda=7, ldb=6, ldc=24)

    def bad(**over):
        d = dict(kw)
        raw = over.pop("raw", {})
        d.update(over)
        p.submit(Gemm(**d, raw=raw))

    bad(version=1); bad(version=3); bad(opcode=0x01); bad(opcode=0x41); bad(opcode=0xFF)
    bad(flags=0x10); bad(flags=0x80)
    if not c.dbuf:
        bad(flags=FL_PF)
    p.nop(flags=FL_NM); p.nop(raw={3: 1}); p.nop(raw={0: (A.ABI_VERSION << 8) | (1 << 15)})
    w0 = (A.OP_GEMM | (A.ABI_VERSION << 8))
    bad(raw={0: w0 | (1 << 15)})                                                   # header bit 15
    bad(raw={9: 1 << 15}); bad(raw={9: 1 << 6}); bad(raw={11: 1 << 16}); bad(raw={11: 1 << 6})
    bad(rm=1); bad(relu=1); bad(qmult=5); bad(qshift=3); bad(qzp=1)                # INT32 output + quant fields
    bad(ofmt=A.OFMT_INT8, rm=5); bad(ofmt=A.OFMT_INT8, rm=7)
    bad(a_lay=1); bad(b_lay=2); bad(c_lay=3)
    bad(a_type=1); bad(b_type=2); bad(ofmt=2); bad(ofmt=3)
    if not c.quant:
        bad(ofmt=A.OFMT_INT8)
    bad(m=0); bad(n=0); bad(k=0)
    bad(kc=c.tile_k + 1)
    if c.k_max < 131071:
        bad(k=c.k_max + 1, lda=c.k_max + 1)                                        # DIM_RANGE
    if c.k_max >= 65536:
        bad(k=65536, kc=1, lda=65536, raw={})                                     # 65536 chunks > 65535
    bad(lda=6); bad(ldb=5); bad(ldc=23); bad(ldc=20)
    bad(c=kw["c"] + 2); bad(ldc=26)                                                # INT32 C alignment
    bad(a=0xFFFF_FFF0, lda=7)                                                      # A wraps 2^32
    bad(c=0xFFFF_FFF0)                                                             # C wraps 2^32
    bad(ldb=0x4000_0000)                                                           # (K-1)*LDB overflows
    bad(a=BASE - 4)                                                                # below the window
    bad(c=p.cfg.mem_hi - 16)                                                       # leaves the window
    a_end = 4 * 7 + 7                                                              # A footprint: 35 bytes
    bad(a=p.cfg.mem_hi - a_end + 1)                                                # last byte == MEM_HI: RANGE
    bad(c=(kw["a"] + 8) & ~3, ldc=24)                                              # C overlaps A
    bad(c=(kw["b"] + 3) & ~3)                                                      # C overlaps B
    # boundary accepted: A's last byte is the last byte of the window (and of the memory model)
    a_top = p.cfg.mem_hi - a_end
    p.matrix_i8(5, 7, 7, addr=a_top)
    g2 = p.gemm(5, 6, 7, submit=False)
    g2.a = a_top
    p.submit(g2)
    p.gemm(5, 6, 7)                                                                # still healthy
    return p, {}


def t_dma_errors(cfg, seed):
    """Memory answers errors: a read error inside B, a write error inside C.  Records carry the failing word
    address and the exact acknowledged-byte prefix; stop-on-error skips the next command until ERR_CLEAR."""
    p = P(cfg, seed)
    g = p.gemm(9, 9, 40, submit=False)
    pa = (g.b + 3 * g.ldb) & ~3                                                    # B[3][0]: first failing read
    p.op(f"P 0 {pa:x} {pa + 4:x} 1 0")
    p.submit(g, expect=dict(err=A.E_DMA_READ, status=A.ST_ERROR, detail=7, err_addr=pa, count=0, tiles=0, sat=0),
             executes=False)
    p.gemm(3, 3, 3, expect=dict(err=A.E_PRIOR, status=A.ST_SKIPPED, count=0, tiles=0, sat=0), executes=False)
    p.sync()
    p.op("K")
    p.op("P 0 0 0 0 0")
    # write error in C, tile (row 4..7, col 0..3) = second tile row of a 9x9 matrix; element (5, 2)
    g = p.gemm(9, 9, 12, submit=False)
    pw = g.c + 5 * g.ldc + 4 * 2
    p.op(f"P 1 {pw:x} {pw + 4:x} 2 0")
    tiles, count = 0, 0
    for m0, n0, k0, em, en, ek, lastk in schedule(g, p.cfg):
        if not lastk:
            continue
        if m0 <= 5 < m0 + em and n0 <= 2 < n0 + en:
            count += (5 - m0) * 4 * en + 4 * (2 - n0)
            break
        tiles += 1
        count += em * en * 4
    p.submit(g, expect=dict(err=A.E_DMA_WRITE, status=A.ST_ERROR, detail=8, err_addr=pw, count=count, tiles=tiles,
                            sat=0), executes=False)
    p.sync()
    p.op("K")
    p.op("P 1 0 0 0 0")
    p.gemm(7, 5, 9)
    return p, {}


def t_stop_continue(cfg, seed):
    p = P(cfg, seed)
    p.nop()
    p.submit(Gemm(0, 0, 0, 1, 1, 1, 1, 1, 4, version=1))                           # ERROR (VERSION)
    p.gemm(4, 4, 4, expect=dict(err=A.E_PRIOR, status=A.ST_SKIPPED, count=0, tiles=0, sat=0), executes=False)
    p.nop(expect=dict(err=A.E_PRIOR, status=A.ST_SKIPPED))
    p.op("K")
    p.gemm(4, 4, 4)
    p.op("E 1")
    p.submit(Gemm(0, 0, 0, 0, 1, 1, 1, 1, 4))                                      # ERROR (DIM_ZERO), continue
    p.gemm(5, 5, 5)
    return p, {}


def t_irq(cfg, seed):
    p = P(cfg, seed)
    p.op("N 7")
    p.gemm(4, 4, 8, flags=FL_IRQ)
    p.nop(flags=FL_IRQ)
    p.gemm(3, 3, 3)
    p.plus["irq_min_edges"] = 1
    return p, {}


def t_reset(cfg, seed):
    """Hard reset (DUT, fabric and memory together, SFB2 R11) at a random point of a running GEMM; then the unit
    must accept and execute new commands exactly.  Records before the reset must be a prefix of the expected."""
    p = P(cfg, seed)
    p.perf_ok = False
    p.new_group("prefix")
    p.gemm(17, 13, 29, lda=29, ldb=13, ldc=13 * 4 + 8)
    p.gemm(16, 16, 100)
    p.gemm(9, 9, 9)
    p.op(f"D {p.rng.randrange(40, 14000)}")
    p.op(f"X {p.rng.randrange(1, 6)}")
    p.new_group("exact")
    p.gemm(17, 13, 29)
    p.gemm(8, 8, 8)
    return p, {}


def t_abort(cfg, seed):
    """CTRL.ABORT while commands run and are queued: the running one completes ERROR/ABORTED (or OK if it was
    already done), every queued one SKIPPED/ABORTED; the bus port is quiesced and the datapath reset before the
    record; new commands then execute exactly."""
    p = P(cfg, seed)
    p.perf_ok = False
    p.new_group("abort")
    p.gemm(16, 16, 64)
    p.gemm(17, 13, 29)
    p.gemm(8, 8, 200)
    p.gemm(4, 4, 4)
    p.op(f"D {p.rng.randrange(30, 18000)}")
    p.op("A")
    p.op("K")
    p.new_group("exact")
    p.gemm(17, 13, 29)
    p.gemm(5, 5, 5)
    p.sync()
    p.op("A")                                                                      # abort while idle: no record
    p.gemm(4, 4, 4)
    return p, {}


def t_contention(cfg, seed):
    """DMA contention on the real DataFabric crossbar: a second master issues random reads / writes to the same
    SRAM slave (round-robin arbitration, one transaction per port, R6)."""
    p = P(cfg, seed)
    nz = p.alloc(4096, 4096)
    p.dontcare.append([nz, nz + 4096])
    shapes(p)
    p.gemm(16, 16, 64)
    return p, dict(noise=60, nz_lo=f"{nz:x}", nz_hi=f"{nz + 4096:x}", lat_min=1, lat_max=3)


def t_watchdog(cfg, seed):
    """WDOG_LOG2 = 10.  (1) B reads answered 1500 cycles late: TIMEOUT, the port is drained (the late response
    is collected), the datapath reset, the next command runs.  (2) B reads never answered: TIMEOUT, the port
    cannot be drained -> HALT; only a hard reset recovers."""
    p = P(cfg, seed)
    g = p.gemm(4, 4, 16, submit=False)
    p.op(f"P 0 {g.b:x} {g.b + g.ldb * g.k:x} 8 1500")
    p.submit(g, expect=dict(err=A.E_TIMEOUT, status=A.ST_ERROR, count=0, tiles=0), executes=False)
    p.sync()
    p.op("P 0 0 0 0 0")
    p.op("K")
    p.gemm(4, 4, 16)
    g = p.gemm(4, 4, 16, submit=False)
    p.op(f"P 0 {g.b:x} {g.b + g.ldb * g.k:x} 4 0")
    p.new_group("prefix")
    p.submit(g, expect=dict(err=A.E_TIMEOUT, status=A.ST_ERROR, count=0, tiles=0), executes=False)
    p.sync()
    p.op("X 3")
    p.op("P 0 0 0 0 0")
    p.new_group("exact")
    p.gemm(6, 6, 6)
    p.perf_ok = False
    return p, {}


# ============================================================================= stage 3: advanced features
def t_dbuf_shapes(cfg, seed):
    p = P(cfg, seed)
    shapes(p, flags=FL_PF)
    p.gemm(32, 32, 256, flags=FL_PF)
    p.gemm(64, 16, 64, flags=FL_PF | FL_NM)
    return p, {}


def t_dbuf_mixed(cfg, seed):
    """PREFETCH and SEQUENTIAL commands back to back on the same buffers."""
    p = P(cfg, seed)
    for i in range(6):
        p.gemm(p.rng.randrange(1, 20), p.rng.randrange(1, 20), p.rng.randrange(1, 150),
               flags=FL_PF if i % 2 == 0 else 0, kc=p.rng.choice([0, 0, 9, 31]))
    return p, {}


def qparams(p: Prog, K: int):
    scale = Fraction(p.rng.randrange(1, 1000), 1000) / (K * 40)
    m, s = __import__("tq_ref").quantize_multiplier(scale)
    return m & 0xFFFF_FFFF, s


def t_quant(cfg, seed):
    """INT8 requantised output: every rounding mode, ReLU, output zero-points, saturation, unaligned C rows."""
    p = P(cfg, seed)
    for rm in range(5):
        K = p.rng.randrange(1, 90)
        m, s = qparams(p, K)
        p.gemm(p.rng.randrange(1, 14), p.rng.randrange(1, 14), K, ofmt=A.OFMT_INT8, rm=rm, qmult=m, qshift=s,
               qzp=p.rng.randrange(-20, 21) & 0xFF, relu=p.rng.randrange(2), ldc=None)
    p.gemm(9, 11, 40, ofmt=A.OFMT_INT8, qmult=0x7FFF_FFFF, qshift=20, qzp=0, ldc=13, c_off=1)          # saturates
    p.gemm(6, 5, 70, ofmt=A.OFMT_INT8, qmult=(-12345) & 0xFFFF_FFFF, qshift=17, qzp=(-7) & 0xFF, relu=1)
    p.gemm(17, 13, 29, ofmt=A.OFMT_INT8, qmult=1 << 30, qshift=40, qzp=3, ldc=17, c_off=3)
    p.gemm(8, 8, 8)                                                                                      # INT32 too
    p.gemm(4, 4, 200, ofmt=A.OFMT_INT8, qmult=1, qshift=0, qzp=0)                                        # identity + sat
    return p, {}


def t_quant_mixed(cfg, seed):
    p = P(cfg, seed)
    for i in range(6):
        K = p.rng.randrange(1, 140)
        if i % 2:
            p.gemm(p.rng.randrange(1, 18), p.rng.randrange(1, 18), K)
        else:
            m, s = qparams(p, K)
            p.gemm(p.rng.randrange(1, 18), p.rng.randrange(1, 18), K, ofmt=A.OFMT_INT8, rm=p.rng.randrange(5),
                   qmult=m, qshift=s, qzp=p.rng.randrange(-128, 128) & 0xFF, relu=p.rng.randrange(2),
                   flags=FL_PF if p.cfg.dbuf and p.rng.randrange(2) else 0)
    return p, {}


def t_fault(cfg, seed):
    """Fault injection (FAULT_INJ = 1): (1) operand fills redirected into a set the DMA does not own -> TC03
    refuses (OWNER) -> BUF_ACCESS, DETAIL 6; (2) output-buffer reads redirected into a set the DMA does not own
    -> refused -> BUF_ACCESS; (3) TC04 told an overflowing K -> STRICT_RANGE refusal -> ACC_OVF.  After each, the
    soft-reset datapath executes a clean GEMM."""
    p = P(cfg, seed)
    p.op("E 1")
    for mode, exp in ((1, dict(err=A.E_BUF_ACCESS, detail=6, count=0, tiles=0)),
                      (3, dict(err=A.E_BUF_ACCESS, count=0, tiles=0)),
                      (2, dict(err=A.E_ACC_OVF, detail=A.IE_ACC_RANGE, count=0, tiles=0))):
        p.sync()
        p.op(f"F {mode}")
        exp.update(status=A.ST_ERROR, err_addr=None, detail=exp.get("detail"))
        p.gemm(8, 8, 20, flags=FL_PF if mode != 2 else 0, expect=exp, executes=False)
        p.sync()
        p.op("F 0")
        p.gemm(8, 8, 20, flags=FL_PF)
    return p, {}


# ============================================================================= catalogue
#   name -> (function, stage, [configurations], [memory profiles], seeds, xbar)
TESTS = {
    "g4x4x4":        (t_g4x4x4, 1, ["base"], ["lat1"], 1, 0),
    "g1x1x1":        (t_g1x1x1, 1, ["base"], ["lat1"], 1, 0),
    "shapes":        (t_shapes, 2, ["base", "mo1"], ["lat1", "lat8", "rand"], 2, 0),
    "shapes_nmajor": (t_shapes_nmajor, 2, ["base"], ["lat1", "rand"], 1, 0),
    "tiles_large":   (t_tiles_large, 2, ["base"], ["lat1", "rand"], 1, 0),
    "kchunk_long":   (t_kchunk_long, 2, ["base"], ["lat1"], 1, 0),
    "extreme":       (t_extreme, 2, ["base"], ["lat1"], 1, 0),
    "b2b":           (t_b2b, 2, ["base", "mo1"], ["lat1", "rand"], 2, 0),
    "invalid":       (t_invalid, 2, ["base"], ["lat1"], 1, 0),
    "dma_errors":    (t_dma_errors, 2, ["base", "mo1"], ["lat1", "rand"], 1, 0),
    "stop_continue": (t_stop_continue, 2, ["base"], ["lat1"], 1, 0),
    "irq":           (t_irq, 2, ["base"], ["lat1"], 1, 0),
    "reset":         (t_reset, 2, ["base"], ["lat1", "rand"], 6, 0),
    "abort":         (t_abort, 2, ["base"], ["lat1", "rand"], 6, 0),
    "contention":    (t_contention, 2, ["base"], ["lat1"], 2, 1),
    "watchdog":      (t_watchdog, 2, ["wd"], ["lat1"], 1, 0),
    # ---- stage 3: advanced features, each in its own configuration
    "dbuf_shapes":   (t_dbuf_shapes, 3, ["dbuf", "full"], ["lat1", "rand"], 1, 0),
    "dbuf_mixed":    (t_dbuf_mixed, 3, ["dbuf"], ["lat1", "rand"], 3, 0),
    "dbuf_b2b":      (t_b2b, 3, ["dbuf"], ["rand"], 1, 0),
    "dbuf_reset":    (t_reset, 3, ["dbuf"], ["rand"], 3, 0),
    "dbuf_abort":    (t_abort, 3, ["dbuf"], ["rand"], 3, 0),
    "dbuf_errors":   (t_dma_errors, 3, ["dbuf"], ["lat1"], 1, 0),
    "dbuf_contention": (t_contention, 3, ["dbuf"], ["lat1"], 1, 1),
    "quant":         (t_quant, 3, ["quant", "full"], ["lat1", "rand"], 2, 0),
    "quant_mixed":   (t_quant_mixed, 3, ["quant", "full"], ["lat1"], 3, 0),
    "quant_invalid": (t_invalid, 3, ["quant", "full"], ["lat1"], 1, 0),
    "a8_shapes":     (t_shapes, 3, ["a8"], ["lat1", "rand"], 1, 0),
    "a8_quant":      (t_quant_mixed, 3, ["a8"], ["lat1"], 2, 0),
    "a8_b2b":        (t_b2b, 3, ["a8"], ["lat1"], 1, 0),
    "a2_shapes":     (t_shapes, 3, ["a2"], ["lat1", "rand"], 1, 0),
    "a2_quant":      (t_quant_mixed, 3, ["a2"], ["lat1"], 1, 0),
    "tk16_shapes":   (t_shapes, 3, ["tk16"], ["lat1", "rand"], 1, 0),
    "tk16_invalid":  (t_invalid, 3, ["tk16"], ["lat1"], 1, 0),
    "tk16_b2b":      (t_b2b, 3, ["tk16"], ["lat1"], 1, 0),
    "fault":         (t_fault, 3, ["fi"], ["lat1", "rand"], 1, 0),
}
