"""Test-program builder for tb/tb_tsu.sv.

A Prog owns a random initial memory image, places matrices in it, emits host operations (prog.txt) and records
what the hardware must produce (expect.json):

  groups  ordered list; each group is consumed from the record stream in order:
            exact   every command produces exactly its expected record
            prefix  the last group before a hard reset: the records are a prefix of the expected ones
            abort   records match the expected OK record until the first ABORTED one; every later record of
                    the group is SKIPPED / ABORTED
  per command: expected record fields (None = not checked), C bytes it writes when it completes OK, and the
               C footprint, which becomes don't-care when the command did not complete OK after starting
  dontcare     global byte intervals not checked (e.g. the competing master's window)
  perf         expected counter totals (only for programs without reset / abort / execution errors)

Commands are executed strictly in order by the hardware, so expected results are computed on a golden copy of
memory in program order (a command may read what an earlier one wrote).
"""
from __future__ import annotations

import json
import random
from pathlib import Path

import tsu_abi as A
from tsu_ref import Gemm, HwCfg, gemm_result, nop, traffic, validate

BASE = 0x1000_0000
MEM_BYTES = 1 << 20


class Prog:
    def __init__(self, cfg: HwCfg, seed: int, mem_bytes: int = MEM_BYTES):
        self.cfg = cfg
        self.rng = random.Random(seed)
        self.mem_bytes = mem_bytes
        self.init = bytearray(self.rng.getrandbits(8) for _ in range(mem_bytes))
        self.gold = bytearray(self.init)
        self.top = BASE + 0x100
        self.ops: list[str] = []
        self.groups: list[dict] = [dict(kind="exact", cmds=[])]
        self.dontcare: list[list[int]] = []
        self.tid = 0
        self.perf_ok = True
        self.perf = dict(gemm_ok=0, tiles=0, chunks=0, macs=0, desc=0, rd=0, wr=0, records=0, errs=0, sat=0)
        self.plus: dict = {}
        self.gemms: list[dict] = []
        self.nrec = 0                      # records expected since the last hard reset
        self.err_cont = False              # CTRL.ERR_CONT as programmed
        self.sticky = False                # the unit's sticky error (stop-on-error state)

    # ------------------------------------------------------------------ memory
    def alloc(self, size: int, align: int = 1, gap: int | None = None) -> int:
        gap = self.rng.randrange(0, 61) if gap is None else gap
        a = self.top + gap
        a = (a + align - 1) // align * align
        self.top = a + size
        assert self.top <= BASE + self.mem_bytes - 64, "test does not fit in the memory model"
        return a

    def fill(self, addr: int, data: bytes):
        o = addr - BASE
        self.init[o:o + len(data)] = data
        self.gold[o:o + len(data)] = data

    def matrix_i8(self, rows: int, cols: int, ld: int, mode: str = "rand", align: int = 1, addr: int | None = None):
        size = (rows - 1) * ld + cols
        if addr is None:
            addr = self.alloc(size, align)
        for r in range(rows):
            if mode == "rand":
                row = bytes(self.rng.getrandbits(8) for _ in range(cols))
            elif mode == "min":
                row = bytes([0x80] * cols)
            elif mode == "max":
                row = bytes([0x7F] * cols)
            elif mode == "small":
                row = bytes(self.rng.randrange(-4, 5) & 0xFF for _ in range(cols))
            else:
                raise ValueError(mode)
            self.fill(addr + r * ld, row)
        return addr

    # ------------------------------------------------------------------ host operations
    def op(self, s: str):
        self.ops.append(s)
        t = s.split()
        if t[0] == "X":
            self.nrec, self.sticky, self.err_cont = 0, False, False
        elif t[0] == "E":
            self.err_cont = t[1] != "0"
        elif t[0] == "K":
            self.sticky = False
        # "A": an abort that hits a running command leaves the sticky error set (ERROR record); every test
        # that can abort running work clears it with K, and an abort while idle sets nothing

    def sync(self):
        """Wait until every command submitted so far has produced its record."""
        self.op(f"S {self.nrec}")

    def new_group(self, kind: str):
        if self.groups[-1]["cmds"] or self.groups[-1]["kind"] != "exact":
            self.groups.append(dict(kind=kind, cmds=[]))
        else:
            self.groups[-1]["kind"] = kind

    def submit(self, g: Gemm, expect: dict | None = None, executes: bool | None = None):
        """Submit g; the expected record follows from validation unless `expect` overrides fields.
        executes=False: the command is expected not to complete OK (execution error) -> its C is don't-care."""
        g.tid = self.tid & 0xFF if g.tid == 0 else g.tid
        self.tid += 1
        w = g.words()
        self.op("C " + " ".join(f"{x:08x}" for x in w))
        code = validate(w, self.cfg)
        rec = dict(tid=w[0] >> 24, op=w[0] & 0xFF, err=code, status=A.ST_OK if code == A.E_NONE else A.ST_ERROR,
                   irq=(w[0] >> (16 + A.FL_IRQ)) & 1, sat=0, detail=0, count=0, err_addr=0, tiles=0)
        cmd = dict(rec=rec, c=[], dc=[], gemm=None)
        if self.sticky and not self.err_cont:              # stop-on-error: not executed
            rec.update(err=A.E_PRIOR, status=A.ST_SKIPPED)
            if expect:
                rec.update(expect)
            self.perf["records"] += 1
            self.perf["errs"] += 1
            self.nrec += 1
            self.groups[-1]["cmds"].append(cmd)
            return g
        if code == A.E_NONE and g.opcode == A.OP_GEMM:
            res, sat = gemm_result(self.gold, BASE, g)
            t = traffic(g, self.cfg)
            esz = g.esz
            rec.update(sat=int(sat), count=g.m * g.n * esz, tiles=t["tiles"])
            cmd["c"] = sorted(res.items())
            cmd["dc"] = [[g.c + r * g.ldc, g.c + r * g.ldc + g.n * esz] for r in range(g.m)]
            cmd["gemm"] = dict(m=g.m, n=g.n, k=g.k, flags=g.flags, ofmt=g.ofmt, **t)
            if executes is not False:
                for a, v in res.items():
                    self.gold[a - BASE] = v
                for key in ("tiles", "macs", "desc", "rd", "wr"):
                    self.perf[key] += t[key]
                self.perf["chunks"] += t["jobs"]
                self.perf["gemm_ok"] += 1
                self.perf["sat"] += 0
            self.gemms.append(dict(m=g.m, n=g.n, k=g.k, flags=g.flags, ofmt=g.ofmt, macs=t["macs"]))
        if code != A.E_NONE:
            self.perf["errs"] += 1
        if expect:
            rec.update(expect)
        if executes is False:
            self.perf_ok = False
            if not cmd["dc"] and g.opcode == A.OP_GEMM:
                cmd["dc"] = [[g.c + r * g.ldc, g.c + r * g.ldc + g.n * g.esz] for r in range(g.m)]
            for lo, hi in cmd["dc"]:
                pass                                   # C stays don't-care; gold keeps the old bytes
        self.perf["records"] += 1
        self.nrec += 1
        if rec["status"] == A.ST_ERROR:
            self.sticky = True
        self.groups[-1]["cmds"].append(cmd)
        return g

    def gemm(self, M: int, N: int, K: int, lda=None, ldb=None, ldc=None, kc=0, flags=0, a_mode="rand",
             b_mode="rand", ofmt=A.OFMT_INT32, rm=0, relu=0, qmult=0, qshift=0, qzp=0, a_align=1, b_align=1,
             c_align=None, c_off=0, expect=None, executes=None, submit=True, **kw) -> Gemm:
        lda = K if lda is None else lda
        ldb = N if ldb is None else ldb
        esz = 1 if ofmt == A.OFMT_INT8 else 4
        ldc = esz * N if ldc is None else ldc
        a = self.matrix_i8(M, K, lda, a_mode, a_align)
        b = self.matrix_i8(K, N, ldb, b_mode, b_align)
        c = self.alloc((M - 1) * ldc + esz * N + c_off, c_align if c_align else (4 if esz == 4 else 1)) + c_off
        g = Gemm(a, b, c, M, N, K, lda, ldb, ldc, kc=kc, flags=flags, ofmt=ofmt, rm=rm, relu=relu, qmult=qmult,
                 qshift=qshift, qzp=qzp, **kw)
        if submit:
            self.submit(g, expect=expect, executes=executes)
        return g

    def nop(self, flags=0, raw=None, expect=None):
        return self.submit(nop(flags=flags, raw=raw), expect=expect)

    # ------------------------------------------------------------------ output
    def write(self, out: Path, meta: dict | None = None):
        out.mkdir(parents=True, exist_ok=True)
        with open(out / "mem_init.hex", "w") as f:
            for i in range(0, self.mem_bytes, 16):
                f.write(" ".join(f"{b:02x}" for b in self.init[i:i + 16]) + "\n")
        (out / "prog.txt").write_text("\n".join(self.ops + ["Q"]) + "\n")
        exp = dict(base=BASE, mem_bytes=self.mem_bytes, groups=self.groups, dontcare=self.dontcare,
                   perf=self.perf if self.perf_ok else None, plus=self.plus, cfg=self.cfg.__dict__, meta=meta or {},
                   gemms=self.gemms)
        (out / "expect.json").write_text(json.dumps(exp))
        (out / "mem_gold.bin").write_bytes(bytes(self.gold))
