"""Coexistence programs for tb/tb_system.sv: tensor GEMMs and HPC tile FP32 KERNEL commands submitted
interleaved, so the two units run concurrently on the shared SRAM through the DataFabric crossbar, while the
host CPU port issues its own traffic.

Expected tile results: D[i] = fp32(A[i] op B[i]) for FADD / FMUL, computed in binary64 and rounded once to binary32
(round to nearest even).  For + and x on binary32 operands this double rounding is innocuous (53 >= 2*24 + 2),
so the expectation is exact.  Operands are normal numbers well inside the range (no NaN / Inf / subnormal).
"""
from __future__ import annotations

import struct

import tsu_abi as A
from prog import BASE, Prog
from tsu_ref import HwCfg

SPM_BASE = 0x2000_0000
VOP = {"FADD": 0x01, "FMUL": 0x03}


def f32_bytes(x: float) -> bytes:
    return struct.pack("<f", x)


def f32(x: float) -> float:
    return struct.unpack("<f", struct.pack("<f", x))[0]


def tile_kernel(p: Prog, vl: int, op: str, tag: int):
    a = p.alloc(4 * vl, 4)
    b = p.alloc(4 * vl, 4)
    d = p.alloc(4 * vl, 4)
    av = [f32(p.rng.uniform(-1000, 1000) * 2.0 ** p.rng.randrange(-20, 20)) for _ in range(vl)]
    bv = [f32(p.rng.uniform(-1000, 1000) * 2.0 ** p.rng.randrange(-20, 20)) for _ in range(vl)]
    p.fill(a, b"".join(f32_bytes(x) for x in av))
    p.fill(b, b"".join(f32_bytes(x) for x in bv))
    res = [x + y if op == "FADD" else x * y for x, y in zip(av, bv)]
    out = b"".join(f32_bytes(x) for x in res)
    for i, v in enumerate(out):
        p.extra.append([d + i, v])
        p.gold[d + i - BASE] = v
    w0 = 3 | (VOP[op] << 4) | (0 << 9) | ((tag & 0xFF) << 16)          # KERNEL, RNE
    words = [w0, vl, 0, a, b, 0, d, SPM_BASE]
    p.op("H " + " ".join(f"{x:08x}" for x in words))
    p.tile_expect.append(dict(tag=tag & 0xFF, status=0, type=3, count=vl))


def system_prog(seed: int, n_rounds: int = 3) -> Prog:
    cfg = HwCfg(quant=1, dbuf=1)
    p = Prog(cfg, seed)
    p.extra, p.tile_expect = [], []
    cpu = p.alloc(2048, 4096)
    p.dontcare.append([cpu, cpu + 2048])
    p.plus["cpu_lo"] = f"{cpu:x}"
    tag = 0
    for r in range(n_rounds):
        tile_kernel(p, p.rng.randrange(64, 700), p.rng.choice(["FADD", "FMUL"]), tag); tag += 1
        p.gemm(17, 13, 29, lda=31, ldb=17, ldc=13 * 4 + 12, flags=1 << A.FL_PREFETCH)
        tile_kernel(p, p.rng.randrange(64, 700), p.rng.choice(["FADD", "FMUL"]), tag); tag += 1
        p.gemm(32, 32, 128, flags=(1 << A.FL_PREFETCH) if r % 2 == 0 else 0)
        k = p.rng.randrange(20, 120)
        p.gemm(p.rng.randrange(3, 20), p.rng.randrange(3, 20), k, ofmt=A.OFMT_INT8, rm=p.rng.randrange(5),
               qmult=p.rng.randrange(1 << 28, 1 << 30), qshift=p.rng.randrange(30, 40), qzp=p.rng.randrange(256),
               relu=p.rng.randrange(2))
        tile_kernel(p, p.rng.randrange(64, 700), p.rng.choice(["FADD", "FMUL"]), tag); tag += 1
    # the tensor unit cannot reach the tile scratchpad: its window is the SRAM only (validation, no bus access)
    from tsu_ref import Gemm
    p.submit(Gemm(SPM_BASE, SPM_BASE + 0x100, SPM_BASE + 0x200, 4, 4, 4, 4, 4, 16))
    return p
