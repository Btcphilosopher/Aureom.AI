#!/usr/bin/env python3
"""Check one tb_tsu run directory against its expect.json.

  * records: every field the reference predicts (TID, OPCODE, ERR_CODE, STATUS, IRQ, SAT, DETAIL, COUNT, ERR_ADDR,
    SEQ, TILES), per group kind (exact / prefix before a hard reset / abort race), CYCLES > 0 for executed commands
  * memory: the WHOLE final memory image.  Expected = the initial image, plus the C bytes of every command whose
    record says OK, applied in program order; only the C footprint of a command that started and did not complete
    OK (execution error, abort, destroyed by a reset) and the global don't-care windows are excluded
  * counters: exact totals (GEMMs, tiles, chunks, MACs, descriptors, SFB2 word reads / writes, records) whenever
    the program has no reset, abort or execution error
  * the simulator log: RESULT PASS and no $error / ERROR line
Prints one JSON line and exits 0 on PASS.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import tsu_abi as A  # noqa: E402
from tsu_ref import rec_fields  # noqa: E402

FIELDS = ("tid", "op", "err", "status", "irq", "sat", "detail", "count", "err_addr", "tiles")


def load_records(d: Path):
    segs, cur = [], []
    for line in (d / "records.txt").read_text().splitlines():
        t = line.split()
        if not t:
            continue
        if t[0] == "X":
            segs.append(cur)
            cur = []
        elif t[0] == "R":
            cur.append(rec_fields([int(x, 16) for x in t[1:7]]))
    segs.append(cur)
    return segs


def load_mem(path: Path, n: int) -> bytearray:
    out = bytearray()
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("//"):
            continue
        out.extend(int(x, 16) for x in line.split())
    assert len(out) == n, f"{path.name}: {len(out)} bytes, expected {n}"
    return out


def match(exp: dict, got: dict) -> list[str]:
    return [f"{k}: got {got[k]:#x} expected {exp[k]:#x}" for k in FIELDS if exp.get(k) is not None and got[k] != exp[k]]


def is_aborted(r):
    return r["err"] == A.E_ABORTED and r["status"] in (A.ST_ERROR, A.ST_SKIPPED)


def check(d: Path) -> dict:
    exp = json.loads((d / "expect.json").read_text())
    fails: list[str] = []
    log = (d / "sim.log").read_text(errors="replace") if (d / "sim.log").exists() else ""
    if "RESULT PASS" not in log:
        fails.append("testbench did not report RESULT PASS")
    for line in log.splitlines():
        if ("ERROR" in line or "%Error" in line or "error:" in line.lower()) and "RESULT" not in line:
            fails.append("log: " + line.strip()[:200])
            break
    try:
        segs = load_records(d)
    except FileNotFoundError:
        return dict(ok=False, fails=fails + ["no records.txt"])
    base, nbytes = exp["base"], exp["mem_bytes"]
    init = load_mem(d / "mem_init.hex", nbytes)
    expmem = bytearray(init)
    care = bytearray([1]) * nbytes

    def dontcare(lo, hi):
        for a in range(max(lo, base), min(hi, base + nbytes)):
            care[a - base] = 0

    def apply(cmd):
        for a, v in cmd["c"]:
            expmem[a - base] = v
            care[a - base] = 1

    si, ri = 0, 0                     # segment, record index inside the segment
    seq_in_seg = 0
    n_ok_gemm = 0
    for gi, grp in enumerate(exp["groups"]):
        kind, cmds = grp["kind"], grp["cmds"]
        if si >= len(segs):
            fails.append(f"group {gi}: no record segment left")
            break
        seg = segs[si]
        if kind == "prefix":
            got = seg[ri:]
            if len(got) > len(cmds):
                fails.append(f"group {gi}: {len(got)} records before the reset, at most {len(cmds)} expected")
            for i, cmd in enumerate(cmds):
                if i < len(got):
                    m = match(cmd["rec"], got[i])
                    if got[i]["seq"] != seq_in_seg:
                        m.append(f"seq {got[i]['seq']} expected {seq_in_seg}")
                    seq_in_seg += 1
                    if m:
                        fails.append(f"group {gi} cmd {i} (before reset): " + "; ".join(m))
                    if got[i]["status"] == A.ST_OK:
                        apply(cmd)
                        n_ok_gemm += cmd["gemm"] is not None
                else:
                    for lo, hi in cmd["dc"]:   # destroyed by the reset, may have written part of C
                        dontcare(lo, hi)
            si += 1
            ri = 0
            seq_in_seg = 0
            continue
        got = seg[ri:ri + len(cmds)]
        ri += len(cmds)
        if len(got) < len(cmds):
            fails.append(f"group {gi}: {len(got)} records, {len(cmds)} expected")
        aborted = False
        for i, cmd in enumerate(cmds):
            if i >= len(got):
                break
            r = got[i]
            if r["seq"] != seq_in_seg:
                fails.append(f"group {gi} cmd {i}: seq {r['seq']} expected {seq_in_seg}")
            seq_in_seg += 1
            if kind == "abort" and (aborted or is_aborted(r)):
                if not is_aborted(r):
                    fails.append(f"group {gi} cmd {i}: record after an aborted one is not SKIPPED/ABORTED")
                if aborted and r["status"] != A.ST_SKIPPED:
                    fails.append(f"group {gi} cmd {i}: second aborted record must be SKIPPED")
                if r["status"] == A.ST_ERROR:
                    for lo, hi in cmd["dc"]:
                        dontcare(lo, hi)
                aborted = True
                continue
            m = match(cmd["rec"], r)
            if m:
                fails.append(f"group {gi} cmd {i}: " + "; ".join(m))
            if r["status"] == A.ST_OK and cmd["gemm"] is not None:
                if r["cycles"] == 0:
                    fails.append(f"group {gi} cmd {i}: CYCLES = 0")
                apply(cmd)
                n_ok_gemm += 1
            elif r["status"] == A.ST_ERROR and cmd["rec"]["err"] >= 0x18:
                for lo, hi in cmd["dc"]:
                    dontcare(lo, hi)
    if si < len(segs) and ri < len(segs[si]):
        fails.append(f"{len(segs[si]) - ri} unexpected extra records")
    for lo, hi in exp["dontcare"]:
        dontcare(lo, hi)
    for a, v in exp.get("extra", []):          # results of other units (system test)
        expmem[a - base] = v
        care[a - base] = 1

    if not (d / "mem_final.hex").exists():
        fails.append("no final memory image: the simulation did not finish")
        return dict(ok=False, fails=fails[:12], n_records=sum(len(s) for s in segs), ok_gemms=n_ok_gemm, cycles=None,
                    perf={})
    final = load_mem(d / "mem_final.hex", nbytes)
    bad = [i for i in range(nbytes) if care[i] and final[i] != expmem[i]]
    if bad:
        a = bad[0]
        fails.append(f"memory: {len(bad)} bytes differ, first at {base + a:#x}: got {final[a]:02x} expected "
                     f"{expmem[a]:02x} (initial {init[a]:02x})")

    perf = {}
    pf = d / "perf.txt"
    if pf.exists():
        for line in pf.read_text().splitlines():
            k, v = line.split()
            perf[k] = int(v)
    if exp["perf"] is not None and perf:
        p = exp["perf"]
        want = {A.PC_GEMM_OK: p["gemm_ok"], A.PC_TILES: p["tiles"], A.PC_CHUNKS: p["chunks"], A.PC_MACS: p["macs"],
                A.PC_DESC: p["desc"], A.PC_RD_WORDS: p["rd"], A.PC_WR_WORDS: p["wr"], A.PC_CMD_DONE: p["records"],
                A.PC_CMD_ACCEPT: p["records"], A.PC_ABORTS: 0}
        for idx, v in want.items():
            if perf.get(str(idx)) != v:
                fails.append(f"counter {idx}: {perf.get(str(idx))} expected {v}")
    return dict(ok=not fails, fails=fails[:12], n_records=sum(len(s) for s in segs), ok_gemms=n_ok_gemm,
                cycles=perf.get("cycles"), perf={k: v for k, v in perf.items()})


if __name__ == "__main__":
    res = check(Path(sys.argv[1]))
    print(json.dumps(res))
    sys.exit(0 if res["ok"] else 1)
