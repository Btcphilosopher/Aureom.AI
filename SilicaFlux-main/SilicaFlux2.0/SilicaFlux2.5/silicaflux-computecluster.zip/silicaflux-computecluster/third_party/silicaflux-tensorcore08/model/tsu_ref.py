"""Independent reference model of silicaflux_tensor_unit (TENSORCORE 08).

* GEMM descriptor encoding (ABI VERSION 2, rtl/tsu_defs.svh via the generated model/tsu_abi.py)
* validation rules, in the hardware's order, written from the ABI document (not from the RTL)
* the GEMM contract: exact INT32 C = A x B with plain Python integers; INT8 output through
  TENSORCORE 05's own element() reference (third_party/silicaflux-tensorcore05/model/tq_ref.py)
* the tile schedule and the exact SFB2 traffic it implies (word reads / writes, descriptors, MACs),
  used to check the hardware performance counters
"""
from __future__ import annotations

import sys
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "model"))
sys.path.insert(0, str(ROOT / "third_party" / "silicaflux-tensorcore05" / "model"))
import tsu_abi as A  # noqa: E402
import tq_ref  # noqa: E402

MASK32 = 0xFFFF_FFFF


def s8(v: int) -> int:
    return v - 256 if v >= 128 else v


# ----------------------------------------------------------------------------- hardware configuration
@dataclass
class HwCfg:
    rows: int = 4
    cols: int = 4
    tile_k: int = 64
    opbuf: int = 2048
    banks: int = 4
    quant: int = 0
    dbuf: int = 0
    max_out: int = 4
    k_max: int = 131071
    mem_lo: int = 0x1000_0000
    mem_hi: int = 0x1010_0000          # 1 MiB window = the testbench memory
    cmdq: int = 4
    cplq: int = 4
    wdog: int = 16
    fault: int = 0

    def gparams(self) -> list[str]:
        return [f"-GARRAY_ROWS={self.rows}", f"-GARRAY_COLS={self.cols}", f"-GTILE_K={self.tile_k}",
                f"-GOPERAND_BUFFER_BYTES={self.opbuf}", f"-GNUM_MEMORY_BANKS={self.banks}",
                f"-GENABLE_QUANTIZATION={self.quant}", f"-GENABLE_DOUBLE_BUFFERING={self.dbuf}",
                f"-GMAX_OUT={self.max_out}", f"-GK_MAX={self.k_max}", f"-GCMD_QUEUE_DEPTH={self.cmdq}",
                f"-GCPL_QUEUE_DEPTH={self.cplq}", f"-GWDOG_LOG2={self.wdog}", f"-GFAULT_INJ={self.fault}"]

    def key(self) -> str:
        return (f"r{self.rows}c{self.cols}k{self.tile_k}b{self.opbuf}n{self.banks}q{self.quant}d{self.dbuf}"
                f"o{self.max_out}km{self.k_max}cq{self.cmdq}{self.cplq}w{self.wdog}f{self.fault}")


# ----------------------------------------------------------------------------- descriptor
@dataclass
class Gemm:
    a: int
    b: int
    c: int
    m: int
    n: int
    k: int
    lda: int
    ldb: int
    ldc: int
    kc: int = 0
    tid: int = 0
    flags: int = 0
    ofmt: int = A.OFMT_INT32
    rm: int = 0
    relu: int = 0
    qmult: int = 0
    qshift: int = 0
    qzp: int = 0
    a_type: int = 0
    b_type: int = 0
    a_lay: int = 0
    b_lay: int = 0
    c_lay: int = 0
    opcode: int = A.OP_GEMM
    version: int = A.ABI_VERSION
    raw: dict = field(default_factory=dict)      # word index -> value override (invalid-command tests)

    def words(self) -> list[int]:
        w = [0] * A.DESC_WORDS
        w[0] = (self.opcode & 0xFF) | ((self.version & 0xF) << 8) | ((self.rm & 7) << 12) | \
               ((self.flags & 0xFF) << 16) | ((self.tid & 0xFF) << 24)
        if self.opcode != A.OP_NOP:
            w[1], w[2], w[3] = self.a & MASK32, self.b & MASK32, self.c & MASK32
            w[4] = (self.m & 0xFFFF) | ((self.n & 0xFFFF) << 16)
            w[5] = (self.k & 0x1FFFF) | ((self.kc & 0x7FFF) << 17)
            w[6], w[7], w[8] = self.lda & MASK32, self.ldb & MASK32, self.ldc & MASK32
            w[9] = (self.a_type & 3) | ((self.b_type & 3) << 2) | ((self.ofmt & 3) << 4) | ((self.a_lay & 3) << 8) | \
                   ((self.b_lay & 3) << 10) | ((self.c_lay & 3) << 12) | ((self.relu & 1) << 14)
            w[10] = self.qmult & MASK32
            w[11] = (self.qshift & 0x3F) | ((self.qzp & 0xFF) << 8)
        for i, v in self.raw.items():
            w[i] = v & MASK32
        return w

    @property
    def esz(self) -> int:
        return 1 if self.ofmt == A.OFMT_INT8 else 4


def nop(tid=0, flags=0, raw=None) -> Gemm:
    return Gemm(0, 0, 0, 0, 0, 0, 0, 0, 0, tid=tid, flags=flags, opcode=A.OP_NOP, raw=raw or {})


# ----------------------------------------------------------------------------- validation (first failing rule)
def validate(w: list[int], cfg: HwCfg) -> int:
    op, ver, rm = w[0] & 0xFF, (w[0] >> 8) & 0xF, (w[0] >> 12) & 7
    h15, flags = (w[0] >> 15) & 1, (w[0] >> 16) & 0xFF
    if ver != A.ABI_VERSION:
        return A.E_VERSION
    if op not in (A.OP_NOP, A.OP_GEMM):
        return A.E_OPCODE
    if op == A.OP_NOP:
        if flags & ~((1 << A.FL_IRQ) | (1 << A.FL_BARRIER)) & 0xFF:
            return A.E_FLAGS
        if h15 or rm or any(w[1:]):
            return A.E_RSVD
        return A.E_NONE
    if (flags & ~A.FL_MASK & 0xFF) or ((flags >> A.FL_PREFETCH) & 1 and not cfg.dbuf):
        return A.E_FLAGS
    ofmt = (w[9] >> 4) & 3
    relu = (w[9] >> 14) & 1
    rsvd = h15 or (w[9] & A.W9_RSVD_MASK) or (w[11] & A.W11_RSVD_MASK)
    if ofmt == A.OFMT_INT32 and (rm or relu or w[10] or w[11]):
        rsvd = True
    if rsvd:
        return A.E_RSVD
    int8 = ofmt == A.OFMT_INT8
    if int8 and rm > A.RM_RMM:
        return A.E_RM
    if any((w[9] >> s) & 3 for s in (8, 10, 12)):
        return A.E_LAYOUT
    if (w[9] & 3) or ((w[9] >> 2) & 3) or not (ofmt == A.OFMT_INT32 or (int8 and cfg.quant)):
        return A.E_PRECISION
    a, b, c = w[1], w[2], w[3]
    m, n, k, kc = w[4] & 0xFFFF, w[4] >> 16, w[5] & 0x1FFFF, w[5] >> 17
    lda, ldb, ldc = w[6], w[7], w[8]
    if m == 0 or n == 0 or k == 0:
        return A.E_DIM_ZERO
    if k > cfg.k_max:
        return A.E_DIM_RANGE
    kce = kc if kc else cfg.tile_k
    if kc > cfg.tile_k or -(-k // kce) > 65535:
        return A.E_CHUNK
    esz = 1 if int8 else 4
    if lda < k or ldb < n or ldc < esz * n:
        return A.E_LD
    if not int8 and (c & 3 or ldc & 3):
        return A.E_ALIGN
    al, bl, cl = a + (m - 1) * lda + k - 1, b + (k - 1) * ldb + n - 1, c + (m - 1) * ldc + esz * n - 1
    if max(al, bl, cl) >= 1 << 32:
        return A.E_ADDR_OVF
    if any(lo < cfg.mem_lo or hi >= cfg.mem_hi for lo, hi in ((a, al), (b, bl), (c, cl))):
        return A.E_RANGE
    if (c <= al and a <= cl) or (c <= bl and b <= cl):
        return A.E_ALIAS
    return A.E_NONE


# ----------------------------------------------------------------------------- GEMM contract
def lda_loc(ek: int) -> int:
    r4 = (ek + 3) & ~3
    return r4 if (r4 >> 2) & 1 else r4 + 4


def schedule(g: Gemm, cfg: HwCfg):
    """The tile sequence: list of (m0, n0, k0, eff_m, eff_n, eff_k, last_k)."""
    kc = g.kc if g.kc else cfg.tile_k
    tm, tn = cfg.rows, cfg.cols
    nmajor = (g.flags >> A.FL_NMAJOR) & 1
    tiles = [(m0, n0) for m0 in range(0, g.m, tm) for n0 in range(0, g.n, tn)]
    if nmajor:
        tiles = [(m0, n0) for n0 in range(0, g.n, tn) for m0 in range(0, g.m, tm)]
    steps = []
    for m0, n0 in tiles:
        for k0 in range(0, g.k, kc):
            steps.append((m0, n0, k0, min(tm, g.m - m0), min(tn, g.n - n0), min(kc, g.k - k0), k0 + kc >= g.k))
    return steps


def words_touched(addr: int, length: int) -> int:
    return ((addr + length - 1) >> 2) - (addr >> 2) + 1


def traffic(g: Gemm, cfg: HwCfg) -> dict:
    """Exact SFB2 traffic of a successful command: TC07 reads only words holding transfer bytes and writes
    each destination word once per row (byte strobes for partial words)."""
    rd = wr = desc = macs = tiles = jobs = 0
    for m0, n0, k0, em, en, ek, lastk in schedule(g, cfg):
        for r in range(em):
            rd += words_touched(g.a + (m0 + r) * g.lda + k0, ek)
        for r in range(ek):
            rd += words_touched(g.b + (k0 + r) * g.ldb + n0, en)
        desc += 2
        jobs += 1
        macs += em * en * ek
        if lastk:
            desc += 1
            tiles += 1
            for r in range(em):
                wr += words_touched(g.c + (m0 + r) * g.ldc + n0 * g.esz, en * g.esz)
    return dict(rd=rd, wr=wr, desc=desc, macs=macs, tiles=tiles, jobs=jobs)


def gemm_result(mem: bytearray, base: int, g: Gemm):
    """Expected C bytes {address: byte} and the SAT flag, from the INITIAL memory image."""
    def A_(m, k):
        return s8(mem[g.a - base + m * g.lda + k])

    def B_(k, n):
        return s8(mem[g.b - base + k * g.ldb + n])

    Bc = [[B_(k, n) for k in range(g.k)] for n in range(g.n)]
    out, sat = {}, False
    for m in range(g.m):
        arow = [A_(m, k) for k in range(g.k)]
        for n in range(g.n):
            acc = sum(x * y for x, y in zip(arow, Bc[n]))
            assert -(1 << 31) <= acc < (1 << 31), "INT32 accumulation overflow: the validation bound is wrong"
            if g.ofmt == A.OFMT_INT8:
                zp = s8(g.qzp)
                mult = g.qmult - (1 << 32) if g.qmult & 0x8000_0000 else g.qmult
                q, s, _ = tq_ref.element(acc, mult=mult, shift=g.qshift, zp=zp, rq=True, ofmt=tq_ref.OFMT_INT8,
                                         relu=bool(g.relu), rm=g.rm)
                sat |= s
                out[g.c + m * g.ldc + n] = q & 0xFF
            else:
                v = acc & MASK32
                for i in range(4):
                    out[g.c + m * g.ldc + 4 * n + i] = (v >> (8 * i)) & 0xFF
    return out, sat


def footprint(g: Gemm, which: str):
    """Byte intervals [lo, hi) of the rows of a matrix footprint."""
    if which == "c":
        return [(g.c + r * g.ldc, g.c + r * g.ldc + g.n * g.esz) for r in range(g.m)]
    raise ValueError(which)


# ----------------------------------------------------------------------------- completion record
def rec_fields(r: list[int]) -> dict:
    w0 = r[0]
    return dict(tid=w0 & 0xFF, op=(w0 >> 8) & 0xFF, err=(w0 >> 16) & 0xFF, status=(w0 >> 24) & 3,
                irq=(w0 >> 26) & 1, sat=(w0 >> 27) & 1, detail=(w0 >> 28) & 0xF, count=r[1], err_addr=r[2],
                seq=r[3], cycles=r[4], tiles=r[5])
