# third_party — additions of Project 32

`PROVENANCE.md` and `SHA256SUMS` are TENSORCORE 08's own files, copied unchanged with its `third_party/` tree.
Every source file still matches them (`sha256sum -c SHA256SUMS`). The single exception is an entry for a Python
bytecode cache (`silicaflux-tensorcore05/model/__pycache__/tq_ref.cpython-313.pyc`), which the TENSORCORE 08
archive itself does not contain; the check fails the same way on the original archive. Project 32 vendors these files in addition, again
byte for byte (checked with `cmp` against the archives in `btcphilosopher/Aureom.AI`):

| Directory / file | Source archive | Content used |
|---|---|---|
| `silicaflux-tensorcore08/rtl/`, `model/`, `integration/`, `README.md` | `SilicaFlux-main/silicaflux-tensorcore08.zip` | `silicaflux_tensor_unit` and its RTL (the tensor engine); the independent reference model (`tsu_ref.py`, `tsu_abi.py`, ...) used to build this project's GEMM expectations; the coexistence wrapper (reference only, not compiled) |
| `silicaflux-datafabric/rtl/interconnect/sfb_reg_slice.sv`, `sfb_skid_buffer.sv` | `SilicaFlux-main/silicaflux-datafabric.zip` | NoC-facing pipeline boundaries, command-ingress and completion-egress register stages |

`SHA256SUMS_P32` lists every file under `third_party/` as delivered.
