#!/usr/bin/env python3
"""Render an OpenROAD placement dump (placement.txt: name x1 y1 x2 y2 master region) as SVG.

Every dot is a placed instance read back from the OpenROAD database (sampled for file size); rectangles are the
proposed regions of plan.json.  Nothing is drawn from the RTL hierarchy alone.
Usage: plot_placement.py <placement.txt> <plan.json> <out.svg> <title>
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

COLORS = {"SFX_VEC0": "#1f77b4", "SFX_VEC1": "#17becf", "SFX_VEC2": "#2ca02c", "SFX_VEC3": "#98df8a",
          "SFX_VEC4": "#393b79", "SFX_VEC5": "#6b6ecf", "SFX_VEC6": "#637939", "SFX_VEC7": "#b5cf6b",
          "SFX_TSU0": "#d62728", "SFX_TSU1": "#ff7f0e", "SFX_TSU2": "#e377c2", "SFX_TSU3": "#bcbd22",
          "SFX_CTRL": "#9467bd", "SFX_NOC": "#8c564b"}


def main():
    pl, plan_p, out, title = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), sys.argv[4]
    plan = json.loads(plan_p.read_text())
    regs = plan["regions"]
    die = [v * 1000 for v in plan["die_um"]]
    W, H = die[2] - die[0], die[3] - die[1]
    S = 900.0 / max(W, H)
    pts = {}
    step = 0
    for line in pl.read_text().splitlines():
        t = line.split()
        if len(t) < 7:
            continue
        step += 1
        if step % 25:
            continue                                         # 1 in 25 instances
        x, y = (int(t[1]) + int(t[3])) / 2, (int(t[2]) + int(t[4])) / 2
        owner = next((r["name"] for r in regs if any(t[0].startswith(p) for p in r["prefixes"])), None)
        pts.setdefault(owner, []).append((x, y))
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{W * S + 220:.0f}" height="{H * S + 40:.0f}" '
         f'font-family="sans-serif" font-size="11">',
         f'<rect x="0" y="0" width="{W * S + 220:.0f}" height="{H * S + 40:.0f}" fill="white"/>',
         f'<text x="4" y="14" font-size="12">{title}</text>',
         f'<rect x="0" y="20" width="{W * S:.1f}" height="{H * S:.1f}" fill="none" stroke="#000"/>']

    def tx(x):
        return (x - die[0]) * S

    def ty(y):
        return 20 + (die[3] - y) * S

    for owner, ps in pts.items():
        c = COLORS.get(owner, "#999999")
        for x, y in ps:
            o.append(f'<circle cx="{tx(x):.1f}" cy="{ty(y):.1f}" r="0.6" fill="{c}"/>')
    for r in regs:
        x1, y1, x2, y2 = r["box_dbu"]
        c = COLORS.get(r["name"], "#000")
        o.append(f'<rect x="{tx(x1):.1f}" y="{ty(y2):.1f}" width="{(x2 - x1) * S:.1f}" height="{(y2 - y1) * S:.1f}" '
                 f'fill="none" stroke="{c}" stroke-width="1.5" stroke-dasharray="5,3"/>')
        o.append(f'<text x="{tx(x1) + 3:.1f}" y="{ty(y2) + 12:.1f}" fill="{c}">{r["name"]}</text>')
    yl = 30
    for name, c in COLORS.items():
        if name in pts:
            o.append(f'<rect x="{W * S + 10:.0f}" y="{yl}" width="10" height="10" fill="{c}"/>'
                     f'<text x="{W * S + 25:.0f}" y="{yl + 9}">{name} ({len(pts[name]) * 25:,} inst.)</text>')
            yl += 16
    o.append(f'<text x="{W * S + 10:.0f}" y="{yl + 14}">dots: 1 in 25 placed instances</text>')
    o.append(f'<text x="{W * S + 10:.0f}" y="{yl + 28}">dashed: proposed regions</text>')
    o.append("</svg>")
    out.write_text("\n".join(o))


if __name__ == "__main__":
    main()
