"""SilicaFlux Project 32 — region / instance-group generator and placement measurement.

Regions are a PROPOSAL derived from measured cell area (sky130hd `stat -liberty` of the mapped netlist) and a target
utilization, arranged on a template that expresses the locality rules of docs/04_TIMING_AND_LOCALITY.md:

            ┌──────────────┬────────────────────┬──────────────┐
            │ SFX_VEC0     │ SFX_TSU0           │ SFX_VEC1     │   vector clusters: outer columns (their memory /
            │ u_vector_0   │ u_tensor_0         │ u_vector_1   │   local-memory ports face the centre)
            ├──────────────┼─────────┬──────────┼──────────────┤
            │ ...          │SFX_CTRL │ SFX_NOC  │ ...          │   centre column: tensor clusters on the NoC axis,
            │              │ u_regs  │ u_noc    │              │   the crossbar (u_noc + u_ext_slice) in the middle,
            │              │ u_cmd_* │ u_ext_*  │              │   shell control (u_regs, u_cmd_route, u_cpl_arb)
            ├──────────────┼─────────┴──────────┼──────────────┤   beside it
            │ SFX_VEC2     │ SFX_TSU1           │ SFX_VEC3     │
            └──────────────┴────────────────────┴──────────────┘
Every coordinate is computed here from the netlist's measured area; nothing is hard-coded in RTL.  The template
is a starting point for floorplanning, not a validated floorplan.
"""
from __future__ import annotations

import json
import math
import re
from collections import defaultdict
from pathlib import Path

DBU = 1000                      # sky130hd LEF database units per micron
SITE_W, ROW_H = 0.46, 2.72


def liberty_areas(lib: Path) -> dict[str, float]:
    txt = lib.read_text(errors="replace")
    out = {}
    for m in re.finditer(r'cell\s*\(\s*"?([\w$]+)"?\s*\)\s*\{(.*?)\barea\s*:\s*([0-9.]+)', txt, re.S):
        out[m.group(1)] = float(m.group(3))
    return out


def _blackbox(m: dict) -> bool:
    return str(m.get("attributes", {}).get("blackbox", "0")).lstrip("0") != ""


def region_areas(netlist_json: Path, lib: Path) -> dict:
    """Cell area (um^2) and cell count of every top-level instance, from the hierarchical mapped netlist."""
    la = liberty_areas(lib)
    nl = json.loads(netlist_json.read_text())
    mods = {n: m for n, m in nl["modules"].items() if not _blackbox(m)}     # liberty cells are leaves
    memo: dict[str, tuple[float, int]] = {}

    def tot(m):
        if m in memo:
            return memo[m]
        a, n = 0.0, 0
        for c in mods[m]["cells"].values():
            if c["type"] in mods:
                sa, sn = tot(c["type"])
                a, n = a + sa, n + sn
            else:
                a, n = a + la.get(c["type"], 0.0), n + 1
        memo[m] = (a, n)
        return memo[m]

    top = next(n for n, m in mods.items() if str(m.get("attributes", {}).get("top", "0")).lstrip("0") in ("1",))
    res = {}
    ga, gn = 0.0, 0
    for cn, c in mods[top]["cells"].items():
        if c["type"] in mods:
            a, n = tot(c["type"])
            res[cn] = dict(area_um2=round(a, 1), cells=n)
        else:
            ga, gn = ga + la.get(c["type"], 0.0), gn + 1
    res["(top-level glue)"] = dict(area_um2=round(ga, 1), cells=gn)
    return res


def _snap(v: float, g: float) -> float:
    return round(v / g) * g


def plan(areas: dict, cfg: dict, util: float = 0.45, margin_um: float = 20.0) -> dict:
    nv, nt = cfg["params"].get("NUM_VECTOR_CLUSTERS", 1), cfg["params"].get("NUM_TENSOR_CLUSTERS", 1)
    A = lambda names: sum(areas.get(n, {}).get("area_um2", 0.0) for n in names) / util  # noqa: E731
    vec = [f"u_vector_{k}" for k in range(nv)]
    tsu = [f"u_tensor_{j}" for j in range(nt)]
    left, right = vec[0::2], vec[1::2]
    ctrl, noc = ["u_regs", "u_cmd_route", "u_cpl_arb"], ["u_noc", "u_ext_slice"]
    glue = areas.get("(top-level glue)", {}).get("area_um2", 0.0) / util
    total = sum(A([v]) for v in vec) + sum(A([t]) for t in tsu) + A(ctrl) + A(noc) + glue
    H = math.sqrt(total)                                   # square-ish core
    wl = A(left) / H if left else 0.0
    wr = A(right) / H if right else 0.0
    wc = (sum(A([t]) for t in tsu) + A(ctrl) + A(noc) + glue) / H
    core_w, core_h = wl + wc + wr, H
    regions = []

    def stack(names, x0, w, tags):
        """stack regions vertically in a column, heights proportional to area"""
        tot = sum(A(n) for n in names) or 1.0
        y = 0.0
        for n, tg in zip(names, tags):
            h = core_h * A(n) / tot
            regions.append(dict(name=tg, prefixes=[p + "/" for p in n], box_um=[x0, y, x0 + w, y + h]))
            y += h

    stack([[v] for v in left], 0.0, wl, [f"SFX_VEC{v.split('_')[-1]}" for v in left])
    stack([[v] for v in right], wl + wc, wr, [f"SFX_VEC{v.split('_')[-1]}" for v in right])
    # centre column: tensor 0 (top), NoC + control (middle), tensor 1 (bottom), further tensors alternate
    top_t, bot_t = tsu[0::2], tsu[1::2]
    mid = A(ctrl) + A(noc) + glue
    col = [("t", t) for t in top_t] + [("mid", None)] + [("t", t) for t in reversed(bot_t)]
    colA = [A([t]) if k == "t" else mid for k, t in col]
    y = core_h
    for (k, t), a in zip(col, colA):
        h = core_h * a / sum(colA)
        y0 = y - h
        if k == "t":
            regions.append(dict(name=f"SFX_TSU{t.split('_')[-1]}", prefixes=[t + "/"], box_um=[wl, y0, wl + wc, y]))
        else:
            fc = A(ctrl) / max(A(ctrl) + A(noc), 1e-9)
            xm = wl + wc * max(0.25, min(0.5, fc + 0.1))
            regions.append(dict(name="SFX_CTRL", prefixes=[c + "/" for c in ctrl], box_um=[wl, y0, xm, y]))
            regions.append(dict(name="SFX_NOC", prefixes=[n + "/" for n in noc], box_um=[xm, y0, wl + wc, y]))
        y = y0
    # snap to the row / site grid, shift into the core (core origin = margin)
    for r in regions:
        x1, y1, x2, y2 = r["box_um"]
        r["box_um"] = [round(_snap(x1, SITE_W) + margin_um, 2), round(_snap(y1, ROW_H) + margin_um, 2),
                       round(_snap(x2, SITE_W) + margin_um, 2), round(_snap(y2, ROW_H) + margin_um, 2)]
        r["box_dbu"] = [int(round(v * DBU)) for v in r["box_um"]]
        r["target_util"] = util
        r["cell_area_um2"] = round(sum(areas.get(p[:-1], {}).get("area_um2", 0.0) for p in r["prefixes"]), 1)
    cw, ch = _snap(core_w, SITE_W) + SITE_W, _snap(core_h, ROW_H) + ROW_H
    return dict(util=util, core_um=[margin_um, margin_um, round(margin_um + cw, 2), round(margin_um + ch, 2)],
                die_um=[0, 0, round(2 * margin_um + cw, 2), round(2 * margin_um + ch, 2)], regions=regions,
                note="proposal from measured sky130hd cell area / target utilization; not a validated floorplan")


def subgroups(netlist_json: Path) -> list[dict]:
    """Instance groups (locality inside a cluster) from the ACTUAL instance names of the mapped netlist."""
    nl = json.loads(netlist_json.read_text())
    mods = {n: m for n, m in nl["modules"].items() if not _blackbox(m)}
    top = next(n for n, m in mods.items() if str(m.get("attributes", {}).get("top", "0")).lstrip("0") in ("1",))

    def children(m):
        return {cn: c["type"] for cn, c in mods[m]["cells"].items() if c["type"] in mods}

    groups = []
    for inst, ty in sorted(children(top).items()):
        if not inst.startswith(("u_vector_", "u_tensor_")) or not children(ty):
            continue
        k = inst.split("_")[-1]
        kind = "VEC" if inst.startswith("u_vector_") else "TSU"
        sub = children(ty)                                        # g_cl.u_tile / g_cl.u_tsu / g_cl.u_ctrl / ...
        eng = next((s for s in sub if s.endswith(("u_tile", "u_tsu"))), None)
        ctrl = [f"{inst}/{s}/" for s in sub if s.endswith(("u_ctrl", "u_rst"))]
        nocif = [f"{inst}/{s}/" for s in sub if s.endswith(("u_mem_slice", "u_lm_slice", "u_upsize"))]
        if eng:
            inner = children(sub[eng])
            path = f"{inst}/{eng}/"
            if kind == "VEC":
                # HPC M08 tile instance names (silicaflux_hpc_tile.sv): u_array (M03 vector array), u_lsu,
                # u_spm (M04 scratchpad), u_dma (M05 adapter), *.u_hs (host-window port), u_regs, u_sched,
                # u_cmdq, u_cplq, *.u_perf
                core = [path + s + "/" for s in inner if s.endswith(("u_array", "u_spm", "u_lsu"))]
                dma = [path + s + "/" for s in inner if s.endswith(("u_dma", "u_hs"))]
                qctl = [path + s + "/" for s in inner if s.endswith(("u_regs", "u_sched", "u_cmdq", "u_cplq", "u_perf"))]
                groups.append(dict(name=f"{kind}{k}_LANES_SPM", prefixes=core,
                                   why="vector lanes next to their local scratchpad and load/store unit"))
                groups.append(dict(name=f"{kind}{k}_DMA_NOCIF", prefixes=dma + nocif,
                                   why="DMA engine and memory-port slice on the NoC-facing edge"))
                groups.append(dict(name=f"{kind}{k}_CTRL", prefixes=qctl + ctrl,
                                   why="command / completion queues, scheduler, register page, local control"))
            else:
                dp = children(inner["u_dp"]) if "u_dp" in inner else {}
                dpp = f"{path}u_dp/"
                arr = [dpp + s + "/" for s in dp if s.endswith(("u_arr", "u_tob", "u_acc", "u_sa", "u_q", "u_seq"))]
                dma = [dpp + s + "/" for s in dp if s.endswith(("u_dma", "u_ob", "u_gate"))]
                qctl = [path + s + "/" for s in inner if s != "u_dp"]
                groups.append(dict(name=f"{kind}{k}_ARRAY_BUFFERS", prefixes=arr,
                                   why="systolic array next to its operand buffers and accumulator storage"))
                groups.append(dict(name=f"{kind}{k}_DMA_NOCIF", prefixes=dma + nocif,
                                   why="tensor DMA, output buffer and memory-port slice on the NoC-facing edge"))
                groups.append(dict(name=f"{kind}{k}_CTRL", prefixes=qctl + ctrl,
                                   why="queues, scheduler, register page, local control"))
    return [g for g in groups if g["prefixes"]]


def write_tcl(p: dict, regions_tcl: Path, groups_tcl: Path, netlist_json: Path):
    lines = ["# SilicaFlux Project 32 :: PROPOSED placement regions — generated by physical/gen_regions.py",
             f"# {p['note']}",
             f"# target utilization {p['util']}; die {p['die_um']} um; core {p['core_um']} um",
             "# Instance names are the ACTUAL names of the sky130hd-mapped netlist as OpenROAD flattens it",
             "# (hierarchy separator '/').  Region type: odb INCLUSIVE (members must be placed inside).",
             "# Tool: OpenROAD 2.0-12331-g6011bbe77 (no create_region command: odb dbRegion API).",
             "set SFX_REGIONS {"]
    for r in p["regions"]:
        x1, y1, x2, y2 = r["box_dbu"]
        lines.append(f"  {{{r['name']} {{{' '.join(r['prefixes'])}}} {x1} {y1} {x2} {y2}}}")
    lines += ["}",
              "# one pass over the instances: longest matching hierarchical prefix (path components split on '/')",
              "proc sfx_prefix_dict {spec} {",
              "  set d [dict create]",
              "  foreach e $spec { foreach p [lindex $e 1] { dict set d $p [lindex $e 0] } }",
              "  return $d",
              "}",
              "proc sfx_owner {d iname} {",
              "  set best \"\"; set acc \"\"",
              "  foreach c [lrange [split $iname /] 0 end-1] { append acc $c /; if {[dict exists $d $acc]} { set best [dict get $d $acc] } }",
              "  return $best",
              "}",
              "proc sfx_apply_regions {block} {",
              "  global SFX_REGIONS",
              "  set d [sfx_prefix_dict $SFX_REGIONS]",
              "  foreach r $SFX_REGIONS {",
              "    lassign $r name prefixes x1 y1 x2 y2",
              "    set reg($name) [odb::dbRegion_create $block $name]",
              "    odb::dbBox_create $reg($name) $x1 $y1 $x2 $y2",
              "    set n($name) 0",
              "  }",
              "  foreach inst [$block getInsts] {",
              "    set o [sfx_owner $d [$inst getName]]",
              "    if {$o ne \"\"} { $reg($o) addInst $inst; incr n($o) }",
              "  }",
              "  foreach r $SFX_REGIONS {",
              "    set name [lindex $r 0]",
              "    puts \"SFX_REGION $name instances $n($name) box {[lrange $r 2 5]}\"",
              "    if {$n($name) == 0} { puts \"SFX_REGION_ERROR $name matched no instance\" }",
              "  }",
              "}"]
    regions_tcl.write_text("\n".join(lines) + "\n")
    gs = subgroups(netlist_json)
    gl = ["# SilicaFlux Project 32 :: instance groups (odb dbGroup, PHYSICAL_CLUSTER) — generated by gen_regions.py",
          "# Locality groups inside each cluster, from the ACTUAL instance names.  They carry no coordinates:",
          "# they name what should stay together for downstream floorplanning (exported in DEF GROUPS).",
          "if {[info procs sfx_owner] eq \"\"} {",
          "  proc sfx_prefix_dict {spec} { set d [dict create]; foreach e $spec { foreach p [lindex $e 1] { dict set d $p [lindex $e 0] } }; return $d }",
          "  proc sfx_owner {d iname} { set best \"\"; set acc \"\"; foreach c [lrange [split $iname /] 0 end-1] { append acc $c /; if {[dict exists $d $acc]} { set best [dict get $d $acc] } }; return $best }",
          "}",
          "set SFX_GROUPS {"]
    for g in gs:                                                   # a '#' inside a braced list is not a comment
        gl.insert(gl.index("set SFX_GROUPS {"), f"#   {g['name']}: {g['why']}")
    for g in gs:
        gl.append(f"  {{{g['name']} {{{' '.join(g['prefixes'])}}}}}")
    gl += ["}",
           "proc sfx_apply_groups {block} {",
           "  global SFX_GROUPS",
           "  set d [sfx_prefix_dict $SFX_GROUPS]",
           "  foreach g $SFX_GROUPS { set name [lindex $g 0]; set grp($name) [odb::dbGroup_create $block $name]; set n($name) 0 }",
           "  foreach inst [$block getInsts] {",
           "    set o [sfx_owner $d [$inst getName]]",
           "    if {$o ne \"\"} { $grp($o) addInst $inst; incr n($o) }",
           "  }",
           "  foreach g $SFX_GROUPS { set name [lindex $g 0]; puts \"SFX_GROUP $name instances $n($name)\" }",
           "}",
           "# NOTE (measured, docs/07): in OpenROAD 2.0-12331 detailed_placement becomes exhaustive when region-less",
           "# PHYSICAL_CLUSTER groups exist; apply the groups for DEF export / other tools, not before dpl in this build."]
    groups_tcl.write_text("\n".join(gl) + "\n")


def measure(placement_txt: Path, p: dict) -> dict:
    """Containment of every region's members in its proposed box, foreign instances inside it, cluster spread."""
    regs = p["regions"]
    stats = {r["name"]: dict(members=0, inside=0, foreign_inside=0, bbox=[1 << 60, 1 << 60, -1, -1], sx=0, sy=0)
             for r in regs}
    unassigned = 0
    for line in placement_txt.read_text().splitlines():
        t = line.split()
        if len(t) < 7:
            continue
        name, x1, y1, x2, y2 = t[0], int(t[1]), int(t[2]), int(t[3]), int(t[4])
        owner = next((r for r in regs if any(name.startswith(pp) for pp in r["prefixes"])), None)
        cx, cy = (x1 + x2) // 2, (y1 + y2) // 2
        for r in regs:
            bx1, by1, bx2, by2 = r["box_dbu"]
            inside = bx1 <= x1 and by1 <= y1 and x2 <= bx2 and y2 <= by2
            s = stats[r["name"]]
            if owner is r:
                s["members"] += 1
                s["inside"] += inside
                b = s["bbox"]
                b[0], b[1], b[2], b[3] = min(b[0], x1), min(b[1], y1), max(b[2], x2), max(b[3], y2)
                s["sx"] += cx
                s["sy"] += cy
            elif inside:
                s["foreign_inside"] += 1
        if owner is None:
            unassigned += 1
    out = []
    for r in regs:
        s = stats[r["name"]]
        n = max(s["members"], 1)
        b = s["bbox"]
        bx1, by1, bx2, by2 = r["box_dbu"]
        out.append(dict(region=r["name"], members=s["members"], inside=s["inside"],
                        inside_pct=round(100.0 * s["inside"] / n, 2), foreign_inside=s["foreign_inside"],
                        spread_bbox_um2=round(max(0, b[2] - b[0]) * max(0, b[3] - b[1]) / DBU / DBU, 1),
                        region_area_um2=round((bx2 - bx1) * (by2 - by1) / DBU / DBU, 1),
                        centroid_um=[round(s["sx"] / n / DBU, 1), round(s["sy"] / n / DBU, 1)]))
    return dict(regions=out, unassigned_instances=unassigned)
