read_lef $::env(SFX_PLAT)/lef/sky130_fd_sc_hd.tlef
read_lef $::env(SFX_PLAT)/lef/sky130_fd_sc_hd_merged.lef
read_liberty $::env(SFX_PLAT)/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog regtest.v
link_design regtest
initialize_floorplan -die_area {0 0 600 600} -core_area {10 10 590 590} -site unithd
source $::env(SFX_PLAT)/make_tracks.tcl
set block [ord::get_db_block]
# region boxes (DBU): block A top-right, block B bottom-left (opposite corners on purpose)
set boxes {{u_blk_a/ 340000 340000 580000 580000} {u_blk_b/ 20000 20000 260000 260000}}
set mode seeded
set k 0
foreach b $boxes {
  lassign $b pfx x1 y1 x2 y2
  if {$mode eq "seeded"} {
    set cx [expr ($x1 + $x2) / 2]; set cy [expr ($y1 + $y2) / 2]
    foreach inst [$block getInsts] { if {[string first $pfx [$inst getName]] == 0} { $inst setLocation $cx $cy; $inst setPlacementStatus PLACED } }
  } elseif {$mode eq "odb_region"} {
    set r [odb::dbRegion_create $block R$k]
    odb::dbBox_create $r $x1 $y1 $x2 $y2
    foreach inst [$block getInsts] { if {[string first $pfx [$inst getName]] == 0} { $r addInst $inst } }
  } elseif {$mode eq "voltage_domain"} {
    create_voltage_domain VD$k -area [list [expr $x1/1000.0] [expr $y1/1000.0] [expr $x2/1000.0] [expr $y2/1000.0]]
    set g [$block findGroup VD$k]
    foreach inst [$block getInsts] { if {[string first $pfx [$inst getName]] == 0} { $g addInst $inst } }
  }
  incr k
}
proc dump {block boxes tag} {
  foreach b $boxes {
    lassign $b pfx x1 y1 x2 y2
    set n 0; set in 0
    foreach inst [$block getInsts] {
      if {[string first $pfx [$inst getName]] != 0} continue
      incr n
      set bb [$inst getBBox]
      if {[$bb xMin] >= $x1 && [$bb yMin] >= $y1 && [$bb xMax] <= $x2 && [$bb yMax] <= $y2} { incr in }
    }
    puts "SFX_RESULT $tag $pfx members $n inside $in"
  }
}
global_placement -density 0.6 -skip_io -skip_initial_place
dump $block $boxes after_global_placement
detailed_placement
dump $block $boxes after_detailed_placement
set ok [catch {check_placement} msg]
puts "SFX_RESULT check_placement ok=[expr {!$ok}] $msg"
