#!/usr/bin/env python3
"""Controlled test: does this OpenROAD build honour placement regions?

Two copies of one mapped block (the shell's completion arbiter from the phys_hpc sky130hd netlist, 4 729 cells each)
in a 600 x 600 um die, one region per copy in OPPOSITE corners; containment is measured after global and after
detailed placement for five mechanisms (physical/region_test/<mode>.tcl): plain odb dbRegion, create_voltage_domain,
no constraint, odb dbRegion + region-less PHYSICAL_CLUSTER dbGroup, and members seeded at the region centre.
Writes build/phys/regtest/<mode>.log and summary.txt (copied to reports/physical/region_support_test/).
"""
import os
import re
import shutil
import subprocess
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
D = ROOT / "build" / "phys" / "regtest"
MODES = ["odb_region", "voltage_domain", "none", "odb_region_groups", "seeded"]
TIMEOUT = {"odb_region_groups": 600}          # exhaustive detailed placement in this build: bounded on purpose


def extract():
    v = (ROOT / "build" / "phys" / "phys_hpc" / "netlist.v").read_text()
    mods = {m.group(1): m.group(0) for m in re.finditer(r"^module (\S+) \(.*?^endmodule", v, re.M | re.S)}
    name = next(n for n in mods if n.startswith("sfx_cpl_arbiter"))
    ports = re.findall(r"^\s*(input|output)\s+(\[\d+:\d+\]\s+)?(\w+)\s*;", mods[name], re.M)
    decl, ca, cb = [], [], []
    for d, w, n in ports:
        for i in ("a", "b"):
            decl.append(f"  {d} {(w or '').strip()} {i}_{n};")
        ca.append(f".{n}(a_{n})")
        cb.append(f".{n}(b_{n})")
    top = ("module regtest(" + ", ".join(f"{i}_{n}" for d, w, n in ports for i in ("a", "b")) + ");\n" +
           "\n".join(decl) + f"\n  {name} u_blk_a ({', '.join(ca)});\n  {name} u_blk_b ({', '.join(cb)});\nendmodule\n")
    need, i = [name], 0
    while i < len(need):
        for sub in set(re.findall(r"^\s+(\w+)\s+\S+\s*\(", mods[need[i]], re.M)):
            if sub in mods and sub not in need:
                need.append(sub)
        i += 1
    (D / "regtest.v").write_text("\n".join(mods[m] for m in need) + "\n" + top)


def run(mode):
    shutil.copy(ROOT / "physical" / "region_test" / f"{mode}.tcl", D / f"{mode}.tcl")
    env = dict(os.environ, SFX_PLAT="/opt/eda/orfs/flow/platforms/sky130hd")
    with open(D / f"{mode}.log", "w") as lf:
        try:
            subprocess.run(["/opt/eda/env/bin/openroad", "-no_init", "-threads", "1", "-exit", f"{mode}.tcl"], cwd=D,
                           stdout=lf, stderr=subprocess.STDOUT, env=env, timeout=TIMEOUT.get(mode, 1800))
        except subprocess.TimeoutExpired:
            lf.write(f"\nSFX_TIMEOUT stopped after {TIMEOUT.get(mode)} s\n")


def main():
    D.mkdir(parents=True, exist_ok=True)
    extract()
    with ThreadPoolExecutor(3) as ex:
        list(ex.map(run, MODES))
    lines = [f"{m}: " + "|".join(re.findall(r"SFX_RESULT.*|SFX_TIMEOUT.*", (D / f"{m}.log").read_text())) for m in MODES]
    (D / "summary.txt").write_text("\n".join(lines) + "\n")
    out = ROOT / "reports" / "physical" / "region_support_test"
    out.mkdir(parents=True, exist_ok=True)
    for m in MODES:
        shutil.copy(D / f"{m}.log", out / f"{m}.log")
        shutil.copy(D / f"{m}.tcl", out / f"{m}.tcl")
    shutil.copy(D / "summary.txt", out / "summary.txt")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
