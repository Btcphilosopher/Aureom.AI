#!/usr/bin/env python3
"""Collect every physical-experiment result into reports/physical/summary.json (input of scripts/make_report.py)."""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "physical"))
import gen_regions  # noqa: E402

LIB = Path("/opt/eda/orfs/flow/platforms/sky130hd/lib/sky130_fd_sc_hd__tt_025C_1v80.lib")
B = ROOT / "build" / "phys"
R = ROOT / "reports" / "physical"


def load(p):
    return json.loads(p.read_text()) if p.exists() else None


def main():
    out = {}
    plan = json.loads((ROOT / "physical" / "phys_hpc" / "plan.json").read_text())
    cfg = json.loads((ROOT / "configs" / "phys_hpc.json").read_text())
    out["config"] = cfg["params"]
    out["areas"] = gen_regions.region_areas(B / "phys_hpc" / "netlist.json", LIB)
    m = re.search(r"Chip area for top module '\\\\?(\S+)':\s+([0-9.]+)", (B / "phys_hpc" / "stat_liberty.txt").read_text())
    out["chip_cell_area_um2"] = float(m.group(2)) if m else None
    out["plan"] = plan
    out["constraints_check"] = load(R / "phys_hpc_constraints_check.json")
    # small controlled experiment: does the tool honour the constraints?
    rt = {}
    for mode in ("odb_region", "voltage_domain", "none", "odb_region_groups", "seeded"):
        f = B / "regtest" / f"{mode}.log"
        if not f.exists():
            continue
        t = f.read_text(errors="replace")
        rt[mode] = dict(
            after_gpl=[int(x) for x in re.findall(r"after_global_placement \S+ members \d+ inside (\d+)", t)],
            after_dpl=[int(x) for x in re.findall(r"after_detailed_placement \S+ members \d+ inside (\d+)", t)],
            members=[int(x) for x in re.findall(r"after_global_placement \S+ members (\d+)", t)],
            avg_disp=re.findall(r"average displacement\s+([0-9.]+)", t), max_disp=re.findall(r"max displacement\s+([0-9.]+)", t),
            check_placement=("ok=1" if "check_placement ok=1" in t else ("FAILED " + " ".join(sorted(set(re.findall(r"DPL-00\d\d", t)))))
                             if "check_placement ok=0" in t else
                             ("detailed placement unfinished after 600 s (bounded run)" if "SFX_TIMEOUT" in t else "not reached")))
    out["region_support_test"] = rt
    # full design, control placement
    ctl = B / "phys_hpc" / "no_regions"
    if not (ctl / "placement.txt").exists():
        ctl = B / "phys_hpc" / "no_regions_p"          # the run used for reports/ (started in parallel, same script)
    t = (ctl / "openroad.log").read_text(errors="replace")
    out["control"] = dict(
        check_placement_ok="SFX_CHECK_PLACEMENT ok=1" in t,
        gpl_overflow=re.findall(r"Finished with Overflow: ([0-9.]+)", t),
        legalized_hpwl=re.findall(r"legalized HPWL\s+([0-9.]+)", t),
        dpl_avg_disp=re.findall(r"average displacement\s+([0-9.]+)", t),
        containment=gen_regions.measure(ctl / "placement.txt", plan))
    out["full_with_regions"] = dict(
        status="stopped in detailed_placement after 44 CPU-minutes (Opendp::place -> mapMove -> diamondSearch, "
               "gdb stack sample); regions + region-less PHYSICAL_CLUSTER groups applied before placement; the "
               "small test odb_region_groups reproduces the same exhaustive detailed placement")
    out["timing"] = {}
    for tag, f in (("all_slices", ctl / "post_sta.json"),
                   ("no_slices", B / "phys_hpc_noslice" / "no_regions" / "post_sta.json")):
        r = load(f)
        if r:
            out["timing"][tag] = {k: r[k] for k in ("wns_ns", "tns_ns", "period_ns", "check_placement_ok", "repair_design",
                                                    "n_paths", "n_crossing", "worst_by_region_pair", "area_line",
                                                    "interfaces")}
            out["timing"][tag]["worst_data_paths"] = r["worst_data_paths"][:8]
            out["timing"][tag]["worst_crossing_data"] = [p for p in r["worst_crossing"] if p["group"] != "asynchronous"][:8]
    R.mkdir(parents=True, exist_ok=True)
    (R / "summary.json").write_text(json.dumps(out, indent=1))
    print(json.dumps({k: v for k, v in out.items() if k in ("region_support_test", "timing")}, indent=1)[:4000])


if __name__ == "__main__":
    main()
