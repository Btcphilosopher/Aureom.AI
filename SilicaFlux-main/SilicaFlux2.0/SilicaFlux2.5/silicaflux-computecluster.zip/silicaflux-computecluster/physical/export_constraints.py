#!/usr/bin/env python3
"""Apply physical/<cfg>/regions.tcl + groups.tcl to the mapped netlist in OpenROAD and export DEF REGIONS / GROUPS.

Proves that the delivered constraints load on the real instance names (member count per region / group) and gives
the DEF sections other tools import.  No placement.  Usage: export_constraints.py <cfg>
"""
import json
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PLAT = Path("/opt/eda/orfs/flow/platforms/sky130hd")
cfg = sys.argv[1] if len(sys.argv) > 1 else "phys_hpc"
d = (ROOT / "build" / "phys" / cfg).resolve()
pdir = (ROOT / "physical" / cfg).resolve()
plan = json.loads((pdir / "plan.json").read_text())
out = d / "export"
out.mkdir(exist_ok=True)
tcl = f"""
read_lef {PLAT}/lef/sky130_fd_sc_hd.tlef
read_lef {PLAT}/lef/sky130_fd_sc_hd_merged.lef
read_liberty {PLAT}/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_verilog {d}/netlist.v
link_design silicaflux_compute_cluster
initialize_floorplan -die_area {{{' '.join(map(str, plan['die_um']))}}} -core_area {{{' '.join(map(str, plan['core_um']))}}} -site unithd
set SFX_CFG_DIR {pdir}
set t0 [clock milliseconds]
source {ROOT}/physical/apply_constraints.tcl
puts "SFX_APPLY_MS [expr [clock milliseconds] - $t0]"
write_def {out}/floorplan_constraints.def
"""
(out / "export.tcl").write_text(tcl)
with open(out / "export.log", "w") as lf:
    subprocess.run(["/opt/eda/env/bin/openroad", "-no_init", "-exit", str(out / "export.tcl")], cwd=out, stdout=lf,
                   stderr=subprocess.STDOUT)
log = (out / "export.log").read_text(errors="replace")
dtext = (out / "floorplan_constraints.def").read_text(errors="replace") if (out / "floorplan_constraints.def").exists() else ""
regions = re.search(r"^REGIONS .*?^END REGIONS", dtext, re.M | re.S)
groups = re.search(r"^GROUPS .*?^END GROUPS", dtext, re.M | re.S)
rep = ROOT / "reports" / "physical"
rep.mkdir(parents=True, exist_ok=True)
excerpt = "# DEF sections written by OpenROAD 2.0-12331 after physical/apply_constraints.tcl (no placement)\n"
excerpt += (regions.group(0) if regions else "# no REGIONS section") + "\n\n"
# the GROUPS section lists every member instance: keep the group headers and the first members only
if groups:
    g_lines = groups.group(0).splitlines()
    kept, cnt = [], 0
    for line in g_lines:
        if line.lstrip().startswith("- ") or line.startswith(("GROUPS", "END GROUPS")) or line.strip().startswith("+"):
            kept.append(line); cnt = 0
        else:
            cnt += 1
            if cnt <= 3:
                kept.append(line)
            elif cnt == 4:
                kept.append("      ... (members elided in this excerpt)")
    excerpt += "\n".join(kept) + "\n"
(rep / f"{cfg}_regions_groups.def").write_text(excerpt)
res = dict(cfg=cfg, regions=re.findall(r"SFX_REGION (\S+) instances (\d+)", log),
           groups=re.findall(r"SFX_GROUP (\S+) instances (\d+)", log),
           region_errors=re.findall(r"SFX_REGION_ERROR.*", log), apply_ms=re.findall(r"SFX_APPLY_MS (\d+)", log),
           summary=re.findall(r"SFX_CONSTRAINTS.*", log), def_regions=bool(regions), def_groups=bool(groups))
(rep / f"{cfg}_constraints_check.json").write_text(json.dumps(res, indent=1))
print(json.dumps(res, indent=1))
