#!/usr/bin/env python3
"""SilicaFlux Project 32 — physical-integration experiment (exploratory, NOT a floorplan sign-off).

  1. synth   : Yosys 0.33 maps a REDUCED compute subsystem (configs/phys_*.json) onto sky130_fd_sc_hd, hierarchy
               kept, memories mapped to flip-flops (no SRAM macros exist for this flow); per-region cell area from
               `stat -liberty` of every top-level instance.
  2. regions : physical/gen_regions.py turns the measured areas into a proposed region map (a grid template:
               vector clusters around a central NoC column, tensor clusters on the NoC axis, shell control next to
               the host side) and writes physical/<cfg>/regions.tcl + groups.tcl with the ACTUAL instance names.
  3. place   : OpenROAD 2.0-12331-g6011bbe77 (FloorplanLab's pinned build): floorplan, pins, regions (odb dbRegion,
               INCLUSIVE) and instance groups (odb dbGroup), global_placement, detailed_placement, check_placement;
               the same run WITHOUT regions as the control.  Containment and per-cluster spread are measured from the
               placed database, DEF (with REGIONS / GROUPS) is written.
Pre-CTS, no routing, no timing closure, typical corner only.  Nothing here is a fabricated layout: every
coordinate in the reports comes from the OpenROAD database after placement.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
PHYS = ROOT / "physical"
BUILD = ROOT / "build" / "phys"
PLAT = Path("/opt/eda/orfs/flow/platforms/sky130hd")
LIB = PLAT / "lib" / "sky130_fd_sc_hd__tt_025C_1v80.lib"
TLEF = PLAT / "lef" / "sky130_fd_sc_hd.tlef"
CLEF = PLAT / "lef" / "sky130_fd_sc_hd_merged.lef"
OPENROAD = "/opt/eda/env/bin/openroad"
PERIOD_NS = 20.0          # 50 MHz reference clock for the pre-CTS timing report (not a target, not a claim)
sys.path.insert(0, str(PHYS))
import gen_regions  # noqa: E402


def files():
    f = (ROOT / "rtl" / "files.f").read_text().split()
    inc = [str(ROOT / x[len("+incdir+"):]) for x in f if x.startswith("+incdir+")]
    src = [str(ROOT / x) for x in f if not x.startswith("+")]
    return inc, src


def synth(cfg: dict, d: Path) -> dict:
    inc, src = files()
    ch = " ".join(f"-chparam {k} {v}" for k, v in cfg["params"].items())
    top = "silicaflux_compute_cluster"
    nv = cfg["params"].get("NUM_VECTOR_CLUSTERS", 1)
    nt = cfg["params"].get("NUM_TENSOR_CLUSTERS", 1)
    # unpopulated slots are empty wrappers; dissolve them before mapping so that hilomap / insbuf do not give
    # each one its own tie cells and buffers (their constant outputs become top-level constants)
    empty = [f"{top}/u_vector_{k}" for k in range(nv, 8)] + [f"{top}/u_tensor_{j}" for j in range(nt, 4)]
    ys = "\n".join([
        f"read_liberty -lib {LIB}",
        "read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{i}" for i in inc) + " " + " ".join(src),
        f"hierarchy -check -top {top} {ch}",
        f"synth -top {top}",
        (f"flatten {' '.join(empty)}" if empty else "# all slots populated"),
        "opt_clean -purge",
        f"dfflibmap -liberty {LIB}",
        f"abc -liberty {LIB}",
        "opt_clean -purge",
        "setundef -zero",
        "hilomap -singleton -hicell sky130_fd_sc_hd__conb_1 HI -locell sky130_fd_sc_hd__conb_1 LO",
        "insbuf -buf sky130_fd_sc_hd__buf_1 A X",
        "opt_clean -purge",
        "check -assert",
        f"tee -o stat_liberty.txt stat -liberty {LIB} -top {top}",
        "write_json netlist.json",
        "write_verilog -noattr -noexpr -nohex -nodec netlist_raw.v",
    ]) + "\n"
    (d / "synth.ys").write_text(ys)
    t0 = time.time()
    p = subprocess.run(["yosys", "-q", "-l", "yosys.log", "-s", "synth.ys"], cwd=d, stdout=subprocess.PIPE,
                       stderr=subprocess.STDOUT, text=True)
    if p.returncode != 0:
        raise RuntimeError(p.stdout[-3000:])
    # OpenSTA-friendly module names: $paramod$<hash>\name -> name__<hash8>
    v = (d / "netlist_raw.v").read_text()
    v = re.sub(r"\\\$paramod\$([0-9a-f]{8})[0-9a-f]*\\(\w+)", r"\2__\1", v)
    v = re.sub(r"\\\$paramod\\(\w+)\\(\S+)", lambda m: m.group(1) + "__" + re.sub(r"\W", "_", m.group(2)), v)
    (d / "netlist.v").write_text(v)
    return dict(synth_secs=round(time.time() - t0, 1))


OR_TCL = r"""
read_lef {tlef}
read_lef {clef}
read_liberty {lib}
read_verilog {netlist}
link_design silicaflux_compute_cluster
initialize_floorplan -die_area {{{die}}} -core_area {{{core}}} -site unithd
source {platdir}/make_tracks.tcl
place_pins -hor_layers met3 -ver_layers met2 -random
set block [ord::get_db_block]
{regions}
global_placement -density {density} -skip_io
detailed_placement
set ok [catch {{check_placement -verbose}} msg]
puts "SFX_CHECK_PLACEMENT ok=[expr {{!$ok}}] $msg"
# ------------------------------------------------------------- measurements from the placed database
set fp [open {out}/placement.txt w]
foreach inst [$block getInsts] {{
  set bb [$inst getBBox]
  set r [$inst getRegion]
  set rn [expr {{$r eq "NULL" ? "-" : [$r getName]}}]
  puts $fp "[$inst getName] [$bb xMin] [$bb yMin] [$bb xMax] [$bb yMax] [[$inst getMaster] getName] $rn"
}}
close $fp
write_def {out}/placed.def
report_design_area
# ------------------------------------------------------------- pre-CTS timing, placement-estimated parasitics
create_clock -name clk -period {period} [get_ports clk]
set_input_delay  0 -clock clk [delete_from_list [all_inputs] [get_ports clk]]
set_output_delay 0 -clock clk [all_outputs]
source {platdir}/setRC.tcl
estimate_parasitics -placement
puts "SFX_TIMING_BEGIN"
report_checks -path_delay max -group_count 8 -endpoint_count 1 -digits 3
report_worst_slack -max -digits 3
report_tns -digits 3
puts "SFX_TIMING_END"
"""


def openroad(d: Path, tag: str, plan: dict, with_regions: bool, density: float) -> dict:
    out = d / tag
    out.mkdir(exist_ok=True)
    reg = f"source {d / 'regions.tcl'}\nsource {d / 'groups.tcl'}\nsfx_apply_regions $block\nsfx_apply_groups $block" \
        if with_regions else "# control run: no regions"
    tcl = OR_TCL.format(tlef=TLEF, clef=CLEF, lib=LIB, netlist=d / "netlist.v", platdir=PLAT,
                        die=" ".join(str(x) for x in plan["die_um"]), core=" ".join(str(x) for x in plan["core_um"]),
                        regions=reg, density=density, out=out, period=PERIOD_NS)
    (out / "place.tcl").write_text(tcl)
    t0 = time.time()
    with open(out / "openroad.log", "w") as lf:                     # streamed: progress is visible while it runs
        p = subprocess.run([OPENROAD, "-no_init", "-threads", "4", "-exit", str(out / "place.tcl")], cwd=out,
                           stdout=lf, stderr=subprocess.STDOUT, text=True)
    return parse_run(out, plan, rc=p.returncode, secs=round(time.time() - t0, 1))


def parse_run(out: Path, plan: dict, rc=None, secs=None) -> dict:
    """Results of one OpenROAD run directory (openroad.log, placement.txt) — also usable after the fact."""
    class P:                                                       # minimal stand-in for the subprocess result
        stdout = (out / "openroad.log").read_text(errors="replace")
    p = P()
    res = dict(rc=rc, secs=secs, run_dir=str(out.relative_to(ROOT)),
               completed="SFX_TIMING_END" in p.stdout and (out / "placement.txt").exists())
    m = re.search(r"SFX_CHECK_PLACEMENT ok=(\d)", p.stdout)
    res["check_placement_ok"] = bool(m and m.group(1) == "1")
    hp = re.findall(r"HPWL[^\n]*?([0-9.]+)\s*$", p.stdout, re.M)
    res["gpl_final_hpwl_line"] = next((l for l in p.stdout.splitlines()[::-1] if "HPWL" in l), "")
    res["dpl_lines"] = [l for l in p.stdout.splitlines() if "DPL" in l or "legal" in l.lower()][-8:]
    res["warnings"] = sorted({l.split("]")[0] + "]" for l in p.stdout.splitlines() if l.startswith("[WARNING")})
    res["errors"] = [l for l in p.stdout.splitlines() if l.startswith("[ERROR") or "Error" in l][:10]
    tm = p.stdout.split("SFX_TIMING_BEGIN")[-1].split("SFX_TIMING_END")[0] if "SFX_TIMING_BEGIN" in p.stdout else ""
    (out / "timing.rpt").write_text(tm)
    paths = []
    for blk in tm.split("Startpoint: ")[1:]:
        sp = blk.split()[0]
        ep = blk.split("Endpoint: ")[1].split()[0] if "Endpoint: " in blk else "?"
        m2 = re.search(r"(-?[0-9.]+)\s+slack", blk)
        dm = re.search(r"(-?[0-9.]+)\s+data arrival time", blk)
        paths.append(dict(start=sp, end=ep, slack_ns=float(m2.group(1)) if m2 else None,
                          arrival_ns=float(dm.group(1)) if dm else None))
    res["timing_period_ns"] = PERIOD_NS
    res["timing_paths"] = paths
    ws = re.search(r"worst slack\s+(-?[0-9.]+)", tm)
    tn = re.search(r"tns\s+(-?[0-9.]+)", tm)
    res["wns_ns"] = float(ws.group(1)) if ws else None
    res["tns_ns"] = float(tn.group(1)) if tn else None
    if (out / "placement.txt").exists():
        res.update(gen_regions.measure(out / "placement.txt", plan))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cfg", default="phys_hpc")
    ap.add_argument("--util", type=float, default=0.45)
    ap.add_argument("--density", type=float, default=0.6)
    ap.add_argument("--skip-synth", action="store_true")
    ap.add_argument("--control-only", action="store_true", help="placement without regions only")
    ap.add_argument("--parse-only", nargs=2, metavar=("WITH_DIR", "WITHOUT_DIR"),
                    help="only parse two finished run directories (relative to build/phys/<cfg>)")
    a = ap.parse_args()
    cfg = json.loads((ROOT / "configs" / f"{a.cfg}.json").read_text())
    d = BUILD / a.cfg
    d.mkdir(parents=True, exist_ok=True)
    res = dict(cfg=a.cfg, params=cfg["params"])
    if not (a.skip_synth or a.parse_only) or not (d / "netlist.v").exists():
        res.update(synth(cfg, d))
    areas = gen_regions.region_areas(d / "netlist.json", LIB)
    plan = gen_regions.plan(areas, cfg, util=a.util)
    pdir = PHYS / a.cfg
    pdir.mkdir(parents=True, exist_ok=True)
    gen_regions.write_tcl(plan, d / "regions.tcl", d / "groups.tcl", d / "netlist.json")
    for f in ("regions.tcl", "groups.tcl"):
        (pdir / f).write_text((d / f).read_text())
    (pdir / "plan.json").write_text(json.dumps(plan, indent=1))
    res["areas"] = areas
    res["plan"] = plan
    if a.parse_only:
        res["with_regions"] = parse_run(d / a.parse_only[0], plan)
        res["control_no_regions"] = parse_run(d / a.parse_only[1], plan)
    elif a.control_only:
        res["control_no_regions"] = openroad(d, "no_regions", plan, False, a.density)
    else:
        res["with_regions"] = openroad(d, "with_regions", plan, True, a.density)
        res["control_no_regions"] = openroad(d, "no_regions", plan, False, a.density)
    rep = ROOT / "reports" / "physical"
    rep.mkdir(parents=True, exist_ok=True)
    (rep / f"{a.cfg}.json").write_text(json.dumps(res, indent=1))
    for k in ("with_regions", "control_no_regions"):
        if k not in res:
            continue
        r = res[k]
        print(k, "rc", r["rc"], "secs", r["secs"], "check_placement", r["check_placement_ok"])
        for reg in r.get("regions", []):
            print("  ", reg)


if __name__ == "__main__":
    main()
