# SilicaFlux Project 32 :: apply the proposed regions and instance groups to a linked, floorplanned design.
# Usage inside OpenROAD (2.0-12331-g6011bbe77 checked), after link_design + initialize_floorplan:
#     set SFX_CFG_DIR <dir with regions.tcl / groups.tcl>      ;# e.g. physical/phys_hpc
#     source physical/apply_constraints.tcl
# In OpenROAD-flow-scripts it can be called from a floorplan hook (e.g. the script named by FOOTPRINT_TCL /
# a custom do-floorplan step); the instance names must be those of the hierarchical Yosys netlist as OpenROAD
# links it (hierarchy separator '/').
# Effects: odb dbRegion per SFX_REGIONS entry (INCLUSIVE), odb dbGroup per SFX_GROUPS entry; both are written by
# write_def (REGIONS / GROUPS sections), so other tools can import them.
source $SFX_CFG_DIR/regions.tcl
source $SFX_CFG_DIR/groups.tcl
set sfx_block [ord::get_db_block]
sfx_apply_regions $sfx_block
sfx_apply_groups $sfx_block
puts "SFX_CONSTRAINTS regions [llength [$sfx_block getRegions]] groups [llength [$sfx_block getGroups]]"
