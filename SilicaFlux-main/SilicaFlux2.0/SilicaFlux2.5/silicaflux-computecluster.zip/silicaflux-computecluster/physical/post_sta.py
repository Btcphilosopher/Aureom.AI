#!/usr/bin/env python3
"""Post-placement buffering + pre-CTS timing of a placed run (physical/run_phys.py output).

The placement runs stop after detailed placement; without buffering, high-fanout nets (resets) dominate any timing
report.  This session loads the placed DEF, marks the sky130hd low-power / isolation cells dont_use (as ORFS does),
runs repair_design (max slew / cap / fanout buffering), legalizes the inserted buffers (regions respected), estimates
placement parasitics and reports the worst paths.  Each path is classified by the regions of its start and end
point (instance-name prefixes of plan.json): intra-region or crossing.
Still pre-CTS (ideal clock), no repair_timing, no routing: an indication of WHERE the long paths are, not a
frequency result.
Single-threaded: OpenSTA 2.4 (in this OpenROAD build) crashed (SIGSEGV in Search::setVertexArrivals) in a
multi-threaded `report_checks -through` on the 4 + 2 design.
Usage: post_sta.py <run_dir> <plan.json> [period_ns]
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
from collections import Counter
from pathlib import Path

PLAT = Path("/opt/eda/orfs/flow/platforms/sky130hd")
OPENROAD = "/opt/eda/env/bin/openroad"

TCL = """
read_lef {plat}/lef/sky130_fd_sc_hd.tlef
read_lef {plat}/lef/sky130_fd_sc_hd_merged.lef
read_liberty {plat}/lib/sky130_fd_sc_hd__tt_025C_1v80.lib
read_def {run}/placed.def
create_clock -name clk -period {period} [get_ports clk]
set_input_delay  0 -clock clk [delete_from_list [all_inputs] [get_ports clk]]
set_output_delay 0 -clock clk [all_outputs]
source {plat}/setRC.tcl
set_dont_use [get_lib_cells {{sky130_fd_sc_hd__lpflow_* sky130_fd_sc_hd__probe_* sky130_fd_sc_hd__clkdly* sky130_fd_sc_hd__dlygate* sky130_fd_sc_hd__dlymetal*}}]
estimate_parasitics -placement
repair_design
detailed_placement
set ok [catch {{check_placement}} msg]
puts "SFX_CHECK_PLACEMENT ok=[expr {{!$ok}}] $msg"
estimate_parasitics -placement
puts "SFX_TIMING_BEGIN"
report_checks -path_delay max -group_count 300 -endpoint_count 1 -digits 3 -fields {{fanout}}
report_worst_slack -max -digits 3
report_tns -digits 3
puts "SFX_TIMING_END"
report_design_area
# worst path through each region-boundary interface (top-level nets of the shell)
foreach {{tag pat}} {{cluster_mem_req xm_req_* cluster_mem_rsp xm_rsp_* local_mem_req xs_req_* local_mem_rsp xs_rsp_* command sl_cmd_* completion sl_cpl_* csr sl_csr_* status sl_busy*}} {{
  set nets [get_nets -quiet $pat]
  if {{[llength $nets] == 0}} {{ puts "SFX_IF $tag none"; continue }}
  puts "SFX_IF_BEGIN $tag [llength $nets]"
  report_checks -path_delay max -through $nets -digits 3
  puts "SFX_IF_END $tag"
}}
"""


def region_of(name: str, regions: list[dict]) -> str:
    for r in regions:
        if any(name.startswith(p) for p in r["prefixes"]):
            return r["name"]
    return "TOP"


def main():
    run, plan_p = Path(sys.argv[1]).resolve(), Path(sys.argv[2]).resolve()
    period = float(sys.argv[3]) if len(sys.argv) > 3 else 20.0
    plan = json.loads(plan_p.read_text())
    (run / "post_sta.tcl").write_text(TCL.format(plat=PLAT, run=run, period=period))
    with open(run / "post_sta.log", "w") as lf:
        rc = subprocess.run([OPENROAD, "-no_init", "-threads", "1", "-exit", str(run / "post_sta.tcl")], cwd=run,
                            stdout=lf, stderr=subprocess.STDOUT).returncode
    log = (run / "post_sta.log").read_text(errors="replace")
    tm = log.split("SFX_TIMING_BEGIN")[-1].split("SFX_TIMING_END")[0] if "SFX_TIMING_BEGIN" in log else ""
    paths = []
    for blk in tm.split("Startpoint: ")[1:]:
        sp = blk.split()[0]
        ep = blk.split("Endpoint: ")[1].split()[0] if "Endpoint: " in blk else "?"
        grp = re.search(r"Path Group: (\S+)", blk)
        sl = re.search(r"(-?[0-9.]+)\s+slack", blk)
        ar = re.search(r"(-?[0-9.]+)\s+data arrival time", blk)
        rs, re_ = region_of(sp, plan["regions"]), region_of(ep, plan["regions"])
        paths.append(dict(start=sp, end=ep, group=grp.group(1) if grp else "?", slack_ns=float(sl.group(1)) if sl else None,
                          arrival_ns=float(ar.group(1)) if ar else None, start_region=rs, end_region=re_,
                          crossing=rs != re_))
    ws = re.search(r"worst slack\s+(-?[0-9.]+)", tm)
    tn = re.search(r"tns\s+(-?[0-9.]+)", tm)
    data = [p for p in paths if p["group"] != "asynchronous"]
    res = dict(rc=rc, period_ns=period, check_placement_ok="SFX_CHECK_PLACEMENT ok=1" in log,
               wns_ns=float(ws.group(1)) if ws else None, tns_ns=float(tn.group(1)) if tn else None,
               repair_design=[l for l in log.splitlines() if "RSZ-00" in l][:12],
               n_paths=len(paths), n_crossing=sum(p["crossing"] for p in paths),
               worst_by_region_pair=dict(Counter(f"{p['start_region']}->{p['end_region']}" for p in paths).most_common(12)),
               worst_data_paths=data[:15], worst_async_paths=[p for p in paths if p["group"] == "asynchronous"][:5],
               worst_crossing=[p for p in paths if p["crossing"]][:15],
               area_line=next((l for l in log.splitlines() if l.startswith("Design area")), ""))
    ifs = {}
    for m in re.finditer(r"SFX_IF_BEGIN (\S+) (\d+)(.*?)SFX_IF_END", log, re.S):
        blk = m.group(3)
        sp = re.search(r"Startpoint: (\S+)", blk)
        ep = re.search(r"Endpoint: (\S+)", blk)
        sl = re.search(r"(-?[0-9.]+)\s+slack", blk)
        ar = re.search(r"(-?[0-9.]+)\s+data arrival time", blk)
        ifs[m.group(1)] = dict(nets=int(m.group(2)), start=sp.group(1) if sp else None, end=ep.group(1) if ep else None,
                               slack_ns=float(sl.group(1)) if sl else None, arrival_ns=float(ar.group(1)) if ar else None,
                               start_region=region_of(sp.group(1), plan["regions"]) if sp else None,
                               end_region=region_of(ep.group(1), plan["regions"]) if ep else None)
    res["interfaces"] = ifs
    (run / "post_sta.json").write_text(json.dumps(res, indent=1))
    print(json.dumps({k: res[k] for k in ("rc", "check_placement_ok", "wns_ns", "tns_ns", "n_paths", "n_crossing",
                                          "worst_by_region_pair", "area_line", "interfaces")}, indent=1))


if __name__ == "__main__":
    main()
