// =============================================================================
// SilicaFlux Project 32 :: tb_compute_cluster
// System testbench of silicaflux_compute_cluster (any configuration).
// Aureom.AI | SilicaFlux-HPC
//
// Program (model/cc_prog.py writes prog.txt; one operation per line):
//   C d w0..w11   send a command to cluster ID d.  Stream mode (CMD_IF = 1): queued and driven on
//                 cmd_* with random gaps (+cmd_gap=%); legacy (CMD_IF = 0): staged in the cluster's
//                 register page + DOORBELL (retried while refused), completions polled from CPL regs.
//   S n           wait until n completions have been received in total
//   Q             wait until every command sent has completed and no cluster is busy
//   WR a d        register write, must be accepted        WE a d   register write, must be refused
//   RD a v m      register read, (value & m) must equal v RS a     register read, logged as "L a value"
//   PW a m v      poll the register until (value & m) == v
//   HW a d        host data-port write of 32-bit word d   HR a v   host read, must return v without error
//   HE a          host read, must answer rsp_error = 1
//   X id          reset cluster id (shell CL_RESET), wait until it is held in reset; "X id" marker logged
//   XW id         wait until cluster id has left reset
//   WB id         wait until cluster id reports busy       D n      wait n cycles
//   I v           check the shell irq output equals v
// Background: the host data port issues random reads / writes into a private window at +cpu_rate=%
// (shadow-checked); the shared memory answers after +lat_min..+lat_max cycles, refuses requests at
// +mem_stall=% and answers rsp_error for [+err_lo, +err_hi); cpl_ready is high at +cpl_rate=%.
// Every crossbar master and slave port and the shared-memory port carry an SFB2 protocol checker.
// Outputs: records.txt ("P src err w0..w5", "X id", "L a v"), mem_final.hex, stats.txt.
// =============================================================================
`timescale 1ns/1ps
`include "sfx_cluster_defs.svh"
module tb_compute_cluster;
  parameter int NV = 1, NT = 1, W = 32, MEM_PIPE = 0, LM_PIPE = 0, EXT_PIPE = 0, CMD_PIPE = 0, CMD_IF = 1,
                LOCAL_MEM_PORT = 1, VEC_LANES = 4, VEC_SPM_BYTES = 65536, VEC_BANKS = 4, VEC_DMA_BUF = 0,
                TSU_ROWS = 4, TSU_COLS = 4, TSU_TILE_K = 64, TSU_OPBUF = 2048, TSU_BANKS = 4, TSU_QUANT = 0, TSU_DBUF = 0,
                RST_HOLD = 8, RB_AW = 16, VEC_CMDQ = 8, VEC_PERF = 1, TSU_CMDQ = 4,
                TSU_PERF = 1, SHELL_PERF = 1;
  localparam logic [31:0] MEM_BASE = 32'h1000_0000, SPM_BASE = 32'h2000_0000;
  localparam int          MEM_BYTES = 1 << 20;
  localparam int WB = W / 8, NM = 1 + NV + NT, NS = 1 + ((LOCAL_MEM_PORT != 0) ? NV : 0), NSLOT = `SFX_NSLOT;
  localparam int OFF = $clog2(WB);

  logic clk = 1'b0, rst_n = 1'b0;
  always #5 clk = ~clk;
  longint cyc = 0;
  always @(posedge clk) cyc <= cyc + 1;
  int errors = 0;
  `define ERR(args) begin errors = errors + 1; if (errors <= 40) begin $write("ERROR cyc=%0d: ", cyc); $display args ; end end
  int unsigned rs [0:7];
  function automatic int unsigned rnd(input int s);
    int unsigned x;
    x = rs[s]; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); rs[s] = x; return x;
  endfunction
  function automatic bit pct(input int s, input int p);
    if (p <= 0) return 1'b0;
    if (p >= 100) return 1'b1;
    return (rnd(s) % 100) < p;
  endfunction

  // ============================================================ DUT
  logic                rb_sel = 1'b0, rb_we = 1'b0, rb_err;
  logic [RB_AW-1:0]    rb_addr = '0;
  logic [31:0]         rb_wdata = '0, rb_rdata;
  logic                cmd_valid = 1'b0, cmd_ready;
  logic [3:0]          cmd_dest = '0;
  logic [383:0]        cmd_data = '0;
  logic                cpl_valid, cpl_ready = 1'b0, cpl_err;
  logic [3:0]          cpl_src;
  logic [191:0]        cpl_data;
  logic                h_req_valid = 1'b0, h_req_ready, h_req_write = 1'b0, h_rsp_valid, h_rsp_error;
  logic                h_rdy = 1'b1;                 // host response ready (op HRDY)
  logic [31:0]         h_req_addr = '0;
  logic [W-1:0]        h_req_wdata = '0, h_rsp_rdata;
  logic [WB-1:0]       h_req_wstrb = '0;
  logic                mem_req_valid, mem_req_ready, mem_req_write, mem_rsp_valid, mem_rsp_ready, mem_rsp_error;
  logic [31:0]         mem_req_addr;
  logic [W-1:0]        mem_req_wdata, mem_rsp_rdata;
  logic [WB-1:0]       mem_req_wstrb;
  logic                irq;
  logic [NSLOT-1:0]    cl_irq, cl_err, cl_busy, cl_in_reset, cl_clk_en_req;
  logic [NSLOT*8-1:0]  cl_perf_ev;
  logic [NM-1:0]       mon_acc, mon_stall, mon_loss;

  silicaflux_compute_cluster #(
    .NUM_VECTOR_CLUSTERS(NV), .NUM_TENSOR_CLUSTERS(NT), .TRANSACTION_WIDTH(W), .MEM_BASE(MEM_BASE),
    .MEM_BYTES(MEM_BYTES), .LOCAL_MEM_PORT(LOCAL_MEM_PORT), .MEM_PIPE(MEM_PIPE), .LM_PIPE(LM_PIPE),
    .EXT_PIPE(EXT_PIPE), .CMD_PIPE(CMD_PIPE), .CMD_IF(CMD_IF), .VEC_NUM_LANES(VEC_LANES),
    .VEC_SCRATCHPAD_BYTES(VEC_SPM_BYTES), .VEC_NUM_BANKS(VEC_BANKS), .VEC_DMA_BUFFER_DEPTH(VEC_DMA_BUF),
    .VEC_SPM_BASE(SPM_BASE), .TSU_ARRAY_ROWS(TSU_ROWS), .TSU_ARRAY_COLS(TSU_COLS), .TSU_TILE_K(TSU_TILE_K),
    .TSU_OPERAND_BUFFER_BYTES(TSU_OPBUF), .TSU_NUM_MEMORY_BANKS(TSU_BANKS), .TSU_QUANT(TSU_QUANT), .TSU_DBUF(TSU_DBUF), .RST_HOLD(RST_HOLD),
    .RB_AW(RB_AW), .VEC_CMD_QUEUE_DEPTH(VEC_CMDQ), .VEC_CPL_QUEUE_DEPTH(VEC_CMDQ), .VEC_PERF(VEC_PERF),
    .TSU_CMD_QUEUE_DEPTH(TSU_CMDQ), .TSU_PERF(TSU_PERF), .SHELL_PERF(SHELL_PERF)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_dest(cmd_dest), .cmd_data(cmd_data),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_src(cpl_src), .cpl_err(cpl_err), .cpl_data(cpl_data),
    .h_req_valid(h_req_valid), .h_req_ready(h_req_ready), .h_req_write(h_req_write), .h_req_addr(h_req_addr),
    .h_req_wdata(h_req_wdata), .h_req_wstrb(h_req_wstrb), .h_rsp_valid(h_rsp_valid), .h_rsp_ready(h_rdy),
    .h_rsp_rdata(h_rsp_rdata), .h_rsp_error(h_rsp_error),
    .mem_req_valid(mem_req_valid), .mem_req_ready(mem_req_ready), .mem_req_write(mem_req_write),
    .mem_req_addr(mem_req_addr), .mem_req_wdata(mem_req_wdata), .mem_req_wstrb(mem_req_wstrb),
    .mem_rsp_valid(mem_rsp_valid), .mem_rsp_ready(mem_rsp_ready), .mem_rsp_rdata(mem_rsp_rdata),
    .mem_rsp_error(mem_rsp_error),
    .irq(irq), .cl_irq(cl_irq), .cl_err(cl_err), .cl_busy(cl_busy), .cl_in_reset(cl_in_reset),
    .cl_clk_en_req(cl_clk_en_req), .cl_perf_ev(cl_perf_ev),
    .mon_req_accept(mon_acc), .mon_req_stall(mon_stall), .mon_arb_loss(mon_loss));

  // ============================================================ SFB2 protocol checkers
  logic [31:0] viol_m [0:NM-1], viol_s [0:NS-1], viol_x;
  for (genvar m = 0; m < NM; m++) begin : g_cm
    /* verilator lint_off UNUSEDSIGNAL */
    logic [31:0] a, b, c;
    /* verilator lint_on UNUSEDSIGNAL */
    sfb_protocol_checker #(.DW(W), .MAX_OUT(1), .NAME("xbar_master")) u_chk (.clk(clk), .rst_n(rst_n),
      .req_valid(dut.xm_req_valid[m]), .req_ready(dut.xm_req_ready[m]), .req_write(dut.xm_req_write[m]),
      .req_addr(dut.xm_req_addr[m*32 +: 32]), .req_wdata(dut.xm_req_wdata[m*W +: W]),
      .req_wstrb(dut.xm_req_wstrb[m*WB +: WB]), .rsp_valid(dut.xm_rsp_valid[m]), .rsp_ready(dut.xm_rsp_ready[m]),
      .rsp_rdata(dut.xm_rsp_rdata[m*W +: W]), .rsp_error(dut.xm_rsp_error[m]),
      .violations(viol_m[m]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  for (genvar s = 0; s < NS; s++) begin : g_cs
    /* verilator lint_off UNUSEDSIGNAL */
    logic [31:0] a, b, c;
    /* verilator lint_on UNUSEDSIGNAL */
    sfb_protocol_checker #(.DW(W), .MAX_OUT(1), .NAME("xbar_slave")) u_chk (.clk(clk), .rst_n(rst_n),
      .req_valid(dut.xs_req_valid[s]), .req_ready(dut.xs_req_ready[s]), .req_write(dut.xs_req_write[s]),
      .req_addr(dut.xs_req_addr[s*32 +: 32]), .req_wdata(dut.xs_req_wdata[s*W +: W]),
      .req_wstrb(dut.xs_req_wstrb[s*WB +: WB]), .rsp_valid(dut.xs_rsp_valid[s]), .rsp_ready(dut.xs_rsp_ready[s]),
      .rsp_rdata(dut.xs_rsp_rdata[s*W +: W]), .rsp_error(dut.xs_rsp_error[s]),
      .violations(viol_s[s]), .n_req(a), .n_rsp(b), .outstanding(c));
  end
  /* verilator lint_off UNUSEDSIGNAL */
  logic [31:0] xa, xb, xc;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_protocol_checker #(.DW(W), .MAX_OUT(2), .NAME("mem_port")) u_chk_mem (.clk(clk), .rst_n(rst_n),
    .req_valid(mem_req_valid), .req_ready(mem_req_ready), .req_write(mem_req_write), .req_addr(mem_req_addr),
    .req_wdata(mem_req_wdata), .req_wstrb(mem_req_wstrb), .rsp_valid(mem_rsp_valid), .rsp_ready(mem_rsp_ready),
    .rsp_rdata(mem_rsp_rdata), .rsp_error(mem_rsp_error), .violations(viol_x), .n_req(xa), .n_rsp(xb),
    .outstanding(xc));

  // ============================================================ shared memory (write performed at response, R7)
  logic [7:0] mem [0:MEM_BYTES-1];
  int lat_min = 1, lat_max = 1, mem_stall = 0, mem_stall0 = 0;
  logic [31:0] err_lo = '0, err_hi = '0;
  localparam int QN = 8;
  logic q_w [0:QN-1]; logic [31:0] q_a [0:QN-1]; logic [W-1:0] q_d [0:QN-1]; logic [WB-1:0] q_s [0:QN-1];
  longint q_t [0:QN-1];
  int q_head = 0, q_tail = 0;
  logic rsp_v_q = 1'b0, rsp_e_q = 1'b0; logic [W-1:0] rsp_d_q = '0;
  logic mrdy_q = 1'b0;
  assign mem_rsp_valid = rsp_v_q; assign mem_rsp_error = rsp_e_q; assign mem_rsp_rdata = rsp_d_q;
  assign mem_req_ready = rst_n && mrdy_q && (q_tail - q_head < QN - 2);
  longint n_mem = 0, n_mem_err = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      q_head = 0; q_tail = 0; rsp_v_q <= 1'b0; mrdy_q <= 1'b0;
    end else begin
      bit can;
      mrdy_q <= !pct(1, mem_stall);
      can = (!rsp_v_q || mem_rsp_ready) && q_head != q_tail && cyc >= q_t[q_head % QN];
      if (can) begin
        int h; logic [31:0] o; bit e;
        h = q_head % QN; q_head = q_head + 1; o = q_a[h] - MEM_BASE;
        e = q_a[h] >= err_lo && q_a[h] < err_hi;
        rsp_v_q <= 1'b1; rsp_e_q <= e; n_mem = n_mem + 1; if (e) n_mem_err = n_mem_err + 1;
        if (q_w[h] || e) begin
          rsp_d_q <= '0;
          if (!e) for (int b = 0; b < WB; b++) if (q_s[h][b]) mem[o + b] = q_d[h][8*b +: 8];
        end else for (int b = 0; b < WB; b++) rsp_d_q[8*b +: 8] <= mem[o + b];
      end else if (rsp_v_q && mem_rsp_ready) rsp_v_q <= 1'b0;
      if (mem_req_valid && mem_req_ready) begin
        int t; t = q_tail % QN;
        if (mem_req_addr < MEM_BASE || mem_req_addr >= MEM_BASE + MEM_BYTES || mem_req_addr[OFF-1:0] != '0)
          `ERR(("shared memory: request outside the window / misaligned: %h", mem_req_addr))
        q_w[t] = mem_req_write; q_a[t] = mem_req_addr; q_d[t] = mem_req_wdata; q_s[t] = mem_req_wstrb;
        q_t[t] = cyc + lat_min + ((lat_max > lat_min) ? (rnd(2) % (lat_max - lat_min + 1)) : 0);
        q_tail = q_tail + 1;
      end
    end
  end

  // ============================================================ host data port: foreground ops + background traffic
  int          cpu_rate = 0, cpu_rate0 = 0;
  logic [31:0] cpu_lo = '0;
  localparam int CW = 256;
  logic [31:0] c_sh [0:CW-1];
  bit          c_sv [0:CW-1];
  initial for (int i = 0; i < CW; i++) c_sv[i] = 1'b0;
  bit          fg_req = 1'b0, fg_done = 1'b0, fg_wr = 1'b0, fg_err = 1'b0, h_pend = 1'b0, h_fg = 1'b0, h_pw = 1'b0;
  logic [31:0] fg_addr = '0, fg_wd = '0, fg_rd = '0, h_pa = '0;
  longint      n_cpu = 0;
  always @(posedge clk) begin
    if (!rst_n) begin
      h_req_valid <= 1'b0; h_pend <= 1'b0;
    end else begin
      if (h_req_valid && h_req_ready) begin
        h_req_valid <= 1'b0; h_pend <= 1'b1;
        if (!h_fg && h_req_write) begin
          c_sh[(h_pa - cpu_lo) >> 2] = h_req_wdata[31:0];          // every lane carries the same word
          c_sv[(h_pa - cpu_lo) >> 2] = 1'b1;
        end
      end
      if (h_rsp_valid && h_rdy) begin
        logic [31:0] lane;
        lane = (W == 32) ? h_rsp_rdata[31:0] : h_rsp_rdata[32 * ((h_pa >> 2) % (W / 32)) +: 32];
        h_pend <= 1'b0;
        if (h_fg) begin
          fg_rd = lane; fg_err = h_rsp_error; fg_done = 1'b1; h_fg <= 1'b0;
        end else begin
          n_cpu = n_cpu + 1;
          if (h_rsp_error) `ERR(("host traffic: error response at %h", h_pa))
          if (!h_pw && c_sv[(h_pa - cpu_lo) >> 2] && lane != c_sh[(h_pa - cpu_lo) >> 2])
            `ERR(("host traffic: read %h at %h, expected %h", lane, h_pa, c_sh[(h_pa - cpu_lo) >> 2]))
        end
      end
      if (!h_req_valid && !h_pend && !(h_rsp_valid && h_rdy)) begin
        logic [31:0] a; logic [31:0] d; bit w, go;
        go = 1'b0;
        if (fg_req && !fg_done) begin
          a = fg_addr; d = fg_wd; w = fg_wr; go = 1'b1; h_fg <= 1'b1; fg_req = 1'b0;
        end else if (cpu_lo != 0 && pct(4, cpu_rate)) begin
          a = cpu_lo + ((rnd(5) % CW) << 2); w = (rnd(6) & 1) != 0; d = rnd(7); go = 1'b1; h_fg <= 1'b0;
        end
        if (go) begin
          h_req_valid <= 1'b1; h_req_addr <= {a[31:OFF], {OFF{1'b0}}}; h_req_write <= w; h_pa <= a; h_pw <= w;
          h_req_wdata <= {(W / 32){d}};
          h_req_wstrb <= w ? (WB'(4'hF) << (4 * ((a >> 2) % (W / 32)))) : '0;
        end
      end
    end
  end
  task automatic host(input bit w, input logic [31:0] a, input logic [31:0] d, output logic [31:0] q, output bit e);
    @(negedge clk);
    fg_addr = a; fg_wd = d; fg_wr = w; fg_done = 1'b0; fg_req = 1'b1;
    while (!fg_done) @(negedge clk);
    q = fg_rd; e = fg_err; fg_done = 1'b0;
  endtask

  // ============================================================ host register BFM (SilicaFlux-V rb)
  task automatic rb(input bit we, input logic [31:0] a, input logic [31:0] d, output logic [31:0] q, output bit e);
    @(negedge clk);
    rb_sel = 1'b1; rb_we = we; rb_addr = a[RB_AW-1:0]; rb_wdata = d;
    #1; q = rb_rdata; e = rb_err;
    @(posedge clk); #1;
    rb_sel = 1'b0; rb_we = 1'b0;
    @(posedge clk);                         // >= 1 idle cycle: the SilicaFlux-V LSU waits for rvalid (sfv_cpu d_req)
  endtask
  task automatic wr32(input logic [31:0] a, input logic [31:0] d);
    logic [31:0] q; bit e;
    rb(1'b1, a, d, q, e);
    if (e) `ERR(("register write %h refused", a))
  endtask
  task automatic rd32(input logic [31:0] a, output logic [31:0] q);
    bit e;
    rb(1'b0, a, 32'd0, q, e);
    if (e) `ERR(("register read %h refused", a))
  endtask
  function automatic logic [31:0] page_of(input int id);
    return 32'((id < 8) ? (8 + id) : (8 + NV + id - 8)) << 12;
  endfunction
  localparam logic [31:0] SHELL = 32'h7000;

  // ============================================================ command stream driver
  int cmd_gap = 0, cpl_rate = 100;
  logic [383:0] cq_d [$];
  logic [3:0]   cq_t [$];
  int n_sent = 0, n_acc = 0, n_lost = 0;              // n_lost: commands destroyed by cluster resets
  always @(posedge clk) begin
    if (!rst_n) cmd_valid <= 1'b0;
    else begin
      if (cmd_valid && cmd_ready) begin
        cmd_valid <= 1'b0; n_acc = n_acc + 1;
        $fdisplay(fd_r, "A %0d %0d", cmd_dest, cyc);              // acceptance time (latency measurements)
      end
      if ((!cmd_valid || cmd_ready) && cq_d.size() > 0 && !pct(3, cmd_gap)) begin
        cmd_valid <= 1'b1; cmd_data <= cq_d.pop_front(); cmd_dest <= cq_t.pop_front();
      end
    end
  end

  // ============================================================ completion monitor
  int fd_r, n_cpl = 0;
  int n_cpl_src [0:15];
  initial for (int i = 0; i < 16; i++) n_cpl_src[i] = 0;
  always @(posedge clk) begin
    if (!rst_n) cpl_ready <= 1'b0;
    else begin
      if (cpl_valid && cpl_ready) begin
        $fdisplay(fd_r, "P %0d %0d %h %h %h %h %h %h %0d", cpl_src, cpl_err, cpl_data[31:0], cpl_data[63:32],
                  cpl_data[95:64], cpl_data[127:96], cpl_data[159:128], cpl_data[191:160], cyc);
        n_cpl = n_cpl + 1; n_cpl_src[cpl_src] = n_cpl_src[cpl_src] + 1;
        if (CMD_IF == 0) `ERR(("completion on the stream in legacy mode"))
      end
      cpl_ready <= pct(0, cpl_rate);
    end
  end

  // legacy mode: completions collected from the CPL registers of every cluster
  task automatic legacy_collect();
    for (int id = 0; id < NSLOT; id++) begin
      logic [31:0] st, r [0:5]; bit e; bit cv;
      if (!((id < 8 && id < NV) || (id >= 8 && id - 8 < NT))) continue;
      rd32(page_of(id) + ((id < 8) ? 32'h028 : 32'h01C), st);
      cv = (id < 8) ? st[5] : st[4];
      while (cv) begin
        for (int k = 0; k < 6; k++) rd32(page_of(id) + ((id < 8) ? 32'h040 : 32'h080) + 32'(4 * k), r[k]);
        rb(1'b1, page_of(id) + ((id < 8) ? 32'h058 : 32'h098), 32'd1, st, e);
        $fdisplay(fd_r, "P %0d %0d %h %h %h %h %h %h", id,
                  (id < 8) ? (r[0][11:8] != 0) : (r[0][25:24] != 0), r[0], r[1], r[2], r[3], r[4], r[5]);
        n_cpl = n_cpl + 1; n_cpl_src[id] = n_cpl_src[id] + 1;
        rd32(page_of(id) + ((id < 8) ? 32'h028 : 32'h01C), st);
        cv = (id < 8) ? st[5] : st[4];
      end
    end
  endtask
  task automatic legacy_submit(input int id, input logic [383:0] d);
    logic [31:0] q; bit e;
    int nw; nw = (id < 8) ? 8 : 12;
    for (int k = 0; k < nw; k++) wr32(page_of(id) + ((id < 8) ? 32'h080 : 32'h040) + 32'(4 * k), d[32 * k +: 32]);
    rb(1'b1, page_of(id) + ((id < 8) ? 32'h0A0 : 32'h070), 32'd1, q, e);
    while (e) begin legacy_collect(); rb(1'b1, page_of(id) + ((id < 8) ? 32'h0A0 : 32'h070), 32'd1, q, e); end
  endtask
  task automatic wait_cpl(input int n);
    while (n_cpl < n) begin
      if (CMD_IF == 0) legacy_collect(); else @(posedge clk);
    end
  endtask

  // ============================================================ statistics
  longint stall [0:NM-1], loss [0:NM-1], accn [0:NM-1];
  longint v_and_t_busy = 0, multi_busy = 0, max_busy = 0, ev_tot [0:NSLOT*8-1];
  initial begin
    for (int i = 0; i < NM; i++) begin stall[i] = 0; loss[i] = 0; accn[i] = 0; end
    for (int i = 0; i < NSLOT * 8; i++) ev_tot[i] = 0;
  end
  always @(posedge clk) if (rst_n) begin
    int nb;
    for (int i = 0; i < NM; i++) begin
      stall[i] = stall[i] + mon_stall[i]; loss[i] = loss[i] + mon_loss[i]; accn[i] = accn[i] + mon_acc[i];
    end
    for (int i = 0; i < NSLOT * 8; i++) ev_tot[i] = ev_tot[i] + cl_perf_ev[i];
    nb = $countones(cl_busy);
    if (|cl_busy[7:0] && |cl_busy[11:8]) v_and_t_busy = v_and_t_busy + 1;
    if (nb >= 2) multi_busy = multi_busy + 1;
    if (nb > max_busy) max_busy = nb;
  end

  // ============================================================ coverage: cluster-reset isolation paths
  longint cov_req_cap = 0, cov_rsp_cap = 0, cov_err_rsp = 0, cov_sunk = 0;
`define SFX_COV_V(K) \
  if (NV > K) begin : g_cov_v``K \
    always @(posedge clk) if (rst_n) begin \
      cov_req_cap = cov_req_cap + (dut.u_vector_``K.g_cl.u_rst.mh_v_q && dut.u_vector_``K.g_cl.u_rst.fm_req_ready); \
      cov_rsp_cap = cov_rsp_cap + (dut.u_vector_``K.g_cl.u_rst.sh_v_q && dut.u_vector_``K.g_cl.u_rst.fs_rsp_ready); \
      cov_err_rsp = cov_err_rsp + (dut.u_vector_``K.g_cl.u_rst.iso_q && dut.u_vector_``K.g_cl.u_rst.fs_rsp_valid && \
                                   dut.u_vector_``K.g_cl.u_rst.fs_rsp_ready && dut.u_vector_``K.g_cl.u_rst.fs_rsp_error); \
      cov_sunk    = cov_sunk + (dut.u_vector_``K.g_cl.u_rst.iso_q && dut.u_vector_``K.g_cl.u_rst.fm_rsp_valid); \
    end \
  end
`define SFX_COV_T(K) \
  if (NT > K) begin : g_cov_t``K \
    always @(posedge clk) if (rst_n) begin \
      cov_req_cap = cov_req_cap + (dut.u_tensor_``K.g_cl.u_rst.mh_v_q && dut.u_tensor_``K.g_cl.u_rst.fm_req_ready); \
      cov_sunk    = cov_sunk + (dut.u_tensor_``K.g_cl.u_rst.iso_q && dut.u_tensor_``K.g_cl.u_rst.fm_rsp_valid); \
    end \
  end
  `SFX_COV_V(0) `SFX_COV_V(1) `SFX_COV_V(2) `SFX_COV_V(3) `SFX_COV_V(4) `SFX_COV_V(5) `SFX_COV_V(6) `SFX_COV_V(7)
  `SFX_COV_T(0) `SFX_COV_T(1) `SFX_COV_T(2) `SFX_COV_T(3)

  // ============================================================ program interpreter
  string dir;
  logic [31:0] ha_exp = '0, ha_addr = '0;
  logic [63:0] op;
  logic [31:0] tok;
  int fd, rc, rt, maxcyc = 40_000_000;
  initial begin
    int s, v, v2, v3;
    logic [31:0] q; bit e;
    if (!$value$plusargs("dir=%s", dir)) dir = ".";
    if (!$value$plusargs("seed=%d", s)) s = 1;
    for (int i = 0; i < 8; i++) rs[i] = 32'h9E37_79B9 * (s + i * 7919) + 32'h1234_5 + i;
    void'($value$plusargs("lat_min=%d", lat_min)); void'($value$plusargs("lat_max=%d", lat_max));
    void'($value$plusargs("mem_stall=%d", mem_stall)); void'($value$plusargs("cpu_rate=%d", cpu_rate));
    mem_stall0 = mem_stall; cpu_rate0 = cpu_rate;
    void'($value$plusargs("cmd_gap=%d", cmd_gap)); void'($value$plusargs("cpl_rate=%d", cpl_rate));
    void'($value$plusargs("maxcyc=%d", maxcyc));
    if ($value$plusargs("cpu_lo=%h", v)) cpu_lo = v;
    if ($value$plusargs("err_lo=%h", v)) err_lo = v;
    if ($value$plusargs("err_hi=%h", v)) err_hi = v;
    $readmemh({dir, "/mem_init.hex"}, mem);
    fd_r = $fopen({dir, "/records.txt"}, "w");
    fd = $fopen({dir, "/prog.txt"}, "r");
    repeat (4) @(posedge clk);
    @(negedge clk) rst_n = 1'b1;
    repeat (4) @(posedge clk);
    // identification of the shell and of every populated cluster page; unmapped page refused
    rd32(SHELL + 32'h000, q); if (q != `SFX_CC_ID) `ERR(("shell ID %h", q))
    for (int id = 0; id < NSLOT; id++) if ((id < 8 && id < NV) || (id >= 8 && id - 8 < NT)) begin
      rd32(page_of(id), q);
      if (q != ((id < 8) ? 32'h5346_4854 : 32'h5346_5443)) `ERR(("cluster %0d ID %h", id, q))
    end
    rb(1'b0, 32'h3000, 32'd0, q, e); if (!e) `ERR(("unmapped register page accepted"))
    rt = 1;
    while (!$feof(fd) && rt == 1) begin
      rt = $fscanf(fd, "%s", op);
      if (rt == 1) case (op)
        64'("C"): begin
          logic [383:0] d;
          rc = $fscanf(fd, "%d", v);
          for (int i = 0; i < 12; i++) begin rc = $fscanf(fd, "%h", tok); d[32 * i +: 32] = tok; end
          n_sent = n_sent + 1;
          if (CMD_IF == 0) legacy_submit(v, d);
          else begin cq_d.push_back(d); cq_t.push_back(4'(v)); end
        end
        64'("S"): begin rc = $fscanf(fd, "%d", v); wait_cpl(v); end
        64'("Q"): begin
          wait_cpl(n_sent - n_lost);
          do begin
            if (CMD_IF == 0) legacy_collect(); else @(posedge clk);
          end while (cl_busy != '0 || cq_d.size() != 0 || cmd_valid);
          wait_cpl(n_sent - n_lost);
        end
        64'("WR"): begin rc = $fscanf(fd, "%h %h", v, v2); wr32(v, v2); end
        64'("WE"): begin
          rc = $fscanf(fd, "%h %h", v, v2); rb(1'b1, v, v2, q, e);
          if (!e) `ERR(("register write %h accepted, refusal expected", v))
        end
        64'("RD"): begin
          rc = $fscanf(fd, "%h %h %h", v, v2, v3); rd32(v, q);
          if ((q & v3) != v2) `ERR(("register %h = %h, expected %h (mask %h)", v, q, v2, v3))
        end
        64'("RS"): begin rc = $fscanf(fd, "%h", v); rd32(v, q); $fdisplay(fd_r, "L %h %h", v, q); end
        64'("PW"): begin
          longint t0; t0 = cyc;
          rc = $fscanf(fd, "%h %h %h", v, v2, v3);
          do begin
            if (CMD_IF == 0) legacy_collect();
            rd32(v, q);
          end while ((q & v2) != v3 && cyc - t0 < 2_000_000);
          if ((q & v2) != v3) `ERR(("poll %h: %h never matched %h/%h", v, q, v3, v2))
        end
        64'("HW"): begin
          rc = $fscanf(fd, "%h %h", v, v2); host(1'b1, v, v2, q, e);
          if (e) `ERR(("host write %h: error response", v))
        end
        64'("HR"): begin
          rc = $fscanf(fd, "%h %h", v, v2); host(1'b0, v, 32'd0, q, e);
          if (e || q != v2) `ERR(("host read %h: %h err %0d, expected %h", v, q, e, v2))
        end
        64'("HA"): begin                                   // asynchronous host read, checked by HJ
          rc = $fscanf(fd, "%h %h", v, v2); ha_exp = v2; ha_addr = v;
          @(negedge clk); fg_addr = v; fg_wr = 1'b0; fg_done = 1'b0; fg_req = 1'b1;
        end
        64'("HJ"): begin
          while (!fg_done) @(negedge clk);
          if (fg_err || fg_rd != ha_exp) `ERR(("async host read %h: %h err %0d, expected %h", ha_addr, fg_rd, fg_err, ha_exp))
          fg_done = 1'b0;
        end
        64'("HRDY"): begin rc = $fscanf(fd, "%d", v); h_rdy = v[0]; end
        64'("CPU"): begin rc = $fscanf(fd, "%d", v); cpu_rate = (v < 0) ? cpu_rate0 : v; end
        64'("HE"): begin
          rc = $fscanf(fd, "%h", v); host(1'b0, v, 32'd0, q, e);
          if (!e) `ERR(("host read %h: no error response, expected one", v))
        end
        64'("X"): begin
          rc = $fscanf(fd, "%d", v);
          wr32(SHELL + 32'h020, 32'd1 << v);
          $fdisplay(fd_r, "X %0d", v);
          while (!cl_in_reset[v]) @(posedge clk);
          repeat (2) @(posedge clk);                        // LOST is captured one edge after IN_RESET rises
          rd32(SHELL + 32'h080 + 32'(4 * v), q);
          $fdisplay(fd_r, "L %h %h", SHELL + 32'h080 + 32'(4 * v), q);
          n_lost = n_lost + int'(q);
        end
        64'("XW"): begin rc = $fscanf(fd, "%d", v); while (cl_in_reset[v]) @(posedge clk); end
        64'("WB"): begin
          longint t0; t0 = cyc;
          rc = $fscanf(fd, "%d", v);
          while (!cl_busy[v] && cyc - t0 < 1_000_000) @(posedge clk);
          if (!cl_busy[v]) `ERR(("cluster %0d never became busy", v))
        end
        64'("D"): begin rc = $fscanf(fd, "%d", v); repeat (v) @(posedge clk); end
        64'("MS"): begin rc = $fscanf(fd, "%d", v); mem_stall = (v < 0) ? mem_stall0 : v; end
        64'("I"): begin
          rc = $fscanf(fd, "%d", v); repeat (3) @(posedge clk);
          if (irq != v[0]) `ERR(("irq = %0d, expected %0d", irq, v))
        end
        default: `ERR(("unknown op %s", op))
      endcase
    end
    cpu_rate = 0;
    repeat (50) @(posedge clk);
    $fclose(fd); $fclose(fd_r);
    $writememh({dir, "/mem_final.hex"}, mem);
    for (int m = 0; m < NM; m++) if (viol_m[m] != 0) `ERR(("SFB2 violations at crossbar master %0d: %0d", m, viol_m[m]))
    for (int x = 0; x < NS; x++) if (viol_s[x] != 0) `ERR(("SFB2 violations at crossbar slave %0d: %0d", x, viol_s[x]))
    if (viol_x != 0) `ERR(("SFB2 violations at the shared-memory port: %0d", viol_x))
    if (n_acc != n_sent && CMD_IF != 0) `ERR(("%0d commands sent, %0d accepted", n_sent, n_acc))
    if (n_cpl + n_lost != n_sent) `ERR(("%0d commands sent, %0d completed, %0d destroyed by resets", n_sent, n_cpl, n_lost))
    begin
      int fp; fp = $fopen({dir, "/stats.txt"}, "w");
      for (int i = 0; i < NM; i++)
        $fdisplay(fp, "master%0d accepted %0d stall_cycles %0d arb_losses %0d", i, accn[i], stall[i], loss[i]);
      $fdisplay(fp, "vector_and_tensor_busy_cycles %0d", v_and_t_busy);
      $fdisplay(fp, "multi_busy_cycles %0d", multi_busy);
      $fdisplay(fp, "max_clusters_busy %0d", max_busy);
      $fdisplay(fp, "host_transactions %0d", n_cpu);
      $fdisplay(fp, "mem_transactions %0d mem_errors %0d", n_mem, n_mem_err);
      $fdisplay(fp, "completions %0d sent %0d", n_cpl, n_sent);
      for (int i = 0; i < NSLOT; i++) if ((i < 8 && i < NV) || (i >= 8 && i - 8 < NT)) begin
        $write("");
        $fdisplay(fp, "events %0d %0d %0d %0d %0d %0d %0d %0d %0d", i, ev_tot[i*8+0], ev_tot[i*8+1], ev_tot[i*8+2],
                  ev_tot[i*8+3], ev_tot[i*8+4], ev_tot[i*8+5], ev_tot[i*8+6], ev_tot[i*8+7]);
      end
      $fdisplay(fp, "cover iso_req_captured %0d iso_rsp_captured %0d iso_error_responses %0d iso_responses_sunk %0d",
                cov_req_cap, cov_rsp_cap, cov_err_rsp, cov_sunk);
      $fdisplay(fp, "cycles %0d", cyc);
      $fclose(fp);
    end
    $display("TB cycles=%0d completions=%0d sent=%0d vt_busy=%0d max_busy=%0d host=%0d", cyc, n_cpl, n_sent,
             v_and_t_busy, max_busy, n_cpu);
    $display("RESULT %s", (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  always @(posedge clk) if (cyc == longint'(maxcyc)) begin
    `ERR(("TB WATCHDOG")) $display("RESULT FAIL"); $finish;
  end
endmodule
