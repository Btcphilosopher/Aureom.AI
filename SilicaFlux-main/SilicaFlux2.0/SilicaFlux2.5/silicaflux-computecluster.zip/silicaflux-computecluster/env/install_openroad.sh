#!/usr/bin/env bash
# Physical-experiment toolchain, exactly as used for reports/physical.md (FloorplanLab's pinned recipe, reduced):
#   OpenROAD 2.0-12331-g6011bbe77 + Yosys 0.38 (conda litex-hub), ORFS ab2aaf0f sparse checkout (sky130hd platform).
# Simulation / synthesis tools come from Ubuntu 24.04: apt-get install -y iverilog yosys verilator
set -euo pipefail
EDA_ROOT=${EDA_ROOT:-/opt/eda}
MM_URL=https://conda.anaconda.org/conda-forge/linux-64/micromamba-2.10.0-0.tar.bz2
MM_SHA=9a97976244929bbae28fb1fae504e74a3e7e6d1932870e3a03321f01b7fbd07b
ORFS_REV=ab2aaf0fb8513f6f6fa8898ba65ae9599a26e621
mkdir -p "$EDA_ROOT/mamba"
if [ ! -x "$EDA_ROOT/mamba/bin/micromamba" ]; then
  tmp=$(mktemp -d); curl -sSfL -o "$tmp/mm.tar.bz2" "$MM_URL"
  echo "$MM_SHA  $tmp/mm.tar.bz2" | sha256sum -c -
  tar xjf "$tmp/mm.tar.bz2" -C "$EDA_ROOT/mamba" bin/micromamba
fi
if [ ! -x "$EDA_ROOT/env/bin/openroad" ]; then
  printf 'channel_priority: flexible\n' > "$EDA_ROOT/condarc"
  [ -f /root/.ccr/ca-bundle.crt ] && printf 'ssl_verify: /root/.ccr/ca-bundle.crt\n' >> "$EDA_ROOT/condarc"
  MAMBA_ROOT_PREFIX="$EDA_ROOT/mamba" CONDARC="$EDA_ROOT/condarc" "$EDA_ROOT/mamba/bin/micromamba" create -y \
    -p "$EDA_ROOT/env" --override-channels -c litex-hub -c https://repo.anaconda.com/pkgs/main \
    "openroad=2.0_12331_g6011bbe77" "yosys=0.38_93_g84116c9a3" "python=3.10"
fi
"$EDA_ROOT/env/bin/openroad" -version | grep -q 2.0-12331-g6011bbe77
if [ ! -d "$EDA_ROOT/orfs/.git" ]; then
  git clone -q --filter=blob:none --no-checkout https://github.com/The-OpenROAD-Project/OpenROAD-flow-scripts.git "$EDA_ROOT/orfs"
fi
cd "$EDA_ROOT/orfs" && git sparse-checkout init --no-cone
printf '%s\n' /flow/platforms/sky130hd/ /flow/scripts/ /flow/util/ > .git/info/sparse-checkout
git checkout -q "$ORFS_REV"
echo "OpenROAD and the sky130hd platform are ready under $EDA_ROOT"
