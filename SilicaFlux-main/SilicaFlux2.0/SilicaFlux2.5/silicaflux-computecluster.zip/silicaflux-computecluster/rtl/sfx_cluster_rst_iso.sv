// =============================================================================
// SilicaFlux Project 32 :: sfx_cluster_rst_iso
// Cluster-local reset sequencer and bus isolation.  Aureom.AI | SilicaFlux-HPC
//
// A cluster can be reset on its own (shell CL_RESET register) while every other
// cluster, the DataFabric crossbar and the shared memory keep running.  The
// crossbar keeps ONE transaction per port (SFB2 R6) and is not reset, so a
// cluster may never simply vanish with a transaction open: its master port
// would never consume the response (blocking the memory slave for everybody)
// and its local-memory slave port would never answer the host.
//
//   unit (local reset) ◄──► sfx_cluster_rst_iso ◄──► slices / fabric (global reset)
//
//   RUN    pass-through on both ports; counts master transactions outstanding (m_out) and
//          slave transactions owed (s_pend).
//   rst_req -> ISOLATE+RESET (same edge): the unit is held in reset (local_rst_n = 0) for at least
//          HOLD cycles and while rst_req is high.  Master port: a request the unit was presenting and
//          the fabric had not yet accepted is captured and kept presented, unchanged, until accepted
//          (SFB2 R2: no withdrawal); no other request is presented; every response still owed to the
//          unit is consumed and dropped (rsp_ready = 1).  Slave port: a response the unit was presenting
//          and the fabric had not yet accepted is captured and kept, unchanged, until accepted (R4);
//          every other request still owed by the unit, and every new one, is answered with
//          rsp_error = 1 (one at a time, 1 cycle after acceptance, R5/R8) — never a hang, never
//          silent data.
//   release when HOLD elapsed, rst_req low, nothing captured, m_out = 0 and s_pend = 0; no slave request is accepted
//          in the release cycle, so the unit starts with no transaction open on either port.
// The unit's reset: local_rst_n = rst_n AND NOT iso_q — asynchronous assert (global), synchronous
// assert/release from a flip-flop (local); the SilicaFlux reset convention.
// Commands destroyed by the reset produce no completion (TENSORCORE 08 convention); the shell
// counts them (LOST registers).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sfx_cluster_rst_iso #(
  parameter int  DW      = 32,
  parameter int  AW      = 32,
  parameter int  HAS_SLV = 1,        // 1: a local-memory slave port is isolated as well
  parameter int  HOLD    = 8,        // minimum cycles in reset (>= 2)
  localparam int SB      = DW / 8
) (
  input  wire logic          clk,
  input  wire logic          rst_n,          // global reset
  input  wire logic          rst_req,        // cluster reset request (level, synchronous)
  output logic               local_rst_n,    // reset of the unit and of the cluster control
  output logic               in_reset,       // registered: cluster held in reset / isolated
  output logic               active,         // registered: in reset or a transaction open on a port
  // ---------------------------------------------------------- master: unit side
  input  wire logic          um_req_valid,
  output logic               um_req_ready,
  input  wire logic          um_req_write,
  input  wire logic [AW-1:0] um_req_addr,
  input  wire logic [DW-1:0] um_req_wdata,
  input  wire logic [SB-1:0] um_req_wstrb,
  output logic               um_rsp_valid,
  input  wire logic          um_rsp_ready,
  output logic [DW-1:0]      um_rsp_rdata,
  output logic               um_rsp_error,
  // ---------------------------------------------------------- master: fabric side
  output logic               fm_req_valid,
  input  wire logic          fm_req_ready,
  output logic               fm_req_write,
  output logic [AW-1:0]      fm_req_addr,
  output logic [DW-1:0]      fm_req_wdata,
  output logic [SB-1:0]      fm_req_wstrb,
  input  wire logic          fm_rsp_valid,
  output logic               fm_rsp_ready,
  input  wire logic [DW-1:0] fm_rsp_rdata,
  input  wire logic          fm_rsp_error,
  // ---------------------------------------------------------- slave: fabric side
  input  wire logic          fs_req_valid,
  output logic               fs_req_ready,
  input  wire logic          fs_req_write,
  input  wire logic [AW-1:0] fs_req_addr,
  input  wire logic [DW-1:0] fs_req_wdata,
  input  wire logic [SB-1:0] fs_req_wstrb,
  output logic               fs_rsp_valid,
  input  wire logic          fs_rsp_ready,
  output logic [DW-1:0]      fs_rsp_rdata,
  output logic               fs_rsp_error,
  // ---------------------------------------------------------- slave: unit side
  output logic               us_req_valid,
  input  wire logic          us_req_ready,
  output logic               us_req_write,
  output logic [AW-1:0]      us_req_addr,
  output logic [DW-1:0]      us_req_wdata,
  output logic [SB-1:0]      us_req_wstrb,
  input  wire logic          us_rsp_valid,
  output logic               us_rsp_ready,
  input  wire logic [DW-1:0] us_rsp_rdata,
  input  wire logic          us_rsp_error
);
  if (HOLD < 2 || HOLD > 255) begin : g_err_hold
    `SRAM_CFG_FATAL("sfx_cluster_rst_iso: HOLD must be 2..255")
  end
  if (HAS_SLV != 0 && HAS_SLV != 1) begin : g_err_has_slv
    `SRAM_CFG_FATAL("sfx_cluster_rst_iso: HAS_SLV must be 0 or 1")
  end

  logic       iso_q;
  logic [7:0] cnt_q;
  logic [5:0] m_out_q;
  logic [3:0] s_pend_q;
  wire        entering = !iso_q && rst_req;
  // request captured on entry (master port) / response captured on entry (slave port)
  logic          mh_v_q, mh_w_q, sh_v_q;
  logic [AW-1:0] mh_a_q;
  logic [DW-1:0] mh_d_q;
  logic [SB-1:0] mh_s_q;
  /* verilator lint_off UNUSEDSIGNAL */
  logic          sh_e_q;                          // unused without a slave port (HAS_SLV = 0)
  logic [DW-1:0] sh_d_q;
  /* verilator lint_on UNUSEDSIGNAL */
  wire        release_c = iso_q && cnt_q == 8'd0 && !rst_req && m_out_q == 6'd0 && s_pend_q == 4'd0 &&
                          !mh_v_q && !sh_v_q;

  assign local_rst_n = rst_n && !iso_q;
  assign in_reset    = iso_q;

  // ============================================================ master port
  assign fm_req_valid = iso_q ? mh_v_q : um_req_valid;
  assign um_req_ready = fm_req_ready && !iso_q;
  assign fm_req_write = iso_q ? mh_w_q : um_req_write;
  assign fm_req_addr  = iso_q ? mh_a_q : um_req_addr;
  assign fm_req_wdata = iso_q ? mh_d_q : um_req_wdata;
  assign fm_req_wstrb = iso_q ? mh_s_q : um_req_wstrb;
  assign um_rsp_valid = fm_rsp_valid && !iso_q;
  assign fm_rsp_ready = um_rsp_ready || iso_q;          // isolated: drop responses owed to the unit
  assign um_rsp_rdata = fm_rsp_rdata;
  assign um_rsp_error = fm_rsp_error;
  wire m_acc = fm_req_valid && fm_req_ready;
  wire m_ret = fm_rsp_valid && fm_rsp_ready;

  // ============================================================ slave port
  logic s_acc, s_ret;
  if (HAS_SLV != 0) begin : g_slv
    assign us_req_valid = fs_req_valid && !iso_q;
    assign fs_req_ready = iso_q ? (s_pend_q == 4'd0 && !release_c) : us_req_ready;
    assign us_req_write = fs_req_write;
    assign us_req_addr  = fs_req_addr;
    assign us_req_wdata = fs_req_wdata;
    assign us_req_wstrb = fs_req_wstrb;
    assign fs_rsp_valid = iso_q ? (sh_v_q || s_pend_q != 4'd0) : us_rsp_valid;
    assign fs_rsp_rdata = iso_q ? (sh_v_q ? sh_d_q : '0) : us_rsp_rdata;
    assign fs_rsp_error = iso_q ? (sh_v_q ? sh_e_q : 1'b1) : us_rsp_error;
    assign us_rsp_ready = fs_rsp_ready || iso_q;
    assign s_acc = fs_req_valid && fs_req_ready;
    assign s_ret = fs_rsp_valid && fs_rsp_ready;
  end else begin : g_no_slv
    assign us_req_valid = 1'b0; assign us_req_write = 1'b0; assign us_req_addr = '0; assign us_req_wdata = '0;
    assign us_req_wstrb = '0; assign us_rsp_ready = 1'b1;
    assign fs_req_ready = 1'b0; assign fs_rsp_valid = 1'b0; assign fs_rsp_rdata = '0; assign fs_rsp_error = 1'b0;
    assign s_acc = 1'b0; assign s_ret = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_s = &{1'b0, fs_req_valid, fs_req_write, fs_req_addr, fs_req_wdata, fs_req_wstrb, fs_rsp_ready,
                      us_req_ready, us_rsp_valid, us_rsp_rdata, us_rsp_error};
    /* verilator lint_on UNUSEDSIGNAL */
  end

  // ============================================================ sequencer and counters
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      iso_q <= 1'b0; cnt_q <= 8'd0; m_out_q <= 6'd0; s_pend_q <= 4'd0; active <= 1'b0;
      mh_v_q <= 1'b0; sh_v_q <= 1'b0;
    end else begin
      m_out_q  <= m_out_q + {5'd0, m_acc} - {5'd0, m_ret};
      s_pend_q <= s_pend_q + {3'd0, s_acc} - {3'd0, s_ret};
      if (!iso_q) begin
        if (rst_req) begin iso_q <= 1'b1; cnt_q <= 8'(HOLD - 1); end
      end else begin
        if (cnt_q != 8'd0) cnt_q <= cnt_q - 8'd1;
        if (release_c) iso_q <= 1'b0;
      end
      // entry: keep an un-accepted request presented (R2) and an un-accepted response held (R4)
      if (entering && fm_req_valid && !fm_req_ready) mh_v_q <= 1'b1;
      else if (iso_q && mh_v_q && fm_req_ready)      mh_v_q <= 1'b0;
      if (entering && HAS_SLV != 0 && fs_rsp_valid && !fs_rsp_ready) sh_v_q <= 1'b1;
      else if (iso_q && sh_v_q && fs_rsp_ready)                      sh_v_q <= 1'b0;
      active <= iso_q || rst_req || (m_out_q + {5'd0, m_acc} - {5'd0, m_ret}) != 6'd0 ||
                (s_pend_q + {3'd0, s_acc} - {3'd0, s_ret}) != 4'd0;
    end
  end

  // captured payloads (no reset: qualified by mh_v_q / sh_v_q)
  always_ff @(posedge clk) begin
    if (entering) begin
      mh_w_q <= um_req_write; mh_a_q <= um_req_addr; mh_d_q <= um_req_wdata; mh_s_q <= um_req_wstrb;
      sh_d_q <= us_rsp_rdata; sh_e_q <= us_rsp_error;
    end
  end

`ifdef SFX_ASSERT
  always @(posedge clk) if (rst_n) begin
    if (m_ret && m_out_q == 6'd0 && !m_acc)
      $error("sfx_cluster_rst_iso: master response with no transaction outstanding");
    if (s_ret && s_pend_q == 4'd0 && !s_acc)
      $error("sfx_cluster_rst_iso: slave response with no transaction owed");
    if (m_out_q == 6'h3F && m_acc) $error("sfx_cluster_rst_iso: master outstanding counter overflow");
    if (s_pend_q == 4'hF && s_acc) $error("sfx_cluster_rst_iso: slave pending counter overflow");
  end
`endif
endmodule

`default_nettype wire
