// =============================================================================
// SilicaFlux Project 32 :: sfx_cpl_arbiter
// Completion egress of the compute shell: the completion streams of every
// cluster (and the shell's error-record source) merged into one valid/ready
// stream tagged with the source cluster ID.  Aureom.AI | SilicaFlux-HPC
//
//   src_valid[i] ─► sfb_arbiter (DataFabric, round robin, grant lock while stalled) ─► mux
//                ─► sfb_skid_buffer (valid, payload AND ready registered) ─► cpl_*
// * Per source, completions keep their order (each source presents one record at a time).
// * Fairness: a waiting source is served after at most NSRC - 1 other completions (sfb_arbiter).
// * A source may withdraw a record before it is accepted (cluster reset): the arbiter's lock is
//   released and the skid buffer only ever captures on a handshake, so nothing is duplicated.
// Latency: 1 cycle (registered output).  Throughput: one completion per cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cluster_defs.svh"
`default_nettype none

module sfx_cpl_arbiter #(
  parameter int  NSRC = `SFX_NSLOT + 1,
  localparam int PW   = `SFX_CPL_W,
  localparam int IDW  = `SFX_ID_W,
  localparam int IW   = (NSRC > 1) ? $clog2(NSRC) : 1
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  input  wire logic [NSRC-1:0]     src_valid,
  output logic      [NSRC-1:0]     src_ready,
  input  wire logic [NSRC-1:0]     src_err,
  input  wire logic [NSRC*IDW-1:0] src_id,
  input  wire logic [NSRC*PW-1:0]  src_data,
  output logic                     cpl_valid,
  input  wire logic                cpl_ready,
  output logic [IDW-1:0]           cpl_src,
  output logic                     cpl_err,
  output logic [PW-1:0]            cpl_data
);
  logic [NSRC-1:0] grant;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [IW-1:0]   gidx;                         // the one-hot grant drives the mux
  /* verilator lint_on UNUSEDSIGNAL */
  logic            gv, sk_ready;

  sfb_arbiter #(.N(NSRC), .MODE(1)) u_arb (
    .clk(clk), .rst_n(rst_n), .req(src_valid), .stall(gv && !sk_ready), .accept(gv && sk_ready),
    .grant(grant), .grant_idx(gidx), .grant_valid(gv));

  assign src_ready = sk_ready ? grant : '0;

  logic [IDW-1:0] m_id;
  logic           m_err;
  logic [PW-1:0]  m_data;
  always_comb begin
    m_id = '0; m_err = 1'b0; m_data = '0;
    for (int i = 0; i < NSRC; i++) if (grant[i]) begin
      m_id = src_id[i * IDW +: IDW]; m_err = src_err[i]; m_data = src_data[i * PW +: PW];
    end
  end

  sfb_skid_buffer #(.WIDTH(IDW + 1 + PW)) u_out (
    .clk(clk), .rst_n(rst_n), .s_valid(gv), .s_ready(sk_ready), .s_data({m_id, m_err, m_data}),
    .m_valid(cpl_valid), .m_ready(cpl_ready), .m_data({cpl_src, cpl_err, cpl_data}));
endmodule

`default_nettype wire
