// =============================================================================
// SilicaFlux Project 32 :: silicaflux_vector_cluster
// One replicable, floorplan-friendly FP32 vector compute region.
// Aureom.AI | SilicaFlux-HPC
//
//            cluster boundary (faces the shell / NoC)
//   cmd_* ─────────┐   ┌──────── cpl_*            csr_* (host register page)
//                  ▼   │                              │
//   ┌──────────────────┴──────────────────────────────▼─────────────────────────┐
//   │ u_ctrl  sfx_cluster_ctrl   command / completion streams ◄─► unit rb page    │ local control
//   │ u_rst   sfx_cluster_rst_iso   cluster reset, port isolation, counters      │
//   │ ┌───────────────────────────────────────────────────────────────────────┐  │
//   │ │ u_tile  silicaflux_hpc_tile (HPC Module 08, UNMODIFIED)               │  │ compute region:
//   │ │   vector array (M03, NUM_LANES x M02 FP32 lanes) ◄─► LSU              │  │ lanes next to their
//   │ │   banked scratchpad (M04)  ◄─► DMA adapter (M05) ◄─► command queue    │  │ local scratchpad
//   │ └──────────┬───────────────────────────────────────────────▲────────────┘  │
//   │ u_mem_slice│ (sfb_reg_slice, MEM_PIPE)          u_lm_slice  │ (LM_PIPE)    │
//   └────────────▼───────────────────────────────────────────────┴──────────────┘
//            mem_* SFB2 master (DMA -> NoC)              lm_* SFB2 slave (scratchpad window <- NoC)
//
// Interfaces (docs/02_CLUSTER_INTERFACE.md): clock / reset (+ cl_rst_req), command request
// (cmd_*: 8-word HPC Module 08 descriptor), command completion (cpl_*: 6-word record), memory
// request / response (mem_*), optional local memory (lm_*), host CSR page (csr_*), interrupt /
// error status (irq, busy, halted, in_reset, err_ev), clock-enable request (clk_req), performance
// events (perf_ev, SFX_EV_*).  Status / event outputs are registered at the boundary (1 cycle).
//
// PRESENT = 0 elaborates an empty slot (no cells, constant outputs) so the shell's instance
// names never move when the configuration changes.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "hpc_spm_defs.svh"
`include "sfx_cluster_defs.svh"
`default_nettype none

module silicaflux_vector_cluster #(
  parameter int          PRESENT              = 1,
  // ------------------------------------------------------------ compute (HPC Module 08 tile)
  parameter int          NUM_LANES            = 4,           // 1, 2, 4, 8, 16 FP32 lanes
  parameter int          DATA_WIDTH           = 32,          // transaction width: 32, 64, 128
  parameter int          SCRATCHPAD_BYTES     = 65536,       // local scratchpad capacity
  parameter int          NUM_BANKS            = 4,
  parameter int          CMD_QUEUE_DEPTH      = 8,
  parameter int          CPL_QUEUE_DEPTH      = 8,
  parameter int          DMA_BUFFER_DEPTH     = 0,
  parameter int          ENABLE_PERF_COUNTERS = 1,
  parameter logic [31:0] SPM_BASE             = 32'h2000_0000, // this cluster's scratchpad window
  parameter int          SPM_BACKEND          = `SRAM_BACKEND_GENERIC,
  // ------------------------------------------------------------ cluster
  parameter int          LOCAL_MEM_PORT       = 1,           // 1: scratchpad window on lm_* (SFB2 slave)
  parameter int          MEM_PIPE             = 0,           // 1: register slice on mem_* (+1 cycle each way)
  parameter int          LM_PIPE              = 0,           // 1: register slice on lm_*  (+1 cycle each way)
  parameter int          CMD_IF               = 1,           // 1: cmd_* / cpl_* streams; 0: legacy rb page only
  parameter int          RST_HOLD             = 8,
  localparam int         DW                   = DATA_WIDTH,
  localparam int         SB                   = DW / 8,
  localparam int         CMD_W                = 32 * `SFX_VEC_CMD_WORDS,
  localparam int         CPL_W                = `SFX_CPL_W
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             cl_rst_req,
  // ---------------------------------------------------------- command request / completion
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [CMD_W-1:0] cmd_data,
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [CPL_W-1:0]      cpl_data,
  output logic                  cpl_err,
  // ---------------------------------------------------------- host CSR page (SilicaFlux-V rb)
  input  wire logic             csr_sel,
  input  wire logic             csr_we,
  input  wire logic [11:0]      csr_addr,
  input  wire logic [31:0]      csr_wdata,
  output logic [31:0]           csr_rdata,
  output logic                  csr_err,
  // ---------------------------------------------------------- memory request / response (SFB2 master)
  output logic                  mem_req_valid,
  input  wire logic             mem_req_ready,
  output logic                  mem_req_write,
  output logic [31:0]           mem_req_addr,
  output logic [DW-1:0]         mem_req_wdata,
  output logic [SB-1:0]         mem_req_wstrb,
  input  wire logic             mem_rsp_valid,
  output logic                  mem_rsp_ready,
  input  wire logic [DW-1:0]    mem_rsp_rdata,
  input  wire logic             mem_rsp_error,
  // ---------------------------------------------------------- local memory (SFB2 slave, LOCAL_MEM_PORT)
  input  wire logic             lm_req_valid,
  output logic                  lm_req_ready,
  input  wire logic             lm_req_write,
  input  wire logic [31:0]      lm_req_addr,
  input  wire logic [DW-1:0]    lm_req_wdata,
  input  wire logic [SB-1:0]    lm_req_wstrb,
  output logic                  lm_rsp_valid,
  input  wire logic             lm_rsp_ready,
  output logic [DW-1:0]         lm_rsp_rdata,
  output logic                  lm_rsp_error,
  // ---------------------------------------------------------- interrupt / error / status (registered)
  output logic                  irq,
  output logic                  busy,
  output logic                  halted,
  output logic                  in_reset,
  output logic                  err_ev,
  output logic                  clk_req,
  output logic [`SFX_NUM_EV-1:0] perf_ev
);
  if (PRESENT != 0 && PRESENT != 1) begin : g_err_present
    `SRAM_CFG_FATAL("silicaflux_vector_cluster: PRESENT must be 0 or 1")
  end
  if (MEM_PIPE != 0 && MEM_PIPE != 1) begin : g_err_mem_pipe
    `SRAM_CFG_FATAL("silicaflux_vector_cluster: MEM_PIPE must be 0 or 1")
  end
  if (LM_PIPE != 0 && LM_PIPE != 1) begin : g_err_lm_pipe
    `SRAM_CFG_FATAL("silicaflux_vector_cluster: LM_PIPE must be 0 or 1")
  end
  if (LOCAL_MEM_PORT != 0 && LOCAL_MEM_PORT != 1) begin : g_err_lmp
    `SRAM_CFG_FATAL("silicaflux_vector_cluster: LOCAL_MEM_PORT must be 0 or 1")
  end

  if (PRESENT == 0) begin : g_empty
    // ---------------------------------------------------------- unpopulated slot
    assign cmd_ready = 1'b0;  assign cpl_valid = 1'b0;  assign cpl_data = '0;  assign cpl_err = 1'b0;
    assign csr_rdata = 32'd0; assign csr_err = csr_sel;
    assign mem_req_valid = 1'b0; assign mem_req_write = 1'b0; assign mem_req_addr = 32'd0; assign mem_req_wdata = '0;
    assign mem_req_wstrb = '0;   assign mem_rsp_ready = 1'b1;
    assign lm_req_ready = 1'b0;  assign lm_rsp_valid = 1'b0; assign lm_rsp_rdata = '0; assign lm_rsp_error = 1'b0;
    assign irq = 1'b0; assign busy = 1'b0; assign halted = 1'b0; assign in_reset = 1'b0; assign err_ev = 1'b0;
    assign clk_req = 1'b0; assign perf_ev = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_e = &{1'b0, clk, rst_n, cl_rst_req, cmd_valid, cmd_data, cpl_ready, csr_we, csr_addr, csr_wdata,
                      mem_req_ready, mem_rsp_valid, mem_rsp_rdata, mem_rsp_error, lm_req_valid, lm_req_write,
                      lm_req_addr, lm_req_wdata, lm_req_wstrb, lm_rsp_ready};
    /* verilator lint_on UNUSEDSIGNAL */
  end else begin : g_cl
    // ============================================================ local reset and isolation
    logic local_rst_n, iso, rst_active;
    logic          tm_req_valid, tm_req_ready, tm_req_write, tm_rsp_valid, tm_rsp_ready, tm_rsp_error;
    logic [31:0]   tm_req_addr;
    logic [DW-1:0] tm_req_wdata, tm_rsp_rdata;
    logic [SB-1:0] tm_req_wstrb;
    logic          fm_req_valid, fm_req_ready, fm_req_write, fm_rsp_valid, fm_rsp_ready, fm_rsp_error;
    logic [31:0]   fm_req_addr;
    logic [DW-1:0] fm_req_wdata, fm_rsp_rdata;
    logic [SB-1:0] fm_req_wstrb;
    logic          fs_req_valid, fs_req_ready, fs_req_write, fs_rsp_valid, fs_rsp_ready, fs_rsp_error;
    logic [31:0]   fs_req_addr;
    logic [DW-1:0] fs_req_wdata, fs_rsp_rdata;
    logic [SB-1:0] fs_req_wstrb;
    logic          hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error;
    logic [31:0]   hs_req_addr;
    logic [DW-1:0] hs_req_wdata, hs_rsp_rdata;
    logic [SB-1:0] hs_req_wstrb;

    sfx_cluster_rst_iso #(.DW(DW), .AW(32), .HAS_SLV(LOCAL_MEM_PORT), .HOLD(RST_HOLD)) u_rst (
      .clk(clk), .rst_n(rst_n), .rst_req(cl_rst_req), .local_rst_n(local_rst_n), .in_reset(iso),
      .active(rst_active),
      .um_req_valid(tm_req_valid), .um_req_ready(tm_req_ready), .um_req_write(tm_req_write),
      .um_req_addr(tm_req_addr), .um_req_wdata(tm_req_wdata), .um_req_wstrb(tm_req_wstrb),
      .um_rsp_valid(tm_rsp_valid), .um_rsp_ready(tm_rsp_ready), .um_rsp_rdata(tm_rsp_rdata),
      .um_rsp_error(tm_rsp_error),
      .fm_req_valid(fm_req_valid), .fm_req_ready(fm_req_ready), .fm_req_write(fm_req_write),
      .fm_req_addr(fm_req_addr), .fm_req_wdata(fm_req_wdata), .fm_req_wstrb(fm_req_wstrb),
      .fm_rsp_valid(fm_rsp_valid), .fm_rsp_ready(fm_rsp_ready), .fm_rsp_rdata(fm_rsp_rdata),
      .fm_rsp_error(fm_rsp_error),
      .fs_req_valid(fs_req_valid), .fs_req_ready(fs_req_ready), .fs_req_write(fs_req_write),
      .fs_req_addr(fs_req_addr), .fs_req_wdata(fs_req_wdata), .fs_req_wstrb(fs_req_wstrb),
      .fs_rsp_valid(fs_rsp_valid), .fs_rsp_ready(fs_rsp_ready), .fs_rsp_rdata(fs_rsp_rdata),
      .fs_rsp_error(fs_rsp_error),
      .us_req_valid(hs_req_valid), .us_req_ready(hs_req_ready), .us_req_write(hs_req_write),
      .us_req_addr(hs_req_addr), .us_req_wdata(hs_req_wdata), .us_req_wstrb(hs_req_wstrb),
      .us_rsp_valid(hs_rsp_valid), .us_rsp_ready(hs_rsp_ready), .us_rsp_rdata(hs_rsp_rdata),
      .us_rsp_error(hs_rsp_error));

    // ============================================================ local control
    logic        c_cmd_ready, c_cpl_valid, c_cpl_err, c_csr_err, ctrl_idle;
    logic [CPL_W-1:0] c_cpl_data;
    logic [31:0] c_csr_rdata;
    logic        u_sel, u_we, u_err;
    logic [11:0] u_addr;
    logic [31:0] u_wdata, u_rdata;
    /* verilator lint_off UNUSEDSIGNAL */
    logic        cpl_seen_u;
    /* verilator lint_on UNUSEDSIGNAL */
    sfx_cluster_ctrl #(
      .CMD_IF(CMD_IF), .DESC_WORDS(`SFX_VEC_CMD_WORDS), .CPL_WORDS(`SFX_CPL_WORDS),
      .A_STATUS(12'h028), .A_DESC0(12'h080), .A_DOORBELL(12'h0A0), .A_CPL0(12'h040), .A_CPL_POP(12'h058),
      .SB_CPL_VALID(5), .BLOCK_MASK(32'h0000_0018), .ERR_LSB(8), .ERR_BITS(4)
    ) u_ctrl (
      .clk(clk), .rst_n(local_rst_n),
      .cmd_valid(cmd_valid && !iso), .cmd_ready(c_cmd_ready), .cmd_data(cmd_data),
      .cpl_valid(c_cpl_valid), .cpl_ready(cpl_ready), .cpl_data(c_cpl_data), .cpl_err(c_cpl_err),
      .csr_sel(csr_sel && !iso), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata),
      .csr_rdata(c_csr_rdata), .csr_err(c_csr_err),
      .u_sel(u_sel), .u_we(u_we), .u_addr(u_addr), .u_wdata(u_wdata), .u_rdata(u_rdata), .u_err(u_err),
      .idle(ctrl_idle), .cpl_seen(cpl_seen_u));
    assign cmd_ready = c_cmd_ready && !iso;
    assign cpl_valid = c_cpl_valid && !iso;
    assign cpl_data  = c_cpl_data;
    assign cpl_err   = c_cpl_err;
    assign csr_rdata = iso ? 32'd0 : c_csr_rdata;
    assign csr_err   = iso ? csr_sel : c_csr_err;          // cluster in reset: register page refused

    // ============================================================ compute region (HPC Module 08, unmodified)
    logic t_irq, t_busy, t_halted;
    silicaflux_hpc_tile #(
      .NUM_LANES(NUM_LANES), .DATA_WIDTH(DATA_WIDTH), .SCRATCHPAD_BYTES(SCRATCHPAD_BYTES), .NUM_BANKS(NUM_BANKS),
      .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .DMA_BUFFER_DEPTH(DMA_BUFFER_DEPTH),
      .ENABLE_PERF_COUNTERS(ENABLE_PERF_COUNTERS), .SPM_BASE(SPM_BASE), .CPL_QUEUE_DEPTH(CPL_QUEUE_DEPTH),
      .HOST_SPM_PORT(LOCAL_MEM_PORT), .SPM_BACKEND(SPM_BACKEND)
    ) u_tile (
      .clk(clk), .rst_n(local_rst_n),
      .rb_sel(u_sel), .rb_we(u_we), .rb_addr(u_addr), .rb_wdata(u_wdata), .rb_rdata(u_rdata), .rb_err(u_err),
      .hs_req_valid(hs_req_valid), .hs_req_ready(hs_req_ready), .hs_req_write(hs_req_write),
      .hs_req_addr(hs_req_addr), .hs_req_wdata(hs_req_wdata), .hs_req_wstrb(hs_req_wstrb),
      .hs_rsp_valid(hs_rsp_valid), .hs_rsp_ready(hs_rsp_ready), .hs_rsp_rdata(hs_rsp_rdata),
      .hs_rsp_error(hs_rsp_error),
      .fab_req_valid(tm_req_valid), .fab_req_ready(tm_req_ready), .fab_req_write(tm_req_write),
      .fab_req_addr(tm_req_addr), .fab_req_wdata(tm_req_wdata), .fab_req_wstrb(tm_req_wstrb),
      .fab_rsp_valid(tm_rsp_valid), .fab_rsp_ready(tm_rsp_ready), .fab_rsp_rdata(tm_rsp_rdata),
      .fab_rsp_error(tm_rsp_error),
      .irq(t_irq), .busy(t_busy), .halted(t_halted));

    // ============================================================ NoC-facing pipeline boundaries (global reset)
    sfb_reg_slice #(.AW(32), .DW(DW), .REQ_SLICE(MEM_PIPE), .RSP_SLICE(MEM_PIPE)) u_mem_slice (
      .clk(clk), .rst_n(rst_n),
      .s_req_valid(fm_req_valid), .s_req_ready(fm_req_ready), .s_req_write(fm_req_write), .s_req_addr(fm_req_addr),
      .s_req_wdata(fm_req_wdata), .s_req_wstrb(fm_req_wstrb), .s_rsp_valid(fm_rsp_valid), .s_rsp_ready(fm_rsp_ready),
      .s_rsp_rdata(fm_rsp_rdata), .s_rsp_error(fm_rsp_error),
      .m_req_valid(mem_req_valid), .m_req_ready(mem_req_ready), .m_req_write(mem_req_write),
      .m_req_addr(mem_req_addr), .m_req_wdata(mem_req_wdata), .m_req_wstrb(mem_req_wstrb),
      .m_rsp_valid(mem_rsp_valid), .m_rsp_ready(mem_rsp_ready), .m_rsp_rdata(mem_rsp_rdata),
      .m_rsp_error(mem_rsp_error));

    if (LOCAL_MEM_PORT != 0) begin : g_lm
      sfb_reg_slice #(.AW(32), .DW(DW), .REQ_SLICE(LM_PIPE), .RSP_SLICE(LM_PIPE)) u_lm_slice (
        .clk(clk), .rst_n(rst_n),
        .s_req_valid(lm_req_valid), .s_req_ready(lm_req_ready), .s_req_write(lm_req_write),
        .s_req_addr(lm_req_addr), .s_req_wdata(lm_req_wdata), .s_req_wstrb(lm_req_wstrb),
        .s_rsp_valid(lm_rsp_valid), .s_rsp_ready(lm_rsp_ready), .s_rsp_rdata(lm_rsp_rdata),
        .s_rsp_error(lm_rsp_error),
        .m_req_valid(fs_req_valid), .m_req_ready(fs_req_ready), .m_req_write(fs_req_write),
        .m_req_addr(fs_req_addr), .m_req_wdata(fs_req_wdata), .m_req_wstrb(fs_req_wstrb),
        .m_rsp_valid(fs_rsp_valid), .m_rsp_ready(fs_rsp_ready), .m_rsp_rdata(fs_rsp_rdata),
        .m_rsp_error(fs_rsp_error));
    end else begin : g_no_lm
      assign lm_req_ready = 1'b0; assign lm_rsp_valid = 1'b0; assign lm_rsp_rdata = '0; assign lm_rsp_error = 1'b0;
      assign fs_req_valid = 1'b0; assign fs_req_write = 1'b0; assign fs_req_addr = 32'd0; assign fs_req_wdata = '0;
      assign fs_req_wstrb = '0;   assign fs_rsp_ready = 1'b1;
      /* verilator lint_off UNUSEDSIGNAL */
      wire unused_lm = &{1'b0, lm_req_valid, lm_req_write, lm_req_addr, lm_req_wdata, lm_req_wstrb, lm_rsp_ready,
                         fs_req_ready, fs_rsp_valid, fs_rsp_rdata, fs_rsp_error};
      /* verilator lint_on UNUSEDSIGNAL */
    end

    // ============================================================ registered status and events (narrow outputs)
    wire cmd_acc = cmd_valid && cmd_ready;
    wire cpl_acc = cpl_valid && cpl_ready;
    logic halted_d;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        irq <= 1'b0; busy <= 1'b0; halted <= 1'b0; in_reset <= 1'b0; err_ev <= 1'b0; clk_req <= 1'b0;
        perf_ev <= '0; halted_d <= 1'b0;
      end else begin
        halted_d <= t_halted;
        irq      <= t_irq && !iso;
        busy     <= (t_busy || !ctrl_idle) && !iso;
        halted   <= t_halted && !iso;
        in_reset <= iso;
        err_ev   <= (cpl_acc && cpl_err) || (t_halted && !halted_d && !iso);
        clk_req  <= t_busy || !ctrl_idle || rst_active;
        perf_ev[`SFX_EV_CMD_ACCEPT] <= cmd_acc;
        perf_ev[`SFX_EV_CPL]        <= cpl_acc;
        perf_ev[`SFX_EV_CPL_ERR]    <= cpl_acc && cpl_err;
        perf_ev[`SFX_EV_BUSY]       <= t_busy && !iso;
        perf_ev[`SFX_EV_MEM_REQ]    <= mem_req_valid && mem_req_ready;
        perf_ev[`SFX_EV_MEM_STALL]  <= mem_req_valid && !mem_req_ready;
        perf_ev[`SFX_EV_LOCAL]      <= lm_req_valid && lm_req_ready;
        perf_ev[`SFX_EV_CMD_STALL]  <= cmd_valid && !cmd_ready;
      end
    end
  end
endmodule

`default_nettype wire
