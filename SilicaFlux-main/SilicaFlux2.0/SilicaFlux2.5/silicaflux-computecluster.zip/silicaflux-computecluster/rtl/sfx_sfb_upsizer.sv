// =============================================================================
// SilicaFlux Project 32 :: sfx_sfb_upsizer
// SFB2 width converter: one narrow (NDW-bit) master onto a wide (WDW-bit)
// fabric.  Aureom.AI | SilicaFlux-HPC
//
// Used to place the TENSORCORE 08 tensor unit (32-bit SFB2 master) on a 64- or
// 128-bit DataFabric (TRANSACTION_WIDTH).  Every narrow transaction becomes
// exactly one wide transaction (SFB2 has no bursts, R10):
//   address  : the lane bits are cleared (wide-aligned, R9); the low two bits are
//              kept, so a misaligned narrow address still reaches the crossbar's
//              alignment check and is answered with a decode error
//   write    : wdata replicated on every lane, wstrb shifted to the addressed lane
//   read     : the addressed lane of rsp_rdata is returned
// The lane of every accepted transaction is kept in an in-order FIFO (responses are
// in order, R5) of DEPTH entries; when it is full no request is presented (the
// upstream master sees req_ready = 0).  Zero added latency; full throughput.
// WDW = NDW: wires.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sfx_sfb_upsizer #(
  parameter int  AW    = 32,
  parameter int  NDW   = 32,
  parameter int  WDW   = 64,
  parameter int  DEPTH = 4,          // transactions in flight below this block (>= the master's own limit)
  localparam int NSB   = NDW / 8,
  localparam int WSB   = WDW / 8,
  localparam int R     = WDW / NDW,
  localparam int LW    = (R > 1) ? $clog2(R) : 1,
  localparam int NOFF  = $clog2(NSB)
) (
  input  wire logic           clk,
  input  wire logic           rst_n,
  // narrow side (from the master)
  input  wire logic           s_req_valid,
  output logic                s_req_ready,
  input  wire logic           s_req_write,
  input  wire logic [AW-1:0]  s_req_addr,
  input  wire logic [NDW-1:0] s_req_wdata,
  input  wire logic [NSB-1:0] s_req_wstrb,
  output logic                s_rsp_valid,
  input  wire logic           s_rsp_ready,
  output logic [NDW-1:0]      s_rsp_rdata,
  output logic                s_rsp_error,
  // wide side (towards the fabric)
  output logic                m_req_valid,
  input  wire logic           m_req_ready,
  output logic                m_req_write,
  output logic [AW-1:0]       m_req_addr,
  output logic [WDW-1:0]      m_req_wdata,
  output logic [WSB-1:0]      m_req_wstrb,
  input  wire logic           m_rsp_valid,
  output logic                m_rsp_ready,
  input  wire logic [WDW-1:0] m_rsp_rdata,
  input  wire logic           m_rsp_error
);
  if (NDW != 32 || (WDW != 32 && WDW != 64 && WDW != 128)) begin : g_err_width
    `SRAM_CFG_FATAL("sfx_sfb_upsizer: NDW must be 32 and WDW 32, 64 or 128")
  end
  if (DEPTH < 1 || DEPTH > 32) begin : g_err_depth
    `SRAM_CFG_FATAL("sfx_sfb_upsizer: DEPTH must be 1..32")
  end

  if (R == 1) begin : g_wire
    assign m_req_valid = s_req_valid;  assign s_req_ready = m_req_ready;  assign m_req_write = s_req_write;
    assign m_req_addr  = s_req_addr;   assign m_req_wdata = s_req_wdata;  assign m_req_wstrb = s_req_wstrb;
    assign s_rsp_valid = m_rsp_valid;  assign m_rsp_ready = s_rsp_ready;  assign s_rsp_rdata = m_rsp_rdata;
    assign s_rsp_error = m_rsp_error;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_w = &{1'b0, clk, rst_n};
    /* verilator lint_on UNUSEDSIGNAL */
  end else begin : g_up
    localparam int PW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
    logic [LW-1:0] lane_q [0:DEPTH-1];
    logic [PW-1:0] wp_q, rp_q;
    logic [PW:0]   cnt_q;
    wire           full = 32'(cnt_q) == DEPTH;
    wire [LW-1:0]  lane = s_req_addr[NOFF +: LW];

    assign m_req_valid = s_req_valid && !full;
    assign s_req_ready = m_req_ready && !full;
    assign m_req_write = s_req_write;
    assign m_req_addr  = {s_req_addr[AW-1:NOFF+LW], {LW{1'b0}}, s_req_addr[NOFF-1:0]};
    assign m_req_wdata = {R{s_req_wdata}};
    assign m_req_wstrb = {{(WSB - NSB){1'b0}}, s_req_wstrb} << (NSB * lane);

    assign s_rsp_valid = m_rsp_valid;
    assign m_rsp_ready = s_rsp_ready;
    assign s_rsp_rdata = m_rsp_rdata[NDW * lane_q[rp_q] +: NDW];
    assign s_rsp_error = m_rsp_error;

    wire push = m_req_valid && m_req_ready;
    wire pop  = m_rsp_valid && m_rsp_ready;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        wp_q <= '0; rp_q <= '0; cnt_q <= '0;
      end else begin
        if (push) wp_q <= (32'(wp_q) == DEPTH - 1) ? '0 : wp_q + 1'b1;
        if (pop)  rp_q <= (32'(rp_q) == DEPTH - 1) ? '0 : rp_q + 1'b1;
        cnt_q <= cnt_q + {{PW{1'b0}}, push} - {{PW{1'b0}}, pop};
      end
    end
    always_ff @(posedge clk) if (push) lane_q[wp_q] <= lane;
`ifdef SFX_ASSERT
    always @(posedge clk) if (rst_n && pop && cnt_q == '0 && !push)
      $error("sfx_sfb_upsizer: response with no transaction in flight");
`endif
  end
endmodule

`default_nettype wire
