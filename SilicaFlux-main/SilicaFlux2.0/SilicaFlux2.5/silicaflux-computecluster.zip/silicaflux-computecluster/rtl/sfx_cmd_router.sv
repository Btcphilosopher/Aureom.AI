// =============================================================================
// SilicaFlux Project 32 :: sfx_cmd_router
// Command ingress of the compute shell: one valid/ready command stream with a
// destination cluster ID, routed to the addressed cluster.  Aureom.AI | SilicaFlux-HPC
//
//   cmd_* ─► [CMD_PIPE: sfb_skid_buffer] ─► q ─┬─► sl_cmd_valid[ID]  (payload broadcast, valid per cluster)
//                                              └─► absent ID: one-entry error-record source (err_*)
// * A command to a populated cluster is accepted when that cluster accepts it (its local
//   control holds one descriptor); the stream stalls otherwise (no head-of-line reordering:
//   commands leave in arrival order).
// * A command to an absent cluster is accepted into the error source, which produces one
//   completion {SFX_SHELL_REC_MAGIC, SFX_SE_BAD_DEST} carrying the command's word 0 (TAG / TID),
//   delivered with cpl_src = that ID and cpl_err = 1 — never dropped silently.
// CMD_PIPE = 1 registers valid, payload and ready at the shell boundary (+1 cycle).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cluster_defs.svh"
`default_nettype none

module sfx_cmd_router #(
  parameter int                   NSLOT        = `SFX_NSLOT,
  parameter logic [NSLOT-1:0]     PRESENT_MASK = {NSLOT{1'b0}},
  parameter int                   CMD_PIPE     = 0,
  localparam int                  CW           = `SFX_CMD_W,
  localparam int                  IDW          = `SFX_ID_W
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ingress
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [IDW-1:0]   cmd_dest,
  input  wire logic [CW-1:0]    cmd_data,
  // to the clusters
  output logic [NSLOT-1:0]      sl_cmd_valid,
  input  wire logic [NSLOT-1:0] sl_cmd_ready,
  output logic [CW-1:0]         sl_cmd_data,
  output logic [NSLOT-1:0]      sl_cmd_wake,      // a command is waiting for this cluster
  // error-record source (to the completion arbiter)
  output logic                  err_valid,
  input  wire logic             err_ready,
  output logic [IDW-1:0]        err_dest,
  output logic [31:0]           err_word0,
  output logic                  ev_bad_dest       // pulse: a command to an absent cluster was accepted
);
  logic           q_valid, q_ready;
  logic [IDW-1:0] q_dest;
  logic [CW-1:0]  q_data;

  if (CMD_PIPE != 0) begin : g_pipe
    sfb_skid_buffer #(.WIDTH(IDW + CW)) u_skid (
      .clk(clk), .rst_n(rst_n), .s_valid(cmd_valid), .s_ready(cmd_ready), .s_data({cmd_dest, cmd_data}),
      .m_valid(q_valid), .m_ready(q_ready), .m_data({q_dest, q_data}));
  end else begin : g_wire
    assign q_valid = cmd_valid; assign cmd_ready = q_ready; assign q_dest = cmd_dest; assign q_data = cmd_data;
  end

  localparam int NID = 1 << IDW;
  wire [NID-1:0] pm_x = {{(NID - NSLOT){1'b0}}, PRESENT_MASK};     // every ID, absent beyond NSLOT
  wire [NID-1:0] rd_x = {{(NID - NSLOT){1'b0}}, sl_cmd_ready};
  wire present = pm_x[q_dest];
  logic e_v_q;
  always_comb begin
    for (int i = 0; i < NSLOT; i++) begin
      sl_cmd_valid[i] = q_valid && present && 32'(q_dest) == i;
      sl_cmd_wake[i]  = sl_cmd_valid[i];
    end
  end
  assign sl_cmd_data = q_data;
  assign q_ready     = present ? rd_x[q_dest] : !e_v_q;

  assign err_valid = e_v_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      e_v_q <= 1'b0; err_dest <= '0; err_word0 <= 32'd0; ev_bad_dest <= 1'b0;
    end else begin
      ev_bad_dest <= 1'b0;
      if (e_v_q && err_ready) e_v_q <= 1'b0;
      if (q_valid && !present && !e_v_q) begin
        e_v_q <= 1'b1; err_dest <= q_dest; err_word0 <= q_data[31:0]; ev_bad_dest <= 1'b1;
      end
    end
  end
endmodule

`default_nettype wire
