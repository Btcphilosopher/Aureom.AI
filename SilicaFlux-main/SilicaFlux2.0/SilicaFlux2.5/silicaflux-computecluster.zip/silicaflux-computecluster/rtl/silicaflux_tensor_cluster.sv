// =============================================================================
// SilicaFlux Project 32 :: silicaflux_tensor_cluster
// One replicable, floorplan-friendly INT8 tensor compute region.
// Aureom.AI | SilicaFlux-HPC
//
//            cluster boundary (faces the shell / NoC)
//   cmd_* ─────────┐   ┌──────── cpl_*            csr_* (host register page)
//                  ▼   │                              │
//   ┌──────────────────┴──────────────────────────────▼─────────────────────────┐
//   │ u_ctrl  sfx_cluster_ctrl   command / completion streams ◄─► unit rb page    │ local control
//   │ u_rst   sfx_cluster_rst_iso   cluster reset, port isolation, counters      │
//   │ ┌───────────────────────────────────────────────────────────────────────┐  │
//   │ │ u_tsu  silicaflux_tensor_unit (TENSORCORE 08, UNMODIFIED)             │  │ compute region:
//   │ │   TC02 systolic array ◄─► TC03 operand buffers / TC04 accumulator     │  │ PE array next to its
//   │ │   TC05 quantiser, TC07 DMA + output buffer, M08 queues + counters     │  │ operand / accumulator
//   │ └──────────┬────────────────────────────────────────────────────────────┘  │ storage (all inside)
//   │ u_upsize   │ sfx_sfb_upsizer: 32-bit unit port -> TRANSACTION_WIDTH        │
//   │ u_mem_slice│ sfb_reg_slice (MEM_PIPE)                                      │
//   └────────────▼──────────────────────────────────────────────────────────────┘
//            mem_* SFB2 master (operand loads / C stores -> NoC)
//
// The operand and output buffers are private to the unit (TENSORCORE 08 ownership rule), so the
// tensor cluster has no local-memory port.  The unit's 20 x 32-bit performance-event bus (perf_ev,
// 640 wires) is reduced inside the cluster to the 8 narrow SFX_EV_* bits; the full counters stay
// readable on the CSR page.
// PRESENT = 0 elaborates an empty slot (no cells, constant outputs).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "tsu_defs.svh"
`include "sfx_cluster_defs.svh"
`default_nettype none

module silicaflux_tensor_cluster #(
  parameter int          PRESENT                 = 1,
  // ------------------------------------------------------------ compute (TENSORCORE 08 tensor unit)
  parameter int          ARRAY_ROWS              = 4,
  parameter int          ARRAY_COLS              = 4,
  parameter int          TILE_K                  = 64,
  parameter int          OPERAND_BUFFER_BYTES    = 2048,
  parameter int          NUM_MEMORY_BANKS        = 4,
  parameter int          ENABLE_QUANTIZATION     = 0,
  parameter int          ENABLE_DOUBLE_BUFFERING = 0,
  parameter int          CMD_QUEUE_DEPTH         = 4,
  parameter int          CPL_QUEUE_DEPTH         = 4,
  parameter logic [32:0] MEM_LO                  = 33'h0_1000_0000,
  parameter logic [32:0] MEM_HI                  = 33'h0_1010_0000,
  parameter int          MAX_OUT                 = 4,
  parameter int          PERF_EN                 = 1,
  parameter int          ALLOW_UNVERIFIED        = 0,
  // ------------------------------------------------------------ cluster
  parameter int          DATA_WIDTH              = 32,     // transaction width of mem_*: 32, 64, 128
  parameter int          MEM_PIPE                = 0,
  parameter int          CMD_IF                  = 1,
  parameter int          RST_HOLD                = 8,
  localparam int         DW                      = DATA_WIDTH,
  localparam int         SB                      = DW / 8,
  localparam int         CMD_W                   = 32 * `SFX_TSU_CMD_WORDS,
  localparam int         CPL_W                   = `SFX_CPL_W
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  input  wire logic             cl_rst_req,
  // ---------------------------------------------------------- command request / completion
  input  wire logic             cmd_valid,
  output logic                  cmd_ready,
  input  wire logic [CMD_W-1:0] cmd_data,
  output logic                  cpl_valid,
  input  wire logic             cpl_ready,
  output logic [CPL_W-1:0]      cpl_data,
  output logic                  cpl_err,
  // ---------------------------------------------------------- host CSR page (SilicaFlux-V rb)
  input  wire logic             csr_sel,
  input  wire logic             csr_we,
  input  wire logic [11:0]      csr_addr,
  input  wire logic [31:0]      csr_wdata,
  output logic [31:0]           csr_rdata,
  output logic                  csr_err,
  // ---------------------------------------------------------- memory request / response (SFB2 master)
  output logic                  mem_req_valid,
  input  wire logic             mem_req_ready,
  output logic                  mem_req_write,
  output logic [31:0]           mem_req_addr,
  output logic [DW-1:0]         mem_req_wdata,
  output logic [SB-1:0]         mem_req_wstrb,
  input  wire logic             mem_rsp_valid,
  output logic                  mem_rsp_ready,
  input  wire logic [DW-1:0]    mem_rsp_rdata,
  input  wire logic             mem_rsp_error,
  // ---------------------------------------------------------- interrupt / error / status (registered)
  output logic                  irq,
  output logic                  busy,
  output logic                  halted,
  output logic                  in_reset,
  output logic                  err_ev,
  output logic                  clk_req,
  output logic [`SFX_NUM_EV-1:0] perf_ev
);
  if (PRESENT != 0 && PRESENT != 1) begin : g_err_present
    `SRAM_CFG_FATAL("silicaflux_tensor_cluster: PRESENT must be 0 or 1")
  end
  if (MEM_PIPE != 0 && MEM_PIPE != 1) begin : g_err_mem_pipe
    `SRAM_CFG_FATAL("silicaflux_tensor_cluster: MEM_PIPE must be 0 or 1")
  end
  if (DATA_WIDTH != 32 && DATA_WIDTH != 64 && DATA_WIDTH != 128) begin : g_err_dw
    `SRAM_CFG_FATAL("silicaflux_tensor_cluster: DATA_WIDTH must be 32, 64 or 128")
  end

  if (PRESENT == 0) begin : g_empty
    assign cmd_ready = 1'b0;  assign cpl_valid = 1'b0;  assign cpl_data = '0;  assign cpl_err = 1'b0;
    assign csr_rdata = 32'd0; assign csr_err = csr_sel;
    assign mem_req_valid = 1'b0; assign mem_req_write = 1'b0; assign mem_req_addr = 32'd0; assign mem_req_wdata = '0;
    assign mem_req_wstrb = '0;   assign mem_rsp_ready = 1'b1;
    assign irq = 1'b0; assign busy = 1'b0; assign halted = 1'b0; assign in_reset = 1'b0; assign err_ev = 1'b0;
    assign clk_req = 1'b0; assign perf_ev = '0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_e = &{1'b0, clk, rst_n, cl_rst_req, cmd_valid, cmd_data, cpl_ready, csr_we, csr_addr, csr_wdata,
                      mem_req_ready, mem_rsp_valid, mem_rsp_rdata, mem_rsp_error};
    /* verilator lint_on UNUSEDSIGNAL */
  end else begin : g_cl
    // ============================================================ local reset and isolation (32-bit unit side)
    logic local_rst_n, iso, rst_active;
    logic        tm_req_valid, tm_req_ready, tm_req_write, tm_rsp_valid, tm_rsp_ready, tm_rsp_error;
    logic [31:0] tm_req_addr, tm_req_wdata, tm_rsp_rdata;
    logic [3:0]  tm_req_wstrb;
    logic        nm_req_valid, nm_req_ready, nm_req_write, nm_rsp_valid, nm_rsp_ready, nm_rsp_error;
    logic [31:0] nm_req_addr, nm_req_wdata, nm_rsp_rdata;
    logic [3:0]  nm_req_wstrb;
    logic          fm_req_valid, fm_req_ready, fm_req_write, fm_rsp_valid, fm_rsp_ready, fm_rsp_error;
    logic [31:0]   fm_req_addr;
    logic [DW-1:0] fm_req_wdata, fm_rsp_rdata;
    logic [SB-1:0] fm_req_wstrb;
    /* verilator lint_off UNUSEDSIGNAL */
    logic        s_req_ready_u, s_rsp_valid_u, s_rsp_error_u, us_req_valid_u, us_req_write_u, us_rsp_ready_u;
    logic [31:0] s_rsp_rdata_u, us_req_addr_u, us_req_wdata_u;
    logic [3:0]  us_req_wstrb_u;
    /* verilator lint_on UNUSEDSIGNAL */

    sfx_cluster_rst_iso #(.DW(32), .AW(32), .HAS_SLV(0), .HOLD(RST_HOLD)) u_rst (
      .clk(clk), .rst_n(rst_n), .rst_req(cl_rst_req), .local_rst_n(local_rst_n), .in_reset(iso),
      .active(rst_active),
      .um_req_valid(tm_req_valid), .um_req_ready(tm_req_ready), .um_req_write(tm_req_write),
      .um_req_addr(tm_req_addr), .um_req_wdata(tm_req_wdata), .um_req_wstrb(tm_req_wstrb),
      .um_rsp_valid(tm_rsp_valid), .um_rsp_ready(tm_rsp_ready), .um_rsp_rdata(tm_rsp_rdata),
      .um_rsp_error(tm_rsp_error),
      .fm_req_valid(nm_req_valid), .fm_req_ready(nm_req_ready), .fm_req_write(nm_req_write),
      .fm_req_addr(nm_req_addr), .fm_req_wdata(nm_req_wdata), .fm_req_wstrb(nm_req_wstrb),
      .fm_rsp_valid(nm_rsp_valid), .fm_rsp_ready(nm_rsp_ready), .fm_rsp_rdata(nm_rsp_rdata),
      .fm_rsp_error(nm_rsp_error),
      .fs_req_valid(1'b0), .fs_req_ready(s_req_ready_u), .fs_req_write(1'b0), .fs_req_addr(32'd0),
      .fs_req_wdata(32'd0), .fs_req_wstrb(4'd0), .fs_rsp_valid(s_rsp_valid_u), .fs_rsp_ready(1'b1),
      .fs_rsp_rdata(s_rsp_rdata_u), .fs_rsp_error(s_rsp_error_u),
      .us_req_valid(us_req_valid_u), .us_req_ready(1'b0), .us_req_write(us_req_write_u),
      .us_req_addr(us_req_addr_u), .us_req_wdata(us_req_wdata_u), .us_req_wstrb(us_req_wstrb_u),
      .us_rsp_valid(1'b0), .us_rsp_ready(us_rsp_ready_u), .us_rsp_rdata(32'd0), .us_rsp_error(1'b0));

    // ============================================================ local control
    logic        c_cmd_ready, c_cpl_valid, c_cpl_err, c_csr_err, ctrl_idle;
    logic [CPL_W-1:0] c_cpl_data;
    logic [31:0] c_csr_rdata;
    logic        u_sel, u_we, u_err;
    logic [11:0] u_addr;
    logic [31:0] u_wdata, u_rdata;
    /* verilator lint_off UNUSEDSIGNAL */
    logic        cpl_seen_u;
    /* verilator lint_on UNUSEDSIGNAL */
    sfx_cluster_ctrl #(
      .CMD_IF(CMD_IF), .DESC_WORDS(`SFX_TSU_CMD_WORDS), .CPL_WORDS(`SFX_CPL_WORDS),
      .A_STATUS(`TSU_R_STATUS), .A_DESC0(`TSU_R_DESC0), .A_DOORBELL(`TSU_R_DOORBELL), .A_CPL0(`TSU_R_CPL0),
      .A_CPL_POP(`TSU_R_CPL_POP), .SB_CPL_VALID(`TSU_SB_CPL_VALID), .BLOCK_MASK(32'h1 << `TSU_SB_Q_FULL),
      .ERR_LSB(24), .ERR_BITS(2)
    ) u_ctrl (
      .clk(clk), .rst_n(local_rst_n),
      .cmd_valid(cmd_valid && !iso), .cmd_ready(c_cmd_ready), .cmd_data(cmd_data),
      .cpl_valid(c_cpl_valid), .cpl_ready(cpl_ready), .cpl_data(c_cpl_data), .cpl_err(c_cpl_err),
      .csr_sel(csr_sel && !iso), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata),
      .csr_rdata(c_csr_rdata), .csr_err(c_csr_err),
      .u_sel(u_sel), .u_we(u_we), .u_addr(u_addr), .u_wdata(u_wdata), .u_rdata(u_rdata), .u_err(u_err),
      .idle(ctrl_idle), .cpl_seen(cpl_seen_u));
    assign cmd_ready = c_cmd_ready && !iso;
    assign cpl_valid = c_cpl_valid && !iso;
    assign cpl_data  = c_cpl_data;
    assign cpl_err   = c_cpl_err;
    assign csr_rdata = iso ? 32'd0 : c_csr_rdata;
    assign csr_err   = iso ? csr_sel : c_csr_err;

    // ============================================================ compute region (TENSORCORE 08, unmodified)
    logic t_irq, t_busy, t_halted;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [`TSU_NUM_PC*32-1:0] t_perf_ev;
    /* verilator lint_on UNUSEDSIGNAL */
    silicaflux_tensor_unit #(
      .ARRAY_ROWS(ARRAY_ROWS), .ARRAY_COLS(ARRAY_COLS), .TILE_K(TILE_K),
      .OPERAND_BUFFER_BYTES(OPERAND_BUFFER_BYTES), .NUM_MEMORY_BANKS(NUM_MEMORY_BANKS),
      .ENABLE_QUANTIZATION(ENABLE_QUANTIZATION), .ENABLE_DOUBLE_BUFFERING(ENABLE_DOUBLE_BUFFERING),
      .CMD_QUEUE_DEPTH(CMD_QUEUE_DEPTH), .CPL_QUEUE_DEPTH(CPL_QUEUE_DEPTH), .MEM_LO(MEM_LO), .MEM_HI(MEM_HI),
      .MAX_OUT(MAX_OUT), .PERF_EN(PERF_EN), .ALLOW_UNVERIFIED(ALLOW_UNVERIFIED)
    ) u_tsu (
      .clk(clk), .rst_n(local_rst_n),
      .rb_sel(u_sel), .rb_we(u_we), .rb_addr(u_addr), .rb_wdata(u_wdata), .rb_rdata(u_rdata), .rb_err(u_err),
      .m_req_valid(tm_req_valid), .m_req_ready(tm_req_ready), .m_req_write(tm_req_write),
      .m_req_addr(tm_req_addr), .m_req_wdata(tm_req_wdata), .m_req_wstrb(tm_req_wstrb),
      .m_rsp_valid(tm_rsp_valid), .m_rsp_ready(tm_rsp_ready), .m_rsp_rdata(tm_rsp_rdata),
      .m_rsp_error(tm_rsp_error),
      .irq(t_irq), .busy(t_busy), .halted(t_halted), .perf_ev(t_perf_ev), .fi_mode(2'd0));

    // ============================================================ width conversion and NoC-facing pipeline (global reset)
    // DEPTH: the unit keeps <= MAX_OUT transactions in flight; a sliced fabric path holds up to 2 more.
    sfx_sfb_upsizer #(.AW(32), .NDW(32), .WDW(DW), .DEPTH(MAX_OUT + 2)) u_upsize (
      .clk(clk), .rst_n(rst_n),
      .s_req_valid(nm_req_valid), .s_req_ready(nm_req_ready), .s_req_write(nm_req_write), .s_req_addr(nm_req_addr),
      .s_req_wdata(nm_req_wdata), .s_req_wstrb(nm_req_wstrb), .s_rsp_valid(nm_rsp_valid), .s_rsp_ready(nm_rsp_ready),
      .s_rsp_rdata(nm_rsp_rdata), .s_rsp_error(nm_rsp_error),
      .m_req_valid(fm_req_valid), .m_req_ready(fm_req_ready), .m_req_write(fm_req_write), .m_req_addr(fm_req_addr),
      .m_req_wdata(fm_req_wdata), .m_req_wstrb(fm_req_wstrb), .m_rsp_valid(fm_rsp_valid), .m_rsp_ready(fm_rsp_ready),
      .m_rsp_rdata(fm_rsp_rdata), .m_rsp_error(fm_rsp_error));

    sfb_reg_slice #(.AW(32), .DW(DW), .REQ_SLICE(MEM_PIPE), .RSP_SLICE(MEM_PIPE)) u_mem_slice (
      .clk(clk), .rst_n(rst_n),
      .s_req_valid(fm_req_valid), .s_req_ready(fm_req_ready), .s_req_write(fm_req_write), .s_req_addr(fm_req_addr),
      .s_req_wdata(fm_req_wdata), .s_req_wstrb(fm_req_wstrb), .s_rsp_valid(fm_rsp_valid), .s_rsp_ready(fm_rsp_ready),
      .s_rsp_rdata(fm_rsp_rdata), .s_rsp_error(fm_rsp_error),
      .m_req_valid(mem_req_valid), .m_req_ready(mem_req_ready), .m_req_write(mem_req_write),
      .m_req_addr(mem_req_addr), .m_req_wdata(mem_req_wdata), .m_req_wstrb(mem_req_wstrb),
      .m_rsp_valid(mem_rsp_valid), .m_rsp_ready(mem_rsp_ready), .m_rsp_rdata(mem_rsp_rdata),
      .m_rsp_error(mem_rsp_error));

    // ============================================================ registered status and events (narrow outputs)
    wire cmd_acc = cmd_valid && cmd_ready;
    wire cpl_acc = cpl_valid && cpl_ready;
    wire computing = |t_perf_ev[`TSU_PC_COMPUTE_CYC * 32 +: 32];
    logic halted_d;
    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        irq <= 1'b0; busy <= 1'b0; halted <= 1'b0; in_reset <= 1'b0; err_ev <= 1'b0; clk_req <= 1'b0;
        perf_ev <= '0; halted_d <= 1'b0;
      end else begin
        halted_d <= t_halted;
        irq      <= t_irq && !iso;
        busy     <= (t_busy || !ctrl_idle) && !iso;
        halted   <= t_halted && !iso;
        in_reset <= iso;
        err_ev   <= (cpl_acc && cpl_err) || (t_halted && !halted_d && !iso);
        clk_req  <= t_busy || !ctrl_idle || rst_active;
        perf_ev[`SFX_EV_CMD_ACCEPT] <= cmd_acc;
        perf_ev[`SFX_EV_CPL]        <= cpl_acc;
        perf_ev[`SFX_EV_CPL_ERR]    <= cpl_acc && cpl_err;
        perf_ev[`SFX_EV_BUSY]       <= t_busy && !iso;
        perf_ev[`SFX_EV_MEM_REQ]    <= mem_req_valid && mem_req_ready;
        perf_ev[`SFX_EV_MEM_STALL]  <= mem_req_valid && !mem_req_ready;
        perf_ev[`SFX_EV_LOCAL]      <= computing && !iso;
        perf_ev[`SFX_EV_CMD_STALL]  <= cmd_valid && !cmd_ready;
      end
    end
  end
endmodule

`default_nettype wire
