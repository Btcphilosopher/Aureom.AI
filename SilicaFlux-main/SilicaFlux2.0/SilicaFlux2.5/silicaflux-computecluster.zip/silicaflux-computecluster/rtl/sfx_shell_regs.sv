// =============================================================================
// SilicaFlux Project 32 :: sfx_shell_regs
// Register page of the compute shell (SilicaFlux-V rb protocol: answered in the
// strobe cycle, side effects at the clock edge, rb_err = refused / no effect).
// Aureom.AI | SilicaFlux-HPC
//
// Map: rtl/sfx_cluster_defs.svh (SFX_R_*), docs/02_CLUSTER_INTERFACE.md section 6.
// * cluster reset (CL_RESET, write-1 pulses) -> cl_rst_req (one-cycle pulse per cluster)
// * sticky per-cluster error status (W1C) from the clusters' err_ev pulses and BAD_DEST
// * aggregated, maskable interrupt
// * INFLIGHT[i] = commands accepted - completions delivered; on entry into a cluster reset it is
//   copied to LOST[i] (commands destroyed by that reset, which produce no completion) and cleared
// * SHELL_PERF = 1: one 32-bit saturating counter per populated cluster and SFX_EV_* event
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sfx_cluster_defs.svh"
`default_nettype none

module sfx_shell_regs #(
  parameter int               NSLOT        = `SFX_NSLOT,
  parameter logic [NSLOT-1:0] PRESENT_MASK = {NSLOT{1'b0}},
  parameter logic [31:0]      CONFIG0      = 32'd0,
  parameter logic [31:0]      CONFIG1      = 32'd0,
  parameter logic [31:0]      SPM_BASE     = 32'd0,
  parameter logic [31:0]      MEM_BASE     = 32'd0,
  parameter int               SHELL_PERF   = 1,
  localparam int              NEV          = `SFX_NUM_EV
) (
  input  wire logic                 clk,
  input  wire logic                 rst_n,
  input  wire logic                 rb_sel,
  input  wire logic                 rb_we,
  input  wire logic [11:0]          rb_addr,
  /* verilator lint_off UNUSEDSIGNAL */
  input  wire logic [31:0]          rb_wdata,         // bits beyond the defined fields are ignored
  /* verilator lint_on UNUSEDSIGNAL */
  output logic [31:0]               rb_rdata,
  output logic                      rb_err,
  // cluster status (registered at the cluster boundaries)
  input  wire logic [NSLOT-1:0]     cl_busy,
  input  wire logic [NSLOT-1:0]     cl_in_reset,
  input  wire logic [NSLOT-1:0]     cl_clk_req,
  input  wire logic [NSLOT-1:0]     cl_irq,
  input  wire logic [NSLOT-1:0]     cl_err_ev,
  input  wire logic [NSLOT*NEV-1:0] cl_perf_ev,
  input  wire logic                 ev_bad_dest,
  // control
  output logic [NSLOT-1:0]          cl_rst_req,
  output logic [NSLOT-1:0]          err_status,
  output logic                      irq
);
  wire aligned = rb_addr[1:0] == 2'b00;
  wire wr      = rb_sel && rb_we && aligned;

  // ============================================================ control / status registers
  logic [NSLOT-1:0] err_q;
  logic             bad_q;
  logic [1:0]       irq_en_q;
  logic [31:0]      bad_cnt_q;
  logic [NSLOT-1:0] in_reset_d;
  logic [15:0]      inflight_q [0:NSLOT-1];
  logic [15:0]      lost_q     [0:NSLOT-1];

  wire a_cl_reset = rb_addr == `SFX_R_CL_RESET;
  wire a_err      = rb_addr == `SFX_R_ERR_STATUS;
  wire a_irq_en   = rb_addr == `SFX_R_IRQ_EN;
  wire a_perf     = rb_addr == `SFX_R_PERF_CTRL;
  /* verilator lint_off UNUSEDSIGNAL */
  wire perf_clr   = wr && a_perf && rb_wdata[0];      // unused when SHELL_PERF = 0
  /* verilator lint_on UNUSEDSIGNAL */

  assign err_status = err_q;

  logic [15:0] inf_nxt [0:NSLOT-1];
  always_comb
    for (int i = 0; i < NSLOT; i++)
      inf_nxt[i] = inflight_q[i] + {15'd0, cl_perf_ev[i * NEV + `SFX_EV_CMD_ACCEPT]}
                                 - {15'd0, cl_perf_ev[i * NEV + `SFX_EV_CPL]};

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      err_q <= '0; bad_q <= 1'b0; irq_en_q <= 2'b00; bad_cnt_q <= 32'd0; cl_rst_req <= '0; in_reset_d <= '0;
      irq <= 1'b0;
      for (int i = 0; i < NSLOT; i++) begin inflight_q[i] <= 16'd0; lost_q[i] <= 16'd0; end
    end else begin
      cl_rst_req <= (wr && a_cl_reset) ? (rb_wdata[NSLOT-1:0] & PRESENT_MASK) : '0;
      in_reset_d <= cl_in_reset;
      // sticky errors: a same-cycle new error wins over the W1C clear
      err_q <= ((wr && a_err) ? (err_q & ~rb_wdata[NSLOT-1:0]) : err_q) | (cl_err_ev & PRESENT_MASK);
      bad_q <= ((wr && a_err && rb_wdata[16]) ? 1'b0 : bad_q) | ev_bad_dest;
      if (ev_bad_dest && bad_cnt_q != 32'hFFFF_FFFF) bad_cnt_q <= bad_cnt_q + 32'd1;
      if (wr && a_irq_en) irq_en_q <= rb_wdata[1:0];
      irq <= (irq_en_q[0] && |(cl_irq & PRESENT_MASK)) || (irq_en_q[1] && (|err_q || bad_q));
      for (int i = 0; i < NSLOT; i++) begin
        if (cl_in_reset[i] && !in_reset_d[i]) begin
          lost_q[i]     <= inf_nxt[i];
          inflight_q[i] <= 16'd0;
        end else inflight_q[i] <= inf_nxt[i];
      end
    end
  end

  // ============================================================ event counters (populated clusters only)
  logic [31:0] evcnt [0:NSLOT*NEV-1];
  for (genvar i = 0; i < NSLOT; i++) begin : g_slot
    for (genvar e = 0; e < NEV; e++) begin : g_ev
      if (SHELL_PERF != 0 && PRESENT_MASK[i]) begin : g_cnt
        logic [31:0] c_q;
        always_ff @(posedge clk or negedge rst_n) begin
          if (!rst_n)                                                c_q <= 32'd0;
          else if (perf_clr)                                         c_q <= 32'd0;
          else if (cl_perf_ev[i * NEV + e] && c_q != 32'hFFFF_FFFF) c_q <= c_q + 32'd1;
        end
        assign evcnt[i * NEV + e] = c_q;
      end else begin : g_none
        assign evcnt[i * NEV + e] = 32'd0;
      end
    end
  end

  // ============================================================ read / refusal decode
  wire        in_inflight = rb_addr >= `SFX_R_INFLIGHT0 && rb_addr < `SFX_R_INFLIGHT0 + 12'(4 * NSLOT);
  wire        in_lost     = rb_addr >= `SFX_R_LOST0 && rb_addr < `SFX_R_LOST0 + 12'(4 * NSLOT);
  wire        in_evcnt    = rb_addr >= `SFX_R_EVCNT0 && rb_addr < `SFX_R_EVCNT0 + 12'(4 * NEV * NSLOT);
  localparam int SIW = $clog2(NSLOT), EIW = $clog2(NSLOT * NEV);
  /* verilator lint_off UNUSEDSIGNAL */
  wire [11:0] o_inf       = rb_addr - `SFX_R_INFLIGHT0;   // word offsets (bits 1:0 are 0 when aligned)
  wire [11:0] o_lost      = rb_addr - `SFX_R_LOST0;
  wire [11:0] o_ev        = rb_addr - `SFX_R_EVCNT0;
  /* verilator lint_on UNUSEDSIGNAL */
  always_comb begin
    rb_rdata = 32'd0;
    rb_err   = 1'b0;
    if (rb_sel) begin
      if (!aligned) rb_err = 1'b1;
      else case (rb_addr)
        `SFX_R_ID:         begin rb_rdata = `SFX_CC_ID;      rb_err = rb_we; end
        `SFX_R_VERSION:    begin rb_rdata = `SFX_CC_VERSION; rb_err = rb_we; end
        `SFX_R_CONFIG0:    begin rb_rdata = CONFIG0;         rb_err = rb_we; end
        `SFX_R_CONFIG1:    begin rb_rdata = CONFIG1;         rb_err = rb_we; end
        `SFX_R_PRESENT:    begin rb_rdata = 32'(PRESENT_MASK); rb_err = rb_we; end
        `SFX_R_BUSY:       begin rb_rdata = 32'(cl_busy);    rb_err = rb_we; end
        `SFX_R_IN_RESET:   begin rb_rdata = 32'(cl_in_reset); rb_err = rb_we; end
        `SFX_R_CLK_REQ:    begin rb_rdata = 32'(cl_clk_req); rb_err = rb_we; end
        `SFX_R_CL_RESET:   rb_rdata = 32'd0;
        `SFX_R_ERR_STATUS: rb_rdata = {15'd0, bad_q, 4'd0, err_q};
        `SFX_R_IRQ_EN:     rb_rdata = {30'd0, irq_en_q};
        `SFX_R_CL_IRQ:     begin rb_rdata = 32'(cl_irq);     rb_err = rb_we; end
        `SFX_R_BAD_DEST:   begin rb_rdata = bad_cnt_q;       rb_err = rb_we; end
        `SFX_R_PERF_CTRL:  rb_rdata = 32'd0;
        `SFX_R_SPM_BASE:   begin rb_rdata = SPM_BASE;        rb_err = rb_we; end
        `SFX_R_MEM_BASE:   begin rb_rdata = MEM_BASE;        rb_err = rb_we; end
        default: begin
          if (in_inflight)                        begin rb_rdata = {16'd0, inflight_q[o_inf[SIW+1:2]]};  rb_err = rb_we; end
          else if (in_lost)                       begin rb_rdata = {16'd0, lost_q[o_lost[SIW+1:2]]};     rb_err = rb_we; end
          else if (in_evcnt && SHELL_PERF != 0)   begin rb_rdata = evcnt[o_ev[EIW+1:2]];                 rb_err = rb_we; end
          else rb_err = 1'b1;
        end
      endcase
    end
  end
endmodule

`default_nettype wire
