// =============================================================================
// SilicaFlux Project 32 :: sfx_cluster_ctrl
// Local control of one compute cluster: command stream -> unit register page,
// unit completion queue -> completion stream, host CSR pass-through.
// Aureom.AI | SilicaFlux-HPC
//
// The verified units (HPC Module 08 tile, TENSORCORE 08 tensor unit) accept
// commands only through their SilicaFlux-V register page (stage DESC words,
// ring DOORBELL) and return completions through CPL registers + CPL_POP.  This
// block drives that page from a valid/ready command stream and turns the
// completion queue into a valid/ready completion stream, so the units are
// reused byte for byte and the arithmetic pipeline is not duplicated.
//
//   cmd_* ──► hold register ──┐                         ┌──► out register ──► cpl_*
//                             ▼                         │
//                     ┌── sequencer (POLL / ISSUE / CPL_RD / CPL_POP) ──┐
//   csr_* (host) ─────┴─► rb mux (host has priority) ──► u_* (unit rb page)
//
// Sequencer (one register-bus access per cycle; stalls in any cycle the host uses the bus):
//   POLL     read STATUS (no side effect).  Completion waiting and output register free -> CPL_RD;
//            command held and STATUS shows the unit can accept (BLOCK_MASK clear) -> ISSUE.
//            Both wanted: alternate (fairness).
//   ISSUE    write DESC0..DESC(N-1), then DOORBELL.  DOORBELL refused (rb_err) -> back to POLL,
//            descriptor kept, retried (never lost).  Accepted -> hold register freed.
//   CPL_RD   read CPL0..CPL5 into the output register.
//   CPL_POP  write CPL_POP; the record is emitted on cpl_* only if the pop is accepted and no host
//            write happened since the first CPL read (a host CTRL write could have flushed or reset
//            the unit's completion queue under the sequence; the record is then re-read from scratch).
// Cost: issue = 1 + N + 1 cycles (vector 10, tensor 14); completion = 1 + 6 + 1 = 8 cycles.
//
// Ownership of the register page (CMD_IF = 1): the host may read every register and write every
// register EXCEPT the descriptor staging window, DOORBELL and CPL_POP, which belong to this block;
// such host writes answer csr_err = 1 and have no effect.  CMD_IF = 0 (legacy): the host owns the
// whole page (exactly the TENSORCORE 08 / HPC Module 08 programming model), the streams are tied off.
//
// One clock domain; rst_n is the cluster-local reset (asynchronous assert, synchronous release).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`default_nettype none

module sfx_cluster_ctrl #(
  parameter int          CMD_IF     = 1,          // 1 stream interface, 0 legacy register page only
  parameter int          DESC_WORDS = 8,          // descriptor words (vector 8, tensor 12)
  parameter int          CPL_WORDS  = 6,          // completion-record words read per record
  parameter logic [11:0] A_STATUS   = 12'h028,
  parameter logic [11:0] A_DESC0    = 12'h080,
  parameter logic [11:0] A_DOORBELL = 12'h0A0,
  parameter logic [11:0] A_CPL0     = 12'h040,
  parameter logic [11:0] A_CPL_POP  = 12'h058,
  parameter int          SB_CPL_VALID = 5,        // STATUS bit: a completion record is waiting
  parameter logic [31:0] BLOCK_MASK = 32'h0000_0018, // STATUS bits that forbid a DOORBELL (queue full, soft reset)
  parameter int          ERR_LSB    = 8,          // record word 0: status field, non-zero = error
  parameter int          ERR_BITS   = 4,
  localparam int         DW_CMD     = 32 * DESC_WORDS,
  localparam int         DW_CPL     = 32 * CPL_WORDS,
  localparam int         IW         = $clog2(DESC_WORDS + 1)
) (
  input  wire logic              clk,
  input  wire logic              rst_n,
  // ---------------------------------------------------------- command stream
  input  wire logic              cmd_valid,
  output logic                   cmd_ready,
  input  wire logic [DW_CMD-1:0] cmd_data,
  // ---------------------------------------------------------- completion stream
  output logic                   cpl_valid,
  input  wire logic              cpl_ready,
  output logic [DW_CPL-1:0]      cpl_data,
  output logic                   cpl_err,
  // ---------------------------------------------------------- host CSR port (SilicaFlux-V rb protocol)
  input  wire logic              csr_sel,
  input  wire logic              csr_we,
  input  wire logic [11:0]       csr_addr,
  input  wire logic [31:0]       csr_wdata,
  output logic [31:0]            csr_rdata,
  output logic                   csr_err,
  // ---------------------------------------------------------- unit register page
  output logic                   u_sel,
  output logic                   u_we,
  output logic [11:0]            u_addr,
  output logic [31:0]            u_wdata,
  input  wire logic [31:0]       u_rdata,
  input  wire logic              u_err,
  // ---------------------------------------------------------- status
  output logic                   idle,           // nothing held, nothing to deliver, no completion seen waiting
  output logic                   cpl_seen        // last STATUS poll saw a completion waiting (registered)
);
  // ============================================================ configuration checks
  if (CMD_IF != 0 && CMD_IF != 1) begin : g_err_cmd_if
    `SRAM_CFG_FATAL("sfx_cluster_ctrl: CMD_IF must be 0 or 1")
  end
  if (DESC_WORDS < 1 || DESC_WORDS > 16 || CPL_WORDS < 1 || CPL_WORDS > 8) begin : g_err_words
    `SRAM_CFG_FATAL("sfx_cluster_ctrl: DESC_WORDS must be 1..16 and CPL_WORDS 1..8")
  end
  if (ERR_LSB < 0 || ERR_BITS < 1 || ERR_LSB + ERR_BITS > 32 || SB_CPL_VALID < 0 || SB_CPL_VALID > 31) begin : g_err_fields
    `SRAM_CFG_FATAL("sfx_cluster_ctrl: status / record field positions out of range")
  end

  if (CMD_IF == 0) begin : g_legacy
    // ---------------------------------------------------------- legacy: host owns the page
    assign u_sel = csr_sel;  assign u_we = csr_we;  assign u_addr = csr_addr;  assign u_wdata = csr_wdata;
    assign csr_rdata = u_rdata;  assign csr_err = u_err;
    assign cmd_ready = 1'b0;  assign cpl_valid = 1'b0;  assign cpl_data = '0;  assign cpl_err = 1'b0;
    assign idle = 1'b1;  assign cpl_seen = 1'b0;
    /* verilator lint_off UNUSEDSIGNAL */
    wire unused_ok = &{1'b0, clk, rst_n, cmd_valid, cmd_data, cpl_ready};
    /* verilator lint_on UNUSEDSIGNAL */
  end else begin : g_stream
    // ---------------------------------------------------------- host access decode
    localparam logic [11:0] DESC_END = A_DESC0 + 12'(4 * DESC_WORDS);
    wire h_owned = (csr_addr >= A_DESC0 && csr_addr < DESC_END) || csr_addr == A_DOORBELL || csr_addr == A_CPL_POP;
    wire h_block = csr_sel && csr_we && h_owned;          // refused host write
    wire h_use   = csr_sel && !h_block;                   // host occupies the unit bus this cycle
    wire h_wr    = h_use && csr_we;                       // host write that reaches the unit

    // ---------------------------------------------------------- sequencer state
    localparam logic [1:0] S_POLL = 2'd0, S_ISSUE = 2'd1, S_CPL_RD = 2'd2, S_CPL_POP = 2'd3;
    logic [1:0]         st_q;
    logic [IW-1:0]      idx_q;                            // ISSUE: word index (DESC_WORDS = doorbell); CPL_RD: word
    logic               hv_q;                             // command held
    logic [DW_CMD-1:0]  hd_q;
    logic               ov_q;                             // completion held for delivery
    logic [DW_CPL-1:0]  od_q;
    logic               last_iss_q;                       // fairness: last POLL decision issued a command
    logic               hwr_q;                            // host write seen during a CPL_RD / CPL_POP sequence
    logic               cv_q;

    // adapter's bus request for this cycle
    logic        a_we;
    logic [11:0] a_addr;
    logic [31:0] a_wdata;
    always_comb begin
      a_we = 1'b0; a_addr = A_STATUS; a_wdata = 32'd0;
      case (st_q)
        S_ISSUE: begin
          if (32'(idx_q) == DESC_WORDS) begin a_we = 1'b1; a_addr = A_DOORBELL; a_wdata = 32'd1; end
          else begin a_we = 1'b1; a_addr = A_DESC0 + 12'({idx_q, 2'b00}); a_wdata = hd_q[32 * idx_q +: 32]; end
        end
        S_CPL_RD:  begin a_addr = A_CPL0 + 12'({idx_q, 2'b00}); end
        S_CPL_POP: if (!hwr_q) begin a_we = 1'b1; a_addr = A_CPL_POP; a_wdata = 32'd1; end  // else: STATUS read
        default:   ;                                      // POLL: read STATUS
      endcase
    end
    wire go = !h_use;                                     // the adapter owns the bus this cycle

    assign u_sel   = h_use || go;
    assign u_we    = h_use ? csr_we    : a_we;
    assign u_addr  = h_use ? csr_addr  : a_addr;
    assign u_wdata = h_use ? csr_wdata : a_wdata;
    assign csr_rdata = h_use ? u_rdata : 32'd0;
    assign csr_err   = h_block || (h_use && u_err);

    // POLL decision (combinational on the STATUS read of this cycle)
    wire st_cv   = u_rdata[SB_CPL_VALID];
    wire st_blk  = |(u_rdata & BLOCK_MASK);
    wire want_c  = st_cv && !ov_q;
    wire want_i  = hv_q && !st_blk;
    wire pick_c  = want_c && (!want_i || last_iss_q);

    assign cmd_ready = !hv_q;
    assign cpl_valid = ov_q;
    assign cpl_data  = od_q;
    assign cpl_err   = |od_q[ERR_LSB +: ERR_BITS];
    assign idle      = !hv_q && !ov_q && !cv_q && st_q == S_POLL;
    assign cpl_seen  = cv_q;

    always_ff @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        st_q <= S_POLL; idx_q <= '0; hv_q <= 1'b0; hd_q <= '0; ov_q <= 1'b0; od_q <= '0;
        last_iss_q <= 1'b0; hwr_q <= 1'b0; cv_q <= 1'b0;
      end else begin
        if (cmd_valid && !hv_q) begin hv_q <= 1'b1; hd_q <= cmd_data; end
        if (ov_q && cpl_ready) ov_q <= 1'b0;
        if (h_wr && (st_q == S_CPL_RD || st_q == S_CPL_POP)) hwr_q <= 1'b1;
        if (go) begin
          case (st_q)
            S_POLL: begin
              cv_q <= st_cv;
              hwr_q <= 1'b0;
              idx_q <= '0;
              if (pick_c)      begin st_q <= S_CPL_RD; last_iss_q <= 1'b0; end
              else if (want_i) begin st_q <= S_ISSUE;  last_iss_q <= 1'b1; end
            end
            S_ISSUE: begin
              if (32'(idx_q) == DESC_WORDS) begin
                st_q <= S_POLL;
                if (!u_err) hv_q <= 1'b0;                 // accepted by the unit's command queue
              end else idx_q <= idx_q + 1'b1;
            end
            S_CPL_RD: begin
              od_q[32 * idx_q +: 32] <= u_rdata;
              if (32'(idx_q) == CPL_WORDS - 1) st_q <= S_CPL_POP;
              else idx_q <= idx_q + 1'b1;
            end
            default: begin                                // S_CPL_POP
              st_q <= S_POLL;
              if (!hwr_q) begin                           // the pop was performed this cycle
                if (!u_err) ov_q <= 1'b1;                 // accepted: deliver the record
                cv_q <= 1'b0;
              end
            end
          endcase
        end
      end
    end
    // A host write that reaches the unit takes the bus (go = 0) and sets hwr_q while a CPL_RD / CPL_POP
    // sequence is open; the pop is then replaced by a STATUS read and the sequence restarts from POLL.
    // A pop is therefore only ever performed after an uninterrupted read of the whole record, and a
    // record is delivered exactly when its pop was performed and accepted.
  end
endmodule

`default_nettype wire
