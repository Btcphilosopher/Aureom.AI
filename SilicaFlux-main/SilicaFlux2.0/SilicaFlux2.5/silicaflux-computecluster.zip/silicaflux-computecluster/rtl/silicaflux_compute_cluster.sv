// =============================================================================
// SilicaFlux Project 32 :: silicaflux_compute_cluster   (primary source)
// ComputeCluster integration shell: floorplan-aware vector and tensor regions.
// Aureom.AI | SilicaFlux-HPC
//
//                              host rb page (shell page 7, cluster pages 8..)    host SFB2 data port
//                                      │                                               │
//   cmd_* (dest ID) ─► u_cmd_route ────┼──────────────┬────────────────┐               │
//   cpl_* (src ID)  ◄─ u_cpl_arb   ◄───┼──────────┐   │                │               │
//                      u_regs ◄────────┘          │   ▼                ▼               ▼
//        ┌──────────────────────┐  ┌──────────────────────┐   ┌──────────────────────────────────────┐
//        │ u_vector_0 .. _7     │  │ u_tensor_0 .. _3     │   │ u_noc  DataFabric sfb_crossbar       │
//        │ silicaflux_vector_   │  │ silicaflux_tensor_   │   │   m0 host, m1.. vector DMA,          │
//        │ cluster (FP32 lanes  │  │ cluster (INT8 PE     │◄─►│   m.. tensor DMA                     │
//        │ + local scratchpad)  │◄►│ array + operand /    │   │   s0 shared memory (mem_*),          │
//        │ mem_* ─► / lm_* ◄─   │  │ accumulator storage) │   │   s1.. vector scratchpad windows     │
//        └──────────────────────┘  └──────────────────────┘   └──────────────┬───────────────────────┘
//                                                                  u_ext_slice│(EXT_PIPE)
//                                                                             ▼ mem_* (SFB2 master)
//
// SLOT-BASED HIERARCHY.  Every slot is a direct child of this module with a fixed name —
// u_vector_0 .. u_vector_7 and u_tensor_0 .. u_tensor_3 — whether or not it is populated.  A
// populated slot is a full cluster; an unpopulated one elaborates to an empty wrapper (no cells,
// constant outputs, connected to nothing).  Instance paths therefore never move when the cluster
// counts change, and floorplan constraints written for one configuration stay valid for the others.
// NUM_VECTOR_CLUSTERS populates slots u_vector_0 .. u_vector_(NV-1); NUM_TENSOR_CLUSTERS populates
// u_tensor_0 .. u_tensor_(NT-1).  Cluster ID = slot: vector k -> k, tensor j -> 8 + j.
//
// No physical coordinates are written in RTL: regions are proposed in physical/ (Tcl) from the
// synthesized instance names.
// Classification: SYNTHESIZABLE
// =============================================================================
`include "sram_defs.svh"
`include "sfx_cluster_defs.svh"
`default_nettype none

module silicaflux_compute_cluster #(
  // ------------------------------------------------------------ replication
  parameter int          NUM_VECTOR_CLUSTERS     = 1,             // 0..8 (slots u_vector_0..7)
  parameter int          NUM_TENSOR_CLUSTERS     = 1,             // 0..4 (slots u_tensor_0..3)
  // ------------------------------------------------------------ fabric
  parameter int          TRANSACTION_WIDTH       = 32,            // SFB2 data width: 32, 64, 128
  parameter logic [31:0] MEM_BASE                = 32'h1000_0000, // shared-memory window (crossbar slave 0)
  parameter int          MEM_BYTES               = 1 << 20,
  parameter int          LOCAL_MEM_PORT          = 1,             // vector scratchpads reachable from the host
  parameter int          MEM_PIPE                = 0,             // register slice at every cluster memory port
  parameter int          LM_PIPE                 = 0,             // register slice at every local-memory port
  parameter int          EXT_PIPE                = 0,             // register slice at the shared-memory port
  parameter int          CMD_PIPE                = 0,             // register slice at the command ingress
  parameter int          CMD_IF                  = 1,             // 1 streams; 0 legacy register-page command path
  // ------------------------------------------------------------ vector clusters (HPC Module 08 tile)
  parameter int          VEC_NUM_LANES           = 4,
  parameter int          VEC_SCRATCHPAD_BYTES    = 65536,
  parameter int          VEC_NUM_BANKS           = 4,
  parameter int          VEC_CMD_QUEUE_DEPTH     = 8,
  parameter int          VEC_CPL_QUEUE_DEPTH     = 8,
  parameter int          VEC_DMA_BUFFER_DEPTH    = 0,
  parameter int          VEC_PERF                = 1,
  parameter logic [31:0] VEC_SPM_BASE            = 32'h2000_0000, // slot k window: + k * VEC_SCRATCHPAD_BYTES
  parameter int          VEC_SPM_BACKEND         = `SRAM_BACKEND_GENERIC,
  // ------------------------------------------------------------ tensor clusters (TENSORCORE 08 tensor unit)
  parameter int          TSU_ARRAY_ROWS          = 4,
  parameter int          TSU_ARRAY_COLS          = 4,
  parameter int          TSU_TILE_K              = 64,
  parameter int          TSU_OPERAND_BUFFER_BYTES = 2048,
  parameter int          TSU_NUM_MEMORY_BANKS    = 4,
  parameter int          TSU_QUANT               = 0,
  parameter int          TSU_DBUF                = 0,
  parameter int          TSU_CMD_QUEUE_DEPTH     = 4,
  parameter int          TSU_MAX_OUT             = 4,
  parameter int          TSU_PERF                = 1,
  // ------------------------------------------------------------ control
  parameter int          RB_AW                   = 16,            // host register-bus address width (4 KiB pages)
  parameter int          SHELL_PAGE              = 7,
  parameter int          CL_PAGE0                = 8,             // vector k: page CL_PAGE0 + k; tensor j: + NV + j
  parameter int          SHELL_PERF              = 1,
  parameter int          ENABLE_CLK_REQ          = 1,             // 0: clock-enable requests tied to 1
  parameter int          RST_HOLD                = 8,
  // ------------------------------------------------------------ derived (never set)
  localparam int NV    = NUM_VECTOR_CLUSTERS,
  localparam int NT    = NUM_TENSOR_CLUSTERS,
  localparam int W     = TRANSACTION_WIDTH,
  localparam int WB    = W / 8,
  localparam int NM    = 1 + NV + NT,
  localparam int NLM   = (LOCAL_MEM_PORT != 0) ? NV : 0,
  localparam int NS    = 1 + NLM,
  localparam int NSLOT = `SFX_NSLOT,
  localparam int MAXV  = `SFX_MAX_VEC,
  localparam int MAXT  = `SFX_MAX_TSU,
  localparam int CW    = `SFX_CMD_W,
  localparam int PW    = `SFX_CPL_W,
  localparam int IDW   = `SFX_ID_W,
  localparam int NEV   = `SFX_NUM_EV
) (
  input  wire logic                clk,
  input  wire logic                rst_n,
  // ---------------------------------------------------------- host register bus (SilicaFlux-V rb)
  input  wire logic                rb_sel,
  input  wire logic                rb_we,
  input  wire logic [RB_AW-1:0]    rb_addr,
  input  wire logic [31:0]         rb_wdata,
  output logic [31:0]              rb_rdata,
  output logic                     rb_err,
  // ---------------------------------------------------------- command request (to cluster ID cmd_dest)
  input  wire logic                cmd_valid,
  output logic                     cmd_ready,
  input  wire logic [IDW-1:0]      cmd_dest,
  input  wire logic [CW-1:0]       cmd_data,
  // ---------------------------------------------------------- command completion (from cluster ID cpl_src)
  output logic                     cpl_valid,
  input  wire logic                cpl_ready,
  output logic [IDW-1:0]           cpl_src,
  output logic                     cpl_err,
  output logic [PW-1:0]            cpl_data,
  // ---------------------------------------------------------- host data port (SFB2 master m0 of the fabric)
  input  wire logic                h_req_valid,
  output logic                     h_req_ready,
  input  wire logic                h_req_write,
  input  wire logic [31:0]         h_req_addr,
  input  wire logic [W-1:0]        h_req_wdata,
  input  wire logic [WB-1:0]       h_req_wstrb,
  output logic                     h_rsp_valid,
  input  wire logic                h_rsp_ready,
  output logic [W-1:0]             h_rsp_rdata,
  output logic                     h_rsp_error,
  // ---------------------------------------------------------- shared-memory port (SFB2 master towards memory / NoC)
  output logic                     mem_req_valid,
  input  wire logic                mem_req_ready,
  output logic                     mem_req_write,
  output logic [31:0]              mem_req_addr,
  output logic [W-1:0]             mem_req_wdata,
  output logic [WB-1:0]            mem_req_wstrb,
  input  wire logic                mem_rsp_valid,
  output logic                     mem_rsp_ready,
  input  wire logic [W-1:0]        mem_rsp_rdata,
  input  wire logic                mem_rsp_error,
  // ---------------------------------------------------------- interrupt / error / status, per cluster ID (registered)
  output logic                     irq,
  output logic [NSLOT-1:0]         cl_irq,
  output logic [NSLOT-1:0]         cl_err,
  output logic [NSLOT-1:0]         cl_busy,
  output logic [NSLOT-1:0]         cl_in_reset,
  output logic [NSLOT-1:0]         cl_clk_en_req,
  output logic [NSLOT*NEV-1:0]     cl_perf_ev,
  // ---------------------------------------------------------- fabric monitor (per crossbar master: host, vector, tensor)
  output logic [NM-1:0]            mon_req_accept,
  output logic [NM-1:0]            mon_req_stall,
  output logic [NM-1:0]            mon_arb_loss
);
  // ============================================================ configuration checks
  if (NV < 0 || NV > MAXV || NT < 0 || NT > MAXT || NV + NT < 1) begin : g_err_counts
    `SRAM_CFG_FATAL("silicaflux_compute_cluster: NUM_VECTOR_CLUSTERS must be 0..8, NUM_TENSOR_CLUSTERS 0..4, at least one cluster")
  end
  if (W != 32 && W != 64 && W != 128) begin : g_err_width
    `SRAM_CFG_FATAL("silicaflux_compute_cluster: TRANSACTION_WIDTH must be 32, 64 or 128")
  end
  if (RB_AW < 16 || RB_AW > 20 || SHELL_PAGE < 0 || CL_PAGE0 < 0 || SHELL_PAGE >= (1 << (RB_AW - 12)) ||
      CL_PAGE0 + NV + NT > (1 << (RB_AW - 12)) || (SHELL_PAGE >= CL_PAGE0 && SHELL_PAGE < CL_PAGE0 + NV + NT)) begin : g_err_pages
    `SRAM_CFG_FATAL("silicaflux_compute_cluster: register pages do not fit RB_AW or overlap the shell page")
  end
  if (MEM_BYTES < 1024 || (MEM_BYTES & (MEM_BYTES - 1)) != 0 || (MEM_BASE & 32'(MEM_BYTES - 1)) != 32'd0) begin : g_err_mem
    `SRAM_CFG_FATAL("silicaflux_compute_cluster: MEM_BYTES must be a power of two >= 1 KiB and MEM_BASE aligned to it")
  end
  if (NV > 0 && ((64'(VEC_SPM_BASE) + 64'(NV) * 64'(VEC_SCRATCHPAD_BYTES) > 64'(MEM_BASE) &&
                  64'(VEC_SPM_BASE) < 64'(MEM_BASE) + 64'(MEM_BYTES)) ||
                 64'(VEC_SPM_BASE) + 64'(NV) * 64'(VEC_SCRATCHPAD_BYTES) > 64'h1_0000_0000)) begin : g_err_windows
    `SRAM_CFG_FATAL("silicaflux_compute_cluster: vector scratchpad windows overlap the shared memory or leave the 4 GiB space")
  end
  if (MEM_PIPE > 1 || LM_PIPE > 1 || EXT_PIPE > 1 || CMD_PIPE > 1 || CMD_IF > 1 || LOCAL_MEM_PORT > 1 ||
      SHELL_PERF > 1 || ENABLE_CLK_REQ > 1 || MEM_PIPE < 0 || LM_PIPE < 0 || EXT_PIPE < 0 || CMD_PIPE < 0 ||
      CMD_IF < 0 || LOCAL_MEM_PORT < 0 || SHELL_PERF < 0 || ENABLE_CLK_REQ < 0) begin : g_err_flags
    `SRAM_CFG_FATAL("silicaflux_compute_cluster: MEM_PIPE, LM_PIPE, EXT_PIPE, CMD_PIPE, CMD_IF, LOCAL_MEM_PORT, SHELL_PERF, ENABLE_CLK_REQ must be 0 or 1")
  end

  // populated slots: vector k at bit k, tensor j at bit 8 + j (counts clamped so that an illegal count is
  // reported by the check above, not by an incidental elaboration error)
  localparam int NVC = (NV < 0) ? 0 : (NV > MAXV) ? MAXV : NV;
  localparam int NTC = (NT < 0) ? 0 : (NT > MAXT) ? MAXT : NT;
  localparam logic [MAXV-1:0]  VEC_MASK     = (MAXV)'((64'd1 << NVC) - 64'd1);
  localparam logic [MAXT-1:0]  TSU_MASK     = (MAXT)'((64'd1 << NTC) - 64'd1);
  localparam logic [NSLOT-1:0] PRESENT_MASK = {TSU_MASK, VEC_MASK};
  localparam logic [32:0]      MEM_LO33     = {1'b0, MEM_BASE};
  localparam logic [32:0]      MEM_HI33     = {1'b0, MEM_BASE} + 33'(MEM_BYTES);

  // ============================================================ per-slot signals (index = cluster ID)
  logic [NSLOT-1:0]      sl_cmd_valid, sl_cmd_ready, sl_cmd_wake, sl_cpl_valid, sl_cpl_ready, sl_cpl_err;
  logic [CW-1:0]         sl_cmd_data;
  logic [NSLOT*PW-1:0]   sl_cpl_data;
  logic [NSLOT-1:0]      sl_csr_sel, sl_csr_err, cl_rst_req;
  logic [NSLOT*32-1:0]   sl_csr_rdata;
  logic [NSLOT-1:0]      sl_irq, sl_busy, sl_in_reset, sl_err_ev, sl_clk_req;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [NSLOT-1:0]      sl_halted;              // reported through err_ev (halt entry) and the cluster pages
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NSLOT*NEV-1:0]  sl_perf_ev;
  // Per-slot buses are sized for every slot; the bits of unpopulated slots / of a configuration
  // without local-memory ports are intentionally unused (constant, removed by synthesis).
  /* verilator lint_off UNUSEDSIGNAL */
  // memory master port of every slot
  logic [NSLOT-1:0]      sm_req_valid, sm_req_ready, sm_req_write, sm_rsp_valid, sm_rsp_ready, sm_rsp_error;
  logic [NSLOT*32-1:0]   sm_req_addr;
  logic [NSLOT*W-1:0]    sm_req_wdata, sm_rsp_rdata;
  logic [NSLOT*WB-1:0]   sm_req_wstrb;
  // local-memory slave port of every vector slot
  logic [MAXV-1:0]       sl_lm_req_valid, sl_lm_req_ready, sl_lm_req_write, sl_lm_rsp_valid, sl_lm_rsp_ready,
                         sl_lm_rsp_error;
  logic [MAXV*32-1:0]    sl_lm_req_addr;
  logic [MAXV*W-1:0]     sl_lm_req_wdata, sl_lm_rsp_rdata;
  logic [MAXV*WB-1:0]    sl_lm_req_wstrb;
  /* verilator lint_on UNUSEDSIGNAL */

  // ============================================================ host register-bus decode
  wire [RB_AW-13:0] page = rb_addr[RB_AW-1:12];
  wire              shell_sel = rb_sel && 32'(page) == SHELL_PAGE;
  always_comb begin
    for (int i = 0; i < NSLOT; i++)
      sl_csr_sel[i] = rb_sel && PRESENT_MASK[i] &&
                      32'(page) == ((i < MAXV) ? (CL_PAGE0 + i) : (CL_PAGE0 + NV + i - MAXV));
  end
  logic [31:0] s_rdata;
  logic        s_err;
  always_comb begin
    rb_rdata = shell_sel ? s_rdata : 32'd0;
    rb_err   = shell_sel ? s_err : (rb_sel && sl_csr_sel == '0);   // unmapped page: refused
    for (int i = 0; i < NSLOT; i++) if (sl_csr_sel[i]) begin
      rb_rdata = sl_csr_rdata[i * 32 +: 32];
      rb_err   = sl_csr_err[i];
    end
  end

  // ============================================================ shell control: command route, completion merge, registers
  logic           e_valid, e_ready, ev_bad_dest;
  logic [IDW-1:0] e_dest;
  logic [31:0]    e_word0;
  sfx_cmd_router #(.NSLOT(NSLOT), .PRESENT_MASK(PRESENT_MASK), .CMD_PIPE(CMD_PIPE)) u_cmd_route (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_dest(cmd_dest), .cmd_data(cmd_data),
    .sl_cmd_valid(sl_cmd_valid), .sl_cmd_ready(sl_cmd_ready), .sl_cmd_data(sl_cmd_data), .sl_cmd_wake(sl_cmd_wake),
    .err_valid(e_valid), .err_ready(e_ready), .err_dest(e_dest), .err_word0(e_word0), .ev_bad_dest(ev_bad_dest));

  // completion sources: the 12 slots (ID = index) + the shell error-record source (index 12)
  logic [NSLOT:0]          a_ready;
  logic [(NSLOT+1)*IDW-1:0] a_id;
  for (genvar i = 0; i < NSLOT; i++) begin : g_id
    assign a_id[i * IDW +: IDW] = `SFX_ID_W'(i);
  end
  assign a_id[NSLOT * IDW +: IDW] = e_dest;
  sfx_cpl_arbiter #(.NSRC(NSLOT + 1)) u_cpl_arb (
    .clk(clk), .rst_n(rst_n),
    .src_valid({e_valid, sl_cpl_valid & PRESENT_MASK}), .src_ready(a_ready),
    .src_err({1'b1, sl_cpl_err}), .src_id(a_id),
    .src_data({{4{32'd0}}, e_word0, {`SFX_SHELL_REC_MAGIC, `SFX_SE_BAD_DEST}, sl_cpl_data}),
    .cpl_valid(cpl_valid), .cpl_ready(cpl_ready), .cpl_src(cpl_src), .cpl_err(cpl_err), .cpl_data(cpl_data));
  assign sl_cpl_ready = a_ready[NSLOT-1:0];
  assign e_ready      = a_ready[NSLOT];

  localparam logic [31:0] CONFIG0 = {1'b0, 1'(SHELL_PERF), 1'(CMD_PIPE), 5'($clog2(VEC_SCRATCHPAD_BYTES)),
                                     8'(VEC_NUM_LANES), 1'(EXT_PIPE), 1'(CMD_IF), 1'(MEM_PIPE), 1'(LOCAL_MEM_PORT),
                                     4'($clog2(WB)), 4'(NT), 4'(NV)};
  localparam logic [31:0] CONFIG1 = {16'(TSU_TILE_K), 8'(TSU_ARRAY_COLS), 8'(TSU_ARRAY_ROWS)};
  logic [31:0] reg_rdata;
  logic        reg_err;
  sfx_shell_regs #(.NSLOT(NSLOT), .PRESENT_MASK(PRESENT_MASK), .CONFIG0(CONFIG0), .CONFIG1(CONFIG1),
                   .SPM_BASE(VEC_SPM_BASE), .MEM_BASE(MEM_BASE), .SHELL_PERF(SHELL_PERF)) u_regs (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(shell_sel), .rb_we(rb_we), .rb_addr(rb_addr[11:0]), .rb_wdata(rb_wdata), .rb_rdata(reg_rdata),
    .rb_err(reg_err),
    .cl_busy(sl_busy), .cl_in_reset(sl_in_reset), .cl_clk_req(sl_clk_req), .cl_irq(sl_irq), .cl_err_ev(sl_err_ev),
    .cl_perf_ev(sl_perf_ev), .ev_bad_dest(ev_bad_dest),
    .cl_rst_req(cl_rst_req), .err_status(cl_err), .irq(irq));
  assign s_rdata = reg_rdata;
  assign s_err   = reg_err;

  assign cl_irq      = sl_irq;
  assign cl_busy     = sl_busy;
  assign cl_in_reset = sl_in_reset;
  assign cl_perf_ev  = sl_perf_ev;

  // clock-enable request: cluster activity (registered in the cluster) or a pending wake source
  logic [NSLOT-1:0] wake;
  always_comb begin
    wake = sl_cmd_wake | sl_csr_sel;
    for (int k = 0; k < MAXV; k++) wake[k] = wake[k] | sl_lm_req_valid[k];
  end
  if (ENABLE_CLK_REQ != 0) begin : g_clk_req
    always_ff @(posedge clk or negedge rst_n)
      if (!rst_n) cl_clk_en_req <= '0;
      else        cl_clk_en_req <= (sl_clk_req | wake) & PRESENT_MASK;
  end else begin : g_no_clk_req
    assign cl_clk_en_req = PRESENT_MASK;
  end

  // ============================================================ cluster slots (fixed names; unpopulated = empty)
`define SFX_VEC_PARAMS(K) \
    .PRESENT(((K) < NV) ? 1 : 0), .NUM_LANES(VEC_NUM_LANES), .DATA_WIDTH(W), \
    .SCRATCHPAD_BYTES(VEC_SCRATCHPAD_BYTES), .NUM_BANKS(VEC_NUM_BANKS), .CMD_QUEUE_DEPTH(VEC_CMD_QUEUE_DEPTH), \
    .CPL_QUEUE_DEPTH(VEC_CPL_QUEUE_DEPTH), .DMA_BUFFER_DEPTH(VEC_DMA_BUFFER_DEPTH), .ENABLE_PERF_COUNTERS(VEC_PERF), \
    .SPM_BASE(VEC_SPM_BASE + 32'((K) * VEC_SCRATCHPAD_BYTES)), .SPM_BACKEND(VEC_SPM_BACKEND), \
    .LOCAL_MEM_PORT(LOCAL_MEM_PORT), .MEM_PIPE(MEM_PIPE), .LM_PIPE(LM_PIPE), .CMD_IF(CMD_IF), .RST_HOLD(RST_HOLD)
`define SFX_VEC_PORTS(K) \
    .clk(clk), .rst_n(rst_n), .cl_rst_req(cl_rst_req[K]), \
    .cmd_valid(sl_cmd_valid[K]), .cmd_ready(sl_cmd_ready[K]), .cmd_data(sl_cmd_data[255:0]), \
    .cpl_valid(sl_cpl_valid[K]), .cpl_ready(sl_cpl_ready[K]), .cpl_data(sl_cpl_data[(K)*PW +: PW]), \
    .cpl_err(sl_cpl_err[K]), \
    .csr_sel(sl_csr_sel[K]), .csr_we(rb_we), .csr_addr(rb_addr[11:0]), .csr_wdata(rb_wdata), \
    .csr_rdata(sl_csr_rdata[(K)*32 +: 32]), .csr_err(sl_csr_err[K]), \
    .mem_req_valid(sm_req_valid[K]), .mem_req_ready(sm_req_ready[K]), .mem_req_write(sm_req_write[K]), \
    .mem_req_addr(sm_req_addr[(K)*32 +: 32]), .mem_req_wdata(sm_req_wdata[(K)*W +: W]), \
    .mem_req_wstrb(sm_req_wstrb[(K)*WB +: WB]), .mem_rsp_valid(sm_rsp_valid[K]), .mem_rsp_ready(sm_rsp_ready[K]), \
    .mem_rsp_rdata(sm_rsp_rdata[(K)*W +: W]), .mem_rsp_error(sm_rsp_error[K]), \
    .lm_req_valid(sl_lm_req_valid[K]), .lm_req_ready(sl_lm_req_ready[K]), .lm_req_write(sl_lm_req_write[K]), \
    .lm_req_addr(sl_lm_req_addr[(K)*32 +: 32]), .lm_req_wdata(sl_lm_req_wdata[(K)*W +: W]), \
    .lm_req_wstrb(sl_lm_req_wstrb[(K)*WB +: WB]), .lm_rsp_valid(sl_lm_rsp_valid[K]), \
    .lm_rsp_ready(sl_lm_rsp_ready[K]), .lm_rsp_rdata(sl_lm_rsp_rdata[(K)*W +: W]), \
    .lm_rsp_error(sl_lm_rsp_error[K]), \
    .irq(sl_irq[K]), .busy(sl_busy[K]), .halted(sl_halted[K]), .in_reset(sl_in_reset[K]), \
    .err_ev(sl_err_ev[K]), .clk_req(sl_clk_req[K]), .perf_ev(sl_perf_ev[(K)*NEV +: NEV])
`define SFX_TSU_PARAMS(J) \
    .PRESENT(((J) < NT) ? 1 : 0), .ARRAY_ROWS(TSU_ARRAY_ROWS), .ARRAY_COLS(TSU_ARRAY_COLS), .TILE_K(TSU_TILE_K), \
    .OPERAND_BUFFER_BYTES(TSU_OPERAND_BUFFER_BYTES), .NUM_MEMORY_BANKS(TSU_NUM_MEMORY_BANKS), \
    .ENABLE_QUANTIZATION(TSU_QUANT), .ENABLE_DOUBLE_BUFFERING(TSU_DBUF), .CMD_QUEUE_DEPTH(TSU_CMD_QUEUE_DEPTH), \
    .CPL_QUEUE_DEPTH(TSU_CMD_QUEUE_DEPTH), .MEM_LO(MEM_LO33), .MEM_HI(MEM_HI33), .MAX_OUT(TSU_MAX_OUT), \
    .PERF_EN(TSU_PERF), .DATA_WIDTH(W), .MEM_PIPE(MEM_PIPE), .CMD_IF(CMD_IF), .RST_HOLD(RST_HOLD)
`define SFX_TSU_PORTS(S) \
    .clk(clk), .rst_n(rst_n), .cl_rst_req(cl_rst_req[S]), \
    .cmd_valid(sl_cmd_valid[S]), .cmd_ready(sl_cmd_ready[S]), .cmd_data(sl_cmd_data), \
    .cpl_valid(sl_cpl_valid[S]), .cpl_ready(sl_cpl_ready[S]), .cpl_data(sl_cpl_data[(S)*PW +: PW]), \
    .cpl_err(sl_cpl_err[S]), \
    .csr_sel(sl_csr_sel[S]), .csr_we(rb_we), .csr_addr(rb_addr[11:0]), .csr_wdata(rb_wdata), \
    .csr_rdata(sl_csr_rdata[(S)*32 +: 32]), .csr_err(sl_csr_err[S]), \
    .mem_req_valid(sm_req_valid[S]), .mem_req_ready(sm_req_ready[S]), .mem_req_write(sm_req_write[S]), \
    .mem_req_addr(sm_req_addr[(S)*32 +: 32]), .mem_req_wdata(sm_req_wdata[(S)*W +: W]), \
    .mem_req_wstrb(sm_req_wstrb[(S)*WB +: WB]), .mem_rsp_valid(sm_rsp_valid[S]), .mem_rsp_ready(sm_rsp_ready[S]), \
    .mem_rsp_rdata(sm_rsp_rdata[(S)*W +: W]), .mem_rsp_error(sm_rsp_error[S]), \
    .irq(sl_irq[S]), .busy(sl_busy[S]), .halted(sl_halted[S]), .in_reset(sl_in_reset[S]), \
    .err_ev(sl_err_ev[S]), .clk_req(sl_clk_req[S]), .perf_ev(sl_perf_ev[(S)*NEV +: NEV])

  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(0)) u_vector_0 (`SFX_VEC_PORTS(0));
  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(1)) u_vector_1 (`SFX_VEC_PORTS(1));
  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(2)) u_vector_2 (`SFX_VEC_PORTS(2));
  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(3)) u_vector_3 (`SFX_VEC_PORTS(3));
  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(4)) u_vector_4 (`SFX_VEC_PORTS(4));
  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(5)) u_vector_5 (`SFX_VEC_PORTS(5));
  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(6)) u_vector_6 (`SFX_VEC_PORTS(6));
  silicaflux_vector_cluster #(`SFX_VEC_PARAMS(7)) u_vector_7 (`SFX_VEC_PORTS(7));
  silicaflux_tensor_cluster #(`SFX_TSU_PARAMS(0)) u_tensor_0 (`SFX_TSU_PORTS(8));
  silicaflux_tensor_cluster #(`SFX_TSU_PARAMS(1)) u_tensor_1 (`SFX_TSU_PORTS(9));
  silicaflux_tensor_cluster #(`SFX_TSU_PARAMS(2)) u_tensor_2 (`SFX_TSU_PORTS(10));
  silicaflux_tensor_cluster #(`SFX_TSU_PARAMS(3)) u_tensor_3 (`SFX_TSU_PORTS(11));
`undef SFX_VEC_PARAMS
`undef SFX_VEC_PORTS
`undef SFX_TSU_PARAMS
`undef SFX_TSU_PORTS

  // ============================================================ DataFabric crossbar (unmodified)
  // masters: m0 host, m1 + k vector slot k (k < NV), m1 + NV + j tensor slot j (j < NT)
  // slaves : s0 shared memory, s1 + k scratchpad window of vector slot k (LOCAL_MEM_PORT)
  // access matrix: the host reaches every slave; every cluster DMA reaches the shared memory only
  // (a cluster never reaches another cluster's scratchpad: ownership, docs/04_TIMING_AND_LOCALITY.md).
  localparam logic [9*32-1:0] ALL_BASE =
    {VEC_SPM_BASE + 32'(7 * VEC_SCRATCHPAD_BYTES), VEC_SPM_BASE + 32'(6 * VEC_SCRATCHPAD_BYTES),
     VEC_SPM_BASE + 32'(5 * VEC_SCRATCHPAD_BYTES), VEC_SPM_BASE + 32'(4 * VEC_SCRATCHPAD_BYTES),
     VEC_SPM_BASE + 32'(3 * VEC_SCRATCHPAD_BYTES), VEC_SPM_BASE + 32'(2 * VEC_SCRATCHPAD_BYTES),
     VEC_SPM_BASE + 32'(VEC_SCRATCHPAD_BYTES), VEC_SPM_BASE, MEM_BASE};
  localparam logic [31:0]     SPM_MASK = ~(32'(VEC_SCRATCHPAD_BYTES) - 32'd1);
  localparam logic [31:0]     MEM_MASK = ~(32'(MEM_BYTES) - 32'd1);
  localparam logic [9*32-1:0] ALL_MASK = {{8{SPM_MASK}}, MEM_MASK};
  localparam logic [NS*32-1:0]  SLV_BASE = ALL_BASE[NS*32-1:0];
  localparam logic [NS*32-1:0]  SLV_MASK = ALL_MASK[NS*32-1:0];
  localparam logic [NM*NS-1:0]  MST_SLV_EN = {{(NM - 1){{(NS - 1){1'b0}}, 1'b1}}, {NS{1'b1}}};

  logic [NM-1:0]    xm_req_valid, xm_req_ready, xm_req_write, xm_rsp_valid, xm_rsp_ready, xm_rsp_error;
  logic [NM*32-1:0] xm_req_addr;
  logic [NM*W-1:0]  xm_req_wdata, xm_rsp_rdata;
  logic [NM*WB-1:0] xm_req_wstrb;
  logic [NS-1:0]    xs_req_valid, xs_req_ready, xs_req_write, xs_rsp_valid, xs_rsp_ready, xs_rsp_error;
  logic [NS*32-1:0] xs_req_addr;
  logic [NS*W-1:0]  xs_req_wdata, xs_rsp_rdata;
  logic [NS*WB-1:0] xs_req_wstrb;

  // m0: host data port
  assign xm_req_valid[0] = h_req_valid;  assign h_req_ready = xm_req_ready[0];  assign xm_req_write[0] = h_req_write;
  assign xm_req_addr[31:0] = h_req_addr; assign xm_req_wdata[W-1:0] = h_req_wdata; assign xm_req_wstrb[WB-1:0] = h_req_wstrb;
  assign h_rsp_valid = xm_rsp_valid[0];  assign xm_rsp_ready[0] = h_rsp_ready;  assign h_rsp_rdata = xm_rsp_rdata[W-1:0];
  assign h_rsp_error = xm_rsp_error[0];

  // cluster memory masters
  for (genvar i = 0; i < NSLOT; i++) begin : g_mport
    localparam bit IS_V = i < MAXV;
    localparam int M    = IS_V ? (1 + i) : (1 + NV + (i - MAXV));
    if (PRESENT_MASK[i]) begin : g_on
      assign xm_req_valid[M]             = sm_req_valid[i];
      assign sm_req_ready[i]             = xm_req_ready[M];
      assign xm_req_write[M]             = sm_req_write[i];
      assign xm_req_addr[M*32 +: 32]     = sm_req_addr[i*32 +: 32];
      assign xm_req_wdata[M*W +: W]      = sm_req_wdata[i*W +: W];
      assign xm_req_wstrb[M*WB +: WB]    = sm_req_wstrb[i*WB +: WB];
      assign sm_rsp_valid[i]             = xm_rsp_valid[M];
      assign xm_rsp_ready[M]             = sm_rsp_ready[i];
      assign sm_rsp_rdata[i*W +: W]      = xm_rsp_rdata[M*W +: W];
      assign sm_rsp_error[i]             = xm_rsp_error[M];
    end else begin : g_off
      assign sm_req_ready[i] = 1'b0; assign sm_rsp_valid[i] = 1'b0; assign sm_rsp_rdata[i*W +: W] = '0;
      assign sm_rsp_error[i] = 1'b0;
    end
  end

  // vector scratchpad windows (slaves)
  for (genvar k = 0; k < MAXV; k++) begin : g_lport
    if (k < NLM) begin : g_on
      assign sl_lm_req_valid[k]            = xs_req_valid[1 + k];
      assign xs_req_ready[1 + k]           = sl_lm_req_ready[k];
      assign sl_lm_req_write[k]            = xs_req_write[1 + k];
      assign sl_lm_req_addr[k*32 +: 32]    = xs_req_addr[(1 + k)*32 +: 32];
      assign sl_lm_req_wdata[k*W +: W]     = xs_req_wdata[(1 + k)*W +: W];
      assign sl_lm_req_wstrb[k*WB +: WB]   = xs_req_wstrb[(1 + k)*WB +: WB];
      assign xs_rsp_valid[1 + k]           = sl_lm_rsp_valid[k];
      assign sl_lm_rsp_ready[k]            = xs_rsp_ready[1 + k];
      assign xs_rsp_rdata[(1 + k)*W +: W]  = sl_lm_rsp_rdata[k*W +: W];
      assign xs_rsp_error[1 + k]           = sl_lm_rsp_error[k];
    end else begin : g_off
      assign sl_lm_req_valid[k] = 1'b0; assign sl_lm_req_write[k] = 1'b0; assign sl_lm_req_addr[k*32 +: 32] = 32'd0;
      assign sl_lm_req_wdata[k*W +: W] = '0; assign sl_lm_req_wstrb[k*WB +: WB] = '0; assign sl_lm_rsp_ready[k] = 1'b1;
    end
  end

  /* verilator lint_off UNUSEDSIGNAL */
  logic        x_err_evt, x_err_write;
  logic [31:0] x_err_addr;
  logic [((NM > 1) ? $clog2(NM) : 1)-1:0] x_err_master;
  logic [NM-1:0] x_rsp_stall;
  /* verilator lint_on UNUSEDSIGNAL */
  sfb_crossbar #(
    .NM(NM), .NS(NS), .AW(32), .DW(W), .ARB_MODE(1), .CHECK_ALIGN(1),
    .SLV_BASE(SLV_BASE), .SLV_MASK(SLV_MASK), .MST_SLV_EN(MST_SLV_EN)
  ) u_noc (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(xm_req_valid), .m_req_ready(xm_req_ready), .m_req_write(xm_req_write), .m_req_addr(xm_req_addr),
    .m_req_wdata(xm_req_wdata), .m_req_wstrb(xm_req_wstrb), .m_rsp_valid(xm_rsp_valid), .m_rsp_ready(xm_rsp_ready),
    .m_rsp_rdata(xm_rsp_rdata), .m_rsp_error(xm_rsp_error),
    .s_req_valid(xs_req_valid), .s_req_ready(xs_req_ready), .s_req_write(xs_req_write), .s_req_addr(xs_req_addr),
    .s_req_wdata(xs_req_wdata), .s_req_wstrb(xs_req_wstrb), .s_rsp_valid(xs_rsp_valid), .s_rsp_ready(xs_rsp_ready),
    .s_rsp_rdata(xs_rsp_rdata), .s_rsp_error(xs_rsp_error),
    .err_evt(x_err_evt), .err_addr(x_err_addr), .err_master(x_err_master), .err_write(x_err_write),
    .ev_req_accept(mon_req_accept), .ev_req_stall(mon_req_stall), .ev_arb_loss(mon_arb_loss),
    .ev_rsp_stall(x_rsp_stall));

  // s0: shared memory, through the optional external slice
  sfb_reg_slice #(.AW(32), .DW(W), .REQ_SLICE(EXT_PIPE), .RSP_SLICE(EXT_PIPE)) u_ext_slice (
    .clk(clk), .rst_n(rst_n),
    .s_req_valid(xs_req_valid[0]), .s_req_ready(xs_req_ready[0]), .s_req_write(xs_req_write[0]),
    .s_req_addr(xs_req_addr[31:0]), .s_req_wdata(xs_req_wdata[W-1:0]), .s_req_wstrb(xs_req_wstrb[WB-1:0]),
    .s_rsp_valid(xs_rsp_valid[0]), .s_rsp_ready(xs_rsp_ready[0]), .s_rsp_rdata(xs_rsp_rdata[W-1:0]),
    .s_rsp_error(xs_rsp_error[0]),
    .m_req_valid(mem_req_valid), .m_req_ready(mem_req_ready), .m_req_write(mem_req_write), .m_req_addr(mem_req_addr),
    .m_req_wdata(mem_req_wdata), .m_req_wstrb(mem_req_wstrb), .m_rsp_valid(mem_rsp_valid), .m_rsp_ready(mem_rsp_ready),
    .m_rsp_rdata(mem_rsp_rdata), .m_rsp_error(mem_rsp_error));
endmodule

`default_nettype wire
