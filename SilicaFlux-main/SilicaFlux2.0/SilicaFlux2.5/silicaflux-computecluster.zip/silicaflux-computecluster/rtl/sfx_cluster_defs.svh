// =============================================================================
// SilicaFlux Project 32 :: sfx_cluster_defs.svh
// Shared definitions of the SilicaFlux ComputeCluster (vector / tensor cluster
// wrappers and the compute-cluster integration shell).  Aureom.AI | SilicaFlux-HPC
//
// A `define header (not a package) for the reason given by DataFabric
// dma_defs.svh and HPC Module 08 hpc_tile_defs.svh: Yosys 0.33 cannot resolve
// package references in module parameter lists.
// Rules: never renumber, only append.
// =============================================================================
`ifndef SFX_CLUSTER_DEFS_SVH
`define SFX_CLUSTER_DEFS_SVH

// ------------------------------------------------------------ identification
`define SFX_CC_ID               32'h5346_4343   // "SFCC"
`define SFX_CC_VERSION          32'h0001_0000   // 1.0

// ------------------------------------------------------------ slots and cluster IDs
// A cluster ID is {TYPE, INDEX[2:0]}: vector slot k -> ID k (0..7), tensor slot j -> ID 8+j (8..11).
// The ID is also the bit position of the cluster in every per-cluster vector of the shell.
`define SFX_ID_W                4
`define SFX_MAX_VEC             8
`define SFX_MAX_TSU             4
`define SFX_NSLOT               12              // MAX_VEC + MAX_TSU
`define SFX_TSU_ID0             8

// ------------------------------------------------------------ command / completion streams
// Command payload: the unit's own descriptor, word 0 in bits [31:0].
//   vector cluster: 8 words (HPC Module 08 descriptor, hpc_tile_defs.svh)
//   tensor cluster: 12 words (TENSORCORE 08 GEMM descriptor, tsu_defs.svh)
// Completion payload: the unit's own 6-word completion record, word 0 in bits [31:0],
// read verbatim from the unit's CPL registers (vector: CPL_INFO..CPL_CYCLES; tensor: CPL0..CPL5).
`define SFX_VEC_CMD_WORDS       8
`define SFX_TSU_CMD_WORDS       12
`define SFX_CMD_W               384             // shell ingress payload (12 words; vector uses [255:0])
`define SFX_CPL_WORDS           6
`define SFX_CPL_W               192

// Shell-generated completion (command addressed to an absent cluster):
//   word0 = {SFX_SHELL_REC_MAGIC, SFX_SE_*}, word1 = command word 0 (carries the TAG / TID), words 2..5 = 0
`define SFX_SHELL_REC_MAGIC     16'h5345        // "SE"
`define SFX_SE_BAD_DEST         16'h0001

// ------------------------------------------------------------ per-cluster performance events (registered pulses)
`define SFX_EV_CMD_ACCEPT       0   // command accepted at the cluster boundary
`define SFX_EV_CPL              1   // completion delivered at the cluster boundary
`define SFX_EV_CPL_ERR          2   // ... with an error status
`define SFX_EV_BUSY             3   // unit busy (queued / executing work)
`define SFX_EV_MEM_REQ          4   // memory request accepted at the cluster memory port
`define SFX_EV_MEM_STALL        5   // memory request presented and not accepted (contention / back-pressure)
`define SFX_EV_LOCAL            6   // vector: local-memory window request accepted; tensor: systolic array computing
`define SFX_EV_CMD_STALL        7   // command presented and not accepted (back-pressure)
`define SFX_NUM_EV              8

// ------------------------------------------------------------ shell register page
`define SFX_R_ID                12'h000   // RO "SFCC"
`define SFX_R_VERSION           12'h004   // RO
`define SFX_R_CONFIG0           12'h008   // RO [3:0] NV [7:4] NT [11:8] log2(TRANSACTION_WIDTH/8) [12] LOCAL_MEM_PORT
                                          //    [13] MEM_PIPE [14] CMD_IF [15] EXT_PIPE [23:16] VEC_NUM_LANES
                                          //    [28:24] log2(VEC_SCRATCHPAD_BYTES) [29] CMD_PIPE [30] SHELL_PERF
`define SFX_R_CONFIG1           12'h00C   // RO [7:0] TSU_ARRAY_ROWS [15:8] TSU_ARRAY_COLS [31:16] TSU_TILE_K
`define SFX_R_PRESENT           12'h010   // RO [11:0] populated slots
`define SFX_R_BUSY              12'h014   // RO [11:0] cluster busy
`define SFX_R_IN_RESET          12'h018   // RO [11:0] cluster held in local reset
`define SFX_R_CLK_REQ           12'h01C   // RO [11:0] cluster clock-enable request (activity)
`define SFX_R_CL_RESET          12'h020   // WO [11:0] write 1: reset that cluster (isolate, hold, release); reads 0
`define SFX_R_ERR_STATUS        12'h024   // W1C [11:0] cluster error seen (error completion / halt) [16] BAD_DEST
`define SFX_R_IRQ_EN            12'h028   // RW [0] cluster IRQ lines [1] ERR_STATUS
`define SFX_R_CL_IRQ            12'h02C   // RO [11:0] cluster interrupt lines
`define SFX_R_BAD_DEST          12'h030   // RO commands addressed to an absent cluster (saturating)
`define SFX_R_PERF_CTRL         12'h034   // WO [0] clear the event counters; reads 0
`define SFX_R_SPM_BASE          12'h038   // RO local-memory window of vector slot 0 (slot k: + k * SPM bytes)
`define SFX_R_MEM_BASE          12'h03C   // RO shared-memory window base
`define SFX_R_INFLIGHT0         12'h040   // RO INFLIGHT[i] at 0x040 + 4 i: commands accepted - completions delivered
`define SFX_R_LOST0             12'h080   // RO LOST[i] at 0x080 + 4 i: commands destroyed by the last reset of slot i
`define SFX_R_EVCNT0            12'h100   // RO EVCNT[i][e] at 0x100 + 0x20 i + 4 e (SHELL_PERF = 1), saturating

`endif
