# 04 — Interface timing, pipeline boundaries and physical locality

Numbers come from `reports/synth.md` (generic netlists, fanout through the hierarchy), `reports/perf.md`
(measured cycles) and `reports/physical.md` (OpenROAD, reduced configuration).

## 1. High-fanout signals (leaf input pins reached, memories counted as one leaf per port bit)

| Signal | Where | Leaf loads | Treatment |
|---|---|---|---|
| `clk` | whole subsystem, 4 + 2 | 73 106 (76 172 with slices), excluding memory macros | one domain; CTS per region is natural because every region is a contiguous hierarchy |
| `rst_n` (global) | top of the 4 + 2 shell | 2 348 | each cluster re-derives its own `local_rst_n = rst_n ∧ ¬iso_q` (`u_rst`), so the global tree only reaches the shell logic, slices and each cluster's `u_rst` / status flops |
| `g_cl.local_rst_n` | inside one cluster | vector 1 543, tensor 3 145 | the per-region reset tree, sourced from a flip-flop (synchronous assert / release, asynchronous global assert) |
| `g_cl.u_addr[8]` (register-page decode) | inside one cluster | vector 770, tensor 1 219 | local to the region: the unit's register decode / read mux; only the 12-bit address crosses the boundary |
| `sl_lm_rsp_valid[k]` | shell, per vector cluster | 239 | response routing of each local-memory port inside `u_noc` |
| `sl_csr_sel[id]`, `shell_sel` | shell | 34–37 | page decode, one per region |

## 2. Wide buses

| Bus | Width | Endpoints | Registered at both ends? |
|---|---|---|---|
| `cmd_data` → `sl_cmd_data` | 384 (vector uses 256) | shell ingress → every cluster's hold register (broadcast, valid per cluster) | sink: hold register in `u_ctrl`; source: `CMD_PIPE = 1` skid buffer at the shell boundary |
| `sl_cpl_data` | 192 per cluster (2 304 for 12 slots; 1 152 used in 4 + 2) | every cluster's record register → `u_cpl_arb` (13:1 mux) → skid buffer | yes: `u_ctrl` output register → arbiter skid register (one region crossing) |
| crossbar master data | 32 + W request, W response per cluster | cluster DMA → `u_noc` | only with `MEM_PIPE = 1` |
| crossbar slave data | W per local-memory port | `u_noc` → vector scratchpad window | only with `LM_PIPE = 1` |
| shared-memory port | 32 + W + W/8 / W | `u_noc` → `mem_*` | only with `EXT_PIPE = 1` |
| `t_perf_ev` | 640 | tensor unit → event reduction | **kept inside the tensor region**: only 8 registered event bits leave it |
| CSR `rdata` | 32 per cluster | cluster → shell read mux | **combinational round trip** (rb protocol answers in the strobe cycle), §4 |

## 3. Pipeline boundaries (parameters, all default 0)

| Parameter | Where | Implementation | Added latency | Buffering | Flip-flops (measured, W = 32) |
|---|---|---|---|---|---|
| `MEM_PIPE` | every cluster memory port, between `u_rst` (or `u_upsize`) and the crossbar | DataFabric `sfb_reg_slice`, both channels | +1 cycle request, +1 cycle response | 2-entry skid buffer per channel | ≈ 208 per cluster |
| `LM_PIPE` | every vector local-memory port | `sfb_reg_slice` | +1 / +1 | 2 + 2 entries | ≈ 208 per vector cluster |
| `EXT_PIPE` | shared-memory port (crossbar slave 0) | `sfb_reg_slice` | +1 / +1 | 2 + 2 entries | 208 |
| `CMD_PIPE` | command ingress | `sfb_skid_buffer` (388 bits) | +1 cycle per command | 2 entries | 778 |

Totals from synthesis: the 4 + 2 shape with every slice has 3 066 more flip-flops than without (`compute_hpc_piped`
vs `compute_hpc`).

**Correctness.** `sfb_reg_slice` is protocol-transparent: in order, one response per request, stable payloads
under back-pressure; it is DataFabric's verified slice. Between a master and a crossbar master port it gives the
master one more transaction in flight than the crossbar sees. PROTOCOL.md §7 allows that only for masters that
track their own outstanding count. Both cluster masters do: the DataFabric simple DMA engine keeps one transaction
in flight, and the tensor DMA keeps `MAX_OUT` with its own FIFO. The width converter's lane FIFO is sized
`MAX_OUT + 2` to cover the two sliced channels. Between a crossbar slave port and its slave, the crossbar's
one-outstanding rule holds end to end. All four slices are on in the regression configurations `p64` and `phys`
(mixed traffic, back-pressure, cluster reset): every run passes with zero SFB2 violations.

**Cost (measured, `reports/perf.md`).** The crossbar keeps one transaction per port (SFB2 R6), and the vector DMA
keeps exactly one in flight. Every sliced direction therefore adds about 1 cycle to every DMA round trip:

* control path: a NOP goes from 23 to 24 cycles end to end (`CMD_PIPE`: +1);
* DMA-bound commands with a 1-cycle memory: ×1.72–×1.78 (KERNEL vl=512 8 096 → 14 240 unit cycles; GEMM 32×32×128
  68 378 → 121 242);
* with an 8-cycle memory: ×1.21–×1.33. The penalty is a constant number of cycles per transaction (+769 cycles for
  the 192 transactions of a vl=64 KERNEL at both latencies), so it shrinks as memory latency grows.

**Placement evidence (docs/07, `reports/physical.md`).** The reduced 4 + 2 design was placed by OpenROAD and timed
pre-CTS after buffering, with an ideal clock and a 20 ns reference. With every slice on, all region-boundary
interfaces have positive slack and the critical paths are inside the regions. Without slices, the worst path through
the cluster memory interface (scratchpad response → combinational crossbar → another cluster's DMA) arrives at
23.2 ns and fails, and TNS grows 4.4×. The slices are therefore *required* for a spread placement and *not* for a
compact one.

**Policy.** Boundaries are inserted only where required: all are off by default (minimum and HPC configurations).
`CMD_PIPE` is nearly free and can be enabled whenever the command source is far from the shell. `MEM_PIPE` /
`EXT_PIPE` are timing-closure options for a spread floorplan, with the measured throughput price above. The
`hpc_piped` configuration and the `phys` experiment show them working; they are not a default. Recovering the
throughput would require transaction IDs / multiple outstanding transactions in the crossbar (DataFabric
PROTOCOL.md §8, not implemented upstream).

## 4. Paths that cross a region boundary

| Path | Start → end | Registered? |
|---|---|---|
| command | shell `cmd_*` → `u_cmd_route` (decode) → cluster hold register | end: yes; start: with `CMD_PIPE`. `cmd_ready` comes from a cluster flip-flop through the router mux |
| completion | cluster record register → `u_cpl_arb` → skid register → `cpl_*` | yes / yes |
| memory request / response | unit DMA register → `u_rst` mux → (`u_upsize`) → crossbar decode / arbitration / mux → shared-memory port | with `MEM_PIPE` + `EXT_PIPE` every hop is register-bounded; without, one combinational path cluster → NoC → port, and `ready` / response back |
| local memory | crossbar slave → (`u_lm_slice`) → `u_rst` → tile scratchpad window | with `LM_PIPE` |
| status, interrupt, events | unit → cluster boundary flip-flops → shell (`u_regs` registers ERR_STATUS / IRQ again) | yes, 1 cycle at the boundary; narrow (≤ 13 wires per cluster) |
| cluster reset | `u_regs` CL_RESET flip-flop → `u_rst` → `iso_q` flip-flop → `local_rst_n` | yes |
| **CSR (rb)** | host `rb_addr` → shell page decode → cluster `u_ctrl` mux → unit register decode / read mux → back to the shell read mux, **in one cycle** | **no**: the SilicaFlux-V rb protocol answers in the strobe cycle. This is the one unregistered cross-region round trip. Mitigation outside this project: a registered rb variant at the SoC bridge, which already returns `rvalid` one cycle after the grant. Recorded in docs/08 |

## 5. Physical locality expressed in the hierarchy

| Rule | How it is expressed |
|---|---|
| Vector engine near its local scratchpad | lanes (`u_array`, the M03 vector array), LSU (`u_lsu`) and the banked scratchpad (`u_spm`) are siblings inside `g_cl.u_tile`. Instance group `VEC<k>_LANES_SPM` names exactly these (`physical/<cfg>/groups.tcl`) |
| Tensor array near operand / accumulator storage | `u_arr` (systolic array), `u_tob` (operand buffers), `u_acc` (accumulator), `u_seq` in `g_cl.u_tsu/u_dp`; group `TSU<j>_ARRAY_BUFFERS` |
| Cluster interfaces facing the NoC | `u_mem_slice`, `u_lm_slice`, `u_upsize` and the engine's DMA (`u_dma`, tensor `u_ob`) form group `<C><k>_DMA_NOCIF`. The region template puts vector clusters in the outer columns with their NoC side towards the central crossbar column, tensor clusters on the NoC axis, and `u_noc` + `u_ext_slice` in the centre |
| Control / error outputs narrow and registered | ≤ 13 status / event wires per cluster, all from flip-flops at the boundary; the 640-bit tensor event bus stays inside |
| Shell control together | `u_regs`, `u_cmd_route`, `u_cpl_arb` → region `SFX_CTRL`, next to the NoC on the host side |

Locality is **not** assumed to happen automatically: the regions and groups are explicit constraints
(`physical/`). docs/07 measures what the placer does with and without them.
