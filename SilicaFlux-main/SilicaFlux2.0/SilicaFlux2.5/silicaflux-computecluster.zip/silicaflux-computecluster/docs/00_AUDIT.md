# 00 — Repository audit (what exists, what is reused, what is new)

Source: `btcphilosopher/Aureom.AI`, branch `claude/happy-bohr-vbg8k3`, `SilicaFlux-main/` archives. Every reused
file is vendored **byte for byte** under `third_party/` (`SHA256SUMS`, `PROVENANCE.md`). The reused copies are
identical across the projects that carry them; the SHA-256 of `sfb_crossbar.sv`, `sfb_arbiter.sv` and the other
interconnect files was compared between the DataFabric archive and TENSORCORE 08's copy.

## 1. Items named in the brief

| Item | Where it lives | State found | Use here |
|---|---|---|---|
| `hpc_vector_array.sv` | `silicaflux-hpc-m03-vector-array.zip` → vendored in M08 `third_party/` | verified in M03 (regression, mutation, gate-level sim) and again inside M08 | inside the tile, **unmodified** |
| `silicaflux_hpc_tile.sv` | `silicaflux-hpc-m08-tile.zip` (also carried by TC08, P21, P28) | M08: 145 / 145 integration runs, firmware on SilicaFlux-V, ECP5 P&R 31.24 MHz post-route estimate; abc mapping of the flattened tile > 10 min / config (cut in M08) | the vector engine, **unmodified** |
| `silicaflux_tensor_unit.sv` | `silicaflux-tensorcore08.zip` | TC08: stages 1–3 (642 GEMMs), Icarus/Verilator cross-sim, coexistence with the tile 9 / 9, ECP5 P&R 28.85 MHz baseline estimate (full config misses 25 MHz), SKY130 smoke test 154 882 cells (buffers as flip-flops) | the tensor engine, **unmodified** |
| TensorCore verification | TC08 `model/` (`tsu_ref.py`, `tsu_abi.py`, `prog.py`, `check.py`) + TC05 `tq_ref.py` | independent Python reference, ABI generated from `tsu_defs.svh` | GEMM descriptors and expected results of this project's tests |
| Scratchpad interfaces | `silicaflux-hpc-m04-scratchpad.zip` (`hpc_scratchpad`, `hpc_spm_defs.svh`) | banked 1RW scratchpad, per-bank RR, host window | the tile's host window becomes the cluster's local-memory port |
| DataFabric | `silicaflux-datafabric.zip` | SFB2 protocol (R1–R12), `sfb_crossbar` (unbounded formal proofs of the interconnect), `sfb_reg_slice` / `sfb_skid_buffer`, `sfb_error_slave`, protocol checker | crossbar `u_noc`, every pipeline boundary, completion-arbiter output stage, protocol checkers |
| Actual synthesis results | M08 `reports/synth.md`, TC08 `reports/synth.md`, FloorplanLab `reports/synthesis/` | FPGA mapping + nextpnr estimates; SKY130 smoke test; FloorplanLab: ORFS on IHP SG13G2 for SilicaFlux-V (not the HPC tile) | baseline for the numbers in docs/06; FloorplanLab's pinned OpenROAD build reused for docs/07 |

## 2. Other findings that shaped the design

* **The two engines take commands only through their register pages.** Both use the SilicaFlux-V rb protocol:
  stage descriptor words, ring DOORBELL, read CPL registers, pop. A stream interface therefore needs an adapter
  (`sfx_cluster_ctrl`). Pushing directly into the internal command queue would have meant editing verified RTL.
* **The crossbar keeps one transaction per port (SFB2 R6)** and is combinational (0 added cycles). Pipeline
  boundaries are the reused `sfb_reg_slice`. PROTOCOL.md §7 allows a slice between a master and the crossbar only
  if that master tracks its own outstanding count. Both DMA masters do: the DataFabric simple engine keeps one
  transaction in flight, and the tensor unit's `tdma_sfb_port` keeps `MAX_OUT` with its own FIFO.
* **No ready/wait state on the rb protocol.** Host accesses and the adapter must share the unit's page without
  changing register semantics. The SilicaFlux-V LSU leaves at least one idle cycle per access (`sfv_cpu.sv`
  `lsu_wait_q`).
* **Yosys 0.33 names generate-loop instances `g[0].u`.** No generate construct yields a literal `u_vector_0`, hence
  the slot-based top level (docs/01 §3). Yosys 0.33 also needs `read_verilog -defer`, rejects `int'()` casts and
  declarations in unnamed blocks, and asserts with `chparam` on some tops (TC08). All new RTL follows these rules.
* **No OpenROAD in the base environment;** FloorplanLab's pinned recipe installs OpenROAD 2.0-12331-g6011bbe77 from
  the litex-hub conda channel. That build has `create_voltage_domain`, physical-cluster commands and the odb
  `dbRegion` / `dbGroup` API, but **no `create_region` command** (checked: `info commands`).
* **No SRAM macros for the HPC memories** in any open flow in the repository. The 64 KiB tile scratchpad is 524 288
  bits; mapped to flip-flops it dominates any gate count. Memories are therefore reported as inferred, not mapped
  (docs/06). The physical experiment uses a reduced configuration (docs/07).
* **Performance specifications in illustrations** (TFLOPS figures, die photos) are not used. Every number in this
  project comes from a tool run in `reports/`.

## 3. New in Project 32

| File | Purpose |
|---|---|
| `rtl/silicaflux_compute_cluster.sv` | integration shell (primary RTL) |
| `rtl/silicaflux_vector_cluster.sv`, `rtl/silicaflux_tensor_cluster.sv` | the two reusable region wrappers |
| `rtl/sfx_cluster_ctrl.sv` | local control: command / completion streams ⇄ register page |
| `rtl/sfx_cluster_rst_iso.sv` | cluster reset sequencer + SFB2-correct port isolation |
| `rtl/sfx_sfb_upsizer.sv` | 32-bit SFB2 master onto a 64/128-bit fabric |
| `rtl/sfx_cmd_router.sv`, `rtl/sfx_cpl_arbiter.sv`, `rtl/sfx_shell_regs.sv` | shell control |
| `rtl/sfx_cluster_defs.svh` | IDs, stream formats, events, shell register map |
