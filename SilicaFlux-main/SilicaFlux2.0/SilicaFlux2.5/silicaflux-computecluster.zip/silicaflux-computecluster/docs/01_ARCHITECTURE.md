# 01 — Architecture

## 1. Goal and non-goals

Organise the verified SilicaFlux engines into **repeatable, identifiable physical regions**, each with its own
local control, reset, status and NoC-facing ports. Keep the arithmetic pipelines exactly as verified. Not a
performance claim: the clusters run the throughput the engines already have (HPC M08 `reports/perf.md`, TC08
`reports/perf.md`). Nothing here assumes the large performance figures of the SilicaFlux illustrations.

## 2. Block diagram

```
                     host rb (page 7 shell, 8.. clusters)        host SFB2 data port (h_*)
                                 │                                        │
  cmd_* (dest ID) ──► u_cmd_route ──┐                                     │
  cpl_* (src ID)  ◄── u_cpl_arb ◄───┤  u_regs (ERR_STATUS, CL_RESET,     │
                                    │          INFLIGHT/LOST, EVCNT, IRQ) │
        ┌───────────────────────────┼───────────────────────────────────┼────────────────────────────┐
        │                           ▼                                   ▼                            │
        │ ┌───────────────────────┐   ┌───────────────────────┐   ┌───────────────────────────────┐  │
        │ │ u_vector_k            │   │ u_tensor_j            │   │ u_noc  (DataFabric crossbar)  │  │
        │ │  u_ctrl  u_rst        │   │  u_ctrl  u_rst        │   │  m0 host                      │  │
        │ │  u_tile (HPC M08):    │   │  u_tsu (TC08):        │   │  m1+k vector k DMA            │  │
        │ │   FP32 lanes, LSU,    │   │   systolic array,     │   │  m1+NV+j tensor j DMA         │  │
        │ │   banked scratchpad,  │   │   operand buffers,    │   │  s0 shared memory ──► u_ext_slice ──► mem_*
        │ │   DMA, cmd/cpl queues │   │   accumulator, quant, │   │  s1+k vector k scratchpad     │  │
        │ │  u_mem_slice ──mem_*──┼──►│   DMA, out buffer     │──►│                               │  │
        │ │  u_lm_slice ◄──lm_*───┼◄──│  u_upsize u_mem_slice │   │                               │  │
        │ └───────────────────────┘   └───────────────────────┘   └───────────────────────────────┘  │
        └──────────────────────────────────────────────────────────────────────────────────────────────┘
```

## 3. Slot-based hierarchy (stable instance names)

The shell instantiates **every slot**, always, as a direct child with a literal name: `u_vector_0` … `u_vector_7`
and `u_tensor_0` … `u_tensor_3`. `NUM_VECTOR_CLUSTERS = NV` populates `u_vector_0 .. u_vector_{NV-1}`;
`NUM_TENSOR_CLUSTERS = NT` populates `u_tensor_0 .. u_tensor_{NT-1}`. An unpopulated slot is the same wrapper with
`PRESENT = 0`: no cells, constant outputs, connected to nothing.

Why not a generate loop: Yosys 0.33 names a generate-loop instance `g_vector[0].u_vector` and an unnamed generate
block `genblk3.u_vector_9` (checked). Neither gives the instance name `u_vector_0` the brief asks for, and bracketed
names are awkward in every downstream Tcl. With fixed slots:

* the instance path of a region never changes with the configuration (`u_vector_2` is `u_vector_2` in 3+1, 4+2 or
  8+4), so floorplan constraints written once stay valid;
* the synthesized netlist contains exactly these names (checked by `syn/run_synth.py` for every target: "missing
  instances: []");
* the flattened OpenROAD instance names start with `u_vector_k/` and `u_tensor_j/` (docs/07);
* the cost is an empty module per unpopulated slot in the hierarchical netlist (0 cells in the generic netlists,
  listed as "(empty slot)" in the synthesis report). A technology-mapping flow that inserts tie cells and port
  buffers (`hilomap`, `insbuf`) would otherwise give each empty slot ~350 cells for its constant outputs (measured
  on sky130hd), so `physical/run_phys.py` dissolves the empty slots (`flatten` of those instances only) before
  mapping. Their outputs become top-level constants and the placed design contains no trace of them.

Scalability: 8 + 4 slots cover the HPC 4 + 2 shape with headroom (all 12 populated is simulated: `s3_max_*`).
Adding a slot is one macro line plus the ID / page arithmetic; the cluster wrappers themselves are fully
parameterised and independent of the shell.

Inside a cluster the names are fixed too: `g_cl.u_tile` / `g_cl.u_tsu`, `g_cl.u_ctrl`, `g_cl.u_rst`,
`g_cl.u_mem_slice`, `g_cl.g_lm.u_lm_slice`, `g_cl.u_upsize`. The shell's own blocks are `u_noc`, `u_ext_slice`,
`u_cmd_route`, `u_cpl_arb`, `u_regs`.

## 4. Local control per cluster

| Requirement | Mechanism |
|---|---|
| Command acceptance | `cmd_valid/ready` into a one-entry hold register; staged into the unit's page when STATUS allows |
| Busy status | `busy` = unit busy ∨ command held ∨ record pending (registered) |
| Completion | the unit's 6-word record, read and popped by `u_ctrl`, delivered on `cpl_*` with `cpl_err` |
| Error reporting | `cpl_err` per record; `err_ev` pulse on error completion or halt entry; shell ERR_STATUS + IRQ; LOST |
| Reset | `cl_rst_req` → `u_rst`: isolate, hold, drain, release; SFB2-correct (docs/02 §9) |
| Optional clock-enable request | `clk_req` (quiescence); shell adds wake sources → `cl_clk_en_req`; `ENABLE_CLK_REQ` |
| Performance events | 8 registered event bits; shell counts them (EVCNT, `SHELL_PERF`) |
| No duplicated arithmetic | the engines are instantiated once per cluster, unmodified; the wrappers add control and plumbing only |

## 5. Ownership and ordering

* A cluster's scratchpad is reachable by its own engine and the host only. The tensor unit's buffers are private.
  Cluster DMA reaches only the shared memory (crossbar access matrix).
* Per cluster, completions are delivered in command order. Across clusters there is no ordering: the merged stream
  carries `cpl_src` and each record its own TAG / TID and SEQ.
* No coherence; there are no caches. A producer's completion means all its writes were acknowledged (SFB2 R7: both
  engines complete only after the last write response). Software starts the consumer after that.

## 6. Reuse

| Block | Origin | Modified? |
|---|---|---|
| `silicaflux_hpc_tile` and everything below it | HPC Modules 02–08 | no |
| `silicaflux_tensor_unit` and everything below it | TENSORCORE 02–08 + HPC M08 queues / counters | no |
| `sfb_crossbar`, `sfb_arbiter`, `sfb_reg_slice`, `sfb_skid_buffer`, `sfb_error_slave` (+ protocol checker) | DataFabric | no |
| SRAM Wrapper Library, M04 scratchpad, M05 DMA adapter | Projects 01, M04, M05 | no |
