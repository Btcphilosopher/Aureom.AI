# 07 — Physical integration: regions, instance groups, OpenROAD support

> Exploratory. The constraints are a **proposal**. The OpenROAD run places a **reduced** configuration
> (`configs/phys_hpc.json`: 4 + 2 clusters, 1 FP32 lane, 1 KiB scratchpads, 2×2 INT8 arrays, depth-2 queues,
> counters off, every NoC-facing slice on). Memories are mapped to flip-flops because there is no SRAM-macro path for
> these shapes, and the run stops pre-CTS, with no routing, at the typical corner only. **No layout is inferred from
> the RTL hierarchy:** every coordinate in `reports/physical.md` was read back from the OpenROAD database after
> placement.

## 1. Files

| File | Content |
|---|---|
| `physical/gen_regions.py` | region sizing from measured cell area, the region template, instance-group extraction, placement measurement |
| `physical/phys_hpc/regions.tcl` | `SFX_REGIONS` (name, instance-name prefixes, box in DBU) + `sfx_apply_regions` (odb `dbRegion`, INCLUSIVE) |
| `physical/phys_hpc/groups.tcl` | `SFX_GROUPS` (locality groups inside each cluster, from actual names) + `sfx_apply_groups` (odb `dbGroup`) |
| `physical/phys_hpc/plan.json` | die / core / region boxes in µm and DBU, utilization target, area per region |
| `physical/apply_constraints.tcl` | reusable entry point: `set SFX_CFG_DIR …; source physical/apply_constraints.tcl` after floorplanning |
| `physical/run_phys.py` | sky130hd mapping (Yosys 0.33, hierarchy kept, empty slots dissolved), OpenROAD floorplan / pins / global + detailed placement / check_placement, `--control-only` (no regions) or with regions + groups |
| `physical/export_constraints.py` | applies the constraints to the mapped netlist without placement, counts members, writes DEF REGIONS / GROUPS |
| `physical/region_support_test.py`, `physical/region_test/*.tcl` | controlled test of the tool's region support (five mechanisms) |
| `physical/post_sta.py` | `repair_design` + pre-CTS timing of a placed run, worst path through every region-boundary interface |
| `physical/summarize.py`, `physical/plot_placement.py` | result collection (`reports/physical/summary.json`), SVG of placed instances (sampled) with the proposed boxes |
| `configs/phys_hpc.json`, `configs/phys_hpc_noslice.json` | the reduced configuration with and without the NoC-facing slices |
| `reports/physical.md`, `reports/physical/` | results, OpenROAD logs (gzip), timing reports, SVG, DEF REGIONS / GROUPS excerpt |

## 2. Instance names used

OpenROAD flattens the hierarchical Verilog netlist when it links it. Every leaf instance is named by its hierarchical
path with `/`, for example `u_vector_2/g_cl.u_tile/g_core.u_spm/...` and `u_tensor_1/g_cl.u_tsu/u_dp/u_arr/...`.
Region membership is therefore an instance-name prefix: `u_vector_k/`, `u_tensor_j/`, `u_noc/`, `u_ext_slice/`,
`u_regs/`, `u_cmd_route/`, `u_cpl_arb/`. These are the synthesis instance names, unchanged. Groups use deeper
prefixes taken from the netlist, e.g. `u_vector_0/g_cl.u_tile/g_core.u_array/`. `sfx_apply_regions` prints the
member count of every region and flags a region that matched no instance.

## 3. Region template (generated, not hard-coded)

```
 ┌────────────┬──────────────────────┬────────────┐
 │ SFX_VEC0   │ SFX_TSU0             │ SFX_VEC1   │   outer columns: vector clusters, NoC side facing the centre
 │ u_vector_0 │ u_tensor_0           │ u_vector_1 │
 ├────────────┼──────────┬───────────┼────────────┤
 │            │ SFX_CTRL │ SFX_NOC   │            │   centre: crossbar + shared-memory slice, shell control
 ├────────────┼──────────┴───────────┼────────────┤
 │ SFX_VEC2   │ SFX_TSU1             │ SFX_VEC3   │
 │ u_vector_2 │ u_tensor_1           │ u_vector_3 │
 └────────────┴──────────────────────┴────────────┘
```

Each region's area = its measured sky130hd cell area / target utilization (0.45). Column widths and row heights
follow from those areas, and the boxes are snapped to the 0.46 µm site / 2.72 µm row grid. The RTL contains no
coordinates.

## 4. Tool support check (OpenROAD 2.0-12331-g6011bbe77, FloorplanLab's pinned build)

| Mechanism | Present? | Used |
|---|---|---|
| `create_region` Tcl command | **no** (`info commands`) | — |
| odb `dbRegion_create`, `dbBox_create`, `dbRegion::addInst`, `dbInst::getRegion` | yes | regions (INCLUSIVE: members must be placed inside) |
| odb `dbGroup_create`, `dbGroup::addInst` | yes | instance groups (PHYSICAL_CLUSTER) |
| `create_voltage_domain`, `create_physical_cluster`, `add_to_physical_cluster` | yes | not used: a single voltage domain; the odb calls cover physical clusters |
| `write_def` REGIONS / GROUPS | yes | exported, so other tools can read the constraints |
| `global_placement` / `detailed_placement` honouring regions | **measured below** | |

## 5. Results (details and every number: `reports/physical.md`)

**The constraints are valid for the real netlist.** `apply_constraints.tcl` loads them onto the mapped reduced 4 + 2
design (≈ 520 k instances) in 3.4 s with no placement. All 8 regions and 18 groups get members: for example
SFX_VEC0 74 328 instances, SFX_TSU0 105 367, VEC0_LANES_SPM 55 134, TSU0_ARRAY_BUFFERS 43 152. DEF REGIONS / GROUPS
are written (`reports/physical/phys_hpc_regions_groups.def`) for any tool that imports them.

**This OpenROAD build cannot steer placement with them** (controlled test, two 4 729-cell blocks, boxes in opposite
corners):

* `global_placement` honours none of the mechanisms. 0 cells end up inside the box with a plain odb region, with a
  voltage domain, and with members seeded at the box centre (`-skip_initial_place`): the seeds are discarded and the
  result is identical to the unconstrained control.
* `detailed_placement` ignores plain odb regions. It forces voltage-domain members into their box: 100 % inside, but
  568 µm average displacement and `check_placement` FAILS (DPL-0033).
* Region-less PHYSICAL_CLUSTER groups make `detailed_placement` exhaustive: unfinished after 10 min for 9.5 k cells
  (bounded run, reproduced by `physical/region_support_test.py`). On the
  full reduced design (regions + groups applied before placement) detailed placement was still in
  `Opendp::diamondSearch` after 44 CPU-minutes (gdb stack sample) and was stopped. The control placement of the same
  design takes about 4 minutes.

**Without constraints, locality does not happen by itself.** In the unconstrained placement of the full reduced
design, each cluster's instances spread over a bounding box 3.4–7× the area of its proposed region. The clusters
interleave: SFX_VEC3 has 0 % of its cells in its box, SFX_TSU1 4 %, SFX_NOC 0 %
(`reports/physical/phys_hpc_placement_no_regions.svg`). This is the measured case for constraints.

**The NoC-facing slices matter for timing** (pre-CTS, after `repair_design`, ideal clock, 20 ns reference period,
same reduced design placed twice):

* with every slice: WNS −3.32 ns, and all 300 worst data paths are **inside** a region (TC03 operand-buffer address
  generator of the tensor units). Every region-boundary interface has positive slack. The worst is the
  combinational CSR round trip (+6.9 ns, 12.9 ns arrival from `rb_addr` into a tensor register), then the completion
  path (+9.0 ns), then the crossbar paths (≈ 8–9 ns arrival, +11 ns);
* without slices: WNS −5.08 ns, TNS −1 208 ns (vs −277 ns). The worst path through the cluster memory interface
  **fails**: vector 3's scratchpad response, through the combinational crossbar, into tensor 0's DMA, 23.2 ns
  arrival (−3.27 ns). The other interfaces: `reports/physical.md` §5.

So for a spread placement of this size the memory-side slices are required at this reference period, at the
throughput cost measured in docs/04 §3. For a compact placement they are not, which is why they stay parameters
(default off).

## 6. Recommended use downstream

1. **Hierarchical (block-level) implementation**, which the slot hierarchy is built for. Harden one
   `silicaflux_vector_cluster` and one `silicaflux_tensor_cluster` as blocks (independent synthesis targets,
   docs/06), then place `u_vector_k` / `u_tensor_j` as macros around `u_noc`. Macro placement is supported by this
   OpenROAD / ORFS. Region placement is not.
2. **Flat implementation in a tool with fence / guide support**: import the DEF REGIONS / GROUPS, or use the Tcl
   lists `SFX_REGIONS` / `SFX_GROUPS` (name, instance-name prefixes, box) directly.
3. Re-generate the region boxes for the real configuration and memories. The template sizes come from the mapped area
   of whatever netlist `gen_regions.region_areas()` is given; with SRAM macros the vector regions shrink and must
   host the macros.
4. Enable `MEM_PIPE` / `EXT_PIPE` (and `LM_PIPE`) when the clusters are spread around the crossbar, as the no-slice
   timing above shows; keep them off for compact placements to avoid the per-transaction cycle (docs/04).

