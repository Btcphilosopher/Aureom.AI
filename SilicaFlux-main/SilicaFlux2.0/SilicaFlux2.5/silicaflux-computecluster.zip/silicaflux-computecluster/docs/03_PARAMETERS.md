# 03 — Parameters and configurations

Every parameter is checked at elaboration. An illegal value stops Verilator, Icarus and Yosys with the design's own
`$fatal` message (`scripts/run_lint.py`: 12 illegal configurations, each refused by all three tools; Verilator's
refusal must be a USERFATAL). Defaults = **the minimum configuration**.

## 1. Shell (`silicaflux_compute_cluster`)

| Brief item | Parameter | Default | Legal |
|---|---|---|---|
| Vector cluster count | `NUM_VECTOR_CLUSTERS` | 1 | 0..8 (slots `u_vector_0..7`) |
| Tensor cluster count | `NUM_TENSOR_CLUSTERS` | 1 | 0..4 (slots `u_tensor_0..3`); at least one cluster in total |
| Vector lane count | `VEC_NUM_LANES` | 4 | 1, 2, 4, 8, 16 (HPC M08 rule) |
| Tensor PE array dimensions | `TSU_ARRAY_ROWS`, `TSU_ARRAY_COLS` | 4, 4 | 2×2, 4×4, 8×8 (TC08 verified list; others need the unit's `ALLOW_UNVERIFIED`) |
| Scratchpad capacity | `VEC_SCRATCHPAD_BYTES` (+ `TSU_OPERAND_BUFFER_BYTES`) | 65536 (2048) | power of two 1 KiB–16 MiB (TC08 rules) |
| Transaction width | `TRANSACTION_WIDTH` | 32 | 32, 64, 128 (SFB2 widths; tensor via `sfx_sfb_upsizer`) |
| Optional local memory interface | `LOCAL_MEM_PORT` | 1 | 0, 1 |
| Pipeline boundaries | `MEM_PIPE`, `LM_PIPE`, `EXT_PIPE`, `CMD_PIPE` | 0 | 0, 1 (docs/04) |
| Command path | `CMD_IF` | 1 | 1 streams, 0 legacy register page |
| Shared memory window | `MEM_BASE`, `MEM_BYTES` | 0x1000_0000, 1 MiB | power of two ≥ 1 KiB, base aligned |
| Scratchpad windows | `VEC_SPM_BASE` | 0x2000_0000 | slot k at `VEC_SPM_BASE + k·VEC_SCRATCHPAD_BYTES`; must not overlap the shared window or leave 4 GiB |
| Register bus | `RB_AW`, `SHELL_PAGE`, `CL_PAGE0` | 16, 7, 8 | all pages fit `RB_AW` and do not overlap; > 8 clusters need `RB_AW = 17` |
| Other | `VEC_NUM_BANKS`, `VEC_CMD_QUEUE_DEPTH`, `VEC_CPL_QUEUE_DEPTH`, `VEC_DMA_BUFFER_DEPTH`, `VEC_PERF`, `VEC_SPM_BACKEND`, `TSU_TILE_K`, `TSU_NUM_MEMORY_BANKS`, `TSU_QUANT`, `TSU_DBUF`, `TSU_CMD_QUEUE_DEPTH`, `TSU_MAX_OUT`, `TSU_PERF`, `SHELL_PERF`, `ENABLE_CLK_REQ`, `RST_HOLD` | see RTL | unit rules apply unchanged |

## 2. Compatibility with the minimum chip configuration

With every default, the shell holds one HPC M08 tile and one TC08 tensor unit, with exactly their own default
parameters, on one DataFabric crossbar with the host, a shared memory and the tile's scratchpad window. That is the
TENSORCORE 08 coexistence system (`sfx_hpc_tensor_system`). With `CMD_IF = 0` the register pages are the same
(tile page 8, tensor page 9, page 7 now holds the shell's registers instead of being unmapped), and the existing
drivers' programming model applies unchanged. Simulated: `s2_legacy_basic`, `s2_legacy_mixed`. With `CMD_IF = 1`
(default) the same engines are driven by the command / completion streams. The host may still use every control
register; only the staging window, DOORBELL and CPL_POP belong to the stream path.

## 3. Named configurations (`configs/*.json`)

Each file lists the overrides, the fully resolved parameter set and the generated address map: cluster IDs,
instance names, register pages, scratchpad windows, crossbar master / slave indices.

| File | Shape | Used by |
|---|---|---|
| `min.json` | 1 + 1, defaults | stage 2 regression, `compute_min` synthesis |
| `hpc.json` | 4 + 2 (`u_vector_0..3`, `u_tensor_0..1`), full engines | stage 3 regression, `compute_hpc` synthesis |
| `hpc_piped.json` | 4 + 2, every NoC-facing slice | `compute_hpc_piped` synthesis |
| `wide128.json` | 2 + 2, 128-bit, 8 lanes, 16 KiB, 8×8 quant + double buffering, no local-memory port | stage 3 (`p128`) |
| `max_slots.json` | 8 + 4 (every slot), reduced engines, `RB_AW = 17` | stage 3 (`max`) |
| `phys_hpc.json` | 4 + 2 reduced (1 lane, 1 KiB, 2×2, depth-2 queues, counters off, all slices) | OpenROAD experiment + stage 3 (`phys`) |
| `phys_hpc_noslice.json` | same, without the NoC-facing slices | OpenROAD timing comparison (docs/07 §5) |
