# 05 — Verification

RTL simulation (Verilator 5.020) of `tb/tb_compute_cluster.sv` on `silicaflux_compute_cluster`, programs and
expectations from `model/cc_prog.py`, checks by `model/cc_check.py`. Results: `reports/regression.md`.

## 1. Method

* **Independent references, never the RTL.** GEMM: TENSORCORE 08's `tsu_ref.py` (exact INT32 with Python integers,
  INT8 through TENSORCORE 05's `tq_ref`, validation rules written from the ABI document). FP32 FADD / FMUL: binary64
  arithmetic rounded once to binary32 (exact for + and ×, the TC08 method). DMA: byte copies.
* **What is checked in every run:**
  1. every completion record: source ID (`cpl_src`), `cpl_err`, and every field the reference predicts — vector
     TAG / STATUS / TYPE / STEP / COUNT / SEQ; tensor TID / OPCODE / ERR_CODE / STATUS / COUNT / TILES / SAT / SEQ —
     in each cluster's command order (completion routing);
  2. the **whole** 1 MiB shared-memory image: initial image + the bytes of every command that completed OK. Only
     footprints of destroyed or execution-failed commands, and the host-traffic window, are excluded;
  3. SFB2 protocol checkers (DataFabric `sfb_protocol_checker`) on every crossbar master and slave port and on the
     shared-memory port: no withdrawal (R2), stable payloads, exactly one in-order response (R5), outstanding limits;
  4. shadow-checked background host traffic on the host data port (contention with the clusters' DMA);
  5. register reads with expected values (ERR_STATUS, BAD_DEST, INFLIGHT = 0 at the end, BUSY = 0, unit STATUS);
  6. LOST after every cluster reset = the number of that epoch's commands that produced no record;
  7. named coverage items a scenario must hit (cluster-reset isolation paths);
  8. embedded assertions (`SFX_ASSERT`, the reused units' `*_ASSERT` checkers) and the testbench watchdog.
* **Run modes:** `fast` (1-cycle memory, no back-pressure); `bp` (memory latency 1–8 cycles, 30 % request refusal,
  completion ready 40 %, command gaps 50 %, host traffic 30 %); `slow` (latency 4–12, 50 % refusal, completion ready
  15 %).

## 2. Brief → tests

| Brief item | Where | Tests |
|---|---|---|
| Single-cluster operation | one vector or one tensor cluster alone in the shell | `s1_vec_*`, `s1_tsu_*` |
| Multiple replicated clusters | 4 + 2, 2 + 1, 2 + 2, 8 + 4, reduced 4 + 2 | `s3_*` |
| Simultaneous vector and tensor commands | interleaved programs; "vector_and_tensor_busy_cycles" and "max_clusters_busy" in stats (6 of 6 in `hpc`, 12 in `max`) | `s2_min_mixed*`, `s3_*_mixed*` |
| SRAM contention | all cluster DMAs + host traffic on the one shared-memory slave; per-master stall / arbitration-loss counts from the crossbar monitor | every `mixed` run (stats) |
| Backpressure | memory request refusal + latency, completion-stream `cpl_ready`, command gaps, unit queues of depth 2 (`phys`), shell `CMD_PIPE` / slices | `bp`, `slow` modes; `s3_phys_*`, `s3_p64_*` |
| Completion routing | per-source ordered matching incl. SEQ and TAG / TID; shell records for absent destinations (ID 15 and an absent slot) | every run; `*_errors` |
| Cluster reset | reset one cluster mid-command while the others run (memory forced to refuse so a request is presented at reset time); local-memory read held across the reset; host read during reset → error response; reset of an idle cluster; LOST checked; the reset cluster works afterwards | `*_reset*` |
| Error propagation | vector BAD_TYPE, ALIGN, DMA_ERR (memory error window); tensor VERSION, RANGE, DMA_READ; bad destination; refused host writes to stream-owned registers; ERR_STATUS / IRQ / W1C; vector HALT_ON_ERROR halt + RESUME; tensor stop-on-error + ERR_CLEAR | `*_errors` |
| Parameter configurations | 32 / 64 / 128-bit, 1 / 4 / 8 lanes, 1 KiB–64 KiB scratchpads, 2×2 / 4×4 / 8×8, quantisation + double buffering, local-memory port off, every slice on, legacy command path, 8 + 4 slots | regression configs + `scripts/run_lint.py` (12 legal + 12 illegal) |

## 3. Coverage of the reset isolation paths

`stats.txt` of every reset run reports `cover iso_req_captured / iso_rsp_captured / iso_error_responses /
iso_responses_sunk`. The checker fails a run whose scenario declares an item it did not hit. The first regression
found a real defect here: the original isolation dropped `req_valid` of a presented-but-unaccepted request (SFB2
R2), and the crossbar-master protocol checker flagged it. The fix keeps the request presented until accepted, and
likewise holds an un-accepted response unchanged (R4).

## 4. Testbench-model assumptions (stated, not hidden)

* Host register-bus rate: at most one access every two cycles per page, the SilicaFlux-V LSU rate (docs/02 §6).
* The shared memory performs writes when it responds (SFB2 R7) and answers errors with no side effect (R8).
* No formal proof of the new RTL and no gate-level simulation in this project.
