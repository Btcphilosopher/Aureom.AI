# 06 — Synthesis: independent build targets

`syn/run_synth.py` (Yosys 0.33). Generated report: `reports/synth.md`. Raw scripts, logs (gzip) and `stat` output:
`reports/synth/<target>/`.

## 1. Targets

| Make target | Yosys target | Top | Parameters |
|---|---|---|---|
| `make synth-vector` | `vector_cluster` | `silicaflux_vector_cluster` | defaults: 4 FP32 lanes, 32-bit, 64 KiB scratchpad, local-memory port |
| `make synth-tensor` | `tensor_cluster` | `silicaflux_tensor_cluster` | defaults: 4×4 INT8, 2 KiB operand buffers, 32-bit |
| `make synth-subsystem` | `compute_min` | `silicaflux_compute_cluster` | defaults: 1 + 1 (minimum configuration) |
| | `compute_hpc` | | 4 + 2 |
| | `compute_hpc_piped` | | 4 + 2 with MEM_PIPE, LM_PIPE, EXT_PIPE, CMD_PIPE |

## 2. Flow

```
read_verilog -defer -sv (rtl/files.f)   hierarchy -check -top T [-chparam ...]   proc   check -assert
synth -run begin:fine        # coarse: FSM, wreduce, alumacc, share, memory inference (memory -nomap)
opt -fast -full; techmap; opt -fast; abc -fast; opt -fast      # = synth's "fine" step WITHOUT memory_map
no-latch assertion; check -assert; stat -top T; write_json / write_verilog (hierarchy NOT flattened)
```

* **Hierarchy is kept.** The netlist contains `u_vector_k`, `u_tensor_j`, `u_noc`, `u_cmd_route`, `u_cpl_arb`,
  `u_regs`, `u_ext_slice`, and inside each cluster `g_cl.u_tile` / `g_cl.u_tsu`, `g_cl.u_ctrl`, `g_cl.u_rst`, …. The
  script checks the expected names for every target ("missing instances: []" for all five).
* **Memories are inferred, not mapped.** Every `$mem_v2` is listed with its instance path, width, depth and ports.
  Arrays ≥ 4 Kbit and ≥ 64 deep are classed "SRAM-macro candidate", the rest "register file / flip-flops". Mapping
  the 64 KiB scratchpads to flip-flops would add 524 288 flip-flops per vector cluster, and the logic count would
  mean nothing for an ASIC that uses SRAM macros. M08 also reported that abc on the flattened tile ran over 10 min
  per configuration.
* **Per-region totals** are computed from the hierarchical JSON netlist (`analyse()` in `syn/run_synth.py`): cells,
  flip-flops and memory bits of every top-level instance, plus the top-level glue.
* **Fanout analysis**: for every net of the top module, the number of leaf cell input pins it reaches through the
  hierarchy. Memories are excluded as leaves; a net's sinks inside a `$mem_v2` count once per memory port bit.

## 3. Results (from `reports/synth/*.json`)

| Target | Generic cells | Flip-flops | Inferred memory bits | Yosys time |
|---|---|---|---|---|
| one vector cluster | 156 963 | 11 393 | 530 484 | 58 s |
| one tensor cluster | 116 013 | 12 373 | 27 592 | 92 s |
| subsystem 1 + 1 | 284 706 | 25 193 | 558 076 | 183 s |
| subsystem 4 + 2 | 885 953 | 72 842 | 2 177 120 | 294 s |
| subsystem 4 + 2, all slices | 890 773 | 75 908 | 2 177 120 | 293 s |

Per region, 4 + 2: each `u_vector_k` ≈ 157 000 cells / 11 393 FF / 530 484 memory bits; each `u_tensor_j` 115 813
cells / 12 373 FF / 27 592 bits; `u_noc` 8 059 cells; `u_regs` 14 316 cells (1 986 FF, mostly the 48 event
counters); `u_cpl_arb` 3 423 cells; `u_cmd_route` 89 cells; unpopulated slots 0 cells. The four vector clusters
differ by a few dozen cells because their `SPM_BASE` differs: each slot is a separately specialised module.

Cost of the local control (vector cluster): `u_ctrl` 2 188 cells / 461 FF (one 256-bit hold register + one 192-bit
record register), `u_rst` 398 cells / 124 FF. Together ≈ 1.6 % of the cluster's cells. The slices cost 3 066 FF in
the 4 + 2 shape (`compute_hpc_piped` − `compute_hpc`).

## 4. What these numbers are not

Generic Yosys cells are not standard cells and do not give silicon area. For a technology-mapped view see docs/07:
reduced configuration, sky130hd, memories as flip-flops. Earlier SilicaFlux mappings: M08 Xilinx-7 baseline
29 091 LUT; TC08 SKY130 smoke test 154 882 cells for the tensor unit alone with buffers as flip-flops.
