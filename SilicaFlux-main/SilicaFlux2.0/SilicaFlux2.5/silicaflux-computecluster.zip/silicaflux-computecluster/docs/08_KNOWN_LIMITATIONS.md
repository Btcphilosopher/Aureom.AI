# 08 — Known limitations and what is not claimed

## Not claimed

* **No silicon area, power or timing closure.** Generic Yosys cell counts are not area. The sky130hd numbers of
  docs/07 belong to a reduced configuration with memories as flip-flops, placed pre-CTS with no routing. Neither is
  a floorplan or an area result for the HPC configuration.
* **No placed layout of the full design.** The region map is a proposal generated from measured cell area. The
  OpenROAD run checks whether the tool honours the regions on a real, reduced netlist; it does not validate the
  proposal for the full design.
* **No FPGA or silicon run, no formal proof of the new RTL, no gate-level simulation.**
* **No performance beyond the engines'.** Throughput figures of the SilicaFlux illustrations are not used anywhere.

## Limitations of the design

1. **Register-bus sharing.** The host has priority on each unit's register page. The command stream advances only
   in cycles without a host access to that page. A bus master that strobes one cluster page on every cycle starves
   that cluster's stream path. The SilicaFlux-V CPU cannot do this (one access, then wait for `rvalid`). A DMA
   engine mapped onto the register bus could.
2. **Command issue cost.** Each command costs 10 (vector) / 14 (tensor) register-bus cycles to stage, and each
   completion 8. That suits coarse-grained commands (KERNEL, GEMM). A NOP round trip is 23 cycles
   (`reports/perf.md`). A direct queue-push port would require modifying the verified units.
3. **One command held per cluster.** The hold register is one entry. Deeper buffering is the unit's own command
   queue (vector 8, tensor 4 by default).
4. **Pipeline slices cost throughput.** The DataFabric crossbar keeps one transaction per port (SFB2 R6), and the
   simple DMA engines keep one in flight. Each sliced direction therefore adds about 1 cycle to every DMA round trip:
   about ×1.75 on DMA-bound commands with a 1-cycle memory, about ×1.3 with an 8-cycle memory (measured). Enable the
   slices only where place-and-route timing needs them. Multi-outstanding transactions (DataFabric PROTOCOL.md §8,
   transaction IDs) would recover this; they do not exist in the reused crossbar.
5. **CSR round trip is combinational.** The rb protocol answers in the strobe cycle. The host address therefore
   travels shell decode → cluster → unit register decode → read mux → back, within one cycle. A spread floorplan may
   need a registered register-bus variant at the SoC bridge (`sfv_periph_bridge` already returns `rvalid` one cycle
   later). Not implemented.
6. **Cluster reset destroys queued commands.** LOST counts them; their records are never produced (TC08 convention).
   A write accepted by the fabric before the reset may or may not have been performed (SFB2 R11).
7. **Clock gating is a request only.** No clock gate is instantiated. A power manager must ungate before host
   *writes* to a gated cluster's page (no wait states).
8. **Slots: 8 vector + 4 tensor.** More need an extra macro line per slot and `RB_AW` / ID arithmetic. `SFX_ID_W = 4`
   limits the shell ID space to 16.
9. **Unpopulated slots** remain as empty module instances (0 cells) in the hierarchical generic netlist. A
   liberty-mapping flow must dissolve them before tie-cell / buffer insertion (done in `physical/run_phys.py`),
   or each keeps ~350 tie / buffer cells.
10. **No cluster-to-cluster scratchpad access.** The access matrix limits cluster DMA to the shared memory. A
    producer / consumer pipeline between clusters goes through the shared memory.
11. **Memories.** The 64 KiB scratchpads (524 288 bits per vector cluster) need SRAM macros. The SRAM Wrapper
    Library's ASIC backend exists, but no macro for these shapes is wired here (`VEC_SPM_BACKEND` parameter is
    passed through).
