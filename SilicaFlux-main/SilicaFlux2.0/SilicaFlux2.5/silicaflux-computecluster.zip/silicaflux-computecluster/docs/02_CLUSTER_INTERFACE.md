# 02 — Cluster interface

Both cluster wrappers (`silicaflux_vector_cluster`, `silicaflux_tensor_cluster`) expose the same port groups, so the
shell, a NoC or a different integration treats every compute region the same way. Single clock domain (`clk`).
The SilicaFlux reset convention applies everywhere: asynchronous assert, synchronous release.

| Group | Ports | Direction (cluster view) | Notes |
|---|---|---|---|
| Clock / reset | `clk`, `rst_n`, `cl_rst_req` | in | `rst_n` = global; `cl_rst_req` = cluster-local reset request (§9) |
| Command request | `cmd_valid`, `cmd_ready`, `cmd_data` | in / out / in | 8 words (vector) or 12 words (tensor), §2 |
| Command completion | `cpl_valid`, `cpl_ready`, `cpl_data[191:0]`, `cpl_err` | out / in / out / out | 6-word record, §3 |
| Memory request / response | `mem_req_*`, `mem_rsp_*` | SFB2 **master** | DMA traffic towards the NoC / shared memory, §4 |
| Local memory (optional) | `lm_req_*`, `lm_rsp_*` | SFB2 **slave** | vector scratchpad window, `LOCAL_MEM_PORT = 1`, §5 |
| Host CSR page | `csr_sel`, `csr_we`, `csr_addr[11:0]`, `csr_wdata`, `csr_rdata`, `csr_err` | SilicaFlux-V rb slave | the unit's own 4 KiB register page, §6 |
| Interrupt / error / status | `irq`, `busy`, `halted`, `in_reset`, `err_ev` | out, **registered** | §7 |
| Clock-enable request | `clk_req` | out, registered | §8 |
| Performance events | `perf_ev[7:0]` | out, registered pulses | §8 |

SFB2 is the DataFabric bus protocol: `req_valid/ready`, `req_write`, `req_addr`, `req_wdata`, `req_wstrb`,
`rsp_valid/ready`, `rsp_rdata`, `rsp_error`. The rules R1–R12 are in
`third_party/silicaflux-datafabric/docs/datafabric/PROTOCOL.md`. Data width = `DATA_WIDTH` (the shell's
`TRANSACTION_WIDTH`: 32, 64 or 128).

## 1. Hierarchy inside a cluster (stable names)

| Instance | Module | Reset | Role |
|---|---|---|---|
| `g_cl.u_tile` / `g_cl.u_tsu` | `silicaflux_hpc_tile` (HPC M08) / `silicaflux_tensor_unit` (TC08), **unmodified** | local | the compute engine |
| `g_cl.u_ctrl` | `sfx_cluster_ctrl` | local | command / completion streams ⇄ unit register page |
| `g_cl.u_rst` | `sfx_cluster_rst_iso` | global | cluster reset sequencing, port isolation |
| `g_cl.u_mem_slice` | DataFabric `sfb_reg_slice` | global | optional pipeline boundary on `mem_*` (`MEM_PIPE`) |
| `g_cl.g_lm.u_lm_slice` (vector) | DataFabric `sfb_reg_slice` | global | optional pipeline boundary on `lm_*` (`LM_PIPE`) |
| `g_cl.u_upsize` (tensor) | `sfx_sfb_upsizer` | global | 32-bit unit port → `TRANSACTION_WIDTH` |

`g_cl` is the generate block of a populated slot. An unpopulated slot (`PRESENT = 0`) elaborates `g_empty`. It has
no cells and drives constant outputs (`cmd_ready = 0`, `cpl_valid = 0`, `mem_req_valid = 0`, `mem_rsp_ready = 1`,
`csr_err = csr_sel`).

## 2. Command request (valid / ready)

* A transfer happens when `cmd_valid && cmd_ready`. `cmd_data` holds the unit's own descriptor, word 0 in bits
  [31:0]:
  * vector cluster: the 8-word HPC Module 08 descriptor (`hpc_tile_defs.svh`: TYPE, VOP, RM, BCAST, RED, TAG, FENCE / VL
    / SCALAR / A / B / C / D / STAGE);
  * tensor cluster: the 12-word TENSORCORE 08 GEMM descriptor (`tsu_defs.svh`, ABI version 2).
* **Acceptance** means the command sits in the cluster's one-entry hold register (`u_ctrl`). The adapter then stages
  it in the unit's register page and rings DOORBELL, but only when STATUS shows the unit can take it (vector:
  CMDQ_FULL and SOFT_RESET clear; tensor: Q_FULL clear). A refused DOORBELL keeps the descriptor and retries it, so a
  command is never lost. `cmd_ready = !held && !in_reset`, driven from a register. The command is
  validated by the unit itself; an invalid command completes with an error record, in order.
* **Back-pressure:** while the hold register is occupied, `cmd_ready = 0`. Since the unit's command queue drains
  in order, a full queue propagates back to the sender without loss.
* **Issue cost** (measured, `reports/perf.md`): 1 STATUS poll + N descriptor writes + DOORBELL = 10 cycles (vector)
  / 14 cycles (tensor) of register-bus time per command, overlapping execution of earlier commands.
* `CMD_IF = 0` (legacy): the stream is tied off (`cmd_ready = 0`). The host programs the register page exactly as the
  TENSORCORE 08 / HPC Module 08 drivers do. The minimum configuration in this mode is page-compatible with the
  TENSORCORE 08 coexistence system (tile page 8, tensor page 9).

## 3. Command completion (valid / ready)

* `cpl_data` = the unit's completion record **verbatim** (6 words, word 0 in [31:0]):
  * vector: CPL_INFO {VALID[31], STEP[27:25], FFLAGS[24:20], DETAIL[19:16], TYPE[15:12], STATUS[11:8], TAG[7:0]}, SEQ,
    COUNT, RESULT, ERR_ADDR, CYCLES;
  * tensor: {DETAIL, SAT, IRQ, STATUS[25:24], ERR_CODE, OPCODE, TID}, COUNT, ERR_ADDR, SEQ, CYCLES, TILES.
* `cpl_err = 1` when the record's status field is non-zero (vector STATUS ≠ OK; tensor STATUS = ERROR or SKIPPED).
* Order: records leave in the unit's completion order. That is command order for both units: the tensor unit runs
  one command at a time, and the tile retires in order through its reorder buffer.
* Completion cost: 1 poll + 6 record reads + 1 CPL_POP = 8 register-bus cycles. A pop is only performed after an
  uninterrupted read of the whole record. If a host write reaches the unit in between (it could be a FLUSH or soft
  reset), the sequence restarts.
* `cpl_valid` is held with stable data until `cpl_ready`. The one exception: a cluster reset (§9) withdraws it. The
  shell's arbiter is built for that (`sfx_cpl_arbiter`: lock released on withdrawal; captures only on handshake).

## 4. Memory port (SFB2 master)

* Carries all DMA traffic of the engine: tile DMA (simple engine: one transaction in flight; buffered engine:
  `MAX_OUT`), tensor DMA (≤ `MAX_OUT` in flight, own outstanding FIFO). Both masters track their own outstanding
  count, which PROTOCOL.md §7 requires before a register slice may sit between a master and a crossbar master port.
* Tensor: the unit's 32-bit port goes through `sfx_sfb_upsizer` (one wide transaction per narrow one; lane FIFO of
  `MAX_OUT + 2` entries; misaligned narrow addresses still reach the crossbar's alignment check).
* `MEM_PIPE = 1`: `sfb_reg_slice` adds one cycle per direction (§ docs/04).

## 5. Local-memory port (SFB2 slave, vector, `LOCAL_MEM_PORT = 1`)

* The tile's host scratchpad window (`hs_*`), addresses `SPM_BASE .. SPM_BASE + SCRATCHPAD_BYTES - 1`, reached by
  the host through the shell crossbar. Other clusters cannot reach it (shell access matrix: ownership rule of
  TENSORCORE 08 docs/06).
* `LM_PIPE = 1`: `sfb_reg_slice` on the port. During a cluster reset the port answers `rsp_error = 1` (§9).

## 6. Host CSR page (SilicaFlux-V rb protocol)

* One 4 KiB page per cluster: **the unit's own register page** (HPC M08 `docs/03_register_map.md`, TC08
  `tsu_defs.svh`). Access semantics: `csr_sel` is a one-cycle strobe; `csr_rdata` / `csr_err` are combinational in
  the strobe cycle; side effects occur at the clock edge.
* **Ownership (`CMD_IF = 1`):** the host may read everything and write everything except the descriptor staging
  window, DOORBELL and CPL_POP, which belong to `u_ctrl`. Those writes answer `csr_err = 1` and have no effect, so a
  host can never corrupt a descriptor being staged or steal a record. The vector refused range is 0x080–0x09C,
  0x0A0, 0x058; the tensor range is 0x040–0x06C, 0x070, 0x098. Control writes such as CTRL (RESUME / FLUSH /
  ERR_CLEAR / ABORT / soft reset), CFG, IRQ_EN and ERR_CONT pass through.
* **Arbitration:** the host has priority on the unit's register bus, so register semantics are unchanged. `u_ctrl`
  uses every cycle in which the host does not access that page. Progress guarantee: the stream path advances
  whenever the host leaves at least one idle cycle on that page. The SilicaFlux-V CPU always does: its LSU holds
  `d_req` low while it waits for `rvalid` (`sfv_cpu.sv` `lsu_wait_q`). A master that strobes one page on every
  single cycle would starve the stream; see docs/08.
* While the cluster is held in reset, the page answers `csr_err = 1`.

## 7. Interrupt / error / status (registered at the boundary, 1 cycle)

| Output | Meaning |
|---|---|
| `irq` | the unit's interrupt line (its IRQ_EN / IRQ_STATUS registers, unchanged) |
| `busy` | the unit has queued or executing work, or `u_ctrl` holds a command / record or has seen a waiting record |
| `halted` | vector: the scheduler is HALTED (HALT_ON_ERROR); tensor: the scheduler is in its HALT state |
| `in_reset` | the cluster is held in its local reset / isolated |
| `err_ev` | one-cycle pulse: an error completion was delivered on `cpl_*`, or the unit entered HALTED |

The shell turns `err_ev` into a sticky per-cluster bit (ERR_STATUS, W1C) and an optional interrupt.

## 8. Clock-enable request and performance events

* `clk_req` (registered) = unit busy ∨ `u_ctrl` not idle ∨ reset / outstanding transaction on a port. **0 means the
  cluster is quiescent**: nothing held, queued, executing, waiting to be delivered, and no transaction open. The
  shell outputs `cl_clk_en_req[id] = clk_req ∨ wake` (registered), where wake = a command waiting for this cluster, a
  host access to its page, or a request presented on its local-memory port. A power manager may gate the cluster's
  clock while `cl_clk_en_req = 0`. It must ungate before the host *writes* the cluster's page: the rb protocol has no
  wait state, so a write to a gated cluster would be lost. No clock gate is instantiated here (power management is
  the power-clock project's `sf_clock_gate`).
* `perf_ev[7:0]` (registered one-cycle pulses / levels):

| bit | name | vector | tensor |
|---|---|---|---|
| 0 | CMD_ACCEPT | command accepted | same |
| 1 | CPL | completion delivered | same |
| 2 | CPL_ERR | … with error status | same |
| 3 | BUSY | tile busy | tensor unit busy |
| 4 | MEM_REQ | memory request accepted at the port | same |
| 5 | MEM_STALL | memory request presented, not accepted | same |
| 6 | LOCAL | local-memory request accepted | systolic array computing (TC08 `TSU_PC_COMPUTE_CYC` event) |
| 7 | CMD_STALL | command presented, not accepted | same |

The tensor unit's 640-wire event bus (20 × 32-bit increments) stays inside the cluster. Only these 8 wires cross the
region boundary; the full counters remain readable on the CSR page.

## 9. Cluster reset

`cl_rst_req` (synchronous; the shell sends a one-cycle pulse from CL_RESET) starts this sequence in `u_rst`:

1. **Same edge:** `in_reset` (internal `iso`) rises and the unit and `u_ctrl` are held in reset
   (`local_rst_n = rst_n ∧ ¬iso`).
2. **Master port:** a request the unit was presenting, and the fabric had not yet accepted, is captured and kept
   presented, unchanged, until accepted (SFB2 R2, no withdrawal). No other request is presented. Every response still
   owed to the unit is consumed and dropped.
3. **Local-memory port:** a response the unit was presenting, not yet accepted, is captured and delivered unchanged
   (R4). Every other request still owed, and every new one, is answered with `rsp_error = 1`. Requests are answered
   one at a time, one cycle after acceptance; the port never hangs.
4. **Release:** after at least `RST_HOLD` cycles, with `cl_rst_req` low, nothing captured, and no transaction open on
   either port, the reset releases synchronously. No local-memory request is accepted in the release cycle.

Commands accepted but not completed are destroyed and produce no record (TENSORCORE 08 convention). The shell copies
INFLIGHT[id] into LOST[id] at reset entry, so software knows how many records will never come. All four isolation
paths are covered and enforced by the regression (`reports/regression.md`, coverage lines).

## 10. Shell-level interface (`silicaflux_compute_cluster`)

| Group | Ports |
|---|---|
| Clock / reset | `clk`, `rst_n` |
| Host register bus | `rb_sel`, `rb_we`, `rb_addr[RB_AW-1:0]`, `rb_wdata`, `rb_rdata`, `rb_err` |
| Command request | `cmd_valid`, `cmd_ready`, `cmd_dest[3:0]`, `cmd_data[383:0]` (vector clusters use `[255:0]`) |
| Command completion | `cpl_valid`, `cpl_ready`, `cpl_src[3:0]`, `cpl_err`, `cpl_data[191:0]` |
| Host data port | `h_req_*` / `h_rsp_*` (SFB2 master m0 of the fabric, `TRANSACTION_WIDTH`) |
| Shared-memory port | `mem_req_*` / `mem_rsp_*` (SFB2 master towards memory / NoC) |
| Per-cluster status (bit = cluster ID) | `cl_irq`, `cl_err` (sticky ERR_STATUS), `cl_busy`, `cl_in_reset`, `cl_clk_en_req` [11:0], `cl_perf_ev[95:0]` |
| Aggregate interrupt | `irq` = (IRQ_EN[0] ∧ any `cl_irq`) ∨ (IRQ_EN[1] ∧ any error / BAD_DEST) |
| Fabric monitor | `mon_req_accept`, `mon_req_stall`, `mon_arb_loss` [NM-1:0] per crossbar master |

**Cluster IDs = slots.** Vector slot k → ID k (0–7), instance `u_vector_k`. Tensor slot j → ID 8 + j (8–11), instance
`u_tensor_j`. A command to an absent ID (including 12–15) is accepted and answered by the shell with an error
record: `cpl_src` = that ID, `cpl_err = 1`, word 0 = 0x5345_0001 ("SE", BAD_DEST), word 1 = the command's word 0.

**Register pages** (`rb_addr[RB_AW-1:12]`): shell = page 7. Vector k = page 8 + k. Tensor j = page
8 + NUM_VECTOR_CLUSTERS + j. Any other page is refused (`rb_err`). With 1 + 1 this gives pages 8 / 9, the TENSORCORE
08 map. More than 8 clusters need `RB_AW = 17`.

**Shell register page** (`sfx_cluster_defs.svh`, `SFX_R_*`):

| Offset | Name | Access | Content |
|---|---|---|---|
| 0x000 | ID | RO | 0x5346_4343 "SFCC" |
| 0x004 | VERSION | RO | 0x0001_0000 |
| 0x008 / 0x00C | CONFIG0 / CONFIG1 | RO | counts, width, flags, lanes, scratchpad log2, PE array, TILE_K |
| 0x010 | PRESENT | RO | populated slots |
| 0x014 / 0x018 / 0x01C | BUSY / IN_RESET / CLK_REQ | RO | per cluster |
| 0x020 | CL_RESET | WO | write 1 to bit id: reset that cluster |
| 0x024 | ERR_STATUS | W1C | [11:0] cluster error seen, [16] BAD_DEST |
| 0x028 | IRQ_EN | RW | [0] cluster IRQ lines, [1] errors |
| 0x02C | CL_IRQ | RO | cluster interrupt lines |
| 0x030 | BAD_DEST | RO | commands to absent clusters |
| 0x034 | PERF_CTRL | WO | [0] clear event counters |
| 0x038 / 0x03C | SPM_BASE / MEM_BASE | RO | windows |
| 0x040 + 4·id | INFLIGHT[id] | RO | commands accepted − completions delivered |
| 0x080 + 4·id | LOST[id] | RO | commands destroyed by the last reset of that cluster |
| 0x100 + 0x20·id + 4·e | EVCNT[id][e] | RO | saturating counter of event e (`SHELL_PERF = 1`) |

**Fabric (DataFabric `sfb_crossbar`, `u_noc`, round robin):** masters m0 = host, m1+k = vector k, m1+NV+j = tensor j.
Slaves s0 = shared memory (`mem_*`), s1+k = scratchpad window of vector k. Access matrix: the host reaches every
slave; every cluster DMA reaches the shared memory only. Tensor clusters validate commands against the
shared-memory window (`MEM_LO / MEM_HI`).
