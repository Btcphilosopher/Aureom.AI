#!/usr/bin/env python3
"""SilicaFlux Project 32 lint / elaboration sweep.

  * Verilator 5.020 --lint-only -Wall: warnings in the NEW RTL (rtl/) must be zero, for every legal configuration
    (the reused, unmodified third-party RTL is reported separately, never edited)
  * Icarus Verilog 12: elaboration of every legal configuration (-g2012)
  * Yosys 0.33: read -defer, hierarchy -check -chparam, proc, check -assert (elaboration, no latch inference later)
  * illegal configurations: every tool must refuse to elaborate them (the shell's own $fatal checks)
Writes reports/lint.json and reports/lint.md.
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TOP = "silicaflux_compute_cluster"

LEGAL = {
    "min": {},
    "v1_only": dict(NUM_VECTOR_CLUSTERS=1, NUM_TENSOR_CLUSTERS=0),
    "t1_only": dict(NUM_VECTOR_CLUSTERS=0, NUM_TENSOR_CLUSTERS=1),
    "hpc": dict(NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2),
    "hpc_piped": dict(NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2, MEM_PIPE=1, LM_PIPE=1, EXT_PIPE=1, CMD_PIPE=1),
    "w64": dict(NUM_VECTOR_CLUSTERS=2, NUM_TENSOR_CLUSTERS=1, TRANSACTION_WIDTH=64),
    "w128_nolm": dict(NUM_VECTOR_CLUSTERS=2, NUM_TENSOR_CLUSTERS=2, TRANSACTION_WIDTH=128, LOCAL_MEM_PORT=0,
                      VEC_NUM_LANES=8, VEC_SCRATCHPAD_BYTES=16384, TSU_ARRAY_ROWS=8, TSU_ARRAY_COLS=8,
                      TSU_NUM_MEMORY_BANKS=8, TSU_OPERAND_BUFFER_BYTES=4096, TSU_QUANT=1, TSU_DBUF=1),
    "legacy": dict(CMD_IF=0),
    "lanes16": dict(NUM_VECTOR_CLUSTERS=1, NUM_TENSOR_CLUSTERS=0, VEC_NUM_LANES=16, TRANSACTION_WIDTH=128),
    "max_slots": dict(NUM_VECTOR_CLUSTERS=8, NUM_TENSOR_CLUSTERS=4, RB_AW=17, VEC_NUM_LANES=1,
                      VEC_SCRATCHPAD_BYTES=4096, TSU_ARRAY_ROWS=2, TSU_ARRAY_COLS=2, TSU_NUM_MEMORY_BANKS=2,
                      TSU_OPERAND_BUFFER_BYTES=512),
    "phys_hpc": dict(NUM_VECTOR_CLUSTERS=4, NUM_TENSOR_CLUSTERS=2, VEC_NUM_LANES=1, VEC_SCRATCHPAD_BYTES=1024,
                     VEC_NUM_BANKS=2, VEC_CMD_QUEUE_DEPTH=2, VEC_CPL_QUEUE_DEPTH=2, VEC_PERF=0, TSU_ARRAY_ROWS=2,
                     TSU_ARRAY_COLS=2, TSU_OPERAND_BUFFER_BYTES=512, TSU_NUM_MEMORY_BANKS=2, TSU_CMD_QUEUE_DEPTH=2,
                     TSU_PERF=0, SHELL_PERF=0, MEM_PIPE=1, LM_PIPE=1, EXT_PIPE=1, CMD_PIPE=1),
    "noclkreq_noperf": dict(ENABLE_CLK_REQ=0, SHELL_PERF=0),
}
ILLEGAL = {
    "no_cluster": dict(NUM_VECTOR_CLUSTERS=0, NUM_TENSOR_CLUSTERS=0),
    "too_many_vec": dict(NUM_VECTOR_CLUSTERS=9),
    "too_many_tsu": dict(NUM_TENSOR_CLUSTERS=5),
    "bad_width": dict(TRANSACTION_WIDTH=48),
    "pages_overflow": dict(NUM_VECTOR_CLUSTERS=8, NUM_TENSOR_CLUSTERS=4),          # 20 pages need RB_AW = 17
    "shell_page_overlap": dict(SHELL_PAGE=8),
    "mem_not_pow2": dict(MEM_BYTES=3 << 20),
    "mem_misaligned": dict(MEM_BASE=0x1008_0000),
    "spm_overlaps_mem": dict(VEC_SPM_BASE=0x1000_0000),
    "bad_flag": dict(MEM_PIPE=2),
    "bad_lanes": dict(VEC_NUM_LANES=3),                                            # rejected by the reused tile
    "bad_tsu_shape": dict(TSU_ARRAY_ROWS=3, TSU_ARRAY_COLS=3),                    # rejected by the reused unit
}


def fl():
    f = (ROOT / "rtl" / "files.f").read_text().split()
    return [x[len("+incdir+"):] for x in f if x.startswith("+incdir+")], [x for x in f if not x.startswith("+")]


def run(cmd, timeout=900):
    try:
        p = subprocess.run(cmd, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
        return p.returncode, p.stdout
    except subprocess.TimeoutExpired:
        return -1, "TIMEOUT"


def verilator(prm, legal=True):
    # legal: -Wall, warnings reported (never fatal); illegal: default severity, only a USERFATAL ($fatal of an
    # elaboration check) counts as the intended refusal (method of TENSORCORE 08 scripts/run_lint.py)
    flags = ["-Wall", "-Wno-fatal"] if legal else []
    rc, out = run(["verilator", "--lint-only", *flags, "--top-module", TOP,
                   *[f"-G{k}={v}" for k, v in prm.items()], "-f", "rtl/files.f"])
    new = [l for l in out.splitlines() if l.startswith("%Warning") and " rtl/" in l and "third_party" not in l]
    err = [l for l in out.splitlines() if l.startswith("%Error")]
    tp = [l for l in out.splitlines() if l.startswith("%Warning") and "third_party" in l]
    fatal = [l for l in out.splitlines() if "USERFATAL" in l]
    return dict(ok=rc == 0 and not err, rc=rc, new_rtl_warnings=new if legal else [], errors=err[:5],
                third_party_warnings=len(tp), own_fatal=fatal[:3])


def icarus(prm):
    inc, src = fl()
    with tempfile.TemporaryDirectory() as t:
        rc, out = run(["iverilog", "-g2012", "-o", f"{t}/a.out", "-s", TOP, *[f"-I{i}" for i in inc],
                       *[f"-P{TOP}.{k}={v}" for k, v in prm.items()], *src])
        if rc == 0:                     # Icarus 12 reports SRAM_CFG_FATAL-style errors at time 0 (initial $fatal)
            rc2, out2 = run(["vvp", "-n", f"{t}/a.out"], timeout=300)
            fatal = "FATAL" in out2 or "$fatal" in out2.lower() or rc2 != 0
            return dict(ok=not fatal, rc=rc2, msg=(out + out2)[-600:])
    return dict(ok=False, rc=rc, msg=out[-600:])


def yosys(prm):
    inc, src = fl()
    ch = " ".join(f"-chparam {k} {v}" for k, v in prm.items())
    ys = (f"read_verilog -defer -sv -DSYNTHESIS {' '.join('-I' + i for i in inc)} {' '.join(src)}; "
          f"hierarchy -check -top {TOP} {ch}; proc; check -assert")
    rc, out = run(["yosys", "-q", "-p", ys], timeout=1200)
    return dict(ok=rc == 0, rc=rc, msg=out[-400:])


def job(kind, name, prm):
    r = dict(kind=kind, name=name, params=prm)
    r["verilator"] = verilator(prm, legal=kind == "legal")
    r["icarus"] = icarus(prm)
    r["yosys"] = yosys(prm)
    if kind == "legal":
        r["pass"] = all(r[t]["ok"] for t in ("verilator", "icarus", "yosys")) and not r["verilator"]["new_rtl_warnings"]
    else:
        r["pass"] = not any(r[t]["ok"] for t in ("verilator", "icarus", "yosys")) and bool(r["verilator"]["own_fatal"])
    return r


def main():
    jobs = [("legal", k, v) for k, v in LEGAL.items()] + [("illegal", k, v) for k, v in ILLEGAL.items()]
    with ThreadPoolExecutor(4) as ex:
        res = list(ex.map(lambda j: job(*j), jobs))
    for r in res:
        print(f"{r['kind']:7s} {r['name']:20s} verilator={r['verilator']['ok']} (new-RTL warnings "
              f"{len(r['verilator']['new_rtl_warnings'])}) icarus={r['icarus']['ok']} yosys={r['yosys']['ok']} "
              f"-> {'PASS' if r['pass'] else 'FAIL'}")
    n = sum(r["pass"] for r in res)
    print(f"lint: {n}/{len(res)} pass")
    (ROOT / "reports").mkdir(exist_ok=True)
    (ROOT / "reports" / "lint.json").write_text(json.dumps(dict(passed=n, total=len(res), results=res), indent=1))
    sys.exit(0 if n == len(res) else 1)


if __name__ == "__main__":
    main()
