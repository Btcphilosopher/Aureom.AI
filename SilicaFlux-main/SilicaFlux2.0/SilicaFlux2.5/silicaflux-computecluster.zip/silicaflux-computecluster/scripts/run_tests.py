#!/usr/bin/env python3
"""SilicaFlux Project 32 regression: tb/tb_compute_cluster.sv on silicaflux_compute_cluster.

Staged as the brief asks — one vector cluster and one tensor cluster first, then replicated instances:
  stage 1  single clusters        (1 vector / 0 tensor, 0 vector / 1 tensor)
  stage 2  minimum configuration  (1 vector + 1 tensor: the TENSORCORE 08 coexistence shape), incl. legacy CMD_IF = 0
  stage 3  multiple instances     (4 + 2 HPC shape, 2 + 1 at 64-bit with every pipeline boundary, 2 + 2 at 128-bit
                                   with 8-lane / 8x8 engines, 8 + 4 = every slot populated)
Usage: run_tests.py [--stages 1,2,3] [--only NAME[,NAME]] [--jobs N] [--out regression]
Writes reports/<out>.json and reports/<out>.md.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "model"))
import cc_check  # noqa: E402
import cc_prog as M  # noqa: E402
from cc_prog import CCProg, Cfg  # noqa: E402

BUILD = ROOT / "build"
REPORTS = ROOT / "reports"
DEFS = ["+define+SFX_ASSERT", "+define+HPC_TILE_ASSERT", "+define+HPC_DMA_ASSERT", "+define+HPC_SPM_ASSERT",
        "+define+SRAMLIB_ASSERT", "+define+TOB_ASSERT"]

CONFIGS = {
    "v1": Cfg(nv=1, nt=0, rst_hold=64),
    "t1": Cfg(nv=0, nt=1, rst_hold=64),
    "min": Cfg(nv=1, nt=1),                                      # every default: the minimum configuration
    "min_hold": Cfg(nv=1, nt=1, rst_hold=64),
    "min_legacy": Cfg(nv=1, nt=1, cmd_if=0),
    "hpc": Cfg(nv=4, nt=2, rst_hold=64),
    "p64": Cfg(nv=2, nt=1, w=64, mem_pipe=1, lm_pipe=1, ext_pipe=1, cmd_pipe=1, rst_hold=64),
    "p128": Cfg(nv=2, nt=2, w=128, local_mem=0, vec_lanes=8, vec_spm=16384, tsu_rows=8, tsu_cols=8, tsu_banks=8,
                tsu_opbuf=4096, tsu_quant=1, tsu_dbuf=1, rst_hold=64),
    "phys": Cfg(nv=4, nt=2, vec_lanes=1, vec_spm=1024, vec_banks=2, vec_cmdq=2, vec_perf=0, tsu_rows=2, tsu_cols=2,
                tsu_opbuf=512, tsu_banks=2, tsu_cmdq=2, tsu_perf=0, shell_perf=0, mem_pipe=1, lm_pipe=1, ext_pipe=1,
                cmd_pipe=1, rst_hold=64),                        # = configs/phys_hpc.json (placement experiment)
    "max": Cfg(nv=8, nt=4, rb_aw=17, vec_lanes=1, vec_spm=4096, tsu_rows=2, tsu_cols=2, tsu_banks=2, tsu_opbuf=512,
               rst_hold=64),
}

RUNMODES = {
    "fast": dict(lat_min=1, lat_max=1, mem_stall=0, cpl_rate=100, cmd_gap=0, cpu_rate=0),
    "bp": dict(lat_min=1, lat_max=8, mem_stall=30, cpl_rate=40, cmd_gap=50, cpu_rate=30),
    "slow": dict(lat_min=4, lat_max=12, mem_stall=50, cpl_rate=15, cmd_gap=20, cpu_rate=40),
}


# ============================================================================ scenarios
def kvl(p: CCProg, hi: int = 600) -> int:
    return p.rng.randrange(16, max(17, min(hi, p.cfg.vec_spm // 32)))


def gemm_shapes(p: CCProg):
    r, c, tk = p.cfg.tsu_rows, p.cfg.tsu_cols, p.cfg.tsu_tile_k
    return [(r, c, 4), (17, 13, 29), (2 * r + 1, 3 * c - 1, 2 * tk + 5), (8, 12, 40)]


def background(p: CCProg):
    lo = p.alloc(1024, 4096)
    p.dontcare.append([lo, lo + 1024])
    p.plus["cpu_lo"] = f"{lo:x}"


def finish(p: CCProg):
    p.op("Q")
    if p.cfg.cmd_if:
        for cid in p.cfg.vec_ids() + p.cfg.tsu_ids():
            p.op(f"RD {M.SHELL + 0x040 + 4 * cid:x} 0 ffff")          # INFLIGHT back to 0
    p.op(f"RD {M.SHELL + 0x014:x} 0 fff")                             # nobody busy


def sc_basic(p: CCProg):
    background(p)
    for cid in p.cfg.vec_ids():
        for _ in range(3):
            p.vec_kernel(cid, kvl(p))
        p.vec_nop(cid)
        dst, data = p.vec_dma_in(cid, 64 * (p.cfg.w // 8), p.cfg.vec_spm // 2)
        p.vec_dma_out(cid, dst, data)
        p.op("Q")
        if p.cfg.local_mem:                                          # local-memory window read back by the host
            for k in range(0, len(data), max(4, len(data) // 8)):
                p.op(f"HR {dst + k:x} {int.from_bytes(data[k:k + 4], 'little'):08x}")
            hw = dst + len(data)                                     # host write, then read back
            p.op(f"HW {hw:x} cafef00d")
            p.op(f"HR {hw:x} cafef00d")
    for cid in p.cfg.tsu_ids():
        for (m, n, k) in gemm_shapes(p):
            p.gemm(cid, m, n, k)
        p.gemm(cid, 9, 11, 33, flags=1 << M.A.FL_NMAJOR)
        if p.cfg.tsu_quant:
            p.gemm(cid, 7, 9, 21, ofmt=M.A.OFMT_INT8, rm=1, qmult=1 << 29, qshift=34, qzp=3, relu=1)
    finish(p)


def sc_mixed(p: CCProg, rounds: int = 5):
    background(p)
    for _ in range(rounds):
        for cid in p.cfg.vec_ids():
            p.vec_kernel(cid, kvl(p, 400))
        for cid in p.cfg.tsu_ids():
            m, n, k = p.rng.choice(gemm_shapes(p))
            p.gemm(cid, m, n, k, flags=(1 << M.A.FL_PREFETCH) if p.cfg.tsu_dbuf and p.rng.random() < 0.5 else 0)
        for cid in p.cfg.vec_ids():
            if p.rng.random() < 0.5:
                dst, data = p.vec_dma_in(cid, 16 * p.rng.randrange(1, 9) * (p.cfg.w // 8) // 4, p.cfg.vec_spm // 2)
                p.vec_dma_out(cid, dst, data)
            else:
                p.vec_kernel(cid, kvl(p, 200))
    finish(p)


def sc_errors(p: CCProg):
    pg, cfg = p.cfg.page, p.cfg
    for cid in cfg.vec_ids():
        p.op(f"WR {pg(cid) + 0x024:x} 0")                             # HALT_ON_ERROR = 0
    for cid in cfg.tsu_ids():
        p.op(f"WR {pg(cid) + 0x018:x} 1")                             # ERR_CONT = 1
    p.op(f"WR {M.SHELL + 0x028:x} 2")                                 # shell IRQ on ERR_STATUS
    p.op("I 0")
    if cfg.cmd_if:                                                    # the stream owns staging / doorbell / pop
        for cid in cfg.vec_ids()[:1]:
            p.op(f"WE {pg(cid) + 0x080:x} 0"); p.op(f"WE {pg(cid) + 0x0A0:x} 1"); p.op(f"WE {pg(cid) + 0x058:x} 1")
            p.op(f"RD {pg(cid) + 0x000:x} 53464854 ffffffff")
        for cid in cfg.tsu_ids()[:1]:
            p.op(f"WE {pg(cid) + 0x040:x} 0"); p.op(f"WE {pg(cid) + 0x070:x} 1"); p.op(f"WE {pg(cid) + 0x098:x} 1")
    for cid in cfg.vec_ids():
        p.vec_bad_type(cid)
        p.vec_kernel(cid, 32, misalign=True)
        p.vec_kernel(cid, 48, a_err=True)
        p.vec_kernel(cid, kvl(p, 100))
    for cid in cfg.tsu_ids():
        p.gemm(cid, 4, 4, 4, version=1)                               # VERSION
        p.gemm(cid, 4, 4, 4, raw={3: 0x0000_1000})                    # C outside the memory window: RANGE
        p.gemm(cid, 5, 6, 7, b_err=True)                              # DMA read error (execution error)
        p.gemm(cid, *gemm_shapes(p)[1])
    absent = [i for i in range(8) if i >= cfg.nv] + [8 + j for j in range(4) if j >= cfg.nt]
    p.bad_dest(15)
    if absent:
        p.bad_dest(absent[0])
    p.op("Q")
    mask = sum(1 << c for c in cfg.vec_ids() + cfg.tsu_ids())
    if cfg.cmd_if:
        p.op(f"RD {M.SHELL + 0x024:x} {mask | (1 << 16):x} 1ffff")
        p.op("I 1")
        p.op(f"RD {M.SHELL + 0x030:x} {1 + (1 if absent else 0):x} ffffffff")
    p.op(f"WR {M.SHELL + 0x024:x} 1ffff")                             # W1C
    p.op(f"RD {M.SHELL + 0x024:x} 0 1ffff")
    p.op("I 0")
    # vector halt / resume (HALT_ON_ERROR = 1): the good command after the bad one waits for RESUME
    for cid in cfg.vec_ids()[:1]:
        p.op(f"WR {pg(cid) + 0x024:x} 1")
        p.vec_bad_type(cid)
        p.vec_kernel(cid, kvl(p, 100))
        p.op(f"PW {pg(cid) + 0x028:x} 2 2")                           # STATUS.HALTED
        p.op("D 200")
        p.op(f"RD {pg(cid) + 0x028:x} 2 2")                           # still halted: nothing ran
        p.op(f"WR {pg(cid) + 0x020:x} 2")                             # CTRL.RESUME
    # tensor stop-on-error: ERR_CONT = 0, error, wait for its record, ERR_CLEAR, then good work
    for cid in cfg.tsu_ids()[:1]:
        p.op(f"WR {pg(cid) + 0x018:x} 2")                             # ERR_CONT = 0 + ERR_CLEAR of earlier errors
        p.gemm(cid, 4, 4, 4, version=3)
        p.op("Q")
        p.op(f"WR {pg(cid) + 0x018:x} 2")                             # ERR_CLEAR
        p.gemm(cid, *gemm_shapes(p)[0])
    finish(p)


def sc_reset(p: CCProg, targets=None):
    background(p)
    p.cover += ["iso_req_captured", "iso_responses_sunk"] + (["iso_error_responses"] if p.cfg.nv and p.cfg.local_mem
                                                             and p.cfg.rst_hold >= 32 else [])
    cfg = p.cfg
    hold = cfg.rst_hold >= 32
    targets = targets or ([cfg.vec_ids()[-1]] if cfg.nv else []) + ([cfg.tsu_ids()[-1]] if cfg.nt else [])
    for t in targets:
        others = [c for c in cfg.vec_ids() + cfg.tsu_ids() if c != t]
        for c in others:                                             # the rest of the subsystem keeps working
            if c < 8:
                p.vec_kernel(c, kvl(p, 300))
            else:
                p.gemm(c, *gemm_shapes(p)[2])
        if t < 8:
            p.vec_kernel(t, max(16, cfg.vec_spm // 32))
            p.vec_kernel(t, kvl(p, 200))
        else:
            p.gemm(t, 4 * cfg.tsu_rows + 3, 4 * cfg.tsu_cols + 1, 3 * cfg.tsu_tile_k)
            p.gemm(t, *gemm_shapes(p)[1])
        p.op(f"WB {t}")
        p.op("D 40")
        directed = t < 8 and cfg.local_mem and not hold
        if directed:
            p.op("CPU 0")                                           # quiet host port (its traffic needs the memory)
            p.op("D 80")
        p.op("MS 100")                                              # memory refuses: requests stay presented
        p.op("D 30")
        after = ["D 4", "MS -1"]                                    # the captured request must then complete
        if directed:
            # hold a local-memory read response across the reset (host not ready): it must arrive unchanged
            a = cfg.spm(t) + cfg.vec_spm // 2 + 64
            p.op(f"HW {a:x} 5eed{t:04x}")
            p.op("HRDY 0")
            p.op(f"HA {a:x} 5eed{t:04x}")
            p.op("D 12")
            after = ["D 4", "HRDY 1", "HJ"] + after + ["CPU -1"]
            p.cover.append("iso_rsp_captured")
        p.reset(t, hold_check=hold, after_x=after)
        for c in others:
            if c < 8:
                p.vec_kernel(c, kvl(p, 200))
            else:
                p.gemm(c, *gemm_shapes(p)[0])
        if t < 8:                                                    # the reset cluster works again
            p.vec_kernel(t, kvl(p, 200))
            if cfg.local_mem:
                dst, data = p.vec_dma_in(t, 16 * (cfg.w // 8), cfg.vec_spm // 2)
                p.op("Q")
                p.op(f"HR {dst:x} {int.from_bytes(data[:4], 'little'):08x}")
        else:
            p.gemm(t, *gemm_shapes(p)[1])
        p.op("Q")
    # reset of an idle cluster: nothing lost
    if targets:
        p.reset(targets[0], hold_check=False)
        if targets[0] < 8:
            p.vec_kernel(targets[0], 32)
        else:
            p.gemm(targets[0], *gemm_shapes(p)[0])
    finish(p)


SCENARIOS = dict(basic=sc_basic, mixed=sc_mixed, errors=sc_errors, reset=sc_reset)

# (name, stage, config, scenario, run mode, seed)
TESTS = [
    ("s1_vec_basic", 1, "v1", "basic", "fast", 1), ("s1_vec_errors", 1, "v1", "errors", "fast", 2),
    ("s1_vec_reset", 1, "v1", "reset", "bp", 3), ("s1_vec_bp", 1, "v1", "mixed", "slow", 4),
    ("s1_tsu_basic", 1, "t1", "basic", "fast", 1), ("s1_tsu_errors", 1, "t1", "errors", "fast", 2),
    ("s1_tsu_reset", 1, "t1", "reset", "bp", 3), ("s1_tsu_bp", 1, "t1", "mixed", "slow", 4),
    ("s2_min_basic", 2, "min", "basic", "fast", 1), ("s2_min_mixed", 2, "min", "mixed", "fast", 2),
    ("s2_min_mixed_bp", 2, "min", "mixed", "bp", 3), ("s2_min_mixed_slow", 2, "min", "mixed", "slow", 4),
    ("s2_min_errors", 2, "min", "errors", "bp", 5), ("s2_min_reset", 2, "min", "reset", "bp", 6),
    ("s2_min_reset_hold", 2, "min_hold", "reset", "fast", 7),
    ("s2_legacy_basic", 2, "min_legacy", "basic", "fast", 8), ("s2_legacy_mixed", 2, "min_legacy", "mixed", "bp", 9),
    ("s3_hpc_mixed", 3, "hpc", "mixed", "fast", 1), ("s3_hpc_mixed_bp", 3, "hpc", "mixed", "bp", 2),
    ("s3_hpc_errors", 3, "hpc", "errors", "bp", 3), ("s3_hpc_reset", 3, "hpc", "reset", "bp", 4),
    ("s3_p64_mixed", 3, "p64", "mixed", "bp", 5), ("s3_p64_reset", 3, "p64", "reset", "slow", 6),
    ("s3_p64_basic", 3, "p64", "basic", "fast", 7),
    ("s3_p128_mixed", 3, "p128", "mixed", "bp", 8), ("s3_p128_errors", 3, "p128", "errors", "fast", 9),
    ("s3_phys_mixed", 3, "phys", "mixed", "bp", 12), ("s3_phys_reset", 3, "phys", "reset", "bp", 13),
    ("s3_max_mixed", 3, "max", "mixed", "bp", 10), ("s3_max_reset", 3, "max", "reset", "fast", 11),
]


# ============================================================================ build / run
def run(cmd, cwd=None, log=None, timeout=None):
    p = subprocess.run(cmd, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    if log:
        Path(log).write_text(p.stdout)
    return p.returncode, p.stdout


def build(name: str) -> Path:
    cfg = CONFIGS[name]
    out = BUILD / "sim" / name
    exe = out / "Vtb_compute_cluster"
    if exe.exists():
        return exe
    out.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "2", "--top-module", "tb_compute_cluster",
           "-Mdir", str(out), "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY",
           "-Wno-MULTIDRIVEN", "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE",
           "-Wno-WIDTH", *DEFS, *cfg.gparams(), "-f", "rtl/files.f",
           "third_party/silicaflux-datafabric/tb/common/sfb_protocol_checker.sv", "tb/tb_compute_cluster.sv"]
    t0 = time.time()
    rc, txt = run(cmd, cwd=ROOT, log=out / "build.log")
    (out / "build_secs.txt").write_text(f"{time.time() - t0:.1f}\n")
    if rc != 0 or not exe.exists():
        raise RuntimeError(f"build {name} failed:\n" + txt[-3000:])
    return exe


def one(test) -> dict:
    name, stage, cname, scen, mode, seed = test
    cfg = CONFIGS[cname]
    d = BUILD / "runs" / name
    if d.exists():
        shutil.rmtree(d)
    p = CCProg(cfg, seed * 1009 + 17)
    SCENARIOS[scen](p)
    p.write(d, meta=dict(test=name, config=cname, scenario=scen, mode=mode, seed=seed))
    plus = [f"+dir={d}", f"+seed={seed}"] + [f"+{k}={v}" for k, v in RUNMODES[mode].items()] + \
           [f"+{k}={v}" for k, v in p.plus.items()]
    t0 = time.time()
    try:
        run([str(BUILD / "sim" / cname / "Vtb_compute_cluster")] + plus, cwd=d, log=d / "sim.log", timeout=3600)
    except subprocess.TimeoutExpired:
        (d / "sim.log").write_text("TIMEOUT\n")
    res = cc_check.check(d)
    res.update(name=name, stage=stage, config=cname, scenario=scen, mode=mode, seed=seed,
               secs=round(time.time() - t0, 1), commands=len(p.cmds))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stages", default="1,2,3")
    ap.add_argument("--only", default="")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 4)
    ap.add_argument("--out", default="regression")
    a = ap.parse_args()
    stages = {int(s) for s in a.stages.split(",")}
    only = set(filter(None, a.only.split(",")))
    tests = [t for t in TESTS if t[1] in stages and (not only or t[0] in only)]
    cfgs = sorted({t[2] for t in tests})
    with ThreadPoolExecutor(min(a.jobs, 2)) as ex:          # each build already uses 2 compile jobs
        list(ex.map(build, cfgs))
    results = []
    for st in sorted(stages):                                # stage order: a later stage starts after the earlier
        batch = [t for t in tests if t[1] == st]
        with ThreadPoolExecutor(a.jobs) as ex:
            rs = list(ex.map(one, batch))
        for r in rs:
            tag = "PASS" if r["ok"] else "FAIL " + " | ".join(r["fails"])[:600]
            print(f"[stage {r['stage']}] {r['name']:22s} {r['config']:10s} {r['scenario']:7s} {r['mode']:5s} "
                  f"cmds {r['commands']:3d} records {r['records']:3d} destroyed {r['destroyed']} "
                  f"{r['secs']:7.1f}s {tag}", flush=True)
        results += rs
    n = sum(r["ok"] for r in results)
    print(f"regression: {n}/{len(results)} pass")
    REPORTS.mkdir(exist_ok=True)
    (REPORTS / f"{a.out}.json").write_text(json.dumps(dict(passed=n, total=len(results), results=results,
                                                            configs={k: CONFIGS[k].__dict__ for k in cfgs}),
                                                       indent=1))
    sys.exit(0 if n == len(results) else 1)


if __name__ == "__main__":
    main()
