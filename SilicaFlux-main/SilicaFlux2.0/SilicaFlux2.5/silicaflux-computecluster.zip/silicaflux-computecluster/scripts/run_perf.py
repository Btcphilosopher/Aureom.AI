#!/usr/bin/env python3
"""SilicaFlux Project 32: measured latency of the cluster control path and of the NoC-facing pipeline boundaries.

The same deterministic programs run on the minimum configuration without and with every register slice
(MEM_PIPE = LM_PIPE = EXT_PIPE = CMD_PIPE = 1).  Each command runs alone (Q between commands), 1-cycle memory, no
back-pressure.  Reported per command: end-to-end cycles (command accepted at the shell boundary -> completion
delivered at the shell boundary) and the unit's own CYCLES field (dispatch -> retirement inside the unit).
Writes reports/perf.json.
"""
from __future__ import annotations

import json
import sys
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "model"))
import run_tests as R  # noqa: E402
from cc_prog import CCProg  # noqa: E402

R.CONFIGS["perf_min"] = replace(R.CONFIGS["min"])
R.CONFIGS["perf_piped"] = replace(R.CONFIGS["min"], mem_pipe=1, lm_pipe=1, ext_pipe=1, cmd_pipe=1)
CASES = [("vec NOP", lambda p: p.vec_nop(0)),
         ("vec KERNEL FADD vl=64", lambda p: p.vec_kernel(0, 64, "FADD")),
         ("vec KERNEL FMUL vl=512", lambda p: p.vec_kernel(0, 512, "FMUL")),
         ("vec DMA 1 KiB in", lambda p: p.vec_dma_in(0, 1024, 32768)),
         ("tsu GEMM 4x4x4", lambda p: p.gemm(8, 4, 4, 4)),
         ("tsu GEMM 16x16x64", lambda p: p.gemm(8, 16, 16, 64)),
         ("tsu GEMM 32x32x128", lambda p: p.gemm(8, 32, 32, 128))]


def prog(cfg):
    p = CCProg(cfg, 99)
    for _, f in CASES:
        f(p)
        p.op("Q")
    return p


def main():
    out = {}
    for lat in (1, 8):
      for name in ("perf_min", "perf_piped"):
        R.build(name)
        cfg = R.CONFIGS[name]
        d = R.BUILD / "runs" / f"{name}_lat{lat}"
        p = prog(cfg)
        p.write(d)
        R.run([str(R.BUILD / "sim" / name / "Vtb_compute_cluster"), f"+dir={d}", "+seed=1", f"+lat_min={lat}",
               f"+lat_max={lat}"], cwd=d, log=d / "sim.log")
        acc, rec = [], []
        for line in (d / "records.txt").read_text().splitlines():
            t = line.split()
            if t and t[0] == "A":
                acc.append(int(t[2]))
            elif t and t[0] == "P":
                w = [int(x, 16) for x in t[3:9]]
                unit_cycles = w[5] if int(t[1]) < 8 else w[4]
                rec.append((int(t[9]), unit_cycles))
        ok = "RESULT PASS" in (d / "sim.log").read_text()
        out[f"{name}_lat{lat}"] = dict(ok=ok, lat=lat, cases=[dict(case=c[0], end_to_end=r[0] - a, unit_cycles=r[1])
                                                         for c, a, r in zip(CASES, acc, rec)])
      for a, b in zip(out[f"perf_min_lat{lat}"]["cases"], out[f"perf_piped_lat{lat}"]["cases"]):
        a["piped_end_to_end"] = b["end_to_end"]
        a["piped_unit_cycles"] = b["unit_cycles"]
        a["added"] = b["end_to_end"] - a["end_to_end"]
        a["ratio"] = round(b["end_to_end"] / a["end_to_end"], 3)
        print(f"lat {lat} {a['case']:24s} e2e {a['end_to_end']:6d} -> {b['end_to_end']:6d} (+{a['added']:5d}, "
              f"x{a['ratio']})   unit {a['unit_cycles']:6d} -> {b['unit_cycles']:6d}")
    (ROOT / "reports" / "perf.json").write_text(json.dumps(out, indent=1))
    sys.exit(0 if all(v["ok"] for v in out.values()) else 1)


if __name__ == "__main__":
    main()
