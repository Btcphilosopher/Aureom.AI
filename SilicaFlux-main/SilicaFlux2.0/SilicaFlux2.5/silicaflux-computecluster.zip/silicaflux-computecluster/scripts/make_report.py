#!/usr/bin/env python3
"""Generate reports/*.md from the JSON results (every number in the reports comes from a tool run)."""
from __future__ import annotations

import json
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REP = ROOT / "reports"


def load(p):
    p = REP / p
    return json.loads(p.read_text()) if p.exists() else None


def tool_versions():
    out = {}
    for name, cmd in (("verilator", ["verilator", "--version"]), ("icarus", ["iverilog", "-V"]),
                      ("yosys", ["yosys", "-V"]), ("openroad", ["/opt/eda/env/bin/openroad", "-version"]),
                      ("python", ["python3", "--version"])):
        try:
            out[name] = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                       timeout=60).stdout.splitlines()[0].strip()
        except Exception as e:  # noqa: BLE001
            out[name] = f"unavailable ({e})"
    return out


def regression_md(r):
    L = ["# Regression (RTL simulation, Verilator 5.020)", "",
         f"**{r['passed']} / {r['total']} runs pass.**  Every run is checked by `model/cc_check.py` against "
         "independent references (TENSORCORE 08 `tsu_ref.py` for GEMM, binary64-rounded FP32 for FADD / FMUL): "
         "every completion record field incl. SEQ and source ID, the error flag, the whole 1 MiB shared-memory image, "
         "LOST after every cluster reset, SFB2 protocol checkers on every crossbar port and the shared-memory port, "
         "and the coverage items each scenario must hit.", "",
         "| stage | run | config | scenario | mode | commands | records checked | destroyed by reset | sim s | result |",
         "|---|---|---|---|---|---|---|---|---|---|"]
    for x in r["results"]:
        L.append(f"| {x['stage']} | `{x['name']}` | {x['config']} | {x['scenario']} | {x['mode']} | {x['commands']} | "
                 f"{x['records']} | {x['destroyed']} | {x['secs']} | {'PASS' if x['ok'] else 'FAIL: ' + '; '.join(x['fails'])[:300]} |")
    L += ["", "## Configurations", "", "| config | parameters |", "|---|---|"]
    for k, v in r["configs"].items():
        L.append(f"| {k} | " + ", ".join(f"{a}={b}" for a, b in v.items()) + " |")
    L += ["", "## Contention, concurrency and coverage (from each run's stats.txt)", ""]
    for x in r["results"]:
        st = x.get("stats", "")
        keep = [l for l in st.splitlines() if l.startswith(("master", "vector_and", "max_clusters", "cover", "host_tr",
                                                             "mem_tr"))]
        if keep:
            L.append(f"**{x['name']}**")
            L.append("```")
            L += keep
            L.append("```")
    return "\n".join(L) + "\n"


def lint_md(r):
    L = ["# Lint and elaboration sweep", "",
         f"**{r['passed']} / {r['total']} checks pass.**  Legal configurations: Verilator 5.020 `--lint-only -Wall` "
         "with **zero warnings in the new RTL** (`rtl/`), Icarus 12 elaboration + time-0 run, Yosys 0.33 "
         "`hierarchy -check -chparam; proc; check -assert`.  Illegal configurations: all three tools must refuse, and "
         "Verilator's refusal must be an elaboration `$fatal` of the design's own parameter checks (USERFATAL).", "",
         "| kind | name | parameters | Verilator | new-RTL warnings | 3rd-party warnings (unmodified RTL) | Icarus | Yosys | result |",
         "|---|---|---|---|---|---|---|---|---|"]
    for x in r["results"]:
        v = x["verilator"]
        p = ", ".join(f"{a}={b}" for a, b in x["params"].items()) or "(defaults)"
        L.append(f"| {x['kind']} | {x['name']} | {p} | {'ok' if v['ok'] else 'refused'} | {len(v['new_rtl_warnings'])} | "
                 f"{v['third_party_warnings']} | {'ok' if x['icarus']['ok'] else 'refused'} | "
                 f"{'ok' if x['yosys']['ok'] else 'refused'} | {'PASS' if x['pass'] else 'FAIL'} |")
    return "\n".join(L) + "\n"


def mem_class(m):
    return "SRAM-macro candidate" if m["bits"] >= 4096 and m["depth"] >= 64 and m["rd_ports"] <= 2 and m["wr_ports"] <= 2 \
        else "register file / flip-flops"


def synth_md(targets):
    L = ["# Synthesis (Yosys 0.33, technology-independent, hierarchy preserved)", "",
         "**Not silicon area.**  Generic Yosys cells (`$_AND_`, `$_MUX_`, `$_DFF_*` ...) after `abc -fast`; memories are "
         "left as inferred `$mem_v2` (reported in bits, never mapped to gates: on silicon they are SRAM macros from the "
         "SRAM Wrapper Library ASIC backend).  Raw logs (gzip), scripts and `stat` output: `reports/synth/<target>/`.", "",
         "## Build targets", "",
         "| target | top | parameters | result | Yosys s | generic cells | flip-flops | inferred memories | memory bits |",
         "|---|---|---|---|---|---|---|---|---|"]
    for t in targets:
        p = ", ".join(f"{a}={b}" for a, b in t["chparams"].items()) or "(defaults)"
        L.append(f"| `{t['target']}` | `{t['top']}` | {p} | {'OK' if t['ok'] else 'FAIL'} | {t['secs']} | "
                 f"{t.get('cells', 0):,} | {t.get('ffs', 0):,} | {t.get('mems', 0)} | {t.get('mem_bits', 0):,} |")
    for t in targets:
        if not t["ok"]:
            continue
        L += ["", f"## `{t['target']}` — {t['desc']}", "",
              f"Instance-name check: expected `{', '.join(t['expected_instances'])}` -> "
              f"{'all present' if not t['missing_instances'] else 'MISSING ' + str(t['missing_instances'])}.", "",
              "| region (instance) | cells | flip-flops | memory bits | memories | populated |", "|---|---|---|---|---|---|"]
        for g in t["regions"]:
            L.append(f"| `{g['instance']}` | {g['cells']:,} | {g['ffs']:,} | {g['mem_bits']:,} | {g['mems']} | "
                     f"{'yes' if g.get('populated', True) else 'no (empty slot)'} |")
        if t["target"] in ("vector_cluster", "tensor_cluster"):
            L += ["", "Inferred memories:", "", "| instance path | width | depth | bits | R/W ports | class |",
                  "|---|---|---|---|---|---|"]
            for m in sorted(t["memories"], key=lambda m: -m["bits"]):
                L.append(f"| `{m['path']}` | {m['width']} | {m['depth']} | {m['bits']:,} | {m['rd_ports']}R/{m['wr_ports']}W | "
                         f"{mem_class(m)} |")
        L += ["", "Highest leaf fanout (leaf cell input pins reached through the hierarchy):", "",
              "| net | leaf loads |", "|---|---|"]
        for f in t["fanout"][:12]:
            L.append(f"| `{f['net']}` | {f['leaf_loads']:,} |")
        if t["wide_buses"]:
            L += ["", "Widest nets of the top module (>= 64 bits):", "", "| net | width | max loads per bit |", "|---|---|---|"]
            for b in t["wide_buses"][:12]:
                L.append(f"| `{b['net']}` | {b['width']} | {b['max_bit_loads']} |")
        top_types = list(t["cell_types"].items())[:10]
        L += ["", "Most frequent cell types: " + ", ".join(f"`{k}` {v:,}" for k, v in top_types)]
    return "\n".join(L) + "\n"


def physical_md(r):
    if not r:
        return "# Physical experiment\n\nNot run.\n"
    L = ["# Physical-integration experiment (OpenROAD, exploratory)", "",
         "**Reduced configuration (`configs/phys_hpc.json`), memories as flip-flops, sky130hd typical corner, pre-CTS "
         "(ideal clock), no routing.** Not a floorplan sign-off and not an area result. Every coordinate and count "
         "below was read back from the OpenROAD database or log; tool: OpenROAD 2.0-12331-g6011bbe77 (FloorplanLab's "
         "pinned build), ORFS ab2aaf0f sky130hd platform.", "",
         "Configuration: " + ", ".join(f"{a}={b}" for a, b in r["config"].items()), "",
         f"Mapped standard-cell area (Yosys 0.33 `stat -liberty`): **{r['chip_cell_area_um2']:,.0f} um^2**.", "",
         "## 1. Mapped area per region", "", "| instance | cells | cell area um^2 |", "|---|---|---|"]
    for k, v in sorted(r["areas"].items()):
        if v["cells"]:
            L.append(f"| `{k}` | {v['cells']:,} | {v['area_um2']:,} |")
    p = r["plan"]
    L += ["", f"Proposed floorplan (generated): die {p['die_um']} um, core {p['core_um']} um, region utilization "
          f"target {p['util']}.", "", "| region | prefixes | box um | cell area um^2 |", "|---|---|---|---|"]
    for g in p["regions"]:
        L.append(f"| {g['name']} | `{' '.join(g['prefixes'])}` | {g['box_um']} | {g['cell_area_um2']:,} |")
    c = r.get("constraints_check") or {}
    L += ["", "## 2. The constraints load on the real instance names", "",
          f"`physical/apply_constraints.tcl` on the mapped netlist (no placement): {c.get('summary')}, applied in "
          f"{c.get('apply_ms')} ms, regions without members: {c.get('region_errors') or 'none'}; DEF REGIONS / GROUPS "
          f"written (`reports/physical/phys_hpc_regions_groups.def`).", "",
          "| region | members |  | group | members |", "|---|---|---|---|---|"]
    regs, grps = c.get("regions", []), c.get("groups", [])
    for i in range(max(len(regs), len(grps))):
        a = regs[i] if i < len(regs) else ("", "")
        b = grps[i] if i < len(grps) else ("", "")
        L.append(f"| {a[0]} | {a[1]} |  | {b[0]} | {b[1]} |")
    L += ["", "## 3. Does this OpenROAD build honour placement regions? (controlled test)", "",
          "Two copies of the mapped completion arbiter (2 x 4 729 cells, `reports/physical/region_support_test/`), "
          "one region per copy in OPPOSITE corners of a 600 x 600 um die; containment measured after global and after "
          "detailed placement.", "",
          "| mechanism | inside after global placement (block A / block B) | inside after detailed placement (A / B) | avg / max displacement um | check_placement |",
          "|---|---|---|---|---|"]
    names = dict(odb_region="odb dbRegion (INCLUSIVE) + addInst", voltage_domain="create_voltage_domain + group addInst",
                 none="no constraint (control)", odb_region_groups="odb dbRegion + region-less PHYSICAL_CLUSTER dbGroup",
                 seeded="members seeded at the region centre, global_placement -skip_initial_place")
    for k, v in r["region_support_test"].items():
        L.append(f"| {names.get(k, k)} | {'/'.join(map(str, v['after_gpl']))} of {'/'.join(map(str, v['members']))} | "
                 f"{'/'.join(map(str, v['after_dpl'])) or '—'} | {'/'.join(v['avg_disp']) or '—'} / {'/'.join(v['max_disp']) or '—'} | "
                 f"{v['check_placement']} |")
    ct = r["control"]
    L += ["", "## 4. Full reduced design placed WITHOUT constraints (control)", "",
          f"check_placement {'passed' if ct['check_placement_ok'] else 'FAILED'}; global placement overflow "
          f"{', '.join(ct['gpl_overflow'])}; legalized HPWL {', '.join(ct['legalized_hpwl'])} um; average detailed-placement "
          f"displacement {', '.join(ct['dpl_avg_disp'])} um. Containment of each cluster in its *proposed* box, and the "
          "bounding box its instances actually occupy:", "",
          "| region | members | inside proposed box | inside % | other instances in the box | members' bbox um^2 | region um^2 | centroid um |",
          "|---|---|---|---|---|---|---|---|"]
    for g in ct["containment"]["regions"]:
        L.append(f"| {g['region']} | {g['members']:,} | {g['inside']:,} | {g['inside_pct']} | {g['foreign_inside']:,} | "
                 f"{g['spread_bbox_um2']:,} | {g['region_area_um2']:,} | {g['centroid_um']} |")
    L += ["", "Picture: `reports/physical/phys_hpc_placement_no_regions.svg` (1 in 25 placed instances, coloured by cluster; "
          "dashed boxes = proposal).", "",
          "Full design WITH the regions and groups applied: " + r["full_with_regions"]["status"] + ".", "",
          "## 5. Pre-CTS timing after buffering: are the NoC-facing slices required?", "",
          "`physical/post_sta.py` on each placed design: dont_use sky130 low-power / delay cells, `repair_design`, "
          "re-legalization, placement parasitics, ideal clock, 20 ns reference period (a reference, not a target). "
          "Worst path through each region-boundary interface (`report_checks -through` the shell's nets):", ""]
    tm = r.get("timing", {})
    if tm:
        tags = [t for t in ("all_slices", "no_slices") if t in tm]
        L.append("| interface | " + " | ".join(f"{t}: slack ns (arrival ns), start -> end region" for t in tags) + " |")
        L.append("|---|" + "---|" * len(tags))
        keys = sorted({k for t in tags for k in tm[t].get("interfaces", {})})
        for k in keys:
            row = [k]
            for t in tags:
                x = tm[t].get("interfaces", {}).get(k)
                row.append("—" if not x or x.get("slack_ns") is None else
                           f"{x['slack_ns']} ({x['arrival_ns']}), {x['start_region']} -> {x['end_region']}")
            L.append("| " + " | ".join(row) + " |")
        L.append("")
        for t in tags:
            x = tm[t]
            L += [f"**{t}**: WNS {x['wns_ns']} ns, TNS {x['tns_ns']} ns, check_placement after buffering "
                  f"{'passed' if x['check_placement_ok'] else 'FAILED'}; {x['area_line']}; repair_design: "
                  + "; ".join(l.split('] ')[-1] for l in x["repair_design"]) + ".", "",
                  "Worst data paths: " + "; ".join(f"{p['slack_ns']} ns {p['start_region']}->{p['end_region']} "
                                                    f"(`{p['start'][:48]}` → `{p['end'][:48]}`)" for p in x["worst_data_paths"][:4]), ""]
    return "\n".join(L) + "\n"


def perf_md(r):
    if not r:
        return ""
    L = ["# Measured latency of the control path and of the pipeline boundaries", "",
         "Minimum configuration without and with every register slice (MEM_PIPE = LM_PIPE = EXT_PIPE = CMD_PIPE = 1); "
         "each command alone, no back-pressure, shared-memory latency 1 and 8 cycles (`scripts/run_perf.py`). "
         "End-to-end = command accepted at the shell boundary -> completion delivered at the shell boundary. "
         "`unit` = the unit's own CYCLES field (dispatch -> retirement).", ""]
    for lat in (1, 8):
        key = f"perf_min_lat{lat}"
        if key not in r:
            continue
        L += [f"## shared-memory latency {lat} cycle(s)", "",
              "| command | end-to-end, no slices | end-to-end, all slices | added | ratio | unit, no slices | unit, all slices |",
              "|---|---|---|---|---|---|---|"]
        for c in r[key]["cases"]:
            L.append(f"| {c['case']} | {c['end_to_end']} | {c['piped_end_to_end']} | +{c['added']} | x{c['ratio']} | "
                     f"{c['unit_cycles']} | {c['piped_unit_cycles']} |")
        L.append("")
    return "\n".join(L) + "\n"


def main():
    REP.mkdir(exist_ok=True)
    vers = tool_versions()
    (REP / "tools.json").write_text(json.dumps(vers, indent=1))
    r = load("regression.json")
    if r:
        (REP / "regression.md").write_text(regression_md(r))
    li = load("lint.json")
    if li:
        (REP / "lint.md").write_text(lint_md(li))
    targets = [load(f"synth/{t}.json") for t in ("vector_cluster", "tensor_cluster", "compute_min", "compute_hpc",
                                                   "compute_hpc_piped")]
    targets = [t for t in targets if t]
    if targets:
        (REP / "synth.md").write_text(synth_md(targets))
    ph = load("physical/summary.json")
    (REP / "physical.md").write_text(physical_md(ph))
    pf = load("perf.json")
    if pf:
        (REP / "perf.md").write_text(perf_md(pf))
    # summary
    S = ["# Results summary (generated by scripts/make_report.py)", "", "Tools: " + "; ".join(f"{k}: {v}" for k, v in vers.items()), ""]
    if r:
        S.append(f"* Regression: **{r['passed']} / {r['total']}** runs pass ([regression.md](regression.md))")
    if li:
        S.append(f"* Lint / elaboration / illegal-configuration rejection: **{li['passed']} / {li['total']}** ([lint.md](lint.md))")
    for t in targets:
        S.append(f"* Synthesis `{t['target']}`: {'OK' if t['ok'] else 'FAIL'}, {t.get('cells', 0):,} generic cells, "
                 f"{t.get('ffs', 0):,} flip-flops, {t.get('mem_bits', 0):,} inferred memory bits, missing instances: "
                 f"{t.get('missing_instances')} ([synth.md](synth.md))")
    if ph:
        S.append("* OpenROAD region support (controlled test) and reduced-design placement / timing: [physical.md](physical.md)")
    if pf:
        S.append("* Latency of the pipeline boundaries: [perf.md](perf.md)")
    (REP / "SUMMARY.md").write_text("\n".join(S) + "\n")
    print("\n".join(S))


if __name__ == "__main__":
    main()
