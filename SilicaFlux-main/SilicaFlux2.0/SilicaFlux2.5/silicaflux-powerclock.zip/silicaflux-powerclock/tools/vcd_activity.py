#!/usr/bin/env python3
"""
Toggle/activity analysis of a POWERCLOCK simulation VCD (activity-based
estimate ONLY). For each scenario phase (tb_pm_top.phase) it reports:
  * clock edges per microsecond on clk_core / clk_vec / clk_tns  (clock-tree activity)
  * signal bit-toggles per core cycle inside the DUT, by sub-block
  * unit busy duty cycles
No capacitance, voltage or library data is used, so NO WATTAGE IS PRODUCED.
Converting these activity factors to power requires a vendor or ASIC power
tool with real netlists and libraries (see docs/07_power_estimation.md).
"""
import sys, collections, re, json

def parse(path, phase_name="phase"):
    ids = {}            # id -> (scope, name, width)
    scope = []
    t_now = 0
    phase_id = None
    vals = {}
    phase = 0
    t_phase_start = {}
    dur = collections.Counter()
    toggles = collections.defaultdict(collections.Counter)   # phase -> scope -> toggles
    edges = collections.defaultdict(collections.Counter)     # phase -> clock -> rising edges
    busy_t = collections.defaultdict(collections.Counter)    # phase -> signal -> high time
    last_t = 0
    clocks = {}
    busies = {}
    with open(path) as f:
        in_defs = True
        for line in f:
            line = line.strip()
            if not line:
                continue
            if in_defs:
                if line.startswith("$scope"):
                    scope.append(line.split()[2])
                elif line.startswith("$upscope"):
                    scope.pop()
                elif line.startswith("$var"):
                    p = line.split()
                    w, code, name = int(p[2]), p[3], p[4]
                    sc = ".".join(scope)
                    ids.setdefault(code, []).append((sc, name, w))
                    full = sc + "." + name
                    if name == phase_name and sc.endswith("tb_pm_top"):
                        phase_id = code
                    if sc.endswith("tb_pm_top") and name in ("clk_core", "clk_vec", "clk_tns"):
                        clocks[code] = name
                    if sc.endswith("tb_pm_top") and name in ("vec_busy", "tns_busy", "dma_busy"):
                        busies[code] = name
                elif line.startswith("$enddefinitions"):
                    in_defs = False
                continue
            c = line[0]
            if c == "#":
                t = int(line[1:])
                d = t - last_t
                dur[phase] += d
                for code, nm in busies.items():
                    if vals.get(code) == "1":
                        busy_t[phase][nm] += d
                last_t = t
                continue
            if c in "01xzXZ":
                v, code = c, line[1:]
            elif c in "bB":
                v, code = line[1:].split()
            else:
                continue
            old = vals.get(code)
            vals[code] = v
            if code == phase_id:
                phase = int(v, 2) if c in "bB" else int(v)
                continue
            if old is None:
                continue
            if code in clocks and v == "1" and old == "0":
                edges[phase][clocks[code]] += 1
            if len(v) == 1 and len(old) == 1:
                n = int(v != old)
            else:
                a, b = old.zfill(len(v)), v.zfill(len(old))
                n = sum(1 for x, y in zip(a, b) if x != y)
            if n:
                for sc, name, _w in ids[code]:
                    # clock nets are reported as edges/us above; counting them here
                    # would swamp data activity with a constant 2 toggles/cycle/port
                    if "clk" in name.lower():
                        continue
                    if ".dut" in sc and "u_" in sc:
                        blk = sc.split(".dut.", 1)[1].split(".")[0]
                        toggles[phase][blk] += n
                    elif sc.endswith(".dut"):
                        toggles[phase]["(top-level nets)"] += n
    return dur, edges, toggles, busy_t

def main():
    vcd, out_md = sys.argv[1], sys.argv[2]
    dur, edges, toggles, busy_t = parse(vcd)
    names = {1: "ACTIVE (full issue rate)", 2: "THERMAL_LIMIT (rate 4/16, tensor paused)",
             3: "IDLE (unit clocks running)", 4: "CLOCK_IDLE (unit clocks gated)"}
    res = {}
    L = ["# POWERCLOCK activity analysis (toggle-based, unit-less)", "",
         "Source: `" + vcd.split("/")[-1] + "` from `tb_pm_top +TEST=power_trace` (base build, core 100 MHz, always-on 100 MHz).",
         "These are **activity factors from RTL simulation**, not power. No wattage is derived here;",
         "see docs/07_power_estimation.md for the vendor/ASIC flows that turn activity into power.", "",
         "| Phase | duration (us) | clk_core edges/us | clk_vec edges/us | clk_tns edges/us | DUT data toggles / core cycle (clock nets excluded) | vec busy | tns busy | dma busy |",
         "|---|---|---|---|---|---|---|---|---|"]
    for ph in (1, 2, 3, 4):
        us = dur[ph] / 1e6  # VCD timescale is ps
        if us <= 0:
            continue
        e = edges[ph]
        core_cyc = max(e["clk_core"], 1)
        tog = sum(toggles[ph].values())
        r = {"us": us, "core_mhz": e["clk_core"] / us, "vec_mhz": e["clk_vec"] / us, "tns_mhz": e["clk_tns"] / us,
             "tog_per_cyc": tog / core_cyc, "blocks": {k: v / core_cyc for k, v in toggles[ph].items()},
             "busy": {k: busy_t[ph][k] / dur[ph] for k in ("vec_busy", "tns_busy", "dma_busy")}}
        res[ph] = r
        L.append(f"| {names[ph]} | {us:.1f} | {r['core_mhz']:.1f} | {r['vec_mhz']:.1f} | {r['tns_mhz']:.1f} | "
                 f"{r['tog_per_cyc']:.1f} | {100*r['busy']['vec_busy']:.0f}% | {100*r['busy']['tns_busy']:.0f}% | {100*r['busy']['dma_busy']:.0f}% |")
    L += ["", "## DUT data toggles per core cycle by sub-block (clock nets excluded)", "",
          "| Block | " + " | ".join(names[p].split(" (")[0] for p in res) + " |",
          "|---|" + "---|" * len(res)]
    blocks = sorted({b for p in res for b in res[p]["blocks"]})
    for b in blocks:
        L.append(f"| {b} | " + " | ".join(f"{res[p]['blocks'].get(b, 0):.2f}" for p in res) + " |")
    if 1 in res and 4 in res:
        L += ["", "## Observations", "",
              f"* Unit clock activity in CLOCK_IDLE: vector {res[4]['vec_mhz']:.2f} edges/us, tensor {res[4]['tns_mhz']:.2f} edges/us "
              f"(vs {res[3]['vec_mhz']:.1f} in IDLE with clocks running): the gated unit clock trees are fully stopped.",
              f"* THERMAL_LIMIT reduced vector busy duty from {100*res[1]['busy']['vec_busy']:.0f}% to {100*res[2]['busy']['vec_busy']:.0f}% "
              f"and tensor from {100*res[1]['busy']['tns_busy']:.0f}% to {100*res[2]['busy']['tns_busy']:.0f}% (tensor paused).",
              f"* Always-on timers (thermal sample-timeout counter, FSM idle/dwell/step timers) contribute "
              f"{res[4]['blocks'].get('u_therm', 0) + res[4]['blocks'].get('u_fsm', 0):.1f} data toggles per cycle in every phase, "
              "including CLOCK_IDLE: the floor of the power manager's own activity.",
              f"* In THERMAL_LIMIT the power manager's own core-side logic is slightly busier than in ACTIVE "
              f"({res[2]['blocks'].get('u_shim', 0):.1f} vs {res[1]['blocks'].get('u_shim', 0):.1f} toggles/cycle in u_shim: rate "
              "accumulator and stall counters), while unit duty falls; the throttling saving is in the units, not in this block.",
              "* Unit datapaths are testbench models here, so unit-internal toggles are not part of the DUT figures; on silicon the",
              "  dominant saving of CLOCK_IDLE is the unit clock trees and datapath registers, which this RTL stops but cannot quantify."]
    open(out_md, "w").write("\n".join(L) + "\n")
    json.dump(res, open(out_md.replace(".md", ".json"), "w"), indent=1)
    print("\n".join(L[:12]))

if __name__ == "__main__":
    main()
