#!/usr/bin/env python3
"""Golden-model check: RTL sf_thermal_monitor vs tools/pm_policy_model.ThermalMonitorModel.
Generates randomized configurations and stimulus (threshold crossings, hysteresis
band dwell, spikes, out-of-range, implausible steps, sensor faults, dropouts),
runs the Verilator testbench, and compares every cycle."""
import os, random, subprocess, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from pm_policy_model import ThermCfg, ThermalMonitorModel, to_s16

ROOT = pathlib.Path(__file__).resolve().parent.parent
BIN = ROOT / "build/therm/tb_therm"
WORK = ROOT / "build/therm/vectors"


def build():
    if BIN.exists():
        return
    files = [l.strip() for l in open(ROOT / "rtl/files.f") if l.strip()]
    cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Irtl",
           "--top-module", "tb_thermal_monitor", *files, "tb/tb_thermal_monitor.sv",
           "-Mdir", "build/therm", "-o", "tb_therm"]
    subprocess.run(cmd, cwd=ROOT, check=True, stdout=subprocess.DEVNULL)


def rand_cfg(rng):
    warn = rng.randint(60, 90) * 16
    thr = warn + rng.randint(0, 15) * 16
    crit = thr + rng.randint(0, 15) * 16
    return ThermCfg(warn_set=warn, warn_hyst=rng.randint(0, 6) * 16, thr_set=thr,
                    thr_hyst=rng.randint(0, 8) * 16, crit_set=crit, crit_hyst=rng.randint(0, 12) * 16,
                    range_min=-40 * 16, range_max=150 * 16,
                    max_delta=rng.choice([0, 0, 5 * 16, 12 * 16]),
                    sample_timeout=rng.choice([0, 40, 120, 400]),
                    escalate=rng.randint(0, 4), deescalate=rng.randint(0, 5))


def rand_stim(rng, cfg, n):
    out, t, period = [], 60.0, rng.randint(1, 12)
    fault_len = 0
    lo, hi = to_s16(cfg.warn_set) / 16 - 12, to_s16(cfg.crit_set) / 16 + 4
    center = rng.uniform(lo, hi)
    for i in range(n):
        valid = (i % period == 0)
        if rng.random() < 0.002:
            period = rng.randint(1, 60)          # occasional dropout-length gaps -> timeouts
        if valid:
            r = rng.random()
            if r < 0.05:
                t = rng.uniform(40, 125)          # jump
            elif r < 0.08:
                t = rng.choice([200.0, -60.0])    # implausible
            else:
                if rng.random() < 0.01:
                    center = rng.uniform(lo, hi)      # move the operating point
                t += rng.gauss(0, 2.0) + 0.08 * (center - t)
                t = min(max(t, 30), 130)
        if fault_len == 0 and rng.random() < 0.003:
            fault_len = rng.randint(1, 30)
        f = fault_len > 0
        fault_len = max(0, fault_len - 1)
        s = int(round(t * 16)) & 0xFFFF
        out.append((int(valid), int(f), s))
    return out


def run_case(seed, n=6000):
    rng = random.Random(seed)
    cfg = rand_cfg(rng)
    stim = rand_stim(rng, cfg, n)
    WORK.mkdir(parents=True, exist_ok=True)
    fc, fs, fo = WORK / f"cfg{seed}.hex", WORK / f"stim{seed}.hex", WORK / f"out{seed}.hex"
    fc.write_text("\n".join(f"{v:08x}" for v in cfg.fields()) + "\n")
    fs.write_text("\n".join(f"{(v << 17) | (f << 16) | s:05x}" for v, f, s in stim) + "\n")
    subprocess.run([str(BIN), f"+CFG={fc}", f"+STIM={fs}", f"+OUT={fo}", f"+N={n}"],
                   check=True, stdout=subprocess.DEVNULL)
    rtl = [int(l, 16) for l in fo.read_text().split()]
    m = ThermalMonitorModel(cfg)
    stats = {"levels": [0, 0, 0, 0], "fault_cycles": 0}
    for i, (v, f, s) in enumerate(stim):
        m.step(bool(v), s, bool(f))
        exp = m.outputs()
        stats["levels"][m.level] += 1
        stats["fault_cycles"] += int(m.fault)
        if rtl[i] != exp:
            return False, f"seed {seed} cycle {i}: rtl {rtl[i]:06x} model {exp:06x} stim v={v} f={f} s={to_s16(s)/16:.2f}", stats
    return True, "", stats


def mutate():
    """Deliberately break the reference model (de-escalate on the SET threshold,
    i.e. ignore hysteresis) to prove the comparison detects a policy error."""
    orig = ThermalMonitorModel._levels
    def bad(self, s):
        raw, _hold = orig(self, s)
        return raw, raw
    ThermalMonitorModel._levels = bad


def main():
    if "--mutate" in sys.argv:
        sys.argv.remove("--mutate")
        mutate()
        print("MUTATION MODE: reference model hysteresis disabled; mismatches are EXPECTED")
    build()
    seeds = range(int(sys.argv[1]) if len(sys.argv) > 1 else 40)
    agg = [0, 0, 0, 0]; fcyc = 0; fails = 0
    for sd in seeds:
        ok, msg, st = run_case(sd)
        agg = [a + b for a, b in zip(agg, st["levels"])]; fcyc += st["fault_cycles"]
        if not ok:
            fails += 1
            print("MISMATCH", msg)
    total = sum(agg)
    print(f"thermal monitor golden check: {len(seeds)} random configurations x 6000 cycles, "
          f"{fails} mismatching runs")
    print("  coverage (cycles per level): " + ", ".join(
        f"{n} {c} ({100*c/total:.1f}%)" for n, c in zip(["NORMAL", "WARN", "THROTTLE", "CRITICAL"], agg))
          + f", sensor-fault cycles {fcyc}")
    sys.exit(1 if fails else 0)


if __name__ == "__main__":
    main()
