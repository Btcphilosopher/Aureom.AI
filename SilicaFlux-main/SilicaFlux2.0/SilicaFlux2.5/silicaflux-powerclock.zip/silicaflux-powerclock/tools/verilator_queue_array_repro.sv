// Verilator 5.020 defect reproduction (simulator bug, not RTL): an array of
// queues mis-routes push_back and reads data as 0. Expected output:
//   pend sizes 3 2 0 / cmd sizes 3 2 0 / q0 entries non-zero
// Observed with Verilator 5.020: pend sizes 3 5 0, cmd sizes 1 2 0, q0[0]=0.
// Build: verilator --binary --timing tools/verilator_queue_array_repro.sv
`timescale 1ns/1ps
module tb_dbg;
  logic [47:0] q_cmd [3][$];
  logic [47:0] q_pend[3][$];
  int next_id = 1;
  task automatic enqueue(input int ch, input int n);
    for (int i = 0; i < n; i++) begin
      logic [15:0] id = 16'(next_id);
      logic [15:0] a  = 16'($urandom);
      next_id = next_id + 1;
      q_pend[ch].push_back({id, a, 16'h00AB});
    end
  endtask
  initial begin
    enqueue(0, 3); enqueue(1, 2);
    $display("pend sizes %0d %0d %0d", q_pend[0].size(), q_pend[1].size(), q_pend[2].size());
    for (int c = 0; c < 3; c++) while (q_pend[c].size() > 0) q_cmd[c].push_back(q_pend[c].pop_front());
    $display("cmd sizes %0d %0d %0d", q_cmd[0].size(), q_cmd[1].size(), q_cmd[2].size());
    foreach (q_cmd[0][i]) $display("q0[%0d]=%h", i, q_cmd[0][i]);
    $finish;
  end
endmodule
