#!/usr/bin/env python3
"""Prepare a Yosys-0.33-compatible copy of the RTL in build/syn_src/.
Yosys 0.33 does not implement SystemVerilog `import pkg::*`; it does accept
package-qualified names. This MECHANICAL transform removes import lines and
qualifies every identifier declared in sf_pm_pkg / sf_pm_regs_pkg. The
simulation sources are untouched; this copy is only for the synthesis check."""
import pathlib, re
ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "build/syn_src"; OUT.mkdir(parents=True, exist_ok=True)
files = [l.strip() for l in open(ROOT / "rtl/files.f") if l.strip()]
pk_names = {}
for pf, pk in [("rtl/sf_pm_pkg.sv", "sf_pm_pkg"), ("rtl/sf_pm_regs_pkg.sv", "sf_pm_regs_pkg")]:
    txt = re.sub(r"//.*", "", (ROOT / pf).read_text())
    names = set(re.findall(r"localparam\s+(?:\w+\s+)?(?:logic\s*)?(?:\[[^\]]*\]\s*)?(\w+)\s*=", txt))
    names |= set(re.findall(r"\}\s*(\w+)\s*;", txt))                      # typedef names
    for body in re.findall(r"enum[^{]*\{([^}]*)\}", txt):                  # enum constants
        names |= set(re.findall(r"(\w+)\s*=", body))
    for n in names: pk_names[n] = pk
pat = re.compile(r"(?<![\w:.'])(" + "|".join(sorted(pk_names, key=len, reverse=True)) + r")\b")
for f in files:
    src = (ROOT / f).read_text()
    if f.endswith("_pkg.sv"):
        (OUT / pathlib.Path(f).name).write_text(src); continue
    src = re.sub(r"^\s*import\s+\w+::\*;\s*$", "", src, flags=re.M)
    lines = []
    for line in src.split("\n"):
        code, sep, com = line.partition("//")
        code = pat.sub(lambda m: f"{pk_names[m.group(1)]}::{m.group(1)}", code)
        lines.append(code + sep + com)
    (OUT / pathlib.Path(f).name).write_text("\n".join(lines))
print(f"prepared {len(files)} files, {len(pk_names)} package identifiers qualified")
