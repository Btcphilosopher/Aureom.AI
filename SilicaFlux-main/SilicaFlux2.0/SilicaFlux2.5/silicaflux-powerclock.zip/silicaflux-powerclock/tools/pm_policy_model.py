#!/usr/bin/env python3
"""
POWERCLOCK policy reference model.

1. ThermalMonitorModel : cycle-exact mirror of rtl/sf_thermal_monitor.sv.
   Used by tools/check_thermal_monitor.py to compare against the RTL
   sample-by-sample (golden-model check).

2. PolicyModel : sample-level model of the THERMAL_LIMIT / FAULT policy
   (level -> throttle rate, min dwell, critical -> fault), used for
   control-loop stability studies with a thermal backend.

3. Thermal backends:
   LumpedRCBackend    - first-order RC node. EXPLICITLY NOT ThermalLab.
   ThermalLabBackend  - adapter for SilicaFlux ThermalLab (Project 09).
                        ThermalLab was not available in the build
                        environment, so this adapter defines the contract
                        and refuses to run rather than invent an API.

Units: temperatures in degC; RTL samples are signed 16-bit, 1/16 degC.
Power numbers used in studies are ASSUMED scenario inputs, not estimates.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Protocol

NORMAL, WARN, THROTTLE, CRITICAL = 0, 1, 2, 3
LEVEL_NAMES = ["NORMAL", "WARN", "THROTTLE", "CRITICAL"]
MAX24 = (1 << 24) - 1


def to_s16(v: int) -> int:
    v &= 0xFFFF
    return v - 0x10000 if v & 0x8000 else v


# ---------------------------------------------------------------------------
# 1. Cycle-exact thermal monitor model
# ---------------------------------------------------------------------------
@dataclass
class ThermCfg:
    warn_set: int = 1360
    warn_hyst: int = 48
    thr_set: int = 1520
    thr_hyst: int = 80
    crit_set: int = 1680
    crit_hyst: int = 160
    range_min: int = -640
    range_max: int = 2400
    max_delta: int = 0
    sample_timeout: int = MAX24
    escalate: int = 2
    deescalate: int = 4

    def fields(self) -> List[int]:
        """Order used by tb/tb_thermal_monitor.sv cfg file."""
        return [self.warn_set & 0xFFFF, self.warn_hyst, self.thr_set & 0xFFFF, self.thr_hyst,
                self.crit_set & 0xFFFF, self.crit_hyst, self.range_min & 0xFFFF,
                self.range_max & 0xFFFF, self.max_delta, self.sample_timeout,
                self.escalate, self.deescalate]


@dataclass
class ThermalMonitorModel:
    cfg: ThermCfg
    level: int = NORMAL
    esc: int = 0
    desc: int = 0
    good: int = 0
    fault: bool = False
    reason: int = 0          # {delta, range, timeout, ext}
    since: int = 0
    prev_raw: int = 0
    have_prev: bool = False
    last: int = 0
    seen: bool = False

    def _levels(self, s: int):
        c = self.cfg
        sets = [to_s16(c.warn_set), to_s16(c.thr_set), to_s16(c.crit_set)]
        clrs = [sets[0] - c.warn_hyst, sets[1] - c.thr_hyst, sets[2] - c.crit_hyst]
        raw = CRITICAL if s >= sets[2] else THROTTLE if s >= sets[1] else WARN if s >= sets[0] else NORMAL
        hold = CRITICAL if s >= clrs[2] else THROTTLE if s >= clrs[1] else WARN if s >= clrs[0] else NORMAL
        return raw, hold

    def step(self, valid: bool, sample: int, ext_fault: bool) -> None:
        """Advance one clock. Mirrors the nonblocking-assignment order in RTL."""
        c = self.cfg
        s = to_s16(sample)
        raw, hold = self._levels(s)
        range_bad = s < to_s16(c.range_min) or s > to_s16(c.range_max)
        step_abs = abs(s - self.prev_raw)
        delta_bad = (c.max_delta != 0) and self.have_prev and not range_bad and step_abs > c.max_delta
        sample_bad = range_bad or delta_bad or ext_fault
        esc_lim = 1 if c.escalate == 0 else c.escalate
        desc_lim = 1 if c.deescalate == 0 else c.deescalate
        timeout_hit = (c.sample_timeout != 0) and (self.since >= c.sample_timeout)

        n = dict(level=self.level, esc=self.esc, desc=self.desc, good=self.good, fault=self.fault,
                 reason=self.reason, prev_raw=self.prev_raw, have_prev=self.have_prev,
                 last=self.last, seen=self.seen)
        n["since"] = 0 if valid else (self.since + 1 if self.since != MAX24 else self.since)
        if timeout_hit and not valid:
            n["fault"] = True
            n["reason"] = n["reason"] | 0b0010
            n["good"] = 0
        if ext_fault:
            n["fault"] = True
            n["reason"] = n["reason"] | 0b0001
            n["good"] = 0
        if valid:
            if not range_bad:
                n["prev_raw"] = s
                n["have_prev"] = True
            if sample_bad:
                n["fault"] = True
                n["reason"] = self.reason | (int(delta_bad) << 3) | (int(range_bad) << 2) | int(ext_fault)
                n["good"] = 0
                n["esc"] = 0
                n["desc"] = 0
            else:
                n["last"] = s
                n["seen"] = True
                if self.fault:
                    if self.good + 1 >= desc_lim:
                        n["fault"] = False
                        n["reason"] = 0
                        n["good"] = 0
                    else:
                        n["good"] = self.good + 1
                if raw > self.level:
                    n["desc"] = 0
                    if raw == CRITICAL or self.esc + 1 >= esc_lim:
                        n["level"] = raw
                        n["esc"] = 0
                    else:
                        n["esc"] = self.esc + 1
                elif hold < self.level and not self.fault:
                    n["esc"] = 0
                    if self.desc + 1 >= desc_lim:
                        n["level"] = hold
                        n["desc"] = 0
                    else:
                        n["desc"] = self.desc + 1
                else:
                    n["esc"] = 0
                    n["desc"] = 0
        for k, v in n.items():
            setattr(self, k, v)

    def outputs(self) -> int:
        """Packed like tb_thermal_monitor output: {seen, last[15:0], reason[3:0], fault, level[1:0]}"""
        return ((int(self.seen) << 23) | ((self.last & 0xFFFF) << 7) | (self.reason << 3)
                | (int(self.fault) << 2) | self.level)


# ---------------------------------------------------------------------------
# 2/3. Policy model and thermal backends (stability studies)
# ---------------------------------------------------------------------------
class ThermalBackend(Protocol):
    name: str

    def step(self, power_by_block: Dict[str, float], dt_s: float) -> float:
        """Advance dt_s seconds with the given block powers [W]; return junction temperature [degC]."""
        ...


@dataclass
class LumpedRCBackend:
    """Single thermal node: C dT/dt = P - (T - T_amb)/R.  NOT ThermalLab."""
    r_th_k_per_w: float
    c_th_j_per_k: float
    t_amb_c: float
    t_c: Optional[float] = None
    name: str = "lumped-RC (illustrative, not ThermalLab)"

    def __post_init__(self):
        if self.t_c is None:
            self.t_c = self.t_amb_c

    def step(self, power_by_block: Dict[str, float], dt_s: float) -> float:
        p = sum(power_by_block.values())
        tau = self.r_th_k_per_w * self.c_th_j_per_k
        t_inf = self.t_amb_c + p * self.r_th_k_per_w
        # exact discretisation of the first-order response
        import math
        a = math.exp(-dt_s / tau)
        self.t_c = t_inf + (self.t_c - t_inf) * a
        return self.t_c


class ThermalLabBackend:
    """
    Adapter for SilicaFlux ThermalLab (Project 09).

    Contract the adapter needs from ThermalLab (to be bound by the integrator):
      * a transient solver object that accepts per-block power maps for the
        SilicaFlux floorplan blocks {"vector", "tensor", "dma", "core_misc"}
      * step(dt_s) advancing the transient solution
      * a probe returning the temperature at the on-die sensor location
    ThermalLab's Python API was not available in the POWERCLOCK build
    environment, so no call into it is guessed here.
    """
    name = "SilicaFlux ThermalLab"

    def __init__(self, solver=None, sensor_probe: str = "ts0"):
        if solver is None:
            raise NotImplementedError(
                "ThermalLab solver not provided. Construct ThermalLabBackend(solver=<ThermalLab transient "
                "solver>) and implement _apply_power/_advance/_probe for its API. Until then studies use "
                "LumpedRCBackend, which is labelled illustrative.")
        self.solver = solver
        self.sensor_probe = sensor_probe

    def step(self, power_by_block: Dict[str, float], dt_s: float) -> float:  # pragma: no cover
        raise NotImplementedError("bind to the ThermalLab API")


@dataclass
class PolicyCfg:
    warn_c: float = 85.0
    warn_hyst_c: float = 3.0
    thr_c: float = 95.0
    thr_hyst_c: float = 5.0
    crit_c: float = 105.0
    crit_hyst_c: float = 10.0
    escalate: int = 2
    deescalate: int = 4
    thr_rate: int = 8          # issue slots / 16
    thr_pause_tns: bool = False
    warn_rate: int = 16
    min_dwell_s: float = 0.010
    sample_period_s: float = 0.001


@dataclass
class PolicyModel:
    """Sample-level model of the POWERCLOCK thermal policy (same level rules as the RTL)."""
    cfg: PolicyCfg
    state: str = "ACTIVE"
    dwell_s: float = 0.0
    entries: int = 0
    mon: ThermalMonitorModel = field(init=False)

    def __post_init__(self):
        c = self.cfg
        q = lambda x: int(round(x * 16))
        self.mon = ThermalMonitorModel(ThermCfg(
            warn_set=q(c.warn_c), warn_hyst=q(c.warn_hyst_c), thr_set=q(c.thr_c), thr_hyst=q(c.thr_hyst_c),
            crit_set=q(c.crit_c), crit_hyst=q(c.crit_hyst_c), sample_timeout=0,
            escalate=c.escalate, deescalate=c.deescalate))

    def sample(self, temp_c: float) -> None:
        self.mon.step(True, int(round(temp_c * 16)) & 0xFFFF, False)
        lvl = self.mon.level
        if self.state == "FAULT":
            return
        if lvl == CRITICAL:
            self.state = "FAULT"
            return
        throttle_cond = lvl >= THROTTLE
        if throttle_cond:
            self.dwell_s = 0.0
            if self.state != "THERMAL_LIMIT":
                self.state = "THERMAL_LIMIT"
                self.entries += 1
        elif self.state == "THERMAL_LIMIT":
            self.dwell_s += self.cfg.sample_period_s
            if self.dwell_s >= self.cfg.min_dwell_s:
                self.state = "ACTIVE"

    def issue_fraction(self) -> Dict[str, float]:
        """Fraction of full command issue rate per unit under the current policy."""
        if self.state == "FAULT":
            return {"vector": 0.0, "tensor": 0.0}
        if self.state == "THERMAL_LIMIT":
            r = self.cfg.thr_rate / 16.0
            return {"vector": r, "tensor": 0.0 if self.cfg.thr_pause_tns else r}
        if self.mon.level == WARN:
            r = self.cfg.warn_rate / 16.0
            return {"vector": r, "tensor": r}
        return {"vector": 1.0, "tensor": 1.0}
