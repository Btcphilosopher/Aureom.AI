#!/usr/bin/env python3
"""
SilicaFlux POWERCLOCK register map — single source of truth.

Generates:
  rtl/sf_pm_regs_pkg.sv      register offsets + field LSB/width constants (RTL uses offsets)
  tb/sf_pm_reg_resets.svh    reset-value table checked against the RTL by tb test `reg_reset`
  fw/sf_pm_regs.h            firmware C header
  docs/register_map.md       human documentation

Access types:
  RO   read-only (writes return PSLVERR)
  RW   read/write
  WO   write-only command (reads return 0); each 1 bit produces a single-cycle pulse
  W1C  read; writing 1 clears the bit
Reset value "volatile" means the value depends on live status or integration
parameters, so the reset check skips it.
"""
from __future__ import annotations
import pathlib, sys

ROOT = pathlib.Path(__file__).resolve().parent.parent

# (name, offset, access, description, [fields]) ; field = (name, lsb, width, reset, desc)
# reset None => volatile/parameter-dependent
REGS = [
    ("ID", 0x00, "RO", "Block identification", [
        ("ID", 0, 32, 0x53461B01, "0x53461B01 = 'S' 'F' project 27 (0x1B), revision 01"),
    ]),
    ("CAP", 0x04, "RO", "Capabilities. Firmware MUST read this before using frequency control.", [
        ("UNIT_CLOCK_GATING", 0, 1, 1, "Vector/tensor unit clock gating implemented"),
        ("FREQ_CTRL", 1, 1, None, "Frequency controller interface present (integration parameter HAS_FREQ_CTRL)"),
        ("VOLTAGE_CTRL", 2, 1, 0, "Voltage regulator control. Always 0: no regulator/PMIC interface exists"),
        ("DVFS", 3, 1, 0, "Dynamic voltage+frequency scaling. Always 0 in this revision"),
        ("POWER_SWITCHING", 4, 1, 0, "Power-off states with retention. Always 0: no power switches exist"),
        ("SENSOR_CALIBRATED", 5, 1, None, "1 = integrator declared the temperature input calibrated (parameter)"),
        ("NUM_OPP", 8, 4, None, "Number of entries in the operating-point table"),
        ("OPP_VALIDATED", 16, 16, None, "Bit i = operating point i is validated (timing-closed) and requestable"),
    ]),
    ("CTRL", 0x08, "RW", "Policy control", [
        ("AUTO_CLK_IDLE_EN", 0, 1, 1, "Allow IDLE -> CLOCK_IDLE automatic unit clock gating"),
        ("THROTTLE_EN", 1, 1, 1, "Enable thermal throttling (CRITICAL -> FAULT is always enabled)"),
        ("SENSOR_FAULT_ACTION", 2, 1, 0, "Sensor fault response: 0 = treat as THROTTLE, 1 = enter FAULT"),
        ("THERMAL_OPP_EN", 3, 1, 0, "In THERMAL_LIMIT, also drop to THROTTLE_CFG.THERMAL_OPP (needs CAP.FREQ_CTRL)"),
        ("CORE_RST_ON_CLEAR", 4, 1, 0, "FAULT_CLEAR also re-asserts the core-domain reset"),
    ]),
    ("STATUS", 0x0C, "RO", "Live status", [
        ("STATE", 0, 3, None, "Architectural state: 0 RESET 1 IDLE 2 ACTIVE 3 CLOCK_IDLE 4 THERMAL_LIMIT 5 FAULT"),
        ("SEQ", 3, 4, None, "Clock/reset sequencer step (see state-machine documentation)"),
        ("THERM_LEVEL", 7, 2, None, "0 NORMAL 1 WARN 2 THROTTLE 3 CRITICAL"),
        ("SENSOR_FAULT", 9, 1, None, "Temperature sensor fault active"),
        ("EMERGENCY_REQ", 10, 1, None, "Emergency shutdown request output (sticky until FAULT_CLEAR)"),
        ("CORE_CLK_EN", 11, 1, None, "Core clock enable as seen by the clock buffer (acknowledged)"),
        ("VEC_CLK_ON", 12, 1, None, "Vector unit clock enabled (acknowledged)"),
        ("TNS_CLK_ON", 13, 1, None, "Tensor unit clock enabled (acknowledged)"),
        ("DRAIN", 14, 1, None, "Drain (no new command issue) requested"),
        ("CORE_ALIVE", 15, 1, None, "Core domain out of reset"),
        ("PLL_LOCKED", 16, 1, None, "Clock source locked (synchronised)"),
        ("THROTTLE_ACTIVE", 17, 1, None, "Thermal issue-rate throttling active"),
        ("STOP_NEW", 18, 1, None, "All new command issue stopped (RESET/FAULT/critical)"),
        ("FAULT_ACTIVE", 19, 1, None, "A FAULT condition is currently present"),
    ]),
    ("CMD", 0x10, "WO", "Commands (write 1 to trigger)", [
        ("FAULT_CLEAR", 0, 1, 0, "Leave FAULT (ignored while any fault condition is still present)"),
        ("WAKE", 1, 1, 0, "Force exit from CLOCK_IDLE / abort clock-idle entry"),
        ("OPP_GO", 2, 1, 0, "Request transition to OPP_REQ.TARGET"),
    ]),
    ("OPP_REQ", 0x14, "RW", "Requested operating point", [
        ("TARGET", 0, 4, None, "Target operating-point index (0 = lowest frequency)"),
    ]),
    ("OPP_STATUS", 0x18, "RO", "Operating point status", [
        ("CUR", 0, 4, None, "Current operating point"),
        ("RESULT", 4, 3, None, "Last result: 0 OK 1 BUSY 2 UNAVAILABLE 3 INVALID 4 NOT_VALIDATED 5 TIMEOUT 6 BAD_STATE"),
        ("BUSY", 8, 1, None, "Firmware-requested transition in progress"),
        ("UNCERTAIN", 9, 1, None, "Transition aborted after request was issued; clock is CUR or the requested OPP"),
        ("FW_OPP", 12, 4, None, "Firmware-selected OPP restored after THERMAL_LIMIT"),
    ]),
    ("IDLE_CFG", 0x1C, "RW", "Idle detection thresholds (always-on clock cycles)", [
        ("IDLE_ENTER", 0, 16, 64, "Continuous idle cycles before ACTIVE -> IDLE"),
        ("CLKIDLE_ENTER", 16, 16, 1024, "Continuous idle cycles before IDLE -> CLOCK_IDLE"),
    ]),
    ("SEQ_TIMEOUT", 0x20, "RW", "Per-step sequencer timeout", [
        ("CYCLES", 0, 24, 0x0FFFFF, "Always-on cycles before a sequencer wait faults (0 = maximum)"),
    ]),
    ("CLK_TIMING", 0x24, "RW", "Clock sequencing timing", [
        ("LOCK_STABLE", 0, 16, 256, "Cycles PLL lock must be continuously high before clock enable"),
        ("CLK_SETTLE", 16, 16, 8, "Cycles after an enable is acknowledged before it is considered stable"),
    ]),
    ("THROTTLE_CFG", 0x28, "RW", "Throttle policy (issue slots per 16 core cycles; written 0 reads back 1, >16 reads 16)", [
        ("WARN_RATE", 0, 5, 16, "Issue rate at WARN"),
        ("WARN_PAUSE_TNS", 5, 1, 0, "Pause new tensor commands at WARN"),
        ("THR_RATE", 8, 5, 8, "Issue rate in THERMAL_LIMIT"),
        ("THR_PAUSE_TNS", 13, 1, 0, "Pause new tensor commands in THERMAL_LIMIT"),
        ("THERMAL_OPP", 16, 4, 0, "Operating point used in THERMAL_LIMIT when CTRL.THERMAL_OPP_EN"),
    ]),
    ("THERM_DWELL", 0x2C, "RW", "THERMAL_LIMIT exit hold-off", [
        ("MIN_DWELL", 0, 24, 1024, "Always-on cycles the throttle condition must stay clear before leaving THERMAL_LIMIT"),
    ]),
    ("TEMP_WARN", 0x30, "RW", "Warning threshold (signed, 1/16 degC per LSB)", [
        ("SET", 0, 16, 1360, "Set threshold (85.0 degC placeholder - replace with product limit)"),
        ("HYST", 16, 16, 48, "Hysteresis: clears below SET-HYST"),
    ]),
    ("TEMP_THROTTLE", 0x34, "RW", "Throttle threshold", [
        ("SET", 0, 16, 1520, "95.0 degC placeholder"),
        ("HYST", 16, 16, 80, "5.0 degC"),
    ]),
    ("TEMP_CRIT", 0x38, "RW", "Critical threshold (SET clamped to integration parameter CRIT_HARD_LIMIT)", [
        ("SET", 0, 16, 1680, "105.0 degC placeholder"),
        ("HYST", 16, 16, 160, "10.0 degC"),
    ]),
    ("TEMP_RANGE", 0x3C, "RW", "Plausible sensor range; samples outside are a sensor fault", [
        ("MIN", 0, 16, 0xFD80, "-40.0 degC"),
        ("MAX", 16, 16, 2400, "150.0 degC"),
    ]),
    ("TEMP_TIMEOUT", 0x40, "RW", "Sensor sample timeout", [
        ("CYCLES", 0, 24, 0xFFFFFF, "Always-on cycles without a valid sample before sensor fault (0 = disabled)"),
    ]),
    ("TEMP_FILTER", 0x44, "RW", "Sample filtering", [
        ("ESCALATE", 0, 4, 2, "Consecutive samples above a WARN/THROTTLE threshold before escalation (CRITICAL is immediate)"),
        ("DEESCALATE", 4, 4, 4, "Consecutive samples below a clear threshold before de-escalation / sensor-fault clear"),
        ("MAX_DELTA", 16, 16, 0, "Max |sample-step| before the sample is rejected as implausible (0 = disabled)"),
    ]),
    ("TEMP_STATUS", 0x48, "RO", "Temperature status", [
        ("LAST", 0, 16, None, "Last accepted sample (signed, 1/16 degC)"),
        ("LEVEL", 16, 2, None, "Thermal level"),
        ("SEEN", 18, 1, None, "At least one sample accepted"),
        ("FAULT", 19, 1, None, "Sensor fault active"),
        ("F_EXT", 20, 1, None, "Fault reason: sensor reported fault"),
        ("F_TIMEOUT", 21, 1, None, "Fault reason: sample timeout"),
        ("F_RANGE", 22, 1, None, "Fault reason: out-of-range sample"),
        ("F_DELTA", 23, 1, None, "Fault reason: implausible step"),
    ]),
    ("IRQ_STATUS", 0x4C, "W1C", "Interrupt status", [
        ("STATE_CHANGE", 0, 1, 0, "Architectural state changed"),
        ("THERM_WARN", 1, 1, 0, "Level rose to >= WARN"),
        ("THERM_THROTTLE", 2, 1, 0, "Level rose to >= THROTTLE"),
        ("THERM_CRIT", 3, 1, 0, "Level rose to CRITICAL"),
        ("SENSOR_FAULT", 4, 1, 0, "Sensor fault asserted"),
        ("HW_ERR", 5, 1, 0, "New hardware error flag"),
        ("FAULT", 6, 1, 0, "Entered FAULT"),
        ("OPP_DONE", 7, 1, 0, "OPP request finished (see OPP_STATUS.RESULT)"),
        ("ACT_WINDOW", 8, 1, 0, "New activity snapshot"),
        ("THERM_CLEAR", 9, 1, 0, "Level returned to NORMAL"),
    ]),
    ("IRQ_ENABLE", 0x50, "RW", "Interrupt enable (same bit layout as IRQ_STATUS)", [
        ("MASK", 0, 10, 0, "1 = interrupt enabled"),
    ]),
    ("FAULT_CAUSE", 0x54, "RO", "Latched FAULT causes, cleared by an accepted FAULT_CLEAR", [
        ("THERM_CRIT", 0, 1, 0, "Critical temperature"),
        ("SENSOR", 1, 1, 0, "Sensor fault with CTRL.SENSOR_FAULT_ACTION=1"),
        ("HW_ERR", 2, 1, 0, "Fatal hardware error flag (HW_ERR_FATAL mask)"),
        ("SEQ_TIMEOUT", 3, 1, 0, "Clock/reset sequencer timeout"),
        ("CLK_LOSS", 4, 1, 0, "Unexpected loss of clock lock"),
    ]),
    ("HW_ERR", 0x58, "W1C", "Sticky hardware error flags from the core domain", [
        ("FLAGS", 0, 8, 0, "Bit i = hw_err_i[i] has been seen"),
    ]),
    ("HW_ERR_FATAL", 0x5C, "RW", "Hardware errors that force FAULT", [
        ("MASK", 0, 8, 0, "1 = error is fatal"),
    ]),
    ("ACT_CFG", 0x60, "RW", "Activity monitor", [
        ("WINDOW_LOG2", 0, 5, 16, "Window = 2^N core cycles (clamped to 4..24)"),
        ("FREEZE", 8, 1, 0, "Hold ACT_* registers for a coherent multi-register read"),
    ]),
    ("ACT_VEC", 0x64, "RO", "Vector busy cycles in last window", [("COUNT", 0, 32, 0, "")]),
    ("ACT_TNS", 0x68, "RO", "Tensor busy cycles in last window", [("COUNT", 0, 32, 0, "")]),
    ("ACT_DMA", 0x6C, "RO", "DMA busy cycles in last window", [("COUNT", 0, 32, 0, "")]),
    ("ACT_IDLE", 0x70, "RO", "Fully idle cycles in last window", [("COUNT", 0, 32, 0, "")]),
    ("ACT_QOCC", 0x74, "RO", "Sum over the window of total queue occupancy (saturating)", [("SUM", 0, 32, 0, "")]),
    ("ACT_STALL", 0x78, "RO", "Cycles a valid command was held back by the power manager", [("COUNT", 0, 32, 0, "")]),
    ("ACT_SEQ", 0x7C, "RO", "Snapshot sequence", [
        ("SEQ", 0, 16, 0, "Window sequence number"),
        ("DROPPED", 16, 16, 0, "Windows overwritten before crossing to the always-on domain"),
    ]),
    ("STATS", 0x80, "RO", "Policy statistics (saturating)", [
        ("THERM_ENTRIES", 0, 16, 0, "Entries into THERMAL_LIMIT"),
        ("FAULT_ENTRIES", 16, 16, 0, "Entries into FAULT"),
    ]),
    ("OPP_INFO_SEL", 0x84, "RW", "Operating-point info selector", [
        ("IDX", 0, 4, 0, "OPP index for OPP_INFO"),
    ]),
    ("OPP_INFO", 0x88, "RO", "Integrator-declared frequency of OPP_INFO_SEL.IDX", [
        ("FREQ_KHZ", 0, 32, None, "kHz from integration parameter OPP_FREQ_KHZ; 0 = not declared"),
    ]),
]


def reg_reset(fields):
    val, volatile = 0, False
    for (_n, lsb, w, rst, _d) in fields:
        if rst is None:
            volatile = True
            continue
        val |= (rst & ((1 << w) - 1)) << lsb
    return val, volatile


def check():
    offs = set()
    for name, off, acc, _d, fields in REGS:
        assert off % 4 == 0 and off < 256, name
        assert off not in offs, f"duplicate offset {name}"
        offs.add(off)
        used = 0
        for fn, lsb, w, rst, _ in fields:
            m = ((1 << w) - 1) << lsb
            assert lsb + w <= 32, f"{name}.{fn}"
            assert not (used & m), f"overlap {name}.{fn}"
            used |= m
            if rst is not None:
                assert 0 <= rst < (1 << w), f"reset out of range {name}.{fn}"
        assert acc in ("RO", "RW", "WO", "W1C"), name


def gen_sv():
    o = ["// GENERATED by tools/gen_regs.py - do not edit", "/* verilator lint_off UNUSEDPARAM */", "package sf_pm_regs_pkg;"]
    for name, off, acc, _d, fields in REGS:
        o.append(f"  localparam logic [7:0] REG_{name} = 8'h{off:02X};  // {acc}")
        for fn, lsb, w, _r, _ in fields:
            o.append(f"  localparam int {name}_{fn}_LSB = {lsb};")
            o.append(f"  localparam int {name}_{fn}_W   = {w};")
    o.append("endpackage")
    o.append("/* verilator lint_on UNUSEDPARAM */")
    return "\n".join(o) + "\n"


def gen_svh():
    n = len(REGS)
    o = ["// GENERATED by tools/gen_regs.py - reset table checked by tb test reg_reset",
         f"localparam int NUM_REG_RST = {n};",
         "logic [7:0]  RST_OFF  [NUM_REG_RST];",
         "logic [31:0] RST_VAL  [NUM_REG_RST];",
         "logic [31:0] RST_MASK [NUM_REG_RST];",
         "bit          RST_WO   [NUM_REG_RST];",
         "string       RST_NAME [NUM_REG_RST];",
         "initial begin"]
    for i, (name, off, acc, _d, fields) in enumerate(REGS):
        val = 0; mask = 0
        for fn, lsb, w, rst, _ in fields:
            if rst is None or acc == "WO":
                continue
            m = ((1 << w) - 1) << lsb
            mask |= m
            val |= (rst << lsb) & m
        o.append(f"  RST_OFF[{i}] = 8'h{off:02X}; RST_VAL[{i}] = 32'h{val:08X}; RST_MASK[{i}] = 32'h{mask:08X}; "
                 f"RST_WO[{i}] = {1 if acc == 'WO' else 0}; RST_NAME[{i}] = \"{name}\";")
    o.append("end")
    return "\n".join(o) + "\n"


def gen_h():
    o = ["/* GENERATED by tools/gen_regs.py - do not edit */",
         "#ifndef SF_PM_REGS_H", "#define SF_PM_REGS_H", "#include <stdint.h>", ""]
    for name, off, acc, desc, fields in REGS:
        o.append(f"/* {name} ({acc}) - {desc} */")
        o.append(f"#define SF_PM_{name}_OFFSET 0x{off:02X}u")
        rv, vol = reg_reset(fields)
        if not vol:
            o.append(f"#define SF_PM_{name}_RESET 0x{rv:08X}u")
        for fn, lsb, w, _r, _d in fields:
            msk = ((1 << w) - 1) << lsb
            o.append(f"#define SF_PM_{name}_{fn}_LSB {lsb}u")
            o.append(f"#define SF_PM_{name}_{fn}_MASK 0x{msk:08X}u")
        o.append("")
    o += ["#define SF_PM_GET(reg, fld, v) (((uint32_t)(v) & SF_PM_##reg##_##fld##_MASK) >> SF_PM_##reg##_##fld##_LSB)",
          "#define SF_PM_SET(reg, fld, v) (((uint32_t)(v) << SF_PM_##reg##_##fld##_LSB) & SF_PM_##reg##_##fld##_MASK)",
          "", "#endif /* SF_PM_REGS_H */"]
    return "\n".join(o) + "\n"


def gen_md():
    o = ["# POWERCLOCK register map", "",
         "Generated by `tools/gen_regs.py` (single source of truth). APB3, 32-bit, byte offsets, "
         "always-on clock domain. Temperatures are signed 16-bit, 1/16 degC per LSB. "
         "Writes to RO registers and accesses to unmapped offsets return PSLVERR.", "",
         "Threshold reset values are **placeholders** chosen only so the block is usable in simulation; "
         "they are not SilicaFlux silicon or package limits and must be replaced from the product thermal specification.", ""]
    o.append("| Offset | Register | Access | Description |")
    o.append("|---|---|---|---|")
    for name, off, acc, desc, _f in REGS:
        o.append(f"| 0x{off:02X} | {name} | {acc} | {desc} |")
    o.append("")
    for name, off, acc, desc, fields in REGS:
        o.append(f"## 0x{off:02X} {name} ({acc})")
        o.append("")
        o.append(desc)
        o.append("")
        o.append("| Bits | Field | Reset | Description |")
        o.append("|---|---|---|---|")
        for fn, lsb, w, rst, d in fields:
            bits = f"{lsb}" if w == 1 else f"{lsb + w - 1}:{lsb}"
            r = "param/live" if rst is None else f"0x{rst:X}"
            o.append(f"| {bits} | {fn} | {r} | {d} |")
        o.append("")
    return "\n".join(o)


def main():
    check()
    (ROOT / "rtl/sf_pm_regs_pkg.sv").write_text(gen_sv())
    (ROOT / "tb/sf_pm_reg_resets.svh").write_text(gen_svh())
    (ROOT / "fw/sf_pm_regs.h").write_text(gen_h())
    (ROOT / "docs/register_map.md").write_text(gen_md())
    print(f"generated {len(REGS)} registers")


if __name__ == "__main__":
    sys.exit(main())
