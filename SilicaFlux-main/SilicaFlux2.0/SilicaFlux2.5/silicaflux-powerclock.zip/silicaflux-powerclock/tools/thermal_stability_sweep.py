#!/usr/bin/env python3
"""
POWERCLOCK thermal-policy stability study (brief section 11).

Couples the POWERCLOCK policy model (same level / hysteresis / escalation
rules as the RTL, see tools/pm_policy_model.py) to a thermal backend and
sweeps policy parameters to find:
  * critical excursions   (temperature reaches CRITICAL -> FAULT)
  * oscillation/chatter   (THERMAL_LIMIT entries per second, limit-cycle amplitude)
  * excessive throttling  (delivered throughput vs the ideal throughput that
                           would hold the die exactly at the throttle threshold)

BACKEND: ThermalLab (Project 09) is the intended backend, but its API was not
available in the build environment, so this study runs on LumpedRCBackend,
a single-node RC model. Every power and thermal number below is an ASSUMED
SCENARIO INPUT chosen only to exercise the control loop. Nothing here is a
SilicaFlux power or temperature prediction.
"""
from __future__ import annotations
import csv, itertools, json, math, pathlib, random, sys
sys.path.insert(0, str(pathlib.Path(__file__).parent))
from pm_policy_model import LumpedRCBackend, PolicyCfg, PolicyModel

ROOT = pathlib.Path(__file__).resolve().parent.parent
OUT = ROOT / "reports/thermal_stability"

# ---------------- ASSUMED scenario (illustrative, not SilicaFlux data) -------------
SCENARIO = {
    "t_amb_c": 45.0,
    "r_th_k_per_w": 0.40,        # junction-to-ambient
    "c_th_j_per_k": 0.05,        # -> tau = 20 ms
    "p_static_w": 30.0,
    "p_vector_full_w": 60.0,     # at 100% vector issue
    "p_tensor_full_w": 120.0,    # at 100% tensor issue
    "sensor_noise_c": 0.3,
    "sim_time_s": 4.0,
    "dt_s": 1e-4,
    "label": "ASSUMED illustrative scenario for control-loop dynamics; not a power estimate",
}


def run(cfg: PolicyCfg, sc=SCENARIO, seed=1, keep_trace=False):
    rng = random.Random(seed)
    th = LumpedRCBackend(sc["r_th_k_per_w"], sc["c_th_j_per_k"], sc["t_amb_c"])
    pol = PolicyModel(cfg)
    steps = int(sc["sim_time_s"] / sc["dt_s"])
    per_sample = max(1, int(round(cfg.sample_period_s / sc["dt_s"])))
    tmax, thr_time, work, t_hist, states = -1e9, 0.0, 0.0, [], []
    trace = []
    for k in range(steps):
        frac = pol.issue_fraction()
        p = {"static": sc["p_static_w"], "vector": sc["p_vector_full_w"] * frac["vector"],
             "tensor": sc["p_tensor_full_w"] * frac["tensor"]}
        t = th.step(p, sc["dt_s"])
        tmax = max(tmax, t)
        if k % per_sample == 0:
            pol.sample(t + rng.gauss(0, sc["sensor_noise_c"]))
        if pol.state == "THERMAL_LIMIT":
            thr_time += sc["dt_s"]
        # delivered work: vector + tensor weighted by their full-rate power share
        work += (frac["vector"] * sc["p_vector_full_w"] + frac["tensor"] * sc["p_tensor_full_w"]) * sc["dt_s"]
        if k > steps // 2:
            t_hist.append(t)
        if keep_trace and k % 10 == 0:
            trace.append((k * sc["dt_s"], t, pol.state, pol.mon.level))
        if pol.state == "FAULT":
            break
    total = sc["sim_time_s"]
    dyn_full = sc["p_vector_full_w"] + sc["p_tensor_full_w"]
    delivered = work / (dyn_full * total)
    # ideal: dynamic power that holds T exactly at the throttle threshold
    p_star = (cfg.thr_c - sc["t_amb_c"]) / sc["r_th_k_per_w"]
    ideal = min(1.0, max(0.0, (p_star - sc["p_static_w"]) / dyn_full))
    amp = (max(t_hist) - min(t_hist)) if t_hist else float("nan")
    return {
        "fault": pol.state == "FAULT", "tmax_c": tmax, "entries_per_s": pol.entries / total,
        "throttled_frac": thr_time / total, "delivered": delivered, "ideal": ideal,
        "throttle_loss": max(0.0, ideal - delivered), "limit_cycle_pp_c": amp,
    }, trace


def classify(r, cfg):
    if r["fault"] or r["tmax_c"] >= cfg.crit_c:
        return "UNSAFE (critical reached)"
    if r["entries_per_s"] > 20:
        return "CHATTER (>20 throttle entries/s)"
    if r["throttle_loss"] > 0.15:
        return "EXCESSIVE THROTTLING (>15% below ideal)"
    return "OK"


def main():
    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    grid = itertools.product([2, 4, 8, 12], [False, True], [1.0, 3.0, 5.0, 8.0], [0.0, 0.005, 0.02, 0.05])
    for rate, pause, hyst, dwell in grid:
        cfg = PolicyCfg(thr_rate=rate, thr_pause_tns=pause, thr_hyst_c=hyst, min_dwell_s=dwell)
        r, _ = run(cfg)
        r.update(thr_rate=rate, pause_tensor=pause, thr_hyst_c=hyst, min_dwell_ms=dwell * 1e3)
        r["class"] = classify(r, cfg)
        rows.append(r)
    keys = ["thr_rate", "pause_tensor", "thr_hyst_c", "min_dwell_ms", "class", "fault", "tmax_c",
            "entries_per_s", "throttled_frac", "delivered", "ideal", "throttle_loss", "limit_cycle_pp_c"]
    with open(OUT / "sweep.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader()
        for r in rows: w.writerow({k: r[k] for k in keys})

    counts = {}
    for r in rows: counts[r["class"]] = counts.get(r["class"], 0) + 1
    ok = [r for r in rows if r["class"] == "OK"]
    best = max(ok, key=lambda r: r["delivered"]) if ok else None

    # representative traces
    reps = {"chatter-prone (hyst 1C, no dwell)": PolicyCfg(thr_rate=8, thr_hyst_c=1.0, min_dwell_s=0.0),
            "default (rate 8, hyst 5C, dwell 20ms)": PolicyCfg(thr_rate=8, thr_hyst_c=5.0, min_dwell_s=0.02),
            "aggressive (rate 2, tensor paused)": PolicyCfg(thr_rate=2, thr_pause_tns=True, thr_hyst_c=5.0, min_dwell_s=0.02)}
    try:
        import matplotlib; matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, axes = plt.subplots(len(reps), 1, figsize=(10, 8), sharex=True)
        for ax, (name, cfg) in zip(axes, reps.items()):
            r, tr = run(cfg, keep_trace=True)
            ts = [p[0] for p in tr]; tc = [p[1] for p in tr]
            ax.plot(ts, tc, lw=0.8, color="#1f3a5f")
            for y, lab, col in [(cfg.warn_c, "WARN", "#c9a227"), (cfg.thr_c, "THROTTLE", "#d9822b"),
                                (cfg.thr_c - cfg.thr_hyst_c, "throttle clear", "#d9822b"), (cfg.crit_c, "CRITICAL", "#a4161a")]:
                ax.axhline(y, ls="--" if "clear" in lab else "-", lw=0.7, color=col)
            ax.set_ylabel("T (degC)")
            ax.set_title(f"{name}: {classify(r, cfg)}, {r['entries_per_s']:.1f} entries/s, delivered {100*r['delivered']:.0f}% (ideal {100*r['ideal']:.0f}%)", fontsize=9)
        axes[-1].set_xlabel("time (s) - lumped-RC backend, ASSUMED scenario (not ThermalLab, not SilicaFlux data)")
        fig.tight_layout(); fig.savefig(OUT / "representative_traces.png", dpi=110)
    except Exception as e:  # plotting is optional
        print("plot skipped:", e)

    L = ["# Thermal policy stability study", "",
         f"**Backend:** {LumpedRCBackend(0.4, 0.05, 45).name}. ThermalLab adapter present (`ThermalLabBackend`) but not bound: ThermalLab's API was not available.",
         f"**Scenario:** {SCENARIO['label']}: T_amb {SCENARIO['t_amb_c']} C, R_th {SCENARIO['r_th_k_per_w']} K/W, "
         f"tau {SCENARIO['r_th_k_per_w']*SCENARIO['c_th_j_per_k']*1e3:.0f} ms, static {SCENARIO['p_static_w']} W, "
         f"vector {SCENARIO['p_vector_full_w']} W, tensor {SCENARIO['p_tensor_full_w']} W at full issue, sensor noise "
         f"{SCENARIO['sensor_noise_c']} C, 1 ms sampling. Unthrottled steady state would be "
         f"{SCENARIO['t_amb_c'] + SCENARIO['r_th_k_per_w']*(SCENARIO['p_static_w']+SCENARIO['p_vector_full_w']+SCENARIO['p_tensor_full_w']):.0f} C (> CRITICAL), so throttling is required.",
         "", "Thresholds: WARN 85 C, THROTTLE 95 C, CRITICAL 105 C (the RTL placeholder defaults). "
         f"{len(rows)} policy configurations swept (throttle rate x tensor pause x hysteresis x min dwell).", "",
         "| Outcome | configurations |", "|---|---|"] + [f"| {k} | {v} |" for k, v in sorted(counts.items())]
    if best:
        L += ["", f"Highest delivered throughput among OK configurations: rate {best['thr_rate']}/16, tensor pause {best['pause_tensor']}, "
              f"hysteresis {best['thr_hyst_c']} C, dwell {best['min_dwell_ms']:.0f} ms -> {100*best['delivered']:.1f}% "
              f"(ideal {100*best['ideal']:.1f}%), {best['entries_per_s']:.1f} entries/s, Tmax {best['tmax_c']:.1f} C."]
    L += ["", "## Findings (computed from the sweep)", ""]
    unsafe = [r for r in rows if r["class"].startswith("UNSAFE")]
    if unsafe:
        combos = sorted({(r["thr_rate"], r["pause_tensor"]) for r in unsafe})
        L.append(f"* **Critical reached** in {len(unsafe)} configurations, for (rate, tensor-paused) = {combos}: the throttled "
                 "power still exceeds what the package removes below CRITICAL, independent of hysteresis/dwell. The throttle "
                 "rate must be chosen from the thermal budget, not tuned by hysteresis.")
    else:
        L.append("* No configuration reached CRITICAL.")
    # limit-cycle behaviour vs hysteresis and dwell, for a safe mid rate
    L += ["", "Throttle entries per second (rate 8/16, tensor not paused) - the bang-bang limit-cycle frequency:", "",
          "| hysteresis \\ min dwell | " + " | ".join(f"{d:.0f} ms" for d in (0, 5, 20, 50)) + " |", "|---|---|---|---|---|"]
    for h in (1.0, 3.0, 5.0, 8.0):
        cells = []
        for d in (0.0, 5.0, 20.0, 50.0):
            m = [r for r in rows if r["thr_rate"] == 8 and not r["pause_tensor"] and r["thr_hyst_c"] == h and abs(r["min_dwell_ms"] - d) < 1e-6]
            cells.append(f"{m[0]['entries_per_s']:.1f}" if m else "-")
        L.append(f"| {h:.0f} C | " + " | ".join(cells) + " |")
    sc = SCENARIO
    t_ss = sc["t_amb_c"] + sc["r_th_k_per_w"] * (sc["p_static_w"] + 0.5 * (sc["p_vector_full_w"] + sc["p_tensor_full_w"]))
    L += ["", "* **Oscillation criterion.** On/off throttling oscillates only if the *throttled* steady-state temperature is "
          "below the throttle clear threshold (SET - HYST); otherwise the policy enters THERMAL_LIMIT once and parks there. "
          f"Here rate 8/16 settles at {t_ss:.1f} C (T_amb + R_th x P_throttled), so:"]
    for h in (1.0, 3.0, 5.0, 8.0):
        clr = 95.0 - h
        m = [r for r in rows if r["thr_rate"] == 8 and not r["pause_tensor"] and r["thr_hyst_c"] == h and r["min_dwell_ms"] == 0.0][0]
        verdict = (f"cycles at {m['entries_per_s']:.1f} entries/s, {m['limit_cycle_pp_c']:.1f} C peak-to-peak"
                   if t_ss < clr else f"parks throttled at ~{t_ss:.0f} C ({m['entries_per_s']:.1f} entries/s, {m['limit_cycle_pp_c']:.1f} C swing)")
        L.append(f"  * hysteresis {h:.0f} C -> clear {clr:.0f} C: {verdict}")
    L += ["* Where a cycle exists, MIN_DWELL lowers its rate (hysteresis 1 C row above). Parking is not instability, but it holds "
          "throughput at the throttled level even though the die is below SET; a second, gentler throttle step between WARN and "
          "THROTTLE would recover that headroom.",
          "* The transition cost decides whether cycling matters: issue-rate changes are free (no clock or reset sequencing), but "
          "THERMAL_OPP frequency changes drain and relock on every entry/exit, so MIN_DWELL must be set well above the relock "
          "time when THERMAL_OPP_EN is used."]
    exc = [r for r in rows if r["class"].startswith("EXCESSIVE")]
    if exc:
        combos = sorted({(r["thr_rate"], r["pause_tensor"]) for r in exc})
        L.append(f"* **Excessive throttling** (>15% below the ideal hold-at-threshold throughput) in {len(exc)} configurations, "
                 f"(rate, tensor-paused) = {combos}: a single throttle step that is much lower than needed wastes performance. "
                 "Multiple throttle steps, or a validated lower OPP, would track the ideal more closely.")
    L += ["* All conclusions concern policy dynamics under the ASSUMED scenario. Re-run with the ThermalLab backend and "
          "SilicaFlux power data (synthesis activity x library power) before choosing production thresholds.",
          "", "Full results: `sweep.csv`; traces: `representative_traces.png`."]
    (OUT / "summary.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))


if __name__ == "__main__":
    main()
