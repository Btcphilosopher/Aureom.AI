// =============================================================================
// tb_pm_top : system-level self-checking testbench for silicaflux_power_manager
// Select a test with +TEST=<name>. Parameter HAS_FREQ selects the build:
//   HAS_FREQ=0 : no frequency controller (CAP.FREQ_CTRL=0)  -> "base" build
//   HAS_FREQ=1 : 4 OPPs, OPP0..2 validated, OPP3 NOT validated -> "freq" build
// Plusargs: +CORE_HALF=<ns> (base build core half-period), +AON_HALF=<ns>
//
// Always-on checkers (any violation fails the test):
//   * scoreboard: every command enqueued completes exactly once with the
//     correct result (detects loss, duplication, corruption under throttling)
//   * no command transfer into a unit whose clock is gated
//   * no core-clock edge while the clock source is unlocked
//   * activity snapshots match an independent testbench count, field by field
//   * RTL SVA (compiled with SF_ASSERT)
// =============================================================================
`timescale 1ns/1ps
module tb_pm_top;
  import sf_pm_pkg::*;
  import sf_pm_regs_pkg::*;

  parameter bit HAS_FREQ = 1'b0;
  localparam int          NUM_OPP = HAS_FREQ ? 4 : 1;
  localparam logic [15:0] OPP_VAL = HAS_FREQ ? 16'h0007 : 16'h0001;
  localparam logic [511:0] OPP_KHZ = HAS_FREQ ?
      {{12{32'd0}}, 32'd333333, 32'd250000, 32'd166667, 32'd100000} : '0;
  localparam int QW = 8;

`include "sf_pm_reg_resets.svh"

  // ---------------------------------------------------------------------------
  // clocks / reset
  // ---------------------------------------------------------------------------
  realtime aon_half = 5.0;
  logic clk_aon = 1'b0;
  logic rst_aon_n = 1'b0;
  always #(aon_half) clk_aon = ~clk_aon;

  logic clk_root, clk_core, rst_core_n, clk_vec, clk_tns;
  logic fc_req, fc_ack, pll_locked;
  logic [3:0] fc_opp;

  sf_clk_src_model #(.NUM_OPP(4)) clksrc (
    .fc_req_i(fc_req), .fc_opp_i(fc_opp), .fc_ack_o(fc_ack),
    .pll_locked_o(pll_locked), .clk_o(clk_root));

  // ---------------------------------------------------------------------------
  // APB / sensor / unit wiring
  // ---------------------------------------------------------------------------
  logic        psel = 0, penable = 0, pwrite = 0;
  logic [7:0]  paddr = 0;
  logic [31:0] pwdata = 0;
  logic [31:0] prdata;
  logic        pready, pslverr, irq;
  logic        emerg;

  logic               tb_temp_valid = 0;
  logic signed [15:0] tb_temp_data = 0;
  logic               tb_temp_fault = 0;
  logic               sm_valid, sm_fault;
  logic signed [15:0] sm_data;
  bit                 use_sensor_model = 0;
  logic               temp_valid, temp_fault;
  logic signed [15:0] temp_data;
  assign temp_valid = use_sensor_model ? sm_valid : tb_temp_valid;
  assign temp_data  = use_sensor_model ? sm_data  : tb_temp_data;
  assign temp_fault = use_sensor_model ? sm_fault : tb_temp_fault;

  logic vec_busy, tns_busy, dma_busy;
  logic [QW-1:0] vec_qocc, tns_qocc, dma_qocc;
  logic [7:0] hw_err = 0;
  logic wake = 0;
  logic vec_up_valid, vec_up_ready, vec_dn_valid, vec_dn_ready;
  logic tns_up_valid, tns_up_ready, tns_dn_valid, tns_dn_ready;
  logic dma_up_valid, dma_up_ready, dma_dn_valid, dma_dn_ready;
  logic [47:0] vec_up_data, tns_up_data, dma_up_data;

  silicaflux_power_manager #(
    .HAS_FREQ_CTRL(HAS_FREQ), .NUM_OPP(NUM_OPP), .OPP_VALIDATED(OPP_VAL),
    .OPP_FREQ_KHZ(OPP_KHZ), .RESET_OPP(0), .SENSOR_CALIBRATED(1'b0),
    .CRIT_HARD_LIMIT(16'sd1840), .QW(QW)
  ) dut (
    .clk_aon_i(clk_aon), .rst_aon_ni(rst_aon_n), .clk_core_root_i(clk_root),
    .test_en_i(1'b0), .clk_core_o(clk_core), .rst_core_no(rst_core_n),
    .clk_vec_o(clk_vec), .clk_tns_o(clk_tns),
    .psel_i(psel), .penable_i(penable), .pwrite_i(pwrite), .paddr_i(paddr),
    .pwdata_i(pwdata), .prdata_o(prdata), .pready_o(pready), .pslverr_o(pslverr),
    .irq_o(irq),
    .temp_valid_i(temp_valid), .temp_data_i(temp_data), .temp_fault_i(temp_fault),
    .emergency_shutdown_req_o(emerg),
    .fc_req_o(fc_req), .fc_opp_o(fc_opp), .fc_ack_i(fc_ack), .pll_locked_i(pll_locked),
    .vec_busy_i(vec_busy), .tns_busy_i(tns_busy), .dma_busy_i(dma_busy),
    .vec_qocc_i(vec_qocc), .tns_qocc_i(tns_qocc), .dma_qocc_i(dma_qocc),
    .hw_err_i(hw_err), .wake_i(wake),
    .vec_up_valid_i(vec_up_valid), .vec_up_ready_o(vec_up_ready),
    .vec_dn_valid_o(vec_dn_valid), .vec_dn_ready_i(vec_dn_ready),
    .tns_up_valid_i(tns_up_valid), .tns_up_ready_o(tns_up_ready),
    .tns_dn_valid_o(tns_dn_valid), .tns_dn_ready_i(tns_dn_ready),
    .dma_up_valid_i(dma_up_valid), .dma_up_ready_o(dma_up_ready),
    .dma_dn_valid_o(dma_dn_valid), .dma_dn_ready_i(dma_dn_ready));

  // units: vector and tensor on their gated clocks, DMA on the core clock
  logic vres_v, tres_v, dres_v;
  logic [15:0] vres_id, tres_id, dres_id;
  logic [31:0] vres, tres, dres;
  tb_unit_model #(.KIND(0), .DEPTH(2), .LAT_MAX(6)) u_vec (
    .clk_i(clk_vec), .pclk_i(clk_core), .rst_ni(rst_core_n), .cmd_valid_i(vec_dn_valid), .cmd_ready_o(vec_dn_ready),
    .cmd_i(vec_up_data), .busy_o(vec_busy), .res_valid_o(vres_v), .res_id_o(vres_id), .res_o(vres));
  tb_unit_model #(.KIND(1), .DEPTH(2), .LAT_MAX(10)) u_tns (
    .clk_i(clk_tns), .pclk_i(clk_core), .rst_ni(rst_core_n), .cmd_valid_i(tns_dn_valid), .cmd_ready_o(tns_dn_ready),
    .cmd_i(tns_up_data), .busy_o(tns_busy), .res_valid_o(tres_v), .res_id_o(tres_id), .res_o(tres));
  tb_unit_model #(.KIND(2), .DEPTH(4), .LAT_MAX(4)) u_dma (
    .clk_i(clk_core), .pclk_i(clk_core), .rst_ni(rst_core_n), .cmd_valid_i(dma_dn_valid), .cmd_ready_o(dma_dn_ready),
    .cmd_i(dma_up_data), .busy_o(dma_busy), .res_valid_o(dres_v), .res_id_o(dres_id), .res_o(dres));

  // explicitly simulated sensor (closed-loop test only)
  sf_temp_sensor_model sensor (
    .clk_i(clk_aon), .rst_ni(rst_aon_n), .vec_busy_i(vec_busy), .tns_busy_i(tns_busy),
    .dma_busy_i(dma_busy), .core_clk_on_i(dut.core_clk_en_ack_s),
    .valid_o(sm_valid), .data_o(sm_data), .fault_o(sm_fault));

  // ---------------------------------------------------------------------------
  // bookkeeping
  // ---------------------------------------------------------------------------
  int errors = 0;
  string test_name;
  `define CHECK(c, m) begin if (!(c)) begin errors++; $display("[%0t] ERROR: %s", $realtime, m); end end
  `define INFO(m)     $display("[%0t] %s", $realtime, m)

  function automatic logic [31:0] expect_res(input int kind, input logic [15:0] id,
                                             input logic [15:0] a, input logic [15:0] b);
    case (kind)
      0:       return {16'h0, a} + {16'h0, b} * 32'd3 ^ {16'h0, id};
      1:       return a * b + {16'h0, id};
      default: return {a, b} ^ {id, id};
    endcase
  endfunction

  // ---------------------------------------------------------------------------
  // command producers (upstream queues in the core domain)
  // ---------------------------------------------------------------------------
  // NOTE: separate queues per channel. Verilator 5.020 corrupts arrays of
  // queues (q[3][$]): pushes land in the wrong element and data reads as 0.
  logic [47:0] qc0[$], qc1[$], qc2[$];   // upstream command queues
  logic [47:0] qp0[$], qp1[$], qp2[$];   // pending pushes from test threads
  function automatic int qsize(input int ch);
    case (ch) 0: return qc0.size(); 1: return qc1.size(); default: return qc2.size(); endcase
  endfunction
  function automatic int psize(input int ch);
    case (ch) 0: return qp0.size(); 1: return qp1.size(); default: return qp2.size(); endcase
  endfunction
  function automatic int queued_total();
    return qc0.size() + qc1.size() + qc2.size() + qp0.size() + qp1.size() + qp2.size();
  endfunction
  logic [31:0] exp0[int], exp1[int], exp2[int];   // per-channel expected results
  function automatic void exp_put(input int ch, input int id, input logic [31:0] v);
    case (ch) 0: exp0[id] = v; 1: exp1[id] = v; default: exp2[id] = v; endcase
  endfunction
  function automatic bit exp_has(input int ch, input int id);
    case (ch) 0: return exp0.exists(id); 1: return exp1.exists(id); default: return exp2.exists(id); endcase
  endfunction
  function automatic logic [31:0] exp_get(input int ch, input int id);
    case (ch) 0: return exp0[id]; 1: return exp1[id]; default: return exp2[id]; endcase
  endfunction
  function automatic void exp_del(input int ch, input int id);
    case (ch) 0: exp0.delete(id); 1: exp1.delete(id); default: exp2.delete(id); endcase
  endfunction
  int          next_id = 1;
  int          n_enq[3] = '{0, 0, 0};
  int          n_done[3] = '{0, 0, 0};

  task automatic enqueue(input int ch, input int n);
    for (int i = 0; i < n; i++) begin
      logic [15:0] id = 16'(next_id);
      logic [15:0] a  = 16'($urandom);
      logic [15:0] b  = 16'($urandom);
      next_id = (next_id % 65000) + 1;
      exp_put(ch, int'(id), expect_res(ch, id, a, b));
      case (ch) 0: qp0.push_back({id, a, b}); 1: qp1.push_back({id, a, b}); default: qp2.push_back({id, a, b}); endcase
      n_enq[ch]++;
    end
  endtask

  function automatic logic [QW-1:0] sat_occ(input int n);
    return (n > 255) ? 8'd255 : QW'(n);
  endfunction

  always @(posedge clk_core) begin
    if (vec_up_valid && vec_up_ready) void'(qc0.pop_front());
    if (tns_up_valid && tns_up_ready) void'(qc1.pop_front());
    if (dma_up_valid && dma_up_ready) void'(qc2.pop_front());
    while (qp0.size() > 0) qc0.push_back(qp0.pop_front());
    while (qp1.size() > 0) qc1.push_back(qp1.pop_front());
    while (qp2.size() > 0) qc2.push_back(qp2.pop_front());
    vec_up_valid <= (qc0.size() > 0);
    tns_up_valid <= (qc1.size() > 0);
    dma_up_valid <= (qc2.size() > 0);
    vec_up_data  <= (qc0.size() > 0) ? qc0[0] : '0;
    tns_up_data  <= (qc1.size() > 0) ? qc1[0] : '0;
    dma_up_data  <= (qc2.size() > 0) ? qc2[0] : '0;
    vec_qocc     <= sat_occ(qc0.size());
    tns_qocc     <= sat_occ(qc1.size());
    dma_qocc     <= sat_occ(qc2.size());
  end
  initial begin
    vec_up_valid = 0; tns_up_valid = 0; dma_up_valid = 0;
    vec_up_data = 0; tns_up_data = 0; dma_up_data = 0;
    vec_qocc = 0; tns_qocc = 0; dma_qocc = 0;
  end

  // ---------------------------------------------------------------------------
  // scoreboard
  // ---------------------------------------------------------------------------
  task automatic score(input int ch, input logic [15:0] id, input logic [31:0] val);
    if (!exp_has(ch, int'(id))) begin
      errors++;
      $display("[%0t] ERROR: unit %0d produced unexpected/duplicate id %0d", $realtime, ch, id);
    end else begin
      if (exp_get(ch, int'(id)) !== val) begin
        errors++;
        $display("[%0t] ERROR: unit %0d id %0d result %h expected %h", $realtime, ch, id, val, exp_get(ch, int'(id)));
      end
      exp_del(ch, int'(id));
      n_done[ch]++;
    end
  endtask
  always @(posedge clk_vec)  if (rst_core_n && vres_v) score(0, vres_id, vres);
  always @(posedge clk_tns)  if (rst_core_n && tres_v) score(1, tres_id, tres);
  always @(posedge clk_core) if (rst_core_n && dres_v) score(2, dres_id, dres);

  function automatic int outstanding();
    return exp0.num() + exp1.num() + exp2.num();
  endfunction

  // ---------------------------------------------------------------------------
  // checker: no transfer into a gated unit (ICG latch decides the next edge)
  // ---------------------------------------------------------------------------
  int xfer_vec = 0, xfer_tns = 0, xfer_dma = 0;
  always @(posedge clk_core) begin
    if (vec_dn_valid && vec_dn_ready) begin
      xfer_vec++;
      `CHECK(dut.u_shim.u_cg_vec.en_latched, "vector command transferred while unit clock gated")
    end
    if (tns_dn_valid && tns_dn_ready) begin
      xfer_tns++;
      `CHECK(dut.u_shim.u_cg_tns.en_latched, "tensor command transferred while unit clock gated")
    end
    if (dma_dn_valid && dma_dn_ready) xfer_dma++;
  end

  // ---------------------------------------------------------------------------
  // checker: the core never sees an edge from an unlocked clock source
  // ---------------------------------------------------------------------------
  bit allow_unlocked_edges = 0;
  int unlocked_edges = 0;
  always @(posedge clk_core) begin
    if (!pll_locked && !allow_unlocked_edges) begin
      unlocked_edges++;
      if (unlocked_edges < 5) begin
        errors++;
        $display("[%0t] ERROR: core clock edge while clock source unlocked", $realtime);
      end
    end
  end

  // ---------------------------------------------------------------------------
  // checker: activity snapshots vs independent count
  // ---------------------------------------------------------------------------
  typedef struct { logic [31:0] v, t, d, q; logic [15:0] seq; } exp_snap_t;
  exp_snap_t exp_snaps[int];
  logic [31:0] cnt_v, cnt_t, cnt_d, cnt_q;
  int snap_match = 0, snap_mismatch = 0, snap_missing = 0;
  always @(posedge clk_core or negedge rst_core_n) begin
    if (!rst_core_n) begin
      cnt_v <= 0; cnt_t <= 0; cnt_d <= 0; cnt_q <= 0;
      exp_snaps.delete();
    end else if (dut.u_shim.u_act.win_restart) begin
      cnt_v <= 0; cnt_t <= 0; cnt_d <= 0; cnt_q <= 0;
    end else if (dut.u_shim.u_act.win_end) begin
      exp_snap_t e;
      e.v = cnt_v + 32'(vec_busy); e.t = cnt_t + 32'(tns_busy); e.d = cnt_d + 32'(dma_busy);
      e.q = cnt_q + 32'(vec_qocc) + 32'(tns_qocc) + 32'(dma_qocc);
      e.seq = dut.u_shim.u_act.seq_q + 16'd1;
      exp_snaps[int'(e.seq)] = e;
      cnt_v <= 0; cnt_t <= 0; cnt_d <= 0; cnt_q <= 0;
    end else begin
      cnt_v <= cnt_v + 32'(vec_busy); cnt_t <= cnt_t + 32'(tns_busy);
      cnt_d <= cnt_d + 32'(dma_busy); cnt_q <= cnt_q + 32'(vec_qocc) + 32'(tns_qocc) + 32'(dma_qocc);
    end
  end
  always @(posedge clk_aon) begin
    if (dut.snap_aon_valid) begin
      int k = int'(dut.snap_aon.seq);
      if (!exp_snaps.exists(k)) snap_missing++;
      else begin
        exp_snap_t e = exp_snaps[k];
        if (e.v == dut.snap_aon.vec_busy && e.t == dut.snap_aon.tns_busy &&
            e.d == dut.snap_aon.dma_busy && e.q == dut.snap_aon.qocc_sum) snap_match++;
        else begin
          snap_mismatch++;
          errors++;
          $display("[%0t] ERROR: snapshot %0d mismatch v %0d/%0d t %0d/%0d d %0d/%0d q %0d/%0d",
                   $realtime, k, dut.snap_aon.vec_busy, e.v, dut.snap_aon.tns_busy, e.t,
                   dut.snap_aon.dma_busy, e.d, dut.snap_aon.qocc_sum, e.q);
        end
        exp_snaps.delete(k);
      end
    end
  end

  // ---------------------------------------------------------------------------
  // state trace
  // ---------------------------------------------------------------------------
  pm_state_e trace[$];
  pm_state_e last_state;
  initial last_state = PM_RESET;
  bit trace_on = 0;
  pm_seq_e last_seq_t = SEQ_NONE;
  always @(posedge clk_aon) if (trace_on && (dut.state != last_state || dut.seq != last_seq_t || dut.u_fsm.opp_done_o)) begin
    $display("[%0t] TRACE state=%s seq=%s cur_opp=%0d fw_opp=%0d res=%s busy=%0d unc=%0d level=%0d thr=%0d",
      $realtime, dut.state.name(), dut.seq.name(), dut.cur_opp, dut.fw_opp, dut.opp_result.name(),
      dut.opp_busy, dut.opp_unc, dut.level, dut.u_fsm.throttle_cond);
    last_seq_t = dut.seq;
  end
  always @(posedge clk_aon) begin
    if (dut.state != last_state) begin
      trace.push_back(dut.state);
      last_state = dut.state;
    end
  end
  function automatic bit trace_has(input pm_state_e s);
    foreach (trace[i]) if (trace[i] == s) return 1;
    return 0;
  endfunction

  // ---------------------------------------------------------------------------
  // APB master
  // ---------------------------------------------------------------------------
  task automatic apb_write(input logic [7:0] a, input logic [31:0] d, input bit exp_err = 0);
    logic err;
    @(posedge clk_aon); #(aon_half / 4);
    psel = 1; pwrite = 1; paddr = a; pwdata = d; penable = 0;
    @(posedge clk_aon); #(aon_half / 4);
    penable = 1;
    #(aon_half / 4);
    err = pslverr;
    @(posedge clk_aon); #(aon_half / 4);
    psel = 0; penable = 0; pwrite = 0;
    if (err !== exp_err) begin
      errors++;
      $display("[%0t] ERROR: APB write %02h pslverr=%0b expected %0b", $realtime, a, err, exp_err);
    end
  endtask

  task automatic apb_read(input logic [7:0] a, output logic [31:0] d, input bit exp_err = 0);
    logic err;
    @(posedge clk_aon); #(aon_half / 4);
    psel = 1; pwrite = 0; paddr = a; penable = 0;
    @(posedge clk_aon); #(aon_half / 4);
    penable = 1;
    #(aon_half / 4);
    d = prdata; err = pslverr;
    @(posedge clk_aon); #(aon_half / 4);
    psel = 0; penable = 0;
    if (err !== exp_err) begin
      errors++;
      $display("[%0t] ERROR: APB read %02h pslverr=%0b expected %0b", $realtime, a, err, exp_err);
    end
  endtask

  function automatic logic [31:0] fld(input logic [31:0] v, input int lsb, input int w);
    return (v >> lsb) & ((32'd1 << w) - 1);
  endfunction

  // ---------------------------------------------------------------------------
  // temperature stimulus: periodic sampler of tb_temp_c
  // ---------------------------------------------------------------------------
  real tb_temp_c = 50.0;
  bit  sampler_en = 0;
  int  sample_period = 20;
  initial begin
    forever begin
      @(posedge clk_aon);
      if (sampler_en && !use_sensor_model) begin
        repeat (sample_period - 1) @(posedge clk_aon);
        #(aon_half / 4);
        tb_temp_valid = 1;
        tb_temp_data  = 16'($rtoi(tb_temp_c * 16.0));
        @(posedge clk_aon); #(aon_half / 4);
        tb_temp_valid = 0;
      end
    end
  end
  task automatic set_temp(input real c);
    tb_temp_c = c;
  endtask
  task automatic samples(input int n);   // wait for n sampler periods
    repeat (n * sample_period + 2) @(posedge clk_aon);
  endtask

  // ---------------------------------------------------------------------------
  // background traffic
  // ---------------------------------------------------------------------------
  bit traffic_en = 0;
  bit traffic_burst = 0;   // top queues up to depth every cycle (saturating load)
  int traffic_mask = 3'b111;
  int traffic_depth = 6;
  initial begin
    forever begin
      @(posedge clk_aon);
      if (traffic_en) begin
        for (int c = 0; c < 3; c++) begin
          if (traffic_burst) begin
            if (traffic_mask[c] && (qsize(c) + psize(c)) < traffic_depth)
              enqueue(c, traffic_depth - (qsize(c) + psize(c)));
          end else if (traffic_mask[c] && (qsize(c) + psize(c)) < traffic_depth && ($urandom_range(0, 3) != 0))
            enqueue(c, 1);
        end
      end
    end
  end

  // core period / always-on period: tests scale absolute counts and waits by it
  real core_ratio = 1.0;
  function automatic int scale_up(input int n);    // more always-on time for a slow core
    return (core_ratio > 1.0) ? int'(real'(n) * core_ratio) : n;
  endfunction
  function automatic int scale_dn(input int n);    // fewer events expected for a slow core
    return (core_ratio > 1.0) ? int'(real'(n) / core_ratio) : n;
  endfunction

  // ---------------------------------------------------------------------------
  // helpers
  // ---------------------------------------------------------------------------
  task automatic wait_aon(input int n);
    repeat (n) @(posedge clk_aon);
  endtask

  task automatic wait_state(input pm_state_e s, input int max_cyc, input string why = "");
    int i = 0;
    while (dut.state != s && i < max_cyc) begin @(posedge clk_aon); i++; end
    if (dut.state != s) begin
      errors++;
      $display("[%0t] ERROR: timeout waiting for state %s (now %s seq %s) %s", $realtime,
               s.name(), dut.state.name(), dut.seq.name(), why);
    end
  endtask

  task automatic wait_cond_seq(input pm_seq_e s, input int max_cyc);
    int i = 0;
    while (dut.seq != s && i < max_cyc) begin @(posedge clk_aon); i++; end
    `CHECK(dut.seq == s, $sformatf("timeout waiting for sequencer step %s", s.name()))
  endtask

  // finish all work: keep clocks on, wait for scoreboard to empty
  task automatic drain_all(input int max_cyc = 200000);
    int i = 0;
    traffic_en = 0;
    while ((outstanding() != 0 || queued_total() != 0) && i < max_cyc) begin
      if (dut.state == PM_CLOCK_IDLE && (i % 64) == 0) apb_write(REG_CMD, 32'h2);
      @(posedge clk_aon); i++;
    end
    `CHECK(outstanding() == 0, $sformatf("%0d commands never completed", outstanding()))
  endtask

  task automatic fast_cfg();
    apb_write(REG_IDLE_CFG,     {16'd64, 16'd16});
    apb_write(REG_CLK_TIMING,   {16'd4, 16'd16});
    apb_write(REG_SEQ_TIMEOUT,  32'd4000);
    apb_write(REG_THERM_DWELL,  32'd200);
    apb_write(REG_TEMP_FILTER,  {16'd0, 8'd0, 4'd2, 4'd1});
    apb_write(REG_TEMP_TIMEOUT, 32'd0);
    apb_write(REG_ACT_CFG,      32'd8);
    apb_write(REG_IRQ_ENABLE,   32'h3FF);
  endtask

  task automatic por();
    rst_aon_n = 0;
    wait_aon(5);
    rst_aon_n = 1;
  endtask

  // measure accepted transfers per core cycle on a channel over n core cycles
  task automatic measure_rate(input int ch, input int ncyc, output real rate);
    int x0, x1;
    x0 = (ch == 0) ? xfer_vec : (ch == 1) ? xfer_tns : xfer_dma;
    repeat (ncyc) @(posedge clk_core);
    x1 = (ch == 0) ? xfer_vec : (ch == 1) ? xfer_tns : xfer_dma;
    rate = real'(x1 - x0) / real'(ncyc);
  endtask

  logic [31:0] rd;
  real r0, r1;

  int edges_vec = 0, edges_tns = 0, edges_core = 0;
  always @(posedge clk_vec)  edges_vec++;
  always @(posedge clk_tns)  edges_tns++;
  always @(posedge clk_core) edges_core++;

  // reset-ordering observation (module scope: outlives any test task)
  realtime t_lock_rise = 0, t_clk_rise = 0, t_rst_rise = 0;
  int core_edges_before_rst = 0;
  always @(posedge pll_locked)             t_lock_rise = $realtime;
  always @(posedge dut.core_clk_en_root)   t_clk_rise  = $realtime;
  always @(posedge rst_core_n)             t_rst_rise  = $realtime;
  always @(posedge clk_core) if (!rst_core_n) core_edges_before_rst++;
  int core_rst_falls = 0;
  always @(negedge rst_core_n) core_rst_falls++;

  // ===========================================================================
  // TESTS
  // ===========================================================================
  task automatic t_reg_reset();
    for (int i = 0; i < NUM_REG_RST; i++) begin
      if (RST_WO[i]) continue;
      apb_read(RST_OFF[i], rd);
      `CHECK((rd & RST_MASK[i]) == RST_VAL[i],
             $sformatf("reset value %s = %08h expected %08h (mask %08h)", RST_NAME[i],
                       rd, RST_VAL[i], RST_MASK[i]))
    end
    apb_read(REG_OPP_REQ, rd);
    `CHECK(rd == 0, "OPP_REQ reset (RESET_OPP)")
    apb_read(REG_CAP, rd);
    `CHECK(fld(rd, CAP_VOLTAGE_CTRL_LSB, 1) == 0, "CAP.VOLTAGE_CTRL must be 0")
    `CHECK(fld(rd, CAP_DVFS_LSB, 1) == 0, "CAP.DVFS must be 0")
    `CHECK(fld(rd, CAP_POWER_SWITCHING_LSB, 1) == 0, "CAP.POWER_SWITCHING must be 0")
    `CHECK(fld(rd, CAP_FREQ_CTRL_LSB, 1) == 32'(HAS_FREQ), "CAP.FREQ_CTRL mismatch")
    `CHECK(fld(rd, CAP_NUM_OPP_LSB, 4) == NUM_OPP, "CAP.NUM_OPP mismatch")
    `CHECK(fld(rd, CAP_OPP_VALIDATED_LSB, 16) == 32'(OPP_VAL), "CAP.OPP_VALIDATED mismatch")
    // RO write and unmapped access -> PSLVERR
    apb_write(REG_STATUS, 32'hFFFF_FFFF, 1);
    apb_write(REG_ID, 32'h0, 1);
    apb_read(8'hFC, rd, 1);
    apb_write(8'hF0, 32'h1, 1);
    // critical threshold can never exceed the hard limit
    apb_write(REG_TEMP_CRIT, {16'd160, 16'h7FFF});
    apb_read(REG_TEMP_CRIT, rd);
    `CHECK(rd[15:0] == 16'd1840, $sformatf("TEMP_CRIT not clamped to hard limit: %0d", $signed(rd[15:0])))
    // throttle rate clamps
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b0, 5'd0, 2'b0, 1'b0, 5'd31});
    apb_read(REG_THROTTLE_CFG, rd);
    `CHECK(rd[4:0] == 5'd16 && rd[12:8] == 5'd1, $sformatf("rate clamp wrong: %08h", rd))
    // read-write registers hold written values
    apb_write(REG_IDLE_CFG, 32'h1234_5678);
    apb_read(REG_IDLE_CFG, rd);
    `CHECK(rd == 32'h1234_5678, "IDLE_CFG readback")
    apb_read(REG_CMD, rd);
    `CHECK(rd == 0, "CMD must read 0")
  endtask

  task automatic t_reset_sequence();
    realtime t_lock, t_clk, t_rst;
    // re-run POR and observe ordering
    clksrc.set_lock(0);
    core_edges_before_rst = 0;
    por();
    `CHECK(dut.state == PM_RESET, "not in RESET after POR")
    `CHECK(dut.core_cfg.stop_new, "stop_new must be asserted in RESET")
    wait_aon(50);
    `CHECK(dut.state == PM_RESET && !rst_core_n, "left RESET without clock lock")
    `CHECK(dut.seq == SEQ_WAIT_LOCK, "should be waiting for lock")
    clksrc.set_lock(1);
    wait_state(PM_IDLE, 3000, "reset sequence");
    t_lock = t_lock_rise; t_clk = t_clk_rise; t_rst = t_rst_rise;
    `CHECK(t_clk > t_lock, "core clock enabled before lock")
    `CHECK(t_rst > t_clk, "core reset released before core clock enabled")
    `CHECK(core_edges_before_rst >= 2, "reset released without clock edges for synchronous release")
    apb_read(REG_STATUS, rd);
    `CHECK(fld(rd, STATUS_CORE_ALIVE_LSB, 1) && fld(rd, STATUS_VEC_CLK_ON_LSB, 1) &&
           fld(rd, STATUS_TNS_CLK_ON_LSB, 1) && fld(rd, STATUS_CORE_CLK_EN_LSB, 1),
           $sformatf("STATUS after reset %08h", rd))
    `CHECK(!fld(rd, STATUS_STOP_NEW_LSB, 1), "stop_new still set after reset")
    // lock timeout during reset -> FAULT(SEQ_TIMEOUT), recoverable
    apb_write(REG_SEQ_TIMEOUT, 32'd300);
    clksrc.set_lock(0);
    rst_aon_n = 0; wait_aon(3); rst_aon_n = 1;
    apb_write(REG_SEQ_TIMEOUT, 32'd300);
    wait_state(PM_FAULT, 2000, "lock never arrives");
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd[FC_SEQ_TIMEOUT], "FAULT_CAUSE.SEQ_TIMEOUT expected")
    clksrc.set_lock(1);
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_IDLE, 3000, "recovery from reset timeout");
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd == 0, "FAULT_CAUSE not cleared")
  endtask

  task automatic t_idle_active();
    apb_write(REG_CTRL, 32'b00010);          // auto clock idle off
    traffic_en = 1;
    wait_state(PM_ACTIVE, 500);
    wait_aon(400);
    `CHECK(dut.state == PM_ACTIVE, "should stay ACTIVE under traffic")
    drain_all();
    wait_state(PM_IDLE, 200, "idle detection");
    wait_aon(2000);
    `CHECK(dut.state == PM_IDLE, "auto clock idle disabled but left IDLE")
    enqueue(0, 3);
    wait_state(PM_ACTIVE, 100, "wake to ACTIVE on work");
    drain_all();
  endtask

  task automatic t_clock_idle();
    int e0, e1, core0, core1;
    for (int it = 0; it < 6; it++) begin
      traffic_en = 1;
      wait_aon(200 + $urandom_range(0, 200));
      drain_all();
      wait_state(PM_CLOCK_IDLE, 1000, "auto clock idle");
      apb_read(REG_STATUS, rd);
      `CHECK(!fld(rd, STATUS_VEC_CLK_ON_LSB, 1) && !fld(rd, STATUS_TNS_CLK_ON_LSB, 1),
             $sformatf("units not gated in CLOCK_IDLE (STATUS %08h)", rd))
      `CHECK(fld(rd, STATUS_DRAIN_LSB, 1), "drain must be held in CLOCK_IDLE")
      e0 = edges_vec + edges_tns; core0 = edges_core;
      wait_aon(300);
      e0 = edges_vec + edges_tns - e0; core0 = edges_core - core0;
      `CHECK(e0 == 0, $sformatf("%0d unit clock edges while gated", e0))
      `CHECK(core0 > scale_dn(200), "core clock must keep running in CLOCK_IDLE")
      // wake via work
      enqueue(it % 2, 4);
      wait_state(PM_ACTIVE, 500, "wake from CLOCK_IDLE");
    end
    drain_all();
    `CHECK(trace_has(PM_CLOCK_IDLE), "never entered CLOCK_IDLE")
  endtask

  task automatic t_clock_idle_abort();
    // run with a SLOW core clock (+CORE_HALF=40) so the drain handshake takes
    // long enough to inject work deterministically during DRAIN
    int aborted = 0, gated = 0;
    for (int it = 0; it < 4; it++) begin
      if (dut.state == PM_CLOCK_IDLE) begin
        apb_write(REG_CMD, 32'h2);
        wait_state(PM_ACTIVE, 4000);
      end
      wait_state(PM_IDLE, 4000);
      while (!(dut.seq == SEQ_DRAIN && dut.u_fsm.kind_q == 3'd2)) @(posedge clk_aon);
      enqueue(1, 2);
      while (dut.seq != SEQ_NONE) @(posedge clk_aon);
      if (dut.state == PM_CLOCK_IDLE) gated++; else aborted++;
      drain_all();
    end
    `INFO($sformatf("clock-idle entry aborted %0d times, completed %0d", aborted, gated));
    `CHECK(aborted >= 1, "abort path (work during DRAIN) never exercised")
    // WAKE command during UNIT_GATE must bring clocks back
    if (dut.state == PM_CLOCK_IDLE) begin apb_write(REG_CMD, 32'h2); wait_state(PM_ACTIVE, 4000); end
    wait_state(PM_IDLE, 4000);
    while (!(dut.seq == SEQ_UNIT_GATE)) @(posedge clk_aon);
    apb_write(REG_CMD, 32'h2);
    wait_state(PM_ACTIVE, 2000, "WAKE during UNIT_GATE");
  endtask

  task automatic t_wake_cmd();
    wait_state(PM_CLOCK_IDLE, 2000);
    apb_write(REG_CMD, 32'h2);
    wait_state(PM_ACTIVE, 500, "WAKE command");
    apb_read(REG_STATUS, rd);
    `CHECK(fld(rd, STATUS_VEC_CLK_ON_LSB, 1), "vector clock not restored by WAKE")
    // auto-gates again after the idle thresholds
    wait_state(PM_CLOCK_IDLE, 3000, "re-gate after wake");
    // external wake_i pin
    wake = 1; wait_aon(20); wake = 0;
    `CHECK(dut.state != PM_CLOCK_IDLE || dut.seq != SEQ_NONE, "wake_i ignored")
    wait_state(PM_ACTIVE, 500, "wake_i");
  endtask

  task automatic t_throttle_rate();
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b0, 5'd4, 2'b0, 1'b0, 5'd16});
    sampler_en = 1; set_temp(60.0);
    traffic_mask = 3'b001; traffic_depth = 32; traffic_burst = 1; traffic_en = 1;
    wait_aon(300);
    measure_rate(0, 2000, r0);
    set_temp(97.0);
    wait_state(PM_THERMAL_LIMIT, 400, "throttle threshold");
    apb_read(REG_STATUS, rd);
    `CHECK(fld(rd, STATUS_THROTTLE_ACTIVE_LSB, 1), "THROTTLE_ACTIVE not set")
    wait_aon(50);
    measure_rate(0, 4000, r1);
    `INFO($sformatf("vector issue rate: normal %.3f, throttled %.3f (limit 4/16 = 0.250)", r0, r1));
    `CHECK(r0 > 0.30, "unthrottled rate unexpectedly low")
    // window quantisation: at most ceil(n*rate/16)+1 transfers in n cycles
    `CHECK(r1 <= 0.25 + 2.0 / 4000.0 && r1 > 0.20, "throttled rate not at 4/16")
    set_temp(70.0);
    wait_state(PM_ACTIVE, 2000, "exit THERMAL_LIMIT");
    measure_rate(0, 2000, r1);
    `CHECK(r1 > 0.30, "rate not restored after THERMAL_LIMIT")
    drain_all();
    apb_read(REG_STATS, rd);
    `CHECK(rd[15:0] == 1, $sformatf("THERM_ENTRIES = %0d expected 1", rd[15:0]))
  endtask

  task automatic t_throttle_pause_tns();
    int t0, t1, v0, v1;
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b1, 5'd16, 2'b0, 1'b0, 5'd16});
    sampler_en = 1; set_temp(60.0);
    traffic_mask = 3'b011; traffic_depth = 16; traffic_en = 1;
    wait_aon(300);
    set_temp(97.0);
    wait_state(PM_THERMAL_LIMIT, 400);
    wait_aon(30);      // config crossing
    t0 = xfer_tns; v0 = xfer_vec;
    wait_aon(1500);
    t1 = xfer_tns; v1 = xfer_vec;
    `CHECK(t1 == t0, $sformatf("%0d tensor commands issued while paused", t1 - t0))
    `CHECK(v1 - v0 > 100, "vector issue should continue while tensor paused")
    `CHECK(tns_qocc > 0, "tensor work should be queued, not dropped")
    set_temp(60.0);
    wait_state(PM_ACTIVE, 2000);
    wait_aon(200);
    `CHECK(xfer_tns > t1, "tensor issue did not resume")
    drain_all();
  endtask

  task automatic t_hysteresis();
    realtime t_clear, t_exit;
    sampler_en = 1; set_temp(60.0);
    traffic_en = 1; traffic_mask = 3'b111;
    apb_write(REG_THERM_DWELL, 32'd600);
    wait_aon(200);
    set_temp(96.0);
    wait_state(PM_THERMAL_LIMIT, 400);
    set_temp(92.0);                  // between clear (90) and set (95)
    samples(20);
    `CHECK(dut.level == TL_THROTTLE, "level dropped inside hysteresis band")
    `CHECK(dut.state == PM_THERMAL_LIMIT, "left THERMAL_LIMIT inside hysteresis band")
    set_temp(89.0);                  // below clear; WARN (85) still holds
    while (dut.level == TL_THROTTLE) @(posedge clk_aon);
    t_clear = $realtime;
    `CHECK(dut.level == TL_WARN, "should de-escalate to WARN")
    wait_state(PM_ACTIVE, 3000);
    t_exit = $realtime;
    `CHECK((t_exit - t_clear) >= 600 * 2 * aon_half, $sformatf("left THERMAL_LIMIT before min dwell (%.0f ns)", t_exit - t_clear))
    // escalate filter: a single high sample must not throttle (ESCALATE=2)
    apb_write(REG_TEMP_FILTER, {16'd0, 8'd0, 4'd2, 4'd2});
    sampler_en = 0; wait_aon(40);
    tb_temp_c = 96.0; sampler_en = 1; samples(1); sampler_en = 0; tb_temp_c = 70.0; wait_aon(5); sampler_en = 1;
    samples(4);
    `CHECK(dut.state != PM_THERMAL_LIMIT && dut.u_fsm.therm_entries_q == 1, "single-sample spike escalated despite ESCALATE=2")
    drain_all();
  endtask

  task automatic t_warn_level();
    // WARN_RATE=3 (0.1875/cycle) is below the unit model's own ceiling (~0.38),
    // so the measured rate is set by the power manager, not by the unit
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b0, 5'd8, 2'b0, 1'b0, 5'd3});
    apb_write(REG_IRQ_STATUS, 32'h3FF);
    sampler_en = 1; set_temp(60.0);
    traffic_mask = 3'b001; traffic_depth = 32; traffic_burst = 1; traffic_en = 1;
    wait_aon(200);
    measure_rate(0, 2000, r0);
    set_temp(87.0);
    while (dut.level != TL_WARN) @(posedge clk_aon);
    wait_aon(40);
    measure_rate(0, 3000, r1);
    `INFO($sformatf("vector rate: NORMAL %.3f, WARN with WARN_RATE=3 %.3f (limit 0.1875)", r0, r1));
    `CHECK(r0 > 0.30, "unthrottled rate unexpectedly low")
    `CHECK(r1 <= 0.1875 + 2.0 / 3000.0 && r1 > 0.16, "WARN rate not applied")
    `CHECK(dut.state == PM_ACTIVE, "WARN must not enter THERMAL_LIMIT")
    apb_read(REG_IRQ_STATUS, rd);
    `CHECK(rd[IRQ_THERM_WARN] && !rd[IRQ_THERM_THROTTLE], $sformatf("IRQ_STATUS %03h", rd))
    `CHECK(irq, "irq_o not asserted")
    set_temp(60.0);
    while (dut.level != TL_NORMAL) @(posedge clk_aon);
    apb_read(REG_IRQ_STATUS, rd);
    `CHECK(rd[IRQ_THERM_CLEAR], "THERM_CLEAR irq missing")
    drain_all();
  endtask

  task automatic t_critical_fault();
    int x0, x1;
    realtime t_hot, t_emerg, t_stop;
    sampler_en = 1; set_temp(60.0);
    traffic_en = 1; traffic_mask = 3'b111; traffic_depth = 12;
    wait_aon(400);
    traffic_en = 0;
    enqueue(0, 200); enqueue(1, 200); enqueue(2, 200);   // deep queues at the moment of the fault
    wait_aon(5);
    set_temp(106.0);
    t_hot = $realtime;
    @(posedge emerg); t_emerg = $realtime;
    `INFO($sformatf("emergency request %.0f ns after hot sample period start", t_emerg - t_hot));
    `CHECK(t_emerg - t_hot < (sample_period + 10) * 2 * aon_half, "emergency request too slow")
    wait_state(PM_FAULT, 200, "critical temperature");
    // stop_new crosses to the core through the config handshake; wait until
    // the core has applied it, then two more core cycles for committed transfers
    while (!dut.u_shim.cfg_q.stop_new) @(posedge clk_core);
    t_stop = $realtime;
    `INFO($sformatf("stop-new effective in core %.0f ns after emergency request (%.1f core cycles)",
                    t_stop - t_emerg, (t_stop - t_emerg) / (2.0 * clksrc.half_ns[0])));
    // a transfer already OFFERED before stop-new is held until the unit accepts
    // it (never withdrawn); that can take many cycles if the unit is full.
    // Count only after every such committed offer has completed.
    while (vec_dn_valid || tns_dn_valid || dma_dn_valid) @(posedge clk_core);
    @(posedge clk_core);
    x0 = xfer_vec + xfer_tns + xfer_dma;
    wait_aon(600);
    x1 = xfer_vec + xfer_tns + xfer_dma;
    `CHECK(x1 == x0, $sformatf("%0d new commands accepted in FAULT", x1 - x0))
    `CHECK(!vec_busy && !tns_busy && !dma_busy, "in-flight work did not complete in FAULT")
    `CHECK(qc0.size() + qc1.size() + qc2.size() > 0, "queued work lost")
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd == 32'h1, $sformatf("FAULT_CAUSE %02h expected THERM_CRIT", rd))
    apb_read(REG_STATUS, rd);
    `CHECK(fld(rd, STATUS_EMERGENCY_REQ_LSB, 1) && fld(rd, STATUS_STOP_NEW_LSB, 1), "STATUS emergency/stop")
    // clear rejected while hot
    apb_write(REG_CMD, 32'h1);
    wait_aon(50);
    `CHECK(dut.state == PM_FAULT, "FAULT_CLEAR accepted while still critical")
    // cool down: still WARN, but below critical clear
    set_temp(88.0);
    while (dut.level == TL_CRITICAL) @(posedge clk_aon);
    `CHECK(emerg, "emergency request must stay asserted until FAULT_CLEAR")
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_RESET, 100);
    `CHECK(!emerg, "emergency request not released by FAULT_CLEAR")
    wait_state(PM_ACTIVE, 3000, "resume after fault");
    drain_all();
    apb_read(REG_STATS, rd);
    `CHECK(rd[31:16] == 1, "FAULT_ENTRIES != 1")
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd == 0, "FAULT_CAUSE not cleared")
  endtask

  task automatic t_core_reset_on_clear();
    int seq0;
    sampler_en = 1; set_temp(60.0);
    apb_write(REG_CTRL, 32'b10011);   // CORE_RST_ON_CLEAR
    traffic_en = 1; wait_aon(300); drain_all();
    set_temp(106.0);
    wait_state(PM_FAULT, 300);
    set_temp(60.0);
    while (dut.level == TL_CRITICAL) @(posedge clk_aon);
    seq0 = core_rst_falls;
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_IDLE, 3000);
    `CHECK(core_rst_falls == seq0 + 1, "core reset not re-asserted by FAULT_CLEAR")
    seq0 = int'(dut.u_regs.snap_q.seq);
    // CDC endpoints recovered: config and snapshots still flow
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b0, 5'd3, 2'b0, 1'b0, 5'd16});
    set_temp(97.0);
    wait_state(PM_THERMAL_LIMIT, 400);
    wait_aon(40);
    `CHECK(dut.u_shim.cfg_q.issue_rate == 5'd3, "core config did not cross after core reset")
    traffic_en = 1; wait_aon(1500);
    `CHECK(int'(dut.u_regs.snap_q.seq) != seq0 || snap_match > 0, "activity snapshots stopped after core reset")
    set_temp(60.0);
    drain_all();
  endtask

  task automatic t_sensor_timeout();
    apb_write(REG_TEMP_TIMEOUT, 32'd500);
    sampler_en = 1; set_temp(60.0);
    traffic_en = 1;
    wait_aon(300);
    sampler_en = 0;
    wait_state(PM_THERMAL_LIMIT, 800, "sensor timeout -> throttle");
    apb_read(REG_TEMP_STATUS, rd);
    `CHECK(fld(rd, TEMP_STATUS_FAULT_LSB, 1) && fld(rd, TEMP_STATUS_F_TIMEOUT_LSB, 1),
           $sformatf("TEMP_STATUS %08h", rd))
    `CHECK(dut.u_shim.cfg_q.issue_rate == 5'd8 || dut.core_cfg.issue_rate == 5'd8, "throttle not applied on sensor fault")
    sampler_en = 1;
    wait_state(PM_ACTIVE, 3000, "recovery after samples resume");
    `CHECK(!dut.sensor_fault, "sensor fault not cleared")
    drain_all();
  endtask

  task automatic t_sensor_fault_action_fault();
    apb_write(REG_CTRL, 32'b00111);     // SENSOR_FAULT_ACTION = fault
    sampler_en = 1; set_temp(60.0);
    traffic_en = 1; wait_aon(200);
    tb_temp_fault = 1;
    wait_state(PM_FAULT, 100, "sensor fault -> FAULT");
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd == 32'h2, $sformatf("FAULT_CAUSE %02h expected SENSOR", rd))
    apb_write(REG_CMD, 32'h1); wait_aon(30);
    `CHECK(dut.state == PM_FAULT, "cleared while sensor faulted")
    tb_temp_fault = 0;
    samples(4);
    `CHECK(!dut.sensor_fault, "sensor fault did not recover")
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_ACTIVE, 3000);
    drain_all();
  endtask

  task automatic t_sensor_range_delta();
    sampler_en = 1; set_temp(60.0);
    traffic_en = 1; wait_aon(200);
    set_temp(200.0);                   // implausible
    samples(2);
    `CHECK(dut.level != TL_CRITICAL, "out-of-range sample was used as a temperature")
    `CHECK(dut.sensor_fault, "out-of-range sample did not flag sensor fault")
    apb_read(REG_TEMP_STATUS, rd);
    `CHECK(fld(rd, TEMP_STATUS_F_RANGE_LSB, 1), "F_RANGE not set")
    `CHECK(dut.state == PM_THERMAL_LIMIT, "sensor fault (action throttle) must throttle")
    set_temp(60.0);
    wait_state(PM_ACTIVE, 3000);
    // implausible step
    apb_write(REG_TEMP_FILTER, {16'd160, 8'd0, 4'd2, 4'd1});    // max step 10 degC
    samples(2);
    set_temp(81.0);                    // +21 degC in one sample
    samples(1);
    `CHECK(dut.sensor_fault, "implausible step not flagged")
    apb_read(REG_TEMP_STATUS, rd);
    `CHECK(fld(rd, TEMP_STATUS_F_DELTA_LSB, 1), "F_DELTA not set")
    samples(4);                        // a genuine step is accepted once it persists
    `CHECK(!dut.sensor_fault, "genuine persistent step never accepted")
    `CHECK($signed(dut.last_temp) == 16'sd1296, "last temperature not updated after recovery")
    set_temp(60.0); samples(3);
    drain_all();
  endtask

  task automatic t_hw_error();
    traffic_en = 1; wait_aon(100);
    @(posedge clk_core); hw_err = 8'h08; @(posedge clk_core); hw_err = 0;
    wait_aon(10);
    apb_read(REG_HW_ERR, rd);
    `CHECK(rd == 32'h08, $sformatf("HW_ERR %02h", rd))
    apb_read(REG_IRQ_STATUS, rd);
    `CHECK(rd[IRQ_HW_ERR], "HW_ERR irq")
    `CHECK(dut.state != PM_FAULT, "non-fatal error caused FAULT")
    apb_write(REG_HW_ERR, 32'h08);
    // the clear crosses always-on -> core -> always-on: poll, bounded
    for (int i = 0; i < 50; i++) begin apb_read(REG_HW_ERR, rd); if (rd == 0) break; end
    `CHECK(rd == 0, "HW_ERR W1C did not clear")
    // fatal
    apb_write(REG_HW_ERR_FATAL, 32'h20);
    @(posedge clk_core); hw_err = 8'h20; @(posedge clk_core); hw_err = 0;
    wait_state(PM_FAULT, 50, "fatal hw error");
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd == 32'h4, "FAULT_CAUSE.HW_ERR")
    apb_write(REG_CMD, 32'h1); wait_aon(20);
    `CHECK(dut.state == PM_FAULT, "cleared while fatal error flag still set")
    apb_write(REG_HW_ERR, 32'h20);
    for (int i = 0; i < 50; i++) begin apb_read(REG_HW_ERR, rd); if (rd == 0) break; end
    wait_aon(5);
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_ACTIVE, 3000);
    drain_all();
  endtask

  task automatic t_inflight_throttle();
    apb_write(REG_THERM_DWELL, 32'd20);
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b1, 5'd3, 2'b0, 1'b1, 5'd9});
    sampler_en = 1; sample_period = 7;
    traffic_en = 1; traffic_mask = 3'b111; traffic_depth = 10;
    for (int i = 0; i < 60; i++) begin
      case ($urandom_range(0, 3))
        0: set_temp(60.0);
        1: set_temp(88.0);
        2: set_temp(97.0);
        3: set_temp(92.0);
      endcase
      wait_aon($urandom_range(20, 300));
      if ($urandom_range(0, 9) == 0) apb_write(REG_CMD, 32'h2);
    end
    set_temp(60.0);
    drain_all();
    `INFO($sformatf("inflight: %0d/%0d/%0d commands, THERMAL_LIMIT entries %0d",
                    n_done[0], n_done[1], n_done[2], dut.u_fsm.therm_entries_q));
    `CHECK(dut.u_fsm.therm_entries_q >= 5, "throttle toggling not exercised")
    `CHECK(n_done[0] > scale_dn(300) && n_done[1] > scale_dn(300) && n_done[2] > scale_dn(300), "too little traffic")
  endtask

  task automatic t_activity_counters();
    logic [31:0] s0, s1;
    int m0, d0, d1, lost;
    traffic_en = 1; traffic_mask = 3'b111;
    // phase 1: 64-cycle windows, every snapshot must cross and match
    apb_write(REG_ACT_CFG, 32'd6);
    wait_aon(scale_up(4000));
    `INFO($sformatf("phase 1: snapshots matched %0d, mismatched %0d, missing %0d", snap_match, snap_mismatch, snap_missing));
    `CHECK(snap_match >= 40, "too few activity snapshots compared")
    apb_read(REG_ACT_VEC, rd);
    `CHECK(rd > 0 && rd <= 64, $sformatf("ACT_VEC %0d outside window", rd))
    apb_read(REG_ACT_SEQ, rd);
    `CHECK(rd[31:16] == 0, "snapshots dropped at a 64-cycle window")
    // phase 2: minimum (16-cycle) window: the CDC round trip can exceed the
    // window, so some snapshots are overwritten. Every one that crosses must
    // still match, and every one that does not must be counted as dropped.
    m0 = snap_match; d0 = int'(rd[31:16]);
    apb_write(REG_ACT_CFG, 32'd4);
    wait_aon(scale_up(3000));
    apb_write(REG_ACT_CFG, 32'd10);       // long window: let the last 16-cycle snapshot cross
    wait_aon(scale_up(200));
    apb_read(REG_ACT_SEQ, rd);
    d1 = int'(rd[31:16]);
    lost = exp_snaps.num();                // generated but never delivered
    `INFO($sformatf("phase 2: matched %0d more, dropped counter +%0d, undelivered %0d", snap_match - m0, d1 - d0, lost));
    `CHECK(snap_match - m0 > 50, "too few 16-cycle snapshots")
    `CHECK(lost == d1 - d0, "dropped-window accounting does not match undelivered snapshots")
    exp_snaps.delete();
    // freeze holds a coherent set
    apb_write(REG_ACT_CFG, 32'd8);
    wait_aon(scale_up(600));
    apb_write(REG_ACT_CFG, 32'h108);
    apb_read(REG_ACT_SEQ, s0);
    wait_aon(scale_up(1000));
    apb_read(REG_ACT_SEQ, s1);
    `CHECK(s0 == s1, "ACT registers changed while frozen")
    apb_write(REG_ACT_CFG, 32'h008);
    wait_aon(scale_up(1000));
    apb_read(REG_ACT_SEQ, s1);
    `CHECK(s0[15:0] != s1[15:0], "ACT registers did not resume after unfreeze")
    drain_all();
  endtask

  task automatic t_dvfs_unavailable();
    int rc0 = clksrc.reconfig_count;
    apb_write(REG_IRQ_STATUS, 32'h3FF);
    for (int t = 0; t < 4; t++) begin
      apb_write(REG_OPP_REQ, t);
      apb_write(REG_CMD, 32'h4);
      wait_aon(5);
      apb_read(REG_OPP_STATUS, rd);
      `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_ERR_UNAVAILABLE,
             $sformatf("OPP %0d result %0d expected UNAVAILABLE", t, fld(rd, OPP_STATUS_RESULT_LSB, 3)))
      `CHECK(fld(rd, OPP_STATUS_CUR_LSB, 4) == 0 && !fld(rd, OPP_STATUS_BUSY_LSB, 1), "OPP state changed")
    end
    apb_read(REG_IRQ_STATUS, rd);
    `CHECK(rd[IRQ_OPP_DONE], "OPP_DONE irq for rejected request")
    `CHECK(clksrc.reconfig_count == rc0 && !fc_req, "frequency request issued with no controller")
    // thermal OPP reduction requested by policy but impossible: still only issue throttling
    apb_write(REG_CTRL, 32'b01011);
    traffic_en = 1;
    sampler_en = 1; set_temp(97.0);
    wait_state(PM_THERMAL_LIMIT, 400);
    wait_aon(200);
    `CHECK(clksrc.reconfig_count == rc0, "thermal OPP attempted without controller")
    `CHECK(dut.u_shim.cfg_q.issue_rate == 5'd8, "issue throttling must still apply")
    set_temp(60.0);
    wait_state(PM_ACTIVE, 3000);
    drain_all();
  endtask

  task automatic t_irq();
    apb_write(REG_IRQ_ENABLE, 32'h0);
    apb_write(REG_IRQ_STATUS, 32'h3FF);
    `CHECK(!irq, "irq with everything masked/cleared")
    enqueue(0, 2);
    wait_state(PM_ACTIVE, 200);
    wait_aon(5);
    apb_read(REG_IRQ_STATUS, rd);
    `CHECK(rd[IRQ_STATE_CHANGE], "STATE_CHANGE status not set")
    `CHECK(!irq, "masked interrupt asserted irq_o")
    apb_write(REG_IRQ_ENABLE, 32'h1);
    wait_aon(2);
    `CHECK(irq, "enabled pending interrupt not asserted")
    apb_write(REG_IRQ_STATUS, 32'h1);
    wait_aon(2);
    `CHECK(!irq || dut.u_regs.irq_stat_q[0], "W1C did not clear")
    drain_all();
  endtask

  bit lock_loss_kick = 0;
  initial forever begin
    wait (lock_loss_kick);
    lock_loss_kick = 0;
    clksrc.lose_lock(800.0);
  end
  task automatic t_lock_loss();
    traffic_en = 1; wait_aon(200); drain_all();
    wait_aon(5);
    allow_unlocked_edges = 1;      // the source glitches before we can react; that is the point
    apb_write(REG_CTRL, 32'b10011);
    lock_loss_kick = 1;
    wait_state(PM_FAULT, 100, "lock loss");
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd == 32'h10, $sformatf("FAULT_CAUSE %02h expected CLK_LOSS", rd))
    wait_aon(10);
    `CHECK(!dut.core_clk_en_ack_s, "core clock not gated after lock loss")
    wait (pll_locked == 1);
    allow_unlocked_edges = 0;
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_IDLE, 3000, "recovery after lock loss");
    traffic_en = 1; wait_aon(500);
    drain_all();
  endtask

  task automatic t_requests_during_transition();
    // FAULT_CLEAR outside FAULT: no effect
    apb_write(REG_CMD, 32'h1);
    wait_aon(10);
    `CHECK(dut.state inside {PM_IDLE, PM_ACTIVE, PM_CLOCK_IDLE}, "FAULT_CLEAR outside FAULT changed state")
    // OPP request while a clock-idle sequence runs
    wait_state(PM_IDLE, 4000);
    while (dut.seq == SEQ_NONE) @(posedge clk_aon);
    apb_write(REG_OPP_REQ, 1);
    apb_write(REG_CMD, 32'h4);
    wait_aon(3);
    apb_read(REG_OPP_STATUS, rd);
    `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) inside {OPP_ERR_BUSY, OPP_ERR_UNAVAILABLE, OPP_ERR_STATE},
           "OPP request during transition not rejected")
    // critical temperature during an un-gate sequence: emergency now, FAULT after
    wait_state(PM_CLOCK_IDLE, 4000);
    sampler_en = 1; sample_period = 3; set_temp(60.0); wait_aon(20);
    enqueue(0, 1);
    while (dut.seq != SEQ_UNIT_UNGATE) @(posedge clk_aon);
    set_temp(110.0);
    @(posedge emerg);
    `CHECK(dut.core_cfg.stop_new || dut.u_fsm.fault_cond, "stop_new not immediate")
    wait_state(PM_FAULT, 300, "FAULT after sequence completes");
    `CHECK(dut.vec_en_req && dut.tns_en_req, "unit clocks must be restored by the completed sequence")
    set_temp(60.0);
    while (dut.level == TL_CRITICAL) @(posedge clk_aon);
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_ACTIVE, 3000);
    drain_all();
  endtask

  task automatic t_closed_loop();
    real tmax = 0.0;
    int throttled = 0, total = 0;
    use_sensor_model = 1;
    sensor.enable = 1;
    sensor.noise_degc = 0.4;
    apb_write(REG_TEMP_WARN,     {16'd48, 16'd1360});   // 85
    apb_write(REG_TEMP_THROTTLE, {16'd64, 16'd1440});   // 90, clear 86
    apb_write(REG_TEMP_CRIT,     {16'd160, 16'd1680});  // 105
    apb_write(REG_THROTTLE_CFG,  {12'd0, 4'd0, 2'b0, 1'b1, 5'd4, 2'b0, 1'b0, 5'd16});
    apb_write(REG_THERM_DWELL,   32'd2000);
    apb_write(REG_TEMP_FILTER,   {16'd0, 8'd0, 4'd3, 4'd2});
    traffic_en = 1; traffic_mask = 3'b111; traffic_depth = 16;
    for (int i = 0; i < 120000; i++) begin
      @(posedge clk_aon);
      if (sensor.temp_c > tmax) tmax = sensor.temp_c;
      total++;
      if (dut.state == PM_THERMAL_LIMIT) throttled++;
    end
    `INFO($sformatf("closed loop (SIMULATED sensor, compressed time): Tmax %.2f C, THERMAL_LIMIT entries %0d, throttled %.1f%% of time",
                    tmax, dut.u_fsm.therm_entries_q, 100.0 * throttled / total));
    `CHECK(tmax < 105.0, "temperature reached the critical threshold under closed-loop throttling")
    `CHECK(dut.u_fsm.therm_entries_q >= 1, "policy never throttled")
    `CHECK(dut.state != PM_FAULT, "closed loop entered FAULT")
    drain_all();
  endtask

  // ---------------- frequency build ----------------
  task automatic opp_go(input int t, input int max_cyc = 20000);
    apb_write(REG_IRQ_STATUS, 32'h080);
    apb_write(REG_OPP_REQ, t);
    apb_write(REG_CMD, 32'h4);
    for (int i = 0; i < max_cyc && !dut.u_regs.irq_stat_q[IRQ_OPP_DONE]; i++) @(posedge clk_aon);
    `CHECK(dut.u_regs.irq_stat_q[IRQ_OPP_DONE], $sformatf("OPP_DONE for target %0d never arrived", t))
  endtask

  task automatic t_opp_change();
    realtime ta, tb;
    int tgts[4] = '{2, 0, 1, 2};
    traffic_en = 1; traffic_mask = 3'b111; traffic_depth = 10;
    wait_aon(300);
    foreach (tgts[i]) begin
      int tgt = tgts[i];
      opp_go(tgt);
      apb_read(REG_OPP_STATUS, rd);
      `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_OK && fld(rd, OPP_STATUS_CUR_LSB, 4) == tgt &&
             fld(rd, OPP_STATUS_FW_OPP_LSB, 4) == tgt, $sformatf("OPP_STATUS %08h after change to %0d", rd, tgt))
      `CHECK(clksrc.cur_opp == tgt, "clock source not at requested OPP")
      @(posedge clk_core); ta = $realtime; @(posedge clk_core); tb = $realtime;
      `CHECK((tb - ta) > 1.99 * clksrc.half_ns[tgt] && (tb - ta) < 2.01 * clksrc.half_ns[tgt],
             $sformatf("core period %.3f ns at OPP %0d", tb - ta, tgt))
      wait_aon(300);
    end
    drain_all();
    `CHECK(unlocked_edges == 0, "core saw edges from an unlocked source")
    apb_write(REG_OPP_INFO_SEL, 2);
    apb_read(REG_OPP_INFO, rd);
    `CHECK(rd == 250000, "OPP_INFO kHz")
  endtask

  task automatic t_opp_invalid();
    int rc0 = clksrc.reconfig_count;
    opp_go(5);
    apb_read(REG_OPP_STATUS, rd);
    `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_ERR_INVALID, "index >= NUM_OPP accepted")
    opp_go(3);
    apb_read(REG_OPP_STATUS, rd);
    `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_ERR_NOT_VALIDATED, "non-validated OPP accepted")
    wait_state(PM_CLOCK_IDLE, 4000);
    opp_go(0);
    apb_read(REG_OPP_STATUS, rd);
    `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_OK, "no-op OPP request failed")
    opp_go(1);
    apb_read(REG_OPP_STATUS, rd);
    `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_ERR_STATE, "real change accepted in CLOCK_IDLE")
    `CHECK(clksrc.reconfig_count == rc0, "rejected/no-op request reached the clock controller")
  endtask

  task automatic t_opp_busy_state();
    traffic_en = 1; wait_aon(200);
    apb_write(REG_IRQ_STATUS, 32'h080);
    apb_write(REG_OPP_REQ, 2);
    apb_write(REG_CMD, 32'h4);
    while (dut.seq != SEQ_WAIT_LOCK) @(posedge clk_aon);
    apb_write(REG_OPP_REQ, 1);
    apb_write(REG_CMD, 32'h4);
    wait_aon(2);
    `CHECK(dut.opp_result == OPP_ERR_BUSY, "second request during change not BUSY")
    `CHECK(dut.opp_busy, "first request lost its busy state")
    while (dut.opp_busy) @(posedge clk_aon);
    `CHECK(dut.opp_result == OPP_OK && dut.cur_opp == 2, "first request did not complete")
    drain_all();
    // CLOCK_IDLE: rejected with BAD_STATE
    wait_state(PM_CLOCK_IDLE, 4000);
    opp_go(1);
    `CHECK(dut.opp_result == OPP_ERR_STATE, "OPP accepted in CLOCK_IDLE")
    // THERMAL_LIMIT: rejected
    traffic_en = 1;
    sampler_en = 1; set_temp(97.0);
    wait_state(PM_THERMAL_LIMIT, 1000);
    opp_go(1);
    `CHECK(dut.opp_result == OPP_ERR_STATE, "OPP accepted in THERMAL_LIMIT")
    set_temp(60.0);
    wait_state(PM_ACTIVE, 3000);
    drain_all();
  endtask

  task automatic t_opp_timeout_ack();
    apb_write(REG_SEQ_TIMEOUT, 32'd500);
    clksrc.never_ack = 1;
    opp_go(1);
    `CHECK(dut.state == PM_FAULT, "ack timeout did not FAULT")
    apb_read(REG_OPP_STATUS, rd);
    `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_ERR_TIMEOUT && fld(rd, OPP_STATUS_UNCERTAIN_LSB, 1),
           $sformatf("OPP_STATUS %08h", rd))
    `CHECK(!fc_req, "fc_req left asserted after timeout")
    apb_read(REG_FAULT_CAUSE, rd);
    `CHECK(rd == 32'h8, "FAULT_CAUSE.SEQ_TIMEOUT")
    clksrc.never_ack = 0;
    clksrc.set_lock(1);
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_IDLE, 4000, "recovery after ack timeout");
    opp_go(1);
    apb_read(REG_OPP_STATUS, rd);
    `CHECK(fld(rd, OPP_STATUS_RESULT_LSB, 3) == OPP_OK && !fld(rd, OPP_STATUS_UNCERTAIN_LSB, 1),
           "successful change must clear UNCERTAIN")
    traffic_en = 1; wait_aon(300); drain_all();
  endtask

  task automatic t_opp_timeout_lock();
    apb_write(REG_SEQ_TIMEOUT, 32'd400);
    clksrc.never_lock = 1;
    opp_go(2);
    `CHECK(dut.state == PM_FAULT, "lock timeout did not FAULT")
    `CHECK(dut.opp_result == OPP_ERR_TIMEOUT, "result not TIMEOUT")
    `CHECK(!dut.core_clk_en_ack_s, "core clock enabled without lock")
    clksrc.never_lock = 0;
    clksrc.set_lock(1);
    apb_write(REG_CMD, 32'h1);
    wait_state(PM_IDLE, 4000);
    traffic_en = 1; wait_aon(300); drain_all();
  endtask

  task automatic t_thermal_opp();
    traffic_en = 1; traffic_mask = 3'b111;
    opp_go(2);
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b0, 5'd8, 2'b0, 1'b0, 5'd16});
    apb_write(REG_CTRL, 32'b01011);       // THERMAL_OPP_EN
    sampler_en = 1; set_temp(60.0); wait_aon(200);
    set_temp(97.0);
    wait_state(PM_THERMAL_LIMIT, 500);
    for (int i = 0; i < 20000 && !(dut.cur_opp == 0 && dut.seq == SEQ_NONE); i++) @(posedge clk_aon);
    `CHECK(clksrc.cur_opp == 0 && dut.cur_opp == 0, "thermal OPP reduction not applied")
    `CHECK(dut.fw_opp == 2, "firmware OPP must be remembered")
    wait_aon(300);
    set_temp(60.0);
    wait_state(PM_ACTIVE, 20000, "exit THERMAL_LIMIT with OPP restore");
    `CHECK(clksrc.cur_opp == 2 && dut.cur_opp == 2, "firmware OPP not restored")
    drain_all();
  endtask

  // ---------------- activity trace for power analysis ----------------
  int phase = 0;   // dumped to VCD: 1 ACTIVE full rate, 2 THERMAL_LIMIT, 3 IDLE (clocks on), 4 CLOCK_IDLE
  task automatic t_power_trace();
    int ph_cyc = 3000;
    apb_write(REG_CTRL, 32'b00010);                       // auto clock-idle off for phases 1-3
    apb_write(REG_THROTTLE_CFG, {12'd0, 4'd0, 2'b0, 1'b1, 5'd4, 2'b0, 1'b0, 5'd16});
    sampler_en = 1; set_temp(60.0);
    traffic_burst = 1; traffic_depth = 16; traffic_mask = 3'b111; traffic_en = 1;
    wait_aon(300);
    phase = 1; wait_aon(ph_cyc);
    set_temp(97.0);
    wait_state(PM_THERMAL_LIMIT, 500);
    wait_aon(50);
    phase = 2; wait_aon(ph_cyc);
    phase = 0;
    set_temp(60.0);
    drain_all();
    wait_state(PM_IDLE, 4000);
    phase = 3; wait_aon(ph_cyc);
    phase = 0;
    apb_write(REG_CTRL, 32'b00011);
    wait_state(PM_CLOCK_IDLE, 4000);
    phase = 4; wait_aon(ph_cyc);
    phase = 0;
    `CHECK(dut.state == PM_CLOCK_IDLE, "power trace: CLOCK_IDLE phase not held")
  endtask

`ifdef SF_TRACE
  initial begin
    string vcd;
    if ($value$plusargs("VCD=%s", vcd)) begin
      $dumpfile(vcd);
      $dumpvars(0, tb_pm_top);
    end
  end
`endif

  // ===========================================================================
  // main
  // ===========================================================================
  initial begin
    realtime ch;
    #1;   // let model initial blocks set defaults before plusargs override them
    if (!$value$plusargs("TEST=%s", test_name)) test_name = "reg_reset";
    if ($test$plusargs("TRACE")) trace_on = 1;
    if ($value$plusargs("AON_HALF=%f", ch)) aon_half = ch;
    if ($value$plusargs("CORE_HALF=%f", ch)) clksrc.half_ns[0] = ch;
    if (HAS_FREQ) begin
      clksrc.half_ns[0] = 5.0; clksrc.half_ns[1] = 3.0; clksrc.half_ns[2] = 2.0; clksrc.half_ns[3] = 1.5;
    end
    core_ratio = clksrc.half_ns[0] / aon_half;
    $display("=== tb_pm_top HAS_FREQ=%0d TEST=%s aon_half=%.2f core_half=%.2f ===", HAS_FREQ, test_name, aon_half, clksrc.half_ns[0]);
    por();
    if (test_name != "reg_reset" && test_name != "reset_sequence") begin
      wait_state(PM_IDLE, 5000, "initial reset");
      fast_cfg();
    end
    case (test_name)
      "reg_reset":                  t_reg_reset();
      "reset_sequence":             t_reset_sequence();
      "idle_active":                t_idle_active();
      "clock_idle":                 t_clock_idle();
      "clock_idle_abort":           t_clock_idle_abort();
      "wake_cmd":                   t_wake_cmd();
      "throttle_rate":              t_throttle_rate();
      "throttle_pause_tns":         t_throttle_pause_tns();
      "hysteresis":                 t_hysteresis();
      "warn_level":                 t_warn_level();
      "critical_fault":             t_critical_fault();
      "core_reset_on_clear":        t_core_reset_on_clear();
      "sensor_timeout":             t_sensor_timeout();
      "sensor_fault_action_fault":  t_sensor_fault_action_fault();
      "sensor_range_delta":         t_sensor_range_delta();
      "hw_error":                   t_hw_error();
      "inflight_throttle":          t_inflight_throttle();
      "activity_counters":          t_activity_counters();
      "dvfs_unavailable":           t_dvfs_unavailable();
      "irq":                        t_irq();
      "lock_loss":                  t_lock_loss();
      "requests_during_transition": t_requests_during_transition();
      "closed_loop":                t_closed_loop();
      "opp_change":                 t_opp_change();
      "opp_invalid":                t_opp_invalid();
      "opp_busy_state":             t_opp_busy_state();
      "opp_timeout_ack":            t_opp_timeout_ack();
      "opp_timeout_lock":           t_opp_timeout_lock();
      "thermal_opp":                t_thermal_opp();
      "power_trace":                t_power_trace();
      default: begin errors++; $display("ERROR: unknown test %s", test_name); end
    endcase
    wait_aon(20);
    `CHECK(outstanding() == 0, $sformatf("%0d commands outstanding at end", outstanding()))
    $display("=== %s: %0d errors, commands vec/tns/dma %0d/%0d/%0d, snapshots ok %0d (missing %0d, pending %0d), state changes %0d ===",
             test_name, errors, n_done[0], n_done[1], n_done[2], snap_match, snap_missing, exp_snaps.num(), trace.size());
    if (errors == 0) $display("TEST PASSED: %s", test_name);
    else             $display("TEST FAILED: %s", test_name);
    $finish;
  end

  // global watchdog
  initial begin
    #(50ms);
    $display("TEST FAILED: %s watchdog", test_name);
    $finish;
  end
endmodule
