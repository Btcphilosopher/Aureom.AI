// =============================================================================
// tb_thermal_monitor : drives sf_thermal_monitor from a stimulus file and
// dumps its outputs every cycle; tools/check_thermal_monitor.py runs the
// Python reference model on the same stimulus and compares cycle by cycle.
//   +CFG=<file>  12 hex words (order: ThermCfg.fields())
//   +STIM=<file> one hex word per cycle: {valid, fault, sample[15:0]}
//   +OUT=<file>  one hex word per cycle: {seen, last[15:0], reason[3:0], fault, level[1:0]}
// =============================================================================
`timescale 1ns/1ps
module tb_thermal_monitor;
  import sf_pm_pkg::*;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  therm_cfg_t cfg;
  logic valid = 0, fault = 0;
  logic signed [15:0] sample = 0;
  therm_level_e level;
  logic sfault, seen;
  logic [3:0] reason;
  logic signed [15:0] last;

  sf_thermal_monitor dut (.clk_i(clk), .rst_ni(rst_n), .cfg_i(cfg),
    .sample_valid_i(valid), .sample_i(sample), .sensor_fault_i(fault),
    .level_o(level), .sensor_fault_o(sfault), .fault_reason_o(reason),
    .last_temp_o(last), .sample_seen_o(seen));

  logic [31:0] cfgw [12];
  logic [17:0] stim [200000];
  string fcfg, fstim, fout;
  int n, fd;

  initial begin
    if (!$value$plusargs("CFG=%s", fcfg) || !$value$plusargs("STIM=%s", fstim) ||
        !$value$plusargs("OUT=%s", fout)) $fatal(1, "need +CFG +STIM +OUT");
    if (!$value$plusargs("N=%d", n)) n = 0;
    $readmemh(fcfg, cfgw);
    $readmemh(fstim, stim);
    cfg.warn_set = cfgw[0][15:0];  cfg.warn_hyst = cfgw[1][15:0];
    cfg.thr_set = cfgw[2][15:0];   cfg.thr_hyst = cfgw[3][15:0];
    cfg.crit_set = cfgw[4][15:0];  cfg.crit_hyst = cfgw[5][15:0];
    cfg.range_min = cfgw[6][15:0]; cfg.range_max = cfgw[7][15:0];
    cfg.max_delta = cfgw[8][15:0]; cfg.sample_timeout = cfgw[9][23:0];
    cfg.escalate = cfgw[10][3:0];  cfg.deescalate = cfgw[11][3:0];
    fd = $fopen(fout, "w");
    #12 rst_n = 1;
    for (int i = 0; i < n; i++) begin
      @(negedge clk);
      {valid, fault, sample} = stim[i];
      @(posedge clk); #1;
      $fwrite(fd, "%06h\n", {seen, last, reason, sfault, level});
    end
    $fclose(fd);
    $finish;
  end
endmodule
