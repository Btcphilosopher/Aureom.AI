// =============================================================================
// Testbench compute-unit stand-in. Runs on the unit's (possibly gated) clock.
// Accepts {id, a, b} commands on a valid/ready channel, holds up to DEPTH
// operations in flight with random latency, then emits {id, result}.
// busy_o = at least one operation in flight (the POWERCLOCK unit contract).
// The result function differs per unit KIND so cross-unit mix-ups are caught.
// =============================================================================
`timescale 1ns/1ps
module tb_unit_model #(
  parameter int KIND    = 0,   // 0 vector, 1 tensor, 2 dma
  parameter int DEPTH   = 2,
  parameter int LAT_MAX = 6
) (
  input  logic        clk_i,       // unit clock (possibly gated)
  input  logic        pclk_i,      // parent (ungated) clock, used only to sample inputs
  input  logic        rst_ni,
  input  logic        cmd_valid_i,
  output logic        cmd_ready_o,
  input  logic [47:0] cmd_i,        // {id[15:0], a[15:0], b[15:0]}
  output logic        busy_o,
  output logic        res_valid_o,
  output logic [15:0] res_id_o,
  output logic [31:0] res_o
);
  typedef struct { logic [15:0] id; logic [31:0] val; int remain; } op_t;
  op_t ops[$];

  function automatic logic [31:0] compute(input logic [15:0] id, input logic [15:0] a, input logic [15:0] b);
    case (KIND)
      0:       return {16'h0, a} + {16'h0, b} * 32'd3 ^ {16'h0, id};   // vector: fused add/scale
      1:       return a * b + {16'h0, id};                              // tensor: MAC
      default: return {a, b} ^ {id, id};                                // dma: move/transform
    endcase
  endfunction

  // ready is registered so every observer samples the same pre-edge value.
  // Inputs are captured on the parent clock's falling edge: Verilator evaluates
  // processes on a derived (gated) clock after the parent clock's NBA updates,
  // so sampling inputs directly at posedge clk_i would see post-edge values.
  // Mid-cycle capture gives exactly the value a real flop samples at the edge.
  logic        v_pre;
  logic [47:0] d_pre;
  always @(negedge pclk_i) begin
    v_pre = cmd_valid_i;
    d_pre = cmd_i;
  end
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ops.delete();
      cmd_ready_o <= 1'b1;
      busy_o      <= 1'b0;
      res_valid_o <= 1'b0;
      res_id_o    <= '0;
      res_o       <= '0;
    end else begin
      res_valid_o <= 1'b0;
      // retire at most one per cycle (oldest finished)
      foreach (ops[i]) if (ops[i].remain > 0) ops[i].remain--;
      if (ops.size() > 0 && ops[0].remain == 0) begin
        res_valid_o <= 1'b1;
        res_id_o    <= ops[0].id;
        res_o       <= ops[0].val;
        void'(ops.pop_front());
      end
      if (v_pre && cmd_ready_o) begin
        op_t o;
        o.id     = d_pre[47:32];
        o.val    = compute(d_pre[47:32], d_pre[31:16], d_pre[15:0]);
        o.remain = $urandom_range(1, LAT_MAX);
        ops.push_back(o);
      end
      busy_o      <= (ops.size() > 0);
      cmd_ready_o <= (ops.size() < DEPTH);
    end
  end
endmodule
