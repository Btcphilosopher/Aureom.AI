#!/bin/bash
# build.sh <name> <HAS_FREQ> [extra verilator args]
set -e
name=$1; hf=$2; shift 2
verilator --binary --timing -j 4 -Wno-fatal -Wno-lint -Wno-style -DSF_ASSERT --assert \
  -Itb -Irtl --top-module tb_pm_top -GHAS_FREQ=$hf "$@" -f rtl/files.f \
  sim/sf_clk_src_model.sv sim/sf_temp_sensor_model.sv tb/tb_unit_model.sv tb/tb_pm_top.sv \
  -Mdir build/$name -o tb_$name
