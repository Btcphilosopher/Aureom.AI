#!/bin/bash
# run_tests.sh <binary> <logdir> <test...> [-- plusargs]
bin=$1; logdir=$2; shift 2
tests=(); extra=()
while [ $# -gt 0 ]; do if [ "$1" == "--" ]; then shift; extra=("$@"); break; fi; tests+=("$1"); shift; done
mkdir -p $logdir; pass=0; fail=0
for t in "${tests[@]}"; do
  timeout 900 $bin +TEST=$t "${extra[@]}" > $logdir/$t.log 2>&1
  if grep -q "TEST PASSED" $logdir/$t.log; then pass=$((pass+1)); echo "PASS $t";
  else fail=$((fail+1)); echo "FAIL $t"; grep -m3 "ERROR" $logdir/$t.log; fi
done
echo "SUMMARY $bin: $pass passed, $fail failed"
