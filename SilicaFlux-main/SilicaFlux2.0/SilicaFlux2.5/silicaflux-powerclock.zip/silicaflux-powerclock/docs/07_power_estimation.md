# 7. Power estimation

POWERCLOCK produces **no wattage figures**. The four categories of estimate in
the brief are distinguished below, with what was and was not done for each.

| Category | Status | Artefact |
|---|---|---|
| Toggle/activity-based (RTL simulation) | **Done** | `reports/activity_analysis.md`, from `tb_pm_top +TEST=power_trace` VCD through `tools/vcd_activity.py` |
| FPGA vendor estimate (Vivado `report_power` + SAIF) | Template only (no Vivado available) | `power/vivado_power.tcl` |
| ASIC library-based (PrimeTime PX / Joules + SAIF + SPEF + .db) | Template only (no library or netlist available) | `power/asic_power.tcl` |
| Measured board/device power | Not possible (no hardware) | - |

## What the activity analysis shows, and does not

The power-trace scenario holds four phases of equal length: ACTIVE at full
rate, THERMAL_LIMIT, IDLE with clocks running, and CLOCK_IDLE. For each phase
it reports:

* clock edges per microsecond in each clock domain (`clk_core`, `clk_vec`, `clk_tns`);
* DUT signal toggles per core cycle, by sub-block;
* unit busy duty cycles.

These are activity factors. They show *that* CLOCK_IDLE stops the unit clock
trees and *how much* throttling reduces unit duty. The vector, tensor and DMA
datapaths are testbench models, so their internal switching, the dominant real
power, is not in the DUT figures. Turning activity into watts requires
capacitance and voltage, which only the vendor and library flows above provide.

## Generic synthesis size

`reports/yosys_stat.txt` gives the Yosys generic-cell statistics for the
power-manager logic itself: 3 ICGs and about 1.9k flops. These are a
complexity indicator, not an area or power result.
