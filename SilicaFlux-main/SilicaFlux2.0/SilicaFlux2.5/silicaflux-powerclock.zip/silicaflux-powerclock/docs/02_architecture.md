# 2. Architecture and integration contract

## Block structure

```
                    always-on domain (clk_aon)                     |  core domain (clk_core, gated root)
 APB3 --> sf_pm_regfile --cfg--> sf_pm_fsm ----------------------- | --> sf_pm_core_shim
 temp --> sf_thermal_monitor --level--^  | controls (2-FF levels)  |       sync, ICGs (vec/tns), issue gate,
                                         | config (handshake) ---- | -->   rate limiter, activity monitor,
 irq <--  event capture <-- status <---- | <-- status (2-FF) ----- | <--   drain-ack, error capture
                                         | <-- snapshot (hshake) - | <--
 fc_req/fc_opp --> clock controller -->  clk_core_root --[sync]-->[ICG]--> clk_core --[ICG]--> clk_vec / clk_tns
```

| File | Role |
|---|---|
| `silicaflux_power_manager.sv` | Top: domains, reset syncs, global core clock gate, CDC instances |
| `sf_pm_fsm.sv` | Architectural states + clock/reset/frequency sequencer |
| `sf_thermal_monitor.sv` | Levels with hysteresis, escalation filter, sensor-fault detection |
| `sf_pm_regfile.sv` | APB3 registers (generated map), IRQ, CRIT hard-limit clamp |
| `sf_pm_core_shim.sv` | Core-side synchronisers, unit ICGs + busy interlock, issue gating |
| `sf_cmd_gate.sv` | Per-channel valid/ready gate that never withdraws an offered transfer |
| `sf_activity_monitor.sv` | Windowed busy/idle/queue/stall counters |
| `sf_cdc_sync_2ff.sv`, `sf_cdc_handshake.sv`, `sf_reset_sync.sv` | CDC/RDC primitives |
| `sf_clock_gate.sv` | The only clock-gating point: BUFGCE / ASIC ICG / sim model |

## Unit contract (what the vector, tensor and DMA blocks must provide)

* **Command channel**: valid/ready; valid held until accepted. The payload does
  not pass through POWERCLOCK, so throttling cannot alter data.
* **busy**: high whenever the unit holds ANY in-flight state, including
  outstanding memory transactions. Drain and gating rely on this definition.
* **Clocking**: vector/tensor run on `clk_vec_o`/`clk_tns_o`; their command and
  status interfaces are synchronous to `clk_core_o` (same root).
* **Queue occupancy** (`*_qocc_i`): commands waiting upstream of the gate.

## Integration parameters

| Parameter | Default | Meaning |
|---|---|---|
| `HAS_FREQ_CTRL` | 0 | A real frequency controller is connected |
| `NUM_OPP` | 1 | Operating-point table size (index 0 = lowest frequency) |
| `OPP_VALIDATED` | 16'h0001 | Bit i set only after OPP i closes timing (all corners, single voltage) |
| `OPP_FREQ_KHZ` | 0 | Declared frequencies, informational (`OPP_INFO`) |
| `RESET_OPP` | 0 | OPP after POR; must be validated |
| `SENSOR_CALIBRATED` | 0 | Reported in `CAP`; set only with a calibrated sensor |
| `CRIT_HARD_LIMIT` | 1840 (115 C) | Firmware can never set CRITICAL above this. **Placeholder** |
| `QW` | 8 | Queue-occupancy width |

## Firmware view

`fw/sf_pm_regs.h` (generated) and `fw/sf_pm_driver.[ch]`. Firmware must read
`CAP` before using frequency control. The driver checks capability, range and
validation before writing hardware, and the hardware repeats every check.
