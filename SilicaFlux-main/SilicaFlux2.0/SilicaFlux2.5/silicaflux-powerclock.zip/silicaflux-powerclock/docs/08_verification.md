# 8. Verification

All results below come from `make regress` and the other `make` targets in this
tree. Logs are in `reports/`.

## Test inventory (`tb/tb_pm_top.sv`)

| Test | Brief item | What it proves |
|---|---|---|
| reg_reset | regs | every register reset value matches the generated map; PSLVERR on RO writes and unmapped offsets; CRIT hard-limit clamp; rate clamps; CAP reports no voltage/DVFS/power switching |
| reset_sequence | reset | no core clock before lock; reset released only after clock enable and >=2 core edges; lock timeout in RESET faults and recovers |
| idle_active | idle detection | ACTIVE under load; IDLE after IDLE_ENTER; no CLOCK_IDLE when auto-gating is disabled |
| clock_idle | clock enables | 6 gate/wake cycles; zero unit-clock edges while gated; core clock keeps running; drain held |
| clock_idle_abort | requests during transitions | work arriving during DRAIN aborts gating; WAKE during UNIT_GATE (slow core, 16x ratio) |
| wake_cmd | clock enables | WAKE register and wake_i pin; automatic re-gating |
| throttle_rate | throttling | measured issue rate = 4/16 under THROTTLE; restored after exit; one THERMAL_LIMIT entry |
| throttle_pause_tns | throttling | zero tensor issues while paused, vector continues, tensor work stays queued |
| hysteresis | hysteresis | no exit inside the band; de-escalation below clear; MIN_DWELL respected; single-sample spike filtered |
| warn_level | recovery from warning | WARN rate applied without THERMAL_LIMIT; WARN and THERM_CLEAR IRQs |
| critical_fault | fault, in-flight data | emergency request; stop-new reaches the core; no new transfers in FAULT while in-flight work completes; queued work kept; FAULT_CLEAR refused while hot; recovery |
| core_reset_on_clear | reset, RDC | core reset re-asserted by FAULT_CLEAR; handshakes still carry config and snapshots afterwards |
| sensor_timeout | sensor failure | missing samples -> fault -> throttle; recovery when samples resume |
| sensor_fault_action_fault | sensor failure | sensor flag -> FAULT; clear refused until sensor healthy |
| sensor_range_delta | sensor failure | out-of-range sample rejected (never treated as critical); implausible step rejected; genuine persistent step accepted |
| hw_error | fault interrupts | sticky error + IRQ; W1C across domains; fatal mask -> FAULT; clear refused while flag set |
| inflight_throttle | in-flight DMA/compute under throttling | 60 random temperature changes and WAKEs under full three-channel load; every result bit-exact |
| activity_counters | monitoring | every snapshot matches an independent count; forced drops at a 16-cycle window are accounted exactly; FREEZE |
| dvfs_unavailable | invalid operating points | every OPP request -> UNAVAILABLE; nothing reaches the clock controller, even from thermal policy |
| irq | fault interrupts | enable mask, W1C |
| lock_loss | clock transitions | lock loss -> FAULT(CLK_LOSS) and core clock gated; recovery |
| requests_during_transition | requests during transitions | FAULT_CLEAR outside FAULT; OPP during a sequence; critical during an ungate sequence (emergency immediate, FAULT after the sequence) |
| closed_loop | thermal | simulated sensor + full load: temperature held below CRITICAL |
| opp_change | DVFS (frequency only) | three OPP changes under load; measured core period matches; no edge from an unlocked (glitching) source |
| opp_invalid | invalid operating points | INVALID, NOT_VALIDATED, no-op OK in CLOCK_IDLE, real change refused there; nothing reaches the controller |
| opp_busy_state | requests during transitions | BUSY during a change; BAD_STATE in CLOCK_IDLE and THERMAL_LIMIT |
| opp_timeout_ack / opp_timeout_lock | clock transitions | controller never acks / never relocks -> TIMEOUT, UNCERTAIN, FAULT, fc_req released; recovery |
| thermal_opp | throttling via OPP | THERMAL_LIMIT lowers to THERMAL_OPP; exit restores the firmware OPP |
| power_trace | power estimation | fixed four-phase scenario for VCD activity analysis |

## Always-on checkers (active in every test)

* **Scoreboard**: every command completes exactly once with a bit-exact result. This catches loss, duplication or corruption.
* **No transfer into a gated unit**: checked using the ICG latch state.
* **No core-clock edge while the clock source is unlocked.** The clock model generates runt pulses while unlocked.
* **Activity snapshots**: checked field-by-field against an independent testbench count.
* **RTL assertions (SVA)**:
  * the frequency-controller handshake;
  * no core clock while a frequency request is outstanding;
  * unit gating only while drained;
  * legal states;
  * no frequency request without a controller;
  * no new command transfers while blocked;
  * the valid/ready protocol on both sides of every gate.

## Other verification

| Check | Result |
|---|---|
| Thermal monitor vs Python reference (40 random configs x 6000 cycles) | see reports/thermal_golden.txt |
| Mutation check (hysteresis removed from reference) | see reports/thermal_golden_mutation.txt |
| Verilator `-Wall` lint, both builds | clean |
| Yosys generic synthesis | passes; 3 ICGs; **0 latches** (asserted); no-target synthesis fails as designed |
| Firmware driver host test (`-Werror -pedantic`) | see reports/firmware_driver_test.txt |

## Defects found by testing during this build

| Found by | Defect | Fix |
|---|---|---|
| opp_timeout_ack | After FAULT recovery the saturated idle counter made the block gate units the moment it reached IDLE; the next firmware request was rejected BUSY | Idle timer restarts in RESET/FAULT/CLOCK_IDLE and during sequences |
| opp_invalid | A request for the current OPP was refused BAD_STATE in CLOCK_IDLE | No-op requests succeed in any operational state |
| activity checker (0 snapshots) | A new window length only took effect at the next boundary (up to 2^24 cycles) | Window restarts immediately; the partial window is discarded (documented) |
| Yosys portability | Named struct patterns, multi-dimensional packed arrays, `return`, `inside`, `$bits(type)` unsupported by Yosys 0.33 | Rewritten in portable forms; `import` handled by a mechanical prep step (`tools/yosys_prep.py`) |

Simulator defects, not RTL defects, are recorded in docs/04 (Verilator arrays
of queues; derived-clock ordering). Several testbench expectations were also
corrected when the clock-ratio sweeps showed they assumed equal clock rates:

* the producer could not saturate a fast core;
* fixed waits were shorter than the slow core's CDC latency;
* rate tolerances did not allow for window quantisation;
* the stop-new check counted a legitimately held, committed transfer.

## Known limitations

* No structural CDC signoff tool, no gate-level simulation, no STA, and no FPGA or ASIC power runs: none of these tools was available.
* The SilicaFlux repository was not inspected (docs/01). Unit contracts are assumptions to confirm.
* The unit models are testbench stand-ins, not TENSORCORE 02 or the real vector unit.

## Results (final RTL)

| Regression run | passed | failed |
|---|---|---|
| base build | 22 | 0 |
| freq build: frequency tests | 6 | 0 |
| freq build: base suite | 21 | 0 |
| CDC random delay, core 3ns / aon 10ns | 16 | 0 |
| CDC random delay, core 46ns / aon 10ns | 16 | 0 |
| CDC random delay, core 6.2ns / aon 14.6ns | 16 | 0 |
| CDC random delay, core 160ns: clock-idle abort | 1 | 0 |
| CDC random delay, freq build | 9 | 0 |
| **Total** | **107** | **0** |

Power-trace scenario: PASSED; analysis in `reports/activity_analysis.md`.

* Thermal golden check: 40 random configurations x 6000 cycles, 0 mismatching runs
  * coverage (cycles per level): NORMAL 68467 (28.5%), WARN 26693 (11.1%), THROTTLE 29877 (12.4%), CRITICAL 114963 (47.9%), sensor-fault cycles 79389
* Mutation check: 10 random configurations x 6000 cycles, 9 mismatching runs (mismatches expected and detected)
* Firmware: DRIVER TEST PASSED: 0 failures
* Measured stop-new latency (emergency request -> core refuses new work): 35-242 ns, i.e. 5.3-11.5 core cycles, across all clock ratios.
* Yosys: 3 ICG instances, 0 latches, ~1.9k flops (generic cells; `reports/yosys_stat.txt`).
