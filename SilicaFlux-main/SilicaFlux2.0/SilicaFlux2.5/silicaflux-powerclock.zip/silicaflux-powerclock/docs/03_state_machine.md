# 3. State machine

Two layers: the **architectural state** (`STATUS.STATE`) and the **sequencer
step** (`STATUS.SEQ`). Every sequencer wait is on an *acknowledged* condition
(never a bare delay) and has a per-step timeout (`SEQ_TIMEOUT`) that faults.

## Architectural states

| State | Meaning | Clocks | New work |
|---|---|---|---|
| RESET | POR, or recovery after FAULT_CLEAR; runs the reset sequence | sequencing | stopped |
| IDLE | No work for `IDLE_ENTER` cycles | on | allowed |
| ACTIVE | Work present | on | allowed (rate per thermal level) |
| CLOCK_IDLE | No work for `CLKIDLE_ENTER` cycles; vector + tensor clocks gated | unit clocks off | drained (held) |
| THERMAL_LIMIT | Throttle condition, or within `MIN_DWELL` of it clearing | on | `THR_RATE`, optional tensor pause, optional lower OPP |
| FAULT | Critical temperature, fatal error, sensor fault (if configured), sequencer timeout, clock loss | unchanged (core gated on clock loss) | stopped |

There are no power-off states: no power switches or retention exist.

## Transitions (evaluated when no sequence is running, in priority order)

| From | Condition | To / action |
|---|---|---|
| any operational | lock lost while lock is required | FAULT immediately (aborts any sequence), core clock gated |
| IDLE/ACTIVE/CLOCK_IDLE/THERMAL_LIMIT | CRITICAL, fatal HW error, or sensor fault with `SENSOR_FAULT_ACTION=1` | FAULT (causes latched) |
| CLOCK_IDLE | pending work, `WAKE` cmd or `wake_i` | sequence K_UNGATE -> ACTIVE (or THERMAL_LIMIT if throttling) |
| IDLE/ACTIVE | throttle condition | THERMAL_LIMIT |
| THERMAL_LIMIT | `THERMAL_OPP_EN` and a lower validated thermal OPP | sequence K_FREQ to THERMAL_OPP |
| THERMAL_LIMIT | throttle clear for `MIN_DWELL` | restore firmware OPP if changed (K_FREQ), then ACTIVE |
| IDLE/ACTIVE | firmware `OPP_GO` to a different validated OPP | sequence K_FREQ |
| ACTIVE | idle `IDLE_ENTER` cycles | IDLE |
| IDLE | work | ACTIVE |
| IDLE | idle `CLKIDLE_ENTER` cycles and `AUTO_CLK_IDLE_EN` | sequence K_GATE -> CLOCK_IDLE |
| FAULT | `FAULT_CLEAR` and no fault condition present | RESET (core reset re-asserted if `CORE_RST_ON_CLEAR`) |

In CLOCK_IDLE, heat alone does not change the architectural state: the units
are already stopped. The throttle configuration is still applied, so a wake
goes to THERMAL_LIMIT. CRITICAL still goes to FAULT.

The idle timer measures continuous idle time **since entering an operational
state**. It restarts in RESET, FAULT and CLOCK_IDLE and during any sequence,
so recovery never gates the units immediately.

## Sequences

| Kind | Steps |
|---|---|
| K_RESET | WAIT_LOCK (locked for `LOCK_STABLE`) -> CORE_UNGATE (ack + `CLK_SETTLE`) -> [RST_RELEASE (core alive)] -> UNIT_UNGATE -> UNDRAIN |
| K_GATE | DRAIN (drain-ack) -> UNIT_GATE (enable acks low); aborts to UNDRAIN if work arrived during DRAIN |
| K_UNGATE | UNIT_UNGATE -> UNDRAIN |
| K_FREQ | DRAIN -> CORE_GATE -> FC_REQ (ack high) -> FC_REL (ack low) -> WAIT_LOCK -> CORE_UNGATE -> UNDRAIN |

**Drain-ack**: the core reports `drain_ack = drain seen in the core AND no unit
busy AND no transfer offered`. A stale "quiescent" from before the drain
arrived can therefore never be mistaken for drained. Simulation demonstrated
this: with a slow core, a command slipped into a unit before the drain crossed
over, and the sequencer waited for it to complete before gating.

## Protective actions do not wait for sequences

`stop_new` (no new commands on any channel) and the emergency shutdown request
are derived from the thermal/fault conditions every cycle. The *architectural*
move to FAULT happens at the next sequencer-idle point (each sequence is
timeout-bounded); clock-lock loss aborts sequences immediately.

## OPP request results (`OPP_STATUS.RESULT`)

OK, BUSY (sequence running), UNAVAILABLE (`CAP.FREQ_CTRL=0`), INVALID (index >=
NUM_OPP), NOT_VALIDATED, TIMEOUT (sets `UNCERTAIN`: the clock is either the old
or the requested OPP, both validated), BAD_STATE (CLOCK_IDLE, THERMAL_LIMIT,
RESET, FAULT). A request for the current OPP is a successful no-op in any
operational state.
