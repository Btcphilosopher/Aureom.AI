# 6. DVFS status: unavailable

**SilicaFlux-HPC has no voltage-control interface that POWERCLOCK could drive.**
For that reason:

* `CAP.VOLTAGE_CTRL` and `CAP.DVFS` are hard-wired to 0.
* The block has no voltage port.
* An assertion (`a_no_fc_without_ctrl`) checks that no frequency request leaves the block without a declared controller.

What *is* implemented:

* Clock-enable management: the global core gate and the unit gates.
* Frequency-only operating-point changes, available **only** when:
  * the integrator sets `HAS_FREQ_CTRL=1`; and
  * the target OPP is marked in `OPP_VALIDATED`.

All validated OPPs must close timing at the single supply voltage.

## Frequency controller contract (when `HAS_FREQ_CTRL=1`)

1. POWERCLOCK drains issue, waits for drain-ack, then gates the core clock and waits for the gate acknowledge.
2. It raises `fc_req_o` with `fc_opp_o` already stable.
3. The controller drives `pll_locked_i` low (if relock is needed) **before** raising `fc_ack_i`.
4. POWERCLOCK drops `fc_req_o`. The controller drops `fc_ack_i`.
5. POWERCLOCK waits for `pll_locked_i` to be high continuously for `LOCK_STABLE` cycles.
6. It ungates and waits for the acknowledge plus `CLK_SETTLE`, then releases drain.

Every wait has a timeout. A timeout after the request was issued sets `OPP_STATUS.UNCERTAIN` and FAULT. Recovery goes through RESET, which re-waits for lock.

The clock-source simulation model drives runt pulses while unlocked. The testbench verifies that the core never sees an edge from an unlocked source.

## What a real DVFS implementation would additionally need

This must not be added until the hardware exists. Each item maps to the brief's requirements:

| # | Requirement | Needed |
|---|---|---|
| 1 | Validated operating point | (V, F) pairs characterised and timing-closed per corner; table entries carry both |
| 2 | Voltage-controller availability | A PMIC/regulator interface (e.g. PMBus/AVS/SVID or a dedicated handshake) and its presence bit |
| 3 | Frequency-controller availability | As above (exists as an interface here) |
| 4 | Safe transition order | Raise V, then F; lower F, then V. Never run F above what the present V supports |
| 5 | Clock stability | Existing lock-stable + settle handshake |
| 6 | Regulator settling | Regulator power-good / settled acknowledgement with timeout, plus slew-time allowance |
| 7 | Status acknowledgement | Per-step acknowledgements as in the existing sequencer, with UNCERTAIN semantics extended to voltage |

The sequencer architecture accommodates this as two extra steps: VREG_REQ and VREG_SETTLE, before or after the frequency steps depending on direction. They were deliberately **not** implemented. Code paths that cannot be exercised against real hardware would be an untested claim.
