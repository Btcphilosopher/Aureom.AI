# 5. Thermal monitoring and throttling

## Sensor input

* Format: signed 16-bit, 1/16 degC per LSB, with a `temp_valid` strobe and a sensor `temp_fault` flag, synchronous to `clk_aon`.
* A sensor in another domain must cross through `sf_cdc_handshake`.
* The input is assumed to be **calibrated**. `CAP.SENSOR_CALIBRATED` reports what the integrator declared; the default is 0, because no calibrated SilicaFlux sensor was confirmed.
* `sim/sf_temp_sensor_model.sv` is an **explicitly simulated** sensor: a lumped thermal node with compressed time and assumed unitless power. It is used only in simulation.

## Levels, hysteresis, filtering

* **Thresholds.** NORMAL < WARN < THROTTLE < CRITICAL, each with its own SET and HYST. A level clears below SET - HYST.
* **Escalation.**
  * CRITICAL escalates on a single sample.
  * WARN and THROTTLE need `ESCALATE` consecutive samples, which rejects single-sample spikes (tested).
* **De-escalation** needs `DEESCALATE` consecutive samples below the clear threshold.
* **Hard limit.** `CRIT_HARD_LIMIT` is an integration parameter; firmware writes above it are clamped (tested).
* **Placeholder thresholds.** The reset thresholds (85/95/105 C) and hard limit (115 C) are placeholders. They are not SilicaFlux silicon or package limits.

## Sensor fault detection

| Cause | Detection | Effect |
|---|---|---|
| Sensor flag | `temp_fault_i` | fault |
| Missing samples | no valid sample for `TEMP_TIMEOUT` cycles | fault |
| Implausible value | outside `TEMP_RANGE` | sample rejected, fault |
| Implausible step | step greater than `MAX_DELTA` from the previous in-range sample | sample rejected, fault |

The step check compares against the previous in-range raw sample. A genuine, persistent step is therefore accepted on the next sample, while a single outlier is rejected (tested).

While a fault is present:

* the level can rise but never falls;
* the fault clears after `DEESCALATE` consecutive good samples.

The response is set by `SENSOR_FAULT_ACTION`: 0 throttles (fail-safe), 1 enters FAULT.

## Throttling policy (deterministic)

| Condition | Issue rate (per 16 core cycles) | Tensor | Other |
|---|---|---|---|
| NORMAL | 16 | - | - |
| WARN (with `THROTTLE_EN`) | `WARN_RATE` (default 16) | `WARN_PAUSE_TNS` | state stays ACTIVE/IDLE |
| THERMAL_LIMIT | `THR_RATE` (default 8) | `THR_PAUSE_TNS` | optional `THERMAL_OPP` |
| CRITICAL / FAULT | 0: stop all new commands | stopped | emergency shutdown request |

* **Even spreading.** The rate limiter is a fractional accumulator, so slots are spread evenly. A rate of 8 gives one issue every other cycle, not bursts.
* **Gating new transfers only.** Throttling only gates the *start* of new transfers. A transfer already offered to a unit is never withdrawn.
* **No effect on in-flight work or data.** In-flight work always completes and payloads never pass through POWERCLOCK. The scoreboard in every test checks bit-exact results for every command.
* **DMA.** DMA is not rate-limited: it moves data for work already accepted. It is stopped by drain and stop-new.
* **Measured in simulation.**
  * THR_RATE 4/16: 0.25 commands/cycle.
  * WARN_RATE 3/16: 0.1875 commands/cycle.
  * Tensor pause: zero tensor issues while vector work continues.
  * Stop-new: zero new transfers in FAULT while in-flight work drains.
  * Stop-new latency (emergency request to the core refusing new work): 35-242 ns, i.e. 5.3-11.5 core cycles, across all clock ratios tested. It crosses through the configuration handshake.

## Verification specific to this block

* **Golden-model check** (`tools/check_thermal_monitor.py`). The RTL is compared cycle-by-cycle with the Python reference over 40 randomized configurations x 6000 cycles, with **0 mismatches**.
  * The stimulus mixes threshold crossings, hysteresis-band dwell, jumps, out-of-range samples, sensor faults and sample gaps.
  * Coverage spans all four levels plus sensor-fault cycles; see `reports/thermal_golden.txt`.
* **Mutation test.** With hysteresis deliberately removed from the reference model, 9 of 10 runs mismatch. The check detects policy errors.
* **Closed-loop RTL simulation.** Simulated sensor, full load, compressed time: the temperature stays below CRITICAL under throttling.

## Stability (ThermalLab integration, section 11)

See `reports/thermal_stability/summary.md`.

* ThermalLab's API was not available here. The adapter in `tools/pm_policy_model.py` defines the contract and refuses to run unbound.
* The study therefore uses a lumped-RC backend with an **assumed** scenario. It is about control-loop dynamics, not SilicaFlux temperatures.
* Main findings:
  * On/off throttling either cycles or parks, depending on whether the throttled steady-state temperature is below SET - HYST.
  * MIN_DWELL bounds the cycling rate.
  * Too-low throttle rates waste performance.
  * Too-high throttle rates cannot hold the temperature below CRITICAL.
