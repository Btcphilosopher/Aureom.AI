# 4. Clock, reset and clock-domain crossing

## Clock gating

All gating goes through `sf_clock_gate.sv`. There is no combinational clock gating anywhere:

* **FPGA**: `+define+SF_CLKGATE_XILINX_BUFGCE` maps to `BUFGCE`.
* **ASIC**: `+define+SF_CLKGATE_ASIC_ICG` maps to `sf_icg_lib_cell`, which the integrator wraps around the library ICG.
* **Simulation**: a behavioural latch-plus-AND ICG model.
* **Synthesis with no target selected** fails on purpose. Verified: Yosys stops on `sf_clkgate_target_not_selected`.

Every enable is synchronised in the gated clock's own source domain before the gate.

There are three gates:

* the global core gate, enabled only during reset sequencing, frequency changes and lock loss;
* the vector unit gate;
* the tensor unit gate.

The unit gates include a hardware interlock: `enable = requested OR busy OR transfer offered`. A unit's clock therefore cannot stop with work in flight, even if sequencing were wrong.

Yosys generic synthesis (`syn/yosys_synth.ys`) confirms that exactly three ICG instances are used and that **no latches are inferred** anywhere (`select -assert-none` on all latch cell types).

## Reset

* POR (`rst_aon_ni`) resets the always-on domain asynchronously.
* The core reset is requested by an always-on flop. It asserts asynchronously, so it works with the core clock stopped, and it releases synchronously to `clk_core` through `sf_reset_sync`.
* The order is enforced by the sequencer: lock stable, then clock enabled and acknowledged, then reset released.
* Test `reset_sequence` checks the order and the number of clock edges before release.

## CDC and RDC

The full manifest is in `constraints/cdc_crossings.md`. In summary:

* Single-bit levels cross through 2-FF synchronisers.
* Multi-bit values cross through 2-phase toggle handshakes: core configuration, error-clear mask, and the 224-bit activity snapshot.
* The frequency controller uses a 4-phase request/acknowledge.
* Both ends of every handshake are reset together. The always-on endpoints are reset while the core reset is requested.

Constraint templates (not run here):

* `constraints/sf_pm_cdc.xdc` (Vivado);
* `constraints/sf_pm_cdc.sdc` (ASIC).

Handshake payloads are skew-bounded with `set_max_delay -datapath_only`, not false-pathed.

## CDC verification performed

* **`SF_CDC_RANDOM_DELAY` metastability model.** Each synchroniser bit independently and randomly resolves one cycle late. This exposes any logic that wrongly assumes two bits cross together.
* **Clock ratios.** The suites run with core/always-on period ratios of 0.3x (fast core), 4.6x (slow core) and 16x (clock-idle abort), plus non-commensurate periods.
* **Activity snapshots.** Every 224-bit snapshot is compared field-by-field against an independent testbench count. A minimum-window phase forces dropped snapshots, and the test checks that the dropped count exactly equals the snapshots never delivered.
* **Not done:** structural CDC signoff with Questa CDC, SpyGlass or Meridian. None was available, so this remains a signoff item.

## Simulator notes (Verilator 5.020)

Two simulator behaviours shaped the testbench. Neither affects the RTL.

1. **Arrays of queues are corrupted.** `logic [47:0] q[3][$]` misplaces pushes, and data reads back as zero. A 20-line standalone reproduction is described in docs/08. The testbench uses separate queues.
2. **Derived-clock ordering.** Processes on a gated clock evaluate after the parent clock's NBA updates. The unit models therefore sample their inputs on the parent clock's falling edge, which gives exactly the value a real flop samples at the rising edge.
