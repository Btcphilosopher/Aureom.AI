# 1. Audit: what POWERCLOCK can actually control

## Scope of the audit, stated plainly

The SilicaFlux-HPC source tree (ControlCore, PowerGrid, TENSORCORE 02, the
vector unit, DMA, board files) was **not available in the build environment**.
Nothing below was inspected in your repository. This audit is therefore a
controllability matrix: for each item the brief asked to inspect, it records
what POWERCLOCK assumes, the interface it exposes so the assumption is
explicit, and what must be confirmed at integration. Where a capability's
existence could not be established, POWERCLOCK defaults to "absent" and
reports it as absent in `CAP`.

| Audit item | Inspected? | POWERCLOCK assumption | Interface provided | Confirm at integration |
|---|---|---|---|---|
| Clock/reset architecture | No | One always-on reference clock that is never gated or reconfigured; one core clock root from a PLL/MMCM or fixed oscillator | `clk_aon_i`, `clk_core_root_i`, `rst_aon_ni` (POR) | Always-on clock really exists and is independent of the core PLL; POR polarity |
| FPGA clocking resources | No | BUFGCE (or equivalent global buffer with clock enable) available | `SF_CLKGATE_XILINX_BUFGCE` mapping in `sf_clock_gate.sv` | Device family, BUFGCE count, CE synchronisation rules (UG472/UG572) |
| ASIC clock-gating cells | No | Library provides a latch-based integrated clock gate | `SF_CLKGATE_ASIC_ICG` -> integrator-written `sf_icg_lib_cell` wrapper (CK, E, SE, GCK) | Cell name, test-enable pin, clock-gating check setup in STA |
| PLL / frequency control | No | **Unknown -> treated as absent** | `HAS_FREQ_CTRL=0` default; when 1: 4-phase `fc_req/fc_ack/fc_opp`, `pll_locked_i` | A reconfiguration controller exists (e.g. MMCM DRP sequencer) and meets the contract in docs/06 |
| Voltage regulators / PMIC | No | **Absent.** No regulator interface exists | None. `CAP.VOLTAGE_CTRL = CAP.DVFS = 0` (constants) | If a PMIC is added, follow docs/06 before any voltage scaling is attempted |
| Power switches / retention | No | **Absent** | None. No power-off states. `CAP.POWER_SWITCHING = 0` | - |
| PowerGrid (Project 08) | No | Not a control surface; a source of power data for estimation | Activity outputs (`ACT_*`, VCD) suitable as PowerGrid/ThermalLab input | Data format exchange |
| ThermalLab (Project 09) | No (API not available) | Thermal backend for policy studies | `ThermalLabBackend` adapter contract in `tools/pm_policy_model.py` (refuses to run unbound) | Bind adapter to ThermalLab's transient solver API |
| Vector / tensor enable signals | No | Each unit has a command valid/ready channel and a `busy` (= has in-flight work) output; its clock can be gated externally | `*_up/_dn` valid/ready per channel, `*_busy_i`, gated `clk_vec_o`/`clk_tns_o` | Unit `busy` covers ALL in-flight state incl. outstanding memory writes |
| Performance counters | No | No existing counters relied upon; POWERCLOCK counts real busy/queue/stall events itself | `ACT_VEC/TNS/DMA/IDLE/QOCC/STALL` | Map to existing counters if ControlCore already has them |
| ControlCore | No | APB3 master in, or bridged to, the always-on domain; takes one level IRQ | APB3 slave, `irq_o` | Bus protocol/bridge; if ControlCore is on the core clock an APB CDC bridge is required |
| Sensor interfaces | No | **No calibrated on-die sensor confirmed** | `temp_valid/temp_data/temp_fault` (signed 1/16 degC, always-on synchronous); `CAP.SENSOR_CALIBRATED` parameter (default 0); explicitly simulated sensor model for simulation | Sensor exists, calibration method, sample rate, domain (handshake CDC if not always-on) |

## What POWERCLOCK therefore controls

1. Global core clock enable (only during reset sequencing, lock loss, and validated frequency changes).
2. Vector and tensor unit clock enables (CLOCK_IDLE), interlocked with unit busy.
3. Core-domain reset sequencing.
4. Command acceptance: issue rate (1-16 slots per 16 cycles), tensor pause, stop-all-new-work.
5. Frequency requests, **only** if `HAS_FREQ_CTRL=1` and **only** to OPPs marked validated at integration.

It does not control supply voltage or power switches, and it never reports
that it does.
