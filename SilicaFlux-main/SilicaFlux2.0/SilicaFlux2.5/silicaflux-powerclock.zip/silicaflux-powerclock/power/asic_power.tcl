# =============================================================================
# POWERCLOCK - ASIC library-based power TEMPLATE (PrimeTime PX style; not run:
# no library/netlist available). Library-based estimates need: gate-level
# netlist, SPEF parasitics, characterised .db at the operating corner, and
# per-scenario activity (SAIF/VCD from gate-level simulation).
# =============================================================================
set power_enable_analysis true
read_db   $env(SF_LIB_DB)
read_verilog silicaflux_power_manager.gate.v
link_design silicaflux_power_manager
read_parasitics silicaflux_power_manager.spef
read_sdc constraints/sf_pm_cdc.sdc
foreach scen {active thermal_limit idle clock_idle} {
  reset_switching_activity
  read_saif pm_${scen}.saif -strip_path tb_pm_top/dut
  update_power
  report_power -hierarchy > power_${scen}.rpt
}
