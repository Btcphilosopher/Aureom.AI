# =============================================================================
# POWERCLOCK - Vivado vendor power estimate TEMPLATE (not run: no Vivado here).
# Produces a VENDOR ESTIMATE from post-route netlist + simulation activity.
# Do not report numbers from a run without the SAIF; vectorless estimates are
# defaults-driven and not representative of POWERCLOCK operating states.
# =============================================================================
# 1. Simulate the routed netlist (or RTL as a first pass) per scenario and
#    write SAIF, e.g. xsim: open_saif pm_active.saif; log_saif [get_objects -r *]
# 2. In the implemented design:
open_checkpoint impl_routed.dcp
foreach scen {active thermal_limit idle clock_idle} {
  reset_switching_activity -all
  read_saif -file pm_${scen}.saif -strip_path tb_pm_top/dut
  report_power -file power_${scen}.rpt -name pwr_${scen}
}
# Compare power_*.rpt between scenarios; the difference between idle and
# clock_idle isolates the unit clock-tree/register contribution that
# CLOCK_IDLE removes. Record tool version, device, speed grade, temperature.
