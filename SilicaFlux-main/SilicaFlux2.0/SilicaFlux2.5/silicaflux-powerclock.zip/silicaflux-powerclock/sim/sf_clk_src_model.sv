// =============================================================================
// SIMULATION ONLY. Behavioural model of a reconfigurable clock source
// (PLL/MMCM + reconfiguration controller) implementing the POWERCLOCK
// frequency-controller contract:
//   * fc_opp_i is sampled when fc_req_i rises
//   * pll_locked_o is driven LOW before fc_ack_o rises (if relock is needed)
//   * fc_ack_o follows a 4-phase handshake with fc_req_i
//   * pll_locked_o returns HIGH after relock_ns with the new period
// While unlocked the output may be stopped or glitchy (random runt pulses),
// which is what a real MMCM/PLL output can do; the power manager must keep
// the core clock gated throughout.
// Fault injection: never_ack, never_lock, lose_lock().
// =============================================================================
`timescale 1ns/1ps
module sf_clk_src_model #(
  parameter int NUM_OPP = 4
) (
  input  logic       fc_req_i,
  input  logic [3:0] fc_opp_i,
  output logic       fc_ack_o,
  output logic       pll_locked_o,
  output logic       clk_o
);
  realtime half_ns [16];
  int      cur_opp;
  bit      never_ack;
  bit      never_lock;
  bit      glitchy;
  realtime ack_delay_ns;
  realtime relock_ns;
  int      reconfig_count;

  initial begin
    for (int i = 0; i < 16; i++) half_ns[i] = 5.0;
    cur_opp        = 0;
    never_ack      = 0;
    never_lock     = 0;
    glitchy        = 1;
    ack_delay_ns   = 40.0;
    relock_ns      = 1500.0;
    reconfig_count = 0;
    clk_o          = 1'b0;
    fc_ack_o       = 1'b0;
    pll_locked_o   = 1'b0;
    #(relock_ns);
    pll_locked_o   = 1'b1;
  end

  // clock generation
  always begin
    if (pll_locked_o) begin
      #(half_ns[cur_opp]) clk_o = ~clk_o;
    end else if (glitchy) begin
      // runt pulses of random width: what the core must never see
      #($urandom_range(1, 7) * 0.37) clk_o = ~clk_o;
    end else begin
      clk_o = 1'b0;
      #(1.0);
    end
  end

  // reconfiguration handshake
  always @(posedge fc_req_i) begin
    automatic int opp = int'(fc_opp_i);
    reconfig_count++;
    #(2.0) pll_locked_o = 1'b0;             // relock required
    #(ack_delay_ns);
    if (!never_ack) begin
      fc_ack_o = 1'b1;
      wait (!fc_req_i);
      #(ack_delay_ns) fc_ack_o = 1'b0;
      cur_opp = (opp < NUM_OPP) ? opp : cur_opp;
      #(relock_ns);
      if (!never_lock) pll_locked_o = 1'b1;
    end
  end

  task automatic lose_lock(input realtime dur_ns);
    pll_locked_o = 1'b0;
    #(dur_ns);
    pll_locked_o = 1'b1;
  endtask

  task automatic set_lock(input bit v);
    pll_locked_o = v;
  endtask
endmodule
