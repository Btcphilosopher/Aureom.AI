// =============================================================================
// SIMULATION ONLY - EXPLICITLY SIMULATED TEMPERATURE SENSOR.
// Not a model of SilicaFlux silicon. A first-order lumped thermal node driven
// by unit activity, sampled and quantised like a digital on-die sensor
// (signed 16-bit, 1/16 degC), with optional noise and fault injection.
//
// Time is COMPRESSED: tau_cycles is a few thousand always-on cycles so that
// closed-loop policy behaviour can be exercised in RTL simulation; real
// package time constants are milliseconds to seconds. Power coefficients are
// ASSUMED, unit-less "relative activity power" numbers; they are not watts
// and must not be read as a power estimate. Use ThermalLab (via
// tools/pm_policy_model.py) for physically meaningful thermal studies.
// =============================================================================
`timescale 1ns/1ps
module sf_temp_sensor_model (
  input  logic               clk_i,          // always-on clock
  input  logic               rst_ni,
  input  logic               vec_busy_i,     // activity (any domain; sampled loosely)
  input  logic               tns_busy_i,
  input  logic               dma_busy_i,
  input  logic               core_clk_on_i,
  output logic               valid_o,
  output logic signed [15:0] data_o,
  output logic               fault_o
);
  real t_amb, r_th, tau, p_static, k_vec, k_tns, k_dma, k_clk, noise_degc;
  real temp_c;
  int  sample_period;
  int  cnt;
  bit  enable;
  bit  stuck;          // fault injection: output frozen
  bit  dropout;        // fault injection: no samples
  bit  report_fault;   // fault injection: sensor flags its own fault
  real spike_degc;     // fault injection: one-shot spike added to next sample

  initial begin
    t_amb         = 45.0;
    r_th          = 1.0;     // degC per relative-power unit (ASSUMED)
    tau           = 4000.0;  // always-on cycles (COMPRESSED)
    p_static      = 5.0;
    k_vec         = 20.0;
    k_tns         = 45.0;
    k_dma         = 8.0;
    k_clk         = 5.0;
    noise_degc    = 0.0;
    temp_c        = t_amb;
    sample_period = 50;
    enable        = 1'b0;
    stuck         = 1'b0;
    dropout       = 1'b0;
    report_fault  = 1'b0;
    spike_degc    = 0.0;
  end

  function automatic logic signed [15:0] quantise(input real c);
    real q = c * 16.0;
    if (q > 32767.0)  q = 32767.0;
    if (q < -32768.0) q = -32768.0;
    return 16'($rtoi(q < 0.0 ? q - 0.5 : q + 0.5));
  endfunction

  real p;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      cnt     <= 0;
      valid_o <= 1'b0;
      data_o  <= '0;
      fault_o <= 1'b0;
    end else begin
      p = p_static + (core_clk_on_i ? k_clk : 0.0) + (vec_busy_i ? k_vec : 0.0) +
          (tns_busy_i ? k_tns : 0.0) + (dma_busy_i ? k_dma : 0.0);
      temp_c = temp_c + ((t_amb + r_th * p) - temp_c) / tau;
      valid_o <= 1'b0;
      fault_o <= report_fault;
      if (enable && !dropout) begin
        if (cnt >= sample_period - 1) begin
          real n = (noise_degc > 0.0) ? noise_degc * ($itor($urandom_range(0, 2000)) / 1000.0 - 1.0) : 0.0;
          cnt     <= 0;
          valid_o <= 1'b1;
          if (!stuck) data_o <= quantise(temp_c + n + spike_degc);
          spike_degc = 0.0;
        end else begin
          cnt <= cnt + 1;
        end
      end
    end
  end
endmodule
