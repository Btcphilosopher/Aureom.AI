#!/bin/bash
# Full regression: 4 builds, functional suites, CDC random-delay clock-ratio sweeps.
cd "$(dirname "$0")"
set -o pipefail
R=reports/regression; rm -rf $R; mkdir -p $R
BASE=$(cat tb/base_tests.txt); FREQ=$(cat tb/freq_tests.txt)
BASE_NO_DVFS=$(echo $BASE | sed 's/dvfs_unavailable//')
SWEEP="reset_sequence clock_idle wake_cmd throttle_rate throttle_pause_tns warn_level hysteresis critical_fault core_reset_on_clear hw_error inflight_throttle activity_counters requests_during_transition lock_loss sensor_timeout irq"
( ./build.sh base 0 > $R/build_base.log 2>&1 ) &
( ./build.sh freq 1 > $R/build_freq.log 2>&1 ) &
wait
( ./build.sh base_cdc 0 -DSF_CDC_RANDOM_DELAY > $R/build_base_cdc.log 2>&1 ) &
( ./build.sh freq_cdc 1 -DSF_CDC_RANDOM_DELAY > $R/build_freq_cdc.log 2>&1 ) &
wait
( ./build.sh trace 0 --trace -DSF_TRACE > $R/build_trace.log 2>&1 ) &
{
echo "### base build"; bash ./run_tests.sh build/base/tb_base $R/base $BASE
echo "### freq build: frequency tests"; bash ./run_tests.sh build/freq/tb_freq $R/freq $FREQ
echo "### freq build: base suite"; bash ./run_tests.sh build/freq/tb_freq $R/freq_base $BASE_NO_DVFS
echo "### CDC random delay, core 3ns / aon 10ns"; bash ./run_tests.sh build/base_cdc/tb_base_cdc $R/cdc_fast $SWEEP -- +CORE_HALF=1.5
echo "### CDC random delay, core 46ns / aon 10ns"; bash ./run_tests.sh build/base_cdc/tb_base_cdc $R/cdc_slow $SWEEP -- +CORE_HALF=23.0
echo "### CDC random delay, core 6.2ns / aon 14.6ns"; bash ./run_tests.sh build/base_cdc/tb_base_cdc $R/cdc_odd $SWEEP -- +CORE_HALF=3.1 +AON_HALF=7.3
echo "### CDC random delay, core 160ns: clock-idle abort"; bash ./run_tests.sh build/base_cdc/tb_base_cdc $R/cdc_abort clock_idle_abort -- +CORE_HALF=40
echo "### CDC random delay, freq build"; bash ./run_tests.sh build/freq_cdc/tb_freq_cdc $R/cdc_freq $FREQ inflight_throttle critical_fault clock_idle
echo "### power trace (activity analysis)"
wait
./build/trace/tb_trace +TEST=power_trace +VCD=build/power_trace.vcd > $R/power_trace.log 2>&1
grep -E "TEST (PASSED|FAILED)" $R/power_trace.log
python3 tools/vcd_activity.py build/power_trace.vcd reports/activity_analysis.md > /dev/null && echo "activity analysis written"
} > $R/summary.txt 2>&1
echo REGRESSION_DONE >> $R/summary.txt
