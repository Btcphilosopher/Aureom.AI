/* Host-side unit test of the POWERCLOCK driver against a mock register block. */
#include <stdio.h>
#include <string.h>
#include "sf_pm_driver.h"

static uint32_t mock[64];
static int fails = 0;
#define EXPECT(c) do { if (!(c)) { printf("FAIL %s:%d %s\n", __FILE__, __LINE__, #c); fails++; } } while (0)
#define M(name) mock[SF_PM_##name##_OFFSET / 4]

int main(void) {
  sf_pm_t pm;
  memset(mock, 0, sizeof mock);
  EXPECT(sf_pm_init(&pm, (uintptr_t)mock) == SF_PM_ERR_ID);
  M(ID) = 0x53461B01u;
  M(CAP) = SF_PM_SET(CAP, UNIT_CLOCK_GATING, 1) | SF_PM_SET(CAP, NUM_OPP, 1) |
           SF_PM_SET(CAP, OPP_VALIDATED, 1);                   /* no frequency controller */
  EXPECT(sf_pm_init(&pm, (uintptr_t)mock) == SF_PM_OK);
  EXPECT(!sf_pm_dvfs_available(&pm));
  EXPECT(!sf_pm_has_freq_ctrl(&pm));

  /* fixed-point conversion */
  EXPECT(sf_pm_mc_to_q4(85000) == 1360);
  EXPECT(sf_pm_mc_to_q4(-40000) == -640);
  EXPECT(sf_pm_mc_to_q4(31) == 0 && sf_pm_mc_to_q4(32) == 1);   /* 1/16 degC = 62.5 mC */
  EXPECT(sf_pm_mc_to_q4(10000000) == 32767);
  EXPECT(sf_pm_q4_to_mc(1360) == 85000);

  /* OPP requests never reach hardware without a controller */
  M(CMD) = 0;
  EXPECT(sf_pm_request_opp(&pm, 0) == SF_PM_ERR_UNAVAILABLE);
  EXPECT(M(CMD) == 0);

  /* with a controller: 4 OPPs, 0..2 validated */
  M(CAP) = SF_PM_SET(CAP, UNIT_CLOCK_GATING, 1) | SF_PM_SET(CAP, FREQ_CTRL, 1) |
           SF_PM_SET(CAP, NUM_OPP, 4) | SF_PM_SET(CAP, OPP_VALIDATED, 0x7);
  sf_pm_init(&pm, (uintptr_t)mock);
  M(STATUS) = SF_PM_SET(STATUS, STATE, SF_PM_ACTIVE);
  EXPECT(sf_pm_request_opp(&pm, 4) == SF_PM_ERR_INVALID_OPP);
  EXPECT(sf_pm_request_opp(&pm, 3) == SF_PM_ERR_NOT_VALIDATED);
  EXPECT(M(CMD) == 0);
  EXPECT(sf_pm_request_opp(&pm, 2) == SF_PM_OK);
  EXPECT(M(OPP_REQ) == 2 && M(CMD) == SF_PM_CMD_OPP_GO_MASK);
  M(STATUS) = SF_PM_SET(STATUS, STATE, SF_PM_THERMAL_LIMIT);
  EXPECT(sf_pm_request_opp(&pm, 1) == SF_PM_ERR_STATE);
  M(OPP_STATUS) = SF_PM_SET(OPP_STATUS, RESULT, 5) | SF_PM_SET(OPP_STATUS, BUSY, 0);
  bool busy; EXPECT(sf_pm_opp_result(&pm, &busy) == SF_PM_ERR_TIMEOUT && !busy);

  /* thermal configuration encoding + validation */
  sf_pm_thermal_cfg_t t = { 85000, 3000, 95000, 5000, 105000, 10000, -40000, 150000, 0, 0xFFFFFF, 2, 4 };
  EXPECT(sf_pm_set_thermal(&pm, &t) == SF_PM_OK);   /* mock memory reads back unclamped */
  EXPECT(M(TEMP_WARN) == ((48u << 16) | 1360u));
  EXPECT(M(TEMP_THROTTLE) == ((80u << 16) | 1520u));
  EXPECT(M(TEMP_RANGE) == ((2400u << 16) | 0xFD80u));
  EXPECT(M(TEMP_FILTER) == ((0u << 16) | (4u << 4) | 2u));
  sf_pm_thermal_cfg_t bad = t; bad.throttle_mc = 80000;          /* below WARN */
  EXPECT(sf_pm_set_thermal(&pm, &bad) == SF_PM_ERR_ARG);
  bad = t; bad.crit_hyst_mc = 30000;                               /* CRIT clear below THROTTLE clear */
  EXPECT(sf_pm_set_thermal(&pm, &bad) == SF_PM_ERR_ARG);

  /* hardware hard-limit clamp is reported: simulate the clamped readback */
  {
    sf_pm_thermal_cfg_t hot = t; hot.crit_mc = 140000;
    /* write, then emulate the RTL clamp (CRIT_HARD_LIMIT = 115 degC) and re-check */
    sf_pm_set_thermal(&pm, &hot);
    M(TEMP_CRIT) = (M(TEMP_CRIT) & 0xFFFF0000u) | 1840u;
    EXPECT(SF_PM_GET(TEMP_CRIT, SET, M(TEMP_CRIT)) != (uint16_t)sf_pm_mc_to_q4(hot.crit_mc));
  }

  /* throttle configuration */
  sf_pm_throttle_cfg_t th = { 16, 8, false, true, 1024, true, 0 };
  M(CTRL) = 0x3;
  EXPECT(sf_pm_set_throttle(&pm, &th) == SF_PM_OK);
  EXPECT(M(THROTTLE_CFG) == ((0u << 16) | (1u << 13) | (8u << 8) | 16u));
  EXPECT(M(CTRL) == (0x3u | SF_PM_CTRL_THERMAL_OPP_EN_MASK));
  th.thermal_opp = 3;
  EXPECT(sf_pm_set_throttle(&pm, &th) == SF_PM_ERR_NOT_VALIDATED);
  th.thr_rate = 0;
  EXPECT(sf_pm_set_throttle(&pm, &th) == SF_PM_ERR_ARG);

  /* fault clear refuses while a fault condition is active */
  M(CMD) = 0;
  M(STATUS) = SF_PM_SET(STATUS, FAULT_ACTIVE, 1) | SF_PM_SET(STATUS, STATE, SF_PM_FAULT);
  EXPECT(sf_pm_fault_clear(&pm) == SF_PM_ERR_STILL_FAULTED && M(CMD) == 0);
  M(STATUS) = SF_PM_SET(STATUS, STATE, SF_PM_FAULT);
  EXPECT(sf_pm_fault_clear(&pm) == SF_PM_OK && M(CMD) == SF_PM_CMD_FAULT_CLEAR_MASK);

  /* activity read restores FREEZE=0 and reports the window */
  M(ACT_CFG) = 8; M(ACT_VEC) = 100; M(ACT_SEQ) = (3u << 16) | 42u;
  sf_pm_activity_t a;
  sf_pm_read_activity(&pm, &a);
  EXPECT(a.vec_busy == 100 && a.seq == 42 && a.dropped == 3 && a.window_cycles == 256);
  EXPECT(M(ACT_CFG) == 8);

  /* temperature readback */
  M(TEMP_STATUS) = SF_PM_SET(TEMP_STATUS, LAST, 1520) | SF_PM_SET(TEMP_STATUS, SEEN, 1);
  bool v; EXPECT(sf_pm_temperature_mc(&pm, &v) == 95000 && v);

  printf("%s: %d failures\n", fails ? "DRIVER TEST FAILED" : "DRIVER TEST PASSED", fails);
  return fails != 0;
}
