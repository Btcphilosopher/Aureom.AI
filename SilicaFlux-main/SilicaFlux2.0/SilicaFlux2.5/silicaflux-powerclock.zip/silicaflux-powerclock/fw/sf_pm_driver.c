/* SilicaFlux-HPC POWERCLOCK firmware driver - see sf_pm_driver.h */
#include "sf_pm_driver.h"

#define REG(pm, name) ((pm)->regs[SF_PM_##name##_OFFSET / 4u])
#define SF_PM_ID_VALUE 0x53461B01u

int16_t sf_pm_mc_to_q4(int32_t mc) {
  /* q4 = round(mc * 16 / 1000), saturating to int16 */
  int64_t n = (int64_t)mc * 16;
  int64_t q = (n >= 0) ? (n + 500) / 1000 : -((-n + 500) / 1000);
  if (q > 32767) q = 32767;
  if (q < -32768) q = -32768;
  return (int16_t)q;
}

int32_t sf_pm_q4_to_mc(int16_t q4) { return ((int32_t)q4 * 1000) / 16; }

static uint32_t hyst_q4(int32_t mc) {
  int16_t h = sf_pm_mc_to_q4(mc);
  return (uint32_t)(uint16_t)(h < 0 ? 0 : h);
}

sf_pm_status_t sf_pm_init(sf_pm_t *pm, uintptr_t base) {
  pm->regs = (volatile uint32_t *)base;
  if (REG(pm, ID) != SF_PM_ID_VALUE) return SF_PM_ERR_ID;
  pm->cap = REG(pm, CAP);
  return SF_PM_OK;
}

bool sf_pm_has_freq_ctrl(const sf_pm_t *pm) { return SF_PM_GET(CAP, FREQ_CTRL, pm->cap) != 0; }

bool sf_pm_dvfs_available(const sf_pm_t *pm) {
  /* DVFS requires voltage control; report what the hardware says (always 0 here) */
  return SF_PM_GET(CAP, DVFS, pm->cap) && SF_PM_GET(CAP, VOLTAGE_CTRL, pm->cap);
}

sf_pm_state_t sf_pm_state(const sf_pm_t *pm) {
  return (sf_pm_state_t)SF_PM_GET(STATUS, STATE, REG(pm, STATUS));
}

static uint32_t thr_word(int32_t set_mc, int32_t hyst_mc) {
  return SF_PM_SET(TEMP_WARN, SET, (uint16_t)sf_pm_mc_to_q4(set_mc)) |
         SF_PM_SET(TEMP_WARN, HYST, hyst_q4(hyst_mc));
}

sf_pm_status_t sf_pm_set_thermal(sf_pm_t *pm, const sf_pm_thermal_cfg_t *c) {
  /* Ordered, non-overlapping levels; hysteresis must not cross the level below. */
  if (!(c->warn_mc <= c->throttle_mc && c->throttle_mc <= c->crit_mc)) return SF_PM_ERR_ARG;
  if (c->warn_hyst_mc < 0 || c->throttle_hyst_mc < 0 || c->crit_hyst_mc < 0) return SF_PM_ERR_ARG;
  if (c->crit_mc - c->crit_hyst_mc < c->throttle_mc - c->throttle_hyst_mc) return SF_PM_ERR_ARG;
  if (c->range_min_mc >= c->range_max_mc || c->crit_mc > c->range_max_mc) return SF_PM_ERR_ARG;
  if (c->escalate < 1 || c->escalate > 15 || c->deescalate < 1 || c->deescalate > 15) return SF_PM_ERR_ARG;
  if (c->sample_timeout_cycles > 0xFFFFFFu || c->max_step_mc < 0) return SF_PM_ERR_ARG;
  REG(pm, TEMP_WARN) = thr_word(c->warn_mc, c->warn_hyst_mc);
  REG(pm, TEMP_THROTTLE) = thr_word(c->throttle_mc, c->throttle_hyst_mc);
  REG(pm, TEMP_CRIT) = thr_word(c->crit_mc, c->crit_hyst_mc);   /* hardware clamps to its hard limit */
  REG(pm, TEMP_RANGE) = SF_PM_SET(TEMP_RANGE, MIN, (uint16_t)sf_pm_mc_to_q4(c->range_min_mc)) |
                        SF_PM_SET(TEMP_RANGE, MAX, (uint16_t)sf_pm_mc_to_q4(c->range_max_mc));
  REG(pm, TEMP_TIMEOUT) = c->sample_timeout_cycles;
  REG(pm, TEMP_FILTER) = SF_PM_SET(TEMP_FILTER, ESCALATE, c->escalate) |
                         SF_PM_SET(TEMP_FILTER, DEESCALATE, c->deescalate) |
                         SF_PM_SET(TEMP_FILTER, MAX_DELTA, hyst_q4(c->max_step_mc));
  /* report a hard-limit clamp so callers know CRIT is lower than requested */
  if (SF_PM_GET(TEMP_CRIT, SET, REG(pm, TEMP_CRIT)) != (uint16_t)sf_pm_mc_to_q4(c->crit_mc)) return SF_PM_ERR_ARG;
  return SF_PM_OK;
}

sf_pm_status_t sf_pm_set_throttle(sf_pm_t *pm, const sf_pm_throttle_cfg_t *c) {
  if (c->warn_rate < 1 || c->warn_rate > 16 || c->thr_rate < 1 || c->thr_rate > 16) return SF_PM_ERR_ARG;
  if (c->min_dwell_cycles > 0xFFFFFFu) return SF_PM_ERR_ARG;
  if (c->thermal_opp_enable) {
    if (!sf_pm_has_freq_ctrl(pm)) return SF_PM_ERR_UNAVAILABLE;
    if (c->thermal_opp >= SF_PM_GET(CAP, NUM_OPP, pm->cap)) return SF_PM_ERR_INVALID_OPP;
    if (!((SF_PM_GET(CAP, OPP_VALIDATED, pm->cap) >> c->thermal_opp) & 1u)) return SF_PM_ERR_NOT_VALIDATED;
  }
  REG(pm, THROTTLE_CFG) = SF_PM_SET(THROTTLE_CFG, WARN_RATE, c->warn_rate) |
                          SF_PM_SET(THROTTLE_CFG, WARN_PAUSE_TNS, c->warn_pause_tensor) |
                          SF_PM_SET(THROTTLE_CFG, THR_RATE, c->thr_rate) |
                          SF_PM_SET(THROTTLE_CFG, THR_PAUSE_TNS, c->thr_pause_tensor) |
                          SF_PM_SET(THROTTLE_CFG, THERMAL_OPP, c->thermal_opp);
  REG(pm, THERM_DWELL) = c->min_dwell_cycles;
  uint32_t ctrl = REG(pm, CTRL) & ~SF_PM_CTRL_THERMAL_OPP_EN_MASK;
  REG(pm, CTRL) = ctrl | SF_PM_SET(CTRL, THERMAL_OPP_EN, c->thermal_opp_enable);
  return SF_PM_OK;
}

static sf_pm_status_t map_result(uint32_t r) {
  switch (r) {
    case 0: return SF_PM_OK;
    case 1: return SF_PM_ERR_BUSY;
    case 2: return SF_PM_ERR_UNAVAILABLE;
    case 3: return SF_PM_ERR_INVALID_OPP;
    case 4: return SF_PM_ERR_NOT_VALIDATED;
    case 5: return SF_PM_ERR_TIMEOUT;
    default: return SF_PM_ERR_STATE;
  }
}

sf_pm_status_t sf_pm_request_opp(sf_pm_t *pm, unsigned idx) {
  /* Fail fast with the same checks the hardware makes: never ask for a
   * frequency the silicon has not declared available and validated. */
  if (!sf_pm_has_freq_ctrl(pm)) return SF_PM_ERR_UNAVAILABLE;
  if (idx >= SF_PM_GET(CAP, NUM_OPP, pm->cap)) return SF_PM_ERR_INVALID_OPP;
  if (!((SF_PM_GET(CAP, OPP_VALIDATED, pm->cap) >> idx) & 1u)) return SF_PM_ERR_NOT_VALIDATED;
  sf_pm_state_t st = sf_pm_state(pm);
  if (st == SF_PM_CLOCK_IDLE) sf_pm_wake(pm);           /* changes are not accepted while gated */
  else if (st != SF_PM_IDLE && st != SF_PM_ACTIVE) return SF_PM_ERR_STATE;
  REG(pm, OPP_REQ) = idx;
  REG(pm, CMD) = SF_PM_CMD_OPP_GO_MASK;
  return SF_PM_OK;   /* completion: IRQ OPP_DONE or poll sf_pm_opp_result() */
}

sf_pm_status_t sf_pm_opp_result(const sf_pm_t *pm, bool *busy) {
  uint32_t s = REG(pm, OPP_STATUS);
  *busy = SF_PM_GET(OPP_STATUS, BUSY, s) != 0;
  return map_result(SF_PM_GET(OPP_STATUS, RESULT, s));
}

sf_pm_status_t sf_pm_fault_clear(sf_pm_t *pm) {
  if (SF_PM_GET(STATUS, FAULT_ACTIVE, REG(pm, STATUS))) return SF_PM_ERR_STILL_FAULTED;
  REG(pm, CMD) = SF_PM_CMD_FAULT_CLEAR_MASK;
  return SF_PM_OK;
}

void sf_pm_wake(sf_pm_t *pm) { REG(pm, CMD) = SF_PM_CMD_WAKE_MASK; }

sf_pm_status_t sf_pm_read_activity(sf_pm_t *pm, sf_pm_activity_t *a) {
  uint32_t cfg = REG(pm, ACT_CFG);
  REG(pm, ACT_CFG) = cfg | SF_PM_ACT_CFG_FREEZE_MASK;      /* coherent multi-register read */
  a->vec_busy = REG(pm, ACT_VEC);
  a->tns_busy = REG(pm, ACT_TNS);
  a->dma_busy = REG(pm, ACT_DMA);
  a->all_idle = REG(pm, ACT_IDLE);
  a->qocc_sum = REG(pm, ACT_QOCC);
  a->stall    = REG(pm, ACT_STALL);
  uint32_t sq = REG(pm, ACT_SEQ);
  REG(pm, ACT_CFG) = cfg & ~SF_PM_ACT_CFG_FREEZE_MASK;
  a->seq = (uint16_t)SF_PM_GET(ACT_SEQ, SEQ, sq);
  a->dropped = (uint16_t)SF_PM_GET(ACT_SEQ, DROPPED, sq);
  uint32_t w = SF_PM_GET(ACT_CFG, WINDOW_LOG2, cfg);
  w = w < 4 ? 4 : (w > 24 ? 24 : w);
  a->window_cycles = 1u << w;
  return SF_PM_OK;
}

uint32_t sf_pm_irq_ack(sf_pm_t *pm) {
  uint32_t pend = REG(pm, IRQ_STATUS) & REG(pm, IRQ_ENABLE);
  REG(pm, IRQ_STATUS) = pend;   /* W1C */
  return pend;
}

int32_t sf_pm_temperature_mc(const sf_pm_t *pm, bool *valid) {
  uint32_t t = REG(pm, TEMP_STATUS);
  *valid = SF_PM_GET(TEMP_STATUS, SEEN, t) && !SF_PM_GET(TEMP_STATUS, FAULT, t);
  return sf_pm_q4_to_mc((int16_t)SF_PM_GET(TEMP_STATUS, LAST, t));
}
