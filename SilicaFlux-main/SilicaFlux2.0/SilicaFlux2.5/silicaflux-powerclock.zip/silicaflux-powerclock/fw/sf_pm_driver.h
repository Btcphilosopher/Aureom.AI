/* SilicaFlux-HPC POWERCLOCK firmware driver (Project 27, Aureom.AI).
 * Bare-metal, no allocation, no floating point. Register layout comes from
 * the generated sf_pm_regs.h (tools/gen_regs.py). */
#ifndef SF_PM_DRIVER_H
#define SF_PM_DRIVER_H
#include <stdint.h>
#include <stdbool.h>
#include "sf_pm_regs.h"

typedef enum {
  SF_PM_OK = 0,
  SF_PM_ERR_ID = -1,            /* block not found at base address            */
  SF_PM_ERR_ARG = -2,           /* argument out of range / inconsistent        */
  SF_PM_ERR_UNAVAILABLE = -3,   /* capability not present in this hardware     */
  SF_PM_ERR_INVALID_OPP = -4,
  SF_PM_ERR_NOT_VALIDATED = -5,
  SF_PM_ERR_BUSY = -6,
  SF_PM_ERR_TIMEOUT = -7,
  SF_PM_ERR_STATE = -8,
  SF_PM_ERR_STILL_FAULTED = -9
} sf_pm_status_t;

typedef enum { SF_PM_RESET = 0, SF_PM_IDLE, SF_PM_ACTIVE, SF_PM_CLOCK_IDLE,
               SF_PM_THERMAL_LIMIT, SF_PM_FAULT } sf_pm_state_t;

typedef struct {
  volatile uint32_t *regs;
  uint32_t cap;
} sf_pm_t;

/* Thresholds in milli-degrees Celsius (converted to 1/16 degC fixed point). */
typedef struct {
  int32_t warn_mc, warn_hyst_mc;
  int32_t throttle_mc, throttle_hyst_mc;
  int32_t crit_mc, crit_hyst_mc;
  int32_t range_min_mc, range_max_mc;
  int32_t max_step_mc;            /* 0 = disabled */
  uint32_t sample_timeout_cycles; /* always-on cycles, 0 = disabled (NOT recommended) */
  uint8_t escalate, deescalate;   /* 1..15 consecutive samples */
} sf_pm_thermal_cfg_t;

typedef struct {
  uint8_t warn_rate, thr_rate;    /* issue slots per 16 core cycles, 1..16 */
  bool warn_pause_tensor, thr_pause_tensor;
  uint32_t min_dwell_cycles;
  bool thermal_opp_enable;
  uint8_t thermal_opp;
} sf_pm_throttle_cfg_t;

typedef struct {
  uint32_t vec_busy, tns_busy, dma_busy, all_idle, qocc_sum, stall;
  uint16_t seq, dropped;
  uint32_t window_cycles;
} sf_pm_activity_t;

int16_t sf_pm_mc_to_q4(int32_t milli_c);
int32_t sf_pm_q4_to_mc(int16_t q4);

sf_pm_status_t sf_pm_init(sf_pm_t *pm, uintptr_t base);
bool sf_pm_has_freq_ctrl(const sf_pm_t *pm);
bool sf_pm_dvfs_available(const sf_pm_t *pm);   /* false: no voltage control exists */
sf_pm_state_t sf_pm_state(const sf_pm_t *pm);

sf_pm_status_t sf_pm_set_thermal(sf_pm_t *pm, const sf_pm_thermal_cfg_t *c);
sf_pm_status_t sf_pm_set_throttle(sf_pm_t *pm, const sf_pm_throttle_cfg_t *c);
sf_pm_status_t sf_pm_request_opp(sf_pm_t *pm, unsigned idx);
sf_pm_status_t sf_pm_opp_result(const sf_pm_t *pm, bool *busy);
sf_pm_status_t sf_pm_fault_clear(sf_pm_t *pm);
void sf_pm_wake(sf_pm_t *pm);
sf_pm_status_t sf_pm_read_activity(sf_pm_t *pm, sf_pm_activity_t *a);
uint32_t sf_pm_irq_ack(sf_pm_t *pm);          /* returns and clears pending, enabled events */
int32_t sf_pm_temperature_mc(const sf_pm_t *pm, bool *valid);
#endif
