// =============================================================================
// sf_pm_regfile : APB3 register file, always-on domain. Offsets come from the
// generated sf_pm_regs_pkg (tools/gen_regs.py is the single source of truth).
// Zero wait states. PSLVERR on unmapped offsets and on writes to RO registers.
// =============================================================================
module sf_pm_regfile
  import sf_pm_pkg::*;
  import sf_pm_regs_pkg::*;
#(
  parameter bit                 HAS_FREQ_CTRL     = 1'b0,
  parameter int                 NUM_OPP           = 1,
  parameter logic [15:0]        OPP_VALIDATED     = 16'h0001,
  parameter logic [511:0]       OPP_FREQ_KHZ      = '0,  // 16 x 32-bit kHz, entry i at [32*i +: 32]
  parameter int                 RESET_OPP         = 0,
  parameter bit                 SENSOR_CALIBRATED = 1'b0,
  parameter logic signed [15:0] CRIT_HARD_LIMIT   = 16'sd1840   // 115 degC placeholder
) (
  input  logic               clk_i,
  input  logic               rst_ni,
  // APB3
  input  logic               psel_i,
  input  logic               penable_i,
  input  logic               pwrite_i,
  input  logic [7:0]         paddr_i,
  input  logic [31:0]        pwdata_i,
  output logic [31:0]        prdata_o,
  output logic               pready_o,
  output logic               pslverr_o,
  // configuration out
  output pm_cfg_t            cfg_o,
  output therm_cfg_t         tcfg_o,
  output logic [7:0]         hw_err_fatal_mask_o,
  // command pulses
  output logic               cmd_fault_clear_o,
  output logic               cmd_wake_o,
  output logic               cmd_opp_go_o,
  output logic [3:0]         opp_target_o,
  output logic [7:0]         errclr_pulse_o,
  // status in
  input  pm_state_e          state_i,
  input  pm_seq_e            seq_i,
  input  therm_level_e       level_i,
  input  logic               sensor_fault_i,
  input  logic [3:0]         fault_reason_i,
  input  logic signed [15:0] last_temp_i,
  input  logic               sample_seen_i,
  input  logic               emergency_i,
  input  logic               core_clk_en_ack_i,
  input  logic               vec_clk_on_i,
  input  logic               tns_clk_on_i,
  input  logic               drain_i,
  input  logic               core_alive_i,
  input  logic               pll_locked_i,
  input  logic               throttle_active_i,
  input  logic               stop_new_i,
  input  logic               fault_active_i,
  input  logic [3:0]         cur_opp_i,
  input  logic [3:0]         fw_opp_i,
  input  opp_result_e        opp_result_i,
  input  logic               opp_busy_i,
  input  logic               opp_uncertain_i,
  input  logic               opp_done_i,
  input  logic [NUM_FAULT_CAUSE-1:0] fault_cause_i,
  input  logic               state_change_i,
  input  logic               fault_enter_i,
  input  logic [7:0]         hw_err_i,          // synchronised sticky flags
  input  logic               snap_valid_i,
  input  act_snap_t          snap_i,
  input  logic [15:0]        therm_entries_i,
  input  logic [15:0]        fault_entries_i,
  output logic               irq_o
);
  // ---------------------------------------------------------------------------
  // storage
  // ---------------------------------------------------------------------------
  logic [4:0]  ctrl_q;
  logic [3:0]  opp_req_q;
  logic [31:0] idle_cfg_q, clk_timing_q, temp_warn_q, temp_thr_q, temp_crit_q, temp_range_q;
  logic [23:0] seq_timeout_q, dwell_q, temp_timeout_q;
  logic [4:0]  warn_rate_q, thr_rate_q;
  logic        warn_pause_q, thr_pause_q;
  logic [3:0]  thermal_opp_q;
  logic [31:0] temp_filter_q;
  logic [NUM_IRQ-1:0] irq_stat_q, irq_en_q;
  logic [7:0]  fatal_mask_q;
  logic [4:0]  act_wlog_q;
  logic        act_freeze_q;
  act_snap_t   snap_q;
  logic [3:0]  opp_info_sel_q;

  // ---------------------------------------------------------------------------
  // APB decode (access phase)
  // ---------------------------------------------------------------------------
  logic wr, rd, known, ro;
  assign wr = psel_i & penable_i &  pwrite_i;
  assign rd = psel_i & penable_i & ~pwrite_i;

  always_comb begin
    known = 1'b1; ro = 1'b0;
    unique case (paddr_i)
      REG_ID, REG_CAP, REG_STATUS, REG_OPP_STATUS, REG_TEMP_STATUS, REG_FAULT_CAUSE,
      REG_ACT_VEC, REG_ACT_TNS, REG_ACT_DMA, REG_ACT_IDLE, REG_ACT_QOCC, REG_ACT_STALL,
      REG_ACT_SEQ, REG_STATS, REG_OPP_INFO:                       ro = 1'b1;
      REG_CMD, REG_CTRL, REG_OPP_REQ, REG_IDLE_CFG, REG_SEQ_TIMEOUT, REG_CLK_TIMING, REG_THROTTLE_CFG,
      REG_THERM_DWELL, REG_TEMP_WARN, REG_TEMP_THROTTLE, REG_TEMP_CRIT, REG_TEMP_RANGE,
      REG_TEMP_TIMEOUT, REG_TEMP_FILTER, REG_IRQ_STATUS, REG_IRQ_ENABLE, REG_HW_ERR,
      REG_HW_ERR_FATAL, REG_ACT_CFG, REG_OPP_INFO_SEL:            ;
      default:                                                    known = 1'b0;
    endcase
  end

  assign pready_o  = 1'b1;
  assign pslverr_o = psel_i & penable_i & (~known | (pwrite_i & ro));

  function automatic logic [4:0] clamp_rate(input logic [4:0] r);
    if (r == 5'd0)      clamp_rate = 5'd1;
    else if (r > 5'd16) clamp_rate = 5'd16;
    else                clamp_rate = r;
  endfunction

  // ---------------------------------------------------------------------------
  // writes and event capture
  // ---------------------------------------------------------------------------
  therm_level_e level_prev_q;
  logic         sfault_prev_q;
  logic [7:0]   hw_err_prev_q;
  logic         wr_ok;
  assign wr_ok = wr & known & ~ro;

  logic [NUM_IRQ-1:0] irq_set;
  always_comb begin
    irq_set = '0;
    irq_set[IRQ_STATE_CHANGE]   = state_change_i;
    irq_set[IRQ_THERM_WARN]     = (level_i >= TL_WARN)     && (level_prev_q < TL_WARN);
    irq_set[IRQ_THERM_THROTTLE] = (level_i >= TL_THROTTLE) && (level_prev_q < TL_THROTTLE);
    irq_set[IRQ_THERM_CRIT]     = (level_i == TL_CRITICAL) && (level_prev_q != TL_CRITICAL);
    irq_set[IRQ_SENSOR_FAULT]   = sensor_fault_i && !sfault_prev_q;
    irq_set[IRQ_HW_ERR]         = |(hw_err_i & ~hw_err_prev_q);
    irq_set[IRQ_FAULT]          = fault_enter_i;
    irq_set[IRQ_OPP_DONE]       = opp_done_i;
    irq_set[IRQ_ACT_WINDOW]     = snap_valid_i && !act_freeze_q;
    irq_set[IRQ_THERM_CLEAR]    = (level_i == TL_NORMAL) && (level_prev_q != TL_NORMAL);
  end

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      ctrl_q            <= 5'b00011;
      opp_req_q         <= 4'(RESET_OPP);
      idle_cfg_q        <= {16'd1024, 16'd64};
      seq_timeout_q     <= 24'h0F_FFFF;
      clk_timing_q      <= {16'd8, 16'd256};
      warn_rate_q       <= 5'd16;
      warn_pause_q      <= 1'b0;
      thr_rate_q        <= 5'd8;
      thr_pause_q       <= 1'b0;
      thermal_opp_q     <= 4'd0;
      dwell_q           <= 24'd1024;
      temp_warn_q       <= {16'd48,  16'd1360};
      temp_thr_q        <= {16'd80,  16'd1520};
      temp_crit_q       <= {16'd160, 16'd1680};
      temp_range_q      <= {16'd2400, 16'hFD80};
      temp_timeout_q    <= 24'hFF_FFFF;
      temp_filter_q     <= {16'd0, 8'h00, 4'd4, 4'd2};
      irq_stat_q        <= '0;
      irq_en_q          <= '0;
      fatal_mask_q      <= '0;
      act_wlog_q        <= 5'd16;
      act_freeze_q      <= 1'b0;
      snap_q            <= '0;
      opp_info_sel_q    <= '0;
      cmd_fault_clear_o <= 1'b0;
      cmd_wake_o        <= 1'b0;
      cmd_opp_go_o      <= 1'b0;
      errclr_pulse_o    <= '0;
      level_prev_q      <= TL_NORMAL;
      sfault_prev_q     <= 1'b0;
      hw_err_prev_q     <= '0;
    end else begin
      cmd_fault_clear_o <= 1'b0;
      cmd_wake_o        <= 1'b0;
      cmd_opp_go_o      <= 1'b0;
      errclr_pulse_o    <= '0;
      level_prev_q      <= level_i;
      sfault_prev_q     <= sensor_fault_i;
      hw_err_prev_q     <= hw_err_i;

      if (snap_valid_i && !act_freeze_q) snap_q <= snap_i;

      // W1C first, then hardware set wins over a simultaneous clear
      if (wr_ok && paddr_i == REG_IRQ_STATUS) irq_stat_q <= (irq_stat_q & ~pwdata_i[NUM_IRQ-1:0]) | irq_set;
      else                                    irq_stat_q <= irq_stat_q | irq_set;

      if (wr_ok) begin
        unique case (paddr_i)
          REG_CTRL:          ctrl_q        <= pwdata_i[4:0];
          REG_CMD: begin
            cmd_fault_clear_o <= pwdata_i[0];
            cmd_wake_o        <= pwdata_i[1];
            cmd_opp_go_o      <= pwdata_i[2];
          end
          REG_OPP_REQ:       opp_req_q     <= pwdata_i[3:0];
          REG_IDLE_CFG:      idle_cfg_q    <= pwdata_i;
          REG_SEQ_TIMEOUT:   seq_timeout_q <= pwdata_i[23:0];
          REG_CLK_TIMING:    clk_timing_q  <= pwdata_i;
          REG_THROTTLE_CFG: begin
            warn_rate_q   <= clamp_rate(pwdata_i[4:0]);
            warn_pause_q  <= pwdata_i[5];
            thr_rate_q    <= clamp_rate(pwdata_i[12:8]);
            thr_pause_q   <= pwdata_i[13];
            thermal_opp_q <= pwdata_i[19:16];
          end
          REG_THERM_DWELL:   dwell_q       <= pwdata_i[23:0];
          REG_TEMP_WARN:     temp_warn_q   <= pwdata_i;
          REG_TEMP_THROTTLE: temp_thr_q    <= pwdata_i;
          REG_TEMP_CRIT: begin
            // firmware can never raise CRITICAL above the integration hard limit
            temp_crit_q[31:16] <= pwdata_i[31:16];
            temp_crit_q[15:0]  <= ($signed(pwdata_i[15:0]) > CRIT_HARD_LIMIT) ?
                                  CRIT_HARD_LIMIT : pwdata_i[15:0];
          end
          REG_TEMP_RANGE:    temp_range_q   <= pwdata_i;
          REG_TEMP_TIMEOUT:  temp_timeout_q <= pwdata_i[23:0];
          REG_TEMP_FILTER:   temp_filter_q  <= {pwdata_i[31:16], 8'h00, pwdata_i[7:0]};
          REG_IRQ_ENABLE:    irq_en_q       <= pwdata_i[NUM_IRQ-1:0];
          REG_HW_ERR:        errclr_pulse_o <= pwdata_i[7:0];
          REG_HW_ERR_FATAL:  fatal_mask_q   <= pwdata_i[7:0];
          REG_ACT_CFG: begin
            act_wlog_q   <= pwdata_i[4:0];
            act_freeze_q <= pwdata_i[8];
          end
          REG_OPP_INFO_SEL:  opp_info_sel_q <= pwdata_i[3:0];
          default: ;
        endcase
      end
    end
  end

  // ---------------------------------------------------------------------------
  // read mux
  // ---------------------------------------------------------------------------
  logic [31:0] cap, status, opp_status, temp_status, stats;
  assign cap = {OPP_VALIDATED, 4'h0, 4'(NUM_OPP), 2'b00, SENSOR_CALIBRATED,
                1'b0 /*POWER_SWITCHING*/, 1'b0 /*DVFS*/, 1'b0 /*VOLTAGE_CTRL*/,
                HAS_FREQ_CTRL, 1'b1 /*UNIT_CLOCK_GATING*/};
  assign status = {12'h000, fault_active_i, stop_new_i, throttle_active_i, pll_locked_i,
                   core_alive_i, drain_i, tns_clk_on_i, vec_clk_on_i, core_clk_en_ack_i,
                   emergency_i, sensor_fault_i, level_i, seq_i, state_i};
  assign opp_status  = {16'h0000, fw_opp_i, 2'b00, opp_uncertain_i, opp_busy_i, 1'b0,
                        opp_result_i, cur_opp_i};
  assign temp_status = {8'h00, fault_reason_i[3], fault_reason_i[2], fault_reason_i[1],
                        fault_reason_i[0], sensor_fault_i, sample_seen_i, level_i, last_temp_i};
  assign stats       = {fault_entries_i, therm_entries_i};

  always_comb begin
    prdata_o = '0;
    if (rd) begin
      unique case (paddr_i)
        REG_ID:            prdata_o = 32'h5346_1B01;
        REG_CAP:           prdata_o = cap;
        REG_CTRL:          prdata_o = {27'd0, ctrl_q};
        REG_STATUS:        prdata_o = status;
        REG_OPP_REQ:       prdata_o = {28'd0, opp_req_q};
        REG_OPP_STATUS:    prdata_o = opp_status;
        REG_IDLE_CFG:      prdata_o = idle_cfg_q;
        REG_SEQ_TIMEOUT:   prdata_o = {8'd0, seq_timeout_q};
        REG_CLK_TIMING:    prdata_o = clk_timing_q;
        REG_THROTTLE_CFG:  prdata_o = {12'd0, thermal_opp_q, 2'b00, thr_pause_q, thr_rate_q,
                                       2'b00, warn_pause_q, warn_rate_q};
        REG_THERM_DWELL:   prdata_o = {8'd0, dwell_q};
        REG_TEMP_WARN:     prdata_o = temp_warn_q;
        REG_TEMP_THROTTLE: prdata_o = temp_thr_q;
        REG_TEMP_CRIT:     prdata_o = temp_crit_q;
        REG_TEMP_RANGE:    prdata_o = temp_range_q;
        REG_TEMP_TIMEOUT:  prdata_o = {8'd0, temp_timeout_q};
        REG_TEMP_FILTER:   prdata_o = temp_filter_q;
        REG_TEMP_STATUS:   prdata_o = temp_status;
        REG_IRQ_STATUS:    prdata_o = {{(32-NUM_IRQ){1'b0}}, irq_stat_q};
        REG_IRQ_ENABLE:    prdata_o = {{(32-NUM_IRQ){1'b0}}, irq_en_q};
        REG_FAULT_CAUSE:   prdata_o = {{(32-NUM_FAULT_CAUSE){1'b0}}, fault_cause_i};
        REG_HW_ERR:        prdata_o = {24'd0, hw_err_i};
        REG_HW_ERR_FATAL:  prdata_o = {24'd0, fatal_mask_q};
        REG_ACT_CFG:       prdata_o = {23'd0, act_freeze_q, 3'd0, act_wlog_q};
        REG_ACT_VEC:       prdata_o = snap_q.vec_busy;
        REG_ACT_TNS:       prdata_o = snap_q.tns_busy;
        REG_ACT_DMA:       prdata_o = snap_q.dma_busy;
        REG_ACT_IDLE:      prdata_o = snap_q.all_idle;
        REG_ACT_QOCC:      prdata_o = snap_q.qocc_sum;
        REG_ACT_STALL:     prdata_o = snap_q.stall;
        REG_ACT_SEQ:       prdata_o = {snap_q.dropped, snap_q.seq};
        REG_STATS:         prdata_o = stats;
        REG_OPP_INFO_SEL:  prdata_o = {28'd0, opp_info_sel_q};
        REG_OPP_INFO:      prdata_o = (32'(opp_info_sel_q) < NUM_OPP) ? OPP_FREQ_KHZ[32*opp_info_sel_q +: 32] : 32'd0;
        default:           prdata_o = '0;
      endcase
    end
  end

  assign irq_o = |(irq_stat_q & irq_en_q);

  // ---------------------------------------------------------------------------
  // configuration outputs
  // ---------------------------------------------------------------------------
  always_comb begin
    cfg_o.auto_clk_idle_en    = ctrl_q[0];
    cfg_o.throttle_en         = ctrl_q[1];
    cfg_o.sensor_fault_action = ctrl_q[2];
    cfg_o.thermal_opp_en      = ctrl_q[3];
    cfg_o.core_rst_on_clear   = ctrl_q[4];
    cfg_o.idle_enter_cyc      = idle_cfg_q[15:0];
    cfg_o.clkidle_enter_cyc   = idle_cfg_q[31:16];
    cfg_o.seq_timeout         = seq_timeout_q;
    cfg_o.lock_stable         = clk_timing_q[15:0];
    cfg_o.clk_settle          = clk_timing_q[31:16];
    cfg_o.therm_min_dwell     = dwell_q;
    cfg_o.warn_rate           = warn_rate_q;
    cfg_o.warn_pause_tns      = warn_pause_q;
    cfg_o.thr_rate            = thr_rate_q;
    cfg_o.thr_pause_tns       = thr_pause_q;
    cfg_o.thermal_opp         = thermal_opp_q;
    cfg_o.window_log2         = act_wlog_q;

    tcfg_o.warn_set       = temp_warn_q[15:0];
    tcfg_o.warn_hyst      = temp_warn_q[31:16];
    tcfg_o.thr_set        = temp_thr_q[15:0];
    tcfg_o.thr_hyst       = temp_thr_q[31:16];
    tcfg_o.crit_set       = temp_crit_q[15:0];
    tcfg_o.crit_hyst      = temp_crit_q[31:16];
    tcfg_o.range_min      = temp_range_q[15:0];
    tcfg_o.range_max      = temp_range_q[31:16];
    tcfg_o.max_delta      = temp_filter_q[31:16];
    tcfg_o.sample_timeout = temp_timeout_q;
    tcfg_o.escalate       = temp_filter_q[3:0];
    tcfg_o.deescalate     = temp_filter_q[7:4];
  end

  assign hw_err_fatal_mask_o = fatal_mask_q;
  assign opp_target_o        = opp_req_q;
endmodule
