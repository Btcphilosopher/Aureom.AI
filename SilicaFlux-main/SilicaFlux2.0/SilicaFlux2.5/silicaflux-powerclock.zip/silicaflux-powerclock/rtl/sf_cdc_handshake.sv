// =============================================================================
// sf_cdc_handshake : two-phase (toggle) request/acknowledge synchroniser for
// multi-bit payloads. Only the single-bit req and ack toggles are
// synchronised; the payload register is held stable from before the request
// toggle is launched until the acknowledge returns.
//
// Source side   : src_valid_i/src_ready_o; payload captured on valid&ready.
// Destination   : dst_valid_o pulses one dst cycle with dst_data_o.
//
// Constraint (see constraints/): src_hold_q -> dst_data_q is a quasi-static
// path; constrain with set_max_delay -datapath_only <= one destination period
// (or the 2-stage synchroniser latency) rather than set_false_path.
//
// Reset-domain rule: src and dst resets MUST be asserted together (they may
// de-assert independently). One side being reset alone would desynchronise
// the toggles. sf_power_manager guarantees this by resetting the always-on
// endpoints whenever the core reset is requested.
// =============================================================================
module sf_cdc_handshake #(
  parameter int WIDTH = 32
) (
  input  logic             src_clk_i,
  input  logic             src_rst_ni,
  input  logic             src_valid_i,
  output logic             src_ready_o,
  input  logic [WIDTH-1:0] src_data_i,

  input  logic             dst_clk_i,
  input  logic             dst_rst_ni,
  output logic             dst_valid_o,
  output logic [WIDTH-1:0] dst_data_o
);
  // ---------------- source ----------------
  logic             src_req_q;
  logic [WIDTH-1:0] src_hold_q;   // CDC quasi-static payload
  logic             src_ack_s;
  logic             dst_ack_q;

  sf_cdc_sync_2ff #(.WIDTH(1)) u_ack_sync (
    .clk_i(src_clk_i), .rst_ni(src_rst_ni), .d_i(dst_ack_q), .q_o(src_ack_s));

  assign src_ready_o = (src_req_q == src_ack_s);

  always_ff @(posedge src_clk_i or negedge src_rst_ni) begin
    if (!src_rst_ni) begin
      src_req_q  <= 1'b0;
      src_hold_q <= '0;
    end else if (src_valid_i && src_ready_o) begin
      src_hold_q <= src_data_i;
      src_req_q  <= ~src_req_q;
    end
  end

  // ---------------- destination ----------------
  logic dst_req_s;
  sf_cdc_sync_2ff #(.WIDTH(1)) u_req_sync (
    .clk_i(dst_clk_i), .rst_ni(dst_rst_ni), .d_i(src_req_q), .q_o(dst_req_s));

  always_ff @(posedge dst_clk_i or negedge dst_rst_ni) begin
    if (!dst_rst_ni) begin
      dst_ack_q   <= 1'b0;
      dst_valid_o <= 1'b0;
      dst_data_o  <= '0;
    end else begin
      dst_valid_o <= 1'b0;
      if (dst_req_s != dst_ack_q) begin
        dst_ack_q   <= dst_req_s;
        dst_data_o  <= src_hold_q;   // stable: launched >= 2 dst edges ago
        dst_valid_o <= 1'b1;
      end
    end
  end
endmodule
