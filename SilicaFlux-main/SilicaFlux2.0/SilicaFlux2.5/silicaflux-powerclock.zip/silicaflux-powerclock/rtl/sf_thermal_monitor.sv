// =============================================================================
// sf_thermal_monitor : converts temperature samples into a thermal level with
// hysteresis and detects sensor faults. Always-on domain.
//
// Sample format: signed 16-bit, 1/16 degC per LSB. The input is assumed to be
// a CALIBRATED reading synchronous to clk_i (if the sensor runs in another
// domain, cross it with sf_cdc_handshake first). Where no calibrated sensor
// exists, sim/sf_temp_sensor_model.sv provides an explicitly simulated one;
// CAP.SENSOR_CALIBRATED reports which the integrator connected.
//
// Level rules (per accepted sample s):
//   raw(s)  = highest level L with s >= SET(L)
//   hold(s) = highest level L with s >= SET(L) - HYST(L)
//   raw  > level : escalate to raw. CRITICAL immediately; WARN/THROTTLE after
//                  ESCALATE consecutive samples.
//   hold < level : de-escalate to hold after DEESCALATE consecutive samples,
//                  only while the sensor is healthy.
//   otherwise    : hold the level, reset both counters.
// Sensor fault: sensor flag, sample timeout, out-of-range, or implausible step.
// Rejected samples never move the level. Fault clears after DEESCALATE
// consecutive good samples. While faulted the level can rise but not fall.
// tools/pm_policy_model.py implements the same rules; tb_thermal_monitor
// compares the two sample-by-sample.
// =============================================================================
module sf_thermal_monitor
  import sf_pm_pkg::*;
(
  input  logic               clk_i,
  input  logic               rst_ni,
  input  therm_cfg_t         cfg_i,
  input  logic               sample_valid_i,
  input  logic signed [15:0] sample_i,
  input  logic               sensor_fault_i,
  output therm_level_e       level_o,
  output logic               sensor_fault_o,
  output logic [3:0]         fault_reason_o,   // {delta, range, timeout, ext}
  output logic signed [15:0] last_temp_o,
  output logic               sample_seen_o
);
  // ---------------------------------------------------------------------------
  // thresholds (17-bit signed so SET-HYST cannot wrap)
  // ---------------------------------------------------------------------------
  logic signed [16:0] warn_set, thr_set, crit_set, warn_clr, thr_clr, crit_clr, s17;
  assign warn_set = 17'(cfg_i.warn_set);
  assign thr_set  = 17'(cfg_i.thr_set);
  assign crit_set = 17'(cfg_i.crit_set);
  assign warn_clr = warn_set - $signed({1'b0, cfg_i.warn_hyst});
  assign thr_clr  = thr_set  - $signed({1'b0, cfg_i.thr_hyst});
  assign crit_clr = crit_set - $signed({1'b0, cfg_i.crit_hyst});
  assign s17      = 17'(sample_i);

  therm_level_e raw_lvl, hold_lvl;
  always_comb begin
    if      (s17 >= crit_set) raw_lvl = TL_CRITICAL;
    else if (s17 >= thr_set)  raw_lvl = TL_THROTTLE;
    else if (s17 >= warn_set) raw_lvl = TL_WARN;
    else                      raw_lvl = TL_NORMAL;
    if      (s17 >= crit_clr) hold_lvl = TL_CRITICAL;
    else if (s17 >= thr_clr)  hold_lvl = TL_THROTTLE;
    else if (s17 >= warn_clr) hold_lvl = TL_WARN;
    else                      hold_lvl = TL_NORMAL;
  end

  // ---------------------------------------------------------------------------
  // plausibility
  // ---------------------------------------------------------------------------
  logic signed [15:0] prev_raw_q;
  logic               have_prev_q;
  logic signed [16:0] step;
  logic        [16:0] step_abs;
  logic               range_bad, delta_bad, sample_bad;

  assign range_bad  = (sample_i < cfg_i.range_min) || (sample_i > cfg_i.range_max);
  assign step       = s17 - 17'(prev_raw_q);
  assign step_abs   = step[16] ? 17'(-step) : 17'(step);
  assign delta_bad  = (cfg_i.max_delta != 16'd0) && have_prev_q && !range_bad &&
                      (step_abs > {1'b0, cfg_i.max_delta});
  assign sample_bad = range_bad | delta_bad | sensor_fault_i;

  logic [3:0] esc_lim, desc_lim;
  assign esc_lim  = (cfg_i.escalate   == 4'd0) ? 4'd1 : cfg_i.escalate;
  assign desc_lim = (cfg_i.deescalate == 4'd0) ? 4'd1 : cfg_i.deescalate;

  // ---------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------
  therm_level_e level_q;
  logic [3:0]   esc_cnt_q, desc_cnt_q, good_cnt_q;
  logic         fault_q;
  logic [3:0]   reason_q;
  logic [TW-1:0] since_q;
  logic         timeout_hit;

  assign timeout_hit = (cfg_i.sample_timeout != '0) && (since_q >= cfg_i.sample_timeout);

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      level_q       <= TL_NORMAL;
      esc_cnt_q     <= '0;
      desc_cnt_q    <= '0;
      good_cnt_q    <= '0;
      fault_q       <= 1'b0;
      reason_q      <= '0;
      since_q       <= '0;
      prev_raw_q    <= '0;
      have_prev_q   <= 1'b0;
      last_temp_o   <= '0;
      sample_seen_o <= 1'b0;
    end else begin
      // ------------- sample timeout -------------
      if (sample_valid_i)        since_q <= '0;
      else if (since_q != '1)    since_q <= since_q + 1'b1;

      if (timeout_hit && !sample_valid_i) begin
        fault_q     <= 1'b1;
        reason_q[1] <= 1'b1;
        good_cnt_q  <= '0;
      end
      // sensor-reported fault is honoured even without a sample strobe
      if (sensor_fault_i) begin
        fault_q     <= 1'b1;
        reason_q[0] <= 1'b1;
        good_cnt_q  <= '0;
      end

      if (sample_valid_i) begin
        if (!range_bad) begin
          prev_raw_q  <= sample_i;
          have_prev_q <= 1'b1;
        end
        if (sample_bad) begin
          fault_q    <= 1'b1;
          reason_q   <= reason_q | {delta_bad, range_bad, 1'b0, sensor_fault_i};
          good_cnt_q <= '0;
          esc_cnt_q  <= '0;
          desc_cnt_q <= '0;
        end else begin
          last_temp_o   <= sample_i;
          sample_seen_o <= 1'b1;
          // fault recovery
          if (fault_q) begin
            if (good_cnt_q + 4'd1 >= desc_lim) begin
              fault_q    <= 1'b0;
              reason_q   <= '0;
              good_cnt_q <= '0;
            end else begin
              good_cnt_q <= good_cnt_q + 4'd1;
            end
          end
          // level update
          if (raw_lvl > level_q) begin
            desc_cnt_q <= '0;
            if (raw_lvl == TL_CRITICAL || (esc_cnt_q + 4'd1 >= esc_lim)) begin
              level_q   <= raw_lvl;
              esc_cnt_q <= '0;
            end else begin
              esc_cnt_q <= esc_cnt_q + 4'd1;
            end
          end else if (hold_lvl < level_q && !fault_q) begin
            esc_cnt_q <= '0;
            if (desc_cnt_q + 4'd1 >= desc_lim) begin
              level_q    <= hold_lvl;
              desc_cnt_q <= '0;
            end else begin
              desc_cnt_q <= desc_cnt_q + 4'd1;
            end
          end else begin
            esc_cnt_q  <= '0;
            desc_cnt_q <= '0;
          end
        end
      end
    end
  end

  assign level_o        = level_q;
  assign sensor_fault_o = fault_q;
  assign fault_reason_o = reason_q;
endmodule
