// =============================================================================
// SilicaFlux-HPC  |  Project 27 POWERCLOCK  |  Aureom.AI
// sf_pm_pkg : shared types for the power / clock / thermal manager
// =============================================================================
package sf_pm_pkg;

  // ---------------------------------------------------------------------------
  // Architectural power states (visible in STATUS.STATE)
  // No power-off states exist: SilicaFlux-HPC has no power switches or
  // retention infrastructure, so "off" cannot be represented honestly.
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] {
    PM_RESET         = 3'd0,  // core held/being brought out of reset, clocks sequencing
    PM_IDLE          = 3'd1,  // clocks running, no work for IDLE_ENTER cycles
    PM_ACTIVE        = 3'd2,  // work present, full policy rate
    PM_CLOCK_IDLE    = 3'd3,  // vector + tensor unit clocks gated, issue drained
    PM_THERMAL_LIMIT = 3'd4,  // throttling active (issue rate / tensor pause / lower OPP)
    PM_FAULT         = 3'd5   // no new work accepted; firmware must FAULT_CLEAR
  } pm_state_e;

  // ---------------------------------------------------------------------------
  // Sequencer steps (STATUS.SEQ). Each step waits on an acknowledged
  // condition (never on a fixed delay alone) and has a timeout.
  // ---------------------------------------------------------------------------
  typedef enum logic [3:0] {
    SEQ_NONE        = 4'd0,
    SEQ_WAIT_LOCK   = 4'd1,   // clock source locked continuously LOCK_STABLE cycles
    SEQ_CORE_UNGATE = 4'd2,   // core clock enable on, wait ack + CLK_SETTLE
    SEQ_RST_RELEASE = 4'd3,   // release core reset, wait core alive
    SEQ_UNIT_UNGATE = 4'd4,   // unit clock enables on, wait acks + CLK_SETTLE
    SEQ_UNDRAIN     = 4'd5,   // release drain, wait drain-ack low
    SEQ_DRAIN       = 4'd6,   // request drain, wait core drained (quiescent under drain)
    SEQ_UNIT_GATE   = 4'd7,   // unit clock enables off, wait acks low
    SEQ_CORE_GATE   = 4'd8,   // core clock enable off, wait ack low
    SEQ_FC_REQ      = 4'd9,   // frequency controller request, wait ack high
    SEQ_FC_REL      = 4'd10   // release request, wait ack low
  } pm_seq_e;

  typedef enum logic [1:0] {
    TL_NORMAL   = 2'd0,
    TL_WARN     = 2'd1,
    TL_THROTTLE = 2'd2,
    TL_CRITICAL = 2'd3
  } therm_level_e;

  typedef enum logic [2:0] {
    OPP_OK                = 3'd0,
    OPP_ERR_BUSY          = 3'd1,
    OPP_ERR_UNAVAILABLE   = 3'd2,   // no frequency controller (CAP.FREQ_CTRL = 0)
    OPP_ERR_INVALID       = 3'd3,   // index >= NUM_OPP
    OPP_ERR_NOT_VALIDATED = 3'd4,   // OPP exists but is not timing-validated
    OPP_ERR_TIMEOUT       = 3'd5,
    OPP_ERR_STATE         = 3'd6    // not accepted in the current architectural state
  } opp_result_e;

  // FAULT_CAUSE bit positions
  localparam int FC_THERM_CRIT  = 0;
  localparam int FC_SENSOR      = 1;
  localparam int FC_HW_ERR      = 2;
  localparam int FC_SEQ_TIMEOUT = 3;
  localparam int FC_CLK_LOSS    = 4;
  localparam int NUM_FAULT_CAUSE = 5;

  localparam int NUM_IRQ = 10;
  localparam int IRQ_STATE_CHANGE   = 0;
  localparam int IRQ_THERM_WARN     = 1;
  localparam int IRQ_THERM_THROTTLE = 2;
  localparam int IRQ_THERM_CRIT     = 3;
  localparam int IRQ_SENSOR_FAULT   = 4;
  localparam int IRQ_HW_ERR         = 5;
  localparam int IRQ_FAULT          = 6;
  localparam int IRQ_OPP_DONE       = 7;
  localparam int IRQ_ACT_WINDOW     = 8;
  localparam int IRQ_THERM_CLEAR    = 9;

  localparam int TW = 24;  // timer width (always-on cycles)

  // ---------------------------------------------------------------------------
  // Policy configuration (always-on domain, from the register file)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic          auto_clk_idle_en;
    logic          throttle_en;
    logic          sensor_fault_action;   // 0 = throttle, 1 = fault
    logic          thermal_opp_en;
    logic          core_rst_on_clear;
    logic [15:0]   idle_enter_cyc;
    logic [15:0]   clkidle_enter_cyc;
    logic [TW-1:0] seq_timeout;
    logic [15:0]   lock_stable;
    logic [15:0]   clk_settle;
    logic [TW-1:0] therm_min_dwell;
    logic [4:0]    warn_rate;
    logic          warn_pause_tns;
    logic [4:0]    thr_rate;
    logic          thr_pause_tns;
    logic [3:0]    thermal_opp;
    logic [4:0]    window_log2;
  } pm_cfg_t;

  typedef struct packed {
    logic signed [15:0] warn_set;
    logic        [15:0] warn_hyst;
    logic signed [15:0] thr_set;
    logic        [15:0] thr_hyst;
    logic signed [15:0] crit_set;
    logic        [15:0] crit_hyst;
    logic signed [15:0] range_min;
    logic signed [15:0] range_max;
    logic        [15:0] max_delta;
    logic      [TW-1:0] sample_timeout;
    logic         [3:0] escalate;
    logic         [3:0] deescalate;
  } therm_cfg_t;

  // ---------------------------------------------------------------------------
  // Configuration bundle crossing always-on -> core (handshake CDC)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [4:0] window_log2;  // activity window 2^N core cycles
    logic [4:0] issue_rate;   // compute issue slots per 16 core cycles (1..16)
    logic       pause_tns;    // no new tensor commands
    logic       stop_new;     // no new commands on any channel
  } core_cfg_t;

  // Core-side reset value. The always-on side's "last sent" register uses the
  // same value so both ends agree after a joint reset (see CDC documentation).
  // packed order: {window_log2=16, issue_rate=16, pause_tns=0, stop_new=1}
  localparam core_cfg_t CORE_CFG_RESET = {5'd16, 5'd16, 1'b0, 1'b1};

  // ---------------------------------------------------------------------------
  // Activity snapshot crossing core -> always-on (handshake CDC)
  // ---------------------------------------------------------------------------
  typedef struct packed {
    logic [31:0] vec_busy;
    logic [31:0] tns_busy;
    logic [31:0] dma_busy;
    logic [31:0] all_idle;
    logic [31:0] qocc_sum;
    logic [31:0] stall;
    logic [15:0] seq;
    logic [15:0] dropped;
  } act_snap_t;

endpackage
