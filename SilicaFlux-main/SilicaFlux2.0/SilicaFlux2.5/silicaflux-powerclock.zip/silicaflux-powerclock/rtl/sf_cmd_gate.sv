// =============================================================================
// sf_cmd_gate : gates NEW command transfers on a valid/ready channel.
//
// * The payload is never touched (it bypasses this module entirely), so
//   throttling cannot alter data; it can only delay the start of a transfer.
// * Once dn_valid_o has been presented it is held until accepted
//   (committed_q), even if allow_i drops: the AXI-style rule "valid must not
//   be withdrawn" is preserved, so a transfer already offered to a unit is
//   never torn.
// * Requires the upstream to obey the same rule (up_valid_i stable until
//   up_ready_o); checked by assertion.
// =============================================================================
module sf_cmd_gate (
  input  logic clk_i,
  input  logic rst_ni,
  input  logic allow_i,      // a new transfer may start this cycle
  input  logic up_valid_i,
  output logic up_ready_o,
  output logic dn_valid_o,
  input  logic dn_ready_i,
  output logic stalled_o     // a valid command is being held back by the PM
);
  logic committed_q;
  logic pass;

  assign pass       = allow_i | committed_q;
  assign dn_valid_o = up_valid_i & pass;
  assign up_ready_o = dn_ready_i & pass;
  assign stalled_o  = up_valid_i & ~pass;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) committed_q <= 1'b0;
    else         committed_q <= dn_valid_o & ~dn_ready_i;
  end

`ifdef SF_ASSERT
  // upstream protocol: valid held until accepted
  a_up_valid_stable: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (up_valid_i && !up_ready_o) |=> up_valid_i)
    else $error("sf_cmd_gate: upstream withdrew valid");
  // the gate never withdraws an offered transfer
  a_dn_valid_held: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (dn_valid_o && !dn_ready_i) |=> dn_valid_o)
    else $error("sf_cmd_gate: dn_valid withdrawn before acceptance");
`endif
endmodule
