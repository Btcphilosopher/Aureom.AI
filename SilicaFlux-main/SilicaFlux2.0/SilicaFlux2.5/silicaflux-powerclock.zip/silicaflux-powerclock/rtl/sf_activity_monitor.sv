// =============================================================================
// sf_activity_monitor : windowed utilisation counters in the core domain.
// All inputs are real implemented events from the units (busy = has in-flight
// work, as defined by the unit contract in docs/02_architecture.md).
// A snapshot is produced every 2^window_log2 core cycles and handed to the
// handshake CDC. If the previous snapshot has not yet crossed, it is
// overwritten and `dropped` increments (visible to firmware, never silent).
// Changing the window length restarts the window immediately and discards
// the partial window (no snapshot is produced for it).
// =============================================================================
module sf_activity_monitor
  import sf_pm_pkg::*;
#(
  parameter int QSUM_W = 10
) (
  input  logic              clk_i,
  input  logic              rst_ni,
  input  logic [4:0]        window_log2_i,
  input  logic              vec_busy_i,
  input  logic              tns_busy_i,
  input  logic              dma_busy_i,
  input  logic              all_idle_i,
  input  logic              stall_i,
  input  logic [QSUM_W-1:0] qocc_sum_i,
  output logic              snap_valid_o,
  input  logic              snap_ready_i,
  output act_snap_t         snap_o
);
  logic [4:0]  wlog_q;
  logic [24:0] win_cnt_q;
  logic [31:0] vec_acc_q, tns_acc_q, dma_acc_q, idle_acc_q, qocc_acc_q, stall_acc_q;
  logic [15:0] seq_q, dropped_q;
  logic        win_end;
  logic        win_restart;
  logic [4:0]  wlog_new;
  logic [24:0] win_last;

  function automatic logic [4:0] clamp_wlog(input logic [4:0] w);
    if (w < 5'd4)       clamp_wlog = 5'd4;
    else if (w > 5'd24) clamp_wlog = 5'd24;
    else                clamp_wlog = w;
  endfunction

  assign wlog_new    = clamp_wlog(window_log2_i);
  assign win_restart = (wlog_new != wlog_q);
  assign win_last    = (25'd1 << wlog_q) - 25'd1;
  assign win_end     = (win_cnt_q == win_last) && !win_restart;

  // saturating accumulate of queue occupancy
  logic [32:0] qocc_next;
  assign qocc_next = {1'b0, qocc_acc_q} + {{(33-QSUM_W){1'b0}}, qocc_sum_i};

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      wlog_q       <= 5'd16;
      win_cnt_q    <= '0;
      vec_acc_q    <= '0;
      tns_acc_q    <= '0;
      dma_acc_q    <= '0;
      idle_acc_q   <= '0;
      qocc_acc_q   <= '0;
      stall_acc_q  <= '0;
      seq_q        <= '0;
      dropped_q    <= '0;
      snap_valid_o <= 1'b0;
      snap_o       <= '0;
    end else begin
      if (win_end) begin
        snap_o.vec_busy <= vec_acc_q   + 32'(vec_busy_i);
        snap_o.tns_busy <= tns_acc_q   + 32'(tns_busy_i);
        snap_o.dma_busy <= dma_acc_q   + 32'(dma_busy_i);
        snap_o.all_idle <= idle_acc_q  + 32'(all_idle_i);
        snap_o.qocc_sum <= qocc_next[32] ? 32'hFFFF_FFFF : qocc_next[31:0];
        snap_o.stall    <= stall_acc_q + 32'(stall_i);
        snap_o.seq      <= seq_q + 16'd1;
        seq_q           <= seq_q + 16'd1;
        if (snap_valid_o && !snap_ready_i) begin
          if (dropped_q != 16'hFFFF) dropped_q <= dropped_q + 16'd1;
          snap_o.dropped <= (dropped_q != 16'hFFFF) ? dropped_q + 16'd1 : dropped_q;
        end else begin
          snap_o.dropped <= dropped_q;
        end
        snap_valid_o <= 1'b1;
        vec_acc_q    <= '0;
        tns_acc_q    <= '0;
        dma_acc_q    <= '0;
        idle_acc_q   <= '0;
        qocc_acc_q   <= '0;
        stall_acc_q  <= '0;
        win_cnt_q    <= '0;
      end else if (win_restart) begin
        if (snap_valid_o && snap_ready_i) snap_valid_o <= 1'b0;
        vec_acc_q    <= '0;
        tns_acc_q    <= '0;
        dma_acc_q    <= '0;
        idle_acc_q   <= '0;
        qocc_acc_q   <= '0;
        stall_acc_q  <= '0;
        win_cnt_q    <= '0;
        wlog_q       <= wlog_new;
      end else begin
        if (snap_valid_o && snap_ready_i) snap_valid_o <= 1'b0;
        win_cnt_q   <= win_cnt_q + 25'd1;
        vec_acc_q   <= vec_acc_q   + 32'(vec_busy_i);
        tns_acc_q   <= tns_acc_q   + 32'(tns_busy_i);
        dma_acc_q   <= dma_acc_q   + 32'(dma_busy_i);
        idle_acc_q  <= idle_acc_q  + 32'(all_idle_i);
        qocc_acc_q  <= qocc_next[32] ? 32'hFFFF_FFFF : qocc_next[31:0];
        stall_acc_q <= stall_acc_q + 32'(stall_i);
      end
    end
  end
endmodule
