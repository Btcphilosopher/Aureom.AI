// =============================================================================
// SilicaFlux-HPC  |  Project 27 POWERCLOCK  |  Aureom.AI
// silicaflux_power_manager : dynamic power and thermal management subsystem
//
// Clock domains
//   clk_aon_i        always-on reference clock (never gated or reconfigured):
//                    FSM, sequencer, thermal monitor, register file, IRQ.
//   clk_core_root_i  core clock source output (PLL/MMCM or fixed oscillator).
//                    Used ONLY to synchronise the global core clock enable.
//   clk_core_o       core clock after the global gate (root of the core domain).
//   clk_vec_o/clk_tns_o  per-unit gated clocks derived from clk_core_o
//                    (synchronous to clk_core_o; no CDC between them).
//
// What this block controls (see docs/01_audit.md):
//   * global core clock enable (during reset sequencing / frequency change)
//   * vector and tensor unit clock enables (CLOCK_IDLE)
//   * core-domain reset sequencing
//   * command issue rate / tensor pause / stop-new-work (thermal throttling)
//   * operating-point (frequency) requests to an EXTERNAL frequency controller,
//     only when HAS_FREQ_CTRL=1 and only to OPPs marked validated
// What it does NOT control: supply voltage (no regulator/PMIC interface
// exists; CAP.VOLTAGE_CTRL = CAP.DVFS = 0) and power switching (no power
// switches / retention exist; no power-off states are implemented).
// =============================================================================
module silicaflux_power_manager
  import sf_pm_pkg::*;
#(
  parameter bit                 HAS_FREQ_CTRL     = 1'b0,
  parameter int                 NUM_OPP           = 1,
  parameter logic [15:0]        OPP_VALIDATED     = 16'h0001,
  parameter logic [511:0]       OPP_FREQ_KHZ      = '0,  // 16 x 32-bit kHz, entry i at [32*i +: 32]
  parameter int                 RESET_OPP         = 0,
  parameter bit                 SENSOR_CALIBRATED = 1'b0,
  parameter logic signed [15:0] CRIT_HARD_LIMIT   = 16'sd1840,
  parameter int                 QW                = 8
) (
  // ---------------- clocks / reset ----------------
  input  logic               clk_aon_i,
  input  logic               rst_aon_ni,        // power-on reset (async)
  input  logic               clk_core_root_i,
  input  logic               test_en_i,         // scan: force clocks on, bypass reset syncs
  output logic               clk_core_o,
  output logic               rst_core_no,       // synchronised to clk_core_o
  output logic               clk_vec_o,
  output logic               clk_tns_o,

  // ---------------- APB3 (clk_aon_i) ----------------
  input  logic               psel_i,
  input  logic               penable_i,
  input  logic               pwrite_i,
  input  logic [7:0]         paddr_i,
  input  logic [31:0]        pwdata_i,
  output logic [31:0]        prdata_o,
  output logic               pready_o,
  output logic               pslverr_o,
  output logic               irq_o,

  // ---------------- temperature sensor (clk_aon_i) ----------------
  input  logic               temp_valid_i,
  input  logic signed [15:0] temp_data_i,      // 1/16 degC
  input  logic               temp_fault_i,
  output logic               emergency_shutdown_req_o,

  // ---------------- frequency controller (async handshake) ----------------
  output logic               fc_req_o,
  output logic [3:0]         fc_opp_o,         // stable while fc_req_o is high
  input  logic               fc_ack_i,
  input  logic               pll_locked_i,     // tie 1 for a fixed, always-valid clock

  // ---------------- core-domain unit interface (clk_core_o) ----------------
  input  logic               vec_busy_i,
  input  logic               tns_busy_i,
  input  logic               dma_busy_i,
  input  logic [QW-1:0]      vec_qocc_i,
  input  logic [QW-1:0]      tns_qocc_i,
  input  logic [QW-1:0]      dma_qocc_i,
  input  logic [7:0]         hw_err_i,
  input  logic               wake_i,
  input  logic               vec_up_valid_i,
  output logic               vec_up_ready_o,
  output logic               vec_dn_valid_o,
  input  logic               vec_dn_ready_i,
  input  logic               tns_up_valid_i,
  output logic               tns_up_ready_o,
  output logic               tns_dn_valid_o,
  input  logic               tns_dn_ready_i,
  input  logic               dma_up_valid_i,
  output logic               dma_up_ready_o,
  output logic               dma_dn_valid_o,
  input  logic               dma_dn_ready_i
);
  // ===========================================================================
  // always-on side signals
  // ===========================================================================
  pm_cfg_t      cfg;
  therm_cfg_t   tcfg;
  therm_level_e level;
  pm_state_e    state;
  pm_seq_e      seq;
  core_cfg_t    core_cfg;
  opp_result_e  opp_result;
  logic         sensor_fault, sample_seen, emergency;
  logic [3:0]   fault_reason, cur_opp, fw_opp, opp_target;
  logic signed [15:0] last_temp;
  logic         cmd_fault_clear, cmd_wake, cmd_opp_go;
  logic [7:0]   errclr_pulse, fatal_mask;
  logic         core_clk_en_req, core_rst_req, vec_en_req, tns_en_req, drain_req;
  logic         opp_busy, opp_unc, opp_done, fault_active, throttle_active;
  logic         state_change, fault_enter;
  logic [NUM_FAULT_CAUSE-1:0] fault_cause;
  logic [15:0]  therm_entries, fault_entries;

  // synchronised status
  logic pll_locked_s, fc_ack_s, core_clk_en_ack_s;
  logic core_idle_s, core_pending_s, drain_ack_s, vec_ack_s, tns_ack_s, core_alive_s;
  logic [7:0] err_s;
  logic hw_err_fatal_q;

  // CDC endpoints on the always-on side are reset whenever the core reset is
  // requested, so both ends of every handshake are reset together (RDC rule).
  // core_rst_req is a flop (async-set by rst_aon_ni): glitch-free reset source.
  logic cdc_aon_rst_n;
  assign cdc_aon_rst_n = ~core_rst_req;

  // ===========================================================================
  // core clock root: global gate with enable synchronised in the root domain
  // ===========================================================================
  logic rst_root_n, core_clk_en_root;

  sf_reset_sync u_rst_root (.clk_i(clk_core_root_i), .rst_ni(rst_aon_ni),
                            .test_mode_i(test_en_i), .rst_no(rst_root_n));
  sf_cdc_sync_2ff #(.WIDTH(1), .RESET_VAL(1'b0)) u_sync_core_en (
    .clk_i(clk_core_root_i), .rst_ni(rst_root_n), .d_i(core_clk_en_req), .q_o(core_clk_en_root));
  sf_clock_gate u_cg_core (.clk_i(clk_core_root_i), .en_i(core_clk_en_root),
                           .test_en_i, .clk_o(clk_core_o));

  // core-domain reset: async assert from the always-on request, sync release
  sf_reset_sync u_rst_core (.clk_i(clk_core_o), .rst_ni(~core_rst_req),
                            .test_mode_i(test_en_i), .rst_no(rst_core_no));

  // ===========================================================================
  // synchronisers into the always-on domain
  // ===========================================================================
  sf_cdc_sync_2ff #(.WIDTH(3), .RESET_VAL(3'b000)) u_sync_ext (
    .clk_i(clk_aon_i), .rst_ni(rst_aon_ni),
    .d_i({pll_locked_i, fc_ack_i, core_clk_en_root}),
    .q_o({pll_locked_s, fc_ack_s, core_clk_en_ack_s}));

  logic core_idle_c, core_pending_c, drain_ack_c, vec_ack_c, tns_ack_c, core_alive_c;
  logic [7:0] err_c;
  sf_cdc_sync_2ff #(.WIDTH(6), .RESET_VAL(6'b000000)) u_sync_core_status (
    .clk_i(clk_aon_i), .rst_ni(cdc_aon_rst_n),
    .d_i({core_idle_c, core_pending_c, drain_ack_c, vec_ack_c, tns_ack_c, core_alive_c}),
    .q_o({core_idle_s, core_pending_s, drain_ack_s, vec_ack_s, tns_ack_s, core_alive_s}));
  sf_cdc_sync_2ff #(.WIDTH(8), .RESET_VAL(8'h00)) u_sync_err (
    .clk_i(clk_aon_i), .rst_ni(cdc_aon_rst_n), .d_i(err_c), .q_o(err_s));

  always_ff @(posedge clk_aon_i or negedge rst_aon_ni) begin
    if (!rst_aon_ni) hw_err_fatal_q <= 1'b0;
    else             hw_err_fatal_q <= |(err_s & fatal_mask);
  end

  // ===========================================================================
  // thermal monitor
  // ===========================================================================
  sf_thermal_monitor u_therm (
    .clk_i(clk_aon_i), .rst_ni(rst_aon_ni), .cfg_i(tcfg),
    .sample_valid_i(temp_valid_i), .sample_i(temp_data_i), .sensor_fault_i(temp_fault_i),
    .level_o(level), .sensor_fault_o(sensor_fault), .fault_reason_o(fault_reason),
    .last_temp_o(last_temp), .sample_seen_o(sample_seen));

  // ===========================================================================
  // FSM / sequencer
  // ===========================================================================
  sf_pm_fsm #(.HAS_FREQ_CTRL(HAS_FREQ_CTRL), .NUM_OPP(NUM_OPP),
              .OPP_VALIDATED(OPP_VALIDATED), .RESET_OPP(RESET_OPP)) u_fsm (
    .clk_i(clk_aon_i), .rst_ni(rst_aon_ni), .cfg_i(cfg),
    .cmd_fault_clear_i(cmd_fault_clear), .cmd_wake_i(cmd_wake),
    .cmd_opp_go_i(cmd_opp_go), .opp_target_i(opp_target),
    .therm_level_i(level), .sensor_fault_i(sensor_fault), .hw_err_fatal_i(hw_err_fatal_q),
    .pll_locked_i(pll_locked_s), .core_clk_en_ack_i(core_clk_en_ack_s),
    .core_alive_i(core_alive_s), .vec_en_ack_i(vec_ack_s), .tns_en_ack_i(tns_ack_s),
    .drain_ack_i(drain_ack_s), .core_idle_i(core_idle_s), .core_pending_i(core_pending_s),
    .fc_ack_i(fc_ack_s),
    .core_clk_en_o(core_clk_en_req), .core_rst_req_o(core_rst_req),
    .vec_clk_en_o(vec_en_req), .tns_clk_en_o(tns_en_req), .drain_req_o(drain_req),
    .fc_req_o, .fc_opp_o, .core_cfg_o(core_cfg), .emergency_req_o(emergency),
    .state_o(state), .seq_o(seq), .cur_opp_o(cur_opp), .fw_opp_o(fw_opp),
    .opp_busy_o(opp_busy), .opp_uncertain_o(opp_unc), .opp_result_o(opp_result),
    .opp_done_o(opp_done), .fault_cause_o(fault_cause), .fault_active_o(fault_active),
    .throttle_active_o(throttle_active), .state_change_o(state_change),
    .fault_enter_o(fault_enter), .therm_entries_o(therm_entries),
    .fault_entries_o(fault_entries));

  assign emergency_shutdown_req_o = emergency;

  // ===========================================================================
  // handshake CDCs
  // ===========================================================================
  // (1) core configuration: always-on -> core, sent whenever it changes
  core_cfg_t cfg_sent_q, cfg_core;
  logic      cfg_src_ready, cfg_core_valid;
  logic      cfg_send;
  assign cfg_send = (core_cfg != cfg_sent_q);
  always_ff @(posedge clk_aon_i or negedge cdc_aon_rst_n) begin
    if (!cdc_aon_rst_n)                 cfg_sent_q <= CORE_CFG_RESET;
    else if (cfg_send && cfg_src_ready) cfg_sent_q <= core_cfg;
  end
  sf_cdc_handshake #(.WIDTH($bits(core_cfg))) u_hs_cfg (
    .src_clk_i(clk_aon_i), .src_rst_ni(cdc_aon_rst_n),
    .src_valid_i(cfg_send), .src_ready_o(cfg_src_ready), .src_data_i(core_cfg),
    .dst_clk_i(clk_core_o), .dst_rst_ni(rst_core_no),
    .dst_valid_o(cfg_core_valid), .dst_data_o(cfg_core));

  // (2) error-flag clear mask: always-on -> core
  logic [7:0] errclr_pend_q, errclr_core_mask;
  logic       errclr_ready, errclr_core_valid;
  always_ff @(posedge clk_aon_i or negedge cdc_aon_rst_n) begin
    if (!cdc_aon_rst_n) errclr_pend_q <= '0;
    else if ((|errclr_pend_q) && errclr_ready) errclr_pend_q <= errclr_pulse;
    else                                        errclr_pend_q <= errclr_pend_q | errclr_pulse;
  end
  sf_cdc_handshake #(.WIDTH(8)) u_hs_errclr (
    .src_clk_i(clk_aon_i), .src_rst_ni(cdc_aon_rst_n),
    .src_valid_i(|errclr_pend_q), .src_ready_o(errclr_ready), .src_data_i(errclr_pend_q),
    .dst_clk_i(clk_core_o), .dst_rst_ni(rst_core_no),
    .dst_valid_o(errclr_core_valid), .dst_data_o(errclr_core_mask));

  // (3) activity snapshot: core -> always-on
  act_snap_t snap_core, snap_aon;
  logic      snap_core_valid, snap_core_ready, snap_aon_valid;
  sf_cdc_handshake #(.WIDTH($bits(snap_core))) u_hs_snap (
    .src_clk_i(clk_core_o), .src_rst_ni(rst_core_no),
    .src_valid_i(snap_core_valid), .src_ready_o(snap_core_ready), .src_data_i(snap_core),
    .dst_clk_i(clk_aon_i), .dst_rst_ni(cdc_aon_rst_n),
    .dst_valid_o(snap_aon_valid), .dst_data_o(snap_aon));

  // ===========================================================================
  // core-domain shim
  // ===========================================================================
  core_cfg_t cfg_active_unused;
  sf_pm_core_shim #(.QW(QW)) u_shim (
    .clk_i(clk_core_o), .rst_ni(rst_core_no), .test_en_i,
    .drain_req_ai(drain_req), .vec_en_ai(vec_en_req), .tns_en_ai(tns_en_req),
    .cfg_valid_i(cfg_core_valid), .cfg_i(cfg_core),
    .errclr_valid_i(errclr_core_valid), .errclr_mask_i(errclr_core_mask),
    .clk_vec_o, .clk_tns_o,
    .vec_busy_i, .tns_busy_i, .dma_busy_i, .vec_qocc_i, .tns_qocc_i, .dma_qocc_i,
    .hw_err_i, .wake_i,
    .vec_up_valid_i, .vec_up_ready_o, .vec_dn_valid_o, .vec_dn_ready_i,
    .tns_up_valid_i, .tns_up_ready_o, .tns_dn_valid_o, .tns_dn_ready_i,
    .dma_up_valid_i, .dma_up_ready_o, .dma_dn_valid_o, .dma_dn_ready_i,
    .core_idle_o(core_idle_c), .core_pending_o(core_pending_c), .drain_ack_o(drain_ack_c),
    .vec_en_ack_o(vec_ack_c), .tns_en_ack_o(tns_ack_c), .core_alive_o(core_alive_c),
    .err_sticky_o(err_c),
    .snap_valid_o(snap_core_valid), .snap_ready_i(snap_core_ready), .snap_o(snap_core),
    .cfg_active_o(cfg_active_unused));

  // ===========================================================================
  // register file
  // ===========================================================================
  sf_pm_regfile #(.HAS_FREQ_CTRL(HAS_FREQ_CTRL), .NUM_OPP(NUM_OPP),
                  .OPP_VALIDATED(OPP_VALIDATED), .OPP_FREQ_KHZ(OPP_FREQ_KHZ),
                  .RESET_OPP(RESET_OPP), .SENSOR_CALIBRATED(SENSOR_CALIBRATED),
                  .CRIT_HARD_LIMIT(CRIT_HARD_LIMIT)) u_regs (
    .clk_i(clk_aon_i), .rst_ni(rst_aon_ni),
    .psel_i, .penable_i, .pwrite_i, .paddr_i, .pwdata_i, .prdata_o, .pready_o, .pslverr_o,
    .cfg_o(cfg), .tcfg_o(tcfg), .hw_err_fatal_mask_o(fatal_mask),
    .cmd_fault_clear_o(cmd_fault_clear), .cmd_wake_o(cmd_wake), .cmd_opp_go_o(cmd_opp_go),
    .opp_target_o(opp_target), .errclr_pulse_o(errclr_pulse),
    .state_i(state), .seq_i(seq), .level_i(level), .sensor_fault_i(sensor_fault),
    .fault_reason_i(fault_reason), .last_temp_i(last_temp), .sample_seen_i(sample_seen),
    .emergency_i(emergency), .core_clk_en_ack_i(core_clk_en_ack_s),
    .vec_clk_on_i(vec_ack_s), .tns_clk_on_i(tns_ack_s), .drain_i(drain_req),
    .core_alive_i(core_alive_s), .pll_locked_i(pll_locked_s),
    .throttle_active_i(throttle_active), .stop_new_i(core_cfg.stop_new),
    .fault_active_i(fault_active), .cur_opp_i(cur_opp), .fw_opp_i(fw_opp),
    .opp_result_i(opp_result), .opp_busy_i(opp_busy), .opp_uncertain_i(opp_unc),
    .opp_done_i(opp_done), .fault_cause_i(fault_cause), .state_change_i(state_change),
    .fault_enter_i(fault_enter), .hw_err_i(err_s), .snap_valid_i(snap_aon_valid),
    .snap_i(snap_aon), .therm_entries_i(therm_entries), .fault_entries_i(fault_entries),
    .irq_o);

  // synopsys translate_off
  initial begin
    if (NUM_OPP < 1 || NUM_OPP > 16) $fatal(1, "NUM_OPP must be 1..16");
    if (RESET_OPP >= NUM_OPP)        $fatal(1, "RESET_OPP out of range");
    if (!OPP_VALIDATED[RESET_OPP])   $fatal(1, "RESET_OPP must be a validated operating point");
  end
  // synopsys translate_on
endmodule
