// =============================================================================
// sf_clock_gate : the ONLY place a clock is gated in POWERCLOCK.
//
// Never gate a clock with a plain AND/OR in RTL. Select the implementation:
//   +define+SF_CLKGATE_XILINX_BUFGCE : Xilinx BUFGCE global buffer with clock
//        enable (7-series / UltraScale). en_i MUST be synchronous to clk_i;
//        POWERCLOCK always synchronises enables in the gated clock's source
//        domain before this cell. (UltraScale integrators may additionally set
//        CE_TYPE per UG572; not set here so one netlist serves both families.)
//   +define+SF_CLKGATE_ASIC_ICG : instantiates sf_icg_lib_cell, a 4-pin wrapper
//        (CK, E, SE, GCK) the integrator maps onto the target library's
//        latch-based integrated clock-gating cell.
//   neither, simulation      : behavioural latch+AND model of an ICG
//        (functionally identical to a library ICG, glitch-free by construction).
//   neither, SYNTHESIS defined: deliberately instantiates an undefined module
//        so synthesis fails loudly instead of inferring a latch-based gate.
// =============================================================================
module sf_clock_gate (
  input  logic clk_i,
  input  logic en_i,       // functional enable, synchronous to clk_i
  input  logic test_en_i,  // scan / test override (forces clock on)
  output logic clk_o
);
`ifdef SF_CLKGATE_XILINX_BUFGCE
  BUFGCE u_bufgce (.I(clk_i), .CE(en_i | test_en_i), .O(clk_o));
`elsif SF_CLKGATE_ASIC_ICG
  sf_icg_lib_cell u_icg (.CK(clk_i), .E(en_i), .SE(test_en_i), .GCK(clk_o));
`else
  `ifdef SYNTHESIS
  sf_clkgate_target_not_selected u_select_SF_CLKGATE_XILINX_BUFGCE_or_SF_CLKGATE_ASIC_ICG ();
  `else
  // Behavioural ICG: enable latched while the clock is low, so the gated clock
  // can only start or stop on a full low phase -> no runt pulses.
  logic en_latched;
  always_latch begin
    if (!clk_i) en_latched = en_i | test_en_i;
  end
  assign clk_o = clk_i & en_latched;
  `endif
`endif
endmodule
