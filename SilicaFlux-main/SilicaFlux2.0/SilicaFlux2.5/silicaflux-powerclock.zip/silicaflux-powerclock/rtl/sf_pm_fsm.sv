// =============================================================================
// sf_pm_fsm : architectural power-state machine and clock/reset/frequency
// sequencer. Always-on domain. All inputs from other domains arrive already
// synchronised (single-bit levels).
//
// Two layers:
//   state_q : architectural state (RESET IDLE ACTIVE CLOCK_IDLE THERMAL_LIMIT FAULT)
//   seq_q   : sequencer step; every step waits on an ACKNOWLEDGED condition
//             with a timeout (SEQ_TIMEOUT) -> FAULT(SEQ_TIMEOUT).
//
// Sequences (kind_q):
//   K_RESET  : WAIT_LOCK -> CORE_UNGATE -> [RST_RELEASE] -> UNIT_UNGATE -> UNDRAIN
//   K_GATE   : DRAIN -> UNIT_GATE                     (enter CLOCK_IDLE; drain held)
//              DRAIN -> UNDRAIN  if work arrived      (abort to ACTIVE)
//   K_UNGATE : UNIT_UNGATE -> UNDRAIN                 (leave CLOCK_IDLE)
//   K_FREQ   : DRAIN -> CORE_GATE -> FC_REQ -> FC_REL -> WAIT_LOCK
//              -> CORE_UNGATE -> UNDRAIN              (operating-point change)
//
// Protective actions (stop_new to the core, emergency shutdown request) are
// derived directly from the thermal/fault conditions every cycle and do not
// wait for a sequence to finish. The architectural transition to FAULT is
// taken at the next sequencer-idle point (each sequence is bounded by the
// timeout), except clock-lock loss which aborts any sequence immediately.
//
// There is NO voltage control in this revision (no regulator/PMIC interface
// exists): DVFS is reported unavailable and only frequency / clock-enable
// management is implemented. Frequency control itself is only enabled when
// the integrator sets HAS_FREQ_CTRL=1 and connects a real clock controller.
// =============================================================================
module sf_pm_fsm
  import sf_pm_pkg::*;
#(
  parameter bit          HAS_FREQ_CTRL = 1'b0,
  parameter int          NUM_OPP       = 1,
  parameter logic [15:0] OPP_VALIDATED = 16'h0001,
  parameter int          RESET_OPP     = 0
) (
  input  logic          clk_i,
  input  logic          rst_ni,
  input  pm_cfg_t       cfg_i,

  input  logic          cmd_fault_clear_i,
  input  logic          cmd_wake_i,
  input  logic          cmd_opp_go_i,
  input  logic [3:0]    opp_target_i,

  input  therm_level_e  therm_level_i,
  input  logic          sensor_fault_i,
  input  logic          hw_err_fatal_i,

  // synchronised status
  input  logic          pll_locked_i,
  input  logic          core_clk_en_ack_i,
  input  logic          core_alive_i,
  input  logic          vec_en_ack_i,
  input  logic          tns_en_ack_i,
  input  logic          drain_ack_i,
  input  logic          core_idle_i,
  input  logic          core_pending_i,
  input  logic          fc_ack_i,

  // controls
  output logic          core_clk_en_o,
  output logic          core_rst_req_o,
  output logic          vec_clk_en_o,
  output logic          tns_clk_en_o,
  output logic          drain_req_o,
  output logic          fc_req_o,
  output logic [3:0]    fc_opp_o,
  output core_cfg_t     core_cfg_o,
  output logic          emergency_req_o,

  // status
  output pm_state_e     state_o,
  output pm_seq_e       seq_o,
  output logic [3:0]    cur_opp_o,
  output logic [3:0]    fw_opp_o,
  output logic          opp_busy_o,
  output logic          opp_uncertain_o,
  output opp_result_e   opp_result_o,
  output logic          opp_done_o,
  output logic [NUM_FAULT_CAUSE-1:0] fault_cause_o,
  output logic          fault_active_o,
  output logic          throttle_active_o,
  output logic          state_change_o,
  output logic          fault_enter_o,
  output logic [15:0]   therm_entries_o,
  output logic [15:0]   fault_entries_o
);
  typedef enum logic [2:0] {K_NONE, K_RESET, K_GATE, K_UNGATE, K_FREQ} kind_e;

  // ---------------------------------------------------------------------------
  // registers
  // ---------------------------------------------------------------------------
  pm_state_e   state_q, state_d, dest_q, dest_d;
  pm_seq_e     seq_q, seq_d;
  kind_e       kind_q, kind_d;
  logic [3:0]  target_q, target_d, cur_opp_q, cur_opp_d, fw_opp_q, fw_opp_d;
  logic        opp_busy_q, opp_busy_d, opp_unc_q, opp_unc_d, opp_done_d;
  opp_result_e opp_result_q, opp_result_d;
  logic        core_clk_en_q, core_clk_en_d, core_rst_req_q, core_rst_req_d;
  logic        vec_en_q, vec_en_d, tns_en_q, tns_en_d, drain_q, drain_d;
  logic        fc_req_q, fc_req_d;
  logic [3:0]  fc_opp_q, fc_opp_d;
  logic [NUM_FAULT_CAUSE-1:0] cause_q, cause_d;
  logic        emerg_q, emerg_d;
  logic        wake_q, wake_d;
  logic [TW-1:0] step_cnt_q, stable_cnt_q, dwell_cnt_q;
  logic [15:0] idle_cnt_q, therm_entries_q, fault_entries_q;
  core_cfg_t   core_cfg_q, core_cfg_d;

  // ---------------------------------------------------------------------------
  // derived conditions
  // ---------------------------------------------------------------------------
  logic crit, throttle_cond, fault_cond, timeout, lock_check_en, dwell_done;
  logic [NUM_FAULT_CAUSE-1:0] cause_now;
  logic [TW-1:0] to_lim;

  assign crit          = (therm_level_i == TL_CRITICAL);
  assign throttle_cond = cfg_i.throttle_en &
                         ((therm_level_i >= TL_THROTTLE) |
                          (sensor_fault_i & ~cfg_i.sensor_fault_action));
  always_comb begin
    cause_now                 = '0;
    cause_now[FC_THERM_CRIT]  = crit;
    cause_now[FC_SENSOR]      = sensor_fault_i & cfg_i.sensor_fault_action;
    cause_now[FC_HW_ERR]      = hw_err_fatal_i;
  end
  assign fault_cond    = |cause_now;
  assign to_lim        = (cfg_i.seq_timeout == '0) ? '1 : cfg_i.seq_timeout;
  assign timeout       = (step_cnt_q >= to_lim);
  assign dwell_done    = (dwell_cnt_q >= cfg_i.therm_min_dwell);

  // The clock source may legitimately be unlocked only while we hold the core
  // clock off for a frequency change, before lock has been established in
  // RESET, or in FAULT (recovery goes through RESET, which waits for lock).
  assign lock_check_en = (state_q != PM_FAULT) &&
                         !((state_q == PM_RESET) && (seq_q == SEQ_NONE || seq_q == SEQ_WAIT_LOCK)) &&
                         !((kind_q == K_FREQ) &&
                           (seq_q == SEQ_FC_REQ || seq_q == SEQ_FC_REL || seq_q == SEQ_WAIT_LOCK));

  function automatic opp_result_e opp_check(input logic [3:0] t);
    if (!HAS_FREQ_CTRL)          opp_check = OPP_ERR_UNAVAILABLE;
    else if (32'(t) >= NUM_OPP)  opp_check = OPP_ERR_INVALID;
    else if (!OPP_VALIDATED[t])  opp_check = OPP_ERR_NOT_VALIDATED;
    else                         opp_check = OPP_OK;
  endfunction

  logic need_thermal_opp;
  assign need_thermal_opp = HAS_FREQ_CTRL && cfg_i.thermal_opp_en && throttle_cond &&
                            (opp_check(cfg_i.thermal_opp) == OPP_OK) &&
                            (cfg_i.thermal_opp < cur_opp_q);

  // ---------------------------------------------------------------------------
  // next-state logic
  // ---------------------------------------------------------------------------
  logic opp_taken;

  always_comb begin
    state_d        = state_q;
    seq_d          = seq_q;
    kind_d         = kind_q;
    dest_d         = dest_q;
    target_d       = target_q;
    cur_opp_d      = cur_opp_q;
    fw_opp_d       = fw_opp_q;
    opp_busy_d     = opp_busy_q;
    opp_unc_d      = opp_unc_q;
    opp_result_d   = opp_result_q;
    opp_done_d     = 1'b0;
    core_clk_en_d  = core_clk_en_q;
    core_rst_req_d = core_rst_req_q;
    vec_en_d       = vec_en_q;
    tns_en_d       = tns_en_q;
    drain_d        = drain_q;
    fc_req_d       = fc_req_q;
    fc_opp_d       = fc_opp_q;
    cause_d        = cause_q;
    emerg_d        = emerg_q | crit;
    wake_d         = wake_q | cmd_wake_i;
    opp_taken      = 1'b0;

    if (lock_check_en && !pll_locked_i) begin
      // ---------------- clock lost: stop the core clock immediately -------
      core_clk_en_d        = 1'b0;
      fc_req_d             = 1'b0;
      seq_d                = SEQ_NONE;
      kind_d               = K_NONE;
      state_d              = PM_FAULT;
      cause_d[FC_CLK_LOSS] = 1'b1;
      if (opp_busy_q) begin
        opp_busy_d   = 1'b0;
        opp_result_d = OPP_ERR_TIMEOUT;
        opp_done_d   = 1'b1;
      end
    end else begin
      unique case (seq_q)
        // =====================================================================
        SEQ_NONE: begin
          unique case (state_q)
            PM_RESET: begin
              kind_d = K_RESET;
              seq_d  = SEQ_WAIT_LOCK;
              dest_d = PM_IDLE;
            end
            PM_FAULT: begin
              if (cmd_fault_clear_i && !fault_cond) begin
                state_d = PM_RESET;
                cause_d = '0;
                emerg_d = 1'b0;
                wake_d  = 1'b0;
                if (cfg_i.core_rst_on_clear) core_rst_req_d = 1'b1;
              end
            end
            default: begin  // IDLE / ACTIVE / CLOCK_IDLE / THERMAL_LIMIT
              if (fault_cond) begin
                state_d = PM_FAULT;
                cause_d = cause_q | cause_now;
              end else if (state_q == PM_CLOCK_IDLE) begin
                if (core_pending_i || wake_q || cmd_wake_i) begin
                  kind_d = K_UNGATE;
                  seq_d  = SEQ_UNIT_UNGATE;
                  dest_d = throttle_cond ? PM_THERMAL_LIMIT : PM_ACTIVE;
                end
              end else if (throttle_cond && state_q != PM_THERMAL_LIMIT) begin
                state_d = PM_THERMAL_LIMIT;
              end else if (state_q == PM_THERMAL_LIMIT) begin
                if (need_thermal_opp) begin
                  kind_d   = K_FREQ;
                  seq_d    = SEQ_DRAIN;
                  target_d = cfg_i.thermal_opp;
                  dest_d   = PM_THERMAL_LIMIT;
                end else if (!throttle_cond && dwell_done) begin
                  if (HAS_FREQ_CTRL && (cur_opp_q != fw_opp_q)) begin
                    kind_d   = K_FREQ;     // restore the firmware operating point
                    seq_d    = SEQ_DRAIN;
                    target_d = fw_opp_q;
                    dest_d   = PM_ACTIVE;
                  end else begin
                    state_d = PM_ACTIVE;
                  end
                end
              end else if (cmd_opp_go_i && (opp_check(opp_target_i) == OPP_OK)) begin
                opp_taken = 1'b1;
                if (opp_target_i == cur_opp_q) begin
                  opp_result_d = OPP_OK;      // already there: no-op
                  opp_done_d   = 1'b1;
                  fw_opp_d     = opp_target_i;
                end else begin
                  kind_d     = K_FREQ;
                  seq_d      = SEQ_DRAIN;
                  target_d   = opp_target_i;
                  dest_d     = state_q;
                  opp_busy_d = 1'b1;
                end
              end else if (state_q == PM_ACTIVE && core_idle_i &&
                           idle_cnt_q >= cfg_i.idle_enter_cyc) begin
                state_d = PM_IDLE;
              end else if (state_q == PM_IDLE && !core_idle_i) begin
                state_d = PM_ACTIVE;
              end else if (state_q == PM_IDLE && cfg_i.auto_clk_idle_en && core_idle_i &&
                           !wake_q && idle_cnt_q >= cfg_i.clkidle_enter_cyc) begin
                kind_d = K_GATE;
                seq_d  = SEQ_DRAIN;
                dest_d = PM_CLOCK_IDLE;
              end
            end
          endcase
        end
        // =====================================================================
        SEQ_WAIT_LOCK: begin
          if (pll_locked_i && stable_cnt_q >= TW'(cfg_i.lock_stable)) seq_d = SEQ_CORE_UNGATE;
        end
        SEQ_CORE_UNGATE: begin
          if (core_clk_en_ack_i && stable_cnt_q >= TW'(cfg_i.clk_settle)) begin
            if (kind_q == K_RESET) seq_d = core_rst_req_q ? SEQ_RST_RELEASE : SEQ_UNIT_UNGATE;
            else                   seq_d = SEQ_UNDRAIN;
          end
        end
        SEQ_RST_RELEASE: begin
          if (core_alive_i) seq_d = SEQ_UNIT_UNGATE;
        end
        SEQ_UNIT_UNGATE: begin
          if (vec_en_ack_i && tns_en_ack_i && stable_cnt_q >= TW'(cfg_i.clk_settle))
            seq_d = SEQ_UNDRAIN;
        end
        SEQ_UNDRAIN: begin
          if (!drain_ack_i) seq_d = SEQ_NONE;   // sequence complete
        end
        SEQ_DRAIN: begin
          if (drain_ack_i) begin
            if (kind_q == K_GATE) begin
              if (core_pending_i || wake_q) begin
                seq_d  = SEQ_UNDRAIN;          // work arrived: abort clock-idle entry
                dest_d = PM_ACTIVE;
              end else begin
                seq_d  = SEQ_UNIT_GATE;
              end
            end else begin
              seq_d = SEQ_CORE_GATE;           // K_FREQ
            end
          end
        end
        SEQ_UNIT_GATE: begin
          if (!vec_en_ack_i && !tns_en_ack_i) seq_d = SEQ_NONE;   // drain stays asserted
        end
        SEQ_CORE_GATE: begin
          if (!core_clk_en_ack_i) seq_d = SEQ_FC_REQ;
        end
        SEQ_FC_REQ: begin
          if (fc_ack_i) seq_d = SEQ_FC_REL;
        end
        SEQ_FC_REL: begin
          if (!fc_ack_i) seq_d = SEQ_WAIT_LOCK;
        end
        default: seq_d = SEQ_NONE;
      endcase

      // ---------------- sequence completion ----------------
      if (seq_q != SEQ_NONE && seq_d == SEQ_NONE) begin
        state_d = dest_d;
        kind_d  = K_NONE;
        if (kind_q == K_FREQ) begin
          cur_opp_d = target_q;
          opp_unc_d = 1'b0;
          if (opp_busy_q) begin
            fw_opp_d     = target_q;
            opp_busy_d   = 1'b0;
            opp_result_d = OPP_OK;
            opp_done_d   = 1'b1;
          end
        end
      end

      // ---------------- step timeout ----------------
      if (seq_q != SEQ_NONE && seq_d == seq_q && timeout) begin
        seq_d                   = SEQ_NONE;
        kind_d                  = K_NONE;
        state_d                 = PM_FAULT;
        fc_req_d                = 1'b0;
        cause_d[FC_SEQ_TIMEOUT] = 1'b1;
        if (kind_q == K_FREQ &&
            (seq_q == SEQ_FC_REQ || seq_q == SEQ_FC_REL || seq_q == SEQ_WAIT_LOCK || seq_q == SEQ_CORE_UNGATE))
          opp_unc_d = 1'b1;   // controller may or may not have switched
        if (opp_busy_q) begin
          opp_busy_d   = 1'b0;
          opp_result_d = OPP_ERR_TIMEOUT;
          opp_done_d   = 1'b1;
        end
      end
    end

    // ---------------- step entry actions ----------------
    if (seq_d != seq_q) begin
      unique case (seq_d)
        SEQ_CORE_UNGATE: core_clk_en_d  = 1'b1;
        SEQ_RST_RELEASE: core_rst_req_d = 1'b0;
        SEQ_UNIT_UNGATE: begin vec_en_d = 1'b1; tns_en_d = 1'b1; end
        SEQ_UNDRAIN:     drain_d        = 1'b0;
        SEQ_DRAIN:       drain_d        = 1'b1;
        SEQ_UNIT_GATE:   begin vec_en_d = 1'b0; tns_en_d = 1'b0; end
        SEQ_CORE_GATE:   core_clk_en_d  = 1'b0;
        SEQ_FC_REQ:      begin fc_req_d = 1'b1; fc_opp_d = target_d; end
        SEQ_FC_REL:      fc_req_d       = 1'b0;
        default: ;
      endcase
    end

    // ---------------- firmware OPP request not taken ----------------
    // A request for the current OPP is a successful no-op in any operational
    // state (nothing to sequence), so it is not rejected for state reasons.
    if (cmd_opp_go_i && !opp_taken) begin
      opp_done_d = 1'b1;
      if (opp_check(opp_target_i) != OPP_OK) opp_result_d = opp_check(opp_target_i);
      else if (seq_q != SEQ_NONE || opp_busy_q) opp_result_d = OPP_ERR_BUSY;
      else if (opp_target_i == cur_opp_q && !(state_q == PM_RESET || state_q == PM_FAULT)) begin
        opp_result_d = OPP_OK;
        fw_opp_d     = opp_target_i;
      end
      else                                      opp_result_d = OPP_ERR_STATE;
    end

    // wake request is consumed once clocks are running and no sequence is
    // pending; in IDLE it simply restarts the idle timer (one cycle of wake_q)
    if ((state_d == PM_ACTIVE || state_d == PM_THERMAL_LIMIT || state_d == PM_FAULT || state_d == PM_RESET) ||
        (state_q == PM_IDLE && seq_q == SEQ_NONE && seq_d == SEQ_NONE && wake_q))
      wake_d = 1'b0;

    // ---------------- core configuration (issue policy) ----------------
    core_cfg_d.window_log2 = cfg_i.window_log2;
    core_cfg_d.stop_new    = (state_q == PM_RESET) || (state_q == PM_FAULT) || fault_cond;
    if (throttle_cond || state_q == PM_THERMAL_LIMIT) begin
      core_cfg_d.issue_rate = cfg_i.thr_rate;
      core_cfg_d.pause_tns  = cfg_i.thr_pause_tns;
    end else if (cfg_i.throttle_en && therm_level_i == TL_WARN) begin
      core_cfg_d.issue_rate = cfg_i.warn_rate;
      core_cfg_d.pause_tns  = cfg_i.warn_pause_tns;
    end else begin
      core_cfg_d.issue_rate = 5'd16;
      core_cfg_d.pause_tns  = 1'b0;
    end
  end

  // ---------------------------------------------------------------------------
  // sequential
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      state_q         <= PM_RESET;
      seq_q           <= SEQ_NONE;
      kind_q          <= K_NONE;
      dest_q          <= PM_IDLE;
      target_q        <= 4'(RESET_OPP);
      cur_opp_q       <= 4'(RESET_OPP);
      fw_opp_q        <= 4'(RESET_OPP);
      opp_busy_q      <= 1'b0;
      opp_unc_q       <= 1'b0;
      opp_result_q    <= OPP_OK;
      opp_done_o      <= 1'b0;
      core_clk_en_q   <= 1'b0;
      core_rst_req_q  <= 1'b1;
      vec_en_q        <= 1'b1;
      tns_en_q        <= 1'b1;
      drain_q         <= 1'b0;
      fc_req_q        <= 1'b0;
      fc_opp_q        <= 4'(RESET_OPP);
      cause_q         <= '0;
      emerg_q         <= 1'b0;
      wake_q          <= 1'b0;
      step_cnt_q      <= '0;
      stable_cnt_q    <= '0;
      dwell_cnt_q     <= '0;
      idle_cnt_q      <= '0;
      therm_entries_q <= '0;
      fault_entries_q <= '0;
      core_cfg_q      <= CORE_CFG_RESET;
      state_change_o  <= 1'b0;
      fault_enter_o   <= 1'b0;
    end else begin
      state_q        <= state_d;
      seq_q          <= seq_d;
      kind_q         <= kind_d;
      dest_q         <= dest_d;
      target_q       <= target_d;
      cur_opp_q      <= cur_opp_d;
      fw_opp_q       <= fw_opp_d;
      opp_busy_q     <= opp_busy_d;
      opp_unc_q      <= opp_unc_d;
      opp_result_q   <= opp_result_d;
      opp_done_o     <= opp_done_d;
      core_clk_en_q  <= core_clk_en_d;
      core_rst_req_q <= core_rst_req_d;
      vec_en_q       <= vec_en_d;
      tns_en_q       <= tns_en_d;
      drain_q        <= drain_d;
      fc_req_q       <= fc_req_d;
      fc_opp_q       <= fc_opp_d;
      cause_q        <= cause_d;
      emerg_q        <= emerg_d;
      wake_q         <= wake_d;
      core_cfg_q     <= core_cfg_d;
      state_change_o <= (state_d != state_q);
      fault_enter_o  <= (state_d == PM_FAULT) && (state_q != PM_FAULT);

      // per-step timers
      if (seq_d != seq_q) begin
        step_cnt_q   <= '0;
        stable_cnt_q <= '0;
      end else begin
        if (step_cnt_q != '1) step_cnt_q <= step_cnt_q + 1'b1;
        // "stable" counts continuous cycles of the step's acknowledge condition
        unique case (seq_q)
          SEQ_WAIT_LOCK:   stable_cnt_q <= pll_locked_i ? ((stable_cnt_q != '1) ? stable_cnt_q + 1'b1 : stable_cnt_q) : '0;
          SEQ_CORE_UNGATE: stable_cnt_q <= core_clk_en_ack_i ? ((stable_cnt_q != '1) ? stable_cnt_q + 1'b1 : stable_cnt_q) : '0;
          SEQ_UNIT_UNGATE: stable_cnt_q <= (vec_en_ack_i && tns_en_ack_i) ? ((stable_cnt_q != '1) ? stable_cnt_q + 1'b1 : stable_cnt_q) : '0;
          default:         stable_cnt_q <= '0;
        endcase
      end

      // idle detection: measures continuous idle time SINCE entering an
      // operational state; restarts after work, wake, any sequence, and in
      // RESET / FAULT / CLOCK_IDLE (so recovery never gates immediately)
      if (!core_idle_i || wake_q || seq_q != SEQ_NONE ||
          (state_q == PM_RESET || state_q == PM_FAULT || state_q == PM_CLOCK_IDLE))     idle_cnt_q <= '0;
      else if (idle_cnt_q != '1)                              idle_cnt_q <= idle_cnt_q + 1'b1;

      // THERMAL_LIMIT exit hold-off: time since the throttle condition last held
      if (throttle_cond || state_q != PM_THERMAL_LIMIT) dwell_cnt_q <= '0;
      else if (dwell_cnt_q != '1)                       dwell_cnt_q <= dwell_cnt_q + 1'b1;

      if (state_d == PM_THERMAL_LIMIT && state_q != PM_THERMAL_LIMIT && therm_entries_q != '1)
        therm_entries_q <= therm_entries_q + 1'b1;
      if (state_d == PM_FAULT && state_q != PM_FAULT && fault_entries_q != '1)
        fault_entries_q <= fault_entries_q + 1'b1;
    end
  end

  // ---------------------------------------------------------------------------
  // outputs
  // ---------------------------------------------------------------------------
  assign core_clk_en_o     = core_clk_en_q;
  assign core_rst_req_o    = core_rst_req_q;
  assign vec_clk_en_o      = vec_en_q;
  assign tns_clk_en_o      = tns_en_q;
  assign drain_req_o       = drain_q;
  assign fc_req_o          = fc_req_q;
  assign fc_opp_o          = fc_opp_q;
  assign core_cfg_o        = core_cfg_q;
  assign emergency_req_o   = emerg_q | crit;
  assign state_o           = state_q;
  assign seq_o             = seq_q;
  assign cur_opp_o         = cur_opp_q;
  assign fw_opp_o          = fw_opp_q;
  assign opp_busy_o        = opp_busy_q;
  assign opp_uncertain_o   = opp_unc_q;
  assign opp_result_o      = opp_result_q;
  assign fault_cause_o     = cause_q;
  assign fault_active_o    = fault_cond;
  assign throttle_active_o = throttle_cond || (state_q == PM_THERMAL_LIMIT);
  assign therm_entries_o   = therm_entries_q;
  assign fault_entries_o   = fault_entries_q;

`ifdef SF_ASSERT
  // frequency-controller 4-phase protocol: request is only withdrawn after
  // acknowledge, unless a timeout/clock-loss abort put us in FAULT
  a_fc_req_hold: assert property (@(posedge clk_i) disable iff (!rst_ni)
    ($fell(fc_req_q)) |-> ($past(fc_ack_i) || state_q == PM_FAULT))
    else $error("fc_req withdrawn before acknowledge");
  // core clock is never re-enabled while a frequency change is outstanding
  a_no_clk_during_fc: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (fc_req_q) |-> !core_clk_en_q)
    else $error("core clock enabled while frequency request outstanding");
  // unit clocks are only gated while drain is held
  a_gate_needs_drain: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (!vec_en_q || !tns_en_q) |-> drain_q)
    else $error("unit clock gated without drain");
  a_state_legal: assert property (@(posedge clk_i) disable iff (!rst_ni)
    state_q inside {PM_RESET, PM_IDLE, PM_ACTIVE, PM_CLOCK_IDLE, PM_THERMAL_LIMIT, PM_FAULT})
    else $error("illegal state");
  // DVFS must never be claimed: voltage is never touched (no port exists) and
  // frequency requests only leave the block when the integrator declared a controller
  a_no_fc_without_ctrl: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (!HAS_FREQ_CTRL) |-> !fc_req_q)
    else $error("frequency request issued without a frequency controller");
`endif
endmodule
