// =============================================================================
// sf_cdc_sync_2ff : multi-stage flip-flop synchroniser for LEVEL signals.
//
// WIDTH > 1 is permitted ONLY for bundles of independent single-bit levels
// (each bit is meaningful on its own and no relationship between bits is
// relied upon). Multi-bit values must use sf_cdc_handshake.
//
// Simulation-only metastability model (define SF_CDC_RANDOM_DELAY):
// when the input differs from the first stage, the first stage randomly
// "resolves to the old value" for one cycle. This reproduces the one-cycle
// latency uncertainty of a real synchroniser, independently per bit, which
// exposes designs that rely on bit-coherence through 2-FF synchronisers.
// =============================================================================
module sf_cdc_sync_2ff #(
  parameter int              WIDTH     = 1,
  parameter int              STAGES    = 2,
  parameter logic [WIDTH-1:0] RESET_VAL = '0
) (
  input  logic             clk_i,
  input  logic             rst_ni,
  input  logic [WIDTH-1:0] d_i,
  output logic [WIDTH-1:0] q_o
);
  // synthesis attributes: keep together, no SRL inference, place close.
  // Stage s occupies bits [s*WIDTH +: WIDTH] (flattened for tool portability).
  (* ASYNC_REG = "TRUE" *) logic [STAGES*WIDTH-1:0] sync_q;

`ifdef SF_CDC_RANDOM_DELAY
  logic [WIDTH-1:0] held_q;  // bit already held back once for this transition
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      sync_q <= {STAGES{RESET_VAL}};
      held_q <= '0;
    end else begin
      for (int b = 0; b < WIDTH; b++) begin
        if (d_i[b] != sync_q[b] && !held_q[b] && ($urandom_range(0, 1) == 1)) begin
          held_q[b] <= 1'b1;            // metastable flop resolved to old value
        end else begin
          sync_q[b] <= d_i[b];
          held_q[b] <= 1'b0;
        end
      end
      for (int st = 1; st < STAGES; st++) sync_q[st*WIDTH +: WIDTH] <= sync_q[(st-1)*WIDTH +: WIDTH];
    end
  end
`else
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) sync_q <= {STAGES{RESET_VAL}};
    else         sync_q <= {sync_q[(STAGES-1)*WIDTH-1:0], d_i};
  end
`endif

  assign q_o = sync_q[(STAGES-1)*WIDTH +: WIDTH];

  // synopsys translate_off
  initial begin
    if (STAGES < 2) $fatal(1, "sf_cdc_sync_2ff: STAGES must be >= 2");
  end
  // synopsys translate_on
endmodule
