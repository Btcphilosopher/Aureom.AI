// =============================================================================
// sf_pm_core_shim : everything that must run on the (globally gated) core
// clock: unit clock gates, command issue gating/throttling, activity
// monitoring, quiescence/drain acknowledgement and error capture.
//
// Inputs suffixed _ai are asynchronous (always-on domain) and are
// synchronised here. Outputs to the always-on domain are registered levels
// (single-bit, synchronised at the receiver) or handshake payloads.
// =============================================================================
module sf_pm_core_shim
  import sf_pm_pkg::*;
#(
  parameter int QW = 8
) (
  input  logic          clk_i,          // core clock (after global gate)
  input  logic          rst_ni,         // core reset, synchronised to clk_i
  input  logic          test_en_i,

  // asynchronous levels from always-on domain
  input  logic          drain_req_ai,
  input  logic          vec_en_ai,
  input  logic          tns_en_ai,

  // handshake deliveries (already in this domain)
  input  logic          cfg_valid_i,
  input  core_cfg_t     cfg_i,
  input  logic          errclr_valid_i,
  input  logic [7:0]    errclr_mask_i,

  // gated unit clocks
  output logic          clk_vec_o,
  output logic          clk_tns_o,

  // unit / queue status (core-synchronous; unit clocks are derived from clk_i)
  input  logic          vec_busy_i,
  input  logic          tns_busy_i,
  input  logic          dma_busy_i,
  input  logic [QW-1:0] vec_qocc_i,
  input  logic [QW-1:0] tns_qocc_i,
  input  logic [QW-1:0] dma_qocc_i,
  input  logic [7:0]    hw_err_i,
  input  logic          wake_i,

  // command channels: up = from queue, dn = to unit
  input  logic          vec_up_valid_i,
  output logic          vec_up_ready_o,
  output logic          vec_dn_valid_o,
  input  logic          vec_dn_ready_i,
  input  logic          tns_up_valid_i,
  output logic          tns_up_ready_o,
  output logic          tns_dn_valid_o,
  input  logic          tns_dn_ready_i,
  input  logic          dma_up_valid_i,
  output logic          dma_up_ready_o,
  output logic          dma_dn_valid_o,
  input  logic          dma_dn_ready_i,

  // levels to always-on domain (registered)
  output logic          core_idle_o,
  output logic          core_pending_o,
  output logic          drain_ack_o,
  output logic          vec_en_ack_o,
  output logic          tns_en_ack_o,
  output logic          core_alive_o,
  output logic [7:0]    err_sticky_o,

  // activity snapshot to handshake source
  output logic          snap_valid_o,
  input  logic          snap_ready_i,
  output act_snap_t     snap_o,

  output core_cfg_t     cfg_active_o
);
  // ---------------------------------------------------------------------------
  // Synchronise always-on control levels
  // ---------------------------------------------------------------------------
  logic drain_s, vec_en_s, tns_en_s;

  sf_cdc_sync_2ff #(.WIDTH(1), .RESET_VAL(1'b0)) u_sync_drain (
    .clk_i, .rst_ni, .d_i(drain_req_ai), .q_o(drain_s));
  // independent single-bit levels; reset value 1 = unit clocks run while the
  // core reset propagates
  sf_cdc_sync_2ff #(.WIDTH(2), .RESET_VAL(2'b11)) u_sync_en (
    .clk_i, .rst_ni, .d_i({vec_en_ai, tns_en_ai}), .q_o({vec_en_s, tns_en_s}));

  // ---------------------------------------------------------------------------
  // Configuration (handshake delivered)
  // ---------------------------------------------------------------------------
  core_cfg_t cfg_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni)          cfg_q <= CORE_CFG_RESET;
    else if (cfg_valid_i) cfg_q <= cfg_i;
  end
  assign cfg_active_o = cfg_q;

  // ---------------------------------------------------------------------------
  // Issue-rate limiter: evenly spread slots (fractional accumulator), so a
  // rate of 8/16 issues on alternate cycles rather than in bursts.
  // ---------------------------------------------------------------------------
  logic [4:0] rate_acc_q;
  logic [5:0] rate_sum;
  logic       rate_slot;
  assign rate_sum  = {1'b0, rate_acc_q} + {1'b0, cfg_q.issue_rate};
  assign rate_slot = (rate_sum >= 6'd16);
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) rate_acc_q <= '0;
    else         rate_acc_q <= rate_slot ? 5'(rate_sum - 6'd16) : rate_sum[4:0];
  end

  logic block_all, allow_vec, allow_tns, allow_dma;
  assign block_all = drain_s | cfg_q.stop_new;
  assign allow_vec = ~block_all & rate_slot;
  assign allow_tns = ~block_all & rate_slot & ~cfg_q.pause_tns;
  // DMA is not rate limited: it moves operands/results for work already
  // accepted, and starving it could stall in-flight compute. It is stopped
  // by drain / stop_new like every other channel.
  assign allow_dma = ~block_all;

  logic vec_stall, tns_stall, dma_stall;
  sf_cmd_gate u_gate_vec (.clk_i, .rst_ni, .allow_i(allow_vec),
    .up_valid_i(vec_up_valid_i), .up_ready_o(vec_up_ready_o),
    .dn_valid_o(vec_dn_valid_o), .dn_ready_i(vec_dn_ready_i), .stalled_o(vec_stall));
  sf_cmd_gate u_gate_tns (.clk_i, .rst_ni, .allow_i(allow_tns),
    .up_valid_i(tns_up_valid_i), .up_ready_o(tns_up_ready_o),
    .dn_valid_o(tns_dn_valid_o), .dn_ready_i(tns_dn_ready_i), .stalled_o(tns_stall));
  sf_cmd_gate u_gate_dma (.clk_i, .rst_ni, .allow_i(allow_dma),
    .up_valid_i(dma_up_valid_i), .up_ready_o(dma_up_ready_o),
    .dn_valid_o(dma_dn_valid_o), .dn_ready_i(dma_dn_ready_i), .stalled_o(dma_stall));

  // ---------------------------------------------------------------------------
  // Unit clock gating with hardware interlock: a unit's clock cannot stop
  // while it is busy or a transfer is being offered to it, even if the
  // sequencer requests it (defence in depth; the sequencer drains first).
  // ---------------------------------------------------------------------------
  logic vec_en_eff, tns_en_eff;
  assign vec_en_eff = vec_en_s | vec_busy_i | vec_dn_valid_o;
  assign tns_en_eff = tns_en_s | tns_busy_i | tns_dn_valid_o;

  sf_clock_gate u_cg_vec (.clk_i, .en_i(vec_en_eff), .test_en_i, .clk_o(clk_vec_o));
  sf_clock_gate u_cg_tns (.clk_i, .en_i(tns_en_eff), .test_en_i, .clk_o(clk_tns_o));

  // ---------------------------------------------------------------------------
  // Status levels
  // ---------------------------------------------------------------------------
  logic any_busy, any_q, any_up, any_dn, quiescent;
  assign any_busy  = vec_busy_i | tns_busy_i | dma_busy_i;
  assign any_q     = (|vec_qocc_i) | (|tns_qocc_i) | (|dma_qocc_i);
  assign any_up    = vec_up_valid_i | tns_up_valid_i | dma_up_valid_i;
  assign any_dn    = vec_dn_valid_o | tns_dn_valid_o | dma_dn_valid_o;
  assign quiescent = ~any_busy & ~any_dn;

  logic [7:0] err_q;
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      core_idle_o    <= 1'b0;
      core_pending_o <= 1'b0;
      drain_ack_o    <= 1'b0;
      vec_en_ack_o   <= 1'b1;
      tns_en_ack_o   <= 1'b1;
      core_alive_o   <= 1'b0;
      err_q          <= '0;
    end else begin
      core_idle_o    <= ~any_busy & ~any_q & ~any_up;
      core_pending_o <= any_up | any_q | wake_i;
      // drain acknowledged only once THIS domain has seen the drain request
      // and nothing is in flight; prevents the race where quiescence is
      // reported before the drain took effect.
      drain_ack_o    <= drain_s & quiescent;
      vec_en_ack_o   <= vec_en_eff;
      tns_en_ack_o   <= tns_en_eff;
      core_alive_o   <= 1'b1;
      err_q          <= (err_q & ~(errclr_valid_i ? errclr_mask_i : 8'h00)) | hw_err_i;
    end
  end
  assign err_sticky_o = err_q;

  // ---------------------------------------------------------------------------
  // Activity monitor
  // ---------------------------------------------------------------------------
  logic [QW+1:0] qsum;
  assign qsum = {2'b00, vec_qocc_i} + {2'b00, tns_qocc_i} + {2'b00, dma_qocc_i};

  sf_activity_monitor #(.QSUM_W(QW + 2)) u_act (
    .clk_i, .rst_ni,
    .window_log2_i(cfg_q.window_log2),
    .vec_busy_i, .tns_busy_i, .dma_busy_i,
    .all_idle_i(~any_busy & ~any_q & ~any_up),
    .stall_i(vec_stall | tns_stall | dma_stall),
    .qocc_sum_i(qsum),
    .snap_valid_o, .snap_ready_i, .snap_o);

`ifdef SF_ASSERT
  // no new transfer may start while stop/drain is in force (committed ones may finish)
  a_no_new_vec_when_blocked: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (block_all && vec_dn_valid_o) |-> $past(vec_dn_valid_o && !vec_dn_ready_i))
    else $error("vector command started while issue blocked");
  a_no_new_tns_when_blocked: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (block_all && tns_dn_valid_o) |-> $past(tns_dn_valid_o && !tns_dn_ready_i))
    else $error("tensor command started while issue blocked");
  a_no_new_dma_when_blocked: assert property (@(posedge clk_i) disable iff (!rst_ni)
    (block_all && dma_dn_valid_o) |-> $past(dma_dn_valid_o && !dma_dn_ready_i))
    else $error("DMA command started while issue blocked");
`endif
endmodule
