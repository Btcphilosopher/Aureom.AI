# POWERCLOCK activity analysis (toggle-based, unit-less)

Source: `power_trace.vcd` from `tb_pm_top +TEST=power_trace` (base build, core 100 MHz, always-on 100 MHz).
These are **activity factors from RTL simulation**, not power. No wattage is derived here;
see docs/07_power_estimation.md for the vendor/ASIC flows that turn activity into power.

| Phase | duration (us) | clk_core edges/us | clk_vec edges/us | clk_tns edges/us | DUT data toggles / core cycle (clock nets excluded) | vec busy | tns busy | dma busy |
|---|---|---|---|---|---|---|---|---|
| ACTIVE (full issue rate) | 30.7 | 100.0 | 100.0 | 100.0 | 42.2 | 100% | 99% | 100% |
| THERMAL_LIMIT (rate 4/16, tensor paused) | 30.0 | 100.0 | 100.0 | 100.0 | 43.7 | 77% | 0% | 100% |
| IDLE (unit clocks running) | 30.0 | 100.0 | 100.0 | 100.0 | 10.4 | 0% | 0% | 0% |
| CLOCK_IDLE (unit clocks gated) | 30.0 | 100.0 | 0.0 | 0.0 | 8.3 | 0% | 0% | 0% |

## DUT data toggles per core cycle by sub-block (clock nets excluded)

| Block | ACTIVE | THERMAL_LIMIT | IDLE | CLOCK_IDLE |
|---|---|---|---|---|
| (top-level nets) | 7.61 | 5.85 | 0.16 | 0.14 |
| u_fsm | 2.01 | 2.00 | 4.00 | 2.00 |
| u_hs_cfg | 0.01 | 0.00 | 0.00 | 0.00 |
| u_hs_snap | 0.15 | 0.18 | 0.12 | 0.10 |
| u_regs | 0.08 | 0.09 | 0.05 | 0.03 |
| u_shim | 30.32 | 33.56 | 4.07 | 4.05 |
| u_therm | 2.01 | 2.00 | 2.00 | 2.00 |

## Observations

* Unit clock activity in CLOCK_IDLE: vector 0.00 edges/us, tensor 0.00 edges/us (vs 100.0 in IDLE with clocks running): the gated unit clock trees are fully stopped.
* THERMAL_LIMIT reduced vector busy duty from 100% to 77% and tensor from 99% to 0% (tensor paused).
* Always-on timers (thermal sample-timeout counter, FSM idle/dwell/step timers) contribute 4.0 data toggles per cycle in every phase, including CLOCK_IDLE: the floor of the power manager's own activity.
* In THERMAL_LIMIT the power manager's own core-side logic is slightly busier than in ACTIVE (33.6 vs 30.3 toggles/cycle in u_shim: rate accumulator and stall counters), while unit duty falls; the throttling saving is in the units, not in this block.
* Unit datapaths are testbench models here, so unit-internal toggles are not part of the DUT figures; on silicon the
  dominant saving of CLOCK_IDLE is the unit clock trees and datapath registers, which this RTL stops but cannot quantify.
