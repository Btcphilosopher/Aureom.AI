# Thermal policy stability study

**Backend:** lumped-RC (illustrative, not ThermalLab). ThermalLab adapter present (`ThermalLabBackend`) but not bound: ThermalLab's API was not available.
**Scenario:** ASSUMED illustrative scenario for control-loop dynamics; not a power estimate: T_amb 45.0 C, R_th 0.4 K/W, tau 20 ms, static 30.0 W, vector 60.0 W, tensor 120.0 W at full issue, sensor noise 0.3 C, 1 ms sampling. Unthrottled steady state would be 129 C (> CRITICAL), so throttling is required.

Thresholds: WARN 85 C, THROTTLE 95 C, CRITICAL 105 C (the RTL placeholder defaults). 128 policy configurations swept (throttle rate x tensor pause x hysteresis x min dwell).

| Outcome | configurations |
|---|---|
| CHATTER (>20 throttle entries/s) | 74 |
| EXCESSIVE THROTTLING (>15% below ideal) | 24 |
| OK | 14 |
| UNSAFE (critical reached) | 16 |

Highest delivered throughput among OK configurations: rate 8/16, tensor pause False, hysteresis 1.0 C, dwell 20 ms -> 52.3% (ideal 52.8%), 17.5 entries/s, Tmax 98.3 C.

## Findings (computed from the sweep)

* **Critical reached** in 16 configurations, for (rate, tensor-paused) = [(12, False)]: the throttled power still exceeds what the package removes below CRITICAL, independent of hysteresis/dwell. The throttle rate must be chosen from the thermal budget, not tuned by hysteresis.

Throttle entries per second (rate 8/16, tensor not paused) - the bang-bang limit-cycle frequency:

| hysteresis \ min dwell | 0 ms | 5 ms | 20 ms | 50 ms |
|---|---|---|---|---|
| 1 C | 26.2 | 24.0 | 17.5 | 11.2 |
| 3 C | 0.2 | 0.2 | 0.2 | 0.2 |
| 5 C | 0.2 | 0.2 | 0.2 | 0.2 |
| 8 C | 0.2 | 0.2 | 0.2 | 0.2 |

* **Oscillation criterion.** On/off throttling oscillates only if the *throttled* steady-state temperature is below the throttle clear threshold (SET - HYST); otherwise the policy enters THERMAL_LIMIT once and parks there. Here rate 8/16 settles at 93.0 C (T_amb + R_th x P_throttled), so:
  * hysteresis 1 C -> clear 94 C: cycles at 26.2 entries/s, 5.1 C peak-to-peak
  * hysteresis 3 C -> clear 92 C: parks throttled at ~93 C (0.2 entries/s, 0.0 C swing)
  * hysteresis 5 C -> clear 90 C: parks throttled at ~93 C (0.2 entries/s, 0.0 C swing)
  * hysteresis 8 C -> clear 87 C: parks throttled at ~93 C (0.2 entries/s, 0.0 C swing)
* Where a cycle exists, MIN_DWELL lowers its rate (hysteresis 1 C row above). Parking is not instability, but it holds throughput at the throttled level even though the die is below SET; a second, gentler throttle step between WARN and THROTTLE would recover that headroom.
* The transition cost decides whether cycling matters: issue-rate changes are free (no clock or reset sequencing), but THERMAL_OPP frequency changes drain and relock on every entry/exit, so MIN_DWELL must be set well above the relock time when THERMAL_OPP_EN is used.
* **Excessive throttling** (>15% below the ideal hold-at-threshold throughput) in 24 configurations, (rate, tensor-paused) = [(2, False), (2, True), (4, False), (4, True), (8, True), (12, True)]: a single throttle step that is much lower than needed wastes performance. Multiple throttle steps, or a validated lower OPP, would track the ideal more closely.
* All conclusions concern policy dynamics under the ASSUMED scenario. Re-run with the ThermalLab backend and SilicaFlux power data (synthesis activity x library power) before choosing production thresholds.

Full results: `sweep.csv`; traces: `representative_traces.png`.
