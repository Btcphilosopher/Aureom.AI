## =============================================================================
## POWERCLOCK ASIC SDC TEMPLATE (Synopsys/Cadence style). Not run here: no ASIC
## library or STA tool was available. Adapt clock names, periods, hierarchy.
## =============================================================================
# create_clock -name clk_aon       -period 10.0 [get_ports clk_aon]
# create_clock -name clk_core_root -period  2.0 [get_ports clk_core_root]   ;# PLL output
# Gated clocks: ICG outputs propagate the source clock; let the tool infer
# clock-gating checks on sf_icg_lib_cell instances (setup/hold on E pin).
# create_generated_clock -name clk_core -source [get_ports clk_core_root] -divide_by 1 [get_pins u_pm/u_cg_core/u_icg/GCK]

set_clock_groups -asynchronous -group {clk_aon} -group {clk_core_root clk_core}

## Quasi-static handshake payloads: skew-bounded
set_max_delay 1.5 -from [get_cells -hier *u_hs_*/src_hold_q_reg*] -to [get_cells -hier *u_hs_*/dst_data_o_reg*]
set_min_delay 0.0 -from [get_cells -hier *u_hs_*/src_hold_q_reg*] -to [get_cells -hier *u_hs_*/dst_data_o_reg*]

## Synchroniser first stages: tool-specific "synchronizer" attribute / don't-touch
set_dont_touch [get_cells -hier *sync_q_reg*]

## Multi-OPP signoff: every OPP marked validated in OPP_VALIDATED must close
## timing in its own scenario (MCMM) at its frequency and the SINGLE supply
## voltage (no voltage scaling exists).
