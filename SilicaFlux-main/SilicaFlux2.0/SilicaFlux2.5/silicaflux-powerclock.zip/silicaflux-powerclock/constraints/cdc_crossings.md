# POWERCLOCK clock-domain-crossing manifest

Every signal that crosses between `clk_aon` (always-on), `clk_core_root`
(clock source) and `clk_core` (gated core root). `clk_vec`/`clk_tns` are
ICG-derived from `clk_core` and synchronous to it: no CDC exists between them.

| # | Signal | From -> To | Width | Kind | Mechanism | Instance |
|---|---|---|---|---|---|---|
| 1 | core_clk_en_req | aon -> core_root | 1 | level | 2-FF sync, feeds ICG enable | u_sync_core_en |
| 2 | pll_locked_i, fc_ack_i, core_clk_en_root | ext/root -> aon | 3 | independent levels | 2-FF sync per bit | u_sync_ext |
| 3 | drain_req | aon -> core | 1 | level | 2-FF sync | u_shim.u_sync_drain |
| 4 | vec_en, tns_en | aon -> core | 2 | independent levels | 2-FF sync per bit, reset value 1 | u_shim.u_sync_en |
| 5 | core_idle, core_pending, drain_ack, vec_ack, tns_ack, core_alive | core -> aon | 6 | independent registered levels | 2-FF sync per bit | u_sync_core_status |
| 6 | err_sticky[7:0] | core -> aon | 8 | independent sticky levels | 2-FF sync per bit | u_sync_err |
| 7 | core_cfg_t (12 b) | aon -> core | 12 | multi-bit value | 2-phase toggle handshake | u_hs_cfg |
| 8 | error clear mask | aon -> core | 8 | multi-bit value | 2-phase toggle handshake | u_hs_errclr |
| 9 | act_snap_t (224 b) | core -> aon | 224 | multi-bit value | 2-phase toggle handshake | u_hs_snap |
| 10 | fc_req_o / fc_opp_o | aon -> freq controller | 1 + 4 | req + payload | 4-phase handshake; fc_opp stable while fc_req high | u_fsm |
| 11 | core reset request | aon -> core | 1 | reset | async assert, sync release | u_rst_core |
| 12 | POR | async -> core_root | 1 | reset | async assert, sync release | u_rst_root |

Design rules relied on (and why each multi-bit 2-FF bundle above is legal):
* Rows 2, 4, 5, 6 carry bits that are each meaningful alone; no logic combines
  two of them assuming they arrived in the same cycle. The drain handshake is
  explicitly *acknowledged* (drain_ack = drain seen in core AND quiescent) so a
  stale `quiescent` can never be paired with a new `drain`.
* Rows 7-9: only the toggles are synchronised; the payload register is held
  from launch until acknowledge.

Reset-domain crossings:
* Always-on CDC endpoints are reset by `~core_rst_req` whenever the core reset
  is requested, so both ends of every handshake reset together (a one-sided
  reset would desynchronise the toggles). Verified by test `core_reset_on_clear`.
* Core reset assertion is asynchronous (works with the core clock stopped);
  release is synchronous to `clk_core` and only requested after the clock is
  enabled and acknowledged (`reset_sequence` checks the order).

Verification performed: simulation with the randomized metastability-delay
model (`SF_CDC_RANDOM_DELAY`) across clock ratios 0.22x-4.6x, plus
field-by-field checking of every activity snapshot. Structural CDC signoff
with a dedicated tool (Questa CDC / SpyGlass CDC / Meridian) was NOT run: none
was available. That remains a signoff item.
