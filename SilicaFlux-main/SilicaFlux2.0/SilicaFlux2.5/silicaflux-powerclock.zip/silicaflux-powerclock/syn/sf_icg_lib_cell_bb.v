// Blackbox stand-in for the target library ICG (integrator maps the real cell).
(* blackbox *)
module sf_icg_lib_cell (input CK, input E, input SE, output GCK);
endmodule
