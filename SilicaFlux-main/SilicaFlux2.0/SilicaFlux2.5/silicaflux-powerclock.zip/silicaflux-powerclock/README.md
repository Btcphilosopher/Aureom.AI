# SilicaFlux-HPC Project 27 - POWERCLOCK
### Dynamic power and thermal management (Aureom.AI / SilicaFlux-HPC)

`rtl/silicaflux_power_manager.sv` and its submodules form a power manager. It
controls the SilicaFlux-HPC operating state through:

* clock-enable management;
* reset sequencing;
* thermal throttling of command issue;
* frequency-only operating-point changes, when a real frequency controller is declared.

It **does not perform DVFS**. No voltage-control interface exists, so
`CAP.DVFS = CAP.VOLTAGE_CTRL = 0` are hard-wired, and there is no voltage
port. The block never claims a capability the hardware lacks (docs/06).

## Status

Final regression on the final RTL: **107 test runs, 0 failures** across 4 builds (no-controller, frequency-controller, and both with randomized CDC metastability delay at core/always-on clock ratios from 0.3x to 16x).

| Regression run | passed | failed |
|---|---|---|
| base build | 22 | 0 |
| freq build: frequency tests | 6 | 0 |
| freq build: base suite | 21 | 0 |
| CDC random delay, core 3ns / aon 10ns | 16 | 0 |
| CDC random delay, core 46ns / aon 10ns | 16 | 0 |
| CDC random delay, core 6.2ns / aon 14.6ns | 16 | 0 |
| CDC random delay, core 160ns: clock-idle abort | 1 | 0 |
| CDC random delay, freq build | 9 | 0 |
| **Total** | **107** | **0** |

Also: thermal monitor matches the Python reference on 40 random configurations x 6000 cycles with 0 mismatches (and a deliberately broken reference is caught); Verilator `-Wall` lint clean; Yosys synthesis latch-free with ICG-only gating; firmware driver host test passes. Full detail: docs/08_verification.md.

## Quick start

```
make regs            # regenerate register package / C header / docs from tools/gen_regs.py
make lint            # Verilator -Wall, both builds
make sim TEST=clock_idle
make regress         # 4 builds, all suites, CDC random-delay clock-ratio sweeps, power trace
make thermal-golden  # RTL thermal monitor vs Python reference (+ mutation check)
make synth           # Yosys: latch-free, ICG-only gating; no-target negative test
make fw-test         # firmware driver host test
make stability       # thermal policy stability sweep (assumed scenario, lumped RC)
```
Requires Verilator 5.x, Python 3 (matplotlib optional), Yosys, and gcc.

## Layout

| Path | Contents |
|---|---|
| `rtl/` | SystemVerilog RTL (13 files; `files.f` order) |
| `sim/` | **Simulation-only** models: clock source/frequency controller with glitching output, explicitly simulated temperature sensor |
| `tb/` | System testbench (29 tests), thermal-monitor golden testbench, unit models |
| `fw/` | Generated `sf_pm_regs.h`, driver `sf_pm_driver.[ch]`, host test |
| `tools/` | Register generator, Python policy/thermal reference model, golden check, VCD activity analysis, stability sweep, Yosys prep |
| `constraints/` | CDC manifest, Vivado XDC and ASIC SDC templates |
| `power/` | Vivado and ASIC power-flow templates (not run here) |
| `syn/` | Yosys scripts and the ICG blackbox |
| `docs/` | 01 audit, 02 architecture, 03 state machine, 04 clock/reset/CDC, 05 thermal, 06 DVFS status, 07 power estimation, 08 verification, register map |
| `reports/` | Regression, golden check, synthesis, activity, stability and firmware results |

## Read before integrating

* **No inspection of your repository (docs/01).** The SilicaFlux repository was not available, so the controllability audit records assumptions and the interfaces that make them explicit.
* **Placeholder values.**
  * The temperature thresholds and `CRIT_HARD_LIMIT` must be replaced from the product thermal specification.
  * `OPP_VALIDATED` bits may be set only after timing closure at each frequency.
* **No real thermal or power data.** ThermalLab's API was not available. The stability study uses a clearly labelled lumped-RC backend and an assumed scenario. No wattage figures are produced anywhere.
* **Signoff not done.** Structural CDC signoff, STA, gate-level simulation and vendor/library power were not run (docs/08).
