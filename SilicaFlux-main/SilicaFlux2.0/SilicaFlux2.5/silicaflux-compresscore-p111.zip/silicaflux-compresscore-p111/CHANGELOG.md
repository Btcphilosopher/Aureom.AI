# Changelog — SilicaFlux CompressCore (Project 111)

## 1.0 (this delivery)

Built in the order the brief requires: **decompressor first, verified against externally produced LZ4 blocks; compressor only afterwards.**

1. **Audit** of the repository (`docs/00_AUDIT.md`): StreamDMA, IronMemory, StorageFabric, DataFabric, PacketCore located and read; **no PacketForge and no compression RTL exist**; integrity/ECC modules catalogued.
2. **Contract + models** (`tools/lz4model.py`, `tools/check_model.py`): the decode contract written from the LZ4 block specification and validated against python-lz4 / LZ4 1.9.4 — 915 valid library blocks and 42 984 truncated/mutated
   blocks, 0 mismatches. Findings that shaped the design: the reference library enforces the end-of-block rules relative to the *buffer capacity* (not the true size), and it **accepts offset 0**, which the specification calls invalid.
3. **Decoder** (`sf_lz4_decoder`, `sf_lz4_history`, `sf_lz4_pack`, `sf_lz4_srcchk`): baseline correct design first, then a measured optimisation (one-cycle `SEQ` fast path: text 2.9 → 4.8 B/cycle) with every suite re-run.
   Interoperability gate (library + `lz4` CLI blocks, `reports/regression.md`) passed **before** any compressor RTL was written.
4. **Compressor** (`sf_lz4_encoder`, `sf_lz4_matchfinder`): baseline greedy LZ4 compressor with reference-style skip acceleration; epoch-tagged hash table so a dry-run sizing pass is decision-for-decision identical to the emit pass; policies
   `STREAM` / `ERROR` / `RAW`; bit-exact Python model; every output block decoded by the independent library and (as LZ4 frames, content checksum) by the `lz4` command-line tool.
5. **Core** (`sf_compress_core`, `sf_compress_stream_adapter`, `sf_compress_crc`, `sf_compress_perf`): keep-mask streams with repacking, framing checks, mode demux and in-order return, optional CRC-32 / CRC-32C, counters with hardware-computed Q16.16 ratios.
6. **Verification**: Verilator C++ bench (random / bursty backpressure, partial input beats, reset injection, fault injection), 339 939 vector executions in the full regression (all pass), round trip, perf-counter cross-check, formal (packer, ring, FIFO, hazard
   lemma), formal sensitivity (13/13), mutation testing (52/58 killed, 6 analysed equivalent), lint in 18 configurations, Yosys estimates, benchmarks.

### Defects found and fixed during development (kept here because they were found by the verification, not by inspection)

* Epoch wrap in the match finder never answered the `PASS` command (hang once per 255 passes) — found while re-reading the FSM, before simulation; mutant `mf-pass-resp` now guards it.
* Combinational loop in the encoder's packer handshake (chunk size gated by `fire`, which depends on `in_ready`, which depends on the chunk size) — found by Verilator `-Wall` (UNOPTFLAT).
* Encoder used stale `in_cnt` / `size_err` from the previous block in the first-beat cycle — found in review, fixed by `st_idle` gating.
* End-of-block threshold mutant (12 → 11) **survived** the first vector set: the suites tested distance 9 and 12 but not the boundary 11. Exact-boundary vectors added (`bad_eob_dist*`, `bad_eob_fin*`), mutant killed.
* Yosys 0.33 rejected `int'()` casts that Verilator accepted — replaced by `32'()` casts everywhere (found by actually running Yosys on every module).
* PERF_EN = 0 left 20 unused-signal lint warnings — fixed (found by the multi-configuration lint run).
* Benchmark methodology errors found and corrected before publishing numbers: compress latency was dominated by the post-reset hash-table sweep (now measured on a warm core and the sweep documented); mismatched corpora between sections; a meaningless "busy %" column.
* Mutation testing found three boundary gaps (compressed-size limit, length-counter limit, offset == window): closed with the `limits` suites and a small-window mutation profile; the formal sensitivity check exposed a weak *harness* (unused packer lanes carried the stream's own next bytes), fixed before the proofs were reported.
* Synthesis methodology: a black-boxed SRAM made Yosys' `ltp` report a 1517-level path through the decoder (the memory treated as combinational pass-through, unrolling the read→write feedback); a first single-flop stand-in collapsed the read funnel. Caught by looking at the path itself (it hopped `bank0_q[0] → bank0_q[1] → …`) and by a negative flop count; replaced by a per-bit register-boundary stand-in with exact subtraction.
* Formal: depth-14 packer BMC did not finish in 11 minutes; depths re-tuned (the exponential growth is documented in `reports/formal.md`).

### Not done (see `docs/08_LIMITATIONS.md`)

Integration into StreamDMA / IronMemory / StorageFabric / DataFabric; ECC on the SRAMs; linked-block LZ4 frames; HC-level compression; a pipelined (faster) compressor scan; FPGA / ASIC implementation and timing.
