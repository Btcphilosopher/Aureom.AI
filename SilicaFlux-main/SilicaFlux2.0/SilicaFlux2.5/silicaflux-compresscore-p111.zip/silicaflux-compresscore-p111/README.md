# SilicaFlux CompressCore — Project 111

**A synthesizable LZ4 block-format compression / decompression accelerator** for SilicaFlux cloud computing (`sf_compress_core`): a 128-bit streaming core with ready/valid back-pressure on both sides, byte-valid masks, block start/end, transaction ids and per-block
completion status; a **decompressor** with a 2-bank SRAM history ring (16 bytes/cycle, overlapping-match copy, every offset/length validated) and a **baseline compressor** (hash-table match finder, three documented policies for incompressible data),
plus an optional, separate CRC-32 / CRC-32C integrity stage and performance counters.

**Format: the standard LZ4 block format** — no proprietary format is substituted. The decoder was built and verified against externally produced blocks **before** any compressor RTL was written; the compressor's output is decoded by the independent
software LZ4 and by the `lz4` command-line tool.

**Evidence level: RTL simulation + formal on selected blocks + mutation testing + Yosys synthesis estimates. No FPGA, no silicon, no technology library, no timing closure: no frequency, area (µm²) or power figure is claimed.** Read `docs/08_LIMITATIONS.md` first.
Delivered as a ZIP; **nothing was committed to git.**

## Deliverables (brief §13)

| Brief | Where |
|---|---|
| `sf_compress_core.sv` | `rtl/sf_compress_core.sv` — top level: adapter + decoder + encoder + CRC stages + counters |
| `sf_lz4_decoder.sv` | `rtl/` — parser FSM → op queue → 2-stage copy engine → packer |
| `sf_lz4_encoder.sv` | `rtl/` — ingest, dry-run / emit passes, sequence emission, policies |
| `sf_lz4_history.sv` | `rtl/` — bounded 2-bank SRAM ring (+ `sf_lz4_sram_1r1w.sv`, the only technology-dependent file, + `sf_lz4_srcchk.sv`, the proved hazard predicate) |
| `sf_lz4_matchfinder.sv` | `rtl/` — hash table with epoch tags, verification, 16-byte extension |
| `sf_compress_stream_adapter.sv` | `rtl/` — keep-mask repack, framing checks, mode demux, in-order return |
| `sf_compress_perf.sv` | `rtl/` — counters, latency tracker, Q16.16 ratio divider |
| extras | `sf_compress_crc.sv` (CRC stage), `sf_lz4_pack.sv`, `sf_lz4_fifo.sv`, `sf_compress_defs.svh` |
| interoperability tests | `tests/`, `tools/` (models, vector generators, frame builder), `vectors/golden/` (shipped corpus), `reports/interop_encoder.md` |
| formal properties | `formal/` — Yosys 0.33 / Z3 harnesses + sensitivity (`reports/formal.md`, `formal_mutants.md`) |
| synthesis and benchmark reports | `reports/synth.md`, `benchmarks/REPORT.md` (+ `results.csv`) |
| docs | `docs/00_AUDIT … 09_INTEGRATION`, `CHANGELOG.md` |

## Results (every number below is read from `reports/` or `benchmarks/`)

| Item | Result |
|---|---|
| **Interoperability (decode)** | blocks from python-lz4 (default / fast / HC levels 3–12) and from the **`lz4` C tool** (`-1 … -12`, `--fast`, 64 KiB–1 MiB blocks) decode byte-exactly under all back-pressure profiles; 29-block golden corpus shipped (`make golden`) |
| **Interoperability (encode)** | every hardware block decodes in the reference library; LZ4 **frames** built from hardware blocks (RAW fallbacks as uncompressed blocks, content checksum) are decoded identically by `lz4 -d` (`reports/interop_encoder.md`) |
| Regression | **339 939 vector executions, all pass** (`reports/regression.md`): decoder (default / small window / permissive / `OPQ_DEPTH` 8), encoder (default / small / fast / tiny table) and core (CRC-32 / CRC-32C / no CRC) builds × 7 back-pressure profiles, decoder suites incl. 4 MiB blocks and exact limit boundaries, plus round trip, three reset campaigns and the interop scripts |
| Decode contract vs the trusted library | 915 valid + 42 984 mutated blocks, **0 mismatches** (`reports/model_check.md`); two measured deviations: the library accepts **offset 0** (rejected here) and checks the end-of-block rules against its **buffer capacity** (here: the actual size) |
| Round trip | 842 blocks compressed by the hardware, 747 decompressed by the hardware (CRC check on) + 93 RAW fallbacks, 0 failures; performance counters match independent counts exactly (28/28) |
| Reset / fault injection | 3 × 40 random-cycle reset campaigns (all non-interrupted records bit-exact); 7 % framing faults injected in the mixed stream, all detected, stream recovers |
| Formal (Yosys 0.33 + Z3) | **11 / 11 jobs pass**: the SRAM-hazard lemma **exhaustively** (also at the default 23-bit / 64 KiB widths), packer / history ring / FIFO by BMC (depth 4–14); **13 / 13** non-equivalent injected bugs are found by their harnesses (`reports/formal.md`, `formal_mutants.md`) |
| Mutation testing | **52 / 58 injected RTL bugs killed; the 6 survivors are each analysed (equivalent or performance-only), none unexplained** (`reports/mutation.md`) |
| Lint | Verilator `-Wall` clean in 18 parameterisations; 13 illegal parameter sets rejected; every top parses in Yosys 0.33 (`reports/lint.md`) |
| Decompression throughput (simulation) | ≈ 15 B/cycle on long matches / literal runs (15.9 with `OPQ_DEPTH = 8`), **4.8 B/cycle text, 6.7 source, 8.8 mixed**; latency 31 cycles for a 256 B block; tracks `out_ready` almost linearly (`benchmarks/REPORT.md`) |
| Compression (simulation) | ratio 1.57 text / 2.28 source / 2.23 mixed vs the reference's 1.68 / 2.37 / 2.27 (default) — better than its `fast=9`; throughput is the weak point: 0.3–0.6 B/cycle on text-like data, 3.3 on incompressible, ≈ 5 on long matches |
| Synthesis (Yosys, no PDK) | decoder 2.8 k flops / 22 k gates / 74 gate levels; encoder 2.1 k / 14 k / 65; **core 11.0 k flops (4.4 k of them the optional counters) / 60 k gates / 79 levels, plus 144 KiB SRAM** (64 + 64 + 16) — relative indicators only, not timing or area (`reports/synth.md`, `docs/07_SYNTHESIS.md`) |

## What the design guarantees (and where it is checked)

* **Byte-exact output under back-pressure, both sides**: history is committed only when the output packer accepts a chunk; random / bursty / 10 % `out_ready` including 4 MiB blocks; reset at random cycles.
* **Every offset and length is validated**; first error in stream order wins, the block still completes in sync with a status; **output never exceeds the capacity** (a 255:1 bomb against a 1000-byte capacity is rejected after one match).
* **Overlapping matches** (offset < length) by pattern replication (any offset 1..15 at 16 B/cycle) and SRAM reads (offset ≥ 16) with a *proved* hazard rule: a read is issued only when every source byte is written and not yet overwritten (`formal/fv_srcchk.sv`, exhaustive).
* **Incompressible input**: `STREAM` never exceeds the capacity; `ERROR` sizes first (exact, epoch-tagged dry run) and emits **nothing** if it does not fit; `RAW` emits the input unchanged flagged `out_raw` (= an LZ4 frame's uncompressed block). No incompatible block marker is invented.
* **Compression never changes the data**: the CRC stage passes data through unchanged and reports the CRC of the uncompressed bytes in both directions.

## Quick start

Tools (Ubuntu 24.04): `verilator` 5.020, `yosys` 0.33, `z3` 4.8, `lz4` (CLI), `g++`, `make`, python 3 with `pip install lz4` (`reports/tools.txt`).

```bash
make lint                 # Verilator -Wall in 18 configurations + negative elaboration + Yosys parse
make vectors golden       # generate the suites (independent LZ4 producers); verify the shipped golden corpus
make quick                # models + decoder/encoder/core suites (3 backpressure profiles) + interop + round trip + reset  (~5 min)
make regress formal mutate synth bench      # the full evidence (formal / mutate / synth are slow)
```

Instantiate: `sf_compress_core #(.DW(128), .HIST_BYTES(65536), .BLK_BYTES(65536), .HASH_BITS(12), .CRC_EN(1))` — ports and protocol in `docs/04_INTERFACES.md`, architecture in `docs/02_ARCHITECTURE.md`.

## Layout

```
rtl/        synthesizable SystemVerilog + filelist.f          formal/     Yosys harnesses, runner, sensitivity check
tests/      Verilator C++ bench, runners, interop/round-trip/reset/golden scripts     scripts/    regress, lint, mutate, synth
tools/      LZ4 model, encoder model, frame builder, vector generators, corpus         benchmarks/ run_bench.py, REPORT.md, results.csv
vectors/    golden/ (shipped); generated suites are rebuilt by `make vectors`          docs/       00_AUDIT … 09_INTEGRATION
reports/    regression, interop, formal, mutation, lint, synth, model check, tools     CHANGELOG.md
```

## Known limits (summary of `docs/08_LIMITATIONS.md`)

LZ4 **block** format with **independent blocks** only (no linked-block frames, no HC compressor); the compressor is a baseline with low throughput on compressible data and one block at a time; output of a block that completes with an error is
invalid and was already streamed (the consumer must discard it); SRAMs are behavioural (needs a 1R1W macro with byte enables) and **unprotected by ECC**; the parser, copy engine, encoder and adapter are verified by simulation and mutation only
(not formally); BMC proofs are bounded; **not integrated** into StreamDMA / IronMemory / StorageFabric / DataFabric (`docs/09_INTEGRATION.md`); there is **no module called PacketForge** in the repository (`docs/00_AUDIT.md`).
