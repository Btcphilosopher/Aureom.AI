#!/bin/bash
# Verilator -Wall lint of the CompressCore modules in several parameterisations (must be warning-free) plus negative elaboration tests
# (illegal parameter combinations must be REJECTED).  Also checks that Yosys 0.33 parses every module.  Writes reports/lint.md.
cd "$(dirname "$0")/.."
mkdir -p reports; OUT=reports/lint.md
FILES="rtl/sf_lz4_fifo.sv rtl/sf_lz4_sram_1r1w.sv rtl/sf_lz4_history.sv rtl/sf_lz4_pack.sv rtl/sf_lz4_srcchk.sv rtl/sf_lz4_decoder.sv rtl/sf_lz4_matchfinder.sv rtl/sf_lz4_encoder.sv rtl/sf_compress_crc.sv rtl/sf_compress_stream_adapter.sv rtl/sf_compress_perf.sv rtl/sf_compress_core.sv"
{ echo "# Lint report (Verilator $(verilator --version | cut -d' ' -f2), -Wall, no waivers file; the only suppressions are inline \`lint_off UNUSEDSIGNAL\` pragmas on intentionally unused bits)"; echo; echo "| top | configuration | warnings |"; echo "|---|---|---|"; } > $OUT
fail=0
lint() { # top, name, params...
  top="$1"; name="$2"; shift; shift; G=""; for p in "$@"; do G="$G -G$p"; done
  n=$(verilator --lint-only -Wall -Wno-DECLFILENAME -Irtl $FILES --top-module $top $G 2>&1 | grep -c '^%Warning\|^%Error')
  echo "| $top | $name | $n |" >> $OUT; [ "$n" = 0 ] || fail=1
}
lint sf_compress_core "default"
lint sf_compress_core "CRC-32C, no perf" CRC_POLY=2197175160 PERF_EN=0
lint sf_compress_core "no CRC stage" CRC_EN=0
lint sf_compress_core "small decoder window + permissive EOB" HIST_BYTES=1024 MAX_IN_BYTES=262144 MAX_OUT_BYTES=524288 STRICT_EOB=0
lint sf_compress_core "small encoder (4 KiB block, 2^8 table, accel 3)" BLK_BYTES=4096 HASH_BITS=8 ACCEL=3 SKIP_SHIFT=4
lint sf_compress_core "large table 2^16, 8 blocks in flight" HASH_BITS=16 ORDQ_DEPTH=8
lint sf_lz4_decoder "decoder alone, default"
lint sf_lz4_decoder "decoder alone, 4 KiB window" HIST_BYTES=4096 MAX_IN_BYTES=65536 MAX_OUT_BYTES=65536 OPQ_DEPTH=8 OUTQ_DEPTH=2
lint sf_lz4_encoder "encoder alone, default"
lint sf_lz4_encoder "encoder alone, 16 KiB / 2^10 / accel 2" BLK_BYTES=16384 HASH_BITS=10 ACCEL=2
lint sf_lz4_matchfinder "match finder, 2^14" HASH_BITS=14
lint sf_lz4_pack "packer, 64-bit" DW=64
lint sf_lz4_pack "packer, 256-bit, FIFO 8" DW=256 FDEPTH=8
lint sf_lz4_history "history, 128-bit 64 KiB"
lint sf_lz4_history "history, 64-bit 4 KiB" DW=64 HIST_BYTES=4096
lint sf_lz4_srcchk "hazard predicate"
lint sf_compress_crc "CRC stage"
lint sf_compress_perf "counters"
echo >> $OUT; echo "## Negative elaboration tests (each must be rejected)" >> $OUT; echo >> $OUT; echo "| illegal parameters | rejected |" >> $OUT; echo "|---|---|" >> $OUT
neg() { top="$1"; name="$2"; shift; shift; G=""; for p in "$@"; do G="$G -G$p"; done
  if verilator --lint-only -Irtl $FILES --top-module $top $G >/dev/null 2>&1; then echo "| $top $name | **NO (accepted!)** |" >> $OUT; fail=1; else echo "| $top $name | yes |" >> $OUT; fi; }
neg sf_lz4_decoder "DW=64" DW=64
neg sf_lz4_decoder "HIST_BYTES not a power of two" HIST_BYTES=1000
neg sf_lz4_decoder "HIST_BYTES=32 (< 64)" HIST_BYTES=32
neg sf_lz4_decoder "MAX_OUT_BYTES < HIST_BYTES" HIST_BYTES=65536 MAX_OUT_BYTES=4096
neg sf_lz4_encoder "DW=64" DW=64
neg sf_lz4_encoder "BLK_BYTES=131072 (> 64 KiB)" BLK_BYTES=131072
neg sf_lz4_encoder "BLK_BYTES not a power of two" BLK_BYTES=5000
neg sf_lz4_encoder "ACCEL=0" ACCEL=0
neg sf_lz4_matchfinder "HASH_BITS=4" HASH_BITS=4
neg sf_lz4_matchfinder "HASH_BITS=24" HASH_BITS=24
neg sf_lz4_fifo "DEPTH=3" DEPTH=3
neg sf_lz4_fifo "DEPTH=1" DEPTH=1
neg sf_lz4_history "HIST_BYTES=48" HIST_BYTES=48
echo >> $OUT; echo "## Yosys 0.33 parse (read_verilog -sv + hierarchy) of every top" >> $OUT; echo >> $OUT
for top in sf_compress_core sf_lz4_decoder sf_lz4_encoder sf_lz4_history sf_lz4_pack sf_lz4_matchfinder sf_compress_crc sf_compress_stream_adapter sf_compress_perf; do
  if yosys -q -p "read_verilog -sv -Irtl $FILES; hierarchy -check -top $top" >/dev/null 2>&1; then echo "- $top: parses and elaborates" >> $OUT; else echo "- $top: **FAILS**" >> $OUT; fail=1; fi
done
cat $OUT; exit $fail
