#!/usr/bin/env python3
"""Mutation testing of the RTL against the regression suites.  Each mutant is ONE textual change to ONE file (applied to a scratch copy, which must match exactly
once), built into its own Verilator model and run against a fast subset of the suites.  A mutant is KILLED when any check fails, the bench reports a protocol
error, or the run does not complete.  The harness refuses to run unless the UNMUTATED design passes (baseline gate).  Survivors are listed with the reason they
are expected / accepted (equivalent or performance-only mutants).  Writes reports/mutation.md.   usage: mutate.py [--only SUBSTR] [--jobs N]"""
import os, sys, shutil, time, argparse, subprocess
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tests")); sys.path.insert(0, os.path.join(ROOT, "tools"))
import run_suite as R, genvec as G

# (id, file, old, new, kind, description).  kind: dec | enc | core (core also runs the round-trip + perf check)
M = [
 # ---- sf_lz4_srcchk / hazard
 ("srcchk-vis-plus1", "sf_lz4_srcchk", "<= {1'b0, mpos};", "<= {1'b0, mpos} + 1;", "dec", "SRAM read issued one byte before the source is committed"),
 ("srcchk-window-le", "sf_lz4_srcchk", "(off32 < 32'(HIST_BYTES))", "(off32 <= 32'(HIST_BYTES))", "dec_small", "offset == window size accepted (small-window profile)"),
 ("srcchk-off-lt-pos", "sf_lz4_srcchk", "(off32 <= 32'(pos1))", "(off32 < 32'(pos1))", "dec", "offset == bytes produced rejected"),
 # ---- decoder: parser
 ("dec-fast-zero-off", "sf_lz4_decoder", "&& (fast_off != 16'd0) &&", "&&", "dec", "fast path accepts offset 0"),
 ("dec-fast-need", "sf_lz4_decoder", "wire [5:0]  fast_need = 6'd3 + {2'd0, cur_b0[7:4]};", "wire [5:0]  fast_need = 6'd2 + {2'd0, cur_b0[7:4]};", "dec", "fast path consumes one byte too few"),
 ("dec-llext-255", "sf_lz4_decoder", "if (cur_b0 != 8'hFF) begin lit_rem_n = sum32[LENW-1:0]; pst_n = P_LIT; end", "if (cur_b0 != 8'hFE) begin lit_rem_n = sum32[LENW-1:0]; pst_n = P_LIT; end", "dec", "literal extension terminator 254 instead of <255"),
 ("dec-mlen-base", "sf_lz4_decoder", "LENW'(32'd4) + {{(LENW-4){1'b0}}, mnib_q}", "LENW'(32'd3) + {{(LENW-4){1'b0}}, mnib_q}", "dec", "minimum match 3 instead of 4 (slow path)"),
 ("dec-mlext-base", "sf_lz4_decoder", "ml_n = LENW'(32'd19);", "ml_n = LENW'(32'd18);", "dec", "match length with extension off by one"),
 ("dec-offzero-ignored", "sf_lz4_decoder", "if (off_v == 16'd0) begin err_v = 1'b1; err_c = `SF_CST_OFFSET_ZERO; end", "if (1'b0) begin err_v = 1'b1; err_c = `SF_CST_OFFSET_ZERO; end", "dec", "offset 0 not rejected (slow path)"),
 ("dec-size-gt", "sf_lz4_decoder", "if (in_cnt_q >= 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end\n          else if (fast_ok)", "if (in_cnt_q > 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end\n          else if (fast_ok)", "dec", "compressed size limit off by one"),
 ("dec-lit-take", "sf_lz4_decoder", "take = (32'(avail) < {8'd0, lit_rem_q}) ? avail : lit_rem_q[4:0];", "take = (32'(avail) <= {8'd0, lit_rem_q}) ? lit_rem_q[4:0] : avail;", "dec", "literal chunk size wrong when the beat ends exactly at the run end"),
 ("dec-len-limit", "sf_lz4_decoder", "else if (sum32 > LEN_LIMIT) begin err_v = 1'b1; err_c = `SF_CST_LENGTH; end\n          else if (cur_b0 == 8'hFF)", "else if (sum32 > LEN_LIMIT + 1) begin err_v = 1'b1; err_c = `SF_CST_LENGTH; end\n          else if (cur_b0 == 8'hFF)", "dec", "match-length overflow limit off by one"),
 # ---- decoder: copy engine
 ("dec-lit-cap", "sf_lz4_decoder", "else if (pos_ext > 32'(s1_cap)) begin s1_err_n = `SF_CST_OUT_OVERFLOW; s1_pop = 1'b1; end\n          else if (can_issue) begin\n            issue = 1'b1; i_data = op_d;", "else if (pos_ext > 32'(s1_cap) + 32'd1) begin s1_err_n = `SF_CST_OUT_OVERFLOW; s1_pop = 1'b1; end\n          else if (can_issue) begin\n            issue = 1'b1; i_data = op_d;", "dec", "literal capacity check off by one"),
 ("dec-match-cap", "sf_lz4_decoder", "(32'(pos1) + m_len > 32'(s1_cap))", "(32'(pos1) + m_len > 32'(s1_cap) + 32'd1)", "dec", "match capacity check off by one"),
 ("dec-eob-12", "sf_lz4_decoder", "(32'(pos1) - 32'(lms_q)) < 32'd12", "(32'(pos1) - 32'(lms_q)) < 32'd13", "dec", "last-match rule 13 instead of 12"),
 ("dec-eob-5", "sf_lz4_decoder", "(op_d[8 +: LENW] < LENW'(5))", "(op_d[8 +: LENW] < LENW'(4))", "dec", "last-5-literals rule weakened"),
 ("dec-phase", "sf_lz4_decoder", "4'((ph + 16) % o)", "4'((ph + 15) % o)", "dec", "overlapping-copy phase advance wrong"),
 ("dec-rep", "sf_lz4_decoder", "tail_q[8*(16-o+(k%o)) +: 8]", "tail_q[8*(16-o+((k+1)%o)) +: 8]", "dec", "overlapping-copy pattern rotated"),
 ("dec-pat-wait", "sf_lz4_decoder", "m_ok = m_first ? !s2_valid : can_issue;", "m_ok = m_first ? 1'b1 : can_issue;", "dec", "overlapping copy captures the tail before the previous chunk committed"),
 ("dec-lms", "sf_lz4_decoder", "lms_n = m_first ? pos1 : m_start_q;", "lms_n = pos1;", "dec", "last-match start recorded at the END of multi-chunk matches"),
 ("dec-tail", "sf_lz4_decoder", "wire [2*DW-1:0] tail_cat = {cmask, tail_q} >> (8 * 32'(s2_n));", "wire [2*DW-1:0] tail_cat = {cmask, tail_q} >> (8 * 32'(s2_n + 5'd1));", "dec", "tail register shifted by one byte too many"),
 ("dec-mpos", "sf_lz4_decoder", "mpos_q <= mpos_q + POSW'(s2_n);", "mpos_q <= mpos_q + POSW'(5'd16);", "dec", "committed-byte counter advances by 16 for partial chunks"),
 ("dec-seq-lit", "sf_lz4_decoder", "i_data = {16'd0, op_d[111:0]}; i_n = op_n;", "i_data = {16'd0, op_d[111:0]}; i_n = op_n - 5'd1;", "dec", "fast-path literal chunk one byte short"),
 # ---- history ring
 ("hist-hi-be", "sf_lz4_history", "wire [BYTES-1:0] w_hi_be = w_bewide[2*BYTES-1:BYTES];", "wire [BYTES-1:0] w_hi_be = w_bewide[2*BYTES-2:BYTES-1];", "dec", "byte enables of the upper word shifted"),
 ("hist-bank", "sf_lz4_history", "wire              w_to_b0   = (w_word[0] == 1'b0);", "wire              w_to_b0   = (w_word[0] == 1'b1);", "dec", "write bank assignment swapped"),
 ("hist-funnel", "sf_lz4_history", "wire [DW-1:0] r_lo = rb_q ? bank1_q : bank0_q;", "wire [DW-1:0] r_lo = rb_q ? bank0_q : bank1_q;", "dec", "read bank order swapped"),
 ("hist-roff", "sf_lz4_history", "roff_q <= r_off;", "roff_q <= r_off + 1'b1;", "dec", "read byte offset off by one"),
 # ---- packer
 ("pack-complete", "sf_lz4_pack", "wire            completes = (tot >= (LW+2)'(BYTES));", "wire            completes = (tot > (LW+2)'(BYTES));", "dec", "word completion needs more than BYTES"),
 ("pack-flush", "sf_lz4_pack", "if (h_valid && acc_n != '0) begin\n        f_push = !f_full;", "if (h_valid) begin\n        f_push = !f_full;", "dec", "flush pushes the held word as non-last even when the accumulator is empty"),
 ("pack-mask", "sf_lz4_pack", "if ((LW+1)'(i) < in_n) cm[8*i +: 8] = in_data[8*i +: 8];", "if ((LW+1)'(i) <= in_n) cm[8*i +: 8] = in_data[8*i +: 8];", "dec", "chunk not masked to its byte count"),
 # ---- encoder / match finder
 ("enc-token-lit", "sf_lz4_encoder", "tok = {((lit_rem_q >= PW'(15)) ? 4'd15 : lit_rem_q[3:0]),", "tok = {((lit_rem_q >= PW'(16)) ? 4'd15 : lit_rem_q[3:0]),", "enc", "literal-length nibble saturates at 16"),
 ("enc-ext-255", "sf_lz4_encoder", "for (int j = 1; j <= 15; j++) if (lext_q >= PW'(255 * j)) ext_k = 5'(j);", "for (int j = 1; j <= 15; j++) if (lext_q >= PW'(254 * j)) ext_k = 5'(j);", "enc", "extension byte count uses 254"),
 ("enc-lext-base", "sf_lz4_encoder", "begin lext_q <= lit_rem_q - PW'(15); st <= E_LEXT; end", "begin lext_q <= lit_rem_q - PW'(14); st <= E_LEXT; end", "enc", "literal extension value off by one"),
 ("enc-mext-base", "sf_lz4_encoder", "if (mlen_q >= PW'(19)) begin lext_q <= mlen_q - PW'(19); st <= E_MEXT; end", "if (mlen_q >= PW'(20)) begin lext_q <= mlen_q - PW'(19); st <= E_MEXT; end", "enc", "match with exactly 19 bytes emits no extension"),
 ("enc-mflimit", "sf_lz4_encoder", "(pos_q <= (n_blk - PW'(12)))", "(pos_q <= (n_blk - PW'(11)))", "enc", "a match may start 11 bytes before the end (violates the format)"),
 ("enc-lastlit", "sf_lz4_encoder", "mf_limit = n_blk - PW'(5);", "mf_limit = n_blk - PW'(4);", "enc", "a match may reach into the last 5 bytes (violates the format)"),
 ("enc-skip", "sf_lz4_encoder", "assign step      = PW'(ACCEL) + (PW'(miss_q) >> SKIP_SHIFT);", "assign step      = PW'(ACCEL) + (PW'(miss_q) >> (SKIP_SHIFT + 1));", "enc", "skip acceleration slower (valid but different output)"),
 ("enc-raw-lim", "sf_lz4_encoder", "lim_q <= (cap_eff < (in_cnt_q - 32'd1)) ? cap_eff : (in_cnt_q - 32'd1);", "lim_q <= (cap_eff < in_cnt_q) ? cap_eff : in_cnt_q;", "enc", "RAW policy accepts a compressed block that is not smaller"),
 ("enc-stream-over", "sf_lz4_encoder", "wire        c_over  = ch_valid && (cb_new > {1'b0, lim_q});", "wire        c_over  = ch_valid && (cb_new > {1'b0, lim_q} + 33'd1);", "enc", "emission may exceed the capacity by one byte"),
 ("enc-raw-fit", "sf_lz4_encoder", "if (pol_q == `SF_POL_RAW && {1'b0, in_cnt_q} <= {1'b0, cap_eff}) begin", "if (pol_q == `SF_POL_RAW && {1'b0, in_cnt_q} < {1'b0, cap_eff}) begin", "enc", "RAW fallback refused when the input exactly fits"),
 ("enc-crc-pass", "sf_lz4_encoder", "crc_q <= in_crc; ferr_q <= in_ferr;", "crc_q <= ~in_crc; ferr_q <= in_ferr;", "enc", "CRC sideband corrupted"),
 ("enc-empty-raw", "sf_lz4_encoder", "else if (in_cnt_q == 32'd0) begin            // RAW, empty input", "else if (in_cnt_q == 32'd1) begin            // RAW, empty input", "enc", "RAW empty-input special case on the wrong length"),
 ("mf-verify", "sf_lz4_matchfinder", "r_found <= (bb_rd_data[31:0] == cur4_q);", "r_found <= (bb_rd_data[23:0] == cur4_q[23:0]);", "enc", "candidate verified on 3 bytes only"),
 ("mf-ext-lt", "sf_lz4_matchfinder", "if ((5'(i) < ncmp) && (cur16_q[8*i +: 8] != bb_rd_data[8*i +: 8])) mism = 5'(i);", "if ((5'(i) <= ncmp) && (cur16_q[8*i +: 8] != bb_rd_data[8*i +: 8])) mism = 5'(i);", "enc", "extension compares one byte past the limit"),
 ("mf-ext-iter", "sf_lz4_matchfinder", "if (mism == ncmp && e_rem > PW'(16)) begin\n            e_rem", "if (mism == ncmp && e_rem >= PW'(16)) begin\n            e_rem", "enc", "extension iterates once more at an exact 16-byte boundary"),
 ("mf-verify-skip", "sf_lz4_matchfinder", "r_found <= (bb_rd_data[31:0] == cur4_q);", "r_found <= 1'b1;", "enc_small", "candidate verification skipped (hash collisions would create invalid matches; small table config)"),
 ("mf-pass-resp", "sf_lz4_matchfinder", "pass_pend_q <= 1'b1; st <= S_CLR; end", "pass_pend_q <= 1'b0; st <= S_CLR; end", "enc", "PASS response lost on epoch wrap (hang)"),
 # ---- adapter / core / crc / perf
 ("ad-keep", "sf_compress_stream_adapter", "wire                 keep_ok   = ((in_keep & (in_keep + 1'b1)) == '0);", "wire                 keep_ok   = 1'b1;", "core", "non-contiguous keep not flagged"),
 ("ad-midfirst", "sf_compress_stream_adapter", "(starting && !in_first) || (!starting && in_first) ||", "(starting && !in_first) ||", "core", "first flag inside a block not flagged"),
 ("ad-nofirst", "sf_compress_stream_adapter", "(starting && !in_first) || (!starting && in_first) ||", "(!starting && in_first) ||", "core", "missing first flag not flagged"),
 ("ad-keep-out", "sf_compress_stream_adapter", "out_keep[i] = ((LW+1)'(i) < o_n);", "out_keep[i] = ((LW+1)'(i) <= o_n);", "core", "output byte mask one lane too wide"),
 ("ad-order", "sf_compress_stream_adapter", "assign oq_pop    = out_valid && out_ready && out_last;", "assign oq_pop    = out_valid && out_ready;", "core", "order queue popped on every beat"),
 ("ad-policy", "sf_compress_stream_adapter", "assign enc_in_policy = pk_o_desc[TIDW+33 +: 2];", "assign enc_in_policy = pk_o_desc[TIDW+32 +: 2];", "core", "policy field slice shifted"),
 ("core-crc-cmp", "sf_compress_core", "(dc_crc != o_crc_exp)) ? `SF_CST_CRC : dc_status;", "(dc_crc == o_crc_exp)) ? `SF_CST_CRC : dc_status;", "core", "CRC check inverted"),
 ("crc-noreset", "sf_compress_crc", "crc_q <= in_last ? 32'hFFFF_FFFF : crc_nxt;", "crc_q <= crc_nxt;", "core", "running CRC not restarted after a block"),
 ("crc-poly", "sf_compress_crc", "c = c[0] ? ((c >> 1) ^ POLY) : (c >> 1);", "c = c[0] ? ((c >> 1) ^ (POLY ^ 32'd1)) : (c >> 1);", "core", "CRC polynomial bit flipped"),
 ("perf-inbytes", "sf_compress_perf", "cnt[R_INB]   <= cnt[R_INB]  + 64'(ev_in_bytes);", "cnt[R_INB]   <= cnt[R_INB]  + 64'(ev_in_bytes != 0);", "core", "input byte counter counts beats (perf check only)"),
 ("perf-lat", "sf_compress_perf", "wire [31:0] lat_now = free_cyc - ts_head + 32'd1;", "wire [31:0] lat_now = free_cyc - ts_head;", "core", "latency off by one cycle (perf check only)"),
]
# mutants expected to survive, with the reason (none at the moment: every survivor found during development was either killed by a new vector or documented here)
ACCEPTED = {
 "pack-complete": "EQUIVALENT: an exactly-full accumulator is pushed one item later (or at the flush); the byte stream, beat shape, block ends and sideband are identical (also confirmed by the formal harness, which cannot distinguish it either).",
 "hist-hi-be": "EQUIVALENT at system level: the shifted upper-word byte enable writes ONE junk byte just ahead of the write pointer; the next chunk overwrites it before anything can read it, and its previous content sat at distance exactly HIST_BYTES (an illegal offset). The module-level formal shadow-memory proof DOES detect it (formal/formal_mutants.py).",
 "enc-token-lit": "EQUIVALENT: for a literal length of exactly 15, `lit[3:0]` is already 4'd15, so saturating at 15 or at 16 yields the same nibble.",
 "mf-verify": "EQUIVALENT for this hash: two 4-byte values that differ only in the top byte always differ in the top 8 hash bits, which lie inside the table index (HASH_BITS >= 8); index equality plus equal first 3 bytes therefore already implies equal 4th byte. The check that verification as a whole cannot be dropped is `mf-verify-skip` (killed).",
 "mf-ext-lt": "EQUIVALENT: the extra compared lane can only set mism = ncmp, which is the value it already has when all lower lanes match.",
 "mf-ext-iter": "PERFORMANCE-ONLY: one redundant extension iteration that compares zero bytes and returns the same length (two extra cycles per exactly-16-byte-aligned match).",
}

DEC_SUITES = ["dec_limits", "dec_hand", "dec_bad", "dec_lib", "dec_ring", "dec_fuzz"]
DEC_SMALL_SUITES = ["decs_limits", "decs_hand", "decs_bad", "decs_ring"]       # small-window profile: boundary mutants that the default 64 KiB window cannot express
ENC_SUITES = ["enc_edge", "enc_pol", "enc_rnd", "enc_lib"]
ENC_SMALL_SUITES = ["enc_edge", "enc_rnd", "enc_lib"]            # encoder built with HASH_BITS=8 / BLK_BYTES=4096: hash collisions are frequent
CORE_SUITES = ["core_mix"]


def runs_for(kind):
    return {"dec": ("decoder", DEC_SUITES), "dec_small": ("decoder", DEC_SMALL_SUITES), "enc": ("encoder", ENC_SUITES), "enc_small": ("encoder", ENC_SMALL_SUITES), "core": ("core", CORE_SUITES)}[kind]


def evaluate(dut, suites, exe, mp, profile="rand50", seed=7, extra=()):
    for s in suites:
        out, r, dt = R.run(exe, s, profile, seed, extra=list(extra), timeout=900)
        c = R.check_decoder(s, out) if dut == "decoder" else (R.check_encoder(s, out, mp) if dut == "encoder" else R.check_core(s, out))
        if c["fails"] or r.returncode:
            return f"{s}: {c['fails'][0] if c['fails'] else 'bench rc=%d' % r.returncode}"
    return None


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--only"); ap.add_argument("--jobs", type=int, default=3); a = ap.parse_args()
    work = os.path.join(ROOT, "build", "mut"); shutil.rmtree(work, ignore_errors=True); os.makedirs(work)
    # baseline gate
    print("baseline gate ...", flush=True)
    for kind in ("dec", "dec_small", "enc", "enc_small", "core"):
        dut, suites = runs_for(kind)
        exe = R.build(dut, name="base_" + kind, params=(G.RTL_PARAMS["small"] if kind == "dec_small" else (G.ENC_CONFIGS["small"][0] if kind == "enc_small" else {})))
        bad = evaluate(dut, suites, exe, (G.ENC_CONFIGS["small"][1] if kind == "enc_small" else {}), extra=(["--split", "1"] if dut == "core" else []))
        if bad: sys.exit(f"BASELINE FAILS ({dut}): {bad} -- refusing to run mutation testing")
    sys.path.insert(0, os.path.join(ROOT, "tests")); import roundtrip
    todo = [m for m in M if not a.only or a.only in m[0]]

    def one(m):
        mid, f, old, new, kind, desc = m
        d = os.path.join(work, mid); shutil.copytree(os.path.join(ROOT, "rtl"), d)
        src = open(os.path.join(d, f + ".sv")).read()
        if src.count(old) != 1: return (m, "INVALID", f"pattern found {src.count(old)}x")
        open(os.path.join(d, f + ".sv"), "w").write(src.replace(old, new))
        dut, suites = runs_for(kind)
        try:
            exe = R.build(dut, name="mut_" + mid, rtl_dir=d, params=(G.RTL_PARAMS["small"] if kind == "dec_small" else (G.ENC_CONFIGS["small"][0] if kind == "enc_small" else {})))
        except SystemExit as e:
            return (m, "INVALID", "does not compile")
        res = evaluate(dut, suites, exe, (G.ENC_CONFIGS["small"][1] if kind == "enc_small" else {}), extra=(["--split", "1"] if dut == "core" else []))
        if res is None and kind == "core":
            try:
                rc = roundtrip.main(exe=exe, quiet=True)
                if rc: res = "roundtrip/perf check failed"
            except Exception as e:
                res = f"roundtrip crashed: {type(e).__name__}"
        shutil.rmtree(d, ignore_errors=True)
        return (m, "KILLED" if res else "SURVIVED", res or "")

    results = []
    with ThreadPoolExecutor(a.jobs) as ex:
        for m, st, why in ex.map(one, todo):
            results.append((m, st, why)); print(f"{st:8s} {m[0]:20s} {m[5]}  [{why[:90]}]", flush=True)
    # merge with earlier results (a partial re-run with --only updates just those mutants), persist, then report everything
    import json
    jpath = os.path.join(ROOT, "reports", "mutation.json")
    merged = json.load(open(jpath)) if os.path.exists(jpath) else {}
    for m, st, why in results: merged[m[0]] = [st, why]
    json.dump(merged, open(jpath, "w"), indent=1)
    allres = [(m, merged[m[0]][0], merged[m[0]][1]) for m in M if m[0] in merged]
    killed = sum(1 for r in allres if r[1] == "KILLED"); surv = [r for r in allres if r[1] == "SURVIVED"]; inv = [r for r in allres if r[1] == "INVALID"]
    unexplained = [r for r in surv if r[0][0] not in ACCEPTED]
    with open(os.path.join(ROOT, "reports", "mutation.md"), "w") as f:
        f.write("# Mutation testing (scripts/mutate.py)\n\nEach mutant is one textual change to one RTL file, built into its own Verilator model and run against the regression subset "
                f"(decoder: {', '.join(DEC_SUITES)}; decoder small-window profile: {', '.join(DEC_SMALL_SUITES)}; encoder: {', '.join(ENC_SUITES)}; encoder small-table config: {', '.join(ENC_SMALL_SUITES)}; "
                f"core: {', '.join(CORE_SUITES)} + round trip/perf check; profile rand50). Baseline gate: the unmutated design passes every one of these.\n\n")
        n_valid = len(allres) - len(inv)
        f.write(f"**{killed} / {n_valid} valid mutants killed; {len(surv)} survive, of which {len(surv) - len(unexplained)} are analysed as equivalent / performance-only (below) and {len(unexplained)} are unexplained; {len(inv)} invalid.**\n\n")
        f.write("| mutant | file | change | result | detected by |\n|---|---|---|---|---|\n")
        for m, st, why in allres: f.write(f"| {m[0]} | {m[1]} | {m[5]} | {st} | {why[:110].replace('|', '/')} |\n")
        if surv:
            f.write("\n## Survivors and why they are accepted\n\n")
            for m, st, why in surv: f.write(f"- `{m[0]}` ({m[5]}): {ACCEPTED.get(m[0], '**NOT YET ANALYSED**')}\n")
    print(f"\n{killed}/{n_valid} killed, {len(surv)} survivors ({len(unexplained)} unexplained), {len(inv)} invalid")
    return 1 if unexplained or inv else 0


if __name__ == "__main__":
    sys.exit(main())
