#!/usr/bin/env python3
"""Yosys synthesis ESTIMATES (technology-independent): flops, generic gates, a LUT6 mapping estimate, longest gate-level path, and the SRAM requirement.
SRAMs (sf_lz4_sram_1r1w instances) are replaced by a register-boundary stand-in and reported in bits (they map to compiler macros / block RAM, not to logic).
NO technology library, NO place-and-route, NO timing closure: these are NOT area / frequency / power figures.  Writes reports/synth.md and reports/synth.json."""
import os, re, sys, json, subprocess, time, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["sf_lz4_fifo", "sf_lz4_history", "sf_lz4_pack", "sf_lz4_srcchk", "sf_lz4_decoder", "sf_lz4_matchfinder", "sf_lz4_encoder", "sf_compress_crc",
       "sf_compress_stream_adapter", "sf_compress_perf", "sf_compress_core"]
STUB = """// SYNTHESIS STAND-IN for sf_lz4_sram_1r1w.  A plain black box makes Yosys' `ltp` treat the memory as combinational pass-through (read data -> write data feedback
// through the commit stage is then unrolled into an artificial multi-thousand-level path).  The real macro has a synchronous read register, i.e. it is a register
// boundary: every read-data bit launches from its OWN flop (so the read funnel logic is not collapsed) and every input feeds those flops (so the logic that drives
// the SRAM stays alive).  Cost per instance: DW flops and DW + (k-1) XOR gates (k = control/address bits), subtracted from the reported figures.
module sf_lz4_sram_1r1w #(parameter AW = 11, parameter DW = 128) (input clk, input we, input [DW/8-1:0] be, input [AW-1:0] waddr,
  input [DW-1:0] wdata, input re, input [AW-1:0] raddr, output [DW-1:0] rdata);
  wire fold = ^{we, be, waddr, re, raddr};
  reg [DW-1:0] q; always @(posedge clk) q <= wdata ^ {DW{fold}};
  assign rdata = q;
endmodule\n"""


TARGETS = [  # name, top, parameter overrides
    ("sf_lz4_pack", "sf_lz4_pack", {}), ("sf_compress_crc", "sf_compress_crc", {}), ("sf_lz4_history (64 KiB)", "sf_lz4_history", {}),
    ("sf_lz4_matchfinder", "sf_lz4_matchfinder", {}), ("sf_lz4_decoder", "sf_lz4_decoder", {}), ("sf_lz4_encoder", "sf_lz4_encoder", {}),
    ("sf_compress_stream_adapter", "sf_compress_stream_adapter", {}), ("sf_compress_perf", "sf_compress_perf", {}), ("sf_compress_core", "sf_compress_core", {}),
]


def sram_spec(top, params):
    """SRAM requirement of a module from its parameters: (descriptions, total bits, number of instances, stand-in flops, stand-in XOR gates)"""
    # per instance: DW flops; DW + (k-1) XOR gates with k = 1 (we) + DW/8 (be) + AW (waddr) + 1 (re) + AW (raddr)
    def inst(dw, aw): return (dw, dw + (1 + dw // 8 + aw + 1 + aw) - 1)
    def hist(nbytes):
        aw = (nbytes // 32).bit_length() - 1; f, g = inst(128, aw)
        return (f"2 x {nbytes // 32} x 128b (history/block buffer {nbytes // 1024} KiB)", nbytes * 8, 2, 2 * f, 2 * g)
    def tbl(hb):
        f, g = inst(32, hb)
        return (f"1 x {1 << hb} x 32b (hash table {(1 << hb) * 4 // 1024} KiB)", (1 << hb) * 32, 1, f, g)
    HB = params.get("HASH_BITS", 12); HIST = params.get("HIST_BYTES", 65536); BLK = params.get("BLK_BYTES", 65536)
    parts = {"sf_lz4_history": [hist(HIST)], "sf_lz4_matchfinder": [tbl(HB)], "sf_lz4_decoder": [hist(HIST)], "sf_lz4_encoder": [hist(BLK), tbl(HB)],
             "sf_compress_core": [hist(HIST), hist(BLK), tbl(HB)]}.get(top, [])
    return [p[0] for p in parts], sum(p[1] for p in parts), sum(p[2] for p in parts), sum(p[3] for p in parts), sum(p[4] for p in parts)


def synth(top, params, lut):
    d = tempfile.mkdtemp()
    stub = os.path.join(d, "stub.v"); open(stub, "w").write(STUB)
    ys = [f"read_verilog -sv {stub}", "read_verilog -sv -I rtl " + " ".join(f"rtl/{f}.sv" for f in RTL)]
    for k, v in params.items(): ys.append(f"chparam -set {k} {v} {top}")
    ys += [f"hierarchy -check -top {top}", "synth -flatten -top " + top + (" -noabc" if lut else "")]
    if lut: ys += ["abc -lut 6"]
    ys += ["opt_clean -purge", "tee -o " + os.path.join(d, "stat.txt") + " stat", "tee -o " + os.path.join(d, "ltp.txt") + " ltp -noff"]
    t0 = time.time()
    r = subprocess.run(["yosys", "-q", "-p", "; ".join(ys)], cwd=ROOT, capture_output=True, text=True, timeout=3000)
    if r.returncode: return dict(error=(r.stdout + r.stderr)[-600:])
    st = open(os.path.join(d, "stat.txt")).read(); lt = open(os.path.join(d, "ltp.txt")).read()
    cells = {}
    for m in re.finditer(r"^\s+(\S+)\s+(\d+)\s*$", st, re.M):
        cells[m.group(1)] = cells.get(m.group(1), 0) + int(m.group(2))
    flops = sum(v for k, v in cells.items() if "DFF" in k or "DLATCH" in k)
    sram, sram_bits, n_inst, stub_flops, stub_xor = sram_spec(top, params)
    flops -= stub_flops                   # the stand-ins' own read-data flops
    luts = sum(v for k, v in cells.items() if k.startswith("$lut") or k.startswith("$_LUT") or "LUT" in k)
    gates = sum(v for k, v in cells.items() if k.startswith("$_") and "DFF" not in k and "DLATCH" not in k) - stub_xor
    m = re.search(r"Longest topological path in \S+ \(length=(\d+)\)", lt)
    return dict(flops=flops, gates=gates, luts=luts, cells=cells, sram_bits=sram_bits, sram=sram, ltp=int(m.group(1)) if m else None, secs=time.time() - t0)


def main():
    from concurrent.futures import ThreadPoolExecutor
    jobs = [(name, top, p, lut) for name, top, p in TARGETS for lut in (False, True)]
    # biggest first so the long poles start immediately
    jobs.sort(key=lambda j: {"sf_compress_core": 0, "sf_lz4_decoder": 1, "sf_lz4_encoder": 2}.get(j[1], 9))
    out = {}
    with ThreadPoolExecutor(3) as ex:
        for (name, top, p, lut), r in zip(jobs, ex.map(lambda j: synth(j[1], j[2], j[3]), jobs)):
            out[(name, lut)] = r
            print(name, "LUT6-map" if lut else "generic", {k: (v if k != "cells" else "...") for k, v in r.items()}, flush=True)
    res = {}
    for name, top, p in TARGETS:
        g, l = out[(name, False)], out[(name, True)]
        res[name] = dict(generic=g, lut6=l.get("luts") if "error" not in l else None, lut6_ltp=l.get("ltp") if "error" not in l else None)
    json.dump(res, open(os.path.join(ROOT, "reports", "synth.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "synth.md"), "w") as f:
        f.write("# Synthesis estimates (Yosys %s, generic technology-independent flow)\n\n" % subprocess.run(["yosys", "-V"], capture_output=True, text=True).stdout.split()[1])
        f.write("**These are not area, frequency or power figures.** No technology library, no place-and-route, no timing closure. SRAMs are replaced by a register-boundary stand-in (reported in bits; "
                "they map to compiler macros or block RAM; the stand-in's own flop and XOR tree are subtracted). `gates` = generic 2-input-class gates after ABC; `LUT6` = ABC `-lut 6` mapping count; `levels` = longest topological "
                "combinational path in the generic netlist (a relative indicator of logic depth, NOT a timing result).\n\n")
        f.write("| module | flops | generic gates | LUT6 (est.) | levels (gates) | levels (LUT6) | SRAM |\n|---|---|---|---|---|---|---|\n")
        for name, r in res.items():
            g = r["generic"]
            if "error" in g: f.write(f"| {name} | ERROR | | | | | {g['error'][:80]} |\n"); continue
            f.write(f"| {name} | {g['flops']:,} | {g['gates']:,} | {r['lut6'] if r['lut6'] is not None else ''} | {g['ltp']} | {r['lut6_ltp']} | {', '.join(g['sram']) or '-'} ({g['sram_bits']/8/1024:.1f} KiB) |\n")
        f.write("\nSRAM sizes are derived analytically from the module parameters: decoder history = 2 banks x (HIST_BYTES/32) x 128 b; encoder block buffer = the same for "
                "BLK_BYTES, plus the match-finder hash table 2^HASH_BITS x 32 b.\n")
    print(open(os.path.join(ROOT, "reports", "synth.md")).read())


if __name__ == "__main__":
    main()
