#!/usr/bin/env python3
"""Master regression: models vs the trusted software LZ4, decoder / encoder / core suites under backpressure profiles and configurations,
interoperability (library blocks, lz4-CLI blocks, hardware blocks -> lz4 CLI), round trip, reset injection, perf-counter consistency.
Writes reports/regression.md.   usage: regress.py [--quick] [--jobs N]"""
import os, sys, time, argparse, subprocess, importlib, zlib
from concurrent.futures import ThreadPoolExecutor
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tests")); sys.path.insert(0, os.path.join(ROOT, "tools"))
import run_suite as R, genvec as G, corpus

PROFS_ALL = ["full", "rand50", "slow_out", "slow_in", "burst", "rand_hi", "rand_lo"]


def gen_vectors():
    for prof, suites in (("default", ["hand", "bad", "fuzz", "lib", "cli", "ring", "max", "limits"]), ("small", ["hand", "bad", "fuzz", "ring", "limits"]),
                         ("permissive", ["hand", "bad", "fuzz", "ring", "limits"])):
        subprocess.run([sys.executable, os.path.join(ROOT, "tools", "genvec.py"), "--profile", prof] + suites, check=True, capture_output=True)
    subprocess.run([sys.executable, os.path.join(ROOT, "tools", "genvec.py"), "enc_lib", "enc_edge", "enc_pol", "enc_rnd", "core_mix", "core_mix_c"], check=True, capture_output=True)


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--quick", action="store_true"); ap.add_argument("--jobs", type=int, default=4); ap.add_argument("--skip-gen", action="store_true")
    a = ap.parse_args()
    t0 = time.time()
    rows = []          # (group, item, vectors, ok, fails, extra)
    problems = []
    if not a.skip_gen:
        gen_vectors()
    profs = ["full", "rand50", "burst"] if a.quick else PROFS_ALL
    # ---- model checks
    for name, mod in (("tools/check_model.py (decoder contract vs python-lz4)", "check_model"), ("tools/check_encmodel.py (encoder model vs python-lz4)", "check_encmodel")):
        r = subprocess.run([sys.executable, os.path.join(ROOT, "tools", mod + ".py")], capture_output=True, text=True)
        rows.append(("models", name, "", "PASS" if r.returncode == 0 else "FAIL", "", r.stdout.strip().splitlines()[-1] if r.stdout.strip() else ""))
        if r.returncode: problems.append(name)
    # ---- builds (serial: verilator uses the build dir)
    builds = {}
    for dut, cfgs in (("decoder", ["default", "small", "permissive", "opq8"]), ("encoder", ["default", "small", "fast", "tiny_table"]), ("core", ["default", "crc32c", "nocrc"])):
        for cfg in cfgs:
            if dut == "encoder": rp, mp = G.ENC_CONFIGS[cfg]
            elif dut == "core": rp, mp = {"default": {}, "crc32c": {"CRC_POLY": 0x82F63B78}, "nocrc": {"CRC_EN": 0, "PERF_EN": 0}}[cfg], {}
            else: rp, mp = G.RTL_PARAMS[cfg], {}
            builds[(dut, cfg)] = (R.build(dut, name=dut + ("" if cfg == "default" else "_" + cfg), params=rp), mp)
    # ---- jobs
    jobs = []
    for prof in profs:
        for s in ("dec_hand", "dec_bad", "dec_fuzz", "dec_lib", "dec_cli", "dec_ring", "dec_max", "dec_limits"):
            if s == "dec_max" and prof not in ("full", "rand50"): continue
            jobs.append(("decoder", "default", s, prof, []))
        for s in ("decs_hand", "decs_bad", "decs_fuzz", "decs_ring", "decs_limits"): jobs.append(("decoder", "small", s, prof, []))
        for s in ("decp_hand", "decp_bad", "decp_fuzz", "decp_ring", "decp_limits"): jobs.append(("decoder", "permissive", s, prof, []))
        if prof in ("full", "rand50"):
            for s in ("dec_hand", "dec_bad", "dec_lib", "dec_cli", "dec_max"): jobs.append(("decoder", "opq8", s, prof, []))
        for cfg in (["default", "small", "fast", "tiny_table"] if prof in ("full", "rand50") else ["default"]):
            for s in ("enc_lib", "enc_edge", "enc_pol", "enc_rnd"): jobs.append(("encoder", cfg, s, prof, []))
        for split in (0, 1): jobs.append(("core", "default", "core_mix", prof, ["--split", str(split)]))
        if prof in ("full", "rand50", "burst"):
            jobs.append(("core", "crc32c", "core_mix_c", prof, ["--split", "1"]))                    # CRC-32C polynomial (StorageFabric protection information)
            for s_ in ("dec_hand", "dec_lib", "enc_edge", "enc_pol"): jobs.append(("core", "nocrc", s_, prof, ["--split", "1"]))   # CRC stage and counters compiled out

    def do(job):
        dut, cfg, suite, prof, extra = job
        exe, mp = builds[(dut, cfg)]
        out, r, dt = R.run(exe, suite, prof, seed=1000 + zlib.crc32(f"{suite}/{prof}".encode()) % 997, extra=extra, outdir=os.path.join(ROOT, "build", "results", f"{dut}_{cfg}"))
        if dut == "decoder": c = R.check_decoder(suite, out)
        elif dut == "encoder": c = R.check_encoder(suite, out, mp)
        else: c = R.check_core(suite, out, crc_fn=(corpus.crc32c if cfg == "crc32c" else None))
        return job, c, r.returncode, dt

    agg = {}
    with ThreadPoolExecutor(a.jobs) as ex:
        for job, c, rc, dt in ex.map(do, jobs):
            dut, cfg, suite, prof, extra = job
            k = (dut, cfg, suite)
            g = agg.setdefault(k, dict(runs=0, vec=0, ok=0, fails=[], cyc=0, profs=[]))
            g["runs"] += 1; g["vec"] += c["total"]; g["ok"] += c["ok"]; g["cyc"] += c["trailer"]["cycles"] if c["trailer"] else 0
            g["profs"].append(prof + ("/split" + extra[1] if extra else ""))
            if c["fails"] or rc:
                g["fails"].append((prof, c["fails"][:2], rc)); problems.append(f"{dut}/{cfg}/{suite}/{prof}")
    for (dut, cfg, suite), g in sorted(agg.items()):
        rows.append((f"{dut} [{cfg}]", suite, f"{g['vec']} vectors in {g['runs']} runs", "PASS" if not g["fails"] else "FAIL", g["ok"], f"{g['cyc']:,} simulated cycles; profiles: {', '.join(sorted(set(g['profs'])))}" + (f"; FAILS {g['fails'][:2]}" if g["fails"] else "")))
    # ---- scripts with their own verdicts
    for name, cmd in (("hardware compress -> lz4 CLI frame decode (tests/interop_enc.py)", ["tests/interop_enc.py"]),
                      ("round trip HW compress -> HW decompress + perf counters (tests/roundtrip.py)", ["tests/roundtrip.py"]),
                      ("reset injection: decoder", ["tests/reset_test.py", "decoder"]), ("reset injection: encoder", ["tests/reset_test.py", "encoder"]),
                      ("reset injection: core", ["tests/reset_test.py", "core"])):
        r = subprocess.run([sys.executable, os.path.join(ROOT, cmd[0])] + cmd[1:], capture_output=True, text=True)
        last = [l for l in r.stdout.strip().splitlines() if l.strip()]
        rows.append(("scripts", name, "", "PASS" if r.returncode == 0 else "FAIL", "", " | ".join(last[-2:]) if last else r.stderr[-200:]))
        if r.returncode: problems.append(name)
    # ---- report
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    tv = sum(int(str(r[2]).split()[0]) for r in rows if "vectors" in str(r[2]))
    with open(os.path.join(ROOT, "reports", "regression.md"), "w") as f:
        f.write("# Regression report (scripts/regress.py%s)\n\n" % (" --quick" if a.quick else ""))
        f.write(f"Verilator {subprocess.run(['verilator','--version'],capture_output=True,text=True).stdout.split()[1]}, trusted reference: python-lz4 (LZ4 1.9.4) and the `lz4` v1.9.4 command-line tool. "
                f"Backpressure profiles: {', '.join(profs)}. Wall time {time.time()-t0:.0f} s.\n\n")
        f.write(f"**Total vector executions: {tv:,}. Overall: {'ALL PASS' if not problems else 'FAILURES: ' + ', '.join(problems)}**\n\n")
        f.write("| group | item | scope | result | ok | detail |\n|---|---|---|---|---|---|\n")
        for r in rows: f.write("| " + " | ".join(str(x) for x in r) + " |\n")
    print(open(os.path.join(ROOT, "reports", "regression.md")).read())
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
