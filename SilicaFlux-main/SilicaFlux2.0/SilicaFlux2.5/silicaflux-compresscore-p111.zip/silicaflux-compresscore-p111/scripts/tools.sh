#!/bin/bash
echo "verilator: $(verilator --version)"; echo "yosys:     $(yosys -V)"; echo "z3:        $(z3 --version)"; echo "iverilog:  $(iverilog -V 2>&1 | head -1)"
echo "lz4 CLI:   $(lz4 --version 2>&1 | head -1)"; echo "python:    $(python3 --version)"
python3 -c "import lz4; print('python-lz4:', lz4.__version__, '(LZ4', lz4.library_version_string() + ')')"
echo "g++:       $(g++ --version | head -1)"; echo "os:        $(uname -sr)"
