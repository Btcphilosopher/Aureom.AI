#!/bin/bash
# Builds the deliverable ZIP (nothing is committed to git).  usage: scripts/make_zip.sh [output.zip]
set -e
cd "$(dirname "$0")/.."
ROOT=$(basename "$PWD"); OUT=${1:-../$ROOT.zip}; rm -f "$OUT"
cd ..
zip -qr "$OUT" "$ROOT" -x "$ROOT/build/*" "$ROOT/vectors/*.sfv" "$ROOT/vectors/*.pkl" "*/__pycache__/*" "*.pyc" "$ROOT/benchmarks/quick_*.py" "*/.DS_Store"
echo "wrote $OUT: $(unzip -l "$OUT" | tail -1)"
