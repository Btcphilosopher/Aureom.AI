// Exhaustive proof (all input values) of the history-read legality lemma, on the REAL module sf_lz4_srcchk (the one the decoder instantiates).
module fv_srcchk #(parameter POSW = 16, parameter HIST_BYTES = 1024) (
  input wire [POSW-1:0] pos1, input wire [15:0] off, input wire [POSW-1:0] mpos, input wire [4:0] nn_raw
);
  wire [4:0] nn = (nn_raw == 5'd0 || nn_raw > 5'd16) ? 5'd16 : nn_raw;          // 1..16
  wire in_window, vis_ok; wire [POSW-1:0] src;
  sf_lz4_srcchk #(.POSW(POSW), .HIST_BYTES(HIST_BYTES)) dut (.pos1(pos1), .off(off), .mpos(mpos), .nn(nn), .in_window(in_window), .src(src), .vis_ok(vis_ok));
  // independent restatement of the window rule
  wire win_ref = (off >= 1) && (off <= pos1) && (off < HIST_BYTES);
  wire [POSW+1:0] src_w = {2'b00, pos1} - {2'b00, off};
  wire [POSW+1:0] end_w = {2'b00, src} + {{(POSW-3){1'b0}}, nn};
  always @* begin
    assert(in_window == win_ref);
    if (mpos <= pos1 && in_window) begin                                          // invariant of the decoder: committed bytes never exceed issued bytes
      assert(src == src_w[POSW-1:0]);                                             // no wrap-around: src = pos1 - off exactly
      assert(src < pos1);                                                         // source lies strictly before the destination
      if (vis_ok) begin
        assert(end_w <= {2'b00, mpos});                                           // (a) every source byte has already been written
        assert({2'b00, src} + HIST_BYTES >= {2'b00, mpos});                       // (b) the OLDEST source byte has not been overwritten by the ring
      end
      if (!vis_ok) assert(end_w > {2'b00, mpos});                                 // the read is refused exactly when some source byte is not yet committed
    end
  end
endmodule
