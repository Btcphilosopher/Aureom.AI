// Bounded proof: sf_lz4_fifo returns pushed words in order, never loses/duplicates, count/full/empty consistent, never over/underflows.
module fv_fifo #(parameter W = 8, parameter DEPTH = 4) (input wire clk, input wire push_req, input wire pop_req);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire [W-1:0] dout; wire full, empty; wire [$clog2(DEPTH+1)-1:0] count;
  reg [W-1:0] wseq = 0, rseq = 0;
  sf_lz4_fifo #(.W(W), .DEPTH(DEPTH)) dut (.clk(clk), .rst_n(rst_n), .flush(1'b0), .push(push_req), .din(wseq), .pop(pop_req), .dout(dout), .full(full), .empty(empty), .count(count));
  wire do_push = push_req && !full, do_pop = pop_req && !empty;
  always @(posedge clk) if (rst_n) begin
    if (do_push) wseq <= wseq + 1;
    if (do_pop)  rseq <= rseq + 1;
  end
  always @* if (rst_n) begin
    assert(count <= DEPTH);
    assert(count == (wseq - rseq));                       // occupancy == pushed - popped
    assert(full == (count == DEPTH));
    assert(empty == (count == 0));
    if (!empty) assert(dout == rseq);                     // first-word-fall-through: head is the oldest unpopped word, in order
  end
endmodule
