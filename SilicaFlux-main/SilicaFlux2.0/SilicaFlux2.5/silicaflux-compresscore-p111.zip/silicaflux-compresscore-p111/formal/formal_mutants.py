#!/usr/bin/env python3
"""Formal sensitivity check: every harness must FAIL on deliberately broken RTL (otherwise a PASS would mean nothing).  Each mutant is one textual change
to a scratch copy of the RTL; the matching harness is run and must report FAIL.  Writes reports/formal_mutants.md."""
import os, sys, shutil, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_formal as F
ROOT = F.ROOT
J = {j[0]: j for j in F.JOBS}
def quick(name, depth=None):
    j = list(J[name]);
    if depth: j[4] = depth
    return tuple(j)
# (mutant id, rtl module, old, new, harness job)
MUT = [
 ("srcchk-vis-plus1", "sf_lz4_srcchk", "<= {1'b0, mpos};", "<= {1'b0, mpos} + 1;", quick("srcchk_p16_h1024")),
 ("srcchk-window-le", "sf_lz4_srcchk", "(off32 < 32'(HIST_BYTES))", "(off32 <= 32'(HIST_BYTES))", quick("srcchk_p16_h1024")),
 ("srcchk-src-off", "sf_lz4_srcchk", "assign src       = pos1 - POSW'(off);", "assign src       = pos1 - POSW'(off) + 1'b1;", quick("srcchk_p16_h1024")),
 ("srcchk-off-lt", "sf_lz4_srcchk", "(off32 <= 32'(pos1))", "(off32 <= 32'(pos1) + 32'd1)", quick("srcchk_p16_h1024")),
 ("fifo-full", "sf_lz4_fifo", "assign full  = (count == CW'(DEPTH));", "assign full  = (count == CW'(DEPTH - 1));", quick("fifo_w8_d4", 8)),
 ("fifo-pop-skip", "sf_lz4_fifo", "if (do_pop)  rp <= rp + 1'b1;", "if (do_pop)  rp <= rp + 2'd2;", quick("fifo_w8_d4", 8)),
 ("pack-complete", "sf_lz4_pack", "wire            completes = (tot >= (LW+2)'(BYTES));", "wire            completes = (tot > (LW+2)'(BYTES));", quick("pack_dw16_f2", 9)),
 ("pack-mask", "sf_lz4_pack", "if ((LW+1)'(i) < in_n) cm[8*i +: 8] = in_data[8*i +: 8];", "if ((LW+1)'(i) <= in_n) cm[8*i +: 8] = in_data[8*i +: 8];", quick("pack_dw16_f2", 9)),
 ("pack-flush", "sf_lz4_pack", "if (h_valid && acc_n != '0) begin\n        f_push = !f_full;", "if (h_valid) begin\n        f_push = !f_full;", quick("pack_dw16_f2", 9)),
 ("pack-tid", "sf_lz4_pack", "h_n <= (LW+1)'(BYTES); h_tid <= in_tid;", "h_n <= (LW+1)'(BYTES); h_tid <= acc_tid;", quick("pack_dw16_f2", 9)),
 ("hist-hi-be", "sf_lz4_history", "wire [BYTES-1:0] w_hi_be = w_bewide[2*BYTES-1:BYTES];", "wire [BYTES-1:0] w_hi_be = w_bewide[2*BYTES-2:BYTES-1];", quick("history_dw16_h64", 4)),
 ("hist-bank", "sf_lz4_history", "wire              w_to_b0   = (w_word[0] == 1'b0);", "wire              w_to_b0   = (w_word[0] == 1'b1);", quick("history_dw16_h64", 4)),
 ("hist-roff", "sf_lz4_history", "roff_q <= r_off;", "roff_q <= r_off + 1'b1;", quick("history_dw16_h64", 4)),
 ("hist-wrap", "sf_lz4_history", "wire [WAW-1:0] w_word1 = w_word + 1'b1;", "wire [WAW-1:0] w_word1 = w_word + 2'd2;", quick("history_dw16_h64", 4)),
]
# mutants that provably do not change the observable behaviour the harness checks (the reason is part of the report)
EQUIVALENT = {"pack-complete": "word completion needs `> BYTES` instead of `>= BYTES`: an exactly-full accumulator is pushed one item later (or at the flush) -- the byte stream, beat shape, "
              "block ends and sideband are identical; only the cycle in which the word is pushed changes"}


def main():
    from concurrent.futures import ThreadPoolExecutor
    tmp = tempfile.mkdtemp(); out = os.path.join(ROOT, "build", "formal_mut"); shutil.rmtree(out, ignore_errors=True)
    def one(m):
        mid, mod, old, new, job = m
        d = os.path.join(tmp, mid); os.makedirs(d)
        files = []
        for f in F.RTL:
            src = open(os.path.join(ROOT, f)).read()
            if os.path.basename(f) == mod + ".sv":
                assert src.count(old) == 1, (mid, src.count(old)); src = src.replace(old, new)
            p = os.path.join(d, os.path.basename(f)); open(p, "w").write(src); files.append(p)
        j = list(job); j[0] = mid
        r = F.run(tuple(j), out, tmo=900, rtl_override=files)
        return m, r
    rows = []
    with ThreadPoolExecutor(4) as ex:
        for m, r in ex.map(one, MUT):
            rows.append((m, r)); print(f"{'detected' if r[1]=='FAIL' else ('equivalent' if m[0] in EQUIVALENT else r[1]):10s} {m[0]:18s} {r[2]:6.1f}s harness {m[4][0]}", flush=True)
    ok = all(r[1] == "FAIL" or m[0] in EQUIVALENT for m, r in rows)
    nfound = sum(1 for m, r in rows if r[1] == "FAIL"); neq = sum(1 for m, r in rows if r[1] != "FAIL" and m[0] in EQUIVALENT)
    with open(os.path.join(ROOT, "reports", "formal_mutants.md"), "w") as f:
        f.write("# Formal sensitivity (formal/formal_mutants.py)\n\nA proof is only meaningful if the harness can fail.  Each row: one injected RTL bug, the harness that must find it.\n\n"
                f"**{nfound} / {len(rows) - neq} non-equivalent injected bugs found by their harness; {neq} mutant(s) documented as equivalent.**\n\n| mutant | change | harness | result |\n|---|---|---|---|\n")
        for m, r in rows: f.write(f"| {m[0]} | `{m[2][:50].strip()}` -> `{m[3][:50].strip()}` | {m[4][0]} (depth {m[4][4]}) | {'FOUND (FAIL)' if r[1]=='FAIL' else ('equivalent: ' + EQUIVALENT[m[0]] if m[0] in EQUIVALENT else r[1])} |\n")
    sys.exit(0 if ok else 1)
if __name__ == "__main__":
    main()
