#!/usr/bin/env python3
"""Formal runner (Yosys 0.33 + Z3 4.8; SymbiYosys is not packaged for this environment, so the same pipeline is driven directly, as in the StreamDMA project).
'exhaustive' = bit-vector SAT over ALL input values (a proof).  'BMC' = bounded model check from reset to the stated depth (a bounded proof, NOT an unbounded one).
usage: run_formal.py [--only NAME] [--report reports/formal.md]"""
import argparse, os, subprocess, sys, time, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/sf_lz4_fifo.sv", "rtl/sf_lz4_sram_1r1w.sv", "rtl/sf_lz4_history.sv", "rtl/sf_lz4_pack.sv", "rtl/sf_lz4_srcchk.sv"]
# name, harness file, top, params, depth, engine, what is proved
JOBS = [
 ("srcchk_p16_h1024", "fv_srcchk.sv", "fv_srcchk", "POSW=16 HIST_BYTES=1024", 1, "smt", "history-read legality lemma, exhaustive: source bytes written AND not overwritten"),
 ("srcchk_p23_h65536", "fv_srcchk.sv", "fv_srcchk", "POSW=23 HIST_BYTES=65536", 1, "smt", "the same lemma at the DEFAULT decoder widths (23-bit positions, 64 KiB window), exhaustive"),
 ("srcchk_p12_h4096", "fv_srcchk.sv", "fv_srcchk", "POSW=12 HIST_BYTES=4096", 1, "smt", "the same lemma, window == position range"),
 ("fifo_w8_d4", "fv_fifo.sv", "fv_fifo", "W=8 DEPTH=4", 14, "sat", "FIFO order / count / full / empty (BMC)"),
 ("fifo_w4_d2", "fv_fifo.sv", "fv_fifo", "W=4 DEPTH=2", 14, "sat", "FIFO order / count / full / empty, depth 2 (BMC)"),
 ("pack_dw16_f2", "fv_pack.sv", "fv_pack", "DW=16 FDEPTH=2", 12, "sat", "packer, 2-byte beats, FIFO depth 2: byte conservation, dense beats, block ends, tid/side, stall stability (BMC)"),
 ("pack_dw32_f2", "fv_pack.sv", "fv_pack", "DW=32 FDEPTH=2", 10, "sat", "packer, 4-byte beats: the same properties (BMC)"),
 ("pack_dw16_f4", "fv_pack.sv", "fv_pack", "DW=16 FDEPTH=4", 10, "sat", "packer, FIFO depth 4 (the depth used in the RTL): the same properties (BMC)"),
 ("history_dw32_h64", "fv_history.sv", "fv_history", "DW=32 HIST_BYTES=64 POSW=8", 5, "sat", "ring == shadow memory: byte enables, bank straddle, wrap (BMC)"),
 ("history_dw64_h128", "fv_history.sv", "fv_history", "DW=64 HIST_BYTES=128 POSW=9", 4, "sat", "ring == shadow memory, 8-byte words (BMC)"),
 ("history_dw16_h64", "fv_history.sv", "fv_history", "DW=16 HIST_BYTES=64 POSW=7", 5, "sat", "ring == shadow memory, 2-byte words, 32 words (BMC)"),
]

def prep(job, rtl_override=None):
    name, h, top, params, depth, eng, what = job
    rtl = rtl_override or RTL
    ys = ["read_verilog -formal -sv -I rtl " + " ".join(rtl) + " formal/" + h]
    for kv in params.split():
        k, v = kv.split("="); ys.append(f"chparam -set {k} {v} {top}")
    ys += [f"prep -top {top}", "flatten", "memory_map", "async2sync", "dffunmap"]
    return ys

def run(job, out, cwd=None, tmo=1200, rtl_override=None):
    name, h, top, params, depth, eng, what = job
    cwd = cwd or ROOT; d = os.path.join(out, name); os.makedirs(d, exist_ok=True)
    ys = prep(job, rtl_override); t0 = time.time()
    if eng == "sat":
        ys.append(f"sat -verify -seq {depth} -prove-asserts -timeout {tmo}")
        try: r = subprocess.run(["yosys", "-q", "-l", f"{d}/log.txt", "-p", "; ".join(ys)], cwd=cwd, capture_output=True, text=True, timeout=tmo + 60)
        except subprocess.TimeoutExpired: return name, "TIMEOUT", time.time() - t0, "", what
        log = open(f"{d}/log.txt").read() if os.path.exists(f"{d}/log.txt") else ""
        st = "PASS" if "no model found: SUCCESS" in log else ("FAIL" if "model found: FAIL" in log else "ERROR")
        return name, st, time.time() - t0, "" if st == "PASS" else (r.stdout + r.stderr)[-300:], what
    ys += [f"write_smt2 -wires {d}/m.smt2"]
    r = subprocess.run(["yosys", "-q", "-p", "; ".join(ys)], cwd=cwd, capture_output=True, text=True)
    if r.returncode: return name, "ERROR", 0, r.stdout[-400:] + r.stderr[-400:], what
    try: b = subprocess.run(["yosys-smtbmc", "-s", "z3", "-t", str(depth), "--presat", f"{d}/m.smt2"], cwd=cwd, capture_output=True, text=True, timeout=tmo)
    except subprocess.TimeoutExpired: return name, "TIMEOUT", time.time() - t0, "", what
    st = "PASS" if "Status: PASSED" in b.stdout else ("FAIL" if "Status: FAILED" in b.stdout else "ERROR")
    return name, st, time.time() - t0, "" if st == "PASS" else b.stdout[-300:], what

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--only"); ap.add_argument("--report", default="reports/formal.md"); a = ap.parse_args()
    out = os.path.join(ROOT, "build", "formal"); shutil.rmtree(out, ignore_errors=True)
    rows = []
    from concurrent.futures import ThreadPoolExecutor
    todo = [j for j in JOBS if not a.only or a.only in j[0]]
    with ThreadPoolExecutor(4) as ex:
        for r, j in zip(ex.map(lambda j: run(j, out, tmo=1500), todo), todo):
            rows.append((r, j)); print(f"{r[1]:5s} {r[0]:20s} {r[2]:6.1f}s  {r[4]}  {r[3]}", flush=True)
    ok = all(r[0][1] == "PASS" for r in rows)
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    with open(os.path.join(ROOT, a.report), "w") as f:
        f.write("# Formal verification results\n\nTools: Yosys 0.33 (built-in SAT for the sequential jobs, `yosys-smtbmc` + Z3 4.8.12 for the exhaustive combinational jobs). SymbiYosys is not packaged for this environment.\n"
                "'exhaustive' = bit-vector SAT over ALL input values (a proof). 'BMC' = bounded model check from reset to the stated depth (a bounded proof, NOT an unbounded one).\n\n"
                "| job | result | depth | time | engine | what |\n|---|---|---|---|---|---|\n")
        for (r, j) in rows: f.write(f"| {r[0]} | {r[1]} | {j[4]} | {r[2]:.1f}s | {j[5]} | {r[4]} |\n")
        f.write("\nNot formally verified (simulation, mutation testing and the independent software models only): the decoder parser / copy engine as a whole, the encoder, match finder, "
                "stream adapter, CRC stage and performance counters.  The decoder's SRAM-hazard predicate (`sf_lz4_srcchk`) and the history ring are the two places where a subtle "
                "off-by-one would corrupt data silently, which is why they are proved rather than only simulated.\n")
    sys.exit(0 if ok else 1)
