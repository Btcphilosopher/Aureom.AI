// Bounded proof for sf_lz4_pack.  Input bytes carry an 8-bit sequence tag; blocks end at in_end.  Proved at the output:
//   * the output byte stream equals the input byte stream (order preserved, nothing lost, duplicated or invented)
//   * every beat except the last of a block is FULL; the last beat of a block holds the block's remaining bytes (1..BYTES), or 0 only for an empty block
//   * out_last coincides EXACTLY with the end of a block (the k-th out_last ends at the k-th in_end's byte count)
//   * tid is carried to every beat, the end-sideband is delivered with out_last; the output is stable while stalled; the FIFO never overflows
module fv_pack #(parameter DW = 32, parameter FDEPTH = 4) (
  input wire clk, input wire in_valid, input wire [7:0] n_raw, input wire in_end, input wire out_ready, input wire [3:0] side_raw
);
  localparam BYTES = DW / 8, LW = $clog2(BYTES);
  reg rst_n = 1'b0; always @(posedge clk) rst_n <= 1'b1;
  wire [LW:0] in_n = n_raw % (BYTES + 1);                                    // 0..BYTES valid bytes
  reg [7:0] seq_in = 0, seq_out = 0; reg [3:0] blk_in = 0, blk_out = 0;
  reg [DW-1:0] in_data;
  integer i;
  // lanes below in_n carry the stream tags; lanes ABOVE in_n carry genuine junk (the complement of the tag), so a packer that fails to mask unused lanes is caught
  always @* begin in_data = 0; for (i = 0; i < BYTES; i = i + 1) in_data[8*i +: 8] = (i < in_n) ? (seq_in + i) : ~(seq_in + i); end
  wire in_ready, out_valid, out_last, busy; wire [DW-1:0] out_data; wire [LW:0] out_n; wire [3:0] out_tid, out_side;
  sf_lz4_pack #(.DW(DW), .TIDW(4), .SIDEW(4), .FDEPTH(FDEPTH)) dut (.clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(in_ready), .in_data(in_data), .in_n(in_n),
    .in_end(in_end), .in_tid(blk_in), .in_side(side_raw ^ blk_in), .out_valid(out_valid), .out_ready(out_ready), .out_data(out_data), .out_n(out_n), .out_last(out_last),
    .out_tid(out_tid), .out_side(out_side), .busy(busy));
  wire in_fire = in_valid && in_ready, out_fire = out_valid && out_ready;
  // shadow queue of (end sequence number, side) per block in flight
  reg [7:0] endq_seq [0:15]; reg [3:0] endq_side [0:15]; reg [3:0] wp = 0, rp = 0;
  reg [7:0] blk_bytes_in = 0, blk_bytes_out = 0;            // bytes of the block being output so far
  reg pv = 0, pstall = 0; reg [DW-1:0] pd; reg [LW:0] pn; reg pl; reg [3:0] ptid;
  integer b;
  always @(posedge clk) if (rst_n) begin
    if (in_fire) begin
      seq_in <= seq_in + in_n;
      if (in_end) begin endq_seq[wp] <= seq_in + in_n; endq_side[wp] <= side_raw ^ blk_in; wp <= wp + 1; blk_in <= blk_in + 1; end
    end
    if (out_fire) begin
      seq_out <= seq_out + out_n;
      if (out_last) begin rp <= rp + 1; blk_out <= blk_out + 1; blk_bytes_out <= 0; end else blk_bytes_out <= blk_bytes_out + out_n;
    end
    pv <= out_valid; pstall <= out_valid && !out_ready; pd <= out_data; pn <= out_n; pl <= out_last; ptid <= out_tid;
  end
  always @* if (rst_n) begin
    if (out_valid) begin
      for (b = 0; b < BYTES; b = b + 1) if (b < out_n) assert(out_data[8*b +: 8] == (seq_out + b));      // order / no loss / no duplication / nothing invented
      assert(out_n <= BYTES);
      if (!out_last) assert(out_n == BYTES);                                                             // dense: only the last beat of a block may be partial
      assert(out_tid == blk_out);                                                                        // tid of the block this beat belongs to
    end
    if (out_valid && out_last) begin
      assert(wp != rp);                                                                                  // the last beat only after the block's in_end
      assert(seq_out + out_n == endq_seq[rp]);                                                           // ends exactly at the byte count of the k-th in_end
      assert(out_side == endq_side[rp]);                                                                 // sideband of that block
      if (out_n == 0) assert(blk_bytes_out == 0);                                                        // an empty beat only for a block with no bytes
      assert(out_n != 0 || seq_out == endq_seq[rp]);
    end
    if (pstall) begin                                                                                    // stability while stalled
      assert(out_valid); assert(out_n == pn); assert(out_last == pl); assert(out_tid == ptid);
    end
  end
endmodule
