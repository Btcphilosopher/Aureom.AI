// Bounded proof for sf_lz4_history (two-bank ring, byte-enable writes, unaligned 1-cycle reads).  A shadow byte array models the ring
// (position p lives at slot p mod HIST_BYTES).  For every read issued, EVERY byte that has been written at least once must come back with the
// value last written to its slot (read-before-write semantics: the read sees the state at the start of its cycle).  Covers byte-enable merging,
// writes/reads that straddle two words and two banks, and ring wrap-around.
module fv_history #(parameter DW = 32, parameter HIST_BYTES = 64, parameter POSW = 8) (
  input wire clk, input wire wr_valid, input wire [POSW-1:0] wr_pos, input wire [7:0] wr_n_raw, input wire [DW-1:0] wr_data,
  input wire rd_valid, input wire [POSW-1:0] rd_pos
);
  localparam BYTES = DW / 8, LW = $clog2(BYTES);
  wire [LW:0] wr_n = (wr_n_raw % BYTES) + 1;                                  // 1..BYTES
  wire [DW-1:0] rd_data;
  sf_lz4_history #(.DW(DW), .HIST_BYTES(HIST_BYTES), .POSW(POSW)) dut (.clk(clk), .wr_valid(wr_valid), .wr_pos(wr_pos), .wr_n(wr_n), .wr_data(wr_data),
                                                                    .rd_valid(rd_valid), .rd_pos(rd_pos), .rd_data(rd_data));
  reg [7:0] shadow [0:HIST_BYTES-1]; reg [HIST_BYTES-1:0] wrt = 0;          // value + "written at least once"
  reg exp_v = 0; reg [DW-1:0] exp_d = 0; reg [BYTES-1:0] exp_m = 0;
  integer i, k;
  reg [DW-1:0] nd; reg [BYTES-1:0] nm;
  always @(posedge clk) begin
    exp_v <= rd_valid;
    nd = 0; nm = 0;
    for (i = 0; i < BYTES; i = i + 1) begin
      nd[8*i +: 8] = shadow[(rd_pos + i) % HIST_BYTES]; nm[i] = wrt[(rd_pos + i) % HIST_BYTES];
    end
    exp_d <= nd; exp_m <= nm;                                                 // state as of the start of the read cycle (before this edge's write)
    if (wr_valid) for (k = 0; k < BYTES; k = k + 1) if (k < wr_n) begin
      shadow[(wr_pos + k) % HIST_BYTES] <= wr_data[8*k +: 8]; wrt[(wr_pos + k) % HIST_BYTES] <= 1'b1;
    end
  end
  reg hold = 0;                                                               // rd_data must HOLD until the next read: check one cycle after a read with no new read
  always @* begin
    if (exp_v) for (i = 0; i < BYTES; i = i + 1) if (exp_m[i]) assert(rd_data[8*i +: 8] == exp_d[8*i +: 8]);
  end
endmodule
