// DUT binding: sf_lz4_decoder (dense beats, in_n byte counts)
#pragma once
#include "Vsf_lz4_decoder.h"
#include "tb_common.h"
typedef Vsf_lz4_decoder DUT;
static const bool DUT_HAS_KEEP = false;
static const char* EVNAMES[NEV] = {"raw_stall", "pat_bubble", "out_stall", "opq_stall", "hist_rd", "hist_wr", "busy", "-"};
static inline void drive_in(DUT* t, const Beat& b, bool have, const Rec* r, uint64_t junk) {
  t->in_n = b.n; t->in_first = b.first; t->in_last = b.last; t->in_ferr = 0;
  t->in_tid = have ? (r->tid & 0xFF) : (uint8_t)junk; t->in_cap = have ? r->cap : (uint32_t)junk;
  for (int w = 0; w < 4; w++) { uint32_t x = 0; for (int k = 0; k < 4; k++) x |= (uint32_t)b.d[4 * w + k] << (8 * k); t->in_data[w] = x; }
}
static inline void sample_out(DUT* t, OutBeat& o) {
  for (int w = 0; w < 4; w++) { uint32_t x = t->out_data[w]; for (int k = 0; k < 4; k++) o.d[4 * w + k] = (x >> (8 * k)) & 0xFF; }
  o.n = t->out_n; o.last = t->out_last; o.tid = t->out_tid; o.status = t->out_status; o.in_bytes = t->out_in_bytes; o.out_bytes = t->out_out_bytes;
  o.crc = 0; o.crc_valid = 0; o.raw = 0;
}
static inline void sample_events(DUT* t, uint64_t* ev) {
  ev[0] += t->ev_raw_stall; ev[1] += t->ev_pat_bubble; ev[2] += t->ev_out_stall; ev[3] += t->ev_opq_stall; ev[4] += t->ev_hist_rd; ev[5] += t->ev_hist_wr; ev[6] += t->busy;
}

static const bool HAS_PERF = false;
static inline void perf_drive(DUT*, bool, bool, int) {}
static inline uint64_t perf_read(DUT*) { return 0; }
static inline bool perf_busy(DUT*) { return false; }
