#!/usr/bin/env python3
"""Reset test: inject a reset at many different cycles during vector streams (under backpressure); every record that was NOT in flight must still
be bit-exact/valid, aborted ones are reported as aborted by the bench, nothing may hang and the monitors stay clean."""
import os, sys, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import run_suite as R

def main(dut="decoder", suites=None, n=40, config="default"):
    import genvec
    if dut == "decoder":
        suites = suites or ("dec_hand", "dec_lib", "dec_bad"); rp, mp = genvec.RTL_PARAMS[config], {}
        chk = lambda s, out: R.check_decoder(s, out)
    elif dut == "core":
        suites = suites or ("core_mix",); rp, mp = {}, {}
        chk = lambda s, out: R.check_core(s, out)
    else:
        suites = suites or ("enc_edge", "enc_pol", "enc_rnd"); rp, mp = genvec.ENC_CONFIGS[config]
        chk = lambda s, out: R.check_encoder(s, out, mp)
    exe = R.build(dut, name=dut + ("" if config == "default" else "_" + config), params=rp)
    rng = random.Random(99)
    tot = aborted = bad = runs = 0
    for k in range(n):
        s = suites[k % len(suites)]
        prof = rng.choice(["full", "rand50", "burst", "slow_out", "rand_lo"])
        at = rng.randrange(50, 400000 if dut == "decoder" else 3000000)
        ex = ["--reset-at", str(at)] + (["--split", str(rng.randrange(2))] if dut == "core" else [])
        out, r, dt = R.run(exe, s, prof, seed=100 + k, extra=ex)
        c = chk(s, out)
        runs += 1; tot += c["total"]; aborted += c["aborted"]
        if c["fails"] or r.returncode:
            bad += 1; print("FAIL", s, prof, at, c["fails"][:3], r.stderr[-300:])
    print(f"reset test [{dut}]: {runs} runs, {tot} records, {aborted} aborted by reset, {tot-aborted} checked, failing runs: {bad}")
    return bad

if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else "decoder"
    sys.exit(1 if main(d) else 0)
