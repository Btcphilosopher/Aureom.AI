// =============================================================================
// CompressCore verification bench (Verilator): a DRIVER + RECORDER.  It contains no expected values; every pass/fail decision is made
// by tests/run_suite.py against the independent software models (tools/lz4model.py, python-lz4, lz4 CLI).
//
//   vector file (.sfv)  : 'SFV1', then records { u32 id, mode, cap, policy, flags, exp_crc, tid, in_len; u8 data[in_len] }
//   result file (.sfr)  : 'SFR1', then records { u32 id, status, raw, in_bytes, out_bytes, crc, crc_valid, latency, out_len, nbeats; u8 data[out_len] }
//                         trailer record id = 0xFFFFFFFF carrying global counters
//   status 0xFFFF       : the record was in flight when a reset was injected (aborted by the test)
//
//   arguments: --vec F --out F --seed N --pin P --pout P --burst B --reset-at CYCLE --maxcyc N --split S --back0 K
//     P  : probability (0..1) that in_valid / out_ready is asserted in a cycle      B : 1 = bursty (long runs) instead of per-cycle random
//     S  : (core only) input beat-splitting: 0 = dense 16-byte beats, 1 = random partial beats      --serialize 1 : withhold each block start until the previous block completed
//   Monitors: held-valid on the input; output stable while stalled; beat shape (full beats except the last, no trailing empty beat);
//             no output after completion / no output before a block was started; per-block hang watchdog.
// =============================================================================
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <vector>
#include <string>
#include <random>
#include <deque>
#include "verilated.h"
#include "tb_common.h"
#include BIND_HEADER

struct Res { uint32_t id = 0, status = 0xFFFE, raw = 0, in_bytes = 0, out_bytes = 0, crc = 0, crc_valid = 0, latency = 0, nbeats = 0; std::vector<uint8_t> data;
             bool done = false; uint64_t t_first_in = 0; bool started = false; };

static std::vector<Rec> read_vec(const char* fn) {
  FILE* f = fopen(fn, "rb"); if (!f) { perror(fn); exit(2); }
  char m[4]; if (fread(m, 1, 4, f) != 4 || memcmp(m, "SFV1", 4)) { fprintf(stderr, "bad vector file\n"); exit(2); }
  std::vector<Rec> v;
  for (;;) {
    uint32_t h[8]; if (fread(h, 4, 8, f) != 8) break;
    Rec r; r.id = h[0]; r.mode = h[1]; r.cap = h[2]; r.policy = h[3]; r.flags = h[4]; r.exp_crc = h[5]; r.tid = h[6];
    r.data.resize(h[7]); if (h[7] && fread(r.data.data(), 1, h[7], f) != h[7]) break;
    v.push_back(std::move(r));
  }
  fclose(f); return v;
}

static std::mt19937_64 rng;
static double urand() { return (rng() >> 11) * (1.0 / 9007199254740992.0); }

struct Gate {                         // per-cycle random enable, optionally bursty
  double p; bool burst; bool st = true; int left = 0;
  bool next() {
    if (p >= 1.0) return true;
    if (!burst) return urand() < p;
    if (left <= 0) { st = (urand() < p); left = 1 + (int)(urand() * 48); }
    left--; return st;
  }
};

int main(int argc, char** argv) {
  Verilated::commandArgs(argc, argv);
  std::string vec, outf = "out.sfr"; uint64_t seed = 1, reset_at = 0, maxcyc = 400000000ULL; double pin = 1, pout = 1; int burst = 0, split = 0, serialize = 0;
  for (int i = 1; i < argc; i++) {
    std::string a = argv[i];
    auto nx = [&]() { return std::string(argv[++i]); };
    if (a == "--vec") vec = nx(); else if (a == "--out") outf = nx(); else if (a == "--seed") seed = std::stoull(nx());
    else if (a == "--pin") pin = std::stod(nx()); else if (a == "--pout") pout = std::stod(nx()); else if (a == "--burst") burst = std::stoi(nx());
    else if (a == "--reset-at") reset_at = std::stoull(nx()); else if (a == "--maxcyc") maxcyc = std::stoull(nx());
    else if (a == "--split") split = std::stoi(nx()); else if (a == "--serialize") serialize = std::stoi(nx());
  }
  if (vec.empty()) { fprintf(stderr, "no --vec\n"); return 2; }
  rng.seed(seed);
  std::vector<Rec> recs = read_vec(vec.c_str());
  std::vector<Res> res(recs.size());
  for (size_t i = 0; i < recs.size(); i++) res[i].id = recs[i].id;

  DUT* top = new DUT;
  Gate gin{pin, burst != 0}, gout{pout, burst != 0};

  // ---- input beat generator
  bool fault3_done = false;
  size_t in_rec = 0, in_off = 0; bool in_have_beat = false, in_hold = false; Beat cur{};
  auto make_beat = [&]() -> bool {
    if (in_rec >= recs.size()) return false;
    Rec& r = recs[in_rec];
    int left = (int)(r.data.size() - in_off);
    int n;
    if (split && DUT_HAS_KEEP) { n = left == 0 ? 0 : 1 + (int)(rng() % (left < 16 ? left : 16)); if (rng() % 3 == 0 && left >= 16) n = 16; }
    else n = left > 16 ? 16 : left;
    memset(cur.d, 0, 16); for (int i = 0; i < 16; i++) cur.d[i] = (uint8_t)rng();    // garbage in unused lanes
    if (n) memcpy(cur.d, r.data.data() + in_off, n);
    cur.n = n; cur.first = (in_off == 0); in_off += n; cur.last = (in_off >= r.data.size()); cur.rec = in_rec;
    cur.keep = (uint16_t)(n >= 16 ? 0xFFFF : ((1u << n) - 1));
    // injected framing faults (core only; the expectation for such a record is "completes with an error and the stream recovers")
    if (cur.first) fault3_done = false;
    int fault = (r.flags >> 8) & 3;
    if (DUT_HAS_KEEP && fault) {
      bool is_first_beat = cur.first;
      if (fault == 1 && is_first_beat) cur.first = false;
      if (fault == 2 && !is_first_beat && !cur.first) cur.first = true;
      if (fault == 3 && n >= 3 && !fault3_done) { cur.keep = (uint16_t)(cur.keep & ~(1u << 1)); fault3_done = true; }
    }
    return true;
  };

  // ---- output collector
  size_t out_rec = 0; bool out_prev_valid = false, out_prev_stall = false; uint8_t pd[16]; int pn = 0; bool plast = false; uint32_t ptid = 0;
  uint64_t cyc = 0, in_stall = 0, out_stall = 0, proto_err = 0, in_beats = 0, out_beats = 0, busy_cyc = 0;
  uint64_t ev[NEV] = {0};
  uint64_t last_progress = 0;
  uint64_t reset_left = 0; bool did_reset = false;
  size_t blk_bytes_out = 0;

  top->rst_n = 0; top->in_valid = 0; top->out_ready = 0; if (HAS_PERF) perf_drive(top, false, false, 0);
  for (int i = 0; i < 8; i++) { top->clk = 0; top->eval(); top->clk = 1; top->eval(); }
  top->rst_n = 1;

  while (cyc < maxcyc) {
    bool all_fed = (in_rec >= recs.size()) && !in_have_beat;
    bool all_done = (out_rec >= recs.size());
    if (all_done) break;
    // --- reset injection
    bool in_reset = false;
    if (reset_at && !did_reset && cyc >= reset_at && in_rec < recs.size()) { did_reset = true; reset_left = 5; }
    if (reset_left) {
      in_reset = true; reset_left--;
      if (reset_left == 4) {              // abort everything in flight
        for (size_t k = out_rec; k <= in_rec && k < recs.size(); k++) { res[k].status = 0xFFFF; res[k].done = true; }
        out_rec = in_rec + 1; in_rec = in_rec + 1; in_off = 0; in_have_beat = false; in_hold = false; out_prev_valid = false; out_prev_stall = false; blk_bytes_out = 0;
        if (out_rec >= recs.size()) break;
      }
    }
    // --- choose inputs for this cycle
    bool want_in = false;
    if (!in_reset) {
      if (!in_have_beat) in_have_beat = make_beat();
      if (in_have_beat) { if (in_hold) want_in = true; else want_in = gin.next(); }
      // --serialize: a block start is withheld until every earlier block has COMPLETED (single block alone in an idle core: latency measurements)
      if (serialize && in_have_beat && !in_hold && cur.first && out_rec < in_rec) want_in = false;
    }
    bool out_rdy = in_reset ? (urand() < 0.5) : gout.next();
    top->rst_n = in_reset ? 0 : 1;
    top->out_ready = out_rdy;
    top->in_valid = want_in;
    drive_in(top, cur, in_have_beat, in_have_beat ? &recs[cur.rec] : nullptr, rng());
    top->clk = 0; top->eval();
    bool in_fire = want_in && top->in_ready && !in_reset;
    bool ov = top->out_valid && !in_reset;
    bool out_fire = ov && out_rdy;
    // --- sample output
    OutBeat ob; memset(&ob, 0, sizeof(ob));
    uint8_t* od = ob.d; int on = 0; bool olast = false; uint32_t otid = 0, ostatus = 0, oin = 0, oout = 0, ocrc = 0, ocrcv = 0, oraw = 0, omode = 0;
    if (ov) {
      sample_out(top, ob);
      on = ob.n; olast = ob.last; otid = ob.tid; ostatus = ob.status; oin = ob.in_bytes; oout = ob.out_bytes; ocrc = ob.crc; ocrcv = ob.crc_valid; oraw = ob.raw; omode = ob.mode;
      // monitors
      if (out_prev_valid && out_prev_stall) {
        if (on != pn || olast != plast || otid != ptid) { proto_err++; fprintf(stderr, "[cyc %llu] output control changed while stalled\n", (unsigned long long)cyc); }
        else { for (int i = 0; i < pn; i++) if (od[i] != pd[i]) { proto_err++; fprintf(stderr, "[cyc %llu] output data changed while stalled\n", (unsigned long long)cyc); break; } }
      }
      if (out_rec >= recs.size()) { proto_err++; fprintf(stderr, "[cyc %llu] output after the last record\n", (unsigned long long)cyc); }
      if (!olast && on != 16) { proto_err++; fprintf(stderr, "[cyc %llu] non-last beat is not full (n=%d)\n", (unsigned long long)cyc, on); }
      if (olast && on == 0 && blk_bytes_out != 0) { proto_err++; fprintf(stderr, "[cyc %llu] trailing empty last beat\n", (unsigned long long)cyc); }
      if (on > 16) { proto_err++; fprintf(stderr, "[cyc %llu] out_n > 16\n", (unsigned long long)cyc); }
    }
    sample_events(top, ev);
    if (want_in && !top->in_ready && !in_reset) in_stall++;
    if (ov && !out_rdy) out_stall++;
    top->clk = 1; top->eval();
    // --- advance state
    if (in_fire) {
      in_beats++; last_progress = cyc;
      Res& r = res[cur.rec];
      if (cur.first) { r.t_first_in = cyc; r.started = true; }
      in_have_beat = false; in_hold = false;
      if (cur.last) { in_rec++; in_off = 0; }
    } else if (want_in) in_hold = true;
    if (out_fire && out_rec < recs.size()) {
      out_beats++; last_progress = cyc;
      Res& r = res[out_rec];
      r.data.insert(r.data.end(), od, od + on); r.nbeats++; blk_bytes_out += on;
      if (olast) {
        r.status = ostatus; r.in_bytes = oin; r.out_bytes = oout; r.crc = ocrc; r.crc_valid = ocrcv; r.raw = oraw | (omode << 1); r.done = true;
        r.latency = (uint32_t)(cyc - r.t_first_in + 1);
        if (otid != (recs[out_rec].tid & 0xFF)) { proto_err++; fprintf(stderr, "record %zu: tid %u != %u\n", out_rec, otid, recs[out_rec].tid & 0xFF); }
        out_rec++; blk_bytes_out = 0;
      }
    }
    out_prev_valid = ov; out_prev_stall = ov && !out_rdy; pn = on; plast = olast; ptid = otid; memcpy(pd, od, 16);
    if (!all_fed || !all_done) busy_cyc++;
    cyc++;
    if (cyc - last_progress > 3000000ULL) { fprintf(stderr, "WATCHDOG: no progress for 3M cycles at record in=%zu out=%zu\n", in_rec, out_rec); proto_err++; break; }
  }
  if (HAS_PERF && !reset_at) {      // snapshot the counters and read them all back
    auto tick = [&]() { top->clk = 0; top->eval(); top->clk = 1; top->eval(); };
    top->in_valid = 0; top->out_ready = 1;
    perf_drive(top, false, true, 0); tick(); perf_drive(top, false, false, 0); tick();
    for (int i = 0; i < 4000 && perf_busy(top); i++) tick();
    for (int sel = 0; sel < 36; sel++) { perf_drive(top, false, false, sel); top->clk = 0; top->eval(); printf("perf %d %llu\n", sel, (unsigned long long)perf_read(top)); }
  }
  bool complete = (out_rec >= recs.size());
  if (!complete) { fprintf(stderr, "INCOMPLETE: out_rec=%zu of %zu after %llu cycles\n", out_rec, recs.size(), (unsigned long long)cyc); proto_err++; }

  FILE* f = fopen(outf.c_str(), "wb"); if (!f) { perror(outf.c_str()); return 2; }
  fwrite("SFR1", 1, 4, f);
  for (auto& r : res) {
    uint32_t h[10] = {r.id, r.status, r.raw, r.in_bytes, r.out_bytes, r.crc, r.crc_valid, r.latency, (uint32_t)r.data.size(), r.nbeats};
    fwrite(h, 4, 10, f); if (!r.data.empty()) fwrite(r.data.data(), 1, r.data.size(), f);
  }
  uint32_t t[10] = {0xFFFFFFFFu, (uint32_t)cyc, (uint32_t)in_stall, (uint32_t)out_stall, (uint32_t)proto_err, (uint32_t)in_beats, (uint32_t)out_beats,
                    (uint32_t)busy_cyc, 0, 0};
  fwrite(t, 4, 10, f); fclose(f);
  printf("cycles=%llu in_beats=%llu out_beats=%llu in_stall=%llu out_stall=%llu proto_err=%llu\n", (unsigned long long)cyc, (unsigned long long)in_beats,
         (unsigned long long)out_beats, (unsigned long long)in_stall, (unsigned long long)out_stall, (unsigned long long)proto_err);
  for (int k = 0; k < NEV; k++) if (EVNAMES[k][0] != '-') printf("ev_%s=%llu\n", EVNAMES[k], (unsigned long long)ev[k]);
  delete top;
  return proto_err ? 1 : 0;
}
