#!/usr/bin/env python3
"""Hardware-compressed blocks -> LZ4 frame -> decoded by the independent `lz4` command-line tool (C reference implementation) AND the python library.
RAW-policy fallback blocks are carried as UNCOMPRESSED frame blocks (bit 31 of the block-size word), the format's own mechanism.
The frame carries a content checksum (xxHash32), so the tool verifies the whole stream.  Writes reports/interop_encoder.md"""
import os, sys, subprocess, tempfile, random, pickle
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
import run_suite as R, lz4frame as FR
import lz4.frame as LF
ROOT = R.ROOT

def main():
    exe = R.build("encoder")
    lines = ["# Encoder interoperability: hardware blocks decoded by the independent `lz4` command-line tool", "",
             f"`{subprocess.run(['lz4', '--version'], capture_output=True, text=True).stdout.strip()}`; python-lz4 {__import__('lz4').__version__}.", "",
             "| suite | blocks | of which RAW (uncompressed frame blocks) | frames | `lz4 -d` | python-lz4 frame decode |", "|---|---|---|---|---|---|"]
    allok = True
    for suite in ("enc_lib", "enc_edge", "enc_rnd"):
        out, r, dt = R.run(exe, suite, "rand50", 21)
        res, _ = R.read_results(out)
        meta = pickle.load(open(os.path.join(ROOT, "vectors", suite + ".exp.pkl"), "rb"))["meta"]
        # one frame per run of up to 40 consecutive OK blocks (independent blocks; contents concatenated)
        frames = []; cur = []; cur_content = b""
        for (id_, mode, cap, policy, flags, exp_crc, tid, ilen, tag, _a, _b, data) in meta:
            x = res[id_]
            if x["status"] != 0 or ilen == 0 or policy == 0 and cap: continue
            cur.append((x["data"], bool(x["raw"]))); cur_content += data
            if len(cur) >= 40: frames.append((cur, cur_content)); cur = []; cur_content = b""
        if cur: frames.append((cur, cur_content))
        nblk = sum(len(f[0]) for f in frames); nraw = sum(1 for f in frames for b in f[0] if b[1])
        ok_cli = ok_py = 0
        for blocks, content in frames:
            fr = FR.build_frame(blocks, content, bmax_id=4 if all(len(b[0]) <= 65536 for b in blocks) else 7)
            with tempfile.TemporaryDirectory() as d:
                open(os.path.join(d, "a.lz4"), "wb").write(fr)
                p = subprocess.run(["lz4", "-d", "-c", "-q", os.path.join(d, "a.lz4")], capture_output=True)
                if p.returncode == 0 and p.stdout == content: ok_cli += 1
                else: print("CLI FAIL", suite, p.returncode, p.stderr[:200])
            try:
                if LF.decompress(fr) == content: ok_py += 1
            except Exception as e: print("PY FAIL", e)
        allok &= (ok_cli == len(frames) and ok_py == len(frames))
        lines.append(f"| {suite} | {nblk} | {nraw} | {len(frames)} | {ok_cli}/{len(frames)} | {ok_py}/{len(frames)} |")
    open(os.path.join(ROOT, "reports", "interop_encoder.md"), "w").write("\n".join(lines) + "\n")
    print("\n".join(lines))
    return 0 if allok else 1

if __name__ == "__main__":
    sys.exit(main())
