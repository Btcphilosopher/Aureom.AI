#!/usr/bin/env python3
"""Round trip: raw data -> HARDWARE compress (core, mode 1) -> HARDWARE decompress (core, mode 0, CRC check on) -> must equal the raw data.
Both passes run under random backpressure and random input beat splitting.  Output blocks are also decoded by the reference library (encoder check).
Also verifies the performance counters against independent counts from the bench results."""
import os, sys, random, zlib, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
import run_suite as R, genvec as G, lz4model as M

def perf_regs(stdout):
    return {int(l.split()[1]): int(l.split()[2]) for l in stdout.splitlines() if l.startswith("perf ")}

def main(seed=7, exe=None, quiet=False):
    rng = random.Random(seed)
    exe = exe or R.build("core")
    src = G.suite_enc_lib() + G.suite_enc_edge()[:500] + G.suite_enc_rnd(150, 86)
    src = [v for v in src if len(v.data) <= 65536]
    for v in src:
        v.policy = rng.choice((0, 0, 2, 1)); v.cap = 0 if v.policy == 0 else len(v.data) + 20; v.flags = 1
    G.write_suite("core_rt_enc", src)
    out, r, dt = R.run(exe, "core_rt_enc", "rand50", seed, extra=["--split", "1"])
    c1 = R.check_core("core_rt_enc", out)
    res = c1["results"]
    dec = []
    n_raw = n_cmp = 0
    for v in src:
        x = res[v.id]
        if x["status"] != 0: continue
        if x["raw"]:
            assert x["data"] == v.data; n_raw += 1; continue
        n_cmp += 1
        d = G.Vec(0, x["data"], cap=len(v.data), flags=3, exp_crc=zlib.crc32(v.data) & 0xFFFFFFFF, tag="rt_" + v.tag, exp_status=0, exp_out=bytes(v.data))
        dec.append(d)
    G.write_suite("core_rt_dec", dec)
    out2, r2, dt2 = R.run(exe, "core_rt_dec", "burst", seed + 1, extra=["--split", "1"])
    c2 = R.check_core("core_rt_dec", out2)
    # perf counters vs bench results (second run: decode only)
    p = perf_regs(r2.stdout); res2 = c2["results"]
    exp_in = sum(len(d.data) for d in dec); exp_out = sum(len(res2[d.id]["data"]) for d in dec)
    lats = [res2[d.id]["latency"] for d in dec]
    checks = [("blocks_in", p[3], len(dec)), ("blocks_out", p[4], len(dec)), ("in_bytes", p[1], exp_in), ("out_bytes", p[2], exp_out), ("dec_blocks", p[6], len(dec)),
              ("dec_in_bytes", p[7], exp_in), ("dec_out_bytes", p[8], exp_out), ("enc_in_bytes", p[11], 0), ("lat_count", p[29], len(dec)), ("lat_max", p[27], max(lats)),
              ("lat_sum", p[28], sum(lats)), ("lat_last", p[26], lats[-1]), ("cycles", p[0], c2["trailer"]["cycles"]), ("in_stall", p[14], c2["trailer"]["in_stall"]),
              ("out_stall", p[15], c2["trailer"]["out_stall"]), ("blocks_err", p[5], 0)]
    q = lambda a, b: (a << 16) // b if b else 0
    checks += [("dec_ratio_q16", p[31], q(exp_out, exp_in)), ("in_bpc_q16", p[34], q(exp_in, c2["trailer"]["cycles"])), ("out_bpc_q16", p[35], q(exp_out, c2["trailer"]["cycles"]))]
    # compress side (pass 1): same idea
    p1 = perf_regs(r.stdout); res1 = c1["results"]
    e_in = sum(len(v.data) for v in src); e_out = sum(len(res1[v.id]["data"]) for v in src)
    l1 = [res1[v.id]["latency"] for v in src]
    checks += [("enc_blocks", p1[10], len(src)), ("enc_in_bytes", p1[11], e_in), ("enc_out_bytes", p1[12], e_out), ("enc_comp_ratio_q16", p1[30], q(e_in, e_out)),
               ("enc_lat_max", p1[27], max(l1)), ("enc_lat_sum", p1[28], sum(l1)), ("enc_in_stall", p1[14], c1["trailer"]["in_stall"]),
               ("enc_blocks_err", p1[5], sum(1 for v in src if res1[v.id]["status"] != 0)), ("enc_cycles", p1[0], c1["trailer"]["cycles"])]
    bad = [(n, got, want) for n, got, want in checks if got != want]
    if quiet:
        return 0 if not (c1["fails"] or c2["fails"] or bad) else 1
    print(f"round trip: {len(src)} blocks compressed (pass 1: {len(c1['fails'])} failures), {n_cmp} compressed + {n_raw} raw; {len(dec)} decompressed "
          f"(pass 2: {len(c2['fails'])} failures)")
    print(f"perf counters vs independent counts: {len(checks) - len(bad)}/{len(checks)} exact" + (f"  MISMATCH {bad}" if bad else ""))
    for f in (c1["fails"] + c2["fails"])[:5]: print("  FAIL", f)
    return 0 if not (c1["fails"] or c2["fails"] or bad) else 1

if __name__ == "__main__":
    sys.exit(main())
