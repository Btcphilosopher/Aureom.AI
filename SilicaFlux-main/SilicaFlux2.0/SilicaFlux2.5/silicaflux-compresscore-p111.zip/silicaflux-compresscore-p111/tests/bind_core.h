// DUT binding: sf_compress_core (keep-mask streams, per-record mode / policy / CRC flags, framing-fault injection)
#pragma once
#include "Vsf_compress_core.h"
#include "tb_common.h"
typedef Vsf_compress_core DUT;
static const bool DUT_HAS_KEEP = true;
static const char* EVNAMES[NEV] = {"busy", "-", "-", "-", "-", "-", "-", "-"};
static inline void drive_in(DUT* t, const Beat& b, bool have, const Rec* r, uint64_t junk) {
  t->in_keep = b.keep; t->in_first = b.first; t->in_last = b.last;
  t->in_tid = have ? (r->tid & 0xFF) : (uint8_t)junk;
  t->in_mode = have ? r->mode : (junk >> 9) & 1; t->in_cap = have ? r->cap : (uint32_t)junk; t->in_policy = have ? (r->policy & 3) : (junk >> 12) & 3;
  t->in_crc_en = have ? (r->flags & 1) : (junk >> 14) & 1; t->in_crc_chk = have ? ((r->flags >> 1) & 1) : (junk >> 15) & 1;
  t->in_crc_exp = have ? r->exp_crc : (uint32_t)(junk >> 20);
  for (int w = 0; w < 4; w++) { uint32_t x = 0; for (int k = 0; k < 4; k++) x |= (uint32_t)b.d[4 * w + k] << (8 * k); t->in_data[w] = x; }
}
static inline void sample_out(DUT* t, OutBeat& o) {
  for (int w = 0; w < 4; w++) { uint32_t x = t->out_data[w]; for (int k = 0; k < 4; k++) o.d[4 * w + k] = (x >> (8 * k)) & 0xFF; }
  int n = 0; uint32_t m = t->out_keep, c = 0; while (m & 1) { n++; m >>= 1; } if (m) { /* non-contiguous keep on the output: record as 99 so the bench flags it */ n = 99; }
  (void)c;
  o.n = n; o.last = t->out_last; o.tid = t->out_tid; o.status = t->out_status; o.in_bytes = t->out_in_bytes; o.out_bytes = t->out_out_bytes;
  o.crc = t->out_crc; o.crc_valid = t->out_crc_valid; o.raw = t->out_raw; o.mode = t->out_mode;
}
static inline void sample_events(DUT* t, uint64_t* ev) { ev[0] += t->busy; }

static const bool HAS_PERF = true;
static inline void perf_drive(DUT* t, bool clear, bool snap, int sel) { t->perf_clear = clear; t->perf_snap = snap; t->perf_rd_sel = sel; }
static inline uint64_t perf_read(DUT* t) { return t->perf_rd_data; }
static inline bool perf_busy(DUT* t) { return t->perf_rd_busy; }
