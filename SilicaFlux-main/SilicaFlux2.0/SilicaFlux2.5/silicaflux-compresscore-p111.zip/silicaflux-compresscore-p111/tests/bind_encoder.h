// DUT binding: sf_lz4_encoder (dense raw beats in, compressed dense beats out; mode field of a record is ignored)
#pragma once
#include "Vsf_lz4_encoder.h"
#include "tb_common.h"
typedef Vsf_lz4_encoder DUT;
static const bool DUT_HAS_KEEP = false;
static const char* EVNAMES[NEV] = {"probe", "hit", "ext_cycle", "out_stall", "dry_pass", "busy", "-", "-"};
static inline void drive_in(DUT* t, const Beat& b, bool have, const Rec* r, uint64_t junk) {
  t->in_n = b.n; t->in_first = b.first; t->in_last = b.last; t->in_ferr = 0;
  t->in_tid = have ? (r->tid & 0xFF) : (uint8_t)junk; t->in_cap = have ? r->cap : (uint32_t)junk; t->in_policy = have ? (r->policy & 3) : (junk >> 8) & 3;
  t->in_crc = have ? r->exp_crc : (uint32_t)(junk >> 16);
  for (int w = 0; w < 4; w++) { uint32_t x = 0; for (int k = 0; k < 4; k++) x |= (uint32_t)b.d[4 * w + k] << (8 * k); t->in_data[w] = x; }
}
static inline void sample_out(DUT* t, OutBeat& o) {
  for (int w = 0; w < 4; w++) { uint32_t x = t->out_data[w]; for (int k = 0; k < 4; k++) o.d[4 * w + k] = (x >> (8 * k)) & 0xFF; }
  o.n = t->out_n; o.last = t->out_last; o.tid = t->out_tid; o.status = t->out_status; o.in_bytes = t->out_in_bytes; o.out_bytes = t->out_out_bytes;
  o.crc = t->out_crc; o.crc_valid = 1; o.raw = t->out_raw;
}
static inline void sample_events(DUT* t, uint64_t* ev) {
  ev[0] += t->ev_probe; ev[1] += t->ev_hit; ev[2] += t->ev_ext_cycle; ev[3] += t->ev_out_stall; ev[4] += t->ev_dry_pass; ev[5] += t->busy;
}

static const bool HAS_PERF = false;
static inline void perf_drive(DUT*, bool, bool, int) {}
static inline uint64_t perf_read(DUT*) { return 0; }
static inline bool perf_busy(DUT*) { return false; }
