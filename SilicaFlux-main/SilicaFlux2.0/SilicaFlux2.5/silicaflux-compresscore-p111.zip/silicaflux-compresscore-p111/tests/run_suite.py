#!/usr/bin/env python3
"""Build a Verilator bench for a DUT/parameter set and run vector suites under backpressure profiles, checking every result against the
independent expectations stored with the vectors (tools/genvec.py).  Importable (used by the Makefile targets and the regression)."""
import os, sys, subprocess, struct, pickle, hashlib, time, shutil
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import lz4model as M

DUTS = {  # name -> (top module, bind header, rtl files)
    "core": ("sf_compress_core", "bind_core.h", ["sf_lz4_fifo", "sf_lz4_sram_1r1w", "sf_lz4_history", "sf_lz4_pack", "sf_lz4_srcchk", "sf_lz4_decoder", "sf_lz4_matchfinder",
                                                  "sf_lz4_encoder", "sf_compress_crc", "sf_compress_stream_adapter", "sf_compress_perf", "sf_compress_core"]),
    "encoder": ("sf_lz4_encoder", "bind_encoder.h", ["sf_lz4_fifo", "sf_lz4_sram_1r1w", "sf_lz4_history", "sf_lz4_pack", "sf_lz4_matchfinder", "sf_lz4_encoder"]),
    "decoder": ("sf_lz4_decoder", "bind_decoder.h", ["sf_lz4_fifo", "sf_lz4_sram_1r1w", "sf_lz4_history", "sf_lz4_pack", "sf_lz4_srcchk", "sf_lz4_decoder"]),
}
PROFILES = {  # name -> (pin, pout, burst)
    "full": (1.0, 1.0, 0), "rand50": (0.5, 0.5, 0), "slow_out": (1.0, 0.1, 0), "slow_in": (0.1, 1.0, 0),
    "burst": (0.5, 0.5, 1), "rand_hi": (0.9, 0.8, 0), "rand_lo": (0.3, 0.7, 0),
}


def build(dut, name=None, params=None, extra_defs=(), quiet=True, rtl_dir=None):
    top, bind, files = DUTS[dut]
    name = name or dut
    params = params or {}
    mdir = os.path.join(ROOT, "build", name)
    exe = os.path.join(mdir, "tb")
    rtl_dir = rtl_dir or os.path.join(ROOT, "rtl")
    srcs = [os.path.join(rtl_dir, f + ".sv") for f in files]
    stamp = hashlib.sha1((" ".join(f"{k}={v}" for k, v in sorted(params.items())) + "|" + "|".join(open(s, "rb").read().hex() for s in srcs) +
                          open(os.path.join(ROOT, "tests", "tb_stream.cpp")).read() + open(os.path.join(ROOT, "tests", bind)).read() +
                          open(os.path.join(ROOT, "rtl", "sf_compress_defs.svh")).read()).encode()).hexdigest()
    sf = os.path.join(mdir, "stamp")
    if os.path.exists(exe) and os.path.exists(sf) and open(sf).read() == stamp:
        return exe
    shutil.rmtree(mdir, ignore_errors=True)
    os.makedirs(mdir)
    cmd = ["verilator", "--cc", "--exe", "--build", "-j", os.environ.get("SF_VJOBS", "4"), "-Mdir", mdir, "--top-module", top, "-O2", "--x-initial", "unique", "--x-assign", "unique",
           "-Wno-lint", "-Wno-style", "-Wno-fatal", "-I" + rtl_dir, "-o", "tb",
           "-CFLAGS", f'-O2 -DBIND_HEADER=\\"{bind}\\" -I{os.path.join(ROOT, "tests")} ' + " ".join(extra_defs)]
    for k, v in params.items():
        cmd.append(f"-G{k}={v}")
    cmd += srcs + [os.path.join(ROOT, "tests", "tb_stream.cpp")]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        print((r.stdout + r.stderr)[-1800:]); raise SystemExit("verilator build failed: " + name)
    open(sf, "w").write(stamp)
    return exe


def read_results(path):
    f = open(path, "rb").read()
    assert f[:4] == b"SFR1"
    p = 4; res = {}; trailer = None
    while p < len(f):
        h = struct.unpack_from("<10I", f, p); p += 40
        data = f[p:p + h[8]]; p += h[8]
        if h[0] == 0xFFFFFFFF:
            trailer = dict(cycles=h[1], in_stall=h[2], out_stall=h[3], proto_err=h[4], in_beats=h[5], out_beats=h[6], busy_cyc=h[7])
        else:
            res[h[0]] = dict(status=h[1], raw=h[2] & 1, mode=h[2] >> 1, in_bytes=h[3], out_bytes=h[4], crc=h[5], crc_valid=h[6], latency=h[7], nbeats=h[9], data=data)
    return res, trailer


def run(exe, suite, prof="full", seed=1, extra=(), outdir=None, timeout=3600):
    pin, pout, burst = PROFILES[prof]
    outdir = outdir or os.path.join(ROOT, "build", "results"); os.makedirs(outdir, exist_ok=True)
    out = os.path.join(outdir, f"{suite}.{prof}.{seed}.sfr")
    cmd = [exe, "--vec", os.path.join(ROOT, "vectors", suite + ".sfv"), "--out", out, "--seed", str(seed), "--pin", str(pin), "--pout", str(pout),
           "--burst", str(burst), "+verilator+rand+reset+2", f"+verilator+seed+{seed}"] + list(extra)
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    return out, r, time.time() - t0


def check_decoder(suite, resfile, hw_max_out=1 << 22):
    pk = pickle.load(open(os.path.join(ROOT, "vectors", suite + ".exp.pkl"), "rb"))
    meta = pk["meta"]; hw_max_out = pk["profile"].get("max_out", hw_max_out)
    res, trailer = read_results(resfile)
    fails = []; n_ok = 0; n_abort = 0
    for (id_, mode, cap, policy, flags, exp_crc, tid, ilen, tag, exp_status, exp_out, orig) in meta:
        r = res.get(id_)
        if r is None: fails.append((tag, "missing result")); continue
        if r["status"] == 0xFFFF: n_abort += 1; continue
        cap_eff = min(cap if cap else hw_max_out, hw_max_out)
        why = None
        if r["status"] != exp_status:
            why = f"status {M.STATUS_NAME.get(r['status'], r['status'])} != expected {M.STATUS_NAME[exp_status]}"
        elif exp_status == 0 and r["data"] != exp_out:
            d = r["data"]; k = next((i for i in range(min(len(d), len(exp_out))) if d[i] != exp_out[i]), min(len(d), len(exp_out)))
            why = f"output differs at byte {k} (got {len(d)} bytes, expected {len(exp_out)})"
        elif r["in_bytes"] != ilen:
            why = f"in_bytes {r['in_bytes']} != {ilen}"
        elif exp_status == 0 and r["out_bytes"] != len(exp_out):
            why = f"out_bytes {r['out_bytes']} != {len(exp_out)}"
        elif len(r["data"]) > cap_eff:
            why = f"emitted {len(r['data'])} bytes > capacity {cap_eff}"
        if why: fails.append((tag, why))
        else: n_ok += 1
    return dict(total=len(meta), ok=n_ok, aborted=n_abort, fails=fails, trailer=trailer, results=res)


def check_core(suite, resfile, enc_cfg=None, dec_params=None, crc_fn=None):
    """sf_compress_core: per record the decoder or encoder check, plus mode, CRC, framing-fault and recovery checks"""
    import encmodel as E, zlib
    import lz4.block as LB
    crc_fn = crc_fn or (lambda d: zlib.crc32(d) & 0xFFFFFFFF)
    enc_cfg = dict(enc_cfg or {}); blk = enc_cfg.pop("blk_bytes", 65536)
    dp = dict(dec_params or {})
    pk = pickle.load(open(os.path.join(ROOT, "vectors", suite + ".exp.pkl"), "rb"))
    res, trailer = read_results(resfile)
    fails = []; n_ok = 0; n_abort = 0; stat = {}
    for (id_, mode, cap, policy, flags, exp_crc, tid, ilen, tag, exp_status, exp_out, orig) in pk["meta"]:
        r = res.get(id_)
        if r is None: fails.append((tag, "missing")); continue
        if r["status"] == 0xFFFF: n_abort += 1; continue
        out = r["data"]; why = None
        fault = (flags >> 8) & 3
        crc_en = flags & 1
        if fault:
            if r["status"] == 0: why = f"framing fault {fault} was not detected (status OK)"
        elif r["mode"] != mode: why = f"out_mode {r['mode']} != {mode}"
        elif mode == 0:
            cap_eff = min(cap if cap else (1 << 22), 1 << 22)
            if r["status"] != exp_status: why = f"status {M.STATUS_NAME.get(r['status'], r['status'])} != expected {M.STATUS_NAME.get(exp_status, exp_status)}"
            elif exp_status == 0 and out != exp_out: why = "decompressed output differs"
            elif r["in_bytes"] != ilen: why = f"in_bytes {r['in_bytes']} != {ilen}"
            elif len(out) > cap_eff: why = f"emitted {len(out)} > capacity {cap_eff}"
            elif r["crc_valid"] != crc_en: why = f"crc_valid {r['crc_valid']} != {crc_en}"
            elif crc_en and exp_status in (0, M.STATUS["CRC"]) and r["crc"] != crc_fn(exp_out_for_crc(pk, id_, exp_out)): why = "crc of the decompressed data wrong"
        else:
            est, eraw, ebytes, kind = E.expected(orig, cap, policy, blk_bytes=blk, **enc_cfg)
            if r["status"] != est: why = f"status {M.STATUS_NAME.get(r['status'], r['status'])} != expected {M.STATUS_NAME[est]}"
            elif r["raw"] != eraw: why = f"raw {r['raw']} != {eraw}"
            elif kind == "exact" and out != ebytes: why = "compressed output differs from the encoder model"
            elif kind == "prefix" and out != ebytes[:len(out)]: why = "output not a prefix of the model output"
            elif kind == "none" and len(out): why = "data emitted although none expected"
            elif len(out) > (cap if cap else (1 << 32)): why = "emitted more than the destination capacity"
            elif r["in_bytes"] != ilen or r["out_bytes"] != len(out): why = "byte counts wrong"
            elif r["crc_valid"] != crc_en: why = "crc_valid wrong"
            elif crc_en and r["crc"] != crc_fn(orig): why = "crc of the raw input wrong"
            elif r["status"] == 0 and not r["raw"]:
                try: dec = LB.decompress(out, uncompressed_size=max(ilen, 1)) if ilen else (b"" if out == b"\x00" else None)
                except Exception: dec = None
                if dec != orig: why = "INDEPENDENT CHECK: reference LZ4 does not decode the hardware output"
        key = ("fault" if fault else ("dec" if mode == 0 else "enc")) + ":" + M.STATUS_NAME.get(r["status"], str(r["status"]))
        stat[key] = stat.get(key, 0) + 1
        if why: fails.append((tag, why))
        else: n_ok += 1
    return dict(total=len(pk["meta"]), ok=n_ok, aborted=n_abort, fails=fails, trailer=trailer, results=res, stat=stat)


def exp_out_for_crc(pk, id_, exp_out):
    """the CRC reported for a decompress block is the CRC of the DECOMPRESSED data: for a CRC-mismatch record the decoded data is the model output"""
    return exp_out if exp_out is not None else pk.get("crc_data", {}).get(id_, b"")


def check_encoder(suite, resfile, cfg=None):
    """encoder checks: exact comparison with the bit-exact model, PLUS independent validation by the trusted software LZ4"""
    import encmodel as E
    import lz4.block as LB
    cfg = dict(cfg or {})
    blk = cfg.pop("blk_bytes", 65536)
    pk = pickle.load(open(os.path.join(ROOT, "vectors", suite + ".exp.pkl"), "rb"))
    res, trailer = read_results(resfile)
    fails = []; n_ok = 0; n_abort = 0
    stat = {}
    tot_in = tot_out = 0
    for (id_, mode, cap, policy, flags, exp_crc, tid, ilen, tag, _es, _eo, data) in pk["meta"]:
        r = res.get(id_)
        if r is None: fails.append((tag, "missing")); continue
        if r["status"] == 0xFFFF: n_abort += 1; continue
        est, eraw, ebytes, kind = E.expected(data, cap, policy, blk_bytes=blk, **cfg)
        out = r["data"]; why = None
        cap_eff = cap if cap else (1 << 32) - 1
        stat[M.STATUS_NAME.get(r["status"], r["status"])] = stat.get(M.STATUS_NAME.get(r["status"], r["status"]), 0) + 1
        if r["status"] != est: why = f"status {M.STATUS_NAME.get(r['status'], r['status'])} != expected {M.STATUS_NAME[est]}"
        elif r["raw"] != eraw: why = f"raw flag {r['raw']} != {eraw}"
        elif kind == "exact" and out != ebytes:
            k = next((i for i in range(min(len(out), len(ebytes))) if out[i] != ebytes[i]), min(len(out), len(ebytes)))
            why = f"output differs from the model at byte {k} (got {len(out)} bytes, model {len(ebytes)})"
        elif kind == "prefix" and (out != ebytes[:len(out)]): why = "output is not a prefix of the model output"
        elif kind == "none" and len(out) != 0: why = f"{len(out)} data bytes emitted, expected none"
        elif len(out) > cap_eff: why = f"emitted {len(out)} bytes > destination capacity {cap_eff}"
        elif r["in_bytes"] != ilen: why = f"in_bytes {r['in_bytes']} != {ilen}"
        elif r["out_bytes"] != len(out): why = f"out_bytes {r['out_bytes']} != emitted {len(out)}"
        elif r["crc"] != exp_crc: why = "crc sideband not passed through"
        elif r["status"] == 0 and not r["raw"]:
            try: dec = LB.decompress(out, uncompressed_size=max(ilen, 1)) if ilen else (b"" if out == b"\x00" else None)
            except Exception as e: dec = None
            if dec != data: why = "INDEPENDENT CHECK: the reference LZ4 library does not decode the hardware output to the input"
        if why: fails.append((tag, why))
        else:
            n_ok += 1
            if r["status"] == 0 and not r["raw"]: tot_in += ilen; tot_out += len(out)
    return dict(total=len(pk["meta"]), ok=n_ok, aborted=n_abort, fails=fails, trailer=trailer, results=res, stat=stat, ratio=(tot_in / tot_out if tot_out else 0))


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("dut"); ap.add_argument("suite", nargs="+"); ap.add_argument("--prof", default="full"); ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--config", default="default")
    a = ap.parse_args()
    import genvec
    if a.dut == "encoder":
        rp, mp = genvec.ENC_CONFIGS[a.config]
    else:
        rp, mp = genvec.RTL_PARAMS[a.config], {}
    exe = build(a.dut, name=a.dut + ("" if a.config == "default" else "_" + a.config), params=rp)
    rc = 0
    for s in a.suite:
        out, r, dt = run(exe, s, a.prof, a.seed)
        c = check_encoder(s, out, mp) if a.dut == "encoder" else (check_core(s, out) if a.dut == "core" else check_decoder(s, out))
        print(f"{s:12s} {a.prof:9s} total={c['total']} ok={c['ok']} fail={len(c['fails'])}  [{dt:.1f}s]  {r.stdout.strip().splitlines()[0] if r.stdout else ''}")
        if r.returncode: print("  bench rc", r.returncode, r.stderr[-500:])
        for f in c["fails"][:8]: print("   FAIL", f)
        rc |= bool(c["fails"]) or bool(r.returncode)
    sys.exit(rc)
