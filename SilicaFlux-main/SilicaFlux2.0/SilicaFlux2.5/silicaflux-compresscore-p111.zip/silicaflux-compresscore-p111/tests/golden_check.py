#!/usr/bin/env python3
"""Runs the DECODER RTL on the shipped externally-produced golden blocks (vectors/golden/ext) and compares byte-for-byte with the shipped raw files.
Needs only Verilator + python (no lz4 installation): the expected data is in the repository."""
import os, sys, json, hashlib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
import run_suite as R, genvec as G
ROOT = R.ROOT
def main():
    gd = os.path.join(ROOT, "vectors", "golden"); man = json.load(open(os.path.join(gd, "manifest.json")))
    vecs = []; exp = {}
    for k, m in sorted(man.items()):
        if not k.startswith("ext/"): continue
        blk = open(os.path.join(gd, k + ".lz4b"), "rb").read(); raw = open(os.path.join(gd, k + ".raw"), "rb").read()
        assert hashlib.sha256(blk).hexdigest() == m["block_sha256"] and hashlib.sha256(raw).hexdigest() == m["raw_sha256"], "golden file corrupted: " + k
        v = G.Vec(0, blk, cap=len(raw), tag=k, exp_status=0, exp_out=raw); vecs.append(v)
    G.write_suite("golden_ext", vecs)
    exe = R.build("decoder"); bad = 0
    for prof in ("full", "rand50", "burst"):
        out, r, dt = R.run(exe, "golden_ext", prof, 5); c = R.check_decoder("golden_ext", out)
        bad += len(c["fails"]); print(f"golden external blocks [{prof}]: {c['ok']}/{c['total']} decoded byte-exactly by the RTL")
    return 1 if bad else 0
if __name__ == "__main__":
    sys.exit(main())
