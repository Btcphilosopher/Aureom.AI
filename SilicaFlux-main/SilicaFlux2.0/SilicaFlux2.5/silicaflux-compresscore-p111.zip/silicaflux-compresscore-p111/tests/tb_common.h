// shared types of the CompressCore verification bench (see tb_stream.cpp)
#pragma once
#include <cstdint>
#include <vector>
struct Rec  { uint32_t id, mode, cap, policy, flags, exp_crc, tid; std::vector<uint8_t> data; };
// flags: bit0 crc_en, bit1 crc_chk, bits 8-9 injected framing fault (0 none, 1 first flag missing, 2 spurious first flag mid-block, 3 keep mask with a hole)
struct Beat { uint8_t d[16]; int n; bool first, last; size_t rec; uint16_t keep; };
struct OutBeat { uint8_t d[16]; int n; bool last; uint32_t tid, status, in_bytes, out_bytes, crc, crc_valid, raw, mode; };
static const int NEV = 8;
