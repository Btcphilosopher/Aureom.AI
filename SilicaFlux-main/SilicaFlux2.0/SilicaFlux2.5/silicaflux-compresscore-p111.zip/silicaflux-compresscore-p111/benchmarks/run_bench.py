#!/usr/bin/env python3
"""Benchmarks (RTL SIMULATION, cycle counts; no clock frequency is assumed or claimed).  Everything is measured with the product itself (sf_compress_core, CRC stage on)
and read back from its own performance counters (sf_compress_perf), cross-checked against the bench's counts:
  A. decompression throughput by data class and by producer (python-lz4 default / high-compression, lz4 CLI), 64 KiB blocks, no backpressure
  B. compression ratio and throughput by data class vs the reference library; policy cost (STREAM / ERROR / RAW)
  C. compression level / area trade-off: HASH_BITS x ACCEL builds
  D. backpressure sensitivity of the decompressor (output / input ready probability sweeps)
  E. single-block end-to-end latency (idle core) for 256 B .. 64 KiB
Writes benchmarks/REPORT.md and benchmarks/results.csv.   usage: run_bench.py [--quick]"""
import os, sys, random, csv, glob, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tests")); sys.path.insert(0, os.path.join(ROOT, "tools"))
import run_suite as R, genvec as G, corpus, lz4model as M
import lz4.block as LB

REG = dict(cycles=0, in_bytes=1, out_bytes=2, blocks_in=3, blocks_out=4, dec_in=7, dec_out=8, dec_busy=9, enc_in=11, enc_out=12, enc_busy=13, in_stall=14, out_stall=15,
           raw=16, pat=17, dec_out_stall=18, opq=19, probes=20, hits=21, ext=22, enc_out_stall=23, dry=24, lat_last=26, lat_max=27, lat_sum=28, lat_cnt=29)


def perf(stdout):
    return {int(l.split()[1]): int(l.split()[2]) for l in stdout.splitlines() if l.startswith("perf ")}


def run_core(exe, vecs, prof="full", seed=1, extra=(), enc_cfg=None):
    G.write_suite("bench_tmp", vecs)
    out, r, dt = R.run(exe, "bench_tmp", prof, seed, extra=list(extra))
    c = R.check_core("bench_tmp", out, enc_cfg=enc_cfg)
    assert not c["fails"], c["fails"][:2]
    return perf(r.stdout), c, r


def classes(rng, size=65536):
    src = b"".join(open(f, "rb").read() for f in sorted(glob.glob(os.path.dirname(os.__file__) + "/*.py"))[:60])
    src = (src * 3)[:size]
    return [("text", corpus.text(rng, size)), ("source code", src), ("mixed", corpus.mixed(rng, size)), ("random", corpus.rnd(rng, size)), ("zeros", bytes(size)),
            ("pattern 7B", corpus.repeat_pattern(rng, 7, size)), ("pattern 40B", corpus.repeat_pattern(rng, 40, size))]


def section_E(core, rng, P, rows):
    P("## E. Single-block end-to-end latency (idle core, no backpressure)\n")
    P("Cycles from the first input beat accepted to the last output beat accepted, **one block alone in an idle core**: the bench withholds the block start until the previous (warm-up) block has completed (`--serialize 1`). "
      "The warm-up matters: the very first compress block after reset additionally waits for the hash-table sweep (2^HASH_BITS = 4096 cycles, `docs/02_ARCHITECTURE.md`). "
      "Without serialization a block queues behind its predecessor inside the core and the latency includes that wait.\n")
    P("| block | decompress (text) | decompress (random) | compress (text, STREAM) | compress (random, STREAM) | compress (text, ERROR 2-pass) |")
    P("|---|---|---|---|---|---|")
    for size in (256, 1024, 4096, 16384, 65536):
        d_text = corpus.text(rng, size); d_rnd = corpus.rnd(rng, size)
        cells = []
        for data, mode, pol in ((d_text, 0, 0), (d_rnd, 0, 0), (d_text, 1, 0), (d_rnd, 1, 0), (d_text, 1, 1)):
            if mode == 0:
                v = G.valid_vec(LB.compress(data, store_size=False), data, "lat")
            else:
                v = G.enc_vec(data, 0 if pol == 0 else len(data) + 64, pol, "lat")
            warm = G.enc_vec(b"warm-up block " * 3, 0, 0, "warm") if mode == 1 else G.valid_vec(LB.compress(b"warm-up block " * 3, store_size=False), b"warm-up block " * 3, "warm")
            p, c, r = run_core(core, [warm, v], extra=["--serialize", "1"])
            cells.append(c["results"][2]["latency"])
        rows.append(dict(section="E", size=size, lat=cells))
        P(f"| {size} B | {cells[0]:,} | {cells[1]:,} | {cells[2]:,} | {cells[3]:,} | {cells[4]:,} |")
    P()



def main():
    if '--only-latency' in sys.argv:
        only_latency(); return
    quick = "--quick" in sys.argv
    rng = random.Random(1234)
    rows = []; md = []
    P = lambda s="": md.append(s)
    P("# CompressCore benchmarks (RTL simulation)\n")
    P("All numbers are **simulated clock cycles** of `sf_compress_core` (128-bit stream, 64 KiB history, CRC stage on, default parameters unless stated), read from the "
      "core's own performance counters and cross-checked against the bench. **No clock frequency, area or power is claimed**: bytes/cycle x frequency is the only conversion, "
      "and no timing closure exists (docs/07_SYNTHESIS.md). Datapath peak: 16 bytes/cycle.\n")
    core = R.build("core")
    NBLK = 8 if quick else 24
    CL = classes(rng)          # ONE corpus for sections A, B and C (so their numbers are comparable)
    # ---------------------------------------------------------------------------------------------------------------- A
    P("## A. Decompression throughput (64 KiB blocks, no backpressure)\n")
    P("`out B/cyc` = decompressed bytes per busy cycle of the decoder; `end-to-end B/cyc` = decompressed bytes per elapsed cycle for the whole stream. "
      "`RAW conflicts` = cycles the copy engine waited because a match source was not yet visible in the history SRAM; `pattern bubbles` = overlapping-match starts that waited one cycle.\n")
    P("| data class | producer | ratio | out B/cyc | end-to-end B/cyc | in B/cyc | RAW conflicts / MiB | pattern bubbles / MiB | op-queue stalls / MiB |")
    P("|---|---|---|---|---|---|---|---|---|")
    producers = [("python-lz4 default", lambda d: LB.compress(d, store_size=False)), ("python-lz4 hc9", lambda d: LB.compress(d, store_size=False, mode="high_compression", compression=9))]
    for name, data in CL:
        for pname, fn in producers:
            if quick and pname.endswith("hc9"): continue
            blk = fn(data)
            vecs = [G.valid_vec(blk, data, name) for _ in range(NBLK)]
            for v in vecs: v.mode = 0
            p, c, r = run_core(core, vecs)
            ob = p[REG["dec_out"]]; mib = ob / (1 << 20)
            row = dict(section="A", cls=name, producer=pname, ratio=len(data) / len(blk), out_bpc=ob / p[REG["dec_busy"]], e2e=ob / p[REG["cycles"]], in_bpc=p[REG["dec_in"]] / p[REG["cycles"]],
                       raw=p[REG["raw"]] / mib, pat=p[REG["pat"]] / mib, opq=p[REG["opq"]] / mib)
            rows.append(row)
            P(f"| {name} | {pname} | {row['ratio']:.2f} | {row['out_bpc']:.2f} | {row['e2e']:.2f} | {row['in_bpc']:.2f} | {row['raw']:.0f} | {row['pat']:.0f} | {row['opq']:.0f} |")
    P()
    # ---------------------------------------------------------------------------------------------------------------- B
    P("## B. Compression ratio and throughput (64 KiB blocks, policy STREAM, no backpressure)\n")
    P("Ratio = input / output bytes. The reference columns are the software library on the same block (a different, more elaborate parser: HW is a baseline, see docs/03_ENCODER.md).\n")
    P("| data class | HW ratio | lz4 default | lz4 fast=9 | lz4 hc9 | in B/cyc (busy) | probes / KiB | cycles per probe |")
    P("|---|---|---|---|---|---|---|---|")
    for name, data in CL:
        vecs = [G.enc_vec(data, 0, 0, name) for _ in range(NBLK // 3)]
        p, c, r = run_core(core, vecs)
        out_b = p[REG["enc_out"]]; in_b = p[REG["enc_in"]]
        ref = lambda **kw: len(data) / len(LB.compress(data, store_size=False, **kw))
        row = dict(section="B", cls=name, ratio=in_b / out_b, lz4=ref(), fast9=ref(mode="fast", acceleration=9), hc9=ref(mode="high_compression", compression=9),
                   bpc=in_b / p[REG["enc_busy"]], probes_kib=p[REG["probes"]] / (in_b / 1024), cyc_probe=p[REG["enc_busy"]] / max(p[REG["probes"]], 1))
        rows.append(row)
        P(f"| {name} | {row['ratio']:.2f} | {row['lz4']:.2f} | {row['fast9']:.2f} | {row['hc9']:.2f} | {row['bpc']:.2f} | {row['probes_kib']:.0f} | {row['cyc_probe']:.1f} |")
    P()
    P("### Policy cost (same blocks; capacity = input size + 16)\n")
    P("Input bytes per busy cycle. `ERROR` / `RAW` run a dry-run sizing pass first; the dry run stops early when the size exceeds the acceptable limit, so incompressible data fails fast.\n")
    P("| data class | STREAM B/cyc | ERROR (2 passes) B/cyc | ERROR result | RAW (2 passes) B/cyc | RAW result |")
    P("|---|---|---|---|---|---|")
    for name, data in classes(rng, 32768):
        res = {}
        for pol in (0, 1, 2):
            vecs = [G.enc_vec(data, 0 if pol == 0 else len(data) + 16, pol, name) for _ in range(6)]
            p, c, r = run_core(core, vecs)
            res[pol] = (p[REG["enc_in"]] / p[REG["enc_busy"]], c["results"][1]["raw"], c["results"][1]["status"])
        P(f"| {name} | {res[0][0]:.2f} | {res[1][0]:.2f} | {M.STATUS_NAME[res[1][2]]} | {res[2][0]:.2f} | {'raw copy' if res[2][1] else 'compressed'} |")
    P()
    # ---------------------------------------------------------------------------------------------------------------- C
    if not quick:
        P("## C. Compression level / area trade-off (encoder parameters)\n")
        P("Same corpus as section B (text / source code / mixed / random, 64 KiB, 8 blocks each, STREAM).  SRAM = block buffer (64 KiB) + hash table (2^HASH_BITS x 32 b).\n")
        P("| HASH_BITS | ACCEL | hash table | ratio (text / source / mixed) | in B/cyc (text / source / mixed / random) |")
        P("|---|---|---|---|---|")
        sel = [CL[0], CL[1], CL[2], CL[3]]
        for hb, ac in ((10, 1), (12, 1), (14, 1), (12, 2), (12, 4), (12, 8)):
            exe = R.build("core", name=f"core_hb{hb}_a{ac}", params=dict(HASH_BITS=hb, ACCEL=ac))
            rr = []; bb = []
            for name, data in sel:
                vecs = [G.enc_vec(data, 0, 0, name) for _ in range(8)]
                p, c, r = run_core(exe, vecs, enc_cfg=dict(hash_bits=hb, accel=ac))
                rr.append(p[REG["enc_in"]] / p[REG["enc_out"]]); bb.append(p[REG["enc_in"]] / p[REG["enc_busy"]])
            rows.append(dict(section="C", hash_bits=hb, accel=ac, ratios=rr, bpcs=bb))
            P(f"| {hb} | {ac} | {(1 << hb) * 4 / 1024:.0f} KiB | {rr[0]:.2f} / {rr[1]:.2f} / {rr[2]:.2f} | {bb[0]:.2f} / {bb[1]:.2f} / {bb[2]:.2f} / {bb[3]:.2f} |")
        P()
    # ---------------------------------------------------------------------------------------------------------------- D
    P("## D. Backpressure sensitivity (decompression of mixed-data blocks, ratio ~2.6)\n")
    P("`out_ready` / `in_valid` probability per cycle (independent random). Throughput = decompressed bytes per elapsed cycle.\n")
    P("| in_valid p | out_ready p | B/cyc | in stall cycles | out stall cycles |")
    P("|---|---|---|---|---|")
    mixed = CL[2][1]
    blk = LB.compress(mixed, store_size=False)
    for pin, pout in ((1.0, 1.0), (1.0, 0.75), (1.0, 0.5), (1.0, 0.25), (1.0, 0.1), (0.75, 1.0), (0.5, 1.0), (0.25, 1.0), (0.5, 0.5)):
        R.PROFILES[f"sweep_{pin}_{pout}"] = (pin, pout, 0)
        vecs = [G.valid_vec(blk, mixed, "m") for _ in range(NBLK)]
        G.write_suite("bench_tmp", vecs)
        out, r, dt = R.run(core, "bench_tmp", f"sweep_{pin}_{pout}", 3)
        c = R.check_core("bench_tmp", out); assert not c["fails"]
        p = perf(r.stdout)
        rows.append(dict(section="D", pin=pin, pout=pout, bpc=p[REG["dec_out"]] / p[REG["cycles"]]))
        P(f"| {pin} | {pout} | {p[REG['dec_out']] / p[REG['cycles']]:.2f} | {p[REG['in_stall']]:,} | {p[REG['out_stall']]:,} |")
    P()
    # ---------------------------------------------------------------------------------------------------------------- E
    section_E(core, rng, P, rows)
    P("Illustrative conversion only (NOT a performance claim, no timing closure exists): at a hypothetical 1 GHz, 1 byte/cycle = 1 GB/s.\n")
    open(os.path.join(ROOT, "benchmarks", "REPORT.md"), "w").write("\n".join(md) + "\n")
    with open(os.path.join(ROOT, "benchmarks", "results.csv"), "w") as f:
        keys = sorted({k for r in rows for k in r})
        w = csv.DictWriter(f, fieldnames=keys); w.writeheader(); [w.writerow(r) for r in rows]
    print("\n".join(md))


def only_latency():
    """re-run section E only and splice it into the existing REPORT.md (sections A-D are unaffected)"""
    rng = random.Random(4321); md = []; rows = []
    core = R.build("core")
    section_E(core, rng, (lambda s="": md.append(s)), rows)
    path = os.path.join(ROOT, "benchmarks", "REPORT.md"); old = open(path).read()
    a = old.index("## E. Single-block end-to-end latency"); b = old.index("Illustrative conversion only")
    open(path, "w").write(old[:a] + "\n".join(md) + "\n" + old[b:])
    print("\n".join(md))


if __name__ == "__main__":
    main()
