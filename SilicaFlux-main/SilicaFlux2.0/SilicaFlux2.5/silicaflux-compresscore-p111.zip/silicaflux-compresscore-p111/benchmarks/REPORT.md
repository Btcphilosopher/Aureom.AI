# CompressCore benchmarks (RTL simulation)

All numbers are **simulated clock cycles** of `sf_compress_core` (128-bit stream, 64 KiB history, CRC stage on, default parameters unless stated), read from the core's own performance counters and cross-checked against the bench. **No clock frequency, area or power is claimed**: bytes/cycle x frequency is the only conversion, and no timing closure exists (docs/07_SYNTHESIS.md). Datapath peak: 16 bytes/cycle.

## A. Decompression throughput (64 KiB blocks, no backpressure)

`out B/cyc` = decompressed bytes per busy cycle of the decoder; `end-to-end B/cyc` = decompressed bytes per elapsed cycle for the whole stream. `RAW conflicts` = cycles the copy engine waited because a match source was not yet visible in the history SRAM; `pattern bubbles` = overlapping-match starts that waited one cycle.

| data class | producer | ratio | out B/cyc | end-to-end B/cyc | in B/cyc | RAW conflicts / MiB | pattern bubbles / MiB | op-queue stalls / MiB |
|---|---|---|---|---|---|---|---|---|
| text | python-lz4 default | 1.68 | 4.77 | 4.77 | 2.85 | 0 | 416 | 448 |
| text | python-lz4 hc9 | 2.04 | 5.21 | 5.21 | 2.55 | 0 | 272 | 160 |
| source code | python-lz4 default | 2.37 | 6.70 | 6.70 | 2.82 | 144 | 1712 | 2560 |
| source code | python-lz4 hc9 | 2.93 | 6.99 | 6.99 | 2.39 | 192 | 1296 | 3872 |
| mixed | python-lz4 default | 2.27 | 8.82 | 8.82 | 3.89 | 8032 | 816 | 30494 |
| mixed | python-lz4 hc9 | 2.54 | 8.55 | 8.55 | 3.37 | 8752 | 720 | 32268 |
| random | python-lz4 default | 1.00 | 15.04 | 15.04 | 15.10 | 0 | 0 | 0 |
| random | python-lz4 hc9 | 1.00 | 15.03 | 15.03 | 15.09 | 0 | 0 | 0 |
| zeros | python-lz4 default | 245.45 | 15.05 | 15.05 | 0.06 | 0 | 0 | 62729 |
| zeros | python-lz4 hc9 | 245.45 | 15.05 | 15.05 | 0.06 | 0 | 0 | 62729 |
| pattern 7B | python-lz4 default | 240.06 | 15.04 | 15.04 | 0.06 | 0 | 0 | 62744 |
| pattern 7B | python-lz4 hc9 | 240.06 | 15.04 | 15.04 | 0.06 | 0 | 0 | 62744 |
| pattern 40B | python-lz4 default | 213.47 | 15.04 | 15.04 | 0.07 | 0 | 0 | 62713 |
| pattern 40B | python-lz4 hc9 | 213.47 | 15.04 | 15.04 | 0.07 | 0 | 0 | 62713 |

## B. Compression ratio and throughput (64 KiB blocks, policy STREAM, no backpressure)

Ratio = input / output bytes. The reference columns are the software library on the same block (a different, more elaborate parser: HW is a baseline, see docs/03_ENCODER.md).

| data class | HW ratio | lz4 default | lz4 fast=9 | lz4 hc9 | in B/cyc (busy) | probes / KiB | cycles per probe |
|---|---|---|---|---|---|---|---|
| text | 1.57 | 1.68 | 1.24 | 2.04 | 0.31 | 292 | 11.4 |
| source code | 2.28 | 2.37 | 1.71 | 2.93 | 0.46 | 245 | 9.1 |
| mixed | 2.23 | 2.27 | 1.72 | 2.54 | 0.57 | 271 | 6.6 |
| random | 1.00 | 1.00 | 1.00 | 1.00 | 3.33 | 45 | 6.9 |
| zeros | 245.45 | 245.45 | 245.45 | 245.45 | 5.31 | 0 | 6167.1 |
| pattern 7B | 240.06 | 240.06 | 222.16 | 240.06 | 5.30 | 0 | 1544.5 |
| pattern 40B | 213.47 | 213.47 | 140.33 | 213.47 | 5.25 | 1 | 304.6 |

### Policy cost (same blocks; capacity = input size + 16)

Input bytes per busy cycle. `ERROR` / `RAW` run a dry-run sizing pass first; the dry run stops early when the size exceeds the acceptable limit, so incompressible data fails fast.

| data class | STREAM B/cyc | ERROR (2 passes) B/cyc | ERROR result | RAW (2 passes) B/cyc | RAW result |
|---|---|---|---|---|---|
| text | 0.30 | 0.16 | OK | 0.16 | compressed |
| source code | 0.44 | 0.22 | OK | 0.22 | compressed |
| mixed | 0.58 | 0.30 | OK | 0.30 | compressed |
| random | 2.62 | 3.13 | INCOMPRESSIBLE | 2.62 | raw copy |
| zeros | 5.02 | 3.08 | OK | 3.08 | compressed |
| pattern 7B | 5.01 | 3.06 | OK | 3.06 | compressed |
| pattern 40B | 4.91 | 2.99 | OK | 2.99 | compressed |

## C. Compression level / area trade-off (encoder parameters)

Same corpus as section B (text / source code / mixed / random, 64 KiB, 8 blocks each, STREAM).  SRAM = block buffer (64 KiB) + hash table (2^HASH_BITS x 32 b).

| HASH_BITS | ACCEL | hash table | ratio (text / source / mixed) | in B/cyc (text / source / mixed / random) |
|---|---|---|---|---|
| 10 | 1 | 4 KiB | 1.39 / 2.11 / 2.00 | 0.28 / 0.44 / 0.53 / 3.33 |
| 12 | 1 | 16 KiB | 1.57 / 2.28 / 2.23 | 0.31 / 0.46 / 0.57 / 3.33 |
| 14 | 1 | 64 KiB | 1.63 / 2.35 / 2.29 | 0.32 / 0.46 / 0.58 / 3.09 |
| 12 | 2 | 16 KiB | 1.48 / 2.03 / 2.09 | 0.34 / 0.52 / 0.72 / 3.37 |
| 12 | 4 | 16 KiB | 1.35 / 1.79 / 1.92 | 0.41 / 0.64 / 0.98 / 3.46 |
| 12 | 8 | 16 KiB | 1.21 / 1.54 / 1.67 | 0.56 / 0.82 / 1.45 / 3.63 |

## D. Backpressure sensitivity (decompression of mixed-data blocks, ratio ~2.6)

`out_ready` / `in_valid` probability per cycle (independent random). Throughput = decompressed bytes per elapsed cycle.

| in_valid p | out_ready p | B/cyc | in stall cycles | out stall cycles |
|---|---|---|---|---|
| 1.0 | 1.0 | 8.82 | 134,956 | 0 |
| 1.0 | 0.75 | 8.38 | 144,196 | 32,444 |
| 1.0 | 0.5 | 7.01 | 181,052 | 98,431 |
| 1.0 | 0.25 | 3.99 | 350,925 | 294,960 |
| 1.0 | 0.1 | 1.60 | 937,294 | 882,705 |
| 0.75 | 1.0 | 8.71 | 122,575 | 0 |
| 0.5 | 1.0 | 8.34 | 101,523 | 0 |
| 0.25 | 1.0 | 7.02 | 48,394 | 0 |
| 0.5 | 0.5 | 6.96 | 139,083 | 98,228 |

## E. Single-block end-to-end latency (idle core, no backpressure)

Cycles from the first input beat accepted to the last output beat accepted, **one block alone in an idle core**: the bench withholds the block start until the previous (warm-up) block has completed (`--serialize 1`). The warm-up matters: the very first compress block after reset additionally waits for the hash-table sweep (2^HASH_BITS = 4096 cycles, `docs/02_ARCHITECTURE.md`). Without serialization a block queues behind its predecessor inside the core and the latency includes that wait.

| block | decompress (text) | decompress (random) | compress (text, STREAM) | compress (random, STREAM) | compress (text, ERROR 2-pass) |
|---|---|---|---|---|---|
| 256 B | 31 | 29 | 1,008 | 632 | 1,974 |
| 1024 B | 173 | 80 | 3,855 | 1,460 | 7,558 |
| 4096 B | 803 | 285 | 14,609 | 3,297 | 28,633 |
| 16384 B | 3,361 | 1,101 | 54,392 | 7,733 | 106,692 |
| 65536 B | 13,693 | 4,365 | 212,131 | 19,688 | 416,516 |

Illustrative conversion only (NOT a performance claim, no timing closure exists): at a hypothetical 1 GHz, 1 byte/cycle = 1 GB/s.

