#!/bin/sh
# Verify the hardware-produced blocks with the independent `lz4` tool: wraps each .lz4b block into an LZ4 frame (tools/lz4frame.py) and decodes it with `lz4 -d`.
set -e
cd "$(dirname "$0")"
python3 ../../../tools/golden_verify_hw.py
