# Vectors

* `golden/` — **shipped** interoperability corpus (small, with a SHA-256 manifest):
  * `ext/` — blocks produced by EXTERNAL implementations (python-lz4 default / high-compression, the `lz4` command-line tool) and the raw data they decode to. `make golden` runs the decoder RTL on them and compares byte for byte —
    no `lz4` installation needed, only Verilator.
  * `hw/` — blocks produced by THIS hardware (RTL simulation, policies STREAM and RAW) and their raw data. `hw/verify_with_lz4.sh` decodes them with the independent `lz4` tool (as LZ4 frames) and python-lz4.
  * `manifest.json` — producer, tool versions, sizes, SHA-256 of every file.
* everything else (`*.sfv`, `*.exp.pkl`) is **generated** by `make vectors` (`tools/genvec.py`) from independent LZ4 producers and the models; it is not shipped (tens of MB) because it is reproducible and seeded.

Vector file format (`.sfv`): `'SFV1'`, then records `{u32 id, mode, cap, policy, flags, exp_crc, tid, in_len; u8 data[in_len]}`; results (`.sfr`): `'SFR1'`, records `{u32 id, status, raw|mode<<1, in_bytes, out_bytes, crc, crc_valid, latency, out_len, nbeats; data}`.
Expected values live in the matching `.exp.pkl` (written by the generator, read by the Python checkers) — the C++ bench contains none.
