"""Bit-exact software model of the CompressCore ENCODER algorithm (rtl/sf_lz4_encoder.sv + rtl/sf_lz4_matchfinder.sv), written from the documented
algorithm (docs/03_ENCODER.md).  Given the same parameters it must produce byte-identical compressed blocks.  Every block it (and the hardware)
produces is separately validated by the trusted software LZ4 -- the model is a regression oracle, not the correctness criterion."""
import lz4model as M

MINMATCH, MFLIMIT, LASTLITERALS = 4, 12, 5


def _hash(v4, hash_bits):
    h = (int.from_bytes(v4, "little") * 0x9E3779B1) & 0xFFFFFFFF
    return h >> (32 - hash_bits), (h >> (32 - hash_bits - 8)) & 0xFF


def encode(data, hash_bits=12, accel=1, skip_shift=6):
    n = len(data)
    if n < MFLIMIT + 1:
        return M.seq(bytes(data))
    table = {}
    out = bytearray()
    pos = anchor = miss = 0
    limit = n - LASTLITERALS                       # exclusive end bound of any match
    while pos <= n - MFLIMIT:
        idx, tag = _hash(data[pos:pos + 4], hash_bits)
        ent = table.get(idx)
        table[idx] = (tag, pos)
        cand = None
        if ent is not None and ent[0] == tag and ent[1] < pos and data[ent[1]:ent[1] + 4] == data[pos:pos + 4]:
            cand = ent[1]
        if cand is None:
            pos += accel + (miss >> skip_shift)
            miss += 1
            continue
        rem = max(0, limit - (pos + 4))
        e = 0
        while e < rem and data[pos + 4 + e] == data[cand + 4 + e]:
            e += 1
        mlen = 4 + e
        out += M.seq(bytes(data[anchor:pos]), pos - cand, mlen)
        pos += mlen
        anchor = pos
        miss = 0
        i2, t2 = _hash(data[pos - 2:pos + 2], hash_bits)         # LZ4: also insert the position just before the end of the match
        table[i2] = (t2, pos - 2)
    out += M.seq(bytes(data[anchor:]))
    return bytes(out)


def expected(data, cap, policy, *, blk_bytes=65536, **kw):
    """-> (status, raw, bytes_or_None, kind)   kind: 'exact' (output must equal bytes) | 'prefix' (output is a prefix of bytes) | 'none' (no data)"""
    n = len(data)
    S = M.STATUS
    if n > blk_bytes:
        return S['BLOCK_SIZE'], 0, b"", 'none'
    comp = encode(data, **kw)
    cs = len(comp)
    cap_eff = cap if cap else (1 << 32) - 1
    if policy == 1:                                   # ERROR
        return (S['OK'], 0, comp, 'exact') if cs <= cap_eff else (S['INCOMPRESSIBLE'], 0, b"", 'none')
    if policy == 2:                                   # RAW
        if n == 0:
            return S['OK'], 1, b"", 'exact'
        if cs <= cap_eff and cs < n:
            return S['OK'], 0, comp, 'exact'
        if n <= cap_eff:
            return S['OK'], 1, bytes(data), 'exact'
        return S['INCOMPRESSIBLE'], 0, b"", 'none'
    # STREAM (and the reserved value 3)
    if cs <= cap_eff:
        return S['OK'], 0, comp, 'exact'
    return S['DST_OVERFLOW'], 0, comp, 'prefix'
