"""A small, simple GREEDY LZ4 block encoder in Python (bounded window).  Used ONLY to produce valid blocks whose offsets stay inside a chosen
window (to exercise small-history hardware configurations); every block it emits is checked against the trusted LZ4 library by the vector
generator.  Obeys the end-of-block rules (last match starts >= 12 bytes before the end, last 5 bytes are literals)."""
import lz4model as M


def encode(data, window=65535, insert_inside=True):
    n = len(data)
    if n < 13:
        return M.seq(bytes(data))
    out = bytearray()
    table = {}
    anchor = 0
    i = 0
    mflimit = n - 12
    matchlimit = n - 5
    while i <= mflimit:
        key = bytes(data[i:i + 4])
        cand = table.get(key)
        table[key] = i
        if cand is not None and 0 < i - cand <= window:
            ln = 4
            while i + ln < matchlimit and data[cand + ln] == data[i + ln]:
                ln += 1
            out += M.seq(bytes(data[anchor:i]), i - cand, ln)
            i += ln
            anchor = i
            if insert_inside and i - 2 >= 0 and i + 2 <= n:
                table[bytes(data[i - 2:i + 2])] = i - 2
        else:
            i += 1
    out += M.seq(bytes(data[anchor:]))
    return bytes(out)
