#!/usr/bin/env python3
"""Builds vectors/golden/: a small SHIPPED interoperability corpus.
  ext/  blocks produced by EXTERNAL LZ4 implementations (python-lz4 and the `lz4` command-line tool) + the raw data they decode to
  hw/   blocks produced by THIS hardware (RTL simulation of sf_compress_core, mode 1) + the raw data, for checking with any LZ4 tool (hw/verify_with_lz4.sh)
  manifest.json: source tool/version/arguments, sizes and SHA-256 of every file.   Regenerate: python3 tools/make_golden.py [--hw]"""
import os, sys, json, hashlib, random, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lz4, lz4.block as LB
import corpus, lz4model as M
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
G = os.path.join(ROOT, "vectors", "golden")
sha = lambda b: hashlib.sha256(b).hexdigest()

def put(sub, name, blk, raw, meta, man):
    os.makedirs(os.path.join(G, sub), exist_ok=True)
    open(os.path.join(G, sub, name + ".lz4b"), "wb").write(blk)
    open(os.path.join(G, sub, name + ".raw"), "wb").write(raw)
    man[sub + "/" + name] = dict(meta, block_bytes=len(blk), raw_bytes=len(raw), block_sha256=sha(blk), raw_sha256=sha(raw))

def main(hw=False):
    rng = random.Random(2026)
    man = {"_info": dict(python_lz4=lz4.__version__, lz4_library=lz4.library_version_string(),
                         lz4_cli=subprocess.run(["lz4", "--version"], capture_output=True, text=True).stdout.strip())}
    data = {"empty": b"", "one_byte": b"A", "text_1k": corpus.text(rng, 1024), "text_8k": corpus.text(rng, 8192), "zeros_4k": bytes(4096),
            "run_300": b"\x5a" * 300, "pat_7": corpus.repeat_pattern(rng, 7, 5000), "pat_40": corpus.repeat_pattern(rng, 40, 6000), "random_2k": corpus.rnd(rng, 2048),
            "mixed_16k": corpus.mixed(rng, 16384), "ext_lengths": b"x" + b"y" * 1000 + corpus.rnd(rng, 600) + b"z" * 530 + b"end-of-block-literals"}
    for name, d in data.items():
        for how, kw in (("default", dict(mode="default")), ("hc9", dict(mode="high_compression", compression=9))):
            if how == "hc9" and len(d) < 100: continue
            blk = LB.compress(d, store_size=False, **kw)
            put("ext", f"pylz4_{how}_{name}", blk, d, dict(producer="python-lz4", args=kw), man)
    for name in ("text_8k", "mixed_16k", "pat_40"):
        for args in (["-1"], ["-9"], ["--fast=5"]):
            blocks, indep = corpus.cli_frame_blocks(data[name], args + ["-B4"])
            for k, (blk, piece) in enumerate(blocks[:1]):
                put("ext", f"lz4cli_{name}_{''.join(args).replace('-','')}", blk, piece, dict(producer="lz4 CLI frame block", args=args + ["-B4"]), man)
    if hw:
        sys.path.insert(0, os.path.join(ROOT, "tests")); import run_suite as R, genvec as GV
        vecs = []
        for name, d in data.items():
            for pol in (0, 2):
                vecs.append(GV.enc_vec(d, 0 if pol == 0 else len(d) + 16, pol, f"{name}_p{pol}"))
        GV.write_suite("golden_hw", vecs)
        exe = R.build("core"); out, r, dt = R.run(exe, "golden_hw", "rand50", 3, extra=["--split", "1"])
        res, _ = R.read_results(out)
        for v in vecs:
            x = res[v.id]; assert x["status"] == 0
            put("hw", f"hw_{v.tag}", x["data"], v.data, dict(producer="sf_compress_core (RTL simulation)", policy=v.policy, raw_fallback=bool(x["raw"])), man)
        open(os.path.join(G, "hw", "verify_with_lz4.sh"), "w").write('''#!/bin/sh
# Verify the hardware-produced blocks with the independent `lz4` tool: wraps each .lz4b block into an LZ4 frame (tools/lz4frame.py) and decodes it with `lz4 -d`.
set -e
cd "$(dirname "$0")"
python3 ../../../tools/golden_verify_hw.py
''')
    json.dump(man, open(os.path.join(G, "manifest.json"), "w"), indent=1, sort_keys=True)
    print(f"golden corpus: {len([k for k in man if k.startswith('ext/')])} external blocks, {len([k for k in man if k.startswith('hw/')])} hardware blocks")

if __name__ == "__main__":
    main("--hw" in sys.argv)
