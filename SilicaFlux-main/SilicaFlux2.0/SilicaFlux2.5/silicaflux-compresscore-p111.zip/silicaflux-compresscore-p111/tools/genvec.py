#!/usr/bin/env python3
"""Decoder vector suites.  Expectations come from tools/lz4model.py (validated against python-lz4 by tools/check_model.py); every vector that is
expected to decode OK is ALSO decoded by the trusted software LZ4 here and must give the same bytes (so a wrong hand-built vector is caught).

   hand   hand-built sequences: every length / offset / extension corner of the format
   lib    blocks produced by python-lz4 (default, fast, hc levels) over the data classes of tools/corpus.py
   cli    blocks cut out of frames produced by the `lz4` C command-line tool (independent blocks)
   bad    malformed blocks: every truncation point, offset 0 / too large, length overflow, no final literals, capacity too small ...
   fuzz   random mutations of valid blocks
   max    maximum supported sizes (4 MiB decompressed / compressed-size limit), plus unsupported sizes
"""
import os, sys, random, struct, pickle
import lz4.block as LB
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lz4model as M
import corpus

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROFILE = {}          # model parameters of the hardware profile the suites are generated for (see PROFILES)
PROFILES = {
    "default": {},
    "small": dict(hist=1024, max_in=1 << 18, max_out=1 << 19),             # RTL: HIST_BYTES=1024 MAX_IN_BYTES=262144 MAX_OUT_BYTES=524288
    "permissive": dict(strict=False),                                     # RTL: STRICT_EOB=0
}
RTL_PARAMS = {"default": {}, "small": dict(HIST_BYTES=1024, MAX_IN_BYTES=1 << 18, MAX_OUT_BYTES=1 << 19), "permissive": dict(STRICT_EOB=0), "opq8": dict(OPQ_DEPTH=8)}
# encoder configurations: name -> (RTL parameters, encoder-model parameters)
ENC_CONFIGS = {
    "default": ({}, {}),
    "small": (dict(BLK_BYTES=4096, HASH_BITS=8), dict(blk_bytes=4096, hash_bits=8)),
    "fast": (dict(HASH_BITS=14, ACCEL=3, SKIP_SHIFT=4), dict(hash_bits=14, accel=3, skip_shift=4)),
    "tiny_table": (dict(HASH_BITS=9, BLK_BYTES=16384, SKIP_SHIFT=2), dict(hash_bits=9, blk_bytes=16384, skip_shift=2)),
}


class Vec:
    __slots__ = ("id", "mode", "cap", "policy", "flags", "exp_crc", "tid", "data", "tag", "exp_status", "exp_out", "orig")

    def __init__(self, mode, data, cap=0, policy=0, flags=0, exp_crc=0, tag="", exp_status=None, exp_out=None, orig=None):
        self.id = 0; self.mode = mode; self.cap = cap; self.policy = policy; self.flags = flags; self.exp_crc = exp_crc
        self.tid = 0; self.data = data; self.tag = tag; self.exp_status = exp_status; self.exp_out = exp_out; self.orig = orig


def write_suite(name, vecs, outdir=None):
    outdir = outdir or os.path.join(ROOT, "vectors")
    os.makedirs(outdir, exist_ok=True)
    with open(os.path.join(outdir, name + ".sfv"), "wb") as f:
        f.write(b"SFV1")
        for i, v in enumerate(vecs):
            v.id = i + 1
            v.tid = (i * 37 + 5) & 0xFF
            f.write(struct.pack("<8I", v.id, v.mode, v.cap, v.policy, v.flags, v.exp_crc, v.tid, len(v.data)))
            f.write(v.data)
    meta = [(v.id, v.mode, v.cap, v.policy, v.flags, v.exp_crc, v.tid, len(v.data), v.tag, v.exp_status, v.exp_out, v.orig) for v in vecs]
    pickle.dump(dict(meta=meta, profile=dict(PROFILE)), open(os.path.join(outdir, name + ".exp.pkl"), "wb"))
    return len(vecs)


def dec_vec(blk, cap, tag, orig=None):
    st, out = M.ref_decode(blk, cap, **PROFILE)
    return Vec(0, blk, cap=cap, tag=tag, exp_status=st, exp_out=(out if st == 0 else None), orig=orig)


def valid_vec(blk, data, tag, cap=None):
    """a block that must decode OK to `data`; cross-checked with the trusted LZ4 library"""
    cap = len(data) if cap is None else cap
    if len(data):
        assert LB.decompress(blk, uncompressed_size=len(data)) == data, ("library rejects/changes vector", tag)
    v = dec_vec(blk, cap, tag, orig=data)
    if not PROFILE:     # in a restricted hardware profile a valid block may legitimately exceed the profile (window / size limits)
        assert v.exp_status == 0 and v.exp_out == data, ("model disagrees on valid vector", tag, M.STATUS_NAME[v.exp_status])
    elif v.exp_status == 0:
        assert v.exp_out == data
    return v


# ---------------------------------------------------------------------------------------------------------------------------------
def suite_hand():
    rng = random.Random(11)
    V = []
    S = M.seq

    def fin_for(ml):          # final literals: >= 5, and last match starts >= 12 bytes before the end
        return bytes(rng.getrandbits(8) for _ in range(max(5, 12 - ml)))
    # lengths of literal runs / match runs around every extension boundary
    LITS = [0, 1, 2, 3, 4, 5, 13, 14, 15, 16, 17, 31, 32, 33, 268, 269, 270, 271, 272, 524, 525, 526, 527, 779, 780, 781, 1000, 4095, 4096, 4097]
    MLENS = [4, 5, 6, 17, 18, 19, 20, 21, 32, 33, 272, 273, 274, 275, 276, 527, 528, 529, 530, 1000, 4096, 5000]
    for L in LITS:
        for ML in MLENS:
            if L == 0 and ML > 20:
                continue
            fin = fin_for(ML)
            if L == 0:      # zero-length literal run in a sequence that follows an earlier one (needs history)
                seed = bytes(rng.getrandbits(8) for _ in range(8))
                blk = M.build([(seed, 8, 4), (b"", 1 + rng.randrange(8), ML), (fin, None, None)])
            else:
                lits = bytes(rng.getrandbits(8) for _ in range(L))
                blk = M.build([(lits, 1 + rng.randrange(L), ML), (fin, None, None)])
            st, out = M.ref_decode(blk, 0, **{})
            assert st == 0, (L, ML, M.STATUS_NAME[st])
            V.append(valid_vec(blk, out, f"hand_L{L}_M{ML}"))
    # offsets: 1..70 and the interesting large ones, on top of 80 bytes of history (offset <= history)
    for off in list(range(1, 71)) + [127, 128, 129, 255, 256, 257, 1000, 4095, 4096, 4097, 8191, 32768, 65534, 65535]:
        hist = bytes(rng.getrandbits(8) for _ in range(max(off, 80)))
        for ML in (4, 5, 15, 16, 17, 18, 19, 20, 35, 36, 37, 100, 300):
            blk = M.build([(hist, off, ML), (fin_for(ML), None, None)])
            st, out = M.ref_decode(blk, 0)
            assert st == 0
            V.append(valid_vec(blk, out, f"hand_off{off}_M{ML}"))
    # chained sequences: many short sequences (parser throughput corner: back-to-back tokens)
    for nseq in (2, 3, 8, 50, 400):
        seqs = [(bytes([65 + i % 26]) * (1 + i % 4), 1 + (i * 7) % 5, 4 + (i % 9)) for i in range(nseq)]
        seqs[0] = (b"seed-data", 3, 4 + nseq % 5)
        seqs.append((b"tail-literals!", None, None))
        blk = M.build(seqs)
        st, out = M.ref_decode(blk, 0)
        assert st == 0, M.STATUS_NAME[st]
        V.append(valid_vec(blk, out, f"hand_chain{nseq}"))
    # literal-only blocks of every length 0..70 (0 = the empty block [0x00])
    for n in range(0, 71):
        d = bytes(rng.getrandbits(8) for _ in range(n))
        V.append(valid_vec(M.build([(d, None, None)]), d, f"hand_lit{n}"))
    for n in (255, 256, 1000, 4096):
        d = bytes(rng.getrandbits(8) for _ in range(n))
        V.append(valid_vec(M.build([(d, None, None)]), d, f"hand_lit{n}"))
    # overlapping match chains: pattern phases at every offset 1..17, long lengths
    for off in range(1, 18):
        blk = M.build([(bytes(range(1, off + 1)), off, 1000 + off), (b"12345", None, None)])
        st, out = M.ref_decode(blk, 0)
        V.append(valid_vec(blk, out, f"hand_overlap{off}"))
    # exact end-of-block boundary: last match starts exactly 12 bytes before the end / exactly 5 final literals
    for ML in range(4, 21):
        for extra in (0, 1, 2):
            fin = bytes(rng.getrandbits(8) for _ in range(max(5, 12 - ML) + extra))
            blk = M.build([(b"0123456789abcdef", 16, ML), (fin, None, None)])
            st, out = M.ref_decode(blk, 0)
            assert st == 0, (ML, extra)
            V.append(valid_vec(blk, out, f"hand_eob_boundary_M{ML}_x{extra}"))
    # capacity: exact, +1, 0 (= max), larger; and one byte too small -> OUT_OVERFLOW
    blk = M.build([(b"abcdefgh", 8, 100), (b"fin!!", None, None)])
    st, out = M.ref_decode(blk, 0)
    n = len(out)
    V.append(valid_vec(blk, out, "cap_exact", cap=n))
    V.append(valid_vec(blk, out, "cap_zero", cap=0))
    V.append(valid_vec(blk, out, "cap_big", cap=n + 1000))
    for c in (n - 1, n - 5, n - 6, n - 7, n - 20, n - 100, 50, 8, 7, 1):
        V.append(dec_vec(blk, c, f"cap_small_{c}"))
    return V


def suite_lib():
    rng = random.Random(21)
    V = []
    for name, data in corpus.data_classes(rng, small=False):
        for blk, how in corpus.lib_blocks(data):
            V.append(valid_vec(blk, data, f"lib_{name}_{how}"))
            if len(data) <= 20000 and how in ("default", "hc9"):
                V.append(valid_vec(blk, data, f"lib_{name}_{how}_cap0", cap=0))
    return V


def suite_cli():
    rng = random.Random(31)
    V = []
    corp = [("text200k", corpus.text(rng, 200000)), ("mixed400k", corpus.mixed(rng, 400000)), ("rnd+text", corpus.rnd(rng, 70000) + corpus.text(rng, 140000)),
            ("zeros300k", bytes(300000)), ("pat13_150k", corpus.repeat_pattern(rng, 13, 150000))]
    # real files that exist on any machine: python sources, the lz4 binary itself
    for p in ("/usr/bin/lz4", sys.executable):
        try:
            corp.append((os.path.basename(p), open(os.path.realpath(p), "rb").read()[:600000]))
        except Exception:
            pass
    import glob
    src = b"".join(open(f, "rb").read() for f in sorted(glob.glob(os.path.dirname(os.__file__) + "/*.py"))[:60])[:500000]
    corp.append(("pysrc", src))
    nblk = 0
    for name, data in corp:
        for args in (["-1"], ["-3", "-B4"], ["-9", "-B4"], ["-12", "-B5"], ["--fast=5", "-B4"], ["-9", "-B6", "-BI"]):
            blocks, indep = corpus.cli_frame_blocks(data, args)
            for k, (blk, piece) in enumerate(blocks):
                if not indep and k > 0:
                    continue
                V.append(valid_vec(blk, piece, f"cli_{name}_{' '.join(args)}_b{k}"))
                nblk += 1
    return V


def suite_bad():
    rng = random.Random(41)
    V = []
    S = M.seq
    # hand-made malformed blocks, one error class each
    good = M.build([(b"abcdefgh", 8, 30), (b"final-lits", None, None)])
    st, gout = M.ref_decode(good, 0)
    assert st == 0
    cases = {
        "offset_zero": M.build([(b"abcdefgh", 8, 30), (b"final-lits", None, None)]).replace(bytes([8, 0]), bytes([0, 0]), 1),
        "offset_gt_pos": M.build([(b"abc", 4, 8), (b"final-lits", None, None)]),
        "offset_eq_pos_plus1": M.build([(b"abcd", 5, 8), (b"final-lits", None, None)]),
        "no_final_literals": M.build([(b"abcdefgh", 8, 30)]),
        "empty_input": b"",
        "final_lits_lt5": M.build([(b"abcdefgh", 8, 30), (b"fin!", None, None)]),
        "final_lits_0": M.build([(b"abcdefgh", 8, 30), (b"", None, None)]),
        "match_ends_in_last5": M.build([(b"abcdefgh", 8, 30), (b"fin!!", None, None)])[:-5] + bytes([0x00]),
        "last_match_lt12_from_end": M.build([(b"abcdefgh", 8, 4), (b"12345", None, None)]),
        "lit_len_trunc": bytes([0xF0, 0x10]) + b"short",
        "lit_ext_trunc": bytes([0xF0, 0xFF, 0xFF]),
        "lit_ext_only": bytes([0xF0]),
        "token_only_match": bytes([0x1F]),
        "offset_1byte": bytes([0x10, 0x41, 0x01]),
        "ml_ext_trunc": bytes([0x1F, 0x41, 0x01, 0x00, 0xFF]),
        "ml_ext_none": bytes([0x1F, 0x41, 0x01, 0x00]),
        "len_overflow_lit": bytes([0xF0]) + bytes([0xFF]) * 70000 + bytes([0x00]),
        "len_overflow_match": bytes([0x1F, 0x41, 0x01, 0x00]) + bytes([0xFF]) * 70000 + bytes([0x00]),
        "huge_match_cap_small": M.build([(b"a", 1, 1 << 20), (b"final", None, None)]),
        "garbage_ff": bytes([0xFF] * 40),
        "garbage_00": bytes([0x00] * 40),
        "zero_then_data": bytes([0x00, 0x41]),
    }
    for k, blk in cases.items():
        for cap in (0, 100, 1000):
            V.append(dec_vec(blk, cap, f"bad_{k}_cap{cap}"))
    # end-of-block rule, exact boundaries on the INVALID side: last match starts 11 / 10 / 9 bytes before the end; final literals 0..4
    for ML in range(4, 8):
        for dist in (11, 10, 9, 8):
            fl = dist - ML
            if fl < 0: continue
            V.append(dec_vec(M.build([(b"0123456789abcdef", 16, ML), (bytes(rng.getrandbits(8) for _ in range(fl)), None, None)]), 0, f"bad_eob_dist{dist}_M{ML}"))
    for ML in (4, 7, 8, 12, 30):
        for fl in range(0, 5):
            V.append(dec_vec(M.build([(b"0123456789abcdef", 16, ML), (bytes(rng.getrandbits(8) for _ in range(fl)), None, None)]), 0, f"bad_eob_fin{fl}_M{ML}"))
    # truncation at every byte of several valid blocks
    for name, data in (("text", corpus.text(rng, 700)), ("pat", corpus.repeat_pattern(rng, 5, 900)), ("mix", corpus.mixed(rng, 1500)), ("rnd", corpus.rnd(rng, 300))):
        for blk, how in corpus.lib_blocks(data)[:2]:
            for k in range(0, len(blk)):
                V.append(dec_vec(blk[:k], len(data), f"bad_trunc_{name}_{how}_{k}"))
            for c in (len(data) - 1, len(data) // 2, 1, 16, 17):
                V.append(dec_vec(blk, c, f"bad_cap_{name}_{how}_{c}"))
    return V


def suite_fuzz(n=6000, seed=51):
    rng = random.Random(seed)
    V = []
    seeds = []
    for name, data in corpus.data_classes(rng, small=True):
        for blk, how in corpus.lib_blocks(data)[:2]:
            seeds.append((blk, len(data)))
    for i in range(n):
        blk, cnt = rng.choice(seeds)
        b = bytearray(blk)
        for _ in range(rng.choice((1, 1, 2, 3, 5))):
            if not b: break
            kind = rng.random()
            k = rng.randrange(len(b))
            if kind < 0.5: b[k] = rng.choice((0, 1, 2, 15, 16, 0x0F, 0xF0, 0xFF, rng.randrange(256)))
            elif kind < 0.7: b.insert(k, rng.randrange(256))
            elif kind < 0.85: del b[k]
            else: b[k] ^= 1 << rng.randrange(8)
        if rng.random() < 0.1 and b: del b[rng.randrange(len(b)):]
        cap = rng.choice((cnt, cnt, cnt + 1, max(cnt - 1, 0), 0, 1 << 16))
        V.append(dec_vec(bytes(b), cap, f"fuzz{i}"))
    return V


def suite_ring():
    """valid blocks with bounded windows over large data: forces the history ring to wrap many times in small-HIST configurations"""
    import lz4enc_ref as E
    rng = random.Random(71)
    V = []
    big = [("text300k", corpus.text(rng, 300000)), ("mixed200k", corpus.mixed(rng, 200000)), ("pat13", corpus.repeat_pattern(rng, 13, 100000)),
           ("pat40", corpus.repeat_pattern(rng, 40, 100000)), ("zeros", bytes(120000)), ("rnd+rep", corpus.rnd(rng, 3000) * 30)]
    for name, data in big:
        for win in (15, 16, 17, 31, 32, 33, 63, 64, 100, 255, 256, 500, 1000, 1022, 1023, 4000, 65535):
            if len(data) > 150000 and win in (15, 31, 33, 63, 100, 500, 1022):
                continue
            blk = E.encode(data, window=win)
            assert LB.decompress(blk, uncompressed_size=len(data)) == data, ("encoder bug", name, win)
            V.append(valid_vec(blk, data, f"ring_{name}_w{win}"))
    return V


def _lit_block_of_size(total, rng):
    """a literal-only LZ4 block whose COMPRESSED size is exactly `total` bytes (token + extension + literals)"""
    lo = max(total - total // 255 - 4, 1)
    for L in range(lo, total):
        sz = 1 + (0 if L < 15 else (L - 15) // 255 + 1) + L
        if sz == total:
            return L
    raise ValueError(total)


def suite_limits():
    """exact boundaries of every limit of the hardware profile (PROFILE): compressed size == max_in / max_in+1, a token at index max_in, decompressed size == max_out / +1,
    offset == HIST-1 / HIST / HIST+1 (when the 16-bit field can express them), match length at the 24-bit length-counter limit (+/- 1)"""
    rng = random.Random(95)
    mi = PROFILE.get("max_in", 1 << 22); mo = PROFILE.get("max_out", 1 << 22); hist = PROFILE.get("hist", 1 << 16)
    V = []
    # compressed size exactly at the limit (valid literal-only block) and one over
    for tot in (mi - 1, mi, mi + 1):
        L = _lit_block_of_size(tot, rng)
        d = bytes(rng.getrandbits(8) for _ in range(L))
        V.append(dec_vec(M.build([(d, None, None)]), 0, f"limit_in_{tot - mi:+d}", orig=d))
    # a sequence that ends exactly at the limit, followed by one more token byte (the first byte beyond the limit)
    for extra in (0, 1):
        L = None
        for cand in range(mi - mi // 255 - 12, mi):
            if len(M.seq(bytes(cand), 1, 4)) == mi:
                L = cand; break
        if L is None: continue
        d = bytes(rng.getrandbits(8) for _ in range(L))
        blk = M.seq(d, 1, 4) + (b"\x00" if extra else b"")
        V.append(dec_vec(blk, 0, f"limit_in_token_after_{extra}"))
    # decompressed size at the limit (cap = 0 means "the hard maximum")
    if mo <= (1 << 22):
        z = bytes(mo)
        V.append(dec_vec(LB.compress(z, store_size=False), 0, "limit_out_exact_cap0"))
        V.append(dec_vec(LB.compress(bytes(mo + 1), store_size=False), 0, "limit_out_plus1_cap0"))
    # offsets around the window size
    for off in (hist - 2, hist - 1, hist, hist + 1):
        if 1 <= off <= 0xFFFF:
            h = bytes(rng.getrandbits(8) for _ in range(off + 20))
            blk = M.build([(h, off, 40), (bytes(rng.getrandbits(8) for _ in range(16)), None, None)])
            V.append(dec_vec(blk, 0, f"limit_offset_{off - hist:+d}"))
    # match length at the length-counter limit: 19 + 255*65792 + 236 = 2^24 - 1 (accepted by the length check -> out-of-capacity), +1 -> LENGTH
    lim = (1 << 24) - 1
    for lastb in (235, 236, 237):
        ext = bytes([255]) * 65792 + bytes([lastb])
        blk = bytes([0x1F]) + b"a" + bytes([1, 0]) + ext + bytes([0x50]) + b"final"
        V.append(dec_vec(blk, 0, f"limit_len_{19 + 255 * 65792 + lastb - lim:+d}"))
    return V


def suite_max():
    V = []
    rng = random.Random(61)
    # largest legal decompressed block (4 MiB), highly compressible: compressed to ~16 KiB
    z = bytes(1 << 22)
    V.append(valid_vec(LB.compress(z, store_size=False), z, "max_out_4MiB_zeros"))
    V.append(valid_vec(LB.compress(z, store_size=False), z, "max_out_4MiB_zeros_cap0", cap=0))
    t = corpus.text(rng, 1 << 22)
    V.append(valid_vec(LB.compress(t, store_size=False), t, "max_out_4MiB_text"))
    # one byte over the limit: OUT_OVERFLOW even with cap=0 (the hard bound MAX_OUT_BYTES)
    z1 = bytes((1 << 22) + 1)
    V.append(dec_vec(LB.compress(z1, store_size=False), 0, "over_out_4MiB+1_cap0"))
    V.append(dec_vec(LB.compress(z1, store_size=False), (1 << 22) + 1, "over_out_4MiB+1_cap_big"))
    # unbounded expansion attempt: a 255:1 match with a huge length against a small capacity
    V.append(dec_vec(M.build([(b"a", 1, 5_000_000), (b"final", None, None)]), 1000, "expand_bomb_cap1000"))
    # compressed block larger than MAX_IN_BYTES: a literal-only block of 4 MiB + 100 (valid LZ4, unsupported size) and exactly at the limit
    d = bytes(rng.getrandbits(8) for _ in range(4 * 1024 * 1024 - 20000))
    blk = M.build([(d, None, None)])
    V.append(dec_vec(blk, 0, "max_in_just_under_limit"))
    d2 = d + bytes(rng.getrandbits(8) for _ in range(30000))
    blk2 = M.build([(d2, None, None)])
    V.append(dec_vec(blk2, 0, "over_max_in_literal_block"))
    return V


import zlib


def enc_vec(data, cap=0, policy=0, tag=""):
    v = Vec(1, bytes(data), cap=cap, policy=policy, exp_crc=zlib.crc32(data) & 0xFFFFFFFF, tag=tag, exp_status=None, exp_out=None, orig=bytes(data))
    return v


def suite_enc_lib():
    rng = random.Random(81)
    V = []
    for name, data in corpus.data_classes(rng, small=False):
        V.append(enc_vec(data, 0, 0, f"enc_{name}_stream"))
        if len(data) <= 65536 and len(data) > 100:
            V.append(enc_vec(data, 0, 2, f"enc_{name}_raw"))
    return V


def suite_enc_edge():
    rng = random.Random(82)
    V = []
    for n in list(range(0, 81)) + [100, 127, 128, 129, 255, 256, 257, 511, 512, 513, 1023, 1024, 1025, 4095, 4096, 4097, 8191, 8192, 8193, 32767, 32768, 32769, 65535, 65536, 65537, 70000]:
        for kind in ("rnd", "zero", "text", "pat3", "mix"):
            if n > 4097 and kind in ("pat3",) and n not in (65536, 65535, 65537): continue
            d = {"rnd": lambda: corpus.rnd(rng, n), "zero": lambda: bytes(n), "text": lambda: corpus.text(rng, n),
                 "pat3": lambda: corpus.repeat_pattern(rng, 3, n), "mix": lambda: corpus.mixed(rng, n)}[kind]()
            V.append(enc_vec(d, 0, rng.choice((0, 0, 1, 2)), f"edge_{kind}{n}"))
    # a block whose matches all start exactly at / around the 12-bytes-from-the-end limit, and long runs ending near the 5-literal limit
    for n in range(13, 60):
        for lead in range(0, 4):
            d = bytes(rng.getrandbits(8) for _ in range(lead)) + b"abcd" * 30
            V.append(enc_vec(d[:n], 0, 0, f"edge_tail{n}_{lead}"))
    return V


def suite_enc_pol():
    import encmodel as E
    rng = random.Random(83)
    V = []
    bases = [("text4k", corpus.text(rng, 4096)), ("rnd4k", corpus.rnd(rng, 4096)), ("zeros3k", bytes(3000)), ("pat13", corpus.repeat_pattern(rng, 13, 5000)),
             ("tiny9", corpus.rnd(rng, 9)), ("tiny13", corpus.text(rng, 13)), ("empty", b""), ("mixed9k", corpus.mixed(rng, 9000)), ("rnd300", corpus.rnd(rng, 300))]
    for name, d in bases:
        cs = len(E.encode(d)); n = len(d)
        caps = sorted(set(c for c in (0, 1, 2, 10, cs - 1, cs, cs + 1, n - 1, n, n + 1, n + 16, 2 * n + 10, 100000) if c >= 0))
        for pol in (0, 1, 2, 3):
            for c in caps:
                V.append(enc_vec(d, c, pol, f"pol_{name}_p{pol}_cap{c}"))
    return V


def suite_enc_rnd(n=500, seed=84):
    rng = random.Random(seed)
    V = []
    for i in range(n):
        ln = rng.choice((rng.randrange(0, 300), rng.randrange(0, 5000), rng.randrange(0, 70000)))
        kind = rng.choice(("rnd", "text", "mix", "pat", "zero", "textrnd"))
        if kind == "rnd": d = corpus.rnd(rng, ln)
        elif kind == "text": d = corpus.text(rng, ln)
        elif kind == "mix": d = corpus.mixed(rng, ln)
        elif kind == "pat": d = corpus.repeat_pattern(rng, rng.choice((1, 2, 3, 5, 8, 17, 100)), ln)
        elif kind == "zero": d = bytes(ln)
        else: d = corpus.text(rng, ln // 2) + corpus.rnd(rng, ln - ln // 2)
        pol = rng.choice((0, 1, 2))
        cap = rng.choice((0, 0, ln, ln + 5, max(ln // 2, 1), max(ln // 4, 1), rng.randrange(1, ln + 20)))
        V.append(enc_vec(d, cap, pol, f"rnd{i}_{kind}{ln}"))
    return V


CRC_FN = lambda d: zlib.crc32(d) & 0xFFFFFFFF


def suite_core_mix(n_dec=900, n_enc=500, seed=91, faults=True):
    """decode and encode blocks interleaved in ONE stream, with CRC flags (valid / deliberately wrong expected CRC) and injected framing faults"""
    rng = random.Random(seed)
    pool_dec = []
    for nm in ("hand", "lib", "bad", "fuzz"):
        pool_dec += SUITES[nm]() if nm in ("hand", "bad", "fuzz") else [v for v in SUITES["lib"]() if len(v.data) < 70000]
    pool_enc = suite_enc_edge() + suite_enc_pol() + suite_enc_rnd(200, 85)
    pool_dec = rng.sample(pool_dec, min(n_dec, len(pool_dec)))
    pool_enc = rng.sample(pool_enc, min(n_enc, len(pool_enc)))
    V = []
    for v in pool_dec + pool_enc:
        flags = 0
        if v.mode == 0:
            st, out = v.exp_status, v.exp_out
            if rng.random() < 0.5:
                flags |= 1
                if st == 0 and rng.random() < 0.6:
                    flags |= 2
                    good = CRC_FN(out)
                    if rng.random() < 0.25:          # deliberately wrong expected CRC -> SF_CST_CRC
                        v.exp_crc = good ^ (1 << rng.randrange(32)); v.exp_status = M.STATUS["CRC"]
                    else:
                        v.exp_crc = good
                else:
                    v.exp_crc = rng.getrandbits(32)
        else:
            if rng.random() < 0.5: flags |= 1
        if faults and rng.random() < 0.07 and len(v.data) >= 40:
            flags |= rng.choice((1, 2, 3)) << 8
        v.flags = flags
        V.append(v)
    rng.shuffle(V)
    return V


ENC_SUITES = {"enc_lib": suite_enc_lib, "enc_edge": suite_enc_edge, "enc_pol": suite_enc_pol, "enc_rnd": suite_enc_rnd}
CORE_SUITES = {"core_mix": suite_core_mix, "core_mix_c": suite_core_mix}
SUITES = {"limits": suite_limits, "ring": suite_ring, "hand": suite_hand, "lib": suite_lib, "cli": suite_cli, "bad": suite_bad, "fuzz": suite_fuzz, "max": suite_max}

if __name__ == "__main__":
    args = sys.argv[1:]
    prof = "default"
    if "--profile" in args:
        k = args.index("--profile"); prof = args[k + 1]; del args[k:k + 2]
    PROFILE.update(PROFILES[prof])
    pre = "dec_" if prof == "default" else "dec" + prof[0] + "_"
    names = args or list(SUITES)
    for n in names:
        if n in CORE_SUITES:
            if n.endswith("_c"):
                import corpus as _c
                CRC_FN = _c.crc32c
            vecs = CORE_SUITES[n]()
            write_suite(n, vecs)
            print(f"{n}: {len(vecs)} vectors ({sum(1 for v in vecs if v.mode==0)} decode, {sum(1 for v in vecs if v.mode==1)} encode), {sum(len(v.data) for v in vecs)} input bytes")
            continue
        if n in ENC_SUITES:
            vecs = ENC_SUITES[n]()
            write_suite(n, vecs)
            print(f"{n}: {len(vecs)} vectors, {sum(len(v.data) for v in vecs)} input bytes")
            continue
        vecs = SUITES[n]()
        stats = {}
        for v in vecs:
            stats[M.STATUS_NAME[v.exp_status]] = stats.get(M.STATUS_NAME[v.exp_status], 0) + 1
        nb = sum(len(v.data) for v in vecs)
        write_suite(pre + n, vecs)
        print(f"{pre}{n}: {len(vecs)} vectors, {nb} input bytes, expected status mix {stats}")
