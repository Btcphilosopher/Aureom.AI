#!/usr/bin/env python3
"""Validates tools/lz4model.py (the contract the hardware is checked against) against the trusted software LZ4 (python-lz4, LZ4 1.9.4):

  A. every block produced by the library (all modes/levels, many data classes) must decode OK in the model to the original data;
  B. for every mutated / hand-malformed block, model-accept <=> library-accept, and when both accept the bytes are identical.
     The ONE documented exception is offset 0: the library does not reject it (it copies from the not-yet-written output
     position, i.e. indeterminate bytes) while the LZ4 block format defines offset 0 as invalid; the model (and the hardware) reject it.
  Output: reports/model_check.md
"""
import os, random, sys, collections
import lz4.block as LB
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lz4model as M
import corpus

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def lib_decode(blk, cap):
    try:
        return True, LB.decompress(blk, uncompressed_size=max(cap, 1) if cap else 1 << 22)
    except Exception:
        return False, None


def main(nfuzz=20000, seed=1):
    rng = random.Random(seed)
    stats = collections.Counter()
    problems = []
    # ---- A: valid library blocks
    for name, data in corpus.data_classes(rng, small=False):
        for blk, how in corpus.lib_blocks(data):
            st, out = M.ref_decode(blk, len(data))
            stats['A_total'] += 1
            if st != 0 or out != data:
                problems.append(("A", name, how, M.STATUS_NAME[st]))
            else:
                stats['A_ok'] += 1
    # ---- B: mutation fuzz + exhaustive truncation
    seeds = []
    for name, data in corpus.data_classes(rng, small=True):
        for blk, how in corpus.lib_blocks(data)[:3]:
            seeds.append((blk, len(data)))
    for blk, n in seeds:
        muts = [(blk[:k], n) for k in range(0, min(len(blk), 300))]          # every truncation point (first 300)
        muts += [(blk, max(n - d, 0)) for d in (1, 2, 5, 17)] + [(blk, n + 1), (blk, 0)]     # capacity too small / larger
        for _ in range(nfuzz // max(len(seeds), 1) + 1):
            b = bytearray(blk)
            for _ in range(rng.choice((1, 1, 2, 3))):
                if not b: break
                k = rng.randrange(len(b))
                b[k] = rng.choice((0, 1, 15, 16, 255, rng.randrange(256)))
            if b and rng.random() < 0.15:
                del b[rng.randrange(len(b)):]
            muts.append((bytes(b), n))
        for mb, cap in muts:
            st, out = M.ref_decode(mb, cap, strict=True)
            stp, outp = M.ref_decode(mb, cap, strict=False)
            ok, lout = lib_decode(mb, cap)
            stats['B_total'] += 1
            # (1) library accepts at this capacity => permissive model accepts the same bytes (offset 0 is the documented exception)
            if ok:
                if stp == 0:
                    if outp == lout: stats['B_lib_ok__perm_ok_same_bytes'] += 1
                    else: problems.append(("B1-bytes", len(mb), cap))
                elif stp == M.STATUS['OFFSET_ZERO']: stats['B_offset0_lib_accepts(documented)'] += 1
                else: problems.append(("B1-perm-rejects", M.STATUS_NAME[stp], len(mb), cap, mb[:40].hex()))
            else:
                # (2) library rejects, permissive accepts => only through its capacity-relative end-of-block rule => strict must be EOB_RULE
                if stp == 0:
                    if st == M.STATUS['EOB_RULE']: stats['B_lib_rejects_cap_relative_eob__strict_EOB'] += 1
                    else: problems.append(("B2-lib-stricter-unexplained", M.STATUS_NAME[st], len(mb), cap, mb[:40].hex()))
                else: stats['B_both_reject'] += 1
            # (3) strict accept => the library at the EXACT decoded size accepts the same bytes
            if st == 0:
                ok2, l2 = lib_decode(mb, len(out)) if len(out) else (True, b"")
                if len(out) == 0:
                    ok2, l2 = True, b""
                    try: l2 = LB.decompress(mb, uncompressed_size=1)  # tolerate: empty blocks are [0x00]
                    except Exception: ok2 = False
                if ok2 and l2 == out: stats['B_strict_ok__lib_exact_ok_same_bytes'] += 1
                else: problems.append(("B3-strict-ok-lib-exact-rejects", len(mb), cap, mb[:40].hex()))
            # (4) strict EOB_RULE => the library at the exact (permissive) decoded size rejects
            if st == M.STATUS['EOB_RULE']:
                ok4, _ = lib_decode(mb, len(outp)) if len(outp) else (False, None)
                if len(outp) == 0 or not ok4: stats['B_strict_EOB__lib_exact_rejects'] += 1
                else: problems.append(("B4-strict-EOB-lib-exact-accepts", len(mb), cap, mb[:40].hex()))
    out = ["# Model-vs-library check (tools/check_model.py)", "", "| item | count |", "|---|---|"]
    for k in sorted(stats): out.append(f"| {k} | {stats[k]} |")
    out += ["", f"**mismatches: {len(problems)}**", ""]
    for p in problems[:30]: out.append(f"- {p}")
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    open(os.path.join(ROOT, "reports", "model_check.md"), "w").write("\n".join(out) + "\n")
    print("\n".join(out))
    return 0 if not problems else 1


if __name__ == "__main__":
    sys.exit(main())
