#!/usr/bin/env python3
"""The encoder model must always produce blocks the trusted LZ4 library (and the lz4 CLI) accept and decode to the original data."""
import os, sys, random, subprocess, tempfile
import lz4.block as LB
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import encmodel as E, corpus, lz4frame as FR
rng = random.Random(3)
n = bad = 0; tot_in = tot_out = 0
for name, data in corpus.data_classes(rng, small=False):
    if len(data) > 65536: data = data[:65536]
    for kw in (dict(), dict(hash_bits=10), dict(hash_bits=14, accel=1), dict(accel=4), dict(skip_shift=3)):
        blk = E.encode(data, **kw)
        n += 1
        try:
            ok = (LB.decompress(blk, uncompressed_size=len(data)) == data) if len(data) else (blk == b"\x00")
        except Exception as e:
            ok = False
        if not ok: bad += 1; print("BAD", name, kw)
        if not kw: tot_in += len(data); tot_out += len(blk)
print(f"encmodel: {n} blocks decoded by the reference library, {bad} bad; default-config ratio over the corpus {tot_in/tot_out:.3f}")
sys.exit(1 if bad else 0)
