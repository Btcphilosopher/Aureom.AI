"""LZ4 FRAME builder (frame format spec: lz4_Frame_format.md) used to hand the hardware-produced BLOCKS to the independent `lz4` command-line tool.
An uncompressed block (the RAW policy of the encoder) is represented exactly as the frame format defines it: block-size word with bit 31 set."""
import struct

P1, P2, P3, P4, P5 = 2654435761, 2246822519, 3266489917, 668265263, 374761393
M32 = 0xFFFFFFFF


def _rotl(x, r):
    return ((x << r) | (x >> (32 - r))) & M32


def xxh32(data, seed=0):
    n = len(data); i = 0
    if n >= 16:
        v1 = (seed + P1 + P2) & M32; v2 = (seed + P2) & M32; v3 = seed & M32; v4 = (seed - P1) & M32
        while i <= n - 16:
            a, b, c, d = struct.unpack_from("<4I", data, i); i += 16
            v1 = (_rotl((v1 + a * P2) & M32, 13) * P1) & M32
            v2 = (_rotl((v2 + b * P2) & M32, 13) * P1) & M32
            v3 = (_rotl((v3 + c * P2) & M32, 13) * P1) & M32
            v4 = (_rotl((v4 + d * P2) & M32, 13) * P1) & M32
        h = (_rotl(v1, 1) + _rotl(v2, 7) + _rotl(v3, 12) + _rotl(v4, 18)) & M32
    else:
        h = (seed + P5) & M32
    h = (h + n) & M32
    while i <= n - 4:
        (a,) = struct.unpack_from("<I", data, i); i += 4
        h = (_rotl((h + a * P3) & M32, 17) * P4) & M32
    while i < n:
        h = (_rotl((h + data[i] * P5) & M32, 11) * P1) & M32; i += 1
    h ^= h >> 15; h = (h * P2) & M32; h ^= h >> 13; h = (h * P3) & M32; h ^= h >> 16
    return h


def build_frame(blocks, content, bmax_id=7, content_checksum=True):
    """blocks: [(payload_bytes, is_raw)] ; content: the concatenated original data (for the content checksum)"""
    flg = 0x60 | (0x04 if content_checksum else 0)
    bd = bmax_id << 4
    hc = (xxh32(bytes([flg, bd])) >> 8) & 0xFF
    f = bytearray(struct.pack("<I", 0x184D2204)) + bytes([flg, bd, hc])
    for payload, raw in blocks:
        f += struct.pack("<I", len(payload) | (0x80000000 if raw else 0)) + payload
    f += struct.pack("<I", 0)
    if content_checksum:
        f += struct.pack("<I", xxh32(content))
    return bytes(f)


if __name__ == "__main__":
    import lz4.frame as F, os
    # xxh32 check vectors and our own frame header against the library's
    assert xxh32(b"") == 0x02CC5D05, hex(xxh32(b""))
    d = os.urandom(1000)
    fr = F.compress(d, block_size=F.BLOCKSIZE_MAX4MB, block_linked=False, content_checksum=True, store_size=False)
    assert fr[6] == (xxh32(fr[4:6]) >> 8) & 0xFF, fr[4:7].hex()          # header checksum computed with OUR xxh32 == the library's
    assert xxh32(d) == int.from_bytes(fr[-4:], 'little')                   # content checksum too
    assert F.decompress(build_frame([(d, True)], d)) == d
    print("lz4frame self-check ok")
