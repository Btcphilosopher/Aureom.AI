"""Data classes and independent LZ4 producers shared by the model check, the vector generators and the benchmarks.
All compressors used here are software LZ4 (python-lz4 / the lz4 CLI): independent of the hardware and of tools/lz4model.py."""
import os, random, struct, subprocess, tempfile
import lz4.block as LB

WORDS = ("the of and to in is that for it with as was on be at by this have from or had not but what all were when we there can an "
         "your which their said if do will each about how up out them then she many some so these would other into has more her two "
         "like him see time could no make than first been its who now people my made over did down only way find use may water long "
         "little very after words called just where most know get through back much before go good new write our used me man too any "
         "day same right look think also around another came come work three word must because does part even place well such here "
         "take why things help put years different away again off went old number great tell men say small every found still between "
         "name should home big give air line set own under read last never us left end along while might next sound below saw something "
         "thought both few those always looked show large often together asked house don't world going want school important until form "
         "food keep children feet land side without boy once animal life enough took sometimes four head above kind began almost live "
         "page got earth need far hand high year mother light country father let night picture being study second soon story since white "
         "ever paper hard near sentence better best across during today however sure knew try told young sun thing whole hear example "
         "heard several change answer room sea against top turned learn point city play toward five using himself usually").split()


def text(rng, n):
    out = bytearray()
    while len(out) < n:
        out += rng.choice(WORDS).encode() + rng.choice((b" ", b" ", b" ", b", ", b". ", b"\n"))
    return bytes(out[:n])


def rnd(rng, n):
    return bytes(rng.getrandbits(8) for _ in range(n))


def repeat_pattern(rng, period, n):
    p = rnd(rng, period)
    return (p * (n // period + 1))[:n]


def mixed(rng, n):
    """random chunks interleaved with copies of earlier data at far distances (exercises large offsets)"""
    out = bytearray()
    while len(out) < n:
        r = rng.random()
        if r < 0.3 or len(out) < 100:
            out += rnd(rng, rng.randrange(1, 200))
        elif r < 0.6:
            out += text(rng, rng.randrange(1, 300))
        else:
            off = rng.choice((1, 2, 3, 7, 15, 16, 17, 31, 33, rng.randrange(1, len(out) + 1), min(len(out), 65535)))
            off = min(off, len(out))
            ln = rng.randrange(4, 400)
            for _ in range(ln):
                out.append(out[-off])
    return bytes(out[:n])


def data_classes(rng, small=False):
    """yields (name, bytes).  small=True: compact set for fuzzing; small=False: the full benchmark/regression set."""
    cls = []
    cls.append(("empty", b""))
    for n in list(range(1, 40)):
        cls.append((f"rnd{n}", rnd(rng, n)))
        cls.append((f"zeros{n}", bytes(n)))
    for n in (12, 13, 14, 15, 16, 17, 31, 32, 33, 63, 64, 65, 127, 128, 129):
        cls.append((f"txt{n}", text(rng, n)))
    for p in (1, 2, 3, 4, 5, 7, 8, 9, 15, 16, 17, 24, 31, 32, 33, 47, 48, 49, 63, 64, 100, 255, 256, 1000):
        cls.append((f"pat{p}", repeat_pattern(rng, p, 3000)))
    for n in (16, 17, 18, 19, 20, 100, 255, 256, 269, 270, 271, 273, 274, 275, 524, 525, 526, 529, 530, 4096, 65536, 65537):
        cls.append((f"run{n}", b"\x5a" * n))
    cls.append(("text4k", text(rng, 4096)))
    cls.append(("text64k", text(rng, 65536)))
    cls.append(("mixed20k", mixed(rng, 20000)))
    cls.append(("mixed80k", mixed(rng, 80000)))
    cls.append(("rnd300", rnd(rng, 300)))
    cls.append(("rnd4k", rnd(rng, 4096)))
    if not small:
        cls.append(("rnd64k", rnd(rng, 65536)))
        cls.append(("rnd150k", rnd(rng, 150000)))        # long literal run: length-extension chain of ~590 bytes
        cls.append(("text300k", text(rng, 300000)))
        cls.append(("mixed300k", mixed(rng, 300000)))
        cls.append(("pat7_1m", repeat_pattern(rng, 7, 1 << 20)))
        # far match: a 64 KiB-1 distant copy (largest legal offset)
        base = rnd(rng, 65535)
        cls.append(("far65535", base + base[:300] + rnd(rng, 40)))
        cls.append(("far65535b", base + base + rnd(rng, 40)))
    else:
        cls = [c for c in cls if len(c[1]) <= 100000]
    return cls


def lib_blocks(data):
    """independent LZ4 encodings of `data` (python-lz4 default / fast / high-compression).  Returns [(block, how)]"""
    res = []
    modes = [("default", dict(mode="default")), ("fast2", dict(mode="fast", acceleration=2)), ("fast9", dict(mode="fast", acceleration=9)),
             ("hc3", dict(mode="high_compression", compression=3)), ("hc9", dict(mode="high_compression", compression=9)),
             ("hc12", dict(mode="high_compression", compression=12))]
    for name, kw in modes:
        if len(data) > 400000 and name in ("hc9", "hc12", "fast9"):
            continue
        res.append((LB.compress(data, store_size=False, **kw), name))
    return res


# ---- lz4 CLI frames: extract the compressed blocks produced by the C command-line tool ---------------------------------------
def cli_frame_blocks(data, args):
    """compress `data` with the `lz4` CLI and return [(compressed_block, original_slice)] for independent compressed blocks.
    (Parses the LZ4 *frame* format only to locate the block boundaries; payload decoding is done by the DUT / library.)"""
    with tempfile.TemporaryDirectory() as d:
        src, dst = os.path.join(d, "in"), os.path.join(d, "out.lz4")
        open(src, "wb").write(data)
        subprocess.run(["lz4", "-q", "-f"] + args + [src, dst], check=True)
        f = open(dst, "rb").read()
    assert f[:4] == bytes.fromhex("04224d18"), "not an LZ4 frame"
    flg, bd = f[4], f[5]
    assert (flg >> 6) == 1
    indep = (flg >> 5) & 1
    has_bcs = (flg >> 4) & 1
    has_csz = (flg >> 3) & 1
    has_dict = flg & 1
    bmax = {4: 64 << 10, 5: 256 << 10, 6: 1 << 20, 7: 4 << 20}[(bd >> 4) & 7]
    p = 6 + (8 if has_csz else 0) + (4 if has_dict else 0) + 1     # + header checksum byte
    blocks = []
    off = 0
    while True:
        (sz,) = struct.unpack_from("<I", f, p); p += 4
        if sz == 0:
            break
        raw = sz >> 31
        sz &= 0x7FFFFFFF
        blk = f[p:p + sz]; p += sz + (4 if has_bcs else 0)
        piece = data[off:off + bmax]
        off += len(piece)
        if not raw:
            blocks.append((blk, piece))
    return blocks, bool(indep)


_C32C = None
def crc32c(data):
    """CRC-32C (Castagnoli, reflected, init/xorout 0xFFFFFFFF); check value of "123456789" is 0xE3069283"""
    global _C32C
    if _C32C is None:
        t = []
        for i in range(256):
            c = i
            for _ in range(8): c = (c >> 1) ^ (0x82F63B78 if c & 1 else 0)
            t.append(c)
        _C32C = t
    c = 0xFFFFFFFF
    for b in data: c = _C32C[(c ^ b) & 0xFF] ^ (c >> 8)
    return c ^ 0xFFFFFFFF

assert crc32c(b"123456789") == 0xE3069283
