#!/usr/bin/env python3
"""Software reference model of the CompressCore decoder CONTRACT, written from the LZ4 block-format specification
(https://github.com/lz4/lz4/blob/dev/doc/lz4_Block_format.md), NOT from the RTL.

It defines, for any byte string, exactly one (status, output) pair; the hardware must produce the same status, and -- when the
status is OK -- the same bytes.  Errors are resolved in *stream order* (byte-granular), see ref_decode().

It is itself checked against the trusted software LZ4 (python-lz4 = LZ4 1.9.4) on large corpora: tools/check_model.py.
"""
import struct

STATUS = dict(OK=0, TRUNCATED=1, OFFSET_ZERO=2, OFFSET_RANGE=3, OUT_OVERFLOW=4, LENGTH=5, BLOCK_SIZE=6, EOB_RULE=7,
              FRAMING=8, INCOMPRESSIBLE=9, DST_OVERFLOW=10, CRC=11)
STATUS_NAME = {v: k for k, v in STATUS.items()}

# default hardware profile (rtl/sf_lz4_decoder.sv parameter defaults)
MAX_IN_BYTES = 1 << 22
MAX_OUT_BYTES = 1 << 22
HIST_BYTES = 1 << 16
LEN_BITS = 24
MFLIMIT = 12       # last match must START at least 12 bytes before the end of the block
LASTLITERALS = 5   # the last 5 bytes of a block are always literals
MINMATCH = 4


def ref_decode(blk, cap=0, *, max_in=MAX_IN_BYTES, max_out=MAX_OUT_BYTES, hist=HIST_BYTES, len_bits=LEN_BITS, strict=True):
    """Decode one LZ4 block (independent block: no dictionary).  Returns (status, bytes_out).
    cap == 0 means "MAX_OUT_BYTES".  On an error the returned bytes are what the contract allows to be emitted before the
    error (hardware output before an error is *invalid* by contract and is never compared)."""
    cap_eff = min(cap if cap else max_out, max_out)
    len_limit = (1 << len_bits) - 1
    n = len(blk)
    out = bytearray()
    i = 0
    had_match = False
    last_match_start = 0
    final_lit = 0

    def in_fail(idx):
        # reading input byte idx failed: end of block (TRUNCATED) is detected before the size limit
        return STATUS['TRUNCATED'] if idx >= n else STATUS['BLOCK_SIZE']

    while True:
        # ---- token ----
        if i >= n or i >= max_in:
            return in_fail(i), bytes(out)
        tok = blk[i]; i += 1
        lnib, mnib = tok >> 4, tok & 15
        L = lnib
        if lnib == 15:
            while True:
                if i >= n or i >= max_in:
                    return in_fail(i), bytes(out)
                b = blk[i]; i += 1
                L += b
                if L > len_limit:
                    return STATUS['LENGTH'], bytes(out)
                if b != 255:
                    break
        # ---- literals (byte granular, see module docstring) ----
        t_cap = cap_eff - len(out)
        t_in = n - i
        t_sz = max_in - i
        pushed = min(L, t_in, t_sz)
        if pushed > t_cap:
            return STATUS['OUT_OVERFLOW'], bytes(out)
        out += blk[i:i + pushed]
        i += pushed
        if L > pushed:
            return (STATUS['TRUNCATED'] if t_in <= t_sz else STATUS['BLOCK_SIZE']), bytes(out)
        if i >= n:   # input ended exactly after the literals: this was the final (literal-only) sequence
            final_lit = L
            break
        # ---- offset ----
        if i >= max_in:
            return STATUS['BLOCK_SIZE'], bytes(out)
        lo = blk[i]; i += 1
        if i >= n or i >= max_in:
            return in_fail(i), bytes(out)
        hi = blk[i]; i += 1
        off = lo | (hi << 8)
        if off == 0:
            return STATUS['OFFSET_ZERO'], bytes(out)
        # ---- match length ----
        ml = mnib + MINMATCH
        if mnib == 15:
            while True:
                if i >= n or i >= max_in:
                    return in_fail(i), bytes(out)
                b = blk[i]; i += 1
                ml += b
                if ml > len_limit:
                    return STATUS['LENGTH'], bytes(out)
                if b != 255:
                    break
        # ---- engine checks, in this order ----
        if off > len(out) or off >= hist:
            return STATUS['OFFSET_RANGE'], bytes(out)
        if len(out) + ml > cap_eff:
            return STATUS['OUT_OVERFLOW'], bytes(out)
        had_match = True
        last_match_start = len(out)
        for _ in range(ml):               # byte-at-a-time == the overlapping-copy semantics of the format
            out.append(out[-off])
    # ---- end of block ----
    if strict and had_match and (final_lit < LASTLITERALS or (len(out) - last_match_start) < MFLIMIT):
        return STATUS['EOB_RULE'], bytes(out)
    return STATUS['OK'], bytes(out)


# --------------------------------------------------------------------------------------------------------------------
# Block builder: hand-made sequences, to reach every corner of the format without relying on any compressor.
# --------------------------------------------------------------------------------------------------------------------
def _ext(v):
    """extension bytes for a length remainder v >= 0 (the part above the 15 stored in the nibble)"""
    b = bytearray()
    while v >= 255:
        b.append(255); v -= 255
    b.append(v)
    return bytes(b)


def seq(lits=b"", off=None, mlen=None):
    """one LZ4 sequence.  off=None -> final (literal-only) sequence."""
    L = len(lits)
    tok = min(L, 15) << 4
    body = bytearray()
    if L >= 15:
        body += _ext(L - 15)
    body += lits
    if off is None:
        return bytes([tok]) + bytes(body)
    assert mlen >= MINMATCH and 1 <= off <= 0xFFFF
    ml = mlen - MINMATCH
    tok |= min(ml, 15)
    body += struct.pack('<H', off)
    if ml >= 15:
        body += _ext(ml - 15)
    return bytes([tok]) + bytes(body)


def build(seqs):
    """seqs: list of (lits, off, mlen); the last one must have off=None."""
    return b"".join(seq(*s) for s in seqs)


def ref_encode_trivial(data):
    """the always-valid trivial LZ4 block: one literal-only sequence."""
    return seq(data)


if __name__ == "__main__":
    # tiny self-check against the spec's own worked example: literal 'a', match offset 1 length 8, then 5 literals
    blk = build([(b"a", 1, 8), (b"bcdef", None, None)])
    st, out = ref_decode(blk, 14)
    assert st == 0 and out == b"a" * 9 + b"bcdef", (st, out)
    print("lz4model self-check ok")
