#!/usr/bin/env python3
"""Checks the shipped hardware-produced golden blocks (vectors/golden/hw) with the independent `lz4` command-line tool and python-lz4."""
import os, sys, json, subprocess, tempfile
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import lz4frame as FR, lz4.block as LB
G = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "vectors", "golden")
man = json.load(open(os.path.join(G, "manifest.json")))
bad = n = 0
for k, m in sorted(man.items()):
    if not k.startswith("hw/"): continue
    blk = open(os.path.join(G, k + ".lz4b"), "rb").read(); raw = open(os.path.join(G, k + ".raw"), "rb").read()
    fr = FR.build_frame([(blk, m.get("raw_fallback", False))], raw, bmax_id=4)
    with tempfile.NamedTemporaryFile(suffix=".lz4") as t:
        t.write(fr); t.flush()
        p = subprocess.run(["lz4", "-d", "-c", "-q", t.name], capture_output=True)
    ok = p.returncode == 0 and p.stdout == raw
    if not m.get("raw_fallback", False) and raw:
        ok &= LB.decompress(blk, uncompressed_size=len(raw)) == raw
    n += 1; bad += (not ok)
    if not ok: print("FAIL", k)
print(f"hardware golden blocks: {n - bad}/{n} decoded identically by `lz4 -d` (frame, content checksum) and python-lz4")
sys.exit(1 if bad else 0)
