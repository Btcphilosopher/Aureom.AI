# Formal sensitivity (formal/formal_mutants.py)

A proof is only meaningful if the harness can fail.  Each row: one injected RTL bug, the harness that must find it.

**13 / 13 non-equivalent injected bugs found by their harness; 1 mutant(s) documented as equivalent.**

| mutant | change | harness | result |
|---|---|---|---|
| srcchk-vis-plus1 | `<= {1'b0, mpos};` -> `<= {1'b0, mpos} + 1;` | srcchk_p16_h1024 (depth 1) | FOUND (FAIL) |
| srcchk-window-le | `(off32 < 32'(HIST_BYTES))` -> `(off32 <= 32'(HIST_BYTES))` | srcchk_p16_h1024 (depth 1) | FOUND (FAIL) |
| srcchk-src-off | `assign src       = pos1 - POSW'(off);` -> `assign src       = pos1 - POSW'(off) + 1'b1;` | srcchk_p16_h1024 (depth 1) | FOUND (FAIL) |
| srcchk-off-lt | `(off32 <= 32'(pos1))` -> `(off32 <= 32'(pos1) + 32'd1)` | srcchk_p16_h1024 (depth 1) | FOUND (FAIL) |
| fifo-full | `assign full  = (count == CW'(DEPTH));` -> `assign full  = (count == CW'(DEPTH - 1));` | fifo_w8_d4 (depth 8) | FOUND (FAIL) |
| fifo-pop-skip | `if (do_pop)  rp <= rp + 1'b1;` -> `if (do_pop)  rp <= rp + 2'd2;` | fifo_w8_d4 (depth 8) | FOUND (FAIL) |
| pack-complete | `wire            completes = (tot >= (LW+2)'(BYTES)` -> `wire            completes = (tot > (LW+2)'(BYTES))` | pack_dw16_f2 (depth 9) | equivalent: word completion needs `> BYTES` instead of `>= BYTES`: an exactly-full accumulator is pushed one item later (or at the flush) -- the byte stream, beat shape, block ends and sideband are identical; only the cycle in which the word is pushed changes |
| pack-mask | `if ((LW+1)'(i) < in_n) cm[8*i +: 8] = in_data[8*i` -> `if ((LW+1)'(i) <= in_n) cm[8*i +: 8] = in_data[8*i` | pack_dw16_f2 (depth 9) | FOUND (FAIL) |
| pack-flush | `if (h_valid && acc_n != '0) begin
        f_push =` -> `if (h_valid) begin
        f_push = !f_full;` | pack_dw16_f2 (depth 9) | FOUND (FAIL) |
| pack-tid | `h_n <= (LW+1)'(BYTES); h_tid <= in_tid;` -> `h_n <= (LW+1)'(BYTES); h_tid <= acc_tid;` | pack_dw16_f2 (depth 9) | FOUND (FAIL) |
| hist-hi-be | `wire [BYTES-1:0] w_hi_be = w_bewide[2*BYTES-1:BYTE` -> `wire [BYTES-1:0] w_hi_be = w_bewide[2*BYTES-2:BYTE` | history_dw16_h64 (depth 4) | FOUND (FAIL) |
| hist-bank | `wire              w_to_b0   = (w_word[0] == 1'b0);` -> `wire              w_to_b0   = (w_word[0] == 1'b1);` | history_dw16_h64 (depth 4) | FOUND (FAIL) |
| hist-roff | `roff_q <= r_off;` -> `roff_q <= r_off + 1'b1;` | history_dw16_h64 (depth 4) | FOUND (FAIL) |
| hist-wrap | `wire [WAW-1:0] w_word1 = w_word + 1'b1;` -> `wire [WAW-1:0] w_word1 = w_word + 2'd2;` | history_dw16_h64 (depth 4) | FOUND (FAIL) |
