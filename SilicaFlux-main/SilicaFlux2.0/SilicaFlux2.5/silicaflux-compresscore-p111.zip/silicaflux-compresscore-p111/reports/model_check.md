# Model-vs-library check (tools/check_model.py)

| item | count |
|---|---|
| A_ok | 915 |
| A_total | 915 |
| B_both_reject | 29991 |
| B_lib_ok__perm_ok_same_bytes | 12858 |
| B_lib_rejects_cap_relative_eob__strict_EOB | 14 |
| B_offset0_lib_accepts(documented) | 121 |
| B_strict_EOB__lib_exact_rejects | 56 |
| B_strict_ok__lib_exact_ok_same_bytes | 12816 |
| B_total | 42984 |

**mismatches: 0**

