# Encoder interoperability: hardware blocks decoded by the independent `lz4` command-line tool

`*** LZ4 command line interface 64-bits v1.9.4, by Yann Collet ***`; python-lz4 4.4.5.

| suite | blocks | of which RAW (uncompressed frame blocks) | frames | `lz4 -d` | python-lz4 frame decode |
|---|---|---|---|---|---|
| enc_lib | 192 | 5 | 5 | 5/5 | 5/5 |
| enc_edge | 702 | 75 | 18 | 18/18 | 18/18 |
| enc_rnd | 299 | 30 | 8 | 8/8 | 8/8 |
