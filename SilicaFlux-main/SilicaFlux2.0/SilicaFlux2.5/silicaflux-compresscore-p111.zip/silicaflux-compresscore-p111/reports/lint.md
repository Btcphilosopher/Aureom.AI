# Lint report (Verilator 5.020, -Wall, no waivers file; the only suppressions are inline `lint_off UNUSEDSIGNAL` pragmas on intentionally unused bits)

| top | configuration | warnings |
|---|---|---|
| sf_compress_core | default | 0 |
| sf_compress_core | CRC-32C, no perf | 0 |
| sf_compress_core | no CRC stage | 0 |
| sf_compress_core | small decoder window + permissive EOB | 0 |
| sf_compress_core | small encoder (4 KiB block, 2^8 table, accel 3) | 0 |
| sf_compress_core | large table 2^16, 8 blocks in flight | 0 |
| sf_lz4_decoder | decoder alone, default | 0 |
| sf_lz4_decoder | decoder alone, 4 KiB window | 0 |
| sf_lz4_encoder | encoder alone, default | 0 |
| sf_lz4_encoder | encoder alone, 16 KiB / 2^10 / accel 2 | 0 |
| sf_lz4_matchfinder | match finder, 2^14 | 0 |
| sf_lz4_pack | packer, 64-bit | 0 |
| sf_lz4_pack | packer, 256-bit, FIFO 8 | 0 |
| sf_lz4_history | history, 128-bit 64 KiB | 0 |
| sf_lz4_history | history, 64-bit 4 KiB | 0 |
| sf_lz4_srcchk | hazard predicate | 0 |
| sf_compress_crc | CRC stage | 0 |
| sf_compress_perf | counters | 0 |

## Negative elaboration tests (each must be rejected)

| illegal parameters | rejected |
|---|---|
| sf_lz4_decoder DW=64 | yes |
| sf_lz4_decoder HIST_BYTES not a power of two | yes |
| sf_lz4_decoder HIST_BYTES=32 (< 64) | yes |
| sf_lz4_decoder MAX_OUT_BYTES < HIST_BYTES | yes |
| sf_lz4_encoder DW=64 | yes |
| sf_lz4_encoder BLK_BYTES=131072 (> 64 KiB) | yes |
| sf_lz4_encoder BLK_BYTES not a power of two | yes |
| sf_lz4_encoder ACCEL=0 | yes |
| sf_lz4_matchfinder HASH_BITS=4 | yes |
| sf_lz4_matchfinder HASH_BITS=24 | yes |
| sf_lz4_fifo DEPTH=3 | yes |
| sf_lz4_fifo DEPTH=1 | yes |
| sf_lz4_history HIST_BYTES=48 | yes |

## Yosys 0.33 parse (read_verilog -sv + hierarchy) of every top

- sf_compress_core: parses and elaborates
- sf_lz4_decoder: parses and elaborates
- sf_lz4_encoder: parses and elaborates
- sf_lz4_history: parses and elaborates
- sf_lz4_pack: parses and elaborates
- sf_lz4_matchfinder: parses and elaborates
- sf_compress_crc: parses and elaborates
- sf_compress_stream_adapter: parses and elaborates
- sf_compress_perf: parses and elaborates
