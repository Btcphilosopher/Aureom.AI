# Mutation testing (scripts/mutate.py)

Each mutant is one textual change to one RTL file, built into its own Verilator model and run against the regression subset (decoder: dec_limits, dec_hand, dec_bad, dec_lib, dec_ring, dec_fuzz; decoder small-window profile: decs_limits, decs_hand, decs_bad, decs_ring; encoder: enc_edge, enc_pol, enc_rnd, enc_lib; encoder small-table config: enc_edge, enc_rnd, enc_lib; core: core_mix + round trip/perf check; profile rand50). Baseline gate: the unmutated design passes every one of these.

**52 / 58 valid mutants killed; 6 survive, of which 6 are analysed as equivalent / performance-only (below) and 0 are unexplained; 0 invalid.**

| mutant | file | change | result | detected by |
|---|---|---|---|---|
| srcchk-vis-plus1 | sf_lz4_srcchk | SRAM read issued one byte before the source is committed | KILLED | dec_hand: ('hand_L16_M17', 'output differs at byte 32 (got 38 bytes, expected 38)') |
| srcchk-window-le | sf_lz4_srcchk | offset == window size accepted (small-window profile) | KILLED | decs_limits: ('limit_offset_+0', 'status OK != expected OFFSET_RANGE') |
| srcchk-off-lt-pos | sf_lz4_srcchk | offset == bytes produced rejected | KILLED | dec_hand: ('hand_L0_M4', 'status OFFSET_RANGE != expected OK') |
| dec-fast-zero-off | sf_lz4_decoder | fast path accepts offset 0 | KILLED | dec_bad: ('bad_garbage_00_cap0', 'status OFFSET_RANGE != expected OFFSET_ZERO') |
| dec-fast-need | sf_lz4_decoder | fast path consumes one byte too few | KILLED | dec_hand: ('hand_L0_M4', 'status OFFSET_RANGE != expected OK') |
| dec-llext-255 | sf_lz4_decoder | literal extension terminator 254 instead of <255 | KILLED | dec_hand: ('hand_L269_M4', 'status TRUNCATED != expected OK') |
| dec-mlen-base | sf_lz4_decoder | minimum match 3 instead of 4 (slow path) | KILLED | dec_hand: ('hand_L0_M20', 'output differs at byte 11 (got 36 bytes, expected 37)') |
| dec-mlext-base | sf_lz4_decoder | match length with extension off by one | KILLED | dec_hand: ('hand_L0_M19', 'output differs at byte 30 (got 35 bytes, expected 36)') |
| dec-offzero-ignored | sf_lz4_decoder | offset 0 not rejected (slow path) | KILLED | dec_bad: ('bad_offset_zero_cap0', 'status OFFSET_RANGE != expected OFFSET_ZERO') |
| dec-size-gt | sf_lz4_decoder | compressed size limit off by one | KILLED | dec_limits: ('limit_in_token_after_1', 'status EOB_RULE != expected BLOCK_SIZE') |
| dec-lit-take | sf_lz4_decoder | literal chunk size wrong when the beat ends exactly at the run end | KILLED | dec_hand: ('hand_L0_M4', 'status OFFSET_RANGE != expected OK') |
| dec-len-limit | sf_lz4_decoder | match-length overflow limit off by one | KILLED | dec_limits: ('limit_len_+1', 'status EOB_RULE != expected LENGTH') |
| dec-lit-cap | sf_lz4_decoder | literal capacity check off by one | KILLED | dec_hand: ('cap_small_112', 'status OK != expected OUT_OVERFLOW') |
| dec-match-cap | sf_lz4_decoder | match capacity check off by one | KILLED | dec_hand: ('cap_small_107', 'emitted 108 bytes > capacity 107') |
| dec-eob-12 | sf_lz4_decoder | last-match rule 13 instead of 12 | KILLED | dec_hand: ('hand_L0_M4', 'status EOB_RULE != expected OK') |
| dec-eob-5 | sf_lz4_decoder | last-5-literals rule weakened | KILLED | dec_bad: ('bad_final_lits_lt5_cap0', 'status OK != expected EOB_RULE') |
| dec-phase | sf_lz4_decoder | overlapping-copy phase advance wrong | KILLED | dec_hand: ('hand_L0_M17', 'output differs at byte 28 (got 34 bytes, expected 34)') |
| dec-rep | sf_lz4_decoder | overlapping-copy pattern rotated | KILLED | dec_hand: ('hand_L0_M4', 'output differs at byte 8 (got 24 bytes, expected 24)') |
| dec-pat-wait | sf_lz4_decoder | overlapping copy captures the tail before the previous chunk committed | KILLED | dec_hand: ('hand_L0_M4', 'output differs at byte 8 (got 24 bytes, expected 24)') |
| dec-lms | sf_lz4_decoder | last-match start recorded at the END of multi-chunk matches | KILLED | dec_hand: ('hand_L0_M17', 'status EOB_RULE != expected OK') |
| dec-tail | sf_lz4_decoder | tail register shifted by one byte too many | KILLED | dec_hand: ('hand_L0_M4', 'output differs at byte 8 (got 24 bytes, expected 24)') |
| dec-mpos | sf_lz4_decoder | committed-byte counter advances by 16 for partial chunks | KILLED | dec_hand: ('hand_L16_M17', 'output differs at byte 30 (got 38 bytes, expected 38)') |
| dec-seq-lit | sf_lz4_decoder | fast-path literal chunk one byte short | KILLED | dec_hand: ('hand_L0_M4', 'output differs at byte 7 (got 23 bytes, expected 24)') |
| hist-hi-be | sf_lz4_history | byte enables of the upper word shifted | SURVIVED |  |
| hist-bank | sf_lz4_history | write bank assignment swapped | KILLED | dec_hand: ('hand_L16_M17', 'output differs at byte 16 (got 38 bytes, expected 38)') |
| hist-funnel | sf_lz4_history | read bank order swapped | KILLED | dec_hand: ('hand_L16_M17', 'output differs at byte 16 (got 38 bytes, expected 38)') |
| hist-roff | sf_lz4_history | read byte offset off by one | KILLED | dec_hand: ('hand_L16_M17', 'output differs at byte 16 (got 38 bytes, expected 38)') |
| pack-complete | sf_lz4_pack | word completion needs more than BYTES | SURVIVED |  |
| pack-flush | sf_lz4_pack | flush pushes the held word as non-last even when the accumulator is empty | KILLED | dec_hand: ('hand_L0_M4', 'output differs at byte 24 (got 227 bytes, expected 24)') |
| pack-mask | sf_lz4_pack | chunk not masked to its byte count | KILLED | dec_hand: ('hand_L0_M4', 'output differs at byte 8 (got 24 bytes, expected 24)') |
| enc-token-lit | sf_lz4_encoder | literal-length nibble saturates at 16 | SURVIVED |  |
| enc-ext-255 | sf_lz4_encoder | extension byte count uses 254 | KILLED | enc_edge: ('edge_mix4096', 'output differs from the model at byte 1799 (got 2100 bytes, mo |
| enc-lext-base | sf_lz4_encoder | literal extension value off by one | KILLED | enc_edge: ('edge_text15', 'output differs from the model at byte 1 (got 17 bytes, model 17 |
| enc-mext-base | sf_lz4_encoder | match with exactly 19 bytes emits no extension | KILLED | enc_edge: ('edge_zero25', 'output differs from the model at byte 4 (got 10 bytes, model 11 |
| enc-mflimit | sf_lz4_encoder | a match may start 11 bytes before the end (violates the format) | KILLED | enc_edge: ('edge_pat314', 'output differs from the model at byte 0 (got 12 bytes, model 15 |
| enc-lastlit | sf_lz4_encoder | a match may reach into the last 5 bytes (violates the format) | KILLED | enc_edge: ('edge_zero13', 'output differs from the model at byte 0 (got 9 bytes, model 10) |
| enc-skip | sf_lz4_encoder | skip acceleration slower (valid but different output) | KILLED | enc_edge: ('edge_text127', 'output differs from the model at byte 0 (got 122 bytes, model  |
| enc-raw-lim | sf_lz4_encoder | RAW policy accepts a compressed block that is not smaller | KILLED | enc_edge: ('edge_text70', 'raw flag 0 != 1') |
| enc-stream-over | sf_lz4_encoder | emission may exceed the capacity by one byte | KILLED | enc_edge: ('edge_text70', 'raw flag 0 != 1') |
| enc-raw-fit | sf_lz4_encoder | RAW fallback refused when the input exactly fits | KILLED | enc_pol: ('pol_rnd4k_p2_cap4096', 'status INCOMPRESSIBLE != expected OK') |
| enc-crc-pass | sf_lz4_encoder | CRC sideband corrupted | KILLED | enc_edge: ('edge_rnd0', 'crc sideband not passed through') |
| enc-empty-raw | sf_lz4_encoder | RAW empty-input special case on the wrong length | KILLED | enc_edge: ('edge_zero0', 'raw flag 0 != 1') |
| mf-verify | sf_lz4_matchfinder | candidate verified on 3 bytes only | SURVIVED |  |
| mf-ext-lt | sf_lz4_matchfinder | extension compares one byte past the limit | SURVIVED |  |
| mf-ext-iter | sf_lz4_matchfinder | extension iterates once more at an exact 16-byte boundary | SURVIVED |  |
| mf-verify-skip | sf_lz4_matchfinder | candidate verification skipped (hash collisions would create invalid matches; small table config) | KILLED | enc_edge: ('edge_mix67', 'output differs from the model at byte 1 (got 69 bytes, model 69)') |
| mf-pass-resp | sf_lz4_matchfinder | PASS response lost on epoch wrap (hang) | KILLED | enc_edge: ('edge_zero39', 'status 65534 != expected OK') |
| ad-keep | sf_compress_stream_adapter | non-contiguous keep not flagged | KILLED | core_mix: ('edge_pat340', 'framing fault 3 was not detected (status OK)') |
| ad-midfirst | sf_compress_stream_adapter | first flag inside a block not flagged | KILLED | core_mix: ('edge_zero40', 'framing fault 2 was not detected (status OK)') |
| ad-nofirst | sf_compress_stream_adapter | missing first flag not flagged | KILLED | core_mix: ('edge_rnd46', 'framing fault 1 was not detected (status OK)') |
| ad-keep-out | sf_compress_stream_adapter | output byte mask one lane too wide | KILLED | core_mix: ('hand_off62_M5', 'decompressed output differs') |
| ad-order | sf_compress_stream_adapter | order queue popped on every beat | KILLED | core_mix: ('fuzz1396', 'crc_valid 0 != 1') |
| ad-policy | sf_compress_stream_adapter | policy field slice shifted | KILLED | core_mix: ('pol_text4k_p2_cap3030', 'status DST_OVERFLOW != expected INCOMPRESSIBLE') |
| core-crc-cmp | sf_compress_core | CRC check inverted | KILLED | core_mix: ('hand_L13_M529', 'status CRC != expected OK') |
| crc-noreset | sf_compress_crc | running CRC not restarted after a block | KILLED | core_mix: ('hand_L13_M529', 'status CRC != expected OK') |
| crc-poly | sf_compress_crc | CRC polynomial bit flipped | KILLED | core_mix: ('pol_text4k_p2_cap3030', 'crc of the raw input wrong') |
| perf-inbytes | sf_compress_perf | input byte counter counts beats (perf check only) | KILLED | roundtrip/perf check failed |
| perf-lat | sf_compress_perf | latency off by one cycle (perf check only) | KILLED | roundtrip/perf check failed |

## Survivors and why they are accepted

- `hist-hi-be` (byte enables of the upper word shifted): EQUIVALENT at system level: the shifted upper-word byte enable writes ONE junk byte just ahead of the write pointer; the next chunk overwrites it before anything can read it, and its previous content sat at distance exactly HIST_BYTES (an illegal offset). The module-level formal shadow-memory proof DOES detect it (formal/formal_mutants.py).
- `pack-complete` (word completion needs more than BYTES): EQUIVALENT: an exactly-full accumulator is pushed one item later (or at the flush); the byte stream, beat shape, block ends and sideband are identical (also confirmed by the formal harness, which cannot distinguish it either).
- `enc-token-lit` (literal-length nibble saturates at 16): EQUIVALENT: for a literal length of exactly 15, `lit[3:0]` is already 4'd15, so saturating at 15 or at 16 yields the same nibble.
- `mf-verify` (candidate verified on 3 bytes only): EQUIVALENT for this hash: two 4-byte values that differ only in the top byte always differ in the top 8 hash bits, which lie inside the table index (HASH_BITS >= 8); index equality plus equal first 3 bytes therefore already implies equal 4th byte. The check that verification as a whole cannot be dropped is `mf-verify-skip` (killed).
- `mf-ext-lt` (extension compares one byte past the limit): EQUIVALENT: the extra compared lane can only set mism = ncmp, which is the value it already has when all lower lanes match.
- `mf-ext-iter` (extension iterates once more at an exact 16-byte boundary): PERFORMANCE-ONLY: one redundant extension iteration that compares zero bytes and returns the same length (two extra cycles per exactly-16-byte-aligned match).
