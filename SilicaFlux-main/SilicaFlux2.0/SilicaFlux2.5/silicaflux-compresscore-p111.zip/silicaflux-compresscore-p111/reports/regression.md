# Regression report (scripts/regress.py)

Verilator 5.020, trusted reference: python-lz4 (LZ4 1.9.4) and the `lz4` v1.9.4 command-line tool. Backpressure profiles: full, rand50, slow_out, slow_in, burst, rand_hi, rand_lo. Wall time 539 s.

**Total vector executions: 339,939. Overall: ALL PASS**

| group | item | scope | result | ok | detail |
|---|---|---|---|---|---|
| models | tools/check_model.py (decoder contract vs python-lz4) |  | PASS |  | **mismatches: 0** |
| models | tools/check_encmodel.py (encoder model vs python-lz4) |  | PASS |  | encmodel: 765 blocks decoded by the reference library, 0 bad; default-config ratio over the corpus 1.953 |
| core [crc32c] | core_mix_c | 4200 vectors in 3 runs | PASS | 4200 | 10,120,241 simulated cycles; profiles: burst/split1, full/split1, rand50/split1 |
| core [default] | core_mix | 19600 vectors in 14 runs | PASS | 19600 | 51,132,008 simulated cycles; profiles: burst/split0, burst/split1, full/split0, full/split1, rand50/split0, rand50/split1, rand_hi/split0, rand_hi/split1, rand_lo/split0, rand_lo/split1, slow_in/split0, slow_in/split1, slow_out/split0, slow_out/split1 |
| core [nocrc] | dec_hand | 5694 vectors in 3 runs | PASS | 5694 | 1,719,114 simulated cycles; profiles: burst/split1, full/split1, rand50/split1 |
| core [nocrc] | dec_lib | 3597 vectors in 3 runs | PASS | 3597 | 5,552,696 simulated cycles; profiles: burst/split1, full/split1, rand50/split1 |
| core [nocrc] | enc_edge | 2148 vectors in 3 runs | PASS | 2148 | 8,416,153 simulated cycles; profiles: burst/split1, full/split1, rand50/split1 |
| core [nocrc] | enc_pol | 1260 vectors in 3 runs | PASS | 1260 | 6,647,812 simulated cycles; profiles: burst/split1, full/split1, rand50/split1 |
| decoder [default] | dec_bad | 29071 vectors in 7 runs | PASS | 29071 | 7,925,676 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [default] | dec_cli | 1127 vectors in 7 runs | PASS | 1127 | 27,346,854 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [default] | dec_fuzz | 42000 vectors in 7 runs | PASS | 42000 | 15,247,930 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [default] | dec_hand | 13286 vectors in 7 runs | PASS | 13286 | 6,351,916 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [default] | dec_lib | 8393 vectors in 7 runs | PASS | 8393 | 18,997,499 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [default] | dec_limits | 84 vectors in 7 runs | PASS | 84 | 52,458,903 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [default] | dec_max | 16 vectors in 2 runs | PASS | 16 | 6,784,712 simulated cycles; profiles: full, rand50 |
| decoder [default] | dec_ring | 616 vectors in 7 runs | PASS | 616 | 20,150,935 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [opq8] | dec_bad | 8306 vectors in 2 runs | PASS | 8306 | 1,465,764 simulated cycles; profiles: full, rand50 |
| decoder [opq8] | dec_cli | 322 vectors in 2 runs | PASS | 322 | 4,596,340 simulated cycles; profiles: full, rand50 |
| decoder [opq8] | dec_hand | 3796 vectors in 2 runs | PASS | 3796 | 696,789 simulated cycles; profiles: full, rand50 |
| decoder [opq8] | dec_lib | 2398 vectors in 2 runs | PASS | 2398 | 2,856,230 simulated cycles; profiles: full, rand50 |
| decoder [opq8] | dec_max | 16 vectors in 2 runs | PASS | 16 | 6,623,760 simulated cycles; profiles: full, rand50 |
| decoder [permissive] | decp_bad | 29071 vectors in 7 runs | PASS | 29071 | 7,932,585 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [permissive] | decp_fuzz | 42000 vectors in 7 runs | PASS | 42000 | 15,238,856 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [permissive] | decp_hand | 13286 vectors in 7 runs | PASS | 13286 | 6,362,899 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [permissive] | decp_limits | 84 vectors in 7 runs | PASS | 84 | 52,433,269 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [permissive] | decp_ring | 616 vectors in 7 runs | PASS | 616 | 20,127,167 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [small] | decs_bad | 29071 vectors in 7 runs | PASS | 29071 | 6,716,385 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [small] | decs_fuzz | 42000 vectors in 7 runs | PASS | 42000 | 12,304,550 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [small] | decs_hand | 13286 vectors in 7 runs | PASS | 13286 | 6,318,986 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [small] | decs_limits | 98 vectors in 7 runs | PASS | 98 | 5,219,406 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| decoder [small] | decs_ring | 616 vectors in 7 runs | PASS | 616 | 19,131,682 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| encoder [default] | enc_edge | 5012 vectors in 7 runs | PASS | 5012 | 20,196,999 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| encoder [default] | enc_lib | 1407 vectors in 7 runs | PASS | 1407 | 9,776,191 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| encoder [default] | enc_pol | 2940 vectors in 7 runs | PASS | 2940 | 15,877,351 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| encoder [default] | enc_rnd | 3500 vectors in 7 runs | PASS | 3500 | 75,468,782 simulated cycles; profiles: burst, full, rand50, rand_hi, rand_lo, slow_in, slow_out |
| encoder [fast] | enc_edge | 1432 vectors in 2 runs | PASS | 1432 | 4,201,352 simulated cycles; profiles: full, rand50 |
| encoder [fast] | enc_lib | 402 vectors in 2 runs | PASS | 402 | 1,970,693 simulated cycles; profiles: full, rand50 |
| encoder [fast] | enc_pol | 840 vectors in 2 runs | PASS | 840 | 2,215,393 simulated cycles; profiles: full, rand50 |
| encoder [fast] | enc_rnd | 1000 vectors in 2 runs | PASS | 1000 | 14,844,911 simulated cycles; profiles: full, rand50 |
| encoder [small] | enc_edge | 1432 vectors in 2 runs | PASS | 1432 | 756,354 simulated cycles; profiles: full, rand50 |
| encoder [small] | enc_lib | 402 vectors in 2 runs | PASS | 402 | 735,251 simulated cycles; profiles: full, rand50 |
| encoder [small] | enc_pol | 840 vectors in 2 runs | PASS | 840 | 2,338,645 simulated cycles; profiles: full, rand50 |
| encoder [small] | enc_rnd | 1000 vectors in 2 runs | PASS | 1000 | 2,568,372 simulated cycles; profiles: full, rand50 |
| encoder [tiny_table] | enc_edge | 1432 vectors in 2 runs | PASS | 1432 | 758,315 simulated cycles; profiles: full, rand50 |
| encoder [tiny_table] | enc_lib | 402 vectors in 2 runs | PASS | 402 | 640,532 simulated cycles; profiles: full, rand50 |
| encoder [tiny_table] | enc_pol | 840 vectors in 2 runs | PASS | 840 | 1,921,023 simulated cycles; profiles: full, rand50 |
| encoder [tiny_table] | enc_rnd | 1000 vectors in 2 runs | PASS | 1000 | 2,221,805 simulated cycles; profiles: full, rand50 |
| scripts | hardware compress -> lz4 CLI frame decode (tests/interop_enc.py) |  | PASS |  | | enc_edge | 702 | 75 | 18 | 18/18 | 18/18 | | | enc_rnd | 299 | 30 | 8 | 8/8 | 8/8 | |
| scripts | round trip HW compress -> HW decompress + perf counters (tests/roundtrip.py) |  | PASS |  | round trip: 842 blocks compressed (pass 1: 0 failures), 747 compressed + 93 raw; 747 decompressed (pass 2: 0 failures) | perf counters vs independent counts: 28/28 exact |
| scripts | reset injection: decoder |  | PASS |  | reset test [decoder]: 40 runs, 96148 records, 47 aborted by reset, 96101 checked, failing runs: 0 |
| scripts | reset injection: encoder |  | PASS |  | reset test [encoder]: 40 runs, 21984 records, 68 aborted by reset, 21916 checked, failing runs: 0 |
| scripts | reset injection: core |  | PASS |  | reset test [core]: 40 runs, 56000 records, 117 aborted by reset, 55883 checked, failing runs: 0 |
