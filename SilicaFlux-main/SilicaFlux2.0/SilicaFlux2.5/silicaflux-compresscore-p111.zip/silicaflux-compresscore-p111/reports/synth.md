# Synthesis estimates (Yosys 0.33, generic technology-independent flow)

**These are not area, frequency or power figures.** No technology library, no place-and-route, no timing closure. SRAMs are replaced by a register-boundary stand-in (reported in bits; they map to compiler macros or block RAM; the stand-in's own flop and XOR tree are subtracted). `gates` = generic 2-input-class gates after ABC; `LUT6` = ABC `-lut 6` mapping count; `levels` = longest topological combinational path in the generic netlist (a relative indicator of logic depth, NOT a timing result).

| module | flops | generic gates | LUT6 (est.) | levels (gates) | levels (LUT6) | SRAM |
|---|---|---|---|---|---|---|
| sf_lz4_pack | 864 | 2,758 | 1126 | 20 | 4 | - (0.0 KiB) |
| sf_compress_crc | 200 | 2,525 | 959 | 77 | 24 | - (0.0 KiB) |
| sf_lz4_history (64 KiB) | 5 | 2,550 | 1669 | 19 | 6 | 2 x 2048 x 128b (history/block buffer 64 KiB) (64.0 KiB) |
| sf_lz4_matchfinder | 342 | 3,287 | 1025 | 41 | 14 | 1 x 4096 x 32b (hash table 16 KiB) (16.0 KiB) |
| sf_lz4_decoder | 2,801 | 22,362 | 8074 | 74 | 18 | 2 x 2048 x 128b (history/block buffer 64 KiB) (64.0 KiB) |
| sf_lz4_encoder | 2,074 | 14,047 | 5315 | 65 | 21 | 2 x 2048 x 128b (history/block buffer 64 KiB), 1 x 4096 x 32b (hash table 16 KiB) (80.0 KiB) |
| sf_compress_stream_adapter | 1,268 | 3,594 | 1688 | 35 | 7 | - (0.0 KiB) |
| sf_compress_perf | 4,377 | 14,177 | 4305 | 34 | 22 | - (0.0 KiB) |
| sf_compress_core | 11,027 | 59,551 | 21360 | 79 | 27 | 2 x 2048 x 128b (history/block buffer 64 KiB), 2 x 2048 x 128b (history/block buffer 64 KiB), 1 x 4096 x 32b (hash table 16 KiB) (144.0 KiB) |

SRAM sizes are derived analytically from the module parameters: decoder history = 2 banks x (HIST_BYTES/32) x 128 b; encoder block buffer = the same for BLK_BYTES, plus the match-finder hash table 2^HASH_BITS x 32 b.
