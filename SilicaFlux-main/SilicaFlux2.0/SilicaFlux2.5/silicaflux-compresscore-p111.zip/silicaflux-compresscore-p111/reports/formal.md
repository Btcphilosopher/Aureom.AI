# Formal verification results

Tools: Yosys 0.33 (built-in SAT for the sequential jobs, `yosys-smtbmc` + Z3 4.8.12 for the exhaustive combinational jobs). SymbiYosys is not packaged for this environment.
'exhaustive' = bit-vector SAT over ALL input values (a proof). 'BMC' = bounded model check from reset to the stated depth (a bounded proof, NOT an unbounded one).

| job | result | depth | time | engine | what |
|---|---|---|---|---|---|
| srcchk_p16_h1024 | PASS | 1 | 0.2s | smt | history-read legality lemma, exhaustive: source bytes written AND not overwritten |
| srcchk_p23_h65536 | PASS | 1 | 0.3s | smt | the same lemma at the DEFAULT decoder widths (23-bit positions, 64 KiB window), exhaustive |
| srcchk_p12_h4096 | PASS | 1 | 0.2s | smt | the same lemma, window == position range |
| fifo_w8_d4 | PASS | 14 | 2.1s | sat | FIFO order / count / full / empty (BMC) |
| fifo_w4_d2 | PASS | 14 | 0.4s | sat | FIFO order / count / full / empty, depth 2 (BMC) |
| pack_dw16_f2 | PASS | 12 | 195.7s | sat | packer, 2-byte beats, FIFO depth 2: byte conservation, dense beats, block ends, tid/side, stall stability (BMC) |
| pack_dw32_f2 | PASS | 10 | 108.2s | sat | packer, 4-byte beats: the same properties (BMC) |
| pack_dw16_f4 | PASS | 10 | 15.0s | sat | packer, FIFO depth 4 (the depth used in the RTL): the same properties (BMC) |
| history_dw32_h64 | PASS | 5 | 155.8s | sat | ring == shadow memory: byte enables, bank straddle, wrap (BMC) |
| history_dw64_h128 | PASS | 4 | 666.0s | sat | ring == shadow memory, 8-byte words (BMC) |
| history_dw16_h64 | PASS | 5 | 20.9s | sat | ring == shadow memory, 2-byte words, 32 words (BMC) |

Not formally verified (simulation, mutation testing and the independent software models only): the decoder parser / copy engine as a whole, the encoder, match finder, stream adapter, CRC stage and performance counters.  The decoder's SRAM-hazard predicate (`sf_lz4_srcchk`) and the history ring are the two places where a subtle off-by-one would corrupt data silently, which is why they are proved rather than only simulated.
