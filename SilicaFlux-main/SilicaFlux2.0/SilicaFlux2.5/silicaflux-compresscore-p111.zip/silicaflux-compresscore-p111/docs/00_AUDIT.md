# 00 — Repository audit (Project 111, CompressCore)

Scope: the SilicaFlux repository (`btcphilosopher/Aureom.AI`, working tree at the time of the task). Method: every module named in the brief was looked for by directory
**and inside every `.zip` member listing** (the repository is mostly archives), the relevant archives were extracted to a scratch directory (the repository itself was not
modified), and READMEs / interface documents / key RTL were read. Nothing from the repository is vendored into this deliverable: the reuse decisions below are about
conventions, interfaces and integration points.

## What exists, what does not

| Brief item | Found? | Where | What it is (read, not assumed) | Decision |
|---|---|---|---|---|
| **StreamDMA** | yes | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-streamdma-p103(-r2).zip` | P103 rev 2: protected scatter-gather DMA, one channel, AXI4-style ready/valid memory port with IDs / bursts / byte strobes, 128-bit default datapath (32..512), reservation-ring data buffer (register-file style), verified against MemoryMatrix P101; Verilator C++ benches, Yosys/Z3 formal, mutation testing, delivered as a ZIP "nothing committed to git" | **Process template** (layout, evidence-level wording, reports, formal/mutation methodology). Not integrated: CompressCore exposes a stream interface; the attachment is in `09_INTEGRATION.md`. |
| **IronMemory** | yes | `…/silicaflux-p84-ironmemory.zip` (and inside P88 / Albion archives) | P84: shared on-chip memory of the Albion processor — 4 single-port SRAM banks, SECDED ECC, buffer manager enforcing ownership, per-bank arbiter for 5 masters, replaceable external-memory adapter, 256-bit wide port from 4 banked lanes, CSRs and counters | **Not used for the history**: the decoder needs a *private* 16-byte-per-cycle unaligned read + byte-write memory with no arbitration latency; IronMemory is the natural place for the *compressed/uncompressed buffers around* the core (`09_INTEGRATION.md`). |
| **StorageFabric** | yes | `…/silicaflux-storagefabric-p68.zip` | P68: storage-request offload for a cloud DPU — queue pairs, validation, scheduler, protected DMA, **end-to-end integrity (CRC-32C protection information, optional XTS-AES-256, optional host CRC)**, pluggable backend (simulated device / P60 STORE / host software / future NVMe) | **Integration target.** Its protection information is CRC-32C, so the CRC stage supports polynomial 0x82F63B78 (`CRC_POLY`). Position in the pipeline discussed in `09_INTEGRATION.md`; not integrated. |
| **DataFabric** | yes | `…/silicaflux-datafabric.zip` (also `SilicaFlux-main/silicaflux-datafabric.zip`) | P03: SFB2 bus (SFB + response back-pressure + DW parameter), crossbar, skid buffers, single-channel DMA, SRAM-library slave adapters; interconnect proofs unbounded, DMA bounded | Integration target (bus-side wrapper in `09_INTEGRATION.md`); not integrated. |
| **PacketForge** | **no module of that name exists** (searched all directories and all archive member names for `packetforge` / `packet_forge`) | — | Closest: **PacketCore P62** (`silicaflux-packetcore-p62.zip`), a programmable network processor with an AXI4-Stream-compatible subset: `keep` all-ones except a contiguous low-order mask on the last beat, `last`, **no SOP signal**, sideband sampled on the first beat, frames exclude FCS | Used as the **stream-convention reference** for `keep`/`last` semantics. CompressCore adds an explicit `first` because blocks (unlike frames) may be empty / back-to-back with partial beats. |
| **Existing compression modules** | **none in RTL** (searched all archive member names for `lz4`, `zstd`, `deflate`, `snappy`, `huffman`, `compress`) | `hypercompress-media.zip` is a media web service (not hardware); `ArcadiumX/…/decompression.py` is game-storage Python; `silicafluxbitcoinasic` "compressor" is the SHA-256 *round function* | unrelated | The decompressor and compressor are **new**. |
| **Buffer management** | partial | P55 BufferCore (NAND/flash buffer manager), IronMemory buffer manager (ownership/descriptors), StreamDMA reservation ring | each is bound to its own protocol (flash pages, ownership descriptors, AXI IDs) | History / block buffers are CompressCore-private SRAMs behind one replaceable wrapper (`sf_lz4_sram_1r1w`). |
| **ECC and integrity modules** | yes | P77 EccMemory (`sf_sram_ecc_ras.sv`, SECDED), P54 ECCCore, MemoryCore `sf_ecc_enc/dec`, `sfd_crc32` (CloudDPU: CRC-32 IEEE, ≤ 4 bytes/cycle, check value 0xCBF43926), `sfsec_crc` (SecureStore; its package uses `return`, which the Yosys 0.33 flow rejects, per P61 notes) | | **CRC**: a new 16-byte/cycle stage supporting both polynomials (the repository's CRC engines are 4 bytes/cycle). **ECC**: not integrated in the history SRAM; the SRAM wrapper is the single place to insert P77's SECDED wrapper (`09_INTEGRATION.md`, `08_LIMITATIONS.md`). |

## Conventions adopted from the repository

`sf_` prefixed modules; asynchronous-assert, active-low `rst_n`; `` `default_nettype none``; definitions in a `.svh` header with macros (no packages: the baseline Yosys 0.33 flow
and Verilator both accept it); `input wire logic` ports; **Verilator `-Wall` clean**; RTL written for Yosys 0.33 (no `int'()` casts — found by actually running Yosys, not assumed);
verification evidence = Verilator C++ benches + independent software model + Yosys/Z3 formal + mutation testing + Yosys synthesis *estimates*, with the evidence level stated in
the README; deliverable as a ZIP, nothing committed.

## Environment used

Verilator 5.020, Icarus Verilog 12.0 (cross-check of syntax only), Yosys 0.33, Z3 4.8.12, `lz4` command-line tool 1.9.4, python-lz4 4.4.5 (LZ4 1.9.4). SymbiYosys is not
packaged for this environment; the same Yosys + `yosys-smtbmc` + Z3 pipeline is driven directly (as the StreamDMA project did). No FPGA, no PDK, no hardware.
