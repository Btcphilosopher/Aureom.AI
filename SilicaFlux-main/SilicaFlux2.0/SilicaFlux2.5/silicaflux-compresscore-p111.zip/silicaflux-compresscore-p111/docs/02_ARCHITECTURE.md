# 02 — Architecture

```
                        +--------------------------- sf_compress_core ---------------------------------------------------------------+
 in_* (128-bit, keep,   |  sf_compress_stream_adapter                                                                                 |
  first/last, tid,  --> |  framing check -> repack (sf_lz4_pack) -> demux by mode                     order queue (blocks in flight)   |
  mode/cap/policy/crc)  |        |                                  |                                       |                         |
                        |        v decompress                       v compress                              v                         |
                        |  sf_lz4_decoder                    [sf_compress_crc]                       in-order output mux  --> out_*   |
                        |   parser FSM -> op queue            CRC of raw data                          (+ keep, first, status, CRC)   |
                        |   -> copy engine (issue, commit)          |                                       ^                         |
                        |   -> sf_lz4_history (2-bank SRAM)         v                                       |                         |
                        |   -> sf_lz4_pack  ----> [sf_compress_crc]/CRC check            sf_lz4_encoder -> sf_lz4_pack ------------+  |
                        |                                           block buffer = sf_lz4_history, sf_lz4_matchfinder (hash SRAM)     |
                        |  sf_compress_perf  (counters, latency tracker, Q16.16 divider)                                              |
                        +-------------------------------------------------------------------------------------------------------------+
```

Clock: one clock, asynchronous-assert active-low reset (`rst_n`). All streams are `valid/ready` with data held while stalled. The top-level `in_ready` is a function of registered state only
(it never depends combinationally on `out_ready`); `out_ready` acts on registered FIFO occupancy.

## Common blocks

* **`sf_lz4_pack`** — the byte-stream packer, used three times (adapter input, decoder output, encoder output). Variable-size chunks (0..16 bytes) in, **dense 16-byte beats** out;
  a completed word is held until the next one completes or the block ends, so a block whose length is a multiple of 16 still ends with a full, `last` beat (never a trailing empty
  beat; an *empty block* produces exactly one beat with 0 bytes and `last`). Output FIFO depth 4; `in_ready` falls only when the word that would have to be pushed does not fit.
  Formally checked (`formal/fv_pack.sv`).
* **`sf_lz4_history`** — the bounded SRAM ring. **Two word-interleaved banks** (even / odd 16-byte words), each a 1R1W SRAM with byte write-enables, so a chunk of ≤ 16 bytes at *any*
  byte position is **written in one cycle** (it spans ≤ 2 consecutive words = one per bank) and 16 bytes at any byte position are **read in one cycle** (both words fetched in
  parallel, funnel-shifted). No bank conflicts between a read and a write, no read-modify-write. A byte stays readable until byte p + `HIST_BYTES` is written, so all offsets
  ≤ `HIST_BYTES`-1 are safe (the LZ4 maximum 65535 with the default 64 KiB). Read data holds until the next read (needed for stalls). Formally checked against a shadow memory
  (`formal/fv_history.sv`). `sf_lz4_sram_1r1w` is the only technology-dependent module (macro / BRAM wrapper).
* **`sf_lz4_fifo`**, **`sf_lz4_srcchk`** (the SRAM-hazard predicate, below), **`sf_compress_crc`** (`04_INTERFACES.md`), **`sf_compress_perf`**.

## Decompressor (`sf_lz4_decoder`)

```
 dense beat -> ib register -> PARSER ---ops---> op queue (4) ---> STAGE 1 (issue) ---> STAGE 2 (commit) ---> sf_lz4_pack ---> out
                                                                     |  ^                   |
                                                       16-byte read  v  | rd_data           v write (byte-enabled), tail register, mpos
                                                                  sf_lz4_history
```

**Parser** (one FSM, ≤ 1 field per cycle, many fast paths): `TOKEN` → `LLEXT` (literal-length extension bytes) → `LIT` (literal bytes, up to 16 per cycle, one op per chunk) →
`OFFLO/OFFHI` (both offset bytes in one cycle when they lie in the same beat) → `MLEXT` → back to `TOKEN`. **Fast path:** when a whole sequence — token, ≤ 13 literals, 2-byte
offset, no extension bytes, non-zero offset — lies inside the current beat, one cycle parses it and pushes a single **`SEQ`** op (literals + offset + match nibble); everything
else (long literals/matches, sequences straddling a beat, any suspicious field) takes the slower path, which is the one that reports errors with exact stream-order semantics.
Every length and offset field is validated; on any error the FSM enters `DRAIN`, consumes the remaining beats of the block (the stream stays framed), then emits `END(status)`.
Ops: `BEGIN{tid,cap}`, `LIT`, `MATCH{offset,length}`, `SEQ`, `END{status, sizes, final literal length}`; the queue decouples parsing from copying (parsing runs ahead of the copy engine,
and a full queue back-pressures the input — `ev_opq_stall`).

**Copy engine, stage 1 (issue)** — per op, ≤ 16 bytes per cycle:

* checks first: capacity (`pos + n ≤ cap` per literal chunk, `pos + length ≤ cap` per match), offset window (`1 ≤ off ≤ pos`, `off < HIST_BYTES`); the first error switches the engine to *discard until END*;
* **literal chunk** → data straight from the op;
* **match, offset ≥ 16** → 16-byte unaligned **history read**. `sf_lz4_srcchk` decides whether the read may be issued *now*: all source bytes must already be committed (`src + n ≤ mpos`,
  `mpos` = bytes already written to the SRAM). Otherwise the engine waits one cycle and counts a **history RAW conflict** (`ev_raw_stall`). Because a chunk takes one cycle to reach the SRAM,
  steady-state matches with offset ≥ 32 never wait; offsets 16..31 wait about one cycle per chunk. `fv_srcchk.sv` **proves exhaustively** that whenever the predicate allows a read, every
  source byte has been written *and* its ring slot has not been overwritten;
* **match, offset < 16 (overlapping copy)** → no SRAM access at all: the last `offset` bytes are held in a **16-byte tail register**; their pattern is replicated into a 32-byte
  register at match start (`rep[k] = pattern[k mod offset]`) and each cycle emits `rep[phase .. phase+15]`, `phase += 16 (mod offset)` — **16 bytes per cycle for any offset 1..15**, with
  repeated output bytes feeding later bytes by construction. The first chunk of such a match waits for the previous chunk to commit (one bubble per match, `ev_pat_bubble`).
* `END`: end-of-block rules (`STRICT_EOB`), status precedence (engine error → parser error → EOB rule → framing), sizes.

**Stage 2 (commit)** — writes the chunk to the history (byte-enabled), updates the tail register and `mpos`, and offers it to the output packer. **A chunk is committed only when the packer
accepts it**, so output back-pressure can never lose or reorder history state (verified under random / bursty / 10 % `out_ready`, including 4 MiB blocks).

**Output** — the packer produces dense 16-byte beats; the last beat of a block carries `out_status`, `out_in_bytes`, `out_out_bytes`.

Latency: the decoder is a 5-stage pipeline (input beat register, parser + op queue, issue, commit, packer hold/FIFO) in front of a data-dependent copy time; end-to-end latencies of single blocks are
measured in `benchmarks/REPORT.md` §E.

## Compressor (`sf_lz4_encoder`, `sf_lz4_matchfinder`) — see `03_ENCODER.md`

## Stream adapter (`sf_compress_stream_adapter`) — see `04_INTERFACES.md`

## Parameters (top level `sf_compress_core`)

| parameter | default | meaning |
|---|---|---|
| `DW` / `TIDW` | 128 / 8 | stream width (fixed at 128 in this revision, checked at elaboration) / transaction-id width |
| `ORDQ_DEPTH` | 4 | blocks in flight (power of two) |
| `CRC_EN`, `CRC_POLY` | 1, `0xEDB88320` | integrity stage; `0x82F63B78` = CRC-32C |
| `PERF_EN` | 1 | performance counters |
| `HIST_BYTES`, `MAX_IN_BYTES`, `MAX_OUT_BYTES`, `STRICT_EOB` | 65536, 4 MiB, 4 MiB, 1 | decoder (`01_FORMAT.md`) |
| `BLK_BYTES`, `HASH_BITS`, `ACCEL`, `SKIP_SHIFT` | 65536, 12, 1, 6 | encoder (`03_ENCODER.md`) |

SRAM at the defaults: decoder history 64 KiB (2 × 2048 × 128 b), encoder block buffer 64 KiB, hash table 16 KiB (4096 × 32 b).
