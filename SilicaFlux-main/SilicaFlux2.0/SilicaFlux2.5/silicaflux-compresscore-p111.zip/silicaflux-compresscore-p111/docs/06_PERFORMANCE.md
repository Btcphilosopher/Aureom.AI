# 06 — Performance (RTL simulation; no clock frequency, area or power is claimed)

Source of every number: `benchmarks/REPORT.md` (regenerate with `make bench`; raw data `benchmarks/results.csv`), measured on `sf_compress_core` with the CRC stage on, read from the core's own performance counters
and cross-checked against the bench (`tests/roundtrip.py` verifies the counters against independent counts). The only unit is **bytes per simulated clock cycle**; the datapath peak is 16 B/cycle in each direction.

## What was measured (the brief's list)

| quantity | where |
|---|---|
| input / output bytes, compression ratio | counters 1, 2, 7, 8, 11, 12 and derived Q16.16 registers 30, 31 (`04_INTERFACES.md` §4); table B |
| bytes per cycle, decompression throughput, compression throughput | table A (decoder), table B (encoder), derived registers 32–35 |
| stall cycles | counters 14, 15 (stream), 18, 19, 23 (internal); table D |
| history-buffer conflicts | counter 16 `hist_raw_conflicts` (+ 17 pattern bubbles); table A |
| end-to-end latency | counters 26–29; table E (idle core) |

## Decompression

| data (64 KiB blocks, python-lz4 default) | ratio | decompressed B/cycle |
|---|---|---|
| text | 1.68 | 4.77 |
| source code | 2.37 | 6.70 |
| mixed (text + random + far copies) | 2.27 | 8.82 |
| random (literals only) | 1.00 | 15.04 |
| zeros / repeating patterns (overlapping matches) | 213–245 | 15.04–15.05 |

(`hc9` blocks: text 5.21, source 6.99, mixed 8.55 B/cycle.)

**What limits it, by regime** (verified by the stall counters and by experiments, not assumed):

* **Short-sequence data (text, source)** is limited by the **parser**: even with the one-cycle `SEQ` fast path a sequence costs ≥ 2 cycles through the copy engine (literal chunk, then match chunk) and the slow paths (long literals,
  sequences that straddle a 16-byte input beat) cost 3–4. Typical text sequences carry ≈ 12 output bytes, hence ≈ 5 B/cycle. The fast path was a measured optimisation: text 2.9 → 4.8 B/cycle (+64 %), source 4.7 → 6.7.
* **Long literal runs and long matches** run at the datapath peak minus a fixed ≈ 5.5 % per 64 KiB block:
  - *Random data*: a 64 KiB literal run carries ≈ 258 length-extension bytes that the parser consumes **one per cycle**: 4113 input beats + ≈ 244 cycles = 4357 cycles/block = 15.04 B/cycle (measured 4357).
    Consuming several 0xFF bytes per cycle is the obvious fix and is **not implemented**.
  - *Zero runs / patterns*: the match-length extension chain (257 bytes) of the *next* block cannot overlap the copy of the current block with the default 4-entry op queue; **`OPQ_DEPTH = 8` removes it: 15.05 → 15.94 B/cycle** (verified in the regression, `decoder [opq8]`) at ≈ 560 more flops.
* **Overlapping matches (offset < 16)** cost nothing per chunk (pattern replication); the first chunk of each waits one cycle for the previous chunk to commit (`pattern bubbles`, 270–1700 per MiB of output).
* **SRAM matches** wait when the source is still in flight: **history RAW conflicts** — 0 for text (offsets are large), 144–192 per MiB on source code, ≈ 8 000 per MiB on the mixed data set (which was built with copies at offsets 1–65535) = ≈ 7 % of its cycles.
  Offsets ≥ 32 never wait at steady state; offsets 16–31 wait about one cycle per chunk.
* **Backpressure** (table D, mixed data): the decoder tracks the consumer almost perfectly — 8.82 B/cycle unthrottled, 8.38 at `out_ready` 75 %, 7.01 at 50 %, 3.99 at 25 % (= 16 B × 0.25), 1.60 at 10 % (= 16 B × 0.1). A starved input
  hurts little until it is the bottleneck (8.71 at `in_valid` 75 %, 7.02 at 25 %). Output backpressure never loses history state (4 MiB blocks under 10 % `out_ready` pass byte-exact).

Latency of a single block alone in an idle core (table E): **31 cycles for a 256 B block, 173 for 1 KiB, 803 for 4 KiB, 13.7 k for 64 KiB** (text); random data 29 / 80 / 285 / 4365.

## Compression

| data (64 KiB blocks, STREAM) | HW ratio | reference `lz4` default | `fast=9` | `hc9` | input B/cycle |
|---|---|---|---|---|---|
| text | 1.57 | 1.68 | 1.24 | 2.04 | 0.31 |
| source code | 2.28 | 2.37 | 1.71 | 2.93 | 0.46 |
| mixed | 2.23 | 2.27 | 1.72 | 2.54 | 0.57 |
| random | 1.00 | 1.00 | 1.00 | 1.00 | 3.33 |
| zeros / patterns | 213–245 | same | 140–245 | same | 5.3 |

* **Ratio**: within 2–7 % of the reference's default compressor on text-like data and always better than its `fast=9`; the same on runs. It does not reach the reference's HC levels (not implemented).
* **Throughput is the weak spot** and is documented as such: the scan is a sequential FSM (≈ 4 cycles per probed position, 6 with a verified candidate), so text-like data compresses at 0.3–0.6 B/cycle. Incompressible data scans fast
  (skip acceleration: 3.3 B/cycle) and long matches extend at ≈ 5 B/cycle. The compress side of table E is accordingly slow: ≈ 1000 cycles for 256 B of text, 14.6 k for 4 KiB, 212 k for 64 KiB.
* **Policies** cost a second (dry-run) pass: `ERROR` / `RAW` halve the throughput on compressible data (0.16 vs 0.30 B/cycle on text) but fail fast on incompressible data (the dry run stops as soon as the size exceeds the limit).
* **Level / area trade-off** (table C, one corpus): `HASH_BITS` 10 → 12 → 14 (4 / 16 / 64 KiB table): text ratio 1.39 → 1.57 → 1.63; `ACCEL` 1 → 8 trades ratio 1.57 → 1.21 (text) for 1.8× the throughput (0.31 → 0.56 B/cycle), mixed data 2.5× (0.57 → 1.45).
* After reset a compress block waits for the 4096-cycle hash-table sweep once (and once more every 255 passes).

## Honest summary

The **decompressor** is the strong half: at or near the 16 B/cycle datapath peak on literal- and match-dominated data (with `OPQ_DEPTH = 8`), ≈ 5–9 B/cycle on typical text/source/mixed data, graceful under backpressure, 31-cycle latency for small blocks.
The **compressor** is a correct, interoperable baseline whose throughput on compressible data is its main weakness (documented, with the improvement path in `03_ENCODER.md`).
To convert to bandwidth multiply by an achievable clock — which is unknown: no timing closure exists (`07_SYNTHESIS.md`).
