# 04 — Interfaces

## 1. Stream protocol (input and output)

128-bit data, `valid/ready` handshake (a transfer happens on `valid && ready`), **backpressure on both sides**. Once `valid` is asserted the payload and sideband are held until
accepted (checked by the bench monitors on the output; the producer must obey it on the input). Byte *k* of a beat is `data[8k+7:8k]`; byte 0 of a block is `data[7:0]` of its first beat.

### Input (`in_*`)

| signal | meaning |
|---|---|
| `in_data[127:0]`, `in_keep[15:0]` | data and byte-valid mask. `keep` must be a **contiguous mask from lane 0** (`2^n − 1`, n = 0..16). Beats may be partial anywhere inside a block; they are repacked. `keep = 0` is legal (no bytes; typically the last beat of a block whose data ended on a beat boundary). Bytes under `keep = 0` are never used (the bench drives random garbage there). |
| `in_first`, `in_last` | block start / end. A block is `in_first … in_last` (a single beat can be both). |
| `in_tid[7:0]` | transaction id, returned unchanged on every output beat of the block. |
| `in_mode` | **descriptor, sampled with the first beat**: 0 = decompress, 1 = compress. |
| `in_cap[31:0]` | decompress: maximum decompressed size (0 = `MAX_OUT_BYTES`); compress: bytes available at the destination (0 = unlimited). |
| `in_policy[1:0]` | compress: 0 `STREAM`, 1 `ERROR`, 2 `RAW` (`03_ENCODER.md`); 3 reserved (= `STREAM`). |
| `in_crc_en` | report the CRC-32 of the **uncompressed** data (`out_crc`, `out_crc_valid`). |
| `in_crc_chk`, `in_crc_exp[31:0]` | decompress: compare the CRC of the decompressed data with `in_crc_exp`; mismatch ⇒ status `CRC`. |

Descriptor fields are sampled **with the first beat** (any value on later beats is ignored). Blocks of both modes may be interleaved freely.

### Output (`out_*`)

| signal | valid | meaning |
|---|---|---|
| `out_data[127:0]`, `out_keep[15:0]` | every beat | dense beats: **every beat is full (`keep` = 0xFFFF) except the last of a block**, whose `keep` is a contiguous mask of the remaining 1..16 bytes. A block with no output bytes (empty block, or an error before any output) produces exactly **one beat with `keep = 0` and `out_last`**; an empty beat never follows data. |
| `out_first`, `out_last` | every beat | block start (first beat after a `last`) / block completion. |
| `out_tid`, `out_mode` | every beat | the block's id and kind. |
| `out_raw` | every beat | compress only: the block is the input copied unchanged (`RAW` policy fallback). |
| `out_status[3:0]` | with `out_last` | 0 = OK, otherwise `01_FORMAT.md` codes. **If non-zero, the data beats of that block are invalid and must be discarded.** |
| `out_in_bytes`, `out_out_bytes` | with `out_last` | bytes of the block received / bytes emitted in its data beats (decompress: decompressed size; compress: compressed size, 0 for `INCOMPRESSIBLE`). |
| `out_crc`, `out_crc_valid` | `out_crc` with `out_last`; `out_crc_valid` every beat | CRC of the uncompressed data (decompress: of the output; compress: of the input); `out_crc_valid` = `in_crc_en` of the block (and the stage is built in). |

**Ordering**: blocks come back in the order their first beats were accepted. At most `ORDQ_DEPTH` (4) blocks are in flight; a fifth block's first beat waits.
**Output stability**: while `out_valid && !out_ready` every output signal is held.

### Framing policy (adapter)

A violation never hangs the stream and never corrupts the next block; the block completes with `FRAMING` (unless an engine error was found first): a block's first beat without `in_first`; `in_first` on a beat inside a block;
a non-contiguous `keep` (only the number of valid lanes is used). A producer that never sends `in_last` stalls the stream (there is no timeout). Verified by fault injection (`core_mix`: 7 % of records).

### Reset

Asynchronous-assert, active-low `rst_n`; synchronous release. Reset discards every block in flight (an output block in progress is cut **without** `out_last`, like PacketCore: the receiver must be reset with the core). The history,
block-buffer and hash-table contents need no initialisation (the match finder clears its table by itself after reset; `PASS` commands wait for it). Verified with resets at random cycles during decode, encode and mixed streams.

## 2. Engine-level interfaces (when `sf_lz4_decoder` / `sf_lz4_encoder` are used directly)

Dense beats with a byte count instead of `keep`: `in_n[4:0]` = valid bytes (16 for every beat except the last of a block, 1..16 or 0), `in_first`, `in_last`, `in_tid`, `in_cap`, `in_ferr` (upstream framing error flagged with `in_last`);
encoder additionally `in_policy[1:0]` and `in_crc[31:0]` (raw-data CRC, valid with `in_last`, returned in `out_crc`). Outputs: `out_n[4:0]`, `out_last`, `out_tid`, `out_status`, `out_in_bytes`, `out_out_bytes`; encoder also `out_raw`, `out_crc`.
Event pulses for the performance counters: decoder `ev_raw_stall`, `ev_pat_bubble`, `ev_out_stall`, `ev_opq_stall`, `ev_hist_rd`, `ev_hist_wr`, `busy`; encoder `ev_probe`, `ev_hit`, `ev_ext_cycle`, `ev_out_stall`, `ev_dry_pass`, `busy`.

## 3. Integrity stage (`sf_compress_crc`)

A one-entry register slice with a CRC engine; the data are passed through **unchanged** (so compression/decompression results are identical with the stage present or absent). Reflected CRC, init and final XOR `0xFFFFFFFF`:
`POLY = 0xEDB88320` → CRC-32 (IEEE 802.3 / zlib; `"123456789"` → `0xCBF43926`), `POLY = 0x82F63B78` → CRC-32C (Castagnoli, the StorageFabric protection-information polynomial; `"123456789"` → `0xE3069283`).
It sits **in front of the encoder** (CRC of the raw input, carried with the completion) and **behind the decoder** (CRC of the decompressed data, compared with `in_crc_exp` when `in_crc_chk` is set), so both directions report the CRC of the same uncompressed bytes.
Verified against zlib's CRC-32 and an independent CRC-32C over thousands of blocks, including deliberately wrong expected CRCs. It is an integrity **check**, not authentication.

## 4. Performance counters (`sf_compress_perf`)

`perf_clear` zeroes, `perf_snap` latches a coherent snapshot and starts the serial divider (≈ 340 cycles; `perf_rd_busy` is high meanwhile), `perf_rd_sel` / `perf_rd_data` read register *n* of the snapshot (64-bit).
Counts are in clock cycles / bytes; "bytes" are uncompressed bytes except where marked.

| # | register | # | register |
|---|---|---|---|
| 0 | cycles | 18 | dec_out_stall_cycles (commit stalled by output back-pressure) |
| 1 | in_bytes (external input) | 19 | dec_opq_stall_cycles (parser stalled by a full op queue) |
| 2 | out_bytes (external output) | 20 | enc_probes |
| 3 / 4 / 5 | blocks_in / blocks_out / blocks_err | 21 | enc_hits (verified matches) |
| 6 | dec_blocks | 22 | enc_ext_cycles |
| 7 / 8 | dec_in_bytes (compressed) / dec_out_bytes | 23 | enc_out_stall_cycles |
| 9 | dec_busy_cycles | 24 | enc_dry_cycles (dry-run sizing passes) |
| 10 | enc_blocks | 25 | frame_errors |
| 11 / 12 | enc_in_bytes / enc_out_bytes (compressed) | 26 / 27 | lat_last / lat_max (cycles, first input beat accepted → last output beat accepted) |
| 13 | enc_busy_cycles | 28 / 29 | lat_sum / lat_count |
| 14 / 15 | in_stall_cycles / out_stall_cycles (`valid && !ready`) | 30 | comp_ratio = enc_in / enc_out (Q16.16) |
| 16 | **hist_raw_conflicts** (match source not yet visible in the history SRAM) | 31 | dec_ratio = dec_out / dec_in (Q16.16) |
| 17 | dec_pat_bubbles | 32 / 33 | dec / enc bytes per busy cycle (Q16.16) |
|    |    | 34 / 35 | in / out bytes per elapsed cycle (Q16.16) |

Derived registers are 0 when the denominator is 0. Compression ratio, bytes per cycle, throughput (bytes / busy cycles), stalls, history conflicts and end-to-end latency — the quantities listed in the brief — are all here; the
performance counters are **verified against independent counts** (`tests/roundtrip.py`: 28 exact comparisons including the divider results and latency statistics).
