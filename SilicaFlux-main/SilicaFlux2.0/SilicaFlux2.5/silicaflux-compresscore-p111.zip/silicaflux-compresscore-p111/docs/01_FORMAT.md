# 01 — Format and decode contract

CompressCore implements the **LZ4 block format** (`lz4_Block_format.md` of the LZ4 project). It does not define or substitute any other format and invents no block marker.
What a block *is* here, and what the hardware promises for every possible input, is fixed by `tools/lz4model.py` — a model written from the specification, validated against
the trusted software LZ4 (below), and used as the oracle for every simulation.

## The format as implemented

A block is a sequence of *sequences*. Each sequence:

```
token (1 byte):  [7:4] literal length L    [3:0] match length M-4
[L = 15: extension bytes, each adds its value, 255 = "more", the first byte < 255 ends]
L literal bytes
offset (2 bytes, little endian, 1 .. 65535)          \  absent in the LAST sequence
[M-4 = 15: extension bytes, same rule]                /
```

* **Match length** = nibble + 4 (+ extension). **Offset** 1 means "repeat the previous byte"; offsets smaller than the length make the copy **overlap** — repeated output
  bytes become the source of later bytes (`a` + offset 1, length 8 → `aaaaaaaaa`). Hardware: pattern replication for offsets 1..15, SRAM reads for offsets ≥ 16
  (`02_ARCHITECTURE.md`).
* **Last sequence**: literals only, ends the block. An empty block is the single byte `0x00`.
* **End-of-block rules** (spec): the **last 5 bytes** of a block are literals; the **last match starts at least 12 bytes before the end**. Blocks shorter than 13 bytes
  are therefore literal-only. The encoder obeys both; the decoder enforces both (`STRICT_EOB = 1`, default) relative to the actual decoded size.
* **Independent blocks, no dictionary**: a match may only reference bytes of the same block. (LZ4 *frames* with linked blocks need a dictionary across blocks; out of scope,
  `08_LIMITATIONS.md`. Frame headers/checksums are the surrounding container's job — `tools/lz4frame.py` builds frames only for the tests.)

## What the decoder guarantees for ANY input

Errors are resolved **in stream order** (byte granular); the first error wins; the rest of the block is consumed so the stream stays framed; the block completes with a status
(`rtl/sf_compress_defs.svh`). **Output of a block that completes with an error is invalid and must be discarded** — the decoder streams while it decodes, it does not buffer
the whole block (the consumer or the surrounding DMA commit/abort provides atomicity).

| status | meaning |
|---|---|
| 0 `OK` | block decoded; output valid |
| 1 `TRUNCATED` | the block ended inside a sequence (token, length extension, literals, offset), after a match with no final literal-only sequence, or is empty |
| 2 `OFFSET_ZERO` | offset 0 (invalid in the format) |
| 3 `OFFSET_RANGE` | offset larger than the bytes produced so far in this block, or ≥ the history window (`HIST_BYTES`, default 65536 ⇒ every legal offset) |
| 4 `OUT_OVERFLOW` | the decompressed size would exceed the capacity given for the block (`in_cap`, 0 = `MAX_OUT_BYTES` = 4 MiB). **Nothing beyond the capacity is ever written or emitted.** |
| 5 `LENGTH` | a literal/match length does not fit the 24-bit length counter (a run of > ~65 000 consecutive 0xFF extension bytes) |
| 6 `BLOCK_SIZE` | compressed block larger than `MAX_IN_BYTES` (4 MiB) (encoder: input larger than `BLK_BYTES`) |
| 7 `EOB_RULE` | last-5-literals / last-match-12-from-end violated |
| 8 `FRAMING` | stream protocol violation on the input (`04_INTERFACES.md`) |
| 9 `INCOMPRESSIBLE`, 10 `DST_OVERFLOW` | encoder policies (`03_ENCODER.md`) |
| 11 `CRC` | CRC of the decompressed data differs from the expected CRC supplied with the block |

Error precedence inside one block is the order the bytes appear: a truncated literal run is `TRUNCATED` unless the capacity is exhausted *before* the missing byte (then
`OUT_OVERFLOW`); an offset of 0 is reported before any match-length extension bytes are examined; the copy engine's range check precedes its capacity check. The model
implements exactly this; the hardware is compared against it for every vector.

**Unbounded output is impossible**: every literal chunk and every match is checked against the capacity before it is issued; a 255:1 "decompression bomb" against a small
capacity is rejected after the first match (test `expand_bomb_cap1000`); the hard ceiling is `MAX_OUT_BYTES` even when the capacity field is 0.

## How the contract relates to the trusted software LZ4

Measured, not assumed (`tools/check_model.py` → `reports/model_check.md`: 915 valid library blocks + 42 984 truncated / mutated blocks compared):

1. **Valid blocks** produced by python-lz4 (default, fast, high-compression levels) and by the `lz4` command-line tool decode to identical bytes.
2. **End-of-block rules are enforced by the reference library relative to the buffer capacity it is given**, not the true decoded size: with a too-large buffer it accepts
   blocks that violate the rules. The hardware only knows the actual end, so `STRICT_EOB` checks against the actual size; the two coincide exactly when the capacity equals the
   true decoded size (the normal container case), and the hardware is stricter otherwise. `STRICT_EOB = 0` is the permissive profile (verified separately, `decp_*` suites).
3. **Offset 0**: the library *does not reject it* (it copies from the not-yet-written output position, i.e. indeterminate bytes). The block-format specification defines offset 0
   as invalid; the hardware rejects it (status 2). This is the one deliberate deviation from the library, found by probing it directly.

## Hardware profile (parameters of `sf_lz4_decoder`)

| parameter | default | meaning |
|---|---|---|
| `HIST_BYTES` | 65536 | history window / ring size (power of two ≥ 64): supported offsets 1 .. `HIST_BYTES`-1 |
| `MAX_IN_BYTES` | 4 MiB | largest compressed block |
| `MAX_OUT_BYTES` | 4 MiB | largest decompressed block (also the hard output bound) |
| `STRICT_EOB` | 1 | enforce the end-of-block rules |
