# 09 — Integration notes (design guidance; **nothing here is implemented or verified in the repository's other projects**)

CompressCore is a stream block engine: bytes in, bytes out, a completion status per block. The points below say where it plugs in and what each neighbour must provide. Every item marked *(open)* is a gap, not a solved problem.

## Software / container contract

* The core processes **LZ4 blocks**. Whoever owns the container (an LZ4 *frame*, a storage format, a network encapsulation) stores `out_out_bytes`, the `out_raw` flag and, if used, the CRC alongside the data. An LZ4 frame represents `out_raw` as an
  *uncompressed block* (block-size word, bit 31); the core's compressed blocks are standard LZ4 blocks that any LZ4 decoder accepts (`reports/interop_encoder.md`, `vectors/golden/hw/verify_with_lz4.sh`).
* Choose the block size per use: ≥ 64 KiB blocks give the best ratio and amortise the per-block overhead; 4 KiB storage blocks are supported (latencies in `benchmarks/REPORT.md` §E).
* Always give a capacity (`in_cap`): for decompression it bounds the output (a corrupt block cannot expand beyond it); for compression it is the destination size and selects the overflow behaviour (policy).

## StreamDMA (P103)

* Place the core between the DMA's *read data* path and its *write data* path (or between two DMA channels). The DMA's byte strobes are not low-aligned: run them through the DMA's realigner so beats satisfy `keep = 2^n − 1`; the core repacks
  partial beats itself.
* **Fixed-length descriptors vs variable output length** *(open)*: StreamDMA rev 2 validates a descriptor's byte count up front and has no rollback. Compression changes the length, so the write side needs either (a) a staging buffer and a second
  descriptor carrying `out_out_bytes`, or (b) the `ERROR` / `RAW` policies, which fix the output size before the first data beat. Decompression writes `≤ in_cap` bytes into a scratch destination; on `out_status ≠ 0` the destination must be treated as
  garbage (no rollback in the DMA) — software must not publish it.
* `in_tid` ↔ the DMA transaction id; `out_status` ↔ the completion status.

## IronMemory (P84)

* Use IronMemory buffers as the *source / destination staging* of the stream (its buffer manager enforces ownership). The core's own SRAMs are private and not behind IronMemory (they need 16 bytes/cycle unaligned access with no arbitration).
* If the history must be ECC protected, the SECDED codec from P84/P77 applies, but see the partial-write issue in `08_LIMITATIONS.md` *(open)*.

## StorageFabric (P68)

* Natural position: **compress → protect → encrypt**, i.e. before the CRC-32C protection information and before XTS-AES (encrypted data does not compress). `CRC_POLY = 0x82F63B78` gives CRC-32C of the *uncompressed* data so the read path can
  check end to end (`in_crc_chk`) after decompression, independently of the PI computed over what is stored.
* Store `out_raw` and `out_out_bytes` in the per-block metadata; use `RAW` policy so incompressible blocks cost one copy and no expansion. Block size must be a multiple of the LBA size *(open: FTL mapping of variable-length blocks)*.

## DataFabric (P03) and PacketCore (P62)

* DataFabric: a thin SFB2 master/slave wrapper that maps bus bursts to `in_*` / `out_*` beats and exposes the performance registers (`perf_rd_sel` / `perf_rd_data`) as CSRs *(not written)*.
* PacketCore uses `keep` / `last` with no SOP and a sideband sampled on the first beat — close to this stream. Compressing a frame payload: `first` = first beat after `last`; carry the frame's metadata separately.
  Network frames are small (≤ 9 KiB): use `RAW` for already compressed payloads. *(PacketForge does not exist in the repository.)*

## Physical integration

* Replace `sf_lz4_sram_1r1w` with the target SRAM compiler macro or block RAM wrapper: 1R1W, 128-bit, byte write-enables, synchronous read with hold. Sizes at the defaults: 2 × 2048 × 128 b (decoder history), 2 × 2048 × 128 b (encoder block buffer),
  4096 × 32 b (hash table); smaller windows / tables are parameters (`HIST_BYTES`, `BLK_BYTES`, `HASH_BITS`).
* One clock, active-low asynchronous reset: bridge with the repository's `sf_reset_sync` (P40). Reset the core and its consumers together (an output block in progress is cut without `out_last`).
* Frequency is unknown: the longest generic-gate path is in `reports/synth.md` (relative indicator only). Add pipeline registers on the stream boundaries if the target frequency needs them — all streams are `valid/ready`.
