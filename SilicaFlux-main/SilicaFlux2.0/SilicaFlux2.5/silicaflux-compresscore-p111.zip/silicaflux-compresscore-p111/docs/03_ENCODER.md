# 03 — Compressor

The compressor is a **baseline**: correct, interoperable, area-modest, with the trade-offs below. It is built *after* the decoder was verified against externally produced blocks
(`reports/regression.md`, `reports/interop_encoder.md`).

## Flow of one block

1. **INGEST** — dense 16-byte beats are written to the **block buffer** (`sf_lz4_history`, `BLK_BYTES`, default 64 KiB). Input larger than `BLK_BYTES` is drained and the block completes with `BLOCK_SIZE`.
   One block at a time: ingest of the next block starts after the previous block's completion item has been handed to the output packer.
2. **PLAN** — according to the block's policy (below): one *emit* pass, or a *dry-run* pass first.
3. **SCAN** — greedy parse, the reference LZ4 structure: at position `pos` look up the 4 bytes at `pos`, insert `pos`, and if a verified candidate exists, extend it and emit a sequence; otherwise advance by
   `step = ACCEL + (misses >> SKIP_SHIFT)` (the reference's skip acceleration: step grows by one every 2^`SKIP_SHIFT` consecutive misses, so incompressible data is scanned quickly).
   After a match, the position two bytes before its end is also inserted (as the reference does). A match may only **start** ≥ 12 bytes before the end and never reaches into the last 5 bytes.
4. **EMIT** — token, literal-length extension, literals (read back from the block buffer, 16 bytes per cycle), 2-byte offset, match-length extension; the last sequence is literal-only.
   Blocks < 13 bytes are one literal sequence; an empty block is `0x00`. Chunks go through `sf_lz4_pack` (dense output beats).

## Match finder (`sf_lz4_matchfinder`)

One command at a time: `PASS` (new pass), `PROBE`, `EXTEND`, `INSERT`. Hash table of 2^`HASH_BITS` entries × 32 bit `{epoch[7:0], tag[7:0], pos[15:0]}`; hash = (4 bytes × 0x9E3779B1) ≫ (32 − `HASH_BITS`).
A candidate needs: current epoch, equal 8-bit tag, smaller position, and is then **verified against the block bytes** (4 bytes read from the buffer) — so correctness never depends on table
contents: a stale or corrupt entry can only cost time. `EXTEND` compares 16 bytes per iteration (2 cycles per iteration), bounded by `block length − 5`.

**Reset-to-ready**: the hash table SRAM is not reset, so after reset the match finder sweeps all 2^`HASH_BITS` entries (4096 cycles at the default) before it accepts its first command; a compress block that arrives earlier is ingested meanwhile and its scan starts after the sweep (decompression is not affected). The sweep repeats once per 255 passes when the epoch wraps.

**Epochs** are what make the two-pass policies exact: `PASS` increments an 8-bit epoch; entries of older passes are invalid; the table is physically cleared only after reset and once per 255 passes. The
dry-run pass and the emit pass of the same block therefore see an identical (empty) table and take identical decisions — the dry-run size is the exact emitted size. The model
(`tools/encmodel.py`) reproduces the hardware **byte for byte**; the regression compares exactly, and independently decodes every block with the trusted software LZ4.

## Policy when the output would not fit (brief §7)

Per block, from `in_policy`, with `in_cap` = bytes available at the destination (0 = unlimited):

| policy | passes | behaviour |
|---|---|---|
| `STREAM` (0) | 1 | The compressed size is not known in advance. **Emission never exceeds the capacity**: when the next chunk would, emission stops and the block completes with `DST_OVERFLOW`; the ≤ `cap` bytes already emitted are invalid. |
| `ERROR` (1) | 2 | A dry-run pass computes the exact compressed size **without emitting anything**. If it exceeds the capacity the block completes with `INCOMPRESSIBLE` and **no data beat was emitted — the destination is untouched** ("error before overwriting the destination"). |
| `RAW` (2) | 2 | As `ERROR`, but if the compressed block would not fit **or would not be smaller than the input**, and the input fits the capacity, the **input is emitted unchanged** with `out_raw = 1` on every beat. An LZ4 *frame* carries exactly this as an *uncompressed block* (block-size word with bit 31 set); `tools/lz4frame.py` builds such frames and the real `lz4 -d` tool decodes them (`reports/interop_encoder.md`). If even the raw input does not fit: `INCOMPRESSIBLE`. |

No incompatible LZ4 block marker is invented: a compressed block is always a standard LZ4 block; raw data is flagged by the sideband and by the *container's* uncompressed-block bit. The dry-run stops as soon
as the running size exceeds the acceptable limit (`cap`, and for `RAW` also `input size − 1`), so incompressible data fails fast. Policy value 3 is reserved and behaves as `STREAM`. With `RAW`, an empty
input is emitted as 0 raw bytes (a compressed empty block would be 1 byte, never smaller).

## Compression level / area trade-off (documented, measured in `benchmarks/REPORT.md` §C)

| knob | effect |
|---|---|
| `HASH_BITS` (default 12: 4096 entries = 16 KiB) | more entries → fewer collisions → better ratio, more SRAM |
| `ACCEL` (default 1), `SKIP_SHIFT` (default 6) | larger `ACCEL` / smaller `SKIP_SHIFT` scan faster and compress less (reference-LZ4 semantics) |
| `BLK_BYTES` (default 64 KiB = the LZ4 frame minimum block size and the 16-bit offset range) | block buffer size; must be ≤ 65536 |

Compared with the reference library on the same block: ratio is within a few percent of `LZ4_compress_default` on text/source/mixed data (it lacks the reference's backward match extension and
multi-candidate refinement) and better than the reference's `fast=9`; it is a **baseline** — high-compression (HC) modes and lazy matching are not implemented.

## What limits throughput (baseline, by design)

The scan is a **sequential FSM**: ≈ 4 cycles per probed position (issue → read 4 bytes → table read → response) and 2 more when the tag hits and the candidate is verified; matches extend at 8 bytes/cycle
(2 cycles per 16 bytes); literals are copied at 16 bytes/cycle. Consequences (measured): incompressible data is fast (skip acceleration: ≈ 3.3 B/cycle), long matches ≈ 5 B/cycle, text-like data is slow
(≈ 0.3 B/cycle). The documented path to higher throughput is a pipelined probe (hash/table read of position p+1 overlapped with verification of p) and a sliding window register instead of re-reading the
buffer; it is not implemented in this revision (`08_LIMITATIONS.md`).
