# 07 — Synthesis estimates

**These are estimates from a technology-independent flow. They are not area (µm²), frequency or power figures.** There is no technology library, no place-and-route, no timing constraint and no timing closure anywhere in this deliverable.

## Method (`scripts/synth_report.py`, `make synth`)

Yosys 0.33: `read_verilog -sv` (all RTL, with the SRAM wrapper `sf_lz4_sram_1r1w` replaced by a **register-boundary stand-in**), `hierarchy -check`, `synth -flatten`, `opt_clean -purge`, then `stat` and `ltp -noff`; a second run maps with `abc -lut 6`.

* **flops** — all `$_DFF*` cells; **generic gates** — all other generic cells after ABC; **LUT6 (est.)** — ABC `-lut 6` mapping count (FPGA-style estimate of the combinational logic).
* **levels** — the longest topological combinational path in the netlist (gates, and LUT6s in the mapped run). A relative indicator of logic depth and a hint at where the critical paths will be; **it is not a timing result** (no wire, no cell delay; the generic flow uses Yosys' `abc -fast`).
* **SRAM** — derived analytically from the module parameters. SRAMs map to compiler macros / block RAM, not to logic; their area/timing is the macro's.
* **The stand-in** (found necessary, not assumed): a plain black box was tried first and **rejected** — Yosys' `ltp` treats a black box as combinational pass-through, so the read-data → write-data feedback through the commit stage
  was unrolled into an artificial path of ≈ 1500 levels (decoder) that does not exist in hardware (the real macro has a synchronous read register). The stand-in launches every read-data bit from its own flop and feeds every input into those flops (so the
  read-funnel logic is neither collapsed nor orphaned); its own flops and XOR gates (DW flops and DW + k − 1 gates per instance) are **subtracted** from the reported figures. A first stand-in with a *single* flop was also rejected: identical read-data bits let Yosys collapse the funnel logic.

## Results (`reports/synth.md`)

| module | flops | generic gates | LUT6 (est.) | levels (gates) | levels (LUT6) | SRAM |
|---|---|---|---|---|---|---|
| sf_lz4_pack | 864 | 2,758 | 1126 | 20 | 4 | - (0.0 KiB) |
| sf_compress_crc | 200 | 2,525 | 959 | 77 | 24 | - (0.0 KiB) |
| sf_lz4_history (64 KiB) | 5 | 2,550 | 1669 | 19 | 6 | 2 x 2048 x 128b (history/block buffer 64 KiB) (64.0 KiB) |
| sf_lz4_matchfinder | 342 | 3,287 | 1025 | 41 | 14 | 1 x 4096 x 32b (hash table 16 KiB) (16.0 KiB) |
| sf_lz4_decoder | 2,801 | 22,362 | 8074 | 74 | 18 | 2 x 2048 x 128b (history/block buffer 64 KiB) (64.0 KiB) |
| sf_lz4_encoder | 2,074 | 14,047 | 5315 | 65 | 21 | 2 x 2048 x 128b (history/block buffer 64 KiB), 1 x 4096 x 32b (hash table 16 KiB) (80.0 KiB) |
| sf_compress_stream_adapter | 1,268 | 3,594 | 1688 | 35 | 7 | - (0.0 KiB) |
| sf_compress_perf | 4,377 | 14,177 | 4305 | 34 | 22 | - (0.0 KiB) |
| sf_compress_core | 11,027 | 59,551 | 21360 | 79 | 27 | 2 x 2048 x 128b (history/block buffer 64 KiB), 2 x 2048 x 128b (history/block buffer 64 KiB), 1 x 4096 x 32b (hash table 16 KiB) (144.0 KiB) |

## Reading the numbers

* **Where the flops are** (core 11 027): the **performance counters are 4 377 of them (40 %)** — 30 × 64-bit counters, the same again as the coherent snapshot, the divider and latency tracker; `PERF_EN = 0` removes all of it. The rest: decoder 2 801
  (including its output packer 864), encoder 2 074 (including its packer), stream adapter 1 268 (input packer + order queue), the two CRC stages 200 each, match finder 342.
* **Where the logic is** (core ≈ 59 600 generic gates, ≈ 21 400 LUT6): decoder 22 400, encoder 14 000, counters 14 200, adapter 3 600, CRC stage 2 500 (each of the two), history ring 2 550, match finder 3 300, packer 2 800 (each of three).
  The LUT6 counts include the stand-ins' XOR trees (≈ 730 gates ≈ 0.7 % of the core). Per-signal attribution inside a module was not analysed.
* **SRAM dominates the storage**: 144 KiB at the defaults — decoder history 64 KiB, encoder block buffer 64 KiB, hash table 16 KiB (`HIST_BYTES`, `BLK_BYTES`, `HASH_BITS` scale it: a 4 KiB window and a 4 KiB block would need 4 KiB + 4 KiB plus the hash table).
* **Logic depth (relative indicator, `abc -fast`, not timing):** decoder 74 gate levels (18 LUT6), encoder 65 (21), core 79 (27); the CRC stage (a 16-byte serial CRC function) is the deepest small block at 77 (24); packer 20, history ring 19,
  match finder 41, adapter 35, counters 34. Which paths are the deepest was **not analysed further**; they are the first candidates for an extra pipeline register if a target clock needs one (all streams are `valid/ready`).
* A cautionary note on the first attempt (kept because it is instructive): with the SRAM as a plain black box the *same* tool reported **1 517 / 449 / 1 409** levels for decoder / encoder / core; that was an artefact of the method (see Method), not a property of the design.

## What a real implementation estimate would still need

A technology library and SRAM macros (1R1W, 128-bit, byte write-enables, or the bank scheme of `sf_lz4_sram_1r1w`), timing constraints, place-and-route, clock-tree and power analysis, DFT insertion, and — for ECC — a decision about the
partial-word writes of the history (`08_LIMITATIONS.md`). The longest generic-gate paths above are the first places to look for pipeline registers (all streams are `valid/ready`, so extra stages are straightforward).
