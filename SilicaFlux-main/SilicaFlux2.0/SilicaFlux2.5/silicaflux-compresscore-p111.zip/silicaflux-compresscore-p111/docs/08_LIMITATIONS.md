# 08 — Limitations (read this before relying on anything)

## Evidence level

RTL **simulation** (Verilator, 2-state, randomised initial state) against independent software models and the trusted software LZ4; **formal** proofs on the packer, history ring, FIFO and the SRAM-hazard predicate
(bounded except the exhaustive combinational lemma); **mutation testing**; **Yosys synthesis estimates**. There is **no FPGA run, no silicon, no technology library, no place-and-route, no timing closure, no
power estimate**: no frequency, area (µm²) or power figure is claimed anywhere. Cycle counts are simulated clock cycles.

## Format scope

* LZ4 **block** format, **independent blocks**, no dictionary: LZ4 frames with *linked* blocks (which need history across blocks) are not decodable block by block. The frame container (magic, descriptor, block sizes,
  checksums, end mark) is the caller's job; `tools/lz4frame.py` builds frames for tests only. No LZ4_HC-style compressor, no legacy format, no other algorithm.
* **Offset 0 is rejected**, although the reference library accepts it (indeterminate output). **End-of-block rules are checked against the actual decoded size**; the library checks them against the buffer capacity it is
  given, so the hardware is stricter than the library whenever capacity > true size. `STRICT_EOB = 0` removes the check (`01_FORMAT.md`).
* Limits: decompressed block ≤ 4 MiB (`MAX_OUT_BYTES`), compressed block ≤ 4 MiB (`MAX_IN_BYTES`), offsets ≤ `HIST_BYTES − 1` (65535 by default), compressor input ≤ `BLK_BYTES` (64 KiB). 128-bit stream width only (`DW` is fixed and checked).

## Decompressor

* **Output of a block that completes with an error is invalid and was already streamed** (the decoder streams while decoding; it does not hold a whole block back). Atomicity — discarding the written bytes — is the consumer's/DMA's job
  (`09_INTEGRATION.md`). The bytes emitted never exceed the capacity.
* One decode stream, one block parsed at a time (blocks overlap in the pipeline). Multiple engines were deliberately not built before the single stream was verified.
* Throughput is data dependent (`06_PERFORMANCE.md`): ≈ 15 B/cycle on long matches and literal runs, but short-sequence data (typical text, ratio ≈ 1.7) decodes at ≈ 5 B/cycle because the parser spends two cycles per sequence; matches with
  offsets 16..31 wait for the SRAM (history RAW conflicts); the first chunk of an overlapping match costs one bubble.
* A producer that never sends `in_last` blocks the stream (no timeout / watchdog).

## Compressor

* A **baseline**: greedy parse, one hash entry per bucket, no backward extension, no lazy matching, no high-compression levels. Ratio is a few percent below the reference `LZ4_compress_default` on text-like data
  (`benchmarks/REPORT.md`), and its output is *not* byte-identical to the reference's (any valid block is interoperable; the hardware matches its own bit-exact model).
* Throughput is **low on compressible data** (≈ 0.3–0.6 B/cycle on text/source): the scan is a sequential FSM (≈ 4 cycles per probed position). Incompressible data is fast (skip acceleration), long matches ≈ 5 B/cycle.
  The documented improvements (pipelined probe, sliding window) are not implemented.
* After reset the match finder needs 2^`HASH_BITS` cycles (4096 by default) to clear its table before the first compress block can be scanned; the sweep repeats once every 255 passes (a 4096-cycle pause).
* One block at a time: the next block's ingest waits for the previous completion (no double buffering). `ERROR` / `RAW` policies cost a second pass (dry-run + emit).
* `STREAM` policy on overflow leaves ≤ `cap` invalid bytes in the destination (documented, never beyond `cap`). `ERROR` / `RAW` guarantee an untouched destination on `INCOMPRESSIBLE` (no data beat is emitted).
* Maximum input block 64 KiB (the 16-bit offset range and the block buffer).

## Memory

* All SRAMs are behavioural (`sf_lz4_sram_1r1w`, 1R1W with byte write-enables). A physical implementation needs a **1R1W macro with byte write-enables** (or an equivalent bank scheme) behind that one wrapper; the read-before-write
  semantics of the model are assumed (the design never depends on same-cycle read-after-write: `mpos` visibility rule, proved).
* **No ECC / parity on the history, block buffer or hash table.** The repository's SECDED wrapper (P77) cannot simply be dropped in: the history writes *partial words* (byte enables), which under per-word ECC need
  read-modify-write — a design decision left open (per-byte parity or write-combining are the candidate routes). A single-bit upset in the history corrupts decoded data silently; the optional CRC stage detects it end to end
  when the producer supplied a CRC.
* No BIST / DFT / reset of memories (contents are never read before being written — formally and by simulation with random initial memory).

## Adapter, CRC, counters

* `ORDQ_DEPTH` = 4 blocks in flight. Framing errors complete the block with `FRAMING`; a lost `in_last` is not detected. The CRC is an integrity check, **not authentication**. Counters are 64-bit (no saturation); `perf_snap` during a running
  divide restarts it.

## Verification gaps

* Formal covers the packer, history ring, FIFO and the hazard predicate. The **parser FSM, copy engine, encoder FSM, match finder, adapter, CRC and counters are verified by simulation and mutation testing only**
  (`05_VERIFICATION.md` lists what mutation testing killed and anything that survived). BMC results are bounded (depths in `reports/formal.md`).
* Simulation is Verilator two-state; there is no gate-level simulation, no X-propagation analysis, no CDC analysis (single clock), no code-coverage report (functional coverage is by test statistics).
* SymbiYosys is not available in this environment; the Yosys + `yosys-smtbmc` + Z3 pipeline is driven directly.

## Integration

* **Not integrated** into StreamDMA, IronMemory, StorageFabric, DataFabric or PacketCore; `09_INTEGRATION.md` gives the attachment points and the open issues (e.g. variable output length versus fixed-length DMA descriptors).
  There is no module called PacketForge in the repository (`00_AUDIT.md`).
