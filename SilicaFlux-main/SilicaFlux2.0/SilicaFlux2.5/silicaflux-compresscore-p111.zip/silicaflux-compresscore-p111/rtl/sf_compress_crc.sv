// =============================================================================
// CompressCore :: sf_compress_crc -- OPTIONAL data-integrity stage: CRC over the UNCOMPRESSED bytes of each block (stream pass-through)
//
//   A one-entry register slice with a CRC engine on its input side.  The stream is passed through UNCHANGED (data, byte count, last, user
//   sideband); the CRC is computed over the bytes that pass (byte i of a beat is included when i < in_n) and is presented as `out_crc`,
//   valid together with out_last (the CRC of the whole block, final-XORed).  The running value restarts after every out_last.
//   Reflected CRC with initial value and final XOR 0xFFFFFFFF; POLY = 0xEDB88320 -> CRC-32 (IEEE 802.3, zlib/gzip/PNG: "123456789" -> 0xCBF43926),
//   POLY = 0x82F63B78 -> CRC-32C (Castagnoli, the polynomial of the repository's StorageFabric protection information).
//   It does not touch the data, so compression/decompression results are identical with the stage present or absent.
//   Where it sits (sf_compress_core): in FRONT of the encoder (CRC of the raw input) and BEHIND the decoder (CRC of the decompressed output),
//   so both directions report the CRC of the same uncompressed data.  This is an integrity CHECK, not authentication.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_compress_crc #(
  parameter int          DW   = 128,
  parameter int          UW   = 1,
  parameter logic [31:0] POLY = 32'hEDB88320,
  localparam int         BYTES = DW / 8,
  localparam int         LW    = $clog2(BYTES)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            in_valid,
  output logic                 in_ready,
  input  wire logic [DW-1:0]   in_data,
  input  wire logic [LW:0]     in_n,
  input  wire logic            in_last,
  input  wire logic [UW-1:0]   in_user,
  output logic                 out_valid,
  input  wire logic            out_ready,
  output logic      [DW-1:0]   out_data,
  output logic      [LW:0]     out_n,
  output logic                 out_last,
  output logic      [UW-1:0]   out_user,
  output logic      [31:0]     out_crc
);
  function automatic logic [31:0] crc_beat(input logic [31:0] c_in, input logic [DW-1:0] d, input logic [LW:0] n);
    logic [31:0] c;
    c = c_in;
    for (int i = 0; i < BYTES; i++) begin
      if ((LW+1)'(i) < n) begin
        c = c ^ {24'd0, d[8*i +: 8]};
        for (int b = 0; b < 8; b++) c = c[0] ? ((c >> 1) ^ POLY) : (c >> 1);
      end
    end
    crc_beat = c;
  endfunction

  logic [31:0] crc_q;
  wire  [31:0] crc_nxt = crc_beat(crc_q, in_data, in_n);
  assign in_ready = !out_valid || out_ready;
  wire fire = in_valid && in_ready;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      crc_q <= 32'hFFFF_FFFF; out_valid <= 1'b0; out_data <= '0; out_n <= '0; out_last <= 1'b0; out_user <= '0; out_crc <= '0;
    end else begin
      if (out_valid && out_ready) out_valid <= 1'b0;
      if (fire) begin
        out_valid <= 1'b1; out_data <= in_data; out_n <= in_n; out_last <= in_last; out_user <= in_user; out_crc <= ~crc_nxt;
        crc_q <= in_last ? 32'hFFFF_FFFF : crc_nxt;
      end
    end
  end
endmodule
`default_nettype wire
