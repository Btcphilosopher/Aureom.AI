// CompressCore file list (order does not matter; include dir: rtl/).  Top level: sf_compress_core
sf_compress_defs.svh
sf_lz4_fifo.sv
sf_lz4_sram_1r1w.sv
sf_lz4_history.sv
sf_lz4_pack.sv
sf_lz4_srcchk.sv
sf_lz4_decoder.sv
sf_lz4_matchfinder.sv
sf_lz4_encoder.sv
sf_compress_crc.sv
sf_compress_stream_adapter.sv
sf_compress_perf.sv
sf_compress_core.sv
