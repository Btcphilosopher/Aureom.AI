// =============================================================================
// CompressCore :: sf_compress_stream_adapter -- external stream <-> engine channels
//
//   EXTERNAL STREAM (what a StreamDMA / DataFabric master sees): 128-bit data + byte-valid mask `keep`, block start `first`, block end `last`,
//   a transaction id and the per-block descriptor fields, all carried with the FIRST beat of a block:
//       in_mode (0 = decompress, 1 = compress), in_cap, in_policy, in_crc_en, in_crc_chk, in_crc_exp
//   Beats may carry any number of valid bytes 0..16 in the LOW lanes (keep must be contiguous from lane 0); partial beats inside a block are legal
//   and are REPACKED into dense 16-byte beats for the engines (sf_lz4_pack).  Output beats are dense (full except the last of a block).
//
//   FRAMING POLICY  a violation never hangs or corrupts the stream: the block is carried on and completes with SF_CST_FRAMING (unless an engine
//   error was found first):  * a block's first beat lacks `first`   * `first` on a beat inside a block   * non-contiguous keep (only the count of
//   valid lanes is used).  A block is delimited by `last`; a producer that never sends `last` stalls the stream (no timeout, documented).
//
//   ORDERING        blocks are returned in the order they were accepted.  One queue entry per block in flight (ORDQ_DEPTH): it holds the block's mode
//   and CRC configuration and selects which engine's output is forwarded.  Compress and decompress blocks may be interleaved freely.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_compress_stream_adapter #(
  parameter int DW         = 128,
  parameter int TIDW       = 8,
  parameter int ORDQ_DEPTH = 4,          // blocks in flight (power of two)
  parameter int FDEPTH     = 4,
  localparam int BYTES     = DW / 8,
  localparam int LW        = $clog2(BYTES)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // ---------------- external input
  input  wire logic            in_valid,
  output logic                 in_ready,
  input  wire logic [DW-1:0]   in_data,
  input  wire logic [BYTES-1:0] in_keep,
  input  wire logic            in_first,
  input  wire logic            in_last,
  input  wire logic [TIDW-1:0] in_tid,
  input  wire logic            in_mode,
  input  wire logic [31:0]     in_cap,
  input  wire logic [1:0]      in_policy,
  input  wire logic            in_crc_en,
  input  wire logic            in_crc_chk,
  input  wire logic [31:0]     in_crc_exp,
  // ---------------- decoder channel
  output logic                 dec_in_valid,
  input  wire logic            dec_in_ready,
  output logic      [DW-1:0]   dec_in_data,
  output logic      [LW:0]     dec_in_n,
  output logic                 dec_in_first,
  output logic                 dec_in_last,
  output logic      [TIDW-1:0] dec_in_tid,
  output logic      [31:0]     dec_in_cap,
  output logic                 dec_in_ferr,
  // ---------------- encoder channel
  output logic                 enc_in_valid,
  input  wire logic            enc_in_ready,
  output logic      [DW-1:0]   enc_in_data,
  output logic      [LW:0]     enc_in_n,
  output logic                 enc_in_first,
  output logic                 enc_in_last,
  output logic      [TIDW-1:0] enc_in_tid,
  output logic      [31:0]     enc_in_cap,
  output logic      [1:0]      enc_in_policy,
  output logic                 enc_in_ferr,
  // ---------------- decoder output
  input  wire logic            dec_out_valid,
  output logic                 dec_out_ready,
  input  wire logic [DW-1:0]   dec_out_data,
  input  wire logic [LW:0]     dec_out_n,
  input  wire logic            dec_out_last,
  input  wire logic [TIDW-1:0] dec_out_tid,
  input  wire logic [3:0]      dec_out_status,
  input  wire logic [31:0]     dec_out_in_bytes,
  input  wire logic [31:0]     dec_out_out_bytes,
  input  wire logic [31:0]     dec_out_crc,
  // ---------------- encoder output
  input  wire logic            enc_out_valid,
  output logic                 enc_out_ready,
  input  wire logic [DW-1:0]   enc_out_data,
  input  wire logic [LW:0]     enc_out_n,
  input  wire logic            enc_out_last,
  input  wire logic [TIDW-1:0] enc_out_tid,
  input  wire logic            enc_out_raw,
  input  wire logic [3:0]      enc_out_status,
  input  wire logic [31:0]     enc_out_in_bytes,
  input  wire logic [31:0]     enc_out_out_bytes,
  input  wire logic [31:0]     enc_out_crc,
  // ---------------- per-block configuration of the block at the head of the order queue (for the decode-path CRC check)
  output logic                 o_valid,
  output logic                 o_mode,
  output logic                 o_crc_en,
  output logic                 o_crc_chk,
  output logic      [31:0]     o_crc_exp,
  // ---------------- external output
  output logic                 out_valid,
  input  wire logic            out_ready,
  output logic      [DW-1:0]   out_data,
  output logic      [BYTES-1:0] out_keep,
  output logic                 out_first,
  output logic                 out_last,
  output logic      [TIDW-1:0] out_tid,
  output logic                 out_mode,
  output logic      [3:0]      out_status,
  output logic                 out_raw,
  output logic      [31:0]     out_in_bytes,
  output logic      [31:0]     out_out_bytes,
  output logic      [31:0]     out_crc,
  output logic                 out_crc_valid,
  // ---------------- events
  output logic                 ev_frame_err,
  output logic                 ev_blk_in,
  output logic                 ev_blk_out,
  output logic      [LW:0]     ev_in_bytes,
  output logic      [LW:0]     ev_out_bytes,
  output logic                 ev_in_mode,
  output logic                 ev_out_mode
);
  localparam int DESCW = 1 + 32 + 2 + TIDW;                // {policy, cap, mode, tid}
  localparam int OQW   = 1 + 1 + 1 + 32;                   // {mode, crc_en, crc_chk, crc_exp}

  // ===========================================================================================================================
  //  input side: framing check + repack
  // ===========================================================================================================================
  logic                blk_open_q, ferr_q;
  logic [DESCW-1:0]    desc_q;
  wire                 starting  = !blk_open_q;
  wire [DESCW-1:0]     desc_in   = {in_policy, in_cap, in_mode, in_tid};
  wire [DESCW-1:0]     desc_eff  = starting ? desc_in : desc_q;
  wire                 keep_ok   = ((in_keep & (in_keep + 1'b1)) == '0);          // 2^n - 1 pattern
  logic [LW:0]         n_in;
  always_comb begin
    n_in = '0;
    for (int i = 0; i < BYTES; i++) n_in = n_in + (LW+1)'(in_keep[i]);
  end
  wire                 beat_err  = (starting && !in_first) || (!starting && in_first) || !keep_ok;

  logic                pk_in_ready, oq_full, oq_empty, oq_push, oq_pop;
  assign in_ready = pk_in_ready && (!starting || !oq_full);
  wire   in_fire  = in_valid && in_ready;
  wire   ferr_eff = (starting ? 1'b0 : ferr_q) | beat_err;
  assign oq_push  = in_fire && starting;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      blk_open_q <= 1'b0; ferr_q <= 1'b0; desc_q <= '0;
    end else if (in_fire) begin
      if (starting) desc_q <= desc_in;
      ferr_q     <= ferr_eff;
      blk_open_q <= !in_last;
    end
  end

  // dense beats toward the engines
  /* verilator lint_off UNUSEDSIGNAL */
  logic             pk_busy_unused;
  /* verilator lint_on UNUSEDSIGNAL */
  logic             pk_o_valid, pk_o_ready, pk_o_last, pk_o_ferr;
  logic [DW-1:0]    pk_o_data;
  logic [LW:0]      pk_o_n;
  logic [DESCW-1:0] pk_o_desc;
  sf_lz4_pack #(.DW(DW), .TIDW(DESCW), .SIDEW(1), .FDEPTH(FDEPTH)) u_inpack (
    .clk(clk), .rst_n(rst_n),
    .in_valid(in_valid && (!starting || !oq_full)), .in_ready(pk_in_ready), .in_data(in_data), .in_n(n_in), .in_end(in_last),
    .in_tid(desc_eff), .in_side(ferr_eff),
    .out_valid(pk_o_valid), .out_ready(pk_o_ready), .out_data(pk_o_data), .out_n(pk_o_n), .out_last(pk_o_last), .out_tid(pk_o_desc),
    .out_side(pk_o_ferr), .busy(pk_busy_unused)
  );

  // demux by mode
  logic first_pend_q;
  wire  pk_mode = pk_o_desc[TIDW];
  assign dec_in_valid  = pk_o_valid && !pk_mode;
  assign enc_in_valid  = pk_o_valid &&  pk_mode;
  assign pk_o_ready    = pk_mode ? enc_in_ready : dec_in_ready;
  assign dec_in_data   = pk_o_data;   assign enc_in_data  = pk_o_data;
  assign dec_in_n      = pk_o_n;      assign enc_in_n     = pk_o_n;
  assign dec_in_first  = first_pend_q; assign enc_in_first = first_pend_q;
  assign dec_in_last   = pk_o_last;   assign enc_in_last  = pk_o_last;
  assign dec_in_tid    = pk_o_desc[TIDW-1:0];  assign enc_in_tid = pk_o_desc[TIDW-1:0];
  assign dec_in_cap    = pk_o_desc[TIDW+1 +: 32]; assign enc_in_cap = pk_o_desc[TIDW+1 +: 32];
  assign enc_in_policy = pk_o_desc[TIDW+33 +: 2];
  assign dec_in_ferr   = pk_o_last && pk_o_ferr;
  assign enc_in_ferr   = pk_o_last && pk_o_ferr;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) first_pend_q <= 1'b1;
    else if (pk_o_valid && pk_o_ready) first_pend_q <= pk_o_last;
  end

  // ===========================================================================================================================
  //  order queue + output side
  // ===========================================================================================================================
  logic [OQW-1:0] oq_din, oq_dout;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(ORDQ_DEPTH+1)-1:0] oq_count;
  /* verilator lint_on UNUSEDSIGNAL */
  assign oq_din = {in_mode, in_crc_en, in_crc_chk, in_crc_exp};
  sf_lz4_fifo #(.W(OQW), .DEPTH(ORDQ_DEPTH)) u_oq (
    .clk(clk), .rst_n(rst_n), .flush(1'b0), .push(oq_push), .din(oq_din), .pop(oq_pop), .dout(oq_dout),
    .full(oq_full), .empty(oq_empty), .count(oq_count)
  );
  assign o_valid   = !oq_empty;
  assign {o_mode, o_crc_en, o_crc_chk, o_crc_exp} = oq_dout;

  wire sel_dec = o_valid && !o_mode;
  wire sel_enc = o_valid &&  o_mode;
  logic [LW:0] o_n;
  assign out_valid     = sel_dec ? dec_out_valid : (sel_enc ? enc_out_valid : 1'b0);
  assign dec_out_ready = sel_dec && out_ready;
  assign enc_out_ready = sel_enc && out_ready;
  assign out_data      = sel_enc ? enc_out_data : dec_out_data;
  assign o_n           = sel_enc ? enc_out_n    : dec_out_n;
  assign out_last      = sel_enc ? enc_out_last : dec_out_last;
  assign out_tid       = sel_enc ? enc_out_tid  : dec_out_tid;
  assign out_status    = sel_enc ? enc_out_status : dec_out_status;
  assign out_raw       = sel_enc && enc_out_raw;
  assign out_in_bytes  = sel_enc ? enc_out_in_bytes  : dec_out_in_bytes;
  assign out_out_bytes = sel_enc ? enc_out_out_bytes : dec_out_out_bytes;
  assign out_crc       = sel_enc ? enc_out_crc : dec_out_crc;
  assign out_crc_valid = o_crc_en;
  assign out_mode      = o_mode;
  always_comb begin
    out_keep = '0;
    for (int i = 0; i < BYTES; i++) out_keep[i] = ((LW+1)'(i) < o_n);
  end
  logic ofirst_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) ofirst_q <= 1'b1;
    else if (out_valid && out_ready) ofirst_q <= out_last;
  end
  assign out_first = ofirst_q;
  assign oq_pop    = out_valid && out_ready && out_last;

  assign ev_frame_err = in_fire && beat_err;
  assign ev_blk_in    = oq_push;
  assign ev_blk_out   = oq_pop;
  assign ev_in_bytes  = in_fire ? n_in : '0;
  assign ev_out_bytes = (out_valid && out_ready) ? o_n : '0;
  assign ev_in_mode   = starting ? in_mode : desc_q[TIDW];
  assign ev_out_mode  = o_mode;
endmodule
`default_nettype wire
