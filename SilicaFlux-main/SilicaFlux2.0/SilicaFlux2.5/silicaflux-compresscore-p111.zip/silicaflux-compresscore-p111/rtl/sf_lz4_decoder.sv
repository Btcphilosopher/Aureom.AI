// =============================================================================
// CompressCore :: sf_lz4_decoder -- streaming LZ4 BLOCK-format decompressor (independent blocks, no dictionary), 128-bit stream
//
//   compressed beats -> [ input beat register ] -> PARSER FSM -> op queue -> COPY ENGINE (stage 1 -> stage 2) -> packer -> beats
//                                                                              |  ^
//                                                                              v  | (16-byte unaligned reads)
//                                                                         sf_lz4_history (2-bank SRAM ring)
//
//   PARSER   token / literal-length extension / literal bytes / 2-byte offset / match-length extension.  It validates every length and
//            offset field, never stalls the copy engine more than the op queue allows, and on ANY error switches to a DRAIN state that
//            consumes the rest of the block from the input (keeping the stream framed) and then reports the first error found.
//   OPS      BEGIN{tid,cap} | LIT{<=16 bytes} | MATCH{offset,length} | SEQ{<=13 literals + offset + match nibble} | END{status,sizes}   (parser -> copy engine, in order).
//            SEQ is the one-cycle FAST PATH: a whole sequence (token, <=13 literals, offset, no extension bytes) inside the current input beat becomes ONE op
//            (2 cycles per sequence through the copy engine instead of 3-4); everything else takes the LIT / MATCH path that reports errors in exact stream order.
//   COPY     stage 1 (issue): capacity + offset-range checks, then up to 16 bytes per cycle per op:
//              * literal chunk              -> data straight from the op
//              * match, offset >= 16        -> 16-byte unaligned read of the history SRAM (read-after-write hazard: a read is only
//                                              issued when the bytes it needs are already visible in the SRAM, `mpos_q`; otherwise the
//                                              engine stalls and counts a history RAW conflict)
//              * match, offset <  16        -> OVERLAPPING copy: the pattern of the last `offset` bytes (held in a 16-byte tail register)
//                                              is replicated, so repeated output bytes become the source of later bytes without any
//                                              dependency on the SRAM -- 16 bytes per cycle for ANY offset 1..15 (e.g. long runs)
//            stage 2 (commit): writes the chunk to the history, updates the tail register and merges it into the output packer.  A chunk is
//            committed only when the packer accepts it, so output backpressure can never lose or reorder history state.
//   ERRORS   (status codes in sf_compress_defs.svh)  first error in stream order wins; output produced before an error is INVALID and the
//            block completes with out_status != OK.  Nothing is ever written beyond the capacity given for the block.
//   BLOCK    one block = in_first .. in_last.  Blocks are independent: a match may only reference bytes of the same block.
//
//   Contract/ports: dense input beats (every beat full, 16 bytes, except the last of a block: in_n = 1..16, or 0 for an empty block).
//   in_cap: maximum decompressed size for the block (0 = MAX_OUT_BYTES).  in_ferr: upstream framing error flagged with in_last.
//   Output: dense beats, out_last carries out_status / out_in_bytes / out_out_bytes.
// Classification: SYNTHESIZABLE (history memory: sf_lz4_sram_1r1w)
// =============================================================================
`default_nettype none
`include "sf_compress_defs.svh"
module sf_lz4_decoder #(
  parameter int DW            = 128,           // fixed at 128 (checked)
  parameter int TIDW          = 8,
  parameter int HIST_BYTES    = 65536,         // history window; supported offsets are 1 .. HIST_BYTES-1
  parameter int MAX_IN_BYTES  = 4194304,       // largest accepted compressed block
  parameter int MAX_OUT_BYTES = 4194304,       // largest accepted decompressed block (hard bound on output, also bounds in_cap)
  parameter bit STRICT_EOB    = 1'b1,          // enforce the LZ4 end-of-block rules relative to the actual decoded size
  parameter int OPQ_DEPTH     = 4,
  parameter int OUTQ_DEPTH    = 4,
  localparam int LW           = $clog2(DW / 8),
  localparam int POSW         = $clog2(MAX_OUT_BYTES) + 1
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // compressed block in
  input  wire logic            in_valid,
  output logic                 in_ready,
  input  wire logic [DW-1:0]   in_data,
  input  wire logic [LW:0]     in_n,
  input  wire logic            in_first,
  input  wire logic            in_last,
  input  wire logic [TIDW-1:0] in_tid,
  input  wire logic [31:0]     in_cap,
  input  wire logic            in_ferr,
  // decompressed data out
  output logic                 out_valid,
  input  wire logic            out_ready,
  output logic      [DW-1:0]   out_data,
  output logic      [LW:0]     out_n,
  output logic                 out_last,
  output logic      [TIDW-1:0] out_tid,
  output logic      [3:0]      out_status,
  output logic      [31:0]     out_in_bytes,
  output logic      [31:0]     out_out_bytes,
  // performance / debug events (one-cycle pulses)
  output logic                 ev_raw_stall,    // history read-after-write conflict: match source not yet visible in the SRAM
  output logic                 ev_pat_bubble,   // overlapping-match start waited for the previous chunk to commit
  output logic                 ev_out_stall,    // commit stage stalled by output backpressure
  output logic                 ev_opq_stall,    // parser stalled by a full op queue
  output logic                 ev_hist_rd,
  output logic                 ev_hist_wr,
  output logic                 busy
);
  if (DW != 128) begin : g_dw
    illegal_parameter_DW_must_be_128 u_bad ();
  end
  if (MAX_OUT_BYTES < HIST_BYTES) begin : g_mo
    illegal_parameter_MAX_OUT_BYTES_must_be_ge_HIST_BYTES u_bad2 ();
  end

  localparam int LENW      = 24;
  localparam int BYTES     = 16;
  localparam logic [31:0] LEN_LIMIT = 32'((1 << LENW) - 1);

  // op types
  localparam logic [2:0] OP_BEGIN = 3'd0, OP_LIT = 3'd1, OP_MATCH = 3'd2, OP_END = 3'd3, OP_SEQ = 3'd4;
  // parser states
  localparam logic [3:0] P_IDLE = 4'd0, P_TOKEN = 4'd1, P_LLEXT = 4'd2, P_LIT = 4'd3, P_AFTERLIT = 4'd4,
                         P_OFFLO = 4'd5, P_OFFHI = 4'd6, P_MLEXT = 4'd7, P_DRAIN = 4'd8, P_END = 4'd9;

  // ===========================================================================================================================
  //  op queue
  // ===========================================================================================================================
  // entry = { type[2:0], m4[3:0], n[4:0], data[127:0] }.  SEQ: n = literal count (<=13), data[111:0] = literals, data[127:112] = offset, m4 = match nibble (len = m4 + 4)
  localparam int OPW = 3 + 4 + 5 + DW;
  logic            opq_push, opq_pop, opq_full, opq_empty;
  logic [OPW-1:0]  opq_din, opq_dout;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(OPQ_DEPTH+1)-1:0] opq_count;
  /* verilator lint_on UNUSEDSIGNAL */
  sf_lz4_fifo #(.W(OPW), .DEPTH(OPQ_DEPTH)) u_opq (
    .clk(clk), .rst_n(rst_n), .flush(1'b0), .push(opq_push), .din(opq_din), .pop(opq_pop),
    .dout(opq_dout), .full(opq_full), .empty(opq_empty), .count(opq_count)
  );

  // ===========================================================================================================================
  //  PARSER
  // ===========================================================================================================================
  logic [3:0]      pst;
  logic            ib_valid, ib_last, ib_ferr;
  logic [DW-1:0]   ib_data;
  logic [4:0]      ib_n;
  logic [TIDW-1:0] ib_tid;
  logic [31:0]     ib_cap;
  logic [4:0]      ip;
  logic            eof_q, blk_ferr_q;
  logic [31:0]     in_cnt_q;
  logic [LENW-1:0] lit_len_q, lit_rem_q, ml_q, flit_q;
  logic [3:0]      mnib_q;
  logic [7:0]      lo_q;
  logic [15:0]     off_q;
  logic            had_match_q;
  logic [3:0]      perr_q;

  wire        beat_ok = ib_valid && !eof_q;
  wire [4:0]  avail   = beat_ok ? (ib_n - ip) : 5'd0;
  wire [7:0]  cur_b0  = ib_data[8*32'(ip) +: 8];
  wire [7:0]  cur_b1  = ib_data[8*(32'(ip) + 1) +: 8];

  logic [3:0]      pst_n;
  logic [4:0]      adv;
  logic            push_v;
  logic [OPW-1:0]  push_e;
  logic            err_v;
  logic [3:0]      err_c;
  logic            lit_done_now;
  logic [LENW-1:0] lit_total_now;
  logic [LENW-1:0] lit_len_n, lit_rem_n, ml_n, flit_n;
  logic [3:0]      mnib_n;
  logic [7:0]      lo_n;
  logic [15:0]     off_n;
  logic            had_match_n;
  logic            clr_blk;
  logic            ev_opq_stall_c;

  logic [15:0]     off_v;
  logic            got_off;
  logic [4:0]      take;
  logic [31:0]     sum32;
  logic [4:0]      ip_after;

  // ---- fast-path sequence recognition (see P_TOKEN)
  wire [3:0]  fast_nlit = cur_b0[7:4];
  wire [5:0]  fast_need = 6'd3 + {2'd0, cur_b0[7:4]};
  wire [4:0]  fast_ix   = ip + 5'd1 + {1'b0, cur_b0[7:4]};                      // byte index of the offset (<= 15 when avail allows)
  wire [15:0] fast_off  = {ib_data[8*(32'(fast_ix) + 1) +: 8], ib_data[8*32'(fast_ix) +: 8]};
  /* verilator lint_off UNUSEDSIGNAL */
  wire [DW-1:0] seq_sh  = ib_data >> (8 * (32'(ip) + 1));             // literals start right after the token
  /* verilator lint_on UNUSEDSIGNAL */
  wire        fast_ok   = (cur_b0[7:4] != 4'd15) && (cur_b0[3:0] != 4'd15) && ({1'b0, avail} >= fast_need) && (fast_off != 16'd0) &&
                          (in_cnt_q + 32'(fast_need) <= 32'(MAX_IN_BYTES)) && !opq_full;

  always_comb begin
    pst_n = pst; adv = 5'd0; push_v = 1'b0; push_e = '0; err_v = 1'b0; err_c = 4'd0;
    lit_done_now = 1'b0; lit_total_now = lit_len_q;
    lit_len_n = lit_len_q; lit_rem_n = lit_rem_q; ml_n = ml_q; flit_n = flit_q; mnib_n = mnib_q; lo_n = lo_q; off_n = off_q;
    had_match_n = had_match_q; clr_blk = 1'b0; ev_opq_stall_c = 1'b0;
    off_v = 16'd0; got_off = 1'b0; take = 5'd0; sum32 = 32'd0;

    case (pst)
      P_IDLE: begin
        if (ib_valid) begin
          if (!opq_full) begin
            push_v = 1'b1;
            push_e = {OP_BEGIN, 4'd0, 5'd0, {(DW-32-TIDW){1'b0}}, ib_tid, ib_cap};
            clr_blk = 1'b1;
            pst_n = P_TOKEN;
          end else ev_opq_stall_c = 1'b1;
        end
      end

      P_TOKEN: begin
        if (avail >= 5'd1) begin
          if (in_cnt_q >= 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end
          else if (fast_ok) begin
            // whole sequence inside this beat: token, <=13 literals, offset, no extension bytes -> ONE combined op, one cycle
            adv = fast_need[4:0];
            push_v = 1'b1;
            push_e = {OP_SEQ, cur_b0[3:0], {1'b0, fast_nlit}, fast_off, seq_sh[111:0]};
            had_match_n = 1'b1;
          end else begin
            adv = 5'd1;
            mnib_n = cur_b0[3:0];
            lit_len_n = {{(LENW-4){1'b0}}, cur_b0[7:4]};
            if (cur_b0[7:4] == 4'd15) pst_n = P_LLEXT;
            else if (cur_b0[7:4] == 4'd0) begin lit_done_now = 1'b1; lit_total_now = '0; end
            else begin lit_rem_n = {{(LENW-4){1'b0}}, cur_b0[7:4]}; pst_n = P_LIT; end
          end
        end else if (eof_q) begin err_v = 1'b1; err_c = `SF_CST_TRUNCATED; end
      end

      P_LLEXT: begin
        if (avail >= 5'd1) begin
          sum32 = {8'd0, lit_len_q} + {24'd0, cur_b0};
          if (in_cnt_q >= 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end
          else if (sum32 > LEN_LIMIT) begin err_v = 1'b1; err_c = `SF_CST_LENGTH; end
          else begin
            adv = 5'd1;
            lit_len_n = sum32[LENW-1:0];
            if (cur_b0 != 8'hFF) begin lit_rem_n = sum32[LENW-1:0]; pst_n = P_LIT; end
          end
        end else if (eof_q) begin err_v = 1'b1; err_c = `SF_CST_TRUNCATED; end
      end

      P_LIT: begin
        if (avail >= 5'd1) begin
          take = (32'(avail) < {8'd0, lit_rem_q}) ? avail : lit_rem_q[4:0];
          if (in_cnt_q + 32'(take) > 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end
          else if (!opq_full) begin
            push_v = 1'b1;
            push_e = {OP_LIT, 4'd0, take, ib_data >> (8 * 32'(ip))};
            adv = take;
            lit_rem_n = lit_rem_q - {{(LENW-5){1'b0}}, take};
            if ({8'd0, lit_rem_q} == {27'd0, take}) lit_done_now = 1'b1;
          end else ev_opq_stall_c = 1'b1;
        end else if (eof_q) begin err_v = 1'b1; err_c = `SF_CST_TRUNCATED; end
      end

      P_AFTERLIT: begin
        if (avail >= 5'd1) pst_n = P_OFFLO;
        else if (eof_q) begin pst_n = P_END; flit_n = lit_len_q; end
      end

      P_OFFLO: begin
        if (avail >= 5'd2) begin
          if (in_cnt_q + 32'd2 > 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end
          else begin off_v = {cur_b1, cur_b0}; got_off = 1'b1; end
        end else if (avail == 5'd1) begin
          if (in_cnt_q >= 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end
          else begin lo_n = cur_b0; adv = 5'd1; pst_n = P_OFFHI; end
        end else if (eof_q) begin err_v = 1'b1; err_c = `SF_CST_TRUNCATED; end
      end

      P_OFFHI: begin
        if (avail >= 5'd1) begin
          if (in_cnt_q >= 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end
          else begin off_v = {cur_b0, lo_q}; got_off = 1'b1; end
        end else if (eof_q) begin err_v = 1'b1; err_c = `SF_CST_TRUNCATED; end
      end

      P_MLEXT: begin
        if (avail >= 5'd1) begin
          sum32 = {8'd0, ml_q} + {24'd0, cur_b0};
          if (in_cnt_q >= 32'(MAX_IN_BYTES)) begin err_v = 1'b1; err_c = `SF_CST_BLOCK_SIZE; end
          else if (sum32 > LEN_LIMIT) begin err_v = 1'b1; err_c = `SF_CST_LENGTH; end
          else if (cur_b0 == 8'hFF) begin adv = 5'd1; ml_n = sum32[LENW-1:0]; end
          else if (!opq_full) begin
            adv = 5'd1;
            push_v = 1'b1;
            push_e = {OP_MATCH, 4'd0, 5'd0, {(DW-16-LENW){1'b0}}, sum32[LENW-1:0], off_q};
            had_match_n = 1'b1;
            pst_n = P_TOKEN;
          end else ev_opq_stall_c = 1'b1;
        end else if (eof_q) begin err_v = 1'b1; err_c = `SF_CST_TRUNCATED; end
      end

      P_DRAIN: begin
        adv = avail;                       // consume the rest of the beat; the framing of the stream is kept
        if (eof_q) pst_n = P_END;
      end

      P_END: begin
        if (!opq_full) begin
          push_v = 1'b1;
          push_e = {OP_END, 4'd0, 5'd0, {(DW-64){1'b0}}, in_cnt_q, flit_q, 2'b00, blk_ferr_q, had_match_q, perr_q};
          pst_n = P_IDLE;
        end else ev_opq_stall_c = 1'b1;
      end

      default: pst_n = P_IDLE;
    endcase

    // ---- offset field complete (shared by P_OFFLO fast path and P_OFFHI)
    if (got_off) begin
      if (off_v == 16'd0) begin err_v = 1'b1; err_c = `SF_CST_OFFSET_ZERO; end
      else if (mnib_q != 4'd15) begin
        if (!opq_full) begin
          adv = (pst == P_OFFLO) ? 5'd2 : 5'd1;
          push_v = 1'b1;
          push_e = {OP_MATCH, 4'd0, 5'd0, {(DW-16-LENW){1'b0}}, LENW'(32'd4) + {{(LENW-4){1'b0}}, mnib_q}, off_v};
          had_match_n = 1'b1;
          off_n = off_v;
          pst_n = P_TOKEN;
        end else ev_opq_stall_c = 1'b1;
      end else begin
        adv = (pst == P_OFFLO) ? 5'd2 : 5'd1;
        off_n = off_v;
        ml_n = LENW'(32'd19);
        pst_n = P_MLEXT;
      end
    end

    // ---- literal run complete: where does the sequence go next?
    ip_after = ip + adv;
    if (lit_done_now) begin
      if (ip_after < ib_n) pst_n = P_OFFLO;
      else if (ib_last)  begin pst_n = P_END; flit_n = lit_total_now; end
      else               pst_n = P_AFTERLIT;
    end

    // ---- error: abandon the sequence, keep the stream framed
    if (err_v) begin
      adv = 5'd0; push_v = 1'b0;
      pst_n = eof_q ? P_END : P_DRAIN;
    end
  end

  wire [4:0] ip_next = ip + adv;
  wire       ib_done = beat_ok && (ip_next == ib_n);
  assign in_ready    = !ib_valid || ib_done;
  assign opq_push    = push_v;
  assign opq_din     = push_e;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      pst <= P_IDLE; ib_valid <= 1'b0; ib_last <= 1'b0; ib_ferr <= 1'b0; ib_data <= '0; ib_n <= '0; ib_tid <= '0; ib_cap <= '0;
      ip <= '0; eof_q <= 1'b1; blk_ferr_q <= 1'b0; in_cnt_q <= '0;
      lit_len_q <= '0; lit_rem_q <= '0; ml_q <= '0; flit_q <= '0; mnib_q <= '0; lo_q <= '0; off_q <= '0;
      had_match_q <= 1'b0; perr_q <= 4'd0;
    end else begin
      pst <= pst_n;
      lit_len_q <= lit_len_n; lit_rem_q <= lit_rem_n; ml_q <= ml_n; flit_q <= flit_n; mnib_q <= mnib_n; lo_q <= lo_n; off_q <= off_n;
      had_match_q <= had_match_n;
      in_cnt_q <= in_cnt_q + 32'(adv);
      if (err_v) perr_q <= err_c;
      // beat register
      if (ib_done) begin
        ip <= 5'd0;
        if (ib_last) begin eof_q <= 1'b1; blk_ferr_q <= ib_ferr; end
      end else ip <= ip_next;
      if (in_valid && in_ready) begin
        ib_valid <= 1'b1; ib_data <= in_data; ib_n <= in_n; ib_last <= in_last; ib_ferr <= in_ferr; ib_tid <= in_tid; ib_cap <= in_cap;
      end else if (ib_done) ib_valid <= 1'b0;
      if (clr_blk) begin
        eof_q <= 1'b0; blk_ferr_q <= 1'b0; in_cnt_q <= '0; had_match_q <= 1'b0; perr_q <= 4'd0; flit_q <= '0;
      end
    end
  end
  wire unused_first = in_first;   // the adapter guarantees framing: a block starts with its first beat

  // ===========================================================================================================================
  //  COPY ENGINE -- stage 1 (issue)
  // ===========================================================================================================================
  logic [POSW-1:0] s1_cap, pos1, lms_q, m_start_q, mpos_q;
  logic [TIDW-1:0] s1_tid;
  logic [3:0]      s1_err;
  logic            m_active;
  logic [LENW-1:0] m_rem_q;
  logic [8*32-1:0] rep_q;
  logic [3:0]      phase_q;
  logic [DW-1:0]   tail_q;

  // stage-2 registers
  logic            s2_valid, s2_hist, s2_end;
  logic [DW-1:0]   s2_data;
  logic [4:0]      s2_n;
  logic [TIDW-1:0] s2_tid;
  logic [67:0]     s2_side;
  logic            s2_fire;

  wire [2:0]       op_t  = opq_dout[OPW-1 -: 3];
  wire [3:0]       op_m4 = opq_dout[DW + 5 +: 4];
  wire [4:0]       op_n  = opq_dout[DW +: 5];
  wire [DW-1:0]    op_d  = opq_dout[DW-1:0];
  wire             op_valid = !opq_empty;
  wire             can_issue = !s2_valid || s2_fire;
  logic            seqlit_q;                  // SEQ op: its literal part has been issued, the match part is next

  // overlapping-copy pattern: rep[k] = byte (k mod off) of the last `off` output bytes, oldest first
  logic [16*32*8-1:0] rep_cand;
  logic [16*16*4-1:0] pht;
  for (genvar o = 0; o < 16; o++) begin : g_rep
    for (genvar k = 0; k < 32; k++) begin : g_k
      if (o == 0) begin : g_z
        assign rep_cand[(o*32+k)*8 +: 8] = 8'h00;
      end else begin : g_nz
        assign rep_cand[(o*32+k)*8 +: 8] = tail_q[8*(16-o+(k%o)) +: 8];
      end
    end
    for (genvar ph = 0; ph < 16; ph++) begin : g_ph
      if (o == 0) begin : g_pz
        assign pht[(o*16+ph)*4 +: 4] = 4'd0;
      end else begin : g_pnz
        assign pht[(o*16+ph)*4 +: 4] = 4'((ph + 16) % o);
      end
    end
  end

  wire [15:0]      mt_off = (op_t == OP_SEQ) ? op_d[127:112] : op_d[15:0];
  wire [LENW-1:0]  mt_len = (op_t == OP_SEQ) ? (LENW'(op_m4) + LENW'(4)) : op_d[16 +: LENW];
  // chunk size of the match chunk being issued (drives sf_lz4_srcchk)
  wire [31:0]      rem_c = m_active ? {8'd0, m_rem_q} : {8'd0, mt_len};
  wire [4:0]       nn_c  = (rem_c >= 32'd16) ? 5'd16 : rem_c[4:0];
  logic            sc_in_window, sc_vis_ok;
  logic [POSW-1:0] sc_src;
  sf_lz4_srcchk #(.POSW(POSW), .HIST_BYTES(HIST_BYTES)) u_srcchk (
    .pos1(pos1), .off(mt_off), .mpos(mpos_q), .nn(nn_c), .in_window(sc_in_window), .src(sc_src), .vis_ok(sc_vis_ok)
  );
  logic [8*32-1:0] rep_b;
  logic [3:0]      off4;
  always_comb begin
    off4 = mt_off[3:0];
    for (int k = 0; k < 32; k++) rep_b[8*k +: 8] = rep_cand[(32'(off4)*32 + k)*8 +: 8];
  end
  wire [8*32-1:0] rep_cur = m_active ? rep_q : rep_b;
  wire [3:0]      ph_cur  = m_active ? phase_q : 4'd0;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [8*32-1:0] rep_sh  = rep_cur >> (8 * 32'(ph_cur));
  /* verilator lint_on UNUSEDSIGNAL */
  wire [3:0]      ph_next = pht[(32'(off4)*16 + 32'(ph_cur))*4 +: 4];

  logic            issue, hist_rd_valid;
  logic [DW-1:0]   i_data;
  logic [4:0]      i_n;
  logic            i_hist, i_end;
  logic [67:0]     i_side;
  logic [POSW-1:0] hist_rd_pos;
  logic            s1_pop;
  logic [3:0]      s1_err_n;
  logic [POSW-1:0] pos1_n, s1_cap_n, lms_n, m_start_n;
  logic [TIDW-1:0] s1_tid_n;
  logic            m_active_n;
  logic [LENW-1:0] m_rem_n;
  logic            s1_set_rep;
  logic            ev_raw_c, ev_pat_c, do_match, seqlit_n;

  logic [31:0]     m_off, m_len, m_rem_eff, pos_ext;
  logic [4:0]      m_nn;
  logic            m_pat, m_ok, m_first;
  logic [31:0]     cap_ext;
  logic [3:0]      end_status;

  always_comb begin
    issue = 1'b0; hist_rd_valid = 1'b0; i_data = '0; i_n = 5'd0; i_hist = 1'b0; i_end = 1'b0; i_side = '0; hist_rd_pos = '0;
    s1_pop = 1'b0; s1_err_n = s1_err; pos1_n = pos1; s1_cap_n = s1_cap; lms_n = lms_q; m_start_n = m_start_q; s1_tid_n = s1_tid;
    m_active_n = m_active; m_rem_n = m_rem_q; s1_set_rep = 1'b0; ev_raw_c = 1'b0; ev_pat_c = 1'b0;
    m_off = 32'd0; m_len = 32'd0; m_rem_eff = 32'd0; pos_ext = 32'd0; m_nn = 5'd0; m_pat = 1'b0; m_ok = 1'b0;
    m_first = 1'b0; cap_ext = 32'd0; end_status = `SF_CST_OK;

    do_match = 1'b0; seqlit_n = seqlit_q;
    if (op_valid) begin
      case (op_t)
        OP_BEGIN: begin
          s1_pop = 1'b1;
          cap_ext = op_d[31:0];
          s1_cap_n = ((cap_ext == 32'd0) || (cap_ext > 32'(MAX_OUT_BYTES))) ? POSW'(MAX_OUT_BYTES) : cap_ext[POSW-1:0];
          s1_tid_n = op_d[32 +: TIDW];
          pos1_n = '0; s1_err_n = 4'd0; lms_n = '0; m_active_n = 1'b0; seqlit_n = 1'b0;
        end

        OP_LIT: begin
          pos_ext = 32'(pos1) + {27'd0, op_n};
          if (s1_err != 4'd0) s1_pop = 1'b1;
          else if (pos_ext > 32'(s1_cap)) begin s1_err_n = `SF_CST_OUT_OVERFLOW; s1_pop = 1'b1; end
          else if (can_issue) begin
            issue = 1'b1; i_data = op_d; i_n = op_n; i_hist = 1'b0;
            pos1_n = pos_ext[POSW-1:0];
            s1_pop = 1'b1;
          end
        end

        OP_SEQ: begin                                   // combined sequence: literal chunk first, then the match
          pos_ext = 32'(pos1) + {27'd0, op_n};
          if (s1_err != 4'd0) begin s1_pop = 1'b1; seqlit_n = 1'b0; end
          else if (!seqlit_q && op_n != 5'd0) begin
            if (pos_ext > 32'(s1_cap)) begin s1_err_n = `SF_CST_OUT_OVERFLOW; s1_pop = 1'b1; seqlit_n = 1'b0; end
            else if (can_issue) begin
              issue = 1'b1; i_data = {16'd0, op_d[111:0]}; i_n = op_n; i_hist = 1'b0;
              pos1_n = pos_ext[POSW-1:0];
              seqlit_n = 1'b1;                          // stay on this op: the match part follows
            end
          end else do_match = 1'b1;
        end

        OP_MATCH: begin
          if (s1_err != 4'd0) s1_pop = 1'b1;
          else do_match = 1'b1;
        end

        default: begin                                    // OP_END
          if (can_issue) begin
            end_status = s1_err;
            if (end_status == `SF_CST_OK) end_status = op_d[3:0];
            if (end_status == `SF_CST_OK && STRICT_EOB && op_d[4] &&
                ((op_d[8 +: LENW] < LENW'(5)) || ((32'(pos1) - 32'(lms_q)) < 32'd12)))
              end_status = `SF_CST_EOB_RULE;
            if (end_status == `SF_CST_OK && op_d[5]) end_status = `SF_CST_FRAMING;
            issue = 1'b1; i_end = 1'b1; i_n = 5'd0;
            i_side = {end_status, op_d[32 +: 32], 32'(pos1)};
            s1_pop = 1'b1;
            pos1_n = '0; s1_err_n = 4'd0; lms_n = '0; m_active_n = 1'b0; seqlit_n = 1'b0;
          end
        end
      endcase
    end

    // ---- match part (OP_MATCH, or the second half of OP_SEQ)
    if (do_match) begin
      m_off = {16'd0, mt_off};
      m_len = {8'd0, mt_len};
      if (!m_active && !sc_in_window) begin
        s1_err_n = `SF_CST_OFFSET_RANGE; s1_pop = 1'b1; seqlit_n = 1'b0;
      end else if (!m_active && (32'(pos1) + m_len > 32'(s1_cap))) begin
        s1_err_n = `SF_CST_OUT_OVERFLOW; s1_pop = 1'b1; seqlit_n = 1'b0;
      end else begin
        m_first   = !m_active;
        m_rem_eff = m_active ? {8'd0, m_rem_q} : m_len;
        m_nn      = nn_c;
        m_pat     = (m_off < 32'd16);
        if (m_pat) begin
          m_ok = m_first ? !s2_valid : can_issue;
          if (m_first && s2_valid) ev_pat_c = 1'b1;
        end else begin
          m_ok = can_issue && sc_vis_ok;
          if (can_issue && !m_ok) ev_raw_c = 1'b1;
        end
        if (m_ok) begin
          issue = 1'b1; i_n = m_nn; i_hist = !m_pat;
          if (m_pat) begin i_data = rep_sh[DW-1:0]; s1_set_rep = 1'b1; end
          else begin hist_rd_valid = 1'b1; hist_rd_pos = sc_src; end
          pos1_n = POSW'(32'(pos1) + {27'd0, m_nn});
          if (m_first) m_start_n = pos1;
          if (m_rem_eff == {27'd0, m_nn}) begin
            s1_pop = 1'b1; m_active_n = 1'b0; seqlit_n = 1'b0;
            lms_n = m_first ? pos1 : m_start_q;
          end else begin
            m_active_n = 1'b1; m_rem_n = m_rem_eff[LENW-1:0] - {{(LENW-5){1'b0}}, m_nn};
          end
        end
      end
    end
  end

  assign opq_pop = s1_pop;

  wire s2_valid_n = issue ? 1'b1 : (s2_fire ? 1'b0 : s2_valid);

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      s1_cap <= '0; pos1 <= '0; lms_q <= '0; m_start_q <= '0; s1_tid <= '0; s1_err <= 4'd0; m_active <= 1'b0; m_rem_q <= '0; seqlit_q <= 1'b0;
      rep_q <= '0; phase_q <= 4'd0;
      s2_valid <= 1'b0; s2_hist <= 1'b0; s2_end <= 1'b0; s2_data <= '0; s2_n <= '0; s2_tid <= '0; s2_side <= '0;
    end else begin
      s1_cap <= s1_cap_n; pos1 <= pos1_n; lms_q <= lms_n; m_start_q <= m_start_n; s1_tid <= s1_tid_n; s1_err <= s1_err_n;
      m_active <= m_active_n; m_rem_q <= m_rem_n; seqlit_q <= seqlit_n;
      if (s1_set_rep) begin rep_q <= rep_cur; phase_q <= ph_next; end
      s2_valid <= s2_valid_n;
      if (issue) begin
        s2_hist <= i_hist; s2_end <= i_end; s2_data <= i_data; s2_n <= i_n; s2_tid <= s1_tid; s2_side <= i_side;
      end
    end
  end
  // ===========================================================================================================================
  //  COPY ENGINE -- stage 2 (commit): history write, tail update, output packer
  // ===========================================================================================================================
  logic [DW-1:0] hist_rd_data;
  wire  [DW-1:0] chunk_data = s2_hist ? hist_rd_data : s2_data;
  logic          pk_in_ready, pk_busy;
  assign s2_fire = s2_valid && pk_in_ready;

  wire             hist_wr_valid = s2_fire && !s2_end;
  logic [DW-1:0]   cmask;
  always_comb begin
    cmask = '0;
    for (int i = 0; i < BYTES; i++) if (5'(i) < s2_n) cmask[8*i +: 8] = chunk_data[8*i +: 8];
  end
  /* verilator lint_off UNUSEDSIGNAL */
  wire [2*DW-1:0] tail_cat = {cmask, tail_q} >> (8 * 32'(s2_n));
  /* verilator lint_on UNUSEDSIGNAL */

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      mpos_q <= '0; tail_q <= '0;
    end else if (s2_fire) begin
      if (s2_end) mpos_q <= '0;
      else begin
        mpos_q <= mpos_q + POSW'(s2_n);
        tail_q <= tail_cat[DW-1:0];
      end
    end
  end

  sf_lz4_history #(.DW(DW), .HIST_BYTES(HIST_BYTES), .POSW(POSW)) u_hist (
    .clk(clk),
    .wr_valid(hist_wr_valid), .wr_pos(mpos_q), .wr_n(s2_n), .wr_data(chunk_data),
    .rd_valid(hist_rd_valid), .rd_pos(hist_rd_pos), .rd_data(hist_rd_data)
  );

  sf_lz4_pack #(.DW(DW), .TIDW(TIDW), .SIDEW(68), .FDEPTH(OUTQ_DEPTH)) u_pack (
    .clk(clk), .rst_n(rst_n),
    .in_valid(s2_valid), .in_ready(pk_in_ready), .in_data(chunk_data), .in_n(s2_end ? 5'd0 : s2_n), .in_end(s2_end),
    .in_tid(s2_tid), .in_side(s2_side),
    .out_valid(out_valid), .out_ready(out_ready), .out_data(out_data), .out_n(out_n), .out_last(out_last), .out_tid(out_tid),
    .out_side({out_status, out_in_bytes, out_out_bytes}), .busy(pk_busy)
  );

  assign ev_raw_stall  = ev_raw_c;
  assign ev_pat_bubble = ev_pat_c;
  assign ev_out_stall  = s2_valid && !pk_in_ready;
  assign ev_opq_stall  = ev_opq_stall_c;
  assign ev_hist_rd    = hist_rd_valid;
  assign ev_hist_wr    = hist_wr_valid;
  assign busy          = (pst != P_IDLE) || ib_valid || !opq_empty || s2_valid || pk_busy;
endmodule
`default_nettype wire
