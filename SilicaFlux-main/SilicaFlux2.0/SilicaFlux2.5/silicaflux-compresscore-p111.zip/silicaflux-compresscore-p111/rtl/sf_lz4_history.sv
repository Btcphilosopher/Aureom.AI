// =============================================================================
// CompressCore :: sf_lz4_history -- bounded SRAM history / block buffer
//
//   A byte-addressed ring of HIST_BYTES bytes built from TWO word-interleaved SRAM banks (even / odd 16-byte words), each a 1R1W
//   SRAM with byte write-enables.  Because consecutive words live in different banks:
//     * a chunk of up to 16 bytes at ANY byte position is written in ONE cycle (it spans at most two consecutive words -> one per bank),
//     * 16 bytes at ANY byte position are read in ONE cycle (the two words that hold them are fetched in parallel from the two banks)
//   so there are no bank conflicts between a read and a write, and no read-modify-write.
//
//   write port: wr_valid, wr_pos (byte position; low log2(HIST_BYTES) bits are the ring address), wr_n (1..16), wr_data (byte 0 in [7:0])
//   read  port: rd_valid, rd_pos.  rd_data is valid in the cycle AFTER the read was issued and HOLDS until the next rd_valid
//               (rd_data = 16 bytes starting at rd_pos; bytes beyond what the caller needs are don't-care).
//   hazard rule (caller): a read must not be issued for bytes written in the same cycle -- a read sees the contents as of the start
//               of its cycle.  The decoder enforces this with its `visible bytes` counter.
//   Ring: position p lives at p mod HIST_BYTES.  A byte stays readable until byte p+HIST_BYTES is written, so every distance
//   1..HIST_BYTES-1 (>= the LZ4 maximum 65535 when HIST_BYTES = 65536) is safe.
// Classification: SYNTHESIZABLE (storage via sf_lz4_sram_1r1w)
// =============================================================================
`default_nettype none
module sf_lz4_history #(
  parameter int DW         = 128,
  parameter int HIST_BYTES = 65536,        // power of two, >= 64
  parameter int POSW       = 24,
  localparam int BYTES     = DW / 8,
  localparam int LW        = $clog2(BYTES),
  localparam int NWORDS    = HIST_BYTES / BYTES,
  localparam int WAW       = $clog2(NWORDS),   // word-index bits
  localparam int BAW       = WAW - 1           // per-bank address bits
) (
  input  wire logic            clk,
  input  wire logic            wr_valid,
  /* verilator lint_off UNUSEDSIGNAL */   // only the ring-address bits of a position are used
  input  wire logic [POSW-1:0] wr_pos,
  input  wire logic [LW:0]     wr_n,
  input  wire logic [DW-1:0]   wr_data,
  input  wire logic            rd_valid,
  input  wire logic [POSW-1:0] rd_pos,
  /* verilator lint_on UNUSEDSIGNAL */
  output logic      [DW-1:0]   rd_data
);
  if (HIST_BYTES < 64 || (HIST_BYTES & (HIST_BYTES - 1)) != 0 || (BYTES & (BYTES - 1)) != 0) begin : g_bad
    illegal_parameter_HIST_BYTES_or_DW u_bad ();
  end
  if (POSW < LW + WAW) begin : g_bad_posw
    illegal_parameter_POSW_too_small u_bad2 ();
  end

  // ---------------------------------------------------------------- write path
  wire [WAW-1:0] w_word = wr_pos[LW +: WAW];
  wire [LW-1:0]  w_off  = wr_pos[LW-1:0];
  /* verilator lint_off UNUSEDSIGNAL */
  wire [WAW-1:0] w_word1 = w_word + 1'b1;                      // wraps modulo NWORDS (bit 0 unused: only the bank address is needed)
  /* verilator lint_on UNUSEDSIGNAL */

  logic [2*DW-1:0]    w_wide;
  logic [2*BYTES-1:0] w_bewide;
  logic [BYTES-1:0]   mask_n;
  always_comb begin
    mask_n = '0;
    for (int i = 0; i < BYTES; i++) mask_n[i] = (LW+1)'(i) < wr_n;
    w_wide   = {{DW{1'b0}}, wr_data} << (8 * 32'(w_off));
    w_bewide = {{BYTES{1'b0}}, mask_n} << 32'(w_off);
  end
  wire [DW-1:0]    w_lo_d  = w_wide[DW-1:0];
  wire [DW-1:0]    w_hi_d  = w_wide[2*DW-1:DW];
  wire [BYTES-1:0] w_lo_be = w_bewide[BYTES-1:0];
  wire [BYTES-1:0] w_hi_be = w_bewide[2*BYTES-1:BYTES];

  // lo part goes to the bank of w_word, hi part to the other bank
  wire              w_to_b0   = (w_word[0] == 1'b0);                 // lo part belongs to bank 0
  wire              wen0      = wr_valid && ((w_to_b0 ? w_lo_be : w_hi_be) != '0);
  wire              wen1      = wr_valid && ((w_to_b0 ? w_hi_be : w_lo_be) != '0);
  wire [BYTES-1:0]  wbe0      = w_to_b0 ? w_lo_be : w_hi_be;
  wire [BYTES-1:0]  wbe1      = w_to_b0 ? w_hi_be : w_lo_be;
  wire [DW-1:0]     wdat0     = w_to_b0 ? w_lo_d : w_hi_d;
  wire [DW-1:0]     wdat1     = w_to_b0 ? w_hi_d : w_lo_d;
  wire [BAW-1:0]    waddr0    = w_to_b0 ? w_word[WAW-1:1] : w_word1[WAW-1:1];
  wire [BAW-1:0]    waddr1    = w_to_b0 ? w_word1[WAW-1:1] : w_word[WAW-1:1];

  // ---------------------------------------------------------------- read path
  wire [WAW-1:0] r_word  = rd_pos[LW +: WAW];
  wire [LW-1:0]  r_off   = rd_pos[LW-1:0];
  /* verilator lint_off UNUSEDSIGNAL */
  wire [WAW-1:0] r_word1 = r_word + 1'b1;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [BAW-1:0] raddr0  = (r_word[0] == 1'b0) ? r_word[WAW-1:1] : r_word1[WAW-1:1];
  wire [BAW-1:0] raddr1  = (r_word[0] == 1'b1) ? r_word[WAW-1:1] : r_word1[WAW-1:1];

  logic [DW-1:0] bank0_q, bank1_q;
  logic          rb_q;                     // bank holding the FIRST word of the last read
  logic [LW-1:0] roff_q;
  always_ff @(posedge clk) begin
    if (rd_valid) begin
      rb_q   <= r_word[0];
      roff_q <= r_off;
    end
  end

  sf_lz4_sram_1r1w #(.AW(BAW), .DW(DW)) u_sram0 (
    .clk(clk), .we(wen0), .be(wbe0), .waddr(waddr0), .wdata(wdat0), .re(rd_valid), .raddr(raddr0), .rdata(bank0_q)
  );
  sf_lz4_sram_1r1w #(.AW(BAW), .DW(DW)) u_sram1 (
    .clk(clk), .we(wen1), .be(wbe1), .waddr(waddr1), .wdata(wdat1), .re(rd_valid), .raddr(raddr1), .rdata(bank1_q)
  );

  wire [DW-1:0] r_lo = rb_q ? bank1_q : bank0_q;
  wire [DW-1:0] r_hi = rb_q ? bank0_q : bank1_q;
  /* verilator lint_off UNUSEDSIGNAL */
  wire [2*DW-1:0] r_cat = {r_hi, r_lo} >> (8 * 32'(roff_q));
  /* verilator lint_on UNUSEDSIGNAL */
  assign rd_data = r_cat[DW-1:0];
endmodule
`default_nettype wire
