// =============================================================================
// CompressCore :: sf_compress_perf -- performance counters (measurement only; never influences the datapath)
//
//   64-bit event counters, a per-block latency tracker, a coherent SNAPSHOT (`snap`) and a serial divider that turns the snapshot into
//   fixed-point (Q16.16) ratios.  Read-out: `rd_sel` selects a register, `rd_data` returns it (combinational on the snapshot).
//   `clear` zeroes the counters.  Registers (all 64-bit; "bytes" are UNCOMPRESSED bytes unless stated):
//     0 cycles                    1 in_bytes (external input)      2 out_bytes (external output)   3 blocks_in      4 blocks_out    5 blocks_err
//     6 dec_blocks                7 dec_in_bytes (compressed)      8 dec_out_bytes                 9 dec_busy_cycles
//    10 enc_blocks               11 enc_in_bytes                  12 enc_out_bytes (compressed)   13 enc_busy_cycles
//    14 in_stall_cycles (valid & !ready)  15 out_stall_cycles     16 hist_raw_conflicts (decoder: match source not yet visible in the SRAM)
//    17 dec_pat_bubbles          18 dec_out_stall_cycles          19 dec_opq_stall_cycles         20 enc_probes     21 enc_hits
//    22 enc_ext_cycles           23 enc_out_stall_cycles          24 enc_dry_cycles               25 frame_errors
//    26 lat_last (cycles, first input beat accepted -> last output beat accepted)   27 lat_max   28 lat_sum   29 lat_count
//    ---- derived by the divider after `snap` (Q16.16; 0 if the denominator is 0; valid when rd_busy = 0) ----
//    30 comp_ratio  = enc_in_bytes / enc_out_bytes          31 dec_ratio = dec_out_bytes / dec_in_bytes
//    32 dec_bytes_per_busy_cycle = dec_out_bytes / dec_busy_cycles   33 enc_bytes_per_busy_cycle = enc_in_bytes / enc_busy_cycles
//    34 in_bytes_per_cycle = in_bytes / cycles              35 out_bytes_per_cycle = out_bytes / cycles
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_compress_perf #(
  parameter int ORDQ_DEPTH = 4,
  parameter int LW         = 4
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  input  wire logic            clear,
  input  wire logic            snap,
  // events (one-cycle pulses / counts)
  input  wire logic [LW:0]     ev_in_bytes,
  input  wire logic            ev_in_mode,
  input  wire logic [LW:0]     ev_out_bytes,
  input  wire logic            ev_out_mode,
  input  wire logic            ev_blk_in,
  input  wire logic            ev_blk_out,
  input  wire logic            ev_blk_err,
  input  wire logic            ev_in_stall,
  input  wire logic            ev_out_stall,
  input  wire logic            ev_frame_err,
  input  wire logic            ev_dec_busy,
  input  wire logic            ev_enc_busy,
  input  wire logic            ev_dec_raw_stall,
  input  wire logic            ev_dec_pat_bubble,
  input  wire logic            ev_dec_out_stall,
  input  wire logic            ev_dec_opq_stall,
  input  wire logic            ev_enc_probe,
  input  wire logic            ev_enc_hit,
  input  wire logic            ev_enc_ext_cycle,
  input  wire logic            ev_enc_out_stall,
  input  wire logic            ev_enc_dry,
  // read-out
  input  wire logic [5:0]      rd_sel,
  output logic      [63:0]     rd_data,
  output logic                 rd_busy
);
  localparam int NC = 30;      // snapshot registers 0..29
  localparam int ND = 6;       // derived registers 30..35
  localparam int R_CYC = 0, R_INB = 1, R_OUTB = 2, R_BLKI = 3, R_BLKO = 4, R_BLKE = 5, R_DBLK = 6, R_DIN = 7, R_DOUT = 8, R_DBUSY = 9,
                 R_EBLK = 10, R_EIN = 11, R_EOUT = 12, R_EBUSY = 13, R_INST = 14, R_OUTST = 15, R_RAW = 16, R_PAT = 17, R_DOST = 18,
                 R_OPQ = 19, R_EPROBE = 20, R_EHIT = 21, R_EEXT = 22, R_EOST = 23, R_EDRY = 24, R_FRM = 25, R_LLAST = 26, R_LMAX = 27,
                 R_LSUM = 28, R_LCNT = 29;

  logic [63:0] cnt [NC];
  logic [63:0] snp [NC];
  logic [63:0] der [ND];
  logic [31:0] free_cyc;

  // ---- latency tracker (timestamp per block in flight)
  logic        ts_empty;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        ts_full;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [31:0] ts_head;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(ORDQ_DEPTH+1)-1:0] ts_count;
  /* verilator lint_on UNUSEDSIGNAL */
  sf_lz4_fifo #(.W(32), .DEPTH(ORDQ_DEPTH)) u_ts (
    .clk(clk), .rst_n(rst_n), .flush(1'b0), .push(ev_blk_in), .din(free_cyc), .pop(ev_blk_out), .dout(ts_head),
    .full(ts_full), .empty(ts_empty), .count(ts_count)
  );
  wire [31:0] lat_now = free_cyc - ts_head + 32'd1;
  wire        lat_ev  = ev_blk_out && !ts_empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) free_cyc <= '0; else free_cyc <= free_cyc + 32'd1;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NC; i++) cnt[i] <= '0;
    end else if (clear) begin
      for (int i = 0; i < NC; i++) cnt[i] <= '0;
    end else begin
      cnt[R_CYC]   <= cnt[R_CYC] + 64'd1;
      cnt[R_INB]   <= cnt[R_INB]  + 64'(ev_in_bytes);
      cnt[R_OUTB]  <= cnt[R_OUTB] + 64'(ev_out_bytes);
      cnt[R_BLKI]  <= cnt[R_BLKI] + 64'(ev_blk_in);
      cnt[R_BLKO]  <= cnt[R_BLKO] + 64'(ev_blk_out);
      cnt[R_BLKE]  <= cnt[R_BLKE] + 64'(ev_blk_err);
      cnt[R_DBLK]  <= cnt[R_DBLK] + 64'(ev_blk_out && !ev_out_mode);
      cnt[R_EBLK]  <= cnt[R_EBLK] + 64'(ev_blk_out &&  ev_out_mode);
      // bytes of a block are attributed to the engine that handles it: compressed side / uncompressed side per direction
      cnt[R_DIN]   <= cnt[R_DIN]  + ((!ev_in_mode)  ? 64'(ev_in_bytes)  : 64'd0);
      cnt[R_DOUT]  <= cnt[R_DOUT] + ((!ev_out_mode) ? 64'(ev_out_bytes) : 64'd0);
      cnt[R_EIN]   <= cnt[R_EIN]  + (( ev_in_mode)  ? 64'(ev_in_bytes)  : 64'd0);
      cnt[R_EOUT]  <= cnt[R_EOUT] + (( ev_out_mode) ? 64'(ev_out_bytes) : 64'd0);
      cnt[R_DBUSY] <= cnt[R_DBUSY] + 64'(ev_dec_busy);
      cnt[R_EBUSY] <= cnt[R_EBUSY] + 64'(ev_enc_busy);
      cnt[R_INST]  <= cnt[R_INST]  + 64'(ev_in_stall);
      cnt[R_OUTST] <= cnt[R_OUTST] + 64'(ev_out_stall);
      cnt[R_RAW]   <= cnt[R_RAW]   + 64'(ev_dec_raw_stall);
      cnt[R_PAT]   <= cnt[R_PAT]   + 64'(ev_dec_pat_bubble);
      cnt[R_DOST]  <= cnt[R_DOST]  + 64'(ev_dec_out_stall);
      cnt[R_OPQ]   <= cnt[R_OPQ]   + 64'(ev_dec_opq_stall);
      cnt[R_EPROBE]<= cnt[R_EPROBE]+ 64'(ev_enc_probe);
      cnt[R_EHIT]  <= cnt[R_EHIT]  + 64'(ev_enc_hit);
      cnt[R_EEXT]  <= cnt[R_EEXT]  + 64'(ev_enc_ext_cycle);
      cnt[R_EOST]  <= cnt[R_EOST]  + 64'(ev_enc_out_stall);
      cnt[R_EDRY]  <= cnt[R_EDRY]  + 64'(ev_enc_dry);
      cnt[R_FRM]   <= cnt[R_FRM]   + 64'(ev_frame_err);
      if (lat_ev) begin
        cnt[R_LLAST] <= 64'(lat_now);
        if (64'(lat_now) > cnt[R_LMAX]) cnt[R_LMAX] <= 64'(lat_now);
        cnt[R_LSUM]  <= cnt[R_LSUM] + 64'(lat_now);
        cnt[R_LCNT]  <= cnt[R_LCNT] + 64'd1;
      end
    end
  end

  // ---- snapshot + serial restoring divider: der[k] = (num_k << 16) / den_k, operands saturated to 40 bits
  logic [2:0]  dk;                   // derived register being computed (0..ND-1), ND = idle
  logic [6:0]  dbit;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [55:0] rem_q;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [55:0] quo_q;
  logic [39:0] den_q;
  logic        dbusy;
  logic [63:0] num_sel, den_sel;
  always_comb begin
    case (dk)
      3'd0: begin num_sel = snp[R_EIN];  den_sel = snp[R_EOUT]; end
      3'd1: begin num_sel = snp[R_DOUT]; den_sel = snp[R_DIN];  end
      3'd2: begin num_sel = snp[R_DOUT]; den_sel = snp[R_DBUSY]; end
      3'd3: begin num_sel = snp[R_EIN];  den_sel = snp[R_EBUSY]; end
      3'd4: begin num_sel = snp[R_INB];  den_sel = snp[R_CYC]; end
      default: begin num_sel = snp[R_OUTB]; den_sel = snp[R_CYC]; end
    endcase
  end
  function automatic logic [39:0] sat40(input logic [63:0] v);
    sat40 = (v >> 40) != 64'd0 ? 40'hFF_FFFF_FFFF : v[39:0];
  endfunction
  wire [55:0] shl_rem  = {rem_q[54:0], quo_q[55]};
  wire        sub_ok   = (shl_rem >= {16'd0, den_q});
  assign rd_busy = dbusy;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int i = 0; i < NC; i++) snp[i] <= '0;
      for (int i = 0; i < ND; i++) der[i] <= '0;
      dk <= 3'(ND); dbit <= '0; rem_q <= '0; quo_q <= '0; den_q <= '0; dbusy <= 1'b0;
    end else begin
      if (snap) begin
        for (int i = 0; i < NC; i++) snp[i] <= cnt[i];
        dk <= 3'd0; dbusy <= 1'b1; dbit <= 7'd0;
        for (int i = 0; i < ND; i++) der[i] <= '0;
        // operand setup happens in the first divider cycle below (needs the new snapshot)
      end else if (dbusy) begin
        if (dbit == 7'd0) begin                                   // load operands for derived register dk
          den_q <= sat40(den_sel); quo_q <= {sat40(num_sel), 16'd0}; rem_q <= '0; dbit <= 7'd1;
          if (sat40(den_sel) == 40'd0) begin der[dk] <= 64'd0; dk <= dk + 3'd1; dbit <= 7'd0; if (dk == 3'(ND-1)) begin dbusy <= 1'b0; dk <= 3'(ND); end end
        end else begin
          rem_q <= sub_ok ? (shl_rem - {16'd0, den_q}) : shl_rem;
          quo_q <= {quo_q[54:0], sub_ok};
          if (dbit == 7'd56) begin
            dbit <= 7'd0; dk <= dk + 3'd1;
            der[dk] <= 64'({quo_q[54:0], sub_ok});
            if (dk == 3'(ND-1)) begin dbusy <= 1'b0; dk <= 3'(ND); end
          end else dbit <= dbit + 7'd1;
        end
      end
    end
  end

  always_comb begin
    rd_data = '0;
    if (rd_sel < 6'(NC)) rd_data = snp[rd_sel[4:0]];
    else if (rd_sel < 6'(NC + ND)) rd_data = der[3'(rd_sel - 6'(NC))];
  end
endmodule
`default_nettype wire
