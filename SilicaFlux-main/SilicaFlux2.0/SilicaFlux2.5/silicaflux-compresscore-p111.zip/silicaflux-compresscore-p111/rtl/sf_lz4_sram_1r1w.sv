// =============================================================================
// CompressCore :: sf_lz4_sram_1r1w -- simple dual-port SRAM with per-byte write enables, synchronous read (BEHAVIOURAL MODEL)
//
//   write : at the clock edge when `we`, bytes with be[i]=1 take wdata byte i
//   read  : when `re`, rdata <= mem[raddr] at the clock edge (the value BEFORE any write of the same edge); rdata HOLDS when !re
//   A write at edge E is visible to a read issued in the cycle after E (read address presented after E).
//
// This module is the single place to replace for a physical implementation: an ASIC SRAM compiler 1R1W macro (or two single-port
// macros with the documented bank scheme), or an FPGA block-RAM (this coding infers true-dual-port-style BRAM with byte enables).
// Nothing else in CompressCore depends on the memory technology.  Contents are NOT reset.
// Classification: SYNTHESIZABLE (memory is inferred; use the macro wrapper in a real flow)
// =============================================================================
`default_nettype none
module sf_lz4_sram_1r1w #(
  parameter int AW = 11,
  parameter int DW = 128
) (
  input  wire logic            clk,
  input  wire logic            we,
  input  wire logic [DW/8-1:0] be,
  input  wire logic [AW-1:0]   waddr,
  input  wire logic [DW-1:0]   wdata,
  input  wire logic            re,
  input  wire logic [AW-1:0]   raddr,
  output logic      [DW-1:0]   rdata
);
  logic [DW-1:0] mem [2**AW];
  always_ff @(posedge clk) begin
    if (we) begin
      for (int i = 0; i < DW/8; i++) begin
        if (be[i]) mem[waddr][8*i +: 8] <= wdata[8*i +: 8];
      end
    end
    if (re) rdata <= mem[raddr];
  end
endmodule
`default_nettype wire
