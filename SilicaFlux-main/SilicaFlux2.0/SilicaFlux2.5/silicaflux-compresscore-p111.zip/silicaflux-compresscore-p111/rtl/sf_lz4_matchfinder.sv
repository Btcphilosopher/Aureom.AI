// =============================================================================
// CompressCore :: sf_lz4_matchfinder -- hash-table match finder for the baseline LZ4 compressor
//
//   One command at a time (baseline, see docs/03_ENCODER.md for the area / ratio / throughput trade-offs):
//     OP_PASS    start a new compression pass: bump the table EPOCH (entries of older passes become invalid; a full table sweep only every
//                255 passes) -- this is what makes a dry-run pass and the emit pass of the same block take IDENTICAL decisions
//     OP_PROBE   look up the 4 bytes at `pos`, insert `pos` into the table, and return a verified candidate (4 bytes equal) if there is one
//     OP_EXTEND  count how many further bytes of pos/cand are equal (16 bytes per iteration, 2 cycles per iteration), bounded by `limit`
//     OP_INSERT  insert `pos` only (used for the position just before the end of a match, like the reference LZ4)
//   Table: 2^HASH_BITS entries x 32 bit {epoch[7:0], tag[7:0], pos[15:0]}; hash = (4 bytes * 0x9E3779B1) >> (32 - HASH_BITS).
//   A candidate must have the current epoch, the same 8-bit tag, a smaller position, and is then VERIFIED against the actual block bytes, so
//   correctness never depends on the table contents (a corrupted/stale entry can only cost time, never produce a wrong match).
//   The block buffer is read through a 16-byte-unaligned read port (sf_lz4_history): `bb_rd_*`.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_lz4_matchfinder #(
  parameter int HASH_BITS = 12,                 // 2^HASH_BITS table entries (area / compression-ratio trade-off); 8..20
  parameter int PW        = 17                  // position width (block <= 64 KiB => positions < 2^16, limits up to 2^16)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // command
  input  wire logic            cmd_valid,
  output logic                 cmd_ready,
  input  wire logic [1:0]      cmd_op,
  input  wire logic [PW-1:0]   cmd_pos,
  input  wire logic [PW-1:0]   cmd_cand,
  input  wire logic [PW-1:0]   cmd_limit,       // EXTEND: exclusive end bound for the match (block length - 5)
  // response (one-cycle pulse)
  output logic                 rsp_valid,
  output logic                 rsp_found,
  output logic      [PW-1:0]   rsp_cand,
  output logic      [PW-1:0]   rsp_len,
  // block buffer read port (data valid the cycle after bb_rd_valid, holds until the next read)
  output logic                 bb_rd_valid,
  output logic      [PW-1:0]   bb_rd_pos,
  input  wire logic [127:0]    bb_rd_data
);
  localparam logic [1:0] OP_PASS = 2'd0, OP_PROBE = 2'd1, OP_EXTEND = 2'd2, OP_INSERT = 2'd3;
  localparam logic [3:0] S_CLR = 4'd0, S_IDLE = 4'd1, S_P1 = 4'd2, S_P2 = 4'd3, S_P3 = 4'd4, S_E2 = 4'd5, S_E3 = 4'd6, S_RESP = 4'd7;

  if (HASH_BITS < 8 || HASH_BITS > 20) begin : g_hb
    illegal_parameter_HASH_BITS u_bad ();
  end

  logic [3:0]          st;
  logic [7:0]          epoch;
  logic [HASH_BITS-1:0] sweep;
  logic [PW-1:0]       pos_q, cand_q, e_cur, e_cand, e_rem, e_cnt;
  logic                ins_q, pass_pend_q;
  logic [31:0]         cur4_q;
  logic [127:0]        cur16_q;
  logic                r_found;
  logic [PW-1:0]       r_cand, r_len;

  // ---- hash table
  logic                 t_we, t_re;
  logic [HASH_BITS-1:0] t_waddr, t_raddr;
  logic [31:0]          t_wdata, t_rdata;
  sf_lz4_sram_1r1w #(.AW(HASH_BITS), .DW(32)) u_tbl (
    .clk(clk), .we(t_we), .be(4'hF), .waddr(t_waddr), .wdata(t_wdata), .re(t_re), .raddr(t_raddr), .rdata(t_rdata)
  );

  // hash of the 4 bytes just read (state S_P1)
  /* verilator lint_off UNUSEDSIGNAL */
  wire [31:0]           h32   = bb_rd_data[31:0] * 32'h9E3779B1;
  /* verilator lint_on UNUSEDSIGNAL */
  wire [HASH_BITS-1:0]  h_idx = h32[31 -: HASH_BITS];
  wire [7:0]            h_tag = h32[31 - HASH_BITS -: 8];
  logic [HASH_BITS-1:0] idx_q;
  logic [7:0]           tag_q;

  // table entry returned in S_P2
  wire [7:0]  e_epoch = t_rdata[31:24];
  wire [7:0]  e_tag   = t_rdata[23:16];
  wire [PW-1:0] e_pos = PW'(t_rdata[15:0]);
  wire cand_ok = (e_epoch == epoch) && (epoch != 8'd0) && (e_tag == tag_q) && (e_pos < pos_q);

  // extension compare (state S_E3): both 16-byte windows are valid in bb_rd_data (cand) and cur16_q (cur)
  logic [4:0]  mism;
  logic [4:0]  ncmp;
  always_comb begin
    ncmp = (e_rem >= PW'(16)) ? 5'd16 : e_rem[4:0];
    mism = ncmp;
    for (int i = 15; i >= 0; i--) begin
      if ((5'(i) < ncmp) && (cur16_q[8*i +: 8] != bb_rd_data[8*i +: 8])) mism = 5'(i);
    end
  end

  assign cmd_ready = (st == S_IDLE);
  assign rsp_valid = (st == S_RESP);
  assign rsp_found = r_found;
  assign rsp_cand  = r_cand;
  assign rsp_len   = r_len;

  always_comb begin
    t_we = 1'b0; t_waddr = idx_q; t_wdata = {epoch, tag_q, pos_q[15:0]}; t_re = 1'b0; t_raddr = h_idx;
    bb_rd_valid = 1'b0; bb_rd_pos = '0;
    case (st)
      S_CLR: begin t_we = 1'b1; t_waddr = sweep; t_wdata = 32'd0; end
      S_IDLE: begin
        if (cmd_valid) begin
          if (cmd_op == OP_PROBE || cmd_op == OP_INSERT) begin bb_rd_valid = 1'b1; bb_rd_pos = cmd_pos; end
          else if (cmd_op == OP_EXTEND && (cmd_limit > cmd_pos + PW'(4))) begin bb_rd_valid = 1'b1; bb_rd_pos = cmd_pos + PW'(4); end
        end
      end
      S_P1: begin t_re = 1'b1; t_raddr = h_idx; end
      S_P2: begin
        t_we = 1'b1; t_waddr = idx_q; t_wdata = {epoch, tag_q, pos_q[15:0]};
        if (!ins_q && cand_ok) begin bb_rd_valid = 1'b1; bb_rd_pos = e_pos; end
      end
      S_E2: begin bb_rd_valid = 1'b1; bb_rd_pos = e_cand; end
      S_E3: begin
        if (mism == ncmp && e_rem > PW'(16)) begin bb_rd_valid = 1'b1; bb_rd_pos = e_cur + PW'(16); end
      end
      default: ;
    endcase
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_CLR; epoch <= 8'd0; sweep <= '0; pos_q <= '0; cand_q <= '0; e_cur <= '0; e_cand <= '0; e_rem <= '0; e_cnt <= '0;
      ins_q <= 1'b0; pass_pend_q <= 1'b0; cur4_q <= '0; cur16_q <= '0; r_found <= 1'b0; r_cand <= '0; r_len <= '0; idx_q <= '0; tag_q <= '0;
    end else begin
      case (st)
        S_CLR: begin
          sweep <= sweep + 1'b1;
          if (sweep == {HASH_BITS{1'b1}}) begin st <= pass_pend_q ? S_RESP : S_IDLE; pass_pend_q <= 1'b0; end
        end
        S_IDLE: begin
          if (cmd_valid) begin
            pos_q <= cmd_pos;
            case (cmd_op)
              OP_PASS: begin
                r_found <= 1'b0; r_cand <= '0; r_len <= '0;
                if (epoch == 8'd255) begin epoch <= 8'd1; sweep <= '0; pass_pend_q <= 1'b1; st <= S_CLR; end   // wrap: clear the table, THEN answer the PASS
                else begin epoch <= epoch + 8'd1; st <= S_RESP; end
              end
              OP_PROBE:  begin ins_q <= 1'b0; st <= S_P1; end
              OP_INSERT: begin ins_q <= 1'b1; st <= S_P1; end
              default: begin                                     // OP_EXTEND
                cand_q <= cmd_cand;
                if (cmd_limit > cmd_pos + PW'(4)) begin
                  e_rem <= cmd_limit - (cmd_pos + PW'(4)); e_cur <= cmd_pos + PW'(4); e_cand <= cmd_cand + PW'(4); e_cnt <= '0;
                  st <= S_E2;
                end else begin
                  r_found <= 1'b1; r_cand <= cmd_cand; r_len <= PW'(4); st <= S_RESP;
                end
              end
            endcase
          end
        end
        S_P1: begin
          cur4_q <= bb_rd_data[31:0]; idx_q <= h_idx; tag_q <= h_tag; st <= S_P2;
        end
        S_P2: begin
          if (!ins_q && cand_ok) begin cand_q <= e_pos; st <= S_P3; end
          else begin r_found <= 1'b0; r_cand <= '0; r_len <= '0; st <= S_RESP; end
        end
        S_P3: begin
          r_found <= (bb_rd_data[31:0] == cur4_q); r_cand <= cand_q; r_len <= '0; st <= S_RESP;
        end
        S_E2: begin cur16_q <= bb_rd_data; st <= S_E3; end
        S_E3: begin
          e_cnt <= e_cnt + PW'(mism);
          if (mism == ncmp && e_rem > PW'(16)) begin
            e_rem <= e_rem - PW'(16); e_cur <= e_cur + PW'(16); e_cand <= e_cand + PW'(16);
            st <= S_E2;
          end else begin
            r_found <= 1'b1; r_cand <= cand_q; r_len <= PW'(4) + e_cnt + PW'(mism); st <= S_RESP;
          end
        end
        S_RESP: st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end
endmodule
`default_nettype wire
