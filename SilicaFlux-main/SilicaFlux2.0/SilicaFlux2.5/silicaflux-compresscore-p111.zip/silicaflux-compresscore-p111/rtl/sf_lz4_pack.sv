// =============================================================================
// CompressCore :: sf_lz4_pack -- byte-stream packer: variable-size chunks in, DENSE 16-byte beats out
//
//   Input items are (data, n bytes in the low lanes, n = 0..BYTES).  Items are concatenated in order into dense BYTES-byte output beats.
//   `in_end` marks the last item of a block: after merging its bytes the block is flushed, the final beat carries 1..BYTES bytes and
//   out_last=1.  A block with no bytes at all produces ONE empty beat (out_n = 0, out_last = 1).
//   Every beat except the last of a block is full (out_n == BYTES).  A completed word is HELD until the next word completes or the
//   block ends, so a block whose length is a multiple of BYTES still ends with a full, `last` beat (never a trailing empty beat).
//   `in_tid` is carried to every output beat; `in_side` (taken from the in_end item) is delivered with out_last.
//   Throughput: one chunk per cycle; BYTES bytes per cycle sustained for full chunks; a block flush costs 1-2 cycles.
//   Backpressure: in_ready is low while the output FIFO cannot take the word that would have to be pushed; nothing is ever dropped.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_lz4_pack #(
  parameter int DW     = 128,
  parameter int TIDW   = 8,
  parameter int SIDEW  = 1,
  parameter int FDEPTH = 4,
  localparam int BYTES = DW / 8,
  localparam int LW    = $clog2(BYTES)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // chunk input
  input  wire logic            in_valid,
  output logic                 in_ready,
  input  wire logic [DW-1:0]   in_data,
  input  wire logic [LW:0]     in_n,
  input  wire logic            in_end,
  input  wire logic [TIDW-1:0] in_tid,
  input  wire logic [SIDEW-1:0] in_side,
  // dense beats out
  output logic                 out_valid,
  input  wire logic            out_ready,
  output logic      [DW-1:0]   out_data,
  output logic      [LW:0]     out_n,
  output logic                 out_last,
  output logic      [TIDW-1:0] out_tid,
  output logic      [SIDEW-1:0] out_side,
  // 1 while any byte or completion is still held inside the packer (accumulator, held word, pending flush, output FIFO)
  output logic                 busy
);
  localparam int EW = DW + (LW + 1) + 1 + TIDW + SIDEW;

  logic [DW-1:0]   acc;
  logic [LW:0]     acc_n;
  logic [TIDW-1:0] acc_tid;
  logic            h_valid;
  logic [DW-1:0]   h_data;
  logic [LW:0]     h_n;
  logic [TIDW-1:0] h_tid;
  logic            fl_pend;
  logic [SIDEW-1:0] fl_side;

  // ---- output FIFO
  logic          f_push, f_full, f_empty;
  logic [EW-1:0] f_din, f_dout;
  /* verilator lint_off UNUSEDSIGNAL */
  logic [$clog2(FDEPTH+1)-1:0] f_count;
  /* verilator lint_on UNUSEDSIGNAL */
  sf_lz4_fifo #(.W(EW), .DEPTH(FDEPTH)) u_fifo (
    .clk(clk), .rst_n(rst_n), .flush(1'b0), .push(f_push), .din(f_din), .pop(out_valid && out_ready),
    .dout(f_dout), .full(f_full), .empty(f_empty), .count(f_count)
  );
  assign out_valid = !f_empty;
  assign {out_side, out_tid, out_last, out_n, out_data} = f_dout;

  // ---- merge arithmetic
  logic [DW-1:0] cm;                      // chunk masked to in_n bytes
  always_comb begin
    cm = '0;
    for (int i = 0; i < BYTES; i++) if ((LW+1)'(i) < in_n) cm[8*i +: 8] = in_data[8*i +: 8];
  end
  wire [LW+1:0]   tot       = {1'b0, acc_n} + {1'b0, in_n};
  wire            completes = (tot >= (LW+2)'(BYTES));
  wire [2*DW-1:0] wide      = {{DW{1'b0}}, cm} << (8 * 32'(acc_n));
  wire [DW-1:0]   merged    = acc | wide[DW-1:0];
  wire [DW-1:0]   rest      = wide[2*DW-1:DW];
  wire [LW:0]     tot_rem   = (LW+1)'(tot - (LW+2)'(BYTES));

  assign in_ready = !fl_pend && !(completes && h_valid && f_full);
  assign busy     = fl_pend || h_valid || (acc_n != '0) || !f_empty;   // data is held somewhere inside (accumulator, held word, pending flush, output FIFO)

  always_comb begin
    f_push = 1'b0;
    f_din  = '0;
    if (fl_pend) begin
      if (h_valid && acc_n != '0) begin
        f_push = !f_full;
        f_din  = {{SIDEW{1'b0}}, h_tid, 1'b0, h_n, h_data};
      end else begin
        f_push = !f_full;
        f_din  = {fl_side, (h_valid ? h_tid : acc_tid), 1'b1, (h_valid ? h_n : acc_n), (h_valid ? h_data : acc)};
      end
    end else if (in_valid && in_ready && completes && h_valid) begin
      f_push = 1'b1;
      f_din  = {{SIDEW{1'b0}}, h_tid, 1'b0, h_n, h_data};
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      acc <= '0; acc_n <= '0; acc_tid <= '0;
      h_valid <= 1'b0; h_data <= '0; h_n <= '0; h_tid <= '0;
      fl_pend <= 1'b0; fl_side <= '0;
    end else if (fl_pend) begin
      if (h_valid && acc_n != '0) begin
        if (!f_full) begin                     // push H (not last); the partial accumulator becomes the held (final) beat
          h_data <= acc; h_n <= acc_n; h_tid <= acc_tid;
          acc <= '0; acc_n <= '0;
        end
      end else if (!f_full) begin              // push the final beat
        h_valid <= 1'b0; acc <= '0; acc_n <= '0; fl_pend <= 1'b0;
      end
    end else if (in_valid && in_ready) begin
      acc_tid <= in_tid;
      if (completes) begin
        h_valid <= 1'b1; h_data <= merged; h_n <= (LW+1)'(BYTES); h_tid <= in_tid;
        acc <= rest; acc_n <= tot_rem;
      end else begin
        acc <= merged; acc_n <= tot[LW:0];
      end
      if (in_end) begin fl_pend <= 1'b1; fl_side <= in_side; end
    end
  end
endmodule
`default_nettype wire
