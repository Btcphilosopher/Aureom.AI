// =============================================================================
// SilicaFlux CompressCore (Project 111) :: sf_compress_core -- cloud data compression / decompression accelerator (LZ4 block format)
//
//   external stream (128-bit data + byte mask) -> sf_compress_stream_adapter (framing check, repack, mode demux, in-order return)
//        |-- decompress blocks -> sf_lz4_decoder ---------------------------> [sf_compress_crc: CRC of the decompressed data + expected-CRC check]
//        `-- compress blocks   -> [sf_compress_crc: CRC of the raw data] -> sf_lz4_encoder
//   plus sf_compress_perf (counters).  Blocks of both kinds may be interleaved; results come back in the order the blocks were accepted.
//
//   FORMAT  the standard LZ4 BLOCK format (independent blocks, no dictionary); see docs/01_FORMAT.md.  No proprietary format is substituted.
//   BLOCK   `in_first` .. `in_last`.  Descriptor fields are sampled with the first beat:
//             in_mode    0 = decompress, 1 = compress
//             in_cap     decompress: maximum decompressed size (0 = MAX_OUT_BYTES)    compress: destination capacity in bytes (0 = unlimited)
//             in_policy  compress only, what to do when the result does not fit / does not shrink: 0 STREAM, 1 ERROR, 2 RAW (see sf_lz4_encoder)
//             in_crc_en  report the CRC-32 of the UNCOMPRESSED data in out_crc (valid with out_last, flagged by out_crc_valid)
//             in_crc_chk decompress only: compare that CRC with in_crc_exp and complete with SF_CST_CRC on a mismatch
//   RESULT  out_last carries out_status (0 = OK), the byte counts and the CRC.  Output data of a block that completes with an error is INVALID
//           and must be discarded by the consumer.  out_raw (compress) is 1 on every beat when the block is the input copied unchanged.
//   RESET   asynchronous, active low; every block in flight is lost.  The history / block buffers and the hash table need no initialisation.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
`include "sf_compress_defs.svh"
module sf_compress_core #(
  parameter int          DW            = 128,
  parameter int          TIDW          = 8,
  parameter int          ORDQ_DEPTH    = 4,
  parameter bit          CRC_EN        = 1'b1,
  parameter logic [31:0] CRC_POLY      = 32'hEDB88320,   // 0xEDB88320 CRC-32 (IEEE), 0x82F63B78 CRC-32C
  parameter bit          PERF_EN       = 1'b1,
  // decoder
  parameter int          HIST_BYTES    = 65536,
  parameter int          MAX_IN_BYTES  = 4194304,
  parameter int          MAX_OUT_BYTES = 4194304,
  parameter bit          STRICT_EOB    = 1'b1,
  // encoder
  parameter int          BLK_BYTES     = 65536,
  parameter int          HASH_BITS     = 12,
  parameter int          ACCEL         = 1,
  parameter int          SKIP_SHIFT    = 6,
  localparam int         BYTES         = DW / 8,
  localparam int         LW            = $clog2(DW / 8)
) (
  input  wire logic             clk,
  input  wire logic             rst_n,
  // ---------------- input stream
  input  wire logic             in_valid,
  output logic                  in_ready,
  input  wire logic [DW-1:0]    in_data,
  input  wire logic [BYTES-1:0] in_keep,
  input  wire logic             in_first,
  input  wire logic             in_last,
  input  wire logic [TIDW-1:0]  in_tid,
  input  wire logic             in_mode,
  input  wire logic [31:0]      in_cap,
  input  wire logic [1:0]       in_policy,
  input  wire logic             in_crc_en,
  input  wire logic             in_crc_chk,
  input  wire logic [31:0]      in_crc_exp,
  // ---------------- output stream
  output logic                  out_valid,
  input  wire logic             out_ready,
  output logic      [DW-1:0]    out_data,
  output logic      [BYTES-1:0] out_keep,
  output logic                  out_first,
  output logic                  out_last,
  output logic      [TIDW-1:0]  out_tid,
  output logic                  out_mode,
  output logic      [3:0]       out_status,
  output logic                  out_raw,
  output logic      [31:0]      out_in_bytes,
  output logic      [31:0]      out_out_bytes,
  output logic      [31:0]      out_crc,
  output logic                  out_crc_valid,
  // ---------------- performance counters (see sf_compress_perf)
  input  wire logic             perf_clear,
  input  wire logic             perf_snap,
  input  wire logic [5:0]       perf_rd_sel,
  output logic      [63:0]      perf_rd_data,
  output logic                  perf_rd_busy,
  output logic                  busy
);
  // ---------------------------------------------------------------- adapter <-> engines
  logic            dec_in_valid, dec_in_ready, dec_in_first, dec_in_last, dec_in_ferr;
  logic [DW-1:0]   dec_in_data;
  logic [LW:0]     dec_in_n;
  logic [TIDW-1:0] dec_in_tid;
  logic [31:0]     dec_in_cap;
  logic            enc_in_valid, enc_in_ready, enc_in_first, enc_in_last, enc_in_ferr;
  logic [DW-1:0]   enc_in_data;
  logic [LW:0]     enc_in_n;
  logic [TIDW-1:0] enc_in_tid;
  logic [31:0]     enc_in_cap;
  logic [1:0]      enc_in_policy;

  logic            dec_out_valid, dec_out_ready, dec_out_last;
  logic [DW-1:0]   dec_out_data;
  logic [LW:0]     dec_out_n;
  logic [TIDW-1:0] dec_out_tid;
  logic [3:0]      dec_out_status;
  logic [31:0]     dec_out_in_bytes, dec_out_out_bytes, dec_out_crc;
  logic            enc_out_valid, enc_out_ready, enc_out_last, enc_out_raw;
  logic [DW-1:0]   enc_out_data;
  logic [LW:0]     enc_out_n;
  logic [TIDW-1:0] enc_out_tid;
  logic [3:0]      enc_out_status;
  logic [31:0]     enc_out_in_bytes, enc_out_out_bytes, enc_out_crc;

  logic            o_valid, o_mode, o_crc_en, o_crc_chk;
  logic [31:0]     o_crc_exp;
  logic            ev_frame_err, ev_blk_in, ev_blk_out, ev_in_mode, ev_out_mode;
  logic [LW:0]     ev_in_bytes, ev_out_bytes;
  logic            a_out_valid, a_out_last, a_out_crc_valid;
  logic [3:0]      a_out_status;

  sf_compress_stream_adapter #(.DW(DW), .TIDW(TIDW), .ORDQ_DEPTH(ORDQ_DEPTH)) u_adapter (
    .clk(clk), .rst_n(rst_n),
    .in_valid(in_valid), .in_ready(in_ready), .in_data(in_data), .in_keep(in_keep), .in_first(in_first), .in_last(in_last), .in_tid(in_tid),
    .in_mode(in_mode), .in_cap(in_cap), .in_policy(in_policy), .in_crc_en(in_crc_en), .in_crc_chk(in_crc_chk), .in_crc_exp(in_crc_exp),
    .dec_in_valid(dec_in_valid), .dec_in_ready(dec_in_ready), .dec_in_data(dec_in_data), .dec_in_n(dec_in_n), .dec_in_first(dec_in_first),
    .dec_in_last(dec_in_last), .dec_in_tid(dec_in_tid), .dec_in_cap(dec_in_cap), .dec_in_ferr(dec_in_ferr),
    .enc_in_valid(enc_in_valid), .enc_in_ready(enc_in_ready), .enc_in_data(enc_in_data), .enc_in_n(enc_in_n), .enc_in_first(enc_in_first),
    .enc_in_last(enc_in_last), .enc_in_tid(enc_in_tid), .enc_in_cap(enc_in_cap), .enc_in_policy(enc_in_policy), .enc_in_ferr(enc_in_ferr),
    .dec_out_valid(dec_out_valid), .dec_out_ready(dec_out_ready), .dec_out_data(dec_out_data), .dec_out_n(dec_out_n), .dec_out_last(dec_out_last),
    .dec_out_tid(dec_out_tid), .dec_out_status(dec_out_status), .dec_out_in_bytes(dec_out_in_bytes), .dec_out_out_bytes(dec_out_out_bytes),
    .dec_out_crc(dec_out_crc),
    .enc_out_valid(enc_out_valid), .enc_out_ready(enc_out_ready), .enc_out_data(enc_out_data), .enc_out_n(enc_out_n), .enc_out_last(enc_out_last),
    .enc_out_tid(enc_out_tid), .enc_out_raw(enc_out_raw), .enc_out_status(enc_out_status), .enc_out_in_bytes(enc_out_in_bytes),
    .enc_out_out_bytes(enc_out_out_bytes), .enc_out_crc(enc_out_crc),
    .o_valid(o_valid), .o_mode(o_mode), .o_crc_en(o_crc_en), .o_crc_chk(o_crc_chk), .o_crc_exp(o_crc_exp),
    .out_valid(a_out_valid), .out_ready(out_ready), .out_data(out_data), .out_keep(out_keep), .out_first(out_first), .out_last(a_out_last),
    .out_tid(out_tid), .out_mode(out_mode), .out_status(a_out_status), .out_raw(out_raw), .out_in_bytes(out_in_bytes), .out_out_bytes(out_out_bytes),
    .out_crc(out_crc), .out_crc_valid(a_out_crc_valid),
    .ev_frame_err(ev_frame_err), .ev_blk_in(ev_blk_in), .ev_blk_out(ev_blk_out), .ev_in_bytes(ev_in_bytes), .ev_out_bytes(ev_out_bytes),
    .ev_in_mode(ev_in_mode), .ev_out_mode(ev_out_mode)
  );
  assign out_crc_valid = a_out_crc_valid && CRC_EN;
  assign out_valid  = a_out_valid;
  assign out_last   = a_out_last;
  assign out_status = a_out_status;

  // ===========================================================================================================================
  //  decompress path:  decoder -> CRC stage -> (CRC check) -> adapter
  // ===========================================================================================================================
  logic            d_valid, d_ready, d_last;
  logic [DW-1:0]   d_data;
  logic [LW:0]     d_n;
  logic [TIDW-1:0] d_tid;
  logic [3:0]      d_status;
  logic [31:0]     d_inb, d_outb;
  logic            ev_raw, ev_pat, ev_dout_stall, ev_opq, ev_hrd, ev_hwr, dec_busy;

  sf_lz4_decoder #(.DW(DW), .TIDW(TIDW), .HIST_BYTES(HIST_BYTES), .MAX_IN_BYTES(MAX_IN_BYTES), .MAX_OUT_BYTES(MAX_OUT_BYTES),
                   .STRICT_EOB(STRICT_EOB)) u_dec (
    .clk(clk), .rst_n(rst_n),
    .in_valid(dec_in_valid), .in_ready(dec_in_ready), .in_data(dec_in_data), .in_n(dec_in_n), .in_first(dec_in_first), .in_last(dec_in_last),
    .in_tid(dec_in_tid), .in_cap(dec_in_cap), .in_ferr(dec_in_ferr),
    .out_valid(d_valid), .out_ready(d_ready), .out_data(d_data), .out_n(d_n), .out_last(d_last), .out_tid(d_tid), .out_status(d_status),
    .out_in_bytes(d_inb), .out_out_bytes(d_outb),
    .ev_raw_stall(ev_raw), .ev_pat_bubble(ev_pat), .ev_out_stall(ev_dout_stall), .ev_opq_stall(ev_opq), .ev_hist_rd(ev_hrd), .ev_hist_wr(ev_hwr),
    .busy(dec_busy)
  );

  localparam int DUW = TIDW + 4 + 64;                 // sideband carried through the CRC stage: {tid, status, in_bytes, out_bytes}
  logic [31:0]     dc_crc;
  logic [DUW-1:0]  dc_user_in, dc_user_out;
  assign dc_user_in = {d_tid, d_status, d_inb, d_outb};
  if (CRC_EN) begin : g_dcrc
    sf_compress_crc #(.DW(DW), .UW(DUW), .POLY(CRC_POLY)) u_dcrc (
      .clk(clk), .rst_n(rst_n),
      .in_valid(d_valid), .in_ready(d_ready), .in_data(d_data), .in_n(d_n), .in_last(d_last), .in_user(dc_user_in),
      .out_valid(dec_out_valid), .out_ready(dec_out_ready), .out_data(dec_out_data), .out_n(dec_out_n), .out_last(dec_out_last),
      .out_user(dc_user_out), .out_crc(dc_crc)
    );
  end else begin : g_dnocrc
    assign dec_out_valid = d_valid; assign d_ready = dec_out_ready; assign dec_out_data = d_data; assign dec_out_n = d_n; assign dec_out_last = d_last;
    assign dc_user_out = dc_user_in;
    assign dc_crc = 32'd0;
  end
  wire [TIDW-1:0] dc_tid    = dc_user_out[DUW-1 -: TIDW];
  wire [3:0]      dc_status = dc_user_out[64 +: 4];
  assign dec_out_tid       = dc_tid;
  assign dec_out_status    = (dc_status == `SF_CST_OK && o_crc_chk && CRC_EN && (dc_crc != o_crc_exp)) ? `SF_CST_CRC : dc_status;
  assign dec_out_in_bytes  = dc_user_out[32 +: 32];
  assign dec_out_out_bytes = dc_user_out[0 +: 32];
  assign dec_out_crc       = dc_crc;

  // ===========================================================================================================================
  //  compress path:  adapter -> CRC stage -> encoder
  // ===========================================================================================================================
  logic            e_valid, e_ready, e_last, e_first, e_ferr;
  logic [DW-1:0]   e_data;
  logic [LW:0]     e_n;
  logic [TIDW-1:0] e_tid;
  logic [31:0]     e_cap, e_crc;
  logic [1:0]      e_pol;
  logic            ev_probe, ev_hit, ev_ext, ev_eout_stall, ev_dry, enc_busy;
  localparam int EUW = 1 + TIDW + 32 + 2 + 1;
  if (CRC_EN) begin : g_ecrc
    logic [EUW-1:0] eu_out;
    sf_compress_crc #(.DW(DW), .UW(EUW), .POLY(CRC_POLY)) u_ecrc (
      .clk(clk), .rst_n(rst_n),
      .in_valid(enc_in_valid), .in_ready(enc_in_ready), .in_data(enc_in_data), .in_n(enc_in_n), .in_last(enc_in_last),
      .in_user({enc_in_first, enc_in_tid, enc_in_cap, enc_in_policy, enc_in_ferr}),
      .out_valid(e_valid), .out_ready(e_ready), .out_data(e_data), .out_n(e_n), .out_last(e_last), .out_user(eu_out), .out_crc(e_crc)
    );
    assign {e_first, e_tid, e_cap, e_pol, e_ferr} = eu_out;
  end else begin : g_enocrc
    assign e_valid = enc_in_valid; assign enc_in_ready = e_ready; assign e_data = enc_in_data; assign e_n = enc_in_n; assign e_last = enc_in_last;
    assign e_first = enc_in_first; assign e_tid = enc_in_tid; assign e_cap = enc_in_cap; assign e_pol = enc_in_policy; assign e_ferr = enc_in_ferr;
    assign e_crc = 32'd0;
  end

  sf_lz4_encoder #(.DW(DW), .TIDW(TIDW), .BLK_BYTES(BLK_BYTES), .HASH_BITS(HASH_BITS), .ACCEL(ACCEL), .SKIP_SHIFT(SKIP_SHIFT)) u_enc (
    .clk(clk), .rst_n(rst_n),
    .in_valid(e_valid), .in_ready(e_ready), .in_data(e_data), .in_n(e_n), .in_first(e_first), .in_last(e_last), .in_tid(e_tid), .in_cap(e_cap),
    .in_policy(e_pol), .in_ferr(e_ferr), .in_crc(e_crc),
    .out_valid(enc_out_valid), .out_ready(enc_out_ready), .out_data(enc_out_data), .out_n(enc_out_n), .out_last(enc_out_last), .out_tid(enc_out_tid),
    .out_raw(enc_out_raw), .out_status(enc_out_status), .out_in_bytes(enc_out_in_bytes), .out_out_bytes(enc_out_out_bytes), .out_crc(enc_out_crc),
    .ev_probe(ev_probe), .ev_hit(ev_hit), .ev_ext_cycle(ev_ext), .ev_out_stall(ev_eout_stall), .ev_dry_pass(ev_dry), .busy(enc_busy)
  );

  // ===========================================================================================================================
  //  performance counters
  // ===========================================================================================================================
  if (PERF_EN) begin : g_perf
    sf_compress_perf #(.ORDQ_DEPTH(ORDQ_DEPTH), .LW(LW)) u_perf (
      .clk(clk), .rst_n(rst_n), .clear(perf_clear), .snap(perf_snap),
      .ev_in_bytes(ev_in_bytes), .ev_in_mode(ev_in_mode), .ev_out_bytes(ev_out_bytes), .ev_out_mode(ev_out_mode),
      .ev_blk_in(ev_blk_in), .ev_blk_out(ev_blk_out), .ev_blk_err(ev_blk_out && (a_out_status != `SF_CST_OK)),
      .ev_in_stall(in_valid && !in_ready), .ev_out_stall(a_out_valid && !out_ready), .ev_frame_err(ev_frame_err),
      .ev_dec_busy(dec_busy), .ev_enc_busy(enc_busy), .ev_dec_raw_stall(ev_raw), .ev_dec_pat_bubble(ev_pat), .ev_dec_out_stall(ev_dout_stall),
      .ev_dec_opq_stall(ev_opq), .ev_enc_probe(ev_probe), .ev_enc_hit(ev_hit), .ev_enc_ext_cycle(ev_ext), .ev_enc_out_stall(ev_eout_stall),
      .ev_enc_dry(ev_dry),
      .rd_sel(perf_rd_sel), .rd_data(perf_rd_data), .rd_busy(perf_rd_busy)
    );
  end else begin : g_noperf
    assign perf_rd_data = '0; assign perf_rd_busy = 1'b0;
    // with the counters compiled out, the event wires and the read-out controls are intentionally unused
    wire unused_perf = &{1'b0, perf_clear, perf_snap, perf_rd_sel, ev_frame_err, ev_blk_in, ev_blk_out, ev_in_mode, ev_out_mode, ev_in_bytes, ev_out_bytes,
                         ev_raw, ev_pat, ev_dout_stall, ev_opq, ev_probe, ev_hit, ev_ext, ev_eout_stall, ev_dry};
  end

  assign busy = dec_busy || enc_busy || o_valid;
  wire unused_core = &{1'b0, ev_hrd, ev_hwr, o_mode, o_crc_en};
endmodule
`default_nettype wire
