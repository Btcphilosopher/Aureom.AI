// =============================================================================
// CompressCore :: sf_lz4_srcchk -- legality of a history-SRAM match read (combinational; formally proved, formal/fv_srcchk.sv)
//
//   Inputs : pos1   bytes of this block issued so far (position of the NEXT output byte)
//            off    match offset (1 .. 65535)
//            mpos   bytes already COMMITTED to (visible in) the history SRAM
//            nn     bytes this chunk needs (1 .. 16)
//   Outputs: in_window  the offset is usable: 1 <= off <= pos1 (a match may only reference the same block) and off < HIST_BYTES
//            src        position of the first source byte (pos1 - off)
//            vis_ok     all nn source bytes are already committed to the SRAM (src + nn <= mpos): the read can be issued NOW
//   Proved (fv_srcchk): whenever in_window && vis_ok && mpos <= pos1, EVERY source byte q in [src, src+nn) satisfies
//            (a) q < mpos            -- it HAS been written (no read of stale / not yet written data), and
//            (b) q + HIST_BYTES >= mpos -- its ring slot has NOT been overwritten by a newer byte (the ring holds the last HIST_BYTES bytes),
//   which, with the bank/word addressing proved in fv_history, is what makes every history read return exactly the bytes of the output stream.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_lz4_srcchk #(
  parameter int POSW       = 23,
  parameter int HIST_BYTES = 65536
) (
  input  wire logic [POSW-1:0] pos1,
  input  wire logic [15:0]     off,
  input  wire logic [POSW-1:0] mpos,
  input  wire logic [4:0]      nn,
  output logic                 in_window,
  output logic      [POSW-1:0] src,
  output logic                 vis_ok
);
  wire [31:0] off32 = {16'd0, off};
  assign in_window = (off32 != 32'd0) && (off32 <= 32'(pos1)) && (off32 < 32'(HIST_BYTES));
  assign src       = pos1 - POSW'(off);
  assign vis_ok    = ({1'b0, src} + {{(POSW-4){1'b0}}, nn}) <= {1'b0, mpos};
endmodule
`default_nettype wire
