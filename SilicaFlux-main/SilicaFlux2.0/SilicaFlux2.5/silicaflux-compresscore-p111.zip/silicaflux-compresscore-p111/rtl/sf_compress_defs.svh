// =============================================================================
// SilicaFlux CompressCore (Project 111) -- shared definitions (status codes, policies, modes)
// Mirrored byte-for-byte by tools/lz4model.py (STATUS table) -- a test checks both agree.
// Macros (not a package) so every tool in the repository flow (Verilator, Icarus, Yosys 0.33) accepts the file.
// =============================================================================
`ifndef SF_COMPRESS_DEFS_SVH
`define SF_COMPRESS_DEFS_SVH

// ---- completion status (out_status, valid with out_last) --------------------------------------------------------------
`define SF_CST_OK             4'd0   // block completed, output valid
`define SF_CST_TRUNCATED      4'd1   // decoder: compressed block ended inside a sequence, or without a final literal-only sequence
`define SF_CST_OFFSET_ZERO    4'd2   // decoder: match offset 0 (invalid in the LZ4 block format)
`define SF_CST_OFFSET_RANGE   4'd3   // decoder: offset > bytes already produced in this block, or beyond the history window
`define SF_CST_OUT_OVERFLOW   4'd4   // decoder: decompressed size would exceed the capacity given for the block (or MAX_OUT_BYTES)
`define SF_CST_LENGTH         4'd5   // decoder: literal / match length does not fit the length counter
`define SF_CST_BLOCK_SIZE     4'd6   // unsupported block size (decoder: compressed block > MAX_IN_BYTES; encoder: input > BLK_BYTES)
`define SF_CST_EOB_RULE       4'd7   // decoder (STRICT_EOB): last-5-bytes-literal / last-match-12-bytes-from-end rule violated
`define SF_CST_FRAMING        4'd8   // stream protocol violation on the input (first/last flags, non-contiguous byte mask)
`define SF_CST_INCOMPRESSIBLE 4'd9   // encoder: compressed size exceeds the destination capacity, policy ERROR/RAW-without-room: nothing emitted
`define SF_CST_DST_OVERFLOW   4'd10  // encoder, policy STREAM: compressed output reached the destination capacity: stopped, data invalid
`define SF_CST_CRC            4'd11  // decoder: CRC of the decompressed data differs from the expected CRC supplied with the block

// ---- encoder output policy when the compressed block does not fit / does not shrink the data ---------------------------
`define SF_POL_STREAM  2'd0   // single pass; never emit beyond the capacity; on overflow stop with DST_OVERFLOW (partial data invalid)
`define SF_POL_ERROR   2'd1   // two-pass: size is known BEFORE the first output byte; too big -> INCOMPRESSIBLE, no data beat emitted
`define SF_POL_RAW     2'd2   // two-pass: too big / not smaller -> emit the input unchanged, flagged out_raw=1 on every beat

// ---- operating mode (per block, sampled with the first beat) ------------------------------------------------------------
`define SF_MODE_DECOMP 1'b0
`define SF_MODE_COMP   1'b1

`endif
