// =============================================================================
// CompressCore :: sf_lz4_encoder -- baseline streaming LZ4 BLOCK-format compressor (independent blocks), 128-bit stream
//
//   input beats -> INGEST into the block buffer (sf_lz4_history, BLK_BYTES) -> [DRY-RUN pass: size only] -> EMIT pass -> sf_lz4_pack -> beats
//
//   INGEST   dense 16-byte beats are written to the block buffer; blocks larger than BLK_BYTES are drained and rejected (BLOCK_SIZE).
//   SCAN     greedy LZ4 parse with the reference's skip acceleration: step = ACCEL + (misses >> SKIP_SHIFT).  Positions are probed in the match
//            finder (hash table + verification + 16-byte-per-iteration extension).  A match may only START at least 12 bytes before the end of
//            the block and never reaches into the last 5 bytes, so every block is accepted by the reference decoder (LZ4 end-of-block rules).
//   EMIT     token, literal-length extension, literals (read back from the block buffer, 16 bytes per cycle), 2-byte offset, match-length
//            extension, exactly as the LZ4 block format; the last sequence is literal-only.  Blocks < 13 bytes are one literal sequence;
//            an empty block compresses to the single byte 0x00.
//   POLICY   (per block, sampled with the first beat; capacity `in_cap` = bytes available at the destination, 0 = unlimited)
//            STREAM  one pass; the compressed size is not known in advance.  Emission NEVER exceeds the capacity: when the next chunk would,
//                    emission stops and the block completes with DST_OVERFLOW (bytes already emitted, <= capacity, are invalid).
//            ERROR   two passes: pass 1 (dry run) computes the exact compressed size without emitting anything; if it exceeds the capacity the
//                    block completes with INCOMPRESSIBLE and NO data beat was emitted -- the destination is untouched.
//            RAW     as ERROR, but when the compressed block would not fit or would not be SMALLER than the input and the input fits the
//                    capacity, the input is emitted UNCHANGED with out_raw = 1 on every beat (an LZ4 *frame* represents this as an
//                    uncompressed block: block-size word with bit 31 set).  No incompatible LZ4 block marker is invented.
//            The dry-run and emit passes are decision-for-decision identical (table epochs, see sf_lz4_matchfinder), so the size is exact.
//   One block at a time (INGEST of the next block waits for the completion of the previous one); throughput of a block is
//   ingest (16 B/cycle) + scan/emit (data dependent, see benchmarks).  Optional CRC: in_crc (raw-data CRC from the separate CRC stage, valid
//   with in_last) is returned unchanged in out_crc with the completion.
// Classification: SYNTHESIZABLE (block buffer + hash table: sf_lz4_sram_1r1w)
// =============================================================================
`default_nettype none
`include "sf_compress_defs.svh"
module sf_lz4_encoder #(
  parameter int DW         = 128,        // fixed at 128 (checked)
  parameter int TIDW       = 8,
  parameter int BLK_BYTES  = 65536,      // largest input block (power of two, <= 65536); also the block buffer size
  parameter int HASH_BITS  = 12,         // 2^HASH_BITS match-finder entries
  parameter int ACCEL      = 1,          // initial search step (>= 1); larger = faster, lower compression
  parameter int SKIP_SHIFT = 6,          // the step grows by one every 2^SKIP_SHIFT consecutive misses
  parameter int OUTQ_DEPTH = 4,
  localparam int LW        = $clog2(DW / 8)
) (
  input  wire logic            clk,
  input  wire logic            rst_n,
  // raw data in
  input  wire logic            in_valid,
  output logic                 in_ready,
  input  wire logic [DW-1:0]   in_data,
  input  wire logic [LW:0]     in_n,
  input  wire logic            in_first,
  input  wire logic            in_last,
  input  wire logic [TIDW-1:0] in_tid,
  input  wire logic [31:0]     in_cap,       // destination capacity in bytes (0 = unlimited)
  input  wire logic [1:0]      in_policy,    // SF_POL_*
  input  wire logic            in_ferr,
  input  wire logic [31:0]     in_crc,       // CRC of the raw data (valid with in_last), passed through to out_crc
  // compressed block out
  output logic                 out_valid,
  input  wire logic            out_ready,
  output logic      [DW-1:0]   out_data,
  output logic      [LW:0]     out_n,
  output logic                 out_last,
  output logic      [TIDW-1:0] out_tid,
  output logic                 out_raw,      // valid on every beat
  output logic      [3:0]      out_status,   // valid with out_last
  output logic      [31:0]     out_in_bytes,
  output logic      [31:0]     out_out_bytes,
  output logic      [31:0]     out_crc,
  // events
  output logic                 ev_probe,     // hash-table probe issued
  output logic                 ev_hit,       // verified match found
  output logic                 ev_ext_cycle, // cycle spent extending a match
  output logic                 ev_out_stall, // emission stalled by output backpressure
  output logic                 ev_dry_pass,  // cycle spent in a dry-run (sizing) pass
  output logic                 busy
);
  if (DW != 128) begin : g_dw
    illegal_parameter_DW_must_be_128 u_bad ();
  end
  if (BLK_BYTES > 65536 || BLK_BYTES < 64 || (BLK_BYTES & (BLK_BYTES - 1)) != 0) begin : g_blk
    illegal_parameter_BLK_BYTES u_bad2 ();
  end
  if (ACCEL < 1 || ACCEL > 64) begin : g_acc
    illegal_parameter_ACCEL u_bad3 ();
  end

  localparam int PW = 17;
  localparam logic [4:0] ST_IDLE = 5'd0, ST_ING = 5'd1, ST_DECIDE = 5'd2, ST_NP_I = 5'd3, ST_NP_W = 5'd4, ST_SCAN = 5'd5, ST_PR_W = 5'd6,
                         ST_EX_I = 5'd7, ST_EX_W = 5'd8, E_TOK = 5'd9, E_LEXT = 5'd10, E_LRD = 5'd11, E_LPUSH = 5'd12, E_OFF = 5'd13,
                         E_MEXT = 5'd14, ST_IN_I = 5'd15, ST_IN_W = 5'd16, ST_FINAL = 5'd17, ST_PDONE = 5'd18, ST_FIN = 5'd19;

  logic [4:0]      st;
  // ---- per-block configuration
  logic [TIDW-1:0] tid_q;
  logic [31:0]     cap_q;
  logic [1:0]      pol_q;
  logic [31:0]     crc_q;
  logic            ferr_q, size_err_q, raw_q, dry_q, abort_q, raw_mode_q;
  logic [31:0]     in_cnt_q;
  logic [3:0]      status_q;
  logic [31:0]     cb_q, emit_q, lim_q;       // compressed bytes counted in this pass, bytes actually emitted, limit for the pass
  // ---- scan / sequence
  logic [PW-1:0]   pos_q, anchor_q, cand_q, lit_src_q, lit_rem_q, mlen_q;
  logic [15:0]     miss_q;
  logic [15:0]     off_q;
  logic            has_match_q;
  logic [PW-1:0]   lext_q;                    // remaining extension value (literal length - 15, or match length - 19)

  wire [PW-1:0] n_blk   = in_cnt_q[PW-1:0];
  wire [31:0]   cap_eff = (cap_q == 32'd0) ? 32'hFFFF_FFFF : cap_q;
  wire          is_stream = (pol_q != `SF_POL_ERROR) && (pol_q != `SF_POL_RAW);

  // ---- ingest arithmetic (the first beat of a block starts from zero, whatever the previous block left behind)
  wire          st_idle   = (st == ST_IDLE);
  wire [31:0]   ing_base  = st_idle ? 32'd0 : in_cnt_q;
  wire [32:0]   ing_sum   = {1'b0, ing_base} + {28'd0, in_n};
  wire          ing_fits  = (st_idle || !size_err_q) && (ing_sum <= 33'(BLK_BYTES));

  // ---- block buffer
  logic            hist_wr_valid, hist_rd_valid;
  logic [PW-1:0]   hist_rd_pos;
  logic [DW-1:0]   hist_rd_data;
  wire  [PW-1:0]   wr_pos = ing_base[PW-1:0];
  sf_lz4_history #(.DW(DW), .HIST_BYTES(BLK_BYTES), .POSW(PW)) u_bb (
    .clk(clk), .wr_valid(hist_wr_valid), .wr_pos(wr_pos), .wr_n(in_n), .wr_data(in_data),
    .rd_valid(hist_rd_valid), .rd_pos(hist_rd_pos), .rd_data(hist_rd_data)
  );

  // ---- match finder
  logic            mf_cmd_valid, mf_cmd_ready, mf_rsp_valid, mf_rsp_found, mf_rd_valid;
  logic [1:0]      mf_op;
  logic [PW-1:0]   mf_pos, mf_cand, mf_limit, mf_rsp_cand, mf_rsp_len, mf_rd_pos;
  sf_lz4_matchfinder #(.HASH_BITS(HASH_BITS), .PW(PW)) u_mf (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(mf_cmd_valid), .cmd_ready(mf_cmd_ready), .cmd_op(mf_op), .cmd_pos(mf_pos), .cmd_cand(mf_cand), .cmd_limit(mf_limit),
    .rsp_valid(mf_rsp_valid), .rsp_found(mf_rsp_found), .rsp_cand(mf_rsp_cand), .rsp_len(mf_rsp_len),
    .bb_rd_valid(mf_rd_valid), .bb_rd_pos(mf_rd_pos), .bb_rd_data(hist_rd_data)
  );

  // ---- output packer (tid carries the raw flag in its top bit)
  logic            pk_valid, pk_ready, pk_end, pk_busy;
  logic [DW-1:0]   pk_data;
  logic [LW:0]     pk_n;
  logic [99:0]     pk_side;
  logic [TIDW:0]   o_tid;
  sf_lz4_pack #(.DW(DW), .TIDW(TIDW + 1), .SIDEW(100), .FDEPTH(OUTQ_DEPTH)) u_pack (
    .clk(clk), .rst_n(rst_n),
    .in_valid(pk_valid), .in_ready(pk_ready), .in_data(pk_data), .in_n(pk_n), .in_end(pk_end), .in_tid({raw_q, tid_q}), .in_side(pk_side),
    .out_valid(out_valid), .out_ready(out_ready), .out_data(out_data), .out_n(out_n), .out_last(out_last), .out_tid(o_tid),
    .out_side({out_status, out_in_bytes, out_out_bytes, out_crc}), .busy(pk_busy)
  );
  assign out_tid = o_tid[TIDW-1:0];
  assign out_raw = o_tid[TIDW];

  // ===========================================================================================================================
  //  emission chunk generation
  // ===========================================================================================================================
  logic [7:0]    tok;
  logic [31:0]   ch_n;
  logic          ch_valid;
  logic [DW-1:0] ch_data;
  logic [4:0]    ext_k;                 // number of 0xFF bytes in this extension chunk
  logic [7:0]    ext_r;                 // terminating byte
  logic          ext_last;              // this chunk completes the extension
  logic [PW-1:0] ext_next;
  always_comb begin
    // extension chunk (shared by the literal-length and match-length extensions): k x 0xFF, then the remainder byte (< 255)
    ext_k = 5'd0; ext_r = 8'd0; ext_last = 1'b1; ext_next = lext_q;
    if (lext_q >= PW'(4080)) begin
      ext_k = 5'd16; ext_last = 1'b0; ext_next = lext_q - PW'(4080);
    end else begin
      for (int j = 1; j <= 15; j++) if (lext_q >= PW'(255 * j)) ext_k = 5'(j);
      ext_r = 8'(lext_q - PW'(255) * PW'(ext_k));
    end
    tok = {((lit_rem_q >= PW'(15)) ? 4'd15 : lit_rem_q[3:0]),
           (has_match_q ? ((mlen_q >= PW'(19)) ? 4'd15 : 4'(mlen_q - PW'(4))) : 4'd0)};
  end

  always_comb begin
    ch_valid = 1'b0; ch_n = 32'd0; ch_data = '0;
    case (st)
      E_TOK:  begin ch_valid = 1'b1; ch_n = 32'd1; ch_data = {{(DW-8){1'b0}}, tok}; end
      E_LEXT, E_MEXT: begin
        ch_valid = 1'b1; ch_n = 32'(ext_k) + (ext_last ? 32'd1 : 32'd0);
        for (int i = 0; i < 16; i++) ch_data[8*i +: 8] = (5'(i) < ext_k) ? 8'hFF : ((5'(i) == ext_k && ext_last) ? ext_r : 8'h00);
      end
      E_OFF:  begin ch_valid = 1'b1; ch_n = 32'd2; ch_data = {{(DW-16){1'b0}}, off_q[15:8], off_q[7:0]}; end
      E_LRD:  begin if (dry_q) begin ch_valid = 1'b1; ch_n = {15'd0, lit_rem_q}; end end       // dry run: count the literals, no read
      E_LPUSH: begin ch_valid = 1'b1; ch_n = (lit_rem_q >= PW'(16)) ? 32'd16 : {15'd0, lit_rem_q}; ch_data = hist_rd_data; end
      default: ;
    endcase
  end

  wire [32:0] cb_new  = {1'b0, cb_q} + {1'b0, ch_n};
  wire        c_over  = ch_valid && (cb_new > {1'b0, lim_q});
  wire        c_can   = dry_q || pk_ready;
  wire        c_fire  = ch_valid && !c_over && c_can;

  // ===========================================================================================================================
  //  control
  // ===========================================================================================================================
  wire             in_fire = in_valid && in_ready;
  logic [PW-1:0]   step;
  logic            scan_cond;
  assign in_ready  = (st == ST_IDLE) || (st == ST_ING);
  assign step      = PW'(ACCEL) + (PW'(miss_q) >> SKIP_SHIFT);
  assign scan_cond = (n_blk >= PW'(13)) && (pos_q <= (n_blk - PW'(12)));

  wire [PW-1:0] seq_end_pos = pos_q + mlen_q;

  always_comb begin
    hist_wr_valid = in_fire && (in_n != '0) && ing_fits;
    hist_rd_valid = mf_rd_valid || (st == E_LRD && !dry_q && lit_rem_q != '0) || (st == E_LPUSH && c_fire && (lit_rem_q > PW'(16)));
    hist_rd_pos   = mf_rd_valid ? mf_rd_pos : ((st == E_LPUSH) ? (lit_src_q + PW'(16)) : lit_src_q);
    // match finder command
    mf_cmd_valid = 1'b0; mf_op = 2'd0; mf_pos = pos_q; mf_cand = cand_q; mf_limit = n_blk - PW'(5);
    case (st)
      ST_NP_I:  begin mf_cmd_valid = 1'b1; mf_op = 2'd0; end
      ST_SCAN:  begin mf_cmd_valid = scan_cond; mf_op = 2'd1; end
      ST_EX_I:  begin mf_cmd_valid = 1'b1; mf_op = 2'd2; end
      ST_IN_I:  begin mf_cmd_valid = 1'b1; mf_op = 2'd3; mf_pos = pos_q - PW'(2); end
      default: ;
    endcase
    // packer item
    // the chunk size is presented unconditionally (the packer's readiness depends on it); `valid` alone gates the transfer
    pk_valid = 1'b0; pk_end = 1'b0; pk_n = ch_valid ? ch_n[LW:0] : '0; pk_data = ch_data; pk_side = '0;
    if (c_fire && !dry_q) pk_valid = 1'b1;
    if (st == ST_FIN) begin
      pk_valid = 1'b1; pk_end = 1'b1; pk_n = '0;
      pk_side = {status_q, in_cnt_q, emit_q, crc_q};
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= ST_IDLE; tid_q <= '0; cap_q <= '0; pol_q <= '0; crc_q <= '0; ferr_q <= 1'b0; size_err_q <= 1'b0; raw_q <= 1'b0; dry_q <= 1'b0;
      abort_q <= 1'b0; raw_mode_q <= 1'b0; in_cnt_q <= '0; status_q <= '0; cb_q <= '0; emit_q <= '0; lim_q <= '0;
      pos_q <= '0; anchor_q <= '0; cand_q <= '0; lit_src_q <= '0; lit_rem_q <= '0; mlen_q <= '0; miss_q <= '0; off_q <= '0;
      has_match_q <= 1'b0; lext_q <= '0;
    end else begin
      case (st)
        // ------------------------------------------------------------------------------------------------------------ ingest
        ST_IDLE, ST_ING: begin
          if (in_fire) begin
            if (st_idle) begin
              tid_q <= in_tid; cap_q <= in_cap; pol_q <= in_policy; ferr_q <= 1'b0; raw_q <= 1'b0; emit_q <= '0;
              abort_q <= 1'b0; raw_mode_q <= 1'b0; status_q <= `SF_CST_OK;
            end
            in_cnt_q <= ing_sum[31:0];
            size_err_q <= !ing_fits;
            if (in_last) begin crc_q <= in_crc; ferr_q <= in_ferr; st <= ST_DECIDE; end
            else st <= ST_ING;
          end
        end
        // ------------------------------------------------------------------------------------------------------------ plan
        ST_DECIDE: begin
          cb_q <= '0;
          if (size_err_q)  begin status_q <= `SF_CST_BLOCK_SIZE; st <= ST_FIN; end
          else if (ferr_q) begin status_q <= `SF_CST_FRAMING;    st <= ST_FIN; end
          else if (is_stream) begin dry_q <= 1'b0; lim_q <= cap_eff; st <= ST_NP_I; end
          else if (pol_q == `SF_POL_ERROR) begin dry_q <= 1'b1; lim_q <= cap_eff; st <= ST_NP_I; end
          else if (in_cnt_q == 32'd0) begin            // RAW, empty input: the 1-byte compressed form can never be smaller -> raw (0 bytes)
            raw_q <= 1'b1; raw_mode_q <= 1'b1; dry_q <= 1'b0; st <= ST_FIN;
          end else begin                               // RAW: acceptable compressed size < input size and <= capacity
            dry_q <= 1'b1; lim_q <= (cap_eff < (in_cnt_q - 32'd1)) ? cap_eff : (in_cnt_q - 32'd1); st <= ST_NP_I;
          end
        end
        // ------------------------------------------------------------------------------------------------------------ new pass
        ST_NP_I: if (mf_cmd_ready) st <= ST_NP_W;
        ST_NP_W: if (mf_rsp_valid) begin
          pos_q <= '0; anchor_q <= '0; miss_q <= '0; cb_q <= '0; abort_q <= 1'b0; st <= ST_SCAN;
        end
        // ------------------------------------------------------------------------------------------------------------ scan
        ST_SCAN: begin
          if (!scan_cond) st <= ST_FINAL;
          else if (mf_cmd_ready) st <= ST_PR_W;
        end
        ST_PR_W: if (mf_rsp_valid) begin
          if (mf_rsp_found) begin cand_q <= mf_rsp_cand; st <= ST_EX_I; end
          else begin miss_q <= miss_q + 16'd1; pos_q <= pos_q + step; st <= ST_SCAN; end
        end
        ST_EX_I: if (mf_cmd_ready) st <= ST_EX_W;
        ST_EX_W: if (mf_rsp_valid) begin
          mlen_q <= mf_rsp_len; off_q <= 16'(pos_q - cand_q); has_match_q <= 1'b1;
          lit_src_q <= anchor_q; lit_rem_q <= pos_q - anchor_q;
          st <= E_TOK;
        end
        // ------------------------------------------------------------------------------------------------------------ emission
        E_TOK: begin
          if (c_over) begin abort_q <= 1'b1; st <= ST_PDONE; end
          else if (c_fire) begin
            cb_q <= cb_new[31:0]; if (!dry_q) emit_q <= emit_q + ch_n;
            if (lit_rem_q >= PW'(15)) begin lext_q <= lit_rem_q - PW'(15); st <= E_LEXT; end
            else if (lit_rem_q != '0) st <= E_LRD;
            else st <= has_match_q ? E_OFF : ST_PDONE;
          end
        end
        E_LEXT: begin
          if (c_over) begin abort_q <= 1'b1; st <= ST_PDONE; end
          else if (c_fire) begin
            cb_q <= cb_new[31:0]; if (!dry_q) emit_q <= emit_q + ch_n;
            lext_q <= ext_next;
            if (ext_last) st <= E_LRD;
          end
        end
        E_LRD: begin
          if (dry_q) begin
            if (c_over) begin abort_q <= 1'b1; st <= ST_PDONE; end
            else begin cb_q <= cb_new[31:0]; st <= has_match_q ? E_OFF : ST_PDONE; end
          end else if (lit_rem_q == '0) st <= raw_mode_q ? ST_FIN : (has_match_q ? E_OFF : ST_PDONE);
          else st <= E_LPUSH;                      // the block-buffer read was issued this cycle
        end
        E_LPUSH: begin
          if (c_over) begin abort_q <= 1'b1; st <= ST_PDONE; end
          else if (c_fire) begin
            cb_q <= cb_new[31:0]; emit_q <= emit_q + ch_n;
            lit_src_q <= lit_src_q + PW'(16);
            lit_rem_q <= (lit_rem_q >= PW'(16)) ? (lit_rem_q - PW'(16)) : '0;
            if (lit_rem_q <= PW'(16)) st <= raw_mode_q ? ST_FIN : (has_match_q ? E_OFF : ST_PDONE);
          end
        end
        E_OFF: begin
          if (c_over) begin abort_q <= 1'b1; st <= ST_PDONE; end
          else if (c_fire) begin
            cb_q <= cb_new[31:0]; if (!dry_q) emit_q <= emit_q + ch_n;
            if (mlen_q >= PW'(19)) begin lext_q <= mlen_q - PW'(19); st <= E_MEXT; end
            else begin pos_q <= seq_end_pos; anchor_q <= seq_end_pos; miss_q <= '0; st <= ST_IN_I; end
          end
        end
        E_MEXT: begin
          if (c_over) begin abort_q <= 1'b1; st <= ST_PDONE; end
          else if (c_fire) begin
            cb_q <= cb_new[31:0]; if (!dry_q) emit_q <= emit_q + ch_n;
            lext_q <= ext_next;
            if (ext_last) begin pos_q <= seq_end_pos; anchor_q <= seq_end_pos; miss_q <= '0; st <= ST_IN_I; end
          end
        end
        ST_IN_I: if (mf_cmd_ready) st <= ST_IN_W;
        ST_IN_W: if (mf_rsp_valid) st <= ST_SCAN;
        // ------------------------------------------------------------------------------------------------------------ final literals
        ST_FINAL: begin
          has_match_q <= 1'b0; lit_src_q <= anchor_q; lit_rem_q <= n_blk - anchor_q; st <= E_TOK;
        end
        // ------------------------------------------------------------------------------------------------------------ end of a pass
        ST_PDONE: begin
          if (dry_q) begin
            if (abort_q) begin
              // not acceptable: ERROR -> incompressible; RAW -> raw copy if the input fits the capacity, else incompressible
              if (pol_q == `SF_POL_RAW && {1'b0, in_cnt_q} <= {1'b0, cap_eff}) begin
                raw_q <= 1'b1; raw_mode_q <= 1'b1; dry_q <= 1'b0; cb_q <= '0; lim_q <= cap_eff; lit_src_q <= '0; lit_rem_q <= n_blk; st <= E_LRD;
              end else begin status_q <= `SF_CST_INCOMPRESSIBLE; st <= ST_FIN; end
            end else begin
              dry_q <= 1'b0; lim_q <= cap_eff; st <= ST_NP_I;       // acceptable: now emit for real
            end
          end else begin
            if (abort_q) status_q <= `SF_CST_DST_OVERFLOW;
            st <= ST_FIN;
          end
        end
        ST_FIN: if (pk_ready) st <= ST_IDLE;
        default: st <= ST_IDLE;
      endcase
    end
  end

  assign ev_probe     = (st == ST_SCAN) && scan_cond && mf_cmd_ready;
  assign ev_hit       = (st == ST_PR_W) && mf_rsp_valid && mf_rsp_found;
  assign ev_ext_cycle = (st == ST_EX_W) && !mf_rsp_valid;
  assign ev_out_stall = ch_valid && !dry_q && !pk_ready;
  assign ev_dry_pass  = dry_q && (st != ST_IDLE) && (st != ST_ING) && (st != ST_FIN);
  assign busy         = (st != ST_IDLE) || pk_busy;
  wire unused_first = in_first;
endmodule
`default_nettype wire
