// =============================================================================
// CompressCore :: sf_lz4_fifo -- small synchronous first-word-fall-through FIFO (power-of-two depth, register-file storage)
//   push is ignored when full, pop is ignored when empty (callers gate with full/empty).  flush empties it (priority).
//   No push/pop bypass: a full FIFO accepts a push only after the pop of an earlier cycle.
// Classification: SYNTHESIZABLE
// =============================================================================
`default_nettype none
module sf_lz4_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 4,                 // power of two, >= 2
  localparam int AW   = $clog2(DEPTH),
  localparam int CW   = $clog2(DEPTH + 1)
) (
  input  wire logic          clk,
  input  wire logic          rst_n,
  input  wire logic          flush,
  input  wire logic          push,
  input  wire logic [W-1:0]  din,
  input  wire logic          pop,
  output logic      [W-1:0]  dout,
  output logic               full,
  output logic               empty,
  output logic      [CW-1:0] count
);
  if (DEPTH < 2 || (DEPTH & (DEPTH - 1)) != 0) begin : g_bad_depth
    illegal_parameter_DEPTH_must_be_a_power_of_two_ge_2 u_bad ();
  end

  logic [W-1:0]  mem [DEPTH];
  logic [AW-1:0] rp, wp;

  assign full  = (count == CW'(DEPTH));
  assign empty = (count == '0);
  assign dout  = mem[rp];

  wire do_push = push && !full;
  wire do_pop  = pop  && !empty;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rp <= '0; wp <= '0; count <= '0;
    end else if (flush) begin
      rp <= '0; wp <= '0; count <= '0;
    end else begin
      if (do_push) wp <= wp + 1'b1;
      if (do_pop)  rp <= rp + 1'b1;
      count <= count + (do_push ? CW'(1) : '0) - (do_pop ? CW'(1) : '0);
    end
  end
  always_ff @(posedge clk) begin
    if (do_push) mem[wp] <= din;
  end
endmodule
`default_nettype wire
