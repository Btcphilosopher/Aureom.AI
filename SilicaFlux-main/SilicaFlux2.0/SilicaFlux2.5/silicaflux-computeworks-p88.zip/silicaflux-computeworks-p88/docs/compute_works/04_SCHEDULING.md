# 04 · Scheduling (brief §7)

## One queue (the reference configuration)

`NUM_QUEUES = 1`: a FIFO of `CMD_QUEUE_DEPTH` descriptors. The scheduler takes the head when idle, validates it, runs it, pushes
exactly one completion record, and takes the next. **One command is in flight at a time** (reference configuration:
*one outstanding compute command*). Submission back-pressures (`sub_ready` low) when the queue is full; nothing is dropped.

## Multiple protected queues

`NUM_QUEUES` = 1…4 (1, 2 and 4 verified). Each queue has its **own storage** (one tenant's backlog cannot displace another's
descriptors; verified by filling every queue to depth with a fixed arbitration order) and its own hardware-programmed
configuration, set by the management plane only (`CW_POL_BIND_QUEUE`, accepted only while the tile is idle):

| Field | Meaning |
|---|---|
| domain | the security domain the queue belongs to; a descriptor's `DOM` must equal it |
| priority class | 0..3, 3 = highest |
| default destination | where a *rejected* command's completion goes |
| enable | a disabled queue is parked: nothing is scheduled from it, nothing is lost |
| RR quantum | 1..15 consecutive commands per turn (0 means 1) |
| work budget | per-command resource limit (`0` = none): GEMM `M·N·K`, vector `VL`, CLEAR `LEN`; above it → `CW_ST_RESLIMIT` |

A queue that was never bound is **unbound**: its commands are still scheduled (so a submitter always gets an answer) and are
rejected with `CW_ST_OWNER`.

### Arbitration (specified; independently modelled in `model/cwlib.py::ArbModel`)

State: `last` (last winner), `sticky` (consecutive commands served to it), `wait[q]` (decisions lost while eligible).

1. *Eligible*: non-empty and enabled.
2. *Class*: the queue's priority class, **raised to 3 if it has lost `STARVE_LIMIT` (16) consecutive decisions while eligible** (ageing).
3. Only queues of the **highest class** present are candidates (strict priority between classes).
4. If `last` is still a candidate and `sticky < quantum[last]`, it keeps the tile (**quantum**).
5. Otherwise **round robin**: the first candidate after `last`.
6. After the decision: the winner's `wait` clears; every other *eligible* queue's `wait` increments; `sticky` counts the winner's run.

Properties checked by the regression (168 completions per run, 4 queues): plain RR order; quanta 3/1/2/1; strict priority with
ageing promoting starved queues; mixed classes; a disabled queue parked, then released; completion back-pressure at 30 % ready.
The hardware's completion order is compared with the model's **exactly**.

Strict priority *can* starve a lower class; the ageing bound limits that to `STARVE_LIMIT` decisions for any eligible queue.
No bandwidth guarantee or latency bound in cycles is claimed: the time of a decision depends on the commands ahead of it.

### Resource limits

Per queue: the work budget above. Per tile: `K ≤ KMAX` (staging), local SRAM range. These reject at validation time, before any
resource is consumed.

## Context switching

Queues are switched **only at command boundaries**. A command carries all its state in memory (descriptor fields and buffers);
the tile keeps nothing between commands except the arbitration counters and, optionally, nothing else (staging is zeroed). So
there is **nothing to save or restore**.

> **No mid-kernel preemption exists and none is claimed.** A started command runs to completion; the reused arrays (TENSORCORE 02,
> HPC M03) and IronMemory do not expose a way to save and restore execution state, and this tile does not try. A long command
> delays every other queue by its duration (the benchmark's 32×32×256 GEMM is ~36 k cycles). Software that needs bounded latency
> must bound command size (the per-queue work budget exists for that).

## Policy changes and the scheduler

Policy operations (`pol_*`) are accepted only while no command is between dispatch and completion (`pol_ready = idle`), and the
scheduler does not start a command in the same cycle a policy operation is accepted. A command therefore always sees one
consistent policy from decode to completion (tested: a policy operation issued behind a long GEMM does not complete until the GEMM
has completed). A multi-cycle `SCRUB` keeps the scheduler stopped until the zero-fill finishes.

## Clock enable

`clk_en_i` gates **dispatch only**. A command already started always completes; the next waits. `clk_gate_ok_o` is high only when
the scheduler is idle, all queues and the completion FIFO are empty, all memory engines idle and no policy operation is running.
(`07_VERIFICATION.md`: `p3_clken`.)
