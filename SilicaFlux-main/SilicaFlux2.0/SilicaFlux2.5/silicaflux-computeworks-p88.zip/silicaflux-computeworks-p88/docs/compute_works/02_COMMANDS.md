# 02 · Command descriptors, validation and completion (brief §3, §5)

The encodings are defined **once**, in `rtl/albion/sf_compute_defs.svh`; `model/cw_defs.py` is generated from it
(`scripts/gen_defs.py`, checked by `run_tests.py`). Never renumber, only append.

## 1. Descriptor (8 × 32-bit words, little endian, pushed into a queue)

| Word | Bits | Field | Meaning |
|---|---|---|---|
| W0 | 7:0 | `OP` | operation (below) |
| | 15:8 | `ETYPE` | element type (below) |
| | 18:16 | `RM` | FP rounding mode: RNE 0, RTZ 1, RDN 2, RUP 3, RMM 4 (RISC-V `frm`). Ignored for integer types. |
| | 19 | `ACC` | GEMM only: `D = C_in + A·B` (INT32 accumulation into `SRC_C`) |
| | 31:20 | reserved | must be 0 (`CW_ST_BAD_FLAGS`) |
| W1 | 15:0 | `TAG` | transaction tag, echoed in the completion record |
| | 18:16 | `DOM` | the **claimed** security domain. Never trusted: it must equal the queue's hardware-bound domain. |
| | 22:19 | `DEST` | completion destination (must be allowed for the domain) |
| | 31:23 | reserved | must be 0 |
| W2 / W3 / W4 | | `SRC_A / SRC_B / SRC_C` | byte addresses of operands A, B, C |
| W5 | | `DST` | byte address of the result |
| W6 | 15:0 / 31:16 | `M` / `N` | GEMM rows / columns. For vector ops **all 32 bits are `VL`** (elements); for `CLEAR` all 32 bits are `LEN` (bytes). |
| W7 | 15:0 | `K` | GEMM inner dimension |
| | 31:16 | reserved | must be 0 |

Unused words of an operation are ignored. Operand addresses are byte addresses inside the local SRAM window
(`SRAM_BASE = 0x1000_0000`, size = banks × depth × word bytes).

### Operations and element types

| `OP` | Name | Semantics | Element type |
|---|---|---|---|
| 0 | `NOP` | completes immediately (still subject to ownership / flag / destination checks) | — |
| 1 | `VADD` | `D[i] = A[i] + B[i]` | FP32 (`FADD`) or INT32 (`IADD`, mod 2³²) |
| 2 | `VMUL` | `D[i] = A[i] × B[i]` | FP32 (`FMUL`) or INT32 (`IMUL`, mod 2³²) |
| 3 | `VFMA` | `D[i] = A[i] × B[i] + C[i]`, **one rounding** | FP32 only |
| 4 | `GEMM` | `D[M,N] = A[M,K] × B[K,N]` (+ `C[M,N]`), INT8 × INT8 → INT32 | INT8 only |
| 5 | `CLEAR` | zero-fill `LEN` bytes at `DST` | — |

| `ETYPE` | | |
|---|---|---|
| 0 | FP32 | supported (VADD, VMUL, VFMA) |
| 1 | INT8 | supported (GEMM) |
| 2 | INT32 | supported (VADD, VMUL) |
| 3 / 4 / 5 | **FP16 / BF16 / FP64** | **not implemented → rejected** (`CW_ST_BAD_ETYPE`) |
| other | reserved | rejected |

An element type that is legal for *some* operation but not for this one (INT8 on `VADD`, FP32 on `GEMM`, INT32 on `VFMA`, …) is
rejected the same way. No code path converts between formats.

### Memory layouts

Little endian, packed, row major: A is `M × K` INT8 (`lda = K`), B is `K × N` INT8 (`ldb = N`), C and D are `M × N` INT32
(`ldc = ldd = N`). Vectors are `VL` contiguous 4-byte elements. A and B may start at **any byte address**; every INT32 / FP32
buffer (C, D, vector operands, `CLEAR` target and length) must be 4-byte aligned.

Operand ordering is part of the contract and is tested with non-symmetric matrices: the array pairs `A[i][k]` with `B[k][j]` and
produces `D[i][j]`; `A×B`, `B×A` and `A×Bᵀ` all differ for the test vectors.

## 2. Validation (before any side effect)

First failing rule wins; the order is part of the ABI (`sf_compute_decoder.sv`, re-implemented independently in
`model/cwlib.py::validate`, fuzzed against the RTL).

| # | Status | Rule | `DETAIL` |
|---|---|---|---|
| 1 | `OWNER` 7 | queue unbound, or claimed `DOM` ≠ the queue's bound domain | `{bound, claim}` = bit 3 / bits 2:0 |
| 2 | `BAD_FLAGS` 12 | reserved bits set; `ACC` on a non-GEMM op; FP32 rounding mode > 4 | `RM` |
| 3 | `BAD_DEST` 9 | `DEST` not in the domain's destination mask | `DEST` |
| 4 | `BAD_OP` 1 | `OP` > 5, or a vector op when `EN_VECTOR = 0` | `OP` |
| 5 | `BAD_ETYPE` 2 | unsupported / reserved / wrong-for-op element type | `ETYPE` |
| 6 | `BAD_DIMS` 3 | `M`, `N`, `K`, `VL` or `LEN` = 0 | 1 M, 2 N, 3 K, 4 VL, 5 LEN |
| 7 | `RESLIMIT` 10 | `K > KMAX` (staging capacity), or work > the queue's budget (GEMM: `M·N·K`; vector: `VL`; CLEAR: `LEN`) | 1 K, 3 budget |
| 8 | `BAD_ALIGN` 4 | a 4-byte-aligned buffer / length is not | first offending operand (1 A, 2 B, 3 C, 4 D) |
| 9 | `BAD_RANGE` 5 | any buffer not entirely inside the local SRAM (computed in 40 bits: no wrap) | operand id |
| 10 | `OVERLAP` 6 | vector: result partially overlaps A/B/C (identical = in place is **allowed**); GEMM: result intersects A or B; with `ACC`, partially overlaps C (identical = in place **allowed**) | operand id |
| 11 | `DENIED` 8 | the isolation check refused an operand range (applied by the scheduler, per operand in A, B, C, D order) | `{fault[7:4], operand[3:0]}` |

Faults (Meridian's numbering): `1 NOMAP` (no single region contains the range), `2 PERM` (right missing, e.g. writing a read-only
region), `3 DOMAIN` (region belongs to another domain), `6 CITTMO` (external Citadel did not answer: fail closed).

A rejected command has **no side effect on memory**: the regression fuzzes 880 random descriptors (4 seeds × 220; 1,760 over the 8 seeds run in development) and compares the whole SRAM
with the model after every few commands. It receives exactly one completion, whose destination is the claimed `DEST` only if that
was validated, otherwise the queue's default destination, otherwise destination 0.

Execution-time errors: `MEM_ERR` 11 with `DETAIL = {phase[15:12], 0, code[2:0]}`; phases 1 load-A, 2 load-B, 3 load-C, 4 store,
5 clear, `F` internal consistency; `code` is IronMemory's response code (3 PERM, 4 ECC uncorrectable, 6 BOUNDS, …). A command
that fails while loading stores nothing. A multi-block GEMM that fails while storing block *n* leaves the blocks stored before
it in memory (documented, tested only for the single-failure cases).

## 3. Completion record

One per submitted descriptor, in order per queue.

| Field | Meaning |
|---|---|
| `queue` | the queue it came from |
| `domain` | the **hardware-bound** domain of that queue – never the descriptor's claim |
| `dest` | the destination (always allowed for `domain`; checked by an assertion on every completion) |
| `tag`, `op` | echoed from the descriptor |
| `status`, `detail` | as above |
| `fflags` | OR of the FP exception flags `{NV, DZ, OF, UF, NX}` over all elements (RISC-V `fflags` bit order); 0 for non-FP ops |
| `out_bytes` | bytes written (0 for a rejected or failed command) |
| `cycles` | dispatch → completion pushed |
| `qwait` | enqueue → dispatch |
| `seq` | running count of completions since reset |

## 4. Worked examples (from `model/cwlib.py::pack_desc`)

SRAM at `0x1000_0000`, tenant domain 1, queue 0, destination 0:

```
GEMM 4x4x4 INT8   00000104 00011001 10000000 10000800 10001000 10001800 00040004 00000004
                  W0: OP=4 (GEMM), ETYPE=1 (INT8)   W1: TAG=0x1001, DOM=1   A=0x10000000 B=0x10000800 DST=0x10001800
                  W6: M=4,N=4   W7: K=4            ->  16 INT32 results (64 bytes) at 0x10001800, status 0
VFMA 64 elements  00000003 00092002 10000000 10000800 10001000 10001800 00000040 00000000
                  OP=3 (VFMA), FP32, RNE;  DEST=1;  VL = 0x40 (all of W6)
VADD on FP16      00000301 00013003 ...                                        -> status 2 BAD_ETYPE, detail 3
```

Software flow: Keystone allocates an IronMemory buffer (`ALLOC_AT`), programs the tenant region, binds the queue and sets the
destination mask (`CW_POL_*`, only accepted while the tile is idle), the BridgeEngine loads operands, the tenant submits
descriptors, completions come back with the status above.
