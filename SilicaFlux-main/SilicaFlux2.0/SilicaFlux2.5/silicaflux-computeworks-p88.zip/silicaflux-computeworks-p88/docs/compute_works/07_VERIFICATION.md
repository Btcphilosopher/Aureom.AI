# 07 · Verification (brief §8, §11)

Counts and pass/fail of the final run are in `reports/regression.md`, `reports/mutation.md` and `reports/lint.md` (generated; they
are the authority, not this text). Everything here is **RTL simulation** with Verilator 5.020; the tile also elaborates in Icarus 12
(elaboration only: Icarus does not support constant selects in `always_*` blocks, so no Icarus simulation is claimed).
No formal proof, gate-level simulation, FPGA or silicon result exists.

## Method

* One **system testbench** (`tests/compute_works/tb_compute_tile.sv`) drives the real ports of `sf_compute_tile` from a script:
  buffer-manager commands, tenant policy, descriptors, operand data through the BridgeEngine port, completions, resets, clock
  enable, CSR access, ECC fault injection, concurrent background traffic. The testbench contains **no arithmetic and no expected values**.
* All expected values come from **independent Python models** (`model/`), written from the specification, not translated from the RTL:

| Model | What it predicts | How it is validated itself |
|---|---|---|
| `fp32ref.py` | IEEE-754 binary32 add, multiply, fused multiply-add in all 5 rounding modes, with exception flags and RISC-V NaN / zero-sign conventions. **Exact rational arithmetic** (`fractions.Fraction`), one final rounding. | Against **numpy** (an independent IEEE implementation) on 20 000 corner-biased vectors for add / mul (RNE), and a **neighbour-bracket test** (numpy `nextafter`) on ~40 000 (vector, rounding-mode) pairs for FMA including exact ties. |
| `cwlib.gemm_ref` | INT8 GEMM with INT32 wrap-around accumulation | plain Python integers |
| `cwlib.validate` | the descriptor validation precedence | independent restatement of `02_COMMANDS.md`; fuzzed against the RTL |
| `cwlib.GuardModel` | region table lifecycle, range check, fault codes, policy statuses | independent restatement of `05_ISOLATION.md` |
| `cwlib.ArbModel` | queue arbitration order | independent restatement of `04_SCHEDULING.md` |
| `cwlib.Mem` | byte-accurate shadow of the whole local SRAM | every script ends by comparing **the entire SRAM** with it, so any stray write anywhere fails |
| `cwlib.Tally` | exactly-predictable performance counters | compared with the hardware counters |

The reused blocks' own verification (SoftFloat vectors, mutation, formal-like checks) is **not** repeated; this project verifies the *integration* and
everything new. The independent FP32 model agreeing with the reused lanes is, in effect, a second, unrelated cross-check of them.

## Brief §11 → tests

| Required | Test (suite, in `tests/compute_works/gen_tests.py`) |
|---|---|
| **Vector arithmetic** | `p2_fp32` (corner-biased random data; VADD / VMUL / VFMA; all 5 rounding modes; odd lengths; lengths straddling the chunk boundary; in-place), `p2_special` (every pair of 24 special values — ±0, ±1, ±∞, quiet and signalling NaNs, subnormal edges, max / min — through every op and rounding mode), `p2_int32` |
| **Tensor GEMM** | `p1_single` (the single 4×4 operation, three ways), `p1_gemm`, `p1_overflow` |
| **Mixed workloads** | `p2_mixed` (GEMM + FP32 + INT32 interleaved on shared staging and engines) |
| **SRAM access** | `tb_adapter` (unit: random 2-D READ / WRITE / FILL at arbitrary alignment, stride and pitch, 1 or 2 engines, 64 / 128 bit, vs a byte-level shadow of memory *and* of all four staging buffers) and the whole-SRAM compare in every suite |
| **DMA** | every operand load and result read-back goes through the BridgeEngine port; `p3_backpressure` adds a concurrent master creating real bank conflicts, with its own self-checking data pattern |
| **Command ordering** | one completion per submission, in order per queue (`p3_backpressure` phase B, 36 commands with a stalled completion path), arbitration order (`p3_queues`) |
| **Backpressure** | submit side (2-deep queues, `bp` configuration), completion side (6 % ready, 2-deep FIFO: the runner asserts the scheduler really stalled), memory side (concurrent master), payload stability while stalled (checked on every cycle of every run) |
| **Reset** | `p3_reset`: during a long GEMM with queued commands; no completion survives; SRAM re-reads as zero; policy back to default deny; works again |
| **Invalid precision** | `p3_reject_table` (FP16, BF16, FP64, reserved codes, on every op that takes a type, plus type / op mismatches), `p3_validate` |
| **Buffer bounds** | `p3_reject_table` + `p3_validate`: out-of-window, one byte over the end, exactly at the end (accepted), 32-bit length wrap, near-region-edge ranges in `p3_isolation`; IronMemory bounds in `p3_memlayer` |
| **Isolation** | `p3_isolation`, `p3_leak`, `p3_memlayer`, `p3_extcit`, `p3_extcit_hang` (`05_ISOLATION.md`) |
| **Randomised input data** | random operands everywhere; descriptor fuzz (`p3_validate`, 880 per run); two-tenant isolation fuzz (`p3_isolation`) |
| *Also* | memory error propagation with real ECC fault injection (`p3_ecc`); clock enable (`p3_clken`); queues / scheduling (`p3_queues`); performance counters (exact prediction + identities, in every suite that dumps them) |

### Brief §8, numerical correctness

* **FP32**: bit-exact result *and* exact exception-flag word against the exact-rational reference — no tolerance.
* **INT8 GEMM**: signed multiplication (extreme values ±128 / 127 at 12 % density), accumulation, the **overflow policy**
  (wrap modulo 2³², tested with `C_in` at the INT32 edge and K at the staging limit), matrix dimensions (1…11 and K up to 256), **partial tiles**
  (every M, N not a multiple of the array size; an 8×8 and 2×2 array too), and **operand ordering** (non-commuting matrices: `A×B`, `B×A`, `A×Bᵀ` all differ).

## Configuration matrix

Beyond the `base` reference: 1 / 2 / 8 / 16 lanes; 2 compute ports; 128-bit memory (1 and 2 ports); 256-byte and 2 KiB staging; 2×2, 4×2, 8×8 arrays;
ECC off; staging clearing off (the "staging is zero" check is correctly absent); two and four queues; tiny queues; external Citadel (answering and hung); vector path disabled.

## Mutation check

`scripts/mutate.py`: **49** deliberate bugs injected into every **new** module (decoder, guard, scheduler, queue, executors, engine, adapter, perf, tile), each rebuilt in a private
copy of the tree and run against the relevant suites (memory-path and executor mutants also against the unit benches); a mutant is *killed* if any run fails (a hang counts).
**Final result: 49 / 49 killed** (`reports/mutation.md`). The reused third-party blocks are not mutated (they have their own campaigns).

The **first** campaign killed only **42 / 48**. The six survivors each exposed a real gap in the *tests*, and were closed before the final campaign:

| Survivor | Gap | Closed by |
|---|---|---|
| M05 stray byte scattered into staging padding | invisible at tile level (padding is never read, staging is cleared) | unit benches added to the plan (the adapter bench compares every staging byte) |
| M06 `stg_clear` does nothing | the mutant itself was a no-op by construction | mutant rebuilt; killed by the white-box "staging is zero" check |
| M12 partial tile launched at full width | functionally invisible (extra lanes are never stored) | exact **array-busy** prediction from TC02's documented timing (`1 + K + m + n` per block), checked against the hardware counter |
| M20 range check off by one at the SRAM end | only operand D's end boundary was tested directly | exact-end / one-word-over cases for **every** operand of every op |
| M30 a dirty entry reused for a different range | would forget the dirty marker of the old range (a leak path); only the same-range case was tested | new scenario in `p3_leak` |
| M33 external-Citadel request timeout fails open | the stub always accepted requests, so that path never ran | stub mode "never accepts" (`p3_extcit_noready`), plus M49 for the answer-timeout path |

**One real RTL bug was found by the tests** (it would have shipped silently otherwise): the tensor executor could accept a new memory job in the same cycle the previous
job's `done` pulse arrived, and a later assignment erased the "engine busy" flag, so the array was launched before operand B had finished loading (visible as an all-zero result on the
first end-to-end run). It is fixed (done is handled first, accept last) and is mutant M10. A latent 16-bit overflow in the GEMM block-count arithmetic (M near 65 535) was found
by code review, not by a test. The rest of the defects found along the way were in the *testbenches* (a sampling race between the bench and the DUT, a closed-file crash at `$finish`,
Verilator 5.020 limitations with `fork` and unpacked structs), and several wrong test constructions were caught by the generators' own assertions; they were fixed in the benches, not hidden.

## Lint and structure

`reports/lint.md`: Verilator `-Wall` on the new RTL — **0 warnings** (one documented waiver: the reused TC02 array has a synchronous reset on the same `rst_n` net). Elaboration of
the tile over parameter sets and rejection of illegal parameters at elaboration (`scripts/run_lint.py`). Illegal parameters fail *elaboration* in every tool because the tile's `generate`
checks instantiate a deliberately undefined module (an `initial $fatal` would only fire when a simulation starts; that weaker first version was caught by the lint check itself).

## What was not verified

Formal properties; gate-level behaviour; a real Citadel or a real DMA; timing / area / power; multi-block-GEMM failure atomicity beyond the single-block cases; a reset
*during* a running SCRUB; FP64 / FP16 / BF16 (rejected, so nothing to verify beyond the rejection).
