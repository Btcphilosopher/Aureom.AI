# 00 · Repository audit (brief §1)

The repository (`btcphilosopher/Aureom.AI`) is a collection of zip archives. The ComputeWorks inputs live in
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/*.zip` (one archive per earlier project). Every archive named in the table
below was extracted into an isolated directory and read; nothing in the repository was modified.

## What exists, and what this project does with it

| Brief item | Where it is | State in the repository | Decision |
|---|---|---|---|
| **FP32 FMA** | `hpc_fp32_fma.sv` (HPC M02 lane; byte-identical copy inside M03) | Verified by its own project against Berkeley SoftFloat-3e (600 000 + 166 140 vectors, 0 mismatches, per the M08 report) | **Reused**, unmodified. No floating-point arithmetic is written in this project. |
| **HPC Vector Lane** | `silicaflux-hpc-m02-vector-lane.zip` → `hpc_vector_lane.sv` + add / mul / FMA / round units | Verified; INT32 add / multiply also present | **Reused** (inside M03). The 10 lane files in `third_party/hpc-m03-vector-array/lane/` are byte-identical to the M02 originals (checked). |
| **HPC Vector Array** | `silicaflux-hpc-m03-vector-array.zip` → `hpc_vector_array.sv` (+ issue, collect, fifo, reduce, perf) | Verified: 1632/1632 Verilator + 288/288 Icarus runs, 32/32 mutants killed | **Reused**, unmodified, 4 lanes in the reference configuration (1/2/4/8/16 verified here). Its streaming operand/result interface is driven from staging buffers. The optional reduction unit is not used (`RED_EN = 0`). |
| **TensorCore** | `silicaflux-tensorcore01 … 10` | TC02 `tensor_systolic_array` (INT8×INT8→INT32, output-stationary, 4×4 default) is verified: 877-line identical Icarus/Verilator logs, 44/47 mutants | **TC02 reused**, unmodified (it contains the PE, skew and output-collect blocks). TC03 (operand buffer), TC04 (accumulator), TC06 (GEMM engine), TC07 (DMA adapter) are **not** reused – see below. |
| **Tensor PE arrays** | TC01 `tensor_pe_mesh`, TC02 `tensor_pe` | TC01 is a mesh; TC02's PE is part of the systolic array | TC02's PE is used through `tensor_systolic_array`. |
| **TensorScratch** | P75 `sf_tensor_scratchpad` | Verified, but built on its own private SRAM banks (`sf_sram_bank`) and the TC04 accumulator interface | **Design reference only.** The brief mandates IronMemory as local memory; instantiating P75 too would duplicate the storage and bypass IronMemory's ownership checks. P75's idea (an A lane consumes one memory word over several k-slices; slices only leave when every lane holds the same `k`) informed the staging design. |
| **VectorScratch** | P76 `sf_vector_scratchpad` | Verified, private banks, SFB2 DMA port, "not wired into the HPC tile" (its own words) | **Design reference only**, same reason. |
| **DataFabric / DMA** | `silicaflux-datafabric*`, HPC M05 DMA adapter, CloudDMA P64, TC07 tensor DMA | 1-D (DataFabric) or 2-D (TC07) engines on the SFB2 bus; CloudDMA is an AXI4 master with a permission checker | **None speaks IronMemory's master-port protocol.** The BridgeEngine attaches to IronMemory's port 1 (domain 1); this project exposes that port. Wiring a real CloudDMA needs an AXI4-to-master-port adapter (not built; see limitations). A testbench DMA stand-in exercises the port concurrently with compute. |
| **Performance counters** | HPC M07 `hpc_perf_counters`, M03 `hpc_varray_perf`, TC02 per-tile counters, IronMemory CSR counters | M07 is tile-specific (its event set is the M08 tile's) | **New** `sf_compute_perf` for command / phase / utilisation events; TC02's and IronMemory's counters are consumed, not duplicated (IronMemory's conflict counters are read through its CSR port in the benchmarks). |
| **IronMemory** | P84 `sf_iron_memory.sv` + 12 blocks | Verified: 20/20 regression runs, 12/12 mutants, Yosys generic synthesis clean | **Reused**, unmodified, as the local operand SRAM. |
| **Citadel** | *no RTL exists* | Meridian (P83) `sf_meridian_citadel_ref.sv` states: "The repository contains no block named Citadel"; it maps the role onto CloudDMA's permission table | **Not a block we can instantiate.** This project implements the *client* of a Citadel (a range-check interface with Meridian's fault codes) and a **reference** Citadel (a region table). A real Citadel replaces it through `GUARD_MODE = 2`. |
| **BridgeEngine** | *no RTL exists* | In IronMemory it is **domain 1**, the DMA master class; Keystone P82 lists it as a code name | **A port, not a block.** See above. |
| **ComputeWorks** | Keystone P82 `sf_keystone_engmodel.sv` | A *behavioural model* ("does no compute and moves no data") with a queue ABI (`Q_CREATE`, `Q_DOORBELL`) | This tile is the first real engine behind that name. **Keystone's queue ABI is not implemented here**: queues are fixed-size descriptor FIFOs with a hardware-programmed binding. Adapting Keystone's doorbell protocol is a thin shim and is listed as future work. |
| **HPC tile (M08)** | `silicaflux-hpc-m08-tile.zip` | A complete FP32 tile with its own scratchpad, DMA adapter and queue, driven over SFB2 | **Design reference** for descriptor conventions (8-word descriptor, in-order completion record, validation before side effects). It is not a block of this design: it has no INT8 path, no IronMemory, no tenant isolation. |

## Reused blocks (all unmodified)

| Directory | Source archive (`SilicaFlux2.5/`) | Files | Check |
|---|---|---|---|
| `third_party/p84-ironmemory/` | `silicaflux-p84-ironmemory.zip` | 13 | SHA-256 + byte-identical to the archive |
| `third_party/tensorcore02/` | `silicaflux-tensorcore02.zip` | 4 | same |
| `third_party/hpc-m03-vector-array/` | `silicaflux-hpc-m03-vector-array.zip` | 17 | same (and the 10 lane files equal the M02 archive's) |

`python3 scripts/check_vendor.py --archives <path to SilicaFlux2.5>` repeats the byte comparison; `third_party/PROVENANCE.md`
records the source hashes. Reuse is by **instantiation**; nothing was copied into new RTL and edited.

## Gaps found in the inputs (and how they were handled)

1. **No Citadel, no BridgeEngine block** – implemented the client / reference described above and said so in every place a
   reader might assume otherwise (`sf_compute_guard.sv` header, `05_ISOLATION.md`, `08_LIMITATIONS.md`).
2. **IronMemory does not zero freed buffers** (its own README, "Things to know before integrating", roadmap item 1). The
   brief asks for a scratchpad clearing procedure; it is implemented here at the tile level (`CLEAR`, `SCRUB`, the
   REVOKE → SCRUB → SET lifecycle) and tested. IronMemory's own `FREE` still does not clear: a supervisor that frees an
   IronMemory buffer must scrub it first.
3. **IronMemory's ownership domains are agent classes** (Keystone, Bridge, PacketForge, ComputeWorks, VirtualFoundry), not
   tenants. Two tenants using ComputeWorks are both "domain 3" to IronMemory, so IronMemory alone cannot separate them. The
   tenant isolation is therefore a tile-level layer (`sf_compute_guard`); IronMemory ownership is the second, independent layer.
4. **No technology data** – no frequency, area or power is claimed anywhere. The activity counters are inputs a power model
   would need, nothing more.
