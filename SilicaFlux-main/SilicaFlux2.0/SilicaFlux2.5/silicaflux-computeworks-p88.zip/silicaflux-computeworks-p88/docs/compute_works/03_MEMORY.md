# 03 · Local memory (brief §6)

The tile **owns one IronMemory (P84) instance** as its local operand SRAM and uses its real RTL for banking, ECC, bank
arbitration and buffer ownership. IronMemory is reused unmodified.

## Ports and domains

| IronMemory port | Domain | Who | Exposed as |
|---|---|---|---|
| 0 | 0 Keystone | supervisor (raw access to *unmanaged* memory, buffer-manager and CSR owner) | `ks_*` master port, `bm_*` command port, `csr_*` |
| 1 | 1 BridgeEngine | the DMA master class | `br_*` master port (width = `DMA_DW`) |
| 2 … 1+`NUM_CP` | 3 ComputeWorks | the tile's own memory engines | internal |

`NUM_CP` is **1 or 2**. The design never assumes an arbitrary number of SRAM ports: each engine owns exactly one port, and
with one port every transfer simply serialises. IronMemory's four banks are single-port: a bank sees at most one access per
cycle, enforced by IronMemory's per-bank arbiter (asserted in its own simulation).

`bm_cmd_requester` (the identity of whoever manages buffers) must be driven by the interconnect, not by software – IronMemory's
rule, preserved at the tile boundary.

## Capacity and the address map

`SRAM_BYTES = NUM_BANKS × BANK_DEPTH × DMA_DW/8` at `SRAM_BASE = 0x1000_0000` (default 4 × 1024 × 8 = 32 KiB). Words are
interleaved across banks (`bank = word mod NUM_BANKS`), so a sequential stream touches every bank in turn. The external-memory
window of IronMemory is disabled (`EXT_EN = 0`): this tile is a *local* SRAM design.

## Operand buffering and result buffering

Operands stay in IronMemory. For each command the executors ask the memory adapter for **jobs**:

| Job | Meaning |
|---|---|
| `READ2D` | `ROWS` rows of `ROWBYTES` bytes, row *r* at `BASE + r·STRIDE`, into staging at `STG_BASE + r·STG_PITCH` |
| `WRITE2D` | the reverse (byte strobes: only bytes inside the rows are written) |
| `FILL0` | zero-fill `ROWBYTES` bytes |

A GEMM A-block is `m` rows of `K` bytes; the B-block is `K` rows of `n` bytes (stride `N`); a result block is `m` rows of `4n` bytes
(stride `4N`); a vector chunk is one row. The engine (`sf_compute_mem_engine`) does everything at **aligned full-word**
granularity: a row that starts or ends inside a word, or straddles words, is handled by issuing the covering words and masking.
Consequences, each covered by a randomised test against a byte-level shadow model (1–2.3 M checks per configuration):

* any byte alignment of any operand works;
* bytes of a word that lie outside the requested row are **discarded**, never staged (so a partial-word read cannot leak a
  neighbour tenant's bytes into a command);
* a write never changes a neighbouring byte (byte strobes; IronMemory turns partial words into read-modify-write under ECC);
* responses return in request order per port (IronMemory reorders internally), so the response side simply mirrors the request
  iteration: no tags.

**Staging buffers** (flip-flops, `STG_BYTES` each): `0` A, `1` B, `2` C, `3` OUT. Operand buffers are written only by engine
scatter; OUT only by the executors. One cycle at the end of every command zeroes all four (`stg_clear`).

## Bank arbitration

Two levels, both real:

1. **Between the tile's own ports** (`NUM_CP = 2`): both engines issue into IronMemory; its per-bank round-robin arbiter (with
   priority classes and an anti-starvation limit) resolves conflicts.
2. **Between agents** – ComputeWorks, BridgeEngine and Keystone ports share the same banks. The benchmarks create real contention
   with a second master (`06_PERFORMANCE.md` §4) and read IronMemory's own conflict counters; nothing is modelled.

The adapter itself has no arbiter and no extra port: it exposes the resulting stalls as events (`MEM_STALL`).

## Buffer ownership

IronMemory's buffer manager enforces, **per access**, that the issuing *agent domain* holds the read / write right of the buffer
the access falls in (`RSP_PERM` otherwise; partial overlap with a buffer is `RSP_BOUNDS`; unmanaged memory is Keystone-only).
The tile maps IronMemory's refusals to a completion:

| IronMemory response | completion |
|---|---|
| `RSP_PERM` (3) | `MEM_ERR`, `DETAIL = {phase, 3}` |
| `RSP_ECC_UE` (4) uncorrectable | `MEM_ERR`, `DETAIL = {phase, 4}`; nothing stored |
| single-bit ECC error | corrected invisibly (verified with fault injection) |
| `RSP_BOUNDS` (6), `RSP_ALIGN` (2), `RSP_DECODE` (1) | `MEM_ERR` with that code (cannot occur for a validated command unless buffers were mis-programmed) |

A *refused write never modifies memory* and a refused read returns nothing (IronMemory's guarantee; verified through the tile: a
store into a compute-read-only buffer, a store into the unmanaged hole and a CLEAR into a read-only buffer all leave memory
bit-identical, hole included).

**Typical life of a tenant buffer** (software contract): Keystone `ALLOC` / `ALLOC_AT` an IronMemory buffer with owner =
BridgeEngine (or Keystone), `rd_mask`/`wr_mask` including **domain 3** wherever compute must read / write; programs the tile's
tenant region (`SET_REGION`) over it; the BridgeEngine DMAs operands in; the tenant submits commands; the BridgeEngine DMAs
results out; Keystone `REVOKE`s and `SCRUB`s the region (tile) and only then frees / reassigns the IronMemory buffer.
`TRANSFER` of IronMemory ownership between DMA and compute is available but the tile does not need it: the compute domain is
simply granted in the masks.

## DMA integration

The BridgeEngine is a **port**: any DMA master can drive `br_*` with IronMemory's request / response protocol
(`DMA_DW` bits wide, 1/2/4/8(/16)-byte naturally aligned accesses, up to `MAX_OUT` outstanding). Evidence in this project:

* the testbench loads operands and reads results through that port in every test (the whole SRAM is read back after every
  suite and compared with the model);
* concurrent contention with compute is measured (`06_PERFORMANCE.md` §4) and verified for data integrity;
* 64-bit and 128-bit widths both verified.

**Not done:** wiring a real DMA engine. CloudDMA (P64) is an AXI4 master and the DataFabric DMA speaks SFB2; neither speaks
IronMemory's master-port protocol, so a protocol adapter is needed (not built). **The BridgeEngine port is not gated by the
tenant region table** (see `05_ISOLATION.md`, `08_LIMITATIONS.md`): a DMA is assumed to be policed by its own permission check.

## Scratchpad clearing

IronMemory's own `FREE` does **not** zero a buffer (its README says so). This tile provides: the `CLEAR` command (a tenant
zero-fills its own buffer), the guard's `SCRUB` (the supervisor zero-fills a revoked region) with the REVOKE → SCRUB → SET lifecycle
enforced in hardware, and zeroing of the staging buffers after every command. Details and tests: `05_ISOLATION.md`.
