# 08 · Limitations and what is not claimed

Read this before relying on anything else in the package.

## Evidence level

* **RTL simulation only** (Verilator 5.020). The tile *elaborates* in Icarus Verilog 12; no Icarus simulation is claimed (Icarus lacks support for constant selects in `always_*` blocks).
* **No formal proof, no gate-level simulation, no FPGA, no synthesis, no place-and-route, no silicon.** No clock frequency, area, power or timing is claimed anywhere; no technology library was available.
  The "activity" counters are inputs a power model would need, not a power estimate.
* Mutation testing and fuzzing are evidence of test strength, not proof of correctness.

## Numerical formats

* **Implemented:** FP32 add / multiply / fused multiply-add (the reused HPC lanes), INT32 add / multiply (mod 2³²), INT8 × INT8 → INT32 matrix multiply with INT32 accumulation (wrapping).
* **FP64, FP16, BF16 are NOT implemented and are rejected** (`CW_ST_BAD_ETYPE`), as are all reserved element codes. No conversion between formats exists.
* INT32 accumulation **wraps modulo 2³²**: no saturation, no overflow flag (documented policy).
* FP32 follows the reused lane's conventions: canonical quiet NaN, no payload propagation, no flush-to-zero, tininess after rounding. Not covered: FP32 comparison / min / max / reduction (the reused array has them; this tile does not expose them).

## Compute

* **One outstanding command.** No overlap of load / compute / store and none between commands; this bounds MAC utilisation (≈ 45 % best case measured) and makes vector throughput memory-bound
  (`06_PERFORMANCE.md`). Double-buffered staging is the obvious next step; it was not built.
* `K ≤ KMAX` (256 in the reference configuration): larger K is rejected, **not split**. Matrices are packed row-major (no leading-dimension / stride fields).
* A GEMM that fails while *storing* a block of a multi-block result leaves the earlier blocks stored. Only the single-block failures are tested.
* **No mid-kernel preemption.** Queues switch at command boundaries only (`04_SCHEDULING.md`).
* `clk_en_i` gates dispatch only; the tile contains **no clock-gating cell**. IronMemory's optional background scrubber stops with the clock.
* The compute array dimensions are parameters but only 2×2, 4×2, 4×4 and 8×8 were run; vector lanes 1…16 were run.

## Memory and DMA

* The local memory is **IronMemory in its local configuration** (external window disabled). IronMemory does not zero freed buffers (its own limitation).
* **No real DMA is wired.** The BridgeEngine is IronMemory's domain-1 port; a real DMA (CloudDMA, AXI4) needs a protocol adapter that was not built. Concurrent traffic is a testbench master.
* The BridgeEngine and Keystone ports are **not gated by the tenant region table**.
* Wide-word writes from the compute side are partial-word read-modify-write under ECC (IronMemory's cost); no wide-port (4-lane) mode of IronMemory is used.

## Isolation

* **There is no Citadel in the repository.** `GUARD_MODE = 1` is a *reference* policy (a region table) that this project defined; `GUARD_MODE = 2` forwards to an external Citadel over an interface defined here (modelled on Meridian's check) and was only tested against a testbench stub.
  `GUARD_MODE = 0` disables isolation entirely.
* Range checks are single-region containment; 8 regions of 256-byte granularity; regions disjoint.
* No protection against timing / side channels, contention-based denial of service beyond the ageing bound, or a mis-programmed management plane (`05_ISOLATION.md`).
* A reset *during* a running SCRUB was not separately exercised (a reset after a REVOKE was).

## Integration with the rest of Albion

* **Keystone's ComputeWorks queue ABI (`Q_CREATE` / `Q_DOORBELL`, P82) is not implemented.** Keystone's current ComputeWorks is a behavioural model of that ABI; a shim that
  turns its doorbell into descriptor pushes is straightforward but not done. Meridian (P83) is not instantiated; the tile's ports are plain valid / ready and IronMemory's master-port protocol,
  not Meridian's transaction format.
* The tile is a single **tile**: no NoC, no multi-tile scheduling, no HBM / external memory.

## Tools and reproducibility

* Verilator 5.020 (Debian 5.020-1), Python 3.13, numpy 2.5. The build cache is keyed by a hash of the sources and parameters. The FP32 model is validated against numpy; nothing is validated
  against Berkeley SoftFloat in *this* package (the reused lanes were, in theirs).
* Host-dependent: simulation wall-clock times in the reports.

## Things that look like gaps but are decisions

* Descriptor `DOM` is a claim, not an identity (by design); the queue binding is the identity.
* Rejected commands still produce a completion (every submission gets exactly one answer); commands for a *disabled* queue produce none until it is enabled.
* The staging buffers are flip-flops (simple, zeroable in one cycle); their size is a parameter, and a synthesised design would likely map them to SRAM with a different clearing strategy.
