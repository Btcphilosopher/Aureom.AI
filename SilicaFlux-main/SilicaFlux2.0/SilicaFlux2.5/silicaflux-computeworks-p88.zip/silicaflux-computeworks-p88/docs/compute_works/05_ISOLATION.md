# 05 · Cloud isolation (brief §9)

> **Citadel and BridgeEngine are not blocks in this repository** (`00_AUDIT.md`). This tile implements the *client side* of a Citadel
> (a range-check interface using Meridian's fault codes), a **reference** policy behind it, and a pass-through for a real one.
> The BridgeEngine is IronMemory's domain-1 port. Everything below is about what this tile enforces itself.

## Threat model

Mutually distrusting tenants share one tile and one local SRAM. A tenant (or its driver) controls only the *content of descriptors it
submits to its own queue* and the data it DMA-loads. It must not be able to: read or write another tenant's buffers; make the tile act
for another domain; learn another tenant's data through residue left in the tile or in memory; or get its completions delivered where it
was not authorised, or get someone else's delivered to it. The management plane (Keystone) and the interconnect that sources
hardware identities (queue binding, `bm_cmd_requester`) are trusted.

## Two namespaces of "domain" (do not confuse them)

| | Values | Enforced by |
|---|---|---|
| **Tenant / security domain** | 3 bits (8) — the `DOM` of a queue, region and completion | this tile (`sf_compute_guard`) |
| **IronMemory master domain** | 0 Keystone, 1 Bridge, 2 PacketForge, **3 ComputeWorks**, 4 VirtualFoundry | IronMemory's buffer manager |

IronMemory sees every tenant's compute traffic as domain 3, so it **cannot** separate two ComputeWorks tenants. That is why the tile
layer exists; IronMemory ownership is an independent second layer (it separates ComputeWorks from DMA, supervisor and the other engine
classes).

## Layers and what each prevents

| Required prevention | Mechanism | Test |
|---|---|---|
| **Incorrect command ownership** | The domain of a command is the **queue's hardware-bound domain**, programmed by the management plane. The descriptor's `DOM` is only a claim and must match, else `CW_ST_OWNER`; the completion carries the bound domain, never the claim. An unbound queue rejects everything. | `p3_isolation` (forged domain), `p3_reject_table`, `p3_validate` (forged domains are one of the fuzzed corruptions), `p3_queues` (unbound queue) |
| **Cross-domain buffer access** | Every memory operand range of a command is checked **before** it runs: it must lie entirely inside **one** live region owned by the queue's domain, with the read (inputs) / write (result) right. Otherwise `CW_ST_DENIED` with fault `NOMAP` / `DOMAIN` / `PERM` and the **operand id**; nothing executes. IronMemory then checks every individual access against buffer ownership (second layer). | `p3_isolation`: cross-domain read, write, second operand, read-only region, region-straddling range, unassigned memory, plus 120 random two-tenant commands against an independent guard model; `p3_memlayer` |
| **Scratchpad data leakage** | (a) staging zeroed after every command; (b) bytes outside a requested row are never staged; (c) the REVOKE → SCRUB → SET lifecycle below; (d) `CLEAR` for tenants. | `p3_leak`; white-box "staging is zero" check after every command in `p3_isolation` and `p3_memlayer` (and after the back-pressure phase of `p3_backpressure`); the same check is correctly absent when `CLEAR_STAGING = 0` |
| **Unauthorised completion delivery** | A command may name a destination only if the domain's destination mask allows it (`BAD_DEST` otherwise). A rejected command's completion goes to the queue's default destination **only if the domain may use it**, else to destination 0 (always allowed, hard-wired into the mask). The completion's destination is asserted allowed for its domain on every completion. | `p3_isolation` (destinations), `p3_reject_table`, `p3_validate`; the assertion runs in every test |

## Regions and the policy port

A **region** is `{base, size, domain, read, write}`; `base` and `size` are multiples of 256 bytes (IronMemory's granule), inside the
local SRAM; regions are **mutually disjoint** (so an address belongs to at most one domain); `NUM_REGIONS` = 8. After reset there are
none: **default deny**. The check is by single-region containment; a range that spans two regions is refused (`NOMAP`) even if both are
the tenant's – a stated simplification, not a hole.

The policy port (`pol_*`, Keystone only, accepted only while the tile is quiescent):

| Op | Effect |
|---|---|
| `SET_REGION` idx, base, size, domain, rd, wr | assign a region (status codes `CW_PS_*`) |
| `REVOKE` idx | withdraw it **immediately**; the entry becomes **DIRTY** |
| `SCRUB` idx | zero-fill a revoked region through the memory engine; on success the entry is **CLEAN** (the response is held until the zero-fill finishes) |
| `BIND_QUEUE`, `SET_DESTMASK` | queue binding / destination permissions |

### The scratchpad clearing / reassignment procedure (enforced, not advisory)

```
 CLEAN ──SET_REGION──▶ LIVE ──REVOKE──▶ DIRTY ──SCRUB──▶ CLEAN
```

* `SET_REGION` on a **DIRTY** entry, or over a range that overlaps any **DIRTY** or **LIVE** region, is **refused**
  (`NOT_CLEAN` / `OVERLAP`). There is no way to give a tenant memory that may hold another tenant's data without the zero-fill in between.
* `SCRUB` of a LIVE region is refused (`IN_USE`); a failed scrub (memory error) leaves it DIRTY.
* After reset all entries are CLEAN (IronMemory's init sweep zeroes the SRAM).

The leak test builds a "secret" (a GEMM result) in tenant 1's region, revokes it, shows that every reassignment attempt is refused
(same entry, another entry at the same base, a sub-range, an overlap), shows the secret is still physically there, scrubs, and
then has tenant 2 read the former secret area through a VADD: it sees zeros. A reset after a REVOKE (`p3_reset`) leaves every entry clean and the SRAM zero; a reset *during* a running SCRUB was not separately exercised.

**IronMemory's own `FREE` does not zero memory.** The supervisor must `REVOKE` + `SCRUB` the tile region before freeing or
reassigning the IronMemory buffer.

## The Citadel interface (`GUARD_MODE`)

`chk_valid / chk_ready, {dom, write, base, len(40 bit)}` → `chk_rsp_valid, ok, fault`. Same shape as Meridian's check, extended with a
range length.

| `GUARD_MODE` | Behaviour |
|---|---|
| 0 | **Off — no isolation.** Bring-up only. |
| 1 | The reference region table described above. |
| 2 | Each query is forwarded over `cit_*` to an **external Citadel**; no answer within `CIT_TMO` cycles → denied (`CITTMO`, **fail closed**). Region policy ops return `UNSUPPORTED` (the Citadel owns that policy). |

Mode 2 is tested against a testbench stub that is a *different implementation* from the reference table (a flat window), including
the hung-Citadel case. It has not been tested against a real Citadel because none exists.

## What is NOT protected (read this)

1. **The BridgeEngine port is not gated by the region table.** A DMA can read or write any IronMemory buffer whose masks allow
   domain 1, whatever tenant it "belongs" to. Tenant-level policing of DMA is assumed to happen in the DMA's own permission check
   (CloudDMA's permission table). IronMemory buffer masks are the only tile-side control on that port.
2. **The Keystone port** is the supervisor: fully trusted.
3. **Timing and side channels.** Command durations, queue waits, the shared performance counters and IronMemory's CSR counters are
   visible to anyone who can read them; the shared banks create contention a tenant could observe. Nothing here is constant-time.
4. **Availability.** A tenant can submit commands up to its budget and queue depth; strict priority can delay lower classes by up to the
   ageing bound; one long command delays everyone (no preemption, `04_SCHEDULING.md`).
5. **Single-region ranges only; 8 regions.** Larger tenants must use contiguous arenas.
6. **A multi-block GEMM that fails mid-way** leaves earlier blocks stored (within the same tenant's own region).
7. **Management-plane trust.** If the management plane misprograms a region or a buffer mask, the tile enforces what it was told.
8. **Formal assurance:** none. Isolation is verified by simulation, fuzzing against an independent model, and mutation testing
   (`07_VERIFICATION.md`), not by proof.
