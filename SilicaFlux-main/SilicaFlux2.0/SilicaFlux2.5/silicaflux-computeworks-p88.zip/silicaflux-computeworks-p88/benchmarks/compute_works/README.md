# ComputeWorks benchmarks

```bash
python3 benchmarks/compute_works/bench.py                 # all groups, about 8 minutes  -> results/bench.json
python3 benchmarks/compute_works/bench.py --only latency  # re-run one group and merge it into bench.json
python3 benchmarks/compute_works/bench.py --quick         # a few points
python3 benchmarks/compute_works/make_report.py           # -> docs/compute_works/06_PERFORMANCE.md (every number generated)
```

All figures are **measured RTL-simulation cycle counts** from the tile's own counters, the per-command completion records and IronMemory's own conflict counters.
No frequency, area or power is claimed. Every point verifies the numerical result of its last command against the independent models, so a benchmark can never report
speed for a wrong answer.

Groups: GEMM shape sweep, vector length sweep, command overhead, lane count, compute ports and memory width, concurrent-DMA contention (0–95 % background load),
queue latency (held-dispatch and idle-tile), and activity counters. Method and definitions are at the top of `docs/compute_works/06_PERFORMANCE.md`.
