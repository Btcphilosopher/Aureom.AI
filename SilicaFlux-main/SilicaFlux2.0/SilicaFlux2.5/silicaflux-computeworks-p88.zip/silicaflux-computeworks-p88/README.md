# SilicaFlux Albion — Project 88 · ComputeWorks: cloud vector and tensor compute tile

**Primary RTL:** `rtl/albion/sf_compute_tile.sv` · Aureom.AI / SilicaFlux Albion · delivered as this archive — **nothing was committed to GitHub.**

One compute tile for the Albion cloud processor. A cloud command (a 256-bit descriptor) enters a queue, is validated and isolation-checked, reads its
operands from a local IronMemory SRAM, runs on **reused, previously verified** SilicaFlux compute engines — the HPC FP32 vector array (add / multiply / fused
multiply-add) and the TENSORCORE 02 INT8 systolic array — writes the result back, and returns a completion record carrying the command's tag, the **hardware-bound**
domain, a validated destination, status and floating-point exception flags.

> **Read first — status and honesty notes.** Everything below is **RTL simulation** (Verilator 5.020). There is no formal proof, FPGA, synthesis, timing, area or
> power result, and no clock frequency is claimed. **Citadel and BridgeEngine are not blocks that exist in this repository**: Citadel is implemented here as a
> *client* with a *reference* policy (and an interface for a real one), BridgeEngine is IronMemory's DMA port; no real DMA is wired. **FP64, FP16 and BF16 are not
> implemented and are rejected.** There is **no mid-kernel preemption**. Full list: [`docs/compute_works/08_LIMITATIONS.md`](docs/compute_works/08_LIMITATIONS.md).

## Definition of done — met in RTL simulation

> *The compute tile accepts a supported cloud command, reads actual operands, performs real vector / tensor arithmetic and returns a numerically correct result with
> properly associated completion metadata.*

Built in the order the brief asked for: **one 4×4 INT8 tensor operation first** (stage 1 of the regression), then partial tiles / accumulation / larger shapes, then FP32 and
INT32 vectors, then validation, isolation, multiple queues and the robustness suites; each stage runs only if the previous one passed. Results are bit-exact (FP32 including
the exception-flag word) against **independent** models — exact-rational IEEE-754 arithmetic validated against numpy, plain-integer INT8 GEMM — and the *entire* local SRAM is
compared with a byte-level shadow model at the end of every test.

<!-- RESULTS:BEGIN -->
## Results (all from the generated reports in `reports/`; `make report` regenerates this list)

* **Regression:** 112 / 112 runs passed, 9,452,410 checks, 20 suites, 21 configurations (290 s)
* **Unit benches (memory path):** 24 / 24 runs passed, 28,792,992 checks
* **Mutation check (new RTL):** 49 / 49 valid mutants killed, 0 survived, 0 invalid or stale
* **Lint:** 0 warnings in the new RTL over 18 parameter sets; 9 / 9 illegal parameter sets rejected at elaboration; Icarus elaboration OK
* **Performance (RTL cycles, 4 lanes, 4x4 array, 1 port, 64-bit):** best GEMM 14.4 ops/cycle (45 % of MAC peak, 97 % while the array is busy); best vector 0.53 elements/cycle; 4x4x4 GEMM 70 cycles; idle-tile queue latency 1 cycle

The mutation check was run twice on purpose: the first campaign killed only 42 / 48, and each of the six survivors exposed a real gap in the *tests* (not the RTL); they were
closed and the final campaign kills 49 / 49. Details, and the one real RTL bug the tests found (a done/accept race in the executor), are in
[`docs/compute_works/07_VERIFICATION.md`](docs/compute_works/07_VERIFICATION.md). What limits the performance numbers (non-overlapped load / compute phases; a single 64-bit port for
vectors) is analysed in [`06_PERFORMANCE.md`](docs/compute_works/06_PERFORMANCE.md).
<!-- RESULTS:END -->

## What was built, and what was reused

```
                        reused, unmodified (third_party/, SHA-256 + provenance)          new in this project
 FP32 add / mul / FMA   HPC M02 lanes inside HPC M03 hpc_vector_array                    sf_compute_vector_exec
 INT8 GEMM              TENSORCORE 02 tensor_systolic_array                              sf_compute_tensor_exec
 local SRAM, ECC,       IronMemory P84 sf_iron_memory (4 banks, buffer ownership)        sf_compute_memory_adapter / _mem_engine
 bank arbitration                                                                         sf_compute_command_queue, _decoder, _scheduler
 isolation                                                                                sf_compute_guard (Citadel client + reference), _clear_exec
 counters                                                                                sf_compute_perf        (+ sf_compute_tile = top)
```

| Brief deliverable | Where |
|---|---|
| `sf_compute_tile.sv` | `rtl/albion/sf_compute_tile.sv` |
| `sf_compute_command_queue.sv` | `rtl/albion/` |
| `sf_compute_scheduler.sv` | `rtl/albion/` (arbitration, sequencing, completion FIFO) |
| `sf_compute_memory_adapter.sv` | `rtl/albion/` (+ `sf_compute_mem_engine.sv`) |
| `sf_compute_perf.sv` | `rtl/albion/` |
| `tests/compute_works/` | system testbench, unit benches, test generators, runner (`scripts/`), independent models (`model/`) |
| `benchmarks/compute_works/` | benchmark harness, results, generated report |
| documentation | `docs/compute_works/00 … 08` |

Extras the architecture needed: `sf_compute_decoder.sv`, `sf_compute_guard.sv`, `sf_compute_clear_exec.sv`, `sf_compute_tensor_exec.sv`, `sf_compute_vector_exec.sv`, `sf_compute_defs.svh`.

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit, reuse of verified engines, no new FP arithmetic | [00_AUDIT](docs/compute_works/00_AUDIT.md), `third_party/PROVENANCE.md` |
| 2 | Queue → decoder → scheduler → execution → SRAM → completion | [01_ARCHITECTURE](docs/compute_works/01_ARCHITECTURE.md) |
| 3 | FP32 add / mul / FMA, INT8 GEMM, INT32 accumulation; reject unsupported precision | [02_COMMANDS](docs/compute_works/02_COMMANDS.md), suites `p1_*`, `p2_*`, `p3_reject_table` |
| 4 | Lanes, array size, scratchpad, queue depth, DMA width, format, clock enable; reference configuration | [01_ARCHITECTURE](docs/compute_works/01_ARCHITECTURE.md) §Compute configuration |
| 5 | Command descriptor; buffer-length and range validation | [02_COMMANDS](docs/compute_works/02_COMMANDS.md) |
| 6 | IronMemory, operand / result buffering, arbitration, DMA, ownership; no assumed port count | [03_MEMORY](docs/compute_works/03_MEMORY.md) |
| 7 | One queue; multiple protected queues, RR, priority, limits, command-boundary switching; **no** mid-kernel preemption | [04_SCHEDULING](docs/compute_works/04_SCHEDULING.md) |
| 8 | Numerical correctness: IEEE FP32 vs software reference; INT8 sign / accumulate / overflow / dimensions / partial tiles / operand order | [07_VERIFICATION](docs/compute_works/07_VERIFICATION.md) |
| 9 | Cloud isolation; clearing / reassignment procedure | [05_ISOLATION](docs/compute_works/05_ISOLATION.md) |
| 10 | Performance measurements | [06_PERFORMANCE](docs/compute_works/06_PERFORMANCE.md) (generated) |
| 11 | Verification list | [07_VERIFICATION](docs/compute_works/07_VERIFICATION.md), `reports/` |

## Quick start

```bash
sudo apt-get install -y verilator iverilog python3-numpy        # Verilator >= 5.0 (developed with 5.020)

make check      # generated constants current, third_party unmodified, FP32 reference self-test
make lint       # Verilator -Wall (0 warnings in the new RTL), illegal parameters rejected, Icarus elaboration
make quick      # about 1.5 minutes: every stage on the reference configurations
make regress    # full regression: config matrix x suites x seeds  ->  reports/regression.md
make unit       # memory-path unit benches on the real IronMemory
make bench      # performance benchmarks (about 8 minutes)         ->  docs/compute_works/06_PERFORMANCE.md
make mutate     # 49 injected RTL bugs, each must be caught (about 30 minutes)  ->  reports/mutation.md
```

Single run: `python3 scripts/run_tests.py --suite p3_isolation --config q2 --seeds 1,2`. Hardware parameters are Verilator `-G` overrides (see `model/cwlib.py::Cfg.vparams`).

## Layout

```
rtl/albion/        new RTL (+ sf_compute_defs.svh) · rtl/files*.f compile lists · rtl/lint.vlt waivers
third_party/       reused blocks, unmodified: p84-ironmemory, tensorcore02, hpc-m03-vector-array · SHA256SUMS · PROVENANCE.md
model/             independent reference models (fp32ref.py, cwlib.py), generated cw_defs.py
tests/compute_works/   tb_compute_tile.sv (script-driven system bench) · tb_adapter.sv, tb_tensor_exec.sv (unit) · gen_tests.py (all suites)
scripts/           run_tests.py · run_unit.py · run_lint.py · mutate.py · check_vendor.py · gen_defs.py · make_summary.py · make_zip.py · cwsim.py
benchmarks/compute_works/   bench.py · make_report.py · results/bench.json
docs/compute_works/   00 audit · 01 architecture · 02 commands · 03 memory · 04 scheduling · 05 isolation · 06 performance · 07 verification · 08 limitations
reports/           regression · unit · lint · mutation · SUMMARY (generated)
MANIFEST.sha256    SHA-256 of every shipped file
```
