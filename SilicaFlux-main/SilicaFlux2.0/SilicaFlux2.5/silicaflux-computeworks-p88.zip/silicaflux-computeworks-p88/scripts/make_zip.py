#!/usr/bin/env python3
"""Package the project into a zip (never touches git).

  python3 scripts/make_zip.py [--out DIR]

* Includes the sources, tests, models, benchmarks, docs, reports and the vendored third-party IP; excludes build/, caches and the zip itself.
* Writes MANIFEST.sha256 (SHA-256 of every shipped file except the manifest) into the tree first.
* Verifies the zip: extracts it to a temp directory and re-checks every hash, then checks the vendored IP against its manifest.
"""
import hashlib
import pathlib
import shutil
import subprocess
import sys
import tempfile
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
NAME = "silicaflux-computeworks-p88"
EXCLUDE_DIRS = {"build", "__pycache__", ".git", ".pytest_cache"}
EXCLUDE_SUFFIX = {".pyc", ".zip", ".swp"}


def shipped():
    out = []
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file():
            continue
        rel = p.relative_to(ROOT)
        if any(part in EXCLUDE_DIRS for part in rel.parts) or p.suffix in EXCLUDE_SUFFIX or rel.name == "MANIFEST.sha256":
            continue
        out.append(rel)
    return out


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    outdir = pathlib.Path(sys.argv[sys.argv.index("--out") + 1]) if "--out" in sys.argv else ROOT.parent
    files = shipped()
    (ROOT / "MANIFEST.sha256").write_text("".join(f"{sha(ROOT / f)}  {f.as_posix()}\n" for f in files))
    files = shipped() + [pathlib.Path("MANIFEST.sha256")]
    zpath = outdir / f"{NAME}.zip"
    if zpath.exists():
        zpath.unlink()
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in sorted(set(files)):
            z.write(ROOT / f, f"{NAME}/{f.as_posix()}")
    print(f"wrote {zpath}  ({zpath.stat().st_size / 1e6:.2f} MB, {len(set(files))} files)")

    # ---- verify the zip, not the tree
    tmp = pathlib.Path(tempfile.mkdtemp(prefix="cwzip_"))
    with zipfile.ZipFile(zpath) as z:
        bad = z.testzip()
        assert bad is None, f"corrupt member {bad}"
        z.extractall(tmp)
    root = tmp / NAME
    problems = 0
    for line in (root / "MANIFEST.sha256").read_text().splitlines():
        h, name = line.split(None, 1)
        if sha(root / name.strip()) != h:
            print("HASH MISMATCH", name)
            problems += 1
    n = len((root / "MANIFEST.sha256").read_text().splitlines())
    print(f"verified {n} files against MANIFEST.sha256 after extraction: {'OK' if not problems else str(problems) + ' problem(s)'}")
    r = subprocess.run([sys.executable, "scripts/check_vendor.py"], cwd=root, capture_output=True, text=True)
    print(r.stdout.strip())
    problems += r.returncode
    shutil.rmtree(tmp, ignore_errors=True)
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
