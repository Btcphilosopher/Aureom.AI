#!/usr/bin/env python3
"""Mutation check of the NEW ComputeWorks RTL: inject a deliberate bug, rebuild, run the relevant regression
suites, and require that at least one run FAILS.  A surviving mutant is a hole in the tests (or an equivalent
mutant, which must then be explained in reports/mutation.md).

  python3 scripts/mutate.py                 all mutants (about 30 minutes on 4 cores)
  python3 scripts/mutate.py M08 M21         only these
  python3 scripts/mutate.py --list

Each mutant runs in a private COPY of the tree (the working RTL is never touched).  The reused third-party blocks are
not mutated: they are verified by their own projects.  The pattern of every mutant must occur exactly once in its
file, otherwise the mutant is reported STALE (so an edit of the RTL cannot silently turn a mutant into a no-op).
"""
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = pathlib.Path(__file__).resolve().parent.parent
RTL = "rtl/albion/"

# suites chosen per area (config:suite:seeds).  q2 = two queues (also runs every single-queue suite through queue 0).
CORE = "q2:p1_single:1;q2:p1_gemm:1;q2:p2_fp32:1;q2:p2_int32:1;q2:p2_mixed:1"
VALID = "q2:p3_reject_table:1;q2:p3_validate:1"
ISOL = "q2:p3_isolation:1;q2:p3_leak:1;base:p3_memlayer:1"
SCHED = "q4:p3_queues:1"
ROBUST = "base:p3_clken:1;base:p3_ecc:1;base:p3_reset:1;bp:p3_backpressure:1"
EXT = "ext:p3_extcit:1;exthang:p3_extcit_hang:1;extnr:p3_extcit_noready:1"

M = []
# memory-path / executor mutants are also run against the unit benches: some corruptions (e.g. a stray byte in a staging PAD) are invisible at tile level
UNIT = {**{f"M0{i}": "adapter" for i in range(1, 7)}, **{f"M{i:02d}": "tensor_exec" for i in range(7, 14)}}


def mut(mid, file, old, new, plan, why):
    M.append(dict(id=mid, file=RTL + file, old=old, new=new, plan=plan, why=why, unit=UNIT.get(mid)))


# ----------------------------------------------------------------------------- memory engine / adapter
mut("M01", "sf_compute_mem_engine.sv", "inr  = (ba >= {1'b0, rq_rs_q}) && (ba < rq_end);", "inr  = (ba >= {1'b0, rq_rs_q}) && (ba <= rq_end);",
    CORE, "write strobe one byte too wide (corrupts the neighbour byte)")
mut("M02", "sf_compute_mem_engine.sv", "lane0_c = (LNB+1)'(l);", "lane0_c = (LNB+1)'(0);",
    CORE, "scatter descriptor always starts at lane 0 (unaligned reads land in the wrong staging bytes)")
mut("M03", "sf_compute_mem_engine.sv", "rq_rs_q   <= rq_rs_q + stride_q;", "rq_rs_q   <= rq_rs_q + rowbytes_q;",
    CORE, "row stride ignored on the request side")
mut("M04", "sf_compute_mem_engine.sv", "if (err_q == 3'd0) err_q <= m_rsp_err;", "if (err_q == 3'd0) err_q <= 3'd0;",
    ISOL, "memory error responses are dropped (a failed access would complete as OK)")
mut("M05", "sf_compute_mem_engine.sv", "if ((ba >= {1'b0, rs_rs_q}) && (ba < rs_end)) begin", "if ((ba >= {1'b0, rs_rs_q}) && (ba <= rs_end)) begin",
    CORE, "one extra byte beyond the row is scattered into staging (data leakage across rows)")
mut("M06", "sf_compute_memory_adapter.sv", "end else if (stg_clear) begin", "end else if (stg_clear && 1'b0) begin",
    "q2:p3_isolation:1;q2:p3_leak:1;base:p3_memlayer:1", "stg_clear does nothing: scratchpad residue survives a command")

# ----------------------------------------------------------------------------- tensor executor
mut("M07", "sf_compute_tensor_exec.sv", "sum = tc_m_data[j*32 +: 32] + cin;", "sum = tc_m_data[j*32 +: 32] - cin;",
    CORE, "INT32 accumulation subtracts C_in")
mut("M08", "sf_compute_tensor_exec.sv", "ai = i * A_PITCH + int'(tc_s_k);", "ai = i * A_PITCH + int'(tc_s_k) + 1;",
    CORE, "k-slice of A skewed by one (operand ordering)")
mut("M09", "sf_compute_tensor_exec.sv", "bi = int'(tc_s_k) * COLS + j;", "bi = j * COLS + int'(tc_s_k);",
    CORE, "B read column-major instead of row-major")
mut("M10", "sf_compute_tensor_exec.sv", "eng_act_q[e]          <= 1'b1;", "eng_act_q[e]          <= !job_done[e];",
    CORE, "done/accept race: a job accepted in the cycle another finishes is forgotten (premature launch)")
mut("M11", "sf_compute_tensor_exec.sv", "pb_q   <= 1'b1;", "pb_q   <= (nb_q == 16'd0);",
    CORE, "B column block not reloaded for the later column blocks")
mut("M12", "sf_compute_tensor_exec.sv", ".cfg_n(NW'(nblk_q))", ".cfg_n(NW'(COLS))",
    CORE, "partial column tile launched at full width")
mut("M13", "sf_compute_tensor_exec.sv", "nblk_q <= (rem_n > 16'(COLS)) ? 16'(COLS) : rem_n;", "nblk_q <= 16'(COLS);",
    CORE, "edge-block extent ignored")

# ----------------------------------------------------------------------------- vector executor
mut("M14", "sf_compute_vector_exec.sv", "ff_q      <= ff_q | va_cpl_flags;", "ff_q      <= va_cpl_flags;",
    "q2:p2_fp32:1;q2:p2_special:1", "exception flags of earlier chunks are lost (not ORed)")
mut("M15", "sf_compute_vector_exec.sv", ".cmd_rm_i(is_int ? 3'd0 : rm_q)", ".cmd_rm_i(3'd0)",
    CORE, "rounding mode ignored")
mut("M16", "sf_compute_vector_exec.sv", "`CW_OP_VMUL: va_cmd_op = is_int ? 5'(`CW_VOP_IMUL) : 5'(`CW_VOP_FMUL);", "`CW_OP_VMUL: va_cmd_op = is_int ? 5'(`CW_VOP_IMUL) : 5'(`CW_VOP_FADD);",
    CORE, "VMUL mapped to FADD")
mut("M17", "sf_compute_vector_exec.sv", "wire [31:0] off4  = e0_q << 2;", "wire [31:0] off4  = 32'd0;",
    CORE, "chunk offset ignored (vectors longer than one chunk)")
mut("M18", "sf_compute_vector_exec.sv", "pa_q <= 1'b1; pb_q <= 1'b1; pc_q <= is_fma;", "pa_q <= 1'b1; pb_q <= 1'b1; pc_q <= 1'b0;",
    CORE, "VFMA does not load operand C")

# ----------------------------------------------------------------------------- decoder
mut("M19", "sf_compute_decoder.sv", "else if (is_vec)            et_ok = (etype == `CW_ET_FP32) || (EN_INT32 && (etype == `CW_ET_INT32));", "else if (is_vec)            et_ok = (etype == `CW_ET_FP32) || (etype == `CW_ET_FP16) || (EN_INT32 && (etype == `CW_ET_INT32));",
    VALID, "FP16 accepted on vector ops (unsupported precision not rejected)")
mut("M20", "sf_compute_decoder.sv", "(({8'd0, src_a} + la) > SR_HI)", "(({8'd0, src_a} + la) >= SR_HI)",
    VALID, "range check off by one at the end of the SRAM")
mut("M21", "sf_compute_decoder.sv", "if (intersects({8'd0, dst}, ld, {8'd0, src_b}, lb)) begin", "if (1'b0) begin",
    VALID, "GEMM result overlapping B is not rejected")
mut("M22", "sf_compute_decoder.sv", "(src_b[1:0] != 2'b00)", "1'b0",
    VALID, "misaligned B of a vector op accepted")
mut("M23", "sf_compute_decoder.sv", "if (!q_bound || (claim != q_dom)) begin", "if (!q_bound) begin",
    "q2:p3_isolation:1;q2:p3_reject_table:1;q2:p3_validate:1", "forged domain field accepted (ownership check removed)")
mut("M24", "sf_compute_decoder.sv", "end else if (!dest_mask[dest]) begin", "end else if (1'b0) begin",
    VALID + ";q2:p3_isolation:1", "completion destination not validated")
mut("M25", "sf_compute_decoder.sv", "end else if (is_gemm && (k32 > 32'(KMAX))) begin", "end else if (is_gemm && (k32 > 32'(KMAX) + 32'd1)) begin",
    VALID, "K limit off by one")

# ----------------------------------------------------------------------------- guard
mut("M26", "sf_compute_guard.sv", "if (r_dom[e] == chk_dom) begin", "if (1'b1) begin",
    "q2:p3_isolation:1;q2:p3_leak:1", "region domain not compared (cross-tenant access allowed)")
mut("M27", "sf_compute_guard.sv", "if (chk_write ? r_wr[e] : r_rd[e]) any_ok = 1'b1;", "if (r_rd[e]) any_ok = 1'b1;",
    "q2:p3_isolation:1", "write permission not checked (read-only regions writable)")
mut("M28", "sf_compute_guard.sv", "contains = r_valid[e] && (qlo >= elo) && (qhi <= ehi) && (chk_len != 40'd0);", "contains = r_valid[e] && (qlo >= elo) && (chk_len != 40'd0);",
    "q2:p3_isolation:1", "range END not checked (a range may run past its region)")
mut("M29", "sf_compute_guard.sv", "else if (ov_dirty)                                pol_status <= `CW_PS_NOT_CLEAN;", "else if (1'b0)                                pol_status <= `CW_PS_NOT_CLEAN;",
    "q2:p3_leak:1", "a new region may overlap a DIRTY (revoked, unscrubbed) one: residue leak")
mut("M30", "sf_compute_guard.sv", "else if (r_dirty[ridx])                        pol_status <= `CW_PS_NOT_CLEAN;", "else if (1'b0)                        pol_status <= `CW_PS_NOT_CLEAN;",
    "q2:p3_leak:1", "a dirty entry may be reassigned without a scrub")
mut("M31", "sf_compute_guard.sv", "r_valid[ridx] <= 1'b0;\n                r_dirty[ridx] <= 1'b1;", "r_valid[ridx] <= 1'b0;",
    "q2:p3_leak:1", "REVOKE does not mark the region dirty")
mut("M32", "sf_compute_guard.sv", "r_dirty[p_idx_q] <= 1'b0;", "r_dirty[p_idx_q] <= r_dirty[p_idx_q];",
    "q2:p3_leak:1", "SCRUB never makes the region clean")
mut("M33", "sf_compute_guard.sv", "chk_rsp_valid <= 1'b1; chk_rsp_ok <= 1'b0; chk_rsp_fault <= `CW_GF_CITTMO; c_q <= C_IDLE;\n              end\n            end\n            C_WAIT:", "chk_rsp_valid <= 1'b1; chk_rsp_ok <= 1'b1; chk_rsp_fault <= `CW_GF_NONE; c_q <= C_IDLE;\n              end\n            end\n            C_WAIT:",
    EXT, "external-Citadel REQUEST-channel timeout fails OPEN (Citadel never accepts a query)")
mut("M49", "sf_compute_guard.sv", "end else if (int'(tmo_q) >= CIT_TMO) begin\n                chk_rsp_valid <= 1'b1; chk_rsp_ok <= 1'b0; chk_rsp_fault <= `CW_GF_CITTMO; c_q <= C_IDLE;", "end else if (int'(tmo_q) >= CIT_TMO) begin\n                chk_rsp_valid <= 1'b1; chk_rsp_ok <= 1'b1; chk_rsp_fault <= `CW_GF_NONE; c_q <= C_IDLE;",
    EXT, "external-Citadel ANSWER timeout fails OPEN")
mut("M34", "sf_compute_guard.sv", "else if (!any_contains) ref_fault = `CW_GF_NOMAP;", "else if (!any_contains) ref_fault = `CW_GF_PERM;",
    "q2:p3_isolation:1", "wrong fault code for an unmapped range")

# ----------------------------------------------------------------------------- scheduler / queue
mut("M35", "sf_compute_scheduler.sv", "cls[q] = (int'(wait_q[q]) >= STARVE_LIMIT) ? 2'd3 : q_prio[q*`CW_PRIO_W +: `CW_PRIO_W];", "cls[q] = q_prio[q*`CW_PRIO_W +: `CW_PRIO_W];",
    SCHED, "anti-starvation ageing disabled")
mut("M36", "sf_compute_scheduler.sv", "if (last_v_q && cand[last_q] && (int'(sticky_q) < int'(q_quantum[last_q*4 +: 4]))) begin", "if (1'b0) begin",
    SCHED, "RR quantum ignored")
mut("M37", "sf_compute_scheduler.sv", "if (elig[q] && (cls[q] > maxc)) maxc = cls[q];", "if (elig[q] && (cls[q] > maxc) && 1'b0) maxc = cls[q];",
    SCHED, "priority classes ignored")
mut("M38", "sf_compute_scheduler.sv", "assign stg_clear      = CLEAR_STAGING && f_push;", "assign stg_clear      = 1'b0;",
    ISOL, "staging buffers never cleared after a command")
mut("M39", "sf_compute_scheduler.sv", "r_dest_def_q ? (f_dmask[f_dest] ? f_dest : 4'd0) : d_dest;", "d_dest;",
    VALID + ";q2:p3_isolation:1", "a rejected command's completion goes to its UNVALIDATED claimed destination")
mut("M40", "sf_compute_scheduler.sv", "wire [RECW-1:0] rec_in = {cq_q, f_dom, fin_dest,", "wire [RECW-1:0] rec_in = {cq_q, d_claim, fin_dest,",
    "q2:p3_isolation:1;q2:p3_validate:1", "completion carries the CLAIMED domain instead of the hardware-bound one")
mut("M41", "sf_compute_scheduler.sv", "wire start_ok = clk_en_i && !pol_busy && !pol_acc && any_elig && (st_q == S_IDLE);", "wire start_ok = !pol_busy && !pol_acc && any_elig && (st_q == S_IDLE);",
    "base:p3_clken:1", "clk_en_i does not stop dispatch")
mut("M42", "sf_compute_scheduler.sv", "assign chk_write = (chk_next == 3'd3);", "assign chk_write = 1'b0;",
    "q2:p3_isolation:1", "the result buffer is checked for READ instead of WRITE permission")
mut("M43", "sf_compute_scheduler.sv", "r_detail_q   <= {8'd0, chk_rsp_fault, 1'b0, chk_cur_q + 3'd1};", "r_detail_q   <= {8'd0, chk_rsp_fault, 1'b0, chk_cur_q};",
    "q2:p3_isolation:1", "DENIED detail names the wrong operand")
mut("M44", "sf_compute_command_queue.sv", "assign sub_ready    = !sub_valid ? 1'b1 : (q_ok ? !full_v[sub_q] : 1'b1);", "assign sub_ready    = 1'b1;",
    "bp:p3_backpressure:1;q4:p3_queues:1", "queue accepts a descriptor while full (overwrites)")

# ----------------------------------------------------------------------------- tile / perf
mut("M45", "sf_compute_tile.sv", "for (int i = 0; i < ncp; i++) r[3*(2+i) +: 3] = 3'd3;", "for (int i = 0; i < ncp; i++) r[3*(2+i) +: 3] = 3'd2;",
    "base:p3_memlayer:1;q2:p1_single:1", "compute ports mapped to the wrong IronMemory domain")
mut("M46", "sf_compute_perf.sv", "inc[`CW_PC_TENSOR_MACS]  = {16'd0, ev_macs};", "inc[`CW_PC_TENSOR_MACS]  = {16'd0, ev_macs} + 64'd1;",
    "q2:p1_gemm:1", "MAC counter over-counts")
mut("M47", "sf_compute_perf.sv", "inc[`CW_PC_REJ_DENIED]   = {63'd0, ev_cpl && (ev_status == `CW_ST_DENIED)};", "inc[`CW_PC_REJ_DENIED]   = 64'd0;",
    "q2:p3_isolation:1", "isolation rejects not counted")

mut("M48", "sf_compute_guard.sv", "assign pol_ready = quiescent_i && (p_q == P_IDLE) && !pol_done;", "assign pol_ready = (p_q == P_IDLE) && !pol_done;",
    "q2:p3_leak:1", "policy operations accepted while a command is running (policy may change under a command)")


def run_mutant(m, tmp_root, keep):
    t0 = time.time()
    work = pathlib.Path(tmp_root) / m["id"]
    if work.exists():
        shutil.rmtree(work)
    work.mkdir(parents=True)
    for d in ("rtl", "third_party", "scripts", "model", "tests"):
        shutil.copytree(ROOT / d, work / d, ignore=shutil.ignore_patterns("__pycache__"))
    (work / "build").mkdir()
    f = work / m["file"]
    src = f.read_text()
    n = src.count(m["old"])
    if n != 1:
        return dict(id=m["id"], status="STALE", why=f"pattern occurs {n} times", secs=0)
    f.write_text(src.replace(m["old"], m["new"]))
    # a mutant that makes a memory job never finish hangs its simulation: that is a legitimate kill, but it must be fast
    env = dict(os.environ, CW_RUN_TIMEOUT="120")
    r = subprocess.run([sys.executable, "scripts/run_tests.py", "--plan", m["plan"], "--jobs", "2", "--out", str(work / "rep")],
                       cwd=work, capture_output=True, text=True, env=env)
    out = r.stdout + r.stderr
    if "verilator build failed" in out or "Traceback" in out:
        status = "INVALID"            # the mutant does not build: not counted
    else:
        failed = re.findall(r"^\s+FAIL\s+(\S+)\s+(\S+)", out, re.M)
        status = "KILLED" if (r.returncode != 0 or failed) else "SURVIVED"
    by_unit = None
    if status == "SURVIVED" and m.get("unit"):
        ur = subprocess.run([sys.executable, "scripts/run_unit.py", "--only", m["unit"], "--timeout", "150"], cwd=work, capture_output=True, text=True)
        if ur.returncode != 0:
            status, by_unit = "KILLED", f"unit:{m['unit']}"
    detail = [l.strip() for l in out.splitlines() if l.strip().startswith(("FAIL", "perf[", "[FAIL]", "completion", "IronMemory"))][:3]
    if not keep:
        shutil.rmtree(work, ignore_errors=True)
    return dict(id=m["id"], status=status, why=m["why"], by=sorted(set(f"{a}:{b}" for a, b in re.findall(r"^\s+FAIL\s+(\S+)\s+(\S+)", out, re.M))) + ([by_unit] if by_unit else []),
                detail=detail, secs=round(time.time() - t0))


def main():
    a = sys.argv[1:]
    if "--list" in a:
        for m in M:
            print(f"{m['id']}  {m['file'].split('/')[-1]:32s} {m['why']}")
        return 0
    sel = [m for m in M if (not a or m["id"] in a)]
    tmp = tempfile.mkdtemp(prefix="cwmut_")
    print(f"{len(sel)} mutants, working in {tmp}", flush=True)
    results = []
    with ThreadPoolExecutor(max_workers=2) as ex:
        futs = {m["id"]: ex.submit(run_mutant, m, tmp, False) for m in sel}
        for m in sel:
            r = futs[m["id"]].result()
            results.append(r)
            print(f"  {r['id']}  {r['status']:9s} {r.get('secs', 0):4d}s  {m['why']}"
                  + (f"   [{', '.join(r.get('by', [])[:3])}]" if r.get("by") else ""), flush=True)
    shutil.rmtree(tmp, ignore_errors=True)
    killed = sum(1 for r in results if r["status"] == "KILLED")
    surv = [r for r in results if r["status"] == "SURVIVED"]
    invalid = [r for r in results if r["status"] in ("INVALID", "STALE")]
    print(f"\n{killed}/{len(results) - len(invalid)} valid mutants killed; {len(surv)} survived; {len(invalid)} invalid/stale")
    out = ROOT / "reports"
    out.mkdir(exist_ok=True)
    (out / "mutation.json").write_text(json.dumps(results, indent=1))
    lines = ["# Mutation check of the new ComputeWorks RTL", "",
             f"**{killed} / {len(results) - len(invalid)} valid mutants killed** ({len(surv)} survived, {len(invalid)} invalid or stale).", "",
             "Each mutant is one deliberate RTL bug in a NEW module (the reused third-party blocks are not mutated), built in a private copy of the",
             "tree and run against the listed suites; a mutant is killed when any run fails.", "",
             "| id | file | bug | result | killed by |", "|---|---|---|---|---|"]
    for r in results:
        mm = next(x for x in M if x["id"] == r["id"])
        lines.append(f"| {r['id']} | `{mm['file'].split('/')[-1]}` | {mm['why']} | {r['status']} | {', '.join(r.get('by', [])[:3])} |")
    (out / "mutation.md").write_text("\n".join(lines) + "\n")
    return 0 if not surv else 1


if __name__ == "__main__":
    sys.exit(main())
