#!/usr/bin/env python3
"""Unit benches of the memory path:

  tb_adapter      sf_compute_memory_adapter + sf_compute_mem_engine on the real IronMemory: random 2-D READ / WRITE / FILL jobs at
                  arbitrary byte alignment, stride and pitch, checked against a byte-level shadow of memory AND of all four staging buffers.
  tb_tensor_exec  sf_compute_tensor_exec (reused TENSORCORE 02 inside) on the real IronMemory: random INT8 GEMMs vs an SV 64-bit reference.

  python3 scripts/run_unit.py                 all configurations x 3 seeds   -> reports/unit.md
  python3 scripts/run_unit.py --only adapter  one quick configuration (used by the mutation runner)
"""
import argparse
import hashlib
import pathlib
import re
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
BUILD = ROOT / "build"


def flist(path):
    out = []
    for line in (ROOT / path).read_text().splitlines():
        line = line.split("//")[0].strip()
        if not line:
            continue
        if line.startswith("-f "):
            out += flist(line[3:].strip())
        elif line.startswith("+incdir+"):
            out.append("-I" + str(ROOT / line[len("+incdir+"):]))
        else:
            out.append(str(ROOT / line))
    return out


UNITS = {
    "adapter": dict(top="tb_adapter", rtl=["sf_compute_mem_engine", "sf_compute_memory_adapter"], tensor=False,
                    configs=[dict(NUM_CP=2, DW=64), dict(NUM_CP=1, DW=64), dict(NUM_CP=2, DW=128), dict(NUM_CP=1, DW=128)]),
    "tensor_exec": dict(top="tb_tensor_exec", rtl=["sf_compute_mem_engine", "sf_compute_memory_adapter", "sf_compute_tensor_exec"], tensor=True,
                        configs=[dict(NUM_CP=1, DW=64), dict(NUM_CP=2, DW=64), dict(NUM_CP=1, DW=128), dict(NUM_CP=2, DW=128)]),
}


def build(name, params):
    u = UNITS[name]
    files = ["-I" + str(ROOT / "rtl/albion"), "-I" + str(ROOT / "tests/compute_works")] + flist("rtl/files_iron.f")
    if u["tensor"]:
        files += flist("rtl/files_tensor.f")
    files += [str(ROOT / "rtl/albion" / (m + ".sv")) for m in u["rtl"]] + [str(ROOT / "tests/compute_works" / (u["top"] + ".sv"))]
    h = hashlib.sha256()
    for f in files:
        if not f.startswith("-I"):
            h.update(pathlib.Path(f).read_bytes())
    h.update(repr(sorted(params.items())).encode())
    d = BUILD / f"unit_{u['top']}_{h.hexdigest()[:12]}"
    if not (d / "sim").exists():
        cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-O2", "-j", "2",
               "--top-module", u["top"], "-Mdir", str(d), "-o", "sim"] + [f"-G{k}={v}" for k, v in params.items()] + files
        r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
        if r.returncode != 0 or not (d / "sim").exists():
            raise RuntimeError("build failed\n" + "\n".join((r.stdout + r.stderr).splitlines()[-20:]))
        for e in d.iterdir():
            if e.name != "sim":
                shutil.rmtree(e) if e.is_dir() else e.unlink()
    return d / "sim"


def run(sim, seed, timeout):
    try:
        r = subprocess.run(["stdbuf", "-o0", "-e0", str(sim), f"+seed={seed}"], capture_output=True, text=True, timeout=timeout)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return "FAIL", 0, "timeout"
    m = re.search(r"TB_RESULT\s+\S+\s+(PASS|FAIL)\s*(?:checks=(\d+))?(?:\s*errors=(\d+))?(?:\s*checks=(\d+))?", out)
    if not m:
        return "FAIL", 0, "no result banner"
    checks = int(m.group(2) or m.group(4) or 0)
    bad = [l for l in out.splitlines() if re.search(r"%Error|\$error|sf_compute\w*: ", l)]
    return ("FAIL" if (m.group(1) != "PASS" or bad) else "PASS"), checks, (bad[0] if bad else "")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", choices=list(UNITS))
    ap.add_argument("--timeout", type=int, default=600)
    a = ap.parse_args()
    rows, ok = [], True
    for name, u in UNITS.items():
        if a.only and name != a.only:
            continue
        cfgs = u["configs"][:1] if a.only else u["configs"]
        seeds = [1] if a.only else [1, 2, 3]
        for cfg in cfgs:
            sim = build(name, cfg)
            for sd in seeds:
                res, checks, note = run(sim, sd, a.timeout)
                ok &= (res == "PASS")
                rows.append((name, cfg, sd, res, checks))
                print(f"  {res}  {name:12s} {cfg} seed {sd}  checks={checks:,} {note}", flush=True)
    if not a.only:
        out = ROOT / "reports"
        out.mkdir(exist_ok=True)
        L = ["# Unit benches (memory path)", "", f"**{sum(1 for r in rows if r[3] == 'PASS')} / {len(rows)} runs passed, {sum(r[4] for r in rows):,} checks.**", "",
             "| bench | configuration | seed | result | checks |", "|---|---|---|---|---:|"]
        for n, c, sd, res, ch in rows:
            L.append(f"| {n} | {c} | {sd} | {res} | {ch:,} |")
        (out / "unit.md").write_text("\n".join(L) + "\n")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
