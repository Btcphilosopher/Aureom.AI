#!/usr/bin/env python3
"""Lint and elaboration checks for the NEW ComputeWorks RTL.

  1. Verilator --lint-only -Wall over many parameter sets: the new RTL must produce ZERO warnings (reused third-party
     warnings are counted and reported separately; they are not ours to change).
  2. Illegal parameter sets must be REJECTED at elaboration (the tile's own $fatal checks, or the reused blocks').
  3. Icarus Verilog 12 elaboration of the reference configuration (elaboration only: no Icarus simulation is claimed).

Writes reports/lint.md and reports/lint.json.  Exit status 0 iff everything passes.
"""
import json
import pathlib
import re
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import cwsim  # noqa: E402

LINT_FLAGS = ["--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Wno-UNUSEDSIGNAL", "-Wno-UNUSEDPARAM", "-Wno-PINCONNECTEMPTY",
              "-Wno-TIMESCALEMOD", str(ROOT / "rtl/lint.vlt")]

GOOD = {
    "reference (4 lanes, 4x4, 1 port, 64 bit)": {},
    "1 lane": {"NUM_LANES": 1},
    "2 lanes": {"NUM_LANES": 2},
    "8 lanes": {"NUM_LANES": 8},
    "16 lanes": {"NUM_LANES": 16},
    "2 compute ports": {"NUM_CP": 2},
    "128-bit memory": {"DMA_DW": 128, "BANK_DEPTH": 512},
    "128-bit memory, 2 ports": {"DMA_DW": 128, "BANK_DEPTH": 512, "NUM_CP": 2},
    "4 queues": {"NUM_QUEUES": 4, "CMD_QUEUE_DEPTH": 8},
    "2 queues, depth 1 / completion 1": {"NUM_QUEUES": 2, "CMD_QUEUE_DEPTH": 1, "CPL_DEPTH": 1},
    "guard off": {"GUARD_MODE": 0},
    "external Citadel": {"GUARD_MODE": 2},
    "vector path disabled": {"EN_VECTOR": 0},
    "2x2 array": {"TENSOR_ROWS": 2, "TENSOR_COLS": 2},
    "8x8 array, 2 KiB staging": {"TENSOR_ROWS": 8, "TENSOR_COLS": 8, "STG_BYTES": 2048},
    "staging 256 B": {"STG_BYTES": 256},
    "staging clearing off": {"CLEAR_STAGING": 0},
    "ECC off, read latency 2": {"IM_ECC_EN": 0, "IM_RL": 2},
}

BAD = {   # must NOT elaborate
    "NUM_CP = 3": {"NUM_CP": 3},
    "NUM_CP = 0": {"NUM_CP": 0},
    "NUM_QUEUES = 5": {"NUM_QUEUES": 5},
    "DMA_DW = 32": {"DMA_DW": 32},
    "STG_BYTES = 100 (not a power of two)": {"STG_BYTES": 100},
    "STG_BYTES = 32 (too small)": {"STG_BYTES": 32},
    "GUARD_MODE = 3": {"GUARD_MODE": 3},
    "TENSOR_ROWS = 0": {"TENSOR_ROWS": 0},
    "NUM_LANES = 3 (not a power of two)": {"NUM_LANES": 3},
}


def files(vector=True):
    return [f for f in cwsim.rtl_files(vector) if not f.startswith("-I")] + ["-I" + str(ROOT / "rtl/albion")] + \
           [f for f in cwsim.rtl_files(vector) if f.startswith("-I")]


def run_verilator(params, vector=True):
    cmd = ["verilator"] + LINT_FLAGS + ["--top-module", "sf_compute_tile"]
    for k, v in params.items():
        cmd.append(f"-G{k}={int(v)}")
    cmd += cwsim.rtl_files(vector)
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT)
    return r.returncode, r.stdout + r.stderr


def main():
    res = {"good": [], "bad": [], "icarus": None}
    ok = True
    print("== Verilator -Wall, new RTL must be warning-free")
    for name, p in GOOD.items():
        rc, out = run_verilator(p, vector=bool(p.get("EN_VECTOR", 1)))
        warn = [l for l in out.splitlines() if re.match(r"%(Warning|Error)", l)]
        mine = [l for l in warn if "third_party" not in l]
        theirs = [l for l in warn if "third_party" in l]
        good = (rc == 0) and not mine
        ok &= good
        res["good"].append(dict(name=name, params=p, ok=good, warnings_new=len(mine), warnings_third_party=len(theirs), sample=mine[:3]))
        print(f"  {'PASS' if good else 'FAIL'}  {name:42s} new-RTL warnings: {len(mine)}   (third-party: {len(theirs)})")
        for l in mine[:3]:
            print("        ", l[:150])
    print("== illegal parameter sets must be rejected at elaboration")
    for name, p in BAD.items():
        rc, out = run_verilator(p)
        rejected = rc != 0
        ok &= rejected
        msg = next((l for l in out.splitlines() if "sf_compute_tile:" in l or "must be" in l or "hpc_param_error" in l or "Cannot find" in l or "%Error" in l), "")
        res["bad"].append(dict(name=name, params=p, ok=rejected, message=msg.strip()[:160]))
        print(f"  {'PASS' if rejected else 'FAIL'}  {name:42s} {'rejected' if rejected else 'ACCEPTED (should not be)'}")
    print("== Icarus Verilog elaboration (reference configuration)")
    r = subprocess.run(["iverilog", "-g2012", "-o", "/dev/null", "-s", "sf_compute_tile"] + cwsim.rtl_files(True),
                       capture_output=True, text=True, cwd=ROOT)
    res["icarus"] = dict(ok=r.returncode == 0, note="elaboration only; Icarus prints 'constant selects in always_*' notes and does not simulate this design correctly")
    print(f"  {'PASS' if r.returncode == 0 else 'FAIL'}  iverilog -g2012 -s sf_compute_tile (exit {r.returncode})")
    ok &= (r.returncode == 0)

    out = ROOT / "reports"
    out.mkdir(exist_ok=True)
    (out / "lint.json").write_text(json.dumps(res, indent=1))
    L = ["# Lint and elaboration", "",
         "Generated by `scripts/run_lint.py`. Tool: Verilator `--lint-only -Wall` (waiver file `rtl/lint.vlt`), Icarus Verilog 12.", "",
         f"**New RTL: {sum(g['warnings_new'] for g in res['good'])} warnings over {len(res['good'])} parameter sets. "
         f"{sum(1 for b in res['bad'] if b['ok'])} / {len(res['bad'])} illegal parameter sets rejected at elaboration.**", "",
         "The only waiver: `SYNCASYNCNET` on `sf_compute_tile.sv` — the reused TENSORCORE 02 array uses a synchronous reset on the same `rst_n` net as the asynchronously-reset ComputeWorks flops.",
         "Warnings inside `third_party/` (reused, unmodified) are counted but not ours to change.", "",
         "| parameter set | new-RTL warnings | third-party warnings |", "|---|---:|---:|"]
    for g in res["good"]:
        L.append(f"| {g['name']} | {g['warnings_new']} | {g['warnings_third_party']} |")
    L += ["", "| illegal parameter set | rejected | message |", "|---|---|---|"]
    for b in res["bad"]:
        L.append(f"| {b['name']} | {'yes' if b['ok'] else '**NO**'} | `{b['message']}` |")
    L += ["", f"Icarus Verilog 12 elaboration of the reference configuration: **{'OK' if res['icarus']['ok'] else 'FAILED'}** (elaboration only — no Icarus simulation is claimed)."]
    (out / "lint.md").write_text("\n".join(L) + "\n")
    print("\nOK" if ok else "\nFAILED")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
