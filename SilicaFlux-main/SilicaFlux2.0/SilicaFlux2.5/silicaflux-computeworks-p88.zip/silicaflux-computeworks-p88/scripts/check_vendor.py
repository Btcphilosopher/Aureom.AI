#!/usr/bin/env python3
"""Verify that every vendored third-party source is UNMODIFIED.

  python3 scripts/check_vendor.py                    check third_party/SHA256SUMS
  python3 scripts/check_vendor.py --regen            rewrite third_party/SHA256SUMS (after a deliberate re-vendoring)
  python3 scripts/check_vendor.py --archives DIR     additionally compare every file byte-for-byte with the member of the
                                                     ORIGINAL repo archive (DIR = .../SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5)
"""
import hashlib
import pathlib
import sys
import zipfile

ROOT = pathlib.Path(__file__).resolve().parent.parent
TP = ROOT / "third_party"

# vendored directory -> (source archive, member prefix inside the archive, files)
SOURCES = {
    "p84-ironmemory": ("silicaflux-p84-ironmemory.zip", "silicaflux-ironmemory/rtl/albion/", ""),
    "tensorcore02": ("silicaflux-tensorcore02.zip", "silicaflux-tensorcore02/rtl/", ""),
    "hpc-m03-vector-array": ("silicaflux-hpc-m03-vector-array.zip", "silicaflux-hpc-m03-vector-array/rtl/", ""),
}


def sha(p: pathlib.Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def vendored_files():
    return sorted(p for p in TP.rglob("*.sv"))


def main():
    args = sys.argv[1:]
    files = vendored_files()
    sums_path = TP / "SHA256SUMS"
    if "--regen" in args:
        sums_path.write_text("".join(f"{sha(p)}  {p.relative_to(TP)}\n" for p in files))
        print(f"wrote {sums_path} ({len(files)} files)")
        return 0
    bad = 0
    want = {}
    for line in sums_path.read_text().splitlines():
        h, name = line.split(None, 1)
        want[name.strip()] = h
    for p in files:
        rel = str(p.relative_to(TP))
        if want.get(rel) != sha(p):
            print(f"MODIFIED or unlisted: {rel}")
            bad += 1
    for rel in want:
        if not (TP / rel).exists():
            print(f"MISSING: {rel}")
            bad += 1
    print(f"SHA256SUMS: {len(files)} files, {'OK' if not bad else str(bad) + ' problem(s)'}")
    if "--archives" in args:
        root = pathlib.Path(args[args.index("--archives") + 1])
        for d, (zname, prefix, _x) in SOURCES.items():
            z = zipfile.ZipFile(root / zname)
            names = set(z.namelist())
            for p in sorted((TP / d).rglob("*.sv")):
                rel = p.relative_to(TP / d).as_posix()
                member = prefix + rel
                if member not in names:
                    print(f"NOT IN ARCHIVE: {zname}:{member}")
                    bad += 1
                elif z.read(member) != p.read_bytes():
                    print(f"DIFFERS FROM ARCHIVE: {zname}:{member}")
                    bad += 1
            print(f"{d}: compared with {zname}")
        print("archive comparison:", "byte-identical" if not bad else f"{bad} problem(s)")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
