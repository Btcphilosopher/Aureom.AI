#!/usr/bin/env python3
"""ComputeWorks (Project 88) regression runner.

  python3 scripts/run_tests.py                 full regression -> reports/regression.md + reports/regression.json
  python3 scripts/run_tests.py --quick         one configuration, one seed per suite (about a minute)
  python3 scripts/run_tests.py --suite p1_gemm --config base --seeds 1,2
  python3 scripts/run_tests.py --list

Staged exactly as the brief demands: stage 1 = one 4x4 INT8 tensor operation and the tensor data path; the later stages
(FP32 vectors, validation, isolation, scheduling, robustness) are only run if the earlier ones pass.  Every run is
self-checking: expected values come from the independent models in model/, never from the RTL.
"""
import argparse
import json
import os
import pathlib
import sys
import time
from concurrent.futures import ThreadPoolExecutor

ROOT = pathlib.Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "model"))
sys.path.insert(0, str(ROOT / "tests/compute_works"))
import cwsim            # noqa: E402
import gen_tests        # noqa: E402
from cwlib import Cfg   # noqa: E402
import cw_defs as D     # noqa: E402

# ------------------------------------------------------------------------------------------------ configurations
CONFIGS = {
    "base":      dict(),
    "lanes1":    dict(num_lanes=1),
    "lanes2":    dict(num_lanes=2),
    "lanes8":    dict(num_lanes=8),
    "lanes16":   dict(num_lanes=16),
    "cp2":       dict(cp=2),
    "dw128":     dict(dw=128, depth=256),
    "dw128cp2":  dict(dw=128, depth=256, cp=2),
    "stg256":    dict(stg=256),
    "arr2x2":    dict(rows=2, cols=2),
    "arr4x2":    dict(rows=4, cols=2),
    "arr8x8":    dict(rows=8, cols=8, stg=2048),
    "noecc":     dict(ecc=0),
    "q2":        dict(queues=2),
    "q4":        dict(queues=4, cmd_depth=8, cpl_depth=2),
    "bp":        dict(cmd_depth=2, cpl_depth=2),
    "ext":       dict(guard=2),
    "exthang":   dict(guard=2),
    "extnr":     dict(guard=2),
    "nostgclr":  dict(clear_staging=0),
    "novec":     dict(en_vector=0),
}
TB_EXTRA = {"exthang": {"EXT_CIT_HANG": 1}, "extnr": {"EXT_CIT_HANG": 2}, "noecc": {}}

STAGES = [
    ("stage 1: one 4x4 INT8 tensor operation, then the tensor data path", [
        ("base", "p1_single", [1]), ("base", "p1_gemm", [1, 2, 3]), ("base", "p1_overflow", [1]),
    ]),
    ("stage 2: FP32 / INT32 vector arithmetic and mixed workloads", [
        ("base", "p2_fp32", [1, 2, 3]), ("base", "p2_special", [1]), ("base", "p2_int32", [1, 2]), ("base", "p2_mixed", [1, 2, 3]),
    ]),
    ("stage 3: descriptor validation, unsupported precision, isolation, scratchpad leakage", [
        ("base", "p3_reject_table", [1]), ("base", "p3_validate", [1, 2, 3, 4]),
        ("q2", "p3_isolation", [1, 2, 3]), ("q2", "p3_leak", [1, 2]), ("base", "p3_memlayer", [1, 2]),
        ("ext", "p3_extcit", [1]), ("exthang", "p3_extcit_hang", [1]), ("extnr", "p3_extcit_noready", [1]),
        ("novec", "p3_reject_table", [1]), ("novec", "p3_validate", [1]),
    ]),
    ("stage 4: multiple queues, scheduling, back-pressure, reset, clock enable, memory errors", [
        ("q4", "p3_queues", [1, 2]), ("bp", "p3_backpressure", [1, 2]), ("base", "p3_reset", [1]),
        ("base", "p3_clken", [1]), ("base", "p3_ecc", [1, 2]),
    ]),
    ("stage 5: configuration matrix (the same tensor / vector suites on every other configuration)", [
        (c, su, [5]) for c in ("lanes1", "lanes2", "lanes8", "lanes16", "cp2", "dw128", "dw128cp2", "stg256",
                               "arr2x2", "arr4x2", "arr8x8", "noecc", "nostgclr")
        for su in ("p1_single", "p1_gemm", "p2_fp32", "p2_int32", "p2_mixed")
    ] + [(c, su, [5]) for c in ("dw128cp2", "arr8x8", "nostgclr") for su in ("p3_validate", "p3_memlayer")]
      + [("dw128cp2", "p3_isolation", [5]), ("dw128cp2", "p3_leak", [5])]),
]
CFG_FOR_SUITE_OVERRIDE = {
    ("dw128cp2", "p3_isolation"): dict(queues=2), ("dw128cp2", "p3_leak"): dict(queues=2),
}


def make_cfg(cname, suite):
    kw = dict(CONFIGS[cname])
    kw.update(CFG_FOR_SUITE_OVERRIDE.get((cname, suite), {}))
    return Cfg(**kw)


# ------------------------------------------------------------------------------------------------ post checks
def check_perf_identities(res, tally_expected, notes):
    """Exact predicted counters + structural identities between counters."""
    p = res["perf"]
    bad = []
    if not p:
        return ["no PERF dump"]
    for idx, want in tally_expected.items():
        if p.get(idx) != want:
            bad.append(f"perf[{idx}] = {p.get(idx)} expected {want}")
    P = lambda k: p.get(k, 0)
    if P(D.CW_PC_CMD_DONE) != P(D.CW_PC_CMD_OK) + P(D.CW_PC_CMD_REJ) + P(D.CW_PC_CMD_ERR):
        bad.append("DONE != OK + REJ + ERR")
    if P(D.CW_PC_PH_LOAD) + P(D.CW_PC_PH_COMPUTE) + P(D.CW_PC_PH_STORE) + P(D.CW_PC_OVERHEAD) != P(D.CW_PC_BUSY):
        bad.append("load + compute + store + overhead != busy")
    if P(D.CW_PC_BUSY) > P(D.CW_PC_CYCLES):
        bad.append("busy > cycles")
    if P(D.CW_PC_TENSOR_MACS) > P(D.CW_PC_TENSOR_PEAK):
        bad.append("MAC utilisation > 100%")
    if P(D.CW_PC_VEC_ELEMS) > P(D.CW_PC_VEC_PEAK):
        bad.append("vector utilisation > 100%")
    if P(D.CW_PC_CMD_DONE) and P(D.CW_PC_EXEC_SUM) < P(D.CW_PC_CMD_DONE):
        bad.append("EXEC_SUM smaller than the command count")
    if P(D.CW_PC_QWAIT_MAX) > P(D.CW_PC_QWAIT_SUM):
        bad.append("QWAIT_MAX > QWAIT_SUM")
    return bad


def post_check(suite, cname, script, res):
    """Suite-specific checks beyond the testbench's own comparisons.  Returns a list of problems."""
    bad = []
    if getattr(script, "perf_checkpoint", None) and suite not in ("p3_reset",):
        bad += check_perf_identities(res, script.perf_checkpoint, None)
    if suite == "p3_queues":
        got = [(int(c["q"]), int(c["tag"], 16), int(c["st"]), int(c["dom"])) for c in res["cplrecs"]]
        exp = [x for ph in script.expect_order for x in ph]
        if got != exp:
            i = next((k for k, (g, e) in enumerate(zip(got, exp)) if g != e), min(len(got), len(exp)))
            bad.append(f"completion order differs from the arbitration model at #{i}: hardware {got[i:i+1]} model {exp[i:i+1]} "
                       f"(lengths {len(got)} / {len(exp)})")
    if suite == "p3_backpressure":
        p = res["perf"]
        if p.get(D.CW_PC_STALL_CPL, 0) == 0:
            bad.append("completion back-pressure never stalled the scheduler (STALL_CPL = 0): the test did not stress it")
        if p.get(D.CW_PC_MEM_STALL, 0) == 0:
            bad.append("no memory stall cycles seen (MEM_STALL = 0)")
        conf = sum(v for a, v in res["csr"].items() if 0x100 <= a < 0x100 + 0x20 * 4 and ((a - 0x100) % 0x20) == 12)
        if conf == 0:
            bad.append("IronMemory reports no bank conflicts: the concurrent master created no contention")
        if "BG ops=" not in res["out"]:
            bad.append("background traffic report missing")
    if suite == "p3_ecc":
        st = [v for a, v in sorted(res["csr"].items()) if a == 0x008]
        vals = [int(x) for x in __import__("re").findall(r"^CSR 8 (\d+)$", res["out"], __import__("re").M)]
        if len(vals) != 2 or not (vals[0] & (1 << 5)) or not (vals[1] & (1 << 1)):
            bad.append(f"IronMemory STATUS did not show corrected (bit5) then uncorrectable (bit1) ECC errors: {vals}")
    return bad


def run_one(sim, cname, suite, seed, outdir):
    cfg = make_cfg(cname, suite)
    gen = gen_tests.SUITES[suite]
    script = gen(cfg, seed)
    path = script.write(str(outdir / f"{cname}_{suite}_{seed}.cwt"))
    r = cwsim.run(sim, [f"+script={path}", f"+seed={seed}"], timeout=int(os.environ.get("CW_RUN_TIMEOUT", "1800")))
    problems = list(r["fails"][:3]) + list(r["dut_errors"][:3])
    if r["result"] == "PASS":
        problems += post_check(suite, cname, script, r)
    ok = r["result"] == "PASS" and not problems
    return dict(config=cname, suite=suite, seed=seed, ok=ok, result=r["result"], checks=r["checks"],
                errors=r["errors"], secs=round(r["secs"], 1), problems=problems, rc=r["rc"],
                perf=r["perf"], lines=len(script.lines), commands=script.tally.cmd_in)


# ------------------------------------------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--suite")
    ap.add_argument("--config", default="base")
    ap.add_argument("--seeds", default="1")
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--plan", help="explicit plan 'config:suite:seed,seed;config:suite:seed;...' (used by the mutation runner)")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--out", default=str(ROOT / "reports"))
    a = ap.parse_args()

    if a.list:
        for title, items in STAGES:
            print(title)
            for c, su, sd in items:
                print(f"   {c:9s} {su:16s} seeds {sd}")
        return 0

    outdir = pathlib.Path(a.out)
    outdir.mkdir(parents=True, exist_ok=True)
    tdir = ROOT / "build" / "tests"
    tdir.mkdir(parents=True, exist_ok=True)

    stages = STAGES
    if a.plan:
        items = []
        for part in a.plan.split(";"):
            c, su, sd = part.split(":")
            items.append((c, su, [int(x) for x in sd.split(",")]))
        stages = [("plan", items)]
    elif a.suite:
        stages = [("selected", [(a.config, a.suite, [int(x) for x in a.seeds.split(",")])])]
    elif a.quick:
        stages = [(t, [(c, su, sd[:1]) for c, su, sd in items if c in ("base", "q2", "q4", "bp", "ext", "exthang")] or items[:1])
                  for t, items in STAGES[:4]]

    all_res, t_start = [], time.time()
    built = {}
    stop = False
    for title, items in stages:
        print(f"\n== {title}", flush=True)
        # build every needed configuration first (sequential: verilator itself uses 4 jobs)
        for c, su, sd in items:
            key = (c, su in ("p3_isolation", "p3_leak") and c == "dw128cp2")
            if (c, key) in built:
                continue
            cfg = make_cfg(c, su)
            params = dict(cfg.vparams())
            params.update(TB_EXTRA.get(c, {}))
            built[(c, key)] = cwsim.build("tb_compute_tile", params, vector=bool(cfg.en_vector), quiet=False)
        jobs = []
        for c, su, sd in items:
            key = (c, su in ("p3_isolation", "p3_leak") and c == "dw128cp2")
            for seed in sd:
                jobs.append((built[(c, key)], c, su, seed))
        with ThreadPoolExecutor(max_workers=a.jobs) as ex:
            futs = [ex.submit(run_one, sim, c, su, seed, tdir) for sim, c, su, seed in jobs]
            stage_ok = True
            for f in futs:
                r = f.result()
                all_res.append(r)
                flag = "PASS" if r["ok"] else "FAIL"
                print(f"  {flag}  {r['config']:9s} {r['suite']:16s} seed {r['seed']}  checks={r['checks']:>8d}  {r['secs']:5.1f}s", flush=True)
                for pr in r["problems"][:4]:
                    print("        ", pr)
                stage_ok &= r["ok"]
        if not stage_ok:
            print(f"\n*** stage failed: later stages are NOT run: {title}", flush=True)
            stop = True
            break

    n_ok = sum(1 for r in all_res if r["ok"])
    total_checks = sum(r["checks"] for r in all_res)
    elapsed = time.time() - t_start
    print(f"\n{n_ok}/{len(all_res)} runs passed, {total_checks:,} checks, {elapsed:.0f}s", flush=True)
    (outdir / "regression.json").write_text(json.dumps(
        dict(runs=[{k: v for k, v in r.items() if k != "perf"} for r in all_res], passed=n_ok, total=len(all_res),
             checks=total_checks, seconds=round(elapsed), stopped_early=stop), indent=1))
    write_report(outdir / "regression.md", all_res, n_ok, total_checks, elapsed, stop)
    return 0 if (n_ok == len(all_res) and not stop) else 1


def write_report(path, res, n_ok, total_checks, elapsed, stop):
    lines = ["# ComputeWorks regression", "",
             "Generated by `scripts/run_tests.py`.  Every run is self-checking against the independent models in `model/`.", "",
             f"**{n_ok} / {len(res)} runs passed - {total_checks:,} checks - {elapsed:.0f} s**" + ("  (STOPPED EARLY)" if stop else ""), "",
             "| config | suite | seed | result | checks | commands | s |", "|---|---|---|---|---|---|---|"]
    for r in res:
        lines.append(f"| {r['config']} | {r['suite']} | {r['seed']} | {'PASS' if r['ok'] else 'FAIL'} | {r['checks']:,} | {r['commands']} | {r['secs']} |")
    path.write_text("\n".join(lines) + "\n")


if __name__ == "__main__":
    sys.exit(main())
