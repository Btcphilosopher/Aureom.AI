# Mutation check of the new ComputeWorks RTL

**49 / 49 valid mutants killed** (0 survived, 0 invalid or stale).

Each mutant is one deliberate RTL bug in a NEW module (the reused third-party blocks are not mutated), built in a private copy of the
tree and run against the listed suites; a mutant is killed when any run fails.

| id | file | bug | result | killed by |
|---|---|---|---|---|
| M01 | `sf_compute_mem_engine.sv` | write strobe one byte too wide (corrupts the neighbour byte) | KILLED | q2:p1_gemm, q2:p2_fp32, q2:p2_int32 |
| M02 | `sf_compute_mem_engine.sv` | scatter descriptor always starts at lane 0 (unaligned reads land in the wrong staging bytes) | KILLED | q2:p1_gemm, q2:p1_single, q2:p2_mixed |
| M03 | `sf_compute_mem_engine.sv` | row stride ignored on the request side | KILLED | q2:p1_gemm, q2:p2_mixed |
| M04 | `sf_compute_mem_engine.sv` | memory error responses are dropped (a failed access would complete as OK) | KILLED | base:p3_memlayer |
| M05 | `sf_compute_mem_engine.sv` | one extra byte beyond the row is scattered into staging (data leakage across rows) | KILLED | unit:adapter |
| M06 | `sf_compute_memory_adapter.sv` | stg_clear does nothing: scratchpad residue survives a command | KILLED | base:p3_memlayer, q2:p3_isolation, q2:p3_leak |
| M07 | `sf_compute_tensor_exec.sv` | INT32 accumulation subtracts C_in | KILLED | q2:p1_gemm, q2:p2_mixed |
| M08 | `sf_compute_tensor_exec.sv` | k-slice of A skewed by one (operand ordering) | KILLED | q2:p1_gemm, q2:p1_single, q2:p2_mixed |
| M09 | `sf_compute_tensor_exec.sv` | B read column-major instead of row-major | KILLED | q2:p1_gemm, q2:p1_single, q2:p2_mixed |
| M10 | `sf_compute_tensor_exec.sv` | done/accept race: a job accepted in the cycle another finishes is forgotten (premature launch) | KILLED | q2:p1_gemm, q2:p1_single, q2:p2_mixed |
| M11 | `sf_compute_tensor_exec.sv` | B column block not reloaded for the later column blocks | KILLED | q2:p1_gemm, q2:p2_mixed |
| M12 | `sf_compute_tensor_exec.sv` | partial column tile launched at full width | KILLED | q2:p1_gemm, q2:p2_mixed |
| M13 | `sf_compute_tensor_exec.sv` | edge-block extent ignored | KILLED | q2:p1_gemm, q2:p2_mixed |
| M14 | `sf_compute_vector_exec.sv` | exception flags of earlier chunks are lost (not ORed) | KILLED | q2:p2_fp32, q2:p2_special |
| M15 | `sf_compute_vector_exec.sv` | rounding mode ignored | KILLED | q2:p2_fp32, q2:p2_mixed |
| M16 | `sf_compute_vector_exec.sv` | VMUL mapped to FADD | KILLED | q2:p2_fp32, q2:p2_mixed |
| M17 | `sf_compute_vector_exec.sv` | chunk offset ignored (vectors longer than one chunk) | KILLED | q2:p2_fp32 |
| M18 | `sf_compute_vector_exec.sv` | VFMA does not load operand C | KILLED | q2:p2_fp32, q2:p2_mixed |
| M19 | `sf_compute_decoder.sv` | FP16 accepted on vector ops (unsupported precision not rejected) | KILLED | q2:p3_reject_table |
| M20 | `sf_compute_decoder.sv` | range check off by one at the end of the SRAM | KILLED | q2:p3_reject_table |
| M21 | `sf_compute_decoder.sv` | GEMM result overlapping B is not rejected | KILLED | q2:p3_reject_table, q2:p3_validate |
| M22 | `sf_compute_decoder.sv` | misaligned B of a vector op accepted | KILLED | q2:p3_reject_table, q2:p3_validate |
| M23 | `sf_compute_decoder.sv` | forged domain field accepted (ownership check removed) | KILLED | q2:p3_isolation, q2:p3_reject_table, q2:p3_validate |
| M24 | `sf_compute_decoder.sv` | completion destination not validated | KILLED | q2:p3_isolation, q2:p3_reject_table, q2:p3_validate |
| M25 | `sf_compute_decoder.sv` | K limit off by one | KILLED | q2:p3_reject_table |
| M26 | `sf_compute_guard.sv` | region domain not compared (cross-tenant access allowed) | KILLED | q2:p3_isolation |
| M27 | `sf_compute_guard.sv` | write permission not checked (read-only regions writable) | KILLED | q2:p3_isolation |
| M28 | `sf_compute_guard.sv` | range END not checked (a range may run past its region) | KILLED | q2:p3_isolation |
| M29 | `sf_compute_guard.sv` | a new region may overlap a DIRTY (revoked, unscrubbed) one: residue leak | KILLED | q2:p3_leak |
| M30 | `sf_compute_guard.sv` | a dirty entry may be reassigned without a scrub | KILLED | q2:p3_leak |
| M31 | `sf_compute_guard.sv` | REVOKE does not mark the region dirty | KILLED | q2:p3_leak |
| M32 | `sf_compute_guard.sv` | SCRUB never makes the region clean | KILLED | q2:p3_leak |
| M33 | `sf_compute_guard.sv` | external-Citadel REQUEST-channel timeout fails OPEN (Citadel never accepts a query) | KILLED | extnr:p3_extcit_noready |
| M49 | `sf_compute_guard.sv` | external-Citadel ANSWER timeout fails OPEN | KILLED | exthang:p3_extcit_hang |
| M34 | `sf_compute_guard.sv` | wrong fault code for an unmapped range | KILLED | q2:p3_isolation |
| M35 | `sf_compute_scheduler.sv` | anti-starvation ageing disabled | KILLED | q4:p3_queues |
| M36 | `sf_compute_scheduler.sv` | RR quantum ignored | KILLED | q4:p3_queues |
| M37 | `sf_compute_scheduler.sv` | priority classes ignored | KILLED | q4:p3_queues |
| M38 | `sf_compute_scheduler.sv` | staging buffers never cleared after a command | KILLED | base:p3_memlayer, q2:p3_isolation, q2:p3_leak |
| M39 | `sf_compute_scheduler.sv` | a rejected command's completion goes to its UNVALIDATED claimed destination | KILLED | q2:p3_isolation, q2:p3_reject_table, q2:p3_validate |
| M40 | `sf_compute_scheduler.sv` | completion carries the CLAIMED domain instead of the hardware-bound one | KILLED | q2:p3_isolation, q2:p3_validate |
| M41 | `sf_compute_scheduler.sv` | clk_en_i does not stop dispatch | KILLED | base:p3_clken |
| M42 | `sf_compute_scheduler.sv` | the result buffer is checked for READ instead of WRITE permission | KILLED | q2:p3_isolation |
| M43 | `sf_compute_scheduler.sv` | DENIED detail names the wrong operand | KILLED | q2:p3_isolation |
| M44 | `sf_compute_command_queue.sv` | queue accepts a descriptor while full (overwrites) | KILLED | bp:p3_backpressure |
| M45 | `sf_compute_tile.sv` | compute ports mapped to the wrong IronMemory domain | KILLED | base:p3_memlayer, q2:p1_single |
| M46 | `sf_compute_perf.sv` | MAC counter over-counts | KILLED | q2:p1_gemm |
| M47 | `sf_compute_perf.sv` | isolation rejects not counted | KILLED | q2:p3_isolation |
| M48 | `sf_compute_guard.sv` | policy operations accepted while a command is running (policy may change under a command) | KILLED | q2:p3_leak |
