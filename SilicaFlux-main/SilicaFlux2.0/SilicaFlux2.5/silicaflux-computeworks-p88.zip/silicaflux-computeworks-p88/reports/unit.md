# Unit benches (memory path)

**24 / 24 runs passed, 28,792,992 checks.**

| bench | configuration | seed | result | checks |
|---|---|---|---|---:|
| adapter | {'NUM_CP': 2, 'DW': 64} | 1 | PASS | 1,076,741 |
| adapter | {'NUM_CP': 2, 'DW': 64} | 2 | PASS | 1,053,709 |
| adapter | {'NUM_CP': 2, 'DW': 64} | 3 | PASS | 1,053,718 |
| adapter | {'NUM_CP': 1, 'DW': 64} | 1 | PASS | 1,399,187 |
| adapter | {'NUM_CP': 1, 'DW': 64} | 2 | PASS | 1,325,459 |
| adapter | {'NUM_CP': 1, 'DW': 64} | 3 | PASS | 1,440,659 |
| adapter | {'NUM_CP': 2, 'DW': 128} | 1 | PASS | 1,662,496 |
| adapter | {'NUM_CP': 2, 'DW': 128} | 2 | PASS | 1,662,485 |
| adapter | {'NUM_CP': 2, 'DW': 128} | 3 | PASS | 1,645,079 |
| adapter | {'NUM_CP': 1, 'DW': 128} | 1 | PASS | 2,289,043 |
| adapter | {'NUM_CP': 1, 'DW': 128} | 2 | PASS | 2,184,595 |
| adapter | {'NUM_CP': 1, 'DW': 128} | 3 | PASS | 2,210,707 |
| tensor_exec | {'NUM_CP': 1, 'DW': 64} | 1 | PASS | 566,782 |
| tensor_exec | {'NUM_CP': 1, 'DW': 64} | 2 | PASS | 566,530 |
| tensor_exec | {'NUM_CP': 1, 'DW': 64} | 3 | PASS | 566,536 |
| tensor_exec | {'NUM_CP': 2, 'DW': 64} | 1 | PASS | 566,782 |
| tensor_exec | {'NUM_CP': 2, 'DW': 64} | 2 | PASS | 566,530 |
| tensor_exec | {'NUM_CP': 2, 'DW': 64} | 3 | PASS | 566,536 |
| tensor_exec | {'NUM_CP': 1, 'DW': 128} | 1 | PASS | 1,065,083 |
| tensor_exec | {'NUM_CP': 1, 'DW': 128} | 2 | PASS | 1,064,862 |
| tensor_exec | {'NUM_CP': 1, 'DW': 128} | 3 | PASS | 1,064,764 |
| tensor_exec | {'NUM_CP': 2, 'DW': 128} | 1 | PASS | 1,065,083 |
| tensor_exec | {'NUM_CP': 2, 'DW': 128} | 2 | PASS | 1,064,862 |
| tensor_exec | {'NUM_CP': 2, 'DW': 128} | 3 | PASS | 1,064,764 |
