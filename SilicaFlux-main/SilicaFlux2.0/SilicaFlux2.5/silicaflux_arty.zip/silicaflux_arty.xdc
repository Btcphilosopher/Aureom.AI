## =============================================================================
## silicaflux_arty.xdc
## SilicaFlux SoC - Digilent Arty A7-100T board constraints
## Device : xc7a100tcsg324-1 (Artix-7 XC7A100T, CSG324, speed grade -1)
##
## Board-level top ports
##   clk        in   100 MHz system oscillator          E3        bank 35 (MRCC)
##   reset_n    in   RESET push-button ck_rst, act-low  C2        bank 35
##   uart_rx    in   USB-UART uart_txd_in  (host->FPGA) A9        bank 16
##   uart_tx    out  USB-UART uart_rxd_out (FPGA->host) D10       bank 16
##   led[3:0]   out  User LEDs LD4..LD7                 H5 J5 T9 T10
##
## Primary clock "clk" is defined here with the same name, period and waveform
## as synth/silicaflux.sdc. Do not load silicaflux.sdc in the same constraint
## set for this board build.
## =============================================================================

## -----------------------------------------------------------------------------
## Primary clock - 100 MHz, 10.000 ns, 50 % duty cycle
## -----------------------------------------------------------------------------
set_property -dict { PACKAGE_PIN E3 IOSTANDARD LVCMOS33 } [get_ports clk]
create_clock -name clk -period 10.000 -waveform {0.000 5.000} [get_ports clk]

set_clock_uncertainty -setup 0.200 [get_clocks clk]
set_clock_uncertainty -hold  0.100 [get_clocks clk]

## -----------------------------------------------------------------------------
## Reset - RESET push-button (ck_rst), active-low, asynchronous
## -----------------------------------------------------------------------------
set_property -dict { PACKAGE_PIN C2 IOSTANDARD LVCMOS33 PULLUP TRUE } [get_ports reset_n]

## -----------------------------------------------------------------------------
## Debug UART - FTDI FT2232HQ channel B, 3.3 V, idle high
## -----------------------------------------------------------------------------
set_property -dict { PACKAGE_PIN A9  IOSTANDARD LVCMOS33 PULLUP TRUE } [get_ports uart_rx]
set_property -dict { PACKAGE_PIN D10 IOSTANDARD LVCMOS33 }             [get_ports uart_tx]

## -----------------------------------------------------------------------------
## Status LEDs - LD4..LD7, active-high
## -----------------------------------------------------------------------------
set_property -dict { PACKAGE_PIN H5  IOSTANDARD LVCMOS33 } [get_ports {led[0]}]
set_property -dict { PACKAGE_PIN J5  IOSTANDARD LVCMOS33 } [get_ports {led[1]}]
set_property -dict { PACKAGE_PIN T9  IOSTANDARD LVCMOS33 } [get_ports {led[2]}]
set_property -dict { PACKAGE_PIN T10 IOSTANDARD LVCMOS33 } [get_ports {led[3]}]

## -----------------------------------------------------------------------------
## I/O delays - 2.0 ns max / 0.0 ns min budget, as in silicaflux.sdc
## -----------------------------------------------------------------------------
set_input_delay  -clock [get_clocks clk] -max 2.000 [get_ports {reset_n uart_rx}]
set_input_delay  -clock [get_clocks clk] -min 0.000 [get_ports {reset_n uart_rx}]

set_output_delay -clock [get_clocks clk] -max 2.000 [get_ports {uart_tx led[*]}]
set_output_delay -clock [get_clocks clk] -min 0.000 [get_ports {uart_tx led[*]}]

## -----------------------------------------------------------------------------
## Timing exceptions - asynchronous board I/O
## reset_n and uart_rx are synchronised on-chip by 2-FF synchronisers.
## uart_tx and led[*] are sampled asynchronously off-chip.
## -----------------------------------------------------------------------------
set_false_path -from [get_ports reset_n]
set_false_path -from [get_ports uart_rx]
set_false_path -to   [get_ports uart_tx]
set_false_path -to   [get_ports {led[*]}]

## -----------------------------------------------------------------------------
## Configuration - bank 0 at 3.3 V, Quad-SPI boot flash
## -----------------------------------------------------------------------------
set_property CFGBVS VCCO                      [current_design]
set_property CONFIG_VOLTAGE 3.3               [current_design]
set_property CONFIG_MODE SPIx4                [current_design]
set_property BITSTREAM.CONFIG.SPI_BUSWIDTH 4  [current_design]
set_property BITSTREAM.CONFIG.CONFIGRATE 33   [current_design]
set_property BITSTREAM.GENERAL.COMPRESS TRUE  [current_design]
