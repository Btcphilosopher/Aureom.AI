# RTL code coverage of the test suites

Verilator 5.020 `--coverage-line --coverage-toggle`, merged by source location over: p1_L1, p1_L3, sys_a, sys_b, sys_c.  **Line** = statement / branch points; **toggle** = signal bits that changed 0->1 and 1->0 (counted as one point per bit and object).
A point counts as covered when ANY run hit it.  This measures how much of the RTL the tests execute; it is not a measure of correctness
and not fault coverage (`reports/coverage.md`).

| file | line points | % | toggle points | % |
|---|---:|---:|---:|---:|
| `sf_mbist_pattern.sv` | 8 / 8 | 100.0 | 22 / 25 | 88.0 |
| `sf_mbist_addr_seq.sv` | 5 / 5 | 100.0 | 27 / 27 | 100.0 |
| `sf_mbist_arbiter.sv` | 50 / 55 | 90.9 | 63 / 132 | 47.7 |
| `sf_mbist_failreg.sv` | 29 / 32 | 90.6 | 633 / 924 | 68.5 |
| `sf_mbist_fsm.sv` | 98 / 102 | 96.1 | 495 / 749 | 66.1 |
| `sf_mbist_ras_if.sv` | 24 / 31 | 77.4 | 141 / 324 | 43.5 |
| `sf_mbist_repair.sv` | 41 / 43 | 95.3 | 137 / 224 | 61.2 |
| `sf_mbist_regs.sv` | 69 / 70 | 98.6 | 678 / 1884 | 36.0 |
| `sf_sram_mbist.sv` | 3 / 3 | 100.0 | 740 / 1281 | 57.8 |
| **all RTL** | 327 / 349 | 93.7 | 2936 / 5570 | 52.7 |

## Statements / branches no run reached

### `rtl/sf_mbist_arbiter.sv`
* L107: `if (intrusion_cnt_o != 16'hFFFF) intrusion_cnt_o <= intrusion_cnt_o + 1'b1;`
* L137: `if (!permit_i) begin hold_q <= 1'b1; evt_perm_loss_o <= 1'b1; st <= A_REL0; end`
* L138: `else if (!own_req_i)                          st <= A_REL0;`
* L148: `if (dirty_i) evt_reinit_req_o <= 1'b1;`
* L166: `default: st <= A_IDLE;`

### `rtl/sf_mbist_failreg.sv`
* L183: `if (total_q != 32'hFFFF_FFFF) total_q <= total_q + 1'b1;`
* L184: `if (bank_cnt_q[f_bank_i*16 +: 16] != 16'hFFFF)`
* L194: `if (lost_q != 16'hFFFF) lost_q <= lost_q + 1'b1;`

### `rtl/sf_mbist_fsm.sv`
* L379: `if (bad) st_q <= S_REL;`
* L386: `if (bad) st_q <= S_REL;`
* L431: `else if (tested_q != mask_q) begin`
* L438: `default: st_q <= S_IDLE;`

### `rtl/sf_mbist_ras_if.sv`
* L98: `if (p_first) begin if (lost_o != 16'hFFFF) lost_o <= lost_o + 1'b1; evt_lost_o <= 1'b1; end`
* L106: `if (p_sum) begin if (lost_o != 16'hFFFF) lost_o <= lost_o + 1'b1; evt_lost_o <= 1'b1; end`
* L113: `if (p_err[e]) begin if (lost_o != 16'hFFFF) lost_o <= lost_o + 1'b1; evt_lost_o <= 1'b1; end`

### `rtl/sf_mbist_repair.sv`
* L97: `for (int j = 0; j < SC; j++) if (!cv[j] && !placed) begin`
* L105: `for (int j = 0; j < SC; j++) if (!cv[j] && !placed) begin`

### `rtl/sf_mbist_regs.sv`
* L309: `default: ;`
