# Lint

`verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM` over the nine synthesizable RTL files (Verilator 5.020), top `sf_sram_mbist` with default parameters.

**Clean: no warnings.**

Unused-signal / unused-parameter warnings are suppressed on purpose: several interfaces carry fields that a given configuration does not use.
Not run: technology-mapped synthesis, timing, CDC or formal tools (none is installed here).  A Yosys 0.33 generic `synth` smoke test is part of the regression (see regression.md).
