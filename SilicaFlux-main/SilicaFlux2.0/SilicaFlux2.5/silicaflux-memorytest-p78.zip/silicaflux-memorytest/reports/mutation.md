# MBIST mutation testing

41 deliberate single-point bugs injected into the RTL (`sim/run_mutants.py`), each compiled with Icarus Verilog and run against `tb_p1_march_one_bank` (read latency 1 and 3) and `tb_sf_sram_mbist` (default and latency 2 + test pipe 1).  Control (unmutated) run: **CONTROL-PASS**.

**Killed: 39 / 41**   survivors: 2   invalid / build errors: 0

| id | file | injected bug | result | detail |
|---|---|---|---|---|
| F01 | `sf_mbist_fsm.sv` | March element 3 runs ascending instead of descending | KILLED | p1-L1: killed (8 failed checks)  |
| F02 | `sf_mbist_fsm.sv` | March element 2 reads/writes the wrong polarity | KILLED | p1-L1: killed (37 failed checks)  |
| F03 | `sf_mbist_fsm.sv` | final read element of March C- dropped | KILLED | p1-L1: killed (12 failed checks)  |
| F04 | `sf_mbist_fsm.sv` | compare at the wrong pipeline stage (wrong read latency) | KILLED | p1-L1: pass; p1-L3: killed (20 failed checks)  |
| F05 | `sf_mbist_fsm.sv` | permission is not part of the issue gate | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (4 failed checks)  |
| F06 | `sf_mbist_fsm.sv` | ownership is not part of the issue gate | SURVIVED | p1-L1: pass; p1-L3: pass; sys-default: pass; sys-L2TP1: pass (redundant defence in depth in the integrated design: the arbiter drops own_ok only together with permission or after the engine's own release; observable only with a different arbiter) |
| F07 | `sf_mbist_fsm.sv` | an aborted run reports PASS | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (4 failed checks)  |
| F08 | `sf_mbist_fsm.sv` | an interrupted bank is marked tested | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (1 failed checks)  |
| F09 | `sf_mbist_fsm.sv` | failures do not change the result | KILLED | p1-L1: killed (10 failed checks)  |
| F10 | `sf_mbist_fsm.sv` | unread failure data may be overwritten by a new start | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (2 failed checks)  |
| F11 | `sf_mbist_fsm.sv` | banks without a raw test port are tested | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (25 failed checks)  |
| F12 | `sf_mbist_fsm.sv` | out-of-range row window accepted | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (5 failed checks)  |
| F13 | `sf_mbist_fsm.sv` | stop-on-fail ignored | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (3 failed checks)  |
| F14 | `sf_mbist_fsm.sv` | array never marked dirty: no re-initialisation | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (7 failed checks)  |
| F15 | `sf_mbist_fsm.sv` | banks visited highest-first | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (6 failed checks)  |
| F16 | `sf_mbist_fsm.sv` | background sweep runs one pass too few | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (1 failed checks)  |
| F17 | `sf_mbist_fsm.sv` | run watchdog never fires | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (2 failed checks)  |
| F18 | `sf_mbist_fsm.sv` | pipeline not drained before the bank / pass ends | KILLED | p1-L1: pass; p1-L3: pass; sys-default: pass; sys-L2TP1: killed (1 failed checks)  |
| A01 | `sf_mbist_addr_seq.sv` | ascending sequence stops one address early | KILLED | p1-L1: killed (23 failed checks)  |
| A02 | `sf_mbist_addr_seq.sv` | descending sequence starts at the wrong end | KILLED | p1-L1: killed (14 failed checks)  |
| P01 | `sf_mbist_pattern.sv` | checkerboard not inverted on odd rows | KILLED | p1-L1: killed (1 failed checks)  |
| P02 | `sf_mbist_pattern.sv` | address pattern copies not inverted (ambiguous aliasing) | KILLED | p1-L1: killed (1 failed checks)  |
| R01 | `sf_mbist_arbiter.sv` | ownership taken without waiting for the memory to drain | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (5 failed checks)  |
| R02 | `sf_mbist_arbiter.sv` | quiesce acknowledge not required in QUIESCE | SURVIVED | p1-L1: pass; p1-L3: pass; sys-default: pass; sys-L2TP1: pass (equivalent: the acknowledge is ALSO required in DRAIN (idle cycles are counted only while it holds), so ownership still cannot be taken without it) |
| R03 | `sf_mbist_arbiter.sv` | memory returned to service without re-initialisation | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (8 failed checks)  |
| R04 | `sf_mbist_arbiter.sv` | ownership fault is not sticky | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (3 failed checks)  |
| R05 | `sf_mbist_arbiter.sv` | intrusions are not counted / reported | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (4 failed checks)  |
| R06 | `sf_mbist_arbiter.sv` | array handed to the test bus during quiesce, before the drain | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (7 failed checks)  |
| R07 | `sf_mbist_arbiter.sv` | quiesce raised late (one state after the request) | KILLED | p1-L1: killed (98 failed checks)  |
| Q01 | `sf_mbist_failreg.sv` | first-failure record is overwritten by later failures | KILLED | p1-L1: killed (13 failed checks)  |
| Q02 | `sf_mbist_failreg.sv` | FIFO overflow silently lost | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (2 failed checks)  |
| Q03 | `sf_mbist_failreg.sv` | stuck-at-0 / stuck-at-1 symptom classes swapped | KILLED | p1-L1: killed (7 failed checks)  |
| Q04 | `sf_mbist_failreg.sv` | unread data never protected | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (3 failed checks)  |
| Q05 | `sf_mbist_failreg.sv` | reported bit index is the HIGHEST failing bit, not the lowest | KILLED | p1-L1: killed (1 failed checks)  |
| G01 | `sf_mbist_regs.sv` | bank-index field decoded from the wrong bits | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (39 failed checks)  |
| G02 | `sf_mbist_regs.sv` | write-1-to-clear does not clear | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (1 failed checks)  |
| G03 | `sf_mbist_regs.sv` | writes to read-only / unmapped registers not rejected | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (2 failed checks)  |
| S01 | `sf_mbist_ras_if.sv` | timeout and error RAS types swapped | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (2 failed checks)  |
| S02 | `sf_mbist_ras_if.sv` | events claim a correction was performed | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (1 failed checks)  |
| B01 | `sf_mbist_repair.sv` | single-cell failures consume spare rows instead of columns | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (1 failed checks)  |
| B02 | `sf_mbist_repair.sv` | unrepairable banks reported as repairable | KILLED | p1-L1: pass; p1-L3: pass; sys-default: killed (1 failed checks)  |

## Survivors

* **F06** - ownership is not part of the issue gate.  Explanation: redundant defence in depth in the integrated design: the arbiter drops own_ok only together with permission or after the engine's own release; observable only with a different arbiter.
* **R02** - quiesce acknowledge not required in QUIESCE.  Explanation: equivalent: the acknowledge is ALSO required in DRAIN (idle cycles are counted only while it holds), so ownership still cannot be taken without it.

A full kill count says nothing about faults nobody thought to inject; it shows that the listed bug classes cannot pass unnoticed.
