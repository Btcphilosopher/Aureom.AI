// =============================================================================
// Phase 1 testbench: March C- on ONE SRAM bank.
// Core modules only (engine FSM + arbiter + failure register) wired straight to one fault-model bank, no top.
//   P1.1  fault-free March C-: PASS, exact 10N operation count, bus trace == independently generated golden
//         March C- (element order, ascending / descending, op order, data), tst_ce only while owned
//   P1.2  ownership sequence observed on the wires (quiesce before tst_active, idle before ownership, re-init)
//   P1.3  one fault at a time (SAF0/1, TF up/down, AF none/alias/multi, CFin, CFid, CFst): FAIL + first-failure
//         signature derived BY HAND from the March C- definition (element, row, bit, symptom class)
//   P1.4  MATS+ weaker than March C-; descending-only window; single-row window; READ_LATENCY via -GL=
// =============================================================================
`timescale 1ns/1ps
`include "sf_mbist_defs.svh"
`include "tb_common.svh"

module tb_p1_march_one_bank;
  parameter int ROWS = 16;
  parameter int W    = 8;
  parameter int L    = 1;                    // READ_LATENCY of the bank (also the engine compare latency LT)
  localparam int AW  = (ROWS > 1) ? $clog2(ROWS) : 1;
  localparam int BITW = (W > 1) ? $clog2(W) : 1;

  integer errors = 0, checks = 0;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---- control
  logic start, abort, clear, permit;
  logic [3:0] cfg_algo; logic [2:0] cfg_pat; logic [3:0] cfg_k; logic cfg_sweep; logic [1:0] cfg_col;
  logic cfg_stop, cfg_reinit; logic [AW-1:0] lo, hi;
  logic [31:0] cfg_wdog;
  logic traffic, rogue;

  // ---- wires
  wire own_req, own_ok, own_idle, own_fault, dirty, reinit_en;
  wire quiesce, q_ack, idle, init_start, init_busy, func_req, tst_active;
  wire [0:0] tst_sel; wire tst_ce, tst_we; wire [AW-1:0] tst_addr; wire [W-1:0] tst_wdata; wire [W-1:0] tst_rdata;
  wire f_valid; wire [0:0] f_bank; wire [AW-1:0] f_row; wire [2:0] f_elem; wire f_op, f_pol; wire [3:0] f_pass;
  wire [2:0] f_pat; wire [W-1:0] f_exp, f_obs, f_mask, syn; wire clr_fail;
  wire busy, done; wire [2:0] result; wire [3:0] fsm_state; wire [0:0] cur_bank; wire [3:0] cur_pass; wire [2:0] cur_elem;
  wire [AW-1:0] cur_addr; wire [31:0] cycles; wire [0:0] tested; wire [`MB_NERR-1:0] evt;
  wire pending; wire [31:0] fail_count;
  wire fv; wire [0:0] fbank; wire [AW-1:0] frow; wire [BITW-1:0] fbit; wire fbitv, finc; wire [2:0] felem; wire fop, fpol;
  wire [3:0] fpass, fcls; wire [AW-1:0] falias; wire [W-1:0] fexp, fobs;
  wire [3:0] arb_state;
  wire [7:0] inflight; wire func_acc; wire [31:0] fchk_cnt, fchk_err, facc_cnt, fblk, facc_in_test;
  wire [15:0] intr_cnt; wire e_own_to, e_re_to, e_perm, e_intr, e_re_req;

  sf_mbist_sram_sys #(.NBANK(1), .ROWS(ROWS), .W(W), .READ_LATENCY(L)) sys (
    .clk(clk), .rst_n(rst_n), .quiesce_i(quiesce), .quiesce_ack_o(q_ack), .idle_o(idle), .init_start_i(init_start),
    .init_busy_o(init_busy), .func_req_o(func_req), .tst_active_i(tst_active), .tst_sel_i(tst_sel), .tst_ce_i(tst_ce),
    .tst_we_i(tst_we), .tst_addr_i(tst_addr), .tst_wdata_i(tst_wdata), .tst_rdata_o(tst_rdata),
    .traffic_en_i(traffic), .rogue_i(rogue), .ctl_no_ack_i(1'b0), .ctl_no_idle_i(1'b0), .ctl_no_init_i(1'b0), .init_on_reset_i(1'b0),
    .ack_delay_i(8'd0), .drain_extra_i(8'd0), .init_extra_i(8'd0), .func_acc_o(func_acc), .inflight_o(inflight),
    .func_acc_cnt_o(facc_cnt), .func_chk_cnt_o(fchk_cnt), .func_chk_err_o(fchk_err), .func_blocked_cnt_o(fblk),
    .func_acc_in_test_o(facc_in_test));

  sf_mbist_arbiter #(.OWN_TIMEOUT(1000), .IDLE_CONSEC(2), .INIT_TIMEOUT(ROWS + 100), .INIT_GRACE(16)) arb (
    .clk(clk), .rst_n(rst_n), .own_req_i(own_req), .permit_i(permit), .reinit_en_i(reinit_en), .dirty_i(dirty),
    .clr_fault_i(1'b0), .quiesce_o(quiesce), .quiesce_ack_i(q_ack), .idle_i(idle), .init_start_o(init_start),
    .init_busy_i(init_busy), .func_req_i(func_req), .tst_active_o(tst_active), .own_ok_o(own_ok), .own_idle_o(own_idle),
    .own_fault_o(own_fault), .clk_req_o(), .evt_own_timeout_o(e_own_to), .evt_reinit_timeout_o(e_re_to),
    .evt_perm_loss_o(e_perm), .evt_intrusion_o(e_intr), .evt_reinit_req_o(e_re_req), .intrusion_cnt_o(intr_cnt),
    .state_o(arb_state));

  sf_mbist_fsm #(.NBANK(1), .ROWS(ROWS), .W(W), .DATA_W(W), .LT(L)) fsm (
    .clk(clk), .rst_n(rst_n), .start_i(start), .start_clr_i(1'b0), .abort_i(abort), .clear_i(clear),
    .cfg_algo_i(cfg_algo), .cfg_pattern_i(cfg_pat), .cfg_stripe_k_i(cfg_k), .cfg_sweep_i(cfg_sweep),
    .cfg_colsel_i(cfg_col), .cfg_stop_i(cfg_stop), .cfg_reinit_i(cfg_reinit), .cfg_sel_i(`MB_SEL_BANK),
    .cfg_bank_i(8'd0), .cfg_bmask_i(1'b1), .cfg_row_lo_i(32'(lo)), .cfg_row_hi_i(32'(hi)), .cfg_wdog_i(cfg_wdog),
    .permit_i(permit), .protect_i(1'b0), .cpu_halted_i(1'b0), .results_pending_i(pending),
    .own_req_o(own_req), .own_ok_i(own_ok), .own_idle_i(own_idle), .own_fault_i(own_fault), .dirty_o(dirty),
    .reinit_en_o(reinit_en), .tst_sel_o(tst_sel), .tst_ce_o(tst_ce), .tst_we_o(tst_we), .tst_addr_o(tst_addr),
    .tst_wdata_o(tst_wdata), .tst_rdata_i(tst_rdata), .f_valid_o(f_valid), .f_bank_o(f_bank), .f_row_o(f_row),
    .f_elem_o(f_elem), .f_op_o(f_op), .f_pol_o(f_pol), .f_pass_o(f_pass), .f_pat_o(f_pat), .f_exp_o(f_exp),
    .f_obs_o(f_obs), .f_mask_o(f_mask), .clr_fail_o(clr_fail), .fail_any_i(fail_count != 0), .busy_o(busy),
    .done_o(done), .result_o(result), .state_o(fsm_state), .cur_bank_o(cur_bank), .cur_pass_o(cur_pass),
    .cur_elem_o(cur_elem), .cur_addr_o(cur_addr), .cycles_o(cycles), .tested_o(tested), .evt_o(evt));

  sf_mbist_failreg #(.NBANK(1), .AW(AW), .W(W), .DATA_W(W), .FIFO_DEPTH(4)) fr (
    .clk(clk), .rst_n(rst_n), .clr_i(clr_fail), .pop_i(1'b0), .f_valid_i(f_valid), .f_bank_i(f_bank),
    .f_row_i(f_row), .f_elem_i(f_elem), .f_op_i(f_op), .f_pol_i(f_pol), .f_pass_i(f_pass), .f_pat_i(f_pat),
    .f_exp_i(f_exp), .f_obs_i(f_obs), .f_mask_i(f_mask), .syn_o(syn), .first_valid_o(fv), .first_bank_o(fbank),
    .first_row_o(frow), .first_bit_o(fbit), .first_bit_v_o(fbitv), .first_in_check_o(finc), .first_elem_o(felem),
    .first_op_o(fop), .first_pol_o(fpol), .first_pass_o(fpass), .first_cls_o(fcls), .first_alias_o(falias),
    .first_exp_o(fexp), .first_obs_o(fobs), .head_valid_o(), .head_bank_o(), .head_row_o(), .head_bit_o(),
    .head_bit_v_o(), .head_in_check_o(), .head_elem_o(), .head_op_o(), .head_pol_o(), .head_pass_o(), .head_cls_o(),
    .head_alias_o(), .head_exp_o(), .head_obs_o(), .fail_count_o(fail_count), .fifo_count_o(), .fifo_lost_o(),
    .bank_cnt_o(), .bank_fail_mask_o(), .col_fail_mask_o(), .pending_o(pending), .evt_first_o(), .evt_fifo_lost_o());

  // ------------------------------------------------------------------ independent golden March C- generator
  localparam int MAXOPS = 12 * ROWS + 8;
  logic         g_we   [MAXOPS];
  logic [AW-1:0] g_addr [MAXOPS];
  logic [W-1:0] g_data [MAXOPS];
  integer       g_n;

  function automatic logic [W-1:0] bg(input int pat, input int k, input int row);
    logic [W-1:0] v;
    begin
      v = '0;
      for (int i = 0; i < W; i++) begin
        case (pat)
          0: v[i] = 1'b0;
          1: v[i] = 1'b1;
          2: v[i] = (i & 1);
          3: v[i] = (i & 1) ^ (row & 1);
          4: v[i] = ((row >> (i % AW)) & 1) ^ ((i / AW) & 1);
          default: v[i] = (i >> k) & 1;
        endcase
      end
      bg = v;
    end
  endfunction

  task automatic gpush(input logic we, input int a, input logic [W-1:0] d);
    begin g_we[g_n] = we; g_addr[g_n] = AW'(a); g_data[g_n] = d; g_n = g_n + 1; end
  endtask

  // March C-  {B(w0); U(r0,w1); U(r1,w0); D(r0,w1); D(r1,w0); B(r0)} over [l,h], background pat
  task automatic build_march_cm(input int pat, input int k, input int l, input int h);
    begin
      g_n = 0;
      for (int a = l; a <= h; a++) gpush(1, a, bg(pat, k, a));
      for (int a = l; a <= h; a++) begin gpush(0, a, bg(pat, k, a));  gpush(1, a, ~bg(pat, k, a)); end
      for (int a = l; a <= h; a++) begin gpush(0, a, ~bg(pat, k, a)); gpush(1, a, bg(pat, k, a));  end
      for (int a = h; a >= l; a--) begin gpush(0, a, bg(pat, k, a));  gpush(1, a, ~bg(pat, k, a)); end
      for (int a = h; a >= l; a--) begin gpush(0, a, ~bg(pat, k, a)); gpush(1, a, bg(pat, k, a));  end
      for (int a = l; a <= h; a++) gpush(0, a, bg(pat, k, a));
    end
  endtask

  task automatic build_mats_plus(input int pat, input int k, input int l, input int h);
    begin
      g_n = 0;
      for (int a = l; a <= h; a++) gpush(1, a, bg(pat, k, a));
      for (int a = l; a <= h; a++) begin gpush(0, a, bg(pat, k, a));  gpush(1, a, ~bg(pat, k, a)); end
      for (int a = h; a >= l; a--) begin gpush(0, a, ~bg(pat, k, a)); gpush(1, a, bg(pat, k, a));  end
    end
  endtask

  // ------------------------------------------------------------------ bus monitor (records every test op)
  integer m_n;
  logic         m_we   [MAXOPS];
  logic [AW-1:0] m_addr [MAXOPS];
  logic [W-1:0] m_data [MAXOPS];
  integer       viol_ce_unowned, viol_inflight, viol_quiesce;
  logic         mon_en;

  always @(posedge clk) begin
    if (mon_en && tst_ce) begin
      if (m_n < MAXOPS) begin m_we[m_n] = tst_we; m_addr[m_n] = tst_addr; m_data[m_n] = tst_wdata; end
      m_n = m_n + 1;
    end
    // safety invariants, checked on every cycle of the whole simulation
    if (tst_ce && !(tst_active && own_ok && permit)) viol_ce_unowned = viol_ce_unowned + 1;
    if (tst_active && (inflight != 0 || func_acc))   viol_inflight   = viol_inflight + 1;
    if (tst_active && !quiesce)                      viol_quiesce    = viol_quiesce + 1;
  end

  // ------------------------------------------------------------------ run helpers
  task automatic tick(input int n);
    begin repeat (n) @(posedge clk); end
  endtask

  task automatic pulse_clear;
    begin @(posedge clk); clear <= 1'b1; @(posedge clk); clear <= 1'b0; @(posedge clk); end
  endtask

  integer timeout_hit;
  task automatic run_test;               // start, wait for done (bounded)
    integer t;
    begin
      m_n = 0; timeout_hit = 0; t = 0;
      @(posedge clk); start <= 1'b1; @(posedge clk); start <= 1'b0;
      // wait for the run to be SEEN (busy rises) before waiting for completion: done still holds the previous
      // run's value in the cycle after the start pulse (race found by running the same TB under Icarus)
      while (!busy && t < 50) begin @(posedge clk); t = t + 1; end
      t = 0;
      while (!(done && !busy) && t < 200000) begin @(posedge clk); t = t + 1; end
      if (t >= 200000) begin timeout_hit = 1; `CHECK(0, "run did not complete (timeout)") end
      tick(3);
    end
  endtask

  task automatic default_cfg;
    begin
      cfg_algo = `MB_ALG_MARCH_CM; cfg_pat = `MB_PAT_ALL0; cfg_k = 0; cfg_sweep = 0; cfg_col = `MB_COL_ALL;
      cfg_stop = 0; cfg_reinit = 1; lo = '0; hi = AW'(ROWS - 1); cfg_wdog = 0;
    end
  endtask

  // expected first-failure signature (derived by hand, see docs/02_march_algorithm.md section 6)
  task automatic expect_fail(input string name, input int e_elem, input int e_row, input int e_bit, input int e_cls,
                             input int e_pol);
    begin
      `CHECK_EQ(result, `MB_RES_FAIL, {name, ": result FAIL"})
      `CHECK(fv, {name, ": first record valid"})
      `CHECK_EQ(felem, 3'(e_elem), {name, ": first-fail March element"})
      `CHECK_EQ(frow, AW'(e_row), {name, ": first-fail row"})
      if (e_bit >= 0) begin
        `CHECK(fbitv, {name, ": single-bit syndrome"})
        `CHECK_EQ(fbit, BITW'(e_bit), {name, ": failing bit"})
      end
      if (e_cls >= 0) `CHECK_EQ(fcls, 4'(e_cls), {name, ": symptom class"})
      if (e_cls == `MB_CLS_ALL_BITS) begin
        `CHECK(!fbitv, {name, ": multi-bit syndrome is not a single bit"})
        `CHECK_EQ(fbit, BITW'(0), {name, ": reported bit index is the LOWEST failing bit"})
      end
      `CHECK_EQ(fpol, e_pol[0], {name, ": expected read polarity"})
      `CHECK(fexp != fobs, {name, ": expected != observed"})
    end
  endtask

  // run one fault and check
  task automatic fault_case(input string name, input int t, input int row, input int bit_, input int row2, input int bit2,
                            input int v, input int v2, input int e_elem, input int e_row, input int e_bit,
                            input int e_cls, input int e_pol);
    begin
      sys.clear_faults();
      sys.set_fault(0, 0, t, row, bit_, row2, bit2, v, v2);
      pulse_clear();
      run_test();
      expect_fail(name, e_elem, e_row, e_bit, e_cls, e_pol);
      sys.clear_faults();
      pulse_clear();
    end
  endtask

  // ------------------------------------------------------------------ test sequence
  integer ncmp;
  initial begin
    start = 0; abort = 0; clear = 0; permit = 1; traffic = 0; rogue = 0;
    viol_ce_unowned = 0; viol_inflight = 0; viol_quiesce = 0; mon_en = 0; m_n = 0;
    default_cfg();
    repeat (4) @(posedge clk);
    rst_n = 1;
    repeat (3) @(posedge clk);

    // ---------------------------------------------------------------- P1.1 fault-free
    `SECTION("P1.1 fault-free March C- on one bank");
    default_cfg();
    build_march_cm(`MB_PAT_ALL0, 0, 0, ROWS - 1);
    mon_en = 1;
    run_test();
    mon_en = 0;
    `CHECK_EQ(result, `MB_RES_PASS, "fault-free result PASS")
    `CHECK(done && !busy, "done, not busy")
    `CHECK_EQ(fail_count, 32'd0, "fail count 0")
    `CHECK_EQ(m_n, g_n, "operation count == 10N")
    `CHECK_EQ(m_n, 10 * ROWS, "10N literally")
    ncmp = 0;
    for (int i = 0; i < g_n && i < MAXOPS; i++) begin
      if (m_we[i] !== g_we[i] || m_addr[i] !== g_addr[i]) ncmp = ncmp + 1;
      else if (g_we[i] && m_data[i] !== g_data[i]) ncmp = ncmp + 1;
    end
    `CHECK_EQ(ncmp, 0, "bus trace equals the independent golden March C- (op order, addresses, write data)")
    `CHECK_EQ(tested, 1'b1, "bank marked tested")
    `CHECK_EQ(arb_state, 4'd0, "arbiter back in IDLE")
    `CHECK(!quiesce && !tst_active, "quiesce / tst_active released")
    $display("  cycles for one March C- over %0d rows, L=%0d: %0d", ROWS, L, cycles);

    // ---------------------------------------------------------------- P1.2 ownership order on the wires
    `SECTION("P1.2 ownership sequence");
    // measured above by the always-block monitors: no test op without ownership/permit, never with an in-flight
    // functional transaction, never without quiesce
    `CHECK_EQ(viol_ce_unowned, 0, "no tst_ce outside (tst_active & own_ok & permit)")
    `CHECK_EQ(viol_inflight, 0, "tst_active never overlaps an in-flight functional transaction")
    `CHECK_EQ(viol_quiesce, 0, "tst_active never without quiesce")

    // ---------------------------------------------------------------- P1.3 fault signatures (hand derived)
    `SECTION("P1.3 single fault signatures (SAF/TF/AF/CF)");
    // type: 1 SAF 2 TF 3 AF_NA 4 AF_ALI 5 AF_MUL 6 CFIN 7 CFID 8 CFST ;  args: row bit row2 bit2 val val2
    //                       name       t  row bit row2 bit2 v v2   elem row  bit   cls                  pol
    fault_case("SA0 (5,3)",       1,  5, 3, 0, 0, 0, 0,   2,  5,  3, `MB_CLS_1TO0_BIT, 1);   // read 1 returns 0 first in U(r1,w0)
    fault_case("SA1 (5,3)",       1,  5, 3, 0, 0, 1, 0,   1,  5,  3, `MB_CLS_0TO1_BIT, 0);   // read 0 returns 1 first in U(r0,w1)
    fault_case("TF up (5,3)",     2,  5, 3, 0, 0, 1, 0,   2,  5,  3, `MB_CLS_1TO0_BIT, 1);   // 0->1 never happens: U(r1,w0) reads 0
    fault_case("TF down (5,3)",   2,  5, 3, 0, 0, 0, 0,   3,  5,  3, `MB_CLS_0TO1_BIT, 0);   // 1->0 fails in U(r1,w0); D(r0,w1) reads 1
    fault_case("AF none (5)",     3,  5, 0, 0, 0, 0, 0,   2,  5, -1, `MB_CLS_ALL_BITS, 1);   // reads 0 always; first wrong read is r1
    fault_case("AF alias 5->9",   4,  5, 0, 9, 0, 0, 0,   1,  9, -1, -1,               0);   // row 9 polluted by row 5's w1
    fault_case("AF multi 5+9 OR", 5,  5, 0, 9, 0, 0, 0,   1,  9, -1, -1,               0);   // writes of row 5 also hit row 9
    fault_case("CFin up (2,0)->(7,0)", 6, 2, 0, 7, 0, 1, 0, 1, 7,  0, `MB_CLS_0TO1_BIT, 0);   // victim flipped to 1 by aggressor rise
    fault_case("CFid up (2,0)->(7,0)=1", 7, 2, 0, 7, 0, 1, 1, 1, 7, 0, `MB_CLS_0TO1_BIT, 0);
    fault_case("CFst agg=1 -> victim reads 1", 8, 2, 0, 7, 0, 1, 1, 1, 7, 0, `MB_CLS_0TO1_BIT, 0);

    // ---------------------------------------------------------------- P1.4 variants
    `SECTION("P1.4 variants: window, MATS+, patterns");
    default_cfg(); lo = AW'(3); hi = AW'(9);
    build_march_cm(`MB_PAT_ALL0, 0, 3, 9);
    sys.clear_faults(); pulse_clear(); mon_en = 1; run_test(); mon_en = 0;
    `CHECK_EQ(result, `MB_RES_PASS, "window [3,9] PASS")
    `CHECK_EQ(m_n, 10 * 7, "window op count 10 x 7")
    ncmp = 0;
    for (int i = 0; i < g_n && i < MAXOPS; i++)
      if (m_we[i] !== g_we[i] || m_addr[i] !== g_addr[i] || (g_we[i] && m_data[i] !== g_data[i])) ncmp = ncmp + 1;
    `CHECK_EQ(ncmp, 0, "window bus trace equals golden")

    default_cfg(); lo = AW'(4); hi = AW'(4);
    build_march_cm(`MB_PAT_ALL0, 0, 4, 4);
    mon_en = 1; run_test(); mon_en = 0;
    `CHECK_EQ(result, `MB_RES_PASS, "single-row window PASS")
    `CHECK_EQ(m_n, 10, "single-row window: 10 operations")

    default_cfg(); cfg_algo = `MB_ALG_MATS_P;
    build_mats_plus(`MB_PAT_ALL0, 0, 0, ROWS - 1);
    mon_en = 1; run_test(); mon_en = 0;
    `CHECK_EQ(result, `MB_RES_PASS, "MATS+ fault-free PASS")
    `CHECK_EQ(m_n, 5 * ROWS, "MATS+ is 5N")
    ncmp = 0;
    for (int i = 0; i < g_n && i < MAXOPS; i++)
      if (m_we[i] !== g_we[i] || m_addr[i] !== g_addr[i] || (g_we[i] && m_data[i] !== g_data[i])) ncmp = ncmp + 1;
    `CHECK_EQ(ncmp, 0, "MATS+ bus trace equals golden")

    for (int p = 0; p <= 5; p++) begin
      default_cfg(); cfg_pat = 3'(p); cfg_k = 4'd1;
      build_march_cm(p, 1, 0, ROWS - 1);
      mon_en = 1; run_test(); mon_en = 0;
      `CHECK_EQ(result, `MB_RES_PASS, "pattern fault-free PASS")
      ncmp = 0;
      for (int i = 0; i < g_n && i < MAXOPS; i++)
        if (m_we[i] !== g_we[i] || m_addr[i] !== g_addr[i] || (g_we[i] && m_data[i] !== g_data[i])) ncmp = ncmp + 1;
      `CHECK_EQ(ncmp, 0, "pattern bus trace equals golden (pattern generator cross-check)")
    end

    // ---------------------------------------------------------------- final safety counters
    `SECTION("global safety invariants over the whole run");
    `CHECK_EQ(viol_ce_unowned, 0, "no tst_ce outside ownership (final)")
    `CHECK_EQ(viol_inflight, 0, "no overlap with functional traffic (final)")
    `CHECK_EQ(viol_quiesce, 0, "no ownership without quiesce (final)")
    `CHECK_EQ(facc_in_test, 32'd0, "no functional access accepted while tst_active")

    $display("RESULT tb_p1_march_one_bank ROWS=%0d W=%0d L=%0d checks=%0d errors=%0d %s", ROWS, W, L, checks, errors,
             (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #200000000;
    $display("RESULT tb_p1_march_one_bank global timeout FAIL");
    $finish;
  end
endmodule
