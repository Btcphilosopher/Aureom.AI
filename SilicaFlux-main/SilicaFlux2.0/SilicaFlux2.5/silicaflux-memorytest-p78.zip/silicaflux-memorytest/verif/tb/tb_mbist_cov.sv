// =============================================================================
// MBIST fault-coverage campaign (measurement, not a claim).
// One bank of COV_ROWS x COV_W cells behind sf_sram_mbist (direct pin interface).  For EVERY fault of an
// explicitly enumerated population the testbench injects the single fault (sf_mbist_fault_mem semantics,
// docs/04_fault_models.md), runs the configured test and records whether the controller reported a failure.
//
//   population (exhaustive; n = COV_ROWS x COV_W cells)
//     cell faults       SAF0, SAF1, TF-up, TF-down                          each cell
//     address faults    AF-none (each row), AF-alias (ordered row pair), AF-multi-OR / AND (ordered row pair)
//     coupling faults   every ORDERED pair of distinct cells (aggressor != victim), split by scope:
//                         inter-word (different rows)  /  intra-word (same row)
//                       CFin x {up, down} ; CFid x {up,down} x {force 0, force 1} ; CFst x {aggr 0/1} x {victim 0/1}
//   configurations    C0 March C- solid | C1 March C- checkerboard | C2 March C- solid UNION checkerboard (two runs;
//                     the two backgrounds of MemoryCore's engine) | C3 March C- background sweep (solid + stripes)
//                     | C4 MATS+ solid (weaker reference)
//   checks            a fault-free run must PASS (false alarms = 0); every run must end PASS or FAIL (anomalies = 0);
//                     for single-cell faults the first failure must be located at the faulty cell;
//                     a sample of faults is re-run and the full first-failure record compared (reproducibility).
// Output: one `COVER` line per (configuration, class); tools: sim/run_coverage.py -> reports/coverage.{json,md}.
// "Detected" = the controller raised FAIL for that injected fault.  Coverage of this model population is NOT
// silicon defect coverage (docs/04 section 6).
// =============================================================================
`timescale 1ns/1ps
`include "sf_mbist_defs.svh"
`include "tb_common.svh"

module tb_mbist_cov;
  parameter int COV_ROWS   = 4;
  parameter int COV_W      = 8;
  parameter int COV_STRIDE = 1;          // evaluate every COV_STRIDE-th coupling pair (1 = exhaustive)
  parameter int COV_CFG    = -1;         // -1: all configurations, else only that one
  localparam int AW = (COV_ROWS > 1) ? $clog2(COV_ROWS) : 1;
  localparam int KMAX = (COV_W > 1) ? $clog2(COV_W) : 1;

  integer errors = 0, checks = 0;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic start, clr; logic [3:0] p_algo; logic [2:0] p_pat; logic p_sweep;
  wire busy, done, pass_o, fail_o, error_o; wire [2:0] result; wire [31:0] fail_count;
  wire fail_valid; wire [0:0] fail_bank; wire [AW-1:0] fail_row; wire [$clog2(COV_W)-1:0] fail_bit; wire fail_bit_v; wire [2:0] fail_elem;
  wire [3:0] fail_cls; wire [COV_W-1:0] fexp, fobs;
  wire quiesce, q_ack, idle, init_start, init_busy, func_req, tst_active; wire [0:0] tst_sel; wire tst_ce, tst_we;
  wire [AW-1:0] tst_addr; wire [COV_W-1:0] tst_wdata, tst_rdata; wire [7:0] inflight; wire func_acc;
  wire [31:0] f1, f2, f3, f4, f5;

  sf_mbist_sram_sys #(.NBANK(1), .ROWS(COV_ROWS), .W(COV_W), .READ_LATENCY(1), .NF(1)) sys (
    .clk(clk), .rst_n(rst_n), .quiesce_i(quiesce), .quiesce_ack_o(q_ack), .idle_o(idle), .init_start_i(init_start),
    .init_busy_o(init_busy), .func_req_o(func_req), .tst_active_i(tst_active), .tst_sel_i(tst_sel), .tst_ce_i(tst_ce),
    .tst_we_i(tst_we), .tst_addr_i(tst_addr), .tst_wdata_i(tst_wdata), .tst_rdata_o(tst_rdata), .traffic_en_i(1'b0),
    .rogue_i(1'b0), .ctl_no_ack_i(1'b0), .ctl_no_idle_i(1'b0), .ctl_no_init_i(1'b0), .init_on_reset_i(1'b0),
    .ack_delay_i(8'd0), .drain_extra_i(8'd0), .init_extra_i(8'd0), .func_acc_o(func_acc), .inflight_o(inflight),
    .func_acc_cnt_o(f1), .func_chk_cnt_o(f2), .func_chk_err_o(f3), .func_blocked_cnt_o(f4), .func_acc_in_test_o(f5));

  sf_sram_mbist #(.NBANK(1), .ROWS(COV_ROWS), .DATA_W(COV_W), .STORE_W(COV_W), .READ_LATENCY(1), .FIFO_DEPTH(2),
                  .OWN_TIMEOUT(1000), .INIT_TIMEOUT(COV_ROWS + 100)) dut (
    .clk(clk), .rst_n(rst_n), .start_i(start), .start_clr_i(1'b0), .abort_i(1'b0), .clear_i(clr), .fail_pop_i(1'b0),
    .clr_fault_i(1'b0), .cfg_from_pins_i(1'b1), .cfg_algo_i(p_algo), .cfg_pattern_i(p_pat), .cfg_stripe_k_i(4'd0),
    .cfg_sweep_i(p_sweep), .cfg_colsel_i(2'd0), .cfg_stop_i(1'b0), .cfg_reinit_i(1'b1), .cfg_sel_i(`MB_SEL_ALL),
    .cfg_bank_i(8'd0), .cfg_bmask_i(1'b1), .cfg_row_lo_i('0), .cfg_row_hi_i(AW'(COV_ROWS - 1)), .cfg_wdog_i(32'd0),
    .test_mode_i(1'b1), .test_permit_i(1'b1), .mem_inhibit_i(1'b0), .cpu_halted_i(1'b0), .protect_i(1'b0),
    .busy_o(busy), .done_o(done), .pass_o(pass_o), .fail_o(fail_o), .error_o(error_o), .result_o(result),
    .bank_tested_o(), .bank_fail_mask_o(), .err_flags_o(), .state_o(), .fail_valid_o(fail_valid), .fail_bank_o(fail_bank),
    .fail_row_o(fail_row), .fail_bit_o(fail_bit), .fail_bit_v_o(fail_bit_v), .fail_in_check_o(), .fail_elem_o(fail_elem),
    .fail_op_o(), .fail_pol_o(), .fail_pass_o(), .fail_cls_o(fail_cls), .fail_alias_o(), .fail_exp_o(fexp), .fail_obs_o(fobs),
    .fail_count_o(fail_count), .quiesce_o(quiesce), .quiesce_ack_i(q_ack), .idle_i(idle), .init_start_o(init_start),
    .init_busy_i(init_busy), .func_req_i(func_req), .clk_req_o(), .tst_active_o(tst_active), .tst_sel_o(tst_sel),
    .tst_ce_o(tst_ce), .tst_we_o(tst_we), .tst_addr_o(tst_addr), .tst_wdata_o(tst_wdata), .tst_rdata_i(tst_rdata),
    .rb_req(1'b0), .rb_we(1'b0), .rb_addr(12'd0), .rb_wdata(32'd0), .rb_gnt(), .rb_rdata(), .rb_err(),
    .ras_valid_o(), .ras_type_o(), .ras_addr_o(), .ras_addr_v_o(), .ras_info_o(), .ras_corr_o(), .rep_row_v_o(),
    .rep_row_o(), .rep_col_v_o(), .rep_col_o(), .rep_ok_o(), .rep_unrep_o(), .rep_phys_o());

  // ------------------------------------------------------------------ run one configured test, return detection
  integer anomalies = 0, false_alarms = 0, runs_total = 0;
  logic det; logic [AW-1:0] r_row; logic [31:0] r_bit; logic r_bitv; logic [2:0] r_elem; logic [31:0] r_cnt;

  task automatic run_cfg(input int algo, input int pat, input int sweep);
    integer t;
    begin
      @(posedge clk); p_algo <= 4'(algo); p_pat <= 3'(pat); p_sweep <= sweep[0]; clr <= 1'b1;
      @(posedge clk); clr <= 1'b0;
      @(posedge clk); start <= 1'b1;
      @(posedge clk); start <= 1'b0;
      t = 0; while (!busy && t < 40) begin @(posedge clk); t = t + 1; end
      t = 0; while (busy && t < 100000) begin @(posedge clk); t = t + 1; end
      @(posedge clk);
      runs_total = runs_total + 1;
      if (result != `MB_RES_PASS && result != `MB_RES_FAIL) anomalies = anomalies + 1;
      det = (result == `MB_RES_FAIL) && (fail_count != 0);
      r_row = fail_row; r_bit = 32'(fail_bit); r_bitv = fail_bit_v; r_elem = fail_elem; r_cnt = fail_count;
    end
  endtask

  // a configuration = up to two runs; a fault is detected if ANY run detects it
  integer cfg_nruns [5]; integer cfg_algo [5][2]; integer cfg_pat [5][2]; integer cfg_swp [5][2];
  string  cfg_name [5];
  logic   det_any; integer cur_cfg;
  logic [AW-1:0] a_row; logic [31:0] a_bit; logic a_bitv;

  task automatic run_fault_config(input int c);
    begin
      det_any = 1'b0;
      for (int k = 0; k < cfg_nruns[c]; k++) begin
        run_cfg(cfg_algo[c][k], cfg_pat[c][k], cfg_swp[c][k]);
        if (det && !det_any) begin det_any = 1'b1; a_row = r_row; a_bit = r_bit; a_bitv = r_bitv; end
      end
    end
  endtask

  // ------------------------------------------------------------------ class table
  localparam int NCLS = 8;
  string cls_name [NCLS]; string cls_scope [NCLS];
  integer cls_tot [NCLS]; integer cls_det [NCLS]; integer cls_loc [NCLS];
  initial begin
    cls_name[0]  = "SAF0";        cls_scope[0]  = "cell";
    cls_name[1]  = "SAF1";        cls_scope[1]  = "cell";
    cls_name[2]  = "TF_up";       cls_scope[2]  = "cell";
    cls_name[3]  = "TF_down";     cls_scope[3]  = "cell";
    cls_name[4]  = "AF_none";     cls_scope[4]  = "row";
    cls_name[5]  = "AF_alias";    cls_scope[5]  = "row pair";
    cls_name[6]  = "AF_multi_OR"; cls_scope[6]  = "row pair";
    cls_name[7]  = "AF_multi_AND";cls_scope[7]  = "row pair";
  end

  // ---- the coupling sub-variant table (10 variants): type, trigger/aggr value, forced value
  localparam int NV = 10;
  integer v_type [NV]; integer v_a [NV]; integer v_f [NV]; string v_name [NV];
  initial begin
    v_type[0] = 6; v_a[0] = 1; v_f[0] = 0; v_name[0] = "CFin_up";
    v_type[1] = 6; v_a[1] = 0; v_f[1] = 0; v_name[1] = "CFin_down";
    v_type[2] = 7; v_a[2] = 1; v_f[2] = 0; v_name[2] = "CFid_up_f0";
    v_type[3] = 7; v_a[3] = 1; v_f[3] = 1; v_name[3] = "CFid_up_f1";
    v_type[4] = 7; v_a[4] = 0; v_f[4] = 0; v_name[4] = "CFid_down_f0";
    v_type[5] = 7; v_a[5] = 0; v_f[5] = 1; v_name[5] = "CFid_down_f1";
    v_type[6] = 8; v_a[6] = 0; v_f[6] = 0; v_name[6] = "CFst_a0_v0";
    v_type[7] = 8; v_a[7] = 0; v_f[7] = 1; v_name[7] = "CFst_a0_v1";
    v_type[8] = 8; v_a[8] = 1; v_f[8] = 0; v_name[8] = "CFst_a1_v0";
    v_type[9] = 8; v_a[9] = 1; v_f[9] = 1; v_name[9] = "CFst_a1_v1";
  end
  integer cv_tot [2][NV]; integer cv_det [2][NV];       // [scope 0 inter / 1 intra][variant]

  // ------------------------------------------------------------------ campaign
  integer c, r, b, r2, b2, v, scope, pairn, repro_bad, repro_n;
  logic [AW-1:0] r1_row; logic [2:0] r1_elem; logic [31:0] r1_cnt, r1_bit; logic [COV_W-1:0] r1_exp, r1_obs;

  task automatic print_cover(input int cfg, input string cname, input string cl, input string sc, input int tot, input int dt, input int lc);
    begin
      $display("COVER cfg=%0d name=\"%s\" class=%s scope=\"%s\" total=%0d detected=%0d located=%0d pct=%0d.%02d", cfg, cname, cl, sc, tot, dt, lc,
               (tot == 0) ? 0 : (dt * 100) / tot, (tot == 0) ? 0 : (((dt * 10000) / tot) % 100));
    end
  endtask

  initial begin
    start = 0; clr = 0; p_algo = 0; p_pat = 0; p_sweep = 0;
    cfg_name[0] = "March C-, solid";            cfg_nruns[0] = 1; cfg_algo[0][0] = 0; cfg_pat[0][0] = `MB_PAT_ALL0;    cfg_swp[0][0] = 0;
    cfg_name[1] = "March C-, checkerboard";     cfg_nruns[1] = 1; cfg_algo[1][0] = 0; cfg_pat[1][0] = `MB_PAT_CHECKER; cfg_swp[1][0] = 0;
    cfg_name[2] = "March C-, solid U checkerboard (2 runs)"; cfg_nruns[2] = 2; cfg_algo[2][0] = 0; cfg_pat[2][0] = `MB_PAT_ALL0; cfg_swp[2][0] = 0;
                                                                               cfg_algo[2][1] = 0; cfg_pat[2][1] = `MB_PAT_CHECKER; cfg_swp[2][1] = 0;
    cfg_name[3] = "March C-, background sweep (solid + stripes)"; cfg_nruns[3] = 1; cfg_algo[3][0] = 0; cfg_pat[3][0] = `MB_PAT_ALL0; cfg_swp[3][0] = 1;
    cfg_name[4] = "MATS+, solid";               cfg_nruns[4] = 1; cfg_algo[4][0] = 1; cfg_pat[4][0] = `MB_PAT_ALL0;    cfg_swp[4][0] = 0;
    repeat (4) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);

    $display("CAMPAIGN rows=%0d width=%0d cells=%0d stride=%0d", COV_ROWS, COV_W, COV_ROWS * COV_W, COV_STRIDE);
    for (c = 0; c < 5; c++) if (COV_CFG < 0 || COV_CFG == c) begin
      for (int k = 0; k < NCLS; k++) begin cls_tot[k] = 0; cls_det[k] = 0; cls_loc[k] = 0; end
      for (int s = 0; s < 2; s++) for (int k = 0; k < NV; k++) begin cv_tot[s][k] = 0; cv_det[s][k] = 0; end
      cur_cfg = c;

      // ---- fault-free: no false alarm
      sys.clear_faults();
      for (int k = 0; k < cfg_nruns[c]; k++) begin
        run_cfg(cfg_algo[c][k], cfg_pat[c][k], cfg_swp[c][k]);
        if (result != `MB_RES_PASS) begin false_alarms = false_alarms + 1; $display("  FALSE ALARM cfg %0d run %0d result %0d", c, k, result); end
      end

      // ---- cell faults
      for (r = 0; r < COV_ROWS; r++) for (b = 0; b < COV_W; b++) begin
        for (int k = 0; k < 4; k++) begin
          sys.clear_faults();
          case (k)
            0: sys.set_fault(0, 0, 1, r, b, 0, 0, 0, 0);
            1: sys.set_fault(0, 0, 1, r, b, 0, 0, 1, 0);
            2: sys.set_fault(0, 0, 2, r, b, 0, 0, 1, 0);
            3: sys.set_fault(0, 0, 2, r, b, 0, 0, 0, 0);
          endcase
          run_fault_config(c);
          cls_tot[k] = cls_tot[k] + 1;
          if (det_any) begin
            cls_det[k] = cls_det[k] + 1;
            if (a_row == AW'(r) && a_bit == 32'(b) && a_bitv) cls_loc[k] = cls_loc[k] + 1;
          end
        end
      end

      // ---- address-decoder faults
      for (r = 0; r < COV_ROWS; r++) begin
        sys.clear_faults(); sys.set_fault(0, 0, 3, r, 0, 0, 0, 0, 0); run_fault_config(c);
        cls_tot[4] = cls_tot[4] + 1; if (det_any) cls_det[4] = cls_det[4] + 1;
        for (r2 = 0; r2 < COV_ROWS; r2++) if (r2 != r) begin
          sys.clear_faults(); sys.set_fault(0, 0, 4, r, 0, r2, 0, 0, 0); run_fault_config(c);
          cls_tot[5] = cls_tot[5] + 1; if (det_any) cls_det[5] = cls_det[5] + 1;
          sys.clear_faults(); sys.set_fault(0, 0, 5, r, 0, r2, 0, 0, 0); run_fault_config(c);
          cls_tot[6] = cls_tot[6] + 1; if (det_any) cls_det[6] = cls_det[6] + 1;
          sys.clear_faults(); sys.set_fault(0, 0, 5, r, 0, r2, 0, 1, 0); run_fault_config(c);
          cls_tot[7] = cls_tot[7] + 1; if (det_any) cls_det[7] = cls_det[7] + 1;
        end
      end

      // ---- coupling faults: every ordered pair of distinct cells
      pairn = 0;
      for (r = 0; r < COV_ROWS; r++) for (b = 0; b < COV_W; b++)
        for (r2 = 0; r2 < COV_ROWS; r2++) for (b2 = 0; b2 < COV_W; b2++) if (!(r == r2 && b == b2)) begin
          pairn = pairn + 1;
          if ((pairn % COV_STRIDE) == 0) begin
            scope = (r == r2) ? 1 : 0;
            for (v = 0; v < NV; v++) begin
              sys.clear_faults(); sys.set_fault(0, 0, v_type[v], r, b, r2, b2, v_a[v], v_f[v]);
              run_fault_config(c);
              cv_tot[scope][v] = cv_tot[scope][v] + 1; if (det_any) cv_det[scope][v] = cv_det[scope][v] + 1;
            end
          end
        end

      // ---- reproducibility: re-run a sample of faults, the first-failure record and count must be identical
      sys.clear_faults(); repro_bad = 0; repro_n = 0;
      for (r = 0; r < COV_ROWS; r++) for (b = 0; b < COV_W; b += 3) begin
        sys.clear_faults(); sys.set_fault(0, 0, 1, r, b, 0, 0, b % 2, 0);
        run_cfg(cfg_algo[c][0], cfg_pat[c][0], cfg_swp[c][0]);
        r1_row = r_row; r1_elem = r_elem; r1_cnt = r_cnt; r1_bit = r_bit; r1_exp = fexp; r1_obs = fobs;
        run_cfg(cfg_algo[c][0], cfg_pat[c][0], cfg_swp[c][0]);
        repro_n = repro_n + 1;
        if (r1_row !== r_row || r1_elem !== r_elem || r1_cnt !== r_cnt || r1_bit !== r_bit || r1_exp !== fexp || r1_obs !== fobs) repro_bad = repro_bad + 1;
      end
      sys.clear_faults();

      // ---- report
      for (int k = 0; k < 8; k++) print_cover(c, cfg_name[c], cls_name[k], cls_scope[k], cls_tot[k], cls_det[k], (k < 4) ? cls_loc[k] : 0);
      for (int s = 0; s < 2; s++) for (v = 0; v < NV; v++)
        print_cover(c, cfg_name[c], v_name[v], (s == 0) ? "inter-word pair" : "intra-word pair", cv_tot[s][v], cv_det[s][v], 0);
      $display("REPRO cfg=%0d samples=%0d mismatches=%0d", c, repro_n, repro_bad);
      `CHECK_EQ(repro_bad, 0, "first-failure records reproduce exactly on a re-run")
    end

    $display("SUMMARY runs=%0d false_alarms=%0d anomalies=%0d", runs_total, false_alarms, anomalies);
    `CHECK_EQ(false_alarms, 0, "no false alarm on a fault-free memory")
    `CHECK_EQ(anomalies, 0, "every run ended PASS or FAIL")
    $display("RESULT tb_mbist_cov rows=%0d width=%0d stride=%0d runs=%0d checks=%0d errors=%0d %s", COV_ROWS, COV_W, COV_STRIDE, runs_total, checks, errors,
             (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end
  initial begin #2000000000; $display("RESULT tb_mbist_cov global timeout FAIL"); $finish; end
endmodule
