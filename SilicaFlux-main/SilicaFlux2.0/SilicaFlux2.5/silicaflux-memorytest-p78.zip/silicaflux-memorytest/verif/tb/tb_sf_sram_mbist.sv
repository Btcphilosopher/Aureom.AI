// =============================================================================
// System testbench of sf_sram_mbist (top) on a multi-bank memory group (sf_mbist_sram_sys: fault-model banks +
// functional master with scoreboard).  Drives the DUT through its REGISTER page unless a test says "pins".
//
//   S01 identity / capability registers          S10 completion signalling (done / pass / fail / error pins)
//   S02 start refusals (nothing touched)         S11 ownership safety with live traffic, slow ack / drain, rogue master
//   S03 memory selection + accessibility         S12 timeouts: no ack, no idle, no init, slow init -> FAULT paths
//   S04 per-bank fault signatures, multi-bank    S13 interruption: abort, permission loss, inhibit, stop-on-fail, watchdog
//   S05 every supported fault type detected      S14 reset in the middle of a test
//   S06 diagnostics: first / FIFO / counters     S15 RAS events
//   S07 column selection (data vs check)         S16 redundancy analysis
//   S08 patterns and background sweep            S17 direct pin interface
//   S09 row windows / configuration errors       S18 register access errors
// Safety monitors run every cycle of the whole simulation (counted, asserted at the end):
//   tst_ce without (tst_active & permit) | tst_active with functional traffic in flight | tst_active without
//   quiesce | tst_active before the quiesce acknowledge | functional access accepted while quiesced.
// =============================================================================
`timescale 1ns/1ps
`include "sf_mbist_defs.svh"
`include "tb_common.svh"

module tb_sf_sram_mbist;
  parameter int NBANK  = 4;
  parameter int ROWS   = 16;
  parameter int DATA_W = 8;
  parameter int STORE_W = 12;
  parameter int L      = 1;
  parameter int TP     = 0;
  parameter logic [3:0] ACCESS = 4'b0111;      // bank 3 has no raw test port
  parameter logic [3:0] SHARED = 4'b0011;
  parameter logic [3:0] TENSOR = 4'b0100;
  parameter logic [3:0] VECTOR = 4'b1000;      // refers to the inaccessible bank in the default configuration
  localparam int AW   = (ROWS > 1) ? $clog2(ROWS) : 1;
  localparam int BW   = (NBANK > 1) ? $clog2(NBANK) : 1;
  localparam int BITW = (STORE_W > 1) ? $clog2(STORE_W) : 1;
  localparam int NF   = 8;
  localparam int KMAX = (STORE_W > 1) ? $clog2(STORE_W) : 1;
  localparam bit HAS_CHECK = (STORE_W > DATA_W);                       // ECC-style check columns exist
  localparam int CB1 = HAS_CHECK ? DATA_W + 1 : DATA_W - 1;            // a "check" column (a high data column if none exist)
  localparam int CB2 = HAS_CHECK ? DATA_W + 2 : DATA_W - 2;

  integer errors = 0, checks = 0;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------------------------------------------------------- DUT pins
  logic start_i, start_clr_i, abort_i, clear_i, fail_pop_i, clr_fault_i, cfg_from_pins_i;
  logic [3:0] cfg_algo_i; logic [2:0] cfg_pattern_i; logic [3:0] cfg_stripe_k_i; logic cfg_sweep_i; logic [1:0] cfg_colsel_i;
  logic cfg_stop_i, cfg_reinit_i; logic [2:0] cfg_sel_i; logic [7:0] cfg_bank_i; logic [NBANK-1:0] cfg_bmask_i;
  logic [AW-1:0] cfg_row_lo_i, cfg_row_hi_i; logic [31:0] cfg_wdog_i;
  logic test_mode_i, test_permit_i, mem_inhibit_i, cpu_halted_i; logic [NBANK-1:0] protect_i;
  wire busy_o, done_o, pass_o, fail_o, error_o; wire [2:0] result_o; wire [NBANK-1:0] bank_tested_o, bank_fail_mask_o;
  wire [`MB_NERR-1:0] err_flags_o; wire [7:0] state_o;
  wire fail_valid_o; wire [BW-1:0] fail_bank_o; wire [AW-1:0] fail_row_o; wire [BITW-1:0] fail_bit_o; wire fail_bit_v_o, fail_in_check_o;
  wire [2:0] fail_elem_o; wire fail_op_o, fail_pol_o; wire [3:0] fail_pass_o, fail_cls_o; wire [AW-1:0] fail_alias_o;
  wire [STORE_W-1:0] fail_exp_o, fail_obs_o; wire [31:0] fail_count_o;
  wire quiesce_o, init_start_o, clk_req_o, tst_active_o, tst_ce_o, tst_we_o; wire [NBANK-1:0] tst_sel_o;
  wire [AW-1:0] tst_addr_o; wire [STORE_W-1:0] tst_wdata_o; wire [NBANK*STORE_W-1:0] tst_rdata_i;
  logic rb_req, rb_we; logic [11:0] rb_addr; logic [31:0] rb_wdata; wire rb_gnt, rb_err; wire [31:0] rb_rdata;
  wire ras_valid_o, ras_addr_v_o, ras_corr_o; wire [3:0] ras_type_o; wire [31:0] ras_addr_o, ras_info_o;
  localparam int SR = 2, SC = 2;
  wire [NBANK*SR-1:0] rep_row_v_o; wire [NBANK*SR*AW-1:0] rep_row_o; wire [NBANK*SC-1:0] rep_col_v_o;
  wire [NBANK*SC*BITW-1:0] rep_col_o; wire [NBANK-1:0] rep_ok_o, rep_unrep_o; wire rep_phys_o;

  // ---------------------------------------------------------------- memory group model
  wire q_ack, idle, init_busy, func_req, func_acc; wire [7:0] inflight;
  wire [31:0] facc_cnt, fchk_cnt, fchk_err, fblk, facc_in_test;
  logic traffic, rogue, no_ack, no_idle, no_init, init_on_reset; logic [7:0] ack_delay, drain_extra, init_extra;

  sf_mbist_sram_sys #(.NBANK(NBANK), .ROWS(ROWS), .W(STORE_W), .READ_LATENCY(L + TP), .NF(NF)) sys (
    .clk(clk), .rst_n(rst_n), .quiesce_i(quiesce_o), .quiesce_ack_o(q_ack), .idle_o(idle), .init_start_i(init_start_o),
    .init_busy_o(init_busy), .func_req_o(func_req), .tst_active_i(tst_active_o), .tst_sel_i(tst_sel_o), .tst_ce_i(tst_ce_o),
    .tst_we_i(tst_we_o), .tst_addr_i(tst_addr_o), .tst_wdata_i(tst_wdata_o), .tst_rdata_o(tst_rdata_i),
    .traffic_en_i(traffic), .rogue_i(rogue), .ctl_no_ack_i(no_ack), .ctl_no_idle_i(no_idle), .ctl_no_init_i(no_init),
    .init_on_reset_i(init_on_reset), .ack_delay_i(ack_delay), .drain_extra_i(drain_extra), .init_extra_i(init_extra),
    .func_acc_o(func_acc), .inflight_o(inflight), .func_acc_cnt_o(facc_cnt), .func_chk_cnt_o(fchk_cnt),
    .func_chk_err_o(fchk_err), .func_blocked_cnt_o(fblk), .func_acc_in_test_o(facc_in_test));

  sf_sram_mbist #(
    .NBANK(NBANK), .ROWS(ROWS), .DATA_W(DATA_W), .STORE_W(STORE_W), .READ_LATENCY(L), .TEST_PIPE(TP),
    .ACCESS_MASK(ACCESS), .SHARED_MASK(SHARED), .TENSOR_MASK(TENSOR), .VECTOR_MASK(VECTOR), .FIFO_DEPTH(4),
    .OWN_TIMEOUT(300), .IDLE_CONSEC(2), .INIT_TIMEOUT(ROWS + 100), .INIT_GRACE(16),
    .REPAIR_EN(1'b1), .SPARE_ROWS(SR), .SPARE_COLS(SC)
  ) dut (
    .clk(clk), .rst_n(rst_n), .start_i(start_i), .start_clr_i(start_clr_i), .abort_i(abort_i), .clear_i(clear_i),
    .fail_pop_i(fail_pop_i), .clr_fault_i(clr_fault_i), .cfg_from_pins_i(cfg_from_pins_i), .cfg_algo_i(cfg_algo_i),
    .cfg_pattern_i(cfg_pattern_i), .cfg_stripe_k_i(cfg_stripe_k_i), .cfg_sweep_i(cfg_sweep_i), .cfg_colsel_i(cfg_colsel_i),
    .cfg_stop_i(cfg_stop_i), .cfg_reinit_i(cfg_reinit_i), .cfg_sel_i(cfg_sel_i), .cfg_bank_i(cfg_bank_i),
    .cfg_bmask_i(cfg_bmask_i), .cfg_row_lo_i(cfg_row_lo_i), .cfg_row_hi_i(cfg_row_hi_i), .cfg_wdog_i(cfg_wdog_i),
    .test_mode_i(test_mode_i), .test_permit_i(test_permit_i), .mem_inhibit_i(mem_inhibit_i), .cpu_halted_i(cpu_halted_i),
    .protect_i(protect_i), .busy_o(busy_o), .done_o(done_o), .pass_o(pass_o), .fail_o(fail_o), .error_o(error_o),
    .result_o(result_o), .bank_tested_o(bank_tested_o), .bank_fail_mask_o(bank_fail_mask_o), .err_flags_o(err_flags_o),
    .state_o(state_o), .fail_valid_o(fail_valid_o), .fail_bank_o(fail_bank_o), .fail_row_o(fail_row_o),
    .fail_bit_o(fail_bit_o), .fail_bit_v_o(fail_bit_v_o), .fail_in_check_o(fail_in_check_o), .fail_elem_o(fail_elem_o),
    .fail_op_o(fail_op_o), .fail_pol_o(fail_pol_o), .fail_pass_o(fail_pass_o), .fail_cls_o(fail_cls_o),
    .fail_alias_o(fail_alias_o), .fail_exp_o(fail_exp_o), .fail_obs_o(fail_obs_o), .fail_count_o(fail_count_o),
    .quiesce_o(quiesce_o), .quiesce_ack_i(q_ack), .idle_i(idle), .init_start_o(init_start_o), .init_busy_i(init_busy),
    .func_req_i(func_req), .clk_req_o(clk_req_o), .tst_active_o(tst_active_o), .tst_sel_o(tst_sel_o), .tst_ce_o(tst_ce_o),
    .tst_we_o(tst_we_o), .tst_addr_o(tst_addr_o), .tst_wdata_o(tst_wdata_o), .tst_rdata_i(tst_rdata_i),
    .rb_req(rb_req), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_gnt(rb_gnt), .rb_rdata(rb_rdata),
    .rb_err(rb_err), .ras_valid_o(ras_valid_o), .ras_type_o(ras_type_o), .ras_addr_o(ras_addr_o),
    .ras_addr_v_o(ras_addr_v_o), .ras_info_o(ras_info_o), .ras_corr_o(ras_corr_o), .rep_row_v_o(rep_row_v_o),
    .rep_row_o(rep_row_o), .rep_col_v_o(rep_col_v_o), .rep_col_o(rep_col_o), .rep_ok_o(rep_ok_o),
    .rep_unrep_o(rep_unrep_o), .rep_phys_o(rep_phys_o));

  // ---------------------------------------------------------------- register addresses
  localparam logic [11:0] A_ID = 12'h000, A_REV = 12'h004, A_CAPS0 = 12'h008, A_CAPS1 = 12'h00C, A_CAPS2 = 12'h010,
    A_ACCESS = 12'h014, A_SHARED = 12'h018, A_TENSOR = 12'h01C, A_VECTOR = 12'h020, A_CTRL = 12'h030, A_CFG = 12'h034,
    A_SELECT = 12'h038, A_BMASK = 12'h03C, A_ROWLO = 12'h040, A_ROWHI = 12'h044, A_WDOG = 12'h048, A_STATUS = 12'h050,
    A_ERR = 12'h054, A_TESTED = 12'h058, A_BFAILED = 12'h05C, A_FCOUNT = 12'h060, A_FIFOST = 12'h064, A_PROG = 12'h068,
    A_CURADDR = 12'h06C, A_CYCLES = 12'h070, A_INTR = 12'h074, A_RAS = 12'h078, A_ARB = 12'h07C, A_COLF = 12'h080,
    A_FF_ADDR = 12'h0A0, A_FF_BIT = 12'h0A4, A_FF_OP = 12'h0A8, A_FF_VALID = 12'h0AC, A_FF_EXP = 12'h0B0, A_FF_OBS = 12'h0D0,
    A_HD_ADDR = 12'h100, A_HD_BIT = 12'h104, A_HD_OP = 12'h108, A_HD_VALID = 12'h10C, A_HD_EXP = 12'h110, A_HD_OBS = 12'h130,
    A_BCNT = 12'h200, A_REP_OK = 12'h300, A_REP_UNREP = 12'h304, A_REP_TOUCHED = 12'h308, A_REP_PHYS = 12'h30C,
    A_REP_ROW = 12'h340, A_REP_COL = 12'h3C0;

  // ---------------------------------------------------------------- monitors
  integer viol_ce_unowned = 0, viol_inflight = 0, viol_quiesce = 0, viol_ack = 0, viol_func_in_own = 0, viol_permit = 0;
  integer ops_n = 0, act_cycles = 0, bseq_n = 0; integer bseq [0:127]; integer last_b = -1;
  integer ras_n = 0; logic [3:0] ras_t [0:63]; logic [31:0] ras_a [0:63]; logic [31:0] ras_i [0:63]; logic ras_av [0:63]; integer ras_corr_seen = 0;
  integer we_n = 0;

  function automatic integer onehot_idx(input logic [NBANK-1:0] v);
    integer r;
    begin r = -1; for (int i = 0; i < NBANK; i++) if (v[i]) r = i; onehot_idx = r; end
  endfunction
  function automatic integer popc(input logic [31:0] v);
    integer r;
    begin r = 0; for (int i = 0; i < 32; i++) if (v[i]) r = r + 1; popc = r; end
  endfunction

  always @(posedge clk) begin
    if (tst_ce_o && !(tst_active_o && test_mode_i && test_permit_i && !mem_inhibit_i)) viol_ce_unowned = viol_ce_unowned + 1;
    if (tst_ce_o && !(test_mode_i && test_permit_i && !mem_inhibit_i)) viol_permit = viol_permit + 1;
    if (tst_active_o && (inflight != 0 || func_acc)) viol_inflight = viol_inflight + 1;
    if (tst_active_o && !quiesce_o) viol_quiesce = viol_quiesce + 1;
    if (tst_active_o && !q_ack) viol_ack = viol_ack + 1;
    if (func_acc && quiesce_o) viol_func_in_own = viol_func_in_own + 1;
    if (tst_active_o) act_cycles = act_cycles + 1;
    if (tst_ce_o) begin
      ops_n = ops_n + 1;
      if (tst_we_o) we_n = we_n + 1;
      if (onehot_idx(tst_sel_o) != last_b) begin
        last_b = onehot_idx(tst_sel_o);
        if (bseq_n < 128) bseq[bseq_n] = last_b;
        bseq_n = bseq_n + 1;
      end
    end
    if (ras_valid_o) begin
      if (ras_n < 64) begin ras_t[ras_n] = ras_type_o; ras_a[ras_n] = ras_addr_o; ras_i[ras_n] = ras_info_o; ras_av[ras_n] = ras_addr_v_o; end
      ras_n = ras_n + 1;
      if (ras_corr_o) ras_corr_seen = ras_corr_seen + 1;
    end
  end

  task automatic mon_clear;
    begin ops_n = 0; act_cycles = 0; bseq_n = 0; last_b = -1; we_n = 0; end
  endtask
  task automatic ras_clear; begin ras_n = 0; end endtask

  // ---------------------------------------------------------------- register bus tasks
  logic [31:0] rd_val; logic rd_err;
  task automatic rb_access(input logic we, input logic [11:0] a, input logic [31:0] d);
    begin
      @(posedge clk); rb_req <= 1'b1; rb_we <= we; rb_addr <= a; rb_wdata <= d;
      @(posedge clk); rd_val = rb_rdata; rd_err = rb_err; rb_req <= 1'b0; rb_we <= 1'b0;
    end
  endtask
  task automatic rw(input logic [11:0] a, input logic [31:0] d);
    begin rb_access(1'b1, a, d); `CHECK(!rd_err, "register write accepted") end
  endtask
  task automatic rr(input logic [11:0] a);
    begin rb_access(1'b0, a, 32'd0); `CHECK(!rd_err, "register read accepted") end
  endtask

  task automatic cfgw(input int algo, input int pat, input int k, input int sweep, input int col, input int stop, input int reinit);
    reg [31:0] v;
    begin
      v = 32'd0; v[3:0] = algo; v[6:4] = pat; v[10:7] = k; v[11] = sweep; v[13:12] = col; v[14] = stop; v[15] = reinit;
      rw(A_CFG, v);
    end
  endtask
  task automatic selw(input int sel, input int bank, input int bmask);
    reg [31:0] v;
    begin v = 32'd0; v[2:0] = sel; v[15:8] = bank; rw(A_SELECT, v); rw(A_BMASK, bmask); end
  endtask
  task automatic winw(input int lo, input int hi); begin rw(A_ROWLO, lo); rw(A_ROWHI, hi); end endtask
  task automatic defcfg;       // March C-, ALL0, no sweep, all columns, no stop, re-init on, select ALL, full window
    begin cfgw(0, 0, 0, 0, 0, 0, 1); selw(`MB_SEL_ALL, 0, (1 << NBANK) - 1); winw(0, ROWS - 1); rw(A_WDOG, 0); end
  endtask

  integer run_to;
  task automatic wait_run;
    integer t;
    begin
      t = 0; run_to = 0;
      while (!busy_o && t < 60) begin @(posedge clk); t = t + 1; end
      t = 0;
      while (busy_o && t < 400000) begin @(posedge clk); t = t + 1; end
      if (t >= 400000) begin run_to = 1; `CHECK(0, "run did not complete (timeout)") end
      repeat (4) @(posedge clk);
    end
  endtask
  task automatic go;            // start via the register page and wait for the end of the run
    begin mon_clear(); rw(A_CTRL, 32'h1); wait_run(); end
  endtask
  task automatic do_clear;
    begin rw(A_CTRL, 32'h4); repeat (4) @(posedge clk); end
  endtask
  task automatic fault(input int b, input int s, input int t, input int row, input int bit_, input int row2, input int bit2, input int v, input int v2);
    begin sys.set_fault(b, s, t, row, bit_, row2, bit2, v, v2); end
  endtask
  task automatic nofaults; begin sys.clear_faults(); end endtask
  task automatic tick(input int n); begin repeat (n) @(posedge clk); end endtask
`define PULSE(sig) begin @(posedge clk); sig <= 1'b1; @(posedge clk); sig <= 1'b0; end

  function automatic logic [NBANK-1:0] sel_mask_tb(input int sel, input int bank, input logic [NBANK-1:0] bm);
    begin
      case (sel)
        0: sel_mask_tb = (bank < NBANK) ? (NBANK'(1) << bank) : '0;
        1: sel_mask_tb = bm;
        2: sel_mask_tb = ACCESS;
        3: sel_mask_tb = SHARED;
        4: sel_mask_tb = TENSOR;
        5: sel_mask_tb = VECTOR;
        default: sel_mask_tb = '0;
      endcase
    end
  endfunction

  function automatic logic flag(input int idx); begin flag = err_flags_o[idx]; end endfunction

  integer lowacc;   // lowest accessible bank
  integer hiacc;    // highest accessible bank
  integer nacc;

  // expect a refused start: result REFUSED, memory untouched, flag raised
  task automatic expect_refused(input string name, input int flagidx);
    begin
      `CHECK_EQ(result_o, `MB_RES_REFUSED, {name, ": result REFUSED"})
      `CHECK(done_o && !busy_o && error_o && !pass_o, {name, ": done/error pins, not pass"})
      `CHECK(flag(flagidx), {name, ": error flag"})
      `CHECK_EQ(ops_n, 0, {name, ": no test operation issued"})
      `CHECK_EQ(act_cycles, 0, {name, ": memory never handed to the test bus"})
    end
  endtask

  // ------------------------------------------------------------------ main
  integer i, j, n_exp, t0; logic [31:0] v1, v2, v3; logic [NBANK-1:0] em;
  integer before_acc, before_blk, before_intr;
  initial begin
    start_i = 0; start_clr_i = 0; abort_i = 0; clear_i = 0; fail_pop_i = 0; clr_fault_i = 0; cfg_from_pins_i = 0;
    cfg_algo_i = 0; cfg_pattern_i = 0; cfg_stripe_k_i = 0; cfg_sweep_i = 0; cfg_colsel_i = 0; cfg_stop_i = 0; cfg_reinit_i = 1;
    cfg_sel_i = 0; cfg_bank_i = 0; cfg_bmask_i = '0; cfg_row_lo_i = '0; cfg_row_hi_i = AW'(ROWS - 1); cfg_wdog_i = 0;
    test_mode_i = 1; test_permit_i = 1; mem_inhibit_i = 0; cpu_halted_i = 0; protect_i = '0;
    rb_req = 0; rb_we = 0; rb_addr = 0; rb_wdata = 0;
    traffic = 0; rogue = 0; no_ack = 0; no_idle = 0; no_init = 0; init_on_reset = 0; ack_delay = 0; drain_extra = 0; init_extra = 0;
    lowacc = -1; hiacc = -1; nacc = 0;
    for (int b = 0; b < NBANK; b++) if (ACCESS[b]) begin if (lowacc < 0) lowacc = b; hiacc = b; nacc = nacc + 1; end
    repeat (4) @(posedge clk); rst_n = 1; repeat (3) @(posedge clk);

    // ============================================================ S01
    `SECTION("S01 identity / capability registers");
    rr(A_ID);     `CHECK_EQ(rd_val, 32'h4D425354, "ID = MBST")
    rr(A_REV);    `CHECK_EQ(rd_val, 32'h00780001, "REV = project 78 release 1")
    rr(A_CAPS0);  `CHECK_EQ(rd_val, {8'(STORE_W), 8'(DATA_W), 8'(AW), 8'(NBANK)}, "CAPS0 = {STORE_W, DATA_W, ROW_W, NBANK}")
    rr(A_CAPS1);  `CHECK_EQ(rd_val[3:0], 4'(L + TP), "CAPS1.LT")
                  `CHECK_EQ(rd_val[15:8], {4'(SC), 4'(SR)}, "CAPS1 spare counts")
                  `CHECK(rd_val[16] && !rd_val[17], "CAPS1: repair analysis on, physical redundancy absent")
    rr(A_CAPS2);  `CHECK_EQ(rd_val, 32'(ROWS), "CAPS2 = ROWS")
    rr(A_ACCESS); `CHECK_EQ(rd_val, 32'(ACCESS), "ACCESS_MASK register")
    rr(A_SHARED); `CHECK_EQ(rd_val, 32'(SHARED), "SHARED_MASK register")
    rr(A_TENSOR); `CHECK_EQ(rd_val, 32'(TENSOR), "TENSOR_MASK register")
    rr(A_VECTOR); `CHECK_EQ(rd_val, 32'(VECTOR), "VECTOR_MASK register")
    rr(A_STATUS); `CHECK(!rd_val[0] && !rd_val[1], "idle after reset: not busy, not done")
                  `CHECK_EQ(rd_val[10:8], `MB_RES_NONE, "no result after reset")
    rr(A_CFG);    `CHECK_EQ(rd_val[15:0], 16'h8000, "CFG reset value: March C-, ALL0, re-init enabled")
    rr(A_ROWHI);  `CHECK_EQ(rd_val, 32'(ROWS - 1), "ROW_HI resets to ROWS-1")

    // ============================================================ S02 refusals
    `SECTION("S02 start refusals leave the memory untouched");
    defcfg();
    test_permit_i = 0; go(); expect_refused("no permit", `MB_ERR_NO_PERMIT); test_permit_i = 1; do_clear();
    test_mode_i = 0;   go(); expect_refused("no test mode", `MB_ERR_NO_PERMIT); test_mode_i = 1; do_clear();
    mem_inhibit_i = 1; go(); expect_refused("mem inhibit", `MB_ERR_NO_PERMIT); mem_inhibit_i = 0; do_clear();
    selw(`MB_SEL_SEQ, 0, 0); go(); expect_refused("empty selection", `MB_ERR_EMPTY_SEL); do_clear();
    if (ACCESS != {NBANK{1'b1}}) begin
      selw(`MB_SEL_SEQ, 0, (1 << NBANK) - 1); go(); expect_refused("selection includes a bank without a test port", `MB_ERR_NOT_ACCESSIBLE); do_clear();
      for (int b = 0; b < NBANK; b++) if (!ACCESS[b]) begin
        selw(`MB_SEL_BANK, b, 0); go(); expect_refused("single inaccessible bank", `MB_ERR_NOT_ACCESSIBLE); do_clear();
      end
    end
    defcfg();
    cfgw(7, 0, 0, 0, 0, 0, 1); go(); expect_refused("bad algorithm", `MB_ERR_BAD_CFG); do_clear();
    cfgw(0, 7, 0, 0, 0, 0, 1); go(); expect_refused("bad pattern", `MB_ERR_BAD_CFG); do_clear();
    cfgw(0, 0, 0, 0, 3, 0, 1); go(); expect_refused("bad column select", `MB_ERR_BAD_CFG); do_clear();
    defcfg(); winw(9, 3); go(); expect_refused("row_lo > row_hi", `MB_ERR_BAD_CFG); do_clear();
    defcfg(); winw(0, ROWS); go(); expect_refused("row_hi >= ROWS", `MB_ERR_BAD_CFG); do_clear();
    defcfg(); selw(7, 0, 0); go(); expect_refused("invalid select mode", `MB_ERR_BAD_CFG); do_clear();
    defcfg(); selw(`MB_SEL_BANK, NBANK, 0); go(); expect_refused("bank index out of range", `MB_ERR_BAD_CFG); do_clear();
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); protect_i[lowacc] = 1;
    go(); expect_refused("protected bank, CPU running", `MB_ERR_PROTECTED); do_clear();
    cpu_halted_i = 1; go(); `CHECK_EQ(result_o, `MB_RES_PASS, "protected bank tested once the CPU is halted") cpu_halted_i = 0; protect_i = '0; do_clear();
    rr(A_ERR); `CHECK_EQ(rd_val, 32'd0, "CLEAR acknowledged every error flag")
    // start while busy
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); mon_clear(); rw(A_CTRL, 32'h1); tick(20); rw(A_CTRL, 32'h1); rw(A_CTRL, 32'h4); wait_run();
    `CHECK(flag(`MB_ERR_CMD_BUSY), "START / CLEAR during a run flagged CMD_BUSY")
    `CHECK_EQ(result_o, `MB_RES_PASS, "run unaffected by the ignored commands")
    `CHECK_EQ(ops_n, 10 * ROWS, "exactly one March C- executed")
    do_clear();

    // ============================================================ S03 selection
    `SECTION("S03 memory selection: bank / sequential / all / shared / tensor / vector");
    for (int e = 0; e < NBANK + 6; e++) begin
      integer sel_, arg_; logic [NBANK-1:0] bm_;
      bm_ = '0;
      if (e < NBANK)          begin sel_ = `MB_SEL_BANK; arg_ = e; end
      else if (e == NBANK)    begin sel_ = `MB_SEL_SEQ;  arg_ = 0; bm_ = ACCESS & ~(NBANK'(1) << lowacc); end   // accessible subset
      else if (e == NBANK+1)  begin sel_ = `MB_SEL_SEQ;  arg_ = 0; bm_ = {NBANK{1'b1}}; end                    // every bank, accessible or not
      else if (e == NBANK+2)  begin sel_ = `MB_SEL_ALL;    arg_ = 0; end
      else if (e == NBANK+3)  begin sel_ = `MB_SEL_SHARED; arg_ = 0; end
      else if (e == NBANK+4)  begin sel_ = `MB_SEL_TENSOR; arg_ = 0; end
      else                    begin sel_ = `MB_SEL_VECTOR; arg_ = 0; end
      defcfg(); selw(sel_, arg_, bm_);
      em = sel_mask_tb(sel_, arg_, bm_);
      go();
      $display("  select mode %0d arg %0d bmask %b -> resolved %b, accessible %b: result %0d tested %b", sel_, arg_, bm_, em, ACCESS, result_o, bank_tested_o);
      if (em == 0) begin expect_refused("selection resolves to no bank", `MB_ERR_EMPTY_SEL); end
      else if ((em & ~ACCESS) != 0) begin expect_refused("selection includes inaccessible bank", `MB_ERR_NOT_ACCESSIBLE); end
      else begin
        `CHECK_EQ(result_o, `MB_RES_PASS, "fault-free selection PASS")
        `CHECK_EQ(bank_tested_o, em, "tested mask equals the resolved selection")
        `CHECK_EQ(ops_n, 10 * ROWS * popc(32'(em)), "operation count = 10 N per selected bank")
        `CHECK_EQ(bseq_n, popc(32'(em)), "each selected bank entered exactly once")
        for (int k = 1; k < bseq_n && k < 128; k++) `CHECK(bseq[k] > bseq[k-1], "banks visited in ascending order, one at a time")
        for (int k = 0; k < bseq_n && k < 128; k++) `CHECK(em[bseq[k]], "only selected banks are touched")
      end
      do_clear();
    end

    // ============================================================ S04 per-bank fault signatures
    `SECTION("S04 fault signatures per bank, multi-bank diagnosis");
    for (int b = 0; b < NBANK; b++) if (ACCESS[b]) begin
      defcfg(); nofaults(); fault(b, 0, 1, 5, 3, 0, 0, 0, 0);          // SA0 (row 5, bit 3) in bank b
      go();
      `CHECK_EQ(result_o, `MB_RES_FAIL, "SA0 in bank: FAIL")
      `CHECK(fail_o && done_o && !pass_o && !error_o, "pins: done, fail, not pass")
      `CHECK_EQ(fail_bank_o, BW'(b), "failing bank id")
      `CHECK_EQ(fail_row_o, AW'(5), "failing row")
      `CHECK_EQ(fail_bit_o, BITW'(3), "failing bit")
      `CHECK(fail_bit_v_o && !fail_in_check_o, "single data bit")
      `CHECK_EQ(fail_elem_o, 3'd2, "first failing March element U(r1,w0)")
      `CHECK_EQ(fail_pol_o, 1'b1, "expected read polarity r1")
      `CHECK_EQ(fail_cls_o, `MB_CLS_1TO0_BIT, "symptom: 1 read as 0")
      `CHECK_EQ(fail_exp_o ^ fail_obs_o, STORE_W'(1 << 3), "expected ^ observed = failing bit")
      `CHECK_EQ(bank_fail_mask_o, NBANK'(1 << b), "bank_fail_mask has only the failing bank")
      `CHECK(fail_count_o >= 32'd2, "SA0 fails in both r1 reads (elements 2 and 4)")
      rr(A_BCNT + 12'(4 * b)); `CHECK(rd_val >= 32'd2, "per-bank failure counter")
      do_clear();
    end
    if (nacc >= 2) begin       // two faulty banks: the lowest bank reports first, both appear in the mask
      defcfg(); nofaults(); fault(lowacc, 0, 2, 4, 2, 0, 0, 1, 0); fault(hiacc, 0, 1, 11, 6, 0, 0, 1, 0);
      go();
      `CHECK_EQ(result_o, `MB_RES_FAIL, "two faulty banks: FAIL")
      `CHECK_EQ(fail_bank_o, BW'(lowacc), "first failure belongs to the lowest bank")
      `CHECK_EQ(bank_fail_mask_o, NBANK'((1 << lowacc) | (1 << hiacc)), "both faulty banks in the mask")
      `CHECK_EQ(bank_tested_o, ACCESS, "every accessible bank was tested to completion")
      do_clear(); nofaults();
    end

    // ============================================================ S05 all fault types
    `SECTION("S05 every supported fault type is detected");
    begin : s05
      integer ft; integer b;
      b = hiacc;
      for (ft = 0; ft < 10; ft++) begin
        defcfg(); selw(`MB_SEL_BANK, b, 0); nofaults();
        case (ft)
          0: fault(b, 0, 1, 6, 1, 0, 0, 0, 0);       // SA0
          1: fault(b, 0, 1, 6, 1, 0, 0, 1, 0);       // SA1
          2: fault(b, 0, 2, 6, 1, 0, 0, 1, 0);       // TF up
          3: fault(b, 0, 2, 6, 1, 0, 0, 0, 0);       // TF down
          4: fault(b, 0, 3, 6, 0, 0, 0, 0, 0);       // AF no access
          5: fault(b, 0, 4, 6, 0, 10, 0, 0, 0);      // AF alias
          6: fault(b, 0, 5, 6, 0, 10, 0, 0, 0);      // AF multi-access OR
          7: fault(b, 0, 6, 2, 0, 9, 4, 1, 0);       // CFin, aggressor rise
          8: fault(b, 0, 7, 2, 0, 9, 4, 0, 1);       // CFid, aggressor fall -> victim 1
          9: fault(b, 0, 8, 2, 0, 9, 4, 1, 1);       // CFst
        endcase
        go();
        `CHECK_EQ(result_o, `MB_RES_FAIL, "fault type detected")
        `CHECK(fail_valid_o && fail_o, "failure reported")
        `CHECK(fail_exp_o != fail_obs_o, "observed differs from expected")
        do_clear();
      end
      nofaults();
    end
    // fault-free again, after all that
    defcfg(); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "fault-free after fault campaign (arrays re-initialised, no stale state)") do_clear();

    // ============================================================ S06 diagnostics
    `SECTION("S06 failure diagnostics: first record, FIFO, counters, classification, preservation");
    begin : s06
      integer b; integer cnt0;
      b = lowacc;
      defcfg(); selw(`MB_SEL_BANK, b, 0); nofaults();
      fault(b, 0, 1, 2, 1, 0, 0, 0, 0); fault(b, 1, 1, 7, CB1, 0, 0, 1, 0);   // SA0 (2,1); SA1 (7,CB1): CB1 is a check column when STORE_W > DATA_W
      go();
      `CHECK_EQ(result_o, `MB_RES_FAIL, "two cell faults: FAIL")
      rr(A_FF_VALID); `CHECK_EQ(rd_val, 32'd1, "FIRST valid")
      rr(A_FF_ADDR);  `CHECK_EQ(rd_val[31:24], 8'(b), "FF_ADDR bank field") `CHECK_EQ(rd_val[23:0], 24'd7, "FF_ADDR row field = failing row 7")
      `CHECK_EQ(rd_val[23:0], 24'(fail_row_o), "FF_ADDR row equals the pin")
      // first failure is the earliest March read that miscompares: SA1 (7,CB1) fails in U(r0,w1) element 1 at row 7,
      // before SA0 (2,1) fails in element 2
      `CHECK_EQ(fail_elem_o, 3'd1, "first failing element (SA1 at row 7)")
      `CHECK_EQ(fail_row_o, AW'(7), "first failing row")
      `CHECK_EQ(fail_bit_o, BITW'(CB1), "first failing bit")
      `CHECK(fail_bit_v_o && (fail_in_check_o == HAS_CHECK), "in_check set exactly when the failing bit is >= DATA_W")
      `CHECK_EQ(fail_cls_o, `MB_CLS_0TO1_BIT, "class: 0 read as 1")
      rr(A_FF_BIT);   `CHECK_EQ(rd_val[15:0], 16'(CB1), "FF_BIT index") `CHECK(rd_val[16] && (rd_val[17] == HAS_CHECK), "FF_BIT: bit_valid, in_check per column kind")
      rr(A_FF_OP);    `CHECK_EQ(rd_val[2:0], 3'd1, "FF_OP element") `CHECK_EQ(rd_val[15:12], `MB_CLS_0TO1_BIT, "FF_OP class")
      rr(A_FF_EXP);   v2 = rd_val; rr(A_FF_OBS); v3 = rd_val;
      `CHECK_EQ(v2[STORE_W-1:0], fail_exp_o, "FF_EXP register equals the pin") `CHECK_EQ(v3[STORE_W-1:0], fail_obs_o, "FF_OBS register equals the pin")
      `CHECK_EQ(v2 ^ v3, 32'(1 << CB1), "FF_EXP ^ FF_OBS = the failing bit")
      // column fail mask
      rr(A_COLF); `CHECK_EQ(rd_val[STORE_W-1:0], STORE_W'((1 << 1) | (1 << CB1)), "column-failure mask = {1, CB1}")
      // FIFO: head equals first record, pop advances, count drops, FIRST stays
      rr(A_FIFOST); cnt0 = rd_val[7:0]; `CHECK(cnt0 >= 2 && cnt0 <= 4, "FIFO holds the first failures (depth 4)")
      rr(A_HD_VALID); `CHECK_EQ(rd_val, 32'd1, "FIFO head valid")
      rr(A_HD_ADDR); v1 = rd_val; rr(A_FF_ADDR); `CHECK_EQ(v1, rd_val, "FIFO head == first record before any pop")
      // every remaining diagnostic register: head record == first record, status registers == pins
      rr(A_HD_BIT); v2 = rd_val; rr(A_FF_BIT); `CHECK_EQ(v2, rd_val, "HD_BIT == FF_BIT before any pop")
      rr(A_HD_OP);  v2 = rd_val; rr(A_FF_OP);  `CHECK_EQ(v2, rd_val, "HD_OP == FF_OP before any pop")
      rr(A_HD_EXP); v2 = rd_val; rr(A_FF_EXP); `CHECK_EQ(v2, rd_val, "HD_EXP == FF_EXP before any pop")
      rr(A_HD_OBS); v2 = rd_val; rr(A_FF_OBS); `CHECK_EQ(v2, rd_val, "HD_OBS == FF_OBS before any pop")
      rr(A_TESTED);  `CHECK_EQ(rd_val, 32'(bank_tested_o), "BANK_TESTED register == pin")
      rr(A_BFAILED); `CHECK_EQ(rd_val, 32'(bank_fail_mask_o), "BANK_FAILED register == pin")
      rr(A_FCOUNT);  `CHECK_EQ(rd_val, fail_count_o, "FAIL_COUNT register == pin")
      rr(A_CYCLES);  `CHECK(rd_val > 10 * ROWS, "CYCLES covers at least the 10N operations")
      rr(A_PROG);    rr(A_CURADDR);
      rr(A_ARB);     `CHECK_EQ(rd_val[3:0], 4'd0, "arbiter idle after the run") `CHECK(!rd_val[4] && !rd_val[5] && !rd_val[6] && !rd_val[7], "no quiesce / ownership / clock request when idle")
      rr(A_STATUS);  `CHECK(rd_val[1] && rd_val[3] && rd_val[7] && rd_val[24] && rd_val[25], "STATUS: done, fail, unread, FIFO head, first record")
      rr(A_FCOUNT); v1 = rd_val;
      rw(A_CTRL, 32'h8); tick(3); rr(A_FIFOST); `CHECK_EQ(rd_val[7:0], 8'(cnt0 - 1), "POP removes one FIFO entry")
      rr(A_FF_VALID); `CHECK_EQ(rd_val, 32'd1, "FIRST record not consumed by POP")
      for (int k = 0; k < 8; k++) begin rw(A_CTRL, 32'h8); tick(2); end
      rr(A_FIFOST); `CHECK_EQ(rd_val[7:0], 8'd0, "FIFO empty after popping everything") `CHECK_EQ(rd_val[31], 1'b0, "head_valid low when empty")
      rr(A_FCOUNT); `CHECK_EQ(rd_val, v1, "FAIL_COUNT not consumed by POP")
      // preservation over time
      tick(200); rr(A_FF_ADDR); `CHECK_EQ(rd_val[23:0], 24'(fail_row_o), "record preserved while idle") `CHECK(fail_valid_o, "first record still valid after 200 idle cycles")
      // a new start with unread results is refused ... and nothing is lost
      mon_clear(); rw(A_CTRL, 32'h1); wait_run();
      `CHECK_EQ(result_o, `MB_RES_REFUSED, "start with unread failure data refused")
      `CHECK(flag(`MB_ERR_RESULT_PENDING), "RESULT_PENDING flagged")
      `CHECK(fail_valid_o && fail_count_o == v1, "unread data intact after the refused start")
      // START_CLR = clear + start in one command
      mon_clear(); rw(A_CTRL, 32'h10); wait_run();
      `CHECK_EQ(result_o, `MB_RES_FAIL, "START_CLR runs (and finds the same faults again)")
      `CHECK_EQ(fail_count_o, v1, "failure count reproducible: identical to the previous run")
      `CHECK_EQ(fail_elem_o, 3'd1, "first-failure element reproducible")
      do_clear(); nofaults();
      rr(A_FF_VALID); `CHECK_EQ(rd_val, 32'd0, "CLEAR erases the first record")
      rr(A_FCOUNT);   `CHECK_EQ(rd_val, 32'd0, "CLEAR erases the counter")
      `CHECK(!done_o && result_o == `MB_RES_NONE, "CLEAR drops done and the result")
    end
    // FIFO overflow: more failing compares than entries; nothing is silently lost
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); nofaults();
    fault(lowacc, 0, 1, 1, 0, 0, 0, 1, 0); fault(lowacc, 1, 1, 3, 1, 0, 0, 1, 0); fault(lowacc, 2, 1, 5, 2, 0, 0, 1, 0); fault(lowacc, 3, 1, 8, 3, 0, 0, 1, 0);
    go();
    rr(A_FIFOST); v1 = rd_val; rr(A_FCOUNT); v2 = rd_val;
    `CHECK_EQ(v1[7:0], 8'd4, "FIFO full at depth 4")
    `CHECK(v1[23:16] > 0, "overflow counted in FIFO lost")
    `CHECK_EQ(32'(v1[7:0]) + 32'(v1[23:16]), v2, "pushed + lost == failing compares (no silent loss)")
    `CHECK(flag(`MB_ERR_FIFO_LOST), "FIFO_LOST flagged")
    `CHECK_EQ(fail_row_o, AW'(1), "first record is still the first failure after overflow")
    do_clear(); nofaults();
    // address-dependent pattern recovers the alias target
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); cfgw(0, `MB_PAT_ADDR, 0, 0, 0, 0, 1); nofaults(); fault(lowacc, 0, 4, 5, 0, 9, 0, 0, 0);
    go();
    `CHECK_EQ(result_o, `MB_RES_FAIL, "AF alias with ADDR pattern: FAIL")
    `CHECK_EQ(fail_cls_o, `MB_CLS_ADDR_ALIAS, "diagnosed as an address alias")
    `CHECK_EQ(fail_alias_o, AW'(9), "alias target row recovered from the observed word")
    `CHECK_EQ(fail_row_o, AW'(5), "failing address is the aliased row")
    `CHECK_EQ(fail_elem_o, 3'd1, "detected by the first read element")
    do_clear(); nofaults();

    // ============================================================ S07 column selection
    `SECTION("S07 raw array test: data columns vs check columns");
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0);
    if (HAS_CHECK) begin
      nofaults(); fault(lowacc, 0, 1, 6, CB2, 0, 0, 0, 0);                                    // SA0 in a check column
      cfgw(0, 0, 0, 0, `MB_COL_ALL, 0, 1);   go(); `CHECK_EQ(result_o, `MB_RES_FAIL, "ALL columns: check-column fault found")  `CHECK(fail_in_check_o, "reported as check column") do_clear();
      cfgw(0, 0, 0, 0, `MB_COL_DATA, 0, 1);  go(); `CHECK_EQ(result_o, `MB_RES_PASS, "DATA columns only: check-column fault not compared") do_clear();
      cfgw(0, 0, 0, 0, `MB_COL_CHECK, 0, 1); go(); `CHECK_EQ(result_o, `MB_RES_FAIL, "CHECK columns only: found") `CHECK(fail_in_check_o, "in_check") do_clear();
      nofaults(); fault(lowacc, 0, 1, 6, 3, 0, 0, 0, 0);                                     // SA0 in data column 3
      cfgw(0, 0, 0, 0, `MB_COL_CHECK, 0, 1); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "CHECK columns only: data-column fault not compared") do_clear();
      cfgw(0, 0, 0, 0, `MB_COL_DATA, 0, 1);  go(); `CHECK_EQ(result_o, `MB_RES_FAIL, "DATA columns only: found") `CHECK(!fail_in_check_o, "data column") do_clear();
    end else begin
      cfgw(0, 0, 0, 0, `MB_COL_CHECK, 0, 1); go(); expect_refused("CHECK-column test on a memory without check columns", `MB_ERR_BAD_CFG); do_clear();
    end
    nofaults();

    // ============================================================ S08 patterns / sweep
    `SECTION("S08 backgrounds and sweep");
    for (int p = 0; p <= 5; p++) begin
      defcfg(); selw(`MB_SEL_BANK, lowacc, 0); cfgw(0, p, 2, 0, 0, 0, 1); go();
      `CHECK_EQ(result_o, `MB_RES_PASS, "pattern fault-free PASS") `CHECK_EQ(ops_n, 10 * ROWS, "one pass = 10N") do_clear();
    end
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); cfgw(0, 0, 0, 1, 0, 0, 1); go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "sweep fault-free PASS")
    `CHECK_EQ(ops_n, (1 + KMAX) * 10 * ROWS, "sweep = (1 + ceil(log2 W)) passes of 10N")
    do_clear();
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); cfgw(1, 0, 0, 0, 0, 0, 1); go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "MATS+ PASS") `CHECK_EQ(ops_n, 5 * ROWS, "MATS+ = 5N") do_clear();

    // ============================================================ S09 windows
    `SECTION("S09 row windows");
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); winw(3, 9); go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "window PASS") `CHECK_EQ(ops_n, 70, "window [3,9]: 10 x 7") do_clear();
    winw(4, 4); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "one-row window") `CHECK_EQ(ops_n, 10, "one-row window: 10 operations") do_clear();
    nofaults(); fault(lowacc, 0, 1, 12, 0, 0, 0, 0, 0); winw(0, 8); go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "fault outside the window is not seen") do_clear();
    winw(10, 15); go(); `CHECK_EQ(result_o, `MB_RES_FAIL, "fault inside the window is seen") `CHECK_EQ(fail_row_o, AW'(12), "row") do_clear(); nofaults();

    // ============================================================ S10 completion signalling
    `SECTION("S10 completion signalling");
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0);
    rw(A_CTRL, 32'h1); tick(5); `CHECK(busy_o && !done_o, "busy, not done while running"); wait_run();
    `CHECK(done_o && pass_o && !fail_o && !error_o && !busy_o, "pass: done, pass; not fail / error / busy")
    tick(300); `CHECK(done_o && pass_o, "done / pass held until the next start or clear")
    rw(A_CTRL, 32'h1); tick(3); `CHECK(!done_o && busy_o, "done drops when the next run starts"); wait_run(); do_clear();
    nofaults(); fault(lowacc, 0, 1, 2, 2, 0, 0, 0, 0); go();
    `CHECK(done_o && fail_o && !pass_o && !error_o, "fail: done, fail; not pass / error"); do_clear(); nofaults();
    test_permit_i = 0; go(); `CHECK(done_o && error_o && !pass_o && !fail_o, "refused: done + error, neither pass nor fail"); test_permit_i = 1; do_clear();

    // ============================================================ S11 ownership safety under live traffic
    `SECTION("S11 ownership safety: live traffic, slow quiesce acknowledge / drain, rogue master");
    defcfg(); selw(`MB_SEL_ALL, 0, 0);
    traffic = 1; tick(300); before_acc = facc_cnt;
    `CHECK(before_acc > 20, "functional traffic is running before the test")
    mon_clear(); rw(A_CTRL, 32'h1); wait_run();
    `CHECK_EQ(result_o, `MB_RES_PASS, "PASS with functional traffic before / after")
    `CHECK(!flag(`MB_ERR_INTRUSION), "a well-behaved master (stops after the quiesce acknowledge) raises NO intrusion")
    tick(300);
    `CHECK(facc_cnt > before_acc + 20, "functional traffic resumed after release")
    `CHECK_EQ(fchk_err, 32'd0, "functional scoreboard: no corrupted data (array re-initialised before release)")
    `CHECK(fchk_cnt > 0, "scoreboard actually checked reads")
    do_clear();
    // slow acknowledge and slow drain
    ack_delay = 9; drain_extra = 17; tick(50); defcfg(); selw(`MB_SEL_ALL, 0, 0); go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "PASS with slow quiesce acknowledge and slow drain") `CHECK_EQ(fchk_err, 32'd0, "scoreboard clean") do_clear();
    ack_delay = 0; drain_extra = 0;
    // rogue master: presents a request every cycle, ignoring the protocol
    rogue = 1; before_blk = fblk; tick(20); defcfg(); selw(`MB_SEL_ALL, 0, 0); go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "test unaffected by a rogue master (its requests are blocked)")
    `CHECK(flag(`MB_ERR_INTRUSION), "intrusion detected and flagged")
    rr(A_INTR); `CHECK(rd_val > 0, "intrusion counter")
    `CHECK(fblk > before_blk, "rogue requests were refused by the group")
    `CHECK_EQ(facc_in_test, 32'd0, "no functional access accepted while tst_active")
    do_clear(); rogue = 0; traffic = 0; tick(20);
    // skipping the re-initialisation is visible to the scoreboard (so the scoreboard CAN fail)
    traffic = 1; tick(200); defcfg(); selw(`MB_SEL_ALL, 0, 0); cfgw(0, 0, 0, 0, 0, 0, 0); before_intr = fchk_err; go();
    `CHECK_EQ(result_o, `MB_RES_PASS, "run with re-initialisation disabled")
    `CHECK(flag(`MB_ERR_REINIT_REQ), "released dirty without re-initialisation: REINIT_REQ flagged")
    tick(600);
    `CHECK(fchk_err > before_intr, "without re-initialisation the functional scoreboard sees the destroyed contents")
    do_clear(); traffic = 0; tick(10);
    defcfg(); selw(`MB_SEL_ALL, 0, 0); go(); do_clear();       // re-initialise properly (also resets the scoreboard reference)

    // ============================================================ S12 timeouts
    `SECTION("S12 ownership faults: no acknowledge, no idle, no init, slow init");
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0);
    no_ack = 1; go();
    `CHECK_EQ(result_o, `MB_RES_ERROR, "no quiesce acknowledge: ERROR") `CHECK(!pass_o && error_o, "not a pass")
    `CHECK(flag(`MB_ERR_OWN_TIMEOUT), "OWN_TIMEOUT flagged") `CHECK_EQ(ops_n, 0, "no test operation") `CHECK_EQ(act_cycles, 0, "memory never owned")
    `CHECK(!quiesce_o && !tst_active_o, "port returned to functional use") `CHECK_EQ(state_o[7:4], 4'd8, "arbiter in FAULT")
    no_ack = 0; do_clear(); go();
    `CHECK_EQ(result_o, `MB_RES_ERROR, "ownership fault is sticky: next start denied") `CHECK_EQ(act_cycles, 0, "still no access")
    do_clear(); rw(A_CTRL, 32'h20); tick(4); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "CLR_FAULT restores ownership"); do_clear();
    no_idle = 1; go(); `CHECK_EQ(result_o, `MB_RES_ERROR, "memory never idle: ERROR") `CHECK(flag(`MB_ERR_OWN_TIMEOUT), "OWN_TIMEOUT") `CHECK_EQ(act_cycles, 0, "never owned");
    no_idle = 0; do_clear(); rw(A_CTRL, 32'h20); tick(4);
    no_init = 1; go();
    `CHECK_EQ(result_o, `MB_RES_ERROR, "init engine does not start: ERROR (content undefined)")
    `CHECK(flag(`MB_ERR_REINIT_TIMEOUT) && flag(`MB_ERR_REINIT_REQ), "REINIT_TIMEOUT and REINIT_REQ flagged")
    `CHECK(!quiesce_o && !tst_active_o, "port returned, host must initialise") `CHECK(ops_n > 0, "the test itself did run")
    no_init = 0; do_clear(); rw(A_CTRL, 32'h20); tick(4);
    init_extra = 40; go(); `CHECK_EQ(result_o, `MB_RES_PASS, "slow init (within the timeout) is waited for"); init_extra = 0; do_clear();

    // ============================================================ S13 interruption
    `SECTION("S13 interruption: abort, permission loss, inhibit, stop-on-fail, watchdog");
    before_intr = fchk_err;     // baseline: S11 deliberately caused scoreboard errors
    traffic = 1; tick(100);
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0);
    mon_clear(); rw(A_CTRL, 32'h1); while (ops_n < 60) @(posedge clk); rw(A_CTRL, 32'h2); wait_run();
    `CHECK_EQ(result_o, `MB_RES_ABORTED, "abort mid-run: ABORTED") `CHECK(!pass_o && !error_o && !fail_o, "not a pass")
    `CHECK(ops_n < 10 * ROWS && ops_n >= 60, "run stopped early") `CHECK(!quiesce_o && !tst_active_o, "memory released")
    `CHECK_EQ(bank_tested_o, '0, "interrupted bank not marked tested")
    tick(400); `CHECK_EQ(fchk_err, before_intr, "memory re-initialised after the abort: functional traffic clean")
    do_clear(); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "a new run after an abort works"); do_clear();
    // abort while waiting for ownership
    ack_delay = 40; mon_clear(); rw(A_CTRL, 32'h1); tick(15); rw(A_CTRL, 32'h2); wait_run(); ack_delay = 0;
    `CHECK_EQ(result_o, `MB_RES_ABORTED, "abort while acquiring ownership") `CHECK_EQ(ops_n, 0, "nothing issued") `CHECK(!quiesce_o, "quiesce released"); do_clear();
    // permission loss mid-run
    mon_clear(); rw(A_CTRL, 32'h1); while (ops_n < 50) @(posedge clk); test_permit_i = 0; wait_run();
    `CHECK_EQ(result_o, `MB_RES_ERROR, "permission loss: ERROR") `CHECK(flag(`MB_ERR_PERM_LOSS), "PERM_LOSS flagged")
    `CHECK_EQ(viol_permit, 0, "no test operation after the permission dropped") `CHECK(!quiesce_o && !tst_active_o, "memory released")
    test_permit_i = 1; tick(400); `CHECK_EQ(fchk_err, before_intr, "memory re-initialised after permission loss"); do_clear();
    // DFT memory inhibit mid-run
    mon_clear(); rw(A_CTRL, 32'h1); while (ops_n < 50) @(posedge clk); mem_inhibit_i = 1; wait_run();
    `CHECK_EQ(result_o, `MB_RES_ERROR, "inhibit asserted mid-run: ERROR") `CHECK_EQ(viol_permit, 0, "no test operation under inhibit"); mem_inhibit_i = 0; do_clear();
    traffic = 0; tick(10);
    // an abort that arrives while the engine is already RELEASING a completed run has nothing left to abort
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); mon_clear(); rw(A_CTRL, 32'h1);
    t0 = 0; while (state_o[3:0] != 4'd8 && t0 < 20000) begin @(posedge clk); t0 = t0 + 1; end
    `CHECK_EQ(state_o[3:0], 4'd8, "engine reached the release state")
    `PULSE(abort_i); wait_run();
    `CHECK_EQ(result_o, `MB_RES_PASS, "abort during release does not turn a completed run into ABORTED") `CHECK(!flag(`MB_ERR_ABORTED), "no ABORTED flag"); do_clear();
    // permission loss / abort while still waiting for the quiesce acknowledge or the drain (nothing owned, nothing dirty)
    ack_delay = 60; mon_clear(); rw(A_CTRL, 32'h1); tick(20); test_permit_i = 0; wait_run(); ack_delay = 0; test_permit_i = 1;
    `CHECK_EQ(result_o, `MB_RES_ERROR, "permission lost while waiting for the acknowledge: ERROR") `CHECK(flag(`MB_ERR_PERM_LOSS), "PERM_LOSS flagged")
    `CHECK_EQ(ops_n, 0, "nothing issued") `CHECK_EQ(act_cycles, 0, "memory never owned") `CHECK(!quiesce_o, "quiesce released"); do_clear();
    drain_extra = 100; mon_clear(); rw(A_CTRL, 32'h1); tick(30); test_permit_i = 0; wait_run(); test_permit_i = 1;
    `CHECK_EQ(result_o, `MB_RES_ERROR, "permission lost while draining: ERROR") `CHECK_EQ(act_cycles, 0, "memory never owned") `CHECK(!quiesce_o, "quiesce released"); do_clear();
    mon_clear(); rw(A_CTRL, 32'h1); tick(30); rw(A_CTRL, 32'h2); wait_run(); drain_extra = 0;
    `CHECK_EQ(result_o, `MB_RES_ABORTED, "abort while draining: ABORTED") `CHECK_EQ(ops_n, 0, "nothing issued") `CHECK_EQ(act_cycles, 0, "memory never owned") `CHECK(!quiesce_o, "quiesce released"); do_clear();
    traffic = 0;
    // stop on fail in a MULTI-PASS (sweep) run stops before the remaining passes
    nofaults(); fault(lowacc, 0, 1, 2, 4, 0, 0, 0, 0);
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); cfgw(0, 0, 0, 1, 0, 1, 1); go();
    `CHECK_EQ(result_o, `MB_RES_FAIL, "stop-on-fail with sweep: FAIL") `CHECK(ops_n < (1 + KMAX) * 10 * ROWS, "remaining background passes skipped")
    `CHECK_EQ(fail_pass_o, 4'd0, "failure found in the first pass"); do_clear(); nofaults(); traffic = 1;
    // stop on fail
    nofaults(); fault(lowacc, 0, 1, 2, 4, 0, 0, 0, 0);
    defcfg(); selw(`MB_SEL_SEQ, 0, ACCESS); cfgw(0, 0, 0, 0, 0, 1, 1); go();
    `CHECK_EQ(result_o, `MB_RES_FAIL, "stop-on-fail: FAIL") `CHECK(ops_n < 10 * ROWS * nacc, "run stopped early")
    `CHECK(bank_tested_o != ACCESS || nacc == 1, "later banks not tested") `CHECK(fail_valid_o, "first failure kept")
    do_clear(); nofaults();
    // watchdog
    defcfg(); rw(A_WDOG, 100); selw(`MB_SEL_BANK, lowacc, 0); go();
    `CHECK_EQ(result_o, `MB_RES_ERROR, "run watchdog expired: ERROR") `CHECK(flag(`MB_ERR_WDOG), "WDOG flagged") `CHECK(!quiesce_o, "released"); do_clear();
    rw(A_WDOG, 0);

    // ============================================================ S14 reset in the middle of a test
    `SECTION("S14 asynchronous reset during a test");
    traffic = 1; tick(100); defcfg(); selw(`MB_SEL_BANK, lowacc, 0); cfgw(0, 0, 0, 0, 0, 0, 1); before_intr = fchk_err;
    mon_clear(); rw(A_CTRL, 32'h1); while (ops_n < 70) @(posedge clk);
    #2 rst_n = 0; tick(3); #2 rst_n = 1; tick(5);
    `CHECK(!busy_o && !done_o && !quiesce_o && !tst_active_o, "after reset: idle, nothing owned")
    `CHECK_EQ(state_o, 8'd0, "engine and arbiter in reset state")
    rr(A_CFG); `CHECK_EQ(rd_val[15:0], 16'h8000, "registers back to reset values")
    rr(A_STATUS); `CHECK_EQ(rd_val[10:8], `MB_RES_NONE, "result cleared")
    rr(A_FCOUNT); `CHECK_EQ(rd_val, 32'd0, "failure data cleared by reset")
    rr(A_ERR); `CHECK_EQ(rd_val, 32'd0, "error flags cleared by reset")
    before_acc = facc_cnt; before_intr = fchk_err; tick(4000); `CHECK(facc_cnt > before_acc, "functional traffic works after reset")
    // (the model's own counters are cleared by the reset, so the baseline is taken after it)
    // the array holds the test background unless the platform re-initialises on reset (documented, docs/01 hazard H3)
    `CHECK(fchk_err > before_intr, "WITHOUT platform re-initialisation the interrupted test leaves a dirty array (hazard demonstrated)")
    traffic = 0; tick(10); defcfg(); selw(`MB_SEL_ALL, 0, 0); go(); do_clear();
    traffic = 1; tick(100); before_intr = fchk_err; init_on_reset = 1;
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); mon_clear(); rw(A_CTRL, 32'h1); while (ops_n < 70) @(posedge clk);
    #2 rst_n = 0; tick(3); #2 rst_n = 1; tick(ROWS + 40);
    before_intr = fchk_err; tick(600);
    `CHECK_EQ(fchk_err, before_intr, "WITH platform init-on-reset the array is valid again: no new scoreboard errors")
    init_on_reset = 0; traffic = 0; tick(10);
    defcfg(); selw(`MB_SEL_ALL, 0, 0); go(); `CHECK_EQ(result_o, `MB_RES_PASS, "DUT fully functional after reset"); do_clear();

    // ============================================================ S15 RAS events
    `SECTION("S15 RAS events");
    ras_clear(); nofaults(); fault(lowacc, 0, 1, 2, 1, 0, 0, 0, 0);
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); go(); tick(20);
    `CHECK(ras_n >= 2, "first-fail event and run summary sent")
    `CHECK(ras_t[0] == 4'd2 && ras_av[0], "FIRST_FAIL: type MEM_UE with address")
    `CHECK_EQ(ras_a[0], {8'(lowacc), 24'd2}, "FIRST_FAIL address = {bank, row}")
    `CHECK(ras_i[0][31] && ras_i[0][30:28] == `MB_EVK_FIRST_FAIL, "FIRST_FAIL info marker and sub-kind")
    `CHECK_EQ(ras_i[0][27:24], `MB_CLS_1TO0_BIT, "FIRST_FAIL info: class")
    `CHECK_EQ(ras_i[0][23:16], 8'd1, "FIRST_FAIL info: bit index")
    `CHECK(ras_t[1] == 4'd2 && !ras_av[1] && ras_i[1][30:28] == `MB_EVK_SUMMARY, "SUMMARY event")
    `CHECK(ras_i[1][15:0] >= 16'd2, "SUMMARY carries the failure count")
    `CHECK_EQ(ras_corr_seen, 0, "ev_corr never asserted: MBIST corrects nothing")
    do_clear(); nofaults();
    ras_clear(); test_permit_i = 0; go(); tick(20); test_permit_i = 1;
    `CHECK(ras_n >= 1 && ras_t[0] == 4'd8, "refused start -> ILLEGAL_OP event") `CHECK_EQ(ras_i[0][23:16], 8'(`MB_ERR_NO_PERMIT), "flag number in info")
    do_clear();
    ras_clear(); no_ack = 1; defcfg(); selw(`MB_SEL_BANK, lowacc, 0); go(); tick(20); no_ack = 0;
    `CHECK(ras_n >= 1 && ras_t[0] == 4'd11, "ownership timeout -> TIMEOUT event"); do_clear(); rw(A_CTRL, 32'h20); tick(4);
    ras_clear(); rogue = 1; defcfg(); selw(`MB_SEL_BANK, lowacc, 0); go(); tick(20); rogue = 0;
    `CHECK(ras_n >= 1, "intrusion event"); j = 0; for (int k = 0; k < ras_n && k < 64; k++) if (ras_i[k][30:28] == `MB_EVK_INTRUSION) j = j + 1;
    `CHECK_EQ(j, 1, "exactly one intrusion event per episode"); do_clear();
    rr(A_RAS); `CHECK(rd_val[15:0] > 0, "RAS_STAT.sent counts events") `CHECK_EQ(rd_val[31:16], 16'd0, "no RAS events lost")
    // two events of the same kind in consecutive cycles collide in the single pending slot: COUNTED, flagged, never silent
    defcfg(); selw(`MB_SEL_BANK, lowacc, 0); mon_clear(); rw(A_CTRL, 32'h1); tick(30);
    @(posedge clk); start_i <= 1'b1; repeat (4) @(posedge clk); start_i <= 1'b0;       // 4 consecutive CMD_BUSY events
    wait_run();
    rr(A_RAS); `CHECK(rd_val[31:16] > 0, "colliding RAS events are COUNTED in RAS_STAT.lost") `CHECK(flag(`MB_ERR_RAS_LOST), "RAS_LOST flagged")
    do_clear();

    // ============================================================ S16 redundancy analysis
    `SECTION("S16 redundancy analysis (plan only)");
    begin : s16
      integer b; b = lowacc;
      defcfg(); selw(`MB_SEL_BANK, b, 0); nofaults();
      fault(b, 0, 1, 5, 1, 0, 0, 0, 0); fault(b, 1, 1, 5, 3, 0, 0, 0, 0);          // two bad cells in ONE row -> spare row
      go(); `CHECK_EQ(result_o, `MB_RES_FAIL, "row defect: FAIL")
      `CHECK(rep_ok_o[b] && !rep_unrep_o[b], "analysis: coverable")
      `CHECK(rep_row_v_o[b*SR + 0], "one spare row allocated") `CHECK_EQ(rep_row_o[(b*SR + 0)*AW +: AW], AW'(5), "...for row 5")
      `CHECK(!rep_col_v_o[b*SC +: SC], "no spare column used") `CHECK(!rep_phys_o, "physical repair NOT claimed")
      rr(A_REP_OK); `CHECK_EQ(rd_val[b], 1'b1, "REP_OK register") rr(A_REP_PHYS); `CHECK_EQ(rd_val, 32'd0, "REP_PHYS register: 0")
      rr(A_REP_ROW + 12'(4 * (b * SR))); `CHECK(rd_val[31] && rd_val[23:0] == 24'd5, "REP_ROW register window")
      do_clear();
      nofaults(); fault(b, 0, 1, 2, 4, 0, 0, 0, 0); fault(b, 1, 1, 7, 4, 0, 0, 1, 0); fault(b, 2, 1, 11, 4, 0, 0, 0, 0);   // one defective COLUMN (bit 4)
      go(); `CHECK(rep_ok_o[b], "column defect covered")
      `CHECK(rep_col_v_o[b*SC + 0] && rep_col_o[(b*SC + 0)*BITW +: BITW] == BITW'(4), "one spare column allocated for bit 4")
      `CHECK(!rep_row_v_o[b*SR +: SR], "no spare row consumed by a column defect")
      do_clear();
      nofaults();                                                                 // three bad ROWS (two bits each): 2 spare rows, then 2 spare COLUMNS
      fault(b, 0, 1, 2, 1, 0, 0, 0, 0); fault(b, 1, 1, 2, 3, 0, 0, 0, 0); fault(b, 2, 1, 5, 1, 0, 0, 0, 0);
      fault(b, 3, 1, 5, 3, 0, 0, 0, 0); fault(b, 4, 1, 9, 1, 0, 0, 0, 0); fault(b, 5, 1, 9, 3, 0, 0, 0, 0);
      go(); `CHECK(rep_ok_o[b] && !rep_unrep_o[b], "third bad row covered by spare COLUMNS once both spare rows are used")
      `CHECK(rep_row_v_o[b*SR +: SR] == 2'b11, "both spare rows used") `CHECK(rep_col_v_o[b*SC +: SC] == 2'b11, "both spare columns used")
      `CHECK(rep_col_o[(b*SC + 0)*BITW +: BITW] == BITW'(1) && rep_col_o[(b*SC + 1)*BITW +: BITW] == BITW'(3), "columns 1 and 3")
      rr(A_REP_UNREP);   `CHECK_EQ(rd_val[b], 1'b0, "REP_UNREP register") rr(A_REP_TOUCHED); `CHECK_EQ(rd_val[b], 1'b1, "REP_TOUCHED register")
      rr(A_REP_COL + 12'(4 * (b * SC))); `CHECK(rd_val[31] && rd_val[15:0] == 16'd1, "REP_COL window: valid, column 1")
      do_clear();
      nofaults();                                                                 // five independent cell defects > 2 rows + 2 columns
      fault(b, 0, 1, 1, 0, 0, 0, 0, 0); fault(b, 1, 1, 3, 1, 0, 0, 0, 0); fault(b, 2, 1, 5, 2, 0, 0, 0, 0);
      fault(b, 3, 1, 8, 3, 0, 0, 0, 0); fault(b, 4, 1, 12, 5, 0, 0, 0, 0);
      go(); `CHECK(rep_unrep_o[b] && !rep_ok_o[b], "too many defects: UNREPAIRABLE with 2 rows + 2 columns (online greedy)")
      do_clear(); nofaults();
      go(); `CHECK(rep_ok_o == '0 && rep_unrep_o == '0, "clean run: repair state cleared") do_clear();
    end

    // ============================================================ S17 pin interface
    `SECTION("S17 direct pin interface");
    cfg_from_pins_i = 1; cfg_algo_i = 0; cfg_pattern_i = 0; cfg_stripe_k_i = 0; cfg_sweep_i = 0; cfg_colsel_i = 0; cfg_stop_i = 0;
    cfg_reinit_i = 1; cfg_sel_i = `MB_SEL_BANK; cfg_bank_i = 8'(hiacc); cfg_bmask_i = '0; cfg_row_lo_i = '0; cfg_row_hi_i = AW'(ROWS - 1); cfg_wdog_i = 0;
    selw(`MB_SEL_BANK, lowacc, 0);       // the register page says another bank: pins must win
    nofaults(); fault(hiacc, 0, 1, 3, 2, 0, 0, 1, 0);
    mon_clear(); `PULSE(start_i); wait_run();
    `CHECK_EQ(result_o, `MB_RES_FAIL, "pin-configured run: FAIL") `CHECK_EQ(fail_bank_o, BW'(hiacc), "pins selected the bank, not the register page")
    `CHECK(bank_tested_o == NBANK'(1 << hiacc), "only the pin-selected bank tested") `CHECK_EQ(ops_n, 10 * ROWS, "one bank, 10N")
    `PULSE(clear_i); tick(4); `CHECK(!done_o && !fail_valid_o, "clear pin erases results")
    fault(hiacc, 0, 1, 3, 2, 0, 0, 1, 0); mon_clear(); `PULSE(start_i); wait_run(); `PULSE(fail_pop_i);
    `PULSE(abort_i); tick(4); `CHECK(done_o, "abort while idle is ignored");
    `PULSE(clear_i); tick(4); nofaults();
    mon_clear(); @(posedge clk); start_i <= 1; start_clr_i <= 1; @(posedge clk); start_i <= 0; start_clr_i <= 0; wait_run();
    `CHECK_EQ(result_o, `MB_RES_PASS, "start + start_clr pins: PASS"); `PULSE(clear_i); tick(4);
    cfg_from_pins_i = 0;

    // ============================================================ S18 register access errors
    `SECTION("S18 register access errors");
    rb_access(1'b1, A_ID, 32'h1234);        `CHECK(rd_err, "write to read-only register -> err")
    rb_access(1'b0, A_CTRL, 0);             `CHECK(rd_err, "read of write-only CTRL -> err")
    rb_access(1'b0, 12'h0F0, 0);            `CHECK(rd_err, "unmapped address -> err")
    rb_access(1'b0, 12'h002, 0);            `CHECK(rd_err, "misaligned address -> err")
    rb_access(1'b1, 12'h0F0, 32'h55);       `CHECK(rd_err, "write to unmapped address -> err")
    rb_access(1'b0, A_BCNT + 12'(4 * NBANK), 0); `CHECK(rd_err, "per-bank window past the last bank -> err")
    rr(A_ID); `CHECK_EQ(rd_val, 32'h4D425354, "state unchanged by the failed accesses")
    rw(A_ROWHI, 32'd7); rr(A_ROWHI); `CHECK_EQ(rd_val, 32'd7, "configuration register read-back")
    rw(A_WDOG, 32'h1234_5678); rr(A_WDOG); `CHECK_EQ(rd_val, 32'h1234_5678, "WDOG read-back"); rw(A_WDOG, 0);
    // W1C on a flag that is really set: only the written bit is cleared, and without using CLEAR
    defcfg(); test_permit_i = 0; go(); test_permit_i = 1;
    rr(A_ERR); `CHECK(rd_val[`MB_ERR_NO_PERMIT], "NO_PERMIT flag set by a refused start")
    rw(A_ERR, 32'(1 << `MB_ERR_BAD_CFG)); rr(A_ERR); `CHECK(rd_val[`MB_ERR_NO_PERMIT], "W1C of a DIFFERENT bit leaves the flag set")
    rw(A_ERR, 32'(1 << `MB_ERR_NO_PERMIT)); rr(A_ERR); `CHECK(!rd_val[`MB_ERR_NO_PERMIT], "W1C of the flag clears it")
    rw(A_CTRL, 32'h4); tick(4);
    rw(A_ERR, 32'h0); rb_access(1'b1, A_ERR, 32'hFFFF_FFFF); `CHECK(!rd_err, "W1C ERR_FLAGS write accepted"); rr(A_ERR); `CHECK_EQ(rd_val, 32'd0, "all flags clear")

    // ============================================================ summary
    `SECTION("global safety invariants over the whole simulation");
    `CHECK_EQ(viol_ce_unowned, 0, "no tst_ce outside (tst_active & test mode & permit)")
    `CHECK_EQ(viol_permit, 0, "no test operation without permission")
    `CHECK_EQ(viol_inflight, 0, "tst_active never overlapped an in-flight or accepted functional access")
    `CHECK_EQ(viol_quiesce, 0, "tst_active never without quiesce")
    `CHECK_EQ(viol_ack, 0, "tst_active never before the quiesce acknowledge")
    `CHECK_EQ(viol_func_in_own, 0, "no functional access accepted while quiesced")
    `CHECK_EQ(facc_in_test, 32'd0, "no functional access accepted while tst_active")

    $display("RESULT tb_sf_sram_mbist NBANK=%0d ROWS=%0d DATA_W=%0d STORE_W=%0d L=%0d TP=%0d ACCESS=%b checks=%0d errors=%0d %s",
             NBANK, ROWS, DATA_W, STORE_W, L, TP, ACCESS, checks, errors, (errors == 0) ? "PASS" : "FAIL");
    $finish;
  end

  initial begin
    #1500000000;
    $display("RESULT tb_sf_sram_mbist global timeout FAIL");
    $finish;
  end
endmodule
