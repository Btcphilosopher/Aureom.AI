# 05 - Integration with SilicaFlux (ECC, RAS, test access, clock / reset, repair)

What was **simulated together** here: `sf_sram_mbist` + the real MemoryCore `sf_sram_controller` / `sf_sram_bank` / `sf_sram_core` (ECC on and
off) - `tb_mbist_memorycore`.  Everything else below is interface compatibility established by reading the other projects' RTL and
documents, **not co-simulated**, and is labelled so.

## 1. Memory configuration recipes

| Integration | `NBANK / ROWS / DATA_W / STORE_W` | Masks |
|---|---|---|
| MemoryCore shared SRAM, ECC off | `NB / DEPTH / DW / DW` | `ACCESS = SHARED = all`, `TENSOR = VECTOR = 0` (scratchpads own no array) |
| MemoryCore shared SRAM, SECDED | `NB / DEPTH / DW / DW + R + 1` (137 for 128-bit lines, 39 for 32-bit) | same |
| A die with scratchpad macros that have a test port | one bank per macro | those banks in `TENSOR_MASK` / `VECTOR_MASK` **and** in `ACCESS_MASK` |
| ... that have **no** test port (P31 `hpc_scratchpad`) | one bank per macro | listed in the class mask, **not** in `ACCESS_MASK` -> selecting them is refused `NOT_ACCESSIBLE` |

## 2. ECC interaction - three separate things

ECC correction can hide an underlying bit fault: the decoder repairs a single stuck bit on every functional read, so functional
traffic keeps "working" while the array is defective.  (Demonstrated on the real bank: `tb_mbist_memorycore` M05 - a stuck data cell is
returned **corrected with `rsp_ce`** to a functional reader, but the raw test finds it; without ECC the same fault corrupts the data
and nothing reports it.)

| Test class | What it exercises | Status in this project |
|---|---|---|
| **Raw array tests** | the stored bits themselves: data **and check columns**, with the ECC encoder / decoder **bypassed** by the raw test bus (`tst_*` writes / reads the stored word) | **Implemented** (`COLSEL` ALL / DATA / CHECK).  Verified on the real stack: check-column defect invisible to a data-only compare (PASS), found by the full-word test (FAIL, `in_check`, index `DW + 3`) - M05; the raw bus does not touch the CE / UE counters - M02 |
| **ECC encode / decode tests** | the SECDED encoder produces valid codewords; the decoder corrects 1-bit and detects 2-bit errors | **Not implemented in this controller.**  The raw bus *can* write arbitrary codewords, so an ATE / firmware procedure exists (write data functionally; corrupt one or two stored bits through the raw bus or the RAS fault injector `sfras_fi_ctrl`; read functionally; expect `rsp_ce` / `ECC_UE`), but no hardware engine runs it here.  MemoryCore ships its own codec / system ECC testbenches (`tb_ecc_codec`, `tb_ecc_system`); they were **not re-run** in this project |
| **Protected data-path tests** | function writes / reads through the ECC path, no bypass | Not a separate engine: verified as *interaction* - functional traffic through the real ECC bank before, around and after tests (scoreboard clean), and **every line valid after the test** (re-init produces valid ECC; a never-initialised row would decode as UE) - M02 / M06 / M07 |

**Protection is never bypassed in ordinary operation.**  The raw bus is reachable only while the arbiter owns the arrays: functional
traffic is quiesced, drained and blocked first; the monitors assert no test operation outside ownership and no functional access
during it.  A destructive test leaves raw patterns with arbitrary check bits, so the array is re-initialised (`init_start`) before it
returns to service.

## 3. RAS event interface

One RAS source port (`ras_*`), same shape as every `silicaflux-ras` event port: `ev_valid` (pulse), `ev_type[3:0]`, `ev_addr[31:0]`,
`ev_addr_v`, `ev_info[31:0]`, `ev_corr` (always 0).

| Event | Type (default) | `ev_addr` | `ev_info` |
|---|---|---|---|
| first failure of a run | 2 `SFRAS_EV_MEM_UE` (hardware minimum ERROR) | `{bank[7:0], row[23:0]}`, valid | `[31]` = 1 (MBIST origin), `[30:28]` = 1, `[27:24]` class, `[23:16]` bit, `[15:13]` element, `[12]` polarity, `[11:8]` pass |
| run finished with failures | 2 | - | `[30:28]` = 2, `[15:0]` failure count |
| refused start, timeouts, permission loss, FIFO overflow ... | 8 `SFRAS_EV_ILLEGAL_OP` (WARN) / 11 `SFRAS_EV_TIMEOUT` for OWN_TIMEOUT, REINIT_TIMEOUT, WDOG | - | `[30:28]` = 3 / 4 intrusion / 5 re-init, `[23:16]` error-flag number |

Never silent: one pending slot per event kind and error flag; a request that finds its slot occupied is counted (`RAS_STAT.lost`,
flag `RAS_LOST`).  A host abort is a command, not an error, and sends no event.

**Open item.**  The RAS type table (silicaflux-ras `sfras_defs.svh`) has **no MBIST type**; the header says "never renumber, only
append".  Using `MEM_UE` mixes MBIST failures into the runtime MEM_UE counters.  The clean fix is to append e.g. `SFRAS_EV_MBIST = 13`
(and raise `SFRAS_EV_NUM_TYPES`); only the `RAS_EV_FAIL / ERR / TMO` parameters here change.  That RAS change was **not** made.

## 4. TestCore / DFTGrid / JTAG  (interface compatibility only; not co-simulated)

* **Register bus**: `rb_*` is the TestCore group-page bus.  A host reaches it through the TestCore JTAG `TC_REG` data register
  (46 bits, `{OP, ADDR[11:0], DATA[31:0]}` over the toggle-handshake bridge) or the system register port.  Because this page has
  **its own register map** (not `sftc_regs`), DFTGrid would have to map it as a group-page personality at `0x200 * (g + 1)`; that
  mapping is **not built**.
* **Mode / permission**: `test_mode_i` = TestCore global MBIST mode; `test_permit_i` = MBIST permission from the lifecycle policy;
  `mem_inhibit_i` = DFTGrid `dft_mem_inhibit` (scan mode: random scan states must never write a macro).  Losing any of them during a run
  hard-stops the engine and releases the memory re-initialised.
* **Protect / halt**: `protect_i` / `cpu_halted_i` follow the TestCore `PROTECT` rule (a bank holding live CPU state is refused unless the CPU is halted).
* **Status pins**: `done_o / pass_o / fail_o` map to the DFTGrid `TEST_DONE / TEST_PASS / TEST_FAIL` pins.
* **Not provided**: JTAG instructions of its own, ATPG / scan interaction ("RAM sequential" models, scan bypass), a TestCore-style
  algorithm set (walking patterns, checkerboard-only runs).

## 5. Clock / reset

* `clk_req_o` (high from QUIESCE to the end of re-init) is the request for the memory's clock branch (P35 `br_clk_req_i`): the MBIST runs on the
  **memory's own clock** (no clock crossing, at functional speed).  The P35 clock tree was **not** simulated with it.
* Asynchronous active-low reset on every flop (repository style `always_ff @(posedge clk or negedge rst_n)`).  Reset clears the arbiter, the engine,
  all configuration and **all failure data**.  Reset in the middle of a test therefore cannot remember that the array is dirty:
  ECC builds of `sf_sram_controller` re-initialise on reset (`INIT_ON_RESET`), non-ECC builds do not (hazard H3, demonstrated both ways).

## 6. Redundancy analysis ("repair research") - ANALYSIS ONLY

* **What exists**: `sf_mbist_repair` (parameter `REPAIR_EN`) folds every miscompare into per-bank spare-row / spare-column allocation with
  a greedy rule (docs in the file header) and exports a **repair map**, `rep_ok / rep_unrep` (validity) per bank.  Sound by construction: `rep_ok`
  only if every *observed* failing (row, bit) is covered by an allocated spare.
* **What does not exist**: **physical repair.**  None of the repository's SRAM macros has spare rows / columns or a repair-load interface (OpenRAM SKY130,
  IHP / GF180 leaves, FPGA BRAM, behavioural arrays; MemoryCore `KNOWN_LIMITATIONS` 6).  `rep_phys_o` / `REP_PHYS` is tied to the parameter
  `REDUNDANCY_PRESENT` (0).  The map is a **plan**.
* **Limits**: online greedy, not optimal (can declare a pattern unrepairable that an offline must-repair + branch-and-bound allocator could repair);
  sees only failures the engine observed (algorithm-masked faults and anything after a stop-on-fail are not in the map); one decision per event.
* **To claim physical repair** one would need a macro with redundancy, its repair-load interface (fuses or soft repair), a flow that applies the map and re-tests,
  and measurements on that macro.  None is claimed.
