# 03 - Interface: register page, pins, preservation contract

## 1. Register page (`sf_mbist_regs`)

12-bit byte address, 32-bit registers, word aligned, **zero wait states**: `rb_gnt = rb_req`; `rb_rdata` / `rb_err` are valid in the same
cycle as the request (combinational read), a write takes effect at the clock edge.  The bus is the TestCore group-page bus
(`sftc_regs`: `req / we / addr / wdata -> gnt / rdata / err`).  An access that is misaligned, unmapped, a write to a read-only
register or a read of the write-only `CTRL` returns `rb_err = 1`, reads as 0 and **changes nothing**.
(The page has its own map: it is *not* the `sftc_regs` register map; see `docs/05_integration.md` section 4.)
Access types: RO, RW, WO (write-one pulses), W1C.  The table below is checked against the RTL by `sim/run_regress.py`.

| Address | Name | Acc | Reset | Fields |
|---|---|---|---|---|
| `0x000` | ID | RO | `0x4D425354` | "MBST" |
| `0x004` | REV | RO | `0x00780001` | [31:16] project 0x0078, [15:0] release |
| `0x008` | CAPS0 | RO | - | [7:0] NBANK, [15:8] ROW_W, [23:16] DATA_W, [31:24] STORE_W |
| `0x00C` | CAPS1 | RO | - | [3:0] LT (= READ_LATENCY + TEST_PIPE), [7:4] FIFO_DEPTH, [11:8] SPARE_ROWS, [15:12] SPARE_COLS, [16] REPAIR_EN, [17] REDUNDANCY_PRESENT |
| `0x010` | CAPS2 | RO | - | ROWS |
| `0x014` | ACCESS_MASK | RO | - | banks with a raw test port |
| `0x018` | SHARED_MASK | RO | - | banks of the shared SRAM |
| `0x01C` | TENSOR_MASK | RO | - | banks backing tensor scratchpads |
| `0x020` | VECTOR_MASK | RO | - | banks backing vector scratchpads |
| `0x030` | CTRL | WO | - | pulses: [0] START, [1] ABORT, [2] CLEAR, [3] POP, [4] START_CLR (start and erase unread results), [5] CLR_FAULT |
| `0x034` | CFG | RW | `0x00008000` | [3:0] ALGO (0 March C-, 1 MATS+), [6:4] PATTERN (0 ALL0, 1 ALL1, 2 ALT, 3 CHECKER, 4 ADDR, 5 STRIPE), [10:7] STRIPE_K, [11] SWEEP, [13:12] COLSEL (0 ALL, 1 DATA, 2 CHECK), [14] STOP_ON_FAIL, [15] REINIT_EN |
| `0x038` | SELECT | RW | `0x00000002` | [2:0] mode (0 BANK, 1 SEQ, 2 ALL, 3 SHARED, 4 TENSOR, 5 VECTOR), [15:8] BANK_IDX |
| `0x03C` | BANK_MASK | RW | all ones | banks of mode SEQ |
| `0x040` | ROW_LO | RW | 0 | window start (32 bit: an out-of-range value is refused, never wrapped) |
| `0x044` | ROW_HI | RW | ROWS-1 | window end (inclusive) |
| `0x048` | WDOG_LIMIT | RW | 0 | run watchdog in cycles, 0 = off |
| `0x050` | STATUS | RO | 0 | [0] busy [1] done [2] pass [3] fail [4] aborted [5] error [6] refused [7] unread results [10:8] result (MB_RES_*) [15:12] engine state [19:16] arbiter state [20] own_ok [21] tst_active [22] quiesce [23] clk_req [24] FIFO head valid [25] first record valid |
| `0x054` | ERR_FLAGS | W1C | 0 | sticky: see section 3 |
| `0x058` | BANK_TESTED | RO | 0 | banks completed |
| `0x05C` | BANK_FAILED | RO | 0 | banks with at least one miscompare |
| `0x060` | FAIL_COUNT | RO | 0 | failing compares, 32-bit saturating |
| `0x064` | FIFO_STAT | RO | 0 | [7:0] entries, [23:16] lost (overflow), [31] head valid |
| `0x068` | PROGRESS | RO | - | [7:0] bank, [11:8] pass, [14:12] March element |
| `0x06C` | CUR_ADDR | RO | - | current row |
| `0x070` | CYCLES | RO | - | cycles of the current / last run |
| `0x074` | INTRUSION_CNT | RO | 0 | cycles with a functional request accepted / presented after the acknowledge while owned (16 bit sat.) |
| `0x078` | RAS_STAT | RO | 0 | [15:0] events sent, [31:16] events lost |
| `0x07C` | ARB_STAT | RO | - | [3:0] arbiter state (0 IDLE .. 8 FAULT), [4] quiesce, [5] tst_active, [6] own_ok, [7] clk_req |
| `0x080` | COL_FAIL | RO | 0 | 5 words (0x080..0x090): columns that ever failed in the run (OR of all syndromes) |
| `0x0A0` | FF_ADDR | RO | - | first failure: [23:0] row, [31:24] bank |
| `0x0A4` | FF_BIT | RO | - | [15:0] lowest failing bit, [16] bit_valid (exactly one bit), [17] in_check |
| `0x0A8` | FF_OP | RO | - | [2:0] March element, [3] op index, [4] expected polarity, [11:8] pass, [15:12] class, [31:16] alias row |
| `0x0AC` | FF_VALID | RO | 0 | [0] a first record exists |
| `0x0B0` | FF_EXP | RO | - | expected word, 5 words (0x0B0..0x0C0) |
| `0x0D0` | FF_OBS | RO | - | observed word, 5 words (0x0D0..0x0E0) |
| `0x100` | HD_ADDR | RO | - | FIFO head record: same layout as FF_ADDR |
| `0x104` | HD_BIT | RO | - | same as FF_BIT |
| `0x108` | HD_OP | RO | - | same as FF_OP |
| `0x10C` | HD_VALID | RO | 0 | [0] FIFO not empty |
| `0x110` | HD_EXP | RO | - | 5 words |
| `0x130` | HD_OBS | RO | - | 5 words |
| `0x200` | BANK_FAILCNT | RO | 0 | `0x200 + 4*bank`: 16-bit saturating failing compares of that bank |
| `0x300` | REP_OK | RO | 0 | banks whose observed failures are all covered by the allocation (analysis only) |
| `0x304` | REP_UNREP | RO | 0 | banks whose failures exceed the spares |
| `0x308` | REP_TOUCHED | RO | 0 | banks with at least one failure |
| `0x30C` | REP_PHYS | RO | 0 | [0] physical redundancy + repair load exists (**0 for every macro in the repository**) |
| `0x340` | REP_ROW | RO | 0 | `0x340 + 4*(bank*SPARE_ROWS + i)`: [31] valid, [23:0] row |
| `0x3C0` | REP_COL | RO | 0 | `0x3C0 + 4*(bank*SPARE_COLS + j)`: [31] valid, [15:0] column |

Reset values of everything else are 0.  A register block bigger than the limits (`STORE_W > 160`, `NBANK > 32`) fails elaboration.

## 2. Pins (`sf_sram_mbist`)

| Group | Signals |
|---|---|
| command (pulses) | `start_i`, `start_clr_i`, `abort_i`, `clear_i`, `fail_pop_i`, `clr_fault_i` |
| configuration | `cfg_from_pins_i` = 1 selects `cfg_algo_i, cfg_pattern_i, cfg_stripe_k_i, cfg_sweep_i, cfg_colsel_i, cfg_stop_i, cfg_reinit_i, cfg_sel_i, cfg_bank_i, cfg_bmask_i, cfg_row_lo_i, cfg_row_hi_i, cfg_wdog_i`; 0 selects the register values (the same fields, same encodings) |
| test-access context | `test_mode_i`, `test_permit_i`, `mem_inhibit_i`, `cpu_halted_i`, `protect_i[NBANK]` |
| status | `busy_o`, `done_o` (held from completion until the next start / clear), `pass_o`, `fail_o`, `error_o`, `result_o[2:0]`, `bank_tested_o`, `bank_fail_mask_o`, `err_flags_o`, `state_o` |
| failure report | `fail_valid_o`, `fail_bank_o`, `fail_row_o` (**failed address**), `fail_bit_o`, `fail_bit_v_o`, `fail_in_check_o`, `fail_elem_o`, `fail_op_o`, `fail_pol_o`, `fail_pass_o`, `fail_cls_o`, `fail_alias_o`, `fail_exp_o` (**expected data**), `fail_obs_o` (**observed data**), `fail_count_o` |
| memory group | see `docs/01` section 4 |
| register bus | `rb_req, rb_we, rb_addr[11:0], rb_wdata[31:0] -> rb_gnt, rb_rdata[31:0], rb_err` |
| RAS event port | `ras_valid_o, ras_type_o[3:0], ras_addr_o[31:0], ras_addr_v_o, ras_info_o[31:0], ras_corr_o` |
| redundancy analysis | `rep_row_v_o, rep_row_o, rep_col_v_o, rep_col_o, rep_ok_o, rep_unrep_o, rep_phys_o` (zero when `REPAIR_EN = 0`) |

A start from either path is accepted only while idle; a `START` or `CLEAR` during a run is ignored and flagged `CMD_BUSY`.  An
`abort_i` while idle is ignored, and so is one that arrives once the engine is already releasing the memory (nothing is left to abort; a
completed run keeps its result).

## 3. Sticky error flags (`ERR_FLAGS`, bit numbers)

| Bit | Name | Meaning |
|---|---|---|
| 0 | NO_PERMIT | start refused: test mode / permission absent, or memory inhibit |
| 1 | BAD_CFG | start refused: invalid configuration |
| 2 | EMPTY_SEL | start refused: selection resolves to no bank |
| 3 | NOT_ACCESSIBLE | start refused: selection includes a bank without a raw test port |
| 4 | PROTECTED | start refused: protected bank while the CPU runs |
| 5 | RESULT_PENDING | start refused: unread failure data (CLEAR, or START_CLR) |
| 6 | CMD_BUSY | START / CLEAR during a run (ignored) |
| 7 | OWN_TIMEOUT | quiesce / drain timed out (arbiter FAULT) |
| 8 | REINIT_TIMEOUT | re-initialisation did not complete: **content undefined** |
| 9 | PERM_LOSS | permission lost during a run |
| 10 | INTRUSION | functional request accepted / presented after the acknowledge while owned (blocked) |
| 11 | WDOG | run watchdog expired |
| 12 | REINIT_REQ | released dirty without re-initialisation: software must initialise |
| 13 | FIFO_LOST | failure FIFO overflowed (first record and counters still exact) |
| 14 | RAS_LOST | RAS event could not be queued (counted) |
| 15 | ABORTED | run aborted by command |
| 16 | INTERNAL | consistency check failed (never expected) |

Flags are set by 1-cycle events, cleared by a `W1C` write (a simultaneous new event wins) or by `CLEAR` (only while idle) or reset.

## 4. Preserving diagnostic information (documented interface)

* The **first record**, **FIFO**, **counters**, per-bank counts, `BANK_FAILED` and `COL_FAIL` are held until **`CLEAR`** (or an accepted
  `START` / `START_CLR`, which clears them as it begins) or **reset**.  They survive `done`, idle time and **any number of reads**.
* `POP` advances only the FIFO read pointer.  The first record, `FAIL_COUNT` and the masks are **not** consumed by it.
* The FIFO keeps the **first** `FIFO_DEPTH` failures; later ones are *not stored* and counted in `lost` (flag `FIFO_LOST`); `FAIL_COUNT`
  and the first record stay exact (invariant: entries + lost == failing compares while nothing is popped).
* A new `START` while unread failure data exists is **refused** (`RESULT_PENDING`) and the data is untouched; `START_CLR` is the explicit
  "erase and run".  Reproducibility: re-running the same configuration on the same fault yields the identical first record and
  count (checked on a sample in every coverage campaign).
