# 00 - Repository audit (SilicaFlux Project 78, MemoryTest)

Scope: what the `btcphilosopher/Aureom.AI` repository already contains for SRAM, ECC, test access, RAS and clock / reset, and
what that implies for an SRAM MBIST controller.  Everything below was read in the nested project archives under
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` (and `SilicaFlux-main/`); nothing was inferred from a project's name.
Labels: **READ** = I read the file; **RUN** = I built and simulated it; **NOT FOUND** = searched, absent.

## 1. Inventory

| Requested item | Where it lives | Status |
|---|---|---|
| SRAMCore | `silicaflux-sramcore-p71.zip` (SRAM core), and the `sf_sram_core` of `silicaflux-memorycore-sram.zip` | READ. `sf_sram_core`: 1RW synchronous array, `READ_LATENCY >= 1`, array never reset, **simulation-only fault models** (`FAULT_INJECT = 1`, `SF_FT_*`) |
| SRAMBank | `silicaflux-srambank-p72.zip`, `sf_sram_bank` of MemoryCore | READ. Request / response wrapper, optional SECDED(137,128), init engine, opportunistic scrubber, **raw MBIST test port** (`tst_*`, tests the STORED word incl. check bits) |
| SRAMController | `silicaflux-sramcontroller-p73.zip`, `sf_sram_controller` of MemoryCore | READ + RUN. NM masters x NB banks; **`quiesce_i` / `idle_o` / `init_start_i` / `init_busy_o` and a collar-compatible raw test bus (`tst_active_i`, `tst_sel_i[NB]`, ...)** already exist for exactly this purpose |
| ECCMemory | `silicaflux-ecccore-p54.zip` (storage-controller ECC: BCH / LDPC for NAND), `sf_ecc_enc/dec` + `silicaflux-ras-project26.zip` (`sfras_secded_*`, `sfras_ecc_sram`) | READ. The SRAM ECC is the **RAS-project SECDED** wrapped by MemoryCore.  P54 is flash ECC and is not an SRAM path |
| TestCore | `silicaflux-testcore.zip` (`tc_*`), `silicaflux-testcore-p07.zip` (`sftc_*`, the newer one) | READ. TAP + register bridge + mode controller + a **per-bank MBIST engine with ownership FSM (`sftc_mem_owner`)** and a collar bus contract |
| DFT grid | `silicaflux-dftgrid-p39.zip` | READ. Wraps TestCore: test-mode arbitration, sequencer, clock / reset test modes, MBIST integration doc incl. a **memory inventory with which memories have a raw test bus** |
| JTAG | `sftc_jtag_tap`, `sftc_jtag_reg_bridge` (TestCore p07), `sf_test_ras` (P40 stand-in TAP) | READ. `TC_REG` = 46-bit DR {OP, ADDR[11:0], DATA[31:0]} through a toggle-handshake CDC bridge onto a **12-bit-address, 32-bit register bus** (`req/we/addr/wdata -> gnt/rdata/err`) |
| RAS | `silicaflux-ras-project26.zip` | READ. Per-source event port `ev_valid / ev_type[3:0] / ev_addr / ev_addr_v / ev_info / ev_corr`; counters, log, first-error capture; **no MBIST event type exists** (types 1..12) |
| Clock / reset | `silicaflux-clocktree-p35.zip`, DFTGrid doc 07 | READ (docs). `mbist_clk_req[g]` -> `br_clk_req_i[b]` opens a gated branch for MBIST; `dft_mem_inhibit` stops macro writes during scan; reset syncs switch to `test_rst_ni` in scan |
| Existing MBIST hardware | see section 2 | READ + RUN (MemoryCore's pieces rebuilt and run here) |

## 2. Existing MBIST hardware (and what this project does with it)

| Piece | What it does | Limits observed (READ) |
|---|---|---|
| `sram_mbist_march` (sramlib P01, reused byte-identical by MemoryCore) | March C- (10N) / MATS+ (5N), solid or checkerboard, serial over targets, compare at `READ_LATENCY`, first-failure record (target, element, address, syndrome), `stop_on_fail` | No ownership / quiesce, no abort, no timeout, no permission input, one background per run, no diagnostic FIFO |
| `sf_sram_mbist_ctl` (MemoryCore) | wraps the engine: QUIESCE (wait `idle_i` x2) -> RUN -> REINIT -> DONE | **No timeout on the quiesce wait** (waits forever); no abort; fixed 32-cycle re-init timeout; `fail_target` of the engine is **left unconnected, so the bank id of the first failure is not exported** (only a per-bank fail mask); no permission / protect input |
| `sftc_mbist_*` + `sftc_mem_owner` (TestCore p07) | per-bank engine with ownership FSM, fail log, many algorithms; register page `sftc_regs` | Separate register map and a different bank interface (`t_req/t_gnt/t_rvalid`); not driven by the SRAM collar bus of MemoryCore directly |
| MemoryCore coverage campaign | measured March C- coverage of its own fault models: 100 % cell / address / inter-word coupling, **80.65 % same-word coupling** with {solid, checkerboard} | its own limitation note: four same-word coupling classes ~51 % |

**Decision.** `sf_sram_mbist` targets the **MemoryCore memory-side contract** (`sf_sram_controller`: quiesce / idle / init / raw test
bus), because that is the SRAM stack that exists with a raw test port and was verified end to end here.  It adds what the above
lacks: a real test-mode **arbiter** (timeouts, permission, abort, intrusion accounting, re-init handshake), **per-run diagnostic
storage** (first record, FIFO, counters, classification, bank id), **selection** of banks / shared / tensor / vector memories
with an explicit accessibility check, a **background sweep** that closes the same-word coupling gap, a RAS port, a register
page, and an optional redundancy-analysis block.  It reuses the same March definitions (so results are comparable) and the
same fault-type numbering (`SF_FT_*`) in its verification model.

## 3. Which memories are physically accessible to an MBIST controller

Source: DFTGrid `docs/05_MBIST.md` section 1 (memory inventory of the die), MemoryCore sources, and this project's own runs.

| Memory | Raw test bus? | Consequence for `sf_sram_mbist` |
|---|---|---|
| **Shared SRAM** = banks of `sf_sram_controller` (MemoryCore) | **Yes** (`tst_*`, per-bank `tst_sel`, stored word incl. ECC check bits) | Fully supported. Verified on the real RTL (`tb_mbist_memorycore`) |
| `sf_tensor_scratchpad` / `sf_vector_scratchpad` (MemoryCore) | They own **no array**: ownership / alias logic over **lines of the shared banks** | There is no separate physical memory to test.  They are covered by testing the shared banks.  In that integration `TENSOR_MASK = VECTOR_MASK = 0`, and selecting them is **refused as an empty selection** (never a false pass) |
| P31 die tensor operand / accumulator buffers, vector-tile scratchpads (`hpc_scratchpad`, `hpc_spm_bank`) | **No** - "generic memories, no test mux" (DFTGrid doc 05) | Not testable until the bank gets a test port.  Listing such a bank in `TENSOR_MASK` / `VECTOR_MASK` but not in `ACCESS_MASK` makes the selection **refused with `NOT_ACCESSIBLE`** (default configuration of the system testbench, section S03) |
| P33 SRAM grid (distributed regions) | Yes | Connected through DFTGrid / TestCore's own engine, not through this module |
| ControlCore IMEM / DMEM (`mcu_sram_bank`) | Port exists but **tied off** inside the ControlCore | Not accessible (needs the ControlCore to export it) |
| Boot ROM, small flop-based queues | No (ROM) / scan covers flops | Not applicable |

`ACCESS_MASK`, `SHARED_MASK`, `TENSOR_MASK`, `VECTOR_MASK` are elaboration parameters; the register page exposes them read-only so
a host can ask the hardware what it can test.

## 4. Findings that shaped the design

1. **The memory contract already exists** (`quiesce_i / idle_o / init / tst_*`).  The MBIST must follow it exactly, including
   that `tst_rdata` is valid exactly `READ_LATENCY` cycles after the accepting edge and is *never held*, and that `idle_o`
   goes low during test operations themselves (so "idle" can only be demanded at the moment ownership is taken).
2. **MBIST is destructive and ECC makes it worse**: raw patterns carry arbitrary check bits, so the array must be re-initialised
   (`init_start_i`) before functional use; a controller that skips it hands out words that decode as uncorrectable.
3. **`req_ready` back-pressure is not intrusion.**  A legitimate master stalled by `quiesce_i` keeps `valid` high.  The arbiter's
   intrusion probe is therefore defined on *accepted* requests (or on valid after a quiesce acknowledge), not on raw `valid`
   (found while writing the real-stack testbench; `docs/01` section 4).
4. **No MBIST RAS type exists**; the RAS header is append-only (`docs/05` section 5).
5. **Simulator caveat**: Verilator 5.020's default build mis-simulates MemoryCore's simulation-only CFST read-view in the
   integrated build (`docs/06` section 5).  Found by running two simulators and then isolating it.
6. **Redundancy does not exist anywhere in the repo's SRAM macros** (OpenRAM SKY130 / IHP / GF180 leaves, FPGA BRAM, behavioural
   arrays): MemoryCore `KNOWN_LIMITATIONS` item 6.  The repair interface of this project is analysis only.

## 5. What was reused unmodified

`third_party/silicaflux-memorycore-sram/` holds 15 MemoryCore files (11 RTL + 4 SECDED leaf codec) copied **byte-identical** (SHA-256 in `SHA256SUMS`,
provenance in `PROVENANCE.md`) so the integration testbench builds standalone.  Nothing in `third_party/` is part of the new-RTL
claim; the new RTL is `rtl/`.
