# 07 - Limitations, open items, next actions

Read this before relying on anything in the package.  Items are ordered by how much they could mislead.

## Not claimed / not done

1. **No silicon data of any kind.**  Every result is RTL simulation (Verilator 5.020, Icarus 12).  The only synthesis step is a Yosys 0.33 *generic* `synth` smoke test (elaborates, no inferred latch; 10 619 / 20 325 generic cells at two parameter sets - **not** an area figure: no technology mapping).  Nothing was placed, timed, formally
   verified, CDC-checked, power-analysed or run on an FPGA; none of those tools is installed in the build environment.  There is no area, timing or
   power number for this module.
2. **Fault coverage is coverage of a behavioural fault-model population**, measured exhaustively on small instances (4 x 8, 4 x 32 cells).  It is
   **not** silicon defect coverage and not a DPPM claim.  Not modelled, therefore unmeasured: data retention (the controller has no pause /
   retention element), read-disturb, write recovery, stuck-open, bit-line / sense-amplifier, neighbourhood pattern-sensitive, multi-cell / bridging
   other than the listed classes, resistive and at-speed faults, soft errors.  "Checkerboard" is logical, not physical.  The sweep's 100 % same-word coupling
   is shown at 8 and 32 columns only.
3. **No physical repair.**  The redundancy block is analysis.  No SRAM macro in the repository has spare rows / columns or a repair load interface.  The
   allocator is an online greedy heuristic, not optimal, and sees only what the engine observed.
4. **Only the MemoryCore memory-side contract was integrated and simulated** (`sf_sram_controller` / `sf_sram_bank`).  TestCore, DFTGrid, the JTAG TAP,
   the RAS event controller and the P35 clock tree were read, not co-simulated with this module.  The register page has its own map and would need a
   DFTGrid group-page personality (not built).  The RAS type table has no MBIST type (`MEM_UE` is used; append-only RAS change not made).
5. **ECC encode / decode and "protected data path" tests are not hardware engines here.**  The raw array test (data and check columns) is implemented and
   verified on the real ECC bank; the codec itself is verified by MemoryCore's own testbenches, which were **not re-run** in this project.
6. **Non-destructive (save / restore) test: not implemented.**  Every test is destructive and ends in a re-initialisation.
7. **A reset in the middle of a test leaves the array dirty** unless the platform re-initialises on reset (ECC builds of the controller do; non-ECC
   builds do not).  This block cannot remember across a reset.  An `INIT_AFTER_RESET` option was considered and not built (hazard H3).
8. **All banks of one instance share `ROWS` and `STORE_W`; one instance = one quiesce / idle / init domain.**  `STORE_W <= 160`, `NBANK <= 32`.  No parallel-bank mode (peak
   power is bounded by running banks one at a time; test time is not optimised).
9. **Intrusion detection is a probe, not a guarantee**: it counts functional requests accepted (or presented after a quiesce acknowledge) while the memory is
   owned.  Blocking itself is the memory group's job (`req_ready = 0` while `quiesce_i`).  If the group's quiesce were broken, the arbiter would count the leak
   but could not stop it.

## Tool and method findings (details in `docs/06` section 5)

10. **Verilator 5.020 default (optimised) builds mis-simulate MemoryCore's vendored, simulation-only fault model** (CFST read-view) for a 39-bit stored word
    in the integrated build; `-O0` and Icarus agree with each other and with the analysis.  The real-stack regression therefore builds Verilator at `-O0`.  Not
    reduced to a Verilator bug report.
11. Icarus 12 prints `constant selects in always_* are not currently supported` notices for `sf_mbist_regs.sv` (conservative sensitivity; results identical in both simulators).
12. Mutation testing uses a hand-written mutant list; a full kill count says nothing about bugs nobody thought to inject.  Two mutants survive and are
    documented as equivalent (`reports/mutation.md`).
13. Several guards cannot be exercised in feasible simulation and are **not** covered: the 32 / 16-bit counter saturation branches, `default:` recovery states, the
    `INTERNAL` consistency check, and three one-cycle windows (permission loss / abort exactly in `OWN1`, `BSEL`, `PINIT`).  `reports/code_coverage.md` lists every statement no run reached.

## Next actions (ordered)

1. Technology-map the nine RTL files (the generic Yosys smoke test already passes) and report area for a realistic `FIFO_DEPTH` / `STORE_W`; run timing and CDC checks on the
   register bus path if it is bridged from TCK.
2. Add the register page as a DFTGrid group-page personality and co-simulate with the TestCore JTAG bridge (`TC_REG`) and the P35 clock tree.
3. Append `SFRAS_EV_MBIST` to the RAS type table and co-simulate with `silicaflux_ras` (severity, counters, log, first-error capture).
4. Decide the reset-in-test policy for non-ECC memories (platform init-on-reset, or an `INIT_AFTER_RESET` sweep in this block).
5. If a macro with redundancy is ever chosen: define its repair-load interface, replace the greedy allocator by an offline must-repair allocator, and add
   an apply-and-retest sequence.  Until then keep `REDUNDANCY_PRESENT = 0`.
6. Retention / pause elements and data-retention tests (a wait state between march elements) if a process-level retention risk is identified.
7. Parallel-bank testing with a documented power budget.
8. Report the Verilator 5.020 behaviour (docs/06 section 5) upstream with a reduced reproducer.
