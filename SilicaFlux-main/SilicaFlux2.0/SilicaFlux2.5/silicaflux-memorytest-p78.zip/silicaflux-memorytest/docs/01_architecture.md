# 01 - Architecture

MBIST is a manufacturing / diagnostic feature.  It is not a replacement for functional verification and it never changes what a
functional master sees when no test is running.

## 1. Block diagram

```
                     register page (rb_*)            pins (start/abort/clear/pop, cfg_* when cfg_from_pins_i)
                            |                                   |
                      sf_mbist_regs  ---- cfg / pulses -------> mux ----+
                            ^   (ERR_FLAGS W1C, status, records)         |
                            |                                           v
   test_mode_i / test_permit_i / mem_inhibit_i / protect_i / cpu_halted_i --> sf_mbist_fsm  (engine)
                                                                          |  own_req / own_ok / own_idle / dirty / reinit_en
   sf_mbist_addr_seq  <----(load, step, window)------------------------- |
   sf_mbist_pattern x2 (issue side, compare side) <---------------------- |
                                                                          v
                                    sf_mbist_arbiter  (exclusive ownership, quiesce/drain/confirm/release/re-init)
                                       |  quiesce_o, init_start_o, tst_active_o     ^ quiesce_ack_i, idle_i, init_busy_i, func_req_i
                                       v                                           |
   engine test bus: tst_sel/ce/we/addr/wdata ---(gated by tst_active_o)--->  memory group (sf_sram_controller)
   compare:  tst_rdata_i  (LT cycles after the issue)
        |
        v  f_valid / bank / row / elem / op / pol / pass / exp / obs
   sf_mbist_failreg  (first record, FIFO, counters, classification) --> registers, pins, sf_mbist_ras_if --> RAS event port
        |                                                         \--> sf_mbist_repair (optional analysis)
```

Files (all `rtl/`): `sf_sram_mbist.sv` (top), `sf_mbist_fsm.sv`, `sf_mbist_addr_seq.sv`, `sf_mbist_pattern.sv`,
`sf_mbist_arbiter.sv`, `sf_mbist_failreg.sv`, `sf_mbist_regs.sv`, `sf_mbist_ras_if.sv`, `sf_mbist_repair.sv`, `sf_mbist_defs.svh`.
Verification-only (`verif/models/`): `sf_mbist_fault_mem.sv`, `sf_mbist_sram_sys.sv`.

## 2. Test-mode arbiter and exclusive ownership (`sf_mbist_arbiter`)

One arbiter per memory group (one quiesce / idle / init domain).  Destructive tests require exclusive ownership; **normal operation
and a destructive MBIST sequence are never active together**.

```
IDLE --own_req & permit--> QUIESCE --quiesce_ack--> DRAIN --idle for IDLE_CONSEC cycles (while ack)--> OWN1 --> OWNED
  ^                           |timeout                |timeout                                        (tst_active, own_ok)
  |                           v                       v                                                    | !own_req | !permit
  +---(re-init done)--- REINIT_WAIT <-- REINIT <-(dirty & reinit_en)-- REL0 <------------------------------+
                                                       \--(clean, or re-init disabled: REINIT_REQ)--> IDLE            FAULT
```

| Step | Requirement | How it is met | Evidence |
|---|---|---|---|
| Stop new functional accesses | `quiesce_o` high from QUIESCE on, held to the end of re-init | state decode | monitor `tst_active && !quiesce` = 0 |
| Drain / safely cancel | outstanding transactions are **drained, never cancelled** (their responses are delivered) | wait for `idle_i` for `IDLE_CONSEC` (default 2) consecutive cycles *and* the acknowledge | monitor: `tst_active` never with in-flight / accepted functional access; mutants R01 R06 killed |
| Confirm ownership | acknowledge + drained, then one OWN1 cycle with `tst_active_o` but no test op; `own_ok_o` one cycle later | state machine | monitor: never `tst_active` before `quiesce_ack` |
| Disable conflicting users | quiesce held for the whole ownership; engine issues only in a cycle with `own_ok_i & permit_i & no halt` | issue gate | `tst_ce` outside `tst_active & permit` = 0 (monitor); mutants F05 R06 killed |
| Release | engine drops `own_req_o`; `tst_active_o` falls in REL0; if the engine wrote the array: `init_start_o`, wait *busy seen, then idle*; only then `quiesce_o` falls | REL0 / REINIT / REINIT_WAIT | scoreboard: functional reads after a test equal the reference (re-initialised); with re-init disabled the scoreboard **does** fail (the check can fail) |
| Timeouts | `OWN_TIMEOUT` (QUIESCE+DRAIN), `INIT_GRACE` / `INIT_TIMEOUT` | FAULT state: port back to functional, sticky until `clr_fault_i` | S12 (no ack, no idle, no init, slow init) |
| Permission loss | `permit_i` low in OWN1/OWNED forces REL0 at once; `hold_q` blocks a restart until `own_req_i` drops | | S13: no test op after the drop; array re-initialised |
| Intrusion | a functional request ACCEPTED, or presented after the quiesce acknowledge, is counted (`intrusion_cnt_o`) with one `INTRUSION` RAS event per episode; **the group blocks it** | see 4 | S11 rogue master |

`quiesce_ack_i`: tie to 1 for a memory whose quiesce is immediate (`sf_sram_controller`: `m_req_ready` depends combinationally
on `quiesce_i`).  Drive it from the masters if they must complete a handshake first.

## 3. Engine (`sf_mbist_fsm`)

`IDLE -> CHECK -> ACQ -> BSEL -> PINIT -> RUN -> DRAIN -> BEND -> (BSEL | PINIT | REL) -> FIN -> IDLE`.

* `CHECK` validates the start and **refuses** it (result `REFUSED`, memory never requested) for: no test mode / permission / inhibit,
  invalid configuration (unknown algorithm / pattern / column select / selection mode, bank index out of range, window inverted or
  beyond `ROWS`), empty selection, a selected bank without a raw test port, a protected bank while the CPU runs, or unread
  failure data.  The row-window registers are 32 bit so an out-of-range value is refused, **never silently wrapped**
  (a wrap was found and fixed during verification).
* One test operation per cycle.  `tst_sel_o` holds the current bank one-hot; banks are tested one after another in ascending order
  (bounds peak test power).  A bank counts as tested only when its last pass completed.
* Result priority `REFUSED > ERROR > ABORTED > FAIL > PASS`.  **PASS additionally requires every selected bank to be tested**:
  a run that stopped for any reason can never report PASS.
* An **abort that arrives once the engine is already releasing the memory is ignored** (nothing is left to abort, a completed run keeps its result).
* `halt` (abort, watchdog, stop-on-fail, permission loss, ownership loss) stops issuing in the next cycle; reads already in flight
  are still compared (so `fail_count` is deterministic and reproducible).

### Read timing

`tst_rdata` is valid exactly `LT = READ_LATENCY + TEST_PIPE` cycles after the accepting edge and is not held.  A read issued in
cycle *t* is compared in cycle *t + LT*; the expected word is regenerated from (pattern, row, polarity) at the compare stage, so no
wide expected-data pipeline exists.  `DRAIN` waits `LT` cycles before a bank / pass boundary.  Verified for `LT` = 1 .. 4.

## 4. Interface contract to `sf_sram_controller`

| MBIST pin | Controller pin | Notes |
|---|---|---|
| `quiesce_o` | `quiesce_i` | refuses new requests, immediately |
| `idle_i` | `idle_o` | **low while test operations are in flight** (they are bank accesses), so idle is only demanded when ownership is taken |
| `init_start_o` / `init_busy_i` | `init_start_i` / `init_busy_o` | `init_busy_o` rises one cycle after the pulse (init is *pending* first); the arbiter waits "busy seen, then idle" |
| `tst_active_o, tst_sel_o, tst_ce_o, tst_we_o, tst_addr_o, tst_wdata_o` | same names | `tst_wdata` is the **stored word** (STORE_W = DW + ECC bits) |
| `tst_rdata_i` | `tst_rdata_o` | bank-major, `NB * STORE_W` |
| `func_req_i` | `|(m_req_valid & m_req_ready)` | **accepted** functional requests: must never be 1 while owned.  Do **not** wire raw `m_req_valid`: a master merely back-pressured by `req_ready = 0` is legal and would raise false intrusions |
| `quiesce_ack_i` | `1'b1` | immediate quiesce |
| `clk_req_o` | P35 `br_clk_req_i` of the memory's clock branch | opens a software-gated branch for the whole ownership |

## 5. Hazards (read before integrating)

| # | Hazard | Mitigation / status |
|---|---|---|
| H1 | An access in flight when ownership is requested | drained, not cancelled; `IDLE_CONSEC` consecutive idle cycles required |
| H2 | A master that ignores the quiesce protocol | the group blocks it (`req_ready = 0`); counted as an intrusion; test result unaffected (S11) |
| H3 | **Reset in the middle of a test leaves the array dirty** unless the platform re-initialises on reset | ECC builds of `sf_sram_controller` re-initialise on reset (`INIT_ON_RESET`); **non-ECC builds do not**.  A reset clears the arbiter, so nothing in this block can remember "dirty": the platform must initialise (demonstrated both ways in S14 / M08).  An `INIT_AFTER_RESET` option was considered and not built |
| H4 | `cfg_reinit = 0` returns a dirty array | allowed for software that re-initialises itself; flagged (`REINIT_REQ`) |
| H5 | Re-init timeout | FAULT, port returned, `REINIT_TIMEOUT` + `REINIT_REQ`: **memory content undefined**, software must initialise |
| H6 | Banks holding live CPU state (stack, code) | `protect_i`; refused unless `cpu_halted_i` (the TestCore `PROTECT` rule) |
| H7 | Scratchpad "regions" are views of shared lines | a test of a bank destroys every logical region in it (they own no array) |
| H8 | Clock gating | `clk_req_o` keeps the branch open; the MBIST runs on the memory's own clock (no crossing) |
| H9 | Test power | banks run one at a time; no parallel mode (not claimed) |
| H10 | ECC hides single-bit faults from functional reads | the raw test bus bypasses the decoder, so MBIST sees them (docs/05 section 2) |
| H11 | Non-destructive (save / restore) test | **not implemented** |

## 6. Test time

`cycles = 10 * N * B * P + overhead` for March C- (N rows, B banks, P background passes); MATS+ is `5 * N * B * P`.  Measured in
simulation for one 16-row bank at `READ_LATENCY = 1`: **194 cycles** = 160 operations + 34 cycles of ownership acquisition,
drain, per-pass start and re-initialisation (the re-init term scales with `ROWS`).  A `1024`-row, 4-bank memory is therefore about
`10 * 1024 * 4 + 1024 ~ 42 000` cycles (arithmetic, not measured; the memory model's init takes `ROWS` cycles).  A background sweep
multiplies the operation count by `1 + ceil(log2 STORE_W)`.

## 7. Parameters

| Parameter | Default | Meaning |
|---|---|---|
| `NBANK`, `ROWS`, `DATA_W`, `STORE_W` | 4, 64, 32, `DATA_W` | memory group shape; `STORE_W - DATA_W` = ECC check columns (>= 0) |
| `READ_LATENCY`, `TEST_PIPE` | 1, 0 | `LT` = sum; `TEST_PIPE` for adapter stages on the test path |
| `ACCESS_MASK`, `SHARED_MASK`, `TENSOR_MASK`, `VECTOR_MASK` | all banks, all banks, 0, 0 | memory inventory (docs/00 section 3) |
| `FIFO_DEPTH` | 4 | stored failure records (2 x STORE_W flop bits each; use a power of two so the read / write index is a plain counter, otherwise it is a modulo) |
| `OWN_TIMEOUT`, `IDLE_CONSEC`, `INIT_TIMEOUT`, `INIT_GRACE` | 4096, 2, `ROWS + 256`, 16 | arbiter limits |
| `REINIT_ENGINE` | 1 | 0 = memory has no init engine: a dirty release is flagged, never initialised |
| `REPAIR_EN`, `SPARE_ROWS`, `SPARE_COLS`, `REDUNDANCY_PRESENT` | 0, 2, 2, 0 | analysis block; `REDUNDANCY_PRESENT` must stay 0 for every macro in the repository |
| `RAS_EV_FAIL / ERR / TMO` | 2 / 8 / 11 | RAS type codes (docs/05 section 5) |

Common limits: all banks share `ROWS` and `STORE_W`; `STORE_W <= 160` and `NBANK <= 32` for the register page.
