#!/usr/bin/env python3
"""Full regression of the MBIST project.  Writes reports/regression.md and reports/lint.md.

   python3 sim/run_regress.py            # lint + unit + system + MemoryCore integration + docs check (minutes)
   python3 sim/run_regress.py --full     # ... plus the exhaustive coverage campaign and the mutation campaign

Simulators: Verilator 5.020 and Icarus Verilog 12 (the versions MemoryCore's own reports use).  The MemoryCore
integration testbench is built with Verilator at -O0: the default (optimised) Verilator build MIS-SIMULATES the vendored,
simulation-only fault model of sf_sram_core for one fault type at a 39-bit stored word (docs/06 section 5); Icarus and
Verilator -O0 agree with each other and with the analytic expectation."""
import argparse, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
VF = open(os.path.join(ROOT, "sim", "vflags.txt")).read().split()
RTL = ["rtl/sf_mbist_pattern.sv", "rtl/sf_mbist_addr_seq.sv", "rtl/sf_mbist_arbiter.sv", "rtl/sf_mbist_failreg.sv",
       "rtl/sf_mbist_fsm.sv", "rtl/sf_mbist_ras_if.sv", "rtl/sf_mbist_repair.sv", "rtl/sf_mbist_regs.sv", "rtl/sf_sram_mbist.sv"]
MODELS = ["verif/models/sf_mbist_fault_mem.sv", "verif/models/sf_mbist_sram_sys.sv"]
MC = "third_party/silicaflux-memorycore-sram"
MCSRC = [f"{MC}/rtl/sf_sram_core.sv", f"{MC}/rtl/backends/sf_sram_fpga_bram.sv", f"{MC}/rtl/backends/sf_sram_asic_sky130.sv",
         f"{MC}/rtl/sf_sram_macro_wrapper.sv", f"{MC}/rtl/sf_ecc_enc.sv", f"{MC}/rtl/sf_ecc_dec.sv", f"{MC}/rtl/sf_ecc_counters.sv",
         f"{MC}/rtl/sf_sram_bank.sv", f"{MC}/rtl/sf_sram_controller.sv", f"{MC}/rtl/sf_sync_fifo.sv",
         f"{MC}/third_party/ras_secded/sfras_secded_enc.sv", f"{MC}/third_party/ras_secded/sfras_secded_dec.sv"]

def sh(cmd, timeout=1800):
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
    return p.returncode, p.stdout + p.stderr

def vl_run(name, tb, top, params, srcs, extra=(), flags=None, incs=None):
    d = os.path.join("build", "reg", name)
    shutil.rmtree(os.path.join(ROOT, d), ignore_errors=True)
    cmd = ["verilator"] + (flags or VF) + (incs or ["+incdir+rtl", "+incdir+verif/tb"]) + list(srcs) + [tb, "--top-module", top, "-Mdir", d, "-o", "t.exe"] + \
          [f"-G{k}={v}" for k, v in params.items()] + list(extra)
    t0 = time.time()
    rc, o = sh(cmd)
    if rc != 0:
        return dict(name=name, sim="verilator", status="BUILD-FAIL", detail=o[-400:], secs=0)
    rc, o = sh([os.path.join(d, "t.exe")])
    res = [l for l in o.splitlines() if l.startswith("RESULT")]
    ok = rc == 0 and res and res[-1].endswith("PASS")
    return dict(name=name, sim="verilator", status="PASS" if ok else "FAIL", result=res[-1] if res else "(no RESULT line)",
                secs=round(time.time() - t0, 1), fails=[l for l in o.splitlines() if l.strip().startswith("FAIL")][:5])

def iv_run(name, tb, top, params, srcs, incs):
    out = os.path.join("build", "reg", name + ".vvp")
    os.makedirs(os.path.join(ROOT, "build", "reg"), exist_ok=True)
    cmd = ["iverilog", "-g2012"] + sum([["-I", i] for i in incs], []) + ["-o", out] + list(srcs) + [tb, "-s", top] + \
          sum([["-P", f"{top}.{k}={v}"] for k, v in params.items()], [])
    t0 = time.time()
    rc, o = sh(cmd)
    if rc != 0 and "error" in o.lower():
        return dict(name=name, sim="icarus", status="BUILD-FAIL", detail=o[-400:], secs=0)
    rc, o = sh(["vvp", out])
    res = [l for l in o.splitlines() if l.startswith("RESULT")]
    ok = rc == 0 and res and res[-1].endswith("PASS")
    return dict(name=name, sim="icarus", status="PASS" if ok else "FAIL", result=res[-1] if res else "(no RESULT line)",
                secs=round(time.time() - t0, 1), fails=[l for l in o.splitlines() if l.strip().startswith("FAIL")][:5])

def lint():
    rc, o = sh(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-Wno-UNUSEDSIGNAL", "-Wno-UNUSEDPARAM", "+incdir+rtl"] + RTL + ["--top-module", "sf_sram_mbist"])
    open(os.path.join(ROOT, "reports", "lint.md"), "w").write(
        "# Lint\n\n`verilator --lint-only -Wall -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM` over the nine synthesizable RTL files "
        "(Verilator 5.020), top `sf_sram_mbist` with default parameters.\n\n" + ("**Clean: no warnings.**\n" if rc == 0 and not o.strip() else "```\n" + o + "\n```\n") +
        "\nUnused-signal / unused-parameter warnings are suppressed on purpose: several interfaces carry fields that a given configuration does not use.\n"
        "Not run: technology-mapped synthesis, timing, CDC or formal tools (none is installed here).  A Yosys 0.33 generic `synth` smoke test is part of the regression (see regression.md).\n")
    return dict(name="lint (-Wall)", sim="verilator", status="PASS" if rc == 0 and not o.strip() else "FAIL", result="clean" if rc == 0 and not o.strip() else o[-300:], secs=0)

def yosys_check(name, params):
    """Yosys 0.33 (the version MemoryCore's reports use) must elaborate and synthesize the RTL with no inferred latch.
    Generic-cell counts are a smoke-test figure only: no technology mapping, no area / timing claim."""
    if not shutil.which("yosys"):
        return dict(name=name, sim="yosys", status="SKIP", result="yosys not installed", secs=0)
    cp = "; ".join(f"chparam -set {k} {v} sf_sram_mbist" for k, v in params.items())
    t0 = time.time()
    rc, o = sh(["yosys", "-q", "-l", f"build/yosys_{name.split()[-1]}.log", "-p",
                "read_verilog -sv -I rtl " + " ".join(RTL) + "; " + (cp + "; " if cp else "") +
                "hierarchy -check -top sf_sram_mbist; synth -flatten -top sf_sram_mbist; stat"])
    log = open(os.path.join(ROOT, "build", f"yosys_{name.split()[-1]}.log")).read() if os.path.exists(os.path.join(ROOT, "build", f"yosys_{name.split()[-1]}.log")) else o
    cells = re.findall(r"Number of cells:\s+(\d+)", log)
    latch = [l for l in log.splitlines() if re.search(r"latch inferred|\$dlatch|\$_DLATCH", l, re.I) and "No latch" not in l]
    ok = rc == 0 and cells and not latch
    return dict(name=name, sim="yosys 0.33", status="PASS" if ok else "FAIL", result=(f"{cells[-1]} generic cells after synth -flatten, no latches" if ok else (o[-200:] or "latch inferred")),
                secs=round(time.time() - t0, 1))

def docs_check():
    """every register localparam of the RTL appears in docs/03_register_map.md with the same address"""
    rtl = open(os.path.join(ROOT, "rtl", "sf_mbist_regs.sv")).read()
    doc = open(os.path.join(ROOT, "docs", "03_register_map.md")).read()
    pairs = re.findall(r"\b(A_[A-Z0-9_]+)\s*=\s*12'h([0-9A-Fa-f]+)", rtl)
    bad = []
    for name, addr in pairs:
        if f"`0x{int(addr, 16):03X}`" not in doc:
            bad.append(f"{name}=0x{int(addr, 16):03X}")
    return dict(name="docs: register map matches RTL", sim="python", status="PASS" if not bad and pairs else "FAIL",
                result=f"{len(pairs)} registers checked" if not bad else "missing in docs: " + ", ".join(bad), secs=0)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--full", action="store_true"); ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    os.makedirs(os.path.join(ROOT, "build", "reg"), exist_ok=True)      # verilator -Mdir does not create parents
    rows = [lint()]
    inc_my = ["+incdir+rtl", "+incdir+verif/tb"]
    jobs = []
    # unit testbench: March C- on one bank (shapes x latencies)
    for cfg in [dict(L=1, ROWS=16, W=8), dict(L=2, ROWS=16, W=8), dict(L=3, ROWS=16, W=8), dict(L=1, ROWS=13, W=8), dict(L=2, ROWS=20, W=12),
                dict(L=1, ROWS=16, W=137), dict(L=4, ROWS=12, W=33)]:
        nm = "p1_" + "_".join(f"{k}{v}" for k, v in cfg.items())
        jobs.append(lambda nm=nm, cfg=cfg: vl_run(nm, "verif/tb/tb_p1_march_one_bank.sv", "tb_p1_march_one_bank", cfg, RTL + MODELS))
    jobs.append(lambda: iv_run("p1_icarus", "verif/tb/tb_p1_march_one_bank.sv", "tb_p1_march_one_bank", {}, RTL + MODELS, ["rtl", "verif/tb"]))
    # system testbench: five configurations
    for nm, cfg in [("sys_default", {}), ("sys_all4_accessible", dict(ACCESS="4'b1111", SHARED="4'b1111", TENSOR="4'b0000", VECTOR="4'b0000")),
                    ("sys_L2_TP1", dict(L=2, TP=1)), ("sys_L3_rows24", dict(L=3, TP=0, ROWS=24)),
                    ("sys_w16_nocheck", dict(ROWS=24, STORE_W=16, DATA_W=16, ACCESS="4'b1101", SHARED="4'b0101", TENSOR="4'b1000", VECTOR="4'b0001"))]:
        jobs.append(lambda nm=nm, cfg=cfg: vl_run(nm, "verif/tb/tb_sf_sram_mbist.sv", "tb_sf_sram_mbist", cfg, RTL + MODELS))
    jobs.append(lambda: iv_run("sys_icarus", "verif/tb/tb_sf_sram_mbist.sv", "tb_sf_sram_mbist", {}, RTL + MODELS, ["rtl", "verif/tb"]))
    # MemoryCore integration: Verilator -O0 and Icarus, ECC on/off, latency 1/2
    incs_mc = ["+incdir+rtl", "+incdir+verif/tb", f"+incdir+{MC}/rtl", f"+incdir+{MC}/third_party/ras_secded"]
    mcflags = ["--binary", "--timing", "-O0", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME", "-Wno-WIDTH"]
    for ecc in (1, 0):
        for lat in (1, 2):
            jobs.append(lambda ecc=ecc, lat=lat: vl_run(f"mc_ecc{ecc}_L{lat}_O0", "verif/tb/tb_mbist_memorycore.sv", "tb_mbist_memorycore",
                                                       dict(ECC_EN=ecc, READ_LATENCY=lat), MCSRC + RTL, flags=mcflags, incs=incs_mc))
            jobs.append(lambda ecc=ecc, lat=lat: iv_run(f"mc_ecc{ecc}_L{lat}_icarus", "verif/tb/tb_mbist_memorycore.sv", "tb_mbist_memorycore",
                                                       dict(ECC_EN=ecc, READ_LATENCY=lat), MCSRC + RTL, ["rtl", "verif/tb", f"{MC}/rtl", f"{MC}/third_party/ras_secded"]))
    with ThreadPoolExecutor(a.jobs) as ex:
        rows += list(ex.map(lambda j: j(), jobs))
    rows.append(yosys_check("synthesis smoke: default parameters", {}))
    rows.append(yosys_check("synthesis smoke: 4 banks x 1024 x 39 b + repair analysis", dict(ROWS=1024, DATA_W=32, STORE_W=39, REPAIR_EN=1)))
    rows.append(docs_check())
    if a.full:
        for nm, cmd in (("coverage campaign (exhaustive)", ["python3", "sim/run_coverage.py"]), ("mutation campaign", ["python3", "sim/run_mutants.py"])):
            t0 = time.time(); rc, o = sh(cmd, timeout=7200)
            rows.append(dict(name=nm, sim="verilator/icarus", status="PASS" if rc == 0 else "FAIL", result=o.strip().splitlines()[-1] if o.strip() else "", secs=round(time.time() - t0, 1)))
    md = ["# Regression summary", "", "Generated by `sim/run_regress.py" + (" --full" if a.full else "") + "`.  All results are RTL simulation (Verilator 5.020, Icarus 12); "
          "no silicon, synthesis, timing or formal result exists.", "", "| test | simulator | status | result | s |", "|---|---|---|---|---:|"]
    for r in rows:
        md.append(f"| {r['name']} | {r['sim']} | **{r['status']}** | {r.get('result', r.get('detail', ''))} | {r.get('secs', '')} |")
    bad = [r for r in rows if r["status"] != "PASS"]
    md += ["", f"**{len(rows) - len(bad)} / {len(rows)} passed.**", ""]
    for r in bad:
        md += [f"### {r['name']}: {r['status']}", "```", *r.get("fails", []), r.get("detail", ""), "```"]
    open(os.path.join(ROOT, "reports", "regression.md"), "w").write("\n".join(md))
    for r in rows:
        print(f"{r['status']:10s} {r['name']:40s} {r.get('result', '')[:110]}")
    print(f"{len(rows) - len(bad)}/{len(rows)} passed")
    return 0 if not bad else 1

if __name__ == "__main__":
    sys.exit(main())
