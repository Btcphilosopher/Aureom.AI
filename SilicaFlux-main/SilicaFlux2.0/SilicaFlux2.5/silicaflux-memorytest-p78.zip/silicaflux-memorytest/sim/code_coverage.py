#!/usr/bin/env python3
"""RTL code coverage of the MBIST test suites (Verilator --coverage-line --coverage-toggle).

   python3 sim/code_coverage.py [--skip-build] [--with-campaign]

Builds the unit and system testbenches with coverage instrumentation and a custom main that writes coverage.dat
(Verilator 5.020's generated --binary main does not), runs them, merges every run BY SOURCE LOCATION (verilator_coverage's own
merge across different top modules is unreliable) and writes reports/code_coverage.md: line/branch points and toggle bits per RTL file
plus the list of statements no run reached.  Only the nine synthesizable RTL files under rtl/ are measured.
--with-campaign adds the exhaustive-campaign testbench (instrumented, about ten minutes)."""
import argparse, collections, os, re, shutil, subprocess, sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/sf_mbist_pattern.sv", "rtl/sf_mbist_addr_seq.sv", "rtl/sf_mbist_arbiter.sv", "rtl/sf_mbist_failreg.sv",
       "rtl/sf_mbist_fsm.sv", "rtl/sf_mbist_ras_if.sv", "rtl/sf_mbist_repair.sv", "rtl/sf_mbist_regs.sv", "rtl/sf_sram_mbist.sv"]
MODELS = ["verif/models/sf_mbist_fault_mem.sv", "verif/models/sf_mbist_sram_sys.sv"]
RUNS = [  # name, tb file, top, parameter overrides
    ("p1_L1", "tb_p1_march_one_bank", {"L": 1}), ("p1_L3", "tb_p1_march_one_bank", {"L": 3}),
    ("sys_a", "tb_sf_sram_mbist", {}),
    ("sys_b", "tb_sf_sram_mbist", {"ACCESS": "4'b1111", "SHARED": "4'b1111", "TENSOR": "4'b0000", "VECTOR": "4'b0000"}),
    ("sys_c", "tb_sf_sram_mbist", {"L": 2, "TP": 1}),
]
KEY = re.compile(r"\x01f\x02([^\x01]*)\x01l\x02(\d+)\x01n\x02(\d+)\x01page\x02([^\x01]*)\x01o\x02([^\x01]*)")

def build_run(name, top, par, tbfile):
    d = os.path.join(ROOT, "build", "ccov", name)
    shutil.rmtree(d, ignore_errors=True)
    os.makedirs(d)
    tmpl = open(os.path.join(ROOT, "sim", "cov_main.cpp.in")).read().replace("@TOP@", "V" + top)
    open(os.path.join(d, "main.cpp"), "w").write(tmpl)
    cmd = ["verilator", "--cc", "--exe", "--build", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-DECLFILENAME",
           "-Wno-WIDTH", "-Wno-BLKSEQ", "-Wno-MULTIDRIVEN", "-Wno-INITIALDLY", "--coverage-line", "--coverage-toggle", "+incdir+rtl", "+incdir+verif/tb"] + RTL + MODELS + \
          [f"verif/tb/{tbfile}.sv", "--top-module", top, "-Mdir", d, "-o", "t.exe"] + [f"-G{k}={v}" for k, v in par.items()] + [os.path.join(d, "main.cpp")]
    p = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    if p.returncode != 0:
        print("BUILD FAIL", name, p.stderr[-300:]); return None
    p = subprocess.run(["./t.exe"], cwd=d, capture_output=True, text=True)
    res = [l for l in p.stdout.splitlines() if l.startswith("RESULT")]
    print(name, res[-1] if res else "(no RESULT)")
    return os.path.join(d, "coverage.dat")

def parse(dat, acc):
    for l in open(dat, errors="replace"):
        if not l.startswith("C '"):
            continue
        body, _, cnt = l.rpartition("' ")
        m = KEY.search(body)
        if not m or not m[1].startswith("rtl/"):
            continue
        typ = "toggle" if m[4].startswith("v_toggle") else "line"
        acc[(m[1], typ, int(m[2]), int(m[3]), m[5])] += int(cnt)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--skip-build", action="store_true"); ap.add_argument("--with-campaign", action="store_true")
    a = ap.parse_args()
    runs = list(RUNS) + ([("cov8", "tb_mbist_cov", {"COV_W": 8})] if a.with_campaign else [])
    dats = []
    for name, tb, par in runs:
        dat = os.path.join(ROOT, "build", "ccov", name, "coverage.dat")
        if not a.skip_build or not os.path.exists(dat):
            dat = build_run(name, tb, par, tb)
        if dat:
            dats.append(dat)
    acc = collections.Counter()
    for d in dats:
        parse(d, acc)
    src = {f: open(os.path.join(ROOT, f)).read().splitlines() for f in RTL}
    md = ["# RTL code coverage of the test suites", "",
          "Verilator 5.020 `--coverage-line --coverage-toggle`, merged by source location over: " + ", ".join(n for n, _, _ in runs) +
          ".  **Line** = statement / branch points; **toggle** = signal bits that changed 0->1 and 1->0 (counted as one point per bit and object).",
          "A point counts as covered when ANY run hit it.  This measures how much of the RTL the tests execute; it is not a measure of correctness",
          "and not fault coverage (`reports/coverage.md`).", "",
          "| file | line points | % | toggle points | % |", "|---|---:|---:|---:|---:|"]
    tl = cl = tt = ct = 0
    unc_lines = {}
    for f in RTL:
        lp = {k: v for k, v in acc.items() if k[0] == f and k[1] == "line"}
        tp = {k: v for k, v in acc.items() if k[0] == f and k[1] == "toggle"}
        l_tot, l_cov = len(lp), sum(1 for v in lp.values() if v > 0)
        t_tot, t_cov = len(tp), sum(1 for v in tp.values() if v > 0)
        tl += l_tot; cl += l_cov; tt += t_tot; ct += t_cov
        pc = lambda c, t: f"{100.0 * c / t:.1f}" if t else "n/a"
        md.append(f"| `{os.path.basename(f)}` | {l_cov} / {l_tot} | {pc(l_cov, l_tot)} | {t_cov} / {t_tot} | {pc(t_cov, t_tot)} |")
        unc_lines[f] = sorted({k[2] for k, v in lp.items() if v == 0})
    md.append(f"| **all RTL** | {cl} / {tl} | {100.0 * cl / max(tl, 1):.1f} | {ct} / {tt} | {100.0 * ct / max(tt, 1):.1f} |")
    md += ["", "## Statements / branches no run reached", ""]
    for f in RTL:
        if unc_lines[f]:
            md.append(f"### `{f}`")
            for ln in unc_lines[f]:
                md.append(f"* L{ln}: `{src[f][ln - 1].strip()[:150]}`")
            md.append("")
    open(os.path.join(ROOT, "reports", "code_coverage.md"), "w").write("\n".join(md))
    print(f"line points {cl}/{tl} = {100.0 * cl / max(tl, 1):.1f}%   toggle bits {ct}/{tt} = {100.0 * ct / max(tt, 1):.1f}%")
    for f in RTL:
        print(f"  {os.path.basename(f):22s} uncovered line points on lines: {unc_lines[f]}")

if __name__ == "__main__":
    main()
