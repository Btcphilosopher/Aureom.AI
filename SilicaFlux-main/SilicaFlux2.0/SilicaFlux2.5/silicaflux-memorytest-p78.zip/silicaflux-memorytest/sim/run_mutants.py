#!/usr/bin/env python3
"""Mutation testing of the MBIST RTL.

   python3 sim/run_mutants.py [--jobs N] [--only ID,ID]

Each mutant is ONE deliberate textual change to ONE RTL file (listed below, with the reason it would be a real bug).  The
mutated RTL is compiled with Icarus Verilog and run against the unit testbench (tb_p1_march_one_bank, two latencies) and
the system testbench (tb_sf_sram_mbist, two configurations).  A mutant is KILLED when any run fails, hangs or reports an
error.  A SURVIVOR means the testbenches cannot tell the mutant from the correct design: either the mutant is
functionally equivalent (explained in `equiv`) or the verification has a gap.  The unmutated design is run through the
identical pipeline first as a control and MUST pass.  Writes reports/mutation.{json,md}.
A full kill count says nothing about faults nobody thought to inject."""
import argparse, json, os, re, shutil, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/sf_mbist_pattern.sv", "rtl/sf_mbist_addr_seq.sv", "rtl/sf_mbist_arbiter.sv", "rtl/sf_mbist_failreg.sv",
       "rtl/sf_mbist_fsm.sv", "rtl/sf_mbist_ras_if.sv", "rtl/sf_mbist_repair.sv", "rtl/sf_mbist_regs.sv", "rtl/sf_sram_mbist.sv"]
MODELS = ["verif/models/sf_mbist_fault_mem.sv", "verif/models/sf_mbist_sram_sys.sv"]
VARIANTS = [  # label, testbench, top, parameter overrides
    ("p1-L1", "verif/tb/tb_p1_march_one_bank.sv", "tb_p1_march_one_bank", {}),
    ("p1-L3", "verif/tb/tb_p1_march_one_bank.sv", "tb_p1_march_one_bank", {"L": 3}),
    ("sys-default", "verif/tb/tb_sf_sram_mbist.sv", "tb_sf_sram_mbist", {}),
    ("sys-L2TP1", "verif/tb/tb_sf_sram_mbist.sv", "tb_sf_sram_mbist", {"L": 2, "TP": 1}),
]

# id, file, old text (must occur exactly once), new text, why it would be a bug, equivalent-explanation (or "")
M = [
 ("F01", "rtl/sf_mbist_fsm.sv", "3'd3:    elem_info = 6'b111001;   // D(r0,w1)", "3'd3:    elem_info = 6'b011001;   // D(r0,w1)", "March element 3 runs ascending instead of descending", ""),
 ("F02", "rtl/sf_mbist_fsm.sv", "3'd2:    elem_info = 6'b011100;   // U(r1,w0)", "3'd2:    elem_info = 6'b011000;   // U(r1,w0)", "March element 2 reads/writes the wrong polarity", ""),
 ("F03", "rtl/sf_mbist_fsm.sv", "localparam int NELEM_C = 6, NELEM_M = 3;", "localparam int NELEM_C = 5, NELEM_M = 3;", "final read element of March C- dropped", ""),
 ("F04", "rtl/sf_mbist_fsm.sv", "wire         fail_now = c_v[LT-1] && (syn_c != '0);", "wire         fail_now = c_v[0] && (syn_c != '0);", "compare at the wrong pipeline stage (wrong read latency)", ""),
 ("F05", "rtl/sf_mbist_fsm.sv", "wire bad  = abort_q | wd_q | !permit_i | !own_ok_i | own_fault_i;", "wire bad  = abort_q | wd_q | !own_ok_i | own_fault_i;", "permission is not part of the issue gate", ""),
 ("F06", "rtl/sf_mbist_fsm.sv", "wire bad  = abort_q | wd_q | !permit_i | !own_ok_i | own_fault_i;", "wire bad  = abort_q | wd_q | !permit_i | own_fault_i;", "ownership is not part of the issue gate", "redundant defence in depth in the integrated design: the arbiter drops own_ok only together with permission or after the engine's own release; observable only with a different arbiter"),
 ("F07", "rtl/sf_mbist_fsm.sv", "else if (abort_q)                                   res_q <= `MB_RES_ABORTED;", "else if (1'b0)                                   res_q <= `MB_RES_ABORTED;", "an aborted run reports PASS", ""),
 ("F08", "rtl/sf_mbist_fsm.sv", "if (bad) st_q <= S_REL;\n          else if ((pass_q + 4'd1) < npass_q) begin", "if (bad) begin tested_q[bank_q] <= 1'b1; st_q <= S_REL; end\n          else if ((pass_q + 4'd1) < npass_q) begin", "an interrupted bank is marked tested", ""),
 ("F09", "rtl/sf_mbist_fsm.sv", "else if (fail_any_i)                                res_q <= `MB_RES_FAIL;", "else if (1'b0)                                res_q <= `MB_RES_FAIL;", "failures do not change the result", ""),
 ("F10", "rtl/sf_mbist_fsm.sv", "wire r_pend   = results_pending_i && !startclr_q;", "wire r_pend   = 1'b0;", "unread failure data may be overwritten by a new start", ""),
 ("F11", "rtl/sf_mbist_fsm.sv", "wire r_inacc  = ((mask_q & ~ACCESS_MASK) != '0);", "wire r_inacc  = 1'b0;", "banks without a raw test port are tested", ""),
 ("F12", "rtl/sf_mbist_fsm.sv", "(hi_q >= 32'(ROWS)) || selbad_q;", "1'b0 || selbad_q;", "out-of-range row window accepted", ""),
 ("F13", "rtl/sf_mbist_fsm.sv", "if (stop_q && fail_now) stop_req_q <= 1'b1;", "if (1'b0 && fail_now) stop_req_q <= 1'b1;", "stop-on-fail ignored", ""),
 ("F14", "rtl/sf_mbist_fsm.sv", "if (tst_we_o) dirty_q <= 1'b1;", "if (1'b0) dirty_q <= 1'b1;", "array never marked dirty: no re-initialisation", ""),
 ("F15", "rtl/sf_mbist_fsm.sv", "for (int b = NBANK - 1; b >= 0; b--) if (todo_q[b]) low_bank = BW'(b);", "for (int b = 0; b < NBANK; b++) if (todo_q[b]) low_bank = BW'(b);", "banks visited highest-first", ""),
 ("F16", "rtl/sf_mbist_fsm.sv", "npass_q <= sweep_q ? 4'(1 + STRIPE_KMAX) : 4'd1;", "npass_q <= sweep_q ? 4'(STRIPE_KMAX) : 4'd1;", "background sweep runs one pass too few", ""),
 ("F17", "rtl/sf_mbist_fsm.sv", "if (wdl_q != 32'd0 && cyc_q >= wdl_q && !wd_q)", "if (1'b0 && cyc_q >= wdl_q && !wd_q)", "run watchdog never fires", ""),
 ("F18", "rtl/sf_mbist_fsm.sv", "if (drain_q == 8'd0) st_q <= S_BEND;", "if (1'b1) st_q <= S_BEND;", "pipeline not drained before the bank / pass ends", "equivalent when LT == 1 (one DRAIN cycle either way); only observable at LT > 1"),
 ("A01", "rtl/sf_mbist_addr_seq.sv", "assign last_o = down_o ? (addr_o == lo_q) : (addr_o == hi_q);", "assign last_o = down_o ? (addr_o == lo_q) : (addr_o == hi_q - 1'b1);", "ascending sequence stops one address early", ""),
 ("A02", "rtl/sf_mbist_addr_seq.sv", "addr_o <= down_i ? hi_i : lo_i;", "addr_o <= lo_i;", "descending sequence starts at the wrong end", ""),
 ("P01", "rtl/sf_mbist_pattern.sv", "`MB_PAT_CHECKER: b = ALT_I ^ row0;", "`MB_PAT_CHECKER: b = ALT_I;", "checkerboard not inverted on odd rows", ""),
 ("P02", "rtl/sf_mbist_pattern.sv", "`MB_PAT_ADDR:    b = row_b ^ COPY_I;", "`MB_PAT_ADDR:    b = row_b;", "address pattern copies not inverted (ambiguous aliasing)", ""),
 ("R01", "rtl/sf_mbist_arbiter.sv", "if (idle_i && quiesce_ack_i && idle_cnt >= 16'(IDLE_CONSEC - 1)) st <= A_OWN1;", "if (quiesce_ack_i) st <= A_OWN1;", "ownership taken without waiting for the memory to drain", ""),
 ("R02", "rtl/sf_mbist_arbiter.sv", "else if (quiesce_ack_i) begin st <= A_DRAIN; idle_cnt <= '0; end", "else begin st <= A_DRAIN; idle_cnt <= '0; end", "quiesce acknowledge not required in QUIESCE", "equivalent: the acknowledge is ALSO required in DRAIN (idle cycles are counted only while it holds), so ownership still cannot be taken without it"),
 ("R03", "rtl/sf_mbist_arbiter.sv", "if (dirty_i && reinit_en_i && (REINIT_ENGINE != 0)) st <= A_REINIT;", "if (1'b0) st <= A_REINIT;", "memory returned to service without re-initialisation", ""),
 ("R04", "rtl/sf_mbist_arbiter.sv", "if (clr_fault_i && !own_req_i) begin st <= A_IDLE; hold_q <= 1'b0; end", "begin st <= A_IDLE; hold_q <= 1'b0; end", "ownership fault is not sticky", ""),
 ("R05", "rtl/sf_mbist_arbiter.sv", "if (intr) begin", "if (1'b0) begin", "intrusions are not counted / reported", ""),
 ("R06", "rtl/sf_mbist_arbiter.sv", "assign tst_active_o = (st == A_OWN1) || (st == A_OWNED);", "assign tst_active_o = (st == A_QUIESCE) || (st == A_OWN1) || (st == A_OWNED);", "array handed to the test bus during quiesce, before the drain", ""),
 ("R07", "rtl/sf_mbist_arbiter.sv", "assign quiesce_o    = (st == A_QUIESCE) || in_own;", "assign quiesce_o    = in_own;", "quiesce raised late (one state after the request)", "equivalent in sf_mbist_sram_sys: the first QUIESCE cycle has no functional traffic effect; kept to document the limit"),
 ("Q01", "rtl/sf_mbist_failreg.sv", "if (!first_v_q) begin first_v_q <= 1'b1; first_q <= rec_in; evt_first_o <= 1'b1; end", "begin first_v_q <= 1'b1; first_q <= rec_in; evt_first_o <= ~first_v_q; end", "first-failure record is overwritten by later failures", ""),
 ("Q02", "rtl/sf_mbist_failreg.sv", "if (lost_q != 16'hFFFF) lost_q <= lost_q + 1'b1;", "lost_q <= lost_q;", "FIFO overflow silently lost", ""),
 ("Q03", "rtl/sf_mbist_failreg.sv", "cls = f_exp_i[lo_idx] ? `MB_CLS_1TO0_BIT : `MB_CLS_0TO1_BIT;", "cls = f_exp_i[lo_idx] ? `MB_CLS_0TO1_BIT : `MB_CLS_1TO0_BIT;", "stuck-at-0 / stuck-at-1 symptom classes swapped", ""),
 ("Q04", "rtl/sf_mbist_failreg.sv", "assign pending_o        = (total_q != 32'd0) || (cnt_q != 16'd0) || (lost_q != 16'd0);", "assign pending_o        = 1'b0;", "unread data never protected", ""),
 ("Q05", "rtl/sf_mbist_failreg.sv", "for (int i = W - 1; i >= 0; i--) begin\n      if (syn[i]) begin pc = pc + 1'b1; lo_idx = BITW'(i); end", "for (int i = 0; i < W; i++) begin\n      if (syn[i]) begin pc = pc + 1'b1; lo_idx = BITW'(i); end", "reported bit index is the HIGHEST failing bit, not the lowest", ""),
 ("G01", "rtl/sf_mbist_regs.sv", "A_SELECT: begin sel_q <= rb_wdata[2:0]; bank_q <= rb_wdata[15:8]; end", "A_SELECT: begin sel_q <= rb_wdata[2:0]; bank_q <= rb_wdata[23:16]; end", "bank-index field decoded from the wrong bits", ""),
 ("G02", "rtl/sf_mbist_regs.sv", "A_ERR:    err_q <= (err_q | evt_i) & ~rb_wdata[`MB_NERR-1:0];", "A_ERR:    err_q <= (err_q | evt_i);", "write-1-to-clear does not clear", ""),
 ("G03", "rtl/sf_mbist_regs.sv", "assign rb_err   = rb_req && (rb_we ? !wr_ok : !rd_ok);", "assign rb_err   = rb_req && (rb_we ? 1'b0 : !rd_ok);", "writes to read-only / unmapped registers not rejected", ""),
 ("S01", "rtl/sf_mbist_ras_if.sv", "ev_type_o <= is_timeout_flag(err_idx) ? RAS_EV_TMO : RAS_EV_ERR;", "ev_type_o <= is_timeout_flag(err_idx) ? RAS_EV_ERR : RAS_EV_TMO;", "timeout and error RAS types swapped", ""),
 ("S02", "rtl/sf_mbist_ras_if.sv", "ev_valid_o <= 1'b0; ev_corr_o <= 1'b0; evt_lost_o <= 1'b0;", "ev_valid_o <= 1'b0; ev_corr_o <= 1'b1; evt_lost_o <= 1'b0;", "events claim a correction was performed", ""),
 ("B01", "rtl/sf_mbist_repair.sv", "if (nunc >= 2) begin", "if (nunc >= 1) begin", "single-cell failures consume spare rows instead of columns", ""),
 ("B02", "rtl/sf_mbist_repair.sv", "assign rep_ok_o      = touched & ~unrep;", "assign rep_ok_o      = touched;", "unrepairable banks reported as repairable", ""),
]

def sh(cmd, cwd, timeout=240):
    try:
        p = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT"

def run_one(mid, f, old, new, why, equiv, control=False):
    wd = os.path.join(ROOT, "build", "mut", mid)
    shutil.rmtree(wd, ignore_errors=True)
    os.makedirs(wd)
    for rel in RTL + ["rtl/sf_mbist_defs.svh"]:
        os.makedirs(os.path.join(wd, os.path.dirname(rel)), exist_ok=True)
        shutil.copy(os.path.join(ROOT, rel), os.path.join(wd, rel))
    if not control:
        path = os.path.join(wd, f)
        s = open(path).read()
        if s.count(old) != 1:
            return dict(id=mid, status="INVALID", why=why, detail=f"old text occurs {s.count(old)} times")
        open(path, "w").write(s.replace(old, new))
    details = []
    killed = False
    for label, tb, top, par in VARIANTS:
        out = os.path.join(wd, f"{label}.vvp")
        cmd = ["iverilog", "-g2012", "-I", os.path.join(wd, "rtl"), "-I", os.path.join(ROOT, "verif/tb"), "-o", out] + \
              [os.path.join(wd, r) for r in RTL] + [os.path.join(ROOT, m) for m in MODELS] + [os.path.join(ROOT, tb), "-s", top] + \
              sum([["-P", f"{top}.{k}={v}"] for k, v in par.items()], [])
        rc, o = sh(cmd, ROOT)
        if rc != 0:
            details.append(f"{label}: BUILD-ERROR")
            return dict(id=mid, status="BUILD-ERROR", why=why, detail=o[-300:])
        rc, o = sh(["vvp", out], ROOT, timeout=180)
        res = [l for l in o.splitlines() if l.startswith("RESULT")]
        ok = (rc == 0) and bool(res) and res[-1].endswith("PASS") and "FAIL" not in o
        if not ok:
            killed = True
            nfail = sum(1 for l in o.splitlines() if l.strip().startswith("FAIL"))
            details.append(f"{label}: {'TIMEOUT' if rc == 124 else 'killed (' + str(nfail) + ' failed checks)'}")
            if not control:
                break
        else:
            details.append(f"{label}: pass")
    if control:
        return dict(id=mid, status="CONTROL-PASS" if not killed else "CONTROL-FAIL", why="unmutated design", detail="; ".join(details))
    return dict(id=mid, status="KILLED" if killed else "SURVIVED", why=why, equiv=equiv, detail="; ".join(details))

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--jobs", type=int, default=4); ap.add_argument("--only", default="")
    a = ap.parse_args()
    sel = [m for m in M if not a.only or m[0] in a.only.split(",")]
    ctl = run_one("CONTROL", "", "", "", "", "", control=True)
    print("control:", ctl["status"], ctl["detail"])
    if ctl["status"] != "CONTROL-PASS":
        print("the unmutated design does not pass: aborting"); return 2
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda m: run_one(m[0], m[1], m[2], m[3], m[4], m[5]), sel))
    res_all = [ctl] + res
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res_all, open(os.path.join(ROOT, "reports", "mutation.json"), "w"), indent=1)
    ids = {m[0]: m for m in M}
    nk = sum(r["status"] == "KILLED" for r in res); ns = [r for r in res if r["status"] == "SURVIVED"]
    bad = [r for r in res if r["status"] in ("INVALID", "BUILD-ERROR")]
    md = ["# MBIST mutation testing", "",
          f"{len(res)} deliberate single-point bugs injected into the RTL (`sim/run_mutants.py`), each compiled with Icarus Verilog and run against "
          f"`tb_p1_march_one_bank` (read latency 1 and 3) and `tb_sf_sram_mbist` (default and latency 2 + test pipe 1).  Control (unmutated) run: **{ctl['status']}**.", "",
          f"**Killed: {nk} / {len(res)}**   survivors: {len(ns)}   invalid / build errors: {len(bad)}", "",
          "| id | file | injected bug | result | detail |", "|---|---|---|---|---|"]
    for r in res:
        m = ids[r["id"]]
        md.append(f"| {r['id']} | `{os.path.basename(m[1])}` | {m[4]} | {r['status']} | {r.get('detail', '')} {('(' + m[5] + ')') if r['status'] == 'SURVIVED' and m[5] else ''} |")
    if ns:
        md += ["", "## Survivors", ""]
        for r in ns:
            m = ids[r["id"]]
            md.append(f"* **{r['id']}** - {m[4]}.  " + (f"Explanation: {m[5]}." if m[5] else "**UNEXPLAINED: verification gap - strengthen the testbench.**"))
    md += ["", "A full kill count says nothing about faults nobody thought to inject; it shows that the listed bug classes cannot pass unnoticed.", ""]
    open(os.path.join(ROOT, "reports", "mutation.md"), "w").write("\n".join(md))
    print(f"killed {nk}/{len(res)} survivors {[r['id'] for r in ns]} invalid {[r['id'] for r in bad]}")
    unexplained = [r for r in ns if not ids[r["id"]][5]]
    return 0 if not unexplained and not bad else 1

if __name__ == "__main__":
    sys.exit(main())
