# third_party/silicaflux-memorycore-sram - existing SilicaFlux code reused BYTE-IDENTICAL

Source repository: `btcphilosopher/Aureom.AI`, `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memorycore-sram.zip`
(MemoryCore).  Every file here is an unmodified copy; `SHA256SUMS` lists the digest of each one
(`cd third_party/silicaflux-memorycore-sram && sha256sum -c SHA256SUMS`).

| Files | Why they are here |
|---|---|
| `rtl/sf_sram_core.sv`, `rtl/backends/*`, `rtl/sf_sram_macro_wrapper.sv` | the SRAM array with its simulation-only fault models (`FAULT_INJECT = 1`) |
| `rtl/sf_sram_bank.sv`, `rtl/sf_sram_controller.sv`, `rtl/sf_sync_fifo.sv`, `rtl/sf_ecc_*.sv`, `rtl/sf_sram_defs.svh` | the real bank / controller / ECC wrapper the MBIST drives (`tb_mbist_memorycore`) |
| `third_party/ras_secded/*` | the SECDED leaf codec those wrappers instantiate |

Not copied: the MemoryCore MBIST controller (`sf_sram_mbist_ctl`) and the March engine it wraps - this project replaces them with
`rtl/sf_sram_mbist.sv` and the modules it instantiates.  Nothing in this directory is part of the new-RTL claim; the new RTL lives
in `rtl/`.  Known tool caveat for this code: `docs/06_verification.md` section 5.
