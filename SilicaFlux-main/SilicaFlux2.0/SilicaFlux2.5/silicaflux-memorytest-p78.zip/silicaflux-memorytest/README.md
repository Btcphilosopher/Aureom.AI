# SilicaFlux MemoryTest (Project 78) - SRAM built-in self-test controller

`rtl/sf_sram_mbist.sv` is a Built-In Self-Test controller for SilicaFlux SRAM.  It runs documented, reproducible **March tests** on the raw stored word of
selected banks, reports **where and what failed**, takes **exclusive ownership** of the memory for destructive tests, and hands the memory back **re-initialised**.
It integrates with the repository's SRAM stack (MemoryCore `sf_sram_controller`), its ECC, and its RAS event interface.

> MBIST here is a **manufacturing / diagnostic feature**, not a replacement for functional verification.  Everything below is **RTL simulation** plus a Yosys 0.33 generic-synthesis smoke test; no technology-mapped
> synthesis, timing, power or silicon data exists.  Fault coverage is measured against an explicitly enumerated fault-model population, not silicon defects.  See `docs/07`.

## What is in the box

| Requested deliverable | File |
|---|---|
| `sf_sram_mbist.sv` (top: start, test mode, memory selection, algorithm, busy, pass / fail, failed address, expected, observed, failure count, completion) | `rtl/sf_sram_mbist.sv` |
| MBIST FSM (March C- / MATS+, bank and pass sequencing, op issue, compare) | `rtl/sf_mbist_fsm.sv` |
| Pattern generator (all-0, all-1, alternating, checkerboard, address, stripe) | `rtl/sf_mbist_pattern.sv` |
| Address sequencer (ascending / descending over a row window) | `rtl/sf_mbist_addr_seq.sv` |
| Test-mode arbiter (quiesce -> drain -> confirm -> test -> release -> re-init, timeouts, intrusion) | `rtl/sf_mbist_arbiter.sv` |
| Failure capture (first record, FIFO, counters, classification) | `rtl/sf_mbist_failreg.sv` |
| RAS interface | `rtl/sf_mbist_ras_if.sv` |
| Register page, optional redundancy **analysis** | `rtl/sf_mbist_regs.sv`, `rtl/sf_mbist_repair.sv`, `rtl/sf_mbist_defs.svh` |
| Fault-injection (verification-only) models | `verif/models/sf_mbist_fault_mem.sv`, `verif/models/sf_mbist_sram_sys.sv` |
| Testbenches | `verif/tb/` (unit, system, MemoryCore integration, coverage campaign) |
| Test coverage report | `reports/coverage.md` (fault), `reports/code_coverage.md` (RTL), `reports/mutation.md`, `reports/regression.md`; `docs/06_verification.md` |

## Quick start

```bash
make regress          # lint + unit + system + MemoryCore integration + Yosys + docs check (minutes)
make regress-full     # + exhaustive fault-coverage campaign + mutation testing
make coverage         # reports/coverage.md
make mutants          # reports/mutation.md
make code-coverage    # reports/code_coverage.md
```

Needs `verilator` (5.020 used), `iverilog` (12 used), `python3`; `yosys` (0.33) is optional (its checks are skipped if absent).

## Results (see `reports/` for the regenerated numbers)

* Regression: lint clean; unit (March C- on one bank, 7 shapes / latencies + Icarus); system testbench (5 configurations + Icarus, ~1 300 checks each); **real MemoryCore stack**
  (ECC on / off, latency 1 / 2, Verilator `-O0` and Icarus); Yosys 0.33 elaborates and synthesizes with no latch; register map document == RTL.
* **Safety**: monitors on every cycle of every run - no test operation outside ownership and permission, no overlap with in-flight or accepted functional accesses,
  ownership only after quiesce + acknowledge + drain, re-initialisation before release (and the scoreboard demonstrably fails when it is skipped).
* **Fault coverage** (exhaustive over the enumerated model population, `reports/coverage.md`): March C- detects 100 % of stuck-at, transition, address-decoder and every inter-word
  coupling fault and locates every single-cell fault exactly; **same-word coupling is the weak spot of solid / checkerboard tests** (60 % / 80.65 % - the latter identical to
  MemoryCore's own measurement) and the background **sweep** this project adds measures **100 %** at 8 and 32 columns.
* **Mutation testing**: 39 / 41 injected bugs killed; the 2 survivors are explained equivalents.
* The verification found real defects in its own first version (silent row-window wrap, false-intrusion semantics, testbench races, two testbench gaps): `docs/06` section 4.

## Honest scope

* **Implemented and verified**: raw array tests (data and ECC check columns, decoder bypassed), exclusive ownership with drain and re-initialisation, multi-bank selection with an explicit
  "which memories have a test port" check, diagnostics with preserved records, RAS events, register readback.
* **Analysis only**: redundancy allocation.  **No physical repair is claimed**: no SRAM macro in the repository has spare rows / columns or a repair interface.
* **Not implemented**: ECC encode / decode and protected-path *engines* (documented as separate test classes in `docs/05`; the codec is verified by MemoryCore's own testbenches, not re-run here),
  non-destructive test, retention / read-disturb / at-speed tests, parallel-bank testing.
* **Interfaces read but not co-simulated**: TestCore, DFTGrid, JTAG, the RAS event controller, the P35 clock tree.
* **Tool caveat**: Verilator 5.020's default build mis-simulates MemoryCore's vendored fault model in one integrated case; the real-stack regression uses `-O0` and cross-checks on Icarus (`docs/06` section 5).

## Layout

```
rtl/        nine synthesizable files + sf_mbist_defs.svh
verif/      models/ (fault-injection, memory-group model)   tb/ (testbenches, shared helpers)
sim/        run_regress.py  run_coverage.py  run_mutants.py  code_coverage.py  vflags.txt  cov_main.cpp.in
third_party/silicaflux-memorycore-sram/   15 MemoryCore files, byte-identical, SHA256SUMS + PROVENANCE.md
docs/       00 audit  01 architecture  02 March / patterns / diagnosis  03 registers  04 fault models  05 integration  06 verification  07 limitations
reports/    generated regression, coverage, mutation, code-coverage, lint reports
```

Start with `docs/00_repository_audit.md` (what exists in the repository and why this design), then `docs/01_architecture.md`.
