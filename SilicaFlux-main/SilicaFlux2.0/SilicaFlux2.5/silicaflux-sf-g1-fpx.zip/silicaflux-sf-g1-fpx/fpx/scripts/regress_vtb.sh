#!/usr/bin/env bash
# High-volume differential regression of the FP unit and of the IP adapter (Verilator + SoftFloat in process).
#   fpx/scripts/regress_vtb.sh            default volume;   N=<random triples> scales it (default 120000 -> 4.2M ops per profile run)
# Writes fpx/reports/vtb_summary.txt.  Every line is a measured run; expected values come from Berkeley SoftFloat 3e
# (restricted profile: SoftFloat composed with DAZ/FTZ, docs/fpx/F1 4.3).  FAIL on any mismatch or protocol error.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
N=${N:-120000}; H=$((N/2)); Q=$((N/6))
SUM="$ROOT/fpx/reports/vtb_summary.txt"; mkdir -p "$ROOT/fpx/reports"
{ echo "# fpx differential regression ($(date -u +%Y-%m-%dT%H:%MZ)); Verilator $(verilator --version | awk '{print $2}'), SoftFloat 3e RISCV specialisation"; } > "$SUM"
rc=0
run() {   # name, binary, label, args...
  local name=$1 exe=$2 label=$3; shift 3
  local line; line=$("$exe" "$@" --quiet 2>&1 | grep SUMMARY | sed 's/^SUMMARY //')
  printf "%-14s %-30s %s\n" "$name" "$label" "${line:-NO SUMMARY}" | tee -a "$SUM"
  grep -q ' PASS$' <<<"$line" || rc=1
}
# ---- FP unit, nine configurations
while read -r name r pipe tagw; do
  [[ -z "$name" || "$name" == \#* ]] && continue
  "$ROOT/fpx/scripts/vbuild_unit.sh" "$name" "$r" "$pipe" "$tagw" > /dev/null || { echo "build $name FAILED" | tee -a "$SUM"; rc=1; continue; }
  B="$ROOT/fpx/build/vtb/$name/Vsf_fpx_unit"
  run "$name" "$B" "edge cross product"            --edge
  run "$name" "$B" "directed boundary cases"       --hard
  run "$name" "$B" "random N=$N"                    --random "$N" --seed 11
  run "$name" "$B" "stalls in 0.5 out 0.3"          --random "$H" --seed 12 --pin 0.5 --pout 0.3
  run "$name" "$B" "resets, in 0.9 out 0.6"         --random "$Q" --seed 13 --pin 0.9 --pout 0.6 --reset-every 4000
done < "$ROOT/fpx/scripts/unit_configs.txt"
# ---- IP adapter (IP_LAT FIFO TAG_W QUIRKY)
for cfg in "ip_lat6 6 8 8 1" "ip_lat1 1 3 8 1" "ip_lat2 2 4 8 0" "ip_lat3 3 5 8 1" "ip_lat7 7 9 8 1" "ip_lat9 9 11 8 0" "ip_lat6_f2 6 2 8 1" "ip_lat6_f5 6 5 8 1"; do
  set -- $cfg; name=$1
  "$ROOT/fpx/scripts/vbuild_unit_ip.sh" "$@" > /dev/null || { echo "build $name FAILED" | tee -a "$SUM"; rc=1; continue; }
  B="$ROOT/fpx/build/vtb/$name/Vsf_fpx_unit_ip"
  lab="IP_LAT=$2 FIFO=$3 QUIRKY=$5"
  run "$name" "$B" "$lab edge"                      --edge
  run "$name" "$B" "$lab boundary"                  --hard
  run "$name" "$B" "$lab random"                    --random "$H" --seed 21
  run "$name" "$B" "$lab stalls+resets"             --random "$Q" --seed 22 --pin 0.8 --pout 0.5 --reset-every 3000
done
echo "RESULT: $([ $rc = 0 ] && echo PASS || echo FAIL)" | tee -a "$SUM"
exit $rc
