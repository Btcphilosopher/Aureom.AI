#!/usr/bin/env bash
# TestFloat 3e level-1 operand streams (hard cases: ties, subnormal boundaries, cancellation, overflow edges, NaN classes)
# driven through the RTL FP unit.  testfloat_gen only supplies OPERANDS here; the expected result of every operation is
# computed in-process by SoftFloat inside the harness (IEEE profile) or by its DAZ/RNE/FTZ composition (restricted profile).
#   fpx/scripts/testfloat_unit.sh          writes fpx/reports/testfloat_summary.txt
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
TFD="$ROOT/fpx/build/ref/testfloat"
SUM="$ROOT/fpx/reports/testfloat_summary.txt"; mkdir -p "$ROOT/fpx/reports"
echo "# TestFloat level-1 streams through the RTL FP unit ($(date -u +%Y-%m-%dT%H:%MZ))" > "$SUM"
rc=0
for cfg in "ieee_default 0 11110 8" "r_default 1 11110 8"; do
  set -- $cfg; name=$1
  "$ROOT/fpx/scripts/vbuild_unit.sh" "$@" > /dev/null || { echo "build $name FAILED" | tee -a "$SUM"; rc=1; continue; }
  B="$ROOT/fpx/build/vtb/$name/Vsf_fpx_unit"
  for fn in "f32_mulAdd fma" "f32_add add" "f32_sub sub" "f32_mul mul"; do
    set -- $fn; tfn=$1; op=$2
    for m in "0 rnear_even" "1 rminMag" "2 rmin" "3 rmax" "4 rnear_maxMag"; do
      set -- $m; rm=$1; mode=$2
      line=$("$TFD/testfloat_gen" -level 1 -$mode -tininessafter "$tfn" | "$B" --stdin "$op" --rm "$rm" --pin 0.9 --pout 0.8 --quiet 2>&1 | grep SUMMARY | sed 's/^SUMMARY //;s/ discarded_by_reset=0 resets=0//;s/cycles=[0-9]* //')
      printf "%-13s %-11s %-14s %s\n" "$name" "$tfn" "$mode" "${line:-NO SUMMARY}" | tee -a "$SUM"
      grep -q ' PASS$' <<<"$line" || rc=1
    done
  done
done
echo "RESULT: $([ $rc = 0 ] && echo PASS || echo FAIL)" | tee -a "$SUM"
exit $rc
