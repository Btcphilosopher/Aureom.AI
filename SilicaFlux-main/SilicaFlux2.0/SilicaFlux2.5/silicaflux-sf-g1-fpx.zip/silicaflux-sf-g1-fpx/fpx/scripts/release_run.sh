#!/usr/bin/env bash
# The complete fpx regression, one log per step in fpx/reports/logs/ (tools/fpx_summary.py turns them into REGRESSION_SUMMARY.md).
#   fpx/scripts/release_run.sh A     RTL conformance gate, kernels (deep), differential runs, TestFloat streams, IP demo
#   fpx/scripts/release_run.sh B     base `make test`, generation/registry/provenance checks, Python tests, model and RTL mutation checks
# The two streams are independent and may run in parallel.  Does not touch git.
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"; cd "$ROOT"
L=fpx/reports/logs; mkdir -p "$L"
PY=${PYTHON:-python3}
step() { local name=$1; shift; echo "== $name"; local t0=$(date +%s); "$@" > "$L/$name.txt" 2>&1; local rc=$?; echo "rc=$rc secs=$(( $(date +%s) - t0 ))" >> "$L/$name.txt"; echo "   rc=$rc"; return 0; }
case "${1:-}" in
A)
  fpx/ref/build_ref.sh > /dev/null
  step gate          $PY tools/fpx_gate.py
  step kernels       $PY tools/fpx_kernel_check.py --deep
  step vtb           fpx/scripts/regress_vtb.sh
  step testfloat     fpx/scripts/testfloat_unit.sh
  step ip_demo       $PY tools/fpx_ip_demo.py
  ;;
B)
  fpx/ref/build_ref.sh > /dev/null
  step base_make_test make test
  step check_gen      $PY tools/gen_fpx.py --check
  step registry       $PY tools/check_registry_fpx.py
  step provenance     $PY tools/check_fpx_provenance.py
  step python_tests   bash -c "cd sim && $PY -m unittest discover -s tests_fpx -t . -v"
  step model_mutation $PY tools/fpx_model_mutation.py
  step rtl_mutation   $PY tools/fpx_rtl_mutation.py
  ;;
*) echo "usage: $0 A|B"; exit 2;;
esac
echo "stream ${1} done"
