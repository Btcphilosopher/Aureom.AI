#!/usr/bin/env bash
# Build the Verilator differential harness for the IP-backed unit (sf_fpx_unit_ip = adapter + simulation-model IP).
#   fpx/scripts/vbuild_unit_ip.sh <name> <IP_LAT> [FIFO_DEPTH] [TAG_W] [IP_QUIRKY 0|1]
# Output: fpx/build/vtb/<name>/Vsf_fpx_unit_ip   (restricted-profile expectations: SoftFloat composition DAZ->RNE->FTZ)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
NAME=$1; IPLAT=$2; FIFO=${3:-$((IPLAT + 2))}; TAGW=${4:-8}; QUIRK=${5:-1}
"$ROOT/fpx/ref/build_ref.sh" > /dev/null
OUT="$ROOT/fpx/build/vtb/$NAME"; mkdir -p "$OUT"
SF="$ROOT/fpx/third_party/berkeley-softfloat-3"; SFD="$ROOT/fpx/build/ref/softfloat-RISCV"
IMP="$ROOT/fpx/rtl/imported/fp32_fma"
RTL="$ROOT/fpx/rtl/gen/sf_g1_fpx_pkg.sv $(sed "s|^|$IMP/|" "$IMP/files.f" | tr '\n' ' ') $ROOT/fpx/rtl/sf_fpx_oprewrite.sv $ROOT/fpx/rtl/sf_fpx_unit.sv $ROOT/fpx/rtl/sf_arith_adapter.sv $ROOT/fpx/sim_models/sf_third_party_fma_ip_sim.sv $ROOT/fpx/rtl/sf_fpx_unit_ip.sv"
verilator --cc --exe --build -j "$(nproc)" -O3 --x-assign fast --x-initial unique -Wno-fatal \
  --top-module sf_fpx_unit_ip -GTAG_W=$TAGW -GIP_LAT=$IPLAT -GFIFO_DEPTH=$FIFO $([ "$QUIRK" = 0 ] && echo -DSF_IP_SIM_WELL_BEHAVED) \
  -Mdir "$OUT/obj" -o "$OUT/Vsf_fpx_unit_ip" \
  -CFLAGS "-O2 -DVTOP=Vsf_fpx_unit_ip -DVTOP_HDR='\"Vsf_fpx_unit_ip.h\"' -DCFG_RESTRICTED=1 -DCFG_LATENCY=$((IPLAT + 1)) -DCFG_TAGW=$TAGW -DCFG_DRAIN=$IPLAT -DCFG_FULL_RATE=$([ $FIFO -ge $((IPLAT + 2)) ] && echo 1 || echo 0) -I$SF/source/include -I$SFD" \
  -LDFLAGS "$SFD/softfloat.a" \
  $RTL "$ROOT/fpx/tb/tb_unit.cpp" > "$OUT/build.log" 2>&1 || { tail -40 "$OUT/build.log"; exit 1; }
echo "built $OUT/Vsf_fpx_unit_ip (IP_LAT=$IPLAT FIFO_DEPTH=$FIFO TAG_W=$TAGW IP_QUIRKY=$QUIRK)"
