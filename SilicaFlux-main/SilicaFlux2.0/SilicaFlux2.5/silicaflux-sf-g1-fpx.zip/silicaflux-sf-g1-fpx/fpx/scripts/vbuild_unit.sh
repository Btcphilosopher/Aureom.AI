#!/usr/bin/env bash
# Build the Verilator differential harness for sf_fpx_unit.
#   fpx/scripts/vbuild_unit.sh <name> <RESTRICTED 0|1> <PIPE_CFG 5-bit binary> [TAG_W]
# Output: fpx/build/vtb/<name>/Vsf_fpx_unit
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"     # silicaflux-sf-g1
NAME=$1; RESTR=$2; PIPE=$3; TAGW=${4:-8}
"$ROOT/fpx/ref/build_ref.sh" > /dev/null
LAT=$(( 1 + $(echo "$PIPE" | tr -cd 1 | wc -c) ))
OUT="$ROOT/fpx/build/vtb/$NAME"; mkdir -p "$OUT"
SF="$ROOT/fpx/third_party/berkeley-softfloat-3"; SFD="$ROOT/fpx/build/ref/softfloat-RISCV"
IMP="$ROOT/fpx/rtl/imported/fp32_fma"
RTL="$ROOT/fpx/rtl/gen/sf_g1_fpx_pkg.sv $(sed "s|^|$IMP/|" "$IMP/files.f" | tr '\n' ' ') $ROOT/fpx/rtl/sf_fpx_oprewrite.sv $ROOT/fpx/rtl/sf_fpx_unit.sv"
verilator --cc --exe --build -j "$(nproc)" -O3 --x-assign fast --x-initial unique -Wno-fatal \
  --top-module sf_fpx_unit -GTAG_W=$TAGW -GRESTRICTED=1\'b$RESTR -GPIPE_CFG=5\'b$PIPE \
  -Mdir "$OUT/obj" -o "$OUT/Vsf_fpx_unit" \
  -CFLAGS "-O2 -DCFG_RESTRICTED=$RESTR -DCFG_LATENCY=$LAT -DCFG_TAGW=$TAGW -I$SF/source/include -I$SFD" \
  -LDFLAGS "$SFD/softfloat.a" \
  $RTL "$ROOT/fpx/tb/tb_unit.cpp" > "$OUT/build.log" 2>&1 || { tail -40 "$OUT/build.log"; exit 1; }
echo "built $OUT/Vsf_fpx_unit (RESTRICTED=$RESTR PIPE_CFG=$PIPE latency=$LAT TAG_W=$TAGW)"
