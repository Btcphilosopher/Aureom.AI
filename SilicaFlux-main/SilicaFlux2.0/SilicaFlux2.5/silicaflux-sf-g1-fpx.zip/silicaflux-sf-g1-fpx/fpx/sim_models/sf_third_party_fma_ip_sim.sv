// =============================================================================
// sf_third_party_fma_ip_sim.sv -- SIMULATION MODEL standing in for a third-party arithmetic IP
// sf-origin: sim-model.  NOT synthesizable, NOT licensed IP, NOT part of any hardware build.  Contains no vendor code.
//
// Purpose: give sf_arith_adapter something with the right SHAPE to be tested against: fixed latency LAT, one
// operation per cycle, no backpressure, no reset, no tag, no flags -- the common profile of a generated FPGA
// floating-point operator.  The arithmetic is behavioural (it reuses the original verified datapath in restricted
// mode, or in full-IEEE mode when QUIRKY); it is therefore NOT independent evidence about any real IP.  Its only job is to exercise the adapter's
// protocol machinery (credits, lock-step tags, drain after reset, profile enforcement).
//
// A real IP is integrated by providing a module with THE SAME NAME AND PORTS in place of this file (see
// docs/fpx/F5-ip-adapter.md section 4) and re-running the adapter conformance suite against it.
//
// Port contract (module sf_third_party_fma_ip):
//     valid, a, b, c        one operation per cycle when valid (no ready: the IP always accepts)
//     out_valid, out_result exactly LAT cycles after the accepting edge; out_valid is low when no result is due
// =============================================================================
`default_nettype none

// The integrator-facing interface of sf_third_party_fma_ip is the single parameter LAT.  QUIRKY exists only in this model and is
// chosen by a macro, so that sf_fpx_unit_ip never passes a parameter a real vendor wrapper would not have:
//   default                         QUIRKY = 1: behaves like a typical vendor IP that is NOT SFX-R conformant on its own: keeps
//                                   subnormals (no DAZ/FTZ) and returns NaNs with a non-canonical payload and sign.  The adapter
//                                   must repair this at its boundary.
//   -DSF_IP_SIM_WELL_BEHAVED        QUIRKY = 0: an IP that already flushes subnormals and returns the canonical NaN.
`ifdef SF_IP_SIM_WELL_BEHAVED
  `define SF_IP_SIM_QUIRKY_DEFAULT 1'b0
`else
  `define SF_IP_SIM_QUIRKY_DEFAULT 1'b1
`endif

module sf_third_party_fma_ip #(
  parameter int LAT    = 6,                  // >= 1
  parameter bit QUIRKY = `SF_IP_SIM_QUIRKY_DEFAULT   // model-only: see above
) (
  input  wire logic        clk,
  input  wire logic        valid,
  input  wire logic [31:0] a,
  input  wire logic [31:0] b,
  input  wire logic [31:0] c,
  output logic             out_valid,
  output logic      [31:0] out_result
);
  localparam int CORE = (LAT > 6) ? 6 : LAT;                         // stages provided by the core
  localparam logic [4:0] PIPE = 5'((1 << (CORE - 1)) - 1);            // latency = 1 + popcount = CORE

  // power-on reset only (a vendor IP has no reset port): held until the first clock edge
  logic por_n;
  initial por_n = 1'b0;
  always @(posedge clk) por_n <= 1'b1;

  logic        core_valid;
  logic [31:0] core_raw, core_result;
  logic        raw_nan;
  assign raw_nan     = (core_raw[30:23] == 8'hFF) && (core_raw[22:0] != 23'd0);
  assign core_result = (QUIRKY && raw_nan) ? 32'hFFAA5A5A : core_raw;   // negative NaN with a payload
  /* verilator lint_off PINCONNECTEMPTY */
  sf_fpx_unit #(.TAG_W(1), .RESTRICTED(!QUIRKY), .PIPE_CFG(PIPE)) u_model (
    .clk(clk), .rst_n(por_n), .in_valid(valid), .in_ready(),
    .in_op(3'(sf_g1_fpx_pkg::FPFN_FMA)), .in_a(a), .in_b(b), .in_c(c), .in_rm(3'd0), .in_tag(1'b0),
    .out_valid(core_valid), .out_ready(1'b1), .out_result(core_raw), .out_flags(), .out_tag());
  /* verilator lint_on PINCONNECTEMPTY */

  if (LAT > CORE) begin : g_extra
    localparam int X = LAT - CORE;
    logic [X-1:0]    v_q;
    logic [32*X-1:0] d_q;
    if (X == 1) begin : g_one
      always_ff @(posedge clk) begin
        v_q <= core_valid;
        d_q <= core_result;
      end
    end else begin : g_many
      always_ff @(posedge clk) begin
        v_q <= {v_q[X-2:0], core_valid};
        d_q <= {d_q[32*(X-1)-1:0], core_result};
      end
    end
    assign out_valid  = v_q[X-1] & por_n;
    assign out_result = d_q[32*(X-1) +: 32];
  end else begin : g_direct
    assign out_valid  = core_valid;
    assign out_result = core_result;
  end
endmodule

`default_nettype wire
