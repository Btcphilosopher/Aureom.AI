// sf-origin: original (verification only; not synthesizable)
// Conformance testbench: sf_fpx_widen against sim/sfg1/fpx/fp.py widen() for ALL 65536 patterns of both formats.
// Run with +VEC=<fpx_widen.vec>.
`timescale 1ns/1ps
module tb_fpx_widen;
  logic        fmt;
  logic [15:0] x;
  logic [31:0] y;
  sf_fpx_widen dut (.fmt(fmt), .x(x), .y(y));

  reg [8*512-1:0] path;
  integer fd, n, i, rc, errors;
  logic [3:0]  vfmt;
  logic [15:0] vx;
  logic [31:0] vy;

  initial begin
    errors = 0;
    if (!$value$plusargs("VEC=%s", path)) begin $display("TB_RESULT fpx_widen FAIL missing +VEC"); $finish; end
    fd = $fopen(path, "r");
    if (fd == 0) begin $display("TB_RESULT fpx_widen FAIL cannot open vector file"); $finish; end
    rc = $fscanf(fd, "%d\n", n);
    for (i = 0; i < n; i = i + 1) begin
      rc = $fscanf(fd, "%h %h %h\n", vfmt, vx, vy);
      fmt = vfmt[0]; x = vx;
      #1;
      if (y !== vy) begin
        errors = errors + 1;
        if (errors <= 10) $display("MISMATCH #%0d fmt=%0d x=%04h got=%08h exp=%08h", i, fmt, x, y, vy);
      end
    end
    if (errors == 0) $display("TB_RESULT fpx_widen PASS vectors=%0d", n);
    else             $display("TB_RESULT fpx_widen FAIL errors=%0d of %0d", errors, n);
    $finish;
  end
endmodule
