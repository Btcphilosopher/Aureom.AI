// sf-origin: original (verification only; not synthesizable)
// Conformance testbench: sf_fpx_unit against sim/sfg1/fpx/fp.py vectors.  Run with +VEC=<fpx_unit.vec>.
// Random bubbles on in_valid, random stalls on out_ready; checks result, flags, tag, in-order delivery, payload
// stability while stalled, and the exact latency of an isolated operation.  The expected values are read from
// the vector file: this testbench contains no arithmetic of its own (docs/09 rule V2).
// Structure: one clocked process samples the values present just before each edge, then drives the next cycle
// with non-blocking assignments, so there is no sampling race with the DUT.
`timescale 1ns/1ps
module tb_fpx_unit;
  import sf_g1_fpx_pkg::*;
  parameter bit       RESTRICTED = 1'b0;
  parameter bit [4:0] PIPE_CFG   = 5'b11110;
  parameter int       PCT_IN     = 70;      // % of cycles with a request offered
  parameter int       PCT_OUT    = 60;      // % of cycles with out_ready high
  parameter int       ARITH      = 0;       // 0: sf_fpx_unit   1: IP-backed unit (adapter + simulation-model IP), restricted profile only
  parameter int       IP_LAT     = 6;
  localparam int LAT  = (ARITH == 0) ? (1 + PIPE_CFG[0] + PIPE_CFG[1] + PIPE_CFG[2] + PIPE_CFG[3] + PIPE_CFG[4]) : (IP_LAT + 1);
  localparam int MAXV = 200000;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic        in_valid, in_ready, out_valid, out_ready;
  logic [2:0]  in_op, in_rm;
  logic [31:0] in_a, in_b, in_c, out_result;
  logic [4:0]  out_flags;
  logic [7:0]  in_tag, out_tag;

  if (ARITH == 0) begin : g_unit
    sf_fpx_unit #(.TAG_W(8), .RESTRICTED(RESTRICTED), .PIPE_CFG(PIPE_CFG)) dut (
      .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(in_ready), .in_op(in_op), .in_a(in_a), .in_b(in_b),
      .in_c(in_c), .in_rm(in_rm), .in_tag(in_tag), .out_valid(out_valid), .out_ready(out_ready),
      .out_result(out_result), .out_flags(out_flags), .out_tag(out_tag));
  end else begin : g_ip
    sf_fpx_unit_ip #(.TAG_W(8), .IP_LAT(IP_LAT)) dut (
      .clk(clk), .rst_n(rst_n), .in_valid(in_valid), .in_ready(in_ready), .in_op(in_op), .in_a(in_a), .in_b(in_b),
      .in_c(in_c), .in_rm(in_rm), .in_tag(in_tag), .out_valid(out_valid), .out_ready(out_ready),
      .out_result(out_result), .out_flags(out_flags), .out_tag(out_tag));
  end

  // vector store: {op[2:0], rm[2:0], a, b, c, res, flags[4:0]}
  logic [138:0] vec [0:MAXV-1];
  reg [8*512-1:0] path;
  integer fd, n, i, rc, errors, perr, issue_i, check_i, cyc, idle, lat;
  logic [3:0]  vop, vrm;
  logic [31:0] va, vb, vc, vres;
  logic [7:0]  vfl;
  logic [31:0] lfsr;
  logic        run, held_ov;
  logic [31:0] held_res; logic [4:0] held_fl; logic [7:0] held_tag;

  function automatic logic [31:0] nxt(input logic [31:0] s);
    logic [31:0] x;
    begin x = s; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); nxt = x; end
  endfunction

  // ------------------------------------------------------------------ main run: sample pre-edge, drive next cycle
  always @(posedge clk) begin
    if (run) begin
      // ---- sample (values present just before this edge)
      if (held_ov) begin
        if (!out_valid) begin perr = perr + 1; if (perr < 6) $display("PROTOCOL: out_valid fell without a transfer"); end
        else if (out_result !== held_res || out_flags !== held_fl || out_tag !== held_tag) begin
          perr = perr + 1; if (perr < 6) $display("PROTOCOL: payload changed while stalled");
        end
      end
      if (out_valid && out_ready) begin
        if (check_i >= issue_i) begin perr = perr + 1; if (perr < 6) $display("PROTOCOL: result with nothing outstanding"); end
        else begin
          if (out_result !== vec[check_i][36:5] || out_flags !== vec[check_i][4:0] || out_tag !== check_i[7:0]) begin
            errors = errors + 1;
            if (errors <= 10) $display("MISMATCH #%0d op=%0d rm=%0d a=%08h b=%08h c=%08h got=%08h/%02h tag=%02h exp=%08h/%02h",
              check_i, vec[check_i][138:136], vec[check_i][135:133], vec[check_i][132:101], vec[check_i][100:69],
              vec[check_i][68:37], out_result, out_flags, out_tag, vec[check_i][36:5], vec[check_i][4:0]);
          end
          check_i = check_i + 1; idle = 0;
        end
      end
      held_ov  = out_valid && !out_ready;
      held_res = out_result; held_fl = out_flags; held_tag = out_tag;
      if (in_valid && in_ready) begin issue_i = issue_i + 1; idle = 0; end
      idle = idle + 1;
      // ---- drive the next cycle
      lfsr = nxt(lfsr);
      if (!(in_valid && !in_ready)) begin                    // not holding an un-accepted request
        if (issue_i < n && (lfsr[15:8] % 100) < PCT_IN) begin
          in_valid <= 1'b1;
          in_op <= vec[issue_i][138:136]; in_rm <= vec[issue_i][135:133];
          in_a <= vec[issue_i][132:101];  in_b <= vec[issue_i][100:69]; in_c <= vec[issue_i][68:37];
          in_tag <= issue_i[7:0];
        end else begin
          in_valid <= 1'b0;                                  // garbage on a bubble: the unit must ignore it
          in_op <= lfsr[2:0] % 7; in_a <= lfsr; in_b <= ~lfsr; in_c <= {lfsr[15:0], lfsr[31:16]};
          in_rm <= lfsr[18:16]; in_tag <= lfsr[26:19];
        end
      end
      lfsr = nxt(lfsr);
      out_ready <= (lfsr[15:8] % 100) < PCT_OUT;
    end
  end

  // ------------------------------------------------------------------ setup, probe, verdict
  initial begin
    errors = 0; perr = 0; run = 0; held_ov = 0; issue_i = 0; check_i = 0; idle = 0;
    in_valid = 0; out_ready = 0; in_op = 0; in_rm = 0; in_a = 0; in_b = 0; in_c = 0; in_tag = 0;
    lfsr = 32'h1234ABCD;
    if (!$value$plusargs("VEC=%s", path)) begin $display("TB_RESULT fpx_unit FAIL missing +VEC"); $finish; end
    fd = $fopen(path, "r");
    if (fd == 0) begin $display("TB_RESULT fpx_unit FAIL cannot open vector file"); $finish; end
    rc = $fscanf(fd, "%d\n", n);
    if (n > MAXV) begin $display("TB_RESULT fpx_unit FAIL too many vectors"); $finish; end
    for (i = 0; i < n; i = i + 1) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h %h\n", vop, vrm, va, vb, vc, vres, vfl);
      vec[i] = {vop[2:0], vrm[2:0], va, vb, vc, vres, vfl[4:0]};
    end
    $fclose(fd);
    repeat (3) @(posedge clk);
    #1 rst_n = 1;
    if (ARITH != 0) repeat (IP_LAT + 2) @(posedge clk);       // the adapter refuses requests while it drains the IP
    // ---- isolated-latency probe: one ADD into an empty pipeline, no stall
    @(negedge clk); in_valid = 1; in_op = 3'(FPFN_ADD); in_a = 32'h3F800000; in_b = 32'h3F800000; in_c = 0; in_rm = 0;
    in_tag = 8'hA5; out_ready = 1;
    #1 if (!in_ready) begin perr = perr + 1; $display("PROBE: in_ready low on an empty pipeline"); end
    @(posedge clk);                                           // accepted here
    @(negedge clk); in_valid = 0; lat = 1;
    while (!out_valid && lat < 40) begin @(negedge clk); lat = lat + 1; end
    if (lat != LAT || out_result !== 32'h40000000 || out_tag !== 8'hA5) begin
      perr = perr + 1; $display("PROBE: latency %0d (expected %0d) result %08h tag %02h", lat, LAT, out_result, out_tag);
    end
    @(negedge clk);
    if (out_valid) begin perr = perr + 1; $display("PROBE: result delivered twice"); end
    // ---- main run
    out_ready = 0;
    @(posedge clk); run = 1;
    while (check_i < n && idle < 3000) @(posedge clk);
    #1 run = 0;
    if (check_i == n && errors == 0 && perr == 0)
      $display("TB_RESULT fpx_unit PASS vectors=%0d profile=%s latency=%0d", n, RESTRICTED ? "SFX-R   " : "SFX-IEEE", LAT);
    else
      $display("TB_RESULT fpx_unit FAIL errors=%0d protocol=%0d checked=%0d of %0d", errors, perr, check_i, n);
    $finish;
  end
endmodule
