// sf-origin: original.  Links third-party Berkeley SoftFloat 3e (BSD-3-Clause) as the oracle; verification only.
//
// Differential harness for sf_fpx_unit (Verilator).  Every accepted request is evaluated by SoftFloat *in
// process* (RISCV specialisation, tininess after rounding); the DUT's 32 result bits (NaNs included), five
// flags and tag are compared bit for bit.  The expected value of the restricted profile is the composition
// defined in docs/fpx/F1 4.3: DAZ -> SoftFloat RNE -> FTZ, flags 0.
//
// Protocol checks: in-order delivery with matching tag, no loss/duplication, out_* stable while
// out_valid && !out_ready, out_valid never falls without a transfer, exact latency of an isolated operation,
// sustained one-op-per-cycle throughput without stalls, reset discards outstanding work and nothing stale
// appears afterwards.
//
//   --random N       N random operand triples x selected ops x selected rounding modes
//   --edge           cross product of the edge-value table (every class and binade boundary)
//   --hard           directed list of subnormal-boundary cases (round-up into the smallest normal, ties at half the smallest
//                    subnormal, carry out of the subnormal range, ...) x every op x every rounding mode
//   --stdin OP       TestFloat stream "a b c z flags" (OP = fma|add|sub|mul), rounding via --rm
//   --ops LIST       comma list of fma,fms,fnma,fnms,add,sub,mul (default all)
//   --rm all|0..4    rounding modes (restricted profile: ignored by the DUT, still varied on the input)
//   --pin P --pout P per-cycle probability of in_valid / out_ready (default 1.0 = no stalls)
//   --reset-every N  assert reset at a random cycle about every N cycles
//   --seed S  --quiet
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <deque>
#include <random>
#include <string>
#include <vector>

#ifndef VTOP
#define VTOP Vsf_fpx_unit
#define VTOP_HDR "Vsf_fpx_unit.h"
#endif
#include VTOP_HDR
#include "verilated.h"
extern "C" {
#include "softfloat.h"
}

#ifndef CFG_RESTRICTED
#define CFG_RESTRICTED 0
#endif
#ifndef CFG_LATENCY
#define CFG_LATENCY 5
#endif
#ifndef CFG_DRAIN
#define CFG_DRAIN 0      /* cycles after reset release during which requests may be refused (adapter drain) */
#endif
#ifndef CFG_FULL_RATE
#define CFG_FULL_RATE 1  /* 1: the configuration must sustain one operation per cycle */
#endif
#ifndef CFG_TAGW
#define CFG_TAGW 8
#endif

static const uint32_t SIGN = 0x80000000u;
enum { FMA, FMS, FNMA, FNMS, ADD, SUB, MUL };
static const char *OPN[] = {"fma", "fms", "fnma", "fnms", "add", "sub", "mul"};

static const uint32_t EDGE[] = {
    0x00000000, 0x80000000, 0x00000001, 0x80000001, 0x00000002, 0x00400000, 0x007FFFFE, 0x007FFFFF, 0x80400000,
    0x807FFFFF, 0x00800000, 0x80800000, 0x00800001, 0x00FFFFFF, 0x01000000, 0x3F7FFFFF, 0x3F800000, 0x3F800001,
    0xBF800000, 0xBF7FFFFF, 0x3F000000, 0x40000000, 0x40400000, 0x40490FDB, 0x4B000000, 0x4B7FFFFF, 0x4B800000,
    0x7F7FFFFF, 0xFF7FFFFF, 0x7F000000, 0x7E800000, 0x1F800000, 0x20000000, 0x7F800000, 0xFF800000, 0x7FC00000,
    0xFFC00000, 0x7FC00001, 0x7FFFFFFF, 0x7F800001, 0xFF800001, 0x7FBFFFFF};

static uint_fast8_t map_rm(unsigned rm) {
  switch (rm) {
    case 1: return softfloat_round_minMag;
    case 2: return softfloat_round_min;
    case 3: return softfloat_round_max;
    case 4: return softfloat_round_near_maxMag;
    default: return softfloat_round_near_even;
  }
}
static unsigned map_flags(uint_fast8_t f) {
  unsigned r = 0;
  if (f & softfloat_flag_inexact) r |= 1;
  if (f & softfloat_flag_underflow) r |= 2;
  if (f & softfloat_flag_overflow) r |= 4;
  if (f & softfloat_flag_infinite) r |= 8;
  if (f & softfloat_flag_invalid) r |= 16;
  return r;
}
static uint32_t sf_op(int op, uint32_t a, uint32_t b, uint32_t c, unsigned rm, unsigned *fl) {
  float32_t fa, fb, fc, fz;
  fa.v = a; fb.v = b; fc.v = c;
  softfloat_roundingMode = map_rm(rm);
  softfloat_detectTininess = softfloat_tininess_afterRounding;
  softfloat_exceptionFlags = 0;
  switch (op) {
    case FMA:  fz = f32_mulAdd(fa, fb, fc); break;
    case FMS:  fc.v ^= SIGN; fz = f32_mulAdd(fa, fb, fc); break;
    case FNMA: fa.v ^= SIGN; fz = f32_mulAdd(fa, fb, fc); break;
    case FNMS: fa.v ^= SIGN; fc.v ^= SIGN; fz = f32_mulAdd(fa, fb, fc); break;
    case ADD:  fz = f32_add(fa, fb); break;
    case SUB:  fz = f32_sub(fa, fb); break;
    default:   fz = f32_mul(fa, fb); break;
  }
  *fl = map_flags(softfloat_exceptionFlags);
  return fz.v;
}
static bool is_sub(uint32_t x) { return ((x >> 23) & 0xFF) == 0 && (x & 0x7FFFFF) != 0; }
static uint32_t dazf(uint32_t x) { return is_sub(x) ? (x & SIGN) : x; }
static void expect(int op, uint32_t a, uint32_t b, uint32_t c, unsigned rm, uint32_t *res, unsigned *fl) {
  if (!CFG_RESTRICTED) {
    unsigned r = rm > 4 ? 0 : rm;
    *res = sf_op(op, a, b, c, r, fl);
  } else {
    unsigned f;
    uint32_t z = sf_op(op, dazf(a), dazf(b), dazf(c), 0, &f);
    *res = is_sub(z) ? (z & SIGN) : z;
    *fl = 0;
  }
}

static const uint32_t HARD[][3] = {
    {0x0D800000, 0xA6800000, 0x00800000},   // 2^-100 * -2^-50 + 2^-126 = 2^-126 - 2^-150: rounds UP into the smallest normal (F1 4.3)
    {0x0D800000, 0x26800000, 0x80800000},   // the mirror image, negative
    {0x0D800000, 0x26800000, 0x00000000},   // 2^-150: exactly half the smallest subnormal (tie)
    {0x1A000000, 0x1A000000, 0x00000000},   // 2^-75 * 2^-75 = 2^-150 through the multiplier
    {0x3F800000, 0x00000001, 0x007FFFFF},   // 1 * 2^-149 + max subnormal = smallest normal, exact
    {0x3F800001, 0x00000001, 0x007FFFFF},   // the same plus a rounding bit
    {0x00000001, 0x3F000000, 0x00000000},   // 2^-149 * 0.5
    {0x00000001, 0x3F400000, 0x00000000},   // 2^-149 * 0.75: rounds up to 2^-149 (RNE)
    {0x007FFFFF, 0x3F800001, 0x00000000},   // max subnormal * (1+ulp)
    {0x00800000, 0x3F7FFFFF, 0x00000000},   // smallest normal * (1-ulp): rounds up on the subnormal grid
    {0x00800000, 0xBF7FFFFF, 0x80000000},   // and its mirror with a negative-zero addend
    {0x00FFFFFF, 0x3F000000, 0x00000000},   // (2^-125 - ulp) * 0.5
    {0x00000003, 0x3F000000, 0x00000000},   // 3 * 2^-149 * 0.5: tie to even
    {0x00000005, 0x3F000000, 0x00000000},   // 5 * 2^-149 * 0.5: tie to even
};
struct Req { int op; uint32_t a, b, c; unsigned rm; uint32_t tag; };
struct Exp { uint32_t res; unsigned fl; uint32_t tag; uint64_t t_in; };

static uint32_t rand_operand(std::mt19937_64 &g) {
  unsigned k = g() % 16;
  if (k < 3) return EDGE[g() % (sizeof(EDGE) / sizeof(EDGE[0]))];
  uint32_t s = (uint32_t)(g() & 1) << 31, m = (uint32_t)(g() & 0x7FFFFF);
  switch (k % 6) {
    case 0: return (uint32_t)g();
    case 1: return s | ((124u + g() % 8) << 23) | m;           // near-equal exponents: cancellation
    case 2: return s | ((uint32_t)(g() % 24) << 23) | m;       // tiny / subnormal
    case 3: return s | ((0xE0u + g() % 31) << 23) | m;         // huge / overflow
    case 4: { uint32_t mm = 0; for (unsigned i = g() % 4; i; --i) mm |= 1u << (g() % 23); return s | ((100u + g() % 54) << 23) | mm; }
    default: return (uint32_t)g();
  }
}

int main(int argc, char **argv) {
  Verilated::commandArgs(argc, argv);
  uint64_t nrand = 0, seed = 1, reset_every = 0;
  double pin = 1.0, pout = 1.0;
  bool edge = false, quiet = false, from_stdin = false, hard = false;
  std::string stdin_op = "fma", rmarg = "all", opsarg = "all";
  for (int i = 1; i < argc; i++) {
    std::string s = argv[i];
    auto nxt = [&]() { return std::string(argv[++i]); };
    if (s == "--random") nrand = strtoull(nxt().c_str(), 0, 0);
    else if (s == "--seed") seed = strtoull(nxt().c_str(), 0, 0);
    else if (s == "--pin") pin = atof(nxt().c_str());
    else if (s == "--pout") pout = atof(nxt().c_str());
    else if (s == "--reset-every") reset_every = strtoull(nxt().c_str(), 0, 0);
    else if (s == "--edge") edge = true;
    else if (s == "--hard") hard = true;
    else if (s == "--quiet") quiet = true;
    else if (s == "--stdin") { from_stdin = true; stdin_op = nxt(); }
    else if (s == "--rm") rmarg = nxt();
    else if (s == "--ops") opsarg = nxt();
  }
  std::vector<int> ops;
  { std::string l = opsarg == "all" ? "fma,fms,fnma,fnms,add,sub,mul" : opsarg; size_t p = 0;
    while (p <= l.size()) { size_t q = l.find(',', p); if (q == std::string::npos) q = l.size();
      std::string t = l.substr(p, q - p); for (int k = 0; k < 7; k++) if (t == OPN[k]) ops.push_back(k); p = q + 1; } }
  std::vector<unsigned> rms;
  if (rmarg == "all") rms = {0, 1, 2, 3, 4}; else rms = {(unsigned)atoi(rmarg.c_str())};

  // ------------------------------------------------------------------ request source
  std::mt19937_64 g(seed), gs(seed * 7919 + 13);
  std::deque<Req> pending;      // generated ahead (bounded)
  uint32_t next_tag = 0;
  uint64_t gen_count = 0;
  size_t ei = 0, ej = 0, ek = 0, hi = 0;
  const size_t NE = sizeof(EDGE) / sizeof(EDGE[0]);
  int stdin_opc = stdin_op == "fma" ? FMA : stdin_op == "add" ? ADD : stdin_op == "sub" ? SUB : MUL;
  bool src_done = false;
  auto refill = [&]() {
    while (pending.size() < 64 && !src_done) {
      if (from_stdin) {
        unsigned a, b, c = 0, z, f; int n;
        if (stdin_op == "fma") n = scanf("%x %x %x %x %x", &a, &b, &c, &z, &f);
        else n = scanf("%x %x %x %x", &a, &b, &z, &f) + 1;
        if (n < 4) { src_done = true; break; }
        pending.push_back({stdin_opc, a, b, c, rms[0], 0});
      } else if (hard) {
        if (hi >= sizeof(HARD) / sizeof(HARD[0])) { src_done = true; break; }
        for (int op = 0; op < 7; op++) for (unsigned rm = 0; rm < 5; rm++) pending.push_back({op, HARD[hi][0], HARD[hi][1], HARD[hi][2], rm, 0});
        ++hi;
      } else if (edge) {
        if (ei >= NE) { src_done = true; break; }
        for (int op : ops) for (unsigned rm : rms) pending.push_back({op, EDGE[ei], EDGE[ej], EDGE[ek], rm, 0});
        if (++ek >= NE) { ek = 0; if (++ej >= NE) { ej = 0; ++ei; } }
      } else {
        if (gen_count >= nrand) { src_done = true; break; }
        uint32_t a = rand_operand(g), b = rand_operand(g), c = rand_operand(g);
        for (int op : ops) for (unsigned rm : rms) pending.push_back({op, a, b, c, rm, 0});
        gen_count++;
      }
    }
  };

  // ------------------------------------------------------------------ DUT
  VTOP *dut = new VTOP;
  uint64_t cyc = 0;
  auto tick = [&]() { dut->clk = 1; dut->eval(); dut->clk = 0; dut->eval(); cyc++; };
  dut->clk = 0; dut->rst_n = 0; dut->in_valid = 0; dut->out_ready = 0; dut->in_op = 0; dut->in_a = dut->in_b = dut->in_c = 0;
  dut->in_rm = 0; dut->in_tag = 0; dut->eval();
  tick(); tick(); dut->rst_n = 1; dut->eval();

  uint64_t cov_flag[5] = {0,0,0,0,0}, cov_sub = 0, cov_nan = 0, cov_inf = 0;
  uint64_t mism = 0, perr = 0, issued = 0, checked = 0, discarded = 0, resets = 0, lat_min = ~0ull, lat_max = 0, stale = 0;
  std::deque<Exp> sb;
  bool prev_ov = false; uint32_t pres = 0, pfl = 0, ptag = 0;
  const uint32_t TAGMASK = (CFG_TAGW >= 32) ? 0xFFFFFFFFu : ((1u << CFG_TAGW) - 1);
  std::uniform_real_distribution<double> U(0.0, 1.0);

  // ------------------------------------------------ isolated-latency probe (empty pipeline, no stall)
  {
    int drained = 0;                       // wait out the documented post-reset drain window, if any
    dut->in_valid = 0; dut->out_ready = 1; dut->eval();
    while (!dut->in_ready && drained < CFG_DRAIN + 4) { tick(); drained++; }
    if (drained != CFG_DRAIN) { printf("PROBE FAIL: in_ready first high %d cycles after reset release (documented drain window %d)\n", drained, CFG_DRAIN); perr++; }
    if (!quiet && CFG_DRAIN) printf("post-reset drain: %d cycles (window %d)\n", drained, CFG_DRAIN);
    dut->out_ready = 1; dut->in_valid = 1; dut->in_op = FMA; dut->in_a = 0x3F800000; dut->in_b = 0x40000000; dut->in_c = 0x3F800000;
    dut->in_rm = 0; dut->in_tag = 0x5A & TAGMASK; dut->eval();
    if (!dut->in_ready) { printf("PROBE FAIL: in_ready low on an empty pipeline\n"); perr++; }
    tick(); dut->in_valid = 0; dut->eval();
    int lat = 1;
    while (!dut->out_valid && lat < 64) { tick(); lat++; }
    uint32_t er; unsigned ef; expect(FMA, 0x3F800000, 0x40000000, 0x3F800000, 0, &er, &ef);
    if (lat != CFG_LATENCY || dut->out_result != er || dut->out_flags != ef) {
      printf("PROBE FAIL: latency %d (expected %d) result %08x (expected %08x)\n", lat, CFG_LATENCY, dut->out_result, er); perr++; }
    tick(); dut->eval();
    if (dut->out_valid) { printf("PROBE FAIL: result delivered twice\n"); perr++; }
    if (!quiet) printf("latency probe: %d cycles (configured %d)\n", lat, CFG_LATENCY);
  }

  uint64_t next_reset = reset_every ? 1 + g() % (2 * reset_every) : ~0ull;
  uint64_t idle = 0, loop_cycles = 0;
  bool in_hold = false; Req hold{};
  int drain_left = 0;                      // cycles after a reset release in which in_ready must stay low (adapter drain window)
  while (true) {
    refill();
    if (pending.empty() && !in_hold && sb.empty()) break;
    if (loop_cycles++ > 2000000000ull) { printf("TIMEOUT\n"); perr++; break; }
    // reset injection
    if (cyc >= next_reset) {
      dut->rst_n = 0; dut->eval();
      // in_valid is deliberately left as the previous cycle drove it: a unit in reset must not offer to accept it
      if (CFG_DRAIN && dut->in_ready) { if (perr++ < 10) printf("PROTOCOL: in_ready high while reset is asserted (cycle %llu)\n", (unsigned long long)cyc); }
      tick();
      discarded += sb.size(); sb.clear(); in_hold = false; resets++; prev_ov = false;
      if (dut->out_valid) { printf("PROTOCOL: out_valid high during reset\n"); perr++; }
      dut->rst_n = 1; dut->eval();
      drain_left = CFG_DRAIN;
      next_reset = cyc + 1 + g() % (2 * reset_every);
      continue;
    }
    // drive inputs for this cycle
    bool want_valid = in_hold || (!pending.empty() && U(gs) < pin);
    if (want_valid && !in_hold) { hold = pending.front(); hold.tag = next_tag & TAGMASK; in_hold = true; }
    dut->in_valid = want_valid;
    if (want_valid) { dut->in_op = hold.op; dut->in_a = hold.a; dut->in_b = hold.b; dut->in_c = hold.c; dut->in_rm = hold.rm; dut->in_tag = hold.tag; }
    else { dut->in_op = (uint8_t)(g() % 7); dut->in_a = (uint32_t)g(); dut->in_b = (uint32_t)g(); dut->in_c = (uint32_t)g(); dut->in_rm = g() % 8; dut->in_tag = (uint32_t)g() & TAGMASK; }
    bool ordy = U(gs) < pout;
    dut->out_ready = ordy;
    dut->eval();
    bool iready = dut->in_ready, ov = dut->out_valid;
    if (drain_left > 0) {
      if (iready) { if (perr++ < 10) printf("PROTOCOL: in_ready high %d cycle(s) before the end of the post-reset drain window (cycle %llu)\n", drain_left, (unsigned long long)cyc); }
      drain_left--;
    }
    // stability: out_valid held and payload unchanged while stalled
    if (prev_ov) {
      if (!ov) { if (perr++ < 10) printf("PROTOCOL: out_valid fell without a transfer (cycle %llu)\n", (unsigned long long)cyc); }
      else if (dut->out_result != pres || dut->out_flags != pfl || dut->out_tag != ptag) { if (perr++ < 10) printf("PROTOCOL: payload changed while stalled (cycle %llu)\n", (unsigned long long)cyc); }
    }
    // sample transfers (before the clock edge)
    bool in_xfer = want_valid && iready, out_xfer = ov && ordy;
    if (out_xfer) {
      if (sb.empty()) { stale++; if (stale < 10) printf("PROTOCOL: unexpected result (nothing outstanding), cycle %llu\n", (unsigned long long)cyc); }
      else {
        Exp e = sb.front(); sb.pop_front();
        checked++;
        for (int b = 0; b < 5; b++) cov_flag[b] += (e.fl >> b) & 1;
        cov_sub += is_sub(e.res);
        cov_nan += ((e.res >> 23) & 0xFF) == 0xFF && (e.res & 0x7FFFFF) != 0;
        cov_inf += ((e.res >> 23) & 0xFF) == 0xFF && (e.res & 0x7FFFFF) == 0;
        uint64_t lat = cyc - e.t_in;
        if (lat < lat_min) lat_min = lat;
        if (lat > lat_max) lat_max = lat;
        if (dut->out_result != e.res || dut->out_flags != e.fl || dut->out_tag != e.tag) {
          mism++;
          if (mism <= 10) printf("MISMATCH #%llu got res=%08x fl=%02x tag=%02x exp res=%08x fl=%02x tag=%02x\n", (unsigned long long)checked,
                                 dut->out_result, dut->out_flags, dut->out_tag, e.res, e.fl, e.tag);
        }
      }
    }
    prev_ov = ov && !ordy; pres = dut->out_result; pfl = dut->out_flags; ptag = dut->out_tag;
    if (in_xfer) {
      Exp e; expect(hold.op, hold.a, hold.b, hold.c, hold.rm, &e.res, &e.fl); e.tag = hold.tag; e.t_in = cyc;
      sb.push_back(e); issued++; next_tag++; pending.pop_front(); in_hold = false;
    }
    tick();
    if (!ov && !want_valid) { if (++idle > 100000) { printf("TIMEOUT idle\n"); perr++; break; } } else idle = 0;
  }
  // drain
  dut->in_valid = 0; dut->out_ready = 1; dut->eval();
  for (int i = 0; i < 64; i++) { if (dut->out_valid) { stale++; printf("PROTOCOL: stale output after drain\n"); } tick(); }
  // without stalls or resets the unit must sustain one operation per cycle (initiation interval 1)
  if (CFG_FULL_RATE && pin >= 1.0 && pout >= 1.0 && !reset_every && checked > 1000 && cyc > issued + CFG_LATENCY + 150 + CFG_DRAIN) {
    printf("THROUGHPUT: %llu operations took %llu cycles (expected about %llu)\n", (unsigned long long)issued,
           (unsigned long long)cyc, (unsigned long long)(issued + CFG_LATENCY));
    perr++;
  }
  const bool ok = mism == 0 && perr == 0 && stale == 0 && sb.empty() && checked > 0;
  printf("SUMMARY profile=%s latency_cfg=%d issued=%llu checked=%llu discarded_by_reset=%llu resets=%llu mismatches=%llu protocol_errors=%llu stale=%llu "
         "cycles=%llu ops_per_cycle=%.4f latency[min/max]=%llu/%llu %s\n", CFG_RESTRICTED ? "SFX-R" : "SFX-IEEE", CFG_LATENCY,
         (unsigned long long)issued, (unsigned long long)checked, (unsigned long long)discarded, (unsigned long long)resets,
         (unsigned long long)mism, (unsigned long long)perr, (unsigned long long)stale, (unsigned long long)cyc,
         cyc ? (double)checked / cyc : 0.0, (unsigned long long)(lat_min == ~0ull ? 0 : lat_min), (unsigned long long)lat_max, ok ? "PASS" : "FAIL");
  printf("COVERAGE results with NX=%llu UF=%llu OF=%llu DZ=%llu NV=%llu | subnormal=%llu nan=%llu inf=%llu\n",
         (unsigned long long)cov_flag[0], (unsigned long long)cov_flag[1], (unsigned long long)cov_flag[2], (unsigned long long)cov_flag[3],
         (unsigned long long)cov_flag[4], (unsigned long long)cov_sub, (unsigned long long)cov_nan, (unsigned long long)cov_inf);
  delete dut;
  return ok ? 0 : 1;
}
