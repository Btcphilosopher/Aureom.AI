// sf-origin: original (verification only; not synthesizable)
// Conformance testbench: sf_fpx_decode against sim/sfg1/fpx/config.py ExtIsa.decode (record = {base record, rd_re}).
// Run with +VEC=<fpx_decode.vec>.  Every comparison uses !== so X and Z count as mismatches.
`timescale 1ns/1ps
module tb_fpx_decode;
  import sf_g1_fpx_decode_pkg::*;
  logic [31:0]     insn;
  sf_fpx_decoded_t dec;
  sf_fpx_decode dut (.insn(insn), .dec(dec));

  reg [8*512-1:0] path;
  integer fd, n, i, rc, errors;
  logic [31:0]               vw;
  logic [SF_FPX_DECODED_W-1:0] vexp;

  initial begin
    errors = 0;
    if (!$value$plusargs("VEC=%s", path)) begin $display("TB_RESULT fpx_decode FAIL missing +VEC"); $finish; end
    fd = $fopen(path, "r");
    if (fd == 0) begin $display("TB_RESULT fpx_decode FAIL cannot open vector file"); $finish; end
    rc = $fscanf(fd, "%d\n", n);
    for (i = 0; i < n; i = i + 1) begin
      rc = $fscanf(fd, "%h %h\n", vw, vexp);
      insn = vw;
      #1;
      if (dec !== vexp) begin
        errors = errors + 1;
        if (errors <= 10) $display("MISMATCH #%0d insn=%08h got=%h exp=%h", i, insn, dec, vexp);
      end
    end
    if (errors == 0) $display("TB_RESULT fpx_decode PASS vectors=%0d", n);
    else             $display("TB_RESULT fpx_decode FAIL errors=%0d of %0d", errors, n);
    $finish;
  end
endmodule
