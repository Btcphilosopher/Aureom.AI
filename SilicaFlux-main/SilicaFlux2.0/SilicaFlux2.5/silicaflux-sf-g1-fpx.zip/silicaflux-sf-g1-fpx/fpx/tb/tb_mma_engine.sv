// sf-origin: original (verification only; not synthesizable)
// Conformance testbench: sf_mma_engine against sim/sfg1/fpx/matrix.py jobs.  Run with +VEC=<mma_engine.vec>.
//
// A word-addressed shared-memory model sits behind the engine's master port:
//   +LAT=n   base read latency (cycles after acceptance, default 2)   +JIT=n  extra random 0..n cycles per read
//   +RDY=p   percent of cycles with mem_req_ready high (default 70)   +RSPRDY=p  percent with rsp_ready high
//   +GAP=n   random 0..n idle cycles between jobs                      +SEED=s
// Reads return in request order, data captured when the request is accepted; writes take effect at acceptance.
// After every job the WHOLE memory image is compared with the model's expected image (so a stray write anywhere,
// or a missing one, is caught), together with the completion tag and the accumulated exception flags.
// Also checked: cmd_ready low while a job runs, no memory traffic while idle, aligned in-range word addresses,
// completion payload stable while stalled.  No arithmetic lives here: expected values come from the vector file.
//   +RSTJOB=p  percent of jobs aborted by a reset 3..62 cycles after acceptance.  The reset also flushes the memory model's outstanding
//              reads (a master's reset must cover its memory port: F4 section 7); memory is restored, the same job is re-issued and
//              must then complete correctly.  The run FAILS if p > 0 and no job was ever aborted (a vacuous pass).
//   +RSTNOFLUSH=1  negative control: the reset does NOT flush outstanding reads.  The engine is then expected to FAIL (stale responses
//              land in the next job), which demonstrates why F4 requires the memory port to be reset with the engine.
`timescale 1ns/1ps
module tb_mma_engine;
  parameter int       M = 4, N = 4, K = 8, P = 4;
  parameter bit       RESTRICTED = 1'b0;
  parameter bit [4:0] PIPE_CFG   = 5'b11110;
  parameter int       ARITH      = 0;
  parameter int       IP_LAT     = 6;
  localparam int ADDR_W = 16;
  localparam int CWN    = M * N;
  localparam int MAXW   = 2048;
  localparam int MAXJ   = 1024;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic              cmd_valid, cmd_ready, rsp_valid, rsp_ready;
  logic [ADDR_W-1:0] cmd_a, cmd_b, cmd_c;
  logic [2:0]        cmd_rm;
  logic              cmd_fmt, cmd_zero;
  logic [3:0]        cmd_tag, rsp_tag;
  logic [4:0]        rsp_flags;
  logic              mreq_v, mreq_r, mreq_we, mrsp_v;
  logic [ADDR_W-1:0] mreq_addr;
  logic [31:0]       mreq_wdata, mrsp_data;

  sf_mma_engine #(.M(M), .N(N), .K(K), .P(P), .ADDR_W(ADDR_W), .TAG_W(4), .RESTRICTED(RESTRICTED), .PIPE_CFG(PIPE_CFG), .ARITH(ARITH), .IP_LAT(IP_LAT)) dut (
    .clk(clk), .rst_n(rst_n),
    .cmd_valid(cmd_valid), .cmd_ready(cmd_ready), .cmd_a_addr(cmd_a), .cmd_b_addr(cmd_b), .cmd_c_addr(cmd_c),
    .cmd_rm(cmd_rm), .cmd_fmt(cmd_fmt), .cmd_zero_c(cmd_zero), .cmd_tag(cmd_tag),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_tag(rsp_tag), .rsp_flags(rsp_flags),
    .mem_req_valid(mreq_v), .mem_req_ready(mreq_r), .mem_req_we(mreq_we), .mem_req_addr(mreq_addr),
    .mem_req_wdata(mreq_wdata), .mem_rsp_valid(mrsp_v), .mem_rsp_data(mrsp_data));

  // ---------------------------------------------------------------- vectors
  logic [31:0] mem     [0:MAXW-1];
  logic [31:0] exp_mem [0:MAXW-1];
  logic [3:0]  j_fmt [0:MAXJ-1], j_rm [0:MAXJ-1], j_zero [0:MAXJ-1], j_tag [0:MAXJ-1];
  logic [15:0] j_a [0:MAXJ-1], j_b [0:MAXJ-1], j_c [0:MAXJ-1];
  logic [7:0]  j_fl [0:MAXJ-1];
  logic [31:0] j_d [0:MAXJ*CWN-1];
  localparam int MAXPRE = 512;
  integer      j_npre [0:MAXJ-1];
  integer      j_pidx [0:MAXJ*MAXPRE-1];
  logic [31:0] j_pval [0:MAXJ*MAXPRE-1];
  integer      npre_i, pk;

  reg [8*512-1:0] path;
  integer fd, rc, hm, hn, hk, nw, nj, i, t, errors, perr, jidx, nwords_cmp;
  integer lat, jit, rdy, rspr, gap, rstjob, rst_at, rst_hold, n_aborts, rstnoflush;
  integer seed;
  integer cyc, job_start, jsum, jmin, jmax, idle;
  integer n_reads, n_writes;
  logic [31:0] lfsr;
  logic [31:0] hv;
  logic [3:0] hf [0:6];

  // read queue
  logic [31:0] rq_data [0:1023];
  integer      rq_due  [0:1023];
  integer      rq_head, rq_tail, rq_cnt;

  typedef enum integer {J_GAP, J_CMD, J_WAIT, J_DONE} jstate_e;
  jstate_e jst;
  integer gap_left;
  logic running, held_rsp;
  logic [3:0] held_tag; logic [4:0] held_fl;
  logic job_active;

  function automatic logic [31:0] nxt(input logic [31:0] s);
    logic [31:0] x;
    begin x = s; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); nxt = x; end
  endfunction
  function automatic integer rnd(input integer mx);       // 0..mx
    begin lfsr = nxt(lfsr); rnd = (mx <= 0) ? 0 : (lfsr[23:4] % (mx + 1)); end
  endfunction

  // ---------------------------------------------------------------- the clocked process: memory model + job driver
  integer wi;
  always @(posedge clk) begin
    if (running) begin
      cyc = cyc + 1;
      // ----- memory port: accept requests (pre-edge values)
      if (mreq_v && mreq_r) begin
        if (mreq_addr[1:0] != 2'b00 || (mreq_addr >> 2) >= nw) begin
          perr = perr + 1; if (perr < 6) $display("PROTOCOL: bad memory address %0h (we=%0d)", mreq_addr, mreq_we);
        end else if (mreq_we) begin
          mem[mreq_addr >> 2] = mreq_wdata; n_writes = n_writes + 1;
        end else begin
          rq_data[rq_tail] = mem[mreq_addr >> 2]; rq_due[rq_tail] = cyc + lat + rnd(jit);
          if (rq_cnt > 0 && rq_due[rq_tail] < rq_due[(rq_tail + 1023) % 1024]) rq_due[rq_tail] = rq_due[(rq_tail + 1023) % 1024];  // keep order
          rq_tail = (rq_tail + 1) % 1024; rq_cnt = rq_cnt + 1; n_reads = n_reads + 1;
        end
      end
      if (mreq_v && !job_active) begin perr = perr + 1; if (perr < 6) $display("PROTOCOL: memory request while idle"); end
      // ----- memory port: drive next-cycle response and ready
      if (rq_cnt > 0 && rq_due[rq_head] <= cyc) begin
        mrsp_v <= 1'b1; mrsp_data <= rq_data[rq_head]; rq_head = (rq_head + 1) % 1024; rq_cnt = rq_cnt - 1;
      end else begin
        mrsp_v <= 1'b0; mrsp_data <= lfsr;                    // garbage when invalid
      end
      mreq_r <= (rnd(99) < rdy);

      // ----- completion channel monitoring
      if (held_rsp) begin
        if (!rsp_valid) begin perr = perr + 1; if (perr < 6) $display("PROTOCOL: rsp_valid fell without a transfer"); end
        else if (rsp_tag !== held_tag || rsp_flags !== held_fl) begin perr = perr + 1; if (perr < 6) $display("PROTOCOL: rsp payload changed while stalled"); end
      end
      held_rsp = rsp_valid && !rsp_ready; held_tag = rsp_tag; held_fl = rsp_flags;
      if (job_active && cmd_ready) begin perr = perr + 1; if (perr < 6) $display("PROTOCOL: cmd_ready high while a job is running"); end

      // ----- job driver
      case (jst)
        J_GAP: begin
          cmd_valid <= 1'b0;
          if (gap_left > 0) gap_left = gap_left - 1;
          else if (jidx < nj && rst_n) begin
            for (wi = 0; wi < j_npre[jidx]; wi = wi + 1) begin        // the "kernel stores" that precede this job
              mem[j_pidx[jidx * MAXPRE + wi]] = j_pval[jidx * MAXPRE + wi];
              exp_mem[j_pidx[jidx * MAXPRE + wi]] = j_pval[jidx * MAXPRE + wi];
            end
            jst <= J_CMD;
            cmd_valid <= 1'b1; cmd_a <= j_a[jidx]; cmd_b <= j_b[jidx]; cmd_c <= j_c[jidx];
            cmd_rm <= j_rm[jidx][2:0]; cmd_fmt <= j_fmt[jidx][0]; cmd_zero <= j_zero[jidx][0]; cmd_tag <= j_tag[jidx];
          end else jst <= J_DONE;
        end
        J_CMD: begin
          if (cmd_valid && cmd_ready) begin
            cmd_valid <= 1'b0; job_active = 1; job_start = cyc; jst <= J_WAIT;
            rst_at = (rstjob > 0 && rnd(99) < rstjob) ? cyc + 3 + rnd(59) : -1;
            cmd_a <= $random; cmd_b <= $random; cmd_c <= $random; cmd_rm <= $random; cmd_tag <= $random;  // garbage after acceptance
          end
        end
        J_WAIT: begin
          rsp_ready <= (rnd(99) < rspr);
          if (rsp_valid && rsp_ready) begin
            jsum = jsum + (cyc - job_start); if (cyc - job_start < jmin) jmin = cyc - job_start; if (cyc - job_start > jmax) jmax = cyc - job_start;
            if (rsp_tag !== j_tag[jidx] || rsp_flags !== j_fl[jidx][4:0]) begin
              errors = errors + 1; if (errors <= 10) $display("MISMATCH job %0d: tag/flags got %0h/%02h exp %0h/%02h", jidx, rsp_tag, rsp_flags, j_tag[jidx], j_fl[jidx][4:0]);
            end
            for (wi = 0; wi < CWN; wi = wi + 1) exp_mem[(j_c[jidx] >> 2) + wi] = j_d[jidx * CWN + wi];
            for (wi = 0; wi < nw; wi = wi + 1) begin
              if (mem[wi] !== exp_mem[wi]) begin
                errors = errors + 1;
                if (errors <= 10) $display("MISMATCH job %0d (fmt=%0d rm=%0d zero=%0d a=%0h b=%0h c=%0h): mem[%0d] got %08h exp %08h",
                  jidx, j_fmt[jidx], j_rm[jidx], j_zero[jidx], j_a[jidx], j_b[jidx], j_c[jidx], wi, mem[wi], exp_mem[wi]);
              end
            end
            job_active = 0; jidx = jidx + 1; gap_left = rnd(gap); jst <= J_GAP; rsp_ready <= 1'b0;
          end
        end
        default: ;
      endcase
      // ----- reset injection: abort the running job, flush the memory port, restore memory, retry the same job
      if (rst_hold > 0) begin rst_hold = rst_hold - 1; if (rst_hold == 0) rst_n <= 1'b1; end
      if (job_active && jst == J_WAIT && rst_at >= 0 && cyc >= rst_at) begin
        rst_at = -1; rst_n <= 1'b0; rst_hold = 2; n_aborts = n_aborts + 1;
        if (!rstnoflush) begin rq_head = 0; rq_tail = 0; rq_cnt = 0; mrsp_v <= 1'b0; end
        for (wi = 0; wi < nw; wi = wi + 1) mem[wi] = exp_mem[wi];
        job_active = 0; held_rsp = 0; jst <= J_GAP; gap_left = 4; cmd_valid <= 1'b0; rsp_ready <= 1'b0;
      end
      if (jst == J_WAIT || jst == J_CMD) begin idle = idle + 1; if (rsp_valid || mreq_v) idle = 0; end else idle = 0;
    end
  end

  // ---------------------------------------------------------------- setup and verdict
  initial begin
    errors = 0; perr = 0; running = 0; jidx = 0; cyc = 0; jsum = 0; jmin = 1 << 30; jmax = 0; idle = 0; n_reads = 0; n_writes = 0;
    rq_head = 0; rq_tail = 0; rq_cnt = 0; job_active = 0; held_rsp = 0; gap_left = 0; jst = J_GAP;
    cmd_valid = 0; rsp_ready = 0; mreq_r = 0; mrsp_v = 0; mrsp_data = 0; cmd_a = 0; cmd_b = 0; cmd_c = 0; cmd_rm = 0; cmd_fmt = 0; cmd_zero = 0; cmd_tag = 0;
    lat = 2; jit = 0; rdy = 70; rspr = 60; gap = 3; seed = 1; rstjob = 0; rstnoflush = 0; rst_at = -1; rst_hold = 0; n_aborts = 0;
    void'($value$plusargs("LAT=%d", lat)); void'($value$plusargs("JIT=%d", jit)); void'($value$plusargs("RDY=%d", rdy));
    void'($value$plusargs("RSTJOB=%d", rstjob)); void'($value$plusargs("RSTNOFLUSH=%d", rstnoflush)); void'($value$plusargs("RSPRDY=%d", rspr)); void'($value$plusargs("GAP=%d", gap)); void'($value$plusargs("SEED=%d", seed));
    lfsr = 32'hC0FFEE01 ^ seed;
    if (!$value$plusargs("VEC=%s", path)) begin $display("TB_RESULT mma_engine FAIL missing +VEC"); $finish; end
    fd = $fopen(path, "r");
    if (fd == 0) begin $display("TB_RESULT mma_engine FAIL cannot open vector file"); $finish; end
    rc = $fscanf(fd, "%d %d %d %d %d\n", hm, hn, hk, nw, nj);
    if (hm != M || hn != N || hk != K) begin $display("TB_RESULT mma_engine FAIL vector file is for %0dx%0dx%0d, DUT is %0dx%0dx%0d", hm, hn, hk, M, N, K); $finish; end
    if (nw > MAXW || nj > MAXJ) begin $display("TB_RESULT mma_engine FAIL vector file too large"); $finish; end
    for (i = 0; i < nw; i = i + 1) begin rc = $fscanf(fd, "%h\n", hv); mem[i] = hv; exp_mem[i] = hv; end
    for (i = 0; i < nj; i = i + 1) begin
      rc = $fscanf(fd, "%h %h %h %h %h %h %h %h\n", hf[0], hf[1], hf[2], j_a[i], j_b[i], j_c[i], hf[3], j_fl[i]);
      j_fmt[i] = hf[0]; j_rm[i] = hf[1]; j_zero[i] = hf[2]; j_tag[i] = hf[3];
      rc = $fscanf(fd, "%h", npre_i); j_npre[i] = npre_i;
      if (npre_i > MAXPRE) begin $display("TB_RESULT mma_engine FAIL too many preceding writes"); $finish; end
      for (t = 0; t < npre_i; t = t + 1) begin rc = $fscanf(fd, "%h %h", pk, hv); j_pidx[i * MAXPRE + t] = pk; j_pval[i * MAXPRE + t] = hv; end
      for (t = 0; t < CWN; t = t + 1) begin rc = $fscanf(fd, "%h", hv); j_d[i * CWN + t] = hv; end
    end
    $fclose(fd);
    repeat (3) @(posedge clk);
    #1 rst_n = 1;
    @(posedge clk); #1 running = 1;
    while (jst != J_DONE && idle < 20000) @(posedge clk);
    #1 running = 0;
    if (rstjob > 0 && n_aborts == 0) begin errors = errors + 1; $display("MISMATCH: +RSTJOB=%0d but no job was ever aborted (vacuous)", rstjob); end
    if (jst == J_DONE && errors == 0 && perr == 0)
      $display("TB_RESULT mma_engine PASS jobs=%0d tile=%0dx%0dx%0d P=%0d profile=%s cycles_per_job[min/avg/max]=%0d/%0d/%0d reads=%0d writes=%0d aborted_by_reset=%0d",
               nj, M, N, K, P, RESTRICTED ? "SFX-R   " : "SFX-IEEE", jmin, jsum / (nj > 0 ? nj : 1), jmax, n_reads, n_writes, n_aborts);
    else
      $display("TB_RESULT mma_engine FAIL errors=%0d protocol=%0d jobs_done=%0d of %0d (state %0d, idle %0d)", errors, perr, jidx, nj, jst, idle);
    $finish;
  end
endmodule
