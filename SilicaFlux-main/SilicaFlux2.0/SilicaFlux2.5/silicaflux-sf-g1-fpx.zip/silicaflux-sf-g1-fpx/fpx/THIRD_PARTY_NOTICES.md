# Third-party notices (fpx extension)

Nothing below is part of the synthesizable hardware. All of it is used only by verification flows.

| component | where | licence | how used |
|---|---|---|---|
| **Berkeley SoftFloat**, Release 3e (John R. Hauser) | `fpx/third_party/berkeley-softfloat-3/` | BSD-3-Clause, text in `COPYING.txt` in that directory | vendored **unmodified**; built locally by `fpx/ref/build_ref.sh` into a ctypes library and a static library; the oracle for the RTL differential harness and the Python cross-checks |
| **Berkeley TestFloat**, Release 3e (John R. Hauser) | `fpx/third_party/berkeley-testfloat-3/` | BSD-3-Clause, text in `COPYING.txt` in that directory | vendored **unmodified**; `testfloat_gen` supplies operand streams of hard cases |
| GNU MPFR / GMP, via `gmpy2` | *not redistributed*; an optional Python dependency | LGPL-3.0-or-later | an extra value-only cross-check of the Python reference (`sim/tests_fpx/test_fp_vs_softfloat.py`, skipped when absent) |
| NumPy | *not redistributed*; an optional Python dependency | BSD-3-Clause | only `sim/tests_fpx/test_hostfloat.py`, which demonstrates why host floating point is not an oracle |
| Icarus Verilog, Verilator, Yosys | *not redistributed*; tools | GPL-2.0, LGPL-3.0 / Artistic-2.0, ISC | simulation, lint, synthesis |

The vendored trees are exactly those shipped inside the sibling SilicaFlux module `silicaflux-hpc-fp32-fma.zip` (that module's `ref/build_ref.sh` header and `ref/REFERENCE.md` record the
upstream revisions: SoftFloat git f74b1e4, TestFloat git 06b2007). They are pinned by a tree hash in `fpx/PROVENANCE.json`;
`tools/check_fpx_provenance.py` fails if either changes. They were **not** re-compared with the upstream projects in this work.

No licensed arithmetic IP is included. The adapter and a simulation-only stand-in for such an IP are original SilicaFlux code
([docs/fpx/F5-ip-adapter.md](../docs/fpx/F5-ip-adapter.md)). Integrating a vendor IP brings that vendor's licence with it.
