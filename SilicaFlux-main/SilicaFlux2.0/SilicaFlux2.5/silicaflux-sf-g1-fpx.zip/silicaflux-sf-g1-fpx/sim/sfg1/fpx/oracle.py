"""Independent oracles used to validate the reference model (``fp.py``) and the RTL.

Oracle hierarchy (docs/fpx/F6-verification.md):

1. ``SoftFloat``    Berkeley SoftFloat 3e through ctypes (third-party, BSD-3-Clause, simulation only).
2. ``mpfr_fma``     GNU MPFR through gmpy2, values only (third-party, LGPL, optional).
3. exhaustive brute force on tiny formats lives in ``sim/tests_fpx/test_fp_exhaustive.py``.

Host floating point is deliberately **not** here: see ``hostfloat.py`` for why it is only a
labelled counter-example generator and never an oracle.
"""
from __future__ import annotations

import ctypes
import os
from pathlib import Path
from typing import Optional, Tuple

FPX_ROOT = Path(__file__).resolve().parents[3] / "fpx"
LIB_PATH = FPX_ROOT / "build" / "ref" / "libsfshim.so"
TESTFLOAT_DIR = FPX_ROOT / "build" / "ref" / "testfloat"

OPC_FMA, OPC_ADD, OPC_SUB, OPC_MUL = 0, 1, 2, 3


class OracleUnavailable(RuntimeError):
    pass


class SoftFloat:
    """Berkeley SoftFloat 3e (RISCV specialisation) behind ctypes."""

    def __init__(self, path: Optional[os.PathLike] = None) -> None:
        p = Path(path) if path else LIB_PATH
        if not p.exists():
            raise OracleUnavailable(f"{p} not built; run fpx/ref/build_ref.sh")
        lib = ctypes.CDLL(str(p))
        u = ctypes.c_uint
        lib.sf_f32_op.restype = ctypes.c_uint32
        lib.sf_f32_op.argtypes = [u, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, u, u, ctypes.POINTER(u)]
        lib.sf_f16_op.restype = ctypes.c_uint16
        lib.sf_f16_op.argtypes = [u, ctypes.c_uint16, ctypes.c_uint16, ctypes.c_uint16, u, u, ctypes.POINTER(u)]
        self._lib = lib

    def f32(self, op: int, a: int, b: int, c: int, rm: int, tin_after: int = 1) -> Tuple[int, int]:
        fl = ctypes.c_uint(0)
        r = self._lib.sf_f32_op(op, a & 0xFFFFFFFF, b & 0xFFFFFFFF, c & 0xFFFFFFFF, rm, tin_after, ctypes.byref(fl))
        return r, fl.value

    def f16(self, op: int, a: int, b: int, c: int, rm: int, tin_after: int = 1) -> Tuple[int, int]:
        fl = ctypes.c_uint(0)
        r = self._lib.sf_f16_op(op, a & 0xFFFF, b & 0xFFFF, c & 0xFFFF, rm, tin_after, ctypes.byref(fl))
        return r, fl.value


# --------------------------------------------------------------------------- MPFR (optional)
def mpfr_available() -> bool:
    try:
        import gmpy2  # noqa: F401
        return True
    except ImportError:
        return False


def mpfr_f32_fma(a: int, b: int, c: int, rm: int) -> Optional[int]:
    """binary32 ``a*b+c`` with ONE rounding computed by MPFR (value only; flags are not compared).

    Returns ``None`` when an operand is NaN or infinite or the result is NaN (those cases are
    pure rule tables, covered by the exhaustive and SoftFloat checks).  MPFR emulates binary32
    with ``precision=24, emin=-148, emax=128, subnormalize=True``.
    """
    import gmpy2
    from gmpy2 import mpfr
    import struct

    def val(bits: int):
        # exact binary32 -> mpfr without going through any host float arithmetic:
        # build from the integer significand and exponent.
        s = bits >> 31
        e = (bits >> 23) & 0xFF
        m = bits & 0x7FFFFF
        if e == 0xFF:
            return None
        if e == 0:
            n, ex = m, -149
        else:
            n, ex = m | 0x800000, e - 150
        x = gmpy2.mul_2exp(mpfr(n), ex)
        return -x if s else x

    modes = {0: gmpy2.RoundToNearest, 1: gmpy2.RoundToZero, 2: gmpy2.RoundDown, 3: gmpy2.RoundUp,
             4: gmpy2.RoundAwayZero}
    va, vb, vc = val(a), val(b), val(c)
    if va is None or vb is None or vc is None:
        return None
    if rm == 4:
        return None  # MPFR has no round-to-nearest-ties-away; RMM is covered by the other oracles
    ctx = gmpy2.context(precision=24, emin=-148, emax=128, subnormalize=True, round=modes[rm],
                        trap_overflow=False, trap_underflow=False, trap_inexact=False, trap_invalid=False,
                        trap_erange=False, trap_divzero=False)
    with ctx:
        # exact product then one fused rounding: gmpy2.fma rounds once
        r = gmpy2.fma(va, vb, vc)
    if gmpy2.is_nan(r):
        return None
    sign = 1 if gmpy2.is_signed(r) else 0
    if gmpy2.is_infinite(r):
        return (sign << 31) | (0xFF << 23)
    if r == 0:
        return sign << 31
    # decompose r (exact) into mantissa/exponent
    mant, exp = r.as_mantissa_exp()
    mant = int(mant)
    exp = int(exp)
    n = abs(mant)
    # normalise to binary32 fields
    nb = n.bit_length()
    e2 = nb - 1 + exp
    if e2 < -126:  # subnormal: value = n * 2^exp, field = value / 2^-149
        frac = n << (exp + 149) if exp + 149 >= 0 else n >> (-(exp + 149))
        return (sign << 31) | frac
    sh = 24 - nb
    n24 = n << sh if sh >= 0 else n >> (-sh)
    return (sign << 31) | ((e2 + 127) << 23) | (n24 & 0x7FFFFF)
