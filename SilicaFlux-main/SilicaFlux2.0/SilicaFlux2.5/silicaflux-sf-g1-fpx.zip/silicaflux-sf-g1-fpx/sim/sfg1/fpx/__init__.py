"""SilicaFlux SF-G1 optional floating-point and matrix-compute extension ("fpx").

Nothing in this package is imported by the base model: the base ``sfg1`` package, its tests and its
conformance gate behave identically whether or not this directory exists.
"""
