"""Host floating point: a labelled COUNTER-EXAMPLE generator, never an oracle.

The task brief forbids treating ordinary host floating-point arithmetic as an unquestioned
oracle, and this module shows why with a concrete, tested example (sim/tests_fpx/test_hostfloat.py):

* ``double_rounded_fma``  a fused multiply-add emulated through binary64 (``math.fma`` then a cast
  to binary32) rounds twice and is wrong when the first rounding lands exactly on a binary32
  midpoint.  It is a typical "just use the CPU" shortcut and it *fails* on a 3-operand example.
* ``unfused_fma``  ``float32(a)*float32(b)+float32(c)`` rounds twice by construction.
* host binary32 add/mul in round-to-nearest-even *do* agree with the reference on every vector we
  tried, but they offer no directed rounding, no flags, and depend on the process FP environment
  (MXCSR / FTZ / DAZ), so the project never relies on them.

Everything here goes through ``struct`` so that the conversion between bit patterns and host
floats is explicit.  Nothing in the verification flow imports this module except the tests that
demonstrate the counter-examples.
"""
from __future__ import annotations

import math
import struct

import numpy as np


def f32_from_bits(b: int) -> np.float32:
    return np.frombuffer(struct.pack("<I", b & 0xFFFFFFFF), dtype=np.float32)[0]


def bits_from_f32(x) -> int:
    return struct.unpack("<I", np.float32(x).tobytes())[0]


def double_rounded_fma(a: int, b: int, c: int) -> int:
    """binary32 bit pattern of ``float32(math.fma(double(a), double(b), double(c)))`` (two roundings)."""
    r = math.fma(float(f32_from_bits(a)), float(f32_from_bits(b)), float(f32_from_bits(c)))
    return bits_from_f32(r)


def unfused_fma(a: int, b: int, c: int) -> int:
    with np.errstate(all="ignore"):
        return bits_from_f32(f32_from_bits(a) * f32_from_bits(b) + f32_from_bits(c))


def host_add(a: int, b: int) -> int:
    with np.errstate(all="ignore"):
        return bits_from_f32(f32_from_bits(a) + f32_from_bits(b))


def host_mul(a: int, b: int) -> int:
    with np.errstate(all="ignore"):
        return bits_from_f32(f32_from_bits(a) * f32_from_bits(b))
