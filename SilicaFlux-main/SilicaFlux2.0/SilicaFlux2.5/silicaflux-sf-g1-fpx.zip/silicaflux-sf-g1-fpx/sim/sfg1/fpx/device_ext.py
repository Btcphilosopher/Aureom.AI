"""FpxDevice: the SF-G1 functional model plus the optional FP / matrix extension.

``FpxDevice`` subclasses the unmodified base ``Device``.  It adds

* the fpx instructions (ISA classes FPU and MMA), executed with the bit-accurate reference in ``fp.py`` / ``matrix.py``,
* per-thread sticky FP exception flags (IEEE profile),
* the capability registers CAPS_FPX / CAPS_MMA and the extension CFG_HASH,
* an ``mma_jobs`` log (parameters + operand/result words of every executed tile job) from which the RTL matrix
  engine is replayed on kernel-derived data (tools/fpx_kernel_check.py).

A kernel that does not use the new opcodes runs bit-identically to the base device (same commit trace digest):
that is checked by sim/tests_fpx/test_fpx_model.py against reference/*/report.json.
"""
from __future__ import annotations

import struct
from typing import Dict, List, Optional

from ..device import Device, Fault, ST_RUNNING, W_BARRIER, W_DONE, Warp, ExecutionGroup
from ..spec import Config, MASK32, device_spec
from . import fp, matrix as mx
from .config import FpxConfig, ext_isa, load_ext_spec

_EXT = load_ext_spec()
_CLS = {c["name"]: c["code"] for c in _EXT["classes"]}
_FN = {f["name"]: f["code"] for f in _EXT["fp_functions"]}
_MF = {f["name"]: f["code"] for f in _EXT["mma_functions"]}
FAULTS = {f["name"]: f["code"] for f in _EXT["faults"]}
EXT_REG_OFFSETS = {r["name"]: int(r["offset"], 0) for r in _EXT["registers"]}
_BASE_FAULTS = device_spec().faults


class FpxDevice(Device):
    def __init__(self, cfg: Optional[Config] = None, fpx: Optional[FpxConfig] = None, trace: bool = False,
                 poison: bool = True, record_stack: bool = False, log_mma: bool = False) -> None:
        self.fpx = fpx or FpxConfig.default()
        self.isa_ext = ext_isa()
        self.mma_jobs: Optional[List[Dict]] = [] if log_mma else None
        super().__init__(cfg, trace=trace, poison=poison, record_stack=record_stack)
        self.spec = _ExtSpecView(self.spec)       # fault names of the extension resolve in fault_name()

    # ------------------------------------------------------------------ registers
    def ext_hash(self) -> int:
        return self.fpx.cfg_hash(self.cfg)

    def reg_read(self, off: int) -> int:
        if off & 3 == 0 and off in EXT_REG_OFFSETS.values():
            name = next(k for k, v in EXT_REG_OFFSETS.items() if v == off)
            return self.fpx.caps_fpx() if name == "CAPS_FPX" else self.fpx.caps_mma()
        if off == self.spec.reg_offset["CFG_HASH"] and off & 3 == 0:
            return self.ext_hash()
        return super().reg_read(off)

    def reg_write(self, off: int, val: int) -> None:
        if off & 3 == 0 and off in EXT_REG_OFFSETS.values():
            return                                  # read-only registers: ignored, like the base RO registers
        super().reg_write(off, val)

    # ------------------------------------------------------------------ special registers
    def _sr_value(self, idx: int, w: Warp, lane: int) -> int:
        sr = self.isa_ext.special_registers
        if idx == sr["SR_FPX_CAPS"]:
            return self.fpx.caps_fpx()
        if idx == sr["SR_MMA_SHAPE"]:
            return self.fpx.caps_mma()
        return super()._sr_value(idx, w, lane)

    # ------------------------------------------------------------------ launch: decode with the merged ISA
    def _launch_phase(self) -> None:
        super()._launch_phase()
        if self.state == ST_RUNNING:
            self.decoded = [self.isa_ext.decode(x) for x in self.code]

    # ------------------------------------------------------------------ instruction issue
    def _issue(self, eg: ExecutionGroup, w: Warp) -> None:
        st = w.stack
        pc = st.pc
        if pc < self.code_words and not st.rpc_violation():
            d = self.decoded[pc]
            if not d.illegal and d.iclass in (_CLS["FPU"], _CLS["MMA"]):
                self._issue_ext(eg, w, d)
                return
        super()._issue(eg, w)

    def _flags(self, w: Warp) -> List[int]:
        fl = getattr(w, "fflags", None)
        if fl is None:
            fl = w.fflags = [0] * self.cfg.lanes
        return fl

    def _issue_ext(self, eg: ExecutionGroup, w: Warp, d) -> None:
        st, pc, regs = w.stack, w.stack.pc, w.regs
        word = self.code[pc]
        active = st.active
        L = self.cfg.lanes
        lanes = [i for i in range(L) if (active >> i) & 1]
        profile = self.fpx.profile
        want_trace = self.trace is not None
        wb = None
        mem = None

        def write(rd: int, vals: List[int]) -> None:
            nonlocal wb
            if rd:
                row = regs[rd]
                for l, v in zip(lanes, vals):
                    row[l] = v
                if want_trace:
                    wb = [rd, [[l, v] for l, v in zip(lanes, vals)]]

        if d.iclass == _CLS["FPU"]:
            fn, rm = d.alu_fn, d.imm & 7
            fl = self._flags(w)
            if fn <= _FN["MUL"]:
                ra, rb, rc = regs[d.rs1], regs[d.rs2], regs[d.rd]
                vals = []
                for l in lanes:
                    res, f = fp.unit_op(profile, fn, ra[l], rb[l], rc[l], rm)
                    vals.append(res)
                    if profile == fp.PROFILE_IEEE:
                        fl[l] |= f
                write(d.rd, vals)
            elif fn == _FN["RDFLAGS"]:
                write(d.rd, [fl[l] for l in lanes])
            else:  # SWAPFLAGS
                old = [fl[l] for l in lanes]
                if profile == fp.PROFILE_IEEE:
                    for l in lanes:
                        fl[l] = regs[d.rs1][l] & 0x1F
                write(d.rd, old)
            st.seq()
        else:
            mem = self._mma(eg, w, d, pc, lanes, active)
            st.seq()

        # ---- commit (same record as the base device)
        self.perf_issued += 1
        self.perf_lane_ops += len(lanes)
        if want_trace:
            self.trace.add({
                "wg": w.wg.wg_id, "warp": w.index, "seq": w.seq, "pc": pc, "insn": word,
                "mask": active, "wb": wb, "mem": mem,
                "npc": None if st.done else st.pc, "nmask": st.active, "depth": st.depth,
                "eg": eg.index, "tick": self.ticks_total,
            })
        w.seq += 1
        if st.done:
            w.state = W_DONE
        if w.state in (W_BARRIER, W_DONE):
            self._barrier_check(w.wg)

    # ------------------------------------------------------------------ the warp-collective tile instruction
    def _mma(self, eg: ExecutionGroup, w: Warp, d, pc: int, lanes: List[int], active: int):
        """mma / mmaz: all checks first (precise fault), then read everything, compute, write D in place."""
        st, regs, f = w.stack, w.regs, self.fpx
        if active != st.live:
            raise Fault(FAULTS["F_MMA_DIVERGENT"], pc, st.live)
        first = lanes[0]
        operands = []
        for name, reg in (("rd", d.rd), ("rs1", d.rs1), ("rs2", d.rs2)):
            row = regs[reg]
            for l in lanes:
                if row[l] != row[first]:
                    raise Fault(FAULTS["F_MMA_NONUNIFORM"], pc, row[l], l)
            operands.append(row[first] & MASK32)
        c_addr, a_addr, b_addr = operands
        limit = w.wg.shared_bytes
        for addr, nbytes in ((a_addr, f.a_bytes), (b_addr, f.b_bytes), (c_addr, f.c_bytes)):
            if addr & 3:
                raise Fault(_BASE_FAULTS["F_SMEM_ALIGN"], pc, addr, first)
            if addr + nbytes > limit:
                raise Fault(_BASE_FAULTS["F_SMEM_RANGE"], pc, addr, first)
        fmt, rm = (d.imm >> 3) & 1, d.imm & 7
        zero = d.alu_fn == _MF["MMAZ"]
        sm, base = eg.smem, w.wg.smem_base

        def rd_words(addr: int, n: int) -> List[int]:
            return list(struct.unpack_from(f"<{n}I", sm, base + addr))

        a_w, b_w, c_w = rd_words(a_addr, f.a_words), rd_words(b_addr, f.b_words), rd_words(c_addr, f.c_words)
        d_w, flags = mx.mma_tile(f.mma_m, f.mma_n, f.mma_k, fmt, rm, f.profile, a_w, b_w, None if zero else c_w)
        struct.pack_into(f"<{f.c_words}I", sm, base + c_addr, *d_w)
        if f.profile == fp.PROFILE_IEEE:
            fl = self._flags(w)
            for l in lanes:
                fl[l] |= flags
        if self.mma_jobs is not None:
            self.mma_jobs.append(dict(wg=w.wg.wg_id, warp=w.index, pc=pc, fmt=fmt, rm=rm, zero=int(zero),
                                      a=a_addr, b=b_addr, c=c_addr, a_words=a_w, b_words=b_w, c_words=c_w,
                                      d_words=d_w, flags=flags if f.profile == fp.PROFILE_IEEE else 0))
        return ["mma", [[a_addr, b_addr, c_addr, fmt, rm, int(zero)]]]


class _ExtSpecView:
    """Delegates to the base DeviceSpec but knows the extension's fault names."""

    def __init__(self, base) -> None:
        self._base = base
        self.error_names = dict(base.error_names)
        self.error_names.update({v: k for k, v in FAULTS.items()})

    def __getattr__(self, name):
        return getattr(self._base, name)
