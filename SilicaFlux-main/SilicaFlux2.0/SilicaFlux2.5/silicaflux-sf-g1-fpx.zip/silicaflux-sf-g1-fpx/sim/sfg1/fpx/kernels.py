"""Host-side helpers for the fpx example kernels: data layout, runners and bit-accurate references.

Tile-major layout used by examples/fpx/mma_gemm.sfa (docs/fpx/F4-matrix.md section 6):
    A  (Mt*TM) x (Kt*TK)   stored as Mt panels of KC chunks; chunk (ti,kc) is one A tile, tiles consecutive
    B  (Kt*TK) x (Nt*TN)   stored as Nt panels of KC chunks; chunk (tj,kc) is one B^T tile (TN rows x TK elements)
    C  (Mt*TM) x (Nt*TN)   stored as Mt*Nt tiles, each TM x TN row-major binary32
"""
from __future__ import annotations

import random
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from . import fp, matrix as mx
from .asm_ext import assemble, open_fpx
from .config import FpxConfig
from ..spec import Config

EXAMPLES_DIR = Path(__file__).resolve().parents[3] / "examples" / "fpx"


def kernel_source(name: str, fmt: int = mx.FMT_F16, rm: int = fp.RM_RNE) -> str:
    src = (EXAMPLES_DIR / f"{name}.sfa").read_text()
    if name == "mma_gemm":
        mods = f".{mx.FMT_NAMES[fmt]}.{fp.RM_NAMES[rm]}"
        src = src.replace("mmaz  r10", f"mmaz{mods} r10").replace("mma   r10", f"mma{mods} r10")
    return src


# --------------------------------------------------------------------------- FP32 SIMT GEMM
def sgemm_reference(A: Sequence[int], B: Sequence[int], M: int, N: int, K: int, fused: bool,
                    profile: int = fp.PROFILE_IEEE, rm: int = fp.RM_RNE) -> List[int]:
    """Row-major binary32 patterns.  fused: acc = fma(a,b,acc);  unfused: acc = add(acc, mul(a,b)) (two roundings)."""
    out = []
    for i in range(M):
        for j in range(N):
            acc = 0
            for k in range(K):
                a, b = A[i * K + k], B[k * N + j]
                if fused:
                    acc = fp.unit_op(profile, fp.OP_FMA, a, b, acc, rm)[0]
                else:
                    t = fp.unit_op(profile, fp.OP_MUL, a, b, 0, rm)[0]
                    acc = fp.unit_op(profile, fp.OP_ADD, acc, t, 0, rm)[0]
            out.append(acc)
    return out


def run_sgemm(kind: str, A: Sequence[int], B: Sequence[int], M: int, N: int, K: int,
              fpx: Optional[FpxConfig] = None, cfg: Optional[Config] = None, wg: int = 8):
    """Run sgemm_fused / sgemm_unfused on an FpxDevice; returns (C words, LaunchResult, host)."""
    host = open_fpx(cfg, fpx, trace=False)
    kern = host.load_kernel(assemble(kernel_source(f"sgemm_{kind}")).words)
    a, b, c = host.alloc(4 * M * K), host.alloc(4 * K * N), host.alloc(4 * M * N)
    host.write_words(a, A)
    host.write_words(b, B)
    host.write_words(c, [0xCCCCCCCC] * (M * N))
    res = host.launch(kern, grid=M, wg=min(wg, host.max_wg_threads), args=[a, b, c, N, K])
    return host.read_words(c, M * N), res, host


def rand_f32_matrix(rng: random.Random, n: int, dist: str = "uniform") -> List[int]:
    """Binary32 bit patterns from an exact construction (no host float arithmetic): sign, exponent, mantissa."""
    out = []
    for _ in range(n):
        s = rng.getrandbits(1) << 31
        if dist == "uniform":               # magnitude in [0.5, 1): the usual benign case
            out.append(s | (126 << 23) | rng.getrandbits(23))
        elif dist == "wide":                # exponents spread over 2^-12 .. 2^12
            out.append(s | ((127 + rng.randrange(-12, 13)) << 23) | rng.getrandbits(23))
        elif dist == "cancel":              # +-1 plus small noise: provokes cancellation
            out.append(s | ((127 + rng.randrange(-1, 1)) << 23) | (rng.getrandbits(8) << 15))
        else:
            raise ValueError(dist)
    return out


# --------------------------------------------------------------------------- tiled matrix-engine GEMM
def pack_gemm_tiles(A: Sequence[Sequence[int]], Bm: Sequence[Sequence[int]], f: FpxConfig):
    """A: Mtot x Ktot, Bm: Ktot x Ntot (16-bit patterns).  Returns (a_words, b_words, MT, NT, KC)."""
    Mtot, Ktot, Ntot = len(A), len(A[0]), len(Bm[0])
    TM, TN, TK = f.mma_m, f.mma_n, f.mma_k
    assert Mtot % TM == 0 and Ntot % TN == 0 and Ktot % TK == 0
    MT, NT, KC = Mtot // TM, Ntot // TN, Ktot // TK
    a_words: List[int] = []
    for ti in range(MT):
        for kc in range(KC):
            a_words += mx.pack_tile([A[ti * TM + r][kc * TK:(kc + 1) * TK] for r in range(TM)])
    b_words: List[int] = []
    for tj in range(NT):
        for kc in range(KC):
            b_words += mx.pack_tile([[Bm[kc * TK + kk][tj * TN + jj] for kk in range(TK)] for jj in range(TN)])
    return a_words, b_words, MT, NT, KC


def gemm_reference(A, Bm, fmt: int, rm: int, profile: int) -> List[List[int]]:
    """Monolithic definition: every C[i][j] is ONE sequential fused chain over all of K (+0 start). Tiling-independent."""
    Mtot, Ktot, Ntot = len(A), len(A[0]), len(Bm[0])
    out = []
    for i in range(Mtot):
        row = []
        for j in range(Ntot):
            row.append(mx.mma_chain_reference(A[i], [Bm[k][j] for k in range(Ktot)], 0, fmt, rm, profile)[0])
        out.append(row)
    return out


def run_mma_gemm(A, Bm, f: FpxConfig, fmt: int = mx.FMT_F16, rm: int = fp.RM_RNE, cfg: Optional[Config] = None,
                 log_mma: bool = False):
    """Run mma_gemm.sfa; returns (C matrix of binary32 patterns, LaunchResult, host)."""
    host = open_fpx(cfg, f, trace=False, log_mma=log_mma)
    cfg = host.cfg
    a_words, b_words, MT, NT, KC = pack_gemm_tiles(A, Bm, f)
    aw, bw, cw = f.a_words, f.b_words, f.c_words
    ga, gb, gc = host.alloc(4 * len(a_words)), host.alloc(4 * len(b_words)), host.alloc(4 * cw * MT * NT)
    host.write_words(ga, a_words)
    host.write_words(gb, b_words)
    host.write_words(gc, [0xCCCCCCCC] * (cw * MT * NT))
    table = []
    for ti in range(MT):
        for tj in range(NT):
            table += [ga + 4 * ti * KC * aw, gb + 4 * tj * KC * bw, gc + 4 * (ti * NT + tj) * cw]
    gt = host.alloc(4 * len(table))
    host.write_words(gt, table)
    kern = host.load_kernel(assemble(kernel_source("mma_gemm", fmt, rm)).words)
    lanes = host.lanes
    res = host.launch(kern, grid=MT * NT, wg=lanes, shared=4 * (aw + bw + cw),
                      args=[0, 0, 0, gt, KC, aw, bw, cw])
    cwords = host.read_words(gc, cw * MT * NT)
    C = [[0] * (NT * f.mma_n) for _ in range(MT * f.mma_m)]
    for ti in range(MT):
        for tj in range(NT):
            tile = cwords[(ti * NT + tj) * cw:(ti * NT + tj + 1) * cw]
            for r in range(f.mma_m):
                for c in range(f.mma_n):
                    C[ti * f.mma_m + r][tj * f.mma_n + c] = tile[r * f.mma_n + c]
    return C, res, host


def rand_matrix16(rng: random.Random, rows: int, cols: int, fmt: int, mode: str = "benign") -> List[List[int]]:
    """16-bit operand matrices: 'benign' (values around 1), 'wide' (many binades), 'mixed' (edge cases included)."""
    def one() -> int:
        if mode == "mixed":
            return mx.rand_elem(rng, fmt)
        s = rng.getrandbits(1) << 15
        if fmt == mx.FMT_F16:
            e = 15 if mode == "benign" else 15 + rng.randrange(-6, 7)
            return s | (e << 10) | rng.getrandbits(10)
        e = 127 if mode == "benign" else 127 + rng.randrange(-30, 31)
        return s | (e << 7) | rng.getrandbits(7)
    return [[one() for _ in range(cols)] for _ in range(rows)]
