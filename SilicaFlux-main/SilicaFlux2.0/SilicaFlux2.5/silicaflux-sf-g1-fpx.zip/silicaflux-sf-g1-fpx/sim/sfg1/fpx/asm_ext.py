"""Assembler, disassembler and host helper for the fpx extension.

Syntax additions (everything else is the base assembler language):

    fadd|fsub|fmul|ffma|ffms|ffnma|ffnms  rd, rs1, rs2        optional suffix  .rne .rtz .rdn .rup .rmm   (default .rne)
    mma|mmaz                              rd, rs1, rs2        suffixes  .f16 .bf16 (default .f16)  and a rounding mode
    frflags rd           fsflags rd, rs1

    ffma.rtz r3, r4, r5        mma.bf16.rdn r1, r2, r3
"""
from __future__ import annotations

from typing import List, Optional

from ..asm import Assembler, AsmResult, _Stmt, assemble_file as _base_assemble_file
from ..host import Host, LocalTransport
from ..spec import Config
from . import fp
from .config import FpxConfig, ext_isa
from .device_ext import FpxDevice

_MODS_RM = {n: c for c, n in fp.RM_NAMES.items()}
_MODS_FMT = {"f16": 0, "bf16": 1}


class FpxAssembler(Assembler):
    def __init__(self, num_regs: int = 16) -> None:
        super().__init__(num_regs)
        self.isa = ext_isa()

    def _classify(self, lineno: int, text: str, mnem: str, ops: List[str], pc: int) -> Optional[_Stmt]:
        if "." in mnem:
            base, *mods = mnem.split(".")
            d = self.isa.ext_by_mnemonic.get(base)
            if d is None:
                self._err(lineno, f"unknown mnemonic '{mnem}'")
                return None
            for m in mods:
                ok = m in _MODS_RM or (d["format"] == "MR" and m in _MODS_FMT)
                if not ok:
                    self._err(lineno, f"{base}: unknown modifier '.{m}'")
                    return None
            if sum(m in _MODS_RM for m in mods) > 1 or sum(m in _MODS_FMT for m in mods) > 1:
                self._err(lineno, f"{base}: contradictory or repeated modifiers '.{'.'.join(mods)}' (at most one rounding mode and one operand format)")
                return None
            if ops == [""]:
                ops = []
            return _Stmt(lineno, text, "insn", mnem, ops, pc, 1)
        return super()._classify(lineno, text, mnem, ops, pc)

    def _emit(self, st: _Stmt) -> List[int]:
        if st.kind == "insn" and "." in st.mnemonic:
            base, *mods = st.mnemonic.split(".")
            ins = self.isa.by_mnemonic[base]
            if len(st.operands) != len(ins.syntax):
                raise ValueError(f"expected {len(ins.syntax)} operand(s) ({', '.join(ins.syntax)}), got {len(st.operands)}")
            f = {"rd": 0, "rs1": 0, "rs2": 0}
            for tok, op in zip(ins.syntax, st.operands):
                f[tok] = self._regnum(op, st.line)
            imm = 0
            for m in mods:
                imm = (imm & ~7) | _MODS_RM[m] if m in _MODS_RM else imm | (_MODS_FMT[m] << 3)
            return [self.isa.encode(base, imm=imm, **f)]
        return super()._emit(st)


def assemble(source: str, filename: str = "<asm>", num_regs: int = 16) -> AsmResult:
    return FpxAssembler(num_regs).assemble(source, filename)


def assemble_file(path: str) -> AsmResult:
    with open(path, "r", encoding="utf-8") as fh:
        return assemble(fh.read(), path)


def disasm(word: int) -> str:
    """One instruction as text; extension instructions print their modifiers, the rest uses the base disassembler."""
    I = ext_isa()
    op = (word >> 26) & 0x3F
    if I.is_ext(op):
        dec = I.decode(word)
        if dec.illegal:
            return f".word 0x{word:08x}    ; illegal"
        ins = I.by_opcode[op]
        mods = []
        if "rm_valid" in ins.require:
            mods.append(fp.RM_NAMES[dec.imm & 7])
            if ins.fmt.name == "MR":
                mods.insert(0, "bf16" if (dec.imm >> 3) & 1 else "f16")
        fields = {"rd": dec.rd, "rs1": dec.rs1, "rs2": dec.rs2}
        return ".".join([ins.mnemonic] + mods) + " " + ", ".join(f"r{fields[t]}" for t in ins.syntax)
    from ..disasm import disassemble_word as disasm_word
    return disasm_word(word)


def open_fpx(cfg: Optional[Config] = None, fpx: Optional[FpxConfig] = None, trace: bool = False, log_mma: bool = False) -> Host:
    """A host attached to an FpxDevice (the host's hash check is replaced by the extension hash check)."""
    cfg = cfg or Config.default()
    fpx = fpx or FpxConfig.default()
    dev = FpxDevice(cfg, fpx, trace=trace, log_mma=log_mma)
    host = Host(LocalTransport(dev), cfg, check_hash=False)
    host.fpx, host.device = fpx, dev
    if dev.reg_read(8) != fpx.cfg_hash(cfg):
        raise RuntimeError("extension CFG_HASH mismatch")
    return host
