"""Conformance vectors for the fpx RTL blocks: the reference model's answers in a form SV testbenches read.

Rules (same as docs/09 V2): expected values come only from here, never from testbench logic.
Each generator returns the lines of a vector file.
"""
from __future__ import annotations

import random
from pathlib import Path
from typing import Callable, Dict, List

from . import fp, matrix as mx
from .config import FpxConfig, ext_isa
from .vectors_fp import F32_EDGE, random_triples

I = ext_isa()


# ------------------------------------------------------------------------------- unit
def unit_vectors(cfg: FpxConfig, rng: random.Random, n_random: int = 4500, n_edge_triples: int = 2500) -> List[str]:
    """op rm a b c result flags   (hex; rm in decimal-hex).  Every op x every rounding mode on random and edge operands."""
    recs = []
    triples = list(random_triples(n_random, rng.randrange(1 << 30)))
    edge = [(a, b, c) for a in F32_EDGE for b in F32_EDGE for c in F32_EDGE]
    rng.shuffle(edge)
    triples += edge[:n_edge_triples]
    # all-pairs edge for the unfused/two-operand ops (small): cover every class combination
    pairs = [(a, b, rng.choice(F32_EDGE)) for a in F32_EDGE for b in F32_EDGE]
    triples += pairs
    for a, b, c in triples:
        for op in range(7):
            rm = rng.randrange(5) if cfg.profile == fp.PROFILE_IEEE else rng.randrange(8)
            res, fl = fp.unit_op(cfg.profile, op, a, b, c, rm)
            recs.append(f"{op:x} {rm:x} {a:08x} {b:08x} {c:08x} {res:08x} {fl:02x}")
    # every rounding mode on the interesting hard cases (halfway, tie-to-even, carry, subnormal boundary)
    hard = [(((127 - 100) << 23), 0x80000000 | ((127 - 50) << 23), 0x00800000),     # 2^-100 * -2^-50 + 2^-126: rounds UP into the smallest normal (F1 4.3)
            (0x3F800000, 0x3F800001, 0x33800000), (0x00800000, 0x3F000000, 0), (0x7F7FFFFF, 0x3F800001, 0),
            (0x3F800000, 0x3F800000, 0xB3800000), (0x00000001, 0x3F000000, 0), (0x007FFFFF, 0x3F800000, 0x00000001)]
    for a, b, c in hard:
        for op in range(7):
            for rm in (range(5) if cfg.profile == fp.PROFILE_IEEE else (0,)):
                res, fl = fp.unit_op(cfg.profile, op, a, b, c, rm)
                recs.append(f"{op:x} {rm:x} {a:08x} {b:08x} {c:08x} {res:08x} {fl:02x}")
    return [str(len(recs))] + recs


# ------------------------------------------------------------------------------- widen
def widen_vectors(cfg: FpxConfig, rng: random.Random) -> List[str]:
    """fmt x y for ALL 65536 16-bit patterns in both formats."""
    out = [str(2 * 65536)]
    for fmt in (mx.FMT_F16, mx.FMT_BF16):
        src = mx.FMT_OF[fmt]
        for x in range(65536):
            out.append(f"{fmt:x} {x:04x} {fp.widen(src, x):08x}")
    return out


# ------------------------------------------------------------------------------- decode
def decode_vectors(cfg: FpxConfig, rng: random.Random) -> List[str]:
    """word and packed record {base record, rd_re} for ext + base opcodes, reserved bits, bad rounding modes."""
    words: List[int] = []
    for d in I.raw["instructions"]:
        pass
    for mnem, ins in I.by_mnemonic.items():
        for _ in range(40):
            kw = {}
            for name, fl in ins.fmt.fields.items():
                lo, hi = (-(1 << (fl.width - 1)), (1 << (fl.width - 1)) - 1) if fl.signed else (0, (1 << fl.width) - 1)
                kw[name] = rng.choice([lo, hi, 0, 1, rng.randint(lo, hi)])
            if "imm2_nonzero" in ins.require and kw.get("imm2", 1) == 0:
                kw["imm2"] = rng.randint(1, 2047)
            if "valid_sr" in ins.require:
                kw["imm"] = rng.choice(sorted(I.valid_sr))
            if "rm_valid" in ins.require:
                kw["imm"] = (kw.get("imm", 0) & ~7) | rng.randrange(5)
            words.append(I.encode(mnem, **kw))
    for opc, d in I.ext_by_opcode.items():                   # every ext opcode: every rounding-mode value, reserved bits
        ins = I.by_opcode[opc]
        for rmv in range(8):
            for fmtbit in (0, 1):
                w = (opc << 26) | rng.getrandbits(14) & 0x3FFF | 0
                words.append((opc << 26) | (rng.getrandbits(12) << 14) | (rmv | (fmtbit << 3)))
        for b in range(26):
            if ins.fmt.reserved_mask >> b & 1:
                words.append((opc << 26) | (1 << b))
    for sr in range(32):                                       # every special-register index, base and extension
        words.append(I.encode("rdsr", rd=3, imm=sr))
    for op in range(64):
        words += [(op << 26) | rng.getrandbits(26) for _ in range(30)]
    words += [rng.getrandbits(32) for _ in range(1500)]
    out = [str(len(words))]
    for w in words:
        dec = I.decode(w)
        ins = I.by_opcode.get((w >> 26) & 0x3F)
        rd_re = int(bool(ins) and not dec.illegal and "rd" in ins.reads and I.is_ext((w >> 26) & 0x3F))
        out.append(f"{w:08x} {(dec.pack() << 1) | rd_re:x}")
    return out


# ------------------------------------------------------------------------------- matrix engine
def mma_engine_vectors(cfg: FpxConfig, rng: random.Random, njobs: int = 0, nwords: int = 1024) -> List[str]:
    """Header ``M N K nwords njobs``; initial image; then per job: parameters, preceding writes, expected D tile."""
    njobs = njobs or max(24, min(160, 16000 // (cfg.mma_m * cfg.mma_n * cfg.mma_k)))   # fewer, larger jobs for big tiles
    init, jobs = mx.gen_conformance_jobs(cfg.mma_m, cfg.mma_n, cfg.mma_k, cfg.profile, njobs, rng.randrange(1 << 30), nwords)
    out = [f"{cfg.mma_m} {cfg.mma_n} {cfg.mma_k} {nwords} {len(jobs)}"]
    out += [f"{w:08x}" for w in init]
    for t, j in enumerate(jobs):
        out.append(f"{j['fmt']:x} {j['rm']:x} {j['zero']:x} {4 * j['a']:x} {4 * j['b']:x} {4 * j['c']:x} {t & 0xF:x} {j['flags']:02x}")
        out.append(f"{len(j['pre']):x} " + " ".join(f"{i:x} {v:08x}" for i, v in j["pre"]))   # writes preceding the job
        out.append(" ".join(f"{w:08x}" for w in j["d_words"]))
    return out


GENERATORS: Dict[str, Callable[[FpxConfig, random.Random], List[str]]] = {
    "fpx_unit": unit_vectors,
    "fpx_widen": widen_vectors,
    "fpx_decode": decode_vectors,
    "mma_engine": mma_engine_vectors,
}


def write_vectors(cfg: FpxConfig, out_dir: Path, seed: int = 20261121) -> Dict[str, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    paths = {}
    for name, gen in GENERATORS.items():
        rng = random.Random(f"{seed}:{name}:{cfg.name}")
        p = out_dir / f"{name}.vec"
        p.write_text("\n".join(gen(cfg, rng)) + "\n")
        paths[name] = p
    return paths
