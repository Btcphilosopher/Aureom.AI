"""Operand generators shared by tests, vector files and the RTL harness (bit patterns only)."""
from __future__ import annotations

import random
from typing import Iterator, List, Tuple

# binary32 special/edge bit patterns: every class and every binade boundary that matters
F32_EDGE = [
    0x00000000, 0x80000000,                          # +-0
    0x00000001, 0x80000001,                          # +-min subnormal
    0x00000002, 0x00400000, 0x007FFFFE, 0x007FFFFF,  # subnormals incl. max subnormal
    0x80400000, 0x807FFFFF,
    0x00800000, 0x80800000,                          # +-min normal
    0x00800001, 0x00FFFFFF, 0x01000000,
    0x3F7FFFFF, 0x3F800000, 0x3F800001,              # 1-ulp, 1, 1+ulp
    0xBF800000, 0xBF7FFFFF,
    0x3F000000, 0x40000000, 0x40400000, 0x40490FDB,  # 0.5, 2, 3, pi
    0x4B000000, 0x4B7FFFFF, 0x4B800000,              # 2^23, 2^24 boundary
    0x7F7FFFFF, 0xFF7FFFFF,                          # +-max finite
    0x7F000000, 0x7E800000, 0x1F800000, 0x20000000,  # large / small exponents
    0x7F800000, 0xFF800000,                          # +-inf
    0x7FC00000, 0xFFC00000,                          # +-qNaN (canonical, negative)
    0x7FC00001, 0x7FFFFFFF,                          # qNaN with payload
    0x7F800001, 0xFF800001, 0x7FBFFFFF,              # sNaN
]


def _rand32(rng: random.Random, kind: int) -> int:
    if kind == 0:
        return rng.getrandbits(32)
    if kind == 1:                                       # near-equal exponents: cancellation territory
        return (rng.getrandbits(1) << 31) | ((124 + rng.randrange(8)) << 23) | rng.getrandbits(23)
    if kind == 2:                                       # tiny: subnormal / underflow territory
        return (rng.getrandbits(1) << 31) | (rng.randrange(0, 24) << 23) | rng.getrandbits(23)
    if kind == 3:                                       # huge: overflow territory
        return (rng.getrandbits(1) << 31) | ((rng.randrange(0xE0, 0xFF)) << 23) | rng.getrandbits(23)
    if kind == 4:                                       # sparse mantissa (exact / tie territory)
        m = 0
        for _ in range(rng.randrange(0, 4)):
            m |= 1 << rng.randrange(23)
        return (rng.getrandbits(1) << 31) | (rng.randrange(100, 154) << 23) | m
    return rng.choice(F32_EDGE)


def random_operand(rng: random.Random) -> int:
    return _rand32(rng, rng.choices(range(6), weights=[3, 3, 2, 2, 2, 3])[0])


def random_triples(n: int, seed: int) -> Iterator[Tuple[int, int, int]]:
    rng = random.Random(seed)
    for _ in range(n):
        yield random_operand(rng), random_operand(rng), random_operand(rng)


def edge_triples() -> List[Tuple[int, int, int]]:
    e = F32_EDGE
    return [(a, b, c) for a in e for b in e for c in e]
