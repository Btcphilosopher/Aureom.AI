"""Tile semantics of the SF-G1 matrix engine (docs/fpx/F4-matrix.md): the reference for sf_mma_engine.

Layout (all tiles live in workgroup shared memory, 32-bit little-endian words):

    A    M x K   16-bit elements, row-major, two per word: the element with the LOWER k is in the LOW half
    B    N x K   16-bit elements, "B transposed": row j of the stored tile is column j of the matrix B
    C/D  M x N   binary32, row-major, one word per element; D overwrites C in place

Accumulation order (normative, not an implementation choice):

    for every output element (i, j):  acc = C[i][j]  (or +0)
        for k = 0 .. K-1 (ascending):   acc = fma(widen(A[i][k]), widen(B[j][k]), acc)      one fused rounding / step
        D[i][j] = acc

Because each step is an ordinary fused multiply-add on binary32 and the accumulator is stored as binary32
between jobs, chaining jobs over successive K-chunks is IDENTICAL, bit for bit, to one long chain over all of K.
"""
from __future__ import annotations

import random
from typing import List, Optional, Sequence, Tuple

from . import fp

FMT_F16, FMT_BF16 = 0, 1
FMT_NAMES = {FMT_F16: "f16", FMT_BF16: "bf16"}
FMT_OF = {FMT_F16: fp.F16, FMT_BF16: fp.BF16}


def pack_elems(elems: Sequence[int]) -> List[int]:
    """16-bit elements -> 32-bit words (lower index in the low half)."""
    assert len(elems) % 2 == 0
    return [(elems[i] & 0xFFFF) | ((elems[i + 1] & 0xFFFF) << 16) for i in range(0, len(elems), 2)]


def unpack_elems(words: Sequence[int]) -> List[int]:
    out: List[int] = []
    for w in words:
        out += [w & 0xFFFF, (w >> 16) & 0xFFFF]
    return out


def pack_tile(rows: Sequence[Sequence[int]]) -> List[int]:
    """rows x K 16-bit elements -> words, row-major."""
    out: List[int] = []
    for r in rows:
        out += pack_elems(r)
    return out


def unpack_tile(words: Sequence[int], rows: int, K: int) -> List[List[int]]:
    el = unpack_elems(words)
    return [el[r * K:(r + 1) * K] for r in range(rows)]


def mma_tile(M: int, N: int, K: int, fmt: int, rm: int, profile: int, a_words: Sequence[int],
             b_words: Sequence[int], c_words: Optional[Sequence[int]]) -> Tuple[List[int], int]:
    """D = C + A x B.  ``c_words=None`` means a zero-C job (accumulators start at +0).  Returns (D words, flags)."""
    A = unpack_tile(a_words, M, K)
    B = unpack_tile(b_words, N, K)
    src = FMT_OF[fmt]
    flags = 0
    D: List[int] = []
    for i in range(M):
        for j in range(N):
            acc = 0 if c_words is None else c_words[i * N + j] & 0xFFFFFFFF
            for k in range(K):
                acc, f = fp.unit_op(profile, fp.OP_FMA, fp.widen(src, A[i][k]), fp.widen(src, B[j][k]), acc, rm)
                flags |= f
            D.append(acc)
    return D, flags


def mma_chain_reference(a_elems: Sequence[int], b_elems: Sequence[int], c0: int, fmt: int, rm: int,
                        profile: int) -> Tuple[int, int]:
    """One output element: the definition, written as a bare chain (used to cross-check ``mma_tile``)."""
    src = FMT_OF[fmt]
    acc, flags = c0, 0
    for a, b in zip(a_elems, b_elems):
        acc, f = fp.unit_op(profile, fp.OP_FMA, fp.widen(src, a), fp.widen(src, b), acc, rm)
        flags |= f
    return acc, flags


# ---------------------------------------------------------------------------- operand generators
F16_EDGE = [0x0000, 0x8000, 0x0001, 0x8001, 0x03FF, 0x0400, 0x3C00, 0xBC00, 0x3555, 0x7BFF, 0xFBFF, 0x7C00,
            0xFC00, 0x7E00, 0x7C01, 0x5640, 0x0200, 0x0003]
BF16_EDGE = [0x0000, 0x8000, 0x0001, 0x8001, 0x007F, 0x0080, 0x3F80, 0xBF80, 0x7F7F, 0xFF7F, 0x7F80, 0xFF80,
             0x7FC0, 0x7F81, 0x4B00, 0x0040, 0x1F80, 0x6000]


def rand_elem(rng: random.Random, fmt: int, mode: str = "mixed") -> int:
    edge = F16_EDGE if fmt == FMT_F16 else BF16_EDGE
    if mode == "finite":
        while True:
            x = rng.choice(edge) if rng.random() < 0.15 else rng.getrandbits(16)
            if fp.unpack(FMT_OF[fmt], x)[1] in (fp.ZERO, fp.FIN):
                return x
    r = rng.random()
    if r < 0.18:
        return rng.choice(edge)
    if r < 0.30:                                   # subnormal operand
        return (rng.getrandbits(1) << 15) | rng.randrange(1, 0x80 if fmt == FMT_BF16 else 0x400)
    if r < 0.40 and fmt == FMT_BF16:               # huge bf16: overflow territory
        return (rng.getrandbits(1) << 15) | (rng.randrange(0xC0, 0xFF) << 7) | rng.getrandbits(7)
    return rng.getrandbits(16)


def rand_acc(rng: random.Random) -> int:
    r = rng.random()
    if r < 0.2:
        return rng.choice([0, 0x80000000, 0x00000001, 0x007FFFFF, 0x3F800000, 0xBF800000, 0x7F7FFFFF, 0x7F800000, 0x7FC00000])
    if r < 0.4:
        return (rng.getrandbits(1) << 31) | (rng.randrange(0, 30) << 23) | rng.getrandbits(23)    # tiny
    if r < 0.5:
        return (rng.getrandbits(1) << 31) | (rng.randrange(0xE0, 0xFF) << 23) | rng.getrandbits(23)  # huge
    return rng.getrandbits(32)


def gen_conformance_jobs(M: int, N: int, K: int, profile: int, njobs: int, seed: int, nwords: int = 1024):
    """A random program of tile jobs over a small shared-memory image, with model-computed results.

    Returns ``(initial_image, jobs)`` where each job is a dict with its parameters, the operand writes ``pre``
    (word index, value) that precede it, and the model's ``d_words`` / ``flags``.
    The image evolves job by job (``D`` is written in place), jobs may chain (C of one = C of the next) and
    tiles may alias each other: the engine and the model both implement "read all, then write all".
    """
    rng = random.Random(seed)
    HK = K // 2
    a_w, b_w, c_w = M * HK, N * HK, M * N
    mem = [0] * nwords
    for i in range(nwords):                         # background: random words, a few of them edge patterns
        mem[i] = rng.getrandbits(32)
    init = list(mem)
    jobs = []
    last_c = None
    for _ in range(njobs):
        fmt = rng.randrange(2)
        rm = rng.randrange(5) if profile == fp.PROFILE_IEEE else rng.randrange(8)
        zero = rng.random() < 0.25
        kind = rng.random()
        a0 = rng.randrange(0, nwords - a_w)
        b0 = rng.randrange(0, nwords - b_w)
        c0 = rng.randrange(0, nwords - c_w)
        if last_c is not None and kind < 0.30:      # chain: accumulate into the previous output tile
            c0 = last_c
        elif kind < 0.40:                           # D aliases A (the instruction reads everything first)
            a0 = rng.randrange(0, nwords - max(a_w, c_w)); c0 = a0
        elif kind < 0.48:                           # D aliases B
            b0 = rng.randrange(0, nwords - max(b_w, c_w)); c0 = b0
        # "kernel stores" before the mma: freshly generated operands for most jobs, recorded so that the RTL
        # testbench replays exactly the same writes into its memory
        pre = []
        if rng.random() < 0.85:
            for w in range(a_w):
                v = pack_elems([rand_elem(rng, fmt), rand_elem(rng, fmt)])[0]
                mem[a0 + w] = v; pre.append((a0 + w, v))
            for w in range(b_w):
                v = pack_elems([rand_elem(rng, fmt), rand_elem(rng, fmt)])[0]
                mem[b0 + w] = v; pre.append((b0 + w, v))
            if not zero and kind >= 0.30:
                for w in range(c_w):
                    v = rand_acc(rng)
                    mem[c0 + w] = v; pre.append((c0 + w, v))
        a_words = mem[a0:a0 + a_w]
        b_words = mem[b0:b0 + b_w]
        c_words = None if zero else mem[c0:c0 + c_w]
        d_words, flags = mma_tile(M, N, K, fmt, rm, profile, a_words, b_words, c_words)
        mem[c0:c0 + c_w] = d_words
        jobs.append(dict(fmt=fmt, rm=rm, zero=int(zero), a=a0, b=b0, c=c0, pre=pre, d_words=d_words, flags=flags))
        last_c = c0
    return init, jobs
