"""Configuration, merged ISA and decoder of the SF-G1 FP / matrix extension.

Loads ``spec/ext/sf_g1_fpx.json`` (the extension's single source of truth) and exposes

* ``FpxConfig``  validated extension parameters + the CFG_HASH of (base specification + extension),
* ``ExtIsa``     the base ``Isa`` extended with the fpx instruction set, formats, special registers;
                 its ``decode`` is the reference for the generated ``sf_fpx_decode`` RTL function.

The base ``sfg1`` modules are not modified: ``ExtIsa`` is built from copies of the base raw JSON.
"""
from __future__ import annotations

import copy
import json
import zlib
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, List, Optional

from ..isa import Decoded, Insn, Isa, isa as base_isa
from ..spec import Config, MASK32, SPEC_DIR, _strip_docs, canonical_json

EXT_DIR = SPEC_DIR / "ext"


def load_ext_spec() -> Dict[str, Any]:
    with open(EXT_DIR / "sf_g1_fpx.json", "r", encoding="utf-8") as f:
        return json.load(f)


class FpxConfigError(ValueError):
    pass


@dataclass(frozen=True)
class FpxConfig:
    name: str = "fpx-ieee"
    profile: int = 0
    mma_m: int = 4
    mma_n: int = 4
    mma_k: int = 8
    mma_pes: int = 4
    fp_pipe_cfg: int = 30

    # ----------------------------------------------------------------- construction
    @staticmethod
    def parameter_table() -> Dict[str, Any]:
        return load_ext_spec()["parameters"]

    @classmethod
    def from_dict(cls, params: Dict[str, Any], name: str = "custom") -> "FpxConfig":
        table = cls.parameter_table()
        unknown = set(params) - set(table)
        if unknown:
            raise FpxConfigError(f"unknown extension parameter(s): {sorted(unknown)}")
        vals = {k: v["default"] for k, v in table.items()}
        vals.update(params)
        cfg = cls(name=name, **vals)
        cfg.validate()
        return cfg

    @classmethod
    def from_file(cls, name_or_path: str) -> "FpxConfig":
        p = Path(name_or_path)
        if not p.exists():
            p = EXT_DIR / "configs" / f"{name_or_path}.json"
        with open(p, "r", encoding="utf-8") as f:
            d = json.load(f)
        return cls.from_dict(d.get("parameters", {}), name=d.get("name", p.stem))

    @classmethod
    def default(cls) -> "FpxConfig":
        return cls.from_file("fpx-ieee")

    @staticmethod
    def named() -> List["FpxConfig"]:
        return [FpxConfig.from_file(p.stem) for p in sorted((EXT_DIR / "configs").glob("*.json"))]

    def parameters(self) -> Dict[str, int]:
        return {k: getattr(self, k) for k in self.parameter_table()}

    def validate(self) -> None:
        for k, meta in self.parameter_table().items():
            v = getattr(self, k)
            if not isinstance(v, int) or isinstance(v, bool):
                raise FpxConfigError(f"{k} must be an integer, got {v!r}")
            if "allowed" in meta and v not in meta["allowed"]:
                raise FpxConfigError(f"{k}={v} not in allowed set {meta['allowed']}")
            if "min" in meta and v < meta["min"]:
                raise FpxConfigError(f"{k}={v} below minimum {meta['min']}")
            if "max" in meta and v > meta["max"]:
                raise FpxConfigError(f"{k}={v} above maximum {meta['max']}")
        if self.mma_k % 2:
            raise FpxConfigError("mma_k must be even (two 16-bit elements per word)")
        if (self.mma_m * self.mma_n) % self.mma_pes:
            raise FpxConfigError("mma_pes must divide mma_m*mma_n")

    # ----------------------------------------------------------------- derived
    @property
    def restricted(self) -> bool:
        return self.profile == 1

    @property
    def fma_latency(self) -> int:
        return 1 + bin(self.fp_pipe_cfg).count("1")

    @property
    def a_words(self) -> int:
        return self.mma_m * self.mma_k // 2

    @property
    def b_words(self) -> int:
        return self.mma_n * self.mma_k // 2

    @property
    def c_words(self) -> int:
        return self.mma_m * self.mma_n

    @property
    def a_bytes(self) -> int:
        return 4 * self.a_words

    @property
    def b_bytes(self) -> int:
        return 4 * self.b_words

    @property
    def c_bytes(self) -> int:
        return 4 * self.c_words

    def caps_fpx(self) -> int:
        return 0b11 | (self.profile << 2) | (1 << 3) | (1 << 4)

    def caps_mma(self) -> int:
        return (self.mma_k << 16) | (self.mma_n << 8) | self.mma_m

    # ----------------------------------------------------------------- hash
    def hash_payload(self, base: Config) -> Dict[str, Any]:
        return {"base": base.hash_payload(), "fpx": {"params": self.parameters(), "spec": _strip_docs(load_ext_spec())}}

    def cfg_hash(self, base: Optional[Config] = None) -> int:
        base = base or Config.default()
        return zlib.crc32(canonical_json(self.hash_payload(base)).encode("utf-8")) & MASK32


# --------------------------------------------------------------------------- merged ISA
class ExtIsa(Isa):
    """Base ISA plus the fpx instructions.  ``rm_valid`` is the only extra decode rule."""

    def __init__(self) -> None:
        base_raw = base_isa().raw
        ext = load_ext_spec()
        raw = copy.deepcopy(base_raw)
        raw["formats"].update(copy.deepcopy(ext["formats"]))
        raw["classes"] += copy.deepcopy(ext["classes"])
        raw["special_registers"] += copy.deepcopy(ext["special_registers"])
        # fpx instructions are expressed with an 'fn' selector; Isa expects an ALU function name, so they are
        # added after construction (the base alu table must stay exactly the base table).
        super().__init__(raw)
        self.ext = ext
        self.fn_codes = {f["name"]: f["code"] for f in ext["fp_functions"]}
        self.mma_codes = {f["name"]: f["code"] for f in ext["mma_functions"]}
        self.ext_by_mnemonic: Dict[str, Dict[str, Any]] = {}
        self.ext_by_opcode: Dict[int, Dict[str, Any]] = {}
        for d in ext["instructions"]:
            fmt = self.formats[d["format"]]
            fn_table = self.fn_codes if d["class"] == "FPU" else self.mma_codes
            ins = Insn(
                mnemonic=d["mnemonic"], opcode=d["opcode"], fmt=fmt, iclass=d["class"],
                iclass_code=self.classes[d["class"]], alu="ADD", alu_code=fn_table[d["fn"]], b_imm=False,
                reads=tuple(d.get("reads", [])), writes_rd=bool(d.get("writes_rd", False)),
                syntax=tuple(d["syntax"]), require=tuple(d.get("require", [])), imm_shift=0,
                doc=d.get("doc", ""), semantics=d.get("semantics", ""))
            if ins.mnemonic in self.by_mnemonic or ins.opcode in self.by_opcode:
                raise ValueError(f"fpx instruction {ins.mnemonic}/{ins.opcode} collides with the base ISA")
            self.by_mnemonic[ins.mnemonic] = ins
            self.by_opcode[ins.opcode] = ins
            self.ext_by_mnemonic[ins.mnemonic] = d
            self.ext_by_opcode[ins.opcode] = d
        self.valid_sr = set(self.special_registers.values())

    def is_ext(self, opcode: int) -> bool:
        return opcode in self.ext_by_opcode

    def decode(self, word: int) -> Decoded:
        word &= MASK32
        opcode = (word >> self.opcode_lo) & 0x3F
        if opcode not in self.ext_by_opcode:
            return super().decode(word)
        ins = self.by_opcode[opcode]
        if word & ins.fmt.reserved_mask:
            return Decoded(illegal=1)
        raw = {n: (word >> fl.lo) & ((1 << fl.width) - 1) for n, fl in ins.fmt.fields.items()}
        if "rm_valid" in ins.require and (raw.get("imm", 0) & 7) > 4:
            return Decoded(illegal=1)
        return Decoded(
            illegal=0, iclass=ins.iclass_code, opcode=opcode, rd=raw.get("rd", 0), rs1=raw.get("rs1", 0),
            rs2=raw.get("rs2", 0), rd_we=int(ins.writes_rd), rs1_re=int("rs1" in ins.reads),
            rs2_re=int("rs2" in ins.reads), alu_fn=ins.alu_code, b_imm=0, imm=raw.get("imm", 0), imm2=0,
            mnemonic=ins.mnemonic)

    @staticmethod
    def rd_re(ins: Insn) -> int:
        return int("rd" in ins.reads)


@lru_cache(maxsize=1)
def ext_isa() -> ExtIsa:
    return ExtIsa()
