"""Numerical error study: measured accumulation error of the SF-G1 matrix semantics against EXACT arithmetic.

Everything here is integer / Fraction arithmetic.  The "truth" for a dot product  c0 + sum_k a_k*b_k  is computed
exactly (operands are dyadic rationals), the method under test is evaluated with the bit-accurate reference in
``fp.py``, and the error is an exact rational.  Host floating point is never used to compute an error; floats appear
only when a finished statistic is printed.

Methods (all binary32 accumulation of exactly-widened 16-bit operands unless noted)
    chain_fused      THE SF-G1 SEMANTICS: k ascending, acc = fma(a, b, acc), one rounding per step
    chain_unfused    k ascending, t = round(a*b), acc = round(acc + t)            (two roundings per step)
    chain_reversed   k descending, fused                                         (order sensitivity)
    pairwise_fused   balanced binary tree of fused steps                         (a different, better-conditioned order)
    chain_fused_rtz  as chain_fused with round-toward-zero                       (rounding-mode bias)
    chain_restricted as chain_fused under the restricted profile SFX-R           (DAZ/FTZ)
"""
from __future__ import annotations

import random
from fractions import Fraction
from typing import Callable, Dict, List, Tuple

from . import fp, matrix as mx

F32 = fp.F32


# --------------------------------------------------------------------------- exact values
def value(bits: int, f: fp.Fmt = F32) -> Fraction:
    s, k, N, E = fp.unpack(f, bits)
    if k == fp.ZERO:
        return Fraction(0)
    assert k == fp.FIN, "error study uses finite data"
    v = Fraction(N) * (Fraction(2) ** E) if E >= 0 else Fraction(N, 1 << (-E))
    return -v if s else v


def exact_dot(a: List[int], b: List[int], c0: int, src: fp.Fmt) -> Fraction:
    tot = value(c0)
    for x, y in zip(a, b):
        tot += value(x, src) * value(y, src)
    return tot


def round_exact(x: Fraction, rm: int = fp.RM_RNE) -> int:
    """Correctly rounded binary32 pattern of an exact rational (denominator a power of two)."""
    if x == 0:
        return 0
    n, d = x.numerator, x.denominator
    assert d & (d - 1) == 0
    return fp.round_pack(F32, 1 if n < 0 else 0, abs(n), -(d.bit_length() - 1), rm)[0]


def ulp32(x: Fraction) -> Fraction:
    """Spacing of binary32 numbers at |x| (normal range assumed; clamped to the subnormal spacing below)."""
    ax = abs(x)
    n, d = ax.numerator, ax.denominator
    e = n.bit_length() - d.bit_length()
    if Fraction(2) ** e > ax:
        e -= 1
    e = max(e, -126)
    return Fraction(2) ** (e - 23)


# --------------------------------------------------------------------------- the methods
def _fma(profile: int, rm: int):
    return lambda a, b, c: fp.unit_op(profile, fp.OP_FMA, a, b, c, rm)[0]


def chain_fused(a, b, c0, src, profile=fp.PROFILE_IEEE, rm=fp.RM_RNE, order=None):
    f = _fma(profile, rm)
    acc = c0
    for k in (order if order is not None else range(len(a))):
        acc = f(fp.widen(src, a[k]), fp.widen(src, b[k]), acc)
    return acc


def chain_unfused(a, b, c0, src):
    acc = c0
    for x, y in zip(a, b):
        t = fp.mul(F32, fp.widen(src, x), fp.widen(src, y), fp.RM_RNE)[0]
        acc = fp.add(F32, acc, t, fp.RM_RNE)[0]
    return acc


def pairwise_fused(a, b, c0, src):
    """Balanced tree: fused leaf chains of 2 products, partial sums added pairwise, then the initial C."""
    parts = []
    for i in range(0, len(a), 2):
        parts.append(chain_fused(a[i:i + 2], b[i:i + 2], 0, src))
    while len(parts) > 1:
        parts = [fp.add(F32, parts[i], parts[i + 1], fp.RM_RNE)[0] if i + 1 < len(parts) else parts[i] for i in range(0, len(parts), 2)]
    return fp.add(F32, parts[0], c0, fp.RM_RNE)[0]


METHODS: Dict[str, Callable] = {
    "chain_fused":      lambda a, b, c0, src: chain_fused(a, b, c0, src),
    "chain_unfused":    lambda a, b, c0, src: chain_unfused(a, b, c0, src),
    "chain_reversed":   lambda a, b, c0, src: chain_fused(a, b, c0, src, order=range(len(a) - 1, -1, -1)),
    "pairwise_fused":   lambda a, b, c0, src: pairwise_fused(a, b, c0, src),
    "chain_fused_rtz":  lambda a, b, c0, src: chain_fused(a, b, c0, src, rm=fp.RM_RTZ),
    "chain_restricted": lambda a, b, c0, src: chain_fused(a, b, c0, src, profile=fp.PROFILE_RESTRICTED),
}


# --------------------------------------------------------------------------- data
def make_vectors(rng: random.Random, K: int, fmt: int, dist: str) -> Tuple[List[int], List[int]]:
    """Finite 16-bit operand vectors.  benign: |x| in [0.5,1); wide: many binades; cancel: +-1 with the sums arranged to cancel."""
    def one(d: str) -> int:
        s = rng.getrandbits(1) << 15
        if fmt == mx.FMT_F16:
            e = {"benign": 14, "wide": 15 + rng.randrange(-8, 6), "cancel": 15 + rng.randrange(-1, 1)}[d]
            return s | (e << 10) | rng.getrandbits(10)
        e = {"benign": 126, "wide": 127 + rng.randrange(-40, 40), "cancel": 127 + rng.randrange(-1, 1)}[d]
        return s | (e << 7) | rng.getrandbits(7)
    a = [one(dist) for _ in range(K)]
    b = [one(dist) for _ in range(K)]
    if dist == "cancel":                      # second half cancels the first half up to small perturbations
        h = K // 2
        for i in range(h):
            a[h + i] = a[i] ^ 0x8000 if rng.random() < 0.9 else a[h + i]
            b[h + i] = b[i]
    return a, b


# --------------------------------------------------------------------------- statistics
class Stat:
    def __init__(self) -> None:
        self.n = 0
        self.exact = 0                                     # result == correctly rounded exact value
        self.max_ulp = Fraction(0)
        self.sum_ulp = Fraction(0)
        self.max_rel = Fraction(0)                         # |err| / sum|a b|, in units of u = 2^-24
        self.sum_signed_rel = Fraction(0)
        self.bound_violations = 0

    def add(self, err: Fraction, x: Fraction, sumabs: Fraction, result: int, correct: int, bound_u: int) -> None:
        self.n += 1
        self.exact += result == correct
        if x != 0:
            u = abs(err) / ulp32(x)
            self.max_ulp = max(self.max_ulp, u)
            self.sum_ulp += u
        rel = (abs(err) / sumabs) * (1 << 24) if sumabs else Fraction(0)
        self.max_rel = max(self.max_rel, rel)
        self.sum_signed_rel += (err / sumabs) * (1 << 24) if sumabs else Fraction(0)
        if bound_u and rel > bound_u:                      # classical first-order bound  |err| <= bound_u * u * sum|ab|
            self.bound_violations += 1

    def row(self) -> Dict[str, float]:
        return dict(trials=self.n, pct_correctly_rounded=100.0 * self.exact / self.n, max_ulp=float(self.max_ulp),
                    mean_ulp=float(self.sum_ulp / self.n), max_rel_u=float(self.max_rel),
                    bias_u=float(self.sum_signed_rel / self.n), bound_violations=self.bound_violations)


def run_study(Ks=(8, 16, 64, 256, 1024), trials=None, seed=20261121, fmts=(mx.FMT_F16, mx.FMT_BF16),
              dists=("benign", "wide", "cancel")) -> List[Dict]:
    trials = trials or {8: 300, 16: 240, 64: 120, 256: 60, 1024: 24}
    rows = []
    for fmt in fmts:
        src = mx.FMT_OF[fmt]
        for dist in dists:
            for K in Ks:
                rng = random.Random(f"{seed}:{fmt}:{dist}:{K}")
                stats = {m: Stat() for m in METHODS}
                for _ in range(trials[K]):
                    a, b = make_vectors(rng, K, fmt, dist)
                    c0 = 0
                    x = exact_dot(a, b, c0, src)
                    correct = round_exact(x)
                    sumabs = sum((abs(value(p, src) * value(q, src)) for p, q in zip(a, b)), Fraction(0))
                    for m, fn in METHODS.items():
                        r = fn(a, b, c0, src)
                        err = value(r) - x
                        # first-order bounds on the error relative to sum|ab| (units of u): chain (K-1)u (+u for the last), tree ~ log2 K
                        bound = {"chain_fused": K, "chain_unfused": K, "chain_reversed": K, "chain_fused_rtz": 2 * K, "chain_restricted": 0,
                                 "pairwise_fused": K.bit_length() + 1}[m]
                        stats[m].add(err, x, sumabs, r, correct, bound if bound else 0)
                for m, st in stats.items():
                    rows.append(dict(format=mx.FMT_NAMES[fmt], dist=dist, K=K, method=m, **st.row()))
    return rows
