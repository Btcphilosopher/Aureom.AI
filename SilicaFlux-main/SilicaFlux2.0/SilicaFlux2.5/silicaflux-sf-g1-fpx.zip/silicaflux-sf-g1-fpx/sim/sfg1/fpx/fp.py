"""Bit-accurate floating-point reference for the SF-G1 FP / matrix extension.

Design rules
------------
* **No host floating point anywhere in this module.**  Every value is a Python integer
  pair ``(N, E)`` meaning ``N * 2**E`` (an exact dyadic rational).  The exact result of an
  operation is formed with integer arithmetic and rounded once, by ``round_pack``.
* The code is **format generic** (``Fmt(ebits, mbits)``).  The same ``round_pack`` that
  serves binary32 is therefore exercised *exhaustively* on tiny formats in
  ``sim/tests_fpx/test_fp_exhaustive.py`` against an independent definition ("enumerate the
  representable numbers and pick the nearest"), and is cross-checked against Berkeley
  SoftFloat (binary16 and binary32) and MPFR.  See docs/fpx/F6-verification.md.
* ``add`` / ``mul`` are implemented independently of ``fma`` (not as ``fma`` with a constant
  operand) so that the hardware's operand-rewriting trick (add = fma(a,1,b), ...) is itself
  checked, not assumed.

Numerical policy implemented here (docs/fpx/F1-numerics.md)
-----------------------------------------------------------
IEEE profile ("SFX-IEEE"):  all five rounding attributes, gradual underflow, tininess detected
*after* rounding, the five exception flags, NaN results are always the canonical quiet NaN.
Restricted profile ("SFX-R"): round-to-nearest-even only, subnormal operands read as signed
zero (DAZ), subnormal results written as signed zero (FTZ), no flags.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Tuple

# ----------------------------------------------------------------------------- constants
RM_RNE, RM_RTZ, RM_RDN, RM_RUP, RM_RMM = 0, 1, 2, 3, 4
RM_NAMES = {RM_RNE: "rne", RM_RTZ: "rtz", RM_RDN: "rdn", RM_RUP: "rup", RM_RMM: "rmm"}
RM_BY_NAME = {v: k for k, v in RM_NAMES.items()}
VALID_RM = (RM_RNE, RM_RTZ, RM_RDN, RM_RUP, RM_RMM)

# exception flags, RISC-V fflags bit order (also SoftFloat's numbering)
NX, UF, OF, DZ, NV = 1, 2, 4, 8, 16
FLAG_NAMES = ((NV, "NV"), (DZ, "DZ"), (OF, "OF"), (UF, "UF"), (NX, "NX"))

# operand classes
ZERO, FIN, INF, QNAN, SNAN = range(5)

# FP operations of the unit (ISA fp-function codes)
OP_FMA, OP_FMS, OP_FNMA, OP_FNMS, OP_ADD, OP_SUB, OP_MUL = range(7)
OP_NAMES = {OP_FMA: "ffma", OP_FMS: "ffms", OP_FNMA: "ffnma", OP_FNMS: "ffnms",
            OP_ADD: "fadd", OP_SUB: "fsub", OP_MUL: "fmul"}


def flags_str(f: int) -> str:
    return "".join(n for b, n in FLAG_NAMES if f & b) or "-"


@dataclass(frozen=True)
class Fmt:
    name: str
    ebits: int
    mbits: int  # fraction bits (precision p = mbits + 1)

    @property
    def p(self) -> int:
        return self.mbits + 1

    @property
    def width(self) -> int:
        return 1 + self.ebits + self.mbits

    @property
    def bias(self) -> int:
        return (1 << (self.ebits - 1)) - 1

    @property
    def emax(self) -> int:
        return self.bias

    @property
    def emin(self) -> int:
        return 1 - self.bias

    @property
    def exp_ones(self) -> int:
        return (1 << self.ebits) - 1

    @property
    def sign_bit(self) -> int:
        return 1 << (self.width - 1)

    @property
    def qnan(self) -> int:
        """Canonical quiet NaN: positive, quiet bit set, empty payload."""
        return (self.exp_ones << self.mbits) | (1 << (self.mbits - 1))

    def inf(self, sign: int) -> int:
        return (sign << (self.width - 1)) | (self.exp_ones << self.mbits)

    def zero(self, sign: int) -> int:
        return sign << (self.width - 1)

    @property
    def max_finite(self) -> int:
        return ((self.exp_ones - 1) << self.mbits) | ((1 << self.mbits) - 1)


F32 = Fmt("binary32", 8, 23)
F16 = Fmt("binary16", 5, 10)
BF16 = Fmt("bfloat16", 8, 7)
FORMATS = {"binary32": F32, "binary16": F16, "bfloat16": BF16}


# ----------------------------------------------------------------------------- unpack
def unpack(f: Fmt, bits: int) -> Tuple[int, int, int, int]:
    """Return ``(sign, kind, N, E)``; a finite value is ``(-1)**sign * N * 2**E`` exactly."""
    bits &= (1 << f.width) - 1
    s = bits >> (f.width - 1)
    e = (bits >> f.mbits) & f.exp_ones
    m = bits & ((1 << f.mbits) - 1)
    if e == f.exp_ones:
        if m == 0:
            return s, INF, 0, 0
        return s, (QNAN if (m >> (f.mbits - 1)) & 1 else SNAN), m, 0
    if e == 0:
        if m == 0:
            return s, ZERO, 0, 0
        return s, FIN, m, f.emin - f.mbits
    return s, FIN, m | (1 << f.mbits), e - f.bias - f.mbits


def is_nan(f: Fmt, bits: int) -> bool:
    return unpack(f, bits)[1] in (QNAN, SNAN)


# ----------------------------------------------------------------------------- rounding
def _round_div(N: int, drop: int, sign: int, rm: int) -> Tuple[int, bool]:
    """``N / 2**drop`` (drop > 0) rounded to an integer under ``rm``; returns ``(M, inexact)``."""
    M = N >> drop
    rem = N & ((1 << drop) - 1)
    if rem == 0:
        return M, False
    half = 1 << (drop - 1)
    if rm == RM_RNE:
        inc = rem > half or (rem == half and (M & 1))
    elif rm == RM_RMM:
        inc = rem >= half
    elif rm == RM_RTZ:
        inc = False
    elif rm == RM_RDN:
        inc = bool(sign)
    elif rm == RM_RUP:
        inc = not sign
    else:
        raise ValueError(f"invalid rounding mode {rm}")
    return M + int(inc), True


def _overflow_value(f: Fmt, sign: int, rm: int) -> int:
    to_inf = rm in (RM_RNE, RM_RMM) or (rm == RM_RDN and sign) or (rm == RM_RUP and not sign)
    if to_inf:
        return f.inf(sign)
    return (sign << (f.width - 1)) | f.max_finite


def round_pack(f: Fmt, sign: int, N: int, E: int, rm: int) -> Tuple[int, int]:
    """Round the exact nonzero value ``(-1)**sign * N * 2**E`` (``N > 0``) to format ``f``.

    Returns ``(bits, flags)``.  Underflow is detected after rounding (IEEE 754-2019 7.5):
    the result is *tiny* when the value rounded to ``p`` bits with an unbounded exponent
    range is below ``2**emin``; UF is raised when tiny and the delivered result is inexact.
    """
    assert N > 0
    nb = N.bit_length()
    e = nb - 1 + E                                  # floor(log2 |x|)
    q = max(e, f.emin) - f.mbits                    # weight of the result's last place
    drop = q - E
    if drop <= 0:
        M, inexact = N << (-drop), False
    else:
        M, inexact = _round_div(N, drop, sign, rm)
    flags = NX if inexact else 0
    if inexact and e < f.emin:                      # candidate tiny: round with unbounded exponent
        qu = e - f.mbits
        dropu = qu - E
        Mu = N << (-dropu) if dropu <= 0 else _round_div(N, dropu, sign, rm)[0]
        if Mu.bit_length() - 1 + qu < f.emin:       # strictly below 2**emin after rounding
            flags |= UF
    if M == 0:                                      # underflowed to zero
        return f.zero(sign), flags
    ef = q + M.bit_length() - 1                     # exponent of the rounded value's leading bit
    if ef > f.emax:
        return _overflow_value(f, sign, rm), flags | OF | NX
    if ef < f.emin:                                 # subnormal (q == emin - mbits here)
        return (sign << (f.width - 1)) | M, flags
    # (a rounding carry gives M == 2**p; ``ef`` already accounts for it and the mask drops the hidden bit)
    return (sign << (f.width - 1)) | ((ef + f.bias) << f.mbits) | (M & ((1 << f.mbits) - 1)), flags


def _exact_zero_sign(sp: int, sc: int, rm: int) -> int:
    """Sign of an exact zero sum/difference (IEEE 754-2019 6.3)."""
    if sp == sc:
        return sp
    return 1 if rm == RM_RDN else 0


def _nan_result(f: Fmt, invalid: bool) -> Tuple[int, int]:
    return f.qnan, (NV if invalid else 0)


# ----------------------------------------------------------------------------- operations
def fma(f: Fmt, a: int, b: int, c: int, rm: int) -> Tuple[int, int]:
    """``round(a*b + c)`` with a single rounding (IEEE 754-2019 5.4.1 fusedMultiplyAdd)."""
    sa, ka, Na, Ea = unpack(f, a)
    sb, kb, Nb, Eb = unpack(f, b)
    sc, kc, Nc, Ec = unpack(f, c)
    prod_invalid = (ka == INF and kb == ZERO) or (ka == ZERO and kb == INF)
    if ka in (QNAN, SNAN) or kb in (QNAN, SNAN) or kc in (QNAN, SNAN) or prod_invalid:
        snan = SNAN in (ka, kb, kc)
        # inf*0 raises NV even when c is a quiet NaN (RISC-V / SoftFloat choice; IEEE 7.2(c) leaves it open)
        return _nan_result(f, snan or prod_invalid)
    sp = sa ^ sb
    if ka == INF or kb == INF:
        if kc == INF and sc != sp:
            return _nan_result(f, True)
        return f.inf(sp), 0
    if kc == INF:
        return f.inf(sc), 0
    P = 0 if (ka == ZERO or kb == ZERO) else Na * Nb
    EP = Ea + Eb
    if P == 0 and kc == ZERO:
        return f.zero(_exact_zero_sign(sp, sc, rm)), 0
    if P == 0:
        E, S = Ec, (-Nc if sc else Nc)
    elif kc == ZERO:
        E, S = EP, (-P if sp else P)
    else:
        E = min(EP, Ec)
        S = ((-P if sp else P) << (EP - E)) + ((-Nc if sc else Nc) << (Ec - E))
    if S == 0:
        return f.zero(1 if rm == RM_RDN else 0), 0       # exact cancellation of nonzero terms
    return round_pack(f, 1 if S < 0 else 0, abs(S), E, rm)


def add(f: Fmt, a: int, b: int, rm: int) -> Tuple[int, int]:
    """``round(a + b)`` (IEEE 754-2019 5.4.1 addition); independent of ``fma``."""
    sa, ka, Na, Ea = unpack(f, a)
    sb, kb, Nb, Eb = unpack(f, b)
    if ka in (QNAN, SNAN) or kb in (QNAN, SNAN):
        return _nan_result(f, SNAN in (ka, kb))
    if ka == INF and kb == INF:
        return (f.inf(sa), 0) if sa == sb else _nan_result(f, True)
    if ka == INF:
        return f.inf(sa), 0
    if kb == INF:
        return f.inf(sb), 0
    if ka == ZERO and kb == ZERO:
        return f.zero(_exact_zero_sign(sa, sb, rm)), 0
    if ka == ZERO:
        return round_pack(f, sb, Nb, Eb, rm)
    if kb == ZERO:
        return round_pack(f, sa, Na, Ea, rm)
    E = min(Ea, Eb)
    S = ((-Na if sa else Na) << (Ea - E)) + ((-Nb if sb else Nb) << (Eb - E))
    if S == 0:
        return f.zero(1 if rm == RM_RDN else 0), 0
    return round_pack(f, 1 if S < 0 else 0, abs(S), E, rm)


def sub(f: Fmt, a: int, b: int, rm: int) -> Tuple[int, int]:
    """``round(a - b)``: addition of the negated second operand."""
    return add(f, a, b ^ f.sign_bit, rm)


def mul(f: Fmt, a: int, b: int, rm: int) -> Tuple[int, int]:
    """``round(a * b)`` (IEEE 754-2019 5.4.1 multiplication); independent of ``fma``."""
    sa, ka, Na, Ea = unpack(f, a)
    sb, kb, Nb, Eb = unpack(f, b)
    if ka in (QNAN, SNAN) or kb in (QNAN, SNAN):
        return _nan_result(f, SNAN in (ka, kb))
    if (ka == INF and kb == ZERO) or (ka == ZERO and kb == INF):
        return _nan_result(f, True)
    s = sa ^ sb
    if ka == INF or kb == INF:
        return f.inf(s), 0
    if ka == ZERO or kb == ZERO:
        return f.zero(s), 0
    return round_pack(f, s, Na * Nb, Ea + Eb, rm)


# ----------------------------------------------------------------------------- profiles
SIGN32 = F32.sign_bit


def ieee_op(op: int, a: int, b: int, c: int, rm: int) -> Tuple[int, int]:
    """binary32 unit operation under the IEEE profile (docs/fpx/F1-numerics.md section 4).

    ======  ===============  =========================================================
    op      result           notes
    ======  ===============  =========================================================
    FMA     a*b + c          fused, one rounding
    FMS     a*b - c          fused
    FNMA    -(a*b) + c       fused
    FNMS    -(a*b) - c       fused
    ADD     a + b            ``c`` ignored
    SUB     a - b            ``c`` ignored
    MUL     a * b            ``c`` ignored, separately rounded (not fused)
    ======  ===============  =========================================================
    """
    if op == OP_FMA:
        return fma(F32, a, b, c, rm)
    if op == OP_FMS:
        return fma(F32, a, b, c ^ SIGN32, rm)
    if op == OP_FNMA:
        return fma(F32, a ^ SIGN32, b, c, rm)
    if op == OP_FNMS:
        return fma(F32, a ^ SIGN32, b, c ^ SIGN32, rm)
    if op == OP_ADD:
        return add(F32, a, b, rm)
    if op == OP_SUB:
        return sub(F32, a, b, rm)
    if op == OP_MUL:
        return mul(F32, a, b, rm)
    raise ValueError(f"invalid FP op {op}")


def is_subnormal32(bits: int) -> bool:
    return ((bits >> 23) & 0xFF) == 0 and (bits & 0x7FFFFF) != 0


def daz(bits: int) -> int:
    """Denormals-are-zero: a subnormal binary32 operand reads as zero of the same sign."""
    return bits & SIGN32 if is_subnormal32(bits) else bits


def ftz(bits: int) -> int:
    """Flush-to-zero: a subnormal binary32 result is delivered as zero of the same sign."""
    return bits & SIGN32 if is_subnormal32(bits) else bits


def restricted_op(op: int, a: int, b: int, c: int) -> Tuple[int, int]:
    """binary32 unit operation under the restricted profile SFX-R.

    DAZ on all operands -> IEEE round-to-nearest-even result -> FTZ on the result; flags are
    not produced (always 0).  The profile is *defined* by this composition (docs/fpx/F1 4.3):
    note that a result just below the smallest normal that rounds up to it on the gradual-
    underflow grid is delivered as that normal number, not flushed.
    """
    res, _ = ieee_op(op, daz(a), daz(b), daz(c), RM_RNE)
    return ftz(res), 0


PROFILE_IEEE, PROFILE_RESTRICTED = 0, 1
PROFILE_NAMES = {PROFILE_IEEE: "SFX-IEEE", PROFILE_RESTRICTED: "SFX-R"}


def unit_op(profile: int, op: int, a: int, b: int, c: int, rm: int) -> Tuple[int, int]:
    """The complete FP-unit contract (this is what ``fpx/rtl/sf_fpx_unit.sv`` must reproduce)."""
    if profile == PROFILE_IEEE:
        return ieee_op(op, a, b, c, rm if rm in VALID_RM else RM_RNE)
    return restricted_op(op, a, b, c)


# ----------------------------------------------------------------------------- widening
def widen(src: Fmt, bits: int) -> int:
    """Exact conversion of a binary16 / bfloat16 / binary32 pattern to binary32.

    Finite values convert exactly (binary16 subnormals become normal binary32 numbers; bfloat16
    subnormals stay subnormal).  NaNs keep their quiet/signalling kind and shifted payload; the
    FP datapath then turns any NaN into the canonical quiet NaN.
    """
    s, k, N, E = unpack(src, bits)
    if k == ZERO:
        return F32.zero(s)
    if k == INF:
        return F32.inf(s)
    if k in (QNAN, SNAN):
        return (s << 31) | (F32.exp_ones << 23) | (N << (F32.mbits - src.mbits))
    out, fl = round_pack(F32, s, N, E, RM_RNE)
    assert fl == 0, "widening must be exact"
    return out
