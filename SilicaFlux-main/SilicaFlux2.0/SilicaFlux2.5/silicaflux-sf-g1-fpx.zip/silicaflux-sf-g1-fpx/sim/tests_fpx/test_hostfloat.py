"""Why host floating point is not an oracle: a tested counter-example (docs/fpx/F6-verification.md section 1)."""
import struct
import unittest

from sfg1.fpx import fp
from sfg1.fpx.hostfloat import double_rounded_fma, unfused_fma, host_add, host_mul
from sfg1.fpx.vectors_fp import random_triples


def f32bits(sign, exp, frac):
    return (sign << 31) | (exp << 23) | frac


class HostFloatIsNotAnOracle(unittest.TestCase):
    # a = b = 1 + 2^-12 (exact binary32), c = 2^-60:  a*b = 1 + 2^-11 + 2^-24 is EXACTLY a binary32 midpoint
    A = B = f32bits(0, 127, 1 << 11)
    C = f32bits(0, 127 - 60, 0)

    def test_exact_value_is_just_above_the_midpoint(self):
        # reference (integer arithmetic, one rounding): the tiny positive c breaks the tie upward
        res, fl = fp.fma(fp.F32, self.A, self.B, self.C, fp.RM_RNE)
        self.assertEqual(res, f32bits(0, 127, (1 << 12) + 1))       # 1 + 2^-11 + 2^-23
        self.assertEqual(fl, fp.NX)

    def test_double_rounding_through_binary64_gets_it_wrong(self):
        host = double_rounded_fma(self.A, self.B, self.C)
        self.assertEqual(host, f32bits(0, 127, 1 << 12))            # 1 + 2^-11: rounded to the even neighbour
        self.assertNotEqual(host, fp.fma(fp.F32, self.A, self.B, self.C, fp.RM_RNE)[0])

    def test_unfused_multiply_add_differs_from_fused(self):
        n = sum(unfused_fma(a, b, c) != fp.fma(fp.F32, a, b, c, fp.RM_RNE)[0]
                for a, b, c in random_triples(3000, 5)
                if not any(((x >> 23) & 0xFF) == 0xFF for x in (a, b, c)))
        self.assertGreater(n, 0)

    def test_host_add_mul_rne_agree_on_this_machine_but_prove_nothing_about_other_modes(self):
        # informational: agreement on finite RNE vectors; the project still does not rely on it
        bad = 0
        for a, b, _ in random_triples(5000, 6):
            if any(((x >> 23) & 0xFF) == 0xFF for x in (a, b)):
                continue
            bad += host_add(a, b) != fp.add(fp.F32, a, b, fp.RM_RNE)[0]
            bad += host_mul(a, b) != fp.mul(fp.F32, a, b, fp.RM_RNE)[0]
        self.assertEqual(bad, 0)


if __name__ == "__main__":
    unittest.main()
