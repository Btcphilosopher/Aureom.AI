"""Independent brute-force definition of IEEE rounding for tiny formats.

This shares **no code** with ``sfg1.fpx.fp``.  The definition is the textbook one: list every
representable number, find the neighbours of the exact result, and choose by the rounding
rule.  Flags come from comparing against explicitly enumerated *unbounded-exponent* grids
(IEEE 754-2019 7.4 overflow, 7.5 underflow, tininess after rounding).

Special values (NaN, infinity, zero signs) are restated here from the standard's tables rather
than reused from the model.
"""
from __future__ import annotations

from bisect import bisect_right
from fractions import Fraction
from functools import lru_cache
from typing import List, Optional, Tuple

NX, UF, OF, DZ, NV = 1, 2, 4, 8, 16
RNE, RTZ, RDN, RUP, RMM = range(5)


class Tiny:
    def __init__(self, ebits: int, mbits: int):
        self.ebits, self.mbits = ebits, mbits
        self.bias = (1 << (ebits - 1)) - 1
        self.emin, self.emax = 1 - self.bias, self.bias
        self.width = 1 + ebits + mbits
        self.nbits = 1 << self.width

    # ------------------------------------------------------------------ classification
    def classify(self, bits: int):
        s = bits >> (self.width - 1)
        e = (bits >> self.mbits) & ((1 << self.ebits) - 1)
        m = bits & ((1 << self.mbits) - 1)
        allones = (1 << self.ebits) - 1
        if e == allones:
            if m == 0:
                return s, "inf", None
            return s, ("qnan" if m >> (self.mbits - 1) else "snan"), None
        if e == 0:
            return s, ("zero" if m == 0 else "fin"), Fraction(m, 1) * Fraction(2) ** (self.emin - self.mbits)
        return s, "fin", Fraction((1 << self.mbits) | m, 1) * Fraction(2) ** (e - self.bias - self.mbits)

    @property
    def qnan(self) -> int:
        return (((1 << self.ebits) - 1) << self.mbits) | (1 << (self.mbits - 1))

    def inf(self, s: int) -> int:
        return (s << (self.width - 1)) | (((1 << self.ebits) - 1) << self.mbits)

    def zero(self, s: int) -> int:
        return s << (self.width - 1)

    @lru_cache(maxsize=None)
    def grid(self) -> Tuple[List[Fraction], dict]:
        """Ascending list of non-negative finite values (incl. 0) and value -> bits."""
        vals, by = [], {}
        for b in range(1 << (self.width - 1)):
            s, k, v = self.classify(b)
            if k in ("fin", "zero"):
                vv = v if v is not None else Fraction(0)
                vals.append(vv)
                by[vv] = b
        vals.sort()
        return vals, by

    @lru_cache(maxsize=None)
    def unbounded_grid(self) -> List[Fraction]:
        """All p-bit values over a very wide exponent range (stands in for 'unbounded exponent')."""
        out = [Fraction(0)]
        for e in range(self.emin - 16, self.emax + 17):
            for m in range(1 << self.mbits, 1 << (self.mbits + 1)):
                out.append(Fraction(m, 1) * Fraction(2) ** (e - self.mbits))
        out.sort()
        return out


def _choose(vals: List[Fraction], x: Fraction, sign: int, rm: int, parity_of) -> Tuple[Fraction, Fraction]:
    """Return (rounded, lo): rounded neighbour of |x| in ``vals`` (a virtual top value must be appended)."""
    i = bisect_right(vals, x) - 1
    lo = vals[i]
    if lo == x:
        return lo, lo
    hi = vals[i + 1]
    if rm == RTZ:
        r = lo
    elif rm == RDN:
        r = hi if sign else lo
    elif rm == RUP:
        r = lo if sign else hi
    else:
        d_lo, d_hi = x - lo, hi - x
        if d_lo < d_hi:
            r = lo
        elif d_hi < d_lo:
            r = hi
        elif rm == RMM:
            r = hi
        else:
            r = lo if parity_of(lo) == 0 else hi
    return r, lo


def round_exact(t: Tiny, x: Fraction, rm: int) -> Tuple[int, int]:
    """Round the exact nonzero value x to the tiny format; returns (bits, flags)."""
    sign = 1 if x < 0 else 0
    ax = abs(x)
    vals, by = t.grid()
    ulp_top = vals[-1] - vals[-2]
    virt = vals[-1] + ulp_top                      # 2**(emax+1): the position "infinity" occupies
    ext = vals + [virt]
    # an even/odd parity oracle for ties: parity of the *mantissa integer* in the unbounded system
    def parity(v: Fraction) -> int:
        if v == virt:
            return 0
        b = by[v]
        return b & 1
    flags = 0
    # overflow: rounding as though the exponent range were unbounded exceeds the largest finite number
    ug = t.unbounded_grid()
    def uparity(v: Fraction) -> int:
        # parity of the p-bit significand integer of v
        if v == 0:
            return 0
        e = 0
        while True:
            m = v * Fraction(2) ** (t.mbits - e)
            if (1 << t.mbits) <= m < (1 << (t.mbits + 1)):
                return int(m) & 1
            e += 1 if m >= (1 << (t.mbits + 1)) else -1
    ur, _ = _choose(ug + [ug[-1] * 2], ax, sign, rm, uparity)
    if ur > vals[-1]:
        flags |= OF | NX
        to_inf = rm in (RNE, RMM) or (rm == RDN and sign) or (rm == RUP and not sign)
        return (t.inf(sign) if to_inf else (sign << (t.width - 1)) | by[vals[-1]]), flags
    r, lo = _choose(ext, ax, sign, rm, parity)
    if lo != ax:
        flags |= NX
    min_normal = Fraction(2) ** t.emin
    if ur < min_normal and (flags & NX):
        flags |= UF
    if r == virt:
        # rounding on the bounded grid ran off the end although the unbounded rounding did not
        # exceed max: impossible for RNE/RMM/RUP/RDN by construction; keep a loud failure
        raise AssertionError("inconsistent overflow classification")
    if r == 0:
        return t.zero(sign), flags
    return (sign << (t.width - 1)) | by[r], flags


def _exact_zero_sign(sp: int, sc: int, rm: int) -> int:
    return sp if sp == sc else (1 if rm == RDN else 0)


def fma(t: Tiny, a: int, b: int, c: int, rm: int) -> Tuple[int, int]:
    sa, ka, va = t.classify(a)
    sb, kb, vb = t.classify(b)
    sc, kc, vc = t.classify(c)
    kinds = (ka, kb, kc)
    inv_prod = (ka == "inf" and kb == "zero") or (ka == "zero" and kb == "inf")
    if "qnan" in kinds or "snan" in kinds or inv_prod:
        return t.qnan, (NV if ("snan" in kinds or inv_prod) else 0)
    sp = sa ^ sb
    if ka == "inf" or kb == "inf":
        if kc == "inf" and sc != sp:
            return t.qnan, NV
        return t.inf(sp), 0
    if kc == "inf":
        return t.inf(sc), 0
    prod = (va or Fraction(0)) * (vb or Fraction(0))
    cv = vc or Fraction(0)
    if prod == 0 and cv == 0:
        return t.zero(_exact_zero_sign(sp, sc, rm)), 0
    x = (-prod if sp else prod) + (-cv if sc else cv)
    if x == 0:
        return t.zero(1 if rm == RDN else 0), 0
    return round_exact(t, x, rm)


def add(t: Tiny, a: int, b: int, rm: int) -> Tuple[int, int]:
    sa, ka, va = t.classify(a)
    sb, kb, vb = t.classify(b)
    if "qnan" in (ka, kb) or "snan" in (ka, kb):
        return t.qnan, (NV if "snan" in (ka, kb) else 0)
    if ka == "inf" and kb == "inf":
        return (t.inf(sa), 0) if sa == sb else (t.qnan, NV)
    if ka == "inf":
        return t.inf(sa), 0
    if kb == "inf":
        return t.inf(sb), 0
    x = (-(va or 0) if sa else (va or 0)) + (-(vb or 0) if sb else (vb or 0))
    x = Fraction(x)
    if ka == "zero" and kb == "zero":
        return t.zero(_exact_zero_sign(sa, sb, rm)), 0
    if x == 0:
        return t.zero(1 if rm == RDN else 0), 0
    return round_exact(t, x, rm)


def mul(t: Tiny, a: int, b: int, rm: int) -> Tuple[int, int]:
    sa, ka, va = t.classify(a)
    sb, kb, vb = t.classify(b)
    if "qnan" in (ka, kb) or "snan" in (ka, kb):
        return t.qnan, (NV if "snan" in (ka, kb) else 0)
    if (ka == "inf" and kb == "zero") or (ka == "zero" and kb == "inf"):
        return t.qnan, NV
    s = sa ^ sb
    if ka == "inf" or kb == "inf":
        return t.inf(s), 0
    if ka == "zero" or kb == "zero":
        return t.zero(s), 0
    return round_exact(t, Fraction(va) * Fraction(vb) * (-1 if s else 1), rm)
