"""The fpx extension on the functional model: ISA semantics, faults, capability discovery, optionality, end-to-end kernels."""
import json
import random
import unittest
from pathlib import Path

from sfg1.device import Device
from sfg1.examples import EXAMPLES
from sfg1.host import Host, LocalTransport
from sfg1.isa import isa
from sfg1.spec import Config
from sfg1.fpx import fp, kernels as K, matrix as mx
from sfg1.fpx.asm_ext import assemble, disasm, open_fpx
from sfg1.fpx.config import FpxConfig, ext_isa
from sfg1.fpx.device_ext import FAULTS, FpxDevice
from sfg1.fpx.vectors_fp import F32_EDGE, random_triples

ROOT = Path(__file__).resolve().parents[2]
CFG = Config.default()
F_IEEE = FpxConfig.from_file("fpx-ieee")
F_RESTR = FpxConfig.from_file("fpx-restricted")
F_SMALL = FpxConfig.from_file("fpx-small")
F_RECT = FpxConfig.from_file("fpx-rect")

OP_KERNEL = """
    rdsr  r1, SR_GTID
    shli  r1, r1, 2
    rdsr  r2, SR_ARG0
    add   r3, r2, r1
    ldg   r4, [r3]            ; a
    rdsr  r2, SR_ARG1
    add   r3, r2, r1
    ldg   r5, [r3]            ; b
    rdsr  r2, SR_ARG2
    add   r3, r2, r1
    ldg   r6, [r3]            ; c / accumulator
    {OP} r6, r4, r5
    frflags r7
    rdsr  r2, SR_ARG3
    add   r3, r2, r1
    stg   r6, [r3]
    rdsr  r2, SR_ARG4
    add   r3, r2, r1
    stg   r7, [r3]
    exit
"""


def run_op(host, mnemonic, triples):
    n = len(triples)
    pad = (-n) % 8
    triples = list(triples) + [(0, 0, 0)] * pad
    n = len(triples)
    a, b, c, r, f = (host.alloc(4 * n) for _ in range(5))
    host.write_words(a, [t[0] for t in triples]); host.write_words(b, [t[1] for t in triples]); host.write_words(c, [t[2] for t in triples])
    kern = host.load_kernel(assemble(OP_KERNEL.replace("{OP}", mnemonic)).words)
    res = host.launch(kern, grid=n // 8, wg=8, args=[a, b, c, r, f])
    assert res.ok, res
    return host.read_words(r, n), host.read_words(f, n)


class OptionalityAndDiscovery(unittest.TestCase):
    def test_base_examples_unchanged_on_the_extension_device(self):
        """Kernels that do not use fpx opcodes: same results AND same commit-trace digest as the base golden reference."""
        for name in EXAMPLES:
            host = open_fpx(CFG, F_IEEE, trace=True)
            ex = EXAMPLES[name](host, CFG, True)
            self.assertTrue(ex.ok, name)
            ref = json.loads((ROOT / "reference" / name / "report.json").read_text())
            self.assertEqual(host.device.trace.digest(), ref["trace"]["sha256"], name)

    def test_fpx_opcodes_are_illegal_on_the_base_device(self):
        host = Host(LocalTransport(Device(CFG)), CFG)
        word = ext_isa().encode("ffma", rd=3, rs1=4, rs2=5)
        kern = host.load_kernel([word, isa().encode("exit")])
        res = host.launch(kern, grid=1, wg=1)
        self.assertEqual(res.status, "fault")
        self.assertEqual(res.error, "F_ILLEGAL_INSN")
        self.assertEqual(res.fault["DATA"], word)

    def test_base_decoder_unchanged_for_every_non_extension_word(self):
        rng = random.Random(4)
        I, E = isa(), ext_isa()
        for _ in range(20000):
            w = rng.getrandbits(32)
            if E.is_ext((w >> 26) & 0x3F):
                self.assertTrue(I.decode(w).illegal)        # the base ISA knows none of the new opcodes
            else:
                self.assertEqual(E.decode(w), I.decode(w))

    def test_capability_registers_and_extension_hash(self):
        for f in FpxConfig.named():
            host = open_fpx(CFG, f)
            dev = host.device
            self.assertEqual(dev.reg_read(0x080), f.caps_fpx())
            self.assertEqual(dev.reg_read(0x084), f.caps_mma())
            self.assertEqual(dev.reg_read(0x008), f.cfg_hash(CFG))
            self.assertNotEqual(f.cfg_hash(CFG), CFG.cfg_hash())            # extension changes the hash
        # a base device does not map the capability registers: discovery by HOST_ERR
        base = Device(CFG)
        for _ in range(8):
            base.tick()
        self.assertEqual(base.reg_read(0x080), 0)
        self.assertTrue(base.int_status & 8)

    def test_hash_depends_on_every_extension_parameter(self):
        hashes = {c.cfg_hash(CFG) for c in FpxConfig.named()}
        self.assertEqual(len(hashes), len(FpxConfig.named()))

    def test_special_registers_report_the_geometry(self):
        host = open_fpx(CFG, F_RECT)
        out = host.alloc(8)
        src = "rdsr r1, SR_FPX_CAPS\n rdsr r2, SR_MMA_SHAPE\n rdsr r3, SR_ARG0\n stg r1, [r3]\n stg r2, [r3+4]\n exit\n"
        kern = host.load_kernel(assemble(src).words)
        self.assertTrue(host.launch(kern, 1, 1, args=[out]).ok)
        self.assertEqual(host.read_words(out, 2), [F_RECT.caps_fpx(), F_RECT.caps_mma()])


class InstructionSemantics(unittest.TestCase):
    OPS = {"fadd": fp.OP_ADD, "fsub": fp.OP_SUB, "fmul": fp.OP_MUL, "ffma": fp.OP_FMA, "ffms": fp.OP_FMS,
           "ffnma": fp.OP_FNMA, "ffnms": fp.OP_FNMS}

    def _check_all(self, fpx, mods_rm):
        rng = random.Random(77)
        triples = list(random_triples(60, 5)) + [(rng.choice(F32_EDGE), rng.choice(F32_EDGE), rng.choice(F32_EDGE)) for _ in range(60)]
        host = open_fpx(CFG, fpx)
        for mn, op in self.OPS.items():
            for rm in mods_rm:
                res, flg = run_op(host, f"{mn}.{fp.RM_NAMES[rm]}", triples)
                for (a, b, c), r, f in zip(triples, res, flg):
                    er, ef = fp.unit_op(fpx.profile, op, a, b, c, rm)
                    self.assertEqual((r, f), (er, ef), f"{mn}.{fp.RM_NAMES[rm]} {a:08x} {b:08x} {c:08x}")

    def test_all_fp_instructions_ieee_profile_all_rounding_modes(self):
        self._check_all(F_IEEE, range(5))

    def test_all_fp_instructions_restricted_profile(self):
        self._check_all(F_RESTR, (0, 3))          # the rounding field is accepted but ignored

    def test_flags_are_sticky_per_thread_and_swappable(self):
        host = open_fpx(CFG, F_IEEE)
        out = host.alloc(16)
        kern = host.load_kernel(assemble((Path(K.EXAMPLES_DIR) / "fp_flags.sfa").read_text()).words)
        self.assertTrue(host.launch(kern, 1, 8, args=[out]).ok)
        w = host.read_words(out, 4)
        self.assertEqual(w[0], 0x7F800000)                         # max + max overflows to +inf
        self.assertEqual(w[1], fp.OF | fp.NX)                     # sticky flags after the overflow
        self.assertEqual(w[2], 0)                                 # fsflags r8, r0 read-and-cleared, so now zero
        self.assertEqual(w[3], fp.NX)                             # 1.0 + 2^-24 is inexact

    def test_flags_are_zero_under_the_restricted_profile(self):
        host = open_fpx(CFG, F_RESTR)
        out = host.alloc(16)
        kern = host.load_kernel(assemble((Path(K.EXAMPLES_DIR) / "fp_flags.sfa").read_text()).words)
        self.assertTrue(host.launch(kern, 1, 8, args=[out]).ok)
        self.assertEqual(host.read_words(out, 4), [0x7F800000, 0, 0, 0])

    def test_rounding_mode_field_validation(self):
        I = ext_isa()
        good = I.encode("ffma", rd=1, rs1=2, rs2=3, imm=4)
        self.assertFalse(I.decode(good).illegal)
        for rm in (5, 6, 7):
            self.assertTrue(I.decode(I.encode("ffma", rd=1, rs1=2, rs2=3, imm=rm)).illegal)
        self.assertTrue(I.decode(good | (1 << 5)).illegal)         # a reserved bit set
        self.assertTrue(I.decode(I.encode("fadd", rd=1, rs1=2, rs2=3) | (1 << 3)).illegal)   # fmt bit is MMA-only
        self.assertFalse(I.decode(I.encode("mma", rd=1, rs1=2, rs2=3, imm=8 | 2)).illegal)

    def test_disassembler_round_trips(self):
        src = "\n".join(["ffma.rtz r3, r4, r5", "fadd r1, r2, r3", "ffnms.rmm r15, r14, r13", "mma.bf16.rup r1, r2, r3",
                         "mmaz r4, r5, r6", "frflags r9", "fsflags r8, r7", "fmul.rdn r1, r1, r1"]) + "\nexit\n"
        words = assemble(src).words
        text = "\n".join(disasm(w) for w in words)
        self.assertEqual(assemble(text).words, words)
        self.assertIn("mma.bf16.rup r1, r2, r3", text)


class MatrixInstructionFaults(unittest.TestCase):
    def _run(self, body, f=F_IEEE, wg=8, shared=None, grid=1):
        host = open_fpx(CFG, f)
        shared = shared if shared is not None else 4 * (f.a_words + f.b_words + f.c_words)
        kern = host.load_kernel(assemble(body + "\nexit\n").words)
        return host.launch(kern, grid=grid, wg=wg, shared=shared)

    def test_divergent_mma_faults(self):
        body = """
            rdsr r1, SR_LANE_ID
            addi r1, r1, -3
            bz   r1, skip, skip
            mma  r0, r0, r0
        skip:
            nop
        """
        res = self._run(body)
        self.assertEqual((res.status, res.fault["CODE"]), ("fault", FAULTS["F_MMA_DIVERGENT"]))

    def test_nonuniform_address_faults_and_names_the_lane(self):
        body = "rdsr r1, SR_LANE_ID\n shli r1, r1, 2\n mma r0, r1, r0"
        res = self._run(body)
        self.assertEqual(res.fault["CODE"], FAULTS["F_MMA_NONUNIFORM"])
        self.assertEqual((res.fault["LOC"] >> 16) & 0xFF, 1)       # first lane that differs from lane 0
        self.assertEqual(res.fault["DATA"], 4)

    def test_misaligned_and_out_of_range_tiles_fault_with_the_tile_address(self):
        res = self._run("addi r1, r0, 2\n mma r0, r1, r0")
        self.assertEqual((res.fault["CODE"], res.fault["DATA"]), (19 + 2, 2))              # F_SMEM_ALIGN = 21
        limit = 4 * (F_IEEE.a_words + F_IEEE.b_words + F_IEEE.c_words)
        res = self._run(f"li r1, {limit - 4}\n mma r1, r0, r0", shared=limit)               # the C/D tile overruns the region
        self.assertEqual((res.fault["CODE"], res.fault["DATA"]), (22, limit - 4))             # F_SMEM_RANGE, data = tile address
        res = self._run(f"li r1, {limit - 4}\n mma r0, r1, r0", shared=limit)               # ... or the A tile
        self.assertEqual((res.fault["CODE"], res.fault["DATA"]), (22, limit - 4))
        res = self._run(f"li r1, {limit - 4}\n mma r0, r0, r1", shared=limit)               # ... or the B tile
        self.assertEqual((res.fault["CODE"], res.fault["DATA"]), (22, limit - 4))
        res = self._run("mma r0, r0, r0", shared=limit)                                       # all three at 0: legal (aliased tiles)
        self.assertTrue(res.ok, res)

    def test_fault_precedence_is_tile_by_tile_then_nonuniform_register_major(self):
        """docs F4 5.2/5.3: uniformity is checked first (register order rd, rs1, rs2; lowest differing lane); then A, B, C, each alignment before range."""
        limit = 4 * (F_IEEE.a_words + F_IEEE.b_words + F_IEEE.c_words)
        # A aligned but out of range, B misaligned: the A range fault wins (A is checked before B)
        res = self._run(f"li r1, {limit - 4}\n addi r2, r0, 2\n mma r0, r1, r2", shared=limit)
        self.assertEqual((res.fault["CODE"], res.fault["DATA"]), (22, limit - 4))
        # A misaligned and out of range: ALIGN beats RANGE for the same tile
        res = self._run(f"li r1, {limit + 2}\n mma r0, r1, r0", shared=limit)
        self.assertEqual((res.fault["CODE"], res.fault["DATA"]), (21, limit + 2))
        # rs1 differs at lane 1, rd differs at lane 5: the register scan order (rd first) reports rd, lane 5
        body = "rdsr r1, SR_LANE_ID\n addi r2, r0, 4\n slti r3, r1, 5\n xori r3, r3, 1\n shli r3, r3, 2\n addi r4, r0, 0\n slti r5, r1, 2\n xori r5, r5, 1\n sub r5, r5, r4\n mma r3, r5, r0"
        # rd = 4 for lanes >= 5 (else 0); rs1 = 1 for lanes >= 2 (else 0) -> rs1 first differs at lane 2, rd at lane 5
        res = self._run(body)
        self.assertEqual(res.fault["CODE"], FAULTS["F_MMA_NONUNIFORM"])
        self.assertEqual(((res.fault["LOC"] >> 16) & 0xFF, res.fault["DATA"]), (5, 4))     # rd is scanned before rs1

    def test_address_check_is_not_modular(self):
        """docs F4 5.3: address + tile size is compared in unbounded arithmetic; 0xFFFFFFFC must not wrap around to a legal range."""
        res = self._run("li r1, 0xFFFFFFFC\n mma r0, r1, r0")
        self.assertEqual((res.fault["CODE"], res.fault["DATA"]), (22, 0xFFFFFFFC))

    def test_assembler_rejects_contradictory_modifiers(self):
        from sfg1.asm import AsmError
        for bad in ("mma.bf16.f16 r1, r2, r3", "ffma.rtz.rdn r1, r2, r3", "mma.rne.rup r1, r2, r3", "ffma.f16 r1, r2, r3", "fadd.bf16 r1, r2, r3"):
            with self.assertRaises(AsmError, msg=bad):
                assemble(bad + "\nexit\n")
        assemble("mma.bf16.rtz r1, r2, r3\nffma.rup r1, r2, r3\nexit\n")     # one of each is fine

    def test_mma_without_extension_registers_is_not_decodable(self):
        host = Host(LocalTransport(Device(CFG)), CFG)
        kern = host.load_kernel([ext_isa().encode("mma", rd=0, rs1=0, rs2=0), isa().encode("exit")])
        self.assertEqual(host.launch(kern, 1, 8, shared=1024).error, "F_ILLEGAL_INSN")


class EndToEndKernels(unittest.TestCase):
    def test_sgemm_fused_and_unfused_match_their_references_and_differ(self):
        rng = random.Random(8)
        M, N, Kd = 8, 8, 16
        A, B = K.rand_f32_matrix(rng, M * Kd, "wide"), K.rand_f32_matrix(rng, Kd * N, "wide")
        outs = {}
        for kind in ("fused", "unfused"):
            C, res, _ = K.run_sgemm(kind, A, B, M, N, Kd, F_IEEE)
            self.assertTrue(res.ok)
            self.assertEqual(C, K.sgemm_reference(A, B, M, N, Kd, fused=(kind == "fused")), kind)
            outs[kind] = C
        self.assertNotEqual(outs["fused"], outs["unfused"])        # fusing changes bits: it is a real numerical difference

    def test_sgemm_restricted_profile_matches_restricted_reference(self):
        rng = random.Random(9)
        M, N, Kd = 4, 8, 8
        A, B = K.rand_f32_matrix(rng, M * Kd, "wide"), K.rand_f32_matrix(rng, Kd * N, "wide")
        C, res, _ = K.run_sgemm("fused", A, B, M, N, Kd, F_RESTR)
        self.assertEqual(C, K.sgemm_reference(A, B, M, N, Kd, True, profile=fp.PROFILE_RESTRICTED))

    def test_mma_gemm_equals_the_monolithic_chain_for_every_format_and_rounding_mode(self):
        rng = random.Random(10)
        for fmt in (mx.FMT_F16, mx.FMT_BF16):
            for rm in range(5):
                A = K.rand_matrix16(rng, 8, 16, fmt, "wide"); B = K.rand_matrix16(rng, 16, 8, fmt, "wide")
                C, res, host = K.run_mma_gemm(A, B, F_IEEE, fmt, rm)
                self.assertTrue(res.ok, res)
                self.assertEqual(C, K.gemm_reference(A, B, fmt, rm, fp.PROFILE_IEEE), (fmt, rm))

    def test_result_is_independent_of_the_tile_decomposition(self):
        """4x4x8, 2x2x2 and 8x2x4 tiles decompose the same GEMM differently; the bits must be identical."""
        rng = random.Random(11)
        A = K.rand_matrix16(rng, 8, 16, mx.FMT_F16, "wide"); B = K.rand_matrix16(rng, 16, 8, mx.FMT_F16, "wide")
        outs = [K.run_mma_gemm(A, B, f)[0] for f in (F_IEEE, F_SMALL, F_RECT)]
        self.assertEqual(outs[0], outs[1])
        self.assertEqual(outs[0], outs[2])
        self.assertEqual(outs[0], K.gemm_reference(A, B, mx.FMT_F16, 0, fp.PROFILE_IEEE))

    def test_results_independent_of_the_base_machine_configuration(self):
        """Lanes, warps, execution groups and workgroup slots of the base machine must not change one result bit."""
        rng = random.Random(14)
        A = K.rand_matrix16(rng, 8, 16, mx.FMT_BF16, "wide"); B = K.rand_matrix16(rng, 16, 8, mx.FMT_BF16, "wide")
        a32, b32 = K.rand_f32_matrix(rng, 8 * 16, "wide"), K.rand_f32_matrix(rng, 16 * 8, "wide")
        outs, souts = [], []
        for cname in ("default", "small", "wide"):
            cfg = Config.from_file(cname)
            C, res, _ = K.run_mma_gemm(A, B, F_IEEE, mx.FMT_BF16, 0, cfg=cfg)
            self.assertTrue(res.ok, (cname, res))
            outs.append(C)
            sc, sres, _ = K.run_sgemm("fused", a32, b32, 8, 8, 16, F_IEEE, cfg=cfg, wg=4)
            self.assertTrue(sres.ok, (cname, sres))
            souts.append(sc)
        self.assertEqual(outs[0], outs[1]); self.assertEqual(outs[0], outs[2])
        self.assertEqual(souts[0], souts[1]); self.assertEqual(souts[0], souts[2])

    def test_mma_gemm_with_edge_operands_nan_inf_subnormal(self):
        rng = random.Random(12)
        for fmt in (mx.FMT_F16, mx.FMT_BF16):
            A = K.rand_matrix16(rng, 8, 16, fmt, "mixed"); B = K.rand_matrix16(rng, 16, 8, fmt, "mixed")
            C, res, host = K.run_mma_gemm(A, B, F_IEEE, fmt)
            self.assertEqual(C, K.gemm_reference(A, B, fmt, 0, fp.PROFILE_IEEE))

    def test_mma_gemm_restricted_profile(self):
        rng = random.Random(13)
        A = K.rand_matrix16(rng, 8, 16, mx.FMT_BF16, "mixed"); B = K.rand_matrix16(rng, 16, 8, mx.FMT_BF16, "mixed")
        C, res, _ = K.run_mma_gemm(A, B, F_RESTR, mx.FMT_BF16)
        self.assertEqual(C, K.gemm_reference(A, B, mx.FMT_BF16, 0, fp.PROFILE_RESTRICTED))

    def test_mma_flags_reach_every_lane_in_the_ieee_profile(self):
        # one tile of overflowing bf16 products: the NV/OF/NX flags must be readable with frflags after the mma
        f = F_SMALL
        big = 0x7F7F                      # bf16 max finite
        A = [[big] * f.mma_k for _ in range(f.mma_m)]; B = [[big] * f.mma_k for _ in range(f.mma_n)]
        host = open_fpx(CFG, f)
        aw, bw, cw = f.a_words, f.b_words, f.c_words
        out = host.alloc(32)
        src = f"""
            rdsr r1, SR_ARG0
            mmaz.bf16 r0, r0, r0
            frflags r2
            rdsr r3, SR_ARG1
            stg r2, [r3]
            exit
        """
        ga = host.alloc(4 * (aw + bw))
        host.write_words(ga, mx.pack_tile(A) + mx.pack_tile(B))
        # stage tiles with sts from a tiny prologue
        pro = "\n".join(["rdsr r5, SR_ARG2", "addi r6, r0, 0"] +
                        [f"ldg r7, [r5+{4*i}]\n sts r7, [r0+{4*i}]" for i in range(aw + bw)])
        src2 = pro + f"""
            addi r8, r0, {4*aw}
            addi r9, r0, {4*(aw+bw)}
            mmaz.bf16 r9, r0, r8
            frflags r2
            rdsr r3, SR_ARG1
            stg r2, [r3]
            exit
        """
        kern = host.load_kernel(assemble(src2).words)
        res = host.launch(kern, 1, 8, shared=4 * (aw + bw + cw), args=[0, out, ga])
        self.assertTrue(res.ok, res)
        expect = mx.mma_tile(f.mma_m, f.mma_n, f.mma_k, mx.FMT_BF16, 0, 0, mx.pack_tile(A), mx.pack_tile(B), None)[1]
        self.assertEqual(host.read_words(out, 1)[0], expect)
        self.assertEqual(expect & (fp.OF | fp.NX), fp.OF | fp.NX)


if __name__ == "__main__":
    unittest.main()
