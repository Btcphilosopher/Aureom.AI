"""The restricted numerical profile SFX-R: what it is, and that it is NOT IEEE 754 conformant.

SFX-R = DAZ on operands -> round-to-nearest-even IEEE result -> FTZ on the result, no flags
(docs/fpx/F1-numerics.md 4.3).  These tests pin the exact boundary of that definition.
"""
import random
import unittest

from sfg1.fpx import fp
from sfg1.fpx.oracle import SoftFloat, OracleUnavailable, OPC_FMA, OPC_ADD, OPC_SUB, OPC_MUL
from sfg1.fpx.vectors_fp import random_triples, edge_triples, F32_EDGE

SUB = fp.is_subnormal32


class RestrictedProfile(unittest.TestCase):
    def test_flags_never_raised(self):
        for a, b, c in list(random_triples(20000, 7)) + edge_triples()[:20000]:
            for op in range(7):
                self.assertEqual(fp.restricted_op(op, a, b, c)[1], 0)

    def test_never_delivers_a_subnormal(self):
        for a, b, c in random_triples(30000, 8):
            for op in range(7):
                self.assertFalse(SUB(fp.restricted_op(op, a, b, c)[0]))

    def test_subnormal_operands_read_as_signed_zero(self):
        rng = random.Random(3)
        for _ in range(5000):
            sgn = rng.getrandbits(1) << 31
            sub = sgn | rng.randrange(1, 1 << 23)
            zero = sgn
            b, c = fp.F32.qnan if rng.random() < 0.05 else rng.getrandbits(32), rng.getrandbits(32)
            for op in range(7):
                self.assertEqual(fp.restricted_op(op, sub, b, c), fp.restricted_op(op, zero, b, c))
                self.assertEqual(fp.restricted_op(op, b, sub, c), fp.restricted_op(op, b, zero, c))
                self.assertEqual(fp.restricted_op(op, b, c, sub), fp.restricted_op(op, b, c, zero))

    def test_agrees_with_ieee_rne_when_no_subnormal_is_involved(self):
        """Outside the subnormal domain SFX-R is exactly IEEE round-to-nearest-even."""
        n = 0
        for a, b, c in random_triples(40000, 9):
            if SUB(a) or SUB(b) or SUB(c):
                continue
            for op in range(7):
                ieee, _ = fp.ieee_op(op, a, b, c, fp.RM_RNE)
                if SUB(ieee):
                    continue
                n += 1
                self.assertEqual(fp.restricted_op(op, a, b, c)[0], ieee)
        self.assertGreater(n, 100000)

    def test_ignores_the_rounding_mode(self):
        for a, b, c in random_triples(3000, 10):
            for op in range(7):
                for rm in range(8):
                    self.assertEqual(fp.unit_op(fp.PROFILE_RESTRICTED, op, a, b, c, rm), fp.restricted_op(op, a, b, c))

    @staticmethod
    def pow2(sign, e):
        """binary32 bit pattern of (-1)^sign * 2^e for a normal exponent e (built from fields, not typed in hex)."""
        assert -126 <= e <= 127
        return (sign << 31) | ((e + 127) << 23)

    def test_underflow_to_zero_keeps_the_sign(self):
        tiny, half = self.pow2(0, -126), self.pow2(0, -1)
        # 2^-126 * 0.5 = 2^-127 is an EXACT subnormal: IEEE raises nothing (underflow needs tiny AND inexact)
        self.assertEqual(fp.ieee_op(fp.OP_MUL, tiny, half, 0, fp.RM_RNE), (0x00400000, 0))
        self.assertEqual(fp.restricted_op(fp.OP_MUL, tiny, half, 0), (0x00000000, 0))
        self.assertEqual(fp.restricted_op(fp.OP_MUL, tiny | 0x80000000, half, 0), (0x80000000, 0))

    def test_rounding_up_into_min_normal_is_not_flushed(self):
        """The documented corner of the definition (F1 4.3).

        2^-100 * -2^-50 + 2^-126 = 2^-126 - 2^-150.  Rounded with an unbounded exponent range this is still
        below 2^-126 (tiny), but on the gradual-underflow grid it is a tie that rounds to even = the smallest
        NORMAL number.  SFX-R is defined as 'flush delivered subnormals', so the normal result survives; a design
        that flushed on the pre-rounding exponent would deliver 0 here and would NOT conform to SFX-R.
        """
        a, b, c = self.pow2(0, -100), self.pow2(1, -50), self.pow2(0, -126)
        self.assertEqual(c, 0x00800000)
        self.assertEqual(fp.ieee_op(fp.OP_FMA, a, b, c, fp.RM_RNE), (0x00800000, fp.UF | fp.NX))
        self.assertEqual(fp.restricted_op(fp.OP_FMA, a, b, c), (0x00800000, 0))
        try:
            sf = SoftFloat()
        except OracleUnavailable:
            return
        self.assertEqual(sf.f32(OPC_FMA, a, b, c, 0), (0x00800000, fp.UF | fp.NX))   # independent confirmation

    def test_not_ieee_conformant_is_demonstrated_not_asserted(self):
        """SFX-R differs from IEEE on a plain subnormal result, which is why it must never be labelled IEEE."""
        a, b = 0x00000001, 0x3F800000             # min subnormal * 1.0
        self.assertEqual(fp.ieee_op(fp.OP_MUL, a, b, 0, fp.RM_RNE), (0x00000001, 0))
        self.assertEqual(fp.restricted_op(fp.OP_MUL, a, b, 0), (0, 0))

    @unittest.skipUnless(SoftFloat and True, "")
    def test_composition_matches_softfloat_composition(self):
        try:
            sf = SoftFloat()
        except OracleUnavailable:
            self.skipTest("SoftFloat not built")
        S = fp.SIGN32
        mism = 0
        for a, b, c in random_triples(30000, 11):
            da, db, dc = fp.daz(a), fp.daz(b), fp.daz(c)
            cases = ((fp.OP_FMA, sf.f32(OPC_FMA, da, db, dc, 0)), (fp.OP_FMS, sf.f32(OPC_FMA, da, db, dc ^ S, 0)),
                     (fp.OP_FNMA, sf.f32(OPC_FMA, da ^ S, db, dc, 0)), (fp.OP_FNMS, sf.f32(OPC_FMA, da ^ S, db, dc ^ S, 0)),
                     (fp.OP_ADD, sf.f32(OPC_ADD, da, db, 0, 0)), (fp.OP_SUB, sf.f32(OPC_SUB, da, db, 0, 0)),
                     (fp.OP_MUL, sf.f32(OPC_MUL, da, db, 0, 0)))
            for op, (res, _fl) in cases:
                if fp.restricted_op(op, a, b, c) != (fp.ftz(res), 0):
                    mism += 1
        self.assertEqual(mism, 0)


if __name__ == "__main__":
    unittest.main()
