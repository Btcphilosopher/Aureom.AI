"""The reference rounding code against an independent brute-force definition, EXHAUSTIVELY on tiny formats.

Because ``sfg1.fpx.fp`` is format generic, a proof-by-enumeration on tiny formats covers the very same
``round_pack`` / special-case code that binary32 uses.  Every operand triple (or pair) of the format
is checked for all five rounding modes: 100 % of the input space, results and flags.
"""
import itertools
import random
import unittest

from sfg1.fpx import fp
from . import brute


def run_fma(ebits, mbits, sample=None, seed=1):
    t = brute.Tiny(ebits, mbits)
    f = fp.Fmt(f"E{ebits}M{mbits}", ebits, mbits)
    n = t.nbits
    triples = itertools.product(range(n), repeat=3) if sample is None else (
        tuple(random.Random(seed + i).randrange(n) for _ in range(3)) for i in range(sample))
    count = bad = 0
    cov = {"OF": 0, "UF": 0, "NX": 0, "NV": 0, "sub_result": 0}
    for a, b, c in triples:
        for rm in range(5):
            got = fp.fma(f, a, b, c, rm)
            exp = brute.fma(t, a, b, c, rm)
            count += 1
            if got != exp:
                bad += 1
                if bad <= 5:
                    print(f"MISMATCH E{ebits}M{mbits} fma a={a:#x} b={b:#x} c={c:#x} rm={rm} got={got} exp={exp}")
            fl = exp[1]
            cov["OF"] += bool(fl & brute.OF); cov["UF"] += bool(fl & brute.UF)
            cov["NX"] += bool(fl & brute.NX); cov["NV"] += bool(fl & brute.NV)
            e_field = (exp[0] >> mbits) & ((1 << ebits) - 1)
            cov["sub_result"] += (e_field == 0 and (exp[0] & ((1 << mbits) - 1)) != 0)
    return count, bad, cov


def run_binary(ebits, mbits, op):
    t = brute.Tiny(ebits, mbits)
    f = fp.Fmt(f"E{ebits}M{mbits}", ebits, mbits)
    mod, ref = (brute.add, fp.add) if op == "add" else ((brute.mul, fp.mul) if op == "mul" else (None, None))
    n = t.nbits
    count = bad = 0
    for a, b in itertools.product(range(n), repeat=2):
        for rm in range(5):
            if op == "sub":
                exp = brute.add(t, a, b ^ (1 << (t.width - 1)), rm)
                got = fp.sub(f, a, b, rm)
            else:
                exp = mod(t, a, b, rm)
                got = ref(f, a, b, rm)
            count += 1
            if got != exp:
                bad += 1
                if bad <= 5:
                    print(f"MISMATCH E{ebits}M{mbits} {op} a={a:#x} b={b:#x} rm={rm} got={got} exp={exp}")
    return count, bad


class ExhaustiveTiny(unittest.TestCase):
    def test_fma_e2m2_exhaustive(self):
        n, bad, cov = run_fma(2, 2)
        self.assertEqual(n, 32 ** 3 * 5)
        self.assertEqual(bad, 0)
        # the enumeration must really have exercised the hard cases (not a vacuous pass)
        for k in ("OF", "UF", "NX", "NV", "sub_result"):
            self.assertGreater(cov[k], 100, k)

    def test_fma_e3m2_exhaustive(self):
        n, bad, cov = run_fma(3, 2)
        self.assertEqual(n, 64 ** 3 * 5)
        self.assertEqual(bad, 0)
        for k in ("OF", "UF", "NX", "NV", "sub_result"):
            self.assertGreater(cov[k], 1000, k)

    def test_fma_e4m3_random_sample(self):
        n, bad, cov = run_fma(4, 3, sample=60000, seed=77)
        self.assertEqual(bad, 0)
        self.assertGreater(cov["UF"], 100)
        self.assertGreater(cov["OF"], 100)

    def test_add_sub_mul_exhaustive(self):
        for ebits, mbits in ((2, 2), (3, 2), (3, 3), (4, 3), (5, 2)):
            for op in ("add", "sub", "mul"):
                n, bad = run_binary(ebits, mbits, op)
                self.assertEqual(n, (1 << (1 + ebits + mbits)) ** 2 * 5)
                self.assertEqual(bad, 0, f"E{ebits}M{mbits} {op}")


if __name__ == "__main__":
    unittest.main()
