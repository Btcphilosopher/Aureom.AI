"""Reference model vs Berkeley SoftFloat 3e / TestFloat 3e (independent third-party C implementation).

Compares all 32 result bits (NaNs included) and all five flags.  Coverage counters guard against a
vacuous pass: every flag, every rounding mode, subnormal results and NaN results must be hit.
"""
import subprocess
import unittest

from sfg1.fpx import fp
from sfg1.fpx.oracle import SoftFloat, OracleUnavailable, TESTFLOAT_DIR, OPC_FMA, OPC_ADD, OPC_SUB, OPC_MUL
from sfg1.fpx.vectors_fp import random_triples, edge_triples

try:
    SF = SoftFloat()
except OracleUnavailable:  # pragma: no cover
    SF = None

S = fp.SIGN32


def sf_unit_op(op, a, b, c, rm):
    """SoftFloat's answer for a unit operation (sign flips are the *definition* of FMS/FNMA/FNMS)."""
    if op == fp.OP_FMA:
        return SF.f32(OPC_FMA, a, b, c, rm)
    if op == fp.OP_FMS:
        return SF.f32(OPC_FMA, a, b, c ^ S, rm)
    if op == fp.OP_FNMA:
        return SF.f32(OPC_FMA, a ^ S, b, c, rm)
    if op == fp.OP_FNMS:
        return SF.f32(OPC_FMA, a ^ S, b, c ^ S, rm)
    if op == fp.OP_ADD:
        return SF.f32(OPC_ADD, a, b, 0, rm)
    if op == fp.OP_SUB:
        return SF.f32(OPC_SUB, a, b, 0, rm)
    return SF.f32(OPC_MUL, a, b, 0, rm)


@unittest.skipIf(SF is None, "SoftFloat oracle not built (fpx/ref/build_ref.sh)")
class VsSoftFloat(unittest.TestCase):
    def _compare(self, triples, ops, rms=range(5)):
        n = bad = 0
        cov = {"NV": 0, "OF": 0, "UF": 0, "NX": 0, "subres": 0, "nanres": 0, "rm": set(), "op": set()}
        for (a, b, c) in triples:
            for op in ops:
                for rm in rms:
                    got = fp.ieee_op(op, a, b, c, rm)
                    exp = sf_unit_op(op, a, b, c, rm)
                    n += 1
                    if got != exp:
                        bad += 1
                        if bad <= 8:
                            print(f"MISMATCH op={fp.OP_NAMES[op]} a={a:08x} b={b:08x} c={c:08x} rm={rm} "
                                  f"ref=({got[0]:08x},{fp.flags_str(got[1])}) softfloat=({exp[0]:08x},{fp.flags_str(exp[1])})")
                    fl = exp[1]
                    for k, m in (("NV", fp.NV), ("OF", fp.OF), ("UF", fp.UF), ("NX", fp.NX)):
                        cov[k] += bool(fl & m)
                    cov["subres"] += fp.is_subnormal32(exp[0])
                    cov["nanres"] += ((exp[0] >> 23) & 0xFF) == 0xFF and (exp[0] & 0x7FFFFF) != 0
                    cov["rm"].add(rm); cov["op"].add(op)
        return n, bad, cov

    def test_random_all_ops_all_modes(self):
        n, bad, cov = self._compare(random_triples(40000, seed=2024), range(7))
        self.assertEqual(bad, 0)
        self.assertEqual(cov["rm"], set(range(5)))
        self.assertEqual(cov["op"], set(range(7)))
        for k in ("NV", "OF", "UF", "NX", "subres", "nanres"):
            self.assertGreater(cov[k], 500, f"coverage hole: {k}")

    def test_edge_cross_product(self):
        n, bad, cov = self._compare(edge_triples(), (fp.OP_FMA, fp.OP_ADD, fp.OP_MUL))
        self.assertEqual(bad, 0)
        self.assertGreater(n, 400000)

    def test_binary16_vs_softfloat(self):
        import random
        rng = random.Random(5)
        bad = 0
        for _ in range(150000):
            a, b, c = (rng.getrandbits(16) for _ in range(3))
            rm = rng.randrange(5)
            for opc, fn in ((OPC_FMA, lambda: fp.fma(fp.F16, a, b, c, rm)), (OPC_ADD, lambda: fp.add(fp.F16, a, b, rm)),
                            (OPC_SUB, lambda: fp.sub(fp.F16, a, b, rm)), (OPC_MUL, lambda: fp.mul(fp.F16, a, b, rm))):
                if fn() != SF.f16(opc, a, b, c, rm):
                    bad += 1
        self.assertEqual(bad, 0)

    def _testfloat(self, fn, rmarg, rm, nlines, nargs):
        gen = TESTFLOAT_DIR / "testfloat_gen"
        if not gen.exists():
            self.skipTest("testfloat_gen not built")
        p = subprocess.Popen([str(gen), "-level", "1", rmarg, "-tininessafter", fn],
                             stdout=subprocess.PIPE, text=True)
        bad = n = 0
        for line in p.stdout:
            w = line.split()
            ops = [int(x, 16) for x in w[:nargs]]
            z, fl = int(w[nargs], 16), int(w[nargs + 1], 16)
            if fn == "f32_mulAdd":
                got = fp.fma(fp.F32, ops[0], ops[1], ops[2], rm)
            elif fn == "f32_add":
                got = fp.add(fp.F32, ops[0], ops[1], rm)
            elif fn == "f32_sub":
                got = fp.sub(fp.F32, ops[0], ops[1], rm)
            else:
                got = fp.mul(fp.F32, ops[0], ops[1], rm)
            n += 1
            if got != (z, fl):
                bad += 1
                if bad <= 5:
                    print(f"TESTFLOAT MISMATCH {fn} {line.strip()} ref=({got[0]:08x},{got[1]:02x})")
            if n >= nlines:
                break
        p.kill(); p.wait(); p.stdout.close()
        return n, bad

    def test_testfloat_hard_cases(self):
        modes = (("-rnear_even", 0), ("-rminMag", 1), ("-rmin", 2), ("-rmax", 3), ("-rnear_maxMag", 4))
        total = 0
        for rmarg, rm in modes:
            for fn, nargs, lines in (("f32_mulAdd", 3, 30000), ("f32_add", 2, 8000), ("f32_sub", 2, 8000), ("f32_mul", 2, 8000)):
                n, bad = self._testfloat(fn, rmarg, rm, lines, nargs)
                self.assertEqual(bad, 0, f"{fn} {rmarg}")
                self.assertGreater(n, 1000)
                total += n
        self.assertGreater(total, 200000)


@unittest.skipUnless(__import__("sfg1.fpx.oracle", fromlist=["x"]).mpfr_available(), "gmpy2/MPFR not installed")
class VsMPFR(unittest.TestCase):
    def test_binary32_fma_values_vs_mpfr(self):
        from sfg1.fpx.oracle import mpfr_f32_fma
        n = bad = skipped = 0
        for (a, b, c) in random_triples(30000, seed=99):
            for rm in (0, 1, 2, 3):
                exp = mpfr_f32_fma(a, b, c, rm)
                if exp is None:
                    skipped += 1
                    continue
                got = fp.fma(fp.F32, a, b, c, rm)[0]
                n += 1
                if got != exp:
                    bad += 1
                    if bad <= 5:
                        print(f"MPFR MISMATCH a={a:08x} b={b:08x} c={c:08x} rm={rm} ref={got:08x} mpfr={exp:08x}")
        self.assertEqual(bad, 0)
        self.assertGreater(n, 50000)


if __name__ == "__main__":
    unittest.main()
