"""The generated RTL package, decoder package and C header must agree with spec/ext/sf_g1_fpx.json for EVERY named config.

Same idea as sim/tests/test_consistency.py for the base tree: parse the generated files back and compare each constant
with the JSON, so RTL, C and Python cannot drift apart.
"""
import re
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "tools"))

import gen_fpx  # noqa: E402
from sfg1.fpx.config import FpxConfig, ext_isa, load_ext_spec  # noqa: E402
from sfg1.spec import Config  # noqa: E402

EXT = load_ext_spec()


def sv_int(text: str, name: str) -> int:
    m = re.search(rf"localparam\s+(?:int|logic\s*(?:\[[^\]]+\])?)\s+{name}\s*=\s*(?:\d+'h([0-9a-fA-F]+)|\d+'d(\d+)|(\d+))\s*;", text)
    assert m, f"{name} not found"
    return int(m.group(1), 16) if m.group(1) else int(m.group(2) or m.group(3))


def enum_value(text: str, name: str) -> int:
    m = re.search(rf"\b{name}\s*=\s*\d+'d(\d+)", text)
    assert m, f"{name} not found"
    return int(m.group(1))


class GeneratedFilesMatchTheJson(unittest.TestCase):
    def test_every_named_configuration(self):
        for cfg in FpxConfig.named():
            files = gen_fpx.generate(cfg)
            pkg, c_h = files["fpx/rtl/gen/sf_g1_fpx_pkg.sv"], files["sw/include/gen/sf_g1_fpx.h"]
            for k in cfg.parameter_table():
                self.assertEqual(sv_int(pkg, "FPX_" + k.upper()), getattr(cfg, k), (cfg.name, k))
                self.assertIn(f"SFG1_FPX_{k.upper()}", c_h)
            self.assertEqual(sv_int(pkg, "MMA_A_WORDS"), cfg.a_words)
            self.assertEqual(sv_int(pkg, "MMA_B_WORDS"), cfg.b_words)
            self.assertEqual(sv_int(pkg, "MMA_C_WORDS"), cfg.c_words)
            self.assertEqual(sv_int(pkg, "FMA_LATENCY"), cfg.fma_latency)
            self.assertEqual(sv_int(pkg, "FPX_CFG_HASH"), cfg.cfg_hash(Config.default()))
            self.assertEqual(sv_int(pkg, "FPX_CAPS"), cfg.caps_fpx())
            self.assertEqual(sv_int(pkg, "FPX_MMA_SHAPE"), cfg.caps_mma())
            self.assertIn(f"0x{cfg.cfg_hash():08x}u", c_h)
            for r in EXT["rounding_modes"]:
                self.assertEqual(enum_value(pkg, f"FPX_RM_{r['name']}"), r["code"])
                self.assertRegex(c_h, rf"SFG1_RM_{r['name']}\s+{r['code']}\b")
            for f in EXT["flags"]:
                self.assertEqual(sv_int(pkg, f"FPX_FLAG_{f['name']}_BIT"), f["bit"])
            for f in EXT["fp_functions"]:
                self.assertEqual(enum_value(pkg, f"FPFN_{f['name']}"), f["code"])
            for f in EXT["mma_functions"]:
                self.assertEqual(enum_value(pkg, f"MMAFN_{f['name']}"), f["code"])
            for c in EXT["classes"]:
                self.assertEqual(sv_int(pkg, f"ICLASS_{c['name']}"), c["code"])
            for d in EXT["instructions"]:
                self.assertEqual(enum_value(pkg, f"FPX_OP_{d['mnemonic'].upper()}"), d["opcode"])
                self.assertRegex(c_h, rf"SFG1_OP_{d['mnemonic'].upper()}\s+{d['opcode']}\b")
                self.assertIn(f"`{d['mnemonic']}`", files["docs/fpx/generated/isa_reference.md"])
            for s in EXT["special_registers"]:
                self.assertEqual(sv_int(pkg, s["name"]), s["index"])
            for r in EXT["registers"]:
                self.assertEqual(sv_int(pkg, f"REG_{r['name']}"), int(r["offset"], 0))
            for f in EXT["faults"]:
                self.assertEqual(sv_int(pkg, f["name"]), f["code"])

    def test_opcodes_do_not_collide_with_the_base_isa(self):
        base = set(ext_isa().by_opcode) - set(ext_isa().ext_by_opcode)
        self.assertEqual(len(base), 35)
        self.assertFalse(base & set(ext_isa().ext_by_opcode))
        self.assertEqual(len(ext_isa().ext_by_opcode), len(EXT["instructions"]))

    def test_unit_rtl_op_codes_are_the_isa_function_codes(self):
        """in_op of sf_fpx_unit IS the decoded alu_fn: the model's OP_* constants must equal the JSON function codes."""
        from sfg1.fpx import fp
        by = {f["name"]: f["code"] for f in EXT["fp_functions"]}
        for name, code in (("FMA", fp.OP_FMA), ("FMS", fp.OP_FMS), ("FNMA", fp.OP_FNMA), ("FNMS", fp.OP_FNMS),
                           ("ADD", fp.OP_ADD), ("SUB", fp.OP_SUB), ("MUL", fp.OP_MUL)):
            self.assertEqual(by[name], code)

    def test_generated_files_in_tree_are_current(self):
        cfg = FpxConfig.default()
        for rel, text in gen_fpx.generate(cfg).items():
            self.assertEqual((ROOT / rel).read_text(), text, rel)

    def test_rtl_source_has_no_hardcoded_geometry(self):
        """The engine takes its geometry from parameters only; guard against literals sneaking in."""
        src = (ROOT / "fpx/rtl/sf_mma_engine.sv").read_text()
        self.assertNotRegex(src, r"\bM\s*=\s*\d+;")        # no localparam redefining M
        self.assertIn("parameter int       M ", src)


if __name__ == "__main__":
    unittest.main()
