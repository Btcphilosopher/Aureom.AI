"""Dashboard builder tests: embedding, tolerance of missing / malformed / partly-unavailable datasets, size cap,
script-injection safety, and (when node + playwright are available) the browser smoke test in dashboard_smoke.mjs."""
import copy
import json
import math
import os
import re
import shutil
import subprocess

import pytest

from sramlab import dashboard as D

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SMOKE = os.path.join(ROOT, "tests", "dashboard_smoke.mjs")
REAL_DATA = os.path.join(ROOT, "data")
DATA_RE = re.compile(r'<script type="application/json" id="sramlab-data">(.*?)</script>', re.S)


def extract(html: str) -> dict:
    m = DATA_RE.search(html)
    assert m, "embedded JSON element not found"
    return json.loads(m.group(1))


def write(d, name, obj):
    path = os.path.join(str(d), name)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        f.write(obj if isinstance(obj, str) else json.dumps(obj))
    return path


def mini_bank_sweep():
    def stat(m, hw=0.01, n=10):
        return {"n": n, "mean": m, "std": 0.1, "half_width": hw, "lo": m - hw, "hi": m + hw, "conf": 0.95, "relative_half_width": hw / m}
    rows = []
    for wl in ("rand_read", "mixed"):
        for b in (2, 4):
            rows.append({"workload": wl, "banks": b, "label": "simulated", "replications": 10, "throughput_txn_per_cycle": stat(1.5), "useful_bytes_per_cycle": stat(6.0),
                         "read_bytes_per_cycle": stat(4.0), "write_bytes_per_cycle": stat(2.0), "read_latency_mean": stat(3.2), "read_latency_p99": stat(5.0, 0.0),
                         "conflict_rate_per_access": stat(0.2), "bank_utilisation_mean": stat(0.7), "arbitration_delay_mean": stat(1.2), "efficiency_vs_peak": stat(0.7),
                         "bit_activations_per_useful_byte": stat(8.0, 0.0), "latency_histogram": {"3": 90, "4": 9, "5": 1},
                         "conflict_cycle_fraction_per_bank": [0.1] * b, "bank_utilisation_per_bank": [0.7] * b, "tracker_occupancy_mean_per_bank": [0.5] * b,
                         "outstanding_mean": stat(1.0), "analytical_peak_txn_per_cycle": float(b), "analytical_random_estimate_txn_per_cycle": b * 0.9,
                         "capacity_bytes": 65536, "bank_depth_words": 65536 // (4 * b), "per_replication": [{"x": 1}] * 10})
    return {"max_out_1": {"label": "simulated", "capacity_bytes": 65536, "rows": rows, "note": "n"}}


@pytest.fixture
def mini(tmp_path):
    d = tmp_path / "data"
    d.mkdir()
    write(d, "bank_sweep.json", mini_bank_sweep())
    write(d, "rtl_verification.json", {"cases": 3, "passed": 3, "failed": 0, "cycles_compared": 30, "transactions": 9, "counters_compared": 6, "parameter_sets": 1,
                                       "results": [{"label": "a/x", "ok": True, "cycles_compared": 10, "rtl_effective_config": {"big": "x" * 500}, "first_trace_divergence": None}] * 3,
                                       "mutation_check": [{"mutation": "m", "detected": True, "first_divergence": {"model": "long" * 100}, "counter_diffs": 2}]})
    return str(d)


def build(data_dir, tmp_path, name="out.html", **kw):
    out = str(tmp_path / name)
    return D.build(data_dir, out, probe_tools=False, **kw)


# ------------------------------------------------------------------------------------------ Python side
def test_build_returns_path_and_writes_one_self_contained_file(mini, tmp_path):
    out = build(mini, tmp_path)
    assert out == str(tmp_path / "out.html") and os.path.isfile(out)
    html = open(out, encoding="utf-8").read()
    # single file, no network: no external script/stylesheet/font/import references
    assert "<script src" not in html and 'rel="stylesheet"' not in html and "@import" not in html
    urls = set(re.findall(r"https?://[^\s'\"<>)]+", html))
    assert urls <= {"http://www.w3.org/2000/svg"}, urls
    assert html.count("</script>") == 2                      # the JSON element and the one inline script
    assert html.count("<style>") == 1 and "SilicaFlux SRAMLab" in html
    assert os.path.getsize(out) < 6_000_000


def test_embeds_datasets_trimmed_and_tagged(mini, tmp_path):
    b = extract(open(build(mini, tmp_path), encoding="utf-8").read())
    assert b["schema"] == D.SCHEMA and b["measured_exists"] is False
    ds = b["datasets"]
    rows = ds["bank_sweep"]["max_out_1"]["rows"]
    assert len(rows) == 4
    # statistics reduced to {n, mean, half_width}; raw per-replication arrays dropped; histogram kept
    assert set(rows[0]["throughput_txn_per_cycle"]) == {"n", "mean", "half_width"}
    assert "per_replication" in rows[0]                      # not a stats dict: carried through untouched ...
    assert rows[0]["latency_histogram"] == {"3": 90, "4": 9, "5": 1}
    # rtl: verdicts kept, bulky per-case echoes dropped
    rtl = ds["rtl_verification"]
    assert rtl["cases"] == 3 and rtl["passed"] == 3 and len(rtl["results"]) == 3
    assert "rtl_effective_config" not in rtl["results"][0] and "first_divergence" not in rtl["mutation_check"][0]
    assert any("rtl_verification" in n for n in b["trim_notes"])
    # absent datasets are listed, never invented
    for k in ("tensor_study", "vector_study", "optimise", "ecc_study", "mbist_study", "power", "phys", "thermal", "timeline_trace", "synth", "experiments"):
        assert ds[k] is None and k in b["absent"]
    assert "tensor_study" in b["absent"] and "bank_sweep" not in b["absent"]


def test_empty_data_dir_is_tolerated(tmp_path):
    empty = tmp_path / "empty"
    empty.mkdir()
    b = extract(open(build(str(empty), tmp_path), encoding="utf-8").read())
    assert all(v is None for v in b["datasets"].values())
    assert set(D.DATASET_FILES) <= set(b["absent"])


def test_nonexistent_data_dir_is_tolerated(tmp_path):
    b = extract(open(build(str(tmp_path / "nope"), tmp_path), encoding="utf-8").read())
    assert b["datasets"]["bank_sweep"] is None


def test_malformed_json_is_reported_not_fatal(mini, tmp_path):
    write(mini, "optimise.json", "{ not json")
    write(mini, "tensor_study.json", "")
    b = extract(open(build(mini, tmp_path), encoding="utf-8").read())
    assert b["datasets"]["optimise"] is None and "optimise.json" in b["load_errors"]
    assert "tensor_study.json" in b["load_errors"]
    assert b["datasets"]["bank_sweep"] is not None


def test_nan_and_inf_become_null(mini, tmp_path):
    ts = {"label": "simulated", "gemm": {"M": 1, "N": 1, "K": 1}, "util_ideal_reference": float("nan"),
          "rows": [{"banks": 1, "max_out": 1, "word_bits": 32, "pitch": "natural", "dma_duty": 0.0, "mac_utilisation": 0.5,
                    "dma_overlap_fraction": float("nan"), "x": float("inf")}]}
    write(mini, "tensor_study.json", json.dumps(ts))          # json.dumps writes bare NaN / Infinity tokens (invalid JSON)
    html = open(build(mini, tmp_path), encoding="utf-8").read()
    assert not re.search(r"[:\[,]\s*(NaN|-?Infinity)\b", extract_raw(html))
    t = extract(html)["datasets"]["tensor_study"]
    assert t["rows"][0]["dma_overlap_fraction"] is None and t["rows"][0]["x"] is None and t["util_ideal_reference"] is None
    assert t["rows"][0]["mac_utilisation"] == 0.5


def extract_raw(html):
    return DATA_RE.search(html).group(1)


def test_precision_cap_keeps_values_close(mini):
    assert D.sanitize(0.123456789012345) == 0.123456789
    assert D.sanitize(float("-inf")) is None
    assert D.sanitize({1: (1, 2)}) == {"1": [1, 2]}
    assert math.isclose(D.sanitize(1 / 3), 0.333333333)


def test_untrusted_strings_cannot_break_out_of_the_script_element(mini, tmp_path):
    evil = '</script><img src=x onerror=alert(1)><!-- &  '
    write(mini, "vector_study.json", {"study": {"rows": [{"case": evil, "word_bits": 32, "vector_bits": 128, "banks": 4}], "note": evil}, "p76_crosscheck": None})
    html = open(build(mini, tmp_path), encoding="utf-8").read()
    assert html.count("</script>") == 2 and "<img src=x" not in html
    assert extract(html)["datasets"]["vector_study"]["study"]["note"] == evil


def test_machine_paths_are_stripped_from_synthesis_records(mini, tmp_path):
    sweep = {"mode": "generic", "label": "synthesized", "sweep": {}, "rows": [{"banks": 2, "perf": 0, "status": "ok", "cells": 10}],
             "results": [{"run_dir": "/home/secret/run", "exe": "/usr/bin/yosys"}]}
    write(mini, "synth/controller_sweep_generic.json", sweep)
    write(mini, "synth/subsystem_generic.json", {"top": "t", "run_dir": "/home/secret/run", "yosys": {"exe": "/usr/bin/yosys", "version": "0.7"}, "generic": {"total_cells": 5}})
    html = open(build(mini, tmp_path), encoding="utf-8").read()
    assert "/home/secret" not in html and "/usr/bin/yosys" not in html
    ds = extract(html)["datasets"]
    assert ds["synth"]["generic"]["rows"][0]["cells"] == 10 and "results" not in ds["synth"]["generic"]
    assert ds["synth_other"]["subsystem_generic"]["generic"]["total_cells"] == 5


def test_experiments_jsonl_and_records_merge(mini, tmp_path):
    runs = os.path.join(mini, "runs")
    os.makedirs(runs)
    with open(os.path.join(runs, "experiments.jsonl"), "w") as f:
        f.write(json.dumps({"experiment_id": "EXP-1", "created_utc": "2026-01-01T00:00:00+00:00", "command": "simulate", "config_hash": "ab", "result_hash": "cd", "git_revision": "deadbeef"}) + "\n")
        f.write("garbage line\n")
    write(runs, "EXP-1.json", {"experiment_id": "EXP-1", "config": {"name": "cfg_a"}, "git": {"revision": "deadbeef", "dirty": True}, "workload": {"kind": "mixed"}, "wall_seconds": 1.5})
    write(runs, "EXP-2.json", {"experiment_id": "EXP-2", "created_utc": "2026-01-02T00:00:00+00:00", "command": "benchmark", "config": {"name": "cfg_b"}, "git": {}})
    e = extract(open(build(mini, tmp_path), encoding="utf-8").read())["datasets"]["experiments"]
    by = {r["experiment_id"]: r for r in e["rows"]}
    assert set(by) == {"EXP-1", "EXP-2"} and e["unreadable_lines"] == 1
    assert by["EXP-1"]["name"] == "cfg_a" and by["EXP-1"]["git_dirty"] is True and by["EXP-1"]["workload_kind"] == "mixed"
    assert [r["experiment_id"] for r in e["rows"]] == ["EXP-1", "EXP-2"]          # oldest first; the page reverses it


def test_size_cap_raises_when_impossible(mini, tmp_path):
    with pytest.raises(D.DashboardTooLarge):
        build(mini, tmp_path, max_bytes=50_000)


def test_size_cap_trims_in_documented_order_and_records_it(mini, tmp_path):
    runs = os.path.join(mini, "runs")
    os.makedirs(runs)
    with open(os.path.join(runs, "experiments.jsonl"), "w") as f:
        for i in range(3000):
            f.write(json.dumps({"experiment_id": f"EXP-{i:05d}", "created_utc": f"2026-01-01T00:{i // 60 % 60:02d}:{i % 60:02d}+00:00", "command": "simulate",
                                "config_hash": "a" * 64, "result_hash": "b" * 64, "git_revision": "c" * 40, "name": "n" * 40}) + "\n")
    full = len(open(build(mini, tmp_path, "full.html", max_bytes=D.MAX_BYTES), encoding="utf-8").read().encode())
    assert full > 400_000
    b = extract(open(build(mini, tmp_path, "cut.html", max_bytes=full - 50_000), encoding="utf-8").read())
    assert len(b["datasets"]["experiments"]["rows"]) < 3000
    assert any("size guard" in n for n in b["trim_notes"])
    assert b["datasets"]["bank_sweep"] is not None                  # the headline data is trimmed last, never first


@pytest.mark.skipif(not os.path.isdir(REAL_DATA), reason="no committed data directory")
def test_real_data_builds_under_cap_and_reports_headline(tmp_path):
    out = D.build(REAL_DATA, str(tmp_path / "real.html"), probe_tools=False)
    size = os.path.getsize(out)
    assert size < 6_000_000
    b = extract(open(out, encoding="utf-8").read())
    rtl = b["datasets"]["rtl_verification"]
    if rtl:
        assert rtl["passed"] == rtl["cases"] == 253 and rtl["failed"] == 0
    # nothing in the embedded data is ever labelled measured
    assert '"provenance":"measured"' not in open(out, encoding="utf-8").read()


def test_tool_status_without_probe_uses_which_only():
    rows = D.tool_status(probe=False)
    assert {r["tool"] for r in rows} >= {"verilator", "yosys"} and all(isinstance(r["available"], bool) for r in rows)


def test_main_cli_writes_output(mini, tmp_path, capsys):
    out = str(tmp_path / "cli.html")
    assert D.main(["--data", mini, "--out", out, "--no-probe"]) == 0
    assert os.path.isfile(out) and "wrote" in capsys.readouterr().out
    assert D.main(["--data", mini, "--out", out, "--no-probe", "--max-bytes", "1000"]) == 1


def test_source_date_epoch_makes_output_reproducible(mini, tmp_path, monkeypatch):
    monkeypatch.setenv("SOURCE_DATE_EPOCH", "1700000000")
    a = open(build(mini, tmp_path, "a.html"), encoding="utf-8").read()
    b = open(build(mini, tmp_path, "b.html"), encoding="utf-8").read()
    assert a == b and "2023-11-14T22:13:20" in a


def test_assets_present_and_views_registered():
    for f in ("template.html", "dashboard.css"):
        assert os.path.isfile(os.path.join(D.DASH_DIR, f))
    js = "".join(open(p, encoding="utf-8").read() for p in sorted(__import__("glob").glob(os.path.join(D.DASH_DIR, "js", "*.js"))))
    assert sorted(int(n) for n in re.findall(r"SF\.registerView\((\d+),", js)) == list(range(1, 16))
    assert "MEASURED" in js and "none exists" in js


# ------------------------------------------------------------------------------------------ browser smoke test
def _node_playwright():
    node = shutil.which("node")
    if not node:
        return None
    try:
        r = subprocess.run([node, "-e", "require('playwright')"], capture_output=True, timeout=60)
    except Exception:
        return None
    return node if r.returncode == 0 else None


needs_browser = pytest.mark.skipif(_node_playwright() is None, reason="node + playwright not available")


def run_smoke(html, *extra):
    r = subprocess.run([_node_playwright(), SMOKE, html, "--quick", *extra], capture_output=True, text=True, timeout=280)
    assert r.returncode == 0, r.stderr[-3000:] or r.stdout[-3000:]
    return json.loads(r.stdout.strip().splitlines()[-1])


@needs_browser
def test_smoke_empty_data_every_view_explains_itself(tmp_path):
    empty = tmp_path / "e"
    empty.mkdir()
    rep = run_smoke(build(str(empty), tmp_path))
    assert rep["console"] == [] and rep["failures"] == []
    v = rep["views"]["1440x900"]
    assert len(v) == 15 and v["14"]["unavail"] >= 1 and v["3"]["unavail"] >= 1


@needs_browser
def test_smoke_partial_and_unavailable_data(mini, tmp_path):
    bs = mini_bank_sweep()
    for r in bs["max_out_1"]["rows"]:                        # older generator output: no read/write split, no histograms
        for k in ("read_bytes_per_cycle", "write_bytes_per_cycle", "latency_histogram", "conflict_cycle_fraction_per_bank"):
            r.pop(k)
    write(mini, "bank_sweep.json", bs)
    write(mini, "tensor_study.json", {"rows": [{"banks": 1, "max_out": 1, "word_bits": 32, "pitch": "natural", "dma_duty": 0.0, "mac_utilisation": None, "memory_limited": None, "dma_overlap_fraction": None}]})
    write(mini, "optimise.json", "{ broken")
    write(mini, "ecc_study.json", {"label": "analytical"})
    write(mini, "mbist_study.json", {"foo": [1, 2, 3]})
    write(mini, "power.json", {"activity": {"cycles": {"value": None, "provenance": "unavailable", "reason": "no run"}}})
    write(mini, "timeline_trace.json", {"masters": 2, "banks": 2, "cycles": []})
    rep = run_smoke(build(mini, tmp_path))
    assert rep["console"] == [] and rep["failures"] == []


@needs_browser
@pytest.mark.skipif(not os.path.isdir(REAL_DATA), reason="no committed data directory")
def test_smoke_real_data_with_interactions_and_phone_layout(tmp_path):
    out = D.build(REAL_DATA, str(tmp_path / "real.html"), probe_tools=False)
    r = subprocess.run([_node_playwright(), SMOKE, out], capture_output=True, text=True, timeout=290)       # both viewports + interactions
    assert r.returncode == 0, r.stderr[-3000:] or r.stdout[-3000:]
    rep = json.loads(r.stdout.strip().splitlines()[-1])
    assert rep["console"] == [] and rep["failures"] == []
    assert set(rep["views"]) == {"1440x900", "390x844"}
    assert all(i["ok"] for i in rep["interactions"])
    assert all(s["firstRenderMs"] < 1000 for s in rep["sizes"])
