import math, numpy as np, pytest
from sramlab.config import load_config, controller_params
from sramlab.sim.workloads import generate_scripts
from sramlab import stats, metrics, optimise
from sramlab.sim.streams import split_access
from sramlab.sim.controller import CtlParams
from sramlab.prng import SplitMix64

KINDS = ["seq_read", "seq_write", "rand_read", "rand_write", "mixed", "hotspot", "strided", "vector_load", "dma_burst", "contention"]

@pytest.mark.parametrize("kind", KINDS)
def test_workload_deterministic_and_legal(kind):
    cfg = load_config({"workload": {"kind": kind, "requests_per_master": 200, "seed": 9}})
    p = controller_params(cfg)
    a, b = generate_scripts(p, cfg["workload"]), generate_scripts(p, cfg["workload"])
    key = lambda sc: [[(r.we, r.addr, r.wdata, r.wstrb, r.delay) for r in m] for m in sc]
    assert key(a) == key(b)
    for m in a:
        assert len(m) == 200
        for r in m:
            assert 0 <= r.addr < p.total_bytes and r.addr % p.nbyte == 0
            assert (r.we == 0) or r.wstrb != 0

def test_seed_changes_stream():
    c1 = load_config({"workload": {"kind": "rand_read", "seed": 1}}); c2 = load_config({"workload": {"kind": "rand_read", "seed": 2}})
    p = controller_params(c1)
    assert [r.addr for r in generate_scripts(p, c1["workload"])[0]] != [r.addr for r in generate_scripts(p, c2["workload"])[0]]

def test_master_streams_independent():
    c4 = load_config({"controller": {"masters": 4}, "workload": {"kind": "rand_read", "seed": 3}})
    c5 = load_config({"controller": {"masters": 5}, "workload": {"kind": "rand_read", "seed": 3}})
    a = generate_scripts(controller_params(c4), c4["workload"]); b = generate_scripts(controller_params(c5), c5["workload"])
    assert [r.addr for r in a[2]] == [r.addr for r in b[2]]       # adding a master does not perturb master 2

def test_pattern_semantics():
    cfg = load_config({"workload": {"kind": "strided", "stride_words": 4, "requests_per_master": 50}})
    p = controller_params(cfg); s = generate_scripts(p, cfg["workload"])[1]
    assert [(s[i+1].addr - s[i].addr) // 4 for i in range(10)] == [4] * 10
    cfg = load_config({"workload": {"kind": "contention", "requests_per_master": 50}})
    p = controller_params(cfg)
    assert {(r.addr // 4) % p.num_banks for m in generate_scripts(p, cfg["workload"]) for r in m} == {0}

def test_split_access_alignment_arithmetic():
    p = CtlParams(num_banks=4, data_width=32)
    rq, useful = split_access(p, 0, 16, 0, SplitMix64(1), 6)
    assert len(rq) == 4 and useful == 16
    rq, useful = split_access(p, 1, 16, 0, SplitMix64(1), 6)     # 1-byte offset: 5 words, still 16 useful bytes
    assert len(rq) == 5 and useful == 16
    rq, _ = split_access(p, 0, 16, 1, SplitMix64(1), 7, byte_mask=0xFFF0)   # lowest word fully masked -> not accessed
    assert len(rq) == 3 and all(r.wstrb == 0xF for r in rq)

# ------------------------------------------------------------------ statistics (hand-computed values)
def test_t_critical_values():
    assert stats.t_crit(9) == pytest.approx(2.262, abs=1e-3)
    assert stats.t_crit(100) == pytest.approx(1.984, abs=0.003)

def test_mean_ci_hand_computed():
    d = stats.mean_ci([1, 2, 3, 4, 5])            # mean 3, s = sqrt(2.5), t(4)=2.776
    assert d["mean"] == 3 and d["std"] == pytest.approx(math.sqrt(2.5))
    assert d["half_width"] == pytest.approx(2.776 * math.sqrt(2.5) / math.sqrt(5), rel=1e-6)

def test_ci_covers_true_mean_at_nominal_rate():
    rng = SplitMix64(7); hits = 0; trials = 400
    for _ in range(trials):
        xs = [rng.random() for _ in range(10)]    # true mean 0.5
        d = stats.mean_ci(xs); hits += d["lo"] <= 0.5 <= d["hi"]
    assert 0.91 < hits / trials < 0.985

def test_required_replications_monotone():
    assert stats.required_replications(1.0, 0.5) > stats.required_replications(1.0, 1.0) > stats.required_replications(1.0, 2.0)

def test_percentiles_and_spearman():
    a = np.arange(1, 101)
    d = metrics.dist(a)
    assert d["median"] == 50.5 and d["p95"] == pytest.approx(95.05) and d["p99"] == pytest.approx(99.01)
    assert stats.spearman([1, 2, 3, 4], [10, 20, 30, 40]) == pytest.approx(1.0)
    assert stats.spearman([1, 2, 3, 4], [4, 3, 2, 1]) == pytest.approx(-1.0)

def test_elasticity():
    assert stats.elasticity(1, 2, 4, 8) == pytest.approx(1.0)

def test_pareto_dominance():
    pts = [(1, 5), (2, 4), (3, 3), (2, 6), (4, 4)]
    assert sorted(optimise.pareto_front(pts)) == [0, 1, 2]

def test_analytical_ceilings_formulae():
    p = CtlParams(num_masters=4, num_banks=4, max_out=4, bank_lats=[4] * 4)
    c = metrics.analytical_ceilings(p)
    assert c["master_ceiling_txn_per_cycle"] == pytest.approx(0.8)          # MAX_OUT/(L+1) = 4/5
    assert c["peak_txn_per_cycle"] == pytest.approx(3.2)
    p1 = CtlParams(num_masters=4, num_banks=4, max_out=1)
    assert metrics.analytical_ceilings(p1)["peak_txn_per_cycle"] == pytest.approx(2.0)
    assert metrics.analytical_ceilings(p1)["random_access_estimate_txn_per_cycle"] == pytest.approx(min(2.0, 4 * (1 - 0.75 ** 4)))
