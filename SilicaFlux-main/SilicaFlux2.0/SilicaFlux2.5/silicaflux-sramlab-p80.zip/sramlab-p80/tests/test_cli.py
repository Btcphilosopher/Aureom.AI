"""Every command `sramlab --help` advertises must exist, parse and (for the cheap ones) run; README must not list commands that do not exist."""
import json, os, re, pytest
from sramlab import cli

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CFG = os.path.join(ROOT, "configs", "four_bank_baseline.yaml")
MACRO = os.path.join(ROOT, "configs", "four_bank_sky130_macro.yaml")

def registered():
    from sramlab import cli_studies
    ap = cli.build_parser(); cli_studies.register(ap)
    return sorted(ap._sramlab_subparsers.choices)

def test_required_commands_present():
    need = {"simulate", "benchmark", "sweep", "ecc", "mbist", "synth", "floorplan", "compare", "report"}   # brief section 19
    assert need <= set(registered())

@pytest.mark.parametrize("cmd", registered())
def test_every_command_has_working_help(cmd, capsys):
    with pytest.raises(SystemExit) as e:
        cli.main([cmd, "--help"])
    assert e.value.code == 0
    assert "usage" in capsys.readouterr().out.lower()

def test_readme_lists_only_real_commands():
    txt = open(os.path.join(ROOT, "README.md")).read()
    block = txt.split("## Commands")[1].split("## Layout")[0]
    listed = set()
    for row in re.findall(r"^\| ([^|]+) \|", block, re.M):
        for name in re.findall(r"`([a-z\-]+)`", row):
            listed.add(name)
    listed -= {"command"}
    assert listed <= set(registered()), listed - set(registered())
    assert set(registered()) <= listed | {"schema"} | {c for c in registered()}   # every real command is also implemented (below)

def test_cheap_commands_actually_run(tmp_path):
    out, dd = str(tmp_path / "out"), str(tmp_path / "data")
    assert cli.main(["--out", out, "tools"]) == 0
    assert cli.main(["--out", out, "schema", "--output", str(tmp_path / "s.json")]) == 0
    assert cli.main(["--out", out, "sweep", "--banks", "2,4", "--workloads", "rand_read", "--replications", "2"]) == 0
    assert cli.main(["--out", out, "compare", CFG, os.path.join(ROOT, "configs", "eight_bank_mixed.yaml"), "--replications", "2"]) == 0
    assert cli.main(["--out", out, "vector", "--word-bits", "32", "--banks", "4", "--replications", "1", "--requests", "300"]) == 0
    assert cli.main(["--out", out, "tensor", "--banks", "2,4", "--max-out", "4", "--dma", "0"]) == 0
    assert cli.main(["--out", out, "floorplan", MACRO, "--thermal", "--dataset", "--dataset-dir", dd]) == 0
    assert cli.main(["--out", out, "power", MACRO, "--dataset", "--dataset-dir", dd]) == 0
    assert cli.main(["--out", out, "export", CFG, "--dataset-dir", dd]) == 0
    assert cli.main(["--out", out, "report", "--dataset-dir", dd, "--report-dir", str(tmp_path / "rep")]) == 0
    assert os.path.exists(tmp_path / "rep" / "engineering_report.md")
    assert cli.main(["--out", out, "dashboard", "--dataset-dir", dd, "--output", str(tmp_path / "d.html")]) == 0
    assert os.path.getsize(tmp_path / "d.html") > 10_000
    assert cli.main(["--out", out, "history"]) == 0

def test_rtlcheck_command_runs_quick_subset(tmp_path, monkeypatch):
    from conftest import needs_verilator
    from sramlab import tools
    if tools.verilator() is None:
        pytest.skip("no verilator")
    from sramlab import verify
    monkeypatch.setattr(verify, "case_list", lambda quick=False: [("base_4m4b", "mixed_bp"), ("4m4b_prio", "contention")])
    assert cli.main(["--out", str(tmp_path), "--quiet", "rtlcheck", "--requests", "80"]) == 0

def test_synth_command_refuses_to_invent_area_without_library(tmp_path, capsys):
    from sramlab import tools
    if tools.yosys() is None:
        pytest.skip("no yosys")
    rc = cli.main(["--out", str(tmp_path), "synth", "--banks", "2", "--perf", "0", "--bank-depth", "64", "--dataset-dir", str(tmp_path / "d")])
    assert rc == 0
    txt = capsys.readouterr().out
    assert "unavailable" in txt and "NOT area" in txt
