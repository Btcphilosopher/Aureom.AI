# SilicaFlux SRAMLab (Project 80)

Aureom.AI | SilicaFlux Semiconductor Systems — SRAM architecture benchmarking and digital-twin environment.

An engineer can select an SRAM architecture (banks, word width, latency, masters, outstanding transactions, arbitration, interleave, ECC, MBIST, backend, technology profile),
run a real supported workload, compare configurations, and obtain **reproducible results with every number labelled by where it came from**:
`analytical` · `simulated` · `rtl_simulated` · `synthesized` · `assumed` · `unavailable` — and never `measured`, because no SilicaFlux silicon/FPGA measurement exists.

> Start with `reports/engineering_report.md` (generated from `data/`), then `docs/00_audit.md` and `docs/03_verification.md`.

## Quick start

```bash
pip install numpy pandas pyyaml pytest verilator yowasp-yosys     # verilator/yosys are optional but needed for rtlcheck/ecc/mbist/synth
cd tools/sramlab
./bin/sramlab tools                                    # which tools are available (versions are recorded in every record)
./bin/sramlab validate configs/*.yaml
./bin/sramlab simulate configs/four_bank_baseline.yaml --rtl-check --export   # model run + cycle-by-cycle comparison with the real RTL
./bin/sramlab benchmark configs/four_bank_baseline.yaml --replications 10     # mean ± 95% CI
./bin/sramlab sweep --banks 2,4,8,16                                          # bank-count sweep at constant capacity
./bin/sramlab compare configs/four_bank_baseline.yaml configs/eight_bank_mixed.yaml
python3 -m pytest tests -q
```

## What was built (and in which order, as the brief asked)

1. **Four-bank simulation and RTL comparison first.** `sramlab/sim/controller.py` is a cycle-accurate model of the real `sf_sram_subsystem`
   (SRAMController P73 + SRAMCore P71, vendored byte-identical under `rtl/third_party/`). `sramlab rtlcheck` replays identical master scripts in the model and in
   Verilator and compares every cycle and all hardware counters: **253/253 cases identical** (23 parameter sets × 11 workloads, 2–16 banks, error injection, flush, priority
   arbitration), plus a negative control that detects 4/4 deliberately broken models. See `docs/03_verification.md`.
2. Workload generators (11 kinds, deterministic seeds), metrics with analytical ceilings kept separate from simulation, replication statistics (t-CI, bootstrap, sample-size).
3. Bank-count comparison (2/4/8/16) at constant capacity — more banks do **not** always help (computed findings in the report).
4. Vector and tensor memory studies (tensor: does memory bandwidth limit TensorCore throughput? vector: alignment overhead; cross-checked against RTL-simulation data, 76/76 rows exact).
5. ECC (SECDED) cost analysis and MBIST evaluation with real RTL runs (`docs/ecc.md`, `docs/mbist.md`).
6. Synthesis (Yosys generic gates; mapped logic area with a real open library where available), macro-tiling area from real vendor manifests, power-provenance framework, ThermalLab hand-off
   (`docs/synthesis.md`, `physical.md`, `power.md`, `thermal.md`).
7. Multi-goal optimisation with a Pareto frontier and **no single universal optimum**; reproducibility records; the 15-view dashboard.

## Commands

| command | what it does |
|---|---|
| `validate`, `schema`, `tools` | validate configs (all problems at once); write the JSON schema; show tool availability |
| `simulate` | one run; `--rtl-check` compares with the RTL; `--export` writes per-transaction and counter CSVs |
| `benchmark` | replicated run with 95 % CIs and a sample-adequacy statement |
| `sweep` | bank-count sweep at constant capacity |
| `compare` | two configurations, statistically |
| `vector`, `tensor` | the vector and tensor studies |
| `ecc`, `mbist` | ECC cost and MBIST evaluation (RTL) |
| `synth`, `floorplan`, `power` | Yosys flows, area/floorplan, power provenance + thermal hand-off |
| `optimise` | goals A–E, Pareto set |
| `rtlcheck` | model-vs-RTL verification matrix + negative control |
| `report`, `dashboard`, `export` | engineering report + CSVs, browser dashboard, raw data export |
| `history`, `verify-repro` | experiment history; re-run and demand identical result hashes |

Every command listed here is implemented and exercised by `tests/test_cli.py`.

## Documentation

| doc | content |
|---|---|
| `reports/engineering_report.md` | generated engineering report (every table/finding computed from `data/`) |
| `docs/00_audit.md` | repository audit: what exists, what was reused, what was found |
| `docs/01_architecture.md`, `02_methodology.md` | layers, metrics definitions, ceilings vs simulation, statistics |
| `docs/03_verification.md` | model-vs-RTL verification, negative controls, bugs found by it |
| `docs/04_tensor_vector_studies.md` | tensor/vector method, optimisation rules |
| `docs/ecc.md`, `mbist.md` | ECC cost analysis and MBIST evaluation (RTL runs, sibling-report disagreements) |
| `docs/synthesis.md`, `physical.md`, `power.md`, `thermal.md` | Yosys flows, technology/macro data, power provenance, ThermalLab hand-off |
| `docs/dashboard.md` | the 15-view dashboard and its provenance rules |
| `docs/05_limitations.md` | what is not claimed |

## Reproduce everything

```bash
python3 -m pytest tests -q                     # 297 tests (cold caches: a few minutes; Verilator/Yosys builds are cached under .build/ and .cache/)
python3 scripts/generate_data.py               # bank sweeps, timeline, vector, tensor, full 253-case RTL matrix
./bin/sramlab ecc && ./bin/sramlab mbist       # RTL studies (~5 min each cold)
./bin/sramlab synth --banks 2,4,8,16 --perf 0,1                    # generic gates
./bin/sramlab synth --banks 2,4,8,16 --perf 0,1 --liberty nangate45 --fetch   # + mapped logic area (downloads the pinned open Nangate45 liberty; not bundled)
./bin/sramlab floorplan configs/four_bank_sky130_macro.yaml --thermal --dataset
./bin/sramlab power configs/four_bank_sky130_macro.yaml --dataset
./bin/sramlab optimise --dataset
./bin/sramlab rtlcheck --dataset              # full 253-case model-vs-RTL matrix (~2 min)
./bin/sramlab report --dashboard               # reports/engineering_report.md, CSV exports, dashboard/sramlab_dashboard.html
```

## Layout

`sramlab/` package · `rtl/` (testbenches + vendored RTL with SHA-256 manifests) · `configs/` · `schemas/` · `data/` (committed datasets, imported reference data with provenance, macro manifests) ·
`reports/` (engineering report, CSV exports) · `dashboard/` · `docs/` · `tests/` · `scripts/` (data generation, packaging) · `bin/sramlab`.

## Honest scope

See `docs/05_limitations.md`. In short: results are cycles of the implemented protocol, not seconds; there is no energy-per-access or die-area data for the SilicaFlux target process anywhere in the repository,
so those are reported `unavailable` unless a validated profile / real library is supplied; OpenROAD/OpenSTA are not available here, so no timing-closure or P&R result is claimed; MBIST coverage is coverage of an injected simulation fault model only.
