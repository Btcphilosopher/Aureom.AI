"""Reproducibility records.

Every experiment produces one JSON record with (brief section 18): experiment ID, git revision,
simulator/tool versions, hardware (host) configuration, random seed, workload, clock assumptions,
technology library, test results, performance counters, timing results and power provenance.

Two hashes are stored:
  config_hash  - sha256 of the normalised configuration
  result_hash  - sha256 of the *deterministic* result payload (everything except timestamps/host/wall time);
                 re-running the same config + seed must reproduce it bit-for-bit (``sramlab verify-repro``).
Records are appended to ``<out>/experiments.jsonl`` (experiment history) and written individually.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
import time

from . import tools
from .config import config_hash

SCHEMA = "sramlab/record/1"


def _canon(x) -> str:
    return json.dumps(x, sort_keys=True, default=_json_default, separators=(",", ":"))


def _json_default(o):
    try:
        import numpy as np
        if isinstance(o, (np.integer,)):
            return int(o)
        if isinstance(o, (np.floating,)):
            return float(o)
        if isinstance(o, np.ndarray):
            return o.tolist()
    except Exception:
        pass
    if isinstance(o, set):
        return sorted(o)
    return str(o)


def result_hash(payload) -> str:
    return hashlib.sha256(_canon(payload).encode()).hexdigest()


def make_record(command: str, cfg: dict, results: dict, *, counters=None, verification=None, timing=None,
                power=None, tech=None, extra=None, wall_seconds: float | None = None) -> dict:
    now = datetime.datetime.now(datetime.timezone.utc)
    ch = config_hash(cfg) if cfg else "none"
    rec = {
        "schema": SCHEMA,
        "experiment_id": f"EXP-{now.strftime('%Y%m%d-%H%M%S')}-{ch[:8]}",
        "created_utc": now.isoformat(timespec="seconds"),
        "command": command,
        "config": {k: v for k, v in (cfg or {}).items() if not k.startswith("_")},
        "config_hash": ch,
        "git": tools.git_info(),
        "environment": tools.environment(),
        "seed": (cfg or {}).get("workload", {}).get("seed"),
        "workload": (cfg or {}).get("workload"),
        "clock_assumptions": {
            "clock_mhz": (cfg or {}).get("physical", {}).get("clock_mhz"),
            "provenance": "assumed" if (cfg or {}).get("physical", {}).get("clock_mhz") else "unavailable",
            "note": "results are reported in cycles; MB/s appear only when a clock is assumed and are then labelled so",
        },
        "technology": tech or {"profile": (cfg or {}).get("physical", {}).get("technology", "none"),
                               "library": None, "note": "no technology library: area/energy not available"},
        "results": results,
        "performance_counters": counters,
        "verification": verification,
        "timing_results": timing or {"status": "unavailable", "reason": "no STA tool/library; OpenSTA/OpenROAD not installed"},
        "power_provenance": power or {"status": "unavailable", "reason": "no validated energy profile loaded"},
        "wall_seconds": wall_seconds,
    }
    rec["result_hash"] = result_hash(results)
    if extra:
        rec.update(extra)
    return rec


def save(rec: dict, outdir: str) -> str:
    os.makedirs(outdir, exist_ok=True)
    path = os.path.join(outdir, rec["experiment_id"] + ".json")
    with open(path, "w") as f:
        json.dump(rec, f, indent=1, default=_json_default)
    with open(os.path.join(outdir, "experiments.jsonl"), "a") as f:
        slim = {k: rec[k] for k in ("experiment_id", "created_utc", "command", "config_hash", "result_hash", "seed")}
        slim["name"] = rec["config"].get("name") if rec.get("config") else None
        slim["git_revision"] = rec["git"].get("revision")
        slim["headline"] = rec.get("headline")
        f.write(json.dumps(slim, default=_json_default) + "\n")
    return path


def load_history(outdir: str) -> list[dict]:
    p = os.path.join(outdir, "experiments.jsonl")
    if not os.path.exists(p):
        return []
    with open(p) as f:
        return [json.loads(l) for l in f if l.strip()]


# ---------------------------------------------------------------- raw data export
def export_run(rr, outdir: str, stem: str):
    """Write per-transaction CSV, counters CSV and the latency histogram for a RunResult."""
    import csv
    os.makedirs(outdir, exist_ok=True)
    tx = rr.tx
    with open(os.path.join(outdir, stem + "_transactions.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["master", "index", "we", "addr", "bank", "tag", "present_cycle", "accept_cycle", "response_cycle",
                    "transfer_cycle", "status", "rdata_hex", "wdata_hex", "wstrb"])
        for i in range(len(tx)):
            w.writerow([tx.master[i], tx.index[i], tx.we[i], tx.addr[i], tx.bank[i], tx.tag[i], tx.present[i],
                        tx.accept[i], tx.push[i] + 1 if tx.push[i] >= 0 else -1, tx.xfer[i], tx.status[i],
                        f"{tx.rdata[i]:x}", f"{tx.wdata[i]:x}", f"{tx.wstrb[i]:x}"])
    with open(os.path.join(outdir, stem + "_counters.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["scope", "index", "counter", "value"])
        pd = rr.perf_dict
        for k, v in pd["global"].items():
            w.writerow(["global", "", k, v])
        for m, d in enumerate(pd["master"]):
            for k, v in d.items():
                w.writerow(["master", m, k, v])
        for b, d in enumerate(pd["bank"]):
            for k, v in d.items():
                w.writerow(["bank", b, k, v])
    return [stem + "_transactions.csv", stem + "_counters.csv"]
