"""SRAMLab: SilicaFlux SRAM architecture benchmarking and digital twin (Project 80)."""
__version__ = "0.1.0"
