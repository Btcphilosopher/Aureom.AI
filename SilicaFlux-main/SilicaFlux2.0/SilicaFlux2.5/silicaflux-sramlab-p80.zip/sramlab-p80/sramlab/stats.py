"""Statistical analysis: replication, confidence intervals, sample-size planning, sensitivity.

Design rules
* Latency samples inside ONE run are autocorrelated (queues), so confidence intervals are computed
  across independent replications (different seeds), never across the transactions of one run.
* Student-t intervals on replicate means; percentiles get a bootstrap interval across replications
  (seeded, so the report is reproducible).
* ``required_replications`` tells how many replications a target half-width needs; reports state the
  achieved half-width so a reader can see whether the sample was adequate.
No scipy dependency: the t quantile uses an exact table up to 30 d.o.f. and the normal limit beyond.
"""
from __future__ import annotations

import math

import numpy as np

from .prng import SplitMix64

# two-sided 95% / 99% t critical values, df = 1..30
_T95 = [12.706, 4.303, 3.182, 2.776, 2.571, 2.447, 2.365, 2.306, 2.262, 2.228, 2.201, 2.179, 2.160, 2.145,
        2.131, 2.120, 2.110, 2.101, 2.093, 2.086, 2.080, 2.074, 2.069, 2.064, 2.060, 2.056, 2.052, 2.048, 2.045, 2.042]
_T99 = [63.657, 9.925, 5.841, 4.604, 4.032, 3.707, 3.499, 3.355, 3.250, 3.169, 3.106, 3.055, 3.012, 2.977,
        2.947, 2.921, 2.898, 2.878, 2.861, 2.845, 2.831, 2.819, 2.807, 2.797, 2.787, 2.779, 2.771, 2.763, 2.756, 2.750]


def t_crit(df: int, conf: float = 0.95) -> float:
    if df < 1:
        return float("nan")
    tab = {0.95: _T95, 0.99: _T99}[conf]
    if df <= 30:
        return tab[df - 1]
    z = {0.95: 1.960, 0.99: 2.576}[conf]
    return z * (1 + (z * z + 1) / (4 * df))      # Cornish-Fisher style correction, <0.1% error for df > 30


def mean_ci(x, conf: float = 0.95) -> dict:
    a = np.asarray(x, dtype=float)
    n = len(a)
    if n == 0:
        return {"n": 0}
    m = float(a.mean())
    if n == 1:
        return {"n": 1, "mean": m, "half_width": float("nan"), "lo": float("nan"), "hi": float("nan"), "conf": conf}
    s = float(a.std(ddof=1))
    hw = t_crit(n - 1, conf) * s / math.sqrt(n)
    return {"n": n, "mean": m, "std": s, "half_width": hw, "lo": m - hw, "hi": m + hw, "conf": conf,
            "relative_half_width": hw / abs(m) if m else float("nan")}


def required_replications(std: float, target_half_width: float, conf: float = 0.95) -> int:
    """Smallest n with t(n-1) * std / sqrt(n) <= target (iterates because t depends on n)."""
    if target_half_width <= 0 or std == 0:
        return 2
    n = 2
    while n < 100000:
        if t_crit(n - 1, conf) * std / math.sqrt(n) <= target_half_width:
            return n
        n += 1
    return n


def bootstrap_ci(x, stat, conf: float = 0.95, iters: int = 1000, seed: int = 1) -> dict:
    a = np.asarray(x, dtype=float)
    n = len(a)
    if n < 2:
        return {"n": n}
    rng = SplitMix64(seed)
    vals = []
    for _ in range(iters):
        idx = [rng.randbelow(n) for _ in range(n)]
        vals.append(stat(a[idx]))
    lo, hi = np.percentile(vals, [(1 - conf) / 2 * 100, (1 + conf) / 2 * 100])
    return {"n": n, "estimate": float(stat(a)), "lo": float(lo), "hi": float(hi), "conf": conf, "method": "bootstrap"}


def replicate(run_fn, seeds, extract: dict[str, callable]) -> dict:
    """Run ``run_fn(seed)`` for every seed and summarise each extractor over the replications."""
    rows = [run_fn(s) for s in seeds]
    out = {"n_replications": len(rows), "seeds": list(seeds), "metrics": {}}
    for name, fn in extract.items():
        vals = [fn(r) for r in rows]
        out["metrics"][name] = {**mean_ci(vals), "values": vals}
    return out


def pooled_percentile_ci(samples_per_rep: list, q: float, conf: float = 0.95) -> dict:
    """Percentile q of each replication's latency sample, then a t interval across replications."""
    per_rep = [float(np.percentile(s, q)) for s in samples_per_rep if len(s)]
    d = mean_ci(per_rep, conf)
    d["percentile"] = q
    return d


# --------------------------------------------------------------------------- sensitivity
def spearman(x, y) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    if len(x) < 3 or np.std(x) == 0 or np.std(y) == 0:
        return float("nan")
    rx = _rank(x)
    ry = _rank(y)
    return float(np.corrcoef(rx, ry)[0, 1])


def _rank(a: np.ndarray) -> np.ndarray:
    order = a.argsort(kind="mergesort")
    ranks = np.empty(len(a))
    ranks[order] = np.arange(len(a))
    # average ranks for ties
    for v in np.unique(a):
        idx = np.nonzero(a == v)[0]
        if len(idx) > 1:
            ranks[idx] = ranks[idx].mean()
    return ranks


def elasticity(x0: float, y0: float, x1: float, y1: float) -> float:
    """Arc elasticity d ln(y) / d ln(x) between two points (dimensionless sensitivity)."""
    if x0 <= 0 or x1 <= 0 or y0 <= 0 or y1 <= 0 or x0 == x1:
        return float("nan")
    return (math.log(y1) - math.log(y0)) / (math.log(x1) - math.log(x0))


def coefficient_of_variation(x) -> float:
    a = np.asarray(x, float)
    return float(a.std(ddof=1) / a.mean()) if len(a) > 1 and a.mean() else float("nan")
