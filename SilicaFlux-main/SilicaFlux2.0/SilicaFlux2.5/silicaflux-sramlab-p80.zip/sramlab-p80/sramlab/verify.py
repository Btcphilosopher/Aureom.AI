"""Simulator-versus-RTL verification matrix.

``rtl_matrix()`` returns the list of (parameters, workload, options) cases; ``run_matrix()``
builds the Verilator testbench per distinct parameter set, runs the model and the RTL on identical
scripts and demands a cycle-by-cycle identical trace plus identical hardware counters.

``mutation_check()`` is the negative control: it re-runs a case against deliberately broken
models and demands that the comparison FAILS.  A comparator that cannot fail proves nothing.
"""
from __future__ import annotations

import concurrent.futures as cf
import copy
import json
import os
import time

from .prng import SplitMix64
from .sim.controller import CtlParams
from .sim.driver import ReadyMasks, ReqSpec
from .sim.workloads import generate_scripts
from . import rtlrun


def _P(nm, nb, dw=32, bd=64, mo=1, lats=None, ilv="low", prio=0, hpm=1, hpl=4, uni=-1, mask="any", idw=4,
       idchk=1, bank_out=0):
    return CtlParams(num_masters=nm, num_banks=nb, data_width=dw, bank_depth=bd, id_width=idw, max_out=mo,
                     bank_out=bank_out, interleave=ilv, id_check=idchk, mask_mode=mask, prio_en=prio,
                     hp_mask=hpm, hp_limit=hpl, bank_lats=lats or [1] * nb, uniform_lat=uni)


def param_sets() -> dict[str, CtlParams]:
    return {
        "base_4m4b": _P(4, 4),
        "2m2b": _P(2, 2),
        "4m8b_mo2": _P(4, 8, mo=2),
        "4m16b_mo4": _P(4, 16, mo=4),
        "8m4b": _P(8, 4),
        "1m4b_mo4": _P(1, 4, mo=4),
        "4m4b_mo4_lat1234": _P(4, 4, mo=4, lats=[1, 2, 3, 4]),
        "4m4b_mo4_lat2": _P(4, 4, mo=4, lats=[2] * 4),
        "4m4b_mo8_lat4": _P(4, 4, mo=8, lats=[4] * 4),
        "4m4b_dw64": _P(4, 4, dw=64),
        "3m4b_dw128_mo2": _P(3, 4, dw=128, bd=32, mo=2),
        "4m4b_high": _P(4, 4, ilv="high"),
        "4m4b_depth100_mo2": _P(4, 4, bd=100, mo=2),
        "4m4b_prio": _P(4, 4, prio=1, hpm=1, hpl=4),
        "6m4b_prio_mo2": _P(6, 4, mo=2, prio=1, hpm=0b000101, hpl=2),
        "16m16b": _P(16, 16, bd=32),
        "4m4b_dw16": _P(4, 4, dw=16),
        "4m1b_dw8_mo2": _P(4, 1, dw=8, mo=2),
        "2m2b_maskaligned": _P(2, 2, mask="aligned"),
        "4m4b_lat2_forcelock": _P(4, 4, mo=4, lats=[2] * 4, uni=0),
        "4m4b_idw1_mo4": _P(4, 4, mo=4, idw=1),
        "4m4b_bankout1": _P(4, 4, mo=4, bank_out=1),
        "4m2b_lat3_mo4_bout2": _P(4, 2, mo=4, lats=[3, 3], bank_out=2),
    }


WORKLOADS = [
    ("rand_read", {"kind": "rand_read"}),
    ("mixed", {"kind": "mixed", "write_fraction": 0.5}),
    ("seq_write", {"kind": "seq_write"}),
    ("contention", {"kind": "contention", "write_fraction": 0.3}),
    ("hotspot", {"kind": "hotspot", "hotspot_words": 8, "write_fraction": 0.4}),
    ("strided", {"kind": "strided", "stride_words": 4, "write_fraction": 0.2}),
    ("mixed_bp", {"kind": "mixed", "write_fraction": 0.5, "response_ready_rate": 0.5, "request_rate": 0.6}),
    ("dma", {"kind": "dma_burst", "burst_words": 8}),
    ("vector", {"kind": "vector_load", "vector_bits": 128, "misalign_bytes": 4, "store_fraction": 0.3,
                "partial_store": True}),
]


def inject_illegal(p: CtlParams, scripts, seed: int, fraction: float = 0.08):
    """Corrupt a seeded fraction of requests: misaligned, out-of-range, zero-strobe write, poison."""
    rng = SplitMix64(seed ^ 0xBADBAD)
    out = copy.deepcopy(scripts)
    kinds = []
    for s in out:
        for r in s:
            if rng.random() < fraction:
                k = rng.randbelow(4)
                if k == 0:
                    r.addr += 1 + rng.randbelow(p.nbyte - 1) if p.nbyte > 1 else 0   # misaligned
                elif k == 1:
                    r.addr = p.total_bytes + rng.randbelow(64) * p.nbyte           # out of range
                elif k == 2:
                    r.we, r.wstrb, r.wdata = 1, 0, 0                                # zero-strobe write
                else:
                    r.err = 1                                                       # poison
                kinds.append(k)
    return out, len(kinds)


def case_list(quick: bool = False):
    sets = param_sets()
    cases = []
    for pname, p in sets.items():
        for wname, wl in WORKLOADS:
            if quick and (wname not in ("rand_read", "mixed_bp", "contention") or pname.startswith("16m")):
                continue
            cases.append((pname, wname))
        cases.append((pname, "illegal_mix"))
        cases.append((pname, "flush_mix"))
    return cases


def build_case(pname: str, wname: str, n_req: int, seed: int):
    p = param_sets()[pname]
    base = {"requests_per_master": n_req, "seed": seed, "request_rate": 1.0, "response_ready_rate": 1.0,
            "write_fraction": 0.5, "hotspot_fraction": 0.8, "hotspot_words": 16, "stride_words": 4,
            "burst_words": 16, "master_mix": None}
    flush = ()
    inject = False
    if wname == "illegal_mix":
        wl = {**base, "kind": "mixed", "response_ready_rate": 0.7}
        inject = True
    elif wname == "flush_mix":
        wl = {**base, "kind": "mixed", "response_ready_rate": 0.8, "request_rate": 0.8}
        flush = (23, 24, 25, 120, 121, 300)
    else:
        wl = {**base, **dict(WORKLOADS)[wname]}
    scripts = generate_scripts(p, wl)
    if inject:
        scripts, _ = inject_illegal(p, scripts, seed)
    ready = ReadyMasks(p.num_masters, float(wl.get("response_ready_rate", 1.0)), seed)
    return p, scripts, ready, flush


def _run_case(args):
    pname, wname, n_req, seed = args
    p, scripts, ready, flush = build_case(pname, wname, n_req, seed)
    t0 = time.time()
    try:
        v = rtlrun.compare(p, scripts, ready, label=f"{pname}/{wname}", ncycles=None if not flush else None,
                           flush_cycles=flush)
    except Exception as e:  # build failure etc.
        v = {"label": f"{pname}/{wname}", "ok": False, "error": str(e)[-600:]}
    v["params"], v["workload"], v["seed"] = pname, wname, seed
    v["wall_s"] = round(time.time() - t0, 1)
    return v


def run_matrix(quick: bool = False, n_req: int = 300, seed: int = 11, jobs: int | None = None,
               progress=None) -> dict:
    cases = case_list(quick)
    jobs = jobs or max(1, min(3, (os.cpu_count() or 2) - 1))
    # build each distinct parameter set once, sequentially, so concurrent workers only run binaries
    for pname in dict.fromkeys(c[0] for c in cases):
        if progress:
            progress(f"building RTL testbench for {pname}")
        rtlrun.build(param_sets()[pname])
    results = []
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = {ex.submit(_run_case, (pn, wn, n_req, seed)): (pn, wn) for pn, wn in cases}
        for i, f in enumerate(cf.as_completed(futs)):
            results.append(f.result())
            if progress and (i + 1) % 20 == 0:
                progress(f"{i + 1}/{len(cases)} cases")
    results.sort(key=lambda r: r["label"])
    ok = sum(1 for r in results if r.get("ok"))
    return {
        "cases": len(results), "passed": ok, "failed": len(results) - ok,
        "cycles_compared": sum(r.get("cycles_compared", 0) for r in results),
        "transactions": sum(r.get("transactions", 0) for r in results),
        "counters_compared": sum(r.get("counters_compared", 0) for r in results),
        "parameter_sets": len(set(r["params"] for r in results)),
        "results": results,
    }


# ----------------------------------------------------------------------------- negative control
def _mut_arbiter_lowest(ctl_mod):
    orig = ctl_mod._Arb.pick

    def pick(self, req_mask):
        # broken: fixed priority instead of round robin
        if req_mask:
            for i in range(self.n):
                if req_mask >> i & 1:
                    return i, False, req_mask
        return -1, False, req_mask
    return orig, pick


def mutation_check(n_req: int = 200, seed: int = 5) -> list[dict]:
    """Break the model in four ways; the RTL comparison must flag every one of them."""
    from .sim import controller as C
    res = []
    p, scripts, ready, _ = build_case("4m4b_mo4_lat1234", "mixed", n_req, seed)
    p2, scripts2, ready2, _ = build_case("base_4m4b", "contention", n_req, seed)

    def run(label, patch_fn, restore_fn, pp, ss, rr):
        patch_fn()
        try:
            v = rtlrun.compare(pp, ss, rr, label=label)
        finally:
            restore_fn()
        res.append({"mutation": label, "detected": not v["ok"], "first_divergence": v["first_trace_divergence"],
                    "counter_diffs": len(v["counter_mismatches"])})

    # 1. arbiter: fixed priority instead of round robin
    orig, mut = _mut_arbiter_lowest(C)
    run("arbiter_fixed_priority", lambda: setattr(C._Arb, "pick", mut), lambda: setattr(C._Arb, "pick", orig),
        p2, scripts2, ready2)
    # 2. bank-lock rule dropped
    orig_step = C.Controller.step

    def step_nolock(self, reqs, rsp_ready, src_en=None, flush=False):
        old = self.p.uniform_lat
        self.p.uniform_lat = 1
        try:
            return orig_step(self, reqs, rsp_ready, src_en, flush)
        finally:
            self.p.uniform_lat = old
    run("bank_lock_dropped", lambda: setattr(C.Controller, "step", step_nolock),
        lambda: setattr(C.Controller, "step", orig_step), p, scripts, ready)
    # 3. response latency off by one
    orig_lat = C.CtlParams.__dict__["bank_out_eff"]

    def make_late():
        orig_init = C.Controller.__init__

        def init(self, pp, track_data=True, perf=True):
            orig_init(self, pp, track_data, perf)
            self.p = CtlParams(**{**pp.__dict__, "bank_lats": [x + 1 for x in pp.bank_lats]})
        C.Controller.__init__ = init
        return orig_init
    holder = {}
    run("read_latency_plus_one", lambda: holder.setdefault("o", make_late()),
        lambda: setattr(C.Controller, "__init__", holder["o"]), p2, scripts2, ready2)
    # 4. conflict counter off (counts winners as losers)
    orig_perf = C.Controller._perf_update

    def perf_bad(self, *a, **k):
        orig_perf(self, *a, **k)
        self.pg[C.PG_CONFLICT] += 1
    run("conflict_counter_wrong", lambda: setattr(C.Controller, "_perf_update", perf_bad),
        lambda: setattr(C.Controller, "_perf_update", orig_perf), p2, scripts2, ready2)
    return res
