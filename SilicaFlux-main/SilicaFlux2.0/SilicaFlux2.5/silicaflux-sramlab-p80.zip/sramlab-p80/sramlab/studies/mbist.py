"""MBIST evaluation (brief section 11): the SilicaFlux MemoryTest (P78) MBIST controller, run on its real RTL.

What is measured / produced, with its provenance label (``sramlab.provenance``):

  rtl_simulated  Verilator runs of ``sf_sram_mbist`` (+ the P78 verification-only fault-injection memory group
                 ``sf_mbist_sram_sys``): total test cycles, per-phase cycles, test-mode access overhead, the failure
                 registers, and per-fault detection of an enumerated fault population
  simulated      this module's INDEPENDENT Python March simulator (written from the March definitions and the P78
                 fault-model definitions, not from the RTL); cross-checked fault by fault against the RTL
  analytical     operation-count models (10N / 5N, exact overhead model, parallel-bank model)
  unavailable    anything that could not be produced

NOTHING here is ``measured`` (no silicon exists).

**Coverage statement (applies to every coverage number in this module):**
``coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect coverage``.
A March test run on a behavioural fault model says how well the algorithm detects THAT enumerated model population
(stuck-at, transition, address-decoder, coupling faults of a tiny instance); it says nothing about manufacturing or
physical defect coverage, DPPM, retention / read-disturb / bit-line / resistive / at-speed faults (not modelled).

What the RTL does with several banks: ``sf_mbist_fsm`` tests the selected banks ONE AFTER ANOTHER in ascending index
(``tst_sel`` is one-hot; ``BSEL -> PINIT -> RUN -> DRAIN -> BEND`` per bank, one shared ownership acquisition and one
shared re-initialisation per run).  There is no parallel-bank mode in the RTL; the parallel numbers below are an
ANALYTICAL model and are not RTL-verified.

Entry point: :func:`run_mbist_study`.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
import time
from collections import namedtuple
from concurrent.futures import ThreadPoolExecutor

from .. import tools
from ..provenance import tag, unavailable
from . import ecc as _ecc
from .ecc import build_tb, run_sim, parse_lines, verilator_info, _parallel, write_outputs, _guard, _walk_unavailable

ROOT = tools.ROOT
RTL_DIR = os.path.join(ROOT, "rtl")
P78 = os.path.join(RTL_DIR, "third_party", "p78_memorytest")
MC = os.path.join(RTL_DIR, "third_party", "memorycore_sram")
TB_RUN = os.path.join(RTL_DIR, "tb", "tb_sramlab_mbist_run.sv")

COVERAGE_STATEMENT = "coverage of the injected fault model in simulation; this is NOT manufacturing/physical defect coverage"

P78_RTL = [os.path.join(P78, "rtl", f) for f in (
    "sf_mbist_pattern.sv", "sf_mbist_addr_seq.sv", "sf_mbist_arbiter.sv", "sf_mbist_failreg.sv", "sf_mbist_fsm.sv",
    "sf_mbist_ras_if.sv", "sf_mbist_repair.sv", "sf_mbist_regs.sv", "sf_sram_mbist.sv")]
P78_MODELS = [os.path.join(P78, "verif", "models", f) for f in ("sf_mbist_fault_mem.sv", "sf_mbist_sram_sys.sv")]
RUN_SRCS = P78_RTL + P78_MODELS + [TB_RUN]
RUN_INCS = [os.path.join(P78, "rtl")]

# P78 encodings (rtl/sf_mbist_defs.svh)
ALG_MARCH_CM, ALG_MATS_P = 0, 1
PAT_ALL0, PAT_CHECKER, PAT_STRIPE = 0, 3, 5
SEL_SEQ, SEL_ALL = 1, 2
RES_NAMES = {0: "NONE", 1: "PASS", 2: "FAIL", 3: "ABORTED", 4: "ERROR", 5: "REFUSED"}
CLS_NAMES = {0: "NONE", 1: "1TO0_BIT (SA0 or up-TF)", 2: "0TO1_BIT (SA1 or down-TF)", 3: "MULTI_1TO0", 4: "MULTI_0TO1",
             5: "MULTI_MIX", 6: "ALL_BITS", 7: "ADDR_ALIAS"}
ALGO_NAMES = {ALG_MARCH_CM: "March C-", ALG_MATS_P: "MATS+"}
ALGO_OPS_PER_WORD = {ALG_MARCH_CM: 10, ALG_MATS_P: 5}       # analytical operation counts (10N / 5N)

# fault types (same numbers as MemoryCore SF_FT_*)
SAF, TF, AF_NA, AF_ALI, AF_MUL, CFIN, CFID, CFST = 1, 2, 3, 4, 5, 6, 7, 8
Fault = namedtuple("Fault", "t row bit row2 bit2 v v2")
NO_FAULT = None


# ----------------------------------------------------------------------------------------------------------
# Independent Python March simulator + P78 fault-model semantics (docs/04_fault_models.md)
# ----------------------------------------------------------------------------------------------------------
class FaultyMem:
    """ROWS x W behavioural memory with at most one injected fault, semantics of P78 docs/04 section 1.

    write(r): address-decoder mapping, then per target row: TF vs old/new value, SAF forces its bit, store, then every
    coupling fault whose aggressor transitions in this row acts on its victim (a same-word victim overrides the
    just-written value).  read(r): stored row through the AF mapping, SAF, CFST view, AF_MUL wired OR / AND."""

    __slots__ = ("rows", "w", "mem", "f", "mask")

    def __init__(self, rows: int, w: int, fault: Fault | None, init: int = 0):
        self.rows, self.w, self.f = rows, w, fault
        self.mask = (1 << w) - 1
        self.mem = [init] * rows

    def _saf_view(self, r: int, v: int) -> int:
        f = self.f
        if f is not None and f.t == SAF and f.row == r:
            v = (v | (1 << f.bit)) if f.v else (v & ~(1 << f.bit))
        return v

    def _write_row(self, t: int, wd: int):
        f, mem = self.f, self.mem
        old = mem[t]
        new = wd
        if f is not None:
            if f.t == TF and f.row == t:
                b = 1 << f.bit
                if f.v and not (old & b) and (new & b):
                    new &= ~b                               # 0 -> 1 blocked
                if not f.v and (old & b) and not (new & b):
                    new |= b                                # 1 -> 0 blocked
            if f.t == SAF and f.row == t:
                new = (new | (1 << f.bit)) if f.v else (new & ~(1 << f.bit))
        mem[t] = new
        if f is not None and f.t in (CFIN, CFID) and f.row == t:
            a = 1 << f.bit
            if (old & a) != (new & a) and (1 if (new & a) else 0) == f.v:
                vv = mem[f.row2]
                if f.t == CFIN:
                    vv ^= 1 << f.bit2
                else:
                    vv = (vv | (1 << f.bit2)) if f.v2 else (vv & ~(1 << f.bit2))
                mem[f.row2] = vv

    def write(self, addr: int, wd: int):
        f = self.f
        if f is not None and f.row == addr:
            if f.t == AF_NA:
                return
            if f.t == AF_ALI:
                self._write_row(f.row2, wd)
                return
            if f.t == AF_MUL:
                self._write_row(addr, wd)
                self._write_row(f.row2, wd)
                return
        self._write_row(addr, wd)

    def read(self, addr: int) -> int:
        f, mem = self.f, self.mem
        tgt, mul = addr, False
        if f is not None and f.row == addr:
            if f.t == AF_NA:
                return 0
            if f.t == AF_ALI:
                tgt = f.row2
            elif f.t == AF_MUL:
                mul = True
        v = self._saf_view(tgt, mem[tgt])
        if f is not None and f.t == CFST and f.row2 == tgt:
            if (self._saf_view(f.row, mem[f.row]) >> f.bit) & 1 == f.v:
                v = (v | (1 << f.bit2)) if f.v2 else (v & ~(1 << f.bit2))
        if mul:
            v2 = self._saf_view(f.row2, mem[f.row2])
            v = (v & v2) if f.v else (v | v2)
        return v


def background(pattern: int, k: int, w: int, row: int) -> int:
    """B(row): all-0, checkerboard (i[0] ^ row[0]) or column stripe ((i >> k) & 1), bit i of the W-bit word."""
    if pattern == PAT_ALL0:
        return 0
    if pattern == PAT_CHECKER:
        b = 0
        for i in range(w):
            if (i & 1) ^ (row & 1):
                b |= 1 << i
        return b
    if pattern == PAT_STRIPE:
        b = 0
        for i in range(w):
            if (i >> k) & 1:
                b |= 1 << i
        return b
    raise ValueError(f"pattern {pattern} not implemented in the Python simulator")


# (descending?, ops) per element; op = (is_read, polarity)   -- "B" (any order) elements run ascending, as in the RTL
MARCH_ELEMENTS = {
    ALG_MARCH_CM: [(False, [(0, 0)]), (False, [(1, 0), (0, 1)]), (False, [(1, 1), (0, 0)]),
                   (True, [(1, 0), (0, 1)]), (True, [(1, 1), (0, 0)]), (False, [(1, 0)])],
    ALG_MATS_P: [(False, [(0, 0)]), (False, [(1, 0), (0, 1)]), (True, [(1, 1), (0, 0)])],
}


def ops_per_word(algo: int) -> int:
    """Operations per address implied by the element table (10 for March C-, 5 for MATS+)."""
    return sum(len(ops) for _, ops in MARCH_ELEMENTS[algo])


def stripe_passes(w: int) -> int:
    """Background passes of the 'sweep' option: ALL0 plus STRIPE k = 0 .. KMAX-1 with KMAX = $clog2(W)."""
    return 1 + max(1, (w - 1).bit_length())


def run_march(rows: int, w: int, algo: int, pattern: int, sweep: bool, fault: Fault | None, window: tuple | None = None) -> dict:
    """One MBIST run of a single bank on a (possibly faulty) memory that starts all-zero (the state the re-initialisation
    leaves).  Returns the first-failure record (lowest failing bit, element, op, polarity, pass, expected, observed) and the
    number of failing reads, exactly the quantities the RTL failure registers hold."""
    lo, hi = window if window else (0, rows - 1)
    mem = FaultyMem(rows, w, fault)
    mask = (1 << w) - 1
    elems = MARCH_ELEMENTS[algo]
    npass = stripe_passes(w) if sweep else 1
    count = 0
    first = None
    ops = 0
    for ps in range(npass):
        if sweep:
            pat, k = (PAT_ALL0, 0) if ps == 0 else (PAT_STRIPE, ps - 1)
        else:
            pat, k = pattern, 0
        bg = [background(pat, k, w, r) for r in range(rows)]
        for ei, (down, eops) in enumerate(elems):
            addrs = range(hi, lo - 1, -1) if down else range(lo, hi + 1)
            for a in addrs:
                for oi, (is_rd, pol) in enumerate(eops):
                    exp = bg[a] ^ (mask if pol else 0)
                    ops += 1
                    if is_rd:
                        obs = mem.read(a)
                        if obs != exp:
                            count += 1
                            if first is None:
                                syn = (exp ^ obs) & mask
                                first = {"row": a, "bit": (syn & -syn).bit_length() - 1, "bit_v": int(syn & (syn - 1) == 0),
                                         "elem": ei, "op": oi, "pol": pol, "pass": ps, "exp": exp, "obs": obs}
                    else:
                        mem.write(a, exp)
    return {"det": first is not None, "count": count, "first": first, "ops": ops}


# configurations of the P78 coverage campaign (reports/coverage.md): (name, runs[(algo, pattern, sweep)])
CONFIGS = [
    ("C0 March C-, solid", [(ALG_MARCH_CM, PAT_ALL0, False)]),
    ("C1 March C-, checkerboard", [(ALG_MARCH_CM, PAT_CHECKER, False)]),
    ("C2 March C-, solid U checkerboard (2 runs)", [(ALG_MARCH_CM, PAT_ALL0, False), (ALG_MARCH_CM, PAT_CHECKER, False)]),
    ("C3 March C-, background sweep (solid + stripes)", [(ALG_MARCH_CM, PAT_ALL0, True)]),
    ("C4 MATS+, solid", [(ALG_MATS_P, PAT_ALL0, False)]),
    # added here (not in P78's table) to reproduce MemoryCore's committed MATS+ figures, which are for the solid / checkerboard UNION
    ("C5 MATS+, checkerboard", [(ALG_MATS_P, PAT_CHECKER, False)]),
    ("C6 MATS+, solid U checkerboard (2 runs)", [(ALG_MATS_P, PAT_ALL0, False), (ALG_MATS_P, PAT_CHECKER, False)]),
]
CFG_NAMES = [c[0] for c in CONFIGS]

# the coupling sub-variants (type, aggressor/trigger value v, forced value v2), P78 tb_mbist_cov.sv
COUPLING_VARIANTS = [
    ("CFin_up", CFIN, 1, 0), ("CFin_down", CFIN, 0, 0), ("CFid_up_f0", CFID, 1, 0), ("CFid_up_f1", CFID, 1, 1),
    ("CFid_down_f0", CFID, 0, 0), ("CFid_down_f1", CFID, 0, 1), ("CFst_a0_v0", CFST, 0, 0), ("CFst_a0_v1", CFST, 0, 1),
    ("CFst_a1_v0", CFST, 1, 0), ("CFst_a1_v1", CFST, 1, 1),
]
WEAK_SAME_WORD = ("CFid_up_f1", "CFid_down_f0", "CFst_a0_v0", "CFst_a1_v1")


def fault_population(rows: int, w: int, stride: int = 1) -> list:
    """Enumerated fault population of P78 (docs/04, reports/coverage.md): (class, scope, Fault) in the order of
    ``tb_mbist_cov.sv``.  Coupling pairs: every ``stride``-th ordered pair of distinct cells (stride 1 = exhaustive)."""
    pop = []
    for r in range(rows):
        for b in range(w):
            pop.append(("SAF0", "cell", Fault(SAF, r, b, 0, 0, 0, 0)))
            pop.append(("SAF1", "cell", Fault(SAF, r, b, 0, 0, 1, 0)))
            pop.append(("TF_up", "cell", Fault(TF, r, b, 0, 0, 1, 0)))
            pop.append(("TF_down", "cell", Fault(TF, r, b, 0, 0, 0, 0)))
    for r in range(rows):
        pop.append(("AF_none", "row", Fault(AF_NA, r, 0, 0, 0, 0, 0)))
        for r2 in range(rows):
            if r2 != r:
                pop.append(("AF_alias", "row pair", Fault(AF_ALI, r, 0, r2, 0, 0, 0)))
                pop.append(("AF_multi_OR", "row pair", Fault(AF_MUL, r, 0, r2, 0, 0, 0)))
                pop.append(("AF_multi_AND", "row pair", Fault(AF_MUL, r, 0, r2, 0, 1, 0)))
    pairn = 0
    for r in range(rows):
        for b in range(w):
            for r2 in range(rows):
                for b2 in range(w):
                    if r == r2 and b == b2:
                        continue
                    pairn += 1
                    if pairn % stride:
                        continue
                    sc = "intra-word pair" if r == r2 else "inter-word pair"
                    for nm, t, a, f in COUPLING_VARIANTS:
                        pop.append((nm, sc, Fault(t, r, b, r2, b2, a, f)))
    return pop


def simulate_population(rows: int, w: int, pop: list, configs=CONFIGS) -> list:
    """Per fault and configuration: detection + first-failure record from the Python simulator.  A configuration is the
    UNION of its runs (a fault counts as detected if any run detects it; the first detecting run's record is kept)."""
    out = []
    for cls, scope, f in pop:
        per_cfg = []
        for _, runs in configs:
            rec = None
            for algo, pat, sw in runs:
                r = run_march(rows, w, algo, pat, sw, f)
                if r["det"]:
                    rec = r
                    break
            per_cfg.append(rec)
        out.append(per_cfg)
    return out


def tally(pop: list, sim: list, ncfg: int = len(CONFIGS)) -> dict:
    """(class, scope) -> {total, detected[cfg], located[cfg]}.  'located' = single-cell faults whose first failure names the
    faulty row and bit exactly (cell faults only)."""
    t = {}
    for (cls, scope, f), per in zip(pop, sim):
        e = t.setdefault((cls, scope), {"total": 0, "detected": [0] * ncfg, "located": [0] * ncfg})
        e["total"] += 1
        for c, rec in enumerate(per):
            if rec is not None:
                e["detected"][c] += 1
                fr = rec["first"]
                if scope == "cell" and fr["row"] == f.row and fr["bit"] == f.bit and fr["bit_v"]:
                    e["located"][c] += 1
    return t


# ----------------------------------------------------------------------------------------------------------
# RTL runs
# ----------------------------------------------------------------------------------------------------------
def run_exe(nbank: int, rows: int, w: int, rl: int = 1, nf: int = 2, jobs: int = 2) -> str:
    gen = {"NBANK": nbank, "ROWS": rows, "W": w, "RL": rl, "NF": nf}
    return build_tb("mbist_run", "tb_sramlab_mbist_run", RUN_SRCS, gen, RUN_INCS, jobs)


def run_script(nbank, rows, w, rl, nf, lines: list, extra_args=(), jobs=2, timeout=1800) -> list:
    exe = run_exe(nbank, rows, w, rl, nf, jobs)
    wd = tempfile.mkdtemp(prefix="sramlab_mbist_")
    sf = os.path.join(wd, "s.txt")
    with open(sf, "w") as f:
        f.write("\n".join(lines) + "\n")
    out = run_sim(exe, [f"+script={sf}"] + list(extra_args), timeout=timeout)
    shutil.rmtree(wd, ignore_errors=True)
    rows_ = parse_lines(out)
    if "ERROR" in out or not any(r["_tag"] == "DONE" for r in rows_):
        raise RuntimeError("MBIST testbench error:\n" + out[-1500:])
    return rows_


def cmd_run(tg, algo=ALG_MARCH_CM, pat=PAT_ALL0, sweep=0, sel=SEL_ALL, bank=0, bmask=0, lo=0, hi=0, traffic=0, stop=0, reinit=1,
            kk=0, col=0) -> str:
    return "2 " + " ".join(str(int(x)) for x in (tg, algo, pat, sweep, sel, bank, bmask, lo, hi, traffic, stop, reinit, kk, col))


def cmd_fault(bank, slot, f: Fault) -> str:
    return "1 " + " ".join(str(int(x)) for x in (bank, slot, f.t, f.row, f.bit, f.row2, f.bit2, f.v, f.v2))


def group_runs(rows_: list) -> dict:
    """RUN/PH/TL/FUNC lines -> {tag: merged dict}"""
    g = {}
    for r in rows_:
        if r["_tag"] in ("RUN", "PH", "TL", "FUNC") and "tag" in r:
            d = g.setdefault(r["tag"], {})
            for k, v in r.items():
                if k not in ("_tag", "tag"):
                    d[k] = v
            d.setdefault("_tags", []).append(r["_tag"])
    return g


def _hx(v) -> int:
    return int(str(v), 16)


# ---------------------------------------------------------------------------------------------------- cycle model
def refined_cycle_model(nbanks: int, window: int, rows: int, lt: int, algo: int, acq: int, rel_fixed: int, passes: int = 1) -> int:
    """Exact cycle model of a fault-free run, derived from sf_mbist_fsm / sf_mbist_arbiter and validated on every RTL run:

        cycles = B * (1 + P * (K*N + LT + 2))  +  ACQ  +  (ROWS + REL_FIXED)  +  3

    K = ops per address (10 March C-, 5 MATS+), N = window rows, LT = READ_LATENCY + TEST_PIPE, P = background passes (1; the
    'sweep' option runs 1 + ceil(log2 W) passes).  Per bank: BSEL (1) once, then per pass PINIT (1) + RUN (K*N) + DRAIN (LT) +
    BEND (1) -- so for P = 1 this is K*N + LT + 3.  Per run: CHECK (1) + ACQ (arbiter quiesce -> drain -> confirm) + REL (release +
    re-initialisation, ROWS + REL_FIXED because the init engine rewrites every row) + FIN (1) + the cycle in which ``done`` is first
    seen (1).  ``acq`` and ``rel_fixed`` are MEASURED constants (phase histogram of one calibration run), not fitted to the run being
    predicted."""
    return nbanks * (1 + passes * (ALGO_OPS_PER_WORD[algo] * window + lt + 2)) + acq + (rows + rel_fixed) + 3


def cycle_section(banks, bank_depth: int, word_bits: int, quick=False, jobs=2, workers=3) -> dict:
    nmax = max(banks)
    rl = 1
    windows = [bank_depth // 8, bank_depth // 4, bank_depth // 2, bank_depth] if not quick else [bank_depth // 4, bank_depth]
    windows = sorted({max(2, x) for x in windows})
    lines, meta = ["0"], {}
    tg = 0
    for algo in (ALG_MARCH_CM, ALG_MATS_P):
        for nb in sorted(set(banks) | {1}):
            for n in windows:
                tg += 1
                meta[tg] = (algo, nb, n)
                lines.append(cmd_run(tg, algo=algo, sel=SEL_SEQ, bmask=(1 << nb) - 1, lo=0, hi=n - 1))
    # background-sweep runs: P = 1 + ceil(log2 W) passes over each bank (per-pass overhead PINIT + DRAIN + BEND)
    sweep_meta = {}
    for nb in sorted({1, min(banks)}):
        tg += 1
        sweep_meta[tg] = (ALG_MARCH_CM, nb, windows[0])
        lines.append(cmd_run(tg, ALG_MARCH_CM, sweep=1, sel=SEL_SEQ, bmask=(1 << nb) - 1, lo=0, hi=windows[0] - 1))
    rows_ = run_script(nmax, bank_depth, word_bits, rl, 1, lines, jobs=jobs)
    g = group_runs(rows_)
    src = "sf_sram_mbist + sf_mbist_sram_sys via rtl/tb/tb_sramlab_mbist_run.sv (Verilator)"
    runs = []
    for t, (algo, nb, n) in list(meta.items()) + list(sweep_meta.items()):
        d = g[t]
        runs.append({"algo": algo, "banks": nb, "window": n, "sweep": t in sweep_meta, "passes": stripe_passes(word_bits) if t in sweep_meta else 1,
                     "cycles": d["cycles"], "result": d["result"], "tested": _hx(d["tested"]),
                     "run_cycles": d["f5"], "bsel": d["f3"], "pinit": d["f4"], "drain": d["f6"], "bend": d["f7"], "check": d["f1"],
                     "acq": d["f2"], "rel": d["f8"], "fin": d["f9"], "idle_done": d["f0"], "max_sel_w": d["max_sel_w"],
                     "order": _hx(d["order"]), "order_n": d["order_n"], "phase_sum": sum(d[f"f{i}"] for i in range(10))})
    # calibration constants from the smallest run (measured phase histogram), then validated on all
    cal = min([r for r in runs if not r["sweep"]], key=lambda r: (r["banks"], r["window"]))
    acq, rel_fixed = cal["acq"], cal["rel"] - bank_depth
    for r in runs:
        r["ops_only_model"] = ALGO_OPS_PER_WORD[r["algo"]] * r["window"] * r["banks"] * r["passes"]
        r["ops_only_model_error_pct"] = round(100.0 * (r["cycles"] - r["ops_only_model"]) / r["cycles"], 3)
        r["refined_model"] = refined_cycle_model(r["banks"], r["window"], bank_depth, rl, r["algo"], acq, rel_fixed, r["passes"])
        r["refined_model_error_cycles"] = r["cycles"] - r["refined_model"]
    # per-bank time: slope of cycles vs number of banks at fixed window (least squares over the measured bank counts)
    slopes = {}
    for algo in (ALG_MARCH_CM, ALG_MATS_P):
        for n in windows:
            pts = sorted([(r["banks"], r["cycles"]) for r in runs if r["algo"] == algo and r["window"] == n and not r["sweep"]])
            if len(pts) >= 2:
                (b0, c0), (b1, c1) = pts[0], pts[-1]
                slopes[(algo, n)] = (c1 - c0) / (b1 - b0), c0 - (c1 - c0) / (b1 - b0) * b0
    # ROWS dependence of the re-init term and READ_LATENCY dependence of the per-bank constant: extra small builds
    scal = []
    # P78 docs/01 section 6 quotes 194 cycles for one 16-row bank (March C-, READ_LATENCY 1): re-measure that exact shape
    ln = ["0", cmd_run(1, ALG_MARCH_CM, sel=SEL_SEQ, bmask=1, lo=0, hi=15)]
    p1 = group_runs(run_script(1, 16, word_bits, 1, 1, ln, jobs=jobs))[1]
    p78_chk = {"shape": "1 bank x 16 rows, March C-, READ_LATENCY 1", "p78_documented_cycles": 194, "cycles_start_to_done_flag": p1["cycles"],
               "busy_cycles_p78_convention": p1["cycles"] - p1["f0"],
               "explanation": "P78 counts busy cycles (engine state != IDLE); this study counts start-pulse to the cycle `done` is first seen, "
                              "which includes that one final IDLE sample",
               "matches_p78": (p1["cycles"] - p1["f0"]) == 194}
    if not quick:
        for (nbk, rws, lat) in ((4, 64, 1), (4, 128, 1), (4, 64, 2), (4, 1024, 1)):     # the last: P78 docs/01 sec. 6 quotes ~42,000 (arithmetic, not measured)
            ln = ["0", cmd_run(1, ALG_MARCH_CM, sel=SEL_SEQ, bmask=(1 << nbk) - 1, lo=0, hi=rws - 1)]
            rr = run_script(nbk, rws, word_bits, lat, 1, ln, jobs=jobs)
            d = group_runs(rr)[1]
            scal.append({"banks": nbk, "rows": rws, "read_latency": lat, "cycles": d["cycles"], "rel": d["f8"], "drain": d["f6"],
                         "model": refined_cycle_model(nbk, rws, rws, lat, ALG_MARCH_CM, acq, rel_fixed)})
    return {"runs": runs, "calibration": {"acq_cycles": acq, "rel_fixed_cycles": rel_fixed, "source_run": {k: cal[k] for k in ("banks", "window", "algo")}},
            "per_bank_slopes": {f"{ALGO_NAMES[a]}_N{n}": {"cycles_per_added_bank": s, "fixed_cycles": i} for (a, n), (s, i) in slopes.items()},
            "scaling_runs": scal, "p78_cross_check": p78_chk, "source": src, "read_latency": rl, "bank_depth": bank_depth, "word_bits": word_bits}


def order_list(order_val: int, n: int) -> list:
    return [(order_val >> (4 * i)) & 0xF for i in range(n)]


def parallel_model(banks, window: int, rows: int, lt: int, algo: int, acq: int, rel_fixed: int) -> dict:
    """ANALYTICAL parallel-bank test-time model (the RTL does NOT implement parallel testing; not RTL-verified).
    sequential = shared + sum over banks of per-bank time; parallel = shared + max over banks of per-bank time, where the
    shared term (ownership acquisition, re-initialisation, CHECK/FIN) is paid once in both cases.  Identical banks."""
    per_bank = ALGO_OPS_PER_WORD[algo] * window + lt + 3
    shared = acq + (rows + rel_fixed) + 3
    out = {}
    for b in banks:
        seq, par = shared + b * per_bank, shared + per_bank
        out[f"B{b}"] = {"sequential_cycles": tag(seq, "analytical", "shared + B x per-bank (equals the RTL cycle count, validated)"),
                        "parallel_cycles": tag(par, "analytical", "shared + max over banks of per-bank time; NOT implemented in the RTL, NOT RTL-verified"),
                        "speedup": tag(round(seq / par, 3), "analytical", "sequential / parallel"),
                        "peak_simultaneously_tested_banks": b}
    return {"algo": ALGO_NAMES[algo], "per_bank_cycles": per_bank, "shared_cycles": shared, "by_banks": out,
            "assumptions": "identical banks, one test port + comparator per bank, no peak-power or test-bus-width limit modelled "
                           "(the RTL tests banks one at a time precisely to bound peak test power)"}


# ---------------------------------------------------------------------------------------------------- test-mode overhead
def overhead_section(banks, bank_depth: int, word_bits: int, quick=False, jobs=2) -> dict:
    nmax = max(banks)
    nbs = [1, banks[0]] if quick else sorted({1, min(banks), max(banks)})
    lines = ["0", "5 400"]
    meta = {}
    tg = 0
    for nb in nbs:
        for tr in (0, 1):
            tg += 1
            meta[tg] = (nb, tr)
            lines.append(cmd_run(tg, ALG_MARCH_CM, sel=SEL_SEQ, bmask=(1 << nb) - 1, lo=0, hi=bank_depth - 1, traffic=tr))
    rr = run_script(nmax, bank_depth, word_bits, 1, 1, lines, jobs=jobs)
    g = group_runs(rr)
    traf = [r for r in rr if r["_tag"] == "TRAF"][0]
    r0 = traf["accepted"] / traf["cycles"]
    # ownership-acquisition latency with traffic in flight varies with the traffic phase: repeat the same short run
    nrep = 6 if quick else 16
    vl = ["0"] + [cmd_run(100 + i, ALG_MARCH_CM, sel=SEL_SEQ, bmask=1, lo=0, hi=15, traffic=1) for i in range(nrep)] + \
         [cmd_run(200, ALG_MARCH_CM, sel=SEL_SEQ, bmask=1, lo=0, hi=15, traffic=0)]
    vr = group_runs(run_script(nmax, bank_depth, word_bits, 1, 1, vl, jobs=jobs))
    acq_tr = [vr[100 + i]["t_tact_rise"] - vr[100 + i]["t_qrise"] for i in range(nrep)]
    acq_0 = vr[200]["t_tact_rise"] - vr[200]["t_qrise"]
    src = "sf_mbist_arbiter / sf_mbist_fsm via rtl/tb/tb_sramlab_mbist_run.sv with the P78 memory-group model (Verilator)"
    rows_ = []
    for t, (nb, tr) in meta.items():
        d = g[t]
        rows_.append({
            "banks_tested": nb, "functional_traffic": bool(tr), "total_test_cycles": tag(d["cycles"], "rtl_simulated", src),
            "phase_cycles": {
                "check_start_to_quiesce_request": tag(d["t_qrise"] - d["t_start"], "rtl_simulated", src),
                "quiesce_to_acknowledge": tag(d["t_qack"] - d["t_qrise"], "rtl_simulated", src),
                "acknowledge_to_ownership_drain_and_confirm": tag(d["t_tact_rise"] - d["t_qack"], "rtl_simulated", src),
                "test_ownership_tst_active": tag(d["t_tact_fall"] - d["t_tact_rise"], "rtl_simulated", src),
                "release_to_reinit_busy": tag(d["t_ibusy_rise"] - d["t_tact_fall"], "rtl_simulated", src),
                "reinitialisation": tag(d["t_ibusy_fall"] - d["t_ibusy_rise"], "rtl_simulated", src),
                "reinit_done_to_quiesce_release": tag(d["t_qfall"] - d["t_ibusy_fall"], "rtl_simulated", src)},
            "arbiter_state_cycles": {"QUIESCE": d["a1"], "DRAIN": d["a2"], "OWN1": d["a3"], "OWNED": d["a4"], "REL0": d["a5"],
                                     "REINIT": d["a6"], "REINIT_WAIT": d["a7"], "FAULT": d["a8"]},
            "engine_run_cycles_test_operations": tag(d["f5"], "rtl_simulated", src),
            "access_protocol_overhead_cycles": tag(d["cycles"] - d["f5"], "rtl_simulated", src,
                                                   note="all cycles of the run that are not March operations (ACQ, per-bank BSEL/PINIT/DRAIN/BEND, REL incl. re-init, CHECK/FIN)"),
            "functional_unavailable_window_cycles": tag(d["t_rdy_rise"] - d["t_rdy_fall"], "rtl_simulated", src,
                                                        note="cycles in which a functional master is refused (quiesce .. re-init done)"),
            "functional_master": {"requests_blocked_cycles_counted_by_model": d["blocked"], "requests_accepted_in_run_plus_100_cycles": d["acc"],
                                  "scoreboard_checks": d["chk"], "scoreboard_errors": tag(d["err"], "rtl_simulated", src),
                                  "requests_accepted_while_test_owned": tag(d["acc_in_test"], "rtl_simulated", src)},
            "offered_functional_requests_lost_estimate": tag(round(r0 * (d["t_rdy_rise"] - d["t_rdy_fall"]), 1), "analytical",
                                                            "unavailable window x measured traffic acceptance rate (a well-behaved master stops presenting after the acknowledge)")
            if tr else None})
    return {"rows": rows_, "traffic_acceptance_rate_per_cycle": tag(round(r0, 4), "rtl_simulated", src),
            "quiesce_to_ownership_cycles": {
                "no_traffic": tag(acq_0, "rtl_simulated", src),
                "with_traffic_min": tag(min(acq_tr), "rtl_simulated", src, repeats=nrep),
                "with_traffic_max": tag(max(acq_tr), "rtl_simulated", src, repeats=nrep),
                "with_traffic_mean": tag(round(sum(acq_tr) / nrep, 3), "rtl_simulated", src, repeats=nrep),
                "note": "t(tst_active rises) - t(quiesce rises): the drain waits for the in-flight functional accesses (READ_LATENCY + 1 deep) and "
                        "IDLE_CONSEC = 2 consecutive idle cycles"},
            "model": "functional master of sf_mbist_sram_sys (LFSR traffic, scoreboard); the memory group follows the sf_sram_controller "
                     "quiesce / idle / init contract; init engine rewrites one row per cycle (ROWS cycles)",
            "bank_depth": bank_depth, "source": src}


# ---------------------------------------------------------------------------------------------------- failure reporting
def failure_scenarios(rows: int, w: int, nb: int) -> list:
    """(name, {bank: Fault}, config)  config = (algo, pattern, sweep)"""
    c0 = (ALG_MARCH_CM, PAT_ALL0, False)
    sc = [("fault-free memory", {}, c0),
          ("SAF1 bank 5 (row 37, bit 5)", {min(5, nb - 1): Fault(SAF, 37 % rows, 5 % w, 0, 0, 1, 0)}, c0),
          ("SAF0 bank 0 (row 0, MSB)", {0: Fault(SAF, 0, w - 1, 0, 0, 0, 0)}, c0),
          ("up-transition fault bank 9", {min(9, nb - 1): Fault(TF, (rows * 3) // 4, 12 % w, 0, 0, 1, 0)}, c0),
          ("down-transition fault bank 3", {min(3, nb - 1): Fault(TF, rows // 2, 7 % w, 0, 0, 0, 0)}, c0),
          ("address row reaches no cell, bank 7 row 20", {min(7, nb - 1): Fault(AF_NA, 20 % rows, 0, 0, 0, 0, 0)}, c0),
          ("address alias row 10 -> row 99, bank 3", {min(3, nb - 1): Fault(AF_ALI, 10 % rows, 0, 99 % rows, 0, 0, 0)}, c0),
          ("inversion coupling bank 7 ((5,0) -> (100,3))", {min(7, nb - 1): Fault(CFIN, 5 % rows, 0, 100 % rows, 3 % w, 1, 0)}, c0),
          ("two faulty banks (2 and 11): first record must come from bank 2",
           {min(11, nb - 1): Fault(SAF, 3, 3 % w, 0, 0, 1, 0), min(2, nb - 1): Fault(SAF, 50 % rows, 9 % w, 0, 0, 0, 0)}, c0),
          ("same-word CFid_up_f1 bank 1, solid background (expected ESCAPE)", {min(1, nb - 1): Fault(CFID, 4 % rows, 2, 4 % rows, 5, 1, 1)}, c0),
          ("same-word CFid_up_f1 bank 1, background sweep (detected)", {min(1, nb - 1): Fault(CFID, 4 % rows, 2, 4 % rows, 5, 1, 1)},
           (ALG_MARCH_CM, PAT_ALL0, True))]
    return sc


def predict_group(rows: int, w: int, nbanks: int, faults: dict, cfg: tuple) -> dict:
    """Python prediction of the RTL failure registers for a run over banks 0..nbanks-1 (sequential, ascending)."""
    algo, pat, sw = cfg
    total, first, first_bank, mask = 0, None, None, 0
    for b in range(nbanks):
        r = run_march(rows, w, algo, pat, sw, faults.get(b))
        if r["det"]:
            total += r["count"]
            mask |= 1 << b
            if first is None:
                first, first_bank = r["first"], b
    return {"result": "FAIL" if total else "PASS", "count": total, "first": first, "first_bank": first_bank, "bank_fail_mask": mask}


def failure_section(banks, bank_depth: int, word_bits: int, jobs=2) -> dict:
    nb = max(banks)
    scen = failure_scenarios(bank_depth, word_bits, nb)
    lines, meta = [], {}
    for i, (name, flt, cfg) in enumerate(scen, 1):
        lines.append("0")
        for b, f in flt.items():
            lines.append(cmd_fault(b, 0, f))
        lines.append(cmd_run(i, cfg[0], cfg[1], int(cfg[2]), SEL_SEQ, 0, (1 << nb) - 1, 0, bank_depth - 1))
        meta[i] = (name, flt, cfg)
    rr = run_script(nb, bank_depth, word_bits, 1, 1, lines, jobs=jobs)
    g = group_runs(rr)
    src = "sf_sram_mbist failure registers via rtl/tb/tb_sramlab_mbist_run.sv (Verilator); faults from sf_mbist_fault_mem"
    out, nmatch = [], 0
    for i, (name, flt, cfg) in meta.items():
        d = g[i]
        pred = predict_group(bank_depth, word_bits, nb, flt, cfg)
        rtl_first = None
        if d["fail_valid"]:
            rtl_first = {"bank": d["fbank"], "row": d["frow"], "bit": d["fbit"], "bit_v": d["fbit_v"], "elem": d["felem"], "op": d["fop"],
                         "pol": d["fpol"], "pass": d["fpass"], "class": CLS_NAMES.get(d["fcls"], d["fcls"]),
                         "expected": f"0x{_hx(d['fexp']):0{(word_bits + 3) // 4}x}", "observed": f"0x{_hx(d['fobs']):0{(word_bits + 3) // 4}x}"}
        ok = (RES_NAMES[d["result"]] == pred["result"] and d["fail_count"] == pred["count"] and _hx(d["bfm"]) == pred["bank_fail_mask"]
              and ((rtl_first is None) == (pred["first"] is None)))
        if ok and rtl_first:
            p = pred["first"]
            ok = (rtl_first["bank"] == pred["first_bank"] and rtl_first["row"] == p["row"] and rtl_first["bit"] == p["bit"] and
                  rtl_first["bit_v"] == p["bit_v"] and rtl_first["elem"] == p["elem"] and rtl_first["op"] == p["op"] and
                  rtl_first["pol"] == p["pol"] and rtl_first["pass"] == p["pass"] and _hx(d["fexp"]) == p["exp"] and _hx(d["fobs"]) == p["obs"])
        nmatch += int(ok)
        out.append({"scenario": name, "algorithm": ALGO_NAMES[cfg[0]], "background": "sweep" if cfg[2] else ("checkerboard" if cfg[1] == PAT_CHECKER else "solid"),
                    "injected": {str(b): f._asdict() for b, f in flt.items()},
                    "rtl": tag({"result": RES_NAMES[d["result"]], "failure_count": d["fail_count"], "first_failure": rtl_first,
                                "banks_with_failures_mask": f"0x{_hx(d['bfm']):x}", "banks_tested_mask": f"0x{_hx(d['tested']):x}"},
                               "rtl_simulated", src),
                    "python_prediction": tag(pred, "simulated", "sramlab.studies.mbist.run_march (independent March simulator)"),
                    "rtl_matches_python": ok})
    return {"scenarios": out, "all_match": nmatch == len(out), "matched": nmatch, "total": len(out), "banks": nb, "rows": bank_depth, "word_bits": word_bits,
            "note": "'fail_count' counts every failing read (not distinct faults); 'class' is symptom-based: March tests cannot separate SA0 from up-TF"}


# ---------------------------------------------------------------------------------------------------- coverage
def rtl_population(rows: int, w: int, pop: list, jobs=2, timeout=7200) -> list:
    """Run every fault of ``pop`` through the RTL under every configuration (TB cov mode); -> per fault list of per-config
    records (None = not detected)."""
    exe = run_exe(1, rows, w, 1, 1, jobs)
    wd = tempfile.mkdtemp(prefix="sramlab_cov_")
    cf = os.path.join(wd, "cov.txt")
    with open(cf, "w") as f:
        f.write(f"{len(CONFIGS)}\n")
        for _, runs in CONFIGS:
            f.write(f"{len(runs)} " + " ".join(f"{a} {p} {int(s)}" for a, p, s in runs) + "\n")
        for _, _, fl in pop:
            f.write(f"0 {fl.t} {fl.row} {fl.bit} {fl.row2} {fl.bit2} {fl.v} {fl.v2}\n")
    # stream the output: it is large (one line per fault and configuration)
    import subprocess
    p = subprocess.run([exe, f"+cov={cf}"], capture_output=True, text=True, timeout=timeout)
    shutil.rmtree(wd, ignore_errors=True)
    if p.returncode != 0 or "ERROR" in p.stdout or "ANOMALY" in p.stdout:
        raise RuntimeError("coverage testbench failed:\n" + (p.stdout[-1000:] + p.stderr[-500:]))
    res = [[None] * len(CONFIGS) for _ in pop]
    seen = 0
    pat = re.compile(r"^CF idx=(\d+) cfg=(\d+) det=(\d) row=(\d+) bit=(\d+) bit_v=(\d) elem=(\d+) count=(\d+)")
    for ln in p.stdout.splitlines():
        m = pat.match(ln)
        if m:
            i, c, det = int(m[1]), int(m[2]), int(m[3])
            seen += 1
            if det:
                res[i][c] = {"row": int(m[4]), "bit": int(m[5]), "bit_v": int(m[6]), "elem": int(m[7]), "count": int(m[8])}
    if seen != len(pop) * len(CONFIGS):
        raise RuntimeError(f"coverage testbench produced {seen} records, expected {len(pop) * len(CONFIGS)}")
    return res


def compare_sim_rtl(sim: list, rtl: list) -> dict:
    mism, first, n = 0, [], 0
    for i, (a, b) in enumerate(zip(sim, rtl)):
        for c, (x, y) in enumerate(zip(a, b)):
            n += 1
            ok = (x is None) == (y is None)
            if ok and x is not None:
                f = x["first"]
                ok = (f["row"], f["bit"], f["bit_v"], f["elem"], x["count"]) == (y["row"], y["bit"], y["bit_v"], y["elem"], y["count"])
            if not ok:
                mism += 1
                if len(first) < 5:
                    first.append({"fault_index": i, "config": c, "python": x and {"first": x["first"], "count": x["count"]}, "rtl": y})
    return {"compared": n, "mismatches": mism, "first_mismatches": first}


def p78_committed() -> list:
    with open(os.path.join(P78, "reports", "coverage.json")) as f:
        return json.load(f)


def pct(d, t):
    return None if not t else round(100.0 * d / t, 2)


MC_CLASS_MAP = {"AF_noaccess": ("AF_none", "row"), "AF_alias": ("AF_alias", "row pair"), "AF_multi": ("AF_multi_OR", "row pair")}


def memorycore_committed_comparison(tal: dict, labels=None) -> dict:
    """Compare per-class detection counts with MemoryCore's own committed 4x32 exhaustive campaign (``reports/mbist_coverage.json``:
    March C- and MATS+, solid / checkerboard / union).  Needs configurations C0 C1 C2 (March C-) and C4 C5 C6 (MATS+)."""
    with open(os.path.join(MC, "reports", "mbist_coverage.json")) as f:
        data = {c["label"]: c for c in json.load(f)}
    out = {}
    for label, cfgs in (("march_c-_4x32_exhaustive", (0, 1, 2)), ("mats+_4x32_exhaustive", (4, 5, 6))):
        if labels is not None and label not in labels:
            continue
        n = diffs = 0
        first = []
        for r in data[label]["coverage"]:
            if r["class"] in MC_CLASS_MAP:
                cls, sc = MC_CLASS_MAP[r["class"]]
            elif r["scope"] == "cell":
                cls, sc = r["class"], "cell"
            else:
                cls, sc = r["class"], ("intra-word pair" if r["scope"] == "same_word" else "inter-word pair")
            e = tal[(cls, sc)]
            for key, c in zip(("solid", "checker", "union"), cfgs):
                n += 1
                if e["total"] != r["total"] or e["detected"][c] != r[key]:
                    diffs += 1
                    if len(first) < 3:
                        first.append({"class": cls, "scope": sc, "key": key, "memorycore": [r["total"], r[key]], "this": [e["total"], e["detected"][c]]})
        out[label] = {"compared_cells": n, "differences": diffs, "first_differences": first}
    return out


def _march_from_state(rows: int, w: int, algo: int, pattern: int, mem: FaultyMem) -> bool:
    """Run one March over an EXISTING (possibly non-zero) faulty memory; True if any read miscompares."""
    mask = (1 << w) - 1
    bg = [background(pattern, 0, w, r) for r in range(rows)]
    det = False
    for down, eops in MARCH_ELEMENTS[algo]:
        for a in (range(rows - 1, -1, -1) if down else range(rows)):
            for is_rd, pol in eops:
                exp = bg[a] ^ (mask if pol else 0)
                if is_rd:
                    det = det or (mem.read(a) != exp)
                else:
                    mem.write(a, exp)
    return det


def tf_down_prestate_demonstration(rows: int = 4, w: int = 32) -> dict:
    """Why MemoryCore's committed MATS+ checkerboard TF-down figure (128/128) differs from the P78 harness (64/128): MemoryCore runs the checkerboard
    background AFTER the solid run and its re-initialisation writes zero lines THROUGH the faulty array (a TF-down cell that held 1 stays 1), so the second run
    starts from a non-zero state; the P78 model zeroes the array without fault effects before every run.  Both flows replayed in the Python model."""
    cnt = {"cells": 0, "solid_only_detected": 0, "checkerboard_from_all_zero_state_detected": 0,
           "checkerboard_after_re_init_through_faulty_array_detected": 0, "union_with_faulty_re_init_detected": 0}
    for r in range(rows):
        for b in range(w):
            f = Fault(TF, r, b, 0, 0, 0, 0)
            m1 = FaultyMem(rows, w, f)
            d1 = _march_from_state(rows, w, ALG_MATS_P, PAT_ALL0, m1)
            d2 = _march_from_state(rows, w, ALG_MATS_P, PAT_CHECKER, FaultyMem(rows, w, f))
            for a in range(rows):
                m1.write(a, 0)                                    # re-init through the faulty write path
            d3 = _march_from_state(rows, w, ALG_MATS_P, PAT_CHECKER, m1)
            cnt["cells"] += 1
            cnt["solid_only_detected"] += d1
            cnt["checkerboard_from_all_zero_state_detected"] += d2
            cnt["checkerboard_after_re_init_through_faulty_array_detected"] += d3
            cnt["union_with_faulty_re_init_detected"] += (d1 or d3)
    return tag(cnt, "simulated", "sramlab.studies.mbist (independent Python March simulator), MATS+ TF-down cells", note=COVERAGE_STATEMENT)


def coverage_instance(rows: int, w: int, stride: int, run_rtl: bool = True, jobs=2) -> dict:
    t0 = time.time()
    pop = fault_population(rows, w, stride)
    sim = simulate_population(rows, w, pop)
    t_sim = time.time() - t0
    tal = tally(pop, sim)
    out = {"rows": rows, "width": w, "stride": stride, "faults": len(pop), "python_seconds": round(t_sim, 1),
           "coverage_statement": COVERAGE_STATEMENT}
    rtl = None
    if run_rtl:
        t1 = time.time()
        rtl = rtl_population(rows, w, pop, jobs=jobs)
        out["rtl_seconds"] = round(time.time() - t1, 1)
        out["rtl_vs_python_per_fault"] = tag(compare_sim_rtl(sim, rtl), "rtl_simulated",
                                              "every fault x configuration: detected?, first-failure row/bit/element, failing-read count; RTL vs independent Python simulator",
                                              note=COVERAGE_STATEMENT)
        tal_rtl = tally(pop, [[None if x is None else {"first": {"row": x["row"], "bit": x["bit"], "bit_v": x["bit_v"]}} for x in per] for per in rtl])
    ref = [c for c in p78_committed() if c["rows"] == rows and c["width"] == w]
    ref = ref[0] if ref else None
    refmap = {}
    if ref:
        for r in ref["data"]:
            refmap[(r["cls"], r["scope"], r["cfg"])] = r
    table, diffs = [], 0
    for (cls, scope), e in tal.items():
        row = {"class": cls, "scope": scope, "faults": e["total"], "configs": {}}
        for c, nm in enumerate(CFG_NAMES):
            dr = tal_rtl[(cls, scope)]["detected"][c] if rtl is not None else None
            rec = {"detected_python": e["detected"][c], "detected_rtl": dr, "coverage_pct": pct(dr if dr is not None else e["detected"][c], e["total"])}
            if scope == "cell":
                rec["located_exactly_python"] = e["located"][c]
            pr = refmap.get((cls, scope, c))
            if pr is not None and stride == 1:
                rec["p78_committed_detected"] = pr["detected"]
                rec["p78_committed_total"] = pr["total"]
                rec["p78_committed_pct"] = pct(pr["detected"], pr["total"])
                if pr["detected"] != (dr if dr is not None else e["detected"][c]) or pr["total"] != e["total"]:
                    diffs += 1
            row["configs"][nm] = tag(rec, "rtl_simulated" if rtl is not None else "simulated",
                                     "tb_sramlab_mbist_run.sv (cov mode) on sf_sram_mbist; Python simulator cross-check" if rtl is not None else
                                     "sramlab.studies.mbist.run_march", note=COVERAGE_STATEMENT)
        table.append(row)
    out["table"] = table
    out["p78_committed_comparison"] = tag({"compared_cells": len(refmap) if stride == 1 else 0, "differences": diffs if stride == 1 else None,
                                           "note": "exact counts compared (exhaustive instance)" if stride == 1 else "population sub-sampled: counts not comparable, percentages only"},
                                          "rtl_simulated", "rtl/third_party/p78_memorytest/reports/coverage.json (committed by the P78 package, Verilator 5.020)",
                                          note=COVERAGE_STATEMENT)
    if (rows, w) == (4, 32) and stride == 1:
        tal_cmp = tal_rtl if rtl is not None else tal
        out["memorycore_committed_comparison"] = tag(
            memorycore_committed_comparison(tal_cmp), "rtl_simulated" if rtl is not None else "simulated",
            "rtl/third_party/memorycore_sram/reports/mbist_coverage.json (MemoryCore's own 4x32 exhaustive campaign, Verilator 5.020, its own March engine + fault models); "
            "per class: solid / checkerboard / union detection counts for March C- and MATS+", note=COVERAGE_STATEMENT)
        out["memorycore_committed_difference_explained"] = {
            "what": "MATS+ TF-down, checkerboard and union columns: MemoryCore 128/128, this study 64/128 (every other count equal)",
            "likely_reason_demonstrated": tf_down_prestate_demonstration(rows, w)}
    # same-word coupling summary
    summ = {}
    for c, nm in enumerate(CFG_NAMES):
        d = t = 0
        wd_ = wt_ = 0
        for (cls, scope), e in tal.items():
            if scope == "intra-word pair":
                v = tal_rtl[(cls, scope)]["detected"][c] if rtl is not None else e["detected"][c]
                d += v
                t += e["total"]
                if cls in WEAK_SAME_WORD:
                    wd_ += v
                    wt_ += e["total"]
        summ[nm] = tag({"intra_word_coupling_detected": d, "intra_word_coupling_total": t, "pct": pct(d, t),
                        "weak_four_classes_pct": pct(wd_, wt_)}, "rtl_simulated" if rtl is not None else "simulated",
                       "same population definitions as P78 docs/04", note=COVERAGE_STATEMENT)
    out["same_word_coupling_summary"] = summ
    # per algorithm summary over the classes that every algorithm sees (cells, AF, inter-word)
    alg = {}
    for c, nm in enumerate(CFG_NAMES):
        for scope_group, scopes in (("single_cell_faults(SAF,TF)", ("cell",)), ("address_decoder_faults", ("row", "row pair")),
                                    ("inter_word_coupling", ("inter-word pair",)), ("intra_word_coupling", ("intra-word pair",))):
            d = t = 0
            for (cls, scope), e in tal.items():
                if scope in scopes:
                    d += tal_rtl[(cls, scope)]["detected"][c] if rtl is not None else e["detected"][c]
                    t += e["total"]
            alg.setdefault(nm, {})[scope_group] = tag({"detected": d, "total": t, "pct": pct(d, t)}, "rtl_simulated" if rtl is not None else "simulated",
                                                    "aggregated from the per-class table", note=COVERAGE_STATEMENT)
    out["by_algorithm_and_group"] = alg
    return out


def coverage_section(quick=False, jobs=2, stride32: int = 1) -> dict:
    inst = {"4x8": coverage_instance(4, 8, 1, True, jobs)}
    if not quick:
        inst["4x32"] = coverage_instance(4, 32, stride32, True, jobs)
    return {"coverage_statement": COVERAGE_STATEMENT, "instances": inst,
            "fault_population": "SAF0/1, TF up/down (every cell); AF none / alias / multi-OR / multi-AND (rows, ordered row pairs); CFin(2) CFid(4) CFst(4) over every "
                                "ordered pair of distinct cells, split inter-word / intra-word; same definitions as P78 docs/04 + reports/coverage.md",
            "not_modelled": "retention, read-disturb, write recovery, stuck-open, bit-line / sense-amp, neighbourhood pattern-sensitive, multi-cell / bridging "
                            "other than listed, resistive and at-speed faults, soft errors -- NOTHING is claimed about them",
            "configurations": CFG_NAMES}


# ---------------------------------------------------------------------------------------------------- real-stack overhead
TB_STACK = os.path.join(RTL_DIR, "tb", "tb_sramlab_mbist_stack.sv")


def _stack_srcs() -> list:
    srcs = list(P78_RTL)
    srcs += [os.path.join(MC, "rtl", f) for f in ("sf_sram_core.sv", "backends/sf_sram_fpga_bram.sv", "backends/sf_sram_asic_sky130.sv",
                                                  "sf_sram_macro_wrapper.sv", "sf_ecc_enc.sv", "sf_ecc_dec.sv", "sf_ecc_counters.sv",
                                                  "sf_sram_bank.sv", "sf_sram_controller.sv", "sf_sync_fifo.sv")]
    srcs += [os.path.join(MC, "third_party", "ras_secded", f) for f in ("sfras_secded_enc.sv", "sfras_secded_dec.sv")]
    return srcs


def stack_overhead_section(bank_depth: int = 64, nb: int = 4, quick=False, jobs=2, workers=3) -> dict:
    """Test-mode access overhead on the REAL MemoryCore controller (not P78's memory-group model): one March C- run over all ``nb`` banks with
    a HUNGRY functional master (a read is presented every cycle, it never backs off), ECC off / on, READ_LATENCY 1 / 2."""
    variants = [(1, 1)] if quick else [(1, 1), (0, 1), (1, 2)]
    incs = [os.path.join(P78, "rtl"), os.path.join(MC, "rtl"), os.path.join(MC, "third_party", "ras_secded")]
    cases = [(e, r, t) for (e, r) in variants for t in (0, 1)]

    def one(c):
        e, r, t = c
        exe = build_tb("mbist_sstack", "tb_sramlab_mbist_stack", _stack_srcs() + [TB_STACK],
                       {"ECC_EN": e, "READ_LATENCY": r, "NB": nb, "DEPTH": bank_depth}, incs, jobs, extra_flags=["-Wno-WIDTH", "-Wno-DECLFILENAME"])
        rows_ = parse_lines(run_sim(exe, [f"+traffic={t}"], timeout=900))
        d = {}
        for x in rows_:
            if x["_tag"] in ("STACK", "STACKPH", "STACKF"):
                d.update({k: v for k, v in x.items() if k != "_tag"})
        return d
    res = _parallel(one, cases, workers)
    src = "sf_sram_mbist on the real MemoryCore sf_sram_controller via rtl/tb/tb_sramlab_mbist_stack.sv (Verilator)"
    out = []
    for (e, r, t), d in zip(cases, res):
        win = d["t_rdy_rise"] - d["t_rdy_fall"] if t else None
        busy = d["cycles"] - d["f0"]
        model = refined_cycle_model(nb, bank_depth, bank_depth, r, ALG_MARCH_CM, 6, 6)
        out.append({
            "ecc_en": e, "read_latency": r, "banks": nb, "rows": bank_depth, "hungry_functional_master": bool(t),
            "result": RES_NAMES[d["result"]], "total_test_cycles": tag(d["cycles"], "rtl_simulated", src),
            "phase_cycles": {"quiesce_request": tag(d["t_qrise"] - d["t_start"], "rtl_simulated", src),
                             "quiesce_to_ownership": tag(d["t_tact_rise"] - d["t_qrise"], "rtl_simulated", src),
                             "test_ownership": tag(d["t_tact_fall"] - d["t_tact_rise"], "rtl_simulated", src),
                             "release_to_reinit_busy": tag(d["t_ibusy_rise"] - d["t_tact_fall"], "rtl_simulated", src),
                             "reinitialisation": tag(d["t_ibusy_fall"] - d["t_ibusy_rise"], "rtl_simulated", src),
                             "reinit_done_to_quiesce_release": tag(d["t_qfall"] - d["t_ibusy_fall"], "rtl_simulated", src)},
            "engine_run_cycles_test_operations": tag(d["f5"], "rtl_simulated", src),
            "access_protocol_overhead_cycles": tag(d["cycles"] - d["f5"], "rtl_simulated", src),
            "p78_model_cycles_for_same_shape": tag(model, "analytical", "refined_cycle_model with the P78-model calibration (ACQ=6, REL_FIXED=6)"),
            "difference_vs_p78_model_cycles": d["cycles"] - model,
            "functional_master_stalled_window_cycles": tag(win, "rtl_simulated", src,
                                                           note="cycles in which the hungry master's request is refused (m_req_ready low), first refusal to first acceptance") if t else None,
            "functional_requests_accepted_in_run_window": d["accepted"] if t else None,
            "functional_cycles_blocked": d["blocked"] if t else None,
            "one_bank_at_a_time": d["max_sel_w"] == 1, "busy_cycles_p78_convention": busy})
    return {"rows": out, "source": src,
            "note": "the real controller's init engine rewrites one row per cycle like the P78 model; the run differs from the P78 memory-group model by the cycles shown "
                    "in difference_vs_p78_model_cycles"}


# ---------------------------------------------------------------------------------------------------- Verilator caveat
def stack_exe(ecc: int, rl: int, opt: str, jobs=2) -> str:
    """opt: 'default' (no -O flag), 'O0' or 'O3' (Verilator optimisation level, not the C++ one)."""
    srcs = list(P78_RTL)
    srcs += [os.path.join(MC, "rtl", f) for f in ("sf_sram_core.sv", "backends/sf_sram_fpga_bram.sv", "backends/sf_sram_asic_sky130.sv",
                                                  "sf_sram_macro_wrapper.sv", "sf_ecc_enc.sv", "sf_ecc_dec.sv", "sf_ecc_counters.sv",
                                                  "sf_sram_bank.sv", "sf_sram_controller.sv", "sf_sync_fifo.sv")]
    srcs += [os.path.join(MC, "third_party", "ras_secded", f) for f in ("sfras_secded_enc.sv", "sfras_secded_dec.sv")]
    srcs += [os.path.join(P78, "verif", "tb", "tb_mbist_memorycore.sv")]
    incs = [os.path.join(P78, "rtl"), os.path.join(P78, "verif", "tb"), os.path.join(MC, "rtl"), os.path.join(MC, "third_party", "ras_secded")]
    flags = ["-Wno-WIDTH", "-Wno-DECLFILENAME"] + ([] if opt == "default" else [f"-{opt}"])
    return build_tb("mbist_stack_" + opt, "tb_mbist_memorycore", srcs, {"ECC_EN": ecc, "READ_LATENCY": rl}, incs, jobs,
                    extra_flags=flags)


def caveat_section(quick=False, jobs=2, workers=3) -> dict:
    """P78 warns that Verilator 5.020's default (optimised) build mis-simulates MemoryCore's vendored CFST fault model in the integrated
    real-stack testbench (39-bit stored word) and builds that testbench with -O0.  Re-run P78's own ``tb_mbist_memorycore`` here, with and
    without -O0, and report what this Verilator does."""
    variants = [(1, 1)] if quick else [(1, 1), (1, 2), (0, 1), (0, 2)]
    cases = [(e, r, opt) for (e, r) in variants for opt in ("default", "O0", "O3")]

    def one(c):
        e, r, opt = c
        exe = stack_exe(e, r, opt, jobs)
        out = run_sim(exe, [], timeout=900)
        m = re.search(r"RESULT tb_mbist_memorycore ECC_EN=(\d) READ_LATENCY=(\d) STORE_W=(\d+) checks=(\d+) errors=(\d+) (\w+)", out)
        ft = {int(a): (int(b), int(c_)) for a, b, c_ in re.findall(r"fault type (\d+) -> result (\d+) \(2 = FAIL\), fail_count (\d+)", out)}
        return {"ecc_en": e, "read_latency": r, "verilator_opt": opt, "stored_word_bits": int(m[3]) if m else None,
                "checks": int(m[4]) if m else None, "errors": int(m[5]) if m else None, "verdict": m[6] if m else "NO RESULT LINE",
                "fault_type_result": {str(k): {"result": RES_NAMES.get(v[0], v[0]), "fail_count": v[1]} for k, v in ft.items()},
                "cfst_type8_detected": ft.get(8, (None, 0))[0] == 2}
    res = _parallel(one, cases, workers)
    p78 = {"ecc1": 290, "ecc0": 265}
    allok = all(r["verdict"] == "PASS" and r["cfst_type8_detected"] for r in res)
    return {"runs": res, "all_pass_and_cfst_detected_in_every_build": allok,
            "p78_warning": "Verilator 5.020: default (optimised) build did NOT detect CFST in the integrated 39-bit build, -O0 and Icarus did; -O3 and the default did not (P78 docs/06 section 5, docs/07 item 10)",
            "p78_committed_check_counts": p78,
            "observation": ("On this Verilator (" + str((verilator_info() or {}).get("pip_package_version")) + ", simulator reports "
                            + str(_ecc.SIM_VERSION.get("reported_by_simulator")) + ") the P78 real-stack testbench passes with the default build, -O0 and -O3 "
                            + ("and CFST (fault type 8) is detected in every build; the 5.020 symptom is NOT reproduced. " if allok else
                               "BUT at least one build fails or misses CFST: see runs. ")
                            + "This does not prove the 5.020 behaviour was a Verilator bug or that it is fixed: 5.020 is not installed here and was not re-run."),
            "handling": "SRAMLab's own MBIST runs use the P78 fault-model memory (sf_mbist_fault_mem), not MemoryCore's vendored CFST model, so they are not exposed to "
                        "the warned case; the real-stack check is re-run in both modes and is reported here",
            "provenance": "rtl_simulated", "source": "rtl/third_party/p78_memorytest/verif/tb/tb_mbist_memorycore.sv on the vendored MemoryCore stack (Verilator)"}


MANDATORY_NOTES = [
    "All RTL numbers come from Verilator runs executed by this module on the vendored P78 / MemoryCore RTL; nothing is 'measured' (no silicon).",
    COVERAGE_STATEMENT + ".",
    "The RTL tests banks one after another (sequential); the parallel-bank numbers are an analytical model, not RTL-verified.",
    "March tests as implemented here do not exercise retention, read-disturb, bit-line / sense-amp, resistive or at-speed faults (not modelled).",
    "The functional-traffic measurements use P78's verification-only memory-group model (sf_mbist_sram_sys), which follows the sf_sram_controller "
    "quiesce/idle/init contract; they are RTL simulation of the MBIST controller against that model, not of the MemoryCore controller itself.",
]


def _headline(res: dict) -> dict:
    """Plain-number digest (every value is also present, with provenance, in the sections it comes from)."""
    from ..provenance import strip
    h = {"coverage_statement": COVERAGE_STATEMENT}
    tc = res.get("test_cycles", {})
    if isinstance(tc, dict) and "runs" in tc:
        nb, n = max(res["banks"]), res["bank_depth"]
        for algo in (ALG_MARCH_CM, ALG_MATS_P):
            r = [x for x in tc["runs"] if x["algo"] == algo and x["banks"] == nb and x["window"] == n and not x["sweep"]]
            if r:
                h[f"{ALGO_NAMES[algo]}_cycles_{nb}_banks_x_{n}_words"] = strip(r[0]["cycles"])
                h[f"{ALGO_NAMES[algo]}_ops_only_model_error_pct"] = r[0]["ops_only_model_error_pct"]
        h["cycle_model_max_abs_error_cycles"] = tc["cycle_model"]["max_abs_error_cycles"]
        h["one_bank_at_a_time_verified"] = strip(tc["verified_one_bank_at_a_time"])
    cov = res.get("coverage", {})
    for nm, inst in (cov.get("instances", {}) if isinstance(cov, dict) else {}).items():
        h[f"coverage_{nm}_rtl_vs_python_mismatches"] = strip(inst["rtl_vs_python_per_fault"])["mismatches"]
        h[f"coverage_{nm}_p78_committed_differences"] = strip(inst["p78_committed_comparison"])["differences"]
        h[f"coverage_{nm}_same_word_pct"] = {c: strip(v)["pct"] for c, v in inst["same_word_coupling_summary"].items()}
    fr = res.get("failure_reporting", {})
    if isinstance(fr, dict) and "all_match" in fr:
        h["failure_registers_match_python"] = f"{fr['matched']}/{fr['total']}"
    cv = res.get("verilator_caveat", {})
    if isinstance(cv, dict) and "runs" in cv:
        h["verilator_caveat_reproduced"] = not cv["all_pass_and_cfst_detected_in_every_build"]
    return h


def run_mbist_study(banks=(2, 4, 8, 16), bank_depth: int = 256, word_bits: int = 32, outdir: str | None = None, quick: bool = False,
                    workers: int = 3, progress=None) -> dict:
    """Run the MBIST evaluation.  Returns a JSON-serialisable dict; writes ``<outdir>/mbist_study.json`` / ``.csv`` when ``outdir`` is given.
    ``quick=True``: fewer windows / traffic repeats, coverage on the 4x8 instance only, one Verilator-caveat variant."""
    t_start = time.time()
    banks = [int(b) for b in banks]
    log = progress or (lambda m: None)
    v = verilator_info()
    res = {"study": "mbist", "schema": 1, "quick": bool(quick), "banks": banks, "bank_depth": bank_depth, "word_bits": word_bits,
           "coverage_statement": COVERAGE_STATEMENT, "environment": {**tools.environment(), "verilator_detail": v}, "notes": list(MANDATORY_NOTES)}
    if v is None:
        res["error"] = unavailable("Verilator is not installed: every RTL-derived item is unavailable")
        res["wall_seconds"] = round(time.time() - t_start, 1)
        return res
    log("test cycles")
    cyc = _guard(lambda: cycle_section(banks, bank_depth, word_bits, quick=quick), "cycle measurement")
    with ThreadPoolExecutor(2) as bg:
        f_cov = bg.submit(lambda: _guard(lambda: coverage_section(quick=quick), "coverage campaign"))
        f_cav = bg.submit(lambda: _guard(lambda: caveat_section(quick=quick), "Verilator caveat check"))
        log("overhead / failure reporting")
        ovh = _guard(lambda: overhead_section(banks, bank_depth, word_bits, quick=quick), "test-mode overhead")
        fail = _guard(lambda: failure_section(banks, bank_depth, word_bits), "failure reporting")
        stack = _guard(lambda: stack_overhead_section(min(bank_depth, 64), min(max(banks), 4), quick=quick), "real-stack overhead")
        log("coverage + caveat (wait)")
        cov, cav = f_cov.result(), f_cav.result()
    if isinstance(cyc, dict) and "runs" in cyc:
        src = cyc["source"]
        cal = cyc["calibration"]
        for r in cyc["runs"]:
            for k in ("cycles", "ops_only_model", "refined_model"):
                r[k] = tag(r[k], "rtl_simulated" if k == "cycles" else "analytical", src if k == "cycles" else "operation-count model")
        sequential = all(r["max_sel_w"] == 1 for r in cyc["runs"])
        orders_ok = all(order_list(r["order"], r["order_n"]) == list(range(r["banks"])) for r in cyc["runs"])
        res["test_cycles"] = {
            "what_the_rtl_does_with_several_banks": "Banks selected by the mask are tested ONE AFTER ANOTHER in ascending index (tst_sel is one-hot); per bank: "
                                                   "BSEL, PINIT, RUN (K*N operations), DRAIN (LT), BEND; one ownership acquisition and one re-initialisation per run.",
            "verified_one_bank_at_a_time": tag(bool(sequential and orders_ok), "rtl_simulated", "max popcount(tst_sel) over every run == 1 and bank order ascending"),
            "analytical_operation_counts": {"March C-": "10 N per bank", "MATS+": "5 N per bank (N = words in the test window)",
                                            "verified_in_rtl": "engine RUN-state cycles == 10 N B / 5 N B in every run (see runs[].run_cycles)"},
            "cycle_model": {"formula": "cycles = B*(K*N + LT + 3) + ACQ + (ROWS + REL_FIXED) + 3", "ACQ_cycles": cal["acq_cycles"],
                            "REL_FIXED_cycles": cal["rel_fixed_cycles"], "LT": cyc["read_latency"], "ROWS": bank_depth,
                            "validated_on_runs": len(cyc["runs"]) + len(cyc["scaling_runs"]),
                            "max_abs_error_cycles": max([abs(r["refined_model_error_cycles"]) for r in cyc["runs"]] +
                                                        [abs(s["cycles"] - s["model"]) for s in cyc["scaling_runs"]]),
                            "calibration_source": cal["source_run"]},
            "runs": cyc["runs"], "per_bank_time": cyc["per_bank_slopes"], "scaling_runs": cyc["scaling_runs"], "p78_cross_check": cyc["p78_cross_check"],
            "parallel_bank_model_analytical": {ALGO_NAMES[a]: parallel_model(banks, bank_depth, bank_depth, cyc["read_latency"], a, cal["acq_cycles"], cal["rel_fixed_cycles"])
                                               for a in (ALG_MARCH_CM, ALG_MATS_P)},
            "provenance": "rtl_simulated", "source": src}
    else:
        res["test_cycles"] = cyc
    res["test_mode_overhead"] = ovh
    res["test_mode_overhead_real_controller"] = stack
    res["failure_reporting"] = fail
    res["coverage"] = cov
    res["verilator_caveat"] = cav
    res["simulator_version_reported"] = dict(_ecc.SIM_VERSION)
    res["headline"] = _guard(lambda: _headline(res), "headline")
    res["unavailable_items"] = [p for p, x in _walk_unavailable(res)]
    res["wall_seconds"] = round(time.time() - t_start, 1)
    if outdir:
        res["files"] = write_outputs(res, outdir, "mbist_study", ("test_cycles", "test_mode_overhead", "test_mode_overhead_real_controller", "failure_reporting", "coverage", "verilator_caveat"))
        with open(res["files"]["json"], "w") as f:
            json.dump(res, f, indent=1, default=str)
    return res
