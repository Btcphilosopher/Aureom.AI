"""ECC cost study (brief section 10): SRAM with ECC disabled vs SECDED, measured on the real MemoryCore RTL.

Everything reported carries a provenance label (``sramlab.provenance``):

  analytical     stored bits per word / storage overhead (closed form, cross-checked against the widths the
                 elaborated RTL reports)
  synthesized    Yosys GENERIC-gate counts (no liberty file => cell counts, NOT area, NOT timing, NOT power)
  rtl_simulated  Verilator runs of ``sf_sram_bank`` / ``sf_ecc_enc`` / ``sf_ecc_dec`` (decoder latency, partial-write
                 read-modify-write cost, scrub cost, fault reporting)
  unavailable    anything that could not be produced, with the reason

NOTHING here is ``measured`` (no silicon / FPGA measurement exists).  Error *rates* of real SRAM are out of scope: the
fault-injection results say what the logic does when it is handed a 1/2/3-bit error, not how often that happens.

The independent Python SECDED reference in this module (:class:`SecdedRef`) is written from the documented code
layout (``third_party/ras_secded/sfras_ecc_funcs.svh`` header), shares no code with the RTL, and is cross-checked
against the RTL encoder/decoder over seeded random + exhaustive vectors (:func:`crosscheck_codec`), and against the
MemoryCore package's own Python reference (second, independent implementation).

Entry point: :func:`run_ecc_study`.
"""
from __future__ import annotations

import csv
import hashlib
import threading
import uuid
import itertools
import json
import os
import re
import shutil
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor
from importlib import metadata as _md

from .. import tools
from ..prng import SplitMix64
from ..provenance import tag, unavailable

ROOT = tools.ROOT
RTL_DIR = os.path.join(ROOT, "rtl")
MC = os.path.join(RTL_DIR, "third_party", "memorycore_sram")
MC_RTL = os.path.join(MC, "rtl")
MC_RAS = os.path.join(MC, "third_party", "ras_secded")
TB_DIR = os.path.join(RTL_DIR, "tb")
try:                                                    # the shared build cache of the RTL comparison (rtlrun.BUILD_ROOT)
    from ..rtlrun import BUILD_ROOT
except Exception:                                       # rtlrun unavailable / mid-edit: same default location and override variable
    BUILD_ROOT = os.environ.get("SRAMLAB_BUILD", os.path.join(ROOT, ".build"))
BUILD_SCHEME = 1     # bump when the way the testbenches are built changes

ECC_RTL = [  # compile order is irrelevant to Verilator; the list is also the hash input of the build cache
    os.path.join(MC_RTL, "sf_sram_core.sv"), os.path.join(MC_RTL, "backends", "sf_sram_fpga_bram.sv"),
    os.path.join(MC_RTL, "backends", "sf_sram_asic_sky130.sv"), os.path.join(MC_RTL, "sf_sram_macro_wrapper.sv"),
    os.path.join(MC_RTL, "sf_ecc_enc.sv"), os.path.join(MC_RTL, "sf_ecc_dec.sv"),
    os.path.join(MC_RTL, "sf_ecc_counters.sv"), os.path.join(MC_RTL, "sf_sram_bank.sv"),
    os.path.join(MC_RAS, "sfras_secded_enc.sv"), os.path.join(MC_RAS, "sfras_secded_dec.sv"),
]
CODEC_RTL = [os.path.join(MC_RTL, "sf_ecc_enc.sv"), os.path.join(MC_RTL, "sf_ecc_dec.sv"),
             os.path.join(MC_RAS, "sfras_secded_enc.sv"), os.path.join(MC_RAS, "sfras_secded_dec.sv")]
INCS = [MC_RTL, MC_RAS]
TB_CODEC = os.path.join(TB_DIR, "tb_sramlab_ecc_codec.sv")
TB_BANK = os.path.join(TB_DIR, "tb_sramlab_ecc_bank.sv")

# decoder classes (sf_sram_defs.svh SF_ECC_*)
C_NONE, C_CE_DATA, C_CE_CHECK, C_UE_DOUBLE, C_UE_INVALID = range(5)
CLASS_NAMES = ["none", "ce_data", "ce_check", "ue_double", "ue_invalid"]
ST_OK, ST_ECC_UE = 0, 3          # SF_ST_*

_M64 = (1 << 64) - 1


# ----------------------------------------------------------------------------------------------------------
# Verilator build / run helpers (shared with mbist.py)
# ----------------------------------------------------------------------------------------------------------
def verilator_info() -> dict | None:
    v = tools.verilator()
    if v is None:
        return None
    d = dict(v)
    try:
        d["pip_package_version"] = _md.version("verilator")
    except Exception:
        d["pip_package_version"] = None
    return d


def _file_hash(paths) -> str:
    h = hashlib.sha256()
    for p in paths:
        with open(p, "rb") as f:
            h.update(f.read())
    return h.hexdigest()


def gval(name: str, val) -> str:
    """-G value text.  64-bit parameters must be sized hex literals (see rtlrun._gval); everything here is int/str."""
    return str(val)


_BUILD_LOCKS: dict = {}
_BUILD_LOCKS_GUARD = threading.Lock()


def _build_lock(path: str) -> threading.Lock:
    """One lock per build directory: concurrent workers asking for the same testbench wait for the first build
    instead of racing on the same temporary directory (found by a cold-cache run of the suite)."""
    with _BUILD_LOCKS_GUARD:
        return _BUILD_LOCKS.setdefault(path, threading.Lock())


def build_tb(prefix: str, top: str, srcs: list, generics: dict, incs=None, jobs: int = 2, extra_flags=(),
             verbose: bool = False) -> str:
    """Compile a Verilator testbench (cached under BUILD_ROOT, keyed on the exact -G strings, the sources and the Verilator
    version).  Same recipe as ``sramlab.rtlrun.build`` (pip wheel needs ``-MAKEFLAGS CFG_CXXFLAGS_PCH_I=-include``).
    Returns the simulator binary path."""
    v = verilator_info()
    if v is None:
        raise RuntimeError("Verilator is not installed: RTL results are unavailable (`pip install verilator`)")
    gen = {k: gval(k, x) for k, x in generics.items()}
    key = hashlib.sha256(json.dumps([prefix, top, gen, _file_hash(srcs), v["version"], v.get("pip_package_version"),
                                     BUILD_SCHEME, list(extra_flags), [os.path.relpath(s, ROOT) for s in srcs]],
                                    sort_keys=True).encode()).hexdigest()[:16]
    mdir = os.path.join(BUILD_ROOT, f"{prefix}_{key}")
    exe = os.path.join(mdir, "simv")
    if os.path.exists(exe):
        return exe
    with _build_lock(mdir):
        if os.path.exists(exe):                       # another worker built it while we waited
            return exe
        return _build_tb_locked(v, top, gen, srcs, incs, jobs, extra_flags, verbose, prefix, mdir, exe)


def _build_tb_locked(v, top, gen, srcs, incs, jobs, extra_flags, verbose, prefix, mdir, exe) -> str:
    os.makedirs(BUILD_ROOT, exist_ok=True)
    tmp = mdir + f".tmp{os.getpid()}_{uuid.uuid4().hex[:10]}"
    shutil.rmtree(tmp, ignore_errors=True)
    cmd = [v["exe"], "--binary", "--timing", "-j", str(jobs), "-Wno-fatal", "-Wno-lint", "-Wno-style",
           "-Wno-TIMESCALEMOD", "--top-module", top, "-Mdir", tmp, "-o", "simv",
           # the pip Verilator wheel ships CFG_CXXFLAGS_PCH_I empty, so gcc would get the precompiled header as a bare
           # linker input; pass -include explicitly (harmless on a normal install)
           "-MAKEFLAGS", "CFG_CXXFLAGS_PCH_I=-include", "--x-assign", "0", "--x-initial", "0"]
    cmd += [f"-I{i}" for i in (incs or [])] + list(extra_flags)
    cmd += [f"-G{k}={x}" for k, x in gen.items()]
    cmd += list(srcs)
    t0 = time.time()
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not os.path.exists(os.path.join(tmp, "simv")):
        raise RuntimeError(f"Verilator build of {top} {gen} failed:\n" + (r.stdout + r.stderr)[-3000:])
    try:
        os.replace(tmp, mdir)
    except OSError:                                   # a concurrent build won the race: use its result
        shutil.rmtree(tmp, ignore_errors=True)
        if not os.path.exists(exe):
            raise
    if verbose:
        print(f"[rtl] built {prefix} {gen} in {time.time() - t0:.1f}s")
    return exe


SIM_VERSION = {"reported_by_simulator": None}


def run_sim(exe: str, args: list | None = None, timeout: int = 900) -> str:
    r = subprocess.run([exe] + list(args or []), capture_output=True, text=True, timeout=timeout)
    out = r.stdout + r.stderr
    m = re.search(r"Simulation\s+Report:\s+(Verilator\s+[\w.\-]+)", out.replace("S i m u l a t i o n   R e p o r t", "Simulation Report"))
    if m:
        SIM_VERSION["reported_by_simulator"] = m.group(1)
    if r.returncode != 0:
        raise RuntimeError(f"simulator {os.path.basename(os.path.dirname(exe))} exited {r.returncode}:\n{out[-2000:]}")
    return out


def _parallel(fn, items, workers: int = 3):
    items = list(items)
    if workers <= 1 or len(items) <= 1:
        return [fn(i) for i in items]
    with ThreadPoolExecutor(workers) as ex:
        return list(ex.map(fn, items))


# ----------------------------------------------------------------------------------------------------------
# Independent SECDED reference (written from the documented layout, shares no code with the RTL)
# ----------------------------------------------------------------------------------------------------------
def _popc(x: int) -> int:
    return x.bit_count()


class SecdedRef:
    """Extended-Hamming SECDED, K data bits, R check bits (smallest R with 2**R >= K+R+1), 1 overall parity bit.

    Stored word, LSB first: data[K-1:0] | check[R-1:0] | parity -> N = K+R+1 bits.  Syndrome value ("position") of
    check bit j = 2**j; of data bit i = the (i+1)-th integer >= 3 that is not a power of two; the parity bit has no
    position.  ``inv`` (R+1 bits, applied to {parity, check}) is the check-bit inversion of the RTL's default memory
    configuration: the first pair a<b (bit indices 0..R of {parity,check}) for which both the all-zero and the all-ones
    stored word decode as uncorrectable; (0,1) if none does.  It is found here by brute-force decoding, as documented.
    """

    def __init__(self, k: int, inv: int | None = None):
        self.k = k
        r = 1
        while (1 << r) < k + r + 1:
            r += 1
        self.r = r
        self.n = k + r + 1
        cols, v = [], 3
        while len(cols) < k:
            if v & (v - 1):
                cols.append(v)
            v += 1
        self.col = cols                                       # syndrome column of data bit i
        # data-bit mask per check bit (check j covers data bit i iff col[i] has bit j)
        self.cmask = [sum(1 << i for i in range(k) if (cols[i] >> j) & 1) for j in range(r)]
        self.dmask = (1 << k) - 1
        self.pos2idx = {c: i for i, c in enumerate(cols)}     # syndrome -> data bit index
        self.inv = self._pick_inv() if inv is None else inv

    # -- raw (not inverted) helpers
    def _checks(self, data: int) -> int:
        c = 0
        for j, m in enumerate(self.cmask):
            c |= (_popc(data & m) & 1) << j
        return c

    def encode(self, data: int) -> int:
        c = self._checks(data)
        p = (_popc(data) + _popc(c)) & 1                      # even overall parity over data + check bits
        w = data | (c << self.k) | (p << (self.k + self.r))
        return w ^ (self.inv << self.k)

    def decode(self, stored: int) -> tuple:
        """-> (class, data_out, corrected_stored_word, ce, ue, err_idx)  (err_idx = 0 unless ce)"""
        k, r = self.k, self.r
        w = stored ^ (self.inv << k)
        data = w & self.dmask
        c = (w >> k) & ((1 << r) - 1)
        p = (w >> (k + r)) & 1
        s = self._checks(data) ^ c
        pe = (p + _popc(data) + _popc(c)) & 1
        if s == 0 and pe == 0:
            return C_NONE, data, stored, 0, 0, 0
        if s == 0:                                            # pe == 1: the overall parity bit flipped
            return C_CE_CHECK, data, stored ^ (1 << (k + r)), 1, 0, k + r
        if pe == 0:
            return C_UE_DOUBLE, data, stored, 0, 1, 0
        if s > k + r:
            return C_UE_INVALID, data, stored, 0, 1, 0
        i = self.pos2idx.get(s)
        if i is not None:                                     # position s names a data bit
            return C_CE_DATA, data ^ (1 << i), stored ^ (1 << i), 1, 0, i
        j = s.bit_length() - 1                                # a power of two: check bit j
        return C_CE_CHECK, data, stored ^ (1 << (k + j)), 1, 0, k + j

    def _pick_inv(self) -> int:
        ones = (1 << self.n) - 1
        for a in range(self.r + 1):
            for b in range(a + 1, self.r + 1):
                inv = (1 << a) | (1 << b)
                ref = SecdedRef.__new__(SecdedRef)
                ref.__dict__.update(self.__dict__)
                ref.inv = inv
                if ref.decode(0)[4] and ref.decode(ones)[4]:
                    return inv
        return 3

    def with_mutation(self, **kw) -> "SecdedRef":
        """A deliberately WRONG reference (negative control for the tests): kw = inv=..., or swap_cols=(i, j)."""
        m = SecdedRef.__new__(SecdedRef)
        m.__dict__.update(self.__dict__)
        if "inv" in kw:
            m.inv = kw["inv"]
        if "swap_cols" in kw:
            i, j = kw["swap_cols"]
            cols = list(m.col)
            cols[i], cols[j] = cols[j], cols[i]
            m.col = cols
            m.cmask = [sum(1 << t for t in range(m.k) if (cols[t] >> b) & 1) for b in range(m.r)]
            m.pos2idx = {c: t for t, c in enumerate(cols)}
        return m


def rand_bits(rng: SplitMix64, nbits: int) -> int:
    v = 0
    for _ in range((nbits + 63) // 64):
        v = (v << 64) | rng.next_u64()
    return v & ((1 << nbits) - 1)


def rand_positions(rng: SplitMix64, n: int, w: int) -> list:
    pos = []
    while len(pos) < w:
        b = rng.randbelow(n)
        if b not in pos:
            pos.append(b)
    return pos


def _mask_of(pos) -> int:
    m = 0
    for b in pos:
        m |= 1 << b
    return m


def codec_vectors(ref: SecdedRef, rng: SplitMix64, quick: bool) -> list:
    """List of (kind, data, mask, tag).  kind 0: stored = enc(data) ^ mask ; kind 1: stored = mask (raw word)."""
    n = ref.n
    vs = []
    nrand = 300 if quick else 2000
    # error-free + random weight 4..6 (outside any guarantee: pure cross-check of RTL == reference)
    for _ in range(nrand):
        vs.append((0, rand_bits(rng, ref.k), 0, "w0"))
    for w in (4, 5, 6):
        for _ in range(nrand // 2 if quick else 1000):
            vs.append((0, rand_bits(rng, ref.k), _mask_of(rand_positions(rng, n, w)), f"w{w}"))
    # directed data patterns
    for d in (0, ref.dmask, 0x5555555555555555 * 3 & ref.dmask, 0xAAAAAAAAAAAAAAAA * 3 & ref.dmask):
        vs.append((0, d, 0, "w0"))
    for i in range(0, ref.k, max(1, ref.k // 16)):
        vs.append((0, 1 << i, 0, "w0"))
    # raw all-zero / all-ones stored words (the inversion makes the all-zero word uncorrectable)
    vs.append((1, 0, 0, "raw_zero"))
    vs.append((1, 0, (1 << n) - 1, "raw_ones"))
    # every single-bit error position, random data
    for b in range(n):
        vs.append((0, rand_bits(rng, ref.k), 1 << b, "w1"))
        if not quick:
            vs.append((0, rand_bits(rng, ref.k), 1 << b, "w1"))
    # double-bit: every pair (data independent for a linear code, but data is random anyway)
    pairs = list(itertools.combinations(range(n), 2))
    if quick and len(pairs) > 1500:
        pairs = [pairs[rng.randbelow(len(pairs))] for _ in range(1500)]
    for a, b in pairs:
        vs.append((0, rand_bits(rng, ref.k), (1 << a) | (1 << b), "w2"))
    # triple-bit: exhaustive when small, seeded sample otherwise
    ntrip = n * (n - 1) * (n - 2) // 6
    lim = 3000 if quick else 20000
    if ntrip <= (3000 if quick else 60000):
        for t in itertools.combinations(range(n), 3):
            vs.append((0, rand_bits(rng, ref.k), _mask_of(t), "w3"))
    else:
        for _ in range(lim):
            vs.append((0, rand_bits(rng, ref.k), _mask_of(rand_positions(rng, n, 3)), "w3"))
    return vs


def exact_weight_stats(ref: SecdedRef, weight: int) -> dict:
    """Exhaustive outcome of every weight-``weight`` error pattern over the N stored bits, using the reference decoder.
    For a linear code the class depends only on the error pattern (the stored data cancels), so one data word suffices.
    Outcomes: detected (UE flagged), miscorrected (decoder 'corrects' a wrong bit: data_out != data, no UE flag),
    benign (data_out == data, no UE flag; e.g. only check bits were hit / single error corrected)."""
    n = ref.n
    data = 0x1234567890ABCDEF1234567890ABCDEF & ref.dmask
    cw = ref.encode(data)
    cnt = {"detected_ue": 0, "miscorrected": 0, "benign": 0, "total": 0}
    for pos in itertools.combinations(range(n), weight):
        e = _mask_of(pos)
        cls, dout, _, ce, ue, _ = ref.decode(cw ^ e)
        cnt["total"] += 1
        if ue:
            cnt["detected_ue"] += 1
        elif dout != data:
            cnt["miscorrected"] += 1
        else:
            cnt["benign"] += 1
    return cnt


# ----------------------------------------------------------------------------------------------------------
# Item 7: codec cross-check, Python reference vs RTL encoder / decoder
# ----------------------------------------------------------------------------------------------------------
def _hexw(v: int, bits: int) -> str:
    return format(v, "0%dx" % ((bits + 3) // 4))


def codec_exe(k: int, jobs: int = 2) -> str:
    return build_tb("ecc_codec", "tb_sramlab_ecc_codec", CODEC_RTL + [TB_CODEC], {"K": k}, INCS, jobs)


def crosscheck_codec(k: int, quick: bool = False, seed: int = 0xEC0DEC, ref: SecdedRef | None = None,
                     workdir: str | None = None, jobs: int = 2) -> dict:
    """Run the vectors through the RTL codec (Verilator) and compare with ``ref`` (default: the independent
    reference).  Returns counts, the first mismatches, and per-weight outcome statistics measured on the RTL."""
    ref = ref or SecdedRef(k)
    rng = SplitMix64(seed ^ (k * 0x9E3779B97F4A7C15 & _M64))
    vecs = codec_vectors(ref, rng, quick)
    exe = codec_exe(k, jobs)
    wd = workdir or tempfile.mkdtemp(prefix="sramlab_eccvec_")
    os.makedirs(wd, exist_ok=True)
    vf = os.path.join(wd, f"codec_k{k}.vec")
    n = ref.n
    with open(vf, "w") as f:
        for kind, d, m, _ in vecs:
            f.write(f"{kind} {_hexw(d, k)} {_hexw(m, n)}\n")
    out = run_sim(exe, [f"+vec={vf}"], timeout=1800)
    if workdir is None:
        shutil.rmtree(wd, ignore_errors=True)
    cfg = re.search(r"CFG K=(\d+) R=(\d+) N=(\d+)", out)
    rows = [ln.split() for ln in out.splitlines() if ln.startswith("V ")]
    if cfg is None or len(rows) != len(vecs):
        raise RuntimeError(f"codec testbench produced {len(rows)} results for {len(vecs)} vectors:\n{out[-800:]}")
    rtl_r, rtl_n = int(cfg.group(2)), int(cfg.group(3))
    mism, first = 0, []
    stats = {}     # weight tag -> outcome counts as measured on the RTL
    raw_words = {}
    enc_bad = dec_bad = 0
    for (kind, d, m, tg), row in zip(vecs, rows):
        enc_cw, stored, dout, ccorr, ce, ue, cls, idx = row[1:9]
        enc_cw, stored, dout, ccorr = int(enc_cw, 16), int(stored, 16), int(dout, 16), int(ccorr, 16)
        ce, ue, cls, idx = int(ce), int(ue), int(cls), int(idx)
        exp_stored = m if kind == 1 else ref.encode(d) ^ m
        ok = True
        if kind == 0 and enc_cw != ref.encode(d):
            enc_bad += 1
            ok = False
        if stored != exp_stored:
            ok = False
        rcls, rdata, rcorr, rce, rue, ridx = ref.decode(exp_stored)
        if (dout, ccorr, ce, ue, cls) != (rdata, rcorr, rce, rue, rcls) or (ce and idx != ridx):
            dec_bad += 1
            ok = False
        if not ok:
            mism += 1
            if len(first) < 5:
                first.append({"tag": tg, "data": hex(d), "mask": hex(m), "rtl": [hex(dout), ce, ue, cls, idx],
                              "ref": [hex(rdata), rce, rue, rcls, ridx]})
        if kind == 1:
            raw_words[tg] = {"stored": hex(stored), "ue": ue, "ce": ce, "class": CLASS_NAMES[cls]}
        if kind == 0:
            s = stats.setdefault(tg, {"total": 0, "detected_ue": 0, "miscorrected": 0, "corrected_ok": 0, "clean": 0})
            s["total"] += 1
            if m == 0 and not ue and dout == d:
                s["clean"] += 1
            elif ue:
                s["detected_ue"] += 1
            elif dout == d:
                s["corrected_ok"] += 1
            else:
                s["miscorrected"] += 1
    return {"k": k, "r_rtl": rtl_r, "n_rtl": rtl_n, "r_ref": ref.r, "n_ref": ref.n, "inv_ref": ref.inv,
            "vectors": len(vecs), "mismatches": mism, "encoder_mismatches": enc_bad, "decoder_mismatches": dec_bad,
            "first_mismatches": first, "rtl_outcomes_by_weight": stats, "raw_words_rtl": raw_words, "seed": seed, "quick": quick}


def upstream_ref_agreement(k: int, nvec: int = 300, seed: int = 0x5EED) -> dict:
    """Second cross-check: this module's reference vs the MemoryCore package's own Python reference
    (``tools/ecc/secded_ref.py``, vendored byte-identical).  Pure Python."""
    import importlib.util
    path = os.path.join(MC, "tools", "ecc", "secded_ref.py")
    spec = importlib.util.spec_from_file_location("_mc_secded_ref", path)
    up = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(up)
    a, b = SecdedRef(k), up.Code(k)
    rng = SplitMix64(seed + k)
    bad = tot = 0
    for _ in range(nvec):
        d = rand_bits(rng, k)
        w = a.encode(d)
        if w != b.encode(d):
            bad += 1
        tot += 1
        for wt in (0, 1, 2, 3, 4):
            e = _mask_of(rand_positions(rng, a.n, wt)) if wt else 0
            ra, rb = a.decode(w ^ e), b.decode(w ^ e)
            tot += 1
            if (ra[0], ra[1], ra[2]) != tuple(rb):
                bad += 1
    return {"k": k, "checks": tot, "mismatches": bad, "inv_this": a.inv, "inv_upstream": b.inv}


# ----------------------------------------------------------------------------------------------------------
# Bank testbench driver (items 3-6)
# ----------------------------------------------------------------------------------------------------------
def parse_lines(out: str) -> list:
    """Tagged ``TAG k=v k=v`` lines of the testbenches -> list of dicts (ints where possible; hex fields stay strings)."""
    rows = []
    for ln in out.splitlines():
        m = re.match(r"^([A-Z_0-9]+)\s+(.*)$", ln.strip())
        if not m or "=" not in m.group(2):
            continue
        d = {"_tag": m.group(1)}
        for kv in m.group(2).split():
            if "=" in kv:
                k, v = kv.split("=", 1)
                d[k] = int(v) if re.fullmatch(r"-?\d+", v) else v
        rows.append(d)
    return rows


def bank_exe(dw: int, ecc: int, rl: int, fi: int = 1, scrub_wait: int = 64, depth: int = 64, jobs: int = 2) -> str:
    gen = {"DW": dw, "ECC_EN": ecc, "READ_LATENCY": rl, "DEPTH": depth, "SCRUB_WAIT": scrub_wait, "FAULT_INJECT": fi}
    return build_tb("ecc_bank", "tb_sramlab_ecc_bank", ECC_RTL + [TB_BANK], gen, INCS, jobs)


def run_bank(dw: int, ecc: int, rl: int, args: list, fi: int = 1, scrub_wait: int = 64, depth: int = 64,
             jobs: int = 2) -> list:
    exe = bank_exe(dw, ecc, rl, fi, scrub_wait, depth, jobs)
    out = run_sim(exe, args, timeout=1800)
    rows = parse_lines(out)
    if not any(r["_tag"] == "DONE" for r in rows):
        raise RuntimeError("bank testbench did not finish:\n" + out[-1500:])
    bad = [r for r in rows if r["_tag"] == "ERROR"]
    if bad or "ERROR" in out:
        raise RuntimeError("bank testbench reported an error:\n" + out[-1500:])
    return rows


def _by(rows, tag_):
    return [r for r in rows if r["_tag"] == tag_]


def measure_latency_throughput(dw: int, ecc: int, rl: int, n_ops: int, fi: int = 1, jobs: int = 2) -> dict:
    rows = run_bank(dw, ecc, rl, ["+lat=1", f"+thr={n_ops}", "+rmw=1", "+seed=7"], fi=fi, jobs=jobs)
    cfg = _by(rows, "CFG")[0]
    return {"cfg": cfg, "lat": {r["op"]: r for r in _by(rows, "LAT")}, "thr": {r["kind"]: r for r in _by(rows, "THR")},
            "rmw": {r["_tag"]: r for r in rows if r["_tag"] in ("RMW1", "RMW2")}}


def hex_to_int(h) -> int:
    return int(str(h), 16)


# ---------------------------------------------------------------------------------------------------- items 3, 4
def latency_section(word_bits, rls=(1, 2), quick=False, n_ops=None, jobs=2, workers=3) -> dict:
    """Items 3 and 4: decoder latency and partial-write read-modify-write cost, ECC off vs on, per READ_LATENCY."""
    n_ops = n_ops or (200 if quick else 1000)
    dws = list(word_bits[:1]) if quick else list(word_bits)
    cases = [(dw, ecc, rl) for dw in dws for rl in rls for ecc in (0, 1)]
    res = dict(zip(cases, _parallel(lambda c: measure_latency_throughput(c[0], c[1], c[2], n_ops, jobs=jobs), cases, workers)))
    src = "rtl/third_party/memorycore_sram/rtl/sf_sram_bank.sv via rtl/tb/tb_sramlab_ecc_bank.sv (Verilator)"
    lat_out, thr_out = {}, {}
    for dw in dws:
        for rl in rls:
            off, on = res[(dw, 0, rl)], res[(dw, 1, rl)]
            key = f"DW{dw}_RL{rl}"
            L = {}
            for op in ("read", "write_full", "write_partial", "write_be0"):
                a, b = off["lat"][op]["cycles"], on["lat"][op]["cycles"]
                L[op] = {"ecc_off_cycles": tag(a, "rtl_simulated", src), "ecc_on_cycles": tag(b, "rtl_simulated", src),
                         "added_by_ecc_cycles": tag(b - a, "rtl_simulated", src)}
            L["documented_bank_latency_ecc_off"] = tag(rl, "analytical", "sf_sram_bank.sv header: BANK_LAT = READ_LATENCY + (ECC_EN ? 1 : 0)")
            L["documented_bank_latency_ecc_on"] = tag(rl + 1, "analytical", "sf_sram_bank.sv header")
            L["matches_documented"] = (all(L[o]["ecc_off_cycles"]["value"] == rl and L[o]["ecc_on_cycles"]["value"] == rl + 1
                                           for o in ("read", "write_full", "write_partial")))
            lat_out[key] = L
            T = {}
            for ecc, r in ((0, off), (1, on)):
                nm = "ecc_on" if ecc else "ecc_off"
                for kind, t in r["thr"].items():
                    n, c = t["n"], t["cycles"]
                    gap = (c - 1) / (n - 1)          # steady-state accept-to-accept interval (no start/stop edge effect)
                    T.setdefault(kind, {})[nm] = {
                        "ops": n, "cycles": tag(c, "rtl_simulated", src), "ops_per_cycle": tag(round(n / c, 4), "rtl_simulated", src),
                        "accept_interval_cycles": tag(round(gap, 4), "rtl_simulated", src),
                        "steady_ops_per_cycle": tag(round(1 / gap, 4), "rtl_simulated", src),
                        "stall_cycles": tag(t["stall"], "rtl_simulated", src),
                        "stall_cycles_per_op": tag(round(t["stall"] / n, 4), "rtl_simulated", src),
                        "readback_mismatches": t["sweep_bad"]}
            for ecc, nm in ((0, "ecc_off"), (1, "ecc_on")):
                full = T["wr_full"][nm]["steady_ops_per_cycle"]["value"]
                part = T["wr_part"][nm]["steady_ops_per_cycle"]["value"]
                T["wr_part"][nm]["relative_to_full_write"] = tag(round(part / full, 4), "rtl_simulated", src)
            thr_out[key] = T
    cfg0 = res[(dws[0], 1, rls[0])]
    return {"latency": lat_out, "partial_write": thr_out, "n_ops_per_stream": n_ops,
            "rmw_semantics": {f"DW{dw}_RL{rl}": res[(dw, 1, rl)]["rmw"] for dw in dws for rl in rls},
            "rtl_cfg_example": cfg0["cfg"], "_raw": res}


# ---------------------------------------------------------------------------------------------------- item 5
def scrub_section(dw: int, quick=False, jobs=2, workers=3) -> dict:
    """Item 5: scrubbing bandwidth.  RTL scrubber of sf_sram_bank: one step per SCRUB_WAIT cycles, started only in a
    cycle in which no request is presented; a step reads one row (round robin) and writes it back corrected."""
    T = 2500 if quick else 6000
    points = [(1, 64)] if quick else [(1, 64), (1, 8), (2, 64), (2, 8)]
    src = "sf_sram_bank.sv scrubber via rtl/tb/tb_sramlab_ecc_bank.sv (Verilator)"
    runs = _parallel(lambda p: run_bank(dw, 1, p[0], [f"+scrub={T}", "+seed=11"], scrub_wait=p[1], jobs=jobs), points, workers)
    out = {}
    for (rl, wait), rows in zip(points, runs):
        idle = _by(rows, "SCRUB_IDLE")[0]
        steps = idle["steps"]
        period = (idle["last_step_cyc"] - idle["first_step_cyc"]) / (idle["window_steps"] - 1)   # step-entry to step-entry
        step_arr = (idle["scrub_cycles"] + idle["go_cycles"]) / steps
        step_blk = idle["scrub_cycles"] / steps
        loads = {}
        for r in _by(rows, "SCRUB_LOAD"):
            loads.setdefault(r["p"], {})[("on" if r["scrub"] else "off")] = r
        load_rows = []
        for p, d in sorted(loads.items()):
            off, on = d["off"], d["on"]
            load_rows.append({
                "offered_requests_per_256_cycles": p,
                "accepted_without_scrub": tag(off["accepted"], "rtl_simulated", src),
                "accepted_with_scrub": tag(on["accepted"], "rtl_simulated", src),
                "throughput_loss_pct": tag(round(100.0 * (off["accepted"] - on["accepted"]) / off["accepted"], 3) if off["accepted"] else None,
                                           "rtl_simulated", src),
                "scrub_steps": tag(on["steps"], "rtl_simulated", src),
                "cycles_requests_stalled_by_scrub": tag(on["blocked_by_scrub"], "rtl_simulated", src),
                "max_request_wait_cycles_with_scrub": tag(on["max_wait"], "rtl_simulated", src),
                "cycles": on["T"]})
        key = f"RL{rl}_SCRUB_WAIT{wait}"
        out[key] = {
            "read_latency": rl, "scrub_wait": wait, "idle_window_cycles": idle["T"], "steps_in_window": steps,
            "cycles_per_scrubbed_word_period": tag(round(period, 3), "rtl_simulated", src),
            "array_cycles_per_scrub_step": tag(step_arr, "rtl_simulated", src),
            "bank_blocked_cycles_per_scrub_step": tag(step_blk, "rtl_simulated", src),
            "bank_bandwidth_fraction_consumed": tag(round(step_arr / period, 5), "rtl_simulated", src,
                                                   note="array-occupied cycles per step / step period, idle bus"),
            "bank_bandwidth_pct_consumed": tag(round(100.0 * step_arr / period, 3), "rtl_simulated", src),
            "request_blocking_fraction_worst_case": tag(round(step_blk / period, 5), "rtl_simulated", src,
                                                       note="only a request that is presented DURING a step waits; a step is never started while one is presented"),
            "full_bank_scrub_time_cycles_per_1024_rows": tag(round(period * 1024), "analytical", "measured period x 1024 (linear extrapolation in depth)"),
            "under_load": load_rows,
            "repair_test": {"scrub_fix": _by(rows, "SCRUB_FIX")[0], "readback": _by(rows, "SCRUB_READBACK")[0]},
        }
    return out


# ---------------------------------------------------------------------------------------------------- item 6
def fault_vectors(ref: SecdedRef, rng: SplitMix64, depth: int, quick: bool) -> list:
    """(row, data, mask, weight) for the bank-level fault-injection campaign."""
    n = ref.n
    vs = []
    for b in range(n):                                                    # every stored bit position, weight 1
        vs.append((rng.randbelow(depth), rand_bits(rng, ref.k), 1 << b, 1))
    npair, ntrip = (200, 400) if quick else (1500, 4000)
    for _ in range(npair):
        vs.append((rng.randbelow(depth), rand_bits(rng, ref.k), _mask_of(rand_positions(rng, n, 2)), 2))
    for _ in range(ntrip):
        vs.append((rng.randbelow(depth), rand_bits(rng, ref.k), _mask_of(rand_positions(rng, n, 3)), 3))
    for _ in range(20):
        vs.append((rng.randbelow(depth), rand_bits(rng, ref.k), 0, 0))
    return vs


def fault_section(k: int, quick=False, seed=0xF00D, jobs=2, ref: SecdedRef | None = None) -> dict:
    """Item 6: inject 1/2/3-bit errors into the STORED word of the real ECC bank and measure what is reported."""
    ref = ref or SecdedRef(k)
    depth = 64
    rng = SplitMix64(seed ^ (k * 0x9E3779B97F4A7C15 & _M64))
    vecs = fault_vectors(ref, rng, depth, quick)
    wd = tempfile.mkdtemp(prefix="sramlab_eccf_")
    vf = os.path.join(wd, "f.vec")
    with open(vf, "w") as f:
        for row, d, m, _ in vecs:
            f.write(f"{row} {_hexw(d, k)} {_hexw(m, ref.n)}\n")
    rows = run_bank(k, 1, 1, [f"+fvec={vf}", "+rmw=1", "+seed=5"], jobs=jobs)
    shutil.rmtree(wd, ignore_errors=True)
    fr = _by(rows, "F")
    if len(fr) != len(vecs):
        raise RuntimeError(f"fault campaign: {len(fr)} results for {len(vecs)} vectors")
    src = "sf_sram_bank.sv (ECC_EN=1, FAULT_INJECT=1 seu hook) via rtl/tb/tb_sramlab_ecc_bank.sv"
    per_w = {}
    mism = []
    for (row, d, m, w), r in zip(vecs, fr):
        stored = hex_to_int(r["stored"])
        exp_stored = ref.encode(d) ^ m
        cls, rdata_e, _, ce_e, ue_e, _ = ref.decode(exp_stored)
        rdata = hex_to_int(r["rdata"])
        ok = (stored == exp_stored and rdata == rdata_e and r["status"] == (ST_ECC_UE if ue_e else ST_OK) and r["ce"] == ce_e
              and r["ce_cnt"] == ce_e and r["ue_cnt"] == ue_e and (not ce_e or r["first_ce"] == row) and (not ue_e or r["first_ue"] == row))
        if not ok and len(mism) < 5:
            mism.append({"row": row, "weight": w, "mask": hex(m), "rtl": {x: r[x] for x in ("status", "ce", "ce_cnt", "ue_cnt")},
                         "ref": {"class": CLASS_NAMES[cls], "ce": ce_e, "ue": ue_e}})
        s = per_w.setdefault(w, {"injected": 0, "reference_mismatches": 0, "corrected_data_ok": 0, "flagged_uncorrectable": 0,
                                 "silently_miscorrected": 0, "clean": 0, "ce_counter_increments": 0, "ue_counter_increments": 0})
        s["injected"] += 1
        s["reference_mismatches"] += 0 if ok else 1
        s["ce_counter_increments"] += r["ce_cnt"]
        s["ue_counter_increments"] += r["ue_cnt"]
        if r["status"] == ST_ECC_UE:
            s["flagged_uncorrectable"] += 1
        elif rdata == d:
            s["corrected_data_ok" if m else "clean"] += 1
        else:
            s["silently_miscorrected"] += 1
    out = {}
    for w in sorted(per_w):
        s = per_w[w]
        n = s["injected"]
        out[f"weight_{w}"] = {k_: (tag(v, "rtl_simulated", src) if k_ != "reference_mismatches" else v) for k_, v in s.items()}
        out[f"weight_{w}"]["silent_miscorrection_rate"] = tag(round(s["silently_miscorrected"] / n, 4), "rtl_simulated", src,
                                                              samples=n)
        out[f"weight_{w}"]["detected_rate"] = tag(round(s["flagged_uncorrectable"] / n, 4), "rtl_simulated", src, samples=n)
    rmw = {r["_tag"]: r for r in rows if r["_tag"] in ("RMW1", "RMW2")}
    r1, r2 = rmw["RMW1"], rmw["RMW2"]
    d0, d1 = hex_to_int(r1["d0"]), hex_to_int(r1["d1"])
    be = hex_to_int(r1["be"])
    bm = sum(0xFF << (8 * i) for i in range(k // 8) if (be >> i) & 1)
    merged = (d0 & ~bm & ref.dmask) | (d1 & bm)
    rmw_out = {
        "partial_write_on_single_bit_error_line": {
            "write_status_ok": r1["w_status"] == ST_OK, "write_reports_ce": r1["w_ce"] == 1, "ce_counter": r1["ce_cnt"],
            "ue_counter": r1["ue_cnt"], "line_clean_afterwards": r1["ce_cnt_after_read"] == 1 and r1["rd_ce"] == 0,
            "data_is_merge_of_corrected_old_and_new": hex_to_int(r1["rd"]) == merged,
            "stored_word_equals_reference_encoding_of_merge": hex_to_int(r1["stored_after"]) == ref.encode(merged)},
        "partial_write_on_double_bit_error_line": {
            "write_status_is_ecc_ue": r2["w_status"] == ST_ECC_UE, "ue_counter": r2["ue_cnt"], "ce_counter": r2["ce_cnt"],
            "write_aborted_line_left_as_found": r2["stored_before"] == r2["stored_after"],
            "full_write_repairs_line": hex_to_int(r2["repair_rd"]) == hex_to_int(r2["d1"]) and r2["repair_status"] == ST_OK},
        "provenance": "rtl_simulated", "source": src}
    return {"k": k, "n_stored_bits": ref.n, "vectors": len(vecs), "reference_mismatches": sum(v["reference_mismatches"] for v in per_w.values()),
            "first_mismatches": mism, "by_weight": out, "rmw_on_errors": rmw_out, "seed": seed, "quick": quick}


# ---------------------------------------------------------------------------------------------------- item 2
# MemoryCore's own committed Yosys 0.33 generic-gate counts (abc -fast), for comparison only (K = 128, never re-derived here)
MC_COMMITTED_SYNTH = {"sf_ecc_enc K=128": 314, "sf_ecc_dec K=128": 1389}
YOSYS_FLOW = ("read_verilog -sv; chparam; hierarchy -check; synth -flatten -run :fine; opt -fast -full; techmap; opt -fast; "
              "opt_clean; check; stat -json   (NO abc: see ecc.md)")


def _yosys_script(top: str, params: dict, files: list, incs: list) -> str:
    inc = " ".join(f"-I {i}" for i in incs)
    ch = "; ".join(f"chparam -set {k} {v} {top}" for k, v in params.items())
    parts = [f"read_verilog -sv {inc} {' '.join(files)}"]
    if ch:
        parts.append(ch)
    parts += [f"hierarchy -check -top {top}", "synth -flatten -run :fine", "opt -fast -full", "techmap", "opt -fast",
              "opt_clean", "check", "tee -q -o stat.json stat -json"]
    return "; ".join(parts)


def _stage_rtl(wd: str, files: list) -> tuple[list, list]:
    """Copy RTL sources and include directories into the Yosys work directory and return RELATIVE paths.
    yowasp-yosys is a WASI build that cannot open arbitrary absolute paths (e.g. under /tmp), so a package unzipped
    outside the user's home would otherwise silently lose every Yosys result."""
    rel_files = []
    for i, f in enumerate(files):
        name = f"src{i}_{os.path.basename(f)}"
        shutil.copy(f, os.path.join(wd, name))
        rel_files.append(name)
    rel_incs = []
    for j, d in enumerate(INCS):
        if not os.path.isdir(d):
            continue
        dd = os.path.join(wd, f"inc{j}")
        os.makedirs(dd, exist_ok=True)
        for fn in os.listdir(d):
            if fn.endswith((".svh", ".vh", ".sv", ".v")):
                shutil.copy(os.path.join(d, fn), os.path.join(dd, fn))
        rel_incs.append(f"inc{j}")
    return rel_files, rel_incs


def yosys_generic(top: str, params: dict, files: list, mem_width_bits: int | None = None, depth: int | None = None) -> dict:
    """Yosys GENERIC-gate synthesis of one module (no liberty, no ABC, array left as a $mem cell).  Cached."""
    y = tools.yosys()
    if y is None:
        return unavailable("Yosys is not installed (`pip install yowasp-yosys`)")
    script = _yosys_script(top, params, [f"src{i}_{os.path.basename(f)}" for i, f in enumerate(files)],
                           [f"inc{j}" for j, d in enumerate(INCS) if os.path.isdir(d)])
    key = hashlib.sha256(json.dumps([script, _file_hash(files), y["version"], "v3"]).encode()).hexdigest()[:16]
    cache = os.path.join(BUILD_ROOT, f"ys_{key}.json")
    st = None
    if os.path.exists(cache):
        try:
            with open(cache) as f:
                st = json.load(f)
        except Exception:
            st = None
    secs = None
    if st is None:
        wd = tempfile.mkdtemp(prefix="sramlab_ys_")
        _stage_rtl(wd, files)
        t0 = time.time()
        r = subprocess.run([y["exe"], "-q", "-p", script], capture_output=True, text=True, cwd=wd)
        secs = round(time.time() - t0, 1)
        sj = os.path.join(wd, "stat.json")
        if r.returncode != 0 or not os.path.exists(sj):
            shutil.rmtree(wd, ignore_errors=True)
            return unavailable(f"Yosys run failed for {top} {params}: " + (r.stdout + r.stderr)[-300:])
        with open(sj) as f:
            st = json.load(f)["design"]
        shutil.rmtree(wd, ignore_errors=True)
        os.makedirs(BUILD_ROOT, exist_ok=True)
        with open(cache, "w") as f:
            json.dump(st, f)
    types = {k: v for k, v in st["num_cells_by_type"].items() if k != "$scopeinfo"}
    ffs = sum(v for k, v in types.items() if "DFF" in k or "SDFF" in k)
    lat = sum(v for k, v in types.items() if "LATCH" in k)
    mem = sum(v for k, v in types.items() if k.startswith("$mem"))
    logic = sum(v for k, v in types.items() if "DFF" not in k and "LATCH" not in k and not k.startswith("$mem"))
    d = tag({"total_cells": ffs + lat + logic, "logic_cells": logic, "flip_flops": ffs, "latches": lat, "mem_cells": mem,
             "cells_by_type": types}, "synthesized", f"yosys {y['version']} {YOSYS_FLOW}",
            note="generic gate counts (Yosys internal $_*_ cells): NOT area, NOT timing, NOT power; the SRAM array is left as a $mem cell",
            params=params, top=top, seconds=secs)
    if mem_width_bits is not None and depth is not None:
        d["memory_bits"] = tag(mem_width_bits * depth, "analytical", "DEPTH x stored word width (array is not synthesised to gates)")
    return d


def synth_section(word_bits, quick=False, workers=4) -> dict:
    """Item 2: logic cost of the ECC datapath (encoder, decoder) and of the bank with ECC off / on / on+scrub."""
    ks = list(word_bits[:1]) if quick else list(word_bits)
    depth = 256
    jobs = []
    for k in ks:
        r = SecdedRef(k).r
        jobs.append((f"sf_ecc_enc K={k}", "sf_ecc_enc", {"K": k}, CODEC_RTL, None))
        jobs.append((f"sf_ecc_dec K={k}", "sf_ecc_dec", {"K": k}, CODEC_RTL, None))
        for nm, ecc_en, scrub in (("bank_ecc_off", 0, 0), ("bank_ecc_on", 1, 0), ("bank_ecc_on_scrub", 1, 1)):
            if quick and scrub:
                continue
            jobs.append((f"{nm} DW={k}", "sf_sram_bank", {"DEPTH": depth, "DW": k, "ECC_EN": ecc_en, "SCRUB_EN": scrub, "TAG_W": 5},
                         ECC_RTL, (k + r + 1) if ecc_en else k))
    res = _parallel(lambda j: yosys_generic(j[1], j[2], j[3], j[4], depth if j[4] else None), jobs, workers)
    out = {"flow": YOSYS_FLOW, "bank_depth_used_for_synthesis": depth, "modules": {}, "deltas": {},
           "memorycore_committed_for_comparison": {}}
    for j, r in zip(jobs, res):
        out["modules"][j[0]] = r
    for k in ks:
        off, on = out["modules"].get(f"bank_ecc_off DW={k}"), out["modules"].get(f"bank_ecc_on DW={k}")
        if off and on and off["provenance"] == "synthesized" and on["provenance"] == "synthesized":
            a, b = off["value"], on["value"]
            out["deltas"][f"DW={k}"] = {
                "added_total_cells": tag(b["total_cells"] - a["total_cells"], "synthesized", "bank_ecc_on - bank_ecc_off (generic gates)"),
                "added_flip_flops": tag(b["flip_flops"] - a["flip_flops"], "synthesized", "bank_ecc_on - bank_ecc_off"),
                "total_cells_ratio": tag(round(b["total_cells"] / a["total_cells"], 3), "synthesized", "bank_ecc_on / bank_ecc_off"),
                "note": "ECC bank = 3 encoders (new data, zero line, merged RMW data) + 1 decoder + RMW/init/scrub FSM + CE/UE counters + registered response"}
    for nm, v in MC_COMMITTED_SYNTH.items():
        ours = out["modules"].get(nm)
        out["memorycore_committed_for_comparison"][nm] = {
            "memorycore_report_cells": tag(v, "synthesized", "MemoryCore reports/synthesis.md (Yosys 0.33, abc -fast); imported, not re-run",
                                           imported=True),
            "this_run_cells": (tag(ours["value"]["total_cells"], "synthesized", ours["source"]) if ours and ours["provenance"] == "synthesized" else None),
            "why_different": "this environment's Yosys (yowasp wasm 0.71) cannot execute its ABC pass, so no logic optimisation/sharing is "
                             "applied after techmap; the committed numbers are after `abc -fast`"}
    return out


# ---------------------------------------------------------------------------------------------------- storage overhead
def storage_section(word_bits, codec_results: dict, bank_cfgs: dict) -> dict:
    """Item 1 (analytical, cross-checked against the widths the ELABORATED RTL reports)."""
    out = {}
    for k in word_bits:
        ref = SecdedRef(k)
        n_codec = codec_results.get(k, {}).get("n_rtl")
        n_bank = (bank_cfgs.get(k) or {}).get("STORE_W_RTL")
        r_bank = (bank_cfgs.get(k) or {}).get("R_RTL")
        formula = "R = $clog2(DW + $clog2(DW+1) + 1); STORE_W = DW + R + 1 (sf_sram_bank.sv / sf_ecc_enc.sv parameters)"
        out[f"DW{k}"] = {
            "data_bits": k,
            "ecc_off_stored_bits_per_word": tag(k, "analytical", "ECC_EN = 0: STORE_W = DW"),
            "ecc_on_stored_bits_per_word": tag(ref.n, "analytical", formula, rtl_elaborated_bank_store_w=n_bank,
                                                rtl_elaborated_codec_width=n_codec,
                                                agrees_with_rtl=(n_bank in (None, ref.n)) and (n_codec in (None, ref.n))),
            "check_bits_hamming": tag(ref.r, "analytical", formula, rtl_elaborated=r_bank),
            "overall_parity_bits": tag(1, "analytical", formula),
            "extra_bits_per_word": tag(ref.n - k, "analytical", formula),
            "storage_overhead_pct": tag(round(100.0 * (ref.n - k) / k, 3), "analytical", "(STORE_W - DW) / DW"),
            "ratio_text": f"{ref.n}/{k}",
        }
    return out


def _flatten(prefix: str, obj, rows: list):
    if isinstance(obj, dict):
        if "provenance" in obj and "value" in obj:
            v = obj["value"]
            base = {"provenance": obj["provenance"], "source": obj.get("source", ""), "note": obj.get("note", obj.get("reason", ""))}
            if isinstance(v, dict):
                for kk, vv in v.items():
                    if isinstance(vv, dict):
                        for k3, v3 in vv.items():
                            rows.append({"metric": f"{prefix}.{kk}.{k3}", "value": v3, **base})
                    else:
                        rows.append({"metric": f"{prefix}.{kk}", "value": vv, **base})
            else:
                rows.append({"metric": prefix, "value": v, **base})
            return
        for k, v in obj.items():
            if k.startswith("_"):
                continue
            _flatten(f"{prefix}.{k}" if prefix else str(k), v, rows)
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            _flatten(f"{prefix}[{i}]", v, rows)


def to_rows(result: dict, sections=("storage_overhead", "logic_cost", "latency", "partial_write", "scrub", "fault_reporting",
                                    "reference_crosscheck")) -> list:
    rows = []
    for s in sections:
        sub = []
        _flatten(s, result.get(s, {}), sub)
        rows += sub
    return rows


def write_outputs(result: dict, outdir: str, stem: str, sections) -> dict:
    os.makedirs(outdir, exist_ok=True)
    jp, cp = os.path.join(outdir, f"{stem}.json"), os.path.join(outdir, f"{stem}.csv")
    with open(jp, "w") as f:
        json.dump(result, f, indent=1, default=str)
    rows = to_rows(result, sections)
    with open(cp, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["metric", "value", "provenance", "source", "note"])
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in w.fieldnames})
    return {"json": jp, "csv": cp, "csv_rows": len(rows)}


def _guard(fn, what: str):
    try:
        return fn()
    except Exception as e:      # a failed piece is reported as unavailable WITH its reason, never silently dropped
        return unavailable(f"{what} failed: {type(e).__name__}: {str(e)[:400]}")


def fi_timing_check(dw: int, n_ops: int, jobs: int = 2) -> dict:
    """The performance runs use a bank with the simulation-only fault hook compiled in (FAULT_INJECT=1, inputs idle);
    prove it does not change a single timing number by re-measuring on the FAULT_INJECT=0 (synthesizable) build."""
    a = measure_latency_throughput(dw, 1, 1, n_ops, fi=1, jobs=jobs)
    b = measure_latency_throughput(dw, 1, 1, n_ops, fi=0, jobs=jobs)
    same = (all(a["lat"][k]["cycles"] == b["lat"][k]["cycles"] for k in a["lat"]) and
            all(a["thr"][k]["cycles"] == b["thr"][k]["cycles"] and a["thr"][k]["stall"] == b["thr"][k]["stall"] for k in a["thr"]))
    return tag(bool(same), "rtl_simulated", "FAULT_INJECT=1 vs FAULT_INJECT=0 builds, identical latency + throughput streams",
               dw=dw, n_ops=n_ops)


MANDATORY_NOTES = [
    "Every RTL number comes from a Verilator run executed by this module; every synthesis number from a Yosys run executed by this module.",
    "Nothing here is 'measured': no silicon or FPGA measurement exists for any SilicaFlux block.",
    "Yosys numbers are GENERIC GATE counts (no liberty): they are not area, not timing, not power.  This environment's Yosys "
    "(yowasp wasm) cannot run its ABC pass, so the counts are before logic optimisation/sharing.",
    "Fault injection puts bit flips into the STORED word of the RTL; it says what the logic does with a 1/2/3-bit error, not how "
    "often such errors occur (no soft-error or hard-fault rate data exists here).",
    "SECDED does not guarantee detection of 3-bit errors: most random 3-bit patterns are silently miscorrected (counted as a CE).",
]


def run_ecc_study(word_bits=(32, 64, 128), outdir: str | None = None, quick: bool = False, seed: int = 0xEC0DEC,
                  workers: int = 3, progress=None) -> dict:
    """Run the full ECC cost study.  Returns a JSON-serialisable dict; writes ``<outdir>/ecc_study.json`` and
    ``ecc_study.csv`` when ``outdir`` is given.  ``quick=True`` limits the per-word-width sweeps to the first word width,
    skips the scrub-parameter sweep and uses fewer vectors (a few minutes from a cold build cache, ~1 min warm)."""
    t_start = time.time()
    word_bits = [int(k) for k in word_bits]
    for k in word_bits:
        if k % 8:
            raise ValueError("word_bits must be multiples of 8 (byte write enables)")
    log = progress or (lambda m: None)
    v = verilator_info()
    res = {"study": "ecc", "schema": 1, "quick": bool(quick), "word_bits": word_bits, "seed": seed,
           "environment": {**tools.environment(), "verilator_detail": v}, "notes": list(MANDATORY_NOTES)}
    if v is None:
        res["error"] = unavailable("Verilator is not installed: every RTL-derived item is unavailable")
    # ---- synthesis runs in the background (Yosys wasm is single threaded and slow) while the RTL runs proceed
    with ThreadPoolExecutor(1) as bg:
        fut = bg.submit(lambda: _guard(lambda: synth_section(word_bits, quick=quick, workers=2), "Yosys synthesis"))
        if v is not None:
            log("codec cross-check")
            cc = {}
            for k in word_bits:
                cc[k] = _guard(lambda k=k: crosscheck_codec(k, quick=quick, seed=seed), f"codec cross-check K={k}")
            ok_cc = {k: x for k, x in cc.items() if isinstance(x, dict) and "mismatches" in x}
            exact = {}
            for k in word_bits:
                r_ = SecdedRef(k)
                exact[k] = {f"weight_{w}": exact_weight_stats(r_, w) for w in (1, 2, 3)}
            res["reference_crosscheck"] = {
                "reference": "sramlab.studies.ecc.SecdedRef (independent Python SECDED written from the documented layout)",
                "per_word_width": {f"DW{k}": ({
                    "vectors_compared": tag(x["vectors"], "rtl_simulated", "tb_sramlab_ecc_codec.sv vs SecdedRef"),
                    "mismatches": tag(x["mismatches"], "rtl_simulated", "RTL sf_ecc_enc/sf_ecc_dec vs independent reference"),
                    "encoder_mismatches": x["encoder_mismatches"], "decoder_mismatches": x["decoder_mismatches"],
                    "inversion_mask_reference": hex(x["inv_ref"]), "raw_words_rtl": x["raw_words_rtl"],
                    "rtl_outcomes_by_weight": x["rtl_outcomes_by_weight"], "first_mismatches": x["first_mismatches"],
                    "vs_memorycore_python_reference": _guard(lambda k=k: upstream_ref_agreement(k), "upstream reference comparison"),
                } if isinstance(x, dict) and "mismatches" in x else x) for k, x in cc.items()},
                "exact_error_pattern_statistics_reference": {
                    f"DW{k}": {w: {**st, "provenance": "simulated",
                                   "source": "exhaustive enumeration of every error pattern through the independent reference decoder"}
                               for w, st in d.items()} for k, d in exact.items()},
            }
            log("latency / partial write")
            lp = _guard(lambda: latency_section(word_bits, quick=quick, jobs=2, workers=workers), "latency/throughput")
            if isinstance(lp, dict) and "latency" in lp:
                lp.pop("_raw", None)
                res["latency"] = {"by_config": lp["latency"], "provenance": "rtl_simulated",
                                  "definition": "cycles from the edge a request is accepted to the cycle rsp_valid is visible; "
                                                "decoder latency = ecc_on - ecc_off"}
                res["partial_write"] = {"by_config": lp["partial_write"], "ops_per_stream": lp["n_ops_per_stream"],
                                        "rmw_semantics_raw": lp["rmw_semantics"]}
            else:
                res["latency"] = lp
                res["partial_write"] = lp
            res["fault_injection_hook_does_not_change_timing"] = _guard(
                lambda: fi_timing_check(word_bits[0], 200, jobs=2), "FAULT_INJECT timing check")
            log("scrub")
            res["scrub"] = _guard(lambda: scrub_section(word_bits[0], quick=quick, jobs=2, workers=workers), "scrub")
            log("fault reporting")
            fr = {}
            for k in word_bits:
                fr[f"DW{k}"] = _guard(lambda k=k: fault_section(k, quick=quick, seed=seed ^ 0xF00D), f"fault injection K={k}")
            res["fault_reporting"] = {
                "what": "bit flips XORed into the STORED word of sf_sram_bank (SEU hook), then a functional read through the decoder",
                "by_word_width": fr,
                "exact_3bit_statistics": {f"DW{k}": exact[k]["weight_3"] for k in word_bits},
                "memorycore_ecc_md_reported": {"triple_errors": 300, "flagged_uncorrectable": 57, "silently_miscorrected": 243,
                                               "note": "MemoryCore docs/ECC.md, K=128, 300 deterministic random triples; imported, not re-run"},
            }
            bank_cfgs = {}
            for k in word_bits:
                try:
                    bank_cfgs[k] = _by(run_bank(k, 1, 1, [], jobs=2), "CFG")[0]
                except Exception:
                    bank_cfgs[k] = None
            res["storage_overhead"] = storage_section(word_bits, ok_cc, bank_cfgs)
            res["simulator_version_reported"] = dict(SIM_VERSION)
        else:
            res["storage_overhead"] = storage_section(word_bits, {}, {})
        log("synthesis (wait)")
        res["logic_cost"] = fut.result()
    res["headline"] = _guard(lambda: _headline(res), "headline")
    res["unavailable_items"] = [p for p, x in _walk_unavailable(res)]
    res["wall_seconds"] = round(time.time() - t_start, 1)
    if outdir:
        res["files"] = write_outputs(res, outdir, "ecc_study", ("storage_overhead", "logic_cost", "latency", "partial_write", "scrub",
                                                                 "fault_reporting", "reference_crosscheck"))
        with open(res["files"]["json"], "w") as f:       # rewrite so the JSON records its own file names
            json.dump(res, f, indent=1, default=str)
    return res


def _headline(res: dict) -> dict:
    """Plain-number digest of the study (every value is also present, with provenance, in the sections it comes from)."""
    from ..provenance import strip
    h = {}
    for k in res["word_bits"]:
        d = {}
        so = res.get("storage_overhead", {}).get(f"DW{k}")
        if so:
            d["stored_bits_ecc_on"] = strip(so["ecc_on_stored_bits_per_word"])
            d["storage_overhead_pct"] = strip(so["storage_overhead_pct"])
        lm = res.get("logic_cost", {}).get("modules", {}) if isinstance(res.get("logic_cost"), dict) else {}
        for nm, key in ((f"sf_ecc_enc K={k}", "enc_generic_cells"), (f"sf_ecc_dec K={k}", "dec_generic_cells"),
                        (f"bank_ecc_off DW={k}", "bank_cells_ecc_off"), (f"bank_ecc_on DW={k}", "bank_cells_ecc_on")):
            if nm in lm and lm[nm].get("provenance") == "synthesized":
                d[key] = lm[nm]["value"]["total_cells"]
        lat = res.get("latency", {}).get("by_config", {}) if isinstance(res.get("latency"), dict) else {}
        for rl in (1, 2):
            L = lat.get(f"DW{k}_RL{rl}")
            if L:
                d[f"decoder_added_cycles_RL{rl}"] = strip(L["read"]["added_by_ecc_cycles"])
            T = (res.get("partial_write", {}).get("by_config", {}) or {}).get(f"DW{k}_RL{rl}")
            if T:
                d[f"partial_write_accept_interval_RL{rl}_ecc_on"] = strip(T["wr_part"]["ecc_on"]["accept_interval_cycles"])
        fw = (res.get("fault_reporting", {}).get("by_word_width", {}) or {}).get(f"DW{k}")
        if isinstance(fw, dict) and "by_weight" in fw:
            d["single_bit_corrected"] = f"{strip(fw['by_weight']['weight_1']['corrected_data_ok'])}/{strip(fw['by_weight']['weight_1']['injected'])}"
            d["double_bit_detected"] = f"{strip(fw['by_weight']['weight_2']['flagged_uncorrectable'])}/{strip(fw['by_weight']['weight_2']['injected'])}"
            d["triple_bit_silently_miscorrected_rate"] = strip(fw["by_weight"]["weight_3"]["silent_miscorrection_rate"])
        cx = res.get("reference_crosscheck", {}).get("per_word_width", {}).get(f"DW{k}")
        if isinstance(cx, dict) and "mismatches" in cx:
            d["rtl_vs_reference_vectors"] = strip(cx["vectors_compared"])
            d["rtl_vs_reference_mismatches"] = strip(cx["mismatches"])
        h[f"DW{k}"] = d
    return h


def _walk_unavailable(obj, path=""):
    if isinstance(obj, dict):
        if obj.get("provenance") == "unavailable":
            yield path, obj.get("reason")
            return
        for k, v in obj.items():
            yield from _walk_unavailable(v, f"{path}.{k}" if path else str(k))
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            yield from _walk_unavailable(v, f"{path}[{i}]")
