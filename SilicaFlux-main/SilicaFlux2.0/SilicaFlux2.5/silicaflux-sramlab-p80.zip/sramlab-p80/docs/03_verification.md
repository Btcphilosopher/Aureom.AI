# 03 — Verification

| check | method | result |
|---|---|---|
| **Simulator vs RTL consistency** | `sramlab rtlcheck`: identical per-master scripts and response back-pressure replayed in the Python model and in Verilator on `sf_sram_subsystem` (with the RTL's embedded `SFC_ASSERT` checkers enabled). Compared: per-cycle `req_ready`, `rsp_valid/ready`, bank issue mask, `idle`, every response (id, type, status, read data) and **all 112 hardware performance counters**, plus the RTL's derived configuration (`UNIFORM_EFF`, `BANK_OUT_EFF`, latency extremes) | **253/253 cases identical** — 23 parameter sets × 11 workloads (2–16 banks, 1–16 masters, 8–128-bit words, latencies 1–4 incl. non-uniform, low/high interleave, non-power-of-two depth, priority arbitration, MASK_MODE aligned, tiny ID space, forced bank-lock) |
| error / flush paths | seeded injection of misaligned, out-of-range, zero-strobe and poisoned requests; `flush` pulses | identical, incl. `ALIGN/RANGE/MASK/POISON/ID/CANCEL` statuses |
| **Negative control** | the comparison is re-run against 4 deliberately broken models (fixed-priority arbiter, bank-lock dropped, latency+1, mis-counted conflicts) | **4/4 detected** (the counter-only fault leaves the trace identical and is caught by the counters) |
| Counter accuracy | RTL counters = model counters in every case above (31,768 counter values compared); documented RTL figures (0.50 / 1.00 / 2.00 / ~3.99 txn/cycle, `L+1` latency, `MAX_OUT/(L+1)` credit limit, `1/(HP_LIMIT+1)` LOW-class floor, bank-lock cost) reproduced by `tests/test_controller.py` independently of the RTL runs | pass |
| Data integrity | a *flat* byte-addressed oracle replays accepted requests in accept order and checks every read (knows nothing about banks, so mapping/aliasing bugs show) | 0 errors; the oracle is itself shown able to fail |
| Workload generation | determinism by seed, legality (aligned, in-range, non-zero strobes), master-stream independence, pattern semantics (stride, single-bank contention), alignment arithmetic | `tests/test_workloads_stats.py` |
| Configuration validity | 15 illegal configurations rejected with the RTL-matching reason; all problems reported at once | `tests/test_config.py` |
| Statistical calculations | t quantiles, CI hand-computed, CI coverage ≈ nominal over 400 trials, percentile/Spearman/elasticity/Pareto checks | `tests/test_workloads_stats.py` |
| Vector arithmetic vs RTL | alignment word counts and bank-slot cycle model vs the imported VectorScratch RTL bench | **76/76 rows cycle-exact**, 76/76 word counts; corrupted input is detected |
| Reproducibility | identical result hashes on re-run; different seed → different hash | `sramlab verify-repro`, `tests/test_studies_cli.py` |

Two problems were found *by* this verification and fixed (kept as regression tests): the 64-bit `BANK_LATS` parameter was truncated to 32 bits by Verilator's `-G` parser
(zeroing the latencies of banks 8–15 and silently disabling the RTL's automatic uniform-latency detection — surfaced by the 16-bank cases, fixed by passing a sized hex literal and by
having the testbench print the RTL's *effective* configuration, which the comparator now requires to match the model), and a build-cache key that ignored the exact `-G` strings.

**Not covered by the RTL comparison** (stated, not hidden): `src_en` / source-ID mismatch (`SFC_ST_SRC`) and bank-reported errors (`SFC_ST_BANK`, unreachable with `sf_sram_core`); multi-cycle masters that withdraw requests
(forbidden by SFB2 R2); `PERF` counter wrap at 2³².
