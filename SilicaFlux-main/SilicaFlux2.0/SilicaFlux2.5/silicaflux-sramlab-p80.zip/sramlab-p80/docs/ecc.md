# ECC cost study (brief section 10)

`sramlab.studies.ecc.run_ecc_study(word_bits=(32, 64, 128), outdir=None, quick=False)` compares **ECC disabled vs SECDED** on the real
MemoryCore RTL (`rtl/third_party/memorycore_sram`: `sf_sram_bank` + `sf_ecc_enc/dec`, vendored byte-identical, `SHA256SUMS` + `PROVENANCE.md`).
Every number carries a provenance label (`analytical`, `synthesized`, `rtl_simulated`, `unavailable`; **nothing is `measured`** - no silicon / FPGA
data exists) and names its source.  Results are written to `<outdir>/ecc_study.json` and `ecc_study.csv`.

## Method

| item | how |
|---|---|
| 1 storage | `STORE_W = DW + R + 1`, `R = $clog2(DW + $clog2(DW+1) + 1)` (analytical), cross-checked against the widths the elaborated RTL reports (`$bits` of the real ports) |
| 2 logic | Yosys **generic gates** (`synth -flatten -run :fine; opt; techmap; opt`, array left as a `$mem` cell, bank `DEPTH = 256`), `sf_ecc_enc`, `sf_ecc_dec`, bank ECC off / on / on + scrubber. Counts of `$_XOR_/$_AND_/...` cells and flip-flops |
| 3 latency | `rtl/tb/tb_sramlab_ecc_bank.sv`: cycles from the accepting edge to `rsp_valid`, isolated read / full write / partial write / zero-byte-enable write, `READ_LATENCY` 1 and 2, ECC off vs on |
| 4 RMW cost | streams of 1000 back-to-back requests (full writes, partial writes, reads, 50/25/25 mix); steady-state accept-to-accept interval; every row read back and compared with a byte-accurate model |
| 5 scrub | idle-bus step characterisation (period, array cycles, cycles a request is refused), scrub under offered load (Bernoulli reads), seeded-error repair |
| 6 faults | 1-, 2-, 3-bit flips XORed into the **stored** word (SEU hook of `sf_sram_core`, `FAULT_INJECT=1`), raw stored word read through the MBIST test port, functional read: data / status / `rsp_ce` / CE-UE counters / first-error row; partial write onto a 1-bit and a 2-bit-error line |
| 7 reference | `SecdedRef` (own Python SECDED written from the documented layout), vs RTL encoder/decoder over seeded `SplitMix64` vectors (exhaustive 1-bit and 2-bit, exhaustive/sampled 3-bit, random 0/4/5/6-bit, raw all-zero/all-ones words) and vs MemoryCore's own `tools/ecc/secded_ref.py` |

## Results (full run, Verilator 5.4x, Yosys 0.71)

| | DW = 32 | DW = 64 | DW = 128 | label |
|---|---:|---:|---:|---|
| stored bits per word (ECC off -> on) | 32 -> **39** | 64 -> **72** | 128 -> **137** | analytical (= RTL widths) |
| storage overhead | **21.875 %** | **12.5 %** | **7.031 %** | analytical |
| `sf_ecc_enc` / `sf_ecc_dec` generic cells | 84 / 433 | 176 / 812 | 315 / 1544 | synthesized |
| bank (256 rows) total cells: ECC off / on / on + scrub | 335 / 1535 / 1906 | 479 / 2422 / 2929 | 767 / 4050 / 4821 | synthesized |
| bank flip-flops: off / on | 27 / 187 | 27 / 255 | 27 / 391 | synthesized |
| decoder latency (read, full write, partial write) | **+1 cycle** (RL 1: 1 -> 2, RL 2: 2 -> 3), same at every DW | | | rtl_simulated |
| partial-write accept interval, ECC on | **2 cycles** (RL 1), **3 cycles** (RL 2): 0.500 / 0.333 of the full-write rate; ECC off: 1 cycle | | | rtl_simulated |
| mixed 50 % read / 25 % full / 25 % partial: ops per cycle (ECC on, RL 1 / RL 2) | 0.808 / 0.678 | 0.802 / 0.669 | 0.809 / 0.679 | rtl_simulated (ECC off: 1.0) |
| 1-bit error (every stored position) | 39/39 corrected | 72/72 | 137/137 | rtl_simulated |
| 2-bit errors (1500 random pairs) | 1500 detected | 1500 | 1500 | rtl_simulated |
| 3-bit errors (4000 random triples): silently miscorrected | **68.2 %** (exact 69.3 %) | **74.9 %** (76.0 %) | **84.0 %** (83.6 %) | rtl_simulated (exact = exhaustive reference) |
| RTL vs independent reference | 14,980 vectors, 0 mismatches | 67,362, 0 | 34,612, 0 | rtl_simulated |

Scrubber (`sf_sram_bank`, DW = 32): one step every `SCRUB_WAIT + READ_LATENCY + 1` cycles; a step occupies the array `READ_LATENCY + 1` cycles and refuses a request
`READ_LATENCY` cycles; it is started only in a cycle in which no request is presented.  Bank bandwidth consumed on an idle bus: **3.03 %** (RL 1, `SCRUB_WAIT = 64`, 66-cycle period),
4.48 % (RL 2), 20.0 % / 27.3 % at `SCRUB_WAIT = 8`.  Scrubbing 1024 rows takes ~67.6 k cycles at `SCRUB_WAIT = 64`.  Under load the cost is a throughput loss of 0.5-0.9 % (RL 1, WAIT 64, 25-75 % offered
load); a saturated bank is never scrubbed.  The seeded repair test found every seeded single-bit error once (CE counter = 21 = seeded) and re-reported the double-bit row on every pass.

Partial write onto a 1-bit-error line: corrected old data merged with the new bytes, re-encoded, CE counted, line clean afterwards.  Onto a 2-bit-error line: **aborted**, line left as found, `SF_ST_ECC_UE`;
a full-line write repairs it.  A miscorrected 3-bit error is **counted as a corrected error** (the CE counter overcounts real single errors) - SECDED does not guarantee 3-bit detection.

## Cross-checks against the package's own report

* `docs/ECC.md`: 243 of 300 random triples miscorrected (81 %, K = 128): consistent with the exact 83.64 % (1.2 sigma).  Partial-write ratio 0.501 / 0.335 (RL 1 / 2): measured 0.5003 / 0.3336.
* Yosys: MemoryCore committed (Yosys 0.33, `abc -fast`) `sf_ecc_enc` 314 / `sf_ecc_dec` 1389 cells at K = 128; here 315 / 1544 (see limitation 1).
* The performance runs use a bank with the fault hook compiled in (inputs idle); a `FAULT_INJECT=0` build gives identical latency and throughput numbers (checked in every run).

## Limitations (read before using the numbers)

1. **Yosys numbers are generic-gate counts, not area, timing or power.**  The `yowasp-yosys` 0.71 available here cannot execute its ABC pass (the pass ends the process silently), so counts are
   after `techmap` without logic optimisation / sharing (the decoder is ~11 % larger than MemoryCore's abc-optimised 1389).  Area, Fmax and decoder critical path are `unavailable` (no liberty, no STA).
2. Fault injection says what the logic does with a bit flip, **not how often flips happen**: no soft-error or hard-fault rate data exists.  Only the stored word is faulted; faults inside the codec are not modelled.
3. Latency is in cycles, not time (no clock frequency / timing exists); the +1 cycle is the registered response stage, not a measured decoder delay.
4. Bank-level results only: a controller / fabric on top adds its own queueing (the Python controller model does not include ECC).  Partial-write cost is for the single-bank, single-outstanding RMW of `sf_sram_bank`.
5. Scrub costs are for the RTL scrubber as built (round robin, opportunistic); the extrapolation to 1024 rows is linear (analytical).  3-bit statistics at the bank level are 4000-vector samples; the exact values come from the reference decoder.

## Rerun

```
python3 -c "from sramlab.studies.ecc import run_ecc_study as r; r(outdir='out/ecc')"                  # all word widths: ~4.5 min cold (Yosys K=64/128 dominate), seconds warm
python3 -c "from sramlab.studies.ecc import run_ecc_study as r; r(outdir='out/ecc', quick=True)"      # latency / synthesis for the first word width only: ~80 s cold
python3 -m pytest tests/test_ecc.py                                                                   # ~3 s warm, ~2 min cold (the two Yosys tests are marked `slow`: -m "not slow" skips them)
```
Builds are cached under `sramlab.rtlrun.BUILD_ROOT` (`.build/ecc_*`, Yosys results `.build/ys_*.json`).
