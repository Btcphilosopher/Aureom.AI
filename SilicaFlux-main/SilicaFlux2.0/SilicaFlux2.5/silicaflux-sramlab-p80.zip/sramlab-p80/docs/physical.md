# Physical-area analysis (`sramlab/tech.py`, `sramlab/phys.py`)

What this answers: *how many real open-PDK SRAM macros does this memory need, what do they cost in area, and what overheads come with ECC, arbitration and the NoC interface?*
What it refuses to answer from nothing: **die area, routed wirelength, timing, power**.

## Provenance rules

| quantity | label | rule |
|---|---|---|
| bit counts (user / stored incl. ECC) | `analytical` | arithmetic on the configuration; always available |
| macro footprint (`asic_macro`) | `analytical` | vendor LEF/datasheet dimensions (vendored manifests, commit-pinned) x tiling arithmetic; not a layout |
| `fpga_bram` | `analytical` | bit counts; BRAM tiles only if the profile states the device's BRAM size; **no mm^2** |
| `generic` | `analytical` | bit counts only; area `unavailable` |
| controller gate counts | `synthesized` | Yosys generic gates (see `docs/synthesis.md`) |
| controller logic area | `synthesized` or `unavailable("no technology library")` | only from a real Liberty, for THAT library's process |
| geometry / routing proxy | `analytical`, `generated-geometry` | not routed |
| **die area** | `unavailable` unless **all** of: macro dimensions, a logic area from a library of the *same process family* as the macros, and a caller-supplied margin | never estimated from nothing |

This is tested (`tests/test_phys.py::test_die_area_unavailable_when_libraries_are_missing` and friends): with the Nangate45 library the controller area *can* be mapped, but a 45 nm library
area is **not** added to 130 nm SKY130 macros - the die area stays `unavailable` with that reason.  A user-supplied technology profile whose `process_family` equals the macro's (and whose
Liberty path+sha256 is verified) enables it.

## Real macro catalogue (`tech.macro_catalog()`, `data/macros/`)

34 open-PDK macros: IHP SG13G2 (1P: 18, 2P: 9), GF180MCU (4), SKY130 OpenRAM (3).  Each entry has width, height, area, capacity bits, port topology, write-mask granularity, the manifest's
timing numbers where it has any, and its source repo/commit/hashes; vendored byte-identical with `SHA256SUMS` (a modified file is rejected).  The three `commercial_*_pending` placeholders carry no
data and are reported as *pending, no data*.  Provenance and caveats: `data/macros/PROVENANCE.md`.  Nothing here is silicon-measured.

## Tiling (`tech.tile_memory`)

A bank of `depth x stored_word` bits is tiled with one macro shape: `cols = ceil(word / macro_width)`, `rows = ceil(depth / macro_words)`; instances `cols x rows`; provisioned bits
`cols*dw * rows*words`; bit utilisation = required / provisioned.  4 banks x 1024 words x 128 bit (64 KiB), checked against the independent MemoryCore floorplan generator (macro area
numbers equal):

| macro | ECC | per bank (cols x rows) | macros total | macro area (mm^2) | bit utilisation |
|---|---|---|---:|---:|---:|
| `sky130_sram_2kbyte_1rw1r_32x512_8` | none | 4 x 2 | 32 | 9.1052 (9,105,231.04 um^2) | 100.00 % |
| same | SECDED 137 b | 5 x 2 | 40 | 11.3815 | 85.62 % |
| `RM_IHPSG13_1P_1024x64_c2_bm_bist` | none | 2 x 1 | 8 | 2.1116 (2,111,569.12 um^2) | 100.00 % |
| same | SECDED 137 b | 3 x 1 | 12 | 3.1674 | 71.35 % |
| `gf180mcu_fd_ip_sram__sram512x8m8wm1` | none | 16 x 2 | 128 | 26.8032 | 100.00 % |
| same | SECDED 137 b | 18 x 2 | 144 | 30.1536 | 95.14 % |

The SKY130 and GF180 macros reproduce the independent report's `C1`/`C2` rows (32/40 and 128/144 macros; 9.1052/11.3815 and 26.8032/30.1536 mm^2).  `rank_macros()` reproduces its ranking
for the SKY130 family (9.1052 < 12.2056 < 13.0095 mm^2).  Caveats carried in the result: the SKY130 macros are 1RW1R and the read-only port is paid for in every instance (its area share is not
knowable from the manifests); true dual-port IHP `2P` macros are excluded from ranking by default.

## ECC overhead (`area_report()["ecc_overhead"]`)

* stored-bit ratio, pure arithmetic: SECDED 39/32 = 1.2188, 72/64 = 1.1250, 137/128 = 1.0703 (`tech.secded_stored_bits`);
* extra macros and macro area from re-tiling the wider stored word (table above: +8 SKY130 macros, +2.28 mm^2 for 64 KiB at 128 bit);
* ECC codec logic: read from `data/ecc_study.json` **if** the ECC study wrote synthesized-gate rows for the word width; otherwise
  `unavailable("run `sramlab ecc` first")` with `TODO: true`.

## Arbitration overhead and NoC interface

* Controller gate count vs bank count: from the synthesis sweep (`docs/synthesis.md`): without performance counters 1,850 / 3,202 / 6,060 / 11,777 cells for 2 / 4 / 8 / 16 banks; with counters
  15,660 / 19,557 / 27,216 / 42,552.  Arbiters are not separable from the rest in the flat netlist, so this is whole-controller cost, not an incremental arbiter cost.
* NoC interface: the P74 SFB3 bridge `sf_sram_datafabric` (4 NoC masters, DW 128, 4 banks) **elaborates and synthesizes in Yosys**: 11,654 generic cells, 2,487 flip-flops, no latches,
  `check -assert` clean, pre-mapping depth 53 levels; Nangate45-mapped (bridge only): 22,367.94 um^2.  The shared-SRAM top `sf_sram_fabric_top` (NoC crossbar + bridge + MemoryCore controller +
  banks + scratchpads, DEPTH 16 so the tensor tile buffers fit) also synthesizes: 140,807 generic cells, 20,896 flip-flops, 0 latches, depth 96, 138 s (its arrays are flip-flops, not macros;
  at DEPTH 256 the run took ~12 minutes).  The RTL's own elaboration check rejects the *default* `SHARED_BYTES`/`TEN_BASE_LINE` at DEPTH 16, so they are scaled down and recorded in the result.
  Files vendored with SHA-256 under `rtl/third_party/p74_sramfabric` (`PROVENANCE.md`); results in `data/synth/noc_interface*.json`.  The vendored MemoryCore `sf_sram_controller` is a different module
  from P73's of the same name; they are never compiled together.

## Generated geometry (`phys.floorplan`)

Macro rectangles (tile grid inside a bank region, banks stacked in the divisor-pair arrangement with aspect ratio closest to 1) plus, **only if** the controller logic area exists and is of the macros'
process family, a controller strip.  Labelled "GENERATED GEOMETRY FROM VENDOR MACRO DIMENSIONS - NOT A ROUTED / SIGNED-OFF LAYOUT".  Spacing (`gap_um`, `channel_um`, `margin_um`, `halo_um`) is
caller-supplied and labelled `assumed`; omitted means macros abut (a bounding-box convenience, not a legal placement).  Orientation is not modelled (pin edges are not in the manifests).  Checked in tests:
no overlaps, everything inside the bounding box, summed macro area equals the vendor figure, spacing positions exact.  `macro_array_bbox_um2` is explicitly *not* a die area.

Placement constraints: manifests carry **no halo/keep-out** (`unavailable`); the manifests' own usage constraints (e.g. SKY130 "same-address write and read in one cycle must not be issued") are
listed verbatim.

## Routing estimate (analytical, not routed)

`routing_estimate` = for each bank, the Manhattan (half-perimeter) distance from the bank-region centre to the controller anchor, times the controller<->bank bus width
(`wdata + wstrb + row address + valid/we + rdata + valid/err`; 286 signals for 128-bit words, 1024 rows).  Example (SKY130, 4 banks x 1024 x 128, abutted): mean 2,199.28 um per bank,
2,515,976 signal-um in total.  No congestion, detours, buffering, layers or pin locations: a comparison proxy between configurations only.

## Optimiser hook

`phys.candidate_area(candidate, capacity_bytes)` (picked up by `sramlab optimise`) returns the cheapest single-port macro tiling of the bank from **one** macro family (default `IHP_1P`,
a documented comparison choice, so candidates are compared under the same macros), `analytical`, "macro footprint only, not a die area".

## Limits

* Macro dimensions are real, but the area of the *rest* of a memory (periphery outside macros, power grid, halos, routing channels, ECC and MBIST logic, clock tree) is not in the data.
* Tiling uses one macro shape per bank (as the SRAM wrapper library's `sram_asic_array` does); mixed-shape tiling could be smaller.
* `generic` and `fpga_bram` have no area in this tool by design.
* Commercial macros (130/65/28 nm) are pending: no data, no estimate.

## Rerun

```
python3 -m pytest tests/test_tech.py tests/test_phys.py          # < 1 s
python3 - <<'E'
from sramlab import phys; from sramlab.config import load_config
cfg = load_config({"memory": {"banks": 4, "bank_depth_words": 1024, "word_width_bits": 128},
                   "physical": {"backend": "asic_macro", "macro": "sky130_sram_2kbyte_1rw1r_32x512_8"}})
print(phys.area_report(cfg)["memory_footprint"]["total_macro_area_um2"]); phys.floorplan(cfg, outdir="out/")
E
```
