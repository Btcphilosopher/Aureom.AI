#!/usr/bin/env python3
"""Regenerate the committed datasets in data/ (everything is deterministic given the seeds).
Usage: python3 scripts/generate_data.py [--only bank_sweep,timeline,vector,tensor,rtl]
Study datasets with their own commands: sramlab ecc | mbist | synth (+ --liberty nangate45 --fetch) | floorplan --dataset | power --dataset | optimise"""
import argparse, json, os, sys, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from sramlab import experiments as E, record
from sramlab.config import load_config
from sramlab.studies import vector as V, tensor_study as T

D = os.path.join(ROOT, "data")

def dump(name, obj):
    with open(os.path.join(D, name), "w") as f:
        json.dump(obj, f, indent=1, default=record._json_default)
    print("wrote", name, flush=True)

def bank_sweep():
    out = {}
    for mo in (1, 4):
        base = load_config({"name": f"bank_sweep_mo{mo}", "memory": {"banks": 4, "bank_depth_words": 4096},
                            "controller": {"masters": 4, "max_outstanding": mo},
                            "workload": {"kind": "rand_read", "requests_per_master": 2000, "seed": 100,
                                         "write_fraction": 0.3, "hotspot_words": 8}})
        out[f"max_out_{mo}"] = E.sweep_banks(base, (2, 4, 8, 16), ("rand_read", "mixed", "seq_read", "hotspot", "contention"), replications=10)
    dump("bank_sweep.json", out)

def timeline():
    cfg = load_config({"name": "timeline_4b4m", "memory": {"banks": 4, "bank_depth_words": 4096},
                       "controller": {"masters": 4, "max_outstanding": 2},
                       "workload": {"kind": "mixed", "requests_per_master": 400, "seed": 21, "write_fraction": 0.3,
                                    "response_ready_rate": 0.9}})
    dump("timeline_trace.json", E.timeline_trace(cfg, 160))

def vector():
    s = V.run_vector_study(word_bits=(32, 128), vector_bits=(128, 256), banks=(4, 8, 16), replications=3, requests=1500)
    dump("vector_study.json", {"study": s, "p76_crosscheck": V.p76_crosscheck()})

def tensor():
    dump("tensor_study.json", T.run_tensor_study(banks=(1, 2, 4, 8, 16), max_out=(1, 2, 4), word_bits=(32, 128), dma_duty=(0.0, 0.25, 0.5)))

def rtl():
    """Full model-vs-RTL matrix (~2 min); same code as `sramlab rtlcheck`."""
    from sramlab import verify
    res = verify.run_matrix(quick=False, n_req=300, seed=11)
    res["mutation_check"] = verify.mutation_check()
    dump("rtl_verification.json", res)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--only", default="bank_sweep,timeline,vector,tensor,rtl")
    a = ap.parse_args()
    os.makedirs(D, exist_ok=True)
    for name in a.only.split(","):
        t0 = time.time(); globals()[name](); print(f"  {name}: {time.time()-t0:.0f}s", flush=True)
