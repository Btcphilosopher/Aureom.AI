#!/usr/bin/env python3
"""Build the deliverable zip (nothing is committed to git).  Excludes build caches, downloaded technology libraries, logs, bytecode.
Usage: python3 scripts/package.py [output.zip]"""
import hashlib, os, sys, zipfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
EXCLUDE_DIRS = {".build", ".cache", "__pycache__", ".pytest_cache", "logs", "sramlab_results", ".git", "dist", "node_modules"}
EXCLUDE_SUFFIX = (".pyc", ".o", ".gch", ".a")
def main(out):
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    n = 0
    sums = []
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for dp, dn, fn in os.walk(ROOT):
            dn[:] = sorted(d for d in dn if d not in EXCLUDE_DIRS)
            for f in sorted(fn):
                if f.endswith(EXCLUDE_SUFFIX) or f == "SHA256SUMS.package":
                    continue
                p = os.path.join(dp, f)
                rel = os.path.relpath(p, ROOT)
                data = open(p, "rb").read()
                sums.append(f"{hashlib.sha256(data).hexdigest()}  {rel}")
                zi = zipfile.ZipInfo.from_file(p, os.path.join("sramlab-p80", rel))
                zi.compress_type = zipfile.ZIP_DEFLATED
                z.writestr(zi, data); n += 1
        z.writestr("sramlab-p80/SHA256SUMS.package", "\n".join(sums) + "\n")
    print(f"wrote {out}: {n} files, {os.path.getsize(out)/1e6:.1f} MB")
if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "dist", "silicaflux-sramlab-p80.zip"))
