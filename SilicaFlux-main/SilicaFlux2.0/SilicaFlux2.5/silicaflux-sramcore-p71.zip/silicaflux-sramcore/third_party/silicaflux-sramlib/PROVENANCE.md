# Provenance — vendored SilicaFlux SRAM Wrapper Library subset (Project 01)

Source archive: `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` (repository Btcphilosopher/Aureom.AI),
member `silicaflux-sramlib/`.  The four files below are copied **unmodified**; their SHA-256 values equal the entries of
the library's own `SHA256SUMS` (checked when this package was built).

| file | used by | purpose |
|---|---|---|
| `rtl/mem/sram_defs.svh` | cross-check only | include for the two raw backends |
| `rtl/mem/backends/generic/sram_generic_1rw.sv` | `tb_sf_sram_xcheck` | independent raw 1RW reference (GENERIC backend) |
| `rtl/mem/backends/fpga/sram_fpga_1rw.sv` | `tb_sf_sram_xcheck` | independent raw 1RW reference (FPGA inference template) |
| `tb/mem/tb_common.svh` | every testbench | deterministic xorshift PRNG, `tb_check`, `SRAM_RESULT` line |

Nothing under `rtl/sram/` depends on this directory: the core is self-contained.  Only the testbenches use it.
