# SRAMCore synthesis report (Yosys)

Yosys: `Yosys 0.33 (git sha1 2584903a060)`.  Vivado: NOT INSTALLED; Quartus: NOT INSTALLED; OpenROAD: NOT INSTALLED.

**40 pass / 0 fail** of 40 runs.  Every row's exact Yosys script is in `synth.json`.

What this is: technology-independent synthesis and FPGA block-RAM *inference* evidence from Yosys.  What this is NOT: place-and-route, timing closure, power, board or silicon results, or any ASIC area / SRAM access-time figure.  **ASIC flow: NOT RUN** (no liberty file, SRAM compiler or PDK available here).

## Generic synthesis (hierarchy kept)

`memory` = what Yosys infers from the RTL before technology mapping (the storage must be ONE memory with a synchronous read port).  `glue` = cells of `sf_sram_core` itself, excluding the array.  The array's flip-flops after generic mapping are not reported: they are the array bits turned into flops, not an SRAM figure.

| config | params | memory (W x D, rd/wr ports, sync read) | glue flip-flops | glue other cells | latches | warnings | result |
|---|---|---|---|---|---|---|---|
| c32x1024 | `{'DW': 32, 'DEPTH': 1024}` | 32x1024 (1R/1W, sync read=True) | 2 | 3 | 0 | 0 | PASS |
| c32x1024_noack | `{'DW': 32, 'DEPTH': 1024, 'WACK': 0}` | 32x1024 (1R/1W, sync read=True) | 1 | 2 | 0 | 0 | PASS |
| c32x1024_lat2 | `{'DW': 32, 'DEPTH': 1024, 'LAT': 2}` | 32x1024 (1R/1W, sync read=True) | 3 | 3 | 0 | 1 | PASS |
| c32x1024_lat3 | `{'DW': 32, 'DEPTH': 1024, 'LAT': 3}` | 32x1024 (1R/1W, sync read=True) | 4 | 3 | 0 | 1 | PASS |
| c32x1024_a12 | `{'DW': 32, 'DEPTH': 1024, 'AW': 12}` | 32x1024 (1R/1W, sync read=True) | 4 | 39 | 0 | 0 | PASS |
| c32x1000 | `{'DW': 32, 'DEPTH': 1000}` | 32x1000 (1R/1W, sync read=True) | 4 | 44 | 0 | 0 | PASS |
| c32x1024_zero | `{'DW': 32, 'DEPTH': 1024, 'INITM': 1}` | 32x1024 (1R/1W, sync read=True) | 2 | 3 | 0 | 0 | PASS |
| c32x1024_file | `{'DW': 32, 'DEPTH': 1024, 'INITM': 2}` | 32x1024 (1R/1W, sync read=True) | 2 | 3 | 0 | 0 | PASS |
| c64x1024 | `{'DW': 64, 'DEPTH': 1024}` | 64x1024 (1R/1W, sync read=True) | 2 | 3 | 0 | 0 | PASS |
| c64x1024_lat2 | `{'DW': 64, 'DEPTH': 1024, 'LAT': 2}` | 64x1024 (1R/1W, sync read=True) | 3 | 3 | 0 | 1 | PASS |
| c64x1000_a11 | `{'DW': 64, 'DEPTH': 1000, 'AW': 11}` | 64x1000 (1R/1W, sync read=True) | 4 | 89 | 0 | 0 | PASS |
| c8x256 | `{'DW': 8, 'DEPTH': 256}` | 8x256 (1R/1W, sync read=True) | 2 | 3 | 0 | 0 | PASS |
| c24x300 | `{'DW': 24, 'DEPTH': 300}` | 24x300 (1R/1W, sync read=True) | 4 | 39 | 0 | 0 | PASS |
| c72x256_bw9 | `{'DW': 72, 'DEPTH': 256, 'BW': 9}` | 72x256 (1R/1W, sync read=True) | 2 | 3 | 0 | 0 | PASS |
| c128x64 | `{'DW': 128, 'DEPTH': 64}` | 128x64 (1R/1W, sync read=True) | 2 | 3 | 0 | 0 | PASS |
| c32x3 | `{'DW': 32, 'DEPTH': 3}` | 32x3 (1R/1W, sync read=True) | 4 | 39 | 0 | 0 | PASS |

## FPGA block-RAM inference

| configuration | flow | RAM primitives | other RAM cells | flip-flops | LUTs | memories left | result |
|---|---|---|---|---|---|---|---|
| xc7 32x1024 (primary) | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 2 | 8 | 0 | PASS |
| xc7 32x1024 posted writes | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 1 | 7 | 0 | PASS |
| xc7 32x1024 read latency 2 — output register | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 35 | 8 | 0 | PASS |
| xc7 32x1024 read latency 3 | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 68 | 8 | 0 | PASS |
| xc7 32x1024, 12-bit address — bounds check active | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 4 | 42 | 0 | PASS |
| xc7 32x1000 (non power of two) | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 4 | 43 | 0 | PASS |
| xc7 64x1024 | `synth_xilinx -family xc7` | {'RAMB36E1': 2} | - | 2 | 15 | 0 | PASS |
| xc7 64x1000, 11-bit address | `synth_xilinx -family xc7` | {'RAMB36E1': 2} | - | 4 | 85 | 0 | PASS |
| xc7 64x4096 latency 2 (32 KiB) | `synth_xilinx -family xc7` | {'RAMB36E1': 8} | - | 67 | 15 | 0 | PASS |
| xc7 72x1024, 9-bit lanes — parity lanes | `synth_xilinx -family xc7` | {'RAMB36E1': 2} | - | 2 | 15 | 0 | PASS |
| xc7 32x1024 INIT_MODE=ZERO | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 2 | 8 | 0 | PASS |
| xc7 32x1024 INIT_MODE=FILE | `synth_xilinx -family xc7` | {'RAMB36E1': 1} | - | 2 | 8 | 0 | PASS |
| xc7 32x131072 (512 KiB) — capacity scaling | `synth_xilinx -family xc7` | {'RAMB36E1': 128} | - | 3 | 45 | 0 | PASS |
| ice40 16x256 | `synth_ice40` | {'SB_RAM40_4K': 1} | - | 2 | 6 | 0 | PASS |
| ice40 16x1024 | `synth_ice40` | {'SB_RAM40_4K': 4} | - | 2 | 5 | 0 | PASS |
| ecp5 32x1024 | `synth_ecp5` | {'DP16KD': 2} | - | 2 | 20 | 0 | PASS |
| ecp5 64x1024 | `synth_ecp5` | {'DP16KD': 4} | - | 2 | 22 | 0 | PASS |

## Configuration examples (`examples/sf_sram_examples.sv`, synth_xilinx xc7)

| example | RAM primitives | other RAM cells | flip-flops | LUTs | memories left | result |
|---|---|---|---|---|---|---|
| sf_sram_ex_cpu_dcache_data | {'RAMB36E1': 1} | - | 1 | 7 | 0 | PASS |
| sf_sram_ex_tensor_operand_buf | {'RAMB36E1': 4} | - | 2 | 15 | 0 | PASS |
| sf_sram_ex_vector_spm_bank | {'RAMB36E1': 8} | - | 66 | 14 | 0 | PASS |
| sf_sram_ex_controlcore_lmem | {'RAMB36E1': 2} | - | 2 | 8 | 0 | PASS |
| sf_sram_ex_parity_lane_buf | {'RAMB36E1': 2} | - | 2 | 15 | 0 | PASS |
| sf_sram_ex_nibble_tag | {'RAMB36E1': 2} | - | 4 | 44 | 0 | PASS |
| sf_sram_ex_asic_style | {'RAMB36E1': 2} | - | 67 | 15 | 0 | PASS |
