# Mutation sanity report

22 injected RTL bugs: **22 killed**, 0 survived, 0 invalid.

| # | injected bug | requirement exercised | sim | result | first failing check |
|---|---|---|---|---|---|
| M01 | write lane 1 takes lane 2 data | byte enables: lane mapping | verilator | KILLED | SRAM_ERROR t=10410000 reset: stored word lost or changed by reset |
| M02 | lane 0 written regardless of its enable | byte enables: preservation of untouched bytes | verilator | KILLED | SRAM_ERROR t=41490000 rdata got=ab5c59c8 exp=ab5c5937 known=ffffffff (cycle 4148) |
| M03 | byte-enable polarity inverted | byte enables: polarity | verilator | KILLED | SRAM_ERROR t=10410000 reset: stored word lost or changed by reset |
| M04 | unselected lanes cleared on a partial write | byte enables: untouched bytes preserved | verilator | KILLED | SRAM_ERROR t=41490000 rdata got=00000000 exp=ab5c5937 known=ffffffff (cycle 4148) |
| M05 | zero-strobe write corrupts the word | byte enables: zero write strobes | verilator | KILLED | SRAM_ERROR t=41490000 rdata got=ab5c59c8 exp=ab5c5937 known=ffffffff (cycle 4148) |
| M06 | write happens with ce=0 (we=1) | disabled cycles | verilator | KILLED | SRAM_ERROR t=10470000 reset: write presented while rst_n=0 modified the array |
| M07 | bounds check off by one (<=) | invalid addresses: boundary | verilator | KILLED | SRAM_ERROR t=107820000 rd_err got=0 exp=1 (cycle 10781) |
| M08 | invalid addresses silently aliased (no check) | invalid addresses: no aliasing | verilator | KILLED | SRAM_ERROR t=110220000 rd_err got=0 exp=1 (cycle 11021) |
| M09 | address MSB ignored | every address | verilator | KILLED | SRAM_ERROR t=21000000 rdata got=58f50b8b exp=94de6b38 known=ffffffff (cycle 2099) |
| M10 | last word missing from the array | first and last word | verilator | KILLED | SRAM_ERROR t=10700000 last word |
| M11 | rd_valid one cycle early (LAT=2) | read latency: valid | verilator | KILLED | SRAM_ERROR t=70000 rd_valid got=1 exp=0 (cycle 6) |
| M12 | read data one cycle early (LAT=2) | read latency: data | verilator | KILLED | SRAM_ERROR t=21120000 rdata got=ab5c5937 exp=94de6b38 known=ffffffff (cycle 2111) |
| M13 | in-flight responses survive reset | reset: response flush | verilator | KILLED | SRAM_ERROR t=10500000 rd_valid during reset got=1 exp=0 (cycle 1049) |
| M14 | access presented during reset is executed | reset: accesses ignored | verilator | KILLED | SRAM_ERROR t=10470000 reset: write presented while rst_n=0 modified the array |
| M15 | controller reset zero-fills word 0 (array reset by controller) | retention across controller reset | verilator | KILLED | SRAM_ERROR t=113490000 rdata got=00000000 exp=00f3f155 known=ffffffff (cycle 11348) |
| M16 | invalid read returns stale data instead of zero | invalid addresses: deterministic response | verilator | KILLED | SRAM_ERROR t=110220000 rdata on invalid read not zero: 739a7fe6 (cycle 11021) |
| M17 | zero-strobe write is not acknowledged | write acknowledgement | verilator | KILLED | SRAM_ERROR t=31260000 wr_ack got=0 exp=1 (cycle 3125) |
| M18 | invalid write is silent when WRITE_ACK=0 | errors are never silent | verilator | KILLED | SRAM_ERROR t=110240000 wr_err got=0 exp=1 (cycle 11023) |
| M19 | INIT_MODE=ZERO fills ones | INIT_MODE=ZERO | verilator | KILLED | SRAM_ERROR t=70000 rdata got=ffffffff exp=00000000 known=ffffffff (cycle 6) |
| M20 | INIT_MODE=FILE ignores the file | INIT_MODE=FILE | verilator | KILLED | SRAM_ERROR t=70000 rdata got=ca7a13f7 exp=a9741a02 known=ffffffff (cycle 6) |
| M21 | INIT_MODE=NONE silently zero-fills the array | unwritten SRAM must not read as zero (only observable in a 4-state simulator) | icarus | KILLED | SRAM_ERROR t=70000 unwritten bit 0 of read data is not X (got 0), cycle 6 |
| M22 | rdata held (not X) while rd_valid=0 | rdata only meaningful with rd_valid (poison, 4-state) | icarus | KILLED | SRAM_ERROR t=10440000 rdata is not poisoned (X) while rd_valid=0: 66a8d592 (cycle 1043) |
