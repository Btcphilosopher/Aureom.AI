# SRAMCore regression report

Suites: lint, neg, sim, xsim, xcheck, assert, if  |  records: 148  |  **pass 148 / fail 0**

Tools: verilator: `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`; iverilog: `Icarus Verilog version 12.0 (stable) ()`; yosys: `Yosys 0.33 (git sha1 2584903a060)`; python: `3.13.18`; vivado: `NOT INSTALLED`; quartus: `NOT INSTALLED`; openroad: `NOT INSTALLED`

## lint

| tool | config | result |
|---|---|---|
| verilator -Wall | c32x1024 | PASS |
| iverilog -Wall | c32x1024 | PASS |
| verilator -Wall | c32x1024_noack | PASS |
| iverilog -Wall | c32x1024_noack | PASS |
| verilator -Wall | c32x1024_lat2 | PASS |
| iverilog -Wall | c32x1024_lat2 | PASS |
| verilator -Wall | c32x1024_lat3 | PASS |
| iverilog -Wall | c32x1024_lat3 | PASS |
| verilator -Wall | c32x1024_a12 | PASS |
| iverilog -Wall | c32x1024_a12 | PASS |
| verilator -Wall | c32x1000 | PASS |
| iverilog -Wall | c32x1000 | PASS |
| verilator -Wall | c32x1000_a12_lat2 | PASS |
| iverilog -Wall | c32x1000_a12_lat2 | PASS |
| verilator -Wall | c32x1024_zero | PASS |
| iverilog -Wall | c32x1024_zero | PASS |
| verilator -Wall | c32x1024_pattern | PASS |
| iverilog -Wall | c32x1024_pattern | PASS |
| verilator -Wall | c32x1024_file | PASS |
| iverilog -Wall | c32x1024_file | PASS |
| verilator -Wall | c64x1024 | PASS |
| iverilog -Wall | c64x1024 | PASS |
| verilator -Wall | c64x1024_noack | PASS |
| iverilog -Wall | c64x1024_noack | PASS |
| verilator -Wall | c64x1024_lat2 | PASS |
| iverilog -Wall | c64x1024_lat2 | PASS |
| verilator -Wall | c64x1000_a11 | PASS |
| iverilog -Wall | c64x1000_a11 | PASS |
| verilator -Wall | c64x1024_file | PASS |
| iverilog -Wall | c64x1024_file | PASS |
| verilator -Wall | c64x1024_pattern | PASS |
| iverilog -Wall | c64x1024_pattern | PASS |
| verilator -Wall | c8x256 | PASS |
| iverilog -Wall | c8x256 | PASS |
| verilator -Wall | c16x512 | PASS |
| iverilog -Wall | c16x512 | PASS |
| verilator -Wall | c24x300 | PASS |
| iverilog -Wall | c24x300 | PASS |
| verilator -Wall | c72x256_bw9 | PASS |
| iverilog -Wall | c72x256_bw9 | PASS |
| verilator -Wall | c128x64 | PASS |
| iverilog -Wall | c128x64 | PASS |
| verilator -Wall | c32x2 | PASS |
| iverilog -Wall | c32x2 | PASS |
| verilator -Wall | c32x3 | PASS |
| iverilog -Wall | c32x3 | PASS |
| verilator -Wall | c32x4096_lat2 | PASS |
| iverilog -Wall | c32x4096_lat2 | PASS |
| verilator -Wall (-Wno-UNDRIVEN: top-level interface) | sf_sram_core_if | PASS |
| verilator -Wall | sf_sram_ex_cpu_dcache_data | PASS |
| iverilog -Wall | sf_sram_ex_cpu_dcache_data | PASS |
| verilator -Wall | sf_sram_ex_tensor_operand_buf | PASS |
| iverilog -Wall | sf_sram_ex_tensor_operand_buf | PASS |
| verilator -Wall | sf_sram_ex_vector_spm_bank | PASS |
| iverilog -Wall | sf_sram_ex_vector_spm_bank | PASS |
| verilator -Wall | sf_sram_ex_controlcore_lmem | PASS |
| iverilog -Wall | sf_sram_ex_controlcore_lmem | PASS |
| verilator -Wall | sf_sram_ex_parity_lane_buf | PASS |
| iverilog -Wall | sf_sram_ex_parity_lane_buf | PASS |
| verilator -Wall | sf_sram_ex_nibble_tag | PASS |
| iverilog -Wall | sf_sram_ex_nibble_tag | PASS |
| verilator -Wall | sf_sram_ex_asic_style | PASS |
| iverilog -Wall | sf_sram_ex_asic_style | PASS |
| verilator -Wall -DSYNTHESIS | c32x1024 | PASS |

## neg

| illegal parameterisation | overrides | Verilator | Icarus | Yosys | result |
|---|---|---|---|---|---|
| data_width_not_multiple | `{'DATA_WIDTH': 33}` | PASS | PASS | PASS | PASS |
| data_width_below_byte | `{'DATA_WIDTH': 4}` | PASS | PASS | PASS | PASS |
| byte_width_zero | `{'BYTE_WIDTH': 0}` | PASS | PASS | PASS | PASS |
| depth_one | `{'DEPTH_WORDS': 1}` | PASS | PASS | PASS | PASS |
| depth_zero | `{'DEPTH_WORDS': 0}` | PASS | PASS | PASS | PASS |
| depth_negative | `{'DEPTH_WORDS': -4}` | PASS | PASS | PASS | PASS |
| addr_width_too_small | `{'DEPTH_WORDS': 1024, 'ADDR_WIDTH': 9}` | PASS | PASS | PASS | PASS |
| addr_width_zero | `{'ADDR_WIDTH': 0}` | PASS | PASS | PASS | PASS |
| addr_width_31 | `{'ADDR_WIDTH': 31}` | PASS | PASS | PASS | PASS |
| read_latency_zero | `{'READ_LATENCY': 0}` | PASS | PASS | PASS | PASS |
| read_latency_negative | `{'READ_LATENCY': -1}` | PASS | PASS | PASS | PASS |
| write_ack_2 | `{'WRITE_ACK': 2}` | PASS | PASS | PASS | PASS |
| oob_assert_2 | `{'OOB_ASSERT': 2}` | PASS | PASS | PASS | PASS |
| init_mode_7 | `{'INIT_MODE': 7}` | PASS | PASS | PASS | PASS |
| init_file_missing | `{'INIT_MODE': 2}` | PASS | PASS | PASS | PASS |
| init_pattern_in_synthesis | `{'INIT_MODE': 3} ['SYNTHESIS']` | PASS | PASS | PASS | PASS |

## sim

| config | sim | seed | checks | errors | result |
|---|---|---|---|---|---|
| c32x1024 `{'DW': 32, 'DEPTH': 1024}` | verilator | 1 | 193247 | 0 | PASS |
| c32x1024 `{'DW': 32, 'DEPTH': 1024}` | verilator | 2 | 193110 | 0 | PASS |
| c32x1024 `{'DW': 32, 'DEPTH': 1024}` | verilator | 3 | 193297 | 0 | PASS |
| c32x1024 `{'DW': 32, 'DEPTH': 1024}` | icarus | 1 | 140084 | 0 | PASS |
| c32x1024_noack `{'DW': 32, 'DEPTH': 1024, 'WACK': 0}` | verilator | 1 | 193247 | 0 | PASS |
| c32x1024_noack `{'DW': 32, 'DEPTH': 1024, 'WACK': 0}` | icarus | 1 | 140084 | 0 | PASS |
| c32x1024_lat2 `{'DW': 32, 'DEPTH': 1024, 'LAT': 2}` | verilator | 1 | 193448 | 0 | PASS |
| c32x1024_lat2 `{'DW': 32, 'DEPTH': 1024, 'LAT': 2}` | icarus | 1 | 140328 | 0 | PASS |
| c32x1024_lat3 `{'DW': 32, 'DEPTH': 1024, 'LAT': 3}` | verilator | 1 | 193614 | 0 | PASS |
| c32x1024_a12 `{'DW': 32, 'DEPTH': 1024, 'AW': 12}` | verilator | 1 | 231565 | 0 | PASS |
| c32x1024_a12 `{'DW': 32, 'DEPTH': 1024, 'AW': 12}` | verilator | 2 | 231432 | 0 | PASS |
| c32x1024_a12 `{'DW': 32, 'DEPTH': 1024, 'AW': 12}` | icarus | 1 | 182083 | 0 | PASS |
| c32x1000 `{'DW': 32, 'DEPTH': 1000}` | verilator | 1 | 202681 | 0 | PASS |
| c32x1000 `{'DW': 32, 'DEPTH': 1000}` | icarus | 1 | 149171 | 0 | PASS |
| c32x1000_a12_lat2 `{'DW': 32, 'DEPTH': 1000, 'AW': 12, 'LAT': 2}` | verilator | 1 | 230515 | 0 | PASS |
| c32x1024_zero `{'DW': 32, 'DEPTH': 1024, 'INITM': 1}` | verilator | 1 | 193247 | 0 | PASS |
| c32x1024_zero `{'DW': 32, 'DEPTH': 1024, 'INITM': 1}` | icarus | 1 | 107316 | 0 | PASS |
| c32x1024_pattern `{'DW': 32, 'DEPTH': 1024, 'INITM': 3}` | verilator | 1 | 193247 | 0 | PASS |
| c32x1024_pattern `{'DW': 32, 'DEPTH': 1024, 'INITM': 3}` | icarus | 1 | 107316 | 0 | PASS |
| c32x1024_file `{'DW': 32, 'DEPTH': 1024, 'INITM': 2}` | verilator | 1 | 193247 | 0 | PASS |
| c32x1024_file `{'DW': 32, 'DEPTH': 1024, 'INITM': 2}` | icarus | 1 | 107316 | 0 | PASS |
| c64x1024 `{'DW': 64, 'DEPTH': 1024}` | verilator | 1 | 197788 | 0 | PASS |
| c64x1024 `{'DW': 64, 'DEPTH': 1024}` | verilator | 2 | 197512 | 0 | PASS |
| c64x1024 `{'DW': 64, 'DEPTH': 1024}` | verilator | 3 | 197697 | 0 | PASS |
| c64x1024 `{'DW': 64, 'DEPTH': 1024}` | icarus | 1 | 178105 | 0 | PASS |
| c64x1024_noack `{'DW': 64, 'DEPTH': 1024, 'WACK': 0}` | verilator | 1 | 197788 | 0 | PASS |
| c64x1024_noack `{'DW': 64, 'DEPTH': 1024, 'WACK': 0}` | icarus | 1 | 178105 | 0 | PASS |
| c64x1024_lat2 `{'DW': 64, 'DEPTH': 1024, 'LAT': 2}` | verilator | 1 | 198819 | 0 | PASS |
| c64x1024_lat2 `{'DW': 64, 'DEPTH': 1024, 'LAT': 2}` | icarus | 1 | 179460 | 0 | PASS |
| c64x1000_a11 `{'DW': 64, 'DEPTH': 1000, 'AW': 11}` | verilator | 1 | 216288 | 0 | PASS |
| c64x1000_a11 `{'DW': 64, 'DEPTH': 1000, 'AW': 11}` | icarus | 1 | 196551 | 0 | PASS |
| c64x1024_file `{'DW': 64, 'DEPTH': 1024, 'INITM': 2}` | verilator | 1 | 197788 | 0 | PASS |
| c64x1024_file `{'DW': 64, 'DEPTH': 1024, 'INITM': 2}` | icarus | 1 | 112569 | 0 | PASS |
| c64x1024_pattern `{'DW': 64, 'DEPTH': 1024, 'INITM': 3}` | verilator | 1 | 197788 | 0 | PASS |
| c64x1024_pattern `{'DW': 64, 'DEPTH': 1024, 'INITM': 3}` | icarus | 1 | 112569 | 0 | PASS |
| c8x256 `{'DW': 8, 'DEPTH': 256}` | verilator | 1 | 151338 | 0 | PASS |
| c8x256 `{'DW': 8, 'DEPTH': 256}` | icarus | 1 | 62907 | 0 | PASS |
| c16x512 `{'DW': 16, 'DEPTH': 512, 'LAT': 2}` | verilator | 1 | 165420 | 0 | PASS |
| c16x512 `{'DW': 16, 'DEPTH': 512, 'LAT': 2}` | icarus | 1 | 84649 | 0 | PASS |
| c24x300 `{'DW': 24, 'DEPTH': 300}` | verilator | 1 | 160202 | 0 | PASS |
| c24x300 `{'DW': 24, 'DEPTH': 300}` | icarus | 1 | 77049 | 0 | PASS |
| c72x256_bw9 `{'DW': 72, 'DEPTH': 256, 'BW': 9}` | verilator | 1 | 156074 | 0 | PASS |
| c72x256_bw9 `{'DW': 72, 'DEPTH': 256, 'BW': 9}` | icarus | 1 | 84794 | 0 | PASS |
| c128x64 `{'DW': 128, 'DEPTH': 64}` | verilator | 1 | 151049 | 0 | PASS |
| c128x64 `{'DW': 128, 'DEPTH': 64}` | icarus | 1 | 69316 | 0 | PASS |
| c32x2 `{'DW': 32, 'DEPTH': 2}` | verilator | 1 | 136096 | 0 | PASS |
| c32x2 `{'DW': 32, 'DEPTH': 2}` | icarus | 1 | 44028 | 0 | PASS |
| c32x3 `{'DW': 32, 'DEPTH': 3}` | verilator | 1 | 137800 | 0 | PASS |
| c32x3 `{'DW': 32, 'DEPTH': 3}` | icarus | 1 | 45217 | 0 | PASS |
| c32x4096_lat2 `{'DW': 32, 'DEPTH': 4096, 'LAT': 2, 'NRAND': 20000}` | verilator | 1 | 315000 | 0 | PASS |

## xsim

| config | seed | Verilator | Icarus | identical stimulus | result |
|---|---|---|---|---|---|
| c32x1024 | 1 | PASS (95688 checks) | PASS (140084 checks) | True | PASS |
| c32x1024_a12 | 1 | PASS (133667 checks) | PASS (182083 checks) | True | PASS |
| c64x1024 | 1 | PASS (100213 checks) | PASS (178105 checks) | True | PASS |

## xcheck

| case | seed | checks | errors | result |
|---|---|---|---|---|
| x32_lat1 | 1 | 182373 | 0 | PASS |
| x32_lat1 | 2 | 181903 | 0 | PASS |
| x32_lat2 | 1 | 182375 | 0 | PASS |
| x32_lat2 | 2 | 181905 | 0 | PASS |
| x64_lat1 | 1 | 182373 | 0 | PASS |
| x64_lat1 | 2 | 181903 | 0 | PASS |
| x64_lat3 | 1 | 182377 | 0 | PASS |
| x64_lat3 | 2 | 181907 | 0 | PASS |
| x16_lat1 | 1 | 182373 | 0 | PASS |
| x16_lat1 | 2 | 181903 | 0 | PASS |
| x32_lat2 (icarus) | 1 | 182375 | 0 | PASS |

## assert

| simulator | expected | observed | result |
|---|---|---|---|
| verilator | {'oob': 5, 'x': 0} | {'oob': 5, 'x': 0, 'int': 0} | PASS |
| icarus | {'oob': 5, 'x': 2} | {'oob': 5, 'x': 2, 'int': 0} | PASS |

## if

| config | checks | errors | result |
|---|---|---|---|
| if32x1024 | 148826 | 0 | PASS |
| if64x1000_a11_lat2 | 173023 | 0 | PASS |

