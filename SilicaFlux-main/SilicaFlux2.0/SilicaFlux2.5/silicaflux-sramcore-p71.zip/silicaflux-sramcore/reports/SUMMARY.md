# SilicaFlux SRAMCore (Project 71) - verification summary

Generated 2026-11-14T14:10:05Z.  RTL sha256 `0db45ccfdd131c201df1229d97be11101572c843e572f75c9f9133bdd0fb0b8d`.

| check | source report | result |
|---|---|---|
| lint (Verilator -Wall, Icarus -Wall) | regression.md | 64 pass / 0 fail |
| illegal parameterisations rejected | regression.md | 16 pass / 0 fail |
| self-checking simulation (configs x seeds x simulators) | regression.md | 50 pass / 0 fail |
| cross-simulator identical stimulus | regression.md | 3 pass / 0 fail |
| cross-check vs SRAM Wrapper Library backends | regression.md | 11 pass / 0 fail |
| assertions fire where intended | regression.md | 2 pass / 0 fail |
| SV interface wrapper | regression.md | 2 pass / 0 fail |
| scoreboard checks in sim/xcheck/if runs | regression.json | 10,434,977 |
| mutation sanity (injected RTL bugs caught) | mutants.md | 22 killed / 0 survived / 0 invalid of 22 |
| Yosys synthesis + FPGA inference | synth.md | 40 pass / 0 fail |
| gate-level simulation of netlists | gls.md | 13 pass / 0 fail |

**Overall: ALL CHECKS PASS**

## Tools

| tool | version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| python | 3.13.18 |
| vivado | NOT INSTALLED |
| quartus | NOT INSTALLED |
| openroad | NOT INSTALLED |

## Not available / not done

* ASIC SRAM macro flow: no PDK, liberty file or SRAM compiler here - no ASIC area, power or access-time figure exists in this package.
* Vendor FPGA tools (Vivado, Quartus, Radiant): not installed - block-RAM inference is Yosys-based evidence only; no place-and-route, timing or board run.
* Gate-level simulation of Xilinx RAMB / ECP5 DP16KD netlists: not possible with the cell models shipped in this Yosys (timing-only stubs).
* Formal property proofs: not performed (no SymbiYosys installed).

Every number above comes from the JSON reports in this directory; each embeds commands, exit codes and tool versions.
