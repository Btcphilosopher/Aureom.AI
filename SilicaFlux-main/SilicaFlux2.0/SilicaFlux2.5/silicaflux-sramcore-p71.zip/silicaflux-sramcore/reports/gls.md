# Gate-level simulation report

13 pass / 0 fail of 13 synthesised netlists simulated with the same self-checking testbench (Icarus Verilog; Yosys behavioural cell models; seed 1).

| netlist | flow | checks | errors | random cycles | result |
|---|---|---|---|---|---|
| 32x256, 10-bit address (bounds check active) | `synth (generic gates)` | 42381 | 0 | 3000 | PASS |
| 32x300 non-pow2, latency 2, posted writes | `synth (generic gates)` | 40357 | 0 | 3000 | PASS |
| 64x128 | `synth (generic gates)` | 29582 | 0 | 3000 | PASS |
| 28x100, 4-bit lanes | `synth (generic gates)` | 29178 | 0 | 3000 | PASS |
| 72x64, 9-bit lanes | `synth (generic gates)` | 26163 | 0 | 3000 | PASS |
| 32x256, 10-bit address | `synth_xilinx -family xc7 -nobram (distributed RAM)` | 46832 | 0 | 4000 | PASS |
| 64x128 latency 2, 8-bit address | `synth_xilinx -family xc7 -nobram (distributed RAM)` | 38612 | 0 | 4000 | PASS |
| 32x300 non-pow2, posted writes | `synth_xilinx -family xc7 -nobram (distributed RAM)` | 44600 | 0 | 4000 | PASS |
| 16x256 | `synth_ice40 (SB_RAM40_4K block RAM)` | 45084 | 0 | 6000 | PASS |
| 16x1024, 12-bit address | `synth_ice40 (SB_RAM40_4K block RAM)` | 124541 | 0 | 6000 | PASS |
| 16x1000 non-pow2, latency 2 | `synth_ice40 (SB_RAM40_4K block RAM)` | 95755 | 0 | 6000 | PASS |
| 16x512 INIT_MODE=ZERO | `synth_ice40 (SB_RAM40_4K block RAM)` | 50048 | 0 | 4000 | PASS |
| 16x512 INIT_MODE=FILE | `synth_ice40 (SB_RAM40_4K block RAM)` | 50048 | 0 | 4000 | PASS |

**Not simulated:** Xilinx RAMB18E1/RAMB36E1 and ECP5 DP16KD block-RAM netlists - the cell models shipped with this Yosys contain only timing data and no function, so those netlists have inference evidence only (reports/synth.md).  The xc7 rows above use distributed RAM (`-nobram`), not block RAM.

Limits: Yosys' behavioural models, not vendor sign-off models; no timing; the RTL-only 4-state checks (unwritten bits are X, rdata poison) are disabled for netlists.

