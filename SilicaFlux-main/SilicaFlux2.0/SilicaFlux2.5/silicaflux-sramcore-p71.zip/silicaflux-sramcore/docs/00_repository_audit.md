# 00 — Repository audit

Scope: everything in the repository that touches SRAM wrappers, memory controllers, caches, DataFabric, scratchpads,
ECC, FPGA memory inference and test infrastructure — before writing any new RTL.  Nothing was assumed to exist
because an earlier brief asked for it.

## 1. Method, and what was run versus only read

The repository (`Btcphilosopher/Aureom.AI`) is a collection of delivered archives; the SilicaFlux material lives in
`SilicaFlux-main/…` as `.zip` files (the `.sf` extension used in a few top-level files is SystemVerilog, as the SRAM
library's own audit notes).  The relevant archives were extracted into a scratch directory and read.

| Activity | Status |
|---|---|
| Archives located, extracted, file lists and READMEs read | done |
| Source of the SRAM Wrapper Library single-port path (`sram_sp`, `sram_generic_1rw`, `sram_fpga_1rw`, `sram_defs.svh`, `tb_common.svh`) read in full | done |
| Library's own single-port testbench `tb_sram_sp` **re-run in this environment** (Verilator 5.020, seed 7) | **`SRAM_RESULT PASS … checks=47615 errors=0`** |
| SHA-256 of the four files reused here compared with the library's own `SHA256SUMS` | identical |
| All other reports in other archives (regression counts, synthesis tables, placement) | read, **not** re-run — quoted as the owners reported them |

## 2. What exists

No module named `sf_sram_core` and no `rtl/sram/` directory existed.  The SRAM infrastructure is Project 01:

| Area | Where (inside `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/` unless noted) | Finding |
|---|---|---|
| **SRAM wrappers** | `silicaflux-sramlib.zip` → `rtl/mem/` | Project 01 "SRAM Wrapper Library": raw backends `sram_backend_1rw / 1r1w / 2rw` over GENERIC, FPGA and ASIC implementations; handshake wrappers `sram_sp`, `sram_1r1w`, `sram_tdp`; `sram_bank_controller`; MBIST adapter. Its report (`reports/mem/SUMMARY.md`) lists lint 47, sim 53, formal 9, synthesis 29 passes; the single-path claim was spot-checked above. |
| **Memory controllers** | `silicaflux-memorycore1.zip` → `rtl/silicaflux_memory_subsystem.sv`, `sfmem_banked.sv`, `sfmem_cache.sv` | Unified memory subsystem. Banked SRAM reuses `sram_bank_controller`; the ControlCore cache keeps data in one `sram_backend_1rw` per way. States "RTL simulation only". |
| **Cache modules** | `sfmem_cache.sv` (above) | Only cache in the repository: non-coherent ControlCore cache, data in `sram_backend_1rw`. |
| **DataFabric** | `silicaflux-datafabric.zip` → `rtl/mem/sfb_sram_slave.sv`, `sfb_sram_1r1w_slave.sv` | SRAM slave adapters onto the library; the library is vendored unmodified with `SHA256SUMS`. |
| **Scratchpads** | `silicaflux-hpc-m04-scratchpad.zip` → `rtl/hpc_scratchpad.sv`, `hpc_spm_bank.sv` | Vector scratchpad; vendors the library under `third_party/`. |
| **Buffers** | `silicaflux-buffercore-p55.zip` → `rtl/sfsb_sram_bank.sv` | `sram_sp` configured as 8 lanes × 9 bits (`{parity, byte}`); byte enables map 1:1 onto lane masks. This is why `BYTE_WIDTH` here is a free parameter and 9 is a tested value. |
| **Large banked arrays** | `silicaflux-sramgrid-p33.zip` | Macro abstracts for open PDKs, placement, ECC-width cost. Documents that no IHP macro is 72 bits wide (SECDED on 64-bit banks costs 3×32-bit tiles). |
| **ControlCore memory** | `silicaflux-controlcore.zip` → `rtl/generated/sfv_bootrom_image.sv`, `fpga/cc_fpga_top.sv` (`cc_fpga_devmem`) | Boot ROM image and an FPGA device memory; local memory arrives through MemoryCore. |
| **ECC** | `SilicaFlux-main/silicaflux-ecccore-p54.zip` | Project 54 is **NAND** BCH/LDPC (`silicaflux_storage_ecc`), not an SRAM-array ECC. SRAM SECDED exists as `sfras_secded_enc/dec.sv` in the RAS project (vendored under `silicaflux-sramgrid-p33/…/third_party/silicaflux-ras/`). **This core has no ECC**; parity/ECC lanes are supported through `BYTE_WIDTH=9` and a wider `DATA_WIDTH`. |
| **FPGA memory inference** | `sramlib` → `rtl/mem/backends/fpga/sram_fpga_1rw.sv`; `extmem_ram.sv` in `silicaflux-extmem-bridge-p24.zip` | Library template = synchronous read, per-lane write enable, no reset. `extmem_ram` is a 1W/1R buffer with **asynchronous** read (LUT-RAM) and says to replace it by a library 1R1W for an ASIC. |
| **MBIST / test bus** | `silicaflux-testcore-p07.zip`; `sram_mbist_*` in the library | TestCore collar bus format, adopted by the library's test port. Not part of this core (see §5). |
| **Test infrastructure** | `sramlib` → `tb/mem/tb_common.svh`, `scripts/mem/run_regress.py`, `Makefile` (`mem-*` targets) | Deterministic xorshift PRNG, `SRAM_RESULT` line, Verilator/Icarus runners with provenance JSON. Adopted here. |
| **House RTL rules** | cited in `extmem_ram.sv`, `extmem_rob.sv` | "rule 4": datapath storage has no reset; "rule 5": technology cells sit behind wrappers. Both followed. |

## 3. Conventions adopted from the repository

* Raw single-port contract `ce, we, wmask, addr, wdata → rdata`; **word** addresses; lane `l` = bits `[l*LW +: LW]` (little-endian).
* Array and data registers never reset; only control/valid state is reset by `rst_n` (active low, asynchronous assert,
  synchronous release).
* Invalid addresses never touch the array and are **flagged, never silent** (library: `rsp_err` / `wr_err`).
* `rdata` is valid only in its read slot; the library poisons it with X otherwise in simulation (`SRAMLIB_POISON`) —
  here `SF_SRAM_POISON`.
* `` `define `` header instead of a package (Yosys 0.33 limitation noted by the library), `$fatal` in a generate block for
  illegal parameters (with the Icarus time-0 workaround), `Classification: SYNTHESIZABLE` header comments.
* Testbench result line `SRAM_RESULT <PASS|FAIL> tb=… seed=… checks=… errors=…` and provenance-carrying JSON reports.

## 4. Reuse decisions

| Item | Decision | Why |
|---|---|---|
| `sram_defs.svh`, `sram_generic_1rw.sv`, `sram_fpga_1rw.sv`, `tb_common.svh` | **Vendored unmodified** under `third_party/silicaflux-sramlib/` (SHA-256 verified, see `PROVENANCE.md`). Used only by testbenches: `tb_common.svh` everywhere, the two raw backends as independent references in `tb_sf_sram_xcheck`. | They are the verified implementation of the same raw contract; matching them cycle for cycle is the strongest available reuse evidence. |
| `sram_sp` / `sram_bank_controller` as the implementation | **Not used as a dependency.** | They add valid/ready, credits, response FIFOs, ID tags and an MBIST mux. The requested core is the simpler building block *below* that: no handshake, always-accept, fixed latency. Those wrappers remain the right choice where backpressure or MBIST is needed. |
| Library ASIC backend | **Not instantiated here.** | No PDK or macro views are available; `sf_sram_array` keeps the library's raw-backend port shape so a macro can replace it (docs/03 §4), but this path is **not exercised** by this package. |

What this core adds over `sram_backend_1rw` + `sram_sp`: explicit `ADDR_WIDTH` and `BYTE_WIDTH` parameters, a four-way `INIT_MODE`,
a bounds check at the raw level with `rd_valid / rd_err / wr_ack / wr_err` and no handshake, simulation assertions for invalid
accesses and X controls, an interface bundle with a temporal protocol checker, and mutation / gate-level evidence.

## 5. Not present, not assumed, not built here

Dual-port (1R1W / 2RW) variants (use `sram_1r1w` / `sram_tdp`; policy declared in docs/01 §9), MBIST test port, SECDED/parity
generation, macro tiling, handshake/credit protocol, SRAM banking.
