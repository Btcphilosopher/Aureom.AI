# 04 — Status against the definition of done, open items, next actions

## 1. Definition of done

> *The module supports deterministic synchronous operation, correct byte writes, explicitly defined timing and successful automated verification.*

| Clause | Status | Evidence |
|---|---|---|
| Deterministic synchronous operation | met in simulation | single clock, no asynchronous read, no latches (Yosys), fixed latency; cycle-exact scoreboard over every cycle of every run; identical stimulus and results in Verilator and Icarus (`xsim`) |
| Correct byte writes | met in simulation | exhaustive masks for ≤ 8 lanes, zero strobes, preservation, neighbour isolation; mutants M01–M05 caught; gate-level netlists pass |
| Explicitly defined timing | met | docs/01 §3–4; checked per cycle by the scoreboard and by the interface's protocol checker |
| Successful automated verification | met | `make sram-all` → `reports/SUMMARY.md` |

"Met in simulation" is literal: simulation (Verilator 5.020, Icarus 12.0) and Yosys 0.33 are the only tools used.

## 2. Process requirement from the brief

*Start with a single-port 32-bit SRAM, verify it, then generalise.*  Done in that order: `sf_sram_core` was built and verified at 32-bit × 1024
(Verilator, 3 seeds, and Icarus; two hand-injected bugs confirmed the testbench could fail) before the 64-bit, width, depth, latency, init-mode and
interface generalisations were added.  Building the generalisation exposed three testbench mistakes (not RTL defects): directed phases that assumed
depth ≥ 6, a coverage rule that assumed ≥ 2 lanes, and a 2-state `bit` argument that swallowed an X stimulus.  All were fixed in the testbench and the
RTL was not changed to hide them.

## 3. What is *not* done

| Item | Why | Impact |
|---|---|---|
| ASIC macro integration and any ASIC area / power / access-time number | no PDK, liberty file or SRAM compiler available | none produced; `INIT_MODE=NONE` configuration and the replacement contract are documented (docs/03) |
| Vendor FPGA tools (Vivado / Quartus / Radiant), place-and-route, timing, board | not installed | block-RAM inference is Yosys-only evidence; read-during-write mode and output-register absorption are unverified on vendor tools |
| Gate-level simulation of Xilinx RAMB and ECP5 DP16KD netlists | shipped Yosys models contain only timing data | covered by inference evidence only |
| Formal proofs | SymbiYosys not installed | properties are checked by simulation, mutation and gate-level runs, not proved |
| Dual-port option | out of scope for a single-port core | collision policy declared in docs/01 §9 |
| MBIST port, SECDED / parity generation, handshake / credits | belong to the library wrappers / RAS | use `sram_sp`, `sfras_secded_*` around or beside this core |
| Line / toggle coverage by a tool | none available | counter-based functional coverage only |

## 4. Known characteristics worth knowing before integration

* `READ_LATENCY ≥ 2` adds fabric registers under Yosys `synth_xilinx` (not absorbed into the block RAM output register).
* A 12-bit port on a 1024-word array (or any non-power-of-two depth) adds a comparator: on xc7 the 32-bit × 1024 core uses 42 LUTs / 4 flip-flops with the
  12-bit port versus 8 LUTs / 2 flip-flops with the minimal 10-bit port (`reports/synth.md`, Yosys, no vendor tool).  Use the minimum `ADDR_WIDTH` and
  power-of-two depths where invalid addresses cannot occur.
* `BYTE_WIDTH < 8` maps to block RAM in Yosys but needs more logic or narrower RAMs; prefer 8 or 9.
* `rdata` is gated to zero on `rd_err`; see docs/03 §5 for the trade-off.

## 5. Prioritised next actions

1. Run the flow with Vivado and Quartus (or at least their synthesis) on the example configurations; check inferred RAM, read-during-write mode and
   whether latency-2 merges into the output register.
2. Add SymbiYosys proofs: no-alias, timing of `rd_valid` / `wr_ack`, reset behaviour (the temporal checker in `sf_sram_if` is a ready property source).
3. Integrate an ASIC macro through the library's `sram_backend_1rw` as `sf_sram_array`, after PDK macro views exist; rerun `sram-all` with the replacement.
4. First consumers: ControlCore local memory (`INIT_MODE=FILE` for FPGA, loader for ASIC), tensor operand buffers (64-bit, latency 1), vector scratchpad banks
   (64-bit, latency 2).
5. Decide whether a 1R1W sibling is required; if so reuse the library's collision policies (docs/01 §9) and validate `READ_OLD` per tool before relying on it.
