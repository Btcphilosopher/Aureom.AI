# 01 — Interface and semantics (normative)

`sf_sram_core` is a **single-port, synchronous, always-accept** SRAM: one access per clock, no ready signal, fixed
response timing.  Everything below is checked by the testbench; section 10 maps each rule to the check that enforces it.

## 1. Parameters

| Parameter | Default | Rule (violation fails elaboration with the quoted message) |
|---|---|---|
| `DATA_WIDTH` | 32 | multiple of `BYTE_WIDTH`, ≥ `BYTE_WIDTH` — *"DATA_WIDTH must be a multiple of BYTE_WIDTH"*. Verified: 32 and 64; sweep also 8, 16, 24, 28 (4-bit lanes), 72 (9-bit lanes), 128 |
| `DEPTH_WORDS` | 1024 | ≥ 2, any value (not only powers of two) — *"DEPTH_WORDS must be >= 2"* |
| `ADDR_WIDTH` | `clog2(DEPTH_WORDS)` | 1…30 and ≥ `clog2(DEPTH_WORDS)` — *"ADDR_WIDTH must be in 1..30"*, *"some words would be unreachable"*. Wider than the minimum makes invalid addresses representable even for power-of-two depths |
| `BYTE_WIDTH` | 8 | ≥ 1; lane width. 9 supports `{parity, byte}` lanes (BufferCore) |
| `READ_LATENCY` | 1 | ≥ 1 — *"asynchronous read is not supported"* |
| `INIT_MODE` | `SF_SRAM_INIT_NONE` | `NONE`/`ZERO`/`FILE`/`PATTERN` (§8); `FILE` needs `INIT_FILE`; `PATTERN` is rejected when `SYNTHESIS` is defined |
| `INIT_FILE` | `""` | `$readmemh` image for `INIT_MODE=FILE` |
| `WRITE_ACK` | 1 | 0 or 1 |
| `OOB_ASSERT` | 1 | 0 or 1; simulation reports invalid accesses with `$error` (§7) |

`LANES = DATA_WIDTH / BYTE_WIDTH` (4 for 32-bit, 8 for 64-bit) is derived.

## 2. Ports

| Port | Dir | Width | Meaning |
|---|---|---|---|
| `clk` | in | 1 | rising-edge clock; the only clock |
| `rst_n` | in | 1 | active low; asynchronous assert, **synchronous release** (release from a reset synchroniser). Resets only the response pipelines — never the array or the read data registers |
| `ce` | in | 1 | 0 = idle cycle; 1 = one access |
| `we` | in | 1 | with `ce`: 1 write, 0 read |
| `addr` | in | `ADDR_WIDTH` | **word** address |
| `wmask` | in | `LANES` | byte enables; lane `l` = data bits `[l*BYTE_WIDTH +: BYTE_WIDTH]`, lane 0 = least significant byte |
| `wdata` | in | `DATA_WIDTH` | write data (lanes with `wmask=1`) |
| `rdata` | out | `DATA_WIDTH` | read data — meaningful **only** in a cycle with `rd_valid=1` |
| `rd_valid` | out | 1 | one pulse per accepted read, `READ_LATENCY` cycles later |
| `rd_err` | out | 1 | with `rd_valid`: the read address was invalid; `rdata` = 0 |
| `wr_ack` | out | 1 | `WRITE_ACK=1`: one pulse per accepted write, 1 cycle later (invalid writes too, together with `wr_err` = NAK). `WRITE_ACK=0`: tied low |
| `wr_err` | out | 1 | one pulse, 1 cycle after an **invalid** write — always generated, also with `WRITE_ACK=0` |

Port names follow the SRAM Wrapper Library's raw contract (`ce, we, wmask, addr, wdata, rdata`), so the array can be
exchanged with a library backend (docs/03 §4).  `sf_sram_if` bundles the same signals with `master / slave / monitor` modports.

## 3. Timing

"Cycle *t*" is the clock cycle in which the request inputs are presented; they are sampled at the rising edge that ends it.

```
READ_LATENCY = 1, WRITE_ACK = 1              READ_LATENCY = 2
cycle      t    t+1   t+2   t+3              cycle      t    t+1   t+2   t+3
ce         1     1     1     0               ce         1     1     0     0
we         0     1     0     -               we         0     0     -     -
addr       A     A     A     -               addr       A     B     -     -

rd_valid   0     1     0     1               rd_valid   0     0     1     1
rdata      -     M[A]  -     M[A]'           rdata      -     -     M[A]  M[B]
wr_ack     0     0     1     0               (reads at t, t+1 -> responses at t+2, t+3)
```
Left: read A (*t*), write A (*t*+1), read A (*t*+2).  The first read returns the old word `M[A]` (write-after-read), the write is
acknowledged in *t*+2, and the read in *t*+2 returns `M[A]'`, the **new** word (read-after-write in the next cycle).  A read
presented in any cycle after a write observes it.

| Event | Rule |
|---|---|
| Read presented in cycle *t* | `rd_valid` and `rdata` in cycle *t* + `READ_LATENCY` (exactly; one pulse; `rdata` not held afterwards) |
| Write presented in cycle *t* | array updated at the edge ending *t*; `wr_ack` (if `WRITE_ACK`) in cycle *t*+1; every read presented in a cycle ≥ *t*+1 observes it |
| Throughput | one access per cycle in any mix; no wait states, nothing to stall |
| `rdata` outside `rd_valid` | undefined. In simulation with `SF_SRAM_POISON`, driven to X so a consumer that relies on it being held fails |

## 4. Operation semantics (every case defined)

| Case | Behaviour |
|---|---|
| **Read** (`ce=1, we=0`, valid address) | array read; response as §3. `wmask`/`wdata` ignored |
| **Write** (`ce=1, we=1`, valid address) | lanes with `wmask=1` take `wdata`; all other lanes **keep their value** (no read-modify-write is visible) |
| **Zero write strobes** (`we=1, wmask=0`) | a legal write that changes nothing; still acknowledged (`WRITE_ACK=1`) |
| **Full-word write** (`wmask` all ones) | whole word replaced |
| **Disabled cycle** (`ce=0`) | no array access, no response, no state change; `we/addr/wmask/wdata` are don't-care (the testbench drives noise there, including `we=1`) |
| **Back-to-back reads** | one per cycle, responses one per cycle, in order |
| **Back-to-back writes** | one per cycle; the later write wins on the same word and lane |
| **Read-after-write** (write in *t*, read in *t*+1, same word) | returns the **new** data (the write is complete at the edge) |
| **Write-after-read** (read in *t*, write in *t*+1, same word) | the read returns the **old** data |
| **Same-cycle read and write** | cannot occur: one port, `we` selects exactly one operation per cycle. There is therefore no same-address read/write collision in this core |
| **Write cycle and `rdata`** | a write produces no read data ("no-change": the read register is untouched) |
| **Access during reset** (`rst_n=0`) | ignored: no array access, no response, in-flight responses dropped |

## 5. Byte enables

`wmask[l]=1` writes lane `l` (`BYTE_WIDTH` bits).  32-bit: four independent enables; 64-bit: eight.  Any combination is legal;
lane order is little-endian.  A partial write never needs a read-modify-write by the user.  Verified: every single lane,
every mask combination (exhaustive for ≤ 8 lanes, walking-1 / walking-0 / random otherwise), full word, zero strobes,
untouched-byte preservation, neighbouring-word isolation and lane-by-lane assembly of a word.

## 6. Bounds policy (hardware-compatible, no silent aliasing)

An address is **invalid** when `addr >= DEPTH_WORDS`.  This is possible whenever `DEPTH_WORDS` is not `2**ADDR_WIDTH` — a
non-power-of-two depth, or an address port wider than needed.  The policy:

1. The comparison is made **at the port**, one comparator against a constant.  When `DEPTH_WORDS == 2**ADDR_WIDTH` it is the
   constant 1 and costs nothing.
2. An invalid access **never reaches the array** (`ce` to the array is gated): no read, no write, **no aliasing** onto a valid word
   (no wrap-around, no truncation, no mirror).
3. It is **answered, not dropped**, with the same timing as a valid access of its kind: a read gives `rd_valid=1, rd_err=1, rdata=0`
   after `READ_LATENCY`; a write gives `wr_err=1` after one cycle (and `wr_ack=1` when `WRITE_ACK=1`).  Because errors are never
   silent, `wr_err` is produced even when writes are posted.
4. The boundary is exact: `DEPTH_WORDS-1` is valid, `DEPTH_WORDS` is not (mutation M07 proves an off-by-one is caught).
5. In simulation, `OOB_ASSERT=1` additionally reports every invalid access with `$error` (§7).

Rationale: a comparator and one flag pipeline are what a macro wrapper can implement in hardware; stalling, wrapping or reading
back "don't care" data would either need handshake, hide software bugs, or break determinism.  Cost is visible in
`reports/synth.md` (rows with a 12-bit address port on a 1024-word array).

## 7. Assertions (simulation only; excluded when `SYNTHESIS` is defined)

| Message | When | Verified by |
|---|---|---|
| elaboration `$fatal` (`g_err_*` blocks) | any illegal parameter (§1) | `neg` suite: 16 illegal sets rejected in Verilator, Icarus and Yosys |
| `SF_SRAM_ASSERT_OOB` | an access with an invalid address (`OOB_ASSERT=1`) | `tb_sf_sram_assert`: exactly 5 for 5 invalid accesses (3 reads, 2 writes, one with zero strobes) |
| `SF_SRAM_ASSERT_X` | `ce` X/Z out of reset; `we`/`addr` X/Z during an access; `wmask` X/Z during a write | `tb_sf_sram_assert` (4-state, Icarus) |
| `SF_SRAM_ASSERT_INT` | `rd_err` without `rd_valid` | never fires in any run |
| `SF_SRAM_IF_*` | interface protocol checker: `rd_valid`/`wr_ack` timing, X on controls/flags | `tb_sf_sram_if` runs it throughout |

Verilator terminates at the first `$error` (default error limit 1), so any assertion hit in a normal regression fails the run.

## 8. Initial content (`INIT_MODE`)

| Mode | Content at power-up | Use |
|---|---|---|
| `NONE` | undefined (X in a 4-state simulator) | **the only mode that matches an ASIC macro**; default |
| `ZERO` | all zero | FPGA block RAM (bitstream init), simulation |
| `FILE` | `$readmemh(INIT_FILE)` | FPGA, simulation (boot images) |
| `PATTERN` | deterministic non-zero word per address (formula in `sf_sram_array.sv`) | simulation only; lets a 2-state simulator prove nothing depends on zero |

The array is never reset, so none of this changes at run time.  **Unwritten SRAM is not assumed to be zero** anywhere in
the verification (§ docs/02).

## 9. Dual-port extension (declared, not implemented)

Not built: with one port the collision cannot occur.  If a 1R1W or 2RW option is added, its same-address read-during-write behaviour must
be one of the policies the SRAM Wrapper Library already defines (`sram_defs.svh`, `docs/mem/01_interface_spec.md` §6) and be validated per
technology before use:

| Policy | Behaviour | Technology validation |
|---|---|---|
| `STALL` (default) | a same-address read+write pair is never issued together; one side waits; alternating priority | valid on every backend |
| `READ_OLD` | both issued, the read returns the pre-write word | only where the memory guarantees it: FPGA inference must preserve RTL read-first semantics (tool-specific, to be checked per tool); **rejected for ASIC** — the library records that SKY130 OpenRAM and IHP dual-port macros define same-address cross-port access as undefined |
| `FORBID` | the master guarantees no collision; assertion | all |

Until then, use the library's `sram_1r1w` / `sram_tdp`.

## 10. Rule → check map

| Rule | Enforced by |
|---|---|
| Response timing (`rd_valid`, `rdata`, `wr_ack`, `wr_err`, exact cycle, every cycle) | cycle-exact scoreboard (`sf_tb_body.svh`); mutants M11, M12, M17 |
| Byte enables, zero strobes, preservation | `p_byte_enables`, random masks; mutants M01–M05 |
| Disabled cycles | `p_disabled`, random `ce=0` with `we=1` noise; M06 |
| Bounds / no aliasing / errors never silent | `p_invalid`, random invalid traffic, full-array comparison after; M07, M08, M16, M18; assertion TB |
| Reset behaviour, retention across reset | `p_reset`, `p_retention`, resets inside random traffic; M13, M14, M15 |
| Init modes | `p_init_sweep` before any write; M19, M20 (Verilator), M21 (Icarus) |
| `rdata` only valid with `rd_valid` | Icarus poison check; M22 |
| Equivalence with the verified library backends | `tb_sf_sram_xcheck` (GENERIC and FPGA templates, 5 configs × 2 seeds + Icarus) |
