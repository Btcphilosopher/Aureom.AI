# 03 — Implementation: inferred FPGA RAM versus ASIC SRAM macros

## 1. Structure

```
sf_sram_core            control policy: bounds check, response pipelines, reset gating, assertions, poison
 └─ sf_sram_array       storage: one-port memory, per-lane write enables, READ_LATENCY read pipeline, INIT_MODE
```

Only `sf_sram_array` knows how the bits are stored.  Everything that defines behaviour visible to a user (timing, error flags,
reset) is in `sf_sram_core` and is independent of the storage technology.

## 2. The inferred-memory implementation

`sf_sram_array` is written in the single-port byte-write template that FPGA synthesis tools recognise: one clock, per-lane write enables
in a `for` loop, read in the `else` branch of the write enable ("no-change"), **no reset on any storage or output register, no
asynchronous read, no vendor primitive**.

| Requirement (brief §6) | How it is met |
|---|---|
| Do not reset the whole array | the array has no reset port; `rst_n` reaches only the valid/error flags |
| No unnecessary asynchronous read | the read is registered; Yosys reports the inferred memory with a **synchronous read port** for every configuration (`reports/synth.md`) |
| No unsupported simulation constructs | no classes, queues, delays or `force` in RTL; simulation-only code is behind `ifndef SYNTHESIS` and verified in Verilator and Icarus |
| No hardcoded clock-frequency claims | none anywhere in the RTL or documents; no timing numbers exist in this package |

Evidence (Yosys 0.33, see `reports/synth.md`): the array is inferred as exactly one memory per configuration; `synth_xilinx -family xc7`
maps 32×1024 to one `RAMB36E1`, 64×1024 to two, 512 KiB to 128, with no memory left unmapped; `synth_ice40` maps to `SB_RAM40_4K`;
`synth_ecp5` to `DP16KD`; 9-bit lanes and a 4-bit-lane example also map to block RAM; latch count is zero.  Gate-level simulation
of the generic, distributed-RAM (xc7 `-nobram`) and iCE40 netlists passes with the same testbench.

Properties of the template that matter when moving between tools:

* **Same-port read during write.**  A write cycle produces no read data, and `rdata` is only used under `rd_valid`, so the RAM's
  read-during-write mode is unobservable.  Block-RAM modes (read-first / write-first / no-change) therefore do not change behaviour — **not
  verified on real vendor tools here**.
* **`READ_LATENCY`.**  1 = the memory read register.  2 and above add register stages with no reset and no enable, which a vendor tool *may*
  merge into the block RAM's output register.  Yosys 0.33 keeps them in fabric (35 flip-flops at latency 2 for 32-bit data, versus 2 at latency 1).
* **Lane width.**  Vendor block RAMs offer byte-granular write enables (8 or 9 bits).  `BYTE_WIDTH=4` was still mapped to block RAM by Yosys
  (2 × `RAMB36E1` plus 44 LUTs for the 28×600 example) — expect extra logic or more, narrower RAMs, not a failure.
* **Initial content.**  `INIT_MODE=ZERO/FILE` become block-RAM initial values.  `PATTERN` is simulation-only and rejected under `SYNTHESIS`.
* **Resource choice.**  No `ram_style` attribute is applied; the tool chooses.  Add `(* ram_style = "block" *)` (Xilinx) or the vendor equivalent at
  the call site if a specific resource is required.

## 3. ASIC SRAM macros — what is different

An ASIC SRAM is a hard macro from a compiler or a PDK, not inferred logic.  The array-level differences and how this core treats them:

| Topic | Inferred FPGA RAM | ASIC SRAM macro | Consequence here |
|---|---|---|---|
| Power-up content | defined by bitstream (`ZERO`/`FILE`) or unspecified | **undefined**; no initialisation | `INIT_MODE=NONE` is the only ASIC-compatible mode; the SRAM library rejects `INIT_FILE` for ASIC macros. A boot image needs a ROM macro or a loader |
| Reset of contents | none | none | the core never resets storage; retention across controller reset is a tested property |
| Sizes | any depth/width, tool tiles block RAMs | a **catalogue** of macro sizes and aspect ratios, tiled by a wrapper | non-power-of-two depth, odd widths and `BYTE_WIDTH` ≠ 8 may need padding or tiling; the core's bounds check keeps the unused range unreachable |
| Write mask | byte (8/9-bit) granularity on block RAM | bit-mask or byte-mask depending on macro (the library lists SKY130 OpenRAM, GF180MCU bit-mask and IHP SG13G2 macros) | map `wmask` lanes onto the macro's mask granularity in the array replacement |
| Read data after the edge | registered output, held until the next read | macro output may not be held (the library records that the SKY130 OpenRAM model drives X one hold time after each clock edge) | the contract already says `rdata` is valid only in its read slot; `SF_SRAM_POISON` catches consumers that rely on hold |
| Access latency | tool-chosen (1, +1 with output register) | macro-defined; `READ_LATENCY` must be ≥ the macro's native latency | no latency or timing number is claimed for any macro in this package |
| Same-address dual-port access | read-first possible by inference | the library records SKY130 OpenRAM and IHP dual-port macros as undefined for cross-port same-address access | single-port here; see docs/01 §9 |
| Test / repair | none | macros are usually wrapped with BIST/MBIST (IHP macro names carry `bist`) | no MBIST port in this core; use the library's `sram_sp` with `TEST_EN` where needed |
| Simulation model | the inferred array itself | vendor behavioural model, often X-pessimistic around the clock edge | keep `INIT_MODE=NONE` tests and X checks (done under Icarus) |

**Flip-flop numbers from a generic synthesis run are not SRAM area.**  `reports/synth.md` deliberately reports only the glue logic of
`sf_sram_core`; the array's flip-flops under generic mapping are the array bits turned into flops.  **No ASIC area, power or access-time number exists
in this package.**  The ASIC flow was not run (no PDK, liberty file or SRAM compiler in this environment).

## 4. Replacing the array by a macro

Keep `sf_sram_core` unchanged; provide another module named `sf_sram_array` (or an alternative array parameter at integration) with the same ports.  The
port shape equals the SRAM Wrapper Library's raw `sram_backend_1rw`:

| `sf_sram_array` | `sram_backend_1rw` | Note |
|---|---|---|
| `ce`, `we`, `wmask`, `wdata`, `rdata` | same names | `LANES` = `MASK_WIDTH`, lane width = `BYTE_WIDTH` |
| `idx` | `addr` | `sf_sram_core` only passes valid indices (`idx < DEPTH_WORDS`) |
| `READ_LATENCY` | `READ_LATENCY` | read data valid exactly that many cycles after the read edge, one cycle, not held |
| `DEPTH_WORDS` | `DEPTH` | |
| `INIT_MODE`/`INIT_FILE` | — | must be `NONE` for ASIC macros |

```systemverilog
// Sketch (NOT compiled or tested in this package): library ASIC backend as the array.
module sf_sram_array #(parameter int DATA_WIDTH = 32, DEPTH_WORDS = 1024, BYTE_WIDTH = 8, READ_LATENCY = 1,
                       parameter int INIT_MODE = 0, parameter INIT_FILE = "",
                       localparam int IDX_WIDTH = $clog2(DEPTH_WORDS), LANES = DATA_WIDTH / BYTE_WIDTH)
  (input wire clk, ce, we, input wire [LANES-1:0] wmask, input wire [IDX_WIDTH-1:0] idx,
   input wire [DATA_WIDTH-1:0] wdata, output logic [DATA_WIDTH-1:0] rdata);
  sram_backend_1rw #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH_WORDS), .MASK_WIDTH(LANES), .READ_LATENCY(READ_LATENCY),
                     .BACKEND(`SRAM_BACKEND_ASIC), .MACRO(/* catalogue id */ 0)) u (.clk, .ce, .we, .wmask, .addr(idx), .wdata, .rdata);
endmodule
```

This path is **not exercised** here.  The evidence that it is contract-safe is indirect: `tb_sf_sram_xcheck` shows the core's array is cycle-for-cycle
equivalent to the library's GENERIC and FPGA raw backends, and the library verifies its own ASIC leaf cells against the vendor models
(its report, not re-run).

## 5. Design trade-offs

* `rdata` is zeroed on an invalid read by a gate after the array output (deterministic response, one AND level after the memory read register).  A
  design with a critical read path may instead treat `rdata` as don't-care whenever `rd_err=1`; that changes the contract and the checks.
* `rst_n` gating of accesses (`ce & rst_n`) is a synchronous qualifier because `rst_n` is released synchronously.  Releasing it asynchronously is not
  supported.
* Always-accept (no `ready`) keeps the core trivially pipelined; any backpressure, response buffering or arbitration belongs in a wrapper such as the
  library's `sram_sp`.
