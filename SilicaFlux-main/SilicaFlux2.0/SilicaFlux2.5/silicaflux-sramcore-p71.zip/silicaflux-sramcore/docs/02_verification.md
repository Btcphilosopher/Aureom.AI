# 02 — Verification

Run everything with `make sram-all`; results land in `reports/` (`SUMMARY.md` first).  Every report embeds the exact
commands, exit codes, seeds and tool versions.

## 1. Method

* **Independent reference model** (`sf_tb_body.svh`): bit-granular `value`/`known` arrays updated with bit loops, structurally
  different from the RTL's lane part-select writes.  `known` records which bits have a *defined expected value*.
* **Unwritten SRAM is not assumed to be zero.**  With `INIT_MODE=NONE` nothing is known until written; only reads of known bits
  are compared.  To keep that honest: Verilator runs with `--x-initial unique +verilator+rand+reset+2` (arrays start random),
  and under Icarus (4-state) every bit that was never written must read back as **X** — a model that silently zero-fills fails
  (mutant M21).  `INIT_MODE=ZERO/FILE/PATTERN` define initial content and are checked from the first read.
* **Cycle-exact scoreboard.**  At every clock the DUT outputs are compared with the expectation derived from the request accepted
  `READ_LATENCY` (read) or 1 (write) cycles earlier.  `rd_valid`, `rd_err`, `wr_ack`, `wr_err` are checked **every cycle**, so a
  missing, spurious, early or late response fails.  Read data is compared on all known bits; an invalid read must return zeros.
* **Reproducible stimulus.**  Deterministic xorshift PRNG from the repository's `tb_common.svh`; PRNG-consuming calls are
  sequenced explicitly because SystemVerilog leaves argument evaluation order undefined — the same seed produces the same stimulus
  in Verilator and Icarus (`xsim` suite compares the metric line).
* **Directed phases, then constrained-random** with random gaps, noise on don't-care inputs, resets and invalid addresses,
  then a final full-array readback and coverage counters that must all be non-zero.

## 2. Requirement → test

| Brief (§8) | Where | Notes |
|---|---|---|
| Every address | `p_every_address`, `p_init_sweep`, `final_sweep`, full sweep after invalid-address traffic | unique data per address, two passes (ascending full words, descending random masks), plus isolated read/write per address |
| First and last word | `p_first_last` | also words 1 and `DEPTH-2` |
| Random writes / reads | `p_random` | `+nrand` cycles (30 000 default); hot set including 0 and `DEPTH-1` |
| Partial writes | `p_byte_enables`, random masks | single lane, exhaustive masks (≤ 8 lanes), walking patterns, zero strobes, preservation, neighbours, lane-by-lane assembly |
| Repeated writes | `p_repeated` | 24 consecutive overwrites; last writer wins; different masks |
| Back-to-back | `p_back_to_back` + random | W-W, R-R, W-R, R-W, same-address R-A-W, alternation; coverage counters prove each occurred |
| Reset | `p_reset` | in-flight responses dropped, access during reset ignored, async assert mid-run, reset with input noise |
| Read latency | scoreboard (every read, every cycle) + `p_latency` | `measured == READ_LATENCY` and `wr_ack` one cycle after a write |
| Invalid addresses | `p_invalid`, random invalid traffic, `tb_sf_sram_assert` | exhaustive sweep of every invalid address (or ≤ 4096 samples), boundary, zero-strobe invalid write, invalid next to valid; whole array re-read afterwards |
| Data retention across controller reset | `p_retention`, resets inside random traffic | fill → reset ×3 (with noise) → 300 idle cycles → read all |
| Independent reference memory | `rm_val` / `rm_knw` | see §1 |
| Do not assume zero | §1 | M21 proves the check has teeth |

## 3. Configurations (`make sram-test`)

Primary and generalisation sweep, each with the full phase list; seeds in `scripts/common.py`.

| Group | Configurations |
|---|---|
| **Primary — 32-bit × 1024, 1-cycle read, byte enables** | 3 seeds Verilator + Icarus; `WRITE_ACK=0`; latency 2 and 3; 12-bit address port; non-power-of-two (1000) depth; `INIT_MODE` ZERO / PATTERN / FILE |
| **64-bit × 1024 (additional verified configuration)** | 3 seeds Verilator + Icarus; posted writes; latency 2; 1000 words on an 11-bit port; FILE and PATTERN init |
| Widths / depths / lanes | 8×256 (1 lane), 16×512, 24×300 (3 lanes), 72×256 (9-bit lanes), 128×64 (16 lanes), 32×2 (minimum depth), 32×3 (one invalid address), 32×4096 (latency 2) |

Beyond `sim`: `xsim` (same stimulus in both simulators), `xcheck` (§4), `assert` (§5), `if` (§6), `lint`, `neg`.

## 4. Cross-check against the verified library (`tb_sf_sram_xcheck`)

The same random traffic drives `sf_sram_core`, the library's `sram_generic_1rw` and `sram_fpga_1rw` (vendored unmodified).  Read data
must be identical in identical cycles for 16, 32 and 64-bit words and latency 1–3, and `rd_valid` must equal "a read was issued
`READ_LATENCY` cycles ago".  Only valid addresses are used: the raw library backends define no bounds behaviour.

## 5. Assertions and illegal parameters

`neg`: 16 illegal parameterisations (bad widths, depths, address widths, latencies, flags, init modes, `PATTERN` under `SYNTHESIS`) must be rejected
by Verilator (message text checked), Icarus (time-0 `$fatal`) and Yosys (`hierarchy` fails).  `assert`: `SF_SRAM_ASSERT_OOB` and
`SF_SRAM_ASSERT_X` messages are counted and must equal the expected numbers; `SF_SRAM_ASSERT_INT` must never fire.

## 6. SystemVerilog interface

`tb_sf_sram_if` runs the identical testbench body through `sf_sram_if` + `sf_sram_core_if` (Verilator only: Icarus 12 and Yosys 0.33
lack SV-interface support) with the interface's own temporal protocol checker active.

## 7. Mutation sanity (`make sram-mutants`)

22 realistic RTL bugs are injected one at a time and the testbench must fail on each (byte-lane mapping, enable polarity, cleared
unselected lanes, zero-strobe corruption, write with `ce=0`, bounds off-by-one, silent aliasing, MSB ignored, last word missing, early
`rd_valid`, early data, responses surviving reset, access during reset, **controller reset clobbering array content**, stale data on invalid read,
missing acknowledgement, silent invalid write, three init-mode bugs, X-poison removed).  A mutant that survives, or does not apply exactly once,
fails the target.  See `reports/mutants.md`.

## 8. Gate-level simulation (`make sram-gls`)

Synthesised netlists (generic gates; xc7 forced to distributed RAM; iCE40 block RAM) are simulated with the same testbench and
Yosys' behavioural cell models.  **Xilinx RAMB and ECP5 DP16KD block-RAM netlists cannot be simulated**: the models shipped with this Yosys
contain only timing data (verified: no `always`/`assign`/`initial` statements), so they drive nothing.  Those flows have inference evidence only
(`reports/synth.md`).

## 9. What this does *not* show

* No formal proof (SymbiYosys is not installed).  Bounded or unbounded proofs of the timing and no-alias properties would be the next step.
* No vendor tool (Vivado, Quartus, Radiant) was available: inference is checked with Yosys; vendor-specific read-during-write mode choices and
  output-register absorption are **unverified**.  Yosys 0.33 `synth_xilinx` does not merge the second read stage into the RAMB output register
  (see the 35 vs 2 flip-flops in `reports/synth.md` for latency 2 vs 1).
* No timing, area, power, board or silicon results, no ASIC macro integration.
* Functional coverage is counter-based (all categories hit), not tool-measured line/toggle coverage.
* Simulators: Verilator 5.020 and Icarus 12.0 only (the repository's `xsim` row refers to cross-simulation, not to Vivado xsim).
