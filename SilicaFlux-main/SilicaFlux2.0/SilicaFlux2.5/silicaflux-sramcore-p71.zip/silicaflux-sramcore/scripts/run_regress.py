#!/usr/bin/env python3
"""SRAMCore regression driver.

Suites (comma separated, or "all"):
  lint     Verilator -Wall (zero warnings required) + Icarus -Wall elaboration of every configuration,
           the SV-interface wrapper and the configuration examples
  neg      illegal parameterisations must fail elaboration in Verilator, Icarus and Yosys
  sim      self-checking testbench, every configuration x seed, Verilator (all) and Icarus (ic=True)
  xsim     identical seed => identical stimulus in Verilator and Icarus (metric line compared)
  xcheck   sf_sram_core vs the vendored SRAM Wrapper Library raw 1RW backends (GENERIC and FPGA)
  assert   simulation assertions fire (and only) where expected
  if       the SV interface wrapper passes the same testbench body

Every report embeds commands, exit codes, seeds and tool versions.
"""
from __future__ import annotations

import argparse
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (BUILD, CONFIGS, IF_FILES, INC_DIRS, LIB_REF_FILES, NEGATIVE, REPORTS, ROOT, RTL, RTL_FILES, TB,  # noqa: E402
                    VL_SIM_FLAGS, ensure_hex, provenance, sh, src_hash, write_json)

RESULT_RE = re.compile(r"SRAM_RESULT (PASS|FAIL) tb=(\S+) seed=(\d+) checks=(\d+) errors=(\d+)")
BAD_TEXT = re.compile(r"%Error|%Warning-|Assertion failed|SF_SRAM_ASSERT|\$fatal|Segmentation|core dumped")
JOBS = 4
IC_NRAND = 8000          # Icarus is ~100x slower than Verilator; its random phase is shorter

CORE_MAP = {"DW": "DATA_WIDTH", "DEPTH": "DEPTH_WORDS", "AW": "ADDR_WIDTH", "BW": "BYTE_WIDTH", "LAT": "READ_LATENCY",
            "WACK": "WRITE_ACK", "INITM": "INIT_MODE", "INITF": "INIT_FILE"}
SRC_HASH = src_hash([*RTL.glob("*.sv"), *RTL.glob("*.svh"), *TB.glob("*"), *(ROOT / "third_party").rglob("*.sv*")])


def resolved(p: dict) -> dict:
    q = dict(p)
    if isinstance(q.get("INITF"), str) and q["INITF"].startswith("@hex:"):
        q["INITF"] = ensure_hex(q["INITF"])
    return q


def vl_pdefs(p: dict, top_params: bool = True) -> list[str]:
    out = []
    for k, v in resolved(p).items():
        out.append(f'-G{k}="{v}"' if isinstance(v, str) else f"-G{k}={v}")
    return out


def ic_pdefs(p: dict, top: str) -> list[str]:
    out = []
    for k, v in resolved(p).items():
        out.append(f'-P{top}.{k}="{v}"' if isinstance(v, str) else f"-P{top}.{k}={v}")
    return out


def inc(prefix: str) -> list[str]:
    return [f"{prefix}{d}" for d in INC_DIRS]


def parse_result(out: str) -> dict:
    m = RESULT_RE.search(out)
    r = {"result": "FAIL", "checks": 0, "errors": -1, "metric": "", "first_errors": []}
    if m:
        r.update(result=m.group(1), checks=int(m.group(4)), errors=int(m.group(5)))
    mm = re.search(r"^SRAM_METRIC (.*)$", out, re.M)
    if mm:
        r["metric"] = mm.group(1).strip()
    if r["result"] == "PASS" and BAD_TEXT.search(out):
        r["result"] = "FAIL"
        r["first_errors"].append("unexpected tool/assertion message in output")
    r["first_errors"] += [ln.strip() for ln in out.splitlines() if "SRAM_ERROR" in ln or "%Error" in ln][:5]
    return r


# --------------------------------------------------------------------------- builders
def vl_build(top: str, files: list[Path], params: dict, tag: str = "", extra: list[str] | None = None) -> tuple[Path, dict]:
    import hashlib, json
    key = hashlib.sha1(json.dumps([top, params, tag, [str(f) for f in files], extra, SRC_HASH], sort_keys=True, default=str).encode()).hexdigest()[:12]
    mdir = BUILD / "vl" / f"{top}_{key}"
    exe = mdir / "Vtb"
    if exe.exists():
        return exe, {"cmd": "(cached) " + str(mdir), "rc": 0, "out": "", "secs": 0}
    mdir.parent.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", *VL_SIM_FLAGS, *inc("-I"), *files, "--top-module", top, *vl_pdefs(params), *(extra or []),
           "--Mdir", mdir, "-o", "Vtb"]
    r = sh(cmd)
    return exe, r


def ic_build(top: str, files: list[Path], params: dict, tag: str = "") -> tuple[Path, dict]:
    import hashlib, json
    key = hashlib.sha1(json.dumps([top, params, tag, [str(f) for f in files], SRC_HASH], sort_keys=True, default=str).encode()).hexdigest()[:12]
    out = BUILD / "iv" / f"{top}_{key}.vvp"
    out.parent.mkdir(parents=True, exist_ok=True)
    if out.exists():
        return out, {"cmd": "(cached) " + str(out), "rc": 0, "out": "", "secs": 0}
    cmd = ["iverilog", "-g2012", "-DSF_SRAM_POISON", *inc("-I"), "-s", top, "-o", out, *ic_pdefs(params, top), *files]
    return out, sh(cmd)


# --------------------------------------------------------------------------- sim
def run_one(cfg: dict, seed: int, sim: str, nrand: int | None = None, top: str = "tb_sf_sram_core",
            files: list[Path] | None = None) -> dict:
    files = files or [*RTL_FILES, TB / "tb_sf_sram_core.sv"]
    p = cfg["p"]
    if sim == "verilator":
        exe, b = vl_build(top, files, p)
        rec = {"suite": "sim", "sim": sim, "cfg": cfg["name"], "params": p, "seed": seed, "build_rc": b["rc"]}
        if b["rc"] != 0:
            rec.update(result="FAIL", checks=0, errors=-1, first_errors=["build failed: " + b["out"][-400:]], metric="")
            return rec
        args = [exe, f"+seed={seed}", f"+verilator+seed+{seed}", "+verilator+rand+reset+2"]
    else:
        vvp, b = ic_build(top, files, p)
        rec = {"suite": "sim", "sim": sim, "cfg": cfg["name"], "params": p, "seed": seed, "build_rc": b["rc"]}
        if b["rc"] != 0:
            rec.update(result="FAIL", checks=0, errors=-1, first_errors=["build failed: " + b["out"][-400:]], metric="")
            return rec
        args = ["vvp", "-n", vvp, f"+seed={seed}"]
    if nrand is not None:
        args.append(f"+nrand={nrand}")
    r = sh(args)
    rec.update(parse_result(r["out"]))
    rec["run_rc"] = r["rc"]
    rec["secs"] = r["secs"]
    return rec


def suite_sim(only: str | None) -> list[dict]:
    cfgs = [c for c in CONFIGS if not only or re.search(only, c["name"])]
    jobs = []
    for c in cfgs:
        for s in c["seeds"]:
            jobs.append((c, s, "verilator", None))
        if c["ic"]:
            jobs.append((c, c["seeds"][0], "icarus", IC_NRAND))
    # build once per (cfg, sim) before the parallel runs (avoids duplicate concurrent builds)
    builds = {(c["name"], sim): (c, sim) for c, _, sim, _ in jobs}
    with ThreadPoolExecutor(JOBS) as ex:
        list(ex.map(lambda cs: (vl_build if cs[1] == "verilator" else ic_build)(
            "tb_sf_sram_core", [*RTL_FILES, TB / "tb_sf_sram_core.sv"], cs[0]["p"]), builds.values()))
        recs = list(ex.map(lambda j: run_one(j[0], j[1], j[2], j[3]), jobs))
    return recs


def suite_xsim() -> list[dict]:
    recs = []
    for c in [c for c in CONFIGS if c.get("xs")]:
        seed = c["seeds"][0]
        with ThreadPoolExecutor(2) as ex:
            fv = ex.submit(run_one, c, seed, "verilator", IC_NRAND)
            fi = ex.submit(run_one, c, seed, "icarus", IC_NRAND)
            v, i = fv.result(), fi.result()
        same = bool(v["metric"]) and v["metric"] == i["metric"]
        recs.append({"suite": "xsim", "cfg": c["name"], "seed": seed, "nrand": IC_NRAND,
                     "verilator": v["result"], "icarus": i["result"], "metric_verilator": v["metric"], "metric_icarus": i["metric"],
                     "checks_verilator": v["checks"], "checks_icarus": i["checks"], "stimulus_identical": same,
                     "result": "PASS" if (v["result"] == "PASS" and i["result"] == "PASS" and same) else "FAIL"})
    return recs


# --------------------------------------------------------------------------- lint
def core_overrides(p: dict) -> dict:
    return {CORE_MAP[k]: v for k, v in resolved(p).items() if k in CORE_MAP}


def vl_lint(files, top, ovr: dict, defs=(), wall=True) -> dict:
    cmd = ["verilator", "--lint-only", *(["-Wall"] if wall else []), *inc("-I"), *[f"-D{d}" for d in defs], *files,
           "--top-module", top]
    for k, v in ovr.items():
        cmd.append(f'-G{k}="{v}"' if isinstance(v, str) else f"-G{k}={v}")
    return sh(cmd)


def suite_lint() -> list[dict]:
    recs = []

    def lint_cfg(c):
        o = core_overrides(c["p"])
        v = vl_lint(RTL_FILES, "sf_sram_core", o)
        ok_v = v["rc"] == 0 and not re.search(r"%Warning|%Error", v["out"])
        recs.append({"suite": "lint", "tool": "verilator -Wall", "cfg": c["name"], "result": "PASS" if ok_v else "FAIL",
                     "detail": "" if ok_v else v["out"][-500:]})
        ic = sh(["iverilog", "-g2012", "-Wall", *inc("-I"), "-s", "sf_sram_core", "-o", BUILD / "lint_ic.vvp",
                 *[f"-Psf_sram_core.{k}=" + (f'"{x}"' if isinstance(x, str) else str(x)) for k, x in o.items()], *RTL_FILES])
        ok_i = ic["rc"] == 0 and not ic["out"].strip()
        recs.append({"suite": "lint", "tool": "iverilog -Wall", "cfg": c["name"], "result": "PASS" if ok_i else "FAIL",
                     "detail": "" if ok_i else ic["out"][-500:]})

    for c in CONFIGS:
        lint_cfg(c)
    # SV-interface wrapper (linted as a top level: its request signals are driven by the parent, so UNDRIVEN is expected)
    if all(Path(f).exists() for f in IF_FILES):
        v = sh(["verilator", "--lint-only", "-Wall", "-Wno-UNDRIVEN", *inc("-I"), *RTL_FILES, *IF_FILES, "--top-module", "sf_sram_core_if"])
        ok = v["rc"] == 0 and not re.search(r"%Warning|%Error", v["out"])
        recs.append({"suite": "lint", "tool": "verilator -Wall (-Wno-UNDRIVEN: top-level interface)", "cfg": "sf_sram_core_if",
                     "result": "PASS" if ok else "FAIL", "detail": "" if ok else v["out"][-500:]})
    # configuration examples: each module is its own top (one file holds all of them: -Wno-DECLFILENAME)
    ex = ROOT / "examples/sf_sram_examples.sv"
    if ex.exists():
        for mod in re.findall(r"^module (sf_sram_ex_\w+)", ex.read_text(), re.M):
            v = sh(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", *inc("-I"), *RTL_FILES, ex, "--top-module", mod])
            ok = v["rc"] == 0 and not re.search(r"%Warning|%Error", v["out"])
            recs.append({"suite": "lint", "tool": "verilator -Wall", "cfg": mod, "result": "PASS" if ok else "FAIL",
                         "detail": "" if ok else v["out"][-500:]})
            ic = sh(["iverilog", "-g2012", "-Wall", *inc("-I"), "-s", mod, "-o", BUILD / "lint_ic.vvp", *RTL_FILES, ex])
            ok = ic["rc"] == 0 and not ic["out"].strip()
            recs.append({"suite": "lint", "tool": "iverilog -Wall", "cfg": mod, "result": "PASS" if ok else "FAIL",
                         "detail": "" if ok else ic["out"][-500:]})
    # the array on its own, and with SYNTHESIS defined (the synthesis view of the source)
    v = vl_lint(RTL_FILES, "sf_sram_core", {}, defs=["SYNTHESIS"])
    ok = v["rc"] == 0 and not re.search(r"%Warning|%Error", v["out"])
    recs.append({"suite": "lint", "tool": "verilator -Wall -DSYNTHESIS", "cfg": "c32x1024", "result": "PASS" if ok else "FAIL",
                 "detail": "" if ok else v["out"][-500:]})
    return recs


# --------------------------------------------------------------------------- negative elaboration
def suite_neg() -> list[dict]:
    recs = []
    for name, ovr, defs, frag in NEGATIVE:
        row = {"suite": "neg", "case": name, "params": ovr, "defines": defs}
        # Verilator
        v = vl_lint(RTL_FILES, "sf_sram_core", ovr, defs=defs, wall=False)
        row["verilator"] = "PASS" if (v["rc"] != 0 and (frag is None or frag in v["out"])) else "FAIL"
        # Icarus: the time-0 $fatal in the generate block must fire (or compilation must fail)
        ic = sh(["iverilog", "-g2012", *inc("-I"), *[f"-D{d}" for d in defs], "-s", "sf_sram_core", "-o", BUILD / "neg_ic.vvp",
                 *[f"-Psf_sram_core.{k}=" + (f'"{x}"' if isinstance(x, str) else str(x)) for k, x in ovr.items()], *RTL_FILES])
        if ic["rc"] != 0:
            row["icarus"] = "PASS"          # rejected at compile time
        else:
            rr = sh(["vvp", "-n", BUILD / "neg_ic.vvp"])
            row["icarus"] = "PASS" if (rr["rc"] != 0 or (frag and frag in rr["out"])) else "FAIL"
        # Yosys: hierarchy must fail
        sets = ("chparam " + " ".join(f"-set {k} {('\"' + v_ + '\"') if isinstance(v_, str) else v_}" for k, v_ in ovr.items()) + " sf_sram_core;") if ovr else ""
        ys = f"read_verilog -sv {' '.join('-D' + d for d in defs)} -I{RTL} {' '.join(str(f) for f in RTL_FILES)}; {sets} hierarchy -check -top sf_sram_core"
        y = sh(["yosys", "-q", "-p", ys])
        row["yosys"] = "PASS" if y["rc"] != 0 else "FAIL"
        row["result"] = "PASS" if all(row[k] == "PASS" for k in ("verilator", "icarus", "yosys")) else "FAIL"
        recs.append(row)
    return recs


# --------------------------------------------------------------------------- xcheck / assert / if
def suite_xcheck() -> list[dict]:
    recs = []
    cases = [("x32_lat1", dict(DW=32, LAT=1)), ("x32_lat2", dict(DW=32, LAT=2)), ("x64_lat1", dict(DW=64, LAT=1)),
             ("x64_lat3", dict(DW=64, LAT=3)), ("x16_lat1", dict(DW=16, LAT=1))]
    files = [*RTL_FILES, *LIB_REF_FILES, TB / "tb_sf_sram_xcheck.sv"]
    for name, p in cases:
        for seed in (1, 2):
            exe, b = vl_build("tb_sf_sram_xcheck", files, p)
            if b["rc"] != 0:
                recs.append({"suite": "xcheck", "case": name, "seed": seed, "result": "FAIL", "first_errors": [b["out"][-400:]]})
                continue
            r = sh([exe, f"+seed={seed}", f"+verilator+seed+{seed}", "+verilator+rand+reset+2"])
            rec = {"suite": "xcheck", "case": name, "params": p, "seed": seed, **parse_result(r["out"])}
            recs.append(rec)
    vvp, b = ic_build("tb_sf_sram_xcheck", files, dict(DW=32, LAT=2))
    r = sh(["vvp", "-n", vvp, "+seed=1"])
    recs.append({"suite": "xcheck", "case": "x32_lat2 (icarus)", "params": dict(DW=32, LAT=2), "seed": 1, **parse_result(r["out"])})
    return recs


def suite_assert() -> list[dict]:
    recs = []
    files = [*RTL_FILES, TB / "tb_sf_sram_assert.sv"]
    for sim in ("verilator", "icarus"):
        if sim == "verilator":
            exe, b = vl_build("tb_sf_sram_assert", files, {})
            r = sh([exe, "+verilator+rand+reset+2", "+verilator+error+limit+1000"])
        else:
            vvp, b = ic_build("tb_sf_sram_assert", files, {})
            r = sh(["vvp", "-n", vvp])
        out = r["out"]
        exp = {k: int(v) for k, v in re.findall(r"SRAM_EXPECT (\w+)=(\d+)", out)}
        got = {"oob": len(re.findall(r"SF_SRAM_ASSERT_OOB", out)), "x": len(re.findall(r"SF_SRAM_ASSERT_X", out)),
               "int": len(re.findall(r"SF_SRAM_ASSERT_INT", out))}
        ok_counts = all(got.get(k, 0) == v for k, v in exp.items()) and got["int"] == 0 and bool(exp)
        m = RESULT_RE.search(out)
        ok = ok_counts and m is not None and m.group(1) == "PASS"
        recs.append({"suite": "assert", "sim": sim, "expected": exp, "observed": got, "tb_result": m.group(1) if m else "NONE",
                     "result": "PASS" if ok else "FAIL"})
    return recs


def suite_if() -> list[dict]:
    recs = []
    files = [*RTL_FILES, *IF_FILES, TB / "tb_sf_sram_if.sv"]
    for p, name in ((dict(), "if32x1024"), (dict(DW=64, DEPTH=1000, AW=11, LAT=2), "if64x1000_a11_lat2")):
        exe, b = vl_build("tb_sf_sram_if", files, p)
        if b["rc"] != 0:
            recs.append({"suite": "if", "cfg": name, "result": "FAIL", "first_errors": [b["out"][-600:]]})
            continue
        r = sh([exe, "+seed=1", "+verilator+seed+1", "+verilator+rand+reset+2"])
        recs.append({"suite": "if", "cfg": name, "params": p, "seed": 1, **parse_result(r["out"])})
    return recs


# --------------------------------------------------------------------------- report
def write_report(recs: list[dict], suites: list[str], out_json: Path, out_md: Path) -> int:
    fails = [r for r in recs if r.get("result") != "PASS"]
    write_json(out_json, {"provenance": provenance({"suites": suites}), "records": recs,
                          "summary": {"total": len(recs), "pass": len(recs) - len(fails), "fail": len(fails)}})
    L = ["# SRAMCore regression report", "",
         f"Suites: {', '.join(suites)}  |  records: {len(recs)}  |  **pass {len(recs) - len(fails)} / fail {len(fails)}**", ""]
    prov = provenance()
    L += ["Tools: " + "; ".join(f"{k}: `{v}`" for k, v in prov["tools"].items()), ""]
    for s in suites:
        rs = [r for r in recs if r["suite"] == s]
        if not rs:
            continue
        L += [f"## {s}", ""]
        if s == "sim":
            L += ["| config | sim | seed | checks | errors | result |", "|---|---|---|---|---|---|"]
            for r in rs:
                L.append(f"| {r['cfg']} `{ {k: v for k, v in r['params'].items() if k != 'INITF'} }` | {r['sim']} | {r['seed']} | {r['checks']} | {r['errors']} | {r['result']} |")
        elif s == "lint":
            L += ["| tool | config | result |", "|---|---|---|"]
            for r in rs:
                L.append(f"| {r['tool']} | {r['cfg']} | {r['result']} |")
        elif s == "neg":
            L += ["| illegal parameterisation | overrides | Verilator | Icarus | Yosys | result |", "|---|---|---|---|---|---|"]
            for r in rs:
                L.append(f"| {r['case']} | `{r['params']}{' ' + str(r['defines']) if r['defines'] else ''}` | {r['verilator']} | {r['icarus']} | {r['yosys']} | {r['result']} |")
        elif s == "xsim":
            L += ["| config | seed | Verilator | Icarus | identical stimulus | result |", "|---|---|---|---|---|---|"]
            for r in rs:
                L.append(f"| {r['cfg']} | {r['seed']} | {r['verilator']} ({r['checks_verilator']} checks) | {r['icarus']} ({r['checks_icarus']} checks) | {r['stimulus_identical']} | {r['result']} |")
        elif s == "xcheck":
            L += ["| case | seed | checks | errors | result |", "|---|---|---|---|---|"]
            for r in rs:
                L.append(f"| {r['case']} | {r['seed']} | {r.get('checks', 0)} | {r.get('errors', -1)} | {r['result']} |")
        elif s == "assert":
            L += ["| simulator | expected | observed | result |", "|---|---|---|---|"]
            for r in rs:
                L.append(f"| {r['sim']} | {r['expected']} | {r['observed']} | {r['result']} |")
        elif s == "if":
            L += ["| config | checks | errors | result |", "|---|---|---|---|"]
            for r in rs:
                L.append(f"| {r['cfg']} | {r.get('checks', 0)} | {r.get('errors', -1)} | {r['result']} |")
        L.append("")
    if fails:
        L += ["## Failures", ""]
        for r in fails:
            L.append(f"* `{ {k: r.get(k) for k in ('suite', 'cfg', 'case', 'sim', 'seed')} }` {r.get('first_errors') or r.get('detail') or ''}")
    out_md.write_text("\n".join(L) + "\n")
    return len(fails)


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--suite", default="all")
    ap.add_argument("--only", default=None, help="regex: restrict the sim suite to matching configuration names")
    ap.add_argument("--out", default="regression")
    a = ap.parse_args()
    suites = ["lint", "neg", "sim", "xsim", "xcheck", "assert", "if"] if a.suite == "all" else a.suite.split(",")
    BUILD.mkdir(parents=True, exist_ok=True)
    recs: list[dict] = []
    fn = {"lint": suite_lint, "neg": suite_neg, "sim": lambda: suite_sim(a.only), "xsim": suite_xsim,
          "xcheck": suite_xcheck, "assert": suite_assert, "if": suite_if}
    for s in suites:
        print(f"== suite {s}", flush=True)
        rs = fn[s]()
        bad = [r for r in rs if r.get("result") != "PASS"]
        print(f"   {len(rs) - len(bad)} pass / {len(bad)} fail", flush=True)
        for r in bad[:6]:
            print("   FAIL", {k: r.get(k) for k in ("cfg", "case", "sim", "seed", "tool")}, (r.get("first_errors") or r.get("detail") or "")[:300], flush=True)
        recs += rs
    nfail = write_report(recs, suites, REPORTS / f"{a.out}.json", REPORTS / f"{a.out}.md")
    print(f"wrote reports/{a.out}.md  total={len(recs)} fail={nfail}")
    return 1 if nfail else 0


if __name__ == "__main__":
    sys.exit(main())
