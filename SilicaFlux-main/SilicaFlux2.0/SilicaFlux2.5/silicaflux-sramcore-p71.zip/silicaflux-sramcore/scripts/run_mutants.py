#!/usr/bin/env python3
"""Mutation sanity for the SRAMCore testbench.

Each mutant injects one realistic RTL bug into a private copy of the sources,
builds the testbench against the copy and runs it.  A mutant is KILLED when the
run does not report PASS (checks fail, an RTL assertion fires, the run aborts).
A mutant that still passes SURVIVED: a hole in the verification.  A mutation
that does not apply exactly once, or a mutant that does not build, is reported
as INVALID (never counted as killed).

Output: reports/mutants.md / .json
"""
from __future__ import annotations

import shutil
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, INC_DIRS, REPORTS, ROOT, RTL, TB, VL_SIM_FLAGS, ensure_hex, provenance, sh, write_json  # noqa: E402
from run_regress import RESULT_RE, parse_result  # noqa: E402

A = "sf_sram_array.sv"
C = "sf_sram_core.sv"
POS = "-GAW=12"

# (id, file, old, new, TB params, simulator, requirement exercised)
MUTANTS = [
    ("M01 write lane 1 takes lane 2 data", A,
     "<= wdata[l*BYTE_WIDTH +: BYTE_WIDTH];", "<= wdata[((l==1)?2:l)*BYTE_WIDTH +: BYTE_WIDTH];", dict(DW=32), "verilator", "byte enables: lane mapping"),
    ("M02 lane 0 written regardless of its enable", A,
     "if (wmask[l]) mem", "if (wmask[l] || l == 0) mem", dict(DW=32), "verilator", "byte enables: preservation of untouched bytes"),
    ("M03 byte-enable polarity inverted", A,
     "if (wmask[l]) mem", "if (!wmask[l]) mem", dict(DW=32), "verilator", "byte enables: polarity"),
    ("M04 unselected lanes cleared on a partial write", A,
     "if (wmask[l]) mem[idx][l*BYTE_WIDTH +: BYTE_WIDTH] <= wdata[l*BYTE_WIDTH +: BYTE_WIDTH];",
     "if (wmask[l]) mem[idx][l*BYTE_WIDTH +: BYTE_WIDTH] <= wdata[l*BYTE_WIDTH +: BYTE_WIDTH]; else mem[idx][l*BYTE_WIDTH +: BYTE_WIDTH] <= '0;",
     dict(DW=32), "verilator", "byte enables: untouched bytes preserved"),
    ("M05 zero-strobe write corrupts the word", A,
     "if (wmask[l]) mem", "if (wmask[l] || (l == 0 && wmask == '0)) mem", dict(DW=32), "verilator", "byte enables: zero write strobes"),
    ("M06 write happens with ce=0 (we=1)", A,
     "    if (ce) begin\n      if (we) begin", "    if (ce || we) begin\n      if (we) begin", dict(DW=32), "verilator", "disabled cycles"),
    ("M07 bounds check off by one (<=)", C,
     "({1'b0, addr} < DEPTH_W)", "({1'b0, addr} <= DEPTH_W)", dict(DW=32, DEPTH=1000, AW=11), "verilator", "invalid addresses: boundary"),
    ("M08 invalid addresses silently aliased (no check)", C,
     "assign addr_ok = ({1'b0, addr} < DEPTH_W);", "assign addr_ok = 1'b1;", dict(DW=32, DEPTH=1024, AW=12), "verilator", "invalid addresses: no aliasing"),
    ("M09 address MSB ignored", C,
     ".idx(addr[IDX_WIDTH-1:0])", ".idx({1'b0, addr[IDX_WIDTH-2:0]})", dict(DW=32), "verilator", "every address"),
    ("M10 last word missing from the array", A,
     "logic [DATA_WIDTH-1:0] mem [DEPTH_WORDS];", "logic [DATA_WIDTH-1:0] mem [DEPTH_WORDS-1];", dict(DW=32), "verilator", "first and last word"),
    ("M11 rd_valid one cycle early (LAT=2)", C,
     "assign rd_valid = rv_q[READ_LATENCY-1];", "assign rd_valid = rv_q[0];", dict(DW=32, LAT=2), "verilator", "read latency: valid"),
    ("M12 read data one cycle early (LAT=2)", A,
     "assign rdata = pipe[READ_LATENCY-2];", "assign rdata = q0;", dict(DW=32, LAT=2), "verilator", "read latency: data"),
    ("M13 in-flight responses survive reset", C,
     "      rv_q <= '0;\n", "      rv_q <= rv_q;\n", dict(DW=32), "verilator", "reset: response flush"),
    ("M14 access presented during reset is executed", C,
     "assign acc    = ce & rst_n;", "assign acc    = ce;", dict(DW=32), "verilator", "reset: accesses ignored"),
    ("M15 controller reset zero-fills word 0 (array reset by controller)", C,
     ".clk, .ce(arr_ce), .we, .wmask, .idx(addr[IDX_WIDTH-1:0]), .wdata, .rdata(arr_rdata)",
     ".clk, .ce(arr_ce | ~rst_n), .we(we | ~rst_n), .wmask(rst_n ? wmask : '1), .idx(rst_n ? addr[IDX_WIDTH-1:0] : '0), .wdata(rst_n ? wdata : '0), .rdata(arr_rdata)",
     dict(DW=32), "verilator", "retention across controller reset"),
    ("M16 invalid read returns stale data instead of zero", C,
     "assign rdata = rd_valid ? (rd_err ? '0 : arr_rdata) : {DATA_WIDTH{1'bx}};", "assign rdata = rd_valid ? arr_rdata : {DATA_WIDTH{1'bx}};", dict(DW=32, DEPTH=1024, AW=12), "verilator", "invalid addresses: deterministic response"),
    ("M17 zero-strobe write is not acknowledged", C,
     "wa_q <= wr_acc;", "wa_q <= wr_acc & (|wmask);", dict(DW=32), "verilator", "write acknowledgement"),
    ("M18 invalid write is silent when WRITE_ACK=0", C,
     "we_q <= wr_acc & ~addr_ok;", "we_q <= wr_acc & ~addr_ok & (WRITE_ACK != 0);", dict(DW=32, DEPTH=1024, AW=12, WACK=0), "verilator", "errors are never silent"),
    ("M19 INIT_MODE=ZERO fills ones", A,
     "mem[i] = '0;\n    end else if (INIT_MODE == `SF_SRAM_INIT_FILE)", "mem[i] = '1;\n    end else if (INIT_MODE == `SF_SRAM_INIT_FILE)", dict(DW=32, INITM=1), "verilator", "INIT_MODE=ZERO"),
    ("M20 INIT_MODE=FILE ignores the file", A,
     "$readmemh(INIT_FILE, mem);", "begin end", dict(DW=32, INITM=2, INITF="@hex:32x1024"), "verilator", "INIT_MODE=FILE"),
    ("M21 INIT_MODE=NONE silently zero-fills the array", A,
     "if (INIT_MODE == `SF_SRAM_INIT_ZERO) begin", "if (INIT_MODE == `SF_SRAM_INIT_ZERO || INIT_MODE == `SF_SRAM_INIT_NONE) begin", dict(DW=32), "icarus",
     "unwritten SRAM must not read as zero (only observable in a 4-state simulator)"),
    ("M22 rdata held (not X) while rd_valid=0", C,
     "assign rdata = rd_valid ? (rd_err ? '0 : arr_rdata) : {DATA_WIDTH{1'bx}};", "assign rdata = rd_err ? '0 : arr_rdata;", dict(DW=32), "icarus",
     "rdata only meaningful with rd_valid (poison, 4-state)"),
]


def build_and_run(idx: int, m: tuple) -> dict:
    name, fname, old, new, params, sim, req = m
    mdir = BUILD / "mut" / f"m{idx:02d}"
    if mdir.exists():
        shutil.rmtree(mdir)
    (mdir / "rtl").mkdir(parents=True)
    for f in RTL.iterdir():
        if f.suffix in (".sv", ".svh"):
            shutil.copy(f, mdir / "rtl" / f.name)
    src = (mdir / "rtl" / fname).read_text()
    n = src.count(old)
    rec = {"id": name, "requirement": req, "sim": sim, "params": params}
    if n != 1:
        rec.update(status="INVALID", detail=f"mutation pattern matched {n} times (need exactly 1)")
        return rec
    (mdir / "rtl" / fname).write_text(src.replace(old, new))
    files = [mdir / "rtl" / "sf_sram_array.sv", mdir / "rtl" / "sf_sram_core.sv", TB / "tb_sf_sram_core.sv"]
    incs = [mdir / "rtl", *[d for d in INC_DIRS if d != RTL]]
    pr = dict(params)
    if isinstance(pr.get("INITF"), str) and pr["INITF"].startswith("@hex:"):
        pr["INITF"] = ensure_hex(pr["INITF"])
    if sim == "verilator":
        pd = [f'-G{k}="{v}"' if isinstance(v, str) else f"-G{k}={v}" for k, v in pr.items()]
        b = sh(["verilator", *VL_SIM_FLAGS, *[f"-I{d}" for d in incs], *files, "--top-module", "tb_sf_sram_core", *pd,
                "--Mdir", mdir / "obj", "-o", "Vtb"])
        if b["rc"] != 0:
            rec.update(status="INVALID", detail="build failed: " + b["out"][-300:])
            return rec
        r = sh([mdir / "obj" / "Vtb", "+seed=1", "+verilator+seed+1", "+verilator+rand+reset+2", "+nrand=8000"])
    else:
        pd = [f'-Ptb_sf_sram_core.{k}="{v}"' if isinstance(v, str) else f"-Ptb_sf_sram_core.{k}={v}" for k, v in pr.items()]
        b = sh(["iverilog", "-g2012", "-DSF_SRAM_POISON", *[f"-I{d}" for d in incs], "-s", "tb_sf_sram_core", "-o", mdir / "m.vvp", *pd, *files])
        if b["rc"] != 0:
            rec.update(status="INVALID", detail="build failed: " + b["out"][-300:])
            return rec
        r = sh(["vvp", "-n", mdir / "m.vvp", "+seed=1", "+nrand=4000"])
    res = parse_result(r["out"])
    killed = res["result"] != "PASS" or r["rc"] != 0
    first = (res["first_errors"] or [""])[0]
    if not first and r["rc"] != 0:
        first = "run aborted (rc=%d): %s" % (r["rc"], r["out"].strip().splitlines()[-1][:160] if r["out"].strip() else "")
    rec.update(status="KILLED" if killed else "SURVIVED", checks=res["checks"], errors=res["errors"], first_error=first[:200])
    return rec


def main() -> int:
    BUILD.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(4) as ex:
        recs = list(ex.map(lambda t: build_and_run(*t), list(enumerate(MUTANTS, 1))))
    killed = sum(r["status"] == "KILLED" for r in recs)
    surv = [r for r in recs if r["status"] == "SURVIVED"]
    inval = [r for r in recs if r["status"] == "INVALID"]
    # control: the unmutated design must pass the same flow, otherwise "killed" means nothing
    write_json(REPORTS / "mutants.json", {"provenance": provenance(), "records": recs,
                                          "summary": {"total": len(recs), "killed": killed, "survived": len(surv), "invalid": len(inval)}})
    L = ["# Mutation sanity report", "",
         f"{len(recs)} injected RTL bugs: **{killed} killed**, {len(surv)} survived, {len(inval)} invalid.", "",
         "| # | injected bug | requirement exercised | sim | result | first failing check |", "|---|---|---|---|---|---|"]
    for r in recs:
        L.append(f"| {r['id'].split()[0]} | {' '.join(r['id'].split()[1:])} | {r['requirement']} | {r['sim']} | {r['status']} | {r.get('first_error') or r.get('detail', '')} |")
    (REPORTS / "mutants.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 1 if (surv or inval) else 0


if __name__ == "__main__":
    sys.exit(main())
