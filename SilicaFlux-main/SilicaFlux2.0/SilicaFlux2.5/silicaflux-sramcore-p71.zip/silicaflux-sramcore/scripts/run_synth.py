#!/usr/bin/env python3
"""Yosys synthesis / FPGA memory-inference checks for SRAMCore.

generic   technology-independent `synth` (hierarchy kept): elaboration with `hierarchy -check`, the memory Yosys infers
          (width x depth, ports, read-port synchronous?), glue-logic cell counts of sf_sram_core WITHOUT the array,
          latch check (must be zero), warning count.  The flip-flop count of the array after generic synthesis is
          NOT an SRAM area figure (it is the array bits mapped to flops).
fpga      vendor flows (synth_xilinx -family xc7, synth_ice40, synth_ecp5): the memory must map to the target's RAM
          primitives and no memory ($mem) may fall back to flip-flops/LUT-RAM where a block RAM is expected.  This is
          INFERENCE EVIDENCE ONLY: no vendor tool (Vivado, Quartus, Radiant), no place-and-route, no timing, no board.
asic      NOT RUN.  No liberty file, SRAM compiler or PDK exists in this environment.  No area, power or access-time
          number is produced or implied.

Output: reports/synth.md / .json  (every row carries the exact Yosys script that produced it)
"""
from __future__ import annotations

import json
import re
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, CONFIGS, REPORTS, ROOT, RTL, RTL_FILES, ensure_hex, provenance, sh, write_json  # noqa: E402

CORE = {"DW": "DATA_WIDTH", "DEPTH": "DEPTH_WORDS", "AW": "ADDR_WIDTH", "BW": "BYTE_WIDTH", "LAT": "READ_LATENCY",
        "WACK": "WRITE_ACK", "INITM": "INIT_MODE", "INITF": "INIT_FILE"}
FILES = " ".join(str(f) for f in RTL_FILES)
EXAMPLES = ROOT / "examples/sf_sram_examples.sv"
WORK = BUILD / "ys"


def chparams(top: str, p: dict) -> str:
    """ONE chparam command carrying every override.  Yosys 0.33 re-validates the module after each separate
    `chparam -set`, so overriding DATA_WIDTH=28 before BYTE_WIDTH=4 would trip the (correct) DATA_WIDTH % BYTE_WIDTH
    check on the intermediate state."""
    if not p:
        return ""
    sets = []
    for k, v in p.items():
        k = CORE.get(k, k)
        if isinstance(v, str) and v.startswith("@hex:"):
            v = ensure_hex(v)
        sets.append(f'-set {k} "{v}"' if isinstance(v, str) else f"-set {k} {v}")
    return f"chparam {' '.join(sets)} {top};"


def ys(script: str, tag: str) -> tuple[dict, str]:
    WORK.mkdir(parents=True, exist_ok=True)
    js = WORK / f"{tag}.json"
    full = script + f" tee -q -o {js} stat -json"
    r = sh(["yosys", "-p", full], timeout=900)
    data = None
    if js.exists():
        try:
            data = json.loads(js.read_text())
        except Exception:
            data = None
    return {"rc": r["rc"], "log": r["out"], "stat": data}, full


def cells_of(stat: dict | None, which: str | None = None) -> dict:
    if not stat:
        return {}
    if which is None:
        return dict(stat.get("design", {}).get("num_cells_by_type", {}))
    for name, m in stat.get("modules", {}).items():
        if which in name:
            return dict(m.get("num_cells_by_type", {}))
    return {}


def count(cells: dict, pat: str) -> int:
    return sum(v for k, v in cells.items() if re.search(pat, k))


def warnings(log: str) -> int:
    return len(re.findall(r"^Warning:", log, re.M))


# --------------------------------------------------------------------------- generic
def memory_view(top: str, p: dict, tag: str, files: str = FILES, extra_defs: str = "") -> dict:
    """What Yosys infers from the RTL: memories after memory_dff, before technology mapping."""
    js = WORK / f"{tag}_mem.json"
    script = (f"read_verilog -sv -I{RTL} {files}; {chparams(top, p)} hierarchy -check -top {top}; proc; opt; memory -nomap; "
              f"write_json {js}")
    WORK.mkdir(parents=True, exist_ok=True)
    r = sh(["yosys", "-q", "-p", script], timeout=600)
    mems = []
    if r["rc"] == 0 and js.exists():
        d = json.loads(js.read_text())
        for mn, m in d["modules"].items():
            for cn, c in m["cells"].items():
                if c["type"] in ("$mem_v2", "$mem"):
                    pr = c["parameters"]
                    b = lambda k: int(pr[k], 2)  # noqa: E731
                    mems.append({"width": b("WIDTH"), "depth": b("SIZE"), "rd_ports": b("RD_PORTS"), "wr_ports": b("WR_PORTS"),
                                 "rd_sync": all(ch == "1" for ch in pr["RD_CLK_ENABLE"][-b("RD_PORTS"):]) if b("RD_PORTS") else True,
                                 "wr_sync": all(ch == "1" for ch in pr["WR_CLK_ENABLE"][-b("WR_PORTS"):])})
    return {"rc": r["rc"], "mems": mems, "script": script, "err": r["out"][-300:] if r["rc"] else ""}


def generic_case(c: dict) -> dict:
    p = c["p"]
    top = "sf_sram_core"
    mv = memory_view(top, p, c["name"])
    script = (f"read_verilog -sv -I{RTL} {FILES}; {chparams(top, p)} hierarchy -check -top {top}; "
              f"synth -top {top}; check -assert;")
    res, full = ys(script, "gen_" + c["name"])
    st = res["stat"]
    core = cells_of(st, "sf_sram_core") if st else {}
    # with the hierarchy kept, the core module's own cells exclude the array (a separate module instance)
    core_mods = [n for n in (st or {}).get("modules", {}) if "sf_sram_core" in n]
    glue = (st["modules"][core_mods[0]].get("num_cells_by_type", {}) if core_mods else {})
    glue_ff = count({k: v for k, v in glue.items() if "DFF" in k}, r".")
    glue_other = sum(v for k, v in glue.items() if "DFF" not in k and not k.startswith("$paramod") and "sf_sram_array" not in k)
    latches = count(cells_of(st), r"LATCH")
    arr_mems = [m for m in mv["mems"]]
    ok = (res["rc"] == 0 and mv["rc"] == 0 and latches == 0 and len(arr_mems) == 1
          and arr_mems[0]["rd_sync"] and arr_mems[0]["wr_sync"] and arr_mems[0]["rd_ports"] == 1)
    return {"flow": "generic", "cfg": c["name"], "params": {k: v for k, v in p.items() if k != "INITF"},
            "memory": arr_mems, "glue_ff": glue_ff, "glue_cells_excl_ff": glue_other, "latches": latches,
            "warnings": warnings(res["log"]), "rc": res["rc"], "result": "PASS" if ok else "FAIL", "script": full,
            "detail": "" if ok else (mv["err"] or res["log"][-400:])}


# --------------------------------------------------------------------------- fpga
FPGA = [
    # name, flow, params, expected RAM primitive regex, note
    ("xc7 32x1024 (primary)",            "xc7",   dict(DW=32, DEPTH=1024),                  r"^RAMB(18|36)E1$", ""),
    ("xc7 32x1024 posted writes",        "xc7",   dict(DW=32, DEPTH=1024, WACK=0),          r"^RAMB(18|36)E1$", ""),
    ("xc7 32x1024 read latency 2",       "xc7",   dict(DW=32, DEPTH=1024, LAT=2),           r"^RAMB(18|36)E1$", "output register"),
    ("xc7 32x1024 read latency 3",       "xc7",   dict(DW=32, DEPTH=1024, LAT=3),           r"^RAMB(18|36)E1$", ""),
    ("xc7 32x1024, 12-bit address",      "xc7",   dict(DW=32, DEPTH=1024, AW=12),           r"^RAMB(18|36)E1$", "bounds check active"),
    ("xc7 32x1000 (non power of two)",   "xc7",   dict(DW=32, DEPTH=1000),                  r"^RAMB(18|36)E1$", ""),
    ("xc7 64x1024",                      "xc7",   dict(DW=64, DEPTH=1024),                  r"^RAMB(18|36)E1$", ""),
    ("xc7 64x1000, 11-bit address",      "xc7",   dict(DW=64, DEPTH=1000, AW=11),           r"^RAMB(18|36)E1$", ""),
    ("xc7 64x4096 latency 2 (32 KiB)",   "xc7",   dict(DW=64, DEPTH=4096, LAT=2),           r"^RAMB(18|36)E1$", ""),
    ("xc7 72x1024, 9-bit lanes",         "xc7",   dict(DW=72, DEPTH=1024, BW=9),            r"^RAMB(18|36)E1$", "parity lanes"),
    ("xc7 32x1024 INIT_MODE=ZERO",       "xc7",   dict(DW=32, DEPTH=1024, INITM=1),         r"^RAMB(18|36)E1$", ""),
    ("xc7 32x1024 INIT_MODE=FILE",       "xc7",   dict(DW=32, DEPTH=1024, INITM=2, INITF="@hex:32x1024"), r"^RAMB(18|36)E1$", ""),
    ("xc7 32x131072 (512 KiB)",          "xc7",   dict(DW=32, DEPTH=131072),                r"^RAMB(18|36)E1$", "capacity scaling"),
    ("ice40 16x256",                     "ice40", dict(DW=16, DEPTH=256),                   r"^SB_RAM40_4K$", ""),
    ("ice40 16x1024",                    "ice40", dict(DW=16, DEPTH=1024),                  r"^SB_RAM40_4K$", ""),
    ("ecp5 32x1024",                     "ecp5",  dict(DW=32, DEPTH=1024),                  r"^(DP16KD|PDPW16KD)$", ""),
    ("ecp5 64x1024",                     "ecp5",  dict(DW=64, DEPTH=1024),                  r"^(DP16KD|PDPW16KD)$", ""),
]
FLOW = {"xc7": "synth_xilinx -family xc7", "ice40": "synth_ice40", "ecp5": "synth_ecp5"}
FF = {"xc7": r"^FD(RE|CE|PE|SE)$", "ice40": r"^SB_DFF", "ecp5": r"^TRELLIS_FF$"}
LUT = {"xc7": r"^LUT[1-6]$", "ice40": r"^SB_LUT4$", "ecp5": r"^LUT4$"}


def fpga_case(row) -> dict:
    name, fl, p, ram_re, note = row
    top = "sf_sram_core"
    script = f"read_verilog -sv -I{RTL} {FILES}; {chparams(top, p)} hierarchy -check -top {top}; {FLOW[fl]} -top {top};"
    tag = "fpga_" + re.sub(r"\W+", "_", name)
    res, full = ys(script, tag)
    cells = cells_of(res["stat"])
    ram = {k: v for k, v in cells.items() if re.search(ram_re, k)}
    other_ram = {k: v for k, v in cells.items() if re.search(r"RAM|DPR16X4", k) and k not in ram}
    mem_left = (res["stat"] or {}).get("design", {}).get("num_memories", -1)
    ok = res["rc"] == 0 and sum(ram.values()) > 0 and mem_left == 0
    return {"flow": "fpga", "name": name, "target": fl, "params": {k: v for k, v in p.items() if k != "INITF"}, "note": note,
            "ram_primitives": ram, "other_ram_cells": other_ram, "flip_flops": count(cells, FF[fl]), "luts": count(cells, LUT[fl]),
            "memories_left": mem_left, "warnings": warnings(res["log"]), "rc": res["rc"],
            "result": "PASS" if ok else "FAIL", "script": full, "detail": "" if ok else res["log"][-400:]}


# --------------------------------------------------------------------------- examples
def example_case(mod: str) -> dict:
    extra = ""
    if mod == "sf_sram_ex_controlcore_lmem":
        extra = f'chparam -set INIT_FILE "{ensure_hex("@hex:32x2048")}" {mod};'
    script = f"read_verilog -sv -I{RTL} {FILES} {EXAMPLES}; {extra} hierarchy -check -top {mod}; {FLOW['xc7']} -top {mod};"
    res, full = ys(script, "ex_" + mod)
    cells = cells_of(res["stat"])
    ram = {k: v for k, v in cells.items() if re.search(r"^RAMB(18|36)E1$", k)}
    other = {k: v for k, v in cells.items() if re.search(r"^RAM\d+|RAM32|RAM64|DPR", k)}
    mem_left = (res["stat"] or {}).get("design", {}).get("num_memories", -1)
    return {"flow": "example", "name": mod, "ram_primitives": ram, "other_ram_cells": other, "flip_flops": count(cells, FF["xc7"]),
            "luts": count(cells, LUT["xc7"]), "memories_left": mem_left, "rc": res["rc"],
            "result": "PASS" if (res["rc"] == 0 and mem_left == 0) else "FAIL", "script": full}


def main() -> int:
    WORK.mkdir(parents=True, exist_ok=True)
    gen_cfgs = [c for c in CONFIGS if c["name"] in (
        "c32x1024", "c32x1024_noack", "c32x1024_lat2", "c32x1024_lat3", "c32x1024_a12", "c32x1000", "c64x1024", "c64x1024_lat2",
        "c64x1000_a11", "c72x256_bw9", "c24x300", "c32x1024_zero", "c32x1024_file", "c8x256", "c128x64", "c32x3")]
    mods = re.findall(r"^module (sf_sram_ex_\w+)", EXAMPLES.read_text(), re.M)
    with ThreadPoolExecutor(4) as ex:
        g = list(ex.map(generic_case, gen_cfgs))
        f = list(ex.map(fpga_case, FPGA))
        e = list(ex.map(example_case, mods))
    recs = g + f + e
    nfail = sum(r["result"] != "PASS" for r in recs)
    write_json(REPORTS / "synth.json", {"provenance": provenance(), "records": recs,
                                        "asic": "NOT RUN: no liberty / SRAM compiler / PDK in this environment; no area, power or access-time figure produced",
                                        "summary": {"total": len(recs), "pass": len(recs) - nfail, "fail": nfail}})
    tools = provenance()["tools"]
    L = ["# SRAMCore synthesis report (Yosys)", "",
         f"Yosys: `{tools['yosys']}`.  Vivado: {tools['vivado']}; Quartus: {tools['quartus']}; OpenROAD: {tools['openroad']}.", "",
         f"**{len(recs) - nfail} pass / {nfail} fail** of {len(recs)} runs.  Every row's exact Yosys script is in `synth.json`.", "",
         "What this is: technology-independent synthesis and FPGA block-RAM *inference* evidence from Yosys.  What this is NOT: "
         "place-and-route, timing closure, power, board or silicon results, or any ASIC area / SRAM access-time figure.  "
         "**ASIC flow: NOT RUN** (no liberty file, SRAM compiler or PDK available here).", "",
         "## Generic synthesis (hierarchy kept)", "",
         "`memory` = what Yosys infers from the RTL before technology mapping (the storage must be ONE memory with a synchronous "
         "read port).  `glue` = cells of `sf_sram_core` itself, excluding the array.  The array's flip-flops after generic "
         "mapping are not reported: they are the array bits turned into flops, not an SRAM figure.", "",
         "| config | params | memory (W x D, rd/wr ports, sync read) | glue flip-flops | glue other cells | latches | warnings | result |",
         "|---|---|---|---|---|---|---|---|"]
    for r in g:
        mem = "; ".join(f"{m['width']}x{m['depth']} ({m['rd_ports']}R/{m['wr_ports']}W, sync read={m['rd_sync']})" for m in r["memory"]) or "none"
        L.append(f"| {r['cfg']} | `{r['params']}` | {mem} | {r['glue_ff']} | {r['glue_cells_excl_ff']} | {r['latches']} | {r['warnings']} | {r['result']} |")
    L += ["", "## FPGA block-RAM inference", "",
          "| configuration | flow | RAM primitives | other RAM cells | flip-flops | LUTs | memories left | result |", "|---|---|---|---|---|---|---|---|"]
    for r in f:
        L.append(f"| {r['name']}{' — ' + r['note'] if r['note'] else ''} | `{FLOW[r['target']]}` | {r['ram_primitives']} | {r['other_ram_cells'] or '-'} | {r['flip_flops']} | {r['luts']} | {r['memories_left']} | {r['result']} |")
    L += ["", "## Configuration examples (`examples/sf_sram_examples.sv`, synth_xilinx xc7)", "",
          "| example | RAM primitives | other RAM cells | flip-flops | LUTs | memories left | result |", "|---|---|---|---|---|---|---|"]
    for r in e:
        L.append(f"| {r['name']} | {r['ram_primitives'] or '-'} | {r['other_ram_cells'] or '-'} | {r['flip_flops']} | {r['luts']} | {r['memories_left']} | {r['result']} |")
    (REPORTS / "synth.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 1 if nfail else 0


if __name__ == "__main__":
    sys.exit(main())
