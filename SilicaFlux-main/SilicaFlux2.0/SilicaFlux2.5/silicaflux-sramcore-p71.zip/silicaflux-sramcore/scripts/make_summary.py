#!/usr/bin/env python3
"""Aggregate the JSON reports into reports/SUMMARY.md.  Every number is read from a report; nothing is typed in."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, provenance  # noqa: E402


def load(name):
    p = REPORTS / f"{name}.json"
    return json.loads(p.read_text()) if p.exists() else None


def main() -> int:
    reg, mut, syn, gls = load("regression"), load("mutants"), load("synth"), load("gls")
    prov = provenance()
    L = ["# SilicaFlux SRAMCore (Project 71) - verification summary", "",
         f"Generated {prov['generated']}.  RTL sha256 `{prov['rtl_sha256']}`.", "",
         "| check | source report | result |", "|---|---|---|"]
    ok_all = True
    if reg:
        by = {}
        for r in reg["records"]:
            by.setdefault(r["suite"], [0, 0])
            by[r["suite"]][0 if r.get("result") == "PASS" else 1] += 1
        names = {"lint": "lint (Verilator -Wall, Icarus -Wall)", "neg": "illegal parameterisations rejected",
                 "sim": "self-checking simulation (configs x seeds x simulators)", "xsim": "cross-simulator identical stimulus",
                 "xcheck": "cross-check vs SRAM Wrapper Library backends", "assert": "assertions fire where intended",
                 "if": "SV interface wrapper"}
        for k in ("lint", "neg", "sim", "xsim", "xcheck", "assert", "if"):
            if k in by:
                L.append(f"| {names[k]} | regression.md | {by[k][0]} pass / {by[k][1]} fail |")
                ok_all &= by[k][1] == 0
        checks = sum(r.get("checks", 0) for r in reg["records"] if r["suite"] in ("sim", "xcheck", "if"))
        L.append(f"| scoreboard checks in sim/xcheck/if runs | regression.json | {checks:,} |")
    else:
        L.append("| regression | (not run) | - |")
        ok_all = False
    for name, rep, label in (("mutants.md", mut, "mutation sanity (injected RTL bugs caught)"),
                             ("synth.md", syn, "Yosys synthesis + FPGA inference"),
                             ("gls.md", gls, "gate-level simulation of netlists")):
        if rep:
            s = rep["summary"]
            if "killed" in s:
                L.append(f"| {label} | {name} | {s['killed']} killed / {s['survived']} survived / {s['invalid']} invalid of {s['total']} |")
                ok_all &= s["survived"] == 0 and s["invalid"] == 0
            else:
                L.append(f"| {label} | {name} | {s['pass']} pass / {s['fail']} fail |")
                ok_all &= s["fail"] == 0
        else:
            L.append(f"| {label} | {name} | (not run) |")
            ok_all = False
    L += ["", f"**Overall: {'ALL CHECKS PASS' if ok_all else 'NOT ALL CHECKS PASS - see the individual reports'}**", "", "## Tools", "",
          "| tool | version |", "|---|---|"] + [f"| {k} | {v} |" for k, v in prov["tools"].items()]
    L += ["", "## Not available / not done", "",
          "* ASIC SRAM macro flow: no PDK, liberty file or SRAM compiler here - no ASIC area, power or access-time figure exists in this package.",
          "* Vendor FPGA tools (Vivado, Quartus, Radiant): not installed - block-RAM inference is Yosys-based evidence only; no place-and-route, timing or board run.",
          "* Gate-level simulation of Xilinx RAMB / ECP5 DP16KD netlists: not possible with the cell models shipped in this Yosys (timing-only stubs).",
          "* Formal property proofs: not performed (no SymbiYosys installed).", "",
          "Every number above comes from the JSON reports in this directory; each embeds commands, exit codes and tool versions."]
    (REPORTS / "SUMMARY.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
