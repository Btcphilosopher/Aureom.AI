#!/usr/bin/env python3
"""Replace the <!--RESULTS--> marker in README.md with a table generated from reports/*.json.
Idempotent: the generated block is delimited by <!--RESULTS-->...<!--/RESULTS-->."""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, ROOT  # noqa: E402


def load(n):
    return json.loads((REPORTS / f"{n}.json").read_text())


def main() -> int:
    reg, mut, syn, gls = load("regression"), load("mutants"), load("synth"), load("gls")
    by: dict[str, list[int]] = {}
    for r in reg["records"]:
        by.setdefault(r["suite"], [0, 0])[0 if r.get("result") == "PASS" else 1] += 1
    sims = [r for r in reg["records"] if r["suite"] == "sim"]
    checks = sum(r["checks"] for r in sims)
    prim = [r for r in sims if r["cfg"] == "c32x1024"]
    prim64 = [r for r in sims if r["cfg"] == "c64x1024"]
    fp = [r for r in syn["records"] if r["flow"] == "fpga" and r["name"].startswith("xc7")]

    def row(label, p, f, note=""):
        return f"| {label} | {p} pass / {f} fail | {note} |"

    L = ["| Check | Result | Notes |", "|---|---|---|"]
    names = [("lint", "Lint: Verilator `-Wall` (zero warnings) + Icarus `-Wall`", "every configuration, interface wrapper, 7 examples"),
             ("neg", "Illegal parameterisations rejected", "16 cases x Verilator, Icarus, Yosys"),
             ("sim", "Self-checking simulation", f"{len(sims)} runs, {checks:,} scoreboard checks; 32-bit x 1024: {len(prim)} runs, 64-bit x 1024: {len(prim64)} runs"),
             ("xsim", "Same seed = same stimulus, Verilator vs Icarus", "metric line compared"),
             ("xcheck", "Cycle-equivalence with the verified library backends (GENERIC + FPGA templates)", "16/32/64-bit, latency 1-3"),
             ("assert", "Simulation assertions fire exactly where intended", "Verilator + Icarus"),
             ("if", "SV interface wrapper + protocol checker", "Verilator")]
    for k, label, note in names:
        if k in by:
            L.append(row(label, by[k][0], by[k][1], note))
    s = mut["summary"]
    L.append(f"| Mutation sanity: injected RTL bugs | {s['killed']} killed / {s['survived']} survived / {s['invalid']} invalid | of {s['total']}; `reports/mutants.md` |")
    s = syn["summary"]
    L.append(row("Yosys generic synthesis + FPGA inference + examples", s["pass"], s["fail"],
                 "latch count 0; one synchronous-read memory per config; xc7 / ice40 / ecp5 block RAM; `reports/synth.md`"))
    s = gls["summary"]
    L.append(row("Gate-level simulation of synthesised netlists", s["pass"], s["fail"], "generic gates, xc7 distributed RAM, iCE40 block RAM; `reports/gls.md`"))
    if fp:
        prim_row = next((r for r in fp if r["name"].startswith("xc7 32x1024 (primary)")), None)
        if prim_row:
            L.append(f"| xc7 block RAM for the primary 32 x 1024 | {prim_row['ram_primitives']} | {prim_row['flip_flops']} flip-flops, {prim_row['luts']} LUTs of glue (Yosys; inference evidence only) |")
    tools = reg["provenance"]["tools"]
    block = ("<!--RESULTS-->\n" + "\n".join(L) + "\n\nTools: " + "; ".join(f"{k} `{v}`" for k, v in tools.items() if "NOT" not in v) +
             f".  Not installed: {', '.join(k for k, v in tools.items() if 'NOT' in v)}.  RTL sha256 `{reg['provenance']['rtl_sha256'][:16]}…`.\n<!--/RESULTS-->")
    p = ROOT / "README.md"
    t = p.read_text()
    if "<!--/RESULTS-->" in t:
        t = re.sub(r"<!--RESULTS-->.*?<!--/RESULTS-->", lambda m: block, t, flags=re.S)
    else:
        t = t.replace("<!--RESULTS-->", block)
    p.write_text(t)
    print(block)
    return 0


if __name__ == "__main__":
    sys.exit(main())
