"""Shared helpers for the SRAMCore scripts: paths, tool versions, config table,
command runner with provenance (every report records commands, exit codes and
tool versions).  Python >= 3.10, standard library only."""
from __future__ import annotations

import datetime as _dt
import hashlib
import json
import os
import platform
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RTL = ROOT / "rtl/sram"
TB = ROOT / "tb/sram"
LIB = ROOT / "third_party/silicaflux-sramlib"
BUILD = Path(os.environ.get("SRAMCORE_BUILD", ROOT / "build"))   # override for a guaranteed-clean run
REPORTS = ROOT / "reports"

RTL_FILES = [RTL / "sf_sram_array.sv", RTL / "sf_sram_core.sv"]
IF_FILES = [RTL / "sf_sram_if.sv", RTL / "sf_sram_core_if.sv"]
LIB_REF_FILES = [LIB / "rtl/mem/backends/generic/sram_generic_1rw.sv", LIB / "rtl/mem/backends/fpga/sram_fpga_1rw.sv"]
INC_DIRS = [RTL, TB, LIB / "rtl/mem", LIB / "tb/mem"]

VL_SIM_FLAGS = ["--binary", "--timing", "--timescale", "1ns/1ps", "--assert", "-DSF_SRAM_POISON",
                "--x-assign", "unique", "--x-initial", "unique", "-Wno-fatal", "-Wno-DECLFILENAME",
                "-Wno-MULTITOP", "-Wno-UNUSEDSIGNAL", "-Wno-WIDTHEXPAND", "-Wno-WIDTHTRUNC", "-j", "1"]

# --------------------------------------------------------------------------- configurations
# TB parameter names: DW DEPTH AW BW LAT WACK INITM INITF NRAND   (AW defaults to clog2(DEPTH))
# "seeds": regression seeds; "ic": also run in Icarus.
CONFIGS = [
    # ---- primary: 32-bit x 1024 words, 1-cycle read, byte enables, write ack
    dict(name="c32x1024",          p=dict(DW=32, DEPTH=1024),                       seeds=[1, 2, 3], ic=True,  xs=True,  note="primary"),
    dict(name="c32x1024_noack",    p=dict(DW=32, DEPTH=1024, WACK=0),               seeds=[1],       ic=True,  note="posted writes"),
    dict(name="c32x1024_lat2",     p=dict(DW=32, DEPTH=1024, LAT=2),                seeds=[1],       ic=True,  note="BRAM output register"),
    dict(name="c32x1024_lat3",     p=dict(DW=32, DEPTH=1024, LAT=3),                seeds=[1],       ic=False, note="fabric pipeline"),
    dict(name="c32x1024_a12",      p=dict(DW=32, DEPTH=1024, AW=12),                seeds=[1, 2],    ic=True,  xs=True,  note="invalid addresses on a power-of-two depth"),
    dict(name="c32x1000",          p=dict(DW=32, DEPTH=1000),                       seeds=[1],       ic=True,  note="non-power-of-two depth"),
    dict(name="c32x1000_a12_lat2", p=dict(DW=32, DEPTH=1000, AW=12, LAT=2),         seeds=[1],       ic=False, note="non-pow2 + wide address + latency 2"),
    dict(name="c32x1024_zero",     p=dict(DW=32, DEPTH=1024, INITM=1),              seeds=[1],       ic=True,  note="INIT_MODE=ZERO"),
    dict(name="c32x1024_pattern",  p=dict(DW=32, DEPTH=1024, INITM=3),              seeds=[1],       ic=True,  note="INIT_MODE=PATTERN"),
    dict(name="c32x1024_file",     p=dict(DW=32, DEPTH=1024, INITM=2, INITF="@hex:32x1024"), seeds=[1], ic=True, note="INIT_MODE=FILE"),
    # ---- 64-bit: additional verified configuration
    dict(name="c64x1024",          p=dict(DW=64, DEPTH=1024),                       seeds=[1, 2, 3], ic=True,  xs=True,  note="64-bit primary"),
    dict(name="c64x1024_noack",    p=dict(DW=64, DEPTH=1024, WACK=0),               seeds=[1],       ic=True,  note="64-bit posted writes"),
    dict(name="c64x1024_lat2",     p=dict(DW=64, DEPTH=1024, LAT=2),                seeds=[1],       ic=True,  note="64-bit latency 2"),
    dict(name="c64x1000_a11",      p=dict(DW=64, DEPTH=1000, AW=11),                seeds=[1],       ic=True,  note="64-bit non-pow2 + wide address"),
    dict(name="c64x1024_file",     p=dict(DW=64, DEPTH=1024, INITM=2, INITF="@hex:64x1024"), seeds=[1], ic=True, note="64-bit INIT_MODE=FILE"),
    dict(name="c64x1024_pattern",  p=dict(DW=64, DEPTH=1024, INITM=3),              seeds=[1],       ic=True,  note="64-bit INIT_MODE=PATTERN"),
    # ---- generalisation: widths, depths, lane widths
    dict(name="c8x256",            p=dict(DW=8, DEPTH=256),                         seeds=[1],       ic=True,  note="1 lane"),
    dict(name="c16x512",           p=dict(DW=16, DEPTH=512, LAT=2),                 seeds=[1],       ic=True,  note="2 lanes"),
    dict(name="c24x300",           p=dict(DW=24, DEPTH=300),                        seeds=[1],       ic=True,  note="3 lanes, non-pow2 depth"),
    dict(name="c72x256_bw9",       p=dict(DW=72, DEPTH=256, BW=9),                  seeds=[1],       ic=True,  note="9-bit lanes (parity lanes)"),
    dict(name="c128x64",           p=dict(DW=128, DEPTH=64),                        seeds=[1],       ic=True,  note="16 lanes"),
    dict(name="c32x2",             p=dict(DW=32, DEPTH=2),                          seeds=[1],       ic=True,  note="minimum depth"),
    dict(name="c32x3",             p=dict(DW=32, DEPTH=3),                          seeds=[1],       ic=True,  note="depth 3, one invalid address"),
    dict(name="c32x4096_lat2",     p=dict(DW=32, DEPTH=4096, LAT=2, NRAND=20000),   seeds=[1],       ic=False, note="larger array"),
]

# illegal parameterisations: (name, sf_sram_core parameter overrides, extra defines, expected message fragment)
NEGATIVE = [
    ("data_width_not_multiple",   dict(DATA_WIDTH=33),                           [], "multiple of BYTE_WIDTH"),
    ("data_width_below_byte",     dict(DATA_WIDTH=4),                            [], "multiple of BYTE_WIDTH"),
    ("byte_width_zero",           dict(BYTE_WIDTH=0),                            [], None),
    ("depth_one",                 dict(DEPTH_WORDS=1),                           [], "DEPTH_WORDS must be >= 2"),
    ("depth_zero",                dict(DEPTH_WORDS=0),                           [], "DEPTH_WORDS must be >= 2"),
    ("depth_negative",            dict(DEPTH_WORDS=-4),                          [], "DEPTH_WORDS must be >= 2"),
    ("addr_width_too_small",      dict(DEPTH_WORDS=1024, ADDR_WIDTH=9),          [], "unreachable"),
    ("addr_width_zero",           dict(ADDR_WIDTH=0),                            [], "ADDR_WIDTH must be in 1..30"),
    ("addr_width_31",             dict(ADDR_WIDTH=31),                           [], "ADDR_WIDTH must be in 1..30"),
    ("read_latency_zero",         dict(READ_LATENCY=0),                          [], "READ_LATENCY must be >= 1"),
    ("read_latency_negative",     dict(READ_LATENCY=-1),                         [], "READ_LATENCY must be >= 1"),
    ("write_ack_2",               dict(WRITE_ACK=2),                             [], "WRITE_ACK must be 0 or 1"),
    ("oob_assert_2",              dict(OOB_ASSERT=2),                            [], "OOB_ASSERT must be 0 or 1"),
    ("init_mode_7",               dict(INIT_MODE=7),                             [], "INIT_MODE must be one of"),
    ("init_file_missing",         dict(INIT_MODE=2),                             [], "requires INIT_FILE"),
    ("init_pattern_in_synthesis", dict(INIT_MODE=3),                             ["SYNTHESIS"], "simulation-only"),
]


def sh(cmd, cwd=None, timeout=3600, env=None) -> dict:
    t0 = time.time()
    try:
        p = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
        rc, out = p.returncode, p.stdout + p.stderr
    except subprocess.TimeoutExpired as e:
        rc, out = -9, f"TIMEOUT after {timeout}s\n{(e.stdout or b'').decode(errors='replace') if isinstance(e.stdout, bytes) else (e.stdout or '')}"
    return {"cmd": " ".join(str(c) for c in cmd), "rc": rc, "out": out, "secs": round(time.time() - t0, 2)}


def tool_versions() -> dict:
    def first_line(cmd):
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            return (r.stdout + r.stderr).strip().splitlines()[0]
        except Exception:
            return "NOT INSTALLED"
    return {
        "verilator": first_line(["verilator", "--version"]),
        "iverilog": first_line(["iverilog", "-V"]),
        "yosys": first_line(["yosys", "-V"]),
        "python": platform.python_version(),
        "vivado": "NOT INSTALLED" if not shutil.which("vivado") else "present",
        "quartus": "NOT INSTALLED" if not shutil.which("quartus_sh") else "present",
        "openroad": "NOT INSTALLED" if not shutil.which("openroad") else "present",
    }


def src_hash(files) -> str:
    h = hashlib.sha256()
    for f in sorted(str(x) for x in files):
        h.update(f.encode())
        h.update(Path(f).read_bytes())
    return h.hexdigest()


def provenance(extra=None) -> dict:
    d = {"generated": _dt.datetime.now(_dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
         "tools": tool_versions(),
         "rtl_sha256": src_hash([*RTL.glob("*.sv"), *RTL.glob("*.svh")])}
    if extra:
        d.update(extra)
    return d


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, sort_keys=False) + "\n")


def ensure_hex(spec: str, ) -> str:
    """'@hex:<DW>x<DEPTH>' -> path of a deterministic init image (generated on demand)."""
    _, wd = spec.split(":")
    dw, depth = (int(v) for v in wd.split("x"))
    path = BUILD / f"init_{dw}x{depth}.hex"
    if not path.exists():
        BUILD.mkdir(parents=True, exist_ok=True)
        mask = (1 << dw) - 1
        lines = []
        x = 0x243F6A8885A308D3
        for i in range(depth):
            w = 0
            for k in range((dw + 63) // 64):
                x ^= (x << 13) & ((1 << 64) - 1)
                x ^= x >> 7
                x ^= (x << 17) & ((1 << 64) - 1)
                w |= x << (64 * k)
            lines.append(f"{(w ^ (i * 0x9E3779B97F4A7C15)) & mask:0{(dw + 3) // 4}x}")
        path.write_text("\n".join(lines) + "\n")
    return str(path)
