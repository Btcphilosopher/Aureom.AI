#!/usr/bin/env bash
# Build the deliverable archive.  Writes ../silicaflux-sramcore-p71.zip (next to the project directory).
# Excludes build/ and caches.  Regenerates SHA256SUMS (every delivered file).  Does NOT touch git.
set -euo pipefail
cd "$(dirname "$0")/.."
PROJ="$(basename "$PWD")"
OUT="$(cd .. && pwd)/silicaflux-sramcore-p71.zip"
find . -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
rm -f SHA256SUMS
find . -type f ! -path './build*/*' ! -name SHA256SUMS | LC_ALL=C sort | sed 's|^\./||' | xargs sha256sum > SHA256SUMS
rm -f "$OUT"
cd ..
zip -q -r -X "$OUT" "$PROJ" -x "$PROJ/build*/*" -x "*/__pycache__/*" -x "*.pyc"
echo "wrote $OUT"
unzip -l "$OUT" | tail -1
