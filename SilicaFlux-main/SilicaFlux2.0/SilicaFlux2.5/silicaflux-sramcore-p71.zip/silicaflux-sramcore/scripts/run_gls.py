#!/usr/bin/env python3
"""Gate-level simulation of Yosys netlists with the SAME self-checking testbench.

For each case the RTL is synthesised (generic `synth`, synth_xilinx xc7, synth_ice40, synth_ecp5), written out with
`write_verilog`, and simulated in Icarus Verilog with the behavioural cell models that ship with Yosys
(`simcells`-level for generic, share/yosys/<arch>/cells_sim.v for the FPGA flows) against tb_sf_sram_core compiled with
-DSF_NETLIST -DSF_GLS.  This checks that what the tools INFER from the RTL (block-RAM byte-write enables, init
images, lane widths, read register, bounds logic) behaves exactly as the RTL does.

Which flows can be simulated is decided by the cell models Yosys ships: the Xilinx RAMB18E1/RAMB36E1 and ECP5 DP16KD
models contain ONLY timing (`specify`) data and no function (verified: zero always/assign/initial statements), so block-RAM
netlists of those two families CANNOT be simulated here and are covered by inference evidence only (reports/synth.md).
Simulated instead: generic gates, iCE40 block RAM (SB_RAM40_4K has a functional model) and the xc7 flow forced to
distributed RAM (`-nobram`; functional LUT-RAM models), which exercises the Xilinx LUT/FF mapping of the bounds, response
and write-enable logic.

Limits (stated in the report): the cell models are Yosys' behavioural models, not the vendors' sign-off simulation
models; no timing, no vendor tool.  The 4-state "unwritten bit is X" and "rdata poisoned" checks are RTL-simulation
properties (block RAM powers up as zeros in the models) and are disabled with SF_GLS.

Output: reports/gls.md / .json
"""
from __future__ import annotations

import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, INC_DIRS, REPORTS, RTL, RTL_FILES, TB, ensure_hex, provenance, sh, write_json  # noqa: E402
from run_regress import parse_result  # noqa: E402
from run_synth import chparams  # noqa: E402

YS = Path("/usr/share/yosys")
LIBS = {"generic": [], "xc7_lutram": [YS / "xilinx/cells_sim.v"], "ice40": [YS / "ice40/cells_sim.v"]}
SYN = {"generic": "synth -top sf_sram_core -flatten", "xc7_lutram": "synth_xilinx -family xc7 -nobram -noiopad -top sf_sram_core",
       "ice40": "synth_ice40 -top sf_sram_core"}
FLOWNAME = {"generic": "synth (generic gates)", "xc7_lutram": "synth_xilinx -family xc7 -nobram (distributed RAM)", "ice40": "synth_ice40 (SB_RAM40_4K block RAM)"}

CASES = [
    # name, flow, params, random cycles
    ("32x256, 10-bit address (bounds check active)", "generic",    dict(DW=32, DEPTH=256, AW=10),              3000),
    ("32x300 non-pow2, latency 2, posted writes",   "generic",    dict(DW=32, DEPTH=300, LAT=2, WACK=0),      3000),
    ("64x128",                                       "generic",    dict(DW=64, DEPTH=128),                     3000),
    ("28x100, 4-bit lanes",                          "generic",    dict(DW=28, DEPTH=100, BW=4, AW=8),         3000),
    ("72x64, 9-bit lanes",                           "generic",    dict(DW=72, DEPTH=64, BW=9),                3000),
    ("32x256, 10-bit address",                       "xc7_lutram", dict(DW=32, DEPTH=256, AW=10),              4000),
    ("64x128 latency 2, 8-bit address",              "xc7_lutram", dict(DW=64, DEPTH=128, LAT=2, AW=8),        4000),
    ("32x300 non-pow2, posted writes",               "xc7_lutram", dict(DW=32, DEPTH=300, WACK=0),             4000),
    ("16x256",                                       "ice40",      dict(DW=16, DEPTH=256),                     6000),
    ("16x1024, 12-bit address",                      "ice40",      dict(DW=16, DEPTH=1024, AW=12),             6000),
    ("16x1000 non-pow2, latency 2",                  "ice40",      dict(DW=16, DEPTH=1000, LAT=2),             6000),
    ("16x512 INIT_MODE=ZERO",                        "ice40",      dict(DW=16, DEPTH=512, INITM=1),            4000),
    ("16x512 INIT_MODE=FILE",                        "ice40",      dict(DW=16, DEPTH=512, INITM=2, INITF="@hex:16x512"), 4000),
]


def run_case(idx: int, row) -> dict:
    name, flow, p, nrand = row
    d = BUILD / "gls" / f"g{idx:02d}"
    d.mkdir(parents=True, exist_ok=True)
    net = d / "net.v"
    script = (f"read_verilog -sv -I{RTL} {' '.join(str(f) for f in RTL_FILES)}; {chparams('sf_sram_core', p)} "
              f"hierarchy -check -top sf_sram_core; {SYN[flow]}; write_verilog -noattr {net}")
    y = sh(["yosys", "-q", "-p", script], timeout=900)
    rec = {"name": name, "flow": flow, "params": {k: v for k, v in p.items() if k != "INITF"}, "script": script}
    if y["rc"] != 0:
        rec.update(result="FAIL", detail="synthesis failed: " + y["out"][-300:])
        return rec
    top = "tb_sf_sram_core"
    pp = []
    for k, v in p.items():
        if isinstance(v, str) and v.startswith("@hex:"):
            v = ensure_hex(v)
        pp.append(f'-P{top}.{k}="{v}"' if isinstance(v, str) else f"-P{top}.{k}={v}")
    vvp = d / "gls.vvp"
    b = sh(["iverilog", "-g2012", "-DSF_NETLIST", "-DSF_GLS", *[f"-I{x}" for x in INC_DIRS], "-s", top, "-o", vvp, *pp,
            TB / "tb_sf_sram_core.sv", net, *LIBS[flow]], timeout=900)
    if b["rc"] != 0:
        rec.update(result="FAIL", detail="iverilog failed: " + b["out"][-400:])
        return rec
    r = sh(["vvp", "-n", vvp, "+seed=1", f"+nrand={nrand}"], timeout=3000)
    res = parse_result(r["out"])
    rec.update(result=res["result"], checks=res["checks"], errors=res["errors"], nrand=nrand, secs=r["secs"],
               detail="" if res["result"] == "PASS" else "; ".join(res["first_errors"]) or r["out"][-300:])
    return rec


def main() -> int:
    BUILD.mkdir(parents=True, exist_ok=True)
    with ThreadPoolExecutor(4) as ex:
        recs = list(ex.map(lambda t: run_case(*t), list(enumerate(CASES, 1))))
    nfail = sum(r["result"] != "PASS" for r in recs)
    write_json(REPORTS / "gls.json", {"provenance": provenance(), "records": recs,
                                      "summary": {"total": len(recs), "pass": len(recs) - nfail, "fail": nfail}})
    L = ["# Gate-level simulation report", "",
         f"{len(recs) - nfail} pass / {nfail} fail of {len(recs)} synthesised netlists simulated with the same self-checking testbench "
         "(Icarus Verilog; Yosys behavioural cell models; seed 1).", "",
         "| netlist | flow | checks | errors | random cycles | result |", "|---|---|---|---|---|---|"]
    for r in recs:
        L.append(f"| {r['name']} | `{FLOWNAME[r['flow']]}` | {r.get('checks', '-')} | {r.get('errors', '-')} | {r.get('nrand', '-')} | {r['result']} |")
    L += ["", "**Not simulated:** Xilinx RAMB18E1/RAMB36E1 and ECP5 DP16KD block-RAM netlists - the cell models shipped with this Yosys contain only "
          "timing data and no function, so those netlists have inference evidence only (reports/synth.md).  The xc7 rows above use "
          "distributed RAM (`-nobram`), not block RAM.", "",
          "Limits: Yosys' behavioural models, not vendor sign-off models; no timing; the RTL-only 4-state checks (unwritten bits are X, "
          "rdata poison) are disabled for netlists.", ""]
    if nfail:
        L += ["## Failures", ""] + [f"* {r['name']}: {r.get('detail', '')}" for r in recs if r["result"] != "PASS"]
    (REPORTS / "gls.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 1 if nfail else 0


if __name__ == "__main__":
    sys.exit(main())
