// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: sf_sram_array
// Storage array: one synchronous read/write port, byte-lane write enables,
// READ_LATENCY-cycle synchronous read.  Inferred memory (no vendor IP core).
//
// Raw contract (identical in shape and timing to the SilicaFlux SRAM Wrapper
// Library's sram_backend_1rw, so a library ASIC/FPGA backend can replace this
// module unchanged -- see docs/03_implementation_fpga_vs_asic.md):
//   * One access per cycle.  ce=1 selects the port; we=1 write, we=0 read.
//   * Write : lanes with wmask[l]=1 take wdata lane l at the rising edge; all
//             other lanes keep their stored value.  A write cycle produces no
//             read data and leaves the read output register untouched
//             ("no-change" mode).
//   * Read  : rdata is valid EXACTLY READ_LATENCY cycles after the read edge,
//             for that one cycle.  It is NOT held afterwards.
//   * idx must be < DEPTH_WORDS (sf_sram_core guarantees it).
//   * The array and the read data registers are NEVER reset.  The only
//     initial content is what INIT_MODE says.
//
// Coding template: single clock, read in the else-branch of the write enable,
// per-lane write enables in a for loop, no reset on any storage or output
// register, no asynchronous read.  This is the single-port byte-write
// template recognised by Vivado, Quartus, Yosys (synth_xilinx / ice40 / ecp5).
// No ram_style attribute is applied: the tool chooses the primitive.  Add
// (* ram_style = "block" *) / (* ramstyle = "M20K" *) at the call site if a
// specific resource is required.
//
// READ_LATENCY: 1 = memory read register (block-RAM output latch);
//   2 = plus one more register stage with no reset and no enable, which a vendor
//   tool MAY merge into the block RAM's optional output register; >= 3 adds
//   fabric pipeline registers.  Yosys 0.33 synth_xilinx does NOT merge it (the
//   stage stays in fabric flip-flops, see reports/synth.md); Vivado/Quartus
//   behaviour was not checked here (no vendor tool available).
//
// Classification: SYNTHESIZABLE (block-RAM inference)
// =============================================================================
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_array #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH_WORDS  = 1024,
  parameter int BYTE_WIDTH   = 8,
  parameter int READ_LATENCY = 1,
  parameter int INIT_MODE    = `SF_SRAM_INIT_NONE,
  parameter     INIT_FILE    = "",
  localparam int IDX_WIDTH   = (DEPTH_WORDS > 1) ? $clog2(DEPTH_WORDS) : 1,
  localparam int LANES       = DATA_WIDTH / BYTE_WIDTH
) (
  input  wire logic                  clk,
  input  wire logic                  ce,
  input  wire logic                  we,
  input  wire logic [LANES-1:0]      wmask,
  input  wire logic [IDX_WIDTH-1:0]  idx,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  output logic      [DATA_WIDTH-1:0] rdata
);

  // ------------------------------------------------ parameter checks
  if (BYTE_WIDTH < 1) begin : g_err_byte_width_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_array: BYTE_WIDTH must be >= 1")
  end
  if (DATA_WIDTH < BYTE_WIDTH || (DATA_WIDTH % BYTE_WIDTH) != 0) begin : g_err_data_width_not_multiple_of_byte_width
    `SF_SRAM_CFG_FATAL("sf_sram_array: DATA_WIDTH must be a multiple of BYTE_WIDTH (and >= BYTE_WIDTH)")
  end
  if (DEPTH_WORDS < 2) begin : g_err_depth_lt_2
    `SF_SRAM_CFG_FATAL("sf_sram_array: DEPTH_WORDS must be >= 2")
  end
  if (READ_LATENCY < 1) begin : g_err_read_latency_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_array: READ_LATENCY must be >= 1 (asynchronous read is not supported)")
  end
  if (INIT_MODE < `SF_SRAM_INIT_NONE || INIT_MODE > `SF_SRAM_INIT_PATTERN) begin : g_err_init_mode_invalid
    `SF_SRAM_CFG_FATAL("sf_sram_array: INIT_MODE must be one of SF_SRAM_INIT_NONE/ZERO/FILE/PATTERN")
  end
  if (INIT_MODE == `SF_SRAM_INIT_FILE && INIT_FILE == "") begin : g_err_init_file_missing
    `SF_SRAM_CFG_FATAL("sf_sram_array: INIT_MODE=FILE requires INIT_FILE")
  end
`ifdef SYNTHESIS
  if (INIT_MODE == `SF_SRAM_INIT_PATTERN) begin : g_err_init_pattern_is_sim_only
    `SF_SRAM_CFG_FATAL("sf_sram_array: INIT_MODE=PATTERN is simulation-only")
  end
`endif

  // ------------------------------------------------ storage
  logic [DATA_WIDTH-1:0] mem [DEPTH_WORDS];
  logic [DATA_WIDTH-1:0] q0;

  // Deterministic non-zero pattern (INIT_MODE=PATTERN).  Per 32-bit chunk k of
  // word i:  h = i*0x9E3779B1 ^ (k+1)*0x85EBCA6B ^ 0xC2B2AE35;
  //          h ^= h>>15;  h *= 0x2C1B3C6D;  h ^= h>>12.
  localparam int NCHUNK = (DATA_WIDTH + 31) / 32;
  function automatic logic [DATA_WIDTH-1:0] init_pattern(input int unsigned i);
    logic [DATA_WIDTH-1:0] w;
    logic [31:0]           h;
    w = '0;
    for (int k = 0; k < NCHUNK; k++) begin
      h = (32'(i) * 32'h9E3779B1) ^ (32'(k + 1) * 32'h85EBCA6B) ^ 32'hC2B2AE35;
      h = h ^ (h >> 15);
      h = h * 32'h2C1B3C6D;
      h = h ^ (h >> 12);
      for (int b = 0; b < 32; b++)
        if (k * 32 + b < DATA_WIDTH) w[k * 32 + b] = h[b];
    end
    init_pattern = w;
  endfunction

  initial begin
    if (INIT_MODE == `SF_SRAM_INIT_ZERO) begin
      for (int i = 0; i < DEPTH_WORDS; i++) mem[i] = '0;
    end else if (INIT_MODE == `SF_SRAM_INIT_FILE) begin
      $readmemh(INIT_FILE, mem);
    end else if (INIT_MODE == `SF_SRAM_INIT_PATTERN) begin
      for (int i = 0; i < DEPTH_WORDS; i++) mem[i] = init_pattern(i);
    end
  end

  always_ff @(posedge clk) begin
    if (ce) begin
      if (we) begin
        for (int l = 0; l < LANES; l++) begin
          if (wmask[l]) mem[idx][l*BYTE_WIDTH +: BYTE_WIDTH] <= wdata[l*BYTE_WIDTH +: BYTE_WIDTH];
        end
      end else begin
        q0 <= mem[idx];
      end
    end
  end

  // ------------------------------------------------ read latency pipeline
  if (READ_LATENCY == 1) begin : g_lat1
    assign rdata = q0;
  end else begin : g_latn
    logic [DATA_WIDTH-1:0] pipe [READ_LATENCY-1];
    always_ff @(posedge clk) begin
      pipe[0] <= q0;
      for (int k = 1; k < READ_LATENCY - 1; k++) pipe[k] <= pipe[k-1];
    end
    assign rdata = pipe[READ_LATENCY-2];
  end

endmodule

`default_nettype wire
