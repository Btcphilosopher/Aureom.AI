// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: sf_sram_if
// Reusable SRAM port bundle for sf_sram_core and any compatible memory
// (caches, tensor operand buffers, vector scratchpads, ControlCore memory).
//
//   master  : the requester (drives ce/we/addr/wmask/wdata, samples responses)
//   slave   : the memory   (samples requests, drives rdata/rd_valid/rd_err/
//             wr_ack/wr_err)
//   monitor : passive observer (all signals input)
//
// The interface parameters describe the PROTOCOL SHAPE only (widths, response
// timing).  Size, initial content and the storage implementation belong to
// the slave (sf_sram_core_if).
//
// Built-in protocol checker (simulation only, excluded when SYNTHESIS is
// defined).  It is an independent re-statement of the protocol, usable at
// any hierarchy level of a system simulation to police a memory port:
//   * ce is never X/Z out of reset; we/addr (and wmask for writes) are never
//     X/Z during an access;
//   * rd_valid pulses exactly READ_LATENCY cycles after each read access;
//   * wr_ack pulses exactly 1 cycle after each write access (WRITE_ACK=1) and
//     never otherwise (WRITE_ACK=0);
//   * rd_err only with rd_valid; every response flag is known (not X/Z).
// Not usable with Icarus Verilog 12 (no SV interface support) or Yosys 0.33;
// the flat-port sf_sram_core is the synthesis and Icarus view of the same
// block.  CHECKER=0 disables the checks.
// =============================================================================
`default_nettype none

interface sf_sram_if #(
  parameter int DATA_WIDTH   = 32,
  parameter int ADDR_WIDTH   = 10,
  parameter int BYTE_WIDTH   = 8,
  parameter int READ_LATENCY = 1,
  parameter int WRITE_ACK    = 1,
  parameter int CHECKER      = 1
) (
  input wire logic clk,
  input wire logic rst_n
);

  localparam int LANES = DATA_WIDTH / BYTE_WIDTH;

  // The bundle's signals are consumed outside it (by the master / the memory); inside it only the checker reads some.
  /* verilator lint_off UNUSEDSIGNAL */
  // request (master -> memory)
  logic                  ce;
  logic                  we;
  logic [ADDR_WIDTH-1:0] addr;
  logic [LANES-1:0]      wmask;
  logic [DATA_WIDTH-1:0] wdata;
  // response (memory -> master)
  logic [DATA_WIDTH-1:0] rdata;
  logic                  rd_valid;
  logic                  rd_err;
  logic                  wr_ack;
  logic                  wr_err;
  /* verilator lint_on UNUSEDSIGNAL */

  modport master (
    input  clk, rst_n,
    output ce, we, addr, wmask, wdata,
    input  rdata, rd_valid, rd_err, wr_ack, wr_err
  );

  modport slave (
    input  clk, rst_n,
    input  ce, we, addr, wmask, wdata,
    output rdata, rd_valid, rd_err, wr_ack, wr_err
  );

  modport monitor (
    input clk, rst_n, ce, we, addr, wmask, wdata, rdata, rd_valid, rd_err, wr_ack, wr_err
  );

`ifndef SYNTHESIS
  if (CHECKER != 0) begin : g_checker
    // expected response flags, one shift register per response kind
    logic [READ_LATENCY-1:0] rv_sh;
    logic                    wa_sh;

    always @(posedge clk or negedge rst_n) begin
      if (!rst_n) begin
        rv_sh <= '0;
        wa_sh <= 1'b0;
      end else begin
        rv_sh[0] <= (ce === 1'b1) && (we === 1'b0);
        for (int k = 1; k < READ_LATENCY; k++) rv_sh[k] <= rv_sh[k-1];
        wa_sh <= (ce === 1'b1) && (we === 1'b1);
      end
    end

    always @(posedge clk) begin
      if (rst_n) begin
        assert (!$isunknown(ce)) else $error("SF_SRAM_IF_X %m: ce is X/Z");
        if (ce === 1'b1) begin
          assert (!$isunknown({we, addr})) else $error("SF_SRAM_IF_X %m: we/addr is X/Z during an access");
          if (we === 1'b1)
            assert (!$isunknown(wmask)) else $error("SF_SRAM_IF_X %m: wmask is X/Z during a write");
        end
        assert (!$isunknown({rd_valid, rd_err, wr_ack, wr_err})) else $error("SF_SRAM_IF_X %m: response flag is X/Z");
        assert (rd_valid === rv_sh[READ_LATENCY-1]) else
          $error("SF_SRAM_IF_PROTO %m: rd_valid=%b but a read was %saccepted READ_LATENCY=%0d cycles ago",
                 rd_valid, rv_sh[READ_LATENCY-1] ? "" : "not ", READ_LATENCY);
        assert (wr_ack === ((WRITE_ACK != 0) ? wa_sh : 1'b0)) else
          $error("SF_SRAM_IF_PROTO %m: wr_ack=%b inconsistent with WRITE_ACK=%0d and the previous cycle", wr_ack, WRITE_ACK);
        assert (!rd_err || rd_valid) else $error("SF_SRAM_IF_PROTO %m: rd_err without rd_valid");
      end
    end
  end
`endif

endinterface

`default_nettype wire
