// SRAMCore (Project 71) source list, compile order.   +incdir+rtl/sram
rtl/sram/sf_sram_array.sv
rtl/sram/sf_sram_core.sv
// optional, simulators with SystemVerilog interface support only (not Icarus 12 / Yosys 0.33):
// rtl/sram/sf_sram_if.sv
// rtl/sram/sf_sram_core_if.sv
