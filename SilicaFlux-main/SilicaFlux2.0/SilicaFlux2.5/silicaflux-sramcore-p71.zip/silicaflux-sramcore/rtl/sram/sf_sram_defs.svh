// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: sf_sram_defs.svh
//
// Constants shared by sf_sram_array / sf_sram_core.  A `define header rather
// than a SystemVerilog package, for the same reason as the SRAM Wrapper
// Library (Project 01): Yosys 0.33 cannot resolve package references in
// module parameter lists, and every synthesizable module here must elaborate
// unaided in Verilator, Icarus and Yosys.  All names carry the SF_SRAM_
// prefix, so this header can be included next to Project 01's sram_defs.svh.
//
// Values are part of the public contract: never renumber, only append.
// =============================================================================
`ifndef SF_SRAM_DEFS_SVH
`define SF_SRAM_DEFS_SVH

// ---------------------------------------------------------------- INIT_MODE
// Power-up content of the storage array.
//   NONE    : no initial content.  The only mode that corresponds to an ASIC
//             SRAM macro (cells power up with undefined content).  Simulation:
//             X in a 4-state simulator, tool-defined in a 2-state one.
//   ZERO    : every bit 0 at configuration/power-up.  FPGA block RAM
//             (bitstream initialisation) and simulation only.
//   FILE    : $readmemh(INIT_FILE).  FPGA and simulation only.
//   PATTERN : deterministic, non-zero junk word per address (see
//             sf_sram_array.sv).  Simulation only: rejected when SYNTHESIS is
//             defined.  Exists so a 2-state simulator can prove that nothing
//             relies on "unwritten SRAM reads as zero".
`define SF_SRAM_INIT_NONE    0
`define SF_SRAM_INIT_ZERO    1
`define SF_SRAM_INIT_FILE    2
`define SF_SRAM_INIT_PATTERN 3

// ------------------------------------------------- configuration errors
// Elaboration-time failure for illegal parameterisations.  Icarus 12 does not
// evaluate elaboration-time $fatal, so it gets a time-0 $fatal instead.
// Yosys 0.33 aborts on the $fatal but does not print the message; the message
// is therefore also encoded in the generate-block name (g_err_*).
`ifdef __ICARUS__
  `define SF_SRAM_CFG_FATAL(msg) initial $fatal(1, msg);
`else
  `define SF_SRAM_CFG_FATAL(msg) $fatal(1, msg);
`endif

`endif // SF_SRAM_DEFS_SVH
