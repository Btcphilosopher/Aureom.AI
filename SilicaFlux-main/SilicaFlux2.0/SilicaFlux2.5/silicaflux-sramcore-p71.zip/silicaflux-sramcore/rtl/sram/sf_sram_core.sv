// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: sf_sram_core            -- primary RTL
// Configurable synchronous single-port SRAM: one read/write port, byte-lane
// write enables, READ_LATENCY-cycle read, read-data-valid, optional write
// acknowledgement, explicit bounds policy.
// Aureom.AI | SilicaFlux Semiconductor Systems
//
// ---------------------------------------------------------------------------
// Interface (flat ports, same naming as the SRAM Wrapper Library raw contract)
//   clk, rst_n     rst_n: active low, asynchronous assert, SYNCHRONOUS release
//                  (release it from a reset synchroniser).  It resets only the
//                  response pipelines.  The storage array and the read data
//                  registers are never reset.
//   ce, we         ce=0: idle (no access, no response).  ce=1: exactly one
//                  access, we=1 write / we=0 read.  There is no ready: every
//                  access is accepted in the cycle it is presented.
//   addr           ADDR_WIDTH-bit WORD address.
//   wmask          byte enables, one bit per BYTE_WIDTH-bit lane; lane l is
//                  wdata/rdata bits [l*BYTE_WIDTH +: BYTE_WIDTH] (lane 0 =
//                  least-significant byte, i.e. little-endian).
//   wdata          write data (only lanes with wmask=1 are used).
//   rdata          read data; meaningful ONLY in a cycle with rd_valid=1.
//   rd_valid       one pulse per accepted read, exactly READ_LATENCY cycles
//                  after the cycle the read was presented (valid or not).
//   rd_err         with rd_valid: the read address was invalid.  rdata is then
//                  all zeros and the array was not accessed.
//   wr_ack         WRITE_ACK=1: one pulse per accepted write, exactly 1 cycle
//                  after the write was presented (also for invalid writes,
//                  together with wr_err = NAK).  WRITE_ACK=0: tied low (posted).
//   wr_err         one pulse, 1 cycle after an INVALID write, ALWAYS generated
//                  (also with WRITE_ACK=0): errors are never silent.
//
// ---------------------------------------------------------------------------
// Semantics (full text: docs/01_interface_and_semantics.md).  Cycle t = the
// cycle in which ce/we/addr/... are presented; they are sampled at the rising
// clock edge that ends cycle t.
//   Read  (ce=1,we=0)  array read at the edge ending t; rd_valid=1 and rdata
//                      valid in cycle t+READ_LATENCY.  Returns the content
//                      after every write presented in cycles <= t-1.
//   Write (ce=1,we=1)  lanes with wmask=1 written at the edge ending t; any
//                      read presented in cycle >= t+1 observes it.  A write
//                      with wmask=0 is a legal write that changes nothing.
//   Idle  (ce=0)       nothing happens; we/addr/wmask/wdata are don't-care.
//   Same-cycle read+write to one word cannot occur: one port, one operation
//                      per cycle (we selects).  Read-after-write in the next
//                      cycle returns the new data (there is no forwarding
//                      hazard: the write is complete at the edge).
//   Invalid address    addr >= DEPTH_WORDS.  Never reaches the array (no read,
//                      no write, no aliasing); answered as described above.
//                      Possible when DEPTH_WORDS is not 2**ADDR_WIDTH.
//   During reset       rst_n=0: accesses are ignored (no array access, no
//                      response) and in-flight responses are dropped.  The
//                      array contents survive reset.
//
// Parameters (illegal values fail elaboration, see the g_err_* blocks)
//   DATA_WIDTH     bits per word; multiple of BYTE_WIDTH.  Verified: 32, 64
//                  (+ 8, 16, 24, 72, 128 in the sweep).
//   DEPTH_WORDS    number of words, >= 2.  Any value, not only powers of two.
//   ADDR_WIDTH     address port width; >= clog2(DEPTH_WORDS), <= 30.  Default
//                  clog2(DEPTH_WORDS).  A wider port makes invalid addresses
//                  representable for power-of-two depths too.
//   BYTE_WIDTH     lane width, default 8 (9 supports 9-bit parity lanes).
//   READ_LATENCY   >= 1 (1 = memory read register / block-RAM latch; >= 2 adds one
//                  register stage per extra cycle, which a vendor tool MAY merge
//                  into the block RAM's output register - Yosys 0.33 does not).
//   INIT_MODE      SF_SRAM_INIT_NONE / ZERO / FILE / PATTERN (sf_sram_defs.svh).
//   INIT_FILE      $readmemh image for INIT_MODE=FILE.
//   WRITE_ACK      1: acknowledge every write (default); 0: posted writes.
//   OOB_ASSERT     1 (default): simulation reports every invalid access with
//                  $error (a system that never issues invalid addresses wants
//                  to hear about them).  0: silent in simulation.  The
//                  hardware behaviour (rd_err / wr_err) is the same for both.
//
// Classification: SYNTHESIZABLE.  Simulation-only extras are excluded when
// SYNTHESIS is defined.  SF_SRAM_POISON (simulation): rdata = X whenever
// rd_valid=0, so a consumer that relies on rdata being held fails.
// =============================================================================
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_core #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH_WORDS  = 1024,
  parameter int ADDR_WIDTH   = (DEPTH_WORDS > 1) ? $clog2(DEPTH_WORDS) : 1,
  parameter int BYTE_WIDTH   = 8,
  parameter int READ_LATENCY = 1,
  parameter int INIT_MODE    = `SF_SRAM_INIT_NONE,
  parameter     INIT_FILE    = "",
  parameter int WRITE_ACK    = 1,
  parameter int OOB_ASSERT   = 1,
  localparam int LANES       = DATA_WIDTH / BYTE_WIDTH,
  localparam int IDX_WIDTH   = (DEPTH_WORDS > 1) ? $clog2(DEPTH_WORDS) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  rst_n,
  input  wire logic                  ce,
  input  wire logic                  we,
  input  wire logic [ADDR_WIDTH-1:0] addr,
  input  wire logic [LANES-1:0]      wmask,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  output logic      [DATA_WIDTH-1:0] rdata,
  output logic                       rd_valid,
  output logic                       rd_err,
  output logic                       wr_ack,
  output logic                       wr_err
);

  // ------------------------------------------------ illegal parameterisations
  if (BYTE_WIDTH < 1) begin : g_err_byte_width_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_core: BYTE_WIDTH must be >= 1")
  end
  if (DATA_WIDTH < BYTE_WIDTH || (DATA_WIDTH % BYTE_WIDTH) != 0) begin : g_err_data_width_not_multiple_of_byte_width
    `SF_SRAM_CFG_FATAL("sf_sram_core: DATA_WIDTH must be a multiple of BYTE_WIDTH (and >= BYTE_WIDTH)")
  end
  if (DEPTH_WORDS < 2) begin : g_err_depth_lt_2
    `SF_SRAM_CFG_FATAL("sf_sram_core: DEPTH_WORDS must be >= 2")
  end
  if (ADDR_WIDTH < 1 || ADDR_WIDTH > 30) begin : g_err_addr_width_out_of_range_1_30
    `SF_SRAM_CFG_FATAL("sf_sram_core: ADDR_WIDTH must be in 1..30")
  end
  if (ADDR_WIDTH < IDX_WIDTH) begin : g_err_addr_width_cannot_reach_all_words
    `SF_SRAM_CFG_FATAL("sf_sram_core: ADDR_WIDTH < clog2(DEPTH_WORDS): some words would be unreachable")
  end
  if (READ_LATENCY < 1) begin : g_err_read_latency_lt_1
    `SF_SRAM_CFG_FATAL("sf_sram_core: READ_LATENCY must be >= 1 (asynchronous read is not supported)")
  end
  if (WRITE_ACK != 0 && WRITE_ACK != 1) begin : g_err_write_ack_not_0_or_1
    `SF_SRAM_CFG_FATAL("sf_sram_core: WRITE_ACK must be 0 or 1")
  end
  if (OOB_ASSERT != 0 && OOB_ASSERT != 1) begin : g_err_oob_assert_not_0_or_1
    `SF_SRAM_CFG_FATAL("sf_sram_core: OOB_ASSERT must be 0 or 1")
  end
  // INIT_MODE / INIT_FILE are checked in sf_sram_array.

  // ------------------------------------------------ bounds check
  // Every address representable on the port is valid iff the depth is exactly
  // 2**ADDR_WIDTH; then the check is the constant 1 and costs nothing.
  localparam bit                 ALL_VALID = (ADDR_WIDTH == IDX_WIDTH) && (DEPTH_WORDS == (1 << IDX_WIDTH));
  localparam logic [ADDR_WIDTH:0] DEPTH_W  = (ADDR_WIDTH + 1)'(DEPTH_WORDS);

  logic addr_ok;
  if (ALL_VALID) begin : g_all_valid
    assign addr_ok = 1'b1;
  end else begin : g_check
    assign addr_ok = ({1'b0, addr} < DEPTH_W);
  end

  // ------------------------------------------------ access decode
  // Accesses are ignored while rst_n=0 (controller in reset).  rst_n is
  // released synchronously, so this is an ordinary synchronous qualifier.
  logic acc, rd_acc, wr_acc, arr_ce;
  assign acc    = ce & rst_n;
  assign rd_acc = acc & ~we;
  assign wr_acc = acc &  we;
  assign arr_ce = acc & addr_ok;          // invalid addresses never reach the array

  // ------------------------------------------------ storage
  logic [DATA_WIDTH-1:0] arr_rdata;

  sf_sram_array #(
    .DATA_WIDTH(DATA_WIDTH), .DEPTH_WORDS(DEPTH_WORDS), .BYTE_WIDTH(BYTE_WIDTH),
    .READ_LATENCY(READ_LATENCY), .INIT_MODE(INIT_MODE), .INIT_FILE(INIT_FILE)
  ) u_array (
    .clk, .ce(arr_ce), .we, .wmask, .idx(addr[IDX_WIDTH-1:0]), .wdata, .rdata(arr_rdata)
  );

  // ------------------------------------------------ response pipelines
  // Control state only: valid/error flags are reset, data registers are not.
  logic [READ_LATENCY-1:0] rv_q, re_q;
  logic                    wa_q, we_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rv_q <= '0;
      re_q <= '0;
      wa_q <= 1'b0;
      we_q <= 1'b0;
    end else begin
      rv_q[0] <= rd_acc;
      re_q[0] <= rd_acc & ~addr_ok;
      for (int k = 1; k < READ_LATENCY; k++) begin
        rv_q[k] <= rv_q[k-1];
        re_q[k] <= re_q[k-1];
      end
      wa_q <= wr_acc;
      we_q <= wr_acc & ~addr_ok;
    end
  end

  assign rd_valid = rv_q[READ_LATENCY-1];
  assign rd_err   = re_q[READ_LATENCY-1];
  assign wr_ack   = (WRITE_ACK != 0) ? wa_q : 1'b0;
  assign wr_err   = we_q;

  // rdata: zero on an invalid read (deterministic), array output otherwise.
`ifndef SYNTHESIS
`ifdef SF_SRAM_POISON
  assign rdata = rd_valid ? (rd_err ? '0 : arr_rdata) : {DATA_WIDTH{1'bx}};
`else
  assign rdata = rd_err ? '0 : arr_rdata;
`endif
`else
  assign rdata = rd_err ? '0 : arr_rdata;
`endif

  // ------------------------------------------------ simulation assertions
`ifndef SYNTHESIS
  // Invalid accesses (hardware flags them; this reports them to the log).
  if (OOB_ASSERT != 0) begin : g_oob_assert
    always @(posedge clk) begin
      if (rd_acc) begin
        assert (addr_ok) else
          $error("SF_SRAM_ASSERT_OOB %m: invalid read address %0d (DEPTH_WORDS=%0d); access dropped, rd_err will be flagged",
                 addr, DEPTH_WORDS);
      end
      if (wr_acc) begin
        assert (addr_ok) else
          $error("SF_SRAM_ASSERT_OOB %m: invalid write address %0d (DEPTH_WORDS=%0d); access dropped, wr_err will be flagged",
                 addr, DEPTH_WORDS);
      end
    end
  end

  // Control inputs must be known whenever the controller is out of reset.
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!$isunknown(ce)) else $error("SF_SRAM_ASSERT_X %m: ce is X/Z");
      if (ce === 1'b1) begin
        assert (!$isunknown({we, addr})) else $error("SF_SRAM_ASSERT_X %m: we/addr is X/Z during an access");
        if (we === 1'b1)
          assert (!$isunknown(wmask)) else $error("SF_SRAM_ASSERT_X %m: wmask is X/Z during a write");
      end
    end
  end

  // Response consistency: an error flag never appears without its valid/ack.
  always @(posedge clk) begin
    if (rst_n) begin
      assert (!rd_err || rd_valid) else $error("SF_SRAM_ASSERT_INT %m: rd_err without rd_valid");
    end
  end
`endif

endmodule

`default_nettype wire
