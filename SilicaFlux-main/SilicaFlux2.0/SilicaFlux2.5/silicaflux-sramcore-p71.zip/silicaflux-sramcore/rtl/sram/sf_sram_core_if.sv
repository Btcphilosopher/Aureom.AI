// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: sf_sram_core_if
// sf_sram_core behind the sf_sram_if bundle.  Protocol shape (widths, read
// latency, write acknowledgement) comes from the interface instance; size,
// initial content and the assertion policy are parameters of this module.
// Pure wrapper: no logic of its own.  Simulation / lint-level view; the
// synthesis and Icarus view is the flat-port sf_sram_core.
// =============================================================================
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_core_if #(
  parameter int DEPTH_WORDS = 1024,
  parameter int INIT_MODE   = `SF_SRAM_INIT_NONE,
  parameter     INIT_FILE   = "",
  parameter int OOB_ASSERT  = 1
) (
  sf_sram_if.slave bus
);

  localparam int DW = bus.DATA_WIDTH;
  localparam int AW = bus.ADDR_WIDTH;
  localparam int BW = bus.BYTE_WIDTH;
  localparam int RL = bus.READ_LATENCY;
  localparam int WA = bus.WRITE_ACK;

  sf_sram_core #(
    .DATA_WIDTH(DW), .DEPTH_WORDS(DEPTH_WORDS), .ADDR_WIDTH(AW), .BYTE_WIDTH(BW),
    .READ_LATENCY(RL), .INIT_MODE(INIT_MODE), .INIT_FILE(INIT_FILE),
    .WRITE_ACK(WA), .OOB_ASSERT(OOB_ASSERT)
  ) u_core (
    .clk      (bus.clk),
    .rst_n    (bus.rst_n),
    .ce       (bus.ce),
    .we       (bus.we),
    .addr     (bus.addr),
    .wmask    (bus.wmask),
    .wdata    (bus.wdata),
    .rdata    (bus.rdata),
    .rd_valid (bus.rd_valid),
    .rd_err   (bus.rd_err),
    .wr_ack   (bus.wr_ack),
    .wr_err   (bus.wr_err)
  );

endmodule

`default_nettype wire
