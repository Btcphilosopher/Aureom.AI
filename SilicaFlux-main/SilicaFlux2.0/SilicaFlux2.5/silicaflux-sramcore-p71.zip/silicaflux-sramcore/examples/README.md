# Configuration examples

`sf_sram_examples.sv` pins parameter sets for the intended consumers.  They are **illustrative starting points, not confirmed
specifications** of those blocks.  Each module is linted (Verilator `-Wall`, Icarus `-Wall`) by `make sram-lint` and synthesised for xc7
by `make sram-synth` (see `reports/synth.md`).

| Module | Shape | Parameters |
|---|---|---|
| `sf_sram_ex_cpu_dcache_data` | 32 × 1024, 4 KiB | `READ_LATENCY=1, WRITE_ACK=0` |
| `sf_sram_ex_tensor_operand_buf` | 64 × 2048, 16 KiB | `READ_LATENCY=1, WRITE_ACK=1` |
| `sf_sram_ex_vector_spm_bank` | 64 × 4096, 32 KiB | `READ_LATENCY=2, WRITE_ACK=0` |
| `sf_sram_ex_controlcore_lmem` | 32 × 2048, 8 KiB | `INIT_MODE=FILE` (FPGA / simulation boot image) |
| `sf_sram_ex_parity_lane_buf` | 72 × 1024 | `BYTE_WIDTH=9` (8 lanes of `{parity, byte}`) |
| `sf_sram_ex_nibble_tag` | 28 × 600 | `BYTE_WIDTH=4`, depth not a power of two on a 10-bit port: addresses 600–1023 are flagged, never aliased |
| `sf_sram_ex_asic_style` | 64 × 1024 | `INIT_MODE=NONE, READ_LATENCY=2` — the shape that matches an ASIC macro |

## Minimal instantiation — the primary 32-bit × 1024 configuration

```systemverilog
sf_sram_core #(.DATA_WIDTH(32), .DEPTH_WORDS(1024)) u_mem (   // 1-cycle read, byte enables, write ack
  .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata,
  .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
```

64-bit: `.DATA_WIDTH(64)` (eight byte enables).  Invalid addresses: `.DEPTH_WORDS(1000)` or `.ADDR_WIDTH(12)` on a 1024-word array.

## Through the interface bundle

```systemverilog
sf_sram_if #(.DATA_WIDTH(64), .ADDR_WIDTH(11), .READ_LATENCY(2), .WRITE_ACK(1)) bus (.clk, .rst_n);
sf_sram_core_if #(.DEPTH_WORDS(1000)) u_mem (.bus(bus.slave));
// requester: module my_master (sf_sram_if.master bus);   monitor: sf_sram_if.monitor
```
(Verilator and other SV-interface-capable tools only; Icarus 12 and Yosys 0.33 cannot parse interfaces — use the flat ports there.)
