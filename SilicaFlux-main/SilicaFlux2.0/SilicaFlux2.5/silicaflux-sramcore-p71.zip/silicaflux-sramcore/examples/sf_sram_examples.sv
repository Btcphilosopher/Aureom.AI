// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: sf_sram_examples
// Configuration examples: one small module per intended consumer, each pinning
// a sf_sram_core parameter set.  ILLUSTRATIVE ONLY: the sizes and latencies are
// plausible starting points for the named blocks, NOT confirmed specifications
// of those blocks.  Every module here is linted (Verilator -Wall, Icarus) and
// synthesised for FPGA by scripts/ (see reports/).
//
//   sf_sram_ex_cpu_dcache_data    32 x 1024   (4 KiB)   1-cycle read, posted writes
//   sf_sram_ex_tensor_operand_buf 64 x 2048   (16 KiB)  1-cycle read, write ack
//   sf_sram_ex_vector_spm_bank    64 x 4096   (32 KiB)  2-cycle read (BRAM output register)
//   sf_sram_ex_controlcore_lmem   32 x 2048   (8 KiB)   boot image from a hex file (FPGA/sim)
//   sf_sram_ex_parity_lane_buf    72 x 1024   9-bit lanes (8 x {parity, byte}) for parity/ECC-in-lane
//   sf_sram_ex_nibble_tag         28 x 600    4-bit lanes, non-power-of-two depth, invalid addresses flagged
//   sf_sram_ex_asic_style         64 x 1024   INIT_MODE=NONE, 2-cycle read: the ASIC-macro-compatible shape
// =============================================================================
`include "sf_sram_defs.svh"
`default_nettype none

module sf_sram_ex_cpu_dcache_data (
  input  wire logic        clk, rst_n, ce, we,
  input  wire logic [9:0]  addr,
  input  wire logic [3:0]  wmask,
  input  wire logic [31:0] wdata,
  output logic      [31:0] rdata,
  output logic             rd_valid, rd_err, wr_ack, wr_err
);
  sf_sram_core #(.DATA_WIDTH(32), .DEPTH_WORDS(1024), .READ_LATENCY(1), .WRITE_ACK(0)) u (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
endmodule

module sf_sram_ex_tensor_operand_buf (
  input  wire logic        clk, rst_n, ce, we,
  input  wire logic [10:0] addr,
  input  wire logic [7:0]  wmask,
  input  wire logic [63:0] wdata,
  output logic      [63:0] rdata,
  output logic             rd_valid, rd_err, wr_ack, wr_err
);
  sf_sram_core #(.DATA_WIDTH(64), .DEPTH_WORDS(2048), .READ_LATENCY(1), .WRITE_ACK(1)) u (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
endmodule

module sf_sram_ex_vector_spm_bank (
  input  wire logic        clk, rst_n, ce, we,
  input  wire logic [11:0] addr,
  input  wire logic [7:0]  wmask,
  input  wire logic [63:0] wdata,
  output logic      [63:0] rdata,
  output logic             rd_valid, rd_err, wr_ack, wr_err
);
  sf_sram_core #(.DATA_WIDTH(64), .DEPTH_WORDS(4096), .READ_LATENCY(2), .WRITE_ACK(0)) u (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
endmodule

module sf_sram_ex_controlcore_lmem #(
  parameter INIT_FILE = "firmware.hex"
) (
  input  wire logic        clk, rst_n, ce, we,
  input  wire logic [10:0] addr,
  input  wire logic [3:0]  wmask,
  input  wire logic [31:0] wdata,
  output logic      [31:0] rdata,
  output logic             rd_valid, rd_err, wr_ack, wr_err
);
  // INIT_MODE=FILE is an FPGA/simulation feature: ASIC SRAM has no defined power-up content,
  // so a boot image there must come from a ROM or be written by a loader after reset.
  sf_sram_core #(.DATA_WIDTH(32), .DEPTH_WORDS(2048), .READ_LATENCY(1), .WRITE_ACK(1),
                 .INIT_MODE(`SF_SRAM_INIT_FILE), .INIT_FILE(INIT_FILE)) u (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
endmodule

module sf_sram_ex_parity_lane_buf (
  input  wire logic        clk, rst_n, ce, we,
  input  wire logic [9:0]  addr,
  input  wire logic [7:0]  wmask,          // one enable per 9-bit lane
  input  wire logic [71:0] wdata,
  output logic      [71:0] rdata,
  output logic             rd_valid, rd_err, wr_ack, wr_err
);
  sf_sram_core #(.DATA_WIDTH(72), .DEPTH_WORDS(1024), .BYTE_WIDTH(9), .READ_LATENCY(1), .WRITE_ACK(1)) u (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
endmodule

module sf_sram_ex_nibble_tag (
  input  wire logic        clk, rst_n, ce, we,
  input  wire logic [9:0]  addr,           // 600 words on a 10-bit port: addresses 600..1023 are invalid
  input  wire logic [6:0]  wmask,          // seven 4-bit lanes
  input  wire logic [27:0] wdata,
  output logic      [27:0] rdata,
  output logic             rd_valid, rd_err, wr_ack, wr_err
);
  sf_sram_core #(.DATA_WIDTH(28), .DEPTH_WORDS(600), .BYTE_WIDTH(4), .READ_LATENCY(1), .WRITE_ACK(1)) u (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
endmodule

module sf_sram_ex_asic_style (
  input  wire logic        clk, rst_n, ce, we,
  input  wire logic [9:0]  addr,
  input  wire logic [7:0]  wmask,
  input  wire logic [63:0] wdata,
  output logic      [63:0] rdata,
  output logic             rd_valid, rd_err, wr_ack, wr_err
);
  // INIT_MODE=NONE (the default) is the only mode that matches an ASIC SRAM macro.
  sf_sram_core #(.DATA_WIDTH(64), .DEPTH_WORDS(1024), .READ_LATENCY(2), .WRITE_ACK(1), .INIT_MODE(`SF_SRAM_INIT_NONE)) u (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
endmodule

`default_nettype wire
