// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: tb_sf_sram_if        (self-checking)
// Same checking body as tb_sf_sram_core, but the DUT is reached through the
// sf_sram_if bundle and sf_sram_core_if.  The interface's own protocol checker
// (rd_valid / wr_ack timing, no X on controls) runs alongside the scoreboard.
// Runs under Verilator only: Icarus 12 has no interface support.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_sram_if;
  parameter int DW    = 32;
  parameter int DEPTH = 1024;
  parameter int AW    = $clog2(DEPTH);
  parameter int BW    = 8;
  parameter int LAT   = 1;
  parameter int WACK  = 1;
  parameter int INITM = 0;
  parameter     INITF = "";
  parameter int NRAND = 20000;
  localparam int LANES = DW / BW;
  localparam string TBNAME = "tb_sf_sram_if";

  logic                clk   = 1'b0;
  logic                rst_n = 1'b1;
  logic                ce    = 1'b0, we = 1'b0;
  logic [AW-1:0]       addr  = '0;
  logic [LANES-1:0]    wmask = '0;
  logic [DW-1:0]       wdata = '0;
  logic [DW-1:0]       rdata;
  logic                rd_valid, rd_err, wr_ack, wr_err;

  sf_sram_if #(.DATA_WIDTH(DW), .ADDR_WIDTH(AW), .BYTE_WIDTH(BW), .READ_LATENCY(LAT), .WRITE_ACK(WACK)) bus (.clk, .rst_n);

  sf_sram_core_if #(.DEPTH_WORDS(DEPTH), .INIT_MODE(INITM), .INIT_FILE(INITF), .OOB_ASSERT(0)) dut (.bus(bus.slave));

  // drive the request half of the bundle, observe the response half
  assign bus.ce    = ce;
  assign bus.we    = we;
  assign bus.addr  = addr;
  assign bus.wmask = wmask;
  assign bus.wdata = wdata;
  assign rdata     = bus.rdata;
  assign rd_valid  = bus.rd_valid;
  assign rd_err    = bus.rd_err;
  assign wr_ack    = bus.wr_ack;
  assign wr_err    = bus.wr_err;

  `include "sf_tb_body.svh"
endmodule

`default_nettype wire
