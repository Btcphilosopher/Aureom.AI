// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: sf_tb_body.svh        (testbench only)
// Shared self-checking body, included INSIDE a testbench module that provides
//   parameters : DW DEPTH AW BW LAT WACK INITM INITF NRAND
//   localparam : LANES = DW / BW
//   signals    : clk rst_n (initial 1)  ce we addr[AW] wmask[LANES] wdata[DW]
//                rdata rd_valid rd_err wr_ack wr_err      (DUT ports)
// and instantiates the DUT before the include.  The including module may be
// the plain flat-port testbench or the SV-interface one, so both exercise the
// identical checks.
//
// Verification structure
//   * Independent reference model: bit-granular value/known arrays updated with
//     bit loops (the RTL uses lane part-selects).  "known" tracks which bits
//     have a defined expected value: unwritten SRAM is NOT assumed to be zero
//     (INIT_MODE=NONE); only INIT_MODE ZERO/FILE/PATTERN define initial content.
//   * Cycle-exact scoreboard: at every negedge the DUT outputs are compared
//     with the expectation derived from the request accepted READ_LATENCY (read)
//     or 1 (write) cycles earlier.  rd_valid / rd_err / wr_ack / wr_err are
//     checked EVERY cycle, so spurious or missing responses and any latency
//     error fail; read data is checked on all known bits.
//   * Directed phases + constrained-random traffic with random gaps, resets
//     and invalid addresses; final full-array comparison; coverage counters
//     that must be non-zero.
// Plusargs: +seed=<n>  +nrand=<n>
// Result line (same format as the SRAM Wrapper Library regression):
//   SRAM_RESULT <PASS|FAIL> tb=<name> seed=<n> checks=<n> errors=<n>
// =============================================================================
localparam int  AWI   = $clog2(DEPTH);
localparam int  NADDR = 1 << AW;
localparam int  NOOB  = NADDR - DEPTH;           // number of invalid addresses
localparam int  NCH   = (DW + 31) / 32;

`include "tb_common.svh"

always #5 clk = ~clk;
initial #1 rst_n = 1'b0;                          // a real falling edge for the asynchronous reset

// ------------------------------------------------------------------ helpers
// deterministic data word for (address, salt): lane-diverse, never trivially 0/1
function automatic logic [DW-1:0] hw(input int unsigned a, input int unsigned s);
  logic [NCH*32-1:0] w;
  logic [31:0]       h;
  for (int k = 0; k < NCH; k++) begin
    h = 32'(a) * 32'h9E3779B1 + 32'(s) * 32'h7F4A7C15 + 32'(k) * 32'h85EBCA6B + 32'h01234567;
    h = h ^ (h >> 16);
    h = h * 32'h7FEB352D;
    h = h ^ (h >> 15);
    h = h * 32'h846CA68B;
    h = h ^ (h >> 16);
    w[k*32 +: 32] = h;
  end
  hw = w[DW-1:0];
endfunction

function automatic logic [DW-1:0] rv();
  logic [1023:0] t;
  t  = rnd_vec();
  rv = t[DW-1:0];
endfunction

function automatic logic [LANES-1:0] rmask();
  logic [1023:0] t;
  int r;
  r = rnd_below(100);
  t = rnd_vec();
  if (r < 40)      rmask = '1;
  else if (r < 55) rmask = '0;
  else             rmask = t[LANES-1:0];
endfunction

function automatic logic [AW-1:0] raddr_any();    // any representable address (valid or not)
  logic [31:0] t;
  t = rnd32();
  raddr_any = t[AW-1:0];
endfunction

function automatic int raddr_valid();             // any valid address
  raddr_valid = rnd_below(DEPTH);
endfunction

function automatic logic [DW-1:0] lane_merge(input logic [DW-1:0] old_w, input logic [DW-1:0] new_w,
                                              input logic [LANES-1:0] m);
  logic [DW-1:0] r;
  r = old_w;
  for (int l = 0; l < LANES; l++)
    for (int b = 0; b < BW; b++)
      if (m[l]) r[l*BW + b] = new_w[l*BW + b];
  lane_merge = r;
endfunction

// expected INIT_MODE=PATTERN content (re-implementation of the RTL formula,
// documented in sf_sram_array.sv)
function automatic logic [DW-1:0] pat_word(input int unsigned i);
  logic [NCH*32-1:0] w;
  logic [31:0]       h;
  for (int k = 0; k < NCH; k++) begin
    h = (32'(i) * 32'h9E3779B1) ^ (32'(k + 1) * 32'h85EBCA6B) ^ 32'hC2B2AE35;
    h = h ^ (h >> 15);
    h = h * 32'h2C1B3C6D;
    h = h ^ (h >> 12);
    w[k*32 +: 32] = h;
  end
  pat_word = w[DW-1:0];
endfunction

// ------------------------------------------------------------ reference model
logic [DW-1:0] rm_val  [DEPTH];
logic [DW-1:0] rm_knw  [DEPTH];

task automatic rm_write(input int a, input logic [DW-1:0] d, input logic [LANES-1:0] m);
  for (int l = 0; l < LANES; l++)
    if (m[l])
      for (int b = 0; b < BW; b++) begin
        rm_val[a][l*BW + b] = d[l*BW + b];
        rm_knw[a][l*BW + b] = 1'b1;
      end
endtask

task automatic rm_init();
  if (INITM == 2) $readmemh(INITF, rm_val);
  for (int i = 0; i < DEPTH; i++) begin
    case (INITM)
      0: begin rm_val[i] = '0;           rm_knw[i] = '0; end   // NONE: undefined
      1: begin rm_val[i] = '0;           rm_knw[i] = '1; end   // ZERO
      2: begin                           rm_knw[i] = '1; end   // FILE (rm_val read above)
      3: begin rm_val[i] = pat_word(i);  rm_knw[i] = '1; end   // PATTERN
      default: begin rm_val[i] = '0;     rm_knw[i] = '0; end
    endcase
  end
endtask

// ------------------------------------------------------------ statistics
int n_rd = 0, n_wr = 0, n_wr_full = 0, n_wr_part = 0, n_wr_zero = 0, n_idle = 0;
int n_oob_rd = 0, n_oob_wr = 0, n_raw = 0, n_b2b_rd = 0, n_b2b_wr = 0, n_alt = 0;
int n_flush = 0, n_reset_acc = 0, n_ack = 0, n_resets = 0;
int meas_lat = 0;
int prev_op = 0;               // 0 idle, 1 read, 2 write (previous sampled cycle)
int prev_addr = -1;

// ------------------------------------------------------------ scoreboard
localparam int RING = LAT + 3;
bit            x_rv  [RING];
bit            x_re  [RING];
bit            x_wa  [RING];
bit            x_we  [RING];
logic [DW-1:0] x_dat [RING];
logic [DW-1:0] x_knw [RING];
int            ncyc   = 0;
bit            mon_en = 0;

task automatic ring_clear(input int s);
  x_rv[s] = 0; x_re[s] = 0; x_wa[s] = 0; x_we[s] = 0; x_dat[s] = '0; x_knw[s] = '0;
endtask

task automatic chk1(input logic got, input bit exp_b, input string what);
  if (got !== exp_b) tb_check(0, $sformatf("%s got=%b exp=%b (cycle %0d)", what, got, exp_b, ncyc));
  else               tb_checks++;
endtask

always @(negedge clk) begin : mon
  int slot, ws, rs, a;
  bit any_pending;
  if (mon_en) begin
    slot = ncyc % RING;
    // ---- 1. compare outputs with the expectation scheduled for this cycle
    if (!rst_n) begin
      any_pending = 0;
      for (int s = 0; s < RING; s++) if (x_rv[s] || x_wa[s] || x_we[s]) any_pending = 1;
      if (any_pending) n_flush++;
      chk1(rd_valid, 1'b0, "rd_valid during reset");
      chk1(rd_err,   1'b0, "rd_err during reset");
      chk1(wr_ack,   1'b0, "wr_ack during reset");
      chk1(wr_err,   1'b0, "wr_err during reset");
      for (int s = 0; s < RING; s++) ring_clear(s);
    end else begin
      chk1(rd_valid, x_rv[slot],                 "rd_valid");
      chk1(rd_err,   x_re[slot],                 "rd_err");
      chk1(wr_ack,   x_wa[slot] && (WACK != 0),  "wr_ack");
      chk1(wr_err,   x_we[slot],                 "wr_err");
      if (x_wa[slot] && WACK != 0) n_ack++;
      if (x_rv[slot] && !x_re[slot]) begin
        if (((rdata ^ x_dat[slot]) & x_knw[slot]) !== '0)
          tb_check(0, $sformatf("rdata got=%h exp=%h known=%h (cycle %0d)", rdata, x_dat[slot], x_knw[slot], ncyc));
        else tb_checks++;
`ifdef __ICARUS__
`ifndef SF_GLS
        // 4-state simulator: bits never written under INIT_MODE=NONE must still be X,
        // i.e. the model must not silently supply zeros ("unwritten SRAM is not zero").
        if (INITM == 0)
          for (int b = 0; b < DW; b++)
            if (!x_knw[slot][b]) begin
              if (rdata[b] !== 1'bx) tb_check(0, $sformatf("unwritten bit %0d of read data is not X (got %b), cycle %0d", b, rdata[b], ncyc));
              else tb_checks++;
            end
`endif
`endif
      end
      if (x_rv[slot] && x_re[slot]) begin
        if (rdata !== '0) tb_check(0, $sformatf("rdata on invalid read not zero: %h (cycle %0d)", rdata, ncyc));
        else tb_checks++;
      end
`ifdef __ICARUS__
`ifdef SF_SRAM_POISON
`ifndef SF_GLS
      if (!x_rv[slot]) begin
        if (rdata !== {DW{1'bx}}) tb_check(0, $sformatf("rdata is not poisoned (X) while rd_valid=0: %h (cycle %0d)", rdata, ncyc));
        else tb_checks++;
      end
`endif
`endif
`endif
    end
    ring_clear(slot);

    // ---- 2. sample the request that the next rising edge will accept
    if (!rst_n) begin
      if (ce === 1'b1) n_reset_acc++;
      prev_op = 0; prev_addr = -1;
    end else if (ce === 1'b1) begin
      a  = int'(addr);
      ws = (ncyc + 1)   % RING;
      rs = (ncyc + LAT) % RING;
      if (we) begin
        n_wr++;
        if (prev_op == 2) n_b2b_wr++;
        if (prev_op == 1) n_alt++;
        if (a < DEPTH) begin
          if (wmask === '1)      n_wr_full++;
          else if (wmask === '0) n_wr_zero++;
          else                   n_wr_part++;
          rm_write(a, wdata, wmask);
          x_wa[ws] = 1;
        end else begin
          n_oob_wr++;
          x_wa[ws] = 1;
          x_we[ws] = 1;
        end
        prev_op = 2; prev_addr = a;
      end else begin
        n_rd++;
        if (prev_op == 1) n_b2b_rd++;
        if (prev_op == 2) begin n_alt++; if (prev_addr == a) n_raw++; end
        x_rv[rs] = 1;
        if (a < DEPTH) begin
          x_dat[rs] = rm_val[a];
          x_knw[rs] = rm_knw[a];
        end else begin
          n_oob_rd++;
          x_re[rs] = 1;
        end
        prev_op = 1; prev_addr = a;
      end
    end else begin
      n_idle++;
      prev_op = 0; prev_addr = -1;
    end
    ncyc++;
  end
end

// ------------------------------------------------------------ drivers
// One call = one clock cycle.  Inputs change 1 ns after the rising edge and are
// therefore stable for the next edge and for the negedge sampler.
task automatic cyc(input bit c, input bit w, input logic [AW-1:0] a,
                   input logic [LANES-1:0] m, input logic [DW-1:0] d);
  @(posedge clk); #1;
  ce = c; we = w; addr = a; wmask = m; wdata = d;
endtask

task automatic wr(input int a, input logic [LANES-1:0] m, input logic [DW-1:0] d);
  cyc(1'b1, 1'b1, AW'(a), m, d);
endtask

// NOTE: SystemVerilog leaves the evaluation order of call arguments undefined, so
// every PRNG-consuming call is sequenced explicitly: a seed must produce the same
// stimulus in every simulator.
task automatic rd(input int a);                    // junk on the write-only inputs
  logic [LANES-1:0] m;
  logic [DW-1:0]    d;
  m = rmask();  d = rv();
  cyc(1'b1, 1'b0, AW'(a), m, d);
endtask

task automatic wr_rand(input int a);               // random byte mask, random data
  logic [LANES-1:0] m;
  logic [DW-1:0]    d;
  m = rmask();  d = rv();
  wr(a, m, d);
endtask

task automatic wr_any_rand(input logic [AW-1:0] a);
  logic [LANES-1:0] m;
  logic [DW-1:0]    d;
  m = rmask();  d = rv();
  cyc(1'b1, 1'b1, a, m, d);
endtask

task automatic wr_any(input logic [AW-1:0] a, input logic [LANES-1:0] m, input logic [DW-1:0] d);
  cyc(1'b1, 1'b1, a, m, d);
endtask

task automatic rd_any(input logic [AW-1:0] a);
  logic [LANES-1:0] m;
  logic [DW-1:0]    d;
  m = rmask();  d = rv();
  cyc(1'b1, 1'b0, a, m, d);
endtask

task automatic idle();                             // ce=0 with noise on everything else
  bit               w;
  logic [AW-1:0]    a;
  logic [LANES-1:0] m;
  logic [DW-1:0]    d;
  w = rnd_pct(50);  a = raddr_any();  m = rmask();  d = rv();
  cyc(1'b0, w, a, m, d);
endtask

task automatic dis_wr(input int a);                // ce=0 with we=1 and a live-looking write
  logic [LANES-1:0] m;
  logic [DW-1:0]    d;
  m = rmask();  d = rv();
  cyc(1'b0, 1'b1, AW'(a), m, d);
endtask

task automatic idle_n(input int n);
  for (int i = 0; i < n; i++) idle();
endtask

// read, wait for the response and hand it back; also measures the latency
task automatic rd_wait(input int a, output logic [DW-1:0] d, output bit er);
  int k;
  rd(a);
  idle();                                          // the read is accepted at the edge before this returns
  d = '0; er = 1'b0; k = 1;
  @(negedge clk);
  while (rd_valid !== 1'b1 && k < LAT + 4) begin @(negedge clk); k++; end
  if (rd_valid === 1'b1) begin d = rdata; er = rd_err; meas_lat = k; end
  else tb_check(0, $sformatf("rd_wait: no rd_valid for read of %0d", a));
endtask

// synchronous reset pulse of n cycles; optional noise on the control inputs
task automatic do_reset(input int n, input bit noise);
  @(posedge clk); #1;
  rst_n = 1'b0;
  n_resets++;
  for (int i = 0; i < n; i++) begin
    if (noise) begin ce = 1'b1; we = rnd_pct(60); addr = raddr_any(); wmask = rmask(); wdata = rv(); end
    @(posedge clk); #1;
  end
  rst_n = 1'b1;
  ce = 1'b0; we = 1'b0;
endtask

// ------------------------------------------------------------ phases
task automatic p_init_sweep();         // read every word before anything was written
  for (int a = 0; a < DEPTH; a++) rd(a);
  idle_n(LAT + 2);
endtask

task automatic p_reset();
  logic [DW-1:0] d, g;
  bit e;
  int a;
  a = DEPTH / 2;
  // an access presented while rst_n=0 must be ignored (no write)
  wr(a, '1, hw(a, 11));
  idle_n(2);
  do_reset(2, 1'b0);
  idle_n(1);
  rd_wait(a, g, e);
  tb_check(g === hw(a, 11) && !e, "reset: stored word lost or changed by reset");
  // write presented during reset must not modify the array
  @(posedge clk); #1;
  rst_n = 1'b0; ce = 1'b1; we = 1'b1; addr = AW'(a); wmask = '1; wdata = hw(a, 12);
  @(posedge clk); #1;
  @(posedge clk); #1;
  rst_n = 1'b1; ce = 1'b0;
  idle_n(1);
  rd_wait(a, g, e);
  tb_check(g === hw(a, 11) && !e, "reset: write presented while rst_n=0 modified the array");
  // in-flight responses are dropped by reset
  for (int k = 0; k < LAT + 1; k++) begin
    wr(a, '1, hw(a, 20 + k));
    rd(a);
    do_reset(1, 1'b0);
  end
  // reset with traffic noise
  do_reset(3, 1'b1);
  idle_n(2);
  tb_check(n_flush > 0, "coverage: reset never dropped an in-flight response");
endtask

task automatic p_first_last();
  logic [DW-1:0] g;
  bit e;
  wr(0,         '1, hw(0, 31));
  wr(DEPTH - 1, '1, hw(DEPTH - 1, 32));
  if (DEPTH >= 4) begin                            // words 1 and DEPTH-2 are distinct from 0 and DEPTH-1
    wr(1,         '1, hw(1, 33));
    wr(DEPTH - 2, '1, hw(DEPTH - 2, 34));
  end
  idle();
  rd_wait(0, g, e);          tb_check(g === hw(0, 31) && !e,               "first word");
  rd_wait(DEPTH - 1, g, e);  tb_check(g === hw(DEPTH - 1, 32) && !e,       "last word");
  if (DEPTH >= 4) begin
    rd_wait(1, g, e);          tb_check(g === hw(1, 33) && !e,               "word 1");
    rd_wait(DEPTH - 2, g, e);  tb_check(g === hw(DEPTH - 2, 34) && !e,       "word DEPTH-2");
  end
endtask

task automatic p_every_address();
  // pass 1: unique full-word data, ascending, back-to-back writes then back-to-back reads
  for (int a = 0; a < DEPTH; a++) wr(a, '1, hw(a, 1));
  for (int a = 0; a < DEPTH; a++) rd(a);
  // pass 2: complemented data, descending, random byte masks (partial writes)
  for (int a = DEPTH - 1; a >= 0; a--) wr(a, rmask(), ~hw(a, 1));
  for (int a = 0; a < DEPTH; a++) rd(a);
  // pass 3: every address individually (idle between) so each read is isolated
  for (int a = 0; a < DEPTH; a++) begin wr(a, '1, hw(a, 3)); idle(); rd(a); idle(); end
  idle_n(LAT + 2);
endtask

task automatic p_byte_enables();
  logic [DW-1:0] bg, d, e_w, g, lm, nb;
  logic [LANES-1:0] m;
  bit er;
  int a;
  a = DEPTH / 2;
  // --- one byte at a time (direct expectation, independent of the reference model)
  for (int l = 0; l < LANES; l++) begin
    bg = hw(a, 100 + l);  d = hw(a, 200 + l);
    wr(a, '1, bg);
    m = '0; m[l] = 1'b1;
    wr(a, m, d);
    rd_wait(a, g, er);
    lm = '0; for (int b = 0; b < BW; b++) lm[l*BW + b] = 1'b1;
    e_w = (bg & ~lm) | (d & lm);
    tb_check(g === e_w && !er, $sformatf("single-byte write lane %0d: got %h exp %h", l, g, e_w));
  end
  // --- multiple bytes: exhaustive for <= 8 lanes, else walking patterns + random
  if (LANES <= 8) begin
    for (int mi = 0; mi < (1 << LANES); mi++) begin
      bg = hw(a, 300 + mi);  d = hw(a, 400 + mi);
      m = LANES'(mi);
      wr(a, '1, bg);
      wr(a, m, d);
      rd_wait(a, g, er);
      lm = '0;
      for (int l = 0; l < LANES; l++) if (m[l]) for (int b = 0; b < BW; b++) lm[l*BW + b] = 1'b1;
      e_w = (bg & ~lm) | (d & lm);
      tb_check(g === e_w && !er, $sformatf("byte mask %b: got %h exp %h", m, g, e_w));
    end
  end else begin
    for (int mi = 0; mi < 2 * LANES + 512; mi++) begin
      bg = hw(a, 300 + mi);  d = hw(a, 400 + mi);
      if (mi < LANES)            begin m = '0; m[mi] = 1'b1; end          // walking one
      else if (mi < 2 * LANES)   begin m = '1; m[mi - LANES] = 1'b0; end  // walking zero
      else                       m = rmask();
      wr(a, '1, bg);
      wr(a, m, d);
      rd_wait(a, g, er);
      lm = '0;
      for (int l = 0; l < LANES; l++) if (m[l]) for (int b = 0; b < BW; b++) lm[l*BW + b] = 1'b1;
      e_w = (bg & ~lm) | (d & lm);
      tb_check(g === e_w && !er, $sformatf("byte mask %b: got %h exp %h", m, g, e_w));
    end
  end
  // --- full-word write
  wr(a, '1, hw(a, 500));
  rd_wait(a, g, er);
  tb_check(g === hw(a, 500) && !er, "full-word write");
  // --- zero write strobes: legal write, changes nothing
  bg = hw(a, 600);  d = hw(a, 601);
  wr(a, '1, bg);
  wr(a, '0, d);
  rd_wait(a, g, er);
  tb_check(g === bg && !er, "zero strobes changed the word");
  // --- untouched bytes survive and neighbours are not disturbed
  begin
    logic [DW-1:0] nb_lo, nb_hi;
    nb_lo = hw(a - 1, 700);  nb_hi = hw(a + 1, 701);
    if (a >= 1)         wr(a - 1, '1, nb_lo);
    if (a + 1 < DEPTH)  wr(a + 1, '1, nb_hi);
    m = '0; m[0] = 1'b1;
    wr(a, m, hw(a, 702));
    if (a >= 1)        begin rd_wait(a - 1, g, er);  tb_check(g === nb_lo && !er, "neighbour a-1 disturbed by partial write"); end
    if (a + 1 < DEPTH) begin rd_wait(a + 1, g, er);  tb_check(g === nb_hi && !er, "neighbour a+1 disturbed by partial write"); end
  end
  // --- every lane written separately at consecutive cycles builds a full word
  bg = hw(a, 800);
  for (int l = 0; l < LANES; l++) begin
    m = '0; m[l] = 1'b1;
    wr(a, m, bg);
  end
  rd_wait(a, g, er);
  tb_check(g === bg && !er, "lane-by-lane back-to-back writes do not assemble the full word");
endtask

task automatic p_repeated();
  logic [DW-1:0] g, last;
  bit er;
  int a;
  a = (DEPTH > 3) ? 3 : DEPTH - 1;
  for (int i = 0; i < 24; i++) begin
    last = hw(a, 900 + i);
    wr(a, '1, last);
    rd(a);                                   // read-after-write in the very next cycle
  end
  idle_n(LAT + 1);
  rd_wait(a, g, er);
  tb_check(g === last && !er, "repeated writes: last writer must win");
  // write-write-write then read, no gaps, different masks
  wr(a, '1, hw(a, 950));
  wr(a, 'h5 & {LANES{1'b1}}, hw(a, 951));
  wr(a, 'h2 & {LANES{1'b1}}, hw(a, 952));
  rd(a);
  idle_n(LAT + 1);
endtask

task automatic p_back_to_back();
  int nb, h1, h2;
  nb = (DEPTH < 64) ? DEPTH : 64;
  h1 = 7 % DEPTH;  h2 = 8 % DEPTH;
  // consecutive writes, consecutive reads, strict alternation, RAW on the same word
  for (int a = 0; a < nb; a++) wr(a, '1, hw(a, 40));
  for (int a = 0; a < nb; a++) rd(a);
  for (int a = 0; a < nb; a++) begin wr(a, rmask(), hw(a, 41)); rd(a); end         // W,R,W,R ...  (RAW same address)
  for (int a = 0; a < nb; a++) begin rd(a); wr(a, rmask(), hw(a, 42)); end         // R,W,R,W ... (write-after-read)
  for (int i = 0; i < 16; i++) rd(h1);                                             // same-address reads
  for (int i = 0; i < 16; i++) begin wr_rand(h1); rd(h1); wr_rand(h2); rd(h1); end
  idle_n(LAT + 2);
endtask

task automatic p_disabled();
  // ce=0 with we=1/addr/data garbage must not write and must not respond
  int a9;
  a9 = (DEPTH > 9) ? 9 : DEPTH - 1;
  wr(a9, '1, hw(a9, 50));
  for (int i = 0; i < 64; i++) cyc(1'b0, 1'b1, AW'(a9), '1, hw(a9, 51 + i));   // deterministic payload
  rd(a9);
  for (int i = 0; i < 8; i++) begin idle(); idle(); rd(a9); idle(); end
  idle_n(LAT + 2);
endtask

task automatic p_invalid();
  int step;
  if (NOOB > 0) begin
    // distinct data everywhere first, so any aliasing or corruption is visible
    for (int a = 0; a < DEPTH; a++) wr(a, '1, hw(a, 60));
    step = (NOOB > 4096) ? (NOOB / 4096) : 1;
    // boundary: DEPTH-1 is valid, DEPTH is not
    rd(DEPTH - 1);  rd_any(AW'(DEPTH));  rd(DEPTH - 1);
    wr_any_rand(AW'(DEPTH));  rd(DEPTH - 1);  rd(0);
    for (int o = DEPTH; o < NADDR; o += step) begin
      wr_any(AW'(o), '1, hw(o, 61));
      rd_any(AW'(o));
    end
    wr_any_rand(AW'(NADDR - 1));  rd_any(AW'(NADDR - 1));
    // invalid write with zero strobes is still an invalid access
    wr_any(AW'(DEPTH), '0, hw(DEPTH, 62));
    // invalid access directly followed by a valid one, and vice versa
    for (int i = 0; i < 32; i++) begin
      rd_any(AW'(DEPTH + (i % NOOB)));  rd(raddr_valid());
      wr_any_rand(AW'(DEPTH + (i % NOOB)));  rd(raddr_valid());
      rd(raddr_valid());  wr_any_rand(AW'(DEPTH + (i % NOOB)));
    end
    idle_n(LAT + 2);
    // nothing may have changed: no aliasing into valid words
    for (int a = 0; a < DEPTH; a++) rd(a);
    idle_n(LAT + 2);
  end
endtask

task automatic p_random(input int n);
  int r, a, o, hot[16];
  hot[0] = 0; hot[1] = 1; hot[2] = DEPTH - 1; hot[3] = DEPTH - 2; hot[4] = DEPTH / 2;
  for (int i = 5; i < 16; i++) hot[i] = raddr_valid();
  for (int i = 0; i < n; i++) begin
    r = rnd_below(100);
    a = (rnd_below(2) == 0) ? hot[rnd_below(16)] : raddr_valid();
    if (rnd_below(1500) == 0) do_reset(1 + rnd_below(3), 1'b1);
    if (r < 10)                           idle();
    else if (r < 50)                      wr_rand(a);
    else if (r < 92)                      rd(a);
    else if (r < 96 && NOOB > 0)          begin
                                            o = DEPTH + rnd_below(NOOB);
                                            if (rnd_pct(50)) wr_any_rand(AW'(o));
                                            else             rd_any(AW'(o));
                                          end
    else                                  dis_wr(a);                                    // disabled "write"
  end
  idle_n(LAT + 2);
endtask

task automatic p_retention();
  int nb16;
  nb16 = (DEPTH < 16) ? DEPTH : 16;
  // fill with known full words, hammer the controller reset, wait, read everything back
  for (int a = 0; a < DEPTH; a++) wr(a, '1, hw(a, 70));
  idle_n(2);
  do_reset(1, 1'b0);  idle_n(3);
  do_reset(2, 1'b1);  idle_n(1);
  do_reset(5, 1'b1);
  idle_n(300);
  for (int a = 0; a < DEPTH; a++) rd(a);
  idle_n(LAT + 2);
  // reset hits in the middle of a write burst: words written before it survive
  for (int a = 0; a < nb16; a++) wr(a, '1, hw(a, 71));
  do_reset(1, 1'b1);
  idle_n(2);
  for (int a = 0; a < nb16; a++) rd(a);
  idle_n(LAT + 2);
endtask

task automatic p_latency();
  logic [DW-1:0] g;
  bit er;
  int a5;
  a5 = (DEPTH > 5) ? 5 : DEPTH - 1;
  idle_n(4);
  wr(a5, '1, hw(a5, 80));
  idle();                                          // write accepted; ack is visible now
  @(negedge clk);
  tb_check(wr_ack === (WACK != 0), $sformatf("wr_ack one cycle after write: got %b exp %b", wr_ack, WACK != 0));
  rd_wait(a5, g, er);
  tb_check(meas_lat == LAT, $sformatf("measured read latency %0d != READ_LATENCY %0d", meas_lat, LAT));
  tb_check(g === hw(a5, 80) && !er, "latency probe data");
  idle_n(LAT + 2);
endtask

task automatic final_sweep();
  for (int a = 0; a < DEPTH; a++) rd(a);
  idle_n(LAT + 3);
endtask

// ------------------------------------------------------------ main
int cfg_nrand;
initial begin : main
  tb_seed_init();
  if (!$value$plusargs("nrand=%d", cfg_nrand)) cfg_nrand = NRAND;
  $display("SRAM_INFO tb DW=%0d DEPTH=%0d AW=%0d BW=%0d LAT=%0d WACK=%0d INIT=%0d NOOB=%0d nrand=%0d",
           DW, DEPTH, AW, BW, LAT, WACK, INITM, NOOB, cfg_nrand);
  rm_init();
  for (int s = 0; s < RING; s++) ring_clear(s);
  ce = 0; we = 0; addr = '0; wmask = '0; wdata = '0;
  #2 mon_en = 1'b1;                                // armed while the first reset is asserted
  repeat (3) @(posedge clk);
  #1 rst_n = 1'b1;                                 // synchronous release
  idle_n(2);

  p_init_sweep();
  p_reset();
  p_first_last();
  p_every_address();
  p_byte_enables();
  p_repeated();
  p_back_to_back();
  p_disabled();
  p_invalid();
  p_latency();
  p_retention();
  p_random(cfg_nrand);
  final_sweep();
  idle_n(LAT + 4);

  // ---- coverage: every category must have been exercised
  tb_check(n_wr_full > 0 && n_wr_zero > 0,                   "coverage: full and zero-strobe writes");
  tb_check(LANES == 1 || n_wr_part > 0,                      "coverage: partial (multi-lane) writes");
  tb_check(n_rd > 0 && n_idle > 0,                           "coverage: reads and idle cycles");
  tb_check(n_raw > 0 && n_b2b_rd > 0 && n_b2b_wr > 0 && n_alt > 0, "coverage: RAW / back-to-back reads / writes / alternation");
  tb_check(n_reset_acc > 0,                                  "coverage: accesses presented during reset");
  tb_check(NOOB == 0 || (n_oob_rd > 0 && n_oob_wr > 0),      "coverage: invalid reads and writes");
  tb_check(!(WACK != 0) || n_ack > 0,                        "coverage: write acknowledgements");
  $display("SRAM_METRIC reads=%0d writes=%0d (full=%0d partial=%0d zero=%0d) idle=%0d oob_rd=%0d oob_wr=%0d raw=%0d b2b_rd=%0d b2b_wr=%0d alt=%0d resets=%0d flushed=%0d reset_acc=%0d cycles=%0d",
           n_rd, n_wr, n_wr_full, n_wr_part, n_wr_zero, n_idle, n_oob_rd, n_oob_wr, n_raw, n_b2b_rd, n_b2b_wr, n_alt, n_resets, n_flush, n_reset_acc, ncyc);
  tb_finish(TBNAME);
end

// watchdog: a hung testbench must fail, not stall the regression
initial begin : watchdog
  #(64'd10 * 64'(2000000 + 400 * cfg_nrand + 200 * DEPTH + 40 * NOOB));
  $display("SRAM_RESULT FAIL tb=%s seed=%0d checks=%0d errors=%0d  (watchdog)", TBNAME, tb_seed, tb_checks, tb_errors + 1);
  $finish;
end
