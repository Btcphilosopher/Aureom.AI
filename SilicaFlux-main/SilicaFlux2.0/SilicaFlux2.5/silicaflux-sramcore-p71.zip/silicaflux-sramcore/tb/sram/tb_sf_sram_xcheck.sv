// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: tb_sf_sram_xcheck       (self-checking)
// Reuse check against the VERIFIED SilicaFlux SRAM Wrapper Library (Project 01,
// vendored unmodified under third_party/): the same random traffic is applied to
//   A  sf_sram_core            (this project)
//   B  sram_generic_1rw        (library GENERIC backend, behavioural array)
//   C  sram_fpga_1rw           (library FPGA backend, inference template)
// All three must return identical read data at identical cycles.  The library
// backends have no valid flag, so B/C data is aligned by READ_LATENCY and
// compared whenever A raises rd_valid; A's rd_valid must itself equal "a read
// was issued READ_LATENCY cycles ago" (no spurious or missing responses).
// Only valid addresses are used (the raw library backends define no bounds
// behaviour).  Every word is written before the first read, so no comparison
// depends on power-up content.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_sram_xcheck;
  parameter int DW  = 32;
  parameter int LAT = 1;
  localparam int DEPTH = 1024, AW = 10, BW = 8, LANES = DW / BW;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;

  logic                ce = 0, we = 0;
  logic [AW-1:0]       addr = '0;
  logic [LANES-1:0]    wmask = '0;
  logic [DW-1:0]       wdata = '0;
  logic [DW-1:0]       a_rdata, b_rdata, c_rdata;
  logic                a_rv, a_re, a_wa, a_we;

  sf_sram_core #(.DATA_WIDTH(DW), .DEPTH_WORDS(DEPTH), .READ_LATENCY(LAT), .OOB_ASSERT(1)) u_a (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata(a_rdata), .rd_valid(a_rv), .rd_err(a_re),
    .wr_ack(a_wa), .wr_err(a_we));

  sram_generic_1rw #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(LANES), .READ_LATENCY(LAT)) u_b (
    .clk, .ce, .we, .wmask, .addr, .wdata, .rdata(b_rdata));

  sram_fpga_1rw #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(LANES), .READ_LATENCY(LAT)) u_c (
    .clk, .ce, .we, .wmask, .addr, .wdata, .rdata(c_rdata));

  // ------------------------------------------------------------ comparator
  logic [LAT-1:0] rd_issue_sh = '0;      // read presented, shifted by READ_LATENCY
  int             n_cmp = 0;
  bit             armed = 0;

  always @(posedge clk) begin
    rd_issue_sh[0] <= (rst_n && ce === 1'b1 && we === 1'b0);
    for (int k = 1; k < LAT; k++) rd_issue_sh[k] <= rd_issue_sh[k-1];
  end

  always @(negedge clk) begin
    if (armed) begin
      tb_check(a_rv === rd_issue_sh[LAT-1], $sformatf("A rd_valid=%b expected %b", a_rv, rd_issue_sh[LAT-1]));
      tb_check(a_re === 1'b0 && a_we === 1'b0, "A reported an error on a valid address");
      if (rd_issue_sh[LAT-1]) begin
        n_cmp++;
        tb_check(a_rdata === b_rdata, $sformatf("A vs library GENERIC: %h vs %h (read %0d)", a_rdata, b_rdata, n_cmp));
        tb_check(a_rdata === c_rdata, $sformatf("A vs library FPGA:    %h vs %h (read %0d)", a_rdata, c_rdata, n_cmp));
      end
    end
  end

  // ------------------------------------------------------------ stimulus
  task automatic cyc(input bit c, input bit w, input logic [AW-1:0] a, input logic [LANES-1:0] m, input logic [DW-1:0] d);
    @(posedge clk); #1;
    ce = c; we = w; addr = a; wmask = m; wdata = d;
  endtask

  function automatic logic [DW-1:0] rvec();
    logic [1023:0] t;
    t = rnd_vec();
    rvec = t[DW-1:0];
  endfunction

  initial begin : main
    logic [LANES-1:0] m;
    logic [DW-1:0]    d;
    logic [AW-1:0]    a;
    int               r;
    tb_seed_init();
    $display("SRAM_INFO xcheck DW=%0d LAT=%0d", DW, LAT);
    repeat (3) @(posedge clk);
    #1 rst_n = 1'b1;
    armed = 1'b1;
    // fill: every word is fully defined in all three memories
    for (int i = 0; i < DEPTH; i++) begin d = rvec(); cyc(1, 1, AW'(i), '1, d); end
    // random traffic, valid addresses only
    for (int i = 0; i < 60000; i++) begin
      r = rnd_below(100);
      m = rvec();
      d = rvec();
      a = AW'(rnd_below(2) == 0 ? rnd_below(8) : rnd_below(DEPTH));
      if (r < 12)      cyc(0, rnd_pct(50), a, m, d);                       // disabled
      else if (r < 50) cyc(1, 1, a, (rnd_below(4) == 0) ? '1 : m, d);      // write
      else             cyc(1, 0, a, m, d);                                 // read
    end
    cyc(0, 0, '0, '0, '0);
    repeat (LAT + 3) cyc(0, 0, '0, '0, '0);
    tb_check(n_cmp > 15000, $sformatf("too few comparisons: %0d", n_cmp));
    $display("SRAM_METRIC comparisons=%0d", n_cmp);
    tb_finish("tb_sf_sram_xcheck");
  end
endmodule

`default_nettype wire
