// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: tb_sf_sram_assert        (self-checking)
// The simulation assertions of sf_sram_core must fire exactly where intended:
//   SF_SRAM_ASSERT_OOB  once per access to an invalid address (OOB_ASSERT=1)
//   SF_SRAM_ASSERT_X    once per X/Z control violation (4-state simulator only)
//   SF_SRAM_ASSERT_INT  never
// The testbench prints "SRAM_EXPECT <kind>=<count>"; scripts/run_regress.py
// counts the assertion messages in the log and compares.  It also checks that
// the hardware error flags (rd_err / wr_err) fire independently of the
// assertion policy.  DEPTH_WORDS=1000 on a 10-bit port: addresses 1000..1023
// are invalid.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_sram_assert;
  localparam int DW = 32, DEPTH = 1000, AW = 10, LANES = 4;

  `include "tb_common.svh"

  logic clk = 1'b0, rst_n = 1'b1;
  always #5 clk = ~clk;
  initial #1 rst_n = 1'b0;

  logic             ce = 0, we = 0;
  logic [AW-1:0]    addr = '0;
  logic [LANES-1:0] wmask = '0;
  logic [DW-1:0]    wdata = '0;
  logic [DW-1:0]    rdata;
  logic             rd_valid, rd_err, wr_ack, wr_err;

  sf_sram_core #(.DATA_WIDTH(DW), .DEPTH_WORDS(DEPTH), .ADDR_WIDTH(AW), .OOB_ASSERT(1)) dut (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);

  int n_rd_err = 0, n_wr_err = 0, n_rd_ok = 0;
  bit count_en = 0;
  always @(negedge clk) if (count_en) begin
    if (rd_valid && rd_err) n_rd_err++;
    if (rd_valid && !rd_err) n_rd_ok++;
    if (wr_err) n_wr_err++;
  end

  task automatic cyc(input logic c, input logic w, input logic [AW-1:0] a, input logic [LANES-1:0] m, input logic [DW-1:0] d);
    @(posedge clk); #1;
    ce = c; we = w; addr = a; wmask = m; wdata = d;
  endtask

  initial begin : main
    tb_seed_init();
    repeat (3) @(posedge clk);
    #1 rst_n = 1'b1;
    cyc(0, 0, '0, '0, '0);
    count_en = 1;
    // five invalid accesses -> five SF_SRAM_ASSERT_OOB, three rd_err, two wr_err
    cyc(1, 0, AW'(1000), '0, '0);              // read  1000 (first invalid)
    cyc(1, 0, AW'(1023), '0, '0);              // read  1023 (last representable)
    cyc(1, 0, AW'(1001), '0, '0);              // read  1001
    cyc(1, 1, AW'(1000), '1, 32'hDEADBEEF);    // write 1000
    cyc(1, 1, AW'(1023), '0, 32'hDEADBEEF);    // write 1023, zero strobes: still an invalid access
    // five valid accesses -> no assertion
    cyc(1, 1, AW'(999), '1, 32'h12345678);     // last valid word
    cyc(1, 0, AW'(999), '0, '0);
    cyc(1, 1, AW'(0),   '1, 32'h0BADF00D);
    cyc(1, 0, AW'(0),   '0, '0);
    cyc(1, 0, AW'(500), '0, '0);
    cyc(0, 0, '0, '0, '0);
    repeat (4) cyc(0, 0, '0, '0, '0);
    tb_check(n_rd_err == 3, $sformatf("rd_err pulses %0d, expected 3", n_rd_err));
    tb_check(n_wr_err == 2, $sformatf("wr_err pulses %0d, expected 2", n_wr_err));
    tb_check(n_rd_ok == 3,  $sformatf("valid reads %0d, expected 3", n_rd_ok));
    $display("SRAM_EXPECT oob=5");
`ifdef __ICARUS__
    // 4-state only: X on the control inputs must be reported (once per violation).
    // wmask=X during a write, then ce=X (we=1 and a valid address keep the response flags clean).
    count_en = 0;
    cyc(1, 1, AW'(3), 4'bxxxx, 32'h1);         // wmask is X/Z during a write
    cyc(1'bx, 1'b1, AW'(3), '1, 32'h2);        // ce is X/Z
    cyc(0, 0, '0, '0, '0);
    repeat (4) cyc(0, 0, '0, '0, '0);
    $display("SRAM_EXPECT x=2");
`else
    $display("SRAM_EXPECT x=0");
`endif
    tb_finish("tb_sf_sram_assert");
  end
endmodule

`default_nettype wire
