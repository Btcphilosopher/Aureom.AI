// =============================================================================
// SilicaFlux SRAMCore (Project 71) :: tb_sf_sram_core            (self-checking)
// Flat-port testbench for sf_sram_core.  All checking lives in sf_tb_body.svh;
// the configuration is chosen with -G / -P parameter overrides (see
// scripts/run_regress.py).  Defaults = the primary configuration:
// 32-bit x 1024 words, one-cycle read latency, byte enables, write ack.
// =============================================================================
`timescale 1ns/1ps
`default_nettype none

module tb_sf_sram_core;
  parameter int DW    = 32;
  parameter int DEPTH = 1024;
  parameter int AW    = $clog2(DEPTH);
  parameter int BW    = 8;
  parameter int LAT   = 1;
  parameter int WACK  = 1;
  parameter int INITM = 0;
  parameter     INITF = "";
  parameter int NRAND = 30000;
  localparam int LANES = DW / BW;
  localparam string TBNAME = "tb_sf_sram_core";

  logic                clk   = 1'b0;
  logic                rst_n = 1'b1;
  logic                ce    = 1'b0, we = 1'b0;
  logic [AW-1:0]       addr  = '0;
  logic [LANES-1:0]    wmask = '0;
  logic [DW-1:0]       wdata = '0;
  logic [DW-1:0]       rdata;
  logic                rd_valid, rd_err, wr_ack, wr_err;

`ifdef SF_NETLIST
  // gate-level: the synthesised netlist (parameters are baked in; scripts/run_gls.py keeps DW/DEPTH/... in sync)
  sf_sram_core dut (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err
  );
`else
  sf_sram_core #(
    .DATA_WIDTH(DW), .DEPTH_WORDS(DEPTH), .ADDR_WIDTH(AW), .BYTE_WIDTH(BW),
    .READ_LATENCY(LAT), .INIT_MODE(INITM), .INIT_FILE(INITF), .WRITE_ACK(WACK), .OOB_ASSERT(0)
  ) dut (
    .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err
  );
`endif

  `include "sf_tb_body.svh"
endmodule

`default_nettype wire
