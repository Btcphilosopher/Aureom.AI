# SilicaFlux SRAMCore (`silicaflux-sramcore`) — configurable synchronous SRAM

**Primary RTL:** `rtl/sram/sf_sram_core.sv` · Project 71 · Aureom.AI | SilicaFlux Semiconductor Systems

The foundational single-port synchronous SRAM for processor caches, tensor operand buffers, vector scratchpads, ControlCore memory and
future storage processors: byte-enable writes, fixed read latency, read-data-valid, optional write acknowledgement, an explicit
bounds policy (invalid addresses are flagged, never aliased), and storage that is never reset by the controller.

> **Not committed to GitHub** — delivered as a plain archive, like the other SilicaFlux modules.  Simulation (Verilator 5.020, Icarus 12.0) and
> Yosys 0.33 evidence only: no vendor FPGA tool, no board, no silicon, **no ASIC area / power / access-time figure** and no clock-frequency claim anywhere in this package.

## Quick start

```
make sram-primary    # single-port 32-bit x 1024 first (Verilator + Icarus)
make sram-quick      # lint + 32-bit, 64-bit and invalid-address configurations
make sram-all        # lint, illegal-parameter rejection, simulation sweep, cross-checks, mutation, synthesis, gate-level, summary
make package         # ../silicaflux-sramcore-p71.zip
```
Requirements: Verilator ≥ 5.020, Icarus Verilog 12, Yosys 0.33, Python ≥ 3.10 (standard library only).  Start reading at `reports/SUMMARY.md`.

## The core in one screen

```systemverilog
sf_sram_core #(.DATA_WIDTH(32), .DEPTH_WORDS(1024)) u_mem (   // 1-cycle read, 4 byte enables, write ack
  .clk, .rst_n, .ce, .we, .addr, .wmask, .wdata, .rdata, .rd_valid, .rd_err, .wr_ack, .wr_err);
```

| | |
|---|---|
| Parameters | `DATA_WIDTH` `DEPTH_WORDS` `ADDR_WIDTH` `BYTE_WIDTH`(=8) `READ_LATENCY` `INIT_MODE` `INIT_FILE` `WRITE_ACK` `OOB_ASSERT`; illegal values fail elaboration |
| Port | one read/write port, always accepts, one access per cycle in any mix |
| Read | `rd_valid` + `rdata` exactly `READ_LATENCY` cycles later; `rdata` valid only with `rd_valid` |
| Write | per-lane `wmask`; untouched lanes preserved; zero strobes legal; `wr_ack` next cycle (optional) |
| Invalid address (`addr >= DEPTH_WORDS`) | never touches the array, no aliasing; `rd_err` (read, data = 0) / `wr_err` (also when writes are posted) |
| Reset | `rst_n` clears only the response pipelines; **the array and data registers are never reset**; contents survive controller reset |
| Init | `NONE` (ASIC-compatible default) / `ZERO` / `FILE` / `PATTERN` (simulation only) |
| Verified | 32-bit × 1024 first, then 64-bit × 1024 and a sweep of widths, depths, latencies, lane widths and init modes |

Full normative text: `docs/01_interface_and_semantics.md`.

## Deliverables → location

| Brief item | Where |
|---|---|
| `rtl/sram/sf_sram_core.sv` | `rtl/sram/sf_sram_core.sv` (control policy) over `rtl/sram/sf_sram_array.sv` (inferred storage); `sf_sram_defs.svh`, `files.f` |
| Reusable SRAM interface | `rtl/sram/sf_sram_if.sv` (master / slave / monitor modports + protocol checker), `rtl/sram/sf_sram_core_if.sv` |
| Tests for 32-bit and 64-bit variants | `tb/sram/tb_sf_sram_core.sv` + `sf_tb_body.svh` (one parameterised body, 32-bit and 64-bit configurations in `scripts/common.py`); `tb_sf_sram_if.sv`, `tb_sf_sram_xcheck.sv`, `tb_sf_sram_assert.sv` |
| Configuration examples | `examples/sf_sram_examples.sv`, `examples/README.md` |
| Makefile targets | `Makefile` (`sram-*`) |
| Documentation | `docs/00_repository_audit.md` … `04_status_and_next_actions.md` |
| Synthesis report | `reports/synth.md` (+ `gls.md` gate-level simulation) |
| Repository audit | `docs/00_repository_audit.md` |

## Layout

```
rtl/sram/        sf_sram_core.sv  sf_sram_array.sv  sf_sram_defs.svh  sf_sram_if.sv  sf_sram_core_if.sv  files.f
tb/sram/         tb_sf_sram_core.sv  sf_tb_body.svh  tb_sf_sram_if.sv  tb_sf_sram_xcheck.sv  tb_sf_sram_assert.sv
examples/        sf_sram_examples.sv  README.md
scripts/         common.py  run_regress.py  run_mutants.py  run_synth.py  run_gls.py  make_summary.py  package.sh
third_party/     silicaflux-sramlib/   4 files vendored unmodified (PROVENANCE.md, SHA256SUMS)
docs/            00 audit · 01 interface and semantics · 02 verification · 03 FPGA vs ASIC · 04 status and next actions
reports/         SUMMARY.md  regression.{md,json}  mutants.{md,json}  synth.{md,json}  gls.{md,json}
SHA256SUMS       every delivered file
```

## Results (generated from the JSON reports of the final run)

<!--RESULTS-->
| Check | Result | Notes |
|---|---|---|
| Lint: Verilator `-Wall` (zero warnings) + Icarus `-Wall` | 64 pass / 0 fail | every configuration, interface wrapper, 7 examples |
| Illegal parameterisations rejected | 16 pass / 0 fail | 16 cases x Verilator, Icarus, Yosys |
| Self-checking simulation | 50 pass / 0 fail | 50 runs, 8,109,361 scoreboard checks; 32-bit x 1024: 4 runs, 64-bit x 1024: 4 runs |
| Same seed = same stimulus, Verilator vs Icarus | 3 pass / 0 fail | metric line compared |
| Cycle-equivalence with the verified library backends (GENERIC + FPGA templates) | 11 pass / 0 fail | 16/32/64-bit, latency 1-3 |
| Simulation assertions fire exactly where intended | 2 pass / 0 fail | Verilator + Icarus |
| SV interface wrapper + protocol checker | 2 pass / 0 fail | Verilator |
| Mutation sanity: injected RTL bugs | 22 killed / 0 survived / 0 invalid | of 22; `reports/mutants.md` |
| Yosys generic synthesis + FPGA inference + examples | 40 pass / 0 fail | latch count 0; one synchronous-read memory per config; xc7 / ice40 / ecp5 block RAM; `reports/synth.md` |
| Gate-level simulation of synthesised netlists | 13 pass / 0 fail | generic gates, xc7 distributed RAM, iCE40 block RAM; `reports/gls.md` |
| xc7 block RAM for the primary 32 x 1024 | {'RAMB36E1': 1} | 2 flip-flops, 8 LUTs of glue (Yosys; inference evidence only) |

Tools: verilator `Verilator 5.020 2024-01-01 rev (Debian 5.020-1)`; iverilog `Icarus Verilog version 12.0 (stable) ()`; yosys `Yosys 0.33 (git sha1 2584903a060)`; python `3.13.18`.  Not installed: vivado, quartus, openroad.  RTL sha256 `0db45ccfdd131c20…`.
<!--/RESULTS-->

## Honest limits

* Evidence is simulation + Yosys.  Block-RAM inference was checked with Yosys only; **Vivado / Quartus behaviour is unverified**, including read-during-write mode and
  whether a latency-2 read register is merged into the RAM's output register (Yosys 0.33 does not merge it).
* Gate-level simulation covers generic gates, xc7 distributed RAM and iCE40 block RAM.  Xilinx RAMB and ECP5 DP16KD netlists could not be simulated (the cell models shipped with
  Yosys are timing-only).
* No formal proofs, no ASIC macro flow, no dual-port option (policy declared in docs/01 §9), no MBIST, ECC or handshake (use the SRAM Wrapper Library wrappers around or beside this core).
* This core reuses, rather than replaces, Project 01 (`silicaflux-sramlib`): four of its verified files are vendored for the testbenches, and the core is cycle-equivalent to its raw
  single-port backends (`tb_sf_sram_xcheck`).  See `docs/00_repository_audit.md`.
