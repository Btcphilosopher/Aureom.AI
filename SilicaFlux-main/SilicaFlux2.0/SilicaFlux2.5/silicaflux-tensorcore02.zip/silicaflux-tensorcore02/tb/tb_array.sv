// =============================================================================
//  SilicaFlux TENSORCORE 02  --  tb_array.sv
//  Self-checking array-level testbench.  Runs unchanged on Icarus and Verilator.
//
//  +VEC=<file>     vector file from tools/gen_vectors.py (independent numpy oracle)
//  +WAVE=<file>    write a VCD (Icarus / Verilator --trace)
//  +PERFLOG        print one PERF line per tile
//  +NODIRECTED     skip the built-in directed reject / reset tests
//
//  DISCIPLINE (race freedom): every TB-driven DUT input is updated with a
//  non-blocking assignment at a clock edge; every DUT output is sampled at the
//  edge, i.e. before the DUT's own non-blocking updates land.  Variables shared
//  between processes are written by exactly one process.
//
//  CHECKS PERFORMED BY THE WHITE-BOX MONITOR (every enabled cycle, every PE)
//   - token validity at the input pins of PE(i,j) matches the ideal wavefront
//        A valid  <=>  i <  M  and 0 <= (step-1-i-j) < K
//        B valid  <=>  j <  N  and 0 <= (step-1-i-j) < K         (step = en-cycle)
//   - operand DATA equals A[i][k] / B[k][j] with k = step-1-i-j  (token alignment,
//     checked against the operand source, not against the RTL k-index sideband)
//   - invalid tokens carry zero data (zero padding); `last` tag only on k = K-1
//   - fire at PE(i,j) iff both valid; commit exactly MUL_PIPE en-cycles later
//   - per-PE done flag == (commits so far == K)  (no early / late done)
//   - global-enable invariants: pipe_en == s_valid & ~stall in RUN; frozen
//     cycles leave accumulators and forwarding registers untouched
//   - tile_done only after every active PE committed exactly K MACs; accumulators
//     already equal the expected tile at the first tile_done cycle and stay
//     stable for the whole READOUT; no MAC after tile_done
//   - cycle accounting identity and the RTL perf counters vs. the TB's own count
// =============================================================================
`timescale 1ns/1ps
module tb_array #(
    parameter int ROWS      = 4,
    parameter int COLS      = 4,
    parameter int DW        = 8,
    parameter int ACC       = 32,
    parameter int KW        = 17,
    parameter int MUL_PIPE  = 0,
    parameter int CHECK     = 1,
    parameter int PERF      = 1,
    parameter int MEM_WORDS = 1 << 21
);
    localparam int NPE = ROWS * COLS;
    localparam int MW  = $clog2(ROWS + 1);
    localparam int NW  = $clog2(COLS + 1);
    localparam int RW  = (ROWS > 1) ? $clog2(ROWS) : 1;
    localparam int CMAX = 1 << 14;

    localparam [2:0] S_IDLE = 3'd0, S_CLEAR = 3'd1, S_RUN = 3'd2, S_DRAIN = 3'd3, S_READOUT = 3'd4;

    // --------------------------------------------------------------- clock/DUT
    reg clk = 1'b0;
    always #5 clk = ~clk;
    reg rst_n = 1'b0;

    reg                     cfg_valid = 1'b0;
    wire                    cfg_ready;
    reg  [MW-1:0]           cfg_m = '0;
    reg  [NW-1:0]           cfg_n = '0;
    reg  [KW-1:0]           cfg_k = '0;
    wire                    cfg_reject;
    reg                     s_valid = 1'b0;
    wire                    s_ready;
    reg  [ROWS*DW-1:0]      s_a = '0;
    reg  [COLS*DW-1:0]      s_b = '0;
    wire [KW-1:0]           s_k;
    reg                     stall_i = 1'b0;
    wire                    m_valid;
    reg                     m_ready = 1'b0;
    wire [RW-1:0]           m_row;
    wire [COLS*ACC-1:0]     m_data;
    wire [COLS-1:0]         m_col_mask;
    wire                    m_last;
    wire                    busy, tile_done, align_err;
    wire [39:0]             perf_busy, perf_issue, perf_stall_up, perf_stall_ext, perf_mac, perf_pad;

    tensor_systolic_array #(
        .ARRAY_ROWS(ROWS), .ARRAY_COLS(COLS), .DATA_WIDTH(DW), .ACC_WIDTH(ACC),
        .K_WIDTH(KW), .MUL_PIPE(MUL_PIPE), .CHECK_ALIGN(CHECK), .PERF_EN(PERF)
    ) dut (
        .clk(clk), .rst_n(rst_n),
        .cfg_valid(cfg_valid), .cfg_ready(cfg_ready), .cfg_m(cfg_m), .cfg_n(cfg_n),
        .cfg_k(cfg_k), .cfg_reject(cfg_reject),
        .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k),
        .stall_i(stall_i),
        .m_valid(m_valid), .m_ready(m_ready), .m_row(m_row), .m_data(m_data),
        .m_col_mask(m_col_mask), .m_last(m_last),
        .busy(busy), .tile_done(tile_done), .align_err(align_err),
        .perf_busy(perf_busy), .perf_issue(perf_issue), .perf_stall_up(perf_stall_up),
        .perf_stall_ext(perf_stall_ext), .perf_mac(perf_mac), .perf_pad(perf_pad)
    );

    // ------------------------------------------------------------ test storage
    reg [31:0] mem  [0:MEM_WORDS-1];
    reg [31:0] cmem [0:CMAX-1];                 // captured result matrix
    reg [8*512-1:0] vecfile;
    reg [8*512-1:0] wavefile;
    integer ptr, ntests;

    // current test (written by main only; read by monitor between tiles)
    integer t_tid, t_M, t_N, t_K, t_mode, t_up, t_ext, t_rdy, t_flags, t_cat, t_reps;
    reg [31:0] t_p0, t_p1, t_seed;
    integer t_Abase, t_Bbase, t_Cbase;
    reg     use_sv_oracle;                     // expected C from SV GEMM, not from vector file
    // current tile context (written by main before cfg; read by monitor after cfg_go)
    integer tile_r0, tile_c0, tile_m, tile_n;

    // --------------------------------------------------------------- utilities
    function automatic [31:0] xs32(input [31:0] s);
        reg [31:0] x;
        begin
            x = s;
            x = x ^ (x << 13);
            x = x ^ (x >> 17);
            x = x ^ (x << 5);
            xs32 = x;
        end
    endfunction

    function automatic integer sext_dw(input [31:0] w);
        integer v;
        begin
            v = w & ((1 << DW) - 1);
            if (v >= (1 << (DW - 1))) v = v - (1 << DW);
            sext_dw = v;
        end
    endfunction

    // mirror of hash_u32()/to_signed() in tools/gen_vectors.py
    function automatic integer hashv(input [31:0] seed, input integer r, input integer c,
                                     input integer which);
        reg [31:0] x, rr, cc, ww;
        begin
            rr = r; cc = c; ww = which;
            x = seed ^ (rr * 32'h9E3779B1) ^ (cc * 32'h85EBCA6B) ^ (ww * 32'hC2B2AE35);
            x = x ^ (x >> 16);
            x = x * 32'h7FEB352D;
            x = x ^ (x >> 15);
            x = x * 32'h846CA68B;
            x = x ^ (x >> 16);
            hashv = sext_dw(x);
        end
    endfunction

    // operand sources for the CURRENT test (absolute matrix indices)
    function automatic integer opA(input integer r, input integer k);
        begin
            case (t_mode)
                0:       opA = sext_dw(mem[t_Abase + r * t_K + k]);
                1:       opA = sext_dw(t_p0);
                default: opA = hashv(t_p0, r, k, 0);
            endcase
        end
    endfunction

    function automatic integer opB(input integer k, input integer c);
        begin
            case (t_mode)
                0:       opB = sext_dw(mem[t_Bbase + k * t_N + c]);
                1:       opB = sext_dw(t_p1);
                default: opB = hashv(t_p1, k, c, 1);
            endcase
        end
    endfunction

    function automatic [31:0] acc_mask(input [31:0] v);
        begin
            acc_mask = v & (32'hFFFFFFFF >> (32 - ACC));
        end
    endfunction

    // signed integer GEMM reference (32-bit wrap, then reduced mod 2**ACC)
    function automatic [31:0] sv_ref(input integer r, input integer c);
        integer k, sum;
        begin
            sum = 0;
            for (k = 0; k < t_K; k = k + 1) sum = sum + opA(r, k) * opB(k, c);
            sv_ref = acc_mask(sum);
        end
    endfunction

    function automatic [31:0] exp_c(input integer r, input integer c);
        begin
            if (use_sv_oracle) exp_c = sv_ref(r, c);
            else               exp_c = acc_mask(mem[t_Cbase + r * t_N + c]);
        end
    endfunction

    // ------------------------------------------------ stall / backpressure gens
    //  t_ext : 0 none | 1 random 20% | 2 random bursts | 3 alternate cycles |
    //          4 period-5 | 5 40-cycle burst during fill | 6 40-cycle burst in DRAIN |
    //          7 single stall exactly in the cycle all_done is true
    //  t_rdy : 0 always | 1 random 50% | 2 every 7th cycle | 3 low for 30 cycles
    reg [31:0] lf_stall = 32'h1, lf_rdy = 32'h1;
    integer    gen_tcyc, gen_burst, gen_drain, gen_rdcyc;
    initial begin gen_tcyc = 0; gen_burst = 0; gen_drain = 0; gen_rdcyc = 0; end

    always @(posedge clk) begin : stall_ready_gen
        reg ns, nr, pred_done;
        integer ii;
        reg [31:0] st;
        st = dut.state_q;
        if (!rst_n || st == S_IDLE) begin
            gen_tcyc = 0; gen_burst = 0; gen_drain = 0;
        end else begin
            gen_tcyc = gen_tcyc + 1;
        end
        if (st == S_DRAIN) gen_drain = gen_drain + 1; else if (st != S_DRAIN && st != S_READOUT) gen_drain = 0;
        if (st == S_READOUT) gen_rdcyc = gen_rdcyc + 1; else gen_rdcyc = 0;

        // ---- stall_i for the next cycle
        ns = 1'b0;
        pred_done = 1'b1;
        for (ii = 0; ii < NPE; ii = ii + 1)
            if ((ii / COLS) < tile_m && (ii % COLS) < tile_n)
                if (!(dut.done_flat[ii] | dut.commit_flat[ii])) pred_done = 1'b0;
        lf_stall = xs32(lf_stall);
        case (t_ext)
            1: ns = (lf_stall[7:0] < 8'd51);
            2: begin
                if (gen_burst > 0) begin ns = 1'b1; gen_burst = gen_burst - 1; end
                else if (lf_stall[7:0] < 8'd16) begin ns = 1'b1; gen_burst = lf_stall[11:8] % 12; end
            end
            3: ns = gen_tcyc[0];
            4: ns = ((gen_tcyc % 5) == 2);
            5: ns = (gen_tcyc >= 3 && gen_tcyc < 43);
            6: ns = (gen_drain >= 2 && gen_drain < 42);
            7: ns = (st == S_DRAIN) && pred_done && !dut.all_done;
            default: ns = 1'b0;
        endcase
        stall_i <= rst_n ? ns : 1'b0;

        // ---- m_ready for the next cycle
        lf_rdy = xs32(lf_rdy);
        case (t_rdy)
            1: nr = lf_rdy[3];
            2: nr = ((gen_rdcyc % 7) == 0);
            3: nr = (gen_rdcyc >= 30);
            default: nr = 1'b1;
        endcase
        m_ready <= nr;
    end

    // ---------------------------------------------------------------- monitor
    reg prev_readout_q = 1'b0;
    always @(posedge clk) prev_readout_q <= (dut.state_q == S_READOUT) && rst_n;

    integer mon_errs;             // monitor-owned
    integer mon_cyc;              // monitor-owned free-running cycle counter
    integer mon_step;             // en-cycle index (valid in RUN/DRAIN)
    integer pe_fire_cnt   [0:NPE-1];
    integer pe_commit_cnt [0:NPE-1];
    reg [NPE*ACC-1:0] acc_snap;
    reg [(NPE)*ACC-1:0] frz_acc;
    reg [ROWS*(COLS+1)-1:0] frz_av;
    reg [(ROWS+1)*COLS-1:0] frz_bv;
    reg prev_en_zero, prev_active;
    // per-tile measurements (monitor-owned, read by main one cycle after tile end)
    integer m_h, m_d, m_issue, m_stall_up, m_stall_ext, m_macs, m_tile_valid;
    reg [39:0] r_busy, r_issue, r_su, r_se, r_mac, r_pad;   // RTL counters sampled at tile_done
    integer mon_msgs;
    reg     trace_en = 1'b0;                      // +TRACE: print first cycles
    reg     mon_allow_align = 1'b0;               // set only during the directed fault-injection test
    integer max_cyc = 50000000;                   // global hang guard (+MAXCYC=<n>)

    initial begin
        mon_errs = 0; mon_cyc = 0; mon_step = 0; mon_msgs = 0; m_tile_valid = 0;
        m_h = 0; m_d = 0; m_issue = 0; m_stall_up = 0; m_stall_ext = 0; m_macs = 0;
        prev_en_zero = 0; prev_active = 0;
    end

    // Fail fast: a broken design must not grind through watchdogs.
    task automatic bail(input [8*40-1:0] why);
        begin
            $display("TB_ABORT: %0s (monitor_errs=%0d main_errs=%0d)", why, mon_errs, main_errs);
            $display("TB_SUMMARY aborted tests_pass=%0d tests_fail=%0d", tests_pass, tests_fail);
            $display("TB_RESULT: FAIL");
            $finish;
        end
    endtask

    task automatic mon_fail(input [8*64-1:0] what, input integer a, input integer b, input integer c);
        begin
            mon_errs = mon_errs + 1;
            if (mon_errs > 60) bail("too many monitor errors");
            if (mon_msgs < 25) begin
                mon_msgs = mon_msgs + 1;
                $display("MONITOR_ERROR t=%0t cyc=%0d test=%0d: %0s (%0d,%0d,%0d)",
                         $time, mon_cyc, t_tid, what, a, b, c);
            end
        end
    endtask

    always @(posedge clk) begin : monitor
        integer i, j, idx, st, s_rel, kc, ai, bi;
        reg expA, expB, act, expC, av, bv, en;
        reg signed [DW-1:0] ad, bd;
        reg [31:0] lane, e;
        integer ref_a, ref_b;
        mon_cyc = mon_cyc + 1;
        if (trace_en && mon_cyc < 40)
            $display("TRACE cyc=%0d rst_n=%b state=%0d cfg_valid=%b cfg_ready=%b s_valid=%b s_ready=%b", mon_cyc, rst_n, dut.state_q, cfg_valid, cfg_ready, s_valid, s_ready);
        if (mon_cyc > max_cyc) bail("global cycle limit (hang?)");
        st = dut.state_q;
        en = dut.pipe_en;

        if (!rst_n) begin
            prev_en_zero = 0; prev_active = 0;
        end else begin
            // alignment checker must never fire on legal traffic
            // (the sticky flag clears at the end of CLEAR, so it is only enforced from RUN onward)
            if (CHECK != 0 && dut.align_err && !mon_allow_align && (st == S_RUN || st == S_DRAIN || st == S_READOUT))
                mon_fail("align_err asserted", 0, 0, 0);

            // ---- status ports checked directly (not derived from the RTL's own state)
            if (tile_done !== m_valid)                         mon_fail("tile_done != m_valid", tile_done, m_valid, 0);
            if (busy !== (st != S_IDLE))                       mon_fail("busy port wrong", busy, st, 0);
            if (tile_done && (st == S_IDLE || st == S_CLEAR || st == S_RUN || st == S_DRAIN))
                mon_fail("tile_done asserted before READOUT", st, 0, 0);
            if (st == S_READOUT && tile_done !== 1'b1)         mon_fail("tile_done dropped during READOUT", 0, 0, 0);
            if (tile_done && st == S_DRAIN)                    mon_fail("tile_done during DRAIN", 0, 0, 0);

            // ------------------------------------------------ launch bookkeeping
            if (dut.cfg_go) begin
                m_h = mon_cyc; m_issue = 0; m_stall_up = 0; m_stall_ext = 0; m_macs = 0;
                m_tile_valid = 0;
            end
            if (st == S_CLEAR) begin
                mon_step = 0;
                for (idx = 0; idx < NPE; idx = idx + 1) begin pe_fire_cnt[idx] = 0; pe_commit_cnt[idx] = 0; end
                prev_en_zero = 0; prev_active = 0;
            end

            // ------------------------------------------------------ RUN / DRAIN
            if (st == S_RUN || st == S_DRAIN) begin
                if (s_valid && s_ready) m_issue = m_issue + 1;
                if (s_ready && !s_valid) m_stall_up = m_stall_up + 1;
                if (stall_i && !(st == S_DRAIN && dut.all_done)) m_stall_ext = m_stall_ext + 1;

                // global enable protocol
                if (st == S_RUN && (en !== (s_valid && !stall_i))) mon_fail("pipe_en != s_valid&~stall in RUN", 0, 0, 0);
                if (st == S_DRAIN && (en !== !stall_i))            mon_fail("pipe_en != ~stall in DRAIN", 0, 0, 0);
                if (st == S_RUN && s_ready !== !stall_i)           mon_fail("s_ready != ~stall in RUN", 0, 0, 0);

                // frozen cycle must not disturb state (compare against previous snapshot)
                if (prev_active && prev_en_zero) begin
                    if (dut.acc_flat !== frz_acc) mon_fail("acc changed during freeze", 0, 0, 0);
                    if (dut.a_valid_bus !== frz_av) mon_fail("A tokens moved during freeze", 0, 0, 0);
                    if (dut.b_valid_bus !== frz_bv) mon_fail("B tokens moved during freeze", 0, 0, 0);
                end
                frz_acc = dut.acc_flat;
                frz_av  = dut.a_valid_bus;
                frz_bv  = dut.b_valid_bus;
                prev_en_zero = !en;
                prev_active  = 1'b1;

                for (i = 0; i < ROWS; i = i + 1) begin
                    for (j = 0; j < COLS; j = j + 1) begin
                        idx = i * COLS + j;
                        act = (i < tile_m) && (j < tile_n);

                        // done flag must equal "all K commits already happened"
                        if (dut.done_flat[idx] !== (act && (pe_commit_cnt[idx] == t_K)))
                            mon_fail("done flag mismatch PE", i, j, pe_commit_cnt[idx]);

                        if (!en) begin
                            if (dut.fire_flat[idx] || dut.commit_flat[idx])
                                mon_fail("MAC while frozen PE", i, j, 0);
                        end else begin
                            s_rel = mon_step - (1 + i + j);          // k at this PE's pins
                            expA  = (i < tile_m) && (s_rel >= 0) && (s_rel < t_K);
                            expB  = (j < tile_n) && (s_rel >= 0) && (s_rel < t_K);
                            ai = i * (COLS + 1) + j;
                            bi = i * COLS + j;
                            av = dut.a_valid_bus[ai];
                            bv = dut.b_valid_bus[bi];
                            ad = dut.a_data_bus[ai * DW +: DW];
                            bd = dut.b_data_bus[bi * DW +: DW];
                            if (av !== expA) mon_fail("A valid mismatch PE", i, j, s_rel);
                            if (bv !== expB) mon_fail("B valid mismatch PE", i, j, s_rel);
                            if (expA) begin
                                ref_a = opA(tile_r0 + i, s_rel);
                                if (ad !== ref_a[DW-1:0]) mon_fail("A data/k misaligned PE", i, j, s_rel);
                                if (dut.a_last_bus[ai] !== (s_rel == t_K - 1)) mon_fail("A last tag PE", i, j, s_rel);
                                if (CHECK != 0 && dut.a_kidx_bus[ai * KW +: KW] !== s_rel[KW-1:0]) mon_fail("A kidx PE", i, j, s_rel);
                            end else if (ad !== 0) mon_fail("A pad data nonzero PE", i, j, 0);
                            if (expB) begin
                                ref_b = opB(s_rel, tile_c0 + j);
                                if (bd !== ref_b[DW-1:0]) mon_fail("B data/k misaligned PE", i, j, s_rel);
                                if (dut.b_last_bus[bi] !== (s_rel == t_K - 1)) mon_fail("B last tag PE", i, j, s_rel);
                                if (CHECK != 0 && dut.b_kidx_bus[bi * KW +: KW] !== s_rel[KW-1:0]) mon_fail("B kidx PE", i, j, s_rel);
                            end else if (bd !== 0) mon_fail("B pad data nonzero PE", i, j, 0);

                            // fire = both valid; commit MUL_PIPE en-cycles later
                            if (dut.fire_flat[idx] !== (expA && expB)) mon_fail("fire mismatch PE", i, j, s_rel);
                            if (dut.fire_flat[idx]) pe_fire_cnt[idx] = pe_fire_cnt[idx] + 1;

                            kc   = mon_step - (1 + i + j + MUL_PIPE);
                            expC = act && (kc >= 0) && (kc < t_K);
                            if (dut.commit_flat[idx] !== expC) mon_fail("commit timing mismatch PE", i, j, kc);
                            if (dut.commit_flat[idx]) begin
                                if (pe_commit_cnt[idx] != kc) mon_fail("duplicate/skipped MAC PE", i, j, kc);
                                pe_commit_cnt[idx] = pe_commit_cnt[idx] + 1;
                                m_macs = m_macs + 1;
                            end
                        end
                    end
                end
                if (en) mon_step = mon_step + 1;
            end else begin
                prev_active = 1'b0;
            end

            // ----------------------------------------------------------- READOUT
            if (st == S_READOUT) begin
                if (!prev_readout_q) begin                      // first cycle of tile_done
                    m_d = mon_cyc;
                    m_tile_valid = 1;
                    r_busy = perf_busy; r_issue = perf_issue; r_su = perf_stall_up;
                    r_se = perf_stall_ext; r_mac = perf_mac; r_pad = perf_pad;
                    if (!dut.all_done) mon_fail("tile_done but all_done low", 0, 0, 0);
                    for (i = 0; i < tile_m; i = i + 1)
                        for (j = 0; j < tile_n; j = j + 1) begin
                            idx = i * COLS + j;
                            if (pe_commit_cnt[idx] != t_K) mon_fail("tile_done before K MACs PE", i, j, pe_commit_cnt[idx]);
                            if (pe_fire_cnt[idx]   != t_K) mon_fail("fire count != K PE", i, j, pe_fire_cnt[idx]);
                            lane = dut.acc_flat[idx * ACC +: ACC];
                            e    = exp_c(tile_r0 + i, tile_c0 + j);
                            if (acc_mask(lane) !== e) mon_fail("acc != expected at tile_done PE", i, j, lane);
                        end
                    for (idx = 0; idx < NPE; idx = idx + 1)
                        if (!((idx / COLS) < tile_m && (idx % COLS) < tile_n))
                            if (pe_commit_cnt[idx] != 0) mon_fail("inactive PE accumulated", idx / COLS, idx % COLS, 0);
                    acc_snap = dut.acc_flat;
                end else begin
                    if (dut.acc_flat !== acc_snap) mon_fail("accumulators moved during READOUT", 0, 0, 0);
                end
                if (|dut.commit_flat || |dut.fire_flat) mon_fail("MAC during READOUT", 0, 0, 0);
            end else if (st == S_IDLE) begin
                if (|dut.commit_flat || |dut.fire_flat) mon_fail("MAC while IDLE", 0, 0, 0);
            end
        end
    end

    // ---------------------------------------------------- edge sampler (race-free)
    //  The main flow never reads DUT outputs at the clock edge.  This always block
    //  captures them with non-blocking assignments (pre-edge values, identical in
    //  Icarus and Verilator); the main flow waits  @(posedge clk); #1  (task `tick`)
    //  and then reads these registers: "the value during the cycle that just ended".
    reg                smp_cfg_valid = 0, smp_cfg_ready = 0, smp_s_valid = 0, smp_s_ready = 0;
    reg                smp_m_valid = 0, smp_m_ready = 0, smp_m_last = 0, smp_cfg_reject = 0;
    reg [KW-1:0]       smp_s_k = 0;
    reg [RW-1:0]       smp_m_row = 0;
    reg [COLS*ACC-1:0] smp_m_data = 0;
    reg [COLS-1:0]     smp_m_col_mask = 0;
    always @(posedge clk) begin
        smp_cfg_valid  <= cfg_valid;  smp_cfg_ready <= cfg_ready;
        smp_s_valid    <= s_valid;    smp_s_ready   <= s_ready;     smp_s_k <= s_k;
        smp_m_valid    <= m_valid;    smp_m_ready   <= m_ready;     smp_m_last <= m_last;
        smp_m_row      <= m_row;      smp_m_data    <= m_data;      smp_m_col_mask <= m_col_mask;
        smp_cfg_reject <= cfg_reject;
    end

    task automatic tick;
        begin @(posedge clk); #1; end
    endtask

    // ------------------------------------------------------------ main flow
    integer main_errs, tests_pass, tests_fail, tiles_run, perf_lines;
    integer g_r0, g_c0, g_m, g_n;
    reg [31:0] up_lf = 32'h2468ace1, junk_lf = 32'h13579bdf;
    integer fcyc;
    integer msgs;

    task automatic main_fail(input [8*64-1:0] what, input integer a, input integer b);
        begin
            main_errs = main_errs + 1;
            if (main_errs > 60) bail("too many testbench errors");
            if (msgs < 25) begin
                msgs = msgs + 1;
                $display("TB_ERROR t=%0t test=%0d: %0s (%0d,%0d)", $time, t_tid, what, a, b);
            end
        end
    endtask

    function automatic reg up_gate(input integer prof, input integer c, input [31:0] lf);
        begin
            case (prof)
                1:       up_gate = (lf[1:0] != 2'd0);
                2:       up_gate = (lf[1:0] == 2'd0);
                3:       up_gate = (c % 2 == 0);
                4:       up_gate = ((c % 8) < 5);
                default: up_gate = 1'b1;
            endcase
        end
    endfunction

    // present slice k for the NEXT cycle
    task automatic drive_slice(input integer k);
        integer ii;
        reg g;
        reg [31:0] v;
        begin
            up_lf = xs32(up_lf);
            g = up_gate(t_up, fcyc, up_lf);
            s_valid <= (k < t_K) && g;
            for (ii = 0; ii < ROWS; ii = ii + 1) begin
                junk_lf = xs32(junk_lf);
                if (ii < g_m && k < t_K && g) v = opA(g_r0 + ii, k);
                else                          v = junk_lf;                // junk in masked/idle lanes
                s_a[ii * DW +: DW] <= v[DW-1:0];
            end
            for (ii = 0; ii < COLS; ii = ii + 1) begin
                junk_lf = xs32(junk_lf);
                if (ii < g_n && k < t_K && g) v = opB(k, g_c0 + ii);
                else                          v = junk_lf;
                s_b[ii * DW +: DW] <= v[DW-1:0];
            end
        end
    endtask

    // one tile: launch, feed K slices, collect M rows
    task automatic run_tile;
        integer kq, wd, rows_got, j, wdl;
        reg hs, fin;
        reg [31:0] lane;
        begin
            tile_r0 = g_r0; tile_c0 = g_c0; tile_m = g_m; tile_n = g_n;
            wdl = 60 * t_K + 4000;

            cfg_m <= g_m[MW-1:0]; cfg_n <= g_n[NW-1:0]; cfg_k <= t_K[KW-1:0]; cfg_valid <= 1'b1;
            hs = 1'b0; wd = 0;
            while (!hs) begin
                tick;
                if (smp_cfg_valid && smp_cfg_ready) hs = 1'b1;
                wd = wd + 1;
                if (wd > wdl) begin main_fail("cfg handshake timeout", 0, 0); bail("cfg watchdog"); end
            end
            cfg_valid <= 1'b0;

            kq = 0; fcyc = 0; wd = 0;
            drive_slice(0);
            while (kq < t_K) begin
                tick;
                if (smp_s_valid && smp_s_ready) begin
                    if (smp_s_k !== kq[KW-1:0]) main_fail("s_k != expected slice index", smp_s_k, kq);
                    kq = kq + 1;
                end
                fcyc = fcyc + 1;
                drive_slice(kq);
                wd = wd + 1;
                if (wd > wdl) begin main_fail("feed timeout", kq, 0); bail("feed watchdog"); end
            end

            rows_got = 0; wd = 0; fin = 1'b0;
            while (!fin) begin
                tick;
                if (smp_m_valid && smp_m_ready) begin
                    if (smp_m_row !== rows_got[RW-1:0]) main_fail("m_row sequence", smp_m_row, rows_got);
                    if (smp_m_last !== (rows_got == g_m - 1)) main_fail("m_last wrong", rows_got, smp_m_last);
                    for (j = 0; j < COLS; j = j + 1) begin
                        lane = smp_m_data[j * ACC +: ACC];
                        if (j < g_n) begin
                            if (smp_m_col_mask[j] !== 1'b1) main_fail("m_col_mask low on active col", j, 0);
                            if (rows_got < g_m) cmem[(g_r0 + rows_got) * t_N + g_c0 + j] = lane;
                        end else begin
                            if (smp_m_col_mask[j] !== 1'b0) main_fail("m_col_mask high on pad col", j, 0);
                            if (lane !== 0)             main_fail("pad column not zero", j, lane);
                        end
                    end
                    rows_got = rows_got + 1;
                    if (smp_m_last) fin = 1'b1;
                end
                wd = wd + 1;
                if (wd > wdl) begin main_fail("readout timeout", rows_got, 0); bail("readout watchdog"); end
            end
            if (rows_got != g_m) main_fail("rows returned != M", rows_got, g_m);
            tick;                            // settle: monitor finishes tile
            // ---------------------------------------------- per-tile accounting
            if (m_tile_valid == 0) main_fail("monitor never saw tile_done", 0, 0);
            begin : acct
                integer busy_tb, exp_busy, exp_mac, exp_pad;
                busy_tb  = m_d - (m_h + 1);
                exp_busy = 1 + t_K + g_m + g_n + MUL_PIPE + m_stall_up + m_stall_ext;
                exp_mac  = g_m * g_n * t_K;
                exp_pad  = (NPE - g_m * g_n) * t_K;
                if (busy_tb != exp_busy) main_fail("busy cycles != 1+K+M+N+MP+stalls", busy_tb, exp_busy);
                if (m_issue != t_K)      main_fail("issued slices != K", m_issue, t_K);
                if (m_macs  != exp_mac)  main_fail("useful MACs != M*N*K", m_macs, exp_mac);
                if (PERF != 0) begin
                    if (r_busy != busy_tb)   main_fail("perf_busy != TB busy", r_busy, busy_tb);
                    if (r_issue != m_issue)  main_fail("perf_issue != TB issue", r_issue, m_issue);
                    if (r_su != m_stall_up)  main_fail("perf_stall_up != TB", r_su, m_stall_up);
                    if (r_se != m_stall_ext) main_fail("perf_stall_ext != TB", r_se, m_stall_ext);
                    if (r_mac != exp_mac)    main_fail("perf_mac != M*N*K", r_mac, exp_mac);
                    if (r_pad != exp_pad)    main_fail("perf_pad != (R*C-M*N)*K", r_pad, exp_pad);
                end
                if (perf_lines < 4000)
                    $display("PERF,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d,%0d",
                             ROWS, COLS, g_m, g_n, t_K, busy_tb, m_issue, m_stall_up, m_stall_ext,
                             m_macs, exp_pad, t_ext, t_up, MUL_PIPE);
                perf_lines = perf_lines + 1;
            end
            tiles_run = tiles_run + 1;
        end
    endtask

    // full GEMM of the current test via ceil(M/ROWS) x ceil(N/COLS) tile launches
    task automatic run_gemm;
        integer mt, nt, x, bad, e0;
        reg [31:0] e;
        begin
            e0 = main_errs + mon_errs;
            for (x = 0; x < t_M * t_N; x = x + 1) cmem[x] = 32'hDEADBEEF;
            for (mt = 0; mt * ROWS < t_M; mt = mt + 1)
                for (nt = 0; nt * COLS < t_N; nt = nt + 1) begin
                    g_r0 = mt * ROWS;
                    g_c0 = nt * COLS;
                    g_m  = (t_M - g_r0 < ROWS) ? (t_M - g_r0) : ROWS;
                    g_n  = (t_N - g_c0 < COLS) ? (t_N - g_c0) : COLS;
                    run_tile;
                end
            bad = 0;
            for (x = 0; x < t_M * t_N; x = x + 1) begin
                e = exp_c(x / t_N, x % t_N);
                if (acc_mask(cmem[x]) !== e) begin
                    bad = bad + 1;
                    if (bad <= 4) main_fail("RESULT MISMATCH C[idx]", x, cmem[x]);
                end
            end
        end
    endtask

    // ------------------------------------------------------ vector-driven tests
    task automatic run_vector_test;
        integer h, x, bad;
        reg [31:0] e;
        integer errs_before, rp;
        begin
            h = ptr;
            t_tid = mem[h + 0]; t_M = mem[h + 1]; t_N = mem[h + 2]; t_K = mem[h + 3];
            t_mode = mem[h + 4]; t_p0 = mem[h + 5]; t_p1 = mem[h + 6];
            t_up = mem[h + 7]; t_ext = mem[h + 8]; t_rdy = mem[h + 9]; t_seed = mem[h + 10];
            t_flags = mem[h + 11]; t_cat = mem[h + 12]; t_reps = mem[h + 13];
            ptr = h + 16;
            t_Abase = ptr; t_Bbase = ptr;
            if (t_mode == 0) begin
                t_Abase = ptr;
                t_Bbase = ptr + t_M * t_K;
                ptr = ptr + t_M * t_K + t_K * t_N;
            end
            t_Cbase = ptr;
            ptr = ptr + t_M * t_N;
            use_sv_oracle = 1'b0;
            lf_stall = t_seed | 32'h1; lf_rdy = (t_seed ^ 32'h9E3779B9) | 32'h1;
            up_lf = (t_seed ^ 32'h5A5A5A5A) | 32'h1;

            errs_before = main_errs + mon_errs;
            msgs = 0; mon_msgs = 0;

            // optional cross-check: SV integer GEMM vs. numpy oracle (skipped for huge K)
            if ((t_flags & 1) == 0) begin
                bad = 0;
                for (x = 0; x < t_M * t_N; x = x + 1)
                    if (sv_ref(x / t_N, x % t_N) !== acc_mask(mem[t_Cbase + x])) bad = bad + 1;
                if (bad != 0) main_fail("ORACLE MISMATCH: SV GEMM vs numpy vectors", bad, 0);
            end

            for (rp = 0; rp < t_reps; rp = rp + 1) run_gemm;

            if (main_errs + mon_errs == errs_before) begin
                tests_pass = tests_pass + 1;
                $display("TEST %0d [%0d] PASS  M=%0d N=%0d K=%0d up=%0d ext=%0d rdy=%0d reps=%0d",
                         t_tid, t_cat, t_M, t_N, t_K, t_up, t_ext, t_rdy, t_reps);
            end else begin
                tests_fail = tests_fail + 1;
                $display("TEST %0d [%0d] FAIL  M=%0d N=%0d K=%0d up=%0d ext=%0d rdy=%0d reps=%0d",
                         t_tid, t_cat, t_M, t_N, t_K, t_up, t_ext, t_rdy, t_reps);
            end
        end
    endtask

    // --------------------------------------------------- internal (SV-oracle) test
    task automatic run_internal(input integer M, input integer N, input integer K,
                                input [31:0] sa, input [31:0] sb, input integer name_id);
        integer errs_before;
        begin
            t_tid = 9000 + name_id; t_M = M; t_N = N; t_K = K; t_mode = 2; t_p0 = sa; t_p1 = sb;
            t_up = 0; t_ext = 0; t_rdy = 0; t_cat = 99; t_reps = 1; t_flags = 0;
            use_sv_oracle = 1'b1;
            errs_before = main_errs + mon_errs;
            msgs = 0; mon_msgs = 0;
            run_gemm;
            if (main_errs + mon_errs == errs_before) tests_pass = tests_pass + 1;
            else begin tests_fail = tests_fail + 1; $display("TEST %0d FAIL (internal)", t_tid); end
        end
    endtask

    // ----------------------------------------------------------- reset helper
    task automatic do_reset(input integer cycles);
        integer c;
        begin
            rst_n <= 1'b0;
            cfg_valid <= 1'b0; s_valid <= 1'b0;
            for (c = 0; c < cycles; c = c + 1) tick;
            rst_n <= 1'b1;
            tick;
            tick;
        end
    endtask

    task automatic expect_clean_idle(input [8*40-1:0] tag);
        begin
            if (cfg_ready !== 1'b1 || m_valid !== 1'b0 || busy !== 1'b0 || tile_done !== 1'b0 ||
                s_ready !== 1'b0 || align_err !== 1'b0)
                main_fail("not clean IDLE after reset", cfg_ready, m_valid);
            if (PERF != 0 && (perf_busy !== 0 || perf_mac !== 0 || perf_issue !== 0))
                main_fail("perf counters not cleared by reset", perf_busy, perf_mac);
            $display("DIRECTED %0s: idle-after-reset check done", tag);
        end
    endtask

    // ---------------------------------------------------- directed: illegal cfg
    task automatic directed_reject;
        integer c, errs_before, seen;
        reg [MW-1:0] big_m;
        reg [NW-1:0] big_n;
        begin
            errs_before = main_errs + mon_errs;
            t_ext = 0; t_rdy = 0; t_up = 0; msgs = 0;
            // each illegal launch must be dropped with a one-cycle cfg_reject and no state change
            for (c = 0; c < 5; c = c + 1) begin
                case (c)
                    0: begin cfg_m <= 0;               cfg_n <= 1;              cfg_k <= 3; end
                    1: begin cfg_m <= 1;               cfg_n <= 0;              cfg_k <= 3; end
                    2: begin cfg_m <= 1;               cfg_n <= 1;              cfg_k <= 0; end
                    3: begin cfg_m <= {MW{1'b1}};      cfg_n <= 1;              cfg_k <= 3; end
                    4: begin cfg_m <= 1;               cfg_n <= {NW{1'b1}};     cfg_k <= 3; end
                endcase
                big_m = {MW{1'b1}}; big_n = {NW{1'b1}};
                // cases 3/4 are only illegal if the all-ones value exceeds the array size
                if ((c == 3 && int'(big_m) <= ROWS) || (c == 4 && int'(big_n) <= COLS)) begin
                    cfg_valid <= 1'b0;
                    tick;
                end else begin
                    cfg_valid <= 1'b1;
                    seen = 0;
                    tick;                              // handshake happened at this edge; pulse registered
                    cfg_valid <= 1'b0;
                    if (cfg_reject === 1'b1) seen = 1;
                    if (!seen)            main_fail("illegal cfg not rejected (no pulse)", c, 0);
                    if (busy !== 1'b0)    main_fail("illegal cfg started a tile", c, 0);
                    if (cfg_ready !== 1'b1) main_fail("cfg_ready dropped after illegal cfg", c, 0);
                    tick;
                    if (cfg_reject !== 1'b0) main_fail("cfg_reject not a 1-cycle pulse", c, 0);
                end
            end
            $display("DIRECTED reject: done");
            if (main_errs + mon_errs != errs_before) tests_fail = tests_fail + 1; else tests_pass = tests_pass + 1;
        end
    endtask

    // ------------------------------------------------- directed: reset in-flight
    //  phase 1 = reset during RUN (tokens in flight), 2 = during DRAIN, 3 = in READOUT
    task automatic directed_reset(input integer phase);
        integer kq, wd, errs_before, M, N, K;
        reg hs, fin;
        begin
            errs_before = main_errs + mon_errs;
            msgs = 0; mon_msgs = 0;
            M = ROWS; N = COLS; K = 40;
            t_tid = 9100 + phase; t_M = M; t_N = N; t_K = K; t_mode = 2;
            t_p0 = 32'h5EED0 + phase; t_p1 = 32'hFACE0 + phase;
            t_up = 0; t_ext = 0; t_rdy = (phase == 3) ? 3 : 0; t_cat = 98; t_reps = 1; t_flags = 0;
            use_sv_oracle = 1'b1;
            g_r0 = 0; g_c0 = 0; g_m = M; g_n = N;
            tile_r0 = 0; tile_c0 = 0; tile_m = M; tile_n = N;

            cfg_m <= M[MW-1:0]; cfg_n <= N[NW-1:0]; cfg_k <= K[KW-1:0]; cfg_valid <= 1'b1;
            hs = 1'b0;
            while (!hs) begin tick; if (smp_cfg_valid && smp_cfg_ready) hs = 1'b1; end
            cfg_valid <= 1'b0;
            kq = 0; fcyc = 0; wd = 0;
            drive_slice(0);
            // feed, stopping early for phase 1
            while (kq < K && !(phase == 1 && kq >= 12)) begin
                tick;
                if (smp_s_valid && smp_s_ready) kq = kq + 1;
                fcyc = fcyc + 1;
                drive_slice(kq);
            end
            if (phase >= 2) begin
                fin = 1'b0; wd = 0;
                while (!fin) begin
                    tick;
                    wd = wd + 1;
                    if (phase == 2 && dut.state_q == S_DRAIN && mon_step >= K + (ROWS + COLS) / 2 - 1) fin = 1'b1;   // mid-DRAIN (DRAIN is M+N+MP steps long)
                    if (phase == 3 && dut.state_q == S_READOUT) fin = 1'b1;
                    if (wd > 5000) begin main_fail("reset phase wait timeout", phase, 0); fin = 1'b1; end
                end
                if (phase == 3) begin tick; tick; end
            end
            // ---- yank reset with the array mid-operation
            s_valid <= 1'b0;
            do_reset(3);
            expect_clean_idle("reset");
            // follow-ups: different shapes must be exactly right (no residue of the aborted tile)
            run_internal(1, 1, 1, 32'h77, 32'h88, 20 + phase);
            run_internal(ROWS, COLS, 9, 32'hABCD0 + phase, 32'hDCBA0 + phase, 30 + phase);
            if (main_errs + mon_errs != errs_before) begin
                tests_fail = tests_fail + 1; $display("DIRECTED reset phase %0d FAIL", phase);
            end else begin
                tests_pass = tests_pass + 1; $display("DIRECTED reset phase %0d PASS", phase);
            end
        end
    endtask


    // ------------------------------------------------ directed: align_err latch/clear
    //  A one-cycle FORCE on the PE error bus simulates an alignment fault.  Expected:
    //  align_err latches, survives READOUT (sticky), results unaffected, and the next
    //  tile launch clears it.  (Skipped under Verilator: force on this net unsupported.)
    reg inj_arm = 1'b0;
    reg inj_fired = 1'b0;
`ifndef VERILATOR
    always @(posedge clk) begin
        if (inj_arm && !inj_fired && dut.state_q == S_DRAIN) begin
            inj_fired = 1'b1;
            #1 force dut.err_flat = {NPE{1'b1}};
            @(posedge clk);
            #1 release dut.err_flat;
        end
    end
`endif

    task automatic directed_align;
        integer errs_before, mm, nn;
        begin
`ifndef VERILATOR
            if (CHECK != 0) begin
                errs_before = main_errs + mon_errs;
                msgs = 0; mon_msgs = 0;
                mm = (ROWS < 2) ? ROWS : 2;  nn = (COLS < 2) ? COLS : 2;
                mon_allow_align = 1'b1; inj_fired = 1'b0; inj_arm = 1'b1;
                run_internal(mm, nn, 12, 32'h1234, 32'h4321, 60);
                inj_arm = 1'b0;
                if (align_err !== 1'b1) main_fail("align_err did not latch / not sticky through READOUT", align_err, 0);
                mon_allow_align = 1'b0;
                run_internal(mm, nn, 5, 32'h2222, 32'h3333, 61);      // launch must clear the latch
                if (align_err !== 1'b0) main_fail("align_err not cleared by next launch", align_err, 0);
                if (main_errs + mon_errs != errs_before) begin
                    tests_fail = tests_fail + 1; $display("DIRECTED align_err FAIL");
                end else begin
                    tests_pass = tests_pass + 1; $display("DIRECTED align_err PASS (latch, sticky, clear-on-launch)");
                end
            end
`endif
        end
    endtask

    // ----------------------------------------------------------------- driver
    integer ti;
    initial begin
        main_errs = 0; tests_pass = 0; tests_fail = 0; tiles_run = 0; perf_lines = 0; msgs = 0;
        t_tid = -1; t_M = 1; t_N = 1; t_K = 1; t_mode = 0; t_up = 0; t_ext = 0; t_rdy = 0;
        t_flags = 0; t_cat = 0; t_reps = 1; t_p0 = 0; t_p1 = 0; t_seed = 1;
        t_Abase = 0; t_Bbase = 0; t_Cbase = 0; use_sv_oracle = 0;
        tile_r0 = 0; tile_c0 = 0; tile_m = 1; tile_n = 1; g_m = 1; g_n = 1; g_r0 = 0; g_c0 = 0;

        if ($value$plusargs("MAXCYC=%d", max_cyc)) ;
        trace_en = $test$plusargs("TRACE");
        if ($value$plusargs("WAVE=%s", wavefile)) begin
            $dumpfile(wavefile);
            $dumpvars(0, tb_array);
        end
        if (!$value$plusargs("VEC=%s", vecfile)) begin
            $display("TB_FATAL: +VEC=<file> required");
            $finish;
        end
        $readmemh(vecfile, mem);
        ntests = mem[0];
        ptr = 1;
        $display("TB_INFO: ROWS=%0d COLS=%0d DW=%0d ACC=%0d KW=%0d MUL_PIPE=%0d CHECK=%0d tests=%0d",
                 ROWS, COLS, DW, ACC, KW, MUL_PIPE, CHECK, ntests);

        repeat (4) tick;
        rst_n <= 1'b1;
        repeat (3) tick;

        for (ti = 0; ti < ntests; ti = ti + 1) run_vector_test;

        if (!$test$plusargs("NODIRECTED")) begin
            directed_reject;
            directed_align;
            directed_reset(1);
            directed_reset(2);
            directed_reset(3);
        end

        repeat (4) tick;
        $display("TB_SUMMARY tests_pass=%0d tests_fail=%0d tiles=%0d main_errs=%0d monitor_errs=%0d",
                 tests_pass, tests_fail, tiles_run, main_errs, mon_errs);
        if (tests_fail == 0 && main_errs == 0 && mon_errs == 0 && tests_pass > 0)
            $display("TB_RESULT: PASS");
        else
            $display("TB_RESULT: FAIL");
        $finish;
    end

endmodule
