// =============================================================================
//  SilicaFlux TENSORCORE 02  --  tb_pe.sv
//  Unit test for the NEW tensor_pe.sv (the brief's tensor_pe.sv was not present).
//
//  Part 1  DIRECTED, with literal expected numbers (independent of any model):
//            forward latency, MAC latency (MUL_PIPE 0/1), done timing, freeze
//            (en = 0) hold, valid-gating of garbage data, signed arithmetic,
//            clr, alignment-checker positive and negative cases.
//  Part 2  RANDOM cycle-accurate comparison against a behavioural model
//          (random en / valid / data / last / k-index / clr / reset).
// =============================================================================
`timescale 1ns/1ps
module tb_pe #(
    parameter int DW       = 8,
    parameter int ACC      = 32,
    parameter int KW       = 8,
    parameter int MUL_PIPE = 0,
    parameter int CHECK    = 1,
    parameter int NCYC     = 200000
);
    reg clk = 0;
    always #5 clk = ~clk;
    reg rst_n = 0, clr = 0, en = 0, chk_en = 0;
    reg a_valid = 0, a_last = 0, b_valid = 0, b_last = 0;
    reg signed [DW-1:0] a_data = 0, b_data = 0;
    reg [KW-1:0] a_kidx = 0, b_kidx = 0;

    wire a_valid_o, a_last_o, b_valid_o, b_last_o;
    wire signed [DW-1:0] a_data_o, b_data_o;
    wire [KW-1:0] a_kidx_o, b_kidx_o;
    wire signed [ACC-1:0] acc_o;
    wire done_o, fire_o, commit_o, err_o;

    tensor_pe #(.DATA_WIDTH(DW), .ACC_WIDTH(ACC), .KIDX_WIDTH(KW),
                .MUL_PIPE(MUL_PIPE), .CHECK_ALIGN(CHECK)) dut (
        .clk(clk), .rst_n(rst_n), .clr(clr), .en(en), .chk_en(chk_en),
        .a_valid_i(a_valid), .a_last_i(a_last), .a_data_i(a_data), .a_kidx_i(a_kidx),
        .b_valid_i(b_valid), .b_last_i(b_last), .b_data_i(b_data), .b_kidx_i(b_kidx),
        .a_valid_o(a_valid_o), .a_last_o(a_last_o), .a_data_o(a_data_o), .a_kidx_o(a_kidx_o),
        .b_valid_o(b_valid_o), .b_last_o(b_last_o), .b_data_o(b_data_o), .b_kidx_o(b_kidx_o),
        .acc_o(acc_o), .done_o(done_o), .fire_o(fire_o), .commit_o(commit_o), .err_o(err_o));

    integer errs = 0, checks = 0;

    task automatic fail(input [8*56-1:0] what, input integer a, input integer b);
        begin
            errs = errs + 1;
            if (errs < 30) $display("PE_ERROR t=%0t: %0s (%0d, %0d)", $time, what, a, b);
        end
    endtask

    task automatic expect_eq(input [8*56-1:0] what, input integer got, input integer exp);
        begin
            checks = checks + 1;
            if (got !== exp) fail(what, got, exp);
        end
    endtask

    // Part-1 discipline: everything happens on the FALLING edge.  Inputs are set with
    // blocking assignments at a negedge, the rising edge in between consumes them, and
    // the task returns at the next negedge when the DUT outputs are settled.
    task automatic drive(input e, input av, input bv, input integer ad, input integer bd,
                         input al, input bl, input integer ak, input integer bk);
        begin
            en = e; a_valid = av; b_valid = bv; a_data = ad[DW-1:0]; b_data = bd[DW-1:0];
            a_last = al; b_last = bl; a_kidx = ak[KW-1:0]; b_kidx = bk[KW-1:0];
            @(negedge clk);
        end
    endtask

    task automatic idle(input e);
        begin drive(e, 0, 0, 0, 0, 0, 0, 0, 0); end
    endtask

    task automatic do_clr;
        begin clr = 1; en = 0; a_valid = 0; b_valid = 0; @(negedge clk); clr = 0; end
    endtask

    // ------------------------------------------------------------ behavioural model
    reg signed [ACC-1:0] m_acc;
    reg m_done, m_pv, m_pl;
    reg signed [2*DW-1:0] m_pp;
    reg m_av, m_al, m_bv, m_bl;
    reg signed [DW-1:0] m_ad, m_bd;
    reg [KW-1:0] m_ak, m_bk;
    integer cyc_n;
    reg exp_fire, exp_commit, exp_err;
    reg model_on;

    function automatic [ACC-1:0] wrap_acc(input integer v);
        begin wrap_acc = v[ACC-1:0]; end
    endfunction

    always @(posedge clk) begin : model
        reg fire;
        integer prod;
        if (model_on) begin
            // combinational expectations for THIS cycle (pre-edge)
            fire = a_valid & b_valid;
            exp_fire   = en & fire;
            exp_commit = en & ((MUL_PIPE == 0) ? fire : m_pv);
            exp_err    = en & (CHECK != 0) &
                         ((a_valid & b_valid & (a_kidx != b_kidx)) |
                          (a_valid & b_valid & (a_last != b_last)) |
                          (chk_en & (a_valid != b_valid)));
            if (fire_o !== exp_fire)     fail("fire_o mismatch", fire_o, exp_fire);
            if (commit_o !== exp_commit) fail("commit_o mismatch", commit_o, exp_commit);
            if (err_o !== exp_err)       fail("err_o mismatch", err_o, exp_err);
            if (acc_o !== m_acc)         fail("acc_o mismatch", acc_o, m_acc);
            if (done_o !== m_done)       fail("done_o mismatch", done_o, m_done);
            if (a_valid_o !== m_av || b_valid_o !== m_bv) fail("fwd valid mismatch", a_valid_o, m_av);
            if (a_data_o !== m_ad || b_data_o !== m_bd)   fail("fwd data mismatch", a_data_o, m_ad);
            if (a_last_o !== m_al || b_last_o !== m_bl)   fail("fwd last mismatch", a_last_o, m_al);
            if (a_kidx_o !== m_ak || b_kidx_o !== m_bk)   fail("fwd kidx mismatch", a_kidx_o, m_ak);
            checks = checks + 10;

            // advance model across this edge
            if (!rst_n || clr) begin
                m_acc = 0; m_done = 0; m_pv = 0; m_pl = 0; m_pp = 0;
                m_av = 0; m_al = 0; m_ad = 0; m_ak = 0; m_bv = 0; m_bl = 0; m_bd = 0; m_bk = 0;
            end else if (en) begin
                prod = a_data * b_data;          // signed integer product
                if (MUL_PIPE == 0) begin
                    if (fire) begin
                        m_acc = m_acc + prod;
                        if (a_last & b_last) m_done = 1;
                    end
                end else begin
                    if (m_pv) begin
                        m_acc = m_acc + m_pp;
                        if (m_pl) m_done = 1;
                    end
                    m_pv = fire;
                    m_pl = fire & a_last & b_last;
                    if (fire) m_pp = prod;
                end
                m_av = a_valid; m_al = a_last; m_ad = a_data; m_ak = a_kidx;
                m_bv = b_valid; m_bl = b_last; m_bd = b_data; m_bk = b_kidx;
            end
        end
    end

    // ---------------------------------------------------------------- main
    integer i, kk;
    reg [31:0] lf = 32'hC0DE1234;
    function automatic [31:0] xs(input [31:0] s);
        reg [31:0] x;
        begin x = s; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5); xs = x; end
    endfunction
    function automatic integer rnd_data(input [31:0] r);
        integer v;
        begin
            case (r[9:8])
                0: v = -(1 << (DW - 1));
                1: v = (1 << (DW - 1)) - 1;
                2: v = (r[7:0] % 3) - 1;                   // -1, 0, 1
                default: v = $signed(r[DW+15:16]);
            endcase
            rnd_data = v;
        end
    endfunction

    integer rd_a, rd_b;
    initial begin
        model_on = 0;
        m_acc = 0; m_done = 0; m_pv = 0; m_pl = 0; m_pp = 0;
        m_av = 0; m_al = 0; m_ad = 0; m_ak = 0; m_bv = 0; m_bl = 0; m_bd = 0; m_bk = 0;
        repeat (3) @(posedge clk);
        rst_n <= 1;
        @(negedge clk); @(negedge clk);

        if (DW >= 8 && ACC >= 20) begin
        // ============================ Part 1: directed ===========================
        // --- D1 forward latency + MAC latency + done timing ------------------------
        do_clr;
        drive(1, 1, 1, 3, 5, 1, 1, 0, 0);               // the edge after this consumes the token
        expect_eq("D1 fwd A valid after 1 en-cycle", a_valid_o, 1);
        expect_eq("D1 fwd A data after 1 en-cycle",  a_data_o, 3);
        expect_eq("D1 fwd B data after 1 en-cycle",  b_data_o, 5);
        if (MUL_PIPE == 0) begin
            expect_eq("D1 acc visible after 1 en-cycle (MP0)", acc_o, 15);
            expect_eq("D1 done with last (MP0)", done_o, 1);
        end else begin
            expect_eq("D1 acc NOT yet visible (MP1)", acc_o, 0);
            expect_eq("D1 done NOT yet (MP1)", done_o, 0);
        end
        idle(1);
        expect_eq("D1 acc after 2 en-cycles", acc_o, 15);
        expect_eq("D1 done after MAC latency", done_o, 1);
        expect_eq("D1 fwd valid drops after bubble", a_valid_o, 0);

        // --- D2 freeze holds EVERYTHING, MAC resumes exactly once -------------------
        do_clr;
        drive(1, 1, 1, -7, 9, 0, 0, 0, 0);              // k=0 : -63
        drive(0, 1, 1, 100, 100, 1, 1, 1, 1);           // k=1 token presented but en=0 (frozen)
        drive(0, 1, 1, 100, 100, 1, 1, 1, 1);
        drive(0, 1, 1, 100, 100, 1, 1, 1, 1);
        if (MUL_PIPE == 0) expect_eq("D2 acc held during freeze", acc_o, -63);
        else               expect_eq("D2 acc held during freeze (MP1: product pending)", acc_o, 0);
        expect_eq("D2 not done during freeze", done_o, 0);
        expect_eq("D2 fwd data held", a_data_o, -7);
        drive(1, 1, 1, 100, 100, 1, 1, 1, 1);           // en=1: consumed exactly once now
        idle(1); idle(1);
        expect_eq("D2 acc = -63 + 10000", acc_o, 9937);
        expect_eq("D2 done after last", done_o, 1);

        // --- D3 invalid tokens never accumulate, even with garbage data --------------
        do_clr;
        drive(1, 1, 0, 77, 99, 1, 1, 0, 0);             // only A valid
        drive(1, 0, 1, 55, 66, 1, 1, 0, 0);             // only B valid
        drive(1, 0, 0, 12, 34, 1, 1, 0, 0);             // neither valid
        idle(1); idle(1);
        expect_eq("D3 acc unchanged by invalid tokens", acc_o, 0);
        expect_eq("D3 done not set by invalid last", done_o, 0);

        // --- D4 signed extremes ------------------------------------------------------
        do_clr;
        drive(1, 1, 1, -(1 << (DW - 1)), -(1 << (DW - 1)), 0, 0, 0, 0);
        drive(1, 1, 1, -(1 << (DW - 1)), (1 << (DW - 1)) - 1, 1, 1, 1, 1);
        idle(1); idle(1);
        expect_eq("D4 signed extremes", acc_o,
                  (1 << (2 * DW - 2)) + (-(1 << (DW - 1)) * ((1 << (DW - 1)) - 1)));

        // --- D5 clr clears accumulator, done, forwarding and the in-flight product -----
        drive(1, 1, 1, 5, 5, 1, 1, 0, 0);
        do_clr;
        expect_eq("D5 acc cleared", acc_o, 0);
        expect_eq("D5 done cleared", done_o, 0);
        expect_eq("D5 fwd valid cleared", a_valid_o, 0);
        idle(1); idle(1);
        expect_eq("D5 no ghost MAC after clr", acc_o, 0);
        end

        // --- D6 alignment checker: combinational err_o probes between clock edges ------
        do_clr;
        chk_en = 1; en = 1; a_valid = 1; b_valid = 1; a_kidx = 4; b_kidx = 4; a_last = 0; b_last = 0; #1;
        expect_eq("D6 matched tokens -> no err", err_o, 0);
        a_kidx = 3; #1;
        expect_eq("D6 k-index mismatch flagged", err_o, (CHECK != 0));
        a_kidx = 5; b_kidx = 5; a_last = 1; b_last = 0; #1;
        expect_eq("D6 last-tag mismatch flagged", err_o, (CHECK != 0));
        a_last = 0; b_valid = 0; #1;
        expect_eq("D6 missing B token in active region flagged", err_o, (CHECK != 0));
        chk_en = 0; #1;
        expect_eq("D6 one-sided valid OUTSIDE active region legal (padding)", err_o, 0);
        chk_en = 1; a_valid = 0; b_valid = 0; #1;
        expect_eq("D6 both idle -> no err", err_o, 0);
        a_valid = 1; b_valid = 1; a_kidx = 9; b_kidx = 8; en = 0; #1;
        expect_eq("D6 no err event while frozen", err_o, 0);
        en = 0; a_valid = 0; b_valid = 0; chk_en = 0;
        @(negedge clk);
        @(posedge clk);

        // ============================ Part 2: random vs model ======================
        do_clr;
        rst_n <= 0; @(posedge clk); @(posedge clk); rst_n <= 1; @(posedge clk);
        m_acc = 0; m_done = 0; m_pv = 0; m_pl = 0; m_pp = 0;
        m_av = 0; m_al = 0; m_ad = 0; m_ak = 0; m_bv = 0; m_bl = 0; m_bd = 0; m_bk = 0;
        model_on = 1;
        for (cyc_n = 0; cyc_n < NCYC; cyc_n = cyc_n + 1) begin
            lf = xs(lf);
            en      <= (lf[3:0] > 4'd2);                                   // ~81% enabled
            clr     <= (lf[15:8] == 8'h5A);
            rst_n   <= !(lf[27:20] == 8'hA7);
            chk_en  <= lf[16];
            a_valid <= (cyc_n % 4096 < 2048) ? lf[17] : (lf[18] | lf[19] | lf[20]);
            b_valid <= (cyc_n % 4096 < 2048) ? lf[21] : (lf[22] | lf[23] | lf[24]);
            a_last  <= (lf[31:28] == 4'd3);
            b_last  <= (lf[31:28] == 4'd3) ^ (lf[7:4] == 4'd9);
            a_kidx  <= {5'd0, lf[2:0]};
            b_kidx  <= (lf[19:16] == 4'd1) ? {5'd0, lf[10:8]} : {5'd0, lf[2:0]};   // mostly matching
            lf = xs(lf);
            rd_a = rnd_data(lf);
            lf = xs(lf);
            rd_b = rnd_data(lf);
            a_data  <= rd_a[DW-1:0];
            b_data  <= rd_b[DW-1:0];
            @(posedge clk);
        end
        model_on = 0;
        @(posedge clk);

        $display("PE_SUMMARY DW=%0d ACC=%0d MUL_PIPE=%0d CHECK=%0d checks=%0d errs=%0d",
                 DW, ACC, MUL_PIPE, CHECK, checks, errs);
        if (errs == 0) $display("PE_RESULT: PASS"); else $display("PE_RESULT: FAIL");
        $finish;
    end
endmodule
