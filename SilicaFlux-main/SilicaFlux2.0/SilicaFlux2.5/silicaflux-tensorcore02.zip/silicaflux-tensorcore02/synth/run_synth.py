#!/usr/bin/env python3
"""
TENSORCORE 02 -- Yosys synthesis reports.

Targets
  * Xilinx 7-series (yosys synth_xilinx -family xc7): LUT / FF / CARRY4 / DSP48E1 counts.
  * Generic gate-level (synth + abc): technology-independent cell counts.

LIMITS (stated in every report): this is Yosys technology mapping ONLY.  There is no
place-and-route and no static timing analysis in this environment, so NO Fmax or
timing-closure claim is made.  Resource counts exclude I/O buffers (-noiopad).
Vivado may map the same RTL differently (especially DSP packing).
"""
import os, re, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = "rtl/tensor_pe.sv rtl/tensor_skew.sv rtl/tensor_output_collect.sv rtl/tensor_systolic_array.sv"

# name, rows, cols, MUL_PIPE, CHECK_ALIGN, PERF_EN, nodsp, tag
CONFIGS = [
    ("2x2",            2, 2, 0, 0, 0, False),
    ("4x4",            4, 4, 0, 0, 0, False),
    ("8x8",            8, 8, 0, 0, 0, False),
    ("16x16",         16, 16, 0, 0, 0, False),
    ("2x2_mp1",        2, 2, 1, 0, 0, False),
    ("4x4_mp1",        4, 4, 1, 0, 0, False),
    ("8x8_mp1",        8, 8, 1, 0, 0, False),
    ("16x16_mp1",     16, 16, 1, 0, 0, False),
    ("4x4_instr",      4, 4, 0, 1, 1, False),   # CHECK_ALIGN + PERF counters on
    ("4x4_nodsp",      4, 4, 0, 0, 0, True),    # multipliers in fabric
]


def run(cmd, log):
    t0 = time.time()
    r = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True)
    open(os.path.join(ROOT, log), "w").write(r.stdout + r.stderr)
    return r.returncode, time.time() - t0


def parse_stat(path):
    txt = open(os.path.join(ROOT, path)).read()
    # last "Number of cells" block = whole design (flattened)
    blk = txt[txt.rindex("Number of cells"):]
    cells = {}
    for m in re.finditer(r"^\s+(\$?\w+)\s+(\d+)\s*$", blk, re.M):
        cells[m.group(1)] = int(m.group(2))
    return cells


def summarise(cells):
    lut = sum(v for k, v in cells.items() if re.fullmatch(r"LUT[1-6]", k))
    ff = sum(v for k, v in cells.items() if k.startswith("FD"))
    return dict(LUT=lut, FF=ff, CARRY4=cells.get("CARRY4", 0), DSP48E1=cells.get("DSP48E1", 0),
                MUXF7=cells.get("MUXF7", 0), MUXF8=cells.get("MUXF8", 0),
                LUTRAM_SRL=sum(v for k, v in cells.items() if k.startswith(("RAM", "SRL"))))


def main():
    summary_only = "--summary-only" in sys.argv
    only = set(a for a in sys.argv[1:] if not a.startswith("--"))
    os.makedirs(os.path.join(ROOT, "synth/reports"), exist_ok=True)
    rows = []
    for name, R, C, mp, ck, pf, nodsp in CONFIGS:
        if only and name not in only:
            continue
        stat = f"synth/reports/stat_xc7_{name}.txt"
        ys = f"synth/reports/xc7_{name}.ys"
        if not summary_only: open(os.path.join(ROOT, ys), "w").write(f"""read_verilog -sv {SRC}
chparam -set ARRAY_ROWS {R} -set ARRAY_COLS {C} -set MUL_PIPE {mp} -set CHECK_ALIGN {ck} -set PERF_EN {pf} tensor_systolic_array
hierarchy -check -top tensor_systolic_array
synth_xilinx -family xc7 -top tensor_systolic_array -flatten -noiopad {'-nodsp' if nodsp else ''}
tee -o {stat} stat
""")
        if summary_only:
            rc, dt = 0, 0.0
        else:
            rc, dt = run(f"yosys -q -l synth/reports/xc7_{name}.log {ys}", f"synth/reports/xc7_{name}.stdout")
        if rc != 0 or not os.path.exists(os.path.join(ROOT, stat)):
            print(f"{name}: YOSYS FAILED"); rows.append((name, R, C, mp, ck, pf, nodsp, None, dt)); continue
        s = summarise(parse_stat(stat))
        rows.append((name, R, C, mp, ck, pf, nodsp, s, dt))
        print(f"{name:10s} LUT={s['LUT']:6d} FF={s['FF']:6d} DSP48E1={s['DSP48E1']:4d} CARRY4={s['CARRY4']:5d}  ({dt:.0f}s)", flush=True)

    # hierarchical breakdown for the 4x4 baseline
    hier = "synth/reports/stat_xc7_4x4_hier.txt"
    if not summary_only: open(os.path.join(ROOT, "synth/reports/xc7_4x4_hier.ys"), "w").write(f"""read_verilog -sv {SRC}
chparam -set ARRAY_ROWS 4 -set ARRAY_COLS 4 -set CHECK_ALIGN 0 -set PERF_EN 0 tensor_systolic_array
hierarchy -check -top tensor_systolic_array
synth_xilinx -family xc7 -top tensor_systolic_array -noiopad
tee -o {hier} stat
""")
    if (not only or "4x4" in only) and not summary_only:
        run("yosys -q -l synth/reports/xc7_4x4_hier.log synth/reports/xc7_4x4_hier.ys", "synth/reports/xc7_4x4_hier.stdout")

    # generic (technology independent) 4x4
    gen = "synth/reports/stat_generic_4x4.txt"
    if not summary_only: open(os.path.join(ROOT, "synth/reports/generic_4x4.ys"), "w").write(f"""read_verilog -sv {SRC}
chparam -set ARRAY_ROWS 4 -set ARRAY_COLS 4 -set CHECK_ALIGN 0 -set PERF_EN 0 tensor_systolic_array
hierarchy -check -top tensor_systolic_array
synth -flatten -top tensor_systolic_array
abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX
opt_clean
tee -o {gen} stat
""")
    if (not only or "4x4" in only) and not summary_only:
        run("yosys -q -l synth/reports/generic_4x4.log synth/reports/generic_4x4.ys", "synth/reports/generic_4x4.stdout")

    with open(os.path.join(ROOT, "reports/synthesis_summary.md"), "w") as f:
        f.write("# TENSORCORE 02 -- Synthesis summary (Yosys, Xilinx 7-series mapping)\n\n")
        f.write("**Scope and limits.** Technology mapping by Yosys 0.33 `synth_xilinx -family xc7 -flatten -noiopad`. "
                "No place-and-route, no static timing: **no Fmax or timing-closure claim is made.** "
                "Counts exclude I/O buffers. Vivado may map differently (DSP packing in particular).\n\n")
        f.write("| config | array | MUL_PIPE | CHECK_ALIGN | PERF_EN | DSP | LUT | FF | CARRY4 | MUXF7/8 | note |\n|---|---|---|---|---|---|---|---|---|---|---|\n")
        for (name, R, C, mp, ck, pf, nodsp, s, dt) in rows:
            if s is None:
                f.write(f"| {name} | {R}x{C} | {mp} | {ck} | {pf} | NOT COMPLETED in this session | | | | | |\n"); continue
            note = "multipliers in fabric (-nodsp)" if nodsp else ""
            f.write(f"| {name} | {R}x{C} | {mp} | {ck} | {pf} | {s['DSP48E1']} | {s['LUT']} | {s['FF']} | {s['CARRY4']} | "
                    f"{s['MUXF7']}/{s['MUXF8']} | {note} |\n")
    print("wrote reports/synthesis_summary.md")


if __name__ == "__main__":
    sys.exit(main())
