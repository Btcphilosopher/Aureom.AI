# Waveform examples

Each scenario was simulated (Icarus, `+WAVE`), required to PASS the full self-checking testbench, and rendered from the VCD by `tools/vcd_tools.py` (no GUI viewer needed). Open the `.vcd` in GTKWave/Surfer if you prefer; the `.svg` is self-contained.

| scenario | what it shows | files |
|---|---|---|
| 2x2_K3 | Stage-1 example. 2×2, K=3, textbook matrices; RTL gives C = [[58,64],[139,154]]. | `2x2_K3.vcd`, `2x2_K3.svg`, `2x2_K3_wavefront.txt` |
| 4x4_K4 | 4×4 baseline, full tile, K=4 with negative operands (K < M+N−1: never all PEs busy). | `4x4_K4.vcd`, `4x4_K4.svg`, `4x4_K4_wavefront.txt` |
| 4x4_K10_steady | 4×4, K=10 — exactly 4 cycles with all 16 PEs committing (= K−6). | `4x4_K10_steady.vcd`, `4x4_K10_steady.svg`, `4x4_K10_steady_wavefront.txt` |
| 4x4_partial_3x2_K5 | Partial tile M=3, N=2 on the 4×4 array: padded lanes, inactive PEs never fire. | `4x4_partial_3x2_K5.vcd`, `4x4_partial_3x2_K5.svg`, `4x4_partial_3x2_K5_wavefront.txt` |
| 4x4_K4_stalls | Same 4×4 K=4 tile with periodic global stall, upstream gaps and slow readout: the wavefront freezes and resumes. | `4x4_K4_stalls.vcd`, `4x4_K4_stalls.svg`, `4x4_K4_stalls_wavefront.txt` |
| 2x2_K3_mulpipe1 | 2×2 K=3 with MUL_PIPE=1: every commit one enabled cycle later; busy +1. | `2x2_K3_mulpipe1.vcd`, `2x2_K3_mulpipe1.svg`, `2x2_K3_mulpipe1_wavefront.txt` |

Regenerate with `make waves`.

## Reading the waveforms

* Time axis is the clock cycle (value *during* the cycle, i.e. sampled just before the edge).
* `pipe_en` is the global enable; flat stretches while `s_ready`/`pipe_en` are low are the freeze.
* `fire PE(i,j)` is the strobe in which both operand tokens are consumed; `acc PE(i,j)` shows the running partial sum. Check by hand: in `2x2_K3`, PE(0,0): 0 → 7 → 25 → 58 = 1·7 + 2·9 + 3·11.
* `all_done` is only meaningful during DRAIN (it is trivially high when no PE is active, e.g. in IDLE).

## Concurrency (derived from the VCD, asserted at build time)

```
Concurrency histogram from waves/4x4_K10_steady.vcd (4x4 array, M=N=4, K=10)
simultaneous MAC commits in a cycle -> number of cycles
   0 -> 20
   1 -> 2
   3 -> 2
   6 -> 2
  10 -> 2
  13 -> 2
  15 -> 2
  16 -> 4
all-16-PE cycles = 4  (expected K-(M+N-2) = 4)   total MACs = 160 (expected M*N*K = 160)
```

## Wavefront grids derived from the VCD

### 2×2, K=3 (`2x2_K3_wavefront.txt`)

```
Legend: number = reduction index k whose A[i][k] x B[k][j] product is accumulated by PE(i,j) in that cycle ('.' = no MAC).  Cycles in which the global enable is low are marked FROZEN (nothing moves).

cycle   9  RUN     en=1
    |  .   .  |
    |  .   .  |
cycle  10  RUN     en=1
    |  0   .  |
    |  .   .  |
cycle  11  RUN     en=1
    |  1   0  |
    |  0   .  |
cycle  12  DRAIN   en=1
    |  2   1  |
    |  1   0  |
cycle  13  DRAIN   en=1
    |  .   2  |
    |  2   1  |
cycle  14  DRAIN   en=1
    |  .   .  |
    |  .   2  |
cycle  15  DRAIN   en=1
    |  .   .  |
    |  .   .  |

(k-index sideband mismatches vs. fire order: 0)
```

PE(0,0) starts first, PE(0,1)/PE(1,0) one cycle later, PE(1,1) one more; PE(1,1) commits k=2 at step K+M+N−2 = 5.

### 4×4, K=4 (`4x4_K4_wavefront.txt`)

```
Legend: number = reduction index k whose A[i][k] x B[k][j] product is accumulated by PE(i,j) in that cycle ('.' = no MAC).  Cycles in which the global enable is low are marked FROZEN (nothing moves).

cycle   9  RUN     en=1
    |  .   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   .  |
cycle  10  RUN     en=1
    |  0   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   .  |
cycle  11  RUN     en=1
    |  1   0   .   .  |
    |  0   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   .  |
cycle  12  RUN     en=1
    |  2   1   0   .  |
    |  1   0   .   .  |
    |  0   .   .   .  |
    |  .   .   .   .  |
cycle  13  DRAIN   en=1
    |  3   2   1   0  |
    |  2   1   0   .  |
    |  1   0   .   .  |
    |  0   .   .   .  |
cycle  14  DRAIN   en=1
    |  .   3   2   1  |
    |  3   2   1   0  |
    |  2   1   0   .  |
    |  1   0   .   .  |
cycle  15  DRAIN   en=1
    |  .   .   3   2  |
    |  .   3   2   1  |
    |  3   2   1   0  |
    |  2   1   0   .  |
cycle  16  DRAIN   en=1
    |  .   .   .   3  |
    |  .   .   3   2  |
    |  .   3   2   1  |
    |  3   2   1   0  |
cycle  17  DRAIN   en=1
    |  .   .   .   .  |
    |  .   .   .   3  |
    |  .   .   3   2  |
    |  .   3   2   1  |
cycle  18  DRAIN   en=1
    |  .   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   3  |
    |  .   .   3   2  |
cycle  19  DRAIN   en=1
    |  .   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   .  |
    |  .   .   .   3  |
cycle  20  DRAIN   en=1
    |  .   .   .   .  |
    |  .   .   .   .  |
```

