#!/usr/bin/env python3
"""
TENSORCORE 02 -- RTL mutation testing.

Every mutant is a one-site textual change applied to a COPY of the RTL (the
replaced text must occur exactly once).  A mutant is KILLED if the PE unit test
or the array testbench (2x2 MUL_PIPE=0 and 3x2 MUL_PIPE=1) reports anything other
than PASS, hangs, or fails to elaborate its checks.  Survivors are listed with
an explanation (equivalent mutant vs. test gap).

Usage:  tools/mutation_test.py [--only m07,m12] [--out reports/mutation_report.md]
"""
import argparse, json, os, re, shutil, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["tensor_pe.sv", "tensor_skew.sv", "tensor_output_collect.sv", "tensor_systolic_array.sv"]
BUILD = os.path.join(ROOT, "build", "mut")

# (id, file, old, new, description, hint)   hint: "equiv" = expected to be result-equivalent
MUTANTS = [
 ("m01", "tensor_pe.sv", "assign fire_c = a_valid_i & b_valid_i;", "assign fire_c = a_valid_i;",
  "PE accumulates when only the A token is valid", ""),
 ("m02", "tensor_pe.sv", "assign fire_c = a_valid_i & b_valid_i;", "assign fire_c = 1'b1;",
  "PE ignores token valid entirely (relies on zero data)", "result-equivalent: caught only by wavefront monitor"),
 ("m03", "tensor_pe.sv", "acc_q <= acc_q + mac_prod_ext;", "acc_q <= acc_q - mac_prod_ext;",
  "accumulator subtracts", ""),
 ("m04", "tensor_pe.sv", "assign mac_prod_ext = ACC_WIDTH'($signed(mac_prod_c));",
  "assign mac_prod_ext = {{(ACC_WIDTH-2*DATA_WIDTH){1'b0}}, mac_prod_c};",
  "product ZERO-extended instead of sign-extended", ""),
 ("m05", "tensor_pe.sv", "assign prod_c = a_data_i * b_data_i;",
  "assign prod_c = $unsigned(a_data_i) * $unsigned(b_data_i);",
  "unsigned multiply", ""),
 ("m06", "tensor_pe.sv", "if (mac_last_c) done_q <= 1'b1;", "done_q <= 1'b1;",
  "done raised on first MAC instead of the last-tagged MAC", ""),
 ("m07", "tensor_pe.sv", "end else if (en) begin\n            // operand forwarding", "end else begin\n            // operand forwarding",
  "PE ignores the global enable (advances during stall)", ""),
 ("m08", "tensor_pe.sv", "            done_q      <= 1'b0;\n            prod_q", "            prod_q",
  "done flag not cleared at tile launch / reset", ""),
 ("m09", "tensor_pe.sv", "(a_kidx_i != b_kidx_i);", "(a_kidx_i == b_kidx_i);",
  "alignment checker: k-index compare inverted", ""),
 ("m10", "tensor_pe.sv", "assign err_c      = (CHECK_ALIGN != 0) &", "assign err_c      = 1'b0 &",
  "alignment checker permanently disabled", "caught by tb_pe directed D6 only"),
 ("m11", "tensor_pe.sv", "prod_last_q <= fire_c & a_last_i & b_last_i;", "prod_last_q <= 1'b0;",
  "MUL_PIPE=1: last tag lost in product stage", "needs MUL_PIPE=1"),
 ("m12", "tensor_pe.sv", "mac_last_c = prod_last_q;", "mac_last_c = a_last_i & b_last_i;",
  "MUL_PIPE=1: done taken from input stage (1 cycle early)", "needs MUL_PIPE=1"),
 ("m13", "tensor_pe.sv", "assign commit_o = en & mac_c;", "assign commit_o = mac_c;",
  "commit event not qualified by en", ""),
 ("m14", "tensor_pe.sv", "b_valid_o <= b_valid_i;", "b_valid_o <= b_valid_i & ~b_last_i;",
  "B forwarding drops the last token's valid", ""),
 ("m15", "tensor_pe.sv", "if (fire_c) prod_q <= prod_c;", "prod_q <= prod_c;",
  "MUL_PIPE=1: product register updated even without valid (benign)", "equiv"),

 ("m16", "tensor_pe.sv", "            a_valid_o   <= 1'b0;\n            a_last_o    <= 1'b0;", "            a_valid_o   <= clr ? a_valid_o : 1'b0;\n            a_last_o    <= 1'b0;",
  "PE clr does not flush stale forwarded A tokens (stragglers survive launch)", "straggler flush is NOT redundant"),

 ("m20", "tensor_skew.sv", "localparam int D = BASE + l;", "localparam int D = BASE + ((l > 1) ? l + 1 : l);",
  "skew depth off by one on lanes >= 2", "needs >= 3 lanes"),
 ("m21", "tensor_skew.sv", "end else if (en) begin\n                        sr[0]", "end else begin\n                        sr[0]",
  "skew network ignores the global enable", ""),
 ("m22", "tensor_skew.sv", "if (!rst_n || clr) begin\n                        for", "if (!rst_n) begin\n                        for",
  "skew network not flushed at tile launch", "may be equivalent: stale tokens are dead by construction"),
 ("m23", "tensor_skew.sv", "assign out_flat[l*WIDTH +: WIDTH] = sr[D-1];", "assign out_flat[l*WIDTH +: WIDTH] = sr[0];",
  "skew taps first stage (no skew at all)", ""),

 ("m30", "tensor_output_collect.sv", "assign all_done = ~(|pending);", "assign all_done = ~(&pending);",
  "completion when ANY active PE is done", ""),
 ("m31", "tensor_output_collect.sv", "acc_flat[(32'(rd_row)*ARRAY_COLS + j)*ACC_WIDTH +: ACC_WIDTH]",
  "acc_flat[(((32'(rd_row)+1)%ARRAY_ROWS)*ARRAY_COLS + j)*ACC_WIDTH +: ACC_WIDTH]",
  "readout mux selects the wrong row", ""),
 ("m32", "tensor_output_collect.sv", "row_mask[i] & col_mask[j] & ~done_flat[i*ARRAY_COLS + j];",
  "row_mask[i] & col_mask[j] & ~done_flat[0];",
  "completion looks only at PE(0,0)", ""),
 ("m33", "tensor_output_collect.sv", "col_mask[j]\n                ?", "1'b1\n                ?",
  "readout does not mask columns outside N", "equiv: inactive PEs hold zero (defence in depth)"),

 ("m40", "tensor_systolic_array.sv", "row_mask_q[i] <= (32'(cfg_m) > i);", "row_mask_q[i] <= (32'(cfg_m) >= i);",
  "row mask one row too wide", ""),
 ("m41", "tensor_systolic_array.sv", "col_mask_q[j] <= (32'(cfg_n) > j);", "col_mask_q[j] <= (32'(cfg_n) > j+1);",
  "column mask one column too narrow", ""),
 ("m42", "tensor_systolic_array.sv", "live ? s_a[i*DATA_WIDTH +: DATA_WIDTH]  : {DATA_WIDTH{1'b0}},", "s_a[i*DATA_WIDTH +: DATA_WIDTH],",
  "A lanes not zero-padded", "result-equivalent: valid still gates the MAC"),
 ("m43", "tensor_systolic_array.sv", "live ? s_b[j*DATA_WIDTH +: DATA_WIDTH]  : {DATA_WIDTH{1'b0}},", "s_b[j*DATA_WIDTH +: DATA_WIDTH],",
  "B lanes not zero-padded", "result-equivalent: valid still gates the MAC"),
 ("m44", "tensor_systolic_array.sv", "assign live = s_go & row_mask_q[i];", "assign live = s_go;",
  "A rows beyond M injected as valid (padding not masked)", "result-equivalent for output rows < M"),
 ("m45", "tensor_systolic_array.sv", "assign live = s_go & col_mask_q[j];", "assign live = s_go;",
  "B columns beyond N injected as valid (padding not masked)", "result-equivalent for output cols < N"),
 ("m46", "tensor_systolic_array.sv", "assign k_last    = (k_cnt_q == (k_len_q - K_WIDTH'(1)));", "assign k_last    = (k_cnt_q == k_len_q);",
  "last tag one slice late", ""),
 ("m47", "tensor_systolic_array.sv", "((state_q == S_RUN) ? s_valid : (state_q == S_DRAIN))", "((state_q == S_RUN) ? 1'b1 : (state_q == S_DRAIN))",
  "array advances in RUN even when no slice is valid", ""),
 ("m48", "tensor_systolic_array.sv", "assign pipe_en   = ~stall_i & (", "assign pipe_en   = 1'b1 & (",
  "global enable ignores stall_i", ""),
 ("m49", "tensor_systolic_array.sv", "assign s_ready   = (state_q == S_RUN) & ~stall_i;", "assign s_ready   = (state_q == S_RUN);",
  "slice accepted while stalled (dropped/duplicated operand)", ""),
 ("m50", "tensor_systolic_array.sv", "if (s_go) k_cnt_q <= k_cnt_q + K_WIDTH'(1);", "if (s_valid && state_q == S_RUN) k_cnt_q <= k_cnt_q + K_WIDTH'(1);",
  "k counter advances on s_valid instead of the handshake", ""),
 ("m51", "tensor_systolic_array.sv", "assign cfg_legal = (cfg_m != '0) && (32'(cfg_m) <= ARRAY_ROWS) &&", "assign cfg_legal = (32'(cfg_m) <= ARRAY_ROWS) &&",
  "M = 0 accepted", ""),
 ("m52", "tensor_systolic_array.sv", "(cfg_k != '0);", "1'b1;",
  "K = 0 accepted", ""),
 ("m53", "tensor_systolic_array.sv", "assign m_last    = (32'(rd_row_q) == 32'(m_q) - 1);", "assign m_last    = (32'(rd_row_q) == 32'(m_q));",
  "m_last one row late", ""),
 ("m54", "tensor_systolic_array.sv", "assign clr_c     = (state_q == S_CLEAR);", "assign clr_c     = 1'b0;",
  "tile-launch clear removed", ""),
 ("m55", "tensor_systolic_array.sv", "S_DRAIN:   if (all_done)                     state_d = S_READOUT;", "S_DRAIN:   if (1'b1)                         state_d = S_READOUT;",
  "tile completion without waiting for the wavefront to drain", ""),
 ("m56", "tensor_systolic_array.sv", "mac_q <= mac_q + PERF_W'(popc);", "mac_q <= mac_q + PERF_W'(popc) + PERF_W'(1);",
  "useful-MAC counter over-counts", ""),
 ("m57", "tensor_systolic_array.sv", "pad_q   <= pad_q + PERF_W'(pad_slots_c);", "pad_q   <= pad_q + PERF_W'(pad_slots_c + 1);",
  "padding-slot counter over-counts", ""),
 ("m58", "tensor_systolic_array.sv", "if (!rst_n || clr_c)  align_err_q <= 1'b0;", "if (!rst_n)  align_err_q <= 1'b0;",
  "align_err not cleared at tile launch", "equivalent under legal traffic (no error ever latches)"),
 ("m59", "tensor_systolic_array.sv", "tensor_skew #(.LANES(ARRAY_COLS), .WIDTH(TW), .BASE(1)) u_skew_b", "tensor_skew #(.LANES(ARRAY_COLS), .WIDTH(TW), .BASE(2)) u_skew_b",
  "B skew one stage too deep (A/B misaligned by 1)", "expects RTL align_err to fire"),
 ("m60", "tensor_systolic_array.sv", "tensor_skew #(.LANES(ARRAY_ROWS), .WIDTH(TW), .BASE(1)) u_skew_a", "tensor_skew #(.LANES(ARRAY_ROWS), .WIDTH(TW), .BASE(0)) u_skew_a",
  "A skew one stage too shallow (A/B misaligned by 1)", "expects RTL align_err to fire"),
 ("m61", "tensor_systolic_array.sv", "live ? k_cnt_q                          : {K_WIDTH{1'b0}},\n                live ? s_a", "{K_WIDTH{1'b0}},\n                live ? s_a",
  "A k-index metadata lost (data path untouched)", "result-equivalent: only the checker/sideband sees it"),
 ("m62", "tensor_systolic_array.sv", "assign tile_done = (state_q == S_READOUT);", "assign tile_done = (state_q == S_READOUT) | (state_q == S_DRAIN);",
  "tile_done asserted during DRAIN", ""),
]

CONFIGS = [  # name, rows, cols, mul_pipe
    ("2x2_mp0", 2, 2, 0),
    ("3x2_mp1", 3, 2, 1),
]


def sh(cmd, timeout=120, cwd=ROOT):
    try:
        r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout + r.stderr
    except subprocess.TimeoutExpired as e:
        return 124, (e.stdout or "") + "\nTIMEOUT"


def build_run(mdir, files, rows, cols, mp, vec):
    exe = os.path.join(mdir, f"tb_{rows}x{cols}_{mp}.vvp")
    rc, out = sh(f"iverilog -g2012 -s tb_array -Ptb_array.ROWS={rows} -Ptb_array.COLS={cols} "
                 f"-Ptb_array.MUL_PIPE={mp} -o {exe} {' '.join(files)} tb/tb_array.sv")
    if rc != 0:
        return "COMPILE_ERROR", out.strip().splitlines()[:3]
    rc, out = sh(f"vvp -n {exe} +VEC={vec} +MAXCYC=300000", timeout=150)
    if rc == 124:
        return "TIMEOUT", ["simulation timeout"]
    res = re.search(r"TB_RESULT: (\w+)", out)
    if not res:
        return "NO_RESULT", out.strip().splitlines()[-3:]
    if res.group(1) == "PASS":
        return "PASS", []
    errs = [l for l in out.splitlines() if re.search(r"MONITOR_ERROR|TB_ERROR", l)]
    return "FAIL", errs[:4]


def pe_run(mdir, files, mp):
    exe = os.path.join(mdir, f"pe_{mp}.vvp")
    rc, out = sh(f"iverilog -g2012 -s tb_pe -Ptb_pe.MUL_PIPE={mp} -Ptb_pe.NCYC=20000 -o {exe} {files[0]} tb/tb_pe.sv")
    if rc != 0:
        return "COMPILE_ERROR", out.strip().splitlines()[:3]
    rc, out = sh(f"vvp -n {exe}", timeout=60)
    if rc == 124:
        return "TIMEOUT", []
    res = re.search(r"PE_RESULT: (\w+)", out)
    if res and res.group(1) == "PASS":
        return "PASS", []
    return "FAIL", [l for l in out.splitlines() if "PE_ERROR" in l][:3]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--out", default="reports/mutation_report.md")
    a = ap.parse_args()
    only = set(filter(None, a.only.split(",")))

    # vectors for the two mutation configs (level 0 keeps the loop fast)
    for name, r, c, mp in CONFIGS:
        sh(f"python3 tools/gen_vectors.py --rows {r} --cols {c} --level 0 --out vectors/v_mut_{r}x{c}.hex")

    results = []
    # baseline sanity: unmutated design must PASS everything
    todo = [("m00", None, None, None, "UNMUTATED BASELINE", "")] + [m for m in MUTANTS if not only or m[0] in only]
    t0 = time.time()
    for mid, fname, old, new, desc, hint in todo:
        mdir = os.path.join(BUILD, mid)
        shutil.rmtree(mdir, ignore_errors=True)
        os.makedirs(mdir)
        files = []
        for f in RTL:
            src = os.path.join(ROOT, "rtl", f)
            dst = os.path.join(mdir, f)
            txt = open(src).read()
            if f == fname:
                n = txt.count(old)
                if n != 1:
                    print(f"{mid}: PATTERN MATCHED {n} TIMES in {f} -- fix mutant definition", file=sys.stderr)
                    results.append(dict(id=mid, desc=desc, hint=hint, status="BAD_MUTANT", detail=[f"pattern x{n}"]))
                    break
                txt = txt.replace(old, new)
            open(dst, "w").write(txt)
            files.append(os.path.relpath(dst, ROOT))
        else:
            verdicts = []
            for mp in (0, 1):
                verdicts.append(("PE mp%d" % mp,) + pe_run(mdir, files, mp))
            for name, r, c, mp in CONFIGS:
                verdicts.append((name,) + build_run(mdir, files, r, c, mp, f"vectors/v_mut_{r}x{c}.hex"))
            failing = [v for v in verdicts if v[1] != "PASS"]
            if mid == "m00":
                status = "BASELINE_OK" if not failing else "BASELINE_BROKEN"
            else:
                status = "KILLED" if failing else "SURVIVED"
            detail = []
            for v in failing:
                detail.append(f"{v[0]}: {v[1]} -- {(v[2][0] if v[2] else '').strip()[:140]}")
            rtl_checker = any("align_err asserted" in d for d in detail)
            results.append(dict(id=mid, desc=desc, hint=hint, status=status, detail=detail,
                                killers=[v[0] for v in failing], rtl_checker_fired=rtl_checker))
            print(f"{mid:4s} {status:9s} {desc}   [{', '.join(v[0] for v in failing) or '-'}]", flush=True)
    dt = time.time() - t0

    killed = [r for r in results if r["status"] == "KILLED"]
    surv = [r for r in results if r["status"] == "SURVIVED"]
    bad = [r for r in results if r["status"] in ("BAD_MUTANT", "BASELINE_BROKEN")]
    with open(os.path.join(ROOT, a.out), "w") as f:
        f.write("# TENSORCORE 02 -- Mutation test report\n\n")
        f.write(f"Mutants: {len(killed)+len(surv)}   **killed: {len(killed)}**   survived: {len(surv)}   "
                f"invalid: {len(bad)}   (wall time {dt:.0f} s)\n\n")
        f.write("Detectors: PE unit test (MUL_PIPE 0/1) and array TB on 2x2 MUL_PIPE=0 and 3x2 MUL_PIPE=1 "
                "(level-0 vectors + directed reject/reset).\n\n")
        f.write("| id | status | mutation | killed by | first detector message |\n|---|---|---|---|---|\n")
        for r in results:
            first = (r["detail"][0] if r["detail"] else "").replace("|", "/")
            f.write(f"| {r['id']} | {r['status']} | {r['desc']} | {', '.join(r.get('killers', []))} | {first[:150]} |\n")
        if surv:
            f.write("\n## Survivors\n\n")
            for r in surv:
                f.write(f"- **{r['id']}** {r['desc']} -- hint: {r['hint'] or 'none'}\n")
    json.dump(results, open(os.path.join(ROOT, "reports", "mutation_results.json"), "w"), indent=1)
    print(f"\nkilled {len(killed)} / survived {len(surv)} / invalid {len(bad)}  ({dt:.0f}s)")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
