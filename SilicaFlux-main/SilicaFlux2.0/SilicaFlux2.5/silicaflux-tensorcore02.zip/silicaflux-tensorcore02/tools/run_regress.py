#!/usr/bin/env python3
"""
TENSORCORE 02 -- regression driver.

For every configuration: generate numpy-oracle vectors, build + run the array
testbench on Icarus and/or Verilator, parse TB_SUMMARY/TB_RESULT, collect PERF
lines, and (when both simulators ran) require the logs to agree line-for-line.
Also runs the PE unit test over a width/latency matrix.

  tools/run_regress.py [--only name,name] [--skip-verilator] [--quick]
"""
import argparse, csv, os, re, subprocess, sys, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/tensor_pe.sv", "rtl/tensor_skew.sv", "rtl/tensor_output_collect.sv", "rtl/tensor_systolic_array.sv"]

# name, R, C, DW, ACC, KW, MP, CHECK, PERF, level, sims
J = lambda n, r, c, dw=8, acc=32, kw=17, mp=0, ck=1, pf=1, lv=1, sims=("icarus", "verilator"): \
    dict(name=n, R=r, C=c, DW=dw, ACC=acc, KW=kw, MP=mp, CHECK=ck, PERF=pf, level=lv, sims=sims)

JOBS = [
    # ---- stage 1 / stage 2 (as specified: 2x2 first, then the 4x4 baseline)
    J("2x2_L1", 2, 2),
    J("4x4_L2", 4, 4, lv=2),
    # ---- shape coverage
    J("1x1_L1", 1, 1, sims=("icarus",)),
    J("1x4_L1", 1, 4, sims=("icarus",)),
    J("4x1_L1", 4, 1, sims=("icarus",)),
    J("2x4_L1", 2, 4, sims=("icarus",)),
    J("4x2_L1", 4, 2, sims=("icarus",)),
    J("3x5_L1", 3, 5, sims=("icarus", "verilator")),
    J("5x3_L1", 5, 3, sims=("icarus",)),
    # ---- PE multiplier pipeline stage
    J("2x2_MP1_L1", 2, 2, mp=1),
    J("4x4_MP1_L1", 4, 4, mp=1),
    J("3x5_MP1_L1", 3, 5, mp=1, sims=("icarus",)),
    # ---- widths / wraparound
    J("4x4_DW8_ACC16", 4, 4, dw=8, acc=16, sims=("icarus",)),
    J("4x4_DW8_ACC24", 4, 4, dw=8, acc=24, sims=("icarus",)),
    J("4x4_DW4_ACC16", 4, 4, dw=4, acc=16, sims=("icarus",)),
    J("4x4_DW12_ACC32", 4, 4, dw=12, acc=32, sims=("icarus",)),
    J("3x3_DW16_ACC32", 3, 3, dw=16, acc=32, sims=("icarus",)),
    # ---- optional features off / K width
    J("4x4_NOCHECK", 4, 4, ck=0, sims=("icarus",)),
    J("4x4_NOPERF", 4, 4, pf=0, sims=("icarus",)),
    J("4x4_KW8", 4, 4, kw=8, lv=1, sims=("icarus",)),
    J("2x2_KW18_L2", 2, 2, kw=18, lv=2, sims=("verilator",)),
    # ---- research configurations
    J("8x8_L1", 8, 8, sims=("verilator",)),
    J("8x8_MP1_L0", 8, 8, mp=1, lv=0, sims=("verilator",)),
    J("16x16_L1", 16, 16, sims=("verilator",)),
]

PE_JOBS = [(8, 32, 0, 1), (8, 32, 1, 1), (8, 32, 0, 0), (8, 32, 1, 0), (4, 8, 0, 1), (4, 8, 1, 1),
           (8, 16, 0, 1), (8, 16, 1, 1), (12, 32, 1, 1), (16, 32, 0, 1), (2, 4, 0, 1)]


def sh(cmd, timeout=3600):
    t0 = time.time()
    try:
        r = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout + r.stderr, time.time() - t0
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT", time.time() - t0


def params(j):
    return dict(ROWS=j["R"], COLS=j["C"], DW=j["DW"], ACC=j["ACC"], KW=j["KW"], MUL_PIPE=j["MP"],
                CHECK=j["CHECK"], PERF=j["PERF"])


def run_job(j, sims_allowed):
    n = j["name"]
    vec = f"vectors/v_{n}.hex"
    rc, out, _ = sh(f"python3 tools/gen_vectors.py --rows {j['R']} --cols {j['C']} --dw {j['DW']} "
                    f"--acc {j['ACC']} --kw {j['KW']} --level {j['level']} --out {vec}")
    if rc != 0:
        return [dict(name=n, sim="gen", status="GEN_FAIL", detail=out[-300:])]
    ntests = int(re.search(r"(\d+) tests", out).group(1))
    res, logs = [], {}
    for sim in j["sims"]:
        if sim not in sims_allowed:
            continue
        P = params(j)
        log = f"logs/reg_{n}_{sim}.log"
        if sim == "icarus":
            exe = f"build/reg_{n}.vvp"
            pf = " ".join(f"-Ptb_array.{k}={v}" for k, v in P.items())
            rc, out, tb = sh(f"iverilog -g2012 -s tb_array {pf} -o {exe} {' '.join(RTL)} tb/tb_array.sv")
            if rc != 0:
                res.append(dict(name=n, sim=sim, status="BUILD_FAIL", detail=out[-300:]))
                continue
            rc, out, tr = sh(f"vvp -n {exe} +VEC={vec} > {log} 2>&1")
        else:
            mdir = f"build/vl_{n}"
            gf = " ".join(f"-G{k}={v}" for k, v in P.items())
            rc, out, tb = sh(f"verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module tb_array "
                             f"{gf} -Mdir {mdir} -o tb_vl {' '.join(RTL)} tb/tb_array.sv")
            if rc != 0:
                res.append(dict(name=n, sim=sim, status="BUILD_FAIL", detail=out[-400:]))
                continue
            rc, out, tr = sh(f"{mdir}/tb_vl +VEC={vec} > {log} 2>&1")
        txt = open(os.path.join(ROOT, log)).read()
        logs[sim] = txt
        m = re.search(r"TB_SUMMARY.*?tests_pass=(\d+) tests_fail=(\d+)(?: tiles=(\d+))?", txt)
        ok = "TB_RESULT: PASS" in txt
        res.append(dict(name=n, sim=sim, status="PASS" if ok else "FAIL",
                        passed=int(m.group(1)) if m else 0, failed=int(m.group(2)) if m else -1,
                        tiles=int(m.group(3)) if m and m.group(3) else 0, vec_tests=ntests,
                        build_s=tb, run_s=tr, params=j))
    # cross-simulator agreement on every vector-test line + its cycle counts
    if "icarus" in logs and "verilator" in logs:
        def core(t):
            lines = t.splitlines()
            cut = next((i for i, l in enumerate(lines) if l.startswith("DIRECTED")), len(lines))
            return [l for l in lines[:cut] if l.startswith(("TEST", "PERF"))]
        a, b = core(logs["icarus"]), core(logs["verilator"])
        agree = (a == b)
        for r in res:
            r["xsim"] = f"identical ({len(a)} lines)" if agree else f"DIFFER ({len(a)} vs {len(b)})"
    # PERF csv (stall-free tiles only), one per config from the first simulator that ran
    first = next(iter(logs.values()), "")
    rows = [l.split(",")[1:] for l in first.splitlines() if l.startswith("PERF,")]
    with open(os.path.join(ROOT, f"reports/perf_{n}.csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["R", "C", "M", "N", "K", "busy", "issue", "stall_up", "stall_ext", "macs", "pad_slots",
                    "ext_prof", "up_prof", "mul_pipe"])
        w.writerows(rows)
    return res


def run_pe():
    out_rows = []
    for dw, acc, mp, ck in PE_JOBS:
        exe = f"build/pe_{dw}_{acc}_{mp}_{ck}.vvp"
        rc, o, _ = sh(f"iverilog -g2012 -s tb_pe -Ptb_pe.DW={dw} -Ptb_pe.ACC={acc} -Ptb_pe.MUL_PIPE={mp} "
                      f"-Ptb_pe.CHECK={ck} -o {exe} rtl/tensor_pe.sv tb/tb_pe.sv")
        if rc != 0:
            out_rows.append((dw, acc, mp, ck, "BUILD_FAIL", 0, 0)); continue
        rc, o, _ = sh(f"vvp -n {exe}")
        m = re.search(r"checks=(\d+) errs=(\d+)", o)
        ok = "PE_RESULT: PASS" in o
        out_rows.append((dw, acc, mp, ck, "PASS" if ok else "FAIL", int(m.group(1)) if m else 0,
                         int(m.group(2)) if m else -1))
        print(f"PE DW={dw} ACC={acc} MP={mp} CHECK={ck}: {out_rows[-1][4]}", flush=True)
    return out_rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--only", default="")
    ap.add_argument("--skip-verilator", action="store_true")
    ap.add_argument("--skip-pe", action="store_true")
    ap.add_argument("--out", default="reports/regression_summary.md")
    a = ap.parse_args()
    for d in ("build", "logs", "reports", "vectors"):          # a fresh unpack has no build/ directory
        os.makedirs(os.path.join(ROOT, d), exist_ok=True)
    only = set(filter(None, a.only.split(",")))
    sims = {"icarus"} if a.skip_verilator else {"icarus", "verilator"}
    rows, t0 = [], time.time()
    for j in JOBS:
        if only and j["name"] not in only:
            continue
        for r in run_job(j, sims):
            rows.append(r)
            print(f"{r['name']:18s} {r['sim']:9s} {r['status']:10s} pass={r.get('passed','-')} fail={r.get('failed','-')} "
                  f"tiles={r.get('tiles','-')} run={r.get('run_s',0):.0f}s {r.get('xsim','')}", flush=True)
    pe = [] if a.skip_pe else run_pe()
    bad = [r for r in rows if r["status"] != "PASS"] + [p for p in pe if p[4] != "PASS"]
    with open(os.path.join(ROOT, a.out), "w") as f:
        f.write("# TENSORCORE 02 -- Regression summary\n\n")
        f.write(f"Total wall time {time.time()-t0:.0f} s.  Overall: **{'PASS' if not bad else 'FAIL'}**\n\n")
        f.write("| config | R x C | DW/ACC/KW | MUL_PIPE | CHECK/PERF | vector tests | simulator | result | tests passed (incl. directed) | tiles | cross-sim |\n")
        f.write("|---|---|---|---|---|---|---|---|---|---|---|\n")
        for r in rows:
            p = r.get("params", {})
            f.write(f"| {r['name']} | {p.get('R','')}x{p.get('C','')} | {p.get('DW','')}/{p.get('ACC','')}/{p.get('KW','')} | "
                    f"{p.get('MP','')} | {p.get('CHECK','')}/{p.get('PERF','')} | {r.get('vec_tests','')} | {r['sim']} | "
                    f"{r['status']} | {r.get('passed','')} | {r.get('tiles','')} | {r.get('xsim','-')} |\n")
        if pe:
            f.write("\n## PE unit test (tb/tb_pe.sv)\n\n| DATA_WIDTH | ACC_WIDTH | MUL_PIPE | CHECK_ALIGN | result | checks | errors |\n|---|---|---|---|---|---|---|\n")
            for p in pe:
                f.write(f"| {p[0]} | {p[1]} | {p[2]} | {p[3]} | {p[4]} | {p[5]} | {p[6]} |\n")
    print(f"\nOVERALL: {'PASS' if not bad else 'FAIL'}  ({time.time()-t0:.0f}s)")
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())
