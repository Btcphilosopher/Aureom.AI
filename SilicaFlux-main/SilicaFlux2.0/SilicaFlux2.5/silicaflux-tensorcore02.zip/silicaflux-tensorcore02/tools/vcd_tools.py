#!/usr/bin/env python3
"""
TENSORCORE 02 -- VCD post-processing (no GUI viewer required).

  vcd_tools.py --vcd waves/x.vcd --rows 4 --cols 4 --svg waves/x.svg --txt waves/x_wavefront.txt

* Parses the VCD produced by the testbench (Icarus / Verilator).
* Samples every signal just BEFORE each rising clock edge ("value during cycle n"),
  exactly the value the logic sees at that edge.
* --txt : per-cycle wavefront grids (which PE fires / holds which reduction index k),
          derived from the physical fire_flat / commit_flat / done_flat nets in the VCD.
          The k label of each fire is cross-checked against the k-index sideband
          (a_kidx_bus) captured in the same VCD.
* --svg : self-contained SVG waveform (clock, FSM state, handshakes, stall, global
          enable, per-PE fire strobes, per-PE accumulators, completion, readout).
"""
import argparse
import bisect
import sys

STATE_NAMES = {0: "IDLE", 1: "CLEAR", 2: "RUN", 3: "DRAIN", 4: "READOUT"}


class VCD:
    def __init__(self, path):
        self.width = {}
        self.names = {}          # full name -> id code
        self.changes = {}        # id -> ([times], [values])
        self.end_time = 0
        self._parse(path)

    def _parse(self, path):
        scopes = []
        idcode_widths = {}
        t = 0
        in_defs = True
        with open(path) as f:
            toks = f.read().split()
        i = 0
        n = len(toks)
        while i < n:
            tk = toks[i]
            if in_defs:
                if tk == "$scope":
                    scopes.append(toks[i + 2])
                    i += 4
                    continue
                if tk == "$upscope":
                    scopes.pop()
                    i += 2
                    continue
                if tk == "$var":
                    width = int(toks[i + 2])
                    code = toks[i + 3]
                    name = toks[i + 4]
                    full = ".".join(scopes + [name])
                    self.names[full] = code
                    idcode_widths[code] = width
                    self.changes.setdefault(code, ([], []))
                    j = i + 5
                    while toks[j] != "$end":
                        j += 1
                    i = j + 1
                    continue
                if tk == "$enddefinitions":
                    in_defs = False
                    while toks[i] != "$end":
                        i += 1
                    i += 1
                    continue
                i += 1
                continue
            # value-change section
            if tk.startswith("#"):
                t = int(tk[1:])
                self.end_time = max(self.end_time, t)
                i += 1
            elif tk in ("$dumpvars", "$dumpall", "$dumpon", "$dumpoff", "$end"):
                i += 1
            elif tk[0] in "01xXzZ" and len(tk) > 1:
                self._add(tk[1:], t, tk[0])
                i += 1
            elif tk[0] in "bB":
                self._add(toks[i + 1], t, tk[1:])
                i += 2
            elif tk[0] in "rR":
                i += 2
            else:
                i += 1
        self.width = idcode_widths

    def _add(self, code, t, val):
        ts, vs = self.changes.setdefault(code, ([], []))
        ts.append(t)
        vs.append(val)

    def find(self, suffix):
        for k in self.names:
            if k.endswith(suffix):
                return k
        raise KeyError(suffix)

    def value_at(self, full, t):
        code = self.names[full]
        ts, vs = self.changes[code]
        idx = bisect.bisect_right(ts, t) - 1
        if idx < 0:
            return "x" * self.width[code]
        v = vs[idx]
        w = self.width[code]
        if len(v) < w:
            pad = "0" if v[0] in "01" else v[0]
            v = pad * (w - len(v)) + v
        return v


def to_int(bits, signed=False):
    if any(c in "xXzZ" for c in bits):
        return None
    v = int(bits, 2)
    if signed and bits[0] == "1":
        v -= 1 << len(bits)
    return v


def bit_slice(bits, lo, width):
    """bits is MSB-first string; return slice [lo+width-1:lo] MSB-first."""
    n = len(bits)
    return bits[n - lo - width: n - lo]


def rising_edges(vcd, clk_name):
    ts, vs = vcd.changes[vcd.names[clk_name]]
    return [t for t, v in zip(ts, vs) if v == "1" and t > 0]


class Run:
    def __init__(self, vcd, scope, clk, rows, cols, acc):
        self.v, self.rows, self.cols, self.acc = vcd, rows, cols, acc
        self.sc = scope
        self.clk = clk
        self.edges = rising_edges(vcd, clk)

    def sig(self, name, n):
        """value of DUT signal `name` during cycle n (just before edge n)."""
        return self.v.value_at(f"{self.sc}.{name}", self.edges[n] - 1)

    def ncycles(self):
        return len(self.edges)


def wavefront_text(run, c0, c1):
    rows, cols, acc = run.rows, run.cols, run.acc
    npe = rows * cols
    out = []
    seen = {}                       # (i,j) -> fires so far
    out.append("Legend: number = reduction index k whose A[i][k] x B[k][j] product is accumulated by "
               "PE(i,j) in that cycle ('.' = no MAC).  Cycles in which the global enable is low are "
               "marked FROZEN (nothing moves).\n")
    mism = 0
    for n in range(c0, min(c1, run.ncycles())):
        st = to_int(run.sig("state_q", n))
        en = run.sig("pipe_en", n)
        fire = run.sig("fire_flat", n)
        commit = run.sig("commit_flat", n)
        kid = run.sig("a_kidx_bus", n)
        kw = run.v.width[run.v.names[f"{run.sc}.a_kidx_bus"]] // (rows * (cols + 1))
        grid = []
        for i in range(rows):
            line = []
            for j in range(cols):
                idx = i * cols + j
                f = bit_slice(fire, idx, 1) == "1"
                c = bit_slice(commit, idx, 1) == "1"
                if f or c:
                    k = seen.get((i, j), 0)
                    if c:
                        seen[(i, j)] = k + 1
                    ai = i * (cols + 1) + j
                    kv = to_int(bit_slice(kid, ai * kw, kw))
                    tag = f"{k:>2}"
                    if f and kv is not None and kv != k:
                        mism += 1
                        tag = f"{k}!"
                    line.append(tag + ("*" if (c and not f) else " "))
                else:
                    line.append(" . ")
            grid.append(" ".join(line))
        sname = STATE_NAMES.get(st, "?")
        flag = "" if en == "1" else ("  FROZEN" if st in (2, 3) else "")
        if all(g.strip().replace(".", "").strip() == "" for g in grid) and st not in (2, 3):
            continue
        out.append(f"cycle {n:3d}  {sname:<7s} en={en}{flag}")
        for g in grid:
            out.append("    | " + g + " |")
    out.append(f"\n(k-index sideband mismatches vs. fire order: {mism})")
    return "\n".join(out) + "\n"


def svg_waveform(run, c0, c1, title):
    rows, cols, acc = run.rows, run.cols, run.acc
    c1 = min(c1, run.ncycles())
    ncyc = c1 - c0
    cw = 26 if ncyc <= 40 else 18
    left, top, rh = 210, 40, 22
    sigs = []                                    # (label, kind, getter)

    def g_flat(name, idx, width, signed=False):
        return lambda n: to_int(bit_slice(run.sig(name, n), idx * width, width), signed)

    def g_bit(name):
        return lambda n: to_int(run.sig(name, n))

    sigs.append(("state", "state", lambda n: to_int(run.sig("state_q", n))))
    sigs.append(("cfg_valid", "bit", g_bit("cfg_valid")))
    sigs.append(("s_valid", "bit", g_bit("s_valid")))
    sigs.append(("s_ready", "bit", g_bit("s_ready")))
    sigs.append(("s_k", "dec", g_bit("s_k")))
    sigs.append(("stall_i", "bit", g_bit("stall_i")))
    sigs.append(("pipe_en (global enable)", "bit", g_bit("pipe_en")))
    for i in range(rows):
        for j in range(cols):
            sigs.append((f"fire PE({i},{j})", "bit", g_flat("fire_flat", i * cols + j, 1)))
    for i in range(rows):
        for j in range(cols):
            sigs.append((f"acc  PE({i},{j})", "sdec", g_flat("acc_flat", i * cols + j, acc, True)))
    sigs.append(("all_done", "bit", g_bit("all_done")))
    sigs.append(("tile_done", "bit", g_bit("tile_done")))
    sigs.append(("m_valid", "bit", g_bit("m_valid")))
    sigs.append(("m_ready", "bit", g_bit("m_ready")))
    sigs.append(("m_row", "dec", g_bit("m_row")))

    H = top + rh * (len(sigs) + 1) + 30
    W = max(left + cw * ncyc + 20, 8 * len(title) + 30)      # never clip the title
    o = []
    o.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
             f'font-family="monospace" font-size="11">')
    o.append(f'<rect width="{W}" height="{H}" fill="#ffffff"/>')
    o.append(f'<text x="8" y="18" font-size="13" font-weight="bold">{title}</text>')
    # cycle grid + header
    for n in range(ncyc + 1):
        x = left + n * cw
        o.append(f'<line x1="{x}" y1="{top - 6}" x2="{x}" y2="{H - 24}" stroke="#e6e6e6"/>')
        if n < ncyc and (n % 2 == 0 or cw >= 26):
            o.append(f'<text x="{x + 2}" y="{top - 10}" fill="#777">{c0 + n}</text>')
    o.append(f'<text x="8" y="{top - 10}" fill="#777">cycle</text>')
    colors = {"state": "#8e5bb5", "bit": "#1f6fb2", "dec": "#2a8a4a", "sdec": "#b25b1f"}
    for r, (label, kind, get) in enumerate(sigs):
        y = top + r * rh + rh // 2
        o.append(f'<text x="8" y="{y + 4}">{label}</text>')
        vals = [get(c0 + n) for n in range(ncyc)]
        col = colors[kind]
        if kind == "bit":
            pts = []
            for n, v in enumerate(vals):
                yy = y - 6 if v == 1 else y + 6
                x0, x1 = left + n * cw, left + (n + 1) * cw
                pts.append((x0, yy))
                pts.append((x1, yy))
            d = "M" + " L".join(f"{x},{yy}" for x, yy in pts)
            o.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="1.6"/>')
            # vertical edges
            for n in range(1, ncyc):
                if vals[n] != vals[n - 1]:
                    x = left + n * cw
                    o.append(f'<line x1="{x}" y1="{y - 6}" x2="{x}" y2="{y + 6}" stroke="{col}" stroke-width="1.6"/>')
        else:
            n = 0
            while n < ncyc:
                m = n
                while m + 1 < ncyc and vals[m + 1] == vals[n]:
                    m += 1
                x0, x1 = left + n * cw + 1, left + (m + 1) * cw - 1
                v = vals[n]
                if kind == "state":
                    txt = STATE_NAMES.get(v, "?")
                else:
                    txt = "x" if v is None else str(v)
                o.append(f'<rect x="{x0}" y="{y - 8}" width="{x1 - x0}" height="16" rx="3" '
                         f'fill="{col}" fill-opacity="0.12" stroke="{col}"/>')
                fits = (x1 - x0) >= 7 * len(txt)
                if fits:
                    o.append(f'<text x="{(x0 + x1) / 2}" y="{y + 4}" text-anchor="middle" fill="#222">{txt}</text>')
                n = m + 1
    o.append("</svg>")
    return "\n".join(o)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--vcd", required=True)
    ap.add_argument("--scope", default="tb_array.dut")
    ap.add_argument("--clk", default="tb_array.clk")
    ap.add_argument("--rows", type=int, required=True)
    ap.add_argument("--cols", type=int, required=True)
    ap.add_argument("--acc", type=int, default=32)
    ap.add_argument("--c0", type=int, default=0)
    ap.add_argument("--c1", type=int, default=10 ** 9)
    ap.add_argument("--svg")
    ap.add_argument("--txt")
    ap.add_argument("--title", default="TENSORCORE 02")
    a = ap.parse_args()
    vcd = VCD(a.vcd)
    run = Run(vcd, a.scope, a.clk, a.rows, a.cols, a.acc)
    # trim to the active window if the caller did not pick one
    if a.c1 == 10 ** 9:
        first = next((n for n in range(run.ncycles()) if to_int(run.sig("state_q", n)) not in (0, None)), 0)
        last = max((n for n in range(run.ncycles()) if to_int(run.sig("state_q", n)) not in (0, None)), default=0)
        a.c0 = max(first - 1, 0)
        a.c1 = min(last + 3, run.ncycles())
    if a.txt:
        open(a.txt, "w").write(wavefront_text(run, a.c0, a.c1))
    if a.svg:
        open(a.svg, "w").write(svg_waveform(run, a.c0, a.c1, a.title))
    print(f"{a.vcd}: {run.ncycles()} cycles, window {a.c0}..{a.c1}")


if __name__ == "__main__":
    sys.exit(main())
