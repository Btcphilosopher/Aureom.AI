#!/usr/bin/env python3
"""
TENSORCORE 02 -- finalise the deliverable.

1. GATE: refuses to package unless the final pipeline finished, the regression is PASS and the
   mutation baseline is intact (use --force to override; the override is printed in the README).
2. Generates docs/PERFORMANCE.md, docs/VERIFICATION.md, docs/SYNTHESIS.md, waves/README.md, README.md
   and MANIFEST.txt -- every number is read from the result files, none typed by hand.
3. Builds the zip, runs `unzip -t`, unpacks it elsewhere and runs `make smoke` + lint on the copy.
"""
import json, os, re, shutil, subprocess, sys, zipfile, hashlib, glob

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NAME = "silicaflux-tensorcore02"
OUT = "/mnt/user-data/outputs"
FORCE = "--force" in sys.argv


def rd(p):
    return open(os.path.join(ROOT, p)).read()


def wr(p, s):
    open(os.path.join(ROOT, p), "w").write(s)


def sh(cmd, cwd=ROOT, timeout=900):
    r = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout)
    return r.returncode, r.stdout + r.stderr


def fail(msg):
    print("GATE FAILED:", msg)
    if not FORCE:
        sys.exit(1)


# ------------------------------------------------------------------ 1. gate
# (a marker file is only a proxy; check the real conditions instead)
if "OVERALL: PASS" not in rd("logs/final_regress.log"):
    fail("logs/final_regress.log does not end in OVERALL: PASS")
if "killed" not in rd("logs/final_mutation.log"):
    fail("final mutation run did not complete")
if not os.path.exists(os.path.join(ROOT, "reports/synthesis_summary.md")):
    fail("no reports/synthesis_summary.md (run: python3 synth/run_synth.py --summary-only)")
reg = rd("reports/regression_summary.md")
reg_ok = "Overall: **PASS**" in reg
if not reg_ok:
    fail("regression is not PASS:\n" + "\n".join(l for l in rd("logs/final_regress.log").splitlines()
                                               if ("FAIL" in l or "GEN_FAIL" in l or "BUILD" in l)))
mut = json.load(open(os.path.join(ROOT, "reports/mutation_results.json")))
base = [m for m in mut if m["id"] == "m00"]
if not base or base[0]["status"] != "BASELINE_OK":
    fail("mutation baseline broken")
killed = [m for m in mut if m["status"] == "KILLED"]
surv = [m for m in mut if m["status"] == "SURVIVED"]
bad = [m for m in mut if m["status"] in ("BAD_MUTANT", "BASELINE_BROKEN")]
if bad:
    fail("invalid mutants: " + ", ".join(m["id"] for m in bad))
SURV_WHY = {
    "m15": "equivalent: with MUL_PIPE=1 the product register may load garbage when no operand is valid, but its commit is gated by `prod_vld_q`",
    "m22": "redundant: by the time `all_done` fires the skew network holds only all-zero bubbles (the last token has traversed <= M lane stages and DRAIN lasts M+N+MUL_PIPE steps), so the launch flush changes nothing; kept as defence",
    "m33": "equivalent: inactive PEs hold zero (cleared at launch, never accumulate), so masking unread columns changes no output; kept as defence in depth",
}
unexplained = [m["id"] for m in surv if m["id"] not in SURV_WHY]
if unexplained:
    fail("survivors without an explanation (possible test gap): " + ", ".join(unexplained))

# ------------------------------------------------------------------ 2. docs
# ---- concurrency artifact, derived from the VCD and ASSERTED (backs the K-(M+N-2) claim)
sys.path.insert(0, os.path.join(ROOT, "tools"))
import vcd_tools as vt, collections
_v = vt.VCD(os.path.join(ROOT, "waves/4x4_K10_steady.vcd"))
_run = vt.Run(_v, "tb_array.dut", "tb_array.clk", 4, 4, 32)
_hist = collections.Counter(_run.sig("commit_flat", n).count("1") for n in range(_run.ncycles()))
_macs = sum(k * n for k, n in _hist.items())
_K, _M, _N = 10, 4, 4
assert _hist[16] == _K - (_M + _N - 2), f"full-concurrency cycles {_hist[16]} != K-(M+N-2)"
assert _macs == _M * _N * _K, "total commits != M*N*K"
conc_txt = ("Concurrency histogram from waves/4x4_K10_steady.vcd (4x4 array, M=N=4, K=10)\n"
            "simultaneous MAC commits in a cycle -> number of cycles\n"
            + "\n".join(f"  {k:2d} -> {n}" for k, n in sorted(_hist.items()))
            + f"\nall-16-PE cycles = {_hist[16]}  (expected K-(M+N-2) = {_K-(_M+_N-2)})   total MACs = {_macs} (expected M*N*K = {_M*_N*_K})\n")
wr("waves/4x4_K10_steady_concurrency.txt", conc_txt)
sh("python3 tools/build_perf_report.py")

# lint matrix
lint_cfgs = [("1x1", "-GARRAY_ROWS=1 -GARRAY_COLS=1"), ("1x4", "-GARRAY_ROWS=1 -GARRAY_COLS=4"),
             ("2x2", "-GARRAY_ROWS=2 -GARRAY_COLS=2"), ("4x4 (baseline)", ""), ("3x5", "-GARRAY_ROWS=3 -GARRAY_COLS=5"),
             ("8x8", "-GARRAY_ROWS=8 -GARRAY_COLS=8"), ("16x16", "-GARRAY_ROWS=16 -GARRAY_COLS=16"),
             ("4x4 MUL_PIPE=1", "-GMUL_PIPE=1"), ("4x4 CHECK_ALIGN=0 PERF_EN=0", "-GCHECK_ALIGN=0 -GPERF_EN=0"),
             ("4x4 DW=4 ACC=8", "-GDATA_WIDTH=4 -GACC_WIDTH=8"), ("4x4 DW=16 ACC=32 K_WIDTH=8", "-GDATA_WIDTH=16 -GACC_WIDTH=32 -GK_WIDTH=8")]
RTLF = "rtl/tensor_pe.sv rtl/tensor_skew.sv rtl/tensor_output_collect.sv rtl/tensor_systolic_array.sv"
lint_rows = []
for n, g in lint_cfgs:
    rc, o = sh(f"verilator --lint-only -Wall --top-module tensor_systolic_array {g} {RTLF}")
    lint_rows.append((n, rc == 0 and "%Warning" not in o))
lint_all = all(ok for _, ok in lint_rows)

reg_body = reg.split("\n", 2)[2] if reg.count("\n") > 2 else reg
mut_head = [l for l in rd("reports/mutation_report.md").splitlines() if l.startswith("Mutants:")][0]
mut_table = "\n".join(l for l in rd("reports/mutation_report.md").splitlines() if l.startswith("|"))

ver = f"""# Verification — TENSORCORE 02

## 1. Strategy (independent layers)

| layer | what it is | independent of |
|---|---|---|
| **Numpy GEMM oracle** | `tools/gen_vectors.py` computes every expected C in exact int64 and wraps to `ACC_WIDTH` | RTL and SystemVerilog |
| **In-testbench SV oracle** | a signed-integer triple-loop GEMM recomputed from the operand sources; cross-checks the numpy vectors (`ORACLE MISMATCH` otherwise) | the numpy code |
| **Wavefront monitor** | per PE, every enabled cycle: token validity, operand *data* vs `A[i][k]`/`B[k][j]` at the ideal k, `last` tag, k-index, fire/commit step, done flag == (commits == K); freeze invariance; exactly K commits per PE; accumulators == expected *at the first `tile_done` cycle* and stable during READOUT | the RTL's own checker and k-index sideband |
| **Directed tests** | illegal-config rejection, reset during RUN / DRAIN / READOUT, `align_err` latch/sticky/clear (fault injected with `force`) | — |
| **PE unit test** | literal-number directed checks (latency, freeze, valid gating, extremes, `clr`, checker) + 200 000-cycle random comparison with a behavioural model, over 11 width/latency/checker combinations | the array |
| **Two simulators** | Icarus 12 and Verilator 5.020 run the same testbench; vector-test lines, including every cycle count, are required to be identical | each other |
| **Mutation testing** | {len(killed) + len(surv)} injected RTL bugs; see §5 | — |
| **Lint** | `verilator --lint-only -Wall` over {len(lint_rows)} parameter combinations | — |

Testbench discipline: all TB-driven inputs change by non-blocking assignment at a clock edge; the main flow reads only edge-sampled registers after `@(posedge clk); #1`; shared variables have exactly one writer. (A race in an earlier version made Verilator miss handshakes; it was found *because* both simulators were run, and fixed.)

## 2. Brief §9 coverage map

| requirement | where it is tested |
|---|---|
| 1×1 matrix multiplication | category `m1x1` (9 tests: signs, zeros, extremes) on every configuration, incl. a 1×1 array |
| 4×4 output tiles | every `ksweep`/`random`/`negative`/`identity`/`stall` test on the 4×4 baseline |
| K = 1, 3, 4, 7, 16, 257 | category `ksweep`: each K × six tile shapes ((R,C), (1,1), (R,1), (1,C), (R−1,C−1), (2,3)) |
| partial rows and columns | category `partial`: **every** (M,N) with 1≤M≤ROWS, 1≤N≤COLS (e.g. all 256 on 16×16) + multi-tile `gemm` with partial edge tiles |
| negative operands | `negative` (all sign-extreme combinations, constants at the minimum/maximum), `extreme` |
| all-zero operands | `zero` (0×0, 0×rand, rand×0, 1×1) |
| identity-like matrices | `identity` (I·B, A·I, −I·B, permutation, rectangular, K ≷ array size) |
| repeated tiles | `repeat` (same tile ×6, partial tile ×4) + every multi-tile `gemm` (back-to-back launches) |
| reset | directed: reset during RUN (tokens in flight), DRAIN and READOUT, then fresh tiles of other shapes must be exact; counters/flags checked clean |
| backpressure / stalls | `stall` (8 `stall_i` profiles × 5 upstream-gap profiles × 3 shapes on the baseline; readout pacing profiles) + `random` with random profiles |
| long accumulation | `longk`: K = 255/1000/4096/5000, 65535, **131071** (largest INT8→INT32 overflow-free K) incl. random hash operands |
| different array dimensions | 1×1, 1×4, 4×1, 2×2, 2×4, 4×2, 3×5, 5×3, 4×4, 8×8, 16×16 |
| additional | `MUL_PIPE` 0/1; (DW,ACC) = (8,16), (8,24), (4,16), (12,32), (16,32); K_WIDTH 8/17/18; checker/perf off; INT32 wraparound at K = 131072 |

## 3. Regression result (final run on frozen sources)

{reg_body}

Overall: **{'PASS' if reg_ok else 'FAIL'}**.  Per-run logs: `logs/reg_<config>_<simulator>.log`.

Rows with both simulators additionally required the TEST/PERF lines of the two logs to be **identical** (shown in the *cross-sim* column).

## 4. Lint

| configuration | `verilator --lint-only -Wall` |
|---|---|
""" + "\n".join(f"| {n} | {'clean' if ok else 'WARNINGS'} |" for n, ok in lint_rows) + f"""

Waivers (in the RTL, with reasons): unused edge/debug bus bits and `fire_flat` (verification visibility); vacuous upper-bound compares on `cfg_m`/`cfg_n` when their width cannot exceed the array size; `n_q` unused when `PERF_EN = 0`.

## 5. Mutation testing

{mut_head}

Each mutant is a one-site change to a copy of the RTL; it is *killed* if the PE unit test (MUL_PIPE 0/1) or the array testbench (2×2 MUL_PIPE=0 and 3×2 MUL_PIPE=1, level-0 vectors + directed tests) reports anything other than PASS. The unmutated baseline passes everything.

{mut_table}

### Survivors, each examined

""" + "\n".join(f"* **{m['id']}** — {m['desc']}: {SURV_WHY[m['id']]}." for m in surv) + """

Mutation history worth knowing: the first mutation run left **m58** (`align_err` not cleared at launch) and **m62** (`tile_done` asserted during DRAIN) alive. Both were genuine test gaps — the testbench never observed the `tile_done` port and never provoked an alignment error — and were closed by direct port checks and a fault-injection test. A mutant that skips the PE's launch flush (m16) is killed, which is what proves the straggler-token flush is *necessary*.

## 6. Bugs found by the testing (not by inspection)

| found by | defect | fix |
|---|---|---|
| first 2×2 run (TB vs RTL counters) | `perf_stall_ext` over-counted a stall landing in the cycle completion is detected (delays nothing) | RTL counter counts effective stalls only |
| Verilator vs Icarus | testbench sampled handshakes at the clock edge (scheduler-dependent) | edge-sampler registers + `tick` |
| Yosys elaboration | `int'()` cast not accepted by the synthesis front end | `32'()` size casts |
| mutation run | `tile_done` / `align_err` unchecked | direct monitor checks, fault injection |
| 1×1 regression | reset-during-DRAIN trigger could never fire on a 2-cycle DRAIN | trigger scales with array size |
| K_WIDTH=8 regression | vector generator emitted K > K_max | generator respects K_WIDTH |

## 7. What this verification does **not** show

* **Simulation only.** No formal proof, no gate-level or timing simulation, no hardware.
* The `force`-based `align_err` test runs on Icarus only (Verilator does not support forcing that net). The checker itself is also covered at PE level on both.
* Several configurations (1×1, 1×4, 4×1, 2×4, 4×2, 5×3, the width variants, checker/perf off, K_WIDTH=8) ran on Icarus only; 8×8, 16×16 and K_WIDTH=18 ran on Verilator only. The cross-simulator identity check covers 2×2, 3×5, 4×4 (and `MUL_PIPE=1`).
* Mutation testing uses small configurations and level-0 vectors; it measures the strength of the checks, not coverage of the whole RTL.
* The wavefront monitor is white-box (hierarchical references into the DUT); the interface-level checks (results, handshakes, ports) are black-box.
* Operand and accumulator widths up to 32-bit accumulators only in the shipped vector format.
"""
wr("docs/VERIFICATION.md", ver)

# ---- synthesis doc
syn = rd("reports/synthesis_summary.md")
rows = []
for l in syn.splitlines():
    c = [x.strip() for x in l.strip().strip("|").split("|")]
    if len(c) >= 10 and c[0] not in ("config", "---") and c[5].isdigit():
        rows.append(dict(name=c[0], arr=c[1], mp=c[2], ck=c[3], pf=c[4], dsp=int(c[5]), lut=int(c[6]), ff=int(c[7]), c4=int(c[8])))
A200 = dict(dsp=740, lut=134600, ff=269200)       # XC7A200T: 740 DSP48E1; 33,650 slices x 4 LUT6 / 8 FF (DS180)
feas = ["| config | DSP48E1 | LUT | FF | DSP % of XC7A200T | LUT % | FF % |", "|---|---|---|---|---|---|---|"]
for r in rows:
    feas.append(f"| {r['name']} | {r['dsp']} | {r['lut']} | {r['ff']} | {100*r['dsp']/A200['dsp']:.1f} | "
                f"{100*r['lut']/A200['lut']:.1f} | {100*r['ff']/A200['ff']:.1f} |")
def _hier(path):
    t = open(path).read(); out = {}
    for m in re.finditer(r"=== (.+?) ===(.*?)(?==== |\Z)", t, re.S):
        nm = m.group(1).split("\\")[-1]
        out[nm] = {k: int(v) for k, v in re.findall(r"^\s+(\$?\w+)\s+(\d+)\s*$", m.group(2), re.M) if not k.startswith("Number")}
    return out
AREA_NOTE = "(hierarchical report not available)"
_hp = os.path.join(ROOT, "synth/reports/stat_xc7_4x4_hier.txt")
if os.path.exists(_hp):
    H = _hier(_hp)
    lutc = lambda d: sum(v for k, v in d.items() if re.fullmatch(r"LUT[1-6]", k))
    coll = next(v for k, v in H.items() if k.endswith("tensor_output_collect"))
    skew = next(v for k, v in H.items() if k.endswith("tensor_skew"))
    pe = next(v for k, v in H.items() if k.endswith("tensor_pe"))
    tot = H["design hierarchy"]
    flat4 = next((r for r in rows if r["name"] == "4x4"), None)
    AREA_NOTE = (f"**Where the area goes (4×4, from the non-flattened run in §5).** That run cannot prune the unused k-index sideband across module "
                 f"boundaries, so its absolute totals are inflated ({tot.get('FDRE', 0)} FF vs {flat4['ff'] if flat4 else '?'} FF flat) — use it for relative proportions only. "
                 f"`tensor_output_collect` holds {lutc(coll)} of {lutc(tot)} LUT-class cells ({100*lutc(coll)/max(lutc(tot),1):.0f} %): {coll.get('LUT6', 0)} LUT6 form the row-select mux "
                 f"and {coll.get('LUT2', 0)} LUT2 equal COLS×ACC_WIDTH = {4*32} column-mask AND gates (the redundant defence-in-depth shown by surviving mutant m33; whether they survive "
                 f"in the flat design was not measured separately). Each of the two `tensor_skew` instances is {skew.get('FDRE', 0)} FDRE with {lutc(skew)} LUT; each `tensor_pe` is "
                 f"{pe.get('DSP48E1', 0)} DSP48E1 + {pe.get('FDRE', 0)} FDRE + {lutc(pe)} LUTs. The readout mux input count is ROWS×COLS×ACC_WIDTH bits, so it scales with the array and is "
                 f"the largest LUT consumer at 4×4.")
has16 = any(r['name'] == '16x16' for r in rows)
SYN16 = ("measured" if has16 else "**NOT synthesized in this session** — extrapolated from the one-DSP-per-PE pattern seen in every measured row; "
         "the 16×16 Yosys run had not completed when it was stopped")
byname = {r['name']: r for r in rows}
obs = []
_mp = []
for n in ("2x2", "4x4", "8x8"):
    a, b = byname.get(n), byname.get(n + "_mp1")
    if a and b:
        npe = int(a['arr'].split('x')[0]) * int(a['arr'].split('x')[1])
        _mp.append(f"{n}: FF {b['ff']-a['ff']:+d} ({(b['ff']-a['ff'])/npe:.1f} per PE), LUT {b['lut']-a['lut']:+d}")
if _mp:
    obs.append("* **MUL_PIPE = 1 vs 0** — " + "; ".join(_mp) + ". A 16-bit product register per PE would add about 16 FF per PE; "
               "an increase of ~2 per PE is *consistent with* the product register being absorbed into the DSP48E1 multiplier register "
               "(an inference from the counts only; the netlist was not inspected).")
if 'instr' in ''.join(byname) and byname.get('4x4_instr') and byname.get('4x4'):
    a, b = byname['4x4'], byname['4x4_instr']
    obs.append(f"* **Instrumentation (CHECK_ALIGN + PERF_EN) at 4×4:** LUT {a['lut']} → {b['lut']} ({b['lut']/a['lut']:.1f}×), "
               f"FF {a['ff']} → {b['ff']} ({b['ff']/a['ff']:.1f}×), CARRY4 {a['c4']} → {b['c4']}. These are verification/diagnostic features; ship with both off.")
if byname.get('4x4_nodsp') and byname.get('4x4'):
    a, b = byname['4x4'], byname['4x4_nodsp']
    obs.append(f"* **Multipliers in fabric (4×4, -nodsp):** {b['lut']} LUTs and {b['dsp']} DSPs vs {a['lut']} LUTs and {a['dsp']} DSPs "
               f"— about {(b['lut']-a['lut'])/16:.0f} extra LUTs per PE.")
gp = os.path.join(ROOT, "synth/reports/stat_generic_4x4.txt")
if os.path.exists(gp):
    m = re.search(r"Number of cells:?\s+(\d+)", open(gp).read())
    if m:
        obs.append(f"* **Generic gate-level 4×4** (`synth -flatten; abc -g AND,NAND,OR,NOR,XOR,XNOR,MUX`, multipliers expanded to gates): {m.group(1)} cells — technology-independent, for orientation only.")
obs.append("* **Synthesis-tool runtime:** the readout mux is written as a variable part-select over the whole `ROWS*COLS*ACC_WIDTH`-bit accumulator vector, which Yosys expands into very wide `$shiftx` cells. "
           + ("8×8 took about 1 minute and 16×16 did not complete within the session budget. " if not has16 else "")
           + "A per-column one-hot row mux would synthesize much faster and is a recommended RTL cleanup (not applied: sources were frozen for the final verification run).")
OBS = "\n".join(obs)
hier = ""
hp = os.path.join(ROOT, "synth/reports/stat_xc7_4x4_hier.txt")
if os.path.exists(hp):
    hier = "\n".join(open(hp).read().splitlines()[:90])
dsp_per_pe = {r["name"]: r["dsp"] / int(r["arr"].split("x")[0]) / int(r["arr"].split("x")[1]) for r in rows if r["name"] != "4x4_nodsp"}
syndoc = f"""# Synthesis — TENSORCORE 02

**What this is.** Yosys 0.33 technology mapping (`synth_xilinx -family xc7 -flatten -noiopad`) of `tensor_systolic_array` for Xilinx 7-series primitives, plus one generic gate-level run. **What it is not:** there is no place-and-route and no static timing analysis in this environment, so **no Fmax, no timing closure and no GOPS figure is claimed anywhere in this repository.** Counts exclude I/O buffers. Vivado may map the same RTL differently — DSP packing in particular. Treat the numbers as a resource *estimate*, good for feasibility ordering, not for sign-off.

Generated by `synth/run_synth.py`; raw Yosys `stat` output and logs are in `synth/reports/`.

## 1. Results

{syn[syn.index('| config'):].strip()}

DSP48E1 per PE across the non-`nodsp` configurations: {', '.join(f"{k}: {v:.2f}" for k, v in dsp_per_pe.items())}. (Yosys' `xilinx_dsp` pass reported a post-adder for each PE, i.e. the multiply-accumulate was packed into the DSP48E1.)

## 2. FPGA feasibility — larger arrays are **not** automatically feasible

The brief warns that bigger configurations are not automatically FPGA-feasible. The binding resource is the DSP48E1 count: one per PE, so `ROWS × COLS`. Reference device (figures from Xilinx DS180 / Artix-7 product table): **XC7A200T — 740 DSP48E1, 215,360 logic cells, 33,650 slices × (4 LUT6 + 8 FF) = 134,600 LUTs, 269,200 FFs.** The Artix-7 family tops out at 740 DSP slices and Kintex-7 at 1,920.

{chr(10).join(feas)}

Reading the table:

* DSP count scales as `ROWS×COLS`: 4×4 = 16, 8×8 = 64, **16×16 = 256** ({SYN16}), a 32×32 would need 1,024 — more than any Artix-7 and more than half a large Kintex-7. Smaller parts have far fewer DSP slices than the XC7A200T; **check the DSP column of your target's product table against `ROWS×COLS` before choosing a size.**
* {AREA_NOTE}
* `CHECK_ALIGN = 1` and `PERF_EN = 1` are verification/diagnostic features; compare `4x4` with `4x4_instr` for their cost. Ship with both off if area matters.
* `4x4_nodsp` shows the cost of multipliers in fabric (no DSP slices).

## 3. Observations from the measured rows

{OBS}

## 4. Timing risk (qualitative — nothing here was measured)

With `MUL_PIPE = 0` each PE has one stage containing the 8×8 multiplier **and** the 32-bit accumulate. `MUL_PIPE = 1` registers the product (+1 cycle per tile, same throughput) and is the structure that allows a DSP's internal multiplier register to be used; whether Yosys or Vivado actually pack it that way was **not inspected here**. The global enable fans out to every register; `pipe_en` also depends combinationally on `s_valid`/`stall_i` inputs, so the producer's `s_valid` and `stall_i` should be registered upstream if the array is clocked fast. These are risks to evaluate in Vivado, not findings.

## 5. Hierarchical breakdown (4×4, CHECK_ALIGN=0, PERF_EN=0, not flattened)

```
{hier}
```
"""
wr("docs/SYNTHESIS.md", syndoc)

# ---- waves README
scen = [("2x2_K3", "Stage-1 example. 2×2, K=3, textbook matrices; RTL gives C = [[58,64],[139,154]]."),
        ("4x4_K4", "4×4 baseline, full tile, K=4 with negative operands (K < M+N−1: never all PEs busy)."),
        ("4x4_K10_steady", "4×4, K=10 — exactly 4 cycles with all 16 PEs committing (= K−6)."),
        ("4x4_partial_3x2_K5", "Partial tile M=3, N=2 on the 4×4 array: padded lanes, inactive PEs never fire."),
        ("4x4_K4_stalls", "Same 4×4 K=4 tile with periodic global stall, upstream gaps and slow readout: the wavefront freezes and resumes."),
        ("2x2_K3_mulpipe1", "2×2 K=3 with MUL_PIPE=1: every commit one enabled cycle later; busy +1.")]
def excerpt(n, lim=42):
    return "\n".join(rd(f"waves/{n}_wavefront.txt").splitlines()[:lim])
wv = ["# Waveform examples\n",
      "Each scenario was simulated (Icarus, `+WAVE`), required to PASS the full self-checking testbench, and rendered from the VCD by `tools/vcd_tools.py` (no GUI viewer needed). "
      "Open the `.vcd` in GTKWave/Surfer if you prefer; the `.svg` is self-contained.\n",
      "| scenario | what it shows | files |\n|---|---|---|"]
for n, d in scen:
    wv.append(f"| {n} | {d} | `{n}.vcd`, `{n}.svg`, `{n}_wavefront.txt` |")
wv += ["\nRegenerate with `make waves`.\n",
       "## Reading the waveforms\n",
       "* Time axis is the clock cycle (value *during* the cycle, i.e. sampled just before the edge).",
       "* `pipe_en` is the global enable; flat stretches while `s_ready`/`pipe_en` are low are the freeze.",
       "* `fire PE(i,j)` is the strobe in which both operand tokens are consumed; `acc PE(i,j)` shows the running partial sum. Check by hand: in `2x2_K3`, PE(0,0): 0 → 7 → 25 → 58 = 1·7 + 2·9 + 3·11.",
       "* `all_done` is only meaningful during DRAIN (it is trivially high when no PE is active, e.g. in IDLE).\n",
       "## Concurrency (derived from the VCD, asserted at build time)\n", "```", conc_txt.strip(), "```\n",
       "## Wavefront grids derived from the VCD\n",
       "### 2×2, K=3 (`2x2_K3_wavefront.txt`)\n", "```", excerpt("2x2_K3"), "```\n",
       "PE(0,0) starts first, PE(0,1)/PE(1,0) one cycle later, PE(1,1) one more; PE(1,1) commits k=2 at step K+M+N−2 = 5.\n",
       "### 4×4, K=4 (`4x4_K4_wavefront.txt`)\n", "```", excerpt("4x4_K4", 60), "```\n"]
wr("waves/README.md", "\n".join(wv) + "\n")

# ---- top-level README
def _row(cfg, sim):
    for l in reg.splitlines():
        c = [x.strip() for x in l.strip().strip("|").split("|")]
        if len(c) >= 11 and c[0] == cfg and c[6] == sim:
            return c
    return None
_i, _v = _row("4x4_L2", "icarus"), _row("4x4_L2", "verilator")
B4 = "numbers unavailable"
if _i and _v:
    B4 = (f"Icarus {_i[8]} tests / {_i[9]} tiles, Verilator {_v[8]} tests / {_v[9]} tiles, "
          f"cross-simulator logs {_v[10]}")
_arr_rows = [l for l in reg.splitlines() if l.startswith("|") and (" icarus " in l or " verilator " in l)]
_pe_rows = [l for l in reg.splitlines() if re.match(r"\| \d+ \| \d+ \| \d \| \d \| ", l)]
nreg = len(_arr_rows)
npe_rows = len(_pe_rows)
arr_pass = sum(1 for l in _arr_rows if "| PASS |" in l)
pe_pass = sum(1 for l in _pe_rows if "| PASS |" in l)
readme = f"""# SilicaFlux TENSORCORE 02 — Configurable Systolic Matrix-Multiplication Array

Aureom.AI | SilicaFlux-HPC. `C[M,N] = A[M,K] × B[K,N]`, signed INT8 operands, INT32 accumulation,
output-stationary 2D systolic array (baseline 4×4; 2×2, 8×8, 16×16 and arbitrary R×C supported).
Primary source: `rtl/tensor_systolic_array.sv`.

> **Provenance.** The brief names an existing `tensor_pe.sv`; **none existed** in the repository provided. `rtl/tensor_pe.sv` is a new implementation, verified only by the tests in this package (`docs/AUDIT.md`).
> **Not committed to GitHub** — this is a plain archive; there is no `.git` directory.

## Status (from the final run on frozen sources)

* Regression: **{'PASS' if reg_ok else 'FAIL (forced package)'}** — {arr_pass} of {nreg} array-testbench runs and {pe_pass} of {npe_rows} PE unit-test runs pass across the configuration matrix (`docs/VERIFICATION.md`).
* Stage order followed: **2×2 first** (wavefront timing verified against hand-derived formulas and the VCD), **then the 4×4 baseline** ({B4}, incl. K = 131071).
* Mutation testing: **{len(killed)} of {len(killed)+len(surv)} injected bugs killed**; the {len(surv)} survivors are examined individually.
* Lint: {'clean' if lint_all else 'WARNINGS present'} over {len(lint_rows)} parameter combinations.
* Synthesis: Yosys resource estimates only (`docs/SYNTHESIS.md`). **No timing / Fmax claim.**

## Layout

| path | contents |
|---|---|
| `rtl/` | `tensor_systolic_array.sv` (top), `tensor_pe.sv`, `tensor_skew.sv`, `tensor_output_collect.sv` |
| `tb/` | `tb_array.sv` (self-checking array TB + wavefront monitor), `tb_pe.sv` (PE unit test) |
| `tools/` | numpy oracle/vector generator, regression driver, mutation harness, VCD tools, report builders |
| `docs/` | `ARCHITECTURE.md` (dataflow, skew, wavefront, fill/drain, completion, stall protocol), `CONFIGURATION.md` (parameters, ports, limits), `PERFORMANCE.md` (measured), `VERIFICATION.md`, `SYNTHESIS.md`, `AUDIT.md` |
| `waves/` | VCDs, SVG waveforms and wavefront grids for six scenarios (`waves/README.md`) |
| `synth/`, `reports/` | Yosys scripts and raw reports; regression, mutation, performance and synthesis summaries |
| `vectors/` | generated test vectors (deterministic; regenerate with `tools/gen_vectors.py`) |
| `logs/` | logs of the final regression / mutation / synthesis runs |

## Quick start

```
make smoke      # 2x2, ~110 tests, seconds (needs iverilog, python3, numpy)
make lint       # verilator -Wall over several sizes
make stage1     # 2x2, Icarus + Verilator          make stage2   # 4x4 baseline (Icarus part ~7 min)
make regress    # full matrix                       make mutation # 47 mutants
make synth      # Yosys sweep                       make waves    # regenerate waveforms
```

## Headline design facts

* **Dataflow:** output-stationary. A moves east, B moves south, **PE(i,j) computes C[i][j]**. Not weight-stationary.
* **Timing (no stalls):** operands of index k meet at PE(i,j) in enabled step `k+1+i+j`; `busy = 1 + K + M + N + MUL_PIPE` cycles; `tile_done` only after every active PE has committed its `last`-tagged product — measured, never a fixed delay.
* **Stall protocol:** one global enable (`pipe_en = ~stall_i & (RUN ? s_valid : DRAIN)`); no PE ever stalls alone.
* **Limits:** one tile in flight (no overlapped readout); K ≤ 2^K_WIDTH−1 (default 131071 = largest overflow-free INT8→INT32 K); accumulation wraps, no saturation; K = 0 is rejected. See `docs/ARCHITECTURE.md` §13.

## Honest caveats

Simulation-only verification (no formal, no gate-level, no hardware). Synthesis is Yosys mapping without place-and-route, so frequency and timing closure are unknown. Several regression configurations ran on one simulator only — see `docs/VERIFICATION.md` §7.
{'' if not FORCE else chr(10) + '**NOTE: this package was produced with --force despite a failed gate.**' + chr(10)}"""
wr("README.md", readme)

# ------------------------------------------------------------------ 3. zip
for pat in ["logs/dbg_*", "logs/s2_*", "logs/mutation_run1.log", "logs/regress_full.log", "logs/mutation_run1.log",
            "reports/mutation_report_survivors.md", "vectors/v_2x2_l*.hex", "vectors/v_2x2_l*.idx", "vectors/v_4x4_l*.hex",
            "vectors/v_4x4_l*.idx", "vectors/v_chk*", "logs/final_pipeline.done"]:
    for f in glob.glob(os.path.join(ROOT, pat)):
        os.remove(f)
EXCL = ("build/", "__pycache__", "obj_dir", ".pyc", ".git/")
files = []
for dp, dn, fn in os.walk(ROOT):
    rel = os.path.relpath(dp, ROOT)
    if any(x.rstrip("/") in rel.split(os.sep) for x in ("build", "__pycache__", "obj_dir", ".git")):
        continue
    for f in fn:
        if f.endswith(".pyc") or f in (f"{NAME}.zip",):
            continue
        files.append(os.path.normpath(os.path.join(rel, f)))
files.sort()
manifest = ["# MANIFEST (path, bytes, sha256-prefix)"]
for f in files:
    b = open(os.path.join(ROOT, f), "rb").read()
    manifest.append(f"{f}\t{len(b)}\t{hashlib.sha256(b).hexdigest()[:12]}")
wr("MANIFEST.txt", "\n".join(manifest) + "\n")
files.append("MANIFEST.txt")
os.makedirs(OUT, exist_ok=True)
zp = os.path.join(OUT, f"{NAME}.zip")
if os.path.exists(zp):
    os.remove(zp)
with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for f in sorted(set(files)):
        z.write(os.path.join(ROOT, f), f"{NAME}/{f}")
rc, o = sh(f"unzip -tq {zp}")
print("unzip -t:", o.strip())
sha = hashlib.sha256(open(zp, "rb").read()).hexdigest()
print(f"zip: {zp}  {os.path.getsize(zp)/1e6:.2f} MB  sha256={sha[:16]}...  files={len(set(files))}")
assert not any(".git/" in f for f in files)

# smoke-test the unpacked copy (proves the package works standalone)
tmp = "/tmp/tc02_unpack"
shutil.rmtree(tmp, ignore_errors=True)
os.makedirs(tmp)
sh(f"unzip -q {zp} -d {tmp}")
rc, o = sh("make smoke 2>&1 | tail -3", cwd=f"{tmp}/{NAME}")
print("unpacked-copy smoke test:\n" + o)
ok_smoke = "TB_RESULT: PASS" in o
rc, o2 = sh("make lint 2>&1 | tail -6", cwd=f"{tmp}/{NAME}")
print(o2)
if not ok_smoke:
    print("SMOKE TEST FAILED"); sys.exit(2)
print("FINALIZE OK")
