#!/usr/bin/env python3
"""
Generate the waveform examples in waves/: for each scenario, build a one-test vector file,
simulate on Icarus with a VCD, require TB_RESULT: PASS, then render the VCD to
  waves/<name>.vcd            raw waveform
  waves/<name>.svg            rendered waveform (no GUI viewer needed)
  waves/<name>_wavefront.txt  per-cycle PE wavefront grids derived from the VCD
"""
import os, re, subprocess, sys
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "tools"))
import gen_vectors as g

RTL = "rtl/tensor_pe.sv rtl/tensor_skew.sv rtl/tensor_output_collect.sv rtl/tensor_systolic_array.sv"


def sh(cmd):
    r = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True)
    return r.returncode, r.stdout + r.stderr


def scenario(name, R, C, mp, A, B, ext=0, up=0, rdy=0, title=""):
    s = g.Suite(R, C, 8, 32, 17)
    M, K = A.shape
    N = B.shape[1]
    s.add("m1x1" if (M, N, K) == (1, 1, 1) else "ksweep", M, N, K, A=A, B=B, ext=ext, up=up, rdy=rdy, name=name)
    vec = f"vectors/wave_{name}.hex"
    open(os.path.join(ROOT, vec), "w").write("\n".join(f"{x & g.M32:08x}" for x in s.words()) + "\n")
    exe = f"build/wave_{name}.vvp"
    rc, out = sh(f"iverilog -g2012 -s tb_array -Ptb_array.ROWS={R} -Ptb_array.COLS={C} -Ptb_array.MUL_PIPE={mp} "
                 f"-Ptb_array.MEM_WORDS=65536 -o {exe} {RTL} tb/tb_array.sv")
    assert rc == 0, out
    rc, out = sh(f"vvp -n {exe} +VEC={vec} +NODIRECTED +WAVE=waves/{name}.vcd")
    ok = "TB_RESULT: PASS" in out
    ref = s.tests[0]["C"]
    print(f"{name:22s} {'PASS' if ok else 'FAIL'}  C =", ref.tolist())
    assert ok, out[-800:]
    rc, out = sh(f"python3 tools/vcd_tools.py --vcd waves/{name}.vcd --rows {R} --cols {C} "
                 f"--svg waves/{name}.svg --txt waves/{name}_wavefront.txt --title \"{title}\"")
    assert rc == 0, out
    return ref


def main():
    for d in ("waves", "build", "vectors"):
        os.makedirs(os.path.join(ROOT, d), exist_ok=True)
    # 1. stage-1 example: 2x2, K=3, textbook matrices
    A = np.array([[1, 2, 3], [4, 5, 6]], dtype=np.int64)
    B = np.array([[7, 8], [9, 10], [11, 12]], dtype=np.int64)
    ref = scenario("2x2_K3", 2, 2, 0, A, B,
                   title="TENSORCORE 02  2x2  K=3   A=[[1,2,3],[4,5,6]]  B=[[7,8],[9,10],[11,12]]  -> C=[[58,64],[139,154]]")
    assert ref.tolist() == [[58, 64], [139, 154]]

    # 2. 4x4 baseline full tile, K=4 (includes negatives)
    A4 = np.array([[1, 2, 3, 4], [5, 6, 7, 8], [9, 10, 11, 12], [13, 14, 15, 16]], dtype=np.int64)
    B4 = np.array([[1, -1, 2, 0], [0, 1, -2, 3], [2, 0, 1, -1], [-3, 1, 0, 2]], dtype=np.int64)
    scenario("4x4_K4", 4, 4, 0, A4, B4, title="TENSORCORE 02  4x4 baseline  full tile  K=4")

    # 3. 4x4, long enough K to reach full concurrency (K=10 -> 4 cycles with all 16 PEs committing)
    rng = np.random.default_rng(7)
    A10 = rng.integers(-128, 128, size=(4, 10), dtype=np.int64)
    B10 = rng.integers(-128, 128, size=(10, 4), dtype=np.int64)
    scenario("4x4_K10_steady", 4, 4, 0, A10, B10, title="TENSORCORE 02  4x4  K=10  (steady state: all 16 PEs busy)")

    # 4. partial tile 3x2 on 4x4 array: padding lanes / inactive PEs
    A32 = rng.integers(-128, 128, size=(3, 5), dtype=np.int64)
    B32 = rng.integers(-128, 128, size=(5, 2), dtype=np.int64)
    scenario("4x4_partial_3x2_K5", 4, 4, 0, A32, B32, title="TENSORCORE 02  4x4 array, partial tile M=3 N=2 K=5 (padded lanes)")

    # 5. stall / bubble / backpressure: periodic global freeze + upstream gaps + slow readout
    scenario("4x4_K4_stalls", 4, 4, 0, A4[:, :], B4[:, :], ext=4, up=4, rdy=2,
             title="TENSORCORE 02  4x4  K=4 with global stall (every 5th cycle), upstream gaps and slow readout")
    # 6. MUL_PIPE=1 (registered product): latency +1
    scenario("2x2_K3_mulpipe1", 2, 2, 1, A, B, title="TENSORCORE 02  2x2  K=3  MUL_PIPE=1 (registered product, +1 cycle)")


if __name__ == "__main__":
    main()
