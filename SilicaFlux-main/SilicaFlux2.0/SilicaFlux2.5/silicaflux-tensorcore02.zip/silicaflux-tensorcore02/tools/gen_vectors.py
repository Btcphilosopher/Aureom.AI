#!/usr/bin/env python3
"""
TENSORCORE 02 -- independent GEMM oracle / test-vector generator.

Writes a $readmemh word file consumed by tb/tb_array.sv.  The expected C is
computed HERE (numpy int64, exact) and wrapped to ACC_WIDTH two's complement, so
the golden reference shares no code with the RTL or the SystemVerilog testbench.

File layout (32-bit words, 8 hex digits each):
  word 0              : number of tests
  per test, 16-word header
      0 tid   1 M   2 N   3 K   4 mode(0 explicit,1 const,2 hash)
      5 p0 (const A / hash seed A)   6 p1 (const B / hash seed B)
      7 up_prof   8 ext_prof   9 rdy_prof   10 lfsr seed
      11 flags (bit0: skip in-TB SV oracle cross-check)
      12 category index   13 reps   14,15 reserved
  then if mode==0 : A (M*K words, row-major), B (K*N words, row-major)
  then            : expected C (M*N words, row-major, ACC_WIDTH bits, masked)

Operand modes
  const : A[i][k] = p0, B[k][j] = p1                      (signed DW-bit values)
  hash  : A[i][k] = H(p0,i,k,0), B[k][j] = H(p1,k,j,1)    (H below; mirrored in TB)
"""
import argparse
import sys
import numpy as np

M32 = 0xFFFFFFFF
U = np.uint64

CATS = ["m1x1", "ksweep", "partial", "negative", "zero", "identity", "repeat",
        "gemm", "longk", "random", "stall", "overflow", "extreme"]


def hash_u32(seed, r, c, which):
    """32-bit mixing hash; mirrored exactly by function hashv() in tb_array.sv."""
    r = np.asarray(r, dtype=U)
    c = np.asarray(c, dtype=U)
    m = U(M32)
    x = (U(seed & M32) ^ ((r * U(0x9E3779B1)) & m) ^ ((c * U(0x85EBCA6B)) & m)
         ^ ((U(which) * U(0xC2B2AE35)) & m)) & m
    x ^= x >> U(16)
    x = (x * U(0x7FEB352D)) & m
    x ^= x >> U(15)
    x = (x * U(0x846CA68B)) & m
    x ^= x >> U(16)
    return x


def to_signed(v, bits):
    v = np.asarray(v, dtype=np.int64) & ((1 << bits) - 1)
    return np.where(v >= (1 << (bits - 1)), v - (1 << bits), v)


def hash_mat(seed, rows, cols, which, dw):
    rr, cc = np.meshgrid(np.arange(rows), np.arange(cols), indexing="ij")
    return to_signed(hash_u32(seed, rr, cc, which).astype(np.int64), dw)


def wrap(c, acc):
    mod = 1 << acc
    return ((c + (mod >> 1)) % mod) - (mod >> 1)


class Suite:
    def __init__(self, R, C, DW, ACC, KW, seed=1234):
        self.R, self.C, self.DW, self.ACC, self.KW = R, C, DW, ACC, KW
        self.rng = np.random.default_rng(seed)
        self.tests = []
        self.lo, self.hi = -(1 << (DW - 1)), (1 << (DW - 1)) - 1
        self.kmax = (1 << KW) - 1

    # ---- operand helpers -------------------------------------------------
    def mat(self, rows, cols, kind="uniform"):
        lo, hi, rng = self.lo, self.hi, self.rng
        if kind == "uniform":
            return rng.integers(lo, hi + 1, size=(rows, cols), dtype=np.int64)
        if kind == "extreme":
            return rng.choice(np.array([lo, -1, 0, 1, hi], dtype=np.int64), size=(rows, cols))
        if kind == "sparse":
            m = rng.integers(lo, hi + 1, size=(rows, cols), dtype=np.int64)
            return np.where(rng.random((rows, cols)) < 0.8, 0, m)
        if kind == "neg":
            return rng.integers(lo, 0, size=(rows, cols), dtype=np.int64)
        if kind == "pos":
            return rng.integers(1, hi + 1, size=(rows, cols), dtype=np.int64)
        raise ValueError(kind)

    def add(self, cat, M, N, K, mode=0, A=None, B=None, p0=0, p1=0,
            up=0, ext=0, rdy=0, flags=0, reps=1, name=""):
        assert 1 <= M and 1 <= N and 1 <= K <= self.kmax, (M, N, K)
        assert M * N <= 16384
        if mode == 1:
            A = np.full((M, K), p0, dtype=np.int64)
            B = np.full((K, N), p1, dtype=np.int64)
        elif mode == 2:
            A = hash_mat(p0, M, K, 0, self.DW)
            B = hash_mat(p1, K, N, 1, self.DW)
        assert A.shape == (M, K) and B.shape == (K, N)
        assert A.min() >= self.lo and A.max() <= self.hi
        assert B.min() >= self.lo and B.max() <= self.hi
        Cx = wrap(A.astype(np.int64) @ B.astype(np.int64), self.ACC)
        self.tests.append(dict(cat=CATS.index(cat), catname=cat, M=M, N=N, K=K, mode=mode,
                               p0=p0, p1=p1, up=up, ext=ext, rdy=rdy, flags=flags,
                               reps=reps, A=A, B=B, C=Cx, name=name or cat,
                               seed=int(self.rng.integers(1, 1 << 31))))

    # ---- suite -----------------------------------------------------------
    def build(self, level):
        R, C, rng = self.R, self.C, self.rng
        lo, hi = self.lo, self.hi

        # 1x1 matrix multiplication
        for a, b in [(3, 4), (lo, lo), (hi, lo), (0, 5), (-1, -1), (hi, hi), (1, 1), (lo, hi)]:
            self.add("m1x1", 1, 1, 1, A=np.array([[a]]), B=np.array([[b]]), name=f"1x1 {a}*{b}")
        self.add("m1x1", 1, 1, 7, A=self.mat(1, 7), B=self.mat(7, 1), name="1x1xK7")

        # K sweep x tile shapes
        shapes = {(R, C), (1, 1), (R, 1), (1, C), (max(R - 1, 1), max(C - 1, 1)),
                  (min(2, R), min(3, C))}
        ks = [1, 3, 4, 7, 16, 257] if level >= 1 else [1, 3, 4, 7, 16]
        ks = [k for k in ks if k <= self.kmax]          # skip K the configuration cannot represent
        for K in ks:
            for (M, N) in sorted(shapes):
                kind = ["uniform", "extreme"][K % 2]
                self.add("ksweep", M, N, K, A=self.mat(M, K, kind), B=self.mat(K, N, kind),
                         name=f"ksweep M{M} N{N} K{K}")

        # every partial tile shape
        for M in range(1, R + 1):
            for N in range(1, C + 1):
                K = 5
                self.add("partial", M, N, K, A=self.mat(M, K), B=self.mat(K, N),
                         name=f"partial M{M} N{N}")

        # negative operands (all combinations of sign extremes)
        for ka, kb in [("neg", "pos"), ("pos", "neg"), ("neg", "neg"), ("pos", "pos")]:
            M, N, K = R, C, 9
            self.add("negative", M, N, K, A=self.mat(M, K, ka), B=self.mat(K, N, kb),
                     name=f"negative {ka}x{kb}")
        self.add("negative", R, C, 11, mode=1, p0=lo, p1=lo, name="const lo*lo")
        self.add("negative", R, C, 11, mode=1, p0=lo, p1=hi, name="const lo*hi")
        self.add("negative", R, C, 11, mode=1, p0=hi, p1=lo, name="const hi*lo")
        self.add("negative", R, C, 11, mode=1, p0=-1, p1=-1, name="const -1*-1")

        # all-zero operands
        self.add("zero", R, C, 8, mode=1, p0=0, p1=0, name="zero*zero")
        self.add("zero", R, C, 8, A=np.zeros((R, 8), dtype=np.int64), B=self.mat(8, C), name="zero*rand")
        self.add("zero", R, C, 8, A=self.mat(R, 8), B=np.zeros((8, C), dtype=np.int64), name="rand*zero")
        self.add("zero", 1, 1, 1, mode=1, p0=0, p1=0, name="zero 1x1")

        # identity-like matrices
        for K in (R, R + 3, max(R - 1, 1)):
            A = np.eye(R, K, dtype=np.int64)
            self.add("identity", R, C, K, A=A, B=self.mat(K, C), name=f"I*B K{K}")
        for K in (C, C + 2):
            B = np.eye(K, C, dtype=np.int64)
            self.add("identity", R, C, K, A=self.mat(R, K), B=B, name=f"A*I K{K}")
        perm = np.eye(max(R, C), dtype=np.int64)[rng.permutation(max(R, C))]
        self.add("identity", R, C, perm.shape[0], A=perm[:R, :], B=self.mat(perm.shape[0], C),
                 name="perm*B")
        self.add("identity", R, C, 6, A=-np.eye(R, 6, dtype=np.int64), B=self.mat(6, C), name="-I*B")

        # repeated tiles (same operands, back to back) and different-operand repeats
        self.add("repeat", R, C, 6, A=self.mat(R, 6), B=self.mat(6, C), reps=6, name="same tile x6")
        self.add("repeat", max(R // 2, 1), max(C // 2, 1), 3, A=self.mat(max(R // 2, 1), 3),
                 B=self.mat(3, max(C // 2, 1)), reps=4, name="partial tile x4")

        # multi-tile GEMM with partial edge tiles in M and/or N
        for (M, N, K) in [(R + 1, C + 1, 3), (2 * R + 1, 2 * C + 3, 11), (3 * R, 2 * C, 17),
                          (R, 2 * C + 1, 5), (2 * R + 1, C, 5), (R - 1 if R > 1 else 2, C + 2, 4)]:
            self.add("gemm", M, N, K, A=self.mat(M, K), B=self.mat(K, N), name=f"gemm {M}x{N}x{K}")
        self.add("gemm", 2 * R + 1, 2 * C + 1, 13, mode=2, p0=0xA11CE, p1=0xB0B, name="gemm hash")

        # extreme-value mixtures
        for _ in range(4):
            M, N, K = int(rng.integers(1, R + 1)), int(rng.integers(1, C + 1)), int(rng.integers(1, 30))
            self.add("extreme", M, N, K, A=self.mat(M, K, "extreme"), B=self.mat(K, N, "extreme"),
                     name=f"extreme M{M} N{N} K{K}")

        # overflow / wrap-around semantics (only if representable at this ACC/K_WIDTH)
        maxprod = max(lo * lo, 1)
        kov = -(-(1 << (self.ACC - 1)) // maxprod)           # first K whose sum can overflow
        if kov + 10 <= min(self.kmax, 6000):
            for K in (kov - 1, kov, kov + 7, 2 * kov + 3):
                self.add("overflow", min(R, 3), min(C, 3), K, mode=1, p0=lo, p1=lo,
                         name=f"overflow const K{K} (kov={kov})")
            self.add("overflow", min(R, 3), min(C, 3), kov + 40, mode=2, p0=7, p1=9,
                     name="overflow hash")

        # random sweep
        n_rand = {0: 30, 1: 120, 2: 200}[level]
        for _ in range(n_rand):
            M, N = int(rng.integers(1, R + 1)), int(rng.integers(1, C + 1))
            K = int(rng.integers(1, 48))
            kind = ["uniform", "extreme", "sparse"][int(rng.integers(0, 3))]
            self.add("random", M, N, K, A=self.mat(M, K, kind), B=self.mat(K, N, kind),
                     up=int(rng.integers(0, 5)), ext=int(rng.integers(0, 8)),
                     rdy=int(rng.integers(0, 4)), name=f"random M{M} N{N} K{K}")

        # directed stall / bubble / backpressure profiles
        stall_shapes = [(R, C, 5), (1, 1, 3), (max(R - 1, 1), max(C - 1, 1), 9)]
        if level >= 1:
            for (M, N, K) in stall_shapes:
                for ext in range(8):
                    for up in range(5):
                        self.add("stall", M, N, K, A=self.mat(M, K), B=self.mat(K, N),
                                 up=up, ext=ext, rdy=(ext + up) % 4,
                                 name=f"stall M{M} N{N} K{K} up{up} ext{ext}")
        else:
            for ext in range(8):
                self.add("stall", R, C, 5, A=self.mat(R, 5), B=self.mat(5, C),
                         up=ext % 5, ext=ext, rdy=ext % 4, name=f"stall ext{ext}")

        # long accumulation
        if level >= 1:
            for Kl in (255, 1000):                       # longest K this configuration can hold, and 1000
                Kl = min(Kl, self.kmax)
                self.add("longk", R, C, Kl, A=self.mat(R, Kl, "extreme"),
                         B=self.mat(Kl, C, "extreme"), name=f"longk {Kl} extreme")
            if self.kmax >= 5000:
                self.add("longk", min(R, 3), min(C, 3), 4096, mode=2, p0=0x1111, p1=0x2222,
                         name="longk 4096 hash")
                self.add("longk", min(R, 2), min(C, 2), 5000, mode=1, p0=lo, p1=lo,
                         up=1, ext=1, rdy=1, name="longk 5000 const stalled")
            else:
                Kl = self.kmax
                self.add("longk", min(R, 2), min(C, 2), Kl, mode=1, p0=lo, p1=lo,
                         up=1, ext=1, rdy=1, name=f"longk {Kl} const stalled")
        if level >= 2 and self.kmax >= 131071 and self.DW == 8 and self.ACC == 32:
            # K = 131071 is the largest K that cannot overflow INT8 x INT8 -> INT32
            self.add("longk", min(R, 4), min(C, 4), 131071, mode=1, p0=lo, p1=lo, flags=1,
                     name="longk 131071 const lo*lo (max no-overflow)")
            self.add("longk", min(R, 4), min(C, 4), 131071, mode=2, p0=0xC0FFEE, p1=0xFACADE, flags=1,
                     name="longk 131071 hash")
            self.add("longk", 1, 1, 65535, mode=1, p0=hi, p1=lo, flags=1, name="longk 65535 hi*lo")
        if level >= 2 and self.kmax >= 131072 and self.DW == 8 and self.ACC == 32:
            # K = 131072 is the FIRST K where INT8 x INT8 -> INT32 can wrap: 131072 * 16384 = 2**31
            self.add("overflow", min(R, 2), min(C, 2), 131072, mode=1, p0=lo, p1=lo, flags=1,
                     name="K=131072 lo*lo wraps to -2**31 (INT32 wraparound, documented)")
            self.add("overflow", 1, 1, 131072 + 5, mode=1, p0=lo, p1=lo, flags=1,
                     name="K=131077 lo*lo wraps (INT32)")

    # ---- serialisation ---------------------------------------------------
    def words(self):
        w = [len(self.tests)]
        dmask = (1 << self.DW) - 1
        amask = (1 << self.ACC) - 1
        for tid, t in enumerate(self.tests):
            w += [tid, t["M"], t["N"], t["K"], t["mode"], t["p0"] & M32, t["p1"] & M32,
                  t["up"], t["ext"], t["rdy"], t["seed"], t["flags"], t["cat"], t["reps"], 0, 0]
            if t["mode"] == 0:
                w += [int(v) & dmask for v in t["A"].ravel()]
                w += [int(v) & dmask for v in t["B"].ravel()]
            w += [int(v) & amask for v in t["C"].ravel()]
        return w


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--dw", type=int, default=8)
    ap.add_argument("--acc", type=int, default=32)
    ap.add_argument("--kw", type=int, default=17)
    ap.add_argument("--level", type=int, default=1, choices=[0, 1, 2])
    ap.add_argument("--seed", type=int, default=20261107)
    ap.add_argument("--out", required=True, help="output .hex path (index written to .idx)")
    a = ap.parse_args()
    assert a.acc <= 32 and a.acc >= 2 * a.dw
    s = Suite(a.rows, a.cols, a.dw, a.acc, a.kw, a.seed)
    s.build(a.level)
    w = s.words()
    assert len(w) < (1 << 21) - 16, f"vector file too large: {len(w)} words"
    with open(a.out, "w") as f:
        f.write("\n".join(f"{x & M32:08x}" for x in w) + "\n")
    with open(a.out.rsplit(".", 1)[0] + ".idx", "w") as f:
        for tid, t in enumerate(s.tests):
            f.write(f"{tid}\t{t['catname']}\t{t['name']}\tM={t['M']} N={t['N']} K={t['K']} "
                    f"mode={t['mode']} up={t['up']} ext={t['ext']} rdy={t['rdy']} reps={t['reps']}\n")
    print(f"{a.out}: {len(s.tests)} tests, {len(w)} words")


if __name__ == "__main__":
    sys.exit(main())
