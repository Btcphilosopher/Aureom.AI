#!/bin/sh
# Final verification pipeline on FROZEN sources: regression -> mutation -> synthesis.
cd "$(dirname "$0")/.."
python3 tools/run_regress.py   > logs/final_regress.log  2>&1
python3 tools/mutation_test.py > logs/final_mutation.log 2>&1
python3 synth/run_synth.py     > logs/final_synth.log    2>&1
echo DONE > logs/final_pipeline.done
