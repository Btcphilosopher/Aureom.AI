# SilicaFlux TENSORCORE 02 — Configurable Systolic Matrix-Multiplication Array

Aureom.AI | SilicaFlux-HPC. `C[M,N] = A[M,K] × B[K,N]`, signed INT8 operands, INT32 accumulation,
output-stationary 2D systolic array (baseline 4×4; 2×2, 8×8, 16×16 and arbitrary R×C supported).
Primary source: `rtl/tensor_systolic_array.sv`.

> **Provenance.** The brief names an existing `tensor_pe.sv`; **none existed** in the repository provided. `rtl/tensor_pe.sv` is a new implementation, verified only by the tests in this package (`docs/AUDIT.md`).
> **Not committed to GitHub** — this is a plain archive; there is no `.git` directory.

## Status (from the final run on frozen sources)

* Regression: **PASS** — 29 of 29 array-testbench runs and 11 of 11 PE unit-test runs pass across the configuration matrix (`docs/VERIFICATION.md`).
* Stage order followed: **2×2 first** (wavefront timing verified against hand-derived formulas and the VCD), **then the 4×4 baseline** (Icarus 433 tests / 465 tiles, Verilator 430 tests / 463 tiles, cross-simulator logs identical (877 lines), incl. K = 131071).
* Mutation testing: **44 of 47 injected bugs killed**; the 3 survivors are examined individually.
* Lint: clean over 11 parameter combinations.
* Synthesis: Yosys resource estimates only (`docs/SYNTHESIS.md`). **No timing / Fmax claim.**

## Layout

| path | contents |
|---|---|
| `rtl/` | `tensor_systolic_array.sv` (top), `tensor_pe.sv`, `tensor_skew.sv`, `tensor_output_collect.sv` |
| `tb/` | `tb_array.sv` (self-checking array TB + wavefront monitor), `tb_pe.sv` (PE unit test) |
| `tools/` | numpy oracle/vector generator, regression driver, mutation harness, VCD tools, report builders |
| `docs/` | `ARCHITECTURE.md` (dataflow, skew, wavefront, fill/drain, completion, stall protocol), `CONFIGURATION.md` (parameters, ports, limits), `PERFORMANCE.md` (measured), `VERIFICATION.md`, `SYNTHESIS.md`, `AUDIT.md` |
| `waves/` | VCDs, SVG waveforms and wavefront grids for six scenarios (`waves/README.md`) |
| `synth/`, `reports/` | Yosys scripts and raw reports; regression, mutation, performance and synthesis summaries |
| `vectors/` | generated test vectors (deterministic; regenerate with `tools/gen_vectors.py`) |
| `logs/` | logs of the final regression / mutation / synthesis runs |

## Quick start

```
make smoke      # 2x2, ~110 tests, seconds (needs iverilog, python3, numpy)
make lint       # verilator -Wall over several sizes
make stage1     # 2x2, Icarus + Verilator          make stage2   # 4x4 baseline (Icarus part ~7 min)
make regress    # full matrix                       make mutation # 47 mutants
make synth      # Yosys sweep                       make waves    # regenerate waveforms
```

## Headline design facts

* **Dataflow:** output-stationary. A moves east, B moves south, **PE(i,j) computes C[i][j]**. Not weight-stationary.
* **Timing (no stalls):** operands of index k meet at PE(i,j) in enabled step `k+1+i+j`; `busy = 1 + K + M + N + MUL_PIPE` cycles; `tile_done` only after every active PE has committed its `last`-tagged product — measured, never a fixed delay.
* **Stall protocol:** one global enable (`pipe_en = ~stall_i & (RUN ? s_valid : DRAIN)`); no PE ever stalls alone.
* **Limits:** one tile in flight (no overlapped readout); K ≤ 2^K_WIDTH−1 (default 131071 = largest overflow-free INT8→INT32 K); accumulation wraps, no saturation; K = 0 is rejected. See `docs/ARCHITECTURE.md` §13.

## Honest caveats

Simulation-only verification (no formal, no gate-level, no hardware). Synthesis is Yosys mapping without place-and-route, so frequency and timing closure are unknown. Several regression configurations ran on one simulator only — see `docs/VERIFICATION.md` §7.
