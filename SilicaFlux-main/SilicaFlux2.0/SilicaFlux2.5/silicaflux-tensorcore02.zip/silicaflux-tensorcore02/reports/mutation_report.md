# TENSORCORE 02 -- Mutation test report

Mutants: 47   **killed: 44**   survived: 3   invalid: 0   (wall time 65 s)

Detectors: PE unit test (MUL_PIPE 0/1) and array TB on 2x2 MUL_PIPE=0 and 3x2 MUL_PIPE=1 (level-0 vectors + directed reject/reset).

| id | status | mutation | killed by | first detector message |
|---|---|---|---|---|
| m00 | BASELINE_OK | UNMUTATED BASELINE |  |  |
| m01 | KILLED | PE accumulates when only the A token is valid | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=210000: D3 acc unchanged by invalid tokens (7623, 0) |
| m02 | KILLED | PE ignores token valid entirely (relies on zero data) | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=210000: D3 acc unchanged by invalid tokens (11661, 0) |
| m03 | KILLED | accumulator subtracts | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=60000: D1 acc visible after 1 en-cycle (MP0) (-15, 15) |
| m04 | KILLED | product ZERO-extended instead of sign-extended | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 acc held during freeze (65473, -63) |
| m05 | KILLED | unsigned multiply | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 acc held during freeze (2241, -63) |
| m06 | KILLED | done raised on first MAC instead of the last-tagged MAC | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 not done during freeze (1, 0) |
| m07 | KILLED | PE ignores the global enable (advances during stall) | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 acc held during freeze (29937, -63) |
| m08 | KILLED | done flag not cleared at tile launch / reset | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 not done during freeze (1, 0) |
| m09 | KILLED | alignment checker: k-index compare inverted | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=311000: D6 matched tokens -> no err (1, 0) |
| m10 | KILLED | alignment checker permanently disabled | PE mp0, PE mp1 | PE mp0: FAIL -- PE_ERROR t=312000: D6 k-index mismatch flagged (0, 1) |
| m11 | KILLED | MUL_PIPE=1: last tag lost in product stage | PE mp1, 3x2_mp1 | PE mp1: FAIL -- PE_ERROR t=70000: D1 done after MAC latency (0, 1) |
| m12 | KILLED | MUL_PIPE=1: done taken from input stage (1 cycle early) | PE mp1, 3x2_mp1 | PE mp1: FAIL -- PE_ERROR t=70000: D1 done after MAC latency (0, 1) |
| m13 | KILLED | commit event not qualified by en | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=665000: commit_o mismatch (1, 0) |
| m14 | KILLED | B forwarding drops the last token's valid | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=635000: fwd valid mismatch (0, 0) |
| m15 | SURVIVED | MUL_PIPE=1: product register updated even without valid (benign) |  |  |
| m16 | KILLED | PE clr does not flush stale forwarded A tokens (stragglers survive launch) | PE mp0, PE mp1, 2x2_mp0 | PE mp0: FAIL -- PE_ERROR t=280000: D5 fwd valid cleared (1, 0) |
| m20 | KILLED | skew depth off by one on lanes >= 2 | 3x2_mp1 | 3x2_mp1: FAIL -- MONITOR_ERROR t=1285000 cyc=129 test=13: A valid mismatch PE (2,0,0) |
| m21 | KILLED | skew network ignores the global enable | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=16705000 cyc=1671 test=65: A tokens moved during freeze (0,0,0) |
| m22 | SURVIVED | skew network not flushed at tile launch |  |  |
| m23 | KILLED | skew taps first stage (no skew at all) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=865000 cyc=87 test=10: B valid mismatch PE (0,1,-1) |
| m30 | KILLED | completion when ANY active PE is done | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=126000 test=0: busy cycles != 1+K+M+N+MP+stalls (3,4) |
| m31 | KILLED | readout mux selects the wrong row | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=136000 test=0: RESULT MISMATCH C[idx] (0,0) |
| m32 | KILLED | completion looks only at PE(0,0) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=896000 test=10: busy cycles != 1+K+M+N+MP+stalls (4,5) |
| m33 | SURVIVED | readout does not mask columns outside N |  |  |
| m40 | KILLED | row mask one row too wide | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: A valid mismatch PE (1,0,0) |
| m41 | KILLED | column mask one column too narrow | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=105000 cyc=11 test=0: B valid mismatch PE (0,0,0) |
| m42 | KILLED | A lanes not zero-padded | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: A pad data nonzero PE (0,0,0) |
| m43 | KILLED | B lanes not zero-padded | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: B pad data nonzero PE (0,0,0) |
| m44 | KILLED | A rows beyond M injected as valid (padding not masked) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: A valid mismatch PE (1,0,0) |
| m45 | KILLED | B columns beyond N injected as valid (padding not masked) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: B valid mismatch PE (0,1,0) |
| m46 | KILLED | last tag one slice late | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=40706000 test=0: readout timeout (0,0) |
| m47 | KILLED | array advances in RUN even when no slice is valid | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=17365000 cyc=1737 test=66: pipe_en != s_valid&~stall in RUN (0,0,0) |
| m48 | KILLED | global enable ignores stall_i | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=16695000 cyc=1670 test=65: pipe_en != s_valid&~stall in RUN (0,0,0) |
| m49 | KILLED | slice accepted while stalled (dropped/duplicated operand) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=16695000 cyc=1670 test=65: s_ready != ~stall in RUN (0,0,0) |
| m50 | KILLED | k counter advances on s_valid instead of the handshake | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=16706000 test=65: s_k != expected slice index (8,7) |
| m51 | KILLED | M = 0 accepted | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=42956000 test=102: illegal cfg not rejected (no pulse) (0,0) |
| m52 | KILLED | K = 0 accepted | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=42996000 test=102: illegal cfg not rejected (no pulse) (2,0) |
| m53 | KILLED | m_last one row late | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=126000 test=0: m_last wrong (0,0) |
| m54 | KILLED | tile-launch clear removed | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=165000 cyc=17 test=1: done flag mismatch PE (0,0,0) |
| m55 | KILLED | tile completion without waiting for the wavefront to drain | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=126000 test=0: busy cycles != 1+K+M+N+MP+stalls (3,4) |
| m56 | KILLED | useful-MAC counter over-counts | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=136000 test=0: perf_mac != M*N*K (5,1) |
| m57 | KILLED | padding-slot counter over-counts | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=136000 test=0: perf_pad != (R*C-M*N)*K (4,3) |
| m58 | KILLED | align_err not cleared at tile launch | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=43285000 cyc=4329 test=9061: align_err asserted (0,0,0) |
| m59 | KILLED | B skew one stage too deep (A/B misaligned by 1) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=105000 cyc=11 test=0: B valid mismatch PE (0,0,0) |
| m60 | KILLED | A skew one stage too shallow (A/B misaligned by 1) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=95000 cyc=10 test=0: A valid mismatch PE (0,0,-1) |
| m61 | KILLED | A k-index metadata lost (data path untouched) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=675000 cyc=68 test=8: A kidx PE (0,0,1) |
| m62 | KILLED | tile_done asserted during DRAIN | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=105000 cyc=11 test=0: tile_done != m_valid (1,0,0) |

## Survivors

- **m15** MUL_PIPE=1: product register updated even without valid (benign) -- hint: equiv
- **m22** skew network not flushed at tile launch -- hint: may be equivalent: stale tokens are dead by construction
- **m33** readout does not mask columns outside N -- hint: equiv: inactive PEs hold zero (defence in depth)
