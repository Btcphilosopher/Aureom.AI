# TENSORCORE 02 -- Synthesis summary (Yosys, Xilinx 7-series mapping)

**Scope and limits.** Technology mapping by Yosys 0.33 `synth_xilinx -family xc7 -flatten -noiopad`. No place-and-route, no static timing: **no Fmax or timing-closure claim is made.** Counts exclude I/O buffers. Vivado may map differently (DSP packing in particular).

| config | array | MUL_PIPE | CHECK_ALIGN | PERF_EN | DSP | LUT | FF | CARRY4 | MUXF7/8 | note |
|---|---|---|---|---|---|---|---|---|---|---|
| 2x2 | 2x2 | 0 | 0 | 0 | 4 | 163 | 84 | 11 | 6/2 |  |
| 4x4 | 4x4 | 0 | 0 | 0 | 16 | 439 | 378 | 11 | 15/7 |  |
| 8x8 | 8x8 | 0 | 0 | 0 | 64 | 1181 | 1708 | 13 | 46/23 |  |
| 16x16 | 16x16 | 0 | 0 | 0 | NOT COMPLETED in this session | | | | | |
| 2x2_mp1 | 2x2 | 1 | 0 | 0 | 4 | 175 | 92 | 11 | 6/2 |  |
| 4x4_mp1 | 4x4 | 1 | 0 | 0 | 16 | 487 | 410 | 11 | 15/7 |  |
| 8x8_mp1 | 8x8 | 1 | 0 | 0 | 64 | 1373 | 1836 | 13 | 46/23 |  |
| 16x16_mp1 | 16x16 | 1 | 0 | 0 | NOT COMPLETED in this session | | | | | |
| 4x4_instr | 4x4 | 0 | 1 | 1 | 16 | 848 | 1369 | 73 | 130/53 |  |
| 4x4_nodsp | 4x4 | 0 | 0 | 0 | 0 | 5924 | 1018 | 139 | 1361/476 | multipliers in fabric (-nodsp) |
