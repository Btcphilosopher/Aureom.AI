# TENSORCORE 02 -- Regression summary

Total wall time 820 s.  Overall: **PASS**

| config | R x C | DW/ACC/KW | MUL_PIPE | CHECK/PERF | vector tests | simulator | result | tests passed (incl. directed) | tiles | cross-sim |
|---|---|---|---|---|---|---|---|---|---|---|
| 2x2_L1 | 2x2 | 8/32/17 | 0 | 1/1 | 313 | icarus | PASS | 326 | 361 | identical (666 lines) |
| 2x2_L1 | 2x2 | 8/32/17 | 0 | 1/1 | 313 | verilator | PASS | 323 | 359 | identical (666 lines) |
| 4x4_L2 | 4x4 | 8/32/17 | 0 | 1/1 | 420 | icarus | PASS | 433 | 465 | identical (877 lines) |
| 4x4_L2 | 4x4 | 8/32/17 | 0 | 1/1 | 420 | verilator | PASS | 430 | 463 | identical (877 lines) |
| 1x1_L1 | 1x1 | 8/32/17 | 0 | 1/1 | 292 | icarus | PASS | 305 | 347 | - |
| 1x4_L1 | 1x4 | 8/32/17 | 0 | 1/1 | 307 | icarus | PASS | 320 | 354 | - |
| 4x1_L1 | 4x1 | 8/32/17 | 0 | 1/1 | 313 | icarus | PASS | 326 | 365 | - |
| 2x4_L1 | 2x4 | 8/32/17 | 0 | 1/1 | 329 | icarus | PASS | 342 | 374 | - |
| 4x2_L1 | 4x2 | 8/32/17 | 0 | 1/1 | 329 | icarus | PASS | 342 | 377 | - |
| 3x5_L1 | 3x5 | 8/32/17 | 0 | 1/1 | 336 | icarus | PASS | 349 | 381 | identical (709 lines) |
| 3x5_L1 | 3x5 | 8/32/17 | 0 | 1/1 | 336 | verilator | PASS | 346 | 379 | identical (709 lines) |
| 5x3_L1 | 5x3 | 8/32/17 | 0 | 1/1 | 336 | icarus | PASS | 349 | 381 | - |
| 2x2_MP1_L1 | 2x2 | 8/32/17 | 1 | 1/1 | 313 | icarus | PASS | 326 | 361 | identical (666 lines) |
| 2x2_MP1_L1 | 2x2 | 8/32/17 | 1 | 1/1 | 313 | verilator | PASS | 323 | 359 | identical (666 lines) |
| 4x4_MP1_L1 | 4x4 | 8/32/17 | 1 | 1/1 | 337 | icarus | PASS | 350 | 382 | identical (711 lines) |
| 4x4_MP1_L1 | 4x4 | 8/32/17 | 1 | 1/1 | 337 | verilator | PASS | 347 | 380 | identical (711 lines) |
| 3x5_MP1_L1 | 3x5 | 8/32/17 | 1 | 1/1 | 336 | icarus | PASS | 349 | 381 | - |
| 4x4_DW8_ACC16 | 4x4 | 8/16/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 4x4_DW8_ACC24 | 4x4 | 8/24/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 4x4_DW4_ACC16 | 4x4 | 4/16/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 4x4_DW12_ACC32 | 4x4 | 12/32/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 3x3_DW16_ACC32 | 3x3 | 16/32/17 | 0 | 1/1 | 335 | icarus | PASS | 348 | 380 | - |
| 4x4_NOCHECK | 4x4 | 8/32/17 | 0 | 0/1 | 337 | icarus | PASS | 347 | 380 | - |
| 4x4_NOPERF | 4x4 | 8/32/17 | 0 | 1/0 | 337 | icarus | PASS | 350 | 382 | - |
| 4x4_KW8 | 4x4 | 8/32/8 | 0 | 1/1 | 330 | icarus | PASS | 343 | 375 | - |
| 2x2_KW18_L2 | 2x2 | 8/32/18 | 0 | 1/1 | 398 | verilator | PASS | 408 | 444 | - |
| 8x8_L1 | 8x8 | 8/32/17 | 0 | 1/1 | 385 | verilator | PASS | 395 | 428 | - |
| 8x8_MP1_L0 | 8x8 | 8/32/17 | 1 | 1/1 | 173 | verilator | PASS | 183 | 216 | - |
| 16x16_L1 | 16x16 | 8/32/17 | 0 | 1/1 | 577 | verilator | PASS | 587 | 620 | - |

## PE unit test (tb/tb_pe.sv)

| DATA_WIDTH | ACC_WIDTH | MUL_PIPE | CHECK_ALIGN | result | checks | errors |
|---|---|---|---|---|---|---|
| 8 | 32 | 0 | 1 | PASS | 2000027 | 0 |
| 8 | 32 | 1 | 1 | PASS | 2000027 | 0 |
| 8 | 32 | 0 | 0 | PASS | 2000027 | 0 |
| 8 | 32 | 1 | 0 | PASS | 2000027 | 0 |
| 4 | 8 | 0 | 1 | PASS | 2000007 | 0 |
| 4 | 8 | 1 | 1 | PASS | 2000007 | 0 |
| 8 | 16 | 0 | 1 | PASS | 2000007 | 0 |
| 8 | 16 | 1 | 1 | PASS | 2000007 | 0 |
| 12 | 32 | 1 | 1 | PASS | 2000027 | 0 |
| 16 | 32 | 0 | 1 | PASS | 2000027 | 0 |
| 2 | 4 | 0 | 1 | PASS | 2000007 | 0 |
