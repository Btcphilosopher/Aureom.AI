# Configuration and interface reference — `tensor_systolic_array`

## 1. Parameters

| parameter | default | legal values | meaning |
|---|---|---|---|
| `ARRAY_ROWS` | 4 | ≥ 1 | PE rows = max tile M. Independent of `ARRAY_COLS`. |
| `ARRAY_COLS` | 4 | ≥ 1 | PE columns = max tile N. |
| `DATA_WIDTH` | 8 | ≥ 2 | signed operand width (INT8 baseline). |
| `ACC_WIDTH` | 32 | ≥ `2*DATA_WIDTH`, ≤ 32 *in the shipped testbench* | signed accumulator width. RTL itself has no 32-bit limit; the vector format stores expected C in 32-bit words. |
| `K_WIDTH` | 17 | ≥ 1 | width of `cfg_k`, the slice counter and the k-index sideband. `K_max = 2**K_WIDTH − 1`. |
| `MUL_PIPE` | 0 | 0, 1 | 0: multiply and accumulate in one PE stage. 1: registered product, accumulate one enabled cycle later (PE MAC latency 2). Throughput is 1 MAC/PE/cycle either way. |
| `CHECK_ALIGN` | 1 | 0, 1 | 1: in-array alignment checker (k-index equality, `last`-tag equality, token present in active region) with sticky `align_err`. 0: removed; synthesis prunes the k-index sideband registers. |
| `PERF_EN` | 1 | 0, 1 | 1: per-tile performance counters. 0: outputs tied to 0. |

Elaboration-time checks (`$fatal` in simulation): dimensions ≥ 1, `K_WIDTH` ≥ 1, `ACC_WIDTH ≥ 2*DATA_WIDTH`, `MUL_PIPE ∈ {0,1}`.

Configurations exercised by the regression: 1×1, 1×4, 4×1, 2×2, 2×4, 4×2, 3×5, 5×3, **4×4 (baseline)**, 8×8, 16×16; `MUL_PIPE` 0/1; `(DATA_WIDTH, ACC_WIDTH)` = (8,32), (8,16), (8,24), (4,16), (12,32), (16,32); `K_WIDTH` 8/17/18; `CHECK_ALIGN` and `PERF_EN` off. See `reports/regression_summary.md`.

## 2. Arithmetic limits

* Operands: signed two's complement, range `[−2^(DW−1), 2^(DW−1)−1]`. The largest product magnitude is `(−2^(DW−1))² = 2^(2DW−2)`.
* Accumulation **wraps modulo 2^ACC_WIDTH** (two's complement). There is no saturation and no overflow flag.
* Overflow-free K bound: `K ≤ floor((2^(ACC_WIDTH−1) − 1) / 2^(2DW−2))`.
  For INT8 → INT32 this is **K ≤ 131071**; K = 131072 of all `(−128)×(−128)` products is exactly `2^31` and wraps to `−2^31`. With the default `K_WIDTH = 17`, `K_max = 131071`, so the default cannot overflow. Larger `K_WIDTH` values permit K beyond the bound and then wrap as stated; both cases are in the regression.

## 3. Ports

### Tile launch
| port | dir | description |
|---|---|---|
| `cfg_valid` / `cfg_ready` | in / out | handshake; `cfg_ready` is high only in IDLE |
| `cfg_m` (`clog2(ROWS+1)` b), `cfg_n` (`clog2(COLS+1)` b), `cfg_k` (`K_WIDTH` b) | in | tile shape. **Legal:** `1 ≤ M ≤ ARRAY_ROWS`, `1 ≤ N ≤ ARRAY_COLS`, `1 ≤ K ≤ 2^K_WIDTH−1` |
| `cfg_reject` | out | 1-cycle pulse, one cycle after an *illegal* launch was dropped; the array stays IDLE and unchanged. **K = 0 is rejected, not treated as C = 0.** |

### Operand k-slice stream
| port | dir | description |
|---|---|---|
| `s_valid` / `s_ready` | in / out | `s_ready` = RUN and not `stall_i`. A slice is accepted on `s_valid & s_ready`. |
| `s_a` (`ROWS*DW` b) | in | `A[:,k]`, lane i = row i. Lanes ≥ M are ignored (zero-padded internally). |
| `s_b` (`COLS*DW` b) | in | `B[k,:]`, lane j = column j. Lanes ≥ N are ignored. |
| `s_k` | out | index of the slice expected next (0 … K−1) |

Exactly K slices are accepted per tile, in order k = 0 … K−1. The producer must present slice `s_k`.

### Global freeze
`stall_i` — when 1, in RUN/DRAIN the whole datapath freezes (see ARCHITECTURE §6). It has no effect on READOUT, whose pacing is `m_ready`.

### Result stream
| port | dir | description |
|---|---|---|
| `m_valid` / `m_ready` | out / in | one beat per result row, M beats |
| `m_row` | out | row index 0 … M−1 |
| `m_data` (`COLS*ACC` b) | out | lane j = `C[m_row][j]`; lanes ≥ N read 0 |
| `m_col_mask` | out | bit j = 1 for j < N |
| `m_last` | out | high on the final row |

### Status
`busy` (not IDLE), `tile_done` (level, high for the whole READOUT state), `align_err` (sticky from the first alignment violation until the next launch or reset; only meaningful with `CHECK_ALIGN = 1`).

### Performance counters (per tile; cleared at launch, frozen at READOUT; 40 bit)
| port | meaning |
|---|---|
| `perf_busy` | cycles in CLEAR + RUN + DRAIN |
| `perf_issue` | accepted slices (= K) |
| `perf_stall_up` | RUN cycles with no slice and no `stall_i` |
| `perf_stall_ext` | *effective* `stall_i` cycles in RUN/DRAIN (a stall in the cycle where `all_done` is already true delays nothing and is not counted) |
| `perf_mac` | MACs committed (= M·N·K) |
| `perf_pad` | PE-slots occupied by padding, summed over issued slices: `(ROWS·COLS − M·N)·K` |

## 4. Reset

Synchronous, active-low `rst_n`. Reset clears the FSM, masks, all PE state, the skew network, `align_err` and the counters. Verified by asserting reset during RUN, DRAIN and READOUT and then running fresh tiles of different shapes.

## 5. Timing protocol summary (no stalls)

`busy = 1 + K + M + N + MUL_PIPE` cycles from the cycle after launch to the cycle before `tile_done`, then M readout beats. With stalls: `+ perf_stall_up + perf_stall_ext`.
