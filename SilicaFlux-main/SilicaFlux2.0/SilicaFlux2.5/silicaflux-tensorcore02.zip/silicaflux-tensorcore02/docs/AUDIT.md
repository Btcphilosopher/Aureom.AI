# Repository audit — TENSORCORE 02

## What the brief asked for

> Inspect `tensor_pe.sv` and existing tensor RTL. Verify the actual PE interface, latency,
> stall semantics and arithmetic behaviour. Do not integrate unverified or missing
> dependencies as though they work.

## What was found

| item | finding |
|---|---|
| `tensor_pe.sv` | **Not present.** |
| any other tensor RTL (`*.sv`, `*.svh`, `tensor_*`) | **None.** A filesystem-wide search found no SystemVerilog source at all. |
| uploaded files | none (`/mnt/user-data/uploads` was empty) |
| EDA tools | none installed at start; Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33 were installed from the distribution archive for this work |

There was therefore nothing to audit for interface, latency, stall semantics or arithmetic.

## Decision

The PE was **written new** (`rtl/tensor_pe.sv`) and is labelled as new in its file header.
It carries no provenance from any earlier design and must not be assumed to match one. Its
interface, latency, stall semantics and arithmetic were *defined* here and then verified
here:

| property | defined behaviour | verified by |
|---|---|---|
| arithmetic | signed `DATA_WIDTH` × signed `DATA_WIDTH`, sign-extended product, signed `ACC_WIDTH` accumulate (two's-complement wrap) | `tb/tb_pe.sv` directed D4 + random model; array tests vs numpy oracle; mutants m03/m04/m05 |
| accumulate gating | only when **both** operand tokens are valid | `tb_pe` D3; wavefront monitor `fire` check; mutants m01/m02 |
| forward latency | exactly 1 enabled cycle (registered hop) | `tb_pe` D1; monitor token-position check |
| MAC latency | `MUL_PIPE=0`: result visible after 1 enabled cycle; `MUL_PIPE=1`: after 2 | `tb_pe` D1/D2; monitor commit-timing check |
| stall semantics | `en = 0` freezes every datapath register; `clr` overrides `en` | `tb_pe` D2/D5; monitor freeze-invariance check; mutants m07/m21 |
| done semantics | sticky, set at the same edge that commits the `last`-tagged product | `tb_pe` D1; monitor `done == (commits == K)` every cycle; mutants m06/m11/m12 |

## Consequence for the rest of the deliverable

Nothing downstream depends on an unverified external module. Every dependency of
`tensor_systolic_array.sv` is a file in this repository with its own tests.
