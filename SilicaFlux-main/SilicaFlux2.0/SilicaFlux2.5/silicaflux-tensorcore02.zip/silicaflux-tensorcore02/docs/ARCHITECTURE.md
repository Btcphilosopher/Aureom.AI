# Architecture — SilicaFlux TENSORCORE 02

Configurable 2D **output-stationary** systolic array, `C[M,N] = A[M,K] × B[K,N]`, one output tile per launch.
Baseline: 4 × 4, signed INT8 operands, INT32 accumulation. Source: `rtl/tensor_systolic_array.sv`.

```
                 B[k][0]      B[k][1]      B[k][2]      B[k][3]        (B columns, skewed by 1+j)
                    |            |            |            |
                    v            v            v            v
 A[0][k] --1-->  PE(0,0) ---> PE(0,1) ---> PE(0,2) ---> PE(0,3)
 A[1][k] --2-->  PE(1,0) ---> PE(1,1) ---> PE(1,2) ---> PE(1,3)        A moves EAST
 A[2][k] --3-->  PE(2,0) ---> PE(2,1) ---> PE(2,2) ---> PE(2,3)        B moves SOUTH
 A[3][k] --4-->  PE(3,0) ---> PE(3,1) ---> PE(3,2) ---> PE(3,3)        each PE keeps its own C[i][j]
   (A rows, skewed by 1+i)        (vertical arrows: B flows down the columns)
```

**This is not a weight-stationary design.** No operand is preloaded into or held by a PE. Both A and B stream; only the *partial sum* is stationary.

## 1. Module map

| file | role |
|---|---|
| `tensor_pe.sv` | PE: registered A/B forwarding, signed MAC, sticky `done`, optional product register (`MUL_PIPE`), optional alignment checker. **New** (the brief's PE did not exist — `AUDIT.md`). |
| `tensor_skew.sv` | triangular skew / input distribution: lane *l* delayed by `1 + l` registers |
| `tensor_output_collect.sv` | completion detect (`all_done`) and row-select readout mux |
| `tensor_systolic_array.sv` | FSM, zero-padding/masking injection, PE grid, perf counters, alignment-error latch |

## 2. Which PE computes which element

**PE(i, j) computes `C[i][j] = Σ_{k=0}^{K−1} A[i][k]·B[k][j]`** — row index *i* is the A row (PE row), column index *j* the B column (PE column). Its partial sum never leaves the PE until readout. PEs with `i ≥ M` or `j ≥ N` are *inactive* for the tile and accumulate nothing.

## 3. Input injection order

The producer supplies one **k-slice** per accepted handshake, in order `k = 0, 1, …, K−1`:

* `s_a = A[:,k]` — lane *i* carries `A[i][k]` for row *i* (rows ≥ M ignored),
* `s_b = B[k,:]` — lane *j* carries `B[k][j]` for column *j* (columns ≥ N ignored).

Slice 0 is injected first. Lanes outside the active tile are injected as **valid = 0, data = 0** (zero padding). The final slice (k = K−1) carries a `last` tag on every live lane.

## 4. Row/column skew

Each lane passes through `tensor_skew`: A lane *i* has `1 + i` registers, B lane *j* has `1 + j` registers.
(The `+1` is a common input register so that no top-level input drives a multiplier combinationally; a uniform extra delay does not change relative alignment. The systolic skew is the `+ i` / `+ j`.)

Let **step** count *enabled* cycles (`pipe_en = 1`) from the first accepted slice, slice *k* being accepted at step *k*. Then

| event | step |
|---|---|
| `A[i][k]` at the A-input pins of PE(i,0) | `k + 1 + i` |
| `B[k][j]` at the B-input pins of PE(0,j) | `k + 1 + j` |

## 5. Wavefront propagation

Every PE forwards both tokens through a register, so one hop costs exactly one enabled cycle (A east, B south):

| event | step |
|---|---|
| `A[i][k]` at PE(i,j) | `k + 1 + i + j` |
| `B[k][j]` at PE(i,j) | `k + 1 + j + i` |

The two are **equal for every (i, j, k)** — the operands of the same reduction index *k* meet at PE(i,j) in the same enabled cycle. Equivalently, at step *s* the PEs with `i + j = s − 1 − k` are the ones processing index *k*: for fixed k the work forms an anti-diagonal front that sweeps from PE(0,0) towards PE(M−1,N−1) at one diagonal per cycle, and successive k follow one cycle behind each other.

## 6. Accumulation cycles

PE(i,j) fires (both tokens valid) at steps `1 + i + j + k` for k = 0 … K−1 — **K consecutive enabled cycles, one MAC per enabled cycle**: window `[1+i+j, K+i+j]`.

* `MUL_PIPE = 0`: the accumulator is updated at the edge that ends the fire step (visible next cycle).
* `MUL_PIPE = 1`: the product is registered at that edge and accumulated at the edge ending the *next* enabled step; commit step = `1 + i + j + k + 1`.

A PE accumulates **only** when `a_valid & b_valid`. Padded operands cannot accumulate: this gating is by the valid bit, independent of the data value, and is independent of the zero-padding of the data (defence in depth, checked separately by mutants m42–m45 and m02).

## 7. Pipeline fill, steady state, drain

| phase | definition (no stalls) |
|---|---|
| **fill** | first fire at PE(0,0) at step 1; the last active PE, PE(M−1,N−1), first fires at step `M + N − 1`. Fill therefore takes `M + N − 2` steps beyond the first fire. |
| **steady state** | all M·N active PEs fire in the same cycle during steps `M+N−1 … K` — exists only if `K ≥ M + N − 1`. For shorter K the array never reaches full concurrency. |
| **drain** | the last slice is accepted at step K−1; the last fire (PE(M−1,N−1), k = K−1) is at step `K + M + N − 2`. |

### Absolute cycle timeline (cfg handshake in cycle *h*, no stalls)

| cycle | state | event |
|---|---|---|
| h | IDLE | `cfg_valid & cfg_ready`; launch accepted |
| h+1 | CLEAR | one-cycle `clr` to all PEs, skew, `align_err` |
| h+2+k | RUN | slice *k* accepted (k = 0 … K−1) |
| h+2+K … | DRAIN | free-running bubbles until every active PE reports `done` |
| h+1+K+M+N+MUL_PIPE | DRAIN (last) | `all_done` = 1 |
| **d = h+2+K+M+N+MUL_PIPE** | **READOUT** | **`tile_done` = 1**, accumulators stable; M result beats follow |

Hence **`busy = d − (h+1) = 1 + K + M + N + MUL_PIPE`** and, with stalls, `+ stall_up + stall_ext`. This identity is asserted by the testbench on every tile.

## 8. Completion

`tile_done` is asserted only in READOUT, entered only when `all_done` — every *active* PE (`row_mask & col_mask`) has raised its sticky `done` flag. A PE raises `done` at the **same clock edge that commits the product tagged `last` (k = K−1)** into its accumulator. Therefore at the first `tile_done` cycle:

1. every required K product has been accumulated in every active PE (the monitor counts exactly K commits per PE),
2. the wavefront has drained (the last useful token has been consumed),
3. the accumulators already equal the final C and stay bit-stable for the whole READOUT (checked every cycle).

The `last` tag travels through the same registers as the data, so completion tracks the **real** PE latency (it automatically includes `MUL_PIPE` and any stall). There is no fixed delay anywhere in the completion path. Mutants that complete early (m30, m32, m55, m62) or late/never (m11, m46) are all detected.

Tokens that are still travelling through *inactive* lanes at completion (A tokens east of column N−1, B tokens south of row M−1) carry no useful data; they are discarded by `clr` at the next launch. That flush is required, not cosmetic: without it a stale forwarded token could present a one-sided valid in an active PE of the next, larger tile (mutant m16, killed).

## 9. Token alignment and the checker

Every operand token carries `{valid, last, k-index, data}`. With `CHECK_ALIGN = 1` each PE flags (sticky `align_err` at the top):

1. both tokens valid with **different k-index**,
2. both valid with different `last` tags,
3. PE is inside the active M×N region but only one token is valid (token missing / skew wrong). One-sided valid *outside* the active region is legitimate padding and is not flagged.

Independently of the in-array checker, the testbench monitor checks, for **every PE on every enabled cycle**, that the data at the PE pins equals `A[i][k]` / `B[k][j]` for the *ideal* k = step − 1 − i − j — it compares against the operand source, not against the RTL's own k-index. Mismatched-skew mutants (m59, m60, m23, m20) are detected by both mechanisms.

## 10. Stall protocol

One **global pipeline enable**:

```
pipe_en = ~stall_i & ( RUN ? s_valid : DRAIN )
```

* RUN: the array advances exactly when a slice is accepted. A missing slice or `stall_i` freezes *everything* — skew registers, PE forwarding registers, product registers, accumulators, `done` flags. No bubbles are injected.
* DRAIN: free-running unless `stall_i`.
* No PE is ever stalled independently, so relative timing between PEs can never be corrupted.

Consequences (all checked): operand alignment preserved (the monitor works in *enabled-step* time, so every formula above still holds under arbitrary stalls); partial sums preserved (accumulators and forwarding registers compared bit-exactly across every frozen cycle); no duplicate or dropped MAC (exactly K commits per PE, each at its expected step); correct resume.

**What "downstream backpressure" means here — stated plainly.** In an output-stationary single-tile design results are not produced until the tile is complete, so `m_ready` backpressure can only occur during READOUT, where it paces the row sequencer; the accumulators are static there and cannot be disturbed. Backpressure that must freeze an *in-flight* computation (a downstream consumer or shared resource refusing progress mid-tile) is provided by `stall_i`, which is exercised with random, bursty, periodic, fill-time, drain-time and completion-edge patterns (profiles in `tb_array.sv`).

## 11. Result extraction

In READOUT, row sequencer `rd_row` runs 0 … M−1, one beat per `m_valid & m_ready`. `m_data` lane *j* = `C[rd_row][j]` (lanes ≥ N read 0, `m_col_mask` marks active lanes). After the last beat the FSM returns to IDLE.

## 12. Partial tiles and K

* **K = 1, K < array dims, K > array dims:** K is streamed in time, independent of the array size; all are supported (K = 1 … `2^K_WIDTH − 1`).
* **Partial M/N tiles:** `cfg_m`/`cfg_n` build row/column masks; inactive lanes are zero-padded and invalid; inactive PEs never accumulate.
* **M or N larger than the array:** the array computes one tile per launch. Larger matrices are tiled by the *host* (the testbench does this: `ceil(M/ROWS) × ceil(N/COLS)` launches, tested with partial edge tiles).

## 13. Not implemented (honest limits)

* **One tile in flight.** The next tile cannot start while the previous one is still being read out; there is no result double-buffer. Back-to-back tiles therefore pay the launch (1) + drain (`M+N+MUL_PIPE`) overhead each time. Overlapping tiles would need a per-PE result capture register bank (`ROWS·COLS·ACC_WIDTH` FFs) or a shift-out scheme.
* **No K-tiling across launches** (no accumulate-in-place); K is bounded by `K_WIDTH`.
* **No saturation / overflow flag**; accumulation wraps (documented in `CONFIGURATION.md`).
* **No timing/Fmax claim** — see `SYNTHESIS.md`.
