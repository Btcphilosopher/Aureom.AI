# Verification — TENSORCORE 02

## 1. Strategy (independent layers)

| layer | what it is | independent of |
|---|---|---|
| **Numpy GEMM oracle** | `tools/gen_vectors.py` computes every expected C in exact int64 and wraps to `ACC_WIDTH` | RTL and SystemVerilog |
| **In-testbench SV oracle** | a signed-integer triple-loop GEMM recomputed from the operand sources; cross-checks the numpy vectors (`ORACLE MISMATCH` otherwise) | the numpy code |
| **Wavefront monitor** | per PE, every enabled cycle: token validity, operand *data* vs `A[i][k]`/`B[k][j]` at the ideal k, `last` tag, k-index, fire/commit step, done flag == (commits == K); freeze invariance; exactly K commits per PE; accumulators == expected *at the first `tile_done` cycle* and stable during READOUT | the RTL's own checker and k-index sideband |
| **Directed tests** | illegal-config rejection, reset during RUN / DRAIN / READOUT, `align_err` latch/sticky/clear (fault injected with `force`) | — |
| **PE unit test** | literal-number directed checks (latency, freeze, valid gating, extremes, `clr`, checker) + 200 000-cycle random comparison with a behavioural model, over 11 width/latency/checker combinations | the array |
| **Two simulators** | Icarus 12 and Verilator 5.020 run the same testbench; vector-test lines, including every cycle count, are required to be identical | each other |
| **Mutation testing** | 47 injected RTL bugs; see §5 | — |
| **Lint** | `verilator --lint-only -Wall` over 11 parameter combinations | — |

Testbench discipline: all TB-driven inputs change by non-blocking assignment at a clock edge; the main flow reads only edge-sampled registers after `@(posedge clk); #1`; shared variables have exactly one writer. (A race in an earlier version made Verilator miss handshakes; it was found *because* both simulators were run, and fixed.)

## 2. Brief §9 coverage map

| requirement | where it is tested |
|---|---|
| 1×1 matrix multiplication | category `m1x1` (9 tests: signs, zeros, extremes) on every configuration, incl. a 1×1 array |
| 4×4 output tiles | every `ksweep`/`random`/`negative`/`identity`/`stall` test on the 4×4 baseline |
| K = 1, 3, 4, 7, 16, 257 | category `ksweep`: each K × six tile shapes ((R,C), (1,1), (R,1), (1,C), (R−1,C−1), (2,3)) |
| partial rows and columns | category `partial`: **every** (M,N) with 1≤M≤ROWS, 1≤N≤COLS (e.g. all 256 on 16×16) + multi-tile `gemm` with partial edge tiles |
| negative operands | `negative` (all sign-extreme combinations, constants at the minimum/maximum), `extreme` |
| all-zero operands | `zero` (0×0, 0×rand, rand×0, 1×1) |
| identity-like matrices | `identity` (I·B, A·I, −I·B, permutation, rectangular, K ≷ array size) |
| repeated tiles | `repeat` (same tile ×6, partial tile ×4) + every multi-tile `gemm` (back-to-back launches) |
| reset | directed: reset during RUN (tokens in flight), DRAIN and READOUT, then fresh tiles of other shapes must be exact; counters/flags checked clean |
| backpressure / stalls | `stall` (8 `stall_i` profiles × 5 upstream-gap profiles × 3 shapes on the baseline; readout pacing profiles) + `random` with random profiles |
| long accumulation | `longk`: K = 255/1000/4096/5000, 65535, **131071** (largest INT8→INT32 overflow-free K) incl. random hash operands |
| different array dimensions | 1×1, 1×4, 4×1, 2×2, 2×4, 4×2, 3×5, 5×3, 4×4, 8×8, 16×16 |
| additional | `MUL_PIPE` 0/1; (DW,ACC) = (8,16), (8,24), (4,16), (12,32), (16,32); K_WIDTH 8/17/18; checker/perf off; INT32 wraparound at K = 131072 |

## 3. Regression result (final run on frozen sources)

Total wall time 820 s.  Overall: **PASS**

| config | R x C | DW/ACC/KW | MUL_PIPE | CHECK/PERF | vector tests | simulator | result | tests passed (incl. directed) | tiles | cross-sim |
|---|---|---|---|---|---|---|---|---|---|---|
| 2x2_L1 | 2x2 | 8/32/17 | 0 | 1/1 | 313 | icarus | PASS | 326 | 361 | identical (666 lines) |
| 2x2_L1 | 2x2 | 8/32/17 | 0 | 1/1 | 313 | verilator | PASS | 323 | 359 | identical (666 lines) |
| 4x4_L2 | 4x4 | 8/32/17 | 0 | 1/1 | 420 | icarus | PASS | 433 | 465 | identical (877 lines) |
| 4x4_L2 | 4x4 | 8/32/17 | 0 | 1/1 | 420 | verilator | PASS | 430 | 463 | identical (877 lines) |
| 1x1_L1 | 1x1 | 8/32/17 | 0 | 1/1 | 292 | icarus | PASS | 305 | 347 | - |
| 1x4_L1 | 1x4 | 8/32/17 | 0 | 1/1 | 307 | icarus | PASS | 320 | 354 | - |
| 4x1_L1 | 4x1 | 8/32/17 | 0 | 1/1 | 313 | icarus | PASS | 326 | 365 | - |
| 2x4_L1 | 2x4 | 8/32/17 | 0 | 1/1 | 329 | icarus | PASS | 342 | 374 | - |
| 4x2_L1 | 4x2 | 8/32/17 | 0 | 1/1 | 329 | icarus | PASS | 342 | 377 | - |
| 3x5_L1 | 3x5 | 8/32/17 | 0 | 1/1 | 336 | icarus | PASS | 349 | 381 | identical (709 lines) |
| 3x5_L1 | 3x5 | 8/32/17 | 0 | 1/1 | 336 | verilator | PASS | 346 | 379 | identical (709 lines) |
| 5x3_L1 | 5x3 | 8/32/17 | 0 | 1/1 | 336 | icarus | PASS | 349 | 381 | - |
| 2x2_MP1_L1 | 2x2 | 8/32/17 | 1 | 1/1 | 313 | icarus | PASS | 326 | 361 | identical (666 lines) |
| 2x2_MP1_L1 | 2x2 | 8/32/17 | 1 | 1/1 | 313 | verilator | PASS | 323 | 359 | identical (666 lines) |
| 4x4_MP1_L1 | 4x4 | 8/32/17 | 1 | 1/1 | 337 | icarus | PASS | 350 | 382 | identical (711 lines) |
| 4x4_MP1_L1 | 4x4 | 8/32/17 | 1 | 1/1 | 337 | verilator | PASS | 347 | 380 | identical (711 lines) |
| 3x5_MP1_L1 | 3x5 | 8/32/17 | 1 | 1/1 | 336 | icarus | PASS | 349 | 381 | - |
| 4x4_DW8_ACC16 | 4x4 | 8/16/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 4x4_DW8_ACC24 | 4x4 | 8/24/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 4x4_DW4_ACC16 | 4x4 | 4/16/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 4x4_DW12_ACC32 | 4x4 | 12/32/17 | 0 | 1/1 | 342 | icarus | PASS | 355 | 387 | - |
| 3x3_DW16_ACC32 | 3x3 | 16/32/17 | 0 | 1/1 | 335 | icarus | PASS | 348 | 380 | - |
| 4x4_NOCHECK | 4x4 | 8/32/17 | 0 | 0/1 | 337 | icarus | PASS | 347 | 380 | - |
| 4x4_NOPERF | 4x4 | 8/32/17 | 0 | 1/0 | 337 | icarus | PASS | 350 | 382 | - |
| 4x4_KW8 | 4x4 | 8/32/8 | 0 | 1/1 | 330 | icarus | PASS | 343 | 375 | - |
| 2x2_KW18_L2 | 2x2 | 8/32/18 | 0 | 1/1 | 398 | verilator | PASS | 408 | 444 | - |
| 8x8_L1 | 8x8 | 8/32/17 | 0 | 1/1 | 385 | verilator | PASS | 395 | 428 | - |
| 8x8_MP1_L0 | 8x8 | 8/32/17 | 1 | 1/1 | 173 | verilator | PASS | 183 | 216 | - |
| 16x16_L1 | 16x16 | 8/32/17 | 0 | 1/1 | 577 | verilator | PASS | 587 | 620 | - |

## PE unit test (tb/tb_pe.sv)

| DATA_WIDTH | ACC_WIDTH | MUL_PIPE | CHECK_ALIGN | result | checks | errors |
|---|---|---|---|---|---|---|
| 8 | 32 | 0 | 1 | PASS | 2000027 | 0 |
| 8 | 32 | 1 | 1 | PASS | 2000027 | 0 |
| 8 | 32 | 0 | 0 | PASS | 2000027 | 0 |
| 8 | 32 | 1 | 0 | PASS | 2000027 | 0 |
| 4 | 8 | 0 | 1 | PASS | 2000007 | 0 |
| 4 | 8 | 1 | 1 | PASS | 2000007 | 0 |
| 8 | 16 | 0 | 1 | PASS | 2000007 | 0 |
| 8 | 16 | 1 | 1 | PASS | 2000007 | 0 |
| 12 | 32 | 1 | 1 | PASS | 2000027 | 0 |
| 16 | 32 | 0 | 1 | PASS | 2000027 | 0 |
| 2 | 4 | 0 | 1 | PASS | 2000007 | 0 |


Overall: **PASS**.  Per-run logs: `logs/reg_<config>_<simulator>.log`.

Rows with both simulators additionally required the TEST/PERF lines of the two logs to be **identical** (shown in the *cross-sim* column).

## 4. Lint

| configuration | `verilator --lint-only -Wall` |
|---|---|
| 1x1 | clean |
| 1x4 | clean |
| 2x2 | clean |
| 4x4 (baseline) | clean |
| 3x5 | clean |
| 8x8 | clean |
| 16x16 | clean |
| 4x4 MUL_PIPE=1 | clean |
| 4x4 CHECK_ALIGN=0 PERF_EN=0 | clean |
| 4x4 DW=4 ACC=8 | clean |
| 4x4 DW=16 ACC=32 K_WIDTH=8 | clean |

Waivers (in the RTL, with reasons): unused edge/debug bus bits and `fire_flat` (verification visibility); vacuous upper-bound compares on `cfg_m`/`cfg_n` when their width cannot exceed the array size; `n_q` unused when `PERF_EN = 0`.

## 5. Mutation testing

Mutants: 47   **killed: 44**   survived: 3   invalid: 0   (wall time 65 s)

Each mutant is a one-site change to a copy of the RTL; it is *killed* if the PE unit test (MUL_PIPE 0/1) or the array testbench (2×2 MUL_PIPE=0 and 3×2 MUL_PIPE=1, level-0 vectors + directed tests) reports anything other than PASS. The unmutated baseline passes everything.

| id | status | mutation | killed by | first detector message |
|---|---|---|---|---|
| m00 | BASELINE_OK | UNMUTATED BASELINE |  |  |
| m01 | KILLED | PE accumulates when only the A token is valid | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=210000: D3 acc unchanged by invalid tokens (7623, 0) |
| m02 | KILLED | PE ignores token valid entirely (relies on zero data) | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=210000: D3 acc unchanged by invalid tokens (11661, 0) |
| m03 | KILLED | accumulator subtracts | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=60000: D1 acc visible after 1 en-cycle (MP0) (-15, 15) |
| m04 | KILLED | product ZERO-extended instead of sign-extended | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 acc held during freeze (65473, -63) |
| m05 | KILLED | unsigned multiply | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 acc held during freeze (2241, -63) |
| m06 | KILLED | done raised on first MAC instead of the last-tagged MAC | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 not done during freeze (1, 0) |
| m07 | KILLED | PE ignores the global enable (advances during stall) | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 acc held during freeze (29937, -63) |
| m08 | KILLED | done flag not cleared at tile launch / reset | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=120000: D2 not done during freeze (1, 0) |
| m09 | KILLED | alignment checker: k-index compare inverted | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=311000: D6 matched tokens -> no err (1, 0) |
| m10 | KILLED | alignment checker permanently disabled | PE mp0, PE mp1 | PE mp0: FAIL -- PE_ERROR t=312000: D6 k-index mismatch flagged (0, 1) |
| m11 | KILLED | MUL_PIPE=1: last tag lost in product stage | PE mp1, 3x2_mp1 | PE mp1: FAIL -- PE_ERROR t=70000: D1 done after MAC latency (0, 1) |
| m12 | KILLED | MUL_PIPE=1: done taken from input stage (1 cycle early) | PE mp1, 3x2_mp1 | PE mp1: FAIL -- PE_ERROR t=70000: D1 done after MAC latency (0, 1) |
| m13 | KILLED | commit event not qualified by en | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=665000: commit_o mismatch (1, 0) |
| m14 | KILLED | B forwarding drops the last token's valid | PE mp0, PE mp1, 2x2_mp0, 3x2_mp1 | PE mp0: FAIL -- PE_ERROR t=635000: fwd valid mismatch (0, 0) |
| m15 | SURVIVED | MUL_PIPE=1: product register updated even without valid (benign) |  |  |
| m16 | KILLED | PE clr does not flush stale forwarded A tokens (stragglers survive launch) | PE mp0, PE mp1, 2x2_mp0 | PE mp0: FAIL -- PE_ERROR t=280000: D5 fwd valid cleared (1, 0) |
| m20 | KILLED | skew depth off by one on lanes >= 2 | 3x2_mp1 | 3x2_mp1: FAIL -- MONITOR_ERROR t=1285000 cyc=129 test=13: A valid mismatch PE (2,0,0) |
| m21 | KILLED | skew network ignores the global enable | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=16705000 cyc=1671 test=65: A tokens moved during freeze (0,0,0) |
| m22 | SURVIVED | skew network not flushed at tile launch |  |  |
| m23 | KILLED | skew taps first stage (no skew at all) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=865000 cyc=87 test=10: B valid mismatch PE (0,1,-1) |
| m30 | KILLED | completion when ANY active PE is done | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=126000 test=0: busy cycles != 1+K+M+N+MP+stalls (3,4) |
| m31 | KILLED | readout mux selects the wrong row | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=136000 test=0: RESULT MISMATCH C[idx] (0,0) |
| m32 | KILLED | completion looks only at PE(0,0) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=896000 test=10: busy cycles != 1+K+M+N+MP+stalls (4,5) |
| m33 | SURVIVED | readout does not mask columns outside N |  |  |
| m40 | KILLED | row mask one row too wide | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: A valid mismatch PE (1,0,0) |
| m41 | KILLED | column mask one column too narrow | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=105000 cyc=11 test=0: B valid mismatch PE (0,0,0) |
| m42 | KILLED | A lanes not zero-padded | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: A pad data nonzero PE (0,0,0) |
| m43 | KILLED | B lanes not zero-padded | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: B pad data nonzero PE (0,0,0) |
| m44 | KILLED | A rows beyond M injected as valid (padding not masked) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: A valid mismatch PE (1,0,0) |
| m45 | KILLED | B columns beyond N injected as valid (padding not masked) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=115000 cyc=12 test=0: B valid mismatch PE (0,1,0) |
| m46 | KILLED | last tag one slice late | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=40706000 test=0: readout timeout (0,0) |
| m47 | KILLED | array advances in RUN even when no slice is valid | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=17365000 cyc=1737 test=66: pipe_en != s_valid&~stall in RUN (0,0,0) |
| m48 | KILLED | global enable ignores stall_i | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=16695000 cyc=1670 test=65: pipe_en != s_valid&~stall in RUN (0,0,0) |
| m49 | KILLED | slice accepted while stalled (dropped/duplicated operand) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=16695000 cyc=1670 test=65: s_ready != ~stall in RUN (0,0,0) |
| m50 | KILLED | k counter advances on s_valid instead of the handshake | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=16706000 test=65: s_k != expected slice index (8,7) |
| m51 | KILLED | M = 0 accepted | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=42956000 test=102: illegal cfg not rejected (no pulse) (0,0) |
| m52 | KILLED | K = 0 accepted | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=42996000 test=102: illegal cfg not rejected (no pulse) (2,0) |
| m53 | KILLED | m_last one row late | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=126000 test=0: m_last wrong (0,0) |
| m54 | KILLED | tile-launch clear removed | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=165000 cyc=17 test=1: done flag mismatch PE (0,0,0) |
| m55 | KILLED | tile completion without waiting for the wavefront to drain | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=126000 test=0: busy cycles != 1+K+M+N+MP+stalls (3,4) |
| m56 | KILLED | useful-MAC counter over-counts | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=136000 test=0: perf_mac != M*N*K (5,1) |
| m57 | KILLED | padding-slot counter over-counts | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- TB_ERROR t=136000 test=0: perf_pad != (R*C-M*N)*K (4,3) |
| m58 | KILLED | align_err not cleared at tile launch | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=43285000 cyc=4329 test=9061: align_err asserted (0,0,0) |
| m59 | KILLED | B skew one stage too deep (A/B misaligned by 1) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=105000 cyc=11 test=0: B valid mismatch PE (0,0,0) |
| m60 | KILLED | A skew one stage too shallow (A/B misaligned by 1) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=95000 cyc=10 test=0: A valid mismatch PE (0,0,-1) |
| m61 | KILLED | A k-index metadata lost (data path untouched) | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=675000 cyc=68 test=8: A kidx PE (0,0,1) |
| m62 | KILLED | tile_done asserted during DRAIN | 2x2_mp0, 3x2_mp1 | 2x2_mp0: FAIL -- MONITOR_ERROR t=105000 cyc=11 test=0: tile_done != m_valid (1,0,0) |

### Survivors, each examined

* **m15** — MUL_PIPE=1: product register updated even without valid (benign): equivalent: with MUL_PIPE=1 the product register may load garbage when no operand is valid, but its commit is gated by `prod_vld_q`.
* **m22** — skew network not flushed at tile launch: redundant: by the time `all_done` fires the skew network holds only all-zero bubbles (the last token has traversed <= M lane stages and DRAIN lasts M+N+MUL_PIPE steps), so the launch flush changes nothing; kept as defence.
* **m33** — readout does not mask columns outside N: equivalent: inactive PEs hold zero (cleared at launch, never accumulate), so masking unread columns changes no output; kept as defence in depth.

Mutation history worth knowing: the first mutation run left **m58** (`align_err` not cleared at launch) and **m62** (`tile_done` asserted during DRAIN) alive. Both were genuine test gaps — the testbench never observed the `tile_done` port and never provoked an alignment error — and were closed by direct port checks and a fault-injection test. A mutant that skips the PE's launch flush (m16) is killed, which is what proves the straggler-token flush is *necessary*.

## 6. Bugs found by the testing (not by inspection)

| found by | defect | fix |
|---|---|---|
| first 2×2 run (TB vs RTL counters) | `perf_stall_ext` over-counted a stall landing in the cycle completion is detected (delays nothing) | RTL counter counts effective stalls only |
| Verilator vs Icarus | testbench sampled handshakes at the clock edge (scheduler-dependent) | edge-sampler registers + `tick` |
| Yosys elaboration | `int'()` cast not accepted by the synthesis front end | `32'()` size casts |
| mutation run | `tile_done` / `align_err` unchecked | direct monitor checks, fault injection |
| 1×1 regression | reset-during-DRAIN trigger could never fire on a 2-cycle DRAIN | trigger scales with array size |
| K_WIDTH=8 regression | vector generator emitted K > K_max | generator respects K_WIDTH |

## 7. What this verification does **not** show

* **Simulation only.** No formal proof, no gate-level or timing simulation, no hardware.
* The `force`-based `align_err` test runs on Icarus only (Verilator does not support forcing that net). The checker itself is also covered at PE level on both.
* Several configurations (1×1, 1×4, 4×1, 2×4, 4×2, 5×3, the width variants, checker/perf off, K_WIDTH=8) ran on Icarus only; 8×8, 16×16 and K_WIDTH=18 ran on Verilator only. The cross-simulator identity check covers 2×2, 3×5, 4×4 (and `MUL_PIPE=1`).
* Mutation testing uses small configurations and level-0 vectors; it measures the strength of the checks, not coverage of the whole RTL.
* The wavefront monitor is white-box (hierarchical references into the DUT); the interface-level checks (results, handshakes, ports) are black-box.
* Operand and accumulator widths up to 32-bit accumulators only in the shipped vector format.
