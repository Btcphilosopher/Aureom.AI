# Performance — measured

All figures below are **measured in simulation** by the testbench (one record per tile launch, cross-checked against the RTL performance counters and against the closed-form identity `busy = 1 + K + M + N + MUL_PIPE`). No timing/Fmax figure is claimed (no place-and-route here); see `SYNTHESIS.md`.

## 1. Counting conventions

| quantity | definition |
|---|---|
| MAC issue cycles | cycles in which a k-slice is accepted = K |
| useful MACs | MACs committed by PEs inside the active M×N region = M·N·K (counted from the PE commit strobes) |
| padding slots | PE-slots occupied by padded lanes, per issued slice: `ROWS·COLS − M·N`; per tile `(ROWS·COLS − M·N)·K`. (K is streamed, so there is **no K padding**.) |
| busy cycles | CLEAR + RUN + DRAIN = `1 + K + M + N + MUL_PIPE` + stalls |
| fill/drain overhead | `busy − K − stalls = 1 + M + N + MUL_PIPE` (1 launch cycle + diagonal fill/drain; fill overlaps RUN, drain follows it) |
| stall cycles | `stall_up` (no slice offered) + `stall_ext` (effective `stall_i`) |
| array utilisation | `useful MACs / (ROWS·COLS · busy)` — includes launch, fill, drain and padding; excludes readout beats |
| spatial utilisation | `M·N / (ROWS·COLS)` — the padding-only bound reached as K → ∞ |
| peak MAC/cycle | `ROWS·COLS`, **demonstrated**: every active PE commits in K consecutive enabled cycles (monitor, every tile), and §3 shows the cycle count with all PEs committing simultaneously |
| integer ops | **convention: 1 MAC = 2 integer operations** (multiply + add), so peak = `2·ROWS·COLS` ops/cycle |

## 2. 4×4 baseline, full 4×4 tile, K sweep (no stalls)

| K | busy | issue | overhead (busy−K) | useful MACs | array utilisation | peak MAC/cycle | achieved MAC/cycle (over busy) | ops/cycle (2/MAC) |
|---|---|---|---|---|---|---|---|---|
| 1 | 10 | 1 | 9 | 16 | 10.0 % | 16 | 1.60 | 3.2 (peak 32) |
| 3 | 12 | 3 | 9 | 48 | 25.0 % | 16 | 4.00 | 8.0 (peak 32) |
| 4 | 13 | 4 | 9 | 64 | 30.8 % | 16 | 4.92 | 9.8 (peak 32) |
| 7 | 16 | 7 | 9 | 112 | 43.8 % | 16 | 7.00 | 14.0 (peak 32) |
| 16 | 25 | 16 | 9 | 256 | 64.0 % | 16 | 10.24 | 20.5 (peak 32) |
| 257 | 266 | 257 | 9 | 4112 | 96.6 % | 16 | 15.46 | 30.9 (peak 32) |
| 1000 | 1009 | 1000 | 9 | 16000 | 99.1 % | 16 | 15.86 | 31.7 (peak 32) |

* K = 131071, tile 4×4: busy = 131080 (= 1 + K + M + N), MACs = 2097136, utilisation = 99.993 % of the 16 PEs (full tile).
* K = 65535, tile 1×1: busy = 65538 (= 1 + K + M + N), MACs = 65535, utilisation = 6.250 % of the 16 PEs (partial tile, so spatial utilisation is 6.25 %).

## 3. Fill / steady state / drain for the full 4×4 tile

For a full tile (M = N = 4) the number of enabled cycles in which **all 16 PEs commit simultaneously** is `K − (M+N−2) = K − 6` when `K ≥ 7`, and 0 otherwise (the array never reaches full concurrency). This is **checked against the waveform**: in `waves/4x4_K10_steady.vcd` (K = 10) exactly 4 cycles have all 16 PEs committing; each of the levels 1, 3, 6, 10, 13, 15 occurs twice (ramp-up and ramp-down) (`waves/4x4_K10_steady_concurrency.txt`, generated from the VCD and asserted by the build). The last MAC lands `M+N-1` steps after the last slice is accepted; the DRAIN *state* lasts `M+N+MUL_PIPE` cycles.

| K | full-concurrency cycles = max(K−6,0) | step of first MAC at PE(3,3) (= M+N−1) | DRAIN-state cycles (= M+N) |
|---|---|---|---|
| 1 | 0 | 7 | 8 |
| 3 | 0 | 7 | 8 |
| 4 | 0 | 7 | 8 |
| 7 | 1 | 7 | 8 |
| 16 | 10 | 7 | 8 |
| 257 | 251 | 7 | 8 |

## 4. Partial tiles on the 4×4 array (K = 5, no stalls)

| M | N | busy | useful MACs | padding slots | array utilisation | spatial utilisation |
|---|---|---|---|---|---|---|
| 1 | 1 | 8 | 5 | 75 | 3.9 % | 6.2 % |
| 1 | 2 | 9 | 10 | 70 | 6.9 % | 12.5 % |
| 1 | 3 | 10 | 15 | 65 | 9.4 % | 18.8 % |
| 1 | 4 | 11 | 20 | 60 | 11.4 % | 25.0 % |
| 2 | 1 | 9 | 10 | 70 | 6.9 % | 12.5 % |
| 2 | 2 | 10 | 20 | 60 | 12.5 % | 25.0 % |
| 2 | 3 | 11 | 30 | 50 | 17.0 % | 37.5 % |
| 2 | 4 | 12 | 40 | 40 | 20.8 % | 50.0 % |
| 3 | 1 | 10 | 15 | 65 | 9.4 % | 18.8 % |
| 3 | 2 | 11 | 30 | 50 | 17.0 % | 37.5 % |
| 3 | 3 | 12 | 45 | 35 | 23.4 % | 56.2 % |
| 3 | 4 | 13 | 60 | 20 | 28.8 % | 75.0 % |
| 4 | 1 | 11 | 20 | 60 | 11.4 % | 25.0 % |
| 4 | 2 | 12 | 40 | 40 | 20.8 % | 50.0 % |
| 4 | 3 | 13 | 60 | 20 | 28.8 % | 75.0 % |
| 4 | 4 | 14 | 80 | 0 | 35.7 % | 100.0 % |

## 5. Array-size comparison (full tile, no stalls, MUL_PIPE = 0)

| array | K | busy | overhead | useful MACs | array utilisation | peak MAC/cycle |
|---|---|---|---|---|---|---|
| 2×2 | 16 | 21 | 5 | 64 | 76.2 % | 4 |
| 2×2 | 257 | 262 | 5 | 1028 | 98.1 % | 4 |
| 4×4 | 16 | 25 | 9 | 256 | 64.0 % | 16 |
| 4×4 | 257 | 266 | 9 | 4112 | 96.6 % | 16 |
| 8×8 | 16 | 33 | 17 | 1024 | 48.5 % | 64 |
| 8×8 | 257 | 274 | 17 | 16448 | 93.8 % | 64 |
| 16×16 | 16 | 49 | 33 | 4096 | 32.7 % | 256 |
| 16×16 | 257 | 290 | 33 | 65792 | 88.6 % | 256 |

Larger arrays have a larger fixed overhead (`1 + M + N`) and need a larger K to amortise it; they also **only reach full concurrency for `K ≥ M+N−1`** (31 for 16×16).

## 6. Effect of the PE product register (MUL_PIPE)

| array | K | busy MUL_PIPE=0 | busy MUL_PIPE=1 | difference |
|---|---|---|---|---|
| 2×2 | 1 | 6 | 7 | +1 |
| 2×2 | 16 | 21 | 22 | +1 |
| 2×2 | 257 | 262 | 263 | +1 |
| 4×4 | 1 | 10 | 11 | +1 |
| 4×4 | 16 | 25 | 26 | +1 |
| 4×4 | 257 | 266 | 267 | +1 |

Throughput is unchanged (1 MAC/PE/cycle); `MUL_PIPE=1` adds exactly one cycle of latency per tile.

## 7. Stall accounting (stall tests, all array shapes in the regression)

5622 tiles ran with injected stalls/bubbles across the regression (upstream gaps: 117774 cycles, effective `stall_i`: 128105 cycles, of 476318 busy cycles). The identity `busy = 1 + K + M + N + MUL_PIPE + stall_up + stall_ext` held on **5622 / 5622** of them. Results were bit-identical to the oracle in every case.

## 8. What is *not* reported

* No clock frequency, so no GOPS figure: only cycle counts and ops/cycle are claimed.
* Readout beats (M per tile) are excluded from `busy`; with one tile in flight they add M cycles per tile before the next launch.

