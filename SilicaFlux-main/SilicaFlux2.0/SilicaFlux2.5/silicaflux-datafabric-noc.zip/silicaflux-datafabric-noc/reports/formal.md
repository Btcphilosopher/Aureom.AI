# Formal results

Yosys 0.33 (git sha1 2584903a060); BMC with ABC bmc3 (bit level) and, as an independent second engine, yosys-smtbmc + Z3 version 5.4.0 - 64 bit (word level, shorter depth); unbounded proofs with ABC PDR (yosys-abc, budget 900 s).  `expect FAIL` rows are non-vacuity checks: the same harness on one deliberately broken RTL file must give a counterexample.  UNKNOWN = PDR budget reached: the property then holds only to the BMC depth.

**38 / 38 jobs as expected: 21 unbounded proofs, 0 bounded only, 17 mutants caught.**

| job | harness | params | BMC (abc bmc3) | BMC (smtbmc+z3) | unbounded | expect | verdict | note | s |
|---|---|---|---|---|---|---|---|---|---|
| fifo_d1 | fv_sfn_fifo | {'W': 4, 'DEPTH': 1} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 0.5 |
| fifo_d3 | fv_sfn_fifo | {'W': 4, 'DEPTH': 3} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 1.8 |
| fifo_d4 | fv_sfn_fifo | {'W': 4, 'DEPTH': 4} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 2.7 |
| fifo_d1_pass | fv_sfn_fifo | {'W': 4, 'DEPTH': 1, 'PASS_FULL': 1} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 0.4 |
| fifo_d3_pass | fv_sfn_fifo | {'W': 4, 'DEPTH': 3, 'PASS_FULL': 1} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 2.1 |
| qos_arb_n3_s2 | fv_sfn_qos_arbiter | {'N': 3, 'STARVE': 2} | PASS depth 24 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 1.8 |
| qos_arb_n4_s1 | fv_sfn_qos_arbiter | {'N': 4, 'STARVE': 1} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 3.4 |
| qos_arb_n3_s0 | fv_sfn_qos_arbiter | {'N': 3, 'STARVE': 0} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 1.0 |
| qos_arb_n5_s4 | fv_sfn_qos_arbiter | {'N': 5, 'STARVE': 4} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 4.2 |
| mst_port_full | fv_sfn_mst_port | {'EN': "2'b11"} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 9.8 |
| mst_port_denied | fv_sfn_mst_port | {'EN': "2'b01"} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 6.7 |
| mst_port_bypass | fv_sfn_mst_port | {'EN': "2'b11", 'BYP': 1} | PASS depth 16 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 9.9 |
| xbar_rr | fv_sfn_xbar | {'TOPO': 1, 'ARB': 1} | PASS depth 12 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 5.7 |
| xbar_fixed | fv_sfn_xbar | {'TOPO': 1, 'ARB': 0} | PASS depth 12 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 5.1 |
| xbar_qos | fv_sfn_xbar | {'TOPO': 1, 'ARB': 2} | PASS depth 12 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 5.6 |
| sbus_rr | fv_sfn_xbar | {'TOPO': 0, 'ARB': 1} | PASS depth 12 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 2.6 |
| sbus_qos | fv_sfn_xbar | {'TOPO': 0, 'ARB': 2} | PASS depth 12 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 3.0 |
| mut_fifo_overflow | fv_sfn_fifo | {'W': 4, 'DEPTH': 3} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | FIFO accepts when full | 0.3 |
| mut_fifo_rd_ptr | fv_sfn_fifo | {'W': 4, 'DEPTH': 3} | FAIL (counterexample) | PASS depth 8 | - | FAIL | OK | pointer wraps one entry late (non-power-of-two depth) | 0.9 |
| mut_qos_frozen_ptr | fv_sfn_qos_arbiter | {'N': 3, 'STARVE': 1} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | round-robin pointer frozen -> starvation | 0.8 |
| mut_qos_no_aging | fv_sfn_qos_arbiter | {'N': 3, 'STARVE': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | aging removed -> low QoS level starves | 0.8 |
| mut_qos_no_lock | fv_sfn_qos_arbiter | {'N': 3, 'STARVE': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | grant lock removed | 0.7 |
| mut_port_no_id_rule | fv_sfn_mst_port | {'EN': "2'b11"} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | O2 removed | 1.0 |
| mut_port_orphan | fv_sfn_mst_port | {'EN': "2'b11"} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | orphan check ignores the target | 1.0 |
| mut_port_fence | fv_sfn_mst_port | {'EN': "2'b11"} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | O3 removed | 0.8 |
| mut_xbar_rsp_src | fv_sfn_xbar | {'TOPO': 1, 'ARB': 1} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | response steered regardless of source | 1.5 |
| mut_xbar_no_lock | fv_sfn_xbar | {'TOPO': 1, 'ARB': 1} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | arbiter not told about target back-pressure (no grant lock) | 1.6 |
| mut_sbus_ready | fv_sfn_xbar | {'TOPO': 0, 'ARB': 1} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | shared bus uses the wrong target ready | 1.3 |
| router_d2 | fv_sfn_router | {'DEPTH': 2} | PASS depth 14 | PASS depth 6 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 503.7 |
| router_d3 | fv_sfn_router | {'DEPTH': 3} | PASS depth 12 | PASS depth 5 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 898.5 |
| mut_router_no_wormhole | fv_sfn_router | {'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | output released after the head flit (packets interleave) | 3.6 |
| mut_router_no_credit | fv_sfn_router | {'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | flit sent without a credit | 66.2 |
| mut_router_yx | fv_sfn_router | {'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | route Y before X | 3.6 |
| mut_router_credit_lost | fv_sfn_router | {'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | returned credit ignored | 11.5 |
| ni_pair_d2 | fv_sfn_ni | {'DEPTH': 2} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 5.0 |
| ni_pair_d4 | fv_sfn_ni | {'DEPTH': 4} | PASS depth 20 | PASS depth 8 | PROVED (unbounded, ABC PDR) | PASS | OK |  | 113.8 |
| mut_ni_drop_head | fv_sfn_ni | {'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | two-flit head not latched (header of the data flit used) | 0.4 |
| mut_ni_no_credit_wait | fv_sfn_ni | {'DEPTH': 2} | FAIL (counterexample) | FAIL (counterexample) | - | FAIL | OK | packetiser sends without a credit | 0.4 |
