# SilicaFlux DataFabric-NoC -- verification and PPA summary

Generated 2026-11-10 14:48 UTC by `scripts/report.py` from the JSON reports in this directory.  Source: btcphilosopher/Aureom.AI branch claude/kind-gates-dm75tm @ 8158b9d (SilicaFlux-main archives; nothing committed).

## Tools

| tool | version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| z3 (smtbmc) | Z3 version 5.4.0 - 64 bit |
| python | Python 3.13.18 |
| sby | not installed |
| openroad | not installed |

## Source hashes (sha256 over relative paths + contents)

| tree | sha256 |
|---|---|
| rtl | `8e0bb719556092df078cc01183f38e1f4afd73413f6db0bffc163dbf09947a45` |
| tb | `afb6afc76abe9efffbf135ac5bf5c950eb3c673a53f0542eebf9ecaaf123f8ee` |
| formal | `d323bed79bfcf0ada498bb3277f327b07182bc9698d6e2c8d20790c96761b3c6` |
| integration | `58f9168f2dc5f71e3aeabbb78aeeb7a9d8bed403ac1a4ca25d5e22e17a07e446` |
| scripts | `4b0327f86e233b6bb8a1154f2e4b1bb0446ac983bc9f06c680ec0b1ea8696321` |
| third_party | `4ba917fa4da9a3d392ac4f22cc4346499c8b30e586f3b2493ecd1c21c3352dc1` |

## Results

| check | report | result |
|---|---|---|
| Lint: Verilator -Wall (0 warnings), Icarus, Yosys no-latch | [lint.md](lint.md) | 13/13 configurations clean; 10/10 illegal parameter sets refused |
| Crossbar regression (tb_noc, 20 configurations) | [regression_crossbar.md](regression_crossbar.md) | 423/423 as expected (18 negative tests detected); 4,067,046 transactions checked |
| Shared-bus regression (tb_noc, 5 configurations) | [regression_sbus.md](regression_sbus.md) | 99/99 as expected (5 negative tests detected); 969,339 transactions checked |
| Mesh regression (tb_noc, 9 configurations) | [regression_mesh.md](regression_mesh.md) | 260/260 as expected (20 negative tests detected); 3,086,341 transactions checked |
| Mutation campaign (testbench strength) | [mutants.md](mutants.md) | 35/35 mutants killed |
| Formal (ABC bmc3 + yosys-smtbmc/z3 BMC, ABC PDR) | [formal.md](formal.md) | 38/38 jobs as expected: 21 unbounded proofs, 0 bounded only, 17/17 non-vacuity mutants caught |
| Real endpoints: TensorCore 08 system testbench, unmodified tensor unit + HPC tile | [endpoints.md](endpoints.md) | 99/99 runs pass over 11 fabric variants |
| Design-exploration benchmark (self-checked RTL runs with traces) | [bench.md](bench.md) | 133/133 runs passed |
| BandwidthLab integration (its own importer on NoC traces) | [bandwidthlab.md](bandwidthlab.md) | 10/10 traces agree with the independent computation |
| Synthesis (Yosys generic CMOS, no PDK) | [synth.md](synth.md) | 39/39 configurations, 0 latches |

Not run / not available: SymbiYosys (proofs run with yosys-smtbmc and ABC directly), OpenROAD/OpenSTA and any PDK Liberty (no timing, frequency, wire delay, placement or power is claimed), FPGA place and route, SilicaFlux-V firmware (no RISC-V toolchain; the ControlCore port is driven by the TensorCore 08 testbench).
