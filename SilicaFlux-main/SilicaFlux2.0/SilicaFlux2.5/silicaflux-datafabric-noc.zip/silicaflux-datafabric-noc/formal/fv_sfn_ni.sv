// Formal harness: sfn_ni_tx -> link -> sfn_ni_rx (the endpoints of every network path).
// Messages {hdr (4 bits), two, data (4 bits)}; one- and two-flit packets mixed.
// Environment: the sender obeys R2 (a presented message is held until taken);
// the receiver's consumer may stall arbitrarily.
// Properties:
//   N1 credit invariant: flits sent - credits returned = receiver FIFO occupancy <= DEPTH,
//      never an overflow
//   N2 order and integrity: an arbitrarily chosen message is delivered after exactly the
//      messages ahead of it, with its header (and data, for two-flit packets) unchanged
//   N3 the delivered message is stable while not accepted (R4)
module fv_sfn_ni #(
  parameter int DEPTH = 2
) (
  input logic       clk,
  input logic       in_valid,
  input logic [3:0] in_hdr,
  input logic       in_two,
  input logic [3:0] in_data,
  input logic       out_ready,
  input logic       track
);
  localparam int FW = 4, DW = 4, CNTW = sfn_pkg::clog2c(DEPTH + 1);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic          in_ready, l_valid, l_credit, out_valid, ovf;
  logic [FW+1:0] l_flit;
  logic [FW-1:0] out_hdr;
  logic [DW-1:0] out_data;
  logic [CNTW-1:0] occ;
  sfn_ni_tx #(.FW(FW), .DW(DW), .DEPTH(DEPTH)) u_tx (
    .clk, .rst_n, .in_valid, .in_ready, .in_hdr, .in_two, .in_data, .out_valid(l_valid), .out_flit(l_flit),
    .out_credit(l_credit));
  sfn_ni_rx #(.FW(FW), .DW(DW), .DEPTH(DEPTH)) u_rx (
    .clk, .rst_n, .in_valid(l_valid), .in_flit(l_flit), .in_credit(l_credit), .out_valid, .out_ready, .out_hdr,
    .out_data, .occupancy(occ), .overflow(ovf));

`ifdef FORMAL
  wire take = in_valid && in_ready;
  wire dlv  = out_valid && out_ready;
  logic       v_q, hold_q, ohold_q;
  logic [3:0] h_q, d_q, oh_q, od_q;
  logic       two_q;
  logic [4:0] inflight;          // messages taken and not yet delivered
  logic [4:0] lbal;              // flits sent - credits returned
  logic       trk_v;
  logic [4:0] trk_pos;
  logic [3:0] trk_h, trk_d;
  logic       trk_two;
  initial begin v_q = 0; hold_q = 0; ohold_q = 0; inflight = '0; lbal = '0; trk_v = 0; trk_pos = '0; end
  always_ff @(posedge clk) begin
    v_q <= rst_n;
    if (!rst_n) begin
      hold_q <= 0; ohold_q <= 0; inflight <= '0; lbal <= '0; trk_v <= 0;
    end else begin
      lbal <= lbal + 5'(l_valid) - 5'(l_credit);
      hold_q <= in_valid && !in_ready; h_q <= in_hdr; two_q <= in_two; d_q <= in_data;
      ohold_q <= out_valid && !out_ready; oh_q <= out_hdr; od_q <= out_data;
      inflight <= inflight + 5'(take) - 5'(dlv);
      if (trk_v && dlv) begin
        if (trk_pos == '0) trk_v <= 1'b0;
        else               trk_pos <= trk_pos - 1'b1;
      end
      if (!trk_v && take && track) begin
        trk_v <= 1'b1; trk_h <= in_hdr; trk_d <= in_data; trk_two <= in_two;
        trk_pos <= inflight - 5'(dlv);
      end
    end
  end
  always_comb if (rst_n && v_q && hold_q) assume (in_valid && in_hdr == h_q && in_two == two_q && in_data == d_q);
  always_comb if (rst_n) begin
    assert (!ovf);                                                                   // N1
    assert (lbal == 5'(occ) && lbal <= 5'(DEPTH));  // flits on the link side = receiver occupancy <= DEPTH
    if (trk_v) assert (trk_pos < inflight);
    if (trk_v && trk_pos == '0 && out_valid) assert (out_hdr == trk_h && (!trk_two || out_data == trk_d));   // N2
  end
  always_ff @(posedge clk) if (rst_n && v_q && ohold_q) assert (out_valid && out_hdr == oh_q && out_data == od_q);  // N3
`endif
endmodule
