# Mesh formal jobs (appended to JOBS by run_formal.py)
ROUTER = PKG + TP("sfb_arbiter.sv") + R("sfn_fifo.sv", "sfn_qos_arbiter.sv", "sfn_arbiter.sv", "sfn_router.sv") + \
    [H("fv_sfn_router.sv")]
JOBS += [
    ("router_d2", "fv_sfn_router", ROUTER, {"DEPTH": 2}, 14, True, {"smt_depth": 6}),
    ("router_d3", "fv_sfn_router", ROUTER, {"DEPTH": 3}, 12, True, {"smt_depth": 5}),
    ("mut_router_no_wormhole", "fv_sfn_router", ROUTER, {"DEPTH": 2}, 10, False,
     {"expect": "FAIL", "note": "output released after the head flit (packets interleave)",
      "mutate": ("sfn_router.sv", "new_alloc[go] = !busy_q[go] && gv && !h_flit[gidx][FLW-2];", "new_alloc[go] = 1'b0;")}),
    ("mut_router_no_credit", "fv_sfn_router", ROUTER, {"DEPTH": 2}, 10, False,
     {"expect": "FAIL", "note": "flit sent without a credit",
      "mutate": ("sfn_router.sv", "(rt[gi] == 3'(go)) && (cr_q[go] != '0) && !busy_q[go];", "(rt[gi] == 3'(go)) && !busy_q[go];")}),
    ("mut_router_yx", "fv_sfn_router", ROUTER, {"DEPTH": 2}, 8, False,
     {"expect": "FAIL", "note": "route Y before X",
      "mutate": ("sfn_router.sv", "else if (32'(dx[i]) > X)     rt[i] = 3'(sfn_pkg::PORT_E);",
                 "else if (32'(dy[i]) > Y)     rt[i] = 3'(sfn_pkg::PORT_S);\n      else if (32'(dx[i]) > X)     rt[i] = 3'(sfn_pkg::PORT_E);")}),
    ("mut_router_credit_lost", "fv_sfn_router", ROUTER, {"DEPTH": 2}, 10, False,
     {"expect": "FAIL", "note": "returned credit ignored",
      "mutate": ("sfn_router.sv", "+ CRW'(out_credit[o] && PORT_EN[o]);", ";")}),
]
NI = PKG + R("sfn_fifo.sv", "sfn_ni.sv") + [H("fv_sfn_ni.sv")]
JOBS += [
    ("ni_pair_d2", "fv_sfn_ni", NI, {"DEPTH": 2}, 20, True, {}),
    ("ni_pair_d4", "fv_sfn_ni", NI, {"DEPTH": 4}, 20, True, {}),
    ("mut_ni_drop_head", "fv_sfn_ni", NI, {"DEPTH": 2}, 12, False,
     {"expect": "FAIL", "note": "two-flit head not latched (header of the data flit used)",
      "mutate": ("sfn_ni.sv", "assign out_hdr   = hv_q ? hdr_q : f_head[FW-1:0];", "assign out_hdr   = f_head[FW-1:0];")}),
    ("mut_ni_no_credit_wait", "fv_sfn_ni", NI, {"DEPTH": 2}, 12, False,
     {"expect": "FAIL", "note": "packetiser sends without a credit",
      "mutate": ("sfn_ni.sv", "wire can = (cr_q != '0);", "wire can = 1'b1;")}),
]
