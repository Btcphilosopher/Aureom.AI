// Formal harness: sfn_router, the centre router (X=1, Y=1) of a 3x3 mesh, all 5 ports,
// input FIFO depth DEPTH, flit payload = {dst{y,x} (4 bits), tag (3 bits)}.
// Environment:
//   * every upstream sender (neighbour router or NI) obeys the credit protocol: it
//     starts with DEPTH credits, sends only with a credit, gets one back per in_credit;
//   * packets on each input are well formed (head ... tail, no interleaving) and every
//     flit of input p carries tag = p (so packet origin is visible at the outputs);
//   * head flits are XY-legal for the port they arrive on (a flit travelling in Y is
//     already in its column; destinations inside the 3x3 mesh);
//   * every downstream receiver returns a credit only for a flit it holds.
// Properties:
//   C1 credit invariant: output credits + downstream occupancy = DEPTH (per output)
//   C2 no input FIFO overflow: input occupancy + upstream credits = DEPTH
//   W1 wormhole atomicity / framing on every output: a head only between packets, then
//      only body/tail flits, all from the same input, until the tail
//   W2 a head flit leaves on the XY output for its destination
//   W3 flit conservation: flits in - flits out = flits buffered
//   W4 no illegal (Y->X or off-mesh) route is ever requested
module fv_sfn_router #(
  parameter int DEPTH = 2
) (
  input logic        clk,
  input logic [4:0]  in_valid,
  input logic [4:0]  in_head,
  input logic [4:0]  in_tail,
  input logic [19:0] in_dst,        // 4 bits per input: {y[1:0], x[1:0]}
  input logic [4:0]  out_credit
);
  localparam int FW = 7, FLW = 9, CRW = sfn_pkg::clog2c(DEPTH + 1);
  logic rst_n = 1'b0;
  always_ff @(posedge clk) rst_n <= 1'b1;

  logic [5*FLW-1:0] in_flit, out_flit;
  for (genvar p = 0; p < 5; p++) begin : g_f
    assign in_flit[p*FLW +: FLW] = {in_head[p], in_tail[p], in_dst[p*4 +: 4], 3'(p)};
  end
  logic [4:0]       in_credit, out_valid;
  logic [5*CRW-1:0] cr, occ;
  logic             turn_err;
  sfn_router #(.X(1), .Y(1), .XW(2), .YW(2), .FW(FW), .DST_LSB(3), .QOS_LSB(0), .ARB_MODE(1), .DEPTH(DEPTH),
               .PORT_EN(5'b11111)) dut (
    .clk, .rst_n, .in_valid, .in_flit, .in_credit, .out_valid, .out_flit, .out_credit,
    .obs_credits(cr), .obs_occupancy(occ), .obs_turn_err(turn_err));

`ifdef FORMAL
  logic [CRW-1:0] up_cr [5];
  logic [CRW:0]   dn_cnt [5];
  logic [4:0]     up_pkt, out_pkt;
  logic [2:0]     out_tag [5];
  logic [7:0]     bal;               // flits in - flits out
  initial begin
    for (int p = 0; p < 5; p++) begin up_cr[p] = CRW'(DEPTH); dn_cnt[p] = '0; out_tag[p] = '0; end
    up_pkt = '0; out_pkt = '0; bal = '0;
  end
  function automatic logic [7:0] popc5(input logic [4:0] v);
    begin
      popc5 = 8'(v[0]) + 8'(v[1]) + 8'(v[2]) + 8'(v[3]) + 8'(v[4]);
    end
  endfunction
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      for (int p = 0; p < 5; p++) begin up_cr[p] <= CRW'(DEPTH); dn_cnt[p] <= '0; end
      up_pkt <= '0; out_pkt <= '0; bal <= '0;
    end else begin
      bal <= bal + popc5(in_valid) - popc5(out_valid);
      for (int p = 0; p < 5; p++) begin
        up_cr[p]  <= up_cr[p] - CRW'(in_valid[p]) + CRW'(in_credit[p]);
        dn_cnt[p] <= dn_cnt[p] + (CRW+1)'(out_valid[p]) - (CRW+1)'(out_credit[p]);
        if (in_valid[p]) up_pkt[p] <= in_head[p] ? !in_tail[p] : !in_tail[p];
        if (out_valid[p]) begin
          out_pkt[p] <= !out_flit[p*FLW + FLW - 2];
          if (out_flit[p*FLW + FLW - 1]) out_tag[p] <= out_flit[p*FLW +: 3];
        end
      end
    end
  end
  // ------------------------------------------------------------------ environment
  always_comb if (rst_n)
    for (int p = 0; p < 5; p++) begin
      if (in_valid[p]) begin
        assume (up_cr[p] != '0);                                   // credit protocol upstream
        assume (in_head[p] == !up_pkt[p]);                         // framing
        if (in_head[p]) begin
          assume (in_dst[p*4 +: 2] <= 2'd2 && in_dst[p*4 + 2 +: 2] <= 2'd2);   // inside the 3x3 mesh
          if (p == 1 || p == 3) assume (in_dst[p*4 +: 2] == 2'd1);  // N/S: travelling in Y, already in column x = 1
          if (p == 1) assume (in_dst[p*4 + 2 +: 2] >= 2'd1);        // from N: heading south
          if (p == 3) assume (in_dst[p*4 + 2 +: 2] <= 2'd1);        // from S: heading north
          if (p == 2) assume (in_dst[p*4 +: 2] <= 2'd1);            // from E: heading west
          if (p == 4) assume (in_dst[p*4 +: 2] >= 2'd1);            // from W: heading east
        end
      end
      if (out_credit[p]) assume (dn_cnt[p] != '0);                 // downstream returns only held flits
    end
  // ------------------------------------------------------------------ properties
  always_comb if (rst_n) begin
    assert (!turn_err);                                                          // W4
    assert (bal == 8'(occ[0 +: CRW]) + 8'(occ[CRW +: CRW]) + 8'(occ[2*CRW +: CRW]) +
                   8'(occ[3*CRW +: CRW]) + 8'(occ[4*CRW +: CRW]));                  // W3
    for (int p = 0; p < 5; p++) begin
      assert ((CRW+1)'(cr[p*CRW +: CRW]) + dn_cnt[p] == (CRW+1)'(DEPTH));        // C1
      assert ((CRW+1)'(occ[p*CRW +: CRW]) + (CRW+1)'(up_cr[p]) == (CRW+1)'(DEPTH));   // C2
      if (out_valid[p]) begin
        assert (out_flit[p*FLW + FLW - 1] == !out_pkt[p]);                       // W1 framing
        if (out_pkt[p]) assert (out_flit[p*FLW +: 3] == out_tag[p]);             // W1 same packet
        if (out_flit[p*FLW + FLW - 1]) begin                                     // W2 XY output
          if (out_flit[p*FLW + 3 +: 2] > 2'd1)       assert (p == sfn_pkg::PORT_E);
          else if (out_flit[p*FLW + 3 +: 2] < 2'd1)  assert (p == sfn_pkg::PORT_W);
          else if (out_flit[p*FLW + 5 +: 2] > 2'd1)  assert (p == sfn_pkg::PORT_S);
          else if (out_flit[p*FLW + 5 +: 2] < 2'd1)  assert (p == sfn_pkg::PORT_N);
          else                                       assert (p == sfn_pkg::PORT_L);
        end
      end
    end
  end
`endif
endmodule
