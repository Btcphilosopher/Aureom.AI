# Third-party (reused) sources

Every file below is a **byte-identical copy** from the btcphilosopher/Aureom.AI repository, branch
`claude/kind-gates-dm75tm` @ `8158b9d` (`SilicaFlux-main/`). Each directory has a `SHA256SUMS` file; nothing
in `third_party/` was modified.

| Directory | Source archive (sha256 of the archive) | Files | Used for |
|---|---|---|---|
| `datafabric/` | `SilicaFlux-main/silicaflux-datafabric.zip` (`9f1f3735…79b665fb`) — DataFabric, Project 03 | `rtl/interconnect/sfb_arbiter.sv`, `sfb_addr_decoder.sv` (in the NoC RTL); `sfb_crossbar.sv`, `sfb_req_mux.sv`, `sfb_rsp_router.sv`, `sfb_error_slave.sv`, `sfb_shared_bus.sv`, `sfb_skid_buffer.sv` (reference synthesis); `tb/common/sfb_protocol_checker.sv` | fixed / round-robin arbitration and address decoding inside `silicaflux_noc`; SFB2 reference designs |
| `silicaflux-tensorcore08/` | `SilicaFlux-main/silicaflux-tensorcore08.zip` (`be676860…f0c45f06`) — TensorCore 08 | `rtl/`, `third_party/` (TensorCore 02–07, HPC Module 08 tile with M02–M07, SRAM Wrapper Library, DataFabric DMA), `model/`, `tb/tb_system.sv`, `integration/`, `scripts/common.py`, `scripts/run_system.py` (136 files) | the real endpoints, their system testbench, program generator and checker (`integration/run_endpoints.py`) |
| `silicaflux-bandwidthlab/` | `SilicaFlux-main/silicaflux-bandwidthlab.zip` (`572050cb…4fb4f8b6f9`) — BandwidthLab, Project 10 | `python/bandwidthlab/trace_import.py`, `rtl_transactions.csv` | BandwidthLab's trace importer and metrics on NoC traces (`python/sfn_bandwidthlab.py`) |

The only derived file is `build/endpoints/tb_system_mo4.sv`, generated at run time by
`integration/run_endpoints.py` from `silicaflux-tensorcore08/tb/tb_system.sv` with one substitution (the tensor
port's SFB2 checker `MAX_OUT(1)` → `MAX_OUT(4)`) for the variants where that port may have 4 transactions
outstanding; it is not shipped.
