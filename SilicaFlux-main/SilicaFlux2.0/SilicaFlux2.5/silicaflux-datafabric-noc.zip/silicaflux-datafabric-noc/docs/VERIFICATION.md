# Verification

Every number quoted in the project's documents comes from a report in `reports/` (JSON with the exact
command line, seed and exit code of every run, plus a Markdown summary); `reports/SUMMARY.md` lists the final
counts and tool versions. A test is claimed only if it ran and passed there.

## 1. Layers

| Layer | Tool | Where | What it establishes |
|---|---|---|---|
| Lint / elaboration | Verilator 5.020 `-Wall` (zero warnings), Icarus 12 (elaborates **and runs** the elaboration checks), Yosys 0.33 (`proc; check -assert`, no latch) | `scripts/lint.py` | 13 configurations of all three topologies clean; 10 illegal parameter sets refused with the intended message by both simulators |
| Self-checking simulation | Verilator, `tb/tb_noc.sv` | `scripts/regress.py` | crossbar, shared-bus and mesh regressions: every §10 item below; 34 configurations, 782 runs, 8.1 million transactions checked |
| Testbench strength | mutation campaign | `scripts/mutants.py` | every deliberate RTL bug is caught by at least one regression run |
| Formal | Yosys → ABC `bmc3` + yosys-smtbmc/z3 (BMC), ABC PDR (unbounded) | `formal/` | FIFO, QoS arbiter, master port (with an **unconstrained** network), crossbar and shared-bus cores, router, network-interface pair; non-vacuity mutants |
| Real endpoints | TensorCore 08's own system testbench + checker, unmodified | `integration/run_endpoints.py` | the unmodified tensor unit, HPC FP32 tile (DataFabric DMA engine inside) and host port run on every fabric variant; whole final memory image checked |
| Performance | traces of self-checked runs | `scripts/bench.py`, `python/sfn_bandwidthlab.py` | bandwidth / latency / fairness numbers, cross-checked by BandwidthLab's own importer |

## 2. Testbench (`tb/`)

```
 sfn_tb_master ×NM ──► silicaflux_noc (TOPOLOGY 0/1/2) ──► sfn_tb_target ×NT   (or SFB2 slave behind sfn_sfb2_tgt_bridge)
        │  sfn_protocol_checker on every port (R2, R4, X)        │
        └──────────── independent scoreboard in tb_noc ──────────┘
```

* **Traffic generator** (`sfn_tb_master`, plusargs): offered load, opcode mix (read / acknowledged write /
  posted write / FENCE / reserved opcodes), deliberate bad addresses (unmapped, misaligned, denied), address
  modes (uniform, hot spot, long sequential bursts, own-region read-after-write with FENCE phases,
  permutation, all-routes), ID usage, QoS class per master, response back-pressure. xorshift32 generators:
  identical streams on every simulator.
* **Target model** (`sfn_tb_target`): 1,024-word memory per target, random request back-pressure, latency
  `[lat_min, lat_max]` (1 = answers in the next cycle, like a 1-cycle SRAM), optional **out-of-order**
  responses across different (source, ID) pairs, an SLVERR window, and fault injection of **spurious
  responses** (unmatched source/ID, or an illegal source). `sfn_tb_sfb2_mem` is an in-order SFB2 slave used
  behind the real `sfn_sfb2_tgt_bridge` (`TGT_SFB2 = 1`).
* **Scoreboard** (independent of the RTL — its own reference decoder):
  * conservation: every master acceptance routed to a target appears exactly once at that target, with
    identical payload and source, in per-(master, target) order; nothing appears that was not sent;
  * responses: every target response (and every FENCE / DECERR local response) reaches exactly the master
    and ID it belongs to, unchanged, in per-ID order; posted completions and spurious responses never reach a
    master; the numbers of posted-error, orphan and bad-source events equal the injected faults;
  * fabric rules: O1 (≤ MST_MAXO, checked on the RTL's own counter too), O2 (one target per outstanding ID),
    O3 (FENCE only with nothing outstanding), no transfer and no fabric output during reset;
  * fairness: other-master acceptances while a master waits at the switch ≤ NM − 1 (RR) or STARVE + NM − 1
    (QoS) — every crossbar and shared-bus run;
  * QoS effectiveness (`qos_levels`): the top level must wait clearly less than a lower level;
  * liveness watchdog: no handshake for `+wd` cycles while work is pending → DEADLOCK/LIVELOCK failure;
  * performance counters: read back over the register bus at the end of every run and compared with counts
    computed from the ports (requests, accepted / delivered bytes, stall and back-pressure cycles, occupancy
    maximum, errors, sticky error flags; sampled latency within the measured range).
* **Self-checks in the masters**: in the own-region and all-routes modes every read must return the value the
  master's own earlier writes predict — an end-to-end check that includes target memory semantics.

## 3. Brief §10 → tests

| Brief item | Test(s) | Topologies |
|---|---|---|
| every master-to-target route | `routes` (each master writes then reads back every target; denied pairs → DECERR) | all |
| simultaneous reads / writes | `random`, `smoke` (all masters, mixed opcodes) | all |
| conflicting requests | `hotspot` (all masters on one target), `qos_levels` | all |
| long bursts | `bursts` (256-beat sequential streams, 100 % load) | all |
| random back-pressure | `backpress` (50 % request and response back-pressure), `random`, `maxload` | all |
| reset while busy | `resets` (6 asynchronous resets mid-traffic; checks during reset and recovery) | all |
| error responses | `errors` (unmapped / misaligned / denied / reserved opcode / SLVERR window / posted-write errors), `random` | all |
| fairness | bound checked in every crossbar / shared-bus run; `hotspot`; `qos_levels`; Jain index in the benchmark | all |
| ordering | per-ID response order in every run; `raw_fence` (read-after-write with FENCE on out-of-order targets); `nofence_neg` (must FAIL without FENCE) | all |
| packet / transaction conservation | scoreboard in every run; formal W3 / N2 / X1–X4 | all |
| deadlock / liveness | watchdog in every run; `maxload`, `hotspot`, `perm`, `backpress`; formal proofs of the safety properties the argument rests on (docs/DEADLOCK.md) | all |
| misrouting containment | `spurious` (unmatched responses), `spur_bad` (illegal sources); formal M4/M5 with an unconstrained network | all |
| SFB2 bridges | `TGT_SFB2 = 1` configurations; real endpoints through both bridges | crossbar |

## 4. Formal (`formal/`, reports/formal.md)

Same method as DataFabric (no SymbiYosys needed): Yosys prepares the model; BMC with ABC `bmc3` to the job's
depth and, as an independent second engine, yosys-smtbmc + z3; unbounded proof with ABC PDR.

| Harness | Properties |
|---|---|
| `fv_sfn_fifo` (depth 1, 3, 4; PASS_FULL 0/1) | count = pushes − pops ≤ DEPTH; no overflow / underflow; an arbitrary element leaves in order, unchanged; held head stable |
| `fv_sfn_qos_arbiter` (N 3–5, STARVE 0–4) | one-hot grant to requesters; work conserving; grant lock; **≤ STARVE + N − 1** other acceptances; urgent wins; highest QoS level wins otherwise |
| `fv_sfn_mst_port` (bypass 0 and 1; full and partial access matrix) | O1–O3; responses reach the master only for outstanding IDs from the right target, never posted completions; local responses correct; R2 on the core side, R4 on the master side — **with the network side unconstrained** |
| `fv_sfn_xbar` (crossbar and shared bus; RR, fixed, QoS) | target request = presented request of the named source; accepted ⇔ exactly one target accepted it; responses delivered unchanged to the named master, consumed only then; R2 / R4 |
| `fv_sfn_router` (centre router of a 3×3 mesh, depth 2 and 3) | credit invariant; no input overflow; wormhole atomicity and framing; XY output of every head flit; flit conservation; no illegal turn |
| `fv_sfn_ni` (packetiser + depacketiser, depth 2 and 4) | credit invariant; messages in order with header and data unchanged; R4 |

Every property harness also runs on deliberately broken RTL (`mut_*` jobs) that must produce a counterexample.

## 5. Real endpoints (reports/endpoints.md)

TensorCore 08's system (`sfx_hpc_tensor_system`) is replaced by a drop-in edition
(`integration/sfx_hpc_tensor_system_noc.sv`) with the same module name, ports, instance names and SFB2 signal
names; TensorCore 08's testbench, program generator and checker are used unmodified (only for the 4-outstanding
variants, the tensor port's SFB2 checker limit is raised from 1 to 4, by script). Each variant runs the 9
programs of TensorCore 08's `run_system.py` (3 seeds × {1-cycle SRAM, 1-cycle SRAM + 40 % host traffic, 4-cycle
SRAM + 25 % host traffic}); pass = every completion record, the whole final memory image and the protocol
checkers.

## 6. Known verification gaps (see docs/ISSUES.md)

* No liveness *proof*: deadlock freedom rests on the argument of docs/DEADLOCK.md plus safety proofs and
  bounded simulation with a watchdog.
* The mesh is verified end to end by simulation; its components (router, network interfaces, FIFOs, master
  ports) are proved individually, not the mesh as a whole.
* No gate-level simulation and no Icarus run of the full testbench (the testbench uses Verilator `--timing`
  features; Icarus elaborates the RTL only).
* No SilicaFlux-V firmware run: the ControlCore port is driven by the TensorCore 08 testbench's host model.
