# DataFabric-NoC architecture

All numbers below are copied from `reports/` (generated on the frozen sources; reports/SUMMARY.md has the
hashes). Cycles only: no clock frequency, wire delay or power is claimed (no PDK in this environment).

## 1. What the fabric must connect

| Role | SilicaFlux endpoint | Interface today | Traffic |
|---|---|---|---|
| master | ControlCore (SilicaFlux-V RV32I data port) | SFB2, 1 outstanding | sparse, latency-sensitive loads / stores / MMIO |
| master | vector execution (HPC FP32 tile DMA, on the DataFabric DMA engine) | SFB2 | streaming |
| master | TensorCore (tensor unit DMA) | SFB2, up to 4 outstanding | streaming, the largest volume |
| master | system DMA (`silicaflux_dma`) | SFB2 | bulk copies |
| target | SRAM banks (SRAM Wrapper Library, `READ_LATENCY` 1..N) | SFB2 (credit-based adapters) | — |
| target | tile scratchpad window, peripheral page | SFB2 (one transaction at a time) | — |

So the SilicaFlux-HPC fabric has **4–5 masters and 4–6 targets**.

## 2. Topology decision (brief §2)

Three topologies were implemented behind the same master front ends and target ports
(`TOPOLOGY` = 0 / 1 / 2), verified with the same testbench, and measured on the same traffic and the same
real endpoints:

| Criterion (4 masters × 6 targets unless stated) | Shared bus | **Crossbar** | 3×2 mesh |
|---|---|---|---|
| Transfers per cycle, permutation traffic (each master its own target) | 1.00 | **4.00** | 1.45 |
| Useful bandwidth, uniform random, 100 % offered load (B/cycle) | 3.42 | **9.12** | 2.88 |
| Hot spot (all masters → one target), transfers per cycle | 1.00 | **1.00** | 0.61 |
| Fabric latency added (zero load) | 0 cycles | **0 cycles** | 6 + 2·hops cycles round trip (incl. 1-cycle target) |
| Mean access latency at 100 % uniform load (cycles) | 4.0 | **1.5** | 13.3 |
| Logic area, NAND2-eq (no counters) | 3,462 | 8,233 | 45,502 |
| Logic-depth proxy (gate levels; not timing) | 59 | 58 | 51 |
| Flip-flops | 161 | 207 | 9,833 |
| Real endpoints, whole-program cycles vs DataFabric (tensor port 4 outstanding) | 0.235–0.571× | **0.235–0.571×** | 0.43–1.28× |
| Latency QoS works (ControlCore p99 under a saturated target) | yes (5 → 4 cycles) | **yes (5 → 4 cycles)** | no effect (~46–47 cycles) |
| Fairness while all compete (Jain, hot spot) | 1.00 | **1.00** | 0.99 (4×6), 0.73 (8×8, 3×3) |

Scaling (reports/synth.md): crossbar area grows ~ NM·NT (5.9 K → 21.5 K → 83.2 K NAND2-eq for 4×4 → 8×8 →
16×16), the mesh ~ nodes but from a much higher base (29.7 K → 80.5 K → 169.4 K) because every router has
five input FIFOs. At 16×16 endpoints the crossbar is still half the mesh's logic; the mesh's real advantage —
short registered wires instead of NM×NT long ones — is a physical-design effect this environment cannot
measure.

**Decision: the crossbar is the SilicaFlux baseline.** It is the smallest topology that delivers the
required concurrency (the shared bus serialises everything to one transfer per cycle: 2.7× lower bandwidth at
4×6, 4.5× lower at 8×8), adds no latency, gives working latency QoS, and on the real endpoints is as fast as
anything measured. The shared bus is a valid choice only for a low-traffic domain (e.g. a peripheral
sub-bus) — on the real system it matched the crossbar because almost all traffic goes to one SRAM. The **mesh
is not justified** at SilicaFlux's endpoint count by any measured criterion: it costs 5.5× the logic, raises the
zero-load round trip from 1 to 6–18 cycles (0–6 hops), and its two-flit packets halve per-endpoint throughput. It remains a **verified
scale-out option** (260 mesh regression runs, proved router and network interfaces) for an endpoint count or
floorplan where wire length dominates — a decision that needs the physical data of docs/ISSUES.md NOC-01.

## 3. Block structure (`rtl/noc/`)

```
                         silicaflux_noc  (TOPOLOGY, NM, NT, AW, DW, IDW, ARB_MODE, MST_MAXO, ...)
 NM SFB3 masters                                                                        NT SFB3 targets
 ───────────────┐                                                                      ┌───────────────
 m_req_* ──────►│ sfn_mst_port ×NM                         switching core               │──► t_req_* (+src)
                │  · sfb_addr_decoder (DataFabric)    ┌─ 0 sfn_sbus  one arbiter + one  │
                │  · opcode check, per-ID tracker     │              response arbiter   │
                │    (O1 MAXO, O2 one target per ID,  ├─ 1 sfn_xbar  arbiter per target │
                │    O3 FENCE)                        │              (sfn_arbiter:      │
                │  · local responder (FENCE / DECERR) │              sfb_arbiter or     │
 m_rsp_* ◄──────│  · response merge, orphan / posted  │              sfn_qos_arbiter),  │◄── t_rsp_* (src,id)
                │    completion retirement          ──┤              response arbiter   │
                │                                     │              per master         │
                │                                     └─ 2 sfn_mesh  sfn_router ×2/node │
                │                                                    (request + response│
                │                                                    networks), sfn_ni_ │
                │                                                    tx / sfn_ni_rx     │
                └──────────────── sfn_perf (optional counter page, PERF = 1) ───────────┘
 SFB2 endpoints: sfn_sfb2_mst_bridge (master side) / sfn_sfb2_tgt_bridge (target side, tag FIFO = sfn_fifo)
```

| Module | Role | Reuse |
|---|---|---|
| `sfn_pkg` | shared protocol package: opcodes, status, QoS classes, modes, flit field widths | new |
| `silicaflux_noc` | top: front ends + selected core + counters, elaboration checks | new |
| `sfn_mst_port` | per-master decode, tracking, ordering, FENCE, local responses, containment | `sfb_addr_decoder`, `sfb_arbiter` unmodified inside |
| `sfn_xbar` / `sfn_sbus` | switching cores | `sfb_arbiter` unmodified (fixed / RR) |
| `sfn_arbiter`, `sfn_qos_arbiter` | mode selector; QoS + aging arbiter | new (QoS), DataFabric (RR / fixed) |
| `sfn_mesh`, `sfn_router`, `sfn_ni_tx/rx` | mesh core, wormhole XY router, network interfaces | new |
| `sfn_fifo` | FIFO (any depth, optional pass-through when full) | new |
| `sfn_perf` | counters + error capture on the SilicaFlux register bus | new (DataFabric DFPERF style) |
| `sfn_sfb2_mst_bridge`, `sfn_sfb2_tgt_bridge` | SFB2 compatibility | new |

## 4. Parameters

| Parameter | Default | Legal | Meaning |
|---|---|---|---|
| `TOPOLOGY` | 1 | 0 shared bus, 1 crossbar, 2 mesh | switching core |
| `NM`, `NT` | 4, 4 | ≥ 1 (counter page: NM ≤ 28, NT ≤ 64) | masters, targets |
| `AW` | 32 | 8..64 | address width (never truncated) |
| `DW` | 32 | 32, 64, 128, 256 | data width |
| `IDW` | 2 | 1..8 | transaction-ID width |
| `ARB_MODE` | 1 | 0 fixed, 1 round robin, 2 QoS | arbitration (docs/QOS.md) |
| `STARVE` | 8 | 0..255 | QoS aging threshold |
| `CHECK_ALIGN` | 1 | 0, 1 | misaligned addresses → DECERR |
| `RETIRE_BYPASS` | **0** | 0, 1 | §6 |
| `TGT_BASE`, `TGT_MASK` | — | non-overlapping, base inside mask | address map (refused at elaboration otherwise) |
| `MST_TGT_EN` | all 1 | bit m·NT+t | access matrix |
| `MAXO_MAX`, `MST_MAXO[m]` | 4, 4 each | 1..MAXO_MAX | outstanding limits (O1) |
| `MESH_X`, `MESH_Y`, `MST_NODE`, `TGT_NODE`, `FIFO_DEPTH` | 2, 2, —, —, 4 | ≤ 1 master and ≤ 1 target per node; FIFO ≥ 2 | mesh only |
| `PERF` | 1 | 0, 1 | counter page (~30 K NAND2-eq at 4×6) |

Every rule in the "Legal" column is checked at elaboration; 10 illegal sets are refused by both simulators
(reports/lint.md).

## 5. Clock and reset

One clock domain for the whole fabric (the SilicaFlux convention; no CDC is introduced). Asynchronous
assertion, synchronous release by the SoC reset synchroniser, one reset domain for masters, fabric and
targets. Every master port has a registered `run_q` gate: nothing is accepted or delivered during reset and
in the first cycle after it. Reset cancels all transactions in flight (PROTOCOL.md R11); verified by the
`resets` test (six asynchronous resets under full traffic) on all topologies.

## 6. `RETIRE_BYPASS`: a measured timing / throughput trade-off

With `RETIRE_BYPASS = 1` a response retiring in a cycle frees its master's slot in that same cycle (SFB2's
accept-while-retiring). That chains the response path into the request path (target `rsp_valid` → response
arbiter → master port → eligibility → target arbiter → `m_req_ready`).

| Measurement | `RETIRE_BYPASS = 1` | `RETIRE_BYPASS = 0` (default) |
|---|---|---|
| logic-depth proxy, crossbar 4×6 | 92 | **58** |
| logic-depth proxy, crossbar 4×6 QoS | 124 | **85** |
| real endpoints, all ports 1 outstanding (SFB2 limits) | 1.000× DataFabric (cycle-identical on 3 of 9 programs) | 1.06–1.40× |
| real endpoints, tensor port 4 outstanding | 0.235–0.571× | **0.235–0.571× (identical cycles)** |
| one master streaming to a 4-cycle target, B/cycle | MAXO 1: 1.00, MAXO 4: 3.99 | MAXO 1: 0.80, MAXO 4: 3.19, MAXO 8: 3.99 |

Rule: with the default, a master needs **`MST_MAXO ≥ target latency + 1`** for full throughput (with the
bypass, `≥ latency`). The default trades one cycle of round trip at a master's limit for a 37 % shorter
worst path and a request side that depends on registered state only. Choose `RETIRE_BYPASS = 1` only for
single-outstanding masters that need back-to-back throughput, if timing allows.

## 7. Recommended SilicaFlux configuration

| Item | Value | Reason |
|---|---|---|
| topology | crossbar (`TOPOLOGY = 1`) | §2 |
| arbitration | `ARB_RR`; `ARB_QOS` (`STARVE = 8`) if ControlCore latency under DMA load matters | QoS: ControlCore mean access latency 3.1 → 2.2 cycles under a saturated target, bulk bandwidth unchanged, +2.4 K NAND2-eq |
| classes | ControlCore `QOS_CTRL`, vector `QOS_VECTOR`, tensor `QOS_TENSOR`, DMA `QOS_DMA` | sfn_pkg |
| `MST_MAXO` | ControlCore 1, vector tile 2, TensorCore 4, system DMA 2–4 | each endpoint's own capability; §6 rule |
| SRAM bridges | `DEPTH = READ_LATENCY + 1` | sustains one transfer per cycle per bank |
| legacy single-transaction slaves | bridge `DEPTH = 1` (pass-through when full) | SFB2 R6 slaves |
| `RETIRE_BYPASS` | 0 | §6 |
| `PERF` | 1 for bring-up / FPGA, 0 for an area-minimised tape-out | ~30 K NAND2-eq (as DataFabric DF-08) |

`integration/sfx_hpc_tensor_system_noc.sv` is a worked example of this configuration on the real tensor
unit, HPC tile and SRAM.
