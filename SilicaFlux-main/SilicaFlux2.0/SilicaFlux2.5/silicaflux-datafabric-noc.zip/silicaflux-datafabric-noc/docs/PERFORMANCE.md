# Performance and design exploration (brief §9, §11)

Every number is from an RTL simulation that also **passed** the full scoreboard (reports/bench.md: 133/133
runs; reports/endpoints.md: 99/99 runs). Cycle counts only — **no clock frequency or wire delay is assumed**,
so bytes per cycle are not converted to GB/s. Data path 32 bits (4 bytes per transfer) unless stated.

## 1. Metrics and how they are measured

| Metric (brief §9) | Hardware counter (`sfn_perf`, register page) | Simulation measurement (`tb_noc` trace) |
|---|---|---|
| accepted bytes | `M_ACC_BYTES` per master (popcount of strobes for writes, DW/8 for reads) | same, recomputed and compared at the end of every regression run |
| delivered bytes | `M_RD_BYTES` (read data delivered OKAY) per master, `T_WR_BYTES` per target | bytes of OKAY transactions over the measurement window |
| link utilisation | `T_REQ` / `T_RSP` transfers per target port ÷ `CYCLES` | busiest target link (bus / crossbar) or busiest router link in flits (mesh) |
| arbitration stalls | `M_ARB_STALL` (presented to the switch, not accepted) | `sw_stall` per master |
| queue occupancy | `M_OCC_SUM` / `M_OCC_MAX` per master, `T_OCC_MAX` per target | RTL outstanding counter checked every cycle; mesh FIFO occupancy observed |
| end-to-end latency | `M_LAT_SUM / M_LAT_CNT / M_LAT_MAX` (sampled) | every transaction: fabric latency (acceptance → response) and access latency (first presentation → response) |
| back-pressure cycles | `M_REQ_STALL`, `M_RSP_STALL`, `T_REQ_BP`, `T_RSP_BP` | same, compared |

The counters are read back over the register bus at the end of every regression run and must equal the
values the testbench computes from the ports (reports/regression_*.md).
**BandwidthLab**: ten traces were converted to BandwidthLab's format and analysed with BandwidthLab's own,
unmodified importer; every metric agrees exactly with the independent computation (reports/bandwidthlab.md).

## 2. Load / latency curves (4 masters × 6 targets, uniform random, 1-cycle targets)

![bandwidth and latency vs offered load](img/load_curves.png)

| offered load per master | shared bus B/cycle | crossbar B/cycle | 3×2 mesh B/cycle | access latency bus / crossbar / mesh (cycles) |
|---|---|---|---|---|
| 5 % | 0.66 | 0.66 | 0.66 | 1.1 / 1.0 / 9.4 |
| 10 % | 1.29 | 1.31 | 1.24 | 1.2 / 1.0 / 9.9 |
| 30 % | 3.08 | 3.88 | 2.43 | 2.0 / 1.1 / 11.6 |
| 50 % | 3.38 | 5.88 | 2.76 | 3.0 / 1.2 / 12.3 |
| 100 % | 3.42 | 9.12 | 2.88 | 4.0 / 1.5 / 13.3 |

(Exact values for all seven load points and the 4×4 and 8×8 sets: reports/bench.md.) The shared bus
saturates at one transfer per cycle (≈ 3.4 B/cycle with this read/write mix); the crossbar keeps scaling with
offered load; the mesh saturates below the bus because every write request and every read response is two
flits on a one-flit-per-cycle network interface.

## 3. Traffic patterns at saturation

| Pattern | Shared bus | Crossbar | Mesh | What it shows |
|---|---|---|---|---|
| permutation, 4×6 (transfers / cycle) | 1.00 | **4.00** | 1.45 | concurrency: the crossbar serves disjoint pairs in parallel |
| permutation, 8×8 | 1.00 | **8.00** | 2.46 (3×3) / 1.80 (4×4) | |
| hot spot (all → 1 target) | 1.00 | 1.00 | 0.61 | the target is the bottleneck; mesh ejection is 2 flits per read response |
| 256-beat bursts, 4×6 (B/cycle) | 3.42 | **7.92** | 3.93 | |
| hot spot fairness while all compete (Jain) | 1.00 | 1.00 | 0.99 (4×6) / **0.73** (8×8, 3×3) | mesh parking-lot effect |

## 4. Mesh latency vs hop count (zero load)

| hops | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
|---|---|---|---|---|---|---|---|
| mean fabric latency (cycles, 1-cycle target) | 6.0 | 8.0 | 10.0 | 12.0 | 14.1 | 16.1 | 18.1 |

Measured on 2×2, 3×2 and 4×4 meshes: **latency = 6 + 2·hops** cycles round trip (1 cycle per router in each
of the two networks, plus injection / ejection at both network interfaces and the target's cycle). The
crossbar's zero-load round trip is 1 cycle.

## 5. Outstanding transactions vs a pipelined target

Each of 4 masters streams reads to its own target (bytes / cycle, all masters):

| target latency | MAXO 1 | MAXO 2 | MAXO 4 | MAXO 8 | mesh MAXO 8 |
|---|---|---|---|---|---|
| 1 cycle | 8.00 | 15.99 | 15.99 | 15.99 | 7.98 |
| 4 cycles | 3.20 | 6.40 | 12.78 | **15.96** | 7.97 |
| 8 cycles | 1.78 | 3.56 | 7.11 | 14.16 | 7.08 |

(Default `RETIRE_BYPASS = 0`; with the bypass, MAXO 1 reaches 15.99 / 4.00 / 2.00.) This is the measured
reason for SFB3: SFB2's one transaction per port gives a pipelined SRAM 1/latency of its bandwidth; with
enough outstanding transactions (`MST_MAXO ≥ latency + 1`) the fabric delivers the full transfer rate.

## 6. QoS (ControlCore class, sparse reads, vs three bulk masters saturating the same target)

| Fabric / arbitration | ControlCore access latency mean / p99 / max | bulk mean / p99 / max | B/cycle | bulk completions while all compete |
|---|---|---|---|---|
| crossbar, round robin | 3.1 / 5 / 5 | 4.1 / 5 / 5 | 3.56 | 1164 / 1164 / 1164 |
| crossbar, QoS | **2.2 / 4 / 4** | 4.0 / 6 / 10 | 3.57 | 1118 / 1060 / 978 |
| crossbar, fixed priority | 2.1 / 4 / 4 | 3.1 / 3 / **5202** | 3.56 | **2500 / 0 / 0** (starvation) |
| 2×2 mesh, round robin | 33.6 / 47 / 53 | 23.8 / 33 / 37 | 2.10 | 972 / 989 / 1029 |
| 2×2 mesh, QoS | 32.5 / 46 / 47 | 23.9 / 33 / 39 | 2.09 | 975 / 986 / 1026 |

QoS moves latency from the ControlCore to the bulk tail without changing bandwidth; fixed priority starves
the lowest port (5,202-cycle wait); in the mesh, priority cannot overtake flits already queued (docs/QOS.md §5).

## 7. Real SilicaFlux endpoints

![real endpoints on each fabric](img/endpoints.png)

Unmodified tensor unit + HPC FP32 tile + ControlCore host port + shared SRAM, TensorCore 08's own testbench
and checker, 9 programs per variant (reports/endpoints.md):

| Variant | cycles vs DataFabric `sfb_crossbar` (range over 9 programs) |
|---|---|
| NoC crossbar, SFB2 limits, `RETIRE_BYPASS = 1` | **1.000×** on the 3 programs without host traffic (identical cycle counts); 0.996–0.998× otherwise |
| NoC crossbar, SFB2 limits, `RETIRE_BYPASS = 0` | 1.055–1.400× |
| NoC crossbar, all ports 1 outstanding, SRAM pipelined | 0.675–1.340× |
| **NoC crossbar, tensor port 4 outstanding (recommended)** | **0.235–0.571×** (bypass 0 and 1 identical) |
| as above with QoS | 0.235–0.571× |
| NoC shared bus, tensor port 4 outstanding | 0.235–0.571× (one SRAM: the bus is not the bottleneck) |
| NoC 2×2 mesh, all ports 1 outstanding | 1.410–4.184× |
| NoC 2×2 mesh, tensor port 4 outstanding | 0.427–1.281× |

## 8. RTL complexity and synthesis

![area scaling](img/synth_scaling.png)

| Config (no counters) | NAND2-eq | flops | logic-depth proxy |
|---|---|---|---|
| DataFabric `sfb_crossbar` 4×6 (reference) | 6,388 | 68 | 33 |
| DataFabric `sfb_shared_bus` 4×6 (reference) | 2,048 | 44 | 51 |
| NoC shared bus 4×6 | 3,462 | 161 | 59 |
| **NoC crossbar 4×6** | **8,233** | 207 | 58 |
| NoC crossbar 4×6, QoS | 10,656 | 303 | 85 |
| NoC 3×2 mesh 4×6 (FIFO 4 / 2) | 45,502 / 30,640 | 9,833 / 5,589 | 51 / 48 |
| counter page 4×6 | 29,615 | 3,039 | 67 |
| one router (FIFO 4) / one master port (MAXO 4) / SFB2 target bridge | 7,062 / 358 / 176 | | |

The NoC crossbar costs +29 % logic over DataFabric's crossbar for IDs, several outstanding transactions per
port, posted writes, FENCE, containment and the protocol extension; RTL size: the crossbar path is 968
lines of SystemVerilog (package, top, front end, core, arbiters), the mesh adds 664 (router, network
interfaces, FIFO, mesh core); all of `rtl/noc` is 2,267 lines. No latches in any of the 39 synthesized
configurations. Logic depth is a gate-count proxy — not a timing result.

## 9. Conclusions

1. For SilicaFlux's 4–6 masters × 4–6 targets the **crossbar** is the right fabric: highest bandwidth, zero
   added latency, working QoS, modest area.
2. The **SFB3 extension** (IDs + several outstanding transactions) is what makes the measured difference on the
   real system (up to 4.25× fewer cycles); topology alone does not (shared bus = crossbar there).
3. The **mesh** is correct, deadlock-free by construction and verified, but not competitive at this scale in
   any measured metric; it should be reconsidered only with physical data (wire length / frequency) or a much
   larger endpoint count, and then with wider single-flit packets and virtual channels (docs/ISSUES.md).
