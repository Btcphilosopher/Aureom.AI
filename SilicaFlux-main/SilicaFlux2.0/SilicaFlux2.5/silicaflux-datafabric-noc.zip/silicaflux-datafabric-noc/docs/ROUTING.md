# Mesh routing, flits, flow control (TOPOLOGY = 2)

The mesh is the **scale-out option**, built and verified only after the crossbar baseline was complete
(docs/ARCHITECTURE.md §2 explains why the crossbar, not the mesh, is the SilicaFlux baseline). It plugs into
the same master front ends (`sfn_mst_port`) and the same SFB3 target ports, so every protocol rule of
docs/PROTOCOL.md, every testbench and every counter applies unchanged.

## 1. Topology and placement

* `MESH_X × MESH_Y` nodes, node index `n = y·MESH_X + x`; `x` grows East, `y` grows South.
* Each node hosts **at most one master** (`MST_NODE[m]`) and **at most one target** (`TGT_NODE[t]`);
  elaboration refuses two endpoints of one kind on a node or a node index outside the mesh
  (reports/lint.md, illegal-parameter tests).
* **Two physically separate networks** of identical routers (`sfn_mesh`):

```
 request network :  master NI (sfn_ni_tx) ─► L in │ router(x,y) │ L out ─► target NI (sfn_ni_rx) ─► t_req_*
 response network:  target NI (sfn_ni_tx) ─► L in │ router(x,y) │ L out ─► master NI (sfn_ni_rx) ─► fr_* ─► sfn_mst_port
```

Placement used by the 4×6 benchmark (3×2 mesh; master m on node m, target t on node 5−t). The real-endpoint
system uses a 2×2 mesh: ControlCore, vector tile and tensor unit on nodes 0, 1, 2; SRAM on node 3; the tile's
scratchpad window on node 1 (next to its tile).

```
      x=0          x=1          x=2
 y=0  [n0] m0,t5 ─ [n1] m1,t4 ─ [n2] m2,t3
        │            │            │
 y=1  [n3] m3,t2 ─ [n4] t1    ─ [n5] t0
```

## 2. Router (`sfn_router`)

| Item | Specification |
|---|---|
| Ports | 5: `L`=0 (network interface), `N`=1 (y−1), `E`=2 (x+1), `S`=3 (y+1), `W`=4 (x−1); ports that would leave the mesh do not exist (`PORT_EN`) |
| Links | unidirectional, `FLW = FW + 2` bits wide (flit) + 1 valid bit forward, 1 credit bit backward, per port and direction; no combinational path through a link (credits and FIFOs are registered) |
| Buffers | one input FIFO of `FIFO_DEPTH` flits per port (`sfn_fifo`, default 4, minimum 2 = credit round trip for one flit per cycle); no output buffers |
| Flow control | credit based: an output starts with `FIFO_DEPTH` credits (the downstream FIFO depth), spends one per flit, gets one back for every flit the downstream FIFO pops |
| Routing | dimension order **XY**: East/West until `x = dst.x`, then North/South until `y = dst.y`, then Local. Deterministic, minimal. |
| Routing restrictions | a flit that travels in Y (arrived on N or S) never turns into X; a route never leaves the mesh. Both are checked every cycle (`obs_turn_err`, simulation `$error`) and proved under XY-legal inputs (formal W4). |
| Switching | **wormhole**: an output is allocated to one input from the head flit to the tail flit; flits of different packets never interleave on a link (formal W1) |
| Allocation | per output, `sfn_arbiter` among inputs whose head flit wants it **and** only if a credit is available: round robin, or QoS (request network, priority from the head flit's `qos` field) |
| Throughput | one flit per input and per output per cycle; all five outputs can be busy at once |
| Hop latency | 1 cycle per router (write into the next input FIFO) at zero load |

## 3. Flit format and packet boundaries

`flit = {head, tail, payload[FW-1:0]}`. A packet is a head flit optionally followed by one data flit; a
single-flit packet has `head = tail = 1`. Packet boundaries are carried **only** by these two bits, so the
same network interfaces serve both networks.

| Packet | Flits | Head payload (MSB → LSB) | Data flit |
|---|---|---|---|
| READ request | 1 | `{dst{y,x}, src, id, opcode, qos, wstrb, addr}` | — |
| WRITE / WRITE_POSTED request | 2 | same | `wdata` |
| READ response | 2 | `{dst{y,x}, tgt, id, opcode, status}` | `rdata` |
| WRITE / posted-completion response | 1 | same | — |

Widths (no field narrowed): `dst = clog2(MESH_X) + clog2(MESH_Y)`, `src = clog2(NM)`, `tgt = clog2(NT+1)`,
`id = IDW`, `opcode = 3`, `qos = 3`, `status = 2`, `wstrb = DW/8`, `addr = AW`.
Request payload `RQ_FW = max(header, DW)`, response payload `RS_FW = max(header, DW)` — each network is only
as wide as it needs to be. For the SilicaFlux 4×6 set in a 3×2 mesh (AW 32, DW 32, IDW 2): request header
3+2+2+3+3+4+32 = **49 bits → 51-bit request links**; response header 3+3+2+3+2 = 13 bits, data 32 →
**34-bit response links**.

FENCE and every decode error never enter the network (answered by the master's local responder).
A target response naming an illegal source is consumed at the target network interface (`ev_bad_src`).

## 4. Network interfaces (`sfn_ni_tx`, `sfn_ni_rx`)

* `sfn_ni_tx` (packetiser): takes a message when it can send its head flit (credit available); a two-flit
  message's data flit follows in a later cycle (one flit per cycle per link). `in_ready` never depends on
  `in_valid`.
* `sfn_ni_rx` (depacketiser): its own `FIFO_DEPTH` input FIFO (the router's credits refer to it); latches the
  head of a two-flit packet and presents the message with the data flit; holds it stable until accepted (R4).
* Proved (formal `ni_pair_*`): credit invariant (flits sent − credits returned = receiver occupancy ≤ depth,
  never an overflow), messages delivered in order with header and data unchanged, R4.

## 5. Hop count and latency

`hops(m, t) = |x_m − x_t| + |y_m − y_t|`; routers traversed = `hops + 1`. Zero-load timing (cycles, from the
master port's request acceptance):

| Step | Cycles |
|---|---|
| request head flit into the local router FIFO | 1 |
| each router traversed | 1 |
| into the target NI FIFO and presented on `t_req_*` | (+1 for the data flit of a write) |
| target service | target latency (≥ 1) |
| response through the response network | same structure; +1 for the data flit of a read |

Measured zero-load latency by hop count: docs/PERFORMANCE.md §4 (from `reports/bench.md`).

## 6. Ordering in the mesh

A (master, target) pair always uses the same XY path and every link is a FIFO, so requests of one master
reach one target in issue order and responses of one target reach one master in order. Together with O2
(one target per outstanding ID) this gives exactly the crossbar's ordering model (docs/PROTOCOL.md §5) — the
same testbench and the same read-after-write / FENCE checks pass on all three topologies.

## 7. Limits of this mesh (see docs/ISSUES.md)

* No virtual channels: one buffer class per network. Head-of-line blocking is possible (a packet waiting for
  a busy output blocks flits behind it in the same input FIFO); QoS priority therefore cannot overtake flits
  already queued (measured: reports/bench.md, QoS table).
* One endpoint of each kind per node; no concentration.
* The 2-flit request/response format halves link throughput for writes/reads compared with one wide flit;
  link width vs flit count is a physical-design trade-off not evaluated here (no wire model).
