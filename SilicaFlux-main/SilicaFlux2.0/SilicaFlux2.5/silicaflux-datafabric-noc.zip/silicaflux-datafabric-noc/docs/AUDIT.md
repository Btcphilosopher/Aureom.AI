# Repository audit (brief §1)

Source: `btcphilosopher/Aureom.AI`, branch `claude/kind-gates-dm75tm` @ `8158b9d`, directory `SilicaFlux-main/`
(archives inspected in place; nothing in the repository was modified or committed).

## 1. What exists, and what was done with it

| Area | Found | Evidence of verification in the archive | Used here |
|---|---|---|---|
| **DataFabric** (Project 03) `silicaflux-datafabric.zip` (sha256 `9f1f3735…`) | SFB2 protocol; `sfb_crossbar` (decoder, arbiter, request mux, response router, error slave), `sfb_shared_bus`, `sfb_reg_slice`/`sfb_skid_buffer`, `sfb_v1_slave_adapter`, `sfb_perf_counters`; DMA (`silicaflux_dma`, simple + buffered engines); SRAM-library slave adapters; protocol checker; formal flow (yosys-smtbmc + ABC PDR) | 115/115 crossbar parameter runs, 12/12 mutants, unbounded PDR proofs of arbiter / skid / crossbar, SoC firmware 18/18 | **Reused unmodified** (vendored, `third_party/datafabric`, SHA256SUMS): `sfb_arbiter` (fixed / RR arbitration everywhere), `sfb_addr_decoder` (every master's decoder); `sfb_crossbar` and `sfb_shared_bus` as **references** (synthesis, endpoint comparison); formal method copied |
| **SFB v1** (SilicaFlux-V release 1) | OBI-like req/gnt/rvalid | release-1 tests (via DataFabric) | reached through SFB2 → SFB3 bridges |
| **DMA adapters** | DataFabric `silicaflux_dma`; HPC M05 `hpc_dma_adapter` (an SFB2 master built on the DataFabric DMA engine, inside the HPC tile); TensorCore TC07 `tensor_dma_adapter` (MAX_OUT up to 4) | M05/M08 regressions; TC07 328/328 GEMMs | **run unmodified on the NoC** through TensorCore 08's system (reports/endpoints.md) |
| **Vector execution** | HPC Module 08 `silicaflux_hpc_tile` (FP32 vector array M02/M03, scratchpad M04, DMA M05, queues M06, counters M07) | 145/145 integration runs, 27/27 mutants, firmware on the SilicaFlux-V CPU | unmodified endpoint (vendored inside TensorCore 08) |
| **TensorCore** | TensorCore 08 `silicaflux_tensor_unit` + `sfx_hpc_tensor_system` + `tb_system.sv` | 9/9 coexistence runs, 642 GEMMs | unmodified endpoint, **unmodified system testbench, generator and checker** (vendored, `third_party/silicaflux-tensorcore08`, 136 files byte-identical) |
| **ControlCore** | the SilicaFlux-V RV32I CPU (`control_core` in the v1 tree; SFB data port in SilicaFlux-V) | release-1 + DataFabric SoC firmware | represented by the SFB2 host data port that TensorCore 08's testbench drives (no firmware run in this project) |
| **Memory / SRAM interfaces** | SRAM Wrapper Library (`sram_sp` …), DataFabric `sfb_sram_slave` (READ_LATENCY + 1 credits) | sramlib regressions; DataFabric | SFB2 SRAM behind `sfn_sfb2_tgt_bridge` (the system testbench's shared SRAM model) |
| **Earlier NoC** `SilicaFlux2.5/noc_interconnect.sf` | 2×2 mesh, XY, wormhole, valid/ready links (1,069 lines) | none: **does not compile** — its `noc_packet_t` is defined by none of the three `silicaflux_pkg` versions in the repository (checked with Verilator; DataFabric's audit reached the same verdict for the SF2.5 tops); no testbench result in the archive | not reused (its approach — XY, wormhole, Y→X turn prohibition — is consistent with this project's mesh) |
| **Arbitration** | `sfb_arbiter` (DataFabric; RR from memoryflow `sf_rr_arbiter`), TensorCore `chk_arb` assertions | proofs in DataFabric | `sfb_arbiter` reused; QoS/aging arbiter added (`sfn_qos_arbiter`) because no existing arbiter offered priority classes with a starvation bound |
| **Performance tools** | BandwidthLab (Project 10), MemoryLab (Project 02) | BandwidthLab's crossbar model is cycle-exact vs `sfb_crossbar` RTL (SFB2 rules) | NoC traces exported in BandwidthLab format and analysed with BandwidthLab's **unmodified** importer (`third_party/silicaflux-bandwidthlab`, reports/bandwidthlab.md) |
| **Formal library** `formal verification.zip` | generic FIFO / handshake / deadlock SVA, Questa / Jasper scripts | not runnable here (no commercial tools) | not used; DataFabric's open-source flow used instead |
| `comm_protocols.zip` | AXI-lite slave, SPI, I2C, UART | standalone tests | not used (not part of the SilicaFlux fabric; SFB is the SoC protocol) |

## 2. Measured reason not to keep the SFB2 crossbar as is

Brief: "do not replace verified interconnect RTL without a measured reason". The NoC **does not replace**
DataFabric's verified components — it reuses its arbiter and decoder unmodified and extends SFB2 exactly as
DataFabric's own PROTOCOL.md §8 planned. The extension is justified by measurements, three of which pre-date
this project:

1. DataFabric ISSUES.md DF-07: "Single outstanding transaction per port (SFB2 rev 2.0): pipelined slaves
   (READ_LATENCY ≥ 2) run at 1/latency of their bandwidth."
2. TensorCore 08 reports/perf.md: a 32×32×256 INT8 GEMM takes **40,090 cycles** with a 1-cycle memory that
   accepts the unit's 4 outstanding requests, but **72,739 cycles** behind the DataFabric crossbar (R6) with the
   same memory — 1.81× slower.
3. BandwidthLab final_analysis.md: "outstanding 1→2 +27 % … 2→4 0 % (the crossbar allows one transaction per
   port)".

Measured in this project on the **same unmodified endpoints and testbench** (reports/endpoints.md):

| Fabric | whole-system cycles relative to DataFabric's crossbar (9 programs) |
|---|---|
| NoC crossbar with SFB2's limits (1 per master port, 1 per target port, `RETIRE_BYPASS = 1`) | **1.000×** on the 3 programs without host traffic (identical cycle counts), 0.996–0.998× otherwise |
| NoC crossbar, default `RETIRE_BYPASS = 0`, every port 1 outstanding, SRAM pipelined (4 in flight) | 0.675–1.340× |
| NoC crossbar, default `RETIRE_BYPASS = 0`, tensor port 4 outstanding (recommended) | **0.235–0.571×** (up to 4.25× faster) |

So the NoC is a superset that reproduces DataFabric's behaviour when restricted to SFB2's limits and is
measurably faster when the endpoints' own outstanding capacity is used.

## 3. Dependency readiness

All tools used are installed in the environment (exact versions in reports/SUMMARY.md): Verilator 5.020,
Icarus 12, Yosys 0.33 with yosys-smtbmc / yosys-abc, z3 (PyPI build; the distribution z3 4.8.12 hangs under
yosys-smtbmc 0.33), Python 3.13 with numpy / pandas / matplotlib. Not available: SymbiYosys, OpenROAD /
OpenSTA, any PDK or Liberty, FPGA place and route, a RISC-V toolchain for SilicaFlux-V firmware — so no
timing, frequency, wire delay, area in µm², power or firmware-level claim is made.
