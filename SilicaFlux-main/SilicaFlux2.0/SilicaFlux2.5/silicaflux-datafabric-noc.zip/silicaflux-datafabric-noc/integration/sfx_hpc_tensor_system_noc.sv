// =============================================================================
// SilicaFlux DataFabric-NoC :: sfx_hpc_tensor_system (NoC edition)
//
// DROP-IN REPLACEMENT for TensorCore 08's integration/sfx_hpc_tensor_system.sv:
// same module name, same ports, same instance names (u_tile, u_tsu) and the same
// SFB2 master-side signal names (m_req_*, m_rsp_*) that TensorCore 08's
// unmodified tb/tb_system.sv probes.  Only the fabric changes:
//
//   SFB2 masters (unmodified RTL)           silicaflux_noc                    SFB2 slaves
//   m0 host CPU data port  = ControlCore ─► sfn_sfb2_mst_bridge ─┐        ┌─► sfn_sfb2_tgt_bridge ─► s0 shared SRAM
//   m1 HPC tile DMA        = vector tile ─► sfn_sfb2_mst_bridge ─┼─ NoC ──┤
//   m2 tensor unit DMA     = TensorCore  ─► sfn_sfb2_mst_bridge ─┘        └─► sfn_sfb2_tgt_bridge ─► s1 tile scratchpad window
//
// Compile-time selection (macros, so the unmodified testbench needs no change):
//   SFN_TOPOLOGY   0 shared bus, 1 crossbar (default), 2 mesh
//   SFN_ARB        sfn_pkg::ARB_* (default 1 = round robin, as the DataFabric crossbar)
//   SFN_TSU_MAXO   outstanding transactions of the tensor port (default 1 = SFB2 R6 behaviour;
//                  the tensor unit itself supports MAX_OUT = 4)
//   SFN_TILE_MAXO  outstanding transactions of the HPC tile DMA port (default 1)
//   SFN_SRAM_DEPTH outstanding transactions accepted by the SRAM bridge (default 4)
//   SFN_BYPASS     RETIRE_BYPASS of the master ports (default 0 = the RTL default)
// The access matrix is the original one: host -> SRAM + scratchpad window;
// tile DMA -> SRAM; tensor unit -> SRAM only (a stray address gets DECERR).
// Traffic classes: host QOS_CTRL, tile QOS_VECTOR, tensor QOS_TENSOR.
// The NoC counter page (sfn_perf) is added on register page 10 (0xA000).
// Classification: SYNTHESIZABLE
// =============================================================================
`include "tsu_defs.svh"
`default_nettype none
`ifndef SFN_TOPOLOGY
  `define SFN_TOPOLOGY 1
`endif
`ifndef SFN_ARB
  `define SFN_ARB 1
`endif
`ifndef SFN_TSU_MAXO
  `define SFN_TSU_MAXO 1
`endif
`ifndef SFN_TILE_MAXO
  `define SFN_TILE_MAXO 1
`endif
`ifndef SFN_SRAM_DEPTH
  `define SFN_SRAM_DEPTH 4
`endif
`ifndef SFN_BYPASS
  `define SFN_BYPASS 0
`endif
module sfx_hpc_tensor_system #(
  parameter logic [31:0] SRAM_BASE  = 32'h1000_0000,
  parameter int          SRAM_BYTES = 1 << 20,
  parameter logic [31:0] SPM_BASE   = 32'h2000_0000,
  parameter int          SPM_BYTES  = 65536,
  parameter int          TSU_QUANT  = 1,
  parameter int          TSU_DBUF   = 1,
  parameter int          TSU_MAXOUT = 4,
  parameter int          TOPOLOGY   = `SFN_TOPOLOGY,
  parameter int          ARB_MODE   = `SFN_ARB,
  parameter int          TSU_MAXO   = `SFN_TSU_MAXO,
  parameter int          TILE_MAXO  = `SFN_TILE_MAXO,
  parameter int          SRAM_DEPTH = `SFN_SRAM_DEPTH,
  parameter int          BYPASS     = `SFN_BYPASS
) (
  input  wire logic        clk,
  input  wire logic        rst_n,
  input  wire logic        rb_sel,
  input  wire logic        rb_we,
  input  wire logic [15:0] rb_addr,
  input  wire logic [31:0] rb_wdata,
  output logic [31:0]      rb_rdata,
  output logic             rb_err,
  input  wire logic        h_req_valid,
  output logic             h_req_ready,
  input  wire logic        h_req_write,
  input  wire logic [31:0] h_req_addr,
  input  wire logic [31:0] h_req_wdata,
  input  wire logic [3:0]  h_req_wstrb,
  output logic             h_rsp_valid,
  input  wire logic        h_rsp_ready,
  output logic [31:0]      h_rsp_rdata,
  output logic             h_rsp_error,
  output logic             s_req_valid,
  input  wire logic        s_req_ready,
  output logic             s_req_write,
  output logic [31:0]      s_req_addr,
  output logic [31:0]      s_req_wdata,
  output logic [3:0]       s_req_wstrb,
  input  wire logic        s_rsp_valid,
  output logic             s_rsp_ready,
  input  wire logic [31:0] s_rsp_rdata,
  input  wire logic        s_rsp_error,
  output logic             tile_irq,
  output logic             tsu_irq,
  output logic             tile_busy,
  output logic             tsu_busy,
  output logic             tsu_halted,
  output logic [2:0]       mon_req_stall,
  output logic [2:0]       mon_req_accept,
  output logic [2:0]       mon_arb_loss
);
  // ============================================================ register pages
  wire p_tile = rb_addr[15:12] == 4'd8;
  wire p_tsu  = rb_addr[15:12] == 4'd9;
  wire p_noc  = rb_addr[15:12] == 4'd10;
  logic [31:0] t_rdata, u_rdata, n_rdata;
  logic        t_err, u_err, n_err;
  assign rb_rdata = p_tile ? t_rdata : p_tsu ? u_rdata : p_noc ? n_rdata : 32'd0;
  assign rb_err   = rb_sel && (p_tile ? t_err : p_tsu ? u_err : p_noc ? n_err : 1'b1);

  // ============================================================ SFB2 master side (names as in TensorCore 08)
  localparam int NM = 3, NT = 2, IDW = 1;
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  logic [NM*32-1:0] m_req_addr, m_req_wdata, m_rsp_rdata;
  logic [NM*4-1:0]  m_req_wstrb;
  assign m_req_valid[0] = h_req_valid;  assign h_req_ready = m_req_ready[0];  assign m_req_write[0] = h_req_write;
  assign m_req_addr[31:0] = h_req_addr; assign m_req_wdata[31:0] = h_req_wdata; assign m_req_wstrb[3:0] = h_req_wstrb;
  assign h_rsp_valid = m_rsp_valid[0];  assign m_rsp_ready[0] = h_rsp_ready;  assign h_rsp_rdata = m_rsp_rdata[31:0];
  assign h_rsp_error = m_rsp_error[0];

  // ============================================================ HPC Module 08 compute tile (unmodified)
  logic        hs_req_valid, hs_req_ready, hs_req_write, hs_rsp_valid, hs_rsp_ready, hs_rsp_error;
  logic [31:0] hs_req_addr, hs_req_wdata, hs_rsp_rdata;
  logic [3:0]  hs_req_wstrb;
  /* verilator lint_off UNUSEDSIGNAL */
  logic        tile_halted_u;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_hpc_tile #(.SPM_BASE(SPM_BASE), .SCRATCHPAD_BYTES(SPM_BYTES)) u_tile (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel && p_tile), .rb_we(rb_we), .rb_addr(rb_addr[11:0]), .rb_wdata(rb_wdata), .rb_rdata(t_rdata),
    .rb_err(t_err),
    .hs_req_valid(hs_req_valid), .hs_req_ready(hs_req_ready), .hs_req_write(hs_req_write), .hs_req_addr(hs_req_addr),
    .hs_req_wdata(hs_req_wdata), .hs_req_wstrb(hs_req_wstrb), .hs_rsp_valid(hs_rsp_valid),
    .hs_rsp_ready(hs_rsp_ready), .hs_rsp_rdata(hs_rsp_rdata), .hs_rsp_error(hs_rsp_error),
    .fab_req_valid(m_req_valid[1]), .fab_req_ready(m_req_ready[1]), .fab_req_write(m_req_write[1]),
    .fab_req_addr(m_req_addr[63:32]), .fab_req_wdata(m_req_wdata[63:32]), .fab_req_wstrb(m_req_wstrb[7:4]),
    .fab_rsp_valid(m_rsp_valid[1]), .fab_rsp_ready(m_rsp_ready[1]), .fab_rsp_rdata(m_rsp_rdata[63:32]),
    .fab_rsp_error(m_rsp_error[1]),
    .irq(tile_irq), .busy(tile_busy), .halted(tile_halted_u));

  // ============================================================ tensor unit (unmodified)
  /* verilator lint_off UNUSEDSIGNAL */
  logic [`TSU_NUM_PC*32-1:0] tsu_ev;
  /* verilator lint_on UNUSEDSIGNAL */
  silicaflux_tensor_unit #(
    .ENABLE_QUANTIZATION(TSU_QUANT), .ENABLE_DOUBLE_BUFFERING(TSU_DBUF), .MAX_OUT(TSU_MAXOUT),
    .MEM_LO(33'(SRAM_BASE)), .MEM_HI(33'(SRAM_BASE) + 33'(SRAM_BYTES))
  ) u_tsu (
    .clk(clk), .rst_n(rst_n),
    .rb_sel(rb_sel && p_tsu), .rb_we(rb_we), .rb_addr(rb_addr[11:0]), .rb_wdata(rb_wdata), .rb_rdata(u_rdata),
    .rb_err(u_err),
    .m_req_valid(m_req_valid[2]), .m_req_ready(m_req_ready[2]), .m_req_write(m_req_write[2]),
    .m_req_addr(m_req_addr[95:64]), .m_req_wdata(m_req_wdata[95:64]), .m_req_wstrb(m_req_wstrb[11:8]),
    .m_rsp_valid(m_rsp_valid[2]), .m_rsp_ready(m_rsp_ready[2]), .m_rsp_rdata(m_rsp_rdata[95:64]),
    .m_rsp_error(m_rsp_error[2]),
    .irq(tsu_irq), .busy(tsu_busy), .halted(tsu_halted), .perf_ev(tsu_ev), .fi_mode(2'd0));

  // ============================================================ SFB2 -> SFB3 master bridges
  logic [NM-1:0]     n_req_valid, n_req_ready, n_rsp_valid, n_rsp_ready;
  logic [NM*3-1:0]   n_req_opcode, n_req_qos, n_rsp_opcode;
  logic [NM*IDW-1:0] n_req_id, n_rsp_id;
  logic [NM*32-1:0]  n_req_addr, n_req_wdata, n_rsp_rdata;
  logic [NM*4-1:0]   n_req_wstrb;
  logic [NM*2-1:0]   n_rsp_status;
  localparam logic [8:0] QOS = {sfn_pkg::QOS_TENSOR, sfn_pkg::QOS_VECTOR, sfn_pkg::QOS_CTRL};
  for (genvar gm = 0; gm < NM; gm++) begin : g_mb
    sfn_sfb2_mst_bridge #(.AW(32), .DW(32), .IDW(IDW), .ID(1'b0), .QOS(QOS[gm*3 +: 3])) u_mb (
      .s_req_valid(m_req_valid[gm]), .s_req_ready(m_req_ready[gm]), .s_req_write(m_req_write[gm]),
      .s_req_addr(m_req_addr[gm*32 +: 32]), .s_req_wdata(m_req_wdata[gm*32 +: 32]), .s_req_wstrb(m_req_wstrb[gm*4 +: 4]),
      .s_rsp_valid(m_rsp_valid[gm]), .s_rsp_ready(m_rsp_ready[gm]), .s_rsp_rdata(m_rsp_rdata[gm*32 +: 32]),
      .s_rsp_error(m_rsp_error[gm]),
      .m_req_valid(n_req_valid[gm]), .m_req_ready(n_req_ready[gm]), .m_req_opcode(n_req_opcode[gm*3 +: 3]),
      .m_req_id(n_req_id[gm*IDW +: IDW]), .m_req_qos(n_req_qos[gm*3 +: 3]), .m_req_addr(n_req_addr[gm*32 +: 32]),
      .m_req_wdata(n_req_wdata[gm*32 +: 32]), .m_req_wstrb(n_req_wstrb[gm*4 +: 4]),
      .m_rsp_valid(n_rsp_valid[gm]), .m_rsp_ready(n_rsp_ready[gm]), .m_rsp_id(n_rsp_id[gm*IDW +: IDW]),
      .m_rsp_opcode(n_rsp_opcode[gm*3 +: 3]), .m_rsp_status(n_rsp_status[gm*2 +: 2]),
      .m_rsp_rdata(n_rsp_rdata[gm*32 +: 32]));
  end

  // ============================================================ the fabric
  localparam int SRCW = 2;
  logic [NT-1:0]      x_req_valid, x_req_ready, x_rsp_valid, x_rsp_ready;
  logic [NT*3-1:0]    x_req_opcode, x_req_qos, x_rsp_opcode;
  logic [NT*SRCW-1:0] x_req_src, x_rsp_src;
  logic [NT*IDW-1:0]  x_req_id, x_rsp_id;
  logic [NT*32-1:0]   x_req_addr, x_req_wdata, x_rsp_rdata;
  logic [NT*4-1:0]    x_req_wstrb;
  logic [NT*2-1:0]    x_rsp_status;
  /* verilator lint_off UNUSEDSIGNAL */
  logic               irq_err_u;
  logic [NM*3-1:0]    obs_out_u;
  logic [NM-1:0]      obs_dec_u, obs_pe_u, obs_or_u;
  logic [NT-1:0]      obs_bs_u;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [NM-1:0]      sw_valid, sw_ready;
  // bit m*NT+t: host -> SRAM, SPM; tile DMA -> SRAM; tensor unit -> SRAM
  localparam logic [NM*NT-1:0] EN = 6'b01_01_11;
  silicaflux_noc #(
    .TOPOLOGY(TOPOLOGY), .NM(NM), .NT(NT), .AW(32), .DW(32), .IDW(IDW), .ARB_MODE(ARB_MODE), .STARVE(8),
    .CHECK_ALIGN(1), .RETIRE_BYPASS(BYPASS), .TGT_BASE({SPM_BASE, SRAM_BASE}), .TGT_MASK({32'(~(SPM_BYTES - 1)), 32'(~(SRAM_BYTES - 1))}),
    .MST_TGT_EN(EN), .MAXO_MAX(4), .MST_MAXO({8'(TSU_MAXO), 8'(TILE_MAXO), 8'd1}),
    .MESH_X(2), .MESH_Y(2), .MST_NODE({8'd2, 8'd1, 8'd0}), .TGT_NODE({8'd1, 8'd3}), .FIFO_DEPTH(4), .PERF(1)
  ) u_noc (
    .clk, .rst_n,
    .m_req_valid(n_req_valid), .m_req_ready(n_req_ready), .m_req_opcode(n_req_opcode), .m_req_id(n_req_id),
    .m_req_qos(n_req_qos), .m_req_addr(n_req_addr), .m_req_wdata(n_req_wdata), .m_req_wstrb(n_req_wstrb),
    .m_rsp_valid(n_rsp_valid), .m_rsp_ready(n_rsp_ready), .m_rsp_id(n_rsp_id), .m_rsp_opcode(n_rsp_opcode),
    .m_rsp_status(n_rsp_status), .m_rsp_rdata(n_rsp_rdata),
    .t_req_valid(x_req_valid), .t_req_ready(x_req_ready), .t_req_opcode(x_req_opcode), .t_req_src(x_req_src),
    .t_req_id(x_req_id), .t_req_qos(x_req_qos), .t_req_addr(x_req_addr), .t_req_wdata(x_req_wdata),
    .t_req_wstrb(x_req_wstrb), .t_rsp_valid(x_rsp_valid), .t_rsp_ready(x_rsp_ready), .t_rsp_src(x_rsp_src),
    .t_rsp_id(x_rsp_id), .t_rsp_opcode(x_rsp_opcode), .t_rsp_status(x_rsp_status), .t_rsp_rdata(x_rsp_rdata),
    .rb_sel(rb_sel && p_noc), .rb_we(rb_we), .rb_addr(rb_addr[11:0]), .rb_wdata(rb_wdata), .rb_rdata(n_rdata),
    .rb_err(n_err), .irq_err(irq_err_u),
    .obs_sw_valid(sw_valid), .obs_sw_ready(sw_ready), .obs_out_cnt(obs_out_u), .obs_decerr(obs_dec_u),
    .obs_posted_err(obs_pe_u), .obs_orphan(obs_or_u), .obs_bad_src(obs_bs_u));

  // ============================================================ SFB3 -> SFB2 target bridges
  // s0: shared SRAM (external port; the testbench model accepts many in flight)
  sfn_sfb2_tgt_bridge #(.NM(NM), .AW(32), .DW(32), .IDW(IDW), .DEPTH(SRAM_DEPTH)) u_tb0 (
    .clk, .rst_n,
    .t_req_valid(x_req_valid[0]), .t_req_ready(x_req_ready[0]), .t_req_opcode(x_req_opcode[2:0]),
    .t_req_src(x_req_src[1:0]), .t_req_id(x_req_id[0]), .t_req_qos(x_req_qos[2:0]), .t_req_addr(x_req_addr[31:0]),
    .t_req_wdata(x_req_wdata[31:0]), .t_req_wstrb(x_req_wstrb[3:0]),
    .t_rsp_valid(x_rsp_valid[0]), .t_rsp_ready(x_rsp_ready[0]), .t_rsp_src(x_rsp_src[1:0]), .t_rsp_id(x_rsp_id[0]),
    .t_rsp_opcode(x_rsp_opcode[2:0]), .t_rsp_status(x_rsp_status[1:0]), .t_rsp_rdata(x_rsp_rdata[31:0]),
    .s_req_valid, .s_req_ready, .s_req_write, .s_req_addr, .s_req_wdata, .s_req_wstrb,
    .s_rsp_valid, .s_rsp_ready, .s_rsp_rdata, .s_rsp_error);
  // s1: the tile's host scratchpad window -- an SFB2 slave built for the one-transaction rule: DEPTH 1
  sfn_sfb2_tgt_bridge #(.NM(NM), .AW(32), .DW(32), .IDW(IDW), .DEPTH(1)) u_tb1 (
    .clk, .rst_n,
    .t_req_valid(x_req_valid[1]), .t_req_ready(x_req_ready[1]), .t_req_opcode(x_req_opcode[5:3]),
    .t_req_src(x_req_src[3:2]), .t_req_id(x_req_id[1]), .t_req_qos(x_req_qos[5:3]), .t_req_addr(x_req_addr[63:32]),
    .t_req_wdata(x_req_wdata[63:32]), .t_req_wstrb(x_req_wstrb[7:4]),
    .t_rsp_valid(x_rsp_valid[1]), .t_rsp_ready(x_rsp_ready[1]), .t_rsp_src(x_rsp_src[3:2]), .t_rsp_id(x_rsp_id[1]),
    .t_rsp_opcode(x_rsp_opcode[5:3]), .t_rsp_status(x_rsp_status[3:2]), .t_rsp_rdata(x_rsp_rdata[63:32]),
    .s_req_valid(hs_req_valid), .s_req_ready(hs_req_ready), .s_req_write(hs_req_write), .s_req_addr(hs_req_addr),
    .s_req_wdata(hs_req_wdata), .s_req_wstrb(hs_req_wstrb), .s_rsp_valid(hs_rsp_valid), .s_rsp_ready(hs_rsp_ready),
    .s_rsp_rdata(hs_rsp_rdata), .s_rsp_error(hs_rsp_error));

  // ============================================================ monitor taps (as the original)
  assign mon_req_accept = m_req_valid & m_req_ready;
  assign mon_req_stall  = m_req_valid & ~m_req_ready;
  assign mon_arb_loss   = sw_valid & ~sw_ready;
endmodule
`default_nettype wire
