#!/usr/bin/env python3
"""Real-endpoint integration: the UNMODIFIED SilicaFlux tensor unit (TensorCore 08) and HPC FP32 vector tile
(HPC Module 08, whose DMA adapter is the DataFabric DMA engine) plus a ControlCore host port, sharing one SRAM.

The TensorCore 08 system testbench (third_party/silicaflux-tensorcore08/tb/tb_system.sv), its program
generator (model/gen_system.py) and its checker (model/check.py: every completion record, the WHOLE final
memory image, SFB2 protocol checkers on all three master ports) are used unmodified.  Only the fabric changes:

  datafabric_xbar  the original integration/sfx_hpc_tensor_system.sv on DataFabric's sfb_crossbar (reference)
  noc_*            integration/sfx_hpc_tensor_system_noc.sv: the same system on silicaflux_noc

`*_sfb2eq` keeps SFB2's limits on both sides (1 per master port, 1 per target port); `*_m1` keeps 1 per master
port but lets the SRAM bridge pipeline up to 4 requests (the unmodified testbench applies as is to both).
`*_m4` variants let the tensor port use its native MAX_OUT = 4; the testbench is then compiled with the ONE
change that the tensor port's SFB2 checker allows 4 outstanding (MAX_OUT(1) -> MAX_OUT(4) on u_c2), made by
this script into build/endpoints/tb_system_mo4.sv.  Writes reports/endpoints.{json,md}.
usage: run_endpoints.py [--variants v1 v2 ...] [--jobs N]
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TC = ROOT / "third_party" / "silicaflux-tensorcore08"
BUILD = ROOT / "build" / "endpoints"
sys.path.insert(0, str(TC / "model"))
import check                      # noqa: E402  (TensorCore 08 checker, unmodified)
from gen_system import system_prog  # noqa: E402  (TensorCore 08 program generator, unmodified)

NOC_RTL = [l.strip() for l in (ROOT / "files_rtl.f").read_text().splitlines() if l.strip()]
DEFS = ["+define+HPC_TILE_ASSERT", "+define+HPC_DMA_ASSERT", "+define+HPC_SPM_ASSERT", "+define+SRAMLIB_ASSERT",
        "+define+TOB_ASSERT"]
RUNS = [dict(seed=s, lat=lat, cpu_rate=cpu) for s in (1, 2, 3) for lat, cpu in ((1, 0), (1, 40), (4, 25))]

VARIANTS = {
    # mo = outstanding allowed by the tensor port's checker; tsu = fabric limit for the tensor port;
    # depth = requests the SRAM-side bridge keeps in flight (SFB2 R6 = 1 per slave port)
    "datafabric_xbar": dict(noc=False, mo=1, desc="reference: DataFabric sfb_crossbar (original TensorCore 08 system)"),
    "noc_xbar_sfb2eq": dict(noc=True, topo=1, tsu=1, depth=1, mo=1, byp=1,
                            desc="NoC crossbar with SFB2 limits (1 per master port, 1 per target port, RETIRE_BYPASS 1)"),
    "noc_xbar_m1":     dict(noc=True, topo=1, tsu=1, depth=4, mo=1, desc="NoC crossbar, 1 per master, SRAM pipelined (4 in flight)"),
    "noc_xbar_m4":     dict(noc=True, topo=1, tsu=4, depth=4, mo=4, desc="NoC crossbar, tensor port 4 outstanding, SRAM 4 in flight"),
    "noc_xbar_qos_m4": dict(noc=True, topo=1, tsu=4, depth=4, mo=4, arb=2,
                            desc="as noc_xbar_m4 with QoS arbitration (ControlCore > vector > tensor)"),
    "noc_xbar_sfb2eq_nobyp": dict(noc=True, topo=1, tsu=1, depth=1, mo=1, byp=0,
                            desc="as noc_xbar_sfb2eq with RETIRE_BYPASS 0 (the default)"),
    "noc_xbar_m4_byp": dict(noc=True, topo=1, tsu=4, depth=4, mo=4, byp=1, desc="as noc_xbar_m4 with RETIRE_BYPASS 1"),
    "noc_sbus_m1":     dict(noc=True, topo=0, tsu=1, depth=4, mo=1, desc="NoC shared bus, 1 per master, SRAM 4 in flight"),
    "noc_sbus_m4":     dict(noc=True, topo=0, tsu=4, depth=4, mo=4, desc="NoC shared bus, tensor port 4 outstanding"),
    "noc_mesh_m1":     dict(noc=True, topo=2, tsu=1, depth=4, mo=1, desc="NoC 2x2 mesh, 1 per master, SRAM 4 in flight"),
    "noc_mesh_m4":     dict(noc=True, topo=2, tsu=4, depth=4, mo=4, desc="NoC 2x2 mesh, tensor port 4 outstanding"),
}


def tb_file(mo):
    src = TC / "tb" / "tb_system.sv"
    if mo == 1:
        return src
    BUILD.mkdir(parents=True, exist_ok=True)
    txt = src.read_text()
    old = 'sfb_protocol_checker #(.MAX_OUT(1), .NAME("tensor_dma"))'
    assert txt.count(old) == 1
    dst = BUILD / f"tb_system_mo{mo}.sv"
    dst.write_text(txt.replace(old, f'sfb_protocol_checker #(.MAX_OUT({mo}), .NAME("tensor_dma"))'))
    return dst


def build(name):
    v = VARIANTS[name]
    out = BUILD / name
    out.mkdir(parents=True, exist_ok=True)
    flist = [l.strip() for l in (TC / "integration" / "files_system.f").read_text().splitlines() if l.strip()]
    if v["noc"]:
        flist = [l for l in flist if not l.endswith("integration/sfx_hpc_tensor_system.sv")]
        flist += [str(ROOT / f) for f in NOC_RTL] + [str(ROOT / "integration" / "sfx_hpc_tensor_system_noc.sv")]
        defs = [f"+define+SFN_TOPOLOGY={v['topo']}", f"+define+SFN_TSU_MAXO={v['tsu']}", f"+define+SFN_ARB={v.get('arb', 1)}",
                f"+define+SFN_SRAM_DEPTH={v['depth']}", f"+define+SFN_BYPASS={v.get('byp', 0)}"]
    else:
        defs = []
    fl = out / "files.f"
    fl.write_text("\n".join(flist) + "\n")
    cmd = ["verilator", "--binary", "--timing", "-O2", "-j", "4", "--top-module", "tb_system", "-Mdir", str(out),
           "-Wno-fatal", "-Wno-lint", "-Wno-style", "-Wno-TIMESCALEMOD", "-Wno-INITIALDLY", "-Wno-MULTIDRIVEN",
           "-Wno-SYNCASYNCNET", "-Wno-BLKANDNBLK", "-Wno-UNOPTFLAT", "-Wno-CASEINCOMPLETE", "-Wno-WIDTH",
           *DEFS, *defs, "-f", str(fl),
           str(TC / "third_party" / "silicaflux-datafabric" / "tb" / "common" / "sfb_protocol_checker.sv"),
           str(tb_file(v["mo"]))]
    t0 = time.time()
    r = subprocess.run(cmd, cwd=TC, capture_output=True, text=True)
    (out / "build.log").write_text(" ".join(cmd) + "\n" + r.stdout + r.stderr)
    return name, r.returncode, round(time.time() - t0, 1), " ".join(cmd)


def one(name, r):
    exe = BUILD / name / "Vtb_system"
    d = BUILD / name / "runs" / f"s{r['seed']}_lat{r['lat']}_cpu{r['cpu_rate']}"
    if d.exists():
        shutil.rmtree(d)
    p = system_prog(r["seed"] * 77 + 5)          # the same programs as TensorCore 08's run_system.py
    p.write(d, meta=r)
    e = json.loads((d / "expect.json").read_text())
    e["extra"] = p.extra
    (d / "expect.json").write_text(json.dumps(e))
    plus = [f"+dir={d}", f"+seed={r['seed']}", f"+lat={r['lat']}", f"+cpu_rate={r['cpu_rate']}", f"+cpu_lo={p.plus['cpu_lo']}"]
    t0 = time.time()
    s = subprocess.run([str(exe)] + plus, cwd=d, capture_output=True, text=True, timeout=3600)
    (d / "sim.log").write_text(s.stdout + s.stderr)
    res = check.check(d)
    tile = [l.split() for l in (d / "tile_records.txt").read_text().splitlines() if l.strip()] \
        if (d / "tile_records.txt").exists() else []
    if len(tile) != len(p.tile_expect):
        res["ok"] = False
        res["fails"].append(f"{len(tile)} tile records, {len(p.tile_expect)} expected")
    for i, (t, x) in enumerate(zip(tile, p.tile_expect)):
        info, count = int(t[1], 16), int(t[3], 16)
        got = dict(tag=info & 0xFF, status=(info >> 8) & 0xF, type=(info >> 12) & 0xF, count=count)
        if got != x or not (info >> 31) & 1:
            res["ok"] = False
            res["fails"].append(f"tile record {i}: {got} expected {x}")
    stats = (d / "stats.txt").read_text() if (d / "stats.txt").exists() else ""
    m = re.search(r"^cycles (\d+)", stats, re.M)
    acc = [int(x) for x in re.findall(r"accepted (\d+)", stats)]
    res.update(r, variant=name, cycles=int(m.group(1)) if m else None, accepted=acc, n_tile=len(tile),
               secs=round(time.time() - t0, 1), stats=stats)
    return res


def write(builds, res, sel):
    BUILDR = ROOT / "reports"
    BUILDR.mkdir(exist_ok=True)
    json.dump(dict(builds=builds, runs=res), open(BUILDR / "endpoints.json", "w"), indent=1, default=str)
    ref = {(x["seed"], x["lat"], x["cpu_rate"]): x["cycles"] for x in res if x["variant"] == "datafabric_xbar"}
    with open(BUILDR / "endpoints.md", "w") as f:
        f.write("# Real-endpoint integration\n\nUnmodified SilicaFlux tensor unit (TensorCore 08) + HPC FP32 vector tile "
                "(HPC Module 08; its DMA adapter is the DataFabric DMA engine) + ControlCore host port + shared SRAM.  "
                "TensorCore 08's own system testbench, program generator and checker decide pass/fail: every tensor and "
                "tile completion record, the whole final memory image, and SFB2 protocol checkers on all master ports.  "
                "Generated by `integration/run_endpoints.py`.\n\n")
        f.write("| variant | description | runs passed |\n|---|---|---|\n")
        for v in sel:
            rr = [x for x in res if x["variant"] == v]
            f.write(f"| {v} | {VARIANTS[v]['desc']} | {sum(x['ok'] for x in rr)} / {len(rr)} |\n")
        f.write("\n## Cycles per run (whole program, from the testbench's stats.txt)\n\n| seed | SRAM latency | CPU traffic % | "
                + " | ".join(sel) + " |\n|---|---|---|" + "---|" * len(sel) + "\n")
        for r in RUNS:
            k = (r["seed"], r["lat"], r["cpu_rate"])
            cells = []
            for v in sel:
                x = next((y for y in res if y["variant"] == v and (y["seed"], y["lat"], y["cpu_rate"]) == k), None)
                if x is None or x["cycles"] is None:
                    cells.append("-")
                else:
                    rel = f" ({x['cycles'] / ref[k]:.3f}x)" if k in ref and ref[k] and v != "datafabric_xbar" else ""
                    cells.append(f"{x['cycles']}{rel}" + ("" if x["ok"] else " **FAIL**"))
            f.write(f"| {k[0]} | {k[1]} | {k[2]} | " + " | ".join(cells) + " |\n")
        bad = [x for x in res if not x["ok"]]
        if bad:
            f.write("\n## Failures\n\n")
            for x in bad:
                f.write(f"* {x['variant']} seed {x['seed']} lat {x['lat']} cpu {x['cpu_rate']}: {' | '.join(x['fails'])[:400]}\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--variants", nargs="*", default=["datafabric_xbar", "noc_xbar_sfb2eq", "noc_xbar_sfb2eq_nobyp",
                                                       "noc_xbar_m1", "noc_xbar_m4", "noc_xbar_m4_byp", "noc_xbar_qos_m4",
                                                       "noc_sbus_m1", "noc_sbus_m4", "noc_mesh_m1", "noc_mesh_m4"])
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 4)
    a = ap.parse_args()
    with ThreadPoolExecutor(2) as ex:
        builds = list(ex.map(build, a.variants))
    bres = [dict(variant=n, rc=rc, secs=t) for n, rc, t, _ in builds]
    ok_b = [n for n, rc, _, _ in builds if rc == 0]
    for n, rc, _, _ in builds:
        if rc:
            print(f"BUILD FAILED {n}: see build/endpoints/{n}/build.log")
    jobs = [(n, r) for n in ok_b for r in RUNS]
    with ThreadPoolExecutor(a.jobs) as ex:
        res = list(ex.map(lambda j: one(*j), jobs))
    for x in res:
        print(f"{x['variant']:18s} seed {x['seed']} lat {x['lat']} cpu {x['cpu_rate']:2d}%: "
              f"{'PASS' if x['ok'] else 'FAIL ' + ' | '.join(x['fails'])[:200]}  cycles {x['cycles']}")
    write(bres, res, ok_b)
    n = sum(x["ok"] for x in res)
    print(f"endpoints: {n}/{len(res)} runs pass, {len(a.variants) - len(ok_b)} build failures")
    return 0 if n == len(res) and len(ok_b) == len(a.variants) else 1


if __name__ == "__main__":
    sys.exit(main())
