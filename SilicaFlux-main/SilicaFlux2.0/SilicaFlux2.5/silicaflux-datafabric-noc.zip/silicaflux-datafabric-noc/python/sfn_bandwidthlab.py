#!/usr/bin/env python3
"""BandwidthLab integration: DataFabric-NoC RTL traces -> SilicaFlux BandwidthLab (Project 10).

1. Converts tb_noc transaction traces (build/bench/<cfg>/<scenario>.csv) into BandwidthLab's
   trace format (columns master, id, issue_cycle, accept_cycle, response_cycle, error, ...),
   written to reports/traces/<cfg>__<scenario>.bwlab.csv -- RTL_OBSERVED data in BandwidthLab's terms.
2. Imports every converted trace with BandwidthLab's OWN importer and metric code
   (bandwidthlab/trace_import.py, vendored unmodified in third_party/silicaflux-bandwidthlab; set
   BANDWIDTHLAB_PY=<path to BandwidthLab's python/> to use a full checkout instead).
3. Recomputes the same metrics independently from the raw trace and checks agreement.
Writes reports/bandwidthlab.{json,md}.
"""
import importlib.util, json, os, sys
import numpy as np
import pandas as pd

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BW = os.environ.get("BANDWIDTHLAB_PY", os.path.join(ROOT, "third_party", "silicaflux-bandwidthlab", "python"))
spec = importlib.util.spec_from_file_location("bwl_trace_import", os.path.join(BW, "bandwidthlab", "trace_import.py"))
bwl = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bwl)

TRACES = [  # (config, scenario) produced by scripts/bench.py
    ("B_sbus", "load_500"), ("B_xbar", "load_500"), ("B_mesh", "load_500"),
    ("B_sbus", "perm"), ("B_xbar", "perm"), ("B_mesh", "perm"),
    ("Q_xbar_rr", "qos"), ("Q_xbar_qos", "qos"),
    ("O_mo1", "outstanding_4"), ("O_mo4", "outstanding_4"),
]
SRC = "silicaflux_noc tb_noc (Verilator 5.020), DataFabric-NoC Project 22"


def convert(cfg, scen):
    src = os.path.join(ROOT, "build", "bench", cfg, f"{scen}.csv")
    df = pd.read_csv(src).sort_values(["accept_cycle", "master"]).reset_index(drop=True)
    df["seq"] = df.groupby("master").cumcount()
    out = pd.DataFrame({"master": df.master, "id": df.seq, "txn_id": df["id"], "issue_cycle": df.issue_cycle,
                        "accept_cycle": df.accept_cycle, "response_cycle": df.done_cycle,
                        "error": (df.status != 0).astype(int), "addr": df.addr, "op": df.op, "slave": df.target,
                        "bytes": df.bytes, "source_format": SRC})
    os.makedirs(os.path.join(ROOT, "reports", "traces"), exist_ok=True)
    dst = os.path.join(ROOT, "reports", "traces", f"{cfg}__{scen}.bwlab.csv")
    out.to_csv(dst, index=False)
    return src, dst, df


def independent(df):
    span = float(df.done_cycle.max() - df.accept_cycle.min() + 1)
    lat = (df.done_cycle - df.accept_cycle).to_numpy(float)
    q = (df.accept_cycle - df.issue_cycle).to_numpy(float)
    return dict(transactions=len(df), span=span, tpc=len(df) / span, lat_mean=lat.mean(), lat_p50=np.percentile(lat, 50),
                lat_p99=np.percentile(lat, 99), lat_max=lat.max(), q_mean=q.mean(), q_max=q.max(),
                errors=int((df.status != 0).sum()))


def main():
    rows = []
    for cfg, scen in TRACES:
        if not os.path.exists(os.path.join(ROOT, "build", "bench", cfg, f"{scen}.csv")):
            print(f"missing trace {cfg}/{scen} (run scripts/bench.py first)")
            continue
        src, dst, raw = convert(cfg, scen)
        m = bwl.trace_metrics(bwl.read_trace(dst))          # BandwidthLab's own importer + metrics
        ind = independent(raw)
        a2r, i2a = m["accept_to_response"], m.get("issue_to_accept", {})
        checks = {
            "transactions": m["complete"] == ind["transactions"] and m["incomplete"] == 0,
            "span": abs(m["span_cycles"] - ind["span"]) < 1e-9,
            "transactions_per_cycle": abs(m["transactions_per_cycle"] - ind["tpc"]) < 1e-9,
            "latency": all(abs(a - b) < 1e-9 for a, b in ((a2r["mean"], ind["lat_mean"]), (a2r["p50"], ind["lat_p50"]),
                                                          (a2r["p99"], ind["lat_p99"]), (a2r["max"], ind["lat_max"]))),
            "issue_to_accept": bool(i2a) and abs(i2a["mean"] - ind["q_mean"]) < 1e-9 and abs(i2a["max"] - ind["q_max"]) < 1e-9,
            "errors": m.get("errors") == ind["errors"],
        }
        rows.append(dict(config=cfg, scenario=scen, trace=os.path.relpath(dst, ROOT), bandwidthlab=m, independent=ind,
                         agree=all(checks.values()), checks=checks))
    json.dump(dict(bandwidthlab_module=os.path.relpath(os.path.join(BW, "bandwidthlab", "trace_import.py"), ROOT)
                   if BW.startswith(ROOT) else BW, rows=rows),
              open(os.path.join(ROOT, "reports", "bandwidthlab.json"), "w"), indent=1, default=float)
    with open(os.path.join(ROOT, "reports", "bandwidthlab.md"), "w") as f:
        f.write("# BandwidthLab integration\n\nDataFabric-NoC RTL traces converted to BandwidthLab's trace format "
                "(`reports/traces/*.bwlab.csv`, RTL_OBSERVED) and analysed with BandwidthLab's own, unmodified importer "
                "and metrics (`bandwidthlab/trace_import.py`: `read_trace`, `trace_metrics`).  Every metric is also "
                "recomputed independently from the raw trace; `agree` = all equal.  Generated by `python/sfn_bandwidthlab.py`.\n\n")
        f.write(f"**{sum(r['agree'] for r in rows)} / {len(rows)} traces: BandwidthLab and the independent computation agree.**\n\n")
        f.write("| config | scenario | transactions | txn/cycle | accept->response mean / p50 / p99 / max | issue->accept mean / max | errors | agree |\n"
                "|---|---|---|---|---|---|---|---|\n")
        for r in rows:
            m = r["bandwidthlab"]; a = m["accept_to_response"]; i = m.get("issue_to_accept", {})
            f.write(f"| {r['config']} | {r['scenario']} | {m['complete']} | {m['transactions_per_cycle']:.3f} | "
                    f"{a['mean']:.2f} / {a['p50']:.0f} / {a['p99']:.0f} / {a['max']:.0f} | {i.get('mean', 0):.2f} / {i.get('max', 0):.0f} | "
                    f"{m.get('errors', 0)} | {'yes' if r['agree'] else '**NO** ' + str(r['checks'])} |\n")
        f.write("\nNot done: BandwidthLab's event-driven fabric model implements SFB2 rules (one transaction per port, "
                "RTL-validated against `sfb_crossbar`).  A model of SFB3 (IDs, several outstanding, posted writes, FENCE, the "
                "mesh) is a BandwidthLab extension; these traces are the reference data such a model would be calibrated "
                "against (docs/ISSUES.md).\n")
    for r in rows:
        print(f"{r['config']:12s} {r['scenario']:14s} agree={r['agree']} tpc={r['bandwidthlab']['transactions_per_cycle']:.3f}")
    return 0 if rows and all(r["agree"] for r in rows) else 1


if __name__ == "__main__":
    sys.exit(main())
