#!/usr/bin/env python3
"""Mutation campaign: testbench strength.

Each mutant is ONE deliberate bug in a copy of the RTL (build/mutants/<name>/).
The mutant is KILLED when at least one of its listed regression runs fails
(compile error does not count as killed).  A surviving mutant is a testbench
blind spot or an equivalent mutant (explained in the note).
Writes reports/mutants.{json,md}.
usage: mutants.py [--jobs N] [--only NAME ...]
"""
import argparse, json, os, re, shutil, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
sys.path.insert(0, os.path.dirname(__file__))
import regress  # CONFIGS, TESTS

OUT = os.path.join(ROOT, "build", "mutants")
MP, XB, SB_, QA, TB2, PF, MESH, RT, NI = ("rtl/noc/sfn_mst_port.sv", "rtl/noc/sfn_xbar.sv", "rtl/noc/sfn_sbus.sv",
                                          "rtl/noc/sfn_qos_arbiter.sv", "rtl/noc/sfn_sfb2_tgt_bridge.sv",
                                          "rtl/noc/sfn_perf.sv", "rtl/noc/sfn_mesh.sv", "rtl/noc/sfn_router.sv",
                                          "rtl/noc/sfn_ni.sv")

# name, file, old, new, description, [(config, test, seed)]
MUTANTS = [
    ("mp_no_id_rule", MP, "wire id_ok    = (r_idc == '0) ||", "wire id_ok    = 1'b1 || (r_idc == '0) ||",
     "O2 removed: an ID may be outstanding at two targets", [("xb_m4t4", "random", 1), ("xb_m4t4", "raw_fence", 1)]),
    ("mp_no_fence_gate", MP, "wire fence_ok = !is_fence ||", "wire fence_ok = 1'b1 || !is_fence ||",
     "O3 removed: FENCE accepted with transactions outstanding", [("xb_m4t4", "random", 1), ("xb_m4t4", "raw_fence", 1)]),
    ("mp_maxo_off_by_one", MP, "(out_q < CW'(MAXO))", "(out_q <= CW'(MAXO))",
     "O1 off by one: MAXO+1 outstanding", [("xb_m4t4", "random", 1), ("xb_m4t4", "maxload", 1)]),
    ("mp_posted_delivered", MP, "assign m_rsp_valid  = (sel_fr && !fr_post) || sel_lr;", "assign m_rsp_valid  = sel_fr || sel_lr;",
     "posted-write completion shown to the master", [("xb_m4t4", "random", 1)]),
    ("mp_orphan_by_id_only", MP, "(fr_idc != '0) && (fr_idt == fr_tgt)", "(fr_idc != '0)",
     "orphan check ignores the target an ID is outstanding at", [("xb_m4t4", "spurious", 1), ("xb_m4t4", "spurious", 2)]),
    ("mp_local_status_okay", MP, "lr_st_q    <= is_fence ? sfn_pkg::ST_OKAY : sfn_pkg::ST_DECERR;", "lr_st_q    <= sfn_pkg::ST_OKAY;",
     "decode errors answered OKAY", [("xb_m4t4", "errors", 1)]),
    ("mp_retire_any_id", MP, "((r_idc == CW'(1)) && byp && (ret_id == m_req_id))", "((r_idc == CW'(1)) && byp)",
     "retire-and-issue frees the wrong ID (RETIRE_BYPASS = 1 path)", [("xb_m5t6_byp", "random", 1), ("xb_m5t6_byp", "random", 2), ("xb_m5t6_byp", "maxload", 1)]),
    ("mp_posted_drop_answered", MP, "wire post_drop = !to_tgt && is_post;", "wire post_drop = 1'b0;",
     "posted write with a decode error gets a response", [("xb_m4t4", "errors", 1)]),
    ("mp_rsp_merge_no_lock", MP, ".stall(m_rsp_valid && !m_rsp_ready), .accept(ret),", ".stall(1'b0), .accept(ret),",
     "response merge may switch source while the master stalls", [("xb_m4t4", "random", 1), ("xb_m4t4", "errors", 1)]),
    ("mp_track_ignores_tgt", MP, "if (track && (m_req_id == IDW'(i))) idt_q[i*TW +: TW] <= tgt;", "",
     "per-ID target not recorded", [("xb_m4t4", "random", 1), ("xb_m4t4", "spurious", 1)]),
    ("xb_src_zero", XB, "assign t_req_src[gt*SRCW +: SRCW] = gidx;", "assign t_req_src[gt*SRCW +: SRCW] = '0;",
     "source identifier not stamped", [("xb_m4t4", "smoke", 1)]),
    ("xb_rsp_ignores_src", XB, "t_rsp_valid[gt] && (t_rsp_src[gt*SRCW +: SRCW] == SRCW'(gm))", "t_rsp_valid[gt]",
     "response steered to every master", [("xb_m4t4", "smoke", 1)]),
    ("xb_ready_ignores_tgt", XB, "if (grant[t*NM + m] && t_req_ready[t]) fq_ready[m] = 1'b1;", "if (grant[t*NM + m]) fq_ready[m] = 1'b1;",
     "master told accepted while the target is not ready", [("xb_m4t4", "backpress", 1)]),
    ("xb_rsp_ready_any", XB, "if (rgrant[m*NT + t] && fr_ready[m]) t_rsp_ready[t] = 1'b1;", "if (rgrant[m*NT + t]) t_rsp_ready[t] = 1'b1;",
     "target response consumed while the master stalls", [("xb_m4t4", "random", 1)]),
    ("qa_no_aging", QA, "urgent[i] = (age_q[i*AGW +: AGW] >= AGW'(STARVE));", "urgent[i] = 1'b0;",
     "QoS aging disabled: low levels can starve", [("xb_qos_m5t4", "qos_levels", 1), ("sb_qos_m5t4", "qos_levels", 1)]),
    ("qa_no_lock", QA, "if (lock_q && req[lock_idx_q]) begin", "if (1'b0) begin",
     "QoS arbiter grant lock removed", [("xb_qos_m5t4", "backpress", 1), ("xb_qos_m5t4", "random", 1)]),
    ("qa_frozen_pointer", QA, "prio_q <= (grant_idx == IW'(N - 1)) ? '0 : grant_idx + IW'(1);", "prio_q <= prio_q;",
     "QoS round-robin pointer frozen", [("xb_qos_m5t4", "hotspot", 1), ("xb_qos_s1_m4t2", "hotspot", 1)]),
    ("qa_age_not_reset", QA, "if (!req[i] || (accept && grant_valid && grant_idx == IW'(i)))", "if (!req[i])",
     "age not cleared on grant (priority lost)", [("xb_qos_m5t4", "qos_levels", 1), ("xb_qos_m5t4", "qos_levels", 2)]),
    ("sb_rsp_to_master0", SB_, "assign fr_valid[gm]              = rgv && (r_src == SRCW'(gm));",
     "assign fr_valid[gm]              = rgv && (gm == 0);", "shared bus steers every response to master 0",
     [("sb_m4t4", "smoke", 1)]),
    ("sb_ready_tgt0", SB_, "if (sel_t == TW'(t)) sel_ready = t_req_ready[t];", "if (t == 0) sel_ready = t_req_ready[t];",
     "shared bus uses target 0's ready", [("sb_m4t4", "backpress", 1)]),
    ("br_status_inverted", TB2, "assign t_rsp_status = s_rsp_error ? sfn_pkg::ST_SLVERR : sfn_pkg::ST_OKAY;",
     "assign t_rsp_status = s_rsp_error ? sfn_pkg::ST_OKAY : sfn_pkg::ST_SLVERR;", "bridge maps SFB2 errors wrongly",
     [("xb_sfb2tgt", "routes", 1), ("xb_sfb2tgt", "raw_fence", 1)]),
    ("br_posted_as_read", TB2, "assign s_req_write = sfn_pkg::op_is_write(t_req_opcode);",
     "assign s_req_write = (t_req_opcode == sfn_pkg::OP_WRITE);", "bridge turns posted writes into reads",
     [("xb_sfb2tgt", "raw_fence", 1)]),
    ("br_tag_pop_early", TB2, ".out_ready(s_rsp_valid && s_rsp_ready)", ".out_ready(s_rsp_valid)",
     "bridge pops its tag FIFO while the response is held", [("xb_sfb2tgt", "backpress", 1)]),
    ("pf_rdbytes_errors", PF, "if (m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_READ && m_rsp_status[m*2 +: 2] == sfn_pkg::ST_OKAY)",
     "if (m_rsp_opcode[m*3 +: 3] == sfn_pkg::OP_READ)", "delivered-bytes counter includes failed reads",
     [("xb_m4t4", "errors", 1)]),
    ("pf_stall_counts_valid", PF, "if (m_req_valid[m] && !m_req_ready[m])\n            mc_q[(m*NMC+M_REQ_STALL)",
     "if (m_req_valid[m])\n            mc_q[(m*NMC+M_REQ_STALL)", "back-pressure counter counts accepted cycles",
     [("xb_m4t4", "smoke", 1)]),
    ("pf_occ_max_never", PF, "if (32'(m_out_cnt[m*CW +: CW]) > mc_q[(m*NMC+M_OCC_MAX)*32 +: 32])", "if (1'b0)",
     "occupancy maximum never updated", [("xb_m4t4", "smoke", 1)]),
]

# mesh mutants are appended by mutants_mesh.py when the mesh exists
EXTRA = os.path.join(os.path.dirname(__file__), "mutants_mesh.py")
if os.path.exists(EXTRA):
    exec(open(EXTRA).read())

def make_tree(name, f, old, new):
    d = os.path.join(OUT, name)
    if os.path.exists(d):
        shutil.rmtree(d)
    for sub in ("rtl", "third_party", "tb"):
        shutil.copytree(os.path.join(ROOT, sub), os.path.join(d, sub))
    for fl in ("files_rtl.f", "files_tb.f"):
        shutil.copy(os.path.join(ROOT, fl), d)
    p = os.path.join(d, f)
    src = open(p).read()
    if old not in src:
        raise SystemExit(f"mutant {name}: pattern not found in {f}: {old!r}")
    open(p, "w").write(src.replace(old, new, 1))
    return d

def flist(d, name):
    return [os.path.join(d, l.strip()) for l in open(os.path.join(d, name)) if l.strip()]

def one(m):
    name, f, old, new, desc, runs = m
    d = make_tree(name, f, old, new)
    t0 = time.time()
    killed_by, results, built = None, [], {}
    for cfg, test, seed in runs:
        if cfg not in built:
            bd = os.path.join(d, "build", cfg)
            os.makedirs(bd, exist_ok=True)
            g = [f"-G{k}={v}" for k, v in regress.CONFIGS[cfg].items()]
            r = subprocess.run(["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint",
                                "-Wno-style", f"-I{d}/tb", "--top-module", "tb_noc", "--Mdir", bd, "-o", "sim", "-j", "2"]
                               + g + flist(d, "files_rtl.f") + flist(d, "files_tb.f"), capture_output=True, text=True)
            built[cfg] = r.returncode == 0
            if not built[cfg]:
                results.append(dict(cfg=cfg, test=test, seed=seed, outcome="BUILD ERROR", detail=(r.stderr or r.stdout)[-400:]))
                continue
        if not built[cfg]:
            continue
        args = [f"+seed={seed}"] + regress.TESTS[test].split()
        try:
            r = subprocess.run([os.path.join(d, "build", cfg, "sim")] + args, cwd=d, capture_output=True, text=True, timeout=900)
            out, rc = r.stdout + r.stderr, r.returncode
        except subprocess.TimeoutExpired:
            out, rc = "TIMEOUT", -9
        passed = rc == 0 and "TEST PASSED" in out
        err = next((l for l in out.splitlines() if "%Error" in l or "Assertion failed" in l or "TIMEOUT" in l), "")
        results.append(dict(cfg=cfg, test=test, seed=seed, outcome="pass" if passed else "FAIL", detail=err[:240]))
        if not passed and killed_by is None:
            killed_by = f"{cfg}/{test}/s{seed}"
            break
    shutil.rmtree(os.path.join(d, "build"), ignore_errors=True)
    return dict(mutant=name, file=f, description=desc, killed=killed_by is not None, killed_by=killed_by,
                runs=results, secs=round(time.time() - t0, 1))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", nargs="*")
    a = ap.parse_args()
    sel = [m for m in MUTANTS if not a.only or m[0] in a.only]
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(one, sel))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports", "mutants.json"), "w"), indent=1)
    k = sum(r["killed"] for r in res)
    with open(os.path.join(ROOT, "reports", "mutants.md"), "w") as f:
        f.write(f"# Mutation campaign (testbench strength)\n\nEach mutant is one deliberate RTL bug; it is killed when "
                f"one of its regression runs fails.  Generated by `scripts/mutants.py`.\n\n**{k} / {len(res)} killed.**\n\n"
                "| mutant | file | bug | killed by | first failure |\n|---|---|---|---|---|\n")
        for r in res:
            first = next((x["detail"] for x in r["runs"] if x["outcome"] != "pass"), "")
            f.write(f"| {r['mutant']} | `{r['file']}` | {r['description']} | {r['killed_by'] or '**SURVIVED**'} | "
                    f"`{first.replace('|', '/')[:150]}` |\n")
    for r in res:
        print(f"{'KILLED ' if r['killed'] else 'SURVIVED'} {r['mutant']:26s} {r['killed_by'] or ''}")
    print(f"{k}/{len(res)} killed")
    return 0 if k == len(res) else 1

if __name__ == "__main__":
    sys.exit(main())
