#!/usr/bin/env python3
"""Lint / elaboration / illegal-parameter checks for silicaflux_noc.

For every configuration: Verilator --lint-only -Wall (must give ZERO warnings),
Icarus 12 elaboration (iverilog -g2012), Yosys 0.33 elaboration (`proc; check
-assert`, no latches).  Negative tests: each illegal parameter set must be refused
by the elaboration checks (simulation run of a one-instance wrapper ends in $fatal).
Writes reports/lint.{json,md}.
"""
import json, os, re, subprocess, sys
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
RTL = [l.strip() for l in open(os.path.join(ROOT, "files_rtl.f")) if l.strip()]
OUT = os.path.join(ROOT, "build", "lint")

def mesh(nm, nt, mx, my):
    nn = mx * my
    mn = "".join(f"{m % nn:02x}" for m in reversed(range(nm)))
    tn = "".join(f"{(nn - 1 - t % nn):02x}" for t in reversed(range(nt)))
    return dict(TOPOLOGY=2, NM=nm, NT=nt, MESH_X=mx, MESH_Y=my, MST_NODE=f"{8*nm}'h{mn}", TGT_NODE=f"{8*nt}'h{tn}")

CONFIGS = {
    "xbar_m4t4":       dict(TOPOLOGY=1, NM=4, NT=4),
    "xbar_m5t6_qos":   dict(TOPOLOGY=1, NM=5, NT=6, ARB_MODE=2),
    "xbar_m1t1":       dict(TOPOLOGY=1, NM=1, NT=1),
    "xbar_m8t8_id3":   dict(TOPOLOGY=1, NM=8, NT=8, IDW=3, MAXO_MAX=8, MST_MAXO="64'h0808080808080808"),
    "xbar_d128_aw48":  dict(TOPOLOGY=1, NM=3, NT=3, DW=128, AW=48),
    "xbar_fixed_noperf": dict(TOPOLOGY=1, NM=4, NT=4, ARB_MODE=0, PERF=0),
    "xbar_m4t6_bypass":  dict(TOPOLOGY=1, NM=4, NT=6, RETIRE_BYPASS=1),
    "sbus_m4t4":       dict(TOPOLOGY=0, NM=4, NT=4),
    "sbus_m5t6_qos":   dict(TOPOLOGY=0, NM=5, NT=6, ARB_MODE=2),
    "mesh_2x2":        mesh(4, 4, 2, 2),
    "mesh_3x2_qos":    dict(mesh(5, 6, 3, 2), ARB_MODE=2),
    "mesh_4x4_m8t8":   dict(mesh(8, 8, 4, 4), MAXO_MAX=8, MST_MAXO="64'h0808080808080808"),
    "mesh_2x2_d64_aw48": dict(mesh(4, 4, 2, 2), DW=64, AW=48),
}
# illegal parameter sets that the elaboration checks must refuse
ILLEGAL = {
    "dw_48":            dict(TOPOLOGY=1, NM=2, NT=2, DW=48),
    "maxo_zero":        dict(TOPOLOGY=1, NM=2, NT=2, MST_MAXO="16'h0004"),
    "maxo_above_max":   dict(TOPOLOGY=1, NM=2, NT=2, MAXO_MAX=4, MST_MAXO="16'h0805"),
    "topology_3":       dict(TOPOLOGY=3, NM=2, NT=2),
    "arb_mode_3":       dict(TOPOLOGY=1, NM=2, NT=2, ARB_MODE=3),
    "windows_overlap":  dict(TOPOLOGY=1, NM=2, NT=2, TGT_BASE="64'h1000000010000000", TGT_MASK="64'hFFF00000FFF00000"),
    "base_outside_mask": dict(TOPOLOGY=1, NM=2, NT=2, TGT_BASE="64'h1000000120000000", TGT_MASK="64'hFFF00000FFF00000"),
    "mesh_two_masters_one_node": dict(TOPOLOGY=2, NM=2, NT=2, MESH_X=2, MESH_Y=2, MST_NODE="16'h0000", TGT_NODE="16'h0302"),
    "mesh_node_out_of_range":    dict(TOPOLOGY=2, NM=2, NT=2, MESH_X=2, MESH_Y=2, MST_NODE="16'h0700", TGT_NODE="16'h0302"),
    "mesh_fifo_depth_1": dict(mesh(2, 2, 2, 2), FIFO_DEPTH=1),
}
LEGAL_MAP = dict(TGT_BASE=None)   # default windows are all zero: give legal non-overlapping ones below

def default_windows(p):
    if "TGT_BASE" in p:
        return p
    nt = int(p.get("NT", 4)); aw = int(p.get("AW", 32))
    base = "".join(f"{(1 << (aw - 4)) + (t << 20):0{aw // 4}x}" for t in reversed(range(nt)))
    mask = "".join(f"{((1 << aw) - 1) & ~((1 << 20) - 1):0{aw // 4}x}" for t in reversed(range(nt)))
    return dict(p, TGT_BASE=f"{aw*nt}'h{base}", TGT_MASK=f"{aw*nt}'h{mask}")

def run(cmd, **kw):
    r = subprocess.run(cmd, capture_output=True, text=True, cwd=ROOT, **kw)
    return r.returncode, r.stdout + r.stderr

def lint_one(name):
    p = default_windows(CONFIGS[name])
    d = os.path.join(OUT, name); os.makedirs(d, exist_ok=True)
    G = [f"-G{k}={v}" for k, v in p.items()]
    rc, out = run(["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "--top-module", "silicaflux_noc"] + G + RTL)
    nwarn = len(re.findall(r"^%Warning", out, re.M))
    ver = dict(ok=rc == 0 and nwarn == 0, warnings=nwarn, detail=out[-600:] if rc or nwarn else "")
    P = [f"-Psilicaflux_noc.{k}={v}" for k, v in p.items()]
    rc, out = run(["iverilog", "-g2012", "-o", os.path.join(d, "a.out"), "-s", "silicaflux_noc"] + P + RTL)
    if rc == 0:   # run the elaboration-time checks (initial blocks): a legal configuration must not $fatal
        rc, out2 = run(["vvp", "-n", os.path.join(d, "a.out")], timeout=60)
        rc = rc if "FATAL" not in out2.upper() else 1
        out = out + out2
    ica = dict(ok=rc == 0, detail=out[-600:] if rc else "")
    ch = "".join(f"chparam -set {k} {v} silicaflux_noc; " for k, v in p.items())
    rc, out = run(["yosys", "-q", "-p", f"read_verilog -sv -DSYNTHESIS {' '.join(RTL)}; {ch}hierarchy -top silicaflux_noc; "
                   "proc; check -assert; select -assert-none t:$dlatch t:$adlatch t:$sr; stat -width"])
    yos = dict(ok=rc == 0, detail=out[-600:] if rc else "")
    return dict(config=name, params=p, verilator=ver, icarus=ica, yosys=yos, ok=ver["ok"] and ica["ok"] and yos["ok"])

def illegal_one(name):
    p = default_windows(ILLEGAL[name]) if "TGT_BASE" not in ILLEGAL[name] else ILLEGAL[name]
    d = os.path.join(OUT, "illegal", name); os.makedirs(d, exist_ok=True)
    w = os.path.join(d, "tb_param.sv")
    open(w, "w").write("module tb_param; initial begin #1; $display(\"ELABORATED\"); $finish; end endmodule\n")
    # Verilator: build the top itself as a binary with the parameters and run it (initial-block $fatal checks)
    G = [f"-G{k}={v}" for k, v in p.items()]
    rc, out = run(["verilator", "--binary", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module", "silicaflux_noc",
                   "--Mdir", d, "-o", "sim"] + G + RTL)
    if rc == 0:
        rc2, out2 = run([os.path.join(d, "sim")], timeout=60)
        v_ok = rc2 != 0 and "fatal" in out2.lower()
        v_det = out2.strip().splitlines()[-2:] if out2.strip() else []
    else:
        v_ok, v_det = ("Error" in out), out.strip().splitlines()[-2:]   # refused already at compile time
    P = [f"-Psilicaflux_noc.{k}={v}" for k, v in p.items()]
    rc, out = run(["iverilog", "-g2012", "-o", os.path.join(d, "a.out"), "-s", "silicaflux_noc"] + P + RTL)
    if rc == 0:
        rc2, out2 = run(["vvp", "-n", os.path.join(d, "a.out")], timeout=60)
        i_ok = "FATAL" in out2.upper() or rc2 != 0
        i_det = out2.strip().splitlines()[-2:] if out2.strip() else []
    else:
        i_ok, i_det = True, out.strip().splitlines()[-2:]
    return dict(case=name, params=p, verilator=v_ok, icarus=i_ok, ok=v_ok and i_ok, detail=dict(verilator=v_det, icarus=i_det))

def main():
    os.makedirs(OUT, exist_ok=True)
    with ThreadPoolExecutor(4) as ex:
        res = list(ex.map(lint_one, CONFIGS))
        neg = list(ex.map(illegal_one, ILLEGAL))
    ver = lambda c: (subprocess.run(c, capture_output=True, text=True).stdout or "n/a").strip().splitlines()[0]
    tools = dict(verilator=ver(["verilator", "--version"]), icarus=ver(["iverilog", "-V"]), yosys=ver(["yosys", "-V"]))
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(dict(tools=tools, configs=res, illegal=neg), open(os.path.join(ROOT, "reports", "lint.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports", "lint.md"), "w") as f:
        f.write(f"# Lint, elaboration and illegal-parameter checks\n\n{tools['verilator']}; {tools['icarus']}; {tools['yosys']}.  "
                "Verilator `--lint-only -Wall` must report zero warnings (local waivers in the RTL are commented); Icarus "
                "must elaborate; Yosys `proc; check -assert` with no latch cells.  Generated by `scripts/lint.py`.\n\n")
        f.write(f"**{sum(r['ok'] for r in res)} / {len(res)} configurations clean; "
                f"{sum(r['ok'] for r in neg)} / {len(neg)} illegal parameter sets refused by both simulators.**\n\n")
        f.write("| configuration | Verilator -Wall | Icarus | Yosys (no latch) |\n|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['config']} | {'0 warnings' if r['verilator']['ok'] else '**' + str(r['verilator']['warnings']) + ' warnings / error**'} | "
                    f"{'OK' if r['icarus']['ok'] else '**FAIL**'} | {'OK' if r['yosys']['ok'] else '**FAIL**'} |\n")
        f.write("\n| illegal parameter set | Verilator refuses | Icarus refuses | message |\n|---|---|---|---|\n")
        for r in neg:
            msg = " ".join(r["detail"]["verilator"])[:140].replace("|", "/")
            f.write(f"| {r['case']} | {'yes' if r['verilator'] else '**NO**'} | {'yes' if r['icarus'] else '**NO**'} | `{msg}` |\n")
    for r in res:
        print(f"{r['config']:22s} {'OK' if r['ok'] else 'NOT OK'} {'' if r['ok'] else (r['verilator']['detail'] + r['icarus']['detail'] + r['yosys']['detail'])[-400:]}")
    for r in neg:
        print(f"illegal {r['case']:28s} {'refused' if r['ok'] else 'NOT REFUSED'} {r['detail']}")
    return 0 if all(r["ok"] for r in res + neg) else 1

if __name__ == "__main__":
    sys.exit(main())
