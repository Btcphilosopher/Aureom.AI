#!/bin/bash
# Final run on frozen sources: every report in reports/ comes from this sequence.
cd "$(dirname "$0")/.."
mkdir -p build/final
step() { n=$1; shift; t0=$(date +%s); "$@" > build/final/$n.log 2>&1; rc=$?; echo "$n rc=$rc $(( $(date +%s) - t0 ))s" >> build/final/steps.txt; }
: > build/final/steps.txt
step lint          python3 scripts/lint.py
step test-crossbar python3 scripts/regress.py --suite crossbar --jobs 4
step test-sbus     python3 scripts/regress.py --suite sbus --jobs 4
step test-mesh     python3 scripts/regress.py --suite mesh --jobs 4
step formal        env FORMAL_JOBS=4 PDR_TIMEOUT=900 python3 formal/run_formal.py
step mutants       python3 scripts/mutants.py --jobs 4
step endpoints     python3 integration/run_endpoints.py --jobs 3
step synth         env SYNTH_JOBS=3 python3 scripts/synth.py
step bench         python3 scripts/bench.py --jobs 4
step bandwidthlab  python3 python/sfn_bandwidthlab.py
echo DONE >> build/final/steps.txt
