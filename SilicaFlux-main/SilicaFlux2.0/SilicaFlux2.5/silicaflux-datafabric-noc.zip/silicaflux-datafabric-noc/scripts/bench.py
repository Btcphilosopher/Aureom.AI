#!/usr/bin/env python3
"""Design exploration benchmark: shared bus vs crossbar vs mesh on identical endpoints.

Every number comes from an RTL simulation of silicaflux_noc (Verilator) with the self-checking
testbench (each run must also PASS all scoreboard checks) and a per-transaction trace.  Metrics are
computed here from the trace:
  useful bandwidth  = bytes delivered with OKAY status (read data at the master, write data at the
                      target) / measurement window (first acceptance .. last completion), bytes/cycle
  fabric latency    = request acceptance -> response acceptance (cycles)
  access latency    = first cycle the request is presented -> response acceptance (includes arbitration)
  fairness          = Jain's index over per-master completed transactions
Cycle counts only: no clock frequency or wire delay is assumed.
Writes reports/bench.{json,md} and the traces under build/bench/.
usage: bench.py [--jobs N] [--only SCENARIO ...]
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BUILD = os.path.join(ROOT, "build", "bench")
sys.path.insert(0, os.path.dirname(__file__))
import regress  # noqa: E402

CONFIGS = {
    # set A: 4 masters x 4 targets (2x2 mesh)
    "A_sbus": dict(TOPOLOGY=0, NM=4, NT=4, MAXO0=4),
    "A_xbar": dict(TOPOLOGY=1, NM=4, NT=4, MAXO0=4),
    "A_mesh": dict(TOPOLOGY=2, NM=4, NT=4, MAXO0=4, MESH_X=2, MESH_Y=2),
    # set B: SilicaFlux-HPC endpoint count, 4 masters x 6 targets (3x2 mesh)
    "B_sbus": dict(TOPOLOGY=0, NM=4, NT=6, MAXO0=4),
    "B_xbar": dict(TOPOLOGY=1, NM=4, NT=6, MAXO0=4),
    "B_mesh": dict(TOPOLOGY=2, NM=4, NT=6, MAXO0=4, MESH_X=3, MESH_Y=2),
    # set C: scale-out, 8 masters x 8 targets (3x3 and 4x4 meshes)
    "C_sbus": dict(TOPOLOGY=0, NM=8, NT=8, MAXO0=4),
    "C_xbar": dict(TOPOLOGY=1, NM=8, NT=8, MAXO0=4),
    "C_mesh": dict(TOPOLOGY=2, NM=8, NT=8, MAXO0=4, MESH_X=3, MESH_Y=3),
    "C_mesh4": dict(TOPOLOGY=2, NM=8, NT=8, MAXO0=4, MESH_X=4, MESH_Y=4),
    # QoS: ControlCore-like master 0 (1 outstanding) among bulk masters
    "Q_xbar_rr":  dict(TOPOLOGY=1, NM=4, NT=4, MAXO0=1, ARB_MODE=1),
    "Q_xbar_qos": dict(TOPOLOGY=1, NM=4, NT=4, MAXO0=1, ARB_MODE=2, STARVE=8),
    "Q_xbar_fix": dict(TOPOLOGY=1, NM=4, NT=4, MAXO0=1, ARB_MODE=0),
    "Q_sbus_rr":  dict(TOPOLOGY=0, NM=4, NT=4, MAXO0=1, ARB_MODE=1),
    "Q_sbus_qos": dict(TOPOLOGY=0, NM=4, NT=4, MAXO0=1, ARB_MODE=2, STARVE=8),
    "Q_mesh_rr":  dict(TOPOLOGY=2, NM=4, NT=4, MAXO0=1, ARB_MODE=1, MESH_X=2, MESH_Y=2),
    "Q_mesh_qos": dict(TOPOLOGY=2, NM=4, NT=4, MAXO0=1, ARB_MODE=2, STARVE=8, MESH_X=2, MESH_Y=2),
    # outstanding transactions vs a pipelined target
    "O_mo1": dict(TOPOLOGY=1, NM=4, NT=4, MAXO=1, MAXO0=1),
    "O_mo1_byp": dict(TOPOLOGY=1, NM=4, NT=4, MAXO=1, MAXO0=1, RETIRE_BYPASS=1),
    "O_mo2_byp": dict(TOPOLOGY=1, NM=4, NT=4, MAXO=2, MAXO0=2, RETIRE_BYPASS=1),
    "O_mo2": dict(TOPOLOGY=1, NM=4, NT=4, MAXO=2, MAXO0=2),
    "O_mo4": dict(TOPOLOGY=1, NM=4, NT=4, MAXO=4, MAXO0=4),
    "O_mo8": dict(TOPOLOGY=1, NM=4, NT=4, MAXO=8, MAXO0=8, IDW=3, QCAP=16),
    "O_mesh_mo1": dict(TOPOLOGY=2, NM=4, NT=4, MAXO=1, MAXO0=1, MESH_X=2, MESH_Y=2),
    "O_mesh_mo4": dict(TOPOLOGY=2, NM=4, NT=4, MAXO=4, MAXO0=4, MESH_X=2, MESH_Y=2),
    "O_mesh_mo8": dict(TOPOLOGY=2, NM=4, NT=4, MAXO=8, MAXO0=8, IDW=3, QCAP=16, MESH_X=2, MESH_Y=2),
}
MIX = "+p_rd=600 +p_wr=200 +p_post=200 +p_fence=0"
RATES = [50, 100, 200, 300, 500, 700, 1000]
SCEN = []
for s in "ABC":
    for topo in (["sbus", "xbar", "mesh"] + (["mesh4"] if s == "C" else [])):
        cfg = f"{s}_{topo}"
        for r in RATES:
            SCEN.append(("load", cfg, f"+amode=0 +rate={r} +n=1200 {MIX}", dict(rate=r)))
        SCEN.append(("perm", cfg, f"+amode=4 +shift=1 +rate=1000 +n=2000 {MIX}", {}))
        SCEN.append(("hotspot", cfg, f"+amode=1 +hot=0 +rate=1000 +n=1500 {MIX}", {}))
        if s != "C":
            SCEN.append(("bursts", cfg, f"+amode=2 +burst=256 +rate=1000 +n=2048 {MIX}", {}))
for cfg in ("A_mesh", "B_mesh", "C_mesh4"):
    SCEN.append(("zeroload", cfg, f"+amode=0 +rate=15 +n=300 {MIX}", {}))
for cfg in ("Q_xbar_rr", "Q_xbar_qos", "Q_xbar_fix", "Q_sbus_rr", "Q_sbus_qos", "Q_mesh_rr", "Q_mesh_qos"):
    # master 0 (ControlCore class 3) sparse reads into a target the bulk masters (class 0) saturate
    SCEN.append(("qos", cfg, "+amode=1 +hot=0 +p_hot=1000 +rate=1000 +rate0=60 +n=2500 +n0=200 +qos0=3 "
                             "+p_rd=700 +p_wr=300 +p_post=0 +p_fence=0 +lat_max=2", {}))
for cfg in ("O_mo1", "O_mo1_byp", "O_mo2", "O_mo2_byp", "O_mo4", "O_mo8", "O_mesh_mo1", "O_mesh_mo4", "O_mesh_mo8"):
    for lat in (1, 4, 8):
        SCEN.append(("outstanding", cfg, f"+amode=4 +shift=0 +rate=1000 +n=1500 +p_rd=1000 +p_wr=0 +p_post=0 "
                                         f"+p_fence=0 +lat_min={lat} +lat_max={lat}", dict(lat=lat)))


def build(cfg):
    d = os.path.join(BUILD, cfg)
    os.makedirs(d, exist_ok=True)
    g = [f"-G{k}={v}" for k, v in CONFIGS[cfg].items()]
    cmd = (["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style",
            "-Itb", "--top-module", "tb_noc", "--Mdir", d, "-o", "sim", "-j", "2"] + g +
           regress.flist("files_rtl.f") + regress.flist("files_tb.f"))
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    open(os.path.join(d, "build.log"), "w").write(r.stdout + r.stderr)
    return cfg, r.returncode


def placement(p):
    nn = p.get("MESH_X", 1) * p.get("MESH_Y", 1)
    mx = p.get("MESH_X", 1)
    mnode = lambda m: m % nn
    tnode = lambda t: nn - 1 - t % nn
    xy = lambda n: (n % mx, n // mx)
    return lambda m, t: abs(xy(mnode(m))[0] - xy(tnode(t))[0]) + abs(xy(mnode(m))[1] - xy(tnode(t))[1])


def stats(v):
    v = np.asarray(v, dtype=float)
    if v.size == 0:
        return {}
    return dict(n=int(v.size), mean=round(float(v.mean()), 2), p50=float(np.percentile(v, 50)),
                p95=float(np.percentile(v, 95)), p99=float(np.percentile(v, 99)), max=float(v.max()), min=float(v.min()))


def analyse(trace, cfg):
    df = pd.read_csv(trace)
    ok = df[df.status == 0]
    win = int(df.done_cycle.max() - df.accept_cycle.min() + 1)
    nonposted = df[df.op.isin([0, 1])]
    # fairness while every master competes: completions per master up to the moment the first
    # master completes its last transaction (afterwards the remaining masters run with less competition)
    act = df[df.master.isin([m for m in range(CONFIGS[cfg]["NM"])])]
    t_cut = act.groupby("master").done_cycle.max().min()
    per = act[act.done_cycle <= t_cut].groupby("master").size().reindex(range(CONFIGS[cfg]["NM"]), fill_value=0)
    per = per[per.index.isin(act.master.unique())]
    jain = float(per.sum() ** 2 / (len(per) * (per ** 2).sum())) if len(per) and (per ** 2).sum() else None
    out = dict(window=win, txns=int(len(df)), bytes=int(ok.bytes.sum()), bw=round(float(ok.bytes.sum()) / win, 3),
               txn_per_cycle=round(len(df) / win, 3), fabric_lat=stats(nonposted.latency),
               access_lat=stats(nonposted.access_latency), jain=round(jain, 4) if jain else None,
               fair_window=int(t_cut - df.accept_cycle.min() + 1),
               per_master_txn_in_window=[int(per.get(m, 0)) for m in range(CONFIGS[cfg]["NM"])])
    out["m0_access_lat"] = stats(nonposted[nonposted.master == 0].access_latency)
    out["bulk_access_lat"] = stats(nonposted[nonposted.master != 0].access_latency)
    if CONFIGS[cfg]["TOPOLOGY"] == 2:
        hop = placement(CONFIGS[cfg])
        h = nonposted[nonposted.target >= 0].copy()
        h["hops"] = [hop(m, t) for m, t in zip(h.master, h.target)]
        out["lat_by_hops"] = {int(k): stats(g.latency) for k, g in h.groupby("hops")}
    return out


def run(sc):
    kind, cfg, args, meta = sc
    tag = f"{kind}_{meta.get('rate', meta.get('lat', ''))}".rstrip("_")
    tr = os.path.join(BUILD, cfg, f"{tag}.csv")
    cmd = [os.path.join(BUILD, cfg, "sim"), "+seed=7", f"+trace={tr}", f"+test={cfg}/{tag}"] + args.split()
    t0 = time.time()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True, timeout=3600)
    out = r.stdout + r.stderr
    passed = r.returncode == 0 and "TEST PASSED" in out
    res = json.loads(re.search(r"^RESULT (\{.*\})$", out, re.M).group(1)) if "RESULT {" in out else {}
    links = json.loads(re.search(r"^LINKS (\{.*\})$", out, re.M).group(1)) if "LINKS {" in out else {}
    row = dict(kind=kind, config=cfg, params=CONFIGS[cfg], args=args, meta=meta, passed=passed, cmd=" ".join(cmd),
               secs=round(time.time() - t0, 1), result=res, links=links, trace=os.path.relpath(tr, ROOT))
    if passed:
        row["m"] = analyse(tr, cfg)
    return row


def fmt(s, k="mean"):
    return "-" if not s else f"{s[k]:.1f}" if isinstance(s[k], float) else str(s[k])


def write(rows):
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(rows, open(os.path.join(ROOT, "reports", "bench.json"), "w"), indent=1, default=str)
    R = lambda kind, cfg, **mt: next((r for r in rows if r["kind"] == kind and r["config"] == cfg and
                                      all(r["meta"].get(k) == v for k, v in mt.items())), None)
    with open(os.path.join(ROOT, "reports", "bench.md"), "w") as f:
        f.write("# Design exploration: measured performance (RTL simulation)\n\nGenerated by `scripts/bench.py`.  Every "
                "row is a Verilator simulation of `silicaflux_noc` that also PASSED the full scoreboard (traces in "
                "`build/bench`).  Cycles only -- no clock frequency or wire delay is assumed.  Targets are single-cycle "
                "memories unless stated; bandwidth counts OKAY payload bytes (32-bit data path, so 4 B per transfer).\n\n")
        f.write(f"**{sum(r['passed'] for r in rows)} / {len(rows)} benchmark runs passed their checks.**\n\n")
        for s, title in (("A", "4 masters x 4 targets"), ("B", "4 masters x 6 targets (SilicaFlux-HPC endpoint count)"),
                         ("C", "8 masters x 8 targets")):
            topos = ["sbus", "xbar", "mesh"] + (["mesh4"] if s == "C" else [])
            f.write(f"## Set {s}: {title}\n\n### Uniform random traffic: useful bandwidth (B/cycle) and mean fabric / access latency vs offered load\n\n"
                    "| offered rate (per master, /1000 cycles) | " + " | ".join(f"{t} B/cyc | {t} lat (fab/acc)" for t in topos) +
                    " |\n|---|" + "---|---|" * len(topos) + "\n")
            for rt in RATES:
                cells = []
                for t in topos:
                    r = R("load", f"{s}_{t}", rate=rt)
                    if r and r["passed"]:
                        cells += [f"{r['m']['bw']:.2f}", f"{fmt(r['m']['fabric_lat'])} / {fmt(r['m']['access_lat'])}"]
                    else:
                        cells += ["FAIL", ""]
                f.write(f"| {rt} | " + " | ".join(cells) + " |\n")
            f.write("\n### Pattern summary at saturation (rate 1000)\n\n| pattern | topology | B/cycle | txn/cycle | fabric lat mean / p99 / max | "
                    "access lat mean / p99 / max | Jain fairness | busiest link transfers/cycle |\n|---|---|---|---|---|---|---|---|\n")
            for kind in ("perm", "hotspot", "bursts"):
                for t in topos:
                    r = R(kind, f"{s}_{t}")
                    if not r:
                        continue
                    if not r["passed"]:
                        f.write(f"| {kind} | {t} | **FAIL** | | | | | |\n"); continue
                    m, L = r["m"], r["links"]
                    lk = (L["mesh_link_max_flits"] if r["params"]["TOPOLOGY"] == 2 else L["tgt_link_max_transfers"]) / max(1, L["cycles_counted"])
                    f.write(f"| {kind} | {t} | {m['bw']:.2f} | {m['txn_per_cycle']:.2f} | {fmt(m['fabric_lat'])} / {fmt(m['fabric_lat'],'p99')} / "
                            f"{fmt(m['fabric_lat'],'max')} | {fmt(m['access_lat'])} / {fmt(m['access_lat'],'p99')} / {fmt(m['access_lat'],'max')} | "
                            f"{m['jain']} | {lk:.2f}{' (flits)' if r['params']['TOPOLOGY'] == 2 else ''} |\n")
            f.write("\n")
        f.write("## Mesh zero-load latency vs hop count (rate 15 / 1000 per master)\n\n| mesh | hops | n | fabric latency mean | min..max |\n|---|---|---|---|---|\n")
        for cfg in ("A_mesh", "B_mesh", "C_mesh4"):
            r = R("zeroload", cfg)
            if r and r["passed"]:
                for h, st in sorted(r["m"]["lat_by_hops"].items(), key=lambda kv: int(kv[0])):
                    f.write(f"| {cfg} | {h} | {st['n']} | {st['mean']} | {int(st['min'])}..{int(st['max'])} |\n")
        f.write("\n## QoS: ControlCore-class master 0 (sparse reads, 1 outstanding) vs 3 bulk masters saturating the same target\n\n"
                "| config | master 0 access latency mean / p50 / p99 / max | bulk access latency mean / p99 / max | B/cycle (all masters) | "
                "bulk completions per master while all compete |\n|---|---|---|---|---|\n")
        for cfg in ("Q_xbar_rr", "Q_xbar_qos", "Q_xbar_fix", "Q_sbus_rr", "Q_sbus_qos", "Q_mesh_rr", "Q_mesh_qos"):
            r = R("qos", cfg)
            if r and r["passed"]:
                m = r["m"]
                f.write(f"| {cfg} | {fmt(m['m0_access_lat'])} / {fmt(m['m0_access_lat'],'p50')} / {fmt(m['m0_access_lat'],'p99')} / "
                        f"{fmt(m['m0_access_lat'],'max')} | {fmt(m['bulk_access_lat'])} / {fmt(m['bulk_access_lat'],'p99')} / "
                        f"{fmt(m['bulk_access_lat'],'max')} | {m['bw']:.2f} | {m['per_master_txn_in_window'][1:]} |\n")
            elif r:
                f.write(f"| {cfg} | **FAIL** | | |\n")
        f.write("\n## Outstanding transactions vs a pipelined target (each master streams reads to its own target)\n\n"
                "| config | target latency | B/cycle (4 masters) | per master B/cycle | fabric latency mean |\n|---|---|---|---|---|\n")
        for cfg in ("O_mo1", "O_mo1_byp", "O_mo2", "O_mo2_byp", "O_mo4", "O_mo8", "O_mesh_mo1", "O_mesh_mo4", "O_mesh_mo8"):
            for lat in (1, 4, 8):
                r = R("outstanding", cfg, lat=lat)
                if r and r["passed"]:
                    f.write(f"| {cfg} | {lat} | {r['m']['bw']:.2f} | {r['m']['bw'] / 4:.2f} | {fmt(r['m']['fabric_lat'])} |\n")
                elif r:
                    f.write(f"| {cfg} | {lat} | **FAIL** | | |\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", nargs="*")
    ap.add_argument("--reanalyse", action="store_true", help="recompute metrics from existing traces (no simulation)")
    a = ap.parse_args()
    if a.reanalyse:
        rows = json.load(open(os.path.join(ROOT, "reports", "bench.json")))
        for r in rows:
            if r["passed"]:
                r["m"] = analyse(os.path.join(ROOT, r["trace"]), r["config"])
        write(rows)
        print(f"re-analysed {len(rows)} runs")
        return 0
    sc = [s for s in SCEN if not a.only or s[0] in a.only]
    cfgs = sorted({s[1] for s in sc})
    with ThreadPoolExecutor(a.jobs) as ex:
        b = list(ex.map(build, cfgs))
    bad = [c for c, rc in b if rc]
    if bad:
        print("BUILD FAILED:", bad)
    sc = [s for s in sc if s[1] not in bad]
    with ThreadPoolExecutor(a.jobs) as ex:
        rows = list(ex.map(run, sc))
    write(rows)
    n = sum(r["passed"] for r in rows)
    print(f"bench: {n}/{len(rows)} runs passed")
    for r in rows:
        if not r["passed"]:
            print("FAILED", r["config"], r["kind"], r["meta"], r["result"].get("errors"))
    return 0 if n == len(rows) and not bad else 1


if __name__ == "__main__":
    sys.exit(main())
