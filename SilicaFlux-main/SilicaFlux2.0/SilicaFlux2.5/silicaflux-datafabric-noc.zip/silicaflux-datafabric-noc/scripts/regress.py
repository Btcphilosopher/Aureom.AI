#!/usr/bin/env python3
"""DataFabric-NoC regression runner.

Builds every testbench configuration once with Verilator (in parallel), runs the
test matrix (config x test x seed, in parallel) and writes
reports/<name>.json + reports/<name>.md.  Every row records the exact command,
seed, exit code, RESULT line and wall time.  A row passes when the simulator
exits 0 and prints "TEST PASSED" -- or, for `expect: FAIL` rows (negative
tests), when it reports a failure.

usage: regress.py [--suite crossbar|sbus|mesh|all|quick] [--jobs N] [--name REPORT]
"""
import argparse, json, os, re, subprocess, sys, time
from concurrent.futures import ThreadPoolExecutor

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
BUILD = os.path.join(ROOT, "build", "regress")
REPORTS = os.path.join(ROOT, "reports")

def flist(name):
    return [l.strip() for l in open(os.path.join(ROOT, name)) if l.strip() and not l.startswith("#")]

# ------------------------------------------------------------------ configurations (-G parameters of tb_noc)
CONFIGS = {
    # crossbar (TOPOLOGY=1): the SilicaFlux baseline
    "xb_m4t4":        dict(TOPOLOGY=1, NM=4, NT=4),
    "xb_m5t6":        dict(TOPOLOGY=1, NM=5, NT=6),
    "xb_m3t5_sparse": dict(TOPOLOGY=1, NM=3, NT=5, EN_SPARSE=1),
    "xb_m1t1":        dict(TOPOLOGY=1, NM=1, NT=1, MAXO0=4),
    "xb_m2t1":        dict(TOPOLOGY=1, NM=2, NT=1),
    "xb_m8t8_id3":    dict(TOPOLOGY=1, NM=8, NT=8, IDW=3, MAXO=8),
    "xb_qos_m5t4":    dict(TOPOLOGY=1, NM=5, NT=4, ARB_MODE=2, STARVE=4),
    "xb_qos_s1_m4t2": dict(TOPOLOGY=1, NM=4, NT=2, ARB_MODE=2, STARVE=1),
    "xb_fixed_m4t4":  dict(TOPOLOGY=1, NM=4, NT=4, ARB_MODE=0),
    "xb_d64":         dict(TOPOLOGY=1, NM=4, NT=4, DW=64),
    "xb_d128_id1":    dict(TOPOLOGY=1, NM=3, NT=3, DW=128, IDW=1, MAXO=2),
    "xb_aw48":        dict(TOPOLOGY=1, NM=4, NT=4, AW=48),
    "xb_maxo1":       dict(TOPOLOGY=1, NM=4, NT=4, MAXO=1, MAXO0=1),
    "xb_noperf":      dict(TOPOLOGY=1, NM=4, NT=4, PERF=0),
    "xb_noalign":     dict(TOPOLOGY=1, NM=4, NT=4, CHECK_ALIGN=0),
    "xb_sfb2tgt":     dict(TOPOLOGY=1, NM=4, NT=4, TGT_SFB2=1),
    "xb_m5t6_byp":    dict(TOPOLOGY=1, NM=5, NT=6, RETIRE_BYPASS=1),
    "xb_maxo1_byp":   dict(TOPOLOGY=1, NM=4, NT=4, MAXO=1, MAXO0=1, RETIRE_BYPASS=1),
    "xb_qos_byp":     dict(TOPOLOGY=1, NM=5, NT=4, ARB_MODE=2, STARVE=4, RETIRE_BYPASS=1),
    "xb_sfb2tgt_m5t6": dict(TOPOLOGY=1, NM=5, NT=6, TGT_SFB2=1, QCAP=2),
    # shared bus (TOPOLOGY=0): comparison topology
    "sb_m4t4":        dict(TOPOLOGY=0, NM=4, NT=4),
    "sb_m5t6":        dict(TOPOLOGY=0, NM=5, NT=6),
    "sb_qos_m5t4":    dict(TOPOLOGY=0, NM=5, NT=4, ARB_MODE=2, STARVE=4),
    "sb_m3t5_sparse": dict(TOPOLOGY=0, NM=3, NT=5, EN_SPARSE=1),
    "sb_m4t4_byp":    dict(TOPOLOGY=0, NM=4, NT=4, RETIRE_BYPASS=1),
    # mesh (TOPOLOGY=2): scale-out option, verified with the same testbench
    "mesh_2x2_m4t4":  dict(TOPOLOGY=2, NM=4, NT=4, MESH_X=2, MESH_Y=2),
    "mesh_3x2_m5t6":  dict(TOPOLOGY=2, NM=5, NT=6, MESH_X=3, MESH_Y=2),
    "mesh_3x3_m8t8":  dict(TOPOLOGY=2, NM=8, NT=8, MESH_X=3, MESH_Y=3, IDW=3, MAXO=8),
    "mesh_4x4_m8t8":  dict(TOPOLOGY=2, NM=8, NT=8, MESH_X=4, MESH_Y=4, MAXO=8),
    "mesh_2x2_fd2":   dict(TOPOLOGY=2, NM=4, NT=4, MESH_X=2, MESH_Y=2, FIFO_DEPTH=2),
    "mesh_3x2_qos":   dict(TOPOLOGY=2, NM=5, NT=6, MESH_X=3, MESH_Y=2, ARB_MODE=2, STARVE=4),
    "mesh_2x2_d64_aw48": dict(TOPOLOGY=2, NM=4, NT=4, MESH_X=2, MESH_Y=2, DW=64, AW=48),
    "mesh_3x2_sparse": dict(TOPOLOGY=2, NM=5, NT=6, MESH_X=3, MESH_Y=2, EN_SPARSE=1),
    "mesh_3x2_byp":   dict(TOPOLOGY=2, NM=5, NT=6, MESH_X=3, MESH_Y=2, RETIRE_BYPASS=1),
}

# ------------------------------------------------------------------ tests (plusargs)
TESTS = {
    "smoke":     "+n=600",
    "random":    "+n=3000 +ooo=1 +lat_min=1 +lat_max=8 +tbp=200 +rbp=200 +p_err=30 +p_bad=20 +errwin=1",
    "routes":    "+amode=5 +n=64",
    "raw_fence": "+amode=3 +ooo=1 +lat_max=16 +tbp=150 +rbp=150 +n=2000",
    "hotspot":   "+amode=1 +rate=1000 +lat_max=2 +n=3000",
    "bursts":    "+amode=2 +burst=256 +rate=1000 +p_fence=0 +n=2048",
    "perm":      "+amode=4 +shift=1 +rate=1000 +n=3000",
    "backpress": "+tbp=500 +rbp=500 +ooo=1 +lat_max=10 +n=2500",
    "resets":    "+resets=6 +ooo=1 +lat_max=8 +tbp=200 +rbp=200 +n=4000",
    "errors":    "+p_err=200 +p_bad=100 +errwin=1 +p_post=400 +n=3000",
    "spurious":  "+spur=80 +ooo=1 +lat_max=6 +rbp=300 +n=3000",
    "spur_bad":  "+spur=80 +spur_badsrc=1 +ooo=1 +lat_max=6 +n=3000",
    "qos_levels": "+amode=1 +rate=1000 +qos_idx=1 +qos_check=1 +lat_max=2 +n=3000",
    "maxload":   "+rate=1000 +ooo=1 +lat_min=4 +lat_max=16 +rbp=600 +tbp=300 +n=4000 +wd=20000",
    "nofence_neg": "+amode=3 +ooo=1 +lat_max=16 +nofence=1 +n=2000",
}
EXPECT_FAIL = {"nofence_neg"}

XB_TESTS = ["smoke", "random", "routes", "raw_fence", "hotspot", "bursts", "perm", "backpress", "resets",
            "errors", "spurious", "maxload", "nofence_neg"]
SB_TESTS = XB_TESTS
MESH_TESTS = ["smoke", "random", "routes", "raw_fence", "hotspot", "bursts", "perm", "backpress", "resets",
              "errors", "spur_bad", "maxload", "nofence_neg"]

def matrix(suite):
    rows = []
    def add(cfgs, tests, seeds):
        for c in cfgs:
            for t in tests:
                for s in seeds:
                    rows.append((c, t, s))
    if suite in ("crossbar", "all"):
        add(["xb_m4t4", "xb_m5t6"], XB_TESTS, [1, 2, 3])
        add(["xb_m3t5_sparse", "xb_m8t8_id3", "xb_qos_m5t4", "xb_d64", "xb_aw48"], XB_TESTS, [1, 2])
        # one outstanding transaction per master cannot reorder: the no-FENCE negative test does not apply
        add(["xb_maxo1"], [t for t in XB_TESTS if t != "nofence_neg"], [1, 2])
        add(["xb_m1t1", "xb_m2t1", "xb_d128_id1", "xb_noperf", "xb_noalign"],
            ["smoke", "random", "routes", "raw_fence", "resets", "errors", "spurious", "maxload"], [1, 2])
        add(["xb_sfb2tgt", "xb_sfb2tgt_m5t6"], ["smoke", "random", "routes", "raw_fence", "hotspot", "bursts", "backpress",
                                               "resets", "errors", "maxload"], [1, 2])
        add(["xb_qos_m5t4"], ["qos_levels"], [1, 2, 3])
        add(["xb_m5t6_byp"], XB_TESTS, [1, 2])
        add(["xb_maxo1_byp"], [t for t in XB_TESTS if t != "nofence_neg"], [1])
        add(["xb_qos_byp"], ["random", "hotspot", "qos_levels", "maxload"], [1])
        add(["xb_qos_s1_m4t2"], ["smoke", "random", "hotspot", "backpress", "maxload"], [1, 2])
        add(["xb_fixed_m4t4"], ["smoke", "random", "routes", "raw_fence", "backpress", "resets", "errors", "maxload"], [1, 2])
    if suite in ("sbus", "all"):
        add(["sb_m4t4", "sb_m5t6"], SB_TESTS, [1, 2])
        add(["sb_qos_m5t4"], ["qos_levels"], [1, 2])
        add(["sb_m4t4_byp"], SB_TESTS, [1])
        add(["sb_qos_m5t4", "sb_m3t5_sparse"], ["smoke", "random", "routes", "raw_fence", "hotspot", "resets", "spurious", "maxload"], [1, 2])
    if suite in ("mesh", "all"):
        add(["mesh_2x2_m4t4", "mesh_3x2_m5t6"], MESH_TESTS, [1, 2, 3])
        add(["mesh_3x3_m8t8", "mesh_4x4_m8t8", "mesh_2x2_fd2", "mesh_3x2_qos", "mesh_2x2_d64_aw48", "mesh_3x2_sparse",
             "mesh_3x2_byp"],
            MESH_TESTS, [1, 2])
    if suite == "quick":
        add(["xb_m4t4"], ["smoke", "random", "raw_fence", "resets", "spurious"], [1])
    return rows

def build(cfg):
    d = os.path.join(BUILD, cfg)
    os.makedirs(d, exist_ok=True)
    g = [f"-G{k}={v}" for k, v in CONFIGS[cfg].items()]
    cmd = (["verilator", "--binary", "--timing", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint", "-Wno-style",
            "-Itb", "--top-module", "tb_noc", "--Mdir", d, "-o", "sim", "-j", "4"] + g +
           flist("files_rtl.f") + flist("files_tb.f"))
    t0 = time.time()
    r = subprocess.run(cmd, cwd=ROOT, capture_output=True, text=True)
    open(os.path.join(d, "build.log"), "w").write(" ".join(cmd) + "\n" + r.stdout + r.stderr)
    return cfg, r.returncode, time.time() - t0, " ".join(cmd)

def run(row):
    cfg, test, seed = row
    exe = os.path.join(BUILD, cfg, "sim")
    args = [f"+seed={seed}", f"+test={cfg}/{test}"] + TESTS[test].split()
    t0 = time.time()
    try:
        r = subprocess.run([exe] + args, cwd=ROOT, capture_output=True, text=True, timeout=1800)
        out, rc = r.stdout + r.stderr, r.returncode
    except subprocess.TimeoutExpired:
        out, rc = "TIMEOUT", -9
    dt = time.time() - t0
    m = re.search(r"^RESULT (\{.*\})$", out, re.M)
    res = json.loads(m.group(1)) if m else None
    passed = rc == 0 and "TEST PASSED" in out
    expect = "FAIL" if test in EXPECT_FAIL else "PASS"
    ok = passed if expect == "PASS" else (not passed and rc != -9)
    first_err = next((l for l in out.splitlines() if "%Error" in l or "Assertion failed" in l), "")
    logd = os.path.join(BUILD, cfg, "logs"); os.makedirs(logd, exist_ok=True)
    open(os.path.join(logd, f"{test}_s{seed}.log"), "w").write(out)
    return dict(config=cfg, params=CONFIGS[cfg], test=test, seed=seed, cmd=" ".join([os.path.relpath(exe, ROOT)] + args),
                rc=rc, expect=expect, ok=ok, result=res, first_error=first_err[:300], secs=round(dt, 2))

def write(name, builds, rows):
    os.makedirs(REPORTS, exist_ok=True)
    ver = subprocess.run(["verilator", "--version"], capture_output=True, text=True).stdout.strip()
    data = dict(tool=ver, builds=builds, runs=rows,
                summary=dict(total=len(rows), ok=sum(r["ok"] for r in rows)))
    json.dump(data, open(os.path.join(REPORTS, f"{name}.json"), "w"), indent=1)
    with open(os.path.join(REPORTS, f"{name}.md"), "w") as f:
        f.write(f"# Regression `{name}`\n\n{ver}.  Generated by `scripts/regress.py`; every row is one simulation "
                f"(command in the JSON).  `expect FAIL` rows are negative tests that must detect a failure.\n\n")
        f.write(f"**{data['summary']['ok']} / {data['summary']['total']} as expected.**\n\n")
        f.write("| config | test | seed | expect | result | txns | cycles | resets | self-checks | spurious contained | "
                "avg lat | max lat | B/cycle | max wait (other grants) |\n|---|---|---|---|---|---|---|---|---|---|---|---|---|---|\n")
        for r in rows:
            x = r["result"] or {}
            st = "OK" if r["ok"] else "**NOT OK**"
            f.write(f"| {r['config']} | {r['test']} | {r['seed']} | {r['expect']} | {st} | {x.get('txns','-')} | "
                    f"{x.get('cycles','-')} | {x.get('resets','-')} | {x.get('self_checks','-')} | {x.get('spurious','-')} | "
                    f"{x.get('avg_lat','-')} | {x.get('max_lat','-')} | {x.get('bytes_per_cycle','-')} | "
                    f"{max(x.get('wait_max',[0]) or [0]) if x else '-'} |\n")
        bad = [r for r in rows if not r["ok"]]
        if bad:
            f.write("\n## Unexpected results\n\n")
            for r in bad:
                f.write(f"* {r['config']}/{r['test']}/seed {r['seed']}: rc={r['rc']} `{r['first_error']}`\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", default="quick")
    ap.add_argument("--jobs", type=int, default=os.cpu_count() or 4)
    ap.add_argument("--name", default=None)
    a = ap.parse_args()
    rows = matrix(a.suite)
    cfgs = sorted({r[0] for r in rows})
    with ThreadPoolExecutor(max_workers=max(1, a.jobs // 2)) as ex:
        builds = list(ex.map(build, cfgs))
    bres = [dict(config=c, rc=rc, secs=round(t, 1)) for c, rc, t, _ in builds]
    failed = {c for c, rc, _, _ in builds if rc != 0}
    for c in failed:
        print(f"BUILD FAILED: {c} (see build/regress/{c}/build.log)")
    rows = [r for r in rows if r[0] not in failed]
    with ThreadPoolExecutor(max_workers=a.jobs) as ex:
        res = list(ex.map(run, rows))
    for r in res:
        if not r["ok"]:
            print(f"NOT OK {r['config']}/{r['test']}/s{r['seed']} rc={r['rc']} {r['first_error']}")
    name = a.name or f"regression_{a.suite}"
    write(name, bres, res)
    ok = sum(r["ok"] for r in res)
    print(f"{name}: {ok}/{len(res)} as expected, {len(failed)} build failures")
    return 0 if ok == len(res) and not failed else 1

if __name__ == "__main__":
    sys.exit(main())
