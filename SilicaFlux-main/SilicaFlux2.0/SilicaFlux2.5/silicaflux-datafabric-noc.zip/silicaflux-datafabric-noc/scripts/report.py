#!/usr/bin/env python3
"""reports/SUMMARY.md: one table of every result, generated from the JSON reports (never typed by hand)."""
import datetime, hashlib, json, os, subprocess

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
R = lambda f: json.load(open(os.path.join(ROOT, "reports", f))) if os.path.exists(os.path.join(ROOT, "reports", f)) else None


def tree_hash(sub):
    h = hashlib.sha256()
    base = os.path.join(ROOT, sub)
    for dp, _, fs in sorted(os.walk(base)):
        for f in sorted(fs):
            if "__pycache__" in dp:
                continue
            p = os.path.join(dp, f)
            h.update(os.path.relpath(p, ROOT).encode())
            h.update(open(p, "rb").read())
    return h.hexdigest()


def ver(cmd):
    try:
        env = dict(os.environ, PATH="/usr/local/bin" + os.pathsep + os.environ.get("PATH", ""))
        return (subprocess.run(cmd, capture_output=True, text=True, env=env).stdout or "n/a").strip().splitlines()[0]
    except Exception:
        return "not installed"


def main():
    rows = []
    lint = R("lint.json")
    if lint:
        rows.append(("Lint: Verilator -Wall (0 warnings), Icarus, Yosys no-latch", "lint.md",
                     f"{sum(c['ok'] for c in lint['configs'])}/{len(lint['configs'])} configurations clean; "
                     f"{sum(c['ok'] for c in lint['illegal'])}/{len(lint['illegal'])} illegal parameter sets refused"))
    for s, name in (("crossbar", "Crossbar regression"), ("sbus", "Shared-bus regression"), ("mesh", "Mesh regression")):
        g = R(f"regression_{s}.json")
        if g:
            neg = sum(1 for r in g["runs"] if r["expect"] == "FAIL")
            cfgs = len({r["config"] for r in g["runs"]})
            txn = sum((r["result"] or {}).get("txns", 0) for r in g["runs"])
            rows.append((f"{name} (tb_noc, {cfgs} configurations)", f"regression_{s}.md",
                         f"{g['summary']['ok']}/{g['summary']['total']} as expected ({neg} negative tests detected); "
                         f"{txn:,} transactions checked"))
    m = R("mutants.json")
    if m:
        rows.append(("Mutation campaign (testbench strength)", "mutants.md", f"{sum(x['killed'] for x in m)}/{len(m)} mutants killed"))
    f = R("formal.json")
    if f:
        jobs = f["jobs"]
        pv = sum(1 for j in jobs if j["expect"] == "PASS" and j["prove"].startswith("PROVED"))
        bo = sum(1 for j in jobs if j["expect"] == "PASS" and not j["prove"].startswith("PROVED"))
        mc = sum(1 for j in jobs if j["expect"] == "FAIL" and j["ok"])
        nm = sum(1 for j in jobs if j["expect"] == "FAIL")
        rows.append(("Formal (ABC bmc3 + yosys-smtbmc/z3 BMC, ABC PDR)", "formal.md",
                     f"{sum(j['ok'] for j in jobs)}/{len(jobs)} jobs as expected: {pv} unbounded proofs, {bo} bounded only, "
                     f"{mc}/{nm} non-vacuity mutants caught"))
    e = R("endpoints.json")
    if e:
        var = sorted({x["variant"] for x in e["runs"]})
        rows.append(("Real endpoints: TensorCore 08 system testbench, unmodified tensor unit + HPC tile", "endpoints.md",
                     f"{sum(x['ok'] for x in e['runs'])}/{len(e['runs'])} runs pass over {len(var)} fabric variants"))
    b = R("bench.json")
    if b:
        rows.append(("Design-exploration benchmark (self-checked RTL runs with traces)", "bench.md",
                     f"{sum(x['passed'] for x in b)}/{len(b)} runs passed"))
    bw = R("bandwidthlab.json")
    if bw:
        rows.append(("BandwidthLab integration (its own importer on NoC traces)", "bandwidthlab.md",
                     f"{sum(x['agree'] for x in bw['rows'])}/{len(bw['rows'])} traces agree with the independent computation"))
    sy = R("synth.json")
    if sy:
        res = sy["results"]
        rows.append(("Synthesis (Yosys generic CMOS, no PDK)", "synth.md",
                     f"{sum(x['ok'] for x in res)}/{len(res)} configurations, "
                     f"{sum(x.get('latches') or 0 for x in res if x['ok'])} latches"))
    with open(os.path.join(ROOT, "reports", "SUMMARY.md"), "w") as fo:
        fo.write("# SilicaFlux DataFabric-NoC -- verification and PPA summary\n\n")
        fo.write(f"Generated {datetime.datetime.now(datetime.timezone.utc):%Y-%m-%d %H:%M} UTC by `scripts/report.py` from the JSON reports in "
                 "this directory.  Source: btcphilosopher/Aureom.AI branch claude/kind-gates-dm75tm @ 8158b9d "
                 "(SilicaFlux-main archives; nothing committed).\n\n## Tools\n\n| tool | version |\n|---|---|\n")
        for t, c in (("verilator", ["verilator", "--version"]), ("iverilog", ["iverilog", "-V"]), ("yosys", ["yosys", "-V"]),
                     ("z3 (smtbmc)", ["z3", "--version"]), ("python", ["python3", "--version"]), ("sby", ["sby", "--help"]),
                     ("openroad", ["openroad", "-version"])):
            fo.write(f"| {t} | {ver(c)} |\n")
        fo.write("\n## Source hashes (sha256 over relative paths + contents)\n\n| tree | sha256 |\n|---|---|\n")
        for t in ("rtl", "tb", "formal", "integration", "scripts", "third_party"):
            fo.write(f"| {t} | `{tree_hash(t)}` |\n")
        fo.write("\n## Results\n\n| check | report | result |\n|---|---|---|\n")
        for n, rep, res in rows:
            fo.write(f"| {n} | [{rep}]({rep}) | {res} |\n")
        fo.write("\nNot run / not available: SymbiYosys (proofs run with yosys-smtbmc and ABC directly), OpenROAD/OpenSTA "
                 "and any PDK Liberty (no timing, frequency, wire delay, placement or power is claimed), FPGA place and "
                 "route, SilicaFlux-V firmware (no RISC-V toolchain; the ControlCore port is driven by the TensorCore 08 "
                 "testbench).\n")
    print(open(os.path.join(ROOT, "reports", "SUMMARY.md")).read())


if __name__ == "__main__":
    main()
