#!/usr/bin/env python3
"""Figures for docs/PERFORMANCE.md, drawn from the JSON reports (static PNG, light surface).

Palette: categorical slots 1-3 of the reference palette (blue / orange / aqua = shared bus / crossbar / mesh),
validated all-pairs (CVD dE 9.2, normal-vision dE 24.0); aqua is below 3:1 on the surface, so every series is
also direct-labelled and every figure has its data table in docs/PERFORMANCE.md / reports/*.md.
Marks: 2 px lines, 8 px markers with a 2 px surface ring, hairline solid grid, one y-axis per panel.
"""
import json, math, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OUT = os.path.join(ROOT, "docs", "img")
SURF, INK, INK2, MUTED, GRID, AXIS = "#fcfcfb", "#0b0b0b", "#52514e", "#898781", "#e1e0d9", "#c3c2b7"
C = {"sbus": "#2a78d6", "xbar": "#eb6834", "mesh": "#1baf7a"}
NAME = {"sbus": "shared bus", "xbar": "crossbar", "mesh": "mesh"}
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "text.color": INK, "axes.labelcolor": INK2,
                     "xtick.color": MUTED, "ytick.color": MUTED, "axes.edgecolor": AXIS, "figure.facecolor": SURF,
                     "axes.facecolor": SURF, "savefig.facecolor": SURF})


def style(ax):
    ax.grid(True, axis="y", color=GRID, linewidth=1, linestyle="-")
    ax.set_axisbelow(True)
    for s in ("top", "right"):
        ax.spines[s].set_visible(False)
    for s in ("left", "bottom"):
        ax.spines[s].set_color(AXIS)
    ax.tick_params(length=0)


def line(ax, x, y, key, label_end=True, dy=0):
    ax.plot(x, y, color=C[key], linewidth=2, solid_capstyle="round", solid_joinstyle="round", label=NAME[key],
            marker="o", markersize=8, markerfacecolor=C[key], markeredgecolor=SURF, markeredgewidth=2, zorder=3)
    if label_end:
        ax.annotate(NAME[key], (x[-1], y[-1]), xytext=(8, dy), textcoords="offset points", va="center",
                    color=INK2, fontsize=9)


def load_curves(bench):
    rows = [r for r in bench if r["kind"] == "load" and r["config"].startswith("B_") and r["passed"]]
    fig, axs = plt.subplots(1, 2, figsize=(10.5, 3.9), dpi=150)
    for key in ("sbus", "xbar", "mesh"):
        rr = sorted([r for r in rows if r["config"] == f"B_{key}"], key=lambda r: r["meta"]["rate"])
        if not rr:
            continue
        x = [r["meta"]["rate"] / 10 for r in rr]
        line(axs[0], x, [r["m"]["bw"] for r in rr], key)
        line(axs[1], x, [r["m"]["access_lat"]["mean"] for r in rr], key)
    axs[0].set_title("Useful bandwidth (bytes per cycle)", loc="left", fontsize=11, color=INK)
    axs[1].set_title("Mean access latency (cycles, presentation to response)", loc="left", fontsize=11, color=INK)
    for ax in axs:
        style(ax)
        ax.set_xlabel("offered load per master (% of cycles with a new request)")
        ax.set_xlim(0, 118)
        ax.set_ylim(bottom=0)
    axs[0].legend(frameon=False, loc="upper left", fontsize=9, labelcolor=INK2)
    fig.suptitle("4 masters x 6 targets, uniform random traffic, 1-cycle targets (RTL simulation, reports/bench.md)",
                 x=0.01, ha="left", fontsize=9, color=MUTED)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "load_curves.png"))
    plt.close(fig)


def synth_scaling(synth):
    res = {r["config"]: r for r in synth["results"] if r["ok"]}
    pts = {"sbus": [(2, "sbus_m2t2"), (4, "sbus_m4t4"), (8, "sbus_m8t8"), (16, "sbus_m16t16")],
           "xbar": [(2, "xbar_m2t2"), (4, "xbar_m4t4"), (8, "xbar_m8t8"), (16, "xbar_m16t16")],
           "mesh": [(4, "mesh2x2_m4t4"), (8, "mesh3x3_m8t8"), (16, "mesh4x4_m16t16")]}
    fig, ax = plt.subplots(figsize=(7.2, 4.0), dpi=150)
    for key, pp in pts.items():
        xy = [(n, res[c]["nand2_eq"]) for n, c in pp if c in res]
        if xy:
            line(ax, [p[0] for p in xy], [p[1] for p in xy], key, dy={"sbus": -4, "xbar": 4, "mesh": 0}[key])
    ax.set_yscale("log")
    ax.set_xscale("log", base=2)
    ax.set_xticks([2, 4, 8, 16])
    ax.set_xticklabels(["2x2", "4x4", "8x8", "16x16"])
    ax.set_yticks([1000, 3000, 10000, 30000, 100000, 300000])
    ax.set_yticklabels(["1K", "3K", "10K", "30K", "100K", "300K"])
    ax.set_xlim(1.7, 26)
    style(ax)
    ax.set_xlabel("masters x targets")
    ax.set_title("Logic area, NAND2-equivalents (Yosys generic CMOS, no PDK; log scale)", loc="left", fontsize=11)
    ax.legend(frameon=False, loc="upper left", fontsize=9, labelcolor=INK2)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "synth_scaling.png"))
    plt.close(fig)


def endpoints(ep):
    runs = [r for r in ep["runs"] if r.get("cycles")]
    ref = {(r["seed"], r["lat"], r["cpu_rate"]): r["cycles"] for r in runs if r["variant"] == "datafabric_xbar"}
    order = ["noc_xbar_sfb2eq", "noc_xbar_sfb2eq_nobyp", "noc_xbar_m1", "noc_xbar_m4", "noc_xbar_m4_byp", "noc_xbar_qos_m4",
             "noc_sbus_m1", "noc_sbus_m4", "noc_mesh_m1", "noc_mesh_m4"]
    vals = []
    for v in order:
        rr = [r for r in runs if r["variant"] == v and (r["seed"], r["lat"], r["cpu_rate"]) in ref]
        if rr:
            g = math.exp(sum(math.log(r["cycles"] / ref[(r["seed"], r["lat"], r["cpu_rate"])]) for r in rr) / len(rr))
            vals.append((v.replace("noc_", ""), g))
    if not vals:
        return
    fig, ax = plt.subplots(figsize=(8.0, 0.42 * len(vals) + 1.8), dpi=150)
    h = 0.5
    xmax = max(v for _, v in vals) * 1.18
    for i, (n, v) in enumerate(reversed(vals)):
        r = min(0.035 * xmax, v / 2)
        ax.add_patch(FancyBboxPatch((0, i - h / 2), v, h, boxstyle=f"round,pad=0,rounding_size={r}",
                                    mutation_aspect=h / (2 * r) * 0.5 if r else 1, color=C["xbar"], linewidth=0))
        ax.add_patch(Rectangle((0, i - h / 2), max(v - r, 0), h, color=C["xbar"], linewidth=0))
        ax.annotate(f"{v:.2f}x", (v, i), xytext=(6, 0), textcoords="offset points", va="center", color=INK, fontsize=9)
    ax.axvline(1.0, color=INK2, linewidth=1)
    ax.annotate("DataFabric sfb_crossbar = 1.00", (1.0, len(vals) - 0.35), xytext=(4, 0), textcoords="offset points",
                color=INK2, fontsize=8)
    ax.set_yticks(range(len(vals)))
    ax.set_yticklabels([n for n, _ in reversed(vals)], color=INK2)
    ax.set_xlim(0, xmax)
    ax.set_ylim(-0.6, len(vals) - 0.2)
    style(ax)
    ax.grid(True, axis="x", color=GRID, linewidth=1)
    ax.grid(False, axis="y")
    ax.set_xlabel("whole-program cycles relative to DataFabric's crossbar\n(geometric mean of 9 programs; lower is faster)")
    ax.set_title("Real SilicaFlux endpoints on each fabric variant\n(unmodified tensor unit, HPC tile and TensorCore 08 testbench)",
                 loc="left", fontsize=10)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT, "endpoints.png"))
    plt.close(fig)


def main():
    os.makedirs(OUT, exist_ok=True)
    rd = lambda f: json.load(open(os.path.join(ROOT, "reports", f)))
    load_curves(rd("bench.json"))
    synth_scaling(rd("synth.json"))
    endpoints(rd("endpoints.json"))
    print("figures:", sorted(os.listdir(OUT)))


if __name__ == "__main__":
    main()
