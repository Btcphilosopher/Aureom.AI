# SilicaFlux DataFabric-NoC — Project 22

**Primary RTL:** `rtl/noc/silicaflux_noc.sv` · Aureom.AI / SilicaFlux-HPC

A synthesizable, configurable on-chip fabric for SilicaFlux: one master front end and one transaction
protocol (**SFB3**, the planned extension of DataFabric's SFB2), three verified switching cores selected by a
parameter — **shared bus, crossbar (the SilicaFlux baseline), 2-D mesh** — QoS arbitration with a proved
starvation bound, explicit ordering / FENCE / posted-write semantics, performance counters, and bridges that
carry every existing SFB2 endpoint unmodified.

> **Not committed to GitHub** — delivered as an archive. Every number in this file comes from `reports/`
> (final run on frozen sources, `reports/SUMMARY.md` has the tool versions and source hashes). RTL
> simulation, formal proofs and technology-independent synthesis only: no PDK, so **no frequency, wire delay,
> area in µm² or power is claimed**, and nothing here is tape-out ready (docs/ISSUES.md).

## Definition of done — met in RTL simulation

*All supported endpoints exchange correct transactions under contention and back-pressure, with reproducible
latency and throughput measurements from actual simulation.*

* **Real endpoints:** the unmodified SilicaFlux tensor unit (TensorCore 08), HPC FP32 vector tile (whose DMA
  adapter is the DataFabric DMA engine), a ControlCore host port and the shared SRAM run on every fabric
  variant; TensorCore 08's own testbench and checker (every completion record, the whole final memory image,
  protocol checkers) pass **99/99** runs over 11 variants.
* **Contention and back-pressure:** 782 self-checking regression runs on 34 configurations of the three
  topologies — hot spot, saturation, 50 % random back-pressure on every port, out-of-order targets, resets
  mid-traffic, 211,001 injected faulty responses contained — 8.1 million transactions checked by an independent
  scoreboard.
* **Reproducible measurements:** 133 benchmark runs (each also fully checked) with per-transaction traces;
  BandwidthLab's own importer reproduces every metric from them.

## Results (final run)

| Check | Result | Report |
|---|---|---|
| Lint: Verilator `-Wall`, Icarus (elaborate + run checks), Yosys (no latch) | **13/13** configurations, 0 warnings; **10/10** illegal parameter sets refused | [lint](reports/lint.md) |
| Crossbar regression | **423/423** as expected (incl. negative tests) | [regression_crossbar](reports/regression_crossbar.md) |
| Shared-bus regression | **99/99** | [regression_sbus](reports/regression_sbus.md) |
| Mesh regression | **260/260** | [regression_mesh](reports/regression_mesh.md) |
| Mutation campaign (deliberate RTL bugs) | **35/35** killed | [mutants](reports/mutants.md) |
| Formal (ABC bmc3 + smtbmc/z3 BMC, ABC PDR) | **38/38**: **21 unbounded proofs**, 0 bounded-only, 17/17 non-vacuity mutants caught | [formal](reports/formal.md) |
| Real endpoints (TensorCore 08 system testbench, unmodified) | **99/99** runs, 11 fabric variants | [endpoints](reports/endpoints.md) |
| Design-exploration benchmark | **133/133** runs passed their checks | [bench](reports/bench.md) |
| BandwidthLab integration | **10/10** traces: BandwidthLab = independent computation | [bandwidthlab](reports/bandwidthlab.md) |
| Synthesis (Yosys generic CMOS, no PDK) | **39/39** configurations, 0 latches | [synth](reports/synth.md) |

Headline measurements:

| | Value |
|---|---|
| Real system, NoC crossbar with SFB2's limits vs DataFabric's crossbar | **1.000×** cycles (identical on 3 of 9 programs, ≤ 0.4 % otherwise) |
| Real system, NoC crossbar, tensor port 4 outstanding (recommended) | **0.235–0.571×** cycles (up to 4.25× faster) |
| Bandwidth, 4×6, uniform, full load: shared bus / crossbar / mesh | 3.42 / **9.12** / 2.88 B/cycle |
| Permutation traffic, 8×8: transfers per cycle | 1.00 / **8.00** / 2.46 |
| Latency added at zero load: crossbar / mesh | 0 cycles / round trip 6 + 2·hops |
| ControlCore access latency under a saturated target, crossbar RR → QoS | 3.1 → 2.2 cycles mean, bulk bandwidth unchanged |
| Area (NAND2-eq, 4×6, no counters): DataFabric xbar / NoC bus / NoC xbar / NoC 3×2 mesh | 6,388 / 3,462 / **8,233** / 45,502 |

**Decision:** the crossbar is the SilicaFlux baseline; the shared bus is kept for comparison (and low-traffic
domains); the mesh is a verified scale-out option not justified at this endpoint count
([ARCHITECTURE](docs/ARCHITECTURE.md) §2, [PERFORMANCE](docs/PERFORMANCE.md)).

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit; reuse; measured reason before replacing anything | [docs/AUDIT.md](docs/AUDIT.md): DataFabric's arbiter and decoder reused unmodified; SFB2 extended, not replaced; DF-07 / TensorCore 08 / BandwidthLab measurements + this project's endpoint comparison |
| 2 | Shared bus vs crossbar vs NoC; smallest sufficient; documented topology | all three built and measured; [ARCHITECTURE](docs/ARCHITECTURE.md) §2 |
| 3 | Transaction interface: source, destination/address, opcode, data, byte enables, ID, read/write status, response status, ready/valid; no truncation | [PROTOCOL](docs/PROTOCOL.md) §1, `rtl/noc/sfn_pkg.sv`; widths from parameters (AW 8–64, IDW 1–8, DW 32–256), verified at AW 48 / IDW 3 |
| 4 | Routing: XY, ports, links, hop count, flit format, packet boundaries, buffer depth, restrictions | [ROUTING](docs/ROUTING.md), `sfn_router`, `sfn_ni`, `sfn_mesh` |
| 5 | Flow control; no overflow, duplication, loss, misrouting, HOL deadlock; explicit outstanding limits | credits (proved), O1–O5 ([PROTOCOL](docs/PROTOCOL.md) §4), conservation scoreboard, orphan containment (proved) |
| 6 | Round robin; optional QoS classes (ControlCore, vector, tensor, DMA, events); no indefinite starvation; priority ≠ bandwidth | [QOS](docs/QOS.md); `sfn_qos_arbiter` bound STARVE+N−1 proved |
| 7 | Ordering, FENCE, posted vs acknowledged writes, out-of-order rules, no implicit coherence | [PROTOCOL](docs/PROTOCOL.md) §3, §5; `raw_fence` / `nofence_neg` tests |
| 8 | Deadlock analysis, request/response separation, cyclic back-pressure and maximum-load tests | [DEADLOCK](docs/DEADLOCK.md); separate request / response networks; `maxload`, `hotspot`, `perm` |
| 9 | Accepted / delivered bytes, link utilisation, arbitration stalls, occupancy, latency, back-pressure; BandwidthLab | `sfn_perf` (checked against the testbench in every run); [PERFORMANCE](docs/PERFORMANCE.md) §1; [bandwidthlab](reports/bandwidthlab.md) |
| 10 | Every route, simultaneous R/W, conflicts, bursts, random back-pressure, reset while busy, errors, fairness, ordering, conservation, deadlock / liveness; formal FIFO and arbitration | [VERIFICATION](docs/VERIFICATION.md) §3 (test map), §4 (formal) |
| 11 | Benchmark shared bus / crossbar / mesh: bandwidth, latency, RTL complexity, synthesis; no invented frequency | [PERFORMANCE](docs/PERFORMANCE.md), [synth](reports/synth.md) |
| 12 | Deliverables | below |

## Deliverables

| Deliverable | Files |
|---|---|
| `silicaflux_noc.sv` | `rtl/noc/silicaflux_noc.sv` |
| Router / crossbar modules | `rtl/noc/sfn_xbar.sv`, `sfn_sbus.sv`, `sfn_mesh.sv`, `sfn_router.sv`, `sfn_ni.sv`, `sfn_mst_port.sv`, `sfn_fifo.sv`, `sfn_onehot_mux.sv` |
| Shared protocol package | `rtl/noc/sfn_pkg.sv` |
| Arbitration units | `rtl/noc/sfn_arbiter.sv`, `sfn_qos_arbiter.sv` (+ DataFabric `sfb_arbiter`, vendored unmodified) |
| Bridges, counters | `rtl/noc/sfn_sfb2_mst_bridge.sv`, `sfn_sfb2_tgt_bridge.sv`, `sfn_perf.sv` |
| Testbench and scoreboards | `tb/tb_noc.sv` (scoreboard, reference decoder, fairness / liveness / counter checks), `tb/sfn_protocol_checker.sv`, `tb/sfn_tb_target.sv`, `tb/sfn_tb_sfb2_mem.sv` |
| Traffic generator | `tb/sfn_tb_master.sv` |
| Formal | `formal/fv_*.sv`, `formal/run_formal.py` |
| Real-endpoint integration | `integration/sfx_hpc_tensor_system_noc.sv`, `integration/run_endpoints.py` |
| Performance reports | `reports/bench.md`, `reports/endpoints.md`, `reports/synth.md`, `reports/bandwidthlab.md`, `reports/traces/*.bwlab.csv`, `docs/img/*.png` |
| Architecture documentation | `docs/ARCHITECTURE.md`, `PROTOCOL.md`, `ROUTING.md`, `DEADLOCK.md`, `QOS.md`, `VERIFICATION.md`, `PERFORMANCE.md`, `AUDIT.md`, `ISSUES.md` |
| Reused sources | `third_party/` (byte-identical subsets with `SHA256SUMS`; see `third_party/PROVENANCE.md`) |

## Quick start

```bash
make lint
```

```bash
make quick
```

```bash
make test
```

```bash
make formal
```

```bash
make endpoints
```

```bash
make bench
```

```bash
make all
```

`make help` lists every target. Tools: Verilator 5.020, Icarus 12, Yosys 0.33 (with yosys-smtbmc and
yosys-abc), z3 from PyPI (`pip install z3-solver`; the Ubuntu z3 4.8.12 hangs under yosys-smtbmc 0.33),
Python 3 with numpy, pandas and matplotlib. `make all` takes about 45 minutes on 4 cores.

Single configuration by hand (crossbar, 5 masters × 6 targets, out-of-order targets with back-pressure):

```bash
verilator --binary --timing --timescale 1ns/1ps -Wno-fatal -Wno-lint -Wno-style -Itb -f files_rtl.f -f files_tb.f --top-module tb_noc -GTOPOLOGY=1 -GNM=5 -GNT=6 --Mdir build/one -o sim
```

```bash
build/one/sim +seed=3 +n=3000 +ooo=1 +lat_max=8 +tbp=200 +rbp=200 +p_err=30 +errwin=1
```

## Layout

```
rtl/noc/           the fabric (SystemVerilog, synthesizable; one package, 15 modules)
tb/                self-checking testbench, traffic generator, target models, protocol checker
formal/            formal harnesses and runner
integration/       drop-in NoC edition of TensorCore 08's system + real-endpoint runner
scripts/           regression, mutation, lint, synthesis, benchmark, plots, summary, run_all.sh
python/            BandwidthLab integration
docs/              architecture documentation (+ img/ figures)
reports/           every result quoted anywhere (JSON + Markdown; SUMMARY.md)
third_party/       DataFabric interconnect subset, TensorCore 08 subset, BandwidthLab trace importer
```
