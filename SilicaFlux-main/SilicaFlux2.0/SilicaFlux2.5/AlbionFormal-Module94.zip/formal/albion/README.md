# AlbionFormal -- SilicaFlux formal hardware verification (Module 94)

A reproducible, claim-by-claim formal verification suite for the SilicaFlux RTL (SFB2 DataFabric, SRAM library + protection path, DMA, Citadel domain enforcement).
Every row of the **proof ledger** (`reports/ledger.md`, also `.csv` / `.json`) is one named property with: RTL module, property, assumptions, solver/engine, proof depth, result and the exact command that reproduces it.
The ledger is *generated* from the stored results; nothing in it is typed in.

**Read these first:** `reports/ledger.md` (the evidence) - `docs/LIMITATIONS.md` (what is *not* established, findings, unresolved items) - `docs/METHODOLOGY.md` (what each result class means).

## What was verified (summary of the delivered ledger)

| area | assertions | INDUCTIVE | CONDITIONAL | STRUCTURAL | BOUNDED | FAILED (expected) | n/a | covers (reached / unreachable / unreached) |
|---|---|---|---|---|---|---|---|---|
| DataFabric | 210 | 69 | 103 | 12 | 0 | 11 | 15 | 109 / 15 / 0 |
| SRAM | 199 | 52 | 137 | 4 | 0 | 3 | 3 | 161 / 10 / 0 |
| DMA | 380 | 35 | 175 | 10 | 154 | 0 | 6 | 184 / 10 / 1 |
| Security | 170 | 84 | 79 | 2 | 0 | 3 | 2 | 88 / 1 / 0 |
| **total** | **959** | **240** | **494** | **28** | **154** | **17** | **26** | **542 / 36 / 1** |

* **INDUCTIVE** = unbounded proof (all reachable states, all input sequences, for the job's parameter point) with only clock/reset assumed. **CONDITIONAL** = unbounded proof *under the environment assumptions listed in the row* (`docs/ASSUMPTIONS.md`).
  **STRUCTURAL** = constant after elaboration (sound, little proof weight). **BOUNDED** = *not a proof*: no counterexample to the BMC depth in the row. **FAILED** = counterexample exists: all 17 are expected and explained (`docs/LIMITATIONS.md` section 3).
  Self-test rows (30) are listed separately in the ledger.
* **Not claimed anywhere:** unbounded liveness (no fairness model exists or is assumed), production parameter widths, SoC-level composition, anything below RTL (timing, CDC, X). See `docs/LIMITATIONS.md`.
* **Validation of the proof system:** self-test with known verdicts, vacuity covers in every job, and a controlled-bug campaign: **142 mutants, 139 killed**, 3 survivors with written (not machine-checked) equivalence arguments.
* **Findings:** DF-F1/DF-F1b (crossbar not reset-quiet; independently reproduces the Module-93 simulation finding), FAB-F2, SRAM-F1, SRAM-F2, SEC-F1, SEC-F2 -- all reproduced as counterexamples with waveforms in `reports/counterexamples/`. DF-F1, FAB-F2, SRAM-F1, SEC-F1 and SEC-F2 reproduce behaviour that was already reported or is documented in the vendored specs; SRAM-F2 (gate not reset-quiet) and DF-F1b (slave-side view of DF-F1) are, as far as the vendored documents show, not documented. No defect was found in the DMA.

## Where the brief and the RTL differ (read `docs/SPEC_MAPPING.md`)

There is **no module named DomainGuard** (mapped to Citadel gate / permission checker / domain table), **no address translation / TLB / IOMMU** (so "stale translation" is mapped to stale-verdict-after-REVOKE and shown as a counterexample),
**no SFB2 transaction IDs**, **no protection feature inside `sram_sp`** (protection is the `cc_sfb_gate` + `cc_secmon` path in front of it), and **no native bursts / page-boundary rule in the DMA**. Each mapping is stated, not hidden.

## Quick start

```bash
sudo apt-get install -y yosys z3 python3        # yosys 0.33 (yosys-abc, yosys-smtbmc, yosys-witness), z3
make doctor                                      # tools present?
make vendor-check                                # RTL under test still matches its SHA-256 pins
make selftest                                    # proof system against designs with known verdicts
make proofs JOBS=2                               # every assertion and cover (reuses cached results when sources are unchanged)
make mutate JOBS=2                               # controlled-bug campaign (minutes)
make ledger                                      # rebuild reports/ledger.md|csv|json
sh ci/run_ci.sh quick                            # CI smoke: self-test + forced re-proof of one job per area + ledger consistency
sh ci/run_ci.sh full                             # forced re-proof of everything + mutation (hours)
```

Reproduce one row exactly (the command is in the ledger):

```bash
python3 -I tools/albion_formal.py run --job FAB-XBAR-2x2-RR --prop a_no_duplication --force
```

A counterexample leaves `reports/counterexamples/<job>/<property>/{report.md,trace.vcd,cex.*}`; the waveform opens in GTKWave and has been re-simulated by an independent solver-free replay.

## Layout

| path | content |
|---|---|
| `harness/` | formal harnesses (SystemVerilog, immediate assertions, `ALB_ASSERT/COVER/ASSUME` macros): `fv_sfb_*` (DataFabric), `fv_sram_*`/`fv_prot_*` (SRAM + protection), `fv_dma_*`, `fv_cit_*`/`fv_sec_*` (Citadel), `selftest_counter.sv` |
| `lib/albion_sva.svh` | assertion/cover/assume macros (one property per run, selected by `ALB_SEL`) |
| `env/` | clock/reset environments (`albion_env_reset`), SFB2 protocol monitors (`albion_sfb_mon`), reference models (`albion_dma_ref`) |
| `proofs/*.json` | parameterised proof configurations (jobs): RTL files, parameter point, assumptions, depths/budgets, **recorded expectations with reasons**; `claims.json` = claims of record |
| `mutants/*.json` | controlled bugs (exact-text edits applied to copies of the RTL) |
| `rtl_under_test/` | byte-for-byte copy of the RTL, docs and headers under test, pinned by SHA-256 (`MANIFEST.json`; `tools/vendor_rtl.py --check`) |
| `tools/albion_formal.py` | runner (Yosys -> ABC `bmc3`/`pdr`; witness replay; ledger; `.sby` generator) -- `tools/package.py`, `tools/area_tables.py`, `tools/vendor_rtl.py` |
| `reports/` | `ledger.*`, per-property results (`results/`), counterexamples, mutation results -- **the evidence** |
| `sby/` | generated SymbiYosys files (**never executed**: SymbiYosys is not installed in the build environment) |
| `ci/` | `run_ci.sh`, GitHub Actions workflow template (not installed anywhere) |
| `docs/` | `METHODOLOGY`, `ASSUMPTIONS`, `LIMITATIONS`, `SPEC_MAPPING`, `HARNESS_GUIDE`, `PROPERTY_CATALOGUE` (generated), `areas/{DataFabric,SRAM,DMA,Security}.md` |

## Tool flow and honesty notes

Yosys 0.33 (open source, no Verific, hence immediate assertions only) -> AIGER -> ABC `bmc3` (bounded) and `pdr` (unbounded IC3); z3 is used only where noted. SymbiYosys would drive the same engines; it was unavailable, so the runner drives them directly (`.sby` files are generated for CI use but unrun).
Each job is **one small parameter point**; a proof at AW=6 is not a theorem at AW=32. PDR budgets are wall-clock, so a borderline property can move between BOUNDED and PROVED (the two known cases carry the expectation `BOUNDED|PROVED`).
Nothing in this directory was committed to or pushed to any git repository.
