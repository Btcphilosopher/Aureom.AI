# Assumptions register

A proof that lists an assumption is **CONDITIONAL on it**. Every `ALB_ASSUME` in a harness appears (machine-extracted)
in `PROPERTY_CATALOGUE.md` under its harness, and the ids a job relies on are in the ledger column *assumptions*.
This file holds the base assumptions and the DataFabric register; the DMA, SRAM and Security registers (which also say who
discharges each assumption) are in `docs/areas/DMA.md`, `SRAM.md` and `Security.md`.

## Base assumptions (every job)

| id | assumption | meaning / limitation |
|---|---|---|
| ENV-CLK | one clock domain; one formal step = one clock cycle | clock gating, multiple clocks, CDC/RDC, glitches, metastability are **not modelled** |
| ENV-RST-FIRST | reset asserted in step 0 and never again | strongest environment; used where a mid-operation reset is irrelevant |
| ENV-RST-ANY | reset asserted in step 0, may re-assert at any later step for any duration | reset in the middle of a transfer is covered. Asynchronous assertion is modelled by sampling (Yosys `async2sync`): a reset low in step t forces reset state onto the outputs of step t and registers of step t+1 |
| ENV-RST-NONE | no reset constraint; state in step 0 arbitrary | only for state-free checkers and invariants that must hold from every state |
| (two-state) | no X: undriven nets and un-reset storage are arbitrary values (`setundef -anyseq`) | sound for safety (superset of behaviours); says nothing about X-propagation in simulation |

All components in a harness share one reset (R11 / A-RST).

## DataFabric register

| id | assumption | source | who discharges it |
|---|---|---|---|
| ENV-ARB-1/2/3 | (arbiter jobs) `accept` and `stall` imply a grant is presented; they are mutually exclusive | `accept = s_req_valid && s_req_ready`, `stall = s_req_valid && !s_req_ready`, `s_req_valid` requires `grant_valid` | structural in `sfb_crossbar` (the crossbar derives both signals that way); the crossbar jobs prove the composition without these assumptions |
| ENV-SFB-R2 | masters keep a presented request and its payload unchanged until accepted | PROTOCOL R2 | each master. Asserted on the DUT-driven request channel in the DMA area (`DMA-ENG-*`), not for other SoC masters (CPU instruction port is documented to withdraw: job `FAB-XBAR-2x2-RR-NOR2` shows what changes) |
| ENV-SFB-R4 | a slave keeps a presented response valid and unchanged until accepted | PROTOCOL R4 | each slave. Asserted for `sfb_error_slave`, `sfb_reg_slice`, `sfb_sram_slave`; **not** proved for other SoC slaves (CL-ENV-1) |
| ENV-SFB-R5 | a slave responds only to an earlier-accepted request, never in the acceptance cycle | PROTOCOL R5 | as R4. Job `FAB-XBAR-2x2-RR-NOR5` removes it for the response-solicited property and shows the router's `busy` qualifier covers a violating slave |
| ENV-SFB-R8 | a slave error response has `rsp_rdata == 0` | PROTOCOL R8 | as R4 |
| (free) | masters' `rsp_ready`, slaves' `req_ready`, response data/error are otherwise unconstrained | | arbitrary back-pressure is the worst case |

**Not assumed anywhere:** any response-latency bound, any fairness, any slave acceptance guarantee (so no liveness result can
be derived from this suite), any property of the memory map beyond the one parameter point of the job.

## Assumption hygiene
* An assumption is only used on a port the environment drives; the same rule is an assertion on ports the DUT drives.
* Each job has covers that must be REACHED under its full assumption set (vacuity guard) and `SELF-VACUOUS` shows the guard
  detects an over-constrained environment.
* Assumptions about modules outside the verified set are listed in `proofs/claims.json` (CL-ENV-1) as **unproven**.
