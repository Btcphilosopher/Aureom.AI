# AlbionFormal harness guide (conventions every harness follows)

A *harness* is a Verilog/SystemVerilog top module that instantiates the real RTL, constrains its inputs with
assumptions, and states properties. The runner (`tools/albion_formal.py`) enumerates, builds and proves every property
from the harness source; a *job* (`proofs/*.json`) binds a harness to a parameter point.

## C1  One property = one run
Properties are written with the macros of `lib/albion_sva.svh`:

```systemverilog
`include "albion_sva.svh"
module fv_x #(parameter ALB_SEL = 0, ...) (...);       // ALB_SEL is mandatory
  always @(*) begin
    `ALB_ASSUME(e_name, "ENV-XYZ-1 text", cond)            // always active; listed in the job's "assumptions"
    `ALB_ASSERT(10, a_name, "[spec clause] text", cond)    // unique numeric id + unique label, in the harness top ONLY
    `ALB_COVER (90, c_name, "text", cond)                  // reachability / vacuity check
  end
endmodule
```
* The runner elaborates the harness with `ALB_SEL=<id>`; all other assertions are disabled. So **every ledger row is one
  property**, and an unproved property can never hide behind a proved sibling.
* Assertions live in the harness top file only (the scanner reads `files` that are not `rtl:`); shared modules in
  `env/` expose *wires* (`..._ok`) and the harness decides whether to assume or assert them.
* A property inside `if (PARAM == ..)` that is absent for a configuration is reported **N/A**; one whose condition is
  constant after elaboration is **TRIVIAL** (reviewed by hand) -- never a silent PROVED.
* Only yosys-0.33 compatible syntax: immediate assertions, `(* anyconst *)`, `$onehot0`, `$countones`, no `|->`, no
  sequences, no hierarchical references into the DUT (observe through ports or through a *shim module*, see C7).
  Avoid `%` and wide multiplications in monitors (z3 blows up); use compare/subtract.

## C2  Time and reset
* One clock, one step = one cycle (`async2sync` model). Clock gating, multi-clock behaviour and CDC are **not** modelled.
* The RTL resets asynchronously (`negedge rst_n`). **Harness history registers must also use
  `always @(posedge clk or negedge rst_n)`** so the reset state is visible in the same step as in the DUT; a synchronous
  reset in the harness disagrees with the DUT in step 0 (this bit the first harness written for this suite).
* Instantiate `albion_env_reset #(.MODE(m))`: 0 = reset only in step 0, 1 = reset in step 0 and at any later step,
  2 = no reset constraint (state arbitrary in step 0: use for combinational checkers / from-any-state invariants).
  List `ENV-RST-FIRST | ENV-RST-ANY | ENV-RST-NONE` in `assumptions`; these three plus `ENV-CLK` are the *base* assumptions.

## C3  Assumption discipline (what makes a proof CONDITIONAL)
* Every `ALB_ASSUME` has a name `e_*` and a text that starts with its register id (`ENV-<AREA>-<n>`), the id is added to
  the job's `assumptions` array, and documented (source of the rule, who must discharge it) in the area's
  `docs/areas/<AREA>.md` assumptions table.
* An assumption that restates a *protocol rule* (e.g. SFB2 R2) is acceptable only for ports driven by the environment.
  The same rule must be an **assertion** wherever the DUT drives that port (assume-guarantee symmetry).
* Never assume away the behaviour under test. Every job needs `c_*` covers showing that the interesting behaviour is
  reachable *under the assumptions*.
* Liveness is never assumed or claimed. Bounded progress is stated as a safety property with an explicit latency
  assumption (`albion_sfb_lat_mon`, `ENV-SLV-LAT`), and the result is reported with that assumption attached.

## C4  Jobs (`proofs/<area>.json`)
```json
{"jobs": [{
  "id": "DMA-ENG-A", "area": "DMA", "rtl_module": "dma_transfer_engine", "top": "fv_dma_engine",
  "files": ["env/albion_env_reset.sv", "rtl:datafabric/rtl/dma/dma_validate.sv", "harness/fv_dma_engine.sv"],
  "includes": ["rtl:datafabric/rtl/dma"],                 // extra -I dirs (dirs of rtl: files are added automatically)
  "params": {"DW": 16, "MAX_LEN_LOG2": 6},                // chparam on the harness top
  "assumptions": ["ENV-RST-ANY", "ENV-SFB-R2", "..."],   // every ALB_ASSUME id + the reset mode
  "depth": 30, "pdr_timeout": 180, "ind_k": 0, "cover_depth": 40, "bmc_engine": "bmc3",
  "covers_unreachable": ["c_that_must_never_happen"],     // covers expected UNREACHABLE (default: REACHED)
  "expect": {"default": "PROVED", "a_slow_one": "BOUNDED", "a_known": "FAIL:KD-1", "a_cfg_specific": "N/A"},
  "expect_notes": {"a_slow_one": "why it is only bounded (PDR timeout at 180 s on 32-bit counters)"}
}]}
```
* `expect` is the regression gate: a different outcome is `UNEXPECTED` and fails CI. **Never edit an expectation to
  hide a failure.** A property that fails on the unmodified RTL is either a harness bug (fix the harness) or a finding:
  record `FAIL:<finding-id>` plus a note, keep the counterexample under `reports/counterexamples/`, and describe it in
  the area document.
* Parameterised proofs: add one job per parameter point (`DW`, `DEPTH`, `N`, `NM x NS`, `FIFO_DEPTH`, `BURST` ...).
  Logic that is width/count-generic is proved at small points and **stated as such** -- a proof at `AW=8` is not a proof at
  `AW=64`; say so in `expect_notes`/area docs.
* `PDR` is the unbounded engine; if it times out the result is honestly `BOUNDED`. If bounded, record the depth
  reached and why (hidden 32-bit state, no inductive invariant) -- do not raise timeouts indefinitely.

## C5  Result classes (see `tools/albion_formal.py` header)
INDUCTIVE (unbounded, only reset/clock assumed) - CONDITIONAL (unbounded under listed assumptions) - BOUNDED - COVER
(REACHED / UNREACHABLE / UNREACHED) - FAILED - TIMEOUT - UNPROVEN (claims of record, `proofs/claims.json`).

## C6  Mutation (`mutants/<area>.json`)
```json
{"mutants": [{"id": "MUT-DMA-01", "area": "DMA", "rtl": "datafabric/rtl/dma/dma_transfer_engine.sv",
  "find": "exact text occurring exactly once", "replace": "buggy text",
  "jobs": ["DMA-ENG-A"], "expect_fail": ["a_prop1", "a_prop2"],
  "description": "what real bug this models", "depth": 20}]}
```
Each mutant is applied to a *copy*; it is KILLED if at least one listed property FAILS on it (BMC to `depth`). A survivor
needs an `equivalent_note` (written argument) or a strengthened property. Aim for mutants that model *plausible design
errors* (off-by-one in a bound, a dropped qualifier, a reversed priority, a missing reset, a wrong mask) rather than
random noise. At least one mutant per property family; the ledger records which mutants kill each property.

## C7  Observing internals without editing the RTL
Hierarchical references are unsupported, and the RTL under test is never edited. To observe an internal boundary, provide
a **shim**: a module with the *same name and ports* as an RTL sub-module (e.g. `sram_backend_1rw`), placed in `harness/`
and listed in the job's `files` *instead of* the real file; it instantiates the real implementation (`sram_generic_1rw`)
and adds monitoring wires/assertions on its inputs. Say in the job notes which module the shim replaces and what is
therefore *not* covered (the replaced selector's own logic).

## C8  Naming
Job ids `FAB-*`, `SRAM-*`, `DMA-*`, `SEC-*`; harness `harness/fv_<block>.sv`, top `fv_<block>`; assertions `a_*`,
covers `c_*`, assumptions `e_*`; IDs 1-89 assertions, 90-199 covers (per harness).

## C9  Runtime budget
Four cores are shared. Use `--jobs 2`. PDR timeout <= 180 s per property, BMC depth chosen so a property takes < 2 min.
z3 (smtbmc) is only used for induction attempts and counterexample waveforms: its cost explodes with depth on some
models (3 s at depth 10, 9 s at depth 12 on a trivial arbiter model); ABC `bmc3`/`pdr` are the workhorses.

## C10  What goes in the area document `docs/areas/<AREA>.md`
Scope and spec sources, property catalogue (id, text, spec clause), the assumptions table (id, text, rationale, who
discharges it, whether it is itself checked as an assertion elsewhere), findings (with counterexample paths), not-proved
list with reasons, and the mapping decisions where the brief's wording does not match the RTL.
