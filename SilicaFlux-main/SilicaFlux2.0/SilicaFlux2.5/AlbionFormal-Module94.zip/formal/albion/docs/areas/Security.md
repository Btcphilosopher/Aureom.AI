# AlbionFormal -- area "Security" (DomainGuard / Citadel)

Jobs `SEC-*` · harnesses `harness/fv_cit_*.sv`, `harness/fv_sec_stale.sv` · mutants `mutants/security.json` · manifest `proofs/security.json`
RTL under test: `rtl_under_test/citadel/` (`sf_citadel_gate`, `sf_citadel_permission`, `sf_citadel_domain_table`, packages), pinned in `rtl_under_test/MANIFEST.json`.
Specs: `rtl_under_test/citadel/docs/citadel/02,03,04,08`. Every number below is generated from `reports/results/SEC-*` and
`reports/mutation/results/MUT-SEC-*` by the runner; the tables are not typed in.

## 0. Mapping decisions (read first)

The brief's wording does not match the repository in two places. Both mappings are deliberate and stated here, not hidden.

1. **There is no module named DomainGuard** anywhere in the repository (searched by file name across every SilicaFlux 2.5 archive listing and by content, case-insensitively, across the extracted
   datafabric / citadel / securestore / sramlib / albionverify trees). "DomainGuard and related modules" is mapped to **Citadel**, the Albion domain-enforcement block:
   * `sf_citadel_gate` -- the enforcement check point in front of a master port (permission cannot be bypassed, denied writes cannot reach memory);
   * `sf_citadel_permission` -- the combinational permission checker (domain bound to the physical source port, state, windows, devices, queues);
   * `sf_citadel_domain_table` -- descriptors, port bindings and the privileged command interpreter (REVOKE, SET_STATE, quarantine hook, LOCK).
   Not covered: `sf_citadel_ras`, `fault_manager`, `secboot`, `crypto_adapter`, the top `sf_citadel_security` (it is not part of the vendored set;
   the composition job wires gate/checker/table by hand from their ports exactly as `04_ENFORCEMENT.md` describes).
2. **There is no address translation, TLB or IOMMU** (`08` section 3: "No address translation / IOMMU; Citadel checks the physical address it is
   given"). "Invalidation prevents stale translation use" therefore has **no translation cache to be proved about**. It is mapped to the nearest real
   mechanisms: invalidation of a *domain descriptor* (REVOKE / SET_STATE to a non-ACTIVE state / quarantine / unbinding) against (a) the checker,
   which reads the descriptor state on every request, and (b) the gate's *latched verdict*, which can outlive an invalidation (the documented
   residual A-TGT). The honest result is two-sided: the positive invalidation properties are proved, the strong claim "nothing is forwarded after
   a REVOKE" is **refuted** by a counterexample that reproduces the documented limitation (finding SEC-F1).

## 1. Scope, parameter points and what a proof here means

| job | DUT | parameter point | environment |
|---|---|---|---|
| SEC-GATE-A | `sf_citadel_gate` | `OUT_W=3`, target UNCONSTRAINED | free master/target, free verdict that may change every cycle, flush free |
| SEC-GATE-B | `sf_citadel_gate` | `OUT_W=2`, target obeys ALP response rules (T1/T2) | as above + T1/T2 |
| SEC-PERM-A | `sf_citadel_permission` | `NDOM=2 NW=2 NP=2 NDEV=2 NQ=2 AW=8 LEN_W=8` | **none**: all inputs and the whole descriptor state free |
| SEC-PERM-B | same | same, + INV-UNIQ | unique ids among enrolled slots (equivalence needs it) |
| SEC-TBL-A | `sf_citadel_domain_table` | `NDOM=2 NW=2 NP=2 NDEV=2 NQ=2 NKEY=2 AW=4` | **none** beyond reset: command port and containment completely free |
| SEC-TBL-AW5 | same | `AW=5` | scaling confirmation of the same properties |
| SEC-STALE | table + checker + gate (one port) | `NDOM=2 NW=1 NP=1 NDEV=1 NQ=1 AW=5 LEN_W=5 OUT_W=2` | privileged command plane, free stream; master/target free |

**Small parameter points.** The product configuration is `NDOM=8 NW=4 NP=4 NDEV=7 NQ=16 AW=64`; PDR cannot close at that size (a first
exploratory run of INV-EXCL needed 178 s at AW=6 and 13 s at AW=4). The logic is width- and count-generic (loops over slots/windows, no
width-specific constants), but **a proof at AW=4/8 is not a proof at AW=64**: that step is an argument by parametricity, backed by Citadel's own simulation and
its own formal runs, and is *not* a theorem of this suite. `SEC-TBL-AW5` shows the proofs do not change with the width at the next
point; it does not close the gap.

**Evidence classes.** `PROVED` = unbounded (ABC PDR) for every input sequence the harness assumptions allow. The combinational job
SEC-PERM is exhaustive over *all* inputs and all table states (no reset constraint, no clock) -- the result class is INDUCTIVE/CONDITIONAL
only by the presence of the UNIQ assumption. Properties that restate a protocol rule on an input are CONDITIONAL on that rule.

## 2. Assumptions register

| id | assumption | rationale / source | discharged by |
|---|---|---|---|
| ENV-RST-ANY | asserted in step 0, may assert again at any step | async-assert reset, `08` A-RST | base assumption |
| ENV-RST-NONE | no reset / clock constraint (combinational checker proved from every state) | stateless module | base assumption |
| ENV-SEC-GATE-V1 | `chk_permit_i == (chk_status_i == OKAY)` | the check port is driven by the real checker | **proved**: SEC-PERM `a_permit_iff_okay` (assume-guarantee link) |
| ENV-SEC-GATE-T1 | the target answers only requests it was given (a response may still arrive after a flush: orphan) | ALP-RSP-01 | not checked here (target is external); SEC-GATE-A needs no T1 |
| ENV-SEC-GATE-T2 | a presented target response stays valid and unchanged until accepted | ALP-RSP-02 | not checked here (external); only `a_m_rsp_stable` depends on it |
| ENV-SEC-PERM-UNIQ | enrolled slots have pairwise distinct ids | INV-UNIQ | **proved**: SEC-TBL `a_unique_ids` (inductive over every command sequence) |
| ENV-SEC-CFG | command port driven by ROOT, priv=1, cfg_en=1 (stream free) | management plane, `08` A-CFG | integration obligation (physical exclusivity); SEC-TBL does NOT assume it |
| ENV-SEC-STALE-CFG | lockdown, DFT, queue holds, port isolation and gate flush tied low; containment free | isolate the invalidation path; flush is another withdrawal mechanism | scope decision, stated |
| ENV-SEC-STALE-ADDR | request addresses fit the checker's AW-bit space | the gate's 64-bit address is truncated in the small model | scope decision, stated |

The master is not constrained in SEC-GATE / SEC-PERM / SEC-TBL (the gate samples the payload only at acceptance); in SEC-STALE only its address range is
restricted (ENV-SEC-STALE-ADDR). The verdict is free apart from V1.

## 3. Findings

### SEC-F1 -- a stale PERMIT survives an invalidation (documented residual, reproduced; claim REFUTED)

* Claim tested (`SEC-STALE/a_no_forward_after_invalidation`): once domain D has become invalid (REVOKE, SET_STATE away from ACTIVE, quarantine, unbinding), no request of D is forwarded to the target.
* Result: **FAILED**, counterexample at step 6: `reports/counterexamples/SEC-STALE/a_no_forward_after_invalidation/` (`report.md`, `trace.vcd`, confirmed by an independent simulation replay).
  Trace: slot 1 enrolled, activated and bound (steps 1-4); a request of D is accepted; at its FIRST evaluation (step 5) the real checker sees D ACTIVE and bound and PERMITs it, so the gate
  latches PERMIT and presents it; the target does not accept (`t_req_ready_i = 0`); the ROOT REVOKE of the slot lands (`slot_state_o` -> INVALID, `act_D` -> 0); the target accepts in step 6 and the request is
  forwarded **after** the domain was revoked.
* This is exactly the limitation the design documents (`04_ENFORCEMENT.md` "Known limitation (assumption A-TGT)", `08` limitation 12): the verdict is latched so that a policy change cannot withdraw a `valid` the target has seen (ALP-REQ-02); the delay is bounded only by the target's own acceptance. It is **not a new defect**; it is a bounded-by-environment window that formal reproduces and cannot close.
* What IS proved (the true, weaker statements): `a_post_invalidation_denied` (a request whose FIRST evaluation finds D invalidated is never presented, even if D is re-activated while it waits), `a_fwd_needs_active_at_eval` (everything presented was permitted by the real checker against the real table at its first evaluation), `a_stale_forward_only_if_latched` (a stale forward is only ever a request latched PERMIT while D was ACTIVE), `a_revoke_visible_to_checker` and `a_new_request_denied_after_revoke` (the checker itself holds no stale state: a revoked domain is denied in the very next cycle).
* Mitigation per the design: quiesce the master before revoking, or flush (port isolation + engine reset), which is the only event that withdraws a presented request (gate properties `a_flush_*` are proved in SEC-GATE; flush is tied low in SEC-STALE precisely to isolate this window).

### SEC-F2 -- port bindings persist across REVOKE (documented limitation, reproduced; claim REFUTED)

* Claim tested (`SEC-TBL-A/a_revoke_clears_binding`, also `SEC-TBL-AW5`): an accepted REVOKE also clears the port bindings of the revoked slot.
* Result: **FAILED**, counterexample at step 4: `reports/counterexamples/SEC-TBL-A/a_revoke_clears_binding/`. Trace: ENROLL (MGMT) slot 1 id 0x10; BIND_PORT (ROOT) -> `bind_o = 0x2`; REVOKE (MGMT) slot 1 -> slot state and every descriptor field cleared, `bind_o` still 0x2.
* The RTL reads: `bind_q` is written only by BIND_PORT; REVOKE clears state, id, capabilities, windows, device/queue/key masks but not `bind_q`. `docs/citadel/03` and `08` limitation 10 state this as intended ("a slot is a hardware resource provisioned to a port by ROOT; the tenant occupying it changes"; the management plane is trusted, assumption A-DOM). Not a new bug.
* What IS proved: `a_revoke_clears_slot` (everything of the slot except bindings is cleared), `a_revoke_bindings_unchanged` (REVOKE leaves bindings exactly as they were), `a_invalid_slot_clean`. Consequence made visible by covers `c_revoke_with_binding` / `c_binding_survives_revoke`: a tenant ENROLLed into a revoked slot is reachable from the bound port without a new BIND_PORT; hardware does not prevent a wrong assignment (A-DOM).

### Observations (not defects)

* **SEC-O1** The permission checker is exact (`a_equiv_spec`) only under INV-UNIQ: `c_dup_id_exists` is REACHED in SEC-PERM-A (two enrolled slots with the same id are possible as far as the checker alone is concerned). INV-UNIQ is guaranteed by the table (`a_unique_ids`, inductive over every command sequence), so the pair is correct; the dependency is a real assume-guarantee link and is listed in the assumptions register.
* **SEC-O2** `a_chk_const` is STRUCTURAL: the gate ties `chk_cls_o/chk_len_o/chk_idx_o` to constants, so the assertion folds at elaboration.
* **SEC-O3** Documented permissiveness confirmed by exclusion, not hidden: MGMT may clear queue holds and port isolation (limitation 10); `a_mgmt_no_bind_lock_safe` therefore deliberately lists only bindings, LOCK, safe-state clear, counters and thresholds.
* **Tooling note** a transient memory kill by another process surfaced once as PDR `UNKNOWN` / yosys `ERROR` with an EMPTY detail (two properties, <5 s); both passed when re-run alone. The runner could classify an empty-output ABC/yosys exit as `KILLED` instead of UNKNOWN/ERROR.


## 4. Property catalogue and results

Class legend: INDUCTIVE = unbounded, only reset/clock assumed; CONDITIONAL = unbounded under the listed assumptions; STRUCTURAL = constant after
elaboration (checked by construction); FAILED = counterexample; COVER = reachability / vacuity evidence.

### Gate (`fv_cit_gate.sv`)

| id | property | spec clause / statement | SEC-GATE-A | SEC-GATE-B |
|---|---|---|---|---|
| 1 | `a_deny_not_forwarded` | [04 s2 / G1] nothing is presented downstream unless the verdict taken in the request's FIRST evaluation cycle was PERMIT and flush_i is low | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 2 | `a_fwd_payload_bit` | [04 s2 / G2] the presented request is bit-for-bit the accepted request (checked for a solver-chosen bit) | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 3 | `a_fwd_domain_id` | [04 s2] the domain field of the presented request equals the domain field of the accepted request | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 4 | `a_chk_domain_id` | [04 s2] the domain presented to the checker is the accepted request's domain (no time-of-check/time-of-use gap) | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 5 | `a_chk_fields` | [04 s2] op, attr and an address bit presented to the checker are the accepted request's | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 6 | `a_chk_const` | [04 s2] the checker is asked for ADDR class, one 16-byte beat, idx 0 | TRIVIAL | TRIVIAL |
| 7 | `a_chk_valid_tracks` | chk_valid_o == a request is held (reference model) | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 8 | `a_commit_first_cycle` | chk_commit_o pulses exactly in the first evaluation cycle of a held request | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 9 | `a_commit_at_most_once` | [G5] at most one commit per request | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 10 | `a_commit_before_leave` | [G5] a request never leaves the hold register without having been committed | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 11 | `a_deny_response_due` | [G3] a denied request with nothing outstanding is answered: m_rsp_valid_o | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 12 | `a_deny_status_explicit` | [G3 / ALP-RSP-05] the error response carries the verdict status and it is not OKAY | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 13 | `a_deny_tag_echo` | [G3] the error response echoes the request tag | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 14 | `a_deny_data_zero` | [G3 / ALP-RSP-05] the error response data is all-zero | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 15 | `a_deny_meta` | [G3] the error response is last=1, is_write echoes the request, reserved/poison/corrected = 0 | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 16 | `a_deny_order` | [G3 / ORD-01] while forwarded requests are outstanding NO error response is synthesised: the response is the target's | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 17 | `a_rsp_sourced` | every master response is either the due local error response or a consumed target response (no phantom / duplicate response) | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 18 | `a_pass_through` | a target response passes through unchanged and t_rsp_ready_o routes the master's ready (or drains) | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 19 | `a_req_ready_model` | m_req_ready_o == (no request held) // forwarded // error response completing | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 20 | `a_orphan_not_forwarded` | [G8] a target response with nothing outstanding is never forwarded to the master and is flagged | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 21 | `a_outstanding_exact` | [G6] outstanding_o == forwarded - answered (flush clears) | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 22 | `a_no_forward_when_full` | [G6] a full counter stalls forwarding, it never wraps | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 23 | `a_reset_clean` | [G7] in reset: nothing presented, no response, nothing outstanding, no request held | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 24 | `a_flush_nothing_presented` | [G9] flush: nothing is presented, the downstream is drained, no target response is forwarded | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 25 | `a_flush_clears_outstanding` | [G9] the outstanding count is zero in the cycle after a flush | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 26 | `a_t_req_stable` | [ALP-REQ-02 / G4] a request presented and not accepted stays presented, unchanged, (except across a flush) | PROVED (CONDITIONAL) | PROVED (CONDITIONAL) |
| 27 | `a_m_rsp_stable` | [ALP-RSP-02 / G4] (target obeys T1/T2) a master response presented and not accepted stays presented, unchanged | N/A | PROVED (CONDITIONAL) |

Covers (non-vacuity):

| id | cover | meaning | SEC-GATE-A | SEC-GATE-B |
|---|---|---|---|---|
| 90 | `c_permit_forward` | a permitted request is forwarded and accepted by the target | REACHED | REACHED |
| 91 | `c_deny_response` | a denied request receives its error response (handshake) | REACHED | REACHED |
| 92 | `c_target_stall` | a permitted request is presented and the target stalls it | REACHED | REACHED |
| 93 | `c_verdict_flips` | the live verdict differs from the latched one while a request is held (the free verdict is exercised) | REACHED | REACHED |
| 94 | `c_flush_cancel` | flush cancels a held, previously permitted request (CANCELLED response due) | REACHED | REACHED |
| 95 | `c_deny_waits` | a denied request waits for outstanding forwarded requests | REACHED | REACHED |
| 96 | `c_orphan` | an orphan target response is drained | REACHED | REACHED |
| 97 | `c_counter_full` | the outstanding counter is full while a permitted request is held | REACHED | REACHED |
| 98 | `c_pass_response` | a target response is passed to the master | REACHED | REACHED |
| 99 | `c_back_to_back` | a request is accepted in the cycle the previous one is forwarded | REACHED | REACHED |

### Permission checker (`fv_cit_perm.sv`)

| id | property | spec clause / statement | SEC-PERM-A | SEC-PERM-B |
|---|---|---|---|---|
| 1 | `a_permit_implies_spec` | [02] permit => an enrolled, ACTIVE, capable slot bound to src_i owns the request (priority-free declarative predicate) | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 2 | `a_equiv_spec` | [02] (INV-UNIQ) permit <=> the declarative predicate: the checker is exactly its specification | N/A | PROVED (CONDITIONAL) |
| 3 | `a_spoof_denied` | [02 step 7 / domain association] a domain id not bound to the PHYSICAL source port is always denied | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 4 | `a_unknown_denied` | [02 step 7] an unknown domain id is always denied | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 5 | `a_inactive_denied` | [02 step 9] a domain that is not ACTIVE (INVALID / SUSPENDED / QUARANTINED) is always denied | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 6 | `a_isolated_denied` | [02 step 1] an isolated source port is always denied | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 7 | `a_dft_denied` | [02 step 2] DFT / test access active denies everyone | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 8 | `a_lockdown_denied` | [02 step 8] safe state denies every domain except ROOT/MGMT | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 9 | `a_invalid_dom_denied` | [02 step 6] domain id 0xFF (INVALID) is always denied | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 10 | `a_no_wrap` | [02 step 11-12] an ADDR permit has a non-zero length and addr+len-1 does not wrap the address space | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 11 | `a_permit_mem_window` | [02] a memory permit => the range lies inside ONE valid window of an owning slot that grants the access | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 12 | `a_permit_device_rules` | [02 step 13] a device permit => range wholly inside exactly one device, priv/secure met, no instruction fetch, device permission | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 13 | `a_write_needs_write_right` | [02] a WRITE memory permit needs a window with the WRITE right (the read right is not enough) | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 14 | `a_read_needs_read_right` | [02] a READ memory permit needs a window with the READ right | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 15 | `a_instr_not_write` | [02 step 5] an instruction-fetch attribute with a WRITE is never permitted | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 16 | `a_queue_rules` | [02] a QUEUE permit => idx < NQ, queue not on abort-hold, queue in the owning domain's mask | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 17 | `a_privilege_not_escalated` | [02 step 10] a privileged / secure attribute is only permitted for a domain with that capability | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 18 | `a_permit_iff_okay` | [02] permit <=> status OKAY: every denial is an explicit error (also discharges ENV-SEC-GATE-V1) | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 19 | `a_status_coarse` | [02] the requester sees only OKAY / BAD_OPCODE / BAD_ATTR / ACCESS_DENIED (no layout oracle) | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 20 | `a_status_from_reason` | [02] status is a pure coarse function of the reason (OK / BAD_OP / BAD_ATTR / everything else ACCESS_DENIED) | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 21 | `a_reason_range` | [02] reason is a defined code (<= 13) and 0 exactly when permitted | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 22 | `a_slot_attribution` | [02] slot_vld_o => the attributed slot is enrolled with this id AND bound to src_i (safe to attribute) | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |
| 23 | `a_permit_needs_attribution` | [02] a permit always comes with a verified domain attribution | PROVED (INDUCTIVE) | PROVED (CONDITIONAL) |

Covers (non-vacuity):

| id | cover | meaning | SEC-PERM-A | SEC-PERM-B |
|---|---|---|---|---|
| 90 | `c_permit_mem` | a memory access is permitted | REACHED | REACHED |
| 91 | `c_permit_device` | a device access is permitted | REACHED | REACHED |
| 92 | `c_permit_queue` | a queue use is permitted | REACHED | REACHED |
| 93 | `c_deny_spoof` | spoof: a known, ACTIVE domain presented on a port it is not bound to is denied (reason BAD_DOM) | REACHED | REACHED |
| 94 | `c_deny_state` | a bound domain that is not ACTIVE is denied (DOM_STATE) | REACHED | REACHED |
| 95 | `c_deny_nomap` | no single window contains the range (NOMAP) | REACHED | REACHED |
| 96 | `c_deny_perm` | a window contains the range but lacks the right (PERM) | REACHED | REACHED |
| 97 | `c_deny_dev` | device permission missing (DEV) | REACHED | REACHED |
| 98 | `c_deny_overflow` | addr+len-1 wraps (OVERFLOW) | REACHED | REACHED |
| 99 | `c_deny_priv` | privilege claim above the domain's capability (PRIV) | REACHED | REACHED |
| 100 | `c_deny_isolated` | isolated source port (ISOLATED) | REACHED | REACHED |
| 101 | `c_deny_lockdown` | safe state denies a tenant (LOCKDOWN) | REACHED | REACHED |
| 102 | `c_deny_badlen` | zero length (BAD_LEN) | REACHED | REACHED |
| 103 | `c_deny_queue` | queue denial (QUEUE) | REACHED | REACHED |
| 104 | `c_dup_id_exists` | two enrolled slots with the same id are possible without UNIQ (shows the UNIQ assumption removes real states) | REACHED | UNREACHABLE |

### Domain table (`fv_cit_table.sv`)

| id | property | spec clause / statement | SEC-TBL-A | SEC-TBL-AW5 |
|---|---|---|---|---|
| 1 | `a_reset_default_deny` | [03] reset => DEFAULT DENY: every slot INVALID, no window, no binding, not locked, no response / control pulse | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 2 | `a_refused_cmd_noop` | [03] a refused command (status != OK) changes no descriptor bit of the chosen slot | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 3 | `a_unpriv_no_effect` | [03] a command from a requester that is not (priv && ROOT/MGMT) never changes the table | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 4 | `a_unpriv_status_before_decode` | [03] privilege is checked BEFORE the opcode is decoded: even opcode 0 from an unprivileged requester is answered BAD_PRIV / NOT_AUTH, never BAD_CMD | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 5 | `a_noauth_refused` | [03] cfg_en_i low => every command is answered NOT_AUTH and has no effect | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 6 | `a_mgmt_no_system_change` | [03] MGMT can never change an enrolled system-domain slot | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 7 | `a_mgmt_no_system_enroll` | [03] MGMT can never create a system-domain slot (a slot holding an id < 0x10 was already enrolled with that id) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 8 | `a_mgmt_no_release_quarantine` | [03] MGMT can neither leave nor REVOKE a QUARANTINED slot | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 9 | `a_mgmt_no_capability_grant` | [03] MGMT can never grant the privileged / secure capability | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 10 | `a_mgmt_no_bind_lock_safe` | [03] MGMT can never change port bindings, set LOCK, clear the safe state, or set thresholds | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 11 | `a_lock_monotone` | [03] LOCK is set until reset | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 12 | `a_lock_freezes_bindings` | [03] after LOCK port bindings never change until reset | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 13 | `a_lock_freezes_system_slots` | [03] after LOCK an enrolled system-domain slot never changes by command | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 14 | `a_lock_no_new_system_slot` | [03] after LOCK no new system-domain slot can be enrolled | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 15 | `a_inv_excl` | [03 INV-EXCL] windows of distinct slots are disjoint whenever either one is EXCLUSIVE (isolation by construction) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 16 | `a_inv_well_formed` | [03] every valid window has base <= limit | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 17 | `a_unique_ids` | [03 INV-UNIQ] enrolled slots hold pairwise distinct domain ids (discharges ENV-SEC-PERM-UNIQ) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 18 | `a_enrolled_id_legal` | [03] no slot is enrolled with the invalid id 0xFF | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 19 | `a_invalid_slot_clean` | [03] an INVALID slot holds no id, window, permission or mask: no stale permission survives in a free slot | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 20 | `a_excl_window_no_device` | [03] an EXCLUSIVE window never touches a device region | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 21 | `a_revoke_clears_slot` | [03 REVOKE] an accepted REVOKE clears EVERYTHING of the slot: INVALID, id, capabilities, windows, device/queue/key masks | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 22 | `a_revoke_clears_binding` | [03 limitation 10 / 08] (CLAIM) an accepted REVOKE also clears the port bindings of the slot | **FAIL** (cex @4) | **FAIL** (cex @4) |
| 23 | `a_revoke_bindings_unchanged` | [03] an accepted REVOKE leaves all port bindings exactly as they were (the true behaviour behind limitation 10) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 24 | `a_revoke_zeroises_keys` | [03] an accepted REVOKE requests zeroisation of exactly the slot's key mask | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 25 | `a_quarantine_forces` | [03] the containment hook forces an enrolled slot to QUARANTINED (a same-cycle REVOKE wins) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 26 | `a_quarantine_root_only_release` | [03] a QUARANTINED slot only leaves quarantine through a ROOT SET_STATE / REVOKE of that slot | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 27 | `a_response_next_cycle` | [03] every command is answered exactly one cycle later (and only commands) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 28 | `a_activation_needs_command` | [03] a slot becomes ACTIVE only through an accepted SET_STATE(ACTIVE) command on that slot (no automatic re-activation) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 29 | `a_enroll_needs_command` | [03] a free slot becomes enrolled only through an accepted ENROLL command on that slot, and lands SUSPENDED (no access until activated) | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 30 | `a_refused_no_pulses` | [03] a refused command emits no control pulse and no slot-clear pulse | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 31 | `a_safe_clear_root_only` | [03] the safe state is cleared only by a ROOT CLR_SAFE command | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |
| 32 | `a_thresholds_root_only` | [03] thresholds are written only by a ROOT SET_THRESH command | PROVED (INDUCTIVE) | PROVED (INDUCTIVE) |

Covers (non-vacuity):

| id | cover | meaning | SEC-TBL-A | SEC-TBL-AW5 |
|---|---|---|---|---|
| 90 | `c_enroll_ok` | a command ENROLLs the chosen slot | REACHED | REACHED |
| 91 | `c_activate` | the chosen slot becomes ACTIVE | REACHED | REACHED |
| 92 | `c_window_installed` | the chosen slot holds a valid window | REACHED | REACHED |
| 93 | `c_excl_window` | an EXCLUSIVE window exists | REACHED | REACHED |
| 94 | `c_revoke_ok` | an accepted REVOKE of the chosen slot | REACHED | REACHED |
| 95 | `c_revoke_with_binding` | an accepted REVOKE of a slot that has a port binding (limitation 10 scenario) | REACHED | REACHED |
| 96 | `c_quarantine` | containment quarantines the chosen slot | REACHED | REACHED |
| 97 | `c_mgmt_refused` | MGMT is refused (BAD_PRIV) | REACHED | REACHED |
| 98 | `c_overlap_refused` | SET_WINDOW refused with OVERLAP | REACHED | REACHED |
| 99 | `c_lock_set` | LOCK is set | REACHED | REACHED |
| 100 | `c_unpriv_refused` | an unprivileged requester is refused | REACHED | REACHED |
| 101 | `c_two_enrolled` | two slots are enrolled at once | REACHED | REACHED |
| 102 | `c_mgmt_ok` | MGMT successfully changes a tenant slot | REACHED | REACHED |
| 103 | `c_bind_set` | a port binding exists | REACHED | REACHED |
| 104 | `c_sys_slot` | an enrolled system-domain slot exists (ROOT enrolled it) | REACHED | REACHED |

### Stale-use composition (`fv_sec_stale.sv`)

| id | property | spec clause / statement | SEC-STALE |
|---|---|---|---|
| 1 | `a_fwd_needs_active_at_eval` | [04 s2] composition: whatever is presented downstream was permitted by the REAL checker against the REAL table at its first evaluation: its domain was ACTIVE and bound then | PROVED (CONDITIONAL) |
| 2 | `a_post_invalidation_denied` | [03 s7 / 04 s2] POSITIVE invalidation property: a request of domain D whose FIRST evaluation finds D invalidated (revoked, suspended, quarantined, unbound) is never presented downstream -- not even if D is re-activated while the request waits | PROVED (CONDITIONAL) |
| 3 | `a_stale_forward_only_if_latched` | [04 A-TGT] a request of D that is presented while D is invalidated was latched PERMIT while D was ACTIVE (the only way a stale permission is used) | PROVED (CONDITIONAL) |
| 4 | `a_no_forward_after_invalidation` | [CLAIM, expected to FAIL = limitation 12 / A-TGT] after D has become invalid, no request of D is forwarded to the target | **FAIL** (cex @6) |
| 5 | `a_revoke_visible_to_checker` | [03] an accepted REVOKE of a slot is visible to the checker at once: the slot is INVALID in the state the checker reads | PROVED (CONDITIONAL) |
| 6 | `a_new_request_denied_after_revoke` | [03 s7] the checker denies every request of a revoked domain in the cycle after the REVOKE (no stale grant in the checker itself) | PROVED (CONDITIONAL) |

Covers (non-vacuity):

| id | cover | meaning | SEC-STALE |
|---|---|---|---|
| 90 | `c_d_forwarded` | a request of D is permitted and forwarded to the target | REACHED |
| 91 | `c_deny_after_revoke` | a request of D is denied because D is invalidated (error response due) | REACHED |
| 92 | `c_stalled_then_revoked` | the stale scenario: a request of D is presented, the target stalls, D is invalidated meanwhile | REACHED |
| 93 | `c_stale_forward` | the stale scenario completes: a request of D is forwarded after D was invalidated | REACHED |
| 94 | `c_revoke_accepted` | a REVOKE command is accepted | REACHED |
| 95 | `c_reactivated` | D is re-activated after having been invalidated (re-ENROLL + activate) | REACHED |
| 96 | `c_binding_survives_revoke` | a REVOKEd slot still carries its port binding (limitation 10) | REACHED |
| 97 | `c_quarantine_stale` | containment invalidates D while a permitted request is held | REACHED |
| 98 | `c_deny_first_eval` | a request whose first evaluation finds D inactive is held and denied | REACHED |


## 5. Vacuity and non-vacuity evidence

Every job carries covers that show the environment is not over-constrained (a verdict that changes while a request is held, a stalled
target, an orphan response, a full counter, a flush that cancels a permitted request; every permission denial reason, a spoof attempt, a device
permit, a queue permit; every table command class, a quarantine, a revocation with a surviving binding, MGMT refused/accepted; the full stale
scenario). `c_dup_id_exists` is REACHED in SEC-PERM-A and UNREACHABLE in SEC-PERM-B, which shows the unique-id assumption removes real states and
is therefore not vacuous. A pass that relies on a property being weak is caught by the mutation campaign (section 6), not by the solver: the self-test
`a_word_tautology` shows a PDR "proof" of a word-level tautology.

## 6. Mutation campaign

**44 / 44 controlled bugs detected** (each applied to a copy of the real RTL; killed = at least one listed property FAILS on the mutant within the BMC depth while it holds on the unmutated RTL).

| mutant | RTL | bug | killed by |
|---|---|---|---|
| MUT-SEC-G01 | sf_citadel_gate.sv | gate forwards a held request without waiting for / honouring the verdict (denied writes reach memory) | SEC-GATE-A/a_deny_not_forwarded, SEC-GATE-B/a_deny_not_forwarded |
| MUT-SEC-G02 | sf_citadel_gate.sv | gate drops the !flush qualifier: a flush no longer withdraws the presented request | SEC-GATE-A/a_flush_nothing_presented, SEC-GATE-A/a_deny_not_forwarded, SEC-GATE-B/a_flush_nothing_presented ... |
| MUT-SEC-G03 | sf_citadel_gate.sv | verdict is not latched in the first evaluation cycle (a later verdict change resurrects / withdraws a decision) | SEC-GATE-A/a_deny_not_forwarded, SEC-GATE-B/a_deny_not_forwarded, SEC-STALE/a_post_invalidation_denied ... |
| MUT-SEC-G04 | sf_citadel_gate.sv | the explicit error response is never generated: a denied request is silently swallowed / hangs | SEC-GATE-A/a_deny_response_due, SEC-GATE-B/a_deny_response_due |
| MUT-SEC-G05 | sf_citadel_gate.sv | the held denied request is not released after its error response: the error response is repeated | SEC-GATE-A/a_chk_valid_tracks, SEC-GATE-A/a_rsp_sourced, SEC-GATE-B/a_chk_valid_tracks ... |
| MUT-SEC-G06 | sf_citadel_gate.sv | the error response carries status OKAY (a denied access looks successful) | SEC-GATE-A/a_deny_status_explicit, SEC-GATE-B/a_deny_status_explicit |
| MUT-SEC-G07 | sf_citadel_gate.sv | the error response does not echo the request tag | SEC-GATE-A/a_deny_tag_echo, SEC-GATE-B/a_deny_tag_echo |
| MUT-SEC-G08 | sf_citadel_gate.sv | a bit of the domain field is corrupted between the accepted and the presented request (domain association broken) | SEC-GATE-A/a_fwd_domain_id, SEC-GATE-A/a_fwd_payload_bit, SEC-GATE-B/a_fwd_domain_id ... |
| MUT-SEC-G09 | sf_citadel_gate.sv | outstanding counter off by one per forwarded request | SEC-GATE-A/a_outstanding_exact, SEC-GATE-B/a_outstanding_exact |
| MUT-SEC-G10 | sf_citadel_gate.sv | an unsolicited (orphan) target response is forwarded to the master | SEC-GATE-A/a_orphan_not_forwarded, SEC-GATE-A/a_rsp_sourced, SEC-GATE-B/a_orphan_not_forwarded ... |
| MUT-SEC-G11 | sf_citadel_gate.sv | audit commit pulses every held cycle instead of once per request | SEC-GATE-A/a_commit_first_cycle, SEC-GATE-A/a_commit_at_most_once, SEC-GATE-B/a_commit_first_cycle ... |
| MUT-SEC-G12 | sf_citadel_gate.sv | the checker is shown the LIVE master domain instead of the held request's (time-of-check / time-of-use gap) | SEC-GATE-A/a_chk_domain_id, SEC-GATE-B/a_chk_domain_id |
| MUT-SEC-G13 | sf_citadel_gate.sv | outstanding counter is not reset | SEC-GATE-A/a_reset_clean, SEC-GATE-A/a_outstanding_exact, SEC-GATE-B/a_reset_clean ... |
| MUT-SEC-G14 | sf_citadel_gate.sv | a flush does not latch the CANCELLED verdict: the cancelled request reappears when the flush ends | SEC-GATE-A/a_deny_not_forwarded, SEC-GATE-B/a_deny_not_forwarded |
| MUT-SEC-G15 | sf_citadel_gate.sv | a flush does not clear the outstanding count | SEC-GATE-A/a_flush_clears_outstanding, SEC-GATE-A/a_outstanding_exact, SEC-GATE-B/a_flush_clears_outstanding ... |
| MUT-SEC-G16 | sf_citadel_gate.sv | the error response overtakes earlier forwarded requests (response order violated) | SEC-GATE-A/a_deny_order, SEC-GATE-A/a_deny_response_due, SEC-GATE-A/a_rsp_sourced ... |
| MUT-SEC-P01 | sf_citadel_permission.sv | domain-to-port binding check removed (a master can claim any domain: spoofing) | SEC-PERM-A/a_spoof_denied, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_spoof_denied ... |
| MUT-SEC-P02 | sf_citadel_permission.sv | domain state check removed (suspended / quarantined / revoked domains keep access) | SEC-PERM-A/a_inactive_denied, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_inactive_denied ... |
| MUT-SEC-P03 | sf_citadel_permission.sv | write permission checked against the READ bit of the window | SEC-PERM-A/a_write_needs_write_right, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_write_needs_write_right ... |
| MUT-SEC-P04 | sf_citadel_permission.sv | window upper bound off by one (permissive): the byte after the window is accessible | SEC-PERM-A/a_permit_mem_window, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_permit_mem_window ... |
| MUT-SEC-P05 | sf_citadel_permission.sv | window upper bound off by one (strict): the last byte of a window is denied -- safe, but not the specified checker; only the equivalence proof can see it | SEC-PERM-B/a_equiv_spec |
| MUT-SEC-P06 | sf_citadel_permission.sv | address-space wrap check removed (a range wrapping past the top of memory passes as an in-window access) | SEC-PERM-A/a_no_wrap, SEC-PERM-B/a_no_wrap |
| MUT-SEC-P07 | sf_citadel_permission.sv | device read/write permission check bypassed | SEC-PERM-A/a_permit_device_rules, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_permit_device_rules ... |
| MUT-SEC-P08 | sf_citadel_permission.sv | port isolation ignored (an isolated engine keeps access) | SEC-PERM-A/a_isolated_denied, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_isolated_denied ... |
| MUT-SEC-P09 | sf_citadel_permission.sv | safe-state lockdown ignored for tenants | SEC-PERM-A/a_lockdown_denied, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_lockdown_denied ... |
| MUT-SEC-P10 | sf_citadel_permission.sv | secure-attribute claim above the domain's capability is not checked | SEC-PERM-A/a_privilege_not_escalated, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_privilege_not_escalated ... |
| MUT-SEC-P11 | sf_citadel_permission.sv | denials leak a different status code (layout oracle: DECODE_ERR vs ACCESS_DENIED) | SEC-PERM-A/a_status_coarse, SEC-PERM-A/a_status_from_reason, SEC-PERM-B/a_status_coarse ... |
| MUT-SEC-P12 | sf_citadel_permission.sv | instruction-fetch + WRITE attribute combination no longer rejected | SEC-PERM-A/a_instr_not_write, SEC-PERM-A/a_permit_implies_spec, SEC-PERM-B/a_instr_not_write ... |
| MUT-SEC-T01 | sf_citadel_domain_table.sv | privilege is checked AFTER the opcode is decoded (an unprivileged requester learns which opcodes exist) | SEC-TBL-A/a_unpriv_status_before_decode |
| MUT-SEC-T02 | sf_citadel_domain_table.sv | REVOKE does not clear the slot's windows (stale windows survive in a free slot) | SEC-TBL-A/a_revoke_clears_slot, SEC-TBL-A/a_invalid_slot_clean |
| MUT-SEC-T03 | sf_citadel_domain_table.sv | exclusive-window overlap check removed (two domains can own the same bytes) | SEC-TBL-A/a_inv_excl |
| MUT-SEC-T04 | sf_citadel_domain_table.sv | slot state resets to ACTIVE instead of INVALID (default allow) | SEC-TBL-A/a_reset_default_deny |
| MUT-SEC-T05 | sf_citadel_domain_table.sv | MGMT may bind ports (only ROOT may) | SEC-TBL-A/a_mgmt_no_bind_lock_safe |
| MUT-SEC-T06 | sf_citadel_domain_table.sv | LOCK no longer freezes port bindings | SEC-TBL-A/a_lock_freezes_bindings |
| MUT-SEC-T07 | sf_citadel_domain_table.sv | MGMT may release a quarantine through SET_STATE | SEC-TBL-A/a_mgmt_no_release_quarantine, SEC-TBL-A/a_quarantine_root_only_release |
| MUT-SEC-T08 | sf_citadel_domain_table.sv | ENROLL lands ACTIVE: a new domain has access before any activation | SEC-TBL-A/a_enroll_needs_command, SEC-TBL-A/a_activation_needs_command |
| MUT-SEC-T09 | sf_citadel_domain_table.sv | a refused command is applied anyway (status reports refusal, state changes) | SEC-TBL-A/a_refused_cmd_noop, SEC-TBL-A/a_unpriv_no_effect |
| MUT-SEC-T10 | sf_citadel_domain_table.sv | containment hook ignored: a faulting tenant is not quarantined | SEC-TBL-A/a_quarantine_forces |
| MUT-SEC-T11 | sf_citadel_domain_table.sv | duplicate domain-id check removed (two slots with the same id) | SEC-TBL-A/a_unique_ids |
| MUT-SEC-T12 | sf_citadel_domain_table.sv | MGMT may enrol a tenant with the privileged capability | SEC-TBL-A/a_mgmt_no_capability_grant |
| MUT-SEC-T13 | sf_citadel_domain_table.sv | MGMT may set LOCK / clear the safe state / clear counters | SEC-TBL-A/a_mgmt_no_bind_lock_safe, SEC-TBL-A/a_safe_clear_root_only |
| MUT-SEC-T14 | sf_citadel_domain_table.sv | windows with base > limit are accepted | SEC-TBL-A/a_inv_well_formed |
| MUT-SEC-T15 | sf_citadel_domain_table.sv | REVOKE leaves the old domain id in the freed slot | SEC-TBL-A/a_revoke_clears_slot, SEC-TBL-A/a_invalid_slot_clean |
| MUT-SEC-T16 | sf_citadel_domain_table.sv | REVOKE does not request zeroisation of the slot's keys | SEC-TBL-A/a_revoke_zeroises_keys |

`MUT-SEC-P05` (strict off-by-one on the window bound: the last byte of a window is denied) is a *safe* change: it is killed **only** by the equivalence property `SEC-PERM-B/a_equiv_spec`, the one property that states the checker is exactly its specification. No mutant survived; none was argued equivalent.

## 7. Not proved / not claimed

* **No unbounded liveness.** `a_deny_response_due` says that a denied request with nothing outstanding has its error response *presented*; delivery
  needs the master to accept it. Nothing says a target ever accepts or answers; a stalled target holds a permitted request indefinitely (A-TGT).
  No fairness model is assumed and none is claimed.
* **Product width / count.** NDOM=8, NW=4, NP=4, NDEV=7, NQ=16, AW=64 are not proved (section 1).
* **No translation / IOMMU / TLB property** exists to be proved (section 0). Invalidation of address *translations* is therefore unclaimed.
* **Stale permission in the gate** (SEC-F1) and **stale port bindings** (SEC-F2) are *refuted claims*, not proved properties; they are
  documented design limitations (08 limitations 12, 10), reproduced with counterexamples.
* Not modelled: `sf_citadel_security` top-level wiring (per-port counters, telemetry privacy, multi-port arbitration of violations), the fault
  manager / RAS (the quarantine hook is a free input), secure boot, crypto adapter and key zeroisation beyond `a_revoke_zeroises_keys`,
  `look_*` / `own_*` lookup outputs of the table, the `flush_i` interaction with revocation (tied low in SEC-STALE; gate flush properties are
  proved in SEC-GATE), DFT/MBIST paths, side channels, timing.
* `a_chk_const` is STRUCTURAL (the RTL ties the constants), not solver-proved.
* The independence of the reference models is limited: `s_*` in the gate harness transcribes the documented operation from port-level events; the
  permission predicate is declarative and priority-free; the table properties are stated as before/after comparisons. They are written from the
  RTL header comments and `02/03/04`, not fitted to counterexamples, but they were written by the same author as the harness.

## 8. Reproduction

```bash
python3 tools/vendor_rtl.py --check
python3 tools/albion_formal.py run --job SEC-GATE-A SEC-GATE-B SEC-PERM-A SEC-PERM-B SEC-TBL-A SEC-STALE --jobs 2
python3 tools/albion_formal.py mutate --mutant $(python3 -c "import json;print(' '.join(m['id'] for m in json.load(open('mutants/security.json'))['mutants']))") --jobs 2
python3 tools/albion_formal.py run --job SEC-STALE --prop a_no_forward_after_invalidation --force     # SEC-F1 counterexample
python3 tools/albion_formal.py run --job SEC-TBL-A --prop a_revoke_clears_binding --force            # SEC-F2 counterexample
```
