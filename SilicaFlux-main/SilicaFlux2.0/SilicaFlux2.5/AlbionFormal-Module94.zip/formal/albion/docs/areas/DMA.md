# DMA -- formal verification area (AlbionFormal, Module 94)

Generated from `proofs/dma.json`, `reports/results/DMA-*` and `reports/mutation/results/MUT-DMA-*` (tables); the prose sections are hand-written. Every number below comes from an executed run; reproduce any row with the command in `reports/ledger.md` (`python3 tools/albion_formal.py run --job <job> --prop <name> --force`).

## 1. Scope and spec sources

RTL under test (pinned by SHA-256 in `rtl_under_test/MANIFEST.json`, archive `silicaflux-datafabric.zip`): `dma_validate`, `dma_transfer_engine` (simple engine), `dma_burst_engine` (buffered engine, single and dual port), `dma_fifo`, `dma_control_regs`, `dma_irq`, and the complete `silicaflux_dma` top (for the protected-memory integration proofs). Specification: `docs/datafabric/DMA.md` (rule table, state machine, busy protection, interrupts), the DUT header comments ("Guarantees", credit scheme, abort/drain), and the SFB2 rules R2/R4/R5/R8 (`PROTOCOL.md`). Register offsets/fields: `dma_defs.svh`.

Harnesses: `harness/fv_dma_validate.sv`, `fv_dma_engine.sv`, `fv_dma_burst.sv`, `fv_dma_fifo.sv`, `fv_dma_regs.sv`, `fv_dma_prot.sv`; shared reference `env/albion_dma_ref.sv` (independent 40-bit-integer statement of the validation rule table). Jobs: `proofs/dma.json`. Mutants: `mutants/dma.json`.

## 2. Mapping of the brief's wording onto the RTL (decisions, stated openly)

| brief says | what the RTL/spec actually has | what is checked |
|---|---|---|
| "Bursts respect configured boundaries" | SFB2 has no native bursts (PROTOCOL R10); a "burst" is `BURST` back-to-back single-beat transactions in one phase of the buffered engine (single port). There is **no page/4 KiB boundary rule** in the RTL or spec. | at most `BURST` accepted requests per phase; phase switches only when the port is idle; every request inside the validated source/destination range; no wrap past 2^32. No boundary rule is checked because none exists. |
| "Descriptors cannot exceed validated limits" | one descriptor in three registers (SRC, DST, LENGTH); no descriptor rings/chains. Limits = `MAX_LEN_LOG2`, DW alignment, 2^32 wrap, non-overlap. | exhaustive `dma_validate` proof at 32-bit width; "no request for a descriptor that fails validation". |
| "Illegal requests do not mutate protected memory" | the DMA has **no memory map and no protection logic** (DMA.md: region legality is not known to the DMA; protection is the crossbar access matrix). | end-to-end: for ANY programmed descriptor the DMA mutates only bytes inside the programmed destination range and nothing at all if validation fails; a protected window is therefore untouched unless software programmed the DMA at it (`fv_dma_prot`). The crossbar's own protection is verified in the DataFabric/SRAM areas, not here. |
| "Transfer counters remain valid" | `bytes_done`, beat counters, FIFO pointers/count, issue/response counters. | ghost-model equalities and bounds (see catalogue). |
| "Completed transfers have consistent accounting" | DONE is decoded from the terminal state after the last write response. | `a_done_*` family (all beats read/written once, bytes_done == LENGTH, nothing outstanding, no error). |
| "Reset establishes documented control states" (DMA part) | DMA.md 4: reset returns the engine to IDLE, clears registers, no request until START. | `a_reset_state`, `a_no_req_before_start`, register reset values. |
| liveness | no completion guarantee exists (DMA.md: no watchdog; slow slave is not faulty). | **not claimed.** `c_done` covers only show a completing trace exists. No bounded-completion property was written: it would need a slave-latency assumption and was not required. |

## 3. Result summary

Assertion classes over all DMA jobs: BOUNDED 154, CONDITIONAL 175, INDUCTIVE 35, N/A 6, STRUCTURAL 10.

`INDUCTIVE` = unbounded proof (ABC PDR) with only reset/clock assumed; `CONDITIONAL` = unbounded proof under the listed environment assumptions (all engine/protocol jobs: SFB2 slave rules, and ENV-DMA-SMALL where noted); `BOUNDED` = no counterexample to the stated BMC depth, no unbounded argument; `TRIVIAL` = constant after elaboration (a literal interface contract). Full definitions: `docs/METHODOLOGY.md`.

| job | RTL module | parameters | assumptions | BMC depth / PDR budget | IND | COND | BOUNDED | FAILED | TRIV/NA | covers reached / unreachable / other |
|---|---|---|---|---|---|---|---|---|---|---|
| DMA-VAL-DW32-L24 | dma_validate | `{"DW": 32, "MAX_LEN_LOG2": 24}` | ENV-RST-NONE | 3 / 120s | 12 | 0 | 0 | 0 | 0 | 10 / 0 / 0 |
| DMA-VAL-DW16-L6 | dma_validate | `{"DW": 16, "MAX_LEN_LOG2": 6}` | ENV-RST-NONE | 3 / 120s | 12 | 0 | 0 | 0 | 0 | 10 / 0 / 0 |
| DMA-VAL-DW8-L10 | dma_validate | `{"DW": 8, "MAX_LEN_LOG2": 10}` | ENV-RST-NONE | 3 / 120s | 11 | 0 | 0 | 0 | 1 | 8 / 2 / 0 |
| DMA-ENG-DW16-S | dma_transfer_engine | `{"DW": 16, "MAX_LEN_LOG2": 3, "SMALL": 1, "AB": 6}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 22 / 120s | 0 | 29 | 14 | 0 | 2 | 14 / 1 / 0 |
| DMA-BRS-S-B2 | dma_burst_engine (single port, FIFO 4, BURST 2) | `{"DW": 16, "MAX_LEN_LOG2": 4, "FIFO_DEPTH": 4, "BURST": 2, "DUAL_PORT": 0, "MAX_OUT": 2, "SMALL": 1, "AB": 6}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 7 | 25 | 0 | 2 | 13 / 1 / 1 |
| DMA-BRS-S-B4 | dma_burst_engine (single port, FIFO 4, BURST 4) | `{"DW": 16, "MAX_LEN_LOG2": 4, "FIFO_DEPTH": 4, "BURST": 4, "DUAL_PORT": 0, "MAX_OUT": 2, "SMALL": 1, "AB": 6}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 7 | 25 | 0 | 2 | 14 / 1 / 0 |
| DMA-BRS-S-F2 | dma_burst_engine (single port, FIFO 2, BURST 2, MAX_OUT 1) | `{"DW": 16, "MAX_LEN_LOG2": 4, "FIFO_DEPTH": 2, "BURST": 2, "DUAL_PORT": 0, "MAX_OUT": 1, "SMALL": 1, "AB": 6}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 14 | 18 | 0 | 2 | 14 / 1 / 0 |
| DMA-BRS-D-B2 | dma_burst_engine (dual port, FIFO 4, MAX_OUT 2) | `{"DW": 16, "MAX_LEN_LOG2": 4, "FIFO_DEPTH": 4, "BURST": 2, "DUAL_PORT": 1, "MAX_OUT": 2, "SMALL": 1, "AB": 6}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 8 | 23 | 0 | 3 | 13 / 2 / 0 |
| DMA-REG-E0-P1 | dma_control_regs (ENGINE 0, PERF 1, DW 32) | `{"DW": 32, "ENGINE": 0, "FIFO_DEPTH": 1, "MAX_LEN_LOG2": 24, "PERF": 1}` | ENV-RST-ANY, ENV-DMA-ENG-1, ENV-DMA-ENG-2, ENV-DMA-ENG-3 | 20 / 60s | 0 | 18 | 0 | 0 | 0 | 9 / 0 / 0 |
| DMA-REG-E0-P0 | dma_control_regs (ENGINE 0, PERF 0, DW 32) | `{"DW": 32, "ENGINE": 0, "FIFO_DEPTH": 1, "MAX_LEN_LOG2": 24, "PERF": 0}` | ENV-RST-ANY, ENV-DMA-ENG-1, ENV-DMA-ENG-2, ENV-DMA-ENG-3 | 20 / 60s | 0 | 18 | 0 | 0 | 0 | 9 / 0 / 0 |
| DMA-REG-E1-P1 | dma_control_regs (ENGINE 1, FIFO 8, PERF 1, DW 16) | `{"DW": 16, "ENGINE": 1, "FIFO_DEPTH": 8, "MAX_LEN_LOG2": 16, "PERF": 1}` | ENV-RST-ANY, ENV-DMA-ENG-1, ENV-DMA-ENG-2, ENV-DMA-ENG-3 | 20 / 60s | 0 | 18 | 0 | 0 | 0 | 9 / 0 / 0 |
| DMA-PROT-E0 | silicaflux_dma (ENGINE 0) + protected window | `{"DW": 16, "ENGINE": 0, "MAX_LEN_LOG2": 3, "SMALL": 1, "AB": 6, "PB": 24, "PE": 32}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 3 | 3 | 0 | 0 | 6 / 0 / 0 |
| DMA-PROT-E1S | silicaflux_dma (ENGINE 1 single port) + protected window | `{"DW": 16, "ENGINE": 1, "FIFO_DEPTH": 4, "BURST": 2, "DUAL_PORT": 0, "MAX_OUT": 2, "MAX_LEN_LOG2": 3, "SMALL": 1, "AB": 6, "PB": 24, "PE": 32}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 2 | 4 | 0 | 0 | 6 / 0 / 0 |
| DMA-PROT-E1D | silicaflux_dma (ENGINE 1 dual port) + protected window | `{"DW": 16, "ENGINE": 1, "FIFO_DEPTH": 4, "BURST": 2, "DUAL_PORT": 1, "MAX_OUT": 2, "MAX_LEN_LOG2": 3, "SMALL": 1, "AB": 6, "PB": 24, "PE": 32}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 3 | 3 | 0 | 0 | 6 / 0 / 0 |
| DMA-FIFO-D2W4 | dma_fifo (DEPTH 2, WIDTH 4) | `{"WIDTH": 4, "DEPTH": 2, "TAGW": 3}` | ENV-RST-ANY, ENV-FIFO-1, ENV-FIFO-2 | 24 / 90s | 0 | 4 | 0 | 0 | 0 | 5 / 0 / 0 |
| DMA-FIFO-D4W8 | dma_fifo (DEPTH 4, WIDTH 8) | `{"WIDTH": 8, "DEPTH": 4, "TAGW": 3}` | ENV-RST-ANY, ENV-FIFO-1, ENV-FIFO-2 | 24 / 90s | 0 | 4 | 0 | 0 | 0 | 5 / 0 / 0 |
| DMA-FIFO-D8W4 | dma_fifo (DEPTH 8, WIDTH 4) | `{"WIDTH": 4, "DEPTH": 8, "TAGW": 3}` | ENV-RST-ANY, ENV-FIFO-1, ENV-FIFO-2 | 24 / 90s | 0 | 4 | 0 | 0 | 0 | 5 / 0 / 0 |
| DMA-ENG-DW32-S | dma_transfer_engine | `{"DW": 32, "MAX_LEN_LOG2": 4, "SMALL": 1, "AB": 6}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 18 / 60s | 0 | 29 | 14 | 0 | 2 | 14 / 1 / 0 |
| DMA-BRS-S-F2-M2 | dma_burst_engine (single port, FIFO 2, BURST 2, MAX_OUT 2) | `{"DW": 16, "MAX_LEN_LOG2": 4, "FIFO_DEPTH": 2, "BURST": 2, "DUAL_PORT": 0, "MAX_OUT": 2, "SMALL": 1, "AB": 6}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8, ENV-DMA-SMALL | 16 / 30s | 0 | 7 | 25 | 0 | 2 | 14 / 1 / 0 |

## 4. Property catalogue (one row per assertion; class per job; BND = BOUNDED at the job's BMC depth)

### harness/fv_dma_burst.sv

Jobs: DMA-BRS-S-B2, DMA-BRS-S-B4, DMA-BRS-S-F2, DMA-BRS-D-B2, DMA-BRS-S-F2-M2

| # | property | statement [spec clause] | BRS-S-B2 | BRS-S-B4 | BRS-S-F2 | BRS-D-B2 | BRS-S-F2-M2 |
|---|---|---|---|---|---|---|---|
| 1 | `a_fifo_le_depth` | [DMA.md 5] FIFO occupancy never exceeds FIFO_DEPTH (no overflow) and never underflows (underflow wraps above DEPTH) | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 2 | `a_credit` | [DMA.md 5] credit: reads issued - writes issued <= FIFO_DEPTH (a read response can never find the FIFO full) | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 3 | `a_fifo_occupancy` | [DMA.md 5] FIFO occupancy == good read responses - accepted writes while a transfer runs (exact accounting, no loss/duplication; narrow 5-bit ghost) | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 4 | `a_outstanding_bound` | [DMA.md 5] outstanding transactions per port never exceed MAX_OUT | BND d16 | BND d16 | COND | COND | BND d16 |
| 5 | `a_rsp_always_taken` | [DMA.md 5] rsp_ready is constant 1: every response is consumed in its arrival cycle | TRIV | TRIV | TRIV | TRIV | TRIV |
| 6 | `a_burst_le_burst` | [DMA.md 5] a read or write phase issues at most BURST back-to-back transactions | BND d16 | BND d16 | COND | n/a | BND d16 |
| 7 | `a_phase_switch_idle` | [DMA.md 5/DUT header] the phase changes only when the port is idle (nothing presented, nothing outstanding) | BND d16 | BND d16 | COND | n/a | BND d16 |
| 8 | `a_dual_port_types` | [DMA.md 5] dual port: port 0 only reads, port 1 only writes | n/a | n/a | n/a | COND | n/a |
| 9 | `a_no_req_illegal` | [DMA.md 2] a request is only presented for a descriptor that passes validation (illegal => no bus access, no memory mutation) | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 10 | `a_rd_addr_seq` | each read addr == src + beat*DW/8 for the next un-issued beat: no duplicate, skipped or reordered read | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 11 | `a_wr_addr_seq` | each write addr == dst + beat*DW/8 for the next un-issued beat: no duplicate, skipped or reordered write | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 12 | `a_rd_in_src_range` | [DMA.md 2] every read address lies inside [src, src+len) and the word does not wrap past 2^32 | BND d16 | BND d16 | BND d16 | BND d15 | BND d16 |
| 13 | `a_wr_in_dst_range` | [DMA.md 2] every write address lies inside [dst, dst+len) and the word does not wrap past 2^32 | BND d16 | BND d16 | BND d16 | BND d14 | BND d16 |
| 14 | `a_wr_strb_exact` | [DMA.md 2] write strobes are byte-exact: byte b written iff addr+b < dst+len | BND d16 | BND d16 | BND d16 | BND d15 | BND d16 |
| 15 | `a_wr_strb_no_overrun` | [DMA.md 2] no strobed byte outside [dst, dst+len): bytes after the end are never modified | BND d16 | BND d16 | BND d16 | BND d15 | BND d16 |
| 16 | `a_req_stable` | [SFB2 R2] each presented request stays presented with an unchanged payload until accepted (every port) | BND d16 | BND d16 | COND | BND d16 | BND d16 |
| 17 | `a_wr_le_good_reads` | [DMA.md 5] writes never overtake good reads: accepted writes <= good read responses | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 18 | `a_data_integrity` | FIFO data path: the write of beat kk carries the data returned by the read of beat kk (tagged beat, any kk < 2^TAGW) | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 19 | `a_no_rd_after_error` | [DUT hdr] after any bus error no new READ is started | BND d16 | BND d16 | COND | BND d16 | BND d16 |
| 20 | `a_no_wr_after_werr` | [DUT hdr] after a write error no new WRITE is started | COND | COND | COND | COND | COND |
| 21 | `a_abort_no_new_req` | [DMA.md 4/5] once an abort has been seen no new request is started on any port | COND | COND | COND | COND | COND |
| 22 | `a_end_drained` | [DUT hdr] DONE/ERROR only after every outstanding response was drained and consumed and nothing is presented | BND d16 | BND d16 | COND | BND d16 | BND d16 |
| 23 | `a_fail_code_illegal` | [DMA.md 2] a descriptor failing validation ends in ERROR with exactly the documented first-failing-rule code | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 24 | `a_fail_code_legal` | [DMA.md 2/5] a legal descriptor never reports a validation code: only READ_BUS/WRITE_BUS/ABORTED | COND | COND | COND | BND d16 | COND |
| 25 | `a_fail_has_code` | ERROR always carries a non-NONE documented code (1..10) | COND | COND | COND | COND | COND |
| 26 | `a_bytes_done_le_len` | bytes_done never exceeds the validated LENGTH | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 27 | `a_bytes_done_monotone` | bytes_done never decreases within a transfer | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 28 | `a_bytes_done_ghost` | [DMA.md 5] bytes_done == bytes of the contiguous OK-write prefix (before the first write error), byte-accurate | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 29 | `a_done_accounting` | [DMA.md 1/5] DONE => legal, every beat read (good) and written exactly once and acknowledged OK, bytes_done == LENGTH, no bus error | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |
| 30 | `a_done_xor_fail` | DONE and ERROR are never raised together; each implies BUSY; busy == (state != IDLE) | COND | COND | COND | COND | COND |
| 31 | `a_reset_state` | [DMA.md 4] reset: IDLE, no request, bytes_done 0, error code NONE, FIFO empty | COND | COND | COND | COND | COND |
| 32 | `a_no_req_before_start` | [DMA.md 4] after reset no request and not busy until a START is accepted | COND | COND | COND | COND | COND |
| 33 | `a_err_code_first_error` | [DUT hdr] the reported code is that of the FIRST bus error: READ_BUS (8) for a read error, WRITE_BUS (9) for a write error | BND d16 | BND d16 | COND | BND d16 | BND d16 |
| 34 | `a_err_addr_first_error` | [DMA.md 2] ERROR_ADDR is the address of the failing beat (src/dst + index of the failing response * DW/8) | BND d16 | BND d16 | BND d16 | BND d16 | BND d16 |

| # | cover | purpose | BRS-S-B2 | BRS-S-B4 | BRS-S-F2 | BRS-D-B2 | BRS-S-F2-M2 |
|---|---|---|---|---|---|---|---|
| 90 | `c_done` | a transfer completes (DONE) | reach | reach | reach | reach | reach |
| 91 | `c_fifo_full` | the FIFO fills to FIFO_DEPTH | unreached | reach | reach | reach | reach |
| 92 | `c_phase_switch` | single port: the phase switches (read burst -> write burst) | reach | reach | reach | unreach | reach |
| 93 | `c_burst_full` | single port: a full BURST of requests is issued in one phase | reach | reach | reach | unreach | reach |
| 94 | `c_two_outstanding` | MAX_OUT transactions are in flight on a port | reach | reach | reach | reach | reach |
| 95 | `c_read_error` | READ_BUS error path | reach | reach | reach | reach | reach |
| 96 | `c_write_error` | WRITE_BUS error path | reach | reach | reach | reach | reach |
| 97 | `c_aborted` | ABORTED path | reach | reach | reach | reach | reach |
| 98 | `c_partial_tail` | a partial final write strobe is presented | reach | reach | reach | reach | reach |
| 99 | `c_stall` | a request waits for acceptance (back-pressure) | reach | reach | reach | reach | reach |
| 100 | `c_concurrent` | dual port: a read and a write are accepted in the same cycle | unreach | unreach | unreach | reach | unreach |
| 101 | `c_data_tagged` | the tagged beat's data reaches its write (monitor armed and compared) | reach | reach | reach | reach | reach |
| 102 | `c_val_error` | descriptor rejected by validation | reach | reach | reach | reach | reach |
| 103 | `c_reset_mid` | reset hits while a transfer is in flight | reach | reach | reach | reach | reach |
| 104 | `c_abort_done` | DONE although an abort was seen (abort raced the last beat) | reach | reach | reach | reach | reach |

### harness/fv_dma_engine.sv

Jobs: DMA-ENG-DW16-S, DMA-ENG-DW32-S

| # | property | statement [spec clause] | ENG-DW16-S | ENG-DW32-S |
|---|---|---|---|---|
| 1 | `a_busy_iff_not_idle` | [DMA.md 1] BUSY == (state != IDLE) | TRIV | TRIV |
| 2 | `a_done_xor_fail` | [DMA.md 1] DONE and ERROR are never raised together | COND | COND |
| 3 | `a_terminal_busy` | [DMA.md 1] DONE/ERROR coincide with BUSY (no 'not busy and no outcome' window) | COND | COND |
| 4 | `a_terminal_one_cycle` | DONE/ERROR is a one-cycle pulse followed by IDLE | COND | COND |
| 5 | `a_req_state_coherent` | [DMA.md 4] a request is presented only in ISSUE_READ (read) / ISSUE_WRITE (write) | COND | COND |
| 6 | `a_rsp_ready_wait` | [DMA.md 4] rsp_ready == 1 exactly in WAIT_READ / WAIT_WRITE | TRIV | TRIV |
| 7 | `a_reset_state` | [DMA.md 4] reset: IDLE, no request, bytes_done 0, error code NONE | COND | COND |
| 8 | `a_no_req_before_start` | [DMA.md 4] after reset no request and not busy until a START is accepted | COND | COND |
| 9 | `a_no_req_illegal` | [DMA.md 2] a request is only presented for a descriptor that passes validation (illegal => no bus access, no memory mutation) | BND d22 | BND d18 |
| 10 | `a_fail_code_illegal` | [DMA.md 2] a descriptor failing validation ends in ERROR with exactly the documented first-failing-rule code | BND d22 | BND d18 |
| 11 | `a_fail_code_legal` | [DMA.md 2/4] a legal descriptor never reports a validation code (1..7): only READ_BUS/WRITE_BUS/ABORTED | COND | COND |
| 12 | `a_fail_has_code` | ERROR always carries a non-NONE documented code (1..10) | COND | COND |
| 13 | `a_rd_addr_tracks_beat` | reads walk the source one word per completed beat: addr == expected-next-read register (src, src+DW/8, ...): no duplicate or skipped read | COND | COND |
| 14 | `a_wr_addr_tracks_beat` | writes walk the destination one word per completed beat: addr == expected-next-write register (dst, dst+DW/8, ...): no duplicate or skipped write | COND | COND |
| 15 | `a_rd_in_src_range` | [DMA.md 2] every read address lies inside [src, src+len) | BND d22 | COND |
| 16 | `a_wr_in_dst_range` | [DMA.md 2] every write address lies inside [dst, dst+len) | COND | COND |
| 17 | `a_rd_no_wrap` | the read word never crosses 2^32 (no address wrap) | BND d22 | BND d18 |
| 18 | `a_wr_no_wrap` | the written word never crosses 2^32 (no address wrap) | BND d22 | BND d18 |
| 19 | `a_wr_strb_exact` | [DMA.md 2] write strobes are byte-exact: byte b is written iff addr+b < dst+len | COND | COND |
| 20 | `a_wr_strb_no_overrun` | [DMA.md 2] no strobed byte lies outside [dst, dst+len): bytes after the end are never modified | COND | COND |
| 21 | `a_req_stable` | [SFB2 R2] a presented request stays presented with an unchanged payload until accepted (never withdrawn) | COND | COND |
| 22 | `a_one_outstanding` | [SFB2 R6/DMA.md 4] exactly one transaction in flight: nothing presented while one is outstanding | COND | COND |
| 23 | `a_rsp_always_taken` | [DMA.md 4] every response is consumed in the cycle it arrives (rsp_ready whenever a response can be outstanding) | COND | COND |
| 24 | `a_beat_counters_valid` | transfer counters valid: writes done <= reads done <= writes done + 1, reads done <= ceil(len/(DW/8)) | COND | COND |
| 25 | `a_wr_after_good_read` | [DMA.md 4] a write is presented only after an error-free read response of its beat (flag form) | COND | COND |
| 26 | `a_wdata_from_read` | [DMA.md 4] the write data equals the data returned by that read | COND | COND |
| 27 | `a_no_req_after_error` | [DMA.md 4] after any bus error no further request is presented in this transfer | COND | COND |
| 28 | `a_no_wr_after_rd_err` | [DMA.md 4] after a read error no write is presented | COND | COND |
| 29 | `a_bytes_done_le_len` | bytes_done never exceeds the validated LENGTH | COND | COND |
| 30 | `a_bytes_done_monotone` | bytes_done never decreases within a transfer (it restarts only at START) | BND d22 | BND d18 |
| 31 | `a_bytes_done_ghost` | [DMA.md 4] bytes_done == bytes of the contiguous prefix of OK write responses (byte-accurate, ghost model) | COND | COND |
| 32 | `a_bytes_done_prefix` | bytes_done is a whole number of beats unless the transfer is complete | BND d22 | BND d18 |
| 33 | `a_done_all_consumed` | [DMA.md 1/4] DONE => every byte of LENGTH has been moved: remaining bytes (ghost) == 0 and bytes_done == ghost bytes-done | BND d22 | BND d18 |
| 34 | `a_terminal_drained` | DONE/ERROR only after the last transaction's response was consumed: nothing presented or outstanding | COND | COND |
| 35 | `a_err_addr_read` | [DMA.md 2] on a bus error ERROR_ADDR is the failing beat's address: the expected-next-read register (READ_BUS) | BND d22 | BND d18 |
| 36 | `a_err_addr_write` | [DMA.md 2] ERROR_ADDR of a WRITE_BUS error is the expected-next-write register (destination of the failing beat) | COND | COND |
| 37 | `a_abort_no_new_request` | [DMA.md 4] once an abort has been seen no NEW request is started (it is applied at the next beat boundary) | COND | COND |
| 38 | `a_abort_drains` | [DMA.md 4] ABORTED is reported only with nothing in flight: the engine never withdraws or abandons a request | COND | COND |
| 39 | `a_rd_addr_arith` | reads (arithmetic form): addr == src + (completed beats)*DW/8 in 34-bit integers | BND d22 | BND d18 |
| 40 | `a_wr_addr_arith` | writes (arithmetic form): addr == dst + (completed beats)*DW/8 in 34-bit integers | BND d22 | BND d18 |
| 41 | `a_wr_beat_one_ahead` | a write is presented only when exactly one more read than write has completed (the read of THIS beat; counter form) | COND | BND d18 |
| 42 | `a_done_no_error` | [DMA.md 1/4] DONE => no bus error was seen in the transfer and nothing is outstanding | COND | COND |
| 43 | `a_done_legal` | [DMA.md 1/2] DONE => the descriptor passed validation | BND d22 | BND d18 |
| 44 | `a_done_beats_exact` | [DMA.md 4] DONE => every beat was read and written exactly once: reads OK == writes OK == ceil(len/(DW/8)) | BND d22 | BND d18 |
| 45 | `a_done_bytes_eq_len` | [DMA.md 1/4] DONE => bytes_done == the validated LENGTH (completed transfers have consistent accounting) | BND d22 | BND d18 |

| # | cover | purpose | ENG-DW16-S | ENG-DW32-S |
|---|---|---|---|---|
| 90 | `c_done` | a transfer completes (DONE) | reach | reach |
| 91 | `c_multi_beat` | two beats are written (counters exercised) | reach | reach |
| 92 | `c_partial_tail` | a partial final write strobe is presented | reach | reach |
| 93 | `c_read_error` | READ_BUS error path | reach | reach |
| 94 | `c_write_error` | WRITE_BUS error path | reach | reach |
| 95 | `c_aborted` | ABORTED path | reach | reach |
| 96 | `c_val_zero` | descriptor rejected: ZERO_LENGTH | reach | reach |
| 97 | `c_val_length` | descriptor rejected: LENGTH | reach | reach |
| 98 | `c_val_align` | descriptor rejected: SRC_ALIGN or DST_ALIGN | reach | reach |
| 99 | `c_val_overlap` | descriptor rejected: OVERLAP | reach | reach |
| 100 | `c_val_overflow` | descriptor rejected: SRC/DST_OVERFLOW (needs wide addresses: unreachable under ENV-DMA-SMALL) | unreach | unreach |
| 101 | `c_stall` | a request waits for acceptance (back-pressure) | reach | reach |
| 102 | `c_reset_mid` | reset hits while a transfer is in flight | reach | reach |
| 103 | `c_abort_done` | DONE although an abort was seen (abort raced the last beat) | reach | reach |
| 104 | `c_restart` | a second transfer is started after a first one that read data | reach | reach |

### harness/fv_dma_fifo.sv

Jobs: DMA-FIFO-D2W4, DMA-FIFO-D4W8, DMA-FIFO-D8W4

| # | property | statement [spec clause] | FIFO-D2W4 | FIFO-D4W8 | FIFO-D8W4 |
|---|---|---|---|---|---|
| 1 | `a_count_le_depth` | FIFO occupancy never exceeds DEPTH (no overflow) and the counter never wraps | COND | COND | COND |
| 2 | `a_count_matches` | occupancy == pushes - pops since reset/clear (exact accounting, nothing lost or duplicated) | COND | COND | COND |
| 3 | `a_reset_empty` | reset empties the FIFO | COND | COND | COND |
| 4 | `a_fifo_order` | first-in first-out: the k-th pop returns the k-th pushed word (tagged beat, any k < 2^TAGW) | COND | COND | COND |

| # | cover | purpose | FIFO-D2W4 | FIFO-D4W8 | FIFO-D8W4 |
|---|---|---|---|---|---|
| 90 | `c_full` | the FIFO fills to DEPTH | reach | reach | reach |
| 91 | `c_push_pop` | simultaneous push and pop | reach | reach | reach |
| 92 | `c_clr_nonempty` | clr with data inside | reach | reach | reach |
| 93 | `c_tag_checked` | the tagged beat is popped and compared | reach | reach | reach |
| 94 | `c_push_full_pop` | push into a full FIFO with a simultaneous pop (allowed by the contract) | reach | reach | reach |

### harness/fv_dma_prot.sv

Jobs: DMA-PROT-E0, DMA-PROT-E1S, DMA-PROT-E1D

| # | property | statement [spec clause] | PROT-E0 | PROT-E1S | PROT-E1D |
|---|---|---|---|---|---|
| 1 | `a_illegal_no_bus` | [DMA.md 2] an invalid programmed descriptor causes no bus access of any kind (no read, no write) | BND d16 | COND | COND |
| 2 | `a_illegal_no_mem_write` | [DMA.md 2] an invalid descriptor never mutates memory: no accepted write | BND d16 | BND d16 | COND |
| 3 | `a_write_inside_dst` | [DMA.md 2] every byte the DMA writes lies inside the programmed [dst, dst+len): nothing else is mutated | COND | BND d16 | BND d16 |
| 4 | `a_prot_window_clean` | protected window [PB,PE) is mutated only if the programmed destination range intersects it (end-to-end, any descriptor, any traffic) | COND | BND d16 | BND d16 |
| 5 | `a_source_untouched` | the DMA never modifies its own source range (ranges are validated disjoint) | BND d16 | BND d16 | BND d16 |
| 6 | `a_no_bus_before_start` | [DMA.md 4] after reset no bus access until a START is accepted | COND | COND | COND |

| # | cover | purpose | PROT-E0 | PROT-E1S | PROT-E1D |
|---|---|---|---|---|---|
| 90 | `c_done` | a transfer completes | reach | reach | reach |
| 91 | `c_write_adjacent` | a write ends exactly at the protected window's lower edge (adjacent, not touching) | reach | reach | reach |
| 92 | `c_window_hit` | a descriptor aimed at the window really mutates it (the monitor can fire) | reach | reach | reach |
| 93 | `c_illegal_started` | an illegal descriptor is started (and must stay off the bus) | reach | reach | reach |
| 94 | `c_write_seen` | a write is accepted | reach | reach | reach |
| 95 | `c_src_range_used` | a legal transfer reads and writes (source/destination both used) | reach | reach | reach |

### harness/fv_dma_regs.sv

Jobs: DMA-REG-E0-P1, DMA-REG-E0-P0, DMA-REG-E1-P1

| # | property | statement [spec clause] | REG-E0-P1 | REG-E0-P0 | REG-E1-P1 |
|---|---|---|---|---|---|
| 1 | `a_read_data_model` | register reads return the spec value of every register (cfg, IE, IS, STATUS, INFO, ID, perf, engine status) -- reference model | COND | COND | COND |
| 2 | `a_err_model` | [DMA.md 3] rb_err follows the spec rule of every access (refused busy writes, read-only writes, unmapped offsets, absent perf registers) | COND | COND | COND |
| 3 | `a_idle_bus_quiet` | with rb_sel low the bus answers 0 / no error (no phantom access) | COND | COND | COND |
| 4 | `a_start_def` | [DMA.md 1] start == (write CONTROL.START while not busy), nothing else starts a transfer | COND | COND | COND |
| 5 | `a_abort_def` | [DMA.md 3] abort == (write CONTROL.ABORT), except that a refused START/ABORT write while busy does not abort | COND | COND | COND |
| 6 | `a_busy_refuse_src` | [DMA.md 3] a write to SRC_ADDR while BUSY is refused with an error | COND | COND | COND |
| 7 | `a_busy_refuse_dst` | [DMA.md 3] a write to DST_ADDR while BUSY is refused with an error | COND | COND | COND |
| 8 | `a_busy_refuse_len` | [DMA.md 3] a write to LENGTH while BUSY is refused with an error | COND | COND | COND |
| 9 | `a_busy_refuse_start` | [DMA.md 3] CONTROL.START while BUSY is refused with an error | COND | COND | COND |
| 10 | `a_cfg_frozen_busy` | [DMA.md 3] the descriptor registers never change in a cycle following a BUSY cycle (the active transfer is never modified) | COND | COND | COND |
| 11 | `a_cfg_matches_model` | descriptor outputs == register model (written only by non-busy writes to the three registers) | COND | COND | COND |
| 12 | `a_start_ignored_busy` | [DMA.md 3] no start pulse is generated while BUSY | COND | COND | COND |
| 13 | `a_refused_no_abort` | [DMA.md 3] a refused write (START while busy) has no effect at all, abort included | COND | COND | COND |
| 14 | `a_reset_values` | reset values: descriptor registers 0, no interrupt | COND | COND | COND |
| 15 | `a_irq_level` | [DMA.md 6] irq == /(INT_STATUS & INT_ENABLE), level sensitive (set wins over W1C in the model) | COND | COND | COND |
| 16 | `a_ro_write_err` | [DMA.md 2/3] writes to read-only registers return an error | COND | COND | COND |
| 17 | `a_unmapped_err` | [DMA.md 3] accesses to unmapped offsets return an error | COND | COND | COND |
| 18 | `a_read_no_side_effect` | [DMA.md 3] reads have no side effects: a read never starts or aborts | COND | COND | COND |

| # | cover | purpose | REG-E0-P1 | REG-E0-P0 | REG-E1-P1 |
|---|---|---|---|---|---|
| 90 | `c_start` | a START is accepted | reach | reach | reach |
| 91 | `c_busy_refused` | a busy-state write is refused | reach | reach | reach |
| 92 | `c_set_wins_race` | DONE and a W1C write of INT_STATUS[0] in the same cycle (set-wins race exercised) | reach | reach | reach |
| 93 | `c_irq` | the interrupt line rises | reach | reach | reach |
| 94 | `c_aborted_flag` | STATUS.ABORTED observable | reach | reach | reach |
| 95 | `c_abort_pulse` | an abort pulse is generated | reach | reach | reach |
| 96 | `c_ro_write` | a write to a read-only register is refused | reach | reach | reach |
| 97 | `c_cfg_written` | a descriptor register takes a non-zero value | reach | reach | reach |
| 98 | `c_start_while_busy` | START written while busy (refused) | reach | reach | reach |

### harness/fv_dma_validate.sv

Jobs: DMA-VAL-DW32-L24, DMA-VAL-DW16-L6, DMA-VAL-DW8-L10

| # | property | statement [spec clause] | VAL-DW32-L24 | VAL-DW16-L6 | VAL-DW8-L10 |
|---|---|---|---|---|---|
| 1 | `a_code_matches_spec` | [DMA.md 2] error code == first failing rule of the documented table (40-bit integer reference) | IND | IND | IND |
| 2 | `a_none_iff_legal` | [DMA.md 2] NONE <=> descriptor legal (no rule fails) | IND | IND | IND |
| 3 | `a_code_range` | [DMA.md 2] a validation code is one of 0..7 | IND | IND | IND |
| 4 | `a_ok_len_nonzero` | validated => LENGTH != 0 | IND | IND | IND |
| 5 | `a_ok_len_limit` | validated => LENGTH <= 2^MAX_LEN_LOG2 (descriptor cannot exceed the limit) | IND | IND | IND |
| 6 | `a_ok_aligned` | validated => SRC and DST are DW-aligned | IND | IND | TRIV |
| 7 | `a_ok_src_no_wrap` | validated => src_r + len_r <= 2^32 (source range does not wrap) | IND | IND | IND |
| 8 | `a_ok_dst_no_wrap` | validated => dst_r + len_r <= 2^32 (destination range does not wrap) | IND | IND | IND |
| 9 | `a_ok_disjoint` | validated => source and destination ranges are disjoint (no overlap, incl. src_r == dst_r) | IND | IND | IND |
| 10 | `a_first_failing_wins` | [DMA.md 2] the reported rule fails and every lower-numbered rule passes | IND | IND | IND |
| 11 | `a_zero_len_first` | [DMA.md 2] LENGTH == 0 is always reported as ZERO_LENGTH (rule 1 beats every other rule) | IND | IND | IND |
| 12 | `a_overlap_all_else_ok` | OVERLAP is reported only when rules 1-6 pass (range overlap is the last rule) | IND | IND | IND |

| # | cover | purpose | VAL-DW32-L24 | VAL-DW16-L6 | VAL-DW8-L10 |
|---|---|---|---|---|---|
| 90 | `c_legal` | a legal descriptor exists | reach | reach | reach |
| 91 | `c_zero_len` | ZERO_LENGTH reachable | reach | reach | reach |
| 92 | `c_too_long` | LENGTH reachable | reach | reach | reach |
| 93 | `c_src_align` | SRC_ALIGN reachable (only when DW > 8) | reach | reach | unreach |
| 94 | `c_dst_align` | DST_ALIGN reachable (only when DW > 8) | reach | reach | unreach |
| 95 | `c_src_ovf` | SRC_OVERFLOW reachable | reach | reach | reach |
| 96 | `c_dst_ovf` | DST_OVERFLOW reachable | reach | reach | reach |
| 97 | `c_overlap` | OVERLAP reachable | reach | reach | reach |
| 98 | `c_src_eq_dst` | src_r == dst_r (non-zero length) is rejected as OVERLAP | reach | reach | reach |
| 99 | `c_adjacent_ok` | adjacent but disjoint ranges are accepted (dst_r == src_r + len_r) | reach | reach | reach |

## 5. Assumptions register (every `ALB_ASSUME` in the DMA harnesses)

| id | statement | rationale / source | who discharges it | checked elsewhere? |
|---|---|---|---|---|
| ENV-RST-ANY | reset asserted in step 0 and at any later step, any duration | SFB2 R11: reset cancels in-flight transfers; the strongest reset environment | integration (one reset domain) | n/a |
| ENV-RST-NONE | no reset constraint (`dma_validate` is stateless: every 32-bit descriptor allowed) | exhaustive combinational proof | -- | n/a |
| ENV-SFB-R4 | a held response (valid && !ready) stays valid with unchanged data/error | PROTOCOL R4; the DMA's `rsp_ready` is 1 in WAIT states so a held response cannot occur at the DMA, the rule is still stated for completeness | every SFB2 slave (SRAM slave, crossbar slave port) | asserted for the crossbar master port and the SRAM slave in the DataFabric/SRAM areas |
| ENV-SFB-R5 | a response is only given while an earlier-accepted request is outstanding (never in the acceptance cycle, one per request, in order) | PROTOCOL R5 | every SFB2 slave | same |
| ENV-SFB-R8 | rsp_error => rsp_rdata == 0 | PROTOCOL R8 | every SFB2 slave | same |
| ENV-DMA-SMALL | programmed src,dst < 2^AB and len <= 2^AB (AB = 6) | the engines keep 32-bit address/length counters; PDR cannot close arithmetic relations over them at full width. Narrowing the VALUES lets PDR terminate. **Makes every proof of that job CONDITIONAL**; wrap/overflow is not exercised (c_val_overflow is UNREACHABLE under it) and is covered by the exhaustive `dma_validate` proof | nobody (modelling choice); full-width behaviour is covered only by BMC where noted and by DMA-VAL-* | `DMA-VAL-*` prove the validator at full width |
| ENV-DMA-ENG-1/2/3 | engine never raises DONE and ERROR together; DONE/ERROR only while BUSY; error code <= 10 | needed by the register-file harness, which sees the engine only through its ports | the engines | asserted: `a_done_xor_fail`, `a_terminal_busy`, `a_fail_has_code` in `fv_dma_engine` / `fv_dma_burst` |
| ENV-FIFO-1/2 | no pop while empty; no push while full unless a pop frees the slot | the FIFO's own simulation checks (`dma_fifo.sv`) | the burst engine's credit logic | asserted in `fv_dma_burst`: `a_fifo_le_depth`, `a_credit` (BOUNDED, see section 7) |

`start`, `abort`, `cfg_*`, `req_ready`, `rsp_rdata`, and the register bus are FREE in every harness (the register file's busy protection is deliberately not assumed in the engine proofs).

## 6. Findings

**RTL defects found: none.** No property failed on the unmodified DMA RTL in any configuration (every FAILED entry in `reports/results/DMA-*` would have been
investigated; there is none). This is a statement about the properties and parameter points listed in sections 3-4, not a proof of absence of defects.

Observations (not defects):

* `a_busy_iff_not_idle`, `a_rsp_ready_wait` (simple engine) and `a_rsp_always_taken` (buffered engine) are **TRIVIAL**: `busy`, `rsp_ready` are literal decodes
  of the state / a constant in the RTL, so the optimiser folds the property. They are kept as interface-contract statements (and become non-trivial and FAIL under
  mutation, e.g. MUT-DMA-15) but they carry no proof weight.
* Hard-to-prove properties are hard for a reason: PDR (ABC) closes everything that is an equality between the engine's registers and a *register-for-register ghost
  shadow* (address walk, bytes-done accounting, error addresses, state coherence, protocol stability) but not arithmetic relations between advancing 32-bit
  registers and the latched descriptor (range/wrap/accounting vs LENGTH), not the validation-gating property, and almost nothing of the buffered engine's
  counter-based credit logic. These are reported BOUNDED, never silently promoted.
* DW = 8 is outside the documented SFB2 data widths (PROTOCOL.md: DW in {32, 64, 128}); `dma_burst_engine` forces `OFF = 1` for DW = 8 although `DW/8 = 1`
  (`OFF = (DW > 8) ? $clog2(DW/8) : 1`), which looks inconsistent with beat counting `total_q = (len + SB-1) >> OFF`. **This is an unverified suspicion**: DW = 8
  was not analysed (the harnesses require DW >= 16) and no counterexample exists for it.
* Harness bugs found and fixed while building this area (recorded because they are instructive): (1) history registers with a synchronous reset disagree with the
  asynchronously reset RTL in step 0 (convention C2); (2) a 4-bit tag counter wrapped and produced a spurious `FAIL` on a property that was my mistake, not the RTL's;
  (3) ABC `bmc3` refuses purely combinational networks, so the exhaustive `dma_validate` harness feeds the DUT from registers that sample free inputs.

## 7. What is NOT proved, and why

Reasons (each stated once):

* **R1** -- PDR (budget in the job) found no inductive invariant: the property relates the engine's advancing 32-bit address/length registers to the latched descriptor through adders/comparators (arithmetic relation over many latches). BMC passes to the stated depth, which covers complete multi-beat transfers (c_done / c_multi_beat witnesses are at 7 / 11 frames).
* **R2** -- validation gating: needs the relation between dma_validate's verdict on the engine's own registers and the ghost validator (a function of 96 latches); PDR cannot express it. The validator itself is proved exhaustively at 32-bit width (DMA-VAL-*), the state coherence (no request outside ISSUE states) is proved (a_req_state_coherent), and the gating is checked by BMC.
* **R3** -- the buffered engine keeps 32-bit issue/response counters and a FIFO; the property needs arithmetic invariants over them that PDR did not find within the budget. Observed: with MAX_OUT = 1 (DMA-BRS-S-F2) the stability / ordering / phase / burst-length / outstanding properties ARE proved unboundedly, with MAX_OUT = 2 (the other BRS jobs, also with FIFO_DEPTH 2) they are not: the second outstanding slot makes the counter relations too hard for PDR. BMC passes to the stated depth, which reaches FIFO-full, phase switches and complete transfers (see covers).
* **R4** -- whole-DMA composition (register file + engine + monitors): PDR did not close it in the budget; BMC passes to the stated depth. The component proofs (register model, validator, engine properties) are in the DMA-REG-* / DMA-VAL-* / DMA-ENG-* jobs.

| job | BOUNDED/other properties (depth) -> reason |
|---|---|
| DMA-ENG-DW16-S | R1 (BOUNDED d22): `a_bytes_done_monotone`, `a_bytes_done_prefix`, `a_done_all_consumed`, `a_done_beats_exact`, `a_done_bytes_eq_len`, `a_err_addr_read`, `a_rd_addr_arith`, `a_rd_in_src_range`, `a_rd_no_wrap`, `a_wr_addr_arith`, `a_wr_no_wrap`<br>R2 (BOUNDED d22): `a_done_legal`, `a_fail_code_illegal`, `a_no_req_illegal` |
| DMA-BRS-S-B2 | R3 (BOUNDED d16): `a_burst_le_burst`, `a_bytes_done_ghost`, `a_bytes_done_le_len`, `a_bytes_done_monotone`, `a_credit`, `a_data_integrity`, `a_done_accounting`, `a_end_drained`, `a_err_addr_first_error`, `a_err_code_first_error`, `a_fifo_le_depth`, `a_fifo_occupancy`, `a_no_rd_after_error`, `a_outstanding_bound`, `a_phase_switch_idle`, `a_rd_addr_seq`, `a_rd_in_src_range`, `a_req_stable`, `a_wr_addr_seq`, `a_wr_in_dst_range`, `a_wr_le_good_reads`, `a_wr_strb_exact`, `a_wr_strb_no_overrun`<br>R2 (BOUNDED d16): `a_fail_code_illegal`, `a_no_req_illegal` |
| DMA-BRS-S-B4 | R3 (BOUNDED d16): `a_burst_le_burst`, `a_bytes_done_ghost`, `a_bytes_done_le_len`, `a_bytes_done_monotone`, `a_credit`, `a_data_integrity`, `a_done_accounting`, `a_end_drained`, `a_err_addr_first_error`, `a_err_code_first_error`, `a_fifo_le_depth`, `a_fifo_occupancy`, `a_no_rd_after_error`, `a_outstanding_bound`, `a_phase_switch_idle`, `a_rd_addr_seq`, `a_rd_in_src_range`, `a_req_stable`, `a_wr_addr_seq`, `a_wr_in_dst_range`, `a_wr_le_good_reads`, `a_wr_strb_exact`, `a_wr_strb_no_overrun`<br>R2 (BOUNDED d16): `a_fail_code_illegal`, `a_no_req_illegal` |
| DMA-BRS-S-F2 | R3 (BOUNDED d16): `a_bytes_done_ghost`, `a_bytes_done_le_len`, `a_bytes_done_monotone`, `a_credit`, `a_data_integrity`, `a_done_accounting`, `a_err_addr_first_error`, `a_fifo_le_depth`, `a_fifo_occupancy`, `a_rd_addr_seq`, `a_rd_in_src_range`, `a_wr_addr_seq`, `a_wr_in_dst_range`, `a_wr_le_good_reads`, `a_wr_strb_exact`, `a_wr_strb_no_overrun`<br>R2 (BOUNDED d16): `a_fail_code_illegal`, `a_no_req_illegal` |
| DMA-BRS-D-B2 | R3 (BOUNDED d16): `a_bytes_done_ghost`, `a_bytes_done_le_len`, `a_bytes_done_monotone`, `a_credit`, `a_data_integrity`, `a_done_accounting`, `a_end_drained`, `a_err_addr_first_error`, `a_err_code_first_error`, `a_fail_code_legal`, `a_fifo_le_depth`, `a_fifo_occupancy`, `a_no_rd_after_error`, `a_rd_addr_seq`, `a_req_stable`, `a_wr_addr_seq`, `a_wr_le_good_reads`<br>R2 (BOUNDED d16): `a_fail_code_illegal`, `a_no_req_illegal`<br>R3 (BOUNDED d15): `a_rd_in_src_range`, `a_wr_strb_exact`, `a_wr_strb_no_overrun`<br>R3 (BOUNDED d14): `a_wr_in_dst_range` |
| DMA-PROT-E0 | R4 (BOUNDED d16): `a_illegal_no_bus`, `a_illegal_no_mem_write`, `a_source_untouched` |
| DMA-PROT-E1S | R4 (BOUNDED d16): `a_illegal_no_mem_write`, `a_prot_window_clean`, `a_source_untouched`, `a_write_inside_dst` |
| DMA-PROT-E1D | R4 (BOUNDED d16): `a_prot_window_clean`, `a_source_untouched`, `a_write_inside_dst` |
| DMA-ENG-DW32-S | R1 (BOUNDED d18): `a_bytes_done_monotone`, `a_bytes_done_prefix`, `a_done_all_consumed`, `a_done_beats_exact`, `a_done_bytes_eq_len`, `a_err_addr_read`, `a_rd_addr_arith`, `a_rd_no_wrap`, `a_wr_addr_arith`, `a_wr_beat_one_ahead`, `a_wr_no_wrap`<br>R2 (BOUNDED d18): `a_done_legal`, `a_fail_code_illegal`, `a_no_req_illegal` |
| DMA-BRS-S-F2-M2 | R3 (BOUNDED d16): `a_burst_le_burst`, `a_bytes_done_ghost`, `a_bytes_done_le_len`, `a_bytes_done_monotone`, `a_credit`, `a_data_integrity`, `a_done_accounting`, `a_end_drained`, `a_err_addr_first_error`, `a_err_code_first_error`, `a_fifo_le_depth`, `a_fifo_occupancy`, `a_no_rd_after_error`, `a_outstanding_bound`, `a_phase_switch_idle`, `a_rd_addr_seq`, `a_rd_in_src_range`, `a_req_stable`, `a_wr_addr_seq`, `a_wr_in_dst_range`, `a_wr_le_good_reads`, `a_wr_strb_exact`, `a_wr_strb_no_overrun`<br>R2 (BOUNDED d16): `a_fail_code_illegal`, `a_no_req_illegal` |

Claims of record for the DMA that this area does **not** prove (also listed in the global ledger):

| claim | status | reason |
|---|---|---|
| eventual completion of every started transfer (liveness) | **not claimed** | needs fairness / bounded-latency of the slave (`albion_sfb_lat_mon`) and a proof; DMA.md states there is no watchdog. Only `c_done` (a completing trace exists) is shown. |
| unbounded proofs at full 32-bit address/length width for the engines | UNPROVEN | the engine proofs are CONDITIONAL on ENV-DMA-SMALL (values < 2^6); full-width variants of the jobs are not run. Wrap/overflow is covered exhaustively but only for the *validator* (DMA-VAL-*). |
| range/wrap/accounting properties of the engines at unbounded depth | BOUNDED | arithmetic relations over advancing 32-bit registers; PDR budget exhausted (see section 7). |
| validation gating of the bus (illegal descriptor => no request) at unbounded depth | PARTIAL | PROVED unboundedly for the complete DMA with the buffered engine (`a_illegal_no_bus` in DMA-PROT-E1S / E1D, `a_illegal_no_mem_write` in E1D); BOUNDED for the simple engine (DMA-ENG-*, DMA-PROT-E0) and for the engine-level gating properties of the buffered engine; the validator itself and the state coherence are proved. |
| buffered-engine credit / FIFO-level / MAX_OUT / burst-length bounds at unbounded depth | BOUNDED | engine counters are 32-bit; `dma_fifo` itself is proved (DMA-FIFO-*) under its usage contract, the engine's compliance with that contract is bounded. |
| multi-channel / descriptor chains / rings | not applicable | the RTL has one channel and one descriptor (three registers). |
| 4 KiB / page-boundary rule | not applicable | no such rule exists in the RTL or spec; "burst boundary" is the `BURST` phase length. |
| DW = 8 and DW in {64, 128} | not analysed | engine/regs jobs run DW 16/32 only (validator DW 8/16/32). |
| FIFO_DEPTH > 4 for the engine, MAX_OUT > 2, BURST > 4 | not analysed | cost; the logic is count-generic but that is an argument, not a proof. |
| protection by the SoC (crossbar access matrix, Citadel) | outside this area | the DMA has none of its own (DMA.md); see the DataFabric and Security areas. |
| CDC, gate level, timing | out of scope | single-clock RTL formal only. |

## 8. Mutation campaign (controlled bugs, `mutants/dma.json`)

40 mutants: **37 killed**, 3 survived (argued equivalent: 3), 40 total.

| mutant | RTL file | bug modelled | status | killed by |
|---|---|---|---|---|
| MUT-DMA-01 | dma_validate.sv | off-by-one in the LENGTH limit (len == 2^MAX_LEN_LOG2 wrongly rejected) | KILLED | DMA-VAL-DW16-L6/a_code_matches_spec, DMA-VAL-DW16-L6/a_none_iff_legal, DMA-VAL-DW32-L24/a_code_matches_spec |
| MUT-DMA-02 | dma_validate.sv | overlap check missing: overlapping descriptors accepted (memmove semantics not implemented) | KILLED | DMA-VAL-DW16-L6/a_ok_disjoint, DMA-VAL-DW16-L6/a_code_matches_spec, DMA-VAL-DW32-L24/a_ok_disjoint |
| MUT-DMA-03 | dma_validate.sv | off-by-one in the source wrap check (src+len == 2^32 wrongly rejected) | KILLED | DMA-VAL-DW16-L6/a_code_matches_spec, DMA-VAL-DW16-L6/a_none_iff_legal, DMA-VAL-DW32-L24/a_code_matches_spec |
| MUT-DMA-04 | dma_validate.sv | destination wrap check one byte too lax (dst+len == 2^32+1 accepted) | KILLED | DMA-VAL-DW16-L6/a_ok_dst_no_wrap, DMA-VAL-DW16-L6/a_code_matches_spec, DMA-VAL-DW32-L24/a_ok_dst_no_wrap |
| MUT-DMA-05 | dma_validate.sv | overlap test uses <= : adjacent ranges (dst + len == src) wrongly rejected | KILLED | DMA-VAL-DW16-L6/a_code_matches_spec, DMA-VAL-DW16-L6/a_none_iff_legal, DMA-VAL-DW32-L24/a_code_matches_spec |
| MUT-DMA-06 | dma_validate.sv | wrong error code: source misalignment reported as DST_ALIGN | KILLED | DMA-VAL-DW16-L6/a_code_matches_spec, DMA-VAL-DW32-L24/a_code_matches_spec |
| MUT-DMA-07 | dma_transfer_engine.sv | tail strobe ignored: the final partial word is written in full (bytes after LENGTH modified) | KILLED | DMA-ENG-DW16-S/a_wr_strb_exact, DMA-ENG-DW16-S/a_wr_strb_no_overrun |
| MUT-DMA-08 | dma_transfer_engine.sv | accounting error: a partial last beat counts a full word in bytes_done | KILLED | DMA-ENG-DW16-S/a_bytes_done_ghost, DMA-ENG-DW16-S/a_done_bytes_eq_len |
| MUT-DMA-09 | dma_transfer_engine.sv | abort ignored (never latched) | KILLED | DMA-ENG-DW16-S/a_abort_no_new_request |
| MUT-DMA-10 | dma_transfer_engine.sv | off-by-one in last-beat detection: a transfer whose length is a multiple of DW/8 gets an extra beat | KILLED | DMA-ENG-DW16-S/a_beat_counters_valid |
| MUT-DMA-11 | dma_transfer_engine.sv | validation result ignored: illegal descriptors go onto the bus | KILLED | DMA-ENG-DW16-S/a_no_req_illegal, DMA-ENG-DW16-S/a_fail_code_illegal |
| MUT-DMA-12 | dma_transfer_engine.sv | a read error is ignored: a write is issued with data from a failed read | KILLED | DMA-ENG-DW16-S/a_wr_after_good_read, DMA-ENG-DW16-S/a_no_req_after_error |
| MUT-DMA-13 | dma_transfer_engine.sv | req_valid not reset: a request can appear after reset without a START | KILLED | DMA-ENG-DW16-S/a_reset_state |
| MUT-DMA-14 | dma_transfer_engine.sv | wrong error code: a write error is reported as READ_BUS | KILLED | DMA-ENG-DW16-S/a_err_addr_read |
| MUT-DMA-15 | dma_transfer_engine.sv | write responses are never accepted (rsp_ready low in WAIT_WRITE) | KILLED | DMA-ENG-DW16-S/a_rsp_ready_wait, DMA-ENG-DW16-S/a_rsp_always_taken |
| MUT-DMA-16 | dma_transfer_engine.sv | bytes_done not cleared at START: stale count from the previous transfer | KILLED | DMA-ENG-DW16-S/a_bytes_done_ghost, DMA-ENG-DW16-S/a_bytes_done_le_len |
| MUT-DMA-20 | dma_burst_engine.sv | FIFO credit off-by-one: one read too many in flight -> FIFO overflow | KILLED | DMA-BRS-D-B2/a_credit, DMA-BRS-D-B2/a_fifo_le_depth |
| MUT-DMA-21 | dma_burst_engine.sv | MAX_OUT bound off-by-one on the read side | KILLED | DMA-BRS-D-B2/a_outstanding_bound, DMA-BRS-S-B4/a_outstanding_bound |
| MUT-DMA-22 | dma_burst_engine.sv | BURST limit off-by-one in the read phase (BURST+1 reads per phase) | KILLED | DMA-BRS-S-B2/a_burst_le_burst |
| MUT-DMA-23 | dma_burst_engine.sv | BURST limit off-by-one in the write phase | SURVIVED (equivalent: ARGUED equivalent (not machine-checked; the supporting invariant `fifo_level <= BURST` in single-port mode is not asserted in this suite): in single-port mode a write phase never has more than BURST beats available -- a read phase pushes at most BURST beats, phases change only when idle, and a write phase drains them (BURST >= level), so the leftover at the start of a write phase is 0 (non-zero only after an error/abort, which stops writes). The write-phase limit `bcnt_n < BURST` is therefore never the binding constraint and `<=` is unobservable. c_fifo_full is UNREACHED in DMA-BRS-S-B2 (BURST 2 < FIFO 4), consistent with this.) |  |
| MUT-DMA-24 | dma_burst_engine.sv | phase switches while transactions are outstanding (responses attributed to the wrong phase) | KILLED | DMA-BRS-S-B2/a_phase_switch_idle |
| MUT-DMA-25 | dma_burst_engine.sv | one write too many is issued (beyond the last beat / beyond the good reads) | SURVIVED (equivalent: ARGUED equivalent (not machine-checked): `wr_iss_n < wr_limit_n` is redundant with the FIFO-non-empty guard `fcnt_n != 0` in `can_wr`: the FIFO count is pushes - pops, pushes never exceed total beats (or `rd_ok_n` after a stop, which is exactly what wr_limit_n is), so whenever wr_iss_n == wr_limit_n the FIFO is empty and `fcnt_n != 0` already blocks the extra write.) |  |
| MUT-DMA-26 | dma_burst_engine.sv | single port: tail strobe ignored on the final write | KILLED | DMA-BRS-S-B2/a_wr_strb_exact, DMA-BRS-S-B2/a_wr_strb_no_overrun |
| MUT-DMA-27 | dma_burst_engine.sv | data of reads that returned after a stop condition is still pushed into the FIFO | KILLED | DMA-BRS-S-B2/a_fifo_occupancy, DMA-BRS-S-B2/a_wr_le_good_reads, DMA-BRS-D-B2/a_fifo_occupancy |
| MUT-DMA-28 | dma_burst_engine.sv | bytes_done keeps counting after a write error (not a contiguous prefix) | KILLED | DMA-BRS-S-B2/a_bytes_done_ghost, DMA-BRS-D-B2/a_bytes_done_ghost |
| MUT-DMA-29 | dma_burst_engine.sv | abort does not stop write issue | KILLED | DMA-BRS-S-B2/a_abort_no_new_req |
| MUT-DMA-30 | dma_burst_engine.sv | wrong error code: a write error is reported as READ_BUS | KILLED | DMA-BRS-S-B2/a_err_code_first_error |
| MUT-DMA-31 | dma_burst_engine.sv | ERROR_ADDR of a write error is one beat too far | KILLED | DMA-BRS-S-B2/a_err_addr_first_error |
| MUT-DMA-32 | dma_burst_engine.sv | FIFO never cleared between transfers: leftover beats of an aborted/failed transfer leak into the next one | KILLED | DMA-BRS-S-B2/a_fifo_occupancy |
| MUT-DMA-33 | dma_burst_engine.sv | abort_q never set | SURVIVED (equivalent: EQUIVALENT: abort_q is redundant with the rd_stop_q / wr_stop_q latches, which capture the same live `abort` in the same cycle (rd_stop_n/wr_stop_n include `abort`); abort_q only re-ORs a value that is already latched, so no output can differ) |  |
| MUT-DMA-34 | dma_fifo.sv | FIFO write pointer advances by 2 | KILLED | DMA-FIFO-D4W8/a_count_matches, DMA-FIFO-D4W8/a_fifo_order |
| MUT-DMA-40 | dma_control_regs.sv | busy-state protection removed: descriptor registers change while a transfer runs | KILLED | DMA-REG-E0-P1/a_cfg_frozen_busy, DMA-REG-E0-P1/a_cfg_matches_model |
| MUT-DMA-41 | dma_control_regs.sv | a busy-time write to SRC_ADDR is no longer refused (error response lost; the write itself is still blocked) | KILLED | DMA-REG-E0-P1/a_busy_refuse_src, DMA-REG-E0-P1/a_err_model |
| MUT-DMA-42 | dma_irq.sv | clear wins over a same-cycle event (set-wins violated: a completion can be lost) | KILLED | DMA-REG-E0-P1/a_irq_level, DMA-REG-E0-P1/a_read_data_model |
| MUT-DMA-43 | dma_control_regs.sv | START while busy is accepted | KILLED | DMA-REG-E0-P1/a_start_def, DMA-REG-E0-P1/a_start_ignored_busy |
| MUT-DMA-44 | dma_control_regs.sv | a refused START/ABORT write still aborts | KILLED | DMA-REG-E0-P1/a_abort_def, DMA-REG-E0-P1/a_refused_no_abort |
| MUT-DMA-45 | dma_control_regs.sv | cfg_len is not reset | KILLED | DMA-REG-E0-P1/a_reset_values, DMA-REG-E0-P1/a_cfg_matches_model |
| MUT-DMA-46 | dma_control_regs.sv | STATUS.DONE/ERROR/ABORTED flags not cleared at START (stale outcome) | KILLED | DMA-REG-E0-P1/a_read_data_model |
| MUT-DMA-47 | dma_control_regs.sv | a write to the read-only ID register is silently accepted | KILLED | DMA-REG-E0-P1/a_ro_write_err, DMA-REG-E0-P1/a_err_model |
| MUT-DMA-50 | dma_transfer_engine.sv | destination address off by one word: the DMA writes past the programmed range (can reach a protected window) | KILLED | DMA-PROT-E0/a_write_inside_dst, DMA-PROT-E0/a_prot_window_clean |

## 9. Harness limitations and tool notes

* **Narrow values (ENV-DMA-SMALL)** for every engine/integration job: results are conditional on it; DMA-VAL-* is the only full-width evidence.
* **Ghost model from ports only** (descriptor captured at START, counters from OK responses). It re-states the spec, but several ghost updates (e.g. the expected-next-address
  registers) have the same *shape* as the RTL's own updates; their value is in being driven by the externally visible events, and in being checked against the
  byte-/beat-exact spec statements (`a_*_arith`, `a_*_in_*_range`, `a_wr_strb_*`) at least to BMC depth. Mutation (section 8) is the check that these are not tautologies.
* **Memory model** in `fv_dma_prot` is an arbitrary SFB2 slave plus a mutation monitor (accepted write = bytes mutated); no storage array. Conservative for the stated properties.
* **Depths.** Simple engine DMA-ENG-*: BMC depth 22 (DW16) / 18 (DW32); burst/integration jobs: depth 16. Witness depths of the covers (3-11 frames for complete, multi-beat,
  error and abort transfers) show the bounded checks do exercise those behaviours; deeper behaviour (long bursts, many beats, many back-pressure cycles) is not covered by BOUNDED rows.
* **PDR budgets are wall-clock** (`abc pdr -T`): a borderline property can flip between PROVED and BOUNDED under heavy machine load (observed: `a_rd_in_src_range`, `a_rd_no_wrap`
  between two runs). The job budgets were raised until the recorded classes were stable across the final run; classes in the ledger are those of the final run.
* **Counterexample waveforms** (none for the DMA baseline) are produced by the runner; mutation counterexamples are under `reports/mutation/counterexamples/`.
* SymbiYosys was not available; the engines are driven directly (see the global methodology).

