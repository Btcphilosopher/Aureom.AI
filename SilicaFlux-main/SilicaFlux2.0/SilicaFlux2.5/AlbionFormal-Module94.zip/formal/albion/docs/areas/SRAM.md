# AlbionFormal -- SRAM area (jobs `SRAM-*`)

Formal verification of the SilicaFlux SRAM stack: the single-port wrapper `sram_sp` (with its response path and the GENERIC array),
the SFB2 slave adapter `sfb_sram_slave`, and the **protection mechanism that actually exists in the RTL for protected addresses**
(`cc_secmon` host lock + `cc_sfb_gate`, composed with the SRAM). Every number below is produced by `tools/albion_formal.py` from
`reports/results/` (generated tables are marked); nothing is typed in. Tools: Yosys 0.33, ABC (`bmc3`, `pdr`), z3; SymbiYosys is not installed.

## 1  Scope and RTL under test (pinned, `rtl_under_test/MANIFEST.json`)

| RTL | file | role |
|---|---|---|
| `sram_sp` | `datafabric/third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv` | handshake single-port SRAM wrapper (request decode, array mux, test port) |
| `sram_rsp_path` | `.../sram_rsp_path.sv` | tag pipeline + response FIFO with credit accounting |
| `sram_backend_1rw` / `sram_generic_1rw` | `.../sram_backend_1rw.sv`, `.../backends/generic/sram_generic_1rw.sv` | array selector / GENERIC array (SYNTHESIS branch) |
| `sfb_sram_slave` | `datafabric/rtl/mem/sfb_sram_slave.sv` | SFB2 slave adapter on `sram_sp` (WRITE_ACK = 1) |
| `cc_sfb_gate` | `controlcore/rtl/cc_sfb_gate.sv` | SFB2 pass-through that can refuse (host write lock / isolation) |
| `cc_secmon` | `controlcore/rtl/cc_secmon.sv` | security status: `HOST_LOCK` (set-only), `BOOT_MEASURE` (write-once) |

Specifications used: `sram_sp` header, `docs/mem/01_interface_spec.md` (sections 2-4, 8, 9), `docs/datafabric/PROTOCOL.md` R2/R4/R5/R7/R8/R10/R11,
`cc_sfb_gate` / `cc_secmon` headers and `cc_memmap_defs.svh`. Models are written from these documents, never fitted to the RTL.

## 2  Mapping decisions (where the brief's wording does not match the RTL)

| Brief item | What the RTL has | What is proved |
|---|---|---|
| "No illegal write enable" | `sram_sp` drives `ce/we/wmask/addr/wdata` into the array; no named "write enable" port | the array-boundary signals themselves are observed (tap shim, section 3) and proved equal to the specification: array write only for an accepted valid functional write or a test-port write, never for `addr >= DEPTH`, never in reset / the cycle after, never for an accepted functional request in test mode |
| "Protected addresses reject unauthorised writes" | **`sram_sp` and `sfb_sram_slave` have no protection or permission concept.** The protection that exists is the ControlCore host write lock: `cc_secmon.host_lock` (set-only until reset) feeding the `refuse` input of `cc_sfb_gate` in front of the memory | proved for the composition `cc_secmon -> cc_sfb_gate -> sfb_sram_slave -> array` with `refuse = host_lock && write && address in protected window`, exactly the expression `silicaflux_control_core.sv` uses for its host gate (`host_refuse`). The window is the word range `[PLO, DEPTH)`. The Citadel domain permission checker belongs to the Security area |
| "Transaction identifiers remain valid" | `sram_sp` carries `req_id -> rsp_id` (ID_WIDTH); `sfb_sram_slave` fixes `ID_WIDTH = 1` and hides it (SFB2 rev 2.0 has no IDs) | `rsp_id` equals the `req_id` of the matching request, in order, under back-pressure (ID_WIDTH = 2); for the adapter, the in-order one-response-per-request property |
| "Reset establishes documented control states" | spec: control/status/output-valid registers reset asynchronously; `req_ready = 0` in reset and the cycle after; array not reset | `req_ready = 0` in reset and the cycle after; `rsp_valid = 0`, `busy = 0`, nothing outstanding; reset cancels in-flight responses; the scoreboard never claims a value for lanes it has not seen since reset (array content is unconstrained) |
| "Unwritten bytes remain unchanged" | the array has no defined content, so "unchanged" cannot be checked against a known value | **learning scoreboard**: the first read of a never-written lane teaches its value; every later read must return it, whatever else is written to the word (`a_array_unwritten_stable`, `a_raw_lanes`) |

## 3  Method specifics

* **Tap shim** (`harness/shim_sram_backend.sv`, guide C7). The array boundary is internal and Yosys 0.33 has no hierarchical references -- an `a.b.c`
  reference silently becomes an undriven wire (measured), so it was never used. A shim named `sram_backend_1rw` replaces the selector: with `TAP = 0` it
  instantiates the real `sram_generic_1rw`; with `TAP = 1` it presents its own control inputs on `rdata`, which `sram_sp` forwards to `tst_rdata`
  (TEST_EN = 1), so the harness reads the array controls of the **real** `sram_sp` in the same cycle. `defparam <instance path>.TAP` selects the mode
  (it works through nested instances). Not covered: the selector's own generate logic (FPGA/ASIC branches).
* **Single symbolic address** (`(* anyconst *) ta`). The scoreboard (`env/albion_sram_sb.sv`) follows one word, with a per-byte-lane `known` flag and value.
  A proof for every `ta` is a proof for every address; cross-address corruption (a write that disturbs another word) is caught when `ta` is the disturbed word.
* **Exact response timing.** The response queue models the documented contract exactly: `rsp_valid <=> head exists and has aged >= READ_LATENCY`.
  "Never early, never dropped, never duplicated, never unsolicited, in order, posted writes silent, errors never silent" is one property (`a_rsp_valid_exact`)
  plus payload checks; this is a safety statement, not liveness.
* **Raw check.** The array output (`tst_rdata`) is compared with the shadow exactly READ_LATENCY cycles after each array read, and the response data is completed from that same
  array output ("fill"), so responses are tied to what the array actually returned.
* **Harness history registers use asynchronous reset** like the RTL (convention C2). A flag that is async-cleared cannot witness "reset while X": covers
  that need the previous cycle use a non-reset register (this was a harness bug found and fixed twice during development).

## 4  Jobs and results at delivery (generated from `reports/results/`)

Classes: PROVED = unbounded proof by ABC PDR (INDUCTIVE if only reset/clock assumed, CONDITIONAL if other assumptions listed in the job); covers are compiled as 'never' assertions: REACHED = witness found, UNREACHABLE = proved never. All proofs are *under the assumptions listed per job* (section 6).

| job | RTL module | parameters | assertions | PROVED (INDUCTIVE/COND.) | BOUNDED | FAILED | TRIVIAL/N-A | covers (reached / unreachable / other) |
|---|---|---|---|---|---|---|---|---|
| SRAM-CTRL-D4L1W1 | sram_sp (control) | DW=16, MW=2, DEPTH=4, LAT=1, FIFO=2, WACK=1, IDW=2 | 12 | 11 | 0 | 0 | 1 | 6 / 2 / 0 |
| SRAM-CTRL-D6L2W0 | sram_sp (control) | DW=16, MW=2, DEPTH=6, LAT=2, FIFO=3, WACK=0, IDW=2 | 12 | 9 | 0 | 0 | 3 | 8 / 0 / 0 |
| SRAM-ARR-D4L1 | sram_generic_1rw | DW=16, MW=2, DEPTH=4, LAT=1 | 3 | 3 | 0 | 0 | 0 | 5 / 0 / 0 |
| SRAM-ARR-D6L2 | sram_generic_1rw | DW=16, MW=2, DEPTH=6, LAT=2 | 3 | 3 | 0 | 0 | 0 | 5 / 0 / 0 |
| SRAM-ARR-D4L3 | sram_generic_1rw | DW=16, MW=2, DEPTH=4, LAT=3 | 3 | 3 | 0 | 0 | 0 | 5 / 0 / 0 |
| SRAM-ARR-W32D4L1 | sram_generic_1rw | DW=32, MW=4, DEPTH=4, LAT=1 | 3 | 3 | 0 | 0 | 0 | 5 / 0 / 0 |
| SRAM-SFB-D4L1 | sfb_sram_slave | DW=16, DEPTH=4, LAT=1, ASSUME_R2=1 | 10 | 10 | 0 | 0 | 0 | 9 / 1 / 0 |
| SRAM-SFB-D4L2 | sfb_sram_slave | DW=16, DEPTH=4, LAT=2, ASSUME_R2=1 | 10 | 10 | 0 | 0 | 0 | 9 / 1 / 0 |
| SRAM-SFB-D6L1-NOR2 | sfb_sram_slave | DW=16, DEPTH=6, LAT=1, ASSUME_R2=0 | 10 | 10 | 0 | 0 | 0 | 10 / 0 / 0 |
| SRAM-GATE | cc_sfb_gate | - | 15 | 13 | 0 | 1 | 1 | 8 / 0 / 0 |
| SRAM-SECMON | cc_secmon | - | 9 | 9 | 0 | 0 | 0 | 6 / 0 / 0 |
| SRAM-PROT-TAP-D4P2 | cc_secmon+cc_sfb_gate+sfb_sram_slave | DEPTH=4, LAT=1, PLO=2 | 6 | 5 | 0 | 1 | 0 | 7 / 0 / 0 |
| SRAM-PROT-TAP-D4P1L2 | cc_secmon+cc_sfb_gate+sfb_sram_slave | DEPTH=4, LAT=2, PLO=1 | 6 | 5 | 0 | 1 | 0 | 7 / 0 / 0 |
| SRAM-PROT-WORD-D4P2 | cc_secmon+cc_sfb_gate+sfb_sram_slave | DEPTH=4, LAT=1, PLO=2 | 3 | 3 | 0 | 0 | 0 | 6 / 0 / 0 |
| SRAM-CTRL-D4L1W0 | sram_sp (control) | DW=16, MW=2, DEPTH=4, LAT=1, FIFO=2, WACK=0, IDW=2 | 12 | 12 | 0 | 0 | 0 | 6 / 2 / 0 |
| SRAM-CTRL-W32D6 | sram_sp (control) | DW=32, MW=4, DEPTH=6, LAT=1, FIFO=2, WACK=1, IDW=2 | 12 | 11 | 0 | 0 | 1 | 8 / 0 / 0 |
| SRAM-DATA-D4L1W1 | sram_sp (data/timing) | DW=16, MW=2, DEPTH=4, LAT=1, FIFO=2, WACK=1, IDW=2 | 14 | 14 | 0 | 0 | 0 | 10 / 1 / 0 |
| SRAM-DATA-D6L1W1 | sram_sp (data/timing) | DW=16, MW=2, DEPTH=6, LAT=1, FIFO=2, WACK=1, IDW=2 | 14 | 14 | 0 | 0 | 0 | 11 / 0 / 0 |
| SRAM-DATA-D4L1W0 | sram_sp (data/timing) | DW=16, MW=2, DEPTH=4, LAT=1, FIFO=2, WACK=0, IDW=2 | 14 | 14 | 0 | 0 | 0 | 10 / 1 / 0 |
| SRAM-DATA-W8D6L2W0 | sram_sp (data/timing) | DW=8, MW=2, DEPTH=6, LAT=2, FIFO=3, WACK=0, IDW=2 | 14 | 14 | 0 | 0 | 0 | 11 / 0 / 0 |
| SRAM-DATA-W8D4L2F0 | sram_sp (data/timing) | DW=8, MW=2, DEPTH=4, LAT=2, FIFO=0, WACK=1, IDW=2 | 14 | 13 | 0 | 0 | 1 | 9 / 2 / 0 |

Totals: A:FAIL=3, A:N/A=3, A:PROVED=189, A:TRIVIAL=4, C:REACHED=161, C:UNREACHABLE=10


### Results that are not a plain PROVED (every one is a recorded expectation in `proofs/sram.json`)

| job | property | result | why |
|---|---|---|---|
| SRAM-CTRL-D4L1W1 | `a_ready_posted_write` | N/A | applies to WRITE_ACK = 0 only (posted writes) |
| SRAM-CTRL-D6L2W0 | `a_ce_exact` | TRIVIAL | STRUCTURAL: after elaboration the optimiser identifies the DUT's array-control net with the spec expression (the RTL computes exactly the specified function), so the equality folds to constant true. Not vacuous: when the RTL deviates the cell stays live and fails (mutants MUT-SRAM-01/02/04/18 show this on the neighbouring properties). |
| SRAM-CTRL-D6L2W0 | `a_we_exact` | TRIVIAL | STRUCTURAL: after elaboration the optimiser identifies the DUT's array-control net with the spec expression (the RTL computes exactly the specified function), so the equality folds to constant true. Not vacuous: when the RTL deviates the cell stays live and fails (mutants MUT-SRAM-01/02/04/18 show this on the neighbouring properties). |
| SRAM-CTRL-D6L2W0 | `a_wmask_exact` | TRIVIAL | STRUCTURAL: after elaboration the optimiser identifies the DUT's array-control net with the spec expression (the RTL computes exactly the specified function), so the equality folds to constant true. Not vacuous: when the RTL deviates the cell stays live and fails (mutants MUT-SRAM-01/02/04/18 show this on the neighbouring properties). |
| SRAM-GATE | `a_payload_identity` | TRIVIAL | STRUCTURAL: the master-side payload is a pure wire copy of the slave-side payload (assign m_req_* = s_req_*), so the identity folds to constant true; a mutant that touches the payload makes it live. |
| SRAM-GATE | `a_reset_no_forward` | FAIL | FINDING SRAM-F2: cc_sfb_gate does not gate m_req_valid with reset (same class as DF-F1 for the crossbar); benign only if every master/slave shares the reset (PROTOCOL R11 premise) |
| SRAM-PROT-TAP-D4P2 | `a_prot_stale_after_lock` | FAIL | FINDING SRAM-F1: a protected write first presented while unlocked, then stalled downstream (e.g. SRAM in test mode / right after reset), is still performed after host_lock is set (cc_sfb_gate never withdraws a presented request: pend_q). Documented gate behaviour; the host lock therefore guarantees 'no protected write FIRST PRESENTED after the lock', not 'no protected write after the lock'. |
| SRAM-PROT-TAP-D4P1L2 | `a_prot_stale_after_lock` | FAIL | FINDING SRAM-F1: a protected write first presented while unlocked, then stalled downstream (e.g. SRAM in test mode / right after reset), is still performed after host_lock is set (cc_sfb_gate never withdraws a presented request: pend_q). Documented gate behaviour; the host lock therefore guarantees 'no protected write FIRST PRESENTED after the lock', not 'no protected write after the lock'. |
| SRAM-CTRL-W32D6 | `a_ready_posted_write` | N/A | applies to WRITE_ACK = 0 only (posted writes) |
| SRAM-DATA-W8D4L2F0 | `a_ready_exact` | N/A | RSP_FIFO_DEPTH = 0 has no credit counter (can_issue = live); the exact-ready property is defined for FIFO > 0 only |


## 5  Property catalogue (generated from the harness sources)

#### sram_sp array-boundary control (TAP shim)  (`harness/fv_sram_sp_ctrl.sv`)

| id | property | statement |
|---|---|---|
| A1 | `a_ce_exact` | [spec 2,8] array enable == (test mode: tst_ce on a valid test address) / (functional: accepted request with a valid address) |
| A2 | `a_wen_legal` | no illegal write enable: array ce&&we only for an accepted valid functional write, or a test-port write |
| A3 | `a_no_oob_access` | [spec 2] an out-of-range address (addr >= DEPTH) never reaches the array (read or write) |
| A4 | `a_we_exact` | array we follows the functional req_we (test mode: tst_we); a read never sets we |
| A5 | `a_read_no_we` | an accepted functional read with a valid address performs an array READ (ce=1, we=0) |
| A6 | `a_wmask_exact` | write lanes: functional wmask passes through; test writes cover all lanes [spec 8] |
| A7 | `a_addr_data_passthru` | array address and write data are the request's (test port's in test mode) |
| A8 | `a_no_func_access_in_reset` | no functional array access in reset or the cycle after it |
| A9 | `a_ready_low_reset` | [spec 4] req_ready = 0 in reset and the cycle after |
| A10 | `a_ready_low_test` | [spec 4,8] req_ready = 0 while tst_active (functional requests are never accepted in test mode) |
| A11 | `a_invalid_no_array` | [spec 2] an accepted invalid-address request never touches the array |
| A12 | `a_ready_posted_write` | [spec 4] a posted valid write needs no response credit: req_ready = 1 whenever live and not in test mode (WRITE_ACK = 0) |

#### sram_sp data/timing/ordering  (`harness/fv_sram_sp_data.sv`)

| id | property | statement |
|---|---|---|
| A20 | `a_raw_lanes` | [spec 2,3,8,9] array output exactly READ_LATENCY after a read equals the shadow on every known lane: masked writes change only their lanes; never-written lanes stay unchanged |
| A21 | `a_rsp_valid_exact` | [spec 4] rsp_valid <=> the oldest outstanding request has aged >= READ_LATENCY: never early, never dropped, never unsolicited, never duplicated; posted valid writes (WRITE_ACK=0) produce no response |
| A22 | `a_rsp_err` | [spec 2] rsp_err is set exactly for out-of-range addresses (also for posted writes: errors are never silent) |
| A23 | `a_rsp_we` | [spec 4] rsp_we marks the response of a write request |
| A24 | `a_rsp_id` | [spec 4] rsp_id equals the req_id of the request the response belongs to (transaction identifiers stay valid, in order) |
| A25 | `a_rsp_zero` | [spec 4] read data of write acknowledgements and error responses is all-zero |
| A26 | `a_rsp_data` | [spec 3,4] read response data = shadow word (known lanes) -- also under response back-pressure |
| A27 | `a_credit_bound` | [spec 4] outstanding responses never exceed RSP_FIFO_DEPTH: the response FIFO cannot overflow |
| A28 | `a_rsp_stable` | [spec 4] rsp_* hold stable while rsp_valid && !rsp_ready |
| A29 | `a_busy_exact` | busy == (some response outstanding) |
| A30 | `a_reset_state` | [spec 1,4] reset: req_ready = 0, rsp_valid = 0, busy = 0 (control state cleared; array not touched) |
| A31 | `a_ready_exact` | [spec 4] req_ready <=> not test mode && live && (a response credit is free // the request needs no response) |
| A32 | `a_ready_low_reset` | [spec 4] req_ready = 0 in reset and the cycle after |
| A33 | `a_ready_low_test` | [spec 4,8] req_ready = 0 in test mode |

#### sram_generic_1rw raw array  (`harness/fv_sram_array.sv`)

| id | property | statement |
|---|---|---|
| A1 | `a_array_lanes` | [spec 3.2,3.3] data read EXACTLY READ_LATENCY cycles after the read edge equals the shadow on every known lane (writes, masked writes, unwritten lanes) |
| A2 | `a_array_written_lanes` | [spec 3.2] lanes written with wmask=1 return the last value written; a later write with wmask=0 on that lane leaves it unchanged |
| A3 | `a_array_unwritten_stable` | [spec 3.2] bytes that no write ever touched remain unchanged: two reads of such a lane return the same value, whatever else is written to the word |

#### sfb_sram_slave adapter  (`harness/fv_sram_sfb.sv`)

| id | property | statement |
|---|---|---|
| A20 | `a_sfb_array_lanes` | [R7,R10] the array holds exactly what the strobed writes put there: reads return the shadow on every known lane, masked lanes untouched, never-written lanes unchanged |
| A21 | `a_sfb_rsp_exact` | [R5,R7] exactly one response per accepted request, in order, >= READ_LATENCY (>= 1) cycles after acceptance, never unsolicited, dropped or duplicated; a write is answered only after its array write edge |
| A22 | `a_sfb_rsp_error` | [R8] rsp_error exactly for out-of-range SRAM words (non-power-of-two DEPTH) |
| A23 | `a_sfb_rsp_zero` | [R8] error responses and write responses carry rsp_rdata = 0 |
| A24 | `a_sfb_rsp_data` | [R7,R10] read data = the word as written by every earlier accepted write (word address = req_addr[OFF +: AW]) |
| A25 | `a_sfb_rsp_stable` | [R4] a held response (rsp_valid && !rsp_ready) stays valid with unchanged payload |
| A26 | `a_sfb_credit` | outstanding responses never exceed RSP_FIFO_DEPTH = READ_LATENCY + 1 (no overflow, no drop) |
| A27 | `a_sfb_ready_low_reset` | [R11] req_ready = 0 in reset and the first cycle after: reset can generate no transfer |
| A28 | `a_sfb_ready_exact` | req_ready <=> not test mode && live && a response credit is free (every request needs a response: WRITE_ACK = 1) |
| A29 | `a_sfb_reset_state` | [R11] in reset: no response is presented (rsp_valid = 0) and nothing is accepted |

#### cc_sfb_gate  (`harness/fv_prot_gate.sv`)

| id | property | statement |
|---|---|---|
| A1 | `a_fwd_not_refused_first` | [hdr] a request is presented downstream only if `refuse` was 0 in its first presentation cycle (refuse is evaluated before the request is presented) |
| A2 | `a_refused_not_forwarded` | [hdr] a refused request (refused_evt) is never forwarded: nothing reaches the master side in that cycle |
| A3 | `a_refused_evt_exact` | refused_evt is exactly one pulse per request accepted locally (accepted and not forwarded) |
| A4 | `a_refused_resp_next_cycle` | [R8] a refused request is answered ONE cycle after acceptance with rsp_error = 1 and rdata = 0 |
| A5 | `a_resp_exact` | [R5] s_rsp_valid <=> a local error response is owed, or a forwarded request is outstanding and the downstream answers: one response per request, none unsolicited |
| A6 | `a_resp_passthru` | [R4,R8] a forwarded transaction's response reaches the upstream unchanged (rdata/error); local responses never leak downstream data |
| A7 | `a_backpressure_passthru` | m_rsp_ready = s_rsp_ready unless a local response is being delivered (then the downstream response waits) |
| A8 | `a_one_at_a_time` | [R6] a new request is accepted only when nothing is outstanding and no local response is owed |
| A9 | `a_payload_identity` | a forwarded request is bit-identical to the upstream request (address, write, data, strobes) |
| A10 | `a_downstream_r2` | [R2] once presented downstream a request is never withdrawn and its payload never changes, even if `refuse` rises while it waits |
| A11 | `a_valid_formula` | [R3] m_req_valid is a function of registered state, the upstream request and `refuse` only -- it has no dependence on m_req_ready in the same cycle |
| A12 | `a_ready_formula` | s_req_ready = free && (refused ? 1 : m_req_ready): a request is never accepted while the gate is busy, a refused one is accepted at once |
| A13 | `a_idle_exact` | idle <=> nothing outstanding and nothing waiting downstream |
| A14 | `a_outstanding_le1` | at most one transaction is ever outstanding on the master side |
| A15 | `a_reset_no_forward` | [R11-style] no request is presented downstream while reset is asserted (reset quietness: NOT implemented -- finding SRAM-F2) |

#### cc_secmon  (`harness/fv_prot_secmon.sv`)

| id | property | statement |
|---|---|---|
| A1 | `a_lock_set_only` | [CC_SEC_CTRL] HOST_LOCK never clears except by reset: once set it stays set (any bus traffic, including CTRL writes of 0) |
| A2 | `a_lock_only_by_write` | HOST_LOCK rises only in the cycle after a CTRL write with bit 0 = 1 (no other path sets it) |
| A3 | `a_reset_clears_lock` | reset clears HOST_LOCK (documented reset control state) |
| A4 | `a_measure_second_write_refused` | [BOOT_MEASURE] a second write is refused with rb_err |
| A5 | `a_measure_first_write_accepted` | [BOOT_MEASURE] the first write after reset is accepted |
| A6 | `a_measure_holds_value` | [BOOT_MEASURE] reads return the first value written, whatever is written later; 0 before the first write |
| A7 | `a_status_lock_bit` | STATUS[0] reads HOST_LOCK |
| A8 | `a_ctrl_readback` | CTRL reads back HOST_LOCK; a write of 0 never reports an error and never clears it |
| A9 | `a_caps_read_only` | CAPS is read-only: a write is refused |

#### protection composition: array writes  (`harness/fv_prot_compose_tap.sv`)

| id | property | statement |
|---|---|---|
| A1 | `a_prot_write_needs_unlocked_first_eval` | PROTECTED WRITES: a functional array write to a protected word happens only if host_lock was 0 when its request was first evaluated by the gate (a lock set BEFORE a write is presented blocks it) |
| A2 | `a_prot_refused_at_accept` | a protected write that the gate evaluates while host_lock = 1 is refused (accepted locally, never forwarded) |
| A3 | `a_prot_error_response` | a refused protected write is answered one cycle later with rsp_error = 1 and rdata = 0 |
| A4 | `a_unprotected_not_refused` | no false denial: unprotected writes and all reads are never refused, lock or not |
| A5 | `a_lock_monotone_in_chain` | host_lock never clears except by reset (also inside the composed system) |
| A6 | `a_prot_stale_after_lock` | STRONG form (expected to FAIL, finding SRAM-F1): no functional array write to a protected word occurs while host_lock = 1 |

#### protection composition: memory content  (`harness/fv_prot_compose_word.sv`)

| id | property | statement |
|---|---|---|
| A20 | `a_prot_word_unchanged` | END-TO-END: every read of any word returns what the host's successfully acknowledged writes left there (lanes by strobe): refused/unauthorised writes never change memory; never-written lanes stay unchanged |
| A21 | `a_prot_refused_answered_error` | a protected write evaluated while host_lock = 1 is answered with rsp_error = 1 (never acknowledged as done) |
| A22 | `a_no_false_denial` | an unprotected or pre-lock request is acknowledged without error (the lock denies nothing else) |

## 6  Assumptions register (every `ALB_ASSUME`; a job is CONDITIONAL on exactly the ids it lists)

| id | statement | rationale | discharged by |
|---|---|---|---|
| ENV-RST-ANY | reset asserted in step 0; afterwards reset may assert at any step for any duration | `albion_env_reset` MODE 1: includes reset in the middle of a transfer (R11) | base assumption (not counted as conditional) |
| ENV-SRAM-TA | the tracked word address `ta` is a valid word (`ta < DEPTH`) | `ta` is the *quantified* address of the scoreboard, not a restriction of the environment; invalid addresses are covered by the error checks | n/a (quantifier) |
| ENV-SRAM-RSP1 | `rsp_ready = 1` always (only in the `RSP_FIFO_DEPTH = 0` job) | spec section 4: no-backpressure mode requires the master to hold `rsp_ready = 1` | the integration; not checked here |
| ENV-ARR-1 | `addr < DEPTH` whenever `ce` (raw array job) | raw backend contract, spec 3.4 | **proved** in `SRAM-CTRL-*`: `a_no_oob_access` (sram_sp never presents such an address) |
| ENV-SFB-R2 | a presented SFB2 request keeps its payload until accepted | PROTOCOL R2 | the SFB2 master / the crossbar; independence shown by job `SRAM-SFB-D6L1-NOR2` (no R2 assumption, same results) |
| ENV-GATE-R2 | upstream of `cc_sfb_gate` keeps a presented request until accepted | PROTOCOL R2 | upstream master |
| ENV-GATE-R4 / R5 / R8 | the downstream slave holds a response until ready; answers only an accepted request once; error => rdata = 0 | PROTOCOL R4/R5/R8 | **proved for `sfb_sram_slave`** in `SRAM-SFB-*` (`a_sfb_rsp_stable`, `a_sfb_rsp_exact`, `a_sfb_rsp_zero`) |
| ENV-PROT-R2 | as ENV-GATE-R2, in the composition jobs | PROTOCOL R2 | upstream master |
| ENV-PROT-WIN | requests are word-aligned and inside the slave window (`addr[1:0] = 0`, upper bits 0) | crossbar decode / PROTOCOL R9; makes the protected-window predicate equal to the word-index compare | the crossbar (FAB area proves decode) |
| ENV-PROT-NOTEST | `tst_active = 0` (word-content job only) | the MBIST port bypasses the host gate by design; its effect is shown in the tap job (cover `c_test_write_protected_locked`) | integration (DFT lifecycle) |

`refuse`, `rb_*` (the CPU's register bus), `rsp_ready`, `req_valid`, all payloads and the test port are otherwise **free** in every job.

## 7  Findings

Both findings are *behaviours of the RTL that a natural-reading property does not hold for*; each has a recorded counterexample, an `expect: FAIL:<id>`
entry (so a change of behaviour is flagged as UNEXPECTED), and a weaker property that **is** proved. Neither is a memory-corruption defect.

### SRAM-F1 -- a protected write that was presented *before* the lock can still be performed *after* it (documented gate behaviour)

* **Property** `a_prot_stale_after_lock` (jobs `SRAM-PROT-TAP-*`): "no functional array write to a protected word occurs while `host_lock = 1`" -- **FAILS**.
  Counterexample: `reports/counterexamples/SRAM-PROT-TAP-D4P2/a_prot_stale_after_lock/` (`report.md`, `trace.vcd`).
* **Scenario** (from the counterexample, 2 steps after reset): the SRAM is in test mode (`tst_active = 1`, so `req_ready = 0`); the host presents a write to a protected word
  while `host_lock = 0` -- the gate forwards it and, as designed, never withdraws it (`pend_q`); the CPU then writes `CTRL.HOST_LOCK`; test mode ends, the SRAM accepts, and the array
  is written with `host_lock = 1`. Any reason for the downstream to stall (reset-release cycle, test mode) opens the same window.
* **What IS proved** (`a_prot_write_needs_unlocked_first_eval`, `a_prot_refused_at_accept`, `a_prot_error_response`, `a_prot_word_unchanged`): a protected write whose *first evaluation by the gate*
  happens with the lock set is refused, answered with `rsp_error = 1`, never reaches the array, and leaves the memory word unchanged -- end to end, for every word.
* **Status**: documented in the `cc_sfb_gate` header ("once presented it is never withdrawn"); `c_stale_write_performed` shows it is reachable. The host lock therefore guarantees
  *no protected write FIRST PRESENTED after the lock*. Software that needs "nothing can still land" must lock and then wait for the gate's `idle` (proved exact: `a_idle_exact`).

### SRAM-F2 -- `cc_sfb_gate` presents requests downstream while reset is asserted (same class as AlbionVerify DF-F1 for the crossbar)

* **Property** `a_reset_no_forward` (job `SRAM-GATE`): "no request is presented downstream while reset is asserted" -- **FAILS** (cover `c_forward_in_reset` reached).
  Counterexample: `reports/counterexamples/SRAM-GATE/a_reset_no_forward/`.
* `m_req_valid = s_req_valid && free && !refuse_eff` and `s_rsp_valid` pass inputs through with no `rst_n` term; PROTOCOL R11 requires reset quietness only for the fabric, and the gate header does not claim it.
  Benign if every master and slave behind the gate is in the same reset domain (R11's premise); relevant if the host port is not.
* The SRAM slave itself IS reset-quiet (`a_sfb_ready_low_reset`, `a_sfb_reset_state` proved).

### Observations (not findings)
* `sfb_sram_slave` decodes `req_addr[OFF +: AW]` and ignores every other address bit, including a misaligned low bit (`c_misaligned_ignored` reached): alignment and window decode are the crossbar's job (PROTOCOL R9); proved for all address values, not only aligned ones.
* A write answered by the gate as refused has no side effect on the array (proved), but the CPU-visible violation counters (`viol_evt`) are only *wired* to `cc_secmon` in the composition; their counting is outside this area's properties.
* **Harness errors caught during development (not RTL defects).** Two vacuity covers (`c_reset_with_outstanding`, `c_reset_while_locked`) were UNREACHABLE because the history flag they used was itself
  asynchronously cleared in the very step where reset is visible; fixed with non-reset history registers. The raw-array jobs initially failed to elaborate for a missing include directory. None of this changed a property; it is recorded because
  it is exactly the failure mode the covers exist to expose.

### Proof effort (for reproducibility)
Control-legality, gate and `cc_secmon` proofs take about a second each. The memory-backed proofs are the expensive ones: `a_raw_lanes` / `a_array_lanes` 40-240 s, `a_rsp_data` 135-250 s wall under a 2x CPU-contended machine
(ABC's `pdr -T 180` budget is CPU time), `a_prot_word_unchanged` 141 s. The `READ_LATENCY = 2`, `RSP_FIFO_DEPTH = 3`, `DEPTH = 6` data model at DW = 16 was about 10x heavier per property (~240 s for the *light* ones); rather than
let the heavy ones time out, that configuration was moved to DW = 8 (two 4-bit lanes: masked-write semantics are unchanged) -- recorded in `proofs/sram.json`. No result in this area is BOUNDED or TIMEOUT.


## 8  What is NOT proved

Stated plainly -- these are **unresolved or out of scope**, not proved:

1. **Sizes.** The logic is width/depth-generic but proofs exist only at the parameter points of the jobs table: `DW` 8/16/32 (data/timing proofs of `sram_sp` at DW = 16, and DW = 8 for the heavy `READ_LATENCY = 2` configs; **no DW = 32 data/timing job** -- the memory+scoreboard model was too expensive for the shared CPU budget; DW = 32 is covered for the control job `SRAM-CTRL-W32D6` and the raw array `SRAM-ARR-W32D4L1`), `DEPTH` 4 and 6, `READ_LATENCY` 1-3, `ID_WIDTH` 2. A proof at `DEPTH = 6` is not a proof at `DEPTH = 1024`.
2. **Configurations not run:** `TEST_EN = 0`; `RSP_FIFO_DEPTH` other than `READ_LATENCY + 1` and 0 (e.g. 1, or deeper than needed); `MASK_WIDTH` other than 2 and 4; non-GENERIC backends (FPGA/ASIC arrays are not synthesizable in this flow); `sram_1r1w`, `sram_tdp`, `sram_bank_controller`, `sfb_sram_1r1w_slave`, `hpc_scratchpad`.
3. **No combinational path `rsp_ready -> req_ready`** is proved only *behaviourally*: `a_ready_exact` shows `req_ready` equals a function of registered state and the request payload (no `rsp_ready` term) for every `RSP_FIFO_DEPTH > 0` job. It is not a structural cone proof, and it is not asserted for `RSP_FIFO_DEPTH = 0`.
4. **Liveness is not claimed anywhere.** Response *timing* is an exact safety statement (`rsp_valid` iff the head has aged >= `READ_LATENCY`); "every request is eventually answered" is not proved and would need a fairness model for `rsp_ready`.
5. **Protection scope.** Only the host-lock use of `cc_sfb_gate` is composed with a memory. The `refuse` *expression* (`host_lock && write && in_region(...)`) is modelled in the harness from `silicaflux_control_core.sv`; the control core's own wiring and region constants are not verified here. The gate is proved standalone for **any** `refuse` value, which also covers its accelerator-isolation use at gate level, but that composition is not built.
6. **Bypass paths.** The MBIST test port writes the array without passing the gate (cover `c_test_write_protected_locked`); keeping it disabled in production is a lifecycle assumption (ENV-PROT-NOTEST), not a proof. The stale-write window (SRAM-F1) is open until the gate is idle.
7. **Array content semantics.** "Unwritten bytes remain unchanged" means *between observations*: a lane is compared only after it was written or first observed; nothing is claimed about retention across reset (the scoreboard forgets everything at reset).
8. **Single tracked address.** Lanes are compared only when known; a defect that alters data only for a combination of two specific addresses is found only if it also disturbs a known lane of some tracked word (it would for any aliasing/corruption defect that changes a word the model knows).
9. **Not modelled:** timing, CDC, clock gating, power, physical effects (soft errors/multi-bit upsets), gate-level behaviour, X-propagation (formal 2-state model), the simulation-only fault-injection branch of `sram_generic_1rw`.
10. **Solver/tool scope.** Yosys 0.33 front end only (no concurrent SVA); engines ABC `bmc3`/`pdr` and z3; the `sby/*.sby` files generated by the runner were not executed here (SymbiYosys not installed).


## 9  Mutation campaign (controlled bugs, `mutants/sram.json`)

Each mutant is one plausible design error applied to a *copy* of the pinned RTL; it is KILLED when at least one named assertion FAILS on it (ABC `bmc3`, depth 18). **34 / 34 killed.** Survivors: none.

| mutant | RTL | bug | status | killed by |
|---|---|---|---|---|
| MUT-SRAM-01 | `sram_sp.sv` | array enable not gated by the address-range check: an out-of-range request reaches the array (illegal write enable) | KILLED | SRAM-CTRL-D6L2W0/a_ce_exact, SRAM-CTRL-D6L2W0/a_no_oob_access, SRAM-CTRL-D6L2W0/a_invalid_no_array |
| MUT-SRAM-02 | `sram_sp.sv` | functional write mask ignored: every lane is written (unwritten bytes get overwritten) | KILLED | SRAM-CTRL-D4L1W1/a_wmask_exact |
| MUT-SRAM-03 | `sram_sp.sv` | test-port writes write no lanes (all-lanes rule of spec section 8 violated) | KILLED | SRAM-CTRL-D4L1W1/a_wmask_exact |
| MUT-SRAM-04 | `sram_sp.sv` | test mode takes its write enable from the functional port: functional req_we writes the array in test mode | KILLED | SRAM-CTRL-D4L1W1/a_we_exact, SRAM-CTRL-D4L1W1/a_wen_legal |
| MUT-SRAM-05 | `sram_sp.sv` | functional request accepted while the test port owns the array | KILLED | SRAM-CTRL-D4L1W1/a_ready_low_test |
| MUT-SRAM-06 | `sram_sp.sv` | reset-release qualifier removed from the posted-write path: a posted write is accepted in reset / the cycle after | KILLED | SRAM-CTRL-D6L2W0/a_ready_low_reset, SRAM-CTRL-D6L2W0/a_no_func_access_in_reset |
| MUT-SRAM-07 | `sram_rsp_path.sv` | live_q dropped: requests accepted during reset and the cycle after | KILLED | SRAM-CTRL-D4L1W1/a_ready_low_reset |
| MUT-SRAM-08 | `sram_rsp_path.sv` | response credit off by one: FIFO_DEPTH+1 responses may be outstanding -> response FIFO overflow | KILLED | SRAM-DATA-D4L1W1/a_credit_bound, SRAM-DATA-D4L1W1/a_ready_exact |
| MUT-SRAM-09 | `sram_sp.sv` | invalid-address requests are not flagged rsp_err (silent errors) | KILLED | SRAM-DATA-D6L1W1/a_rsp_err |
| MUT-SRAM-10 | `sram_rsp_path.sv` | rsp_id taken from the pipeline stage even when the response comes from the FIFO: wrong id under back-pressure | KILLED | SRAM-DATA-D4L1W1/a_rsp_id |
| MUT-SRAM-11 | `sram_generic_1rw.sv` | read pipeline bypassed: data one cycle early for READ_LATENCY >= 2 | KILLED | SRAM-ARR-D6L2/a_array_lanes |
| MUT-SRAM-12 | `sram_generic_1rw.sv` | array ignores the byte-lane mask: bytes the write did not select are overwritten | KILLED | SRAM-ARR-D4L1/a_array_written_lanes, SRAM-ARR-D4L1/a_array_unwritten_stable, SRAM-ARR-D4L1/a_array_lanes |
| MUT-SRAM-13 | `sram_generic_1rw.sv` | mask lanes reversed (lane l written by mask bit MASK_WIDTH-1-l) | KILLED | SRAM-ARR-D4L1/a_array_written_lanes, SRAM-ARR-D4L1/a_array_lanes |
| MUT-SRAM-14 | `sram_rsp_path.sv` | write acknowledgements and error responses carry array data instead of zero | KILLED | SRAM-DATA-D4L1W1/a_rsp_zero |
| MUT-SRAM-15 | `sram_rsp_path.sv` | rsp_we never set: write acknowledgements indistinguishable from read data | KILLED | SRAM-DATA-D4L1W1/a_rsp_we |
| MUT-SRAM-16 | `sram_sp.sv` | write acknowledgement dropped although WRITE_ACK = 1 (response lost) | KILLED | SRAM-DATA-D4L1W1/a_rsp_valid_exact |
| MUT-SRAM-17 | `sram_sp.sv` | posted writes (WRITE_ACK = 0) produce a response: unsolicited/duplicated response | KILLED | SRAM-DATA-D4L1W0/a_rsp_valid_exact, SRAM-DATA-D4L1W0/a_credit_bound |
| MUT-SRAM-18 | `sram_sp.sv` | out-of-range test address not gated: reaches the array | KILLED | SRAM-CTRL-D6L2W0/a_ce_exact, SRAM-CTRL-D6L2W0/a_no_oob_access |
| MUT-SRAM-19 | `sram_rsp_path.sv` | FIFO bypass taken even when older responses are stored: responses reordered / dropped | KILLED | SRAM-DATA-D4L1W1/a_rsp_valid_exact, SRAM-DATA-D4L1W1/a_rsp_data, SRAM-DATA-D4L1W1/a_rsp_id |
| MUT-SRAM-20 | `sfb_sram_slave.sv` | adapter decodes the wrong address bits (word index shifted) | KILLED | SRAM-SFB-D4L1/a_sfb_array_lanes, SRAM-SFB-D4L1/a_sfb_rsp_data |
| MUT-SRAM-21 | `sfb_sram_slave.sv` | adapter ignores the SFB2 byte strobes: sub-word writes overwrite the whole word | KILLED | SRAM-SFB-D4L1/a_sfb_array_lanes, SRAM-SFB-D4L1/a_sfb_rsp_data |
| MUT-SRAM-22 | `cc_sfb_gate.sv` | pend_q mask removed: a request already presented downstream is withdrawn when `refuse` rises (R2 violated) | KILLED | SRAM-GATE/a_downstream_r2, SRAM-GATE/a_valid_formula |
| MUT-SRAM-23 | `cc_sfb_gate.sv` | refuse ignored when presenting: a refused (unauthorised) write is forwarded to memory | KILLED | SRAM-GATE/a_fwd_not_refused_first, SRAM-GATE/a_refused_not_forwarded |
| MUT-SRAM-24 | `cc_sfb_gate.sv` | refused response leaks downstream read data instead of zero | KILLED | SRAM-GATE/a_refused_resp_next_cycle |
| MUT-SRAM-25 | `cc_sfb_gate.sv` | refused request acknowledged WITHOUT error (the host believes the protected write succeeded) | KILLED | SRAM-GATE/a_refused_resp_next_cycle |
| MUT-SRAM-26 | `cc_sfb_gate.sv` | second request accepted while one is outstanding (ordering / one-at-a-time rule) | KILLED | SRAM-GATE/a_one_at_a_time, SRAM-GATE/a_outstanding_le1 |
| MUT-SRAM-27 | `cc_sfb_gate.sv` | idle asserted while a request is presented downstream (PMU could stop the clock mid-transaction) | KILLED | SRAM-GATE/a_idle_exact |
| MUT-SRAM-28 | `cc_secmon.sv` | HOST_LOCK clearable by software (a write of 0 releases the protection) | KILLED | SRAM-SECMON/a_lock_set_only |
| MUT-SRAM-29 | `cc_secmon.sv` | BOOT_MEASURE overwritable although the second write is reported as refused | KILLED | SRAM-SECMON/a_measure_holds_value |
| MUT-SRAM-30 | `cc_secmon.sv` | HOST_LOCK not reset (survives a system reset) | KILLED | SRAM-SECMON/a_reset_clears_lock |
| MUT-SRAM-31 | `cc_secmon.sv` | host_lock output stuck at 0: the gate never refuses anything (protection silently off) | KILLED | SRAM-SECMON/a_status_lock_bit, SRAM-SECMON/a_ctrl_readback |
| MUT-SRAM-32 | `cc_sfb_gate.sv` | END-TO-END: a refused write is ALSO forwarded: the host reads the error response but the protected word was changed (word-content job) | KILLED | SRAM-PROT-WORD-D4P2/a_prot_word_unchanged |
| MUT-SRAM-33 | `cc_sfb_gate.sv` | END-TO-END: a refused protected write is acknowledged WITHOUT error (host believes it succeeded; word-content job) | KILLED | SRAM-PROT-WORD-D4P2/a_prot_refused_answered_error |
| MUT-SRAM-34 | `cc_sfb_gate.sv` | END-TO-END: refuse ignored when presenting: a protected write evaluated while locked reaches the ARRAY (tap job observes the array write enable) | KILLED | SRAM-PROT-TAP-D4P2/a_prot_write_needs_unlocked_first_eval |


## 10  Reproduction

```bash
cd formal/albion
python3 tools/vendor_rtl.py --check                       # RTL pins
python3 tools/albion_formal.py run --job SRAM-CTRL-D6L2W0 --jobs 2     # one job (all its assertions + covers)
python3 tools/albion_formal.py run --job SRAM-DATA-D4L1W1 --prop a_rsp_data --force   # one property
python3 tools/albion_formal.py mutate --mutant MUT-SRAM-01 --jobs 2     # one controlled bug
python3 tools/albion_formal.py ledger                      # rebuild reports/ledger.{md,csv,json}
```
Counterexamples of failing properties are in `reports/counterexamples/<job>/<property>/` (`report.md`, `trace.vcd`).
