# AlbionFormal -- DataFabric area (jobs `FAB-*`)

All tables in section 4 are generated from `reports/ledger.json` by `tools/area_tables.py` (re-run `albion_formal.py ledger` first);
the prose is hand-written. Reproduce any row with the command in `reports/ledger.md`.

## 1. Scope and RTL under test (pinned by SHA-256 in `rtl_under_test/MANIFEST.json`)

| RTL | role | verified in |
|---|---|---|
| `sfb_arbiter` | per-slave-port arbiter: fixed priority or round robin with grant lock | `FAB-ARB-*` (stand-alone) and inside the crossbar jobs |
| `sfb_addr_decoder` | address -> slave decode, access matrix `MST_SLV_EN`, alignment check | `FAB-DEC-*` (stand-alone, exhaustive over every address of the point) and inside the crossbar jobs |
| `sfb_crossbar` (with `sfb_req_mux`, `sfb_rsp_router`, `sfb_error_slave` instantiated inside, flattened) | the SFB2 interconnect | `FAB-XBAR-*` |
| `sfb_error_slave` | decode-error responder | `FAB-ERR-DW8` and inside the crossbar |
| `sfb_reg_slice`, `sfb_skid_buffer` | pipeline/FIFO elements of the fabric | `FAB-RSLICE-*`, `FAB-SKID-*` |

Specification used: `docs/datafabric/PROTOCOL.md` (SFB2 rules R1-R11, vendored). Harnesses: `harness/fv_sfb_{arbiter,decoder,xbar,skid,reg_slice,error_slave}.sv`;
shared environment monitors: `env/albion_sfb_mon.sv`, `env/albion_env_reset.sv`.

## 2. Mapping of the brief's wording onto the RTL

| brief | what exists | what was checked | job family / property |
|---|---|---|---|
| no duplicated requests | no IDs; a request is a valid/ready handshake | per-cycle conservation: the number of master-side accepts of routed requests equals the number of slave-side accepts; each accepted request reaches exactly its decoded slave with an identical payload | `FAB-XBAR-*` `a_no_duplication`, `a_master_attributed`, `a_payload_intact`; `FAB-SKID/RSLICE` `a_*_no_phantom`, `a_*_no_loss` |
| responses correspond to requests | one outstanding transaction per port (R6), in order | the response a master sees is exactly the response of the slave (or error slave) its request was routed to; a response is delivered only to the owner; no response without an earlier accepted request | `a_rsp_corresponds`, `a_rsp_to_owner`, `a_rsp_solicited`, `a_m_rsp_stable` |
| transaction IDs valid | **SFB2 has no transaction IDs** (PROTOCOL sec. 8) | the routing identifiers that do exist (slave owner record, decode-error capture index) are always valid (`a_owner_records`: exactly one owner per busy slave, none for idle, `err_master < NM`) | claim CL-ID-1 = MAPPED |
| mutually exclusive grants | `sfb_arbiter` grant vector | one-hot-or-zero, subset of requests, equal to an independent reference model (priority, pointer move-on-accept, lock), grant lock holds, work conserving | `FAB-ARB-*` |
| FIFO occupancy in bounds | 2-entry skid buffer, 2-entry register-slice channels | occupancy never exceeds the capacity (and never underflows), data in order, nothing invented or lost | `FAB-SKID-*`, `FAB-RSLICE-*` |
| no invalid routing destination | decoder + access matrix + alignment | the selected slave is exactly the lowest-index enabled region containing an aligned address; otherwise the error slave; a slave never sees a request its map does not route to it (exhaustive over all addresses of the point, four maps incl. overlapping regions and a denied slave) | `FAB-DEC-*`, `FAB-XBAR-*` `a_route_exact` |

## 3. Result highlights

* **Unbounded proofs** (PDR) for every functional property at every parameter point: crossbar, arbiter, decoder, skid buffer, register slice, error slave: **no property is only BOUNDED in this area.**
  The decoder, error slave, skid buffer and register slice are INDUCTIVE (only clock/reset assumed). The arbiter and crossbar proofs are CONDITIONAL on the listed assumptions (section 5).
* **11 FAILED rows, all expected and all explained** (counterexample waveforms in `reports/counterexamples/`):
  * `a_r11_no_ready_in_reset` x5 (every crossbar job): **DF-F1**, the defect AlbionVerify (Module 93, simulation) reported: `sfb_crossbar` does not gate `req_ready` during reset although PROTOCOL R11 says it is 0.
    Formal reproduces it independently at step 0 (the cheapest possible counterexample: reset asserted, a master request presented, `req_ready` high).
  * `a_r11_no_slave_req_in_reset` x5: **DF-F1b**, the same defect seen at the slave port: a routed request is presented to a slave while reset is asserted (`s_req_valid` is not gated by reset).
  * `a_s_req_stable` in `FAB-XBAR-2x2-RR-NOR2`: **FAB-F2**. If a master withdraws a presented request (the CPU instruction port is documented to), the *slave-side* request is no longer stable. R2 at the slave port is therefore guaranteed **only for R2-obeying masters**; the other crossbar jobs assume R2 for the masters and prove stability.
* **Router defence in depth (observation, not a defect).** `FAB-XBAR-2x2-RR-NOR5` drops the assumption that slaves obey R5 (respond only to an accepted request). `a_rsp_solicited` still holds, because the response router qualifies delivery with the slave-`busy` flag; the mutant that removes the qualifier (`MUT-XB-06`) is caught by exactly that job. Without that job the mutant would have survived (it is equivalent when R5 is assumed), which is why the job exists.
* **No liveness is claimed.** The round-robin bound `a_rr_bounded_wait` is a *safety* property over a counter (a continuously asserted request sees at most N-1 accepted competing grants), unbounded in time, and is **not** a latency bound (claims CL-LIVE-1/2).
* **Reset in the middle of a transfer** is covered by all stateful jobs (ENV-RST-ANY); the crossbar jobs carry a cover (`c_reset_mid_flight`) showing that reset really hits an outstanding transaction.

## 4. Jobs and results

| job | RTL module | parameter point | assumptions | IND | COND | STRUC | BND | FAIL | n/a | covers reached / unreachable / unreached |
|---|---|---|---|---|---|---|---|---|---|---|
| FAB-ARB-FIX4 | sfb_arbiter | `{"MODE": 0, "N": 4}` | ENV-RST-ANY, ENV-ARB-1, ENV-ARB-2, ENV-ARB-3 | 0 | 7 | 0 | 0 | 0 | 1 | 8 / 0 / 0 |
| FAB-ARB-RR3 | sfb_arbiter | `{"MODE": 1, "N": 3}` | ENV-RST-ANY, ENV-ARB-1, ENV-ARB-2, ENV-ARB-3 | 0 | 8 | 0 | 0 | 0 | 0 | 7 / 1 / 0 |
| FAB-ARB-RR5 | sfb_arbiter | `{"MODE": 1, "N": 5}` | ENV-RST-ANY, ENV-ARB-1, ENV-ARB-2, ENV-ARB-3 | 0 | 8 | 0 | 0 | 0 | 0 | 7 / 1 / 0 |
| FAB-DEC-A | sfb_addr_decoder | `{"AW": 6, "CHECK_ALIGN": 1, "DW": 16, "EN": 7, "NS": 3, "SLV_BASE": 132096, "SLV_MASK": 232496}` | ENV-RST-NONE | 7 | 0 | 2 | 0 | 0 | 0 | 3 / 2 / 0 |
| FAB-DEC-A-EN5 | sfb_addr_decoder | `{"AW": 6, "CHECK_ALIGN": 1, "DW": 16, "EN": 5, "NS": 3, "SLV_BASE": 132096, "SLV_MASK": 232496}` | ENV-RST-NONE | 8 | 0 | 1 | 0 | 0 | 0 | 4 / 1 / 0 |
| FAB-DEC-NOALIGN | sfb_addr_decoder | `{"AW": 6, "CHECK_ALIGN": 0, "DW": 16, "EN": 7, "NS": 3, "SLV_BASE": 132096, "SLV_MASK": 232496}` | ENV-RST-NONE | 6 | 0 | 3 | 0 | 0 | 0 | 2 / 3 / 0 |
| FAB-DEC-OVL | sfb_addr_decoder | `{"AW": 6, "CHECK_ALIGN": 1, "DW": 16, "EN": 3, "NS": 2, "SLV_BASE": 1024, "SLV_MASK": 3104}` | ENV-RST-NONE | 7 | 0 | 2 | 0 | 0 | 0 | 4 / 1 / 0 |
| FAB-ERR-DW8 | sfb_error_slave | `{"DW": 8}` | ENV-RST-ANY | 4 | 0 | 2 | 0 | 0 | 0 | 3 / 0 / 0 |
| FAB-RSLICE-01 | sfb_reg_slice | `{"AW": 2, "DW": 8, "REQ_SLICE": 0, "RSP_SLICE": 1}` | ENV-RST-ANY | 6 | 0 | 1 | 0 | 0 | 6 | 4 / 1 / 0 |
| FAB-RSLICE-10 | sfb_reg_slice | `{"AW": 2, "DW": 8, "REQ_SLICE": 1, "RSP_SLICE": 0}` | ENV-RST-ANY | 6 | 0 | 1 | 0 | 0 | 6 | 4 / 1 / 0 |
| FAB-RSLICE-11 | sfb_reg_slice | `{"AW": 2, "DW": 8, "REQ_SLICE": 1, "RSP_SLICE": 1}` | ENV-RST-ANY | 11 | 0 | 0 | 0 | 0 | 2 | 5 / 0 / 0 |
| FAB-SKID-W4 | sfb_skid_buffer | `{"WIDTH": 4}` | ENV-RST-ANY | 7 | 0 | 0 | 0 | 0 | 0 | 5 / 0 / 0 |
| FAB-SKID-W8 | sfb_skid_buffer | `{"WIDTH": 8}` | ENV-RST-ANY | 7 | 0 | 0 | 0 | 0 | 0 | 5 / 0 / 0 |
| FAB-XBAR-2x2-NOALIGN | sfb_crossbar | `{"ARB_MODE": 1, "AW": 6, "CHECK_ALIGN": 0, "DW": 16, "MST_SLV_EN": 15, "NM": 2, "NS": 2, "R2_MASTERS": 1, "SLV_BASE": 1024, "SLV_MASK": 3120}` | ENV-RST-ANY, ENV-SFB-R2, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8 | 0 | 16 | 0 | 0 | 2 | 0 | 9 / 1 / 0 |
| FAB-XBAR-2x2-RR | sfb_crossbar | `{"ARB_MODE": 1, "AW": 6, "CHECK_ALIGN": 1, "DW": 16, "MST_SLV_EN": 15, "NM": 2, "NS": 2, "R2_MASTERS": 1, "SLV_BASE": 1024, "SLV_MASK": 3120}` | ENV-RST-ANY, ENV-SFB-R2, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8 | 0 | 16 | 0 | 0 | 2 | 0 | 9 / 1 / 0 |
| FAB-XBAR-2x2-RR-NOR2 | sfb_crossbar | `{"ARB_MODE": 1, "AW": 6, "CHECK_ALIGN": 1, "DW": 16, "MST_SLV_EN": 15, "NM": 2, "NS": 2, "R2_MASTERS": 0, "SLV_BASE": 1024, "SLV_MASK": 3120}` | ENV-RST-ANY, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8 | 0 | 15 | 0 | 0 | 3 | 0 | 9 / 1 / 0 |
| FAB-XBAR-2x2-RR-NOR5 | sfb_crossbar | `{"ARB_MODE": 1, "AW": 6, "CHECK_ALIGN": 1, "DW": 16, "MST_SLV_EN": 15, "NM": 2, "NS": 2, "R2_MASTERS": 1, "R5_SLAVES": 0, "SLV_BASE": 1024, "SLV_MASK": 3120}` | ENV-RST-ANY, ENV-SFB-R2, ENV-SFB-R4, ENV-SFB-R8 | 0 | 1 | 0 | 0 | 0 | 0 | 2 / 0 / 0 |
| FAB-XBAR-2x3-FIX | sfb_crossbar | `{"ARB_MODE": 0, "AW": 6, "CHECK_ALIGN": 1, "DW": 16, "MST_SLV_EN": 63, "NM": 2, "NS": 3, "R2_MASTERS": 1, "SLV_BASE": 132096, "SLV_MASK": 232496}` | ENV-RST-ANY, ENV-SFB-R2, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8 | 0 | 16 | 0 | 0 | 2 | 0 | 9 / 1 / 0 |
| FAB-XBAR-3x2-RR-PM | sfb_crossbar | `{"ARB_MODE": 1, "AW": 6, "CHECK_ALIGN": 1, "DW": 16, "MST_SLV_EN": 47, "NM": 3, "NS": 2, "R2_MASTERS": 1, "SLV_BASE": 1024, "SLV_MASK": 3120}` | ENV-RST-ANY, ENV-SFB-R2, ENV-SFB-R4, ENV-SFB-R5, ENV-SFB-R8 | 0 | 16 | 0 | 0 | 2 | 0 | 10 / 0 / 0 |

IND = INDUCTIVE (unbounded, clock/reset only) - COND = CONDITIONAL (unbounded under the listed assumptions) - STRUC = STRUCTURAL (constant-1 after elaboration; reviewed) - n/a = property not elaborated at this parameter point.
Covers: *reached* = a witness trace exists under the job's full assumption set (non-vacuity evidence); *unreachable* = PDR **proved** the situation cannot occur at this point (each is a recorded expectation with the reason in `proofs/fabric.json`, e.g. `c_matrix_denied` with a full access matrix, `c_wcnt_exceeds` for round robin).

### 4.1 Arbiter (`harness/fv_sfb_arbiter.sv`)
| property | statement | FIX4 | RR3 | RR5 |
|---|---|---|---|---|
| `a_grant_onehot0` | [PROTOCOL 4] grants are mutually exclusive: grant is one-hot or zero | COND | COND | COND |
| `a_grant_subset_req` | a grant is only given to an asserted request | COND | COND | COND |
| `a_idx_consistent` | grant_idx names the granted requester | COND | COND | COND |
| `a_lock_holds` | [PROTOCOL 4] grant lock: a stalled grant is kept while the requester still requests | COND | COND | COND |
| `a_matches_reference` | grant == reference model (priority order, pointer move-on-accept, lock) | COND | COND | COND |
| `a_rr_bounded_wait` | [PROTOCOL 4] round robin: a continuously asserted request sees at most N-1 accepted grants to others | n/a | COND | COND |
| `a_valid_iff_grant` | grant_valid is exactly (grant != 0) | COND | COND | COND |
| `a_work_conserving` | [PROTOCOL 4] work conservation: any request yields a grant | COND | COND | COND |
| `c_accept` (cover) | a grant is accepted | reached | reached | reached |
| `c_accept_each_other` (cover) | an accepted grant to a requester other than k while req[k] pending | reached | reached | reached |
| `c_contention` (cover) | two requesters compete and one is granted | reached | reached | reached |
| `c_lock_engaged` (cover) | a stalled grant is locked into the next cycle | reached | reached | reached |
| `c_lock_withdrawn` (cover) | the locked requester withdraws and the lock is released | reached | reached | reached |
| `c_stall` (cover) | a grant is stalled | reached | reached | reached |
| `c_wait_bound_tight` (cover) | wcnt reaches N-1 (the bound is attained, so property 8 is not vacuous) | reached | reached | reached |
| `c_wcnt_exceeds` (cover) | wcnt >= N (fixed priority starvation; reachable only for MODE 0) | reached | unreachable | unreachable |

### 4.2 Address decoder (`harness/fv_sfb_decoder.sv`)
| property | statement | A | A-EN5 | NOALIGN | OVL |
|---|---|---|---|---|---|
| `a_aligned_only` | [R9] a misaligned address is never routed | IND | IND | STRUC | IND |
| `a_complete` | no valid destination is rejected: an enabled, containing, aligned slave => hit | IND | IND | IND | IND |
| `a_hit_iff_sel` | hit <=> some slave selected (no selection without hit, no hit without destination) | IND | IND | IND | IND |
| `a_lowest_wins` | overlapping regions resolve to the lowest permitted slave index | IND | IND | IND | IND |
| `a_matrix_respected` | [R8] a slave disabled for this master in MST_SLV_EN is never selected | STRUC | IND | STRUC | STRUC |
| `a_misaligned_flag` | misaligned flag == (CHECK_ALIGN && DW>8 && addr not DW-aligned) | STRUC | STRUC | STRUC | STRUC |
| `a_onehot0` | a decode selects at most one slave | IND | IND | IND | IND |
| `a_region_only` | a selected slave's region really contains the address (no invalid routing destination) | IND | IND | IND | IND |
| `a_sel_valid` | [R8] the selected index is a real slave: sel < NS and sel_oh[sel] | IND | IND | IND | IND |
| `c_denied_matrix` (cover) | an address inside a region whose EN bit is 0 and aligned: denied by the access matrix | unreachable | reached | unreachable | unreachable |
| `c_hit` (cover) | an address decodes to a slave | reached | reached | reached | reached |
| `c_misaligned` (cover) | an aligned-region address rejected only for misalignment | reached | reached | unreachable | reached |
| `c_overlap` (cover) | two enabled regions contain the address | unreachable | unreachable | unreachable | reached |
| `c_unmapped` (cover) | an address that is in no region | reached | reached | reached | reached |

### 4.3 Crossbar (`harness/fv_sfb_xbar.sv`)
`FAB-XBAR-2x2-RR-NOR5` runs only `a_rsp_solicited` and its covers (the other properties are identical to `2x2-RR` and need R5).

| property | statement | 2x2-NOALIGN | 2x2-RR | 2x2-RR-NOR2 | 2x2-RR-NOR5 | 2x3-FIX | 3x2-RR-PM |
|---|---|---|---|---|---|---|---|
| `a_err_capture` | decode-error capture port reports exactly the lowest-index master whose unmapped/denied/misaligned request was accepted | COND | COND | COND | - | COND | COND |
| `a_free_rule` | [R6] a new request is accepted only if nothing is outstanding or the previous response is accepted in that cycle | COND | COND | COND | - | COND | COND |
| `a_m_rsp_stable` | [R4] master-side response stays valid and unchanged until accepted | COND | COND | COND | - | COND | COND |
| `a_master_attributed` | an accepted routed master request is accepted by exactly its decoded slave in the same cycle with an identical payload | COND | COND | COND | - | COND | COND |
| `a_no_duplication` | [R1/R5] requests are not duplicated or invented: #routed master accepts == #slave accepts in every cycle | COND | COND | COND | - | COND | COND |
| `a_one_out_master` | [R6] a master port never has more than one transaction outstanding | COND | COND | COND | - | COND | COND |
| `a_one_out_slave` | [R6] a slave port never has more than one transaction outstanding | COND | COND | COND | - | COND | COND |
| `a_owner_records` | routing identifiers valid: each busy slave has exactly one owning master, idle slaves have none; err_master < NM | COND | COND | COND | - | COND | COND |
| `a_payload_intact` | a request presented to a slave carries the payload of a master whose address decodes to that slave | COND | COND | COND | - | COND | COND |
| `a_r11_no_ready_in_reset` | [R11] during reset the fabric's req_ready is 0 (so reset can generate no transfer) | **FAIL** | **FAIL** | **FAIL** | - | **FAIL** | **FAIL** |
| `a_r11_no_rsp_in_reset` | [R11] during reset the fabric presents no response | COND | COND | COND | - | COND | COND |
| `a_r11_no_slave_req_in_reset` | [R11 corollary] during reset no request is presented to a slave | **FAIL** | **FAIL** | **FAIL** | - | **FAIL** | **FAIL** |
| `a_route_exact` | [R8/R9] a slave accepts a request only if the address map routes a master's accepted request to it (no invalid destination) | COND | COND | COND | - | COND | COND |
| `a_rsp_corresponds` | responses correspond to requests: a master's response is exactly the response of the slave (or error slave) its request was routed to | COND | COND | COND | - | COND | COND |
| `a_rsp_solicited` | [R5] a master receives a response only while one of its earlier-accepted requests is outstanding | COND | COND | COND | COND | COND | COND |
| `a_rsp_to_owner` | a slave's response is delivered to its owning master, together with that master's rsp_ready (no foreign delivery) | COND | COND | COND | - | COND | COND |
| `a_s_req_stable` | [R2] slave-side request stays presented with an unchanged payload until accepted (grant lock), given R2 masters | COND | COND | **FAIL** | - | COND | COND |
| `a_work_conserving` | a free slave facing a free, routed requester always presents a request (a grant is always issued) | COND | COND | COND | - | COND | COND |
| `c_arb_loss` (cover) | an eligible master loses arbitration | reached | reached | reached | - | reached | reached |
| `c_back_to_back` (cover) | [R6] a new request is accepted in the cycle the previous response is accepted | reached | reached | reached | - | reached | reached |
| `c_contention` (cover) | two masters present requests to the same slave in one cycle | reached | reached | reached | - | reached | reached |
| `c_decode_error` (cover) | a request with no permitted/aligned destination is accepted by the error slave | reached | reached | reached | - | reached | reached |
| `c_matrix_denied` (cover) | a request inside a slave region is rejected by the access matrix | unreachable | unreachable | unreachable | - | unreachable | reached |
| `c_reset_mid_flight` (cover) | reset asserted while a transaction was outstanding in the previous cycle | reached | reached | reached | - | reached | reached |
| `c_response_routed` (cover) | a slave response reaches its owner | reached | reached | reached | reached | reached | reached |
| `c_route_to_each` (cover) | a master request is accepted by a slave | reached | reached | reached | reached | reached | reached |
| `c_rsp_backpressure` (cover) | a master stalls a valid response | reached | reached | reached | - | reached | reached |
| `c_slave_stall` (cover) | a slave stalls a presented request | reached | reached | reached | - | reached | reached |

### 4.4 Skid buffer, register slice, error slave
| property | statement | W4 | W8 |
|---|---|---|---|
| `a_data_in_order` | every delivered item equals the oldest accepted item (in order, no corruption, no duplication) | IND | IND |
| `a_no_loss` | stored data is never stranded: whenever an item is buffered the output is valid | IND | IND |
| `a_no_overflow` | no item is accepted when 2 are stored: s_ready is low when full | IND | IND |
| `a_no_phantom` | an item is only delivered if one was accepted earlier (no spurious output) | IND | IND |
| `a_occupancy_bound` | FIFO occupancy never exceeds the 2 entries (output register + skid register) | IND | IND |
| `a_reset_empty` | reset empties the buffer: m_valid is low in reset and the shadow count is 0 | IND | IND |
| `a_stable_stall` | payload stable: m_valid && !m_ready => m_valid and m_data unchanged next cycle | IND | IND |
| `c_back_to_back` (cover) | an item is accepted and delivered in the same cycle with one buffered | reached | reached |
| `c_drain_skid` (cover) | skid register drains into the output register | reached | reached |
| `c_full` (cover) | both entries occupied (s_ready low) | reached | reached |
| `c_stall` (cover) | output stalls with data valid | reached | reached |
| `c_withdraw` (cover) | upstream presents data that is not accepted (s_valid & !s_ready) | reached | reached |

| property | statement | 01 | 10 | 11 |
|---|---|---|---|---|
| `a_req_bound` | [sec.7] the request slice stores at most 2 transactions (and never accepts a 3rd) | n/a | IND | IND |
| `a_req_bypass` | REQ_SLICE=0: the request channel is wires (valid, ready, payload) | STRUC | n/a | n/a |
| `a_req_in_order` | [R5/R12] request payloads reach the slave side in order, unmodified, none duplicated | n/a | IND | IND |
| `a_req_no_loss` | an accepted request is never stranded: buffered => presented | n/a | IND | IND |
| `a_req_no_phantom` | no request is presented that was not accepted earlier | n/a | IND | IND |
| `a_req_stable` | [R2] a presented request that is not accepted stays presented, payload unchanged | n/a | IND | IND |
| `a_reset_quiet` | [R11] reset: nothing buffered, nothing presented on either sliced channel | IND | IND | IND |
| `a_rsp_bound` | the response slice stores at most 2 responses (and never accepts a 3rd) | IND | n/a | IND |
| `a_rsp_bypass` | RSP_SLICE=0: the response channel is wires | n/a | STRUC | n/a |
| `a_rsp_in_order` | [R5/R12] responses reach the master side in order, unmodified, none duplicated | IND | n/a | IND |
| `a_rsp_no_loss` | an accepted response is never stranded: buffered => presented | IND | n/a | IND |
| `a_rsp_no_phantom` | no response is presented that was not accepted earlier (solicited) | IND | n/a | IND |
| `a_rsp_stable` | [R4] a held response stays valid with unchanged rdata/error | IND | n/a | IND |
| `c_both_move` (cover) | a request and a response transfer in the same cycle | reached | reached | reached |
| `c_req_full` (cover) | request slice holds 2 transactions | unreachable | reached | reached |
| `c_req_stall` (cover) | slave side stalls a presented request | reached | reached | reached |
| `c_rsp_full` (cover) | response slice holds 2 responses | reached | unreachable | reached |
| `c_rsp_stall` (cover) | master side stalls a presented response | reached | reached | reached |

| property | statement | DW8 |
|---|---|---|
| `a_always_error` | [R8] every response is an error | STRUC |
| `a_held_stable` | [R4] a response that is not accepted stays valid next cycle | IND |
| `a_one_response` | [R5] exactly one response per accepted request: outstanding count is 0 or 1 and rsp_valid <=> 1 outstanding | IND |
| `a_rdata_zero` | [R8] rsp_rdata is 0 (no data leaks from the error slave) | STRUC |
| `a_ready_rule` | req_ready == !pending // rsp_ready (accept-while-retiring, one buffered response) | IND |
| `a_reset_quiet` | reset: no response is pending | IND |
| `c_accept_while_retire` (cover) | a new request is accepted in the cycle the previous response is accepted | reached |
| `c_backpressure` (cover) | response held under back-pressure | reached |
| `c_response` (cover) | an error response is produced | reached |

STRUCTURAL rows are listed with the reason in `proofs/fabric.json` (`expect_notes`): `misaligned == !aligned` and `a_matrix_respected` with a full matrix restate the RTL's own definition; the error slave's `rsp_valid`/`rsp_error` are the same flop and `rsp_rdata` is tied to 0.
`n/a` rows are reported, never counted as proved: e.g. a register slice with `REQ_SLICE=0` has no request FIFO to check.

## 5. Assumptions used (full register in `docs/ASSUMPTIONS.md`)

`ENV-RST-ANY` (reset at step 0 and any later step); `ENV-ARB-1/2/3` (arbiter jobs: `accept`/`stall` imply a grant and are exclusive; structural in the crossbar, whose jobs prove the composition without them);
`ENV-SFB-R2` (masters keep a presented request unchanged until accepted), `ENV-SFB-R4/R5/R8` (slaves: response held until accepted; response only to an accepted request; error response data is 0).
Nothing about latency, fairness or slave acceptance is assumed.

## 6. What is NOT proved (area-specific; global list in `docs/LIMITATIONS.md`)

* Unbounded liveness of any kind (CL-LIVE-1, CL-LIVE-2); response latency; starvation freedom measured in cycles.
* The production parameter values (AW=32, DW=32/64/128, the SoC's real master/slave counts and memory map): every job is one small parameter point (CL-PARAM-1).
  The crossbar is count/width generic, and the points cover contention, a denied matrix entry (`3x2-PM`), fixed and round-robin arbitration, with/without alignment checking, two and three slaves, but a proof at 2x2 is not a theorem for 8x8.
* That the SoC's masters and slaves obey R2/R4/R5/R8 (CL-ENV-1): only the blocks named in the area registers (`docs/ASSUMPTIONS.md`, `docs/areas/*.md`) are checked against these rules; every other master/slave is assumed.
* A per-request transaction ID through the fabric: none exists.
* Anything below RTL (timing, CDC, X-propagation): CL-LOWLEVEL-1.

## 7. Mutation campaign (`mutants/fabric.json`, results `reports/mutation/results/`)

24 single-edit bugs (5 arbiter, 19 interconnect/skid/slice/decoder/error-slave) applied to copies of the RTL; **24 / 24 killed** by at least one property under BMC (the killing property is listed next to each mutant in `reports/ledger.md`).
Highlights: two requesters granted at once (`MUT-ARB-03`), pointer not advancing (starvation, `MUT-ARB-04`), skid buffer accepting a third item (`MUT-XB-10`), access-matrix bypass (`MUT-XB-08`), decoder choosing the highest rather than the lowest overlapping region (`MUT-XB-09`),
error slave reporting success (`MUT-XB-13`), response router swallowing the error flag (`MUT-XB-18`), owner not recorded (`MUT-XB-05`). `MUT-XB-06` first *survived* the baseline job set; adding `FAB-XBAR-2x2-RR-NOR5` killed it (see section 3).

## 8. Reproduction

```bash
python3 tools/albion_formal.py run --job FAB-XBAR-2x2-RR --force      # one job, all properties
python3 tools/albion_formal.py run --job FAB-XBAR-2x2-RR --prop a_no_duplication --force
python3 tools/albion_formal.py mutate --mutant MUT-XB-06
```
