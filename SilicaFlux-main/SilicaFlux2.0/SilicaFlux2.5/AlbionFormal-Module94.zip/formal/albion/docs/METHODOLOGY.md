# AlbionFormal methodology (what a ledger row means)

AlbionFormal is a *claim-by-claim* proof system. Each row of `reports/ledger.md` is one named property, proved (or not)
in its own run, with the engine, depth, assumptions, parameter point and reproduction command next to the result.
Nothing in the ledger is typed in; it is generated from `reports/results/*.json` written by the runner.

## 1. Flow and tools (all open source, all pinned in the ledger header)

```
harness (SystemVerilog, immediate assertions) + RTL under test (rtl_under_test/, SHA-256 pinned)
  -> yosys 0.33: read_verilog -sv -formal; chparam (parameter point, ALB_SEL=<property id>); hierarchy; proc
     prep; flatten; memory_nordff; async2sync; chformal -assume -early; setundef -anyseq; opt; dffunmap
  -> model.smt2 (write_smt2 -wires)            model.aig (memory_map; techmap; abc -g AND; write_aiger -zinit -ywmap)
  -> ABC (yosys-abc):  bmc3  (bounded)   pdr  (IC3/PDR, unbounded)      yosys-smtbmc + z3: k-induction attempts
  -> counterexample: ABC witness -> yosys-witness aiw2yw -> yosys `sim -r` on the optimised RTL -> VCD + report.md
```
SymbiYosys is the usual driver for exactly these engines (`abc bmc3`, `abc pdr`, `smtbmc`). It is **not installed** in
the build environment and could not be obtained, so `tools/albion_formal.py` drives the engines directly. `sby/*.sby`
are generated from the same job manifests for CI use; they have **never been executed** (ledger header says so).

## 2. Result classes

| class | definition (as decided by the runner) |
|---|---|
| **INDUCTIVE** | ABC PDR returned *Property proved* (or k-induction closed with a passing base case), and the job's assumptions are only reset/clock. For state-free blocks PDR is exhaustive over all inputs. The statement is *unbounded*: every reachable state, every input sequence, for the parameter point. |
| **CONDITIONAL** | Same unbounded proof, but the job also lists environment assumptions (`ENV-*`: protocol obedience of neighbours, etc.). The proof is *only as good as those assumptions*; each is registered in `docs/ASSUMPTIONS.md` with who must discharge it. |
| **STRUCTURAL** | The property's condition is constant 1 in the optimised netlist (e.g. `rsp_valid` and `rsp_error` are the same flop). Sound (holds for every input and state) and needs no solver, but it says little about harness quality, so each one is reviewed and annotated. |
| **BOUNDED** | `bmc3` found no counterexample in frames 0..N-1 (depth N recorded) and no unbounded argument was obtained (PDR timed out / unknown, k-induction not inductive). **Never** to be read as a proof. |
| **COVER** | A cover is compiled as the safety property "this never happens"; its counterexample is the witness. *REACHED(step)*: witness exists. *UNREACHABLE*: PDR proved it can never happen (for the parameter point, under the assumptions). *UNREACHED(depth)*: not found to the depth, no proof. Covers are what detect vacuous environments. |
| **FAILED** | A counterexample exists (waveform + report in `reports/counterexamples/`). Either a design defect, a documented limitation reproduced by formal, or an over-strong property. The job's `expect` field records which (`FAIL:<finding-id>`). |
| **TIMEOUT / ERROR** | No bounded result within the budget, or the tool failed. Counted as unresolved. |
| **UNPROVEN** | Claims of record in `proofs/claims.json` for which no proof exists or was attempted (and *why*). Also any property whose unbounded attempt was inconclusive. |
| **N/A** | The property is not elaborated at this parameter point (its label is absent). It is reported, never silently counted as proved. |

A result differing from the job's recorded expectation is flagged **UNEXPECTED** in the ledger and fails CI. Expectations
are written by hand in `proofs/*.json` with reasons; they are not generated from results.
An expectation may be written `BOUNDED|PROVED` (explicit opt-in, used only for two DMA properties whose wall-clock-budgeted PDR run is borderline): either outcome is accepted, the ledger still shows the class actually obtained, and any other outcome is UNEXPECTED.

## 3. What "unbounded" means here, and its limits
* PDR proves the property for **all reachable states of the model** under the harness assumptions. The model is the RTL
  after Yosys elaboration with the two-state, single-clock `async2sync` semantics: asynchronous resets are sampled
  (a reset low in step *t* forces reset state onto outputs of step *t* and registers of step *t+1*); un-reset storage and
  undriven nets are arbitrary (`setundef -anyseq`), which is sound (superset of behaviours).
* Each job is **one parameter point** (widths, depths, port counts). The designs are width/count generic and the points
  were chosen to exercise every branch, but a proof at AW=6 is not a theorem at AW=32/64. Claim CL-PARAM-1 says so.
* ABC's `fold` folds constraints (assumptions) into the property; a property can therefore pass vacuously if the
  assumptions are contradictory. Guards: (a) every job has covers that must be REACHED under the same assumptions,
  (b) `yosys-smtbmc --presat` style checks are used where SMT BMC is run, (c) the self-test (`SELF-VACUOUS`) shows the
  covers do flag an over-constrained environment.

## 4. Environment assumptions (conditional proofs)
* **Clock**: one clock, one formal step per cycle (ENV-CLK). **Reset**: asynchronous assert, modes ENV-RST-FIRST,
  ENV-RST-ANY (reset in step 0 and at any later step, so *reset in the middle of a transfer* is covered), ENV-RST-NONE
  (arbitrary start state, for state-free or from-any-state proofs).
* **Protocol obedience** is assumed *only on ports the environment drives* (masters' request channel stability R2;
  slaves' response rules R4/R5/R8) using the monitors in `env/albion_sfb_mon.sv`, and **asserted** on ports the DUT
  drives (assume-guarantee symmetry).
* **No fairness / liveness assumption** is ever made. Bounded-progress statements use an explicit latency assumption
  (`albion_sfb_lat_mon`, `ENV-SLV-LAT`) and carry it in the ledger.
* Anything an assumption restates about *other* RTL (e.g. "every SoC slave obeys R5") is **not** discharged here
  (claim CL-ENV-1).

## 5. Liveness policy
Unbounded liveness ("eventually") is not claimed anywhere. Where a bounded-waiting statement is provable as a *safety*
property over a counter (e.g. round-robin: at most N-1 accepted competing grants while a request waits), that is what is
proved and it is named accordingly; it is explicitly **not** a time bound.

## 6. Validating the proof system
1. **Self-test** (`make selftest`, `harness/selftest_counter.sv`): a design with known verdicts. The runner must report
   PROVED for true properties, FAILED (with counterexample) for false ones and for an injected bug, STRUCTURAL for a
   constant property, N/A for an absent one, and UNREACHABLE for covers under an over-constraining assumption.
   It also records the honest limit: a word-level tautology the optimiser does not fold is *proved* -- weak properties are
   caught by mutation, not by the solver.
2. **Vacuity covers**: every job declares covers for the behaviour its properties are about (contention, stall, error
   path, reset mid-flight, FIFO full ...). A cover expected REACHED that comes back UNREACHABLE/UNREACHED, or a cover expected
   UNREACHABLE that is reached, is an UNEXPECTED row and the job's vacuity column in the ledger is a warning.
3. **Mutation** (`mutants/*.json`, `make mutate`): each mutant is an exact-text edit of a *copy* of the RTL modelling a
   plausible design error. The baseline property must hold; a mutant is KILLED when at least one listed property FAILS
   with a counterexample (BMC to the mutant's depth). A survivor must carry a written equivalence argument or the
   property is strengthened. The ledger shows, per property, which mutants it kills; a property that kills nothing is a
   candidate weak property.
4. **Known-defect reproduction**: AlbionVerify (Module 93, simulation) found DF-F1 (`sfb_crossbar` does not gate
   `req_ready` during reset). The formal property for PROTOCOL R11 independently finds it (counterexample at step 0),
   which is evidence the property set can find real defects.

## 7. Residual risks of the method (stated, not hidden)
* **Reference models are transcriptions of the specification** (PROTOCOL, DMA.md, interface spec, Citadel docs). Where the
  spec is ambiguous the interpretation is recorded in the area document; a wrong reading would make a property pass or
  fail for the wrong reason. Declarative (spec-level) properties are preferred over copies of RTL logic; where a property
  is a restatement of the RTL it is marked STRUCTURAL.
* **Property completeness**: the catalogue is the set of properties requested by the brief plus what the specs state; it is
  not a proof that no other bug exists.
* **Tool trust**: Yosys 0.33 front end and ABC are trusted. Counterexamples are cross-checked by a second engine
  (simulation of the witness); proofs have no second-engine check except where a property is proved by both PDR and
  k-induction (not generally attempted).
* **Shims** (guide C7) replace a selector module to observe an internal boundary; the replaced module's own logic is
  then not covered. Every shim is listed in its job notes.
