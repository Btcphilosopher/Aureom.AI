#!/usr/bin/env python3
"""Package formal/albion/ as a zip (no git operations).  Excludes build/ (scratch models), caches and editor files; includes
reports/ (the evidence).  Writes SHA256SUMS inside the archive so a recipient can verify it.

  package.py [--out PATH]      default: <repo>/AlbionFormal-Module94.zip
"""
import argparse, hashlib, os, sys, zipfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
REPO = os.path.abspath(os.path.join(ROOT, "..", ".."))
EXCLUDE_DIRS = {"build", "__pycache__", ".git", ".pytest_cache"}
EXCLUDE_SUFFIX = (".pyc", ".swp", "~")


def files():
    for dp, dn, fn in os.walk(ROOT):
        dn[:] = sorted(d for d in dn if d not in EXCLUDE_DIRS)
        for f in sorted(fn):
            if f.endswith(EXCLUDE_SUFFIX) or f == "SHA256SUMS":
                continue
            yield os.path.join(dp, f)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(REPO, "AlbionFormal-Module94.zip"))
    a = ap.parse_args()
    sums, n = [], 0
    if os.path.exists(a.out):
        os.remove(a.out)
    with zipfile.ZipFile(a.out, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for p in files():
            rel = os.path.relpath(p, ROOT)
            data = open(p, "rb").read()
            sums.append("%s  %s" % (hashlib.sha256(data).hexdigest(), rel))
            zi = zipfile.ZipInfo("formal/albion/" + rel, date_time=(2026, 11, 17, 0, 0, 0))   # fixed timestamp: reproducible archive
            zi.compress_type = zipfile.ZIP_DEFLATED
            zi.external_attr = (0o755 if os.access(p, os.X_OK) else 0o644) << 16
            z.writestr(zi, data)
            n += 1
        zi = zipfile.ZipInfo("formal/albion/SHA256SUMS", date_time=(2026, 11, 17, 0, 0, 0))
        zi.external_attr = 0o644 << 16
        z.writestr(zi, "\n".join(sums) + "\n")
    print("%s: %d files, %.1f MB" % (a.out, n, os.path.getsize(a.out) / 1e6))


if __name__ == "__main__":
    sys.exit(main())
