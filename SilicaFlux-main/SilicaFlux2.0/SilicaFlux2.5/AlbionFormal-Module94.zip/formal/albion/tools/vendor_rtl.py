#!/usr/bin/env python3
"""AlbionFormal -- vendor the RTL under test, pinned by SHA-256.

The proofs in this suite are about *specific bytes* of RTL.  This tool copies exactly those files out of the
SilicaFlux archives that live in the repository (read-only) into rtl_under_test/ and writes
rtl_under_test/MANIFEST.json (path, size, sha256, source archive + archive sha256).

  vendor_rtl.py            (re)generate rtl_under_test/ from the archives (aborts if a source file is missing)
  vendor_rtl.py --check    verify that rtl_under_test/ still matches MANIFEST.json (no archives needed)

Nothing is edited: files are copied byte for byte.  Mutants (mutants/*.json) are applied to *copies* in the
build directory, never to rtl_under_test/.
"""
import argparse, hashlib, json, os, sys, zipfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.abspath(os.path.join(HERE, ".."))               # formal/albion
DEST = os.path.join(ROOT, "rtl_under_test")
REPO = os.path.abspath(os.path.join(ROOT, "..", ".."))         # repository root
ARCH = os.path.join(REPO, "SilicaFlux-main", "SilicaFlux2.0", "SilicaFlux2.5")

DF = "silicaflux-datafabric.zip"
CIT = "silicaflux-citadel-p89.zip"
AV = "albionverify-0.1.0.zip"
AVR = "verification/albion/rtl/"   # AlbionVerify's own pinned vendored copy of the control core

# (archive, path inside the archive, destination below rtl_under_test/)
SPEC = []
def add(archive, prefix, dest_prefix, names):
    for n in names:
        SPEC.append((archive, prefix + n, dest_prefix + n))

add(DF, "silicaflux-datafabric/", "datafabric/", [
    "rtl/interconnect/sfb_arbiter.sv", "rtl/interconnect/sfb_addr_decoder.sv", "rtl/interconnect/sfb_req_mux.sv",
    "rtl/interconnect/sfb_rsp_router.sv", "rtl/interconnect/sfb_error_slave.sv", "rtl/interconnect/sfb_crossbar.sv",
    "rtl/interconnect/sfb_skid_buffer.sv", "rtl/interconnect/sfb_reg_slice.sv",
    "rtl/dma/dma_defs.svh", "rtl/dma/dma_validate.sv", "rtl/dma/dma_fifo.sv", "rtl/dma/dma_irq.sv",
    "rtl/dma/dma_control_regs.sv", "rtl/dma/dma_transfer_engine.sv", "rtl/dma/dma_burst_engine.sv",
    "rtl/dma/silicaflux_dma.sv", "rtl/mem/sfb_sram_slave.sv",
    "docs/datafabric/PROTOCOL.md", "docs/datafabric/DMA.md",
    # SRAM wrapper library (vendored unmodified inside the datafabric archive)
    "third_party/silicaflux-sramlib/rtl/mem/sram_defs.svh", "third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv",
    "third_party/silicaflux-sramlib/rtl/mem/sram_rsp_path.sv", "third_party/silicaflux-sramlib/rtl/mem/sram_backend_1rw.sv",
    "third_party/silicaflux-sramlib/rtl/mem/backends/generic/sram_generic_1rw.sv",
    "third_party/silicaflux-sramlib/docs/mem/01_interface_spec.md",
])
add(CIT, "silicaflux-citadel-p89/", "citadel/", [
    "rtl/albion/sf_citadel_pkg.sv", "rtl/albion/sf_citadel_permission.sv", "rtl/albion/sf_citadel_domain_table.sv",
    "rtl/albion/sf_citadel_gate.sv", "third_party/albion/sf_albion_pkg.sv",
    "docs/citadel/02_PERMISSION_CHECKER.md", "docs/citadel/03_DOMAIN_TABLE.md", "docs/citadel/04_ENFORCEMENT.md",
    "docs/citadel/08_ASSUMPTIONS_AND_LIMITATIONS.md",
])
add(AV, "verification/albion/rtl/controlcore/", "controlcore/", [
    "rtl/cc_sfb_gate.sv", "rtl/cc_secmon.sv", "rtl/generated/cc_memmap_defs.svh",
])


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read_zip(path, member, cache={}):
    z = cache.get(path)
    if z is None:
        z = cache[path] = zipfile.ZipFile(path)
    return z.read(member)


def generate():
    files, archives = {}, {}
    for archive, inner, dest in SPEC:
        apath = os.path.join(ARCH, archive)
        if not os.path.exists(apath):
            sys.exit("missing archive: %s" % apath)
        if archive not in archives:
            archives[archive] = sha(open(apath, "rb").read())
        try:
            data = read_zip(apath, inner)
        except KeyError:
            sys.exit("missing member %s in %s" % (inner, archive))
        out = os.path.join(DEST, dest)
        os.makedirs(os.path.dirname(out), exist_ok=True)
        with open(out, "wb") as f:
            f.write(data)
        files[dest] = dict(size=len(data), sha256=sha(data), archive=archive, member=inner)
    man = dict(schema=1, generated_by="tools/vendor_rtl.py",
               archives={k: dict(sha256=v, repo_path="SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/" + k) for k, v in archives.items()},
               files=files)
    with open(os.path.join(DEST, "MANIFEST.json"), "w") as f:
        json.dump(man, f, indent=1, sort_keys=True)
        f.write("\n")
    print("vendored %d files from %d archives" % (len(files), len(archives)))


def check():
    mp = os.path.join(DEST, "MANIFEST.json")
    if not os.path.exists(mp):
        sys.exit("no MANIFEST.json")
    man = json.load(open(mp))
    bad = 0
    for rel, meta in sorted(man["files"].items()):
        p = os.path.join(DEST, rel)
        if not os.path.exists(p):
            print("MISSING  ", rel); bad += 1; continue
        if sha(open(p, "rb").read()) != meta["sha256"]:
            print("MODIFIED ", rel); bad += 1
    print("rtl_under_test: %d files checked, %d problems" % (len(man["files"]), bad))
    return 1 if bad else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true")
    a = ap.parse_args()
    if a.check:
        sys.exit(check())
    generate()
