#!/usr/bin/env python3
"""Emit markdown tables (job summary, per-property class matrix) for one area from reports/ledger.json, so that the numbers
quoted in docs/areas/*.md can be regenerated instead of typed.   Read-only; run `albion_formal.py ledger` first.

  area_tables.py jobs   <job-prefix> [<job-prefix> ...]     one row per job: counts per class, covers
  area_tables.py matrix <harness-module-name>                 property x job matrix for one RTL module family (by job prefix)
                        e.g.  area_tables.py matrix FAB-XBAR
"""
import collections, json, os, sys

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
SHORT = dict(INDUCTIVE="IND", CONDITIONAL="COND", BOUNDED="BND", STRUCTURAL="STRUC", FAILED="**FAIL**", TIMEOUT="TMO", ERROR="ERR")


def load():
    return json.load(open(os.path.join(ROOT, "reports", "ledger.json")))["rows"]


def cell(r):
    if r["kind"] == "cover":
        return r["result"].split("(")[0].lower()
    if r["result"] in ("N/A",) or r["cls"] == "N/A":
        return "n/a"
    s = SHORT.get(r["cls"], r["cls"])
    if r["cls"] == "BOUNDED":
        s += " d" + "".join(ch for ch in r["solver"].split("d=")[-1].split(";")[0] if ch.isdigit()) if "d=" in r["solver"] else ""
    return s


def jobs_table(prefixes):
    rows = [r for r in load() if any(r["job"].startswith(p) for p in prefixes)]
    jobs = collections.OrderedDict()
    for r in sorted(rows, key=lambda r: r["job"]):
        j = jobs.setdefault(r["job"], dict(mod=r["rtl_module"], params=r["params"], ass=r["assumptions"],
                                           c=collections.Counter(), cv=collections.Counter(), secs=0.0))
        if r["kind"] == "assert":
            j["c"][r["cls"]] += 1
        else:
            j["cv"][r["result"].split("(")[0]] += 1
        j["secs"] += r["secs"] or 0
    out = ["| job | RTL module | parameter point | assumptions | IND | COND | STRUC | BND | FAIL | n/a | covers reached / unreachable / unreached |",
           "|---|---|---|---|---|---|---|---|---|---|---|"]
    for k, j in jobs.items():
        c, cv = j["c"], j["cv"]
        out.append("| %s | %s | `%s` | %s | %d | %d | %d | %d | %d | %d | %d / %d / %d |" % (
            k, j["mod"], j["params"].replace("|", "/"), j["ass"], c["INDUCTIVE"], c["CONDITIONAL"], c["STRUCTURAL"], c["BOUNDED"],
            c["FAILED"], c["N/A"], cv["REACHED"], cv["UNREACHABLE"], cv["UNREACHED"]))
    return "\n".join(out)


def matrix(prefix):
    rows = [r for r in load() if r["job"].startswith(prefix)]
    jobs = sorted({r["job"] for r in rows})
    props = collections.OrderedDict()
    for r in rows:
        props.setdefault((r["kind"], r["property"]), r["text"])
    cell_of = {(r["job"], r["kind"], r["property"]): cell(r) for r in rows}
    hdr = "| property | statement | " + " | ".join(j[len(prefix):].lstrip("-") or j for j in jobs) + " |"
    out = [hdr, "|---|---|" + "---|" * len(jobs)]
    for (kind, name), text in sorted(props.items(), key=lambda kv: (kv[0][0] != "assert", kv[0][1])):
        out.append("| `%s`%s | %s | %s |" % (name, " (cover)" if kind == "cover" else "", text.replace("|", "/"),
                                              " | ".join(cell_of.get((j, kind, name), "-") for j in jobs)))
    return "\n".join(out)


if __name__ == "__main__":
    if len(sys.argv) < 3 or sys.argv[1] not in ("jobs", "matrix"):
        sys.exit(__doc__)
    print(jobs_table(sys.argv[2:]) if sys.argv[1] == "jobs" else matrix(sys.argv[2]))
