#!/usr/bin/env python3
"""AlbionFormal runner (Module 94) -- Yosys 0.33 + yosys-smtbmc (z3) + ABC (bmc3, pdr).  No SymbiYosys required.

Every ASSERT and COVER in a harness (`ALB_ASSERT / ALB_COVER`, lib/albion_sva.svh) is checked in ITS OWN run: the
harness is elaborated with ALB_SEL=<id>, so each ledger row is a statement about exactly one property.

Engines (per assertion, in this order; stop at the first counterexample)
  bmc     ABC `bmc3` on the AIGER model (default) or yosys-smtbmc/z3 ("bmc_engine": "smt") to depth `depth`
          -> BOUNDED(depth).  Never reported as a proof.
  pdr     ABC property-directed reachability (IC3) on the AIGER model, `pdr_timeout` s
          -> "Property proved" = unbounded proof for every input sequence allowed by the harness assumptions.
  ind     yosys-smtbmc/z3 temporal induction of length `ind_k` (only tried if pdr did not decide); the base case is the
          BMC run above, so a pass is a k-induction proof.
  cover   compiled as a "never" assertion (ALB_COVER_AS_ASSERT): ABC bmc3 to `cover_depth` -> REACHED(witness step);
          otherwise ABC pdr -> UNREACHABLE (for all time) or UNREACHED(depth) (bounded only)

Result classes (the vocabulary of the proof ledger; see docs/METHODOLOGY.md)
  INDUCTIVE    unbounded proof; the only assumptions are reset/clock (or none: combinational/all-state proofs)
  CONDITIONAL  unbounded proof that additionally depends on listed environment assumptions
  BOUNDED      no counterexample up to `depth`; no unbounded argument was obtained
  COVER        cover REACHED (witness exists) | UNREACHABLE (proved never) | UNREACHED(bounded) -- a vacuity warning when REACHED was expected
  FAILED       counterexample found (a real defect, a documented limitation, or an over-strong property)
  TIMEOUT      no result within the time budget (not even a bounded one)
  UNPROVEN     claim of record with no proof (proofs/claims.json) or an unbounded attempt that was inconclusive and
               has no bounded fallback
  STRUCTURAL   (result TRIVIAL) holds by construction: the condition is constant 1 in the optimised netlist; sound, reviewed
  N/A          the property is not elaborated in this configuration (label absent)

Commands
  list [--job ID]                       jobs and properties found in the harness sources
  run [--job ID ...] [--prop NAME ...] [--quick] [--force] [--jobs N]
  covers [--job ID ...]                 (included in `run`; separate entry point)
  mutate [--mutant ID ...] [--jobs N]   controlled-bug campaign (mutants/*.json)
  selftest                              proof-system self-checks (harness/selftest_*.sv)
  ledger                                build reports/ledger.{md,csv,json} from reports/results/
  sby                                   write sby/<job>.sby (generated, NOT executed here: SymbiYosys is not installed)
  catalogue                             write docs/PROPERTY_CATALOGUE.md from the harness sources
  check                                 verify RTL pins + manifests, exit 1 on any UNEXPECTED result
"""
import argparse, concurrent.futures as cf, csv, glob, hashlib, json, os, re, shlex, shutil, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), ".."))
RUT = os.path.join(ROOT, "rtl_under_test")
BUILD = os.path.join(ROOT, "build")
REPORTS = os.path.join(ROOT, "reports")
RESULTS = os.path.join(REPORTS, "results")
TOOL_VERSION = "1.0"
BASE_ASSUMPTIONS = ("ENV-RST-FIRST", "ENV-RST-ANY", "ENV-RST-NONE", "ENV-CLK")   # not counted as 'conditional'

RE_ASSERT = re.compile(r'`ALB_ASSERT\(\s*(\d+)\s*,\s*(\w+)\s*,\s*"((?:[^"\\]|\\.)*)"')
RE_COVER = re.compile(r'`ALB_COVER\(\s*(\d+)\s*,\s*(\w+)\s*,\s*"((?:[^"\\]|\\.)*)"')
RE_ASSUME = re.compile(r'`ALB_ASSUME\(\s*(\w+)\s*,\s*"((?:[^"\\]|\\.)*)"')


# ----------------------------------------------------------------------------------------------- helpers
def _limits(mem_gb):
    def f():                                   # runs in the child between fork and exec
        import resource
        lim = int(mem_gb * (1 << 30))
        try:
            resource.setrlimit(resource.RLIMIT_AS, (lim, lim))
        except (ValueError, OSError):
            pass
    return f


def sh(cmd, timeout=None, cwd=None, log=None, mem_gb=None):
    """run a command, return (rc, combined output); rc 124 on timeout.
    The child gets its OWN SESSION and on timeout the WHOLE PROCESS GROUP is killed: yosys-smtbmc spawns z3 and
    killing only the parent would leave z3 running (orphaned) and eating memory.  mem_gb caps the child's address space
    (a runaway solver then fails by itself instead of triggering the kernel OOM killer for everybody)."""
    if mem_gb is None:
        mem_gb = 2.5 if (cmd and "smtbmc" in os.path.basename(cmd[0])) else 4
    p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, cwd=cwd,
                         start_new_session=True, preexec_fn=_limits(mem_gb))
    try:
        out, _ = p.communicate(timeout=timeout)
        rc = p.returncode
    except subprocess.TimeoutExpired:
        try:
            os.killpg(p.pid, 9)
        except ProcessLookupError:
            pass
        out, _ = p.communicate()
        out = (out or "") + "\n[albion] TIMEOUT after %ss\n" % timeout
        rc = 124
    if log:
        with open(log, "w") as f:
            f.write(out)
    return rc, out


def sha(*parts):
    h = hashlib.sha256()
    for p in parts:
        h.update(p if isinstance(p, bytes) else str(p).encode())
        h.update(b"\0")
    return h.hexdigest()


def first_line(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True).stdout.strip().splitlines()[0]
    except Exception:
        return "n/a"


def tool_versions():
    return dict(yosys=first_line(["yosys", "-V"]), z3=first_line(["z3", "--version"]),
                abc=first_line(["yosys-abc", "-c", "version"]) if shutil.which("yosys-abc") else "n/a",
                albion_formal=TOOL_VERSION)


def resolve(p):
    return os.path.join(RUT, p[4:]) if p.startswith("rtl:") else os.path.join(ROOT, p)


def read(p):
    with open(p, "r", errors="replace") as f:
        return f.read()


# ----------------------------------------------------------------------------------------------- manifests
def load_jobs(sel=None):
    jobs = {}
    for fn in sorted(glob.glob(os.path.join(ROOT, "proofs", "*.json"))):
        if os.path.basename(fn) in ("claims.json",):
            continue
        d = json.load(open(fn))
        for j in d["jobs"]:
            j.setdefault("source_manifest", os.path.relpath(fn, ROOT))
            if j["id"] in jobs:
                sys.exit("duplicate job id %s" % j["id"])
            jobs[j["id"]] = j
    if sel:
        miss = [s for s in sel if s not in jobs]
        if miss:
            sys.exit("unknown job(s): %s" % ", ".join(miss))
        jobs = {k: v for k, v in jobs.items() if k in sel}
    return jobs


def strip_comments(txt):
    """drop // comments and /* */ blocks (macros mentioned in documentation must not be catalogued); // inside "..." is kept"""
    txt = re.sub(r"/\*.*?\*/", "", txt, flags=re.S)
    out = []
    for line in txt.splitlines():
        i = line.find("//")
        if i >= 0 and line[:i].count('"') % 2 == 0:
            line = line[:i]
        out.append(line)
    return "\n".join(out)


def scan_props(job, override=None):
    """enumerate asserts/covers/assumes from the non-RTL sources of the job (the harness is the catalogue)"""
    asserts, covers, assumes = {}, {}, {}
    for f in job["files"]:
        if f.startswith("rtl:"):
            continue
        txt = strip_comments(read(resolve(f)))
        for i, n, t in RE_ASSERT.findall(txt):
            asserts.setdefault(n, dict(id=int(i), name=n, text=t))
        for i, n, t in RE_COVER.findall(txt):
            covers.setdefault(n, dict(id=int(i), name=n, text=t))
        for n, t in RE_ASSUME.findall(txt):
            assumes.setdefault(n, dict(name=n, text=t))
    ids = [p["id"] for p in list(asserts.values()) + list(covers.values())]
    if len(ids) != len(set(ids)):
        sys.exit("job %s: duplicate property ids in harness" % job["id"])
    return asserts, covers, assumes


# ----------------------------------------------------------------------------------------------- model build
def dirs_for(job):
    d = [os.path.join(ROOT, "lib")]
    for f in job["files"]:
        if f.startswith("rtl:"):
            d.append(os.path.dirname(resolve(f)))
    for i in job.get("includes", []):
        d.append(resolve(i))
    out = []
    for x in d:
        if x not in out:
            out.append(x)
    return out


def yosys_script(job, sel, mode, fmap, outdir, extra_defs=()):
    """mode: 'prove' (smt2 + aig, native covers removed).  Covers are compiled as 'never' assertions (ALB_COVER_AS_ASSERT)."""
    files = [fmap.get(f, resolve(f)) for f in job["files"]]
    s = "read_verilog -sv -formal -DFORMAL -DSYNTHESIS %s %s %s; " % (
        " ".join("-D%s" % d for d in list(job.get("defines", [])) + list(extra_defs)), " ".join("-I%s" % d for d in dirs_for(job)), " ".join(files))
    params = dict(job.get("params", {}))
    params["ALB_SEL"] = sel
    for k, v in params.items():
        s += "chparam -set %s %s %s; " % (k, ('"%s"' % v) if isinstance(v, str) else v, job["top"])
    s += "hierarchy -top %s; proc; tee -q -o %s/asserts_pre.txt dump t:$assert; " % (job["top"], outdir)
    s += "prep -top %s; flatten; memory_nordff; async2sync; chformal -assume -early; " % job["top"]
    if mode == "prove":
        s += "chformal -cover -remove; "
    s += "opt_clean; setundef -anyseq; opt -fast; dffunmap; opt_clean; "
    s += "tee -q -o %s/asserts.txt dump t:$assert; " % outdir
    s += "write_rtlil %s/model.il; " % outdir
    s += "write_smt2 -wires %s/model.smt2; " % outdir
    if mode == "prove":
        s += ("memory_map; techmap; opt -fast -nosdff -nodffe; dffunmap; abc -g AND -fast; opt_clean; "
              "write_aiger -I -B -zinit -no-startoffset -map %s/model.aim -ywmap %s/model.ywa %s/model.aig; " % (outdir, outdir, outdir))
    return s


def assert_state(outdir, name):
    """'live' | 'trivial' | 'absent'.
    absent  = the label does not exist right after elaboration (e.g. inside an untaken `if (PARAM == ..)`): N/A
    trivial = it exists after elaboration but its condition is constant (or the cell was deleted) after optimisation
    live    = it exists with a non-constant condition in the optimised netlist"""
    pre = read(os.path.join(outdir, "asserts_pre.txt"))
    if not re.search(r"cell \$assert \\%s\b" % re.escape(name), pre):
        return "absent"
    txt = read(os.path.join(outdir, "asserts.txt"))
    m = re.search(r"cell \$assert \\%s\b(.*?)end" % re.escape(name), txt, re.S)
    if not m:
        return "trivial"
    a = re.search(r"connect \\A (\S+)", m.group(1))
    return "trivial" if a and a.group(1) in ("1'1", "1'x") else "live"


def build(job, sel, mode, tag, fmap=None, extra_defs=()):
    outdir = os.path.join(BUILD, job["id"], tag)
    shutil.rmtree(outdir, ignore_errors=True)
    os.makedirs(outdir)
    script = yosys_script(job, sel, mode, fmap or {}, outdir, extra_defs)
    rc, out = sh(["yosys", "-q", "-l", os.path.join(outdir, "yosys.log"), "-p", script], timeout=600)
    open(os.path.join(outdir, "repro_yosys.sh"), "w").write("yosys -p %s\n" % shlex.quote(script))
    return outdir, rc, out


# ----------------------------------------------------------------------------------------------- engines
def abc_run(cmd, tmo, log):
    """run yosys-abc; if it died without printing any verdict (killed for memory, transient failure) retry ONCE"""
    for attempt in (1, 2):
        rc, out = sh(["yosys-abc", "-c", cmd], timeout=tmo + 120, log=log)
        verdict = re.search(r"Property proved|was asserted|No output asserted|Reached timeout|Does not work for combinational|"
                            r"Reached conflict|Resource limit|Time =", out)
        if verdict or rc == 124:
            return rc, out
    return rc, out + "\n[albion] yosys-abc produced no verdict twice (rc=%s)\n" % rc


def eng_bmc3(outdir, depth, tmo):
    cmd = "read_aiger %s/model.aig; fold; strash; bmc3 -F %d -T %d -v; write_cex -a %s/cex_bmc3.aiw" % (outdir, depth, tmo, outdir)
    t0 = time.time()
    rc, out = abc_run(cmd, tmo, os.path.join(outdir, "bmc3.log"))
    if "Does not work for combinational networks" in out:
        return dict(status="COMB", secs=time.time() - t0)         # state-free design: PDR alone decides (exhaustively)
    m = re.search(r'was asserted in frame (\d+)', out)
    if m:
        return dict(status="FAIL", depth=int(m.group(1)), secs=time.time() - t0)
    n = re.search(r'No output asserted in (\d+) frames', out)
    if n:
        return dict(status="PASS", depth=int(n.group(1)), secs=time.time() - t0)
    return dict(status="ERROR", depth=0, secs=time.time() - t0, detail=out[-400:])


def eng_pdr(outdir, tmo):
    cmd = "read_aiger %s/model.aig; fold; strash; pdr -T %d; write_cex -a %s/cex_pdr.aiw" % (outdir, tmo, outdir)
    t0 = time.time()
    rc, out = abc_run(cmd, tmo, os.path.join(outdir, "pdr.log"))
    secs = time.time() - t0
    if "Property proved" in out:
        fr = re.search(r'Property proved.*?frame (\d+)', out)
        return dict(status="PROVED", secs=secs, frames=int(fr.group(1)) if fr else None)
    m = re.search(r'was asserted in frame (\d+)', out)
    if m:
        return dict(status="FAIL", depth=int(m.group(1)), secs=secs)
    return dict(status="UNKNOWN", secs=secs, detail=out[-300:])


def eng_smt_bmc(outdir, depth, tmo, vcd=None, solver="z3", presat=True):
    cmd = ["yosys-smtbmc", "--noprogress", "-s", solver] + (["--presat"] if presat else []) + ["-t", str(depth)]
    if vcd:
        cmd += ["--dump-vcd", vcd]
    cmd += [os.path.join(outdir, "model.smt2")]
    t0 = time.time()
    rc, out = sh(cmd, timeout=tmo, log=os.path.join(outdir, "smtbmc.log"))
    secs = time.time() - t0
    if rc == 124:
        return dict(status="TIMEOUT", secs=secs)
    if "BMC failed" in out or "Assert failed" in out:
        m = re.search(r"Checking assertions in step (\d+)", out[::1])
        steps = re.findall(r"Checking assertions in step (\d+)", out)
        return dict(status="FAIL", depth=int(steps[-1]) if steps else 0, secs=secs)
    if "Assumptions are unsatisfiable" in out:
        return dict(status="VACUOUS", secs=secs, detail="assumptions unsatisfiable")
    if "Status: PASSED" in out:
        return dict(status="PASS", depth=depth, secs=secs)
    return dict(status="ERROR", secs=secs, detail=out[-400:])


def eng_sim_replay(outdir, top, yw, vcd):
    """re-execute the counterexample on the optimised RTL netlist with Yosys's built-in simulator (no SMT solver):
    an independent confirmation that the trace really violates the assertion, plus the waveform"""
    rc, out = sh(["yosys", "-q", "-l", os.path.join(os.path.dirname(vcd), "replay.log"), "-p",
                  "read_rtlil %s; sim -r %s -vcd %s -scope %s -timescale 1ns -zinit" % (os.path.join(outdir, "model.il"), yw, vcd, top)],
                 timeout=120)
    log = read(os.path.join(os.path.dirname(vcd), "replay.log")) if os.path.exists(os.path.join(os.path.dirname(vcd), "replay.log")) else out
    m = re.search(r"Warning: Assert (\S+) .*? failed", log)
    return dict(status=("CONFIRMED: simulation violates " + m.group(1)) if m else "replayed (no assertion fired -- inspect trace)")


def eng_induction(outdir, k, tmo):
    t0 = time.time()
    rc, out = sh(["yosys-smtbmc", "--noprogress", "-s", "z3", "-i", "-t", str(k), os.path.join(outdir, "model.smt2")],
                 timeout=tmo, log=os.path.join(outdir, "induction.log"))
    secs = time.time() - t0
    if rc == 124:
        return dict(status="TIMEOUT", secs=secs)
    if "Status: PASSED" in out:
        return dict(status="PROVED", k=k, secs=secs)
    return dict(status="NOT-INDUCTIVE", k=k, secs=secs)


def eng_cover(outdir, name, depth, tmo):
    t0 = time.time()
    rc, out = sh(["yosys-smtbmc", "--noprogress", "-s", "z3", "-c", "-t", str(depth), os.path.join(outdir, "model.smt2")],
                 timeout=tmo, log=os.path.join(outdir, "cover.log"))
    secs = time.time() - t0
    if rc == 124:
        return dict(status="TIMEOUT", secs=secs)
    m = re.search(r"Reached cover statement at %s in step (\d+)" % re.escape(name), out)
    if m:
        return dict(status="REACHED", step=int(m.group(1)), secs=secs)
    if re.search(r"Unreached cover statement at %s\b" % re.escape(name), out):
        return dict(status="UNREACHED", depth=depth, secs=secs)
    return dict(status="ERROR", secs=secs, detail=out[-300:])


# ----------------------------------------------------------------------------------------------- counterexamples
def parse_vcd(path):
    """minimal VCD reader -> (names {id: 'scope.name'}, widths, steps [ {id: value} ]); timestamps become step numbers"""
    names, widths, scope, steps, cur = {}, {}, [], [], None
    for line in open(path):
        line = line.strip()
        if line.startswith("$scope"):
            scope.append(line.split()[2])
        elif line.startswith("$upscope"):
            scope.pop()
        elif line.startswith("$var"):
            p = line.split()
            if p[4] in ("smt_step", "smt_clock") or p[1] == "integer":
                continue
            names[p[3]] = ".".join(scope[-2:] if len(scope) > 1 else scope) + "." + p[4]
            widths[p[3]] = int(p[2])
        elif line.startswith("#"):
            cur = dict(steps[-1]) if steps else {}
            steps.append(cur)
        elif cur is not None and line and line[0] in "01bx":
            if line[0] == "b":
                v, i = line[1:].split()
                cur[i] = v
            else:
                cur[line[1:]] = line[0]
    return names, widths, steps


def write_cex_report(job, prop, depth_fail, outdir, dest, fmap, params_note, aiw=None):
    """counterexample report: ABC found the trace; `yosys-witness aiw2yw` converts it and `yosys-smtbmc --yw` replays the
    FIXED input sequence into a VCD (z3 only checks one concrete trace, so this is fast at any depth)"""
    os.makedirs(dest, exist_ok=True)
    vcd = os.path.join(dest, "trace.vcd")
    r = dict(status="no witness available")
    aiw = aiw or os.path.join(outdir, "cex_bmc3.aiw")
    if os.path.exists(aiw) and os.path.getsize(aiw) > 0:
        yw = os.path.join(dest, "cex.yw")
        rc, out = sh(["yosys-witness", "aiw2yw", aiw, os.path.join(outdir, "model.ywa"), yw], timeout=120)
        if rc == 0 and os.path.exists(yw):
            r = eng_sim_replay(outdir, job["top"], yw, vcd)
            shutil.copy(aiw, os.path.join(dest, "cex.aiw"))
    if not os.path.exists(vcd) and depth_fail <= 4:    # last resort for tiny counterexamples only: let z3 search
        r = eng_smt_bmc(outdir, max(depth_fail + 1, 2), 60, vcd=vcd, presat=False)
    rows = ""
    if os.path.exists(vcd):
        names, widths, steps = parse_vcd(vcd)
        top = job["top"]
        ids = [i for i, n in names.items() if n.split(".")[0] == top and n.count(".") == 1 and not n.split(".")[1].startswith("$")]
        ids.sort(key=lambda i: names[i])
        hdr = "| signal | " + " | ".join("t%d" % t for t in range(len(steps))) + " |\n"
        hdr += "|---|" + "---|" * len(steps) + "\n"
        for i in ids[:60]:
            vals = []
            for s in steps:
                v = s.get(i, "?")
                vals.append(("0x%x" % int(v, 2)) if set(v) <= set("01") and widths[i] > 1 else v)
            rows += "| `%s` | %s |\n" % (names[i].split(".", 1)[1], " | ".join(vals))
    rep = ("# Counterexample: %s / %s\n\n* property: **%s** -- %s\n* failing step: %s (witness replay: %s)\n* parameters: `%s`\n"
           "* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness\n* reproduce: `python3 tools/albion_formal.py run --job %s --prop %s --force`\n\n"
           "## Signal values per step (harness top scope)\n\n%s\n") % (
        job["id"], prop["name"], prop["name"], prop["text"], depth_fail, r.get("status"), params_note, job["id"], prop["name"], rows or "(no waveform)\n")
    open(os.path.join(dest, "report.md"), "w").write(rep)
    return os.path.relpath(dest, ROOT)


# ----------------------------------------------------------------------------------------------- property / cover checks
def prof(job, quick):
    d = dict(depth=job.get("depth", 20), bmc_timeout=job.get("bmc_timeout", 120), pdr_timeout=job.get("pdr_timeout", 120),
             ind_k=job.get("ind_k", 0), cover_depth=job.get("cover_depth", 30), bmc_engine=job.get("bmc_engine", "bmc3"))
    if quick:
        d.update(depth=min(d["depth"], job.get("quick_depth", 10)), bmc_timeout=min(d["bmc_timeout"], 30),
                 pdr_timeout=min(d["pdr_timeout"], 30), cover_depth=min(d["cover_depth"], 20))
    return d


def classify(job, res):
    """final class string from the engine results"""
    asm = [a for a in job.get("assumptions", []) if a not in BASE_ASSUMPTIONS]
    st = res["status"]
    if st == "PROVED":
        return "CONDITIONAL" if asm else "INDUCTIVE"
    return st


def key_for(job, sel, p, fmap, kind):
    files = [fmap.get(f, resolve(f)) for f in job["files"]]
    return sha(TOOL_VERSION, json.dumps(tool_versions(), sort_keys=True), kind, sel, json.dumps(job.get("params", {}), sort_keys=True),
               json.dumps(job.get("defines", [])), json.dumps(sorted(p.items())), *[read(f) for f in files])


def result_path(job, name, tag=""):
    return os.path.join(RESULTS, job["id"], name + tag + ".json")


def check_assert(job, prop, quick=False, force=False, fmap=None, tag="", skip_unbounded=False, cex_dir=None):
    p = prof(job, quick)
    rp = result_path(job, prop["name"], tag)
    key = key_for(job, prop["id"], p, fmap or {}, "assert")
    if not force and os.path.exists(rp):
        old = json.load(open(rp))
        if old.get("key") == key:
            old["cached"] = True
            return old
    t0 = time.time()
    r = dict(job=job["id"], kind="assert", prop=prop["name"], prop_id=prop["id"], text=prop["text"], key=key, quick=quick,
             rtl_module=job["rtl_module"], area=job["area"], params=job.get("params", {}), assumptions=job.get("assumptions", []),
             profile=p, engines=[], tool=tool_versions(), cached=False)
    outdir, rc, out = build(job, prop["id"], "prove", "a_" + prop["name"] + tag, fmap)
    r["build_dir"] = os.path.relpath(outdir, ROOT)
    if rc != 0:
        r.update(result="ERROR", cls="ERROR", detail="yosys: " + out[-500:])
        return finish(rp, r, t0)
    st = assert_state(outdir, prop["name"])
    if st == "absent":
        r.update(result="N/A", cls="N/A", detail="assertion not elaborated in this configuration")
        return finish(rp, r, t0)
    if st == "trivial":
        r.update(result="TRIVIAL", cls="STRUCTURAL", detail="holds by construction: the condition simplifies to constant 1 in the optimised netlist (no solver needed) -- reviewed individually")
        return finish(rp, r, t0)
    # ---- bounded model check
    b = eng_bmc3(outdir, p["depth"], p["bmc_timeout"]) if p["bmc_engine"] == "bmc3" else eng_smt_bmc(outdir, p["depth"], p["bmc_timeout"])
    r["engines"].append(dict(name="bmc3" if p["bmc_engine"] == "bmc3" else "smtbmc-z3", **b))
    if b["status"] == "FAIL":
        r.update(result="FAIL", cls="FAILED", fail_depth=b["depth"])
        if cex_dir:
            r["cex"] = write_cex_report(job, prop, b["depth"], outdir, os.path.join(cex_dir, job["id"], prop["name"]), fmap,
                                        json.dumps(job.get("params", {})))
        return finish(rp, r, t0)
    if b["status"] == "VACUOUS":
        r.update(result="VACUOUS", cls="FAILED", detail="assumptions unsatisfiable")
        return finish(rp, r, t0)
    if b["status"] == "COMB":
        pd = eng_pdr(outdir, p["pdr_timeout"])
        r["engines"].append(dict(name="abc-pdr", **pd))
        if pd["status"] == "PROVED":
            r.update(result="PROVED", cls=classify(job, pd), proof="abc-pdr (state-free design: exhaustive over all inputs)")
        elif pd["status"] == "FAIL":
            r.update(result="FAIL", cls="FAILED", fail_depth=0, detail="combinational counterexample")
            if cex_dir:
                r["cex"] = write_cex_report(job, prop, 0, outdir, os.path.join(cex_dir, job["id"], prop["name"]), fmap,
                                            json.dumps(job.get("params", {})), aiw=os.path.join(outdir, "cex_pdr.aiw"))
        else:
            r.update(result="TIMEOUT", cls="TIMEOUT", detail="pdr: " + pd.get("detail", ""))
        return finish(rp, r, t0)
    bounded = b["status"] == "PASS"
    if not bounded:
        r.update(result="TIMEOUT" if b["status"] in ("TIMEOUT",) else "ERROR", cls="TIMEOUT" if b["status"] in ("TIMEOUT",) else "ERROR",
                 detail=b.get("detail", ""))
    else:
        r.update(result="BOUNDED", cls="BOUNDED", bounded_depth=b["depth"])
        if b["depth"] < p["depth"]:
            r["detail"] = "bmc reached only %d of %d frames (time budget)" % (b["depth"], p["depth"])
    # ---- unbounded attempts
    if not skip_unbounded:
        pd = eng_pdr(outdir, p["pdr_timeout"])
        r["engines"].append(dict(name="abc-pdr", **pd))
        if pd["status"] == "FAIL":
            r.update(result="FAIL", cls="FAILED", fail_depth=pd["depth"], detail="pdr counterexample (bmc did not reach this depth)")
            if cex_dir:
                r["cex"] = write_cex_report(job, prop, pd["depth"], outdir, os.path.join(cex_dir, job["id"], prop["name"]), fmap,
                                            json.dumps(job.get("params", {})), aiw=os.path.join(outdir, "cex_pdr.aiw"))
        elif pd["status"] == "PROVED":
            r.update(result="PROVED", cls=classify(job, pd), proof="abc-pdr")
        elif p["ind_k"] and bounded:
            ind = eng_induction(outdir, p["ind_k"], max(60, p["pdr_timeout"]))
            r["engines"].append(dict(name="k-induction-z3", **ind))
            if ind["status"] == "PROVED" and b["depth"] >= p["ind_k"]:
                r.update(result="PROVED", cls=classify(job, ind), proof="k-induction k=%d" % p["ind_k"])
    return finish(rp, r, t0)


def check_cover(job, cov, quick=False, force=False, fmap=None, tag=""):
    p = prof(job, quick)
    rp = result_path(job, cov["name"], tag)
    key = key_for(job, cov["id"], p, fmap or {}, "cover")
    if not force and os.path.exists(rp):
        old = json.load(open(rp))
        if old.get("key") == key:
            old["cached"] = True
            return old
    t0 = time.time()
    r = dict(job=job["id"], kind="cover", prop=cov["name"], prop_id=cov["id"], text=cov["text"], key=key, quick=quick,
             rtl_module=job["rtl_module"], area=job["area"], params=job.get("params", {}), assumptions=job.get("assumptions", []),
             profile=p, engines=[], tool=tool_versions(), cached=False)
    outdir, rc, out = build(job, cov["id"], "prove", "c_" + cov["name"] + tag, fmap, extra_defs=("ALB_COVER_AS_ASSERT",))
    r["build_dir"] = os.path.relpath(outdir, ROOT)
    if rc != 0:
        r.update(result="ERROR", cls="ERROR", detail="yosys: " + out[-500:])
        return finish(rp, r, t0)
    if assert_state(outdir, cov["name"]) == "absent":
        r.update(result="N/A", cls="N/A", detail="cover not elaborated in this configuration")
        return finish(rp, r, t0)
    # witness search: a counterexample of the 'never' assertion IS a witness trace
    b = eng_bmc3(outdir, p["cover_depth"], p["bmc_timeout"])
    r["engines"].append(dict(name="bmc3", **b))
    if b["status"] == "FAIL":
        r.update(result="REACHED", cls="COVER", witness_step=b["depth"])
        return finish(rp, r, t0)
    if b["status"] == "COMB":                                    # state-free: PDR decides exhaustively
        pd = eng_pdr(outdir, p["pdr_timeout"])
        r["engines"].append(dict(name="abc-pdr", **pd))
        if pd["status"] == "FAIL":
            r.update(result="REACHED", cls="COVER", witness_step=0)
        elif pd["status"] == "PROVED":
            r.update(result="UNREACHABLE", cls="COVER", bounded_depth=0, proof="abc-pdr")
        else:
            r.update(result="UNREACHED", cls="COVER", bounded_depth=0)
        return finish(rp, r, t0)
    if b["status"] != "PASS":
        r.update(result="ERROR", cls="ERROR", detail=b.get("detail", ""))
        return finish(rp, r, t0)
    # not reached to the depth: try to prove it unreachable for all time (PDR); else report bounded
    pd = eng_pdr(outdir, p["pdr_timeout"])
    r["engines"].append(dict(name="abc-pdr", **pd))
    if pd["status"] == "PROVED":
        r.update(result="UNREACHABLE", cls="COVER", bounded_depth=b["depth"], proof="abc-pdr")
    elif pd["status"] == "FAIL":
        r.update(result="REACHED", cls="COVER", witness_step=pd["depth"])
    else:
        r.update(result="UNREACHED", cls="COVER", bounded_depth=b["depth"])
    return finish(rp, r, t0)


def finish(rp, r, t0):
    r["secs"] = round(time.time() - t0, 2)
    r["repro"] = "python3 tools/albion_formal.py run --job %s --prop %s --force" % (r["job"], r["prop"])
    os.makedirs(os.path.dirname(rp), exist_ok=True)
    json.dump(r, open(rp, "w"), indent=1, sort_keys=True)
    return r


# ----------------------------------------------------------------------------------------------- expectations
def expected(job, name, kind):
    e = job.get("expect", {})
    if name in e:
        return e[name]
    if kind == "cover":
        return "UNREACHABLE" if name in job.get("covers_unreachable", []) else "REACHED"
    return e.get("default", "PROVED")


def verdict(job, r):
    """OK / UNEXPECTED vs the job's expectation (PROVED | BOUNDED | FAIL[:tag] | N/A | TRIVIAL | REACHED | UNREACHED)"""
    exp = expected(job, r["prop"], r["kind"])
    got = r["result"]
    e0 = exp.split(":")[0]
    if e0 == "PROVED" and got == "PROVED":
        return "OK"
    # explicit opt-in alternation "BOUNDED|PROVED": the unbounded attempt (wall-clock budgeted PDR) is borderline, so either
    # outcome is accepted; the ledger still shows the class that was actually obtained.  Any other outcome (FAILED, TIMEOUT,
    # ERROR ...) is still UNEXPECTED.
    if "|" in e0:
        return "OK" if got in e0.split("|") else "UNEXPECTED(expected %s, got %s)" % (exp, got)
    return "OK" if e0 == got else "UNEXPECTED(expected %s, got %s)" % (exp, got)


# ----------------------------------------------------------------------------------------------- commands
def cmd_list(a):
    for jid, job in load_jobs(a.job).items():
        asserts, covers, assumes = scan_props(job)
        print("%-22s %-26s params=%s  asserts=%d covers=%d assumes=%d" % (jid, job["rtl_module"], json.dumps(job.get("params", {})),
                                                                          len(asserts), len(covers), len(assumes)))
        if a.verbose:
            for p in sorted(asserts.values(), key=lambda x: x["id"]):
                print("    A%-3d %-28s %s" % (p["id"], p["name"], p["text"]))
            for p in sorted(covers.values(), key=lambda x: x["id"]):
                print("    C%-3d %-28s %s" % (p["id"], p["name"], p["text"]))


def work_items(a, jobs):
    items = []
    for jid, job in jobs.items():
        asserts, covers, _ = scan_props(job)
        names = set(a.prop) if a.prop else None
        if job.get("only"):                       # job restricted to a subset of the harness's properties
            asserts = {k: v for k, v in asserts.items() if k in job["only"]}
            covers = {k: v for k, v in covers.items() if k in job["only"]}
        for p in sorted(asserts.values(), key=lambda x: x["id"]):
            if names is None or p["name"] in names:
                items.append((job, p, "assert"))
        for c in sorted(covers.values(), key=lambda x: x["id"]):
            if names is None or c["name"] in names:
                items.append((job, c, "cover"))
    return items


def cmd_run(a):
    jobs = load_jobs(a.job)
    items = work_items(a, jobs)
    os.makedirs(BUILD, exist_ok=True)
    cexd = os.path.join(REPORTS, "counterexamples")
    bad = 0
    t0 = time.time()

    def one(it):
        job, p, kind = it
        if kind == "assert":
            return job, check_assert(job, p, a.quick, a.force, cex_dir=cexd)
        return job, check_cover(job, p, a.quick, a.force)

    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for job, r in ex.map(one, items):
            v = verdict(job, r)
            if v != "OK":
                bad += 1
            det = ""
            if r["result"] in ("PROVED", "BOUNDED"):
                det = r.get("proof") or ("depth %s" % r.get("bounded_depth"))
            print("%-24s %-30s %-9s %-11s %-22s %6.1fs %s%s" % (r["job"], r["prop"], r["kind"], r["result"], det, r["secs"], v,
                                                               " (cached)" if r.get("cached") else ""), flush=True)
    print("\n%d properties, %d unexpected, %.0fs wall" % (len(items), bad, time.time() - t0))
    return 1 if bad else 0


def load_mutants(sel=None):
    ms = []
    for fn in sorted(glob.glob(os.path.join(ROOT, "mutants", "*.json"))):
        ms += json.load(open(fn))["mutants"]
    if sel:
        ms = [m for m in ms if m["id"] in sel]
    return ms


def cmd_mutate(a):
    jobs_all = load_jobs()
    ms = load_mutants(a.mutant)
    out = []
    t0 = time.time()
    os.makedirs(os.path.join(REPORTS, "mutation"), exist_ok=True)

    def run_one(m):
        src = resolve("rtl:" + m["rtl"])
        txt = read(src)
        if txt.count(m["find"]) != 1:
            return dict(id=m["id"], status="BAD-PATCH", detail="find-text occurs %d times" % txt.count(m["find"]))
        mdir = os.path.join(BUILD, "mut", m["id"])
        os.makedirs(mdir, exist_ok=True)
        dst = os.path.join(mdir, os.path.basename(src))
        open(dst, "w").write(txt.replace(m["find"], m["replace"]))
        fmap = {"rtl:" + m["rtl"]: dst}
        killers, survivors, detail = [], [], []
        for jid in m["jobs"]:
            job = jobs_all[jid]
            asserts, _, _ = scan_props(job)
            targets = m.get("expect_fail") or sorted(asserts)
            for name in targets:
                if name not in asserts:
                    detail.append("%s: unknown property %s" % (jid, name))
                    continue
                # baseline must hold on unmutated RTL (bounded is enough here): otherwise a 'kill' would prove nothing
                base = result_path(job, name)
                if os.path.exists(base):
                    b = json.load(open(base))
                    if b["result"] == "FAIL":
                        detail.append("%s/%s fails on the baseline (known defect) -- not usable as a killer" % (jid, name))
                        continue
                mj = dict(job)
                mj["depth"] = m.get("depth", min(job.get("depth", 20), 20))
                r = check_assert(mj, asserts[name], False, True, fmap=fmap, tag="__mut_" + m["id"], skip_unbounded=True,
                                 cex_dir=os.path.join(REPORTS, "mutation", "counterexamples", m["id"]))
                (killers if r["result"] == "FAIL" else survivors).append("%s/%s" % (jid, name))
        status = "KILLED" if killers else "SURVIVED"
        return dict(id=m["id"], status=status, killed_by=killers, not_killed_by=survivors, detail=detail,
                    description=m.get("description", ""), rtl=m["rtl"], expect_fail=m.get("expect_fail", []),
                    equivalent=m.get("equivalent_note"), area=m.get("area", ""))

    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for r in ex.map(run_one, ms):
            out.append(r)
            print("%-14s %-9s killed_by=%s" % (r["id"], r["status"], ", ".join(r.get("killed_by", [])[:3])), flush=True)
    os.makedirs(os.path.join(REPORTS, "mutation", "results"), exist_ok=True)
    for r in out:                       # one file per mutant: parallel campaigns (different mutant sets) never overwrite each other
        json.dump(r, open(os.path.join(REPORTS, "mutation", "results", r["id"] + ".json"), "w"), indent=1)
    killed = sum(1 for r in out if r["status"] == "KILLED")
    print("\nmutation: %d/%d killed, %.0fs" % (killed, len(out), time.time() - t0))
    return 0 if all(r["status"] == "KILLED" or r.get("equivalent") for r in out) else 1


def cmd_selftest(a):
    """infrastructure self-checks on tiny designs whose correct verdicts are known"""
    jobs = load_jobs()
    st = [j for j in jobs if j.startswith("SELF-")]
    ok = True
    for jid in st:
        job = jobs[jid]
        asserts, covers, _ = scan_props(job)
        for p in sorted(asserts.values(), key=lambda x: x["id"]):
            r = check_assert(job, p, False, True, cex_dir=os.path.join(REPORTS, "counterexamples"))
            v = verdict(job, r)
            ok &= (v == "OK")
            print("%-22s %-26s %-9s %s" % (jid, p["name"], r["result"], v))
        for c in sorted(covers.values(), key=lambda x: x["id"]):
            r = check_cover(job, c, False, True)
            v = verdict(job, r)
            ok &= (v == "OK")
            print("%-22s %-26s %-9s %s" % (jid, c["name"], r["result"], v))
    print("selftest:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


# ----------------------------------------------------------------------------------------------- ledger
def all_results():
    rows = []
    for fn in sorted(glob.glob(os.path.join(RESULTS, "*", "*.json"))):
        if "__mut_" in fn:
            continue
        rows.append(json.load(open(fn)))
    return rows


def engine_str(r):
    parts = []
    for e in r.get("engines", []):
        n = e["name"]
        if n in ("bmc3", "smtbmc-z3"):
            if e["status"] == "COMB":
                continue
            parts.append("%s d=%s" % (n, e.get("depth")))
        elif n == "abc-pdr":
            parts.append("abc-pdr %s" % e["status"].lower() + ("" if e["status"] != "PROVED" else " (%.1fs)" % e["secs"]))
        elif n == "k-induction-z3":
            parts.append("k-ind k=%s %s" % (e.get("k"), e["status"].lower()))
        elif n == "smtbmc-z3-cover":
            parts.append("smtbmc-z3 cover d=%s" % r["profile"]["cover_depth"])
    return "; ".join(parts)


def depth_str(r):
    if r["kind"] == "cover":
        if r["result"] == "UNREACHABLE":
            return "unbounded (abc-pdr)"
        return str(r.get("witness_step", r.get("bounded_depth", "")))
    if r["result"] == "PROVED":
        return "unbounded (%s)" % r.get("proof", "")
    if r["result"] == "FAIL":
        return "cex @%s" % r.get("fail_depth")
    return str(r.get("bounded_depth", ""))


def cmd_ledger(a):
    jobs = load_jobs()
    res = all_results()
    muts = {}
    mres = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(REPORTS, "mutation", "results", "*.json")))]
    known = {m["id"] for m in load_mutants()}
    mres = [m for m in mres if m["id"] in known]          # drop results of mutants that no longer exist
    for m in mres:
        for k in m.get("killed_by", []):
            muts.setdefault(k, []).append(m["id"])
    claims = json.load(open(os.path.join(ROOT, "proofs", "claims.json")))["claims"] if os.path.exists(os.path.join(ROOT, "proofs", "claims.json")) else []
    # job-level vacuity status
    vac = {}
    for jid, job in jobs.items():
        cov = [r for r in res if r["job"] == jid and r["kind"] == "cover"]
        if not cov:
            vac[jid] = "NO COVERS"
            continue
        bad = [r["prop"] for r in cov if verdict(job, r) != "OK"]
        vac[jid] = "OK (%d/%d covers as expected)" % (len(cov) - len(bad), len(cov)) if not bad else "WARNING: " + ", ".join(bad)
    rows = []
    for r in res:
        job = jobs.get(r["job"])
        if job is None:
            continue
        v = verdict(job, r)
        rows.append(dict(
            job=r["job"], area=r["area"], rtl_module=r["rtl_module"], kind=r["kind"], property=r["prop"], text=r["text"],
            cls=r["cls"], result=r["result"], depth=depth_str(r), solver=engine_str(r), params=json.dumps(r["params"], sort_keys=True),
            assumptions=", ".join(r["assumptions"]), secs=r["secs"], verdict=v, vacuity=vac[r["job"]],
            killed_by_mutants=", ".join(sorted(muts.get("%s/%s" % (r["job"], r["prop"]), []))), repro=r["repro"],
            note=job.get("expect_notes", {}).get(r["prop"], r.get("detail", ""))))
    rows.sort(key=lambda x: (x["area"], x["job"], x["kind"], x["property"]))
    tv = tool_versions()
    os.makedirs(REPORTS, exist_ok=True)
    json.dump(dict(tools=tv, rows=rows, mutation=mres, claims=claims, vacuity=vac), open(os.path.join(REPORTS, "ledger.json"), "w"), indent=1)
    cols = ["area", "job", "rtl_module", "kind", "property", "cls", "result", "depth", "solver", "assumptions", "params", "secs",
            "verdict", "vacuity", "killed_by_mutants", "repro", "text", "note"]
    with open(os.path.join(REPORTS, "ledger.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c: r[c] for c in cols})
    write_ledger_md(rows, jobs, mres, claims, vac, tv)
    n_bad = sum(1 for r in rows if r["verdict"] != "OK")
    print("ledger: %d rows, %d unexpected -> reports/ledger.md|csv|json" % (len(rows), n_bad))
    return 1 if n_bad else 0


def write_ledger_md(rows, jobs, mres, claims, vac, tv):
    # the summary counts SilicaFlux properties only: the proof-system self-test rows (known verdicts, incl. deliberate bugs) are
    # listed in their own section below and are not part of the totals
    a = [r for r in rows if r["kind"] == "assert" and r["area"] != "Self-test"]
    cnt = lambda c: sum(1 for r in a if r["cls"] == c)
    L = []
    L.append("# AlbionFormal proof ledger (Module 94)\n")
    L.append("Generated by `tools/albion_formal.py ledger` from `reports/results/` -- every row comes from an executed run; nothing is typed in.\n")
    L.append("Tools: %s; %s; %s (`bmc3`, `pdr`); AlbionFormal %s.  SymbiYosys is **not** installed in the build environment: the engines above are driven "
             "directly (same Yosys front end and the same ABC engines SymbiYosys's `abc bmc3` / `abc pdr` use); `sby/*.sby` are generated for CI "
             "but were **not executed**.\n" % (tv["yosys"], tv["z3"], tv["abc"], tv["albion_formal"]))
    L.append("## Summary\n")
    L.append("| class | meaning | assertions |\n|---|---|---|")
    L.append("| INDUCTIVE | unbounded proof, only reset/clock assumed | %d |" % cnt("INDUCTIVE"))
    L.append("| CONDITIONAL | unbounded proof that depends on listed environment assumptions | %d |" % cnt("CONDITIONAL"))
    L.append("| STRUCTURAL | holds by construction: condition is constant 1 after optimisation (sound, no solver; each reviewed) | %d |" % cnt("STRUCTURAL"))
    L.append("| BOUNDED | no counterexample to the stated depth; no unbounded argument | %d |" % cnt("BOUNDED"))
    L.append("| FAILED | counterexample found (see `reports/counterexamples/`) | %d |" % cnt("FAILED"))
    L.append("| TIMEOUT / ERROR | no result in budget | %d |" % (cnt("TIMEOUT") + cnt("ERROR")))
    L.append("| N/A, TRIVIAL | not elaborated / constant in this configuration | %d |" % (cnt("N/A") + cnt("TRIVIAL")))
    c = [r for r in rows if r["kind"] == "cover" and r["area"] != "Self-test"]
    L.append("| COVER | %d covers: %d reached (witness), %d proved unreachable (PDR), %d unreached within depth (no proof) | %d |\n" % (
        len(c), sum(1 for r in c if r["result"] == "REACHED"), sum(1 for r in c if r["result"] == "UNREACHABLE"),
        sum(1 for r in c if r["result"] == "UNREACHED"), len(c)))
    n_self = sum(1 for r in rows if r["area"] == "Self-test")
    L.append("Per-area counts (assertions: IND / COND / STRUC / BOUNDED / FAILED / N/A):\n")
    L.append("| area | assertions | IND | COND | STRUC | BOUNDED | FAILED | N/A |\n|---|---|---|---|---|---|---|---|")
    for ar in sorted(set(r["area"] for r in a)):
        ca = [r for r in a if r["area"] == ar]
        k = lambda cl: sum(1 for r in ca if r["cls"] == cl)
        L.append("| %s | %d | %d | %d | %d | %d | %d | %d |" % (ar, len(ca), k("INDUCTIVE"), k("CONDITIONAL"), k("STRUCTURAL"), k("BOUNDED"), k("FAILED"), k("N/A") + k("TRIVIAL")))
    L.append("\nThe %d rows of the proof-system self-test (area `Self-test`) are validation of the tool chain, not SilicaFlux properties, and are excluded from the totals above.\n" % n_self)
    L.append("Unexpected results (differ from the job's recorded expectation): **%d**.\n" % sum(1 for r in rows if r["verdict"] != "OK"))
    if mres:
        k = sum(1 for m in mres if m["status"] == "KILLED")
        L.append("Mutation campaign: **%d / %d** controlled bugs detected by at least one assertion (`reports/mutation/`).\n" % (k, len(mres)))
    # full table per area
    areas = sorted(set(r["area"] for r in rows))
    for ar in areas:
        L.append("\n## %s\n" % ar)
        L.append("| RTL module | job | property | class | result | depth / proof | solver(s) | assumptions | vacuity | killed by | reproduction |")
        L.append("|---|---|---|---|---|---|---|---|---|---|---|")
        for r in [x for x in rows if x["area"] == ar]:
            L.append("| %s | %s | `%s`%s | %s | %s | %s | %s | %s | %s | %s | `%s` |" % (
                r["rtl_module"], r["job"], r["property"], " (cover)" if r["kind"] == "cover" else "", r["cls"], r["result"] + ("" if r["verdict"] == "OK" else " **!" + r["verdict"] + "**"),
                r["depth"], r["solver"], r["assumptions"], r["vacuity"].split(" ")[0], r["killed_by_mutants"] or "-", r["repro"]))
    L.append("\n## Properties and claims that are NOT proved\n")
    L.append("| item | status | reason |\n|---|---|---|")
    for r in a:
        if r["cls"] in ("BOUNDED", "FAILED", "TIMEOUT", "ERROR", "N/A"):
            L.append("| %s / `%s` | %s | %s |" % (r["job"], r["property"], r["cls"] + (" " + r["depth"] if r["cls"] == "BOUNDED" else ""), (r["note"] or "").replace("|", "/")))
    for cl in claims:
        L.append("| %s | %s | %s |" % (cl["id"] + " " + cl["text"], cl["status"], cl["reason"].replace("|", "/")))
    L.append("\n## Per-job vacuity checks\n")
    L.append("| job | covers |\n|---|---|")
    for jid in sorted(vac):
        L.append("| %s | %s |" % (jid, vac[jid]))
    if mres:
        L.append("\n## Mutation campaign\n")
        L.append("| mutant | RTL | status | killed by | description |\n|---|---|---|---|---|")
        for m in mres:
            L.append("| %s | %s | %s | %s | %s |" % (m["id"], m.get("rtl", ""), m["status"] + (" (equivalent: %s)" % m["equivalent"] if m.get("equivalent") else ""),
                                                  ", ".join(m.get("killed_by", [])[:4]), m.get("description", "")))
    open(os.path.join(REPORTS, "ledger.md"), "w").write("\n".join(L) + "\n")


# ----------------------------------------------------------------------------------------------- sby generation
def cmd_sby(a):
    os.makedirs(os.path.join(ROOT, "sby"), exist_ok=True)
    for jid, job in load_jobs().items():
        if jid.startswith("SELF-"):
            continue
        p = prof(job, False)
        files = [os.path.relpath(resolve(f), os.path.join(ROOT, "sby")) for f in job["files"]]
        names = [os.path.basename(f) for f in files]
        inc = " ".join("-I../%s" % os.path.relpath(d, ROOT) for d in dirs_for(job))
        cp = "".join("chparam -set %s %s %s\n" % (k, ('"%s"' % v) if isinstance(v, str) else v, job["top"]) for k, v in job.get("params", {}).items())
        txt = ("# GENERATED by tools/albion_formal.py sby -- NOT EXECUTED in the build environment (SymbiYosys not installed).\n"
               "# Evidence in reports/ledger.md comes from the native runner; this file runs ALL assertions of the harness together.\n"
               "[tasks]\nbmc\nprove\ncover\n\n[options]\nbmc: mode bmc\nbmc: depth %d\nprove: mode prove\ncover: mode cover\ncover: depth %d\n\n"
               "[engines]\nbmc: abc bmc3\nprove: abc pdr\ncover: smtbmc z3\n\n[script]\nread_verilog -sv -formal -DFORMAL -DSYNTHESIS %s %s\n%sprep -top %s\n\n[files]\n%s\n"
               % (p["depth"], p["cover_depth"], inc, " ".join(names), cp, job["top"], "\n".join(files)))
        open(os.path.join(ROOT, "sby", jid + ".sby"), "w").write(txt)
    print("wrote sby/*.sby (not executed)")


def cmd_catalogue(a):
    """docs/PROPERTY_CATALOGUE.md generated from the harness sources + manifests (no hand-maintained copy)"""
    jobs = load_jobs()
    by_h = {}
    for jid, job in jobs.items():
        if jid.startswith("SELF-"):
            continue
        h = [f for f in job["files"] if f.startswith("harness/")][-1]
        by_h.setdefault((job["area"], h), []).append(job)
    L = ["# Property catalogue (generated by `tools/albion_formal.py catalogue` -- do not edit)\n",
         "Every assertion (A), cover (C) and assumption (E) found in the harness sources, with the jobs (parameter points) that run it.\n"]
    for (area, h), js in sorted(by_h.items()):
        a, c, e = scan_props(js[0])
        L.append("\n## %s -- `%s`\n" % (area, h))
        L.append("RTL module: %s.  Jobs: %s\n" % (", ".join(sorted(set(j["rtl_module"] for j in js))), ", ".join("`%s`" % j["id"] for j in js)))
        L.append("| id | name | kind | statement |\n|---|---|---|---|")
        for p_ in sorted(a.values(), key=lambda x: x["id"]):
            L.append("| A%d | `%s` | assert | %s |" % (p_["id"], p_["name"], p_["text"].replace("|", "/")))
        for p_ in sorted(c.values(), key=lambda x: x["id"]):
            L.append("| C%d | `%s` | cover | %s |" % (p_["id"], p_["name"], p_["text"].replace("|", "/")))
        for p_ in sorted(e.values(), key=lambda x: x["name"]):
            L.append("| E | `%s` | assume | %s |" % (p_["name"], p_["text"].replace("|", "/")))
    open(os.path.join(ROOT, "docs", "PROPERTY_CATALOGUE.md"), "w").write("\n".join(L) + "\n")
    print("docs/PROPERTY_CATALOGUE.md written")


def cmd_check(a):
    rc, out = sh([sys.executable, os.path.join(ROOT, "tools", "vendor_rtl.py"), "--check"])
    print(out.strip())
    if rc:
        return 1
    return cmd_ledger(a)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    for name in ("list", "run", "mutate", "selftest", "ledger", "sby", "check", "catalogue"):
        s = sp.add_parser(name)
        s.add_argument("--job", nargs="*")
        s.add_argument("--prop", nargs="*")
        s.add_argument("--mutant", nargs="*")
        s.add_argument("--quick", action="store_true")
        s.add_argument("--force", action="store_true")
        s.add_argument("--verbose", "-v", action="store_true")
        s.add_argument("--jobs", type=int, default=max(1, (os.cpu_count() or 2)))
    a = ap.parse_args()
    return dict(list=cmd_list, run=cmd_run, mutate=cmd_mutate, selftest=cmd_selftest, ledger=cmd_ledger, sby=cmd_sby, check=cmd_check, catalogue=cmd_catalogue)[a.cmd](a) or 0


if __name__ == "__main__":
    sys.exit(main())
