#!/bin/sh
# AlbionFormal CI entry point.   sh ci/run_ci.sh quick|full
#   quick : tool check, RTL pins, proof-system self-test, FORCED re-proof of one representative job per area,
#           ledger consistency (exit 1 on any UNEXPECTED result in the stored evidence)   ~ minutes
#   full  : everything above + FORCED re-proof of every job + full mutation campaign + ledger   ~ hours on 4 cores
# The stored results in reports/results/ are keyed by a hash of RTL + harness + parameters + tool versions;
# `--force` bypasses that cache so CI really re-runs the solvers.
set -eu
cd "$(dirname "$0")/.."
MODE="${1:-quick}"
PY="python3 -I"
RUN="$PY tools/albion_formal.py"
JOBS="${JOBS:-2}"
for t in yosys yosys-abc yosys-smtbmc yosys-witness z3; do
  command -v "$t" >/dev/null 2>&1 || { echo "missing tool: $t"; exit 2; }
done
yosys -V; z3 --version
$PY tools/vendor_rtl.py --check
$RUN selftest
case "$MODE" in
  quick)
    $RUN run --force --jobs "$JOBS" --job FAB-ARB-RR3 FAB-DEC-A FAB-SKID-W4 FAB-XBAR-2x2-RR
    for j in $($PY - <<'PYEOF'
import json,glob,os
for f in sorted(glob.glob("proofs/*.json")):
    if os.path.basename(f) in ("claims.json","selftest.json","fabric.json"): continue
    d=json.load(open(f)); print(d["jobs"][0]["id"])
PYEOF
    ); do $RUN run --force --jobs "$JOBS" --job "$j"; done
    ;;
  full)
    $RUN run --force --jobs "$JOBS"
    $RUN mutate --jobs "$JOBS"
    ;;
  *) echo "usage: $0 quick|full"; exit 2;;
esac
$RUN sby
$RUN check            # verifies pins again, rebuilds reports/ledger.*, exits 1 on any UNEXPECTED row
echo "AlbionFormal CI ($MODE): OK"
