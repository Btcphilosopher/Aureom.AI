# Counterexample: SEC-PERM-A / a_status_from_reason

* property: **a_status_from_reason** -- [02] status is a pure coarse function of the reason (OK / BAD_OP / BAD_ATTR / everything else ACCESS_DENIED)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_status_from_reason)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_status_from_reason --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 1 | 1 |
| `a_secure` | 0 | 0 |
| `addr_i` | 0xf8 | 0xf8 |
| `attr_i` | 0x84 | 0x84 |
| `bind_i` | 0x0 | 0x0 |
| `cls_i` | 0x1 | 0x1 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x94 | 0x94 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `k` | 0x2 | 0x2 |
| `len_i` | 0xfd | 0xfd |
| `lockdown_i` | 1 | 1 |
| `op_i` | 0x0 | 0x0 |
| `permit_o` | 0 | 0 |
| `port_isol_i` | 0x1 | 0x1 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x0 | 0x0 |
| `reason_o` | 0xd | 0xd |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x102 | 0x102 |
| `slot_o` | 0 | 0 |
| `slot_priv_i` | 0x0 | 0x0 |
| `slot_secure_i` | 0x0 | 0x0 |
| `slot_state_i` | 0x0 | 0x0 |
| `slot_vld_o` | 0 | 0 |
| `src_i` | 0 | 0 |
| `status_o` | 0x1 | 0x1 |
| `win_base_i` | 0xc000000 | 0xc000000 |
| `win_limit_i` | 0xf8 | 0xf8 |
| `win_r_i` | 0x0 | 0x0 |
| `win_valid_i` | 0x1 | 0x1 |
| `win_w_i` | 0x1 | 0x1 |
| `win_x_i` | 0x0 | 0x0 |

