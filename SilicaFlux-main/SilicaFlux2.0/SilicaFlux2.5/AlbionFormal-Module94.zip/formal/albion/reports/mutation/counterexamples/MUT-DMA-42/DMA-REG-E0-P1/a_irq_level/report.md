# Counterexample: DMA-REG-E0-P1 / a_irq_level

* property: **a_irq_level** -- [DMA.md 6] irq == |(INT_STATUS & INT_ENABLE), level sensitive (set wins over W1C in the model)
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_dma_regs.a_irq_level)
* parameters: `{"DW": 32, "ENGINE": 0, "FIFO_DEPTH": 1, "MAX_LEN_LOG2": 24, "PERF": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-REG-E0-P1 --prop a_irq_level --force`

## Signal values per step (harness top scope)

| `busy` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `bytes_done` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `done` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `err_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `err_code` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `ev_stall` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fail` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `irq` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_ie` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x2 | 0x2 | 0x2 |
| `m_info` | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 |
| `m_is` | 0x0 | 0x0 | 0x0 | 0x0 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `rb_addr` | 0x0 | 0x0 | 0x1c | 0x1c | 0x18 | 0x18 | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rb_wdata` | 0x0 | 0x0 | 0x2 | 0x2 | 0x2 | 0x2 | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `state` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `wr` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |

