# Counterexample: SEC-PERM-A / a_permit_implies_spec

* property: **a_permit_implies_spec** -- [02] permit => an enrolled, ACTIVE, capable slot bound to src_i owns the request (priority-free declarative predicate)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_permit_implies_spec)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_permit_implies_spec --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 1 | 1 |
| `active` | 0x3 | 0x3 |
| `addr_i` | 0xe0 | 0xe0 |
| `addr_ok` | 0x0 | 0x0 |
| `attr_i` | 0x8 | 0x8 |
| `base_ok` | 1 | 1 |
| `bind_i` | 0x3 | 0x3 |
| `bound` | 0x3 | 0x3 |
| `cap_priv_ok` | 0x3 | 0x3 |
| `cap_sec_ok` | 0x3 | 0x3 |
| `capab` | 0x3 | 0x3 |
| `cls_i` | 0x0 | 0x0 |
| `dev_any` | 1 | 1 |
| `dev_in` | 0x2 | 0x2 |
| `dev_ok` | 0x0 | 0x0 |
| `dev_one` | 1 | 1 |
| `dev_ov` | 0x2 | 0x2 |
| `dev_whole` | 1 | 1 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x85 | 0x85 |
| `form_ok` | 1 | 1 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `is_sys` | 0 | 0 |
| `k` | 0x2 | 0x2 |
| `last` | 0xe1 | 0xe1 |
| `last_w` | 0xe1 | 0xe1 |
| `len_i` | 0x2 | 0x2 |
| `lockdown_i` | 0 | 0 |
| `match` | 0x2 | 0x2 |
| `mem_ok` | 0x2 | 0x2 |
| `no_wrap` | 1 | 1 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `q_ok` | 0x3 | 0x3 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0xa | 0xa |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x85a5 | 0x85a5 |
| `slot_o` | 1 | 1 |
| `slot_ok` | 0x2 | 0x2 |
| `slot_priv_i` | 0x3 | 0x3 |
| `slot_secure_i` | 0x3 | 0x3 |
| `slot_state_i` | 0xa | 0xa |
| `slot_vld_o` | 1 | 1 |
| `spec_exist` | 0 | 0 |
| `src_i` | 0 | 0 |
| `src_isol` | 0 | 0 |
| `win_base_i` | 0x9892181 | 0x9892181 |
| `win_limit_i` | 0xf9eb0202 | 0xf9eb0202 |
| `win_r_i` | 0xa | 0xa |
| `win_valid_i` | 0xf | 0xf |
| `win_w_i` | 0x7 | 0x7 |
| `win_x_i` | 0x0 | 0x0 |

