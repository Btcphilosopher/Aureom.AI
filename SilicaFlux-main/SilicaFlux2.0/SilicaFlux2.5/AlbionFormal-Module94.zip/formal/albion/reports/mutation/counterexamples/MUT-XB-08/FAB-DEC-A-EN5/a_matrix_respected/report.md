# Counterexample: FAB-DEC-A-EN5 / a_matrix_respected

* property: **a_matrix_respected** -- [R8] a slave disabled for this master in MST_SLV_EN is never selected
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sfb_decoder.a_matrix_respected)
* parameters: `{"NS": 3, "AW": 6, "DW": 16, "CHECK_ALIGN": 1, "SLV_BASE": 132096, "SLV_MASK": 232496, "EN": 5}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-DEC-A-EN5 --prop a_matrix_respected --force`

## Signal values per step (harness top scope)

| `addr` | 0x10 | 0x10 |
| `enabled_ok` | 0 | 0 |
| `hit` | 1 | 1 |
| `misaligned` | 0 | 0 |
| `s` | 0x3 | 0x3 |
| `sel` | 0x1 | 0x1 |
| `sel_oh` | 0x2 | 0x2 |
| `t` | 0x3 | 0x3 |

