# Counterexample: SEC-GATE-B / a_fwd_payload_bit

* property: **a_fwd_payload_bit** -- [04 s2 / G2] the presented request is bit-for-bit the accepted request (checked for a solver-chosen bit)
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_cit_gate.a_fwd_payload_bit)
* parameters: `{"OUT_W": 2, "TGT_OK": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-GATE-B --prop a_fwd_payload_bit --force`

## Signal values per step (harness top scope)

| `bi` | 0xd8 | 0xd8 | 0xd8 | 0xd8 | 0xd8 | 0xd8 | 0xd8 |
| `bi_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `chk_addr_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_attr_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_cls_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_dom_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `chk_idx_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_len_o` | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 |
| `chk_op_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_permit_i` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `chk_status_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_valid_o` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `clk_i` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `flush_i` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `m_bit` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `m_req_i` | 0x0 | 0x0 | 0x1000000000000000000000000000000000000000000000000000000 | 0x1000000000000000000000000000000000000000000000000000000 | 0x0 | 0x0 | 0x0 |
| `m_req_ready_o` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `m_req_valid_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `m_rsp_ready_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `outstanding_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `p_tbit2` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_thold2` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `r_bit_t` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ri` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `ri_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rst_ni` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `s_acc` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `s_bit` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_fwd` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `t_bit` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `t_req_o` | 0x1000000000000000000000000000000000000000000000000000000 | 0x1000000000000000000000000000000000000000000000000000000 | 0x1000000000000000000000000000000000000000000000000000000 | 0x1000000000000000000000000000000000000000000000000000000 | 0x0 | 0x0 | 0x0 |
| `t_req_ready_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `t_req_valid_o` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `t_rsp_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `t_rsp_ready_o` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `t_rsp_valid_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tgt_out` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |

