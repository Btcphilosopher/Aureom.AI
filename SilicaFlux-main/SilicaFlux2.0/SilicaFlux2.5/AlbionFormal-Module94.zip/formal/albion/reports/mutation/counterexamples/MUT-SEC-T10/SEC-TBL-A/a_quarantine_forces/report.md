# Counterexample: SEC-TBL-A / a_quarantine_forces

* property: **a_quarantine_forces** -- [03] the containment hook forces an enrolled slot to QUARANTINED (a same-cycle REVOKE wins)
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_cit_table.a_quarantine_forces)
* parameters: `{"AW": 4, "DEV_BASE": 140, "DEV_MASK": 204}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-TBL-A --prop a_quarantine_forces --force`

## Signal values per step (harness top scope)

| `allstate` | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00010000000000001000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00010000000000001000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00010000000000001000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00010000000000001000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00010000000000001000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 |
| `bind_o` | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx |
| `cfg_en_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `clk_i` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `cmd_arg_dom_i` | 0x0 | 0x0 | 0x8 | 0x8 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_data0_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_data1_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_dom_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_flags_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_op_i` | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_port_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `cmd_priv_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `cmd_slot_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `cmd_valid_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `cmd_win_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `d` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `devrd_o` | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx |
| `devwr_o` | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx |
| `fs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fs_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `i` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `j` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `k` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `lock_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `look_dom_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `own_addr_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `p_cmdv` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `p_op` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 |
| `p_qtn_slot` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_qtn_v` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `p_slot` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_slot_is_fs` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `p_stfs` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `pp` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `qtn_slot_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `qtn_valid_i` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `revoke_ok` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_status_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rst_ni` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `sl` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 01xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 01xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 01xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 01xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 01xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `slot_id_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 |
| `slot_state_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `st_fs` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `wb_fs` | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx |
| `wex_fs` | xx | xx | xx | xx | xx | xx | xx | xx | xx |
| `win_base_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `win_excl_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `win_limit_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `win_valid_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `wl_fs` | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx |
| `wr_fs` | xx | xx | xx | xx | xx | xx | xx | xx | xx |
| `wv_fs` | xx | xx | xx | xx | xx | xx | xx | xx | xx |
| `ww_fs` | xx | xx | xx | xx | xx | xx | xx | xx | xx |
| `wx_fs` | xx | xx | xx | xx | xx | xx | xx | xx | xx |

