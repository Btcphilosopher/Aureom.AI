# Counterexample: FAB-SKID-W4 / a_no_overflow

* property: **a_no_overflow** -- no item is accepted when 2 are stored: s_ready is low when full
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_sfb_skid.a_no_overflow)
* parameters: `{"WIDTH": 4}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-SKID-W4 --prop a_no_overflow --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `cnt` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x2 | 0x2 | 0x2 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `pop` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `push` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s_data` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_ready` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s_valid` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |

