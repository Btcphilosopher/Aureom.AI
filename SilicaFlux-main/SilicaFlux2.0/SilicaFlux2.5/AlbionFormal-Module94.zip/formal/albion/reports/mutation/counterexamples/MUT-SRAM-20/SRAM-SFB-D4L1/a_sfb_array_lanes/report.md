# Counterexample: SRAM-SFB-D4L1 / a_sfb_array_lanes

* property: **a_sfb_array_lanes** -- [R7,R10] the array holds exactly what the strobed writes put there: reads return the shadow on every known lane, masked lanes untouched, never-written lanes unchanged
* failing step: 3 (witness replay: replayed (no assertion fired -- inspect trace))
* parameters: `{"DW": 16, "DEPTH": 4, "LAT": 1, "ASSUME_R2": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-SFB-D4L1 --prop a_sfb_array_lanes --force`

## Signal values per step (harness top scope)

| `acc` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `addr_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `arr_ad` | 0x1 | 0x1 | 0x3 | 0x3 | 0x3 | 0x3 | 0x0 | 0x0 | 0x0 |
| `arr_ce` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `arr_wd` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `arr_we` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `arr_wm` | 0x0 | 0x0 | 0x3 | 0x3 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_held` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_stable_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ok_id` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ok_raw` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ok_we` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `qcount` | 0xxx | 0xxx | 0xxx | 0xxx | 0xxx | 0xxx | 0xxx | 0xxx | 0xxx |
| `req_addr` | 0x2 | 0x2 | 0x6 | 0x6 | 0x6 | 0x6 | 0x0 | 0x0 | 0x0 |
| `req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_write` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `req_wstrb` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `t_on` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `ta` | 0x3 | 0x3 | 0x3 | 0x3 | 0x3 | 0x3 | 0x3 | 0x3 | 0x3 |
| `tst_active` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `tst_addr` | 0x0 | 0x0 | 0x3 | 0x3 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 |
| `tst_ce` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `tst_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `tst_rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_we` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `wi` | 0x1 | 0x1 | 0x3 | 0x3 | 0x3 | 0x3 | 0x0 | 0x0 | 0x0 |

