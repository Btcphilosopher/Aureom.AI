# Counterexample: FAB-DEC-OVL / a_lowest_wins

* property: **a_lowest_wins** -- overlapping regions resolve to the lowest permitted slave index
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sfb_decoder.a_lowest_wins)
* parameters: `{"NS": 2, "AW": 6, "DW": 16, "CHECK_ALIGN": 1, "SLV_BASE": 1024, "SLV_MASK": 3104, "EN": 3}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-DEC-OVL --prop a_lowest_wins --force`

## Signal values per step (harness top scope)

| `addr` | 0x10 | 0x10 |
| `enabled_ok` | 1 | 1 |
| `hit` | 1 | 1 |
| `in_region` | 1 | 1 |
| `lowest_ok` | 0 | 0 |
| `misaligned` | 0 | 0 |
| `s` | 0x2 | 0x2 |
| `sel` | 1 | 1 |
| `sel_oh` | 0x2 | 0x2 |
| `t` | 0x2 | 0x2 |

