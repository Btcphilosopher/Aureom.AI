# Counterexample: FAB-ARB-RR5 / a_grant_subset_req

* property: **a_grant_subset_req** -- a grant is only given to an asserted request
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sfb_arbiter.a_grant_subset_req)
* parameters: `{"N": 5, "MODE": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-ARB-RR5 --prop a_grant_subset_req --force`

## Signal values per step (harness top scope)

| `accept` | 0 | 0 | 0 |
| `clk` | 1 | 0 | 0 |
| `grant` | 0x3 | 0x3 | 0x3 |
| `grant_idx` | 0x0 | 0x0 | 0x0 |
| `grant_valid` | 1 | 1 | 1 |
| `init_q` | 1 | 1 | 1 |
| `req` | 0x1 | 0x1 | 0x1 |
| `rst_n` | 0 | 0 | 0 |
| `stall` | 0 | 0 | 0 |

