# Counterexample: FAB-RSLICE-11 / a_req_in_order

* property: **a_req_in_order** -- [R5/R12] request payloads reach the slave side in order, unmodified, none duplicated
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_sfb_reg_slice.a_req_in_order)
* parameters: `{"AW": 2, "DW": 8, "REQ_SLICE": 1, "RSP_SLICE": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-RSLICE-11 --prop a_req_in_order --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `m_req_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_req_write` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_req_wstrb` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_rsp_error` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rmem[0][11:0]` | 0x0 | 0x0 | 0x0 | 0x0 | 0x2 | 0x2 | 0x2 |
| `rmem[1][11:0]` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rmem[2][11:0]` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rmem[3][11:0]` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rpop` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rpush` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rq_in` | 0x0 | 0x0 | 0x2 | 0x2 | 0x0 | 0x0 | 0x0 |
| `rq_out` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `rrp` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rs_in` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `rwp` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `s_req_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_req_ready` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s_req_valid` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `s_req_wdata` | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 |
| `s_req_write` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_req_wstrb` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

