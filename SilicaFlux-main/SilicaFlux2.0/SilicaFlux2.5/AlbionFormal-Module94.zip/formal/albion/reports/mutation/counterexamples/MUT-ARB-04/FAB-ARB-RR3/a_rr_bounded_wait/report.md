# Counterexample: FAB-ARB-RR3 / a_rr_bounded_wait

* property: **a_rr_bounded_wait** -- [PROTOCOL 4] round robin: a continuously asserted request sees at most N-1 accepted grants to others
* failing step: 4 (witness replay: CONFIRMED: simulation violates fv_sfb_arbiter.a_rr_bounded_wait)
* parameters: `{"N": 3, "MODE": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-ARB-RR3 --prop a_rr_bounded_wait --force`

## Signal values per step (harness top scope)

| `accept` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `grant_idx` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `grant_valid` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `k` | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `k_valid` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `req` | 0x0 | 0x0 | 0x3 | 0x3 | 0x3 | 0x3 | 0x3 | 0x3 | 0x0 | 0x0 | 0x0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `stall` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `wcnt` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x2 | 0x2 | 0x3 | 0x3 | 0x3 |

