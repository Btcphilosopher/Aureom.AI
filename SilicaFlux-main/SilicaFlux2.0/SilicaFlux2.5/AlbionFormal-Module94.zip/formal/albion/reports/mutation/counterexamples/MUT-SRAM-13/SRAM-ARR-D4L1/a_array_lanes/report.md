# Counterexample: SRAM-ARR-D4L1 / a_array_lanes

* property: **a_array_lanes** -- [spec 3.2,3.3] data read EXACTLY READ_LATENCY cycles after the read edge equals the shadow on every known lane (writes, masked writes, unwritten lanes)
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_sram_array.a_array_lanes)
* parameters: `{"DW": 16, "MW": 2, "DEPTH": 4, "LAT": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-ARR-D4L1 --prop a_array_lanes --force`

## Signal values per step (harness top scope)

| `addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `ce` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ok_id` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ok_raw` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `ok_we` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `qcount` | 00xx | 00xx | 00xx | 00xx | 00xx | 00xx | 00xx | 00xx | 00xx |
| `rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ta` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `wdata` | 0x0 | 0x0 | 0x8000 | 0x8000 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `we` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `wmask` | 0x0 | 0x0 | 0x2 | 0x2 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |

