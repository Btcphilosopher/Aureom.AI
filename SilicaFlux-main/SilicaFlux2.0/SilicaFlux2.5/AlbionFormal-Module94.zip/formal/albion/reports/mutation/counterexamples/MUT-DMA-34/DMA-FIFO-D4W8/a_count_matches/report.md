# Counterexample: DMA-FIFO-D4W8 / a_count_matches

* property: **a_count_matches** -- occupancy == pushes - pops since reset/clear (exact accounting, nothing lost or duplicated)
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_dma_fifo.a_count_matches)
* parameters: `{"WIDTH": 8, "DEPTH": 4, "TAGW": 3}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-FIFO-D4W8 --prop a_count_matches --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `clr` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `count` | 0x0 | 0x0 | 0x0 | 0x0 | 0x2 | 0x2 | 0x2 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `m_cnt` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `pop` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `push` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |

