# Counterexample: DMA-VAL-DW16-L6 / a_none_iff_legal

* property: **a_none_iff_legal** -- [DMA.md 2] NONE <=> descriptor legal (no rule fails)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_validate.a_none_iff_legal)
* parameters: `{"DW": 16, "MAX_LEN_LOG2": 6}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-VAL-DW16-L6 --prop a_none_iff_legal --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `code` | 0x5 | 0x5 | 0x5 |
| `dst` | 0x0 | 0x0 | 0x0 |
| `dst_q` | 0x0 | 0x0 | 0x0 |
| `dst_r` | 0x0 | 0x0 | 0x0 |
| `f_dalign` | 0 | 0 | 0 |
| `f_dovf` | 0 | 0 | 0 |
| `f_long` | 0 | 0 | 0 |
| `f_ovl` | 0 | 0 | 0 |
| `f_salign` | 0 | 0 | 0 |
| `f_sovf` | 0 | 0 | 0 |
| `f_zero` | 0 | 0 | 0 |
| `legal` | 1 | 1 | 1 |
| `len` | 0x0 | 0x0 | 0x0 |
| `len_q` | 0x10 | 0x10 | 0x10 |
| `len_r` | 0x10 | 0x10 | 0x10 |
| `rcode` | 0xxx | 0xxx | 0xxx |
| `src` | 0x0 | 0x0 | 0x0 |
| `src_q` | 0xfffffff0 | 0xfffffff0 | 0xfffffff0 |
| `src_r` | 0xfffffff0 | 0xfffffff0 | 0xfffffff0 |

