# Counterexample: SRAM-SECMON / a_reset_clears_lock

* property: **a_reset_clears_lock** -- reset clears HOST_LOCK (documented reset control state)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_prot_secmon.a_reset_clears_lock)
* parameters: `{}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-SECMON --prop a_reset_clears_lock --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `host_lock` | 1 | 1 | 1 |
| `init_q` | 1 | 1 | 1 |
| `rb_addr` | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 0 | 0 | 0 |
| `rb_wdata` | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 0 |
| `viol_addr` | 0x0 | 0x0 | 0x0 |
| `viol_evt` | 0 | 0 | 0 |

