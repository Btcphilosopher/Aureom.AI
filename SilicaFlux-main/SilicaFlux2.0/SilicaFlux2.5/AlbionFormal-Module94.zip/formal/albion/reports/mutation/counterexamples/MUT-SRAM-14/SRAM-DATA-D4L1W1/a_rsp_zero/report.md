# Counterexample: SRAM-DATA-D4L1W1 / a_rsp_zero

* property: **a_rsp_zero** -- [spec 4] read data of write acknowledgements and error responses is all-zero
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_sram_sp_data.a_rsp_zero)
* parameters: `{"DW": 16, "MW": 2, "DEPTH": 4, "LAT": 1, "FIFO": 2, "WACK": 1, "IDW": 2}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-DATA-D4L1W1 --prop a_rsp_zero --force`

## Signal values per step (harness top scope)

| `acc` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `needs_rsp` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ok_zero` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `qcount` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `req_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_id` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_we` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `req_wmask` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_rdata` | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 |
| `rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `t_on` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ta` | xx | xx | xx | xx | xx | xx | xx | xx | xx |
| `tst_active` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tst_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_ce` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tst_rdata` | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 | 0x4000 |
| `tst_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_we` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

