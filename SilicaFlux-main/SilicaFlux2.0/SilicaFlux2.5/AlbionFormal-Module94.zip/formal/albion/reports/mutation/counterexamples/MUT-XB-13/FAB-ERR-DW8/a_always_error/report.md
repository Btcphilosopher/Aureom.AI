# Counterexample: FAB-ERR-DW8 / a_always_error

* property: **a_always_error** -- [R8] every response is an error
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_sfb_error_slave.a_always_error)
* parameters: `{"DW": 8}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-ERR-DW8 --prop a_always_error --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `req_ready` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `req_valid` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rsp_error` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |

