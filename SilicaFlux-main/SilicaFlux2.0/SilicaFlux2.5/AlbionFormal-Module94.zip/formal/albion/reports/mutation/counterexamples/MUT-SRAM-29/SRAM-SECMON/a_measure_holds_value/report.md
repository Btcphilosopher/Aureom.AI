# Counterexample: SRAM-SECMON / a_measure_holds_value

* property: **a_measure_holds_value** -- [BOOT_MEASURE] reads return the first value written, whatever is written later; 0 before the first write
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_prot_secmon.a_measure_holds_value)
* parameters: `{}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-SECMON --prop a_measure_holds_value --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `host_lock` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_d` | 0x0 | 0x0 | 0x0 | 0x0 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 |
| `m_v` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `meas_acc` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `meas_wr` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rb_addr` | 0x0 | 0x0 | 0xc | 0xc | 0xc | 0xc | 0xc | 0xc | 0xc |
| `rb_err` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rb_rdata` | 0x70 | 0x70 | 0x0 | 0x0 | 0x10 | 0x10 | 0x90 | 0x90 | 0x90 |
| `rb_sel` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rb_wdata` | 0x0 | 0x0 | 0x10 | 0x10 | 0x90 | 0x90 | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `viol_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `viol_evt` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `wr` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |

