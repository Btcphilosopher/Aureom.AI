# Counterexample: SEC-PERM-A / a_permit_implies_spec

* property: **a_permit_implies_spec** -- [02] permit => an enrolled, ACTIVE, capable slot bound to src_i owns the request (priority-free declarative predicate)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_permit_implies_spec)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_permit_implies_spec --force`

## Signal values per step (harness top scope)

| `a_instr` | 1 | 1 |
| `a_priv` | 0 | 0 |
| `a_secure` | 1 | 1 |
| `active` | 0x2 | 0x2 |
| `addr_i` | 0xe3 | 0xe3 |
| `addr_ok` | 0x0 | 0x0 |
| `attr_i` | 0x18 | 0x18 |
| `base_ok` | 1 | 1 |
| `bind_i` | 0x0 | 0x0 |
| `bound` | 0x0 | 0x0 |
| `cap_priv_ok` | 0x3 | 0x3 |
| `cap_sec_ok` | 0x2 | 0x2 |
| `capab` | 0x2 | 0x2 |
| `cls_i` | 0x1 | 0x1 |
| `dev_any` | 1 | 1 |
| `dev_in` | 0x2 | 0x2 |
| `dev_ok` | 0x0 | 0x0 |
| `dev_one` | 1 | 1 |
| `dev_ov` | 0x2 | 0x2 |
| `dev_whole` | 1 | 1 |
| `devrd_i` | 0xc | 0xc |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x40 | 0x40 |
| `form_ok` | 1 | 1 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `is_sys` | 0 | 0 |
| `k` | 0x2 | 0x2 |
| `last` | 0xe0 | 0xe0 |
| `last_w` | 0x1e0 | 0x1e0 |
| `len_i` | 0xfe | 0xfe |
| `lockdown_i` | 0 | 0 |
| `match` | 0x2 | 0x2 |
| `mem_ok` | 0x0 | 0x0 |
| `no_wrap` | 0 | 0 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `q_ok` | 0x3 | 0x3 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0xa | 0xa |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x4012 | 0x4012 |
| `slot_o` | 1 | 1 |
| `slot_ok` | 0x0 | 0x0 |
| `slot_priv_i` | 0x0 | 0x0 |
| `slot_secure_i` | 0x2 | 0x2 |
| `slot_state_i` | 0x8 | 0x8 |
| `slot_vld_o` | 1 | 1 |
| `spec_exist` | 0 | 0 |
| `src_i` | 0 | 0 |
| `src_isol` | 0 | 0 |
| `win_base_i` | 0x9090909 | 0x9090909 |
| `win_limit_i` | 0xa1a8a3a1 | 0xa1a8a3a1 |
| `win_r_i` | 0x0 | 0x0 |
| `win_valid_i` | 0x0 | 0x0 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

