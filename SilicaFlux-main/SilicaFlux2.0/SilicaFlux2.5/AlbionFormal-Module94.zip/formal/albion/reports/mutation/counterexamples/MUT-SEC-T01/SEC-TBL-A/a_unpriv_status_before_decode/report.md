# Counterexample: SEC-TBL-A / a_unpriv_status_before_decode

* property: **a_unpriv_status_before_decode** -- [03] privilege is checked BEFORE the opcode is decoded: even opcode 0 from an unprivileged requester is answered BAD_PRIV / NOT_AUTH, never BAD_CMD
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_cit_table.a_unpriv_status_before_decode)
* parameters: `{"AW": 4, "DEV_BASE": 140, "DEV_MASK": 204}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-TBL-A --prop a_unpriv_status_before_decode --force`

## Signal values per step (harness top scope)

| `allstate` | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 | 00000000000000000000xxxx0000xxxxxxxxxxxx000000000000000000000000000000000000xxxxxxxxxxxxxxxxxxxx0 |
| `bind_o` | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx |
| `cfg_en_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `clk_i` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `cmd_arg_dom_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_data0_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_data1_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_dom_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_flags_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_op_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cmd_port_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `cmd_priv_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `cmd_slot_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `cmd_valid_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `cmd_win_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `d` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `devrd_o` | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx |
| `devwr_o` | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx |
| `i` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `j` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `k` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `lock_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `look_dom_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `own_addr_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `p_cmdv` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `p_dom` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `p_mgmt` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_priv` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_privd` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_root` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `pp` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `qtn_slot_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `qtn_valid_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_status_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `rst_ni` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `s` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `slot_id_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `slot_state_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `win_base_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `win_excl_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `win_limit_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `win_valid_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |

