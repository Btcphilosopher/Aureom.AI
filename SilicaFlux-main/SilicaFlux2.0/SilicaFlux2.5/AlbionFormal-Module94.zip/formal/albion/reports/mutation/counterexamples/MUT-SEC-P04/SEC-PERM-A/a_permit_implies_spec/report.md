# Counterexample: SEC-PERM-A / a_permit_implies_spec

* property: **a_permit_implies_spec** -- [02] permit => an enrolled, ACTIVE, capable slot bound to src_i owns the request (priority-free declarative predicate)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_permit_implies_spec)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_permit_implies_spec --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 1 | 1 |
| `active` | 0x1 | 0x1 |
| `addr_i` | 0x24 | 0x24 |
| `addr_ok` | 0x2 | 0x2 |
| `attr_i` | 0x8 | 0x8 |
| `base_ok` | 1 | 1 |
| `bind_i` | 0x3 | 0x3 |
| `bound` | 0x3 | 0x3 |
| `cap_priv_ok` | 0x3 | 0x3 |
| `cap_sec_ok` | 0x1 | 0x1 |
| `capab` | 0x1 | 0x1 |
| `cls_i` | 0x0 | 0x0 |
| `dev_any` | 0 | 0 |
| `dev_in` | 0x0 | 0x0 |
| `dev_ok` | 0x0 | 0x0 |
| `dev_one` | 0 | 0 |
| `dev_ov` | 0x0 | 0x0 |
| `dev_whole` | 0 | 0 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x6 | 0x6 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x11 | 0x11 |
| `form_ok` | 1 | 1 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `is_sys` | 0 | 0 |
| `k` | 0x2 | 0x2 |
| `last` | 0xa2 | 0xa2 |
| `last_w` | 0xa2 | 0xa2 |
| `len_i` | 0x7f | 0x7f |
| `lockdown_i` | 0 | 0 |
| `match` | 0x1 | 0x1 |
| `mem_ok` | 0x2 | 0x2 |
| `no_wrap` | 1 | 1 |
| `op_i` | 0x2 | 0x2 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `q_ok` | 0x3 | 0x3 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0xa | 0xa |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x4411 | 0x4411 |
| `slot_o` | 0 | 0 |
| `slot_ok` | 0x1 | 0x1 |
| `slot_priv_i` | 0x3 | 0x3 |
| `slot_secure_i` | 0x1 | 0x1 |
| `slot_state_i` | 0x2 | 0x2 |
| `slot_vld_o` | 1 | 1 |
| `spec_exist` | 0 | 0 |
| `src_i` | 0 | 0 |
| `src_isol` | 0 | 0 |
| `win_base_i` | 0x8880828 | 0x8880828 |
| `win_limit_i` | 0xa6a6a166 | 0xa6a6a166 |
| `win_r_i` | 0x0 | 0x0 |
| `win_valid_i` | 0xa | 0xa |
| `win_w_i` | 0xa | 0xa |
| `win_x_i` | 0x0 | 0x0 |

