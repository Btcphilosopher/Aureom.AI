# Counterexample: DMA-VAL-DW32-L24 / a_ok_disjoint

* property: **a_ok_disjoint** -- validated => source and destination ranges are disjoint (no overlap, incl. src_r == dst_r)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_validate.a_ok_disjoint)
* parameters: `{"DW": 32, "MAX_LEN_LOG2": 24}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-VAL-DW32-L24 --prop a_ok_disjoint --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `code` | 0x0 | 0x0 | 0x0 |
| `d_end` | 0x100000000 | 0x100000000 | 0x100000000 |
| `dst` | 0x0 | 0x0 | 0x0 |
| `dst_q` | 0xff800000 | 0xff800000 | 0xff800000 |
| `dst_r` | 0xff800000 | 0xff800000 | 0xff800000 |
| `len` | 0x0 | 0x0 | 0x0 |
| `len_q` | 0x800000 | 0x800000 | 0x800000 |
| `len_r` | 0x800000 | 0x800000 | 0x800000 |
| `s_end` | 0x100000000 | 0x100000000 | 0x100000000 |
| `src` | 0x0 | 0x0 | 0x0 |
| `src_q` | 0xff800000 | 0xff800000 | 0xff800000 |
| `src_r` | 0xff800000 | 0xff800000 | 0xff800000 |

