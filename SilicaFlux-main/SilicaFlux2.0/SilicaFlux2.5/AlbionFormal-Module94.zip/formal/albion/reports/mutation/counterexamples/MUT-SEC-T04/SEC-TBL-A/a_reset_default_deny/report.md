# Counterexample: SEC-TBL-A / a_reset_default_deny

* property: **a_reset_default_deny** -- [03] reset => DEFAULT DENY: every slot INVALID, no window, no binding, not locked, no response / control pulse
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_table.a_reset_default_deny)
* parameters: `{"AW": 4, "DEV_BASE": 140, "DEV_MASK": 204}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-TBL-A --prop a_reset_default_deny --force`

## Signal values per step (harness top scope)

| `allstate` | 0x1400000000000000000000000 | 0x1400000000000000000000000 | 0x1400000000000000000000000 |
| `bind_o` | 0x0 | 0x0 | 0x0 |
| `cfg_en_i` | 0 | 0 | 0 |
| `clk_i` | 1 | 0 | 0 |
| `cmd_arg_dom_i` | 0x0 | 0x0 | 0x0 |
| `cmd_data0_i` | 0x0 | 0x0 | 0x0 |
| `cmd_data1_i` | 0x0 | 0x0 | 0x0 |
| `cmd_deny_o` | 0 | 0 | 0 |
| `cmd_dom_i` | 0x0 | 0x0 | 0x0 |
| `cmd_flags_i` | 0x0 | 0x0 | 0x0 |
| `cmd_op_i` | 0x0 | 0x0 | 0x0 |
| `cmd_port_i` | 0 | 0 | 0 |
| `cmd_priv_i` | 0 | 0 | 0 |
| `cmd_slot_i` | 0 | 0 | 0 |
| `cmd_valid_i` | 0 | 0 | 0 |
| `cmd_win_i` | 0 | 0 | 0 |
| `ctl_clr_cnt_o` | 0 | 0 | 0 |
| `ctl_clr_isol_o` | 0x0 | 0x0 | 0x0 |
| `ctl_clr_qhold_o` | 0x0 | 0x0 | 0x0 |
| `ctl_clr_safe_o` | 0 | 0 | 0 |
| `ctl_thresh_we_o` | 0 | 0 | 0 |
| `d` | 0x2 | 0x2 | 0x2 |
| `devrd_o` | 0x0 | 0x0 | 0x0 |
| `devwr_o` | 0x0 | 0x0 | 0x0 |
| `i` | 0x2 | 0x2 | 0x2 |
| `init_q` | 1 | 1 | 1 |
| `j` | 0x2 | 0x2 | 0x2 |
| `k` | 0x2 | 0x2 | 0x2 |
| `kmask_o` | 0x0 | 0x0 | 0x0 |
| `lock_o` | 0 | 0 | 0 |
| `look_dom_i` | 0x0 | 0x0 | 0x0 |
| `m` | 0x2 | 0x2 | 0x2 |
| `own_addr_i` | 0x0 | 0x0 | 0x0 |
| `pp` | 0x2 | 0x2 | 0x2 |
| `qmask_o` | 0x0 | 0x0 | 0x0 |
| `qtn_slot_i` | 0 | 0 | 0 |
| `qtn_valid_i` | 0 | 0 | 0 |
| `rsp_valid_o` | 0 | 0 | 0 |
| `rst_ni` | 0 | 0 | 0 |
| `s` | 0x2 | 0x2 | 0x2 |
| `slot_clr_o` | 0x0 | 0x0 | 0x0 |
| `slot_id_o` | 0x0 | 0x0 | 0x0 |
| `slot_priv_o` | 0x0 | 0x0 | 0x0 |
| `slot_secure_o` | 0x0 | 0x0 | 0x0 |
| `slot_state_o` | 0xa | 0xa | 0xa |
| `win_base_o` | 0x0 | 0x0 | 0x0 |
| `win_excl_o` | 0x0 | 0x0 | 0x0 |
| `win_limit_o` | 0x0 | 0x0 | 0x0 |
| `win_r_o` | 0x0 | 0x0 | 0x0 |
| `win_valid_o` | 0x0 | 0x0 | 0x0 |
| `win_w_o` | 0x0 | 0x0 | 0x0 |
| `win_x_o` | 0x0 | 0x0 | 0x0 |
| `zero_mask_o` | 0x0 | 0x0 | 0x0 |
| `zero_valid_o` | 0 | 0 | 0 |

