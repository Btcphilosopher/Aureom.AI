# Counterexample: FAB-ARB-FIX4 / a_matches_reference

* property: **a_matches_reference** -- grant == reference model (priority order, pointer move-on-accept, lock)
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_sfb_arbiter.a_matches_reference)
* parameters: `{"N": 4, "MODE": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-ARB-FIX4 --prop a_matches_reference --force`

## Signal values per step (harness top scope)

| `accept` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `exp_idx` | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `exp_valid` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `grant_idx` | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 |
| `grant_valid` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `lock_hit` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `lock_idx_m` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `lock_m` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `req` | 0x0 | 0x0 | 0x2 | 0x2 | 0x3 | 0x3 | 0x3 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `stall` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |

