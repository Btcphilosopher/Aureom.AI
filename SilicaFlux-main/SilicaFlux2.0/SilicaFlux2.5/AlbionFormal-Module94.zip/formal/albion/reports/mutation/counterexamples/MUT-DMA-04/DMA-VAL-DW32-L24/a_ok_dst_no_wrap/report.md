# Counterexample: DMA-VAL-DW32-L24 / a_ok_dst_no_wrap

* property: **a_ok_dst_no_wrap** -- validated => dst_r + len_r <= 2^32 (destination range does not wrap)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_validate.a_ok_dst_no_wrap)
* parameters: `{"DW": 32, "MAX_LEN_LOG2": 24}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-VAL-DW32-L24 --prop a_ok_dst_no_wrap --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `code` | 0x0 | 0x0 | 0x0 |
| `d_end` | 0x100000001 | 0x100000001 | 0x100000001 |
| `dst` | 0x0 | 0x0 | 0x0 |
| `dst_q` | 0xfffffffc | 0xfffffffc | 0xfffffffc |
| `dst_r` | 0xfffffffc | 0xfffffffc | 0xfffffffc |
| `len` | 0x0 | 0x0 | 0x0 |
| `len_q` | 0x5 | 0x5 | 0x5 |
| `len_r` | 0x5 | 0x5 | 0x5 |
| `src` | 0x0 | 0x0 | 0x0 |
| `src_q` | 0xf0004 | 0xf0004 | 0xf0004 |
| `src_r` | 0xf0004 | 0xf0004 | 0xf0004 |

