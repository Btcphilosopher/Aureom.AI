# Counterexample: SRAM-CTRL-D4L1W1 / a_ready_low_test

* property: **a_ready_low_test** -- [spec 4,8] req_ready = 0 while tst_active (functional requests are never accepted in test mode)
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_sram_sp_ctrl.a_ready_low_test)
* parameters: `{"DW": 16, "MW": 2, "DEPTH": 4, "LAT": 1, "FIFO": 2, "WACK": 1, "IDW": 2}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-CTRL-D4L1W1 --prop a_ready_low_test --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `posted_valid_wr` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_id` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_we` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_wmask` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `t_on` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `tst_active` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `tst_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_ce` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tst_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_we` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

