# Counterexample: DMA-FIFO-D4W8 / a_fifo_order

* property: **a_fifo_order** -- first-in first-out: the k-th pop returns the k-th pushed word (tagged beat, any k < 2^TAGW)
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_dma_fifo.a_fifo_order)
* parameters: `{"WIDTH": 8, "DEPTH": 4, "TAGW": 3}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-FIFO-D4W8 --prop a_fifo_order --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `clr` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `kk` | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `m_cnt` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `n_pop` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `n_push` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x2 | 0x2 | 0x2 |
| `pop` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `push` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `tag_data` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x40 | 0x40 | 0x40 |
| `tag_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x40 | 0x40 | 0x0 | 0x0 | 0x0 |

