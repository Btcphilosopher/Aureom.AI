# Counterexample: SEC-PERM-B / a_privilege_not_escalated

* property: **a_privilege_not_escalated** -- [02 step 10] a privileged / secure attribute is only permitted for a domain with that capability
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_privilege_not_escalated)
* parameters: `{"UNIQ": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-B --prop a_privilege_not_escalated --force`

## Signal values per step (harness top scope)

| `a_instr` | 1 | 1 |
| `a_priv` | 0 | 0 |
| `a_secure` | 1 | 1 |
| `active` | 0x3 | 0x3 |
| `addr_i` | 0x80 | 0x80 |
| `any_mwa_priv` | 1 | 1 |
| `any_mwa_sec` | 0 | 0 |
| `attr_i` | 0x18 | 0x18 |
| `bind_i` | 0x3 | 0x3 |
| `bound` | 0x3 | 0x3 |
| `cls_i` | 0x1 | 0x1 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x45 | 0x45 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x0 | 0x0 |
| `k` | 0x2 | 0x2 |
| `len_i` | 0x0 | 0x0 |
| `lockdown_i` | 0 | 0 |
| `match` | 0x2 | 0x2 |
| `mwa` | 0x2 | 0x2 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x4 | 0x4 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x4590 | 0x4590 |
| `slot_o` | 1 | 1 |
| `slot_priv_i` | 0x2 | 0x2 |
| `slot_secure_i` | 0x0 | 0x0 |
| `slot_state_i` | 0xa | 0xa |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `uniq_ok` | 1 | 1 |
| `win_base_i` | 0x8080800 | 0x8080800 |
| `win_limit_i` | 0x8a8a8a8a | 0x8a8a8a8a |
| `win_r_i` | 0x0 | 0x0 |
| `win_valid_i` | 0x0 | 0x0 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

