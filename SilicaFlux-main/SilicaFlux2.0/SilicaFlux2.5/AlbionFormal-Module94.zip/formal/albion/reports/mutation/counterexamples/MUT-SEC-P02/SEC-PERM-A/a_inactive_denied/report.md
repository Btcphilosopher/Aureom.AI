# Counterexample: SEC-PERM-A / a_inactive_denied

* property: **a_inactive_denied** -- [02 step 9] a domain that is not ACTIVE (INVALID / SUSPENDED / QUARANTINED) is always denied
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_inactive_denied)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_inactive_denied --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 0 | 0 |
| `active` | 0x0 | 0x0 |
| `addr_i` | 0xa6 | 0xa6 |
| `attr_i` | 0x0 | 0x0 |
| `bind_i` | 0x3 | 0x3 |
| `bound` | 0x3 | 0x3 |
| `cls_i` | 0x1 | 0x1 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x0 | 0x0 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x0 | 0x0 |
| `k` | 0x2 | 0x2 |
| `len_i` | 0xff | 0xff |
| `lockdown_i` | 0 | 0 |
| `match` | 0x2 | 0x2 |
| `mwa` | 0x0 | 0x0 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x5 | 0x5 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x0 | 0x0 |
| `slot_o` | 1 | 1 |
| `slot_priv_i` | 0x2 | 0x2 |
| `slot_secure_i` | 0x0 | 0x0 |
| `slot_state_i` | 0x4 | 0x4 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `win_base_i` | 0x60a0802 | 0x60a0802 |
| `win_limit_i` | 0x0 | 0x0 |
| `win_r_i` | 0x0 | 0x0 |
| `win_valid_i` | 0x0 | 0x0 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

