# Counterexample: SEC-PERM-B / a_permit_implies_spec

* property: **a_permit_implies_spec** -- [02] permit => an enrolled, ACTIVE, capable slot bound to src_i owns the request (priority-free declarative predicate)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_permit_implies_spec)
* parameters: `{"UNIQ": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-B --prop a_permit_implies_spec --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 1 | 1 |
| `active` | 0x2 | 0x2 |
| `addr_i` | 0x27 | 0x27 |
| `addr_ok` | 0x1 | 0x1 |
| `attr_i` | 0x8 | 0x8 |
| `base_ok` | 1 | 1 |
| `bind_i` | 0x3 | 0x3 |
| `bound` | 0x3 | 0x3 |
| `cap_priv_ok` | 0x3 | 0x3 |
| `cap_sec_ok` | 0x2 | 0x2 |
| `capab` | 0x2 | 0x2 |
| `cls_i` | 0x0 | 0x0 |
| `dev_any` | 0 | 0 |
| `dev_in` | 0x0 | 0x0 |
| `dev_ok` | 0x0 | 0x0 |
| `dev_one` | 0 | 0 |
| `dev_ov` | 0x0 | 0x0 |
| `dev_whole` | 0 | 0 |
| `devrd_i` | 0xa | 0xa |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x40 | 0x40 |
| `form_ok` | 1 | 1 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `is_sys` | 0 | 0 |
| `k` | 0x2 | 0x2 |
| `last` | 0xa4 | 0xa4 |
| `last_w` | 0xa4 | 0xa4 |
| `len_i` | 0x7e | 0x7e |
| `lockdown_i` | 0 | 0 |
| `match` | 0x2 | 0x2 |
| `mem_ok` | 0x1 | 0x1 |
| `no_wrap` | 1 | 1 |
| `op_i` | 0x2 | 0x2 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `q_ok` | 0x3 | 0x3 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0xa | 0xa |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x4081 | 0x4081 |
| `slot_o` | 1 | 1 |
| `slot_ok` | 0x2 | 0x2 |
| `slot_priv_i` | 0x3 | 0x3 |
| `slot_secure_i` | 0x2 | 0x2 |
| `slot_state_i` | 0x8 | 0x8 |
| `slot_vld_o` | 1 | 1 |
| `spec_exist` | 0 | 0 |
| `src_i` | 0 | 0 |
| `src_isol` | 0 | 0 |
| `uniq_ok` | 1 | 1 |
| `win_base_i` | 0x7010909 | 0x7010909 |
| `win_limit_i` | 0xe08580e0 | 0xe08580e0 |
| `win_r_i` | 0xb | 0xb |
| `win_valid_i` | 0xb | 0xb |
| `win_w_i` | 0x3 | 0x3 |

