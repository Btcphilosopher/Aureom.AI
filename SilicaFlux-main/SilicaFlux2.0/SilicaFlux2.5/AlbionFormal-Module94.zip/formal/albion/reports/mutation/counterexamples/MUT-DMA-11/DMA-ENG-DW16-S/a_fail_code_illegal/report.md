# Counterexample: DMA-ENG-DW16-S / a_fail_code_illegal

* property: **a_fail_code_illegal** -- [DMA.md 2] a descriptor failing validation ends in ERROR with exactly the documented first-failing-rule code
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_dma_engine.a_fail_code_illegal)
* parameters: `{"DW": 16, "MAX_LEN_LOG2": 3, "SMALL": 1, "AB": 6}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-ENG-DW16-S --prop a_fail_code_illegal --force`

## Signal values per step (harness top scope)

| `abort` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `b` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `beat_off` | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx0 |
| `busy` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `cfg_dst` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_len` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_src` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `err_code` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0xa | 0xa | 0xa |
| `fail` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `g_dst` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `g_len` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `g_nb` | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `g_src` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `g_started` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `g_wr_ok_cnt` | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `gd` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `gl` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `go` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `gs` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_acc` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_held` | x | x | x | x | x | x | x | x | x |
| `outstanding` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `r_errdata_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `r_solicited_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `r_stable_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ra` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `ref_code` | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `ref_legal` | x | x | x | x | x | x | x | x | x |
| `req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rf_dalign` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rf_dovf` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rf_long` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rf_ovl` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rf_salign` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rf_sovf` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rf_zero` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rsp_error` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_hs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `start` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `state` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x7 | 0x7 | 0x7 |

