# Counterexample: SRAM-CTRL-D4L1W1 / a_wen_legal

* property: **a_wen_legal** -- no illegal write enable: array ce&&we only for an accepted valid functional write, or a test-port write
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sram_sp_ctrl.a_wen_legal)
* parameters: `{"DW": 16, "MW": 2, "DEPTH": 4, "LAT": 1, "FIFO": 2, "WACK": 1, "IDW": 2}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-CTRL-D4L1W1 --prop a_wen_legal --force`

## Signal values per step (harness top scope)

| `acc` | 0 | 0 | 0 |
| `addr_ok` | 1 | 1 | 1 |
| `clk` | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 1 |
| `posted_valid_wr` | 0 | 0 | 0 |
| `req_addr` | 0x0 | 0x0 | 0x0 |
| `req_id` | 0x0 | 0x0 | 0x0 |
| `req_ready` | 0 | 0 | 0 |
| `req_valid` | 0 | 0 | 0 |
| `req_wdata` | 0x0 | 0x0 | 0x0 |
| `req_we` | 1 | 1 | 1 |
| `req_wmask` | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 0 |
| `t_on` | 1 | 1 | 1 |
| `tap_ce` | 1 | 1 | 1 |
| `tap_wd` | xxxxxxxxxx | xxxxxxxxxx | xxxxxxxxxx |
| `tap_we` | 1 | 1 | 1 |
| `tap_wm` | xx | xx | xx |
| `tst_active` | 1 | 1 | 1 |
| `tst_addr` | 0x0 | 0x0 | 0x0 |
| `tst_ce` | 1 | 1 | 1 |
| `tst_ok` | 1 | 1 | 1 |
| `tst_rdata` | xxxxxxxxxxxxxx11 | xxxxxxxxxxxxxx11 | xxxxxxxxxxxxxx11 |
| `tst_wdata` | 0x0 | 0x0 | 0x0 |
| `tst_we` | 0 | 0 | 0 |

