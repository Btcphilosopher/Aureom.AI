# Counterexample: DMA-VAL-DW32-L24 / a_code_matches_spec

* property: **a_code_matches_spec** -- [DMA.md 2] error code == first failing rule of the documented table (40-bit integer reference)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_validate.a_code_matches_spec)
* parameters: `{"DW": 32, "MAX_LEN_LOG2": 24}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-VAL-DW32-L24 --prop a_code_matches_spec --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `code` | 0x0 | 0x0 | 0x0 |
| `dst` | 0x0 | 0x0 | 0x0 |
| `dst_q` | 0xffffc000 | 0xffffc000 | 0xffffc000 |
| `dst_r` | 0xffffc000 | 0xffffc000 | 0xffffc000 |
| `f_dalign` | 0 | 0 | 0 |
| `f_dovf` | 1 | 1 | 1 |
| `f_long` | 0 | 0 | 0 |
| `f_salign` | 0 | 0 | 0 |
| `f_sovf` | 0 | 0 | 0 |
| `f_zero` | 0 | 0 | 0 |
| `len` | 0x0 | 0x0 | 0x0 |
| `len_q` | 0x4001 | 0x4001 | 0x4001 |
| `len_r` | 0x4001 | 0x4001 | 0x4001 |
| `rcode` | 0x6 | 0x6 | 0x6 |
| `src` | 0x0 | 0x0 | 0x0 |
| `src_q` | 0x8000 | 0x8000 | 0x8000 |
| `src_r` | 0x8000 | 0x8000 | 0x8000 |

