# Counterexample: SEC-PERM-A / a_permit_device_rules

* property: **a_permit_device_rules** -- [02 step 13] a device permit => range wholly inside exactly one device, priv/secure met, no instruction fetch, device permission
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_permit_device_rules)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_permit_device_rules --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 1 | 1 |
| `a_secure` | 1 | 1 |
| `active` | 0x2 | 0x2 |
| `addr_i` | 0xf1 | 0xf1 |
| `attr_i` | 0xc | 0xc |
| `bind_i` | 0x2 | 0x2 |
| `bound` | 0x2 | 0x2 |
| `cap_priv_ok` | 0x2 | 0x2 |
| `cap_sec_ok` | 0x2 | 0x2 |
| `capab` | 0x2 | 0x2 |
| `cls_i` | 0x0 | 0x0 |
| `dev_any` | 1 | 1 |
| `dev_in` | 0x1 | 0x1 |
| `dev_ok` | 0x0 | 0x0 |
| `dev_one` | 1 | 1 |
| `dev_ov` | 0x1 | 0x1 |
| `dev_whole` | 1 | 1 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x81 | 0x81 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `k` | 0x2 | 0x2 |
| `last` | 0xf4 | 0xf4 |
| `last_w` | xxxxxxxxx11110100 | xxxxxxxxx11110100 |
| `len_i` | 0x4 | 0x4 |
| `lockdown_i` | 0 | 0 |
| `match` | 0x2 | 0x2 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x0 | 0x0 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x8110 | 0x8110 |
| `slot_o` | 1 | 1 |
| `slot_ok` | 0x2 | 0x2 |
| `slot_priv_i` | 0x2 | 0x2 |
| `slot_secure_i` | 0x2 | 0x2 |
| `slot_state_i` | 0x8 | 0x8 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `win_base_i` | 0x90929 | 0x90929 |
| `win_limit_i` | 0x40000e6 | 0x40000e6 |
| `win_r_i` | 0x5 | 0x5 |
| `win_valid_i` | 0x4 | 0x4 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

