# Counterexample: SEC-GATE-B / a_commit_first_cycle

* property: **a_commit_first_cycle** -- chk_commit_o pulses exactly in the first evaluation cycle of a held request
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_cit_gate.a_commit_first_cycle)
* parameters: `{"OUT_W": 2, "TGT_OK": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-GATE-B --prop a_commit_first_cycle --force`

## Signal values per step (harness top scope)

| `chk_addr_o` | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `chk_attr_o` | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx |
| `chk_cls_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_commit_o` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `chk_dom_o` | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx |
| `chk_idx_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_len_o` | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 |
| `chk_op_o` | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx | xxxx |
| `chk_permit_i` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `chk_status_i` | 0x2 | 0x2 | 0x4 | 0x4 | 0x2 | 0x2 | 0x0 | 0x0 | 0x0 |
| `chk_valid_o` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `clk_i` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `flush_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_req_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_req_ready_o` | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `m_req_valid_i` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_ready_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `outstanding_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `p_tbit2` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_thold2` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `r_bit_t` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ri` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `ri_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rst_ni` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s_acc` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `s_basep` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_dec` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_fwd` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_have` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `s_loc_done` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_loc_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `s_out` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_out_zero` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s_permit` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_taken` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_vp` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `t_req_o` | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `t_req_ready_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `t_req_valid_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `t_rsp_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `t_rsp_ready_o` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `t_rsp_valid_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tgt_out` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |

