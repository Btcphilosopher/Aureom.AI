# Counterexample: DMA-REG-E0-P1 / a_cfg_frozen_busy

* property: **a_cfg_frozen_busy** -- [DMA.md 3] the descriptor registers never change in a cycle following a BUSY cycle (the active transfer is never modified)
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_dma_regs.a_cfg_frozen_busy)
* parameters: `{"DW": 32, "ENGINE": 0, "FIFO_DEPTH": 1, "MAX_LEN_LOG2": 24, "PERF": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-REG-E0-P1 --prop a_cfg_frozen_busy --force`

## Signal values per step (harness top scope)

| `busy` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `busy_p` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `bytes_done` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_dst` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_len` | 0x0 | 0x0 | 0x0 | 0x0 | 0x80000000 | 0x80000000 | 0x80000000 |
| `cfg_src` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `done` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `dst_p` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `err_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `err_code` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `ev_stall` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `fail` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `len_p` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_info` | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 | 0x1180004 |
| `rb_addr` | 0x0 | 0x0 | 0x10 | 0x10 | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rb_wdata` | 0x0 | 0x0 | 0x80000000 | 0x80000000 | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `src_p` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `state` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |

