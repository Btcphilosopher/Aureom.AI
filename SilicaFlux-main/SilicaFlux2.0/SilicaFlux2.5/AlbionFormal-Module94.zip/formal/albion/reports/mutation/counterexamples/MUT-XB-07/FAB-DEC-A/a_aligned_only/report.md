# Counterexample: FAB-DEC-A / a_aligned_only

* property: **a_aligned_only** -- [R9] a misaligned address is never routed
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sfb_decoder.a_aligned_only)
* parameters: `{"NS": 3, "AW": 6, "DW": 16, "CHECK_ALIGN": 1, "SLV_BASE": 132096, "SLV_MASK": 232496, "EN": 7}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-DEC-A --prop a_aligned_only --force`

## Signal values per step (harness top scope)

| `addr` | 0x1 | 0x1 |
| `aligned` | 0 | 0 |
| `enabled_ok` | 1 | 1 |
| `hit` | 1 | 1 |
| `misaligned` | 1 | 1 |
| `s` | 0x3 | 0x3 |
| `t` | 0x3 | 0x3 |

