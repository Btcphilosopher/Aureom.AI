# Counterexample: SRAM-SECMON / a_lock_set_only

* property: **a_lock_set_only** -- [CC_SEC_CTRL] HOST_LOCK never clears except by reset: once set it stays set (any bus traffic, including CTRL writes of 0)
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_prot_secmon.a_lock_set_only)
* parameters: `{}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-SECMON --prop a_lock_set_only --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `host_lock` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `lock_prev` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rb_addr` | 0x0 | 0x0 | 0x8 | 0x8 | 0x8 | 0x8 | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rb_wdata` | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `viol_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `viol_evt` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

