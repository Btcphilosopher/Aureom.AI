# Counterexample: SEC-PERM-B / a_equiv_spec

* property: **a_equiv_spec** -- [02] (INV-UNIQ) permit <=> the declarative predicate: the checker is exactly its specification
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_equiv_spec)
* parameters: `{"UNIQ": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-B --prop a_equiv_spec --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 0 | 0 |
| `active` | 0x3 | 0x3 |
| `addr_i` | 0x5e | 0x5e |
| `addr_ok` | 0x1 | 0x1 |
| `attr_i` | 0x0 | 0x0 |
| `base_ok` | 1 | 1 |
| `bind_i` | 0x1 | 0x1 |
| `bound` | 0x1 | 0x1 |
| `cap_priv_ok` | 0x3 | 0x3 |
| `cap_sec_ok` | 0x3 | 0x3 |
| `capab` | 0x3 | 0x3 |
| `cls_i` | 0x0 | 0x0 |
| `dev_any` | 0 | 0 |
| `dev_in` | 0x0 | 0x0 |
| `dev_ok` | 0x0 | 0x0 |
| `dev_one` | 0 | 0 |
| `dev_ov` | 0x0 | 0x0 |
| `dev_whole` | 0 | 0 |
| `devrd_i` | 0x3 | 0x3 |
| `devwr_i` | 0x3 | 0x3 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x94 | 0x94 |
| `form_ok` | 1 | 1 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x84 | 0x84 |
| `is_sys` | 0 | 0 |
| `k` | 0x2 | 0x2 |
| `last` | 0xdf | 0xdf |
| `last_w` | 0xdf | 0xdf |
| `len_i` | 0x82 | 0x82 |
| `lockdown_i` | 0 | 0 |
| `match` | 0x1 | 0x1 |
| `mem_ok` | 0x1 | 0x1 |
| `no_wrap` | 1 | 1 |
| `op_i` | 0x2 | 0x2 |
| `permit_o` | 0 | 0 |
| `port_isol_i` | 0x0 | 0x0 |
| `q_ok` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x0 | 0x0 |
| `reason_o` | 0x7 | 0x7 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x194 | 0x194 |
| `slot_o` | 0 | 0 |
| `slot_ok` | 0x1 | 0x1 |
| `slot_priv_i` | 0x0 | 0x0 |
| `slot_secure_i` | 0x1 | 0x1 |
| `slot_state_i` | 0xa | 0xa |
| `slot_vld_o` | 1 | 1 |
| `spec_exist` | 1 | 1 |
| `src_i` | 0 | 0 |
| `src_isol` | 0 | 0 |
| `uniq_ok` | 1 | 1 |
| `win_base_i` | 0x2808000 | 0x2808000 |
| `win_limit_i` | 0xef83cedf | 0xef83cedf |
| `win_r_i` | 0x0 | 0x0 |
| `win_valid_i` | 0x3 | 0x3 |
| `win_w_i` | 0x1 | 0x1 |

