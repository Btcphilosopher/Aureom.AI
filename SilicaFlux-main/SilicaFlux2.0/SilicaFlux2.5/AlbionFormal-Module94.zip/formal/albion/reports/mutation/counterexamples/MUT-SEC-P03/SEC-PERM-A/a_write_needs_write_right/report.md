# Counterexample: SEC-PERM-A / a_write_needs_write_right

* property: **a_write_needs_write_right** -- [02] a WRITE memory permit needs a window with the WRITE right (the read right is not enough)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_write_needs_write_right)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_write_needs_write_right --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 1 | 1 |
| `active` | 0x1 | 0x1 |
| `addr_i` | 0x3c | 0x3c |
| `attr_i` | 0x8 | 0x8 |
| `bind_i` | 0x1 | 0x1 |
| `bound` | 0x1 | 0x1 |
| `cap_priv_ok` | 0x3 | 0x3 |
| `cap_sec_ok` | 0x1 | 0x1 |
| `capab` | 0x1 | 0x1 |
| `cls_i` | 0x0 | 0x0 |
| `cont_w` | 0x0 | 0x0 |
| `dev_any` | 0 | 0 |
| `dev_ov` | 0x0 | 0x0 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x10 | 0x10 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `k` | 0x2 | 0x2 |
| `last` | 0x7f | 0x7f |
| `last_w` | xxxxxxxxx01111111 | xxxxxxxxx01111111 |
| `len_i` | 0x44 | 0x44 |
| `lockdown_i` | 0 | 0 |
| `match` | 0x1 | 0x1 |
| `op_i` | 0x2 | 0x2 |
| `perm_has_w` | 0 | 0 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x0 | 0x0 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x10 | 0x10 |
| `slot_o` | 0 | 0 |
| `slot_ok` | 0x1 | 0x1 |
| `slot_priv_i` | 0x1 | 0x1 |
| `slot_secure_i` | 0x1 | 0x1 |
| `slot_state_i` | 0x2 | 0x2 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `win_base_i` | 0x80480020 | 0x80480020 |
| `win_limit_i` | 0xeaababab | 0xeaababab |
| `win_r_i` | 0x1 | 0x1 |
| `win_valid_i` | 0x1 | 0x1 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

