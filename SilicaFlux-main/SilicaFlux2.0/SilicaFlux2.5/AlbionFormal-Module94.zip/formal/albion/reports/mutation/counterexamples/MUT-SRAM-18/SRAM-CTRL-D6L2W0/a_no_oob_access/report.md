# Counterexample: SRAM-CTRL-D6L2W0 / a_no_oob_access

* property: **a_no_oob_access** -- [spec 2] an out-of-range address (addr >= DEPTH) never reaches the array (read or write)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sram_sp_ctrl.a_no_oob_access)
* parameters: `{"DW": 16, "MW": 2, "DEPTH": 6, "LAT": 2, "FIFO": 3, "WACK": 0, "IDW": 2}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-CTRL-D6L2W0 --prop a_no_oob_access --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 1 |
| `req_addr` | 0x0 | 0x0 | 0x0 |
| `req_id` | 0x0 | 0x0 | 0x0 |
| `req_ready` | 0 | 0 | 0 |
| `req_valid` | 0 | 0 | 0 |
| `req_wdata` | 0x0 | 0x0 | 0x0 |
| `req_we` | 0 | 0 | 0 |
| `req_wmask` | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 0 |
| `t_on` | 1 | 1 | 1 |
| `tap_ad` | 0x6 | 0x6 | 0x6 |
| `tap_ce` | 1 | 1 | 1 |
| `tap_wd` | xxxxxxxxx | xxxxxxxxx | xxxxxxxxx |
| `tap_we` | x | x | x |
| `tap_wm` | xx | xx | xx |
| `tst_active` | 1 | 1 | 1 |
| `tst_addr` | 0x6 | 0x6 | 0x6 |
| `tst_ce` | 1 | 1 | 1 |
| `tst_rdata` | xxxxxxxxx110xxx1 | xxxxxxxxx110xxx1 | xxxxxxxxx110xxx1 |
| `tst_wdata` | 0x0 | 0x0 | 0x0 |
| `tst_we` | 0 | 0 | 0 |

