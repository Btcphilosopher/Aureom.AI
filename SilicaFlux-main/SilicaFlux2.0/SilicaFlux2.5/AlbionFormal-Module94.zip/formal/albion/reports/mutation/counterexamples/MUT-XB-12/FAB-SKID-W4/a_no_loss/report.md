# Counterexample: FAB-SKID-W4 / a_no_loss

* property: **a_no_loss** -- stored data is never stranded: whenever an item is buffered the output is valid
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_sfb_skid.a_no_loss)
* parameters: `{"WIDTH": 4}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-SKID-W4 --prop a_no_loss --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `cnt` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `m_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `pop` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `push` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `s_data` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_ready` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `s_valid` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |

