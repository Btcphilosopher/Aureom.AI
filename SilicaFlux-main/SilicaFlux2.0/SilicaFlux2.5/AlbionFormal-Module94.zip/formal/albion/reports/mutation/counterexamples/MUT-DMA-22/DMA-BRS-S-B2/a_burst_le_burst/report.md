# Counterexample: DMA-BRS-S-B2 / a_burst_le_burst

* property: **a_burst_le_burst** -- [DMA.md 5] a read or write phase issues at most BURST back-to-back transactions
* failing step: 5 (witness replay: CONFIRMED: simulation violates fv_dma_burst.a_burst_le_burst)
* parameters: `{"DW": 16, "MAX_LEN_LOG2": 4, "FIFO_DEPTH": 4, "BURST": 2, "DUAL_PORT": 0, "MAX_OUT": 2, "SMALL": 1, "AB": 6}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-BRS-S-B2 --prop a_burst_le_burst --force`

## Signal values per step (harness top scope)

| `abort` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `any_req` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `b` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `cfg_dst` | 0x0 | 0x0 | 0x4 | 0x4 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_len` | 0x0 | 0x0 | 0x5 | 0x5 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_src` | 0x0 | 0x0 | 0xa | 0xa | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `eff_cnt` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x2 | 0x2 | 0x2 |
| `fifo_level` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `g_cnt_q` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x2 | 0x2 | 0x2 |
| `g_nb` | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `g_ph_q` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `gd` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `gl` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `gs` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `in_run` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_acc` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `out0` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `outst` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `outw` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x1 |
| `ph_chg` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ph_obs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `r_err` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `r_hs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `r_sol` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `r_stable` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ra` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `req_write` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_error` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `start` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `state` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `wa` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `wk` | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx |

