# Counterexample: SRAM-PROT-TAP-D4P2 / a_prot_write_needs_unlocked_first_eval

* property: **a_prot_write_needs_unlocked_first_eval** -- PROTECTED WRITES: a functional array write to a protected word happens only if host_lock was 0 when its request was first evaluated by the gate (a lock set BEFORE a write is presented blocks it)
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_prot_compose_tap.a_prot_write_needs_unlocked_first_eval)
* parameters: `{"DEPTH": 4, "LAT": 1, "PLO": 2}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-PROT-TAP-D4P2 --prop a_prot_write_needs_unlocked_first_eval --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `eval_q` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `first_eval` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `free` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `func_prot_wr` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `func_wr` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `fwd_pend` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `host_lock` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `loc_acc` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `loc_pend` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `lock_fe` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `lockfe_q` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_acc` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_req_addr` | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 |
| `m_req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_req_write` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_req_wstrb` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_rsp_hs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `prot` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rb_addr` | 0x0 | 0x0 | 0x8 | 0x8 | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rb_wdata` | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `refuse` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `refused_evt` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `s_acc` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_held` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_req_addr` | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 |
| `s_req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_req_write` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_req_wstrb` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_rsp_hs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_stable_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `t_on` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `tap_ad` | 0x0 | 0x0 | 0x0 | 0x0 | 0x2 | 0x2 | 0x2 |
| `tap_ce` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `tap_prot` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `tap_we` | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `tst_active` | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `tst_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_ce` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tst_rdata` | xxxxxxxxxxxxxxxxxxxxxxxx00xxxx00 | xxxxxxxxxxxxxxxxxxxxxxxx00xxxx00 | xxxxxxxxxxxxxxxxxxxxxxxx00xxxx00 | xxxxxxxxxxxxxxxxxxxxxxxx00xxxx00 | xxxxxxxxxxxxxxxxxxxxxxxx10xxxx11 | xxxxxxxxxxxxxxxxxxxxxxxx10xxxx11 | xxxxxxxxxxxxxxxxxxxxxxxx10xxxx11 |
| `tst_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_we` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `wi` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |

