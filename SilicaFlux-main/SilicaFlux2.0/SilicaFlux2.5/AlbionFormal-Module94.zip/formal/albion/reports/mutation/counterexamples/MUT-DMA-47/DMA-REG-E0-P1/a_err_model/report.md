# Counterexample: DMA-REG-E0-P1 / a_err_model

* property: **a_err_model** -- [DMA.md 3] rb_err follows the spec rule of every access (refused busy writes, read-only writes, unmapped offsets, absent perf registers)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_regs.a_err_model)
* parameters: `{"DW": 32, "ENGINE": 0, "FIFO_DEPTH": 1, "MAX_LEN_LOG2": 24, "PERF": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-REG-E0-P1 --prop a_err_model --force`

## Signal values per step (harness top scope)

| `busy` | 0 | 0 | 0 |
| `bytes_done` | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 0 |
| `done` | 0 | 0 | 0 |
| `err_addr` | 0x0 | 0x0 | 0x0 |
| `err_code` | 0x0 | 0x0 | 0x0 |
| `ev_stall` | 0 | 0 | 0 |
| `fail` | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 1 |
| `m_info` | 0x1180004 | 0x1180004 | 0x1180004 |
| `m_rerr` | 1 | 1 | 1 |
| `rb_addr` | 0x2c | 0x2c | 0x2c |
| `rb_err` | 0 | 0 | 0 |
| `rb_sel` | 1 | 1 | 1 |
| `rb_wdata` | 0x0 | 0x0 | 0x0 |
| `rb_we` | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 0 |
| `start_req` | 0 | 0 | 0 |
| `state` | 0x0 | 0x0 | 0x0 |
| `wr` | 1 | 1 | 1 |

