# Counterexample: SRAM-DATA-D6L1W1 / a_rsp_err

* property: **a_rsp_err** -- [spec 2] rsp_err is set exactly for out-of-range addresses (also for posted writes: errors are never silent)
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_sram_sp_data.a_rsp_err)
* parameters: `{"DW": 16, "MW": 2, "DEPTH": 6, "LAT": 1, "FIFO": 2, "WACK": 1, "IDW": 2}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-DATA-D6L1W1 --prop a_rsp_err --force`

## Signal values per step (harness top scope)

| `acc` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `needs_rsp` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ok_err` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `qcount` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `req_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x6 | 0x6 | 0x0 | 0x0 | 0x0 |
| `req_id` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `req_we` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_wmask` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `t_on` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ta` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_active` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tst_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_ce` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `tst_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `tst_we` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

