# Counterexample: DMA-VAL-DW16-L6 / a_code_matches_spec

* property: **a_code_matches_spec** -- [DMA.md 2] error code == first failing rule of the documented table (40-bit integer reference)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_validate.a_code_matches_spec)
* parameters: `{"DW": 16, "MAX_LEN_LOG2": 6}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-VAL-DW16-L6 --prop a_code_matches_spec --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `code` | 0x7 | 0x7 | 0x7 |
| `dst` | 0x0 | 0x0 | 0x0 |
| `dst_q` | 0x3ff0 | 0x3ff0 | 0x3ff0 |
| `dst_r` | 0x3ff0 | 0x3ff0 | 0x3ff0 |
| `f_dalign` | 0 | 0 | 0 |
| `f_dovf` | 0 | 0 | 0 |
| `f_long` | 0 | 0 | 0 |
| `f_salign` | 0 | 0 | 0 |
| `f_sovf` | 0 | 0 | 0 |
| `f_zero` | 0 | 0 | 0 |
| `len` | 0x0 | 0x0 | 0x0 |
| `len_q` | 0x8 | 0x8 | 0x8 |
| `len_r` | 0x8 | 0x8 | 0x8 |
| `rcode` | 0x0 | 0x0 | 0x0 |
| `src` | 0x0 | 0x0 | 0x0 |
| `src_q` | 0x3ff8 | 0x3ff8 | 0x3ff8 |
| `src_r` | 0x3ff8 | 0x3ff8 | 0x3ff8 |

