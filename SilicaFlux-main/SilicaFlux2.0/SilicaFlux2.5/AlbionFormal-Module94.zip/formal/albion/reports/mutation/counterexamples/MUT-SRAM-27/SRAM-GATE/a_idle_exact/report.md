# Counterexample: SRAM-GATE / a_idle_exact

* property: **a_idle_exact** -- idle <=> nothing outstanding and nothing waiting downstream
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_prot_gate.a_idle_exact)
* parameters: `{}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-GATE --prop a_idle_exact --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `free` | 1 | 1 | 1 |
| `fwd_pend` | 0 | 0 | 0 |
| `idle` | 1 | 1 | 1 |
| `init_q` | 1 | 1 | 1 |
| `loc_acc` | 0 | 0 | 0 |
| `loc_pend` | 0 | 0 | 0 |
| `m_acc` | 0 | 0 | 0 |
| `m_held` | x | x | x |
| `m_req_addr` | 0x0 | 0x0 | 0x0 |
| `m_req_ready` | 0 | 0 | 0 |
| `m_req_valid` | 1 | 1 | 1 |
| `m_req_wdata` | 0x0 | 0x0 | 0x0 |
| `m_req_write` | 0 | 0 | 0 |
| `m_req_wstrb` | 0x0 | 0x0 | 0x0 |
| `m_rsp_error` | 0 | 0 | 0 |
| `m_rsp_rdata` | 0x0 | 0x0 | 0x0 |
| `m_rsp_ready` | 0 | 0 | 0 |
| `m_rsp_valid` | 0 | 0 | 0 |
| `mr_errdata_ok` | 1 | 1 | 1 |
| `mr_hs` | 0 | 0 | 0 |
| `mr_out` | 0x0 | 0x0 | 0x0 |
| `mr_solicited_ok` | 1 | 1 | 1 |
| `mr_stable_ok` | 1 | 1 | 1 |
| `refuse` | 0 | 0 | 0 |
| `refused_evt` | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 0 |
| `s_acc` | 0 | 0 | 0 |
| `s_held` | 0 | 0 | 0 |
| `s_req_addr` | 0x0 | 0x0 | 0x0 |
| `s_req_ready` | 0 | 0 | 0 |
| `s_req_valid` | 1 | 1 | 1 |
| `s_req_wdata` | 0x0 | 0x0 | 0x0 |
| `s_req_write` | 0 | 0 | 0 |
| `s_req_wstrb` | 0x0 | 0x0 | 0x0 |
| `s_rsp_hs` | 0 | 0 | 0 |
| `s_rsp_ready` | 0 | 0 | 0 |
| `s_rsp_valid` | 0 | 0 | 0 |
| `s_stable_ok` | 1 | 1 | 1 |

