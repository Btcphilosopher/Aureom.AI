# Counterexample: SEC-GATE-A / a_deny_order

* property: **a_deny_order** -- [G3 / ORD-01] while forwarded requests are outstanding NO error response is synthesised: the response is the target's
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_cit_gate.a_deny_order)
* parameters: `{"OUT_W": 3, "TGT_OK": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-GATE-A --prop a_deny_order --force`

## Signal values per step (harness top scope)

| `chk_addr_o` | 0x0 | 0x0 | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `chk_attr_o` | 0x0 | 0x0 | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx |
| `chk_cls_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_dom_o` | 0x0 | 0x0 | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx | xxxxxxxx |
| `chk_idx_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_len_o` | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 | 0x10 |
| `chk_op_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `chk_permit_i` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `chk_status_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x8 | 0x8 | 0x8 |
| `chk_valid_o` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `clk_i` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `flush_i` | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_req_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_req_ready_o` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `m_req_valid_i` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `m_rsp_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x80200000000000000000000000000000000 | 0x80200000000000000000000000000000000 | 0x80200000000000000000000000000000000 |
| `m_rsp_ready_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_valid_o` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `outstanding_o` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `rst_ni` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s_acc` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `s_basep` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `s_dec` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_fwd` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `s_have` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `s_loc_done` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_loc_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_out` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `s_out_zero` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `s_permit` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_taken` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_vp` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `t_req_o` | 0x0 | 0x0 | 000000000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 000000000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 000000000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 000000000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 000000000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 000000000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 000000000000xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `t_req_ready_i` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `t_req_valid_o` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `t_rsp_i` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x80200000000000000000000000000000000 | 0x80200000000000000000000000000000000 | 0x80200000000000000000000000000000000 |
| `t_rsp_ready_o` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `t_rsp_valid_i` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

