# Counterexample: SEC-PERM-A / a_permit_mem_window

* property: **a_permit_mem_window** -- [02] a memory permit => the range lies inside ONE valid window of an owning slot that grants the access
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_permit_mem_window)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_permit_mem_window --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 0 | 0 |
| `active` | 0x1 | 0x1 |
| `addr_i` | 0x0 | 0x0 |
| `attr_i` | 0x0 | 0x0 |
| `bind_i` | 0x3 | 0x3 |
| `bound` | 0x3 | 0x3 |
| `cap_priv_ok` | 0x3 | 0x3 |
| `cap_sec_ok` | 0x3 | 0x3 |
| `capab` | 0x3 | 0x3 |
| `cls_i` | 0x0 | 0x0 |
| `dev_any` | 0 | 0 |
| `dev_ov` | 0x0 | 0x0 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x12 | 0x12 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `k` | 0x2 | 0x2 |
| `last` | 0x7b | 0x7b |
| `last_w` | xxxxxxxxx01111011 | xxxxxxxxx01111011 |
| `len_i` | 0x7c | 0x7c |
| `lockdown_i` | 0 | 0 |
| `match` | 0x1 | 0x1 |
| `mem_ok` | 0x0 | 0x0 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x0 | 0x0 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x12 | 0x12 |
| `slot_o` | 0 | 0 |
| `slot_ok` | 0x1 | 0x1 |
| `slot_priv_i` | 0x1 | 0x1 |
| `slot_secure_i` | 0x1 | 0x1 |
| `slot_state_i` | 0x2 | 0x2 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `win_base_i` | 0x84040044 | 0x84040044 |
| `win_limit_i` | 0xfefe7afe | 0xfefe7afe |
| `win_r_i` | 0x3 | 0x3 |
| `win_valid_i` | 0x3 | 0x3 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

