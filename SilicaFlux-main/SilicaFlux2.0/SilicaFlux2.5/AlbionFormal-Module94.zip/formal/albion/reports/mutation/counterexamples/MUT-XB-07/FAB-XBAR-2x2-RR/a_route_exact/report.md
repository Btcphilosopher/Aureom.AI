# Counterexample: FAB-XBAR-2x2-RR / a_route_exact

* property: **a_route_exact** -- [R8/R9] a slave accepts a request only if the address map routes a master's accepted request to it (no invalid destination)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sfb_xbar.a_route_exact)
* parameters: `{"NM": 2, "NS": 2, "AW": 6, "DW": 16, "ARB_MODE": 1, "CHECK_ALIGN": 1, "SLV_BASE": 1024, "SLV_MASK": 3120, "MST_SLV_EN": 15, "R2_MASTERS": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-XBAR-2x2-RR --prop a_route_exact --force`

## Signal values per step (harness top scope)

| `acc_m` | 0x2 | 0x2 | 0x2 |
| `acc_s` | 0x2 | 0x2 | 0x2 |
| `clk` | 1 | 0 | 0 |
| `dec_hit` | 0x1 | 0x1 | 0x1 |
| `dec_s` | 0x2 | 0x2 | 0x2 |
| `ex_acc` | 0x0 | 0x0 | 0x0 |
| `init_q` | 1 | 1 | 1 |
| `m` | 0x2 | 0x2 | 0x2 |
| `m_req_addr` | 0x440 | 0x440 | 0x440 |
| `m_req_ready` | 0x2 | 0x2 | 0x2 |
| `m_req_valid` | 0x2 | 0x2 | 0x2 |
| `m_req_wdata` | 0x0 | 0x0 | 0x0 |
| `m_req_write` | 0x0 | 0x0 | 0x0 |
| `m_req_wstrb` | 0x0 | 0x0 | 0x0 |
| `m_rsp_ready` | 0x0 | 0x0 | 0x0 |
| `m_rsp_valid` | 0x0 | 0x0 | 0x0 |
| `mon_m_stable` | 0x3 | 0x3 | 0x3 |
| `mon_rsp_errdata` | 0x3 | 0x3 | 0x3 |
| `mon_rsp_solicited` | 0x3 | 0x3 | 0x3 |
| `mon_rsp_stable` | 0x3 | 0x3 | 0x3 |
| `rst_n` | 0 | 0 | 0 |
| `s` | 0xffffffff | 0xffffffff | 0xffffffff |
| `s_outstanding` | 0x0 | 0x0 | 0x0 |
| `s_req_ready` | 0x2 | 0x2 | 0x2 |
| `s_req_valid` | 0x2 | 0x2 | 0x2 |
| `s_rsp_error` | 0x0 | 0x0 | 0x0 |
| `s_rsp_rdata` | 0x0 | 0x0 | 0x0 |
| `s_rsp_ready` | 0x0 | 0x0 | 0x0 |
| `s_rsp_valid` | 0x0 | 0x0 | 0x0 |
| `v_route` | 1 | 1 | 1 |

