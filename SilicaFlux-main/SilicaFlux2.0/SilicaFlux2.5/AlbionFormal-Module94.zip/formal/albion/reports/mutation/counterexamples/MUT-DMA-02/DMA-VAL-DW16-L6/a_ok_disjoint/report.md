# Counterexample: DMA-VAL-DW16-L6 / a_ok_disjoint

* property: **a_ok_disjoint** -- validated => source and destination ranges are disjoint (no overlap, incl. src_r == dst_r)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_validate.a_ok_disjoint)
* parameters: `{"DW": 16, "MAX_LEN_LOG2": 6}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-VAL-DW16-L6 --prop a_ok_disjoint --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `code` | 0x0 | 0x0 | 0x0 |
| `d_end` | 0xc2 | 0xc2 | 0xc2 |
| `dst` | 0x0 | 0x0 | 0x0 |
| `dst_q` | 0x82 | 0x82 | 0x82 |
| `dst_r` | 0x82 | 0x82 | 0x82 |
| `len` | 0x0 | 0x0 | 0x0 |
| `len_q` | 0x40 | 0x40 | 0x40 |
| `len_r` | 0x40 | 0x40 | 0x40 |
| `s_end` | 0x100 | 0x100 | 0x100 |
| `src` | 0x0 | 0x0 | 0x0 |
| `src_q` | 0xc0 | 0xc0 | 0xc0 |
| `src_r` | 0xc0 | 0xc0 | 0xc0 |

