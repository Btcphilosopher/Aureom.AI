# Counterexample: DMA-REG-E0-P1 / a_reset_values

* property: **a_reset_values** -- reset values: descriptor registers 0, no interrupt
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_regs.a_reset_values)
* parameters: `{"DW": 32, "ENGINE": 0, "FIFO_DEPTH": 1, "MAX_LEN_LOG2": 24, "PERF": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-REG-E0-P1 --prop a_reset_values --force`

## Signal values per step (harness top scope)

| `busy` | 0 | 0 | 0 |
| `bytes_done` | 0x0 | 0x0 | 0x0 |
| `cfg_dst` | 0x0 | 0x0 | 0x0 |
| `cfg_len` | 0x40000000 | 0x40000000 | 0x40000000 |
| `cfg_src` | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 0 |
| `done` | 0 | 0 | 0 |
| `err_addr` | 0x0 | 0x0 | 0x0 |
| `err_code` | 0x0 | 0x0 | 0x0 |
| `ev_stall` | 0 | 0 | 0 |
| `fail` | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 1 |
| `irq` | 0 | 0 | 0 |
| `m_info` | 0x1180004 | 0x1180004 | 0x1180004 |
| `rb_addr` | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 0 | 0 | 0 |
| `rb_wdata` | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 0 |
| `state` | 0x0 | 0x0 | 0x0 |

