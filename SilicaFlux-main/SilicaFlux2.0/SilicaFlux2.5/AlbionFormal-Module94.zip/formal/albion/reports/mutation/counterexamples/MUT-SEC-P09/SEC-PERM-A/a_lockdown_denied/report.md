# Counterexample: SEC-PERM-A / a_lockdown_denied

* property: **a_lockdown_denied** -- [02 step 8] safe state denies every domain except ROOT/MGMT
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_lockdown_denied)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_lockdown_denied --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 1 | 1 |
| `addr_i` | 0xe4 | 0xe4 |
| `attr_i` | 0x8 | 0x8 |
| `bind_i` | 0x2 | 0x2 |
| `cls_i` | 0x1 | 0x1 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x24 | 0x24 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x0 | 0x0 |
| `is_sys` | 0 | 0 |
| `k` | 0x2 | 0x2 |
| `len_i` | 0xfd | 0xfd |
| `lockdown_i` | 1 | 1 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x4 | 0x4 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x2400 | 0x2400 |
| `slot_o` | 1 | 1 |
| `slot_priv_i` | 0x0 | 0x0 |
| `slot_secure_i` | 0x2 | 0x2 |
| `slot_state_i` | 0x8 | 0x8 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `win_base_i` | 0x8080808 | 0x8080808 |
| `win_limit_i` | 0x8f80808 | 0x8f80808 |
| `win_r_i` | 0x4 | 0x4 |
| `win_valid_i` | 0x4 | 0x4 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

