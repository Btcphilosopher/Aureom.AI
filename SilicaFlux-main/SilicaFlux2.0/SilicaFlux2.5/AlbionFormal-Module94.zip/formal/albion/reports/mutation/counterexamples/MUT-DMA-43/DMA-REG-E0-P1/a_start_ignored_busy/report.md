# Counterexample: DMA-REG-E0-P1 / a_start_ignored_busy

* property: **a_start_ignored_busy** -- [DMA.md 3] no start pulse is generated while BUSY
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_regs.a_start_ignored_busy)
* parameters: `{"DW": 32, "ENGINE": 0, "FIFO_DEPTH": 1, "MAX_LEN_LOG2": 24, "PERF": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-REG-E0-P1 --prop a_start_ignored_busy --force`

## Signal values per step (harness top scope)

| `busy` | 1 | 1 | 1 |
| `bytes_done` | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 0 |
| `done` | 0 | 0 | 0 |
| `err_addr` | 0x0 | 0x0 | 0x0 |
| `err_code` | 0x0 | 0x0 | 0x0 |
| `ev_stall` | 0 | 0 | 0 |
| `fail` | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 1 |
| `m_info` | 0x1180004 | 0x1180004 | 0x1180004 |
| `rb_addr` | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 1 | 1 | 1 |
| `rb_wdata` | 0x1 | 0x1 | 0x1 |
| `rb_we` | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 0 |
| `start` | 1 | 1 | 1 |
| `state` | 0x0 | 0x0 | 0x0 |

