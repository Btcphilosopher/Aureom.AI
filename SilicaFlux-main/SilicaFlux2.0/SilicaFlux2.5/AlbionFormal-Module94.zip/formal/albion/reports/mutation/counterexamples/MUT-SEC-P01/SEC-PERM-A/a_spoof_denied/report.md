# Counterexample: SEC-PERM-A / a_spoof_denied

* property: **a_spoof_denied** -- [02 step 7 / domain association] a domain id not bound to the PHYSICAL source port is always denied
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_spoof_denied)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_spoof_denied --force`

## Signal values per step (harness top scope)

| `a_instr` | 1 | 1 |
| `a_priv` | 0 | 0 |
| `a_secure` | 0 | 0 |
| `addr_i` | 0x84 | 0x84 |
| `attr_i` | 0x10 | 0x10 |
| `bind_i` | 0x0 | 0x0 |
| `bound` | 0x0 | 0x0 |
| `cls_i` | 0x1 | 0x1 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0xa6 | 0xa6 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x0 | 0x0 |
| `k` | 0x2 | 0x2 |
| `len_i` | 0xd1 | 0xd1 |
| `lockdown_i` | 0 | 0 |
| `match` | 0x1 | 0x1 |
| `mw` | 0x0 | 0x0 |
| `op_i` | 0x1 | 0x1 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x1 | 0x1 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0xa6 | 0xa6 |
| `slot_o` | 0 | 0 |
| `slot_priv_i` | 0x0 | 0x0 |
| `slot_secure_i` | 0x0 | 0x0 |
| `slot_state_i` | 0x2 | 0x2 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `win_base_i` | 0x8080800 | 0x8080800 |
| `win_limit_i` | 0x80808080 | 0x80808080 |
| `win_r_i` | 0x1 | 0x1 |
| `win_valid_i` | 0x1 | 0x1 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x1 | 0x1 |

