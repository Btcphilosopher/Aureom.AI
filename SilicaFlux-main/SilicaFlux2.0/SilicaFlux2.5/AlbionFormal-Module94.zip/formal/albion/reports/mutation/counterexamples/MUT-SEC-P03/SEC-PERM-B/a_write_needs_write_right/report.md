# Counterexample: SEC-PERM-B / a_write_needs_write_right

* property: **a_write_needs_write_right** -- [02] a WRITE memory permit needs a window with the WRITE right (the read right is not enough)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_write_needs_write_right)
* parameters: `{"UNIQ": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-B --prop a_write_needs_write_right --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 1 | 1 |
| `a_secure` | 0 | 0 |
| `active` | 0x1 | 0x1 |
| `addr_i` | 0xe | 0xe |
| `attr_i` | 0x4 | 0x4 |
| `bind_i` | 0x1 | 0x1 |
| `bound` | 0x1 | 0x1 |
| `cap_priv_ok` | 0x1 | 0x1 |
| `cap_sec_ok` | 0x3 | 0x3 |
| `capab` | 0x1 | 0x1 |
| `cls_i` | 0x0 | 0x0 |
| `cont_w` | 0x0 | 0x0 |
| `dev_any` | 0 | 0 |
| `dev_ov` | 0x0 | 0x0 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x1 | 0x1 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `k` | 0x2 | 0x2 |
| `last` | 0xbf | 0xbf |
| `last_w` | xxxxxxxxx10111111 | xxxxxxxxx10111111 |
| `len_i` | 0xb2 | 0xb2 |
| `lockdown_i` | 0 | 0 |
| `match` | 0x1 | 0x1 |
| `op_i` | 0x2 | 0x2 |
| `perm_has_w` | 0 | 0 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x0 | 0x0 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x1 | 0x1 |
| `slot_o` | 0 | 0 |
| `slot_ok` | 0x1 | 0x1 |
| `slot_priv_i` | 0x1 | 0x1 |
| `slot_secure_i` | 0x1 | 0x1 |
| `slot_state_i` | 0x2 | 0x2 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `uniq_ok` | 1 | 1 |
| `win_base_i` | 0x82800200 | 0x82800200 |
| `win_limit_i` | 0xcb0b2beb | 0xcb0b2beb |
| `win_r_i` | 0x1 | 0x1 |
| `win_valid_i` | 0x1 | 0x1 |
| `win_w_i` | 0x0 | 0x0 |
| `win_x_i` | 0x0 | 0x0 |

