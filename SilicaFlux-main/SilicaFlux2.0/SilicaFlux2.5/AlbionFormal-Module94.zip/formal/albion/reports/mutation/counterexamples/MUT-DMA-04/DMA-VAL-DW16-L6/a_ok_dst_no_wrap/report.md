# Counterexample: DMA-VAL-DW16-L6 / a_ok_dst_no_wrap

* property: **a_ok_dst_no_wrap** -- validated => dst_r + len_r <= 2^32 (destination range does not wrap)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_dma_validate.a_ok_dst_no_wrap)
* parameters: `{"DW": 16, "MAX_LEN_LOG2": 6}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-VAL-DW16-L6 --prop a_ok_dst_no_wrap --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `code` | 0x0 | 0x0 | 0x0 |
| `d_end` | 0x100000001 | 0x100000001 | 0x100000001 |
| `dst` | 0x0 | 0x0 | 0x0 |
| `dst_q` | 0xfffffffa | 0xfffffffa | 0xfffffffa |
| `dst_r` | 0xfffffffa | 0xfffffffa | 0xfffffffa |
| `len` | 0x0 | 0x0 | 0x0 |
| `len_q` | 0x7 | 0x7 | 0x7 |
| `len_r` | 0x7 | 0x7 | 0x7 |
| `src` | 0x0 | 0x0 | 0x0 |
| `src_q` | 0x2 | 0x2 | 0x2 |
| `src_r` | 0x2 | 0x2 | 0x2 |

