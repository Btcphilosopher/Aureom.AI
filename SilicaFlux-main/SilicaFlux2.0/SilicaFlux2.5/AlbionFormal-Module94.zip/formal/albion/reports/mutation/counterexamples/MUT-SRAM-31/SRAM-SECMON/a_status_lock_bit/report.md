# Counterexample: SRAM-SECMON / a_status_lock_bit

* property: **a_status_lock_bit** -- STATUS[0] reads HOST_LOCK
* failing step: 2 (witness replay: CONFIRMED: simulation violates fv_prot_secmon.a_status_lock_bit)
* parameters: `{}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-SECMON --prop a_status_lock_bit --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `host_lock` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `rb_addr` | 0x0 | 0x0 | 0x8 | 0x8 | 0x4 | 0x4 | 0x4 |
| `rb_rdata` | 0x70 | 0x70 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `rb_sel` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `rb_wdata` | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `viol_addr` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `viol_evt` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

