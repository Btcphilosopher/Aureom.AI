# Counterexample: SRAM-PROT-WORD-D4P2 / a_prot_refused_answered_error

* property: **a_prot_refused_answered_error** -- a protected write evaluated while host_lock = 1 is answered with rsp_error = 1 (never acknowledged as done)
* failing step: 3 (witness replay: CONFIRMED: simulation violates fv_prot_compose_word.a_prot_refused_answered_error)
* parameters: `{"DEPTH": 4, "LAT": 1, "PLO": 2}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SRAM-PROT-WORD-D4P2 --prop a_prot_refused_answered_error --force`

## Signal values per step (harness top scope)

| `b` | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `eval_q` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `first_eval` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `free` | 1 | 1 | 1 | 1 | 1 | 1 | 0 | 0 | 0 |
| `fwd_pend` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `host_lock` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `loc_acc` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `loc_pend` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `lock_fe` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `lockfe_q` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `m_acc` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_req_addr` | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 |
| `m_req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `m_req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_req_write` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `m_req_wstrb` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `m_rsp_error` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_hs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `prot` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rb_addr` | 0x0 | 0x0 | 0x8 | 0x8 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rb_sel` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `rb_wdata` | 0x0 | 0x0 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rb_we` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `refuse` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `refused_evt` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `rq_ref` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rq_v` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `s_acc` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `s_held` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_req_addr` | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 | 0x8 |
| `s_req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `s_req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `s_req_wdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_req_write` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `s_req_wstrb` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `s_rsp_error` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_rsp_hs` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_rsp_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 |
| `s_stable_ok` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ta` | xx | xx | xx | xx | xx | xx | xx | xx | xx |
| `unauth` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `wi` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |

