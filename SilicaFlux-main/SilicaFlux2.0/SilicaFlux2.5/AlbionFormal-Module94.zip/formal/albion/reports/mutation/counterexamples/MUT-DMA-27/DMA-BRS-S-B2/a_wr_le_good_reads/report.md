# Counterexample: DMA-BRS-S-B2 / a_wr_le_good_reads

* property: **a_wr_le_good_reads** -- [DMA.md 5] writes never overtake good reads: accepted writes <= good read responses
* failing step: 8 (witness replay: CONFIRMED: simulation violates fv_dma_burst.a_wr_le_good_reads)
* parameters: `{"DW": 16, "MAX_LEN_LOG2": 4, "FIFO_DEPTH": 4, "BURST": 2, "DUAL_PORT": 0, "MAX_OUT": 2, "SMALL": 1, "AB": 6}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job DMA-BRS-S-B2 --prop a_wr_le_good_reads --force`

## Signal values per step (harness top scope)

| `abort` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `any_req` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `b` | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 |
| `busy` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `cfg_dst` | 0x0 | 0x0 | 0x20 | 0x20 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_len` | 0x0 | 0x0 | 0x3 | 0x3 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `cfg_src` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `clk` | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 1 | 0 | 0 |
| `fifo_level` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 |
| `g_nb` | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 0xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `g_stop` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `gd` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `gl` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `go` | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `gs` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `init_q` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_acc` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `out0` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `outst` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `outw` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 | 0x1 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `ph_obs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `r_err` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `r_hs` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `r_sol` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `r_stable` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ra` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `rd_good` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rd_good_now` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_g` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_ok` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `req_write` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 1 |
| `rsp_error` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_rdata` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 |
| `rsp_ready` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rst_n` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `start` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `state` | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x2 | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 | 0x4 |
| `wa` | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx | 00xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx |
| `wk` | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx | 0000000000000000000000000000000xxx |
| `wr_acc` | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x0 | 0x1 | 0x1 | 0x1 |
| `wr_acc_now` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 | 0 |
| `wr_rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `wr_rsp_g` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

