# Counterexample: SEC-PERM-A / a_no_wrap

* property: **a_no_wrap** -- [02 step 11-12] an ADDR permit has a non-zero length and addr+len-1 does not wrap the address space
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_cit_perm.a_no_wrap)
* parameters: `{"UNIQ": 0}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job SEC-PERM-A --prop a_no_wrap --force`

## Signal values per step (harness top scope)

| `a_instr` | 0 | 0 |
| `a_priv` | 0 | 0 |
| `a_secure` | 0 | 0 |
| `addr_i` | 0xf8 | 0xf8 |
| `attr_i` | 0x0 | 0x0 |
| `bind_i` | 0x1 | 0x1 |
| `cls_i` | 0x0 | 0x0 |
| `devrd_i` | 0x0 | 0x0 |
| `devwr_i` | 0x0 | 0x0 |
| `dft_active_i` | 0 | 0 |
| `dom_i` | 0x81 | 0x81 |
| `i` | 0x2 | 0x2 |
| `idx_i` | 0x1 | 0x1 |
| `k` | 0x2 | 0x2 |
| `last` | 0xa6 | 0xa6 |
| `last_w` | 0x1a6 | 0x1a6 |
| `len_i` | 0xaf | 0xaf |
| `lockdown_i` | 0 | 0 |
| `no_wrap` | 0 | 0 |
| `op_i` | 0x2 | 0x2 |
| `permit_o` | 1 | 1 |
| `port_isol_i` | 0x0 | 0x0 |
| `qhold_i` | 0x0 | 0x0 |
| `qmask_i` | 0x0 | 0x0 |
| `reason_o` | 0x0 | 0x0 |
| `s` | 0x2 | 0x2 |
| `slot_id_i` | 0x2081 | 0x2081 |
| `slot_o` | 0 | 0 |
| `slot_priv_i` | 0x0 | 0x0 |
| `slot_secure_i` | 0x0 | 0x0 |
| `slot_state_i` | 0x2 | 0x2 |
| `slot_vld_o` | 1 | 1 |
| `src_i` | 0 | 0 |
| `win_base_i` | 0xc | 0xc |
| `win_limit_i` | 0x820282b2 | 0x820282b2 |
| `win_r_i` | 0x0 | 0x0 |
| `win_valid_i` | 0x1 | 0x1 |
| `win_w_i` | 0x1 | 0x1 |
| `win_x_i` | 0x0 | 0x0 |

