# Counterexample: FAB-XBAR-2x3-FIX / a_r11_no_ready_in_reset

* property: **a_r11_no_ready_in_reset** -- [R11] during reset the fabric's req_ready is 0 (so reset can generate no transfer)
* failing step: 0 (witness replay: CONFIRMED: simulation violates fv_sfb_xbar.a_r11_no_ready_in_reset)
* parameters: `{"NM": 2, "NS": 3, "AW": 6, "DW": 16, "ARB_MODE": 0, "CHECK_ALIGN": 1, "SLV_BASE": 132096, "SLV_MASK": 232496, "MST_SLV_EN": 63, "R2_MASTERS": 1}`
* waveform: `trace.vcd` if present (open with GTKWave; DUT-internal signals are prefixed `dut.`); `cex.aiw`/`cex.yw` = ABC witness / Yosys witness
* reproduce: `python3 tools/albion_formal.py run --job FAB-XBAR-2x3-FIX --prop a_r11_no_ready_in_reset --force`

## Signal values per step (harness top scope)

| `clk` | 1 | 0 | 0 |
| `init_q` | 1 | 1 | 1 |
| `m` | 0x2 | 0x2 | 0x2 |
| `m_req_addr` | 0x0 | 0x0 | 0x0 |
| `m_req_ready` | 0x2 | 0x2 | 0x2 |
| `m_req_valid` | 0x2 | 0x2 | 0x2 |
| `m_req_wdata` | 0x0 | 0x0 | 0x0 |
| `m_req_write` | 0x2 | 0x2 | 0x2 |
| `m_req_wstrb` | 0x0 | 0x0 | 0x0 |
| `m_rsp_ready` | 0x0 | 0x0 | 0x0 |
| `m_rsp_valid` | 0x0 | 0x0 | 0x0 |
| `mon_m_stable` | 0x3 | 0x3 | 0x3 |
| `mon_rsp_errdata` | 0x7 | 0x7 | 0x7 |
| `mon_rsp_solicited` | 0x7 | 0x7 | 0x7 |
| `mon_rsp_stable` | 0x7 | 0x7 | 0x7 |
| `rst_n` | 0 | 0 | 0 |
| `s` | 0xffffffff | 0xffffffff | 0xffffffff |
| `s_outstanding` | 0x0 | 0x0 | 0x0 |
| `s_req_ready` | 0x1 | 0x1 | 0x1 |
| `s_req_valid` | 0x1 | 0x1 | 0x1 |
| `s_rsp_error` | 0x0 | 0x0 | 0x0 |
| `s_rsp_rdata` | 0x0 | 0x0 | 0x0 |
| `s_rsp_ready` | 0x0 | 0x0 | 0x0 |
| `s_rsp_valid` | 0x0 | 0x0 | 0x0 |

