// =============================================================================
// AlbionFormal :: lib/albion_sva.svh -- assertion library (yosys-0.33 compatible SystemVerilog assertions)
//
// WHY IMMEDIATE ASSERTIONS.  The open-source front end used here (Yosys 0.33, `read_verilog -formal`) supports
// `assert/assume/cover` immediate assertions, labels, `(* anyconst *)` and `initial`; it does NOT support
// concurrent SVA sequences/implication operators (`|->`, `##`, `throughout` ...), which need a commercial front end
// (Verific / Jasper / Questa).  Every temporal property in this suite is therefore written in the standard
// "monitor" style: explicit history registers + an immediate assertion.  That is plain SystemVerilog and is
// portable to any formal tool; the macros below add the bookkeeping this suite needs:
//
//   * every assertion/cover has a NUMERIC ID, a NAME (used as the label) and a one-line TEXT;
//   * `ALB_SEL` (a parameter of every harness top, default 0) selects ONE assertion/cover (ID) or ALL (0).  The
//     runner proves every property in its own run, so each ledger row is a statement about exactly one property;
//   * tools/albion_formal.py scans harness sources for these macros -- the property catalogue is the source,
//     it cannot drift from the code.
//
// Usage inside a harness (names must be unique per harness, IDs unique per harness):
//     `ALB_ASSERT(10, a_grant_onehot0, "grant is one-hot or zero", $onehot0(grant))
//     `ALB_COVER (90, c_two_requesters, "two requesters at once", $countones(req) >= 2)
//     `ALB_ASSUME(e_no_stall_idle, "stall only while granted", stall |-> grant_valid ... written as plain boolean)
//
// A harness top must declare:   parameter ALB_SEL = 0
// Statements must be placed in a procedural block (always @(*) or always @(posedge clk)); the macros end with ';'.
// =============================================================================
`ifndef ALBION_SVA_SVH
`define ALBION_SVA_SVH

// Assertion: disabled (trivially true) unless it is the selected one (or ALL are selected).
`define ALB_ASSERT(ID, NAME, TEXT, COND) \
  NAME : assert ( ((ALB_SEL != 0) && (ALB_SEL != (ID))) || (COND) );

// Cover: only the selected cover (or all) can be hit.
// With -DALB_COVER_AS_ASSERT (the runner's default for covers) the cover is compiled as the safety property
// "this situation never happens": its COUNTEREXAMPLE is the witness trace.  That lets ABC's bit-level BMC find
// witnesses fast and lets PDR prove a cover UNREACHABLE for all time (not just to a depth).
`ifdef ALB_COVER_AS_ASSERT
`define ALB_COVER(ID, NAME, TEXT, COND) \
  NAME : assert ( !( ((ALB_SEL == 0) || (ALB_SEL == (ID))) && (COND) ) );
`else
`define ALB_COVER(ID, NAME, TEXT, COND) \
  NAME : cover ( ((ALB_SEL == 0) || (ALB_SEL == (ID))) && (COND) );
`endif

// Assumption (environment constraint): ALWAYS active.  It is listed in the ledger via the job's assume-set.
`define ALB_ASSUME(NAME, TEXT, COND) \
  NAME : assume ( COND );

// Implication helper for boolean monitors:  `ALB_IMPL(a, b)  ==  (a) |-> (b)  (same cycle)
`define ALB_IMPL(A, B) (!(A) || (B))

`endif
