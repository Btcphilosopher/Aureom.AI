// =============================================================================
// AlbionFormal :: env/albion_env_reset.sv -- clock / reset environment
//
// CLOCK.   Single clock domain.  Formal time steps are clock cycles (Yosys `async2sync` model); the clock port of a
//          harness is only a time base.  No clock gating, no multi-clock behaviour and no CDC is modelled -- see
//          docs/ASSUMPTIONS.md  (ENV-CLK).
// RESET.   All SilicaFlux blocks here use an ASYNCHRONOUS-assert, active-low reset (rst_n / rst_ni).  Under
//          `async2sync` a reset that is low in step t forces the reset state onto the outputs of step t and the
//          registers of step t+1 (the usual sampled model of an async reset).
//
//   MODE 0  ENV-RST-FIRST   reset is asserted in step 0 and never again           (strongest environment)
//   MODE 1  ENV-RST-ANY     reset asserted in step 0; afterwards it may assert at any step and for any duration
//                           (covers "reset in the middle of a transfer", SFB2 rule R11)
//   MODE 2  ENV-RST-NONE    no reset constraint at all (step-0 state arbitrary).  Only for properties that must
//                           hold from EVERY state (e.g. combinational checkers, one-step table invariants).
//
// `init_q` is 1 in step 0 only.  Harnesses use it to suppress history-based checks in the first cycle.
// =============================================================================
`default_nettype none
module albion_env_reset #(
  parameter MODE = 1
) (
  input  wire clk,
  input  wire rst_n,
  output wire init_q
);
  reg init_r = 1'b1;
  always @(posedge clk) init_r <= 1'b0;
  assign init_q = init_r;

  always @(*) begin
    if (MODE != 2 && init_r) assume (!rst_n);
    if (MODE == 0 && !init_r) assume (rst_n);
  end
endmodule
`default_nettype wire
