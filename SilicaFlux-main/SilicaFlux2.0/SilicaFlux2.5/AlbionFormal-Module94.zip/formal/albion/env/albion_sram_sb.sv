// =============================================================================
// AlbionFormal :: env/albion_sram_sb.sv -- single-address SRAM scoreboard (reference model; NO assertions)
//
// A reference model of the documented SRAM-library contract (docs/mem/01_interface_spec.md sections 2-4, 8), written
// from the specification, not from the RTL.  It follows ONE symbolic word address `ta` (the harness declares
// `(* anyconst *) ta`; a proof over every ta is a proof over every address) and exposes check wires `ok_*`; the harness
// decides ASSUME/ASSERT so that every property is its own run (docs/HARNESS_GUIDE.md C1).
//
//   Shadow word      per byte-lane `known` flag + value.  The array has NO defined power-up content (spec section 9), so a lane
//                    becomes known (a) when an array write covers it, or (b) when it is first OBSERVED by a read of a lane
//                    that no write has touched ("learning").  Every later read of a known lane must return the shadow value:
//                    this checks "masked write changes only its lanes" AND "unwritten bytes remain unchanged".  A reset clears
//                    `known` (the model never claims a value for lanes it has not seen since reset).
//   Raw check        the array output (`raw_rdata`, = tst_rdata) must carry, exactly LAT cycles after an array read of `ta`,
//                    the shadow value of every lane that was known when the read was performed.
//   Response queue   every accepted response-producing request (reads, WRITE_ACK writes, invalid-address requests) is pushed
//                    in acceptance order with: kind, error flag, id, and (reads of `ta`) the lane snapshot.  The DUT's
//                    response channel must be exactly this queue:  rsp_valid <=> head exists and has aged >= LAT cycles;
//                    payload (err/we/id/data) equals the head's; popped on rsp_valid && rsp_ready.  Lanes unknown at read time
//                    are completed from the raw array output of that very read (the "fill"), so the response is also tied to
//                    what the array returned.
//
// Port timing: all inputs are the values of the CURRENT cycle (pre-edge).  `arr_*` are the array-boundary events the
// SPEC says must occur (computed by the harness from the DUT's input ports), `acc*` the accepted functional request.
// =============================================================================
`default_nettype none
module albion_sram_sb #(
  parameter DW = 16, MW = 2, AW = 2, DEPTH = 4, LAT = 1, QD = 2,
  parameter WACK = 1, IDW = 1, CHECK_WE = 1, CHECK_ID = 1
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire [AW-1:0]     ta,
  // spec-model array events
  input  wire              arr_ce,
  input  wire              arr_we,
  input  wire [MW-1:0]     arr_wmask,
  input  wire [AW-1:0]     arr_addr,
  input  wire [DW-1:0]     arr_wdata,
  input  wire [DW-1:0]     raw_rdata,
  // accepted functional request (0 when the harness has no functional channel)
  input  wire              acc,
  input  wire              acc_we,
  input  wire [AW-1:0]     acc_addr,
  input  wire [IDW-1:0]    acc_id,
  // response channel
  input  wire              rsp_valid,
  input  wire              rsp_ready,
  input  wire [DW-1:0]     rsp_rdata,
  input  wire              rsp_err,
  input  wire              rsp_we,
  input  wire [IDW-1:0]    rsp_id,
  // checks
  output wire              ok_raw,
  output wire              ok_raw_written,     // lanes written by an array write: exact value after masked writes
  output wire              ok_raw_unwritten,   // lanes never written (learned): value unchanged between reads
  output wire              ok_rsp_valid,
  output wire              ok_err,
  output wire              ok_we,
  output wire              ok_id,
  output wire              ok_zero,
  output wire              ok_data,
  output wire              ok_stable,
  output wire              ov,            // credit overflow: more outstanding responses than QD
  output wire [3:0]        qcount,
  // coverage flags
  output wire              cv_raw_checked,
  output wire              cv_raw_partial,
  output wire              cv_raw_unwritten,   // a lane that no write ever touched was re-read and compared (stability of unwritten bytes)
  output wire              cv_partial_write,
  output wire              cv_backpressure,
  output wire              cv_full,
  output wire              cv_err_rsp,
  output wire              cv_data_checked
);
  localparam LW  = DW / MW;
  localparam AGW = $clog2(LAT + 2);
  localparam [AGW-1:0] AGSAT = LAT + 1;
  wire [DW-1:0] ALL1 = {DW{1'b1}};

  // ---------------------------------------------------------------- shadow word
  reg  [DW-1:0] sh_dt;
  reg  [MW-1:0] sh_kn, sh_wr;                       // known, written-by-an-array-write
  wire arr_hit = arr_ce && (arr_addr == ta);
  wire arr_wr  = arr_hit && arr_we;
  wire arr_rd  = arr_hit && !arr_we;

  // ---------------------------------------------------------------- raw read pipeline (snapshots of the shadow at read time)
  reg  [LAT-1:0]    p_v;
  reg  [LAT*MW-1:0] p_kn, p_lrn;
  reg  [LAT*DW-1:0] p_dt;
  wire              pv_o  = p_v[LAT-1];
  wire [MW-1:0]     pkn_o = p_kn[(LAT-1)*MW +: MW];
  wire [MW-1:0]     plr_o = p_lrn[(LAT-1)*MW +: MW];
  wire [DW-1:0]     pdt_o = p_dt[(LAT-1)*DW +: DW];

  // lane masks expanded to bit masks
  reg [DW-1:0] pkn_bits;
  integer l;
  always @(*) begin
    pkn_bits = {DW{1'b0}};
    for (l = 0; l < MW; l = l + 1)
      if (pkn_o[l]) pkn_bits[l*LW +: LW] = {LW{1'b1}};
  end
  assign ok_raw = !pv_o || ((raw_rdata & pkn_bits) == (pdt_o & pkn_bits));
  // split: lanes learned (never written) vs lanes written by an array write
  reg [DW-1:0] plr_bits, pwr_bits;
  always @(*) begin
    plr_bits = {DW{1'b0}}; pwr_bits = {DW{1'b0}};
    for (l = 0; l < MW; l = l + 1) begin
      if (plr_o[l])             plr_bits[l*LW +: LW] = {LW{1'b1}};
      if (pkn_o[l] && !plr_o[l]) pwr_bits[l*LW +: LW] = {LW{1'b1}};
    end
  end
  assign ok_raw_unwritten = !pv_o || ((raw_rdata & plr_bits) == (pdt_o & plr_bits));
  assign ok_raw_written   = !pv_o || ((raw_rdata & pwr_bits) == (pdt_o & pwr_bits));

  // ---------------------------------------------------------------- response queue
  wire addr_ok   = ({1'b0, acc_addr} < DEPTH);
  wire needs_rsp = !acc_we || (WACK != 0) || !addr_ok;
  wire push      = acc && needs_rsp;

  reg  [QD-1:0]    e_v, e_rd, e_err, e_we, e_tr;
  reg  [QD*MW-1:0] e_kn;
  reg  [QD*DW-1:0] e_dt;
  reg  [QD*IDW-1:0] e_id;
  reg  [QD*AGW-1:0] e_age;

  reg  [QD-1:0]    n_v, n_rd, n_err, n_we, n_tr;
  reg  [QD*MW-1:0] n_kn;
  reg  [QD*DW-1:0] n_dt;
  reg  [QD*IDW-1:0] n_id;
  reg  [QD*AGW-1:0] n_age;
  reg  [DW-1:0]    n_sh_dt;
  reg  [MW-1:0]    n_sh_kn, n_sh_wr;

  wire pop = rsp_valid && rsp_ready && e_v[0];

  integer i, src, cnt, pos, q;
  reg [DW-1:0] fill_bits;
  reg [MW-1:0] fkn;
  reg [DW-1:0] fdt;
  reg          fillnow;
  reg [AGW-1:0] ag;
  always @(*) begin
    cnt = 0;
    for (i = 0; i < QD; i = i + 1) cnt = cnt + (e_v[i] ? 1 : 0);
    n_v = {QD{1'b0}}; n_rd = {QD{1'b0}}; n_err = {QD{1'b0}}; n_we = {QD{1'b0}}; n_tr = {QD{1'b0}};
    n_kn = {(QD*MW){1'b0}}; n_dt = {(QD*DW){1'b0}}; n_id = {(QD*IDW){1'b0}}; n_age = {(QD*AGW){1'b0}};
    for (i = 0; i < QD; i = i + 1) begin
      src = pop ? i + 1 : i;
      if (src < QD) begin
        fillnow = e_v[src] && e_tr[src] && (e_age[src*AGW +: AGW] == LAT) && pv_o;
        fkn = e_kn[src*MW +: MW];
        fdt = e_dt[src*DW +: DW];
        if (fillnow) begin
          for (l = 0; l < MW; l = l + 1)
            if (!fkn[l]) begin fdt[l*LW +: LW] = raw_rdata[l*LW +: LW]; fkn[l] = 1'b1; end
        end
        ag = e_age[src*AGW +: AGW];
        n_v[i]   = e_v[src];   n_rd[i] = e_rd[src];  n_err[i] = e_err[src]; n_we[i] = e_we[src]; n_tr[i] = e_tr[src];
        n_kn[i*MW +: MW] = fkn;  n_dt[i*DW +: DW] = fdt;  n_id[i*IDW +: IDW] = e_id[src*IDW +: IDW];
        n_age[i*AGW +: AGW] = (ag >= AGSAT) ? AGSAT : ag + 1'b1;
      end
    end
    pos = cnt - (pop ? 1 : 0);
    if (push && pos < QD) begin
      n_v[pos] = 1'b1;
      n_rd[pos]  = !acc_we && addr_ok;
      n_err[pos] = !addr_ok;
      n_we[pos]  = acc_we;
      n_tr[pos]  = !acc_we && addr_ok && (acc_addr == ta);
      n_kn[pos*MW +: MW]  = n_tr[pos] ? sh_kn : {MW{1'b0}};
      n_dt[pos*DW +: DW]  = sh_dt;
      n_id[pos*IDW +: IDW] = acc_id;
      n_age[pos*AGW +: AGW] = 1;
    end
    // shadow: learn from the array output of an earlier read, then apply an array write (a write overrides a learn)
    n_sh_dt = sh_dt; n_sh_kn = sh_kn; n_sh_wr = sh_wr;
    if (pv_o) begin
      for (l = 0; l < MW; l = l + 1)
        if (!pkn_o[l] && !sh_kn[l]) begin n_sh_dt[l*LW +: LW] = raw_rdata[l*LW +: LW]; n_sh_kn[l] = 1'b1; end
    end
    if (arr_wr) begin
      for (l = 0; l < MW; l = l + 1)
        if (arr_wmask[l]) begin n_sh_dt[l*LW +: LW] = arr_wdata[l*LW +: LW]; n_sh_kn[l] = 1'b1; n_sh_wr[l] = 1'b1; end
    end
  end

  integer k;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      sh_kn <= {MW{1'b0}}; sh_wr <= {MW{1'b0}};
      p_v <= {LAT{1'b0}};
      e_v <= {QD{1'b0}};
    end else begin
      sh_kn <= n_sh_kn; sh_wr <= n_sh_wr;
      p_v[0] <= arr_rd;
      for (k = 1; k < LAT; k = k + 1) p_v[k] <= p_v[k-1];
      e_v <= n_v;
    end
  end
  // payload registers carry no reset (only observed when the matching valid bit is set)
  always @(posedge clk) begin
    sh_dt <= n_sh_dt;
    e_rd <= n_rd; e_err <= n_err; e_we <= n_we; e_tr <= n_tr; e_kn <= n_kn; e_dt <= n_dt; e_id <= n_id; e_age <= n_age;
    p_kn[0*MW +: MW]  <= sh_kn;
    p_lrn[0*MW +: MW] <= sh_kn & ~sh_wr;
    p_dt[0*DW +: DW]  <= sh_dt;
    for (k = 1; k < LAT; k = k + 1) begin
      p_kn[k*MW +: MW]  <= p_kn[(k-1)*MW +: MW];
      p_lrn[k*MW +: MW] <= p_lrn[(k-1)*MW +: MW];
      p_dt[k*DW +: DW]  <= p_dt[(k-1)*DW +: DW];
    end
  end

  // ---------------------------------------------------------------- checks
  wire        h_v    = e_v[0];
  wire        h_rd   = e_rd[0], h_err = e_err[0], h_we = e_we[0], h_tr = e_tr[0];
  wire [AGW-1:0] h_age = e_age[0 +: AGW];
  wire [IDW-1:0] h_id  = e_id[0 +: IDW];
  wire        h_fill = h_tr && (h_age == LAT) && pv_o;
  wire        rv     = rsp_valid && h_v;

  assign qcount       = cnt[3:0];
  assign ov           = push && (pos >= QD);
  assign ok_rsp_valid = (rsp_valid == (h_v && (h_age >= LAT)));
  assign ok_err       = !rv || (rsp_err == h_err);
  assign ok_we        = (CHECK_WE == 0) || !rv || (rsp_we == h_we);
  assign ok_id        = (CHECK_ID == 0) || !rv || (rsp_id == h_id);
  assign ok_zero      = !rv || !(h_err || !h_rd) || (rsp_rdata == {DW{1'b0}});

  reg [DW-1:0] hkn_bits, hdt_eff;
  reg [MW-1:0] hkn_eff;
  always @(*) begin
    hkn_eff = e_kn[0 +: MW];
    hdt_eff = e_dt[0 +: DW];
    if (h_fill) begin
      for (l = 0; l < MW; l = l + 1)
        if (!hkn_eff[l]) begin hdt_eff[l*LW +: LW] = raw_rdata[l*LW +: LW]; hkn_eff[l] = 1'b1; end
    end
    hkn_bits = {DW{1'b0}};
    for (l = 0; l < MW; l = l + 1)
      if (hkn_eff[l]) hkn_bits[l*LW +: LW] = {LW{1'b1}};
  end
  assign ok_data = !rv || !(h_rd && h_tr) || ((rsp_rdata & hkn_bits) == (hdt_eff & hkn_bits));

  // R4-style stability of the response channel
  reg           hold_q, herr_q, hwe_q;
  reg [DW-1:0]  hdt_q;
  reg [IDW-1:0] hid_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) hold_q <= 1'b0;
    else        hold_q <= rsp_valid && !rsp_ready;
  end
  always @(posedge clk) begin hdt_q <= rsp_rdata; herr_q <= rsp_err; hwe_q <= rsp_we; hid_q <= rsp_id; end
  assign ok_stable = !hold_q || (rsp_valid && rsp_rdata == hdt_q && rsp_err == herr_q &&
                                 (CHECK_WE == 0 || rsp_we == hwe_q) && (CHECK_ID == 0 || rsp_id == hid_q));

  // coverage flags
  assign cv_raw_checked  = pv_o && (pkn_o != {MW{1'b0}});
  assign cv_raw_partial  = pv_o && (pkn_o != {MW{1'b0}}) && (pkn_o != {MW{1'b1}});
  assign cv_raw_unwritten = pv_o && (plr_o != {MW{1'b0}});
  assign cv_partial_write = arr_wr && (arr_wmask != {MW{1'b0}}) && (arr_wmask != {MW{1'b1}});
  assign cv_backpressure = rsp_valid && !rsp_ready;
  assign cv_full         = (cnt == QD);
  assign cv_err_rsp      = rv && h_err;
  assign cv_data_checked = rv && h_rd && h_tr && (hkn_eff != {MW{1'b0}});
endmodule
`default_nettype wire
