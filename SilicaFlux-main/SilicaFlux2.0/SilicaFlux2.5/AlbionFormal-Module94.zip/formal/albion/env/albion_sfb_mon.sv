// =============================================================================
// AlbionFormal :: env/albion_sfb_mon.sv -- SFB2 protocol monitors (docs/datafabric/PROTOCOL.md rules R1..R8)
//
// These modules contain NO assertions.  They turn protocol rules into wires; the harness decides, per port, whether the
// rule is an ASSUMPTION (the port is driven by the environment) or an ASSERTION (the port is driven by the DUT):
//
//     albion_sfb_req_mon m_mon (...);                      // master-driven request channel
//     always @(*) `ALB_ASSUME(e_m_stable, "ENV-SFB-R2 ...", m_mon_stable_ok)       // DUT is the slave
//     always @(*) `ALB_ASSERT(7, a_m_stable, "[R2] ...",     m_mon_stable_ok)       // DUT is the master
//
// Keeping assertions in the harness top is what lets tools/albion_formal.py enumerate every property from the source.
// All history registers use the asynchronous-reset style of the RTL (see docs/HARNESS_GUIDE.md, convention C2).
// =============================================================================
`default_nettype none

// ---- request channel: R1 (transfer = valid && ready), R2 (valid + payload stable until accepted) -------------------
module albion_sfb_req_mon #(
  parameter AW = 32,
  parameter DW = 32
) (
  input  wire          clk,
  input  wire          rst_n,
  input  wire          valid,
  input  wire          ready,
  input  wire          write,
  input  wire [AW-1:0] addr,
  input  wire [DW-1:0] wdata,
  input  wire [DW/8-1:0] wstrb,
  output wire          stable_ok,   // R2: a request presented and not accepted is still presented, with an unchanged payload
  output wire          accepted,    // valid && ready
  output wire          held         // presented and not accepted in the previous cycle (no reset since)
);
  reg              held_q, write_q;
  reg [AW-1:0]     addr_q;
  reg [DW-1:0]     wdata_q;
  reg [DW/8-1:0]   wstrb_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) held_q <= 1'b0;
    else        held_q <= valid && !ready;
  end
  always @(posedge clk) begin           // payload shadow: only observed when held_q (never at reset)
    write_q <= write; addr_q <= addr; wdata_q <= wdata; wstrb_q <= wstrb;
  end
  assign held      = held_q;
  assign accepted  = valid && ready;
  assign stable_ok = !held_q || (valid && write == write_q && addr == addr_q && wstrb == wstrb_q &&
                                 (!write_q || wdata == wdata_q));
endmodule

// ---- response channel: R4 (held response stable), R5 (one response per request, never in the acceptance cycle),
//      R8 (error => rdata == 0), and the number of outstanding transactions ----------------------------------------
module albion_sfb_rsp_mon #(
  parameter DW = 32,
  parameter OW = 4                      // width of the outstanding counter
) (
  input  wire          clk,
  input  wire          rst_n,
  input  wire          req_acc,         // request accepted in this cycle (valid && ready of the request channel)
  input  wire          rsp_valid,
  input  wire          rsp_ready,
  input  wire [DW-1:0] rsp_rdata,
  input  wire          rsp_error,
  output wire          stable_ok,       // R4
  output wire          solicited_ok,    // R5: a response only while an EARLIER-accepted request is outstanding
  output wire          errdata_ok,      // R8: rsp_error => rsp_rdata == 0
  output wire [OW-1:0] outstanding,     // accepted-and-not-yet-answered transactions (registered: excludes this cycle's accept)
  output wire          rsp_hs           // response handshake this cycle
);
  reg            held_q, err_q;
  reg [DW-1:0]   rdata_q;
  reg [OW-1:0]   out_q;
  assign rsp_hs = rsp_valid && rsp_ready;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      held_q <= 1'b0;
      out_q  <= {OW{1'b0}};
    end else begin
      held_q <= rsp_valid && !rsp_ready;
      out_q  <= out_q + {{(OW-1){1'b0}}, req_acc} - {{(OW-1){1'b0}}, rsp_hs};
    end
  end
  always @(posedge clk) begin
    rdata_q <= rsp_rdata;
    err_q   <= rsp_error;
  end
  assign outstanding  = out_q;
  assign stable_ok    = !held_q || (rsp_valid && rsp_rdata == rdata_q && rsp_error == err_q);
  assign solicited_ok = !rsp_valid || (out_q != {OW{1'b0}});
  assign errdata_ok   = !rsp_error || !rsp_valid || (rsp_rdata == {DW{1'b0}});
endmodule

// ---- bounded response latency: an ENVIRONMENT ASSUMPTION used for bounded-progress safety proofs only ---------------
// lat_ok is 0 once a transaction has been outstanding for more than MAXLAT cycles without a response.  Using it as an
// assumption means "the slave answers within MAXLAT cycles" -- a timing/fairness premise that this suite never claims to
// have proved about any slave.  It is the only way bounded-completion properties are stated (no unbounded liveness).
module albion_sfb_lat_mon #(
  parameter MAXLAT = 4,
  parameter LW     = 5
) (
  input  wire clk,
  input  wire rst_n,
  input  wire pending,                  // a transaction is outstanding (registered outstanding != 0)
  input  wire rsp_valid,
  output wire lat_ok
);
  reg [LW-1:0] age_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n)                       age_q <= {LW{1'b0}};
    else if (!pending || rsp_valid)   age_q <= {LW{1'b0}};
    else if (age_q != {LW{1'b1}})     age_q <= age_q + 1'b1;
  end
  assign lat_ok = (age_q <= MAXLAT);
endmodule
`default_nettype wire
