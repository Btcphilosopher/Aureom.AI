// =============================================================================
// AlbionFormal :: env/albion_dma_ref.sv -- independent reference of the DMA descriptor-validation rules
//
// SPEC     docs/datafabric/DMA.md section 2 ("Rules and validation (before any bus access)"), the rule table:
//            1 ZERO_LENGTH  len == 0                         5 SRC_OVERFLOW  src + len > 2^32
//            2 LENGTH       len > 2^MAX_LEN_LOG2             6 DST_OVERFLOW  dst + len > 2^32
//            3 SRC_ALIGN    src not DW-aligned               7 OVERLAP       [src,src+len) and [dst,dst+len) intersect
//            4 DST_ALIGN    dst not DW-aligned               first failing rule wins
// INDEPENDENCE  all arithmetic is done on 40-bit TRUE INTEGERS (no 33-bit trick as in the RTL), overlap is stated as
//          "NOT (s_end <= dst OR d_end <= src)" (the RTL states it as src < d_end AND dst < s_end), the priority is a
//          lowest-code-wins override chain (the RTL is an if/else chain).  No assertions here: harnesses compare.
// =============================================================================
`default_nettype none
module albion_dma_ref_validate #(
  parameter DW = 32,
  parameter MAX_LEN_LOG2 = 24
) (
  input  wire [31:0] src,
  input  wire [31:0] dst,
  input  wire [31:0] len,
  output wire        legal,
  output reg  [3:0]  code,
  output wire        f_zero, f_long, f_salign, f_dalign, f_sovf, f_dovf, f_ovl
);
  localparam SB = DW / 8;
  wire [39:0] s = {8'b0, src}, d = {8'b0, dst}, l = {8'b0, len};
  wire [39:0] s_end = s + l;
  wire [39:0] d_end = d + l;
  assign f_zero   = (len == 32'd0);
  assign f_long   = (l > (40'd1 << MAX_LEN_LOG2));
  assign f_salign = (SB > 1) && ((src & (SB - 1)) != 0);
  assign f_dalign = (SB > 1) && ((dst & (SB - 1)) != 0);
  assign f_sovf   = (s_end > 40'h1_0000_0000);
  assign f_dovf   = (d_end > 40'h1_0000_0000);
  assign f_ovl    = !((s_end <= d) || (d_end <= s));
  assign legal    = !(f_zero || f_long || f_salign || f_dalign || f_sovf || f_dovf || f_ovl);
  always @(*) begin
    code = 4'd0;
    if (f_ovl)    code = 4'd7;
    if (f_dovf)   code = 4'd6;
    if (f_sovf)   code = 4'd5;
    if (f_dalign) code = 4'd4;
    if (f_salign) code = 4'd3;
    if (f_long)   code = 4'd2;
    if (f_zero)   code = 4'd1;
  end
endmodule
`default_nettype wire
