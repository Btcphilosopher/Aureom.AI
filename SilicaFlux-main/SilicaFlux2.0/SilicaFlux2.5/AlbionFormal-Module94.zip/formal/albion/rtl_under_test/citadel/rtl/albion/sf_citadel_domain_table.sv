// =============================================================================
//  sf_citadel_domain_table.sv  --  Citadel domain descriptors + privileged
//                                  configuration interpreter
// -----------------------------------------------------------------------------
//  Holds, for NDOM slots, the descriptor of one security domain:
//
//    * domain id (8 bit, sf_albion_pkg domain space), domain state
//      (INVALID / SUSPENDED / ACTIVE / QUARANTINED), capability bits
//      (may use the privileged / secure access attribute);
//    * NW memory windows {valid, base, limit (INCLUSIVE last byte), r, w, x,
//      exclusive};
//    * device read / write permission masks (NDEV bits each);
//    * queue permission mask (NQ bits);
//    * key-slot permission mask (NKEY bits)  -- used by the crypto adapter;
//
//  and, per physical source port, a BINDING mask: the set of slots whose domain
//  id that port is allowed to present.  A request that names a domain its port
//  is not bound to is a spoof and is denied (the domain label in a request is
//  initiator-supplied and is never trusted on its own).
//
//  After reset every slot is INVALID, every window invalid and every binding
//  empty: DEFAULT DENY.
//
//  PRIVILEGED CONFIGURATION.  All state changes go through ONE command port:
//    * accepted only while cfg_en_i is high (boot authorised / platform
//      enable; tie high when no secure boot is present -- the capability
//      register then reports "unauthenticated");
//    * the requester presents a domain label and a privilege bit; only ROOT
//      (0x00) and MGMT (0x01) with priv=1 are ever accepted.  The command port
//      is a PHYSICALLY dedicated management-plane port: that it is reachable
//      only from the secure monitor / ControlCore is an INTEGRATION
//      ASSUMPTION (docs/citadel/08_ASSUMPTIONS.md, A-CFG);
//    * ROOT may do everything.  MGMT may enrol / change / revoke TENANT
//      domains (ids 0x10..0xFE) only, may not grant the priv / secure
//      capabilities, may not bind ports, lock, clear the safe state, change
//      thresholds or clear counters, and may not release a QUARANTINED domain;
//    * LOCK freezes port bindings and every system-domain slot until reset;
//    * privilege is checked BEFORE the opcode is decoded, so an unprivileged
//      requester learns nothing about which opcodes exist;
//    * every command is answered, one cycle later, with an explicit status
//      (rsp_valid_o / rsp_status_o); a refused command changes no state.
//
//  ISOLATION BY CONSTRUCTION.  A window installed as EXCLUSIVE may not overlap
//  any window of any other (non-INVALID) domain, and no window may overlap an
//  existing exclusive window of another domain: SET_WINDOW is refused with
//  CS_OVERLAP.  Hence invariant INV-EXCL (proved: formal/citadel/fv_cit_table):
//    for distinct slots i != j and windows a of i, b of j (both valid),
//    excl(a) or excl(b)  =>  a and b are disjoint.
//
//  An EXCLUSIVE window may not touch any static device region (it would be inert there and could not
//  protect the device); such a SET_WINDOW is refused with CS_BAD_ARG.  Together with INV-EXCL this gives
//  the isolation theorem: no domain can reach any byte of another domain's exclusive window by any path.
//
//  Containment hook: qtn_valid_i / qtn_slot_i (from the fault manager) forces a
//  slot to QUARANTINED.  Entering QUARANTINED, and REVOKE, emit a key-zeroise
//  request (zero_valid_o / zero_mask_o = the slot's key mask).
//
//  Reset: asynchronous, active low.  Reset clears every register, in particular
//  every in-flight response / control pulse (priv-state-clear property).
// =============================================================================
`default_nettype none

module sf_citadel_domain_table #(
  parameter int unsigned NDOM = 8,    // domain slots (1..64)
  parameter int unsigned NW   = 4,    // windows per domain
  parameter int unsigned NP   = 4,    // physical source ports (binding masks)
  parameter int unsigned NDEV = 7,    // devices (1..64)
  parameter int unsigned NQ   = 16,   // queues (1..64)
  parameter int unsigned NKEY = 8,    // key slots (1..64)
  parameter int unsigned AW   = 64,   // address width (1..64); 64 in the product
  // static device map (same encoding as sf_citadel_permission): an EXCLUSIVE window may not touch a device region
  parameter logic [NDEV*AW-1:0] DEV_BASE = sf_citadel_pkg::SF_CIT_DEV_BASES_DEFAULT,
  parameter logic [NDEV*AW-1:0] DEV_MASK = sf_citadel_pkg::SF_CIT_DEV_MASKS_DEFAULT,
  localparam int unsigned SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1,
  localparam int unsigned WIN_W  = (NW   > 1) ? $clog2(NW)   : 1,
  localparam int unsigned PORT_W = (NP   > 1) ? $clog2(NP)   : 1
) (
  input  wire logic                     clk_i,
  input  wire logic                     rst_ni,

  // ---- privileged command port --------------------------------------------
  input  wire logic                     cfg_en_i,
  input  wire logic                     cmd_valid_i,
  input  wire logic [3:0]               cmd_op_i,
  input  wire logic [7:0]               cmd_dom_i,       // requester domain label
  input  wire logic                     cmd_priv_i,      // requester privilege attribute
  input  wire logic [SLOT_W-1:0]        cmd_slot_i,
  input  wire logic [WIN_W-1:0]         cmd_win_i,
  input  wire logic [PORT_W-1:0]        cmd_port_i,
  input  wire logic [7:0]               cmd_arg_dom_i,   // ENROLL: domain id to enrol
  input  wire logic [7:0]               cmd_flags_i,
  input  wire logic [63:0]              cmd_data0_i,
  input  wire logic [63:0]              cmd_data1_i,
  output logic                          rsp_valid_o,     // one pulse per command, 1 cycle later
  output logic [3:0]                    rsp_status_o,
  output logic                          cmd_deny_o,      // pulse: command refused for NOT_AUTH / BAD_PRIV / LOCKED

  // ---- control pulses produced by privileged commands (registered) --------
  output logic [NQ-1:0]                 ctl_clr_qhold_o,
  output logic [NP-1:0]                 ctl_clr_isol_o,
  output logic                          ctl_clr_safe_o,
  output logic                          ctl_clr_cnt_o,
  output logic                          ctl_thresh_we_o,
  output logic [15:0]                   ctl_thresh_o,

  // ---- containment hook (from the fault manager) ---------------------------
  input  wire logic                     qtn_valid_i,
  input  wire logic [SLOT_W-1:0]        qtn_slot_i,

  // ---- key zeroise request (crypto adapter) ---------------------------------
  output logic                          zero_valid_o,
  output logic [NKEY-1:0]               zero_mask_o,
  output logic [NDOM-1:0]               slot_clr_o,      // pulse: slot enrolled / revoked (clear per-slot telemetry)

  // ---- lookups (combinational) ----------------------------------------------
  input  wire logic [7:0]               look_dom_i,
  output logic                          look_found_o,
  output logic [SLOT_W-1:0]             look_slot_o,
  input  wire logic [AW-1:0]            own_addr_i,      // owner of the byte at own_addr_i = slot holding an EXCLUSIVE window containing it
  output logic                          own_found_o,
  output logic [SLOT_W-1:0]             own_slot_o,

  // ---- exported state (flat; consumed by sf_citadel_permission) -------------
  output logic [NDOM*2-1:0]             slot_state_o,
  output logic [NDOM*8-1:0]             slot_id_o,
  output logic [NDOM-1:0]               slot_priv_o,
  output logic [NDOM-1:0]               slot_secure_o,
  output logic [NDOM*NW-1:0]            win_valid_o,
  output logic [NDOM*NW*AW-1:0]         win_base_o,
  output logic [NDOM*NW*AW-1:0]         win_limit_o,
  output logic [NDOM*NW-1:0]            win_r_o,
  output logic [NDOM*NW-1:0]            win_w_o,
  output logic [NDOM*NW-1:0]            win_x_o,
  output logic [NDOM*NW-1:0]            win_excl_o,
  output logic [NDOM*NDEV-1:0]          devrd_o,
  output logic [NDOM*NDEV-1:0]          devwr_o,
  output logic [NDOM*NQ-1:0]            qmask_o,
  output logic [NDOM*NKEY-1:0]          kmask_o,
  output logic [NP*NDOM-1:0]            bind_o,
  output logic                          lock_o
);

  // ---------------------------------------------------------------------------
  // elaboration-time parameter checks
  // ---------------------------------------------------------------------------
  if (NDOM < 1 || NDOM > 64 || NW < 1 || NP < 1 || NDEV < 1 || NDEV > 64 ||
      NQ < 1 || NQ > 64 || NKEY < 1 || NKEY > 64 || AW < 1 || AW > 64 || NP > 64) begin : gen_param_check
    $error("sf_citadel_domain_table: parameter out of range");
  end

  // ---------------------------------------------------------------------------
  // state
  // ---------------------------------------------------------------------------
  logic [NDOM*2-1:0]     st_q;
  logic [NDOM*8-1:0]     id_q;
  logic [NDOM-1:0]       priv_q;
  logic [NDOM-1:0]       secure_q;
  logic [NDOM*NW-1:0]    wv_q, wr_q, ww_q, wx_q, wex_q;
  logic [NDOM*NW*AW-1:0] wbase_q, wlimit_q;
  logic [NDOM*NDEV-1:0]  devrd_q, devwr_q;
  logic [NDOM*NQ-1:0]    qmask_q;
  logic [NDOM*NKEY-1:0]  kmask_q;
  logic [NP*NDOM-1:0]    bind_q;
  logic                  lock_q;

  assign slot_state_o  = st_q;
  assign slot_id_o     = id_q;
  assign slot_priv_o   = priv_q;
  assign slot_secure_o = secure_q;
  assign win_valid_o   = wv_q;
  assign win_base_o    = wbase_q;
  assign win_limit_o   = wlimit_q;
  assign win_r_o       = wr_q;
  assign win_w_o       = ww_q;
  assign win_x_o       = wx_q;
  assign win_excl_o    = wex_q;
  assign devrd_o       = devrd_q;
  assign devwr_o       = devwr_q;
  assign qmask_o       = qmask_q;
  assign kmask_o       = kmask_q;
  assign bind_o        = bind_q;
  assign lock_o        = lock_q;

  // ---------------------------------------------------------------------------
  // lookups
  // ---------------------------------------------------------------------------
  always_comb begin
    look_found_o = 1'b0;
    look_slot_o  = '0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if (!look_found_o && (st_q[s*2 +: 2] != sf_citadel_pkg::SF_CIT_DS_INVALID) &&
          (id_q[s*8 +: 8] == look_dom_i)) begin
        look_found_o = 1'b1;
        look_slot_o  = SLOT_W'(s);
      end
    end
  end

  always_comb begin
    own_found_o = 1'b0;
    own_slot_o  = '0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      for (int unsigned k = 0; k < NW; k++) begin
        if (!own_found_o && wv_q[s*NW+k] && wex_q[s*NW+k] &&
            (own_addr_i >= wbase_q[(s*NW+k)*AW +: AW]) &&
            (own_addr_i <= wlimit_q[(s*NW+k)*AW +: AW])) begin
          own_found_o = 1'b1;
          own_slot_o  = SLOT_W'(s);
        end
      end
    end
  end

  // ---------------------------------------------------------------------------
  // command decode
  // ---------------------------------------------------------------------------
  wire        req_root = cmd_priv_i && (cmd_dom_i == sf_albion_pkg::SF_DOM_ROOT);
  wire        req_mgmt = cmd_priv_i && (cmd_dom_i == sf_albion_pkg::SF_DOM_MGMT);

  wire [31:0] slot_ext = {{(32-SLOT_W){1'b0}}, cmd_slot_i};
  wire [31:0] win_ext  = {{(32-WIN_W){1'b0}},  cmd_win_i};
  wire [31:0] port_ext = {{(32-PORT_W){1'b0}}, cmd_port_i};
  wire        slot_oob = (slot_ext >= NDOM);
  wire        win_oob  = (win_ext  >= NW);
  wire        port_oob = (port_ext >= NP);

  // an id is "system" below the first tenant id, "tenant" inside the tenant range
  function automatic logic id_is_tenant(input logic [7:0] d);
    id_is_tenant = (d >= sf_albion_pkg::SF_DOM_TENANT_FIRST) && (d <= sf_albion_pkg::SF_DOM_TENANT_LAST);
  endfunction

  // target slot attributes (valid only when !slot_oob)
  logic [1:0] tgt_st;
  logic [7:0] tgt_id;
  logic [NKEY-1:0] tgt_kmask;
  always_comb begin
    tgt_st    = sf_citadel_pkg::SF_CIT_DS_INVALID;
    tgt_id    = 8'h00;
    tgt_kmask = '0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if (slot_ext == s) begin
        tgt_st    = st_q[s*2 +: 2];
        tgt_id    = id_q[s*8 +: 8];
        tgt_kmask = kmask_q[s*NKEY +: NKEY];
      end
    end
  end
  wire tgt_enrolled = !slot_oob && (tgt_st != sf_citadel_pkg::SF_CIT_DS_INVALID);
  wire tgt_tenant   = id_is_tenant(tgt_id);
  wire tgt_system   = !tgt_tenant;           // ids 0x00..0x0F (0xFF can never be enrolled)

  // domain id already enrolled in some slot?
  logic dup_dom;
  always_comb begin
    dup_dom = 1'b0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if ((st_q[s*2 +: 2] != sf_citadel_pkg::SF_CIT_DS_INVALID) && (id_q[s*8 +: 8] == cmd_arg_dom_i)) dup_dom = 1'b1;
    end
  end

  // 64-bit argument views and range guards (no silent truncation when AW < 64)
  logic [AW-1:0] new_base, new_limit;
  logic          d0_fits, d1_fits;
  if (AW == 64) begin : gen_fit64
    assign new_base  = cmd_data0_i;
    assign new_limit = cmd_data1_i;
    assign d0_fits   = 1'b1;
    assign d1_fits   = 1'b1;
  end else begin : gen_fitn
    assign new_base  = cmd_data0_i[AW-1:0];
    assign new_limit = cmd_data1_i[AW-1:0];
    assign d0_fits   = (cmd_data0_i[63:AW] == '0);
    assign d1_fits   = (cmd_data1_i[63:AW] == '0);
  end

  // exclusive-window conflict of the proposed window (slot_ext, new_base..new_limit)
  wire new_excl = cmd_flags_i[sf_citadel_pkg::SF_CIT_WF_EXCL];
  logic conflict;
  always_comb begin
    conflict = 1'b0;
    for (int unsigned j = 0; j < NDOM; j++) begin
      for (int unsigned k = 0; k < NW; k++) begin
        if ((slot_ext != j) && wv_q[j*NW+k] && (new_excl || wex_q[j*NW+k]) &&
            (new_base  <= wlimit_q[(j*NW+k)*AW +: AW]) &&
            (wbase_q[(j*NW+k)*AW +: AW] <= new_limit)) begin
          conflict = 1'b1;
        end
      end
    end
  end

  // an EXCLUSIVE window must not touch any device region: devices are protected by device permissions, not by
  // windows, so such a window could not deliver the protection it claims
  logic excl_dev_conflict;
  always_comb begin
    excl_dev_conflict = 1'b0;
    for (int unsigned i = 0; i < NDEV; i++) begin
      if ((DEV_MASK[i*AW +: AW] != '0) &&
          (new_base <= (DEV_BASE[i*AW +: AW] | ~DEV_MASK[i*AW +: AW])) &&
          (DEV_BASE[i*AW +: AW] <= new_limit)) begin
        excl_dev_conflict = 1'b1;
      end
    end
  end

  // mask range guards
  wire devmask_ok = (NDEV == 64) ? 1'b1 : ((cmd_data0_i >> NDEV) == 64'd0) && ((cmd_data1_i >> NDEV) == 64'd0);
  wire qmask_ok   = (NQ   == 64) ? 1'b1 : ((cmd_data0_i >> NQ)   == 64'd0);
  wire kmask_ok   = (NKEY == 64) ? 1'b1 : ((cmd_data0_i >> NKEY) == 64'd0);
  wire bmask_ok   = (NDOM == 64) ? 1'b1 : ((cmd_data0_i >> NDOM) == 64'd0);
  wire imask_ok   = (NP   >= 64) ? 1'b1 : ((cmd_data0_i >> NP)   == 64'd0);

  wire [1:0] new_state = cmd_flags_i[1:0];

  logic [3:0]            st_d;           // status of the command in this cycle
  logic                  cmd_ok;
  logic [NDOM-1:0]       we_enroll, we_revoke, we_state, we_devprm, we_qprm, we_kprm;
  logic [NDOM*NW-1:0]    we_win, we_clrwin;
  logic                  we_bind, we_lock;

  always_comb begin
    st_d = sf_citadel_pkg::SF_CIT_CS_OK;
    if (!cfg_en_i) begin
      st_d = sf_citadel_pkg::SF_CIT_CS_NOT_AUTH;
    end else if (!(req_root || req_mgmt)) begin
      st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
    end else if (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_INVALID) begin
      st_d = sf_citadel_pkg::SF_CIT_CS_BAD_CMD;
    end else begin
      case (cmd_op_i)
        sf_citadel_pkg::SF_CIT_OP_ENROLL: begin
          if (slot_oob) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_SLOT;
          end else if (!req_root && !(id_is_tenant(cmd_arg_dom_i) && !cmd_flags_i[sf_citadel_pkg::SF_CIT_EF_PRIV] &&
                                      !cmd_flags_i[sf_citadel_pkg::SF_CIT_EF_SECURE])) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (cmd_arg_dom_i == sf_albion_pkg::SF_DOM_INVALID || cmd_flags_i[7:2] != 6'd0) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
          end else if (lock_q && !id_is_tenant(cmd_arg_dom_i)) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;
          end else if (tgt_st != sf_citadel_pkg::SF_CIT_DS_INVALID || dup_dom) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_EXISTS;
          end
        end
        sf_citadel_pkg::SF_CIT_OP_SET_WINDOW: begin
          if (!tgt_enrolled) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_SLOT;
          end else if (!req_root && !tgt_tenant) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (lock_q && tgt_system) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;
          end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_STATE;
          end else if (win_oob || cmd_flags_i[7:4] != 4'd0 || !d0_fits || !d1_fits || (new_base > new_limit) ||
                     (new_excl && excl_dev_conflict)) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
          end else if (conflict) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_OVERLAP;
          end
        end
        sf_citadel_pkg::SF_CIT_OP_CLR_WINDOW: begin
          if (!tgt_enrolled) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_SLOT;
          end else if (!req_root && !tgt_tenant) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (lock_q && tgt_system) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;
          end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_STATE;
          end else if (win_oob) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
          end
        end
        sf_citadel_pkg::SF_CIT_OP_SET_DEVPRM,
        sf_citadel_pkg::SF_CIT_OP_SET_QPRM,
        sf_citadel_pkg::SF_CIT_OP_SET_KEYPRM: begin
          if (!tgt_enrolled) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_SLOT;
          end else if (!req_root && !tgt_tenant) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (lock_q && tgt_system) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;
          end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_STATE;
          end else if ((cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_DEVPRM && !devmask_ok) ||
                       (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_QPRM   && !qmask_ok)   ||
                       (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_KEYPRM && !kmask_ok)) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
          end
        end
        sf_citadel_pkg::SF_CIT_OP_SET_STATE: begin
          if (!tgt_enrolled) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_SLOT;
          end else if (!req_root && !tgt_tenant) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (lock_q && tgt_system) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;
          end else if (new_state == sf_citadel_pkg::SF_CIT_DS_INVALID || cmd_flags_i[7:2] != 6'd0) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
          end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED &&
                       new_state != sf_citadel_pkg::SF_CIT_DS_QUARANTINED && !req_root) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;     // only ROOT releases a quarantine
          end
        end
        sf_citadel_pkg::SF_CIT_OP_REVOKE: begin
          if (!tgt_enrolled) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_SLOT;
          end else if (!req_root && !tgt_tenant) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (lock_q && tgt_system) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;
          end else if (tgt_st == sf_citadel_pkg::SF_CIT_DS_QUARANTINED && !req_root) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;     // REVOKE + re-ENROLL would release a quarantine: ROOT only
          end
        end
        sf_citadel_pkg::SF_CIT_OP_BIND_PORT: begin
          if (!req_root) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (lock_q) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_LOCKED;
          end else if (port_oob) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_SLOT;
          end else if (!bmask_ok) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
          end
        end
        sf_citadel_pkg::SF_CIT_OP_LOCK,
        sf_citadel_pkg::SF_CIT_OP_CLR_SAFE,
        sf_citadel_pkg::SF_CIT_OP_CLR_CNT: begin
          if (!req_root) st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
        end
        sf_citadel_pkg::SF_CIT_OP_CLR_QHOLD: begin
          if (!qmask_ok) st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
        end
        sf_citadel_pkg::SF_CIT_OP_CLR_ISOL: begin
          if (!imask_ok) st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
        end
        sf_citadel_pkg::SF_CIT_OP_SET_THRESH: begin
          if (!req_root) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_PRIV;
          end else if (cmd_data0_i[63:16] != 48'd0) begin
            st_d = sf_citadel_pkg::SF_CIT_CS_BAD_ARG;
          end
        end
        default: begin
          st_d = sf_citadel_pkg::SF_CIT_CS_BAD_CMD;   // unreachable: every non-zero opcode is decoded above
        end
      endcase
    end
  end

  assign cmd_ok = cmd_valid_i && (st_d == sf_citadel_pkg::SF_CIT_CS_OK);

  always_comb begin
    we_enroll = '0; we_revoke = '0; we_state = '0;
    we_devprm = '0; we_qprm = '0; we_kprm = '0;
    we_win = '0; we_clrwin = '0;
    we_bind = 1'b0; we_lock = 1'b0;
    if (cmd_ok) begin
      for (int unsigned s = 0; s < NDOM; s++) begin
        if (slot_ext == s) begin
          we_enroll[s] = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_ENROLL);
          we_revoke[s] = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_REVOKE);
          we_state[s]  = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_STATE);
          we_devprm[s] = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_DEVPRM);
          we_qprm[s]   = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_QPRM);
          we_kprm[s]   = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_KEYPRM);
          for (int unsigned k = 0; k < NW; k++) begin
            if (win_ext == k) begin
              we_win[s*NW+k]    = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_WINDOW);
              we_clrwin[s*NW+k] = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_CLR_WINDOW);
            end
          end
        end
      end
      we_bind = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_BIND_PORT);
      we_lock = (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_LOCK);
    end
  end

  // ---- containment (internal, hard-wired privileged agent) -------------------
  wire [31:0] qtn_ext = {{(32-SLOT_W){1'b0}}, qtn_slot_i};
  logic [NDOM-1:0] qtn_we;
  logic [NKEY-1:0] qtn_kmask;
  always_comb begin
    qtn_we    = '0;
    qtn_kmask = '0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      // a revoke of the same slot in the same cycle wins (the slot is gone)
      if (qtn_valid_i && (qtn_ext == s) && (st_q[s*2 +: 2] != sf_citadel_pkg::SF_CIT_DS_INVALID) && !we_revoke[s]) begin
        qtn_we[s] = 1'b1;
        // zeroise the key mask the slot will HOLD after this cycle: a SET_KEYPRM landing in the same cycle must
        // not leave a freshly granted key slot un-zeroised on a quarantined domain
        if (st_q[s*2 +: 2] != sf_citadel_pkg::SF_CIT_DS_QUARANTINED) begin
          qtn_kmask = we_kprm[s] ? cmd_data0_i[NKEY-1:0] : kmask_q[s*NKEY +: NKEY];
        end
      end
    end
  end

  // key-zeroise request: REVOKE, entering QUARANTINED by command, or by containment
  logic [NKEY-1:0] zero_cmd_mask;
  always_comb begin
    zero_cmd_mask = '0;
    if (cmd_ok && (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_REVOKE)) begin
      zero_cmd_mask = tgt_kmask;
    end
    if (cmd_ok && (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_STATE) &&
        (new_state == sf_citadel_pkg::SF_CIT_DS_QUARANTINED) && (tgt_st != sf_citadel_pkg::SF_CIT_DS_QUARANTINED)) begin
      zero_cmd_mask = tgt_kmask;
    end
    // a key slot REMOVED from a domain by SET_KEYPRM is zeroised, so it can be granted to another domain without
    // handing over the previous owner's key
    if (cmd_ok && (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_KEYPRM)) begin
      zero_cmd_mask = zero_cmd_mask | (tgt_kmask & ~cmd_data0_i[NKEY-1:0]);
    end
  end

  // ---------------------------------------------------------------------------
  // registers: global
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      rsp_valid_o     <= 1'b0;
      rsp_status_o    <= sf_citadel_pkg::SF_CIT_CS_OK;
      cmd_deny_o      <= 1'b0;
      ctl_clr_qhold_o <= '0;
      ctl_clr_isol_o  <= '0;
      ctl_clr_safe_o  <= 1'b0;
      ctl_clr_cnt_o   <= 1'b0;
      ctl_thresh_we_o <= 1'b0;
      ctl_thresh_o    <= 16'd0;
      zero_valid_o    <= 1'b0;
      zero_mask_o     <= '0;
      slot_clr_o      <= '0;
      lock_q          <= 1'b0;
    end else begin
      rsp_valid_o     <= cmd_valid_i;
      rsp_status_o    <= cmd_valid_i ? st_d : sf_citadel_pkg::SF_CIT_CS_OK;
      cmd_deny_o      <= cmd_valid_i && ((st_d == sf_citadel_pkg::SF_CIT_CS_NOT_AUTH) ||
                                         (st_d == sf_citadel_pkg::SF_CIT_CS_BAD_PRIV) ||
                                         (st_d == sf_citadel_pkg::SF_CIT_CS_LOCKED));
      ctl_clr_qhold_o <= (cmd_ok && cmd_op_i == sf_citadel_pkg::SF_CIT_OP_CLR_QHOLD) ? cmd_data0_i[NQ-1:0] : '0;
      ctl_clr_isol_o  <= (cmd_ok && cmd_op_i == sf_citadel_pkg::SF_CIT_OP_CLR_ISOL)  ? cmd_data0_i[NP-1:0] : '0;
      ctl_clr_safe_o  <= cmd_ok && (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_CLR_SAFE);
      ctl_clr_cnt_o   <= cmd_ok && (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_CLR_CNT);
      ctl_thresh_we_o <= cmd_ok && (cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_THRESH);
      if (cmd_ok && cmd_op_i == sf_citadel_pkg::SF_CIT_OP_SET_THRESH) ctl_thresh_o <= cmd_data0_i[15:0];
      zero_valid_o    <= |(zero_cmd_mask | qtn_kmask);          // nothing to zeroise -> no request
      zero_mask_o     <= zero_cmd_mask | qtn_kmask;
      slot_clr_o      <= we_enroll | we_revoke;
      if (we_lock) lock_q <= 1'b1;
    end
  end

  // ---------------------------------------------------------------------------
  // registers: bindings
  // ---------------------------------------------------------------------------
  for (genvar p = 0; p < NP; p++) begin : gen_bind
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        bind_q[p*NDOM +: NDOM] <= '0;
      end else if (we_bind && (port_ext == p)) begin
        bind_q[p*NDOM +: NDOM] <= cmd_data0_i[NDOM-1:0];
      end
    end
  end

  // ---------------------------------------------------------------------------
  // registers: slots and windows
  // ---------------------------------------------------------------------------
  for (genvar s = 0; s < NDOM; s++) begin : gen_slot
    always_ff @(posedge clk_i or negedge rst_ni) begin
      if (!rst_ni) begin
        st_q[s*2 +: 2]        <= sf_citadel_pkg::SF_CIT_DS_INVALID;
        id_q[s*8 +: 8]        <= 8'h00;
        priv_q[s]             <= 1'b0;
        secure_q[s]           <= 1'b0;
        devrd_q[s*NDEV +: NDEV] <= '0;
        devwr_q[s*NDEV +: NDEV] <= '0;
        qmask_q[s*NQ +: NQ]   <= '0;
        kmask_q[s*NKEY +: NKEY] <= '0;
      end else if (we_revoke[s]) begin
        st_q[s*2 +: 2]        <= sf_citadel_pkg::SF_CIT_DS_INVALID;
        id_q[s*8 +: 8]        <= 8'h00;
        priv_q[s]             <= 1'b0;
        secure_q[s]           <= 1'b0;
        devrd_q[s*NDEV +: NDEV] <= '0;
        devwr_q[s*NDEV +: NDEV] <= '0;
        qmask_q[s*NQ +: NQ]   <= '0;
        kmask_q[s*NKEY +: NKEY] <= '0;
      end else begin
        if (we_enroll[s]) begin
          st_q[s*2 +: 2]      <= sf_citadel_pkg::SF_CIT_DS_SUSPENDED;     // enrolled, but no access until activated
          id_q[s*8 +: 8]      <= cmd_arg_dom_i;
          priv_q[s]           <= cmd_flags_i[sf_citadel_pkg::SF_CIT_EF_PRIV];
          secure_q[s]         <= cmd_flags_i[sf_citadel_pkg::SF_CIT_EF_SECURE];
        end
        if (we_state[s])  st_q[s*2 +: 2] <= new_state;
        if (qtn_we[s])    st_q[s*2 +: 2] <= sf_citadel_pkg::SF_CIT_DS_QUARANTINED;   // containment wins over SET_STATE
        if (we_devprm[s]) begin
          devrd_q[s*NDEV +: NDEV] <= cmd_data0_i[NDEV-1:0];
          devwr_q[s*NDEV +: NDEV] <= cmd_data1_i[NDEV-1:0];
        end
        if (we_qprm[s])   qmask_q[s*NQ +: NQ]     <= cmd_data0_i[NQ-1:0];
        if (we_kprm[s])   kmask_q[s*NKEY +: NKEY] <= cmd_data0_i[NKEY-1:0];
      end
    end

    for (genvar k = 0; k < NW; k++) begin : gen_win
      always_ff @(posedge clk_i or negedge rst_ni) begin
        if (!rst_ni) begin
          wv_q[s*NW+k]                  <= 1'b0;
          wr_q[s*NW+k]                  <= 1'b0;
          ww_q[s*NW+k]                  <= 1'b0;
          wx_q[s*NW+k]                  <= 1'b0;
          wex_q[s*NW+k]                 <= 1'b0;
          wbase_q[(s*NW+k)*AW +: AW]    <= '0;
          wlimit_q[(s*NW+k)*AW +: AW]   <= '0;
        end else if (we_revoke[s] || we_clrwin[s*NW+k]) begin
          wv_q[s*NW+k]                  <= 1'b0;
          wr_q[s*NW+k]                  <= 1'b0;
          ww_q[s*NW+k]                  <= 1'b0;
          wx_q[s*NW+k]                  <= 1'b0;
          wex_q[s*NW+k]                 <= 1'b0;
          wbase_q[(s*NW+k)*AW +: AW]    <= '0;
          wlimit_q[(s*NW+k)*AW +: AW]   <= '0;
        end else if (we_win[s*NW+k]) begin
          wv_q[s*NW+k]                  <= 1'b1;
          wr_q[s*NW+k]                  <= cmd_flags_i[sf_citadel_pkg::SF_CIT_WF_R];
          ww_q[s*NW+k]                  <= cmd_flags_i[sf_citadel_pkg::SF_CIT_WF_W];
          wx_q[s*NW+k]                  <= cmd_flags_i[sf_citadel_pkg::SF_CIT_WF_X];
          wex_q[s*NW+k]                 <= cmd_flags_i[sf_citadel_pkg::SF_CIT_WF_EXCL];
          wbase_q[(s*NW+k)*AW +: AW]    <= new_base;
          wlimit_q[(s*NW+k)*AW +: AW]   <= new_limit;
        end
      end
    end
  end

endmodule

`default_nettype wire
