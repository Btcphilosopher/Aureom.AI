// =============================================================================
//  sf_citadel_permission.sv  --  Citadel hardware permission checker
// -----------------------------------------------------------------------------
//  PURELY COMBINATIONAL decision for ONE request: permit or deny, with an
//  explicit reason, using the descriptor state exported by
//  sf_citadel_domain_table.  No state, no side effects: the verdict is a pure
//  function of (request, table, safety levels), so the same inputs always give
//  the same verdict (checked by formal equivalence to an independent reference).
//
//  Request fields (what the master asks for)
//    src_i   PHYSICAL source port.  Driven by the integration (generate index),
//            never by the master: it is the anchor of the domain binding.
//    dom_i   claimed domain id.        op_i    SF_OP_READ / SF_OP_WRITE (ALP codes)
//    attr_i  ALP attribute byte.       addr_i  first byte,  len_i  bytes (>= 1)
//    cls_i   ADDR (byte range) or QUEUE (queue number idx_i)
//
//  Decision order -- the FIRST failing check decides the reason (SF_CIT_R_*):
//     1  source port isolated                         -> ISOLATED
//     2  DFT / test access active                     -> LOCKDOWN   (nobody exempt)
//     3  class not ADDR / QUEUE                       -> BAD_ATTR
//     4  op not READ / WRITE                          -> BAD_OP
//     5  attr reserved bit, memtype 3, or instr+WRITE -> BAD_ATTR
//     6  dom == SF_DOM_INVALID                        -> BAD_DOM
//     7  domain unknown, or NOT BOUND to src_i        -> BAD_DOM   (spoof)
//     8  safe state and dom is not ROOT/MGMT          -> LOCKDOWN
//     9  domain state != ACTIVE                       -> DOM_STATE
//    10  priv / secure claim above the domain's caps  -> PRIV
//    QUEUE:  11 idx >= NQ, on abort-hold, or not in the domain's queue mask -> QUEUE
//    ADDR:   11 len == 0                              -> BAD_LEN
//            12 addr + len - 1 wraps the address space -> OVERFLOW
//            13 range touches a device region:
//                 not wholly inside ONE device        -> NOMAP   (boundary-spanning)
//                 device priv-/secure-only unmet      -> PRIV
//                 instruction fetch from a device     -> PERM
//                 no device read / write permission   -> DEV
//               else the range is memory:
//                 no single window contains it        -> NOMAP   (boundary-spanning)
//                 containing window lacks r / w / x   -> PERM
//  A range that spans two adjacent windows is DENIED even if both grant access:
//  software splits transfers per window (documented policy, not a limitation of
//  the arithmetic).  Devices are never reachable through a memory window.
//
//  The requester only sees status_o: OKAY, BAD_OPCODE, BAD_ATTR or the coarse
//  ACCESS_DENIED.  Unmapped, unauthorised, other-tenant and overflowing
//  addresses are indistinguishable to it (no layout oracle); the fine reason_o
//  is for privileged audit only.
//
//  Verified (formal/citadel):  equivalence with an independent reference,
//  declarative safety properties (permit => range inside an owned window with
//  the needed right, no wrap, domain ACTIVE and bound, device rules ...),
//  cross-domain isolation (with the table) and "every denial is explicit".
// =============================================================================
`default_nettype none

module sf_citadel_permission #(
  parameter int unsigned NDOM  = 8,
  parameter int unsigned NW    = 4,
  parameter int unsigned NP    = 4,
  parameter int unsigned NDEV  = 7,
  parameter int unsigned NQ    = 16,
  parameter int unsigned AW    = 64,
  parameter int unsigned LEN_W = 32,
  parameter logic [NDEV*AW-1:0] DEV_BASE   = sf_citadel_pkg::SF_CIT_DEV_BASES_DEFAULT,
  parameter logic [NDEV*AW-1:0] DEV_MASK   = sf_citadel_pkg::SF_CIT_DEV_MASKS_DEFAULT,
  parameter logic [NDEV-1:0]    DEV_PRIV   = sf_citadel_pkg::SF_CIT_DEV_PRIV_DEFAULT,
  parameter logic [NDEV-1:0]    DEV_SECURE = sf_citadel_pkg::SF_CIT_DEV_SECURE_DEFAULT,
  localparam int unsigned SRC_W  = (NP   > 1) ? $clog2(NP)   : 1,
  localparam int unsigned SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1
) (
  // ---- request ---------------------------------------------------------------
  input  wire logic [SRC_W-1:0]        src_i,
  input  wire logic [7:0]              dom_i,
  input  wire logic [3:0]              op_i,
  input  wire logic [7:0]              attr_i,
  input  wire logic [AW-1:0]           addr_i,
  input  wire logic [LEN_W-1:0]        len_i,
  input  wire logic [1:0]              cls_i,
  input  wire logic [7:0]              idx_i,
  // ---- device-wide safety levels ---------------------------------------------
  input  wire logic                    lockdown_i,
  input  wire logic                    dft_active_i,
  input  wire logic [NQ-1:0]           qhold_i,
  input  wire logic [NP-1:0]           port_isol_i,
  // ---- descriptor state (from sf_citadel_domain_table) -------------------------
  input  wire logic [NDOM*2-1:0]       slot_state_i,
  input  wire logic [NDOM*8-1:0]       slot_id_i,
  input  wire logic [NDOM-1:0]         slot_priv_i,
  input  wire logic [NDOM-1:0]         slot_secure_i,
  input  wire logic [NDOM*NW-1:0]      win_valid_i,
  input  wire logic [NDOM*NW*AW-1:0]   win_base_i,
  input  wire logic [NDOM*NW*AW-1:0]   win_limit_i,
  input  wire logic [NDOM*NW-1:0]      win_r_i,
  input  wire logic [NDOM*NW-1:0]      win_w_i,
  input  wire logic [NDOM*NW-1:0]      win_x_i,
  input  wire logic [NDOM*NDEV-1:0]    devrd_i,
  input  wire logic [NDOM*NDEV-1:0]    devwr_i,
  input  wire logic [NDOM*NQ-1:0]      qmask_i,
  input  wire logic [NP*NDOM-1:0]      bind_i,
  // ---- verdict -------------------------------------------------------------------
  output logic                         permit_o,
  output logic [3:0]                   reason_o,
  output logic [3:0]                   status_o,
  output logic                         slot_vld_o,     // domain verified: known AND bound to src_i (safe to attribute)
  output logic [SLOT_W-1:0]            slot_o
);

  if (NDOM < 1 || NW < 1 || NP < 1 || NDEV < 1 || NQ < 1 || AW < 1 || AW > 64 || LEN_W < 1 || LEN_W > 64) begin : gen_param_check
    $error("sf_citadel_permission: parameter out of range");
  end

  localparam int unsigned SW = ((AW > LEN_W) ? AW : LEN_W) + 1;   // sum width: cannot lose a carry

  wire [31:0] src_ext = {{(32-SRC_W){1'b0}}, src_i};
  wire [31:0] idx_ext = {24'd0, idx_i};

  // ---- 1. port isolation -------------------------------------------------------
  logic port_isol;
  always_comb begin
    port_isol = 1'b0;
    for (int unsigned p = 0; p < NP; p++) begin
      if (src_ext == p) port_isol = port_isol_i[p];
    end
  end

  // ---- request-form checks -----------------------------------------------------
  wire cls_bad  = (cls_i != sf_citadel_pkg::SF_CIT_CLS_ADDR) && (cls_i != sf_citadel_pkg::SF_CIT_CLS_QUEUE);
  wire op_rd    = (op_i == sf_albion_pkg::SF_OP_READ);
  wire op_wr    = (op_i == sf_albion_pkg::SF_OP_WRITE);
  wire op_bad   = !(op_rd || op_wr);
  wire a_instr  = attr_i[sf_albion_pkg::SF_ATTR_INSTR_BIT];
  wire a_secure = attr_i[sf_albion_pkg::SF_ATTR_SECURE_BIT];
  wire a_priv   = attr_i[sf_albion_pkg::SF_ATTR_PRIV_BIT];
  wire attr_bad = attr_i[sf_albion_pkg::SF_ATTR_RSVD_BIT] ||
                  (attr_i[sf_albion_pkg::SF_ATTR_MEMTYPE_LSB +: 2] == 2'd3) ||
                  (a_instr && op_wr);

  // ---- domain lookup and binding -----------------------------------------------
  logic              dom_found, dom_bound;
  logic [SLOT_W-1:0] dom_slot;
  logic [1:0]        dom_state;
  logic              dom_priv_cap, dom_secure_cap;
  always_comb begin
    dom_found      = 1'b0;
    dom_bound      = 1'b0;
    dom_slot       = '0;
    dom_state      = sf_citadel_pkg::SF_CIT_DS_INVALID;
    dom_priv_cap   = 1'b0;
    dom_secure_cap = 1'b0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if (!dom_found && (slot_state_i[s*2 +: 2] != sf_citadel_pkg::SF_CIT_DS_INVALID) &&
          (slot_id_i[s*8 +: 8] == dom_i)) begin
        dom_found      = 1'b1;
        dom_slot       = SLOT_W'(s);
        dom_state      = slot_state_i[s*2 +: 2];
        dom_priv_cap   = slot_priv_i[s];
        dom_secure_cap = slot_secure_i[s];
        for (int unsigned p = 0; p < NP; p++) begin
          if (src_ext == p) dom_bound = bind_i[p*NDOM + s];
        end
      end
    end
  end
  wire dom_ok = dom_found && dom_bound && (dom_i != sf_albion_pkg::SF_DOM_INVALID);

  // ---- queue class ---------------------------------------------------------------
  logic queue_ok;
  always_comb begin
    queue_ok = 1'b0;
    for (int unsigned q = 0; q < NQ; q++) begin
      if ((idx_ext == q) && !qhold_i[q]) begin
        for (int unsigned s = 0; s < NDOM; s++) begin
          if (dom_slot == SLOT_W'(s)) queue_ok = qmask_i[s*NQ + q];
        end
      end
    end
  end

  // ---- range arithmetic -----------------------------------------------------------
  wire              len_zero = (len_i == '0);
  wire [LEN_W-1:0]  len_m1   = len_i - 1'b1;
  wire [SW-1:0]     sum      = {{(SW-AW){1'b0}}, addr_i} + {{(SW-LEN_W){1'b0}}, len_m1};
  wire              ovf      = len_zero ? 1'b0 : (sum[SW-1:AW] != '0);
  wire [AW-1:0]     last     = sum[AW-1:0];

  // ---- device regions ----------------------------------------------------------------
  logic [NDEV-1:0] dev_ov, dev_in;
  always_comb begin
    for (int unsigned i = 0; i < NDEV; i++) begin
      dev_ov[i] = 1'b0;
      dev_in[i] = 1'b0;
      if (DEV_MASK[i*AW +: AW] != '0) begin
        // region = {a : (a & MASK) == BASE}  =  [BASE, BASE | ~MASK]
        dev_ov[i] = (addr_i <= (DEV_BASE[i*AW +: AW] | ~DEV_MASK[i*AW +: AW])) &&
                    (last   >= DEV_BASE[i*AW +: AW]);
        dev_in[i] = (addr_i >= DEV_BASE[i*AW +: AW]) &&
                    (last   <= (DEV_BASE[i*AW +: AW] | ~DEV_MASK[i*AW +: AW]));
      end
    end
  end
  wire dev_any   = (dev_ov != '0);
  wire dev_multi = (dev_ov != '0) && ((dev_ov & (dev_ov - 1'b1)) != '0);   // more than one region touched
  wire dev_whole = (dev_ov & dev_in) != '0;                                // the one touched region contains it

  logic dev_rd_ok, dev_wr_ok, dev_need_priv, dev_need_secure;
  always_comb begin
    dev_rd_ok       = 1'b0;
    dev_wr_ok       = 1'b0;
    dev_need_priv   = 1'b0;
    dev_need_secure = 1'b0;
    for (int unsigned i = 0; i < NDEV; i++) begin
      if (dev_ov[i]) begin
        dev_need_priv   = DEV_PRIV[i];
        dev_need_secure = DEV_SECURE[i];
        for (int unsigned s = 0; s < NDOM; s++) begin
          if (dom_slot == SLOT_W'(s)) begin
            dev_rd_ok = devrd_i[s*NDEV + i];
            dev_wr_ok = devwr_i[s*NDEV + i];
          end
        end
      end
    end
  end

  // ---- memory windows ------------------------------------------------------------------
  logic win_contain, win_allow;
  always_comb begin
    win_contain = 1'b0;
    win_allow   = 1'b0;
    for (int unsigned s = 0; s < NDOM; s++) begin
      if (dom_slot == SLOT_W'(s)) begin
        for (int unsigned k = 0; k < NW; k++) begin
          if (win_valid_i[s*NW+k] &&
              (addr_i >= win_base_i[(s*NW+k)*AW +: AW]) &&
              (last   <= win_limit_i[(s*NW+k)*AW +: AW])) begin
            win_contain = 1'b1;
            if ((op_rd ? win_r_i[s*NW+k] : win_w_i[s*NW+k]) && (!a_instr || win_x_i[s*NW+k])) win_allow = 1'b1;
          end
        end
      end
    end
  end

  // ---- the ordered decision --------------------------------------------------------------
  always_comb begin
    reason_o = sf_citadel_pkg::SF_CIT_R_OK;
    if (port_isol) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_ISOLATED;
    end else if (dft_active_i) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_LOCKDOWN;
    end else if (cls_bad) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_BAD_ATTR;
    end else if (op_bad) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_BAD_OP;
    end else if (attr_bad) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_BAD_ATTR;
    end else if (!dom_ok) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_BAD_DOM;
    end else if (lockdown_i && (dom_i != sf_albion_pkg::SF_DOM_ROOT) && (dom_i != sf_albion_pkg::SF_DOM_MGMT)) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_LOCKDOWN;
    end else if (dom_state != sf_citadel_pkg::SF_CIT_DS_ACTIVE) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_DOM_STATE;
    end else if ((a_priv && !dom_priv_cap) || (a_secure && !dom_secure_cap)) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_PRIV;
    end else if (cls_i == sf_citadel_pkg::SF_CIT_CLS_QUEUE) begin
      if (!queue_ok) reason_o = sf_citadel_pkg::SF_CIT_R_QUEUE;
    end else if (len_zero) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_BAD_LEN;
    end else if (ovf) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_OVERFLOW;
    end else if (dev_any) begin
      if (dev_multi || !dev_whole) begin
        reason_o = sf_citadel_pkg::SF_CIT_R_NOMAP;
      end else if ((dev_need_priv && !a_priv) || (dev_need_secure && !a_secure)) begin
        reason_o = sf_citadel_pkg::SF_CIT_R_PRIV;
      end else if (a_instr) begin
        reason_o = sf_citadel_pkg::SF_CIT_R_PERM;
      end else if (!(op_rd ? dev_rd_ok : dev_wr_ok)) begin
        reason_o = sf_citadel_pkg::SF_CIT_R_DEV;
      end
    end else if (!win_contain) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_NOMAP;
    end else if (!win_allow) begin
      reason_o = sf_citadel_pkg::SF_CIT_R_PERM;
    end
  end

  assign permit_o   = (reason_o == sf_citadel_pkg::SF_CIT_R_OK);
  assign slot_vld_o = dom_ok;
  assign slot_o     = dom_slot;

  // coarse, requester-visible status (ALP status codes)
  always_comb begin
    if (reason_o == sf_citadel_pkg::SF_CIT_R_OK)            status_o = sf_albion_pkg::SF_ST_OKAY;
    else if (reason_o == sf_citadel_pkg::SF_CIT_R_BAD_OP)   status_o = sf_albion_pkg::SF_ST_BAD_OPCODE;
    else if (reason_o == sf_citadel_pkg::SF_CIT_R_BAD_ATTR) status_o = sf_albion_pkg::SF_ST_BAD_ATTR;
    else                                                    status_o = sf_albion_pkg::SF_ST_ACCESS_DENIED;
  end

endmodule

`default_nettype wire
