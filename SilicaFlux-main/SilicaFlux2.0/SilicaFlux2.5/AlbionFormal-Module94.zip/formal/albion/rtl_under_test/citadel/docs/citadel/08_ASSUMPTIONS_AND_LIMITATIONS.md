# 08 — Assumptions, limitations and what is NOT claimed

## 1. Evidence level (read first)

Everything here is **RTL simulation (Verilator 5.020)**, an **independent Python model**, **formal proofs (Yosys 0.33 → AIGER → ABC `pdr`)** and a
**mutation campaign**.  There is **no FPGA, no synthesis with timing, no place-and-route, no power, no silicon** result, and **no frequency, area or
power figure is claimed** (the cell count in `09` is a generic Yosys `stat`, not an area number).  This is **not** a security certification, not
a Common Criteria / FIPS evaluation, and **not** a validated cryptographic module.

## 2. Integration assumptions (each is a precondition of the guarantees; Citadel cannot check them)

| Id | Assumption | If violated |
|---|---|---|
| **A-CFG** | The command port and the telemetry port are physically reachable **only** from the management plane (secure monitor / ControlCore), and `cfg_en_i` is tied to the secure-boot verdict | Anyone who can drive the command port with the label ROOT and `priv = 1` owns the policy.  *Privilege on these ports is a label; physical exclusivity is the control.* |
| **A-PORT** | Every master reaches memory / devices only through its check point (`04` R1); `src` of a check port is the instance index (one physical master per port) | A second path bypasses the policy completely |
| **A-DOM** | The management plane (ROOT / MGMT) is trusted to assign tenant windows / permissions correctly; hardware prevents *overlap* of exclusive windows and *escalation* of capability, not a wrong assignment | A wrong window is a configuration error |
| **A-QUIESCE** | A domain is quiesced before revocation (`03` §7) | A request already forwarded completes |
| **A-RST** | One reset for Citadel and its engines, released synchronously (ALP-RST-01/03); the platform reset also resets / zeroises the crypto engine | Key / state survival across reset differs between blocks |
| **A-DFT** | Test and debug access is disabled by the production lifecycle (TestCore's unlock is an interlock, **not security**); `dft_active_i` reflects test mode | MBIST / JTAG is a path to memory that no master-port policy can see |
| **A-ACT** | The queues / engines honour `abort_*` and `eng_rst_*`, and report `eng_rst_done` | Containment is only as real as its actuator |
| **A-VERDICT** | The external authenticated-boot block's verdict is truthful | Citadel enforces *policy around* the verdict only |
| **A-ENGINE** | The crypto engine implements the algorithms it advertises correctly; its zeroise really wipes | Citadel cannot see inside |
| **A-TOOL** | Event sources are pulses (levels via `LEVEL_MASK`); the platform provides a clock and a reset | counting semantics |
| **A-TGT** | A target accepts a presented request in bounded time or is reset by the containment action (a permitted request that is presented but not accepted stays presented after a quarantine / lock-down; only a port-isolation flush withdraws it); a target honours ALP alignment and touches only `[addr, addr+15]`; an engine reset drops the requests it was serving and their responses | the delay between a revocation and the side effect of an already-permitted request is unbounded; a target that aligns down could reach below the checked window |
| **A-TEL** | The telemetry source port `tel_src_i` is a physical port index; the management plane arrives on a port in `TEL_PRIV_PORTS`, tenants on others | the ROOT / MGMT label alone is **not** trusted for telemetry: a tenant-facing port presenting it is an access violation |
| **A-QIDX** | `ev_idx` of queue-source events comes from the queue controller's wiring, not from a tenant | a tenant-influenced index could hold another tenant's queue (not checked against the attributed domain's queue mask) |

## 3. Not provided (deliberately)

* **No cryptography, no signature verification, no key storage** in Citadel; no random-number source; no tamper detection / resistance, no
  side-channel countermeasures, no fault-injection countermeasures against an attacker with physical access.
* **No secure root of trust.**  `sf_citadel_secboot` is policy + interface.  Without a real OTP / eFuse macro (absent in the repository) there is no
  genuine anti-rollback, revocation or tamper-proof key.  Reporting `ABSENT` / `WAIT` / `AUTH_OK` / `FAILED` accurately is the only claim.
* **No AES-GCM** (does not exist in the repository) — reported `UNSUPPORTED`.  AES-XTS / CMAC (P59) are interface-compatible but not integrated.
* **No address translation / IOMMU**; Citadel checks the physical address it is given.
* **No automatic quarantine on repeated violations** (by design, `05`).
* **No confidentiality of timing**: verdicts are combinational and identical for every denial reason, but no constant-time or timing-channel analysis was done.
* **Not covered by the master-port policy**: DFT / MBIST / JTAG paths, debug masters not given a check point, physical attacks.

## 4. Known limitations of the design

1. **Windows are single-range**: a transfer spanning two adjacent allowing windows is denied by policy (software splits).  Limits: `NW` windows per domain.
2. **Revocation is not instantaneous for a request already forwarded** (§7 of `03`).
3. **One command per cycle; one crypto request at a time; one fault event per cycle** (all occurrences are counted, containment of coalesced duplicates is not repeated).
4. **No always-on domain**: counters and policy restart at reset; "reset events" counts containment resets only.
5. **Counters saturate** (do not wrap): after saturation the *count* is a lower bound, the *event* is still contained.
6. **Telemetry port**: `NDOM ≤ 32`, `NQ ≤ 32`, `NP ≤ 8` (32-bit register layout).
7. **Isolated port stays isolated** until the engine reports done or a privileged clear (`RST_HOLD = 0`): an engine that never reports done needs ROOT / MGMT.
8. **After a failed boot privileged telemetry is closed**; the failure is visible only on `boot_state_o / boot_err_o / lockdown_o / irq_o`.
9. **The Meridian and CloudDMA adapters (`04` §4–5) and the P28 wiring (`06` §1) were not built or run against those blocks' RTL.**
10. **MGMT may clear queue holds and port isolation of any resource** (including ones set by containment of a system-domain fault), and
    **port bindings persist across REVOKE / ENROLL** (a new tenant takes over the ports bound to a slot).  Both are consequences of "ROOT / MGMT
    are the trusted management plane" (A-DOM); they are not enforced by hardware.  Found by the independent review, documented, not changed.
11. **Two fault events for different queues of the same source inside one arbitration window coalesce**; only the first is contained
    (both are counted, `overrun` is flagged).  The window is now bounded (round-robin), not eliminated.
12. **A permitted, presented, not yet accepted request survives a quarantine / lock-down** (A-TGT); only the isolation flush withdraws it.
13. **An engine that ties `eng_rst_done_i` permanently high releases its isolated port after two cycles** (A-ACT); the hardware cannot tell an
    honest instantaneous reset from a stuck signal.

## 5. Formal proof bounds and assumptions (summary; details and per-job parameters in `07`)

* Proofs are **unbounded** (ABC `pdr` returned *Property proved*) **at the parameter points listed**.  Isolation (`fv_cit_iso`) is proved at
  `NDOM = 2, NW = 2, NP = 2, AW = 5`; the permission checker at `AW` = 8, 12, 16 and **64** (`LEN_W = 32`); table privilege at `NDOM = 3, AW = 6`.
  The logic is width- and count-generic and is *replayed* at the real width and counts (`def64`) against the independent model, but a theorem for
  `NDOM = 8, NW = 4, AW = 64` was **not** closed by the prover: that step is an argument by parametricity, backed by simulation, not a proof.
* The table privilege properties are **one-step properties valid from every state** (no reset-state assumption), hence for all time.
* Assumptions of the proofs: reset asserted in the first cycle (where a reset-state is needed); ALP request-handshake obedience by the master and target
  (gate, crypto); `permit ⇔ status == OKAY` for the gate (itself proved for the checker); unique domain ids for the crypto adapter and the
  priority-free permission predicate (INV-UNIQ, proved for the real table); well-formed event severity per source and in-range slot numbers for the fault
  manager.  The environment of every proof is stated in the header of its wrapper in `formal/citadel/`.
