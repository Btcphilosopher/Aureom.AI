# 03 — Domain table and privileged configuration (`sf_citadel_domain_table`)

## 1. Domain descriptor (one per slot, `NDOM` slots)

| Field | Content |
|---|---|
| Domain ID | 8 bit, Albion domain space; unique among non-empty slots (INV-UNIQ) |
| State | `INVALID` (empty) / `SUSPENDED` (enrolled, no access) / `ACTIVE` / `QUARANTINED` (containment; state kept for forensics) |
| Capabilities | `priv`, `secure` — set only by ROOT at enrolment, never changed afterwards (proved `T-CAPS`) |
| Allowed memory windows | `NW` × `{valid, base, limit (inclusive), r, w, x, exclusive}` |
| Read / write permissions | per window (`r`, `w`, `x`), and per device: `devrd[NDEV]`, `devwr[NDEV]` |
| Queue permissions | `qmask[NQ]` |
| Key permissions | `kmask[NKEY]` (used by the crypto adapter; zeroised on revoke / quarantine) |
| **Port bindings** | per **physical port**: the set of slots whose domain id that port may present |

After reset every slot is `INVALID`, every window invalid and every binding empty: **default deny**.

## 2. Privileged command port

All state changes go through **one** port; one command per cycle, answered one cycle later (`rsp_valid_o`, `rsp_status_o`).

```
cfg_en_i                    boot authorised / platform enable (see sf_citadel_secboot)
cmd_valid_i  cmd_op_i[3:0]  cmd_dom_i[7:0] + cmd_priv_i  = requester label + privilege attribute
cmd_slot_i  cmd_win_i  cmd_port_i  cmd_arg_dom_i  cmd_flags_i[7:0]  cmd_data0_i[63:0]  cmd_data1_i[63:0]
```

| Op | Name | Arguments | Who |
|---|---|---|---|
| 1 | ENROLL | slot, arg_dom, flags[0]=priv cap, flags[1]=secure cap | ROOT any id; MGMT tenant ids only, caps = 0 |
| 2 | SET_WINDOW | slot, win, data0=base, data1=limit, flags: r=1 w=2 x=4 **excl=8** | ROOT; MGMT on tenant slots |
| 3 | CLR_WINDOW | slot, win | ″ |
| 4 | SET_DEVPRM | slot, data0=read mask, data1=write mask | ″ |
| 5 | SET_QPRM | slot, data0=queue mask | ″ |
| 6 | SET_KEYPRM | slot, data0=key mask | ″ |
| 7 | SET_STATE | slot, flags[1:0] = 1 SUSPENDED / 2 ACTIVE / 3 QUARANTINED | ″; **releasing a quarantine: ROOT only** |
| 8 | REVOKE | slot | ″ (clears **everything**, zeroises the slot's keys) |
| 9 | BIND_PORT | port, data0 = slot mask | ROOT, before LOCK |
| 10 | LOCK | — | ROOT; freezes bindings and every system-domain slot until reset |
| 11 | CLR_QHOLD | data0 = queue mask | ROOT, MGMT |
| 12 | CLR_ISOL | data0 = port mask | ROOT, MGMT |
| 13 | CLR_SAFE | — | **ROOT only** |
| 14 | SET_THRESH | data0[15:0] = per-domain violation alert threshold | ROOT |
| 15 | CLR_CNT | — (clears counters, report, last-fault record) | **ROOT only** (clearing audit evidence is not a management right) |

### Status (always returned; a refused command changes **no** state — proved `T-REFUSED`)

`0 OK · 1 BAD_CMD (opcode 0) · 2 BAD_PRIV · 3 BAD_ARG · 4 BAD_SLOT · 5 EXISTS · 6 OVERLAP · 7 LOCKED · 8 BAD_STATE · 9 NOT_AUTH`

### Check order (first failing decides)

`cfg_en_i` low → `NOT_AUTH`; requester not (`priv` ∧ label ∈ {ROOT, MGMT}) → `BAD_PRIV`; **then** opcode 0 → `BAD_CMD`; then per-op
slot / authority / lock / state / argument / overlap checks.  **Privilege is checked before the opcode is decoded**, so an
unprivileged requester learns nothing about which opcodes exist (test `P1`, proved `T-UNPRIV`, `T-BADCMD`).

### Argument guards worth knowing

* With `AW < 64` a `data0`/`data1` that does not fit `AW` is `BAD_ARG`, never silently truncated (a truncated base would install a
  window somewhere other than requested).
* A window with `base > limit`, a mask bit beyond `NDEV/NQ/NKEY/NDOM`, a state value 0, reserved flag bits → `BAD_ARG`.
* ENROLL: slot occupied **or** id already enrolled elsewhere → `EXISTS`.

## 4. Privilege matrix (proved: `fv_cit_table`, `T-MGMT`, `T-LOCK`)

| | ROOT | MGMT | any other label / no `priv` |
|---|---|---|---|
| system slots (id ≤ 0x0F) | all (until LOCK) | **never** | never |
| tenant slots | all | all except **ending a quarantine** (neither `SET_STATE` out of it nor `REVOKE`, which would let the slot be re-enrolled fresh) | never |
| enrol with `priv` / `secure` capability | yes | **no** | never |
| BIND_PORT, LOCK, CLR_SAFE, SET_THRESH, CLR_CNT | yes | **no** | never |
| after LOCK | tenant slots only; bindings frozen; no new system domain | tenant slots only | never |

An accepted MGMT command never changes a system slot, the bindings, the lock, the threshold, the safe-state / counter controls,
never creates a capable domain and never ends a quarantine (proved `T-MGMT`, `T-RELEASE`; the first version of this property did not cover
`REVOKE`, and the independent review showed MGMT could REVOKE a quarantined slot, re-ENROLL and re-activate it — fixed, mutant `T25`).

Two things the matrix does **not** restrict, stated so nobody assumes otherwise: MGMT may `CLR_QHOLD` and `CLR_ISOL` any queue / port,
including ones held by the containment of a *system* domain's fault (the privilege model is "ROOT / MGMT are the trusted management
plane", assumption A-DOM), and **port bindings persist across `REVOKE` / `ENROLL`**, so a new tenant enrolled by MGMT into a slot takes
over the physical port(s) bound to that slot.  After `LOCK` only ROOT-before-LOCK could have changed bindings.

## 5. Isolation by construction — exclusive windows

A window installed with `excl = 1` (a **protected region**) must not overlap **any** window of any other non-empty domain, and no
window may overlap an existing exclusive window of another domain; otherwise `SET_WINDOW` returns `OVERLAP` and nothing changes.
An exclusive window may also not touch a **device region** (it would be inert there, devices being protected by device
permissions): `BAD_ARG`.

Invariants (proved inductive over every command sequence including resets, `fv_cit_iso`):

* **INV-EXCL** — for distinct slots *i ≠ j* and valid windows *a* of *i*, *b* of *j*: `excl(a) ∨ excl(b) ⇒ a ∩ b = ∅`
* **INV-UNIQ** — two non-empty slots never share a domain id
* **INV-WF** — a valid window has `base ≤ limit`; an empty slot holds no valid window
* **INV-NODEV** — a valid exclusive window never touches a device region

Consequence (**isolation theorem**, proved): a *permitted* request never touches a single byte of another domain's exclusive window.
Suspended and quarantined slots keep their windows, so a protected region cannot be claimed by someone else until its owner
is revoked.

## 6. Containment hook and key hygiene

* `qtn_valid_i / qtn_slot_i` (from the fault manager) forces a slot to `QUARANTINED`.  It is evaluated against the state at the
  **start of the cycle**: a fault attributed to a slot's previous occupant never quarantines a tenant enrolled in that slot in the
  same cycle; a same-cycle REVOKE wins (the slot is gone); containment wins over a same-cycle `SET_STATE`.
* Entering `QUARANTINED`, `REVOKE`, and a `SET_KEYPRM` that **removes** key slots from a still-enrolled domain request zeroisation (of
  the held mask, the old mask, and the removed slots respectively; proved `T-ZERO`, mutants `T26`, `T27` — before the fix a slot could be
  shrunk away from tenant A and granted to B with A's key still live).  Entering `QUARANTINED` and `REVOKE` zeroise the slot's key mask (`zero_valid_o / zero_mask_o`); the mask zeroised
  is the one the slot *holds after the cycle* (a same-cycle `SET_KEYPRM` cannot leave a freshly granted key un-zeroised — this was
  the first real bug found by the replay test, mutant `T14`).
* A new tenant never inherits per-slot telemetry (`slot_clr_o` clears per-domain counters on ENROLL and REVOKE).  Bindings persist
  across REVOKE/ENROLL (a slot is a hardware resource provisioned to a port by ROOT; the tenant occupying it changes).

## 7. Revocation rule

A policy change applies to the **next** check.  A request already forwarded (or being presented to a target) completes — the same
rule CloudDMA states.  To remove access *now*, suspend the domain and quiesce its masters first.  The one autonomous exception is port
isolation, which flushes the gate (`04` §2).  Reset clears every register,
including the in-flight response and all control pulses (proved `T-RESET`).
