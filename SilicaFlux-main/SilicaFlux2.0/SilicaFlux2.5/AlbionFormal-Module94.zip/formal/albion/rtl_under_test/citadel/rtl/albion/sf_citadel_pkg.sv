// =============================================================================
//  sf_citadel_pkg.sv  --  SilicaFlux Albion Citadel: shared constants
// -----------------------------------------------------------------------------
//  Project   : Aureom.AI / SilicaFlux Albion -- Project 89 "Citadel"
//  Role      : Code points shared by every Citadel module and by the tests:
//              check classes, verdict reason codes, domain states, privileged
//              command opcodes and statuses, RAS sources / severities / actions
//              and the default device map.
//
//  Style     : follows docs/albion/NAMING_RULES.md (Yosys 0.33 subset):
//              * constants only -- there are NO functions in this package, so
//                the "package function resolved in caller scope" Yosys 0.33
//                hazard cannot occur;
//              * no enums, no casts, no struct constants; plain sized logic
//                localparams, referenced as sf_citadel_pkg::NAME;
//              * UPPER_SNAKE_CASE constants, prefix SF_CIT_.
//
//  The device map below is a COPY of the Albion generated map
//  (third_party/albion/sf_albion_memmap_pkg.sv, profile "full catalogue",
//  device-type regions only).  tests/citadel/unit/tb_citadel_pkg.sv asserts
//  that it equals the generated package, so a drift fails the regression.
//
//  This file contains no process-node, timing or performance claims.
// =============================================================================
`default_nettype none

/* verilator lint_off UNUSEDPARAM */
package sf_citadel_pkg;

  // ===========================================================================
  // 1. Identity
  // ===========================================================================
  localparam int unsigned SF_CIT_VERSION_MAJOR = 0;
  localparam int unsigned SF_CIT_VERSION_MINOR = 1;

  // ===========================================================================
  // 2. Check classes (what the requester is asking permission for)
  // ===========================================================================
  //  ADDR  : a byte range [addr, addr+len-1].  The checker itself decides
  //          whether the range is a device region (device permissions) or
  //          ordinary memory (domain windows); the requester cannot choose.
  //  QUEUE : use of queue number idx (virtual-device / DMA / packet queues).
  localparam logic [1:0] SF_CIT_CLS_ADDR  = 2'd0;
  localparam logic [1:0] SF_CIT_CLS_QUEUE = 2'd1;

  // ===========================================================================
  // 3. Verdict reason codes (4 bit).  First failing check in the order listed
  //    in docs/citadel/02_PERMISSION_CHECKER.md decides.  The reason is for
  //    PRIVILEGED audit; the requester only ever sees the coarse ALP status
  //    (see sf_citadel_permission), so it cannot probe other domains' layout.
  // ===========================================================================
  localparam logic [3:0] SF_CIT_R_OK        = 4'd0;
  localparam logic [3:0] SF_CIT_R_BAD_OP    = 4'd1;   // op is not READ / WRITE
  localparam logic [3:0] SF_CIT_R_BAD_ATTR  = 4'd2;   // reserved attribute bit / memtype 3 / reserved class
  localparam logic [3:0] SF_CIT_R_BAD_DOM   = 4'd3;   // invalid / unknown / NOT BOUND to this source port
  localparam logic [3:0] SF_CIT_R_BAD_LEN   = 4'd4;   // zero length
  localparam logic [3:0] SF_CIT_R_OVERFLOW  = 4'd5;   // addr + len - 1 wraps the address space
  localparam logic [3:0] SF_CIT_R_DOM_STATE = 4'd6;   // domain not ACTIVE (suspended / quarantined)
  localparam logic [3:0] SF_CIT_R_NOMAP     = 4'd7;   // no single window / device contains the range
  localparam logic [3:0] SF_CIT_R_PERM      = 4'd8;   // containing window lacks read / write / execute
  localparam logic [3:0] SF_CIT_R_DEV       = 4'd9;   // device permission missing
  localparam logic [3:0] SF_CIT_R_QUEUE     = 4'd10;  // queue out of range / not permitted / on abort-hold
  localparam logic [3:0] SF_CIT_R_PRIV      = 4'd11;  // privileged / secure claim exceeds the domain's capability
  localparam logic [3:0] SF_CIT_R_LOCKDOWN  = 4'd12;  // safe state or DFT access active
  localparam logic [3:0] SF_CIT_R_ISOLATED  = 4'd13;  // source port isolated (engine reset / containment)
  localparam logic [3:0] SF_CIT_R_MAX       = 4'd13;  // highest defined reason

  // ===========================================================================
  // 4. Domain state (2 bit)
  // ===========================================================================
  localparam logic [1:0] SF_CIT_DS_INVALID     = 2'd0;  // slot empty
  localparam logic [1:0] SF_CIT_DS_SUSPENDED   = 2'd1;  // enrolled, no access, state kept
  localparam logic [1:0] SF_CIT_DS_ACTIVE      = 2'd2;  // access per descriptor
  localparam logic [1:0] SF_CIT_DS_QUARANTINED = 2'd3;  // fault containment: no access, state kept for forensics

  // ===========================================================================
  // 5. Privileged command opcodes (4 bit) and statuses (4 bit)
  // ===========================================================================
  localparam logic [3:0] SF_CIT_OP_INVALID    = 4'd0;   // never legal: answered CS_BAD_CMD
  localparam logic [3:0] SF_CIT_OP_ENROLL     = 4'd1;
  localparam logic [3:0] SF_CIT_OP_SET_WINDOW = 4'd2;
  localparam logic [3:0] SF_CIT_OP_CLR_WINDOW = 4'd3;
  localparam logic [3:0] SF_CIT_OP_SET_DEVPRM = 4'd4;
  localparam logic [3:0] SF_CIT_OP_SET_QPRM   = 4'd5;
  localparam logic [3:0] SF_CIT_OP_SET_KEYPRM = 4'd6;
  localparam logic [3:0] SF_CIT_OP_SET_STATE  = 4'd7;
  localparam logic [3:0] SF_CIT_OP_REVOKE     = 4'd8;
  localparam logic [3:0] SF_CIT_OP_BIND_PORT  = 4'd9;
  localparam logic [3:0] SF_CIT_OP_LOCK       = 4'd10;
  localparam logic [3:0] SF_CIT_OP_CLR_QHOLD  = 4'd11;
  localparam logic [3:0] SF_CIT_OP_CLR_ISOL   = 4'd12;
  localparam logic [3:0] SF_CIT_OP_CLR_SAFE   = 4'd13;
  localparam logic [3:0] SF_CIT_OP_SET_THRESH = 4'd14;
  localparam logic [3:0] SF_CIT_OP_CLR_CNT    = 4'd15;

  localparam logic [3:0] SF_CIT_CS_OK       = 4'd0;
  localparam logic [3:0] SF_CIT_CS_BAD_CMD  = 4'd1;   // opcode 0 (INVALID) -- no other opcode is undefined
  localparam logic [3:0] SF_CIT_CS_BAD_PRIV = 4'd2;   // requester is not allowed this command
  localparam logic [3:0] SF_CIT_CS_BAD_ARG  = 4'd3;   // malformed argument (nothing changed)
  localparam logic [3:0] SF_CIT_CS_BAD_SLOT = 4'd4;   // slot / port out of range, or slot not enrolled
  localparam logic [3:0] SF_CIT_CS_EXISTS   = 4'd5;   // slot occupied or domain id already enrolled
  localparam logic [3:0] SF_CIT_CS_OVERLAP  = 4'd6;   // exclusive-window overlap with another domain
  localparam logic [3:0] SF_CIT_CS_LOCKED   = 4'd7;   // configuration locked until reset
  localparam logic [3:0] SF_CIT_CS_BAD_STATE= 4'd8;   // illegal state transition
  localparam logic [3:0] SF_CIT_CS_NOT_AUTH = 4'd9;   // configuration port not enabled (boot not authorised)

  // Window flag bits (cmd_flags_i of SET_WINDOW)
  localparam int unsigned SF_CIT_WF_R    = 0;
  localparam int unsigned SF_CIT_WF_W    = 1;
  localparam int unsigned SF_CIT_WF_X    = 2;
  localparam int unsigned SF_CIT_WF_EXCL = 3;   // exclusive: no other domain may hold an overlapping window
  // Enrol flag bits (cmd_flags_i of ENROLL)
  localparam int unsigned SF_CIT_EF_PRIV   = 0; // domain may issue privileged-attribute requests
  localparam int unsigned SF_CIT_EF_SECURE = 1; // domain may issue secure-attribute requests

  // ===========================================================================
  // 6. RAS: severities, sources, containment actions
  // ===========================================================================
  //  CORRECTED     the error was repaired; data is valid                (count / log)
  //  DETECTED      error detected, operation failed or discarded, data
  //                not consumed; recoverable by retry / abort           (reject / abort queue)
  //  UNCORRECTABLE data lost or corrupt in a resource that has an owner  (quarantine owner / reset engine)
  //  FATAL         device-level integrity cannot be assumed             (safe state)
  localparam logic [1:0] SF_CIT_SEV_CORRECTED     = 2'd0;
  localparam logic [1:0] SF_CIT_SEV_DETECTED      = 2'd1;
  localparam logic [1:0] SF_CIT_SEV_UNCORRECTABLE = 2'd2;
  localparam logic [1:0] SF_CIT_SEV_FATAL         = 2'd3;

  localparam int unsigned SF_CIT_NSRC = 16;
  localparam logic [3:0] SF_CIT_SRC_ECC_CE      = 4'd0;   // SRAM ECC corrected
  localparam logic [3:0] SF_CIT_SRC_ECC_UE      = 4'd1;   // SRAM ECC uncorrectable (carries an address)
  localparam logic [3:0] SF_CIT_SRC_ECC_FATAL   = 4'd2;   // ECC wrapper fatal request
  localparam logic [3:0] SF_CIT_SRC_MBIST_FAIL  = 4'd3;   // memory-test failure
  localparam logic [3:0] SF_CIT_SRC_DMA_FAULT   = 4'd4;   // DMA bus error / timeout / descriptor fault
  localparam logic [3:0] SF_CIT_SRC_PKT_PROTO   = 4'd5;   // packet protocol error
  localparam logic [3:0] SF_CIT_SRC_ILLEGAL     = 4'd6;   // rejected access (verified domain) / privileged-command denial
  localparam logic [3:0] SF_CIT_SRC_INVALID_DMA = 4'd7;   // rejected access on a DMA-kind port
  localparam logic [3:0] SF_CIT_SRC_WATCHDOG    = 4'd8;   // engine watchdog expiry
  localparam logic [3:0] SF_CIT_SRC_COMPUTE_ERR = 4'd9;   // compute error (parity / residue / result check)
  localparam logic [3:0] SF_CIT_SRC_THERM_WARN  = 4'd10;  // thermal warning
  localparam logic [3:0] SF_CIT_SRC_THERM_CRIT  = 4'd11;  // thermal critical
  localparam logic [3:0] SF_CIT_SRC_AUTH_FAIL   = 4'd12;  // authentication failure (crypto tag, signature)
  localparam logic [3:0] SF_CIT_SRC_BOOT_FAIL   = 4'd13;  // secure-boot failure
  localparam logic [3:0] SF_CIT_SRC_QUEUE_FAULT = 4'd14;  // queue fault (descriptor overflow, ring corruption)
  localparam logic [3:0] SF_CIT_SRC_EXT_FATAL   = 4'd15;  // external fatal request (e.g. ControlCore RAS)

  //  Containment action bits.
  localparam int unsigned SF_CIT_ACT_REPORT     = 0;   // sticky device-fault report (irq)
  localparam int unsigned SF_CIT_ACT_ABORT_Q    = 1;   // abort + hold the affected queue
  localparam int unsigned SF_CIT_ACT_RST_ENGINE = 2;   // isolate and reset the affected engine / port
  localparam int unsigned SF_CIT_ACT_QUARANTINE = 3;   // quarantine the owning domain
  localparam int unsigned SF_CIT_ACT_SAFE_STATE = 4;   // enter the safe state (device-wide lockdown)

  //  Fixed per-source policy: severity (2 bit) and base action mask (5 bit),
  //  one 8-bit entry per source, entry i at bits [8*i +: 8] = {1'b0, sev[1:0], act[4:0]}.
  //  Conditional rules (owner resolution, system-domain escalation) are in
  //  sf_citadel_fault_manager and docs/citadel/05_FAULT_CONTAINMENT.md.
  //                                        act = SAFE QTN RST ABQ REP
  localparam logic [7:0] SF_CIT_POL_ECC_CE      = {1'b0, 2'd0, 5'b00000};
  localparam logic [7:0] SF_CIT_POL_ECC_UE      = {1'b0, 2'd2, 5'b01001};
  localparam logic [7:0] SF_CIT_POL_ECC_FATAL   = {1'b0, 2'd3, 5'b10001};
  localparam logic [7:0] SF_CIT_POL_MBIST_FAIL  = {1'b0, 2'd2, 5'b01001};
  localparam logic [7:0] SF_CIT_POL_DMA_FAULT   = {1'b0, 2'd1, 5'b00011};
  localparam logic [7:0] SF_CIT_POL_PKT_PROTO   = {1'b0, 2'd1, 5'b00011};
  localparam logic [7:0] SF_CIT_POL_ILLEGAL     = {1'b0, 2'd1, 5'b00000};
  localparam logic [7:0] SF_CIT_POL_INVALID_DMA = {1'b0, 2'd1, 5'b00000};
  localparam logic [7:0] SF_CIT_POL_WATCHDOG    = {1'b0, 2'd2, 5'b00101};
  localparam logic [7:0] SF_CIT_POL_COMPUTE_ERR = {1'b0, 2'd2, 5'b00111};
  localparam logic [7:0] SF_CIT_POL_THERM_WARN  = {1'b0, 2'd1, 5'b00001};
  localparam logic [7:0] SF_CIT_POL_THERM_CRIT  = {1'b0, 2'd3, 5'b10001};
  localparam logic [7:0] SF_CIT_POL_AUTH_FAIL   = {1'b0, 2'd1, 5'b00001};
  localparam logic [7:0] SF_CIT_POL_BOOT_FAIL   = {1'b0, 2'd3, 5'b10001};
  localparam logic [7:0] SF_CIT_POL_QUEUE_FAULT = {1'b0, 2'd1, 5'b00011};
  localparam logic [7:0] SF_CIT_POL_EXT_FATAL   = {1'b0, 2'd3, 5'b10001};

  localparam logic [127:0] SF_CIT_POLICY = {
    SF_CIT_POL_EXT_FATAL,   SF_CIT_POL_QUEUE_FAULT, SF_CIT_POL_BOOT_FAIL,   SF_CIT_POL_AUTH_FAIL,
    SF_CIT_POL_THERM_CRIT,  SF_CIT_POL_THERM_WARN,  SF_CIT_POL_COMPUTE_ERR, SF_CIT_POL_WATCHDOG,
    SF_CIT_POL_INVALID_DMA, SF_CIT_POL_ILLEGAL,     SF_CIT_POL_PKT_PROTO,   SF_CIT_POL_DMA_FAULT,
    SF_CIT_POL_MBIST_FAIL,  SF_CIT_POL_ECC_FATAL,   SF_CIT_POL_ECC_UE,      SF_CIT_POL_ECC_CE
  };

  // ===========================================================================
  // 6b. CloudCrypto adapter: algorithm codes and statuses
  // ===========================================================================
  //  Citadel contains NO cryptography.  The adapter only AUTHORISES a command and selects a key SLOT of an external,
  //  validated engine (key material never enters Citadel).  An algorithm is usable only if the engine advertises it
  //  (cap_algo_i); nothing is emulated.  Codes >= 2 use a key.
  localparam logic [3:0] SF_CIT_ALGO_NONE        = 4'd0;   // invalid
  localparam logic [3:0] SF_CIT_ALGO_SHA256      = 4'd1;   // hash: no key
  localparam logic [3:0] SF_CIT_ALGO_AESGCM_ENC  = 4'd2;
  localparam logic [3:0] SF_CIT_ALGO_AESGCM_DEC  = 4'd3;   // verifies the tag
  localparam logic [3:0] SF_CIT_ALGO_AESXTS_ENC  = 4'd4;
  localparam logic [3:0] SF_CIT_ALGO_AESXTS_DEC  = 4'd5;
  localparam logic [3:0] SF_CIT_ALGO_CMAC        = 4'd6;
  localparam logic [3:0] SF_CIT_ALGO_MAX         = 4'd6;

  localparam logic [3:0] SF_CIT_CE_OK            = 4'd0;
  localparam logic [3:0] SF_CIT_CE_BAD_ALGO      = 4'd1;   // algorithm code not defined
  localparam logic [3:0] SF_CIT_CE_UNSUPPORTED   = 4'd2;   // the engine does not implement it
  localparam logic [3:0] SF_CIT_CE_DENIED_DOMAIN = 4'd3;   // domain unknown / unbound / not ACTIVE / safe state / DFT
  localparam logic [3:0] SF_CIT_CE_DENIED_KEY    = 4'd4;   // no permission for this key slot (or slot out of range)
  localparam logic [3:0] SF_CIT_CE_ENGINE_ERR    = 4'd5;
  localparam logic [3:0] SF_CIT_CE_AUTH_FAIL     = 4'd6;   // tag / MAC mismatch reported by the engine
  localparam logic [3:0] SF_CIT_CE_KEY_WIPED     = 4'd7;   // the key was zeroised while the operation was in flight
  localparam logic [3:0] SF_CIT_CE_KEY_BLOCKED   = 4'd8;   // a zeroise of this slot is not yet confirmed

  // ===========================================================================
  // 7. Default device map (device-type regions of the Albion catalogue)
  // ===========================================================================
  //  Entry i at bits [64*i +: 64].  Order: controlcore, dma, network, virtio,
  //  tensor_vector, security, perf.  Masks are base/mask decodes exactly as in
  //  sf_albion_memmap_pkg (region = {addr : (addr & MASK) == BASE}).
  localparam int unsigned SF_CIT_NDEV_DEFAULT = 7;

  localparam logic [447:0] SF_CIT_DEV_BASES_DEFAULT = {
    64'h0000000170000000,   // 6 perf
    64'h0000000160000000,   // 5 security
    64'h0000000150000000,   // 4 tensor_vector
    64'h0000000140000000,   // 3 virtio
    64'h0000000130000000,   // 2 network
    64'h0000000120000000,   // 1 dma
    64'h0000000100000000    // 0 controlcore
  };
  localparam logic [447:0] SF_CIT_DEV_MASKS_DEFAULT = {
    64'hFFFFFFFFFFF00000,   // 6 perf          (1 MiB)
    64'hFFFFFFFFFFF00000,   // 5 security      (1 MiB)
    64'hFFFFFFFFF0000000,   // 4 tensor_vector (256 MiB)
    64'hFFFFFFFFFF000000,   // 3 virtio        (16 MiB)
    64'hFFFFFFFFFF000000,   // 2 network       (16 MiB)
    64'hFFFFFFFFFFF00000,   // 1 dma           (1 MiB)
    64'hFFFFFFFFF0000000    // 0 controlcore   (256 MiB)
  };
  //  Per-device requirement flags: bit i of each vector.
  //  priv_only  : from the Albion region attribute bit 3
  //  secure_only: from the Albion region attribute bit 4
  localparam logic [6:0] SF_CIT_DEV_PRIV_DEFAULT   = 7'b1100011;   // controlcore, dma, security, perf  (bits 0,1,5,6)
  localparam logic [6:0] SF_CIT_DEV_SECURE_DEFAULT = 7'b0100000;   // security                          (bit 5)

endpackage
/* verilator lint_on UNUSEDPARAM */

`default_nettype wire
