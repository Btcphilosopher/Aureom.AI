// =============================================================================
//  sf_citadel_gate.sv  --  Citadel enforcement check point for one ALP master port
// -----------------------------------------------------------------------------
//  Sits between ONE master (Meridian master port, accelerator, host DMA bridge,
//  virtual-device descriptor engine, peripheral-register initiator) and the
//  fabric / target.  The downstream request port t_req_* is reachable ONLY
//  through this module: there is no other path from m_req_* to t_req_*, so a
//  master cannot bypass the policy through an alternate port as long as it is
//  attached here and nowhere else (integration rule, docs/citadel/04).
//
//  Operation
//    * one request is accepted into a holding register (m_req_ready_o);
//    * the holding register drives the check port chk_* (the fields come from the
//      HELD request, never from the live input); the verdict is combinational
//      (sf_citadel_permission, LAT = 0) from the table state;
//    * PERMIT: t_req_valid_o is raised with the held request UNCHANGED.  Nothing
//      reaches the target before the verdict, and a denied request never does;
//    * DENY: the request is NEVER forwarded.  An explicit error response (the
//      requester-visible ALP status of the verdict, tag echoed, data zero,
//      ALP-RSP-05) is returned on m_rsp_*, but only after every previously
//      forwarded request has completed, so response ORDER is preserved (ORD-01);
//    * the verdict is LATCHED in the first cycle it is evaluated: a policy change
//      while a request is held or presented cannot withdraw a valid the target
//      has already seen (ALP-REQ-02).  A policy change applies to the NEXT
//      request; a request already presented completes (the revocation rule of
//      docs/citadel/03_DOMAIN_TABLE.md: quiesce first).  The delay of such a
//      request is bounded only by the target's own acceptance -- assumption
//      A-TGT; the one exception is the FLUSH below;
//    * FLUSH (flush_i, wired to port_isol_o[p] of sf_citadel_security): the port
//      is being isolated and its engine reset.  This is the reset event of the
//      downstream protocol (ALP-RST-02), so it may abandon what reset abandons:
//      the held, not yet accepted request is CANCELLED (never forwarded, one
//      explicit SF_ST_CANCELLED response), nothing is presented while flush_i is
//      high, the outstanding count is cleared (the engine's reset drops the
//      requests it was serving; their late responses are drained as orphans) --
//      so a hung engine cannot leave later denied requests without their error
//      response;
//    * chk_commit_o pulses exactly once per request (first evaluation cycle) so
//      the audit counters count each denial once however long it is held.
//
//  Target responses pass through; a response with nothing outstanding is a
//  protocol error: it is drained, flagged (rsp_orphan_o) and NOT forwarded.
//  Reset clears the held request, the latched verdict and the outstanding count
//  (ALP-RST-02: no response is ever generated for a request accepted before reset).
//
//  Fixed ALP v1 widths (sf_albion_pkg): 236-bit request, 148-bit response, one
//  16-byte beat per request (len = 16).
// =============================================================================
`default_nettype none

module sf_citadel_gate #(
  parameter int unsigned OUT_W = 16                        // outstanding-request counter width
) (
  input  wire logic                                   clk_i,
  input  wire logic                                   rst_ni,
  // ---- master side ------------------------------------------------------------
  input  wire logic                                   m_req_valid_i,
  output logic                                        m_req_ready_o,
  input  wire logic [sf_albion_pkg::SF_REQ_W-1:0]     m_req_i,
  output logic                                        m_rsp_valid_o,
  input  wire logic                                   m_rsp_ready_i,
  output logic [sf_albion_pkg::SF_RSP_W-1:0]          m_rsp_o,
  // ---- target side (only reachable through this gate) ---------------------------
  output logic                                        t_req_valid_o,
  input  wire logic                                   t_req_ready_i,
  output logic [sf_albion_pkg::SF_REQ_W-1:0]          t_req_o,
  input  wire logic                                   t_rsp_valid_i,
  output logic                                        t_rsp_ready_o,
  input  wire logic [sf_albion_pkg::SF_RSP_W-1:0]     t_rsp_i,
  // ---- containment -------------------------------------------------------------------
  input  wire logic                                   flush_i,           // port isolated / engine in reset (tie 0 if unused)
  // ---- check port (to sf_citadel_security) -----------------------------------------
  output logic                                        chk_valid_o,
  output logic [7:0]                                  chk_dom_o,
  output logic [3:0]                                  chk_op_o,
  output logic [7:0]                                  chk_attr_o,
  output logic [63:0]                                 chk_addr_o,
  output logic [31:0]                                 chk_len_o,
  output logic [1:0]                                  chk_cls_o,
  output logic [7:0]                                  chk_idx_o,
  output logic                                        chk_commit_o,
  input  wire logic                                   chk_permit_i,
  input  wire logic [3:0]                             chk_status_i,
  // ---- diagnostics ------------------------------------------------------------------
  output logic [OUT_W-1:0]                            outstanding_o,
  output logic                                        rsp_orphan_o
);

  localparam int unsigned REQ_W = sf_albion_pkg::SF_REQ_W;

  logic                have_q, dec_q, permit_q;
  logic [3:0]          status_q;
  logic [REQ_W-1:0]    req_q;
  logic [OUT_W-1:0]    out_q;

  wire out_zero = (out_q == '0);
  wire out_full = (out_q == {OUT_W{1'b1}});

  // ---- check port: always the HELD request ---------------------------------------------
  assign chk_valid_o  = have_q;
  assign chk_dom_o    = req_q[sf_albion_pkg::SF_REQ_DOM_LSB  +: sf_albion_pkg::SF_DOM_W];
  assign chk_op_o     = req_q[sf_albion_pkg::SF_REQ_OP_LSB   +: sf_albion_pkg::SF_OP_W];
  assign chk_attr_o   = req_q[sf_albion_pkg::SF_REQ_ATTR_LSB +: sf_albion_pkg::SF_ATTR_W];
  assign chk_addr_o   = req_q[sf_albion_pkg::SF_REQ_ADDR_LSB +: sf_albion_pkg::SF_ADDR_W];
  assign chk_len_o    = 32'(sf_albion_pkg::SF_BE_W);                   // one 16-byte beat
  assign chk_cls_o    = sf_citadel_pkg::SF_CIT_CLS_ADDR;
  assign chk_idx_o    = 8'd0;
  assign chk_commit_o = have_q && !dec_q;                              // exactly once per request

  // ---- verdict: live in the first cycle, then latched ---------------------------------------
  wire       base_permit = dec_q ? permit_q : chk_permit_i;
  wire [3:0] base_status = dec_q ? status_q : chk_status_i;
  wire       v_permit    = base_permit && !flush_i;                              // a flush cancels the held request
  wire [3:0] v_status    = (base_permit && flush_i) ? sf_albion_pkg::SF_ST_CANCELLED : base_status;

  assign t_req_valid_o = have_q && v_permit && !out_full;
  assign t_req_o       = req_q;
  wire   fwd           = t_req_valid_o && t_req_ready_i;

  // ---- local explicit error response (denied request), ordered after the target's -----------------
  wire        loc_rsp_valid = have_q && !v_permit && out_zero;
  wire [7:0]  req_tag       = req_q[sf_albion_pkg::SF_REQ_TAG_LSB +: sf_albion_pkg::SF_TAG_W];
  wire        req_is_write  = (req_q[sf_albion_pkg::SF_REQ_OP_LSB +: sf_albion_pkg::SF_OP_W] == sf_albion_pkg::SF_OP_WRITE);
  // sf_cmeta_t = {rsvd[3:0], corrected, poisoned, last, is_write}
  wire [sf_albion_pkg::SF_RSP_W-1:0] loc_rsp = {req_tag, v_status, 4'b0000, 1'b0, 1'b0, 1'b1, req_is_write,
                                                {sf_albion_pkg::SF_DATA_W{1'b0}}};
  wire        loc_done      = loc_rsp_valid && m_rsp_ready_i;

  wire pass_rsp = t_rsp_valid_i && !out_zero && !flush_i;
  assign m_rsp_valid_o = loc_rsp_valid || pass_rsp;
  assign m_rsp_o       = loc_rsp_valid ? loc_rsp : t_rsp_i;
  assign t_rsp_ready_o = (out_zero || flush_i) ? 1'b1 : (!loc_rsp_valid && m_rsp_ready_i);   // drain an orphan / a flushed response, else pass through
  assign rsp_orphan_o  = t_rsp_valid_i && out_zero;
  wire   rsp_take      = pass_rsp && !loc_rsp_valid && m_rsp_ready_i;

  assign m_req_ready_o = !have_q || fwd || loc_done;
  assign outstanding_o = out_q;

  always_ff @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      have_q   <= 1'b0;
      dec_q    <= 1'b0;
      permit_q <= 1'b0;
      status_q <= 4'd0;
      req_q    <= '0;
      out_q    <= '0;
    end else begin
      // request holding register
      if (m_req_valid_i && m_req_ready_o) begin
        have_q <= 1'b1;
        dec_q  <= 1'b0;
        req_q  <= m_req_i;
      end else if (fwd || loc_done) begin
        have_q <= 1'b0;
        dec_q  <= 1'b0;
      end
      // latch the verdict in the first evaluation cycle (unless the request completes in that same cycle); a flush
      // latches the CANCELLED verdict of a held request for good (it must not reappear when the flush ends)
      if (have_q && (flush_i || !dec_q) && !fwd && !loc_done) begin
        dec_q    <= 1'b1;
        permit_q <= v_permit;
        status_q <= v_status;
      end
      // outstanding forwarded requests (a flush abandons them)
      if (flush_i)                out_q <= '0;
      else if (fwd && !rsp_take)  out_q <= out_q + 1'b1;
      else if (!fwd && rsp_take)  out_q <= out_q - 1'b1;
    end
  end

endmodule

`default_nettype wire
