# 02 — Permission checker (`sf_citadel_permission`)

The checker decides, for **one request**, *permit or deny* with an explicit reason.  It is purely combinational: the verdict is a
function of the request, the descriptor state exported by the domain table (`03`) and four device-wide levels.  It has no state and
no side effects, so "reject before any side effect" is a property of its *use* (the check point, `04`) and its determinism is
a property of the module (proved, `07`).

## 1. Request

| Input | Meaning | Who drives it |
|---|---|---|
| `src_i` | **physical source port** | a *structural constant of the instance* (generate index in `sf_citadel_security`): a master cannot choose it |
| `dom_i` | claimed domain id (8 bit) | the master (untrusted) |
| `op_i` | `SF_OP_READ` (1) / `SF_OP_WRITE` (2) (ALP codes) | the master |
| `attr_i` | ALP attribute byte (`memtype[1:0]`, `priv[2]`, `secure[3]`, `instr[4]`, `qos`, `rsvd[7]`) | the master (claims, bounded below) |
| `addr_i`, `len_i` | first byte, length in bytes (≥ 1) — `AW = 64`, `LEN_W = 32` in the product | the master |
| `cls_i` | `ADDR` (byte range) or `QUEUE` (queue number `idx_i`) | the master |
| `lockdown_i`, `dft_active_i`, `qhold_i[]`, `port_isol_i[]` | safe state, test access, per-queue abort hold, per-port isolation | fault manager / platform |

## 2. Decision order — the first failing check decides the reason

| # | Check | Reason (`SF_CIT_R_*`) |
|---|---|---|
| 1 | source port isolated (`port_isol_i[src]`) | `ISOLATED` (13) |
| 2 | DFT / test access active (**nobody exempt**) | `LOCKDOWN` (12) |
| 3 | class is neither ADDR nor QUEUE | `BAD_ATTR` (2) |
| 4 | op is not READ / WRITE (includes NONE and the reserved atomic family) | `BAD_OP` (1) |
| 5 | attr reserved bit 7, memtype 3, or `instr` together with WRITE | `BAD_ATTR` (2) |
| 6 | `dom == 0xFF` | `BAD_DOM` (3) |
| 7 | domain unknown, or **not bound to `src`** (spoof) | `BAD_DOM` (3) |
| 8 | safe state and `dom` is not ROOT / MGMT | `LOCKDOWN` (12) |
| 9 | domain state is not ACTIVE (suspended / quarantined) | `DOM_STATE` (6) |
| 10 | `priv` / `secure` claim above the domain's capability | `PRIV` (11) |
| QUEUE | `idx ≥ NQ`, queue on abort-hold, or not in the domain's queue mask | `QUEUE` (10) |
| ADDR 11 | `len == 0` | `BAD_LEN` (4) |
| ADDR 12 | `addr + len − 1` wraps the address space | `OVERFLOW` (5) |
| ADDR 13 | the range **touches a device region**: not wholly inside **one** device → `NOMAP`; device priv-only / secure-only unmet → `PRIV`; instruction fetch → `PERM`; no device read / write permission → `DEV` | see left |
| ADDR 14 | otherwise it is memory: no **single** window contains the range → `NOMAP`; the containing window lacks r / w / x → `PERM` | see left |

`SF_CIT_R_OK` (0) = permit.  Every denial has a reason in 1…13; the reason is an **audit** value (`chk_reason_o`).

## 3. What the requester sees (no layout oracle)

`status_o` is an ALP status: `OKAY`; `BAD_OPCODE` (op invalid); `BAD_ATTR` (attribute / class invalid); **`ACCESS_DENIED` for
everything else** — unmapped address, another tenant's region, missing right, overflow, spoofed domain, safe state, isolation.
A requester therefore cannot distinguish "nothing is mapped there" from "someone else owns it".  (Proved: `a_status_set`,
`a_deny_coarse`; mutant `P18` — reporting `NOMAP` as `DECODE_ERR` — is killed.)

## 4. Arithmetic and policy details

* **No wrap, exact end.**  `last = addr + (len − 1)` is computed in `max(AW, LEN_W) + 1` bits, so no carry is lost even when the
  length is wider than the address; overflow is the carry-out.  Windows are stored as `{base, limit (inclusive last byte)}`, so
  a window can cover the whole space and no `base + size` can overflow.  (Mutants `P01`, `P02`, `P20`.)
* **Boundary-spanning is denied by policy**, even when both adjacent windows would allow the access, because containment is
  tested against *one* window.  Software must split transfers per window (the CloudDMA page-split discipline).  Tests:
  `P3 spans window0 -> window1`, `starts one byte below`, `ends one byte past`, `one byte longer`.
* **Devices cannot be reached through memory windows.**  The checker derives device membership from the address with the same
  base/mask decode as the generated Albion map (`SF_CIT_DEV_*_DEFAULT`, verified against `sf_albion_memmap_pkg` by
  `tb_citadel_pkg`).  A range touching a device is checked only against device permissions (mutant `P17`).  A range
  touching two devices, or straddling a device edge, is `NOMAP` (mutant `P05`).
* **Attributes are claims, not rights.**  `priv` and `secure` are honoured only up to the domain's enrolled capability
  (`slot_priv` / `slot_secure`, settable only by ROOT at enrolment); a device flagged priv-only / secure-only additionally needs the
  matching claim.  (Mutants `P09`, `P14`.)
* **Queues**: class `QUEUE` ignores address and length; a held queue (`qhold`) is refused (mutant `P12`).
* **Lockdown**: in the safe state only verified ROOT / MGMT are served (they are needed for recovery).  DFT access exempts nobody.
* **Slot output**: `slot_vld_o` is true only when the domain is *known and bound*; attribution (per-domain counters) uses
  it, so a spoof is never charged to the victim.

## 5. Parameters

`NDOM` slots, `NW` windows per domain, `NP` ports, `NDEV` devices, `NQ` queues, `AW` ≤ 64, `LEN_W` ≤ 64; device map as base/mask
vectors with per-device priv / secure flags.  Non-power-of-two counts and `AW < LEN_W` are supported and tested.

## 6. Formal statement (see `07_VERIFICATION.md`)

For **every** table state and request (state is a free input): `reason_o`/`status_o` equal an independent priority reference
(exact 130-bit arithmetic), `permit_o` equals a priority-free predicate ("there is a slot that …"), and the named corollaries hold:
no wrap / zero length, wholly-inside-one-window, device-edge denial, devices not reachable via windows, domain context verified
and bound, ACTIVE only, lockdown, DFT, isolation, queue hold, bounded priv/secure claims, explicit denials.  Proved unbounded
at AW = 16, 64 (LEN_W = 32), a non-power-of-two point, and a `LEN_W > AW` point.
