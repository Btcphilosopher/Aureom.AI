# 04 — Enforcement: check points, integration rules, bypass prevention

Citadel **decides**; a *check point* **enforces**.  A check point presents the request on a `chk_*` port of
`sf_citadel_security` (one port per master) and must honour `chk_permit_o` **before any memory or device side effect**.
`sf_citadel_gate` is the ready-made check point for ALP data ports.

## 1. The check points the brief asks for

| Check point | Where it attaches | Class / fields |
|---|---|---|
| **Host DMA** | each DMA descriptor segment, before the descriptor fetch and before every data read / write (a *read* of MMIO has side effects too) | `ADDR`, `{dom = descriptor owner, op, addr, len = segment length}`; the DMA must **split segments so none crosses a window** |
| **Meridian transactions** | `sf_citadel_gate` in front of each master port of the fabric | `ADDR`, one 16-byte beat per ALP request (`len = 16`) |
| **Accelerator requests** | the accelerator's ALP master port (gate) and its command queue (`QUEUE`, its queue number) | `ADDR` + `QUEUE` |
| **Virtual-device descriptors** | the virtqueue (`QUEUE` class, queue number) *and* every descriptor buffer (`ADDR`, its own `len`) | `QUEUE`, `ADDR` |
| **Peripheral register access** | each MMIO access of a master | `ADDR`; the device is **derived from the address** by the checker (not supplied by the master), so a master cannot name a device it is not allowed to use |

### Check-port protocol (`chk_*`)

```
chk_valid_i[p]   a request is presented (may be held for several cycles)
chk_commit_i[p]  the verdict is consumed THIS cycle -- pulse it EXACTLY ONCE per request
chk_dom/op/attr/addr/len/cls/idx_i[p]
chk_permit_o[p]  chk_status_o[p]  chk_reason_o[p]      (combinational, same cycle)
```

`chk_commit_i` exists so the audit counters count a **request**, not a number of held cycles (a gate that holds a denied request
for 100 cycles still records one violation; proven by the system test `P5k` and mutants `S06`, `G05`).  Several ports
denying in the **same cycle** are all counted (`P5k`, mutant `S11`).

## 2. `sf_citadel_gate` — the ALP check point

```
master ──m_req──► [ hold register ] ──t_req (only if PERMIT, bit-for-bit unchanged)──► target
                        │  chk_* fields come from the HELD request
                        └─► deny: explicit error response on m_rsp (status of the verdict, tag echoed, data = 0)
target ──t_rsp──► m_rsp   (a deny response waits until every earlier forwarded request has been answered)
```

Proved (`fv_cit_gate`, unbounded; the verdict is a *free input that may change every cycle*):

* nothing is presented to the target unless the verdict taken in the request's **first** evaluation cycle was PERMIT;
* the presented request is the accepted request, bit for bit; valid and payload are stable until accepted (ALP-REQ-02);
* a denied request gets exactly **one** explicit error response (status ≠ OKAY, tag echoed, data zero, `last = 1`), **after**
  all earlier forwarded requests completed (ALP-ORD-01); the outstanding counter equals *forwarded − answered* and never wraps
  (a full counter stalls, it does not deny); an orphan target response is drained, flagged (`rsp_orphan_o`) and **never forwarded**;
* after reset nothing is presented, nothing is outstanding;
* **flush** (`flush_i`, wired to `port_isol_o[p]`): while the port is isolated and its engine in reset nothing is presented and no
  target response is forwarded; the outstanding count is cleared afterwards (the engine's reset drops what it was serving, late
  responses are drained as orphans); a held request that had not been forwarded is **cancelled** — never forwarded, answered once
  with `SF_ST_CANCELLED` if it had been permitted (its explicit error otherwise) — and the cancellation is latched, so it cannot
  reappear when the flush ends.  Valid / payload stability (ALP-REQ-02) holds except across a flush, which is the downstream reset
  event (ALP-RST-02).  Without this, an engine that never answers would leave every later denied request without its error
  response (finding of the independent review, reproduced, fixed; mutants `G12`–`G16`).

The latch of the verdict is what makes a table update safe: a policy change while a request is held cannot withdraw a `valid` the
target has already seen.  The change applies to the next request (§7 of `03`).

**Known limitation (assumption A-TGT).**  A request that is already permitted and *presented but not yet accepted* by a stalled target
stays presented after a quarantine, a lock-down or a revocation: its delay is bounded only by the target's own acceptance.  The only
event that withdraws it is the flush above (port isolation + engine reset).  Withdrawing a `valid` on any policy change would break
ALP-REQ-02 for every target, so the gate does not.  If the target can stall without bound, quiesce first (R9) or reset the engine.

### "Denied writes cause no destination update"

The destination is reachable **only** through `t_req_*`; `t_req_valid_o` implies a first-cycle PERMIT and the payload is the
accepted one (proved).  Therefore a denied write cannot reach the destination.  This is a proof about the gate plus an
**integration obligation** (§3, R1): the target must have no other path from the master.

## 3. Integration rules (each one is something Citadel cannot verify from inside)

| # | Rule | Why |
|---|---|---|
| **R1** | Every master reaches memory / devices **only** through its check point.  No second port, no side-band, no debug master on the same fabric without its own check point. | "Do not allow a master to bypass the policy engine through an alternate port." The gate has one downstream port; the rest is wiring. |
| **R2** | `src` is fixed per `chk_*` port (instance index).  One physical master per check port; two masters may share a check port only if they are bound to the same slots. | The domain label is attacker-controlled; the port is the anchor. |
| **R3** | `chk_reason_o` goes to **privileged audit only**, never to a requester. | It would re-create the layout oracle. |
| **R4** | Present *before* the descriptor fetch, *before* each read and each write; honour permit before issuing the bus request. | Reads of MMIO have side effects. |
| **R5** | Split transfers so no segment crosses a window or a device edge. | Boundary-spanning is denied by design. |
| **R6** | The command port and the telemetry port are physically reachable **only** from the management plane; tie `cfg_en_i` to the secure-boot gate (or to 1 and accept "unauthenticated", see `06`). | Privilege on these ports is a label; physical exclusivity is the control. |
| **R7** | Drive `dft_active_i` from the test-mode controller; the production lifecycle must disable test / debug access (TestCore's unlock token is an interlock, **not security**). | MBIST / JTAG is a path to memory that no master-port policy can see. |
| **R8** | One reset for Citadel and the engines it contains (ALP-RST-01), released synchronously (`sf_albion_reset_sync`, ALP-RST-03). | State survival across reset must not differ between blocks. |
| **R9** | Quiesce a master before revoking its domain (suspend, drain, then revoke). | A forwarded request completes (§7 of `03`). |
| **R10** | Wire `abort_valid_o/abort_mask_o` and `eng_rst_o[p]` into the queues / engines, and `eng_rst_done_i[p]` back (**not** a signal that is permanently high: a done already high in the reset-request cycle is ignored, one later is honoured); wire `port_isol_o[p]` to the gate's `flush_i`. The engine must honour them. | Containment is only as real as the actuator. |
| **R11** | Wire `zero_valid_o/zero_mask_o/zero_all_o` to the crypto adapter and the adapter's `key_zero_o` to the engine's key store. | Key hygiene (see `06`). |
| **R12** | Event sources are *pulses*; level signals (memory-test status, thermal) are edge-detected by `LEVEL_MASK`. | Counting semantics. |
| **R13** | A target must honour ALP alignment (`ALIGN_ERR`) and touch only `[addr, addr + 15]`; the gate checks that range and does not itself enforce alignment. | A target that aligned *down* instead of refusing would reach below the checked window (assumption A-TGT). |
| **R14** | `tel_src_i` identifies the physical telemetry source port; the management plane must arrive on a port listed in `TEL_PRIV_PORTS` (default: port 0) and tenant-facing telemetry on other ports. | Privileged telemetry is not granted on the ROOT / MGMT label alone. |

## 4. Meridian (P83) mapping — **not built, not tested**

Meridian's reference Citadel exposes, per master port: `cit_req_valid/ready`, `cit_req_dom[3]`, `cit_req_priv`, `cit_req_write`,
`cit_req_addr[32]` → `cit_rsp_valid/ok/fault`.  A thin adapter would present
`{dom = ALP domain id, op = write ? WRITE : READ, attr = priv << 2, addr = zero-extended, len = beat bytes, cls = ADDR}` on
`chk_*` and map the reason to Meridian's faults: `BAD_DOM / DOM_STATE → F_DOMAIN`, `PRIV → F_PRIV`, `PERM / DEV → F_PERM`,
`NOMAP / OVERFLOW / BAD_LEN → F_NOMAP`.  Meridian's fail-closed behaviour on a silent checker is kept by Citadel's
combinational verdict (it cannot be silent).  This adapter was **not written or run** against Meridian's RTL.

## 5. CloudDMA (P64) mapping — **not built, not tested**

`sfdma_perm_checker` clients present `{domain, asid, write, addr, bytes}` and expect `{ok, fault, pa}`.  Citadel returns permit /
reason and does **no translation**: an IOMMU stays in front of (or beside) it, and Citadel must check the **translated physical**
address.  CloudDMA's local rules (length ≤ 4096, no 4 KiB crossing, no wrap) remain advisable *in addition*; Citadel's rules are the
authority on windows, devices and domains.
