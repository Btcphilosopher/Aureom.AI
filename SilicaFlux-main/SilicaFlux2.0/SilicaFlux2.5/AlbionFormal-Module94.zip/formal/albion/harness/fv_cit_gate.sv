// =============================================================================
// AlbionFormal harness :: sf_citadel_gate  (Citadel ALP enforcement check point)   -- area "Security"
//
// DUT      rtl_under_test/citadel/rtl/albion/sf_citadel_gate.sv        (DomainGuard mapping: see docs/areas/Security.md)
// SPEC     DUT header comment, docs/citadel/04_ENFORCEMENT.md section 2/3, ALP rules quoted in the header (ALP-REQ-02, ...)
//
// The verdict inputs (chk_permit_i / chk_status_i) are FREE inputs that may change in EVERY cycle: every property holds
// for any policy behaviour, including a table update while a request is held.  The master is completely free
// (no stability assumption: the gate samples the payload only at acceptance).
//
// ASSUME-SET  ENV-RST-ANY + ENV-SEC-GATE-V1 (+ ENV-SEC-GATE-T1/T2 when TGT_OK = 1)
//   ENV-SEC-GATE-V1  chk_permit_i == (chk_status_i == OKAY).  Discharged by SEC-PERM-* a_permit_iff_okay (proved for the real checker).
//   ENV-SEC-GATE-T1  (TGT_OK=1) the target answers only requests it has been given (one response per forwarded request;
//                    a response may still arrive after a flush: the gate drains it as an orphan)         [ALP-RSP-01]
//   ENV-SEC-GATE-T2  (TGT_OK=1) a presented target response stays valid, payload unchanged, until accepted     [ALP-RSP-02]
//   TGT_OK = 0: the target is completely unconstrained (it may answer unprompted): strongest, used for all properties that
//   do not need T1/T2.
//
// REFERENCE MODEL.  The `s_*` registers transcribe the documented operation (hold register, verdict LATCHED in the first
// evaluation cycle, flush cancels the held request for good, outstanding count) from the PORT-LEVEL events only (handshakes
// observed on the DUT's ports).  Spec-level assertions are stated on that model; a_*_model assertions check the DUT against it.
// Bit-slice abstraction: payload equality is checked for one solver-chosen bit (* anyconst *); a violation in ANY bit is found.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_cit_gate #(
  parameter OUT_W   = 3,
  parameter TGT_OK  = 0,
  parameter ALB_SEL = 0
) (
  input wire         clk_i,
  input wire         rst_ni,
  input wire         m_req_valid_i,
  input wire [235:0] m_req_i,
  input wire         m_rsp_ready_i,
  input wire         t_req_ready_i,
  input wire         t_rsp_valid_i,
  input wire [147:0] t_rsp_i,
  input wire         flush_i,
  input wire         chk_permit_i,
  input wire [3:0]   chk_status_i
);
  wire          m_req_ready_o, m_rsp_valid_o, t_req_valid_o, t_rsp_ready_o, chk_valid_o, chk_commit_o, rsp_orphan_o;
  wire [147:0]  m_rsp_o;
  wire [235:0]  t_req_o;
  wire [7:0]    chk_dom_o, chk_attr_o, chk_idx_o;
  wire [3:0]    chk_op_o;
  wire [63:0]   chk_addr_o;
  wire [31:0]   chk_len_o;
  wire [1:0]    chk_cls_o;
  wire [OUT_W-1:0] outstanding_o;

  sf_citadel_gate #(.OUT_W(OUT_W)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .m_req_valid_i(m_req_valid_i), .m_req_ready_o(m_req_ready_o), .m_req_i(m_req_i),
    .m_rsp_valid_o(m_rsp_valid_o), .m_rsp_ready_i(m_rsp_ready_i), .m_rsp_o(m_rsp_o),
    .t_req_valid_o(t_req_valid_o), .t_req_ready_i(t_req_ready_i), .t_req_o(t_req_o),
    .t_rsp_valid_i(t_rsp_valid_i), .t_rsp_ready_o(t_rsp_ready_o), .t_rsp_i(t_rsp_i),
    .flush_i(flush_i),
    .chk_valid_o(chk_valid_o), .chk_dom_o(chk_dom_o), .chk_op_o(chk_op_o), .chk_attr_o(chk_attr_o),
    .chk_addr_o(chk_addr_o), .chk_len_o(chk_len_o), .chk_cls_o(chk_cls_o), .chk_idx_o(chk_idx_o),
    .chk_commit_o(chk_commit_o), .chk_permit_i(chk_permit_i), .chk_status_i(chk_status_i),
    .outstanding_o(outstanding_o), .rsp_orphan_o(rsp_orphan_o));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk_i), .rst_n(rst_ni), .init_q(init_q));

  // ALP v1 field positions (sf_albion_pkg): REQ op[235:232] tag[231:224] dom[223:216] attr[215:208] addr[207:144] ...
  //                                          RSP tag[147:140] status[139:136] meta[135:128] data[127:0]
  localparam [3:0] OP_WRITE = 4'h2, ST_OKAY = 4'h0, ST_CANCELLED = 4'h9;

  // ------------------------------------------------------------------ bit-slice abstraction indices (universal)
  (* anyconst *) wire [7:0] bi;      // request payload bit      (< 236)
  (* anyconst *) wire [5:0] ai;      // address bit              (< 64)
  (* anyconst *) wire [7:0] ri;      // response payload bit     (< 148)
  wire bi_ok = (bi < 8'd236);
  wire ri_ok = (ri < 8'd148);
  wire t_bit   = bi_ok ? t_req_o[bi] : 1'b0;
  wire m_bit   = bi_ok ? m_req_i[bi] : 1'b0;
  wire a_bit_c = chk_addr_o[ai];
  wire a_bit_m = m_req_i[144 + ai];
  wire r_bit_m = ri_ok ? m_rsp_o[ri] : 1'b0;
  wire r_bit_t = ri_ok ? t_rsp_i[ri] : 1'b0;

  // ------------------------------------------------------------------ reference model (port-level events only)
  reg                s_have, s_dec, s_permit, s_cc, s_isw, s_bit, s_abit;
  reg [3:0]          s_status, s_op;
  reg [7:0]          s_dom, s_tag, s_attr;
  reg [OUT_W-1:0]    s_out;
  wire s_out_zero = (s_out == {OUT_W{1'b0}});
  wire s_out_full = (s_out == {OUT_W{1'b1}});
  wire       s_basep = s_dec ? s_permit : chk_permit_i;
  wire [3:0] s_bases = s_dec ? s_status : chk_status_i;
  wire       s_vp    = s_basep && !flush_i;                              // verdict in force this cycle
  wire [3:0] s_vs    = (s_basep && flush_i) ? ST_CANCELLED : s_bases;
  wire       s_fwd   = t_req_valid_o && t_req_ready_i;                   // forwarded to the target
  wire       s_loc_valid = s_have && !s_vp && s_out_zero;                // an explicit error response is due
  wire       s_loc_done  = s_loc_valid && m_rsp_ready_i;
  wire       s_acc   = m_req_valid_i && m_req_ready_o;                   // request accepted into the hold register
  wire       s_taken = t_rsp_valid_i && t_rsp_ready_o && !s_out_zero && !flush_i;   // target response consumed by the master path

  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      s_have <= 1'b0; s_dec <= 1'b0; s_permit <= 1'b0; s_status <= 4'd0; s_cc <= 1'b0; s_isw <= 1'b0; s_bit <= 1'b0; s_abit <= 1'b0;
      s_op <= 4'd0; s_dom <= 8'd0; s_tag <= 8'd0; s_attr <= 8'd0; s_out <= {OUT_W{1'b0}};
    end else begin
      if (s_acc) begin
        s_have <= 1'b1; s_dec <= 1'b0; s_cc <= 1'b0;
        s_dom  <= m_req_i[223:216]; s_tag <= m_req_i[231:224]; s_op <= m_req_i[235:232]; s_attr <= m_req_i[215:208];
        s_isw  <= (m_req_i[235:232] == OP_WRITE); s_bit <= m_bit; s_abit <= a_bit_m;
      end else begin
        if (chk_commit_o) s_cc <= 1'b1;
        if (s_fwd || s_loc_done) begin s_have <= 1'b0; s_dec <= 1'b0; end
      end
      if (s_have && (flush_i || !s_dec) && !s_fwd && !s_loc_done) begin
        s_dec <= 1'b1; s_permit <= s_vp; s_status <= s_vs;
      end
      if (flush_i)                    s_out <= {OUT_W{1'b0}};
      else if (s_fwd && !s_taken)     s_out <= s_out + 1'b1;
      else if (!s_fwd && s_taken)     s_out <= s_out - 1'b1;
    end
  end

  // ------------------------------------------------------------------ history monitors
  reg p_thold, p_tbit, p_rhold, p_rbit, p_flush, p_thold2, p_tbit2;
  reg [OUT_W-1:0] tgt_out;                                     // target-side view: forwarded - answered (not cleared by flush)
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      p_thold <= 1'b0; p_tbit <= 1'b0; p_rhold <= 1'b0; p_rbit <= 1'b0; p_flush <= 1'b0; p_thold2 <= 1'b0; p_tbit2 <= 1'b0;
      tgt_out <= {OUT_W{1'b0}};
    end else begin
      p_thold <= t_req_valid_o && !t_req_ready_i && !flush_i;  p_tbit <= t_bit;
      p_rhold <= m_rsp_valid_o && !m_rsp_ready_i && !flush_i;  p_rbit <= r_bit_m;
      p_flush <= flush_i;
      p_thold2 <= t_rsp_valid_i && !t_rsp_ready_o;             p_tbit2 <= r_bit_t;
      if (s_fwd && !(t_rsp_valid_i && t_rsp_ready_o))        tgt_out <= tgt_out + 1'b1;
      else if (!s_fwd && (t_rsp_valid_i && t_rsp_ready_o))   tgt_out <= tgt_out - 1'b1;
    end
  end

  // ------------------------------------------------------------------ environment
  always @(*) begin
    `ALB_ASSUME(e_verdict_consistent, "ENV-SEC-GATE-V1 chk_permit_i == (chk_status_i == OKAY) (discharged by SEC-PERM a_permit_iff_okay)",
                chk_permit_i == (chk_status_i == ST_OKAY))
    if (TGT_OK != 0) begin
      `ALB_ASSUME(e_t_solicited, "ENV-SEC-GATE-T1 the target answers only requests it was given", `ALB_IMPL(t_rsp_valid_i, tgt_out != {OUT_W{1'b0}}))
      `ALB_ASSUME(e_t_hold,      "ENV-SEC-GATE-T2 a presented target response stays valid and unchanged until accepted",
                  `ALB_IMPL(p_thold2, t_rsp_valid_i && r_bit_t == p_tbit2))
    end
  end

  // ------------------------------------------------------------------ properties
  always @(*) begin
    // ---- denied requests cannot reach memory ---------------------------------------------------------------
    `ALB_ASSERT(1, a_deny_not_forwarded, "[04 s2 / G1] nothing is presented downstream unless the verdict taken in the request's FIRST evaluation cycle was PERMIT and flush_i is low",
                `ALB_IMPL(t_req_valid_o, s_have && s_vp))
    `ALB_ASSERT(2, a_fwd_payload_bit, "[04 s2 / G2] the presented request is bit-for-bit the accepted request (checked for a solver-chosen bit)",
                `ALB_IMPL(t_req_valid_o, t_bit == s_bit))
    `ALB_ASSERT(3, a_fwd_domain_id, "[04 s2] the domain field of the presented request equals the domain field of the accepted request",
                `ALB_IMPL(t_req_valid_o, t_req_o[223:216] == s_dom))
    // ---- permission checks cannot be bypassed: the checker sees the HELD request, never the live input --------
    `ALB_ASSERT(4, a_chk_domain_id, "[04 s2] the domain presented to the checker is the accepted request's domain (no time-of-check/time-of-use gap)",
                `ALB_IMPL(chk_valid_o, chk_dom_o == s_dom))
    `ALB_ASSERT(5, a_chk_fields, "[04 s2] op, attr and an address bit presented to the checker are the accepted request's",
                `ALB_IMPL(chk_valid_o, chk_op_o == s_op && chk_attr_o == s_attr && a_bit_c == s_abit))
    `ALB_ASSERT(6, a_chk_const, "[04 s2] the checker is asked for ADDR class, one 16-byte beat, idx 0",
                `ALB_IMPL(chk_valid_o, chk_cls_o == 2'd0 && chk_len_o == 32'd16 && chk_idx_o == 8'd0))
    `ALB_ASSERT(7, a_chk_valid_tracks, "chk_valid_o == a request is held (reference model)", chk_valid_o == s_have)
    `ALB_ASSERT(8, a_commit_first_cycle, "chk_commit_o pulses exactly in the first evaluation cycle of a held request", chk_commit_o == (s_have && !s_dec))
    `ALB_ASSERT(9, a_commit_at_most_once, "[G5] at most one commit per request", `ALB_IMPL(chk_commit_o, !s_cc))
    `ALB_ASSERT(10, a_commit_before_leave, "[G5] a request never leaves the hold register without having been committed",
                `ALB_IMPL(s_have && (s_fwd || s_loc_done), s_cc || chk_commit_o))
    // ---- explicit error response for a denied request -----------------------------------------------------------
    `ALB_ASSERT(11, a_deny_response_due, "[G3] a denied request with nothing outstanding is answered: m_rsp_valid_o",
                `ALB_IMPL(s_loc_valid, m_rsp_valid_o))
    `ALB_ASSERT(12, a_deny_status_explicit, "[G3 / ALP-RSP-05] the error response carries the verdict status and it is not OKAY",
                `ALB_IMPL(s_loc_valid, m_rsp_o[139:136] == s_vs && m_rsp_o[139:136] != ST_OKAY))
    `ALB_ASSERT(13, a_deny_tag_echo, "[G3] the error response echoes the request tag", `ALB_IMPL(s_loc_valid, m_rsp_o[147:140] == s_tag))
    `ALB_ASSERT(14, a_deny_data_zero, "[G3 / ALP-RSP-05] the error response data is all-zero", `ALB_IMPL(s_loc_valid, m_rsp_o[127:0] == 128'd0))
    `ALB_ASSERT(15, a_deny_meta, "[G3] the error response is last=1, is_write echoes the request, reserved/poison/corrected = 0",
                `ALB_IMPL(s_loc_valid, m_rsp_o[135:128] == {4'b0000, 1'b0, 1'b0, 1'b1, s_isw}))
    `ALB_ASSERT(16, a_deny_order, "[G3 / ORD-01] while forwarded requests are outstanding NO error response is synthesised: the response is the target's",
                `ALB_IMPL(s_have && !s_vp && !s_out_zero, m_rsp_valid_o == (t_rsp_valid_i && !flush_i) && (!m_rsp_valid_o || m_rsp_o == t_rsp_i)))
    `ALB_ASSERT(17, a_rsp_sourced, "every master response is either the due local error response or a consumed target response (no phantom / duplicate response)",
                `ALB_IMPL(m_rsp_valid_o, s_loc_valid || (t_rsp_valid_i && !s_out_zero && !flush_i)))
    `ALB_ASSERT(18, a_pass_through, "a target response passes through unchanged and t_rsp_ready_o routes the master's ready (or drains)",
                `ALB_IMPL(m_rsp_valid_o && !s_loc_valid, m_rsp_o == t_rsp_i) &&
                (t_rsp_ready_o == ((s_out_zero || flush_i) ? 1'b1 : (!s_loc_valid && m_rsp_ready_i))))
    `ALB_ASSERT(19, a_req_ready_model, "m_req_ready_o == (no request held) || forwarded || error response completing", m_req_ready_o == (!s_have || s_fwd || s_loc_done))
    // ---- orphan target responses ------------------------------------------------------------------------------
    `ALB_ASSERT(20, a_orphan_not_forwarded, "[G8] a target response with nothing outstanding is never forwarded to the master and is flagged",
                `ALB_IMPL(t_rsp_valid_i && s_out_zero && !s_loc_valid, !m_rsp_valid_o) && (rsp_orphan_o == (t_rsp_valid_i && s_out_zero)))
    // ---- outstanding accounting --------------------------------------------------------------------------------
    `ALB_ASSERT(21, a_outstanding_exact, "[G6] outstanding_o == forwarded - answered (flush clears)", outstanding_o == s_out)
    `ALB_ASSERT(22, a_no_forward_when_full, "[G6] a full counter stalls forwarding, it never wraps", `ALB_IMPL(s_out_full, !t_req_valid_o))
    // ---- reset ---------------------------------------------------------------------------------------------------
    `ALB_ASSERT(23, a_reset_clean, "[G7] in reset: nothing presented, no response, nothing outstanding, no request held",
                `ALB_IMPL(!rst_ni, !t_req_valid_o && !m_rsp_valid_o && outstanding_o == {OUT_W{1'b0}} && !chk_valid_o && !chk_commit_o))
    // ---- flush ---------------------------------------------------------------------------------------------------
    `ALB_ASSERT(24, a_flush_nothing_presented, "[G9] flush: nothing is presented, the downstream is drained, no target response is forwarded",
                `ALB_IMPL(flush_i, !t_req_valid_o && t_rsp_ready_o && (!m_rsp_valid_o || s_loc_valid)))
    `ALB_ASSERT(25, a_flush_clears_outstanding, "[G9] the outstanding count is zero in the cycle after a flush", `ALB_IMPL(p_flush, outstanding_o == {OUT_W{1'b0}}))
    // ---- handshake stability (ALP-REQ-02 / RSP-02) ---------------------------------------------------------------
    `ALB_ASSERT(26, a_t_req_stable, "[ALP-REQ-02 / G4] a request presented and not accepted stays presented, unchanged, (except across a flush)",
                `ALB_IMPL(p_thold && !flush_i, t_req_valid_o && t_bit == p_tbit))
    if (TGT_OK != 0) begin
      `ALB_ASSERT(27, a_m_rsp_stable, "[ALP-RSP-02 / G4] (target obeys T1/T2) a master response presented and not accepted stays presented, unchanged",
                  `ALB_IMPL(p_rhold && !flush_i, m_rsp_valid_o && r_bit_m == p_rbit))
    end
  end

  // ------------------------------------------------------------------ vacuity / reachability covers
  always @(*) begin
    `ALB_COVER(90, c_permit_forward, "a permitted request is forwarded and accepted by the target", s_fwd && s_have)
    `ALB_COVER(91, c_deny_response,  "a denied request receives its error response (handshake)", s_loc_done)
    `ALB_COVER(92, c_target_stall,   "a permitted request is presented and the target stalls it", t_req_valid_o && !t_req_ready_i)
    `ALB_COVER(93, c_verdict_flips,  "the live verdict differs from the latched one while a request is held (the free verdict is exercised)", s_have && s_dec && (chk_permit_i != s_permit))
    `ALB_COVER(94, c_flush_cancel,   "flush cancels a held, previously permitted request (CANCELLED response due)", s_loc_valid && s_dec && s_status == ST_CANCELLED)
    `ALB_COVER(95, c_deny_waits,     "a denied request waits for outstanding forwarded requests", s_have && !s_vp && !s_out_zero)
    `ALB_COVER(96, c_orphan,         "an orphan target response is drained", rsp_orphan_o && t_rsp_valid_i)
    `ALB_COVER(97, c_counter_full,   "the outstanding counter is full while a permitted request is held", s_out_full && s_have && s_vp)
    `ALB_COVER(98, c_pass_response,  "a target response is passed to the master", m_rsp_valid_o && !s_loc_valid && m_rsp_ready_i)
    `ALB_COVER(99, c_back_to_back,   "a request is accepted in the cycle the previous one is forwarded", s_acc && s_have)
  end
endmodule
`default_nettype wire
