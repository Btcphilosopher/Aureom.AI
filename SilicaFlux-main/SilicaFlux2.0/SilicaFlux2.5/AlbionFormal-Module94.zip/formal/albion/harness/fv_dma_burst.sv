// =============================================================================
// AlbionFormal harness :: dma_burst_engine  (buffered engine: read issuer -> dma_fifo -> write issuer)
//
// DUT      rtl_under_test/datafabric/rtl/dma/dma_burst_engine.sv  (+ dma_fifo.sv, dma_validate.sv)
// SPEC     docs/datafabric/DMA.md section 5 and the DUT header (credit, phases, drain, accounting), SFB2 R2/R4/R5/R8
//
// ASSUME-SET (job "assumptions")
//   ENV-RST-ANY    reset in step 0, and at any later step (SFB2 R11)
//   ENV-SFB-R4/R5/R8  per port: held response stable / response only for an earlier-accepted outstanding request (in order,
//                  at most MAX_OUT in flight is the DUT's own obligation) / error => rdata == 0
//   ENV-DMA-SMALL  (SMALL=1) src,dst < 2^AB and len <= 2^AB (32-bit counters cannot be closed by PDR at full width; the proof
//                  is then CONDITIONAL on narrow values)
//   ENV-DMA-TAG    the tagged beat index of the FIFO data-integrity monitor is < 2^TAGW (anyconst, small)
//   `start`, `abort`, `cfg_*`, `req_ready`, `rsp_rdata` are free (abort/start at any time).
// No latency/fairness assumption is used: nothing here claims that a transfer ever completes (c_done only shows that it CAN).
//
// GHOST MODEL: from the ports only -- descriptor captured at `go`, accepted-request counters per direction, OK-response counters,
// a "stop" latch (error response or abort seen), first-error latches, byte-accurate bytes-done, and a tagged-beat data monitor.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_dma_burst #(
  parameter ALB_SEL      = 0,
  parameter DW           = 16,
  parameter MAX_LEN_LOG2 = 4,
  parameter FIFO_DEPTH   = 4,
  parameter BURST        = 2,
  parameter DUAL_PORT    = 0,
  parameter MAX_OUT      = 2,
  parameter SMALL        = 1,
  parameter AB           = 6,
  parameter TAGW         = 3
) (
  input wire                    clk,
  input wire                    rst_n,
  input wire                    start,
  input wire                    abort,
  input wire [31:0]             cfg_src,
  input wire [31:0]             cfg_dst,
  input wire [31:0]             cfg_len,
  input wire [((DUAL_PORT != 0) ? 2 : 1)-1:0]               req_ready,
  input wire [((DUAL_PORT != 0) ? 2 : 1)-1:0]               rsp_valid,
  input wire [((DUAL_PORT != 0) ? 2 : 1)*DW-1:0]            rsp_rdata,
  input wire [((DUAL_PORT != 0) ? 2 : 1)-1:0]               rsp_error
);
  localparam SB  = DW / 8;
  localparam OFF = $clog2(SB);
  localparam NP  = (DUAL_PORT != 0) ? 2 : 1;
  localparam WP  = NP - 1;

  // ------------------------------------------------------------------ DUT
  wire              busy, done, fail, ev_stall;
  wire [3:0]        err_code;
  wire [31:0]       err_addr, bytes_done;
  wire [2:0]        state;
  wire [7:0]        fifo_level;
  wire [NP-1:0]     req_valid, req_write, rsp_ready;
  wire [NP*32-1:0]  req_addr;
  wire [NP*DW-1:0]  req_wdata;
  wire [NP*SB-1:0]  req_wstrb;
  dma_burst_engine #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2), .FIFO_DEPTH(FIFO_DEPTH), .BURST(BURST), .DUAL_PORT(DUAL_PORT), .MAX_OUT(MAX_OUT)) dut (
    .clk(clk), .rst_n(rst_n), .start(start), .abort(abort), .cfg_src(cfg_src), .cfg_dst(cfg_dst), .cfg_len(cfg_len),
    .busy(busy), .done(done), .fail(fail), .err_code(err_code), .err_addr(err_addr), .bytes_done(bytes_done), .state(state),
    .ev_stall(ev_stall), .fifo_level(fifo_level),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr), .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // ------------------------------------------------------------------ SFB2 monitors, one per port
  wire [NP-1:0] m_stable, m_acc, m_held, r_stable, r_sol, r_err, r_hs;
  wire [3*NP-1:0] outst;
  genvar gp;
  generate for (gp = 0; gp < NP; gp = gp + 1) begin : g_mon
    albion_sfb_req_mon #(.AW(32), .DW(DW)) m_req (
      .clk(clk), .rst_n(rst_n), .valid(req_valid[gp]), .ready(req_ready[gp]), .write(req_write[gp]), .addr(req_addr[gp*32 +: 32]),
      .wdata(req_wdata[gp*DW +: DW]), .wstrb(req_wstrb[gp*SB +: SB]), .stable_ok(m_stable[gp]), .accepted(m_acc[gp]), .held(m_held[gp]));
    albion_sfb_rsp_mon #(.DW(DW), .OW(3)) m_rsp (
      .clk(clk), .rst_n(rst_n), .req_acc(m_acc[gp]), .rsp_valid(rsp_valid[gp]), .rsp_ready(rsp_ready[gp]), .rsp_rdata(rsp_rdata[gp*DW +: DW]),
      .rsp_error(rsp_error[gp]), .stable_ok(r_stable[gp]), .solicited_ok(r_sol[gp]), .errdata_ok(r_err[gp]),
      .outstanding(outst[gp*3 +: 3]), .rsp_hs(r_hs[gp]));
  end endgenerate

  // ------------------------------------------------------------------ environment
  always @(*) begin
    `ALB_ASSUME(e_rsp_stable,    "ENV-SFB-R4 held response stays valid and unchanged (all ports)", &r_stable)
    `ALB_ASSUME(e_rsp_solicited, "ENV-SFB-R5 response only for an earlier-accepted outstanding request (all ports)", &r_sol)
    `ALB_ASSUME(e_rsp_errdata,   "ENV-SFB-R8 rsp_error implies rsp_rdata == 0 (all ports)", &r_err)
    if (SMALL != 0) begin
      `ALB_ASSUME(e_small, "ENV-DMA-SMALL src,dst < 2^AB and len <= 2^AB", cfg_src < (32'd1 << AB) && cfg_dst < (32'd1 << AB) && cfg_len <= (32'd1 << AB))
    end
  end

  // ------------------------------------------------------------------ ghost model
  wire go = start && !busy;
  reg         g_started, g_stop, g_err, g_werr, g_abort_seen, g_go_prev, g_tag_valid, g_ph_q;
  reg [31:0]  g_src, g_dst, g_len, bd_prev;
  reg [33:0]  rd_acc, wr_acc, rd_good, wr_ok, wr_prefix, rd_rsp_cnt, wr_rsp_cnt;
  reg [4:0]   g_fifo5;                        // narrow occupancy ghost: good-read pushes - accepted-write pops (mod 32)
  reg         g_first_wr;
  reg [31:0]  g_first_addr;
  reg [3:0]   g_cnt_q;
  reg [DW-1:0] g_tag_data;
  (* anyconst *) wire [TAGW-1:0] kk;

  wire        ref_legal, rf_zero, rf_long, rf_salign, rf_dalign, rf_sovf, rf_dovf, rf_ovl;
  wire [3:0]  ref_code;
  albion_dma_ref_validate #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) u_ref (
    .src(g_src), .dst(g_dst), .len(g_len), .legal(ref_legal), .code(ref_code),
    .f_zero(rf_zero), .f_long(rf_long), .f_salign(rf_salign), .f_dalign(rf_dalign), .f_sovf(rf_sovf), .f_dovf(rf_dovf), .f_ovl(rf_ovl));

  wire [33:0] gs = {2'b0, g_src}, gd = {2'b0, g_dst}, gl = {2'b0, g_len};
  wire [33:0] g_src_end = gs + gl;
  wire [33:0] g_dst_end = gd + gl;
  wire [33:0] g_nb      = (gl + (SB - 1)) >> OFF;

  wire rd_acc_now = req_valid[0]  && req_ready[0]  && !req_write[0];
  wire wr_acc_now = req_valid[WP] && req_ready[WP] && req_write[WP];
  // responses classified by port (dual) or by the observed phase (single: the phase changes only when idle -- asserted below)
  wire in_run   = (state == 3'd2) || (state == 3'd4);
  wire ph_obs   = (state == 3'd4);
  wire rd_rsp_g = (DUAL_PORT != 0) ? r_hs[0]  : (r_hs[0] && !ph_obs);
  wire wr_rsp_g = (DUAL_PORT != 0) ? r_hs[WP] : (r_hs[0] &&  ph_obs);
  wire rd_rsp_err = rd_rsp_g && rsp_error[0];
  wire wr_rsp_err = wr_rsp_g && rsp_error[WP];
  wire rd_rsp_ok  = rd_rsp_g && !rsp_error[0];
  wire wr_rsp_ok  = wr_rsp_g && !rsp_error[WP];
  wire rd_good_now = rd_rsp_ok && !g_stop;                      // data pushed into the FIFO (before any stop condition)

  wire ph_chg  = (DUAL_PORT == 0) && in_run && (g_ph_q != ph_obs);
  wire [3:0] eff_cnt = ph_chg ? 4'd0 : g_cnt_q;
  wire [33:0] wk = {{(34-TAGW){1'b0}}, kk};

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      g_started <= 1'b0; g_stop <= 1'b0; g_err <= 1'b0; g_werr <= 1'b0; g_abort_seen <= 1'b0; g_go_prev <= 1'b0;
      g_tag_valid <= 1'b0; g_ph_q <= 1'b0; g_cnt_q <= 4'd0; g_tag_data <= {DW{1'b0}};
      g_src <= 32'd0; g_dst <= 32'd0; g_len <= 32'd0; bd_prev <= 32'd0;
      rd_acc <= 34'd0; wr_acc <= 34'd0; rd_good <= 34'd0; wr_ok <= 34'd0; wr_prefix <= 34'd0; rd_rsp_cnt <= 34'd0; wr_rsp_cnt <= 34'd0;
      g_first_wr <= 1'b0; g_first_addr <= 32'd0; g_fifo5 <= 5'd0;
    end else begin
      g_go_prev <= go;
      bd_prev   <= bytes_done;
      g_ph_q    <= in_run ? ph_obs : 1'b0;
      g_cnt_q   <= in_run ? (eff_cnt + {3'b0, m_acc[0]}) : 4'd0;
      if (!busy)       g_abort_seen <= 1'b0;
      else if (abort)  g_abort_seen <= 1'b1;
      if (go) begin
        g_started <= 1'b1; g_src <= cfg_src; g_dst <= cfg_dst; g_len <= cfg_len;
        g_stop <= 1'b0; g_err <= 1'b0; g_werr <= 1'b0; g_tag_valid <= 1'b0; g_fifo5 <= 5'd0;
        rd_acc <= 34'd0; wr_acc <= 34'd0; rd_good <= 34'd0; wr_ok <= 34'd0; wr_prefix <= 34'd0; rd_rsp_cnt <= 34'd0; wr_rsp_cnt <= 34'd0;
      end else begin
        if (rd_rsp_g) rd_rsp_cnt <= rd_rsp_cnt + 34'd1;
        if (wr_rsp_g) wr_rsp_cnt <= wr_rsp_cnt + 34'd1;
        if (!g_err && (rd_rsp_err || wr_rsp_err)) begin           // first error wins; a read error wins a same-cycle tie
          g_first_wr   <= !rd_rsp_err;
          g_first_addr <= rd_rsp_err ? (g_src + {rd_rsp_cnt[29:0], {OFF{1'b0}}}) : (g_dst + {wr_rsp_cnt[29:0], {OFF{1'b0}}});
        end
        g_fifo5 <= g_fifo5 + {4'd0, rd_good_now} - {4'd0, wr_acc_now};
        if (rd_acc_now) rd_acc <= rd_acc + 34'd1;
        if (wr_acc_now) wr_acc <= wr_acc + 34'd1;
        if (rd_good_now) begin
          rd_good <= rd_good + 34'd1;
          if (rd_good == wk) begin g_tag_valid <= 1'b1; g_tag_data <= rsp_rdata[DW-1:0]; end
        end
        if (wr_rsp_ok) wr_ok <= wr_ok + 34'd1;
        if (wr_rsp_ok && !g_werr) wr_prefix <= wr_prefix + 34'd1;
        if (rd_rsp_err || wr_rsp_err) g_err <= 1'b1;
        if (wr_rsp_err) g_werr <= 1'b1;
        if ((rd_rsp_err || wr_rsp_err) || (abort && busy)) g_stop <= 1'b1;
      end
    end
  end

  // byte-accurate strobe checks of the presented write
  reg strb_exact_ok, strb_inside_ok;
  wire [33:0] wa = {2'b0, req_addr[WP*32 +: 32]};
  wire [SB-1:0] wstrb = req_wstrb[WP*SB +: SB];
  integer b;
  always @(*) begin
    strb_exact_ok = 1'b1; strb_inside_ok = 1'b1;
    for (b = 0; b < SB; b = b + 1) begin
      if (wstrb[b] != ((wa + b) < g_dst_end)) strb_exact_ok = 1'b0;
      if (wstrb[b] && !(((wa + b) < g_dst_end) && ((wa + b) >= gd))) strb_inside_ok = 1'b0;
    end
  end
  wire        rd_req   = req_valid[0]  && !req_write[0];
  wire        wr_req   = req_valid[WP] &&  req_write[WP];
  wire [33:0] ra       = {2'b0, req_addr[31:0]};
  wire        rd_first = rd_req && !m_held[0];
  wire        wr_first = wr_req && !m_held[WP];
  wire [33:0] exp_bytes = (wr_prefix == g_nb) ? gl : (wr_prefix << OFF);
  wire [2:0]  out0 = outst[2:0];
  wire [2:0]  outw = outst[3*WP +: 3];
  wire        any_req  = |req_valid;
  wire        any_out  = (out0 != 3'd0) || (outw != 3'd0);

  // ------------------------------------------------------------------ properties
  always @(*) begin
    // -- FIFO and outstanding bounds
    `ALB_ASSERT(1,  a_fifo_le_depth,     "[DMA.md 5] FIFO occupancy never exceeds FIFO_DEPTH (no overflow) and never underflows (underflow wraps above DEPTH)", fifo_level <= FIFO_DEPTH)
    `ALB_ASSERT(2,  a_credit,            "[DMA.md 5] credit: reads issued - writes issued <= FIFO_DEPTH (a read response can never find the FIFO full)", rd_acc <= wr_acc + FIFO_DEPTH)
    `ALB_ASSERT(3,  a_fifo_occupancy,    "[DMA.md 5] FIFO occupancy == good read responses - accepted writes while a transfer runs (exact accounting, no loss/duplication; narrow 5-bit ghost)", !busy || fifo_level[4:0] == g_fifo5)
    `ALB_ASSERT(4,  a_outstanding_bound, "[DMA.md 5] outstanding transactions per port never exceed MAX_OUT", out0 <= MAX_OUT && outw <= MAX_OUT)
    `ALB_ASSERT(5,  a_rsp_always_taken,  "[DMA.md 5] rsp_ready is constant 1: every response is consumed in its arrival cycle", &rsp_ready)
    // -- burst / phase (single port)
    if (DUAL_PORT == 0) begin
      `ALB_ASSERT(6,  a_burst_le_burst,    "[DMA.md 5] a read or write phase issues at most BURST back-to-back transactions", {2'b0, eff_cnt} + {5'b0, m_acc[0]} <= BURST)
      `ALB_ASSERT(7,  a_phase_switch_idle, "[DMA.md 5/DUT header] the phase changes only when the port is idle (nothing presented, nothing outstanding)", !ph_chg || (!req_valid[0] && out0 == 3'd0))
    end else begin
      `ALB_ASSERT(8,  a_dual_port_types,   "[DMA.md 5] dual port: port 0 only reads, port 1 only writes", (!req_valid[0] || !req_write[0]) && (!req_valid[1] || req_write[1]))
    end
    // -- request addressing: exactly once, in order, inside the validated ranges (DMA.md 2)
    `ALB_ASSERT(9,  a_no_req_illegal,    "[DMA.md 2] a request is only presented for a descriptor that passes validation (illegal => no bus access, no memory mutation)", !any_req || (g_started && ref_legal))
    `ALB_ASSERT(10, a_rd_addr_seq,       "each read addr == src + beat*DW/8 for the next un-issued beat: no duplicate, skipped or reordered read", !rd_req || (ra == gs + (rd_acc << OFF) && rd_acc < g_nb))
    `ALB_ASSERT(11, a_wr_addr_seq,       "each write addr == dst + beat*DW/8 for the next un-issued beat: no duplicate, skipped or reordered write", !wr_req || (wa == gd + (wr_acc << OFF) && wr_acc < g_nb))
    `ALB_ASSERT(12, a_rd_in_src_range,   "[DMA.md 2] every read address lies inside [src, src+len) and the word does not wrap past 2^32", !rd_req || (ra >= gs && ra < g_src_end && ra + SB <= 34'h1_0000_0000))
    `ALB_ASSERT(13, a_wr_in_dst_range,   "[DMA.md 2] every write address lies inside [dst, dst+len) and the word does not wrap past 2^32", !wr_req || (wa >= gd && wa < g_dst_end && wa + SB <= 34'h1_0000_0000))
    `ALB_ASSERT(14, a_wr_strb_exact,     "[DMA.md 2] write strobes are byte-exact: byte b written iff addr+b < dst+len", !wr_req || strb_exact_ok)
    `ALB_ASSERT(15, a_wr_strb_no_overrun,"[DMA.md 2] no strobed byte outside [dst, dst+len): bytes after the end are never modified", !wr_req || strb_inside_ok)
    `ALB_ASSERT(16, a_req_stable,        "[SFB2 R2] each presented request stays presented with an unchanged payload until accepted (every port)", &m_stable)
    // -- ordering / data
    `ALB_ASSERT(17, a_wr_le_good_reads,  "[DMA.md 5] writes never overtake good reads: accepted writes <= good read responses", wr_acc <= rd_good)
    `ALB_ASSERT(18, a_data_integrity,    "FIFO data path: the write of beat kk carries the data returned by the read of beat kk (tagged beat, any kk < 2^TAGW)", !(wr_req && wr_acc == wk) || (g_tag_valid && req_wdata[WP*DW +: DW] == g_tag_data))
    // -- errors / abort / drain (DUT header 'Errors / abort')
    `ALB_ASSERT(19, a_no_rd_after_error, "[DUT hdr] after any bus error no new READ is started", !(rd_first && g_err))
    `ALB_ASSERT(20, a_no_wr_after_werr,  "[DUT hdr] after a write error no new WRITE is started", !(wr_first && g_werr))
    `ALB_ASSERT(21, a_abort_no_new_req,  "[DMA.md 4/5] once an abort has been seen no new request is started on any port", !((rd_first || wr_first) && g_abort_seen))
    `ALB_ASSERT(22, a_end_drained,       "[DUT hdr] DONE/ERROR only after every outstanding response was drained and consumed and nothing is presented", !(done || fail) || (!any_req && !any_out))
    `ALB_ASSERT(23, a_fail_code_illegal, "[DMA.md 2] a descriptor failing validation ends in ERROR with exactly the documented first-failing-rule code", !(fail && g_started && !ref_legal) || err_code == ref_code)
    `ALB_ASSERT(24, a_fail_code_legal,   "[DMA.md 2/5] a legal descriptor never reports a validation code: only READ_BUS/WRITE_BUS/ABORTED", !(fail && g_started && ref_legal) || (err_code >= 4'd8 && err_code <= 4'd10))
    `ALB_ASSERT(25, a_fail_has_code,     "ERROR always carries a non-NONE documented code (1..10)", !fail || (err_code != 4'd0 && err_code <= 4'd10))
    // -- accounting
    `ALB_ASSERT(26, a_bytes_done_le_len, "bytes_done never exceeds the validated LENGTH", bytes_done <= g_len)
    `ALB_ASSERT(27, a_bytes_done_monotone,"bytes_done never decreases within a transfer", g_go_prev || bytes_done >= bd_prev)
    `ALB_ASSERT(28, a_bytes_done_ghost,  "[DMA.md 5] bytes_done == bytes of the contiguous OK-write prefix (before the first write error), byte-accurate", {2'b0, bytes_done} == exp_bytes)
    `ALB_ASSERT(29, a_done_accounting,   "[DMA.md 1/5] DONE => legal, every beat read (good) and written exactly once and acknowledged OK, bytes_done == LENGTH, no bus error",
                !done || (ref_legal && rd_good == g_nb && wr_acc == g_nb && wr_ok == g_nb && bytes_done == g_len && !g_err))
    `ALB_ASSERT(30, a_done_xor_fail,     "DONE and ERROR are never raised together; each implies BUSY; busy == (state != IDLE)", !(done && fail) && (!(done || fail) || busy) && (busy == (state != 3'd0)))
    `ALB_ASSERT(33, a_err_code_first_error,"[DUT hdr] the reported code is that of the FIRST bus error: READ_BUS (8) for a read error, WRITE_BUS (9) for a write error", !(fail && g_err) || err_code == (g_first_wr ? 4'd9 : 4'd8))
    `ALB_ASSERT(34, a_err_addr_first_error,"[DMA.md 2] ERROR_ADDR is the address of the failing beat (src/dst + index of the failing response * DW/8)", !(fail && g_err) || err_addr == g_first_addr)
    // -- reset
    `ALB_ASSERT(31, a_reset_state,       "[DMA.md 4] reset: IDLE, no request, bytes_done 0, error code NONE, FIFO empty", rst_n || (state == 3'd0 && !any_req && !busy && bytes_done == 32'd0 && err_code == 4'd0 && fifo_level == 8'd0))
    `ALB_ASSERT(32, a_no_req_before_start,"[DMA.md 4] after reset no request and not busy until a START is accepted", g_started || (!any_req && !busy))
    // ------------------------------------------------------------------ covers
    `ALB_COVER(90,  c_done,           "a transfer completes (DONE)", done)
    `ALB_COVER(91,  c_fifo_full,      "the FIFO fills to FIFO_DEPTH", fifo_level == FIFO_DEPTH)
    `ALB_COVER(92,  c_phase_switch,   "single port: the phase switches (read burst -> write burst)", ph_chg)
    `ALB_COVER(93,  c_burst_full,     "single port: a full BURST of requests is issued in one phase", (DUAL_PORT == 0) && ({2'b0, eff_cnt} + {5'b0, m_acc[0]} == BURST))
    `ALB_COVER(94,  c_two_outstanding,"MAX_OUT transactions are in flight on a port", out0 == MAX_OUT)
    `ALB_COVER(95,  c_read_error,     "READ_BUS error path", fail && err_code == 4'd8)
    `ALB_COVER(96,  c_write_error,    "WRITE_BUS error path", fail && err_code == 4'd9)
    `ALB_COVER(97,  c_aborted,        "ABORTED path", fail && err_code == 4'd10)
    `ALB_COVER(98,  c_partial_tail,   "a partial final write strobe is presented", wr_req && wstrb != {SB{1'b1}})
    `ALB_COVER(99,  c_stall,          "a request waits for acceptance (back-pressure)", |(req_valid & ~req_ready))
    `ALB_COVER(100, c_concurrent,     "dual port: a read and a write are accepted in the same cycle", (DUAL_PORT != 0) && rd_acc_now && wr_acc_now)
    `ALB_COVER(101, c_data_tagged,    "the tagged beat's data reaches its write (monitor armed and compared)", wr_req && wr_acc == wk && g_tag_valid)
    `ALB_COVER(102, c_val_error,      "descriptor rejected by validation", fail && err_code >= 4'd1 && err_code <= 4'd7)
    `ALB_COVER(103, c_reset_mid,      "reset hits while a transfer is in flight", !rst_n && busy_d)
    `ALB_COVER(104, c_abort_done,     "DONE although an abort was seen (abort raced the last beat)", done && g_abort_seen)
  end
  reg busy_d;                                    // NOT reset: remembers `busy` across a reset step
  always @(posedge clk) busy_d <= busy;
endmodule
`default_nettype wire
