// =============================================================================
// AlbionFormal harness :: sfb_reg_slice (SFB2 pipeline register slice = two skid buffers)
// DUT   rtl_under_test/datafabric/rtl/interconnect/sfb_reg_slice.sv     SPEC  DUT header: "protocol-transparent (in order,
//       exactly one response per request, stable payloads under back-pressure)"; PROTOCOL R2 R4 R5 and section 7.
// Request and response channel each get a shadow ordered FIFO.  ASSUME-SET: ENV-RST-ANY (all inputs free; upstream may even
// withdraw -- the slice's own guarantees do not rely on master obedience).
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sfb_reg_slice #(parameter AW = 2, DW = 8, REQ_SLICE = 1, RSP_SLICE = 1, ALB_SEL = 0) (
  input wire clk, input wire rst_n,
  input wire s_req_valid, input wire s_req_write, input wire [AW-1:0] s_req_addr, input wire [DW-1:0] s_req_wdata, input wire [DW/8-1:0] s_req_wstrb,
  input wire s_rsp_ready,
  input wire m_req_ready, input wire m_rsp_valid, input wire [DW-1:0] m_rsp_rdata, input wire m_rsp_error
);
  localparam SB = DW / 8, QW = 1 + AW + DW + SB, PW = DW + 1;
  wire s_req_ready, s_rsp_valid, m_req_valid, m_req_write, m_rsp_ready, s_rsp_error;
  wire [AW-1:0] m_req_addr; wire [DW-1:0] m_req_wdata, s_rsp_rdata; wire [SB-1:0] m_req_wstrb;
  sfb_reg_slice #(.AW(AW), .DW(DW), .REQ_SLICE(REQ_SLICE), .RSP_SLICE(RSP_SLICE)) dut (
    .clk(clk), .rst_n(rst_n),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr), .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb),
    .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready), .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_error),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error));
  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  wire [QW-1:0] rq_in = {s_req_write, s_req_addr, s_req_wdata, s_req_wstrb}, rq_out = {m_req_write, m_req_addr, m_req_wdata, m_req_wstrb};
  wire [PW-1:0] rs_in = {m_rsp_rdata, m_rsp_error}, rs_out = {s_rsp_rdata, s_rsp_error};
  // ---- request-channel shadow
  reg [QW-1:0] rmem [0:3]; reg [1:0] rwp, rrp; reg [2:0] rcnt;
  wire rpush = s_req_valid && s_req_ready, rpop = m_req_valid && m_req_ready;
  // ---- response-channel shadow
  reg [PW-1:0] pmem [0:3]; reg [1:0] pwp, prp; reg [2:0] pcnt;
  wire ppush = m_rsp_valid && m_rsp_ready, ppop = s_rsp_valid && s_rsp_ready;
  reg rheld_q, pheld_q; reg [QW-1:0] rdata_q; reg [PW-1:0] pdata_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin rwp<=0; rrp<=0; rcnt<=0; pwp<=0; prp<=0; pcnt<=0; rheld_q<=0; pheld_q<=0; end
    else begin
      if (rpush) begin rmem[rwp] <= rq_in; rwp <= rwp + 2'd1; end
      if (rpop)  rrp <= rrp + 2'd1;
      rcnt <= rcnt + {2'b0, rpush} - {2'b0, rpop};
      if (ppush) begin pmem[pwp] <= rs_in; pwp <= pwp + 2'd1; end
      if (ppop)  prp <= prp + 2'd1;
      pcnt <= pcnt + {2'b0, ppush} - {2'b0, ppop};
      rheld_q <= m_req_valid && !m_req_ready; pheld_q <= s_rsp_valid && !s_rsp_ready;
    end
  end
  always @(posedge clk) begin rdata_q <= rq_out; pdata_q <= rs_out; end

  always @(*) begin
    if (REQ_SLICE != 0) begin
      `ALB_ASSERT(1, a_req_in_order,   "[R5/R12] request payloads reach the slave side in order, unmodified, none duplicated", `ALB_IMPL(rpop, rq_out == rmem[rrp]))
      `ALB_ASSERT(2, a_req_no_phantom, "no request is presented that was not accepted earlier", `ALB_IMPL(m_req_valid, rcnt != 3'd0))
      `ALB_ASSERT(3, a_req_bound,      "[sec.7] the request slice stores at most 2 transactions (and never accepts a 3rd)", rcnt <= 3'd2 && `ALB_IMPL(rcnt == 3'd2, !s_req_ready))
      `ALB_ASSERT(4, a_req_stable,     "[R2] a presented request that is not accepted stays presented, payload unchanged", `ALB_IMPL(rheld_q, m_req_valid && rq_out == rdata_q))
      `ALB_ASSERT(5, a_req_no_loss,    "an accepted request is never stranded: buffered => presented", `ALB_IMPL(rcnt != 3'd0, m_req_valid))
    end else begin
      `ALB_ASSERT(6, a_req_bypass,     "REQ_SLICE=0: the request channel is wires (valid, ready, payload)", m_req_valid == s_req_valid && s_req_ready == m_req_ready && rq_out == rq_in)
    end
    if (RSP_SLICE != 0) begin
      `ALB_ASSERT(11, a_rsp_in_order,  "[R5/R12] responses reach the master side in order, unmodified, none duplicated", `ALB_IMPL(ppop, rs_out == pmem[prp]))
      `ALB_ASSERT(12, a_rsp_no_phantom,"no response is presented that was not accepted earlier (solicited)", `ALB_IMPL(s_rsp_valid, pcnt != 3'd0))
      `ALB_ASSERT(13, a_rsp_bound,     "the response slice stores at most 2 responses (and never accepts a 3rd)", pcnt <= 3'd2 && `ALB_IMPL(pcnt == 3'd2, !m_rsp_ready))
      `ALB_ASSERT(14, a_rsp_stable,    "[R4] a held response stays valid with unchanged rdata/error", `ALB_IMPL(pheld_q, s_rsp_valid && rs_out == pdata_q))
      `ALB_ASSERT(15, a_rsp_no_loss,   "an accepted response is never stranded: buffered => presented", `ALB_IMPL(pcnt != 3'd0, s_rsp_valid))
    end else begin
      `ALB_ASSERT(16, a_rsp_bypass,    "RSP_SLICE=0: the response channel is wires", s_rsp_valid == m_rsp_valid && m_rsp_ready == s_rsp_ready && rs_out == rs_in)
    end
    `ALB_ASSERT(20, a_reset_quiet,     "[R11] reset: nothing buffered, nothing presented on either sliced channel", `ALB_IMPL(!rst_n, (REQ_SLICE == 0 || !m_req_valid) && (RSP_SLICE == 0 || !s_rsp_valid)))
    `ALB_COVER(90, c_req_full,         "request slice holds 2 transactions", REQ_SLICE != 0 && rcnt == 3'd2)
    `ALB_COVER(91, c_rsp_full,         "response slice holds 2 responses", RSP_SLICE != 0 && pcnt == 3'd2)
    `ALB_COVER(92, c_req_stall,        "slave side stalls a presented request", m_req_valid && !m_req_ready)
    `ALB_COVER(93, c_rsp_stall,        "master side stalls a presented response", s_rsp_valid && !s_rsp_ready)
    `ALB_COVER(94, c_both_move,        "a request and a response transfer in the same cycle", rpop && ppop)
  end
endmodule
`default_nettype wire
