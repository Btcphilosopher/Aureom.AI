// =============================================================================
// AlbionFormal harness :: PROTECTED ADDRESSES -- memory CONTENT seen from the host port   [SRAM item 3.5(c): "memory word unchanged"]
//
// Same composition and modelling choice as fv_prot_compose_tap.sv (cc_secmon -> cc_sfb_gate -> sfb_sram_slave -> real array, TAP = 0),
// refuse = host_lock && write && (word index >= PLO).  This job checks the END-TO-END data semantics from the host's point of view with a
// one-outstanding scoreboard on ONE symbolic word `ta` (any word, protected or not):
//   * a write the host sees answered WITHOUT error updates the shadow (strobed lanes); a write answered WITH error changes nothing;
//   * every read of `ta` answered without error returns the shadow on every known lane; never-written lanes are learned on first read
//     (the array has no defined power-up content) -- so an unauthorised write that slipped through (answered with an error but performed),
//     or a refused write that corrupts memory, shows up as a read mismatch.
// ENVIRONMENT  ENV-RST-ANY; ENV-PROT-R2; ENV-PROT-WIN (see the tap harness); ENV-PROT-NOTEST: tst_active = 0 (the MBIST port bypasses the host
//       gate by design and is exercised in the tap job; here it would change memory outside any host-visible response).
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_prot_compose_word #(
  parameter ALB_SEL = 0,
  parameter DEPTH = 4, LAT = 1, PLO = 2,
  localparam AW = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam OFF = 2
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        s_req_valid,
  input  wire        s_req_write,
  input  wire [31:0] s_req_addr,
  input  wire [31:0] s_req_wdata,
  input  wire [3:0]  s_req_wstrb,
  input  wire        s_rsp_ready,
  input  wire        rb_sel,
  input  wire        rb_we,
  input  wire [11:0] rb_addr,
  input  wire [31:0] rb_wdata
);
  `include "cc_memmap_defs.svh"
  wire        host_lock, refused_evt, idle, rb_err;
  wire [31:0] rb_rdata;
  wire        s_req_ready, s_rsp_valid, s_rsp_error;
  wire [31:0] s_rsp_rdata;
  wire        m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  wire [31:0] m_req_addr, m_req_wdata, m_rsp_rdata, tst_rdata;
  wire [3:0]  m_req_wstrb;

  wire [AW-1:0] wi   = s_req_addr[OFF +: AW];
  wire          prot = (wi >= PLO);
  wire          refuse = host_lock && s_req_write && prot;

  cc_secmon u_sec (.clk(clk), .rst_n(rst_n), .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata),
                   .rb_rdata(rb_rdata), .rb_err(rb_err), .viol_evt(refused_evt), .viol_addr(s_req_addr), .host_lock(host_lock));
  cc_sfb_gate u_gate (
    .clk(clk), .rst_n(rst_n),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr),
    .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb),
    .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready), .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_error),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .refuse(refuse), .refused_evt(refused_evt), .idle(idle));
  sfb_sram_slave #(.DW(32), .DEPTH(DEPTH), .READ_LATENCY(LAT)) u_ram (
    .clk(clk), .rst_n(rst_n),
    .req_valid(m_req_valid), .req_ready(m_req_ready), .req_write(m_req_write), .req_addr(m_req_addr),
    .req_wdata(m_req_wdata), .req_wstrb(m_req_wstrb),
    .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready), .rsp_rdata(m_rsp_rdata), .rsp_error(m_rsp_error),
    .tst_active(1'b0), .tst_ce(1'b0), .tst_we(1'b0), .tst_addr({AW{1'b0}}), .tst_wdata(32'd0), .tst_rdata(tst_rdata));
  defparam u_ram.u_sram.u_array.TAP = 0;

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));
  wire s_stable_ok, s_acc, s_held;
  albion_sfb_req_mon #(.AW(32), .DW(32)) u_s (.clk(clk), .rst_n(rst_n), .valid(s_req_valid), .ready(s_req_ready), .write(s_req_write),
    .addr(s_req_addr), .wdata(s_req_wdata), .wstrb(s_req_wstrb), .stable_ok(s_stable_ok), .accepted(s_acc), .held(s_held));

  // gate spec model (first evaluation of a request while the gate is free)
  reg fwd_pend, loc_pend, eval_q, lockfe_q;
  wire m_acc    = m_req_valid && m_req_ready;
  wire m_rsp_hs = m_rsp_valid && m_rsp_ready;
  wire s_rsp_hs = s_rsp_valid && s_rsp_ready;
  wire loc_acc  = s_acc && !m_req_valid;
  wire free     = !fwd_pend && !loc_pend;
  wire first_eval = s_req_valid && free && !eval_q;
  wire lock_fe  = first_eval ? host_lock : lockfe_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fwd_pend <= 1'b0; loc_pend <= 1'b0; eval_q <= 1'b0; lockfe_q <= 1'b0;
    end else begin
      fwd_pend <= (fwd_pend && !m_rsp_hs) || m_acc;
      loc_pend <= (loc_pend && !s_rsp_hs) || loc_acc;
      eval_q   <= s_acc ? 1'b0 : ((s_req_valid && free) ? 1'b1 : eval_q);
      if (first_eval) lockfe_q <= host_lock;
    end
  end

  // host-side one-outstanding scoreboard on the tracked word
  (* anyconst *) wire [AW-1:0] ta;
  reg          rq_v, rq_w, rq_ref;
  reg [AW-1:0] rq_a;
  reg [31:0]   rq_d;
  reg [3:0]    rq_s;
  reg [31:0]   sh_dt;
  reg [3:0]    sh_kn;
  reg [31:0]   n_dt;
  reg [3:0]    n_kn;
  integer b;
  wire unauth = s_req_write && prot && lock_fe;               // evaluated by the gate while the lock was set
  always @(*) begin
    n_dt = sh_dt; n_kn = sh_kn;
    if (s_rsp_hs && rq_v && rq_a == ta && !s_rsp_error) begin
      for (b = 0; b < 4; b = b + 1) begin
        if (rq_w) begin
          if (rq_s[b]) begin n_dt[b*8 +: 8] = rq_d[b*8 +: 8]; n_kn[b] = 1'b1; end
        end else if (!sh_kn[b]) begin
          n_dt[b*8 +: 8] = s_rsp_rdata[b*8 +: 8]; n_kn[b] = 1'b1;
        end
      end
    end
  end
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rq_v <= 1'b0; sh_kn <= 4'd0;
    end else begin
      sh_kn <= n_kn;
      if (s_rsp_hs) rq_v <= 1'b0;
      if (s_acc) begin rq_v <= 1'b1; end
    end
  end
  always @(posedge clk) begin
    sh_dt <= n_dt;
    if (s_acc) begin rq_w <= s_req_write; rq_a <= wi; rq_d <= s_req_wdata; rq_s <= s_req_wstrb; rq_ref <= unauth; end
  end
  wire rd_resp = s_rsp_hs && rq_v && !rq_w && rq_a == ta && !s_rsp_error;
  reg [31:0] kmask;
  always @(*) begin
    kmask = 32'd0;
    for (b = 0; b < 4; b = b + 1) if (sh_kn[b]) kmask[b*8 +: 8] = 8'hff;
  end
  wire ok_word = !rd_resp || ((s_rsp_rdata & kmask) == (sh_dt & kmask));

  reg out_prev;
  always @(posedge clk) out_prev <= rq_v;

  always @(*) begin
    `ALB_ASSUME(e_up_r2,  "ENV-PROT-R2 upstream keeps a presented request and its payload until accepted (PROTOCOL R2)", s_stable_ok)
    `ALB_ASSUME(e_win,    "ENV-PROT-WIN requests are word-aligned and inside the slave window (crossbar decode, PROTOCOL R9)",
                s_req_addr[1:0] == 2'b00 && (s_req_addr >> (OFF + AW)) == 32'd0)
    `ALB_ASSUME(e_ta,     "ENV-SRAM-TA the tracked word is a valid word (quantified over every word)", ta < DEPTH)
  end
  always @(*) begin
    `ALB_ASSERT(20, a_prot_word_unchanged, "END-TO-END: every read of any word returns what the host's successfully acknowledged writes left there (lanes by strobe): refused/unauthorised writes never change memory; never-written lanes stay unchanged",
                ok_word)
    `ALB_ASSERT(21, a_prot_refused_answered_error, "a protected write evaluated while host_lock = 1 is answered with rsp_error = 1 (never acknowledged as done)",
                `ALB_IMPL(s_rsp_hs && rq_v && rq_ref, s_rsp_error))
    `ALB_ASSERT(22, a_no_false_denial, "an unprotected or pre-lock request is acknowledged without error (the lock denies nothing else)",
                `ALB_IMPL(s_rsp_hs && rq_v && !rq_ref, !s_rsp_error))
  end
  always @(*) begin
    `ALB_COVER(90, c_protected_word_tracked, "the tracked word is a protected word", ta >= PLO)
    `ALB_COVER(91, c_write_refused_on_tracked, "a write to the tracked protected word is refused while locked", s_rsp_hs && rq_v && rq_ref && rq_a == ta && rq_w)
    `ALB_COVER(92, c_read_checked_after_refusal, "a read of the tracked word is checked against the shadow after a refused write", rd_resp && sh_kn != 4'd0 && host_lock)
    `ALB_COVER(93, c_write_acked_on_tracked, "a write to the tracked word is acknowledged and applied", s_rsp_hs && rq_v && rq_w && rq_a == ta && !s_rsp_error)
    `ALB_COVER(94, c_partial_strobe_ack, "an acknowledged write with partial strobes", s_rsp_hs && rq_v && rq_w && rq_s != 4'hf && rq_s != 4'h0 && !s_rsp_error)
    `ALB_COVER(95, c_reset_with_pending, "reset while a host transaction is pending", !rst_n && !init_q && out_prev)
  end
endmodule
`default_nettype wire
