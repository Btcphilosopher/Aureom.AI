// =============================================================================
// AlbionFormal self-test :: a tiny design with KNOWN verdicts, used to validate the proof system itself
// (docs/METHODOLOGY.md "validating the proof system").  Not RTL under test.
//
//   DUT    saturating counter: counts up while `en`, saturates at LIMIT (9).  BUG=1 saturates at 10 instead.
//   OVERCON=1  adds the assumption `!en` (the counter can then never leave 0): an over-constrained, vacuous environment.
// Expected verdicts are recorded in proofs/selftest.json; `albion_formal.py selftest` fails if any differs.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module selftest_counter #(parameter LIMIT = 9) (input wire clk, input wire rst_n, input wire en, output reg [3:0] q);
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n)                q <= 4'd0;
    else if (en && q != LIMIT) q <= q + 4'd1;
  end
endmodule

module fv_selftest #(parameter ALB_SEL = 0, parameter BUG = 0, parameter OVERCON = 0, parameter MODE = 1) (
  input wire clk, input wire rst_n, input wire en
);
  wire [3:0] q;
  selftest_counter #(.LIMIT(BUG == 1 ? 10 : 9)) dut (.clk(clk), .rst_n(rst_n), .en(en), .q(q));
  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  always @(*) begin
    if (OVERCON != 0) begin
      `ALB_ASSUME(e_never_enable, "SELF: over-constraining assumption (en is never high)", !en)
    end
    `ALB_ASSERT(1, a_le9,        "counter never exceeds 9 (true for BUG=0, false for BUG=1)", q <= 4'd9)
    `ALB_ASSERT(2, a_not_15,     "counter never reaches 15 (true)", q != 4'd15)
    `ALB_ASSERT(3, a_le8_false,  "counter never exceeds 8 (FALSE: reaches 9 at step 9)", q <= 4'd8)
    `ALB_ASSERT(4, a_tautology,  "x == x : constant after elaboration -> TRIVIAL", q == q)
    if (BUG == 2) begin
      `ALB_ASSERT(5, a_only_bug2, "present only when BUG==2 -> N/A otherwise", q <= 4'd9)
    end
    `ALB_ASSERT(6, a_word_tautology, "q==0 || q!=0 : a tautology the optimiser does NOT fold -> PROVED (only mutation testing exposes weak properties)", q == 4'd0 || q != 4'd0)
    `ALB_COVER(90, c_reach_9,  "counter reaches 9", q == 4'd9)
    `ALB_COVER(91, c_reach_10, "counter reaches 10 (reachable only for BUG=1)", q == 4'd10)
    `ALB_COVER(92, c_leaves_0, "counter leaves 0 (unreachable under OVERCON: the vacuity alarm)", q != 4'd0 && !init_q)
  end
endmodule
`default_nettype wire
