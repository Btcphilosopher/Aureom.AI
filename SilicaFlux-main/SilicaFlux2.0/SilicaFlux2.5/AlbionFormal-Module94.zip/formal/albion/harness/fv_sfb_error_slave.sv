// =============================================================================
// AlbionFormal harness :: sfb_error_slave (decode-error slave inside every crossbar master port)
// DUT   rtl_under_test/datafabric/rtl/interconnect/sfb_error_slave.sv      SPEC  DUT header; PROTOCOL R5 R8
// ASSUME-SET: ENV-RST-ANY.  req_valid and rsp_ready are free inputs.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sfb_error_slave #(parameter DW = 8, parameter ALB_SEL = 0) (
  input wire clk, input wire rst_n, input wire req_valid, input wire rsp_ready
);
  wire req_ready, rsp_valid, rsp_error; wire [DW-1:0] rsp_rdata;
  sfb_error_slave #(.DW(DW)) dut (.clk(clk), .rst_n(rst_n), .req_valid(req_valid), .req_ready(req_ready),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error));
  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));
  wire acc = req_valid && req_ready, hs = rsp_valid && rsp_ready;
  reg [1:0] out_q; reg held_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin out_q <= 2'd0; held_q <= 1'b0; end
    else begin out_q <= out_q + {1'b0, acc} - {1'b0, hs}; held_q <= rsp_valid && !rsp_ready; end
  end
  always @(*) begin
    `ALB_ASSERT(1, a_always_error,    "[R8] every response is an error", `ALB_IMPL(rsp_valid, rsp_error))
    `ALB_ASSERT(2, a_rdata_zero,      "[R8] rsp_rdata is 0 (no data leaks from the error slave)", rsp_rdata == {DW{1'b0}})
    `ALB_ASSERT(3, a_one_response,    "[R5] exactly one response per accepted request: outstanding count is 0 or 1 and rsp_valid <=> 1 outstanding",
                out_q <= 2'd1 && (rsp_valid == (out_q == 2'd1)))
    `ALB_ASSERT(4, a_ready_rule,      "req_ready == !pending || rsp_ready (accept-while-retiring, one buffered response)", req_ready == (!rsp_valid || rsp_ready))
    `ALB_ASSERT(5, a_held_stable,     "[R4] a response that is not accepted stays valid next cycle", `ALB_IMPL(held_q, rsp_valid))
    `ALB_ASSERT(6, a_reset_quiet,     "reset: no response is pending", `ALB_IMPL(!rst_n, !rsp_valid))
    `ALB_COVER(90, c_response,        "an error response is produced", rsp_valid)
    `ALB_COVER(91, c_backpressure,    "response held under back-pressure", rsp_valid && !rsp_ready)
    `ALB_COVER(92, c_accept_while_retire, "a new request is accepted in the cycle the previous response is accepted", acc && hs)
  end
endmodule
`default_nettype wire
