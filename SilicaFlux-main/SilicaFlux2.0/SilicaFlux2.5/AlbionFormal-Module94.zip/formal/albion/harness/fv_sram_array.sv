// =============================================================================
// AlbionFormal harness :: sram_generic_1rw -- the RAW array, verified on its own   [SRAM area, brief item 3]
//
// DUT   rtl:.../backends/generic/sram_generic_1rw.sv (SYNTHESIS branch: flip-flop/inferred array, READ_LATENCY pipeline)
// SPEC  raw backend contract, docs/mem/01_interface_spec.md section 3:  write lanes with wmask=1 take wdata, other lanes keep
//       their value; read data valid EXACTLY READ_LATENCY cycles after the read edge; addr < DEPTH; no reset, no initial content.
// WHY   the sram_sp proofs (fv_sram_sp_*) use this array through the shim; this job shows the result does not rest on the shim:
//       the very same scoreboard is applied to the array's own ports.
// ENVIRONMENT  ENV-ARR-1: addr < DEPTH whenever ce (raw contract item 4 -- the handshake wrappers guarantee it; sram_sp's
//       control job proves that it does).  Reset only clears the scoreboard (the array has no reset): ENV-RST-ANY.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sram_array #(
  parameter ALB_SEL = 0,
  parameter DW = 16, MW = 2, DEPTH = 4, LAT = 1,
  localparam AW = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire              ce,
  input  wire              we,
  input  wire [MW-1:0]     wmask,
  input  wire [AW-1:0]     addr,
  input  wire [DW-1:0]     wdata
);
  wire [DW-1:0] rdata;
  sram_generic_1rw #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT)) dut (
    .clk(clk), .ce(ce), .we(we), .wmask(wmask), .addr(addr), .wdata(wdata), .rdata(rdata));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));
  (* anyconst *) wire [AW-1:0] ta;

  wire ok_raw, ok_raw_written, ok_raw_unwritten, ok_rsp_valid, ok_err, ok_we, ok_id, ok_zero, ok_data, ok_stable, ov;
  wire [3:0] qcount;
  wire cv_raw_checked, cv_raw_partial, cv_raw_unwritten, cv_partial_write, cv_backpressure, cv_full, cv_err_rsp, cv_data_checked;
  albion_sram_sb #(.DW(DW), .MW(MW), .AW(AW), .DEPTH(DEPTH), .LAT(LAT), .QD(1), .WACK(1), .IDW(1), .CHECK_WE(0), .CHECK_ID(0)) sb (
    .clk(clk), .rst_n(rst_n), .ta(ta),
    .arr_ce(ce), .arr_we(we), .arr_wmask(wmask), .arr_addr(addr), .arr_wdata(wdata), .raw_rdata(rdata),
    .acc(1'b0), .acc_we(1'b0), .acc_addr({AW{1'b0}}), .acc_id(1'b0),
    .rsp_valid(1'b0), .rsp_ready(1'b1), .rsp_rdata({DW{1'b0}}), .rsp_err(1'b0), .rsp_we(1'b0), .rsp_id(1'b0),
    .ok_raw(ok_raw), .ok_raw_written(ok_raw_written), .ok_raw_unwritten(ok_raw_unwritten),
    .ok_rsp_valid(ok_rsp_valid), .ok_err(ok_err), .ok_we(ok_we), .ok_id(ok_id), .ok_zero(ok_zero), .ok_data(ok_data),
    .ok_stable(ok_stable), .ov(ov), .qcount(qcount),
    .cv_raw_checked(cv_raw_checked), .cv_raw_partial(cv_raw_partial), .cv_raw_unwritten(cv_raw_unwritten),
    .cv_partial_write(cv_partial_write), .cv_backpressure(cv_backpressure), .cv_full(cv_full), .cv_err_rsp(cv_err_rsp),
    .cv_data_checked(cv_data_checked));

  always @(*) begin
    `ALB_ASSUME(e_arr_addr_in_range, "ENV-ARR-1 raw backend contract: addr < DEPTH whenever ce (spec 3.4)", `ALB_IMPL(ce, {1'b0, addr} < DEPTH))
    `ALB_ASSUME(e_ta_valid, "ENV-SRAM-TA the tracked word address is a valid word (quantified over every valid address)", ta < DEPTH)
  end

  always @(*) begin
    `ALB_ASSERT(1, a_array_lanes, "[spec 3.2,3.3] data read EXACTLY READ_LATENCY cycles after the read edge equals the shadow on every known lane (writes, masked writes, unwritten lanes)", ok_raw)
    `ALB_ASSERT(2, a_array_written_lanes, "[spec 3.2] lanes written with wmask=1 return the last value written; a later write with wmask=0 on that lane leaves it unchanged", ok_raw_written)
    `ALB_ASSERT(3, a_array_unwritten_stable, "[spec 3.2] bytes that no write ever touched remain unchanged: two reads of such a lane return the same value, whatever else is written to the word", ok_raw_unwritten)
  end
  always @(*) begin
    `ALB_COVER(90, c_known_read,       "a read of a lane written earlier is checked", cv_raw_checked)
    `ALB_COVER(91, c_partial_known,    "a read where only some lanes are known", cv_raw_partial)
    `ALB_COVER(92, c_unwritten_reread, "a never-written lane is re-read and compared", cv_raw_unwritten)
    `ALB_COVER(93, c_partial_write,    "a masked (partial-lane) write is performed", cv_partial_write)
    `ALB_COVER(94, c_other_addr_write_between, "a write to another word occurs between a write and a read of the tracked word", ce && we && addr != ta)
  end
endmodule
`default_nettype wire
