// =============================================================================
// AlbionFormal harness :: sf_citadel_domain_table  (descriptors, port bindings, privileged command interpreter)
//
// DUT      rtl_under_test/citadel/rtl/albion/sf_citadel_domain_table.sv      SPEC  docs/citadel/03_DOMAIN_TABLE.md, 08
//
// Environment: NONE beyond reset (ENV-RST-ANY).  The command port is completely free: any requester label, privilege bit,
// opcode, argument, cfg_en_i and any containment (qtn_*) stream.  (The composition job SEC-STALE restricts the command
// stream to the privileged plane to make revocation scenarios reachable; THIS job does not.)
//
// Method.  A command at step t is answered at t+1 (rsp_valid_o, rsp_status_o) and its effect lands in the state visible at
// t+1.  Properties therefore compare the state at t+1 with what was captured at t (registers p_*).  To keep the shadow state
// tiny, ONE slot `fs` and ONE bit of that slot's descriptor vector `sli` are chosen by the solver ((* anyconst *)): a
// violation in any slot / bit is found.  Containment (qtn_*) can change a slot without a command, so the "refused command
// changes nothing" family is conditioned on !p_qtn_v.
//
// PARAMETER POINT: NDOM=2 NW=2 NP=2 NDEV=2 NQ=2 NKEY=2 AW=6.  The table logic is count/width generic; the proofs are at this
// point only (not at NDOM=8 NW=4 AW=64).  Device map (explicit: Yosys 0.33 package-default hazard):
//   dev0 = 38..3F, dev1 = 30..37   (an EXCLUSIVE window may not touch them)
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_cit_table #(
  parameter NDOM = 2, parameter NW = 2, parameter NP = 2, parameter NDEV = 2, parameter NQ = 2, parameter NKEY = 2, parameter AW = 6,
  parameter ALB_SEL = 0,
  parameter [NDEV*AW-1:0] DEV_BASE = 12'hC38,
  parameter [NDEV*AW-1:0] DEV_MASK = 12'hE38,
  localparam SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1,
  localparam WIN_W  = (NW   > 1) ? $clog2(NW)   : 1,
  localparam PORT_W = (NP   > 1) ? $clog2(NP)   : 1
) (
  input wire                clk_i,
  input wire                rst_ni,
  input wire                cfg_en_i,
  input wire                cmd_valid_i,
  input wire [3:0]          cmd_op_i,
  input wire [7:0]          cmd_dom_i,
  input wire                cmd_priv_i,
  input wire [SLOT_W-1:0]   cmd_slot_i,
  input wire [WIN_W-1:0]    cmd_win_i,
  input wire [PORT_W-1:0]   cmd_port_i,
  input wire [7:0]          cmd_arg_dom_i,
  input wire [7:0]          cmd_flags_i,
  input wire [63:0]         cmd_data0_i,
  input wire [63:0]         cmd_data1_i,
  input wire                qtn_valid_i,
  input wire [SLOT_W-1:0]   qtn_slot_i,
  input wire [7:0]          look_dom_i,
  input wire [AW-1:0]       own_addr_i
);
  wire                  rsp_valid_o, cmd_deny_o, ctl_clr_safe_o, ctl_clr_cnt_o, ctl_thresh_we_o, zero_valid_o, lock_o, look_found_o, own_found_o;
  wire [3:0]            rsp_status_o;
  wire [NQ-1:0]         ctl_clr_qhold_o;
  wire [NP-1:0]         ctl_clr_isol_o;
  wire [15:0]           ctl_thresh_o;
  wire [NKEY-1:0]       zero_mask_o;
  wire [NDOM-1:0]       slot_clr_o;
  wire [SLOT_W-1:0]     look_slot_o, own_slot_o;
  wire [NDOM*2-1:0]     slot_state_o;
  wire [NDOM*8-1:0]     slot_id_o;
  wire [NDOM-1:0]       slot_priv_o, slot_secure_o;
  wire [NDOM*NW-1:0]    win_valid_o, win_r_o, win_w_o, win_x_o, win_excl_o;
  wire [NDOM*NW*AW-1:0] win_base_o, win_limit_o;
  wire [NDOM*NDEV-1:0]  devrd_o, devwr_o;
  wire [NDOM*NQ-1:0]    qmask_o;
  wire [NDOM*NKEY-1:0]  kmask_o;
  wire [NP*NDOM-1:0]    bind_o;

  sf_citadel_domain_table #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW), .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK)) dut (
    .clk_i(clk_i), .rst_ni(rst_ni), .cfg_en_i(cfg_en_i), .cmd_valid_i(cmd_valid_i), .cmd_op_i(cmd_op_i), .cmd_dom_i(cmd_dom_i),
    .cmd_priv_i(cmd_priv_i), .cmd_slot_i(cmd_slot_i), .cmd_win_i(cmd_win_i), .cmd_port_i(cmd_port_i), .cmd_arg_dom_i(cmd_arg_dom_i),
    .cmd_flags_i(cmd_flags_i), .cmd_data0_i(cmd_data0_i), .cmd_data1_i(cmd_data1_i),
    .rsp_valid_o(rsp_valid_o), .rsp_status_o(rsp_status_o), .cmd_deny_o(cmd_deny_o),
    .ctl_clr_qhold_o(ctl_clr_qhold_o), .ctl_clr_isol_o(ctl_clr_isol_o), .ctl_clr_safe_o(ctl_clr_safe_o), .ctl_clr_cnt_o(ctl_clr_cnt_o),
    .ctl_thresh_we_o(ctl_thresh_we_o), .ctl_thresh_o(ctl_thresh_o), .qtn_valid_i(qtn_valid_i), .qtn_slot_i(qtn_slot_i),
    .zero_valid_o(zero_valid_o), .zero_mask_o(zero_mask_o), .slot_clr_o(slot_clr_o),
    .look_dom_i(look_dom_i), .look_found_o(look_found_o), .look_slot_o(look_slot_o), .own_addr_i(own_addr_i), .own_found_o(own_found_o), .own_slot_o(own_slot_o),
    .slot_state_o(slot_state_o), .slot_id_o(slot_id_o), .slot_priv_o(slot_priv_o), .slot_secure_o(slot_secure_o),
    .win_valid_o(win_valid_o), .win_base_o(win_base_o), .win_limit_o(win_limit_o), .win_r_o(win_r_o), .win_w_o(win_w_o), .win_x_o(win_x_o),
    .win_excl_o(win_excl_o), .devrd_o(devrd_o), .devwr_o(devwr_o), .qmask_o(qmask_o), .kmask_o(kmask_o), .bind_o(bind_o), .lock_o(lock_o));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk_i), .rst_n(rst_ni), .init_q(init_q));

  localparam [3:0] OP_ENROLL = 4'd1, OP_SET_WINDOW = 4'd2, OP_REVOKE = 4'd8, OP_SET_STATE = 4'd7, OP_BIND = 4'd9, OP_LOCK = 4'd10,
                   OP_CLR_SAFE = 4'd13, OP_SET_THRESH = 4'd14;
  localparam [3:0] CS_OK = 4'd0, CS_BAD_PRIV = 4'd2, CS_NOT_AUTH = 4'd9, CS_BAD_CMD = 4'd1, CS_OVERLAP = 4'd6;
  localparam [1:0] DS_INVALID = 2'd0, DS_ACTIVE = 2'd2, DS_QUAR = 2'd3, DS_SUSP = 2'd1;

  // ------------------------------------------------------------------ solver-chosen slot / bit (universal)
  localparam SLW = 2 + 8 + 1 + 1 + 5*NW + 2*NW*AW + 2*NDEV + NQ + NKEY;            // descriptor bits of one slot
  (* anyconst *) wire [SLOT_W-1:0] fs;
  (* anyconst *) wire [7:0]        sli;
  wire fs_ok  = (fs < NDOM);
  wire sli_ok = (sli < SLW);

  reg [1:0]       st_fs;   reg [7:0] id_fs;  reg priv_fs, sec_fs;
  reg [NW-1:0]    wv_fs, wr_fs, ww_fs, wx_fs, wex_fs;
  reg [NW*AW-1:0] wb_fs, wl_fs;
  reg [NDEV-1:0]  drd_fs, dwr_fs;  reg [NQ-1:0] qm_fs;  reg [NKEY-1:0] km_fs;
  integer s;
  always @(*) begin
    st_fs = 2'd0; id_fs = 8'd0; priv_fs = 1'b0; sec_fs = 1'b0; wv_fs = {NW{1'b0}}; wr_fs = {NW{1'b0}}; ww_fs = {NW{1'b0}}; wx_fs = {NW{1'b0}};
    wex_fs = {NW{1'b0}}; wb_fs = {NW*AW{1'b0}}; wl_fs = {NW*AW{1'b0}}; drd_fs = {NDEV{1'b0}}; dwr_fs = {NDEV{1'b0}}; qm_fs = {NQ{1'b0}}; km_fs = {NKEY{1'b0}};
    for (s = 0; s < NDOM; s = s + 1) begin
      if (fs == s) begin
        st_fs = slot_state_o[s*2 +: 2]; id_fs = slot_id_o[s*8 +: 8]; priv_fs = slot_priv_o[s]; sec_fs = slot_secure_o[s];
        wv_fs = win_valid_o[s*NW +: NW]; wr_fs = win_r_o[s*NW +: NW]; ww_fs = win_w_o[s*NW +: NW]; wx_fs = win_x_o[s*NW +: NW]; wex_fs = win_excl_o[s*NW +: NW];
        wb_fs = win_base_o[s*NW*AW +: NW*AW]; wl_fs = win_limit_o[s*NW*AW +: NW*AW];
        drd_fs = devrd_o[s*NDEV +: NDEV]; dwr_fs = devwr_o[s*NDEV +: NDEV]; qm_fs = qmask_o[s*NQ +: NQ]; km_fs = kmask_o[s*NKEY +: NKEY];
      end
    end
  end
  wire [SLW-1:0] sl = {st_fs, id_fs, priv_fs, sec_fs, wv_fs, wr_fs, ww_fs, wx_fs, wex_fs, wb_fs, wl_fs, drd_fs, dwr_fs, qm_fs, km_fs};
  wire sl_bit = sli_ok ? sl[sli] : 1'b0;
  wire sys_fs  = (st_fs != DS_INVALID) && (id_fs < 8'h10);            // enrolled system domain (ids 0x00..0x0F)
  wire enr_fs  = (st_fs != DS_INVALID);

  // whole exported descriptor state, for the reset check
  localparam ASW = NDOM*2+NDOM*8+2*NDOM+5*NDOM*NW+2*NDOM*NW*AW+2*NDOM*NDEV+NDOM*NQ+NDOM*NKEY+NP*NDOM+1;
  wire [ASW-1:0] allstate =
      {slot_state_o, slot_id_o, slot_priv_o, slot_secure_o, win_valid_o, win_r_o, win_w_o, win_x_o, win_excl_o, win_base_o, win_limit_o,
       devrd_o, devwr_o, qmask_o, kmask_o, bind_o, lock_o};

  // ------------------------------------------------------------------ previous-cycle captures (async-reset style, see HARNESS_GUIDE C2)
  reg        p_cmdv, p_priv, p_cfg, p_qtn_v, p_lock, p_slbit, p_slsys, p_slenr, p_privfs, p_secfs;
  reg [3:0]  p_op;  reg [7:0] p_dom, p_flags, p_idfs;  reg [SLOT_W-1:0] p_slot, p_qtn_slot;  reg [1:0] p_stfs;
  reg [NP*NDOM-1:0] p_bind;  reg [NKEY-1:0] p_kmfs;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      p_cmdv <= 1'b0; p_priv <= 1'b0; p_cfg <= 1'b0; p_qtn_v <= 1'b0; p_lock <= 1'b0; p_slbit <= 1'b0; p_slsys <= 1'b0; p_slenr <= 1'b0;
      p_privfs <= 1'b0; p_secfs <= 1'b0; p_op <= 4'd0; p_dom <= 8'd0; p_flags <= 8'd0; p_idfs <= 8'd0; p_slot <= {SLOT_W{1'b0}}; p_qtn_slot <= {SLOT_W{1'b0}};
      p_stfs <= 2'd0; p_bind <= {NP*NDOM{1'b0}}; p_kmfs <= {NKEY{1'b0}};
    end else begin
      p_cmdv <= cmd_valid_i; p_priv <= cmd_priv_i; p_cfg <= cfg_en_i; p_qtn_v <= qtn_valid_i; p_lock <= lock_o; p_slbit <= sl_bit; p_slsys <= sys_fs; p_slenr <= enr_fs;
      p_privfs <= priv_fs; p_secfs <= sec_fs; p_op <= cmd_op_i; p_dom <= cmd_dom_i; p_flags <= cmd_flags_i; p_idfs <= id_fs; p_slot <= cmd_slot_i; p_qtn_slot <= qtn_slot_i;
      p_stfs <= st_fs; p_bind <= bind_o; p_kmfs <= km_fs;
    end
  end
  wire p_root = p_priv && (p_dom == 8'h00);
  wire p_mgmt = p_priv && (p_dom == 8'h01);
  wire p_privd = p_root || p_mgmt;
  wire p_slot_is_fs = (p_slot == fs);
  wire revoke_ok = p_cmdv && p_op == OP_REVOKE && p_slot_is_fs && rsp_status_o == CS_OK;

  // bind-bit mask of slot fs across ports: bit (p*NDOM + fs)
  reg [NP*NDOM-1:0] bind_slot_mask;
  integer pp;
  always @(*) begin
    bind_slot_mask = {NP*NDOM{1'b0}};
    for (pp = 0; pp < NP; pp = pp + 1) bind_slot_mask[pp*NDOM + fs] = 1'b1;
  end

  // ------------------------------------------------------------------ INV-EXCL and friends (state-only invariants)
  reg inv_excl, inv_wf, inv_uniq, inv_idlegal, inv_invclean, inv_excl_dev;
  integer i, j, k, m, d;
  always @(*) begin
    inv_excl = 1'b1; inv_wf = 1'b1; inv_uniq = 1'b1; inv_idlegal = 1'b1; inv_invclean = 1'b1; inv_excl_dev = 1'b1;
    for (i = 0; i < NDOM; i = i + 1) begin
      for (k = 0; k < NW; k = k + 1) begin
        if (win_valid_o[i*NW+k] && (win_base_o[(i*NW+k)*AW +: AW] > win_limit_o[(i*NW+k)*AW +: AW])) inv_wf = 1'b0;
        for (d = 0; d < NDEV; d = d + 1)
          if (win_valid_o[i*NW+k] && win_excl_o[i*NW+k] && DEV_MASK[d*AW +: AW] != {AW{1'b0}} &&
              win_base_o[(i*NW+k)*AW +: AW] <= (DEV_BASE[d*AW +: AW] | ~DEV_MASK[d*AW +: AW]) && DEV_BASE[d*AW +: AW] <= win_limit_o[(i*NW+k)*AW +: AW])
            inv_excl_dev = 1'b0;
        for (j = 0; j < NDOM; j = j + 1)
          for (m = 0; m < NW; m = m + 1)
            if (i != j && win_valid_o[i*NW+k] && win_valid_o[j*NW+m] && (win_excl_o[i*NW+k] || win_excl_o[j*NW+m]) &&
                win_base_o[(i*NW+k)*AW +: AW] <= win_limit_o[(j*NW+m)*AW +: AW] && win_base_o[(j*NW+m)*AW +: AW] <= win_limit_o[(i*NW+k)*AW +: AW])
              inv_excl = 1'b0;
      end
      if (slot_state_o[i*2 +: 2] != DS_INVALID && slot_id_o[i*8 +: 8] == 8'hFF) inv_idlegal = 1'b0;
      for (j = 0; j < NDOM; j = j + 1)
        if (i != j && slot_state_o[i*2 +: 2] != DS_INVALID && slot_state_o[j*2 +: 2] != DS_INVALID && slot_id_o[i*8 +: 8] == slot_id_o[j*8 +: 8]) inv_uniq = 1'b0;
      if (slot_state_o[i*2 +: 2] == DS_INVALID) begin
        if (slot_id_o[i*8 +: 8] != 8'd0 || slot_priv_o[i] || slot_secure_o[i] || (win_valid_o[i*NW +: NW] != {NW{1'b0}}) || (win_r_o[i*NW +: NW] != {NW{1'b0}}) ||
            (win_w_o[i*NW +: NW] != {NW{1'b0}}) || (win_x_o[i*NW +: NW] != {NW{1'b0}}) || (win_excl_o[i*NW +: NW] != {NW{1'b0}}) ||
            (win_base_o[i*NW*AW +: NW*AW] != {NW*AW{1'b0}}) || (win_limit_o[i*NW*AW +: NW*AW] != {NW*AW{1'b0}}) ||
            (devrd_o[i*NDEV +: NDEV] != {NDEV{1'b0}}) || (devwr_o[i*NDEV +: NDEV] != {NDEV{1'b0}}) || (qmask_o[i*NQ +: NQ] != {NQ{1'b0}}) ||
            (kmask_o[i*NKEY +: NKEY] != {NKEY{1'b0}}))
          inv_invclean = 1'b0;
      end
    end
  end

  // ------------------------------------------------------------------ properties
  always @(*) begin
    `ALB_ASSERT(1, a_reset_default_deny, "[03] reset => DEFAULT DENY: every slot INVALID, no window, no binding, not locked, no response / control pulse",
                `ALB_IMPL(!rst_ni, allstate == {ASW{1'b0}} && !rsp_valid_o && !cmd_deny_o && ctl_clr_qhold_o == {NQ{1'b0}} && ctl_clr_isol_o == {NP{1'b0}} &&
                          !ctl_clr_safe_o && !ctl_clr_cnt_o && !ctl_thresh_we_o && !zero_valid_o && zero_mask_o == {NKEY{1'b0}} && slot_clr_o == {NDOM{1'b0}}))
    `ALB_ASSERT(2, a_refused_cmd_noop, "[03] a refused command (status != OK) changes no descriptor bit of the chosen slot",
                `ALB_IMPL(rst_ni && p_cmdv && rsp_status_o != CS_OK && !p_qtn_v, sl_bit == p_slbit))
    `ALB_ASSERT(3, a_unpriv_no_effect, "[03] a command from a requester that is not (priv && ROOT|MGMT) never changes the table",
                `ALB_IMPL(rst_ni && p_cmdv && !p_privd && !p_qtn_v, sl_bit == p_slbit && bind_o == p_bind && (lock_o == p_lock)))
    `ALB_ASSERT(4, a_unpriv_status_before_decode, "[03] privilege is checked BEFORE the opcode is decoded: even opcode 0 from an unprivileged requester is answered BAD_PRIV / NOT_AUTH, never BAD_CMD",
                `ALB_IMPL(rst_ni && p_cmdv && !p_privd, rsp_status_o == CS_BAD_PRIV || rsp_status_o == CS_NOT_AUTH))
    `ALB_ASSERT(5, a_noauth_refused, "[03] cfg_en_i low => every command is answered NOT_AUTH and has no effect",
                `ALB_IMPL(rst_ni && p_cmdv && !p_cfg, rsp_status_o == CS_NOT_AUTH && (p_qtn_v || sl_bit == p_slbit) && bind_o == p_bind))
    `ALB_ASSERT(6, a_mgmt_no_system_change, "[03] MGMT can never change an enrolled system-domain slot",
                `ALB_IMPL(rst_ni && p_cmdv && p_mgmt && !p_qtn_v && p_slsys, sl_bit == p_slbit))
    `ALB_ASSERT(7, a_mgmt_no_system_enroll, "[03] MGMT can never create a system-domain slot (a slot holding an id < 0x10 was already enrolled with that id)",
                `ALB_IMPL(rst_ni && p_cmdv && p_mgmt && sys_fs, p_slenr && id_fs == p_idfs))
    `ALB_ASSERT(8, a_mgmt_no_release_quarantine, "[03] MGMT can neither leave nor REVOKE a QUARANTINED slot",
                `ALB_IMPL(rst_ni && p_cmdv && p_mgmt && p_stfs == DS_QUAR, st_fs == DS_QUAR))
    `ALB_ASSERT(9, a_mgmt_no_capability_grant, "[03] MGMT can never grant the privileged / secure capability",
                `ALB_IMPL(rst_ni && p_cmdv && p_mgmt, !(priv_fs && !p_privfs) && !(sec_fs && !p_secfs)))
    `ALB_ASSERT(10, a_mgmt_no_bind_lock_safe, "[03] MGMT can never change port bindings, set LOCK, clear the safe state, or set thresholds",
                `ALB_IMPL(rst_ni && p_cmdv && p_mgmt, bind_o == p_bind && !(lock_o && !p_lock) && !ctl_clr_safe_o && !ctl_clr_cnt_o && !ctl_thresh_we_o))
    `ALB_ASSERT(11, a_lock_monotone, "[03] LOCK is set until reset", `ALB_IMPL(rst_ni && p_lock, lock_o))
    `ALB_ASSERT(12, a_lock_freezes_bindings, "[03] after LOCK port bindings never change until reset", `ALB_IMPL(rst_ni && p_lock, bind_o == p_bind))
    `ALB_ASSERT(13, a_lock_freezes_system_slots, "[03] after LOCK an enrolled system-domain slot never changes by command",
                `ALB_IMPL(rst_ni && p_cmdv && p_lock && !p_qtn_v && p_slsys, sl_bit == p_slbit))
    `ALB_ASSERT(14, a_lock_no_new_system_slot, "[03] after LOCK no new system-domain slot can be enrolled", `ALB_IMPL(rst_ni && p_cmdv && p_lock && sys_fs, p_slenr && id_fs == p_idfs))
    `ALB_ASSERT(15, a_inv_excl, "[03 INV-EXCL] windows of distinct slots are disjoint whenever either one is EXCLUSIVE (isolation by construction)", inv_excl)
    `ALB_ASSERT(16, a_inv_well_formed, "[03] every valid window has base <= limit", inv_wf)
    `ALB_ASSERT(17, a_unique_ids, "[03 INV-UNIQ] enrolled slots hold pairwise distinct domain ids (discharges ENV-SEC-PERM-UNIQ)", inv_uniq)
    `ALB_ASSERT(18, a_enrolled_id_legal, "[03] no slot is enrolled with the invalid id 0xFF", inv_idlegal)
    `ALB_ASSERT(19, a_invalid_slot_clean, "[03] an INVALID slot holds no id, window, permission or mask: no stale permission survives in a free slot", inv_invclean)
    `ALB_ASSERT(20, a_excl_window_no_device, "[03] an EXCLUSIVE window never touches a device region", inv_excl_dev)
    `ALB_ASSERT(21, a_revoke_clears_slot, "[03 REVOKE] an accepted REVOKE clears EVERYTHING of the slot: INVALID, id, capabilities, windows, device/queue/key masks",
                `ALB_IMPL(rst_ni && revoke_ok && fs_ok, sl == {SLW{1'b0}}))
    `ALB_ASSERT(22, a_revoke_clears_binding, "[03 limitation 10 / 08] (CLAIM) an accepted REVOKE also clears the port bindings of the slot",
                `ALB_IMPL(rst_ni && revoke_ok && fs_ok, bind_o == (p_bind & ~bind_slot_mask)))
    `ALB_ASSERT(23, a_revoke_bindings_unchanged, "[03] an accepted REVOKE leaves all port bindings exactly as they were (the true behaviour behind limitation 10)",
                `ALB_IMPL(rst_ni && revoke_ok && fs_ok, bind_o == p_bind))
    `ALB_ASSERT(24, a_revoke_zeroises_keys, "[03] an accepted REVOKE requests zeroisation of exactly the slot's key mask",
                `ALB_IMPL(rst_ni && revoke_ok && fs_ok && !p_qtn_v, zero_mask_o == p_kmfs && zero_valid_o == (p_kmfs != {NKEY{1'b0}})))
    `ALB_ASSERT(25, a_quarantine_forces, "[03] the containment hook forces an enrolled slot to QUARANTINED (a same-cycle REVOKE wins)",
                `ALB_IMPL(rst_ni && fs_ok && p_qtn_v && p_qtn_slot == fs && p_stfs != DS_INVALID && !revoke_ok, st_fs == DS_QUAR))
    `ALB_ASSERT(26, a_quarantine_root_only_release, "[03] a QUARANTINED slot only leaves quarantine through a ROOT SET_STATE / REVOKE of that slot",
                `ALB_IMPL(rst_ni && fs_ok && p_stfs == DS_QUAR && !(p_cmdv && p_root && (p_op == OP_SET_STATE || p_op == OP_REVOKE) && p_slot_is_fs), st_fs == DS_QUAR))
    `ALB_ASSERT(27, a_response_next_cycle, "[03] every command is answered exactly one cycle later (and only commands)", `ALB_IMPL(rst_ni, rsp_valid_o == p_cmdv))
    `ALB_ASSERT(28, a_activation_needs_command, "[03] a slot becomes ACTIVE only through an accepted SET_STATE(ACTIVE) command on that slot (no automatic re-activation)",
                `ALB_IMPL(rst_ni && fs_ok && st_fs == DS_ACTIVE && p_stfs != DS_ACTIVE,
                          p_cmdv && p_op == OP_SET_STATE && p_slot_is_fs && p_flags[1:0] == DS_ACTIVE && rsp_status_o == CS_OK))
    `ALB_ASSERT(29, a_enroll_needs_command, "[03] a free slot becomes enrolled only through an accepted ENROLL command on that slot, and lands SUSPENDED (no access until activated)",
                `ALB_IMPL(rst_ni && fs_ok && st_fs != DS_INVALID && p_stfs == DS_INVALID,
                          p_cmdv && p_op == OP_ENROLL && p_slot_is_fs && rsp_status_o == CS_OK && st_fs == DS_SUSP))
    `ALB_ASSERT(30, a_refused_no_pulses, "[03] a refused command emits no control pulse and no slot-clear pulse",
                `ALB_IMPL(rst_ni && p_cmdv && rsp_status_o != CS_OK, ctl_clr_qhold_o == {NQ{1'b0}} && ctl_clr_isol_o == {NP{1'b0}} && !ctl_clr_safe_o && !ctl_clr_cnt_o &&
                          !ctl_thresh_we_o && slot_clr_o == {NDOM{1'b0}}))
    `ALB_ASSERT(31, a_safe_clear_root_only, "[03] the safe state is cleared only by a ROOT CLR_SAFE command", `ALB_IMPL(rst_ni && ctl_clr_safe_o, p_cmdv && p_root && p_op == OP_CLR_SAFE))
    `ALB_ASSERT(32, a_thresholds_root_only, "[03] thresholds are written only by a ROOT SET_THRESH command", `ALB_IMPL(rst_ni && ctl_thresh_we_o, p_cmdv && p_root && p_op == OP_SET_THRESH))
  end
  // ------------------------------------------------------------------ vacuity / reachability covers
  always @(*) begin
    `ALB_COVER(90, c_enroll_ok,       "a command ENROLLs the chosen slot", rst_ni && p_cmdv && p_op == OP_ENROLL && p_slot_is_fs && rsp_status_o == CS_OK && st_fs == DS_SUSP)
    `ALB_COVER(91, c_activate,        "the chosen slot becomes ACTIVE", rst_ni && st_fs == DS_ACTIVE && p_stfs != DS_ACTIVE)
    `ALB_COVER(92, c_window_installed, "the chosen slot holds a valid window", rst_ni && (wv_fs != {NW{1'b0}}) && st_fs == DS_ACTIVE)
    `ALB_COVER(93, c_excl_window,     "an EXCLUSIVE window exists", rst_ni && (|win_excl_o) && (|win_valid_o))
    `ALB_COVER(94, c_revoke_ok,       "an accepted REVOKE of the chosen slot", rst_ni && revoke_ok && p_stfs != DS_INVALID)
    `ALB_COVER(95, c_revoke_with_binding, "an accepted REVOKE of a slot that has a port binding (limitation 10 scenario)", rst_ni && revoke_ok && p_stfs != DS_INVALID && ((p_bind & bind_slot_mask) != {NP*NDOM{1'b0}}))
    `ALB_COVER(96, c_quarantine,      "containment quarantines the chosen slot", rst_ni && p_qtn_v && p_qtn_slot == fs && p_stfs != DS_INVALID && p_stfs != DS_QUAR && st_fs == DS_QUAR)
    `ALB_COVER(97, c_mgmt_refused,    "MGMT is refused (BAD_PRIV)", rst_ni && p_cmdv && p_mgmt && rsp_status_o == CS_BAD_PRIV)
    `ALB_COVER(98, c_overlap_refused, "SET_WINDOW refused with OVERLAP", rst_ni && p_cmdv && rsp_status_o == CS_OVERLAP)
    `ALB_COVER(99, c_lock_set,        "LOCK is set", rst_ni && lock_o && !p_lock)
    `ALB_COVER(100, c_unpriv_refused, "an unprivileged requester is refused", rst_ni && p_cmdv && !p_privd && rsp_status_o == CS_BAD_PRIV)
    `ALB_COVER(101, c_two_enrolled,   "two slots are enrolled at once", rst_ni && slot_state_o[1:0] != DS_INVALID && slot_state_o[3:2] != DS_INVALID)
    `ALB_COVER(102, c_mgmt_ok,        "MGMT successfully changes a tenant slot", rst_ni && p_cmdv && p_mgmt && rsp_status_o == CS_OK && p_op != OP_ENROLL)
    `ALB_COVER(103, c_bind_set,       "a port binding exists", rst_ni && (|bind_o))
    `ALB_COVER(104, c_sys_slot,       "an enrolled system-domain slot exists (ROOT enrolled it)", rst_ni && sys_fs)
  end
endmodule
`default_nettype wire
