// =============================================================================
// AlbionFormal shim :: sram_backend_1rw  (REPLACES rtl:.../sram_backend_1rw.sv in SRAM jobs; guide convention C7)
//
// Why.  sram_sp's array boundary (ce / we / wmask / addr / wdata) is internal; Yosys 0.33 has no hierarchical
// references (an `a.b.c` reference silently becomes an undriven wire -- measured), so the boundary can only be observed
// through legal ports.  This shim has the same name, parameters and ports as the selector it replaces and offers two modes,
// chosen from the harness with `defparam <path>.TAP = <0|1>` (defparam works through nested instances in Yosys 0.33):
//
//   TAP = 0  transparent: instantiates the REAL `sram_generic_1rw` (the BACKEND = GENERIC branch of the selector) with the
//            same parameters.  Data/timing jobs use this mode.
//   TAP = 1  observe: the array is dropped and `rdata` carries the array CONTROL inputs combinationally,
//              rdata[0] = ce   rdata[1] = we   rdata[2 +: MASK_WIDTH] = wmask   next AW bits = addr   rest = wdata (low bits)
//            sram_sp forwards `a_rdata` to its `tst_rdata` port (TEST_EN = 1), so the harness reads the array boundary
//            of the real sram_sp control logic in the same cycle.  Functional read data is garbage in this mode; TAP jobs
//            check control behaviour only.
//
// NOT covered by this shim: the selector's own generate logic (BACKEND != GENERIC branches -> FPGA/ASIC arrays are out of
// scope: they need vendor macros/BRAM inference and are not synthesizable in this flow).
// =============================================================================
`include "sram_defs.svh"
`default_nettype none
module sram_backend_1rw #(
  parameter int DATA_WIDTH   = 32,
  parameter int DEPTH        = 1024,
  parameter int MASK_WIDTH   = 4,
  parameter int READ_LATENCY = 1,
  parameter int BACKEND      = `SRAM_BACKEND_GENERIC,
  parameter int MACRO        = 0,
  parameter     INIT_FILE    = "",
  parameter int TAP          = 0,
  localparam int AW          = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire logic                  clk,
  input  wire logic                  ce,
  input  wire logic                  we,
  input  wire logic [MASK_WIDTH-1:0] wmask,
  input  wire logic [AW-1:0]         addr,
  input  wire logic [DATA_WIDTH-1:0] wdata,
  output logic      [DATA_WIDTH-1:0] rdata
);
  localparam int HDR = 2 + MASK_WIDTH + AW;
  if (TAP == 0) begin : g_real
    logic [DATA_WIDTH-1:0] q;
    sram_generic_1rw #(.DATA_WIDTH(DATA_WIDTH), .DEPTH(DEPTH), .MASK_WIDTH(MASK_WIDTH), .READ_LATENCY(READ_LATENCY))
      u_mem (.clk, .ce, .we, .wmask, .addr, .wdata, .rdata(q));
    assign rdata = q;
  end else begin : g_tap
    always_comb begin
      rdata = '0;
      rdata[0] = ce;
      rdata[1] = we;
      rdata[2 +: MASK_WIDTH] = wmask;
      rdata[2 + MASK_WIDTH +: AW] = addr;
      for (int i = HDR; i < DATA_WIDTH; i++) rdata[i] = wdata[i - HDR];
    end
  end
endmodule
`default_nettype wire
