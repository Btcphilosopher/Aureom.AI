// =============================================================================
// AlbionFormal harness :: cc_sfb_gate -- SFB2 pass-through that can refuse (host write lock / isolation gate)   [SRAM area, item 3.5(a)]
//
// DUT   rtl:controlcore/rtl/cc_sfb_gate.sv           SPEC  the module header comment + PROTOCOL.md R2/R3/R4/R5/R8/R11
// ROLE  In silicaflux_control_core the host gate is `refuse = host_lock && write && address in BOOTROM|IMEM|DMEM`, evaluated
//       combinationally on the request presented by the host port.  Here `refuse` is a completely free input (any value in any cycle,
//       including changes while a request waits), so every guarantee below holds for ANY refusal policy.
// SPEC MODEL (observable events only; independent of the RTL's registers)
//   fwd_pend  a request was forwarded (m_req_valid && m_req_ready) and its response has not been consumed
//   loc_pend  a request was accepted by the gate and NOT forwarded (s_req_valid && s_req_ready && !m_req_valid): the gate owes ONE local error response
//   held_m    the downstream request was presented in the previous cycle and not accepted (R2: it is never withdrawn)
//   free      !fwd_pend && !loc_pend  ("one transaction at a time")
// ENVIRONMENT
//   ENV-GATE-R2  the upstream master keeps a presented request and its payload until accepted (PROTOCOL R2)
//   ENV-GATE-R4  the downstream slave holds a response (valid, rdata, error) until rsp_ready
//   ENV-GATE-R5  the downstream slave answers only an accepted, earlier forwarded request, once, never in the acceptance cycle
//   ENV-GATE-R8  a downstream error response carries rdata = 0
//   `refuse`, `m_req_ready`, `s_rsp_ready` and the downstream response timing are otherwise free.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_prot_gate #(
  parameter ALB_SEL = 0
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        s_req_valid,
  input  wire        s_req_write,
  input  wire [31:0] s_req_addr,
  input  wire [31:0] s_req_wdata,
  input  wire [3:0]  s_req_wstrb,
  input  wire        s_rsp_ready,
  input  wire        m_req_ready,
  input  wire        m_rsp_valid,
  input  wire [31:0] m_rsp_rdata,
  input  wire        m_rsp_error,
  input  wire        refuse
);
  wire        s_req_ready, s_rsp_valid, s_rsp_error, m_req_valid, m_req_write, m_rsp_ready, refused_evt, idle;
  wire [31:0] s_rsp_rdata, m_req_addr, m_req_wdata;
  wire [3:0]  m_req_wstrb;
  cc_sfb_gate dut (
    .clk(clk), .rst_n(rst_n),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr),
    .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb),
    .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready), .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_error),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .refuse(refuse), .refused_evt(refused_evt), .idle(idle));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // protocol monitors
  wire s_stable_ok, s_acc, s_held;
  albion_sfb_req_mon #(.AW(32), .DW(32)) u_s (.clk(clk), .rst_n(rst_n), .valid(s_req_valid), .ready(s_req_ready), .write(s_req_write),
    .addr(s_req_addr), .wdata(s_req_wdata), .wstrb(s_req_wstrb), .stable_ok(s_stable_ok), .accepted(s_acc), .held(s_held));
  wire m_stable_ok, m_acc, m_held;
  albion_sfb_req_mon #(.AW(32), .DW(32)) u_m (.clk(clk), .rst_n(rst_n), .valid(m_req_valid), .ready(m_req_ready), .write(m_req_write),
    .addr(m_req_addr), .wdata(m_req_wdata), .wstrb(m_req_wstrb), .stable_ok(m_stable_ok), .accepted(m_acc), .held(m_held));
  wire mr_stable_ok, mr_solicited_ok, mr_errdata_ok, mr_hs;
  wire [3:0] mr_out;
  albion_sfb_rsp_mon #(.DW(32), .OW(4)) u_mr (.clk(clk), .rst_n(rst_n), .req_acc(m_acc), .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready),
    .rsp_rdata(m_rsp_rdata), .rsp_error(m_rsp_error), .stable_ok(mr_stable_ok), .solicited_ok(mr_solicited_ok), .errdata_ok(mr_errdata_ok),
    .outstanding(mr_out), .rsp_hs(mr_hs));

  // spec model of the gate's obligations
  reg fwd_pend, loc_pend, loc_prev;
  wire loc_acc  = s_acc && !m_req_valid;                 // accepted locally (refused), not forwarded
  wire s_rsp_hs = s_rsp_valid && s_rsp_ready;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fwd_pend <= 1'b0; loc_pend <= 1'b0; loc_prev <= 1'b0;
    end else begin
      fwd_pend <= (fwd_pend && !mr_hs) || m_acc;
      loc_pend <= (loc_pend && !(s_rsp_hs)) || loc_acc;
      loc_prev <= loc_acc;
    end
  end
  wire free = !fwd_pend && !loc_pend;
  wire refuse_eff = refuse && !m_held;                  // a request already presented downstream is never withdrawn

  always @(*) begin
    `ALB_ASSUME(e_up_r2,   "ENV-GATE-R2 upstream keeps a presented request and its payload until accepted", s_stable_ok)
    `ALB_ASSUME(e_dn_r4,   "ENV-GATE-R4 downstream holds a response until rsp_ready", mr_stable_ok)
    `ALB_ASSUME(e_dn_r5,   "ENV-GATE-R5 downstream answers only an accepted, earlier forwarded request", mr_solicited_ok)
    `ALB_ASSUME(e_dn_r8,   "ENV-GATE-R8 a downstream error response carries rdata = 0", mr_errdata_ok)
  end

  always @(*) begin
    `ALB_ASSERT(1, a_fwd_not_refused_first, "[hdr] a request is presented downstream only if `refuse` was 0 in its first presentation cycle (refuse is evaluated before the request is presented)",
                `ALB_IMPL(m_req_valid && !m_held, !refuse))
    `ALB_ASSERT(2, a_refused_not_forwarded, "[hdr] a refused request (refused_evt) is never forwarded: nothing reaches the master side in that cycle", `ALB_IMPL(refused_evt, !m_req_valid))
    `ALB_ASSERT(3, a_refused_evt_exact, "refused_evt is exactly one pulse per request accepted locally (accepted and not forwarded)", refused_evt == loc_acc)
    `ALB_ASSERT(4, a_refused_resp_next_cycle, "[R8] a refused request is answered ONE cycle after acceptance with rsp_error = 1 and rdata = 0",
                `ALB_IMPL(loc_prev, s_rsp_valid && s_rsp_error && s_rsp_rdata == 32'd0))
    `ALB_ASSERT(5, a_resp_exact, "[R5] s_rsp_valid <=> a local error response is owed, or a forwarded request is outstanding and the downstream answers: one response per request, none unsolicited",
                s_rsp_valid == (loc_pend || (fwd_pend && m_rsp_valid)))
    `ALB_ASSERT(6, a_resp_passthru, "[R4,R8] a forwarded transaction's response reaches the upstream unchanged (rdata/error); local responses never leak downstream data",
                `ALB_IMPL(s_rsp_valid && !loc_pend, s_rsp_rdata == m_rsp_rdata && s_rsp_error == m_rsp_error))
    `ALB_ASSERT(7, a_backpressure_passthru, "m_rsp_ready = s_rsp_ready unless a local response is being delivered (then the downstream response waits)", m_rsp_ready == (!loc_pend && s_rsp_ready))
    `ALB_ASSERT(8, a_one_at_a_time, "[R6] a new request is accepted only when nothing is outstanding and no local response is owed", `ALB_IMPL(s_acc, free))
    `ALB_ASSERT(9, a_payload_identity, "a forwarded request is bit-identical to the upstream request (address, write, data, strobes)",
                `ALB_IMPL(m_req_valid, m_req_write == s_req_write && m_req_addr == s_req_addr && m_req_wdata == s_req_wdata && m_req_wstrb == s_req_wstrb))
    `ALB_ASSERT(10, a_downstream_r2, "[R2] once presented downstream a request is never withdrawn and its payload never changes, even if `refuse` rises while it waits",
                m_stable_ok)
    `ALB_ASSERT(11, a_valid_formula, "[R3] m_req_valid is a function of registered state, the upstream request and `refuse` only -- it has no dependence on m_req_ready in the same cycle",
                m_req_valid == (s_req_valid && free && !refuse_eff))
    `ALB_ASSERT(12, a_ready_formula, "s_req_ready = free && (refused ? 1 : m_req_ready): a request is never accepted while the gate is busy, a refused one is accepted at once",
                s_req_ready == (free && (refuse_eff || m_req_ready)))
    `ALB_ASSERT(13, a_idle_exact, "idle <=> nothing outstanding and nothing waiting downstream", idle == (free && !m_req_valid))
    `ALB_ASSERT(14, a_outstanding_le1, "at most one transaction is ever outstanding on the master side", mr_out <= 4'd1)
    `ALB_ASSERT(15, a_reset_no_forward, "[R11-style] no request is presented downstream while reset is asserted (reset quietness: NOT implemented -- finding SRAM-F2)",
                `ALB_IMPL(!rst_n, !m_req_valid))
  end
  always @(*) begin
    `ALB_COVER(90, c_refused,            "a request is refused locally", refused_evt)
    `ALB_COVER(91, c_forwarded,          "a request is forwarded and accepted downstream", m_acc)
    `ALB_COVER(92, c_refuse_rises_while_presented, "`refuse` rises while a request waits downstream (it is still delivered: documented behaviour)", m_held && refuse && m_req_valid)
    `ALB_COVER(93, c_local_resp_backpressured, "a local error response waits for rsp_ready", loc_pend && s_rsp_valid && !s_rsp_ready)
    `ALB_COVER(94, c_downstream_stall,   "the downstream does not accept a presented request", m_req_valid && !m_req_ready)
    `ALB_COVER(95, c_fwd_response,       "a forwarded transaction's response is delivered", s_rsp_valid && s_rsp_ready && !loc_pend)
    `ALB_COVER(96, c_busy_blocks_new,    "a new request waits because a transaction is outstanding", s_req_valid && !free && !s_req_ready)
    `ALB_COVER(97, c_forward_in_reset,   "a request is presented downstream during reset (finding SRAM-F2)", !rst_n && !init_q && m_req_valid)
  end
endmodule
`default_nettype wire
