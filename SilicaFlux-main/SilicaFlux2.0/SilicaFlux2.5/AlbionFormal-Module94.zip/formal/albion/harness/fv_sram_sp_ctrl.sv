// =============================================================================
// AlbionFormal harness :: sram_sp -- array-boundary CONTROL legality ("no illegal write enable")  [SRAM area, brief item 3]
//
// DUT   rtl:datafabric/third_party/silicaflux-sramlib/rtl/mem/sram_sp.sv  (+ sram_rsp_path); the array is the TAP shim
//       (harness/shim_sram_backend.sv, TAP=1): the array control inputs of the REAL sram_sp appear on `tst_rdata` in the same
//       cycle, so every statement below is about what the real control logic drives into the array.
// SPEC  sram_sp header comment; docs/mem/01_interface_spec.md sections 2 (invalid addresses), 4 (req_ready), 8 (test port).
// ENVIRONMENT  none beyond reset (ENV-RST-ANY): request, response-ready and test-port inputs are completely free, including
//       request payload instability and `tst_ce` without `tst_active`.  The results are therefore unconditional.
// MAPPING NOTE  `sram_sp` has no write-protection concept; "illegal write enable" is mapped to: an array write only for a
//       valid accepted functional write (addr < DEPTH, test mode off) or for a test-port write; never for an out-of-range
//       address; never in reset / the cycle after; never when a functional request is accepted in test mode.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sram_sp_ctrl #(
  parameter ALB_SEL = 0,
  parameter DW = 16, MW = 2, DEPTH = 4, LAT = 1, FIFO = 2, WACK = 1, IDW = 2,
  localparam AW = (DEPTH > 1) ? $clog2(DEPTH) : 1
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire              req_valid,
  input  wire              req_we,
  input  wire [AW-1:0]     req_addr,
  input  wire [DW-1:0]     req_wdata,
  input  wire [MW-1:0]     req_wmask,
  input  wire [IDW-1:0]    req_id,
  input  wire              rsp_ready,
  input  wire              tst_active,
  input  wire              tst_ce,
  input  wire              tst_we,
  input  wire [AW-1:0]     tst_addr,
  input  wire [DW-1:0]     tst_wdata
);
  wire              req_ready, rsp_valid, rsp_err, rsp_we, busy;
  wire [DW-1:0]     rsp_rdata, tst_rdata;
  wire [IDW-1:0]    rsp_id;

  sram_sp #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .RSP_FIFO_DEPTH(FIFO),
            .WRITE_ACK(WACK), .ID_WIDTH(IDW), .TEST_EN(1)) dut (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_we(req_we), .req_addr(req_addr), .req_wdata(req_wdata),
    .req_wmask(req_wmask), .req_id(req_id),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_err(rsp_err), .rsp_we(rsp_we), .rsp_id(rsp_id),
    .tst_active(tst_active), .tst_ce(tst_ce), .tst_we(tst_we), .tst_addr(tst_addr), .tst_wdata(tst_wdata),
    .tst_rdata(tst_rdata), .busy(busy));
  defparam dut.u_array.TAP = 1;

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // reset-release shadow: 0 in reset and in the first cycle after it (convention C2: asynchronous style)
  reg live_h;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_h <= 1'b0;
    else        live_h <= 1'b1;
  end

  // ---------------------------------------------------------------- specification model of the array boundary
  localparam HDR = 2 + MW + AW;
  wire t_on     = tst_active;
  wire addr_ok  = ({1'b0, req_addr} < DEPTH);
  wire tst_ok   = ({1'b0, tst_addr} < DEPTH);
  wire acc      = req_valid && req_ready;
  wire exp_ce   = t_on ? (tst_ce && tst_ok) : (acc && addr_ok);
  wire [DW-1:0]  exp_wd   = t_on ? tst_wdata : req_wdata;
  wire [MW-1:0]  exp_wm   = t_on ? {MW{1'b1}} : req_wmask;
  wire [AW-1:0]  exp_ad   = t_on ? tst_addr : req_addr;
  wire           exp_we   = t_on ? tst_we : req_we;
  // tap decode
  wire           tap_ce = tst_rdata[0];
  wire           tap_we = tst_rdata[1];
  wire [MW-1:0]  tap_wm = tst_rdata[2 +: MW];
  wire [AW-1:0]  tap_ad = tst_rdata[2 + MW +: AW];
  wire [DW-HDR-1:0] tap_wd = tst_rdata[DW-1:HDR];
  wire posted_valid_wr = (WACK == 0) && req_we && addr_ok;

  always @(*) begin
    `ALB_ASSERT(1, a_ce_exact, "[spec 2,8] array enable == (test mode: tst_ce on a valid test address) | (functional: accepted request with a valid address)",
                tap_ce == exp_ce)
    `ALB_ASSERT(2, a_wen_legal, "no illegal write enable: array ce&&we only for an accepted valid functional write, or a test-port write",
                `ALB_IMPL(tap_ce && tap_we, t_on ? (tst_ce && tst_we && tst_ok) : (acc && req_we && addr_ok)))
    `ALB_ASSERT(3, a_no_oob_access, "[spec 2] an out-of-range address (addr >= DEPTH) never reaches the array (read or write)",
                `ALB_IMPL(tap_ce, {1'b0, tap_ad} < DEPTH))
    `ALB_ASSERT(4, a_we_exact, "array we follows the functional req_we (test mode: tst_we); a read never sets we",
                `ALB_IMPL(tap_ce, tap_we == exp_we))
    `ALB_ASSERT(5, a_read_no_we, "an accepted functional read with a valid address performs an array READ (ce=1, we=0)",
                `ALB_IMPL(!t_on && acc && !req_we && addr_ok, tap_ce && !tap_we))
    `ALB_ASSERT(6, a_wmask_exact, "write lanes: functional wmask passes through; test writes cover all lanes [spec 8]",
                `ALB_IMPL(tap_ce, tap_wm == exp_wm))
    `ALB_ASSERT(7, a_addr_data_passthru, "array address and write data are the request's (test port's in test mode)",
                `ALB_IMPL(tap_ce, tap_ad == exp_ad && tap_wd == exp_wd[DW-HDR-1:0]))
    `ALB_ASSERT(8, a_no_func_access_in_reset, "no functional array access in reset or the cycle after it",
                `ALB_IMPL(!live_h && !t_on, !tap_ce))
    `ALB_ASSERT(9, a_ready_low_reset, "[spec 4] req_ready = 0 in reset and the cycle after", `ALB_IMPL(!live_h, !req_ready))
    `ALB_ASSERT(10, a_ready_low_test, "[spec 4,8] req_ready = 0 while tst_active (functional requests are never accepted in test mode)",
                `ALB_IMPL(t_on, !req_ready))
    `ALB_ASSERT(11, a_invalid_no_array, "[spec 2] an accepted invalid-address request never touches the array",
                `ALB_IMPL(!t_on && acc && !addr_ok, !tap_ce))
    if (WACK == 0) begin
      `ALB_ASSERT(12, a_ready_posted_write, "[spec 4] a posted valid write needs no response credit: req_ready = 1 whenever live and not in test mode (WRITE_ACK = 0)",
                  `ALB_IMPL(posted_valid_wr && live_h && !t_on, req_ready))
    end
  end

  always @(*) begin
    `ALB_COVER(90, c_func_write,   "a functional write reaches the array", tap_ce && tap_we && !t_on)
    `ALB_COVER(91, c_func_read,    "a functional read reaches the array", tap_ce && !tap_we && !t_on)
    `ALB_COVER(92, c_test_write,   "a test-port write reaches the array", tap_ce && tap_we && t_on)
    `ALB_COVER(93, c_invalid_accepted, "an out-of-range request is accepted (non-power-of-two DEPTH only)", acc && !addr_ok && !t_on)
    `ALB_COVER(94, c_test_oob_gated,   "an out-of-range test address is presented and gated", t_on && tst_ce && !tst_ok)
    `ALB_COVER(95, c_after_reset_wait, "a request waits in the cycle after reset release", req_valid && rst_n && !live_h)
    `ALB_COVER(96, c_posted_accept,    "a posted-write-capable request is accepted", acc && req_we && addr_ok)
    `ALB_COVER(97, c_reset_midrun,     "reset asserts after step 0", !rst_n && !init_q)
  end
endmodule
`default_nettype wire
