// =============================================================================
// AlbionFormal harness :: dma_transfer_engine  (simple single-channel DMA engine)
//
// DUT      rtl_under_test/datafabric/rtl/dma/dma_transfer_engine.sv
// SPEC     docs/datafabric/DMA.md sections 1-4 and the DUT header ("Guarantees"), SFB2 rules R2/R4/R5/R8 (PROTOCOL.md)
//
// ASSUME-SET (job "assumptions")
//   ENV-RST-ANY    reset in step 0, and at any later step for any duration (SFB2 R11: reset cancels transfers in flight)
//   ENV-SFB-R4     slave: a held response (valid && !ready) stays valid with unchanged rdata/error
//   ENV-SFB-R5     slave: a response is only given while an EARLIER-accepted request is outstanding (never in the
//                  acceptance cycle, one per request)
//   ENV-SFB-R8     slave: rsp_error => rsp_rdata == 0
//   ENV-DMA-SMALL  (only when SMALL=1) descriptor values are narrow: src,dst < 2^AB and len <= 2^AB.  The engine keeps
//                  32-bit counters, which the unbounded engine (PDR) cannot close at full width; narrowing the VALUES (not
//                  the logic) lets PDR terminate.  A proof under ENV-DMA-SMALL is CONDITIONAL and says nothing about
//                  addresses/lengths outside the narrow window; wrap/overflow behaviour is covered by the exhaustive
//                  dma_validate proof (DMA-VAL-*) and by the full-width bounded jobs (SMALL=0).
//   `start`, `abort`, `cfg_*`, `req_ready`, `rsp_rdata` are otherwise FREE (start/abort at any time, start while busy,
//   cfg changes while busy -- the real register file refuses those, the engine must not depend on it).
//
// GHOST MODEL (independent of the RTL's registers): the descriptor is captured at `go` (start while idle), then beat counters
// of OK read/write responses, the data of the last good read, a byte-accurate `bytes done`, an error latch and an abort latch
// are maintained from the PORTS only.  The reference validator is env/albion_dma_ref.sv (40-bit integers).
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_dma_engine #(
  parameter ALB_SEL      = 0,
  parameter DW           = 16,
  parameter MAX_LEN_LOG2 = 3,
  parameter SMALL        = 1,
  parameter AB           = 6
) (
  input wire          clk,
  input wire          rst_n,
  input wire          start,
  input wire          abort,
  input wire [31:0]   cfg_src,
  input wire [31:0]   cfg_dst,
  input wire [31:0]   cfg_len,
  input wire          req_ready,
  input wire          rsp_valid,
  input wire [DW-1:0] rsp_rdata,
  input wire          rsp_error
);
  localparam SB  = DW / 8;
  localparam OFF = $clog2(SB);

  // ------------------------------------------------------------------ DUT
  wire          busy, done, fail, ev_stall, rsp_ready, req_valid, req_write;
  wire [3:0]    err_code;
  wire [31:0]   err_addr, bytes_done, req_addr;
  wire [2:0]    state;
  wire [DW-1:0] req_wdata;
  wire [SB-1:0] req_wstrb;
  dma_transfer_engine #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) dut (
    .clk(clk), .rst_n(rst_n), .start(start), .abort(abort), .cfg_src(cfg_src), .cfg_dst(cfg_dst), .cfg_len(cfg_len),
    .busy(busy), .done(done), .fail(fail), .err_code(err_code), .err_addr(err_addr), .bytes_done(bytes_done),
    .state(state), .ev_stall(ev_stall),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr), .req_wdata(req_wdata),
    .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // ------------------------------------------------------------------ SFB2 monitors
  wire m_stable_ok, m_acc, m_held;
  albion_sfb_req_mon #(.AW(32), .DW(DW)) m_req (
    .clk(clk), .rst_n(rst_n), .valid(req_valid), .ready(req_ready), .write(req_write), .addr(req_addr),
    .wdata(req_wdata), .wstrb(req_wstrb), .stable_ok(m_stable_ok), .accepted(m_acc), .held(m_held));
  wire r_stable_ok, r_solicited_ok, r_errdata_ok, rsp_hs;
  wire [2:0] outstanding;
  albion_sfb_rsp_mon #(.DW(DW), .OW(3)) m_rsp (
    .clk(clk), .rst_n(rst_n), .req_acc(m_acc), .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata),
    .rsp_error(rsp_error), .stable_ok(r_stable_ok), .solicited_ok(r_solicited_ok), .errdata_ok(r_errdata_ok),
    .outstanding(outstanding), .rsp_hs(rsp_hs));

  // ------------------------------------------------------------------ environment
  always @(*) begin
    `ALB_ASSUME(e_rsp_stable,    "ENV-SFB-R4 held response stays valid and unchanged", r_stable_ok)
    `ALB_ASSUME(e_rsp_solicited, "ENV-SFB-R5 response only for an earlier-accepted outstanding request", r_solicited_ok)
    `ALB_ASSUME(e_rsp_errdata,   "ENV-SFB-R8 rsp_error implies rsp_rdata == 0", r_errdata_ok)
    if (SMALL != 0) begin
      `ALB_ASSUME(e_small, "ENV-DMA-SMALL src,dst < 2^AB and len <= 2^AB", cfg_src < (32'd1 << AB) && cfg_dst < (32'd1 << AB) && cfg_len <= (32'd1 << AB))
    end
  end

  // ------------------------------------------------------------------ ghost model
  wire go = start && !busy;
  reg         g_started, g_err, g_rd_err, g_rd_ok, g_out_wr, g_abort_seen, g_abort_prev, g_go_prev, g_term_prev;
  reg [31:0]  g_src, g_dst, g_len, g_bd, bd_prev, g_exp_rd, g_exp_wr, g_rem;
  reg [33:0]  g_rd_ok_cnt, g_wr_ok_cnt;
  reg [DW-1:0] g_rdata;
  wire        ref_legal, rf_zero, rf_long, rf_salign, rf_dalign, rf_sovf, rf_dovf, rf_ovl;
  wire [3:0]  ref_code;
  albion_dma_ref_validate #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) u_ref (
    .src(g_src), .dst(g_dst), .len(g_len), .legal(ref_legal), .code(ref_code),
    .f_zero(rf_zero), .f_long(rf_long), .f_salign(rf_salign), .f_dalign(rf_dalign), .f_sovf(rf_sovf), .f_dovf(rf_dovf), .f_ovl(rf_ovl));

  wire [33:0] gs = {2'b0, g_src}, gd = {2'b0, g_dst}, gl = {2'b0, g_len};
  wire [33:0] g_src_end = gs + gl;
  wire [33:0] g_dst_end = gd + gl;
  wire [33:0] g_nb      = (gl + (SB - 1)) >> OFF;
  wire [33:0] ra        = {2'b0, req_addr};
  wire [33:0] beat_off  = g_wr_ok_cnt << OFF;
  wire [31:0] take      = (g_rem >= SB) ? SB : g_rem;      // bytes moved by the next completed beat (spec: min(DW/8, remaining))

  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      g_started <= 1'b0; g_err <= 1'b0; g_rd_err <= 1'b0; g_rd_ok <= 1'b0; g_out_wr <= 1'b0;
      g_abort_seen <= 1'b0; g_abort_prev <= 1'b0; g_go_prev <= 1'b0; g_term_prev <= 1'b0;
      g_src <= 32'd0; g_dst <= 32'd0; g_len <= 32'd0; g_bd <= 32'd0; bd_prev <= 32'd0; g_exp_rd <= 32'd0; g_exp_wr <= 32'd0; g_rem <= 32'd0;
      g_rd_ok_cnt <= 34'd0; g_wr_ok_cnt <= 34'd0; g_rdata <= {DW{1'b0}};
    end else begin
      g_go_prev    <= go;
      g_term_prev  <= done || fail;
      bd_prev      <= bytes_done;
      g_abort_prev <= g_abort_seen;
      if (!busy)       g_abort_seen <= 1'b0;
      else if (abort)  g_abort_seen <= 1'b1;
      if (m_acc) g_out_wr <= req_write;
      if (go) begin
        g_started <= 1'b1; g_src <= cfg_src; g_dst <= cfg_dst; g_len <= cfg_len;
        g_err <= 1'b0; g_rd_err <= 1'b0; g_rd_ok <= 1'b0; g_rd_ok_cnt <= 34'd0; g_wr_ok_cnt <= 34'd0; g_bd <= 32'd0;
        g_exp_rd <= cfg_src; g_exp_wr <= cfg_dst; g_rem <= cfg_len;
      end else if (rsp_hs) begin
        if (rsp_error) begin
          g_err <= 1'b1; g_rd_ok <= 1'b0;
          if (!g_out_wr) g_rd_err <= 1'b1;
        end else if (!g_out_wr) begin
          g_rd_ok <= 1'b1; g_rdata <= rsp_rdata; g_rd_ok_cnt <= g_rd_ok_cnt + 34'd1;
        end else begin
          g_rd_ok <= 1'b0; g_wr_ok_cnt <= g_wr_ok_cnt + 34'd1;
          g_bd <= g_bd + take; g_rem <= g_rem - take; g_exp_rd <= g_exp_rd + SB; g_exp_wr <= g_exp_wr + SB;
        end
      end
    end
  end

  reg busy_d;                                    // NOT reset: remembers `busy` across a reset step (async2sync shows reset values in the reset step)
  always @(posedge clk) busy_d <= busy;

  // byte-accurate strobe checks of the presented write
  reg strb_exact_ok, strb_inside_ok;
  integer b;
  always @(*) begin
    strb_exact_ok = 1'b1; strb_inside_ok = 1'b1;
    for (b = 0; b < SB; b = b + 1) begin
      if (req_wstrb[b] != ((ra + b) < g_dst_end)) strb_exact_ok = 1'b0;
      if (req_wstrb[b] && !(((ra + b) < g_dst_end) && ((ra + b) >= gd))) strb_inside_ok = 1'b0;
    end
  end
  wire req_first = req_valid && !m_held;
  wire rd_req    = req_valid && !req_write;
  wire wr_req    = req_valid && req_write;

  // ------------------------------------------------------------------ properties
  always @(*) begin
    // -- state coherence (DMA.md 1, 4)
    `ALB_ASSERT(1,  a_busy_iff_not_idle,   "[DMA.md 1] BUSY == (state != IDLE)", busy == (state != 3'd0))
    `ALB_ASSERT(2,  a_done_xor_fail,       "[DMA.md 1] DONE and ERROR are never raised together", !(done && fail))
    `ALB_ASSERT(3,  a_terminal_busy,       "[DMA.md 1] DONE/ERROR coincide with BUSY (no 'not busy and no outcome' window)", !(done || fail) || busy)
    `ALB_ASSERT(4,  a_terminal_one_cycle,  "DONE/ERROR is a one-cycle pulse followed by IDLE", !g_term_prev || state == 3'd0)
    `ALB_ASSERT(5,  a_req_state_coherent,  "[DMA.md 4] a request is presented only in ISSUE_READ (read) / ISSUE_WRITE (write)",
                !req_valid || (state == 3'd2 && !req_write) || (state == 3'd4 && req_write))
    `ALB_ASSERT(6,  a_rsp_ready_wait,      "[DMA.md 4] rsp_ready == 1 exactly in WAIT_READ / WAIT_WRITE", rsp_ready == (state == 3'd3 || state == 3'd5))
    // -- reset (DMA.md 4 'reset returns the engine to IDLE ... no request until the next START')
    `ALB_ASSERT(7,  a_reset_state,         "[DMA.md 4] reset: IDLE, no request, bytes_done 0, error code NONE", rst_n || (state == 3'd0 && !req_valid && !busy && bytes_done == 32'd0 && err_code == 4'd0))
    `ALB_ASSERT(8,  a_no_req_before_start, "[DMA.md 4] after reset no request and not busy until a START is accepted", g_started || (!req_valid && !busy))
    // -- validation before any bus access (DMA.md 2)
    `ALB_ASSERT(9,  a_no_req_illegal,      "[DMA.md 2] a request is only presented for a descriptor that passes validation (illegal => no bus access, no memory mutation)", !req_valid || (g_started && ref_legal))
    `ALB_ASSERT(10, a_fail_code_illegal,   "[DMA.md 2] a descriptor failing validation ends in ERROR with exactly the documented first-failing-rule code", !(fail && g_started && !ref_legal) || err_code == ref_code)
    `ALB_ASSERT(11, a_fail_code_legal,     "[DMA.md 2/4] a legal descriptor never reports a validation code (1..7): only READ_BUS/WRITE_BUS/ABORTED", !(fail && g_started && ref_legal) || (err_code >= 4'd8 && err_code <= 4'd10))
    `ALB_ASSERT(12, a_fail_has_code,       "ERROR always carries a non-NONE documented code (1..10)", !fail || (err_code != 4'd0 && err_code <= 4'd10))
    // -- request address / range (DMA.md 2, DUT header)
    `ALB_ASSERT(13, a_rd_addr_tracks_beat, "reads walk the source one word per completed beat: addr == expected-next-read register (src, src+DW/8, ...): no duplicate or skipped read", !rd_req || (req_addr == g_exp_rd))
    `ALB_ASSERT(14, a_wr_addr_tracks_beat, "writes walk the destination one word per completed beat: addr == expected-next-write register (dst, dst+DW/8, ...): no duplicate or skipped write", !wr_req || (req_addr == g_exp_wr))
    `ALB_ASSERT(15, a_rd_in_src_range,     "[DMA.md 2] every read address lies inside [src, src+len)", !rd_req || (ra >= gs && ra < g_src_end))
    `ALB_ASSERT(16, a_wr_in_dst_range,     "[DMA.md 2] every write address lies inside [dst, dst+len)", !wr_req || (ra >= gd && ra < g_dst_end))
    `ALB_ASSERT(17, a_rd_no_wrap,          "the read word never crosses 2^32 (no address wrap)", !rd_req || (ra + SB <= 34'h1_0000_0000))
    `ALB_ASSERT(18, a_wr_no_wrap,          "the written word never crosses 2^32 (no address wrap)", !wr_req || (ra + SB <= 34'h1_0000_0000))
    `ALB_ASSERT(19, a_wr_strb_exact,       "[DMA.md 2] write strobes are byte-exact: byte b is written iff addr+b < dst+len", !wr_req || strb_exact_ok)
    `ALB_ASSERT(20, a_wr_strb_no_overrun,  "[DMA.md 2] no strobed byte lies outside [dst, dst+len): bytes after the end are never modified", !wr_req || strb_inside_ok)
    // -- protocol obligations of the DUT as SFB2 master (PROTOCOL R2, R6)
    `ALB_ASSERT(21, a_req_stable,          "[SFB2 R2] a presented request stays presented with an unchanged payload until accepted (never withdrawn)", m_stable_ok)
    `ALB_ASSERT(22, a_one_outstanding,     "[SFB2 R6/DMA.md 4] exactly one transaction in flight: nothing presented while one is outstanding", outstanding <= 3'd1 && (!req_valid || outstanding == 3'd0))
    `ALB_ASSERT(23, a_rsp_always_taken,    "[DMA.md 4] every response is consumed in the cycle it arrives (rsp_ready whenever a response can be outstanding)", outstanding == 3'd0 || rsp_ready)
    // -- ordering / data path
    `ALB_ASSERT(24, a_beat_counters_valid, "transfer counters valid: writes done <= reads done <= writes done + 1, reads done <= ceil(len/(DW/8))", g_wr_ok_cnt <= g_rd_ok_cnt && g_rd_ok_cnt <= g_wr_ok_cnt + 34'd1 && g_rd_ok_cnt <= g_nb)
    `ALB_ASSERT(25, a_wr_after_good_read,  "[DMA.md 4] a write is presented only after an error-free read response of its beat (flag form)", !wr_req || g_rd_ok)
    `ALB_ASSERT(26, a_wdata_from_read,     "[DMA.md 4] the write data equals the data returned by that read", !wr_req || req_wdata == g_rdata)
    `ALB_ASSERT(27, a_no_req_after_error,  "[DMA.md 4] after any bus error no further request is presented in this transfer", !g_err || !req_valid)
    `ALB_ASSERT(28, a_no_wr_after_rd_err,  "[DMA.md 4] after a read error no write is presented", !g_rd_err || !wr_req)
    // -- accounting (DMA.md 4 'BYTES_DONE is always the contiguous prefix whose writes completed')
    `ALB_ASSERT(29, a_bytes_done_le_len,   "bytes_done never exceeds the validated LENGTH", bytes_done <= g_len)
    `ALB_ASSERT(30, a_bytes_done_monotone, "bytes_done never decreases within a transfer (it restarts only at START)", g_go_prev || bytes_done >= bd_prev)
    `ALB_ASSERT(31, a_bytes_done_ghost,    "[DMA.md 4] bytes_done == bytes of the contiguous prefix of OK write responses (byte-accurate, ghost model)", bytes_done == g_bd)
    `ALB_ASSERT(32, a_bytes_done_prefix,   "bytes_done is a whole number of beats unless the transfer is complete", bytes_done[OFF-1:0] == {OFF{1'b0}} || bytes_done == g_len)
    `ALB_ASSERT(33, a_done_all_consumed,   "[DMA.md 1/4] DONE => every byte of LENGTH has been moved: remaining bytes (ghost) == 0 and bytes_done == ghost bytes-done", !done || (g_rem == 32'd0 && bytes_done == g_bd))
    `ALB_ASSERT(41, a_wr_beat_one_ahead,   "a write is presented only when exactly one more read than write has completed (the read of THIS beat; counter form)", !wr_req || g_rd_ok_cnt == g_wr_ok_cnt + 34'd1)
    `ALB_ASSERT(42, a_done_no_error,       "[DMA.md 1/4] DONE => no bus error was seen in the transfer and nothing is outstanding", !done || (!g_err && outstanding == 3'd0))
    `ALB_ASSERT(43, a_done_legal,          "[DMA.md 1/2] DONE => the descriptor passed validation", !done || ref_legal)
    `ALB_ASSERT(44, a_done_beats_exact,    "[DMA.md 4] DONE => every beat was read and written exactly once: reads OK == writes OK == ceil(len/(DW/8))", !done || (g_rd_ok_cnt == g_nb && g_wr_ok_cnt == g_nb))
    `ALB_ASSERT(45, a_done_bytes_eq_len,   "[DMA.md 1/4] DONE => bytes_done == the validated LENGTH (completed transfers have consistent accounting)", !done || bytes_done == g_len)
    `ALB_ASSERT(34, a_terminal_drained,    "DONE/ERROR only after the last transaction's response was consumed: nothing presented or outstanding", !(done || fail) || (!req_valid && outstanding == 3'd0))
    `ALB_ASSERT(35, a_err_addr_read,       "[DMA.md 2] on a bus error ERROR_ADDR is the failing beat's address: the expected-next-read register (READ_BUS)",
                !(fail && err_code == 4'd8) || err_addr == g_src + {g_wr_ok_cnt[29:0], {OFF{1'b0}}})
    `ALB_ASSERT(36, a_err_addr_write,      "[DMA.md 2] ERROR_ADDR of a WRITE_BUS error is the expected-next-write register (destination of the failing beat)",
                !(fail && err_code == 4'd9) || err_addr == g_exp_wr)
    `ALB_ASSERT(39, a_rd_addr_arith,       "reads (arithmetic form): addr == src + (completed beats)*DW/8 in 34-bit integers", !rd_req || (ra == gs + beat_off))
    `ALB_ASSERT(40, a_wr_addr_arith,       "writes (arithmetic form): addr == dst + (completed beats)*DW/8 in 34-bit integers", !wr_req || (ra == gd + beat_off))
    // -- abort (DMA.md 4 'takes effect at the next beat boundary')
    `ALB_ASSERT(37, a_abort_no_new_request,"[DMA.md 4] once an abort has been seen no NEW request is started (it is applied at the next beat boundary)", !(req_first && g_abort_prev))
    `ALB_ASSERT(38, a_abort_drains,        "[DMA.md 4] ABORTED is reported only with nothing in flight: the engine never withdraws or abandons a request", !(fail && err_code == 4'd10) || (outstanding == 3'd0 && !req_valid))
    // ------------------------------------------------------------------ covers (non-vacuity of the environment)
    `ALB_COVER(90,  c_done,          "a transfer completes (DONE)", done)
    `ALB_COVER(91,  c_multi_beat,    "two beats are written (counters exercised)", g_wr_ok_cnt >= 34'd2)
    `ALB_COVER(92,  c_partial_tail,  "a partial final write strobe is presented", wr_req && req_wstrb != {SB{1'b1}})
    `ALB_COVER(93,  c_read_error,    "READ_BUS error path", fail && err_code == 4'd8)
    `ALB_COVER(94,  c_write_error,   "WRITE_BUS error path", fail && err_code == 4'd9)
    `ALB_COVER(95,  c_aborted,       "ABORTED path", fail && err_code == 4'd10)
    `ALB_COVER(96,  c_val_zero,      "descriptor rejected: ZERO_LENGTH", fail && err_code == 4'd1)
    `ALB_COVER(97,  c_val_length,    "descriptor rejected: LENGTH", fail && err_code == 4'd2)
    `ALB_COVER(98,  c_val_align,     "descriptor rejected: SRC_ALIGN or DST_ALIGN", fail && (err_code == 4'd3 || err_code == 4'd4))
    `ALB_COVER(99,  c_val_overlap,   "descriptor rejected: OVERLAP", fail && err_code == 4'd7)
    `ALB_COVER(100, c_val_overflow,  "descriptor rejected: SRC/DST_OVERFLOW (needs wide addresses: unreachable under ENV-DMA-SMALL)", fail && (err_code == 4'd5 || err_code == 4'd6))
    `ALB_COVER(101, c_stall,         "a request waits for acceptance (back-pressure)", req_valid && !req_ready)
    `ALB_COVER(102, c_reset_mid,     "reset hits while a transfer is in flight", !rst_n && busy_d)
    `ALB_COVER(103, c_abort_done,    "DONE although an abort was seen (abort raced the last beat)", done && g_abort_seen)
    `ALB_COVER(104, c_restart,       "a second transfer is started after a first one that read data", go && g_rd_ok_cnt != 34'd0)
  end
endmodule
`default_nettype wire
