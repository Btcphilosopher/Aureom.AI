// =============================================================================
// AlbionFormal harness :: sram_sp -- DATA / TIMING / ORDERING against the reference scoreboard   [SRAM area, brief item 3]
//
// DUT   rtl:.../sram_sp.sv + sram_rsp_path.sv + the REAL sram_generic_1rw array (shim TAP=0)
// SPEC  sram_sp header comment; docs/mem/01_interface_spec.md sections 2-4, 8, 9.
// MODEL env/albion_sram_sb.sv -- single symbolic address `ta` (a proof for every ta is a proof for every word), per-lane shadow with
//       learning of never-written lanes, exact-latency response queue (see that file).  The array-boundary events fed to the model are
//       computed from the DUT's INPUT ports by the spec (functional accept / test port), and the model is compared with
//       tst_rdata (raw array output) and with the response channel.
// ENVIRONMENT   ENV-RST-ANY (reset at step 0, then any time) and ENV-SRAM-TA ("ta" is a valid word address: this is the
//       quantified address of the scoreboard, not a restriction of the environment; invalid addresses are covered by the err checks).
//       Request payload stability is NOT assumed (the DUT never depends on it); rsp_ready and the test port are free.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sram_sp_data #(
  parameter ALB_SEL = 0,
  parameter DW = 16, MW = 2, DEPTH = 4, LAT = 1, FIFO = 2, WACK = 1, IDW = 2,
  localparam AW = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam QD = (FIFO > 0) ? FIFO : LAT
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire              req_valid,
  input  wire              req_we,
  input  wire [AW-1:0]     req_addr,
  input  wire [DW-1:0]     req_wdata,
  input  wire [MW-1:0]     req_wmask,
  input  wire [IDW-1:0]    req_id,
  input  wire              rsp_ready,
  input  wire              tst_active,
  input  wire              tst_ce,
  input  wire              tst_we,
  input  wire [AW-1:0]     tst_addr,
  input  wire [DW-1:0]     tst_wdata
);
  wire              req_ready, rsp_valid, rsp_err, rsp_we, busy;
  wire [DW-1:0]     rsp_rdata, tst_rdata;
  wire [IDW-1:0]    rsp_id;

  sram_sp #(.DATA_WIDTH(DW), .DEPTH(DEPTH), .MASK_WIDTH(MW), .READ_LATENCY(LAT), .RSP_FIFO_DEPTH(FIFO),
            .WRITE_ACK(WACK), .ID_WIDTH(IDW), .TEST_EN(1)) dut (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_we(req_we), .req_addr(req_addr), .req_wdata(req_wdata),
    .req_wmask(req_wmask), .req_id(req_id),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_err(rsp_err), .rsp_we(rsp_we), .rsp_id(rsp_id),
    .tst_active(tst_active), .tst_ce(tst_ce), .tst_we(tst_we), .tst_addr(tst_addr), .tst_wdata(tst_wdata),
    .tst_rdata(tst_rdata), .busy(busy));
  defparam dut.u_array.TAP = 0;

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));
  reg live_h;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_h <= 1'b0;
    else        live_h <= 1'b1;
  end

  (* anyconst *) wire [AW-1:0] ta;

  wire t_on    = tst_active;
  wire addr_ok = ({1'b0, req_addr} < DEPTH);
  wire tst_ok  = ({1'b0, tst_addr} < DEPTH);
  wire acc     = req_valid && req_ready;
  wire needs_rsp = !req_we || (WACK != 0) || !addr_ok;
  wire arr_ce  = t_on ? (tst_ce && tst_ok) : (acc && addr_ok);
  wire arr_we  = t_on ? tst_we : req_we;
  wire [MW-1:0] arr_wm = t_on ? {MW{1'b1}} : req_wmask;
  wire [AW-1:0] arr_ad = t_on ? tst_addr : req_addr;
  wire [DW-1:0] arr_wd = t_on ? tst_wdata : req_wdata;

  wire ok_raw, ok_rsp_valid, ok_err, ok_we, ok_id, ok_zero, ok_data, ok_stable, ov;
  wire [3:0] qcount;
  wire cv_raw_checked, cv_raw_partial, cv_raw_unwritten, cv_partial_write, cv_backpressure, cv_full, cv_err_rsp, cv_data_checked;
  albion_sram_sb #(.DW(DW), .MW(MW), .AW(AW), .DEPTH(DEPTH), .LAT(LAT), .QD(QD), .WACK(WACK), .IDW(IDW), .CHECK_WE(1), .CHECK_ID(1)) sb (
    .clk(clk), .rst_n(rst_n), .ta(ta),
    .arr_ce(arr_ce), .arr_we(arr_we), .arr_wmask(arr_wm), .arr_addr(arr_ad), .arr_wdata(arr_wd), .raw_rdata(tst_rdata),
    .acc(acc), .acc_we(req_we), .acc_addr(req_addr), .acc_id(req_id),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_err(rsp_err), .rsp_we(rsp_we), .rsp_id(rsp_id),
    .ok_raw(ok_raw), .ok_rsp_valid(ok_rsp_valid), .ok_err(ok_err), .ok_we(ok_we), .ok_id(ok_id), .ok_zero(ok_zero), .ok_data(ok_data),
    .ok_stable(ok_stable), .ov(ov), .qcount(qcount),
    .cv_raw_checked(cv_raw_checked), .cv_raw_partial(cv_raw_partial), .cv_raw_unwritten(cv_raw_unwritten),
    .cv_partial_write(cv_partial_write), .cv_backpressure(cv_backpressure), .cv_full(cv_full), .cv_err_rsp(cv_err_rsp),
    .cv_data_checked(cv_data_checked));

  // "an outstanding response existed in the previous cycle" -- NOT reset (the async-cleared queue is already empty in a reset step)
  reg out_prev;
  always @(posedge clk) out_prev <= (qcount != 4'd0);

  always @(*) begin
    `ALB_ASSUME(e_ta_valid, "ENV-SRAM-TA the tracked word address is a valid word (the scoreboard quantifies over every valid address)", ta < DEPTH)
    if (FIFO == 0) begin
      `ALB_ASSUME(e_rsp_ready_always, "ENV-SRAM-RSP1 RSP_FIFO_DEPTH = 0 has no response storage: the master must keep rsp_ready = 1 (spec 4, no-backpressure mode)", rsp_ready)
    end
  end

  always @(*) begin
    `ALB_ASSERT(20, a_raw_lanes, "[spec 2,3,8,9] array output exactly READ_LATENCY after a read equals the shadow on every known lane: masked writes change only their lanes; never-written lanes stay unchanged",
                ok_raw)
    `ALB_ASSERT(21, a_rsp_valid_exact, "[spec 4] rsp_valid <=> the oldest outstanding request has aged >= READ_LATENCY: never early, never dropped, never unsolicited, never duplicated; posted valid writes (WRITE_ACK=0) produce no response",
                ok_rsp_valid)
    `ALB_ASSERT(22, a_rsp_err, "[spec 2] rsp_err is set exactly for out-of-range addresses (also for posted writes: errors are never silent)", ok_err)
    `ALB_ASSERT(23, a_rsp_we, "[spec 4] rsp_we marks the response of a write request", ok_we)
    `ALB_ASSERT(24, a_rsp_id, "[spec 4] rsp_id equals the req_id of the request the response belongs to (transaction identifiers stay valid, in order)", ok_id)
    `ALB_ASSERT(25, a_rsp_zero, "[spec 4] read data of write acknowledgements and error responses is all-zero", ok_zero)
    `ALB_ASSERT(26, a_rsp_data, "[spec 3,4] read response data = shadow word (known lanes) -- also under response back-pressure", ok_data)
    `ALB_ASSERT(27, a_credit_bound, "[spec 4] outstanding responses never exceed RSP_FIFO_DEPTH: the response FIFO cannot overflow", !ov)
    `ALB_ASSERT(28, a_rsp_stable, "[spec 4] rsp_* hold stable while rsp_valid && !rsp_ready", ok_stable)
    `ALB_ASSERT(29, a_busy_exact, "busy == (some response outstanding)", busy == (qcount != 4'd0))
    `ALB_ASSERT(30, a_reset_state, "[spec 1,4] reset: req_ready = 0, rsp_valid = 0, busy = 0 (control state cleared; array not touched)",
                `ALB_IMPL(!rst_n, !req_ready && !rsp_valid && !busy))
    if (FIFO > 0) begin
      `ALB_ASSERT(31, a_ready_exact, "[spec 4] req_ready <=> not test mode && live && (a response credit is free || the request needs no response)",
                  req_ready == (!t_on && live_h && ((qcount < QD) || !needs_rsp)))
    end
    `ALB_ASSERT(32, a_ready_low_reset, "[spec 4] req_ready = 0 in reset and the cycle after", `ALB_IMPL(!live_h, !req_ready))
    `ALB_ASSERT(33, a_ready_low_test, "[spec 4,8] req_ready = 0 in test mode", `ALB_IMPL(t_on, !req_ready))
  end

  always @(*) begin
    `ALB_COVER(90, c_known_read,      "a read of a known lane is checked against the shadow", cv_raw_checked)
    `ALB_COVER(91, c_partial_known,   "a read where only some lanes are known (masked write left the others unwritten)", cv_raw_partial)
    `ALB_COVER(92, c_unwritten_reread,"a lane no write ever touched is re-read and compared (learned stability)", cv_raw_unwritten)
    `ALB_COVER(93, c_partial_write,   "a masked write (some lanes) is performed", cv_partial_write)
    `ALB_COVER(94, c_backpressure,    "response back-pressure (rsp_valid && !rsp_ready)", cv_backpressure)
    `ALB_COVER(95, c_credits_full,    "all response credits in use", cv_full)
    `ALB_COVER(96, c_err_response,    "an out-of-range request produces an error response (non-power-of-two DEPTH)", cv_err_rsp)
    `ALB_COVER(97, c_rsp_data_checked,"a response of a tracked read with known lanes is checked", cv_data_checked)
    `ALB_COVER(98, c_test_while_busy, "test mode is entered while a response is outstanding", t_on && qcount != 4'd0)
    `ALB_COVER(99, c_reset_with_outstanding, "reset while a response is outstanding (cancels it)", !rst_n && !init_q && out_prev)
    `ALB_COVER(100, c_test_write_tracked, "a test-port write to the tracked word", t_on && tst_ce && tst_we && tst_ok && tst_addr == ta)
  end
endmodule
`default_nettype wire
