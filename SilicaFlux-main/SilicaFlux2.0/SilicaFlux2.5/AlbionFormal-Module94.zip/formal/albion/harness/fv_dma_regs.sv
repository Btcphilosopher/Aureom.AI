// =============================================================================
// AlbionFormal harness :: dma_control_regs (+ dma_irq)  -- DMA register file
//
// DUT      rtl_under_test/datafabric/rtl/dma/dma_control_regs.sv, dma_irq.sv, dma_defs.svh
// SPEC     docs/datafabric/DMA.md sections 1, 3 ("Busy-state protection"), 6 (interrupts), 7 (performance registers) and the
//          register table (offsets / fields) in dma_defs.svh
//
// ASSUME-SET (job "assumptions")
//   ENV-RST-ANY   reset in step 0 and later
//   ENV-DMA-ENG-1 the engine never raises DONE and ERROR together               (asserted for the engines: a_done_xor_fail)
//   ENV-DMA-ENG-2 DONE / ERROR are raised only while BUSY                       (asserted for the engines: a_terminal_busy)
//   ENV-DMA-ENG-3 the engine's error code is one of the documented codes 0..10  (asserted: a_fail_has_code / engine codes)
//   The register bus (rb_sel/rb_we/rb_addr/rb_wdata) and every other engine input (busy, bytes_done, err_addr, state,
//   ev_stall) are FREE: the register file must be correct for any bus traffic and any engine status.
//
// REFERENCE MODEL (independent, from the spec): cfg registers, IE, IS (set wins over W1C), STATUS flags and the performance
// counters, advanced by the same events; the read mux and the error rule of every access are modelled per register.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_dma_regs #(
  parameter ALB_SEL      = 0,
  parameter DW           = 32,
  parameter ENGINE       = 0,
  parameter FIFO_DEPTH   = 4,
  parameter MAX_LEN_LOG2 = 24,
  parameter PERF         = 1
) (
  input wire        clk,
  input wire        rst_n,
  input wire        rb_sel,
  input wire        rb_we,
  input wire [11:0] rb_addr,
  input wire [31:0] rb_wdata,
  input wire        busy,
  input wire        done,
  input wire        fail,
  input wire [3:0]  err_code,
  input wire [31:0] err_addr,
  input wire [31:0] bytes_done,
  input wire [2:0]  state,
  input wire        ev_stall
);
  localparam [11:0] A_CONTROL = 12'h000, A_STATUS = 12'h004, A_SRC = 12'h008, A_DST = 12'h00C, A_LEN = 12'h010,
                    A_BYTES = 12'h014, A_IE = 12'h018, A_IS = 12'h01C, A_ECODE = 12'h020, A_EADDR = 12'h024,
                    A_INFO = 12'h028, A_ID = 12'h02C, A_ACT = 12'h030, A_STL = 12'h034, A_XFER = 12'h038;

  wire [31:0] rb_rdata, cfg_src, cfg_dst, cfg_len;
  wire        rb_err, start, abort, irq;
  dma_control_regs #(.DW(DW), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .MAX_LEN_LOG2(MAX_LEN_LOG2), .PERF(PERF)) dut (
    .clk(clk), .rst_n(rst_n), .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err),
    .start(start), .abort(abort), .cfg_src(cfg_src), .cfg_dst(cfg_dst), .cfg_len(cfg_len),
    .busy(busy), .done(done), .fail(fail), .err_code(err_code), .err_addr(err_addr), .bytes_done(bytes_done), .state(state),
    .ev_stall(ev_stall), .irq(irq));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  always @(*) begin
    `ALB_ASSUME(e_eng_done_xor_fail, "ENV-DMA-ENG-1 DONE and ERROR are never raised together", !(done && fail))
    `ALB_ASSUME(e_eng_term_busy,     "ENV-DMA-ENG-2 DONE / ERROR only while BUSY", !(done || fail) || busy)
    `ALB_ASSUME(e_eng_code_range,    "ENV-DMA-ENG-3 engine error code is one of the documented codes 0..10", err_code <= 4'd10)
  end

  // ------------------------------------------------------------------ reference model
  wire wr        = rb_sel && rb_we;
  wire rd        = rb_sel && !rb_we;
  wire start_req = wr && rb_addr == A_CONTROL && rb_wdata[0];
  wire is_cfg_wr = wr && !busy && (rb_addr == A_SRC || rb_addr == A_DST || rb_addr == A_LEN);

  reg [31:0] m_src, m_dst, m_len, m_act, m_stl, m_xfer, src_p, dst_p, len_p;
  reg [1:0]  m_ie, m_is;
  reg        m_done, m_err, m_abt, busy_p;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      m_src <= 32'd0; m_dst <= 32'd0; m_len <= 32'd0; m_ie <= 2'd0; m_is <= 2'd0; m_done <= 1'b0; m_err <= 1'b0; m_abt <= 1'b0;
      m_act <= 32'd0; m_stl <= 32'd0; m_xfer <= 32'd0; busy_p <= 1'b0; src_p <= 32'd0; dst_p <= 32'd0; len_p <= 32'd0;
    end else begin
      busy_p <= busy; src_p <= cfg_src; dst_p <= cfg_dst; len_p <= cfg_len;
      if (is_cfg_wr && rb_addr == A_SRC) m_src <= rb_wdata;
      if (is_cfg_wr && rb_addr == A_DST) m_dst <= rb_wdata;
      if (is_cfg_wr && rb_addr == A_LEN) m_len <= rb_wdata;
      if (wr && rb_addr == A_IE) m_ie <= rb_wdata[1:0];
      // [DMA.md 6] set wins over a same-cycle write-one-to-clear
      m_is <= ((wr && rb_addr == A_IS) ? (m_is & ~rb_wdata[1:0]) : m_is) | {fail, done};
      if (start) begin m_done <= 1'b0; m_err <= 1'b0; m_abt <= 1'b0; end
      if (done) m_done <= 1'b1;
      if (fail) begin m_err <= 1'b1; m_abt <= (err_code == 4'd10); end
      if (start) begin m_act <= 32'd0; m_stl <= 32'd0; end
      else begin
        if (busy)     m_act <= m_act + 32'd1;
        if (ev_stall) m_stl <= m_stl + 32'd1;
      end
      if (done) m_xfer <= m_xfer + 32'd1;
    end
  end

  // spec-level read data / error of every register
  localparam [7:0] ML8  = MAX_LEN_LOG2;
  localparam [3:0] FL4  = $clog2(FIFO_DEPTH);
  localparam [7:0] DWB8 = DW / 8;
  localparam       ENG1 = (ENGINE != 0);
  wire [31:0] m_info = {8'h01, ML8, FL4, 3'd0, ENG1, DWB8};       // [DMA.md 1/7] VERSION 1, MAX_LEN_LOG2, FIFO_LOG2, BUFFERED, DW bytes
  reg  [31:0] m_rdata;
  reg         m_rerr;
  always @(*) begin
    m_rdata = 32'd0; m_rerr = 1'b0;
    case (rb_addr)
      A_CONTROL: begin m_rerr = rb_we && start_req && busy; end
      A_STATUS:  begin m_rdata = {21'd0, state, 4'd0, m_abt, m_err, m_done, busy}; m_rerr = rb_we; end
      A_SRC:     begin m_rdata = m_src; m_rerr = rb_we && busy; end
      A_DST:     begin m_rdata = m_dst; m_rerr = rb_we && busy; end
      A_LEN:     begin m_rdata = m_len; m_rerr = rb_we && busy; end
      A_BYTES:   begin m_rdata = bytes_done; m_rerr = rb_we; end
      A_IE:      begin m_rdata = {30'd0, m_ie}; end
      A_IS:      begin m_rdata = {30'd0, m_is}; end
      A_ECODE:   begin m_rdata = {28'd0, err_code}; m_rerr = rb_we; end
      A_EADDR:   begin m_rdata = err_addr; m_rerr = rb_we; end
      A_INFO:    begin m_rdata = m_info; m_rerr = rb_we; end
      A_ID:      begin m_rdata = 32'h5346_4446; m_rerr = rb_we; end
      A_ACT:     begin m_rdata = m_act;  m_rerr = rb_we || (PERF == 0); end
      A_STL:     begin m_rdata = m_stl;  m_rerr = rb_we || (PERF == 0); end
      A_XFER:    begin m_rdata = m_xfer; m_rerr = rb_we || (PERF == 0); end
      default:   begin m_rerr = 1'b1; end
    endcase
    if (PERF == 0 && (rb_addr == A_ACT || rb_addr == A_STL || rb_addr == A_XFER)) m_rdata = 32'd0;
  end
  wire is_ro_reg  = rb_addr == A_STATUS || rb_addr == A_BYTES || rb_addr == A_ECODE || rb_addr == A_EADDR || rb_addr == A_INFO || rb_addr == A_ID;
  wire is_mapped  = rb_addr == A_CONTROL || rb_addr == A_STATUS || rb_addr == A_SRC || rb_addr == A_DST || rb_addr == A_LEN || rb_addr == A_BYTES ||
                    rb_addr == A_IE || rb_addr == A_IS || rb_addr == A_ECODE || rb_addr == A_EADDR || rb_addr == A_INFO || rb_addr == A_ID ||
                    rb_addr == A_ACT || rb_addr == A_STL || rb_addr == A_XFER;

  // ------------------------------------------------------------------ properties
  always @(*) begin
    `ALB_ASSERT(1,  a_read_data_model,    "register reads return the spec value of every register (cfg, IE, IS, STATUS, INFO, ID, perf, engine status) -- reference model", !rd || rb_rdata == m_rdata)
    `ALB_ASSERT(2,  a_err_model,          "[DMA.md 3] rb_err follows the spec rule of every access (refused busy writes, read-only writes, unmapped offsets, absent perf registers)", rb_err == (rb_sel && m_rerr))
    `ALB_ASSERT(3,  a_idle_bus_quiet,     "with rb_sel low the bus answers 0 / no error (no phantom access)", rb_sel || (rb_rdata == 32'd0 && !rb_err))
    `ALB_ASSERT(4,  a_start_def,          "[DMA.md 1] start == (write CONTROL.START while not busy), nothing else starts a transfer", start == (start_req && !busy))
    `ALB_ASSERT(5,  a_abort_def,          "[DMA.md 3] abort == (write CONTROL.ABORT), except that a refused START|ABORT write while busy does not abort", abort == (wr && rb_addr == A_CONTROL && rb_wdata[1] && !(start_req && busy)))
    `ALB_ASSERT(6,  a_busy_refuse_src,    "[DMA.md 3] a write to SRC_ADDR while BUSY is refused with an error", !(busy && wr && rb_addr == A_SRC) || rb_err)
    `ALB_ASSERT(7,  a_busy_refuse_dst,    "[DMA.md 3] a write to DST_ADDR while BUSY is refused with an error", !(busy && wr && rb_addr == A_DST) || rb_err)
    `ALB_ASSERT(8,  a_busy_refuse_len,    "[DMA.md 3] a write to LENGTH while BUSY is refused with an error", !(busy && wr && rb_addr == A_LEN) || rb_err)
    `ALB_ASSERT(9,  a_busy_refuse_start,  "[DMA.md 3] CONTROL.START while BUSY is refused with an error", !(busy && start_req) || rb_err)
    `ALB_ASSERT(10, a_cfg_frozen_busy,    "[DMA.md 3] the descriptor registers never change in a cycle following a BUSY cycle (the active transfer is never modified)", !busy_p || (cfg_src == src_p && cfg_dst == dst_p && cfg_len == len_p))
    `ALB_ASSERT(11, a_cfg_matches_model,  "descriptor outputs == register model (written only by non-busy writes to the three registers)", cfg_src == m_src && cfg_dst == m_dst && cfg_len == m_len)
    `ALB_ASSERT(12, a_start_ignored_busy, "[DMA.md 3] no start pulse is generated while BUSY", !busy || !start)
    `ALB_ASSERT(13, a_refused_no_abort,   "[DMA.md 3] a refused write (START while busy) has no effect at all, abort included", !(busy && start_req) || !abort)
    `ALB_ASSERT(14, a_reset_values,       "reset values: descriptor registers 0, no interrupt", rst_n || (cfg_src == 32'd0 && cfg_dst == 32'd0 && cfg_len == 32'd0 && !irq))
    `ALB_ASSERT(15, a_irq_level,          "[DMA.md 6] irq == |(INT_STATUS & INT_ENABLE), level sensitive (set wins over W1C in the model)", irq == |(m_is & m_ie))
    `ALB_ASSERT(16, a_ro_write_err,       "[DMA.md 2/3] writes to read-only registers return an error", !(wr && is_ro_reg) || rb_err)
    `ALB_ASSERT(17, a_unmapped_err,       "[DMA.md 3] accesses to unmapped offsets return an error", !(rb_sel && !is_mapped) || rb_err)
    `ALB_ASSERT(18, a_read_no_side_effect,"[DMA.md 3] reads have no side effects: a read never starts or aborts", !rd || (!start && !abort))
    `ALB_COVER(90,  c_start,         "a START is accepted", start)
    `ALB_COVER(91,  c_busy_refused,  "a busy-state write is refused", busy && wr && (rb_addr == A_SRC || rb_addr == A_DST || rb_addr == A_LEN) && rb_err)
    `ALB_COVER(92,  c_set_wins_race, "DONE and a W1C write of INT_STATUS[0] in the same cycle (set-wins race exercised)", done && wr && rb_addr == A_IS && rb_wdata[0])
    `ALB_COVER(93,  c_irq,           "the interrupt line rises", irq)
    `ALB_COVER(94,  c_aborted_flag,  "STATUS.ABORTED observable", m_abt)
    `ALB_COVER(95,  c_abort_pulse,   "an abort pulse is generated", abort)
    `ALB_COVER(96,  c_ro_write,      "a write to a read-only register is refused", wr && is_ro_reg && rb_err)
    `ALB_COVER(97,  c_cfg_written,   "a descriptor register takes a non-zero value", cfg_len != 32'd0)
    `ALB_COVER(98,  c_start_while_busy,"START written while busy (refused)", busy && start_req)
  end
endmodule
`default_nettype wire
