// =============================================================================
// AlbionFormal harness :: sfb_skid_buffer  (DataFabric two-entry valid/ready slice) -- FIFO occupancy / data integrity
// DUT   rtl_under_test/datafabric/rtl/interconnect/sfb_skid_buffer.sv
// SPEC  DUT header: 1 transfer/cycle, payload stable while m_valid && !m_ready, storage not reset.
// Method: a shadow ordered FIFO (depth 4, WIDTH bits) tracks every accepted item; the DUT output must equal its head.
// ASSUME-SET: ENV-RST-ANY only.  The upstream may withdraw and the downstream may stall arbitrarily (both free inputs).
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sfb_skid #(parameter WIDTH = 4, parameter ALB_SEL = 0) (
  input wire clk, input wire rst_n, input wire s_valid, input wire [WIDTH-1:0] s_data, input wire m_ready
);
  wire s_ready, m_valid; wire [WIDTH-1:0] m_data;
  sfb_skid_buffer #(.WIDTH(WIDTH)) dut (.clk(clk), .rst_n(rst_n), .s_valid(s_valid), .s_ready(s_ready), .s_data(s_data),
                                         .m_valid(m_valid), .m_ready(m_ready), .m_data(m_data));
  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // shadow FIFO
  reg [WIDTH-1:0] mem [0:3];
  reg [1:0] wp, rp; reg [2:0] cnt;
  wire push = s_valid && s_ready, pop = m_valid && m_ready;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin wp <= 2'd0; rp <= 2'd0; cnt <= 3'd0; end
    else begin
      if (push) begin mem[wp] <= s_data; wp <= wp + 2'd1; end
      if (pop)  rp <= rp + 2'd1;
      cnt <= cnt + {2'b0, push} - {2'b0, pop};
    end
  end
  reg held_q; reg [WIDTH-1:0] data_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) held_q <= 1'b0; else held_q <= m_valid && !m_ready;
  end
  always @(posedge clk) data_q <= m_data;

  always @(*) begin
    `ALB_ASSERT(1, a_data_in_order,   "every delivered item equals the oldest accepted item (in order, no corruption, no duplication)", `ALB_IMPL(pop, m_data == mem[rp]))
    `ALB_ASSERT(2, a_no_phantom,      "an item is only delivered if one was accepted earlier (no spurious output)", `ALB_IMPL(m_valid, cnt != 3'd0))
    `ALB_ASSERT(3, a_occupancy_bound, "FIFO occupancy never exceeds the 2 entries (output register + skid register)", cnt <= 3'd2)
    `ALB_ASSERT(4, a_no_overflow,     "no item is accepted when 2 are stored: s_ready is low when full", `ALB_IMPL(cnt == 3'd2, !s_ready))
    `ALB_ASSERT(5, a_no_loss,         "stored data is never stranded: whenever an item is buffered the output is valid", `ALB_IMPL(cnt != 3'd0, m_valid))
    `ALB_ASSERT(6, a_stable_stall,    "payload stable: m_valid && !m_ready => m_valid and m_data unchanged next cycle", `ALB_IMPL(held_q, m_valid && m_data == data_q))
    `ALB_ASSERT(7, a_reset_empty,     "reset empties the buffer: m_valid is low in reset and the shadow count is 0", `ALB_IMPL(!rst_n, !m_valid && cnt == 3'd0))
    `ALB_COVER(90, c_full,            "both entries occupied (s_ready low)", cnt == 3'd2)
    `ALB_COVER(91, c_stall,           "output stalls with data valid", m_valid && !m_ready)
    `ALB_COVER(92, c_back_to_back,    "an item is accepted and delivered in the same cycle with one buffered", push && pop && cnt == 3'd1)
    `ALB_COVER(93, c_drain_skid,      "skid register drains into the output register", pop && cnt == 3'd2)
    `ALB_COVER(94, c_withdraw,        "upstream presents data that is not accepted (s_valid & !s_ready)", s_valid && !s_ready)
  end
endmodule
`default_nettype wire
