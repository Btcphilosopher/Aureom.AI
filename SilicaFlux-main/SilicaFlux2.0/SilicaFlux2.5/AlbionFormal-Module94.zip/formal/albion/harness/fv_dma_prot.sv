// =============================================================================
// AlbionFormal harness :: silicaflux_dma (complete DMA: register file + engine) -- protected-memory integration
//
// DUT      rtl_under_test/datafabric/rtl/dma/silicaflux_dma.sv (+ dma_control_regs, dma_irq, dma_validate and the selected engine)
// SPEC     docs/datafabric/DMA.md sections 1-3: "validates the descriptor, then reads source words and writes destination
//          words"; writes target only [dst, dst+len); an invalid descriptor causes no bus access
//
// MEMORY MODEL (stated precisely).  The memory behind the DMA is an arbitrary SFB2-compliant slave (ready / response data /
// error free, subject to R4/R5/R8) plus a MUTATION MONITOR: every WRITE accepted on a master port mutates exactly the bytes
// selected by req_wstrb (SFB2 R7/R10).  No array is modelled -- this is a conservative over-approximation (an accepted write
// is counted as a mutation even if the slave later answers with an error).  The PROTECTED WINDOW is the fixed byte range
// [PB, PE).  The DMA itself has no protection logic (DMA.md: "Region legality is not known to the DMA"; SoC protection is the
// crossbar access matrix, verified in the DataFabric job family): what is proved here is that the DMA only ever mutates the
// bytes software programmed, and nothing at all for an illegal descriptor.
//
// DESCRIPTOR GHOST: taken from REGISTER-BUS TRAFFIC only (writes of SRC_ADDR/DST_ADDR/LENGTH while not busy, snapshot at the
// accepted START write), validated by the independent reference env/albion_dma_ref.sv.  It does not read the DMA's registers.
//
// ASSUME-SET: ENV-RST-ANY, ENV-SFB-R4/R5/R8 (per master port), ENV-DMA-SMALL (SMALL=1: programmed src,dst < 2^AB, len <= 2^AB).
// The register bus is free (any access, any cycle).
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_dma_prot #(
  parameter ALB_SEL      = 0,
  parameter DW           = 16,
  parameter ENGINE       = 0,
  parameter FIFO_DEPTH   = 4,
  parameter BURST        = 2,
  parameter DUAL_PORT    = 0,
  parameter MAX_OUT      = 2,
  parameter MAX_LEN_LOG2 = 3,
  parameter SMALL        = 1,
  parameter AB           = 6,
  parameter PB           = 24,
  parameter PE           = 32
) (
  input wire        clk,
  input wire        rst_n,
  input wire        rb_sel,
  input wire        rb_we,
  input wire [11:0] rb_addr,
  input wire [31:0] rb_wdata,
  input wire [((ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1)-1:0]    m_req_ready,
  input wire [((ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1)-1:0]    m_rsp_valid,
  input wire [((ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1)*DW-1:0] m_rsp_rdata,
  input wire [((ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1)-1:0]    m_rsp_error
);
  localparam SB = DW / 8;
  localparam NP = (ENGINE != 0 && DUAL_PORT != 0) ? 2 : 1;

  wire [31:0]      rb_rdata, bytes_done;
  wire             rb_err, irq, busy, ev_done;
  wire [NP-1:0]    m_req_valid, m_req_write, m_rsp_ready;
  wire [NP*32-1:0] m_req_addr;
  wire [NP*DW-1:0] m_req_wdata;
  wire [NP*SB-1:0] m_req_wstrb;
  wire [7:0]       fifo_level;
  silicaflux_dma #(.DW(DW), .ENGINE(ENGINE), .FIFO_DEPTH(FIFO_DEPTH), .BURST(BURST), .DUAL_PORT(DUAL_PORT), .MAX_OUT(MAX_OUT),
                   .MAX_LEN_LOG2(MAX_LEN_LOG2), .PERF(0)) dut (
    .clk(clk), .rst_n(rst_n), .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata), .rb_rdata(rb_rdata), .rb_err(rb_err), .irq(irq),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata),
    .m_req_wstrb(m_req_wstrb), .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .busy(busy), .ev_done(ev_done), .bytes_done(bytes_done), .fifo_level(fifo_level));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // ---- SFB2 slave environment, per master port
  wire [NP-1:0] r_stable, r_sol, r_err, m_acc, m_stable, m_held, r_hs;
  genvar gp;
  generate for (gp = 0; gp < NP; gp = gp + 1) begin : g_mon
    albion_sfb_req_mon #(.AW(32), .DW(DW)) m_req (
      .clk(clk), .rst_n(rst_n), .valid(m_req_valid[gp]), .ready(m_req_ready[gp]), .write(m_req_write[gp]), .addr(m_req_addr[gp*32 +: 32]),
      .wdata(m_req_wdata[gp*DW +: DW]), .wstrb(m_req_wstrb[gp*SB +: SB]), .stable_ok(m_stable[gp]), .accepted(m_acc[gp]), .held(m_held[gp]));
    albion_sfb_rsp_mon #(.DW(DW), .OW(3)) m_rsp (
      .clk(clk), .rst_n(rst_n), .req_acc(m_acc[gp]), .rsp_valid(m_rsp_valid[gp]), .rsp_ready(m_rsp_ready[gp]), .rsp_rdata(m_rsp_rdata[gp*DW +: DW]),
      .rsp_error(m_rsp_error[gp]), .stable_ok(r_stable[gp]), .solicited_ok(r_sol[gp]), .errdata_ok(r_err[gp]), .outstanding(), .rsp_hs(r_hs[gp]));
  end endgenerate

  wire wr = rb_sel && rb_we;
  always @(*) begin
    `ALB_ASSUME(e_rsp_stable,    "ENV-SFB-R4 held response stays valid and unchanged (all ports)", &r_stable)
    `ALB_ASSUME(e_rsp_solicited, "ENV-SFB-R5 response only for an earlier-accepted outstanding request (all ports)", &r_sol)
    `ALB_ASSUME(e_rsp_errdata,   "ENV-SFB-R8 rsp_error implies rsp_rdata == 0 (all ports)", &r_err)
    if (SMALL != 0) begin
      `ALB_ASSUME(e_small, "ENV-DMA-SMALL programmed src,dst < 2^AB and len <= 2^AB",
                  !(wr && (rb_addr == 12'h008 || rb_addr == 12'h00C)) || rb_wdata < (32'd1 << AB))
      `ALB_ASSUME(e_small_len, "ENV-DMA-SMALL programmed len <= 2^AB", !(wr && rb_addr == 12'h010) || rb_wdata <= (32'd1 << AB))
    end
  end

  // ---- descriptor ghost from register-bus traffic
  reg [31:0] r_src, r_dst, r_len, g_src, g_dst, g_len;
  reg        g_started;
  wire go = wr && rb_addr == 12'h000 && rb_wdata[0] && !busy;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      r_src <= 32'd0; r_dst <= 32'd0; r_len <= 32'd0; g_src <= 32'd0; g_dst <= 32'd0; g_len <= 32'd0; g_started <= 1'b0;
    end else begin
      if (wr && !busy && rb_addr == 12'h008) r_src <= rb_wdata;
      if (wr && !busy && rb_addr == 12'h00C) r_dst <= rb_wdata;
      if (wr && !busy && rb_addr == 12'h010) r_len <= rb_wdata;
      if (go) begin g_src <= r_src; g_dst <= r_dst; g_len <= r_len; g_started <= 1'b1; end
    end
  end
  wire        ref_legal, rf_zero, rf_long, rf_salign, rf_dalign, rf_sovf, rf_dovf, rf_ovl;
  wire [3:0]  ref_code;
  albion_dma_ref_validate #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) u_ref (
    .src(g_src), .dst(g_dst), .len(g_len), .legal(ref_legal), .code(ref_code),
    .f_zero(rf_zero), .f_long(rf_long), .f_salign(rf_salign), .f_dalign(rf_dalign), .f_sovf(rf_sovf), .f_dovf(rf_dovf), .f_ovl(rf_ovl));
  wire [33:0] gs = {2'b0, g_src}, gd = {2'b0, g_dst}, gl = {2'b0, g_len};
  wire [33:0] g_src_end = gs + gl, g_dst_end = gd + gl;

  // ---- memory mutation monitor: bytes touched by WRITES accepted this cycle
  reg  any_wr_acc, mut_outside, mut_prot, mut_src;
  integer p, b;
  reg [33:0] a;
  always @(*) begin
    any_wr_acc = 1'b0; mut_outside = 1'b0; mut_prot = 1'b0; mut_src = 1'b0; a = 34'd0;
    for (p = 0; p < NP; p = p + 1) begin
      if (m_req_valid[p] && m_req_ready[p] && m_req_write[p]) begin
        any_wr_acc = 1'b1;
        for (b = 0; b < SB; b = b + 1) begin
          if (m_req_wstrb[p*SB + b]) begin
            a = {2'b0, m_req_addr[p*32 +: 32]} + b;
            if (!(a >= gd && a < g_dst_end))     mut_outside = 1'b1;
            if (a >= PB && a < PE)               mut_prot = 1'b1;
            if (a >= gs && a < g_src_end)        mut_src = 1'b1;
          end
        end
      end
    end
  end
  wire dst_hits_window = (g_len != 32'd0) && (gd < PE) && (g_dst_end > PB);
  wire any_req = |m_req_valid;

  always @(*) begin
    `ALB_ASSERT(1, a_illegal_no_bus,       "[DMA.md 2] an invalid programmed descriptor causes no bus access of any kind (no read, no write)", !any_req || (g_started && ref_legal))
    `ALB_ASSERT(2, a_illegal_no_mem_write, "[DMA.md 2] an invalid descriptor never mutates memory: no accepted write", !any_wr_acc || (g_started && ref_legal))
    `ALB_ASSERT(3, a_write_inside_dst,     "[DMA.md 2] every byte the DMA writes lies inside the programmed [dst, dst+len): nothing else is mutated", !mut_outside)
    `ALB_ASSERT(4, a_prot_window_clean,    "protected window [PB,PE) is mutated only if the programmed destination range intersects it (end-to-end, any descriptor, any traffic)", !mut_prot || dst_hits_window)
    `ALB_ASSERT(5, a_source_untouched,     "the DMA never modifies its own source range (ranges are validated disjoint)", !mut_src)
    `ALB_ASSERT(6, a_no_bus_before_start,  "[DMA.md 4] after reset no bus access until a START is accepted", g_started || !any_req)
    `ALB_COVER(90, c_done,           "a transfer completes", ev_done)
    `ALB_COVER(91, c_write_adjacent, "a write ends exactly at the protected window's lower edge (adjacent, not touching)", any_wr_acc && !mut_prot && g_dst_end == PB && g_len != 32'd0)
    `ALB_COVER(92, c_window_hit,     "a descriptor aimed at the window really mutates it (the monitor can fire)", mut_prot)
    `ALB_COVER(93, c_illegal_started,"an illegal descriptor is started (and must stay off the bus)", g_started && !ref_legal && busy)
    `ALB_COVER(94, c_write_seen,     "a write is accepted", any_wr_acc)
    `ALB_COVER(95, c_src_range_used, "a legal transfer reads and writes (source/destination both used)", ev_done && ref_legal && g_len != 32'd0)
  end
endmodule
`default_nettype wire
