// =============================================================================
// AlbionFormal harness :: STALE-USE / INVALIDATION composition  (area "Security")
//
// DUTs     sf_citadel_domain_table  ->  sf_citadel_permission  ->  sf_citadel_gate     (ONE master port, wired as in the Citadel top:
//          gate chk_* -> checker (src_i = 0, the PHYSICAL port) <- table descriptor state; checker verdict -> gate chk_permit_i/status_i)
// SPEC     docs/citadel/03 section 7 (revocation), 04 section 2 (verdict latch, "Known limitation A-TGT"), 08 limitations 10/12
//
// MAPPING.  The brief asks "invalidation prevents stale translation use".  Citadel has NO address translation / IOMMU (08 section 3):
// there is no translation cache that could be stale.  The nearest real mechanisms are exercised here:
//   (a) the domain descriptor state (REVOKE / SET_STATE / quarantine) seen by the checker on EVERY request, and
//   (b) the gate's latched verdict, which can outlive a revocation (the documented residual).
// "Invalidated" below means: domain `fd` (solver-chosen, any 8-bit id) has NO ACTIVE slot bound to the port (act_D = 0).
//
// ENVIRONMENT (ASSUME-SET)  ENV-RST-ANY, ENV-SEC-CFG, ENV-SEC-STALE-CFG, ENV-SEC-STALE-ADDR
//   ENV-SEC-CFG         the command port is driven by ROOT with priv = 1 and cfg_en = 1 (tied), i.e. the privileged management plane
//                       (08 A-CFG); the command STREAM (opcode, slot, window, port, arguments) is completely free;
//   ENV-SEC-STALE-CFG   device-wide safety inputs of the checker are tied low (lockdown, dft, queue holds, port isolation) and the gate
//                       flush is tied low: they are other withdrawal mechanisms, not the invalidation path under test; containment
//                       (qtn_valid_i / qtn_slot_i) IS free;
//   ENV-SEC-STALE-ADDR  request addresses fit the checker's AW-bit address space (the checker is instantiated with AW=5; the gate's 64-bit
//                       address is truncated).  Master and target are otherwise completely free.
// Small parameter point: NDOM=2 NW=1 NP=1 NDEV=1 NQ=1 AW=5 LEN_W=5 (the gate always asks for len = 16).  Count/width generic logic,
// proofs at this point only.  Device 0 = 0x10..0x1F (an exclusive window may not touch it).
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_sec_stale #(
  parameter ALB_SEL = 0,
  parameter AW      = 5,
  parameter OUT_W   = 2
) (
  input wire         clk_i,
  input wire         rst_ni,
  // free privileged-plane command stream
  input wire         cmd_valid_i,
  input wire [3:0]   cmd_op_i,
  input wire         cmd_slot_i,
  input wire         cmd_win_i,
  input wire         cmd_port_i,
  input wire [7:0]   cmd_arg_dom_i,
  input wire [7:0]   cmd_flags_i,
  input wire [63:0]  cmd_data0_i,
  input wire [63:0]  cmd_data1_i,
  // free containment hook
  input wire         qtn_valid_i,
  input wire         qtn_slot_i,
  // free master / target
  input wire         m_req_valid_i,
  input wire [235:0] m_req_i,
  input wire         m_rsp_ready_i,
  input wire         t_req_ready_i,
  input wire         t_rsp_valid_i,
  input wire [147:0] t_rsp_i
);
  localparam NDOM = 2, NW = 1, NP = 1, NDEV = 1, NQ = 1, NKEY = 1, LEN_W = 5;
  localparam [NDEV*AW-1:0] DEV_BASE = 16;     // 0x10 (AW=5)
  localparam [NDEV*AW-1:0] DEV_MASK = 16;     // mask 0x10 -> region 0x10..0x1F

  // ---- table
  wire rsp_valid_o, cmd_deny_o, ctl_clr_safe_o, ctl_clr_cnt_o, ctl_thresh_we_o, zero_valid_o, lock_o, look_found_o, own_found_o;
  wire [3:0] rsp_status_o;  wire [NQ-1:0] ctl_clr_qhold_o;  wire [NP-1:0] ctl_clr_isol_o;  wire [15:0] ctl_thresh_o;
  wire [NKEY-1:0] zero_mask_o;  wire [NDOM-1:0] slot_clr_o;  wire look_slot_o, own_slot_o;
  wire [NDOM*2-1:0] slot_state_o;  wire [NDOM*8-1:0] slot_id_o;  wire [NDOM-1:0] slot_priv_o, slot_secure_o;
  wire [NDOM*NW-1:0] win_valid_o, win_r_o, win_w_o, win_x_o, win_excl_o;  wire [NDOM*NW*AW-1:0] win_base_o, win_limit_o;
  wire [NDOM*NDEV-1:0] devrd_o, devwr_o;  wire [NDOM*NQ-1:0] qmask_o;  wire [NDOM*NKEY-1:0] kmask_o;  wire [NP*NDOM-1:0] bind_o;

  sf_citadel_domain_table #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .NKEY(NKEY), .AW(AW), .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK)) u_tbl (
    .clk_i(clk_i), .rst_ni(rst_ni), .cfg_en_i(1'b1), .cmd_valid_i(cmd_valid_i), .cmd_op_i(cmd_op_i), .cmd_dom_i(8'h00),
    .cmd_priv_i(1'b1), .cmd_slot_i(cmd_slot_i), .cmd_win_i(cmd_win_i), .cmd_port_i(cmd_port_i), .cmd_arg_dom_i(cmd_arg_dom_i),
    .cmd_flags_i(cmd_flags_i), .cmd_data0_i(cmd_data0_i), .cmd_data1_i(cmd_data1_i),
    .rsp_valid_o(rsp_valid_o), .rsp_status_o(rsp_status_o), .cmd_deny_o(cmd_deny_o),
    .ctl_clr_qhold_o(ctl_clr_qhold_o), .ctl_clr_isol_o(ctl_clr_isol_o), .ctl_clr_safe_o(ctl_clr_safe_o), .ctl_clr_cnt_o(ctl_clr_cnt_o),
    .ctl_thresh_we_o(ctl_thresh_we_o), .ctl_thresh_o(ctl_thresh_o), .qtn_valid_i(qtn_valid_i), .qtn_slot_i(qtn_slot_i),
    .zero_valid_o(zero_valid_o), .zero_mask_o(zero_mask_o), .slot_clr_o(slot_clr_o),
    .look_dom_i(8'h00), .look_found_o(look_found_o), .look_slot_o(look_slot_o), .own_addr_i({AW{1'b0}}), .own_found_o(own_found_o), .own_slot_o(own_slot_o),
    .slot_state_o(slot_state_o), .slot_id_o(slot_id_o), .slot_priv_o(slot_priv_o), .slot_secure_o(slot_secure_o),
    .win_valid_o(win_valid_o), .win_base_o(win_base_o), .win_limit_o(win_limit_o), .win_r_o(win_r_o), .win_w_o(win_w_o), .win_x_o(win_x_o),
    .win_excl_o(win_excl_o), .devrd_o(devrd_o), .devwr_o(devwr_o), .qmask_o(qmask_o), .kmask_o(kmask_o), .bind_o(bind_o), .lock_o(lock_o));

  // ---- gate and checker
  wire m_req_ready_o, m_rsp_valid_o, t_req_valid_o, t_rsp_ready_o, chk_valid_o, chk_commit_o, rsp_orphan_o;
  wire [147:0] m_rsp_o;  wire [235:0] t_req_o;  wire [7:0] chk_dom_o, chk_attr_o, chk_idx_o;  wire [3:0] chk_op_o;
  wire [63:0] chk_addr_o;  wire [31:0] chk_len_o;  wire [1:0] chk_cls_o;  wire [OUT_W-1:0] outstanding_o;
  wire chk_permit, slot_vld_o, slot_o;  wire [3:0] chk_status, reason_o;

  sf_citadel_gate #(.OUT_W(OUT_W)) u_gate (
    .clk_i(clk_i), .rst_ni(rst_ni),
    .m_req_valid_i(m_req_valid_i), .m_req_ready_o(m_req_ready_o), .m_req_i(m_req_i),
    .m_rsp_valid_o(m_rsp_valid_o), .m_rsp_ready_i(m_rsp_ready_i), .m_rsp_o(m_rsp_o),
    .t_req_valid_o(t_req_valid_o), .t_req_ready_i(t_req_ready_i), .t_req_o(t_req_o),
    .t_rsp_valid_i(t_rsp_valid_i), .t_rsp_ready_o(t_rsp_ready_o), .t_rsp_i(t_rsp_i),
    .flush_i(1'b0),
    .chk_valid_o(chk_valid_o), .chk_dom_o(chk_dom_o), .chk_op_o(chk_op_o), .chk_attr_o(chk_attr_o), .chk_addr_o(chk_addr_o),
    .chk_len_o(chk_len_o), .chk_cls_o(chk_cls_o), .chk_idx_o(chk_idx_o), .chk_commit_o(chk_commit_o),
    .chk_permit_i(chk_permit), .chk_status_i(chk_status), .outstanding_o(outstanding_o), .rsp_orphan_o(rsp_orphan_o));

  sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .AW(AW), .LEN_W(LEN_W),
                          .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK), .DEV_PRIV(1'b1), .DEV_SECURE(1'b0)) u_chk (
    .src_i(1'b0), .dom_i(chk_dom_o), .op_i(chk_op_o), .attr_i(chk_attr_o), .addr_i(chk_addr_o[AW-1:0]), .len_i(chk_len_o[LEN_W-1:0]),
    .cls_i(chk_cls_o), .idx_i(chk_idx_o), .lockdown_i(1'b0), .dft_active_i(1'b0), .qhold_i(1'b0), .port_isol_i(1'b0),
    .slot_state_i(slot_state_o), .slot_id_i(slot_id_o), .slot_priv_i(slot_priv_o), .slot_secure_i(slot_secure_o),
    .win_valid_i(win_valid_o), .win_base_i(win_base_o), .win_limit_i(win_limit_o), .win_r_i(win_r_o), .win_w_i(win_w_o), .win_x_i(win_x_o),
    .devrd_i(devrd_o), .devwr_i(devwr_o), .qmask_i(qmask_o), .bind_i(bind_o),
    .permit_o(chk_permit), .reason_o(reason_o), .status_o(chk_status), .slot_vld_o(slot_vld_o), .slot_o(slot_o));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk_i), .rst_n(rst_ni), .init_q(init_q));

  localparam [3:0] OP_REVOKE = 4'd8, CS_OK = 4'd0;
  localparam [1:0] DS_INVALID = 2'd0, DS_ACTIVE = 2'd2;

  // ---- "domain is usable by this port" = an ACTIVE slot with that id bound to port 0
  (* anyconst *) wire [7:0] fd;
  wire act_D   = (slot_state_o[1:0] == DS_ACTIVE && slot_id_o[7:0]  == fd && bind_o[0]) ||
                 (slot_state_o[3:2] == DS_ACTIVE && slot_id_o[15:8] == fd && bind_o[1]);
  wire act_chk = (slot_state_o[1:0] == DS_ACTIVE && slot_id_o[7:0]  == chk_dom_o && bind_o[0]) ||
                 (slot_state_o[3:2] == DS_ACTIVE && slot_id_o[15:8] == chk_dom_o && bind_o[1]);

  // ---- shadows (async-reset style)
  reg was_q, fe_act_q, p_cmdv, p_slot, p_revcmd;  reg [3:0] p_op;
  always @(posedge clk_i or negedge rst_ni) begin
    if (!rst_ni) begin
      was_q <= 1'b0; fe_act_q <= 1'b0; p_cmdv <= 1'b0; p_slot <= 1'b0; p_op <= 4'd0; p_revcmd <= 1'b0;
    end else begin
      if (act_D) was_q <= 1'b1;                                   // D has been usable at some time since reset
      if (chk_commit_o) fe_act_q <= act_chk;                      // what the checker saw at the request's first evaluation
      p_cmdv <= cmd_valid_i; p_slot <= cmd_slot_i; p_op <= cmd_op_i;
      p_revcmd <= cmd_valid_i && cmd_op_i == OP_REVOKE;          // the command of the PREVIOUS cycle; its status is visible NOW (rsp_status_o)
    end
  end
  wire p_rev = p_revcmd && rsp_valid_o && rsp_status_o == CS_OK;  // a REVOKE of slot p_slot was accepted in the previous cycle
  wire fe_act = chk_commit_o ? act_chk : fe_act_q;                // first-evaluation view of the HELD request
  wire fwd    = t_req_valid_o && t_req_ready_i;
  wire d_held = chk_valid_o && (chk_dom_o == fd);                 // the held request belongs to the domain under test

  always @(*) begin
    `ALB_ASSUME(e_addr_small, "ENV-SEC-STALE-ADDR request addresses fit the checker's AW-bit address space", (m_req_i[207:144] >> AW) == 64'd0)
  end

  always @(*) begin
    `ALB_ASSERT(1, a_fwd_needs_active_at_eval, "[04 s2] composition: whatever is presented downstream was permitted by the REAL checker against the REAL table at its first evaluation: its domain was ACTIVE and bound then",
                `ALB_IMPL(t_req_valid_o, fe_act))
    `ALB_ASSERT(2, a_post_invalidation_denied, "[03 s7 / 04 s2] POSITIVE invalidation property: a request of domain D whose FIRST evaluation finds D invalidated (revoked, suspended, quarantined, unbound) is never presented downstream -- not even if D is re-activated while the request waits",
                `ALB_IMPL(d_held && !fe_act, !t_req_valid_o))
    `ALB_ASSERT(3, a_stale_forward_only_if_latched, "[04 A-TGT] a request of D that is presented while D is invalidated was latched PERMIT while D was ACTIVE (the only way a stale permission is used)",
                `ALB_IMPL(t_req_valid_o && d_held && was_q && !act_D, fe_act_q))
    `ALB_ASSERT(4, a_no_forward_after_invalidation, "[CLAIM, expected to FAIL = limitation 12 / A-TGT] after D has become invalid, no request of D is forwarded to the target",
                `ALB_IMPL(was_q && !act_D && d_held, !fwd))
    `ALB_ASSERT(5, a_revoke_visible_to_checker, "[03] an accepted REVOKE of a slot is visible to the checker at once: the slot is INVALID in the state the checker reads",
                `ALB_IMPL(p_rev && rst_ni, slot_state_o[p_slot*2 +: 2] == DS_INVALID))
    `ALB_ASSERT(6, a_new_request_denied_after_revoke, "[03 s7] the checker denies every request of a revoked domain in the cycle after the REVOKE (no stale grant in the checker itself)",
                `ALB_IMPL(rst_ni && p_rev && chk_valid_o && chk_dom_o == fd && !act_D, !chk_permit))
  end

  // ---- vacuity / reachability covers
  always @(*) begin
    `ALB_COVER(90, c_d_forwarded,      "a request of D is permitted and forwarded to the target", fwd && d_held && fe_act)
    `ALB_COVER(91, c_deny_after_revoke, "a request of D is denied because D is invalidated (error response due)", chk_commit_o && d_held && was_q && !act_D && !chk_permit)
    `ALB_COVER(92, c_stalled_then_revoked, "the stale scenario: a request of D is presented, the target stalls, D is invalidated meanwhile", t_req_valid_o && !t_req_ready_i && d_held && was_q && !act_D)
    `ALB_COVER(93, c_stale_forward,    "the stale scenario completes: a request of D is forwarded after D was invalidated", fwd && d_held && was_q && !act_D)
    `ALB_COVER(94, c_revoke_accepted,  "a REVOKE command is accepted", rst_ni && p_rev)
    `ALB_COVER(95, c_reactivated,      "D is re-activated after having been invalidated (re-ENROLL + activate)", was_q && act_D && !fe_act_q && chk_valid_o)
    `ALB_COVER(96, c_binding_survives_revoke, "a REVOKEd slot still carries its port binding (limitation 10)", rst_ni && p_rev && bind_o[p_slot])
    `ALB_COVER(97, c_quarantine_stale, "containment invalidates D while a permitted request is held", was_q && !act_D && d_held && (slot_state_o[1:0] == 2'd3 || slot_state_o[3:2] == 2'd3))
    `ALB_COVER(98, c_deny_first_eval,  "a request whose first evaluation finds D inactive is held and denied", chk_commit_o && d_held && !act_chk)
  end
endmodule
`default_nettype wire
