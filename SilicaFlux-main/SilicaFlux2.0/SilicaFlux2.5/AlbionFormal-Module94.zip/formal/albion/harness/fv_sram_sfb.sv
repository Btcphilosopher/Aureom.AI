// =============================================================================
// AlbionFormal harness :: sfb_sram_slave -- SFB2 slave adapter on sram_sp   [SRAM area, brief item 3, point 4]
//
// DUT   rtl:datafabric/rtl/mem/sfb_sram_slave.sv  + sram_sp + sram_rsp_path + the REAL generic array (shim TAP=0; the shim is two
//       levels down: dut.u_sram.u_array)
// SPEC  docs/datafabric/PROTOCOL.md  R2 (request stability), R4 (held response stable), R5 (one response per request, in order,
//       never in the acceptance cycle), R7 (a write is acknowledged only after the array was written), R8 (error => rdata = 0;
//       out-of-range SRAM word => error, no side effect), R10 (byte strobes);  adapter header: word address = req_addr[OFF +: AW],
//       WRITE_ACK = 1 (every write answered), RSP_FIFO_DEPTH = READ_LATENCY + 1.
// MODEL env/albion_sram_sb.sv with CHECK_WE = CHECK_ID = 0 (the adapter hides rsp_we / rsp_id).
// ENVIRONMENT   ENV-RST-ANY; ENV-SFB-R2 (master holds a presented request and its payload until accepted -- PROTOCOL R2; the proof does
//       not need it, it is stated because the crossbar guarantees it; the job with ASSUME_R2 = 0 shows independence).  No alignment
//       assumption: the slave decodes req_addr[OFF +: AW] and ignores every other bit, and so does the model.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sram_sfb #(
  parameter ALB_SEL = 0,
  parameter DW = 16, DEPTH = 4, LAT = 1, ASSUME_R2 = 1,
  localparam SB = DW / 8,
  localparam OFF = (DW > 8) ? $clog2(DW / 8) : 0,
  localparam AW = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam QD = LAT + 1
) (
  input  wire              clk,
  input  wire              rst_n,
  input  wire              req_valid,
  input  wire              req_write,
  input  wire [31:0]       req_addr,
  input  wire [DW-1:0]     req_wdata,
  input  wire [SB-1:0]     req_wstrb,
  input  wire              rsp_ready,
  input  wire              tst_active,
  input  wire              tst_ce,
  input  wire              tst_we,
  input  wire [AW-1:0]     tst_addr,
  input  wire [DW-1:0]     tst_wdata
);
  wire              req_ready, rsp_valid, rsp_error;
  wire [DW-1:0]     rsp_rdata, tst_rdata;
  sfb_sram_slave #(.DW(DW), .DEPTH(DEPTH), .READ_LATENCY(LAT)) dut (
    .clk(clk), .rst_n(rst_n),
    .req_valid(req_valid), .req_ready(req_ready), .req_write(req_write), .req_addr(req_addr), .req_wdata(req_wdata), .req_wstrb(req_wstrb),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_error(rsp_error),
    .tst_active(tst_active), .tst_ce(tst_ce), .tst_we(tst_we), .tst_addr(tst_addr), .tst_wdata(tst_wdata), .tst_rdata(tst_rdata));
  defparam dut.u_sram.u_array.TAP = 0;

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));
  reg live_h;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) live_h <= 1'b0;
    else        live_h <= 1'b1;
  end

  // R2 monitor (master side)
  wire m_stable_ok, m_acc, m_held;
  albion_sfb_req_mon #(.AW(32), .DW(DW)) u_req (.clk(clk), .rst_n(rst_n), .valid(req_valid), .ready(req_ready), .write(req_write),
    .addr(req_addr), .wdata(req_wdata), .wstrb(req_wstrb), .stable_ok(m_stable_ok), .accepted(m_acc), .held(m_held));

  (* anyconst *) wire [AW-1:0] ta;
  wire [AW-1:0] wi = req_addr[OFF +: AW];
  wire t_on    = tst_active;
  wire addr_ok = ({1'b0, wi} < DEPTH);
  wire tst_ok  = ({1'b0, tst_addr} < DEPTH);
  wire acc     = req_valid && req_ready;
  wire arr_ce  = t_on ? (tst_ce && tst_ok) : (acc && addr_ok);
  wire arr_we  = t_on ? tst_we : req_write;
  wire [SB-1:0] arr_wm = t_on ? {SB{1'b1}} : req_wstrb;
  wire [AW-1:0] arr_ad = t_on ? tst_addr : wi;
  wire [DW-1:0] arr_wd = t_on ? tst_wdata : req_wdata;

  wire ok_raw, ok_raw_written, ok_raw_unwritten, ok_rsp_valid, ok_err, ok_we, ok_id, ok_zero, ok_data, ok_stable, ov;
  wire [3:0] qcount;
  wire cv_raw_checked, cv_raw_partial, cv_raw_unwritten, cv_partial_write, cv_backpressure, cv_full, cv_err_rsp, cv_data_checked;
  albion_sram_sb #(.DW(DW), .MW(SB), .AW(AW), .DEPTH(DEPTH), .LAT(LAT), .QD(QD), .WACK(1), .IDW(1), .CHECK_WE(0), .CHECK_ID(0)) sb (
    .clk(clk), .rst_n(rst_n), .ta(ta),
    .arr_ce(arr_ce), .arr_we(arr_we), .arr_wmask(arr_wm), .arr_addr(arr_ad), .arr_wdata(arr_wd), .raw_rdata(tst_rdata),
    .acc(acc), .acc_we(req_write), .acc_addr(wi), .acc_id(1'b0),
    .rsp_valid(rsp_valid), .rsp_ready(rsp_ready), .rsp_rdata(rsp_rdata), .rsp_err(rsp_error), .rsp_we(1'b0), .rsp_id(1'b0),
    .ok_raw(ok_raw), .ok_raw_written(ok_raw_written), .ok_raw_unwritten(ok_raw_unwritten),
    .ok_rsp_valid(ok_rsp_valid), .ok_err(ok_err), .ok_we(ok_we), .ok_id(ok_id), .ok_zero(ok_zero), .ok_data(ok_data),
    .ok_stable(ok_stable), .ov(ov), .qcount(qcount),
    .cv_raw_checked(cv_raw_checked), .cv_raw_partial(cv_raw_partial), .cv_raw_unwritten(cv_raw_unwritten),
    .cv_partial_write(cv_partial_write), .cv_backpressure(cv_backpressure), .cv_full(cv_full), .cv_err_rsp(cv_err_rsp),
    .cv_data_checked(cv_data_checked));

  reg out_prev;
  always @(posedge clk) out_prev <= (qcount != 4'd0);

  always @(*) begin
    `ALB_ASSUME(e_ta_valid, "ENV-SRAM-TA the tracked word is a valid word (quantified over every valid word)", ta < DEPTH)
    if (ASSUME_R2 != 0) begin
      `ALB_ASSUME(e_master_r2, "ENV-SFB-R2 [PROTOCOL R2] a presented request stays presented with an unchanged payload until accepted", m_stable_ok)
    end
  end

  always @(*) begin
    `ALB_ASSERT(20, a_sfb_array_lanes, "[R7,R10] the array holds exactly what the strobed writes put there: reads return the shadow on every known lane, masked lanes untouched, never-written lanes unchanged", ok_raw)
    `ALB_ASSERT(21, a_sfb_rsp_exact, "[R5,R7] exactly one response per accepted request, in order, >= READ_LATENCY (>= 1) cycles after acceptance, never unsolicited, dropped or duplicated; a write is answered only after its array write edge", ok_rsp_valid)
    `ALB_ASSERT(22, a_sfb_rsp_error, "[R8] rsp_error exactly for out-of-range SRAM words (non-power-of-two DEPTH)", ok_err)
    `ALB_ASSERT(23, a_sfb_rsp_zero, "[R8] error responses and write responses carry rsp_rdata = 0", ok_zero)
    `ALB_ASSERT(24, a_sfb_rsp_data, "[R7,R10] read data = the word as written by every earlier accepted write (word address = req_addr[OFF +: AW])", ok_data)
    `ALB_ASSERT(25, a_sfb_rsp_stable, "[R4] a held response (rsp_valid && !rsp_ready) stays valid with unchanged payload", ok_stable)
    `ALB_ASSERT(26, a_sfb_credit, "outstanding responses never exceed RSP_FIFO_DEPTH = READ_LATENCY + 1 (no overflow, no drop)", !ov)
    `ALB_ASSERT(27, a_sfb_ready_low_reset, "[R11] req_ready = 0 in reset and the first cycle after: reset can generate no transfer", `ALB_IMPL(!live_h, !req_ready))
    `ALB_ASSERT(28, a_sfb_ready_exact, "req_ready <=> not test mode && live && a response credit is free (every request needs a response: WRITE_ACK = 1)",
                req_ready == (!t_on && live_h && (qcount < QD)))
    `ALB_ASSERT(29, a_sfb_reset_state, "[R11] in reset: no response is presented (rsp_valid = 0) and nothing is accepted", `ALB_IMPL(!rst_n, !rsp_valid && !req_ready))
  end
  always @(*) begin
    `ALB_COVER(90, c_write_then_read,  "a read of a known lane is checked after a (masked) write", cv_raw_checked)
    `ALB_COVER(91, c_partial_known,    "a read with only some lanes known", cv_raw_partial)
    `ALB_COVER(92, c_unwritten_reread, "a never-written lane is re-read and compared", cv_raw_unwritten)
    `ALB_COVER(93, c_strobe_partial,   "a partial-strobe write is performed", cv_partial_write)
    `ALB_COVER(94, c_backpressure,     "response back-pressure", cv_backpressure)
    `ALB_COVER(95, c_credits_full,     "all response credits in use", cv_full)
    `ALB_COVER(96, c_error_response,   "an out-of-range word is answered with rsp_error (non-power-of-two DEPTH)", cv_err_rsp)
    `ALB_COVER(97, c_data_checked,     "a response of a tracked read with known lanes is checked", cv_data_checked)
    `ALB_COVER(98, c_reset_with_outstanding, "reset while a response is outstanding", !rst_n && !init_q && out_prev)
    `ALB_COVER(99, c_misaligned_ignored, "a request with non-zero low address bits is accepted (slave ignores them)", acc && (OFF > 0) && req_addr[0])
  end
endmodule
`default_nettype wire
