// =============================================================================
// AlbionFormal harness :: PROTECTED ADDRESSES -- cc_secmon(HOST_LOCK) -> cc_sfb_gate -> sfb_sram_slave, array-write observation  [SRAM item 3.5(c)]
//
// MAPPING DECISION (brief wording vs RTL).  sram_sp / sfb_sram_slave have NO protection concept.  The protection mechanism that exists
// in the SilicaFlux RTL is the ControlCore HOST WRITE LOCK: cc_secmon.host_lock (set-only until reset) + cc_sfb_gate refusing host writes
// to protected regions.  "Protected addresses reject unauthorised writes" is therefore proved for THIS composition.
// MODELLING CHOICE (exactly as silicaflux_control_core.sv does for its host gate):
//     refuse = host_lock && write && (address inside the protected window)         -- evaluated combinationally on the LIVE upstream request
// The protected window is the word range [PLO, DEPTH) of the SRAM slave (word index = addr[OFF +: AW]).
// DUT chain  cc_secmon (rb_* free, i.e. the CPU may write CTRL at any time) | cc_sfb_gate | sfb_sram_slave | sram_sp | REAL array behind the TAP shim:
//            the array boundary of the real RTL is visible on tst_rdata (see shim_sram_backend.sv), so "array write enable" is observed, not inferred.
// ENVIRONMENT  ENV-RST-ANY; ENV-PROT-R2 (upstream keeps a presented request until accepted, PROTOCOL R2);
//              ENV-PROT-WIN (requests carry word-aligned addresses inside the slave window: addr[1:0]=0, addr[31:OFF+AW]=0 -- the crossbar decode,
//              PROTOCOL R9);  the MBIST test port is FREE: its writes bypass the host gate by design (DFT path, outside the host-gate policy).
// "FIRST EVALUATION" = the first cycle in which the request is presented to the gate while the gate is free (s_req_valid && free).  The gate
// decides permit/refuse in that cycle; a request presented downstream is never withdrawn (pend_q), even if the lock is set while it waits.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_prot_compose_tap #(
  parameter ALB_SEL = 0,
  parameter DEPTH = 4, LAT = 1, PLO = 2,
  localparam AW = (DEPTH > 1) ? $clog2(DEPTH) : 1,
  localparam OFF = 2
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        s_req_valid,
  input  wire        s_req_write,
  input  wire [31:0] s_req_addr,
  input  wire [31:0] s_req_wdata,
  input  wire [3:0]  s_req_wstrb,
  input  wire        s_rsp_ready,
  input  wire        rb_sel,
  input  wire        rb_we,
  input  wire [11:0] rb_addr,
  input  wire [31:0] rb_wdata,
  input  wire        tst_active,
  input  wire        tst_ce,
  input  wire        tst_we,
  input  wire [AW-1:0] tst_addr,
  input  wire [31:0] tst_wdata
);
  `include "cc_memmap_defs.svh"
  wire        host_lock, refused_evt, idle, rb_err;
  wire [31:0] rb_rdata;
  wire        s_req_ready, s_rsp_valid, s_rsp_error;
  wire [31:0] s_rsp_rdata;
  wire        m_req_valid, m_req_ready, m_req_write, m_rsp_valid, m_rsp_ready, m_rsp_error;
  wire [31:0] m_req_addr, m_req_wdata, m_rsp_rdata, tst_rdata;
  wire [3:0]  m_req_wstrb;

  wire [AW-1:0] wi   = s_req_addr[OFF +: AW];
  wire          prot = (wi >= PLO);
  wire          refuse = host_lock && s_req_write && prot;

  cc_secmon u_sec (.clk(clk), .rst_n(rst_n), .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata),
                   .rb_rdata(rb_rdata), .rb_err(rb_err), .viol_evt(refused_evt), .viol_addr(s_req_addr), .host_lock(host_lock));
  cc_sfb_gate u_gate (
    .clk(clk), .rst_n(rst_n),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr),
    .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb),
    .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready), .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_error),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .refuse(refuse), .refused_evt(refused_evt), .idle(idle));
  sfb_sram_slave #(.DW(32), .DEPTH(DEPTH), .READ_LATENCY(LAT)) u_ram (
    .clk(clk), .rst_n(rst_n),
    .req_valid(m_req_valid), .req_ready(m_req_ready), .req_write(m_req_write), .req_addr(m_req_addr),
    .req_wdata(m_req_wdata), .req_wstrb(m_req_wstrb),
    .rsp_valid(m_rsp_valid), .rsp_ready(m_rsp_ready), .rsp_rdata(m_rsp_rdata), .rsp_error(m_rsp_error),
    .tst_active(tst_active), .tst_ce(tst_ce), .tst_we(tst_we), .tst_addr(tst_addr), .tst_wdata(tst_wdata), .tst_rdata(tst_rdata));
  defparam u_ram.u_sram.u_array.TAP = 1;

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // R2 monitor (upstream) and gate spec model
  wire s_stable_ok, s_acc, s_held;
  albion_sfb_req_mon #(.AW(32), .DW(32)) u_s (.clk(clk), .rst_n(rst_n), .valid(s_req_valid), .ready(s_req_ready), .write(s_req_write),
    .addr(s_req_addr), .wdata(s_req_wdata), .wstrb(s_req_wstrb), .stable_ok(s_stable_ok), .accepted(s_acc), .held(s_held));
  reg fwd_pend, loc_pend, loc_prev, locprot_prev, eval_q, lockfe_q;
  wire m_acc   = m_req_valid && m_req_ready;
  wire m_rsp_hs = m_rsp_valid && m_rsp_ready;
  wire s_rsp_hs = s_rsp_valid && s_rsp_ready;
  wire loc_acc = s_acc && !m_req_valid;
  wire free    = !fwd_pend && !loc_pend;
  wire first_eval = s_req_valid && free && !eval_q;
  wire lock_fe = first_eval ? host_lock : lockfe_q;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      fwd_pend <= 1'b0; loc_pend <= 1'b0; loc_prev <= 1'b0; locprot_prev <= 1'b0; eval_q <= 1'b0; lockfe_q <= 1'b0;
    end else begin
      fwd_pend <= (fwd_pend && !m_rsp_hs) || m_acc;
      loc_pend <= (loc_pend && !s_rsp_hs) || loc_acc;
      loc_prev <= loc_acc;
      locprot_prev <= loc_acc && s_req_write && prot;
      eval_q   <= s_acc ? 1'b0 : ((s_req_valid && free) ? 1'b1 : eval_q);
      if (first_eval) lockfe_q <= host_lock;
    end
  end

  // array boundary (tap)
  localparam HDR = 2 + 4 + AW;
  wire        t_on   = tst_active;
  wire        tap_ce = tst_rdata[0];
  wire        tap_we = tst_rdata[1];
  wire [AW-1:0] tap_ad = tst_rdata[2 + 4 +: AW];
  wire        tap_prot = (tap_ad >= PLO);
  wire        func_wr  = tap_ce && tap_we && !t_on;
  wire        func_prot_wr = func_wr && tap_prot;

  reg lock_raw;
  always @(posedge clk) lock_raw <= host_lock;

  always @(*) begin
    `ALB_ASSUME(e_up_r2,  "ENV-PROT-R2 upstream keeps a presented request and its payload until accepted (PROTOCOL R2)", s_stable_ok)
    `ALB_ASSUME(e_win,    "ENV-PROT-WIN requests are word-aligned and inside the slave window (crossbar decode, PROTOCOL R9): addr[1:0]=0, addr[31:OFF+AW]=0",
                s_req_addr[1:0] == 2'b00 && (s_req_addr >> (OFF + AW)) == 32'd0)
  end

  always @(*) begin
    `ALB_ASSERT(1, a_prot_write_needs_unlocked_first_eval, "PROTECTED WRITES: a functional array write to a protected word happens only if host_lock was 0 when its request was first evaluated by the gate (a lock set BEFORE a write is presented blocks it)",
                `ALB_IMPL(func_prot_wr, !lock_fe))
    `ALB_ASSERT(2, a_prot_refused_at_accept, "a protected write that the gate evaluates while host_lock = 1 is refused (accepted locally, never forwarded)",
                `ALB_IMPL(s_acc && s_req_write && prot && lock_fe, refused_evt))
    `ALB_ASSERT(3, a_prot_error_response, "a refused protected write is answered one cycle later with rsp_error = 1 and rdata = 0",
                `ALB_IMPL(locprot_prev, s_rsp_valid && s_rsp_error && s_rsp_rdata == 32'd0))
    `ALB_ASSERT(4, a_unprotected_not_refused, "no false denial: unprotected writes and all reads are never refused, lock or not",
                `ALB_IMPL(s_acc && (!s_req_write || !prot), !refused_evt))
    `ALB_ASSERT(5, a_lock_monotone_in_chain, "host_lock never clears except by reset (also inside the composed system)", `ALB_IMPL(lock_raw && rst_n, host_lock))
    `ALB_ASSERT(6, a_prot_stale_after_lock, "STRONG form (expected to FAIL, finding SRAM-F1): no functional array write to a protected word occurs while host_lock = 1",
                `ALB_IMPL(func_prot_wr, !host_lock))
  end
  always @(*) begin
    `ALB_COVER(90, c_lock_set,            "host_lock is set", host_lock && !lock_raw && rst_n)
    `ALB_COVER(91, c_prot_write_refused,  "a protected write is refused because of the lock", loc_acc && s_req_write && prot && host_lock)
    `ALB_COVER(92, c_prot_write_performed_unlocked, "a protected word IS written while unlocked (the lock does not over-block)", func_prot_wr && !host_lock)
    `ALB_COVER(93, c_unprot_write_after_lock, "an unprotected word is written after the lock is set", func_wr && !tap_prot && host_lock)
    `ALB_COVER(94, c_stale_write_performed,   "FINDING SRAM-F1: a protected write first evaluated while unlocked is performed AFTER the lock was set (it stalled downstream)",
                func_prot_wr && host_lock && !lock_fe)
    `ALB_COVER(95, c_test_write_protected_locked, "DFT path: a test-port write to a protected word while locked (bypasses the host gate by design)", t_on && tap_ce && tap_we && tap_prot && host_lock)
    `ALB_COVER(96, c_read_after_lock,     "a read is served after the lock is set", s_acc && !s_req_write && host_lock)
  end
endmodule
`default_nettype wire
