// =============================================================================
// AlbionFormal harness :: dma_validate (combinational descriptor validation)
// DUT      rtl_under_test/datafabric/rtl/dma/dma_validate.sv      SPEC  docs/datafabric/DMA.md section 2
// ASSUME-SET  ENV-RST-NONE only: the DUT has no state; inputs are completely free (every 32-bit src/dst/len).
// The proof is EXHAUSTIVE at the real 32-bit width (all 2^96 descriptors), not a bounded or sampled check.
// Reference: env/albion_dma_ref.sv (40-bit true-integer statement of the rule table).
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_dma_validate #(
  parameter DW = 32,
  parameter MAX_LEN_LOG2 = 24,
  parameter ALB_SEL = 0
) (
  input wire        clk,
  input wire [31:0] src,
  input wire [31:0] dst,
  input wire [31:0] len
);
  localparam SB = DW / 8;
  // TOOL WORKAROUND (not an assumption): ABC `bmc3` refuses purely combinational networks.  The DUT is therefore fed from
  // registers that sample the free inputs every cycle; every 96-bit value is reachable in the next cycle and the
  // initial register content is arbitrary, so every assertion still quantifies over ALL descriptors.
  reg [31:0] src_q, dst_q, len_q;
  always @(posedge clk) begin src_q <= src; dst_q <= dst; len_q <= len; end
  wire [31:0] src_r = src_q, dst_r = dst_q, len_r = len_q;
  wire [3:0] code;
  dma_validate #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) dut (.src(src_r), .dst(dst_r), .len(len_r), .code(code));

  wire        legal, f_zero, f_long, f_salign, f_dalign, f_sovf, f_dovf, f_ovl;
  wire [3:0]  rcode;
  albion_dma_ref_validate #(.DW(DW), .MAX_LEN_LOG2(MAX_LEN_LOG2)) ref0 (
    .src(src_r), .dst(dst_r), .len(len_r), .legal(legal), .code(rcode),
    .f_zero(f_zero), .f_long(f_long), .f_salign(f_salign), .f_dalign(f_dalign), .f_sovf(f_sovf), .f_dovf(f_dovf), .f_ovl(f_ovl));

  wire [39:0] s_end = {8'b0, src_r} + {8'b0, len_r};
  wire [39:0] d_end = {8'b0, dst_r} + {8'b0, len_r};

  always @(*) begin
    `ALB_ASSERT(1,  a_code_matches_spec,  "[DMA.md 2] error code == first failing rule of the documented table (40-bit integer reference)", code == rcode)
    `ALB_ASSERT(2,  a_none_iff_legal,     "[DMA.md 2] NONE <=> descriptor legal (no rule fails)", (code == 4'd0) == legal)
    `ALB_ASSERT(3,  a_code_range,         "[DMA.md 2] a validation code is one of 0..7", code <= 4'd7)
    `ALB_ASSERT(4,  a_ok_len_nonzero,     "validated => LENGTH != 0", (code != 4'd0) || (len_r != 32'd0))
    `ALB_ASSERT(5,  a_ok_len_limit,       "validated => LENGTH <= 2^MAX_LEN_LOG2 (descriptor cannot exceed the limit)", (code != 4'd0) || ({8'b0, len_r} <= (40'd1 << MAX_LEN_LOG2)))
    `ALB_ASSERT(6,  a_ok_aligned,         "validated => SRC and DST are DW-aligned", (code != 4'd0) || (SB == 1) || (((src_r | dst_r) & (SB - 1)) == 0))
    `ALB_ASSERT(7,  a_ok_src_no_wrap,     "validated => src_r + len_r <= 2^32 (source range does not wrap)", (code != 4'd0) || (s_end <= 40'h1_0000_0000))
    `ALB_ASSERT(8,  a_ok_dst_no_wrap,     "validated => dst_r + len_r <= 2^32 (destination range does not wrap)", (code != 4'd0) || (d_end <= 40'h1_0000_0000))
    `ALB_ASSERT(9,  a_ok_disjoint,        "validated => source and destination ranges are disjoint (no overlap, incl. src_r == dst_r)", (code != 4'd0) || (s_end <= {8'b0, dst_r}) || (d_end <= {8'b0, src_r}))
    `ALB_ASSERT(10, a_first_failing_wins, "[DMA.md 2] the reported rule fails and every lower-numbered rule passes",
                ((code != 4'd2) || !f_zero) && ((code != 4'd3) || !(f_zero || f_long)) && ((code != 4'd4) || !(f_zero || f_long || f_salign)) &&
                ((code != 4'd5) || !(f_zero || f_long || f_salign || f_dalign)) && ((code != 4'd6) || !(f_zero || f_long || f_salign || f_dalign || f_sovf)) &&
                ((code != 4'd7) || !(f_zero || f_long || f_salign || f_dalign || f_sovf || f_dovf)))
    `ALB_ASSERT(11, a_zero_len_first,     "[DMA.md 2] LENGTH == 0 is always reported as ZERO_LENGTH (rule 1 beats every other rule)", (len_r != 32'd0) || (code == 4'd1))
    `ALB_ASSERT(12, a_overlap_all_else_ok,"OVERLAP is reported only when rules 1-6 pass (range overlap is the last rule)", (code != 4'd7) || !(f_zero || f_long || f_salign || f_dalign || f_sovf || f_dovf))
    `ALB_COVER(90, c_legal,        "a legal descriptor exists", code == 4'd0)
    `ALB_COVER(91, c_zero_len,     "ZERO_LENGTH reachable", code == 4'd1)
    `ALB_COVER(92, c_too_long,     "LENGTH reachable", code == 4'd2)
    `ALB_COVER(93, c_src_align,    "SRC_ALIGN reachable (only when DW > 8)", code == 4'd3)
    `ALB_COVER(94, c_dst_align,    "DST_ALIGN reachable (only when DW > 8)", code == 4'd4)
    `ALB_COVER(95, c_src_ovf,      "SRC_OVERFLOW reachable", code == 4'd5)
    `ALB_COVER(96, c_dst_ovf,      "DST_OVERFLOW reachable", code == 4'd6)
    `ALB_COVER(97, c_overlap,      "OVERLAP reachable", code == 4'd7)
    `ALB_COVER(98, c_src_eq_dst,   "src_r == dst_r (non-zero length) is rejected as OVERLAP", src_r == dst_r && len_r != 32'd0 && code == 4'd7)
    `ALB_COVER(99, c_adjacent_ok,  "adjacent but disjoint ranges are accepted (dst_r == src_r + len_r)", {8'b0, dst_r} == s_end && code == 4'd0 && len_r != 32'd0)
  end
endmodule
`default_nettype wire
