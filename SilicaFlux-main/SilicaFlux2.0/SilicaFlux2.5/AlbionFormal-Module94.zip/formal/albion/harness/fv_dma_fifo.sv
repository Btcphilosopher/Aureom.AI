// =============================================================================
// AlbionFormal harness :: dma_fifo (synchronous first-word-fall-through FIFO of the buffered DMA engine)
//
// DUT      rtl_under_test/datafabric/rtl/dma/dma_fifo.sv        SPEC  DUT header ("push/pop are only issued by the engine under credit")
// ASSUME-SET (the FIFO's USAGE CONTRACT, restated from the DUT's own simulation checks)
//   ENV-RST-ANY    reset in step 0 and later
//   ENV-FIFO-1     no pop while empty                                     (RTL: $error "pop while empty")
//   ENV-FIFO-2     no push while full unless a pop frees the slot in the same cycle  (RTL: $error "push while full")
//   `clr` and the data/push/pop values are otherwise free.
// The engine's compliance with ENV-FIFO-1/2 is checked in the engine harness (a_fifo_le_depth / a_credit: BOUNDED there:
// they depend on the engine's 32-bit credit counters).  This split is an assume-guarantee decomposition, stated in the ledger.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_dma_fifo #(
  parameter ALB_SEL = 0,
  parameter WIDTH   = 4,
  parameter DEPTH   = 4,
  parameter TAGW    = 3
) (
  input wire             clk,
  input wire             rst_n,
  input wire             clr,
  input wire             push,
  input wire [WIDTH-1:0] wdata,
  input wire             pop
);
  localparam AW = (DEPTH > 1) ? $clog2(DEPTH) : 1;
  wire [WIDTH-1:0] rdata;
  wire [AW:0]      count;
  dma_fifo #(.WIDTH(WIDTH), .DEPTH(DEPTH)) dut (.clk(clk), .rst_n(rst_n), .clr(clr), .push(push), .wdata(wdata), .pop(pop), .rdata(rdata), .count(count));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // ---- reference model: occupancy and tagged-beat data integrity
  reg [AW+1:0]   m_cnt;                         // wider than the DUT counter: overflow would be visible
  reg [TAGW:0]   n_push, n_pop;
  reg            tag_valid;
  reg [WIDTH-1:0] tag_data;
  (* anyconst *) wire [TAGW-1:0] kk;
  wire do_push = push && !clr;
  wire do_pop  = pop && !clr;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      m_cnt <= 0; n_push <= 0; n_pop <= 0; tag_valid <= 1'b0; tag_data <= {WIDTH{1'b0}};
    end else if (clr) begin
      m_cnt <= 0; n_push <= 0; n_pop <= 0; tag_valid <= 1'b0;
    end else begin
      m_cnt <= m_cnt + {{(AW+1){1'b0}}, push} - {{(AW+1){1'b0}}, pop};
      if (push) begin
        n_push <= n_push + 1'b1;
        if (n_push == {1'b0, kk}) begin tag_valid <= 1'b1; tag_data <= wdata; end
      end
      if (pop) n_pop <= n_pop + 1'b1;
    end
  end

  always @(*) begin
    `ALB_ASSUME(e_no_pop_empty, "ENV-FIFO-1 no pop while empty",  !(pop && m_cnt == 0))
    `ALB_ASSUME(e_no_push_full, "ENV-FIFO-2 no push while full unless a pop frees the slot", !(push && !pop && m_cnt == DEPTH))
    `ALB_ASSERT(1, a_count_le_depth,  "FIFO occupancy never exceeds DEPTH (no overflow) and the counter never wraps", count <= DEPTH)
    `ALB_ASSERT(2, a_count_matches,   "occupancy == pushes - pops since reset/clear (exact accounting, nothing lost or duplicated)", {1'b0, count} == m_cnt[AW:0])
    `ALB_ASSERT(3, a_reset_empty,     "reset empties the FIFO", rst_n || count == 0)
    `ALB_ASSERT(4, a_fifo_order,      "first-in first-out: the k-th pop returns the k-th pushed word (tagged beat, any k < 2^TAGW)",
                !(pop && !clr && n_pop == {1'b0, kk}) || (tag_valid && rdata == tag_data))
    `ALB_COVER(90, c_full,        "the FIFO fills to DEPTH", count == DEPTH)
    `ALB_COVER(91, c_push_pop,    "simultaneous push and pop", push && pop && !clr && count != 0)
    `ALB_COVER(92, c_clr_nonempty,"clr with data inside", clr && count != 0)
    `ALB_COVER(93, c_tag_checked, "the tagged beat is popped and compared", pop && !clr && n_pop == {1'b0, kk} && tag_valid)
    `ALB_COVER(94, c_push_full_pop, "push into a full FIFO with a simultaneous pop (allowed by the contract)", push && pop && count == DEPTH)
  end
endmodule
`default_nettype wire
