// =============================================================================
// AlbionFormal harness :: sfb_addr_decoder  (DataFabric, per-master address decode + access matrix + alignment)
// DUT   rtl_under_test/datafabric/rtl/interconnect/sfb_addr_decoder.sv
// SPEC  DUT header; PROTOCOL R8/R9: unmapped / access-matrix-denied / misaligned addresses must not reach any slave.
// The decoder is purely combinational: the proof covers EVERY address for the given (BASE, MASK, EN) map -- the memory
// map is a module parameter, so each map is its own job.  ASSUME-SET: ENV-RST-NONE (no state, nothing assumed).
// The checks are DECLARATIVE (what a correct decode means), not a copy of the RTL loop.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sfb_decoder #(
  parameter NS = 3, AW = 6, DW = 16, CHECK_ALIGN = 1,
  parameter [NS*AW-1:0] SLV_BASE = 0,
  parameter [NS*AW-1:0] SLV_MASK = 0,
  parameter [NS-1:0]    EN       = {NS{1'b1}},
  parameter ALB_SEL = 0
) (
  input wire [AW-1:0] addr
);
  localparam SW  = (NS > 1) ? $clog2(NS) : 1;
  localparam OFF = (DW > 8) ? $clog2(DW / 8) : 1;
  wire hit, misaligned; wire [SW-1:0] sel; wire [NS-1:0] sel_oh;
  sfb_addr_decoder #(.NS(NS), .AW(AW), .DW(DW), .CHECK_ALIGN(CHECK_ALIGN), .SLV_BASE(SLV_BASE), .SLV_MASK(SLV_MASK), .EN(EN))
    dut (.addr(addr), .hit(hit), .sel(sel), .sel_oh(sel_oh), .misaligned(misaligned));

  // declarative facts about the address map
  integer s, t;
  reg [NS-1:0] in_region;            // region s contains addr (ignoring the access matrix)
  reg          aligned;
  reg          any_ok, lowest_ok, enabled_ok, region_ok;
  always @(*) begin
    aligned = (CHECK_ALIGN == 0) || (DW <= 8) || (addr[OFF-1:0] == {OFF{1'b0}});
    for (s = 0; s < NS; s = s + 1) in_region[s] = ((addr & SLV_MASK[s*AW +: AW]) == SLV_BASE[s*AW +: AW]);
    any_ok = 1'b0; lowest_ok = 1'b1; enabled_ok = 1'b1; region_ok = 1'b1;
    for (s = 0; s < NS; s = s + 1) begin
      if (in_region[s] && EN[s] && aligned) any_ok = 1'b1;
      if (sel_oh[s] && !EN[s])          enabled_ok = 1'b0;
      if (sel_oh[s] && !in_region[s])   region_ok  = 1'b0;
      for (t = 0; t < NS; t = t + 1)
        if (t < s && sel_oh[s] && in_region[t] && EN[t]) lowest_ok = 1'b0;   // a lower enabled region would win
    end
  end
  always @(*) begin
    `ALB_ASSERT(1, a_onehot0,        "a decode selects at most one slave", $onehot0(sel_oh))
    `ALB_ASSERT(2, a_hit_iff_sel,    "hit <=> some slave selected (no selection without hit, no hit without destination)", hit == (sel_oh != {NS{1'b0}}))
    `ALB_ASSERT(3, a_sel_valid,      "[R8] the selected index is a real slave: sel < NS and sel_oh[sel]", `ALB_IMPL(hit, sel < NS && sel_oh[sel]))
    `ALB_ASSERT(4, a_matrix_respected,"[R8] a slave disabled for this master in MST_SLV_EN is never selected", enabled_ok)
    `ALB_ASSERT(5, a_region_only,    "a selected slave's region really contains the address (no invalid routing destination)", region_ok)
    `ALB_ASSERT(6, a_aligned_only,   "[R9] a misaligned address is never routed", `ALB_IMPL(hit, aligned))
    `ALB_ASSERT(7, a_misaligned_flag,"misaligned flag == (CHECK_ALIGN && DW>8 && addr not DW-aligned)", misaligned == !aligned)
    `ALB_ASSERT(8, a_complete,       "no valid destination is rejected: an enabled, containing, aligned slave => hit", `ALB_IMPL(any_ok, hit))
    `ALB_ASSERT(9, a_lowest_wins,    "overlapping regions resolve to the lowest permitted slave index", lowest_ok)
    `ALB_COVER(90, c_hit,            "an address decodes to a slave", hit)
    `ALB_COVER(91, c_unmapped,       "an address that is in no region", in_region == {NS{1'b0}})
    `ALB_COVER(92, c_denied_matrix,  "an address inside a region whose EN bit is 0 and aligned: denied by the access matrix", aligned && ((in_region & ~EN) != {NS{1'b0}}) && !hit)
    `ALB_COVER(93, c_misaligned,     "an aligned-region address rejected only for misalignment", !aligned && (in_region & EN) != {NS{1'b0}} && !hit)
    `ALB_COVER(94, c_overlap,        "two enabled regions contain the address", ((in_region & EN) & ((in_region & EN) - 1'b1)) != {NS{1'b0}})
  end
endmodule
`default_nettype wire
