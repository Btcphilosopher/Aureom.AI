// =============================================================================
// AlbionFormal harness :: cc_secmon -- security STATUS block: HOST_LOCK (set-only) and BOOT_MEASURE (write-once)   [SRAM area, item 3.5(b)]
//
// DUT   rtl:controlcore/rtl/cc_secmon.sv     SPEC  module header + register comments in cc_memmap_defs.svh
//         CC_SEC_CTRL  [0] HOST_LOCK (set-only until system reset)       CC_SEC_BOOT_MEASURE  written once by the boot ROM (second write refused)
// ENVIRONMENT  ENV-RST-ANY only.  The register bus (rb_*), the violation event and its address are completely free (the CPU may write
//       any register at any time, with any value; rb_sel is not even assumed to be a one-cycle strobe).
// NOTE  cc_secmon only STORES the lock; the enforcement is the host gate (fv_prot_gate / fv_prot_compose_*), which consumes host_lock.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_prot_secmon #(
  parameter ALB_SEL = 0
) (
  input  wire        clk,
  input  wire        rst_n,
  input  wire        rb_sel,
  input  wire        rb_we,
  input  wire [11:0] rb_addr,
  input  wire [31:0] rb_wdata,
  input  wire        viol_evt,
  input  wire [31:0] viol_addr
);
  `include "cc_memmap_defs.svh"
  wire [31:0] rb_rdata;
  wire        rb_err, host_lock;
  cc_secmon dut (.clk(clk), .rst_n(rst_n), .rb_sel(rb_sel), .rb_we(rb_we), .rb_addr(rb_addr), .rb_wdata(rb_wdata),
                 .rb_rdata(rb_rdata), .rb_err(rb_err), .viol_evt(viol_evt), .viol_addr(viol_addr), .host_lock(host_lock));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // spec model (asynchronous-reset style: convention C2)
  reg lock_prev, lockwr_prev, m_v;
  reg [31:0] m_d;
  wire wr          = rb_sel && rb_we;
  wire lock_wr     = wr && rb_addr == CC_SEC_CTRL && rb_wdata[0];
  wire meas_wr     = wr && rb_addr == CC_SEC_BOOT_MEASURE;
  wire meas_acc    = meas_wr && !rb_err;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      lock_prev <= 1'b0; lockwr_prev <= 1'b0; m_v <= 1'b0;
    end else begin
      lock_prev   <= host_lock;
      lockwr_prev <= lock_wr;
      if (meas_acc && !m_v) m_v <= 1'b1;
    end
  end
  always @(posedge clk) if (meas_acc && !m_v) m_d <= rb_wdata;
  reg lock_raw;                                  // NOT reset: the value of host_lock in the previous cycle (a reset step itself shows 0)
  always @(posedge clk) lock_raw <= host_lock;

  always @(*) begin
    `ALB_ASSERT(1, a_lock_set_only, "[CC_SEC_CTRL] HOST_LOCK never clears except by reset: once set it stays set (any bus traffic, including CTRL writes of 0)", `ALB_IMPL(lock_prev && rst_n, host_lock))
    `ALB_ASSERT(2, a_lock_only_by_write, "HOST_LOCK rises only in the cycle after a CTRL write with bit 0 = 1 (no other path sets it)", `ALB_IMPL(rst_n && !lock_prev && host_lock, lockwr_prev))
    `ALB_ASSERT(3, a_reset_clears_lock, "reset clears HOST_LOCK (documented reset control state)", `ALB_IMPL(!rst_n, !host_lock))
    `ALB_ASSERT(4, a_measure_second_write_refused, "[BOOT_MEASURE] a second write is refused with rb_err", `ALB_IMPL(meas_wr && m_v, rb_err))
    `ALB_ASSERT(5, a_measure_first_write_accepted, "[BOOT_MEASURE] the first write after reset is accepted", `ALB_IMPL(meas_wr && !m_v, !rb_err))
    `ALB_ASSERT(6, a_measure_holds_value, "[BOOT_MEASURE] reads return the first value written, whatever is written later; 0 before the first write",
                `ALB_IMPL(rb_sel && !rb_we && rb_addr == CC_SEC_BOOT_MEASURE, rb_rdata == (m_v ? m_d : 32'd0)))
    `ALB_ASSERT(7, a_status_lock_bit, "STATUS[0] reads HOST_LOCK", `ALB_IMPL(rb_sel && !rb_we && rb_addr == CC_SEC_STATUS, rb_rdata[0] == host_lock))
    `ALB_ASSERT(8, a_ctrl_readback, "CTRL reads back HOST_LOCK; a write of 0 never reports an error and never clears it", `ALB_IMPL(rb_sel && !rb_we && rb_addr == CC_SEC_CTRL, rb_rdata[0] == host_lock && !rb_err))
    `ALB_ASSERT(9, a_caps_read_only, "CAPS is read-only: a write is refused", `ALB_IMPL(rb_sel && rb_we && rb_addr == CC_SEC_CAPS, rb_err))
  end
  always @(*) begin
    `ALB_COVER(90, c_lock_set,         "HOST_LOCK is set by a CTRL write", host_lock && !lock_prev && rst_n)
    `ALB_COVER(91, c_lock_write_zero_after_set, "a CTRL write of 0 is attempted while locked", lock_prev && wr && rb_addr == CC_SEC_CTRL && !rb_wdata[0])
    `ALB_COVER(92, c_measure_accepted, "a BOOT_MEASURE write is accepted", meas_acc)
    `ALB_COVER(93, c_measure_refused,  "a second BOOT_MEASURE write is refused", meas_wr && m_v && rb_err)
    `ALB_COVER(94, c_measure_read_back,"BOOT_MEASURE is read back after the write", rb_sel && !rb_we && rb_addr == CC_SEC_BOOT_MEASURE && m_v)
    `ALB_COVER(95, c_reset_while_locked, "reset while HOST_LOCK is set", !rst_n && !init_q && lock_raw)
  end
endmodule
`default_nettype wire
