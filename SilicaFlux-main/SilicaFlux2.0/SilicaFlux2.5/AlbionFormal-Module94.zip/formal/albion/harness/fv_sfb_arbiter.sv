// =============================================================================
// AlbionFormal harness :: sfb_arbiter  (DataFabric, per-slave N-way arbiter)
//
// DUT      rtl_under_test/datafabric/rtl/interconnect/sfb_arbiter.sv
// SPEC     DUT header comment + docs/datafabric/PROTOCOL.md section 4 (arbitration and fairness)
// ASSUME-SET  ENV-RST-ANY + ENV-ARB  (listed below; each is also a cover so it cannot be vacuous)
//   ENV-ARB-1  `accept` implies a grant is being presented (accept = s_req_valid && s_req_ready, and the crossbar
//              raises s_req_valid only when the arbiter's grant_valid is high)
//   ENV-ARB-2  `stall` implies a grant is being presented                    (stall = s_req_valid && !s_req_ready)
//   ENV-ARB-3  stall and accept are mutually exclusive in a cycle              (ready is either 0 or 1)
//   `req` is completely free: requesters may withdraw at any time (the legacy CPU instruction port does, PROTOCOL R2)
//
// Reference model: the behaviour documented in the DUT header (fixed priority / rotating priority moved past the
// winner on ACCEPT only / grant lock under back-pressure), transcribed independently into `exp_*` below.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_sfb_arbiter #(
  parameter N       = 3,
  parameter MODE    = 1,              // 0 fixed priority, 1 round robin
  parameter ALB_SEL = 0
) (
  input wire         clk,
  input wire         rst_n,
  input wire [N-1:0] req,
  input wire         stall,
  input wire         accept
);
  localparam IW = (N > 1) ? $clog2(N) : 1;

  wire [N-1:0] grant;
  wire [IW-1:0] grant_idx;
  wire grant_valid;

  sfb_arbiter #(.N(N), .MODE(MODE)) dut (
    .clk(clk), .rst_n(rst_n), .req(req), .stall(stall), .accept(accept),
    .grant(grant), .grant_idx(grant_idx), .grant_valid(grant_valid));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // ------------------------------------------------------------------ environment
  always @(*) begin
    `ALB_ASSUME(e_accept_needs_grant, "ENV-ARB-1 accept only while a grant is presented", `ALB_IMPL(accept, grant_valid))
    `ALB_ASSUME(e_stall_needs_grant,  "ENV-ARB-2 stall only while a grant is presented",  `ALB_IMPL(stall,  grant_valid))
    `ALB_ASSUME(e_stall_accept_excl,  "ENV-ARB-3 stall and accept are mutually exclusive", !(stall && accept))
  end

  // ------------------------------------------------------------------ reference model
  reg [IW-1:0] ptr_m, lock_idx_m;
  reg          lock_m;
  reg          exp_valid;
  reg [IW-1:0] exp_idx;
  wire         lock_hit = lock_m && req[lock_idx_m];
  integer i, idx;
  reg [IW+1:0] sum;
  always @(*) begin
    exp_valid = 1'b0;
    exp_idx   = {IW{1'b0}};
    if (lock_hit) begin
      exp_valid = 1'b1;
      exp_idx   = lock_idx_m;
    end else if (MODE == 0) begin
      for (i = N - 1; i >= 0; i = i - 1)
        if (req[i]) begin exp_valid = 1'b1; exp_idx = i; end
    end else begin
      for (i = N - 1; i >= 0; i = i - 1) begin         // i = offset from the priority pointer
        sum = {1'b0, ptr_m} + i;                        // small-width wrap instead of '%': keeps the SMT encoding cheap
        idx = (sum >= N) ? (sum - N) : sum;
        if (req[idx]) begin exp_valid = 1'b1; exp_idx = idx; end
      end
    end
  end
  // CONVENTION: harness history registers use the same asynchronous reset style as the RTL, so that the reset state is
  // visible in the same step (Yosys `async2sync` model).  A synchronous reset here would disagree with the DUT in step 0.
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      ptr_m <= {IW{1'b0}}; lock_m <= 1'b0; lock_idx_m <= {IW{1'b0}};
    end else begin
      lock_m     <= exp_valid && stall && !accept;
      lock_idx_m <= exp_idx;
      if (MODE != 0 && accept && exp_valid) ptr_m <= (exp_idx == N - 1) ? {IW{1'b0}} : exp_idx + 1'b1;
    end
  end

  // ------------------------------------------------------------------ bounded waiting monitor (safety, not liveness)
  // (* anyconst *): the solver picks one requester k and keeps it for the whole trace; a violation for ANY k is found.
  (* anyconst *) wire [IW-1:0] k;
  reg [IW:0] wcnt;                 // accepted grants to OTHER requesters while req[k] has been continuously asserted
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n)                             wcnt <= {(IW+1){1'b0}};
    else if (!req[k])                       wcnt <= {(IW+1){1'b0}};
    else if (accept && grant_valid) begin
      if (grant_idx == k)                   wcnt <= {(IW+1){1'b0}};
      else if (wcnt != {(IW+1){1'b1}})      wcnt <= wcnt + 1'b1;
    end
  end
  wire k_valid = (k < N);

  // ------------------------------------------------------------------ properties
  always @(*) begin
    `ALB_ASSERT(1, a_grant_onehot0,   "[PROTOCOL 4] grants are mutually exclusive: grant is one-hot or zero", $onehot0(grant))
    `ALB_ASSERT(2, a_grant_subset_req,"a grant is only given to an asserted request", (grant & ~req) == {N{1'b0}})
    `ALB_ASSERT(3, a_valid_iff_grant, "grant_valid is exactly (grant != 0)", grant_valid == (grant != {N{1'b0}}))
    `ALB_ASSERT(4, a_work_conserving, "[PROTOCOL 4] work conservation: any request yields a grant", `ALB_IMPL(req != {N{1'b0}}, grant_valid))
    `ALB_ASSERT(5, a_idx_consistent,  "grant_idx names the granted requester", `ALB_IMPL(grant_valid, grant[grant_idx]))
    `ALB_ASSERT(6, a_matches_reference, "grant == reference model (priority order, pointer move-on-accept, lock)",
                (grant_valid == exp_valid) && `ALB_IMPL(exp_valid, grant_idx == exp_idx))
    `ALB_ASSERT(7, a_lock_holds,      "[PROTOCOL 4] grant lock: a stalled grant is kept while the requester still requests",
                `ALB_IMPL(lock_hit, grant_valid && grant_idx == lock_idx_m))
    if (MODE == 1) begin
      `ALB_ASSERT(8, a_rr_bounded_wait, "[PROTOCOL 4] round robin: a continuously asserted request sees at most N-1 accepted grants to others",
                  !k_valid || wcnt <= N - 1)
    end
  end

  // ------------------------------------------------------------------ vacuity / reachability covers
  always @(*) begin
    `ALB_COVER(90, c_contention,        "two requesters compete and one is granted", $countones(req) >= 2 && grant_valid)
    `ALB_COVER(91, c_lock_engaged,      "a stalled grant is locked into the next cycle", lock_hit && !init_q)
    `ALB_COVER(92, c_lock_withdrawn,    "the locked requester withdraws and the lock is released", lock_m && !req[lock_idx_m] && grant_valid)
    `ALB_COVER(93, c_accept_each_other, "an accepted grant to a requester other than k while req[k] pending", accept && grant_valid && grant_idx != k && req[k] && k_valid)
    `ALB_COVER(94, c_wait_bound_tight,  "wcnt reaches N-1 (the bound is attained, so property 8 is not vacuous)", k_valid && wcnt == N - 1 && req[k])
    `ALB_COVER(95, c_stall,             "a grant is stalled", stall)
    `ALB_COVER(96, c_accept,            "a grant is accepted", accept)
    `ALB_COVER(97, c_wcnt_exceeds,      "wcnt >= N (fixed priority starvation; reachable only for MODE 0)", k_valid && wcnt >= N)
  end
endmodule
`default_nettype wire
