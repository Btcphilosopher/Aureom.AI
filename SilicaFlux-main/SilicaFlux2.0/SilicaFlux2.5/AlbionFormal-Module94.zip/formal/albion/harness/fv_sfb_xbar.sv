// =============================================================================
// AlbionFormal harness :: sfb_crossbar  (SFB2 interconnect NM masters x NS slaves) -- whole-fabric correctness
//
// DUT   rtl_under_test/datafabric/rtl/interconnect/sfb_crossbar.sv (+ arbiter, decoder, mux, router, error slave)
// SPEC  docs/datafabric/PROTOCOL.md  R1-R12 and sections 3-5 (vendored under rtl_under_test/.../docs)
//
// METHOD  The crossbar is checked ONLY THROUGH ITS PORTS against a SPECIFICATION MODEL written here:
//   * an independent address-decode model (lowest permitted slave wins, access matrix, alignment) -- `dec_hit/dec_s`;
//   * per-master shadow state: outstanding count and the destination (slave index or the error slave) of the
//     outstanding transaction -- `out_cnt / own_err / own_s`.
//   Properties relate DUT outputs to (inputs, model).  Nothing inside the DUT is referenced, so the real composition
//   (decoder + arbiter + mux + router + error slaves) is what is proved.
//
// ENVIRONMENT (ASSUME-SET; each is a named `e_*` assumption below)
//   ENV-RST-ANY     reset asserted in step 0, may re-assert at any later step; all components share the reset (R11)
//   ENV-SFB-R2      masters keep a presented request (valid + payload) until it is accepted        (R2)  [R2_MASTERS=1]
//   ENV-SFB-R4      slaves keep a presented response valid and unchanged until accepted            (R4)
//   ENV-SFB-R5      slaves only respond to an earlier-accepted request, never in the acceptance cycle   (R5)
//   ENV-SFB-R8      a slave error response carries rsp_rdata == 0                                    (R8)
//   masters' rsp_ready, slaves' req_ready/rsp_valid/rdata/error are otherwise completely free (arbitrary back-pressure).
//   NOT assumed: any slave latency bound, any fairness.  Nothing here claims liveness.
//
// MAPPING NOTE  "Transaction identifiers remain valid": SFB2 rev 2.0 has NO transaction IDs (PROTOCOL sec. 8: responses
//   can never be re-ordered and need no IDs).  The routing identifiers that do exist are the crossbar's owner records
//   (which master owns each busy slave) and the exported err_master index; properties 13/14 check those.
// =============================================================================
`include "albion_sva.svh"
`default_nettype none
module fv_sfb_xbar #(
  parameter NM = 2, NS = 2, AW = 6, DW = 16, ARB_MODE = 1, CHECK_ALIGN = 1,
  parameter [NS*AW-1:0] SLV_BASE   = 0,
  parameter [NS*AW-1:0] SLV_MASK   = 0,
  parameter [NM*NS-1:0] MST_SLV_EN = {(NM*NS){1'b1}},
  parameter R2_MASTERS = 1,
  parameter R5_SLAVES = 1,            // 1: slaves respond only to accepted requests (assumed); 0: slaves may respond spuriously
  parameter ALB_SEL = 0
) (
  input wire clk, input wire rst_n,
  // master side (free)
  input wire [NM-1:0] m_req_valid, input wire [NM-1:0] m_req_write, input wire [NM*AW-1:0] m_req_addr,
  input wire [NM*DW-1:0] m_req_wdata, input wire [NM*(DW/8)-1:0] m_req_wstrb, input wire [NM-1:0] m_rsp_ready,
  // slave side (free)
  input wire [NS-1:0] s_req_ready, input wire [NS-1:0] s_rsp_valid, input wire [NS*DW-1:0] s_rsp_rdata, input wire [NS-1:0] s_rsp_error
);
  localparam SB = DW / 8;
  localparam MW = (NM > 1) ? $clog2(NM) : 1;
  localparam SW = (NS > 1) ? $clog2(NS) : 1;
  localparam OFF = (DW > 8) ? $clog2(DW / 8) : 1;

  wire [NM-1:0] m_req_ready, m_rsp_valid, m_rsp_error; wire [NM*DW-1:0] m_rsp_rdata;
  wire [NS-1:0] s_req_valid, s_req_write, s_rsp_ready; wire [NS*AW-1:0] s_req_addr; wire [NS*DW-1:0] s_req_wdata; wire [NS*SB-1:0] s_req_wstrb;
  wire err_evt, err_write; wire [AW-1:0] err_addr; wire [MW-1:0] err_master;
  wire [NM-1:0] ev_req_accept, ev_req_stall, ev_arb_loss, ev_rsp_stall;

  sfb_crossbar #(.NM(NM), .NS(NS), .AW(AW), .DW(DW), .ARB_MODE(ARB_MODE), .CHECK_ALIGN(CHECK_ALIGN),
                 .SLV_BASE(SLV_BASE), .SLV_MASK(SLV_MASK), .MST_SLV_EN(MST_SLV_EN)) dut (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_write(m_req_write), .m_req_addr(m_req_addr),
    .m_req_wdata(m_req_wdata), .m_req_wstrb(m_req_wstrb),
    .m_rsp_valid(m_rsp_valid), .m_rsp_ready(m_rsp_ready), .m_rsp_rdata(m_rsp_rdata), .m_rsp_error(m_rsp_error),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_write(s_req_write), .s_req_addr(s_req_addr),
    .s_req_wdata(s_req_wdata), .s_req_wstrb(s_req_wstrb),
    .s_rsp_valid(s_rsp_valid), .s_rsp_ready(s_rsp_ready), .s_rsp_rdata(s_rsp_rdata), .s_rsp_error(s_rsp_error),
    .err_evt(err_evt), .err_addr(err_addr), .err_master(err_master), .err_write(err_write),
    .ev_req_accept(ev_req_accept), .ev_req_stall(ev_req_stall), .ev_arb_loss(ev_arb_loss), .ev_rsp_stall(ev_rsp_stall));

  wire init_q;
  albion_env_reset #(.MODE(1)) u_rst (.clk(clk), .rst_n(rst_n), .init_q(init_q));

  // ------------------------------------------------------------------ protocol monitors / environment
  wire [NM-1:0] mon_m_stable;                       // R2 on each master request channel
  wire [NS-1:0] mon_s_stable;                       // R2 on each slave-side request channel (DUT-driven)
  wire [NS-1:0] mon_rsp_stable, mon_rsp_solicited, mon_rsp_errdata;   // R4 R5 R8 for each slave's response channel
  wire [NS*2-1:0] s_outstanding;                    // accepted-and-unanswered at each slave port (2 bits each)
  wire [NM-1:0] mon_mrsp_stable;                    // R4 on each master response channel (DUT-driven)
  genvar gi;
  generate
    for (gi = 0; gi < NM; gi = gi + 1) begin : g_m
      albion_sfb_req_mon #(.AW(AW), .DW(DW)) u_req (.clk(clk), .rst_n(rst_n), .valid(m_req_valid[gi]), .ready(m_req_ready[gi]),
        .write(m_req_write[gi]), .addr(m_req_addr[gi*AW +: AW]), .wdata(m_req_wdata[gi*DW +: DW]), .wstrb(m_req_wstrb[gi*SB +: SB]),
        .stable_ok(mon_m_stable[gi]), .accepted(), .held());
      albion_sfb_rsp_mon #(.DW(DW), .OW(2)) u_rsp (.clk(clk), .rst_n(rst_n), .req_acc(m_req_valid[gi] && m_req_ready[gi]),
        .rsp_valid(m_rsp_valid[gi]), .rsp_ready(m_rsp_ready[gi]), .rsp_rdata(m_rsp_rdata[gi*DW +: DW]), .rsp_error(m_rsp_error[gi]),
        .stable_ok(mon_mrsp_stable[gi]), .solicited_ok(), .errdata_ok(), .outstanding(), .rsp_hs());
    end
    for (gi = 0; gi < NS; gi = gi + 1) begin : g_s
      albion_sfb_req_mon #(.AW(AW), .DW(DW)) u_req (.clk(clk), .rst_n(rst_n), .valid(s_req_valid[gi]), .ready(s_req_ready[gi]),
        .write(s_req_write[gi]), .addr(s_req_addr[gi*AW +: AW]), .wdata(s_req_wdata[gi*DW +: DW]), .wstrb(s_req_wstrb[gi*SB +: SB]),
        .stable_ok(mon_s_stable[gi]), .accepted(), .held());
      albion_sfb_rsp_mon #(.DW(DW), .OW(2)) u_rsp (.clk(clk), .rst_n(rst_n), .req_acc(s_req_valid[gi] && s_req_ready[gi]),
        .rsp_valid(s_rsp_valid[gi]), .rsp_ready(s_rsp_ready[gi]), .rsp_rdata(s_rsp_rdata[gi*DW +: DW]), .rsp_error(s_rsp_error[gi]),
        .stable_ok(mon_rsp_stable[gi]), .solicited_ok(mon_rsp_solicited[gi]), .errdata_ok(mon_rsp_errdata[gi]),
        .outstanding(s_outstanding[gi*2 +: 2]), .rsp_hs());
    end
  endgenerate

  always @(*) begin
    if (R2_MASTERS != 0) begin
      `ALB_ASSUME(e_m_r2,       "ENV-SFB-R2 masters hold a presented request and its payload until it is accepted", &mon_m_stable)
    end
    `ALB_ASSUME(e_s_r4,         "ENV-SFB-R4 a slave keeps a presented response valid and unchanged until accepted", &mon_rsp_stable)
    if (R5_SLAVES != 0) begin
      `ALB_ASSUME(e_s_r5,       "ENV-SFB-R5 a slave responds only to an earlier-accepted request (never in the acceptance cycle)", &mon_rsp_solicited)
    end
    `ALB_ASSUME(e_s_r8,         "ENV-SFB-R8 a slave error response has rsp_rdata == 0", &mon_rsp_errdata)
  end

  // ------------------------------------------------------------------ specification model: address decode (independent)
  integer m, s, k;
  reg [NM-1:0]    dec_hit, region_any;
  reg [NM*SW-1:0] dec_s;
  reg [NM-1:0]    aligned;
  always @(*) begin
    for (m = 0; m < NM; m = m + 1) begin
      dec_hit[m] = 1'b0; region_any[m] = 1'b0; dec_s[m*SW +: SW] = {SW{1'b0}};
      for (s = NS - 1; s >= 0; s = s - 1)
        if ((m_req_addr[m*AW +: AW] & SLV_MASK[s*AW +: AW]) == SLV_BASE[s*AW +: AW]) begin
          region_any[m] = 1'b1;
          if (MST_SLV_EN[m*NS + s]) begin dec_hit[m] = 1'b1; dec_s[m*SW +: SW] = s; end
        end
      aligned[m] = (CHECK_ALIGN == 0) || (DW <= 8) || (m_req_addr[m*AW +: OFF] == {OFF{1'b0}});
      if (!aligned[m]) dec_hit[m] = 1'b0;
    end
  end
  wire [NM-1:0] acc_m = m_req_valid & m_req_ready;
  wire [NS-1:0] acc_s = s_req_valid & s_req_ready;

  // ------------------------------------------------------------------ specification model: per-master shadow state
  reg [1:0]       out_cnt [0:NM-1];          // transactions outstanding at master port m (spec: 0 or 1)
  reg             own_err [0:NM-1];          // the outstanding transaction was routed to the error slave
  reg [SW-1:0]    own_s   [0:NM-1];          // ... or to this slave
  wire [NM-1:0]   m_rsp_hs = m_rsp_valid & m_rsp_ready;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (k = 0; k < NM; k = k + 1) begin out_cnt[k] <= 2'd0; own_err[k] <= 1'b0; own_s[k] <= {SW{1'b0}}; end
    end else begin
      for (k = 0; k < NM; k = k + 1) begin
        out_cnt[k] <= out_cnt[k] + {1'b0, acc_m[k]} - {1'b0, m_rsp_hs[k]};
        if (acc_m[k]) begin own_err[k] <= !dec_hit[k]; own_s[k] <= dec_s[k*SW +: SW]; end
      end
    end
  end

  // ------------------------------------------------------------------ violation flags (computed with loops, asserted below)
  reg v_route, v_payload, v_attrib, v_conserve, v_err_capture, v_one_out_m, v_one_out_s, v_m_rsp_solicited, v_rsp_owner, v_rsp_routed,
      v_owner_unique, v_err_idx, v_work_cons, v_free_rule;
  integer n_acc_m, n_acc_s, ex_acc, ex_pay, ex_cand, n_owner, lowest_err;
  reg [MW-1:0] lowest_m;
  reg have_lowest;
  reg own_valid_src;
  always @(*) begin
    v_route = 0; v_payload = 0; v_attrib = 0; v_conserve = 0; v_err_capture = 0; v_one_out_m = 0; v_one_out_s = 0;
    v_m_rsp_solicited = 0; v_rsp_owner = 0; v_rsp_routed = 0; v_owner_unique = 0; v_err_idx = 0; v_work_cons = 0; v_free_rule = 0;
    n_acc_m = 0; n_acc_s = 0; have_lowest = 0; lowest_m = {MW{1'b0}};
    for (m = 0; m < NM; m = m + 1) begin
      if (acc_m[m] && dec_hit[m]) n_acc_m = n_acc_m + 1;
      if (!have_lowest && acc_m[m] && !dec_hit[m]) begin have_lowest = 1; lowest_m = m; end
    end
    for (s = 0; s < NS; s = s + 1) if (acc_s[s]) n_acc_s = n_acc_s + 1;
    v_conserve = (n_acc_m != n_acc_s);
    // ---- slave side: every presented/accepted slave request comes from exactly the master the map routes to it
    for (s = 0; s < NS; s = s + 1) begin
      ex_acc = 0; ex_pay = 0; ex_cand = 0;
      for (m = 0; m < NM; m = m + 1)
        if (m_req_valid[m] && dec_hit[m] && dec_s[m*SW +: SW] == s) begin
          if (s_req_write[s] == m_req_write[m] && s_req_addr[s*AW +: AW] == m_req_addr[m*AW +: AW] &&
              s_req_wdata[s*DW +: DW] == m_req_wdata[m*DW +: DW] && s_req_wstrb[s*SB +: SB] == m_req_wstrb[m*SB +: SB]) ex_pay = 1;
          if (acc_m[m]) ex_acc = 1;
        end
      if (s_req_valid[s] && !ex_pay) v_payload = 1;                                  // payload of a real, routed requester
      if (acc_s[s] && !ex_acc) v_route = 1;                                          // accepted only if a master's accept is routed here
    end
    // ---- master side: an accepted routed request is accepted by exactly its slave with the same payload
    for (m = 0; m < NM; m = m + 1)
      if (acc_m[m] && dec_hit[m]) begin
        s = dec_s[m*SW +: SW];
        if (!acc_s[s] || s_req_write[s] != m_req_write[m] || s_req_addr[s*AW +: AW] != m_req_addr[m*AW +: AW] ||
            s_req_wdata[s*DW +: DW] != m_req_wdata[m*DW +: DW] || s_req_wstrb[s*SB +: SB] != m_req_wstrb[m*SB +: SB]) v_attrib = 1;
      end
    // ---- decode-error capture port
    if (err_evt != have_lowest) v_err_capture = 1;
    if (have_lowest && (err_master != lowest_m || err_addr != m_req_addr[lowest_m*AW +: AW] || err_write != m_req_write[lowest_m])) v_err_capture = 1;
    if (have_lowest && lowest_m >= NM) v_err_idx = 1;
    if (err_evt && err_master >= NM) v_err_idx = 1;
    // ---- R6 one transaction per master port / per slave port, R5 solicited master responses
    for (m = 0; m < NM; m = m + 1) begin
      if (out_cnt[m] > 2'd1) v_one_out_m = 1;
      if (acc_m[m] && out_cnt[m] != 2'd0 && !m_rsp_hs[m]) v_free_rule = 1;           // new request only if idle or retiring
      if (m_rsp_valid[m] && out_cnt[m] == 2'd0) v_m_rsp_solicited = 1;
      // response correspondence: the valid response of master m is the response of the slave it was routed to
      if (m_rsp_valid[m] && out_cnt[m] != 2'd0) begin
        if (own_err[m]) begin
          if (!m_rsp_error[m] || m_rsp_rdata[m*DW +: DW] != {DW{1'b0}}) v_rsp_owner = 1;
        end else begin
          s = own_s[m];
          if (!s_rsp_valid[s] || s_outstanding[s*2 +: 2] == 2'd0 || m_rsp_error[m] != s_rsp_error[s] ||
              m_rsp_rdata[m*DW +: DW] != s_rsp_rdata[s*DW +: DW]) v_rsp_owner = 1;
        end
      end
    end
    for (s = 0; s < NS; s = s + 1) begin
      if (s_outstanding[s*2 +: 2] > 2'd1) v_one_out_s = 1;
      // owner records: at most one master owns a busy slave; a slave response reaches exactly its owner, with its ready
      n_owner = 0;
      for (m = 0; m < NM; m = m + 1)
        if (out_cnt[m] != 2'd0 && !own_err[m] && own_s[m] == s) begin
          n_owner = n_owner + 1;
          if (s_rsp_valid[s] && s_outstanding[s*2 +: 2] != 2'd0 && (!m_rsp_valid[m] || s_rsp_ready[s] != m_rsp_ready[m])) v_rsp_routed = 1;
        end
      if (n_owner > 1) v_owner_unique = 1;
      if (s_outstanding[s*2 +: 2] != 2'd0 && n_owner != 1) v_owner_unique = 1;      // a busy slave has exactly one owning master
      if (s_outstanding[s*2 +: 2] == 2'd0 && n_owner != 0) v_owner_unique = 1;
    end
    // ---- work conservation: a free slave facing a free, routed requester presents a request (someone is granted)
    for (s = 0; s < NS; s = s + 1) begin
      ex_cand = 0;
      for (m = 0; m < NM; m = m + 1)
        if (m_req_valid[m] && dec_hit[m] && dec_s[m*SW +: SW] == s && (out_cnt[m] == 2'd0 || m_rsp_hs[m])) ex_cand = 1;
      if (ex_cand && (s_outstanding[s*2 +: 2] == 2'd0 || (s_rsp_valid[s] && s_rsp_ready[s])) && !s_req_valid[s]) v_work_cons = 1;
    end
  end

  // covers helper: was a transaction outstanding in the PREVIOUS cycle (shadow regs reset immediately, so sample without reset)
  reg busy_prev;
  always @(posedge clk) busy_prev <= (out_cnt[0] != 2'd0);
  // covers helpers
  reg c_contend, c_denied_matrix_cov;
  integer n_same;
  always @(*) begin
    c_contend = 1'b0; c_denied_matrix_cov = 1'b0;
    for (s = 0; s < NS; s = s + 1) begin
      n_same = 0;
      for (m = 0; m < NM; m = m + 1) if (m_req_valid[m] && dec_hit[m] && dec_s[m*SW +: SW] == s) n_same = n_same + 1;
      if (n_same >= 2) c_contend = 1'b1;
    end
    for (m = 0; m < NM; m = m + 1) if (m_req_valid[m] && aligned[m] && region_any[m] && !dec_hit[m]) c_denied_matrix_cov = 1'b1;
  end

  // ------------------------------------------------------------------ properties
  always @(*) begin
    `ALB_ASSERT(1,  a_route_exact,      "[R8/R9] a slave accepts a request only if the address map routes a master's accepted request to it (no invalid destination)", !v_route)
    `ALB_ASSERT(2,  a_payload_intact,   "a request presented to a slave carries the payload of a master whose address decodes to that slave", !v_payload)
    `ALB_ASSERT(3,  a_master_attributed,"an accepted routed master request is accepted by exactly its decoded slave in the same cycle with an identical payload", !v_attrib)
    `ALB_ASSERT(4,  a_no_duplication,   "[R1/R5] requests are not duplicated or invented: #routed master accepts == #slave accepts in every cycle", !v_conserve)
    `ALB_ASSERT(5,  a_err_capture,      "decode-error capture port reports exactly the lowest-index master whose unmapped/denied/misaligned request was accepted", !v_err_capture)
    `ALB_ASSERT(6,  a_one_out_master,   "[R6] a master port never has more than one transaction outstanding", !v_one_out_m)
    `ALB_ASSERT(7,  a_one_out_slave,    "[R6] a slave port never has more than one transaction outstanding", !v_one_out_s)
    `ALB_ASSERT(8,  a_free_rule,        "[R6] a new request is accepted only if nothing is outstanding or the previous response is accepted in that cycle", !v_free_rule)
    `ALB_ASSERT(9,  a_rsp_solicited,    "[R5] a master receives a response only while one of its earlier-accepted requests is outstanding", !v_m_rsp_solicited)
    `ALB_ASSERT(10, a_rsp_corresponds,  "responses correspond to requests: a master's response is exactly the response of the slave (or error slave) its request was routed to", !v_rsp_owner)
    `ALB_ASSERT(11, a_rsp_to_owner,     "a slave's response is delivered to its owning master, together with that master's rsp_ready (no foreign delivery)", !v_rsp_routed)
    `ALB_ASSERT(12, a_owner_records,    "routing identifiers valid: each busy slave has exactly one owning master, idle slaves have none; err_master < NM", !v_owner_unique && !v_err_idx)
    `ALB_ASSERT(13, a_work_conserving,  "a free slave facing a free, routed requester always presents a request (a grant is always issued)", !v_work_cons)
    `ALB_ASSERT(14, a_s_req_stable,     "[R2] slave-side request stays presented with an unchanged payload until accepted (grant lock), given R2 masters", &mon_s_stable)
    `ALB_ASSERT(15, a_m_rsp_stable,     "[R4] master-side response stays valid and unchanged until accepted", &mon_mrsp_stable)
    `ALB_ASSERT(16, a_r11_no_rsp_in_reset, "[R11] during reset the fabric presents no response", `ALB_IMPL(!rst_n, m_rsp_valid == {NM{1'b0}}))
    `ALB_ASSERT(17, a_r11_no_ready_in_reset, "[R11] during reset the fabric's req_ready is 0 (so reset can generate no transfer)", `ALB_IMPL(!rst_n, m_req_ready == {NM{1'b0}}))
    `ALB_ASSERT(18, a_r11_no_slave_req_in_reset, "[R11 corollary] during reset no request is presented to a slave", `ALB_IMPL(!rst_n, s_req_valid == {NS{1'b0}}))
    `ALB_COVER(90, c_route_to_each,   "a master request is accepted by a slave", |acc_s)
    `ALB_COVER(91, c_contention,      "two masters present requests to the same slave in one cycle", c_contend)
    `ALB_COVER(92, c_decode_error,    "a request with no permitted/aligned destination is accepted by the error slave", have_lowest)
    `ALB_COVER(93, c_matrix_denied,   "a request inside a slave region is rejected by the access matrix", c_denied_matrix_cov)
    `ALB_COVER(94, c_back_to_back,    "[R6] a new request is accepted in the cycle the previous response is accepted", |(acc_m & m_rsp_hs))
    `ALB_COVER(95, c_rsp_backpressure,"a master stalls a valid response", |(m_rsp_valid & ~m_rsp_ready))
    `ALB_COVER(96, c_slave_stall,     "a slave stalls a presented request", |(s_req_valid & ~s_req_ready))
    `ALB_COVER(97, c_arb_loss,        "an eligible master loses arbitration", |ev_arb_loss)
    `ALB_COVER(98, c_response_routed, "a slave response reaches its owner", |(m_rsp_hs & {NM{|s_rsp_valid}}) && !have_lowest)
    `ALB_COVER(99, c_reset_mid_flight,"reset asserted while a transaction was outstanding in the previous cycle", !rst_n && busy_prev)
  end
endmodule
`default_nettype wire
