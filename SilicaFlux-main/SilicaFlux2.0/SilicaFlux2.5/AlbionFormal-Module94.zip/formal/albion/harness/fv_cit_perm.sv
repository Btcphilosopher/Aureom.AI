// =============================================================================
// AlbionFormal harness :: sf_citadel_permission  (Citadel hardware permission checker, purely combinational)
//
// DUT      rtl_under_test/citadel/rtl/albion/sf_citadel_permission.sv        SPEC  docs/citadel/02_PERMISSION_CHECKER.md
//
// Combinational => every property is proved FROM ANY INPUT / TABLE STATE (ENV-RST-NONE: no reset constraint, no clock).
// The descriptor-state inputs are completely free: not even table invariants are assumed, except in the UNIQ=1 job.
//
// INDEPENDENT REFERENCE.  `spec_exist` is a declarative predicate written from the documented decision order WITHOUT the
// RTL's first-match priority lookup: "there EXISTS a slot that is enrolled with this id, bound to src_i, ACTIVE, within its
// capabilities, and that owns the requested access".  Consequences:
//   * a_permit_implies_spec (permit => spec_exist) holds with NO assumption (priority-free, so duplicate ids cannot weaken it);
//   * the converse (equivalence) additionally needs unique ids among enrolled slots (INV-UNIQ): job UNIQ=1 assumes it as
//     ENV-SEC-PERM-UNIQ, which is discharged by SEC-TBL a_unique_ids (proved for the real table).
//
// PARAMETER POINT (small, so ABC can close): NDOM=2 NW=2 NP=2 NDEV=2 NQ=2 AW=8 LEN_W=8.  The logic is width/count-generic, but a
// proof at AW=8 is NOT a proof at AW=64 (the product width); that step is an argument by parametricity, never a theorem here.
// Device map (explicit overrides: Yosys 0.33 cannot take package references in parameter defaults):
//   dev0 = {a : a & F0 == F0} = F0..FF   privileged-only      dev1 = {a : a & F8 == E0} = E0..E7   secure-only
// =============================================================================
`include "albion_sva.svh"
`default_nettype none

module fv_cit_perm #(
  parameter NDOM = 2, parameter NW = 2, parameter NP = 2, parameter NDEV = 2, parameter NQ = 2,
  parameter AW = 8, parameter LEN_W = 8, parameter UNIQ = 0, parameter ALB_SEL = 0,
  parameter [NDEV*AW-1:0] DEV_BASE   = 16'hE0F0,
  parameter [NDEV*AW-1:0] DEV_MASK   = 16'hF8F0,
  parameter [NDEV-1:0]    DEV_PRIV   = 2'b01,
  parameter [NDEV-1:0]    DEV_SECURE = 2'b10,
  localparam SRC_W = (NP > 1) ? $clog2(NP) : 1
) (
  input wire [SRC_W-1:0]      src_i,
  input wire [7:0]            dom_i,
  input wire [3:0]            op_i,
  input wire [7:0]            attr_i,
  input wire [AW-1:0]         addr_i,
  input wire [LEN_W-1:0]      len_i,
  input wire [1:0]            cls_i,
  input wire [7:0]            idx_i,
  input wire                  lockdown_i,
  input wire                  dft_active_i,
  input wire [NQ-1:0]         qhold_i,
  input wire [NP-1:0]         port_isol_i,
  input wire [NDOM*2-1:0]     slot_state_i,
  input wire [NDOM*8-1:0]     slot_id_i,
  input wire [NDOM-1:0]       slot_priv_i,
  input wire [NDOM-1:0]       slot_secure_i,
  input wire [NDOM*NW-1:0]    win_valid_i,
  input wire [NDOM*NW*AW-1:0] win_base_i,
  input wire [NDOM*NW*AW-1:0] win_limit_i,
  input wire [NDOM*NW-1:0]    win_r_i,
  input wire [NDOM*NW-1:0]    win_w_i,
  input wire [NDOM*NW-1:0]    win_x_i,
  input wire [NDOM*NDEV-1:0]  devrd_i,
  input wire [NDOM*NDEV-1:0]  devwr_i,
  input wire [NDOM*NQ-1:0]    qmask_i,
  input wire [NP*NDOM-1:0]    bind_i
);
  localparam SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1;
  wire                 permit_o, slot_vld_o;
  wire [3:0]           reason_o, status_o;
  wire [SLOT_W-1:0]    slot_o;

  sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(NDEV), .NQ(NQ), .AW(AW), .LEN_W(LEN_W),
                          .DEV_BASE(DEV_BASE), .DEV_MASK(DEV_MASK), .DEV_PRIV(DEV_PRIV), .DEV_SECURE(DEV_SECURE)) dut (
    .src_i(src_i), .dom_i(dom_i), .op_i(op_i), .attr_i(attr_i), .addr_i(addr_i), .len_i(len_i), .cls_i(cls_i), .idx_i(idx_i),
    .lockdown_i(lockdown_i), .dft_active_i(dft_active_i), .qhold_i(qhold_i), .port_isol_i(port_isol_i),
    .slot_state_i(slot_state_i), .slot_id_i(slot_id_i), .slot_priv_i(slot_priv_i), .slot_secure_i(slot_secure_i),
    .win_valid_i(win_valid_i), .win_base_i(win_base_i), .win_limit_i(win_limit_i), .win_r_i(win_r_i), .win_w_i(win_w_i), .win_x_i(win_x_i),
    .devrd_i(devrd_i), .devwr_i(devwr_i), .qmask_i(qmask_i), .bind_i(bind_i),
    .permit_o(permit_o), .reason_o(reason_o), .status_o(status_o), .slot_vld_o(slot_vld_o), .slot_o(slot_o));

  localparam [3:0] OP_READ = 4'h1, OP_WRITE = 4'h2;
  localparam [3:0] ST_OKAY = 4'h0, ST_DENIED = 4'h2, ST_BADOP = 4'h3, ST_BADATTR = 4'h6;
  localparam [1:0] DS_INVALID = 2'd0, DS_ACTIVE = 2'd2;

  // ------------------------------------------------------------------ declarative reference
  localparam SW = AW + LEN_W + 1;
  wire [SW-1:0] last_w  = {{(SW-AW){1'b0}}, addr_i} + {{(SW-LEN_W){1'b0}}, len_i} - 1'b1;
  wire          no_wrap = (len_i != {LEN_W{1'b0}}) && (last_w[SW-1:AW] == {(SW-AW){1'b0}});
  wire [AW-1:0] last    = last_w[AW-1:0];
  wire a_priv = attr_i[2], a_secure = attr_i[3], a_instr = attr_i[4];
  wire form_ok = (cls_i == 2'd0 || cls_i == 2'd1) && (op_i == OP_READ || op_i == OP_WRITE) &&
                 !attr_i[7] && (attr_i[1:0] != 2'd3) && !(a_instr && op_i == OP_WRITE);
  wire src_isol = port_isol_i[src_i];
  wire is_sys   = (dom_i == 8'h00) || (dom_i == 8'h01);
  wire base_ok  = !src_isol && !dft_active_i && form_ok && (dom_i != 8'hFF) && !(lockdown_i && !is_sys);

  reg [NDEV-1:0] dev_ov, dev_in;
  reg            dev_any, dev_one, dev_whole;
  reg [NDOM-1:0] match, bound, active, capab, slot_ok, mem_ok, dev_ok, q_ok, addr_ok;
  reg [NDOM-1:0] cont_r, cont_w, cont_any;
  reg [NDOM-1:0] cap_priv_ok, cap_sec_ok;
  integer s, k, i;
  always @(*) begin
    dev_ov = {NDEV{1'b0}}; dev_in = {NDEV{1'b0}};
    for (i = 0; i < NDEV; i = i + 1) begin
      if (DEV_MASK[i*AW +: AW] != {AW{1'b0}}) begin
        dev_ov[i] = (addr_i <= (DEV_BASE[i*AW +: AW] | ~DEV_MASK[i*AW +: AW])) && (last >= DEV_BASE[i*AW +: AW]);
        dev_in[i] = (addr_i >= DEV_BASE[i*AW +: AW]) && (last <= (DEV_BASE[i*AW +: AW] | ~DEV_MASK[i*AW +: AW]));
      end
    end
    dev_any = (dev_ov != {NDEV{1'b0}});
    dev_one = dev_any && ((dev_ov & (dev_ov - 1'b1)) == {NDEV{1'b0}});
    dev_whole = dev_one && ((dev_ov & dev_in) != {NDEV{1'b0}});
    for (s = 0; s < NDOM; s = s + 1) begin
      match[s]  = (slot_state_i[s*2 +: 2] != DS_INVALID) && (slot_id_i[s*8 +: 8] == dom_i);
      bound[s]  = bind_i[src_i*NDOM + s];
      active[s] = (slot_state_i[s*2 +: 2] == DS_ACTIVE);
      cap_priv_ok[s] = !a_priv   || slot_priv_i[s];
      cap_sec_ok[s]  = !a_secure || slot_secure_i[s];
      capab[s]  = cap_priv_ok[s] && cap_sec_ok[s];
      slot_ok[s] = match[s] && bound[s] && active[s] && capab[s];
      // memory windows
      cont_any[s] = 1'b0; cont_r[s] = 1'b0; cont_w[s] = 1'b0; mem_ok[s] = 1'b0;
      for (k = 0; k < NW; k = k + 1) begin
        if (win_valid_i[s*NW+k] && addr_i >= win_base_i[(s*NW+k)*AW +: AW] && last <= win_limit_i[(s*NW+k)*AW +: AW]) begin
          cont_any[s] = 1'b1;
          if (win_r_i[s*NW+k]) cont_r[s] = 1'b1;
          if (win_w_i[s*NW+k]) cont_w[s] = 1'b1;
          if ((op_i == OP_READ ? win_r_i[s*NW+k] : win_w_i[s*NW+k]) && (!a_instr || win_x_i[s*NW+k])) mem_ok[s] = 1'b1;
        end
      end
      // device rules (the single device the range lies wholly inside)
      dev_ok[s] = 1'b0;
      for (i = 0; i < NDEV; i = i + 1) begin
        if (dev_whole && dev_ov[i] &&
            (!DEV_PRIV[i] || a_priv) && (!DEV_SECURE[i] || a_secure) && !a_instr &&
            (op_i == OP_READ ? devrd_i[s*NDEV+i] : devwr_i[s*NDEV+i]))
          dev_ok[s] = 1'b1;
      end
      addr_ok[s] = no_wrap && (dev_any ? dev_ok[s] : mem_ok[s]);
      // queue class
      q_ok[s] = 1'b0;
      for (i = 0; i < NQ; i = i + 1)
        if (idx_i == i && !qhold_i[i] && qmask_i[s*NQ + i]) q_ok[s] = 1'b1;
    end
  end
  reg spec_exist;
  always @(*) begin
    spec_exist = 1'b0;
    for (s = 0; s < NDOM; s = s + 1)
      if (base_ok && slot_ok[s] && (cls_i == 2'd1 ? q_ok[s] : addr_ok[s])) spec_exist = 1'b1;
  end

  // unique ids among enrolled slots (INV-UNIQ) -- assumed only when UNIQ = 1
  reg uniq_ok;
  always @(*) begin
    uniq_ok = 1'b1;
    for (s = 0; s < NDOM; s = s + 1)
      for (k = 0; k < NDOM; k = k + 1)
        if (s != k && slot_state_i[s*2 +: 2] != DS_INVALID && slot_state_i[k*2 +: 2] != DS_INVALID && slot_id_i[s*8 +: 8] == slot_id_i[k*8 +: 8])
          uniq_ok = 1'b0;
  end

  wire [NDOM-1:0] mw = match & bound;                       // "known and bound to the physical source port"
  wire [NDOM-1:0] mwa = match & bound & active;
  reg  perm_has_w, perm_has_r, any_mwa_priv, any_mwa_sec;
  always @(*) begin
    perm_has_w = 1'b0; perm_has_r = 1'b0; any_mwa_priv = 1'b0; any_mwa_sec = 1'b0;
    for (s = 0; s < NDOM; s = s + 1) begin
      if (slot_ok[s] && cont_w[s]) perm_has_w = 1'b1;
      if (slot_ok[s] && cont_r[s]) perm_has_r = 1'b1;
      if (mwa[s] && slot_priv_i[s])   any_mwa_priv = 1'b1;
      if (mwa[s] && slot_secure_i[s]) any_mwa_sec = 1'b1;
    end
  end
  reg qperm;
  always @(*) begin
    qperm = 1'b0;
    for (s = 0; s < NDOM; s = s + 1) if (slot_ok[s] && q_ok[s]) qperm = 1'b1;
  end

  // ------------------------------------------------------------------ environment
  always @(*) begin
    if (UNIQ != 0) begin
      `ALB_ASSUME(e_unique_ids, "ENV-SEC-PERM-UNIQ enrolled slots have pairwise distinct domain ids (INV-UNIQ; discharged by SEC-TBL a_unique_ids)", uniq_ok)
    end
  end

  // ------------------------------------------------------------------ properties
  always @(*) begin
    `ALB_ASSERT(1, a_permit_implies_spec, "[02] permit => an enrolled, ACTIVE, capable slot bound to src_i owns the request (priority-free declarative predicate)",
                `ALB_IMPL(permit_o, spec_exist))
    if (UNIQ != 0) begin
      `ALB_ASSERT(2, a_equiv_spec, "[02] (INV-UNIQ) permit <=> the declarative predicate: the checker is exactly its specification", permit_o == spec_exist)
    end
    `ALB_ASSERT(3, a_spoof_denied, "[02 step 7 / domain association] a domain id not bound to the PHYSICAL source port is always denied", `ALB_IMPL(mw == {NDOM{1'b0}}, !permit_o))
    `ALB_ASSERT(4, a_unknown_denied, "[02 step 7] an unknown domain id is always denied", `ALB_IMPL(match == {NDOM{1'b0}}, !permit_o))
    `ALB_ASSERT(5, a_inactive_denied, "[02 step 9] a domain that is not ACTIVE (INVALID / SUSPENDED / QUARANTINED) is always denied", `ALB_IMPL(mwa == {NDOM{1'b0}}, !permit_o))
    `ALB_ASSERT(6, a_isolated_denied, "[02 step 1] an isolated source port is always denied", `ALB_IMPL(src_isol, !permit_o))
    `ALB_ASSERT(7, a_dft_denied, "[02 step 2] DFT / test access active denies everyone", `ALB_IMPL(dft_active_i, !permit_o))
    `ALB_ASSERT(8, a_lockdown_denied, "[02 step 8] safe state denies every domain except ROOT/MGMT", `ALB_IMPL(lockdown_i && !is_sys, !permit_o))
    `ALB_ASSERT(9, a_invalid_dom_denied, "[02 step 6] domain id 0xFF (INVALID) is always denied", `ALB_IMPL(dom_i == 8'hFF, !permit_o))
    `ALB_ASSERT(10, a_no_wrap, "[02 step 11-12] an ADDR permit has a non-zero length and addr+len-1 does not wrap the address space", `ALB_IMPL(permit_o && cls_i == 2'd0, no_wrap))
    `ALB_ASSERT(11, a_permit_mem_window, "[02] a memory permit => the range lies inside ONE valid window of an owning slot that grants the access",
                `ALB_IMPL(permit_o && cls_i == 2'd0 && !dev_any, (|(slot_ok & mem_ok))))
    `ALB_ASSERT(12, a_permit_device_rules, "[02 step 13] a device permit => range wholly inside exactly one device, priv/secure met, no instruction fetch, device permission",
                `ALB_IMPL(permit_o && cls_i == 2'd0 && dev_any, dev_whole && (|(slot_ok & dev_ok))))
    `ALB_ASSERT(13, a_write_needs_write_right, "[02] a WRITE memory permit needs a window with the WRITE right (the read right is not enough)",
                `ALB_IMPL(permit_o && cls_i == 2'd0 && !dev_any && op_i == OP_WRITE, perm_has_w))
    `ALB_ASSERT(14, a_read_needs_read_right, "[02] a READ memory permit needs a window with the READ right", `ALB_IMPL(permit_o && cls_i == 2'd0 && !dev_any && op_i == OP_READ, perm_has_r))
    `ALB_ASSERT(15, a_instr_not_write, "[02 step 5] an instruction-fetch attribute with a WRITE is never permitted", `ALB_IMPL(attr_i[4] && op_i == OP_WRITE, !permit_o))
    `ALB_ASSERT(16, a_queue_rules, "[02] a QUEUE permit => idx < NQ, queue not on abort-hold, queue in the owning domain's mask",
                `ALB_IMPL(permit_o && cls_i == 2'd1, (idx_i < NQ) && qperm))
    `ALB_ASSERT(17, a_privilege_not_escalated, "[02 step 10] a privileged / secure attribute is only permitted for a domain with that capability",
                `ALB_IMPL(permit_o && a_priv, any_mwa_priv) && `ALB_IMPL(permit_o && a_secure, any_mwa_sec))
    `ALB_ASSERT(18, a_permit_iff_okay, "[02] permit <=> status OKAY: every denial is an explicit error (also discharges ENV-SEC-GATE-V1)", permit_o == (status_o == ST_OKAY))
    `ALB_ASSERT(19, a_status_coarse, "[02] the requester sees only OKAY / BAD_OPCODE / BAD_ATTR / ACCESS_DENIED (no layout oracle)",
                status_o == ST_OKAY || status_o == ST_BADOP || status_o == ST_BADATTR || status_o == ST_DENIED)
    `ALB_ASSERT(20, a_status_from_reason, "[02] status is a pure coarse function of the reason (OK / BAD_OP / BAD_ATTR / everything else ACCESS_DENIED)",
                status_o == (reason_o == 4'd0 ? ST_OKAY : reason_o == 4'd1 ? ST_BADOP : reason_o == 4'd2 ? ST_BADATTR : ST_DENIED))
    `ALB_ASSERT(21, a_reason_range, "[02] reason is a defined code (<= 13) and 0 exactly when permitted", (reason_o <= 4'd13) && (permit_o == (reason_o == 4'd0)))
    `ALB_ASSERT(22, a_slot_attribution, "[02] slot_vld_o => the attributed slot is enrolled with this id AND bound to src_i (safe to attribute)",
                `ALB_IMPL(slot_vld_o, match[slot_o] && bound[slot_o]))
    `ALB_ASSERT(23, a_permit_needs_attribution, "[02] a permit always comes with a verified domain attribution", `ALB_IMPL(permit_o, slot_vld_o))
  end

  // ------------------------------------------------------------------ vacuity / reachability covers
  always @(*) begin
    `ALB_COVER(90, c_permit_mem,    "a memory access is permitted", permit_o && cls_i == 2'd0 && !dev_any)
    `ALB_COVER(91, c_permit_device, "a device access is permitted", permit_o && cls_i == 2'd0 && dev_any)
    `ALB_COVER(92, c_permit_queue,  "a queue use is permitted", permit_o && cls_i == 2'd1)
    `ALB_COVER(93, c_deny_spoof,    "spoof: a known, ACTIVE domain presented on a port it is not bound to is denied (reason BAD_DOM)", (|(match & active)) && !(|mw) && reason_o == 4'd3)
    `ALB_COVER(94, c_deny_state,    "a bound domain that is not ACTIVE is denied (DOM_STATE)", (|mw) && !(|mwa) && reason_o == 4'd6)
    `ALB_COVER(95, c_deny_nomap,    "no single window contains the range (NOMAP)", reason_o == 4'd7)
    `ALB_COVER(96, c_deny_perm,     "a window contains the range but lacks the right (PERM)", reason_o == 4'd8 && (|(slot_ok & cont_any)))
    `ALB_COVER(97, c_deny_dev,      "device permission missing (DEV)", reason_o == 4'd9)
    `ALB_COVER(98, c_deny_overflow, "addr+len-1 wraps (OVERFLOW)", reason_o == 4'd5)
    `ALB_COVER(99, c_deny_priv,     "privilege claim above the domain's capability (PRIV)", reason_o == 4'd11)
    `ALB_COVER(100, c_deny_isolated, "isolated source port (ISOLATED)", reason_o == 4'd13)
    `ALB_COVER(101, c_deny_lockdown, "safe state denies a tenant (LOCKDOWN)", reason_o == 4'd12 && lockdown_i && !dft_active_i)
    `ALB_COVER(102, c_deny_badlen,  "zero length (BAD_LEN)", reason_o == 4'd4)
    `ALB_COVER(103, c_deny_queue,   "queue denial (QUEUE)", reason_o == 4'd10)
    `ALB_COVER(104, c_dup_id_exists, "two enrolled slots with the same id are possible without UNIQ (shows the UNIQ assumption removes real states)", !uniq_ok)
  end
endmodule
`default_nettype wire
