# IronMemory interfaces

All ports are synchronous to `clk`; `rst_n` is an asynchronous, active-low
reset that the SoC must deassert synchronously (reset synchroniser upstream).
Vectors are flattened per port: port *p* uses bits `[p*W +: W]`.

## Master ports (x `NUM_PORTS`)

Valid/ready on both channels. While `valid && !ready` the master holds every
request field stable.

| Signal | Dir | Width | Meaning |
|---|---|---|---|
| `m_req_valid` / `m_req_ready` | in / out | 1 | request handshake |
| `m_req_addr` | in | AW | byte address |
| `m_req_size` | in | 3 | log2(bytes): 0=1 B, 1=2 B, 2=4 B, 3=8 B (DW=64) |
| `m_req_we` | in | 1 | 1 = write |
| `m_req_wdata` | in | DW | byte-lane aligned (byte at address A sits in lane A % (DW/8)) |
| `m_req_wstrb` | in | DW/8 | write strobe, ANDed with the size mask |
| `m_rsp_valid` / `m_rsp_ready` | out / in | 1 | response handshake (back-pressure allowed) |
| `m_rsp_rdata` | out | DW | requested lanes only; other lanes, writes and errors return 0 |
| `m_rsp_err` | out | 3 | response code (below) |
| `m_rsp_ecc_corr` | out | 1 | a single-bit error was corrected for this access |

Responses return in request order per port. Up to `MAX_OUT` requests may be
outstanding per port; beyond that `m_req_ready` stays low.

### Response codes (`sf_iron_pkg`)

| Code | Name | Cause |
|---|---|---|
| 0 | `RSP_OK` | success |
| 1 | `RSP_DECODE` | address in no mapped window |
| 2 | `RSP_ALIGN` | misaligned, size larger than a word, or empty write strobe |
| 3 | `RSP_PERM` | ownership / permission violation, closing buffer, unmanaged memory |
| 4 | `RSP_ECC_UE` | uncorrectable ECC error (data zeroed; partial write aborted) |
| 5 | `RSP_EXT` | the external memory controller reported an error |
| 6 | `RSP_BOUNDS` | access straddles a buffer boundary |

### Domains

`PORT_DOMAIN_MAP` assigns each port a domain: 0 Keystone (ControlCore,
supervisor), 1 BridgeEngine, 2 PacketForge, 3 ComputeWorks, 4 VirtualFoundry.
Several ports may share a domain (e.g. the four lanes of the wide port).

## Buffer-manager command port

One command at a time (`bm_cmd_ready` is high only when idle). The response
is a single-cycle `bm_rsp_valid` pulse; the descriptor fields beside it show
the descriptor after the command took effect.

| Field | Meaning |
|---|---|
| `bm_cmd_op` | 0 ALLOC, 1 ALLOC_AT, 2 FREE, 3 TRANSFER, 4 QUERY, 5 CLEAR_ERR |
| `bm_cmd_requester` | domain of the issuing agent - **must be driven by the interconnect** |
| `bm_cmd_id` | descriptor id (FREE, TRANSFER, QUERY, CLEAR_ERR) |
| `bm_cmd_btype` | 0 DMA staging, 1 packet, 2 virtio descriptor, 3 tensor operand, 4 compute result, 5 control metadata |
| `bm_cmd_start` | byte address for ALLOC_AT (granule aligned) |
| `bm_cmd_len` | length in bytes |
| `bm_cmd_owner` | owner domain (ALLOC*, TRANSFER) |
| `bm_cmd_rd_mask` / `bm_cmd_wr_mask` | per-domain permissions (bit = domain) |
| `bm_rsp_status` | 0 OK, 1 NODESC, 2 NOSPACE, 3 BADLEN, 4 BADID, 5 NOTOWNER, 6 ALIGN, 7 OVERLAP, 8 BADARG |
| `bm_rsp_err_bits` | [0] read-permission, [1] write-permission, [2] bounds, [3] ECC CE, [4] ECC UE |

Latencies: QUERY and CLEAR_ERR answer two cycles after acceptance. ALLOC
spends one cycle per granule examined by the first-fit scan plus a few cycles
of fixed overhead (worst case is proportional to the granule count: 128
granules in the baseline). FREE and TRANSFER additionally wait for in-flight
accesses to the buffer to drain; ALLOC/ALLOC_AT wait for in-flight raw
Keystone accesses.

## External-memory controller channel

The replaceable controller attaches here (see `external_memory.md`).

| Signal | Dir | Meaning |
|---|---|---|
| `ext_cmd_valid` / `ext_cmd_ready` | out / in | command handshake; `ready` low = back-pressure |
| `ext_cmd_we`, `ext_cmd_addr` (word), `ext_cmd_wdata`, `ext_cmd_wstrb` | out | access |
| `ext_cmd_tag` | out | {port, seq}; unique while outstanding |
| `ext_rsp_valid` / `ext_rsp_ready` | in / out | response handshake (`ready` is always 1) |
| `ext_rsp_rdata`, `ext_rsp_err`, `ext_rsp_tag` | in | completion for `tag`; any order |

A response whose tag is not outstanding is dropped and flagged
(STATUS[4], counter global 18).

## Observability trace (verification)

`trc_valid/port/seq/we/word/be/wdata` per bank describe the access granted
this cycle. The testbenches replay this trace into the reference model.
Leave unconnected in silicon; synthesis removes it.

## Wide port (`sf_iron_wide_port.sv`)

`w_req_*` / `w_rsp_*` mirror the master port at `LANES*DW` bits (default
256), with `w_req_wstrb` of `LANES*DW/8` bits; `l_*` connect to `LANES`
master ports of `sf_iron_memory`. See `architecture.md`.
