# Memory technology portability

Every bank goes through one backend interface - a single-port array with
`en, we, addr, wdata, wunit[NUNITS], rdata` and a fixed read latency `RL` -
selected by `BACKEND`:

| `BACKEND` | File | Use | Read latency |
|---|---|---|---|
| 0 | `sf_iron_sram_generic.sv` | simulation reference, technology-neutral | any RL >= 1 |
| 1 | `sf_iron_sram_fpga.sv` | AMD/Xilinx and Intel block-RAM inference (single port, byte-write, no-change) | 1 (latch) or 2 (output register) |
| 2 | `sf_iron_sram_asic.sv` | qualified compiler SRAM macros, tiled `MACRO_BITS x MACRO_WORDS` | 1 (macro Q) or 2 (+ output flop) |

With ECC on, writes reaching the array are always full codewords (partial
writes become RMW), so `NUNITS=1`; with ECC off, `NUNITS = DW/8` byte lanes.

All three backends pass the identical system suite (`iron_memory`,
`iron_memory_fpga`, `iron_memory_asic`, plus RL=2 and contiguous-bank
variants) and the bank-level suite (9 configurations).

## Using real ASIC macros

1. Define the vendor cell: `+define+SF_IRON_VENDOR_MACRO=<cell_name>`. Its
   pins must match the stub (`CLK, CEN, GWEN, WEN[BITS], A, D, Q`, active-low
   enables, registered `Q`); add a thin shim module if the vendor uses other
   names or polarities.
2. Set `MACRO_WORDS` / `MACRO_BITS` to the macro's real dimensions. The
   wrapper tiles `ceil(CW/MACRO_BITS)` columns by `ceil(DEPTH/MACRO_WORDS)`
   rows and pads unused bits.
3. Timing comes from the vendor's Liberty: if the macro's clock-to-Q plus the
   SECDED decoder does not fit the cycle, use `RL=2`.
4. Re-run the regression with `TB_BACKEND=2` against the vendor's
   simulation model.

`sf_iron_sram_macro_stub` is a behavioural stand-in with no timing, area,
power, redundancy or test logic. It exists so the tiling and pin-level
behaviour can be verified before a library is available.

## Area policy

**IronMemory does not report physical SRAM area from an uncalibrated generic
array.** `tools/sram_area_report.py` reports:

* macro tiling, macro count, bit utilisation and ECC storage overhead (pure
  arithmetic on the configuration), always;
* macro area **only** from a supplied Liberty file's cell `area` attribute,
  and footprint **only** from a supplied LEF `SIZE`; otherwise it prints
  `NOT REPORTED`.

Baseline tiling example (no library supplied, so no area):

```
$ tools/sram_area_report.py --macro-name VENDOR_SP_512X72 --macro-words 512 --macro-bits 72
codeword_bits          72
column_tiles           1
row_tiles              2
macros_total           8
bit_utilisation        1.0
ecc_storage_overhead   0.125
total_macro_area       None
area_status            NOT REPORTED: no Liberty/LEF data supplied for the macro
```
(excerpt; add `--liberty <file>.lib` and `--lef <file>.lef` to get area.)

The fixtures under `tests/iron_memory/fixtures/` are synthetic files that
only exercise the parser; their numbers are arbitrary.

## Synthesizability check (generic, no library)

`syn/run_yosys.sh` converts the RTL with sv2v and runs Yosys generic
synthesis on `syn/sf_iron_memory_synth_top.sv` (baseline architecture, bank
depth reduced to 64 so the run is fast). Result of the run in this build:

* `check -assert`: **0 problems**; **0 latches** inferred.
* 196,119 generic cells in total. Generic cells are not area: there is no
  library, and with no memory library Yosys turns the four SRAM arrays into
  flip-flops (about 18.4 k of the flops are the 4 x 64 x 72 array bits).
* Largest logic blocks by generic cell count (per instance): buffer manager
  ~41.6 k (five ports x 16 descriptors of 32-bit range compares), top-level
  CSR / counter / slot logic ~39.7 k, reorder buffer ~10.9 k (x5), external
  adapter ~9.7 k (64-entry tag tables with 32-bit timestamps). These are the
  first places to look for area once a real library is used: the permission
  compares can be narrowed from AW to log2(window) bits when `SRAM_BASE` is
  aligned to the window size, and the 32-bit latency timestamps can be
  narrowed.

Yosys' SAT resource-sharing pass needs more than the 8 GB available here, so
the script runs `synth -noshare`; this affects optimisation only.

## FPGA

`sf_iron_sram_fpga.sv` follows the vendors' single-port byte-write inference
templates. Resource utilisation must come from the vendor tool's
post-synthesis report; none is claimed here (no vendor tool was available in
this build).
