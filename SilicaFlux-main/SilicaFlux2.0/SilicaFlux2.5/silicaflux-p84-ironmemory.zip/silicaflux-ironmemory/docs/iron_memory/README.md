# IronMemory documentation

| Document | Contents |
|---|---|
| [architecture.md](architecture.md) | block diagram, pipeline timing, address map, banking, ECC, buffer manager, ordering guarantees, reset |
| [interfaces.md](interfaces.md) | master port protocol, response codes, buffer-manager commands, external controller channel, trace, wide port |
| [csr_map.md](csr_map.md) | control/status registers and every performance counter |
| [verification.md](verification.md) | method, brief section 11 coverage, results, mutation check, limits |
| [perf_report.md](perf_report.md) | measured bandwidth, latency, conflicts, ECC overhead, DMA contention, accelerator starvation, buffer occupancy |
| [technology_portability.md](technology_portability.md) | generic / FPGA / ASIC backends, macro integration, area policy, synthesis check |
| [external_memory.md](external_memory.md) | adapter, simulation DRAM model, what is not implemented, licensed-controller integration |
| [repository_audit.md](repository_audit.md) | brief section 1: what existed (nothing) and what was built instead |
| [results/](results/) | raw regression report, perf counters, mutation log, Yosys statistics from this build |
