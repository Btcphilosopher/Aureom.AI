# External memory

## What is implemented

`rtl/albion/sf_iron_extmem_adapter.sv` - a **replaceable controller adapter**:

* maps the external window (`EXT_BASE`, `EXT_BYTES`) to word addresses;
* round-robins the five ports into one registered command stage;
* tags every command `{port, seq}` and keeps an outstanding-tag scoreboard
  (limit `EXT_MAX_OUT`), so the controller may complete in any order;
* propagates back-pressure (`ext_cmd_ready=0`) to the requesting port's issue
  slot - nothing is dropped;
* reports controller errors as `RSP_EXT`, flags responses for unknown tags as
  protocol errors (dropped, counted, sticky status, optional IRQ);
* restricts returned read data to the requested byte lanes;
* per-domain external read/write permission (CSR `EXT_PERM`, reset: Keystone
  only). The external window is not buffer-managed.

`rtl/albion/sim/sf_iron_simdram.sv` - a **simulation-only** controller model
with explicit, documented timing, used to verify the adapter and the
integration. It is not a DRAM controller design and not a PHY.

| Model parameter | Default | Meaning |
|---|---|---|
| `NBANKS`, `ROW_WORDS` | 8, 128 | bank / row geometry, open-page policy |
| `T_RCD` | 4 | activate to column command |
| `T_CL` / `T_CWL` | 6 / 4 | read / write column latency |
| `T_RP` | 4 | precharge |
| `T_WR` | 6 | write recovery before a precharge |
| `T_BURST` | 2 | data transfer |
| `T_REFI` / `T_RFC` | 780 / 52 | refresh interval / duration (back-pressure) |
| `QDEPTH` | 4 | command queue |

One command is in service at a time (no bank-level parallelism), so it
under-represents a real controller's throughput. It exists to exercise
latency variation, back-pressure, refresh and error paths.

Verified (`tb_extmem`, configured with tRCD=5, tRP=6, tCL=7, tCWL=5, tWR=9):
row-empty minus row-hit latency = tRCD exactly; row-miss minus row-empty =
tRP exactly; read minus write CAS difference exact; write recovery delays the
next precharge; 16 refreshes and 6,155 back-pressure cycles observed over 300
commands; injected and out-of-range errors reported; an unknown-tag response
flagged and dropped; 1,000 random multi-port commands completed exactly once
with correct data.

Integrated (`tb_iron_memory_ext`): mixed SRAM/DRAM random traffic from all
five masters with response back-pressure; ROBs absorbed 1,502 completions that
overtook older DRAM accesses; external counters match the testbench; the
reset-default permission blocks non-Keystone masters.

Per the brief, external memory was integrated only after the complete local
suite passed, and `tests/iron_memory/run_tests.py` enforces the same gate.

## What is NOT implemented

* **No DDR5 / LPDDR5 / HBM controller and no PHY.** A physical interface
  requires a licensed controller and PHY (training, DFI, calibration, I/O
  timing). None of that is written in ordinary RTL here, by design.
* No ECC on the external path inside IronMemory (the controller's own ECC
  reports through `ext_rsp_err`).
* No command timeout. A controller that never answers leaves the tag
  outstanding; the outstanding count is visible in CSR `0x03C`.
* External data width equals `DW`. A wider controller (e.g. a 256-bit AXI
  port) needs a width converter between the adapter and the controller.

## Integrating a licensed controller

1. Bridge the adapter channel to the controller's front end (commonly AXI4):
   `cmd` -> AR/AW+W (tag -> ID), R/B -> `rsp` (ID -> tag, RRESP/BRESP error ->
   `rsp_err`). AXI allows out-of-order completion across IDs; the adapter
   accepts that.
2. Set `EXT_BASE`, `EXT_BYTES`, `EXT_MAX_OUT` to the memory size and the
   controller's outstanding capacity.
3. Keep `tb_iron_memory_ext`'s scoreboard approach, but snoop the
   controller's execution order rather than command order if the controller
   reorders same-address traffic.
