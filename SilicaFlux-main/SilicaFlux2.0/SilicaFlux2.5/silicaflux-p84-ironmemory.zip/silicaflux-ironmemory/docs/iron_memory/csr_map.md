# CSR map and performance counters

32-bit registers on the Keystone CSR port (`csr_valid/csr_we/csr_addr/csr_wdata`;
`csr_rvalid/csr_rdata/csr_err` one cycle later). Unmapped or unaligned
addresses return `csr_err=1`.

## Control and status

| Addr | Name | Access | Fields |
|---|---|---|---|
| 0x000 | ID | RO | `0x5346_0084` ("SF", project 84) |
| 0x004 | CONFIG | RO | [7:0] banks, [15:8] bytes/word, [19:16] RL, [20] ECC_EN, [21] EXT_EN, [23:22] BACKEND, [27:24] ports, [28] INTERLEAVE |
| 0x008 | STATUS | RO | [0] init_done, [1] uncorrectable ECC seen, [2] permission/bounds violation seen, [3] external error seen, [4] external protocol error seen, [5] corrected ECC seen, [6] raw_block (allocation draining raw accesses), [15:8] descriptors in use, [31:16] granules in use |
| 0x00C | CTRL | RW | [0] Keystone raw access enable (reset 1), [1] scrub enable, [2] IRQ on UE, [3] IRQ on violation, [4] IRQ on external error, [5] freeze counters |
| 0x010 | SCRUB_INTERVAL | RW | cycles between scrub ticks (reset 1024; 0 -> 1) |
| 0x014 | ARB_HIPRI | RW | per-port high-priority mask |
| 0x018 | EXT_PERM | RW | [4:0] per-domain external read enable, [12:8] write enable (reset: Keystone only) |
| 0x01C | ECC_INJ_BITS | RW | [8:0] bit A, [15] enable A, [24:16] bit B, [31] enable B (codeword bit indices) |
| 0x020 | ECC_INJ_CTRL | W / RO | write [31]=1 with [3:0]=bank to arm; read returns per-bank pending mask |
| 0x024 | STATUS_CLR | W1C | same bit positions as STATUS [5:1] |
| 0x028 | CE_LOG | RO | [31] valid, [27:24] bank, [23:0] bank word (last corrected error) |
| 0x02C | CE_SYN | RO | syndrome {overall-parity, Hamming syndrome} |
| 0x030 | UE_LOG | RO | as CE_LOG for the last uncorrectable error |
| 0x034 | UE_SYN | RO | syndrome |
| 0x038 | CNT_CTRL | W | [0]=1 clears every counter |
| 0x03C | EXT_OUTSTANDING | RO | external commands in flight |

`irq = (UE & CTRL[2]) | (violation & CTRL[3]) | ((ext_err | ext_proto) & CTRL[4])`.

## Counters

All counters are 32-bit and **saturate** at `0xFFFF_FFFF` rather than wrap,
so a read is never silently wrong. They are derived only from real hardware
events (handshakes, grants, SRAM port activity, ECC decoder outputs).

### Per bank: `0x100 + bank*0x20 + idx*4`

| idx | Counter |
|---|---|
| 0 | master reads issued |
| 1 | master writes issued |
| 2 | busy cycles (SRAM port active, including write-backs and scrubs) |
| 3 | conflict cycles (>= 2 requesters) |
| 4 | read-modify-write operations |
| 5 | cycles not ready because of RMW / scrub / init (port-time cost of ECC) |
| 6 | corrected ECC errors |
| 7 | uncorrectable ECC errors |

### Per port: `0x200 + port*0x40 + idx*4`

| idx | Counter |
|---|---|
| 0 | requests accepted (including refused ones) |
| 1 | legal reads accepted |
| 2 | legal writes accepted |
| 3 | bytes read (legal) |
| 4 | bytes written (legal) |
| 5 | request stall cycles (valid & !ready) |
| 6 | bank-wait cycles (issue slot waiting for a grant) |
| 7 | conflict losses (another master won the bank) |
| 8 | starvation events (wait reached STARVE_LIMIT) |
| 9 | maximum wait (cycles) |
| 10 | latency sum (accept -> response presented) |
| 11 | latency samples (= responses) |
| 12 | maximum latency |
| 13 | error responses |
| 14 | response back-pressure cycles (rsp_valid & !rsp_ready) |
| 15 | external-memory accesses accepted |

### Global: `0x400 + idx*4`

| idx | Counter |
|---|---|
| 0 | cycles since reset / clear (after init) |
| 1 | descriptors in use (live value) |
| 2 | granules in use (live value) |
| 3 | peak granules in use |
| 4 | allocations granted |
| 5 | allocations refused: no descriptor |
| 6 | allocations refused: no contiguous space |
| 7 | buffers freed |
| 8 | external reads issued |
| 9 | external writes issued |
| 10 | external command back-pressure cycles |
| 11 | external latency sum (adapter accept -> completion) |
| 12 | external completions |
| 13 | external error completions |
| 14 | scrub reads |
| 15 | scrub repairs (write-backs) |
| 16 | permission / bounds violations |
| 17 | scrub-detected uncorrectable errors |
| 18 | external protocol errors (response for an unknown tag) |

`tb_iron_memory` phase 10 cross-checks the port and bank counters against
the testbench's own count of handshakes and bank issues after 12,500 random
requests.
