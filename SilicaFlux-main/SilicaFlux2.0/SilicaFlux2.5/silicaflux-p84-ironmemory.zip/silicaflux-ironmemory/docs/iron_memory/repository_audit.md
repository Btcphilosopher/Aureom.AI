# Repository audit (brief section 1)

The brief asks to inspect existing SilicaFlux memory components and reuse the
verified ones. The audit was performed on the workspace this build ran in.

**Finding: none of the listed components were present.** The workspace held no
SilicaFlux repository, no RTL, and no prior verification results. Nothing could
be reused, so every block IronMemory needs was written and verified here. No
claim is made that any of these modules is the "verified SilicaFlux" version of
a component that exists elsewhere in Aureom.AI's tree.

| Requested component | Found | What IronMemory uses instead | Verified by |
|---|---|---|---|
| SRAMCore | no | `sf_iron_sram_generic.sv` (behavioural single-port array) | tb_bank_adapter, all system tests |
| SRAMBank | no | `sf_iron_bank_adapter.sv` (bank + ECC + RMW + scrub + init + injection) | tb_bank_adapter (9 configurations) |
| SRAMController | no | per-bank arbiter + issue slots in `sf_iron_memory.sv`, `sf_iron_bank_arbiter.sv` | tb_iron_memory (7 configurations) |
| SRAMFabric | no | `sf_iron_memory.sv` (5 masters x 4 banks, reorder buffers) | tb_iron_memory, tb_iron_memory_ext |
| SRAMMacroBridge | no | `sf_iron_sram_asic.sv` (macro tiling, compiler-macro pin convention) + `sf_iron_sram_fpga.sv` | tb_bank_adapter, tb_iron_memory_asic / _fpga |
| ECCMemory / SECDED engine | no | `sf_iron_secded.sv` (parameterised extended Hamming) | tb_secded (exhaustive 1- and 2-bit, DW 64 and 128) |
| TensorScratch | no | buffer type `BT_TENSOR_OPERAND` / `BT_COMPUTE_RESULT` in the shared window + `sf_iron_wide_port.sv` for 256-bit access | tb_wide_port |
| VectorScratch | no | same shared window and wide port (no separate vector scratchpad was built) | tb_wide_port |
| External DRAM bridge | no | `sf_iron_extmem_adapter.sv` + simulation-only `sim/sf_iron_simdram.sv` | tb_extmem, tb_iron_memory_ext |

## When the real SilicaFlux tree is available

1. Diff `sf_iron_secded.sv` against the SilicaFlux SECDED engine. If the
   existing engine is verified, swap it in behind the same `enc`/`dec` ports
   and re-run `tb_secded` and the system suite; the code layout
   (`{p_all, p[R-1:0], data}`) is the only coupling.
2. Map SRAMCore / SRAMMacroBridge onto the `BACKEND` hook in
   `sf_iron_bank_adapter.sv` (the backend interface is a plain single-port
   `en/we/addr/wdata/wunit/rdata` array with fixed read latency RL).
3. Re-run `python3 tests/iron_memory/run_tests.py`; every system test is
   backend-agnostic.
