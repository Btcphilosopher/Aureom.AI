# IronMemory verification

## How to run

```
python3 tests/iron_memory/run_tests.py            # full regression + perf report
python3 tests/iron_memory/run_tests.py --synth    # + Yosys generic synthesis check (needs sv2v)
python3 tests/iron_memory/run_tests.py --icarus   # + Icarus Verilog cross-check of unit tests
python3 tests/iron_memory/mutation_test.py        # inject bugs, confirm the tests catch them
```

Primary simulator: Verilator 5.020 (`--timing --assert`). Every testbench is
self-checking and prints `TB_RESULT <name> PASS|FAIL checks=N`; the runner
also fails any run in which an RTL assertion fired.

## Method

* **Reference model driven by the DUT's own trace.** The system testbenches
  mirror the address map and buffer table, and replay the bank-issue trace
  into a reference memory, so expected read data is exact even with five
  masters racing for four banks. Every response is checked for error code,
  data (all 64 bits, zero in unrequested lanes) and `ecc_corr`.
* **Embedded assertions** run in every simulation: one grant per bank per
  cycle, no grant without request, no request to a busy bank, RMW write-back
  never collides with another SRAM access, ROB never overflows and never
  receives a completion for a non-outstanding entry, granule bitmap always
  equals the descriptor table (no overlapping buffers), in-flight counters
  never underflow, ext tags never reused while outstanding.
* **Mutation check.** 12 deliberate RTL bugs, each must be caught (see below).

## Brief section 11 coverage

| Requirement | Where | What is checked |
|---|---|---|
| Concurrent masters | `tb_iron_memory` phase 3, `tb_iron_memory_ext` | 5 masters x 2,500 random requests (sizes 1-8 B, sparse strobes, legal and illegal), exact scoreboard; mixed SRAM + DRAM |
| Independent bank operations | phase 1, `tb_perf` | 400 of 400 cycles with all four banks granted in the same cycle; 3.99 accesses/cycle measured |
| Same-bank conflicts | phase 2, `tb_perf hot_bank` | 5 masters on one bank: 1 grant/cycle, conflicts counted, round-robin max wait <= 5; priority + anti-starvation bound |
| Partial writes | phase 4, `tb_bank_adapter`, random traffic | every byte lane, half-words, words, sparse strobes; RMW count and RL+1 blocked cycles per RMW checked exactly |
| ECC fault injection | `tb_secded`, `tb_bank_adapter`, phase 5 | exhaustive 1-bit (corrected) and 2-bit (detected) on (72,64) and (137,128); CSR injection end-to-end: correction, CE/UE logs, sticky status, IRQ, buffer attribution, scrub repair, RMW over CE (repairs) and over UE (aborts) |
| Reset | phase 11, `tb_bank_adapter` | reset in the middle of saturating traffic: no stale responses, no acceptance during reset, init sweep re-runs, descriptor table and counters cleared, memory reads zero |
| Ownership violations | phase 6, `tb_buffer_manager` | unauthorised read gets PERM + zero data; unauthorised write does not modify memory; Keystone obeys buffer masks; violations attributed to buffers; FREE racing a live stream is monotonic (OK... then PERM...) |
| Buffer exhaustion | phase 7, `tb_buffer_manager`, `tb_perf` | descriptor exhaustion (NODESC), space exhaustion and fragmentation (NOSPACE), recovery after FREE |
| Address boundaries | `tb_memory_map`, phase 8 | bijection over every byte of the window; one-past-end, below-base, high-bit aliases, size/alignment matrix, buffer last byte vs straddle |
| Backpressure | phase 9, random back-pressure in phase 3 | ROB fills to exactly MAX_OUT, requests stall, nothing lost, order kept, stall and back-pressure cycles counted; ext command back-pressure from refresh |

Additional: counters cross-checked against TB-observed handshakes (phase 10);
external timing deltas exact (`tb_extmem`); 256-bit wide port integrity and
bandwidth (`tb_wide_port`); every SRAM backend and RL=2 and contiguous banking
through the whole system suite.

## Results (this build)

| Run | Scope | Result | Checks |
|---|---|---|---:|
| `secded` | SECDED exhaustive 1/2-bit, DW 64 and 128 | PASS | 46768 |
| `memory_map` | map bijection, boundaries, aliasing, alignment | PASS | 5214 |
| `bank_adapter` | 9 bank configurations (3 backends, RL 1/2, ECC on/off, power-up) | PASS | 26307 |
| `buffer_manager` | allocator, ownership, drain, raw drain | PASS | 75 |
| `iron_memory` | system suite, baseline | PASS | 18675 |
| `iron_memory_rl2` | system suite, RL=2 | PASS | 18689 |
| `iron_memory_noecc` | system suite, ECC off | PASS | 18604 |
| `iron_memory_fpga` | system suite, FPGA BRAM backend | PASS | 18675 |
| `iron_memory_asic` | system suite, ASIC macro tiling backend | PASS | 18675 |
| `iron_memory_contig` | system suite, contiguous banking | PASS | 18498 |
| `iron_memory_asic_rl2_contig` | system suite, ASIC + RL=2 + contiguous | PASS | 18504 |
| `wide_port` | 256-bit wide port | PASS | 583 |
| `extmem` | ext adapter + DRAM model (after local gate) | PASS | 1320 |
| `iron_memory_ext` | system + external memory (after local gate) | PASS | 3025 |
| `sram_area_tool` | area tool unit tests | PASS | 5 |
| `perf_ecc_on` | performance scenarios, ECC on | PASS | 40 |
| `perf_ecc_off` | performance scenarios, ECC off | PASS | 40 |
| `icarus_memory_map` | Icarus cross-check | PASS | 5214 |
| `icarus_secded` | Icarus cross-check | PASS | 46768 |
| `yosys_generic_synth` | Yosys generic synthesis (0 latches) | PASS | 1 |
| **total** | | **20/20 pass** | **265680** |

Run on 2026-11-15 16:07:46 UTC with `python3 tests/iron_memory/run_tests.py --synth --icarus`; raw report in `docs/iron_memory/results/regression_report.json`.

## Mutation check

| Mutation (deliberate RTL bug) | Caught by | Result |
|---|---|---|
| M1: flip one read-data bit | `tb_iron_memory` | CAUGHT |
| M2: ignore buffer permission masks | `tb_iron_memory` | CAUGHT |
| M3: freeze the round-robin pointer | `tb_iron_memory` | CAUGHT |
| M4: invert the RMW byte-merge mask | `tb_iron_memory` | CAUGHT |
| M5: ECC detects but does not correct | `tb_iron_memory` | CAUGHT |
| M6: FREE skips the in-flight drain | `tb_buffer_manager` | CAUGHT |
| M7: check only the first byte against buffer bounds | `tb_iron_memory` | CAUGHT |
| M8: ROB pops without response handshake | `tb_iron_memory` | CAUGHT |
| M9: RMW does not reserve the SRAM port for its write-back | `tb_bank_adapter` | CAUGHT |
| M10: address decode ignores the top 8 bits (aliasing) | `tb_memory_map` | CAUGHT |
| M11: ext adapter accepts responses for unknown tags | `tb_extmem` | CAUGHT |
| M12: double-bit errors not flagged | `tb_secded` | CAUGHT |

12/12 mutations caught.

## Limits of this verification

* Simulation with assertions, not formal proof. No property checker
  (SymbiYosys / JasperGold) was available; the assertions are written so they
  can be lifted into a formal harness.
* The generic, FPGA and ASIC backends are behavioural models here; real
  macros and BRAM must be re-verified with the vendor's simulation models
  (`TB_BACKEND=2` with `SF_IRON_VENDOR_MACRO`).
* Icarus Verilog 12 runs the SECDED and memory-map unit tests (passing); its
  runtime aborts with an internal assertion on the buffer-manager and system
  testbenches, so those run on Verilator only.
* The external path is verified against a simulation controller model only.
* Gate-level / timing simulation was not run (no technology library).
