# IronMemory architecture

SilicaFlux Albion Project 84. Primary RTL: `rtl/albion/sf_iron_memory.sv`.

## Block diagram

```mermaid
flowchart LR
  subgraph Masters
    K[Keystone<br/>ControlCore]
    B[BridgeEngine<br/>DMA]
    P[PacketForge]
    C[ComputeWorks<br/>vector / tensor]
    V[VirtualFoundry<br/>virtual I/O]
  end
  subgraph PerPort["per master port"]
    MAP[memory map<br/>region / bank / word / byte]
    CHK[ownership check<br/>buffer manager]
    SLOT[issue slot]
    ROB[reorder buffer<br/>MAX_OUT entries]
  end
  K & B & P & C & V --> MAP --> CHK --> SLOT
  SLOT --> ARB0[bank 0 arbiter] --> BA0[bank adapter 0<br/>ECC, RMW, scrub] --> S0[(SRAM bank 0<br/>1024 x 72)]
  SLOT --> ARB1[bank 1 arbiter] --> BA1[bank adapter 1] --> S1[(SRAM bank 1)]
  SLOT --> ARB2[bank 2 arbiter] --> BA2[bank adapter 2] --> S2[(SRAM bank 2)]
  SLOT --> ARB3[bank 3 arbiter] --> BA3[bank adapter 3] --> S3[(SRAM bank 3)]
  SLOT --> EXT[ext-mem adapter] --> CTRL[[DRAM controller<br/>sim model / licensed IP]]
  BA0 & BA1 & BA2 & BA3 & EXT --> ROB --> Masters
  BM[buffer manager<br/>descriptors + granule allocator] --- CHK
  CSR[CSR + perf counters] --- BM
```

## Baseline configuration

| Parameter | Default | Notes |
|---|---|---|
| `NUM_BANKS` | 4 | independent single-port banks, 1..16 |
| `DW` | 64 | word width; 128 / 256 supported (SECDED widens automatically) |
| `BANK_DEPTH` | 1024 | words per bank -> 32 KiB shared window |
| `RL` | 1 | SRAM read latency (1 or 2 for FPGA/ASIC backends; any >= 1 generic) |
| `INTERLEAVE` | 1 | word-interleaved banks; 0 = contiguous |
| `SRAM_BASE` | `0x1000_0000` | shared window base |
| `ECC_EN` | 1 | (72,64) SECDED |
| `BACKEND` | 0 | 0 generic, 1 FPGA BRAM, 2 ASIC macro tiling |
| `NUM_PORTS` | 5 | Keystone, BridgeEngine, PacketForge, ComputeWorks, VirtualFoundry |
| `PORT_DOMAIN_MAP` | `24'o00043210` | 3 bits per port -> ownership domain |
| `MAX_OUT` | 8 | outstanding requests per port (ROB depth) |
| `NUM_DESC` | 16 | buffer descriptors |
| `GRAN_BYTES` | 256 | allocation granule |
| `EXT_EN` | 1 | external window `0x8000_0000`, 1 MiB by default |
| `STARVE_LIMIT` | 16 | wait cycles before a requester becomes urgent |

## Request path and timing

1. **Accept (cycle 0).** A port accepts a request when its ROB has a free
   entry and its issue slot is free (or is issuing this cycle). The address
   map and the ownership check are combinational at this point. A refused
   request (decode, alignment, permission, bounds) takes a ROB entry that is
   completed immediately with the error code; it never reaches a bank.
2. **Issue (cycle 1).** The issue slot requests its target bank. Each bank's
   arbiter grants **at most one** requester per cycle and only when the bank
   adapter is ready. A single-port macro never sees two transactions in one
   cycle; this is asserted in every simulation.
3. **Bank (cycles 1 .. RL+1).** SRAM access, then ECC decode registered.
4. **Complete (cycle RL+2).** The bank response is written into the port's
   reserved ROB entry (or the ext adapter completes it later).
5. **Respond (cycle RL+3).** Responses leave each port strictly in request
   order. Unloaded latency is therefore **RL+3 cycles** (4 cycles at RL=1,
   measured: see `perf_report.md`).

Throughput: one request per port per cycle and one access per bank per cycle;
four independent streams sustain 4 accesses/cycle (measured 3.99).

## Address map (`sf_iron_memory_map.sv`)

Every byte address resolves to region, bank, bank-local word and byte offset.

* SRAM window `[SRAM_BASE, SRAM_BASE + NUM_BANKS*BANK_DEPTH*DW/8)`.
* External window `[EXT_BASE, EXT_BASE + EXT_BYTES)` when `EXT_EN=1`.
* Anything else is `RSP_DECODE`.
* **No aliasing:** the window compare uses every address bit. An address one
  past a window, or differing only in "unused" high bits, is rejected.
  `tb_memory_map` proves the in-window mapping is a bijection (every byte of
  the window reaches a distinct (bank, word, byte) cell, and every cell is
  reached).
* Accesses are 1, 2, 4 or 8 bytes, naturally aligned. Writes AND the size mask
  with a byte strobe; an empty effective strobe is `RSP_ALIGN`.
* Interleaved: `bank = word % NUM_BANKS`, `bank_word = word / NUM_BANKS`.
  Contiguous: `bank = word / BANK_DEPTH`.
* Window overlap between SRAM and EXT is an elaboration error.

## Banking (`sf_iron_bank_adapter.sv`, `sf_iron_bank_arbiter.sv`)

Each bank is a single-port synchronous SRAM with one access per cycle,
shared between (highest first):

1. the post-reset **init sweep** (writes encoded zero to every word),
2. **RMW / scrub write-back**,
3. a master operation granted by the arbiter,
4. a **scrub read** in an idle cycle, or forced after `SCRUB_MAX_DEFER`
   deferred cycles so scrubbing progresses under saturating traffic.

The arbiter is round-robin within priority classes: *urgent* (waited
`>= STARVE_LIMIT` cycles), then CSR-selected *high-priority* ports, then
normal. Measured worst case on a hot bank with five masters: wait <= 4 cycles.
With one high-priority master hammering the same bank, every other master's
wait stays within `STARVE_LIMIT + NUM_PORTS + 2` (checked in `tb_iron_memory`).

## ECC (`sf_iron_secded.sv`)

* Extended Hamming SECDED, systematic: `{p_all, p[R-1:0], data}`.
  (72,64), (137,128), (266,256).
* Storage overhead is physical: banks are instantiated `CW` bits wide.
* Reads return corrected data with `ecc_corr=1`; an uncorrectable word
  returns `RSP_ECC_UE` with zeroed data (poison is never forwarded as data).
* **Partial writes** (strobe not covering the word) are read-modify-write:
  read, decode/correct, merge, re-encode, write. The bank is unavailable for
  RL+1 cycles after the RMW issues (RL+2 cycles of port time in total). A
  correctable error in the old word is repaired by the write-back; an
  uncorrectable old word aborts the write and returns `RSP_ECC_UE` (the
  poison stays visible). With `ECC_EN=0` partial writes use native byte
  enables in one cycle.
* **Scrubbing** (CSR enable + interval) walks every word; correctable errors
  are written back, uncorrectable ones are logged.
* **Fault injection**: CSR-armed per bank; XORs up to two chosen codeword bits
  into the next master write to that bank.
* **Error reporting**: per-bank CE/UE counters, last CE/UE bank/word/syndrome
  logs, sticky status bits, IRQ, and per-buffer sticky error bits.
* **Init**: after reset each bank writes encoded zero to every word before
  accepting traffic. Without it, random power-up contents decode as errors -
  or worse, as "corrected" garbage (observed in `tb_bank_adapter`: 17 of 64
  random words mis-decoded as CE). Keep `INIT_ON_RESET=1` for silicon.

## Buffer manager and ownership (`sf_iron_buffer_manager.sv`)

The SRAM window is managed in granules (`GRAN_BYTES`). A buffer descriptor
holds: id, type (DMA staging, packet, virtio descriptor, tensor operand,
compute result, control metadata), start, length, owner domain, per-domain
read mask, per-domain write mask, in-use, closing, and sticky error status
(read-permission, write-permission, bounds, ECC CE, ECC UE).

| Command | Who | Effect |
|---|---|---|
| `ALLOC` | Keystone, or a domain allocating for itself | first-fit granule run (one granule examined per cycle) |
| `ALLOC_AT` | same | explicit granule-aligned placement (fixed rings, descriptor tables) |
| `FREE` | owner or Keystone | refuse new accesses, drain in-flight ones, release granules |
| `TRANSFER` | owner or Keystone | drain, then install new owner + masks atomically |
| `QUERY` | anyone | read a descriptor |
| `CLEAR_ERR` | owner or Keystone | clear sticky error bits |

Access rules (checked on every request, combinationally, per port):

* fully inside an open buffer: allowed iff the port's domain is in the read
  (or write) mask, else `RSP_PERM`;
* inside a buffer that is being freed / transferred: `RSP_PERM`;
* partially overlapping a buffer: `RSP_BOUNDS`;
* unmanaged memory: Keystone only, when raw access is enabled (CSR), else
  `RSP_PERM`.

Ordering guarantees (verified):

* `FREE` / `TRANSFER` complete only after every access accepted under the old
  rules has completed at its bank. A live stream racing a `FREE` produces a
  clean OK...OK, PERM...PERM sequence, never OK after PERM.
* `ALLOC` commits only after in-flight raw Keystone accesses complete, and
  Keystone accepts stall meanwhile, so no stale supervisor write lands in a
  freshly allocated buffer.
* A refused write never modifies memory; a refused read returns zero data.

`cmd_requester` must come from the interconnect (hardware-sourced), not from
software-writable state.

## Reorder buffers (`sf_iron_rob.sv`)

Each port can have `MAX_OUT` transactions in flight across banks and external
memory. Completions arrive in any order and land in reserved entries;
responses leave in order. Response back-pressure fills the ROB and then
stalls acceptance - nothing is dropped. With external memory enabled,
1,502 cases of a younger SRAM completion overtaking an older DRAM access were
absorbed in `tb_iron_memory_ext`.

## Wider effective interfaces

* **Through banking:** `sf_iron_wide_port.sv` splits a 4 x 64 = 256-bit
  request across four master ports mapped to the ComputeWorks domain. With
  interleaving and 32-byte alignment lane *i* always hits bank *i*: measured
  256 wide accesses in 256 cycles (32 B/cycle). Lanes are independent; a wide
  write is not atomic across lanes.
* **Through wider macros:** set `DW` to 128 or 256; ECC, maps and buffers
  scale with it (SECDED verified at 128).

## External memory

See `external_memory.md`. Integrated only after the local suite passed; the
regression runner enforces that order.

## Reset

Asynchronous active-low reset. All control state (slots, ROBs, descriptors,
counters, CSRs) clears; requests in flight are discarded and produce no
responses. Ports report not-ready until the init sweep completes. SRAM
contents are not reset (they are re-initialised by the sweep).
