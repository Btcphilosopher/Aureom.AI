# SilicaFlux Albion · Project 84 · IRONMEMORY

**Cloud memory and buffering subsystem**, Aureom.AI / SilicaFlux Albion.
Primary RTL: `rtl/albion/sf_iron_memory.sv`.

IronMemory is the shared on-chip memory of the Albion cloud processor: four
independent single-port SRAM banks behind one shared address window, ECC,
a buffer manager that enforces ownership, per-bank arbitration among the five
Albion masters, a replaceable external-memory adapter, CSRs and
counter-based performance measurement.

## Status

| | |
|---|---|
| Regression | 20 / 20 runs pass, 265,680 checks (Verilator 5.020 + Icarus 12 cross-check) |
| Configurations verified | generic / FPGA / ASIC-macro backends, RL 1 and 2, ECC on/off, interleaved and contiguous banking, external memory on |
| Mutation check | 12 / 12 injected RTL bugs caught |
| Synthesis check | Yosys generic flow via sv2v: 0 problems, 0 latches |
| External memory | integrated after the local suite passed (gate enforced by the runner); verified against a simulation-only controller model |

Definition of done: the subsystem allows verified concurrent memory accesses
(four grants in the same cycle, five masters with exact scoreboarding),
preserves data and ownership (refused writes never modify memory, refused
reads return nothing, FREE/TRANSFER drain in-flight accesses first), and
reports every supported conflict and error (response codes, per-buffer error
bits, CE/UE logs, sticky status, IRQ, counters).

## Layout

```
rtl/albion/
  sf_iron_memory.sv           top level: ports, slots, banks, ROBs, CSRs, counters
  sf_iron_memory_map.sv       byte address -> region / bank / word / byte, anti-aliasing
  sf_iron_buffer_manager.sv   descriptors, granule allocator, ownership checks, drain
  sf_iron_bank_adapter.sv     bank: ECC, read-modify-write, scrub, init, injection
  sf_iron_extmem_adapter.sv   replaceable external-memory controller adapter
  sf_iron_bank_arbiter.sv     per-bank round-robin with priority + anti-starvation
  sf_iron_rob.sv              per-port reorder buffer (in-order responses)
  sf_iron_secded.sv           parameterised SECDED encoder / decoder
  sf_iron_sram_generic.sv     generic SRAM backend
  sf_iron_sram_fpga.sv        FPGA block-RAM inference backend
  sf_iron_sram_asic.sv        compiler-macro tiling backend (+ behavioural stub)
  sf_iron_wide_port.sv        256-bit accelerator port built from 4 banked lanes
  sf_iron_pkg.sv              encodings and constants
  sf_iron_memory.f            file list
  sim/sf_iron_simdram.sv      SIMULATION-ONLY DRAM controller model
tests/iron_memory/            testbenches, regression runner, mutation check
docs/iron_memory/             architecture, interfaces, CSRs, verification,
                              performance report, portability, external memory
syn/                          Yosys generic synthesis check
tools/                        perf report generator, Liberty-based area report
```

## Quick start

```
# Verilator >= 5.0, Python 3
python3 tests/iron_memory/run_tests.py           # regression + docs/iron_memory/perf_report.md
python3 tests/iron_memory/run_tests.py --synth   # + Yosys check (needs sv2v, yosys)
python3 tests/iron_memory/mutation_test.py       # confirm the tests catch injected bugs
```

## Measured performance (simulation, cycles)

From IronMemory's own counters; see `docs/iron_memory/perf_report.md`.

* Unloaded latency: RL+3 cycles (4 at RL=1).
* Four independent streams: 3.99 accesses/cycle (32 bytes/cycle at 64-bit words).
* Uniform random traffic from five masters: 2.85 accesses/cycle.
* Hot bank (all five masters on one bank): 1.00 access/cycle, max wait 4 cycles.
* Byte-granular writes with ECC: 1.04 accesses/cycle vs 2.85 without ECC
  (read-modify-write costs the bank RL+2 port cycles).
* Wide port: 256 x 256-bit accesses in 256 cycles.

No clock frequency, silicon area or power is claimed: no technology library
was available. `tools/sram_area_report.py` reports macro area only from a
supplied Liberty/LEF.

## Things to know before integrating

* **Repository audit:** none of the SilicaFlux components named in the brief
  (SRAMCore, SRAMBank, ECCMemory, ...) existed in the build workspace, so all
  blocks were written and verified here. See `docs/iron_memory/repository_audit.md`
  for the swap-in path once the real tree is available.
* **No DRAM PHY.** DDR5/HBM needs a licensed controller + PHY behind the
  adapter channel; `sim/sf_iron_simdram.sv` is a test model only.
* **Freed buffers are not zeroed.** A buffer's previous contents remain
  readable by its next owner. Before reassigning memory across tenants, the
  supervisor must clear it (zero-on-free is the first item on the roadmap).
* **Wide writes are not atomic** across the four lanes.
* `bm_cmd_requester` must be driven by the interconnect, not by software.
* Keep `INIT_ON_RESET=1` on silicon: without the init sweep, random power-up
  contents can decode as "corrected" garbage.

## Roadmap

1. Zero-on-free (hardware clearing engine as an internal master).
2. Narrow the permission comparators to window-offset width (largest logic
   block by generic cell count).
3. Same-address hazard tracking so an RMW blocks only its own word, not the
   whole bank.
4. Formal proofs of the embedded assertions.
5. Licensed DDR5/HBM controller + PHY bridge behind the adapter.
