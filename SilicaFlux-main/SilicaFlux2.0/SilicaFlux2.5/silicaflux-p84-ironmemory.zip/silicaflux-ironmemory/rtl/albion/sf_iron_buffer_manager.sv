// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_buffer_manager.sv : buffer descriptors, allocation and ownership
//
// The whole SRAM window is managed in granules of GRAN_BYTES. A buffer is a
// contiguous granule run described by a descriptor:
//   id, type, start, length (bytes), owner domain, per-domain read mask,
//   per-domain write mask, in-use, closing, sticky error status.
//
// Commands (one at a time, on a single command port; cmd_requester must be
// the hardware-sourced domain of the issuing agent, never software-supplied):
//   ALLOC      first-fit granule search (one granule per cycle)
//   ALLOC_AT   place at an explicit granule-aligned start (fixed rings, etc.)
//   FREE       owner or Keystone; drains in-flight accesses, then releases
//   TRANSFER   owner or Keystone; drains, then installs new owner + masks
//   QUERY      read any descriptor
//   CLEAR_ERR  owner or Keystone; clears sticky error bits
//
// Access checking (combinational, one checker per master port):
//   * access fully inside an open buffer : allowed iff the port's domain bit
//                                          is set in the read / write mask
//   * access fully inside a closing buffer (FREE/TRANSFER draining): PERM
//   * access partially overlapping buffer(s)                         : BOUNDS
//   * access to unmanaged memory : allowed only for the Keystone domain when
//                                  raw access is enabled; otherwise PERM
// Violations set sticky error bits in every overlapped descriptor.
//
// Ordering guarantees:
//   * FREE / TRANSFER take effect only after every access already accepted
//     for that buffer has completed at its bank (per-descriptor counters),
//     and accesses arriving during the drain are refused.
//   * ALLOC / ALLOC_AT commit only after in-flight raw (unmanaged) Keystone
//     accesses have completed; new Keystone accepts stall meanwhile
//     (raw_block), so no stale raw write can land in a new buffer.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_buffer_manager #(
  parameter int             AW              = 32,
  parameter int             NUM_PORTS       = 5,
  parameter logic [23:0]    PORT_DOMAIN_MAP = 24'o00043210,
  parameter int             NUM_DESC        = 16,
  parameter int             GRAN_BYTES      = 256,
  parameter logic [AW-1:0]  SRAM_BASE       = AW'('h1000_0000),
  parameter longint         SRAM_BYTES      = 64'd32768,
  parameter int             NUM_DEC         = 4,      // completion sources (banks)
  parameter int             INFL_W          = 6,
  // derived (do not override)
  parameter int ND    = sf_iron_pkg::NUM_DOMAINS,
  parameter int IDW   = sf_iron_pkg::clog2_min1(NUM_DESC),
  parameter int LEN_W = $clog2(SRAM_BYTES + 1),
  parameter int NG    = int'(SRAM_BYTES / longint'(GRAN_BYTES)),
  parameter int GW    = sf_iron_pkg::clog2_min1(NG),
  parameter int GCW   = $clog2(NG + 1)
) (
  input  logic                     clk,
  input  logic                     rst_n,
  // ---- command port ----
  input  logic                     cmd_valid,
  output logic                     cmd_ready,
  input  logic [2:0]               cmd_op,
  input  logic [2:0]               cmd_requester,
  input  logic [IDW-1:0]           cmd_id,
  input  logic [2:0]               cmd_btype,
  input  logic [AW-1:0]            cmd_start,
  input  logic [LEN_W-1:0]         cmd_len,
  input  logic [2:0]               cmd_owner,
  input  logic [ND-1:0]            cmd_rd_mask,
  input  logic [ND-1:0]            cmd_wr_mask,
  output logic                     rsp_valid,
  output logic [3:0]               rsp_status,
  output logic [IDW-1:0]           rsp_id,
  output logic                     rsp_in_use,
  output logic [2:0]               rsp_btype,
  output logic [AW-1:0]            rsp_start,
  output logic [LEN_W-1:0]         rsp_len,
  output logic [2:0]               rsp_owner,
  output logic [ND-1:0]            rsp_rd_mask,
  output logic [ND-1:0]            rsp_wr_mask,
  output logic [7:0]               rsp_err_bits,
  // ---- access checking (combinational, per port) ----
  input  logic                     raw_en,          // Keystone raw access enable
  input  logic [NUM_PORTS*AW-1:0]  chk_lo,
  input  logic [NUM_PORTS*AW-1:0]  chk_hi,
  input  logic [NUM_PORTS-1:0]     chk_we,
  output logic [NUM_PORTS-1:0]     chk_hit,         // inside an open buffer
  output logic [NUM_PORTS-1:0]     chk_raw,         // unmanaged + allowed
  output logic [NUM_PORTS-1:0]     chk_allow,
  output logic [NUM_PORTS*3-1:0]   chk_err,
  output logic [NUM_PORTS*IDW-1:0] chk_id,
  input  logic [NUM_PORTS-1:0]     chk_fire,        // SRAM access accepted this cycle
  output logic                     raw_block,       // stall Keystone accepts
  // ---- completion accounting (from banks) ----
  input  logic [NUM_DEC-1:0]       dec_valid,       // managed access completed
  input  logic [NUM_DEC*IDW-1:0]   dec_id,
  input  logic [NUM_DEC-1:0]       dec_ce,
  input  logic [NUM_DEC-1:0]       dec_ue,
  input  logic [NUM_DEC-1:0]       dec_raw,         // raw access completed
  // ---- statistics ----
  output logic [IDW:0]             desc_in_use,
  output logic [GCW-1:0]           gran_in_use,
  output logic                     ev_alloc_ok,
  output logic                     ev_alloc_nodesc,
  output logic                     ev_alloc_nospace,
  output logic                     ev_free,
  output logic [NUM_PORTS-1:0]     ev_viol          // accepted access refused
);
  import sf_iron_pkg::*;

  localparam int LOG_G  = $clog2(GRAN_BYTES);
  localparam int RAWC_W = 8;

  initial begin
    if (is_pow2(GRAN_BYTES) == 0 || GRAN_BYTES < 8) $fatal(1, "buffer_manager: GRAN_BYTES must be a power of two >= 8");
    if ((SRAM_BYTES % longint'(GRAN_BYTES)) != 64'd0) $fatal(1, "buffer_manager: SRAM window must be a whole number of granules");
    if ((longint'(SRAM_BASE) % longint'(GRAN_BYTES)) != 64'd0) $fatal(1, "buffer_manager: SRAM_BASE must be granule aligned");
    if (NUM_PORTS > 8) $fatal(1, "buffer_manager: at most 8 ports");
  end

  // ---------------------------------------------------------------------------
  // Descriptor table
  // ---------------------------------------------------------------------------
  logic             d_use   [NUM_DESC];
  logic             d_close [NUM_DESC];
  logic [2:0]       d_type  [NUM_DESC];
  logic [AW-1:0]    d_start [NUM_DESC];
  logic [AW-1:0]    d_last  [NUM_DESC];
  logic [LEN_W-1:0] d_len   [NUM_DESC];
  logic [GW-1:0]    d_gs    [NUM_DESC];
  logic [GCW-1:0]   d_gc    [NUM_DESC];
  logic [2:0]       d_owner [NUM_DESC];
  logic [ND-1:0]    d_rd    [NUM_DESC];
  logic [ND-1:0]    d_wr    [NUM_DESC];
  logic [7:0]       d_err   [NUM_DESC];
  logic [INFL_W-1:0] d_infl [NUM_DESC];
  logic [NG-1:0]    gran_used;
  logic [RAWC_W-1:0] raw_infl;

  // ---------------------------------------------------------------------------
  // Per-port access check
  // ---------------------------------------------------------------------------
  logic [NUM_DESC-1:0] viol_rd  [NUM_PORTS];
  logic [NUM_DESC-1:0] viol_wr  [NUM_PORTS];
  logic [NUM_DESC-1:0] viol_bnd [NUM_PORTS];

  genvar gp;
  generate
    for (gp = 0; gp < NUM_PORTS; gp++) begin : g_chk
      localparam logic [2:0] DOM = PORT_DOMAIN_MAP[3*gp +: 3];
      logic [AW-1:0] lo, hi;
      logic [NUM_DESC-1:0] contain, overlap;
      logic hit, allow, raw;
      logic [IDW-1:0] id;
      logic [2:0] err;
      assign lo = chk_lo[gp*AW +: AW];
      assign hi = chk_hi[gp*AW +: AW];
      always_comb begin
        for (int i = 0; i < NUM_DESC; i++) begin
          contain[i] = d_use[i] && (lo >= d_start[i]) && (hi <= d_last[i]);
          overlap[i] = d_use[i] && (lo <= d_last[i]) && (hi >= d_start[i]);
        end
        hit = 1'b0; id = '0;
        for (int i = 0; i < NUM_DESC; i++)
          if (contain[i] && !d_close[i] && !hit) begin hit = 1'b1; id = IDW'(i); end
        allow = 1'b0; raw = 1'b0; err = RSP_PERM;
        viol_rd[gp] = '0; viol_wr[gp] = '0; viol_bnd[gp] = '0;
        if (hit) begin
          allow = chk_we[gp] ? d_wr[id][DOM] : d_rd[id][DOM];
          err   = allow ? RSP_OK : RSP_PERM;
          if (!allow) begin
            if (chk_we[gp]) viol_wr[gp][id] = 1'b1;
            else            viol_rd[gp][id] = 1'b1;
          end
        end else if (|overlap) begin
          if (|contain) begin              // fully inside a closing buffer
            err = RSP_PERM;
            if (chk_we[gp]) viol_wr[gp] = overlap;
            else            viol_rd[gp] = overlap;
          end else begin                   // straddles a buffer boundary
            err = RSP_BOUNDS;
            viol_bnd[gp] = overlap;
          end
        end else begin                     // unmanaged memory
          allow = (DOM == DOM_KEYSTONE) && raw_en;
          raw   = allow;
          err   = allow ? RSP_OK : RSP_PERM;
        end
      end
      assign chk_hit[gp]             = hit && allow;
      assign chk_raw[gp]             = raw;
      assign chk_allow[gp]           = allow;
      assign chk_err[gp*3 +: 3]      = err;
      assign chk_id[gp*IDW +: IDW]   = id;
      assign ev_viol[gp]             = chk_fire[gp] && !allow;
    end
  endgenerate

  // aggregate per-descriptor access-side events
  logic [NUM_DESC-1:0] set_rd, set_wr, set_bnd, set_ce, set_ue;
  int                  inc_n [NUM_DESC];
  int                  dec_n [NUM_DESC];
  int                  raw_inc, raw_dec;
  always_comb begin
    set_rd = '0; set_wr = '0; set_bnd = '0; set_ce = '0; set_ue = '0;
    raw_inc = 0; raw_dec = 0;
    for (int i = 0; i < NUM_DESC; i++) begin inc_n[i] = 0; dec_n[i] = 0; end
    for (int p = 0; p < NUM_PORTS; p++) begin
      if (chk_fire[p]) begin
        set_rd  = set_rd  | viol_rd[p];
        set_wr  = set_wr  | viol_wr[p];
        set_bnd = set_bnd | viol_bnd[p];
        if (chk_hit[p]) inc_n[chk_id[p*IDW +: IDW]] = inc_n[chk_id[p*IDW +: IDW]] + 1;
        if (chk_raw[p]) raw_inc = raw_inc + 1;
      end
    end
    for (int b = 0; b < NUM_DEC; b++) begin
      if (dec_valid[b]) begin
        dec_n[dec_id[b*IDW +: IDW]] = dec_n[dec_id[b*IDW +: IDW]] + 1;
        if (dec_ce[b]) set_ce[dec_id[b*IDW +: IDW]] = 1'b1;
        if (dec_ue[b]) set_ue[dec_id[b*IDW +: IDW]] = 1'b1;
      end
      if (dec_raw[b]) raw_dec = raw_dec + 1;
    end
  end

  // ---------------------------------------------------------------------------
  // Command FSM
  // ---------------------------------------------------------------------------
  typedef enum logic [2:0] { S_IDLE, S_EXEC, S_SCAN, S_RAWDRAIN, S_DRAIN } state_t;
  state_t st;

  logic [2:0]       c_op, c_req, c_type, c_owner;
  logic [IDW-1:0]   c_id;
  logic [AW-1:0]    c_start;
  logic [LEN_W-1:0] c_len;
  logic [ND-1:0]    c_rd, c_wr;
  logic [GCW-1:0]   need;
  logic [GW:0]      scan_idx;
  logic [GCW-1:0]   run;
  logic [GW-1:0]    run_start, commit_gs;

  // combinational helpers on the latched command
  logic             free_found;
  logic [IDW-1:0]   free_id;
  logic [GCW-1:0]   need_c;
  logic [AW-1:0]    at_off;
  logic             at_ok, at_overlap;
  logic [GW-1:0]    at_gs;
  logic             id_ok, may_manage;

  always_comb begin
    free_found = 1'b0; free_id = '0;
    for (int i = 0; i < NUM_DESC; i++)
      if (!d_use[i] && !free_found) begin free_found = 1'b1; free_id = IDW'(i); end
    need_c = GCW'((longint'(c_len) + longint'(GRAN_BYTES) - 64'd1) >> LOG_G);
    at_off = c_start - SRAM_BASE;
    at_gs  = GW'(at_off >> LOG_G);
    at_ok  = (c_start >= SRAM_BASE) &&
             (longint'(at_off) + longint'(c_len) <= SRAM_BYTES) &&
             (at_off[LOG_G-1:0] == '0);
    at_overlap = 1'b0;
    for (int g = 0; g < NG; g++)
      if (gran_used[g] && (g >= int'(at_gs)) && (g < int'(at_gs) + int'(need_c))) at_overlap = 1'b1;
    id_ok      = (int'(c_id) < NUM_DESC) && d_use[c_id];
    may_manage = (c_req == DOM_KEYSTONE) || (c_req == d_owner[c_id]);
  end

  assign cmd_ready = (st == S_IDLE);
  assign raw_block = (st == S_RAWDRAIN);

  task automatic respond(input logic [3:0] status, input logic [IDW-1:0] id);
    rsp_valid  <= 1'b1;
    rsp_status <= status;
    rsp_id     <= id;
  endtask

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE;
      c_op <= '0; c_req <= '0; c_type <= '0; c_owner <= '0; c_id <= '0; c_start <= '0; c_len <= '0;
      c_rd <= '0; c_wr <= '0; need <= '0; scan_idx <= '0; run <= '0; run_start <= '0; commit_gs <= '0;
      rsp_valid <= 1'b0; rsp_status <= '0; rsp_id <= '0;
      gran_used <= '0; gran_in_use <= '0; raw_infl <= '0;
      ev_alloc_ok <= 1'b0; ev_alloc_nodesc <= 1'b0; ev_alloc_nospace <= 1'b0; ev_free <= 1'b0;
      for (int i = 0; i < NUM_DESC; i++) begin
        d_use[i] <= 1'b0; d_close[i] <= 1'b0; d_type[i] <= '0; d_start[i] <= '0; d_last[i] <= '0;
        d_len[i] <= '0; d_gs[i] <= '0; d_gc[i] <= '0; d_owner[i] <= '0; d_rd[i] <= '0; d_wr[i] <= '0;
        d_err[i] <= '0; d_infl[i] <= '0;
      end
    end else begin
      rsp_valid <= 1'b0;
      ev_alloc_ok <= 1'b0; ev_alloc_nodesc <= 1'b0; ev_alloc_nospace <= 1'b0; ev_free <= 1'b0;

      // access-side bookkeeping (every cycle)
      for (int i = 0; i < NUM_DESC; i++) begin
        d_infl[i] <= d_infl[i] + INFL_W'(inc_n[i]) - INFL_W'(dec_n[i]);
        d_err[i]  <= d_err[i] | {3'b000, set_ue[i], set_ce[i], set_bnd[i], set_wr[i], set_rd[i]};
      end
      raw_infl <= raw_infl + RAWC_W'(raw_inc) - RAWC_W'(raw_dec);

      case (st)
        S_IDLE: if (cmd_valid) begin
          c_op <= cmd_op; c_req <= cmd_requester; c_id <= cmd_id; c_type <= cmd_btype;
          c_start <= cmd_start; c_len <= cmd_len; c_owner <= cmd_owner;
          c_rd <= cmd_rd_mask; c_wr <= cmd_wr_mask;
          st <= S_EXEC;
        end

        S_EXEC: begin
          st <= S_IDLE;
          case (c_op)
            BM_ALLOC, BM_ALLOC_AT: begin
              if (c_len == '0 || longint'(c_len) > SRAM_BYTES)                   respond(BMS_BADLEN, '0);
              else if (int'(c_type) > BT_MAX || int'(c_owner) >= ND)             respond(BMS_BADARG, '0);
              else if (c_req != DOM_KEYSTONE && c_req != c_owner)                respond(BMS_NOTOWNER, '0);
              else if (!free_found) begin
                respond(BMS_NODESC, '0);  ev_alloc_nodesc <= 1'b1;
              end else if (c_op == BM_ALLOC_AT) begin
                if (!at_ok)            respond(BMS_ALIGN, '0);
                else if (at_overlap)   respond(BMS_OVERLAP, '0);
                else begin
                  need <= need_c; commit_gs <= at_gs; c_id <= free_id; st <= S_RAWDRAIN;
                end
              end else begin
                need <= need_c; c_id <= free_id;
                scan_idx <= '0; run <= '0; run_start <= '0;
                st <= S_SCAN;
              end
            end
            BM_FREE, BM_TRANSFER: begin
              if (!id_ok)                                         respond(BMS_BADID, c_id);
              else if (!may_manage)                               respond(BMS_NOTOWNER, c_id);
              else if (c_op == BM_TRANSFER && int'(c_owner) >= ND) respond(BMS_BADARG, c_id);
              else begin
                d_close[c_id] <= 1'b1;
                st <= S_DRAIN;
              end
            end
            BM_QUERY: begin
              if (int'(c_id) >= NUM_DESC) respond(BMS_BADID, c_id);
              else                        respond(BMS_OK, c_id);
            end
            BM_CLEAR_ERR: begin
              if (!id_ok)            respond(BMS_BADID, c_id);
              else if (!may_manage)  respond(BMS_NOTOWNER, c_id);
              else begin
                d_err[c_id] <= {3'b000, set_ue[c_id], set_ce[c_id], set_bnd[c_id], set_wr[c_id], set_rd[c_id]};
                respond(BMS_OK, c_id);
              end
            end
            default: respond(BMS_BADARG, c_id);
          endcase
        end

        S_SCAN: begin
          if (int'(scan_idx) >= NG) begin
            respond(BMS_NOSPACE, '0); ev_alloc_nospace <= 1'b1;
            st <= S_IDLE;
          end else begin
            scan_idx <= scan_idx + 1'b1;
            if (gran_used[scan_idx[GW-1:0]]) begin
              run <= '0;
              run_start <= GW'(scan_idx + 1'b1);
            end else if (run + 1'b1 == need) begin
              commit_gs <= run_start;
              st <= S_RAWDRAIN;
            end else begin
              run <= run + 1'b1;
            end
          end
        end

        S_RAWDRAIN: begin
          // raw_infl already includes accepts from the cycle we entered
          if (raw_infl == '0 && raw_inc == 0) begin
            for (int g = 0; g < NG; g++)
              if ((g >= int'(commit_gs)) && (g < int'(commit_gs) + int'(need))) gran_used[g] <= 1'b1;
            gran_in_use       <= gran_in_use + need;
            d_use[c_id]       <= 1'b1;
            d_close[c_id]     <= 1'b0;
            d_type[c_id]      <= c_type;
            d_start[c_id]     <= SRAM_BASE + (AW'(commit_gs) << LOG_G);
            d_last[c_id]      <= SRAM_BASE + (AW'(commit_gs) << LOG_G) + AW'(c_len) - 1'b1;
            d_len[c_id]       <= c_len;
            d_gs[c_id]        <= commit_gs;
            d_gc[c_id]        <= need;
            d_owner[c_id]     <= c_owner;
            d_rd[c_id]        <= c_rd;
            d_wr[c_id]        <= c_wr;
            d_err[c_id]       <= '0;
            respond(BMS_OK, c_id);
            ev_alloc_ok       <= 1'b1;
            st                <= S_IDLE;
          end
        end

        S_DRAIN: begin
          if (d_infl[c_id] == '0 && inc_n[c_id] == 0) begin
            d_close[c_id] <= 1'b0;
            if (c_op == BM_FREE) begin
              for (int g = 0; g < NG; g++)
                if ((g >= int'(d_gs[c_id])) && (g < int'(d_gs[c_id]) + int'(d_gc[c_id]))) gran_used[g] <= 1'b0;
              gran_in_use   <= gran_in_use - d_gc[c_id];
              d_use[c_id]   <= 1'b0;
              ev_free       <= 1'b1;
            end else begin
              d_owner[c_id] <= c_owner;
              d_rd[c_id]    <= c_rd;
              d_wr[c_id]    <= c_wr;
            end
            respond(BMS_OK, c_id);
            st <= S_IDLE;
          end
        end

        default: st <= S_IDLE;
      endcase
    end
  end

  // response descriptor view (reads the table after the command took effect)
  assign rsp_in_use   = d_use[rsp_id];
  assign rsp_btype    = d_type[rsp_id];
  assign rsp_start    = d_start[rsp_id];
  assign rsp_len      = d_len[rsp_id];
  assign rsp_owner    = d_owner[rsp_id];
  assign rsp_rd_mask  = d_rd[rsp_id];
  assign rsp_wr_mask  = d_wr[rsp_id];
  assign rsp_err_bits = d_err[rsp_id];

  always_comb begin
    int n; n = 0;
    for (int i = 0; i < NUM_DESC; i++) n = n + int'(d_use[i]);
    desc_in_use = (IDW+1)'(n);
  end

`ifndef SYNTHESIS
  // invariants: granule bitmap matches the descriptor table, no overlaps,
  // in-flight counters never underflow
  logic [NG-1:0] model_used;
  int            model_cnt;
  always_comb begin
    model_used = '0; model_cnt = 0;
    for (int i = 0; i < NUM_DESC; i++) if (d_use[i]) begin
      for (int g = 0; g < NG; g++)
        if ((g >= int'(d_gs[i])) && (g < int'(d_gs[i]) + int'(d_gc[i]))) model_used[g] = 1'b1;
      model_cnt = model_cnt + int'(d_gc[i]);
    end
  end
  always_ff @(posedge clk) if (rst_n) begin
    assert (model_used == gran_used) else $error("buffer_manager: granule bitmap out of sync with descriptors");
    assert (model_cnt == int'(gran_in_use)) else $error("buffer_manager: overlapping buffers or bad granule count");
    for (int i = 0; i < NUM_DESC; i++)
      assert (int'(d_infl[i]) + inc_n[i] >= dec_n[i]) else $error("buffer_manager: in-flight underflow on descriptor %0d", i);
    assert (int'(raw_infl) + raw_inc >= raw_dec) else $error("buffer_manager: raw in-flight underflow");
  end
`endif
endmodule
