// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_rob.sv : per-master in-order response (reorder) buffer
//
// A master may have up to DEPTH transactions in flight across different
// banks and the external memory. Each accepted request reserves an entry
// (its sequence number travels with the transaction as part of the tag).
// Completions arrive in any order, from NSRC sources, and are written into
// their reserved entry; responses leave strictly in acceptance order.
//
// Because the entry is reserved at acceptance, a completion can never be
// dropped; response back-pressure (rsp_ready=0) simply fills the buffer, and
// a full buffer stops request acceptance (no loss, no reordering).
//
// Latency sample: cycles from acceptance until the response is first
// presented (rsp_valid rising for that entry); excludes back-pressure time.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_rob #(
  parameter int DEPTH = 4,
  parameter int DW    = 64,
  parameter int NSRC  = 4,
  parameter int TS_W  = 32,
  parameter int SW    = sf_iron_pkg::clog2_min1(DEPTH)
) (
  input  logic              clk,
  input  logic              rst_n,
  input  logic [TS_W-1:0]   now,
  // allocation at request acceptance
  input  logic              alloc,
  output logic [SW-1:0]     alloc_seq,
  output logic              full,
  input  logic              alloc_done,    // completes immediately (decode/permission error)
  input  logic [2:0]        alloc_err,
  // completions
  input  logic [NSRC-1:0]      cpl_valid,
  input  logic [NSRC*SW-1:0]   cpl_seq,
  input  logic [NSRC*DW-1:0]   cpl_data,
  input  logic [NSRC*3-1:0]    cpl_err,
  input  logic [NSRC-1:0]      cpl_ce,
  // in-order responses
  output logic              rsp_valid,
  input  logic              rsp_ready,
  output logic [DW-1:0]     rsp_data,
  output logic [2:0]        rsp_err,
  output logic              rsp_ce,
  // latency sampling
  output logic              lat_valid,
  output logic [TS_W-1:0]   lat_cycles,
  output logic [SW:0]       count
);
  initial if (sf_iron_pkg::is_pow2(DEPTH) == 0) $fatal(1, "sf_iron_rob: DEPTH must be a power of two");

  logic [DEPTH-1:0] busy, done;
  logic [DW-1:0]    e_data [DEPTH];
  logic [2:0]       e_err  [DEPTH];
  logic             e_ce   [DEPTH];
  logic [TS_W-1:0]  e_ts   [DEPTH];
  logic [SW-1:0]    head, tail;
  logic             head_seen;
  logic             pop;

  assign full      = (count == (SW+1)'(DEPTH));
  assign alloc_seq = tail;
  assign rsp_valid = busy[head] && done[head];
  assign rsp_data  = e_data[head];
  assign rsp_err   = e_err[head];
  assign rsp_ce    = e_ce[head];
  assign pop       = rsp_valid && rsp_ready;
  assign lat_valid = rsp_valid && !head_seen;
  assign lat_cycles = now - e_ts[head];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= '0; done <= '0; head <= '0; tail <= '0; count <= '0; head_seen <= 1'b0;
      for (int i = 0; i < DEPTH; i++) begin
        e_data[i] <= '0; e_err[i] <= '0; e_ce[i] <= 1'b0; e_ts[i] <= '0;
      end
    end else begin
      // completions into reserved entries
      for (int s = 0; s < NSRC; s++) begin
        if (cpl_valid[s]) begin
          logic [SW-1:0] q;
          q = cpl_seq[s*SW +: SW];
          done[q]   <= 1'b1;
          e_data[q] <= cpl_data[s*DW +: DW];
          e_err[q]  <= cpl_err[s*3 +: 3];
          e_ce[q]   <= cpl_ce[s];
        end
      end
      // allocation
      if (alloc) begin
        busy[tail]   <= 1'b1;
        done[tail]   <= alloc_done;
        e_err[tail]  <= alloc_done ? alloc_err : 3'd0;
        e_data[tail] <= '0;
        e_ce[tail]   <= 1'b0;
        e_ts[tail]   <= now;
        tail         <= tail + 1'b1;
      end
      // in-order retirement
      if (pop) begin
        busy[head] <= 1'b0;
        done[head] <= 1'b0;
        head       <= head + 1'b1;
        head_seen  <= 1'b0;
      end else if (rsp_valid) begin
        head_seen  <= 1'b1;
      end
      count <= count + (SW+1)'(alloc) - (SW+1)'(pop);
    end
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk) if (rst_n) begin
    assert (!(alloc && full)) else $error("sf_iron_rob: allocation into a full buffer");
    for (int s = 0; s < NSRC; s++) if (cpl_valid[s]) begin
      assert (busy[cpl_seq[s*SW +: SW]] && !done[cpl_seq[s*SW +: SW]])
        else $error("sf_iron_rob: completion for an entry that is not outstanding (seq %0d)", cpl_seq[s*SW +: SW]);
      for (int t = s + 1; t < NSRC; t++)
        assert (!(cpl_valid[t] && cpl_seq[t*SW +: SW] == cpl_seq[s*SW +: SW]))
          else $error("sf_iron_rob: two completions for one entry in a cycle");
    end
  end
`endif
endmodule
