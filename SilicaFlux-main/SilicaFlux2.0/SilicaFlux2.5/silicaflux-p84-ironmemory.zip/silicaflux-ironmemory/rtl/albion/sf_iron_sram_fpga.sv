// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_sram_fpga.sv : FPGA block-RAM inference template (single port)
//
// Coded in the single-port, byte-write-enable, "no-change" style recognised
// by AMD/Xilinx (Vivado) and Intel (Quartus) RAM inference. RL=1 uses the
// BRAM output latch, RL=2 additionally enables the BRAM output register
// (DOA_REG / outdata_reg), which is the recommended setting for Fmax.
// Unit width W/NUNITS of 8 or 9 maps to native byte-write lanes.
// Resource counts must come from the vendor's post-synthesis report.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_sram_fpga #(
  parameter int W      = 72,
  parameter int DEPTH  = 1024,
  parameter int RL     = 1,
  parameter int NUNITS = 1,
  parameter int AWL    = sf_iron_pkg::clog2_min1(DEPTH)
) (
  input  logic              clk,
  input  logic              en,
  input  logic              we,
  input  logic [AWL-1:0]    addr,
  input  logic [W-1:0]      wdata,
  input  logic [NUNITS-1:0] wunit,
  output logic [W-1:0]      rdata
);
  localparam int UW = W / NUNITS;

  (* ram_style = "block" *) logic [W-1:0] ram [DEPTH];
  logic [W-1:0] dout;

  initial begin
    if (RL != 1 && RL != 2) $fatal(1, "sf_iron_sram_fpga: RL must be 1 or 2");
    if ((W % NUNITS) != 0) $fatal(1, "sf_iron_sram_fpga: W must divide into NUNITS");
    // FPGA BRAM contents are defined at configuration (zero unless an init
    // file is used); model that here.
    for (int i = 0; i < DEPTH; i++) ram[i] = '0;
    dout = '0;
  end

  // byte-write template: one always block, per-lane conditional write
  always_ff @(posedge clk) begin
    if (en) begin
      if (we) begin
        for (int u = 0; u < NUNITS; u++)
          if (wunit[u]) ram[addr][u*UW +: UW] <= wdata[u*UW +: UW];
      end else begin
        dout <= ram[addr];
      end
    end
  end

  generate
    if (RL == 2) begin : g_oreg
      logic [W-1:0] dout_q;
      initial dout_q = '0;
      always_ff @(posedge clk) dout_q <= dout;
      assign rdata = dout_q;
    end else begin : g_noreg
      assign rdata = dout;
    end
  endgenerate
endmodule
