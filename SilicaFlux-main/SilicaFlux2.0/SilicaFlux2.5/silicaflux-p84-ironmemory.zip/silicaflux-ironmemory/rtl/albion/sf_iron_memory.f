// IronMemory RTL file list (compile order). Paths relative to the repository root.
+incdir+rtl/albion
rtl/albion/sf_iron_pkg.sv
rtl/albion/sf_iron_secded.sv
rtl/albion/sf_iron_sram_generic.sv
rtl/albion/sf_iron_sram_fpga.sv
rtl/albion/sf_iron_sram_asic.sv
rtl/albion/sf_iron_bank_adapter.sv
rtl/albion/sf_iron_bank_arbiter.sv
rtl/albion/sf_iron_rob.sv
rtl/albion/sf_iron_memory_map.sv
rtl/albion/sf_iron_buffer_manager.sv
rtl/albion/sf_iron_extmem_adapter.sv
rtl/albion/sf_iron_memory.sv
rtl/albion/sf_iron_wide_port.sv
// simulation only:
// rtl/albion/sim/sf_iron_simdram.sv
