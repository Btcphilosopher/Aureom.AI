// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_bank_adapter.sv : one single-port SRAM bank with ECC, partial-write
//                           read-modify-write, scrubbing, init and injection
//
// Port discipline (single-port macro): exactly ONE SRAM access per cycle.
// Sources, highest priority first:
//   1. init sweep (after reset, INIT_ON_RESET=1)    -- bank not ready
//   2. RMW / scrub write-back                       -- bank not ready
//   3. master operation from the bank arbiter       -- only when ready
//   4. scrub read (idle cycle, or forced after SCRUB_MAX_DEFER cycles)
//
// Timing (issue cycle t, SRAM read latency RL):
//   read            : SRAM read @t, data @t+RL, decode reg, response @t+RL+1
//   full write      : SRAM write @t, response @t+RL+1 (uniform pipeline)
//   partial write   : ECC_EN=1 -> SRAM read @t, decode, merge, re-encode,
//                     SRAM write @t+RL+1, response @t+RL+1. The bank is NOT
//                     ready for t+1..t+RL+1 (RL+1 lost issue slots per RMW).
//                     ECC_EN=0 -> native byte-lane write, single cycle.
//   scrub           : read @t; if correctable, write corrected word back
//                     @t+RL+1; bank not ready t+1..t+RL+1.
// Every master op yields exactly one response, RL+1 cycles after issue.
//
// ECC storage overhead: CW/DW (72/64 = 1.125 for DW=64). The SRAM backend is
// instantiated CW bits wide, so the overhead is physically present.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_bank_adapter #(
  parameter int DW                 = 64,
  parameter int DEPTH              = 1024,
  parameter int RL                 = 1,
  parameter int ECC_EN             = 1,
  parameter int BACKEND            = 0,     // 0 generic, 1 FPGA BRAM, 2 ASIC macro tiling
  parameter int MACRO_WORDS        = 256,
  parameter int MACRO_BITS         = 72,
  parameter int INIT_ON_RESET      = 1,
  parameter int SIM_POWERUP_RANDOM = 0,
  parameter int TAG_W              = 8,
  parameter int SCRUB_MAX_DEFER    = 64,
  // derived (do not override)
  parameter int NB  = DW / 8,
  parameter int R   = sf_iron_pkg::secded_r(DW),
  parameter int CW  = (ECC_EN != 0) ? (DW + R + 1) : DW,
  parameter int AWL = sf_iron_pkg::clog2_min1(DEPTH)
) (
  input  logic             clk,
  input  logic             rst_n,
  // request (from bank arbiter); req_valid must only be asserted when req_ready
  input  logic             req_valid,
  output logic             req_ready,
  input  logic             req_we,
  input  logic [AWL-1:0]   req_addr,
  input  logic [DW-1:0]    req_wdata,
  input  logic [NB-1:0]    req_be,
  input  logic [TAG_W-1:0] req_tag,
  // response (one per master op)
  output logic             rsp_valid,
  output logic [TAG_W-1:0] rsp_tag,
  output logic [DW-1:0]    rsp_rdata,
  output logic             rsp_we,
  output logic             rsp_ce,
  output logic             rsp_ue,
  // scrubbing
  input  logic             scrub_en,
  input  logic             scrub_tick,
  // fault injection: XOR inj_mask into the codeword of the next master write
  input  logic             inj_arm,
  input  logic [CW-1:0]    inj_mask,
  output logic             inj_pending,
  // status / events (single-cycle pulses unless noted)
  output logic             init_done,
  output logic             ev_rd,
  output logic             ev_wr,
  output logic             ev_rmw,
  output logic             ev_ce,
  output logic             ev_ue,
  output logic             ev_scrub,
  output logic             ev_scrub_fix,
  output logic [AWL-1:0]   ev_err_addr,
  output logic [R:0]       ev_syndrome,
  output logic             port_busy,      // SRAM port used this cycle
  output logic             stall_rmw       // not ready because of RMW/scrub/init
);
  import sf_iron_pkg::*;

  localparam int NUNITS = (ECC_EN != 0) ? 1 : NB;
  localparam logic [1:0] K_RD = 2'd0, K_WR = 2'd1, K_RMW = 2'd2, K_SCRUB = 2'd3;
  localparam int BCW = $clog2(RL + 2) + 1;

  initial begin
    if (RL < 1) $fatal(1, "bank_adapter: RL must be >= 1");
    if (BACKEND < 0 || BACKEND > 2) $fatal(1, "bank_adapter: BACKEND must be 0, 1 or 2");
  end

  // ---------------------------------------------------------------------------
  // SRAM backend
  // ---------------------------------------------------------------------------
  logic              s_en, s_we;
  logic [AWL-1:0]    s_addr;
  logic [CW-1:0]     s_wdata, s_rdata;
  logic [NUNITS-1:0] s_wunit;

  generate
    if (BACKEND == 0) begin : g_generic
      sf_iron_sram_generic #(.W(CW), .DEPTH(DEPTH), .RL(RL), .NUNITS(NUNITS),
        .SIM_POWERUP_RANDOM(SIM_POWERUP_RANDOM)) u_sram (
        .clk, .en(s_en), .we(s_we), .addr(s_addr), .wdata(s_wdata), .wunit(s_wunit), .rdata(s_rdata));
    end else if (BACKEND == 1) begin : g_fpga
      sf_iron_sram_fpga #(.W(CW), .DEPTH(DEPTH), .RL(RL), .NUNITS(NUNITS)) u_sram (
        .clk, .en(s_en), .we(s_we), .addr(s_addr), .wdata(s_wdata), .wunit(s_wunit), .rdata(s_rdata));
    end else begin : g_asic
      sf_iron_sram_asic #(.W(CW), .DEPTH(DEPTH), .RL(RL), .NUNITS(NUNITS),
        .MACRO_WORDS(MACRO_WORDS), .MACRO_BITS(MACRO_BITS)) u_sram (
        .clk, .en(s_en), .we(s_we), .addr(s_addr), .wdata(s_wdata), .wunit(s_wunit), .rdata(s_rdata));
    end
  endgenerate

  // ---------------------------------------------------------------------------
  // ECC encode / decode
  // ---------------------------------------------------------------------------
  logic [DW-1:0] wb_merged, dec_data;
  logic [CW-1:0] enc_req, enc_wb;
  logic          dec_ce, dec_ue;
  logic [R:0]    dec_syn;

  generate
    if (ECC_EN != 0) begin : g_ecc
      sf_iron_secded_enc #(.DW(DW)) u_enc_req (.data(req_wdata), .cw(enc_req));
      sf_iron_secded_enc #(.DW(DW)) u_enc_wb  (.data(wb_merged), .cw(enc_wb));
      sf_iron_secded_dec #(.DW(DW)) u_dec     (.cw(s_rdata), .data(dec_data), .ce(dec_ce), .ue(dec_ue), .syndrome(dec_syn));
    end else begin : g_noecc
      assign enc_req  = req_wdata;
      assign enc_wb   = wb_merged;
      assign dec_data = s_rdata;
      assign dec_ce   = 1'b0;
      assign dec_ue   = 1'b0;
      assign dec_syn  = '0;
    end
  endgenerate

  function automatic logic [DW-1:0] be2mask(input logic [NB-1:0] be);
    logic [DW-1:0] m;
    for (int i = 0; i < NB; i++) m[i*8 +: 8] = {8{be[i]}};
    return m;
  endfunction

  // ---------------------------------------------------------------------------
  // State
  // ---------------------------------------------------------------------------
  logic             init_done_q;
  logic             init_run;      // sweep active (starts the cycle after reset)
  logic [AWL-1:0]   init_ptr;
  logic [BCW-1:0]   busy_cnt;
  logic             scrub_pending;
  logic [15:0]      scrub_defer;
  logic [AWL-1:0]   scrub_ptr;
  logic             inj_pend_q;

  // read pipeline aligned with SRAM latency (stage RL-1 sees s_rdata)
  logic             pv   [RL];
  logic [1:0]       pk   [RL];
  logic [TAG_W-1:0] ptag [RL];
  logic [AWL-1:0]   paddr[RL];
  logic [DW-1:0]    pwd  [RL];
  logic [NB-1:0]    pbe  [RL];
  logic             pinj [RL];   // injection captured for an RMW write-back

  // decode stage (registered)
  logic             d_v;
  logic [1:0]       d_k;
  logic [TAG_W-1:0] d_tag;
  logic [AWL-1:0]   d_addr;
  logic [DW-1:0]    d_wd, d_data;
  logic [NB-1:0]    d_be;
  logic             d_ce, d_ue, d_inj;
  logic [R:0]       d_syn;

  logic m_go, need_rmw, scrub_force, scrub_go, wb_go, inj_use_wr;

  assign need_rmw    = (ECC_EN != 0) && req_we && (req_be != {NB{1'b1}});
  assign scrub_force = (ECC_EN != 0) && scrub_pending && (int'(scrub_defer) >= SCRUB_MAX_DEFER);
  assign req_ready   = init_done_q && (busy_cnt == '0) && !scrub_force;
  assign m_go        = req_valid && req_ready;
  assign scrub_go    = (ECC_EN != 0) && init_done_q && (busy_cnt == '0) && scrub_pending && !m_go;
  assign wb_go       = d_v && (((d_k == K_RMW) && !d_ue) || ((d_k == K_SCRUB) && d_ce));
  assign inj_use_wr  = m_go && req_we && !need_rmw && inj_pend_q;
  assign wb_merged   = (d_k == K_RMW) ? ((d_data & ~be2mask(d_be)) | (d_wd & be2mask(d_be))) : d_data;

  // ---------------------------------------------------------------------------
  // SRAM port mux (one access per cycle)
  // ---------------------------------------------------------------------------
  always_comb begin
    s_en = 1'b0; s_we = 1'b0; s_addr = '0; s_wdata = '0; s_wunit = '0;
    if (init_run) begin
      s_en = 1'b1; s_we = 1'b1; s_addr = init_ptr; s_wdata = '0; s_wunit = '1;   // enc(0) == 0
    end else if (wb_go) begin
      s_en = 1'b1; s_we = 1'b1; s_addr = d_addr; s_wunit = '1;
      s_wdata = enc_wb ^ ((d_k == K_RMW && d_inj) ? inj_mask : '0);
    end else if (m_go) begin
      s_en = 1'b1; s_we = req_we && !need_rmw; s_addr = req_addr;
      s_wdata = enc_req ^ (inj_use_wr ? inj_mask : '0);
      if (ECC_EN != 0) s_wunit = '1;
      else             s_wunit = NUNITS'(req_be);
    end else if (scrub_go) begin
      s_en = 1'b1; s_we = 1'b0; s_addr = scrub_ptr;
    end
  end

  // ---------------------------------------------------------------------------
  // Sequential
  // ---------------------------------------------------------------------------
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      init_done_q   <= 1'b0;      // never ready while reset is asserted
      init_run      <= 1'b0;
      init_ptr      <= '0;
      busy_cnt      <= '0;
      scrub_pending <= 1'b0;
      scrub_defer   <= '0;
      scrub_ptr     <= '0;
      inj_pend_q    <= 1'b0;
      for (int i = 0; i < RL; i++) begin
        pv[i] <= 1'b0; pk[i] <= K_RD; ptag[i] <= '0; paddr[i] <= '0; pwd[i] <= '0; pbe[i] <= '0; pinj[i] <= 1'b0;
      end
      d_v <= 1'b0; d_k <= K_RD; d_tag <= '0; d_addr <= '0; d_wd <= '0; d_data <= '0;
      d_be <= '0; d_ce <= 1'b0; d_ue <= 1'b0; d_syn <= '0; d_inj <= 1'b0;
    end else begin
      // init sweep (or immediate ready when INIT_ON_RESET=0)
      if (!init_done_q && !init_run) begin
        if (INIT_ON_RESET != 0) init_run    <= 1'b1;
        else                    init_done_q <= 1'b1;
      end else if (init_run) begin
        if (int'(init_ptr) == DEPTH - 1) begin init_run <= 1'b0; init_done_q <= 1'b1; end
        else                             init_ptr <= init_ptr + 1'b1;
      end

      // busy counter for RMW / scrub
      if ((m_go && need_rmw) || scrub_go) busy_cnt <= BCW'(RL + 1);
      else if (busy_cnt != '0)            busy_cnt <= busy_cnt - 1'b1;

      // scrub scheduling
      if (scrub_go) begin
        scrub_pending <= 1'b0;
        scrub_defer   <= '0;
        scrub_ptr     <= (int'(scrub_ptr) == DEPTH - 1) ? '0 : scrub_ptr + 1'b1;
      end else begin
        if (scrub_en && scrub_tick && (ECC_EN != 0)) scrub_pending <= 1'b1;
        if (scrub_pending && scrub_defer != 16'hFFFF) scrub_defer <= scrub_defer + 1'b1;
      end

      // injection arm / consume (an RMW captures the pending injection at issue)
      if (inj_arm)                                    inj_pend_q <= 1'b1;
      else if (inj_use_wr || (m_go && need_rmw && inj_pend_q)) inj_pend_q <= 1'b0;

      // read pipeline
      pv[0]    <= m_go || scrub_go;
      pk[0]    <= scrub_go ? K_SCRUB : (!req_we ? K_RD : (need_rmw ? K_RMW : K_WR));
      ptag[0]  <= req_tag;
      paddr[0] <= scrub_go ? scrub_ptr : req_addr;
      pwd[0]   <= req_wdata;
      pbe[0]   <= req_be;
      pinj[0]  <= m_go && need_rmw && inj_pend_q;
      for (int i = 1; i < RL; i++) begin
        pv[i] <= pv[i-1]; pk[i] <= pk[i-1]; ptag[i] <= ptag[i-1]; paddr[i] <= paddr[i-1];
        pwd[i] <= pwd[i-1]; pbe[i] <= pbe[i-1]; pinj[i] <= pinj[i-1];
      end

      // decode stage
      d_v    <= pv[RL-1];
      d_k    <= pk[RL-1];
      d_tag  <= ptag[RL-1];
      d_addr <= paddr[RL-1];
      d_wd   <= pwd[RL-1];
      d_be   <= pbe[RL-1];
      d_inj  <= pinj[RL-1];
      d_data <= dec_data;
      d_ce   <= (pk[RL-1] != K_WR) && dec_ce;
      d_ue   <= (pk[RL-1] != K_WR) && dec_ue;
      d_syn  <= dec_syn;
    end
  end

  // ---------------------------------------------------------------------------
  // Outputs
  // ---------------------------------------------------------------------------
  assign rsp_valid  = d_v && (d_k != K_SCRUB);
  assign rsp_tag    = d_tag;
  assign rsp_we     = (d_k == K_WR) || (d_k == K_RMW);
  assign rsp_ce     = d_ce && (d_k != K_SCRUB);
  assign rsp_ue     = d_ue && (d_k != K_SCRUB);
  // read data restricted to the requested byte lanes; poisoned data is zeroed
  assign rsp_rdata  = (d_k == K_RD && !d_ue) ? (d_data & be2mask(d_be)) : '0;

  assign init_done    = init_done_q;
  assign inj_pending  = inj_pend_q;
  assign ev_rd        = m_go && !req_we;
  assign ev_wr        = m_go && req_we;
  assign ev_rmw       = m_go && need_rmw;
  assign ev_ce        = d_v && d_ce;
  assign ev_ue        = d_v && d_ue;
  assign ev_scrub     = d_v && (d_k == K_SCRUB);
  assign ev_scrub_fix = wb_go && (d_k == K_SCRUB);
  assign ev_err_addr  = d_addr;
  assign ev_syndrome  = d_syn;
  assign port_busy    = s_en;
  assign stall_rmw    = init_done_q && !req_ready;

  // ---------------------------------------------------------------------------
  // Assertions (checked in every simulation run with --assert)
  // ---------------------------------------------------------------------------
`ifndef SYNTHESIS
  always_ff @(posedge clk) begin
    if (rst_n) begin
      assert (!(req_valid && !req_ready))
        else $error("bank_adapter: request presented while bank not ready");
      assert (!(wb_go && m_go))
        else $error("bank_adapter: write-back collided with a master op (port conflict)");
      assert (!(wb_go && scrub_go))
        else $error("bank_adapter: write-back collided with scrub read");
      assert (!(wb_go && busy_cnt != BCW'(1)))
        else $error("bank_adapter: write-back outside its reserved slot");
    end
  end
`endif
endmodule
