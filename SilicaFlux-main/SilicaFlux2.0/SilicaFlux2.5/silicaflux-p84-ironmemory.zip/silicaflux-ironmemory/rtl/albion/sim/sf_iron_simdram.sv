// =============================================================================
/* verilator lint_off WIDTHEXPAND */
/* verilator lint_off UNUSEDSIGNAL */
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_simdram.sv : SIMULATION-ONLY external DRAM controller model
//
// *** Not a DRAM controller design and not a PHY. ***
// A behavioural stand-in that lets IronMemory's external-memory path be
// verified against explicit, documented timing. Real DDR5 / LPDDR5 / HBM
// requires a licensed controller + PHY attached through the adapter channel.
//
// Model:
//   * NBANKS banks, open-page policy, ROW_WORDS words per row per bank.
//     word address -> bank = (addr / ROW_WORDS) % NBANKS,
//                     row  = addr / (ROW_WORDS * NBANKS)
//   * One command in service at a time (no bank-level parallelism), commands
//     served in arrival order from a QDEPTH-entry queue.
//   * Service time once a command reaches the head (cycles, controller clock
//     = IronMemory clock in this model):
//         row hit   : CAS
//         row empty : T_RCD + CAS
//         row miss  : wr_recovery_left + T_RP + T_RCD + CAS
//       CAS = (we ? T_CWL : T_CL) + T_BURST. A write to a bank keeps it from
//       being precharged for T_WR cycles after the write completes.
//   * Refresh every T_REFI cycles: when due, the controller finishes the
//     current command, closes all rows and is busy for T_RFC cycles;
//     cmd_ready is low throughout (back-pressure).
//   * Errors: word address >= WORDS, or a match on the inj_err_addr hook,
//     returns rsp_err=1 (no access performed).
//   Response latency for an isolated command (handshake -> rsp_valid) is
//   service time + 2 cycles of queue/handshake overhead.
// =============================================================================
`timescale 1ns/1ps

module sf_iron_simdram #(
  parameter int DW      = 64,
  parameter int AW      = 17,
  parameter int WORDS   = 131072,
  parameter int TAG_W   = 6,
  parameter int NBANKS  = 8,
  parameter int ROW_WORDS = 128,
  parameter int T_RCD   = 4,
  parameter int T_CL    = 6,
  parameter int T_CWL   = 4,
  parameter int T_RP    = 4,
  parameter int T_WR    = 6,
  parameter int T_BURST = 2,
  parameter int T_REFI  = 780,
  parameter int T_RFC   = 52,
  parameter int QDEPTH  = 4,
  parameter int NB      = DW / 8
) (
  input  logic             clk,
  input  logic             rst_n,
  input  logic             cmd_valid,
  output logic             cmd_ready,
  input  logic             cmd_we,
  input  logic [AW-1:0]    cmd_addr,
  input  logic [DW-1:0]    cmd_wdata,
  input  logic [NB-1:0]    cmd_wstrb,
  input  logic [TAG_W-1:0] cmd_tag,
  output logic             rsp_valid,
  input  logic             rsp_ready,
  output logic [DW-1:0]    rsp_rdata,
  output logic             rsp_err,
  output logic [TAG_W-1:0] rsp_tag,
  // test hooks
  input  logic             inj_err_en,
  input  logic [AW-1:0]    inj_err_addr,
  // statistics
  output logic             ev_row_hit,
  output logic             ev_row_empty,
  output logic             ev_row_miss,
  output logic             ev_refresh
);
  // ---- storage ----
  logic [DW-1:0] mem [WORDS];
  initial for (int i = 0; i < WORDS; i++) mem[i] = '0;

  // ---- command queue ----
  logic             q_we   [QDEPTH];
  logic [AW-1:0]    q_addr [QDEPTH];
  logic [DW-1:0]    q_wd   [QDEPTH];
  logic [NB-1:0]    q_st   [QDEPTH];
  logic [TAG_W-1:0] q_tag  [QDEPTH];
  int               q_head, q_tail, q_cnt;

  // ---- bank state ----
  logic             open_v  [NBANKS];
  longint           open_row[NBANKS];
  longint           wr_free [NBANKS];   // cycle after which precharge is allowed

  typedef enum logic [1:0] { S_IDLE, S_SERVE, S_RESP, S_REFRESH } st_t;
  st_t     st;
  int      cnt, refi_cnt;
  logic    refresh_due;
  longint  cyc;
  logic             c_we;
  logic [AW-1:0]    c_addr;
  logic [DW-1:0]    c_wd;
  logic [NB-1:0]    c_st;
  logic [TAG_W-1:0] c_tag;

  assign cmd_ready = (q_cnt < QDEPTH) && (st != S_REFRESH) && rst_n;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      q_head <= 0; q_tail <= 0; q_cnt <= 0; st <= S_IDLE; cnt <= 0; refi_cnt <= 0; refresh_due <= 1'b0;
      cyc <= 0; rsp_valid <= 1'b0; rsp_rdata <= '0; rsp_err <= 1'b0; rsp_tag <= '0;
      c_we <= 1'b0; c_addr <= '0; c_wd <= '0; c_st <= '0; c_tag <= '0;
      ev_row_hit <= 1'b0; ev_row_empty <= 1'b0; ev_row_miss <= 1'b0; ev_refresh <= 1'b0;
      for (int b = 0; b < NBANKS; b++) begin open_v[b] <= 1'b0; open_row[b] <= 0; wr_free[b] <= 0; end
    end else begin
      int pops, pushes;
      pops = 0; pushes = 0;
      cyc <= cyc + 1;
      ev_row_hit <= 1'b0; ev_row_empty <= 1'b0; ev_row_miss <= 1'b0; ev_refresh <= 1'b0;

      // refresh interval
      if (refi_cnt + 1 >= T_REFI) begin refi_cnt <= 0; refresh_due <= 1'b1; end
      else refi_cnt <= refi_cnt + 1;

      // enqueue
      if (cmd_valid && cmd_ready) begin
        q_we[q_tail] <= cmd_we; q_addr[q_tail] <= cmd_addr; q_wd[q_tail] <= cmd_wdata;
        q_st[q_tail] <= cmd_wstrb; q_tag[q_tail] <= cmd_tag;
        q_tail <= (q_tail + 1) % QDEPTH;
        pushes = 1;
      end

      case (st)
        S_IDLE: begin
          if (refresh_due) begin
            refresh_due <= 1'b0;
            for (int b = 0; b < NBANKS; b++) open_v[b] <= 1'b0;
            cnt <= T_RFC;
            ev_refresh <= 1'b1;
            st <= S_REFRESH;
          end else if (q_cnt > 0) begin
            int bk; longint row, lat, wrl; int cas;
            c_we <= q_we[q_head]; c_addr <= q_addr[q_head]; c_wd <= q_wd[q_head];
            c_st <= q_st[q_head]; c_tag <= q_tag[q_head];
            q_head <= (q_head + 1) % QDEPTH;
            pops = 1;
            bk  = (int'(q_addr[q_head]) / ROW_WORDS) % NBANKS;
            row = longint'(q_addr[q_head]) / (ROW_WORDS * NBANKS);
            cas = (q_we[q_head] ? T_CWL : T_CL) + T_BURST;
            if (open_v[bk] && open_row[bk] == row) begin
              lat = cas; ev_row_hit <= 1'b1;
            end else if (open_v[bk]) begin
              wrl = (wr_free[bk] > cyc) ? (wr_free[bk] - cyc) : 0;
              lat = wrl + T_RP + T_RCD + cas; ev_row_miss <= 1'b1;
            end else begin
              lat = T_RCD + cas; ev_row_empty <= 1'b1;
            end
            open_v[bk] <= 1'b1; open_row[bk] <= row;
            if (q_we[q_head]) wr_free[bk] <= cyc + lat + T_WR;
            cnt <= int'(lat);
            st <= S_SERVE;
          end
        end
        S_SERVE: begin
          if (cnt > 1) cnt <= cnt - 1;
          else begin
            logic err;
            err = (int'(c_addr) >= WORDS) || (inj_err_en && c_addr == inj_err_addr);
            rsp_err   <= err;
            rsp_tag   <= c_tag;
            rsp_rdata <= '0;
            if (!err) begin
              if (c_we) begin
                for (int i = 0; i < NB; i++) if (c_st[i]) mem[c_addr][i*8 +: 8] <= c_wd[i*8 +: 8];
              end else begin
                rsp_rdata <= mem[c_addr];
              end
            end
            rsp_valid <= 1'b1;
            st <= S_RESP;
          end
        end
        S_RESP: begin
          if (rsp_ready) begin rsp_valid <= 1'b0; st <= S_IDLE; end
        end
        S_REFRESH: begin
          if (cnt > 1) cnt <= cnt - 1; else st <= S_IDLE;
        end
        default: st <= S_IDLE;
      endcase
      q_cnt <= q_cnt + pushes - pops;
    end
  end
endmodule
