// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_extmem_adapter.sv : replaceable external-memory controller adapter
//
// IronMemory side : one request per master port (from the port's issue slot),
//                   tagged {port, seq}; completions go to the port's ROB.
// Controller side : a generic tagged command / response channel
//     cmd : valid/ready, we, word address, wdata, wstrb, tag
//     rsp : valid/ready, rdata, err, tag      (any order across tags)
//
// The controller is REPLACEABLE. In simulation it is sf_iron_simdram
// (rtl/albion/sim/), an explicit-timing behavioural model. For silicon, a
// licensed DDR5 / LPDDR5 / HBM controller + PHY attaches here through a thin
// protocol bridge (e.g. AXI4 -> this channel). IronMemory deliberately
// contains no DRAM PHY or DFI logic.
//
// Adapter duties:
//   * round-robin among ports, single registered command stage (back-pressure
//     from cmd_ready stalls the winning port's slot, never drops)
//   * outstanding-tag scoreboard (limit EXT_MAX_OUT); responses for tags that
//     are not outstanding are dropped and flagged (protocol error)
//   * read data restricted to the requested byte lanes
//   * controller rsp_err -> RSP_EXT on the master response
// rsp_ready is constant 1: every tag has a reserved ROB entry upstream.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_extmem_adapter #(
  parameter int NUM_PORTS   = 5,
  parameter int DW          = 64,
  parameter int EWW         = 17,
  parameter int TAG_W       = 5,
  parameter int EXT_MAX_OUT = 8,
  parameter int TS_W        = 32,
  parameter int NB          = DW / 8,
  parameter int PW          = sf_iron_pkg::clog2_min1(NUM_PORTS),
  parameter int OCW         = $clog2(EXT_MAX_OUT + 1)
) (
  input  logic                       clk,
  input  logic                       rst_n,
  input  logic [TS_W-1:0]            now,
  // ---- from master issue slots ----
  input  logic [NUM_PORTS-1:0]       p_valid,
  output logic [NUM_PORTS-1:0]       p_ready,
  input  logic [NUM_PORTS-1:0]       p_we,
  input  logic [NUM_PORTS*EWW-1:0]   p_word,
  input  logic [NUM_PORTS*DW-1:0]    p_wdata,
  input  logic [NUM_PORTS*NB-1:0]    p_be,
  input  logic [NUM_PORTS*TAG_W-1:0] p_tag,
  // ---- controller channel ----
  output logic                       cmd_valid,
  input  logic                       cmd_ready,
  output logic                       cmd_we,
  output logic [EWW-1:0]             cmd_addr,
  output logic [DW-1:0]              cmd_wdata,
  output logic [NB-1:0]              cmd_wstrb,
  output logic [TAG_W-1:0]           cmd_tag,
  input  logic                       rsp_valid,
  output logic                       rsp_ready,
  input  logic [DW-1:0]              rsp_rdata,
  input  logic                       rsp_err,
  input  logic [TAG_W-1:0]           rsp_tag,
  // ---- completions to ROBs ----
  output logic                       cpl_valid,
  output logic [TAG_W-1:0]           cpl_tag,
  output logic [DW-1:0]              cpl_data,
  output logic                       cpl_err,
  // ---- status / events ----
  output logic [OCW-1:0]             outstanding,
  output logic                       ev_rd,
  output logic                       ev_wr,
  output logic                       ev_bp,
  output logic                       ev_err,
  output logic                       ev_proto,
  output logic                       lat_valid,
  output logic [TS_W-1:0]            lat_cycles
);
  localparam int NT = 1 << TAG_W;

  logic [PW-1:0]  rr_ptr, sel;
  logic           sel_found, can_accept, acc;
  logic           cv_q, cwe_q;
  logic [EWW-1:0] caddr_q;
  logic [DW-1:0]  cwd_q;
  logic [NB-1:0]  cbe_q;
  logic [TAG_W-1:0] ctag_q;
  logic [NT-1:0]  out_q;
  logic [NB-1:0]  t_be  [NT];
  logic           t_we  [NT];
  logic [TS_W-1:0] t_ts [NT];
  logic           rsp_known, cmd_fire;

  function automatic logic [DW-1:0] be2mask(input logic [NB-1:0] be);
    logic [DW-1:0] m;
    for (int i = 0; i < NB; i++) m[i*8 +: 8] = {8{be[i]}};
    return m;
  endfunction

  assign cmd_fire   = cv_q && cmd_ready;
  assign can_accept = (!cv_q || cmd_ready) && (int'(outstanding) < EXT_MAX_OUT);

  always_comb begin
    sel_found = 1'b0; sel = '0;
    for (int i = 0; i < NUM_PORTS; i++) begin
      int idx;
      idx = int'(rr_ptr) + i;
      if (idx >= NUM_PORTS) idx = idx - NUM_PORTS;
      if (!sel_found && p_valid[idx]) begin sel_found = 1'b1; sel = PW'(idx); end
    end
    acc     = sel_found && can_accept;
    p_ready = '0;
    if (acc) p_ready[sel] = 1'b1;
  end

  assign rsp_known = rsp_valid && out_q[rsp_tag];

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      rr_ptr <= '0; cv_q <= 1'b0; cwe_q <= 1'b0; caddr_q <= '0; cwd_q <= '0; cbe_q <= '0; ctag_q <= '0;
      out_q <= '0; outstanding <= '0;
      for (int t = 0; t < NT; t++) begin t_be[t] <= '0; t_we[t] <= 1'b0; t_ts[t] <= '0; end
    end else begin
      if (cmd_fire && !acc) cv_q <= 1'b0;
      if (acc) begin
        cv_q    <= 1'b1;
        cwe_q   <= p_we[sel];
        caddr_q <= p_word[sel*EWW +: EWW];
        cwd_q   <= p_wdata[sel*DW +: DW];
        cbe_q   <= p_be[sel*NB +: NB];
        ctag_q  <= p_tag[sel*TAG_W +: TAG_W];
        rr_ptr  <= (int'(sel) == NUM_PORTS - 1) ? '0 : sel + 1'b1;
        t_be[p_tag[sel*TAG_W +: TAG_W]] <= p_be[sel*NB +: NB];
        t_we[p_tag[sel*TAG_W +: TAG_W]] <= p_we[sel];
        t_ts[p_tag[sel*TAG_W +: TAG_W]] <= now;
      end
      // scoreboard: set on acceptance, clear on response
      for (int t = 0; t < NT; t++) begin
        if (acc && (p_tag[sel*TAG_W +: TAG_W] == TAG_W'(t))) out_q[t] <= 1'b1;
        else if (rsp_known && (rsp_tag == TAG_W'(t)))      out_q[t] <= 1'b0;
      end
      outstanding <= outstanding + OCW'(acc) - OCW'(rsp_known);
    end
  end

  assign cmd_valid = cv_q;
  assign cmd_we    = cwe_q;
  assign cmd_addr  = caddr_q;
  assign cmd_wdata = cwd_q;
  assign cmd_wstrb = cbe_q;
  assign cmd_tag   = ctag_q;
  assign rsp_ready = 1'b1;

  assign cpl_valid  = rsp_known;
  assign cpl_tag    = rsp_tag;
  assign cpl_err    = rsp_err;
  assign cpl_data   = (rsp_err || t_we[rsp_tag]) ? '0 : (rsp_rdata & be2mask(t_be[rsp_tag]));

  assign ev_rd      = cmd_fire && !cwe_q;
  assign ev_wr      = cmd_fire && cwe_q;
  assign ev_bp      = cv_q && !cmd_ready;
  assign ev_err     = rsp_known && rsp_err;
  assign ev_proto   = rsp_valid && !out_q[rsp_tag];
  assign lat_valid  = rsp_known;
  assign lat_cycles = now - t_ts[rsp_tag];

`ifndef SYNTHESIS
  always_ff @(posedge clk) if (rst_n) begin
    assert (!(acc && out_q[p_tag[sel*TAG_W +: TAG_W]] && !(rsp_known && rsp_tag == p_tag[sel*TAG_W +: TAG_W])))
      else $error("extmem_adapter: tag reused while outstanding");
  end
`endif
endmodule
