// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_secded.sv : parameterised extended-Hamming SECDED encoder / decoder
//
// No pre-verified SilicaFlux SECDED engine was present in the repository at
// audit time (see docs/iron_memory/repository_audit.md), so this engine was
// written for IronMemory and is verified exhaustively for single- and
// double-bit errors by tests/iron_memory/tb_secded.sv.
//
// Code: extended Hamming, systematic storage.
//   codeword = { p_all, p[R-1:0], data[DW-1:0] }    CW = DW + R + 1
//   Hamming positions 1..DW+R; parity bit j sits at position 2^j, data bits
//   fill the remaining positions in ascending order. p_all is even parity over
//   the full codeword.
//   DW=64 -> (72,64), DW=128 -> (137,128), DW=256 -> (266,256)
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

// ---------------------------------------------------------------------------
// Encoder (pure combinational)
// ---------------------------------------------------------------------------
module sf_iron_secded_enc #(
  parameter int DW = 64,
  parameter int R  = sf_iron_pkg::secded_r(DW),
  parameter int CW = DW + R + 1
) (
  input  logic [DW-1:0] data,
  output logic [CW-1:0] cw
);
  // Hamming position of each data bit, packed R bits per data bit.
  function automatic logic [DW*R-1:0] build_pos();
    logic [DW*R-1:0] v;
    int cnt;
    v   = '0;
    cnt = 0;
    for (int p = 3; p < (1 << R); p++) begin
      if (((p & (p - 1)) != 0) && (cnt < DW)) begin
        v[cnt*R +: R] = p[R-1:0];
        cnt = cnt + 1;
      end
    end
    return v;
  endfunction

  localparam logic [DW*R-1:0] POS = build_pos();

  logic [R-1:0] p;
  always_comb begin
    p = '0;
    for (int k = 0; k < DW; k++) begin
      for (int j = 0; j < R; j++) begin
        if (POS[k*R + j]) p[j] = p[j] ^ data[k];
      end
    end
  end

  assign cw = { (^data) ^ (^p), p, data };
endmodule

// ---------------------------------------------------------------------------
// Decoder (pure combinational)
//   ce : single-bit error detected and corrected (data is good)
//   ue : uncorrectable (double-bit or invalid-syndrome) error detected
// ---------------------------------------------------------------------------
module sf_iron_secded_dec #(
  parameter int DW = 64,
  parameter int R  = sf_iron_pkg::secded_r(DW),
  parameter int CW = DW + R + 1
) (
  input  logic [CW-1:0] cw,
  output logic [DW-1:0] data,
  output logic          ce,
  output logic          ue,
  output logic [R:0]    syndrome   // {overall parity mismatch, hamming syndrome}
);
  function automatic logic [DW*R-1:0] build_pos();
    logic [DW*R-1:0] v;
    int cnt;
    v   = '0;
    cnt = 0;
    for (int p = 3; p < (1 << R); p++) begin
      if (((p & (p - 1)) != 0) && (cnt < DW)) begin
        v[cnt*R +: R] = p[R-1:0];
        cnt = cnt + 1;
      end
    end
    return v;
  endfunction

  localparam logic [DW*R-1:0] POS    = build_pos();
  localparam int              MAXPOS = DW + R;   // highest legal Hamming position

  logic [DW-1:0] d_in;
  logic [R-1:0]  p_in;
  logic [R-1:0]  s;
  logic          ov;
  logic          s_is_parity;   // syndrome points at a check bit (power of two)
  logic          s_hits_data;
  logic [DW-1:0] flip;

  assign d_in    = cw[DW-1:0];
  assign p_in    = cw[DW +: R];

  always_comb begin
    s = p_in;
    for (int k = 0; k < DW; k++) begin
      for (int j = 0; j < R; j++) begin
        if (POS[k*R + j]) s[j] = s[j] ^ d_in[k];
      end
    end
    ov = ^cw;   // even parity over the whole codeword -> 0 when consistent

    flip        = '0;
    s_hits_data = 1'b0;
    for (int k = 0; k < DW; k++) begin
      if (s == POS[k*R +: R]) begin
        flip[k]     = 1'b1;
        s_hits_data = 1'b1;
      end
    end
    s_is_parity = (s != '0) && ((s & (s - 1'b1)) == '0);

    ce   = 1'b0;
    ue   = 1'b0;
    data = d_in;
    if (ov) begin
      // odd number of flipped bits: assume single-bit error
      if (s == '0) begin
        ce = 1'b1;                       // overall parity bit itself flipped
      end else if (s_is_parity) begin
        ce = 1'b1;                       // a check bit flipped; data intact
      end else if (s_hits_data && (int'(s) <= MAXPOS)) begin
        ce   = 1'b1;
        data = d_in ^ flip;
      end else begin
        ue = 1'b1;                       // syndrome outside the code: >=3 bits
      end
    end else if (s != '0) begin
      ue = 1'b1;                         // even flips, non-zero syndrome: DED
    end
    syndrome = {ov, s};
  end
endmodule
