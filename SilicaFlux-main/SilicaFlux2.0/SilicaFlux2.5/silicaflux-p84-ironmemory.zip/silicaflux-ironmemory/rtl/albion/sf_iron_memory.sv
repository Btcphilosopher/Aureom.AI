// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_memory.sv : cloud memory and buffering subsystem (top level)
// Aureom.AI / SilicaFlux Albion
//
//   NUM_PORTS master ports ──► per-port: address map ─► ownership check ─►
//   issue slot ─► per-bank arbiter ─► bank adapter (ECC, RMW, scrub) ─► SRAM
//                 └──────────────► external-memory adapter ─► controller
//   completions ─► per-port reorder buffer ─► in-order responses
//
// Baseline: four 64-bit single-port banks, one shared, word-interleaved
// address window, five masters (Keystone, BridgeEngine, PacketForge,
// ComputeWorks, VirtualFoundry), buffer manager, SECDED ECC, CSRs and
// performance counters. External memory (EXT_EN=1) adds a second window
// served through sf_iron_extmem_adapter.
//
// Master port protocol (per port, valid/ready, all signals held while
// valid && !ready):
//   req : addr (byte), size (log2 bytes), we, wdata (byte-lane aligned),
//         wstrb (writes; ANDed with the size mask)
//   rsp : rdata (requested lanes only, others zero), err (sf_iron_pkg RSP_*),
//         ecc_corr (a single-bit error was corrected for this access)
// Responses return in request order per port. Up to MAX_OUT outstanding per
// port. Ports are assigned to ownership domains by PORT_DOMAIN_MAP (3 bits
// per port; default identity: port i = domain i).
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_memory #(
  parameter int             NUM_PORTS          = 5,
  parameter logic [23:0]    PORT_DOMAIN_MAP    = 24'o00043210,
  parameter int             AW                 = 32,
  parameter int             DW                 = 64,
  parameter int             NUM_BANKS          = 4,
  parameter int             BANK_DEPTH         = 1024,
  parameter int             RL                 = 1,
  parameter int             INTERLEAVE         = 1,
  parameter logic [AW-1:0]  SRAM_BASE          = AW'('h1000_0000),
  parameter int             ECC_EN             = 1,
  parameter int             BACKEND            = 0,
  parameter int             MACRO_WORDS        = 256,
  parameter int             MACRO_BITS         = 72,
  parameter int             INIT_ON_RESET      = 1,
  parameter int             SIM_POWERUP_RANDOM = 0,
  parameter int             MAX_OUT            = 8,
  parameter int             NUM_DESC           = 16,
  parameter int             GRAN_BYTES         = 256,
  parameter int             EXT_EN             = 1,
  parameter logic [AW-1:0]  EXT_BASE           = AW'('h8000_0000),
  parameter longint         EXT_BYTES          = 64'd1048576,
  parameter int             EXT_MAX_OUT        = 8,
  parameter int             STARVE_LIMIT       = 16,
  parameter int             SCRUB_MAX_DEFER    = 64,
  // derived (do not override)
  parameter int ND    = sf_iron_pkg::NUM_DOMAINS,
  parameter int NB    = DW / 8,
  parameter int PW    = sf_iron_pkg::clog2_min1(NUM_PORTS),
  parameter int SW    = sf_iron_pkg::clog2_min1(MAX_OUT),
  parameter int IDW   = sf_iron_pkg::clog2_min1(NUM_DESC),
  parameter int BW    = sf_iron_pkg::clog2_min1(NUM_BANKS),
  parameter int LW    = sf_iron_pkg::clog2_min1(BANK_DEPTH),
  parameter longint SRAM_BYTES = longint'(NUM_BANKS) * longint'(BANK_DEPTH) * (longint'(DW) / 64'd8),
  parameter int LEN_W = $clog2(SRAM_BYTES + 1),
  parameter int EWW   = sf_iron_pkg::clog2_min1(int'(EXT_BYTES / (longint'(DW) / 64'd8))),
  parameter int ETW   = PW + SW,
  parameter int R     = sf_iron_pkg::secded_r(DW),
  parameter int CW    = (ECC_EN != 0) ? (DW + R + 1) : DW
) (
  input  logic                       clk,
  input  logic                       rst_n,
  // ---------------- master ports ----------------
  input  logic [NUM_PORTS-1:0]       m_req_valid,
  output logic [NUM_PORTS-1:0]       m_req_ready,
  input  logic [NUM_PORTS*AW-1:0]    m_req_addr,
  input  logic [NUM_PORTS*3-1:0]     m_req_size,
  input  logic [NUM_PORTS-1:0]       m_req_we,
  input  logic [NUM_PORTS*DW-1:0]    m_req_wdata,
  input  logic [NUM_PORTS*NB-1:0]    m_req_wstrb,
  output logic [NUM_PORTS-1:0]       m_rsp_valid,
  input  logic [NUM_PORTS-1:0]       m_rsp_ready,
  output logic [NUM_PORTS*DW-1:0]    m_rsp_rdata,
  output logic [NUM_PORTS*3-1:0]     m_rsp_err,
  output logic [NUM_PORTS-1:0]       m_rsp_ecc_corr,
  // ---------------- buffer manager command port ----------------
  input  logic                       bm_cmd_valid,
  output logic                       bm_cmd_ready,
  input  logic [2:0]                 bm_cmd_op,
  input  logic [2:0]                 bm_cmd_requester,   // hardware-sourced domain
  input  logic [IDW-1:0]             bm_cmd_id,
  input  logic [2:0]                 bm_cmd_btype,
  input  logic [AW-1:0]              bm_cmd_start,
  input  logic [LEN_W-1:0]           bm_cmd_len,
  input  logic [2:0]                 bm_cmd_owner,
  input  logic [ND-1:0]              bm_cmd_rd_mask,
  input  logic [ND-1:0]              bm_cmd_wr_mask,
  output logic                       bm_rsp_valid,
  output logic [3:0]                 bm_rsp_status,
  output logic [IDW-1:0]             bm_rsp_id,
  output logic                       bm_rsp_in_use,
  output logic [2:0]                 bm_rsp_btype,
  output logic [AW-1:0]              bm_rsp_start,
  output logic [LEN_W-1:0]           bm_rsp_len,
  output logic [2:0]                 bm_rsp_owner,
  output logic [ND-1:0]              bm_rsp_rd_mask,
  output logic [ND-1:0]              bm_rsp_wr_mask,
  output logic [7:0]                 bm_rsp_err_bits,
  // ---------------- CSR port (Keystone) ----------------
  input  logic                       csr_valid,
  input  logic                       csr_we,
  input  logic [11:0]                csr_addr,
  input  logic [31:0]                csr_wdata,
  output logic                       csr_rvalid,
  output logic [31:0]                csr_rdata,
  output logic                       csr_err,
  // ---------------- external memory controller channel ----------------
  output logic                       ext_cmd_valid,
  input  logic                       ext_cmd_ready,
  output logic                       ext_cmd_we,
  output logic [EWW-1:0]             ext_cmd_addr,
  output logic [DW-1:0]              ext_cmd_wdata,
  output logic [NB-1:0]              ext_cmd_wstrb,
  output logic [ETW-1:0]             ext_cmd_tag,
  input  logic                       ext_rsp_valid,
  output logic                       ext_rsp_ready,
  input  logic [DW-1:0]              ext_rsp_rdata,
  input  logic                       ext_rsp_err,
  input  logic [ETW-1:0]             ext_rsp_tag,
  // ---------------- status ----------------
  output logic                       init_done,
  output logic                       irq,
  // ---------------- observability trace (bank issue events) ----------------
  output logic [NUM_BANKS-1:0]       trc_valid,
  output logic [NUM_BANKS*PW-1:0]    trc_port,
  output logic [NUM_BANKS*SW-1:0]    trc_seq,
  output logic [NUM_BANKS-1:0]       trc_we,
  output logic [NUM_BANKS*LW-1:0]    trc_word,
  output logic [NUM_BANKS*NB-1:0]    trc_be,
  output logic [NUM_BANKS*DW-1:0]    trc_wdata
);
  import sf_iron_pkg::*;

  localparam int TAG_W = 2 + IDW + PW + SW;      // {raw, bufv, bufid, port, seq}
  localparam int NSRC  = NUM_BANKS + 1;          // completion sources per ROB
  localparam int INFL_W = $clog2(NUM_PORTS * MAX_OUT + 2) + 1;
  localparam int TS_W  = 32;
  localparam int OCW   = $clog2(EXT_MAX_OUT + 1);
  localparam int NG    = int'(SRAM_BYTES / longint'(GRAN_BYTES));
  localparam int GCW   = $clog2(NG + 1);
  localparam int OW    = sf_iron_pkg::clog2_min1(NB);

  initial begin
    if (NUM_PORTS < 1 || NUM_PORTS > 8) $fatal(1, "sf_iron_memory: NUM_PORTS must be 1..8");
    if (NUM_BANKS < 1 || NUM_BANKS > 16) $fatal(1, "sf_iron_memory: NUM_BANKS must be 1..16");
    for (int p = 0; p < NUM_PORTS; p++)
      if (int'(PORT_DOMAIN_MAP[3*p +: 3]) >= ND) $fatal(1, "sf_iron_memory: PORT_DOMAIN_MAP names an unknown domain");
  end

  // ===========================================================================
  // Free-running cycle counter (timestamps)
  // ===========================================================================
  logic [TS_W-1:0] now;
  always_ff @(posedge clk or negedge rst_n)
    if (!rst_n) now <= '0; else now <= now + 1'b1;

  // ===========================================================================
  // CSR-controlled state (declared early, implemented at the end)
  // ===========================================================================
  logic                 csr_raw_en, csr_scrub_en, csr_irq_ue, csr_irq_perm, csr_irq_ext, csr_freeze;
  logic [31:0]          csr_scrub_interval;
  logic [NUM_PORTS-1:0] csr_hipri;
  logic [ND-1:0]        csr_ext_rd, csr_ext_wr;
  logic [31:0]          csr_inj_bits;
  logic [NUM_BANKS-1:0] inj_arm;
  logic [CW-1:0]        inj_mask;
  logic                 cnt_clear;

  // ===========================================================================
  // Per-port decode, permission, issue slot, ROB
  // ===========================================================================
  logic [1:0]       mp_region [NUM_PORTS];
  logic [BW-1:0]    mp_bank   [NUM_PORTS];
  logic [LW-1:0]    mp_word   [NUM_PORTS];
  logic [EWW-1:0]   mp_eword  [NUM_PORTS];
  logic [NB-1:0]    mp_be     [NUM_PORTS];
  logic [AW-1:0]    mp_lo     [NUM_PORTS];
  logic [AW-1:0]    mp_hi     [NUM_PORTS];
  logic [OW:0]      mp_nb     [NUM_PORTS];
  logic [2:0]       mp_err    [NUM_PORTS];
  logic [2:0]       fin_err   [NUM_PORTS];
  logic [NUM_PORTS-1:0] fire, legal_fire;

  logic             slot_v     [NUM_PORTS];
  logic [1:0]       slot_region[NUM_PORTS];
  logic [BW-1:0]    slot_bank  [NUM_PORTS];
  logic [LW-1:0]    slot_word  [NUM_PORTS];
  logic [EWW-1:0]   slot_eword [NUM_PORTS];
  logic             slot_we    [NUM_PORTS];
  logic [DW-1:0]    slot_wdata [NUM_PORTS];
  logic [NB-1:0]    slot_be    [NUM_PORTS];
  logic [SW-1:0]    slot_seq   [NUM_PORTS];
  logic             slot_bufv  [NUM_PORTS];
  logic [IDW-1:0]   slot_bufid [NUM_PORTS];
  logic             slot_raw   [NUM_PORTS];
  logic [NUM_PORTS-1:0] slot_fire, port_granted, port_lost, urgent, ext_p_ready;
  logic [15:0]      wait_cnt   [NUM_PORTS];
  logic [NUM_PORTS-1:0] starve_evt;

  logic [NUM_PORTS-1:0] rob_full, rob_rsp_valid, rob_lat_valid;
  logic [TS_W-1:0]  rob_lat [NUM_PORTS];
  logic [SW-1:0]    rob_seq [NUM_PORTS];
  logic [NUM_PORTS-1:0] rsp_fire;

  // buffer manager interface
  logic [NUM_PORTS*AW-1:0]  bm_chk_lo, bm_chk_hi;
  logic [NUM_PORTS-1:0]     bm_chk_we, bm_chk_hit, bm_chk_raw, bm_chk_fire, bm_ev_viol;
  logic [NUM_PORTS*3-1:0]   bm_chk_err;
  logic [NUM_PORTS*IDW-1:0] bm_chk_id;
  logic                     bm_raw_block;

  // bank side (declared here, driven in the bank generate)
  logic [NUM_BANKS-1:0]     bk_rsp_valid, bk_rsp_ce, bk_rsp_ue, bk_init_done;
  logic [TAG_W-1:0]         bk_rsp_tag  [NUM_BANKS];
  logic [DW-1:0]            bk_rsp_rdata[NUM_BANKS];
  logic [NUM_PORTS-1:0]     gnt_m  [NUM_BANKS];
  logic [NUM_PORTS-1:0]     lose_m [NUM_BANKS];

  // ext side
  logic                     ex_cpl_valid, ex_cpl_err;
  logic [ETW-1:0]           ex_cpl_tag;
  logic [DW-1:0]            ex_cpl_data;

  genvar gp, gb;
  generate
    for (gp = 0; gp < NUM_PORTS; gp++) begin : g_port
      localparam logic [2:0] DOM = PORT_DOMAIN_MAP[3*gp +: 3];

      sf_iron_memory_map #(.AW(AW), .DW(DW), .NUM_BANKS(NUM_BANKS), .BANK_DEPTH(BANK_DEPTH),
        .INTERLEAVE(INTERLEAVE), .SRAM_BASE(SRAM_BASE), .EXT_EN(EXT_EN), .EXT_BASE(EXT_BASE),
        .EXT_BYTES(EXT_BYTES)) u_map (
        .addr(m_req_addr[gp*AW +: AW]), .size(m_req_size[gp*3 +: 3]), .we(m_req_we[gp]),
        .wstrb(m_req_wstrb[gp*NB +: NB]), .region(mp_region[gp]), .bank(mp_bank[gp]),
        .bank_word(mp_word[gp]), .byte_off(/* unused */), .ext_word(mp_eword[gp]), .be(mp_be[gp]),
        .lo_addr(mp_lo[gp]), .hi_addr(mp_hi[gp]), .nbytes(mp_nb[gp]), .err(mp_err[gp]));

      assign bm_chk_lo[gp*AW +: AW] = mp_lo[gp];
      assign bm_chk_hi[gp*AW +: AW] = mp_hi[gp];
      assign bm_chk_we[gp]          = m_req_we[gp];

      logic ext_ok;
      assign ext_ok = m_req_we[gp] ? csr_ext_wr[DOM] : csr_ext_rd[DOM];

      always_comb begin
        if (mp_err[gp] != RSP_OK)              fin_err[gp] = mp_err[gp];
        else if (mp_region[gp] == REGION_SRAM) fin_err[gp] = bm_chk_err[gp*3 +: 3];
        else if (mp_region[gp] == REGION_EXT)  fin_err[gp] = ext_ok ? RSP_OK : RSP_PERM;
        else                                   fin_err[gp] = RSP_DECODE;
      end

      assign slot_fire[gp] = slot_v[gp] &&
                             ((slot_region[gp] == REGION_SRAM) ? port_granted[gp] : ext_p_ready[gp]);
      assign m_req_ready[gp] = init_done && !rob_full[gp] && (!slot_v[gp] || slot_fire[gp]) &&
                               !(bm_raw_block && (DOM == DOM_KEYSTONE));
      assign fire[gp]        = m_req_valid[gp] && m_req_ready[gp];
      assign legal_fire[gp]  = fire[gp] && (fin_err[gp] == RSP_OK);
      assign bm_chk_fire[gp] = fire[gp] && (mp_region[gp] == REGION_SRAM) && (mp_err[gp] == RSP_OK);

      // ---- issue slot ----
      always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
          slot_v[gp] <= 1'b0; slot_region[gp] <= REGION_NONE; slot_bank[gp] <= '0; slot_word[gp] <= '0;
          slot_eword[gp] <= '0; slot_we[gp] <= 1'b0; slot_wdata[gp] <= '0; slot_be[gp] <= '0;
          slot_seq[gp] <= '0; slot_bufv[gp] <= 1'b0; slot_bufid[gp] <= '0; slot_raw[gp] <= 1'b0;
          wait_cnt[gp] <= '0;
        end else begin
          if (legal_fire[gp]) begin
            slot_v[gp]      <= 1'b1;
            slot_region[gp] <= mp_region[gp];
            slot_bank[gp]   <= mp_bank[gp];
            slot_word[gp]   <= mp_word[gp];
            slot_eword[gp]  <= mp_eword[gp];
            slot_we[gp]     <= m_req_we[gp];
            slot_wdata[gp]  <= m_req_wdata[gp*DW +: DW];
            slot_be[gp]     <= mp_be[gp];
            slot_seq[gp]    <= rob_seq[gp];
            slot_bufv[gp]   <= (mp_region[gp] == REGION_SRAM) && bm_chk_hit[gp];
            slot_bufid[gp]  <= bm_chk_id[gp*IDW +: IDW];
            slot_raw[gp]    <= (mp_region[gp] == REGION_SRAM) && bm_chk_raw[gp];
          end else if (slot_fire[gp]) begin
            slot_v[gp] <= 1'b0;
          end
          // wait accounting for anti-starvation
          if (!slot_v[gp] || slot_fire[gp]) wait_cnt[gp] <= '0;
          else if (wait_cnt[gp] != 16'hFFFF) wait_cnt[gp] <= wait_cnt[gp] + 1'b1;
        end
      end
      assign urgent[gp]     = slot_v[gp] && (int'(wait_cnt[gp]) >= STARVE_LIMIT);
      assign starve_evt[gp] = slot_v[gp] && !slot_fire[gp] && (int'(wait_cnt[gp]) == STARVE_LIMIT - 1);

      always_comb begin
        port_granted[gp] = 1'b0;
        port_lost[gp]    = 1'b0;
        for (int b = 0; b < NUM_BANKS; b++) begin
          port_granted[gp] = port_granted[gp] | gnt_m[b][gp];
          port_lost[gp]    = port_lost[gp]    | lose_m[b][gp];
        end
      end

      // ---- reorder buffer ----
      logic [NSRC-1:0]    cv;
      logic [NSRC*SW-1:0] cs;
      logic [NSRC*DW-1:0] cd;
      logic [NSRC*3-1:0]  ce3;
      logic [NSRC-1:0]    cce;
      always_comb begin
        for (int b = 0; b < NUM_BANKS; b++) begin
          cv[b]          = bk_rsp_valid[b] && (bk_rsp_tag[b][SW +: PW] == PW'(gp));
          cs[b*SW +: SW] = bk_rsp_tag[b][SW-1:0];
          cd[b*DW +: DW] = bk_rsp_rdata[b];
          ce3[b*3 +: 3]  = bk_rsp_ue[b] ? RSP_ECC_UE : RSP_OK;
          cce[b]         = bk_rsp_ce[b];
        end
        cv[NUM_BANKS]                 = ex_cpl_valid && (ex_cpl_tag[SW +: PW] == PW'(gp));
        cs[NUM_BANKS*SW +: SW]        = ex_cpl_tag[SW-1:0];
        cd[NUM_BANKS*DW +: DW]        = ex_cpl_data;
        ce3[NUM_BANKS*3 +: 3]         = ex_cpl_err ? RSP_EXT : RSP_OK;
        cce[NUM_BANKS]                = 1'b0;
      end

      sf_iron_rob #(.DEPTH(MAX_OUT), .DW(DW), .NSRC(NSRC), .TS_W(TS_W)) u_rob (
        .clk, .rst_n, .now,
        .alloc(fire[gp]), .alloc_seq(rob_seq[gp]), .full(rob_full[gp]),
        .alloc_done(fin_err[gp] != RSP_OK), .alloc_err(fin_err[gp]),
        .cpl_valid(cv), .cpl_seq(cs), .cpl_data(cd), .cpl_err(ce3), .cpl_ce(cce),
        .rsp_valid(rob_rsp_valid[gp]), .rsp_ready(m_rsp_ready[gp]),
        .rsp_data(m_rsp_rdata[gp*DW +: DW]), .rsp_err(m_rsp_err[gp*3 +: 3]), .rsp_ce(m_rsp_ecc_corr[gp]),
        .lat_valid(rob_lat_valid[gp]), .lat_cycles(rob_lat[gp]), .count());
      assign m_rsp_valid[gp] = rob_rsp_valid[gp];
      assign rsp_fire[gp]    = rob_rsp_valid[gp] && m_rsp_ready[gp];
    end
  endgenerate

  // ===========================================================================
  // Buffer manager
  // ===========================================================================
  logic [NUM_BANKS-1:0]     dec_valid, dec_raw;
  logic [NUM_BANKS*IDW-1:0] dec_id;
  logic [IDW:0]             desc_in_use;
  logic [GCW-1:0]           gran_in_use;
  logic                     ev_alloc_ok, ev_alloc_nodesc, ev_alloc_nospace, ev_free;

  always_comb begin
    for (int b = 0; b < NUM_BANKS; b++) begin
      dec_valid[b]          = bk_rsp_valid[b] && bk_rsp_tag[b][TAG_W-2];
      dec_raw[b]            = bk_rsp_valid[b] && bk_rsp_tag[b][TAG_W-1];
      dec_id[b*IDW +: IDW]  = bk_rsp_tag[b][PW + SW +: IDW];
    end
  end

  sf_iron_buffer_manager #(.AW(AW), .NUM_PORTS(NUM_PORTS), .PORT_DOMAIN_MAP(PORT_DOMAIN_MAP),
    .NUM_DESC(NUM_DESC), .GRAN_BYTES(GRAN_BYTES), .SRAM_BASE(SRAM_BASE), .SRAM_BYTES(SRAM_BYTES),
    .NUM_DEC(NUM_BANKS), .INFL_W(INFL_W)) u_bm (
    .clk, .rst_n,
    .cmd_valid(bm_cmd_valid), .cmd_ready(bm_cmd_ready), .cmd_op(bm_cmd_op), .cmd_requester(bm_cmd_requester),
    .cmd_id(bm_cmd_id), .cmd_btype(bm_cmd_btype), .cmd_start(bm_cmd_start), .cmd_len(bm_cmd_len),
    .cmd_owner(bm_cmd_owner), .cmd_rd_mask(bm_cmd_rd_mask), .cmd_wr_mask(bm_cmd_wr_mask),
    .rsp_valid(bm_rsp_valid), .rsp_status(bm_rsp_status), .rsp_id(bm_rsp_id), .rsp_in_use(bm_rsp_in_use),
    .rsp_btype(bm_rsp_btype), .rsp_start(bm_rsp_start), .rsp_len(bm_rsp_len), .rsp_owner(bm_rsp_owner),
    .rsp_rd_mask(bm_rsp_rd_mask), .rsp_wr_mask(bm_rsp_wr_mask), .rsp_err_bits(bm_rsp_err_bits),
    .raw_en(csr_raw_en), .chk_lo(bm_chk_lo), .chk_hi(bm_chk_hi), .chk_we(bm_chk_we),
    .chk_hit(bm_chk_hit), .chk_raw(bm_chk_raw), .chk_allow(), .chk_err(bm_chk_err),
    .chk_id(bm_chk_id), .chk_fire(bm_chk_fire), .raw_block(bm_raw_block),
    .dec_valid(dec_valid), .dec_id(dec_id), .dec_ce(bk_rsp_ce), .dec_ue(bk_rsp_ue), .dec_raw(dec_raw),
    .desc_in_use(desc_in_use), .gran_in_use(gran_in_use),
    .ev_alloc_ok(ev_alloc_ok), .ev_alloc_nodesc(ev_alloc_nodesc), .ev_alloc_nospace(ev_alloc_nospace),
    .ev_free(ev_free), .ev_viol(bm_ev_viol));

  // ===========================================================================
  // Banks: arbiter + adapter
  // ===========================================================================
  logic [NUM_BANKS-1:0] bk_ready, bk_conflict, bk_ev_rd, bk_ev_wr, bk_ev_rmw, bk_ev_ce, bk_ev_ue;
  logic [NUM_BANKS-1:0] bk_ev_scrub, bk_ev_scrub_fix, bk_busy, bk_stall, bk_inj_pending;
  logic [LW-1:0]        bk_err_addr [NUM_BANKS];
  logic [R:0]           bk_syn      [NUM_BANKS];
  logic                 scrub_tick;

  generate
    for (gb = 0; gb < NUM_BANKS; gb++) begin : g_bank
      logic [NUM_PORTS-1:0] breq;
      logic [PW-1:0]        gidx;
      logic                 gv;
      always_comb
        for (int p = 0; p < NUM_PORTS; p++)
          breq[p] = slot_v[p] && (slot_region[p] == REGION_SRAM) && (slot_bank[p] == BW'(gb));

      sf_iron_bank_arbiter #(.N(NUM_PORTS)) u_arb (
        .clk, .rst_n, .req(breq), .urgent(urgent), .hipri(csr_hipri), .bank_ready(bk_ready[gb]),
        .gnt(gnt_m[gb]), .gnt_idx(gidx), .conflict(bk_conflict[gb]), .lose(lose_m[gb]));
      assign gv = |gnt_m[gb];

      logic rsp_we_unused;
      sf_iron_bank_adapter #(.DW(DW), .DEPTH(BANK_DEPTH), .RL(RL), .ECC_EN(ECC_EN), .BACKEND(BACKEND),
        .MACRO_WORDS(MACRO_WORDS), .MACRO_BITS(MACRO_BITS), .INIT_ON_RESET(INIT_ON_RESET),
        .SIM_POWERUP_RANDOM(SIM_POWERUP_RANDOM), .TAG_W(TAG_W), .SCRUB_MAX_DEFER(SCRUB_MAX_DEFER)) u_bank (
        .clk, .rst_n,
        .req_valid(gv), .req_ready(bk_ready[gb]), .req_we(slot_we[gidx]), .req_addr(slot_word[gidx]),
        .req_wdata(slot_wdata[gidx]), .req_be(slot_be[gidx]),
        .req_tag({slot_raw[gidx], slot_bufv[gidx], slot_bufid[gidx], gidx, slot_seq[gidx]}),
        .rsp_valid(bk_rsp_valid[gb]), .rsp_tag(bk_rsp_tag[gb]), .rsp_rdata(bk_rsp_rdata[gb]),
        .rsp_we(rsp_we_unused), .rsp_ce(bk_rsp_ce[gb]), .rsp_ue(bk_rsp_ue[gb]),
        .scrub_en(csr_scrub_en), .scrub_tick(scrub_tick),
        .inj_arm(inj_arm[gb]), .inj_mask(inj_mask), .inj_pending(bk_inj_pending[gb]),
        .init_done(bk_init_done[gb]),
        .ev_rd(bk_ev_rd[gb]), .ev_wr(bk_ev_wr[gb]), .ev_rmw(bk_ev_rmw[gb]), .ev_ce(bk_ev_ce[gb]),
        .ev_ue(bk_ev_ue[gb]), .ev_scrub(bk_ev_scrub[gb]), .ev_scrub_fix(bk_ev_scrub_fix[gb]),
        .ev_err_addr(bk_err_addr[gb]), .ev_syndrome(bk_syn[gb]),
        .port_busy(bk_busy[gb]), .stall_rmw(bk_stall[gb]));

      // trace of bank issue events
      assign trc_valid[gb]            = gv;
      assign trc_port[gb*PW +: PW]    = gidx;
      assign trc_seq[gb*SW +: SW]     = slot_seq[gidx];
      assign trc_we[gb]               = slot_we[gidx];
      assign trc_word[gb*LW +: LW]    = slot_word[gidx];
      assign trc_be[gb*NB +: NB]      = slot_be[gidx];
      assign trc_wdata[gb*DW +: DW]   = slot_wdata[gidx];
    end
  endgenerate

  assign init_done = &bk_init_done;

  // ===========================================================================
  // External memory
  // ===========================================================================
  logic [OCW-1:0] ex_outstanding;
  logic ex_ev_rd, ex_ev_wr, ex_ev_bp, ex_ev_err, ex_ev_proto, ex_lat_valid;
  logic [TS_W-1:0] ex_lat;

  generate
    if (EXT_EN != 0) begin : g_ext
      logic [NUM_PORTS-1:0]       pv, pwe;
      logic [NUM_PORTS*EWW-1:0]   pword;
      logic [NUM_PORTS*DW-1:0]    pwd;
      logic [NUM_PORTS*NB-1:0]    pbe;
      logic [NUM_PORTS*ETW-1:0]   ptag;
      always_comb
        for (int p = 0; p < NUM_PORTS; p++) begin
          pv[p]                = slot_v[p] && (slot_region[p] == REGION_EXT);
          pwe[p]               = slot_we[p];
          pword[p*EWW +: EWW]  = slot_eword[p];
          pwd[p*DW +: DW]      = slot_wdata[p];
          pbe[p*NB +: NB]      = slot_be[p];
          ptag[p*ETW +: ETW]   = {PW'(p), slot_seq[p]};
        end
      sf_iron_extmem_adapter #(.NUM_PORTS(NUM_PORTS), .DW(DW), .EWW(EWW), .TAG_W(ETW),
        .EXT_MAX_OUT(EXT_MAX_OUT), .TS_W(TS_W)) u_ext (
        .clk, .rst_n, .now,
        .p_valid(pv), .p_ready(ext_p_ready), .p_we(pwe), .p_word(pword), .p_wdata(pwd), .p_be(pbe), .p_tag(ptag),
        .cmd_valid(ext_cmd_valid), .cmd_ready(ext_cmd_ready), .cmd_we(ext_cmd_we), .cmd_addr(ext_cmd_addr),
        .cmd_wdata(ext_cmd_wdata), .cmd_wstrb(ext_cmd_wstrb), .cmd_tag(ext_cmd_tag),
        .rsp_valid(ext_rsp_valid), .rsp_ready(ext_rsp_ready), .rsp_rdata(ext_rsp_rdata),
        .rsp_err(ext_rsp_err), .rsp_tag(ext_rsp_tag),
        .cpl_valid(ex_cpl_valid), .cpl_tag(ex_cpl_tag), .cpl_data(ex_cpl_data), .cpl_err(ex_cpl_err),
        .outstanding(ex_outstanding), .ev_rd(ex_ev_rd), .ev_wr(ex_ev_wr), .ev_bp(ex_ev_bp),
        .ev_err(ex_ev_err), .ev_proto(ex_ev_proto), .lat_valid(ex_lat_valid), .lat_cycles(ex_lat));
    end else begin : g_noext
      assign ext_p_ready  = '0;
      assign ext_cmd_valid = 1'b0; assign ext_cmd_we = 1'b0; assign ext_cmd_addr = '0;
      assign ext_cmd_wdata = '0;   assign ext_cmd_wstrb = '0; assign ext_cmd_tag = '0;
      assign ext_rsp_ready = 1'b1;
      assign ex_cpl_valid = 1'b0; assign ex_cpl_tag = '0; assign ex_cpl_data = '0; assign ex_cpl_err = 1'b0;
      assign ex_outstanding = '0; assign ex_ev_rd = 1'b0; assign ex_ev_wr = 1'b0; assign ex_ev_bp = 1'b0;
      assign ex_ev_err = 1'b0; assign ex_ev_proto = (ext_rsp_valid); assign ex_lat_valid = 1'b0; assign ex_lat = '0;
    end
  endgenerate

  // ===========================================================================
  // Scrub timer
  // ===========================================================================
  logic [31:0] scrub_cnt;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) scrub_cnt <= '0;
    else if (!csr_scrub_en) scrub_cnt <= '0;
    else if (scrub_cnt + 1 >= csr_scrub_interval) scrub_cnt <= '0;
    else scrub_cnt <= scrub_cnt + 1'b1;
  end
  assign scrub_tick = csr_scrub_en && (scrub_cnt + 1 >= csr_scrub_interval);

  // ===========================================================================
  // Status, error logs
  // ===========================================================================
  logic st_ue, st_ce, st_perm, st_ext_err, st_ext_proto;
  logic ce_log_v, ue_log_v;
  logic [3:0]  ce_log_bank, ue_log_bank;
  logic [LW-1:0] ce_log_word, ue_log_word;
  logic [R:0]  ce_log_syn, ue_log_syn;
  logic [5:1]  st_clr;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st_ue <= 0; st_ce <= 0; st_perm <= 0; st_ext_err <= 0; st_ext_proto <= 0;
      ce_log_v <= 0; ue_log_v <= 0; ce_log_bank <= 0; ue_log_bank <= 0;
      ce_log_word <= 0; ue_log_word <= 0; ce_log_syn <= 0; ue_log_syn <= 0;
    end else begin
      // STATUS_CLR (0x024) is write-1-to-clear with the same bit positions as STATUS
      if (|bk_ev_ue)       st_ue <= 1'b1;        else if (st_clr[1]) st_ue <= 1'b0;
      if (|bm_ev_viol)     st_perm <= 1'b1;      else if (st_clr[2]) st_perm <= 1'b0;
      if (ex_ev_err)       st_ext_err <= 1'b1;   else if (st_clr[3]) st_ext_err <= 1'b0;
      if (ex_ev_proto)     st_ext_proto <= 1'b1; else if (st_clr[4]) st_ext_proto <= 1'b0;
      if (|bk_ev_ce)       st_ce <= 1'b1;        else if (st_clr[5]) st_ce <= 1'b0;
      for (int b = NUM_BANKS - 1; b >= 0; b--) begin
        if (bk_ev_ce[b]) begin ce_log_v <= 1; ce_log_bank <= 4'(b); ce_log_word <= bk_err_addr[b]; ce_log_syn <= bk_syn[b]; end
        if (bk_ev_ue[b]) begin ue_log_v <= 1; ue_log_bank <= 4'(b); ue_log_word <= bk_err_addr[b]; ue_log_syn <= bk_syn[b]; end
      end
    end
  end
  assign irq = (st_ue && csr_irq_ue) || (st_perm && csr_irq_perm) || ((st_ext_err || st_ext_proto) && csr_irq_ext);

  // ===========================================================================
  // Performance counters (32-bit, saturating -- never silently wrap)
  // ===========================================================================
  localparam int NBC = 8, NPC = 16, NGC = 32;
  logic [31:0] cnt_bank [NUM_BANKS][NBC];
  logic [31:0] cnt_port [NUM_PORTS][NPC];
  logic [31:0] cnt_glob [NGC];

  function automatic logic [31:0] sat_add(input logic [31:0] a, input longint inc);
    longint s;
    s = longint'(a) + inc;
    return (s > 64'hFFFF_FFFF) ? 32'hFFFF_FFFF : s[31:0];
  endfunction
  function automatic logic [31:0] umax(input logic [31:0] a, input logic [31:0] b);
    return (b > a) ? b : a;
  endfunction

  int n_viol, n_scrub, n_scrub_fix, n_scrub_ue;
  always_comb begin
    n_viol = 0; n_scrub = 0; n_scrub_fix = 0; n_scrub_ue = 0;
    for (int p = 0; p < NUM_PORTS; p++) n_viol = n_viol + int'(bm_ev_viol[p]);
    for (int b = 0; b < NUM_BANKS; b++) begin
      n_scrub     = n_scrub + int'(bk_ev_scrub[b]);
      n_scrub_fix = n_scrub_fix + int'(bk_ev_scrub_fix[b]);
      n_scrub_ue  = n_scrub_ue + int'(bk_ev_scrub[b] && bk_ev_ue[b]);
    end
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      for (int b = 0; b < NUM_BANKS; b++) for (int i = 0; i < NBC; i++) cnt_bank[b][i] <= '0;
      for (int p = 0; p < NUM_PORTS; p++) for (int i = 0; i < NPC; i++) cnt_port[p][i] <= '0;
      for (int i = 0; i < NGC; i++) cnt_glob[i] <= '0;
    end else if (cnt_clear) begin
      for (int b = 0; b < NUM_BANKS; b++) for (int i = 0; i < NBC; i++) cnt_bank[b][i] <= '0;
      for (int p = 0; p < NUM_PORTS; p++) for (int i = 0; i < NPC; i++) cnt_port[p][i] <= '0;
      for (int i = 0; i < NGC; i++) cnt_glob[i] <= '0;
    end else if (!csr_freeze) begin
      for (int b = 0; b < NUM_BANKS; b++) begin
        cnt_bank[b][0] <= sat_add(cnt_bank[b][0], longint'(bk_ev_rd[b]));
        cnt_bank[b][1] <= sat_add(cnt_bank[b][1], longint'(bk_ev_wr[b]));
        cnt_bank[b][2] <= sat_add(cnt_bank[b][2], longint'(bk_busy[b] && init_done));
        cnt_bank[b][3] <= sat_add(cnt_bank[b][3], longint'(bk_conflict[b]));
        cnt_bank[b][4] <= sat_add(cnt_bank[b][4], longint'(bk_ev_rmw[b]));
        cnt_bank[b][5] <= sat_add(cnt_bank[b][5], longint'(bk_stall[b] && init_done));
        cnt_bank[b][6] <= sat_add(cnt_bank[b][6], longint'(bk_ev_ce[b]));
        cnt_bank[b][7] <= sat_add(cnt_bank[b][7], longint'(bk_ev_ue[b]));
      end
      for (int p = 0; p < NUM_PORTS; p++) begin
        cnt_port[p][0]  <= sat_add(cnt_port[p][0],  longint'(fire[p]));
        cnt_port[p][1]  <= sat_add(cnt_port[p][1],  longint'(legal_fire[p] && !m_req_we[p]));
        cnt_port[p][2]  <= sat_add(cnt_port[p][2],  longint'(legal_fire[p] &&  m_req_we[p]));
        cnt_port[p][3]  <= sat_add(cnt_port[p][3],  (legal_fire[p] && !m_req_we[p]) ? longint'(mp_nb[p]) : 0);
        cnt_port[p][4]  <= sat_add(cnt_port[p][4],  (legal_fire[p] &&  m_req_we[p]) ? longint'(mp_nb[p]) : 0);
        cnt_port[p][5]  <= sat_add(cnt_port[p][5],  longint'(m_req_valid[p] && !m_req_ready[p] && init_done));
        cnt_port[p][6]  <= sat_add(cnt_port[p][6],  longint'(slot_v[p] && !slot_fire[p]));
        cnt_port[p][7]  <= sat_add(cnt_port[p][7],  longint'(port_lost[p]));
        cnt_port[p][8]  <= sat_add(cnt_port[p][8],  longint'(starve_evt[p]));
        cnt_port[p][9]  <= umax(cnt_port[p][9], 32'(wait_cnt[p]));
        cnt_port[p][10] <= sat_add(cnt_port[p][10], rob_lat_valid[p] ? longint'(rob_lat[p]) : 0);
        cnt_port[p][11] <= sat_add(cnt_port[p][11], longint'(rob_lat_valid[p]));
        cnt_port[p][12] <= rob_lat_valid[p] ? umax(cnt_port[p][12], rob_lat[p]) : cnt_port[p][12];
        cnt_port[p][13] <= sat_add(cnt_port[p][13], longint'(rsp_fire[p] && (m_rsp_err[p*3 +: 3] != RSP_OK)));
        cnt_port[p][14] <= sat_add(cnt_port[p][14], longint'(rob_rsp_valid[p] && !m_rsp_ready[p]));
        cnt_port[p][15] <= sat_add(cnt_port[p][15], longint'(legal_fire[p] && (mp_region[p] == REGION_EXT)));
      end
      cnt_glob[0]  <= sat_add(cnt_glob[0], longint'(init_done));
      cnt_glob[3]  <= umax(cnt_glob[3], 32'(gran_in_use));
      cnt_glob[4]  <= sat_add(cnt_glob[4], longint'(ev_alloc_ok));
      cnt_glob[5]  <= sat_add(cnt_glob[5], longint'(ev_alloc_nodesc));
      cnt_glob[6]  <= sat_add(cnt_glob[6], longint'(ev_alloc_nospace));
      cnt_glob[7]  <= sat_add(cnt_glob[7], longint'(ev_free));
      cnt_glob[8]  <= sat_add(cnt_glob[8], longint'(ex_ev_rd));
      cnt_glob[9]  <= sat_add(cnt_glob[9], longint'(ex_ev_wr));
      cnt_glob[10] <= sat_add(cnt_glob[10], longint'(ex_ev_bp));
      cnt_glob[11] <= sat_add(cnt_glob[11], ex_lat_valid ? longint'(ex_lat) : 0);
      cnt_glob[12] <= sat_add(cnt_glob[12], longint'(ex_lat_valid));
      cnt_glob[13] <= sat_add(cnt_glob[13], longint'(ex_ev_err));
      cnt_glob[14] <= sat_add(cnt_glob[14], longint'(n_scrub));
      cnt_glob[15] <= sat_add(cnt_glob[15], longint'(n_scrub_fix));
      cnt_glob[16] <= sat_add(cnt_glob[16], longint'(n_viol));
      cnt_glob[17] <= sat_add(cnt_glob[17], longint'(n_scrub_ue));
      cnt_glob[18] <= sat_add(cnt_glob[18], longint'(ex_ev_proto));
    end
  end

  // ===========================================================================
  // CSR block
  // ===========================================================================
  localparam logic [31:0] IRON_ID = 32'h5346_0084;   // "SF", project 84

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      csr_raw_en <= 1'b1; csr_scrub_en <= 1'b0; csr_irq_ue <= 1'b0; csr_irq_perm <= 1'b0;
      csr_irq_ext <= 1'b0; csr_freeze <= 1'b0; csr_scrub_interval <= 32'd1024; csr_hipri <= '0;
      csr_ext_rd <= ND'(1); csr_ext_wr <= ND'(1);   // Keystone only after reset
      csr_inj_bits <= '0;
      csr_rvalid <= 1'b0; csr_rdata <= '0; csr_err <= 1'b0;
    end else begin
      csr_rvalid <= csr_valid;
      csr_err    <= 1'b0;
      csr_rdata  <= '0;
      if (csr_valid && csr_we) begin
        case (csr_addr)
          12'h00C: begin
            csr_raw_en <= csr_wdata[0]; csr_scrub_en <= csr_wdata[1]; csr_irq_ue <= csr_wdata[2];
            csr_irq_perm <= csr_wdata[3]; csr_irq_ext <= csr_wdata[4]; csr_freeze <= csr_wdata[5];
          end
          12'h010: csr_scrub_interval <= (csr_wdata == 0) ? 32'd1 : csr_wdata;
          12'h014: csr_hipri <= csr_wdata[NUM_PORTS-1:0];
          12'h018: begin csr_ext_rd <= csr_wdata[ND-1:0]; csr_ext_wr <= csr_wdata[8 +: ND]; end
          12'h01C: csr_inj_bits <= csr_wdata;
          12'h020, 12'h024, 12'h038: ;   // pulse registers (decoded combinationally)
          default: csr_err <= 1'b1;
        endcase
      end else if (csr_valid) begin
        csr_rdata <= csr_read(csr_addr);
        csr_err   <= !csr_addr_ok(csr_addr);
      end
    end
  end

  // write-pulse decode
  always_comb begin
    inj_arm   = '0;
    st_clr    = '0;
    cnt_clear = 1'b0;
    for (int b = 0; b < NUM_BANKS; b++)
      inj_arm[b] = csr_valid && csr_we && (csr_addr == 12'h020) && csr_wdata[31] && (int'(csr_wdata[3:0]) == b);
    if (csr_valid && csr_we && (csr_addr == 12'h024)) st_clr = csr_wdata[5:1];
    if (csr_valid && csr_we && (csr_addr == 12'h038)) cnt_clear = csr_wdata[0];
    inj_mask = '0;
    for (int i = 0; i < CW; i++) begin
      if (csr_inj_bits[15] && int'(csr_inj_bits[8:0])   == i) inj_mask[i] = 1'b1;
      if (csr_inj_bits[31] && int'(csr_inj_bits[24:16]) == i) inj_mask[i] = 1'b1;
    end
  end

  function automatic logic csr_addr_ok(input logic [11:0] a);
    if (a <= 12'h03C && a[1:0] == 2'b00) return 1'b1;
    if (a >= 12'h100 && a < 12'h100 + 12'(NUM_BANKS * NBC * 4) && a[1:0] == 2'b00) return 1'b1;
    if (a >= 12'h200 && a < 12'h200 + 12'(NUM_PORTS * NPC * 4) && a[1:0] == 2'b00) return 1'b1;
    if (a >= 12'h400 && a < 12'h400 + 12'(NGC * 4) && a[1:0] == 2'b00) return 1'b1;
    return 1'b0;
  endfunction

  function automatic logic [31:0] csr_read(input logic [11:0] a);
    logic [31:0] v;
    int idx;
    v = '0;
    case (a)
      12'h000: v = IRON_ID;
      12'h004: v = {3'b0, INTERLEAVE[0], 4'(NUM_PORTS), 2'(BACKEND), EXT_EN[0], ECC_EN[0], 4'(RL), 8'(NB), 8'(NUM_BANKS)};
      12'h008: v = {16'(gran_in_use), 8'(desc_in_use), 1'b0, bm_raw_block, st_ce, st_ext_proto, st_ext_err, st_perm, st_ue, init_done};
      12'h00C: v = {26'b0, csr_freeze, csr_irq_ext, csr_irq_perm, csr_irq_ue, csr_scrub_en, csr_raw_en};
      12'h010: v = csr_scrub_interval;
      12'h014: v = 32'(csr_hipri);
      12'h018: v = {19'b0, csr_ext_wr, 3'b0, csr_ext_rd};
      12'h01C: v = csr_inj_bits;
      12'h020: v = 32'(bk_inj_pending);
      12'h028: v = {ce_log_v, 3'b0, ce_log_bank, 24'(ce_log_word)};
      12'h02C: v = 32'(ce_log_syn);
      12'h030: v = {ue_log_v, 3'b0, ue_log_bank, 24'(ue_log_word)};
      12'h034: v = 32'(ue_log_syn);
      12'h03C: v = 32'(ex_outstanding);
      default: begin
        if (a >= 12'h100 && a < 12'h200) begin
          idx = (int'(a) - 'h100) >> 2;
          if (idx < NUM_BANKS * NBC) v = cnt_bank[idx / NBC][idx % NBC];
        end else if (a >= 12'h200 && a < 12'h400) begin
          idx = (int'(a) - 'h200) >> 2;
          if (idx < NUM_PORTS * NPC) v = cnt_port[idx / NPC][idx % NPC];
        end else if (a >= 12'h400 && a < 12'h480) begin
          idx = (int'(a) - 'h400) >> 2;
          case (idx)
            1:       v = 32'(desc_in_use);
            2:       v = 32'(gran_in_use);
            default: v = cnt_glob[idx];
          endcase
        end
      end
    endcase
    return v;
  endfunction

`ifndef SYNTHESIS
  // single-port discipline: at most one grant per bank per cycle (also
  // asserted in each arbiter); a port is granted by at most one bank
  always_ff @(posedge clk) if (rst_n) begin
    for (int p = 0; p < NUM_PORTS; p++) begin
      int ng; ng = 0;
      for (int b = 0; b < NUM_BANKS; b++) ng = ng + int'(gnt_m[b][p]);
      assert (ng <= 1) else $error("sf_iron_memory: port %0d granted by %0d banks", p, ng);
    end
  end
`endif
endmodule
