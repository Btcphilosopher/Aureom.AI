// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_memory_map.sv : logical byte address -> region / bank / word / byte
//
// Pure combinational decoder, one instance per master port.
//
//   SRAM shared window : [SRAM_BASE, SRAM_BASE + NUM_BANKS*BANK_DEPTH*DW/8)
//   External window    : [EXT_BASE,  EXT_BASE  + EXT_BYTES)      (EXT_EN=1)
//
// Anti-aliasing: every address bit takes part in the window compare (full
// AW-bit magnitude compare, no partial decode). An address one byte past a
// window, or one that differs only in "unused" upper bits, is RSP_DECODE.
// Each in-window byte address therefore maps to exactly one
// (bank, word, byte) triple and vice versa (checked by tb_memory_map).
//
// Access sizes: size = log2(bytes) (0..log2(DW/8)). Accesses must be naturally
// aligned. Writes additionally take a byte-lane strobe; the effective byte
// enable is size_mask & wstrb and must be non-zero.
//
// Bank mapping:
//   INTERLEAVE=1 : bank = word % NUM_BANKS, bank_word = word / NUM_BANKS
//                  (sequential streams rotate through all banks)
//   INTERLEAVE=0 : bank = word / BANK_DEPTH, bank_word = word % BANK_DEPTH
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_memory_map #(
  parameter int              AW         = 32,
  parameter int              DW         = 64,
  parameter int              NUM_BANKS  = 4,
  parameter int              BANK_DEPTH = 1024,
  parameter int              INTERLEAVE = 1,
  parameter logic [AW-1:0]   SRAM_BASE  = AW'('h1000_0000),
  parameter int              EXT_EN     = 1,
  parameter logic [AW-1:0]   EXT_BASE   = AW'('h8000_0000),
  parameter longint          EXT_BYTES  = 64'd1048576,
  // derived (do not override)
  parameter int NB  = DW / 8,
  parameter int BW  = sf_iron_pkg::clog2_min1(NUM_BANKS),
  parameter int LW  = sf_iron_pkg::clog2_min1(BANK_DEPTH),
  parameter int OW  = sf_iron_pkg::clog2_min1(NB),
  parameter int EWW = sf_iron_pkg::clog2_min1(int'(EXT_BYTES / longint'(NB)))
) (
  input  logic [AW-1:0]  addr,
  input  logic [2:0]     size,
  input  logic           we,
  input  logic [NB-1:0]  wstrb,
  output logic [1:0]     region,
  output logic [BW-1:0]  bank,
  output logic [LW-1:0]  bank_word,
  output logic [OW-1:0]  byte_off,
  output logic [EWW-1:0] ext_word,
  output logic [NB-1:0]  be,
  output logic [AW-1:0]  lo_addr,     // first byte touched
  output logic [AW-1:0]  hi_addr,     // last byte touched
  output logic [OW:0]    nbytes,      // bytes touched
  output logic [2:0]     err
);
  import sf_iron_pkg::*;

  localparam longint SRAM_BYTES = longint'(NUM_BANKS) * longint'(BANK_DEPTH) * longint'(NB);
  localparam int     LOG_NB     = $clog2(NB);
  localparam int     LOG_BANKS  = $clog2(NUM_BANKS);
  localparam int     LOG_DEPTH  = $clog2(BANK_DEPTH);
  localparam int     WORD_W     = AW - LOG_NB;

  localparam logic [AW:0] SRAM_LO = (AW+1)'(SRAM_BASE);
  localparam logic [AW:0] SRAM_HI = (AW+1)'(SRAM_BASE) + (AW+1)'(SRAM_BYTES);  // exclusive
  localparam logic [AW:0] EXT_LO  = (AW+1)'(EXT_BASE);
  localparam logic [AW:0] EXT_HI  = (AW+1)'(EXT_BASE) + (AW+1)'(EXT_BYTES);    // exclusive

  // ---------------------------------------------------------------------------
  // Elaboration-time configuration checks
  // ---------------------------------------------------------------------------
  initial begin
    if (AW > 63) $fatal(1, "memory_map: AW must be <= 63");
    if (is_pow2(NB) == 0 || NB < 1) $fatal(1, "memory_map: DW/8 must be a power of two");
    if (INTERLEAVE != 0 && is_pow2(NUM_BANKS) == 0) $fatal(1, "memory_map: interleaving needs a power-of-two bank count");
    if (INTERLEAVE == 0 && is_pow2(BANK_DEPTH) == 0) $fatal(1, "memory_map: contiguous banking needs a power-of-two bank depth");
    if ((longint'(SRAM_BASE) % longint'(NB)) != 64'd0) $fatal(1, "memory_map: SRAM_BASE must be word aligned");
    if ((longint'(SRAM_BASE) + SRAM_BYTES) > (64'd1 << AW)) $fatal(1, "memory_map: SRAM window exceeds address space");
    if (EXT_EN != 0) begin
      if ((longint'(EXT_BASE) % longint'(NB)) != 0) $fatal(1, "memory_map: EXT_BASE must be word aligned");
      if ((EXT_BYTES % longint'(NB)) != 64'd0 || EXT_BYTES <= 0) $fatal(1, "memory_map: EXT_BYTES must be a positive multiple of the word size");
      if ((longint'(EXT_BASE) + EXT_BYTES) > (64'd1 << AW)) $fatal(1, "memory_map: EXT window exceeds address space");
      if ((longint'(SRAM_BASE) < longint'(EXT_BASE) + EXT_BYTES) &&
          (longint'(EXT_BASE)  < longint'(SRAM_BASE) + SRAM_BYTES))
        $fatal(1, "memory_map: SRAM and EXT windows overlap (would alias)");
    end
  end

  logic [AW:0]     a_ext;
  logic            in_sram, in_ext;
  /* verilator lint_off UNUSEDSIGNAL */  // low byte-offset bits are carried separately
  logic [AW-1:0]   off_sram, off_ext;
  /* verilator lint_on UNUSEDSIGNAL */
  logic [WORD_W-1:0] word_sram;
  logic [NB-1:0]   size_mask;
  logic            size_bad, misaligned, strobe_empty;
  int              nbytes_i;

  always_comb begin
    a_ext   = {1'b0, addr};
    in_sram = (a_ext >= SRAM_LO) && (a_ext < SRAM_HI);
    in_ext  = (EXT_EN != 0) && (a_ext >= EXT_LO) && (a_ext < EXT_HI);

    off_sram  = addr - SRAM_BASE;
    off_ext   = addr - EXT_BASE;
    word_sram = off_sram[AW-1:LOG_NB];

    if (INTERLEAVE != 0) begin
      bank      = (NUM_BANKS > 1) ? BW'(word_sram) : '0;          // low word bits
      bank_word = LW'(word_sram >> LOG_BANKS);
    end else begin
      bank      = (NUM_BANKS > 1) ? BW'(word_sram >> LOG_DEPTH) : '0;
      bank_word = LW'(word_sram);
    end
    byte_off = OW'(addr);
    ext_word = EWW'(off_ext[AW-1:LOG_NB]);

    // size / alignment
    size_bad   = (int'(size) > LOG_NB);
    misaligned = !size_bad && ((int'(addr[OW-1:0]) & ((1 << int'(size)) - 1)) != 0);
    for (int i = 0; i < NB; i++)
      size_mask[i] = !size_bad && (i >= int'(byte_off)) && (i < int'(byte_off) + (1 << int'(size)));
    be           = we ? (size_mask & wstrb) : size_mask;
    strobe_empty = we && (be == '0);

    // touched byte range and count
    lo_addr  = {addr[AW-1:LOG_NB], {LOG_NB{1'b0}}};
    hi_addr  = {addr[AW-1:LOG_NB], {LOG_NB{1'b0}}};
    nbytes_i = 0;
    for (int i = NB - 1; i >= 0; i--) if (be[i]) lo_addr = {addr[AW-1:LOG_NB], LOG_NB'(i)};
    for (int i = 0; i < NB; i++)      if (be[i]) hi_addr = {addr[AW-1:LOG_NB], LOG_NB'(i)};
    for (int i = 0; i < NB; i++)      nbytes_i = nbytes_i + int'(be[i]);
    nbytes = (OW+1)'(nbytes_i);

    // region + error priority: decode > align
    if (in_sram)      region = REGION_SRAM;
    else if (in_ext)  region = REGION_EXT;
    else              region = REGION_NONE;

    if (region == REGION_NONE)                       err = RSP_DECODE;
    else if (size_bad || misaligned || strobe_empty) err = RSP_ALIGN;
    else                                             err = RSP_OK;
  end
endmodule
