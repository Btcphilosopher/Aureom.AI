// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_sram_asic.sv : qualified-ASIC SRAM macro tiling wrapper
//
// Builds one logical W x DEPTH single-port bank from compiler macros of
// MACRO_BITS x MACRO_WORDS. Macro pins follow the common compiler-SRAM
// convention (active-low CEN / GWEN / per-bit WEN, registered Q, 1-cycle read).
//
// Macro selection:
//   * default                 -> sf_iron_sram_macro_stub (behavioural stand-in)
//   * `define SF_IRON_VENDOR_MACRO <cell_name>
//                             -> instantiates the vendor cell by name. Its
//                                port names must match the stub (adapt with a
//                                thin shim if the vendor uses other names).
//
// Area / timing: the stub carries NO physical data. Real dimensions come from
// the vendor's LEF/Liberty (see tools/sram_area_report.py), never from here.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_sram_asic #(
  parameter int W           = 72,
  parameter int DEPTH       = 1024,
  parameter int RL          = 1,       // 1: macro Q direct, 2: + output flop
  parameter int NUNITS      = 1,
  parameter int MACRO_WORDS = 256,
  parameter int MACRO_BITS  = 72,
  parameter int AWL         = sf_iron_pkg::clog2_min1(DEPTH)
) (
  input  logic              clk,
  input  logic              en,
  input  logic              we,
  input  logic [AWL-1:0]    addr,
  input  logic [W-1:0]      wdata,
  input  logic [NUNITS-1:0] wunit,
  output logic [W-1:0]      rdata
);
  localparam int UW   = W / NUNITS;
  localparam int TW   = (W + MACRO_BITS - 1) / MACRO_BITS;         // column tiles
  localparam int TD   = (DEPTH + MACRO_WORDS - 1) / MACRO_WORDS;    // row tiles
  localparam int MAW  = sf_iron_pkg::clog2_min1(MACRO_WORDS);
  localparam int TDW  = sf_iron_pkg::clog2_min1(TD);
  localparam int WPAD = TW * MACRO_BITS;

  initial begin
    if (RL != 1 && RL != 2) $fatal(1, "sf_iron_sram_asic: RL must be 1 or 2");
    if (sf_iron_pkg::is_pow2(MACRO_WORDS) == 0) $fatal(1, "sf_iron_sram_asic: MACRO_WORDS must be a power of two");
    if ((W % NUNITS) != 0) $fatal(1, "sf_iron_sram_asic: W must divide into NUNITS");
  end

  // expand unit enables to a bit mask, pad to the tiled width
  logic [WPAD-1:0] bitmask, wdata_pad;
  always_comb begin
    bitmask   = '0;
    wdata_pad = '0;
    wdata_pad[W-1:0] = wdata;
    for (int u = 0; u < NUNITS; u++) bitmask[u*UW +: UW] = {UW{wunit[u]}};
  end

  logic [TDW-1:0] row_sel;
  logic [MAW-1:0] row_addr;
  generate
    if (TD > 1) begin : g_rows
      assign row_sel  = TDW'(addr >> MAW);
      assign row_addr = addr[MAW-1:0];
    end else begin : g_onerow
      assign row_sel  = '0;
      assign row_addr = MAW'(addr);
    end
  endgenerate

  logic [WPAD-1:0] q_row [TD];
  logic [TDW-1:0]  row_sel_q;
  initial row_sel_q = '0;
  always_ff @(posedge clk) if (en && !we) row_sel_q <= row_sel;

  genvar r, c;
  generate
    for (r = 0; r < TD; r++) begin : g_r
      for (c = 0; c < TW; c++) begin : g_c
        logic cen_n, gwen_n;
        logic [MACRO_BITS-1:0] wen_n, q;
        assign cen_n  = !(en && (row_sel == TDW'(r)));
        assign gwen_n = !we;
        assign wen_n  = ~bitmask[c*MACRO_BITS +: MACRO_BITS];
`ifdef SF_IRON_VENDOR_MACRO
        `SF_IRON_VENDOR_MACRO u_macro (
`else
        sf_iron_sram_macro_stub #(.WORDS(MACRO_WORDS), .BITS(MACRO_BITS)) u_macro (
`endif
          .CLK (clk), .CEN (cen_n), .GWEN(gwen_n), .WEN(wen_n),
          .A   (row_addr), .D(wdata_pad[c*MACRO_BITS +: MACRO_BITS]), .Q(q));
        assign q_row[r][c*MACRO_BITS +: MACRO_BITS] = q;
      end
    end
  endgenerate

  logic [W-1:0] rd_mux;
  assign rd_mux = q_row[row_sel_q][W-1:0];

  generate
    if (RL == 2) begin : g_oreg
      logic [W-1:0] q_q;
      initial q_q = '0;
      always_ff @(posedge clk) q_q <= rd_mux;
      assign rdata = q_q;
    end else begin : g_noreg
      assign rdata = rd_mux;
    end
  endgenerate
endmodule

// -----------------------------------------------------------------------------
// Behavioural stand-in for a compiler single-port SRAM macro.
// Clearly NOT a real macro: no timing, no area, no power, no redundancy.
// Q updates only on read cycles (CEN=0, GWEN=1), otherwise holds.
// -----------------------------------------------------------------------------
module sf_iron_sram_macro_stub #(
  parameter int WORDS = 256,
  parameter int BITS  = 72,
  parameter int AW    = sf_iron_pkg::clog2_min1(WORDS)
) (
  input  logic            CLK,
  input  logic            CEN,
  input  logic            GWEN,
  input  logic [BITS-1:0] WEN,
  input  logic [AW-1:0]   A,
  input  logic [BITS-1:0] D,
  output logic [BITS-1:0] Q
);
  logic [BITS-1:0] mem [WORDS];
  initial begin
    for (int i = 0; i < WORDS; i++) mem[i] = '0;
    Q = '0;
  end
  always_ff @(posedge CLK) begin
    if (!CEN) begin
      if (!GWEN) begin
        for (int b = 0; b < BITS; b++) if (!WEN[b]) mem[A][b] <= D[b];
      end else begin
        Q <= mem[A];
      end
    end
  end
endmodule
