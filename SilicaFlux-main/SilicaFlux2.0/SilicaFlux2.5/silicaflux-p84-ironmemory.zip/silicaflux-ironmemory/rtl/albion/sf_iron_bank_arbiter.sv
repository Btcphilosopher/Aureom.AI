// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_bank_arbiter.sv : per-bank request arbiter (one instance per bank)
//
// Grants at most ONE requester per cycle, and only when the bank is ready:
// a single-port macro never sees two transactions in the same cycle.
//
// Priority classes (highest first), round-robin inside the winning class:
//   1. urgent : requester has waited >= STARVE_LIMIT cycles (anti-starvation)
//   2. hipri  : CSR-selected high-priority ports
//   3. normal
// The round-robin pointer advances past the winner, so every requester in a
// class is served within N grants of that class.
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_bank_arbiter #(
  parameter int N  = 5,
  parameter int PW = sf_iron_pkg::clog2_min1(N)
) (
  input  logic         clk,
  input  logic         rst_n,
  input  logic [N-1:0] req,
  input  logic [N-1:0] urgent,
  input  logic [N-1:0] hipri,
  input  logic         bank_ready,
  output logic [N-1:0] gnt,
  output logic [PW-1:0] gnt_idx,
  output logic         conflict,   // >= 2 requesters this cycle
  output logic [N-1:0] lose        // requested, another requester won
);
  logic [PW-1:0] ptr;
  logic [N-1:0]  cand;
  logic          found;
  int            nreq;

  always_comb begin
    if (|(req & urgent))     cand = req & urgent;
    else if (|(req & hipri)) cand = req & hipri;
    else                     cand = req;

    found   = 1'b0;
    gnt_idx = '0;
    for (int i = 0; i < N; i++) begin
      int idx;
      idx = int'(ptr) + i;
      if (idx >= N) idx = idx - N;
      if (!found && cand[idx]) begin
        found   = 1'b1;
        gnt_idx = PW'(idx);
      end
    end
    gnt = '0;
    if (found && bank_ready) gnt[gnt_idx] = 1'b1;

    nreq = 0;
    for (int i = 0; i < N; i++) nreq = nreq + int'(req[i]);
    conflict = (nreq >= 2);
    lose     = (|gnt) ? (req & ~gnt) : '0;
  end

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n)       ptr <= '0;
    else if (|gnt)    ptr <= (int'(gnt_idx) == N - 1) ? '0 : gnt_idx + 1'b1;
  end

`ifndef SYNTHESIS
  always_ff @(posedge clk) if (rst_n) begin
    assert ($onehot0(gnt)) else $error("bank_arbiter: more than one grant in a cycle");
    assert ((gnt & ~req) == '0) else $error("bank_arbiter: grant without request");
  end
`endif
endmodule
