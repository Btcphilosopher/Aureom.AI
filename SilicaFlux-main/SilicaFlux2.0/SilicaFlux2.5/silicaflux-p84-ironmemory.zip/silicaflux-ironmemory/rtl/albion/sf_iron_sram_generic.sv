// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// sf_iron_sram_generic.sv : generic single-port synchronous SRAM (behavioural)
//
// Technology-neutral reference backend. ONE access per cycle (read OR write).
//   * write: en & we   -> units with wunit[u]=1 updated at the clock edge
//   * read : en & !we  -> rdata valid RL cycles later (RL >= 1)
//   * rdata holds its last value on cycles without a read.
// This model has NO physical meaning for area, power or timing. Never derive
// silicon area from it (see docs/iron_memory/technology_portability.md).
// =============================================================================
`timescale 1ns/1ps
`include "sf_iron_pkg.sv"

module sf_iron_sram_generic #(
  parameter int W      = 72,
  parameter int DEPTH  = 1024,
  parameter int RL     = 1,
  parameter int NUNITS = 1,                 // independent write units (byte lanes)
  parameter int SIM_POWERUP_RANDOM = 0,     // 1: fill with random data at t=0
  parameter int AWL    = sf_iron_pkg::clog2_min1(DEPTH)
) (
  input  logic              clk,
  input  logic              en,
  input  logic              we,
  input  logic [AWL-1:0]    addr,
  input  logic [W-1:0]      wdata,
  input  logic [NUNITS-1:0] wunit,
  output logic [W-1:0]      rdata
);
  localparam int UW = W / NUNITS;

  logic [W-1:0] mem [DEPTH];
  logic [W-1:0] pipe [RL];

`ifndef SYNTHESIS
  // simulation-only: parameter checks and power-up contents
  initial begin
    if (RL < 1) $fatal(1, "sf_iron_sram_generic: RL must be >= 1");
    if ((W % NUNITS) != 0) $fatal(1, "sf_iron_sram_generic: W must divide into NUNITS");
    for (int i = 0; i < DEPTH; i++) begin
      logic [W-1:0] v;
      v = '0;
      if (SIM_POWERUP_RANDOM != 0) begin
        for (int b = 0; b < W; b += 32) v = (v << 32) | W'($urandom);
      end
      mem[i] = v;
    end
    for (int i = 0; i < RL; i++) pipe[i] = '0;
  end
`endif

  always_ff @(posedge clk) begin
    if (en && we) begin
      for (int u = 0; u < NUNITS; u++) begin
        if (wunit[u]) mem[addr][u*UW +: UW] <= wdata[u*UW +: UW];
      end
    end
    if (en && !we) pipe[0] <= mem[addr];
    for (int i = 1; i < RL; i++) pipe[i] <= pipe[i-1];
  end

  assign rdata = pipe[RL-1];
endmodule
