#!/bin/bash
# Generic synthesizability check for IronMemory (no technology library).
#   SystemVerilog --sv2v--> Verilog --Yosys--> generic gates
# Reports structural problems, latches and generic cell counts.
# Generic cell counts are NOT area: physical area needs a real standard-cell
# and SRAM-macro library (see tools/sram_area_report.py).
# Requires: sv2v (https://github.com/zachjs/sv2v), yosys >= 0.33
set -euo pipefail
ROOT=$(cd "$(dirname "$0")/.." && pwd)
OUT=${OUT:-$ROOT/build/syn}
mkdir -p "$OUT"
FILES="sf_iron_pkg.sv sf_iron_secded.sv sf_iron_sram_generic.sv sf_iron_sram_fpga.sv sf_iron_sram_asic.sv \
       sf_iron_bank_adapter.sv sf_iron_bank_arbiter.sv sf_iron_rob.sv sf_iron_memory_map.sv \
       sf_iron_buffer_manager.sv sf_iron_extmem_adapter.sv sf_iron_memory.sv"
SRC=""
for f in $FILES; do SRC="$SRC $ROOT/rtl/albion/$f"; done
sv2v -DSYNTHESIS -I"$ROOT/rtl/albion" $SRC "$ROOT/syn/sf_iron_memory_synth_top.sv" \
     --top sf_iron_memory_synth_top -w "$OUT/iron.v"
cat > "$OUT/synth.ys" << YS
read_verilog -sv $OUT/iron.v
hierarchy -check -top sf_iron_memory_synth_top
# -noshare: the SAT resource-sharing pass needs > 8 GB on this design
synth -top sf_iron_memory_synth_top -noshare
check -assert
stat
YS
yosys -q -l "$OUT/synth.log" "$OUT/synth.ys" > /dev/null
echo "latches inferred: $(grep -c 'Latch inferred for' "$OUT/synth.log" || true)"
sed -n '/=== design hierarchy ===/,/^$/p' "$OUT/synth.log"
grep -E "Number of cells|DFF" "$OUT/synth.log" | tail -8
