// =============================================================================
// SilicaFlux Albion -- Project 84 IRONMEMORY
// syn/sf_iron_memory_synth_top.sv : fixed-parameter wrapper used by
// syn/run_yosys.sh for the generic synthesizability check (Yosys via sv2v).
// Baseline architecture (4 banks, 64-bit, ECC, 5 masters, ext adapter),
// reduced bank depth so the generic flow stays fast.
// =============================================================================
module sf_iron_memory_synth_top (
  input  logic clk, rst_n,
  input  logic [4:0] m_req_valid, output logic [4:0] m_req_ready,
  input  logic [159:0] m_req_addr, input logic [14:0] m_req_size, input logic [4:0] m_req_we,
  input  logic [319:0] m_req_wdata, input logic [39:0] m_req_wstrb,
  output logic [4:0] m_rsp_valid, input logic [4:0] m_rsp_ready, output logic [319:0] m_rsp_rdata,
  output logic [14:0] m_rsp_err, output logic [4:0] m_rsp_ecc_corr,
  input  logic bm_cmd_valid, output logic bm_cmd_ready, input logic [2:0] bm_cmd_op, bm_cmd_requester,
  input  logic [3:0] bm_cmd_id, input logic [2:0] bm_cmd_btype, input logic [31:0] bm_cmd_start,
  input  logic [11:0] bm_cmd_len, input logic [2:0] bm_cmd_owner, input logic [4:0] bm_cmd_rd_mask, bm_cmd_wr_mask,
  output logic bm_rsp_valid, output logic [3:0] bm_rsp_status, output logic [3:0] bm_rsp_id,
  output logic [7:0] bm_rsp_err_bits,
  input  logic csr_valid, csr_we, input logic [11:0] csr_addr, input logic [31:0] csr_wdata,
  output logic csr_rvalid, output logic [31:0] csr_rdata, output logic csr_err,
  output logic ext_cmd_valid, input logic ext_cmd_ready, output logic ext_cmd_we, output logic [16:0] ext_cmd_addr,
  output logic [63:0] ext_cmd_wdata, output logic [7:0] ext_cmd_wstrb, output logic [5:0] ext_cmd_tag,
  input  logic ext_rsp_valid, output logic ext_rsp_ready, input logic [63:0] ext_rsp_rdata, input logic ext_rsp_err,
  input  logic [5:0] ext_rsp_tag,
  output logic init_done, irq
);
  sf_iron_memory #(.BANK_DEPTH(64)) u_iron (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_addr, .m_req_size, .m_req_we, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_err, .m_rsp_ecc_corr,
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask, .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id,
    .bm_rsp_in_use(), .bm_rsp_btype(), .bm_rsp_start(), .bm_rsp_len(), .bm_rsp_owner(), .bm_rsp_rd_mask(),
    .bm_rsp_wr_mask(), .bm_rsp_err_bits, .csr_valid, .csr_we, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .csr_err,
    .ext_cmd_valid, .ext_cmd_ready, .ext_cmd_we, .ext_cmd_addr, .ext_cmd_wdata, .ext_cmd_wstrb, .ext_cmd_tag,
    .ext_rsp_valid, .ext_rsp_ready, .ext_rsp_rdata, .ext_rsp_err, .ext_rsp_tag,
    .init_done, .irq, .trc_valid(), .trc_port(), .trc_seq(), .trc_we(), .trc_word(), .trc_be(), .trc_wdata());
endmodule
