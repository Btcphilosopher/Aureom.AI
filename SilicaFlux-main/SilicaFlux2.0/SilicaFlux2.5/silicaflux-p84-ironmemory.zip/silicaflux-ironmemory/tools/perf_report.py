#!/usr/bin/env python3
"""
Generate docs/iron_memory/perf_report.md (+ perf_accesses_per_cycle.svg) from the
PERF_JSON records emitted by tests/iron_memory/tb_perf.sv.

Every figure in the report is derived arithmetically from counters the DUT
itself exposed over its CSR port during simulation (plus the TB's cycle count
for the scenario window). Nothing is estimated or extrapolated.

Counter index map (see docs/iron_memory/csr_map.md):
  bank : 0 reads 1 writes 2 busy 3 conflict 4 rmw 5 rmw_stall 6 ce 7 ue
  port : 0 accepted 1 reads 2 writes 3 bytes_rd 4 bytes_wr 5 req_stall 6 bank_wait
         7 conflict_loss 8 starve_evt 9 max_wait 10 lat_sum 11 lat_cnt 12 lat_max
         13 err_rsp 14 rsp_bp 15 ext_acc
  glob : 0 cycles 1 desc_in_use 2 gran_in_use 3 gran_peak 4 alloc_ok 5 alloc_nodesc
         6 alloc_nospace 7 frees ...
"""
import json, os, sys

PORTS = ['Keystone', 'BridgeEngine', 'PacketForge', 'ComputeWorks', 'VirtualFoundry']


def derive(d):
    ports, banks, g = d['ports'], d['banks'], d['global']
    cyc = max(d['cycles'], 1)
    ops = sum(p[0] for p in ports)
    byt = sum(p[3] + p[4] for p in ports)
    lsum = sum(p[10] for p in ports)
    lcnt = sum(p[11] for p in ports)
    return dict(
        cycles=d['cycles'], ops=ops, bytes=byt,
        ops_per_cycle=ops / cyc, bytes_per_cycle=byt / cyc,
        lat_mean=(lsum / lcnt) if lcnt else 0.0, lat_max=max(p[12] for p in ports),
        bank_util=[b[2] / cyc for b in banks], conflicts=[b[3] for b in banks],
        rmw=sum(b[4] for b in banks), rmw_stall=sum(b[5] for b in banks),
        ce=sum(b[6] for b in banks), ue=sum(b[7] for b in banks),
        wait=[p[6] for p in ports], loss=[p[7] for p in ports], starve=[p[8] for p in ports],
        max_wait=[p[9] for p in ports], glob=g)


def svg_bar_chart(rows, path, ceiling):
    """rows: [(label, value)]. Single series, horizontal bars, light surface."""
    W, rowh, top, left, right = 760, 34, 84, 230, 90
    H = top + rowh * len(rows) + 48
    plot_w = W - left - right
    vmax = max(ceiling, max(v for _, v in rows)) * 1.05
    x = lambda v: left + plot_w * v / vmax
    o = [f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}" width="{W}" height="{H}" '
         f'font-family="system-ui, -apple-system, Segoe UI, sans-serif" role="img" '
         f'aria-label="Accesses per cycle by scenario">',
         f'<rect width="{W}" height="{H}" fill="#fcfcfb"/>',
         f'<text x="{left}" y="24" font-size="15" font-weight="600" fill="#0b0b0b">Accesses completed per cycle, by traffic scenario</text>',
         f'<text x="{left}" y="42" font-size="12" fill="#52514e">Measured in simulation from IronMemory counters (4 banks, 64-bit words, ECC on, RL=1)</text>']
    # recessive grid + axis ticks
    t = 0.0
    while t <= vmax + 1e-9:
        gx = x(t)
        o.append(f'<line x1="{gx:.1f}" y1="{top - 6}" x2="{gx:.1f}" y2="{top + rowh * len(rows)}" stroke="#e7e6e1" stroke-width="1"/>')
        o.append(f'<text x="{gx:.1f}" y="{top + rowh * len(rows) + 18}" font-size="11" fill="#6f6e69" text-anchor="middle">{t:g}</text>')
        t += 1.0
    o.append(f'<text x="{left + plot_w / 2:.1f}" y="{H - 8}" font-size="11" fill="#52514e" text-anchor="middle">accesses per cycle</text>')
    # ceiling reference
    cx = x(ceiling)
    o.append(f'<line x1="{cx:.1f}" y1="{top - 6}" x2="{cx:.1f}" y2="{top + rowh * len(rows)}" stroke="#52514e" stroke-width="1" stroke-dasharray="4 3"/>')
    o.append(f'<text x="{cx + 4:.1f}" y="{top - 10}" font-size="11" fill="#52514e">{ceiling} banks = peak</text>')
    for i, (lab, v) in enumerate(rows):
        y = top + i * rowh + 8
        bh = rowh - 16
        x0, x1 = x(0), x(v)
        w = max(x1 - x0, 1)
        r = min(4, w / 2, bh / 2)
        # bar anchored at baseline: square left end, 4px rounded data end
        d = (f'M{x0:.1f},{y} H{x0 + w - r:.1f} Q{x0 + w:.1f},{y} {x0 + w:.1f},{y + r:.1f} '
             f'V{y + bh - r:.1f} Q{x0 + w:.1f},{y + bh} {x0 + w - r:.1f},{y + bh} H{x0:.1f} Z')
        o.append(f'<g><title>{lab}: {v:.2f} accesses/cycle</title>'
                 f'<rect x="{left - 225}" y="{y - 8}" width="{W - 10}" height="{rowh}" fill="transparent"/>'
                 f'<path d="{d}" fill="#2a78d6"/></g>')
        o.append(f'<text x="{left - 10}" y="{y + bh / 2 + 4:.1f}" font-size="12" fill="#0b0b0b" text-anchor="end">{lab}</text>')
        o.append(f'<text x="{x1 + 6:.1f}" y="{y + bh / 2 + 4:.1f}" font-size="12" fill="#52514e">{v:.2f}</text>')
    o.append('</svg>')
    open(path, 'w').write('\n'.join(o))


def write_report(perf, out_md):
    by = {(d['cfg'], d['scenario']): d for d in perf}
    on = {s: derive(d) for (c, s), d in by.items() if c == 'ecc_on'}
    off = {s: derive(d) for (c, s), d in by.items() if c == 'ecc_off'}
    order = ['independent_streams', 'uniform_random', 'full_write_random', 'hot_bank',
             'partial_write_heavy', 'dma_vs_accel_equal', 'dma_vs_accel_hipri']
    notes = {s: by[('ecc_on', s)]['note'] for s in order if ('ecc_on', s) in by}
    L = []
    L.append('# IronMemory performance report (measured)\n')
    L.append('> Generated by `tools/perf_report.py` from `build/perf.json`, which `tests/iron_memory/run_tests.py` '
             'captures from `tb_perf`. Every value below is read back from IronMemory\'s own performance counters '
             'over the CSR port, or is the testbench\'s cycle count for the scenario window. Units are **clock cycles**; '
             'no clock frequency is assumed, so nothing here is a GB/s figure. Backend: generic SRAM model, which '
             'defines cycle behaviour only (no silicon timing, area or power).\n')
    L.append('Configuration: 4 banks x 1024 words x 64 bits (32 KiB window, word-interleaved), RL=1, MAX_OUT=8 per port, '
             'five masters, one window-wide buffer with all permissions (so no traffic is refused). 2,000 requests per '
             'active master per scenario, issued back-to-back.\n')
    L.append('![Accesses per cycle](perf_accesses_per_cycle.svg)\n')
    L.append('## Bandwidth and latency\n')
    L.append('Latency is measured per access from request acceptance to the response first being presented '
             '(excludes response back-pressure, which is counted separately).\n')
    L.append('| Scenario | What runs | Cycles | Accesses | Accesses/cycle | Bytes/cycle | Mean latency | Max latency |')
    L.append('|---|---|---:|---:|---:|---:|---:|---:|')
    rows = []
    for s in order:
        if s not in on:
            continue
        m = on[s]
        L.append(f"| `{s}` | {notes[s]} | {m['cycles']} | {m['ops']} | {m['ops_per_cycle']:.2f} | "
                 f"{m['bytes_per_cycle']:.2f} | {m['lat_mean']:.2f} | {m['lat_max']} |")
        rows.append((s, m['ops_per_cycle']))
    svg_bar_chart(rows, os.path.join(os.path.dirname(out_md), 'perf_accesses_per_cycle.svg'), 4)
    L.append('')
    L.append('## Bank utilisation and conflicts\n')
    L.append('Busy = cycles the bank\'s SRAM port performed an access (includes RMW write-backs). '
             'Conflict cycles = cycles with two or more requesters for the bank.\n')
    L.append('| Scenario | Busy % b0 / b1 / b2 / b3 | Conflict cycles b0 / b1 / b2 / b3 |')
    L.append('|---|---|---|')
    for s in order:
        if s in on:
            m = on[s]
            L.append(f"| `{s}` | {' / '.join(f'{u * 100:.0f}' for u in m['bank_util'])} | "
                     f"{' / '.join(str(c) for c in m['conflicts'])} |")
    L.append('')
    L.append('## ECC overhead\n')
    L.append('Storage: each 64-bit word is stored as a 72-bit SECDED codeword, a 12.5 % array overhead that is '
             'physically present in every backend (the SRAM is instantiated 72 bits wide).\n')
    L.append('Port timing: a write that does not cover all 8 bytes needs a read-modify-write with ECC on, which '
             'occupies the bank for RL+2 cycles instead of 1. With ECC off the same write uses native byte enables.\n')
    L.append('| Scenario | ECC | Cycles | Accesses/cycle | RMW operations | Bank cycles lost to RMW |')
    L.append('|---|---|---:|---:|---:|---:|')
    for s in ['partial_write_heavy', 'full_write_random', 'uniform_random']:
        for tag, src in (('on', on), ('off', off)):
            if s in src:
                m = src[s]
                L.append(f"| `{s}` | {tag} | {m['cycles']} | {m['ops_per_cycle']:.2f} | {m['rmw']} | {m['rmw_stall']} |")
    if 'partial_write_heavy' in on and 'partial_write_heavy' in off:
        a, b = on['partial_write_heavy'], off['partial_write_heavy']
        L.append(f"\nFor byte-granular writes, ECC costs {a['cycles'] / b['cycles']:.2f}x the cycles "
                 f"({a['ops_per_cycle']:.2f} vs {b['ops_per_cycle']:.2f} accesses/cycle). Full-word writes pay nothing.\n")
    L.append('## DMA contention and accelerator starvation\n')
    L.append('BridgeEngine streams sequential writes while ComputeWorks issues random reads over the same window. '
             'Wait = cycles a request sat in the port\'s issue slot without a grant; loss = cycles it lost '
             'arbitration to another master; starvation events = waits reaching STARVE_LIMIT (16).\n')
    L.append('| Scenario | Port | Wait cycles | Conflict losses | Max wait | Starvation events | Mean latency |')
    L.append('|---|---|---:|---:|---:|---:|---:|')
    for s in ['dma_vs_accel_equal', 'dma_vs_accel_hipri']:
        if s in on:
            m, raw = on[s], by[('ecc_on', s)]['ports']
            for p in (1, 3):
                lat = raw[p][10] / raw[p][11] if raw[p][11] else 0
                L.append(f"| `{s}` | {PORTS[p]} | {m['wait'][p]} | {m['loss'][p]} | {m['max_wait'][p]} | "
                         f"{m['starve'][p]} | {lat:.2f} |")
    L.append('')
    if 'hot_bank' in on:
        m = on['hot_bank']
        L.append(f"Worst case, all five masters on one bank (`hot_bank`): the bank stays busy every cycle and "
                 f"round-robin bounds every master's wait to {max(m['max_wait'])} cycles; no starvation events.\n")
    if ('ecc_on', 'buffer_occupancy') in by:
        g = by[('ecc_on', 'buffer_occupancy')]['global']
        L.append('## Buffer occupancy\n')
        L.append(by[('ecc_on', 'buffer_occupancy')]['note'] + '.\n')
        L.append('| Allocations granted | Refused: no descriptor | Refused: no contiguous space | Descriptors in use | Granules in use (of 128) | Peak granules |')
        L.append('|---:|---:|---:|---:|---:|---:|')
        L.append(f'| {g[4]} | {g[5]} | {g[6]} | {g[1]} | {g[2]} | {g[3]} |\n')
    L.append('## Reproduce\n')
    L.append('```\npython3 tests/iron_memory/run_tests.py   # regression, then perf + this report\n```\n')
    open(out_md, 'w').write('\n'.join(L) + '\n')


if __name__ == '__main__':
    src = sys.argv[1] if len(sys.argv) > 1 else 'build/perf.json'
    write_report(json.load(open(src)), sys.argv[2] if len(sys.argv) > 2 else 'docs/iron_memory/perf_report.md')
