#!/usr/bin/env python3
"""
IronMemory SRAM macro area report.

Physical SRAM area is reported ONLY from vendor data you supply:
  * Liberty (.lib) : the macro cell's `area : <value> ;` attribute
  * LEF (.lef)     : the macro's `SIZE <w> BY <h> ;` footprint (optional)
Without them the tool prints the macro tiling (counts only) and states that
area is not reported. It never derives area from the generic RTL array, from
bit counts, or from rule-of-thumb bit-cell densities.

Tiling matches rtl/albion/sf_iron_sram_asic.sv:
  column tiles = ceil(codeword_bits / macro_bits)
  row tiles    = ceil(bank_depth / macro_words)
  macros       = column tiles * row tiles * banks

Usage:
  tools/sram_area_report.py --banks 4 --depth 1024 --data-bits 64 --ecc 1 \
      --macro-name <CELL> --macro-words 512 --macro-bits 72 \
      [--liberty path/to/sram.lib] [--lef path/to/sram.lef] [--json out.json]
"""
import argparse, json, math, re, sys


def secded_check_bits(dw):
    r = 1
    while (1 << r) < dw + r + 1:
        r += 1
    return r + 1                        # Hamming bits + overall parity


def liberty_cell_area(path, cell):
    """Return the `area` attribute of `cell (<cell>) { ... }` in a Liberty file."""
    text = open(path, encoding='utf-8', errors='replace').read()
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.S)
    m = re.search(r'\bcell\s*\(\s*"?%s"?\s*\)\s*\{' % re.escape(cell), text)
    if not m:
        return None
    depth, i = 1, m.end()
    body_start = i
    while i < len(text) and depth:
        if text[i] == '{':
            depth += 1
        elif text[i] == '}':
            depth -= 1
        i += 1
    body = text[body_start:i]
    # only the cell-level attribute: strip nested groups first
    flat, d = [], 0
    for ch in body:
        if ch == '{':
            d += 1
        elif ch == '}':
            d -= 1
        elif d == 0:
            flat.append(ch)
    a = re.search(r'\barea\s*:\s*([0-9.eE+-]+)\s*;', ''.join(flat))
    return float(a.group(1)) if a else None


def lef_macro_size(path, macro):
    text = open(path, encoding='utf-8', errors='replace').read()
    m = re.search(r'\bMACRO\s+%s\b(.*?)\bEND\s+%s\b' % (re.escape(macro), re.escape(macro)), text, flags=re.S)
    if not m:
        return None
    s = re.search(r'\bSIZE\s+([0-9.]+)\s+BY\s+([0-9.]+)\s*;', m.group(1))
    return (float(s.group(1)), float(s.group(2))) if s else None


def report(a):
    cw = a.data_bits + (secded_check_bits(a.data_bits) if a.ecc else 0)
    col = math.ceil(cw / a.macro_bits)
    row = math.ceil(a.depth / a.macro_words)
    per_bank = col * row
    total = per_bank * a.banks
    used_bits = a.banks * a.depth * cw
    macro_bits = total * a.macro_words * a.macro_bits
    out = dict(banks=a.banks, depth=a.depth, data_bits=a.data_bits, ecc=bool(a.ecc), codeword_bits=cw,
               macro=a.macro_name, macro_words=a.macro_words, macro_bits=a.macro_bits,
               column_tiles=col, row_tiles=row, macros_per_bank=per_bank, macros_total=total,
               bit_utilisation=round(used_bits / macro_bits, 4),
               ecc_storage_overhead=round(cw / a.data_bits - 1, 4),
               area_source=None, macro_area=None, total_macro_area=None, area_units=None,
               footprint=None, area_status='NOT REPORTED: no Liberty/LEF data supplied for the macro')
    if a.liberty:
        ar = liberty_cell_area(a.liberty, a.macro_name)
        if ar is None:
            out['area_status'] = f'NOT REPORTED: cell {a.macro_name} or its area attribute not found in {a.liberty}'
        else:
            out.update(area_source=a.liberty, macro_area=ar, total_macro_area=ar * total,
                       area_units='Liberty area units (as defined by the library, typically um^2)',
                       area_status='REPORTED from supplied Liberty (macros only; excludes logic, routing, halos)')
    if a.lef:
        sz = lef_macro_size(a.lef, a.macro_name)
        if sz:
            out['footprint'] = dict(width=sz[0], height=sz[1], source=a.lef,
                                    total_footprint_area=sz[0] * sz[1] * total)
    return out


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--banks', type=int, default=4)
    ap.add_argument('--depth', type=int, default=1024)
    ap.add_argument('--data-bits', type=int, default=64)
    ap.add_argument('--ecc', type=int, default=1)
    ap.add_argument('--macro-name', required=True)
    ap.add_argument('--macro-words', type=int, required=True)
    ap.add_argument('--macro-bits', type=int, required=True)
    ap.add_argument('--liberty')
    ap.add_argument('--lef')
    ap.add_argument('--json')
    a = ap.parse_args(argv)
    r = report(a)
    for k, v in r.items():
        print(f'{k:22s} {v}')
    if a.json:
        json.dump(r, open(a.json, 'w'), indent=1)
    return r


if __name__ == '__main__':
    main()
