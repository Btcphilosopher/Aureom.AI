// =============================================================================
// tb_wide_port : 256-bit effective accelerator interface from 4 banked lanes
//   ports 3,5,6,7 -> ComputeWorks domain (PORT_DOMAIN_MAP = 24'o33343210)
//   1  wide write/read data integrity, sparse lanes, empty-strobe write
//   2  sustained bandwidth: one 256-bit access per cycle (32 B/cycle)
//   3  contention from BridgeEngine on one bank: lanes stall independently,
//      data stays correct
//   4  ownership: lanes inherit the ComputeWorks domain
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_wide_port;
  import sf_iron_pkg::*;
  int tb_errors = 0;
  int tb_checks = 0;

  localparam int NP = 8, AW = 32, DW = 64, NB = 8, NBANK = 4, DEPTH = 64, L = 4;
  localparam logic [31:0] SB = 32'h1000_0000;
  localparam int WIN = NBANK * DEPTH * NB;
  localparam int IDW = 4, LEN_W = 12;
  localparam int LANE_PORT [L] = '{3, 5, 6, 7};

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NP-1:0] m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_ready, m_rsp_ecc_corr;
  logic [NP*AW-1:0] m_req_addr; logic [NP*3-1:0] m_req_size; logic [NP*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NP*NB-1:0] m_req_wstrb; logic [NP*3-1:0] m_rsp_err;
  logic bm_cmd_valid, bm_cmd_ready, bm_rsp_valid, bm_rsp_in_use;
  logic [2:0] bm_cmd_op, bm_cmd_requester, bm_cmd_btype, bm_cmd_owner, bm_rsp_btype, bm_rsp_owner;
  logic [IDW-1:0] bm_cmd_id, bm_rsp_id; logic [AW-1:0] bm_cmd_start, bm_rsp_start;
  logic [LEN_W-1:0] bm_cmd_len, bm_rsp_len; logic [4:0] bm_cmd_rd_mask, bm_cmd_wr_mask, bm_rsp_rd_mask, bm_rsp_wr_mask;
  logic [3:0] bm_rsp_status; logic [7:0] bm_rsp_err_bits;
  logic csr_rvalid, csr_err; logic [31:0] csr_rdata;
  logic init_done, irq;

  sf_iron_memory #(.NUM_PORTS(NP), .PORT_DOMAIN_MAP(24'o33343210), .AW(AW), .DW(DW), .NUM_BANKS(NBANK),
    .BANK_DEPTH(DEPTH), .SRAM_BASE(SB), .GRAN_BYTES(64), .EXT_EN(0)) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_addr, .m_req_size, .m_req_we, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_err, .m_rsp_ecc_corr,
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask, .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id,
    .bm_rsp_in_use, .bm_rsp_btype, .bm_rsp_start, .bm_rsp_len, .bm_rsp_owner, .bm_rsp_rd_mask, .bm_rsp_wr_mask,
    .bm_rsp_err_bits, .csr_valid(1'b0), .csr_we(1'b0), .csr_addr(12'h0), .csr_wdata(32'h0), .csr_rvalid, .csr_rdata, .csr_err,
    .ext_cmd_valid(), .ext_cmd_ready(1'b0), .ext_cmd_we(), .ext_cmd_addr(), .ext_cmd_wdata(), .ext_cmd_wstrb(), .ext_cmd_tag(),
    .ext_rsp_valid(1'b0), .ext_rsp_ready(), .ext_rsp_rdata(64'h0), .ext_rsp_err(1'b0), .ext_rsp_tag('0),
    .init_done, .irq, .trc_valid(), .trc_port(), .trc_seq(), .trc_we(), .trc_word(), .trc_be(), .trc_wdata());

  // ---- wide port ----
  logic w_req_valid, w_req_ready, w_req_we, w_rsp_valid, w_rsp_ready, w_rsp_ecc_corr;
  logic [AW-1:0] w_req_addr; logic [L*DW-1:0] w_req_wdata, w_rsp_rdata; logic [L*NB-1:0] w_req_wstrb; logic [2:0] w_rsp_err;
  logic [L-1:0] l_req_valid, l_req_ready, l_req_we, l_rsp_valid, l_rsp_ready, l_rsp_ecc_corr;
  logic [L*AW-1:0] l_req_addr; logic [L*3-1:0] l_req_size, l_rsp_err; logic [L*DW-1:0] l_req_wdata, l_rsp_rdata; logic [L*NB-1:0] l_req_wstrb;

  sf_iron_wide_port #(.LANES(L), .DW(DW), .AW(AW), .QD(8)) u_wide (
    .clk, .rst_n, .w_req_valid, .w_req_ready, .w_req_addr, .w_req_we, .w_req_wdata, .w_req_wstrb,
    .w_rsp_valid, .w_rsp_ready, .w_rsp_rdata, .w_rsp_err, .w_rsp_ecc_corr,
    .l_req_valid, .l_req_ready, .l_req_addr, .l_req_size, .l_req_we, .l_req_wdata, .l_req_wstrb,
    .l_rsp_valid, .l_rsp_ready, .l_rsp_rdata, .l_rsp_err, .l_rsp_ecc_corr);

  // lane <-> port wiring; ports 0,1,2,4 driven by the TB
  logic [NP-1:0] tb_valid, tb_we, tb_rsp_ready; logic [NP*AW-1:0] tb_addr; logic [NP*DW-1:0] tb_wdata;
  always_comb begin
    m_req_valid = tb_valid; m_req_we = tb_we; m_req_addr = tb_addr; m_req_wdata = tb_wdata;
    m_req_size = {NP{3'd3}}; m_req_wstrb = '1; m_rsp_ready = tb_rsp_ready;
    for (int i = 0; i < L; i++) begin
      automatic int p = LANE_PORT[i];
      m_req_valid[p] = l_req_valid[i]; m_req_we[p] = l_req_we[i];
      m_req_addr[p*AW +: AW] = l_req_addr[i*AW +: AW]; m_req_size[p*3 +: 3] = l_req_size[i*3 +: 3];
      m_req_wdata[p*DW +: DW] = l_req_wdata[i*DW +: DW]; m_req_wstrb[p*NB +: NB] = l_req_wstrb[i*NB +: NB];
      m_rsp_ready[p] = l_rsp_ready[i];
      l_req_ready[i] = m_req_ready[p];
      l_rsp_valid[i] = m_rsp_valid[p]; l_rsp_rdata[i*DW +: DW] = m_rsp_rdata[p*DW +: DW];
      l_rsp_err[i*3 +: 3] = m_rsp_err[p*3 +: 3]; l_rsp_ecc_corr[i] = m_rsp_ecc_corr[p];
    end
  end

  // ---- wide scoreboard ----
  logic [255:0] wref [32];          // 32 rows of 256 bits = 1 KiB tensor buffer
  typedef struct { logic [255:0] data; logic [2:0] err; } wexp_t;
  wexp_t wq [$];
  int n_wrsp, first_acc, last_acc, n_acc;
  logic [31:0] cyc;
  always_ff @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  function automatic logic [255:0] lanes(input logic [31:0] be);
    logic [255:0] m; for (int i = 0; i < 32; i++) m[i*8 +: 8] = {8{be[i]}}; return m;
  endfunction

  always @(posedge clk) if (rst_n) begin
    if (w_rsp_valid && w_rsp_ready) begin
      wexp_t e;
      tb_checks++; n_wrsp++;
      if (wq.size() == 0) begin tb_errors++; $display("[FAIL] unexpected wide response"); end
      else begin
        e = wq.pop_front();
        if (w_rsp_rdata !== e.data || w_rsp_err !== e.err) begin
          tb_errors++; if (tb_errors < 20) $display("[FAIL] wide rsp %h/%h err %0d/%0d", w_rsp_rdata, e.data, w_rsp_err, e.err);
        end
      end
    end
  end

  logic [31:0] TBASE;
  task automatic wide(input logic we, input int row, input logic [255:0] wd, input logic [31:0] st, input logic [2:0] experr = RSP_OK);
    wexp_t e;
    @(negedge clk);
    w_req_valid = 1; w_req_we = we; w_req_addr = TBASE + 32'(row * 32); w_req_wdata = wd; w_req_wstrb = st;
    #1;
    while (!w_req_ready) begin @(negedge clk); #1; end
    if (we) begin
      if (experr == RSP_OK) wref[row] = (wref[row] & ~lanes(st)) | (wd & lanes(st));
      e.data = '0;
    end else e.data = (experr == RSP_OK) ? wref[row] : '0;
    e.err = experr;
    wq.push_back(e);
    n_acc++; if (n_acc == 1) first_acc = cyc; last_acc = cyc;
    @(posedge clk); #1;
    w_req_valid = 0;
  endtask
  // back-to-back variant: holds valid across cycles
  task automatic wide_stream(input int nreq);
    for (int k = 0; k < nreq; k++) begin
      wexp_t e;
      if (k == 0) @(negedge clk);
      w_req_valid = 1; w_req_we = 0; w_req_addr = TBASE + 32'((k % 32) * 32); w_req_wstrb = '1;
      #1;
      while (!w_req_ready) begin @(negedge clk); #1; end
      e.data = wref[k % 32]; e.err = RSP_OK; wq.push_back(e);
      n_acc++; if (n_acc == 1) first_acc = cyc; last_acc = cyc;
      @(negedge clk);
    end
    w_req_valid = 0;
  endtask

  int bridge_n;
  initial begin
    w_req_valid = 0; w_req_we = 0; w_req_addr = 0; w_req_wdata = 0; w_req_wstrb = 0; w_rsp_ready = 1;
    tb_valid = 0; tb_we = 0; tb_addr = 0; tb_wdata = 0; tb_rsp_ready = '1;
    bm_cmd_valid = 0; bm_cmd_op = 0; bm_cmd_requester = 0; bm_cmd_id = 0; bm_cmd_btype = 0; bm_cmd_start = 0;
    bm_cmd_len = 0; bm_cmd_owner = 0; bm_cmd_rd_mask = 0; bm_cmd_wr_mask = 0;
    n_wrsp = 0; n_acc = 0; bridge_n = 0;
    for (int r = 0; r < 32; r++) wref[r] = '0;
    repeat (4) @(posedge clk); rst_n = 1;
    while (!init_done) @(posedge clk);
    // tensor buffer owned by ComputeWorks, shared read with BridgeEngine
    @(negedge clk);
    bm_cmd_valid = 1; bm_cmd_op = BM_ALLOC; bm_cmd_requester = DOM_KEYSTONE; bm_cmd_btype = BT_TENSOR_OPERAND;
    bm_cmd_len = 12'd1024; bm_cmd_owner = DOM_COMPUTE; bm_cmd_rd_mask = 5'b01010; bm_cmd_wr_mask = 5'b01000;
    @(negedge clk); bm_cmd_valid = 0;
    while (!bm_rsp_valid) @(posedge clk);
    `CHECK_EQ(bm_rsp_status, BMS_OK, "tensor buffer allocated")
    TBASE = bm_rsp_start;

    // ---- 1. integrity ----
    for (int r = 0; r < 32; r++) wide(1, r, {$urandom, $urandom, $urandom, $urandom, $urandom, $urandom, $urandom, $urandom}, '1);
    for (int r = 0; r < 32; r++) wide(0, r, '0, '1);
    wide(1, 3, {8{32'h5A5A_A5A5}}, 32'h00FF_00F0);          // lanes 0,1(partial),2 ; lane 3 skipped
    wide(0, 3, '0, '1);
    wide(1, 4, '1, 32'h0, RSP_ALIGN);                       // no active lane
    wait (wq.size() == 0); repeat (5) @(posedge clk);

    // ---- 2. sustained bandwidth ----
    n_acc = 0;
    wide_stream(256);
    wait (wq.size() == 0); repeat (5) @(posedge clk);
    $display("wide stream: 256 x 256-bit reads accepted over %0d cycles (%0d bytes/cycle x100 = %0d)",
             last_acc - first_acc + 1, 32, (256 * 32 * 100) / (last_acc - first_acc + 1));
    `CHECK(last_acc - first_acc + 1 <= 260, "one 256-bit access per cycle sustained (32 B/cycle)")

    // ---- 3. contention: BridgeEngine hammers bank 2 inside the tensor buffer ----
    n_acc = 0;
    fork
      wide_stream(256);
      begin
        for (int k = 0; k < 300; k++) begin
          @(negedge clk);
          tb_valid[1] = 1; tb_we[1] = 0; tb_addr[1*AW +: AW] = TBASE + 32'(((k % 32) * 32) + 16);   // lane-2 word
          #1; while (!m_req_ready[1]) begin @(negedge clk); #1; end
          bridge_n++;
        end
        @(negedge clk); tb_valid[1] = 0;
      end
    join
    wait (wq.size() == 0); repeat (10) @(posedge clk);
    $display("wide stream under bank-2 contention: %0d cycles for 256 wide reads", last_acc - first_acc + 1);
    `CHECK(last_acc - first_acc + 1 > 300, "contention on one bank slows the wide stream")

    // ---- 4. ownership: PacketForge may not read the tensor buffer; lanes may write it ----
    @(negedge clk); tb_valid[2] = 1; tb_we[2] = 0; tb_addr[2*AW +: AW] = TBASE;
    #1; while (!m_req_ready[2]) begin @(negedge clk); #1; end
    @(negedge clk); tb_valid[2] = 0;
    while (!m_rsp_valid[2]) @(posedge clk);
    `CHECK_EQ(m_rsp_err[2*3 +: 3], RSP_PERM, "PacketForge refused on ComputeWorks tensor buffer")
    `TB_FINISH("tb_wide_port")
  end
  initial begin #20ms; $display("TB_RESULT tb_wide_port FAIL timeout"); $finish; end
endmodule
