// =============================================================================
// tb_iron_memory_ext : sf_iron_memory with external memory enabled, driving
// the simulated DRAM controller. Run only after the local suite passes.
//   1  external-window permission (reset default: Keystone only)
//   2  mixed SRAM + DRAM random traffic from all masters; per-port in-order
//      responses although SRAM completions overtake DRAM completions (ROB)
//   3  controller error -> RSP_EXT, sticky status, counters
//   4  external latency / traffic counters vs TB observation
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_iron_memory_ext;
  import sf_iron_pkg::*;
  int tb_errors = 0;
  int tb_checks = 0;

  localparam int NP = 5, AW = 32, DW = 64, NB = 8, NBANK = 4, DEPTH = 64, MAXO = 8;
  localparam logic [31:0] SB = 32'h1000_0000, EB = 32'h8000_0000;
  localparam longint EBYTES = 65536;
  localparam int EWW = 13, EWORDS = 8192;
  localparam int WIN = NBANK * DEPTH * NB;
  localparam int PW = 3, SW = 3, IDW = 4, LW = 6, LEN_W = 12, ETW = PW + SW;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NP-1:0] m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_ready, m_rsp_ecc_corr;
  logic [NP*AW-1:0] m_req_addr; logic [NP*3-1:0] m_req_size; logic [NP*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NP*NB-1:0] m_req_wstrb; logic [NP*3-1:0] m_rsp_err;
  logic bm_cmd_valid, bm_cmd_ready, bm_rsp_valid, bm_rsp_in_use;
  logic [2:0] bm_cmd_op, bm_cmd_requester, bm_cmd_btype, bm_cmd_owner, bm_rsp_btype, bm_rsp_owner;
  logic [IDW-1:0] bm_cmd_id, bm_rsp_id; logic [AW-1:0] bm_cmd_start, bm_rsp_start;
  logic [LEN_W-1:0] bm_cmd_len, bm_rsp_len; logic [4:0] bm_cmd_rd_mask, bm_cmd_wr_mask, bm_rsp_rd_mask, bm_rsp_wr_mask;
  logic [3:0] bm_rsp_status; logic [7:0] bm_rsp_err_bits;
  logic csr_valid, csr_we, csr_rvalid, csr_err; logic [11:0] csr_addr; logic [31:0] csr_wdata, csr_rdata;
  logic ext_cmd_valid, ext_cmd_ready, ext_cmd_we, ext_rsp_valid, ext_rsp_ready, ext_rsp_err;
  logic [EWW-1:0] ext_cmd_addr; logic [63:0] ext_cmd_wdata, ext_rsp_rdata; logic [7:0] ext_cmd_wstrb;
  logic [ETW-1:0] ext_cmd_tag, ext_rsp_tag;
  logic init_done, irq;
  logic [NBANK-1:0] trc_valid, trc_we; logic [NBANK*PW-1:0] trc_port; logic [NBANK*SW-1:0] trc_seq;
  logic [NBANK*LW-1:0] trc_word; logic [NBANK*NB-1:0] trc_be; logic [NBANK*DW-1:0] trc_wdata;
  logic inj_en; logic [EWW-1:0] inj_addr; logic ev_hit, ev_empty, ev_miss, ev_ref;

  sf_iron_memory #(.NUM_PORTS(NP), .AW(AW), .DW(DW), .NUM_BANKS(NBANK), .BANK_DEPTH(DEPTH), .SRAM_BASE(SB),
    .MAX_OUT(MAXO), .GRAN_BYTES(64), .EXT_EN(1), .EXT_BASE(EB), .EXT_BYTES(EBYTES), .EXT_MAX_OUT(8)) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_addr, .m_req_size, .m_req_we, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_err, .m_rsp_ecc_corr,
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask, .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id,
    .bm_rsp_in_use, .bm_rsp_btype, .bm_rsp_start, .bm_rsp_len, .bm_rsp_owner, .bm_rsp_rd_mask, .bm_rsp_wr_mask,
    .bm_rsp_err_bits, .csr_valid, .csr_we, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .csr_err,
    .ext_cmd_valid, .ext_cmd_ready, .ext_cmd_we, .ext_cmd_addr, .ext_cmd_wdata, .ext_cmd_wstrb, .ext_cmd_tag,
    .ext_rsp_valid, .ext_rsp_ready, .ext_rsp_rdata, .ext_rsp_err, .ext_rsp_tag,
    .init_done, .irq, .trc_valid, .trc_port, .trc_seq, .trc_we, .trc_word, .trc_be, .trc_wdata);

  sf_iron_simdram #(.DW(DW), .AW(EWW), .WORDS(EWORDS), .TAG_W(ETW), .NBANKS(8), .ROW_WORDS(128),
    .T_REFI(780), .T_RFC(52), .QDEPTH(4)) u_dram (
    .clk, .rst_n, .cmd_valid(ext_cmd_valid), .cmd_ready(ext_cmd_ready), .cmd_we(ext_cmd_we), .cmd_addr(ext_cmd_addr),
    .cmd_wdata(ext_cmd_wdata), .cmd_wstrb(ext_cmd_wstrb), .cmd_tag(ext_cmd_tag),
    .rsp_valid(ext_rsp_valid), .rsp_ready(ext_rsp_ready), .rsp_rdata(ext_rsp_rdata), .rsp_err(ext_rsp_err),
    .rsp_tag(ext_rsp_tag), .inj_err_en(inj_en), .inj_err_addr(inj_addr),
    .ev_row_hit(ev_hit), .ev_row_empty(ev_empty), .ev_row_miss(ev_miss), .ev_refresh(ev_ref));

  // ---------------- reference model ----------------
  logic [63:0] refm [NBANK][DEPTH];
  logic [63:0] erefm [EWORDS];
  logic [4:0]  ext_rd_m, ext_wr_m;
  typedef struct { logic [31:0] addr; logic [2:0] size; logic we; logic [63:0] wdata; logic [7:0] wstrb; } req_t;
  typedef struct { logic [2:0] err; bit rd; logic [SW-1:0] seq; bit tracked; bit is_ext; } exp_t;
  localparam int RQD = 8192, EQD = 32;
  req_t rqa [NP][RQD]; int rq_h [NP], rq_t [NP];
  exp_t eqa [NP][EQD]; int eq_h [NP], eq_t [NP];
  logic [63:0] ed [NP][MAXO]; bit eerr [NP][MAXO]; bit eset [NP][MAXO];
  logic [SW-1:0] tseq [NP];
  int bp_mode [NP];
  int o_ext_acc, o_ext_rd, o_ext_wr, o_ext_err_rsp, n_reorder;

  function automatic int rq_n(input int p); return rq_t[p] - rq_h[p]; endfunction
  function automatic int eq_n(input int p); return eq_t[p] - eq_h[p]; endfunction
  function automatic logic [63:0] lanes(input logic [7:0] be);
    logic [63:0] m; for (int i = 0; i < 8; i++) m[i*8 +: 8] = {8{be[i]}}; return m;
  endfunction

  function automatic logic [2:0] model_err(input int p, input req_t r, output logic [7:0] be, output bit is_ext);
    int off, sz; bit in_s, in_e;
    in_s = (r.addr >= SB) && (r.addr < SB + WIN);
    in_e = (r.addr >= EB) && (r.addr < EB + 32'(EBYTES));
    is_ext = in_e; sz = 1 << r.size; off = r.addr & 7; be = '0;
    if (!in_s && !in_e) return RSP_DECODE;
    if (r.size > 3 || (off % sz) != 0) return RSP_ALIGN;
    for (int i = 0; i < 8; i++) be[i] = (i >= off) && (i < off + sz);
    if (r.we) be = be & r.wstrb;
    if (r.we && be == 0) return RSP_ALIGN;
    if (in_e) return (r.we ? ext_wr_m[p] : ext_rd_m[p]) ? RSP_OK : RSP_PERM;
    return RSP_OK;    // whole SRAM window is one all-access buffer in this test
  endfunction

  // ---------------- cycle engine ----------------
  initial begin
    m_req_valid = 0; m_req_addr = 0; m_req_size = 0; m_req_we = 0; m_req_wdata = 0; m_req_wstrb = 0; m_rsp_ready = '1;
    forever begin
      @(negedge clk);
      for (int p = 0; p < NP; p++) begin
        if (rst_n && rq_n(p) > 0) begin
          req_t r; r = rqa[p][rq_h[p] & (RQD - 1)];
          m_req_valid[p] = 1; m_req_addr[p*AW +: AW] = r.addr; m_req_size[p*3 +: 3] = r.size;
          m_req_we[p] = r.we; m_req_wdata[p*DW +: DW] = r.wdata; m_req_wstrb[p*NB +: NB] = r.wstrb;
        end else m_req_valid[p] = 0;
        m_rsp_ready[p] = (bp_mode[p] == 0) ? 1'b1 : ($urandom_range(0, 99) < 60);
      end
      #1;
      if (rst_n) begin
        // SRAM bank issues
        for (int b = 0; b < NBANK; b++) if (trc_valid[b]) begin
          int p, s, w; logic [7:0] be;
          p = trc_port[b*PW +: PW]; s = trc_seq[b*SW +: SW]; w = trc_word[b*LW +: LW]; be = trc_be[b*NB +: NB];
          // reorder detection: an older DRAM access of this port still pending
          for (int k = eq_h[p]; k < eq_t[p]; k++) begin
            exp_t x; x = eqa[p][k & (EQD - 1)];
            if (x.is_ext && x.tracked && !eset[p][x.seq] && x.seq != s) begin n_reorder++; break; end
          end
          if (trc_we[b]) begin refm[b][w] = (refm[b][w] & ~lanes(be)) | (trc_wdata[b*DW +: DW] & lanes(be)); ed[p][s] = '0; end
          else ed[p][s] = refm[b][w] & lanes(be);
          eerr[p][s] = 0; eset[p][s] = 1;
        end
        // DRAM command handshake (controller executes in order)
        if (ext_cmd_valid && ext_cmd_ready) begin
          int p, s; bit err;
          p = ext_cmd_tag[SW +: PW]; s = ext_cmd_tag[SW-1:0];
          err = inj_en && (ext_cmd_addr == inj_addr);
          if (!err && ext_cmd_we)
            erefm[ext_cmd_addr] = (erefm[ext_cmd_addr] & ~lanes(ext_cmd_wstrb)) | (ext_cmd_wdata & lanes(ext_cmd_wstrb));
          ed[p][s] = (err || ext_cmd_we) ? '0 : (erefm[ext_cmd_addr] & lanes(ext_cmd_wstrb));
          eerr[p][s] = err; eset[p][s] = 1;
          if (ext_cmd_we) o_ext_wr++; else o_ext_rd++;
        end
        // acceptance
        for (int p = 0; p < NP; p++) if (m_req_valid[p] && m_req_ready[p]) begin
          req_t r; exp_t e; logic [7:0] be; bit is_ext;
          r = rqa[p][rq_h[p] & (RQD - 1)]; rq_h[p]++;
          e.err = model_err(p, r, be, is_ext);
          e.rd = !r.we; e.seq = tseq[p]; e.tracked = (e.err == RSP_OK); e.is_ext = is_ext;
          if (is_ext && e.err == RSP_OK) o_ext_acc++;
          eset[p][tseq[p]] = 0;
          eqa[p][eq_t[p] & (EQD - 1)] = e; eq_t[p]++;
          tseq[p] = tseq[p] + 1'b1;
        end
        // responses
        for (int p = 0; p < NP; p++) if (m_rsp_valid[p] && m_rsp_ready[p]) begin
          exp_t e; logic [2:0] xerr; logic [63:0] xd;
          tb_checks++;
          if (eq_n(p) == 0) begin tb_errors++; $display("[FAIL] port %0d unexpected response", p); end
          else begin
            e = eqa[p][eq_h[p] & (EQD - 1)]; eq_h[p]++;
            xerr = e.err; xd = '0;
            if (e.tracked) begin
              if (!eset[p][e.seq]) begin tb_errors++; $display("[FAIL] port %0d response before issue", p); end
              if (eerr[p][e.seq]) xerr = RSP_EXT;
              if (e.rd) xd = ed[p][e.seq];
            end
            if (xerr == RSP_EXT) o_ext_err_rsp++;
            if (m_rsp_err[p*3 +: 3] !== xerr || m_rsp_rdata[p*DW +: DW] !== xd || m_rsp_ecc_corr[p]) begin
              tb_errors++;
              if (tb_errors < 30) $display("[FAIL] %0t port %0d seq %0d ext=%0b: err %0d/%0d data %h/%h", $time, p, e.seq, e.is_ext,
                                           m_rsp_err[p*3 +: 3], xerr, m_rsp_rdata[p*DW +: DW], xd);
            end
          end
        end
      end
    end
  end

  task automatic push(input int p, input logic [31:0] a, input logic [2:0] sz, input logic we,
                      input logic [63:0] wd = '0, input logic [7:0] st = 8'hFF);
    req_t r; r.addr = a; r.size = sz; r.we = we; r.wdata = wd; r.wstrb = st;
    rqa[p][rq_t[p] & (RQD - 1)] = r; rq_t[p]++;
  endtask
  task automatic wait_idle();
    int c; bit idle; c = 0;
    do begin @(posedge clk); c++; idle = 1; for (int p = 0; p < NP; p++) if (rq_n(p) != 0 || eq_n(p) != 0) idle = 0; end
    while (!idle && c < 500000);
    `CHECK(idle, "traffic drained")
    repeat (3) @(posedge clk);
  endtask
  task automatic csr_wr(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); csr_valid = 1; csr_we = 1; csr_addr = a; csr_wdata = d; @(negedge clk); csr_valid = 0; csr_we = 0;
  endtask
  task automatic csr_rd(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk); csr_valid = 1; csr_we = 0; csr_addr = a; @(negedge clk); csr_valid = 0; d = csr_rdata;
  endtask

  logic [31:0] v;
  initial begin
    bm_cmd_valid = 0; bm_cmd_op = 0; bm_cmd_requester = 0; bm_cmd_id = 0; bm_cmd_btype = 0; bm_cmd_start = 0;
    bm_cmd_len = 0; bm_cmd_owner = 0; bm_cmd_rd_mask = 0; bm_cmd_wr_mask = 0;
    csr_valid = 0; csr_we = 0; csr_addr = 0; csr_wdata = 0; inj_en = 0; inj_addr = 0;
    for (int p = 0; p < NP; p++) begin rq_h[p] = 0; rq_t[p] = 0; eq_h[p] = 0; eq_t[p] = 0; tseq[p] = 0; bp_mode[p] = 0; end
    for (int b = 0; b < NBANK; b++) for (int w = 0; w < DEPTH; w++) refm[b][w] = 0;
    for (int i = 0; i < EWORDS; i++) erefm[i] = 0;
    ext_rd_m = 5'b00001; ext_wr_m = 5'b00001;
    o_ext_acc = 0; o_ext_rd = 0; o_ext_wr = 0; o_ext_err_rsp = 0; n_reorder = 0;
    repeat (4) @(posedge clk); rst_n = 1;
    while (!init_done) @(posedge clk);
    // one all-access buffer over the SRAM window
    @(negedge clk);
    bm_cmd_valid = 1; bm_cmd_op = BM_ALLOC; bm_cmd_requester = DOM_KEYSTONE; bm_cmd_len = LEN_W'(WIN);
    bm_cmd_owner = DOM_KEYSTONE; bm_cmd_rd_mask = '1; bm_cmd_wr_mask = '1; bm_cmd_btype = BT_DMA_STAGING;
    @(negedge clk); bm_cmd_valid = 0;
    while (!bm_rsp_valid) @(posedge clk);
    `CHECK_EQ(bm_rsp_status, BMS_OK, "shared buffer allocated")

    // ---- 1. external permission defaults ----
    csr_rd(12'h004, v);
    `CHECK(v[21], "CONFIG reports EXT_EN")
    for (int p = 0; p < NP; p++) begin push(p, EB + 32'(p * 8), 3'd3, 1'b1, 64'(p + 100)); push(p, EB + 32'(p * 8), 3'd3, 1'b0); end
    wait_idle();
    csr_wr(12'h018, {19'b0, 5'b11111, 3'b0, 5'b11111});
    ext_rd_m = '1; ext_wr_m = '1;

    // ---- 2. mixed SRAM / DRAM random traffic ----
    for (int p = 0; p < NP; p++) bp_mode[p] = p % 2;
    csr_wr(12'h038, 32'h1);
    o_ext_rd = 0; o_ext_wr = 0; o_ext_acc = 0;
    for (int k = 0; k < 600; k++) for (int p = 0; p < NP; p++) begin
      logic [31:0] a; int sz; logic we;
      sz = $urandom_range(0, 3); we = $urandom_range(0, 1);
      if ($urandom_range(0, 2) == 0) a = EB + 32'($urandom_range(0, 2047) << 3) + 32'(($urandom_range(0, 7) >> (3 - sz)) << sz);
      else                           a = SB + 32'($urandom_range(0, WIN / 8 - 1) << 3) + 32'(($urandom_range(0, 7) >> (3 - sz)) << sz);
      push(p, a, 3'(sz), we, {$urandom, $urandom}, 8'($urandom) | 8'h1);
    end
    wait_idle();
    `CHECK(n_reorder > 100, $sformatf("SRAM completions overtook older DRAM accesses (%0d times); ROB kept order", n_reorder))
    $display("mixed traffic: %0d DRAM accesses, %0d reorder events absorbed by the ROBs", o_ext_acc, n_reorder);

    // ---- 4. counters ----
    csr_rd(12'h400 + 8 * 4, v);  `CHECK_EQ(int'(v), o_ext_rd, "ext read counter")
    csr_rd(12'h400 + 9 * 4, v);  `CHECK_EQ(int'(v), o_ext_wr, "ext write counter")
    csr_rd(12'h400 + 12 * 4, v); `CHECK_EQ(int'(v), o_ext_acc, "ext response counter")
    begin
      logic [31:0] lsum; csr_rd(12'h400 + 11 * 4, lsum);
      `CHECK(lsum >= 9 * v, "ext latency sum >= count x minimum modelled latency (write hit = 9)")
      $display("ext mean latency (adapter accept -> completion) = %0d.%02d cycles", lsum / v, ((lsum % v) * 100) / v);
    end

    // ---- 3. controller error ----
    for (int p = 0; p < NP; p++) bp_mode[p] = 0;
    inj_en = 1; inj_addr = 13'd9;
    push(1, EB + 72, 3'd3, 1'b0);
    push(1, SB + 8, 3'd3, 1'b0);
    wait_idle();
    `CHECK_EQ(o_ext_err_rsp, 1, "controller error returned as RSP_EXT")
    csr_rd(12'h008, v);
    `CHECK(v[3], "sticky external-error status")
    csr_rd(12'h400 + 13 * 4, v);
    `CHECK_EQ(v, 32'd1, "ext error counter")
    inj_en = 0;
    `TB_FINISH("tb_iron_memory_ext")
  end
  initial begin #50ms; $display("TB_RESULT tb_iron_memory_ext FAIL timeout"); $finish; end
endmodule
