#!/usr/bin/env python3
"""
SilicaFlux Albion -- Project 84 IRONMEMORY regression runner.

Builds and runs every testbench with Verilator (primary simulator), enforces
the brief's ordering gate (external-memory tests run only after the complete
local-memory suite passes), runs the performance scenarios and regenerates
docs/iron_memory/perf_report.md from the measured counters.

Usage:
  python3 tests/iron_memory/run_tests.py            # full regression + perf
  python3 tests/iron_memory/run_tests.py --quick    # skip perf
  python3 tests/iron_memory/run_tests.py --icarus   # also cross-check a subset with Icarus Verilog
  python3 tests/iron_memory/run_tests.py --only tb_memory_map
  python3 tests/iron_memory/run_tests.py --synth    # also run syn/run_yosys.sh (needs sv2v + yosys)
"""
import argparse, json, os, re, shutil, subprocess, sys, time

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
RTL = os.path.join(ROOT, 'rtl', 'albion')
TST = os.path.join(ROOT, 'tests', 'iron_memory')
BUILD = os.path.join(ROOT, 'build')

CORE = ['sf_iron_pkg.sv', 'sf_iron_secded.sv', 'sf_iron_sram_generic.sv', 'sf_iron_sram_fpga.sv',
        'sf_iron_sram_asic.sv', 'sf_iron_bank_adapter.sv', 'sf_iron_bank_arbiter.sv', 'sf_iron_rob.sv',
        'sf_iron_memory_map.sv', 'sf_iron_buffer_manager.sv', 'sf_iron_extmem_adapter.sv', 'sf_iron_memory.sv']
rtl = lambda names: [os.path.join(RTL, n) for n in names]

# (name, top, rtl files, defines, suite)
TESTS = [
    ('secded',              'tb_secded',          rtl(['sf_iron_pkg.sv', 'sf_iron_secded.sv']), [], 'local'),
    ('memory_map',          'tb_memory_map',      rtl(['sf_iron_pkg.sv', 'sf_iron_memory_map.sv']), [], 'local'),
    ('bank_adapter',        'tb_bank_adapter',    rtl(CORE[:6]), [], 'local'),
    ('buffer_manager',      'tb_buffer_manager',  rtl(['sf_iron_pkg.sv', 'sf_iron_buffer_manager.sv']), [], 'local'),
    ('iron_memory',         'tb_iron_memory',     rtl(CORE), [], 'local'),
    ('iron_memory_rl2',     'tb_iron_memory',     rtl(CORE), ['TB_RL2'], 'local'),
    ('iron_memory_noecc',   'tb_iron_memory',     rtl(CORE), ['TB_NOECC'], 'local'),
    ('iron_memory_fpga',    'tb_iron_memory',     rtl(CORE), ['TB_BACKEND=1'], 'local'),
    ('iron_memory_asic',    'tb_iron_memory',     rtl(CORE), ['TB_BACKEND=2'], 'local'),
    ('iron_memory_contig',  'tb_iron_memory',     rtl(CORE), ['TB_CONTIG'], 'local'),
    ('iron_memory_asic_rl2_contig', 'tb_iron_memory', rtl(CORE), ['TB_RL2', 'TB_BACKEND=2', 'TB_CONTIG'], 'local'),
    ('wide_port',           'tb_wide_port',       rtl(CORE + ['sf_iron_wide_port.sv']), [], 'local'),
    # ---- gate: external memory only after the local suite is green ----
    ('extmem',              'tb_extmem',          rtl(['sf_iron_pkg.sv', 'sf_iron_extmem_adapter.sv', 'sim/sf_iron_simdram.sv']), [], 'ext'),
    ('iron_memory_ext',     'tb_iron_memory_ext', rtl(CORE + ['sim/sf_iron_simdram.sv']), [], 'ext'),
]
PERF = [
    ('perf_ecc_on',  'tb_perf', rtl(CORE), [], 'perf'),
    ('perf_ecc_off', 'tb_perf', rtl(CORE), ['TB_NOECC'], 'perf'),
]
# Icarus cross-check subset (Icarus is ~30x slower; the system TBs use
# constructs Icarus 12 does not support, so only unit-level TBs are included)
# (Icarus 12's vvp runtime aborts with an internal assertion on the
# buffer-manager and system testbenches; those run on Verilator only.)
ICARUS = [('memory_map', 'tb_memory_map', rtl(['sf_iron_pkg.sv', 'sf_iron_memory_map.sv'])),
          ('secded', 'tb_secded', rtl(['sf_iron_pkg.sv', 'sf_iron_secded.sv']))]

VFLAGS = ['--binary', '-j', '8', '--timing', '--assert', '-Wno-fatal', '-Wno-lint', '-Wno-style',
          '-Wno-TIMESCALEMOD', '-Wno-UNOPTFLAT']


def build_and_run(name, top, files, defines, timeout=3600):
    obj = os.path.join(BUILD, 'obj_' + name)
    shutil.rmtree(obj, ignore_errors=True)
    cmd = ['verilator'] + VFLAGS + [f'-I{RTL}', f'-I{os.path.join(RTL, "sim")}', f'-I{TST}',
           '--top-module', top, '-Mdir', obj, '-o', 'tb'] + [f'-D{d}' for d in defines] + files + \
          [os.path.join(TST, top + '.sv')]
    t0 = time.time()
    b = subprocess.run(cmd, capture_output=True, text=True)
    if b.returncode != 0:
        return dict(name=name, status='BUILD_FAIL', log=b.stdout[-3000:] + b.stderr[-3000:], seconds=time.time() - t0)
    r = subprocess.run([os.path.join(obj, 'tb')], capture_output=True, text=True, timeout=timeout, cwd=obj)
    out = r.stdout + r.stderr
    open(os.path.join(BUILD, name + '.log'), 'w').write(out)
    m = re.search(r'TB_RESULT (\S+) (PASS|FAIL)(.*)', out)
    asserts = len(re.findall(r'%Error|Assertion failed', out))
    status = m.group(2) if m else 'NO_RESULT'
    if asserts and status == 'PASS':
        status = 'FAIL'
    checks = re.search(r'checks=(\d+)', out)
    return dict(name=name, top=top, defines=defines, status=status, checks=int(checks.group(1)) if checks else 0,
                assertion_errors=asserts, seconds=round(time.time() - t0, 1), output=out)


def run_icarus(name, top, files):
    vvp = os.path.join(BUILD, f'icarus_{name}.vvp')
    b = subprocess.run(['iverilog', '-g2012', f'-I{RTL}', f'-I{TST}', '-o', vvp] + files +
                       [os.path.join(TST, top + '.sv')], capture_output=True, text=True)
    if b.returncode != 0:
        return dict(name='icarus_' + name, status='BUILD_FAIL', log=b.stderr[-2000:])
    r = subprocess.run(['vvp', '-n', vvp], capture_output=True, text=True, timeout=3600)
    m = re.search(r'TB_RESULT (\S+) (PASS|FAIL)', r.stdout)
    checks = re.search(r'checks=(\d+)', r.stdout)
    return dict(name='icarus_' + name, status=m.group(2) if m else 'NO_RESULT',
                checks=int(checks.group(1)) if checks else 0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--icarus', action='store_true')
    ap.add_argument('--only')
    ap.add_argument('--synth', action='store_true')
    a = ap.parse_args()
    os.makedirs(BUILD, exist_ok=True)
    results = []
    local_ok = True
    for name, top, files, defs, suite in TESTS:
        if a.only and a.only not in (name, top):
            continue
        if suite == 'ext' and not local_ok:
            results.append(dict(name=name, status='SKIPPED_GATE', checks=0, seconds=0))
            print(f'{name:32s} SKIPPED (local suite not green: external memory is gated)')
            continue
        r = build_and_run(name, top, files, defs)
        results.append(r)
        if suite == 'local' and r['status'] != 'PASS':
            local_ok = False
        print(f"{name:32s} {r['status']:10s} checks={r.get('checks', 0):<7d} {r.get('seconds', 0):6.1f}s")
        if r['status'] != 'PASS':
            print((r.get('log') or r.get('output', ''))[-2500:])
    if not a.only:
        u = subprocess.run([sys.executable, os.path.join(TST, 'test_sram_area_report.py')], capture_output=True, text=True)
        m = re.search(r'Ran (\d+) test', u.stderr)
        r = dict(name='sram_area_tool', status='PASS' if u.returncode == 0 else 'FAIL', checks=int(m.group(1)) if m else 0)
        results.append(r)
        print(f"{'sram_area_tool':32s} {r['status']:10s} checks={r['checks']}")
    perf = []
    if not a.quick and not a.only:
        for name, top, files, defs, _ in PERF:
            r = build_and_run(name, top, files, defs)
            results.append({k: v for k, v in r.items() if k != 'output'})
            print(f"{name:32s} {r['status']:10s} checks={r.get('checks', 0):<7d} {r.get('seconds', 0):6.1f}s")
            for line in r.get('output', '').splitlines():
                if line.startswith('PERF_JSON '):
                    perf.append(json.loads(line[len('PERF_JSON '):]))
        json.dump(perf, open(os.path.join(BUILD, 'perf.json'), 'w'), indent=1)
        sys.path.insert(0, os.path.join(ROOT, 'tools'))
        import perf_report
        perf_report.write_report(perf, os.path.join(ROOT, 'docs', 'iron_memory', 'perf_report.md'))
        print('perf report written to docs/iron_memory/perf_report.md')
    if a.icarus:
        for name, top, files in ICARUS:
            r = run_icarus(name, top, files)
            results.append(r)
            print(f"{r['name']:32s} {r['status']:10s} checks={r.get('checks', 0)}")
    if a.synth:
        y = subprocess.run(['bash', os.path.join(ROOT, 'syn', 'run_yosys.sh')], capture_output=True, text=True,
                           env=dict(os.environ, OUT=os.path.join(BUILD, 'syn')))
        lat = re.search(r'latches inferred: (\d+)', y.stdout)
        ok = y.returncode == 0 and lat is not None and lat.group(1) == '0'
        results.append(dict(name='yosys_generic_synth', status='PASS' if ok else 'FAIL', checks=1))
        print(f"{'yosys_generic_synth':32s} {'PASS' if ok else 'FAIL':10s} {y.stdout.strip().splitlines()[0] if y.stdout else y.stderr[-300:]}")
    for r in results:
        r.pop('output', None)
    json.dump(dict(timestamp=time.strftime('%Y-%m-%d %H:%M:%S'), results=results),
              open(os.path.join(BUILD, 'regression_report.json'), 'w'), indent=1)
    failed = [r for r in results if r['status'] not in ('PASS',)]
    total = sum(r.get('checks', 0) for r in results)
    print(f"\n{len(results) - len(failed)}/{len(results)} passed, {total} checks")
    return 1 if failed else 0


if __name__ == '__main__':
    sys.exit(main())
