// =============================================================================
// tb_secded : exhaustive single-bit and double-bit error checks for the
// SECDED engine at DW=64 (72,64) and DW=128 (137,128).
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_secded;
  int tb_errors = 0;
  int tb_checks = 0;

  localparam int DW0 = 64;
  localparam int R0  = sf_iron_pkg::secded_r(DW0);
  localparam int CW0 = DW0 + R0 + 1;
  localparam int DW1 = 128;
  localparam int R1  = sf_iron_pkg::secded_r(DW1);
  localparam int CW1 = DW1 + R1 + 1;

  logic [DW0-1:0] d0;      logic [CW0-1:0] c0, c0x;
  logic [DW0-1:0] q0;      logic ce0, ue0;   logic [R0:0] s0;
  logic [DW1-1:0] d1;      logic [CW1-1:0] c1, c1x;
  logic [DW1-1:0] q1;      logic ce1, ue1;   logic [R1:0] s1;

  sf_iron_secded_enc #(.DW(DW0)) u_enc0 (.data(d0), .cw(c0));
  sf_iron_secded_dec #(.DW(DW0)) u_dec0 (.cw(c0x), .data(q0), .ce(ce0), .ue(ue0), .syndrome(s0));
  sf_iron_secded_enc #(.DW(DW1)) u_enc1 (.data(d1), .cw(c1));
  sf_iron_secded_dec #(.DW(DW1)) u_dec1 (.cw(c1x), .data(q1), .ce(ce1), .ue(ue1), .syndrome(s1));

  int n_single, n_double;

  task automatic run64(input logic [63:0] pattern);
    d0 = pattern; #1;
    c0x = c0; #1;
    `CHECK(q0 === pattern && !ce0 && !ue0, "64: clean codeword must decode cleanly")
    for (int i = 0; i < CW0; i++) begin
      c0x = c0 ^ (72'(1) << i); #1;
      n_single++;
      `CHECK(q0 === pattern && ce0 && !ue0, $sformatf("64: single flip bit %0d not corrected", i))
    end
    for (int i = 0; i < CW0; i++) begin
      for (int j = i + 1; j < CW0; j++) begin
        c0x = c0 ^ (72'(1) << i) ^ (72'(1) << j); #1;
        n_double++;
        `CHECK(ue0 && !ce0, $sformatf("64: double flip %0d,%0d not detected", i, j))
      end
    end
  endtask

  task automatic run128(input logic [127:0] pattern);
    d1 = pattern; #1;
    c1x = c1; #1;
    `CHECK(q1 === pattern && !ce1 && !ue1, "128: clean codeword must decode cleanly")
    for (int i = 0; i < CW1; i++) begin
      c1x = c1 ^ (137'(1) << i); #1;
      n_single++;
      `CHECK(q1 === pattern && ce1 && !ue1, $sformatf("128: single flip bit %0d not corrected", i))
    end
    for (int i = 0; i < CW1; i++) begin
      for (int j = i + 1; j < CW1; j++) begin
        c1x = c1 ^ (137'(1) << i) ^ (137'(1) << j); #1;
        n_double++;
        `CHECK(ue1 && !ce1, $sformatf("128: double flip %0d,%0d not detected", i, j))
      end
    end
  endtask

  initial begin
    n_single = 0; n_double = 0;
    `CHECK_EQ(CW0, 72, "(72,64) codeword width")
    `CHECK_EQ(CW1, 137, "(137,128) codeword width")
    // encoding of zero must be the all-zero codeword (used by init sweep)
    d0 = '0; #1;
    `CHECK_EQ(c0, 72'h0, "enc(0) == 0")
    run64(64'h0000_0000_0000_0000);
    run64(64'hFFFF_FFFF_FFFF_FFFF);
    run64(64'hA5A5_5A5A_DEAD_BEEF);
    for (int t = 0; t < 4; t++) run64({$urandom, $urandom});
    run128(128'h0);
    run128({4{32'hC0FF_EE11}});
    run128({$urandom, $urandom, $urandom, $urandom});
    $display("secded: %0d single-bit and %0d double-bit cases exercised", n_single, n_double);
    `TB_FINISH("tb_secded")
  end
endmodule
