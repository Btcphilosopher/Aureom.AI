// =============================================================================
// tb_buffer_manager : allocation, exhaustion, fragmentation, ALLOC_AT,
// ownership rules, permission matrix, boundary violations, error attribution,
// drain-before-free / transfer and raw-access drain before allocation.
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_buffer_manager;
  import sf_iron_pkg::*;
  int tb_errors = 0;
  int tb_checks = 0;

  localparam int AW = 32, NP = 5, NDESC = 8, GRAN = 64;
  localparam longint SBYTES = 1024;               // 16 granules
  localparam logic [31:0] SB = 32'h1000_0000;
  localparam int IDW = 3, LEN_W = 11, ND = 5;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic cmd_valid, cmd_ready; logic [2:0] cmd_op, cmd_req, cmd_btype, cmd_owner;
  logic [IDW-1:0] cmd_id; logic [AW-1:0] cmd_start; logic [LEN_W-1:0] cmd_len; logic [ND-1:0] cmd_rd, cmd_wr;
  logic rsp_valid, rsp_in_use; logic [3:0] rsp_status; logic [IDW-1:0] rsp_id; logic [2:0] rsp_btype, rsp_owner;
  logic [AW-1:0] rsp_start; logic [LEN_W-1:0] rsp_len; logic [ND-1:0] rsp_rd, rsp_wr; logic [7:0] rsp_err;
  logic raw_en; logic [NP*AW-1:0] chk_lo, chk_hi; logic [NP-1:0] chk_we, chk_hit, chk_raw, chk_allow, chk_fire, ev_viol;
  logic [NP*3-1:0] chk_err; logic [NP*IDW-1:0] chk_id; logic raw_block;
  logic [3:0] dec_valid, dec_ce, dec_ue, dec_raw; logic [4*IDW-1:0] dec_id;
  logic [IDW:0] desc_in_use; logic [4:0] gran_in_use;
  logic ev_ok, ev_nodesc, ev_nospace, ev_free;

  sf_iron_buffer_manager #(.AW(AW), .NUM_PORTS(NP), .NUM_DESC(NDESC), .GRAN_BYTES(GRAN),
    .SRAM_BASE(SB), .SRAM_BYTES(SBYTES), .NUM_DEC(4)) dut (
    .clk, .rst_n, .cmd_valid, .cmd_ready, .cmd_op, .cmd_requester(cmd_req), .cmd_id, .cmd_btype,
    .cmd_start, .cmd_len, .cmd_owner, .cmd_rd_mask(cmd_rd), .cmd_wr_mask(cmd_wr),
    .rsp_valid, .rsp_status, .rsp_id, .rsp_in_use, .rsp_btype, .rsp_start, .rsp_len, .rsp_owner,
    .rsp_rd_mask(rsp_rd), .rsp_wr_mask(rsp_wr), .rsp_err_bits(rsp_err),
    .raw_en, .chk_lo, .chk_hi, .chk_we, .chk_hit, .chk_raw, .chk_allow, .chk_err, .chk_id, .chk_fire,
    .raw_block, .dec_valid, .dec_id, .dec_ce, .dec_ue, .dec_raw,
    .desc_in_use, .gran_in_use, .ev_alloc_ok(ev_ok), .ev_alloc_nodesc(ev_nodesc),
    .ev_alloc_nospace(ev_nospace), .ev_free, .ev_viol);

  logic [3:0] st; logic [IDW-1:0] rid; logic [AW-1:0] rstart; int cmd_cycles;

  task automatic cmd(input logic [2:0] op, input logic [2:0] req, input int id, input logic [2:0] bt,
                     input logic [AW-1:0] start, input int len, input logic [2:0] owner,
                     input logic [ND-1:0] rd, input logic [ND-1:0] wr);
    @(negedge clk);
    while (!cmd_ready) @(negedge clk);
    cmd_valid = 1; cmd_op = op; cmd_req = req; cmd_id = IDW'(id); cmd_btype = bt; cmd_start = start;
    cmd_len = LEN_W'(len); cmd_owner = owner; cmd_rd = rd; cmd_wr = wr;
    @(negedge clk); cmd_valid = 0;
    cmd_cycles = 0;
    while (!rsp_valid) begin @(posedge clk); #1; cmd_cycles++; end
    st = rsp_status; rid = rsp_id; rstart = rsp_start;
    @(posedge clk);
  endtask
  task automatic alloc(input logic [2:0] req, input int len, input logic [2:0] owner, input logic [ND-1:0] rd, input logic [ND-1:0] wr);
    cmd(BM_ALLOC, req, 0, BT_PACKET, '0, len, owner, rd, wr);
  endtask

  // set up one port's check inputs (combinational read-back)
  task automatic probe(input int p, input logic [AW-1:0] lo, input logic [AW-1:0] hi, input logic we);
    chk_lo[p*AW +: AW] = lo; chk_hi[p*AW +: AW] = hi; chk_we[p] = we; #1;
  endtask
  function automatic logic [2:0] perr(input int p); return chk_err[p*3 +: 3]; endfunction

  int ids [NDESC];
  logic [IDW-1:0] a_id, b_id, c_id2, d_id;

  initial begin
    cmd_valid = 0; cmd_op = 0; cmd_req = 0; cmd_id = 0; cmd_btype = 0; cmd_start = 0; cmd_len = 0;
    cmd_owner = 0; cmd_rd = 0; cmd_wr = 0; raw_en = 0; chk_lo = 0; chk_hi = 0; chk_we = 0; chk_fire = 0;
    dec_valid = 0; dec_id = 0; dec_ce = 0; dec_ue = 0; dec_raw = 0;
    repeat (3) @(posedge clk); rst_n = 1; @(posedge clk);

    // ---- argument validation -------------------------------------------------
    alloc(DOM_KEYSTONE, 0, DOM_BRIDGE, 5'h1F, 5'h1F);
    `CHECK_EQ(st, BMS_BADLEN, "zero length rejected")
    alloc(DOM_KEYSTONE, 1025, DOM_BRIDGE, 5'h1F, 5'h1F);
    `CHECK_EQ(st, BMS_BADLEN, "length larger than pool rejected")
    cmd(BM_ALLOC, DOM_KEYSTONE, 0, 3'd7, '0, 64, DOM_BRIDGE, 5'h1F, 5'h1F);
    `CHECK_EQ(st, BMS_BADARG, "bad buffer type rejected")
    alloc(DOM_KEYSTONE, 64, 3'd6, 5'h1F, 5'h1F);
    `CHECK_EQ(st, BMS_BADARG, "bad owner domain rejected")
    alloc(DOM_BRIDGE, 64, DOM_PACKET, 5'h1F, 5'h1F);
    `CHECK_EQ(st, BMS_NOTOWNER, "non-supervisor may not allocate for another domain")
    `CHECK_EQ(desc_in_use, 4'd0, "failed commands allocate nothing")

    // ---- first-fit allocation + query ------------------------------------------
    alloc(DOM_BRIDGE, 200, DOM_BRIDGE, 5'b01010, 5'b00010);        // 4 granules
    `CHECK(st == BMS_OK && rstart == SB, "first buffer at window base")
    a_id = rid;
    cmd(BM_QUERY, DOM_PACKET, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK(st == BMS_OK && rsp_in_use && rsp_len == 200 && rsp_owner == DOM_BRIDGE && rsp_btype == BT_PACKET, "query returns descriptor")
    `CHECK(rsp_rd == 5'b01010 && rsp_wr == 5'b00010, "query returns permission masks")
    alloc(DOM_KEYSTONE, 64, DOM_COMPUTE, 5'b01000, 5'b01000);       // 1 granule
    `CHECK(st == BMS_OK && rstart == SB + 256, "second buffer follows first (first-fit)")
    b_id = rid;
    `CHECK_EQ(gran_in_use, 5'd5, "granules in use")

    // ---- permission matrix -----------------------------------------------------
    // buffer A [SB, SB+199]: read by Bridge(1)+Compute(3), write by Bridge only
    for (int p = 0; p < NP; p++) begin
      probe(p, SB + 8, SB + 15, 1'b0);
      `CHECK_EQ(chk_allow[p], (p == 1 || p == 3), $sformatf("read permission port %0d", p))
      `CHECK_EQ(perr(p), (p == 1 || p == 3) ? RSP_OK : RSP_PERM, $sformatf("read error code port %0d", p))
      probe(p, SB + 8, SB + 15, 1'b1);
      `CHECK_EQ(chk_allow[p], (p == 1), $sformatf("write permission port %0d", p))
      `CHECK(chk_hit[p] == (p == 1) && (p != 1 || chk_id[p*IDW +: IDW] == a_id), $sformatf("hit/id port %0d", p))
    end
    // last byte of A (offset 199) is inside, 200 is outside
    probe(1, SB + 192, SB + 199, 1'b1);
    `CHECK(chk_allow[1] && perr(1) == RSP_OK, "last 8 bytes of buffer allowed")
    probe(1, SB + 196, SB + 203, 1'b1);
    `CHECK(!chk_allow[1] && perr(1) == RSP_BOUNDS, "access straddling buffer end is BOUNDS")
    probe(1, SB + 200, SB + 207, 1'b0);
    `CHECK(!chk_allow[1] && perr(1) == RSP_PERM, "slack after buffer is unmanaged -> PERM for non-supervisor")
    // unmanaged memory and the Keystone raw path
    probe(0, SB + 512, SB + 519, 1'b1);
    `CHECK(!chk_allow[0] && perr(0) == RSP_PERM, "Keystone raw access denied while raw_en=0")
    raw_en = 1; #1;
    `CHECK(chk_allow[0] && chk_raw[0] && !chk_hit[0], "Keystone raw access allowed when raw_en=1")
    probe(2, SB + 512, SB + 519, 1'b0);
    `CHECK(!chk_allow[2] && perr(2) == RSP_PERM, "non-supervisor never gets raw access")
    probe(0, SB + 8, SB + 15, 1'b0);
    `CHECK(!chk_allow[0] && perr(0) == RSP_PERM, "Keystone inside a buffer obeys the buffer masks")

    // ---- error attribution + CLEAR_ERR -------------------------------------------
    probe(2, SB + 16, SB + 23, 1'b1);           // PacketForge write into A: violation
    @(negedge clk); chk_fire = 5'b00100; @(negedge clk); chk_fire = 0;
    probe(1, SB + 196, SB + 203, 1'b0);         // straddle
    @(negedge clk); chk_fire = 5'b00010; @(negedge clk); chk_fire = 0;
    cmd(BM_QUERY, DOM_KEYSTONE, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK_EQ(rsp_err, 8'b0000_0110, "sticky WR_PERM and BOUNDS recorded on buffer A")
    cmd(BM_CLEAR_ERR, DOM_PACKET, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK_EQ(st, BMS_NOTOWNER, "non-owner may not clear errors")
    cmd(BM_CLEAR_ERR, DOM_BRIDGE, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK(st == BMS_OK && rsp_err == 8'h00, "owner clears errors")
    // ECC attribution from bank completions (two completions, one counted)
    probe(1, SB + 0, SB + 7, 1'b0);
    @(negedge clk); chk_fire = 5'b00010; @(negedge clk); chk_fire = 0;
    @(negedge clk); dec_valid = 4'b0100; dec_id = {4{a_id}}; dec_ue = 4'b0100; @(negedge clk); dec_valid = 0; dec_ue = 0;
    cmd(BM_QUERY, DOM_KEYSTONE, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK_EQ(rsp_err[BERR_ECC_UE], 1'b1, "uncorrectable ECC attributed to buffer")

    // ---- FREE / TRANSFER ownership -------------------------------------------------
    cmd(BM_FREE, DOM_PACKET, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK_EQ(st, BMS_NOTOWNER, "non-owner may not free")
    cmd(BM_TRANSFER, DOM_BRIDGE, a_id, 0, '0, 0, DOM_COMPUTE, 5'b01000, 5'b01000);
    `CHECK_EQ(st, BMS_OK, "owner transfers buffer to ComputeWorks")
    probe(1, SB + 8, SB + 15, 1'b1);
    `CHECK(!chk_allow[1], "previous owner loses write access after transfer")
    probe(3, SB + 8, SB + 15, 1'b1);
    `CHECK(chk_allow[3], "new owner gains write access after transfer")
    cmd(BM_FREE, DOM_BRIDGE, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK_EQ(st, BMS_NOTOWNER, "previous owner may no longer free")
    cmd(BM_TRANSFER, DOM_COMPUTE, a_id, 0, '0, 0, 3'd5, 0, 0);
    `CHECK_EQ(st, BMS_BADARG, "transfer to invalid domain rejected")

    // ---- drain-before-free ---------------------------------------------------------
    probe(3, SB + 32, SB + 39, 1'b1);
    @(negedge clk); chk_fire = 5'b01000; @(negedge clk); chk_fire = 0;   // one access in flight
    fork
      cmd(BM_FREE, DOM_COMPUTE, a_id, 0, '0, 0, 0, 0, 0);
      begin
        repeat (6) @(negedge clk);
        probe(3, SB + 40, SB + 47, 1'b1);
        `CHECK(!chk_allow[3] && perr(3) == RSP_PERM, "accesses to a draining buffer are refused")
        `CHECK(!rsp_valid, "FREE waits for the in-flight access")
        dec_valid = 4'b0001; dec_id = {4{a_id}}; @(negedge clk); dec_valid = 0;
      end
    join
    `CHECK(st == BMS_OK && cmd_cycles >= 6, "FREE completes after the access drains")
    `CHECK_EQ(gran_in_use, 5'd1, "granules released")
    cmd(BM_FREE, DOM_COMPUTE, a_id, 0, '0, 0, 0, 0, 0);
    `CHECK_EQ(st, BMS_BADID, "double free rejected")

    // ---- descriptor exhaustion -------------------------------------------------------
    begin
      int n_ok; n_ok = 0;
      for (int i = 0; i < NDESC + 2; i++) begin
        alloc(DOM_KEYSTONE, 32, DOM_PACKET, 5'b00100, 5'b00100);
        if (st == BMS_OK) begin ids[n_ok] = rid; n_ok++; end
        else `CHECK_EQ(st, BMS_NODESC, "exhaustion reports NODESC")
      end
      `CHECK_EQ(n_ok, NDESC - 1, "exactly NUM_DESC buffers live (one was already held)")
      `CHECK_EQ(desc_in_use, 4'(NDESC), "descriptor table full")
      for (int i = 0; i < n_ok; i++) cmd(BM_FREE, DOM_PACKET, ids[i], 0, '0, 0, 0, 0, 0);
      `CHECK_EQ(desc_in_use, 4'd1, "descriptors returned")
    end

    // ---- space exhaustion and fragmentation -------------------------------------------
    // pool: granule 4 holds buffer B; fill the rest: [0..3]=A2 [5..8]=C [9..12]=D [13..15]=E
    alloc(DOM_KEYSTONE, 256, DOM_PACKET, 5'h1F, 5'h1F); a_id = rid;
    `CHECK(st == BMS_OK && rstart == SB, "refill granules 0-3")
    alloc(DOM_KEYSTONE, 256, DOM_PACKET, 5'h1F, 5'h1F); c_id2 = rid;
    `CHECK(st == BMS_OK && rstart == SB + 320, "first fit skips the live granule")
    alloc(DOM_KEYSTONE, 256, DOM_PACKET, 5'h1F, 5'h1F); d_id = rid;
    alloc(DOM_KEYSTONE, 192, DOM_PACKET, 5'h1F, 5'h1F);
    `CHECK(st == BMS_OK && rstart == SB + 832, "last three granules")
    `CHECK_EQ(gran_in_use, 5'd16, "pool full")
    alloc(DOM_KEYSTONE, 8, DOM_PACKET, 5'h1F, 5'h1F);
    `CHECK_EQ(st, BMS_NOSPACE, "full pool reports NOSPACE")
    cmd(BM_FREE, DOM_PACKET, a_id, 0, '0, 0, 0, 0, 0);
    cmd(BM_FREE, DOM_PACKET, d_id, 0, '0, 0, 0, 0, 0);
    `CHECK_EQ(gran_in_use, 5'd8, "8 granules free in two runs of 4")
    alloc(DOM_KEYSTONE, 320, DOM_PACKET, 5'h1F, 5'h1F);
    `CHECK_EQ(st, BMS_NOSPACE, "fragmented pool cannot host 5 contiguous granules")
    alloc(DOM_KEYSTONE, 256, DOM_PACKET, 5'h1F, 5'h1F);
    `CHECK(st == BMS_OK && rstart == SB, "4-granule run reused")

    // ---- ALLOC_AT -----------------------------------------------------------------
    cmd(BM_ALLOC_AT, DOM_KEYSTONE, 0, BT_VIRTIO_DESC, SB + 576 + 8, 64, DOM_VFOUNDRY, 5'b10000, 5'b10000);
    `CHECK_EQ(st, BMS_ALIGN, "unaligned ALLOC_AT rejected")
    cmd(BM_ALLOC_AT, DOM_KEYSTONE, 0, BT_VIRTIO_DESC, SB + 512, 64, DOM_VFOUNDRY, 5'b10000, 5'b10000);
    `CHECK_EQ(st, BMS_OVERLAP, "ALLOC_AT over a live buffer rejected")
    cmd(BM_ALLOC_AT, DOM_KEYSTONE, 0, BT_VIRTIO_DESC, SB + 960, 128, DOM_VFOUNDRY, 5'b10000, 5'b10000);
    `CHECK_EQ(st, BMS_ALIGN, "ALLOC_AT beyond the window rejected")
    cmd(BM_ALLOC_AT, DOM_KEYSTONE, 0, BT_VIRTIO_DESC, SB + 576, 128, DOM_VFOUNDRY, 5'b10000, 5'b10000);
    `CHECK(st == BMS_OK && rstart == SB + 576, "ALLOC_AT into free granules 9-10")

    // ---- raw-access drain before allocation commit ------------------------------------
    cmd(BM_FREE, DOM_PACKET, c_id2, 0, '0, 0, 0, 0, 0);               // granules 5-8 free
    probe(0, SB + 320, SB + 327, 1'b1);
    `CHECK(chk_raw[0], "Keystone raw write into free granules")
    @(negedge clk); chk_fire = 5'b00001; @(negedge clk); chk_fire = 0;  // raw write in flight
    fork
      alloc(DOM_KEYSTONE, 64, DOM_COMPUTE, 5'b01000, 5'b01000);
      begin
        int seen_block; seen_block = 0;
        repeat (30) begin @(negedge clk); if (raw_block) seen_block = 1; end
        `CHECK(seen_block && !rsp_valid, "allocation holds raw_block while a raw write is in flight")
        dec_raw = 4'b0010; @(negedge clk); dec_raw = 0;
      end
    join
    `CHECK(st == BMS_OK && rstart == SB + 320, "allocation commits after the raw write drains")
    `CHECK(!raw_block, "raw_block released")

    `TB_FINISH("tb_buffer_manager")
  end
endmodule
