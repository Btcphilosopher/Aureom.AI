#!/usr/bin/env python3
"""Unit tests for tools/sram_area_report.py (run: python3 tests/iron_memory/test_sram_area_report.py)."""
import os, sys, unittest
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, '..', '..', 'tools'))
import sram_area_report as s

FIX = os.path.join(HERE, 'fixtures')
ARGS = ['--banks', '4', '--depth', '1024', '--data-bits', '64', '--ecc', '1',
        '--macro-name', 'FIXTURE_SRAM_512X72', '--macro-words', '512', '--macro-bits', '72']


class T(unittest.TestCase):
    def test_no_library_no_area(self):
        r = s.main(ARGS)
        self.assertIsNone(r['total_macro_area'])
        self.assertTrue(r['area_status'].startswith('NOT REPORTED'))
        self.assertEqual(r['codeword_bits'], 72)
        self.assertEqual(r['macros_total'], 8)           # 1 column x 2 rows x 4 banks
        self.assertAlmostEqual(r['ecc_storage_overhead'], 0.125)

    def test_liberty_area_and_nested_groups_ignored(self):
        r = s.main(ARGS + ['--liberty', os.path.join(FIX, 'fixture_not_a_real_library.lib')])
        self.assertEqual(r['macro_area'], 1000.0)        # not the nested timing() area
        self.assertEqual(r['total_macro_area'], 8000.0)

    def test_missing_cell(self):
        a = list(ARGS); a[a.index('FIXTURE_SRAM_512X72')] = 'NO_SUCH_CELL'
        r = s.main(a + ['--liberty', os.path.join(FIX, 'fixture_not_a_real_library.lib')])
        self.assertIsNone(r['total_macro_area'])
        self.assertIn('not found', r['area_status'])

    def test_lef_footprint_and_tiling(self):
        a = ['--banks', '4', '--depth', '1000', '--data-bits', '64', '--ecc', '1',
             '--macro-name', 'FIXTURE_SRAM_512X72', '--macro-words', '256', '--macro-bits', '40',
             '--lef', os.path.join(FIX, 'fixture_not_a_real_library.lef')]
        r = s.main(a)
        self.assertEqual((r['column_tiles'], r['row_tiles']), (2, 4))   # 72/40 -> 2, 1000/256 -> 4
        self.assertEqual(r['footprint']['total_footprint_area'], 40.0 * 25.0 * 32)

    def test_check_bits(self):
        self.assertEqual(s.secded_check_bits(64), 8)
        self.assertEqual(s.secded_check_bits(128), 9)
        self.assertEqual(s.secded_check_bits(256), 10)


if __name__ == '__main__':
    unittest.main(verbosity=1)
