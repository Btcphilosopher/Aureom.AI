// =============================================================================
// tb_extmem : external-memory adapter + simulated DRAM controller
//   1  explicit timing: row empty / hit / miss / write recovery (measured)
//   2  refresh back-pressure
//   3  error reporting (injected and out-of-range)
//   4  protocol error: response for a tag that is not outstanding
//   5  random multi-port traffic with data check, outstanding limit
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_extmem;
  int tb_errors = 0;
  int tb_checks = 0;

  localparam int NP = 5, DW = 64, NB = 8, EWW = 13, SW = 3, PW = 3, TAG_W = PW + SW, MAXO = 8;
  localparam int WORDS = 4096;                       // < 2^EWW: upper addresses are out of range
  localparam int T_RCD = 5, T_CL = 7, T_CWL = 5, T_RP = 6, T_WR = 9, T_BURST = 2, T_REFI = 400, T_RFC = 30;
  localparam int ROWW = 64, NBK = 4;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;
  logic [31:0] now;
  always_ff @(posedge clk or negedge rst_n) if (!rst_n) now <= 0; else now <= now + 1;

  logic [NP-1:0] p_valid, p_ready, p_we; logic [NP*EWW-1:0] p_word; logic [NP*DW-1:0] p_wdata;
  logic [NP*NB-1:0] p_be; logic [NP*TAG_W-1:0] p_tag;
  logic cmd_valid, cmd_ready, cmd_we; logic [EWW-1:0] cmd_addr; logic [DW-1:0] cmd_wdata; logic [NB-1:0] cmd_wstrb; logic [TAG_W-1:0] cmd_tag;
  logic rsp_valid, rsp_ready, rsp_err; logic [DW-1:0] rsp_rdata; logic [TAG_W-1:0] rsp_tag;
  logic cpl_valid, cpl_err; logic [TAG_W-1:0] cpl_tag; logic [DW-1:0] cpl_data;
  logic [3:0] outstanding; logic ev_rd, ev_wr, ev_bp, ev_err, ev_proto, lat_valid; logic [31:0] lat;
  logic inj_en; logic [EWW-1:0] inj_addr; logic ev_hit, ev_empty, ev_miss, ev_ref;
  // spurious-response injection (protocol test) muxed onto the response channel
  logic spur_v; logic [TAG_W-1:0] spur_tag;
  logic d_rsp_valid; logic [TAG_W-1:0] d_rsp_tag;

  sf_iron_extmem_adapter #(.NUM_PORTS(NP), .DW(DW), .EWW(EWW), .TAG_W(TAG_W), .EXT_MAX_OUT(MAXO)) u_ad (
    .clk, .rst_n, .now, .p_valid, .p_ready, .p_we, .p_word, .p_wdata, .p_be, .p_tag,
    .cmd_valid, .cmd_ready, .cmd_we, .cmd_addr, .cmd_wdata, .cmd_wstrb, .cmd_tag,
    .rsp_valid(d_rsp_valid | spur_v), .rsp_ready, .rsp_rdata, .rsp_err, .rsp_tag(spur_v ? spur_tag : d_rsp_tag),
    .cpl_valid, .cpl_tag, .cpl_data, .cpl_err, .outstanding, .ev_rd, .ev_wr, .ev_bp, .ev_err, .ev_proto,
    .lat_valid, .lat_cycles(lat));
  sf_iron_simdram #(.DW(DW), .AW(EWW), .WORDS(WORDS), .TAG_W(TAG_W), .NBANKS(NBK), .ROW_WORDS(ROWW),
    .T_RCD(T_RCD), .T_CL(T_CL), .T_CWL(T_CWL), .T_RP(T_RP), .T_WR(T_WR), .T_BURST(T_BURST),
    .T_REFI(T_REFI), .T_RFC(T_RFC), .QDEPTH(4)) u_dram (
    .clk, .rst_n, .cmd_valid, .cmd_ready, .cmd_we, .cmd_addr, .cmd_wdata, .cmd_wstrb, .cmd_tag,
    .rsp_valid(d_rsp_valid), .rsp_ready, .rsp_rdata, .rsp_err, .rsp_tag(d_rsp_tag),
    .inj_err_en(inj_en), .inj_err_addr(inj_addr),
    .ev_row_hit(ev_hit), .ev_row_empty(ev_empty), .ev_row_miss(ev_miss), .ev_refresh(ev_ref));

  // ---- reference model (controller is in-order: apply at command handshake) ----
  logic [63:0] refm [1 << EWW];
  logic [63:0] exp_d [1 << TAG_W];
  bit          exp_e [1 << TAG_W];
  bit          outs  [1 << TAG_W];
  int          n_cpl, n_bp, n_ref, n_proto, n_err;
  int          port_out [NP];

  function automatic logic [63:0] lanes(input logic [7:0] be);
    logic [63:0] m; for (int i = 0; i < 8; i++) m[i*8 +: 8] = {8{be[i]}}; return m;
  endfunction

  always @(posedge clk) if (rst_n) begin
    if (cmd_valid && cmd_ready) begin
      bit err; err = (int'(cmd_addr) >= WORDS) || (inj_en && cmd_addr == inj_addr);
      exp_e[cmd_tag] = err;
      if (!err && cmd_we) refm[cmd_addr] = (refm[cmd_addr] & ~lanes(cmd_wstrb)) | (cmd_wdata & lanes(cmd_wstrb));
      exp_d[cmd_tag] = (err || cmd_we) ? '0 : (refm[cmd_addr] & lanes(cmd_wstrb));
    end
    if (cpl_valid) begin
      n_cpl++; tb_checks++;
      if (!outs[cpl_tag]) begin tb_errors++; $display("[FAIL] completion for tag %0h not outstanding", cpl_tag); end
      if (cpl_err !== exp_e[cpl_tag] || cpl_data !== exp_d[cpl_tag]) begin
        tb_errors++; $display("[FAIL] tag %0h data %h/%h err %b/%b", cpl_tag, cpl_data, exp_d[cpl_tag], cpl_err, exp_e[cpl_tag]);
      end
      outs[cpl_tag] = 0;
      port_out[cpl_tag[TAG_W-1:SW]]--;
    end
    if (ev_bp) n_bp++;
    if (ev_ref) n_ref++;
    if (ev_proto) n_proto++;
    if (ev_err) n_err++;
  end

  // ---- per-port request issue ----
  logic [SW-1:0] pseq [NP];
  task automatic issue(input int p, input logic we, input int addr, input logic [63:0] wd, input logic [7:0] be);
    logic [TAG_W-1:0] t;
    @(negedge clk);
    while (port_out[p] >= MAXO) @(negedge clk);
    t = {PW'(p), pseq[p]};
    while (outs[t]) @(negedge clk);
    p_valid[p] = 1; p_we[p] = we; p_word[p*EWW +: EWW] = EWW'(addr); p_wdata[p*DW +: DW] = wd;
    p_be[p*NB +: NB] = be; p_tag[p*TAG_W +: TAG_W] = t;
    #1;
    while (!p_ready[p]) begin @(negedge clk); #1; end
    outs[t] = 1; port_out[p]++;
    pseq[p] = pseq[p] + 1'b1;
    @(posedge clk); #1;
    p_valid[p] = 0;
  endtask

  task automatic run_port(input int p);
    for (int k = 0; k < 200; k++)
      issue(p, $urandom_range(0, 1), $urandom_range(0, 255), {$urandom, $urandom}, 8'($urandom) | 8'h1);
  endtask

  // isolated op: issue, wait for completion, return measured adapter latency
  int last_lat;
  task automatic iso(input logic we, input int addr, input logic [63:0] wd);
    int c0;
    issue(0, we, addr, wd, 8'hFF);
    c0 = now;
    while (!lat_valid) @(posedge clk);
    last_lat = lat;
    @(posedge clk);
    repeat (2) @(posedge clk);
  endtask

  initial begin
    int l_empty, l_hit, l_miss, l_wmiss, l_whit;
    p_valid = 0; p_we = 0; p_word = 0; p_wdata = 0; p_be = 0; p_tag = 0; inj_en = 0; inj_addr = 0;
    spur_v = 0; spur_tag = 0;
    n_cpl = 0; n_bp = 0; n_ref = 0; n_proto = 0; n_err = 0;
    for (int i = 0; i < (1 << EWW); i++) refm[i] = '0;
    for (int t = 0; t < (1 << TAG_W); t++) outs[t] = 0;
    for (int p = 0; p < NP; p++) begin pseq[p] = 0; port_out[p] = 0; end
    repeat (3) @(posedge clk); rst_n = 1; repeat (2) @(posedge clk);

    // ---- 1. timing ----
    iso(0, 0, 0);                 l_empty = last_lat;     // bank 0 row 0: empty
    iso(0, 1, 0);                 l_hit   = last_lat;     // same row: hit
    iso(0, ROWW * NBK, 0);        l_miss  = last_lat;     // bank 0 row 1: miss
    iso(1, ROWW * NBK + 3, 64'h1); l_whit = last_lat;     // write hit on row 1
    iso(0, 2 * ROWW * NBK, 0);    l_wmiss = last_lat;     // miss right after a write: tWR
    $display("ext latency (adapter accept -> completion): empty=%0d hit=%0d miss=%0d write-hit=%0d miss-after-write=%0d",
             l_empty, l_hit, l_miss, l_whit, l_wmiss);
    `CHECK_EQ(l_empty - l_hit, T_RCD, "row empty costs exactly tRCD more than a hit")
    `CHECK_EQ(l_miss - l_empty, T_RP, "row miss costs exactly tRP more than empty")
    `CHECK_EQ(l_hit - l_whit, T_CL - T_CWL, "read vs write CAS difference")
    `CHECK(l_wmiss > l_miss && l_wmiss <= l_miss + T_WR, "write recovery delays the following precharge")
    `CHECK_EQ(l_hit, T_CL + T_BURST + 3, "hit latency = CAS + burst + 3 cycles adapter/queue overhead")

    // ---- 2. refresh back-pressure under load ----
    begin
      int r0, b0; r0 = n_ref; b0 = n_bp;
      for (int k = 0; k < 300; k++) issue($urandom_range(0, NP - 1), 0, $urandom_range(0, WORDS - 1), 0, 8'hFF);
      while (u_ad.outstanding != 0) @(posedge clk);
      `CHECK(n_ref - r0 >= 2, $sformatf("refreshes occurred during load (%0d)", n_ref - r0))
      `CHECK(n_bp - b0 > 0, $sformatf("command back-pressure observed (%0d cycles)", n_bp - b0))
      $display("refresh: %0d refreshes, %0d back-pressure cycles over 300 commands", n_ref - r0, n_bp - b0);
    end

    // ---- 3. error reporting ----
    inj_en = 1; inj_addr = 13'd77;
    iso(0, 77, 0);
    `CHECK_EQ(n_err, 1, "injected controller error reported")
    iso(1, 77, 64'hFFFF);
    `CHECK_EQ(n_err, 2, "write error reported")
    inj_en = 0;
    iso(0, WORDS + 5, 0);
    `CHECK_EQ(n_err, 3, "out-of-range word reported as error")

    // ---- 4. protocol error ----
    @(negedge clk); spur_v = 1; spur_tag = 6'h3F; @(negedge clk); spur_v = 0;
    repeat (3) @(posedge clk);
    `CHECK_EQ(n_proto, 1, "response for a non-outstanding tag flagged and dropped")

    // ---- 5. random multi-port traffic ----
    begin
      int c0; c0 = n_cpl;
      // explicit branches (Verilator 5.020 does not reliably capture loop
      // variables in fork/join_none)
      fork
        run_port(0); run_port(1); run_port(2); run_port(3); run_port(4);
      join
      while (u_ad.outstanding != 0) @(posedge clk);
      `CHECK_EQ(n_cpl - c0, NP * 200, "every command completed exactly once")
    end
    `TB_FINISH("tb_extmem")
  end
  initial begin #20ms; $display("TB_RESULT tb_extmem FAIL timeout"); $finish; end
endmodule
