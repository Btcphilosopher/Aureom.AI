// =============================================================================
// tb_memory_map : bijection, boundary, alignment and anti-aliasing checks for
// sf_iron_memory_map, interleaved and contiguous banking.
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_memory_map;
  import sf_iron_pkg::*;
  int tb_errors = 0;
  int tb_checks = 0;

  localparam int AW = 32, DW = 64, NB = 8, NBANK = 4, DEPTH = 16;
  localparam logic [31:0] SB = 32'h1000_0000;
  localparam logic [31:0] EB = 32'h8000_0000;
  localparam longint EBYTES = 4096;
  localparam int WIN = NBANK * DEPTH * NB;      // 512 bytes

  logic [31:0] addr; logic [2:0] size; logic we; logic [7:0] wstrb;
  logic [1:0] reg_i, reg_c; logic [1:0] bank_i, bank_c; logic [3:0] word_i, word_c;
  logic [2:0] off_i, off_c; logic [8:0] ew_i, ew_c; logic [7:0] be_i, be_c;
  logic [31:0] lo_i, hi_i, lo_c, hi_c; logic [3:0] nb_i, nb_c; logic [2:0] err_i, err_c;

  sf_iron_memory_map #(.AW(AW), .DW(DW), .NUM_BANKS(NBANK), .BANK_DEPTH(DEPTH), .INTERLEAVE(1),
    .SRAM_BASE(SB), .EXT_EN(1), .EXT_BASE(EB), .EXT_BYTES(EBYTES)) u_il (
    .addr, .size, .we, .wstrb, .region(reg_i), .bank(bank_i), .bank_word(word_i), .byte_off(off_i),
    .ext_word(ew_i), .be(be_i), .lo_addr(lo_i), .hi_addr(hi_i), .nbytes(nb_i), .err(err_i));
  sf_iron_memory_map #(.AW(AW), .DW(DW), .NUM_BANKS(NBANK), .BANK_DEPTH(DEPTH), .INTERLEAVE(0),
    .SRAM_BASE(SB), .EXT_EN(1), .EXT_BASE(EB), .EXT_BYTES(EBYTES)) u_ct (
    .addr, .size, .we, .wstrb, .region(reg_c), .bank(bank_c), .bank_word(word_c), .byte_off(off_c),
    .ext_word(ew_c), .be(be_c), .lo_addr(lo_c), .hi_addr(hi_c), .nbytes(nb_c), .err(err_c));

  int e_bi, e_wi, e_bc, e_wc, e_off;
  bit seen_i [NBANK][DEPTH][NB];
  bit seen_c [NBANK][DEPTH][NB];

  task automatic expect_decode_err(input logic [31:0] a, input string what);
    addr = a; size = 3'd0; we = 1'b0; wstrb = 8'hFF; #1;
    `CHECK(err_i == RSP_DECODE && reg_i == REGION_NONE, {"interleaved: expected DECODE for ", what})
    `CHECK(err_c == RSP_DECODE && reg_c == REGION_NONE, {"contiguous: expected DECODE for ", what})
  endtask

  initial begin
    // ---- 1. bijection over every byte of the window ------------------------
    foreach (seen_i[b, w, o]) begin seen_i[b][w][o] = 0; seen_c[b][w][o] = 0; end
    for (int a = 0; a < WIN; a++) begin
      addr = SB + a; size = 3'd0; we = 1'b0; wstrb = '0; #1;
      `CHECK(err_i == RSP_OK && reg_i == REGION_SRAM, "in-window byte must decode")
      `CHECK(!seen_i[bank_i][word_i][off_i], "interleaved alias: two addresses share a cell")
      `CHECK(!seen_c[bank_c][word_c][off_c], "contiguous alias: two addresses share a cell")
      seen_i[bank_i][word_i][off_i] = 1;
      seen_c[bank_c][word_c][off_c] = 1;
      e_bi = (a / NB) - ((a / NB) / NBANK) * NBANK;  e_wi = (a / NB) / NBANK;
      e_bc = (a / NB) / DEPTH;  e_wc = (a / NB) - ((a / NB) / DEPTH) * DEPTH;  e_off = a - (a / NB) * NB;
      `CHECK_EQ(bank_i, 2'(e_bi), "interleaved bank formula")
      `CHECK_EQ(word_i, 4'(e_wi), "interleaved word formula")
      `CHECK_EQ(bank_c, 2'(e_bc), "contiguous bank formula")
      `CHECK_EQ(word_c, 4'(e_wc), "contiguous word formula")
      `CHECK_EQ(off_i, 3'(e_off), "byte offset")
      `CHECK_EQ(be_i, 8'(1 << e_off), "byte enable for 1-byte read")
      `CHECK(lo_i == SB + a && hi_i == SB + a && nb_i == 1, "byte range for 1-byte read")
    end
    begin
      int missing; missing = 0;
      foreach (seen_i[b, w, o]) if (!seen_i[b][w][o] || !seen_c[b][w][o]) missing++;
      `CHECK_EQ(missing, 0, "every cell reached exactly once (surjective)")
    end

    // ---- 2. boundaries and anti-aliasing ------------------------------------
    expect_decode_err(SB - 1,               "byte below SRAM window");
    expect_decode_err(SB + WIN,             "first byte past SRAM window");
    expect_decode_err(SB + WIN + 7,         "word past SRAM window");
    expect_decode_err(SB ^ 32'h4000_0000,   "upper-bit alias of SRAM base");
    expect_decode_err(SB + WIN * 2,         "window-size alias (base + 2*size)");
    expect_decode_err(32'h0000_0000,        "address zero");
    expect_decode_err(32'hFFFF_FFFF,        "top of address space");
    expect_decode_err(EB - 1,               "byte below EXT window");
    expect_decode_err(EB + 32'(EBYTES),     "first byte past EXT window");
    expect_decode_err(EB | 32'h0010_0000,   "upper-bit alias of EXT base");

    addr = SB + WIN - 8; size = 3'd3; we = 1'b0; #1;
    `CHECK(err_i == RSP_OK && bank_i == 2'd3 && word_i == 4'd15, "last word of window, interleaved")
    `CHECK(err_c == RSP_OK && bank_c == 2'd3 && word_c == 4'd15, "last word of window, contiguous")
    `CHECK(be_i == 8'hFF && nb_i == 8 && lo_i == SB + WIN - 8 && hi_i == SB + WIN - 1, "full-word range")

    addr = EB; size = 3'd3; #1;
    `CHECK(err_i == RSP_OK && reg_i == REGION_EXT && ew_i == 0, "first EXT word")
    addr = EB + 32'(EBYTES) - 8; #1;
    `CHECK(err_i == RSP_OK && reg_i == REGION_EXT && ew_i == 9'(EBYTES / 8 - 1), "last EXT word")

    // ---- 3. size / alignment / strobes --------------------------------------
    for (int sz = 0; sz < 4; sz++) begin
      for (int o = 0; o < 8; o++) begin
        addr = SB + 64 + o; size = 3'(sz); we = 1'b0; #1;
        if ((o & ((1 << sz) - 1)) == 0) begin
          `CHECK(err_i == RSP_OK, $sformatf("aligned size %0d off %0d accepted", sz, o))
          `CHECK_EQ(be_i, 8'(((1 << (1 << sz)) - 1) << o), "size mask")
          `CHECK_EQ(nb_i, 4'(1 << sz), "nbytes")
        end else begin
          `CHECK_EQ(err_i, RSP_ALIGN, $sformatf("misaligned size %0d off %0d rejected", sz, o))
        end
      end
    end
    addr = SB; size = 3'd4; we = 1'b0; #1;
    `CHECK_EQ(err_i, RSP_ALIGN, "16-byte access on 64-bit memory rejected")
    addr = SB; size = 3'd3; we = 1'b1; wstrb = 8'h00; #1;
    `CHECK_EQ(err_i, RSP_ALIGN, "write with empty strobe rejected")
    wstrb = 8'b0011_1100; #1;
    `CHECK(err_i == RSP_OK && be_i == 8'b0011_1100, "full-size write with sparse strobe")
    `CHECK(lo_i == SB + 2 && hi_i == SB + 5 && nb_i == 4, "sparse strobe byte range")
    addr = SB + 4; size = 3'd2; wstrb = 8'hFF; #1;
    `CHECK(err_i == RSP_OK && be_i == 8'hF0, "word write strobe limited by size mask")
    addr = SB + 4; size = 3'd1; wstrb = 8'h03; #1;
    `CHECK_EQ(err_i, RSP_ALIGN, "strobe outside size mask leaves empty enable")

    `TB_FINISH("tb_memory_map")
  end
endmodule
