// =============================================================================
// tb_iron_memory : sf_iron_memory system verification (local SRAM, EXT_EN=0)
//
// Reference model: the TB mirrors the address map and the buffer table, and
// replays the DUT's bank-issue trace (trc_*) into a reference memory, so the
// expected read data for every access is exact even with five masters racing
// for four banks. Every response is checked for error code, data and
// ecc_corr. Phases:
//   1  independent bank operations (4 grants per cycle)
//   2  same-bank conflicts, round-robin fairness, priority + anti-starvation
//   3  concurrent random traffic, all masters, with response back-pressure
//   4  partial writes on every byte lane (ECC RMW)
//   5  ECC fault injection: correct, detect, log, IRQ, buffer attribution, scrub
//   6  ownership violations, data not leaked / not modified, drain-before-free
//   7  buffer exhaustion through the top-level command port
//   8  address boundaries
//   9  back-pressure: ROB fills, request stalls, no loss, order kept
//  10  performance-counter cross-check against TB-observed counts
//  11  reset in the middle of traffic
// Config overrides (compile defines): TB_RL2, TB_NOECC, TB_BACKEND=<n>,
// TB_CONTIG, TB_RL2.
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_iron_memory;
  import sf_iron_pkg::*;
  int tb_errors = 0;
  int tb_checks = 0;

`ifdef TB_RL2
  localparam int RL = 2;
`else
  localparam int RL = 1;
`endif
`ifdef TB_NOECC
  localparam int ECC = 0;
`else
  localparam int ECC = 1;
`endif
`ifdef TB_BACKEND
  localparam int BACKEND = `TB_BACKEND;
`else
  localparam int BACKEND = 0;
`endif
`ifdef TB_CONTIG
  localparam int ILV = 0;
`else
  localparam int ILV = 1;
`endif

  localparam int NP = 5, AW = 32, DW = 64, NB = 8, NBANK = 4, DEPTH = 64, MAXO = 8;
  localparam int NDESC = 16, GRAN = 64, STARVE = 16;
  localparam logic [31:0] SB = 32'h1000_0000;
  localparam int WIN = NBANK * DEPTH * NB;          // 2048 bytes
  localparam int PW = 3, SW = 3, IDW = 4, LW = 6, LEN_W = 12;
  localparam int R = sf_iron_pkg::secded_r(DW);
  localparam int CW = (ECC != 0) ? DW + R + 1 : DW;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  // ---------------- DUT signals ----------------
  logic [NP-1:0] m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_ready, m_rsp_ecc_corr;
  logic [NP*AW-1:0] m_req_addr; logic [NP*3-1:0] m_req_size; logic [NP*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NP*NB-1:0] m_req_wstrb; logic [NP*3-1:0] m_rsp_err;
  logic bm_cmd_valid, bm_cmd_ready, bm_rsp_valid, bm_rsp_in_use;
  logic [2:0] bm_cmd_op, bm_cmd_requester, bm_cmd_btype, bm_cmd_owner, bm_rsp_btype, bm_rsp_owner;
  logic [IDW-1:0] bm_cmd_id, bm_rsp_id; logic [AW-1:0] bm_cmd_start, bm_rsp_start;
  logic [LEN_W-1:0] bm_cmd_len, bm_rsp_len; logic [4:0] bm_cmd_rd_mask, bm_cmd_wr_mask, bm_rsp_rd_mask, bm_rsp_wr_mask;
  logic [3:0] bm_rsp_status; logic [7:0] bm_rsp_err_bits;
  logic csr_valid, csr_we, csr_rvalid, csr_err; logic [11:0] csr_addr; logic [31:0] csr_wdata, csr_rdata;
  logic ext_cmd_valid, ext_cmd_we, ext_rsp_ready; logic [16:0] ext_cmd_addr; logic [63:0] ext_cmd_wdata;
  logic [7:0] ext_cmd_wstrb; logic [5:0] ext_cmd_tag;
  logic init_done, irq;
  logic [NBANK-1:0] trc_valid, trc_we; logic [NBANK*PW-1:0] trc_port; logic [NBANK*SW-1:0] trc_seq;
  logic [NBANK*LW-1:0] trc_word; logic [NBANK*NB-1:0] trc_be; logic [NBANK*DW-1:0] trc_wdata;

  sf_iron_memory #(.NUM_PORTS(NP), .AW(AW), .DW(DW), .NUM_BANKS(NBANK), .BANK_DEPTH(DEPTH), .RL(RL),
    .INTERLEAVE(ILV), .SRAM_BASE(SB), .ECC_EN(ECC), .BACKEND(BACKEND), .MACRO_WORDS(32), .MACRO_BITS(40),
    .INIT_ON_RESET(1), .MAX_OUT(MAXO), .NUM_DESC(NDESC), .GRAN_BYTES(GRAN), .EXT_EN(0),
    .STARVE_LIMIT(STARVE), .SCRUB_MAX_DEFER(16)) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_addr, .m_req_size, .m_req_we, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_err, .m_rsp_ecc_corr,
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask, .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id,
    .bm_rsp_in_use, .bm_rsp_btype, .bm_rsp_start, .bm_rsp_len, .bm_rsp_owner, .bm_rsp_rd_mask, .bm_rsp_wr_mask,
    .bm_rsp_err_bits, .csr_valid, .csr_we, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .csr_err,
    .ext_cmd_valid, .ext_cmd_ready(1'b0), .ext_cmd_we, .ext_cmd_addr, .ext_cmd_wdata, .ext_cmd_wstrb, .ext_cmd_tag,
    .ext_rsp_valid(1'b0), .ext_rsp_ready, .ext_rsp_rdata(64'h0), .ext_rsp_err(1'b0), .ext_rsp_tag(6'h0),
    .init_done, .irq, .trc_valid, .trc_port, .trc_seq, .trc_we, .trc_word, .trc_be, .trc_wdata);

  // =========================================================================
  // Reference model state
  // =========================================================================
  logic [63:0] refm  [NBANK][DEPTH];
  bit          r_ce  [NBANK][DEPTH];      // latent single-bit error
  bit          r_ue  [NBANK][DEPTH];      // latent double-bit error (poisoned)
  int          inj_kind [NBANK];          // 0 none, 1 single, 2 double (armed)

  typedef struct { bit used; logic [31:0] start; int len; logic [2:0] owner; logic [4:0] rd; logic [4:0] wr; bit closing; } buf_t;
  buf_t bufs [NDESC];
  bit   raw_en_m;

  typedef struct { logic [31:0] addr; logic [2:0] size; logic we; logic [63:0] wdata; logic [7:0] wstrb; } req_t;
  // fixed ring buffers (Verilator 5.020 mis-indexes arrays of queues)
  localparam int RQD = 16384, EQD = 32;
  req_t rqa [NP][RQD];
  int   rq_h [NP], rq_t [NP];
  typedef struct { logic [2:0] err; bit rd; logic [SW-1:0] seq; logic [63:0] data; bit ce; bit tracked; logic [7:0] be; bit lenient; } exp_t;
  exp_t eqa [NP][EQD];
  int   eq_h [NP], eq_t [NP];
  function automatic int rq_n(input int p); return rq_t[p] - rq_h[p]; endfunction
  function automatic int eq_n(input int p); return eq_t[p] - eq_h[p]; endfunction
  logic [63:0] ed  [NP][MAXO];
  bit          ece [NP][MAXO];
  bit          eue [NP][MAXO];
  bit          eset[NP][MAXO];
  logic [SW-1:0] tseq [NP];
  int          bp_mode [NP];               // 0 ready, 1 random, 2 hold low
  bit          drive_en [NP];
  bit          race_on;
  logic [31:0] race_lo, race_hi;
  int          race_ok, race_perm, race_bad_order;

  // statistics observed by the TB (cross-checked against DUT counters)
  int o_acc [NP], o_rd [NP], o_wr [NP], o_brd [NP], o_bwr [NP], o_err [NP], o_rsp [NP];
  int o_grants [NP], o_bank_ops [NBANK], o_four_grant_cycles, o_conflict_cycles, o_rmw [NBANK];
  int o_ce_rsp, o_ue_rsp;

  function automatic logic [63:0] lanes(input logic [7:0] be);
    logic [63:0] m;
    for (int i = 0; i < 8; i++) m[i*8 +: 8] = {8{be[i]}};
    return m;
  endfunction

  function automatic void addr2bw(input logic [31:0] a, output int bank, output int word);
    int w;
    w = (a - SB) >> 3;
    if (ILV != 0) begin bank = w % NBANK; word = w / NBANK; end
    else          begin bank = w / DEPTH; word = w % DEPTH; end
  endfunction
  function automatic logic [31:0] bw2addr(input int bank, input int word);
    if (ILV != 0) return SB + 32'((word * NBANK + bank) * 8);
    else          return SB + 32'((bank * DEPTH + word) * 8);
  endfunction

  // model of map + ownership check (mirrors the RTL contract)
  function automatic logic [2:0] model_err(input int p, input req_t r, output logic [7:0] be);
    int off, sz, lo, hi; bit in_win, hit, ovl, cont_close; logic allow; int id;
    in_win = (r.addr >= SB) && (r.addr < SB + WIN);
    sz = 1 << r.size;
    off = r.addr & 7;
    be = '0;
    if (!in_win) return RSP_DECODE;
    if (r.size > 3) return RSP_ALIGN;
    if ((off % sz) != 0) return RSP_ALIGN;
    for (int i = 0; i < 8; i++) be[i] = (i >= off) && (i < off + sz);
    if (r.we) be = be & r.wstrb;
    if (r.we && be == 0) return RSP_ALIGN;
    lo = -1; hi = -1;
    for (int i = 0; i < 8; i++) if (be[i]) begin if (lo < 0) lo = i; hi = i; end
    lo = (r.addr & ~32'h7) + lo; hi = (r.addr & ~32'h7) + hi;
    hit = 0; ovl = 0; cont_close = 0; id = -1;
    for (int i = 0; i < NDESC; i++) if (bufs[i].used) begin
      int s, e; s = bufs[i].start; e = bufs[i].start + bufs[i].len - 1;
      if (lo >= s && hi <= e) begin if (!bufs[i].closing && !hit) begin hit = 1; id = i; end else if (bufs[i].closing) cont_close = 1; end
      if (lo <= e && hi >= s) ovl = 1;
    end
    if (hit) begin
      allow = r.we ? bufs[id].wr[p] : bufs[id].rd[p];
      return allow ? RSP_OK : RSP_PERM;
    end
    if (ovl) return cont_close ? RSP_PERM : RSP_BOUNDS;
    return (p == 0 && raw_en_m) ? RSP_OK : RSP_PERM;
  endfunction

  // =========================================================================
  // Cycle engine: drive at negedge, evaluate handshakes at negedge + 1
  // =========================================================================
  initial begin
    m_req_valid = 0; m_req_addr = 0; m_req_size = 0; m_req_we = 0; m_req_wdata = 0; m_req_wstrb = 0;
    m_rsp_ready = '1;
    forever begin
      @(negedge clk);
      for (int p = 0; p < NP; p++) begin
        if (rst_n && drive_en[p] && rq_n(p) > 0) begin
          req_t r; r = rqa[p][rq_h[p] & (RQD - 1)];
          m_req_valid[p] = 1'b1;
          m_req_addr[p*AW +: AW] = r.addr; m_req_size[p*3 +: 3] = r.size; m_req_we[p] = r.we;
          m_req_wdata[p*DW +: DW] = r.wdata; m_req_wstrb[p*NB +: NB] = r.wstrb;
        end else begin
          m_req_valid[p] = 1'b0;
          m_req_addr[p*AW +: AW] = $urandom;   // garbage while invalid
        end
        case (bp_mode[p])
          0: m_rsp_ready[p] = 1'b1;
          1: m_rsp_ready[p] = ($urandom_range(0, 99) < 55);
          default: m_rsp_ready[p] = 1'b0;
        endcase
      end
      #1;
      if (rst_n) begin
        int ng; ng = 0;
        // ---- trace replay (grants committing at the next posedge) ----
        for (int b = 0; b < NBANK; b++) if (trc_valid[b]) begin
          int p, s, w; logic [7:0] be; logic [63:0] wd;
          p = trc_port[b*PW +: PW]; s = trc_seq[b*SW +: SW]; w = trc_word[b*LW +: LW];
          be = trc_be[b*NB +: NB]; wd = trc_wdata[b*DW +: DW];
          ng++; o_grants[p]++; o_bank_ops[b]++;
          if (trc_we[b]) begin
            bit full; full = (be == 8'hFF);
            if (ECC != 0 && !full) o_rmw[b]++;
            if (ECC != 0 && !full && r_ue[b][w]) begin
              eue[p][s] = 1; ece[p][s] = 0;                 // RMW aborted, word stays poisoned
            end else begin
              ece[p][s] = (ECC != 0 && !full && r_ce[b][w]);
              eue[p][s] = 0;
              refm[b][w] = (refm[b][w] & ~lanes(be)) | (wd & lanes(be));
              r_ce[b][w] = 0; r_ue[b][w] = 0;
              if (inj_kind[b] != 0) begin
                if (inj_kind[b] == 1) r_ce[b][w] = 1; else r_ue[b][w] = 1;
                inj_kind[b] = 0;
              end
            end
            ed[p][s] = '0;
          end else begin
            ed[p][s]  = r_ue[b][w] ? '0 : (refm[b][w] & lanes(be));
            ece[p][s] = r_ce[b][w];
            eue[p][s] = r_ue[b][w];
          end
          eset[p][s] = 1;
        end
        if (ng == NBANK) o_four_grant_cycles++;
        // ---- request acceptance ----
        for (int p = 0; p < NP; p++) if (m_req_valid[p] && m_req_ready[p]) begin
          req_t r; exp_t e; logic [7:0] be;
          r = rqa[p][rq_h[p] & (RQD - 1)]; rq_h[p]++;
          e.err = model_err(p, r, be);
          e.rd = !r.we; e.seq = tseq[p]; e.be = be; e.tracked = (e.err == RSP_OK);
          e.lenient = race_on && (r.addr >= race_lo) && (r.addr <= race_hi);
          eset[p][tseq[p]] = 0;
          if (eq_n(p) >= EQD) begin tb_errors++; $display("[FAIL] TB expectation ring overflow"); end
          eqa[p][eq_t[p] & (EQD - 1)] = e; eq_t[p]++;
          tseq[p] = tseq[p] + 1'b1;
          o_acc[p]++;
          if (e.err == RSP_OK) begin
            int n; n = 0; for (int i = 0; i < 8; i++) n += be[i];
            if (r.we) begin o_wr[p]++; o_bwr[p] += n; end else begin o_rd[p]++; o_brd[p] += n; end
          end
        end
        // ---- responses ----
        for (int p = 0; p < NP; p++) if (m_rsp_valid[p] && m_rsp_ready[p]) begin
          exp_t e;
          tb_checks++;
          if (eq_n(p) == 0) begin
            tb_errors++; $display("[FAIL] %0t port %0d: response with nothing outstanding", $time, p);
          end else begin
            logic [2:0] xerr; logic [63:0] xd; bit xce;
            e = eqa[p][eq_h[p] & (EQD - 1)]; eq_h[p]++;
            o_rsp[p]++;
            if (e.lenient) begin
              // FREE racing a live stream: each access is either OK (accepted
              // before the buffer closed) or PERM; never OK after a PERM
              if (m_rsp_err[p*3 +: 3] == RSP_OK) begin
                e.err = RSP_OK; e.tracked = 1; race_ok++;
                if (race_perm != 0) race_bad_order++;
              end else begin
                e.err = RSP_PERM; e.tracked = 0; race_perm++;
              end
            end
            xerr = e.err; xd = '0; xce = 0;
            if (e.tracked) begin
              if (!eset[p][e.seq]) begin
                tb_errors++; $display("[FAIL] %0t port %0d: response before its bank issue (seq %0d)", $time, p, e.seq);
              end
              if (eue[p][e.seq]) xerr = RSP_ECC_UE;
              xce = ece[p][e.seq];
              if (e.rd) xd = ed[p][e.seq];
            end
            if (xerr != RSP_OK) o_err[p]++;
            if (xce) o_ce_rsp++;
            if (xerr == RSP_ECC_UE) o_ue_rsp++;
            if (m_rsp_err[p*3 +: 3] !== xerr || m_rsp_rdata[p*DW +: DW] !== xd || m_rsp_ecc_corr[p] !== xce) begin
              tb_errors++;
              if (tb_errors < 40)
                $display("[FAIL] %0t port %0d seq %0d: err %0d/%0d data %h/%h ce %b/%b", $time, p, e.seq,
                         m_rsp_err[p*3 +: 3], xerr, m_rsp_rdata[p*DW +: DW], xd, m_rsp_ecc_corr[p], xce);
            end
          end
        end
      end
    end
  end

  // =========================================================================
  // Helpers
  // =========================================================================
  task automatic push(input int p, input logic [31:0] a, input logic [2:0] sz, input logic we,
                      input logic [63:0] wd = '0, input logic [7:0] st = 8'hFF);
    req_t r; r.addr = a; r.size = sz; r.we = we; r.wdata = wd; r.wstrb = st;
    if (rq_n(p) >= RQD) $fatal(1, "TB request ring overflow");
    rqa[p][rq_t[p] & (RQD - 1)] = r; rq_t[p]++;
  endtask

  task automatic wait_idle(input int max_cycles = 200000);
    int c; bit idle; c = 0;
    do begin
      @(posedge clk); c++;
      idle = 1;
      for (int p = 0; p < NP; p++) if (rq_n(p) != 0 || eq_n(p) != 0) idle = 0;
    end while (!idle && c < max_cycles);
    `CHECK(idle, "all traffic drained")
    repeat (3) @(posedge clk);
  endtask

  task automatic csr_wr(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); csr_valid = 1; csr_we = 1; csr_addr = a; csr_wdata = d;
    @(negedge clk); csr_valid = 0; csr_we = 0;
  endtask
  task automatic csr_rd(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk); csr_valid = 1; csr_we = 0; csr_addr = a;
    @(negedge clk); csr_valid = 0;
    d = csr_rdata;
    `CHECK(csr_rvalid && !csr_err, $sformatf("CSR read %03h", a))
  endtask

  logic [3:0] bst; logic [IDW-1:0] bid; logic [31:0] bstart;
  task automatic bm(input logic [2:0] op, input logic [2:0] req, input int id, input logic [2:0] bt,
                    input logic [31:0] start, input int len, input logic [2:0] owner, input logic [4:0] rd, input logic [4:0] wr);
    @(negedge clk);
    while (!bm_cmd_ready) @(negedge clk);
    bm_cmd_valid = 1; bm_cmd_op = op; bm_cmd_requester = req; bm_cmd_id = IDW'(id); bm_cmd_btype = bt;
    bm_cmd_start = start; bm_cmd_len = LEN_W'(len); bm_cmd_owner = owner; bm_cmd_rd_mask = rd; bm_cmd_wr_mask = wr;
    if (op == BM_FREE || op == BM_TRANSFER) bufs[id].closing = 1;  // model: closes on acceptance
    @(negedge clk); bm_cmd_valid = 0;
    while (!bm_rsp_valid) begin @(posedge clk); #1; end
    bst = bm_rsp_status; bid = bm_rsp_id; bstart = bm_rsp_start;
    if (op == BM_FREE || op == BM_TRANSFER) bufs[id].closing = 0;
    if (bst == BMS_OK) begin
      case (op)
        BM_ALLOC, BM_ALLOC_AT: begin
          bufs[bid].used = 1; bufs[bid].start = bstart; bufs[bid].len = len; bufs[bid].owner = owner;
          bufs[bid].rd = rd; bufs[bid].wr = wr; bufs[bid].closing = 0;
        end
        BM_FREE: bufs[id].used = 0;
        BM_TRANSFER: begin bufs[id].owner = owner; bufs[id].rd = rd; bufs[id].wr = wr; end
        default: ;
      endcase
    end
    @(posedge clk);
  endtask
  task automatic alloc(input logic [2:0] bt, input int len, input logic [2:0] owner, input logic [4:0] rd, input logic [4:0] wr, output int id);
    bm(BM_ALLOC, DOM_KEYSTONE, 0, bt, '0, len, owner, rd, wr);
    `CHECK_EQ(bst, BMS_OK, "allocation")
    id = bid;
  endtask

  function automatic logic [31:0] port_cnt(input int p, input int i); return 32'h200 + 32'(p * 64 + i * 4); endfunction
  function automatic logic [31:0] bank_cnt(input int b, input int i); return 32'h100 + 32'(b * 32 + i * 4); endfunction

  task automatic reset_model();
    for (int b = 0; b < NBANK; b++) begin
      inj_kind[b] = 0; o_bank_ops[b] = 0; o_rmw[b] = 0;
      for (int w = 0; w < DEPTH; w++) begin refm[b][w] = '0; r_ce[b][w] = 0; r_ue[b][w] = 0; end
    end
    for (int i = 0; i < NDESC; i++) bufs[i].used = 0;
    for (int p = 0; p < NP; p++) begin
      rq_h[p] = 0; rq_t[p] = 0; eq_h[p] = 0; eq_t[p] = 0; tseq[p] = '0; bp_mode[p] = 0; drive_en[p] = 1;
      o_acc[p] = 0; o_rd[p] = 0; o_wr[p] = 0; o_brd[p] = 0; o_bwr[p] = 0; o_err[p] = 0; o_rsp[p] = 0; o_grants[p] = 0;
      for (int s = 0; s < MAXO; s++) eset[p][s] = 0;
    end
    raw_en_m = 1; o_four_grant_cycles = 0; o_ce_rsp = 0; o_ue_rsp = 0; race_on = 0;
  endtask

  function automatic logic [31:0] rand_in(input int id, input int sz);
    int n; n = (bufs[id].len - (1 << sz)) >> sz;
    return bufs[id].start + 32'($urandom_range(0, n) << sz);
  endfunction

  // =========================================================================
  // Test sequence
  // =========================================================================
  int B_DMA, B_PKT, B_TOP, B_RES, B_VIO, B_CTL, B_SHR;
  logic [31:0] v, v2;

  initial begin
    bm_cmd_valid = 0; bm_cmd_op = 0; bm_cmd_requester = 0; bm_cmd_id = 0; bm_cmd_btype = 0; bm_cmd_start = 0;
    bm_cmd_len = 0; bm_cmd_owner = 0; bm_cmd_rd_mask = 0; bm_cmd_wr_mask = 0;
    csr_valid = 0; csr_we = 0; csr_addr = 0; csr_wdata = 0;
    reset_model();
    repeat (4) @(posedge clk);
    rst_n = 1;
    while (!init_done) @(posedge clk);
    $display("config: RL=%0d ECC=%0d BACKEND=%0d INTERLEAVE=%0d", RL, ECC, BACKEND, ILV);

    csr_rd(12'h000, v);
    `CHECK_EQ(v, 32'h5346_0084, "IRONMEMORY ID register")

    // ---------------------------------------------------------------- phase 1
    // Keystone raw access: each of 4 ports gets a bank of its own. Use
    // Keystone (raw) on bank 0 and buffers for the others.
    alloc(BT_DMA_STAGING, WIN, DOM_BRIDGE, 5'b11111, 5'b11111, B_SHR);   // whole window, all domains
    for (int k = 0; k < 400; k++) begin
      for (int p = 1; p < NP; p++) push(p, bw2addr(p - 1, k % DEPTH), 3'd3, (k % 3) == 0, {$urandom, $urandom});
    end
    wait_idle();
    `CHECK(o_four_grant_cycles >= 380, $sformatf("independent banks: %0d cycles with 4 concurrent grants (of 400 ops/bank)", o_four_grant_cycles))
    $display("phase1: cycles with 4 concurrent bank grants = %0d", o_four_grant_cycles);
    bm(BM_FREE, DOM_BRIDGE, B_SHR, 0, '0, 0, 0, 0, 0);

    // ---------------------------------------------------------------- phase 2
    alloc(BT_DMA_STAGING, WIN, DOM_BRIDGE, 5'b11111, 5'b11111, B_SHR);
    for (int p = 0; p < NP; p++) o_grants[p] = 0;
    csr_wr(12'h038, 32'h1);                                              // clear counters
    for (int k = 0; k < 300; k++)
      for (int p = 0; p < NP; p++) push(p, bw2addr(0, $urandom_range(0, DEPTH - 1)), 3'd3, 1'b0);
    wait_idle();
    begin
      int mn, mx; mn = 1 << 30; mx = 0;
      for (int p = 0; p < NP; p++) begin if (o_grants[p] < mn) mn = o_grants[p]; if (o_grants[p] > mx) mx = o_grants[p]; end
      `CHECK(mx == 300 && mn == 300, "every port served on a hot bank")
      csr_rd(bank_cnt(0, 3), v);
      `CHECK(v >= 1000, $sformatf("bank 0 conflict cycles counted (%0d)", v))
      $display("phase2: bank0 conflict cycles = %0d", v);
      for (int p = 0; p < NP; p++) begin
        csr_rd(port_cnt(p, 9), v);
        `CHECK(v <= NP, $sformatf("round-robin bounds wait on a hot bank: port %0d max wait %0d", p, v))
      end
    end
    // priority + anti-starvation: ComputeWorks high priority, everyone hammers bank 1
    csr_wr(12'h014, 32'b01000);
    csr_wr(12'h038, 32'h1);
    for (int k = 0; k < 300; k++)
      for (int p = 0; p < NP; p++) push(p, bw2addr(1, $urandom_range(0, DEPTH - 1)), 3'd3, 1'b0);
    wait_idle();
    for (int p = 0; p < NP; p++) begin
      csr_rd(port_cnt(p, 9), v);
      `CHECK(v <= STARVE + NP + 2, $sformatf("anti-starvation bounds wait under priority: port %0d max wait %0d", p, v))
      if (p != 3) begin
        csr_rd(port_cnt(p, 8), v2);
        `CHECK(v2 > 0, $sformatf("starvation events recorded for low-priority port %0d", p))
      end
    end
    csr_rd(port_cnt(3, 6), v);
    csr_rd(port_cnt(1, 6), v2);
    `CHECK(v < v2, $sformatf("high-priority ComputeWorks waits less (%0d) than BridgeEngine (%0d)", v, v2))
    csr_wr(12'h014, 32'b0);
    bm(BM_FREE, DOM_BRIDGE, B_SHR, 0, '0, 0, 0, 0, 0);

    // ---------------------------------------------------------------- phase 3
    // buffer layout (domains: 0 Keystone 1 Bridge 2 Packet 3 Compute 4 VFoundry)
    alloc(BT_DMA_STAGING,    256, DOM_BRIDGE,   5'b01010, 5'b00010, B_DMA);
    alloc(BT_PACKET,         100, DOM_PACKET,   5'b10100, 5'b00100, B_PKT);
    alloc(BT_TENSOR_OPERAND, 192, DOM_COMPUTE,  5'b01000, 5'b01010, B_TOP);
    alloc(BT_COMPUTE_RESULT, 128, DOM_COMPUTE,  5'b01011, 5'b01000, B_RES);
    alloc(BT_VIRTIO_DESC,     64, DOM_VFOUNDRY, 5'b10001, 5'b10001, B_VIO);
    alloc(BT_CTRL_META,       72, DOM_KEYSTONE, 5'b11111, 5'b00001, B_CTL);
    alloc(BT_DMA_STAGING,    320, DOM_BRIDGE,   5'b11111, 5'b11111, B_SHR);
    for (int p = 0; p < NP; p++) bp_mode[p] = (p % 2 == 0) ? 1 : 0;
    csr_wr(12'h038, 32'h1);
    for (int p = 0; p < NP; p++) begin o_acc[p] = 0; o_rd[p] = 0; o_wr[p] = 0; o_brd[p] = 0; o_bwr[p] = 0; o_err[p] = 0; o_rsp[p] = 0; end
    for (int b = 0; b < NBANK; b++) begin o_bank_ops[b] = 0; o_rmw[b] = 0; end
    for (int k = 0; k < 2500; k++) begin
      for (int p = 0; p < NP; p++) begin
        int cat, id, sz; logic [31:0] a; logic we; logic [7:0] st;
        cat = $urandom_range(0, 99);
        sz  = $urandom_range(0, 3);
        we  = $urandom_range(0, 1);
        st  = ($urandom_range(0, 3) == 0) ? 8'($urandom) : 8'hFF;
        id  = $urandom_range(0, 6);
        case (id) 0: id = B_DMA; 1: id = B_PKT; 2: id = B_TOP; 3: id = B_RES; 4: id = B_VIO; 5: id = B_CTL; default: id = B_SHR; endcase
        if (cat < 70)      a = rand_in(id, sz);
        else if (cat < 76) a = bufs[id].start + bufs[id].len - 4;                 // tail / straddle
        else if (cat < 84) a = SB + 32'($urandom_range(0, WIN / 8 - 1) * 8) + 32'(($urandom_range(0, 7) >> (3 - sz)) << sz);
        else if (cat < 88) a = SB + WIN + 32'($urandom_range(0, 64));              // past window
        else if (cat < 90) a = SB - 32'($urandom_range(1, 64));
        else if (cat < 94) a = rand_in(id, 3) + 32'($urandom_range(1, 7));         // likely misaligned
        else               a = SB + 32'(1280 + $urandom_range(0, 95) * 8);         // unmanaged tail
        push(p, a, 3'(sz), we, {$urandom, $urandom}, st);
      end
    end
    wait_idle(400000);
    for (int p = 0; p < NP; p++) bp_mode[p] = 0;
    $display("phase3: accepted per port = %0d %0d %0d %0d %0d, errors = %0d %0d %0d %0d %0d", o_acc[0], o_acc[1], o_acc[2], o_acc[3], o_acc[4],
             o_err[0], o_err[1], o_err[2], o_err[3], o_err[4]);

    // ---------------------------------------------------------------- phase 10 (counters for phase 3)
    for (int p = 0; p < NP; p++) begin
      csr_rd(port_cnt(p, 0), v);  `CHECK_EQ(int'(v), o_acc[p], $sformatf("port %0d accepted counter", p))
      csr_rd(port_cnt(p, 1), v);  `CHECK_EQ(int'(v), o_rd[p],  $sformatf("port %0d read counter", p))
      csr_rd(port_cnt(p, 2), v);  `CHECK_EQ(int'(v), o_wr[p],  $sformatf("port %0d write counter", p))
      csr_rd(port_cnt(p, 3), v);  `CHECK_EQ(int'(v), o_brd[p], $sformatf("port %0d bytes-read counter", p))
      csr_rd(port_cnt(p, 4), v);  `CHECK_EQ(int'(v), o_bwr[p], $sformatf("port %0d bytes-written counter", p))
      csr_rd(port_cnt(p, 11), v); `CHECK_EQ(int'(v), o_rsp[p], $sformatf("port %0d latency samples == responses", p))
      csr_rd(port_cnt(p, 13), v); `CHECK_EQ(int'(v), o_err[p], $sformatf("port %0d error-response counter", p))
    end
    for (int b = 0; b < NBANK; b++) begin
      csr_rd(bank_cnt(b, 0), v); csr_rd(bank_cnt(b, 1), v2);
      `CHECK_EQ(int'(v + v2), o_bank_ops[b], $sformatf("bank %0d reads+writes == trace issues", b))
      csr_rd(bank_cnt(b, 4), v);
      `CHECK_EQ(int'(v), o_rmw[b], $sformatf("bank %0d RMW counter", b))
      csr_rd(bank_cnt(b, 5), v2);
      if (ECC != 0) `CHECK_EQ(int'(v2), o_rmw[b] * (RL + 1), $sformatf("bank %0d RMW stall cycles == RMWs x (RL+1)", b))
    end

    // final sweep: authorised readers read every byte of every buffer and the unmanaged space
    for (int i = 0; i < NDESC; i++) if (bufs[i].used) begin
      int rdr; rdr = -1;
      for (int p = NP - 1; p >= 0; p--) if (bufs[i].rd[p]) rdr = p;
      for (int o = 0; o + 8 <= bufs[i].len; o += 8) push(rdr, bufs[i].start + o, 3'd3, 1'b0);
      for (int o = (bufs[i].len / 8) * 8; o < bufs[i].len; o++) push(rdr, bufs[i].start + o, 3'd0, 1'b0);
    end
    for (int a = 1280; a < WIN; a += 8) push(0, SB + a, 3'd3, 1'b0);
    wait_idle();

    // ---------------------------------------------------------------- phase 4
    // byte, half, word partial writes on every lane of a shared-buffer word
    for (int ln = 0; ln < 8; ln++) push(1, bufs[B_SHR].start + 8 + ln, 3'd0, 1'b1, {8{8'(8'h10 + ln)}}, 8'hFF);
    for (int ln = 0; ln < 8; ln += 2) push(3, bufs[B_SHR].start + 16 + ln, 3'd1, 1'b1, {4{16'hBEE0 + 16'(ln)}}, 8'hFF);
    for (int ln = 0; ln < 8; ln += 4) push(4, bufs[B_SHR].start + 24 + ln, 3'd2, 1'b1, {2{32'hCAFE_0000 + 32'(ln)}}, 8'hFF);
    push(2, bufs[B_SHR].start + 32, 3'd3, 1'b1, 64'hFFFF_FFFF_FFFF_FFFF, 8'b1010_0101);
    wait_idle();
    push(0, bufs[B_SHR].start + 8, 3'd3, 1'b0);
    push(0, bufs[B_SHR].start + 16, 3'd3, 1'b0);
    push(0, bufs[B_SHR].start + 24, 3'd3, 1'b0);
    push(0, bufs[B_SHR].start + 32, 3'd3, 1'b0);
    wait_idle();
    begin
      int b, w; addr2bw(bufs[B_SHR].start + 8, b, w);
      `CHECK_EQ(refm[b][w], 64'h1716_1514_1312_1110, "byte-lane writes assembled into one word")
      addr2bw(bufs[B_SHR].start + 32, b, w);
      `CHECK_EQ(refm[b][w] & 64'hFF00_FF00_00FF_00FF, 64'hFF00_FF00_00FF_00FF, "sparse strobe write")
    end

    // ---------------------------------------------------------------- phase 5
    if (ECC != 0) begin
      int b, w; logic [31:0] a;
      a = bufs[B_SHR].start + 40; addr2bw(a, b, w);
      // single-bit: corrected, logged, buffer attributed
      csr_wr(12'h01C, 32'h0000_8000 | 32'd37);       // bit A = 37
      csr_wr(12'h020, 32'h8000_0000 | 32'(b));       // arm bank b
      inj_kind[b] = 1;
      push(0, a, 3'd3, 1'b1, 64'h0123_4567_89AB_CDEF);
      wait_idle();
      push(3, a, 3'd3, 1'b0);
      wait_idle();
      `CHECK_EQ(o_ce_rsp, 1, "single-bit injection reported as corrected")
      csr_rd(12'h028, v);
      `CHECK(v[31] && v[27:24] == 4'(b) && v[23:0] == 24'(w), "CE log captures bank and word")
      csr_rd(12'h008, v);
      `CHECK(v[5], "sticky corrected-error status")
      bm(BM_QUERY, DOM_KEYSTONE, B_SHR, 0, '0, 0, 0, 0, 0);
      `CHECK(bm_rsp_err_bits[BERR_ECC_CE], "corrected error attributed to the buffer")
      // scrub repairs the latent error
      csr_wr(12'h010, 32'd4);
      csr_wr(12'h00C, 32'b00_0011);    // raw_en | scrub_en
      begin
        int c; c = 0;
        do begin repeat (16) @(posedge clk); csr_rd(32'h400 + 15 * 4, v); c++; end while (v == 0 && c < 400);
        `CHECK(v >= 1, "scrubber repaired the latent single-bit error")
        r_ce[b][w] = 0;
      end
      csr_wr(12'h00C, 32'b00_0001);
      push(3, a, 3'd3, 1'b0);
      wait_idle();
      `CHECK_EQ(o_ce_rsp, 1, "after scrub the word reads clean")
      // double-bit: detected, poisoned data, UE log, IRQ, buffer attribution
      csr_wr(12'h01C, 32'h8000_8000 | (32'd70 << 16) | 32'd2);
      csr_wr(12'h020, 32'h8000_0000 | 32'(b));
      inj_kind[b] = 2;
      push(0, a, 3'd3, 1'b1, 64'hDEAD_BEEF_0000_0001);
      wait_idle();
      `CHECK(!irq, "IRQ quiet before enable")
      csr_wr(12'h00C, 32'b00_0101);    // raw_en | irq_ue
      push(1, a, 3'd3, 1'b0);
      push(1, a, 3'd0, 1'b1, 64'hAA, 8'hFF);   // partial write over poisoned word: aborted
      push(1, a, 3'd3, 1'b0);
      wait_idle();
      `CHECK_EQ(o_ue_rsp, 3, "uncorrectable error reported on read, RMW and re-read")
      `CHECK(irq, "IRQ raised for uncorrectable error")
      csr_rd(12'h030, v);
      `CHECK(v[31] && v[27:24] == 4'(b) && v[23:0] == 24'(w), "UE log captures bank and word")
      bm(BM_QUERY, DOM_KEYSTONE, B_SHR, 0, '0, 0, 0, 0, 0);
      `CHECK(bm_rsp_err_bits[BERR_ECC_UE], "uncorrectable error attributed to the buffer")
      // full overwrite heals the word; clear status
      push(1, a, 3'd3, 1'b1, 64'h1);
      push(1, a, 3'd3, 1'b0);
      wait_idle();
      csr_wr(12'h024, 32'h3E);
      csr_rd(12'h008, v);
      `CHECK(!v[1] && !v[5], "status cleared")
      `CHECK(!irq, "IRQ cleared")
      csr_wr(12'h00C, 32'b00_0001);
    end

    // ---------------------------------------------------------------- phase 6
    begin
      int b, w; logic [31:0] a; logic [63:0] prev_word;
      a = bufs[B_DMA].start + 16; addr2bw(a, b, w);
      push(1, a, 3'd3, 1'b1, 64'h1111_2222_3333_4444);   // owner write
      wait_idle();
      prev_word = refm[b][w];
      push(2, a, 3'd3, 1'b1, 64'hBAD0_BAD0_BAD0_BAD0);   // PacketForge: no permission
      push(4, a, 3'd3, 1'b0);                            // VirtualFoundry: no read permission
      push(0, a, 3'd3, 1'b1, 64'hBAD1_BAD1_BAD1_BAD1);   // Keystone: masks apply inside buffers
      wait_idle();
      push(3, a, 3'd3, 1'b0);                            // authorised reader sees the owner data
      wait_idle();
      `CHECK_EQ(refm[b][w], prev_word, "unauthorised writes did not modify memory")
      bm(BM_QUERY, DOM_KEYSTONE, B_DMA, 0, '0, 0, 0, 0, 0);
      `CHECK(bm_rsp_err_bits[BERR_WR_PERM] && bm_rsp_err_bits[BERR_RD_PERM], "violations attributed to buffer")
      csr_rd(12'h008, v);
      `CHECK(v[2], "sticky permission-violation status")
      // FREE racing a live write stream from the owner
      race_lo = bufs[B_DMA].start; race_hi = bufs[B_DMA].start + bufs[B_DMA].len - 1;
      race_ok = 0; race_perm = 0; race_bad_order = 0; race_on = 1;
      for (int k = 0; k < 300; k++) push(1, bufs[B_DMA].start + 32'(8 * (k % 32)), 3'd3, 1'b1, 64'(k));
      repeat (40) @(posedge clk);
      bm(BM_FREE, DOM_BRIDGE, B_DMA, 0, '0, 0, 0, 0, 0);
      `CHECK_EQ(bst, BMS_OK, "FREE completed while the owner was streaming")
      wait_idle();
      race_on = 0;
      `CHECK(race_ok > 0 && race_perm > 0, $sformatf("race produced both outcomes (ok=%0d perm=%0d)", race_ok, race_perm))
      `CHECK_EQ(race_bad_order, 0, "no access succeeded after the buffer began closing")
      push(1, bufs[B_DMA].start, 3'd3, 1'b0);            // now unmanaged: Bridge refused
      wait_idle();
    end

    // ---------------------------------------------------------------- phase 7
    begin
      int n_ok, ids [NDESC]; n_ok = 0;
      for (int i = 0; i < NDESC + 1; i++) begin
        bm(BM_ALLOC, DOM_KEYSTONE, 0, BT_PACKET, '0, 8, DOM_PACKET, 5'b00100, 5'b00100);
        if (bst == BMS_OK) begin ids[n_ok] = bid; n_ok++; end
      end
      `CHECK_EQ(bst, BMS_NODESC, "descriptor exhaustion through the command port")
      csr_rd(12'h400 + 5 * 4, v);
      `CHECK(v >= 1, "NODESC counted")
      for (int i = 0; i < n_ok; i++) bm(BM_FREE, DOM_PACKET, ids[i], 0, '0, 0, 0, 0, 0);
      bm(BM_ALLOC, DOM_KEYSTONE, 0, BT_PACKET, '0, WIN, DOM_PACKET, 5'b00100, 5'b00100);
      `CHECK_EQ(bst, BMS_NOSPACE, "space exhaustion (window partly allocated)")
    end

    // ---------------------------------------------------------------- phase 8
    push(0, SB, 3'd3, 1'b0);
    push(0, SB + WIN - 1, 3'd0, 1'b0);
    push(0, SB + WIN, 3'd0, 1'b0);
    push(0, SB - 1, 3'd0, 1'b0);
    push(0, SB + 4, 3'd3, 1'b0);
    push(0, SB + 2, 3'd2, 1'b0);
    push(0, SB, 3'd4, 1'b0);
    push(0, SB, 3'd3, 1'b1, 64'h0, 8'h00);
    push(0, 32'hFFFF_FFF8, 3'd3, 1'b0);
    push(3, bufs[B_RES].start + bufs[B_RES].len - 8, 3'd3, 1'b0);
    push(3, bufs[B_RES].start + bufs[B_RES].len, 3'd3, 1'b0);
    push(2, bufs[B_PKT].start + 96, 3'd3, 1'b0);       // 100-byte buffer: straddles end
    push(2, bufs[B_PKT].start + 96, 3'd2, 1'b0);       // last 4 bytes: inside
    wait_idle();

    // ---------------------------------------------------------------- phase 9
    begin
      int acc_before, stall; logic [31:0] s0;
      bp_mode[4] = 2;
      csr_rd(port_cnt(4, 5), s0);
      for (int k = 0; k < 3 * MAXO; k++) push(4, rand_in(B_VIO, 3), 3'd3, 1'b0);
      repeat (60) @(posedge clk);
      `CHECK_EQ(eq_n(4), MAXO, "ROB full: exactly MAX_OUT requests accepted under back-pressure")
      `CHECK_EQ(rq_n(4), 2 * MAXO, "remaining requests held at the port")
      bp_mode[4] = 1;
      wait_idle();
      csr_rd(port_cnt(4, 5), v);
      `CHECK(v - s0 >= 40, "request stall cycles counted under back-pressure")
      csr_rd(port_cnt(4, 14), v);
      `CHECK(v >= 40, "response back-pressure cycles counted")
      bp_mode[4] = 0;
    end

    // ---------------------------------------------------------------- phase 11
    begin
      for (int k = 0; k < 400; k++) for (int p = 0; p < NP; p++) push(p, rand_in(B_SHR, 3), 3'd3, $urandom_range(0, 1), {$urandom, $urandom});
      repeat (150) @(posedge clk);
      @(negedge clk);
      rst_n = 0;
      repeat (3) @(negedge clk);
      reset_model();
      for (int p = 0; p < NP; p++) drive_en[p] = 0;
      #1;
      `CHECK(m_rsp_valid == '0 && m_req_ready == '0, "no responses or acceptance during reset")
      @(negedge clk);
      rst_n = 1;
      begin
        int c; c = 0;
        while (!init_done) begin
          @(posedge clk); c++;
          `CHECK(m_rsp_valid == '0, "no stale responses after reset")
        end
        `CHECK(c >= DEPTH - 1, "init sweep ran after reset")
      end
      for (int p = 0; p < NP; p++) drive_en[p] = 1;
      csr_rd(12'h008, v);
      `CHECK_EQ(v[15:8], 8'd0, "descriptor table empty after reset")
      csr_rd(port_cnt(0, 0), v);
      `CHECK_EQ(v, 32'd0, "counters cleared by reset")
      for (int a = 0; a < WIN; a += 8) push(0, SB + a, 3'd3, 1'b0);   // all zero after init
      wait_idle();
    end

    `TB_FINISH("tb_iron_memory")
  end

  initial begin
    #50ms;
    $display("TB_RESULT tb_iron_memory FAIL timeout");
    $finish;
  end
endmodule
