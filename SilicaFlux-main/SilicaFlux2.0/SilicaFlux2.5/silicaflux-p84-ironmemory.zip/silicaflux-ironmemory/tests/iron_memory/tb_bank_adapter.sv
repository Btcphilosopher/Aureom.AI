// =============================================================================
// tb_bank_adapter : bank adapter verification across SRAM backends, ECC on/off,
// RL=1/2. Random traffic against a reference model, exact latency, RMW port
// occupancy, ECC injection (single/double), RMW over corrupted words, scrub
// repair, init sweep vs power-up garbage.
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_bank_core #(
  parameter int    BACKEND = 0,
  parameter int    ECC_EN  = 1,
  parameter int    RL      = 1,
  parameter int    INIT    = 1,
  parameter int    PWRRAND = 0,
  parameter int    NOPS    = 3000,
  parameter string NAME    = "core"
) (
  input  logic clk,
  input  logic rst_n,
  output logic done,
  output int   errors,
  output int   checks
);
  localparam int DW = 64, NB = 8, DEPTH = 64, AWL = 6, TAG_W = 8;
  localparam int R  = sf_iron_pkg::secded_r(DW);
  localparam int CW = (ECC_EN != 0) ? DW + R + 1 : DW;

  int tb_errors = 0;
  int tb_checks = 0;
  assign errors = tb_errors;
  assign checks = tb_checks;

  logic req_valid, req_ready, req_we; logic [AWL-1:0] req_addr; logic [DW-1:0] req_wdata;
  logic [NB-1:0] req_be; logic [TAG_W-1:0] req_tag;
  logic rsp_valid, rsp_we, rsp_ce, rsp_ue; logic [TAG_W-1:0] rsp_tag; logic [DW-1:0] rsp_rdata;
  logic scrub_en, scrub_tick, inj_arm, inj_pending, init_done;
  logic [CW-1:0] inj_mask;
  logic ev_rd, ev_wr, ev_rmw, ev_ce, ev_ue, ev_scrub, ev_scrub_fix, port_busy, stall_rmw;
  logic [AWL-1:0] ev_err_addr; logic [R:0] ev_syn;

  sf_iron_bank_adapter #(.DW(DW), .DEPTH(DEPTH), .RL(RL), .ECC_EN(ECC_EN), .BACKEND(BACKEND),
    .MACRO_WORDS(16), .MACRO_BITS(40), .INIT_ON_RESET(INIT), .SIM_POWERUP_RANDOM(PWRRAND),
    .TAG_W(TAG_W), .SCRUB_MAX_DEFER(8)) dut (
    .clk, .rst_n, .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_be, .req_tag,
    .rsp_valid, .rsp_tag, .rsp_rdata, .rsp_we, .rsp_ce, .rsp_ue,
    .scrub_en, .scrub_tick, .inj_arm, .inj_mask, .inj_pending, .init_done,
    .ev_rd, .ev_wr, .ev_rmw, .ev_ce, .ev_ue, .ev_scrub, .ev_scrub_fix,
    .ev_err_addr, .ev_syndrome(ev_syn), .port_busy, .stall_rmw);

  // ---- reference model and expected-response queue --------------------------
  logic [DW-1:0] refm [DEPTH];
  typedef struct { logic [TAG_W-1:0] tag; logic we; logic [DW-1:0] data; logic ce; logic ue; longint t_issue; logic chk_data; } exp_t;
  exp_t q [$];
  longint cyc;
  int n_rsp, n_rmw, stall_cycles;
  logic expect_lat_ok;

  function automatic logic [DW-1:0] m(input logic [NB-1:0] be);
    logic [DW-1:0] r;
    for (int i = 0; i < NB; i++) r[i*8 +: 8] = {8{be[i]}};
    return r;
  endfunction

  always_ff @(posedge clk) begin
    if (!rst_n) cyc <= 0; else cyc <= cyc + 1;
  end

  // response checker
  always @(posedge clk) begin
    if (rst_n && rsp_valid) begin
      exp_t e;
      n_rsp++;
      tb_checks++;
      if (q.size() == 0) begin
        tb_errors++; $display("[FAIL] %s: unexpected response tag %0h", NAME, rsp_tag);
      end else begin
        e = q.pop_front();
        if (rsp_tag !== e.tag || rsp_we !== e.we) begin
          tb_errors++; $display("[FAIL] %s: response order tag %0h exp %0h", NAME, rsp_tag, e.tag);
        end
        if (cyc - e.t_issue != RL + 1) begin
          tb_errors++; $display("[FAIL] %s: latency %0d exp %0d", NAME, cyc - e.t_issue, RL + 1);
        end
        if (e.chk_data && (rsp_rdata !== e.data || rsp_ce !== e.ce || rsp_ue !== e.ue)) begin
          tb_errors++;
          $display("[FAIL] %s: tag %0h data %h exp %h ce %b/%b ue %b/%b", NAME, rsp_tag, rsp_rdata, e.data, rsp_ce, e.ce, rsp_ue, e.ue);
        end
      end
    end
    if (rst_n && stall_rmw && init_done) stall_cycles++;
  end

  logic [TAG_W-1:0] tag_ctr;

  // issue one op; blocks until accepted. exp_* describe the expected response
  task automatic issue(input logic we, input int a, input logic [DW-1:0] wd, input logic [NB-1:0] be,
                       input logic chk, input logic [DW-1:0] exp_data, input logic exp_ce, input logic exp_ue);
    exp_t e;
    // back-to-back capable: req_valid stays high after acceptance until the
    // next negedge; every non-issue activity must call idle() first.
    @(negedge clk);
    while (!req_ready) begin req_valid = 0; @(negedge clk); end
    req_valid = 1; req_we = we; req_addr = AWL'(a); req_wdata = wd; req_be = be; req_tag = tag_ctr;
    @(posedge clk);
    e.tag = tag_ctr; e.we = we; e.data = exp_data; e.ce = exp_ce; e.ue = exp_ue; e.t_issue = cyc; e.chk_data = chk;
    q.push_back(e);
    tag_ctr++;
    if (we && ECC_EN != 0 && be != 8'hFF) n_rmw++;
  endtask
  task automatic idle();
    @(negedge clk);
    req_valid = 0;
  endtask

  task automatic wr(input int a, input logic [DW-1:0] wd, input logic [NB-1:0] be);
    refm[a] = (refm[a] & ~m(be)) | (wd & m(be));
    issue(1, a, wd, be, 1, '0, 0, 0);
  endtask
  task automatic rd(input int a, input logic [NB-1:0] be);
    issue(0, a, '0, be, 1, refm[a] & m(be), 0, 0);
  endtask
  task automatic drain();
    int guard; guard = 0;
    idle();
    while (q.size() != 0 && guard < 1000) begin @(posedge clk); guard++; end
    `CHECK(q.size() == 0, {NAME, ": pipeline drained"})
    repeat (2) @(posedge clk);
  endtask
  task automatic inject(input int b0, input int b1);
    @(negedge clk);
    req_valid = 0;
    inj_mask = '0;
    if (b0 >= 0) inj_mask[b0] = 1'b1;
    if (b1 >= 0) inj_mask[b1] = 1'b1;
    inj_arm = 1;
    @(negedge clk);
    inj_arm = 0;
  endtask

  initial begin
    logic [DW-1:0] v;
    done = 0; req_valid = 0; req_we = 0; req_addr = 0; req_wdata = 0; req_be = 0; req_tag = 0;
    scrub_en = 0; scrub_tick = 0; inj_arm = 0; inj_mask = 0; tag_ctr = 0;
    n_rsp = 0; n_rmw = 0; stall_cycles = 0;
    for (int i = 0; i < DEPTH; i++) refm[i] = '0;
    @(posedge rst_n);
    while (!init_done) @(posedge clk);

    if (PWRRAND != 0 && INIT == 0) begin
      // ---- power-up garbage without init sweep: ECC must flag it ----------
      int bad; bad = 0;
      for (int a = 0; a < DEPTH; a++) issue(0, a, '0, 8'hFF, 0, '0, 0, 0);
      drain();
      // count was gathered from events below
    end else begin
      // ---- 1. init / power-up: every word reads back as clean zero --------
      for (int a = 0; a < DEPTH; a++) rd(a, 8'hFF);
      drain();
      p1_err = pr_ce + pr_ue;

      // ---- 2. random traffic against the reference model ------------------
      for (int n = 0; n < NOPS; n++) begin
        int a; logic [NB-1:0] be; int kind;
        a = $urandom_range(0, DEPTH - 1);
        kind = $urandom_range(0, 9);
        case ($urandom_range(0, 3))
          0: be = 8'hFF;
          1: be = 8'(1 << $urandom_range(0, 7));
          2: be = 8'($urandom) | 8'h01;
          default: be = 8'h0F << (4 * $urandom_range(0, 1));
        endcase
        if (kind < 5) wr(a, {$urandom, $urandom}, be);
        else          rd(a, (kind == 9) ? be : 8'hFF);
      end
      drain();
      if (ECC_EN != 0)
        `CHECK_EQ(stall_cycles, n_rmw * (RL + 1), {NAME, ": each RMW blocks the port for exactly RL+1 cycles"})

      if (ECC_EN != 0) begin
        // ---- 3. single-bit injection on a full write -> corrected --------
        for (int bit_i = 0; bit_i < CW; bit_i += 7) begin
          v = {$urandom, $urandom};
          inject(bit_i, -1);
          refm[5] = v; issue(1, 5, v, 8'hFF, 1, '0, 0, 0);
          issue(0, 5, '0, 8'hFF, 1, v, 1, 0);
        end
        drain();
        // ---- 4. double-bit injection -> uncorrectable, data poisoned ------
        v = 64'h0123_4567_89AB_CDEF;
        inject(3, 60);
        refm[9] = v; issue(1, 9, v, 8'hFF, 1, '0, 0, 0);
        issue(0, 9, '0, 8'hFF, 1, '0, 0, 1);
        // partial write over a UE word must not write (abort, report UE)
        issue(1, 9, 64'hFFFF_FFFF_FFFF_FFFF, 8'h01, 1, '0, 0, 1);
        issue(0, 9, '0, 8'hFF, 1, '0, 0, 1);
        drain();
        // ---- 5. partial write over a CE word: corrects + merges + repairs -
        v = 64'hAAAA_BBBB_CCCC_DDDD;
        inject(17, -1);
        refm[12] = v; issue(1, 12, v, 8'hFF, 1, '0, 0, 0);
        refm[12] = (v & ~m(8'h0F)) | (64'h1111_2222_3333_4444 & m(8'h0F));
        issue(1, 12, 64'h1111_2222_3333_4444, 8'h0F, 1, '0, 1, 0);   // RMW sees CE
        issue(0, 12, '0, 8'hFF, 1, refm[12], 0, 0);                  // repaired, clean
        drain();
        // rewrite the words left corrupted by phases 3/4 so phase 6 has a
        // single known latent error
        wr(5, 64'h0, 8'hFF);
        wr(9, 64'h0, 8'hFF);
        drain();
        // ---- 6. scrubber repairs a latent single-bit error ----------------
        v = 64'h5555_6666_7777_8888;
        inject(40, -1);
        refm[20] = v; issue(1, 20, v, 8'hFF, 1, '0, 0, 0);
        drain();
        begin
          int fixes, scrubs; fixes = 0; scrubs = 0;
          scrub_en = 1;
          for (int c = 0; c < DEPTH * 6 && fixes == 0; c++) begin
            @(negedge clk); scrub_tick = 1; @(negedge clk); scrub_tick = 0;
            @(posedge clk); if (ev_scrub_fix) fixes++;
            repeat (RL + 2) begin @(posedge clk); if (ev_scrub_fix) begin fixes++; `CHECK_EQ(ev_err_addr, 6'd20, {NAME, ": scrub fixed the injected word"}) end end
          end
          scrub_en = 0;
          `CHECK(fixes == 1, {NAME, ": scrubber performed exactly one repair"})
        end
        issue(0, 20, '0, 8'hFF, 1, v, 0, 0);                         // clean after scrub
        drain();
        // ---- 7. forced scrub under continuous traffic (no starvation) ------
        begin
          int sc; sc = 0;
          scrub_en = 1;
          fork
            begin for (int k = 0; k < 200; k++) rd($urandom_range(0, DEPTH - 1), 8'hFF); idle(); end
            begin for (int k = 0; k < 20; k++) begin @(negedge clk); scrub_tick = 1; @(negedge clk); scrub_tick = 0; repeat (8) @(negedge clk); end end
            begin repeat (600) begin @(posedge clk); if (ev_scrub) sc++; end end
          join
          scrub_en = 0;
          `CHECK(sc >= 15, {NAME, ": scrub makes progress under saturating traffic"})
        end
        drain();
      end else begin
        // ---- no ECC: injection corrupts silently (demonstrates the need) --
        v = 64'h0F0F_0F0F_0F0F_0F0F;
        inject(0, -1);
        refm[7] = v; issue(1, 7, v, 8'hFF, 1, '0, 0, 0);
        issue(0, 7, '0, 8'hFF, 1, v ^ 64'h1, 0, 0);
        drain();
      end
    end
    done = 1;
  end

  // power-up-garbage statistics
  int pr_ce, pr_ue, p1_err;
  initial begin pr_ce = 0; pr_ue = 0; p1_err = -1; end
  always @(posedge clk) if (rst_n && ev_ce) pr_ce++;
  always @(posedge clk) if (rst_n && ev_ue) pr_ue++;
  final begin
    if (PWRRAND != 0 && INIT == 0)
      $display("%s: power-up random without init -> %0d CE, %0d UE over %0d words", NAME, pr_ce, pr_ue, DEPTH);
  end
endmodule

module tb_bank_adapter;
  int tb_errors = 0;
  int tb_checks = 0;
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  localparam int N = 9;
  logic d [N];
  int   e [N];
  int   c [N];

  tb_bank_core #(.BACKEND(0), .ECC_EN(1), .RL(1), .NAME("generic_ecc_rl1"))    u0 (.clk, .rst_n, .done(d[0]), .errors(e[0]), .checks(c[0]));
  tb_bank_core #(.BACKEND(0), .ECC_EN(1), .RL(2), .NAME("generic_ecc_rl2"))    u1 (.clk, .rst_n, .done(d[1]), .errors(e[1]), .checks(c[1]));
  tb_bank_core #(.BACKEND(1), .ECC_EN(1), .RL(1), .NAME("fpga_ecc_rl1"))       u2 (.clk, .rst_n, .done(d[2]), .errors(e[2]), .checks(c[2]));
  tb_bank_core #(.BACKEND(1), .ECC_EN(1), .RL(2), .NAME("fpga_ecc_rl2"))       u3 (.clk, .rst_n, .done(d[3]), .errors(e[3]), .checks(c[3]));
  tb_bank_core #(.BACKEND(2), .ECC_EN(1), .RL(1), .NAME("asic_ecc_rl1"))       u4 (.clk, .rst_n, .done(d[4]), .errors(e[4]), .checks(c[4]));
  tb_bank_core #(.BACKEND(2), .ECC_EN(1), .RL(2), .NAME("asic_ecc_rl2"))       u5 (.clk, .rst_n, .done(d[5]), .errors(e[5]), .checks(c[5]));
  tb_bank_core #(.BACKEND(0), .ECC_EN(0), .RL(1), .NAME("generic_noecc_rl1"))  u6 (.clk, .rst_n, .done(d[6]), .errors(e[6]), .checks(c[6]));
  tb_bank_core #(.BACKEND(0), .ECC_EN(1), .RL(1), .INIT(1), .PWRRAND(1), .NAME("generic_pwrrand_init")) u7 (.clk, .rst_n, .done(d[7]), .errors(e[7]), .checks(c[7]));
  tb_bank_core #(.BACKEND(0), .ECC_EN(1), .RL(1), .INIT(0), .PWRRAND(1), .NAME("generic_pwrrand_noinit")) u8 (.clk, .rst_n, .done(d[8]), .errors(e[8]), .checks(c[8]));

  initial begin
    int all_done;
    repeat (4) @(posedge clk);
    rst_n = 1;
    all_done = 0;
    for (int t = 0; t < 2_000_000 && !all_done; t++) begin
      @(posedge clk);
      all_done = 1;
      for (int i = 0; i < N; i++) if (!d[i]) all_done = 0;
    end
    `CHECK(all_done, "all bank-adapter configurations completed")
    for (int i = 0; i < N; i++) begin tb_errors += e[i]; tb_checks += c[i]; end
    // power-up garbage must be visible to ECC when no init sweep runs
    `CHECK(u8.pr_ue + u8.pr_ce > 48, "random power-up contents are flagged by ECC without init")
    `CHECK(u7.p1_err == 0, "init sweep leaves no ECC errors on random power-up contents")
    $display("pwrrand_noinit: CE=%0d UE=%0d of 64 words", u8.pr_ce, u8.pr_ue);
    `TB_FINISH("tb_bank_adapter")
  end
endmodule
