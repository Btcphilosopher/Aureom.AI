#!/usr/bin/env python3
"""
Mutation check for the IronMemory testbenches.

Each mutation injects one deliberate RTL bug into a scratch copy of the RTL
and runs the testbench that should catch it. A mutation is CAUGHT when the
testbench reports FAIL, an assertion fires, or the run aborts. All mutations
must be caught; a MISSED mutation means the verification has a blind spot.

  python3 tests/iron_memory/mutation_test.py            # all
  python3 tests/iron_memory/mutation_test.py M2_perm_ignored
"""
import os, shutil, subprocess, sys, tempfile

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..'))
TST = os.path.join(ROOT, 'tests', 'iron_memory')
CORE = ['sf_iron_pkg.sv', 'sf_iron_secded.sv', 'sf_iron_sram_generic.sv', 'sf_iron_sram_fpga.sv',
        'sf_iron_sram_asic.sv', 'sf_iron_bank_adapter.sv', 'sf_iron_bank_arbiter.sv', 'sf_iron_rob.sv',
        'sf_iron_memory_map.sv', 'sf_iron_buffer_manager.sv', 'sf_iron_extmem_adapter.sv', 'sf_iron_memory.sv']

MUTS = {
    'M1_read_data_flip': ('sf_iron_bank_adapter.sv',
        "? (d_data & be2mask(d_be)) : '0;", "? ((d_data ^ 64'h1) & be2mask(d_be)) : '0;", 'tb_iron_memory'),
    'M2_perm_ignored': ('sf_iron_buffer_manager.sv',
        "allow = chk_we[gp] ? d_wr[id][DOM] : d_rd[id][DOM];", "allow = 1'b1;", 'tb_iron_memory'),
    'M3_rr_pointer_stuck': ('sf_iron_bank_arbiter.sv',
        "else if (|gnt)    ptr <=", "else if (1'b0)    ptr <=", 'tb_iron_memory'),
    'M4_rmw_merge_inverted': ('sf_iron_bank_adapter.sv',
        "((d_data & ~be2mask(d_be)) | (d_wd & be2mask(d_be)))",
        "((d_data & be2mask(d_be)) | (d_wd & ~be2mask(d_be)))", 'tb_iron_memory'),
    'M5_no_correction': ('sf_iron_secded.sv', "        data = d_in ^ flip;", "        data = d_in;", 'tb_iron_memory'),
    'M6_free_skips_drain': ('sf_iron_buffer_manager.sv',
        "if (d_infl[c_id] == '0 && inc_n[c_id] == 0) begin", "if (1'b1) begin", 'tb_buffer_manager'),
    'M7_bounds_unchecked': ('sf_iron_buffer_manager.sv',
        "contain[i] = d_use[i] && (lo >= d_start[i]) && (hi <= d_last[i]);",
        "contain[i] = d_use[i] && (lo >= d_start[i]) && (lo <= d_last[i]);", 'tb_iron_memory'),
    'M8_rob_ignores_backpressure': ('sf_iron_rob.sv',
        "assign pop       = rsp_valid && rsp_ready;", "assign pop       = rsp_valid;", 'tb_iron_memory'),
    'M9_rmw_no_port_block': ('sf_iron_bank_adapter.sv',
        "if ((m_go && need_rmw) || scrub_go) busy_cnt <= BCW'(RL + 1);",
        "if (scrub_go) busy_cnt <= BCW'(RL + 1);", 'tb_bank_adapter'),
    'M10_map_alias_high_bits': ('sf_iron_memory_map.sv',
        "    a_ext   = {1'b0, addr};", "    a_ext   = {1'b0, 8'h10, addr[23:0]};", 'tb_memory_map'),
    'M11_ext_tag_check_off': ('sf_iron_extmem_adapter.sv',
        "assign rsp_known = rsp_valid && out_q[rsp_tag];", "assign rsp_known = rsp_valid;", 'tb_extmem'),
    'M12_double_error_missed': ('sf_iron_secded.sv',
        "    end else if (s != '0) begin\n      ue = 1'b1;", "    end else if (1'b0) begin\n      ue = 1'b1;", 'tb_secded'),
}
TB_FILES = {
    'tb_iron_memory': CORE,
    'tb_buffer_manager': ['sf_iron_pkg.sv', 'sf_iron_buffer_manager.sv'],
    'tb_bank_adapter': CORE[:6],
    'tb_memory_map': ['sf_iron_pkg.sv', 'sf_iron_memory_map.sv'],
    'tb_extmem': ['sf_iron_pkg.sv', 'sf_iron_extmem_adapter.sv', 'sim/sf_iron_simdram.sv'],
    'tb_secded': ['sf_iron_pkg.sv', 'sf_iron_secded.sv'],
}


def run(name):
    fn, old, new, tb = MUTS[name]
    d = tempfile.mkdtemp(prefix=f'iron_{name}_')
    shutil.copytree(os.path.join(ROOT, 'rtl', 'albion'), os.path.join(d, 'albion'))
    p = os.path.join(d, 'albion', fn)
    src = open(p).read()
    if old not in src:
        return 'STALE (mutation anchor not found)'
    open(p, 'w').write(src.replace(old, new))
    rtl = os.path.join(d, 'albion')
    cmd = ['verilator', '--binary', '-j', '8', '--timing', '--assert', '-Wno-fatal', '-Wno-lint', '-Wno-style',
           '-Wno-TIMESCALEMOD', f'-I{rtl}', f'-I{TST}', '--top-module', tb, '-Mdir', os.path.join(d, 'obj'),
           '-o', 'tb'] + [os.path.join(rtl, f) for f in TB_FILES[tb]] + [os.path.join(TST, tb + '.sv')]
    b = subprocess.run(cmd, capture_output=True, text=True)
    if b.returncode:
        shutil.rmtree(d, ignore_errors=True)
        return 'BUILD_FAIL'
    try:
        r = subprocess.run([os.path.join(d, 'obj', 'tb')], capture_output=True, text=True, timeout=1800)
        out = r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        out = 'TIMEOUT'
    shutil.rmtree(d, ignore_errors=True)
    passed = ('PASS' in out.split('TB_RESULT')[-1].split('\n')[0]) if 'TB_RESULT' in out else False
    asserted = '%Error' in out or 'Assertion failed' in out
    return 'MISSED' if (passed and not asserted) else 'CAUGHT'


if __name__ == '__main__':
    names = sys.argv[1:] or list(MUTS)
    bad = 0
    for n in names:
        res = run(n)
        bad += res != 'CAUGHT'
        print(f'{n:30s} {res}  ({MUTS[n][3]})', flush=True)
    print(f'{len(names) - bad}/{len(names)} mutations caught')
    sys.exit(1 if bad else 0)
