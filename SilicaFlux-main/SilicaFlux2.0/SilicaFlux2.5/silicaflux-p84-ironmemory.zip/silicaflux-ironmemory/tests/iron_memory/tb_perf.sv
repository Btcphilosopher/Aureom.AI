// =============================================================================
// tb_perf : performance measurement scenarios for sf_iron_memory
//
// Every number printed here is read back from the DUT's own performance
// counters (CSR space) or counted from the DUT's port handshakes in this
// simulation. Units are clock cycles of the IronMemory clock; no clock
// frequency is assumed. Backend: generic SRAM model (cycle behaviour only).
// Output lines "PERF_JSON {...}" are collected by tools/perf_report.py.
// =============================================================================
`timescale 1ns/1ps
`include "tb_common.svh"

module tb_perf;
  import sf_iron_pkg::*;
  int tb_errors = 0;
  int tb_checks = 0;

`ifdef TB_NOECC
  localparam int ECC = 0;
  localparam string CFG = "ecc_off";
`else
  localparam int ECC = 1;
  localparam string CFG = "ecc_on";
`endif
  localparam int NP = 5, AW = 32, DW = 64, NB = 8, NBANK = 4, DEPTH = 1024, MAXO = 8;
  localparam logic [31:0] SB = 32'h1000_0000;
  localparam int WIN = NBANK * DEPTH * NB;       // 32 KiB
  localparam int IDW = 4, LEN_W = 16;
  localparam int NREQ = 2000;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NP-1:0] m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_ready, m_rsp_ecc_corr;
  logic [NP*AW-1:0] m_req_addr; logic [NP*3-1:0] m_req_size; logic [NP*DW-1:0] m_req_wdata, m_rsp_rdata;
  logic [NP*NB-1:0] m_req_wstrb; logic [NP*3-1:0] m_rsp_err;
  logic bm_cmd_valid, bm_cmd_ready, bm_rsp_valid, bm_rsp_in_use;
  logic [2:0] bm_cmd_op, bm_cmd_requester, bm_cmd_btype, bm_cmd_owner, bm_rsp_btype, bm_rsp_owner;
  logic [IDW-1:0] bm_cmd_id, bm_rsp_id; logic [AW-1:0] bm_cmd_start, bm_rsp_start;
  logic [LEN_W-1:0] bm_cmd_len, bm_rsp_len; logic [4:0] bm_cmd_rd_mask, bm_cmd_wr_mask, bm_rsp_rd_mask, bm_rsp_wr_mask;
  logic [3:0] bm_rsp_status; logic [7:0] bm_rsp_err_bits;
  logic csr_valid, csr_we, csr_rvalid, csr_err; logic [11:0] csr_addr; logic [31:0] csr_wdata, csr_rdata;
  logic init_done, irq;

  sf_iron_memory #(.NUM_PORTS(NP), .AW(AW), .DW(DW), .NUM_BANKS(NBANK), .BANK_DEPTH(DEPTH), .SRAM_BASE(SB),
    .ECC_EN(ECC), .MAX_OUT(MAXO), .GRAN_BYTES(256), .EXT_EN(0)) dut (
    .clk, .rst_n, .m_req_valid, .m_req_ready, .m_req_addr, .m_req_size, .m_req_we, .m_req_wdata, .m_req_wstrb,
    .m_rsp_valid, .m_rsp_ready, .m_rsp_rdata, .m_rsp_err, .m_rsp_ecc_corr,
    .bm_cmd_valid, .bm_cmd_ready, .bm_cmd_op, .bm_cmd_requester, .bm_cmd_id, .bm_cmd_btype, .bm_cmd_start,
    .bm_cmd_len, .bm_cmd_owner, .bm_cmd_rd_mask, .bm_cmd_wr_mask, .bm_rsp_valid, .bm_rsp_status, .bm_rsp_id,
    .bm_rsp_in_use, .bm_rsp_btype, .bm_rsp_start, .bm_rsp_len, .bm_rsp_owner, .bm_rsp_rd_mask, .bm_rsp_wr_mask,
    .bm_rsp_err_bits, .csr_valid, .csr_we, .csr_addr, .csr_wdata, .csr_rvalid, .csr_rdata, .csr_err,
    .ext_cmd_valid(), .ext_cmd_ready(1'b0), .ext_cmd_we(), .ext_cmd_addr(), .ext_cmd_wdata(), .ext_cmd_wstrb(), .ext_cmd_tag(),
    .ext_rsp_valid(1'b0), .ext_rsp_ready(), .ext_rsp_rdata(64'h0), .ext_rsp_err(1'b0), .ext_rsp_tag('0),
    .init_done, .irq, .trc_valid(), .trc_port(), .trc_seq(), .trc_we(), .trc_word(), .trc_be(), .trc_wdata());

  // ---------------- traffic generator ----------------
  int mode;                 // scenario id
  int n_left [NP], n_out [NP], n_rsp [NP], n_bad [NP];
  int k_idx [NP];
  logic [31:0] cyc;
  always_ff @(posedge clk) cyc <= rst_n ? cyc + 1 : 0;

  function automatic logic [31:0] wa(input int bank, input int word);   // interleaved address
    return SB + 32'((word * NBANK + bank) * 8);
  endfunction

  task automatic gen(input int p, input int k, output logic [31:0] a, output logic we, output logic [2:0] sz, output logic [7:0] st);
    sz = 3'd3; st = 8'hFF; we = 1'b0;
    case (mode)
      1: begin a = wa(p - 1, k % DEPTH); we = 1'b0; end                                     // independent streams
      2: begin a = SB + 32'($urandom_range(0, WIN / 8 - 1) * 8); we = $urandom_range(0, 1); end // uniform random
      3: begin a = wa(0, $urandom_range(0, DEPTH - 1)); we = 1'b0; end                      // hot bank
      4: begin a = SB + 32'($urandom_range(0, WIN - 1)); sz = 3'd0; we = 1'b1; end           // partial-write heavy
      5: begin                                                                              // DMA vs accelerator
           if (p == 1) begin a = SB + 32'((k * 8) % WIN); we = 1'b1; end
           else        begin a = SB + 32'($urandom_range(0, WIN / 8 - 1) * 8); we = 1'b0; end
         end
      6: begin a = SB + 32'($urandom_range(0, WIN / 8 - 1) * 8); we = 1'b1; end             // full-write random
      default: a = SB;
    endcase
  endtask

  bit active [NP];
  bit acc_flag [NP];
  initial begin
    m_req_valid = 0; m_req_addr = 0; m_req_size = 0; m_req_we = 0; m_req_wdata = 0; m_req_wstrb = 0; m_rsp_ready = '1;
    forever begin
      @(negedge clk);
      for (int p = 0; p < NP; p++) begin
        if (acc_flag[p]) begin m_req_valid[p] = 1'b0; acc_flag[p] = 0; end
        if (rst_n && active[p] && n_left[p] > 0) begin
          logic [31:0] a; logic we; logic [2:0] sz; logic [7:0] st;
          if (!m_req_valid[p]) begin
            gen(p, k_idx[p], a, we, sz, st);
            m_req_addr[p*AW +: AW] = a; m_req_we[p] = we; m_req_size[p*3 +: 3] = sz; m_req_wstrb[p*NB +: NB] = st;
            m_req_wdata[p*DW +: DW] = {$urandom, $urandom};
            m_req_valid[p] = 1;
          end
        end else m_req_valid[p] = 0;
      end
      #1;
      for (int p = 0; p < NP; p++) begin
        if (m_req_valid[p] && m_req_ready[p]) begin
          n_left[p]--; n_out[p]++; k_idx[p]++;
          acc_flag[p] = 1;   // transfer completes at the coming posedge; replace at next negedge
        end
        if (m_rsp_valid[p] && m_rsp_ready[p]) begin
          n_rsp[p]++; n_out[p]--;
          if (m_rsp_err[p*3 +: 3] != RSP_OK) n_bad[p]++;
        end
      end
    end
  end

  // A request accepted at negedge+1 transfers at the following posedge; the
  // next negedge replaces it, giving one new request per port per cycle.

  task automatic csr_wr(input logic [11:0] a, input logic [31:0] d);
    @(negedge clk); csr_valid = 1; csr_we = 1; csr_addr = a; csr_wdata = d; @(negedge clk); csr_valid = 0; csr_we = 0;
  endtask
  task automatic csr_rd(input logic [11:0] a, output logic [31:0] d);
    @(negedge clk); csr_valid = 1; csr_we = 0; csr_addr = a; @(negedge clk); csr_valid = 0; d = csr_rdata;
  endtask

  int t0, t1;
  task automatic run(input int m, input int ports_mask, input int nreq);
    int busy;
    mode = m;
    csr_wr(12'h038, 32'h1);
    for (int p = 0; p < NP; p++) begin
      active[p] = (ports_mask >> p) & 1; n_left[p] = active[p] ? nreq : 0; n_out[p] = 0; n_rsp[p] = 0; n_bad[p] = 0; k_idx[p] = 0;
    end
    @(posedge clk); t0 = cyc;
    do begin
      @(posedge clk);
      busy = 0;
      for (int p = 0; p < NP; p++) if (n_left[p] > 0 || n_out[p] > 0) busy = 1;
    end while (busy);
    t1 = cyc;
    for (int p = 0; p < NP; p++) active[p] = 0;
    repeat (4) @(posedge clk);
  endtask

  task automatic dump(input string name, input string note);
    logic [31:0] v;
    string s;
    int total_rsp, total_bytes;
    total_rsp = 0; total_bytes = 0;
    s = $sformatf("{\"cfg\":\"%s\",\"scenario\":\"%s\",\"note\":\"%s\",\"cycles\":%0d", CFG, name, note, t1 - t0);
    s = {s, ",\"banks\":["};
    for (int b = 0; b < NBANK; b++) begin
      s = {s, (b ? "," : ""), "["};
      for (int i = 0; i < 8; i++) begin csr_rd(12'h100 + 12'(b * 32 + i * 4), v); s = {s, (i ? "," : ""), $sformatf("%0d", v)}; end
      s = {s, "]"};
    end
    s = {s, "],\"ports\":["};
    for (int p = 0; p < NP; p++) begin
      s = {s, (p ? "," : ""), "["};
      for (int i = 0; i < 16; i++) begin
        csr_rd(12'h200 + 12'(p * 64 + i * 4), v); s = {s, (i ? "," : ""), $sformatf("%0d", v)};
        if (i == 3 || i == 4) total_bytes += v;
      end
      s = {s, "]"};
      total_rsp += n_rsp[p];
      `CHECK_EQ(n_bad[p], 0, {name, ": legal traffic produced no error responses"})
    end
    s = {s, "],\"global\":["};
    for (int i = 0; i < 20; i++) begin csr_rd(12'h400 + 12'(i * 4), v); s = {s, (i ? "," : ""), $sformatf("%0d", v)}; end
    s = {s, $sformatf("],\"tb_responses\":%0d,\"tb_bytes\":%0d}", total_rsp, total_bytes)};
    $display("PERF_JSON %s", s);
  endtask

  initial begin
    bm_cmd_valid = 0; bm_cmd_op = 0; bm_cmd_requester = 0; bm_cmd_id = 0; bm_cmd_btype = 0; bm_cmd_start = 0;
    bm_cmd_len = 0; bm_cmd_owner = 0; bm_cmd_rd_mask = 0; bm_cmd_wr_mask = 0; csr_valid = 0; csr_we = 0; csr_addr = 0; csr_wdata = 0;
    for (int p = 0; p < NP; p++) begin active[p] = 0; n_left[p] = 0; n_out[p] = 0; acc_flag[p] = 0; end
    repeat (4) @(posedge clk); rst_n = 1;
    while (!init_done) @(posedge clk);
    // one window-wide buffer, every domain may read and write
    @(negedge clk);
    bm_cmd_valid = 1; bm_cmd_op = BM_ALLOC; bm_cmd_requester = DOM_KEYSTONE; bm_cmd_len = LEN_W'(WIN);
    bm_cmd_owner = DOM_KEYSTONE; bm_cmd_rd_mask = '1; bm_cmd_wr_mask = '1; bm_cmd_btype = BT_DMA_STAGING;
    @(negedge clk); bm_cmd_valid = 0;
    while (!bm_rsp_valid) @(posedge clk);

    run(1, 5'b11110, NREQ); dump("independent_streams", "4 masters, each streaming 64-bit reads to its own bank");
    run(2, 5'b11111, NREQ); dump("uniform_random", "5 masters, random 64-bit reads/writes over the window");
    run(3, 5'b11111, NREQ); dump("hot_bank", "5 masters, all 64-bit reads to bank 0");
    run(4, 5'b11111, NREQ); dump("partial_write_heavy", "5 masters, random 1-byte writes (ECC read-modify-write)");
    run(6, 5'b11111, NREQ); dump("full_write_random", "5 masters, random 64-bit full writes");
    run(5, 5'b01010, NREQ); dump("dma_vs_accel_equal", "BridgeEngine sequential streaming writes vs ComputeWorks random reads, equal priority");
    csr_wr(12'h014, 32'b01000);
    run(5, 5'b01010, NREQ); dump("dma_vs_accel_hipri", "same, ComputeWorks high priority");
    csr_wr(12'h014, 32'b00000);
    // buffer occupancy: free the window-wide buffer, then fill the
    // descriptor table with mixed buffers until space / descriptors run out
    @(negedge clk);
    bm_cmd_valid = 1; bm_cmd_op = BM_FREE; bm_cmd_requester = DOM_KEYSTONE; bm_cmd_id = '0;
    @(negedge clk); bm_cmd_valid = 0;
    while (!bm_rsp_valid) @(posedge clk);
    csr_wr(12'h038, 32'h1);
    begin
      int sizes [6] = '{4096, 1500, 9000, 256, 64, 2048};
      for (int i = 0; i < 16; i++) begin
        @(negedge clk);
        bm_cmd_valid = 1; bm_cmd_op = BM_ALLOC; bm_cmd_requester = DOM_KEYSTONE; bm_cmd_len = LEN_W'(sizes[i % 6]);
        bm_cmd_owner = 3'(i % 5); bm_cmd_btype = 3'(i % 6); bm_cmd_rd_mask = '1; bm_cmd_wr_mask = '1;
        @(negedge clk); bm_cmd_valid = 0;
        while (!bm_rsp_valid) @(posedge clk);
      end
      t0 = 0; t1 = 0;
      dump("buffer_occupancy", "16 allocation requests of mixed type and size (4096/1500/9000/256/64/2048 B) into an empty 32 KiB pool");
    end
    `TB_FINISH($sformatf("tb_perf_%s", CFG))
  end
  initial begin #200ms; $display("TB_RESULT tb_perf FAIL timeout"); $finish; end
endmodule
