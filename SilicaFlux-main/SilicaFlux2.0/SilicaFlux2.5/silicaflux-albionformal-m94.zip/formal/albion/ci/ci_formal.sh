#!/usr/bin/env bash
# AlbionFormal CI entry point.  Usage: ci/ci_formal.sh [smoke|full|mutate|all]   (default: smoke)
#   smoke   jobs tagged "smoke": fast proofs + covers of every module (minutes)
#   full    every proof/cover job (tens of minutes on 4 cores)
#   mutate  the mutation campaign (needs the detector jobs' RTL only)
#   all     full + mutate + assumption sensitivity + ledger
# Exit status is non-zero if any gate in scripts/check_gates.py fails.
set -euo pipefail
cd "$(dirname "$0")/.."
MODE="${1:-smoke}"
JOBS="${ALBION_JOBS:-$(nproc)}"
python3 scripts/albion_formal.py selfcheck
mkdir -p reports/results build/logs
case "$MODE" in
  smoke)  python3 scripts/albion_formal.py run --tag smoke -j "$JOBS" ;;
  full)   python3 scripts/albion_formal.py run --tag full  -j "$JOBS" ;;
  mutate) python3 scripts/albion_formal.py mutate all -j "$JOBS" ;;
  all)    python3 scripts/albion_formal.py run --tag full -j "$JOBS"
          python3 scripts/albion_formal.py mutate all -j "$JOBS"
          python3 scripts/albion_formal.py sensitivity all ;;
  *) echo "unknown mode $MODE"; exit 2 ;;
esac
python3 scripts/make_env.py
python3 scripts/make_ledger.py
if [ "$MODE" = "all" ]; then python3 scripts/check_gates.py --require-all; else python3 scripts/check_gates.py; fi
