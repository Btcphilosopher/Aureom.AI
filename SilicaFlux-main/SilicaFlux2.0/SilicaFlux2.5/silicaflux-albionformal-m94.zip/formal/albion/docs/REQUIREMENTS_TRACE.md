# Requirement trace: Module 94 brief -> RTL -> properties -> jobs

Property ids are those of `config/properties.json`; results are in `reports/PROOF_LEDGER.md`. "Not applicable /
not present" items are stated plainly, not papered over.

## What was verified (the RTL under test)

| Brief says | Actual RTL | Notes |
|---|---|---|
| "SilicaFlux RTL architecture" | **Albion P90** `rtl/albion` (DataFabric, banked SRAM, DMA, permission) and **Citadel P89** `rtl/albion` (domain table, permission checker, gate) | vendored unmodified in `vendor/`, hashes in `vendor/SOURCES.sha256` |
| "DataFabric" | `sf_albion_datafabric` (4 masters x NB+2 slaves, permission stage before arbitration) | |
| "SRAM" | `sf_albion_sram_bank` (+ `sf_albion_secded`, `sf_albion_sram_macro`) | |
| "DMA" | `sf_albion_dma` (+ `sf_albion_fifo`) | single 4-byte beats; **no bursts** |
| "DomainGuard and related modules" | **No module is named DomainGuard.** Verified instead: Albion permission stage (`sf_albion_datafabric` + `sf_albion_perm`) and Citadel `sf_citadel_domain_table`, `sf_citadel_permission`, `sf_citadel_gate` | see U-DOMAINGUARD |

## 2. DataFabric correctness

| Requirement | Properties | Jobs |
|---|---|---|
| Requests are not duplicated | FAB_HANDSHAKE_1TO1, FAB_NO_SPURIOUS_READY, FAB_GRANT_EXCLUSIVE | FAB-NB{1,2,3,4,8}-* |
| Responses correspond to requests | FAB_RSP_NO_SPURIOUS, FAB_RSP_ROUTING, FAB_RSP_LOCAL_ERROR, FAB_RSP_ONE_SOURCE, FAB_RSP_DELIVERED, FAB_LOCAL_ERR_ACCEPTED (conditional on MASTER_1PO and SLAVE_RSP_MATCH; SRAM_RSP_MATCH backs the latter for SRAM banks; MASTER_1PO is only partly and circularly backed by DMA_PORT_1PO, see U-SYSTEM) | same |
| Transaction identifiers remain valid | FAB_TXN_ID_VALID, FAB_REQ_INTEGRITY | same |
| Mutually exclusive grants never overlap | FAB_GRANT_EXCLUSIVE, FAB_ARB_WORK_CONSERVING; bounded fairness FAB_ARB_BOUNDED_WAIT (conditional) | FAB-NB*, FAB-ARB-* |
| FIFO occupancy remains within bounds | FIFO_COUNT_BOUND, FIFO_FLAGS, FIFO_COUNT_MODEL, FIFO_ORDER (standalone) and DMA_FIFO_BOUNDS (inside the DMA) | FIFO-D4-W8-IND, DMA-* |
| No invalid routing destination is selected | FAB_NO_INVALID_ROUTE, FAB_DENIED_NOT_FORWARDED | FAB-NB* |

## 3. SRAM correctness

| Requirement | Properties | Jobs |
|---|---|---|
| No illegal write enable | SRAM_WRITE_ENABLE_LEGAL, SRAM_SCRUB_WRITES_ONLY | SRAM-W8-IND |
| Unwritten bytes remain unchanged | SRAM_UNWRITTEN_BYTES_STABLE | SRAM-W8-IND |
| Read/write behaviour matches the specification | SRAM_READ_MATCHES_MODEL, SRAM_RSP_MATCH, SRAM_NO_ECC_EVENT_CLEAN, SRAM_MACRO_CONTRACT; code-level ECC: SECDED_CLEAN_ROUNDTRIP, SECDED_SINGLE_CORRECTED, SECDED_DOUBLE_DETECTED | SRAM-*, SECDED-* |
| Protected addresses reject unauthorised writes | The SRAM bank has no permission logic (it is a slave). The protection is the fabric's: FAB_DMA_NO_FW_BANK, FAB_DENIED_NOT_FORWARDED, FAB_HOST_POLICY, plus SRAM_NO_ACCEPT_DURING_SCRUB. End-to-end (DMA+fabric+banks) is **not** composed: U-SYSTEM below | FAB-*, SRAM-* |
| Reset establishes documented control states | SRAM_RESET_STATE, SRAM_SCRUB_BOUNDED, SRAM_READY_GATING, DMA_RESET_STATE, PERM_RESET_DEFAULT_DENY, FAB_RESET_QUIESCENT, CIT_GATE_RESET_STATE, CIT_TBL_RESET_DEFAULT_DENY | |

## 4. DMA correctness

| Requirement | Properties |
|---|---|
| Transfer counters remain valid | DMA_COUNTERS_VALID, DMA_BYTES_BOUND (**bounded**: induction not closed, U-DMA-ERRPATH) |
| Bursts respect configured boundaries | DMA_WR_BEAT_BOUNDS, DMA_RD_BEAT_BOUNDS. The DMA has no bursts; "burst boundary" is read as: every 4-byte beat inside [SRC,SRC+LEN)/[DST,DST+LEN), aligned, no 2^32 wrap |
| Descriptors cannot exceed validated limits | DMA_VALIDATION_EXACT, DMA_DESCRIPTOR_LIMITS, DMA_DESCRIPTOR_FROZEN, DMA_BUSY_WRITE_REJECTED, DMA_BADPARAM_REJECTED |
| Completed transfers have consistent accounting | DMA_ACCOUNTING_OK, DMA_ACCOUNTING_ERR (**bounded**), DMA_STATUS_CONSISTENT |
| Illegal requests do not mutate protected memory | at DMA level: DMA_NO_TRAFFIC_WHEN_IDLE, DMA_BADPARAM_REJECTED, beat bounds; at fabric level FAB_DENIED_NOT_FORWARDED / FAB_DMA_*. The composed end-to-end proof is not part of this suite (U-SYSTEM) |

## 5. Security properties

| Requirement | Properties |
|---|---|
| Denied writes cannot reach memory | FAB_DENIED_NOT_FORWARDED, FAB_DMA_WINDOW_COVERED, FAB_DMA_NO_FW_BANK; Citadel: CIT_WRITE_NEEDS_WRITE_RIGHT, CIT_GATE_NO_BYPASS, CIT_GATE_WRITE_NEEDS_RIGHT |
| Domain identifiers remain associated with requests | FAB_REQ_INTEGRITY, CIT_GATE_DOMAIN_ASSOCIATION, CIT_ATTRIBUTION, CIT_SPOOFED_DOMAIN_DENIED |
| Permission checks cannot be bypassed | CIT_PERMIT_IMPLIES_SPEC, CIT_PERMIT_STATUS_COUPLING, CIT_ISOLATION_AND_LOCKDOWN, CIT_DEFAULT_DENY, CIT_TBL_UNPRIVILEGED_REJECTED, CIT_TBL_CFG_GATED, CIT_TBL_EXCLUSIVE_DISJOINT, FAB_HOST_POLICY |
| Invalidation prevents stale translation use | **No translation hardware exists** (U-TRANSLATION). Proven stale-use analogues: CIT_TBL_REVOKE_INVALIDATES, CIT_TBL_STALE_DOMAIN_DENIED, CIT_TBL_CLRWIN_INVALIDATES, CIT_TBL_STALE_WINDOW_INVALID, CIT_GATE_NO_BYPASS (no stale/inherited verdict); Albion window revocation: PERM_WINDOW_MATCHES_SPEC + FAB_DMA_WINDOW_COVERED (an invalidated window grants nothing) |

## 6-8. Methodology, validation, reporting

| Requirement | Where |
|---|---|
| Distinguish bounded / inductive / conditional / cover / unproven / timeout | `docs/METHODOLOGY.md` section 2; result class on every ledger row; unresolved register |
| Realistic environmental assumptions; no unbounded liveness without a fairness model | `config/assumptions.json`; methodology section 7; U-LIVENESS |
| Cover properties to detect vacuous assumptions | `C_*` covers in every harness; ledger section 4; CI gate G3 |
| Controlled mutations | `mutants/mutants.json`, ledger section 6 |
| Proof ledger | `reports/PROOF_LEDGER.md` / `.json` / `.csv` |

## Not covered by this suite

U-SYSTEM: a composed DMA + fabric + SRAM-bank proof that "an illegal DMA request never changes protected memory" was designed but
**not built**. The conclusion currently rests on the conjunction of FAB_DENIED_NOT_FORWARDED (nothing illegal reaches a bank),
SRAM_WRITE_ENABLE_LEGAL (a bank writes only on an accepted request) and DMA_WR_BEAT_BOUNDS, argued in prose, not machine-checked as one theorem.
