# AlbionFormal methodology

This document says what each kind of result in the ledger means, how the proofs are built, and exactly where
the tool flow could be wrong. Read it before quoting any number from `reports/PROOF_LEDGER.md`.

## 1. Flow

```
vendor/ (RTL snapshot, sha256-pinned)          harness/ (spec models, monitors, properties)   lib/ (macros, reset env)
        |                                                   |
        +--------------- scripts/albion_formal.py ----------+
              1. verify hashes   2. copy RTL to build/<job>/rtl, apply bind include(s) and (mutation runs) a single-point bug
              3. yosys: read_verilog -formal -sv -DFORMAL -DSYNTHESIS ; chparam ; prep -flatten
              4. discover labelled properties and assumptions, REFUSE undeclared assumptions
              5. engine:  smtbmc z3 (--unroll)  BMC + k-induction (+greatest-inductive-subset fixpoint)   | abc pdr (IC3)
                          abc iprove (combinational miter)     | smtbmc cover
              6. classify, isolate failing properties, write counterexample reports, record input hashes
```

* **Engines.** `yosys-smtbmc` (BMC, k-induction, cover) with z3 4.8.12; `yosys-abc` `pdr` for unbounded proofs and as an
  independent cross-check of the k-induction results; `yosys-abc` `iprove` for the exhaustive combinational SECDED proofs;
  cvc5 1.1.2 cross-checks the small combinational jobs (it is ~100x slower than z3 on the sequential models).
* **SymbiYosys.** The environment that produced the shipped results could not install `sby` (not in apt/PyPI, GitHub
  downloads are blocked by the sandbox policy). `scripts/albion_formal.py` therefore runs the same `yosys` + `yosys-smtbmc` /
  `yosys-abc` sequence that sby generates for its `smtbmc` and `abc pdr` engines, and writes an equivalent `job.sby` per
  smtbmc job. **Those `.sby` files were never executed.** If you have sby, `sby -f build/<job>/job.sby` is a useful
  independent check; discrepancies should be reported.
* **Why not `assert property (... |-> ...)`.** The open-source Yosys front end (0.33) accepts immediate assertions and
  trivially simple `assert property (expr)` only. Sequences, `|->`, `##n` need the commercial Verific front end. Every
  temporal property is therefore written as the monitor state machine + immediate assertion it reduces to, with the SVA
  it stands for documented in `lib/albion_formal.svh`. If you have a SVA-capable tool the macros map 1:1.

## 2. Result classes (never mixed)

| Class | Rule used by the driver | What you may claim |
|---|---|---|
| PROVEN | k-induction (k as stated, with the BMC base case to the same depth) or IC3/PDR converged, **and** the job's assumptions are only the structural ones (ideal clock, reset in step 0) | the property holds in every reachable state, for all time |
| PROVEN-COND | same proof, but the job declares at least one non-structural assumption | the same, **provided the assumptions hold in the SoC**; see the assumption register |
| BOUNDED | BMC found no counterexample within N cycles from reset; induction was not closed (or not attempted) | nothing about traces longer than N |
| FAIL | counterexample (VCD + report) | a real violation *of this harness* — check the report to decide between RTL bug and harness error (several early harness errors were found this way; see section 8) |
| TIMEOUT | solver exceeded the job limit | no claim |
| VACUOUS | `--presat` found the assumptions contradictory | the result is meaningless |
| COVER-REACHED/UNREACHED | witness exists / does not exist under the same environment | evidence against / for vacuity |

Unproven claims are not hidden in this table: they are listed in `config/unresolved.json` (ledger section 7).

## 3. Techniques

* **Tracked word / tracked window.** Memory-like state (SRAM words, permission windows, descriptor slots) is checked with a
  free *constant* index `(* anyconst *)` and a byte-exact shadow of that one element. A proof for an arbitrary index is a
  proof for every index and its cost does not grow with the size of the memory.
* **Bind emulation.** Yosys has no `bind`. The driver inserts `` `include "harness/bind/<x>.svh" `` just before the
  `endmodule` of the module under test **in a copy under `build/`**. The vendored RTL is never edited (hashes are checked
  before every run). This gives properties access to internal state for inductive lemmas. Yosys does **not** support
  hierarchical references (`u_mem.mem`); they silently elaborate to undefined values — never use them.
* **Assume-guarantee.** The SRAM bank proof assumes the memory-macro contract (`MACRO_CONTRACT`); the macro job proves it for the
  behavioural macro (non-circular). The fabric proofs assume `MASTER_1PO` / `SLAVE_RSP_MATCH`. `SLAVE_RSP_MATCH` is established
  for SRAM banks by `SRAM_RSP_MATCH` (non-circular). `MASTER_1PO` is **not** soundly discharged: the DMA ports obey it
  (`DMA_PORT_1PO`) only under `DMA_RSP_OUT`, which the fabric provides (`FAB_RSP_NO_SPURIOUS`) only under `MASTER_1PO` - a circular
  argument that this suite does not close with a composed proof (U-SYSTEM). The CORE/HOST masters and the MMIO/HOSTMEM slaves are not
  verified at all. The assumption register states this per assumption.
* **Independent specification.** Permission and decode properties are re-derived from the documents
  (`security_model.md`, module headers, `02_PERMISSION_CHECKER.md`) in `fabric_bind.svh` / `fv_cit_spec.sv`, not copied
  from the RTL's priority logic. The Citadel spec is deliberately an over-approximation ("exists a slot ...") so
  `permit => spec` is a *safety* claim; completeness is not claimed.
* **Helper lemmas and the greatest inductive subset.** Lemmas (`L_*`) are real assertions proven jointly. If k-induction
  fails, the driver removes only the assertions the induction step violates and repeats; survivors are a self-contained
  inductive proof, removed ones fall back to BOUNDED. Nothing is ever assumed that was not proven.
* **Snapshot method** (Citadel gate). The spec verdict and request fields are recorded in the cycle the gate first
  evaluates a request; whatever the gate later presents to the target must be backed by *that* snapshot. This detects stale or
  inherited verdicts (mutants CITG-M03, CITG-M04) without modelling the gate's internal latch.

## 4. Assumption discipline

* Every `assume` carries the label `S_<ID>`; `<ID>` must exist in `config/assumptions.json`, otherwise the job aborts
  (`undeclared assumption`). This prevents quiet over-constraint.
* The catalogue gives each assumption a category (structural / protocol / config / scope), a risk statement and what
  discharges it. `reports/results/assumption_sensitivity.json` records, per job, whether dropping an assumption makes a
  property fail (assumption *needed*) or not (redundant for that job).
* `reports/sensitivity/cex/` holds the counterexamples obtained when an assumption is dropped on purpose (what the assumption protects against). A dropped assumption that produces *no* violation within the bounded run is reported as exactly that, never as "redundant".
* Reset: `sf_fv_ctrl` asserts reset in step 0. State-dependent properties are gated on `sf_live` (step >= 1) because DUT
  flip-flops are unconstrained in step 0. Most jobs use "reset anywhere" (reset may re-assert at any cycle).

## 5. Vacuity

* Every harness contains `C_*_ENV_SATISFIABLE` (a trace of N steps satisfying all assumptions exists) and scenario covers
  (grant per master, denial, window hit, response from slave/local, scrub done, partial write, read after partial write,
  read error, write error, transfer done, ...). Covers are gated on `sf_live`: a cover reached only in the
  unconstrained step 0 would prove nothing.
* BMC runs use `--presat`, which reports `Assumptions are unsatisfiable` (class VACUOUS).
* The CI gate fails if any cover is unreached.

## 6. Mutation testing

`mutants/mutants.json` (generated by `scripts/gen_mutants.py`, which also checks that each pattern occurs exactly once)
holds single-point bugs in security- and function-relevant logic. A mutant is run through the detector job in BMC mode; it
is *killed* if some assertion fails. Survivors must carry a written waiver. A kill proves the property can fail for that class
of bug; it does not prove the property set is complete.

## 7. Liveness policy

No unbounded liveness is claimed anywhere. Liveness needs a fairness model of the environment (slaves/targets eventually accept
and respond) that is not part of any RTL contract here. What is proven instead is *bounded*: local error responses arrive in
the next cycle (`FAB_RSP_LOCAL_ERROR`), the scrub finishes exactly WORDS cycles after reset (`SRAM_SCRUB_BOUNDED`), and, under
the explicit assumption `SLAVE_READY_ALWAYS`, an eligible fabric request waits at most NM-1 cycles (`FAB_ARB_BOUNDED_WAIT`).
These are safety properties with a bound, labelled CONDITIONAL where they depend on an assumption.

## 8. Soundness caveats of this tool flow

1. **`--unroll`.** z3 cannot parse Yosys's `define-fun` wire functions on models of this size (macro expansion turns the DAG
   into a tree; a 450 KB model did not finish parsing in 10 minutes). `yosys-smtbmc --unroll` rewrites each function
   application into one cached definition. This is a semantics-preserving transformation done by the tool; it changes speed, not meaning.
2. **Two-state semantics.** Yosys formal is 2-state; `setundef -anyseq` turns undriven values into free inputs. X-propagation is not modelled.
3. **Asynchronous reset** (Citadel) is modelled step-synchronously by `async2sync`: the reset clears state in the cycle it is
   asserted. A property about the cycle after a command must therefore be conditioned on `rst_n` (an early harness bug).
4. **Single ideal clock**, no CDC, no reset-deassertion timing (assumption CLK_IDEAL).
5. **Reduced parameter points** (SRAM WORDS=8, Citadel NDOM=2/NW=2, fabric NB in {1,2,3,4,8} with NW 2 or 8). Parametricity is
   argued, not machine-checked, except where the ledger shows several parameter points.
6. **Early harness errors** found by counterexample review (kept as a record of why reports must be read, not just counted):
   a truncated width in a lemma (`AW'(WORDS)`), reset history captured in the unconstrained step 0, a harness input wider than the
   RTL port, a monitor lagging the DUT by one cycle, an ungated state property. None was an RTL defect.
7. The shipped mutation campaign shows the assertions *can* fail; it is not a completeness argument.

## 9. Adding a property

1. Write it in the relevant `harness/bind/*.svh` (or harness) with a macro: `` `SF_ASSERT(NAME, expr) ``, `` `SF_ASSERT_IMPL(NAME, ante, cons) ``,
   `` `SF_LEMMA(...) ``, `` `SF_COVER(...) ``. 2. Add its description to `config/properties.json`. 3. If it needs an environment
   constraint use `` `SF_ASSUME(ID, expr) `` and declare `ID` in `config/assumptions.json` and in the job. 4. Add a mutant that
   should violate it to `scripts/gen_mutants.py`. 5. `python3 scripts/albion_formal.py run <JOB>`; read the counterexample first if it fails.
