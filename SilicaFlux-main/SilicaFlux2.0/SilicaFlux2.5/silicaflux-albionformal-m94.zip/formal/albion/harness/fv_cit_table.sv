// =============================================================================
//  fv_cit_table.sv -- formal harness: sf_citadel_domain_table + the REAL sf_citadel_permission it feeds.
//  The command port (requester domain / privilege / opcode / arguments), the containment hook and the
//  lookup ports are FREE inputs: ANY command sequence from ANY requester (A-CFG is therefore NOT assumed;
//  it is listed in the ledger because the isolation theorem is only meaningful given it).
//  The permission request (domain label, address, op, attributes, safety levels) is free as well.
//
//  "Invalidation prevents stale use": the table has no address translation (docs/citadel/08: "No address
//  translation / IOMMU"), so the stale-use hazard that exists is a stale DOMAIN DESCRIPTOR or WINDOW:
//   - after REVOKE of a slot, requests naming that domain id are denied until it is enrolled again;
//   - after CLR_WINDOW, the window is invalid and stays invalid until the next SET_WINDOW for it.
//  Both are proven END TO END (table -> real permission checker).
// =============================================================================
`include "albion_formal.svh"
module fv_cit_table #(
  parameter int unsigned NDOM = 2,
  parameter int unsigned NW   = 2,
  parameter int unsigned NP   = 1,
  parameter int unsigned NQ   = 2,
  parameter int unsigned NKEY = 1,
  parameter int unsigned AW   = 6,
  parameter int WIT = 4
) (
  input  logic                    clk,
  input  logic                    rst_free,
  // command port (free)
  input  logic                    cfg_en_i,
  input  logic                    cmd_valid_i,
  input  logic [3:0]              cmd_op_i,
  input  logic [7:0]              cmd_dom_i,
  input  logic                    cmd_priv_i,
  input  logic [((NDOM > 1) ? $clog2(NDOM) : 1)-1:0] cmd_slot_i,
  input  logic [((NW   > 1) ? $clog2(NW)   : 1)-1:0] cmd_win_i,
  input  logic [((NP   > 1) ? $clog2(NP)   : 1)-1:0] cmd_port_i,
  input  logic [7:0]              cmd_arg_dom_i,
  input  logic [7:0]              cmd_flags_i,
  input  logic [63:0]             cmd_data0_i,
  input  logic [63:0]             cmd_data1_i,
  input  logic                    qtn_valid_i,
  input  logic [((NDOM > 1) ? $clog2(NDOM) : 1)-1:0] qtn_slot_i,
  input  logic [7:0]              look_dom_i,
  input  logic [AW-1:0]           own_addr_i,
  // permission request (free)
  input  logic [7:0]              dom_i,
  input  logic [3:0]              op_i,
  input  logic [7:0]              attr_i,
  input  logic [AW-1:0]           addr_i,
  input  logic [31:0]             len_i,
  input  logic [1:0]              cls_i,
  input  logic [7:0]              idx_i,
  input  logic                    lockdown_i,
  input  logic                    dft_active_i,
  input  logic [NQ-1:0]           qhold_i,
  input  logic [NP-1:0]           port_isol_i
);
  localparam int unsigned SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1;
  localparam int unsigned WIN_W  = (NW   > 1) ? $clog2(NW)   : 1;
  localparam int unsigned PORT_W = (NP   > 1) ? $clog2(NP)   : 1;
  localparam logic [AW-1:0] DEV_LO = {2'b11, {(AW-2){1'b0}}};
  localparam logic [AW-1:0] DEV_MK = {2'b11, {(AW-2){1'b0}}};

  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(1)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);

  logic              rsp_valid_o, cmd_deny_o, ctl_clr_safe_o, ctl_clr_cnt_o, ctl_thresh_we_o, zero_valid_o, look_found_o, own_found_o, lock_o;
  logic [3:0]        rsp_status_o;
  logic [NQ-1:0]     ctl_clr_qhold_o;
  logic [NP-1:0]     ctl_clr_isol_o;
  logic [15:0]       ctl_thresh_o;
  logic [NKEY-1:0]   zero_mask_o;
  logic [NDOM-1:0]   slot_clr_o;
  logic [SLOT_W-1:0] look_slot_o, own_slot_o;
  logic [NDOM*2-1:0] slot_state_o;
  logic [NDOM*8-1:0] slot_id_o;
  logic [NDOM-1:0]   slot_priv_o, slot_secure_o;
  logic [NDOM*NW-1:0] win_valid_o, win_r_o, win_w_o, win_x_o, win_excl_o;
  logic [NDOM*NW*AW-1:0] win_base_o, win_limit_o;
  logic [NDOM*1-1:0] devrd_o, devwr_o;
  logic [NDOM*NQ-1:0] qmask_o;
  logic [NDOM*NKEY-1:0] kmask_o;
  logic [NP*NDOM-1:0] bind_o;

  sf_citadel_domain_table #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(1), .NQ(NQ), .NKEY(NKEY), .AW(AW),
                            .DEV_BASE(DEV_LO), .DEV_MASK(DEV_MK)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .cfg_en_i, .cmd_valid_i, .cmd_op_i, .cmd_dom_i, .cmd_priv_i, .cmd_slot_i, .cmd_win_i, .cmd_port_i, .cmd_arg_dom_i, .cmd_flags_i,
    .cmd_data0_i, .cmd_data1_i, .rsp_valid_o, .rsp_status_o, .cmd_deny_o,
    .ctl_clr_qhold_o, .ctl_clr_isol_o, .ctl_clr_safe_o, .ctl_clr_cnt_o, .ctl_thresh_we_o, .ctl_thresh_o,
    .qtn_valid_i, .qtn_slot_i, .zero_valid_o, .zero_mask_o, .slot_clr_o,
    .look_dom_i, .look_found_o, .look_slot_o, .own_addr_i, .own_found_o, .own_slot_o,
    .slot_state_o, .slot_id_o, .slot_priv_o, .slot_secure_o, .win_valid_o, .win_base_o, .win_limit_o,
    .win_r_o, .win_w_o, .win_x_o, .win_excl_o, .devrd_o, .devwr_o, .qmask_o, .kmask_o, .bind_o, .lock_o);

  logic              permit_o, slot_vld_o;
  logic [3:0]        reason_o, status_o;
  logic [SLOT_W-1:0] slot_o;
  sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(1), .NQ(NQ), .AW(AW), .LEN_W(32),
                          .DEV_BASE(DEV_LO), .DEV_MASK(DEV_MK), .DEV_PRIV(1'b1), .DEV_SECURE(1'b0)) u_perm (
    .src_i('0), .dom_i, .op_i, .attr_i, .addr_i, .len_i, .cls_i, .idx_i, .lockdown_i, .dft_active_i, .qhold_i, .port_isol_i,
    .slot_state_i(slot_state_o), .slot_id_i(slot_id_o), .slot_priv_i(slot_priv_o), .slot_secure_i(slot_secure_o),
    .win_valid_i(win_valid_o), .win_base_i(win_base_o), .win_limit_i(win_limit_o), .win_r_i(win_r_o), .win_w_i(win_w_o), .win_x_i(win_x_o),
    .devrd_i(devrd_o), .devwr_i(devwr_o), .qmask_i(qmask_o), .bind_i(bind_o),
    .permit_o, .reason_o, .status_o, .slot_vld_o, .slot_o);

  // ---- previous-cycle copies: the command presented last cycle, and the state BEFORE it took effect ----------------
  logic [3:0]  p_op;  logic p_valid, p_priv, p_qtn;
  logic [7:0]  p_dom, p_arg;
  logic [SLOT_W-1:0] p_slot, p_qslot;
  logic [WIN_W-1:0]  p_win;
  logic [NDOM*2-1:0] p_state;
  logic [NDOM*8-1:0] p_id;
  logic [NDOM*NW-1:0] p_wv;
  logic [NDOM*NW*AW-1:0] p_wb, p_wl;
  logic [NDOM*NW-1:0] p_wr, p_ww, p_wx, p_we;
  logic [NP*NDOM-1:0] p_bind;
  logic p_lock, p_prev_rst, p_cfg;
  initial begin p_valid = 1'b0; p_prev_rst = 1'b0; p_qtn = 1'b0; end
  always_ff @(posedge clk) begin
    p_valid <= cmd_valid_i && rst_n; p_op <= cmd_op_i; p_dom <= cmd_dom_i; p_priv <= cmd_priv_i; p_slot <= cmd_slot_i;
    p_win <= cmd_win_i; p_arg <= cmd_arg_dom_i; p_qtn <= qtn_valid_i; p_qslot <= qtn_slot_i;
    p_state <= slot_state_o; p_id <= slot_id_o; p_wv <= win_valid_o; p_wb <= win_base_o; p_wl <= win_limit_o;
    p_wr <= win_r_o; p_ww <= win_w_o; p_wx <= win_x_o; p_we <= win_excl_o; p_bind <= bind_o; p_lock <= lock_o;
    p_prev_rst <= !rst_n; p_cfg <= cfg_en_i;
  end
  wire p_ok = rst_n && p_valid && rsp_valid_o && (rsp_status_o == sf_citadel_pkg::SF_CIT_CS_OK);          // last cycle's command was accepted
  wire p_unpriv = !(p_priv && (p_dom == sf_albion_pkg::SF_DOM_ROOT || p_dom == sf_albion_pkg::SF_DOM_MGMT));

  // ---- tracked revoked domain ------------------------------------------------------------------------------------------------
  (* anyconst *) logic [SLOT_W-1:0] fv_ts;       // tracked slot
  (* anyconst *) logic [WIN_W-1:0]  fv_tk;       // tracked window
  logic        fv_rev;                            // slot fv_ts was revoked and its domain id has not been re-enrolled
  logic [7:0]  fv_rid;                            // the revoked domain id
  logic        fv_wclr;                           // window (fv_ts, fv_tk) was cleared and not set again
  initial begin fv_rev = 1'b0; fv_wclr = 1'b0; end
  always_ff @(posedge clk) begin
    if (!rst_n) begin
      fv_rev <= 1'b0; fv_wclr <= 1'b0;
    end else begin
      if (p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_REVOKE && p_slot == fv_ts) begin
        fv_rev <= 1'b1; fv_rid <= p_id[fv_ts*8 +: 8];
      end
      if (p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_ENROLL && fv_rev && p_arg == fv_rid) fv_rev <= 1'b0;
      if (p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_CLR_WINDOW && p_slot == fv_ts && p_win == fv_tk) fv_wclr <= 1'b1;
      if (p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_SET_WINDOW && p_slot == fv_ts && p_win == fv_tk) fv_wclr <= 1'b0;
      if (p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_REVOKE && p_slot == fv_ts) fv_wclr <= 1'b0;   // REVOKE clears all windows anyway
    end
  end

  // ---- helper for the exclusive-window invariant -------------------------------------------------------------------------------
  integer i, j, a, b;
  reg excl_ok, unchanged;
  always @* begin
    excl_ok = 1'b1;
    for (i = 0; i < NDOM; i = i + 1) for (j = 0; j < NDOM; j = j + 1) if (i != j)
      for (a = 0; a < NW; a = a + 1) for (b = 0; b < NW; b = b + 1)
        if (win_valid_o[i*NW+a] && win_valid_o[j*NW+b] && (win_excl_o[i*NW+a] || win_excl_o[j*NW+b]) &&
            win_base_o[(i*NW+a)*AW +: AW] <= win_limit_o[(j*NW+b)*AW +: AW] &&
            win_base_o[(j*NW+b)*AW +: AW] <= win_limit_o[(i*NW+a)*AW +: AW])
          excl_ok = 1'b0;
    unchanged = (slot_state_o == p_state) && (slot_id_o == p_id) && (win_valid_o == p_wv) && (win_base_o == p_wb) &&
                (win_limit_o == p_wl) && (win_r_o == p_wr) && (win_w_o == p_ww) && (win_x_o == p_wx) && (win_excl_o == p_we) &&
                (bind_o == p_bind) && (lock_o == p_lock);
  end

  always @* begin
    // ---- stale-use / invalidation ----
    `SF_ASSERT_IMPL(CIT_TBL_REVOKE_INVALIDATES, p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_REVOKE && !p_qtn,
                    slot_state_o[p_slot*2 +: 2] == sf_citadel_pkg::SF_CIT_DS_INVALID &&
                    win_valid_o[p_slot*NW +: NW] == '0 && devrd_o[p_slot] == 1'b0 && devwr_o[p_slot] == 1'b0 &&
                    qmask_o[p_slot*NQ +: NQ] == '0)
    `SF_ASSERT_IMPL(CIT_TBL_STALE_DOMAIN_DENIED, fv_rev && dom_i == fv_rid && !(p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_ENROLL && p_arg == fv_rid), !permit_o)
    `SF_ASSERT_IMPL(CIT_TBL_CLRWIN_INVALIDATES,   p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_CLR_WINDOW && p_slot == fv_ts && p_win == fv_tk,
                    !win_valid_o[fv_ts*NW + fv_tk])
    `SF_ASSERT_IMPL(CIT_TBL_STALE_WINDOW_INVALID, fv_wclr && !(p_ok && p_op == sf_citadel_pkg::SF_CIT_OP_SET_WINDOW && p_slot == fv_ts && p_win == fv_tk),
                    !win_valid_o[fv_ts*NW + fv_tk])
    // ---- default deny / privilege / refused commands ----
    `SF_ASSERT_IMPL(CIT_TBL_RESET_DEFAULT_DENY, p_prev_rst, slot_state_o == '0 && win_valid_o == '0 && bind_o == '0 && !lock_o && !permit_o)
    `SF_ASSERT_IMPL(CIT_TBL_CFG_GATED, rst_n && p_valid && !p_cfg, rsp_valid_o && rsp_status_o == sf_citadel_pkg::SF_CIT_CS_NOT_AUTH)
    `SF_ASSERT_IMPL(CIT_TBL_UNPRIVILEGED_REJECTED, rst_n && p_valid && p_unpriv, rsp_valid_o && rsp_status_o != sf_citadel_pkg::SF_CIT_CS_OK)
    `SF_ASSERT_IMPL(CIT_TBL_REFUSED_NO_CHANGE, rst_n && p_valid && rsp_valid_o && rsp_status_o != sf_citadel_pkg::SF_CIT_CS_OK && !p_qtn, unchanged)
    // ---- isolation by construction (INV-EXCL) ----
    `SF_ASSERT(CIT_TBL_EXCLUSIVE_DISJOINT, excl_ok)
    // ---- covers ----
    `SF_COVER(CIT_TBL_ENROLLED,          |slot_state_o)
    `SF_COVER(CIT_TBL_ACTIVE_PERMIT,     permit_o)
    `SF_COVER(CIT_TBL_REVOKED,           fv_rev)
    `SF_COVER(CIT_TBL_REVOKED_REQUEST_DENIED, fv_rev && dom_i == fv_rid && !permit_o && reason_o == sf_citadel_pkg::SF_CIT_R_BAD_DOM)
    `SF_COVER(CIT_TBL_WINDOW_CLEARED,    fv_wclr)
    `SF_COVER(CIT_TBL_UNPRIV_REFUSED,    p_valid && p_unpriv && rsp_status_o == sf_citadel_pkg::SF_CIT_CS_BAD_PRIV)
    `SF_COVER(CIT_TBL_OVERLAP_REFUSED,   p_valid && rsp_status_o == sf_citadel_pkg::SF_CIT_CS_OVERLAP)
    `SF_COVER(CIT_TBL_EXCLUSIVE_WINDOW,  |win_excl_o)
  end
  always @* begin
    `SF_COVER(CIT_TBL_ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
