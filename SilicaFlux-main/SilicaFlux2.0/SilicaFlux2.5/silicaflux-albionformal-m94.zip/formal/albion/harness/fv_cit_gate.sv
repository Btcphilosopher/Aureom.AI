// =============================================================================
//  fv_cit_gate.sv -- formal harness: sf_citadel_gate + the REAL sf_citadel_permission, fed by a FREE
//  descriptor table (any contents, changing arbitrarily every cycle), plus the independent spec
//  fv_cit_spec. Environment: master/target handshakes, responses, flush, table, safety levels are all
//  free (no assumptions beyond the declared structural ones).
//
//  SNAPSHOT METHOD: at the cycle the gate evaluates a held request for the first time (chk_commit_o,
//  once per request) the harness records what the SPEC says about that request and the request's
//  fields. Whenever the gate presents a request to the target (t_req_valid_o) it must be backed by the
//  snapshot of THAT request: permitted by the spec, and carrying the same domain/op/attr/address.
//  A policy change after the commit does not withdraw a request already evaluated (documented
//  revocation rule); a request evaluated after the change sees the new policy.
// =============================================================================
`include "albion_formal.svh"
module fv_cit_gate #(
  parameter int unsigned NDOM = 2,
  parameter int unsigned NW   = 2,
  parameter int unsigned NP   = 1,
  parameter int unsigned NQ   = 2,
  parameter int unsigned AW   = 64,
  parameter int unsigned OUT_W = 2,
  parameter int WIT = 6
) (
  input  logic                    clk,
  input  logic                    rst_free,
  // gate environment
  input  logic                    m_req_valid_i,
  input  logic [sf_albion_pkg::SF_REQ_W-1:0] m_req_i,
  input  logic                    m_rsp_ready_i,
  input  logic                    t_req_ready_i,
  input  logic                    t_rsp_valid_i,
  input  logic [sf_albion_pkg::SF_RSP_W-1:0] t_rsp_i,
  input  logic                    flush_i,
  // permission environment (free table)
  input  logic                    lockdown_i,
  input  logic                    dft_active_i,
  input  logic [NQ-1:0]           qhold_i,
  input  logic [NP-1:0]           port_isol_i,
  input  logic [NDOM*2-1:0]       slot_state_i,
  input  logic [NDOM*8-1:0]       slot_id_i,
  input  logic [NDOM-1:0]         slot_priv_i,
  input  logic [NDOM-1:0]         slot_secure_i,
  input  logic [NDOM*NW-1:0]      win_valid_i,
  input  logic [NDOM*NW*AW-1:0]   win_base_i,
  input  logic [NDOM*NW*AW-1:0]   win_limit_i,
  input  logic [NDOM*NW-1:0]      win_r_i,
  input  logic [NDOM*NW-1:0]      win_w_i,
  input  logic [NDOM*NW-1:0]      win_x_i,
  input  logic [NDOM-1:0]         devrd_i,
  input  logic [NDOM-1:0]         devwr_i,
  input  logic [NDOM*NQ-1:0]      qmask_i,
  input  logic [NP*NDOM-1:0]      bind_i
);
  localparam int unsigned SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1;
  localparam logic [AW-1:0] DEV_LO = {2'b11, {(AW-2){1'b0}}};
  localparam logic [AW-1:0] DEV_MK = {2'b11, {(AW-2){1'b0}}};

  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(1)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);

  // ---- gate ----
  logic        m_req_ready_o, m_rsp_valid_o, t_req_valid_o, t_rsp_ready_o, chk_valid_o, chk_commit_o, rsp_orphan_o;
  logic [sf_albion_pkg::SF_RSP_W-1:0] m_rsp_o;
  logic [sf_albion_pkg::SF_REQ_W-1:0] t_req_o;
  logic [7:0]  chk_dom_o, chk_attr_o, chk_idx_o;
  logic [3:0]  chk_op_o;
  logic [63:0] chk_addr_o;
  logic [31:0] chk_len_o;
  logic [1:0]  chk_cls_o;
  logic        chk_permit_i;
  logic [3:0]  chk_status_i;
  logic [OUT_W-1:0] outstanding_o;

  sf_citadel_gate #(.OUT_W(OUT_W)) dut (
    .clk_i(clk), .rst_ni(rst_n),
    .m_req_valid_i, .m_req_ready_o, .m_req_i, .m_rsp_valid_o, .m_rsp_ready_i, .m_rsp_o,
    .t_req_valid_o, .t_req_ready_i, .t_req_o, .t_rsp_valid_i, .t_rsp_ready_o, .t_rsp_i,
    .flush_i,
    .chk_valid_o, .chk_dom_o, .chk_op_o, .chk_attr_o, .chk_addr_o, .chk_len_o, .chk_cls_o, .chk_idx_o, .chk_commit_o,
    .chk_permit_i, .chk_status_i, .outstanding_o, .rsp_orphan_o);

  // ---- the real permission checker (src = constant port 0, as in the integration) ----
  logic              slot_vld_o;
  logic [3:0]        reason_o;
  logic [SLOT_W-1:0] slot_o;
  sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(1), .NQ(NQ), .AW(AW), .LEN_W(32),
                          .DEV_BASE(DEV_LO), .DEV_MASK(DEV_MK), .DEV_PRIV(1'b1), .DEV_SECURE(1'b0)) u_perm (
    .src_i('0), .dom_i(chk_dom_o), .op_i(chk_op_o), .attr_i(chk_attr_o), .addr_i(chk_addr_o[AW-1:0]), .len_i(chk_len_o),
    .cls_i(chk_cls_o), .idx_i(chk_idx_o),
    .lockdown_i, .dft_active_i, .qhold_i, .port_isol_i,
    .slot_state_i, .slot_id_i, .slot_priv_i, .slot_secure_i,
    .win_valid_i, .win_base_i, .win_limit_i, .win_r_i, .win_w_i, .win_x_i,
    .devrd_i, .devwr_i, .qmask_i, .bind_i,
    .permit_o(chk_permit_i), .reason_o, .status_o(chk_status_i), .slot_vld_o, .slot_o);

  // ---- independent spec on the same inputs ----
  logic sp_now, spw_now, sp_bound;
  fv_cit_spec #(.NDOM(NDOM), .NW(NW), .NP(NP), .NQ(NQ), .AW(AW), .DEV_PRESENT(1), .DEV_PRIV(1'b1), .DEV_SECURE(1'b0)) u_spec (
    .src_i(8'd0), .dom_i(chk_dom_o), .op_i(chk_op_o), .attr_i(chk_attr_o), .addr_i(chk_addr_o[AW-1:0]), .len_i(chk_len_o),
    .cls_i(chk_cls_o), .idx_i(chk_idx_o), .lockdown_i, .dft_active_i, .qhold_i, .port_isol_i,
    .slot_state_i, .slot_id_i, .slot_priv_i, .slot_secure_i, .win_valid_i, .win_base_i, .win_limit_i, .win_r_i, .win_w_i, .win_x_i,
    .devrd_i, .devwr_i, .qmask_i, .bind_i, .sp_permit(sp_now), .sp_write_ok(spw_now), .sp_bound);

  // the integration uses a 64-bit address bus: with AW < 64 the checker sees only the low bits (declared reduction)
  localparam int XA = (AW < 64) ? (64 - AW) : 1;
  wire addr_fits = (AW >= 64) || (chk_addr_o[63:AW] == '0);

  // ---- snapshot at first evaluation ----
  logic        sn_ok, sn_wok;
  logic [7:0]  sn_dom, sn_attr;
  logic [3:0]  sn_op;
  logic [63:0] sn_addr;
  always_ff @(posedge clk) begin
    if (chk_commit_o) begin
      sn_ok   <= sp_now;
      sn_wok  <= spw_now;
      sn_dom  <= chk_dom_o;
      sn_attr <= chk_attr_o;
      sn_op   <= chk_op_o;
      sn_addr <= chk_addr_o;
    end
  end
  wire        ok_now   = chk_commit_o ? sp_now  : sn_ok;
  wire        wok_now  = chk_commit_o ? spw_now : sn_wok;
  wire [7:0]  dom_now  = chk_commit_o ? chk_dom_o  : sn_dom;
  wire [7:0]  attr_now = chk_commit_o ? chk_attr_o : sn_attr;
  wire [3:0]  op_now   = chk_commit_o ? chk_op_o   : sn_op;
  wire [63:0] addr_now = chk_commit_o ? chk_addr_o : sn_addr;

  wire [7:0]  t_dom  = t_req_o[sf_albion_pkg::SF_REQ_DOM_LSB  +: 8];
  wire [3:0]  t_op   = t_req_o[sf_albion_pkg::SF_REQ_OP_LSB   +: 4];
  wire [7:0]  t_attr = t_req_o[sf_albion_pkg::SF_REQ_ATTR_LSB +: 8];
  wire [63:0] t_addr = t_req_o[sf_albion_pkg::SF_REQ_ADDR_LSB +: 64];

  logic fv_prev_rst;
  initial fv_prev_rst = 1'b0;
  always_ff @(posedge clk) fv_prev_rst <= !rst_n;

  always @* begin
    // the checker only sees AW address bits: restrict the stimulus to addresses it can see when AW < 64
    `SF_ASSUME_COMB(CIT_PARAM_POINT, addr_fits)
    `SF_ASSERT_IMPL(CIT_GATE_NO_BYPASS,          t_req_valid_o, ok_now)
    `SF_ASSERT_IMPL(CIT_GATE_WRITE_NEEDS_RIGHT,  t_req_valid_o && op_now == sf_albion_pkg::SF_OP_WRITE && chk_cls_o == 2'd0, wok_now)
    `SF_ASSERT_IMPL(CIT_GATE_DOMAIN_ASSOCIATION, t_req_valid_o, t_dom == dom_now && t_op == op_now && t_attr == attr_now && t_addr == addr_now)
    `SF_ASSERT_IMPL(CIT_GATE_FLUSH_QUIET,        flush_i, !t_req_valid_o)
    `SF_ASSERT_IMPL(CIT_GATE_COUNTER_NO_OVERFLOW, t_req_valid_o, outstanding_o != {OUT_W{1'b1}})
    `SF_ASSERT_IMPL(CIT_GATE_RESET_STATE,        fv_prev_rst, !t_req_valid_o && !m_rsp_valid_o && outstanding_o == '0 && !chk_valid_o)
    `SF_COVER(CIT_GATE_FORWARDED,                t_req_valid_o && t_req_ready_i)
    `SF_COVER(CIT_GATE_FORWARDED_WRITE,          t_req_valid_o && t_req_ready_i && op_now == sf_albion_pkg::SF_OP_WRITE)
    `SF_COVER(CIT_GATE_DENIED_COMMIT,            chk_commit_o && !sp_now)
    `SF_COVER(CIT_GATE_POLICY_CHANGED_WHILE_HELD, chk_valid_o && !chk_commit_o && (sp_now != sn_ok))
    `SF_COVER(CIT_GATE_FORWARD_AFTER_REVOKE,     t_req_valid_o && !chk_commit_o && sn_ok && !sp_now)
    `SF_COVER(CIT_GATE_DENIED_RESPONSE,          m_rsp_valid_o && chk_valid_o && !chk_permit_i)
    `SF_COVER(CIT_GATE_FLUSH_CANCEL,             flush_i && chk_valid_o)
  end
  always @* begin
    `SF_COVER(CIT_GATE_ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
