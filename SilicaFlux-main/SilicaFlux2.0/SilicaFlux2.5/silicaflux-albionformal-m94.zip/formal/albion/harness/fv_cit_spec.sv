// =============================================================================
//  fv_cit_spec.sv -- independent DECLARATIVE specification of "this request may be permitted"
//  for sf_citadel_permission, written from the rules in the header of sf_citadel_permission.sv and
//  docs/citadel/02_PERMISSION_CHECKER.md (NOT from the RTL's priority chain).
//
//  sp_permit   : necessary conditions for a permit (exists a domain slot that ...). It is deliberately
//                an OVER-approximation of what the RTL permits when two slots share a domain id (the RTL
//                uses the first match; this spec uses "exists"). Therefore  permit_o => sp_permit  is a
//                SAFETY claim: nothing is permitted that the rules do not allow.
//                (The converse direction, completeness, needs unique domain ids: not claimed here.)
//  sp_write_ok : the permit of a WRITE to an ADDRESS RANGE is backed by a write right: a window with W
//                containing the whole range, or a device region wholly containing it with write permission.
// =============================================================================
module fv_cit_spec #(
  parameter int unsigned NDOM = 2,
  parameter int unsigned NW   = 2,
  parameter int unsigned NP   = 1,
  parameter int unsigned NQ   = 2,
  parameter int unsigned AW   = 64,
  parameter int unsigned DEV_PRESENT = 1,        // one device region: [DEV_LO, DEV_HI]
  parameter logic DEV_PRIV   = 1'b1,
  parameter logic DEV_SECURE = 1'b0
) (
  input  logic [7:0]              src_i,         // physical source port index
  input  logic [7:0]              dom_i,
  input  logic [3:0]              op_i,
  input  logic [7:0]              attr_i,
  input  logic [AW-1:0]           addr_i,
  input  logic [31:0]             len_i,
  input  logic [1:0]              cls_i,
  input  logic [7:0]              idx_i,
  input  logic                    lockdown_i,
  input  logic                    dft_active_i,
  input  logic [NQ-1:0]           qhold_i,
  input  logic [NP-1:0]           port_isol_i,
  input  logic [NDOM*2-1:0]       slot_state_i,
  input  logic [NDOM*8-1:0]       slot_id_i,
  input  logic [NDOM-1:0]         slot_priv_i,
  input  logic [NDOM-1:0]         slot_secure_i,
  input  logic [NDOM*NW-1:0]      win_valid_i,
  input  logic [NDOM*NW*AW-1:0]   win_base_i,
  input  logic [NDOM*NW*AW-1:0]   win_limit_i,
  input  logic [NDOM*NW-1:0]      win_r_i,
  input  logic [NDOM*NW-1:0]      win_w_i,
  input  logic [NDOM*NW-1:0]      win_x_i,
  input  logic [NDOM-1:0]         devrd_i,       // NDEV = 1
  input  logic [NDOM-1:0]         devwr_i,
  input  logic [NDOM*NQ-1:0]      qmask_i,
  input  logic [NP*NDOM-1:0]      bind_i,
  output logic                    sp_permit,
  output logic                    sp_write_ok,   // meaningful when op==WRITE && cls==ADDR && sp_permit
  output logic                    sp_bound       // some slot with this id is bound to src
);
  localparam int unsigned SW = ((AW > 32) ? AW : 32) + 2;
  localparam [AW-1:0] DEV_LO = {2'b11, {(AW-2){1'b0}}};
  localparam [AW-1:0] DEV_HI = {AW{1'b1}};          // region = top quarter of the address space

  wire op_rd = (op_i == 4'h1);
  wire op_wr = (op_i == 4'h2);
  wire a_priv = attr_i[2], a_secure = attr_i[3], a_instr = attr_i[4];
  wire attr_ok = !attr_i[7] && (attr_i[1:0] != 2'd3) && !(a_instr && op_wr);

  wire [SW-1:0] a_x    = SW'(addr_i);
  wire [SW-1:0] last_x = a_x + SW'(len_i) - SW'(1);
  wire          nowrap = (len_i != 32'h0) && (last_x[SW-1:AW] == '0);
  wire [AW-1:0] last   = last_x[AW-1:0];

  wire isol = (src_i < NP) && port_isol_i[src_i[3:0] % NP];

  wire dov    = (DEV_PRESENT != 0) && (addr_i <= DEV_HI) && (last >= DEV_LO);
  wire dwhole = (DEV_PRESENT != 0) && (addr_i >= DEV_LO) && (last <= DEV_HI);

  integer s, k;
  reg any, anyw, anyb, ok_s, wok_s, bound_s, win_ok, win_wok;
  always @* begin
    any = 1'b0; anyw = 1'b0; anyb = 1'b0;
    for (s = 0; s < NDOM; s = s + 1) begin
      bound_s = (src_i < NP) && bind_i[(src_i[3:0] % NP) * NDOM + s];
      if (slot_state_i[s*2 +: 2] != 2'd0 && slot_id_i[s*8 +: 8] == dom_i && bound_s) anyb = 1'b1;
      ok_s = 1'b0; wok_s = 1'b0;
      if (slot_state_i[s*2 +: 2] != 2'd0 && slot_id_i[s*8 +: 8] == dom_i && bound_s &&
          slot_state_i[s*2 +: 2] == 2'd2 /* ACTIVE */ &&
          !isol && !dft_active_i && (op_rd || op_wr) && attr_ok && (dom_i != 8'hFF) &&
          !(lockdown_i && dom_i != 8'h00 && dom_i != 8'h01) &&
          (!a_priv || slot_priv_i[s]) && (!a_secure || slot_secure_i[s])) begin
        if (cls_i == 2'd0 /* ADDR */) begin
          if (nowrap) begin
            if (dov) begin
              ok_s  = dwhole && (!DEV_PRIV || a_priv) && (!DEV_SECURE || a_secure) && !a_instr &&
                      (op_rd ? devrd_i[s] : devwr_i[s]);
              wok_s = ok_s && op_wr && devwr_i[s];
            end else begin
              win_ok = 1'b0; win_wok = 1'b0;
              for (k = 0; k < NW; k = k + 1)
                if (win_valid_i[s*NW+k] && addr_i >= win_base_i[(s*NW+k)*AW +: AW] && last <= win_limit_i[(s*NW+k)*AW +: AW] &&
                    (op_rd ? win_r_i[s*NW+k] : win_w_i[s*NW+k]) && (!a_instr || win_x_i[s*NW+k])) begin
                  win_ok = 1'b1;
                  if (op_wr && win_w_i[s*NW+k]) win_wok = 1'b1;
                end
              ok_s = win_ok; wok_s = win_wok;
            end
          end
        end else if (cls_i == 2'd1 /* QUEUE */) begin
          ok_s = (idx_i < NQ) && !qhold_i[idx_i[3:0] % NQ] && qmask_i[s*NQ + (idx_i[3:0] % NQ)];
        end
      end
      if (ok_s)  any  = 1'b1;
      if (wok_s) anyw = 1'b1;
    end
    sp_permit   = any;
    sp_write_ok = anyw;
    sp_bound    = anyb;
  end
endmodule
