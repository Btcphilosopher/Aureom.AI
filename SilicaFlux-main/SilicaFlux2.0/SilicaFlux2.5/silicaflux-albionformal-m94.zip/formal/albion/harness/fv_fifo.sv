// =============================================================================
//  fv_fifo.sv -- formal harness for sf_albion_fifo (occupancy / flags / ordering)
//  Environment: NONE. push, pop and push_data are free every cycle; reset may be asserted
//  at any cycle (sf_fv_ctrl MODE 1). The properties live in bind/fifo_bind.svh.
// =============================================================================
`include "albion_formal.svh"
module fv_fifo #(
  parameter int W     = 8,
  parameter int DEPTH = 4,
  parameter int RSTMODE = 1,
  parameter int WIT   = 10          // depth witness for the environment-satisfiability cover
) (
  input  logic         clk,
  input  logic         rst_free,
  input  logic         push,
  input  logic         pop,
  input  logic [W-1:0] push_data
);
  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(RSTMODE)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);

  localparam int CW = $clog2(DEPTH + 1);
  logic [W-1:0]  head;
  logic [CW-1:0] count;
  logic          full, empty;
  sf_albion_fifo #(.W(W), .DEPTH(DEPTH)) dut (.clk, .rst_n, .push, .push_data, .pop, .head, .count, .full, .empty);

  always @* begin
    // an N-step trace satisfying every assumption exists (no assumptions here, so trivially true;
    // kept in every harness so the check is uniform and survives later additions of assumptions)
    `SF_COVER(ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
