// =============================================================================
//  fv_dma.sv -- formal harness for sf_albion_dma (protected DMA engine, DEPTH-entry prefetch FIFO)
//  Environment: register writes, port ready/response data/response error are FREE. The only
//  assumption is DMA_RSP_OUT (declared) in bind/dma_bind.svh. Reset may be re-asserted at any cycle.
// =============================================================================
`include "albion_formal.svh"
module fv_dma #(
  parameter int DEPTH   = 4,
  parameter int RSTMODE = 1,
  parameter int WIT     = 10
) (
  input  logic        clk,
  input  logic        rst_free,
  input  logic        rg_we,
  input  logic [11:0] rg_off,
  input  logic [31:0] rg_wdata,
  input  logic        rd_req_ready,
  input  logic        rd_rsp_valid,
  input  logic [31:0] rd_rsp_rdata,
  input  logic [2:0]  rd_rsp_err,
  input  logic        wr_req_ready,
  input  logic        wr_rsp_valid,
  input  logic [2:0]  wr_rsp_err
);
  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(RSTMODE)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);

  logic [31:0] rg_rdata, rd_req_addr, wr_req_addr, wr_req_wdata;
  logic [2:0]  rg_err;
  logic        rd_req_valid, wr_req_valid, ev_done_ok_o, ev_done_err_o, ev_bytes_o;
  logic [3:0]  domain_o;

  sf_albion_dma #(.DEPTH(DEPTH)) dut (
    .clk, .rst_n, .rg_we, .rg_off, .rg_wdata, .rg_rdata, .rg_err,
    .rd_req_valid, .rd_req_ready, .rd_req_addr, .rd_rsp_valid, .rd_rsp_rdata, .rd_rsp_err,
    .wr_req_valid, .wr_req_ready, .wr_req_addr, .wr_req_wdata, .wr_rsp_valid, .wr_rsp_err,
    .domain_o, .ev_done_ok_o, .ev_done_err_o, .ev_bytes_o);

  always @* begin
    `SF_COVER(DMA_ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
