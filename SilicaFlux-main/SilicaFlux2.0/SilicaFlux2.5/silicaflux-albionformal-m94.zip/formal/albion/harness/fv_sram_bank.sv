// =============================================================================
//  fv_sram_bank.sv -- formal harness for sf_albion_sram_bank (SECDED SRAM bank, 1 RW macro)
//  Environment: request stream and fault-injection port are free inputs. Data-correctness jobs
//  add assumption SRAM_NO_INJ; the ECC job (FV_ECC) adds SRAM_INJ_WEIGHT instead.
//  Reset may be re-asserted at any cycle (MODE 1) - the scrub must restart and nothing may leak.
// =============================================================================
`include "albion_formal.svh"
module fv_sram_bank #(
  parameter int WORDS   = 8,
  parameter int RSTMODE = 1,
  parameter int WIT     = 14
) (
  input  logic                         clk,
  input  logic                         rst_free,
  input  logic                         req_valid,
  input  logic [$clog2(WORDS)-1:0]     req_word,
  input  logic                         req_we,
  input  logic [31:0]                  req_wdata,
  input  logic [3:0]                   req_wstrb,
  input  logic [1:0]                   req_id,
  input  logic [3:0]                   req_domain,
  input  logic                         inj_arm,
  input  logic [$clog2(WORDS)-1:0]     inj_word,
  input  logic [38:0]                  inj_mask
);
  localparam int AW = $clog2(WORDS);
  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(RSTMODE)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);

  logic          req_ready, rsp_valid, inj_hit_o, ecc_ce_o, ecc_ue_o, init_done_o;
  logic [31:0]   rsp_rdata;
  logic [2:0]    rsp_err;
  logic [1:0]    rsp_id, ecc_master_o;
  logic [6:0]    ecc_syndrome_o;
  logic [AW-1:0] ecc_word_o;
  logic [3:0]    ecc_domain_o;

  sf_albion_sram_bank #(.WORDS(WORDS)) dut (
    .clk, .rst_n, .req_valid, .req_ready, .req_word, .req_we, .req_wdata, .req_wstrb, .req_id, .req_domain,
    .rsp_valid, .rsp_rdata, .rsp_err, .rsp_id, .inj_arm, .inj_word, .inj_mask, .inj_hit_o,
    .ecc_ce_o, .ecc_ue_o, .ecc_syndrome_o, .ecc_word_o, .ecc_master_o, .ecc_domain_o, .init_done_o);

  always @* begin
    `SF_COVER(SRAM_ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
