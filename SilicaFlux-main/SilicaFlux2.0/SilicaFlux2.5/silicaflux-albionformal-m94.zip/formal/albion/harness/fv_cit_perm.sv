// =============================================================================
//  fv_cit_perm.sv -- formal harness for sf_citadel_permission (Citadel hardware permission checker)
//  The checker is combinational. Request fields, the whole descriptor table (domain states, ids,
//  windows, device/queue masks, port bindings) and the device-wide safety levels are FREE inputs:
//  the proofs hold for ANY table contents (assumption CIT_REQ_FIELDS_FREE is implicit).
//  Parameter point (CIT_PARAM_POINT): NDOM=2 NW=2 NP=1 NDEV=1 NQ=2, AW as given, one device region.
// =============================================================================
`include "albion_formal.svh"
module fv_cit_perm #(
  parameter int unsigned NDOM = 2,
  parameter int unsigned NW   = 2,
  parameter int unsigned NP   = 1,
  parameter int unsigned NQ   = 2,
  parameter int unsigned AW   = 64,
  parameter int unsigned DEV_PRESENT = 1,
  parameter logic DEV_PRIV   = 1'b1,
  parameter logic DEV_SECURE = 1'b0,
  parameter int WIT = 2
) (
  input  logic                    clk,
  input  logic                    rst_free,
  input  logic [((NP > 1) ? $clog2(NP) : 1)-1:0] src_i,     // exactly the RTL's port width
  input  logic [7:0]              dom_i,
  input  logic [3:0]              op_i,
  input  logic [7:0]              attr_i,
  input  logic [AW-1:0]           addr_i,
  input  logic [31:0]             len_i,
  input  logic [1:0]              cls_i,
  input  logic [7:0]              idx_i,
  input  logic                    lockdown_i,
  input  logic                    dft_active_i,
  input  logic [NQ-1:0]           qhold_i,
  input  logic [NP-1:0]           port_isol_i,
  input  logic [NDOM*2-1:0]       slot_state_i,
  input  logic [NDOM*8-1:0]       slot_id_i,
  input  logic [NDOM-1:0]         slot_priv_i,
  input  logic [NDOM-1:0]         slot_secure_i,
  input  logic [NDOM*NW-1:0]      win_valid_i,
  input  logic [NDOM*NW*AW-1:0]   win_base_i,
  input  logic [NDOM*NW*AW-1:0]   win_limit_i,
  input  logic [NDOM*NW-1:0]      win_r_i,
  input  logic [NDOM*NW-1:0]      win_w_i,
  input  logic [NDOM*NW-1:0]      win_x_i,
  input  logic [NDOM-1:0]         devrd_i,
  input  logic [NDOM-1:0]         devwr_i,
  input  logic [NDOM*NQ-1:0]      qmask_i,
  input  logic [NP*NDOM-1:0]      bind_i
);
  localparam int unsigned SRC_W  = (NP   > 1) ? $clog2(NP)   : 1;
  localparam int unsigned SLOT_W = (NDOM > 1) ? $clog2(NDOM) : 1;
  localparam logic [AW-1:0] DEV_LO = {2'b11, {(AW-2){1'b0}}};
  localparam logic [AW-1:0] DEV_MK = {2'b11, {(AW-2){1'b0}}};          // region {a : (a & MASK) == BASE} = top quarter
  localparam logic [1*AW-1:0] DEV_BASE_P = (DEV_PRESENT != 0) ? DEV_LO : '0;
  localparam logic [1*AW-1:0] DEV_MASK_P = (DEV_PRESENT != 0) ? DEV_MK : '0;

  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(0)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);

  logic              permit_o, slot_vld_o;
  logic [3:0]        reason_o, status_o;
  logic [SLOT_W-1:0] slot_o;

  sf_citadel_permission #(.NDOM(NDOM), .NW(NW), .NP(NP), .NDEV(1), .NQ(NQ), .AW(AW), .LEN_W(32),
                          .DEV_BASE(DEV_BASE_P), .DEV_MASK(DEV_MASK_P), .DEV_PRIV(DEV_PRIV), .DEV_SECURE(DEV_SECURE)) dut (
    .src_i, .dom_i, .op_i, .attr_i, .addr_i, .len_i, .cls_i, .idx_i,
    .lockdown_i, .dft_active_i, .qhold_i, .port_isol_i,
    .slot_state_i, .slot_id_i, .slot_priv_i, .slot_secure_i,
    .win_valid_i, .win_base_i, .win_limit_i, .win_r_i, .win_w_i, .win_x_i,
    .devrd_i, .devwr_i, .qmask_i, .bind_i,
    .permit_o, .reason_o, .status_o, .slot_vld_o, .slot_o);

  logic sp_permit, sp_write_ok, sp_bound;
  fv_cit_spec #(.NDOM(NDOM), .NW(NW), .NP(NP), .NQ(NQ), .AW(AW), .DEV_PRESENT(DEV_PRESENT), .DEV_PRIV(DEV_PRIV), .DEV_SECURE(DEV_SECURE)) u_spec (
    .src_i(8'(src_i)), .dom_i, .op_i, .attr_i, .addr_i, .len_i, .cls_i, .idx_i, .lockdown_i, .dft_active_i, .qhold_i, .port_isol_i,
    .slot_state_i, .slot_id_i, .slot_priv_i, .slot_secure_i, .win_valid_i, .win_base_i, .win_limit_i, .win_r_i, .win_w_i, .win_x_i,
    .devrd_i, .devwr_i, .qmask_i, .bind_i, .sp_permit, .sp_write_ok, .sp_bound);

  localparam int XW = ((AW > 32) ? AW : 32) + 2;
  wire all_invalid = (slot_state_i == '0);
  wire wr_addr = (op_i == 4'h2) && (cls_i == 2'd0);
  wire [XW-1:0] last_x = XW'(addr_i) + XW'(len_i) - XW'(1);
  wire nowrap = (len_i != 32'h0) && (last_x[XW-1:AW] == '0);
  wire lock_deny = lockdown_i && dom_i != 8'h00 && dom_i != 8'h01;

  always @* begin
    // ---- ledger properties (combinational: valid in every state, so no reset gating) ----
    `SF_ASSERT_COMB(CIT_PERMIT_IMPLIES_SPEC,   !permit_o || sp_permit)
    `SF_ASSERT_COMB(CIT_WRITE_NEEDS_WRITE_RIGHT, !(permit_o && wr_addr) || sp_write_ok)
    `SF_ASSERT_COMB(CIT_PERMIT_STATUS_COUPLING, (permit_o == (status_o == 4'h0)) && (permit_o == (reason_o == 4'h0)))
    `SF_ASSERT_COMB(CIT_SPOOFED_DOMAIN_DENIED,  sp_bound || !permit_o)
    `SF_ASSERT_COMB(CIT_ATTRIBUTION,            !permit_o || (slot_vld_o && slot_id_i[slot_o*8 +: 8] == dom_i &&
                                                              slot_state_i[slot_o*2 +: 2] == 2'd2 && bind_i[(src_i % NP)*NDOM + slot_o]))
    `SF_ASSERT_COMB(CIT_NO_RANGE_WRAP,          !(permit_o && cls_i == 2'd0) || nowrap)
    `SF_ASSERT_COMB(CIT_ISOLATION_AND_LOCKDOWN, !(((src_i < NP) && port_isol_i[src_i % NP]) || dft_active_i || lock_deny) || !permit_o)
    `SF_ASSERT_COMB(CIT_DEFAULT_DENY,           !all_invalid || !permit_o)
    // ---- covers: both verdicts and each decisive path are reachable ----
    `SF_COVER(CIT_PERMIT_READ_WINDOW,  permit_o && op_i == 4'h1 && cls_i == 2'd0 && !(addr_i >= DEV_LO))
    `SF_COVER(CIT_PERMIT_WRITE_WINDOW, permit_o && wr_addr && !(addr_i >= DEV_LO))
    `SF_COVER(CIT_PERMIT_WRITE_DEVICE, permit_o && wr_addr && (DEV_PRESENT != 0) && addr_i >= DEV_LO)
    `SF_COVER(CIT_PERMIT_QUEUE,        permit_o && cls_i == 2'd1)
    `SF_COVER(CIT_DENY_SPOOF,          !permit_o && reason_o == 4'd3 && (|slot_state_i))
    `SF_COVER(CIT_DENY_WRAP,           !permit_o && reason_o == 4'd5)
    `SF_COVER(CIT_DENY_NOMAP,          !permit_o && reason_o == 4'd7)
    `SF_COVER(CIT_DENY_PERM_NO_WRITE,  !permit_o && reason_o == 4'd8 && op_i == 4'h2)
    `SF_COVER(CIT_DENY_DOMSTATE,       !permit_o && reason_o == 4'd6)
  end
endmodule
