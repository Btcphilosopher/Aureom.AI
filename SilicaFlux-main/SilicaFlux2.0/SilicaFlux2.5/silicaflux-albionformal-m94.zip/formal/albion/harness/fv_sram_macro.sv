// fv_sram_macro.sv -- harness for sf_albion_sram_macro (the 1RW memory contract). Free inputs, no assumptions.
`include "albion_formal.svh"
module fv_sram_macro #(parameter int WORDS = 8, parameter int W = 39, parameter int WIT = 8) (
  input  logic                     clk,
  input  logic                     rst_free,
  input  logic                     en,
  input  logic                     we,
  input  logic [$clog2(WORDS)-1:0] addr,
  input  logic [W-1:0]             wdata
);
  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(0)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);
  logic [W-1:0] rdata;
  sf_albion_sram_macro #(.WORDS(WORDS), .W(W)) dut (.clk, .en, .we, .addr, .wdata, .rdata);
  always @* begin
    `SF_COVER(SRAM_MACRO_ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
