// =============================================================================
//  fv_perm.sv -- formal harness for sf_albion_perm (domain window table + violation log)
//  Environment: register port and violation events are FREE inputs. No assumptions.
// =============================================================================
`include "albion_formal.svh"
module fv_perm #(parameter int NW = 8, parameter int RSTMODE = 1, parameter int WIT = 6) (
  input  logic        clk,
  input  logic        rst_free,
  input  logic        rg_we,
  input  logic [11:0] rg_off,
  input  logic [31:0] rg_wdata,
  input  logic        viol_i,
  input  logic [31:0] viol_addr_i,
  input  logic [1:0]  viol_master_i,
  input  logic [3:0]  viol_domain_i,
  input  logic        viol_we_i
);
  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(RSTMODE)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);
  logic [31:0] rg_rdata;
  logic [2:0]  rg_err;
  logic [NW*32-1:0] win_base_o, win_limit_o;
  logic [NW*12-1:0] win_attr_o;
  sf_albion_perm #(.NW(NW)) dut (.clk, .rst_n, .rg_we, .rg_off, .rg_wdata, .rg_rdata, .rg_err,
    .viol_i, .viol_addr_i, .viol_master_i, .viol_domain_i, .viol_we_i, .win_base_o, .win_limit_o, .win_attr_o);
  always @* begin
    `SF_COVER(PERM_ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
