// =============================================================================
//  fabric_bind.svh -- properties for sf_albion_datafabric (inserted INSIDE the module by
//  scripts/albion_formal.py; the RTL file on disk is never modified).
//
//  STRUCTURE
//   1. SPEC MODEL   fv_dec / fv_perm / fv_tgt / fv_elig / fv_err: decode and permission
//                   re-derived from the documented spec (docs/albion/security_model.md,
//                   header of sf_albion_datafabric.sv), not from the RTL's decode logic.
//   2. MONITOR      fv_out / fv_ptgt / fv_perr: one pending-request record per master,
//                   driven only from OBSERVABLE port behaviour (who actually accepted what).
//   3. ENVIRONMENT  S_MASTER_1PO, S_SLAVE_RSP_MATCH (declared in config/assumptions.json).
//   4. PROPERTIES   A_FAB_*  (ledger rows), L_FAB_* (inductive lemmas), C_FAB_* (covers).
//
//  Everything here is prefixed fv_ / FV_ to avoid clashing with RTL identifiers.
// =============================================================================
`include "albion_formal.svh"
  reg bf_live;
  initial bf_live = 1'b0;
  always @(posedge clk) bf_live <= 1'b1;
  wire sf_live = bf_live;

  localparam integer FV_LOCAL     = NS;                      // "answered by the fabric itself"
  localparam integer FV_FWB       = 32'(sf_albion_regs_pkg::FW_PRIVATE_BANKS);
  localparam [32:0]  FV_SRAM_END  = 33'(NB) * 33'(BANK_BYTES);

  // ---------------------------------------------------------------------------------------
  // 1. SPEC MODEL
  // ---------------------------------------------------------------------------------------
  reg  [NM-1:0]   fv_dec, fv_perm, fv_hit, fv_elig, fv_err;
  reg  [NM*4-1:0] fv_tgt;
  integer fm, fw;
  reg [31:0] fa, faw;
  reg        fwe, fsram, fmmio, fhost, fdatab, fhit;
  reg [3:0]  fdom, fpage;
  reg [31:0] fbank;
  always @* begin
    for (fm = 0; fm < NM; fm = fm + 1) begin
      fa    = m_req_addr[fm*32 +: 32];
      faw   = {fa[31:2], 2'b00};
      fwe   = m_req_we[fm];
      fdom  = m_req_domain[fm*4 +: 4];
      fpage = fa[15:12];
      // documented address map: SRAM [0, NB*BANK_BYTES) | MMIO 64 KiB at MMIO_BASE | host memory from HOSTMEM_BASE
      fsram = ({1'b0, fa} < FV_SRAM_END);
      fmmio = (fa >= sf_albion_regs_pkg::MMIO_BASE) && (fa < sf_albion_regs_pkg::MMIO_BASE + 32'h0001_0000);
      fhost = (fa >= sf_albion_regs_pkg::HOSTMEM_BASE);
      fbank = fa / BANK_BYTES;
      fdatab = fsram && (fbank >= FV_FWB);
      // window cover (word-aligned access, 33-bit arithmetic: no wrap)
      fhit = 1'b0;
      for (fw = 0; fw < NW; fw = fw + 1)
        if (win_attr[fw*12] && (win_attr[fw*12+8 +: 4] == fdom) &&
            (fwe ? win_attr[fw*12+2] : win_attr[fw*12+1]) &&
            ({1'b0, faw} >= {1'b0, win_base[fw*32 +: 32]}) &&
            ({1'b0, faw} + 33'd3 <= {1'b0, win_limit[fw*32 +: 32]}))
          fhit = 1'b1;
      fv_hit[fm] = fhit;
      fv_dec[fm] = fsram || fmmio || fhost;
      fv_tgt[fm*4 +: 4] = fsram ? fbank[3:0] : (fmmio ? 4'(NB) : 4'(NB + 1));
      case (fm)
        sf_albion_regs_pkg::M_CORE: fv_perm[fm] = 1'b1;
        sf_albion_regs_pkg::M_HOST: fv_perm[fm] =
            (fmmio && fpage == sf_albion_regs_pkg::PAGE_MGMT) ||
            (fmmio && !fwe && (fpage == sf_albion_regs_pkg::PAGE_TELEM || fpage == sf_albion_regs_pkg::PAGE_RAS)) ||
            (fsram && boot_mode);
        default: fv_perm[fm] =
            (fdom == sf_albion_regs_pkg::DOM_FIRMWARE)   ? fdatab :
            (fdom == sf_albion_regs_pkg::DOM_HOST_ADMIN) ? 1'b0 :
                                                           ((fdatab || fhost) && fhit);
      endcase
      fv_elig[fm] = m_req_valid[fm] && fv_dec[fm] && fv_perm[fm];
      fv_err[fm]  = m_req_valid[fm] && !(fv_dec[fm] && fv_perm[fm]);
    end
  end

  // observed behaviour at the slave side
  integer fs, fk;
  reg [NM*4-1:0] fv_grants;      // per master: number of slaves currently presenting that master's request
  reg [NM*4-1:0] fv_acc;         // per master: number of slave HANDSHAKES (valid && ready) for it
  reg [NM*4-1:0] fv_accs;        // per master: slave index of the (first) handshake, 15 = none
  reg [NM*4-1:0] fv_rspn;        // per master: number of slaves responding to it this cycle
  always @* begin
    for (fk = 0; fk < NM; fk = fk + 1) begin
      fv_grants[fk*4 +: 4] = 4'd0;
      fv_acc[fk*4 +: 4]    = 4'd0;
      fv_accs[fk*4 +: 4]   = 4'hF;
      fv_rspn[fk*4 +: 4]   = 4'd0;
      for (fs = NS - 1; fs >= 0; fs = fs - 1) begin
        if (s_req_valid[fs] && (s_req_id[fs*2 +: 2] == fk[1:0]))
          fv_grants[fk*4 +: 4] = fv_grants[fk*4 +: 4] + 4'd1;
        if (s_req_valid[fs] && s_req_ready[fs] && (s_req_id[fs*2 +: 2] == fk[1:0])) begin
          fv_acc[fk*4 +: 4]  = fv_acc[fk*4 +: 4] + 4'd1;
          fv_accs[fk*4 +: 4] = 4'(fs);
        end
        if (s_rsp_valid[fs] && (s_rsp_id[fs*2 +: 2] == fk[1:0]))
          fv_rspn[fk*4 +: 4] = fv_rspn[fk*4 +: 4] + 4'd1;
      end
    end
  end

  // ---------------------------------------------------------------------------------------
  // 2. MONITOR: one pending-request record per master (observed, not predicted)
  // ---------------------------------------------------------------------------------------
  reg  [NM-1:0]   fv_out;
  reg  [NM*4-1:0] fv_ptgt;
  reg  [NM*3-1:0] fv_perr;
  wire [NM-1:0]   fv_hs = m_req_valid & m_req_ready;
  integer fq;
  always @(posedge clk) begin
    if (!rst_n) begin
      fv_out <= '0;
    end else begin
      for (fq = 0; fq < NM; fq = fq + 1) begin
        if (m_rsp_valid[fq]) fv_out[fq] <= 1'b0;
        if (fv_hs[fq]) begin
          fv_out[fq] <= 1'b1;
          fv_ptgt[fq*4 +: 4] <= fv_err[fq] ? 4'(FV_LOCAL) : fv_accs[fq*4 +: 4];
          fv_perr[fq*3 +: 3] <= fv_dec[fq] ? sf_albion_regs_pkg::FE_PERM : sf_albion_regs_pkg::FE_DECERR;
        end
      end
    end
  end

  // ---------------------------------------------------------------------------------------
  // 3. ENVIRONMENT (every S_ label is declared in config/assumptions.json)
  // ---------------------------------------------------------------------------------------
  reg fv_a_1po, fv_a_rsp;
  integer fe;
  reg [3:0] fid;
  always @* begin
    fv_a_1po = 1'b1;
    fv_a_rsp = 1'b1;
    for (fe = 0; fe < NM; fe = fe + 1)
      // one outstanding request per master: new valid only if idle, or the response arrives now
      if (m_req_valid[fe] && fv_out[fe] && !m_rsp_valid[fe]) fv_a_1po = 1'b0;
    for (fe = 0; fe < NS; fe = fe + 1) begin
      fid = {2'b00, s_rsp_id[fe*2 +: 2]};
      // a slave answers only a request it accepted from that master, once
      if (s_rsp_valid[fe] && !(fv_out[fid] && fv_ptgt[fid*4 +: 4] == 4'(fe))) fv_a_rsp = 1'b0;
    end
  end

  always @* begin
    `SF_ASSUME(MASTER_1PO,      fv_a_1po)
    `SF_ASSUME(SLAVE_RSP_MATCH, fv_a_rsp)
`ifdef FV_ARB
    `SF_ASSUME(SLAVE_READY_ALWAYS, &s_req_ready)
`endif
  end

  // ---------------------------------------------------------------------------------------
  // 4. PROPERTIES
  // ---------------------------------------------------------------------------------------
  integer fx, fj;
  reg p_route, p_denied, p_excl, p_hs, p_noready, p_integrity, p_id, p_dma_mmio, p_dma_fwb, p_dma_dom1, p_dma_dom0host,
      p_dma_win, p_host, p_workc, p_rsp_spur, p_rsp_route, p_rsp_local, p_rsp_one, p_rsp_deliv, p_viol, p_err_ready,
      l_errq, l_errcode, l_ptgt;
  reg [3:0] fg;
  reg [1:0] fgm;
  reg [3:0] fll;           // lowest violating master (spec)
  reg       fany;
  always @* begin
    p_route = 1; p_denied = 1; p_excl = 1; p_hs = 1; p_noready = 1; p_integrity = 1; p_id = 1;
    p_dma_mmio = 1; p_dma_fwb = 1; p_dma_dom1 = 1; p_dma_dom0host = 1; p_dma_win = 1; p_host = 1; p_workc = 1;
    p_rsp_spur = 1; p_rsp_route = 1; p_rsp_local = 1; p_rsp_one = 1; p_rsp_deliv = 1; p_viol = 1; p_err_ready = 1;
    l_errq = 1; l_errcode = 1; l_ptgt = 1;

    // ---- per slave: what is being presented ----
    for (fx = 0; fx < NS; fx = fx + 1) begin
      fgm = s_req_id[fx*2 +: 2];
      if (s_req_valid[fx]) begin
        // routing: only an eligible (decoded + permitted) request, only to ITS slave
        if (!(fv_elig[fgm] && fv_tgt[fgm*4 +: 4] == 4'(fx))) p_route = 0;
        // identifiers valid, request fields travel unchanged with the master id (incl. domain)
        if (!(fgm < NM && m_req_valid[fgm])) p_id = 0;
        if (!(s_req_addr[fx*32 +: 32]  == m_req_addr[fgm*32 +: 32] &&
              s_req_we[fx]             == m_req_we[fgm] &&
              s_req_wdata[fx*32 +: 32] == m_req_wdata[fgm*32 +: 32] &&
              s_req_wstrb[fx*4 +: 4]   == m_req_wstrb[fgm*4 +: 4] &&
              s_req_domain[fx*4 +: 4]  == m_req_domain[fgm*4 +: 4])) p_integrity = 0;
        // named hardware invariants of the security model
        if (fgm == sf_albion_regs_pkg::M_DMARD || fgm == sf_albion_regs_pkg::M_DMAWR) begin
          if (fx == NB) p_dma_mmio = 0;                                           // DMA never reaches MMIO
          if (fx < FV_FWB) p_dma_fwb = 0;                                         // ... nor firmware-private banks
          if (s_req_domain[fx*4 +: 4] == sf_albion_regs_pkg::DOM_HOST_ADMIN) p_dma_dom1 = 0;
          if (fx == NB + 1 && s_req_domain[fx*4 +: 4] == sf_albion_regs_pkg::DOM_FIRMWARE) p_dma_dom0host = 0;
          if (s_req_domain[fx*4 +: 4] >= sf_albion_regs_pkg::DOM_TENANT_MIN && !fv_hit[fgm]) p_dma_win = 0;
        end
        if (fgm == sf_albion_regs_pkg::M_HOST) begin
          if (fx == NB + 1) p_host = 0;                                           // never host memory via the device
          if (fx < NB && !boot_mode) p_host = 0;                                  // SRAM only in boot mode
          if (fx == NB && !(m_req_addr[fgm*32 + 12 +: 4] == sf_albion_regs_pkg::PAGE_MGMT ||
                            (!m_req_we[fgm] && (m_req_addr[fgm*32 + 12 +: 4] == sf_albion_regs_pkg::PAGE_TELEM ||
                                                m_req_addr[fgm*32 + 12 +: 4] == sf_albion_regs_pkg::PAGE_RAS)))) p_host = 0;
        end
      end
      // work conserving: if some eligible master targets slave fx, the slave must see a request
      fany = 1'b0;
      for (fj = 0; fj < NM; fj = fj + 1)
        if (fv_elig[fj] && fv_tgt[fj*4 +: 4] == 4'(fx)) fany = 1'b1;
      if (fany && !s_req_valid[fx]) p_workc = 0;
    end

    // ---- per master ----
    for (fj = 0; fj < NM; fj = fj + 1) begin
      // denied / undecoded requests never reach any slave
      if (m_req_valid[fj] && !(fv_dec[fj] && fv_perm[fj]) && fv_grants[fj*4 +: 4] != 0) p_denied = 0;
      // a request is never presented to two slaves at once (grants never overlap)
      if (fv_grants[fj*4 +: 4] > 1) p_excl = 0;
      // 1:1 handshake: master handshake <=> exactly one slave handshake (or none for local errors)
      if (fv_acc[fj*4 +: 4] != ((m_req_valid[fj] && m_req_ready[fj] && fv_elig[fj]) ? 4'd1 : 4'd0)) p_hs = 0;
      // no handshake without a request; local errors are always accepted
      if (m_req_ready[fj] && !m_req_valid[fj]) p_noready = 0;
      if (fv_err[fj] && !m_req_ready[fj]) p_err_ready = 0;

      // ---- responses ----
      if (m_rsp_valid[fj] && !fv_out[fj]) p_rsp_spur = 0;                          // no response without a request
      if (m_rsp_valid[fj] && fv_out[fj] && fv_ptgt[fj*4 +: 4] != 4'(FV_LOCAL)) begin
        fg = fv_ptgt[fj*4 +: 4];
        if (!(fg < NS && s_rsp_valid[fg] && s_rsp_id[fg*2 +: 2] == fj[1:0] &&
              m_rsp_rdata[fj*32 +: 32] == s_rsp_rdata[fg*32 +: 32] &&
              m_rsp_err[fj*3 +: 3]     == s_rsp_err[fg*3 +: 3])) p_rsp_route = 0;   // data/err come from THE slave addressed
      end
      if (fv_out[fj] && fv_ptgt[fj*4 +: 4] == 4'(FV_LOCAL)) begin
        if (!(m_rsp_valid[fj] && m_rsp_rdata[fj*32 +: 32] == 32'h0 &&
              m_rsp_err[fj*3 +: 3] == fv_perr[fj*3 +: 3])) p_rsp_local = 0;          // local error: next cycle, right code, zero data
      end
      if (m_rsp_valid[fj] && ((fv_out[fj] && fv_ptgt[fj*4 +: 4] == 4'(FV_LOCAL) ? 4'd1 : 4'd0) + fv_rspn[fj*4 +: 4]) != 4'd1)
        p_rsp_one = 0;                                                              // exactly one response source
      // lemmas for induction: DUT-internal local-error state mirrors the monitor
      if (err_q[fj] != (fv_out[fj] && fv_ptgt[fj*4 +: 4] == 4'(FV_LOCAL))) l_errq = 0;
      if (fv_out[fj] && fv_ptgt[fj*4 +: 4] == 4'(FV_LOCAL) && err_code_q[fj*3 +: 3] != fv_perr[fj*3 +: 3]) l_errcode = 0;
      if (fv_out[fj] && !(fv_ptgt[fj*4 +: 4] <= 4'(FV_LOCAL))) l_ptgt = 0;
    end
    // every slave response is delivered to the master named by its id, unchanged
    for (fx = 0; fx < NS; fx = fx + 1)
      if (s_rsp_valid[fx]) begin
        fgm = s_rsp_id[fx*2 +: 2];
        if (!(m_rsp_valid[fgm] && m_rsp_rdata[fgm*32 +: 32] == s_rsp_rdata[fx*32 +: 32] &&
              m_rsp_err[fgm*3 +: 3] == s_rsp_err[fx*3 +: 3])) p_rsp_deliv = 0;
      end

    // ---- violation event: reported for decoded-but-denied requests, lowest master wins ----
    fll = 4'hF;
    for (fj = NM - 1; fj >= 0; fj = fj - 1)
      if (fv_err[fj] && fv_dec[fj]) fll = fj[3:0];
    if (viol_o != (fll != 4'hF)) p_viol = 0;
    if (fll != 4'hF && !(viol_master_o == fll[1:0] && viol_addr_o == m_req_addr[fll[1:0]*32 +: 32] &&
                         viol_domain_o == m_req_domain[fll[1:0]*4 +: 4] && viol_we_o == m_req_we[fll[1:0]])) p_viol = 0;
    if (decerr_o != (|(fv_err & ~fv_dec))) p_viol = 0;
  end

  // ---- ledger properties -------------------------------------------------------------------
  always @* begin
    `SF_ASSERT_COMB(FAB_NO_INVALID_ROUTE,      p_route)
    `SF_ASSERT_COMB(FAB_DENIED_NOT_FORWARDED,  p_denied)
    `SF_ASSERT_COMB(FAB_GRANT_EXCLUSIVE,       p_excl)
    `SF_ASSERT_COMB(FAB_HANDSHAKE_1TO1,        p_hs)
    `SF_ASSERT_COMB(FAB_NO_SPURIOUS_READY,     p_noready)
    `SF_ASSERT_COMB(FAB_LOCAL_ERR_ACCEPTED,    p_err_ready)
    `SF_ASSERT_COMB(FAB_REQ_INTEGRITY,         p_integrity)
    `SF_ASSERT_COMB(FAB_TXN_ID_VALID,          p_id)
    `SF_ASSERT_COMB(FAB_DMA_NO_MMIO,           p_dma_mmio)
    `SF_ASSERT_COMB(FAB_DMA_NO_FW_BANK,        p_dma_fwb)
    `SF_ASSERT_COMB(FAB_DMA_DOM1_DENIED,       p_dma_dom1)
    `SF_ASSERT_COMB(FAB_DMA_DOM0_NO_HOST,      p_dma_dom0host)
    `SF_ASSERT_COMB(FAB_DMA_WINDOW_COVERED,    p_dma_win)
    `SF_ASSERT_COMB(FAB_HOST_POLICY,           p_host)
    `SF_ASSERT_COMB(FAB_ARB_WORK_CONSERVING,   p_workc)
    `SF_ASSERT(FAB_RSP_NO_SPURIOUS,            p_rsp_spur)
    `SF_ASSERT(FAB_RSP_ROUTING,                p_rsp_route)
    `SF_ASSERT(FAB_RSP_LOCAL_ERROR,            p_rsp_local)
    `SF_ASSERT(FAB_RSP_ONE_SOURCE,             p_rsp_one)
    `SF_ASSERT(FAB_RSP_DELIVERED,              p_rsp_deliv)
    `SF_ASSERT_COMB(FAB_VIOL_REPORT,           p_viol)
    `SF_LEMMA(FAB_ERRQ_MIRROR,                 l_errq)
    `SF_LEMMA(FAB_ERRCODE_MIRROR,              l_errcode)
    `SF_LEMMA(FAB_PTGT_RANGE,                  l_ptgt)
  end

  // ---- reset establishes a quiescent fabric --------------------------------------------------
  reg fv_prev_rst;
  initial fv_prev_rst = 1'b0;
  always @(posedge clk) fv_prev_rst <= !rst_n;
  always @* begin
    // the cycle after a reset cycle: no local error pending, so with no slave response nothing is answered
    `SF_ASSERT_IMPL(FAB_RESET_QUIESCENT, fv_prev_rst && !(|s_rsp_valid), !(|m_rsp_valid))
  end

`ifdef FV_ARB
  // ---- bounded arbitration latency (CONDITIONAL on SLAVE_READY_ALWAYS) ---------------------------
  // A continuously eligible request for the same slave is granted within NM cycles. This is a
  // bounded-response SAFETY property; it is NOT an unbounded liveness claim.
  reg [NM*4-1:0] fv_wait;
  reg [NM*4-1:0] fv_ptg;
  integer fz;
  always @(posedge clk) begin
    if (!rst_n) begin
      fv_wait <= '0;
    end else begin
      for (fz = 0; fz < NM; fz = fz + 1) begin
        fv_ptg[fz*4 +: 4] <= fv_tgt[fz*4 +: 4];
        if (fv_elig[fz] && !m_req_ready[fz] && (fv_wait[fz*4 +: 4] == 4'd0 || fv_ptg[fz*4 +: 4] == fv_tgt[fz*4 +: 4]))
          fv_wait[fz*4 +: 4] <= (fv_wait[fz*4 +: 4] == 4'hF) ? 4'hF : fv_wait[fz*4 +: 4] + 4'd1;
        else
          fv_wait[fz*4 +: 4] <= 4'd0;
      end
    end
  end
  reg p_arb;
  always @* begin
    p_arb = 1;
    for (fz = 0; fz < NM; fz = fz + 1)
      if (fv_wait[fz*4 +: 4] > 4'(NM - 1)) p_arb = 0;
    `SF_ASSERT(FAB_ARB_BOUNDED_WAIT, p_arb)
  end
`endif

  // ---- covers: the proofs are not vacuous (the environment allows all of this to happen) ----------
  always @* begin
    `SF_COVER(FAB_FWD_CORE,         m_req_valid[0] && m_req_ready[0] && fv_elig[0])
    `SF_COVER(FAB_FWD_DMARD,        m_req_valid[1] && m_req_ready[1] && fv_elig[1])
    `SF_COVER(FAB_FWD_DMAWR,        m_req_valid[2] && m_req_ready[2] && fv_elig[2])
    `SF_COVER(FAB_FWD_HOST,         m_req_valid[3] && m_req_ready[3] && fv_elig[3])
    `SF_COVER(FAB_DMA_DENIED_PERM,  (fv_err[1] || fv_err[2]) && (fv_dec[1] || fv_dec[2]))
    `SF_COVER(FAB_DECERR,           |(fv_err & ~fv_dec))
    `SF_COVER(FAB_DMA_WINDOW_GRANT, (fv_elig[1] && fv_hit[1] && m_req_domain[7:4] >= 2) || (fv_elig[2] && fv_hit[2] && m_req_domain[11:8] >= 2))
    `SF_COVER(FAB_HOST_BOOT_SRAM,   fv_elig[3] && fv_tgt[15:12] < NB)
    `SF_COVER(FAB_CONTENTION,       (|(fv_elig & ~m_req_ready)) && (|m_req_ready))
    `SF_COVER(FAB_RSP_FROM_SLAVE,   |(m_rsp_valid & fv_out) && (|s_rsp_valid))
    `SF_COVER(FAB_RSP_LOCAL,        |(m_rsp_valid & err_q))
    `SF_COVER(FAB_VIOL_EVENT,       viol_o)
    `SF_COVER(FAB_SLAVE_STALL,      |(s_req_valid & ~s_req_ready))
  end
