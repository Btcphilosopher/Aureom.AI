// =============================================================================
//  sram_macro_bind.svh -- properties for sf_albion_sram_macro (inserted INSIDE the module).
//  Proves the MEMORY CONTRACT that the bank-level proof (sram_bind.svh) assumes as S_MACRO_CONTRACT:
//     "after a read of word tw, rdata equals the codeword most recently written to tw".
//  The lemma over the internal array (`mem`) is what makes this inductive; it is only visible here
//  (Yosys does not support hierarchical references, so it cannot be stated from the bank).
// =============================================================================
`include "albion_formal.svh"
  reg bf_live;
  initial bf_live = 1'b0;
  always @(posedge clk) bf_live <= 1'b1;
  wire sf_live = bf_live;

  (* anyconst *) reg [AW-1:0] fv_mtw;
  reg [W-1:0] fv_mcw;           // spec: last codeword written to the tracked word
  reg         fv_mv;            // ... has been written at least once
  initial fv_mv = 1'b0;
  always @(posedge clk)
    if (en && we && addr == fv_mtw) begin fv_mcw <= wdata; fv_mv <= 1'b1; end

  reg         fv_rdv, fv_rdmv;  // rdata currently holds the value read from the tracked word
  reg [W-1:0] fv_rdcw;
  initial fv_rdv = 1'b0;
  always @(posedge clk)
    if (en && !we) begin fv_rdv <= (addr == fv_mtw); fv_rdmv <= fv_mv; fv_rdcw <= fv_mcw; end

  always @* begin
    `SF_LEMMA(SRAM_MACRO_MEM,        !fv_mv || mem[fv_mtw] == fv_mcw)
    `SF_ASSERT(SRAM_MACRO_CONTRACT,  !(fv_rdv && fv_rdmv) || rdata == fv_rdcw)
    `SF_COVER(SRAM_MACRO_READ_AFTER_WRITE, fv_rdv && fv_rdmv)
    `SF_COVER(SRAM_MACRO_OVERWRITE,  en && we && addr == fv_mtw && fv_mv)
  end
