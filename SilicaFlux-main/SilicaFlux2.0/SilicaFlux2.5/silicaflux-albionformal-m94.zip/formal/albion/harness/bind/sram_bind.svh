// =============================================================================
//  sram_bind.svh -- properties for sf_albion_sram_bank (inserted INSIDE the module).
//
//  METHOD: "tracked word" + assume-guarantee.
//   * fv_tw is a free constant (anyconst) word index; one word is tracked at two levels:
//       - fv_sh / fv_lanes : DATA shadow built from the DOCUMENTED semantics (scrub-on-reset writes 0,
//         full writes replace the word, partial writes replace only the strobed bytes). It is updated at the
//         moment the macro word is written, so codeword and data shadow stay in lock-step.
//       - fv_cw : CODEWORD shadow of what has been written to the macro at that word.
//     Proof for an arbitrary tw is a proof for every word; cost is independent of WORDS.
//   * The macro is abstracted by its CONTRACT (S_MACRO_CONTRACT): "a read returns the last codeword
//     written". The contract is PROVEN on the real macro by job SRAM-MACRO-IND (sram_macro_bind.svh).
//   * SECDED encode/decode is taken from the real modules; the clean round trip dec(enc(x)) = x is
//     either proven inline by the solver or (job SRAM-W8-IND) listed under its own job.
//  WHITE-BOX: write-enable legality is checked on the macro interface (m_en / m_we / m_addr).
//  Every S_ label is declared in config/assumptions.json.
// =============================================================================
`include "albion_formal.svh"
  reg bf_live;
  initial bf_live = 1'b0;
  always @(posedge clk) bf_live <= 1'b1;
  wire sf_live = bf_live;

  (* anyconst *) reg [AW-1:0] fv_tw;

  wire fv_acc    = req_valid && req_ready;
  wire fv_acc_tw = fv_acc && (req_word == fv_tw);
  wire fv_full   = req_we && (req_wstrb == 4'hF);

  // ---- codeword shadow of the macro word (never reset: the macro is not reset) -------------------------
  reg [38:0] fv_cw;
  reg        fv_cwv;
  initial fv_cwv = 1'b0;
  always @(posedge clk)
    if (m_en && m_we && (m_addr == fv_tw)) begin fv_cw <= m_wdata; fv_cwv <= 1'b1; end

  // ---- the last macro READ, if it was of the tracked word ---------------------------------------------------
  reg        fv_rdv, fv_rdmv, fv_rdok;
  reg [38:0] fv_rdcw;
  reg [31:0] fv_rdsh;
  initial fv_rdv = 1'b0;

  // ---- data shadow --------------------------------------------------------------------------------------------
  reg [31:0] fv_sh;
  reg [3:0]  fv_lanes;               // byte lanes written since reset
  reg        fv_p_v;                 // partial write to tw accepted last cycle (commit happens now)
  reg [31:0] fv_p_data;
  reg [3:0]  fv_p_strb;
  integer    fb;
  always @(posedge clk) begin
    fv_p_v    <= rst_n && fv_acc_tw && req_we && !fv_full;
    fv_p_data <= req_wdata;
    fv_p_strb <= req_wstrb;
    if (!bf_live) begin
      fv_rdv  <= 1'b0;                 // step 0 is a pre-reset state: never capture history from it
    end else if (m_en && !m_we) begin
      fv_rdv  <= (m_addr == fv_tw);
      fv_rdmv <= fv_cwv;
      fv_rdok <= init_done || (fv_tw < init_cnt);
      fv_rdcw <= fv_cw;
      fv_rdsh <= fv_sh;
    end
    if (!rst_n) begin
      fv_sh    <= 32'h0;
      fv_lanes <= 4'h0;
    end else begin
      if (fv_acc_tw && fv_full) begin
        fv_sh    <= req_wdata;
        fv_lanes <= 4'hF;
      end
      if (fv_p_v) begin
        for (fb = 0; fb < 4; fb = fb + 1)
          if (fv_p_strb[fb]) fv_sh[fb*8 +: 8] <= fv_p_data[fb*8 +: 8];
        fv_lanes <= fv_lanes | fv_p_strb;
      end
    end
  end

  // ---- what the response one cycle after an accepted READ of tw must be ----------------------------------------
  reg        fv_rd_v;
  reg [31:0] fv_rd_exp;
  reg [3:0]  fv_rd_lanes;
  reg        fv_rq_v;
  reg [1:0]  fv_rq_id;
  reg        fv_rq_we;
  always @(posedge clk) begin
    fv_rd_v     <= rst_n && fv_acc_tw && !req_we;
    fv_rd_exp   <= fv_sh;
    fv_rd_lanes <= fv_lanes;
    fv_rq_v     <= rst_n && fv_acc;
    fv_rq_id    <= req_id;
    fv_rq_we    <= req_we;
  end

  // ---- reset history ----------------------------------------------------------------------------------------------
  reg fv_prev_rst, fv_pdone;
  reg [AW+1:0] fv_rcnt;
  initial begin fv_prev_rst = 1'b0; fv_rcnt = '0; fv_pdone = 1'b0; end
  always @(posedge clk) begin
    fv_prev_rst <= !rst_n;
    fv_pdone    <= init_done;
    if (!rst_n) fv_rcnt <= '0;
    else if (fv_rcnt <= (AW+2)'(WORDS)) fv_rcnt <= fv_rcnt + 1'b1;
  end

  // ---- encoder copy used to state the codeword lemma ---------------------------------------------------------------
  wire [38:0] fv_enc_sh;
  sf_albion_secded_enc u_fv_enc (.data_i(fv_sh), .cw_o(fv_enc_sh));
  wire [38:0] fv_enc_rd;
  sf_albion_secded_enc u_fv_enc_rd (.data_i(fv_rdsh), .cw_o(fv_enc_rd));
  wire fv_ok = init_done || (fv_tw < init_cnt);          // tracked word scrubbed since the last reset

  // ---- environment -------------------------------------------------------------------------------------------------------
  always @* begin
    `SF_ASSUME_COMB(SRAM_NO_INJ, !inj_arm)
    // memory contract, proven for the real macro by job SRAM-MACRO-IND
    `SF_ASSUME(MACRO_CONTRACT, !(fv_rdv && fv_rdmv) || m_rdata == fv_rdcw)
  end

  // ---- derived predicates ---------------------------------------------------------------------------------------------------
  wire [31:0] fv_lane_mask = {{8{fv_rd_lanes[3]}}, {8{fv_rd_lanes[2]}}, {8{fv_rd_lanes[1]}}, {8{fv_rd_lanes[0]}}};
  wire [31:0] fv_sh_mask   = {{8{fv_lanes[3]}}, {8{fv_lanes[2]}}, {8{fv_lanes[1]}}, {8{fv_lanes[0]}}};

  wire fv_we_legal = !(m_en && m_we) || !init_done || (accept && req_we && req_wstrb == 4'hF) || (s1_valid && s1_rmw);
  wire fv_waddr_ok = !(m_en && m_we) ||
                     (!init_done ? (m_addr == init_cnt) :
                      (s1_valid && s1_rmw) ? (m_addr == s1_word) : (m_addr == req_word));
  wire fv_scrub_ok = init_done || (m_en && m_we && !accept && !(s1_valid && s1_rmw));
  wire fv_read_nowe = !(accept && !req_we) || !(m_we);
  wire fv_part_nowe = !(accept && req_we && req_wstrb != 4'hF) || !(m_we);
  wire fv_idle_nowe = !(init_done && !accept && !(s1_valid && s1_rmw)) || !m_en;

  always @* begin
    // ---- ledger properties ----
    `SF_ASSERT_IMPL(SRAM_READ_MATCHES_MODEL,     fv_rd_v, rsp_valid && rsp_err == sf_albion_regs_pkg::FE_OK && rsp_rdata == fv_rd_exp)
    `SF_ASSERT_IMPL(SRAM_UNWRITTEN_BYTES_STABLE, fv_rd_v, (rsp_rdata & ~fv_lane_mask) == 32'h0)
    `SF_ASSERT_IMPL(SRAM_NO_ECC_EVENT_CLEAN,     fv_rd_v || fv_p_v, !ecc_ce_o && !ecc_ue_o)
    `SF_ASSERT(SRAM_WRITE_ENABLE_LEGAL,          fv_we_legal && fv_waddr_ok && fv_read_nowe && fv_part_nowe && fv_idle_nowe)
    `SF_ASSERT(SRAM_SCRUB_WRITES_ONLY,           fv_scrub_ok)
    `SF_ASSERT(SRAM_RSP_MATCH,                   (rsp_valid == fv_rq_v) && (!rsp_valid || (rsp_id == fv_rq_id && (!fv_rq_we || rsp_rdata == 32'h0))))
    `SF_ASSERT(SRAM_NO_ACCEPT_DURING_SCRUB,      !(req_valid && req_ready) || init_done)
    `SF_ASSERT(SRAM_READY_GATING,                req_ready == (init_done && !(s1_valid && s1_rmw)))
    `SF_ASSERT_IMPL(SRAM_RESET_STATE,            fv_prev_rst, !init_done && !req_ready && !rsp_valid && !s1_valid && init_cnt == '0 && !ecc_ce_o && !ecc_ue_o)
    `SF_ASSERT_IMPL(SRAM_SCRUB_BOUNDED,          !fv_prev_rst && fv_rcnt <= (AW+2)'(WORDS), init_done == (fv_rcnt == (AW+2)'(WORDS)))
    // ---- lemmas ----
    `SF_LEMMA(SRAM_SCRUB_COUNTER,                init_done || (init_cnt < WORDS))
    `SF_LEMMA_IMPL(SRAM_RCNT_TRACKS_INIT,        fv_rcnt <= (AW+2)'(WORDS) && !fv_prev_rst, init_done == (fv_rcnt == (AW+2)'(WORDS)))
    `SF_LEMMA_IMPL(SRAM_RCNT_TRACKS_CNT,         !init_done && !fv_prev_rst, init_cnt == fv_rcnt[AW-1:0])
    `SF_LEMMA_IMPL(SRAM_CW_TRACKS_DATA,          fv_ok, fv_cwv && fv_cw == fv_enc_sh)
    `SF_LEMMA(SRAM_PENDING_MIRROR,               (fv_p_v == (s1_valid && s1_rmw && s1_word == fv_tw)) &&
                                                  (!fv_p_v || (s1_wdata == fv_p_data && s1_wstrb == fv_p_strb)))
    `SF_LEMMA(SRAM_SHADOW_LANES,                 (fv_sh & ~fv_sh_mask) == 32'h0)
    `SF_LEMMA_IMPL(SRAM_RDLANES_ZERO,            fv_rd_v, (fv_rd_exp & ~fv_lane_mask) == 32'h0)
    `SF_LEMMA_IMPL(SRAM_RDCW_TRACKS_DATA,        fv_rdv && fv_rdok, fv_rdmv && fv_rdcw == fv_enc_rd)
    // ---- covers ----
    `SF_COVER(SRAM_INIT_DONE,                    init_done)
    `SF_COVER(SRAM_FULL_WRITE_TW,                fv_acc_tw && fv_full)
    `SF_COVER(SRAM_PARTIAL_WRITE_TW,             fv_acc_tw && req_we && req_wstrb != 4'hF && req_wstrb != 4'h0)
    `SF_COVER(SRAM_READ_TW_AFTER_PARTIAL,        fv_rd_v && fv_lanes != 4'h0 && fv_lanes != 4'hF)
    `SF_COVER(SRAM_READ_UNWRITTEN_LANES,         fv_rd_v && fv_lanes == 4'h0)
    `SF_COVER(SRAM_READ_NONZERO_DATA,            fv_rd_v && fv_rd_exp != 32'h0)
    `SF_COVER(SRAM_RMW_COMMIT,                   s1_valid && s1_rmw)
    `SF_COVER(SRAM_RESET_AFTER_INIT,             fv_prev_rst && fv_pdone)
  end
