// =============================================================================
//  fabric_findings_bind.svh -- OBSERVATION covers for sf_albion_datafabric (used ONLY by job
//  FAB-FINDINGS; included AFTER fabric_bind.svh, which defines fv_err / fv_dec / sf_live).
//
//  OBSERVATION F-01: viol_o is a single bit per cycle and viol_* report only the LOWEST-indexed
//  violating master. If two masters present decoded-but-denied requests in the same cycle, the
//  permission-violation counter (sf_albion_perm: viol_count, telemetry TC_PERM_VIOL) increments ONCE
//  and the log keeps one of them. This is a reachable behaviour (cover below), not a defect in the
//  isolation: both requests ARE denied and answered with PERM. It does mean "every denial counted"
//  (security_model.md assurance table) holds per CYCLE, not per REQUEST.
// =============================================================================
  integer ffm;
  reg [3:0] ff_n;
  always @* begin
    ff_n = 4'd0;
    for (ffm = 0; ffm < NM; ffm = ffm + 1)
      if (fv_err[ffm] && fv_dec[ffm]) ff_n = ff_n + 4'd1;
  end
  always @* begin
    `SF_COVER(FAB_MULTI_DENIAL_ONE_EVENT, ff_n >= 4'd2 && viol_o)
    `SF_COVER(FAB_SINGLE_DENIAL_ONE_EVENT, ff_n == 4'd1 && viol_o)
  end
