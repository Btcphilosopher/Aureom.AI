// =============================================================================
//  dma_bind.svh -- properties for sf_albion_dma (inserted INSIDE the module).
//
//  The DMA moves 4-byte beats (no AXI-style bursts). "Burst boundaries" are therefore checked as:
//  every beat lies inside [SRC, SRC+LEN) / [DST, DST+LEN), is word aligned, does not wrap 2^32 and
//  the transfer never exceeds DMA_MAX_LEN. Descriptor = the SRC/DST/LEN/MODE register set latched at START.
//
//  SPEC predicate fv_desc_ok is written from the module header ("Parameter checks (BADPARAM ...)"),
//  independently of the RTL's `badparam` expression.
//  ENVIRONMENT: S_DMA_RSP_OUT only (a response only while a request is outstanding). Register writes,
//  port ready signals, response data and response error codes are fully free.
// =============================================================================
`include "albion_formal.svh"
  reg bf_live;
  initial bf_live = 1'b0;
  always @(posedge clk) bf_live <= 1'b1;
  wire sf_live = bf_live;

  localparam [31:0] FV_MAXLEN = sf_albion_regs_pkg::DMA_MAX_LEN;

  // ---- observed-handshake monitors -------------------------------------------------------------------------------
  reg fv_rd_pend, fv_wr_pend;
  always @(posedge clk) begin
    if (!rst_n) begin
      fv_rd_pend <= 1'b0;
      fv_wr_pend <= 1'b0;
    end else begin
      fv_rd_pend <= (fv_rd_pend && !rd_rsp_valid) || (rd_req_valid && rd_req_ready);
      fv_wr_pend <= (fv_wr_pend && !wr_rsp_valid) || (wr_req_valid && wr_req_ready);
    end
  end

  // ---- previous-cycle copies (descriptor stability) --------------------------------------------------------------------
  reg [31:0] fv_q_src, fv_q_dst, fv_q_len;
  reg        fv_q_fill, fv_q_busy, fv_q_sb, fv_q_ok, fv_q_err, fv_prev_rst;
  initial begin fv_q_busy = 1'b0; fv_q_sb = 1'b0; fv_q_ok = 1'b0; fv_q_err = 1'b0; fv_prev_rst = 1'b0; end
  always @(posedge clk) begin
    fv_q_src <= r_src; fv_q_dst <= r_dst; fv_q_len <= r_len; fv_q_fill <= r_mode_fill;
    fv_q_busy   <= busy && rst_n;
    fv_q_sb     <= start && badparam && rst_n;
    fv_q_ok     <= ev_done_ok_o && rst_n;
    fv_q_err    <= ev_done_err_o && !(start && badparam) && rst_n;
    fv_prev_rst <= !rst_n;
  end

  // ---- SPEC: descriptor validity (documented BADPARAM rules) -----------------------------------------------------------
  function fv_desc_ok(input [31:0] src, input [31:0] dst, input [31:0] len, input fill);
    reg [32:0] se, de;
    begin
      se = {1'b0, src} + {1'b0, len};
      de = {1'b0, dst} + {1'b0, len};
      fv_desc_ok = (len != 32'h0) && (len % 4 == 0) && (len <= FV_MAXLEN) &&
                   (dst % 4 == 0) && !de[32] &&
                   (fill || ((src % 4 == 0) && !se[32]));
    end
  endfunction

  wire fv_regs_ok = fv_desc_ok(r_src, r_dst, r_len, r_mode_fill);
  wire [31:0] fv_bytes4 = {nwords[29:0], 2'b00};

  // ---- ENVIRONMENT ---------------------------------------------------------------------------------------------------------
  always @* begin
    `SF_ASSUME(DMA_RSP_OUT, (!rd_rsp_valid || fv_rd_pend) && (!wr_rsp_valid || fv_wr_pend))
  end

  // ---- LEMMAS (inductive strengthening; proven jointly) -----------------------------------------------------------------------
  always @* begin
    `SF_LEMMA_IMPL(DMA_DESC_LATCHED,   busy, fv_regs_ok && nwords == {2'b00, r_len[31:2]})
    `SF_LEMMA(DMA_NWORDS_BOUND,        nwords <= (FV_MAXLEN >> 2))
    `SF_LEMMA_IMPL(DMA_IDX_ORDER,      busy, rd_idx <= nwords && wr_idx <= nwords && rd_rsp_idx <= rd_idx && wr_rsp_idx <= wr_idx)
    `SF_LEMMA_IMPL(DMA_RD_OUT_COUNT,   busy, rd_idx == rd_rsp_idx + {31'd0, rd_out})
    `SF_LEMMA_IMPL(DMA_WR_OUT_COUNT,   busy, wr_idx == wr_rsp_idx + {31'd0, wr_out} + {31'd0, stop_wr})
    `SF_LEMMA(DMA_BYTES_EQ_WR_IDX,     !busy || r_bytes == {wr_rsp_idx[29:0], 2'b00})
    `SF_LEMMA(DMA_BYTES_LE_NWORDS,     r_bytes <= fv_bytes4)
    `SF_LEMMA(DMA_IDLE_NO_OUT,          busy || (!rd_out && !wr_out))
    `SF_LEMMA(DMA_OUT_MIRROR,          (fv_rd_pend == rd_out) && (fv_wr_pend == wr_out))
    `SF_LEMMA_IMPL(DMA_COPY_ORDER,     busy && !r_mode_fill, wr_idx <= rd_rsp_idx)
    `SF_LEMMA(DMA_FIFO_ROOM,           (32'(f_count) + 32'(rd_out)) <= DEPTH)
  end

  // ---- LEDGER PROPERTIES --------------------------------------------------------------------------------------------------------
  wire [32:0] fv_wend = {1'b0, wr_req_addr} + 33'd3;
  wire [32:0] fv_rend = {1'b0, rd_req_addr} + 33'd3;
  wire [32:0] fv_dlim = {1'b0, r_dst} + {1'b0, r_len};
  wire [32:0] fv_slim = {1'b0, r_src} + {1'b0, r_len};
  always @* begin
    // descriptor / validation
    `SF_ASSERT_COMB(DMA_VALIDATION_EXACT,   !start || (badparam == !fv_desc_ok(r_src, r_dst, r_len, rg_wdata[1])))
    `SF_ASSERT_IMPL(DMA_DESCRIPTOR_LIMITS,  busy, fv_regs_ok)
    `SF_ASSERT_IMPL(DMA_BUSY_WRITE_REJECTED, busy && rg_we && rg_off != sf_albion_regs_pkg::DMA_CTRL, rg_err != sf_albion_regs_pkg::FE_OK)
    `SF_ASSERT_IMPL(DMA_DESCRIPTOR_FROZEN,  fv_q_busy && busy, r_src == fv_q_src && r_dst == fv_q_dst && r_len == fv_q_len && r_mode_fill == fv_q_fill)
    `SF_ASSERT_IMPL(DMA_BADPARAM_REJECTED,  fv_q_sb, !busy && done && error && r_err_code == sf_albion_regs_pkg::DMAE_BADPARAM && r_bytes == 32'h0)
    // counters
    `SF_ASSERT_IMPL(DMA_COUNTERS_VALID,     busy, rd_idx <= nwords && wr_idx <= nwords && wr_rsp_idx <= nwords && r_bytes == {wr_rsp_idx[29:0], 2'b00})
    `SF_ASSERT(DMA_BYTES_BOUND,             r_bytes <= FV_MAXLEN && r_bytes[1:0] == 2'b00)
    // beats stay inside the programmed ranges
    `SF_ASSERT_IMPL(DMA_WR_BEAT_BOUNDS,     wr_req_valid, wr_req_addr >= r_dst && fv_wend <= fv_dlim && wr_req_addr[1:0] == 2'b00 && wr_idx < nwords)
    `SF_ASSERT_IMPL(DMA_RD_BEAT_BOUNDS,     rd_req_valid, !r_mode_fill && rd_req_addr >= r_src && fv_rend <= fv_slim && rd_req_addr[1:0] == 2'b00 && rd_idx < nwords)
    `SF_ASSERT(DMA_NO_TRAFFIC_WHEN_IDLE,    busy || (!rd_req_valid && !wr_req_valid))
    `SF_ASSERT(DMA_FIRST_FAIL_STOPS,        (!stop_wr || !wr_req_valid) && (!stop_rd || !rd_req_valid))
    `SF_ASSERT(DMA_PORT_1PO,                !(rd_req_valid && fv_rd_pend && !rd_rsp_valid) && !(wr_req_valid && fv_wr_pend && !wr_rsp_valid))
    // accounting
    `SF_ASSERT_IMPL(DMA_ACCOUNTING_OK,      fv_q_ok, done && !error && !busy && r_bytes == fv_bytes4 && wr_rsp_idx == nwords)
    `SF_ASSERT_IMPL(DMA_ACCOUNTING_ERR,     fv_q_err, done && error && !busy && r_err_code != sf_albion_regs_pkg::DMAE_NONE && r_bytes < fv_bytes4 + 32'd4 && r_bytes == {err_idx[29:0], 2'b00})
    `SF_ASSERT(DMA_STATUS_CONSISTENT,  !(busy && done) && (!error || done) && !(ev_done_ok_o && ev_done_err_o))
    // FIFO inside the DMA
    `SF_ASSERT(DMA_FIFO_BOUNDS,             (32'(f_count) <= DEPTH) && ((32'(f_count) + 32'(rd_out)) <= DEPTH))
    // reset
    `SF_ASSERT_IMPL(DMA_RESET_STATE,        fv_prev_rst, !busy && !done && !error && r_bytes == 32'h0 && r_cycles == 32'h0 &&
                                                          r_err_code == sf_albion_regs_pkg::DMAE_NONE && !rd_req_valid && !wr_req_valid)
    // ---- covers ----
    `SF_COVER(DMA_COPY_STARTED,             start && !badparam && !rg_wdata[1])
    `SF_COVER(DMA_FILL_STARTED,             start && !badparam && rg_wdata[1])
    `SF_COVER(DMA_BADPARAM,                 start && badparam)
    `SF_COVER(DMA_DONE_OK,                  ev_done_ok_o)
    `SF_COVER(DMA_DONE_OK_COPY,             ev_done_ok_o && !r_mode_fill)
    `SF_COVER(DMA_READ_ERROR,               busy && rd_rsp_valid && rd_rsp_err != sf_albion_regs_pkg::FE_OK)
    `SF_COVER(DMA_WRITE_ERROR,              busy && wr_rsp_valid && wr_rsp_err != sf_albion_regs_pkg::FE_OK)
    `SF_COVER(DMA_DONE_ERR,                 ev_done_err_o && !(start && badparam))
    `SF_COVER(DMA_BEAT_WRITTEN,             wr_req_valid && wr_req_ready)
    `SF_COVER(DMA_FIFO_FULL,                f_count == DEPTH)
    `SF_COVER(DMA_MULTI_BEAT,               busy && nwords >= 3 && wr_idx >= 2)
    `SF_COVER(DMA_REG_WRITE_REJECTED_BUSY,  busy && rg_we && rg_err != sf_albion_regs_pkg::FE_OK && rg_off != sf_albion_regs_pkg::DMA_CTRL)
  end
