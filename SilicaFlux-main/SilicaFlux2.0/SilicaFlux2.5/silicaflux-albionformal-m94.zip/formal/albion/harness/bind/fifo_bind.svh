// =============================================================================
//  fifo_bind.svh -- white-box properties for sf_albion_fifo (inserted INSIDE the module
//  by scripts/albion_formal.py, "bind emulation"; the RTL file on disk is never modified).
//
//  SPEC MODEL: an independent behavioural queue (shift-register FIFO) with the documented
//  semantics of the FIFO header: "push is ignored when full, pop is ignored when empty".
//  The DUT's pointer/memory implementation is then checked to REFINE this model.
// =============================================================================
`include "albion_formal.svh"
  reg bf_live;
  initial bf_live = 1'b0;
  always @(posedge clk) bf_live <= 1'b1;
  wire sf_live = bf_live;

  // ---- reference queue -----------------------------------------------------------------
  reg [W-1:0]  rq [0:DEPTH-1];
  reg [CW-1:0] rn;
  initial rn = '0;
  wire r_push = push && (rn != CW'(DEPTH));
  wire r_pop  = pop  && (rn != '0);
  integer rk;
  always @(posedge clk) begin
    if (!rst_n) begin
      rn <= '0;
    end else begin
      if (r_pop)
        for (rk = 0; rk < DEPTH - 1; rk = rk + 1) rq[rk] <= rq[rk+1];
      if (r_push)
        rq[rn - (r_pop ? 1 : 0)] <= push_data;      // later assignment wins over the shift
      rn <= rn + CW'(r_push) - CW'(r_pop);
    end
  end

  // ---- helper (lemma) invariants: proven jointly, never assumed ---------------------------
  integer fi;
  reg ok_mem;
  always @* begin
    ok_mem = 1'b1;
    for (fi = 0; fi < DEPTH; fi = fi + 1)
      if (fi < count && mem[(rp + fi) % DEPTH] != rq[fi]) ok_mem = 1'b0;
  end

  always @* begin
    // ---- claimed properties (ledger rows) ----
    `SF_ASSERT(FIFO_COUNT_BOUND,  count <= CW'(DEPTH))
    `SF_ASSERT(FIFO_FLAGS,        (full == (count == CW'(DEPTH))) && (empty == (count == '0)) && !(full && empty))
    `SF_ASSERT(FIFO_COUNT_MODEL,  count == rn)
    `SF_ASSERT_IMPL(FIFO_ORDER,   !empty, head == rq[0])
    // ---- lemmas ----
    `SF_LEMMA(FIFO_PTR_RANGE,     (rp < DEPTH) && (wp < DEPTH))
    `SF_LEMMA(FIFO_PTR_COUNT,     ((rp + count) % DEPTH) == wp)
    `SF_LEMMA(FIFO_MEM_MODEL,     ok_mem)
    // ---- reachability witnesses (vacuity / non-triviality) ----
    `SF_COVER(FIFO_REACH_FULL,    full)
    `SF_COVER(FIFO_REACH_PUSH_FULL_DROP, push && full && !pop)
    `SF_COVER(FIFO_REACH_POP_EMPTY_DROP, pop && empty)
    `SF_COVER(FIFO_REACH_SIMUL,   do_push && do_pop && !empty && !full)
    `SF_COVER(FIFO_REACH_WRAP,    do_push && wp == PW'(DEPTH - 1))
  end
