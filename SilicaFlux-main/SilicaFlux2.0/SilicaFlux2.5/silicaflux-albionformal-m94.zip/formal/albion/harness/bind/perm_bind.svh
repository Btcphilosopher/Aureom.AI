// =============================================================================
//  perm_bind.svh -- properties for sf_albion_perm (window table + violation log register file).
//  "Tracked window" method: fv_tw is a free constant window index; base/limit/attr of that window and
//  the violation counter/log are mirrored by a SPEC model derived from docs/albion/register_map.md
//  (window regs: base @+0, limit @+4, attr @+8; attr = {domain[11:8], W[2], R[1], VALID[0]}, other bits
//  RAZ/WI; violation count saturates; first violation is latched until cleared).
//  The checking logic itself lives in the DataFabric (job FAB-*); this job covers the TABLE that
//  logic reads: default-deny after reset, no unintended mutation, exact write/readback.
// =============================================================================
`include "albion_formal.svh"
  reg bf_live;
  initial bf_live = 1'b0;
  always @(posedge clk) bf_live <= 1'b1;
  wire sf_live = bf_live;

  (* anyconst *) reg [$clog2(NW)-1:0] fv_tw;
  wire [11:0] fv_off_b = 12'h100 + {fv_tw, 4'h0};
  wire [11:0] fv_off_l = 12'h104 + {fv_tw, 4'h0};
  wire [11:0] fv_off_a = 12'h108 + {fv_tw, 4'h0};

  reg [31:0] fv_base, fv_limit;
  reg [11:0] fv_attr;
  reg        fv_prev_rst;
  initial fv_prev_rst = 1'b0;
  // previous-cycle copies of the whole table (to prove "no unintended mutation")
  reg [NW*32-1:0] fv_pb, fv_pl;
  reg [NW*12-1:0] fv_pa;
  reg        fv_pwe_bad;                // previous cycle: a write that the register file must NOT have accepted
  reg        fv_pv;
  reg [31:0] fv_cnt;
  reg [31:0] fv_laddr;
  reg [31:0] fv_linfo;
  always @(posedge clk) begin
    fv_prev_rst <= !rst_n;
    fv_pb <= win_base_o; fv_pl <= win_limit_o; fv_pa <= win_attr_o;
    fv_pwe_bad <= rst_n && rg_we && (rg_err != sf_albion_regs_pkg::FE_OK);
    fv_pv <= rst_n;
    if (!rst_n) begin
      fv_base <= 32'h0; fv_limit <= 32'h0; fv_attr <= 12'h0;
      fv_cnt <= 32'h0; fv_laddr <= 32'h0; fv_linfo <= 32'h0;
    end else begin
      if (rg_we && rg_off == fv_off_b) fv_base  <= rg_wdata;
      if (rg_we && rg_off == fv_off_l) fv_limit <= rg_wdata;
      if (rg_we && rg_off == fv_off_a) fv_attr  <= {rg_wdata[11:8], 5'h0, rg_wdata[2:0]};
      // violation log spec
      if (rg_we && rg_off == sf_albion_regs_pkg::PERM_VIOL_CLEAR && rg_wdata[0]) fv_linfo[31] <= 1'b0;
      if (viol_i) begin
        if (fv_cnt != 32'hFFFF_FFFF) fv_cnt <= fv_cnt + 32'd1;
        if (!fv_linfo[31]) begin
          fv_laddr <= viol_addr_i;
          fv_linfo <= {1'b1, 22'h0, viol_we_i, 2'h0, viol_master_i, viol_domain_i};
        end
      end
    end
  end

  integer fw;
  reg fv_stable;
  always @* begin
    fv_stable = 1'b1;
    for (fw = 0; fw < NW; fw = fw + 1)
      if (win_base_o[fw*32 +: 32] != fv_pb[fw*32 +: 32] || win_limit_o[fw*32 +: 32] != fv_pl[fw*32 +: 32] ||
          win_attr_o[fw*12 +: 12] != fv_pa[fw*12 +: 12]) fv_stable = 1'b0;
  end
  reg fv_attr_clean;
  always @* begin
    fv_attr_clean = 1'b1;
    for (fw = 0; fw < NW; fw = fw + 1)
      if (win_attr_o[fw*12 +: 8] > 8'h07 || win_attr_o[fw*12 +: 8] != {5'h0, win_attr_o[fw*12 +: 3]}) fv_attr_clean = 1'b0;
  end
  wire fv_viol_rd = !rg_we && rg_off == sf_albion_regs_pkg::PERM_VIOL_COUNT;

  always @* begin
    `SF_ASSERT_IMPL(PERM_RESET_DEFAULT_DENY,  fv_prev_rst, win_attr_o == '0 && win_base_o == '0 && win_limit_o == '0 && fv_cnt == 32'h0)
    `SF_ASSERT(PERM_ATTR_RESERVED_ZERO,       fv_attr_clean)
    `SF_ASSERT(PERM_WINDOW_MATCHES_SPEC,      win_base_o[fv_tw*32 +: 32] == fv_base && win_limit_o[fv_tw*32 +: 32] == fv_limit &&
                                              win_attr_o[fv_tw*12 +: 12] == fv_attr)
    `SF_ASSERT_IMPL(PERM_READBACK_BASE,       rg_off == fv_off_b, rg_rdata == fv_base && rg_err == sf_albion_regs_pkg::FE_OK)
    `SF_ASSERT_IMPL(PERM_READBACK_LIMIT,      rg_off == fv_off_l, rg_rdata == fv_limit && rg_err == sf_albion_regs_pkg::FE_OK)
    `SF_ASSERT_IMPL(PERM_READBACK_ATTR,       rg_off == fv_off_a, rg_rdata == {20'h0, fv_attr} && rg_err == sf_albion_regs_pkg::FE_OK)
    `SF_ASSERT_IMPL(PERM_ERROR_WRITE_NO_EFFECT, fv_pwe_bad && fv_pv, fv_stable)
    `SF_ASSERT_IMPL(PERM_RO_REGS_REJECT_WRITE, rg_we && !(rg_off >= 12'h100 && rg_off < 12'h100 + 12'(NW*16)) && rg_off != sf_albion_regs_pkg::PERM_VIOL_CLEAR,
                                              rg_err != sf_albion_regs_pkg::FE_OK)
    `SF_ASSERT(PERM_VIOL_COUNT_MATCHES_SPEC,  viol_count == fv_cnt)
    `SF_ASSERT(PERM_VIOL_LOG_MATCHES_SPEC,    viol_addr == fv_laddr && viol_info == fv_linfo)
    `SF_ASSERT_IMPL(PERM_VIOL_FIRST_STICKY,   fv_linfo[31] && viol_info[31], viol_addr == fv_laddr)
    // covers
    `SF_COVER(PERM_WINDOW_WRITTEN,            rg_we && rg_off == fv_off_a && rg_wdata[0] && rg_err == sf_albion_regs_pkg::FE_OK)
    `SF_COVER(PERM_WINDOW_VALID,              win_attr_o[fv_tw*12] == 1'b1)
    `SF_COVER(PERM_VIOL_LOGGED,               viol_info[31])
    `SF_COVER(PERM_VIOL_CLEARED,              fv_linfo[31] && rg_we && rg_off == sf_albion_regs_pkg::PERM_VIOL_CLEAR && rg_wdata[0])
    `SF_COVER(PERM_VIOL_COUNT_NONZERO,        viol_count != 32'h0)
    `SF_COVER(PERM_RO_WRITE_REJECTED,         rg_we && rg_off == sf_albion_regs_pkg::PERM_VIOL_COUNT && rg_err == sf_albion_regs_pkg::FE_SLVERR)
  end
