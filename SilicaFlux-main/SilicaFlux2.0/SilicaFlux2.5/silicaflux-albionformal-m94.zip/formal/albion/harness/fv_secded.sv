// =============================================================================
//  fv_secded.sv -- exhaustive (all 2^32 data words) check of the (39,32) SECDED code.
//  CHECK = 0  clean round trip:      dec(enc(d)) = d, no CE, no UE
//  CHECK = 1  every SINGLE bit flip: data corrected, CE set, UE clear           (39 patterns)
//  CHECK = 2  every DOUBLE bit flip: UE set, CE clear                            (741 patterns)
//  `bad` is 1 iff some pattern violates the specification. The job proves `bad` is the constant 0
//  with ABC (BDD / rewriting based `iprove`): parity-heavy logic defeats plain CDCL SAT, and
//  the property is combinational so the answer is exhaustive, not bounded.
//  Specification source: header of sf_albion_secded.sv ("all single flips corrected, all double flips detected").
// =============================================================================
module fv_secded #(parameter int CHECK = 1) (
  input  logic [31:0] d,
  output logic        bad
);
  logic [38:0] cw;
  sf_albion_secded_enc enc (.data_i(d), .cw_o(cw));
  localparam int NS1 = 39;
  localparam int ND2 = 741;

  function automatic logic [38:0] dpattern(input integer k);   // k-th unordered pair (i<j)
    integer n;
    dpattern = '0;
    n = 0;
    for (integer i = 0; i < 39; i = i + 1)
      for (integer j = i + 1; j < 39; j = j + 1) begin
        if (n == k) begin dpattern[i] = 1'b1; dpattern[j] = 1'b1; end
        n = n + 1;
      end
  endfunction

  generate
    if (CHECK == 0) begin : g_clean
      logic [31:0] q; logic ce, ue; logic [6:0] syn;
      sf_albion_secded_dec dec (.cw_i(cw), .data_o(q), .ce_o(ce), .ue_o(ue), .syndrome_o(syn));
      assign bad = (q != d) || ce || ue;
    end else if (CHECK == 1) begin : g_single
      logic [NS1-1:0] v;
      for (genvar k = 0; k < NS1; k++) begin : g_p
        logic [31:0] q; logic ce, ue; logic [6:0] syn;
        localparam logic [38:0] E = 39'd1 << k;
        sf_albion_secded_dec dec (.cw_i(cw ^ E), .data_o(q), .ce_o(ce), .ue_o(ue), .syndrome_o(syn));
        assign v[k] = (q != d) || !ce || ue;
      end
      assign bad = |v;
    end else begin : g_double
      logic [ND2-1:0] v;
      for (genvar k = 0; k < ND2; k++) begin : g_p
        logic [31:0] q; logic ce, ue; logic [6:0] syn;
        localparam logic [38:0] E = dpattern(k);
        sf_albion_secded_dec dec (.cw_i(cw ^ E), .data_o(q), .ce_o(ce), .ue_o(ue), .syndrome_o(syn));
        assign v[k] = !ue || ce;
      end
      assign bad = |v;
    end
  endgenerate
endmodule
