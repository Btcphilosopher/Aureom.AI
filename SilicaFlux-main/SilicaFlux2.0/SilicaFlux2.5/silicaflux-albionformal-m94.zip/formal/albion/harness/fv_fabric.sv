// =============================================================================
//  fv_fabric.sv -- formal harness for sf_albion_datafabric (DataFabric correctness)
//  ENVIRONMENT: master requests, window table, boot_mode, slave ready/response are FREE inputs
//  every cycle; the only constraints are the two declared protocol assumptions
//  (MASTER_1PO, SLAVE_RSP_MATCH) written in bind/fabric_bind.svh. Reset may be re-asserted at
//  any cycle (sf_fv_ctrl MODE 1).
// =============================================================================
`include "albion_formal.svh"
module fv_fabric #(
  parameter int NB         = 4,
  parameter int BANK_BYTES = 16384,
  parameter int NW         = 8,
  parameter int RSTMODE    = 1,
  parameter int WIT        = 8
) (
  input  logic                    clk,
  input  logic                    rst_free,
  input  logic [3:0]              m_req_valid,
  input  logic [4*32-1:0]         m_req_addr,
  input  logic [3:0]              m_req_we,
  input  logic [4*32-1:0]         m_req_wdata,
  input  logic [4*4-1:0]          m_req_wstrb,
  input  logic [4*4-1:0]          m_req_domain,
  input  logic [NW*32-1:0]        win_base,
  input  logic [NW*32-1:0]        win_limit,
  input  logic [NW*12-1:0]        win_attr,
  input  logic                    boot_mode,
  input  logic [NB+1:0]           s_req_ready,
  input  logic [NB+1:0]           s_rsp_valid,
  input  logic [(NB+2)*32-1:0]    s_rsp_rdata,
  input  logic [(NB+2)*3-1:0]     s_rsp_err,
  input  logic [(NB+2)*2-1:0]     s_rsp_id
);
  localparam int NS = NB + 2;
  logic rst_n, sf_live, sf_first;
  logic [7:0] sf_step;
  sf_fv_ctrl #(.MODE(RSTMODE)) u_ctrl (.clk, .rst_free, .rst_n, .sf_live, .sf_first, .sf_step);

  logic [3:0]        m_req_ready, m_rsp_valid;
  logic [4*32-1:0]   m_rsp_rdata;
  logic [4*3-1:0]    m_rsp_err;
  logic [NS-1:0]     s_req_valid, s_req_we;
  logic [NS*32-1:0]  s_req_addr, s_req_wdata;
  logic [NS*4-1:0]   s_req_wstrb, s_req_domain;
  logic [NS*2-1:0]   s_req_id;
  logic              viol_o, viol_we_o, decerr_o, ev_bank_conflict_o;
  logic [31:0]       viol_addr_o;
  logic [1:0]        viol_master_o;
  logic [3:0]        viol_domain_o;
  logic [3:0]        ev_m_txn_o, ev_m_stall_o;
  logic [NS-1:0]     ev_s_txn_o;

  sf_albion_datafabric #(.NB(NB), .BANK_BYTES(BANK_BYTES), .NW(NW)) dut (
    .clk, .rst_n,
    .m_req_valid, .m_req_ready, .m_req_addr, .m_req_we, .m_req_wdata, .m_req_wstrb, .m_req_domain,
    .m_rsp_valid, .m_rsp_rdata, .m_rsp_err,
    .win_base, .win_limit, .win_attr, .boot_mode,
    .s_req_valid, .s_req_ready, .s_req_addr, .s_req_we, .s_req_wdata, .s_req_wstrb, .s_req_domain, .s_req_id,
    .s_rsp_valid, .s_rsp_rdata, .s_rsp_err, .s_rsp_id,
    .viol_o, .viol_addr_o, .viol_master_o, .viol_domain_o, .viol_we_o, .decerr_o,
    .ev_m_txn_o, .ev_m_stall_o, .ev_s_txn_o, .ev_bank_conflict_o);

  always @* begin
    // an assumption-satisfying trace of WIT+1 steps exists (guards against contradictory assumptions)
    `SF_COVER(FAB_ENV_SATISFIABLE, sf_step >= 8'(WIT))
  end
endmodule
