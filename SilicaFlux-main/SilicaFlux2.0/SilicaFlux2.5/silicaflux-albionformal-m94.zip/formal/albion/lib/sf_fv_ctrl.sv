// =============================================================================
//  sf_fv_ctrl.sv -- reset / clock environment module shared by every AlbionFormal harness
//  (macros live in albion_formal.svh; this is a separate file so that the macro header can be
//  `included inside DUT modules by the bind mechanism without nesting a module definition)
// =============================================================================
// ---- reset / clock environment ----------------------------------------------------------
//  sf_fv_ctrl produces the reset waveform and the bookkeeping every harness needs.
//
//  MODE = 0  "single reset"   rst_n is 0 in step 0 and then held 1 for ever.
//                              Reachable states = states reachable from ONE reset.
//  MODE = 1  "reset anywhere" rst_n is 0 in step 0 and is free afterwards (reset may be
//                              re-asserted at any cycle, for any length).
//  MODE = 2  "reset window"   rst_n is 0 in steps 0..RST_CYCLES-1 and then held 1.
//
//  Clock assumption (assumption CLK_IDEAL, structural): one ideal clock, one active edge
//  per formal step; no glitches, no skew, no clock-domain crossing. Yosys `async2sync`
//  turns asynchronous resets into step-synchronous ones (reset takes effect in the cycle in
//  which it is asserted). Reset-deassertion timing, metastability and reset-domain crossing
//  are NOT modelled -- see docs/METHODOLOGY.md section 5.
//
//  Outputs
//    rst_n      reset, active low, to be connected to the DUT
//    sf_live    1 from the cycle AFTER the first reset edge: DUT state is then defined
//    sf_first   1 in step 0 only
//    sf_step    step counter, saturating at 255 (used by depth-witness covers)
module sf_fv_ctrl #(
  parameter int MODE       = 0,
  parameter int RST_CYCLES = 2
) (
  input  logic clk,
  input  logic rst_free,   // free input, only used when MODE == 1
  output logic rst_n,
  output logic sf_live,
  output logic sf_first,
  output logic [7:0] sf_step
);
  logic [7:0] cnt;
  logic       first;
  initial begin
    cnt   = 8'd0;
    first = 1'b1;
  end
  always_ff @(posedge clk) begin
    first <= 1'b0;
    if (cnt != 8'hFF) cnt <= cnt + 8'd1;
  end
  assign sf_first = first;
  assign sf_step  = cnt;

  generate
    if (MODE == 0) begin : g_once
      assign rst_n = !first;
    end else if (MODE == 1) begin : g_any
      assign rst_n = !first && rst_free;
    end else begin : g_window
      assign rst_n = (cnt >= 8'(RST_CYCLES));
    end
  endgenerate

  // the DUT has seen at least one reset edge once step >= 1 (reset asserted in step 0)
  assign sf_live = !first;
endmodule

