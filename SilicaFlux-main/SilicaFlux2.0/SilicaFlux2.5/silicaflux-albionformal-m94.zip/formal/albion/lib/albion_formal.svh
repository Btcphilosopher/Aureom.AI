// =============================================================================
//  albion_formal.svh  --  AlbionFormal assertion / assumption / cover macro library
//  SilicaFlux Module 94
// -----------------------------------------------------------------------------
//  WHY MACROS AND NOT `assert property (... |-> ...)`
//    The open-source Yosys front end (0.33, the version used here) accepts immediate
//    assertions and only the most basic `assert property (expr)` form. It does NOT accept
//    SVA sequences, `|->`, `##n`, `$past` over sequences or clocking blocks (those need the
//    commercial Verific front end / Tabby CAD). This library therefore expresses temporal
//    properties in the form every SVA property can be reduced to: a monitor state machine
//    plus an immediate assertion. Each macro below documents the SVA it stands for.
//
//  LABEL CONVENTION (the proof driver depends on it -- scripts/albion_formal.py):
//    A_<ID>   assertion   a property claimed about the RTL        (ledger row per ID)
//    L_<ID>   lemma       helper invariant, proven jointly with the A_ properties in the
//                         same job. Lemmas are real assertions, never silently assumed.
//    S_<ID>   assume      environment constraint. EVERY S_ label must be declared in
//                         config/assumptions.json, otherwise the driver aborts the job
//                         ("undeclared assumption"). This is what stops quiet over-constraint.
//    C_<ID>   cover       reachability witness (vacuity detector / non-triviality evidence)
//
//  GATING ON RESET
//    Flip-flops of the DUT are unconstrained in step 0 (before the first reset edge has been
//    applied). State-dependent properties must therefore only be asserted once the design has
//    seen reset: `sf_live` (see sf_fv_ctrl below). Purely combinational properties that hold in
//    every state use SF_ASSERT_COMB and are NOT gated (they are strictly stronger).
// =============================================================================
`ifndef ALBION_FORMAL_SVH
`define ALBION_FORMAL_SVH

// ---- property macros --------------------------------------------------------------------
// Use inside `always @*` blocks of a harness. `sf_live` must be in scope.
//   SVA equivalent:  assert property (@(posedge clk) disable iff (!live) (expr));
`define SF_ASSERT(id, expr)       A_``id: assert (!sf_live || (expr));
//   SVA equivalent:  assert property (@(posedge clk) (expr));      (holds even before reset)
`define SF_ASSERT_COMB(id, expr)  A_``id: assert (expr);
//   SVA equivalent:  assert property (@(posedge clk) disable iff (!live) (ante) |-> (cons));
`define SF_ASSERT_IMPL(id, ante, cons) A_``id: assert (!sf_live || !(ante) || (cons));
`define SF_LEMMA(id, expr)        L_``id: assert (!sf_live || (expr));
`define SF_LEMMA_IMPL(id, ante, cons) L_``id: assert (!sf_live || !(ante) || (cons));
//   SVA equivalent:  assume property (@(posedge clk) disable iff (!live) (expr));
`define SF_ASSUME(id, expr)       S_``id: assume (!sf_live || (expr));
//   Assumption that is also meaningful in step 0 (e.g. constraints on free inputs only).
`define SF_ASSUME_COMB(id, expr)  S_``id: assume (expr);
//   SVA equivalent:  cover property (@(posedge clk) live && (expr));
//   Covers are gated on sf_live, otherwise they would be "reached" in step 0 from an
//   arbitrary (unreachable) initial state, which proves nothing.
`define SF_COVER(id, expr)        C_``id: cover (sf_live && (expr));

`endif
