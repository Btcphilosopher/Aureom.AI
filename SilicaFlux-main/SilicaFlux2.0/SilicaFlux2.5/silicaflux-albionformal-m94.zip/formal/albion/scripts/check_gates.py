#!/usr/bin/env python3
"""CI gates for AlbionFormal. Exit status != 0 if any gate fails. Reads reports/results/*.json only.

  G1 vendored RTL hashes match vendor/SOURCES.sha256
  G2 every executed job ended in its EXPECTED result class (jobs.json: expect_class); no FAIL/ERROR/TIMEOUT/VACUOUS
  G3 every cover property of every executed cover job is reached (vacuity gate)
  G4 no result is STALE (harness/RTL changed after it was produced)
  G5 cross-check engines never disagree
  G6 mutation campaign (if run): no unwaived survivor
  G7 declared assumptions == assumptions present in the model (no undeclared constraint) -- enforced by the driver (job ERROR)
Usage: check_gates.py [--require-all]   (--require-all: also fail when a configured job has no result)
"""
import hashlib, json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import albion_formal as af  # noqa: E402

req_all = "--require-all" in sys.argv
cfg = af.load_cfg()
fails, notes = [], []
bad = af.verify_vendor()
if bad:
    fails.append(f"G1 vendored RTL differs: {bad}")
res_dir = ROOT / "reports/results"
have = {p.stem: json.load(open(p)) for p in res_dir.glob("*.json") if p.stem not in ("mutation_results", "assumption_sensitivity")}
for j in cfg["jobs"]:
    r = have.get(j["id"])
    if r is None:
        (fails if req_all else notes).append(f"job {j['id']}: no result")
        continue
    ok_class = j["expect_class"] if j["expect"] == "PASS" else ["FAIL"]
    if r["status"] not in ok_class:
        fails.append(f"G2 {j['id']}: {r['status']} (expected one of {ok_class}) {r.get('error', '')[:120]}")
    for cid, v in r.get("covers", {}).items():
        if v["status"] != "COVER-REACHED":
            fails.append(f"G3 {j['id']}: cover {cid} {v['status']}")
    for rel, h in (r.get("inputs") or {}).items():
        p = (ROOT / "vendor" / rel) if rel.startswith(("albion_p90", "citadel_p89")) else ROOT / rel
        if not p.exists() or af.sha256(p) != h:
            fails.append(f"G4 {j['id']}: STALE ({rel} changed)")
            break
    if not r.get("inputs"):
        fails.append(f"G4 {j['id']}: STALE (no input hashes recorded)")
    if r.get("cross_check_agree") is False:
        fails.append(f"G5 {j['id']}: cross-check DISAGREES {r.get('cross_check')}")
mp = res_dir / "mutation_results.json"
if mp.exists():
    for m in json.load(open(mp)):
        if not m["killed"] and not m.get("waiver"):
            fails.append(f"G6 mutant {m['id']} SURVIVED ({m['description']})")
else:
    notes.append("mutation campaign not run")
for n in notes:
    print("note:", n)
if fails:
    print("GATES FAILED:")
    for f in fails:
        print("  -", f)
    sys.exit(1)
print(f"all gates passed ({len(have)} job results)")
