#!/usr/bin/env python3
"""AlbionFormal proof driver (SilicaFlux Module 94).

Runs the formal jobs in config/jobs.json, classifies every result honestly and writes the
raw evidence the proof ledger is generated from.

Backends
  native   yosys + yosys-smtbmc (z3 / cvc5) + yosys-abc (pdr).  This is exactly the flow
           SymbiYosys generates for `smtbmc` / `abc pdr` engines; it is what produced every
           result in the shipped ledger.
  sby      if `sby` is installed, `--backend sby` runs the generated build/<job>/job.sby with it.
           (sby could not be installed in the environment the shipped results were produced in;
           the .sby files are generated for users that have it. See docs/METHODOLOGY.md.)

Result classes (never mixed)
  PROVEN         unbounded proof (k-induction base+step, or ABC PDR), only structural assumptions
  PROVEN-COND    unbounded proof that depends on declared environment assumptions
  BOUNDED        no counterexample up to depth N; NOT a proof for longer traces
  FAIL           counterexample found (see reports/counterexamples)
  COVER-REACHED / COVER-UNREACHED
  TIMEOUT        solver did not finish within the job timeout (no claim made)
  VACUOUS        assumptions are contradictory (the proof would be meaningless)
  ERROR          tool / elaboration error
"""
import argparse
import concurrent.futures as cf
import csv
import hashlib
import json
import os
import re
import shlex
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent          # formal/albion
VENDOR = ROOT / "vendor"
BUILD = Path(os.environ.get("ALBION_BUILD", ROOT / "build"))
REPORTS = ROOT / "reports"
SOLVER_BIN = {"z3": "z3", "cvc5": "cvc5", "boolector": "boolector"}
STRUCTURAL = "structural"


# ------------------------------------------------------------------------------ utilities
def jload(p):
    with open(p) as f:
        return json.load(f)


def jdump(obj, p):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w") as f:
        json.dump(obj, f, indent=2, sort_keys=False)
        f.write("\n")


def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def tool_version(cmd):
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return (out.stdout or out.stderr).strip().splitlines()[0]
    except Exception as e:  # pragma: no cover
        return f"unavailable ({e.__class__.__name__})"


def run(cmd, timeout, log, env=None, cwd=None):
    """Run a command in its own process group; kill the group on timeout.
    Returns (returncode, timed_out, seconds, combined_output)."""
    t0 = time.time()
    with open(log, "w") as lf:
        p = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT, text=True, env=env, cwd=cwd,
                             start_new_session=True)
        try:
            p.wait(timeout=timeout)
            to = False
        except subprocess.TimeoutExpired:
            to = True
            try:
                os.killpg(os.getpgid(p.pid), signal.SIGKILL)
            except Exception:
                p.kill()
            p.wait()
    return p.returncode, to, time.time() - t0, Path(log).read_text(errors="replace")


# ------------------------------------------------------------------------------ configuration
def load_cfg():
    cfg = {
        "jobs": jload(ROOT / "config/jobs.json")["jobs"],
        "props": jload(ROOT / "config/properties.json"),
        "asm": jload(ROOT / "config/assumptions.json"),
        "unres": jload(ROOT / "config/unresolved.json") if (ROOT / "config/unresolved.json").exists() else [],
        "mutants": jload(ROOT / "mutants/mutants.json")["mutants"] if (ROOT / "mutants/mutants.json").exists() else [],
    }
    for j in cfg["jobs"]:
        j.setdefault("mode", "prove")
        j.setdefault("depth", 20)
        j.setdefault("solver", "z3")
        j.setdefault("timeout", 900)
        j.setdefault("defines", [])
        j.setdefault("params", {})
        j.setdefault("binds", [])
        j.setdefault("files", [])
        j.setdefault("assumptions", [])
        j.setdefault("tags", [])
        j.setdefault("embedded", "remove")
        j.setdefault("cross_check", [])
        j.setdefault("expect", "PASS")
        j.setdefault("mut_depth", min(j["depth"], 24))
        j.setdefault("expect_class", {"prove": ["PROVEN", "PROVEN-COND"], "pdr": ["PROVEN", "PROVEN-COND"], "bmc": ["BOUNDED"],
                                      "cover": ["COVER-REACHED"], "abc-comb": ["PROVEN"]}[j["mode"]])
    return cfg


def verify_vendor():
    """The RTL under test must be byte-identical to the snapshot recorded in SOURCES.sha256."""
    bad = []
    for line in (VENDOR / "SOURCES.sha256").read_text().splitlines():
        if not line.strip() or line.startswith("#"):
            continue
        h, rel = line.split(None, 1)
        p = VENDOR / rel.strip()
        if not p.exists() or sha256(p) != h:
            bad.append(rel.strip())
    return bad


# ------------------------------------------------------------------------------ build
def instrument(src_text, module, include_path):
    """Insert `include of a bind file just before the endmodule closing `module` (bind emulation:
    the open-source Yosys front end has no `bind`). The RTL on disk is never touched."""
    m = re.search(r"^\s*module\s+" + re.escape(module) + r"\b", src_text, re.M)
    if not m:
        raise RuntimeError(f"module {module} not found for bind")
    e = re.compile(r"^\s*endmodule\b", re.M).search(src_text, m.end())
    if not e:
        raise RuntimeError(f"endmodule for {module} not found")
    ins = f'\n`ifdef FORMAL\n`include "{include_path}"\n`endif\n'
    return src_text[:e.start()] + ins + src_text[e.start():]


def apply_mutation(text, mut):
    edits = mut.get("edits") or [{"old": mut["old"], "new": mut["new"]}]
    for e in edits:
        n = text.count(e["old"])
        if n != 1:
            raise RuntimeError(f"mutant {mut['id']}: pattern occurs {n} times (must be exactly 1): {e['old'][:60]!r}")
        text = text.replace(e["old"], e["new"])
    return text


def stage_sources(job, wd, mutation=None):
    """Copy RTL into the build dir, applying a mutation and binds. Returns list of staged paths
    in compile order (vendor files first, then harness)."""
    rtl_dir = wd / "rtl"
    rtl_dir.mkdir(parents=True, exist_ok=True)
    staged = []
    binds = {b["file"]: b for b in job["binds"]}
    by_module = {}
    for b in job["binds"]:
        by_module.setdefault(b["file"], []).append(b)
    for rel in job["files"]:
        src = VENDOR / rel
        text = src.read_text()
        if mutation and mutation["file"] == rel:
            text = apply_mutation(text, mutation)
        for b in by_module.get(rel, []):
            text = instrument(text, b["module"], str((ROOT / b["include"]).resolve()))
        dst = rtl_dir / Path(rel).name
        dst.write_text(text)
        staged.append(dst)
    if mutation and mutation["file"] not in job["files"]:
        raise RuntimeError(f"mutant {mutation['id']} targets {mutation['file']}, not in job {job['id']}")
    del binds
    return staged


def yosys_front(job, staged):
    defs = " ".join(f"-D{d}" for d in (["FORMAL", "SYNTHESIS"] + job["defines"]))
    incs = " ".join(f"-I{(ROOT / i).resolve()}" for i in (["lib"] + job.get("incdirs", [])))
    extra = [ROOT / e for e in job.get("extra", [])]
    files = " ".join(shlex.quote(str(p)) for p in staged + [ROOT / "lib/sf_fv_ctrl.sv"] + extra + [ROOT / job["harness"]])
    cp = "; ".join(f"chparam -set {k} {v} {job['top']}" for k, v in job["params"].items())
    s = f"read_verilog -formal -sv {defs} {incs} {files}"
    if cp:
        s += "; " + cp
    s += f"; prep -flatten -top {job['top']}"
    return s


LAB = re.compile(r"(?:^|[.\\])([ALSC]_[A-Za-z0-9_]+)$")


def labels(txt):
    """Cell names from `select -list`. Labelled properties inside bound/flattened submodules carry an instance
    prefix (e.g. $flatten\\dut.A_X): normalise them to the bare label. Anonymous RTL asserts keep their name."""
    out = []
    for ln in txt.splitlines():
        ln = ln.strip()
        if "/" in ln and not ln.startswith("#"):
            n = ln.split("/", 1)[1]
            m = LAB.search(n)
            out.append(m.group(1) if (m and "$assert$" not in n and "$assume$" not in n and "$cover$" not in n) else n)
    return list(dict.fromkeys(out))


def classify_cells(names, kind):
    """Map yosys cell names to (id, group)."""
    ids = []
    for n in names:
        if kind == "assert" and "$assert$" in n:
            m = re.search(r"([^/\\]+\.sv):(\d+)", n)
            ids.append(("RTL:%s:%s" % (m.group(1), m.group(2)) if m else "RTL:" + n, n))
        else:
            ids.append((n, n))
    return ids


def elaborate(job, wd, staged, keep, drop, mode_flow, tag="model"):
    """Run yosys. keep = list of A_ labels to keep (None = all); drop = list of S_ labels to remove.
    Returns dict(model=path, asserts, assumes, covers, log)."""
    wd.mkdir(parents=True, exist_ok=True)
    names = {k: wd / f"{tag}.{k}.txt" for k in ("assume", "assert", "cover")}
    pre = yosys_front(job, staged)
    sel = "; ".join(f"tee -q -o {names[k]} select -list t:${k}" for k in names)
    rm = []
    if job["embedded"] == "remove":
        rm.append("chformal -remove c:*$assert$*")
    if keep is not None:
        for lab in job["_all_asserts"]:
            if lab.startswith(("A_", "L_")) and lab not in keep:
                rm.append(f"chformal -remove c:*{lab}")
    for lab in (drop or []):
        rm.append(f"chformal -remove c:*{lab}")
    if mode_flow == "cover":
        rm.append("chformal -assert -remove")
    elif mode_flow == "pdr-cover-strip":
        rm.append("chformal -cover -remove")
    out = wd / (tag + (".smt2" if mode_flow in ("smt", "cover") else ".aig"))
    if mode_flow == "comb":
        post = f"opt_clean; synth -flatten -top {job['top']}; aigmap; opt_clean; write_aiger -zinit {out}"
    elif mode_flow in ("smt", "cover"):
        post = ("async2sync; chformal -assume -early; opt_clean; setundef -anyseq; opt -fast; dffunmap; "
                f"write_smt2 -wires {out}")
    else:
        post = ("chformal -cover -remove; async2sync; chformal -assume -early; opt_clean; memory_map; setundef -anyseq; "
                "dffunmap; techmap; opt -fast; abc -g AND -fast; dffunmap; aigmap; opt_clean; "
                f"write_aiger -I -B -zinit -map {wd / (tag + '.aim')} {out}")
    script = "; ".join([pre, sel] + rm + [post])
    cmd = ["yosys", "-q", "-l", str(wd / f"{tag}.yosys.log"), "-p", script]
    rc, to, secs, txt = run(cmd, 600, wd / f"{tag}.elab.out")
    r = {"model": out, "ok": rc == 0 and out.exists(), "script": script, "log": txt, "elab_s": secs, "cmd": cmd}
    for k in names:
        r[k + "s"] = labels(names[k].read_text()) if names[k].exists() else []
    return r


# ------------------------------------------------------------------------------ solving
FAIL_RE = re.compile(r"Assert failed in ([^:]+): (.*)")


def parse_failed(txt):
    """Names of failed assertions in an smtbmc log -> list of ids; plus failing step."""
    ids = []
    for m in re.finditer(r"Assert failed in ([^:\n]+): ([^\n]*?)(?: \(step \d+\))?\s*$", txt, re.M):
        body = m.group(2).strip()
        name = body
        lm = re.search(r"(?:^|[.\\])([ALSC]_[A-Za-z0-9_]+)$", body)       # strip instance prefix (dut.A_X -> A_X)
        if lm and "$assert$" not in body:
            name = lm.group(1)
        mm = re.search(r"([^/\\\s:]+\.sv):(\d+)", body)
        if mm and "$assert$" in body:
            name = "RTL:%s:%s" % (mm.group(1), mm.group(2))
        ids.append(name)
    steps = [int(x) for x in re.findall(r"Checking assertions in step (\d+)", txt)]
    return list(dict.fromkeys(ids)), (steps[-1] if steps else None)


def smtbmc_cmd(model, solver, depth, mode, vcd=None, top=None):
    # --unroll: turns each yosys `define-fun` wire function into one cached named definition. Without it z3 expands
    # the functions as macros (a DAG becomes a tree) and a 450 KB model does not even finish parsing.
    cmd = ["yosys-smtbmc", "-s", solver, "--unroll", "--noprogress", "-t", str(depth)]
    if mode == "bmc":
        cmd += ["--presat"]
    if mode == "ind":
        cmd += ["-i"]
    if mode == "cover":
        cmd += ["-c"]
    if vcd:
        cmd += ["--dump-vcd", str(vcd)]
    cmd += [str(model)]       # top module is auto-detected (it may be renamed to $paramod... by chparam)
    return cmd


def solver_env(wd):
    return dict(os.environ)


def run_smt(job, model, wd, solver, mode, depth, tag, timeout):
    vcd = wd / f"{tag}.vcd"
    cmd = smtbmc_cmd(model, solver, depth, mode, vcd, job["top"])
    rc, to, secs, txt = run(cmd, timeout, wd / f"{tag}.smtbmc.log", env=solver_env(wd))
    res = {"cmd": cmd, "seconds": secs, "log": str(wd / f"{tag}.smtbmc.log"), "vcd": str(vcd) if vcd.exists() else None}
    if to:
        res["status"] = "TIMEOUT"
    elif "Assumptions are unsatisfiable" in txt:
        res["status"] = "VACUOUS"
    elif "Status: PASSED" in txt:
        res["status"] = "PASSED"
    elif "Status: FAILED" in txt or "failed!" in txt:
        res["status"] = "FAILED"
        res["failed"], res["fail_step"] = parse_failed(txt)
    else:
        res["status"] = "ERROR"
        res["error"] = txt[-600:]
    if mode == "cover":
        norm = lambda n: (LAB.search(n).group(1) if LAB.search(n) else n)       # dut.C_X -> C_X
        res["reached"] = {norm(m.group(1)): int(m.group(2)) for m in re.finditer(r"Reached cover statement at (\S+) in step (\d+)", txt)}
        res["unreached"] = [norm(x) for x in re.findall(r"Unreached cover statement at (\S+)\.", txt)]
    return res


def run_pdr(job, wd, staged, prop, timeout):
    tag = f"pdr_{prop}"
    el = elaborate(job, wd, staged, keep=[prop], drop=None, mode_flow="aig", tag=tag)
    if not el["ok"]:
        return {"status": "ERROR", "error": el["log"][-500:], "prop": prop}
    cmd = ["yosys-abc", "-c", f"read_aiger {el['model']}; fold; strash; dretime; pdr"]
    rc, to, secs, txt = run(cmd, timeout, wd / f"{tag}.abc.log")
    r = {"prop": prop, "seconds": secs + el["elab_s"], "cmd": cmd, "log": str(wd / f"{tag}.abc.log")}
    if to:
        r["status"] = "TIMEOUT"
    elif "Property proved" in txt:
        r["status"] = "PROVED"
        fr = re.findall(r"Invariant F\[(\d+)\]", txt)
        r["frames"] = int(fr[-1]) if fr else 0
    elif re.search(r"asserted in frame (\d+)", txt):
        r["status"] = "FAILED"
        r["fail_step"] = int(re.search(r"asserted in frame (\d+)", txt).group(1))
    else:
        r["status"] = "ERROR"
        r["error"] = txt[-400:]
    return r


# ------------------------------------------------------------------------------ job execution
def input_hashes(job):
    """sha256 of every file that determines the job's result (RTL, harness, binds, lib). The ledger compares
    these with the files on disk and marks a result STALE if anything changed after it was produced."""
    files = [ROOT / "lib/albion_formal.svh", ROOT / "lib/sf_fv_ctrl.sv", ROOT / job["harness"]] + [ROOT / e for e in job.get("extra", [])]
    files += [ROOT / b["include"] for b in job["binds"]] + [VENDOR / f for f in job["files"]]
    return {str(f.relative_to(ROOT)): sha256(f) for f in files}


def sby_text(job, staged):
    """Generate a SymbiYosys file equivalent to the native flow (smtbmc modes only). NEVER EXECUTED by the shipped results
    (sby was not installable where they were produced). Run the driver once for the job first: it stages the RTL under
    build/<job>/rtl/ (binds applied), which this file references."""
    if job["mode"] not in ("bmc", "prove", "cover"):
        return None
    extra = [ROOT / e for e in job.get("extra", [])]
    srcs = list(staged) + [ROOT / "lib/sf_fv_ctrl.sv"] + extra + [ROOT / job["harness"]]
    defs = " ".join(f"-D{d}" for d in (["FORMAL", "SYNTHESIS"] + job["defines"]))
    cp = "\n".join(f"chparam -set {k} {v} {job['top']}" for k, v in job["params"].items())
    mode = {"bmc": "bmc", "prove": "prove", "cover": "cover"}[job["mode"]]
    s = (f"# generated by scripts/albion_formal.py for job {job['id']}\n"
         f"# NOT EXECUTED: the shipped results come from the native yosys/yosys-smtbmc driver (sby was unavailable).\n"
         f"# Prerequisite: run `python3 scripts/albion_formal.py run {job['id']}` once so build/{job['id']}/rtl/ is staged.\n"
         f"[options]\nmode {mode}\ndepth {job['depth']}\nmulticlock off\n\n"
         f"[engines]\nsmtbmc --unroll {job['solver']}\n\n"
         f"[script]\nread -formal -sv {defs} {' '.join(Path(p).name for p in srcs)}\n{cp}\nprep -flatten -top {job['top']}\n\n[files]\n")
    base = ROOT / "reports/repro" / job["id"]
    s += "\n".join(os.path.relpath(p, base) for p in srcs + [ROOT / "lib/albion_formal.svh"]) + "\n"
    return s


def _dq(arg):
    """double-quote a shell argument, escaping it, and make the suite root relocatable via ${ALBION_ROOT}"""
    t = arg.replace("\\", "\\\\").replace('"', '\\"').replace("$", "\\$").replace("`", "\\`")
    return '"' + t.replace(str(ROOT), "${ALBION_ROOT}") + '"'


def write_repro(job, wd, el, cmds, portable=True):
    lines = ["#!/usr/bin/env bash", f"# reproduction of job {job['id']}: the raw tool invocations the driver ran.",
             "# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).",
             "set -e",
             'ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"',
             'mkdir -p "${ALBION_ROOT}/build/' + job["id"] + '" && cd "${ALBION_ROOT}/build/' + job["id"] + '"',
             "# 1. elaborate", " ".join(_dq(c) for c in el["cmd"]).replace(_dq(str(wd)), '"${ALBION_ROOT}/build/' + job["id"] + '"')]
    lines += ["# 2. solve"] + [" ".join(_dq(c) for c in c_) for c_ in cmds]
    out = (ROOT / "reports/repro" / job["id"]) if portable else wd
    out.mkdir(parents=True, exist_ok=True)
    (out / "repro.sh").write_text("\n".join(lines) + "\n")
    os.chmod(out / "repro.sh", 0o755)


def run_job(job, cfg, mutation=None, isolate=True, drop=None, solver=None, depth=None, mode=None, quiet=False, only=None):
    """Run one job. Returns a result dict (also persisted unless mutation run)."""
    job = json.loads(json.dumps(job))
    jid = job["id"] if not mutation else f"{job['id']}@{mutation['id']}"
    if drop:
        jid += "@drop_" + "_".join(d[2:] for d in drop)        # relaxed-environment runs never overwrite the proof's build dir
    wd = BUILD / jid.replace("@", "__")
    if wd.exists():
        shutil.rmtree(wd)
    wd.mkdir(parents=True)
    if solver:
        job["solver"] = solver
    if depth:
        job["depth"] = depth
    if mode:
        job["mode"] = mode
    t0 = time.time()
    res = {"id": job["id"], "title": job.get("title", ""), "inputs": input_hashes(job), "mode": job["mode"], "solver": job["solver"], "depth": job["depth"],
           "top": job["top"], "harness": job["harness"], "params": job["params"], "mutation": mutation["id"] if mutation else None,
           "dropped": drop or [], "tags": job["tags"], "props": {}, "covers": {}, "notes": job.get("notes", "")}
    try:
        staged = stage_sources(job, wd, mutation)
    except Exception as e:
        res.update(status="ERROR", error=str(e))
        return res
    # --- pass 0: elaborate with everything to learn the label sets
    flow = "cover" if job["mode"] == "cover" else "smt"
    job["_all_asserts"] = []
    el = elaborate(job, wd, staged, keep=None, drop=drop, mode_flow="aig" if job["mode"] == "pdr" else ("comb" if job["mode"] == "abc-comb" else flow), tag="model")
    if not el["ok"]:
        res.update(status="ERROR", error="elaboration failed: " + el["log"][-800:])
        return res
    # labels learnt *before* removal come from the select dumps (run before chformal -remove)
    asserts = el["asserts"]
    job["_all_asserts"] = asserts
    declared = set(job["assumptions"])
    present = {a[2:] for a in el["assumes"] if a.startswith("S_")}
    anon = [a for a in el["assumes"] if not a.startswith("S_")]
    res["assumptions_present"] = sorted(present)
    undeclared = sorted(present - declared - set(drop or []))
    implicit = {k for k, v in cfg["asm"].items() if v.get("implicit")}
    missing = sorted(declared - present - implicit - set(drop or []))
    if undeclared or anon or any(a not in cfg["asm"] for a in present):
        res.update(status="ERROR", error=f"undeclared/unknown assumptions {undeclared + anon + [a for a in present if a not in cfg['asm']]}")
        return res
    if missing:
        res["warn_missing_assumptions"] = missing  # declared in jobs.json but not present in the model
    a_ids = [a for a in asserts if a.startswith("A_")]
    l_ids = [a for a in asserts if a.startswith("L_")]
    unl = [a for a in asserts if "$assert$" in a]
    res["asserts"] = a_ids
    res["lemmas"] = l_ids
    res["embedded"] = [classify_cells([u], "assert")[0][0] for u in unl] if job["embedded"] == "keep" else []
    emb_ids = [classify_cells([u], "assert")[0][0] for u in unl] if job["embedded"] == "keep" else []
    want = [p for p in job.get("props", [])] or ([a[2:] for a in a_ids] + emb_ids)
    if only:                       # mutation detector verification: check ONLY these assertions (lemmas stay)
        want = [p for p in only if ("A_" + p) in asserts]
        if not want:
            res.update(status="NOT-APPLICABLE", note="designed detector not present in this job")
            return res
    want_lab = [lab_of(p) for p in want]
    lemma_ids = list(l_ids)
    if only and job["mode"] in ("bmc", "prove"):
        el = elaborate(job, wd, staged, keep=want_lab + lemma_ids, drop=drop, mode_flow=flow, tag="only")
    for p in want_lab:
        if p not in asserts and not p.startswith("RTL:"):
            res.setdefault("warn_missing_props", []).append(p)
    cond = any(cfg["asm"][a]["category"] != STRUCTURAL for a in declared)
    res["conditional"] = cond
    res["cmds"] = []
    status_map = {}

    def finish(status, detail=None):
        for p in want + lemma_ids:
            status_map.setdefault(p, {"status": status, **(detail or {}), **({"lemma": True} if p.startswith("L_") else {})})

    solvers = [job["solver"]] + [s for s in job["cross_check"] if s != job["solver"]]
    mode_ = job["mode"]
    if mode_ == "abc-comb":
        # combinational miter: prove output `bad` is constant 0 for ALL inputs (exhaustive, not bounded)
        cmd = ["yosys-abc", "-c", f"read_aiger {el['model']}; strash; iprove"]
        rc, to, secs, txt = run(cmd, job["timeout"], wd / "abc_comb.log")
        res["cmds"].append(cmd)
        res["engine"] = "abc iprove (BDD/rewriting) combinational miter"
        if to:
            st = "TIMEOUT"
        elif re.search(r"^UNSATISFIABLE", txt, re.M):
            st = "PROVEN"
        elif re.search(r"^SATISFIABLE", txt, re.M):
            st = "FAIL"
        else:
            st = "ERROR"
        for p in job.get("props", []):
            status_map[p] = {"status": st, "engine": "abc-iprove", "exhaustive": True, "seconds": round(secs, 1)}
        res["solve"] = {"status": st, "log": str(wd / "abc_comb.log"), "cmd": cmd, "seconds": secs}
        res["props"] = status_map
        res["status"] = {"PROVEN": "PROVEN", "FAIL": "FAIL", "TIMEOUT": "TIMEOUT"}.get(st, "ERROR")
        res["failed_assertions"] = ["A_" + p for p in job.get("props", [])] if st == "FAIL" else []
        res["seconds"] = round(time.time() - t0, 2)
        res["repro"] = f"cd formal/albion && python3 scripts/albion_formal.py run {job['id']}"
        res["yosys_script"] = el["script"]
        res["conditional"] = False
        write_repro(job, wd, el, [cmd], portable=not (mutation or drop or only))
        return res
    if mode_ == "pdr":
        # one property per run; PDR discovers its own invariants (no lemmas needed)
        with cf.ThreadPoolExecutor(max_workers=min(3, len(want_lab) or 1)) as ex:
            futs = {p: ex.submit(run_pdr, job, wd, staged, p, job["timeout"]) for p in want_lab}
            for p, f in futs.items():
                r = f.result()
                st = {"PROVED": "PROVEN-COND" if cond else "PROVEN", "FAILED": "FAIL", "TIMEOUT": "TIMEOUT"}.get(r["status"], "ERROR")
                status_map[p[2:]] = {"status": st, "engine": "abc-pdr", "frames": r.get("frames"), "fail_step": r.get("fail_step"),
                                     "seconds": round(r["seconds"], 2), "log": r.get("log")}
                res["cmds"].append(r.get("cmd"))
        res["engine"] = "abc pdr (IC3)"
    elif mode_ == "cover":
        r = run_smt(job, el["model"], wd, job["solver"], "cover", job["depth"], "cover", job["timeout"])
        res["cmds"].append(r["cmd"])
        res["engine"] = f"smtbmc {job['solver']} cover"
        reached, unreached = r.get("reached", {}), r.get("unreached", [])
        for c in el["covers"]:
            cid = c[2:] if c.startswith("C_") else c
            res["covers"][cid] = {"status": "COVER-REACHED" if c in reached else "COVER-UNREACHED",
                                  "step": reached.get(c)}
        if r["status"] == "VACUOUS":
            res["covers"] = {k: {"status": "VACUOUS"} for k in res["covers"]}
        status_map = {}
        res["solve"] = r
    else:
        # smtbmc: bmc always; induction for prove. All asserts+lemmas jointly.
        sol = solvers[0]
        base = run_smt(job, el["model"], wd, sol, "bmc", job["depth"], "bmc", job["timeout"])
        res["cmds"].append(base["cmd"])
        res["solve_bmc"] = base
        ind = None
        if base["status"] == "PASSED" and mode_ == "prove":
            ind = run_smt(job, el["model"], wd, sol, "ind", job["depth"], "ind", job["timeout"])
            res["cmds"].append(ind["cmd"])
            res["solve_ind"] = ind
        res["engine"] = f"smtbmc {sol}" + (" bmc+k-induction" if mode_ == "prove" else " bmc")
        cross = []
        primary = ("pass" if base["status"] == "PASSED" and (mode_ == "bmc" or (ind and ind["status"] == "PASSED")) else
                   "fail" if base["status"] == "FAILED" else "other")
        xt = min(job["timeout"], job.get("cross_timeout", 180))
        for s2 in solvers[1:]:
            t1 = time.time()
            if s2 == "pdr":
                pd = [lab for lab in want_lab if lab.startswith("A_")]
                with cf.ThreadPoolExecutor(max_workers=min(3, len(pd) or 1)) as ex:
                    rs = [f.result() for f in [ex.submit(run_pdr, job, wd, staged, lab, xt) for lab in pd]]
                v = ("fail" if any(r["status"] == "FAILED" for r in rs) else "timeout" if any(r["status"] == "TIMEOUT" for r in rs)
                     else "error" if any(r["status"] == "ERROR" for r in rs) else "pass")
                cross.append({"solver": "abc-pdr", "verdict": v, "seconds": round(time.time() - t1, 1),
                              "frames": max([r.get("frames") or 0 for r in rs] or [0])})
            else:
                b2 = run_smt(job, el["model"], wd, s2, "bmc", job["depth"], f"bmc_{s2}", xt)
                i2 = (run_smt(job, el["model"], wd, s2, "ind", job["depth"], f"ind_{s2}", xt)
                      if (mode_ == "prove" and b2["status"] == "PASSED") else None)
                v = ("fail" if b2["status"] == "FAILED" else "timeout" if "TIMEOUT" in (b2["status"], (i2 or {}).get("status")) else
                     "pass" if (b2["status"] == "PASSED" and (mode_ == "bmc" or (i2 and i2["status"] == "PASSED"))) else "other")
                cross.append({"solver": s2, "verdict": v, "seconds": round(time.time() - t1, 1)})
        res["cross_check"] = cross
        concl = [c for c in cross if c["verdict"] in ("pass", "fail")]
        res["cross_check_agree"] = (None if not cross else (all(c["verdict"] == primary for c in concl) if concl else None))
        if base["status"] == "PASSED" and (mode_ == "bmc" or (ind and ind["status"] == "PASSED")):
            if mode_ == "prove":
                finish("PROVEN-COND" if cond else "PROVEN", {"k": job["depth"]})
            else:
                finish("BOUNDED", {"depth": job["depth"]})
        elif base["status"] == "PASSED" and ind:
            # no counterexample within depth, but k-induction is inconclusive -> bounded only
            res["induction_inconclusive"] = ind.get("failed", [])
            if mutation:
                finish("BOUNDED", {"depth": job["depth"], "note": f"k-induction at k={job['depth']} {ind['status']}"})
            else:
                survivors, removed, iters = induction_fixpoint(job, wd, staged, drop, [p for p in want if not p.startswith("RTL:")],
                                                              lemma_ids, cond, job["timeout"])
                res["induction_fixpoint"] = {"iterations": iters, "not_inductive": sorted(removed)}
                for lab in survivors:
                    pid = lab[2:] if lab.startswith("A_") else lab
                    status_map[pid] = {"status": "PROVEN-COND" if cond else "PROVEN", "k": job["depth"], "fixpoint": True,
                                       **({"lemma": True} if lab.startswith("L_") else {})}
                for lab, it in removed.items():
                    pid = lab[2:] if lab.startswith("A_") else lab
                    status_map[pid] = {"status": "BOUNDED", "depth": job["depth"], **({"lemma": True} if lab.startswith("L_") else {}),
                                       "note": f"not k-inductive at k={job['depth']} (CTI in fixpoint round {it}); BMC passed to depth {job['depth']}"}
                finish("BOUNDED", {"depth": job["depth"], "note": f"k-induction at k={job['depth']} {ind['status']}"})
        elif base["status"] == "FAILED":
            failed = base.get("failed", [])
            for lab in failed:
                pid = lab[2:] if lab.startswith("A_") else lab      # lemmas keep their L_ prefix
                status_map[pid] = {"status": "FAIL", "step": base.get("fail_step"), "depth": job["depth"],
                                   **({"lemma": True} if lab.startswith("L_") else {})}
            res["failed_assertions"] = failed
            res["fail_step"] = base.get("fail_step")
            if isolate and not mutation and job["expect"] == "PASS":
                # attribute precisely: rerun every other property alone (lemmas stay in)
                for p in want:
                    if p in status_map or p.startswith("RTL:"):
                        continue
                    sub = isolate_one(job, wd, staged, p, drop, el)
                    status_map[p] = sub
                for p in want + lemma_ids:
                    status_map.setdefault(p, {"status": "NOT-DETERMINED", "note": "job failed; property not isolated"})
            else:
                for p in want + lemma_ids:
                    status_map.setdefault(p, {"status": "NOT-DETERMINED", "note": "job failed; property not isolated"})
        elif base["status"] == "VACUOUS":
            finish("VACUOUS")
        elif base["status"] == "TIMEOUT":
            finish("TIMEOUT", {"depth": job["depth"]})
        else:
            finish("ERROR", {"error": base.get("error")})
        res["solve"] = base
    res["props"] = status_map
    # job status
    sts = {v["status"] for v in status_map.values()} | {v["status"] for v in res["covers"].values()}
    if "ERROR" in sts:
        res["status"] = "ERROR"
    elif "VACUOUS" in sts:
        res["status"] = "VACUOUS"
    elif "FAIL" in sts:
        res["status"] = "FAIL"
    elif "TIMEOUT" in sts:
        res["status"] = "TIMEOUT"
    elif "COVER-UNREACHED" in sts:
        res["status"] = "COVER-UNREACHED"
    elif sts == {"COVER-REACHED"}:
        res["status"] = "COVER-REACHED"
    elif "BOUNDED" in sts:
        res["status"] = "BOUNDED"
    elif sts:
        res["status"] = sorted(sts)[0] if len(sts) == 1 else ("PROVEN-COND" if "PROVEN-COND" in sts else "PROVEN")
    else:
        res["status"] = "ERROR"
        res["error"] = "no properties were checked"
    res["seconds"] = round(time.time() - t0, 2)
    proof_run = not mutation and not drop and not only
    sbt = sby_text(job, staged)
    if sbt and proof_run:
        (ROOT / "reports/repro" / job["id"]).mkdir(parents=True, exist_ok=True)
        (ROOT / "reports/repro" / job["id"] / "job.sby").write_text(sbt)
    write_repro(job, wd, el, [c for c in res["cmds"] if c], portable=proof_run)
    res["repro"] = f"cd formal/albion && python3 scripts/albion_formal.py run {job['id']}"
    res["yosys_script"] = el["script"]
    if res["status"] == "FAIL":
        cex = write_cex_reports(job, res, wd, cfg)
        res["cex_reports"] = cex
    return res


def induction_fixpoint(job, wd, staged, drop, props, lemmas, cond, timeout):
    """Greatest inductive subset. Run k-induction on the joint set; remove only the assertions the induction
    step actually violates; repeat. The surviving set is inductive on its own (no removed assertion is assumed),
    so every survivor is a sound unbounded proof. Removed ones stay BOUNDED (they passed BMC)."""
    keep = ["A_" + p for p in props if not p.startswith("RTL:")] + list(lemmas)
    removed = {}
    for it in range(12):
        el = elaborate(job, wd, staged, keep=keep, drop=drop, mode_flow="smt", tag=f"fix{it}")
        if not el["ok"] or not keep:
            break
        r = run_smt(job, el["model"], wd, job["solver"], "ind", job["depth"], f"fix{it}_ind", job["timeout"])
        if r["status"] == "PASSED":
            return keep, removed, it + 1
        failed = [f for f in r.get("failed", []) if f in keep]
        if not failed:
            return [], removed, it + 1          # inconclusive (timeout / error): claim nothing
        for f in failed:
            removed[f] = it
        keep = [k for k in keep if k not in failed]
    return [], removed, 12


def isolate_one(job, wd, staged, p, drop, el0):
    """Re-run a single property (with all lemmas) to get its own verdict after a job failure."""
    tag = f"iso_{p}"
    el = elaborate(job, wd, staged, keep=["A_" + p] + [a for a in job["_all_asserts"] if a.startswith("L_")], drop=drop, mode_flow="smt", tag=tag)
    if not el["ok"]:
        return {"status": "ERROR"}
    cond = any(job_asm_cat(a) != STRUCTURAL for a in job["assumptions"])
    b = run_smt(job, el["model"], wd, job["solver"], "bmc", job["depth"], f"{tag}_bmc", job["timeout"])
    if b["status"] == "FAILED":
        if lab_of(p) in b.get("failed", []):
            return {"status": "FAIL", "step": b.get("fail_step"), "depth": job["depth"]}
        # only a helper lemma fails: this property's own verdict is undetermined, never blame it
        return {"status": "NOT-DETERMINED", "note": "helper lemma fails: " + ", ".join(b.get("failed", []))}
    if b["status"] != "PASSED":
        return {"status": b["status"]}
    if job["mode"] == "prove":
        i = run_smt(job, el["model"], wd, job["solver"], "ind", job["depth"], f"{tag}_ind", job["timeout"])
        if i["status"] == "PASSED":
            return {"status": "PROVEN-COND" if cond else "PROVEN", "k": job["depth"], "isolated": True}
        return {"status": "BOUNDED", "depth": job["depth"], "isolated": True, "note": f"k-induction {i['status']}"}
    return {"status": "BOUNDED", "depth": job["depth"], "isolated": True}


def lab_of(p):
    return p if p.startswith(("RTL:", "L_")) else "A_" + p


_ASM = None


def job_asm_cat(a):
    global _ASM
    if _ASM is None:
        _ASM = jload(ROOT / "config/assumptions.json")
    return _ASM[a]["category"]


# ------------------------------------------------------------------------------ counterexamples
def parse_vcd(path):
    """Minimal VCD reader -> (names {id: name}, widths, snapshots [dict id->value]) one snapshot per timestamp."""
    ids, widths, scope, snaps, cur = {}, {}, [], [], {}
    started = False
    curt = 0
    with open(path) as f:
        for ln in f:
            t = ln.split()
            if not t:
                continue
            if t[0] == "$scope":
                scope.append(t[2])
            elif t[0] == "$upscope":
                scope.pop()
            elif t[0] == "$var":
                ids[t[3]] = (".".join(scope[1:] + [t[4]]) if len(scope) > 1 else t[4])
                widths[t[3]] = int(t[2])
            elif t[0].startswith("#"):
                if started and (curt % 10 == 0):
                    snaps.append(dict(cur))
                started = True
                curt = int(t[0][1:])
            elif t[0][0] in "01xz" and len(t) == 1 and t[0][1:] in ids:
                cur[t[0][1:]] = t[0][0]
            elif t[0][0] == "b" and len(t) == 2:
                cur[t[1]] = t[0][1:]
    if started and (curt % 10 == 0):
        snaps.append(dict(cur))
    return ids, widths, snaps


def hexv(v):
    if v is None:
        return "-"
    if set(v) <= set("01"):
        return "%x" % int(v, 2) if len(v) > 1 else v
    return v


def write_cex_reports(job, res, wd, cfg):
    out = []
    vcd = res.get("solve", {}).get("vcd") or res.get("solve_bmc", {}).get("vcd")
    failed = res.get("failed_assertions") or [p for p, v in res["props"].items() if v["status"] == "FAIL"]
    if not failed:
        return out
    sub = "mutation/cex" if res.get("mutation") else ("sensitivity/cex" if res.get("dropped") else "counterexamples")
    cdir = REPORTS / sub
    cdir.mkdir(parents=True, exist_ok=True)
    name = res["id"] + (f"@{res['mutation']}" if res.get("mutation") else ("@drop_" + "_".join(d[2:] for d in res["dropped"]) if res.get("dropped") else ""))
    fname = cdir / (name.replace("@", "__") + ".md")
    L = [f"# Counterexample report: {name}", "",
         f"* job: `{res['id']}` ({res.get('title', '')})",
         f"* mutation: `{res['mutation']}`" if res.get("mutation") else
         (f"* RELAXED ENVIRONMENT: assumption(s) {', '.join(res['dropped'])} were DROPPED on purpose (assumption sensitivity analysis); the RTL is unmodified. This shows what the assumption protects against." if res.get("dropped")
          else "* mutation: none (this is a failure of the unmodified RTL)"),
         f"* engine: {res.get('engine')}   depth bound: {res['depth']}   failing step: {res.get('fail_step')}",
         f"* violated assertions: {', '.join('`%s`' % f for f in failed)}", ""]
    for f in failed:
        pid = f[2:] if f.startswith("A_") else f
        meta = cfg["props"].get(pid, {})
        if meta:
            L.append(f"**{pid}** ({meta.get('module', '')}): {meta.get('text', '')}")
    L += ["", "## Assumptions in force", ""]
    for a in res.get("assumptions_present", []):
        if "S_" + a in (res.get("dropped") or []):
            L.append(f"* `{a}`: **DROPPED in this run** (it is normally in force)")
        else:
            L.append(f"* `{a}`: {cfg['asm'].get(a, {}).get('text', '')}")
    repro = (f"cd formal/albion && python3 scripts/albion_formal.py mutate {res['mutation']}" if res.get("mutation") else
             f"cd formal/albion && python3 scripts/albion_formal.py sensitivity {res['id']}" if res.get("dropped") else res.get("repro", ""))
    L += ["", "## Reproduce", "", "```bash", repro,
          "# raw tool commands: build/%s/repro.sh" % (res["id"] + (("__" + res["mutation"]) if res.get("mutation") else "")), "```", ""]
    if vcd and Path(vcd).exists():
        try:
            ids, widths, snaps = parse_vcd(vcd)
            tops = sorted([(n, i) for i, n in ids.items() if "." not in n and not n.startswith("$") and "auto" not in n and widths[i] <= 64
                           and not n.startswith(("A_", "S_", "C_", "L_"))], key=lambda x: x[0])[:48]
            fs = res.get("fail_step")
            lo = max(0, (fs if fs is not None else len(snaps) - 1) - 7)
            hi = min(len(snaps), (fs if fs is not None else len(snaps) - 1) + 1)
            L += ["## Trace (hex; last cycles before and at the violation)", "", "| signal | " + " | ".join(f"t={k}" for k in range(lo, hi)) + " |",
                  "|---|" + "---|" * (hi - lo)]
            for n, i in tops:
                L.append(f"| `{n}` | " + " | ".join(hexv(snaps[k].get(i)) for k in range(lo, hi)) + " |")
            L += ["", f"Full waveform: `build/{res['id']}{('__' + res['mutation']) if res.get('mutation') else ''}/{Path(vcd).name}` (open with GTKWave).", ""]
            keepvcd = cdir
            shutil.copy(vcd, keepvcd / (name.replace("@", "__") + ".vcd"))
        except Exception as e:  # pragma: no cover
            L.append(f"(trace parse failed: {e})")
    fname.write_text("\n".join(L) + "\n")
    out.append(str(fname.relative_to(ROOT)))
    return out


# ------------------------------------------------------------------------------ commands
def select_jobs(cfg, ids, tag):
    js = cfg["jobs"]
    if ids and ids != ["all"]:
        sel = []
        for i in ids:
            m = [j for j in js if j["id"] == i or (i.endswith("*") and j["id"].startswith(i[:-1]))]
            if not m:
                sys.exit(f"unknown job {i}")
            sel += m
        return sel
    if tag:
        return [j for j in js if tag in j["tags"]]
    return js


def cmd_run(a, cfg):
    bad = verify_vendor()
    if bad:
        sys.exit("vendored RTL differs from vendor/SOURCES.sha256: " + ", ".join(bad))
    BUILD.mkdir(parents=True, exist_ok=True)
    (REPORTS / "results").mkdir(parents=True, exist_ok=True)
    jobs = select_jobs(cfg, a.jobs, a.tag)
    print(f"[albion-formal] {len(jobs)} job(s), -j{a.jobs_par}")
    worst = 0

    def one(j):
        r = run_job(j, cfg, isolate=not a.no_isolate, drop=a.drop, solver=a.solver, depth=a.depth)
        jdump(r, REPORTS / "results" / f"{j['id']}.json")
        return r

    with cf.ThreadPoolExecutor(max_workers=a.jobs_par) as ex:
        futs = {ex.submit(one, j): j for j in jobs}
        for f in cf.as_completed(futs):
            j, r = futs[f], f.result()
            exp = j["expect"]
            ok = (r["status"] in j["expect_class"]) if exp == "PASS" else (r["status"] == "FAIL")
            if r.get("cross_check_agree") is False:
                ok = False
                print(f"      !! cross-check solvers DISAGREE for {j['id']}: {r.get('cross_check')}")
            flag = "ok " if ok else "!! "
            worst |= (0 if ok else 1)
            n = {}
            for v in list(r["props"].values()) + list(r["covers"].values()):
                n[v["status"]] = n.get(v["status"], 0) + 1
            print(f"  {flag}{j['id']:34s} {r['status']:15s} {r.get('seconds', 0):7.1f}s  {n}")
            if r["status"] in ("ERROR",):
                print("      ", r.get("error", "")[:300].replace("\n", " "))
    return worst


def cmd_list(a, cfg):
    for j in cfg["jobs"]:
        print(f"{j['id']:34s} {j['mode']:6s} d={j['depth']:<4d} {j['solver']:5s} {','.join(j['tags']):18s} {j.get('title', '')}")


def cmd_mutate(a, cfg):
    bad = verify_vendor()
    if bad:
        sys.exit("vendored RTL differs from SOURCES.sha256: " + ", ".join(bad))
    BUILD.mkdir(parents=True, exist_ok=True)
    muts = cfg["mutants"]
    if a.ids and a.ids != ["all"]:
        muts = [m for m in muts if m["id"] in a.ids or any(m["id"].startswith(i[:-1]) for i in a.ids if i.endswith("*"))]
    jobs = {j["id"]: j for j in cfg["jobs"]}
    out = []

    def one(m):
        j = dict(jobs[m["job"]])
        if j["mode"] != "abc-comb":
            j["mode"] = "bmc"
        j["depth"] = m.get("depth") or j["mut_depth"]
        j["tags"] = []
        j["cross_check"] = []
        r = run_job(j, cfg, mutation=m, isolate=False)
        confirmed = []
        if a.verify and r["status"] == "FAIL" and j["mode"] == "abc-comb":
            confirmed = [e for e in m.get("expect_detect", []) if e in j.get("props", [])]      # the job's only property IS the detector
        elif a.verify and r["status"] == "FAIL":
            for e in m.get("expect_detect", []):
                if e.startswith("("):
                    continue
                r2 = run_job(j, cfg, mutation=m, isolate=False, only=[e])
                if r2["status"] == "FAIL":
                    confirmed.append(e)
        return {"detectors_confirmed": confirmed, "id": m["id"], "module": m["module"], "job": m["job"], "description": m["description"], "kind": m.get("kind", "functional"),
                "expected_detectors": m.get("expect_detect", []), "status": r["status"],
                "killed": r["status"] == "FAIL", "killed_by": r.get("failed_assertions", []), "fail_step": r.get("fail_step"),
                "depth": j["depth"], "seconds": r.get("seconds"), "error": r.get("error"),
                "cex": r.get("cex_reports", []), "repro": f"python3 scripts/albion_formal.py mutate {m['id']}",
                "waiver": m.get("waiver")}

    print(f"[albion-formal] {len(muts)} mutant(s)")
    with cf.ThreadPoolExecutor(max_workers=a.jobs_par) as ex:
        for r in ex.map(one, muts):
            out.append(r)
            tag = "KILLED  " if r["killed"] else ("ERROR   " if r["status"] == "ERROR" else "SURVIVED")
            print(f"  {tag} {r['id']:26s} by {', '.join((x[2:] if x[:2] in ('A_', 'L_') else x) for x in r['killed_by'])[:90] or '-'}  ({r['status']})")
            if r["status"] == "ERROR":
                print("      ", (r.get("error") or "")[:200])
    if not a.ids or a.ids == ["all"]:
        jdump(out, REPORTS / "results" / "mutation_results.json")
    else:
        # partial run: merge
        p = REPORTS / "results" / "mutation_results.json"
        old = {m["id"]: m for m in (jload(p) if p.exists() else [])}
        for r in out:
            old[r["id"]] = r
        jdump(list(old.values()), p)
    surv = [r for r in out if not r["killed"] and not r.get("waiver")]
    return 1 if surv else 0


def cmd_sensitivity(a, cfg):
    """Assumption-necessity sweep: drop each assumption of a job in turn. If dropping an assumption makes a
    property fail, the assumption is doing real work (the proof is conditional on it); if nothing changes the
    assumption is redundant for that job."""
    jobs = [j for j in cfg["jobs"] if j["id"] in a.jobs] if a.jobs != ["all"] else [j for j in cfg["jobs"] if "sens" in j["tags"]]
    out = []
    for j in jobs:
        j2 = dict(j)
        j2["mode"] = "bmc"
        j2["depth"] = j.get("mut_depth", 20)
        j2["tags"] = []
        j2["cross_check"] = []
        row = {"job": j["id"], "assumptions": {}, "not_assume_cells": []}
        prev = jload(REPORTS / "results" / f"{j['id']}.json") if (REPORTS / "results" / f"{j['id']}.json").exists() else {}
        present = set(prev.get("assumptions_present", []))
        for asm in j["assumptions"]:
            if cfg["asm"][asm]["category"] == STRUCTURAL:
                continue
            if asm not in present:
                row["not_assume_cells"].append(asm)      # configuration/scope choice realised by parameters or model structure
                continue
            r = run_job(j2, cfg, isolate=False, drop=[f"S_{asm}"])
            row["assumptions"][asm] = {"drop_result": r["status"], "violated_when_dropped": r.get("failed_assertions", []),
                                       "fail_step": r.get("fail_step"), "needed": r["status"] == "FAIL"}
            print(f"  {j['id']:28s} drop {asm:22s} -> {r['status']:8s} {r.get('failed_assertions', [])[:4]}")
        out.append(row)
    p = REPORTS / "results" / "assumption_sensitivity.json"
    old = {r["job"]: r for r in (jload(p) if p.exists() else [])}
    for r in out:
        old[r["job"]] = r
    jdump(list(old.values()), p)
    return 0


def cmd_repro(a, cfg):
    """Rebuild reports/repro/<job>/repro.sh from the commands recorded in the result files (no re-run)."""
    jobs = {j["id"]: j for j in cfg["jobs"]}
    n = 0
    for f in sorted((REPORTS / "results").glob("*.json")):
        if f.stem in ("mutation_results", "assumption_sensitivity"):
            continue
        r = jload(f)
        j = jobs.get(r["id"])
        if not j or not r.get("yosys_script"):
            continue
        wd = BUILD / j["id"]
        write_repro(j, wd, {"cmd": ["yosys", "-q", "-l", str(wd / "model.yosys.log"), "-p", r["yosys_script"]]}, [c for c in r.get("cmds", []) if c])
        if j["mode"] == "pdr":
            p = REPORTS / "repro" / j["id"] / "repro.sh"
            p.write_text(p.read_text().replace("# 2. solve", "# NOTE: PDR runs one AIG per property (pdr_<A_PROPERTY>.aig, produced by the driver); the commands below are\n# those ABC invocations. To regenerate the AIGs run: python3 scripts/albion_formal.py run " + j["id"] + "\n# 2. solve"))
        n += 1
    print(f"rebuilt {n} repro.sh files")
    return 0


def cmd_sby(a, cfg):
    """Regenerate build/<job>/job.sby for every smtbmc job from the staged RTL of the last run."""
    n = 0
    for j in cfg["jobs"]:
        wd = BUILD / j["id"]
        staged = [wd / "rtl" / Path(f).name for f in j["files"]]
        if not all(p.exists() for p in staged):
            continue
        t = sby_text(j, staged)
        if t:
            (ROOT / "reports/repro" / j["id"]).mkdir(parents=True, exist_ok=True)
            (ROOT / "reports/repro" / j["id"] / "job.sby").write_text(t)
            n += 1
    print(f"regenerated {n} job.sby files")
    return 0


def cmd_stamp(a, cfg):
    """Record input hashes for results produced before hash recording existed, ONLY if every input file is older
    than the job's start time (result mtime - duration). Marked `inputs_stamped: mtime-verified` in the result."""
    jobs = {j["id"]: j for j in cfg["jobs"]}
    n = 0
    for f in sorted((REPORTS / "results").glob("*.json")):
        if f.stem in ("mutation_results", "assumption_sensitivity"):
            continue
        r = jload(f)
        if r.get("inputs") or r["id"] not in jobs:
            continue
        j = jobs[r["id"]]
        start = f.stat().st_mtime - float(r.get("seconds", 0))
        hs = input_hashes(j)
        paths = [(VENDOR / k) if k.startswith(("albion_p90", "citadel_p89")) else ROOT / k for k in hs]
        newer = [str(p.relative_to(ROOT)) for p in paths if p.stat().st_mtime > start]
        if newer:
            print(f"  NOT stamped {r['id']}: changed after start: {newer}")
            continue
        r["inputs"] = hs
        r["inputs_stamped"] = "mtime-verified"
        jdump(r, f)
        n += 1
        print(f"  stamped {r['id']}")
    return 0


def cmd_selfcheck(a, cfg):
    bad = verify_vendor()
    print("vendor RTL hashes:", "OK" if not bad else f"MISMATCH {bad}")
    tools = {"yosys": tool_version(["yosys", "-V"]), "yosys-smtbmc": shutil.which("yosys-smtbmc"), "yosys-abc": shutil.which("yosys-abc"),
             "z3": tool_version(["z3", "--version"]), "cvc5": tool_version(["cvc5", "--version"]), "sby": shutil.which("sby") or "NOT INSTALLED"}
    for k, v in tools.items():
        print(f"  {k:14s} {v}")
    props = set(cfg["props"])
    used = set()
    for j in cfg["jobs"]:
        used |= set(j.get("props", []))
    print("jobs:", len(cfg["jobs"]), " property catalogue:", len(props), " mutants:", len(cfg["mutants"]))
    return 1 if bad else 0


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sp = ap.add_subparsers(dest="cmd", required=True)
    r = sp.add_parser("run", help="run proof jobs")
    r.add_argument("jobs", nargs="*", default=[])
    r.add_argument("--tag", help="run jobs carrying this tag (smoke|full|cover|slow)")
    r.add_argument("-j", dest="jobs_par", type=int, default=max(1, (os.cpu_count() or 2)))
    r.add_argument("--no-isolate", action="store_true")
    r.add_argument("--drop", action="append", help="drop an assumption label (e.g. S_MASTER_1PO)")
    r.add_argument("--solver")
    r.add_argument("--depth", type=int)
    m = sp.add_parser("mutate", help="run the mutation campaign")
    m.add_argument("ids", nargs="*", default=["all"])
    m.add_argument("--verify", action="store_true", help="re-run each killed mutant with ONLY its designed detector(s) enabled")
    m.add_argument("-j", dest="jobs_par", type=int, default=max(1, (os.cpu_count() or 2)))
    s = sp.add_parser("sensitivity", help="assumption necessity sweep")
    s.add_argument("jobs", nargs="*", default=["all"])
    sp.add_parser("list")
    sp.add_parser("selfcheck")
    sp.add_parser("stamp", help="record input hashes for old results whose inputs are provably unchanged")
    sp.add_parser("repro", help="rebuild reports/repro/<job>/repro.sh from recorded commands")
    sp.add_parser("sby", help="regenerate build/<job>/job.sby (never executed in the shipped results)")
    a = ap.parse_args()
    cfg = load_cfg()
    rc = {"run": cmd_run, "mutate": cmd_mutate, "list": cmd_list, "sensitivity": cmd_sensitivity, "selfcheck": cmd_selfcheck, "stamp": cmd_stamp, "sby": cmd_sby, "repro": cmd_repro}[a.cmd](a, cfg)
    sys.exit(rc or 0)


if __name__ == "__main__":
    main()
