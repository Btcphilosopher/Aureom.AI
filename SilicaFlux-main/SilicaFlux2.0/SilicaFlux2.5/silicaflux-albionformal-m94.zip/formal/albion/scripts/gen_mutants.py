#!/usr/bin/env python3
"""Generates mutants/mutants.json and verifies every pattern occurs exactly once in the vendored RTL.
Each mutant is a CONTROLLED, SINGLE-POINT bug injected into a copy of the RTL (the vendored file is never
modified). `expect_detect` lists the properties that are designed to catch it; `kind` classifies the bug.
A mutant that survives must carry a `waiver` explaining why it cannot be seen by the bounded detector run."""
import json, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
A = "albion_p90/rtl/"
C = "citadel_p89/rtl/"
M = []
def m(id, module, job, file, old, new, desc, detect, kind="functional", depth=None, waiver=None):
    d = {"id": id, "module": module, "job": job, "file": file, "description": desc, "expect_detect": detect, "kind": kind}
    if isinstance(old, list):
        d["edits"] = [{"old": o, "new": n} for o, n in zip(old, new)]
    else:
        d["old"], d["new"] = old, new
    if depth: d["depth"] = depth
    if waiver: d["waiver"] = waiver
    M.append(d)

FAB = "FAB-NB2-NW2"; FF = A + "sf_albion_datafabric.sv"
m("FAB-M01-DMA-FWBANK", "sf_albion_datafabric", FAB, FF, "data_bank = is_sram && (bank >= FWB);", "data_bank = is_sram;",
  "DMA may reach firmware-private SRAM bank 0", ["FAB_DMA_NO_FW_BANK", "FAB_DENIED_NOT_FORWARDED"], "security")
m("FAB-M02-DOM0-HOSTMEM", "sf_albion_datafabric", FAB, FF, "if (dom == sf_albion_regs_pkg::DOM_FIRMWARE)        perm_ok[m] = data_bank;",
  "if (dom == sf_albion_regs_pkg::DOM_FIRMWARE)        perm_ok[m] = data_bank || is_host;", "DMA domain 0 may reach host memory", ["FAB_DMA_DOM0_NO_HOST"], "security")
m("FAB-M03-DOM1-WINDOW", "sf_albion_datafabric", FAB, FF, "else if (dom == sf_albion_regs_pkg::DOM_HOST_ADMIN) perm_ok[m] = 1'b0;",
  "else if (dom == sf_albion_regs_pkg::DOM_HOST_ADMIN) perm_ok[m] = (data_bank || is_host) && win_hit;", "DMA in HOST_ADMIN domain permitted via a window", ["FAB_DMA_DOM1_DENIED"], "security")
m("FAB-M04-NO-WINDOW-CHECK", "sf_albion_datafabric", FAB, FF, "else                                                 perm_ok[m] = (data_bank || is_host) && win_hit;",
  "else                                                 perm_ok[m] = (data_bank || is_host);", "tenant DMA permitted without a window", ["FAB_DMA_WINDOW_COVERED"], "security")
m("FAB-M05-LIMIT-OFF-BY-3", "sf_albion_datafabric", FAB, FF, "({1'b0, aw} + 33'd3 <= {1'b0, win_limit[w*32 +: 32]}))", "({1'b0, aw} <= {1'b0, win_limit[w*32 +: 32]}))",
  "window upper bound checked on the first byte only (word may straddle the limit)", ["FAB_DMA_WINDOW_COVERED"], "security")
m("FAB-M06-RW-SWAPPED", "sf_albion_datafabric", FAB, FF, "(we ? at[2] : at[1])", "(we ? at[1] : at[2])", "window read/write permission bits swapped", ["FAB_DMA_WINDOW_COVERED"], "security")
m("FAB-M07-VALID-IGNORED", "sf_albion_datafabric", FAB, FF, "if (at[0] && (at[11:8] == dom) && (we ? at[2] : at[1]) &&", "if ((at[11:8] == dom) && (we ? at[2] : at[1]) &&",
  "window valid bit ignored (invalidated windows still grant)", ["FAB_DMA_WINDOW_COVERED"], "security")
m("FAB-M08-HOST-SRAM-NOBOOT", "sf_albion_datafabric", FAB, FF, "(is_sram && boot_mode);", "(is_sram);", "host reaches SRAM outside boot mode", ["FAB_HOST_POLICY"], "security")
m("FAB-M09-HOST-WRITE-TELEM", "sf_albion_datafabric", FAB, FF, "(is_mmio && !we && ((page == sf_albion_regs_pkg::PAGE_TELEM) || (page == sf_albion_regs_pkg::PAGE_RAS))) ||",
  "(is_mmio && ((page == sf_albion_regs_pkg::PAGE_TELEM) || (page == sf_albion_regs_pkg::PAGE_RAS))) ||", "host may WRITE telemetry/RAS pages", ["FAB_HOST_POLICY"], "security")
m("FAB-M10-MMIO-ALIAS", "sf_albion_datafabric", FAB, FF, "is_mmio = (a[31:16] == 16'h4000);", "is_mmio = (a[31:20] == 12'h400);", "MMIO decode too wide (aliases 1 MiB)", ["FAB_NO_INVALID_ROUTE"], "decode")
m("FAB-M11-SRAM-OFF-BY-ONE", "sf_albion_datafabric", FAB, FF, "is_sram = {1'b0, a} < SRAM_BYTES;", "is_sram = {1'b0, a} <= SRAM_BYTES;", "first byte past SRAM decodes to SRAM (aliasing)", ["FAB_NO_INVALID_ROUTE"], "decode")
m("FAB-M12-READY-IGNORES-SLAVE", "sf_albion_datafabric", FAB, FF, "m_req_ready[m] = dec_ok[m] && gnt_valid[s] && (32'(gnt_id[s*2 +: 2]) == m) && s_req_ready[s];",
  "m_req_ready[m] = dec_ok[m] && gnt_valid[s] && (32'(gnt_id[s*2 +: 2]) == m);", "master sees ready while the slave is not ready (request lost/duplicated)", ["FAB_HANDSHAKE_1TO1"], "protocol")
m("FAB-M13-ID-ZERO", "sf_albion_datafabric", FAB, FF, "s_req_id[s*2 +: 2]       = gnt_id[s*2 +: 2];", "s_req_id[s*2 +: 2]       = 2'd0;", "slave request carries master id 0 always", ["FAB_TXN_ID_VALID", "FAB_REQ_INTEGRITY"], "protocol")
m("FAB-M14-DOMAIN-DROPPED", "sf_albion_datafabric", FAB, FF, "s_req_domain[s*4 +: 4]   = m_req_domain[g*4 +: 4];", "s_req_domain[s*4 +: 4]   = 4'd0;",
  "request forwarded with domain 0 (FIRMWARE): domain association lost", ["FAB_REQ_INTEGRITY"], "security")
m("FAB-M15-ERRCODE-SWAP", "sf_albion_datafabric", FAB, FF, "err_code_q[m*3 +: 3] <= dec_ok[m] ? sf_albion_regs_pkg::FE_PERM : sf_albion_regs_pkg::FE_DECERR;",
  "err_code_q[m*3 +: 3] <= dec_ok[m] ? sf_albion_regs_pkg::FE_DECERR : sf_albion_regs_pkg::FE_PERM;", "PERM/DECERR codes swapped in local error response", ["FAB_RSP_LOCAL_ERROR"])
m("FAB-M16-LOCAL-RSP-LOST", "sf_albion_datafabric", FAB, FF, "m_rsp_valid[m]          = err_q[m];", "m_rsp_valid[m]          = 1'b0;", "local error response never delivered", ["FAB_RSP_LOCAL_ERROR"], "protocol")
m("FAB-M17-RSP-BROADCAST", "sf_albion_datafabric", FAB, FF, "if (s_rsp_valid[s] && (32'(s_rsp_id[s*2 +: 2]) == m)) begin", "if (s_rsp_valid[s]) begin",
  "slave response delivered to every master", ["FAB_RSP_NO_SPURIOUS", "FAB_RSP_ONE_SOURCE"], "protocol")
m("FAB-M18-VIOL-DECERR", "sf_albion_datafabric", FAB, FF, "if (err_now[m] && dec_ok[m]) begin", "if (err_now[m]) begin", "decode errors reported as permission violations", ["FAB_VIOL_REPORT"])
m("FAB-M19-PERMERR-STALLS", "sf_albion_datafabric", FAB, FF, "err_now[m] = m_req_valid[m] && !(dec_ok[m] && perm_ok[m]);", "err_now[m] = m_req_valid[m] && !dec_ok[m];",
  "permission-denied request is neither forwarded nor answered (master hangs)", ["FAB_LOCAL_ERR_ACCEPTED"], "protocol")
m("FAB-M20-RR-STUCK", "sf_albion_datafabric", "FAB-ARB-NB4-NW2", FF, "rr_ptr[s*2 +: 2] <= gnt_id[s*2 +: 2] + 2'd1;", "rr_ptr[s*2 +: 2] <= gnt_id[s*2 +: 2];",
  "round-robin pointer does not advance (starvation)", ["FAB_ARB_BOUNDED_WAIT"], "fairness", depth=10)

SF = A + "sf_albion_sram_bank.sv"; SJ = "SRAM-W8-IND"
m("SRAM-M01-PARTIAL-FULLWRITE", "sf_albion_sram_bank", SJ, SF, "m_we    = req_we && (req_wstrb == 4'hF);   // partial writes read first", "m_we    = req_we;",
  "partial write overwrites the whole word (unwritten bytes destroyed)", ["SRAM_WRITE_ENABLE_LEGAL", "SRAM_READ_MATCHES_MODEL"])
m("SRAM-M02-STROBE-INVERTED", "sf_albion_sram_bank", SJ, SF, "merged[b*8 +: 8] = s1_wstrb[b] ? s1_wdata[b*8 +: 8] : dec_data[b*8 +: 8];", "merged[b*8 +: 8] = s1_wstrb[b] ? dec_data[b*8 +: 8] : s1_wdata[b*8 +: 8];",
  "RMW merge uses inverted byte strobes", ["SRAM_READ_MATCHES_MODEL"])
m("SRAM-M03-ACCEPT-DURING-SCRUB", "sf_albion_sram_bank", SJ, SF, "assign req_ready = init_done && !(s1_valid && s1_rmw);", "assign req_ready = !(s1_valid && s1_rmw);",
  "bank accepts traffic before the scrub finished", ["SRAM_NO_ACCEPT_DURING_SCRUB", "SRAM_READY_GATING"], "security")
m("SRAM-M04-SCRUB-SHORT", "sf_albion_sram_bank", SJ, SF, "if (init_cnt == AW'(WORDS - 1)) init_done <= 1'b1;", "if (init_cnt == AW'(WORDS - 2)) init_done <= 1'b1;",
  "scrub ends one word early: last word keeps the previous tenant's data", ["SRAM_SCRUB_BOUNDED", "SRAM_READ_MATCHES_MODEL"], "security")
m("SRAM-M05-SCRUB-ONES", "sf_albion_sram_bank", SJ, SF, "      enc_in  = 32'h0;\n      m_wdata = enc_out;", "      enc_in  = 32'hFFFF_FFFF;\n      m_wdata = enc_out;",
  "scrub writes all-ones instead of zero", ["SRAM_READ_MATCHES_MODEL", "SRAM_UNWRITTEN_BYTES_STABLE"])
m("SRAM-M06-RSPID-ZERO", "sf_albion_sram_bank", SJ, SF, "assign rsp_id    = s1_id;", "assign rsp_id    = 2'd0;", "response id always 0", ["SRAM_RSP_MATCH"], "protocol")
m("SRAM-M07-RMW-WRONG-ADDR", "sf_albion_sram_bank", SJ, SF, "      m_addr  = s1_word;", "      m_addr  = req_word;", "RMW commit writes to the CURRENT request's word", ["SRAM_WRITE_ENABLE_LEGAL"])
m("SRAM-M08-WRITE-RSP-LEAK", "sf_albion_sram_bank", SJ, SF, "assign rsp_rdata = s1_we ? 32'h0 : dec_data;", "assign rsp_rdata = dec_data;", "write response returns stored data", ["SRAM_RSP_MATCH"], "security")
m("SRAM-M09-RMW-NEVER", "sf_albion_sram_bank", SJ, SF, "s1_rmw    <= req_we && (req_wstrb != 4'hF);", "s1_rmw    <= 1'b0;", "partial write never committed", ["SRAM_READ_MATCHES_MODEL"])
m("SRAM-M10-RESET-KEEPS-INIT", "sf_albion_sram_bank", SJ, SF, "      init_done <= 1'b0;\n      init_cnt  <= '0;", "      init_done <= init_done;\n      init_cnt  <= '0;",
  "reset does not restart the scrub (previous tenant's data survives reset)", ["SRAM_RESET_STATE"], "security")
m("SRAM-M11-UE-STILL-WRITES", "sf_albion_sram_bank", SJ, SF, "m_en    = !dec_ue;", "m_en    = 1'b1;", "RMW commits even when the old word is uncorrectable",
  ["(ECC property, not in this suite)"], "functional", waiver="Only observable with fault injection; the data-correctness jobs assume SRAM_NO_INJ, and the ECC bank-level job (SRAM-ECC) is NOT implemented. Listed in unresolved.json (U-SRAM-ECC).")
m("SRAM-M12-MACRO-ADDR-FLIP", "sf_albion_sram_macro", "SRAM-MACRO-IND", A + "sf_albion_sram_macro.sv", "else    rdata     <= mem[addr];", "else    rdata     <= mem[addr ^ 1];",
  "macro read address bit 0 flipped", ["SRAM_MACRO_CONTRACT"], "functional", depth=8)

DF = A + "sf_albion_dma.sv"; DJ = "DMA-D4-BMC"
m("DMA-M01-LEN-LIMIT", "sf_albion_dma", DJ, DF, "(r_len > sf_albion_regs_pkg::DMA_MAX_LEN)", "(r_len > (sf_albion_regs_pkg::DMA_MAX_LEN << 1))", "DMA_MAX_LEN doubled", ["DMA_VALIDATION_EXACT"], "security")
m("DMA-M02-UNALIGNED-LEN", "sf_albion_dma", DJ, DF, "(r_len[1:0] != 2'b00) ||", "1'b0 ||", "LEN not a multiple of 4 accepted", ["DMA_VALIDATION_EXACT"])
m("DMA-M03-DST-WRAP", "sf_albion_dma", DJ, DF, "(r_dst[1:0] != 2'b00) || dst_end[32] ||", "(r_dst[1:0] != 2'b00) ||", "destination range wrapping 2^32 accepted", ["DMA_VALIDATION_EXACT"], "security")
m("DMA-M04-RD-STRIDE", "sf_albion_dma", DJ, DF, "assign rd_req_addr  = r_src + {rd_idx[29:0], 2'b00};", "assign rd_req_addr  = r_src + {rd_idx[28:0], 3'b000};", "read beats stride 8 bytes", ["DMA_RD_BEAT_BOUNDS"], "functional")
m("DMA-M05-WR-OFF-BY-ONE", "sf_albion_dma", DJ, DF, "assign wr_req_addr  = r_dst + {wr_idx[29:0], 2'b00};", "assign wr_req_addr  = r_dst + {wr_idx[29:0], 2'b00} + 32'd4;",
  "write beats shifted one word (last beat lands past the destination range)", ["DMA_WR_BEAT_BOUNDS"], "security")
m("DMA-M06-EXTRA-BEAT", "sf_albion_dma", DJ, DF, "(wr_idx < nwords) &&\n                        (!wr_out || wr_rsp_valid);", "(wr_idx <= nwords) &&\n                        (!wr_out || wr_rsp_valid);",
  "one extra write beat beyond LEN", ["DMA_WR_BEAT_BOUNDS", "DMA_COUNTERS_VALID"], "security")
m("DMA-M07-BYTES-DOUBLE", "sf_albion_dma", DJ, DF, "r_bytes    <= r_bytes + 32'd4;", "r_bytes    <= r_bytes + 32'd8;", "BYTES_DONE advances 8 per beat", ["DMA_COUNTERS_VALID", "DMA_ACCOUNTING_OK"])
m("DMA-M08-BUSY-WRITE-OK", "sf_albion_dma", DJ, DF, "else if (busy && rg_off != sf_albion_regs_pkg::DMA_CTRL)\n        rg_err = sf_albion_regs_pkg::FE_SLVERR;", "else if (1'b0)\n        rg_err = sf_albion_regs_pkg::FE_SLVERR;",
  "writes to descriptor registers during a transfer are silently reported OK", ["DMA_BUSY_WRITE_REJECTED"])
m("DMA-M09-DESC-NOT-FROZEN", "sf_albion_dma", DJ, DF, ["else if (busy && rg_off != sf_albion_regs_pkg::DMA_CTRL)\n        rg_err = sf_albion_regs_pkg::FE_SLVERR;", "if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK && !busy) begin"],
  ["else if (1'b0)\n        rg_err = sf_albion_regs_pkg::FE_SLVERR;", "if (rg_we && rg_err == sf_albion_regs_pkg::FE_OK) begin"],
  "descriptor registers can be rewritten mid-transfer (validated limits bypassed)", ["DMA_DESCRIPTOR_FROZEN", "DMA_DESCRIPTOR_LIMITS", "DMA_WR_BEAT_BOUNDS"], "security")
m("DMA-M10-LATER-ERR-OVERRIDES", "sf_albion_dma", DJ, DF, "if (!err_found || rd_rsp_idx < err_idx) begin", "if (1'b1) begin", "a later read failure overwrites the first failing beat", ["DMA_ACCOUNTING_ERR"], "functional", depth=16)
m("DMA-M11-PREFETCH-OVERFLOW", "sf_albion_dma", DJ, DF, "assign rd_room      = (32'(f_count) + 32'(rd_out)) < 32'(DEPTH);", "assign rd_room      = (32'(f_count) + 32'(rd_out)) <= 32'(DEPTH);",
  "prefetch may over-commit the FIFO by one", ["DMA_FIFO_BOUNDS"], "functional")
m("DMA-M12-RESET-KEEPS-BUSY", "sf_albion_dma", DJ, DF, "busy <= 1'b0; done <= 1'b0; error <= 1'b0;", "busy <= busy; done <= 1'b0; error <= 1'b0;", "reset does not stop a running transfer", ["DMA_RESET_STATE"], "security")
m("DMA-M13-BADPARAM-CODE", "sf_albion_dma", DJ, DF, "r_err_code <= sf_albion_regs_pkg::DMAE_BADPARAM;", "r_err_code <= sf_albion_regs_pkg::DMAE_NONE;", "bad descriptor rejected with no error code", ["DMA_BADPARAM_REJECTED"], "functional")
m("DMA-M14-FAILED-READ-PUSHED", "sf_albion_dma", DJ, DF, "assign f_push       = rd_rsp_valid && (rd_rsp_err == sf_albion_regs_pkg::FE_OK) && !stop_wr && !stop_rd;", "assign f_push       = rd_rsp_valid && !stop_wr && !stop_rd;",
  "data of a FAILED read is pushed and later written to the destination", ["DMA_ACCOUNTING_ERR"], "security", depth=16)

FF2 = A + "sf_albion_fifo.sv"; FJ = "FIFO-D4-W8-IND"
m("FIFO-M01-FULL-EARLY", "sf_albion_fifo", FJ, FF2, "assign full    = (count == CW'(DEPTH));", "assign full    = (count == CW'(DEPTH - 1));", "full flag asserted one entry early", ["FIFO_FLAGS", "FIFO_COUNT_MODEL"])
m("FIFO-M02-OVERFLOW", "sf_albion_fifo", FJ, FF2, "assign do_push = push && !full;", "assign do_push = push;", "push accepted when full (overflow)", ["FIFO_COUNT_BOUND", "FIFO_ORDER"])
m("FIFO-M03-UNDERFLOW", "sf_albion_fifo", FJ, FF2, "assign do_pop  = pop && !empty;", "assign do_pop  = pop;", "pop accepted when empty (underflow)", ["FIFO_COUNT_BOUND", "FIFO_COUNT_MODEL"])
m("FIFO-M04-HEAD-WP", "sf_albion_fifo", FJ, FF2, "assign head    = mem[rp];", "assign head    = mem[wp];", "head reads the write slot", ["FIFO_ORDER"])
m("FIFO-M05-WRAP-EARLY", "sf_albion_fifo", FJ, FF2, "inc = (p == PW'(DEPTH - 1)) ? '0 : p + 1'b1;", "inc = (p == PW'(DEPTH - 2)) ? '0 : p + 1'b1;", "pointer wraps one slot early", ["FIFO_ORDER"])

PF = A + "sf_albion_perm.sv"; PJ = "PERM-NW8-IND"
m("PERM-M01-RESET-KEEPS-WINDOWS", "sf_albion_perm", PJ, PF, "win_attr_o  <= '0;      // all windows invalid after reset", "win_attr_o  <= win_attr_o;",
  "reset leaves windows valid (default-allow after reset)", ["PERM_RESET_DEFAULT_DENY"], "security", depth=6)
m("PERM-M02-ATTR-RESERVED", "sf_albion_perm", PJ, PF, "4'h8: win_attr_o[widx*12 +: 12]  <= {rg_wdata[11:8], 5'h0, rg_wdata[2:0]};", "4'h8: win_attr_o[widx*12 +: 12]  <= rg_wdata[11:0];",
  "reserved attribute bits stored", ["PERM_ATTR_RESERVED_ZERO", "PERM_WINDOW_MATCHES_SPEC"], depth=6)
m("PERM-M03-COUNT-WRAPS", "sf_albion_perm", PJ, PF, "if (viol_count != 32'hFFFF_FFFF) viol_count <= viol_count + 32'd1;", "viol_count <= viol_count + 32'd1;", "violation counter wraps instead of saturating", ["PERM_VIOL_COUNT_MATCHES_SPEC"],
  waiver="Differs from the original only after 2^32 violations; a bounded run cannot reach it. The unmutated property is PROVEN by k-induction (PERM-NW8-IND), which covers the saturating branch.")
m("PERM-M04-LOG-OVERWRITE", "sf_albion_perm", PJ, PF, "if (!viol_info[31]) begin", "if (1'b1) begin", "first-violation log overwritten by later violations", ["PERM_VIOL_LOG_MATCHES_SPEC", "PERM_VIOL_FIRST_STICKY"], depth=6)
m("PERM-M05-BASE-LIMIT-SWAP", "sf_albion_perm", PJ, PF, "4'h0: win_base_o[widx*32 +: 32]  <= rg_wdata;", "4'h0: win_limit_o[widx*32 +: 32] <= rg_wdata;", "base register write lands in limit", ["PERM_WINDOW_MATCHES_SPEC"], depth=6)

CJ = "CITP-AW8-DEV"; CF = C + "sf_citadel_permission.sv"
m("CITP-M01-WRITE-VIA-R", "sf_citadel_permission", CJ, CF, "if ((op_rd ? win_r_i[s*NW+k] : win_w_i[s*NW+k]) && (!a_instr || win_x_i[s*NW+k])) win_allow = 1'b1;", "if ((op_rd ? win_r_i[s*NW+k] : win_r_i[s*NW+k]) && (!a_instr || win_x_i[s*NW+k])) win_allow = 1'b1;",
  "WRITE permitted by a read-only window", ["CIT_WRITE_NEEDS_WRITE_RIGHT", "CIT_PERMIT_IMPLIES_SPEC"], "security", depth=2)
m("CITP-M02-LIMIT-UNCHECKED", "sf_citadel_permission", CJ, CF, "(last   <= win_limit_i[(s*NW+k)*AW +: AW])) begin", "(addr_i <= win_limit_i[(s*NW+k)*AW +: AW])) begin", "window end checked against the first byte, not the last", ["CIT_PERMIT_IMPLIES_SPEC"], "security", depth=2)
m("CITP-M03-BINDING-IGNORED", "sf_citadel_permission", CJ, CF, "wire dom_ok = dom_found && dom_bound && (dom_i != sf_albion_pkg::SF_DOM_INVALID);", "wire dom_ok = dom_found && (dom_i != sf_albion_pkg::SF_DOM_INVALID);",
  "port binding ignored: any port may claim any domain (spoofing)", ["CIT_SPOOFED_DOMAIN_DENIED", "CIT_ATTRIBUTION"], "security", depth=2)
m("CITP-M04-SUSPENDED-OK", "sf_citadel_permission", CJ, CF, "end else if (dom_state != sf_citadel_pkg::SF_CIT_DS_ACTIVE) begin", "end else if (dom_state == sf_citadel_pkg::SF_CIT_DS_INVALID) begin",
  "suspended / quarantined domains are permitted", ["CIT_PERMIT_IMPLIES_SPEC", "CIT_ATTRIBUTION"], "security", depth=2)
m("CITP-M05-WRAP-ALLOWED", "sf_citadel_permission", CJ, CF, "ovf      = len_zero ? 1'b0 : (sum[SW-1:AW] != '0);", "ovf      = 1'b0;", "address-range wrap not detected", ["CIT_NO_RANGE_WRAP", "CIT_PERMIT_IMPLIES_SPEC"], "security", depth=2)
m("CITP-M06-ISOLATION-IGNORED", "sf_citadel_permission", CJ, CF, "    if (port_isol) begin", "    if (1'b0) begin", "isolated port still permitted", ["CIT_ISOLATION_AND_LOCKDOWN"], "security", depth=2)
m("CITP-M07-LOCKDOWN-IGNORED", "sf_citadel_permission", CJ, CF, "end else if (lockdown_i && (dom_i != sf_albion_pkg::SF_DOM_ROOT) && (dom_i != sf_albion_pkg::SF_DOM_MGMT)) begin", "end else if (1'b0) begin",
  "safe-state lockdown ignored", ["CIT_ISOLATION_AND_LOCKDOWN"], "security", depth=2)
m("CITP-M08-PERMIT-ON-PERM", "sf_citadel_permission", CJ, CF, "assign permit_o   = (reason_o == sf_citadel_pkg::SF_CIT_R_OK);", "assign permit_o   = (reason_o == sf_citadel_pkg::SF_CIT_R_OK) || (reason_o == sf_citadel_pkg::SF_CIT_R_PERM);",
  "requests denied for PERM are permitted", ["CIT_PERMIT_STATUS_COUPLING", "CIT_PERMIT_IMPLIES_SPEC"], "security", depth=2)
m("CITP-M09-PRIV-ESCALATION", "sf_citadel_permission", CJ, CF, "end else if ((a_priv && !dom_priv_cap) || (a_secure && !dom_secure_cap)) begin", "end else if ((a_secure && !dom_secure_cap)) begin",
  "privileged-attribute claim above the domain's capability accepted", ["CIT_PERMIT_IMPLIES_SPEC"], "security", depth=2)
m("CITP-M10-DEVWRITE-VIA-READ", "sf_citadel_permission", CJ, CF, "end else if (!(op_rd ? dev_rd_ok : dev_wr_ok)) begin", "end else if (!(op_rd ? dev_rd_ok : dev_rd_ok)) begin", "device WRITE permitted with only read permission", ["CIT_WRITE_NEEDS_WRITE_RIGHT"], "security", depth=2)

GJ = "CITG-AW64-BMC"; GF = C + "sf_citadel_gate.sv"
m("CITG-M01-DENIED-FORWARDED", "sf_citadel_gate", GJ, GF, "assign t_req_valid_o = have_q && v_permit && !out_full;", "assign t_req_valid_o = have_q && !out_full;", "denied requests forwarded to the target", ["CIT_GATE_NO_BYPASS", "CIT_GATE_WRITE_NEEDS_RIGHT"], "security")
m("CITG-M02-FLUSH-IGNORED", "sf_citadel_gate", GJ, GF, "wire       v_permit    = base_permit && !flush_i;", "wire       v_permit    = base_permit;", "request still presented while the port is flushed", ["CIT_GATE_FLUSH_QUIET"], "security")
m("CITG-M03-STALE-VERDICT", "sf_citadel_gate", GJ, GF, "wire       base_permit = dec_q ? permit_q : chk_permit_i;", "wire       base_permit = permit_q;", "first evaluation reuses the previous request's verdict (never re-evaluates)", ["CIT_GATE_NO_BYPASS"], "availability",
  waiver="Fail-CLOSED availability bug, not a safety violation: permit_q resets to 0 and is only ever latched from a value derived from itself, so the mutated gate forwards NOTHING. No safety property can fail; detecting it needs a progress property (a permitted request is eventually forwarded), which is outside the safety scope (U-LIVENESS). Analysed, not ignored.")
m("CITG-M06-VERDICT-ALWAYS-PERMIT", "sf_citadel_gate", GJ, GF, "        permit_q <= v_permit;", "        permit_q <= 1'b1;", "latched verdict is always PERMIT: a denied request that has to wait behind an outstanding one is forwarded in a later cycle", ["CIT_GATE_NO_BYPASS", "CIT_GATE_WRITE_NEEDS_RIGHT"], "security", depth=12)
m("CITG-M04-VERDICT-INHERITED", "sf_citadel_gate", GJ, GF, "        dec_q  <= 1'b0;\n        req_q  <= m_req_i;", "        req_q  <= m_req_i;", "a new request inherits the latched verdict of the previous one (its commit pulse is suppressed; detected because the forwarded fields no longer match the monitor's snapshot)", ["CIT_GATE_DOMAIN_ASSOCIATION"], "security")
m("CITG-M05-DOMAIN-REWRITTEN", "sf_citadel_gate", GJ, GF, "assign t_req_o       = req_q;", "assign t_req_o       = req_q | (236'h1 << sf_albion_pkg::SF_REQ_DOM_LSB);", "forwarded request carries a different domain than the one checked", ["CIT_GATE_DOMAIN_ASSOCIATION"], "security")

TF = C + "sf_citadel_domain_table.sv"; TJ = "CITT-BMC"
m("CITT-M01-WINDOWS-SURVIVE-REVOKE", "sf_citadel_domain_table", TJ, TF, "end else if (we_revoke[s] || we_clrwin[s*NW+k]) begin", "end else if (we_clrwin[s*NW+k]) begin",
  "REVOKE leaves the slot's windows valid (a re-enrolled slot would inherit them: stale window use)", ["CIT_TBL_REVOKE_INVALIDATES"], "security", depth=8)
m("CITT-M02-ANYONE-CONFIGURES", "sf_citadel_domain_table", TJ, TF, "end else if (!(req_root || req_mgmt)) begin", "end else if (1'b0) begin", "unprivileged requesters may configure the policy", ["CIT_TBL_UNPRIVILEGED_REJECTED"], "security", depth=6)
m("CITT-M03-CFGEN-IGNORED", "sf_citadel_domain_table", TJ, TF, "    if (!cfg_en_i) begin\n      st_d = sf_citadel_pkg::SF_CIT_CS_NOT_AUTH;", "    if (1'b0) begin\n      st_d = sf_citadel_pkg::SF_CIT_CS_NOT_AUTH;",
  "configuration accepted although boot is not authorised", ["CIT_TBL_CFG_GATED"], "security", depth=6)
m("CITT-M04-EXCL-NEEDS-BOTH", "sf_citadel_domain_table", TJ, TF, "if ((slot_ext != j) && wv_q[j*NW+k] && (new_excl || wex_q[j*NW+k]) &&", "if ((slot_ext != j) && wv_q[j*NW+k] && (new_excl && wex_q[j*NW+k]) &&",
  "exclusive window may overlap another domain's non-exclusive window", ["CIT_TBL_EXCLUSIVE_DISJOINT"], "security", depth=8)
m("CITT-M05-BIND-ALL-AFTER-RESET", "sf_citadel_domain_table", TJ, TF, "        bind_q[p*NDOM +: NDOM] <= '0;\n      end else if (we_bind", "        bind_q[p*NDOM +: NDOM] <= '1;\n      end else if (we_bind",
  "every port bound to every domain after reset (default allow)", ["CIT_TBL_RESET_DEFAULT_DENY"], "security", depth=4)


SD = A + "sf_albion_secded.sv"
m("SEC-M01-NO-CORRECTION", "sf_albion_secded_dec", "SECDED-SINGLE", SD, "if (single && (s != 6'd0)) fixed[s] = ~pos[s];", "if (single && (s != 6'd0)) fixed[s] = pos[s];",
  "single-bit errors detected but never corrected", ["SECDED_SINGLE_CORRECTED"], "functional", depth=0)
m("SEC-M02-PARITY-BIT-DROPPED", "sf_albion_secded_enc", "SECDED-CLEAN", SD, "cw_o[38]   = ^pos[38:1];", "cw_o[38]   = 1'b0;", "overall parity bit of the encoder stuck at 0", ["SECDED_CLEAN_ROUNDTRIP"], "functional", depth=0)
m("SEC-M03-DOUBLE-UNDETECTED", "sf_albion_secded_dec", "SECDED-DOUBLE", SD, "ue_o = (!par && (s != 6'd0)) || (par && (s > 6'd38));", "ue_o = (par && (s > 6'd38));",
  "double-bit errors not flagged uncorrectable", ["SECDED_DOUBLE_DETECTED"], "functional", depth=0)

# ---- verify uniqueness ------------------------------------------------------------------------
bad = 0
for d in M:
    t = (ROOT / "vendor" / d["file"]).read_text()
    for e in (d.get("edits") or [{"old": d["old"]}]):
        n = t.count(e["old"])
        if n != 1:
            print(f"!! {d['id']}: pattern occurs {n}x: {e['old'][:70]!r}"); bad += 1
(ROOT / "mutants").mkdir(exist_ok=True)
json.dump({"mutants": M}, open(ROOT / "mutants/mutants.json", "w"), indent=1)
print(len(M), "mutants written;", bad, "pattern problems")
sys.exit(1 if bad else 0)
