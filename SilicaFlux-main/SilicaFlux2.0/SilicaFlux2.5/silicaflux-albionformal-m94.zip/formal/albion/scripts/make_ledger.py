#!/usr/bin/env python3
"""Builds the AlbionFormal proof ledger from the raw result files. NOTHING in the ledger is hand-written
except the catalogue texts (config/*.json): every status, depth, time, solver and counterexample reference
comes from reports/results/*.json produced by scripts/albion_formal.py.

Outputs: reports/PROOF_LEDGER.md  reports/proof_ledger.json  reports/proof_ledger.csv
"""
import csv
import hashlib
import json
import os
import platform
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "reports/results"
OUT = ROOT / "reports"


def jl(p, default=None):
    p = Path(p)
    return json.load(open(p)) if p.exists() else default


def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        h.update(f.read())
    return h.hexdigest()


def tool(cmd):
    try:
        o = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        return (o.stdout or o.stderr).strip().splitlines()[0]
    except Exception:
        return "unavailable"


CLASS_ORDER = ["PROVEN", "PROVEN-COND", "BOUNDED", "COVER-REACHED", "FAIL", "TIMEOUT", "VACUOUS", "ERROR", "STALE", "NOT-DETERMINED"]
CLASS_TEXT = {
    "PROVEN": "Unbounded proof, no environment assumption beyond reset/clock.",
    "PROVEN-COND": "Unbounded proof that depends on the listed environment/configuration assumptions.",
    "BOUNDED": "No counterexample up to the stated depth. NOT a proof for longer traces.",
    "FAIL": "Counterexample found.",
    "TIMEOUT": "Solver did not finish; no claim made.",
    "VACUOUS": "Assumptions contradictory; result meaningless.",
    "STALE": "A harness/RTL file changed after this result was produced; re-run required.",
    "NOT-DETERMINED": "Not decided in this run.",
}


def depth_text(r, v):
    st = v.get("status")
    if v.get("engine") == "abc-iprove":
        return "combinational: exhaustive over all inputs"
    if v.get("engine") == "abc-pdr":
        return f"IC3/PDR converged (frame {v.get('frames')})"
    if st in ("PROVEN", "PROVEN-COND"):
        k = v.get("k", r.get("depth"))
        base = f"k-induction k={k} (+BMC base {r.get('depth')})"
        xs = [c for c in r.get("cross_check", []) if c["verdict"] == "pass"]
        if xs:
            base += "; confirmed by " + ", ".join(c["solver"] for c in xs)
        return base
    if st == "BOUNDED":
        return f"BMC {v.get('depth', r.get('depth'))} cycles from reset" + (f" ({v['note']})" if v.get("note") else "")
    if st == "FAIL":
        return f"counterexample at step {v.get('step', r.get('fail_step'))}"
    if st == "TIMEOUT":
        return "timeout"
    return ""


def main():
    jobs = {j["id"]: j for j in jl(ROOT / "config/jobs.json")["jobs"]}
    cat = jl(ROOT / "config/properties.json", {})
    asm = jl(ROOT / "config/assumptions.json", {})
    unres = jl(ROOT / "config/unresolved.json", [])
    mut = jl(RES / "mutation_results.json", [])
    sens = jl(RES / "assumption_sensitivity.json", [])
    env = jl(OUT / "environment.json", {})
    results = {}
    for f in sorted(RES.glob("*.json")):
        if f.stem in ("mutation_results", "assumption_sensitivity"):
            continue
        results[f.stem] = jl(f)

    # ---- staleness: compare recorded input hashes with the files on disk ------------------------------------
    def stale(r):
        for rel, h in (r.get("inputs") or {}).items():
            p = ROOT / rel if not rel.startswith("albion_p90") and not rel.startswith("citadel_p89") else ROOT / "vendor" / rel
            if not p.exists() or sha(p) != h:
                return True
        return not r.get("inputs")

    # ---- kill matrix: which properties killed how many mutants -------------------------------------------------
    kills = {}
    for m in mut:
        for k in m.get("killed_by", []):
            kills.setdefault(k[2:] if k[:2] in ("A_", "L_") else k, []).append(m["id"])

    rows = []
    covers = []
    for jid, r in results.items():
        j = jobs.get(jid, {})
        is_stale = stale(r)
        asm_list = j.get("assumptions", [])
        solver = r.get("engine") or j.get("solver", "")
        if r.get("solver") and r.get("engine", "").startswith("smtbmc"):
            solver = f"{r['engine']}"
        for pid, v in sorted(r.get("props", {}).items()):
            base = pid[2:] if pid.startswith("L_") else pid
            meta = cat.get(pid) or cat.get(base) or {}
            st = "STALE" if is_stale else v.get("status", "?")
            rows.append({
                "job": jid, "module": meta.get("module", ""), "property": pid, "requirement": meta.get("requirement", ""),
                "statement": meta.get("text", ""), "kind": meta.get("kind", ""), "lemma": bool(v.get("lemma") or pid.startswith("L_")),
                "assumptions": asm_list, "solver": solver, "depth": depth_text(r, v), "result": st, "seconds": r.get("seconds"),
                "parameters": r.get("params", {}), "reproduction": r.get("repro", ""),
                "cross_check": r.get("cross_check", []), "note": v.get("note", ""),
                "killed_mutants": kills.get(pid, []), "counterexample": r.get("cex_reports", []) if st == "FAIL" else [],
            })
        for cid, v in sorted(r.get("covers", {}).items()):
            meta = cat.get(cid, {})
            covers.append({"job": jid, "cover": cid, "result": "STALE" if is_stale else v["status"], "step": v.get("step"),
                           "assumptions": asm_list, "parameters": r.get("params", {}), "reproduction": r.get("repro", ""),
                           "text": meta.get("text", "")})

    # ---- summaries -----------------------------------------------------------------------------------------------------------
    claim_rows = [x for x in rows if not x["lemma"]]
    count = {}
    for x in claim_rows:
        count[x["result"]] = count.get(x["result"], 0) + 1
    by_prop = {}
    for x in claim_rows:
        by_prop.setdefault((x["module"], x["property"]), []).append(x)
    rank = {c: i for i, c in enumerate(CLASS_ORDER)}
    best = []
    for (mod, pid), xs in sorted(by_prop.items()):
        res = sorted({x["result"] for x in xs}, key=lambda c: rank.get(c, 99))
        strongest = res[0]
        fails = [x for x in xs if x["result"] == "FAIL"]
        best.append({"module": mod, "property": pid, "requirement": xs[0]["requirement"], "best": strongest,
                     "all": res, "jobs": sorted({x["job"] for x in xs}), "mutants_killed": len(xs[0]["killed_mutants"]), "failing": bool(fails)})
    cov_n = {}
    for c in covers:
        cov_n[c["result"]] = cov_n.get(c["result"], 0) + 1
    killed = sum(1 for m in mut if m["killed"])
    waived = sum(1 for m in mut if (not m["killed"]) and m.get("waiver"))
    surv = [m for m in mut if (not m["killed"]) and not m.get("waiver")]

    ledger = {"generated": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "environment": env,
              "summary": {"claim_rows": len(claim_rows), "lemma_rows": len(rows) - len(claim_rows), "by_result": count, "cover_rows": len(covers),
                          "cover_by_result": cov_n, "mutants": len(mut), "mutants_killed": killed, "mutants_waived": waived, "mutants_survived_unwaived": len(surv)},
              "rows": rows, "covers": covers, "property_summary": best, "mutation": mut, "assumption_sensitivity": sens, "unresolved": unres}
    json.dump(ledger, open(OUT / "proof_ledger.json", "w"), indent=1)

    with open(OUT / "proof_ledger.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["job", "rtl_module", "property", "requirement", "kind", "lemma", "assumptions", "solver", "proof_depth", "result", "seconds", "parameters", "mutants_killed", "reproduction"])
        for x in rows:
            w.writerow([x["job"], x["module"], x["property"], x["requirement"], x["kind"], x["lemma"], " ".join(x["assumptions"]), x["solver"], x["depth"], x["result"],
                        x["seconds"], json.dumps(x["parameters"]), " ".join(x["killed_mutants"]), x["reproduction"]])

    # ---- markdown --------------------------------------------------------------------------------------------------------------
    L = []
    A = L.append
    A("# AlbionFormal Proof Ledger (SilicaFlux Module 94)")
    A("")
    A(f"Generated {ledger['generated']} from `reports/results/*.json`. Every row below is a machine result; nothing is asserted by hand.")
    A("")
    A("## 0. How to read this ledger")
    A("")
    A("| Result class | Meaning |")
    A("|---|---|")
    for c in ["PROVEN", "PROVEN-COND", "BOUNDED", "FAIL", "TIMEOUT", "VACUOUS", "STALE"]:
        A(f"| **{c}** | {CLASS_TEXT[c]} |")
    A("| **COVER-REACHED / COVER-UNREACHED** | A witness trace exists / does not exist under the same environment (vacuity evidence, section 4). |")
    A("| **Unproven / not claimed** | Listed in section 7; they have no row above because no proof was produced. |")
    A("")
    A("`Proof depth`: *k-induction k=N* = the property (with helper lemmas) holds in every state reachable in N steps and is inductive, i.e. holds for ALL time; the BMC base case covers N cycles from reset. *BMC N cycles* = exhaustive over all input sequences of length N starting from reset, nothing more.")
    A("")
    A("## 1. Environment and provenance")
    A("")
    for k, v in (env or {}).items():
        A(f"* **{k}**: {v}")
    A("")
    A("## 2. Summary")
    A("")
    s = ledger["summary"]
    A(f"* Claim rows: **{s['claim_rows']}** (+ {s['lemma_rows']} helper-lemma rows). By result: " + ", ".join(f"{k}={v}" for k, v in sorted(count.items(), key=lambda kv: rank.get(kv[0], 99))))
    A(f"* Cover rows: {s['cover_rows']} ({', '.join(f'{k}={v}' for k, v in cov_n.items())})")
    A(f"* Mutation campaign: **{killed} of {len(mut)}** mutants killed; {waived} survive with a documented waiver; **{len(surv)} unwaived survivors**.")
    A("")
    A("| Module | Property | Requirement | Strongest result | Other results | Jobs | Mutants killed |")
    A("|---|---|---|---|---|---|---|")
    for b in best:
        A(f"| {b['module']} | `{b['property']}` | {b['requirement']} | **{b['best']}** | {', '.join(c for c in b['all'] if c != b['best']) or '-'} | {len(b['jobs'])} | {b['mutants_killed']} |")
    A("")
    A("## 3. Proof ledger (one row per property per proof job)")
    A("")
    A("Columns: RTL module | property | assumptions | solver | proof depth | result | reproduction command. Helper lemmas are listed after the claims of each job. Parameters are the job's `chparam` values.")
    A("")
    cur = None
    for x in sorted(rows, key=lambda x: (x["job"], x["lemma"], x["property"])):
        if x["job"] != cur:
            cur = x["job"]
            j = jobs.get(cur, {})
            r = results[cur]
            A(f"### {cur}: {j.get('title', '')}")
            A("")
            A(f"`{r.get('repro', '')}`   parameters `{json.dumps(r.get('params', {}))}`   job time {r.get('seconds')} s   cross-check: " +
              (", ".join(f"{c['solver']}={c['verdict']}" for c in r.get("cross_check", [])) or "none"))
            A("")
            A("| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |")
            A("|---|---|---|---|---|---|---|")
        a_txt = ", ".join(x["assumptions"]) or "-"
        pname = ("*lemma* " if x["lemma"] else "") + f"`{x['property']}`"
        A(f"| {x['module']} | {pname} | {a_txt} | {x['solver']} | {x['depth']} | **{x['result']}** | `scripts/albion_formal.py run {x['job']}` |")
    A("")
    A("The *reproduction command* of every row is the command printed under its job heading; the raw tool invocations are written to `build/<job>/repro.sh` by that command.")
    A("")
    A("## 4. Cover properties (vacuity detection: the environment really permits the behaviours the proofs talk about)")
    A("")
    A("| Job | Cover | Result | First step | What it shows |")
    A("|---|---|---|---|---|")
    for c in covers:
        A(f"| {c['job']} | `{c['cover']}` | **{c['result']}** | {c['step'] if c['step'] is not None else '-'} | {c['text'] or ''} |")
    A("")
    A("## 5. Assumption register")
    A("")
    A("| Assumption | Category | Used by jobs | Discharged by | Sensitivity: does dropping it break a property? (bounded BMC run) | Text / risk |")
    A("|---|---|---|---|---|---|")
    used = {}
    for jid, j in jobs.items():
        for a in j.get("assumptions", []):
            used.setdefault(a, []).append(jid)
    sens_map = {}
    for row in sens:
        for a, v in row["assumptions"].items():
            sens_map.setdefault(a, []).append((row["job"], v["needed"], v.get("violated_when_dropped")))
    for a, d in asm.items():
        sm = sens_map.get(a)
        strip = lambda x: x[2:] if x[:2] == "A_" else x
        need = "n/a (structural / informational)" if d["category"] in ("structural", "informational") else ("not measured (configuration / scope choice, not an assume cell, or no sensitivity job)" if not sm else
               "; ".join(f"{jn}: {'YES - dropping it breaks ' + ','.join(strip(x) for x in (viol or [])[:3]) if nd else 'no violation found in a BOUNDED run without it (NOT proof that it is redundant)'}" for jn, nd, viol in sm))
        A(f"| `{a}` | {d['category']} | {len(used.get(a, []))} | {d.get('discharged_by') or 'not discharged'} | {need} | {d['text']} **Risk:** {d['risk']} |")
    A("")
    A("## 6. Mutation campaign (controlled bugs: do the assertions detect real violations?)")
    A("")
    A(f"{killed} of {len(mut)} mutants killed. A mutant is a single-point bug injected into a COPY of the RTL; it is killed when the detector job (BMC) finds a counterexample. Counterexample reports: `reports/mutation/cex/`.")
    A("")
    A("| Mutant | Module | Class | Bug | Detector job | Result | Violated assertions (first failing step) | Designed detector fired | Step | Reproduce |")
    A("|---|---|---|---|---|---|---|---|---|---|")
    for m in sorted(mut, key=lambda m: m["id"]):
        res = "KILLED" if m["killed"] else ("SURVIVED (waived)" if m.get("waiver") else "**SURVIVED**")
        kb = {x[2:] if x[:2] in ("A_", "L_") else x for x in m["killed_by"]}
        exp = [e for e in m.get("expected_detectors", []) if not e.startswith("(")]
        conf = m.get("detectors_confirmed")
        fired = ((f"{len(conf)}/{len(exp)} confirmed in isolation" if conf is not None and 'detectors_confirmed' in m and m.get("detectors_confirmed") is not None and (conf or exp) else f"{len(kb & set(exp))}/{len(exp)} (in first model)")
                 if exp and m["killed"] else "-")
        A(f"| {m['id']} | {m['module']} | {m['kind']} | {m['description']} | {m['job']} d={m['depth']} | {res} | {', '.join(((x[2:] if x[:2] == 'A_' else 'lemma ' + x[2:] if x[:2] == 'L_' else x)) for x in m['killed_by'][:4]) or '-'} | {fired} | {m['fail_step'] if m['fail_step'] is not None else '-'} | `{m['repro']}` |")
    A("")
    for m in mut:
        if not m["killed"] and m.get("waiver"):
            A(f"* **{m['id']}** survives by design: {m['waiver']}")
    A("")
    A("## 7. Unresolved, not claimed, not applicable")
    A("")
    A("| Id | Status | What | Why |")
    A("|---|---|---|---|")
    for u in unres:
        A(f"| {u['id']} | **{u['status']}** | {u['title']} | {u['reason']} |")
    A("")
    A("### Automatically derived: properties whose STRONGEST result is bounded / failed / timed out")
    A("")
    weak = [b for b in best if b["best"] in ("BOUNDED", "TIMEOUT", "FAIL", "STALE")]
    if weak:
        A("| RTL module | Property | Strongest result | Deepest evidence | Jobs |")
        A("|---|---|---|---|---|")
        for b in weak:
            ds = []
            for x in by_prop[(b["module"], b["property"])]:
                import re as _re
                m_ = _re.search(r"BMC (\d+) cycles", x["depth"])
                if m_:
                    ds.append(int(m_.group(1)))
            A(f"| {b['module']} | `{b['property']}` | **{b['best']}** | {('BMC ' + str(max(ds)) + ' cycles from reset') if ds else '-'} | {', '.join(b['jobs'])} |")
    else:
        A("None.")
    sup = len([x for x in claim_rows if x["result"] == "BOUNDED"]) - sum(1 for b in weak for x in by_prop[(b["module"], b["property"])] if x["result"] == "BOUNDED")
    A("")
    A(f"({sup} further BOUNDED rows above in section 3 are BMC-only runs of properties that are proven unbounded in another job; the property-level result in section 2 is the stronger one.)")
    A("")
    A("## 8. Counterexamples against the UNMUTATED RTL")
    A("")
    fails = [x for x in claim_rows if x["result"] == "FAIL"]
    if fails:
        for x in fails:
            A(f"* {x['job']} / `{x['property']}`: see {', '.join(x['counterexample']) or 'build logs'}")
    else:
        A("None: no property of the unmutated RTL was refuted in any job.")
    A("")
    A("## 9. Observations about the RTL (not property failures)")
    A("")
    for x in covers:
        if x["cover"] in ("FAB_MULTI_DENIAL_ONE_EVENT",) and x["result"] == "COVER-REACHED":
            A(f"* **F-01** (`{x['job']}`): two masters denied in the same cycle yield ONE violation event (`viol_o` is a single bit and only the lowest-indexed master is logged). `PERM_VIOL_COUNT` / `TC_PERM_VIOL` therefore count cycles with a denial, not denials. Both requests are still denied and answered `PERM`; this affects telemetry accuracy, not isolation.")
    A("")
    (OUT / "PROOF_LEDGER.md").write_text("\n".join(L) + "\n")

    # ---- one-page summary ---------------------------------------------------------------------------------------------------------
    S = ["# AlbionFormal: results at a glance", "",
         f"Generated {ledger['generated']}. Source of truth: `PROOF_LEDGER.md` (all rows are machine results). Counts are over DISTINCT (module, property) pairs, best result across parameter points; helper lemmas excluded.", ""]
    mods = {}
    for b in best:
        mods.setdefault(b["module"], []).append(b)
    cols = ["PROVEN", "PROVEN-COND", "BOUNDED", "FAIL", "TIMEOUT", "STALE"]
    S.append("| RTL module | properties | " + " | ".join(cols) + " |")
    S.append("|---|---|" + "---|" * len(cols))
    for mod, bs in sorted(mods.items()):
        S.append(f"| {mod} | {len(bs)} | " + " | ".join(str(sum(1 for b in bs if b['best'] == c)) for c in cols) + " |")
    tot = len(best)
    S.append(f"| **total** | **{tot}** | " + " | ".join(f"**{sum(1 for b in best if b['best'] == c)}**" for c in cols) + " |")
    S.append("")
    S.append("*PROVEN* = unbounded, no assumption beyond clock/reset. *PROVEN-COND* = unbounded, conditional on the declared assumptions (see ledger section 5). *BOUNDED* = no counterexample within the stated number of cycles only. Cover/observation rows are counted separately below.")
    S.append("")
    S.append(f"* Cover witnesses: {cov_n}")
    S.append(f"* Mutation campaign: {killed} of {len(mut)} injected bugs detected; {waived} survive with a written waiver; {len(surv)} unwaived survivors.")
    S.append(f"* Counterexamples against the unmutated RTL: {len([x for x in claim_rows if x['result'] == 'FAIL'])}")
    S.append("")
    S.append("## Properties that are only bounded or unresolved")
    S.append("")
    for b in best:
        if b["best"] in ("BOUNDED", "TIMEOUT", "FAIL", "STALE"):
            S.append(f"* `{b['property']}` ({b['module']}): **{b['best']}**; jobs {', '.join(b['jobs'])}")
    S.append("")
    S.append("## Declared unresolved / not claimed / not applicable")
    S.append("")
    for u in unres:
        S.append(f"* **{u['id']}** [{u['status']}]: {u['title']}")
    S.append("")
    (OUT / "SUMMARY.md").write_text("\n".join(S) + "\n")
    print(f"ledger: {len(rows)} rows ({len(claim_rows)} claims), {len(covers)} covers, {len(mut)} mutants -> reports/PROOF_LEDGER.md")


if __name__ == "__main__":
    main()
