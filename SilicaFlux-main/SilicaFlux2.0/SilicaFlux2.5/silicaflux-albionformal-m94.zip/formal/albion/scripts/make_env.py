#!/usr/bin/env python3
"""Writes reports/environment.json (tool versions, vendor hash status, host) for the ledger header."""
import json, os, platform, shutil, subprocess, sys, time
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "scripts"))
import albion_formal as af  # noqa: E402
env = {
    "date_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "host": f"{platform.system()} {platform.release()} x86_64, {os.cpu_count()} cores",
    "yosys": af.tool_version(["yosys", "-V"]), "z3": af.tool_version(["z3", "--version"]), "cvc5": af.tool_version(["cvc5", "--version"]),
    "yosys-abc": shutil.which("yosys-abc") or "missing", "python": platform.python_version(),
    "sby": ("installed: " + (shutil.which("sby") or "")) if shutil.which("sby") else "NOT INSTALLED - results come from the native driver (same yosys/smtbmc/abc flow); generated job.sby files were never executed",
    "backend": "native (yosys + yosys-smtbmc + yosys-abc)",
    "vendored RTL": "UNMODIFIED snapshot, hashes verified (vendor/SOURCES.sha256)" if not af.verify_vendor() else "MISMATCH",
    "RTL sources": "SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-albion-p90.zip (Albion P90 rtl/albion) and silicaflux-citadel-p89.zip (Citadel P89 rtl/albion)",
}
(ROOT / "reports").mkdir(exist_ok=True)
json.dump(env, open(ROOT / "reports/environment.json", "w"), indent=1)
print(json.dumps(env, indent=1))
