#!/usr/bin/env bash
# reproduction of job CITG-AW64-PDR: the raw tool invocations the driver ran.
# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).
set -e
ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"
mkdir -p "${ALBION_ROOT}/build/CITG-AW64-PDR" && cd "${ALBION_ROOT}/build/CITG-AW64-PDR"
# 1. elaborate
"yosys" "-q" "-l" "${ALBION_ROOT}/build/CITG-AW64-PDR/model.yosys.log" "-p" "read_verilog -formal -sv -DFORMAL -DSYNTHESIS -I${ALBION_ROOT}/lib -I${ALBION_ROOT}/harness ${ALBION_ROOT}/build/CITG-AW64-PDR/rtl/sf_albion_pkg.sv ${ALBION_ROOT}/build/CITG-AW64-PDR/rtl/sf_citadel_pkg.sv ${ALBION_ROOT}/build/CITG-AW64-PDR/rtl/sf_citadel_permission.sv ${ALBION_ROOT}/build/CITG-AW64-PDR/rtl/sf_citadel_gate.sv ${ALBION_ROOT}/lib/sf_fv_ctrl.sv ${ALBION_ROOT}/harness/fv_cit_spec.sv ${ALBION_ROOT}/harness/fv_cit_gate.sv; chparam -set AW 64 fv_cit_gate; prep -flatten -top fv_cit_gate; tee -q -o ${ALBION_ROOT}/build/CITG-AW64-PDR/model.assume.txt select -list t:\$assume; tee -q -o ${ALBION_ROOT}/build/CITG-AW64-PDR/model.assert.txt select -list t:\$assert; tee -q -o ${ALBION_ROOT}/build/CITG-AW64-PDR/model.cover.txt select -list t:\$cover; chformal -remove c:*\$assert\$*; chformal -cover -remove; async2sync; chformal -assume -early; opt_clean; memory_map; setundef -anyseq; dffunmap; techmap; opt -fast; abc -g AND -fast; dffunmap; aigmap; opt_clean; write_aiger -I -B -zinit -map ${ALBION_ROOT}/build/CITG-AW64-PDR/model.aim ${ALBION_ROOT}/build/CITG-AW64-PDR/model.aig"
# NOTE: PDR runs one AIG per property (pdr_<A_PROPERTY>.aig, produced by the driver); the commands below are
# those ABC invocations. To regenerate the AIGs run: python3 scripts/albion_formal.py run CITG-AW64-PDR
# 2. solve
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITG-AW64-PDR/pdr_A_CIT_GATE_COUNTER_NO_OVERFLOW.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITG-AW64-PDR/pdr_A_CIT_GATE_DOMAIN_ASSOCIATION.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITG-AW64-PDR/pdr_A_CIT_GATE_FLUSH_QUIET.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITG-AW64-PDR/pdr_A_CIT_GATE_NO_BYPASS.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITG-AW64-PDR/pdr_A_CIT_GATE_RESET_STATE.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITG-AW64-PDR/pdr_A_CIT_GATE_WRITE_NEEDS_RIGHT.aig; fold; strash; dretime; pdr"
