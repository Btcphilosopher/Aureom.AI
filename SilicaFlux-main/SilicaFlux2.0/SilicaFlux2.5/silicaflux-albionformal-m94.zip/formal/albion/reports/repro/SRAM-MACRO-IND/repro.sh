#!/usr/bin/env bash
# reproduction of job SRAM-MACRO-IND: the raw tool invocations the driver ran.
# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).
set -e
ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"
mkdir -p "${ALBION_ROOT}/build/SRAM-MACRO-IND" && cd "${ALBION_ROOT}/build/SRAM-MACRO-IND"
# 1. elaborate
"yosys" "-q" "-l" "${ALBION_ROOT}/build/SRAM-MACRO-IND/model.yosys.log" "-p" "read_verilog -formal -sv -DFORMAL -DSYNTHESIS -I${ALBION_ROOT}/lib ${ALBION_ROOT}/build/SRAM-MACRO-IND/rtl/sf_albion_sram_macro.sv ${ALBION_ROOT}/lib/sf_fv_ctrl.sv ${ALBION_ROOT}/harness/fv_sram_macro.sv; chparam -set WORDS 8 fv_sram_macro; prep -flatten -top fv_sram_macro; tee -q -o ${ALBION_ROOT}/build/SRAM-MACRO-IND/model.assume.txt select -list t:\$assume; tee -q -o ${ALBION_ROOT}/build/SRAM-MACRO-IND/model.assert.txt select -list t:\$assert; tee -q -o ${ALBION_ROOT}/build/SRAM-MACRO-IND/model.cover.txt select -list t:\$cover; chformal -remove c:*\$assert\$*; async2sync; chformal -assume -early; opt_clean; setundef -anyseq; opt -fast; dffunmap; write_smt2 -wires ${ALBION_ROOT}/build/SRAM-MACRO-IND/model.smt2"
# 2. solve
"yosys-smtbmc" "-s" "z3" "--unroll" "--noprogress" "-t" "4" "--presat" "--dump-vcd" "${ALBION_ROOT}/build/SRAM-MACRO-IND/bmc.vcd" "${ALBION_ROOT}/build/SRAM-MACRO-IND/model.smt2"
"yosys-smtbmc" "-s" "z3" "--unroll" "--noprogress" "-t" "4" "-i" "--dump-vcd" "${ALBION_ROOT}/build/SRAM-MACRO-IND/ind.vcd" "${ALBION_ROOT}/build/SRAM-MACRO-IND/model.smt2"
