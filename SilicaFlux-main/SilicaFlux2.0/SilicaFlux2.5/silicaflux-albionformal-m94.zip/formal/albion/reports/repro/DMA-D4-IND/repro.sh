#!/usr/bin/env bash
# reproduction of job DMA-D4-IND: the raw tool invocations the driver ran.
# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).
set -e
ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"
mkdir -p "${ALBION_ROOT}/build/DMA-D4-IND" && cd "${ALBION_ROOT}/build/DMA-D4-IND"
# 1. elaborate
"yosys" "-q" "-l" "${ALBION_ROOT}/build/DMA-D4-IND/model.yosys.log" "-p" "read_verilog -formal -sv -DFORMAL -DSYNTHESIS -I${ALBION_ROOT}/lib ${ALBION_ROOT}/build/DMA-D4-IND/rtl/sf_albion_regs_pkg.sv ${ALBION_ROOT}/build/DMA-D4-IND/rtl/sf_albion_fifo.sv ${ALBION_ROOT}/build/DMA-D4-IND/rtl/sf_albion_dma.sv ${ALBION_ROOT}/lib/sf_fv_ctrl.sv ${ALBION_ROOT}/harness/fv_dma.sv; chparam -set DEPTH 4 fv_dma; prep -flatten -top fv_dma; tee -q -o ${ALBION_ROOT}/build/DMA-D4-IND/model.assume.txt select -list t:\$assume; tee -q -o ${ALBION_ROOT}/build/DMA-D4-IND/model.assert.txt select -list t:\$assert; tee -q -o ${ALBION_ROOT}/build/DMA-D4-IND/model.cover.txt select -list t:\$cover; chformal -remove c:*\$assert\$*; async2sync; chformal -assume -early; opt_clean; setundef -anyseq; opt -fast; dffunmap; write_smt2 -wires ${ALBION_ROOT}/build/DMA-D4-IND/model.smt2"
# 2. solve
"yosys-smtbmc" "-s" "z3" "--unroll" "--noprogress" "-t" "6" "--presat" "--dump-vcd" "${ALBION_ROOT}/build/DMA-D4-IND/bmc.vcd" "${ALBION_ROOT}/build/DMA-D4-IND/model.smt2"
"yosys-smtbmc" "-s" "z3" "--unroll" "--noprogress" "-t" "6" "-i" "--dump-vcd" "${ALBION_ROOT}/build/DMA-D4-IND/ind.vcd" "${ALBION_ROOT}/build/DMA-D4-IND/model.smt2"
