#!/usr/bin/env bash
# reproduction of job CITG-AW64-BMC: the raw tool invocations the driver ran.
# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).
set -e
ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"
mkdir -p "${ALBION_ROOT}/build/CITG-AW64-BMC" && cd "${ALBION_ROOT}/build/CITG-AW64-BMC"
# 1. elaborate
"yosys" "-q" "-l" "${ALBION_ROOT}/build/CITG-AW64-BMC/model.yosys.log" "-p" "read_verilog -formal -sv -DFORMAL -DSYNTHESIS -I${ALBION_ROOT}/lib -I${ALBION_ROOT}/harness ${ALBION_ROOT}/build/CITG-AW64-BMC/rtl/sf_albion_pkg.sv ${ALBION_ROOT}/build/CITG-AW64-BMC/rtl/sf_citadel_pkg.sv ${ALBION_ROOT}/build/CITG-AW64-BMC/rtl/sf_citadel_permission.sv ${ALBION_ROOT}/build/CITG-AW64-BMC/rtl/sf_citadel_gate.sv ${ALBION_ROOT}/lib/sf_fv_ctrl.sv ${ALBION_ROOT}/harness/fv_cit_spec.sv ${ALBION_ROOT}/harness/fv_cit_gate.sv; chparam -set AW 64 fv_cit_gate; prep -flatten -top fv_cit_gate; tee -q -o ${ALBION_ROOT}/build/CITG-AW64-BMC/model.assume.txt select -list t:\$assume; tee -q -o ${ALBION_ROOT}/build/CITG-AW64-BMC/model.assert.txt select -list t:\$assert; tee -q -o ${ALBION_ROOT}/build/CITG-AW64-BMC/model.cover.txt select -list t:\$cover; chformal -remove c:*\$assert\$*; async2sync; chformal -assume -early; opt_clean; setundef -anyseq; opt -fast; dffunmap; write_smt2 -wires ${ALBION_ROOT}/build/CITG-AW64-BMC/model.smt2"
# 2. solve
"yosys-smtbmc" "-s" "z3" "--unroll" "--noprogress" "-t" "14" "--presat" "--dump-vcd" "${ALBION_ROOT}/build/CITG-AW64-BMC/bmc.vcd" "${ALBION_ROOT}/build/CITG-AW64-BMC/model.smt2"
