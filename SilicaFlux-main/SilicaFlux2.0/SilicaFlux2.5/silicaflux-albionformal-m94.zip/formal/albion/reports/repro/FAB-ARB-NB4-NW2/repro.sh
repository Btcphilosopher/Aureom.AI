#!/usr/bin/env bash
# reproduction of job FAB-ARB-NB4-NW2: the raw tool invocations the driver ran.
# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).
set -e
ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"
mkdir -p "${ALBION_ROOT}/build/FAB-ARB-NB4-NW2" && cd "${ALBION_ROOT}/build/FAB-ARB-NB4-NW2"
# 1. elaborate
"yosys" "-q" "-l" "${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/model.yosys.log" "-p" "read_verilog -formal -sv -DFORMAL -DSYNTHESIS -DFV_ARB -I${ALBION_ROOT}/lib ${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/rtl/sf_albion_regs_pkg.sv ${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/rtl/sf_albion_datafabric.sv ${ALBION_ROOT}/lib/sf_fv_ctrl.sv ${ALBION_ROOT}/harness/fv_fabric.sv; chparam -set NB 4 fv_fabric; chparam -set NW 2 fv_fabric; prep -flatten -top fv_fabric; tee -q -o ${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/model.assume.txt select -list t:\$assume; tee -q -o ${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/model.assert.txt select -list t:\$assert; tee -q -o ${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/model.cover.txt select -list t:\$cover; chformal -remove c:*\$assert\$*; async2sync; chformal -assume -early; opt_clean; setundef -anyseq; opt -fast; dffunmap; write_smt2 -wires ${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/model.smt2"
# 2. solve
"yosys-smtbmc" "-s" "z3" "--unroll" "--noprogress" "-t" "8" "--presat" "--dump-vcd" "${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/bmc.vcd" "${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/model.smt2"
"yosys-smtbmc" "-s" "z3" "--unroll" "--noprogress" "-t" "8" "-i" "--dump-vcd" "${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/ind.vcd" "${ALBION_ROOT}/build/FAB-ARB-NB4-NW2/model.smt2"
