#!/usr/bin/env bash
# reproduction of job SECDED-SINGLE: the raw tool invocations the driver ran.
# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).
set -e
ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"
mkdir -p "${ALBION_ROOT}/build/SECDED-SINGLE" && cd "${ALBION_ROOT}/build/SECDED-SINGLE"
# 1. elaborate
"yosys" "-q" "-l" "${ALBION_ROOT}/build/SECDED-SINGLE/model.yosys.log" "-p" "read_verilog -formal -sv -DFORMAL -DSYNTHESIS -I${ALBION_ROOT}/lib ${ALBION_ROOT}/build/SECDED-SINGLE/rtl/sf_albion_secded.sv ${ALBION_ROOT}/lib/sf_fv_ctrl.sv ${ALBION_ROOT}/harness/fv_secded.sv; chparam -set CHECK 1 fv_secded; prep -flatten -top fv_secded; tee -q -o ${ALBION_ROOT}/build/SECDED-SINGLE/model.assume.txt select -list t:\$assume; tee -q -o ${ALBION_ROOT}/build/SECDED-SINGLE/model.assert.txt select -list t:\$assert; tee -q -o ${ALBION_ROOT}/build/SECDED-SINGLE/model.cover.txt select -list t:\$cover; chformal -remove c:*\$assert\$*; opt_clean; synth -flatten -top fv_secded; aigmap; opt_clean; write_aiger -zinit ${ALBION_ROOT}/build/SECDED-SINGLE/model.aig"
# 2. solve
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/SECDED-SINGLE/model.aig; strash; iprove"
