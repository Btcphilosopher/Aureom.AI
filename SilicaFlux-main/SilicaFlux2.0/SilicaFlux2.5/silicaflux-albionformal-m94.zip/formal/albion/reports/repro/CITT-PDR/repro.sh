#!/usr/bin/env bash
# reproduction of job CITT-PDR: the raw tool invocations the driver ran.
# Needs the RTL staged under build/<job>/rtl/ : run `python3 scripts/albion_formal.py run <job>` once (this script re-runs only the solver commands).
set -e
ALBION_ROOT="${ALBION_ROOT:-$(cd "$(dirname "$0")/../../.." && pwd)}"
mkdir -p "${ALBION_ROOT}/build/CITT-PDR" && cd "${ALBION_ROOT}/build/CITT-PDR"
# 1. elaborate
"yosys" "-q" "-l" "${ALBION_ROOT}/build/CITT-PDR/model.yosys.log" "-p" "read_verilog -formal -sv -DFORMAL -DSYNTHESIS -I${ALBION_ROOT}/lib -I${ALBION_ROOT}/harness ${ALBION_ROOT}/build/CITT-PDR/rtl/sf_albion_pkg.sv ${ALBION_ROOT}/build/CITT-PDR/rtl/sf_citadel_pkg.sv ${ALBION_ROOT}/build/CITT-PDR/rtl/sf_citadel_permission.sv ${ALBION_ROOT}/build/CITT-PDR/rtl/sf_citadel_domain_table.sv ${ALBION_ROOT}/lib/sf_fv_ctrl.sv ${ALBION_ROOT}/harness/fv_cit_table.sv; prep -flatten -top fv_cit_table; tee -q -o ${ALBION_ROOT}/build/CITT-PDR/model.assume.txt select -list t:\$assume; tee -q -o ${ALBION_ROOT}/build/CITT-PDR/model.assert.txt select -list t:\$assert; tee -q -o ${ALBION_ROOT}/build/CITT-PDR/model.cover.txt select -list t:\$cover; chformal -remove c:*\$assert\$*; chformal -cover -remove; async2sync; chformal -assume -early; opt_clean; memory_map; setundef -anyseq; dffunmap; techmap; opt -fast; abc -g AND -fast; dffunmap; aigmap; opt_clean; write_aiger -I -B -zinit -map ${ALBION_ROOT}/build/CITT-PDR/model.aim ${ALBION_ROOT}/build/CITT-PDR/model.aig"
# NOTE: PDR runs one AIG per property (pdr_<A_PROPERTY>.aig, produced by the driver); the commands below are
# those ABC invocations. To regenerate the AIGs run: python3 scripts/albion_formal.py run CITT-PDR
# 2. solve
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_CFG_GATED.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_CLRWIN_INVALIDATES.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_EXCLUSIVE_DISJOINT.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_REFUSED_NO_CHANGE.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_RESET_DEFAULT_DENY.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_REVOKE_INVALIDATES.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_STALE_DOMAIN_DENIED.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_STALE_WINDOW_INVALID.aig; fold; strash; dretime; pdr"
"yosys-abc" "-c" "read_aiger ${ALBION_ROOT}/build/CITT-PDR/pdr_A_CIT_TBL_UNPRIVILEGED_REJECTED.aig; fold; strash; dretime; pdr"
