# Counterexample report: DMA-D4-IND@drop_DMA_RSP_OUT

* job: `DMA-D4-IND` (DMA correctness, DEPTH=4 (k-induction with helper lemmas))
* RELAXED ENVIRONMENT: assumption(s) S_DMA_RSP_OUT were DROPPED on purpose (assumption sensitivity analysis); the RTL is unmodified. This shows what the assumption protects against.
* engine: smtbmc z3 bmc   depth bound: 22   failing step: 4
* violated assertions: `L_DMA_IDX_ORDER`, `L_DMA_RD_OUT_COUNT`

**L_DMA_IDX_ORDER** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.
**L_DMA_RD_OUT_COUNT** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force

* `DMA_RSP_OUT`: **DROPPED in this run** (it is normally in force). Original text: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py sensitivity DMA-D4-IND
# raw tool commands: build/DMA-D4-IND/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 |
|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 |
| `ev_done_err_o` | 0 | 0 | 0 | 0 | 1 |
| `ev_done_ok_o` | 0 | 0 | 0 | 0 | 0 |
| `rd_req_addr` | 0 | 0 | 0 | 0 | 0 |
| `rd_req_ready` | 0 | 0 | 0 | 0 | 0 |
| `rd_req_valid` | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_err` | 0 | 0 | 0 | 1 | 1 |
| `rd_rsp_rdata` | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_valid` | 0 | 1 | 1 | 1 | 1 |
| `rg_err` | 0 | 0 | 0 | 4 | 4 |
| `rg_off` | 0 | 8 | 10 | 0 | 0 |
| `rg_wdata` | 0 | 11080 | 21025 | 1 | 0 |
| `rg_we` | 0 | 1 | 1 | 1 | 1 |
| `rst_free` | 0 | 1 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 | 4 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 | 4 |
| `wr_req_addr` | 0 | 0 | 0 | 0 | 0 |
| `wr_req_ready` | 0 | 0 | 0 | 0 | 0 |
| `wr_req_valid` | 0 | 0 | 0 | 0 | 0 |
| `wr_rsp_err` | 0 | 0 | 0 | 1 | 2 |
| `wr_rsp_valid` | 0 | 0 | 0 | 0 | 1 |

Full waveform: `build/DMA-D4-IND/bmc.vcd` (open with GTKWave).

