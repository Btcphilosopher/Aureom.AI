# Counterexample report: SRAM-W8-IND@drop_SRAM_NO_INJ

* job: `SRAM-W8-IND` (SRAM bank data/write-enable/reset properties, WORDS=8 (k-induction))
* RELAXED ENVIRONMENT: assumption(s) S_SRAM_NO_INJ were DROPPED on purpose (assumption sensitivity analysis); the RTL is unmodified. This shows what the assumption protects against.
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 10
* violated assertions: `L_SRAM_CW_TRACKS_DATA`

**L_SRAM_CW_TRACKS_DATA** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force

* `MACRO_CONTRACT`: Bank-level jobs abstract the memory macro by its contract: after a read of a word, rdata equals the codeword most recently written to that word (an unwritten word is never read: the scrub writes every word before the bank accepts traffic).
* `SRAM_NO_INJ`: **DROPPED in this run** (it is normally in force). Original text: The RAS error-injection port is idle: inj_arm = 0. Required for the data-correctness (read-after-write) proofs, which are false by design when a fault is injected.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py sensitivity SRAM-W8-IND
# raw tool commands: build/SRAM-W8-IND/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=3 | t=4 | t=5 | t=6 | t=7 | t=8 | t=9 | t=10 |
|---|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ecc_ce_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ecc_master_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 |
| `ecc_syndrome_o` | 5f | 5f | 5f | 5f | 5f | 5f | 5f | 5f |
| `ecc_ue_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ecc_word_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 |
| `init_done_o` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| `inj_arm` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| `inj_mask` | 40801090a0 | 41001088c3 | 5080084027 | 41800408aa | 2880010a2 | 60c000a085 | 54408400 | 0 |
| `inj_word` | 0 | 0 | 4 | 2 | 0 | 1 | 2 | 0 |
| `req_domain` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_id` | 1 | 2 | 0 | 1 | 2 | 0 | 2 | 0 |
| `req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| `req_wdata` | 80800204 | 80401022 | 20010101 | 10800200 | 20800208 | 4801012 | 0 | 0 |
| `req_we` | 0 | 1 | 0 | 1 | 1 | 0 | 1 | 0 |
| `req_word` | 0 | 4 | 2 | 1 | 0 | 0 | 2 | 1 |
| `req_wstrb` | 1 | a | 4 | 4 | 3 | 4 | f | 0 |
| `rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_id` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 |
| `rsp_rdata` | 2040081 | 2040081 | 2040081 | 2040081 | 2040081 | 2040081 | 2040081 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| `rst_free` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 3 | 4 | 5 | 6 | 7 | 8 | 9 | a |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 3 | 4 | 5 | 6 | 7 | 8 | 9 | a |

Full waveform: `build/SRAM-W8-IND/bmc.vcd` (open with GTKWave).

