# Counterexample report: FAB-NB2-NW2@drop_SLAVE_RSP_MATCH

* job: `FAB-NB2-NW2` (DataFabric, NB=2 NW=2)
* RELAXED ENVIRONMENT: assumption(s) S_SLAVE_RSP_MATCH were DROPPED on purpose (assumption sensitivity analysis); the RTL is unmodified. This shows what the assumption protects against.
* engine: smtbmc z3 bmc   depth bound: 4   failing step: 1
* violated assertions: `A_FAB_RSP_DELIVERED`, `A_FAB_RSP_NO_SPURIOUS`, `A_FAB_RSP_ONE_SOURCE`

**FAB_RSP_DELIVERED** (sf_albion_datafabric): Every slave response is delivered to the master named by its id, data and error unchanged (none dropped).
**FAB_RSP_NO_SPURIOUS** (sf_albion_datafabric): A master receives a response only while it has an outstanding request.
**FAB_RSP_ONE_SOURCE** (sf_albion_datafabric): A delivered response has exactly one source (fabric error responder XOR one slave).

## Assumptions in force

* `MASTER_1PO`: Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation).
* `SLAVE_RSP_MATCH`: **DROPPED in this run** (it is normally in force). Original text: A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py sensitivity FAB-NB2-NW2
# raw tool commands: build/FAB-NB2-NW2/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 |
|---|---|---|
| `boot_mode` | 1 | 0 |
| `clk` | 1 | 1 |
| `decerr_o` | 0 | 0 |
| `m_req_domain` | 1000 | 0 |
| `m_req_ready` | 0 | 4 |
| `m_req_valid` | 8 | c |
| `m_req_we` | 8 | 0 |
| `m_req_wstrb` | 0 | 0 |
| `m_rsp_err` | 0 | 40 |
| `m_rsp_valid` | 0 | 4 |
| `rst_free` | 0 | 0 |
| `rst_n` | 0 | 0 |
| `s_req_domain` | 100 | 0 |
| `s_req_id` | 30 | 30 |
| `s_req_ready` | 0 | 0 |
| `s_req_valid` | 4 | 4 |
| `s_req_we` | 4 | 0 |
| `s_req_wstrb` | 0 | 0 |
| `s_rsp_err` | 0 | 453 |
| `s_rsp_id` | 0 | aa |
| `s_rsp_valid` | 0 | 5 |
| `sf_first` | 1 | 0 |
| `sf_live` | 0 | 1 |
| `sf_step` | 0 | 1 |
| `smt_clock` | 1 | 1 |
| `smt_step` | 0 | 1 |
| `viol_addr_o` | 0 | 0 |
| `viol_domain_o` | 0 | 0 |
| `viol_master_o` | 0 | 2 |
| `viol_o` | 0 | 1 |
| `viol_we_o` | 0 | 0 |
| `win_attr` | 200003 | 100100 |
| `win_base` | c000000140000001 | 4000000140000001 |
| `win_limit` | c0000000 | 0 |

Full waveform: `build/FAB-NB2-NW2/bmc.vcd` (open with GTKWave).

