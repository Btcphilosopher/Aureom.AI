No counterexamples against the unmutated RTL exist in this delivery. Counterexamples of INJECTED bugs: ../mutation/cex/ . Counterexamples under deliberately relaxed assumptions: ../sensitivity/cex/ .
