# Counterexample report: CITT-BMC@CITT-M03-CFGEN-IGNORED

* job: `CITT-BMC` (Citadel table+permission: invalidation, default-deny, privilege, exclusivity (bounded))
* mutation: `CITT-M03-CFGEN-IGNORED`
* engine: smtbmc z3 bmc   depth bound: 6   failing step: 2
* violated assertions: `A_CIT_TBL_CFG_GATED`

**CIT_TBL_CFG_GATED** (sf_citadel_domain_table): With cfg_en_i low every command is refused NOT_AUTH.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate CITT-M03-CFGEN-IGNORED
# raw tool commands: build/CITT-BMC__CITT-M03-CFGEN-IGNORED/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 |
|---|---|---|---|
| `a` | 2 | 2 | 2 |
| `addr_i` | 0 | 0 | 0 |
| `attr_i` | 0 | 0 | 0 |
| `b` | 2 | 2 | 2 |
| `bind_o` | 0 | 0 | 0 |
| `cfg_en_i` | 0 | 0 | 0 |
| `clk` | 1 | 1 | 1 |
| `cls_i` | 0 | 0 | 0 |
| `cmd_arg_dom_i` | 0 | 8 | 0 |
| `cmd_data0_i` | 0 | 21 | 0 |
| `cmd_data1_i` | 0 | 1 | 0 |
| `cmd_dom_i` | 0 | 0 | 0 |
| `cmd_flags_i` | 0 | f | 0 |
| `cmd_op_i` | 0 | 0 | 0 |
| `cmd_port_i` | 0 | 0 | 0 |
| `cmd_priv_i` | 0 | 1 | 0 |
| `cmd_slot_i` | 0 | 0 | 0 |
| `cmd_valid_i` | 0 | 1 | 0 |
| `cmd_win_i` | 0 | 0 | 0 |
| `devrd_o` | 0 | 0 | 0 |
| `devwr_o` | 0 | 0 | 0 |
| `dft_active_i` | 0 | 0 | 0 |
| `dom_i` | 0 | 0 | 0 |
| `fv_rev` | 0 | 0 | 0 |
| `fv_rid` | 0 | 0 | 0 |
| `fv_tk` | 0 | 0 | 0 |
| `fv_ts` | 0 | 0 | 0 |
| `fv_wclr` | 0 | 0 | 0 |
| `i` | 2 | 2 | 2 |
| `idx_i` | 0 | 0 | 0 |
| `j` | 2 | 2 | 2 |
| `len_i` | 0 | 0 | 0 |
| `lock_o` | 0 | 0 | 0 |
| `lockdown_i` | 0 | 0 | 0 |
| `look_dom_i` | 0 | 0 | 0 |
| `op_i` | 0 | 0 | 0 |
| `own_addr_i` | 0 | 0 | 0 |
| `p_arg` | 0 | 0 | 8 |
| `p_cfg` | 0 | 0 | 0 |
| `p_dom` | 0 | 0 | 0 |
| `p_id` | 0 | 0 | 0 |
| `p_ok` | 0 | 0 | 0 |
| `p_op` | 0 | 0 | 0 |
| `p_priv` | 0 | 0 | 1 |
| `p_slot` | 0 | 0 | 0 |
| `p_unpriv` | 1 | 1 | 0 |
| `p_valid` | 0 | 0 | 1 |
| `p_win` | 0 | 0 | 0 |

Full waveform: `build/CITT-BMC__CITT-M03-CFGEN-IGNORED/bmc.vcd` (open with GTKWave).

