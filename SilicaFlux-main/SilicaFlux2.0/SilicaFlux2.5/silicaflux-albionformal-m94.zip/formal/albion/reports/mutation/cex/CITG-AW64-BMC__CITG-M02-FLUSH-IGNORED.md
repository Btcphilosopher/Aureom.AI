# Counterexample report: CITG-AW64-BMC@CITG-M02-FLUSH-IGNORED

* job: `CITG-AW64-BMC` (Citadel gate + real permission checker, free table (bounded model check))
* mutation: `CITG-M02-FLUSH-IGNORED`
* engine: smtbmc z3 bmc   depth bound: 10   failing step: 2
* violated assertions: `A_CIT_GATE_FLUSH_QUIET`

**CIT_GATE_FLUSH_QUIET** (sf_citadel_gate): Nothing is presented to the target while the port is flushed/isolated.

## Assumptions in force

* `CIT_PARAM_POINT`: Citadel proofs are at a reduced parameter point (NDOM=2, NW=2, NP=1, NDEV=1, NQ=2, AW as stated in the job). The logic is parametric, but 'holds at the small point' implies 'holds at NDOM=8, NW=4' only by an argument, not a proof (the authors' own docs say the same).

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate CITG-M02-FLUSH-IGNORED
# raw tool commands: build/CITG-AW64-BMC__CITG-M02-FLUSH-IGNORED/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 |
|---|---|---|---|
| `addr_fits` | 1 | 1 | 1 |
| `bind_i` | 0 | 0 | 2 |
| `chk_addr_o` | 0 | 0 | c000000000000000 |
| `chk_attr_o` | 0 | 0 | 4 |
| `chk_cls_o` | 0 | 0 | 0 |
| `chk_commit_o` | 0 | 0 | 1 |
| `chk_dom_o` | 0 | 0 | 2 |
| `chk_idx_o` | 0 | 0 | 0 |
| `chk_len_o` | 10 | 10 | 10 |
| `chk_op_o` | 0 | 0 | 1 |
| `chk_permit_i` | 0 | 0 | 1 |
| `chk_status_i` | 0 | 0 | 0 |
| `chk_valid_o` | 0 | 0 | 1 |
| `clk` | 1 | 1 | 1 |
| `devrd_i` | 0 | 0 | 2 |
| `devwr_i` | 0 | 0 | 0 |
| `dft_active_i` | 0 | 0 | 0 |
| `flush_i` | 0 | 0 | 1 |
| `lockdown_i` | 0 | 0 | 0 |
| `m_req_ready_o` | 1 | 1 | 0 |
| `m_req_valid_i` | 0 | 1 | 0 |
| `m_rsp_ready_i` | 0 | 0 | 0 |
| `m_rsp_valid_o` | 0 | 0 | 0 |
| `op_now` | 0 | 0 | 1 |
| `outstanding_o` | 0 | 0 | 0 |
| `port_isol_i` | 0 | 0 | 0 |
| `qhold_i` | 0 | 0 | 0 |
| `qmask_i` | 0 | 0 | 0 |
| `reason_o` | 1 | 1 | 0 |
| `rst_free` | 0 | 1 | 1 |
| `rst_n` | 0 | 1 | 1 |
| `sf_first` | 1 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 |
| `slot_id_i` | 0 | 0 | 200 |
| `slot_o` | 0 | 0 | 1 |
| `slot_priv_i` | 0 | 0 | 2 |
| `slot_secure_i` | 0 | 0 | 0 |
| `slot_state_i` | 0 | 0 | 8 |
| `slot_vld_o` | 0 | 0 | 1 |
| `smt_clock` | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 |
| `sn_ok` | 0 | 0 | 0 |
| `sn_op` | 0 | 0 | 0 |
| `sp_now` | 0 | 0 | 1 |
| `spw_now` | 0 | 0 | 0 |
| `t_addr` | 0 | 0 | c000000000000000 |
| `t_attr` | 0 | 0 | 4 |

Full waveform: `build/CITG-AW64-BMC__CITG-M02-FLUSH-IGNORED/bmc.vcd` (open with GTKWave).

