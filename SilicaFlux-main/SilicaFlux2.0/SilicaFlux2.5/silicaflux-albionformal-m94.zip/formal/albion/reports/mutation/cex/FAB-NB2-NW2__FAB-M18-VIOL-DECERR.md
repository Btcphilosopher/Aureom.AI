# Counterexample report: FAB-NB2-NW2@FAB-M18-VIOL-DECERR

* job: `FAB-NB2-NW2` (DataFabric, NB=2 NW=2)
* mutation: `FAB-M18-VIOL-DECERR`
* engine: smtbmc z3 bmc   depth bound: 4   failing step: 0
* violated assertions: `A_FAB_VIOL_REPORT`

**FAB_VIOL_REPORT** (sf_albion_datafabric): viol/decerr events are raised exactly for decoded-but-denied / undecoded requests and report the lowest-indexed offending master with its true address, domain and direction.

## Assumptions in force

* `MASTER_1PO`: Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation).
* `SLAVE_RSP_MATCH`: A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FAB-M18-VIOL-DECERR
# raw tool commands: build/FAB-NB2-NW2__FAB-M18-VIOL-DECERR/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `boot_mode` | 0 |
| `clk` | 1 |
| `decerr_o` | 1 |
| `m_req_domain` | 1000 |
| `m_req_ready` | 8 |
| `m_req_valid` | 8 |
| `m_req_we` | 1 |
| `m_req_wstrb` | 0 |
| `m_rsp_valid` | 0 |
| `rst_free` | 0 |
| `rst_n` | 0 |
| `s_req_id` | 0 |
| `s_req_ready` | 0 |
| `s_req_valid` | 0 |
| `s_rsp_err` | 0 |
| `s_rsp_id` | 0 |
| `s_rsp_valid` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `viol_addr_o` | 8000 |
| `viol_domain_o` | 1 |
| `viol_master_o` | 3 |
| `viol_o` | 1 |
| `viol_we_o` | 0 |
| `win_attr` | 800100 |
| `win_base` | 100000001 |
| `win_limit` | 0 |

Full waveform: `build/FAB-NB2-NW2__FAB-M18-VIOL-DECERR/bmc.vcd` (open with GTKWave).

