# Counterexample report: SRAM-W8-IND@SRAM-M03-ACCEPT-DURING-SCRUB

* job: `SRAM-W8-IND` (SRAM bank data/write-enable/reset properties, WORDS=8 (k-induction))
* mutation: `SRAM-M03-ACCEPT-DURING-SCRUB`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 1
* violated assertions: `A_SRAM_READY_GATING`

**SRAM_READY_GATING** (sf_albion_sram_bank (+secded, macro)): req_ready == init_done && not in RMW commit (exact).

## Assumptions in force

* `MACRO_CONTRACT`: Bank-level jobs abstract the memory macro by its contract: after a read of a word, rdata equals the codeword most recently written to that word (an unwritten word is never read: the scrub writes every word before the bank accepts traffic).
* `SRAM_NO_INJ`: The RAS error-injection port is idle: inj_arm = 0. Required for the data-correctness (read-after-write) proofs, which are false by design when a fault is injected.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate SRAM-M03-ACCEPT-DURING-SCRUB
# raw tool commands: build/SRAM-W8-IND__SRAM-M03-ACCEPT-DURING-SCRUB/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 |
|---|---|---|
| `clk` | 1 | 1 |
| `ecc_syndrome_o` | 64 | 64 |
| `ecc_word_o` | 0 | 0 |
| `init_done_o` | 1 | 0 |
| `inj_arm` | 0 | 0 |
| `inj_mask` | 0 | 0 |
| `inj_word` | 0 | 0 |
| `req_domain` | 0 | 0 |
| `req_id` | 0 | 0 |
| `req_ready` | 0 | 1 |
| `req_valid` | 0 | 0 |
| `req_wdata` | 100 | 0 |
| `req_we` | 0 | 0 |
| `req_word` | 1 | 0 |
| `req_wstrb` | 0 | 0 |
| `rsp_err` | 0 | 0 |
| `rsp_valid` | 1 | 0 |
| `rst_free` | 0 | 0 |
| `rst_n` | 0 | 0 |
| `sf_first` | 1 | 0 |
| `sf_live` | 0 | 1 |
| `sf_step` | 0 | 1 |
| `smt_clock` | 1 | 1 |
| `smt_step` | 0 | 1 |

Full waveform: `build/SRAM-W8-IND__SRAM-M03-ACCEPT-DURING-SCRUB/bmc.vcd` (open with GTKWave).

