# Counterexample report: SRAM-W8-IND@SRAM-M06-RSPID-ZERO

* job: `SRAM-W8-IND` (SRAM bank data/write-enable/reset properties, WORDS=8 (k-induction))
* mutation: `SRAM-M06-RSPID-ZERO`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 10
* violated assertions: `A_SRAM_RSP_MATCH`

**SRAM_RSP_MATCH** (sf_albion_sram_bank (+secded, macro)): A response appears exactly one cycle after each accepted request, echoes its id, and write responses carry zero data. Discharges the fabric's SLAVE_RSP_MATCH assumption for SRAM banks.

## Assumptions in force

* `MACRO_CONTRACT`: Bank-level jobs abstract the memory macro by its contract: after a read of a word, rdata equals the codeword most recently written to that word (an unwritten word is never read: the scrub writes every word before the bank accepts traffic).
* `SRAM_NO_INJ`: The RAS error-injection port is idle: inj_arm = 0. Required for the data-correctness (read-after-write) proofs, which are false by design when a fault is injected.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate SRAM-M06-RSPID-ZERO
# raw tool commands: build/SRAM-W8-IND__SRAM-M06-RSPID-ZERO/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=3 | t=4 | t=5 | t=6 | t=7 | t=8 | t=9 | t=10 |
|---|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ecc_syndrome_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ecc_word_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 2 |
| `init_done_o` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| `inj_arm` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inj_mask` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inj_word` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_domain` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_id` | 0 | 0 | 0 | 0 | 0 | 0 | 2 | 0 |
| `req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| `req_wdata` | 1084020 | 40020400 | 8801020 | 8400420 | 20100405 | 4020810 | 220200 | 0 |
| `req_we` | 0 | 0 | 0 | 0 | 0 | 1 | 1 | 0 |
| `req_word` | 1 | 4 | 2 | 0 | 2 | 0 | 2 | 0 |
| `req_wstrb` | 9 | 6 | 8 | 8 | e | 8 | f | 0 |
| `rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_id` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_rdata` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| `rst_free` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 3 | 4 | 5 | 6 | 7 | 8 | 9 | a |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 3 | 4 | 5 | 6 | 7 | 8 | 9 | a |

Full waveform: `build/SRAM-W8-IND__SRAM-M06-RSPID-ZERO/bmc.vcd` (open with GTKWave).

