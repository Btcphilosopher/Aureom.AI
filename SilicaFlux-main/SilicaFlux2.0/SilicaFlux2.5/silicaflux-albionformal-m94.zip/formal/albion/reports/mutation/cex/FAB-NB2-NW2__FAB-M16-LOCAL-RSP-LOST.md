# Counterexample report: FAB-NB2-NW2@FAB-M16-LOCAL-RSP-LOST

* job: `FAB-NB2-NW2` (DataFabric, NB=2 NW=2)
* mutation: `FAB-M16-LOCAL-RSP-LOST`
* engine: smtbmc z3 bmc   depth bound: 4   failing step: 2
* violated assertions: `A_FAB_RSP_LOCAL_ERROR`

**FAB_RSP_LOCAL_ERROR** (sf_albion_datafabric): Undecoded/denied requests are answered by the fabric in the next cycle with zero data and the right code (DECERR / PERM).

## Assumptions in force

* `MASTER_1PO`: Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation).
* `SLAVE_RSP_MATCH`: A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FAB-M16-LOCAL-RSP-LOST
# raw tool commands: build/FAB-NB2-NW2__FAB-M16-LOCAL-RSP-LOST/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 |
|---|---|---|---|
| `boot_mode` | 0 | 0 | 0 |
| `clk` | 1 | 1 | 1 |
| `decerr_o` | 0 | 0 | 0 |
| `m_req_domain` | 0 | 200 | 0 |
| `m_req_ready` | 0 | e | 0 |
| `m_req_valid` | 0 | e | 0 |
| `m_req_we` | 0 | 0 | 0 |
| `m_req_wstrb` | 0 | 0 | 0 |
| `m_rsp_err` | 0 | 0 | 491 |
| `m_rsp_valid` | 0 | 0 | 0 |
| `rst_free` | 0 | 1 | 0 |
| `rst_n` | 0 | 1 | 0 |
| `s_req_id` | 0 | 4 | 0 |
| `s_req_ready` | 0 | 6 | 0 |
| `s_req_valid` | 0 | 2 | 0 |
| `s_rsp_err` | 0 | 0 | 0 |
| `s_rsp_id` | 0 | 1 | f0 |
| `s_rsp_valid` | 0 | 0 | 0 |
| `sf_first` | 1 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 |
| `smt_clock` | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 |
| `viol_o` | 0 | 1 | 0 |
| `win_attr` | 0 | 400000 | 0 |
| `win_base` | 0 | 414400004001 | 0 |
| `win_limit` | 0 | 0 | 0 |

Full waveform: `build/FAB-NB2-NW2__FAB-M16-LOCAL-RSP-LOST/bmc.vcd` (open with GTKWave).

