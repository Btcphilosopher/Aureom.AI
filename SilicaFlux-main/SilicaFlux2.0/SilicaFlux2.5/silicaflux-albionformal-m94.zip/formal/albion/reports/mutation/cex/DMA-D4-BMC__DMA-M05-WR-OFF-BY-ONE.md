# Counterexample report: DMA-D4-BMC@DMA-M05-WR-OFF-BY-ONE

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M05-WR-OFF-BY-ONE`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 4
* violated assertions: `A_DMA_WR_BEAT_BOUNDS`

**DMA_WR_BEAT_BOUNDS** (sf_albion_dma): Every write beat lies inside [DST, DST+LEN), is word aligned and does not wrap 2^32.

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M05-WR-OFF-BY-ONE
# raw tool commands: build/DMA-D4-BMC__DMA-M05-WR-OFF-BY-ONE/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 |
|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 |
| `ev_done_err_o` | 0 | 0 | 0 | 0 | 0 |
| `ev_done_ok_o` | 0 | 0 | 0 | 0 | 0 |
| `rd_req_ready` | 0 | 0 | 0 | 0 | 0 |
| `rd_req_valid` | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_err` | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_rdata` | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_valid` | 0 | 0 | 0 | 0 | 0 |
| `rg_err` | 0 | 0 | 0 | 0 | 0 |
| `rg_off` | 0 | 8 | 10 | 0 | 0 |
| `rg_wdata` | 0 | 4 | 3 | 4000000 | 0 |
| `rg_we` | 0 | 1 | 1 | 0 | 0 |
| `rst_free` | 0 | 1 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 | 4 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 | 4 |
| `wr_req_addr` | 4 | 4 | 4 | 4 | 4 |
| `wr_req_ready` | 0 | 0 | 0 | 0 | 0 |
| `wr_req_valid` | 0 | 0 | 0 | 0 | 1 |
| `wr_rsp_err` | 0 | 0 | 0 | 0 | 1 |
| `wr_rsp_valid` | 0 | 0 | 0 | 0 | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M05-WR-OFF-BY-ONE/bmc.vcd` (open with GTKWave).

