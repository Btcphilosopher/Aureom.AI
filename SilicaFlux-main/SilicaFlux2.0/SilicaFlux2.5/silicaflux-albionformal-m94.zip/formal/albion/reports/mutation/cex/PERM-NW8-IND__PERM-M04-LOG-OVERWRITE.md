# Counterexample report: PERM-NW8-IND@PERM-M04-LOG-OVERWRITE

* job: `PERM-NW8-IND` (Permission window table + violation log, NW=8 (k-induction))
* mutation: `PERM-M04-LOG-OVERWRITE`
* engine: smtbmc z3 bmc   depth bound: 6   failing step: 3
* violated assertions: `A_PERM_VIOL_FIRST_STICKY`

**PERM_VIOL_FIRST_STICKY** (sf_albion_perm): A latched first-violation record is never overwritten before PERM_VIOL_CLEAR.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate PERM-M04-LOG-OVERWRITE
# raw tool commands: build/PERM-NW8-IND__PERM-M04-LOG-OVERWRITE/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 |
|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 |
| `rg_err` | 0 | 0 | 1 | 0 |
| `rg_off` | 0 | 10 | 20 | 0 |
| `rg_wdata` | 0 | 1 | 1 | 0 |
| `rg_we` | 0 | 1 | 1 | 0 |
| `rst_free` | 0 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 |
| `smt_clock` | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 |
| `viol_addr_i` | 0 | 20 | 80000000 | 0 |
| `viol_domain_i` | 0 | 0 | 0 | 0 |
| `viol_i` | 0 | 1 | 1 | 0 |
| `viol_master_i` | 0 | 0 | 0 | 0 |
| `viol_we_i` | 0 | 0 | 0 | 0 |

Full waveform: `build/PERM-NW8-IND__PERM-M04-LOG-OVERWRITE/bmc.vcd` (open with GTKWave).

