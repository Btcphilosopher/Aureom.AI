# Counterexample report: DMA-D4-BMC@DMA-M01-LEN-LIMIT

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M01-LEN-LIMIT`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 0
* violated assertions: `A_DMA_VALIDATION_EXACT`

**DMA_VALIDATION_EXACT** (sf_albion_dma): The BADPARAM decision equals the documented rules exactly: LEN!=0, multiple of 4, <= DMA_MAX_LEN, aligned DST (SRC unless fill), no 2^32 wrap.

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M01-LEN-LIMIT
# raw tool commands: build/DMA-D4-BMC__DMA-M01-LEN-LIMIT/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `clk` | 1 |
| `ev_done_err_o` | 0 |
| `ev_done_ok_o` | 0 |
| `rd_req_ready` | 0 |
| `rd_req_valid` | 0 |
| `rd_rsp_err` | 0 |
| `rd_rsp_rdata` | 0 |
| `rd_rsp_valid` | 0 |
| `rg_err` | 0 |
| `rg_off` | 10 |
| `rg_wdata` | 1 |
| `rg_we` | 1 |
| `rst_free` | 0 |
| `rst_n` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `wr_req_ready` | 0 |
| `wr_req_valid` | 0 |
| `wr_rsp_err` | 0 |
| `wr_rsp_valid` | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M01-LEN-LIMIT/bmc.vcd` (open with GTKWave).

