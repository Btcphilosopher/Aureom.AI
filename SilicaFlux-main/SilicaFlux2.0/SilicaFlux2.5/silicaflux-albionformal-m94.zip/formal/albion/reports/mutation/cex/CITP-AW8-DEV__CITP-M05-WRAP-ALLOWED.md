# Counterexample report: CITP-AW8-DEV@CITP-M05-WRAP-ALLOWED

* job: `CITP-AW8-DEV` (Citadel permission checker, AW=8, with a device region)
* mutation: `CITP-M05-WRAP-ALLOWED`
* engine: smtbmc z3 bmc   depth bound: 2   failing step: 0
* violated assertions: `A_CIT_PERMIT_IMPLIES_SPEC`

**CIT_PERMIT_IMPLIES_SPEC** (sf_citadel_permission): Every permit is justified by the declarative spec: known, ACTIVE, port-bound domain; capability and port/lockdown/DFT rules; range inside an owned window (or one device) with the needed right; no wrap. For ANY table contents.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate CITP-M05-WRAP-ALLOWED
# raw tool commands: build/CITP-AW8-DEV__CITP-M05-WRAP-ALLOWED/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `addr_i` | 60 |
| `attr_i` | 10 |
| `bind_i` | 2 |
| `clk` | 1 |
| `cls_i` | 0 |
| `devrd_i` | 0 |
| `devwr_i` | 0 |
| `dft_active_i` | 0 |
| `dom_i` | 4 |
| `idx_i` | 0 |
| `last_x` | 8000005f |
| `len_i` | 80000000 |
| `lock_deny` | 0 |
| `lockdown_i` | 0 |
| `nowrap` | 0 |
| `op_i` | 1 |
| `permit_o` | 1 |
| `port_isol_i` | 0 |
| `qhold_i` | 0 |
| `qmask_i` | 4 |
| `reason_o` | 0 |
| `rst_free` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `slot_id_i` | 400 |
| `slot_o` | 1 |
| `slot_priv_i` | 0 |
| `slot_secure_i` | 0 |
| `slot_state_i` | 8 |
| `slot_vld_o` | 1 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `sp_bound` | 0 |
| `sp_permit` | 0 |
| `sp_write_ok` | 0 |
| `src_i` | 0 |
| `win_base_i` | e1216161 |
| `win_limit_i` | c00000 |
| `win_r_i` | 4 |
| `win_valid_i` | 4 |
| `win_w_i` | 0 |
| `win_x_i` | 4 |
| `wr_addr` | 0 |

Full waveform: `build/CITP-AW8-DEV__CITP-M05-WRAP-ALLOWED/bmc.vcd` (open with GTKWave).

