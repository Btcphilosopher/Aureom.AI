# Counterexample report: CITG-AW64-BMC@CITG-M04-VERDICT-INHERITED

* job: `CITG-AW64-BMC` (Citadel gate + real permission checker, free table (bounded model check))
* mutation: `CITG-M04-VERDICT-INHERITED`
* engine: smtbmc z3 bmc   depth bound: 10   failing step: 4
* violated assertions: `A_CIT_GATE_DOMAIN_ASSOCIATION`

**CIT_GATE_DOMAIN_ASSOCIATION** (sf_citadel_gate): The domain, op, attributes and address forwarded equal those that were checked.

## Assumptions in force

* `CIT_PARAM_POINT`: Citadel proofs are at a reduced parameter point (NDOM=2, NW=2, NP=1, NDEV=1, NQ=2, AW as stated in the job). The logic is parametric, but 'holds at the small point' implies 'holds at NDOM=8, NW=4' only by an argument, not a proof (the authors' own docs say the same).

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate CITG-M04-VERDICT-INHERITED
# raw tool commands: build/CITG-AW64-BMC__CITG-M04-VERDICT-INHERITED/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 |
|---|---|---|---|---|---|
| `addr_fits` | 1 | 1 | 1 | 1 | 1 |
| `addr_now` | 100000 | 100000 | 100000 | 100000 | 100000 |
| `attr_now` | 1 | 1 | 0 | 0 | 0 |
| `bind_i` | 0 | 0 | 3 | 1 | 0 |
| `chk_addr_o` | 0 | 0 | 100000 | 100000 | 0 |
| `chk_attr_o` | 0 | 0 | 0 | 0 | 4 |
| `chk_cls_o` | 0 | 0 | 0 | 0 | 0 |
| `chk_commit_o` | 0 | 0 | 1 | 0 | 0 |
| `chk_dom_o` | 0 | 0 | 0 | 0 | 80 |
| `chk_idx_o` | 0 | 0 | 0 | 0 | 0 |
| `chk_len_o` | 10 | 10 | 10 | 10 | 10 |
| `chk_op_o` | 0 | 0 | 2 | 2 | 0 |
| `chk_permit_i` | 0 | 0 | 1 | 0 | 0 |
| `chk_status_i` | 0 | 0 | 0 | 0 | 0 |
| `chk_valid_o` | 0 | 0 | 1 | 1 | 1 |
| `clk` | 1 | 1 | 1 | 1 | 1 |
| `devrd_i` | 0 | 0 | 0 | 0 | 0 |
| `devwr_i` | 0 | 0 | 0 | 0 | 0 |
| `dft_active_i` | 0 | 0 | 0 | 0 | 0 |
| `dom_now` | 0 | 0 | 0 | 0 | 0 |
| `flush_i` | 0 | 0 | 0 | 0 | 0 |
| `lockdown_i` | 0 | 0 | 0 | 0 | 1 |
| `m_req_ready_o` | 1 | 1 | 0 | 1 | 0 |
| `m_req_valid_i` | 0 | 1 | 1 | 1 | 0 |
| `m_rsp_ready_i` | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_valid_o` | 0 | 0 | 0 | 0 | 0 |
| `op_now` | 2 | 2 | 2 | 2 | 2 |
| `outstanding_o` | 0 | 0 | 0 | 0 | 1 |
| `port_isol_i` | 0 | 0 | 0 | 0 | 0 |
| `qhold_i` | 0 | 0 | 0 | 0 | 0 |
| `qmask_i` | 0 | 0 | 0 | 0 | 0 |
| `reason_o` | 1 | 1 | 0 | 8 | 1 |
| `rst_free` | 0 | 1 | 1 | 1 | 1 |
| `rst_n` | 0 | 1 | 1 | 1 | 1 |
| `sf_first` | 1 | 0 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 | 4 |
| `slot_id_i` | 0 | 0 | 0 | 100 | 0 |
| `slot_o` | 0 | 0 | 0 | 0 | 0 |
| `slot_priv_i` | 0 | 0 | 0 | 0 | 0 |
| `slot_secure_i` | 0 | 0 | 0 | 0 | 0 |
| `slot_state_i` | 0 | 0 | a | 2 | 0 |
| `slot_vld_o` | 0 | 0 | 1 | 1 | 0 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 | 4 |
| `sn_addr` | 100000 | 100000 | 100000 | 100000 | 100000 |
| `sn_attr` | 1 | 1 | 1 | 0 | 0 |
| `sn_dom` | 0 | 0 | 0 | 0 | 0 |

Full waveform: `build/CITG-AW64-BMC__CITG-M04-VERDICT-INHERITED/bmc.vcd` (open with GTKWave).

