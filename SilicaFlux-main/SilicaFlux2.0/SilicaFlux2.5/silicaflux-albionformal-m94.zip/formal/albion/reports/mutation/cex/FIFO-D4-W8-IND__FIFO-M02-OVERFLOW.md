# Counterexample report: FIFO-D4-W8-IND@FIFO-M02-OVERFLOW

* job: `FIFO-D4-W8-IND` (FIFO occupancy/flags/order, DEPTH=4 (k-induction))
* mutation: `FIFO-M02-OVERFLOW`
* engine: smtbmc z3 bmc   depth bound: 8   failing step: 6
* violated assertions: `A_FIFO_ORDER`, `L_FIFO_MEM_MODEL`

**FIFO_ORDER** (sf_albion_fifo): The head always equals the oldest accepted, not yet popped entry of an independent reference queue (strict FIFO order, no loss, no duplication).
**L_FIFO_MEM_MODEL** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FIFO-M02-OVERFLOW
# raw tool commands: build/FIFO-D4-W8-IND__FIFO-M02-OVERFLOW/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 | t=5 | t=6 |
|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `count` | 0 | 0 | 1 | 2 | 3 | 4 | 5 |
| `empty` | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `full` | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| `head` | 1 | 1 | 0 | 0 | 0 | 0 | 2 |
| `pop` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `push` | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `push_data` | 0 | 0 | 0 | 0 | 0 | 2 | 0 |
| `rst_free` | 0 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 | 4 | 5 | 6 |

Full waveform: `build/FIFO-D4-W8-IND__FIFO-M02-OVERFLOW/bmc.vcd` (open with GTKWave).

