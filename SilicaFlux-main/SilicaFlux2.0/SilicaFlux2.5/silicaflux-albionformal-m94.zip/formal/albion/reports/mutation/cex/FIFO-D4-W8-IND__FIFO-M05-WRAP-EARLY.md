# Counterexample report: FIFO-D4-W8-IND@FIFO-M05-WRAP-EARLY

* job: `FIFO-D4-W8-IND` (FIFO occupancy/flags/order, DEPTH=4 (k-induction))
* mutation: `FIFO-M05-WRAP-EARLY`
* engine: smtbmc z3 bmc   depth bound: 8   failing step: 4
* violated assertions: `L_FIFO_PTR_COUNT`

**L_FIFO_PTR_COUNT** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FIFO-M05-WRAP-EARLY
# raw tool commands: build/FIFO-D4-W8-IND__FIFO-M05-WRAP-EARLY/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 |
|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 |
| `count` | 0 | 0 | 1 | 1 | 1 |
| `empty` | 1 | 1 | 0 | 0 | 0 |
| `full` | 0 | 0 | 0 | 0 | 0 |
| `head` | f0 | f0 | 4 | 8 | 0 |
| `pop` | 0 | 0 | 1 | 1 | 0 |
| `push` | 1 | 1 | 1 | 1 | 0 |
| `push_data` | 0 | 4 | 8 | 0 | 0 |
| `rst_free` | 0 | 1 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 | 4 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 | 4 |

Full waveform: `build/FIFO-D4-W8-IND__FIFO-M05-WRAP-EARLY/bmc.vcd` (open with GTKWave).

