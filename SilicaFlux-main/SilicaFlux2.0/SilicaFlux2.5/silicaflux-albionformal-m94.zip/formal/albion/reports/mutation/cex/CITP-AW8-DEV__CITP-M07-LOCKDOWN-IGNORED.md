# Counterexample report: CITP-AW8-DEV@CITP-M07-LOCKDOWN-IGNORED

* job: `CITP-AW8-DEV` (Citadel permission checker, AW=8, with a device region)
* mutation: `CITP-M07-LOCKDOWN-IGNORED`
* engine: smtbmc z3 bmc   depth bound: 2   failing step: 0
* violated assertions: `A_CIT_ISOLATION_AND_LOCKDOWN`

**CIT_ISOLATION_AND_LOCKDOWN** (sf_citadel_permission): Isolated ports, DFT access and (non-ROOT/MGMT during) lockdown are never permitted.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate CITP-M07-LOCKDOWN-IGNORED
# raw tool commands: build/CITP-AW8-DEV__CITP-M07-LOCKDOWN-IGNORED/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `addr_i` | c0 |
| `attr_i` | 10 |
| `bind_i` | 1 |
| `clk` | 1 |
| `cls_i` | 1 |
| `devrd_i` | 0 |
| `devwr_i` | 1 |
| `dft_active_i` | 0 |
| `dom_i` | 2 |
| `idx_i` | 0 |
| `last_x` | 0 |
| `len_i` | 40 |
| `lock_deny` | 1 |
| `lockdown_i` | 1 |
| `nowrap` | 0 |
| `op_i` | 1 |
| `permit_o` | 1 |
| `port_isol_i` | 0 |
| `qhold_i` | 0 |
| `qmask_i` | 1 |
| `reason_o` | 0 |
| `rst_free` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `slot_id_i` | 2 |
| `slot_o` | 0 |
| `slot_priv_i` | 0 |
| `slot_secure_i` | 0 |
| `slot_state_i` | e |
| `slot_vld_o` | 1 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `sp_bound` | 0 |
| `sp_permit` | 0 |
| `sp_write_ok` | 0 |
| `src_i` | 0 |
| `win_base_i` | 41414141 |
| `win_limit_i` | ffffffff |
| `win_r_i` | 0 |
| `win_valid_i` | f |
| `win_w_i` | 0 |
| `win_x_i` | 0 |
| `wr_addr` | 0 |

Full waveform: `build/CITP-AW8-DEV__CITP-M07-LOCKDOWN-IGNORED/bmc.vcd` (open with GTKWave).

