# Counterexample report: FIFO-D4-W8-IND@FIFO-M03-UNDERFLOW

* job: `FIFO-D4-W8-IND` (FIFO occupancy/flags/order, DEPTH=4 (k-induction))
* mutation: `FIFO-M03-UNDERFLOW`
* engine: smtbmc z3 bmc   depth bound: 8   failing step: 2
* violated assertions: `A_FIFO_COUNT_MODEL`

**FIFO_COUNT_MODEL** (sf_albion_fifo): count equals an independent reference counter (push ignored when full, pop ignored when empty).

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FIFO-M03-UNDERFLOW
# raw tool commands: build/FIFO-D4-W8-IND__FIFO-M03-UNDERFLOW/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 |
|---|---|---|---|
| `clk` | 1 | 1 | 1 |
| `count` | 0 | 0 | 0 |
| `empty` | 1 | 1 | 1 |
| `full` | 0 | 0 | 0 |
| `head` | 0 | 0 | 0 |
| `pop` | 0 | 1 | 0 |
| `push` | 1 | 1 | 0 |
| `push_data` | 49 | 55 | 0 |
| `rst_free` | 0 | 1 | 0 |
| `rst_n` | 0 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 |
| `smt_clock` | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 |

Full waveform: `build/FIFO-D4-W8-IND__FIFO-M03-UNDERFLOW/bmc.vcd` (open with GTKWave).

