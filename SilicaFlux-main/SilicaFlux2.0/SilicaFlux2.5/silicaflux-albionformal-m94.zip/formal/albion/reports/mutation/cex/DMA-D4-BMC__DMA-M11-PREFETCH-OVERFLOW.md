# Counterexample report: DMA-D4-BMC@DMA-M11-PREFETCH-OVERFLOW

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M11-PREFETCH-OVERFLOW`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 9
* violated assertions: `A_DMA_FIFO_BOUNDS`, `L_DMA_FIFO_ROOM`

**DMA_FIFO_BOUNDS** (sf_albion_dma): FIFO count <= DEPTH and count + outstanding prefetch <= DEPTH (prefetch can never overflow).
**L_DMA_FIFO_ROOM** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M11-PREFETCH-OVERFLOW
# raw tool commands: build/DMA-D4-BMC__DMA-M11-PREFETCH-OVERFLOW/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=2 | t=3 | t=4 | t=5 | t=6 | t=7 | t=8 | t=9 |
|---|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ev_done_err_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ev_done_ok_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_req_ready` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rd_req_valid` | 0 | 0 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rd_rsp_err` | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_rdata` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_valid` | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| `rg_err` | 0 | 1 | 1 | 0 | 0 | 0 | 0 | 0 |
| `rg_off` | 10 | 40 | 100 | 0 | 0 | 0 | 0 | 0 |
| `rg_wdata` | 1 | 2 | 10000 | 2 | 40 | 400 | 2 | 0 |
| `rg_we` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rst_free` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
| `wr_req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `wr_req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 1 | 1 |
| `wr_rsp_err` | 0 | 0 | 4 | 2 | 2 | 1 | 2 | 0 |
| `wr_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M11-PREFETCH-OVERFLOW/bmc.vcd` (open with GTKWave).

