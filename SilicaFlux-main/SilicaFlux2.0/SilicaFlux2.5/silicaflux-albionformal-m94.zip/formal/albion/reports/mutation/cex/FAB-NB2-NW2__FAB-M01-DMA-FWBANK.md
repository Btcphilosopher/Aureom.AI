# Counterexample report: FAB-NB2-NW2@FAB-M01-DMA-FWBANK

* job: `FAB-NB2-NW2` (DataFabric, NB=2 NW=2)
* mutation: `FAB-M01-DMA-FWBANK`
* engine: smtbmc z3 bmc   depth bound: 4   failing step: 0
* violated assertions: `A_FAB_DENIED_NOT_FORWARDED`

**FAB_DENIED_NOT_FORWARDED** (sf_albion_datafabric): A request the spec model denies (undecoded or not permitted) is never presented to any slave.

## Assumptions in force

* `MASTER_1PO`: Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation).
* `SLAVE_RSP_MATCH`: A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FAB-M01-DMA-FWBANK
# raw tool commands: build/FAB-NB2-NW2__FAB-M01-DMA-FWBANK/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `boot_mode` | 1 |
| `clk` | 1 |
| `decerr_o` | 0 |
| `m_req_domain` | 400 |
| `m_req_ready` | 0 |
| `m_req_valid` | 6 |
| `m_req_we` | 0 |
| `m_req_wstrb` | 0 |
| `m_rsp_valid` | 0 |
| `rst_free` | 0 |
| `rst_n` | 0 |
| `s_req_id` | 81 |
| `s_req_ready` | 0 |
| `s_req_valid` | 9 |
| `s_rsp_err` | 0 |
| `s_rsp_id` | 0 |
| `s_rsp_valid` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `viol_o` | 0 |
| `win_attr` | 3403 |
| `win_base` | 200002001 |
| `win_limit` | 20000000c0000000 |

Full waveform: `build/FAB-NB2-NW2__FAB-M01-DMA-FWBANK/bmc.vcd` (open with GTKWave).

