# Counterexample report: CITP-AW8-DEV@CITP-M10-DEVWRITE-VIA-READ

* job: `CITP-AW8-DEV` (Citadel permission checker, AW=8, with a device region)
* mutation: `CITP-M10-DEVWRITE-VIA-READ`
* engine: smtbmc z3 bmc   depth bound: 2   failing step: 0
* violated assertions: `A_CIT_WRITE_NEEDS_WRITE_RIGHT`

**CIT_WRITE_NEEDS_WRITE_RIGHT** (sf_citadel_permission): A permitted WRITE is backed by a window with W containing the whole range, or a device region wholly containing it with write permission.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate CITP-M10-DEVWRITE-VIA-READ
# raw tool commands: build/CITP-AW8-DEV__CITP-M10-DEVWRITE-VIA-READ/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `addr_i` | c0 |
| `attr_i` | c |
| `bind_i` | 1 |
| `clk` | 1 |
| `cls_i` | 0 |
| `devrd_i` | 1 |
| `devwr_i` | 2 |
| `dft_active_i` | 0 |
| `dom_i` | 4 |
| `idx_i` | 0 |
| `last_x` | df |
| `len_i` | 20 |
| `lock_deny` | 0 |
| `lockdown_i` | 0 |
| `nowrap` | 1 |
| `op_i` | 2 |
| `permit_o` | 1 |
| `port_isol_i` | 0 |
| `qhold_i` | 0 |
| `qmask_i` | 0 |
| `reason_o` | 0 |
| `rst_free` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `slot_id_i` | 404 |
| `slot_o` | 0 |
| `slot_priv_i` | 3 |
| `slot_secure_i` | 3 |
| `slot_state_i` | a |
| `slot_vld_o` | 1 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `sp_bound` | 0 |
| `sp_permit` | 0 |
| `sp_write_ok` | 0 |
| `src_i` | 0 |
| `win_base_i` | 41416041 |
| `win_limit_i` | e0e0e0e0 |
| `win_r_i` | 0 |
| `win_valid_i` | f |
| `win_w_i` | 0 |
| `win_x_i` | 0 |
| `wr_addr` | 1 |

Full waveform: `build/CITP-AW8-DEV__CITP-M10-DEVWRITE-VIA-READ/bmc.vcd` (open with GTKWave).

