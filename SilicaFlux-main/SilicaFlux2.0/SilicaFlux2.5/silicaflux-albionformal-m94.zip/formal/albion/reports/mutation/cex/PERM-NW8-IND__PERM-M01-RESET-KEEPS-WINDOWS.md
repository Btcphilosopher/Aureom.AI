# Counterexample report: PERM-NW8-IND@PERM-M01-RESET-KEEPS-WINDOWS

* job: `PERM-NW8-IND` (Permission window table + violation log, NW=8 (k-induction))
* mutation: `PERM-M01-RESET-KEEPS-WINDOWS`
* engine: smtbmc z3 bmc   depth bound: 6   failing step: 1
* violated assertions: `A_PERM_RESET_DEFAULT_DENY`

**PERM_RESET_DEFAULT_DENY** (sf_albion_perm): After reset every window is invalid (default deny) and the violation counter is 0.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate PERM-M01-RESET-KEEPS-WINDOWS
# raw tool commands: build/PERM-NW8-IND__PERM-M01-RESET-KEEPS-WINDOWS/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 |
|---|---|---|
| `clk` | 1 | 1 |
| `rg_err` | 0 | 0 |
| `rg_off` | 0 | 0 |
| `rg_wdata` | 0 | 0 |
| `rg_we` | 0 | 0 |
| `rst_free` | 0 | 0 |
| `rst_n` | 0 | 0 |
| `sf_first` | 1 | 0 |
| `sf_live` | 0 | 1 |
| `sf_step` | 0 | 1 |
| `smt_clock` | 1 | 1 |
| `smt_step` | 0 | 1 |
| `viol_addr_i` | 0 | 0 |
| `viol_domain_i` | 0 | 0 |
| `viol_i` | 0 | 0 |
| `viol_master_i` | 0 | 0 |
| `viol_we_i` | 0 | 0 |

Full waveform: `build/PERM-NW8-IND__PERM-M01-RESET-KEEPS-WINDOWS/bmc.vcd` (open with GTKWave).

