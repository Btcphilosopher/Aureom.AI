# Counterexample report: CITT-BMC@CITT-M04-EXCL-NEEDS-BOTH

* job: `CITT-BMC` (Citadel table+permission: invalidation, default-deny, privilege, exclusivity (bounded))
* mutation: `CITT-M04-EXCL-NEEDS-BOTH`
* engine: smtbmc z3 bmc   depth bound: 8   failing step: 5
* violated assertions: `A_CIT_TBL_EXCLUSIVE_DISJOINT`

**CIT_TBL_EXCLUSIVE_DISJOINT** (sf_citadel_domain_table): Two valid windows of different slots, at least one exclusive, are disjoint (INV-EXCL).

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate CITT-M04-EXCL-NEEDS-BOTH
# raw tool commands: build/CITT-BMC__CITT-M04-EXCL-NEEDS-BOTH/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 | t=5 |
|---|---|---|---|---|---|---|
| `a` | 2 | 2 | 2 | 2 | 2 | 2 |
| `addr_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `attr_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `b` | 2 | 2 | 2 | 2 | 2 | 2 |
| `bind_o` | 0 | 0 | 0 | 0 | 0 | 0 |
| `cfg_en_i` | 0 | 1 | 1 | 1 | 1 | 0 |
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 |
| `cls_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `cmd_arg_dom_i` | 0 | 20 | 10 | 80 | 0 | 0 |
| `cmd_data0_i` | 0 | 1 | 2 | 1 | 1 | 0 |
| `cmd_data1_i` | 0 | 1 | 8 | 0 | 21 | 0 |
| `cmd_dom_i` | 0 | 1 | 1 | 1 | 1 | 0 |
| `cmd_flags_i` | 0 | 0 | 3 | 0 | c | 0 |
| `cmd_op_i` | 0 | 1 | 2 | 1 | 2 | 0 |
| `cmd_port_i` | 0 | 1 | 1 | 1 | 0 | 0 |
| `cmd_priv_i` | 0 | 1 | 1 | 1 | 1 | 0 |
| `cmd_slot_i` | 0 | 1 | 1 | 0 | 0 | 0 |
| `cmd_valid_i` | 0 | 1 | 1 | 1 | 1 | 0 |
| `cmd_win_i` | 0 | 0 | 0 | 0 | 1 | 0 |
| `devrd_o` | 0 | 0 | 0 | 0 | 0 | 0 |
| `devwr_o` | 0 | 0 | 0 | 0 | 0 | 0 |
| `dft_active_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `dom_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `excl_ok` | 1 | 1 | 1 | 1 | 1 | 0 |
| `fv_rev` | 0 | 0 | 0 | 0 | 0 | 0 |
| `fv_rid` | 0 | 0 | 0 | 0 | 0 | 0 |
| `fv_tk` | 0 | 0 | 0 | 0 | 0 | 0 |
| `fv_ts` | 0 | 0 | 0 | 0 | 0 | 0 |
| `fv_wclr` | 0 | 0 | 0 | 0 | 0 | 0 |
| `i` | 2 | 2 | 2 | 2 | 2 | 2 |
| `idx_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `j` | 2 | 2 | 2 | 2 | 2 | 2 |
| `len_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `lock_o` | 0 | 0 | 0 | 0 | 0 | 0 |
| `lockdown_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `look_dom_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `op_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `own_addr_i` | 0 | 0 | 0 | 0 | 0 | 0 |
| `p_arg` | 0 | 0 | 20 | 10 | 80 | 0 |
| `p_dom` | 0 | 0 | 1 | 1 | 1 | 1 |
| `p_id` | 0 | 0 | 0 | 2000 | 2000 | 2080 |
| `p_ok` | 0 | 0 | 1 | 1 | 1 | 1 |
| `p_op` | 0 | 0 | 1 | 2 | 1 | 2 |
| `p_priv` | 0 | 0 | 1 | 1 | 1 | 1 |
| `p_slot` | 0 | 0 | 1 | 1 | 0 | 0 |
| `p_unpriv` | 1 | 1 | 0 | 0 | 0 | 0 |
| `p_valid` | 0 | 0 | 1 | 1 | 1 | 1 |
| `p_win` | 0 | 0 | 0 | 0 | 0 | 1 |

Full waveform: `build/CITT-BMC__CITT-M04-EXCL-NEEDS-BOTH/bmc.vcd` (open with GTKWave).

