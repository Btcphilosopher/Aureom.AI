# Counterexample report: DMA-D4-BMC@DMA-M07-BYTES-DOUBLE

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M07-BYTES-DOUBLE`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 6
* violated assertions: `L_DMA_BYTES_EQ_WR_IDX`

**L_DMA_BYTES_EQ_WR_IDX** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M07-BYTES-DOUBLE
# raw tool commands: build/DMA-D4-BMC__DMA-M07-BYTES-DOUBLE/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 | t=5 | t=6 |
|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ev_done_err_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ev_done_ok_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_req_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_err` | 0 | 0 | 0 | 0 | 1 | 0 | 0 |
| `rd_rsp_rdata` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rg_err` | 0 | 0 | 0 | 1 | 1 | 0 | 0 |
| `rg_off` | 0 | 8 | 10 | 200 | 2 | 0 | 0 |
| `rg_wdata` | 0 | 1000 | 3 | 1000 | 4000 | 8000000 | 0 |
| `rg_we` | 0 | 1 | 1 | 0 | 0 | 0 | 0 |
| `rst_free` | 0 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 | 4 | 5 | 6 |
| `wr_req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 0 |
| `wr_req_valid` | 0 | 0 | 0 | 0 | 1 | 1 | 0 |
| `wr_rsp_err` | 0 | 0 | 0 | 0 | 4 | 0 | 0 |
| `wr_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 1 | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M07-BYTES-DOUBLE/bmc.vcd` (open with GTKWave).

