# Counterexample report: FAB-ARB-NB4-NW2@FAB-M20-RR-STUCK

* job: `FAB-ARB-NB4-NW2` (DataFabric bounded arbitration latency <= NM-1 waits (CONDITIONAL, FV_ARB))
* mutation: `FAB-M20-RR-STUCK`
* engine: smtbmc z3 bmc   depth bound: 10   failing step: 5
* violated assertions: `A_FAB_ARB_BOUNDED_WAIT`

**FAB_ARB_BOUNDED_WAIT** (sf_albion_datafabric): CONDITIONAL on SLAVE_READY_ALWAYS: a continuously eligible request to one slave is granted after at most NM-1 = 3 waiting cycles (round-robin bound). A bounded-latency safety property, not a liveness claim.

## Assumptions in force

* `MASTER_1PO`: Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation).
* `SLAVE_READY_ALWAYS`: Used ONLY by the bounded-arbitration-latency job: every slave has s_req_ready = 1 in every cycle.
* `SLAVE_RSP_MATCH`: A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FAB-M20-RR-STUCK
# raw tool commands: build/FAB-ARB-NB4-NW2__FAB-M20-RR-STUCK/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 | t=4 | t=5 |
|---|---|---|---|---|---|---|
| `boot_mode` | 0 | 1 | 1 | 1 | 1 | 0 |
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 |
| `decerr_o` | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_req_domain` | 0 | 0 | 0 | 480 | 200 | 0 |
| `m_req_ready` | 0 | 5 | 7 | 5 | 7 | 0 |
| `m_req_valid` | 0 | d | f | d | f | 0 |
| `m_req_we` | 0 | 4 | 4 | 4 | 0 | 0 |
| `m_req_wstrb` | 0 | 0 | 0 | 0 | 0 | 0 |
| `m_rsp_valid` | 0 | 0 | 5 | 5 | 7 | 0 |
| `rst_free` | 0 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 1 | 1 | 0 |
| `s_req_id` | 0 | 8 | 4 | 0 | 48 | 0 |
| `s_req_ready` | 0 | 3f | 3f | 3f | 3f | 3f |
| `s_req_valid` | 0 | 6 | 6 | 4 | e | 0 |
| `s_rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 |
| `s_rsp_id` | 0 | 652 | 8 | 8 | 4 | 960 |
| `s_rsp_valid` | 0 | 0 | 6 | 4 | 6 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 | 4 | 5 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 | 4 | 5 |
| `viol_o` | 0 | 0 | 1 | 0 | 0 | 0 |
| `win_attr` | 0 | 7005 | 303007 | 803405 | 203100 | 0 |
| `win_base` | 0 | 8990404000000012 | c401c00100000001 | 1200100014001 | 12000c002 | 0 |
| `win_limit` | 0 | 2000000 | 4000000000008000 | 8000000080000000 | 8000000000000000 | 0 |

Full waveform: `build/FAB-ARB-NB4-NW2__FAB-M20-RR-STUCK/bmc.vcd` (open with GTKWave).

