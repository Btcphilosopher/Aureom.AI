# Counterexample report: FAB-NB2-NW2@FAB-M11-SRAM-OFF-BY-ONE

* job: `FAB-NB2-NW2` (DataFabric, NB=2 NW=2)
* mutation: `FAB-M11-SRAM-OFF-BY-ONE`
* engine: smtbmc z3 bmc   depth bound: 4   failing step: 0
* violated assertions: `A_FAB_NO_INVALID_ROUTE`

**FAB_NO_INVALID_ROUTE** (sf_albion_datafabric): Every request presented to a slave is eligible (decoded + permitted per the spec model) and addressed to THAT slave: exact decode, no aliasing, no unaddressed slave, bank range respected.

## Assumptions in force

* `MASTER_1PO`: Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation).
* `SLAVE_RSP_MATCH`: A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FAB-M11-SRAM-OFF-BY-ONE
# raw tool commands: build/FAB-NB2-NW2__FAB-M11-SRAM-OFF-BY-ONE/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `boot_mode` | 1 |
| `clk` | 1 |
| `decerr_o` | 0 |
| `m_req_domain` | 440 |
| `m_req_ready` | 0 |
| `m_req_valid` | b |
| `m_req_we` | 4 |
| `m_req_wstrb` | 0 |
| `m_rsp_valid` | 0 |
| `rst_free` | 0 |
| `rst_n` | 0 |
| `s_req_id` | 43 |
| `s_req_ready` | 0 |
| `s_req_valid` | d |
| `s_rsp_err` | 0 |
| `s_rsp_id` | 0 |
| `s_rsp_valid` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `viol_o` | 0 |
| `win_attr` | 403 |
| `win_base` | c000840240008801 |
| `win_limit` | c0008000 |

Full waveform: `build/FAB-NB2-NW2__FAB-M11-SRAM-OFF-BY-ONE/bmc.vcd` (open with GTKWave).

