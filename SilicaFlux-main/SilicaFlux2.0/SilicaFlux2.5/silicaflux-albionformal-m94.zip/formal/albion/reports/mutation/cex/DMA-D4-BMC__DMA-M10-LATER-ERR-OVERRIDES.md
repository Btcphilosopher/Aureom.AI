# Counterexample report: DMA-D4-BMC@DMA-M10-LATER-ERR-OVERRIDES

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M10-LATER-ERR-OVERRIDES`
* engine: smtbmc z3 bmc   depth bound: 16   failing step: 9
* violated assertions: `A_DMA_ACCOUNTING_ERR`

**DMA_ACCOUNTING_ERR** (sf_albion_dma): An error completion has BYTES_DONE = 4 x (index of the first failing beat) and a non-NONE error code.

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M10-LATER-ERR-OVERRIDES
# raw tool commands: build/DMA-D4-BMC__DMA-M10-LATER-ERR-OVERRIDES/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=2 | t=3 | t=4 | t=5 | t=6 | t=7 | t=8 | t=9 |
|---|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ev_done_err_o` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| `ev_done_ok_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_req_ready` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 |
| `rd_req_valid` | 0 | 0 | 1 | 1 | 1 | 1 | 0 | 0 |
| `rd_rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 | 4 | 0 |
| `rd_rsp_rdata` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_valid` | 0 | 0 | 0 | 1 | 1 | 1 | 1 | 0 |
| `rg_err` | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| `rg_off` | 10 | 8 | 0 | 0 | 200 | 0 | 0 | 0 |
| `rg_wdata` | 41 | 100000 | 20 | 4000 | 8002 | 2 | 2 | 0 |
| `rg_we` | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rst_free` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 |
| `wr_req_ready` | 0 | 0 | 0 | 1 | 1 | 0 | 1 | 0 |
| `wr_req_valid` | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| `wr_rsp_err` | 0 | 0 | 4 | 1 | 4 | 1 | 1 | 0 |
| `wr_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M10-LATER-ERR-OVERRIDES/bmc.vcd` (open with GTKWave).

