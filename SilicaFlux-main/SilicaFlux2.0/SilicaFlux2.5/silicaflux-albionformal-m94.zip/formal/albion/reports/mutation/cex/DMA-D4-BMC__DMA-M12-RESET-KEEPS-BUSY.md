# Counterexample report: DMA-D4-BMC@DMA-M12-RESET-KEEPS-BUSY

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M12-RESET-KEEPS-BUSY`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 1
* violated assertions: `A_DMA_RESET_STATE`, `L_DMA_DESC_LATCHED`

**DMA_RESET_STATE** (sf_albion_dma): After reset: idle, not done/error, BYTES_DONE and CYCLES 0, error code NONE, no traffic.
**L_DMA_DESC_LATCHED** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M12-RESET-KEEPS-BUSY
# raw tool commands: build/DMA-D4-BMC__DMA-M12-RESET-KEEPS-BUSY/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 |
|---|---|---|
| `clk` | 1 | 1 |
| `ev_done_err_o` | 0 | 0 |
| `ev_done_ok_o` | 1 | 1 |
| `rd_req_ready` | 0 | 0 |
| `rd_req_valid` | 0 | 0 |
| `rd_rsp_err` | 0 | 0 |
| `rd_rsp_rdata` | 0 | 0 |
| `rd_rsp_valid` | 0 | 0 |
| `rg_err` | 0 | 0 |
| `rg_off` | 0 | 0 |
| `rg_wdata` | 0 | 0 |
| `rg_we` | 0 | 0 |
| `rst_free` | 0 | 0 |
| `rst_n` | 0 | 0 |
| `sf_first` | 1 | 0 |
| `sf_live` | 0 | 1 |
| `sf_step` | 0 | 1 |
| `smt_clock` | 1 | 1 |
| `smt_step` | 0 | 1 |
| `wr_req_ready` | 0 | 0 |
| `wr_req_valid` | 0 | 0 |
| `wr_rsp_err` | 0 | 0 |
| `wr_rsp_valid` | 0 | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M12-RESET-KEEPS-BUSY/bmc.vcd` (open with GTKWave).

