# Counterexample report: SRAM-MACRO-IND@SRAM-M12-MACRO-ADDR-FLIP

* job: `SRAM-MACRO-IND` (SRAM macro memory contract (k-induction))
* mutation: `SRAM-M12-MACRO-ADDR-FLIP`
* engine: smtbmc z3 bmc   depth bound: 8   failing step: 2
* violated assertions: `A_SRAM_MACRO_CONTRACT`

**SRAM_MACRO_CONTRACT** (sf_albion_sram_macro): The memory macro returns the codeword most recently written to the addressed word. Discharges the MACRO_CONTRACT assumption of the bank-level proofs.

## Assumptions in force


## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate SRAM-M12-MACRO-ADDR-FLIP
# raw tool commands: build/SRAM-MACRO-IND__SRAM-M12-MACRO-ADDR-FLIP/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 |
|---|---|---|---|
| `addr` | 0 | 0 | 0 |
| `clk` | 1 | 1 | 1 |
| `en` | 1 | 1 | 0 |
| `rdata` | 4000000 | 4000000 | 2000000 |
| `rst_free` | 0 | 0 | 0 |
| `sf_first` | 1 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 |
| `smt_clock` | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 |
| `wdata` | 0 | 1414020911 | 0 |
| `we` | 1 | 0 | 0 |

Full waveform: `build/SRAM-MACRO-IND__SRAM-M12-MACRO-ADDR-FLIP/bmc.vcd` (open with GTKWave).

