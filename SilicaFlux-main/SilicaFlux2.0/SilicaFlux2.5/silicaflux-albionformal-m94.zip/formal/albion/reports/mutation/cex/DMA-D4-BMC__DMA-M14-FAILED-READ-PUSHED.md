# Counterexample report: DMA-D4-BMC@DMA-M14-FAILED-READ-PUSHED

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M14-FAILED-READ-PUSHED`
* engine: smtbmc z3 bmc   depth bound: 16   failing step: 8
* violated assertions: `A_DMA_ACCOUNTING_ERR`

**DMA_ACCOUNTING_ERR** (sf_albion_dma): An error completion has BYTES_DONE = 4 x (index of the first failing beat) and a non-NONE error code.

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M14-FAILED-READ-PUSHED
# raw tool commands: build/DMA-D4-BMC__DMA-M14-FAILED-READ-PUSHED/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=1 | t=2 | t=3 | t=4 | t=5 | t=6 | t=7 | t=8 |
|---|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ev_done_err_o` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |
| `ev_done_ok_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_req_ready` | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `rd_req_valid` | 0 | 0 | 0 | 1 | 0 | 0 | 0 | 0 |
| `rd_rsp_err` | 0 | 0 | 0 | 4 | 5 | 1 | 5 | 0 |
| `rd_rsp_rdata` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rd_rsp_valid` | 0 | 0 | 0 | 0 | 1 | 0 | 0 | 0 |
| `rg_err` | 0 | 0 | 1 | 0 | 0 | 0 | 0 | 0 |
| `rg_off` | 8 | 10 | 50 | 0 | 0 | 0 | 0 | 0 |
| `rg_wdata` | 44 | 60481 | 40002 | 400 | 2 | 2 | 2 | 0 |
| `rg_we` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rst_free` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
| `wr_req_ready` | 0 | 0 | 0 | 0 | 1 | 1 | 0 | 0 |
| `wr_req_valid` | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |
| `wr_rsp_err` | 0 | 0 | 0 | 1 | 4 | 1 | 0 | 0 |
| `wr_rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 1 | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M14-FAILED-READ-PUSHED/bmc.vcd` (open with GTKWave).

