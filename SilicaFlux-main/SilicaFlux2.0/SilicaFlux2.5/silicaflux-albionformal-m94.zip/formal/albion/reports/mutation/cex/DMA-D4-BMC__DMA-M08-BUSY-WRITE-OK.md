# Counterexample report: DMA-D4-BMC@DMA-M08-BUSY-WRITE-OK

* job: `DMA-D4-BMC` (DMA correctness, DEPTH=4 (bounded model check from reset))
* mutation: `DMA-M08-BUSY-WRITE-OK`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 3
* violated assertions: `A_DMA_BUSY_WRITE_REJECTED`

**DMA_BUSY_WRITE_REJECTED** (sf_albion_dma): A write to a programming register during a transfer is answered with an error (never silently accepted).

## Assumptions in force

* `DMA_RSP_OUT`: The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate DMA-M08-BUSY-WRITE-OK
# raw tool commands: build/DMA-D4-BMC__DMA-M08-BUSY-WRITE-OK/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 | t=1 | t=2 | t=3 |
|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 |
| `ev_done_err_o` | 0 | 0 | 0 | 0 |
| `ev_done_ok_o` | 0 | 0 | 0 | 0 |
| `rd_req_ready` | 0 | 0 | 0 | 0 |
| `rd_req_valid` | 0 | 0 | 0 | 0 |
| `rd_rsp_err` | 0 | 0 | 0 | 0 |
| `rd_rsp_rdata` | 0 | 0 | 0 | 0 |
| `rd_rsp_valid` | 0 | 0 | 0 | 0 |
| `rg_err` | 0 | 0 | 0 | 0 |
| `rg_off` | 0 | 8 | 10 | 0 |
| `rg_wdata` | 0 | 8 | 5 | 0 |
| `rg_we` | 0 | 1 | 1 | 1 |
| `rst_free` | 0 | 1 | 1 | 0 |
| `rst_n` | 0 | 1 | 1 | 0 |
| `sf_first` | 1 | 0 | 0 | 0 |
| `sf_live` | 0 | 1 | 1 | 1 |
| `sf_step` | 0 | 1 | 2 | 3 |
| `smt_clock` | 1 | 1 | 1 | 1 |
| `smt_step` | 0 | 1 | 2 | 3 |
| `wr_req_ready` | 0 | 0 | 0 | 0 |
| `wr_req_valid` | 0 | 0 | 0 | 0 |
| `wr_rsp_err` | 0 | 0 | 0 | 0 |
| `wr_rsp_valid` | 0 | 0 | 0 | 0 |

Full waveform: `build/DMA-D4-BMC__DMA-M08-BUSY-WRITE-OK/bmc.vcd` (open with GTKWave).

