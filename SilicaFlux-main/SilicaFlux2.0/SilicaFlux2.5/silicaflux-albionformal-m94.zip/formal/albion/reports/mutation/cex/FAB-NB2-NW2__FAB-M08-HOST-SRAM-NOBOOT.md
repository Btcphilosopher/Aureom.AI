# Counterexample report: FAB-NB2-NW2@FAB-M08-HOST-SRAM-NOBOOT

* job: `FAB-NB2-NW2` (DataFabric, NB=2 NW=2)
* mutation: `FAB-M08-HOST-SRAM-NOBOOT`
* engine: smtbmc z3 bmc   depth bound: 4   failing step: 0
* violated assertions: `A_FAB_HOST_POLICY`

**FAB_HOST_POLICY** (sf_albion_datafabric): HOST reaches SRAM only in boot mode, never host memory, and MMIO only on MGMT (rw) or TELEM/RAS (read).

## Assumptions in force

* `MASTER_1PO`: Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation).
* `SLAVE_RSP_MATCH`: A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate FAB-M08-HOST-SRAM-NOBOOT
# raw tool commands: build/FAB-NB2-NW2__FAB-M08-HOST-SRAM-NOBOOT/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=0 |
|---|---|
| `boot_mode` | 0 |
| `clk` | 1 |
| `decerr_o` | 0 |
| `m_req_domain` | 100 |
| `m_req_ready` | 0 |
| `m_req_valid` | 8 |
| `m_req_we` | 0 |
| `m_req_wstrb` | 0 |
| `m_rsp_valid` | 0 |
| `rst_free` | 0 |
| `rst_n` | 0 |
| `s_req_id` | 3 |
| `s_req_ready` | 0 |
| `s_req_valid` | 1 |
| `s_rsp_err` | 0 |
| `s_rsp_id` | 0 |
| `s_rsp_valid` | 0 |
| `sf_first` | 1 |
| `sf_live` | 0 |
| `sf_step` | 0 |
| `smt_clock` | 1 |
| `smt_step` | 0 |
| `viol_o` | 0 |
| `win_attr` | 200103 |
| `win_base` | 400200000001 |
| `win_limit` | 80000000 |

Full waveform: `build/FAB-NB2-NW2__FAB-M08-HOST-SRAM-NOBOOT/bmc.vcd` (open with GTKWave).

