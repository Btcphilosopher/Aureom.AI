# Counterexample report: SRAM-W8-IND@SRAM-M04-SCRUB-SHORT

* job: `SRAM-W8-IND` (SRAM bank data/write-enable/reset properties, WORDS=8 (k-induction))
* mutation: `SRAM-M04-SCRUB-SHORT`
* engine: smtbmc z3 bmc   depth bound: 14   failing step: 8
* violated assertions: `L_SRAM_CW_TRACKS_DATA`

**L_SRAM_CW_TRACKS_DATA** ((helper)): Helper invariant (lemma) proven jointly with the claimed properties; never silently assumed.

## Assumptions in force

* `MACRO_CONTRACT`: Bank-level jobs abstract the memory macro by its contract: after a read of a word, rdata equals the codeword most recently written to that word (an unwritten word is never read: the scrub writes every word before the bank accepts traffic).
* `SRAM_NO_INJ`: The RAS error-injection port is idle: inj_arm = 0. Required for the data-correctness (read-after-write) proofs, which are false by design when a fault is injected.

## Reproduce

```bash
cd formal/albion && python3 scripts/albion_formal.py mutate SRAM-M04-SCRUB-SHORT
# raw tool commands: build/SRAM-W8-IND__SRAM-M04-SCRUB-SHORT/repro.sh
```

## Trace (hex; last cycles before and at the violation)

| signal | t=1 | t=2 | t=3 | t=4 | t=5 | t=6 | t=7 | t=8 |
|---|---|---|---|---|---|---|---|---|
| `clk` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `ecc_syndrome_o` | 42 | 42 | 42 | 42 | 42 | 42 | 42 | 42 |
| `ecc_ue_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `ecc_word_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `init_done_o` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| `inj_arm` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inj_mask` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `inj_word` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_domain` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_id` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `req_ready` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 |
| `req_valid` | 0 | 0 | 0 | 0 | 0 | 1 | 0 | 0 |
| `req_wdata` | 0 | 0 | 1010220 | d4f031d2 | 4c866700 | 4c866600 | 807ef | 0 |
| `req_we` | 0 | 0 | 1 | 0 | 0 | 1 | 1 | 0 |
| `req_word` | 0 | 0 | 5 | 4 | 1 | 7 | 1 | 0 |
| `req_wstrb` | 0 | 0 | f | 2 | e | f | 8 | 0 |
| `rsp_err` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rsp_rdata` | 1c000000 | 1c000000 | 1c000000 | 1c000000 | 1c000000 | 1c000000 | 1c000000 | 1c000000 |
| `rsp_valid` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `rst_free` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `rst_n` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 0 |
| `sf_first` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `sf_live` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `sf_step` | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |
| `smt_clock` | 1 | 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| `smt_step` | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 |

Full waveform: `build/SRAM-W8-IND__SRAM-M04-SCRUB-SHORT/bmc.vcd` (open with GTKWave).

