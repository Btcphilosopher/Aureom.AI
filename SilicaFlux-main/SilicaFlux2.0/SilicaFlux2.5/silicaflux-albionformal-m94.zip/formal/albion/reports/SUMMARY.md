# AlbionFormal: results at a glance

Generated 2026-11-17T14:49:43Z. Source of truth: `PROOF_LEDGER.md` (all rows are machine results). Counts are over DISTINCT (module, property) pairs, best result across parameter points; helper lemmas excluded.

| RTL module | properties | PROVEN | PROVEN-COND | BOUNDED | FAIL | TIMEOUT | STALE |
|---|---|---|---|---|---|---|---|
| sf_albion_datafabric | 23 | 0 | 23 | 0 | 0 | 0 | 0 |
| sf_albion_dma | 17 | 0 | 13 | 4 | 0 | 0 | 0 |
| sf_albion_fifo | 4 | 4 | 0 | 0 | 0 | 0 | 0 |
| sf_albion_perm | 11 | 11 | 0 | 0 | 0 | 0 | 0 |
| sf_albion_secded_enc/dec | 3 | 3 | 0 | 0 | 0 | 0 | 0 |
| sf_albion_sram_bank (+secded, macro) | 10 | 0 | 10 | 0 | 0 | 0 | 0 |
| sf_albion_sram_macro | 1 | 0 | 1 | 0 | 0 | 0 | 0 |
| sf_citadel_domain_table | 9 | 0 | 9 | 0 | 0 | 0 | 0 |
| sf_citadel_gate | 6 | 0 | 6 | 0 | 0 | 0 | 0 |
| sf_citadel_permission | 8 | 0 | 8 | 0 | 0 | 0 | 0 |
| **total** | **92** | **18** | **70** | **4** | **0** | **0** | **0** |

*PROVEN* = unbounded, no assumption beyond clock/reset. *PROVEN-COND* = unbounded, conditional on the declared assumptions (see ledger section 5). *BOUNDED* = no counterexample within the stated number of cycles only. Cover/observation rows are counted separately below.

* Cover witnesses: {'COVER-REACHED': 85}
* Mutation campaign: 77 of 80 injected bugs detected; 3 survive with a written waiver; 0 unwaived survivors.
* Counterexamples against the unmutated RTL: 0

## Properties that are only bounded or unresolved

* `DMA_ACCOUNTING_ERR` (sf_albion_dma): **BOUNDED**; jobs DMA-D4-BMC, DMA-D4-IND
* `DMA_ACCOUNTING_OK` (sf_albion_dma): **BOUNDED**; jobs DMA-D4-BMC, DMA-D4-IND
* `DMA_BYTES_BOUND` (sf_albion_dma): **BOUNDED**; jobs DMA-D4-BMC, DMA-D4-IND
* `DMA_COUNTERS_VALID` (sf_albion_dma): **BOUNDED**; jobs DMA-D4-BMC, DMA-D4-IND

## Declared unresolved / not claimed / not applicable

* **U-LIVENESS** [NOT CLAIMED]: Unbounded liveness: every accepted request / every started DMA transfer eventually completes
* **U-DMA-ERRPATH** [BOUNDED (BMC 16 cycles from reset); k-induction not closed]: DMA: unbounded proof of error-path accounting and counter bounds
* **U-SRAM-ECC** [NOT PROVEN at bank level]: SRAM bank with fault injection: single-bit correction / double-bit detection AT BANK LEVEL
* **U-SRAM-SIZE** [PROVEN at WORDS=8 only]: SRAM bank at the product size (WORDS = 4096)
* **U-CIT-SCALE** [PROVEN/BOUNDED at NDOM=2, NW=2, NP=1, NDEV=1, NQ=2 only]: Citadel at product parameters (NDOM=8, NW=4, NP=4, NDEV=7, NQ=16)
* **U-CIT-COMPLETE** [NOT CLAIMED]: Citadel permission checker COMPLETENESS (spec permits => RTL permits)
* **U-TRANSLATION** [NOT APPLICABLE]: Invalidation prevents stale TRANSLATION use
* **U-DOMAINGUARD** [NOT PRESENT]: A module literally named 'DomainGuard'
* **U-OUTOFSCOPE** [NOT VERIFIED]: Blocks not verified
* **U-CDC** [NOT MODELLED]: Reset-deassertion timing, reset-domain crossing, metastability, clock gating, scan/DFT paths
* **U-SBY** [NOT EXECUTED]: SymbiYosys (sby) execution
* **U-SYSTEM** [NOT BUILT]: Composed system proof: closing the assume-guarantee loop MASTER_1PO / DMA_RSP_OUT, and 'illegal DMA requests never change protected memory' (DMA + fabric + SRAM banks)

