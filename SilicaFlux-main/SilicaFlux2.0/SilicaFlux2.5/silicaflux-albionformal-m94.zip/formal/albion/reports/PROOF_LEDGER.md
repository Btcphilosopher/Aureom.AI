# AlbionFormal Proof Ledger (SilicaFlux Module 94)

Generated 2026-11-17T14:49:43Z from `reports/results/*.json`. Every row below is a machine result; nothing is asserted by hand.

## 0. How to read this ledger

| Result class | Meaning |
|---|---|
| **PROVEN** | Unbounded proof, no environment assumption beyond reset/clock. |
| **PROVEN-COND** | Unbounded proof that depends on the listed environment/configuration assumptions. |
| **BOUNDED** | No counterexample up to the stated depth. NOT a proof for longer traces. |
| **FAIL** | Counterexample found. |
| **TIMEOUT** | Solver did not finish; no claim made. |
| **VACUOUS** | Assumptions contradictory; result meaningless. |
| **STALE** | A harness/RTL file changed after this result was produced; re-run required. |
| **COVER-REACHED / COVER-UNREACHED** | A witness trace exists / does not exist under the same environment (vacuity evidence, section 4). |
| **Unproven / not claimed** | Listed in section 7; they have no row above because no proof was produced. |

`Proof depth`: *k-induction k=N* = the property (with helper lemmas) holds in every state reachable in N steps and is inductive, i.e. holds for ALL time; the BMC base case covers N cycles from reset. *BMC N cycles* = exhaustive over all input sequences of length N starting from reset, nothing more.

## 1. Environment and provenance

* **date_utc**: 2026-11-17T14:49:43Z
* **host**: Linux 6.18.44-fc-v553 x86_64, 4 cores
* **yosys**: Yosys 0.33 (git sha1 2584903a060)
* **z3**: Z3 version 4.8.12 - 64 bit
* **cvc5**: This is cvc5 version 1.1.2
* **yosys-abc**: /usr/bin/yosys-abc
* **python**: 3.13.18
* **sby**: NOT INSTALLED - results come from the native driver (same yosys/smtbmc/abc flow); generated job.sby files were never executed
* **backend**: native (yosys + yosys-smtbmc + yosys-abc)
* **vendored RTL**: UNMODIFIED snapshot, hashes verified (vendor/SOURCES.sha256)
* **RTL sources**: SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-albion-p90.zip (Albion P90 rtl/albion) and silicaflux-citadel-p89.zip (Citadel P89 rtl/albion)

## 2. Summary

* Claim rows: **239** (+ 51 helper-lemma rows). By result: PROVEN=29, PROVEN-COND=174, BOUNDED=36
* Cover rows: 85 (COVER-REACHED=85)
* Mutation campaign: **77 of 80** mutants killed; 3 survive with a documented waiver; **0 unwaived survivors**.

| Module | Property | Requirement | Strongest result | Other results | Jobs | Mutants killed |
|---|---|---|---|---|---|---|
| sf_albion_datafabric | `FAB_ARB_BOUNDED_WAIT` | §2 (bounded fairness; NOT unbounded liveness) | **PROVEN-COND** | - | 1 | 1 |
| sf_albion_datafabric | `FAB_ARB_WORK_CONSERVING` | §2 grants never overlap | **PROVEN-COND** | - | 5 | 0 |
| sf_albion_datafabric | `FAB_DENIED_NOT_FORWARDED` | §2/§5 denied never reaches memory | **PROVEN-COND** | - | 5 | 9 |
| sf_albion_datafabric | `FAB_DMA_DOM0_NO_HOST` | §5 hardware invariant | **PROVEN-COND** | - | 5 | 0 |
| sf_albion_datafabric | `FAB_DMA_DOM1_DENIED` | §5 hardware invariant | **PROVEN-COND** | - | 5 | 1 |
| sf_albion_datafabric | `FAB_DMA_NO_FW_BANK` | §3/§5 protected addresses | **PROVEN-COND** | - | 5 | 1 |
| sf_albion_datafabric | `FAB_DMA_NO_MMIO` | §5 hardware invariant | **PROVEN-COND** | - | 5 | 1 |
| sf_albion_datafabric | `FAB_DMA_WINDOW_COVERED` | §5 permission cannot be bypassed | **PROVEN-COND** | - | 5 | 3 |
| sf_albion_datafabric | `FAB_GRANT_EXCLUSIVE` | §2 grants never overlap | **PROVEN-COND** | - | 5 | 1 |
| sf_albion_datafabric | `FAB_HANDSHAKE_1TO1` | §2 requests not duplicated | **PROVEN-COND** | - | 5 | 6 |
| sf_albion_datafabric | `FAB_HOST_POLICY` | §5 permission cannot be bypassed | **PROVEN-COND** | - | 5 | 2 |
| sf_albion_datafabric | `FAB_LOCAL_ERR_ACCEPTED` | §2 responses correspond to requests | **PROVEN-COND** | - | 5 | 8 |
| sf_albion_datafabric | `FAB_NO_INVALID_ROUTE` | §2 no invalid routing destination | **PROVEN-COND** | - | 5 | 10 |
| sf_albion_datafabric | `FAB_NO_SPURIOUS_READY` | §2 requests not duplicated | **PROVEN-COND** | - | 5 | 0 |
| sf_albion_datafabric | `FAB_REQ_INTEGRITY` | §2 identifiers valid / §5 domain association | **PROVEN-COND** | - | 5 | 2 |
| sf_albion_datafabric | `FAB_RESET_QUIESCENT` | §3 reset establishes control states | **PROVEN-COND** | - | 5 | 0 |
| sf_albion_datafabric | `FAB_RSP_DELIVERED` | §2 responses correspond to requests | **PROVEN-COND** | - | 5 | 0 |
| sf_albion_datafabric | `FAB_RSP_LOCAL_ERROR` | §2 responses correspond to requests | **PROVEN-COND** | - | 5 | 2 |
| sf_albion_datafabric | `FAB_RSP_NO_SPURIOUS` | §2 responses correspond to requests | **PROVEN-COND** | - | 5 | 1 |
| sf_albion_datafabric | `FAB_RSP_ONE_SOURCE` | §2 responses correspond to requests | **PROVEN-COND** | - | 5 | 1 |
| sf_albion_datafabric | `FAB_RSP_ROUTING` | §2 responses correspond to requests | **PROVEN-COND** | - | 5 | 0 |
| sf_albion_datafabric | `FAB_TXN_ID_VALID` | §2 transaction identifiers valid | **PROVEN-COND** | - | 5 | 0 |
| sf_albion_datafabric | `FAB_VIOL_REPORT` | §5 denied access is observable | **PROVEN-COND** | - | 5 | 12 |
| sf_albion_dma | `DMA_ACCOUNTING_ERR` | §4 completed transfers consistent accounting | **BOUNDED** | - | 2 | 2 |
| sf_albion_dma | `DMA_ACCOUNTING_OK` | §4 completed transfers consistent accounting | **BOUNDED** | - | 2 | 0 |
| sf_albion_dma | `DMA_BADPARAM_REJECTED` | §4 illegal requests rejected | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_albion_dma | `DMA_BUSY_WRITE_REJECTED` | §4 descriptors / protocol | **PROVEN-COND** | BOUNDED | 2 | 2 |
| sf_albion_dma | `DMA_BYTES_BOUND` | §4 transfer counters remain valid | **BOUNDED** | - | 2 | 0 |
| sf_albion_dma | `DMA_COUNTERS_VALID` | §4 transfer counters remain valid | **BOUNDED** | - | 2 | 1 |
| sf_albion_dma | `DMA_DESCRIPTOR_FROZEN` | §4 descriptors cannot exceed validated limits | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_albion_dma | `DMA_DESCRIPTOR_LIMITS` | §4 descriptors cannot exceed validated limits | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_albion_dma | `DMA_FIFO_BOUNDS` | §2 FIFO occupancy within bounds | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_albion_dma | `DMA_FIRST_FAIL_STOPS` | §4 deterministic error semantics | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_albion_dma | `DMA_NO_TRAFFIC_WHEN_IDLE` | §4 illegal requests do not mutate memory | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_albion_dma | `DMA_PORT_1PO` | §2 MASTER_1PO (partial, circular) | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_albion_dma | `DMA_RD_BEAT_BOUNDS` | §4 bursts respect configured boundaries (beat model) | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_albion_dma | `DMA_RESET_STATE` | §3 reset establishes control states | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_albion_dma | `DMA_STATUS_CONSISTENT` | §4 accounting | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_albion_dma | `DMA_VALIDATION_EXACT` | §4 descriptors cannot exceed validated limits | **PROVEN-COND** | BOUNDED | 2 | 3 |
| sf_albion_dma | `DMA_WR_BEAT_BOUNDS` | §4 bursts respect configured boundaries (beat model) | **PROVEN-COND** | BOUNDED | 2 | 2 |
| sf_albion_fifo | `FIFO_COUNT_BOUND` | §2 FIFO occupancy within bounds | **PROVEN** | - | 1 | 0 |
| sf_albion_fifo | `FIFO_COUNT_MODEL` | §2 FIFO occupancy within bounds | **PROVEN** | - | 1 | 2 |
| sf_albion_fifo | `FIFO_FLAGS` | §2 FIFO occupancy within bounds | **PROVEN** | - | 1 | 1 |
| sf_albion_fifo | `FIFO_ORDER` | §2 FIFO data integrity | **PROVEN** | - | 1 | 1 |
| sf_albion_perm | `PERM_ATTR_RESERVED_ZERO` | §5 | **PROVEN** | - | 2 | 1 |
| sf_albion_perm | `PERM_ERROR_WRITE_NO_EFFECT` | §5 permission state integrity | **PROVEN** | - | 2 | 0 |
| sf_albion_perm | `PERM_READBACK_ATTR` | §5 | **PROVEN** | - | 2 | 0 |
| sf_albion_perm | `PERM_READBACK_BASE` | §5 | **PROVEN** | - | 2 | 0 |
| sf_albion_perm | `PERM_READBACK_LIMIT` | §5 | **PROVEN** | - | 2 | 1 |
| sf_albion_perm | `PERM_RESET_DEFAULT_DENY` | §3/§5 reset establishes states | **PROVEN** | - | 2 | 1 |
| sf_albion_perm | `PERM_RO_REGS_REJECT_WRITE` | §5 | **PROVEN** | - | 2 | 0 |
| sf_albion_perm | `PERM_VIOL_COUNT_MATCHES_SPEC` | §5 denied access observable | **PROVEN** | - | 2 | 0 |
| sf_albion_perm | `PERM_VIOL_FIRST_STICKY` | §5 | **PROVEN** | - | 2 | 1 |
| sf_albion_perm | `PERM_VIOL_LOG_MATCHES_SPEC` | §5 denied access observable | **PROVEN** | - | 2 | 1 |
| sf_albion_perm | `PERM_WINDOW_MATCHES_SPEC` | §5 permission state integrity | **PROVEN** | - | 2 | 1 |
| sf_albion_secded_enc/dec | `SECDED_CLEAN_ROUNDTRIP` | §3 ECC correctness | **PROVEN** | - | 1 | 1 |
| sf_albion_secded_enc/dec | `SECDED_DOUBLE_DETECTED` | §3 ECC correctness | **PROVEN** | - | 1 | 1 |
| sf_albion_secded_enc/dec | `SECDED_SINGLE_CORRECTED` | §3 ECC correctness | **PROVEN** | - | 1 | 1 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_NO_ACCEPT_DURING_SCRUB` | §3 reset establishes states | **PROVEN-COND** | - | 1 | 0 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_NO_ECC_EVENT_CLEAN` | §3 ECC correctness (clean path) | **PROVEN-COND** | - | 1 | 0 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_READY_GATING` | §3 reset establishes states | **PROVEN-COND** | - | 1 | 1 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_READ_MATCHES_MODEL` | §3 read/write behaviour matches spec | **PROVEN-COND** | - | 1 | 0 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_RESET_STATE` | §3 reset establishes documented control states | **PROVEN-COND** | - | 1 | 2 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_RSP_MATCH` | §2 responses correspond / id echo | **PROVEN-COND** | - | 1 | 2 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_SCRUB_BOUNDED` | §3 reset establishes documented control states | **PROVEN-COND** | - | 1 | 1 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_SCRUB_WRITES_ONLY` | §3 no illegal write enable | **PROVEN-COND** | - | 1 | 0 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_UNWRITTEN_BYTES_STABLE` | §3 unwritten bytes unchanged | **PROVEN-COND** | - | 1 | 0 |
| sf_albion_sram_bank (+secded, macro) | `SRAM_WRITE_ENABLE_LEGAL` | §3 no illegal write enable | **PROVEN-COND** | - | 1 | 2 |
| sf_albion_sram_macro | `SRAM_MACRO_CONTRACT` | §3 / assume-guarantee | **PROVEN-COND** | - | 1 | 1 |
| sf_citadel_domain_table | `CIT_TBL_CFG_GATED` | §5 | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_citadel_domain_table | `CIT_TBL_CLRWIN_INVALIDATES` | §5 invalidation prevents stale use | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_citadel_domain_table | `CIT_TBL_EXCLUSIVE_DISJOINT` | §5 isolation by construction | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_citadel_domain_table | `CIT_TBL_REFUSED_NO_CHANGE` | §5 | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_citadel_domain_table | `CIT_TBL_RESET_DEFAULT_DENY` | §3/§5 reset | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_citadel_domain_table | `CIT_TBL_REVOKE_INVALIDATES` | §5 invalidation prevents stale use | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_citadel_domain_table | `CIT_TBL_STALE_DOMAIN_DENIED` | §5 invalidation prevents stale use | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_citadel_domain_table | `CIT_TBL_STALE_WINDOW_INVALID` | §5 invalidation prevents stale use | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_citadel_domain_table | `CIT_TBL_UNPRIVILEGED_REJECTED` | §5 permission cannot be bypassed | **PROVEN-COND** | BOUNDED | 2 | 1 |
| sf_citadel_gate | `CIT_GATE_COUNTER_NO_OVERFLOW` | §2 counters valid | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_citadel_gate | `CIT_GATE_DOMAIN_ASSOCIATION` | §5 domain ids remain associated | **PROVEN-COND** | BOUNDED | 2 | 2 |
| sf_citadel_gate | `CIT_GATE_FLUSH_QUIET` | §5 | **PROVEN-COND** | BOUNDED | 2 | 2 |
| sf_citadel_gate | `CIT_GATE_NO_BYPASS` | §5 denied writes cannot reach memory / permission cannot be bypassed | **PROVEN-COND** | BOUNDED | 2 | 2 |
| sf_citadel_gate | `CIT_GATE_RESET_STATE` | §3 reset | **PROVEN-COND** | BOUNDED | 2 | 0 |
| sf_citadel_gate | `CIT_GATE_WRITE_NEEDS_RIGHT` | §5 denied writes cannot reach memory | **PROVEN-COND** | BOUNDED | 2 | 2 |
| sf_citadel_permission | `CIT_ATTRIBUTION` | §5 domain ids remain associated | **PROVEN-COND** | - | 3 | 2 |
| sf_citadel_permission | `CIT_DEFAULT_DENY` | §5 reset/default | **PROVEN-COND** | - | 3 | 0 |
| sf_citadel_permission | `CIT_ISOLATION_AND_LOCKDOWN` | §5 | **PROVEN-COND** | - | 3 | 2 |
| sf_citadel_permission | `CIT_NO_RANGE_WRAP` | §5 | **PROVEN-COND** | - | 3 | 1 |
| sf_citadel_permission | `CIT_PERMIT_IMPLIES_SPEC` | §5 permission checks cannot be bypassed | **PROVEN-COND** | - | 3 | 10 |
| sf_citadel_permission | `CIT_PERMIT_STATUS_COUPLING` | §5 permission checks cannot be bypassed | **PROVEN-COND** | - | 3 | 1 |
| sf_citadel_permission | `CIT_SPOOFED_DOMAIN_DENIED` | §5 domain ids remain associated | **PROVEN-COND** | - | 3 | 1 |
| sf_citadel_permission | `CIT_WRITE_NEEDS_WRITE_RIGHT` | §5 denied writes cannot reach memory (decision level) | **PROVEN-COND** | - | 3 | 4 |

## 3. Proof ledger (one row per property per proof job)

Columns: RTL module | property | assumptions | solver | proof depth | result | reproduction command. Helper lemmas are listed after the claims of each job. Parameters are the job's `chparam` values.

### CITG-AW64-BMC: Citadel gate + real permission checker, free table (bounded model check)

`cd formal/albion && python3 scripts/albion_formal.py run CITG-AW64-BMC`   parameters `{"AW": 64}`   job time 35.04 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_citadel_gate | `CIT_GATE_COUNTER_NO_OVERFLOW` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 14 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITG-AW64-BMC` |
| sf_citadel_gate | `CIT_GATE_DOMAIN_ASSOCIATION` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 14 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITG-AW64-BMC` |
| sf_citadel_gate | `CIT_GATE_FLUSH_QUIET` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 14 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITG-AW64-BMC` |
| sf_citadel_gate | `CIT_GATE_NO_BYPASS` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 14 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITG-AW64-BMC` |
| sf_citadel_gate | `CIT_GATE_RESET_STATE` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 14 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITG-AW64-BMC` |
| sf_citadel_gate | `CIT_GATE_WRITE_NEEDS_RIGHT` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 14 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITG-AW64-BMC` |
### CITG-AW64-PDR: Citadel gate + real permission checker, free table (ABC PDR / IC3, unbounded)

`cd formal/albion && python3 scripts/albion_formal.py run CITG-AW64-PDR`   parameters `{"AW": 64}`   job time 545.82 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_citadel_gate | `CIT_GATE_COUNTER_NO_OVERFLOW` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 1) | **PROVEN-COND** | `scripts/albion_formal.py run CITG-AW64-PDR` |
| sf_citadel_gate | `CIT_GATE_DOMAIN_ASSOCIATION` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 4) | **PROVEN-COND** | `scripts/albion_formal.py run CITG-AW64-PDR` |
| sf_citadel_gate | `CIT_GATE_FLUSH_QUIET` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 1) | **PROVEN-COND** | `scripts/albion_formal.py run CITG-AW64-PDR` |
| sf_citadel_gate | `CIT_GATE_NO_BYPASS` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITG-AW64-PDR` |
| sf_citadel_gate | `CIT_GATE_RESET_STATE` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 4) | **PROVEN-COND** | `scripts/albion_formal.py run CITG-AW64-PDR` |
| sf_citadel_gate | `CIT_GATE_WRITE_NEEDS_RIGHT` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITG-AW64-PDR` |
### CITP-AW64-DEV: Citadel permission checker, AW=64, with a device region (k-induction k=2)

`cd formal/albion && python3 scripts/albion_formal.py run CITP-AW64-DEV`   parameters `{"AW": 64, "DEV_PRESENT": 1}`   job time 88.91 s   cross-check: cvc5=pass

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_citadel_permission | `CIT_ATTRIBUTION` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
| sf_citadel_permission | `CIT_DEFAULT_DENY` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
| sf_citadel_permission | `CIT_ISOLATION_AND_LOCKDOWN` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
| sf_citadel_permission | `CIT_NO_RANGE_WRAP` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
| sf_citadel_permission | `CIT_PERMIT_IMPLIES_SPEC` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
| sf_citadel_permission | `CIT_PERMIT_STATUS_COUPLING` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
| sf_citadel_permission | `CIT_SPOOFED_DOMAIN_DENIED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
| sf_citadel_permission | `CIT_WRITE_NEEDS_WRITE_RIGHT` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2); confirmed by cvc5 | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW64-DEV` |
### CITP-AW8-DEV: Citadel permission checker, AW=8, with a device region

`cd formal/albion && python3 scripts/albion_formal.py run CITP-AW8-DEV`   parameters `{"AW": 8, "DEV_PRESENT": 1}`   job time 2.56 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_citadel_permission | `CIT_ATTRIBUTION` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
| sf_citadel_permission | `CIT_DEFAULT_DENY` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
| sf_citadel_permission | `CIT_ISOLATION_AND_LOCKDOWN` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
| sf_citadel_permission | `CIT_NO_RANGE_WRAP` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
| sf_citadel_permission | `CIT_PERMIT_IMPLIES_SPEC` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
| sf_citadel_permission | `CIT_PERMIT_STATUS_COUPLING` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
| sf_citadel_permission | `CIT_SPOOFED_DOMAIN_DENIED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
| sf_citadel_permission | `CIT_WRITE_NEEDS_WRITE_RIGHT` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-DEV` |
### CITP-AW8-NODEV: Citadel permission checker, AW=8, no device region

`cd formal/albion && python3 scripts/albion_formal.py run CITP-AW8-NODEV`   parameters `{"AW": 8, "DEV_PRESENT": 0}`   job time 2.01 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_citadel_permission | `CIT_ATTRIBUTION` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
| sf_citadel_permission | `CIT_DEFAULT_DENY` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
| sf_citadel_permission | `CIT_ISOLATION_AND_LOCKDOWN` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
| sf_citadel_permission | `CIT_NO_RANGE_WRAP` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
| sf_citadel_permission | `CIT_PERMIT_IMPLIES_SPEC` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
| sf_citadel_permission | `CIT_PERMIT_STATUS_COUPLING` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
| sf_citadel_permission | `CIT_SPOOFED_DOMAIN_DENIED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
| sf_citadel_permission | `CIT_WRITE_NEEDS_WRITE_RIGHT` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc+k-induction | k-induction k=2 (+BMC base 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITP-AW8-NODEV` |
### CITT-BMC: Citadel table+permission: invalidation, default-deny, privilege, exclusivity (bounded)

`cd formal/albion && python3 scripts/albion_formal.py run CITT-BMC`   parameters `{}`   job time 69.33 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_citadel_domain_table | `CIT_TBL_CFG_GATED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_CLRWIN_INVALIDATES` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_EXCLUSIVE_DISJOINT` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_REFUSED_NO_CHANGE` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_RESET_DEFAULT_DENY` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_REVOKE_INVALIDATES` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_STALE_DOMAIN_DENIED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_STALE_WINDOW_INVALID` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
| sf_citadel_domain_table | `CIT_TBL_UNPRIVILEGED_REJECTED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | smtbmc z3 bmc | BMC 10 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run CITT-BMC` |
### CITT-PDR: Citadel table+permission: unbounded proofs (ABC PDR / IC3)

`cd formal/albion && python3 scripts/albion_formal.py run CITT-PDR`   parameters `{}`   job time 183.47 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_citadel_domain_table | `CIT_TBL_CFG_GATED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_CLRWIN_INVALIDATES` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_EXCLUSIVE_DISJOINT` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_REFUSED_NO_CHANGE` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_RESET_DEFAULT_DENY` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_REVOKE_INVALIDATES` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_STALE_DOMAIN_DENIED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 5) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_STALE_WINDOW_INVALID` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 3) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
| sf_citadel_domain_table | `CIT_TBL_UNPRIVILEGED_REJECTED` | CLK_IDEAL, RST_FIRST, CIT_REQ_FIELDS_FREE, CIT_PARAM_POINT | abc pdr (IC3) | IC3/PDR converged (frame 2) | **PROVEN-COND** | `scripts/albion_formal.py run CITT-PDR` |
### DMA-D4-BMC: DMA correctness, DEPTH=4 (bounded model check from reset)

`cd formal/albion && python3 scripts/albion_formal.py run DMA-D4-BMC`   parameters `{"DEPTH": 4}`   job time 183.47 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_dma | `DMA_ACCOUNTING_ERR` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_ACCOUNTING_OK` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_BADPARAM_REJECTED` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_BUSY_WRITE_REJECTED` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_BYTES_BOUND` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_COUNTERS_VALID` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_DESCRIPTOR_FROZEN` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_DESCRIPTOR_LIMITS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_FIFO_BOUNDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_FIRST_FAIL_STOPS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_NO_TRAFFIC_WHEN_IDLE` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_PORT_1PO` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_RD_BEAT_BOUNDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_RESET_STATE` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_STATUS_CONSISTENT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_VALIDATION_EXACT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| sf_albion_dma | `DMA_WR_BEAT_BOUNDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_BYTES_EQ_WR_IDX` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_BYTES_LE_NWORDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_COPY_ORDER` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_DESC_LATCHED` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_FIFO_ROOM` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_IDLE_NO_OUT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_IDX_ORDER` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_NWORDS_BOUND` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_OUT_MIRROR` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_RD_OUT_COUNT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
| (helper) | *lemma* `L_DMA_WR_OUT_COUNT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc | BMC 16 cycles from reset | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-BMC` |
### DMA-D4-IND: DMA correctness, DEPTH=4 (k-induction with helper lemmas)

`cd formal/albion && python3 scripts/albion_formal.py run DMA-D4-IND`   parameters `{"DEPTH": 4}`   job time 14.58 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_dma | `DMA_ACCOUNTING_ERR` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 2); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_ACCOUNTING_OK` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 1); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_BADPARAM_REJECTED` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_BUSY_WRITE_REJECTED` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_BYTES_BOUND` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 1); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_COUNTERS_VALID` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 4); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_DESCRIPTOR_FROZEN` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_DESCRIPTOR_LIMITS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_FIFO_BOUNDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_FIRST_FAIL_STOPS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_NO_TRAFFIC_WHEN_IDLE` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_PORT_1PO` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_RD_BEAT_BOUNDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_RESET_STATE` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_STATUS_CONSISTENT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_VALIDATION_EXACT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| sf_albion_dma | `DMA_WR_BEAT_BOUNDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_BYTES_EQ_WR_IDX` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_BYTES_LE_NWORDS` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 1); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_COPY_ORDER` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 5); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_DESC_LATCHED` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_FIFO_ROOM` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_IDLE_NO_OUT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_IDX_ORDER` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 3); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_NWORDS_BOUND` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_OUT_MIRROR` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_RD_OUT_COUNT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | k-induction k=6 (+BMC base 6) | **PROVEN-COND** | `scripts/albion_formal.py run DMA-D4-IND` |
| (helper) | *lemma* `L_DMA_WR_OUT_COUNT` | CLK_IDEAL, RST_FIRST, DMA_RSP_OUT | smtbmc z3 bmc+k-induction | BMC 6 cycles from reset (not k-inductive at k=6 (CTI in fixpoint round 0); BMC passed to depth 6) | **BOUNDED** | `scripts/albion_formal.py run DMA-D4-IND` |
### FAB-ARB-NB4-NW2: DataFabric bounded arbitration latency <= NM-1 waits (CONDITIONAL, FV_ARB)

`cd formal/albion && python3 scripts/albion_formal.py run FAB-ARB-NB4-NW2`   parameters `{"NB": 4, "NW": 2}`   job time 1087.69 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_datafabric | `FAB_ARB_BOUNDED_WAIT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH, SLAVE_READY_ALWAYS | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-ARB-NB4-NW2` |
| (helper) | *lemma* `L_FAB_ERRCODE_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH, SLAVE_READY_ALWAYS | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-ARB-NB4-NW2` |
| (helper) | *lemma* `L_FAB_ERRQ_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH, SLAVE_READY_ALWAYS | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-ARB-NB4-NW2` |
| (helper) | *lemma* `L_FAB_PTGT_RANGE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH, SLAVE_READY_ALWAYS | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-ARB-NB4-NW2` |
### FAB-NB1-NW2: DataFabric, NB=1 (no data banks) NW=2

`cd formal/albion && python3 scripts/albion_formal.py run FAB-NB1-NW2`   parameters `{"NB": 1, "NW": 2}`   job time 115.01 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_datafabric | `FAB_ARB_WORK_CONSERVING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_DENIED_NOT_FORWARDED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM0_NO_HOST` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM1_DENIED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_FW_BANK` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_MMIO` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_DMA_WINDOW_COVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_GRANT_EXCLUSIVE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_HANDSHAKE_1TO1` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_HOST_POLICY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_LOCAL_ERR_ACCEPTED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_NO_INVALID_ROUTE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_NO_SPURIOUS_READY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_REQ_INTEGRITY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_RESET_QUIESCENT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_RSP_DELIVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_RSP_LOCAL_ERROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_RSP_NO_SPURIOUS` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_RSP_ONE_SOURCE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_RSP_ROUTING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_TXN_ID_VALID` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| sf_albion_datafabric | `FAB_VIOL_REPORT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| (helper) | *lemma* `L_FAB_ERRCODE_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| (helper) | *lemma* `L_FAB_ERRQ_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
| (helper) | *lemma* `L_FAB_PTGT_RANGE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB1-NW2` |
### FAB-NB2-NW2: DataFabric, NB=2 NW=2

`cd formal/albion && python3 scripts/albion_formal.py run FAB-NB2-NW2`   parameters `{"NB": 2, "NW": 2}`   job time 184.25 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_datafabric | `FAB_ARB_WORK_CONSERVING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_DENIED_NOT_FORWARDED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM0_NO_HOST` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM1_DENIED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_FW_BANK` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_MMIO` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_DMA_WINDOW_COVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_GRANT_EXCLUSIVE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_HANDSHAKE_1TO1` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_HOST_POLICY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_LOCAL_ERR_ACCEPTED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_NO_INVALID_ROUTE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_NO_SPURIOUS_READY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_REQ_INTEGRITY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_RESET_QUIESCENT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_RSP_DELIVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_RSP_LOCAL_ERROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_RSP_NO_SPURIOUS` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_RSP_ONE_SOURCE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_RSP_ROUTING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_TXN_ID_VALID` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| sf_albion_datafabric | `FAB_VIOL_REPORT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| (helper) | *lemma* `L_FAB_ERRCODE_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| (helper) | *lemma* `L_FAB_ERRQ_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
| (helper) | *lemma* `L_FAB_PTGT_RANGE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB2-NW2` |
### FAB-NB3-NW2: DataFabric, NB=3 (non-power-of-two bank count), NW=2

`cd formal/albion && python3 scripts/albion_formal.py run FAB-NB3-NW2`   parameters `{"NB": 3, "NW": 2}`   job time 259.98 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_datafabric | `FAB_ARB_WORK_CONSERVING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_DENIED_NOT_FORWARDED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM0_NO_HOST` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM1_DENIED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_FW_BANK` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_MMIO` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_DMA_WINDOW_COVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_GRANT_EXCLUSIVE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_HANDSHAKE_1TO1` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_HOST_POLICY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_LOCAL_ERR_ACCEPTED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_NO_INVALID_ROUTE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_NO_SPURIOUS_READY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_REQ_INTEGRITY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_RESET_QUIESCENT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_RSP_DELIVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_RSP_LOCAL_ERROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_RSP_NO_SPURIOUS` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_RSP_ONE_SOURCE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_RSP_ROUTING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_TXN_ID_VALID` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| sf_albion_datafabric | `FAB_VIOL_REPORT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| (helper) | *lemma* `L_FAB_ERRCODE_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| (helper) | *lemma* `L_FAB_ERRQ_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
| (helper) | *lemma* `L_FAB_PTGT_RANGE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB3-NW2` |
### FAB-NB4-NW8: DataFabric, product config NB=4 NW=8 (k-induction)

`cd formal/albion && python3 scripts/albion_formal.py run FAB-NB4-NW8`   parameters `{"NB": 4, "NW": 8}`   job time 950.78 s   cross-check: abc-pdr=pass

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_datafabric | `FAB_ARB_WORK_CONSERVING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_DENIED_NOT_FORWARDED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_DMA_DOM0_NO_HOST` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_DMA_DOM1_DENIED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_DMA_NO_FW_BANK` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_DMA_NO_MMIO` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_DMA_WINDOW_COVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_GRANT_EXCLUSIVE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_HANDSHAKE_1TO1` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_HOST_POLICY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_LOCAL_ERR_ACCEPTED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_NO_INVALID_ROUTE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_NO_SPURIOUS_READY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_REQ_INTEGRITY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_RESET_QUIESCENT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_RSP_DELIVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_RSP_LOCAL_ERROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_RSP_NO_SPURIOUS` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_RSP_ONE_SOURCE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_RSP_ROUTING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_TXN_ID_VALID` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| sf_albion_datafabric | `FAB_VIOL_REPORT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| (helper) | *lemma* `L_FAB_ERRCODE_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| (helper) | *lemma* `L_FAB_ERRQ_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
| (helper) | *lemma* `L_FAB_PTGT_RANGE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB4-NW8` |
### FAB-NB8-NW2: DataFabric, NB=8 (HPC config) NW=2

`cd formal/albion && python3 scripts/albion_formal.py run FAB-NB8-NW2`   parameters `{"NB": 8, "NW": 2}`   job time 797.43 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_datafabric | `FAB_ARB_WORK_CONSERVING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_DENIED_NOT_FORWARDED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM0_NO_HOST` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_DMA_DOM1_DENIED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_FW_BANK` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_DMA_NO_MMIO` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_DMA_WINDOW_COVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_GRANT_EXCLUSIVE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_HANDSHAKE_1TO1` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_HOST_POLICY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_LOCAL_ERR_ACCEPTED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_NO_INVALID_ROUTE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_NO_SPURIOUS_READY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_REQ_INTEGRITY` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_RESET_QUIESCENT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_RSP_DELIVERED` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_RSP_LOCAL_ERROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_RSP_NO_SPURIOUS` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_RSP_ONE_SOURCE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_RSP_ROUTING` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_TXN_ID_VALID` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| sf_albion_datafabric | `FAB_VIOL_REPORT` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| (helper) | *lemma* `L_FAB_ERRCODE_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| (helper) | *lemma* `L_FAB_ERRQ_MIRROR` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
| (helper) | *lemma* `L_FAB_PTGT_RANGE` | CLK_IDEAL, RST_FIRST, MASTER_1PO, SLAVE_RSP_MATCH | smtbmc z3 bmc+k-induction | k-induction k=3 (+BMC base 3) | **PROVEN-COND** | `scripts/albion_formal.py run FAB-NB8-NW2` |
### FIFO-D4-W8-IND: FIFO occupancy/flags/order, DEPTH=4 (k-induction)

`cd formal/albion && python3 scripts/albion_formal.py run FIFO-D4-W8-IND`   parameters `{"W": 8, "DEPTH": 4}`   job time 15.64 s   cross-check: abc-pdr=pass

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_fifo | `FIFO_COUNT_BOUND` | - | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run FIFO-D4-W8-IND` |
| sf_albion_fifo | `FIFO_COUNT_MODEL` | - | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run FIFO-D4-W8-IND` |
| sf_albion_fifo | `FIFO_FLAGS` | - | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run FIFO-D4-W8-IND` |
| sf_albion_fifo | `FIFO_ORDER` | - | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run FIFO-D4-W8-IND` |
| (helper) | *lemma* `L_FIFO_MEM_MODEL` | - | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run FIFO-D4-W8-IND` |
| (helper) | *lemma* `L_FIFO_PTR_COUNT` | - | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run FIFO-D4-W8-IND` |
| (helper) | *lemma* `L_FIFO_PTR_RANGE` | - | smtbmc z3 bmc+k-induction | k-induction k=8 (+BMC base 8); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run FIFO-D4-W8-IND` |
### PERM-NW4-IND: Permission window table + violation log, NW=4 (k-induction)

`cd formal/albion && python3 scripts/albion_formal.py run PERM-NW4-IND`   parameters `{"NW": 4}`   job time 6.38 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_perm | `PERM_ATTR_RESERVED_ZERO` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_ERROR_WRITE_NO_EFFECT` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_READBACK_ATTR` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_READBACK_BASE` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_READBACK_LIMIT` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_RESET_DEFAULT_DENY` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_RO_REGS_REJECT_WRITE` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_VIOL_COUNT_MATCHES_SPEC` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_VIOL_FIRST_STICKY` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_VIOL_LOG_MATCHES_SPEC` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
| sf_albion_perm | `PERM_WINDOW_MATCHES_SPEC` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4) | **PROVEN** | `scripts/albion_formal.py run PERM-NW4-IND` |
### PERM-NW8-IND: Permission window table + violation log, NW=8 (k-induction)

`cd formal/albion && python3 scripts/albion_formal.py run PERM-NW8-IND`   parameters `{"NW": 8}`   job time 50.92 s   cross-check: abc-pdr=pass

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_perm | `PERM_ATTR_RESERVED_ZERO` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_ERROR_WRITE_NO_EFFECT` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_READBACK_ATTR` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_READBACK_BASE` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_READBACK_LIMIT` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_RESET_DEFAULT_DENY` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_RO_REGS_REJECT_WRITE` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_VIOL_COUNT_MATCHES_SPEC` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_VIOL_FIRST_STICKY` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_VIOL_LOG_MATCHES_SPEC` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
| sf_albion_perm | `PERM_WINDOW_MATCHES_SPEC` | CLK_IDEAL, RST_FIRST | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN** | `scripts/albion_formal.py run PERM-NW8-IND` |
### SECDED-CLEAN: SECDED: clean round trip, all 2^32 words

`cd formal/albion && python3 scripts/albion_formal.py run SECDED-CLEAN`   parameters `{"CHECK": 0}`   job time 0.89 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_secded_enc/dec | `SECDED_CLEAN_ROUNDTRIP` | CLK_IDEAL | abc iprove (BDD/rewriting) combinational miter | combinational: exhaustive over all inputs | **PROVEN** | `scripts/albion_formal.py run SECDED-CLEAN` |
### SECDED-DOUBLE: SECDED: every double-bit flip detected, all 2^32 words

`cd formal/albion && python3 scripts/albion_formal.py run SECDED-DOUBLE`   parameters `{"CHECK": 2}`   job time 178.79 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_secded_enc/dec | `SECDED_DOUBLE_DETECTED` | CLK_IDEAL | abc iprove (BDD/rewriting) combinational miter | combinational: exhaustive over all inputs | **PROVEN** | `scripts/albion_formal.py run SECDED-DOUBLE` |
### SECDED-SINGLE: SECDED: every single-bit flip corrected, all 2^32 words

`cd formal/albion && python3 scripts/albion_formal.py run SECDED-SINGLE`   parameters `{"CHECK": 1}`   job time 34.03 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_secded_enc/dec | `SECDED_SINGLE_CORRECTED` | CLK_IDEAL | abc iprove (BDD/rewriting) combinational miter | combinational: exhaustive over all inputs | **PROVEN** | `scripts/albion_formal.py run SECDED-SINGLE` |
### SRAM-MACRO-IND: SRAM macro memory contract (k-induction)

`cd formal/albion && python3 scripts/albion_formal.py run SRAM-MACRO-IND`   parameters `{"WORDS": 8}`   job time 1.56 s   cross-check: abc-pdr=pass

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_sram_macro | `SRAM_MACRO_CONTRACT` | CLK_IDEAL, RST_FIRST, SRAM_SMALL | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-MACRO-IND` |
| (helper) | *lemma* `L_SRAM_MACRO_MEM` | CLK_IDEAL, RST_FIRST, SRAM_SMALL | smtbmc z3 bmc+k-induction | k-induction k=4 (+BMC base 4); confirmed by abc-pdr | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-MACRO-IND` |
### SRAM-W8-IND: SRAM bank data/write-enable/reset properties, WORDS=8 (k-induction)

`cd formal/albion && python3 scripts/albion_formal.py run SRAM-W8-IND`   parameters `{"WORDS": 8}`   job time 40.95 s   cross-check: none

| RTL module | Property | Assumptions | Solver / engine | Proof depth | Result | Reproduction command |
|---|---|---|---|---|---|---|
| sf_albion_sram_bank (+secded, macro) | `SRAM_NO_ACCEPT_DURING_SCRUB` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_NO_ECC_EVENT_CLEAN` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_READY_GATING` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_READ_MATCHES_MODEL` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_RESET_STATE` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_RSP_MATCH` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_SCRUB_BOUNDED` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_SCRUB_WRITES_ONLY` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_UNWRITTEN_BYTES_STABLE` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| sf_albion_sram_bank (+secded, macro) | `SRAM_WRITE_ENABLE_LEGAL` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| (helper) | *lemma* `L_SRAM_CW_TRACKS_DATA` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| (helper) | *lemma* `L_SRAM_PENDING_MIRROR` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| (helper) | *lemma* `L_SRAM_RCNT_TRACKS_CNT` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| (helper) | *lemma* `L_SRAM_RDCW_TRACKS_DATA` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| (helper) | *lemma* `L_SRAM_RDLANES_ZERO` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| (helper) | *lemma* `L_SRAM_SCRUB_COUNTER` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |
| (helper) | *lemma* `L_SRAM_SHADOW_LANES` | CLK_IDEAL, RST_FIRST, SRAM_NO_INJ, SRAM_SMALL, MACRO_CONTRACT | smtbmc z3 bmc+k-induction | k-induction k=12 (+BMC base 12) | **PROVEN-COND** | `scripts/albion_formal.py run SRAM-W8-IND` |

The *reproduction command* of every row is the command printed under its job heading; the raw tool invocations are written to `build/<job>/repro.sh` by that command.

## 4. Cover properties (vacuity detection: the environment really permits the behaviours the proofs talk about)

| Job | Cover | Result | First step | What it shows |
|---|---|---|---|---|
| CITG-COV-AW64 | `CIT_GATE_DENIED_COMMIT` | **COVER-REACHED** | 2 |  |
| CITG-COV-AW64 | `CIT_GATE_DENIED_RESPONSE` | **COVER-REACHED** | 2 |  |
| CITG-COV-AW64 | `CIT_GATE_ENV_SATISFIABLE` | **COVER-REACHED** | 6 |  |
| CITG-COV-AW64 | `CIT_GATE_FLUSH_CANCEL` | **COVER-REACHED** | 2 |  |
| CITG-COV-AW64 | `CIT_GATE_FORWARDED` | **COVER-REACHED** | 2 |  |
| CITG-COV-AW64 | `CIT_GATE_FORWARDED_WRITE` | **COVER-REACHED** | 2 |  |
| CITG-COV-AW64 | `CIT_GATE_FORWARD_AFTER_REVOKE` | **COVER-REACHED** | 3 |  |
| CITG-COV-AW64 | `CIT_GATE_POLICY_CHANGED_WHILE_HELD` | **COVER-REACHED** | 3 |  |
| CITP-COV-AW8 | `CIT_DENY_DOMSTATE` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_DENY_NOMAP` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_DENY_PERM_NO_WRITE` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_DENY_SPOOF` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_DENY_WRAP` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_PERMIT_QUEUE` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_PERMIT_READ_WINDOW` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_PERMIT_WRITE_DEVICE` | **COVER-REACHED** | 1 |  |
| CITP-COV-AW8 | `CIT_PERMIT_WRITE_WINDOW` | **COVER-REACHED** | 1 |  |
| CITT-COV | `CIT_TBL_ACTIVE_PERMIT` | **COVER-REACHED** | 5 |  |
| CITT-COV | `CIT_TBL_ENROLLED` | **COVER-REACHED** | 2 |  |
| CITT-COV | `CIT_TBL_ENV_SATISFIABLE` | **COVER-REACHED** | 4 |  |
| CITT-COV | `CIT_TBL_EXCLUSIVE_WINDOW` | **COVER-REACHED** | 3 |  |
| CITT-COV | `CIT_TBL_OVERLAP_REFUSED` | **COVER-REACHED** | 5 |  |
| CITT-COV | `CIT_TBL_REVOKED` | **COVER-REACHED** | 4 |  |
| CITT-COV | `CIT_TBL_REVOKED_REQUEST_DENIED` | **COVER-REACHED** | 4 |  |
| CITT-COV | `CIT_TBL_UNPRIV_REFUSED` | **COVER-REACHED** | 2 |  |
| CITT-COV | `CIT_TBL_WINDOW_CLEARED` | **COVER-REACHED** | 4 |  |
| DMA-COV-D4 | `DMA_BADPARAM` | **COVER-REACHED** | 1 |  |
| DMA-COV-D4 | `DMA_BEAT_WRITTEN` | **COVER-REACHED** | 4 |  |
| DMA-COV-D4 | `DMA_COPY_STARTED` | **COVER-REACHED** | 2 |  |
| DMA-COV-D4 | `DMA_DONE_ERR` | **COVER-REACHED** | 5 |  |
| DMA-COV-D4 | `DMA_DONE_OK` | **COVER-REACHED** | 5 |  |
| DMA-COV-D4 | `DMA_DONE_OK_COPY` | **COVER-REACHED** | 7 |  |
| DMA-COV-D4 | `DMA_ENV_SATISFIABLE` | **COVER-REACHED** | 10 |  |
| DMA-COV-D4 | `DMA_FIFO_FULL` | **COVER-REACHED** | 9 |  |
| DMA-COV-D4 | `DMA_FILL_STARTED` | **COVER-REACHED** | 2 |  |
| DMA-COV-D4 | `DMA_MULTI_BEAT` | **COVER-REACHED** | 6 |  |
| DMA-COV-D4 | `DMA_READ_ERROR` | **COVER-REACHED** | 5 |  |
| DMA-COV-D4 | `DMA_REG_WRITE_REJECTED_BUSY` | **COVER-REACHED** | 3 |  |
| DMA-COV-D4 | `DMA_WRITE_ERROR` | **COVER-REACHED** | 5 |  |
| FAB-COV-NB4-NW8 | `FAB_CONTENTION` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_DECERR` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_DMA_DENIED_PERM` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_DMA_WINDOW_GRANT` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_ENV_SATISFIABLE` | **COVER-REACHED** | 4 |  |
| FAB-COV-NB4-NW8 | `FAB_FWD_CORE` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_FWD_DMARD` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_FWD_DMAWR` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_FWD_HOST` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_HOST_BOOT_SRAM` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_RSP_FROM_SLAVE` | **COVER-REACHED** | 2 |  |
| FAB-COV-NB4-NW8 | `FAB_RSP_LOCAL` | **COVER-REACHED** | 2 |  |
| FAB-COV-NB4-NW8 | `FAB_SLAVE_STALL` | **COVER-REACHED** | 1 |  |
| FAB-COV-NB4-NW8 | `FAB_VIOL_EVENT` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_CONTENTION` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_DECERR` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_DMA_DENIED_PERM` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_DMA_WINDOW_GRANT` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_ENV_SATISFIABLE` | **COVER-REACHED** | 3 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_FWD_CORE` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_FWD_DMARD` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_FWD_DMAWR` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_FWD_HOST` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_HOST_BOOT_SRAM` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_MULTI_DENIAL_ONE_EVENT` | **COVER-REACHED** | 1 | Two masters denied in the same cycle produce ONE violation event (viol_o is 1 bit): reachable, so the violation counter counts cycles with a denial, not denials. |
| FAB-FINDINGS-NB4-NW2 | `FAB_RSP_FROM_SLAVE` | **COVER-REACHED** | 2 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_RSP_LOCAL` | **COVER-REACHED** | 2 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_SINGLE_DENIAL_ONE_EVENT` | **COVER-REACHED** | 1 | A single denial produces one violation event (control for F-01). |
| FAB-FINDINGS-NB4-NW2 | `FAB_SLAVE_STALL` | **COVER-REACHED** | 1 |  |
| FAB-FINDINGS-NB4-NW2 | `FAB_VIOL_EVENT` | **COVER-REACHED** | 1 |  |
| PERM-COV-NW8 | `PERM_ENV_SATISFIABLE` | **COVER-REACHED** | 6 |  |
| PERM-COV-NW8 | `PERM_RO_WRITE_REJECTED` | **COVER-REACHED** | 1 |  |
| PERM-COV-NW8 | `PERM_VIOL_CLEARED` | **COVER-REACHED** | 2 |  |
| PERM-COV-NW8 | `PERM_VIOL_COUNT_NONZERO` | **COVER-REACHED** | 2 |  |
| PERM-COV-NW8 | `PERM_VIOL_LOGGED` | **COVER-REACHED** | 2 |  |
| PERM-COV-NW8 | `PERM_WINDOW_VALID` | **COVER-REACHED** | 2 |  |
| PERM-COV-NW8 | `PERM_WINDOW_WRITTEN` | **COVER-REACHED** | 1 |  |
| SRAM-COV-W8 | `SRAM_ENV_SATISFIABLE` | **COVER-REACHED** | 14 |  |
| SRAM-COV-W8 | `SRAM_FULL_WRITE_TW` | **COVER-REACHED** | 9 |  |
| SRAM-COV-W8 | `SRAM_INIT_DONE` | **COVER-REACHED** | 9 |  |
| SRAM-COV-W8 | `SRAM_PARTIAL_WRITE_TW` | **COVER-REACHED** | 9 |  |
| SRAM-COV-W8 | `SRAM_READ_NONZERO_DATA` | **COVER-REACHED** | 11 |  |
| SRAM-COV-W8 | `SRAM_READ_TW_AFTER_PARTIAL` | **COVER-REACHED** | 12 |  |
| SRAM-COV-W8 | `SRAM_READ_UNWRITTEN_LANES` | **COVER-REACHED** | 10 |  |
| SRAM-COV-W8 | `SRAM_RESET_AFTER_INIT` | **COVER-REACHED** | 1 |  |
| SRAM-COV-W8 | `SRAM_RMW_COMMIT` | **COVER-REACHED** | 10 |  |

## 5. Assumption register

| Assumption | Category | Used by jobs | Discharged by | Sensitivity: does dropping it break a property? (bounded BMC run) | Text / risk |
|---|---|---|---|---|---|
| `CLK_IDEAL` | structural | 30 | not discharged | n/a (structural / informational) | One ideal clock, one active edge per formal step. No skew, glitches or clock-domain crossings. Asynchronous resets are modelled step-synchronously (Yosys async2sync). **Risk:** Real silicon has reset-deassertion timing, RDC and metastability hazards that no cycle-based formal model sees. |
| `RST_FIRST` | structural | 27 | not discharged | n/a (structural / informational) | Reset is asserted in step 0 (all proofs that quantify over 'reachable states'). Mode 'reset anywhere' additionally allows re-assertion at any later step. **Risk:** If a SoC reaches a design state without ever applying reset, reachable-state proofs do not cover it. |
| `MASTER_1PO` | protocol | 8 | PARTIALLY, and CIRCULARLY: the DMA ports satisfy it (property DMA_PORT_1PO, jobs DMA-D4-*), but that proof assumes DMA_RSP_OUT, which is what the fabric's FAB_RSP_NO_SPURIOUS provides - and that proof assumes MASTER_1PO. Circular assume-guarantee is NOT sound without a composed (or time-shifted) argument, and none is machine-checked here (U-SYSTEM). NOT discharged at all for CORE (sf_albion_controlcore) and HOST (sf_albion_host_if): those RTL blocks are out of scope. | FAB-NB2-NW2: no violation found in a BOUNDED run without it (NOT proof that it is redundant) | Each fabric master has at most one outstanding request: it presents m_req_valid only when it has no unanswered request, or when its response arrives in the same cycle (docs/albion/transaction_protocol.md; the RTL checks this only in simulation). **Risk:** A master that issues a second request while one is outstanding can receive a response routed to the wrong request (response-to-request matching is lost). |
| `SLAVE_RSP_MATCH` | protocol | 8 | For SRAM banks: property SRAM_RSP_MATCH (job SRAM-W8-IND), which does not depend on any fabric assumption (non-circular), at WORDS=8 with the MACRO_CONTRACT and SRAM_NO_INJ assumptions. NOT discharged for the MMIO slave or the HOSTMEM slave (RTL not in scope). | FAB-NB2-NW2: YES - dropping it breaks FAB_RSP_DELIVERED,FAB_RSP_NO_SPURIOUS,FAB_RSP_ONE_SOURCE | A fabric slave asserts s_rsp_valid only for a request it accepted earlier, echoes that request's master id in s_rsp_id, and answers each accepted request exactly once. **Risk:** A slave that answers twice, answers unprompted or garbles the id breaks response matching irrespective of the fabric. |
| `SLAVE_READY_ALWAYS` | protocol | 1 | not discharged | not measured (configuration / scope choice, not an assume cell, or no sensitivity job) | Used ONLY by the bounded-arbitration-latency job: every slave has s_req_ready = 1 in every cycle. **Risk:** With ready stalls the latency bound scales with the stall duration; nothing about it can be said without a fairness model of the slave. |
| `SRAM_NO_INJ` | config | 2 | not discharged | SRAM-W8-IND: YES - dropping it breaks L_SRAM_CW_TRACKS_DATA | The RAS error-injection port is idle: inj_arm = 0. Required for the data-correctness (read-after-write) proofs, which are false by design when a fault is injected. **Risk:** None for production use unless injection is enabled; with injection the correct claim is the ECC one (SRAM-ECC-* properties). |
| `SRAM_SMALL` | config | 3 | not discharged | not measured (configuration / scope choice, not an assume cell, or no sensitivity job) | SRAM-bank proofs are run at WORDS = 8 (AW = 3), not the product WORDS = 4096. The properties are about one arbitrary tracked word, so they are independent of bank size by parametricity, but that step is an argument, not a machine-checked theorem. **Risk:** A defect that only appears for AW >= 4 (e.g. a truncated counter) would not be seen at AW = 3. The scrub-on-reset counter logic is the only size-dependent piece; it is separately checked at WORDS = 16. |
| `DMA_RSP_OUT` | protocol | 3 | CIRCULAR, see MASTER_1PO: the fabric guarantees no response without an outstanding request (FAB_RSP_NO_SPURIOUS) only under MASTER_1PO and SLAVE_RSP_MATCH; the DMA's 1-outstanding behaviour (DMA_PORT_1PO) is proven only under DMA_RSP_OUT. Not closed by a composed proof (U-SYSTEM). Also not discharged for the host-memory slave. | DMA-D4-IND: YES - dropping it breaks L_DMA_IDX_ORDER,L_DMA_RD_OUT_COUNT | The DMA read/write ports only receive a response (rd_rsp_valid / wr_rsp_valid) while a request is outstanding on that port, and the outstanding request has been accepted. **Risk:** A response without a request corrupts the engine's beat indices (the RTL has no guard). |
| `CIT_REQ_FIELDS_FREE` | structural | 10 | not discharged | n/a (structural / informational) | Citadel permission/gate/table jobs drive request fields, table state and safety levels as free inputs every cycle (no assumption): the proofs hold for ANY table contents and ANY sequence of table changes. **Risk:** None (this is an over-approximation of the real environment, so it can only make a proof stronger). |
| `CIT_PARAM_POINT` | config | 10 | not discharged | CITG-AW64-BMC: no violation found in a BOUNDED run without it (NOT proof that it is redundant) | Citadel proofs are at a reduced parameter point (NDOM=2, NW=2, NP=1, NDEV=1, NQ=2, AW as stated in the job). The logic is parametric, but 'holds at the small point' implies 'holds at NDOM=8, NW=4' only by an argument, not a proof (the authors' own docs say the same). **Risk:** A defect needing 3+ domains or 3+ windows to manifest would be missed. |
| `CIT_CFG_AUTH` | informational | 0 | n/a (nothing is assumed; the table proofs hold for ANY requester). The isolation guarantee is only meaningful if the command port is physically reachable by the management plane only (integration rule A-CFG). | n/a (structural / informational) | [INFORMATIONAL - not an assumption of any proof] Table jobs: cfg_en_i is the secure-boot verdict and the command port is reachable only by the management plane (docs/citadel/08 A-CFG). In the table jobs the command port is FREE (any requester/domain/privilege), so this is NOT assumed; it is listed because the isolation theorem is only meaningful given A-CFG. **Risk:** If a tenant can drive the command port with label ROOT and priv=1 it owns the policy. |
| `CIT_SINGLE_TABLE_CMD` | informational | 0 | n/a (documented hardware semantics: the gate's verdict is latched at first evaluation; a policy change applies to the NEXT request). | n/a (structural / informational) | [INFORMATIONAL - not an assumption of any proof] Invalidation job: after a REVOKE/CLR_WINDOW the stale-use check is made on requests evaluated in a LATER cycle than the command's commit; a request already presented to the target before the commit completes (quiesce rule, docs/citadel/03 section 7). **Risk:** Requests already forwarded are not recalled by revocation; this is documented hardware behaviour, not a defect. |
| `MACRO_CONTRACT` | protocol | 2 | Property SRAM_MACRO_CONTRACT (job SRAM-MACRO-IND), non-circular, for the behavioural macro sf_albion_sram_macro only. NOT discharged for any compiled / foundry SRAM macro. | SRAM-W8-IND: no violation found in a BOUNDED run without it (NOT proof that it is redundant) | Bank-level jobs abstract the memory macro by its contract: after a read of a word, rdata equals the codeword most recently written to that word (an unwritten word is never read: the scrub writes every word before the bank accepts traffic). **Risk:** If the memory macro (compiled SRAM / OpenRAM / foundry macro) does not behave like the behavioural model, the bank-level proofs do not transfer. The shipped behavioural macro is proven against the contract; a real macro needs its own verification (PDK / macro vendor). |

## 6. Mutation campaign (controlled bugs: do the assertions detect real violations?)

77 of 80 mutants killed. A mutant is a single-point bug injected into a COPY of the RTL; it is killed when the detector job (BMC) finds a counterexample. Counterexample reports: `reports/mutation/cex/`.

| Mutant | Module | Class | Bug | Detector job | Result | Violated assertions (first failing step) | Designed detector fired | Step | Reproduce |
|---|---|---|---|---|---|---|---|---|---|
| CITG-M01-DENIED-FORWARDED | sf_citadel_gate | security | denied requests forwarded to the target | CITG-AW64-BMC d=10 | KILLED | CIT_GATE_FLUSH_QUIET, CIT_GATE_NO_BYPASS, CIT_GATE_WRITE_NEEDS_RIGHT | 2/2 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate CITG-M01-DENIED-FORWARDED` |
| CITG-M02-FLUSH-IGNORED | sf_citadel_gate | security | request still presented while the port is flushed | CITG-AW64-BMC d=10 | KILLED | CIT_GATE_FLUSH_QUIET | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate CITG-M02-FLUSH-IGNORED` |
| CITG-M03-STALE-VERDICT | sf_citadel_gate | availability | first evaluation reuses the previous request's verdict (never re-evaluates) | CITG-AW64-BMC d=10 | SURVIVED (waived) | - | - | - | `python3 scripts/albion_formal.py mutate CITG-M03-STALE-VERDICT` |
| CITG-M04-VERDICT-INHERITED | sf_citadel_gate | security | a new request inherits the latched verdict of the previous one (its commit pulse is suppressed; detected because the forwarded fields no longer match the monitor's snapshot) | CITG-AW64-BMC d=10 | KILLED | CIT_GATE_DOMAIN_ASSOCIATION | 1/1 confirmed in isolation | 4 | `python3 scripts/albion_formal.py mutate CITG-M04-VERDICT-INHERITED` |
| CITG-M05-DOMAIN-REWRITTEN | sf_citadel_gate | security | forwarded request carries a different domain than the one checked | CITG-AW64-BMC d=10 | KILLED | CIT_GATE_DOMAIN_ASSOCIATION | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate CITG-M05-DOMAIN-REWRITTEN` |
| CITG-M06-VERDICT-ALWAYS-PERMIT | sf_citadel_gate | security | latched verdict is always PERMIT: a denied request that has to wait behind an outstanding one is forwarded in a later cycle | CITG-AW64-BMC d=12 | KILLED | CIT_GATE_NO_BYPASS, CIT_GATE_WRITE_NEEDS_RIGHT | 2/2 confirmed in isolation | 3 | `python3 scripts/albion_formal.py mutate CITG-M06-VERDICT-ALWAYS-PERMIT` |
| CITP-M01-WRITE-VIA-R | sf_citadel_permission | security | WRITE permitted by a read-only window | CITP-AW8-DEV d=2 | KILLED | CIT_PERMIT_IMPLIES_SPEC, CIT_WRITE_NEEDS_WRITE_RIGHT | 2/2 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M01-WRITE-VIA-R` |
| CITP-M02-LIMIT-UNCHECKED | sf_citadel_permission | security | window end checked against the first byte, not the last | CITP-AW8-DEV d=2 | KILLED | CIT_PERMIT_IMPLIES_SPEC, CIT_WRITE_NEEDS_WRITE_RIGHT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M02-LIMIT-UNCHECKED` |
| CITP-M03-BINDING-IGNORED | sf_citadel_permission | security | port binding ignored: any port may claim any domain (spoofing) | CITP-AW8-DEV d=2 | KILLED | CIT_ATTRIBUTION, CIT_PERMIT_IMPLIES_SPEC, CIT_SPOOFED_DOMAIN_DENIED | 2/2 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M03-BINDING-IGNORED` |
| CITP-M04-SUSPENDED-OK | sf_citadel_permission | security | suspended / quarantined domains are permitted | CITP-AW8-DEV d=2 | KILLED | CIT_ATTRIBUTION, CIT_PERMIT_IMPLIES_SPEC | 2/2 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M04-SUSPENDED-OK` |
| CITP-M05-WRAP-ALLOWED | sf_citadel_permission | security | address-range wrap not detected | CITP-AW8-DEV d=2 | KILLED | CIT_NO_RANGE_WRAP, CIT_PERMIT_IMPLIES_SPEC | 2/2 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M05-WRAP-ALLOWED` |
| CITP-M06-ISOLATION-IGNORED | sf_citadel_permission | security | isolated port still permitted | CITP-AW8-DEV d=2 | KILLED | CIT_ISOLATION_AND_LOCKDOWN, CIT_PERMIT_IMPLIES_SPEC, CIT_WRITE_NEEDS_WRITE_RIGHT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M06-ISOLATION-IGNORED` |
| CITP-M07-LOCKDOWN-IGNORED | sf_citadel_permission | security | safe-state lockdown ignored | CITP-AW8-DEV d=2 | KILLED | CIT_ISOLATION_AND_LOCKDOWN, CIT_PERMIT_IMPLIES_SPEC | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M07-LOCKDOWN-IGNORED` |
| CITP-M08-PERMIT-ON-PERM | sf_citadel_permission | security | requests denied for PERM are permitted | CITP-AW8-DEV d=2 | KILLED | CIT_PERMIT_IMPLIES_SPEC, CIT_PERMIT_STATUS_COUPLING | 2/2 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M08-PERMIT-ON-PERM` |
| CITP-M09-PRIV-ESCALATION | sf_citadel_permission | security | privileged-attribute claim above the domain's capability accepted | CITP-AW8-DEV d=2 | KILLED | CIT_PERMIT_IMPLIES_SPEC | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M09-PRIV-ESCALATION` |
| CITP-M10-DEVWRITE-VIA-READ | sf_citadel_permission | security | device WRITE permitted with only read permission | CITP-AW8-DEV d=2 | KILLED | CIT_PERMIT_IMPLIES_SPEC, CIT_WRITE_NEEDS_WRITE_RIGHT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate CITP-M10-DEVWRITE-VIA-READ` |
| CITT-M01-WINDOWS-SURVIVE-REVOKE | sf_citadel_domain_table | security | REVOKE leaves the slot's windows valid (a re-enrolled slot would inherit them: stale window use) | CITT-BMC d=8 | KILLED | CIT_TBL_REVOKE_INVALIDATES | 1/1 confirmed in isolation | 4 | `python3 scripts/albion_formal.py mutate CITT-M01-WINDOWS-SURVIVE-REVOKE` |
| CITT-M02-ANYONE-CONFIGURES | sf_citadel_domain_table | security | unprivileged requesters may configure the policy | CITT-BMC d=6 | KILLED | CIT_TBL_UNPRIVILEGED_REJECTED | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate CITT-M02-ANYONE-CONFIGURES` |
| CITT-M03-CFGEN-IGNORED | sf_citadel_domain_table | security | configuration accepted although boot is not authorised | CITT-BMC d=6 | KILLED | CIT_TBL_CFG_GATED | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate CITT-M03-CFGEN-IGNORED` |
| CITT-M04-EXCL-NEEDS-BOTH | sf_citadel_domain_table | security | exclusive window may overlap another domain's non-exclusive window | CITT-BMC d=8 | KILLED | CIT_TBL_EXCLUSIVE_DISJOINT | 1/1 confirmed in isolation | 5 | `python3 scripts/albion_formal.py mutate CITT-M04-EXCL-NEEDS-BOTH` |
| CITT-M05-BIND-ALL-AFTER-RESET | sf_citadel_domain_table | security | every port bound to every domain after reset (default allow) | CITT-BMC d=4 | KILLED | CIT_TBL_RESET_DEFAULT_DENY | 1/1 confirmed in isolation | 1 | `python3 scripts/albion_formal.py mutate CITT-M05-BIND-ALL-AFTER-RESET` |
| DMA-M01-LEN-LIMIT | sf_albion_dma | security | DMA_MAX_LEN doubled | DMA-D4-BMC d=14 | KILLED | DMA_VALIDATION_EXACT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate DMA-M01-LEN-LIMIT` |
| DMA-M02-UNALIGNED-LEN | sf_albion_dma | functional | LEN not a multiple of 4 accepted | DMA-D4-BMC d=14 | KILLED | DMA_VALIDATION_EXACT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate DMA-M02-UNALIGNED-LEN` |
| DMA-M03-DST-WRAP | sf_albion_dma | security | destination range wrapping 2^32 accepted | DMA-D4-BMC d=14 | KILLED | DMA_VALIDATION_EXACT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate DMA-M03-DST-WRAP` |
| DMA-M04-RD-STRIDE | sf_albion_dma | functional | read beats stride 8 bytes | DMA-D4-BMC d=14 | KILLED | DMA_RD_BEAT_BOUNDS | 1/1 confirmed in isolation | 5 | `python3 scripts/albion_formal.py mutate DMA-M04-RD-STRIDE` |
| DMA-M05-WR-OFF-BY-ONE | sf_albion_dma | security | write beats shifted one word (last beat lands past the destination range) | DMA-D4-BMC d=14 | KILLED | DMA_WR_BEAT_BOUNDS | 1/1 confirmed in isolation | 4 | `python3 scripts/albion_formal.py mutate DMA-M05-WR-OFF-BY-ONE` |
| DMA-M06-EXTRA-BEAT | sf_albion_dma | security | one extra write beat beyond LEN | DMA-D4-BMC d=14 | KILLED | DMA_WR_BEAT_BOUNDS | 2/2 confirmed in isolation | 5 | `python3 scripts/albion_formal.py mutate DMA-M06-EXTRA-BEAT` |
| DMA-M07-BYTES-DOUBLE | sf_albion_dma | functional | BYTES_DONE advances 8 per beat | DMA-D4-BMC d=14 | KILLED | DMA_COUNTERS_VALID, lemma DMA_BYTES_EQ_WR_IDX | 2/2 confirmed in isolation | 6 | `python3 scripts/albion_formal.py mutate DMA-M07-BYTES-DOUBLE` |
| DMA-M08-BUSY-WRITE-OK | sf_albion_dma | functional | writes to descriptor registers during a transfer are silently reported OK | DMA-D4-BMC d=14 | KILLED | DMA_BUSY_WRITE_REJECTED | 1/1 confirmed in isolation | 3 | `python3 scripts/albion_formal.py mutate DMA-M08-BUSY-WRITE-OK` |
| DMA-M09-DESC-NOT-FROZEN | sf_albion_dma | security | descriptor registers can be rewritten mid-transfer (validated limits bypassed) | DMA-D4-BMC d=14 | KILLED | DMA_BUSY_WRITE_REJECTED | 3/3 confirmed in isolation | 3 | `python3 scripts/albion_formal.py mutate DMA-M09-DESC-NOT-FROZEN` |
| DMA-M10-LATER-ERR-OVERRIDES | sf_albion_dma | functional | a later read failure overwrites the first failing beat | DMA-D4-BMC d=16 | KILLED | DMA_ACCOUNTING_ERR | 1/1 confirmed in isolation | 9 | `python3 scripts/albion_formal.py mutate DMA-M10-LATER-ERR-OVERRIDES` |
| DMA-M11-PREFETCH-OVERFLOW | sf_albion_dma | functional | prefetch may over-commit the FIFO by one | DMA-D4-BMC d=14 | KILLED | DMA_FIFO_BOUNDS, lemma DMA_FIFO_ROOM | 1/1 confirmed in isolation | 9 | `python3 scripts/albion_formal.py mutate DMA-M11-PREFETCH-OVERFLOW` |
| DMA-M12-RESET-KEEPS-BUSY | sf_albion_dma | security | reset does not stop a running transfer | DMA-D4-BMC d=14 | KILLED | DMA_DESCRIPTOR_LIMITS, DMA_RESET_STATE, lemma DMA_DESC_LATCHED | 1/1 confirmed in isolation | 1 | `python3 scripts/albion_formal.py mutate DMA-M12-RESET-KEEPS-BUSY` |
| DMA-M13-BADPARAM-CODE | sf_albion_dma | functional | bad descriptor rejected with no error code | DMA-D4-BMC d=14 | KILLED | DMA_BADPARAM_REJECTED | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate DMA-M13-BADPARAM-CODE` |
| DMA-M14-FAILED-READ-PUSHED | sf_albion_dma | security | data of a FAILED read is pushed and later written to the destination | DMA-D4-BMC d=16 | KILLED | DMA_ACCOUNTING_ERR | 1/1 confirmed in isolation | 8 | `python3 scripts/albion_formal.py mutate DMA-M14-FAILED-READ-PUSHED` |
| FAB-M01-DMA-FWBANK | sf_albion_datafabric | security | DMA may reach firmware-private SRAM bank 0 | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_DMA_NO_FW_BANK, FAB_LOCAL_ERR_ACCEPTED, FAB_NO_INVALID_ROUTE | 2/2 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M01-DMA-FWBANK` |
| FAB-M02-DOM0-HOSTMEM | sf_albion_datafabric | security | DMA domain 0 may reach host memory | FAB-NB2-NW2 d=4 | KILLED | FAB_LOCAL_ERR_ACCEPTED, FAB_VIOL_REPORT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M02-DOM0-HOSTMEM` |
| FAB-M03-DOM1-WINDOW | sf_albion_datafabric | security | DMA in HOST_ADMIN domain permitted via a window | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_DMA_DOM1_DENIED, FAB_LOCAL_ERR_ACCEPTED, FAB_NO_INVALID_ROUTE | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M03-DOM1-WINDOW` |
| FAB-M04-NO-WINDOW-CHECK | sf_albion_datafabric | security | tenant DMA permitted without a window | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_DMA_WINDOW_COVERED, FAB_HANDSHAKE_1TO1, FAB_NO_INVALID_ROUTE | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M04-NO-WINDOW-CHECK` |
| FAB-M05-LIMIT-OFF-BY-3 | sf_albion_datafabric | security | window upper bound checked on the first byte only (word may straddle the limit) | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_DMA_WINDOW_COVERED, FAB_HANDSHAKE_1TO1, FAB_NO_INVALID_ROUTE | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M05-LIMIT-OFF-BY-3` |
| FAB-M06-RW-SWAPPED | sf_albion_datafabric | security | window read/write permission bits swapped | FAB-NB2-NW2 d=4 | KILLED | FAB_HANDSHAKE_1TO1, FAB_VIOL_REPORT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M06-RW-SWAPPED` |
| FAB-M07-VALID-IGNORED | sf_albion_datafabric | security | window valid bit ignored (invalidated windows still grant) | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_DMA_WINDOW_COVERED, FAB_LOCAL_ERR_ACCEPTED, FAB_NO_INVALID_ROUTE | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M07-VALID-IGNORED` |
| FAB-M08-HOST-SRAM-NOBOOT | sf_albion_datafabric | security | host reaches SRAM outside boot mode | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_HOST_POLICY, FAB_LOCAL_ERR_ACCEPTED, FAB_NO_INVALID_ROUTE | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M08-HOST-SRAM-NOBOOT` |
| FAB-M09-HOST-WRITE-TELEM | sf_albion_datafabric | security | host may WRITE telemetry/RAS pages | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_HOST_POLICY, FAB_LOCAL_ERR_ACCEPTED, FAB_NO_INVALID_ROUTE | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M09-HOST-WRITE-TELEM` |
| FAB-M10-MMIO-ALIAS | sf_albion_datafabric | decode | MMIO decode too wide (aliases 1 MiB) | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_HANDSHAKE_1TO1, FAB_NO_INVALID_ROUTE, FAB_VIOL_REPORT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M10-MMIO-ALIAS` |
| FAB-M11-SRAM-OFF-BY-ONE | sf_albion_datafabric | decode | first byte past SRAM decodes to SRAM (aliasing) | FAB-NB2-NW2 d=4 | KILLED | FAB_DENIED_NOT_FORWARDED, FAB_DMA_NO_MMIO, FAB_LOCAL_ERR_ACCEPTED, FAB_NO_INVALID_ROUTE | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M11-SRAM-OFF-BY-ONE` |
| FAB-M12-READY-IGNORES-SLAVE | sf_albion_datafabric | protocol | master sees ready while the slave is not ready (request lost/duplicated) | FAB-NB2-NW2 d=4 | KILLED | FAB_HANDSHAKE_1TO1 | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M12-READY-IGNORES-SLAVE` |
| FAB-M13-ID-ZERO | sf_albion_datafabric | protocol | slave request carries master id 0 always | FAB-NB2-NW2 d=4 | KILLED | FAB_GRANT_EXCLUSIVE, FAB_HANDSHAKE_1TO1, FAB_NO_INVALID_ROUTE, FAB_REQ_INTEGRITY | 2/2 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M13-ID-ZERO` |
| FAB-M14-DOMAIN-DROPPED | sf_albion_datafabric | security | request forwarded with domain 0 (FIRMWARE): domain association lost | FAB-NB2-NW2 d=4 | KILLED | FAB_REQ_INTEGRITY | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M14-DOMAIN-DROPPED` |
| FAB-M15-ERRCODE-SWAP | sf_albion_datafabric | functional | PERM/DECERR codes swapped in local error response | FAB-NB2-NW2 d=4 | KILLED | FAB_RSP_LOCAL_ERROR, lemma FAB_ERRCODE_MIRROR | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate FAB-M15-ERRCODE-SWAP` |
| FAB-M16-LOCAL-RSP-LOST | sf_albion_datafabric | protocol | local error response never delivered | FAB-NB2-NW2 d=4 | KILLED | FAB_RSP_LOCAL_ERROR | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate FAB-M16-LOCAL-RSP-LOST` |
| FAB-M17-RSP-BROADCAST | sf_albion_datafabric | protocol | slave response delivered to every master | FAB-NB2-NW2 d=4 | KILLED | FAB_RSP_NO_SPURIOUS, FAB_RSP_ONE_SOURCE | 2/2 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate FAB-M17-RSP-BROADCAST` |
| FAB-M18-VIOL-DECERR | sf_albion_datafabric | functional | decode errors reported as permission violations | FAB-NB2-NW2 d=4 | KILLED | FAB_VIOL_REPORT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M18-VIOL-DECERR` |
| FAB-M19-PERMERR-STALLS | sf_albion_datafabric | protocol | permission-denied request is neither forwarded nor answered (master hangs) | FAB-NB2-NW2 d=4 | KILLED | FAB_LOCAL_ERR_ACCEPTED, FAB_VIOL_REPORT | 1/1 confirmed in isolation | 0 | `python3 scripts/albion_formal.py mutate FAB-M19-PERMERR-STALLS` |
| FAB-M20-RR-STUCK | sf_albion_datafabric | fairness | round-robin pointer does not advance (starvation) | FAB-ARB-NB4-NW2 d=10 | KILLED | FAB_ARB_BOUNDED_WAIT | 1/1 confirmed in isolation | 5 | `python3 scripts/albion_formal.py mutate FAB-M20-RR-STUCK` |
| FIFO-M01-FULL-EARLY | sf_albion_fifo | functional | full flag asserted one entry early | FIFO-D4-W8-IND d=8 | KILLED | FIFO_FLAGS | 2/2 confirmed in isolation | 4 | `python3 scripts/albion_formal.py mutate FIFO-M01-FULL-EARLY` |
| FIFO-M02-OVERFLOW | sf_albion_fifo | functional | push accepted when full (overflow) | FIFO-D4-W8-IND d=8 | KILLED | FIFO_COUNT_MODEL, lemma FIFO_MEM_MODEL | 2/2 confirmed in isolation | 6 | `python3 scripts/albion_formal.py mutate FIFO-M02-OVERFLOW` |
| FIFO-M03-UNDERFLOW | sf_albion_fifo | functional | pop accepted when empty (underflow) | FIFO-D4-W8-IND d=8 | KILLED | FIFO_COUNT_MODEL | 2/2 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate FIFO-M03-UNDERFLOW` |
| FIFO-M04-HEAD-WP | sf_albion_fifo | functional | head reads the write slot | FIFO-D4-W8-IND d=8 | KILLED | FIFO_ORDER | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate FIFO-M04-HEAD-WP` |
| FIFO-M05-WRAP-EARLY | sf_albion_fifo | functional | pointer wraps one slot early | FIFO-D4-W8-IND d=8 | KILLED | lemma FIFO_PTR_COUNT | 1/1 confirmed in isolation | 4 | `python3 scripts/albion_formal.py mutate FIFO-M05-WRAP-EARLY` |
| PERM-M01-RESET-KEEPS-WINDOWS | sf_albion_perm | security | reset leaves windows valid (default-allow after reset) | PERM-NW8-IND d=6 | KILLED | PERM_RESET_DEFAULT_DENY | 1/1 confirmed in isolation | 1 | `python3 scripts/albion_formal.py mutate PERM-M01-RESET-KEEPS-WINDOWS` |
| PERM-M02-ATTR-RESERVED | sf_albion_perm | functional | reserved attribute bits stored | PERM-NW8-IND d=6 | KILLED | PERM_ATTR_RESERVED_ZERO | 2/2 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate PERM-M02-ATTR-RESERVED` |
| PERM-M03-COUNT-WRAPS | sf_albion_perm | functional | violation counter wraps instead of saturating | PERM-NW8-IND d=8 | SURVIVED (waived) | - | - | - | `python3 scripts/albion_formal.py mutate PERM-M03-COUNT-WRAPS` |
| PERM-M04-LOG-OVERWRITE | sf_albion_perm | functional | first-violation log overwritten by later violations | PERM-NW8-IND d=6 | KILLED | PERM_VIOL_FIRST_STICKY, PERM_VIOL_LOG_MATCHES_SPEC | 2/2 confirmed in isolation | 3 | `python3 scripts/albion_formal.py mutate PERM-M04-LOG-OVERWRITE` |
| PERM-M05-BASE-LIMIT-SWAP | sf_albion_perm | functional | base register write lands in limit | PERM-NW8-IND d=6 | KILLED | PERM_READBACK_LIMIT, PERM_WINDOW_MATCHES_SPEC | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate PERM-M05-BASE-LIMIT-SWAP` |
| SEC-M01-NO-CORRECTION | sf_albion_secded_dec | functional | single-bit errors detected but never corrected | SECDED-SINGLE d=0 | KILLED | SECDED_SINGLE_CORRECTED | 1/1 confirmed in isolation | - | `python3 scripts/albion_formal.py mutate SEC-M01-NO-CORRECTION` |
| SEC-M02-PARITY-BIT-DROPPED | sf_albion_secded_enc | functional | overall parity bit of the encoder stuck at 0 | SECDED-CLEAN d=0 | KILLED | SECDED_CLEAN_ROUNDTRIP | 1/1 confirmed in isolation | - | `python3 scripts/albion_formal.py mutate SEC-M02-PARITY-BIT-DROPPED` |
| SEC-M03-DOUBLE-UNDETECTED | sf_albion_secded_dec | functional | double-bit errors not flagged uncorrectable | SECDED-DOUBLE d=0 | KILLED | SECDED_DOUBLE_DETECTED | 1/1 confirmed in isolation | - | `python3 scripts/albion_formal.py mutate SEC-M03-DOUBLE-UNDETECTED` |
| SRAM-M01-PARTIAL-FULLWRITE | sf_albion_sram_bank | functional | partial write overwrites the whole word (unwritten bytes destroyed) | SRAM-W8-IND d=14 | KILLED | SRAM_WRITE_ENABLE_LEGAL | 2/2 confirmed in isolation | 9 | `python3 scripts/albion_formal.py mutate SRAM-M01-PARTIAL-FULLWRITE` |
| SRAM-M02-STROBE-INVERTED | sf_albion_sram_bank | functional | RMW merge uses inverted byte strobes | SRAM-W8-IND d=14 | KILLED | lemma SRAM_CW_TRACKS_DATA | 1/1 confirmed in isolation | 11 | `python3 scripts/albion_formal.py mutate SRAM-M02-STROBE-INVERTED` |
| SRAM-M03-ACCEPT-DURING-SCRUB | sf_albion_sram_bank | security | bank accepts traffic before the scrub finished | SRAM-W8-IND d=14 | KILLED | SRAM_READY_GATING, SRAM_RESET_STATE | 2/2 confirmed in isolation | 1 | `python3 scripts/albion_formal.py mutate SRAM-M03-ACCEPT-DURING-SCRUB` |
| SRAM-M04-SCRUB-SHORT | sf_albion_sram_bank | security | scrub ends one word early: last word keeps the previous tenant's data | SRAM-W8-IND d=14 | KILLED | SRAM_SCRUB_BOUNDED | 2/2 confirmed in isolation | 8 | `python3 scripts/albion_formal.py mutate SRAM-M04-SCRUB-SHORT` |
| SRAM-M05-SCRUB-ONES | sf_albion_sram_bank | functional | scrub writes all-ones instead of zero | SRAM-W8-IND d=14 | KILLED | lemma SRAM_CW_TRACKS_DATA | 2/2 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate SRAM-M05-SCRUB-ONES` |
| SRAM-M06-RSPID-ZERO | sf_albion_sram_bank | protocol | response id always 0 | SRAM-W8-IND d=14 | KILLED | SRAM_RSP_MATCH | 1/1 confirmed in isolation | 10 | `python3 scripts/albion_formal.py mutate SRAM-M06-RSPID-ZERO` |
| SRAM-M07-RMW-WRONG-ADDR | sf_albion_sram_bank | functional | RMW commit writes to the CURRENT request's word | SRAM-W8-IND d=14 | KILLED | SRAM_WRITE_ENABLE_LEGAL | 1/1 confirmed in isolation | 10 | `python3 scripts/albion_formal.py mutate SRAM-M07-RMW-WRONG-ADDR` |
| SRAM-M08-WRITE-RSP-LEAK | sf_albion_sram_bank | security | write response returns stored data | SRAM-W8-IND d=14 | KILLED | SRAM_RSP_MATCH | 1/1 confirmed in isolation | 10 | `python3 scripts/albion_formal.py mutate SRAM-M08-WRITE-RSP-LEAK` |
| SRAM-M09-RMW-NEVER | sf_albion_sram_bank | functional | partial write never committed | SRAM-W8-IND d=14 | KILLED | lemma SRAM_PENDING_MIRROR | 1/1 confirmed in isolation | 10 | `python3 scripts/albion_formal.py mutate SRAM-M09-RMW-NEVER` |
| SRAM-M10-RESET-KEEPS-INIT | sf_albion_sram_bank | security | reset does not restart the scrub (previous tenant's data survives reset) | SRAM-W8-IND d=14 | KILLED | SRAM_RESET_STATE, lemma SRAM_CW_TRACKS_DATA | 1/1 confirmed in isolation | 1 | `python3 scripts/albion_formal.py mutate SRAM-M10-RESET-KEEPS-INIT` |
| SRAM-M11-UE-STILL-WRITES | sf_albion_sram_bank | functional | RMW commits even when the old word is uncorrectable | SRAM-W8-IND d=14 | SURVIVED (waived) | - | - | - | `python3 scripts/albion_formal.py mutate SRAM-M11-UE-STILL-WRITES` |
| SRAM-M12-MACRO-ADDR-FLIP | sf_albion_sram_macro | functional | macro read address bit 0 flipped | SRAM-MACRO-IND d=8 | KILLED | SRAM_MACRO_CONTRACT | 1/1 confirmed in isolation | 2 | `python3 scripts/albion_formal.py mutate SRAM-M12-MACRO-ADDR-FLIP` |

* **SRAM-M11-UE-STILL-WRITES** survives by design: Only observable with fault injection; the data-correctness jobs assume SRAM_NO_INJ, and the ECC bank-level job (SRAM-ECC) is NOT implemented. Listed in unresolved.json (U-SRAM-ECC).
* **PERM-M03-COUNT-WRAPS** survives by design: Differs from the original only after 2^32 violations; a bounded run cannot reach it. The unmutated property is PROVEN by k-induction (PERM-NW8-IND), which covers the saturating branch.
* **CITG-M03-STALE-VERDICT** survives by design: Fail-CLOSED availability bug, not a safety violation: permit_q resets to 0 and is only ever latched from a value derived from itself, so the mutated gate forwards NOTHING. No safety property can fail; detecting it needs a progress property (a permitted request is eventually forwarded), which is outside the safety scope (U-LIVENESS). Analysed, not ignored.

## 7. Unresolved, not claimed, not applicable

| Id | Status | What | Why |
|---|---|---|---|
| U-LIVENESS | **NOT CLAIMED** | Unbounded liveness: every accepted request / every started DMA transfer eventually completes | Needs a fairness model of the environment (slaves/targets eventually accept and respond; masters persist). No such model is part of the RTL contract and none was proven. What IS proven is bounded: local error responses arrive the next cycle (FAB_RSP_LOCAL_ERROR); with always-ready slaves an eligible request waits at most NM-1 cycles (FAB_ARB_BOUNDED_WAIT, CONDITIONAL). |
| U-DMA-ERRPATH | **BOUNDED (BMC 16 cycles from reset); k-induction not closed** | DMA: unbounded proof of error-path accounting and counter bounds | k-induction (k=6) yields counterexamples from unreachable states in which err_idx / FIFO count / completed-write count are mutually inconsistent. The missing helper invariants relate FIFO count, successful-read count and the failing-beat index across the read-fail and write-fail (FIFO flush) cases. Not attempted further; no bug is implied. |
| U-SRAM-ECC | **NOT PROVEN at bank level** | SRAM bank with fault injection: single-bit correction / double-bit detection AT BANK LEVEL | The code itself is proven exhaustively (SECDED-CLEAN / SINGLE / DOUBLE, all 2^32 words). The bank-level data-path proofs assume SRAM_NO_INJ. A bank-level proof with injected faults (including the UE-aborted read-modify-write: mutant SRAM-M11) needs a codeword-level shadow with an injected-mask model and was not built. |
| U-SRAM-SIZE | **PROVEN at WORDS=8 only** | SRAM bank at the product size (WORDS = 4096) | Proof is for an arbitrary tracked word at WORDS=8. Size independence is argued (the scrub counter is the only size-dependent logic and is covered by SRAM_SCRUB_BOUNDED / counter lemmas at AW=3), not machine-checked at AW=12. |
| U-CIT-SCALE | **PROVEN/BOUNDED at NDOM=2, NW=2, NP=1, NDEV=1, NQ=2 only** | Citadel at product parameters (NDOM=8, NW=4, NP=4, NDEV=7, NQ=16) | Reduced parameter point (assumption CIT_PARAM_POINT). Address width is the product 64 bits for the permission checker and gate; the table is checked at AW=6. |
| U-CIT-COMPLETE | **NOT CLAIMED** | Citadel permission checker COMPLETENESS (spec permits => RTL permits) | Only the safety direction (permit => spec) is proven. The converse needs unique domain ids (invariant INV-UNIQ of the table) and an exact reference for the device/priv rules; the authors' own equivalence check (formal/citadel) covers it, this suite does not. |
| U-TRANSLATION | **NOT APPLICABLE** | Invalidation prevents stale TRANSLATION use | Neither Albion nor Citadel contains address translation / an IOMMU (docs/citadel/08: 'No address translation / IOMMU'). The stale-use hazards that DO exist (stale domain descriptor after REVOKE, stale window after CLR_WINDOW, stale verdict in the gate) are proven (CIT_TBL_*, CIT_GATE_NO_BYPASS). Host-side IOMMU/VFIO behaviour is outside this RTL. |
| U-DOMAINGUARD | **NOT PRESENT** | A module literally named 'DomainGuard' | No RTL named DomainGuard exists in the repository. The security properties of section 5 were applied to the modules that implement domain protection: the Albion fabric permission stage + window table (sf_albion_datafabric, sf_albion_perm) and the Citadel domain table / permission checker / gate (P89). Datafabric sfd_host_guard / sfd_sram_guard and secureboot sb_dma_guard (other projects) were not verified. |
| U-OUTOFSCOPE | **NOT VERIFIED** | Blocks not verified | Outside the requested scope. Consequence: the fabric proofs assume MASTER_1PO and SLAVE_RSP_MATCH for the CORE/HOST masters and the MMIO/HOSTMEM slaves; those assumptions are discharged only for the DMA ports and SRAM banks. |
| U-CDC | **NOT MODELLED** | Reset-deassertion timing, reset-domain crossing, metastability, clock gating, scan/DFT paths | Cycle-based single-clock formal model (assumption CLK_IDEAL). Citadel's asynchronous reset is modelled step-synchronously (async2sync). |
| U-SBY | **NOT EXECUTED** | SymbiYosys (sby) execution | sby could not be installed in the build environment (not in apt/PyPI; GitHub downloads blocked by policy). All results come from the native driver, which runs the same yosys + yosys-smtbmc / yosys-abc flow sby generates. A job.sby is generated for every smtbmc job but was NEVER run. |
| U-SYSTEM | **NOT BUILT** | Composed system proof: closing the assume-guarantee loop MASTER_1PO / DMA_RSP_OUT, and 'illegal DMA requests never change protected memory' (DMA + fabric + SRAM banks) | (1) The fabric proofs assume MASTER_1PO and SLAVE_RSP_MATCH; the DMA proofs assume DMA_RSP_OUT, which the fabric provides only under MASTER_1PO: this loop is CIRCULAR and is NOT closed by any machine-checked composed theorem. (2) 'An illegal DMA request never changes protected memory' follows from FAB_DENIED_NOT_FORWARDED + SRAM_WRITE_ENABLE_LEGAL + DMA_WR_BEAT_BOUNDS but is argued in prose, not proven as one composed property. The wiring of sf_albion_cloud_top (which master reaches which bank) is not verified. |

### Automatically derived: properties whose STRONGEST result is bounded / failed / timed out

| RTL module | Property | Strongest result | Deepest evidence | Jobs |
|---|---|---|---|---|
| sf_albion_dma | `DMA_ACCOUNTING_ERR` | **BOUNDED** | BMC 16 cycles from reset | DMA-D4-BMC, DMA-D4-IND |
| sf_albion_dma | `DMA_ACCOUNTING_OK` | **BOUNDED** | BMC 16 cycles from reset | DMA-D4-BMC, DMA-D4-IND |
| sf_albion_dma | `DMA_BYTES_BOUND` | **BOUNDED** | BMC 16 cycles from reset | DMA-D4-BMC, DMA-D4-IND |
| sf_albion_dma | `DMA_COUNTERS_VALID` | **BOUNDED** | BMC 16 cycles from reset | DMA-D4-BMC, DMA-D4-IND |

(28 further BOUNDED rows above in section 3 are BMC-only runs of properties that are proven unbounded in another job; the property-level result in section 2 is the stronger one.)

## 8. Counterexamples against the UNMUTATED RTL

None: no property of the unmutated RTL was refuted in any job.

## 9. Observations about the RTL (not property failures)

* **F-01** (`FAB-FINDINGS-NB4-NW2`): two masters denied in the same cycle yield ONE violation event (`viol_o` is a single bit and only the lowest-indexed master is logged). `PERM_VIOL_COUNT` / `TC_PERM_VIOL` therefore count cycles with a denial, not denials. Both requests are still denied and answered `PERM`; this affects telemetry accuracy, not isolation.

