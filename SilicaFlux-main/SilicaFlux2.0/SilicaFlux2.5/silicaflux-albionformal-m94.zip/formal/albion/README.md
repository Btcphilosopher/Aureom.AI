# AlbionFormal — formal hardware verification for SilicaFlux (Module 94)

A reproducible formal verification suite for the SilicaFlux **Albion P90** RTL (DataFabric, banked SECDED SRAM, protected
DMA, permission window table) and the **Citadel P89** domain-protection RTL (domain table, permission checker, enforcement
gate). It tells you precisely which properties are **proven for all time**, which are proven **only under stated assumptions**,
which are **only bounded**, and which are **unresolved**.

> Start with `reports/SUMMARY.md`, then `reports/PROOF_LEDGER.md`. Then `docs/METHODOLOGY.md` (what the result classes mean and where the tool flow could be wrong)
> and `docs/REQUIREMENTS_TRACE.md` (brief -> RTL -> property -> job, including what does not exist in the RTL).

## Quick start

```bash
sudo apt-get install -y yosys z3 cvc5 python3          # Ubuntu 24.04: yosys 0.33, z3 4.8.12, cvc5 1.1.2 (what produced the shipped results)
cd formal/albion
python3 scripts/albion_formal.py selfcheck             # tool versions + RTL hash check
ci/ci_formal.sh smoke                                  # fast proofs + covers of every module, then ledger + CI gates
python3 scripts/albion_formal.py run FAB-NB2-NW2       # one job; raw tool commands land in build/FAB-NB2-NW2/repro.sh
python3 scripts/albion_formal.py mutate FAB-M01-DMA-FWBANK
ci/ci_formal.sh all                                    # everything: full proofs, mutation campaign, sensitivity, ledger, gates
```

Exit status of `ci/ci_formal.sh` is non-zero when a gate fails (unexpected result class, unreached cover, stale result,
cross-check disagreement, unwaived mutant survivor).

## Layout

| Path | Content |
|---|---|
| `vendor/` | the RTL under test, **unmodified**, with `SOURCES.sha256` (hashes verified before every run) |
| `harness/` | formal harnesses (`fv_*.sv`) and white-box property files (`bind/*.svh`) incl. independent spec models |
| `lib/` | `albion_formal.svh` (assertion/assumption/cover macro library) and `sf_fv_ctrl.sv` (clock/reset environment) |
| `config/` | `jobs.json` (parameterised proof configurations), `properties.json`, `assumptions.json` (the register), `unresolved.json` |
| `scripts/` | `albion_formal.py` (driver), `gen_mutants.py`, `make_ledger.py`, `check_gates.py`, `make_env.py` |
| `mutants/` | the mutation campaign (generated) |
| `ci/` | CI entry script and an example GitHub Actions workflow (not installed anywhere) |
| `reports/` | `SUMMARY.md` (one page), `PROOF_LEDGER.md/.json/.csv` (the ledger), raw `results/*.json`, `repro/<job>/{repro.sh,job.sby}` (portable raw tool commands; job.sby never executed), `mutation/cex/` (counterexamples of injected bugs), `sensitivity/cex/` (counterexamples under deliberately dropped assumptions), `counterexamples/` (empty: no property of the unmutated RTL was refuted), `environment.json` |
| `build/` | per-job work dirs created on demand (staged RTL with binds applied, logs, `.smt2`/`.aig` models, waveforms `.vcd`); NOT shipped in the zip |

## Scope in one paragraph

Verified: `sf_albion_datafabric`, `sf_albion_sram_bank` (+ SECDED, macro), `sf_albion_dma` (+ FIFO), `sf_albion_perm`,
`sf_citadel_permission`, `sf_citadel_gate`, `sf_citadel_domain_table`. **Not** verified: ControlCore, host interface, mailbox/management,
MMIO, RAS, telemetry, top-level wiring, Citadel fault manager/crypto/secure boot. There is **no module named DomainGuard**; the
domain-protection modules above were verified in its place. There is **no address-translation hardware**, so "stale translation use" is
verified through its real analogues (stale domain descriptor / window / verdict). See `config/unresolved.json`.

## Honest limits

* `sby` could not be installed where the results were produced; they come from the native driver running the same yosys flow. `job.sby`
  files are generated but were never executed.
* Reduced parameter points for some proofs (SRAM WORDS=8; Citadel NDOM=2/NW=2); parametricity is argued, not proven.
* Cycle-based, single ideal clock, 2-state. No CDC/RDC, X-propagation, timing, power or physical verification.
* No unbounded liveness is claimed anywhere. Bounded-latency properties are labelled as such.
* The fabric/DMA protocol assumptions (`MASTER_1PO`, `DMA_RSP_OUT`) are backed by each other **circularly**; no composed proof closes the loop (U-SYSTEM). `SLAVE_RSP_MATCH` is backed for SRAM banks only.
* A passing proof is only as good as its environment assumptions; every one is in `config/assumptions.json` with its risk and what discharges it.
