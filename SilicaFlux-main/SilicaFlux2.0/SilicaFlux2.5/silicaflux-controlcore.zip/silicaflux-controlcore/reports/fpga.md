# FPGA implementation (ControlCore harness, ULX3S LFE5U-85F-CABGA381)

Tool outputs in `fpga/build/` (regenerate: `make fpga`). **No hardware run**: the bitstream has never been loaded on a board. Timing is nextpnr's post-route estimate for one seed.

Tools: Yosys 0.33 (git sha1 2584903a060); "nextpnr-ecp5" -- Next Generation Place and Route (Version 0.6-3build5).

## Synthesis (Yosys `synth_ecp5`, flattened, harness included)

| Cell | Count |
|---|---|
| LUT4 | 15187 |
| TRELLIS_FF | 3815 |
| CCU2C | 1287 |
| PFUMX | 2087 |
| L6MUX21 | 429 |
| TRELLIS_DPR16X4 | 114 |
| DP16KD | 80 |
| MULT18X18D | 0 |

## Place and route (nextpnr-ecp5 0.6, `--85k --package CABGA381 --freq 25 --seed 1`)

| Resource | Used | Available | % |
|---|---|---|---|
| TRELLIS_IO | 12 | 365 | 3 % |
| DCCA | 1 | 56 | 1 % |
| DP16KD | 80 | 208 | 38 % |
| MULT18X18D | 0 | 156 | 0 % |
| TRELLIS_FF | 3815 | 83640 | 4 % |
| TRELLIS_COMB | 18791 | 83640 | 22 % |
| TRELLIS_RAMW | 114 | 10455 | 1 % |

**Post-route maximum frequency estimate: 27.42 MHz -- PASS at the 25.00 MHz constraint** (placement-stage estimate 17.05 MHz).

Critical register-to-register path (post-route report in `fpga/build/nextpnr.log`): IMEM block-RAM read data -> byte-parity check (`mcu_sram_bank`) -> crossbar response routing -> CPU fetch / interrupt-entry decision -> crossbar request decode. Logic depth is low; most of the delay is routing.

Bitstream `fpga/build/cc_fpga.bit` SHA-256 `e5dad25669b75daae128675eba6b434672f37febbbaca38213c1c48b1a4ac6ce`.

## Per-module breakdown (Yosys `-noflatten`; totals exceed the flattened run: no cross-boundary optimisation)

| Module (one instance) | LUT4 | FF | DP16KD |
|---|---|---|---|
| `mcu_cpu` | 4130 | 476 | 0 |
| `cc_perf` | 3942 | 714 | 0 |
| `cc_mailbox` | 1948 | 636 | 0 |
| `cc_sysctrl` | 1206 | 279 | 0 |
| `sfv_bootrom_image` | 1195 | 0 | 0 |
| `mcu_dma` | 1114 | 354 | 0 |
| `cc_ras` | 933 | 208 | 0 |
| `sfb_rsp_router` | 719 | 0 | 0 |
| `sfv_timer` | 658 | 161 | 0 |
| `sfv_periph_bridge` | 640 | 34 | 0 |
| `paramod` | 629 | 239 | 0 |
| `mcu_cpu_muldiv` | 531 | 177 | 0 |
| `sram_fpga_1rw` | 508 | 5 | 48 |
| `mcu_wdt` | 458 | 136 | 0 |
| `mcu_sram_bank` | 408 | 64 | 0 |
| `sfb_crossbar` | 323 | 29 | 0 |
| `cc_secmon` | 262 | 99 | 0 |
| `cc_fpga_top` | 241 | 68 | 0 |
| `sfb_req_mux` | 207 | 0 | 0 |
| `cc_pmu` | 183 | 69 | 0 |
| `sram_rsp_path` | 153 | 20 | 0 |
| `silicaflux_control_core` | 136 | 33 | 0 |

Area notes: `mcu_cpu` (RV32IM, iterative M unit, no DSP) is the largest block. `cc_perf` (20 x 32-bit saturating counters + 64-bit cycle counter with freeze/clear and a 22-way read mux) is the largest NEW block; reducing the event count or dropping saturation would shrink it. The boot ROM is synthesised as logic (`sfv_bootrom_image`, 522 words). Block RAM: IMEM 64 KiB and DMEM 32 KiB with byte parity (36-bit words) = 48 DP16KD; the harness device memory adds 32.

## Full system resource estimate (ControlCore + vector tile + tensor unit, Yosys only, no P&R)

| Cell | Count |
|---|---|
| LUT4 | 74672 |
| TRELLIS_FF | 26705 |
| CCU2C | 12273 |
| PFUMX | 11157 |
| L6MUX21 | 900 |
| TRELLIS_DPR16X4 | 737 |
| DP16KD | 88 |
| MULT18X18D | 93 |

Logic-cell estimate: LUT4 + 2 x CCU2C = **99218** TRELLIS_COMB-equivalent cells (+ 737 distributed-RAM cells) against **83 640** on the LFE5U-85F: the complete system (ControlCore + FP32 vector tile + INT8 tensor unit with quantisation and double buffering) **does not fit the largest ECP5** and was therefore not placed and routed. The ControlCore itself is about 15 % of it; the accelerator projects document their own separate ECP5 builds. A system prototype needs a larger FPGA (or a reduced accelerator configuration).

