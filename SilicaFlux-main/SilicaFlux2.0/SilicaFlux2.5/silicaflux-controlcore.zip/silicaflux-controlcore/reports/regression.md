# System regression (ControlCore + vector tile + tensor unit, firmware on the RTL CPU)

Generated 2026-11-10 13:41 UTC by `scripts/regress.py`. Simulator: Verilator 5.020 2024-01-01 rev (Debian 5.020-1). Firmware: riscv64-unknown-elf-gcc (13.2.0-11ubuntu1+12) 13.2.0; image 31584 B, CRC32 0x4e49b917.

**6 / 6 runs PASS.**

| Scenario | Back-pressure | Seed | Result | RTL cycles | Firmware checks (fails) | Testbench checks ok / fail | Wall time | Log |
|---|---|---|---|---|---|---|---|---|
| boot_host | 0 % | 1 | **PASS** | 2791325 | 231 (0) | 37 / 0 | 29.4 s | `reports/sim/boot_host_bp0_s1.log` |
| boot_host | 40 % | 7 | **PASS** | 2798937 | 231 (0) | 37 / 0 | 30.3 s | `reports/sim/boot_host_bp40_s7.log` |
| boot_ext | 0 % | 1 | **PASS** | 2348598 | 82 (0) | 8 / 0 | 25.1 s | `reports/sim/boot_ext_bp0_s1.log` |
| boot_ext | 25 % | 3 | **PASS** | 2353682 | 82 (0) | 8 / 0 | 24.6 s | `reports/sim/boot_ext_bp25_s3.log` |
| bad_image | 0 % | 1 | **PASS** | 1841646 | 0 (0) | 10 / 0 | 20.2 s | `reports/sim/bad_image_bp0_s1.log` |
| wdt_reset | 0 % | 1 | **PASS** | 2027569 | 38 (0) | 7 / 0 | 22.6 s | `reports/sim/wdt_reset_bp0_s1.log` |

Scenario descriptions:

* **boot_host** (bp 0 %): host loads firmware; full self-test suite; host GEMM/vector/DMA commands; RAS; telemetry
* **boot_host** (bp 40 %): same, 40 % random back-pressure on device memory
* **boot_ext** (bp 0 %): ROM DMA-copies the image from device memory; self-test subset; host GEMM
* **boot_ext** (bp 25 %): same, 25 % back-pressure
* **bad_image** (bp 0 %): corrupted image rejected (CRC), corrected image accepted, host reset -> cold boot
* **wdt_reset** (bp 0 %): watchdog early warning, timeout reset, warm boot without the host, recovery
