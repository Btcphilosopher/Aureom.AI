# Results summary (final run on the frozen sources)

Every number is copied from the tool output named in the last column (`reports/`).

| Gate | Result | Source |
|---|---|---|
| System regression (ControlCore + vector tile + tensor unit) | **6 / 6 PASS** | `regression.md` |
| Firmware checks executed on the RTL (all runs) | **664 checks, 0 fails** | `sim/*.log` |
| Testbench (host-side) checks | **107 ok, 0 fail** | `regression.md` |
| cocotb unit tests | **19 / 19 PASS** | `unit.md` |
| riscv-tests on the CPU (RV32M = 1) | **pass=63 fail=0** | `isa/riscv_tests_m1.txt` |
| Lint / elaboration gates | **4 / 4 PASS** | `lint.md` |
| Address-map validator | **18 / 18 PASS** | `memmap_tests.md` |
| Vendored files identical to the repository archives | **160 files, 0 problems** | `vendor_run.log` |
| FPGA post-route Fmax estimate (ULX3S 85F, ControlCore harness) | **27.42 MHz -- PASS at the 25.00 MHz constraint** | `fpga.md` |
| FPGA utilisation (TRELLIS_COMB / FF / DP16KD) | **18791 / 3815 / 80** | `fpga.md` |
| FPGA harness RTL simulation | **PASS** | `sim/fpga_harness.log` |

Not performed: FPGA board run, gate-level simulation, formal proof of the new RTL, RISC-V architectural compliance tests, firmware authentication (not implemented). See docs/09_LIMITATIONS.md.
