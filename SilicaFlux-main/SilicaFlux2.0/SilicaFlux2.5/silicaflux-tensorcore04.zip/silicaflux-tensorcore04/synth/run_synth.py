#!/usr/bin/env python3
"""
TENSORCORE 04 -- Yosys synthesis sweep (resource estimates only).

Generic `synth` (technology-independent cells) and `synth_xilinx` (7-series
LUT/FF/DSP mapping, no place & route) of tensor_acc_subsystem for several
configurations.  NO timing / Fmax is claimed: there is no place-and-route
and no timing library in this flow.

  python3 synth/run_synth.py
"""
import os
import re
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/tensor_acc_pkg.sv", "rtl/tensor_acc_fifo.sv", "rtl/tensor_acc_storage.sv",
       "rtl/tensor_acc_out_router.sv", "rtl/tensor_accumulator.sv", "rtl/tensor_acc_subsystem.sv"]

CONFIGS = [
    ("4x4_t2_acc32_rd1", dict(ROWS=4, COLS=4, NUM_TILES=2, ACC_W=32, OUT_W=32, RD_LAT=1)),
    ("4x4_t1_acc32_rd1_noperf", dict(ROWS=4, COLS=4, NUM_TILES=1, ACC_W=32, OUT_W=32, RD_LAT=1, PERF_EN=0)),
    ("4x4_t4_acc40_rd2", dict(ROWS=4, COLS=4, NUM_TILES=4, ACC_W=40, OUT_W=32, RD_LAT=2)),
    ("8x8_t2_acc32_rd1", dict(ROWS=8, COLS=8, NUM_TILES=2, ACC_W=32, OUT_W=32, RD_LAT=1)),
]


def run(name, params, flow):
    os.makedirs(os.path.join(ROOT, "synth/reports"), exist_ok=True)
    chp = " ".join(f"-set {k} {v}" for k, v in params.items())
    synth = "synth -flatten -top tensor_acc_subsystem" if flow == "generic" else \
        "synth_xilinx -flatten -top tensor_acc_subsystem -family xc7"
    ys = (f"read_verilog -sv {' '.join(RTL)}\n"
          f"chparam {chp} tensor_acc_subsystem\n"
          f"{synth}\n"
          f"tee -o synth/reports/stat_{flow}_{name}.txt stat\n")
    yfile = f"synth/reports/{flow}_{name}.ys"
    with open(os.path.join(ROOT, yfile), "w") as f:
        f.write(ys)
    r = subprocess.run(f"yosys -q -s {yfile}", shell=True, cwd=ROOT, capture_output=True, text=True, timeout=3600)
    with open(os.path.join(ROOT, f"synth/reports/{flow}_{name}.stdout"), "w") as f:
        f.write(r.stdout + r.stderr)
    if r.returncode != 0:
        return dict(name=name, flow=flow, ok=False, err=(r.stdout + r.stderr)[-600:])
    st = open(os.path.join(ROOT, f"synth/reports/stat_{flow}_{name}.txt")).read()
    cells = re.search(r"Number of cells:\s+(\d+)", st)
    out = dict(name=name, flow=flow, ok=True, cells=int(cells.group(1)) if cells else -1)
    if flow == "generic":
        ff = sum(int(n) for n in re.findall(r"\$_(?:S?DFF\w*|DFFE\w*|SDFF\w*|ALDFF\w*)_\s+(\d+)", st))
        out["ff"] = ff
    else:
        ff = sum(int(n) for n in re.findall(r"\bFD\w*\s+(\d+)", st))
        lut = sum(int(n) for n in re.findall(r"\bLUT\d\s+(\d+)", st))
        dsp = sum(int(n) for n in re.findall(r"\bDSP48E1\s+(\d+)", st))
        carry = sum(int(n) for n in re.findall(r"\bCARRY4\s+(\d+)", st))
        ram = sum(int(n) for n in re.findall(r"\bRAM\w+\s+(\d+)", st))
        out.update(ff=ff, lut=lut, dsp=dsp, carry4=carry, lutram=ram)
    return out


def main():
    res = []
    for name, p in CONFIGS:
        for flow in ("generic", "xc7"):
            r = run(name, p, flow)
            res.append(r)
            print(r if r["ok"] else f"FAIL {name} {flow}: {r['err']}", flush=True)
    with open(os.path.join(ROOT, "reports/synthesis_summary.md"), "w") as f:
        f.write("# TENSORCORE 04 synthesis summary (Yosys 0.33)\n\n")
        f.write("Resource estimates only. `synth -flatten` (generic gates) and `synth_xilinx -family xc7` "
                "(LUT/FF/CARRY4/DSP mapping, **no place & route**). No timing or Fmax is claimed.\n\n")
        f.write("| configuration | flow | ok | cells | FF | LUT | CARRY4 | DSP48 | LUTRAM |\n|---|---|---|---|---|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['name']} | {r['flow']} | {'yes' if r['ok'] else 'NO'} | {r.get('cells', '')} | "
                    f"{r.get('ff', '')} | {r.get('lut', '')} | {r.get('carry4', '')} | {r.get('dsp', '')} | "
                    f"{r.get('lutram', '')} |\n")
    return 0 if all(r["ok"] for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
