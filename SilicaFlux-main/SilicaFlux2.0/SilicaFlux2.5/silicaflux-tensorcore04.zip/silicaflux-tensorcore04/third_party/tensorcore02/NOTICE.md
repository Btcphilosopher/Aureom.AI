# Third-party: SilicaFlux TENSORCORE 02 systolic array

Copied **unmodified** from `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-tensorcore02.zip`
(repository `btcphilosopher/aureom.ai`; zip SHA-256 `0a2ab37797b30ab3eda08d7e98b47dadd1549f8ab588d434c98b18b0a048370f`).
Used only by the integration testbench (`tb/tb_integ.sv`); the accumulator RTL does not depend on it.

| file | SHA-256 |
|---|---|
| rtl/tensor_systolic_array.sv | 07be2f4be73cb01800406a690d2e1301b8e71db2efc46401c3fe38ca31604c20 |
| rtl/tensor_pe.sv | f931027f5c65b87b38cb962b303e31cd802b2ed6de9ff9bac8356ffcf237780f |
| rtl/tensor_skew.sv | a69f279fa282f22e2df5ea535c1b72bf7d37f4681b5c4c07a3d2f54b4e8bedae |
| rtl/tensor_output_collect.sv | ae2bf95f200152b8b45f80c89b7ddce6398f6a42e364007a896d199471aa2143 |

Note: TENSORCORE 01 also defines a module named `tensor_pe` with a different interface; the two cannot be
compiled together. Only the TC02 version is included here.
