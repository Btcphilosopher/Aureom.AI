# Audit: existing tensor PE, systolic array and memory interfaces

Repository: `btcphilosopher/aureom.ai`, branch `claude/fervent-dirac-skpqwf`, audited 2026-11-08.
Nothing was committed to the repository. This package is delivered only as a zip.

The repository is an archive store of zips, PDFs and images. TensorCore material lives in
`SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/`:

| archive | contents | SHA-256 |
|---|---|---|
| `silicaflux-tensorcore01-tensor_pe.zip` | TC01: `tensor_pe` (INT8 MAC PE), `tensor_pe_mesh` | — |
| `silicaflux-tensorcore02.zip` | TC02: `tensor_systolic_array`, its own `tensor_pe`, `tensor_skew`, `tensor_output_collect` | `0a2ab377…370f` |
| **TENSORCORE 03** | **not present anywhere in the repository** (no operand-buffer RTL was found) | — |

The TC02 smoke test (`make smoke`, 2×2, 116 tests) was re-run here and **passes** (Icarus 12.0).
Its four RTL files are copied **unmodified** into `third_party/tensorcore02/rtl/`; hashes are listed in
`third_party/tensorcore02/NOTICE.md`.

## 1. Do the PEs already contain accumulators?

**Yes, in both PE implementations.**

| | TC01 `tensor_pe` | TC02 `tensor_pe` (used by the TC02 array) |
|---|---|---|
| accumulator | `acc_q`, signed `ACC_W` (32 default, 40 verified) | `acc_q`, signed `ACC_WIDTH` (32 default) |
| restart | `clear_acc_i` token travels with the first operand pair ("clear-and-load") | **every launch zeroes all PE accumulators** in the one-cycle `S_CLEAR` state (`if (!rst_n \|\| clr) acc_q <= '0`) |
| overflow | exact detection, sticky `overflow_o`, SATURATE or WRAP | **none: wraps silently** |
| exactness bound | `2^(ACC_W-15)-1` = 131 071 at 32 bits | `K_WIDTH = 17` caps one launch at 131 071, the same bound |
| used by | `tensor_pe_mesh` (reference only, no controller) | `tensor_systolic_array` (FSM, skew, readout) |

**The two modules share the name `tensor_pe` with incompatible ports.** They cannot be compiled into one
design. This package depends only on the TC02 array (and therefore the TC02 PE); TC01 was read but not
instantiated.

## 2. Accumulator width

The TC02 array is instantiated with `ACC_WIDTH = 32`. Partial sums leave the array as signed 32-bit lanes.
This module receives them as `PSUM_W = 32`.

## 3. How partial sums are exported

TC02 is output-stationary. PE(i,j) holds C[i][j] until the tile completes. Then the FSM enters
`S_READOUT` and streams **one row per beat**: `m_valid/m_ready`, `m_row`, `m_data` (COLS × 32 b, masked
lanes are 0), `m_col_mask`, `m_last`. The accumulators are static during readout, so `m_ready`
backpressure cannot disturb them. `tile_done` is a level that stays high for the whole readout.

The accumulator's `ps_*` port is a direct superset of this stream: `ps_row/ps_data/ps_col_mask/ps_last`
connect to `m_*`, and `ps_ready` drives `m_ready`. The K-chunk sequencer adds the sideband
`{ps_slot, ps_tag, ps_chunk, ps_chunk_k}`, which is constant for the duration of one launch.

## 4. Can a K chunk be restarted?

* There is **no accumulate-in-place** in TC02: a launch cannot continue from a previous partial sum.
  Every launch is a fresh chunk computed from zero.
* There is **no abort input**. The only way to stop a chunk mid-flight is the array's `rst_n`. After
  that the chunk is re-run by launching it again.
* **The double-add hazard therefore lives at the readout.** Suppose the array is reset (or the chunk is
  re-run for any reason) after some rows of the chunk were already handed over. Those rows would be
  offered again. A naive downstream accumulator would add them twice.

This module removes that hazard with a per-row chunk sequence number (`nch`). A beat for chunk `c` is
added only if `c == nch[row]`. A beat with `c < nch[row]` is a replay and is dropped (counted as
`PSUM_DUP`). A beat with `c > nch[row]` is a skipped chunk: it is rejected as an error and is not added.
The integration test resets the TC02 array in the middle of chunk readouts and re-runs the chunk
(`tb/tb_integ.sv`, `arr_rst` jobs). The result stays exact, and the duplicate counter equals the number
of rows that had already been accepted.

## 5. "Do not create a second accumulator that adds the same products twice"

There are two accumulators in the datapath, but they never hold the same products:

* The **PE accumulator** holds only the current chunk. It is zeroed by `S_CLEAR` at every launch.
* The **persistent accumulator** (this module) holds only completed chunks, each added exactly once.

The integration testbench verifies the first property directly. Every one of the array's readout beats
is compared with the **chunk-local** partial sum Σ_{k∈chunk} A·B, computed in the TB from the job's A/B.
A PE that carried a sum across launches would fail this check on the second chunk. (TC01's PE *can*
carry a sum across accumulations if `clear_acc_i` is not asserted on the first pair of each chunk. Any
future integration of TC01 must assert it, or this module would see prefix sums. This is documented in
`ARCHITECTURE.md` §2.)

## 6. Existing memory interfaces

| interface | location | shape | relation to this module |
|---|---|---|---|
| TC02 operand input | `tensor_systolic_array` `s_valid/s_ready, s_a, s_b` | one k-slice per handshake | driven by the K-chunk sequencer / operand buffers (TC03, absent); the testbench models it |
| TC02 result output | `m_*` (above) | one row per beat | **direct input of this module** |
| HPC scratchpad | `silicaflux-hpc-m04-scratchpad.zip`, `hpc_scratchpad` | per-port ready/valid word requests (`we`, byte address, `wdata`, `wstrb`, `tag`), `READ_LATENCY` 1..8, multi-bank | candidate **output SRAM**; one result beat (COLS × 32 b) maps to COLS/`DATA_WIDTH`-word writes at `base + row·stride`. **No adapter is included or verified.** |
| HPC DMA adapter | `silicaflux-hpc-m05-dma-adapter.zip`, `hpc_dma_adapter` | descriptor-driven copy (`cmd_src/dst/len`) between scratchpad and fabric | not a stream sink; the "DMA path" port here is a stream that a DMA-side buffer (or the scratchpad) consumes |
| `sfx_accumulator` | `silicafluxai.zip`, `rtl/arithmetic/` | register file, same-cycle read-modify-write, `clear` = load | prior art for "the first K pass loads instead of adds"; it belongs to the weight-stationary silicaflux-ai lineage, wraps silently, and has no pipelining, duplicate filtering or output path. **Not reused.** |

## 7. Conventions adopted

* Clock/reset: `clk` / `rst_n`, synchronous active-low, as in the TC02 array that drives this module.
  (TC01 uses `clk_i/rst_ni` with asynchronous assertion. Integrating both styles needs a reset
  synchroniser in any case.)
* Flat packed buses with `+:` lane slicing (no unpacked-array ports: Icarus limitation documented by
  silicaflux-ai and TC02).
* Package with scoped references only, no `return` in functions (Yosys 0.33), `translate_off` around
  elaboration checks (same mechanism as TC02).
* Testbench discipline from TC02: DUT outputs are never read by a thread *at* a clock edge; an edge
  sampler latches handshakes and threads read them after `@(posedge clk); #1`. This was needed here too:
  without it, Verilator 5.020 resumed a driver thread after the edge's non-blocking updates and missed its
  own handshake (found and fixed during this work).

## 8. Tools

Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33 (the versions TC01/TC02 used) were installed from
the Ubuntu archive for this work. Python 3 with the standard library only.
