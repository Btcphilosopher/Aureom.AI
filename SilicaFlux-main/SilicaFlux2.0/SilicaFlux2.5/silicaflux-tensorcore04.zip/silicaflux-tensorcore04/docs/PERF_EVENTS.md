# Performance events

Every event is exposed two ways:

* `ev_inc[i*EVW +: EVW]`: the event's **increment in this cycle** (combinational; `EVW = clog2(COLS+1)`
  bits, because element events can count up to COLS per cycle). Feed an external counter block (for
  example the HPC m07 perf-counter module) from here.
* `perf_o[i*PERF_W +: PERF_W]`: an internal **saturating** counter (`PERF_EN = 1`, `PERF_W = 40`
  default). It never wraps: at `2^PERF_W − 1` it stays there (tested with `PERF_W = 6`). It is cleared by
  `rst_n` or a `perf_clr` pulse (tested).

Indices are `tensor_acc_pkg::PF_*`.

| idx | name | increments when | per cycle | checked against |
|---|---|---|---|---|
| 0 | `PSUM_BEATS` | **partial sums accepted**: a `ps_valid & ps_ready` handshake (applied, duplicate or rejected) | 0/1 | model, exact |
| 1 | `PSUM_ELEMS` | elements actually added: popcount of the tile's column mask for each applied beat | 0..COLS | model, exact |
| 2 | `PSUM_DUP` | replayed beats dropped (`chunk < nch[row]`) | 0/1 | model; integration: == rows replayed after array restarts |
| 3 | `PSUM_ERR` | malformed beats dropped (any `PE_*` code) | 0/1 | model, exact |
| 4 | `RD_STALL` | **accumulator read stall**: pipeline enabled, at least one op wants to issue (commit read pending with credit, host op with credit, or `ps_valid`), and the storage read port is busy (`st_rd_ready = 0`) | 0/1 | TB bounds: ≥ cycles(read port busy ∧ enabled ∧ ps_valid), ≤ cycles(read port busy ∧ enabled) |
| 5 | `WR_STALL` | **accumulator write stall**: the W stage holds a write and the write port is busy; the pipeline is frozen | 0/1 | TB observation, exact |
| 6 | `OVF_ACC` | **overflow events**: element adds whose exact result left the ACC_W range | 0..COLS | model, exact |
| 7 | `OVF_OUT` | committed elements clipped when narrowed to OUT_W | 0..COLS | model, exact |
| 8 | `COMMIT_ELEMS` | **output commits** (elements): popcount of the column mask of each result beat retired by the router | 0..COLS | model, exact |
| 9 | `COMMIT_TILES` | **output commits** (tiles): the last row of a tile retired | 0/1 | model; integration: == jobs |
| 10 | `CHUNKS` | **K chunks completed**: an applied beat makes every active row of its tile reach chunk c+1 (`cdone` advances) | 0/1 | model; integration: == chunks applied |
| 11 | `IN_STALL` | `ps_valid & ~ps_ready` (psum backpressure, any cause) | 0/1 | TB observation, exact |
| 12 | `OUT_STALL` | a result beat is waiting: `o_valid & ~o_ready` | 0/1 | TB observation, exact |
| 13 | `CFG_REJECT` | a tile configuration was consumed and rejected | 0/1 | model, exact |
| 14 | `HOST_OPS` | host operations accepted | 0/1 | model, exact |
| 15 | `BUSY` | the accumulator is not idle (ops in flight, FIFOs non-empty, or a tile committing) | 0/1 | not checked (utilisation aid) |

Notes:

* `PSUM_BEATS = applied + PSUM_DUP + PSUM_ERR`, and `PSUM_ELEMS = Σ_applied popcount(mask)`.
* After `HC_CLEAR` of a row, that row re-reaches every chunk level, so `CHUNKS` counts those completions
  again. It counts completion events, not distinct chunks.
* Counters are reset with the accumulator. Rows of a tile that was committing when reset hit may
  already have been counted in `COMMIT_ELEMS`.
* The unit testbench compares every deterministic counter (0–3, 6–10, 13, 14) with the model's
  prediction at **every barrier**, including saturation (`PERF_W = 6`). It compares 5, 11 and 12 with
  its own cycle-by-cycle observation of the interface, and bounds 4. Mutants m31 and m32 (wrong element
  count, missing chunk event) are killed by these checks.

Status signals beside the counters: `err_pulse/err_code` (one cycle after a rejected beat), `err_sticky`
(bit c set once error code c has occurred), `cfg_reject/cfg_reject_code`, `cmt_done` with
`cmt_tag/slot/ovf/clip/err`, `slot_state`, `idle`.
