# Verification report

All numbers below come from the final runs on the frozen sources (`logs/`, `reports/`).

## 1. Method and independence

| layer | what it is | independent of the RTL because |
|---|---|---|
| `model/acc_ref.py` | exact Python-integer model: `gemm_ref` (bias + A@B) and the architectural model (chunk sequencing, duplicate filter, checks, bias-once, overflow policy, narrowing, host ops, deterministic counters) | written from the contract in `ARCHITECTURE.md` / `NUMERIC_RANGE.md`; no fixed-width arithmetic except where the contract narrows |
| `tests/test_ref_model.py` | K bound by integer division, by brute-force enumeration (small widths) and against the RTL's shift formula (DATA_W 2..8, W ≤ 64); 300 random partitions == direct GEMM; replay and policy examples | stdlib only |
| generators | `tools/gen_unit.py`, `tools/gen_integ.py` | every in-range tile's expected result is asserted equal to `gemm_ref` **before** a vector is written, so no vector can encode a partition-dependent "expected" value. The model raises `Nondeterministic` if a scenario's outcome could depend on hardware timing, and the generator asserts that concurrent host/psum streams cannot interfere; these guards caught 4 generator bugs (§8) |
| `tb/tb_acc.sv` | unit TB around `tensor_acc_subsystem` | adds only timing (random gaps, random ready per port, random storage contention); all values come from the vectors |
| `tb/tb_integ.sv` | the **unmodified TC02 array** feeding the accumulator, one launch per K chunk; array restarts cut a readout after **exactly** r rows (the TB holds `ps_ready` low and releases it beat by beat), so the expected duplicate count is exact | expected C from Python; every array readout beat is also checked against a TB-side 64-bit chunk-local partial sum |

**Race-free on both simulators.** Driver threads read DUT outputs only through an edge sampler, after
`@(posedge clk); #1`. Barrier hand-over runs in one clocked controller. Every run that executes on both
simulators with the same vectors and seed must produce **line-identical** TB logs: the regression's
`x-check` rows.

## 2. Stage order (as required)

**Stage 1: accumulation across exactly two K chunks.** It runs first, on the 4×4 baseline, on both
simulators, with every timing profile:

* unit: the same 8-term reduction split [4,4], [1,7], [7,1], [6,2] (identical results asserted); two
  chunks + bias; an M = 1 tile (chunk 1 hits the same entry back-to-back: RAW); a chunk-0 replay before
  and interleaved with chunk 1; a partial 3×3 tile with extreme operands; two tiles in two slots with
  interleaved chunks; K = 2 as [1,1] with −128·−128.
* integration (real TC02 array): the same four two-chunk partitions; bias; M = 1; an **array reset in
  the middle of the chunk-1 readout** followed by a re-run of the chunk; a partial tile.

Only when stage 1 passes does the regression run stage 2, which generalises to arbitrary chunk counts
(1 … 301 chunks per tile in the regression, up to 301 chunks of 131 071 K-steps; 1 000 chunks in the throughput measurement).

## 3. Traceability: brief → tests

| required test | where | notes |
|---|---|---|
| K shorter than one chunk | unit `basic` (K = 1, 3, 15 with chunk 16); integ `general` (K = 5 with chunk 32) | single chunk, `chunk_k < KC` |
| K exactly one chunk | unit `basic` (K = 16 random and −128 extremes); integ `general` (K = 32) | |
| K crossing chunk boundaries | unit `basic` (17, 31, 50); integ `general` (33, 65) | short last chunk |
| many chunks | unit `basic` (256 chunks of 1; **143 chunks of 7 (K = 1 000) on M = 1**: a RAW chain; K = 600 in up to 40 random chunks, rows shuffled); integ (96 chunks of 1; 25 × 8; 50 × 3 on M = 1); unit `overflow` ACC 40/48 (257 / 301 chunks of 131 071) | |
| negative accumulation | unit/integ: A = −128, B = 127 (all products −16 256) over 300–500 K; random all-negative products; worst negative K = 131 071 | |
| cancellation | unit/integ: odd chunks are the exact negation of the preceding chunk (2 and 8 pairs) → result is **exactly the bias**, asserted in the generator | |
| bias addition | unit: bias with 1, 2, 9, 31 chunks (a per-chunk bias would be visible), ±2^30 bias, zero bias, preload + bias; integ: bias over 30 chunks; mutant m01 (bias per chunk) killed | |
| backpressure | every run under profiles P0–P3 (unit) / Q0–Q2 (integ): psum gaps up to 40 %, output ready down to 5 %, host-response ready 10 %, storage read/write busy up to 40 %/60 %, array `stall_i` up to 40 %; payload stability checked on every port | |
| reset | unit `reset`: reset mid-accumulation (multi-slot), during a tile's commit, and inside a back-to-back RAW chain, then a full re-run must be exact; integ: accumulator reset mid-job then re-run; array reset mid-readout then chunk re-run | |
| overflow boundaries | unit `overflow`: K = 131 071 accepted / 131 072 rejected; bias 16 383 → **exactly INT32_MAX** accepted, 16 384 rejected; bias −16 793 472 → **exactly INT32_MIN** accepted, −1 more rejected; one hostile column rejects the tile; ACC 40: INT32 boundary ±1 clip/no-clip, K = 33 554 431; non-strict: first overflow on the last chunk (positive and negative), saturate vs explicit wrap, recovery after overflow, multi-row tile with one overflowing row; integ: **K = 131 071 through the real array**: 2 147 467 264, INT32_MAX, INT32_MIN | |
| repeated output tiles | unit: one slot reused 10× with the same data and 10 partitions (results asserted identical), sometimes without a barrier (cfg waits for the commit to drain); integ: one tile 5× in slot 0, partition-invariance groups | |
| read-after-write | M = 1 multi-chunk tiles at RD_LAT 1/2/3; coverage probe `raw_back_to_back`; mutants m04/m05/m06/m40 killed | |
| multiple psums to one element | the same; plus replay storms (every chunk sent 1–3 times) | |
| pipeline latency | RD_LAT 1, 2, 3 configurations; OFIFO depth 1 (credit-throttled) | |
| tile switching | all slots open at once with beats interleaved (whole tiles and row-shuffled), up to 4 slots; host traffic on one slot while another streams | |
| chunk restart | replays (unit), array reset mid-readout (integ): duplicate counter == rows replayed | |
| protocol errors | unit `errors`: every `PE_*` code, then recovery to the exact result with `o_err`; every `CR_*` code; every host error status | `PE_CHUNK_K` is exercised with `chunk_k = 0`; `chunk_k > PSUM_KMAX` cannot be expressed at the default `KC_W = 17` |
| **definition of done** | the same reduction under many partitions gives identical, exact results: unit stage 1 (4 ways), unit repeated tile (10 ways), integ `inv257` (6 partitions: 1, 17, 257 chunks and random), integ `rst60` (4 partitions with restarts), integ `accrst` | asserted equal in the generator, checked in hardware |

## 4. Regression results

`reports/regression_summary.md` lists every run. Summary: **1 160 checks passed, 0 failed**: 605 Icarus runs, 302 Verilator runs, 252
cross-simulator log comparisons (all identical) and the model self-test, over 26 configuration jobs.
Totals across the runs:

* unit: 356 869 partial-sum beats, 16 777 tiles, 18 706 tile configurations, 9 654 host responses,
  67 950 result beats checked field by field;
* integration (real TC02 array): 1 243 tiles, 17 443 array launches (K chunks), **53 271 array readout
  beats each checked equal to the chunk-local partial sum**, 180 array restarts in the middle of a
  readout (191 rows replayed and dropped as duplicates), 56 accumulator resets in the middle of a job;
* coverage probes (summed): 157 608 forwarded operands, 82 815 back-to-back RAW pairs on one entry,
  93 307 read-stall cycles, 188 153 write-stall (freeze) cycles, 296 349 output-backpressure cycles,
  10 114 commit reads issued while psums were waiting, and 7 158 cycles with a second tile ready to
  commit while one was draining.

Three runs (the 1×1 stage-1 job, whose restart is placed after its only row) take the path where the
whole chunk was accepted before the array reset hit, so the TB correctly does not re-run it.

| job | config | sims | suites |
|---|---|---|---|
| S1_unit_4x4, S1_integ_4x4 | 4×4, 2 slots, ACC 32, RD 1 | both | stage 1 |
| U_4x4_base | baseline | both | all 7 unit suites × P0–P3 × 2 seeds |
| U_2x2, U_1x1_1tile | small arrays, a single slot | Icarus | all |
| U_4x4_4tiles_rd2, U_4x4_3tiles_rd3 | 4 / 3 slots (non-power-of-two slot count), RD_LAT 2 / 3 | both / Icarus | all |
| U_3x5_acc40_out40_rd2 | non-square, 40-bit out | Icarus | all |
| U_4x4_acc40_out32, U_4x4_acc48_out32_rd2 | wide accumulator, INT32 output with clip | both / Icarus | all |
| U_4x4_sat_nonstrict, U_4x4_wrap_nonstrict, U_4x4_acc40_wrap_nonstrict | no static check; saturate / explicit wrap | both / Icarus | overflow, stage 1, soak |
| U_4x4_noguard | psum guard off | Icarus | errors, stage 1, soak |
| U_4x4_ofifo1 | 1-entry output FIFO | Icarus | all |
| U_4x4_perfw6 | 6-bit counters (saturation) | Icarus | all |
| U_8x8, U_16x16_4tiles | large tiles | Verilator | all / 5 suites |
| I_4x4_base, I_4x4_longk(_v) | real TC02 array, K up to 131 071 | both | stage 1, general, longk |
| I_2x2_rd2_mp1 | TC02 with `MUL_PIPE = 1`, RD_LAT 2 | both | stage 1, general |
| I_1x1_1tile, I_3x5_3tiles_acc40_rd3, I_4x4_acc40_out32, I_8x8 | shapes, slots, widths | various | stage 1, general (+longk) |

## 5. Throughput (measured, Icarus, profile P0)

`make perf`; logs in `logs/perf/`. One partial-sum beat is offered every cycle (no gaps, all ports
ready, no contention).

| RD_LAT | scenario | beats | accepted in | throughput | last beat → last result on the output |
|---|---|---|---|---|---|
| 1 | 1 000 back-to-back adds to **one** entry (M = 1, 1 000 chunks of 1 K-step) | 1 000 | 1 000 cycles (8 → 1 007) | **1 beat / cycle** | 4 cycles (= RD_LAT + 3) |
| 1 | 4×4 tile, 250 chunks | 1 000 | 1 000 cycles | 1 beat / cycle | 7 cycles (4 rows) |
| 2 | one entry, 1 000 chunks | 1 000 | 1 000 cycles | 1 beat / cycle | 5 cycles |
| 2 | 4×4 tile, 250 chunks | 1 000 | 1 000 cycles | 1 beat / cycle | 8 cycles |
| 3 | one entry, 1 000 chunks | 1 000 | 1 000 cycles | 1 beat / cycle | 6 cycles |
| 3 | 4×4 tile, 250 chunks | 1 000 | 1 000 cycles | 1 beat / cycle | 9 cycles |

The read-after-write chain to a single element never stalls: forwarding covers it at every RD_LAT. The
TC02 array delivers one readout row per cycle, so the accumulator does not slow it down except while a
finished tile drains (M commit-read cycles).

## 6. Mutation testing

`reports/mutation_report.md`: **40 of 41 mutants killed; the single survivor is an equivalent mutant**. The RTL's own simulation invariants are compiled out for
these runs (`TA_NO_INVARIANTS`), so every kill comes from the testbench checks alone.

The first mutation run found **two genuine test gaps**, now closed:

* **m28** (the tile overflow summary forgot earlier rows) survived because every overflow tile had
  M = 1. Multi-row tiles in which only row 0 overflows or clips were added.
* **m40** (forwarding from pipeline ops that do not write) survived because no host op ever ran on a
  slot that was receiving psums. Erroneous host ops address a real row but write nothing; a younger add
  to that row within RD_LAT+1 cycles would have taken a zero as its base. A scenario was added: host
  error ops (WRITE after a chunk → ERR_ORDER, READ/CLEAR with row ≥ M → ERR_ROW) fire at the *same* slot
  while it streams 78 chunks. These ops cannot change state, so the scenario stays deterministic.

The remaining survivor, **m39** (reset does not clear row metadata), is **equivalent by construction**:
row metadata is consulted only for open slots, and opening a slot re-initialises all its rows.

## 7. Lint and synthesis

* `verilator --lint-only -Wall`: clean for 8 parameter sets (`make lint`, `logs/final_lint.log`). Two
  waivers, each commented in the source: a vacuous comparison at the default widths, and a coverage
  probe read only by the TB.
* Yosys 0.33 (`reports/synthesis_summary.md`): generic and xc7 mapping of four configurations.
  **Resource estimates only; no place and route, no timing, no Fmax claim.**

## 8. Defects found during this work (all fixed; tests that found them are kept)

| # | where | defect | found by |
|---|---|---|---|
| 1 | RTL | `HC_ABORT` response echoed one row's metadata (the contract says zeros: ABORT is a slot op) | unit `host` suite vs model |
| 2 | TB | Verilator 5.020 resumed a driver thread after the edge's non-blocking updates, so the driver missed its own handshake (deadlock in Verilator only) | first Verilator run; fixed with the TC02-style edge sampler |
| 3 | TB | barrier hand-over between two threads at the same `#1` instant raced (1-cycle difference between simulators) | cross-simulator log comparison; fixed with one clocked barrier controller |
| 4 | generator | replays sent after a tile had completed (outcome depends on commit timing) | model `Nondeterministic` guard |
| 5 | generator | host READ issued in the same segment as the `cfg` that opens the slot | slot-disjointness assertion |
| 6 | generator | ACC 40 wrap test used a bias outside INT32 (the TB truncated it) | TB mismatch; fixed, and `cfg()` now asserts that bias fits BIAS_W |
| 7 | generator | 1×1 stage-1 replay landed after the tile completed | model guard |
| 8 | model | stale-tag beats to a committing tile were treated as nondeterministic (they are always `PE_NO_TILE`) | review while fixing #4 |
| 9 | tests | gaps behind mutants m28 and m40 | mutation testing (§6) |
| 10 | TB | a design that keeps emitting beats forever (mutant m27: wrong last-row detection) was detected at once, but the TB never terminated, because output beats count as progress for the watchdog | mutation testing; both TBs now stop after 200 errors |
| 11 | TB | the integration "array restart" asserted the array reset after r accepted rows, but one more row could be accepted at the reset edge itself. When that was the last row of the final chunk, the tile had already committed, and the TB's re-run was correctly rejected by the accumulator as `PE_NO_TILE`. At full readiness on 2×2/1×1 the cut always came too late, so the replay path ran only by chance | first full regression (26 failures, all this cause); the TB now holds `ps_ready` low (via the storage read-port contention input) and releases it one beat at a time, so the cut lands after **exactly** r rows and the duplicate count is deterministic |

## 9. Not covered (stated plainly)

* No formal proof. There is no gate-level simulation, and nothing ran on an FPGA or in silicon.
* No real SRAM macro. Only the reference storage model, with random port contention, is simulated.
* No adapter to the HPC scratchpad or DMA adapter. The three output ports are verified as streams.
* The K-chunk sequencer and operand buffers are testbench models (TC03 is absent).
* `ACC_W` 64 was linted but not simulated; the TB stores values in 64-bit words.
* Several configurations ran on one simulator only (table in §4).
