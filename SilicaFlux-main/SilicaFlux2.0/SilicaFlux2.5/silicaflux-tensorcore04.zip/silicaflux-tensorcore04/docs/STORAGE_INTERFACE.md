# Accumulator storage interface

`tensor_accumulator` keeps the accumulator **values** in an external 1R1W storage reached through the
`st_*` ports. Per-row metadata (valid, chunk count, K count) stays in flops inside the accumulator.
`rtl/tensor_acc_storage.sv` is the reference implementation. A replacement (SRAM macro wrapper, banked
register file) must honour the contract below exactly, because the forwarding network is sized for it.

## Geometry

| item | value |
|---|---|
| depth | `NUM_TILES · ROWS` entries |
| address | `AW = clog2(NUM_TILES·ROWS)` bits; entry = `slot·ROWS + row` |
| entry width | `EW = COLS · (ACC_W + 1)` bits |
| lane j | bits `[j·(ACC_W+1) +: ACC_W]` = value (two's complement), bit `j·(ACC_W+1) + ACC_W` = sticky overflow |

Baseline 4×4, 2 tiles, ACC_W 32: 8 entries × 132 bits = 1 056 bits.

## Ports (accumulator side)

| port | dir | meaning |
|---|---|---|
| `st_en` | out | global pipeline enable. While 0 the storage read pipeline **must hold** its registers |
| `st_rd_req`, `st_rd_addr` | out | read request (only asserted when `st_rd_ready & st_en`) |
| `st_rd_ready` | in | read port available this cycle. 0 = read stall (no op issues) |
| `st_rd_data` | in | entry requested `RD_LAT` enabled cycles earlier. Must be a register output, held while `st_en = 0` |
| `st_wr_req`, `st_wr_addr`, `st_wr_data` | out | write request from the W stage |
| `st_wr_ready` | in | write port available. 0 with `st_wr_req = 1` freezes the accumulator (`st_en = 0`) until it rises |

## Timing contract

1. **Read latency:** a request accepted (`st_rd_req & st_rd_ready & st_en`) in enabled cycle t returns
   data in enabled cycle t + RD_LAT, `RD_LAT ∈ {1, 2, 3}` (a parameter shared with the accumulator).
2. **Write:** a request accepted (`st_wr_req & st_wr_ready`) in cycle w updates the entry at the end of
   cycle w.
3. **Read-before-write:** a read and a write of the same entry in the same cycle return the **old** value.
   A write in cycle w is visible to reads requested in w+1 or later.
4. **No reset requirement:** contents may be arbitrary after reset. The accumulator never consumes an
   entry it has not written for the current tile.
5. **One read and one write per cycle,** independent ports.

Under 1–3 an add can miss at most the writes of the RD_LAT+1 ops issued just before it. The accumulator
forwards exactly those (W stage + RD_LAT history registers; `ARCHITECTURE.md` §4).

A **write-first** storage (same-cycle read returns the new value) is also correct, since forwarding then
merely duplicates what the storage returns. **A storage with a longer read latency than `RD_LAT`, or
with writes delayed beyond the cycle they are accepted, breaks the contract.** For such storage, raise
`RD_LAT` or add a write buffer that is itself forwarded.

## Port contention

`st_rd_ready` / `st_wr_ready` let the storage be shared (for example, a debug or DMA port stealing
cycles, or refresh/BIST). In the reference model they are driven from `st_rd_block` / `st_wr_block`,
which the testbenches randomise up to 40–60 % busy. The resulting stalls are counted (`PF_RD_STALL`,
`PF_WR_STALL`) and checked against the testbench's own observation of the interface.

## Storage operations exposed to the host

Address, read, write and clear are also available as explicit operations on the host port (`hc_*`,
`ARCHITECTURE.md` §6). Valid tracking makes *clear* a metadata operation (one cycle, no storage write).
*Add partial sum* is the `ps_*` stream. *Commit* is performed by the commit engine, and only once every
element of the tile is complete.

## Mapping to an SRAM macro

* RD_LAT = 1: a simple-dual-port SRAM with registered output and a clock-enable (or output latch hold)
  driven by `st_en`.
* RD_LAT = 2: the same plus one output register stage, also enabled by `st_en`.
* Width: `EW` bits. Word-oriented macros can be stacked side by side; all lanes are written together
  (no partial-lane write is ever issued).
* Depth grows with `NUM_TILES`. A double-buffered tile pipeline needs `NUM_TILES ≥ 2` (one slot
  committing while the next accumulates). That is the default, and it is exercised by every multi-slot
  test.
