# Numeric range analysis

## 1. Products

For signed `DATA_W`-bit operands (INT8 baseline) the four corner products are:

| a | b | a·b |
|---|---|---|
| −128 | −128 | **+16 384 = 2^14** (P_MAX) |
| −128 | +127 | −16 256 |
| +127 | −128 | −16 256 (P_MIN) |
| +127 | +127 | +16 129 |

So every product lies in `[P_MIN, P_MAX] = [−16 256, +16 384]`. In general
`P_MAX = 2^(2·DATA_W−2)` and `P_MIN = −(2^(2·DATA_W−2) − 2^(DATA_W−1))`. The positive extreme has the
larger magnitude, so it binds first.

## 2. The K bound

A sum of K products starting from zero lies in `[K·P_MIN, K·P_MAX]`, and so does every prefix of it.
It fits a signed W-bit register for **every** input iff

```
K · 2^(2·DATA_W−2) ≤ 2^(W−1) − 1     and     K · |P_MIN| ≤ 2^(W−1)
⇔   K ≤ 2^(W − 2·DATA_W + 1) − 1      (the positive side binds)
```

| width W | max safe K (INT8, no bias) | worst-case value at that K |
|---|---|---|
| 16 | 1 | 16 384 |
| **32** | **131 071** | 2 147 467 264 (= INT32_MAX − 16 383) |
| 40 | 33 554 431 | 549 755 797 504 |
| 48 | 8 589 934 591 | 140 737 488 338 944 |

This matches the brief: a signed 32-bit accumulator holds at most **131 071** worst-case positive
products (16 384 each) from a zero start without bias. 131 072 of them are exactly 2^31, which overflows.

The bound is established three independent ways (`tests/test_ref_model.py`):

1. integer division from the corner products (`acc_ref.max_exact_k`, no formula),
2. exhaustive enumeration of every reachable K-term sum for small widths (DATA_W 2..3, 5 widths each),
3. equality with the RTL's shift formula `2^(W−2·DATA_W+1)−1` for DATA_W 2..8 and W up to 64.

## 3. Where each width applies

| quantity | width | bound | enforced by |
|---|---|---|---|
| one chunk's partial sum (array PE) | PSUM_W = 32 | `chunk_k ≤ PSUM_KMAX = 131 071` | TC02 `K_WIDTH = 17` **and** `PE_CHUNK_K` check here (the array itself would wrap silently) |
| persistent accumulator | ACC_W | `k_total` (+ bias) per §4 | static check at `cfg` (`STRICT_RANGE = 1`) + exact run-time detection |
| output lane | OUT_W = 32 | value ∈ INT32 | `o_clip` per lane when ACC_W > OUT_W |

**Chunking does not enlarge the INT32 range.** It lets K exceed what the *operand buffer* holds. With
ACC_W = 32 the total K is still limited to 131 071 (no bias), however it is partitioned. The partial sum
of each chunk, and the running sum after each chunk, stay in
`[bias + K_sofar·P_MIN, bias + K_sofar·P_MAX]`, which lies inside the final bound. So no intermediate
value can overflow if the final one cannot.

**Justification for the wider internal accumulator.** Reductions longer than 131 071 (very deep
contractions, long convolutions over large channel counts) need more than 32 bits even though each chunk
fits the array's 32-bit PEs. `ACC_W = 40` gives K ≤ 33 554 431 and `ACC_W = 48` gives K ≤ 8.6 × 10^9.
Only the persistent accumulator widens; the array's PEs stay 32-bit. The output keeps the exact wide
value (`o_wide`, for a quantiser) and an INT32 view with an explicit clip flag (`o_data`, `o_clip`).

## 4. Static range check with bias (`STRICT_RANGE = 1`)

A tile is accepted only if, for every active column n, with `b = bias_en ? bias[n] : 0`:

```
b + k_total · P_MAX ≤ ACC_MAX      and      b + k_total · P_MIN ≥ ACC_MIN
```

`k_total·P_MAX = k_total << 14` and `k_total·|P_MIN| = (k_total << 14) − (k_total << 7)` are shifts and a
subtract. The check is exact (not conservative) and costs 2·COLS comparators at `cfg` time. Otherwise the
tile is rejected with `CR_RANGE`. Boundary cases, all tested:

| ACC_W | k_total | bias | result |
|---|---|---|---|
| 32 | 131 071 | 0 | accepted; worst case 2 147 467 264 |
| 32 | 131 072 | 0 | **rejected** |
| 32 | 131 071 | 16 383 | accepted; worst case **exactly INT32_MAX** |
| 32 | 131 071 | 16 384 | **rejected** |
| 32 | 131 071 | −16 793 472 | accepted; worst negative case **exactly INT32_MIN** |
| 32 | 131 071 | −16 793 473 | **rejected** |
| 32 | 131 071 | 0 except one column 16 384 | **rejected** (one column is enough) |
| 40 | 33 554 431 | 0 | accepted; 549 755 797 504 exact in `o_wide`, `o_clip` set for INT32 |
| 40 | 131 071 | 16 383 / 16 384 | INT32_MAX (no clip) / 2^31 (clip) |

With `STRICT_RANGE = 1` and no host preload, the run-time overflow detector is therefore unreachable
for any data the INT8 array can produce. It stays in place as defence in depth.

## 5. Run-time arithmetic: never silent

Every add is computed exactly: `base (ACC_W) + payload (ACC_W+1, = psum + bias)` in ACC_W+2 bits. The
result fits iff the top three bits agree. If it does not:

* the lane's **sticky overflow bit** is set and stored with the value (it survives later chunks and
  forwarding),
* an **overflow event** is counted (`PF_OVF_ACC`),
* the value follows `OVF_POLICY`:
  * `SATURATE` (default): clamp to ACC_MAX/ACC_MIN in the direction of the exact sum. Later chunks
    continue from the clamped value, so a saturated result is flagged as inexact, not hidden.
  * `WRAP`: keep the low ACC_W bits (modulo 2^ACC_W). This is used **only when explicitly selected** as
    the arithmetic contract, and it is still flagged.

Narrowing to OUT_W follows the same rule (exact range test, `o_clip`, `PF_OVF_OUT`, saturate or the
explicitly selected wrap). Nothing in the datapath wraps silently. The one silent wrap in the system is
inside the TC02 PE, and `PE_CHUNK_K` keeps every launch inside its exact range.

## 6. Partition independence

For in-range data the committed value is `bias + Σ_k A·B` independent of the partition, because:

1. each chunk's partial sum is exact (PSUM_KMAX),
2. each persistent add is exact (§4),
3. each chunk is added exactly once (sequence numbers),
4. bias is added exactly once (with chunk 0),
5. integer addition is associative and commutative.

Verified by:

* the model (300 random partitions in the self-test),
* the unit TB (the same reduction split 4 ways into two chunks in stage 1, and 10 ways for a repeated
  tile, with results asserted identical),
* the integration TB on the real array (the same 257-term reduction under six partitions: 1, 17, 257,
  and random chunk counts; and K = 131 071 split two different ways).

Outside the range (only with `STRICT_RANGE = 0`), SATURATE results can depend on the partition. That is
inherent to saturation, and the overflow flag marks every such element.
