# Architecture: TENSORCORE 04 partial-sum and accumulator engine

Primary source: `rtl/tensor_accumulator.sv`. Integration wrapper: `rtl/tensor_acc_subsystem.sv`.

```
            operand buffers (TC03, absent: modelled by the TB)
                     |  k-slices of chunk c
                     v
   +------------------------------------------+
   |  TC02 tensor_systolic_array (unmodified) |   PE accumulators: chunk-local, zeroed at launch
   +------------------------------------------+
        m_valid/m_ready, m_row, m_data, m_col_mask, m_last
                     |            + sideband {slot, tag, chunk c, chunk_k}  (K-chunk sequencer)
                     v
   +--------------------------- tensor_acc_subsystem -----------------------------+
   |  tensor_accumulator                                                            |
   |   A: arbitrate / check / metadata / issue read --> P1..P_RD_LAT --> X: add --> W: write
   |        ^ cfg (tile open)      ^ host READ/WRITE/CLEAR/ABORT        |          |    |
   |        |                      |                                     forwarding <----+
   |   tensor_acc_storage (1R1W, NUM_TILES*ROWS entries, RD_LAT 1..3)                 |
   |   commit engine --> output FIFO --> tensor_acc_out_router --+--> output SRAM     |
   |                                                             +--> quantiser       |
   |                                                             +--> DMA path        |
   +----------------------------------------------------------------------------------+
```

## 1. Function

For each output tile:

```
acc[m][n] = ( preload[m][n] + bias[n] + P_0[m][n] ) + P_1[m][n] + ... + P_{C-1}[m][n]
P_c[m][n] = sum over k in chunk c of A[m][k] * B[k][n]          (computed by one TC02 launch)
```

K is split into C = `n_chunks` chunks of `chunk_k` K-steps each (any sizes, each 1 .. 131 071). The
committed value equals `bias[n] + sum_{k<K} A[m][k]·B[k][n]` exactly, **regardless of the partition**.
This holds whenever the value is representable, which `STRICT_RANGE = 1` guarantees at tile-open time
(`NUMERIC_RANGE.md`).

## 2. The K-chunk protocol (contract with the sequencer)

1. **Open the tile.** `cfg` handshake on a FREE slot with `{tag, M, N, k_total, n_chunks, bias_en,
   bias[COLS], dest}`. Illegal configurations are consumed and answered with a one-cycle `cfg_reject`
   plus a code. `cfg_ready` is low while the slot is open or committing, so a sequencer may re-open a
   slot immediately and simply waits for its previous tile to drain.
2. **Run chunk c** on the array (`cfg_k = chunk_k`). The PE accumulators restart from zero (TC02
   `S_CLEAR`). **This is required:** `ps_data` must be the chunk-local sum. A PE that carried the previous
   chunk's sum (e.g. TC01 without `clear_acc_i` on the first pair) would make this module add earlier
   chunks again.
3. **Forward the readout.** Wire `m_*` to `ps_*`. Hold `{ps_slot, ps_tag, ps_chunk=c, ps_chunk_k}`
   constant during the launch.
4. **Per row r of the tile, the beat is:**

   | condition (in priority order) | action |
   |---|---|
   | slot out of range / slot not accumulating / tag ≠ tile tag | dropped, `PE_NO_TILE` |
   | `row ≥ M` | dropped, `PE_ROW` |
   | `ps_col_mask` ≠ tile mask, or `ps_last` ≠ (row == M−1) | dropped, `PE_MASK` |
   | `chunk_k == 0` or `chunk_k > PSUM_KMAX` (the array could have wrapped) | dropped, `PE_CHUNK_K` |
   | `c < nch[r]` | **replay: dropped, not an error** (`PSUM_DUP`) |
   | `c > nch[r]` or `c ≥ n_chunks` | dropped, `PE_ORDER` |
   | `kacc[r] + chunk_k > k_total`, or last chunk and `kacc[r] + chunk_k ≠ k_total` | dropped, `PE_K_OVERRUN` |
   | any active lane outside `[chunk_k·P_MIN, chunk_k·P_MAX]` (`PSUM_GUARD`) | dropped, `PE_RANGE` |
   | otherwise | **added exactly once**: `nch[r]++`, `kacc[r] += chunk_k` |

   Dropped beats never touch storage. An error sets `err_pulse/err_code` and a sticky `err_sticky` bit.
   For errors on a matching open tile it also sets the tile's error flag (`o_err`, `cmt_err`). A
   duplicate is not an error: replay is the designed restart mechanism.
5. **Rows are independent.** Each row has its own chunk counter, so rows may arrive in any interleaving,
   and beats of different tiles (slots) may interleave freely. The only rule is that one row's chunks
   arrive in order.
6. **Commit.** When every active row has applied all `n_chunks` chunks, the tile enters COMMIT. By
   check 4.7 it has then also applied exactly `k_total` K-steps. Its rows are read out in order 0..M−1 and
   the slot is freed when the last commit read issues.

### First chunk initialises the accumulator directly

**Yes, and this is the design.** When `nch[r] == 0` and the row has no host preload, the add uses base 0
and **does not read storage**. So there is no clear pass over storage when a tile opens (opening only
clears per-row metadata, in one cycle). Stale storage contents from an earlier tile are also never read:
valid tracking (`vld[r]`) guarantees an entry is consumed only after it has been written for the current
tile. If a host preload exists (`HC_WRITE` before chunk 0), chunk 0 reads it and adds onto it
(C = C_prev + bias + A·B).

### Bias: applied once, with the first K chunk

`bias[n]` is folded into the **initialising add of each row** (the add that applies chunk 0). That add
happens exactly once per row (the duplicate filter guarantees it), so bias is applied **exactly once per
output element, before/with the first K chunk, never per chunk**. Applying it with the first chunk rather
than after the final chunk has two advantages. The static range check covers it, and the commit path
stays a pure read. Integer addition is associative, so both orders give the same exact value. If a row
is restarted with `HC_CLEAR`, its next chunk-0 add applies the bias again, once, to the fresh row.

## 3. Storage organisation

| item | where | width | meaning |
|---|---|---|---|
| entry e = slot·ROWS + row | `tensor_acc_storage` (1R1W memory) | COLS × (ACC_W + 1) | per lane `{ovf, value}` |
| `vld[e]` | flops | 1 | entry holds a value written for the current tile |
| `nch[e]` | flops | CHUNK_W | chunks applied to this row |
| `kacc[e]` | flops | KTOT_W | K-steps applied to this row |
| slot state | flops | 2 | FREE / ACCUM / COMMIT |
| slot config | flops | tag, M, col mask, k_total, n_chunks, bias_en, bias[COLS], dest | latched at cfg |
| `cdone[slot]` | flops | CHUNK_W | chunks complete on **all** active rows (min of `nch`) |
| `err[slot]` | flops | 1 | a malformed beat was rejected on this open tile |

The design is parameterised for larger tile storage: `NUM_TILES ≥ 1` slots, `ROWS × COLS` up to 16×16
verified (any size elaborates), `ACC_W` 32/40/48 verified (≤ 64 by the TB). Storage depth is
`NUM_TILES·ROWS`. The overflow bit is stored *with* the value, so it travels through the same forwarding
path as the data.

## 4. Pipeline and hazards

```
 cycle   t           t+1 .. t+RD_LAT          t+RD_LAT          t+RD_LAT+1
 stage   A           P1 .. P_RD_LAT            X (= P_RD_LAT)    W
         arbitrate   storage read latency      base select       storage write
         check                                  exact add         FIFO push (commit /
         metadata                               overflow policy   host response)
         issue read                                               history shift
```

* **One op per cycle**, fixed priority **commit read > host op > partial sum**. Every op needs the
  storage read-port slot (`st_rd_ready`), even ops that do not read. This keeps `ps_ready` independent
  of the beat's payload.
* **Metadata is updated at A.** Every younger op sees the effect of every older op on `vld`, `nch`,
  `kacc` and the slot state immediately. Duplicate detection, ordering and completion are therefore
  exact even for back-to-back beats to the same row.

### Read-after-write (forwarding)

Storage is read-before-write: a write in cycle w is visible to reads issued at w+1 or later. An op issued
at cycle t reads storage at t. An older op issued at t−d writes at t−d+RD_LAT+1. So the younger op's
read misses the older write exactly when **d ≤ RD_LAT + 1**. At the younger op's X stage (t+RD_LAT) that
older op is:

* d = 1 → in **W** (writing this cycle)
* d = 2 .. RD_LAT+1 → in history register **h[d−2]** (written 0 .. RD_LAT−1 cycles ago)

The X stage compares the entry address with W and h[0..RD_LAT−1] and takes the **youngest** match, or the
storage data if there is none. That is exactly the set of writes the read can have missed, so the
pipeline never needs a RAW stall. Back-to-back adds to one entry (M = 1 tiles with many chunks) run at
one beat per cycle. Mutants that remove either forwarding path (m04, m05), or pick the oldest match
(m06), are killed.

### Multiple partial sums targeting the same element

Every add targets one row entry, and the sequence number serialises them per row. In-flight adds to the
same entry are chained through the forwarding network above. The commit read for a row is issued after
the add that completed it (the COMMIT state is entered at that add's A stage), so it is ordered behind
it and receives the final value through forwarding.

### Backpressure

| source | mechanism |
|---|---|
| output port(s) not ready | the commit engine issues a read only with a free **output-FIFO credit** (`OFIFO_DEPTH`); the pipeline never stalls on the output. Psums keep flowing while the output is blocked |
| host response not taken | host ops issue only with a free response-FIFO credit (`HFIFO_DEPTH`) |
| storage **read** port busy | no op issues this cycle (bubble at A); counted as a **read stall** |
| storage **write** port busy | the whole pipeline **freezes** (`st_en = 0`): A does not issue, P/X/W/history and the storage read registers hold; counted as a **write stall**. Forwarding distances are counted in enabled cycles, so the analysis above holds unchanged |
| array readout | `ps_ready` is the array's `m_ready`; TC02's accumulators are static during readout, so pacing it is safe |

### Pipeline latency

A partial sum accepted at cycle t is in storage at the end of t+RD_LAT+1. If it completes a tile, the
first commit read can issue at t+1 and the first result beat appears on the output at t+RD_LAT+3. A tile
of M rows needs M commit-read slots. These take priority over partial sums, and a tile's beats are
contiguous on every port.

### Tile switching

Slots are independent. Beats of different tiles may interleave in any order. A tile can commit while
others accumulate. The commit engine finishes one tile before it starts the next, so each tile's rows stay
contiguous. A freed slot can be re-opened at once: rows are re-initialised by `cfg`, and stale beats of
the previous tile are rejected by the tag check.

### Reset during accumulation

`rst_n` is synchronous. It returns every slot to FREE, clears row metadata, pipeline, FIFOs, credits,
error flags and counters. Storage is not cleared, and it does not need to be: no row is valid. Ops that
were in flight are discarded. A tile that was open must be re-run from chunk 0; one that was committing
may have delivered some rows. The testbenches reset in the middle of accumulation, in the middle of
back-to-back RAW chains, and during commit. They then re-run the tile and require the exact result.
Resetting **only the array** in the middle of a readout and re-running the chunk is the replay case of
§2.

## 5. Commit and output

* **Completion criterion:** `cdone[slot] == n_chunks`, i.e. `nch[r] == n_chunks` for every active row.
  By the K check this implies `kacc[r] == k_total`, which is re-checked at commit (`o_err`). No output
  element can be committed before all its K contributions are included. Mutants that commit one chunk
  early (m09) or ignore lagging rows (m10) are killed.
* **Output beat** (one row): `o_tag, o_slot, o_row, o_last, o_col_mask, o_err` plus per lane:
  * `o_wide` = exact ACC_W value,
  * `o_data` = OUT_W value (INT32 baseline). If ACC_W > OUT_W and the value does not fit, `o_clip` is
    set and `o_data` saturates (or wraps under `OVF_POLICY = WRAP`),
  * `o_ovf` = the accumulation itself overflowed ACC_W (only possible with `STRICT_RANGE = 0` or a host
    preload).
* **Destinations** (`cfg_dest`, per tile, any subset): output SRAM, quantisation engine, DMA path. The
  router is an eager fork: each port takes the beat independently, and the beat retires when all selected
  ports have it. Raw INT32 to SRAM/DMA never passes through a quantiser. The quantiser should consume
  `o_wide` (exact) when ACC_W > 32.
* `cmt_done` pulses once per tile after its last row has been delivered to every selected port. It
  carries the OR of ovf/clip/err over the tile.

## 6. Host / sequencer storage operations

| op | legal when | effect | response |
|---|---|---|---|
| `HC_READ` | slot ACCUM or COMMIT, row < M | none | value (0 if row not valid), ovf, pre-op `vld/nch/kacc` |
| `HC_WRITE` | slot ACCUM, row < M, `nch == 0` | entry := wdata (masked lanes 0), `vld = 1`; the next chunk-0 add accumulates onto it | written value |
| `HC_CLEAR` | slot ACCUM, row < M | row metadata cleared (`vld = nch = kacc = 0`), `cdone = 0`: the row restarts its reduction from chunk 0 | pre-op metadata |
| `HC_ABORT` | slot ACCUM | slot FREE; in-flight ops of that slot are harmless (rows invalid) | zeros |

Illegal ops change nothing and answer `HS_ERR_SLOT / HS_ERR_ROW / HS_ERR_ORDER` with zero data.
Responses are in order. Host ops go through the same pipeline as adds, so a READ sees every older add
(forwarding) and a WRITE is ordered before every younger add.

## 7. Parameters

| parameter | default | verified | meaning |
|---|---|---|---|
| `ROWS`, `COLS` | 4, 4 | 1×1, 2×2, 3×5, 4×4, 8×8, 16×16 | output tile = array size |
| `DATA_W` | 8 | 8 | operand width of the producer (range analysis only) |
| `PSUM_W` | 32 | 32 | partial-sum lane width (= TC02 `ACC_WIDTH`) |
| `ACC_W` | 32 | 32, 40, 48 | persistent accumulator width (≥ PSUM_W) |
| `OUT_W` | 32 | 32, 40 | output lane width (≤ ACC_W) |
| `BIAS_W` | 32 | 32 | bias width (≤ ACC_W) |
| `NUM_TILES` | 2 | 1, 2, 3, 4 | tile slots in storage |
| `TAG_W`, `CHUNK_W`, `KC_W`, `KTOT_W` | 16, 16, 17, 40 | defaults | tag, chunk index/count, chunk K (= TC02 `K_WIDTH`), total K |
| `RD_LAT` | 1 | 1, 2, 3 | storage read latency |
| `OVF_POLICY` | 0 (SATURATE) | 0, 1 | 1 = explicitly selected wraparound |
| `STRICT_RANGE` | 1 | 1, 0 | reject tiles whose K (+bias) could overflow ACC_W |
| `PSUM_GUARD` | 1 | 1, 0 | reject psums no `chunk_k` INT8 products can produce |
| `OFIFO_DEPTH`, `HFIFO_DEPTH` | 4, 4 | 1, 4 | output / host-response FIFO (credits) |
| `PERF_EN`, `PERF_W` | 1, 40 | 40, 6 (saturation) | counters |

## 8. Limits (stated plainly)

* One commit read per cycle, so draining a tile costs M cycles of the shared op slot. Partial sums wait
  during that time. It is not overlapped.
* The storage reference model is a flop/memory array. Mapping it to a real SRAM macro is a wrapper that
  must honour `STORAGE_INTERFACE.md`. No macro is included.
* No adapter to the HPC scratchpad (`hpc_scratchpad`) or DMA adapter is included. The output ports are
  valid/ready beat streams; `AUDIT.md` §6 gives the mapping.
* The K-chunk sequencer and the operand buffers (TC03) are not part of this RTL. The integration
  testbench implements the sequencer behaviour.
* Verification is simulation only (Icarus + Verilator). There is no formal proof, no gate-level
  simulation and no hardware. Synthesis is Yosys mapping without place and route: no Fmax claim.
