#!/usr/bin/env python3
"""
TENSORCORE 04 -- unit-test vector generator for tb/tb_acc.sv.

Every expected value is produced by the independent Python-integer model
(model/acc_ref.py).  For every tile whose data is in range, the model's
committed result is additionally asserted equal to the direct GEMM
reference  bias + A @ B  BEFORE the vector is written -- so a vector can
never encode a partition-dependent "expected" value.

  gen_unit.py --suite stage1 --rows 4 --cols 4 --tiles 2 --acc 32 --out vectors/x.hex
"""
import argparse
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
import acc_ref as R  # noqa: E402

T_CFG, T_PS, T_HC, T_BAR, T_RST, T_EXP, T_END = 1, 2, 3, 4, 5, 6, 15
MAGIC = 0x7C040001


def u32(v):
    return v & 0xFFFFFFFF


def w64(v):
    v &= (1 << 64) - 1
    return [v & 0xFFFFFFFF, v >> 32]


class Gen:
    def __init__(self, p, rd_lat, seed):
        self.p = p
        self.rd_lat = rd_lat
        self.rng = random.Random(seed)
        self.m = R.AccModel(p)
        self.recs = []
        self.seg = 0
        self.seg_exp = []
        self.seg_ps, self.seg_hc = set(), set()
        self.next_tag = 1
        self.exact = {}          # tag -> expected exact matrix (rows x n) from gemm_ref
        self.committed = {}      # tag -> beats from the model
        self.stats = dict(tiles=0, chunks=0, beats=0, cfg=0, host=0, resets=0)

    # ---------------------------------------------------------------- records
    def _rec(self, typ, payload):
        self.recs.append([(typ << 24) | len(payload)] + [u32(x) for x in payload])

    def tag(self):
        t = self.next_tag
        self.next_tag += 1
        assert t < (1 << self.p.tag_w), "tag space exhausted"
        return t

    def cfg(self, slot, tag, m, n, ktot, nch, bias_en=0, bias=None, dest=1):
        bias = list(bias) if bias is not None else [0] * self.p.cols
        bias += [0] * (self.p.cols - len(bias))
        assert all(R.smin(self.p.bias_w) <= b <= R.smax(self.p.bias_w) for b in bias), "bias must fit BIAS_W"
        code = self.m.cfg(slot, tag, m, n, ktot, nch, bias_en, bias, dest)
        self.seg_ps.add(slot)
        self._rec(T_CFG, [slot, tag, m, n] + w64(ktot) + [nch, bias_en, dest, code] + bias)
        self.stats["cfg"] += 1
        return code

    def ps(self, slot, tag, chunk, kc, row, last, cmask, data, expect=None):
        # lanes outside the tile carry GARBAGE: the accumulator must ignore them
        data = list(data) + [self.rng.randint(-(1 << 31), (1 << 31) - 1)
                             for _ in range(self.p.cols - len(data))]
        n0 = len(self.m.out)
        kind, code = self.m.ps(slot, tag, chunk, kc, row, last, cmask, data)
        if expect is not None:
            assert kind == expect, f"generator expected {expect}, model says {kind}/{code}"
        self.seg_ps.add(slot)
        k = {"apply": 0, "dup": 1, "err": 2}[kind]
        words = [slot, tag, chunk, kc, row, int(bool(last))] + w64(cmask) + [k, code]
        for v in data:
            words += w64(v)
        self._rec(T_PS, words)
        self.stats["beats"] += 1
        for b in self.m.out[n0:]:
            self.seg_exp.append(b)
            self.committed.setdefault(b["tag"], []).append(b)
        return kind, code

    def hc(self, op, slot, row, wdata=None, shared=False):
        """shared=True: a host op that may run concurrently with psum traffic on the SAME
        slot.  Only legal for ops whose outcome cannot depend on that traffic: error ops
        that change no state (asserted below)."""
        wdata = list(wdata) if wdata is not None else [0] * self.p.cols
        wdata += [0] * (self.p.cols - len(wdata))
        r = self.m.hc(op, slot, row, wdata)
        if shared:
            assert r["status"] in (R.HS_ERR_ORDER, R.HS_ERR_ROW), "shared host ops must be stateless errors"
        else:
            self.seg_hc.add(slot)
        words = [op, slot, row]
        for v in wdata:
            words += w64(v)
        words += [r["status"], r["vld"], r["nch"]] + w64(r["kacc"])
        words += w64(sum(b << j for j, b in enumerate(r["ovf"])))
        for v in r["data"]:
            words += w64(v)
        self._rec(T_HC, words)
        self.stats["host"] += 1
        return r

    def reset(self, max_delay=6, hold=3):
        assert not self.seg_hc, "no host traffic in a segment that resets"
        self.m.reset()
        self._rec(T_RST, [max_delay, hold])
        self.stats["resets"] += 1
        self.barrier(check=False, optional=True)

    def barrier(self, check=True, optional=False):
        inter = self.seg_ps & self.seg_hc & set(range(self.p.num_tiles))
        assert not inter, f"segment {self.seg}: host and psum streams share slots {inter}"
        self.m.barrier()
        for b in self.seg_exp:
            words = [b["tag"], b["slot"], b["row"], b["last"], b["dest"], b["err"], int(optional)]
            words += w64(b["cmask"]) + w64(sum(v << j for j, v in enumerate(b["ovf"])))
            words += w64(sum(v << j for j, v in enumerate(b["clip"])))
            for v in b["wide"]:
                words += w64(v)
            for v in b["data"]:
                words += w64(v)
            self._rec(T_EXP, words)
        d = self.m.take_perf()
        words = [self.seg, int(check), self.m.err_sticky]
        for name in sorted(R.PF, key=lambda k: R.PF[k]):
            words += w64(d[name] if name in R.DETERMINISTIC else 0)
        self._rec(T_BAR, words)
        self.seg += 1
        self.seg_exp = []
        self.seg_ps, self.seg_hc = set(), set()

    def write(self, path):
        if self.seg_exp or self.seg_ps or self.seg_hc:
            self.barrier()
        self._rec(T_END, [])
        p = self.p
        hdr = [MAGIC, 0, p.rows, p.cols, p.num_tiles, p.acc_w, p.out_w, self.rd_lat, p.ovf_policy,
               p.strict, p.guard, len(self.recs), 0, 0, 0, 0]
        words = hdr + [w for r in self.recs for w in r]
        words[1] = len(words)
        assert len(words) < (1 << 22), "vector file too large for the TB memory"
        # final gate: every exact tile committed the gemm reference
        for tag, ref in self.exact.items():
            got = [b["wide"][:len(ref[0])] for b in sorted(self.committed.get(tag, []), key=lambda b: b["row"])]
            assert got == ref, f"tag {tag}: model {got} != gemm reference {ref}"
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w") as f:
            f.write("\n".join(f"{w:08x}" for w in words) + "\n")
        return len(words)

    # ---------------------------------------------------------------- tile helpers
    def mat(self, M, N, K, mode="rand"):
        r = self.rng
        if mode == "max":
            A = [[-128] * K for _ in range(M)]
            B = [[-128] * N for _ in range(K)]
        elif mode == "neg":
            A = [[-128] * K for _ in range(M)]
            B = [[127] * N for _ in range(K)]
        elif mode == "sym":
            A = [[r.randint(-127, 127) for _ in range(K)] for _ in range(M)]
            B = [[r.randint(-127, 127) for _ in range(N)] for _ in range(K)]
        elif mode == "edge":
            A = [[r.choice([-128, -127, -1, 0, 1, 126, 127]) for _ in range(K)] for _ in range(M)]
            B = [[r.choice([-128, -127, -1, 0, 1, 126, 127]) for _ in range(N)] for _ in range(K)]
        else:
            A = [[r.randint(-128, 127) for _ in range(K)] for _ in range(M)]
            B = [[r.randint(-128, 127) for _ in range(N)] for _ in range(K)]
        return A, B

    def bounds_uniform(self, K, kc):
        b = list(range(0, K, kc)) + [K]
        return b

    def bounds_random(self, K, nmax=8):
        if K == 1:
            return [0, 1]
        cuts = sorted(self.rng.sample(range(1, K), self.rng.randint(0, min(K - 1, nmax - 1))))
        return [0] + cuts + [K]

    def tile_beats(self, slot, tag, M, N, A, B, bounds):
        """Per-chunk list of beats (TC02 order: chunk by chunk, row 0..M-1)."""
        out = []
        for c in range(len(bounds) - 1):
            P = R.chunk_psums(A, B, bounds[c], bounds[c + 1])
            kc = bounds[c + 1] - bounds[c]
            out.append([(slot, tag, c, kc, m, int(m == M - 1), (1 << N) - 1, P[m]) for m in range(M)])
        return out

    def open_tile(self, slot, M, N, K, nch, bias_en=0, bias=None, dest=1, tag=None):
        tag = self.tag() if tag is None else tag
        code = self.cfg(slot, tag, M, N, K, nch, bias_en, bias, dest)
        return tag, code

    def run_tile(self, slot, M, N, A, B, bounds, bias_en=0, bias=None, dest=1, order="seq",
                 exact=True):
        K = bounds[-1]
        tag, code = self.open_tile(slot, M, N, K, len(bounds) - 1, bias_en, bias, dest)
        assert code == R.CR_OK, f"cfg rejected ({code})"
        chunks = self.tile_beats(slot, tag, M, N, A, B, bounds)
        beats = [b for ch in chunks for b in ch]
        if order == "rowshuffle":
            # any order that keeps each row's chunks in sequence
            per_row = [[b for b in beats if b[4] == m] for m in range(M)]
            beats = self.merge(per_row)
        for b in beats:
            self.ps(*b, expect="apply")
        if exact:
            bb = (bias if bias_en else [0] * N)[:N]
            self.exact[tag] = R.gemm_ref(A, B, bb)
        self.stats["tiles"] += 1
        self.stats["chunks"] += len(bounds) - 1
        return tag

    def merge(self, lists):
        """Random interleave preserving the order inside every list."""
        lists = [list(l) for l in lists if l]
        out = []
        while lists:
            i = self.rng.randrange(len(lists))
            out.append(lists[i].pop(0))
            if not lists[i]:
                lists.pop(i)
        return out

    def rbias(self, lo=-(1 << 24), hi=(1 << 24)):
        return [self.rng.randint(lo, hi) for _ in range(self.p.cols)]


# =============================================================================
# suites
# =============================================================================
def suite_stage1(g):
    """START: accumulation across exactly two K chunks."""
    p = g.p
    M, N = p.rows, p.cols
    A, B = g.mat(M, N, 8)
    # the same 8-term reduction, split four different ways into two chunks
    for cut in (4, 1, 7, 6):
        g.run_tile(0, M, N, A, B, [0, cut, 8])
        g.barrier()
    # two chunks + bias (bias must appear once, not twice)
    g.run_tile(0, M, N, A, B, [0, 3, 8], bias_en=1, bias=g.rbias())
    g.barrier()
    # M = 1: chunk 1 hits the same entry back-to-back with chunk 0 (RAW hazard)
    A1, B1 = g.mat(1, N, 2)
    g.run_tile(0, 1, N, A1, B1, [0, 1, 2])
    g.barrier()
    # replay of chunk 0 interleaved with chunk 1 (restart): replays are dropped
    tag, _ = g.open_tile(0, M, N, 8, 2)
    ch = g.tile_beats(0, tag, M, N, A, B, [0, 5, 8])
    for b in ch[0]:
        g.ps(*b, expect="apply")
    for b in ch[0]:
        g.ps(*b, expect="dup")                         # replay before chunk 1
    if M > 1:
        g.ps(*ch[1][0], expect="apply")
        for b in ch[0]:
            g.ps(*b, expect="dup")                     # replay interleaved with chunk 1
        for b in ch[1][1:]:
            g.ps(*b, expect="apply")
    else:
        g.ps(*ch[1][0], expect="apply")
    g.exact[tag] = R.gemm_ref(A, B)
    g.barrier()
    # partial tile, two chunks, extreme operands
    if M > 1 or N > 1:
        m2, n2 = max(1, M - 1), max(1, N - 1)
        A2, B2 = g.mat(m2, n2, 9, "edge")
        g.run_tile(0, m2, n2, A2, B2, [0, 4, 9], bias_en=1, bias=g.rbias())
        g.barrier()
    # two tiles in two slots, chunks interleaved
    if p.num_tiles >= 2:
        Aa, Ba = g.mat(M, N, 6)
        Ab, Bb = g.mat(M, N, 10)
        bias_b = g.rbias()
        ta, _ = g.open_tile(0, M, N, 6, 2)
        tb, _ = g.open_tile(1, M, N, 10, 2, 1, bias_b, dest=0b101)
        la = [b for ch in g.tile_beats(0, ta, M, N, Aa, Ba, [0, 2, 6]) for b in ch]
        lb = [b for ch in g.tile_beats(1, tb, M, N, Ab, Bb, [0, 7, 10]) for b in ch]
        for b in g.merge([la, lb]):
            g.ps(*b, expect="apply")
        g.exact[ta] = R.gemm_ref(Aa, Ba)
        g.exact[tb] = R.gemm_ref(Ab, Bb, bias_b[:N])
        g.barrier()
    # K = 2 as [1, 1]
    A3, B3 = g.mat(M, N, 2, "max")
    g.run_tile(0, M, N, A3, B3, [0, 1, 2])
    g.barrier()


def suite_basic(g):
    p = g.p
    M, N = p.rows, p.cols
    KC = 16
    # K shorter than one chunk / exactly one chunk / crossing boundaries
    for K, mode in ((1, "rand"), (3, "edge"), (KC - 1, "rand"), (KC, "rand"), (KC, "max"),
                    (KC + 1, "rand"), (2 * KC - 1, "edge"), (3 * KC + 2, "rand")):
        A, B = g.mat(M, N, K, mode)
        g.run_tile(0, M, N, A, B, g.bounds_uniform(K, KC))
        g.barrier()
    # many chunks
    A, B = g.mat(M, N, 256)
    g.run_tile(0, M, N, A, B, g.bounds_uniform(256, 1))             # 256 chunks of 1
    g.barrier()
    A, B = g.mat(1, N, 1000)
    g.run_tile(0, 1, N, A, B, g.bounds_uniform(1000, 7))            # 143 chunks, M=1 RAW chain
    g.barrier()
    A, B = g.mat(M, N, 600, "edge")
    g.run_tile(0, M, N, A, B, g.bounds_random(600, 40), order="rowshuffle")
    g.barrier()
    # negative accumulation
    A, B = g.mat(M, N, 500, "neg")
    g.run_tile(0, M, N, A, B, g.bounds_uniform(500, 37))
    g.barrier()
    A, B = g.mat(M, N, 300)
    A = [[-abs(x) for x in row] for row in A]
    B = [[abs(x) if abs(x) < 128 else 127 for x in row] for row in B]
    g.run_tile(0, M, N, A, B, g.bounds_random(300, 12))
    g.barrier()
    # cancellation: chunk 2i+1 is the exact negation of chunk 2i
    for nb in (2, 8):
        K = 2 * nb * 5
        A, B = g.mat(M, N, K, "sym")
        for c in range(nb):
            for m in range(M):
                for k in range(5):
                    A[m][2 * c * 5 + 5 + k] = -A[m][2 * c * 5 + k]
            for k in range(5):
                B[2 * c * 5 + 5 + k] = list(B[2 * c * 5 + k])
        bias = g.rbias()
        tag = g.run_tile(0, M, N, A, B, g.bounds_uniform(K, 5), bias_en=1, bias=bias)
        assert all(g.exact[tag][m] == bias[:N] for m in range(M)), "cancellation must leave the bias"
        g.barrier()
    # bias: once per element, never per chunk
    for nchunk in (1, 2, 9, 31):
        K = nchunk * 3
        A, B = g.mat(M, N, K)
        g.run_tile(0, M, N, A, B, g.bounds_uniform(K, 3), bias_en=1,
                   bias=g.rbias(-(1 << 30), 1 << 30))
        g.barrier()
    A, B = g.mat(M, N, 4)
    g.run_tile(0, M, N, A, B, [0, 2, 4], bias_en=1, bias=[0] * p.cols)   # zero bias
    g.barrier()
    # partial tiles
    for _ in range(6):
        m, n = g.rng.randint(1, M), g.rng.randint(1, N)
        K = g.rng.randint(1, 70)
        A, B = g.mat(m, n, K)
        g.run_tile(0, m, n, A, B, g.bounds_random(K, 6), bias_en=g.rng.randint(0, 1), bias=g.rbias())
        g.barrier()
    # repeated output tile: same data, same slot, 10 different partitions -> identical results
    A, B = g.mat(M, N, 90)
    ref = None
    for i in range(10):
        bounds = [0, 90] if i == 0 else g.bounds_random(90, 10 + i)
        tag = g.run_tile(0, M, N, A, B, bounds, dest=[1, 2, 4, 3, 5, 6, 7][i % 7])
        ref = g.exact[tag] if ref is None else ref
        assert g.exact[tag] == ref
        if i % 3 == 2:
            g.barrier()       # otherwise: slot reused without a barrier (cfg waits for commit)
    g.barrier()
    # tile switching: every slot open at once, beats from all tiles interleaved
    for rep in range(3):
        lists, tiles = [], []
        for s in range(p.num_tiles):
            m, n = g.rng.randint(1, M), g.rng.randint(1, N)
            K = g.rng.randint(1, 60)
            A, B = g.mat(m, n, K)
            bounds = g.bounds_random(K, 8)
            be = g.rng.randint(0, 1)
            bias = g.rbias()
            tag, code = g.open_tile(s, m, n, K, len(bounds) - 1, be, bias, dest=g.rng.randint(1, 7))
            g.exact[tag] = R.gemm_ref(A, B, bias[:n] if be else None)
            ch = g.tile_beats(s, tag, m, n, A, B, bounds)
            if rep == 2:
                per_row = [[b for c in ch for b in c if b[4] == r] for r in range(m)]
                lists += per_row
            else:
                lists.append([b for c in ch for b in c])
        for b in g.merge(lists):
            g.ps(*b, expect="apply")
        g.barrier()


def suite_errors(g):
    p = g.p
    M, N = p.rows, p.cols
    full = (1 << N) - 1
    A, B = g.mat(M, N, 12)
    bounds = [0, 4, 9, 12]
    tag, _ = g.open_tile(0, M, N, 12, 3)
    ch = g.tile_beats(0, tag, M, N, A, B, bounds)
    s, t, c, kc, r, last, cm, d = ch[0][0]
    # NO_TILE: wrong tag, FREE slot, out-of-range slot
    g.ps(0, tag + 1000, 0, kc, 0, last, cm, d, expect="err")
    if p.num_tiles > 1:
        g.ps(1, tag, 0, kc, 0, last, cm, d, expect="err")
    if p.num_tiles < (1 << max(1, (p.num_tiles - 1).bit_length())):
        g.ps(p.num_tiles, tag, 0, kc, 0, last, cm, d, expect="err")
    # CHUNK_K = 0
    g.ps(0, tag, 0, 0, 0, last, cm, d, expect="err")
    # ORDER: skip ahead / beyond n_chunks
    g.ps(*ch[1][0], expect="err")
    g.ps(0, tag, 3, 1, 0, last, cm, d, expect="err")
    # K_OVERRUN: claims more K than the tile has
    g.ps(0, tag, 0, 13, 0, last, cm, d, expect="err")
    # MASK: wrong col mask / wrong last flag
    if N > 1:
        g.ps(0, tag, 0, kc, 0, last, full >> 1, d, expect="err")
    g.ps(0, tag, 0, kc, 0, 1 - last if M > 1 else 0, cm, d, expect="err")
    # RANGE: impossible for kc INT8 products (applied when the guard is off)
    bad = list(d)
    bad[0] = kc * 16384 + 1
    kind, _ = g.ps(0, tag, 0, kc, 0, last, cm, bad)
    if p.guard:
        assert kind == "err"
    else:
        # guard off: the beat applies; finish this row from chunk 1 and mark the tile inexact
        pass
    # now the correct chunks (rows of chunk 0 again, dups where already applied)
    for b in ch[0]:
        g.ps(*b)
    for b in ch[1]:
        g.ps(*b, expect="apply")
    # replays of chunk 0 and 1 (restart) are no-ops
    for b in ch[0] + ch[1][:1]:
        g.ps(*b, expect="dup")
    # final chunk with wrong K
    s2, t2, c2, kc2, r2, l2, cm2, d2 = ch[2][0]
    g.ps(s2, t2, c2, kc2 - 1, r2, l2, cm2, d2, expect="err")
    for b in ch[2]:
        g.ps(*b, expect="apply")
    if p.guard:
        g.exact[tag] = R.gemm_ref(A, B)
    g.barrier()
    # ROW error on a partial tile
    if M > 1:
        A1, B1 = g.mat(M - 1, N, 3)
        t1, _ = g.open_tile(0, M - 1, N, 3, 1)
        g.ps(0, t1, 0, 3, M - 1, 1, full, [0] * N, expect="err")
        for b in g.tile_beats(0, t1, M - 1, N, A1, B1, [0, 3])[0]:
            g.ps(*b, expect="apply")
        g.exact[t1] = R.gemm_ref(A1, B1)
        g.barrier()
    # cfg rejects
    mw = (p.rows).bit_length()
    nw = (p.cols).bit_length()
    g.cfg(0, g.tag(), 0, N, 4, 1)                       # M = 0
    if (1 << mw) - 1 > p.rows:
        g.cfg(0, g.tag(), p.rows + 1, N, 4, 1)          # M > ROWS
    g.cfg(0, g.tag(), M, 0, 4, 1)                       # N = 0
    if (1 << nw) - 1 > p.cols:
        g.cfg(0, g.tag(), M, p.cols + 1, 4, 1)          # N > COLS
    g.cfg(0, g.tag(), M, N, 4, 0)                       # 0 chunks
    g.cfg(0, g.tag(), M, N, 4, 5)                       # more chunks than K
    g.cfg(0, g.tag(), M, N, 4, 1, dest=0)               # no destination
    if p.num_tiles < (1 << max(1, (p.num_tiles - 1).bit_length())):
        g.cfg(p.num_tiles, g.tag(), M, N, 4, 1)         # slot out of range
    g.barrier()
    # random replay storm on a long tile: every chunk is sent 1..3 times, mixed with later chunks
    A, B = g.mat(M, N, 120)
    bounds = g.bounds_random(120, 15)
    bias_s = g.rbias()
    tag, _ = g.open_tile(0, M, N, 120, len(bounds) - 1, 1, bias_s)
    ch = g.tile_beats(0, tag, M, N, A, B, bounds)
    seq = []
    for ci, c in enumerate(ch):
        seq += c
        if ci == len(ch) - 1:
            break                      # nothing after the final chunk: the tile is committing
        for _ in range(g.rng.randint(0, 2)):
            back = g.rng.randint(0, ci)
            seq += g.rng.sample(ch[back], g.rng.randint(1, len(ch[back])))
    for b in seq:
        g.ps(*b)
    g.exact[tag] = R.gemm_ref(A, B, bias_s[:N])
    g.barrier()


def suite_host(g):
    p = g.p
    M, N = p.rows, p.cols
    full = (1 << N) - 1
    A, B = g.mat(M, N, 20)
    bounds = [0, 8, 14, 20]
    bias = g.rbias()
    # READ mid-accumulation
    tag, _ = g.open_tile(0, M, N, 20, 3, 1, bias)
    ch = g.tile_beats(0, tag, M, N, A, B, bounds)
    g.barrier()
    g.hc(R.HC_READ, 0, 0)                              # not initialised: reads 0, vld 0
    g.barrier()
    for b in ch[0]:
        g.ps(*b, expect="apply")
    g.barrier()
    for r in range(M):
        g.hc(R.HC_READ, 0, r)                          # bias + chunk 0
    g.hc(R.HC_WRITE, 0, 0, [7] * N)                    # too late: chunk already applied
    g.barrier()
    # CLEAR row 0 and re-run its chunks 0..1; other rows continue
    g.hc(R.HC_CLEAR, 0, 0)
    g.barrier()
    g.ps(*ch[0][0], expect="apply")                    # row 0 restarts (bias applied again, once)
    for b in ch[1]:
        g.ps(*b, expect="apply")
    for b in ch[2]:
        g.ps(*b, expect="apply")
    g.exact[tag] = R.gemm_ref(A, B, bias[:N])
    g.barrier()
    # WRITE preload: C = C_prev + bias + A @ B
    cprev = [[g.rng.randint(-(1 << 28), 1 << 28) for _ in range(N)] for _ in range(M)]
    tag, _ = g.open_tile(0, M, N, 20, 3, 1, bias)
    g.barrier()
    for r in range(M):
        g.hc(R.HC_WRITE, 0, r, cprev[r])
    g.barrier()
    for b in [b for c in g.tile_beats(0, tag, M, N, A, B, bounds) for b in c]:
        g.ps(*b, expect="apply")
    ref = R.gemm_ref(A, B, bias[:N])
    g.exact[tag] = [[ref[m][n] + cprev[m][n] for n in range(N)] for m in range(M)]
    g.barrier()
    # ABORT mid-tile, re-open, full run
    tag, _ = g.open_tile(0, M, N, 20, 3)
    for b in g.tile_beats(0, tag, M, N, A, B, bounds)[0]:
        g.ps(*b, expect="apply")
    g.barrier()
    g.hc(R.HC_ABORT, 0, 0)
    g.barrier()
    g.ps(*g.tile_beats(0, tag, M, N, A, B, bounds)[1][0], expect="err")   # tile gone
    g.run_tile(0, M, N, A, B, bounds)
    g.barrier()
    # host errors
    g.hc(R.HC_READ, 0, 0)                              # FREE slot
    g.hc(R.HC_ABORT, 0, 0)
    g.hc(R.HC_CLEAR, 0, 0)
    if p.num_tiles < (1 << max(1, (p.num_tiles - 1).bit_length())):
        g.hc(R.HC_READ, p.num_tiles, 0)
    g.barrier()
    if M > 1:
        tag, _ = g.open_tile(0, M - 1, N, 4, 1)
        g.barrier()
        g.hc(R.HC_READ, 0, M - 1)                      # row >= M
        g.hc(R.HC_WRITE, 0, M - 1, [1] * N)
        g.hc(R.HC_ABORT, 0, 0)
        g.barrier()
    # host ERROR ops on the SAME slot while it streams: they address real rows (or row 0
    # for row >= M) and write nothing; a younger add to that row must not take their
    # (empty) pipeline record as a forwarded value
    mm = M - 1 if M > 1 else M
    K = 80
    A, B = g.mat(mm, N, K)
    bnds = g.bounds_uniform(K, 1)
    bias_h = g.rbias()
    tag, _ = g.open_tile(0, mm, N, K, K, 1, bias_h)
    ch = g.tile_beats(0, tag, mm, N, A, B, bnds)
    for b in ch[0]:
        g.ps(*b, expect="apply")
    g.barrier()
    for c in range(1, K - 1):                       # final chunk withheld: tile stays open
        for b in ch[c]:
            g.ps(*b, expect="apply")
    for i in range(60):
        r = g.rng.randrange(mm)
        if mm < M and i % 3 == 2:
            g.hc(g.rng.choice([R.HC_READ, R.HC_CLEAR]), 0, g.rng.randint(mm, M - 1), shared=True)
        else:
            g.hc(R.HC_WRITE, 0, r, [g.rng.randint(-99, 99)] * N, shared=True)
    g.barrier()
    for b in ch[K - 1]:
        g.ps(*b, expect="apply")
    g.exact[tag] = R.gemm_ref(A, B, bias_h[:N])
    g.barrier()
    # concurrency: host traffic on slot 1 while psums stream into slot 0
    if p.num_tiles >= 2:
        tag1, _ = g.open_tile(1, M, N, 6, 2, 1, g.rbias())
        A1, B1 = g.mat(M, N, 6)
        ch1 = g.tile_beats(1, tag1, M, N, A1, B1, [0, 3, 6])
        for b in ch1[0]:
            g.ps(*b, expect="apply")
        g.barrier()
        A0, B0 = g.mat(M, N, 64)
        tag0, _ = g.open_tile(0, M, N, 64, 16)
        for b in [b for c in g.tile_beats(0, tag0, M, N, A0, B0, g.bounds_uniform(64, 4)) for b in c]:
            g.ps(*b, expect="apply")
        g.exact[tag0] = R.gemm_ref(A0, B0)
        for i in range(24):
            g.hc(R.HC_READ, 1, i % M)
        g.barrier()
        for b in ch1[1]:
            g.ps(*b, expect="apply")
        g.barrier()


def suite_overflow(g):
    p = g.p
    N = p.cols
    full = (1 << N) - 1
    kmax = R.max_exact_k(p.acc_w, 8)
    kc_max = p.psum_kmax          # 131071 for 32-bit psums

    def worst_tile(K, bias=None, prod=16384, m=1, expect_code=R.CR_OK, exact=None):
        """m x N tile, every product = prod (synthetic psums).  K is split into at least two
        chunks when K >= 2, and into maximal (PSUM_KMAX) chunks for long K."""
        kc = kc_max if K > 2 * kc_max else max(1, (K + 1) // 2)
        bounds = g.bounds_uniform(K, kc)
        be = 1 if bias is not None else 0
        tag, code = g.open_tile(0, m, N, K, len(bounds) - 1, be, bias)
        assert code == expect_code, (K, code, expect_code)
        if code != R.CR_OK:
            return None
        for c in range(len(bounds) - 1):
            kc = bounds[c + 1] - bounds[c]
            for r in range(m):
                g.ps(0, tag, c, kc, r, int(r == m - 1), full, [kc * prod] * N, expect="apply")
        if exact is not None:
            g.exact[tag] = [[exact] * N for _ in range(m)]
        return tag

    smax, smin = R.smax(p.acc_w), R.smin(p.acc_w)
    if p.strict:
        # the brief's bound, at this ACC_W
        if kmax <= 40 * kc_max:
            worst_tile(kmax, exact=kmax * 16384)
            g.barrier()
            worst_tile(kmax + 1, expect_code=R.CR_RANGE)
            g.barrier()
        # bias boundary, positive and negative
        K = min(kmax, 131071)
        hi_b = smax - K * 16384
        if hi_b <= R.smax(32):
            worst_tile(K, bias=[hi_b] * N, exact=smax)                            # exactly ACC_MAX
            g.barrier()
            worst_tile(K, bias=[hi_b + 1] * N, expect_code=R.CR_RANGE)
            g.barrier()
        lo_b = smin + K * 16256
        if lo_b >= R.smin(32):
            worst_tile(K, bias=[lo_b] * N, prod=-16256, exact=smin)              # exactly ACC_MIN
            g.barrier()
            worst_tile(K, bias=[lo_b - 1] * N, prod=-16256, expect_code=R.CR_RANGE)
            g.barrier()
        # one column with a hostile bias is enough to reject the tile
        if N > 1 and kmax <= 131071:
            b = [0] * N
            b[N - 1] = smax - kmax * 16384 + 1
            worst_tile(kmax, bias=b, expect_code=R.CR_RANGE)
            g.barrier()
        if p.acc_w > 32:
            # INT32 output boundary with a wider accumulator
            worst_tile(131071, bias=[16383] * N, exact=R.smax(32))                # fits INT32
            g.barrier()
            worst_tile(131071, bias=[16384] * N, exact=R.smax(32) + 1)            # clips at OUT_W=32
            g.barrier()
            worst_tile(131071, bias=[R.smin(32) + 131071 * 16256] * N, prod=-16256,
                       exact=R.smin(32))
            g.barrier()
            worst_tile(131071, bias=[R.smin(32) + 131071 * 16256 - 1] * N, prod=-16256,
                       exact=R.smin(32) - 1)
            g.barrier()
            # multi-row tile: only row 0 clips at OUT_W = 32 -> cmt_clip must still be set
            if p.rows >= 2:
                tag, _ = g.open_tile(0, 2, N, 131071, 2, 1, [16384] * N)
                for c, k in enumerate((65536, 65535)):
                    g.ps(0, tag, c, k, 0, 0, full, [k * 16384] * N, expect="apply")
                    g.ps(0, tag, c, k, 1, 1, full, [-k] * N, expect="apply")
                g.exact[tag] = [[R.smax(32) + 1] * N, [16384 - 131071] * N]
                g.barrier()
            # a long reduction far beyond the INT32-safe K, many chunks
            K = min(kmax, 300 * kc_max + 17)
            worst_tile(K, exact=K * 16384)
            g.barrier()
            worst_tile(K, prod=-16256, exact=-K * 16256)
            g.barrier()
    else:
        # wraparound / saturation explicitly selected or tolerated: overflow is flagged
        K = kmax + 1
        worst_tile(K)                                      # first overflow on the last chunk
        g.barrier()
        worst_tile(K, prod=-16256)                         # negative side
        g.barrier()
        worst_tile(kmax, bias=[smax - kmax * 16384] * N)   # exactly ACC_MAX, no overflow
        g.barrier()
        # overflow, then a negative chunk: SAT continues from the clamp, WRAP from the wrap
        b0 = R.smax(32)
        npos = (smax - b0) // (kc_max * 16384) + 1          # positive chunks needed to overflow
        tag, _ = g.open_tile(0, 1, N, npos * kc_max + kc_max + 1, npos + 2, 1, [b0] * N)
        for c in range(npos):
            g.ps(0, tag, c, kc_max, 0, 1, full, [kc_max * 16384] * N, expect="apply")
        g.ps(0, tag, npos, kc_max, 0, 1, full, [-kc_max * 16256] * N, expect="apply")
        g.ps(0, tag, npos + 1, 1, 0, 1, full, [-5] * N, expect="apply")
        assert g.m.perf["OVF_ACC"] > 0
        g.barrier()
        # huge K accepted without the static check
        worst_tile(4 * kmax + 3)
        g.barrier()
        # multi-row tile: only row 0 overflows -> the tile summary must still report it
        if p.rows >= 2:
            K = kmax + 1
            kc = max(1, (K + 1) // 2) if K <= 2 * kc_max else kc_max
            bnds = g.bounds_uniform(K, kc)
            tag, _ = g.open_tile(0, 2, N, K, len(bnds) - 1)
            for c in range(len(bnds) - 1):
                k = bnds[c + 1] - bnds[c]
                g.ps(0, tag, c, k, 0, 0, full, [k * 16384] * N, expect="apply")    # row 0 overflows
                g.ps(0, tag, c, k, 1, 1, full, [0] * N, expect="apply")            # row 1 stays 0
            g.barrier()


def suite_reset(g):
    p = g.p
    M, N = p.rows, p.cols
    A, B = g.mat(M, N, 30)
    bounds = [0, 10, 20, 30]
    for when in range(4):
        tag, _ = g.open_tile(0, M, N, 30, 3, 1, g.rbias())
        ch = g.tile_beats(0, tag, M, N, A, B, bounds)
        beats = [b for c in ch for b in c]
        if when == 3:
            for b in beats:
                g.ps(*b, expect="apply")      # tile completes; reset may hit its commit
        else:
            n = g.rng.randint(1, len(beats) - 1)
            for b in beats[:n]:
                g.ps(*b, expect="apply")
            if p.num_tiles >= 2:
                t1, _ = g.open_tile(1, M, N, 30, 3)
                for b in g.tile_beats(1, t1, M, N, A, B, bounds)[0]:
                    g.ps(*b, expect="apply")
        g.reset(max_delay=8 if when < 3 else 3)
        # after reset every slot is free and every row invalid: a full re-run is exact
        g.run_tile(0, M, N, A, B, bounds)
        g.barrier()
    # reset in the middle of a stream of back-to-back RAW ops (M=1, many chunks)
    A1, B1 = g.mat(1, N, 40)
    tag, _ = g.open_tile(0, 1, N, 40, 40)
    for b in [b for c in g.tile_beats(0, tag, 1, N, A1, B1, g.bounds_uniform(40, 1)) for b in c][:25]:
        g.ps(*b, expect="apply")
    g.reset(max_delay=0)
    g.run_tile(0, 1, N, A1, B1, g.bounds_uniform(40, 1))
    g.barrier()


def suite_soak(g, n_rounds):
    p = g.p
    r = g.rng
    for rnd in range(n_rounds):
        lists = []
        nt = r.randint(1, p.num_tiles)
        slots = r.sample(range(p.num_tiles), nt)
        for s in slots:
            m, n = r.randint(1, p.rows), r.randint(1, p.cols)
            K = r.choice([1, 2, 3, r.randint(1, 20), r.randint(20, 200)])
            A, B = g.mat(m, n, K, r.choice(["rand", "rand", "edge", "max", "neg"]))
            bounds = g.bounds_random(K, r.choice([2, 4, 16, 64]))
            be = r.randint(0, 1)
            bias = g.rbias(-(1 << 26), 1 << 26)
            tag, code = g.open_tile(s, m, n, K, len(bounds) - 1, be, bias, dest=r.randint(1, 7))
            g.exact[tag] = R.gemm_ref(A, B, bias[:n] if be else None)
            ch = g.tile_beats(s, tag, m, n, A, B, bounds)
            seq = []
            for ci, c in enumerate(ch):
                seq += c
                if ci < len(ch) - 1 and r.random() < 0.15:  # restart: replay an earlier chunk
                    back = r.randint(0, ci)
                    seq += r.sample(ch[back], r.randint(1, len(ch[back])))
            if r.random() < 0.3:
                per_row = [[b for b in seq if b[4] == q] for q in range(m)]
                lists += per_row
            else:
                lists.append(seq)
        for b in g.merge(lists):
            g.ps(*b)
            if r.random() < 0.01:                          # stray malformed beat
                s0, t0, c0, k0, r0, l0, cm0, d0 = b
                g.ps(s0, t0 ^ 0x5555, c0, k0, r0, l0, cm0, d0, expect="err")
        if r.random() < 0.25:
            g.barrier()
    g.barrier()


def suite_perf_raw(g):
    """Throughput: 1000 back-to-back adds to ONE entry (M = 1, chunks of 1 K-step)."""
    A, B = g.mat(1, g.p.cols, 1000)
    g.run_tile(0, 1, g.p.cols, A, B, g.bounds_uniform(1000, 1))


def suite_perf_full(g):
    """Throughput: full tile, 250 chunks (rows of one chunk back-to-back, then the next chunk)."""
    A, B = g.mat(g.p.rows, g.p.cols, 250)
    g.run_tile(0, g.p.rows, g.p.cols, A, B, g.bounds_uniform(250, 1))


SUITES = dict(perf_raw=suite_perf_raw, perf_full=suite_perf_full, stage1=suite_stage1, basic=suite_basic, errors=suite_errors, host=suite_host,
              overflow=suite_overflow, reset=suite_reset)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", required=True,
                    help="comma list of: " + ",".join(list(SUITES) + ["soak"]))
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--tiles", type=int, default=2)
    ap.add_argument("--acc", type=int, default=32)
    ap.add_argument("--out-w", type=int, default=32)
    ap.add_argument("--rd-lat", type=int, default=1)
    ap.add_argument("--policy", type=int, default=0)
    ap.add_argument("--strict", type=int, default=1)
    ap.add_argument("--guard", type=int, default=1)
    ap.add_argument("--soak", type=int, default=40)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    p = R.Params(rows=a.rows, cols=a.cols, num_tiles=a.tiles, acc_w=a.acc, out_w=a.out_w,
                 ovf_policy=a.policy, strict=a.strict, guard=a.guard)
    g = Gen(p, a.rd_lat, a.seed)
    for s in a.suite.split(","):
        if s == "soak":
            suite_soak(g, a.soak)
        else:
            SUITES[s](g)
        g.barrier()
    nw = g.write(a.out)
    st = g.stats
    print(f"{a.out}: {nw} words, {st['tiles']} tiles, {st['beats']} psum beats, {st['cfg']} cfg, "
          f"{st['host']} host ops, {st['resets']} resets, {len(g.exact)} tiles checked vs gemm, "
          f"{g.seg} segments")


if __name__ == "__main__":
    main()
