#!/usr/bin/env python3
"""
TENSORCORE 04 -- mutation testing.

Each mutant is one deliberate, realistic bug in the RTL (exact text
substitution, asserted to match exactly once).  A mutant is KILLED when any
test in the subset below fails (TB_RESULT: FAIL, a simulator $error, a
watchdog/deadlock, or a compile error).  A surviving mutant is reported with
an explanation of why the behaviour is (or is not) observable.

  tools/mutation_test.py [-j N] [--only m01,m02]
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import shutil
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ACC = "rtl/tensor_accumulator.sv"
RTR = "rtl/tensor_acc_out_router.sv"

MUTANTS = [
    ("m01", ACC, "bias applied with every chunk instead of once",
     "assign ps_bias_first = (ps_nch == '0) & s_bias_en_q[ps_si];",
     "assign ps_bias_first = s_bias_en_q[ps_si];"),
    ("m02", ACC, "replayed chunk added again (no duplicate filter)",
     "assign ps_apply      = (ps_code == tensor_acc_pkg::PE_NONE) & ~ps_dup;",
     "assign ps_apply      = (ps_code == tensor_acc_pkg::PE_NONE);"),
    ("m03", ACC, "replay treated as an ordering error",
     "            ps_dup  = 1'b1;                                          // replay: already applied",
     "            ps_code = tensor_acc_pkg::PE_ORDER;"),
    ("m04", ACC, "no forwarding from the W stage (RAW d=1)",
     "        if (w_vld && w_wr && w_addr == x_addr) begin",
     "        if (1'b0) begin"),
    ("m05", ACC, "no forwarding from the write history (RAW d>=2)",
     "            if (h_vld[i] && h_addr[i*AW +: AW] == x_addr) begin",
     "            if (1'b0) begin"),
    ("m06", ACC, "forwarding picks the OLDEST matching write",
     "        for (int i = RD_LAT - 1; i >= 0; i--) begin\n            if (h_vld[i]",
     "        for (int i = 0; i < RD_LAT; i++) begin\n            if (h_vld[i]"),
    ("m07", ACC, "first chunk reads (stale) storage instead of initialising",
     "                a_userd = ps_evld;      // first chunk with no preload: base 0, no read",
     "                a_userd = 1'b1;"),
    ("m08", ACC, "first chunk ignores a host preload",
     "                a_userd = ps_evld;      // first chunk with no preload: base 0, no read",
     "                a_userd = ps_evld & (ps_nch != '0);"),
    ("m09", ACC, "tile committed one chunk early",
     "                    if (ps_nch + CHUNK_W'(1) == ps_nchunks) begin",
     "                    if (ps_nch + CHUNK_W'(2) >= ps_nchunks) begin"),
    ("m10", ACC, "chunk completion ignores the other rows (early commit)",
     "assign ps_chunk_done = (ps_nch == ps_cdone) & (&ps_other_ok);",
     "assign ps_chunk_done = (ps_nch == ps_cdone);"),
    ("m11", ACC, "skipped chunk accepted (no ordering check)",
     "        else if (ps_chunk != ps_nch || ps_chunk >= ps_nchunks)",
     "        else if (1'b0)"),
    ("m12", ACC, "no K bookkeeping check",
     "        else if (ps_kacc_new > (KTOT_W+1)'(ps_ktot) ||\n                 (ps_chunk == ps_nchunks - CHUNK_W'(1) && ps_kacc_new != (KTOT_W+1)'(ps_ktot)))",
     "        else if (1'b0)"),
    ("m13", ACC, "no psum range guard",
     "        else if (!(&ps_lane_ok))", "        else if (1'b0)"),
    ("m14", ACC, "stale beats with a foreign tag accepted",
     "if (ps_soob || ps_st == tensor_acc_pkg::ST_FREE || !ps_tagok)",
     "if (ps_soob || ps_st == tensor_acc_pkg::ST_FREE)"),
    ("m15", ACC, "column-mask / last-flag check removed",
     "        else if (ps_col_mask != ps_cmask_t || ps_last != (32'(ps_row) == 32'(ps_m) - 1))",
     "        else if (1'b0)"),
    ("m16", ACC, "overflow never detected",
     "            assign of  = ~((&sum[SW-1:ACC_W-1]) | ~(|sum[SW-1:ACC_W-1]));",
     "            assign of  = 1'b0;"),
    ("m17", ACC, "saturation silently replaced by wraparound",
     "                if (of && SAT) res =", "                if (1'b0) res ="),
    ("m18", ACC, "overflow flag not sticky across chunks",
     "assign x_entry[gj*LW +: LW] = {bo | of, res};", "assign x_entry[gj*LW +: LW] = {of, res};"),
    ("m19", ACC, "INT32 narrowing wraps instead of saturating",
     "                    (cl && SAT) ?", "                    (1'b0) ?"),
    ("m20", ACC, "lanes outside the tile accumulated",
     "assign ps_pay[gj*PW +: PW] = ps_cmask_t[gj] ? (pterm + bterm) : '0;",
     "assign ps_pay[gj*PW +: PW] = (pterm + bterm);"),
    ("m21", ACC, "output credit off by one (FIFO overflow)",
     "assign o_credit_ok = (32'(o_infl_q) + 32'(ofifo_cnt)) < OFIFO_DEPTH;",
     "assign o_credit_ok = (32'(o_infl_q) + 32'(ofifo_cnt)) <= OFIFO_DEPTH;"),
    ("m22", ACC, "write-port backpressure ignored (write lost)",
     "    assign pipe_en  = ~(w_vld & w_wr & ~st_wr_ready);", "    assign pipe_en  = 1'b1;"),
    ("m23", ACC, "read-port backpressure ignored (read lost)",
     "    assign issue_ok = pipe_en & st_rd_ready;", "    assign issue_ok = pipe_en;"),
    ("m24", ACC, "host WRITE allowed after a chunk landed",
     "                else if (hc_nch != '0)                            hc_stat = tensor_acc_pkg::HS_ERR_ORDER;",
     "                else if (1'b0)                                    hc_stat = tensor_acc_pkg::HS_ERR_ORDER;"),
    ("m25", ACC, "host CLEAR leaves the tile's chunk-complete count",
     "                        a_cdone_we    = 1'b1;          // this row restarts from chunk 0",
     "                        a_cdone_we    = 1'b0;"),
    ("m26", ACC, "host ABORT does not free the slot",
     "                    default: begin                     // HC_ABORT\n                        a_state_we    = 1'b1;",
     "                    default: begin                     // HC_ABORT\n                        a_state_we    = 1'b0;"),
    ("m27", ACC, "commit engine mis-identifies the last row",
     "assign cm_last = (32'(cm_row_q) == 32'(cm_m) - 1);", "assign cm_last = (32'(cm_row_q) == 32'(cm_m) - 2);"),
    ("m28", ACC, "tile overflow summary forgets earlier rows",
     "cmt_ovf_q  <= t_ovf_q  | (|o_ovf);", "cmt_ovf_q  <= (|o_ovf);"),
    ("m29", ACC, "static K-range check disabled",
     "assign cfg_range_ok = (STRICT_RANGE == 0) | (&cfg_col_ok);", "assign cfg_range_ok = 1'b1;"),
    ("m30", ACC, "static K-range check off by one",
     "((hi <= R_ACC_MAX) & (lo >= R_ACC_MIN))", "((hi < R_ACC_MAX) & (lo >= R_ACC_MIN))"),
    ("m31", ACC, "psum-element event counts masked lanes",
     "ev_apply_c ? popc(ps_cmask_t) : '0;", "ev_apply_c ? popc({COLS{1'b1}}) : '0;"),
    ("m32", ACC, "K-chunk-completed event never raised",
     "ev[tensor_acc_pkg::PF_CHUNKS*EVW +: EVW]       = b2e(ev_chunk_c);",
     "ev[tensor_acc_pkg::PF_CHUNKS*EVW +: EVW]       = b2e(1'b0);"),
    ("m33", ACC, "tile error flag never set",
     "                a_serr_we   = 1'b1;", "                a_serr_we   = 1'b0;"),
    ("m34", ACC, "K count not accumulated across chunks",
     "a_meta_kacc_d = ps_kacc_new[KTOT_W-1:0];", "a_meta_kacc_d = KTOT_W'(ps_chunk_k);"),
    ("m35", ACC, "write history not shifted (RD_LAT >= 2)",
     "                h_vld[i]              <= h_vld[i-1];", "                h_vld[i]              <= 1'b0;"),
    ("m36", ACC, "opening a tile does not invalidate its rows",
     "vld_r <= 1'b0; nch_r <= '0; kacc_r <= '0;      // tile open: rows not initialised",
     "vld_r <= vld_r; nch_r <= nch_r; kacc_r <= kacc_r;"),
    ("m37", ACC, "chunk count not incremented",
     "a_meta_nch_d  = ps_nch + CHUNK_W'(1);", "a_meta_nch_d  = ps_nch;"),
    ("m38", RTR, "router re-offers a beat to a port that already took it",
     "assign need      = in_dest & ~done_q;", "assign need      = in_dest;"),
    ("m39", ACC, "reset does not clear row metadata",
     "                if (!rst_n) begin\n                    vld_r <= 1'b0; nch_r <= '0; kacc_r <= '0;",
     "                if (!rst_n) begin\n                    vld_r <= vld_r; nch_r <= nch_r; kacc_r <= kacc_r;"),
    ("m40", ACC, "forwarding from ops that did not write",
     "        if (w_vld && w_wr && w_addr == x_addr) begin", "        if (w_vld && w_addr == x_addr) begin"),
    ("m41", ACC, "INT32 range test uses the wrong bit range",
     "assign in_rng = (&v[ACC_W-1:OUT_W-1]) | ~(|v[ACC_W-1:OUT_W-1]);",
     "assign in_rng = (&v[ACC_W-1:OUT_W]) | ~(|v[ACC_W-1:OUT_W]);"),
]

# explanation for mutants that are expected to be equivalent
EQUIVALENT = {
    "m39": "Equivalent by construction: after reset every slot is FREE, row metadata is only consulted for "
           "open slots, and opening a slot (cfg) re-initialises every row of it. Stale metadata is unreachable.",
}

RTL = ["rtl/tensor_acc_pkg.sv", "rtl/tensor_acc_fifo.sv", "rtl/tensor_acc_storage.sv",
       "rtl/tensor_acc_out_router.sv", "rtl/tensor_accumulator.sv", "rtl/tensor_acc_subsystem.sv"]
ARR = ["third_party/tensorcore02/rtl/" + f for f in
       ("tensor_pe.sv", "tensor_skew.sv", "tensor_output_collect.sv", "tensor_systolic_array.sv")]
P2 = "+PSGAP=40 +HCGAP=40 +ORDY=25 +HRRDY=30 +RDBLK=40 +WRBLK=40"
P1 = "+PSGAP=20 +HCGAP=20 +ORDY=60 +HRRDY=70 +RDBLK=15 +WRBLK=15"

# (config name, tb, params, gen-args, suites, plusargs)
CFGS = [
    ("base_rd1", "tb_acc", dict(ROWS=4, COLS=4, NUM_TILES=2, RD_LAT=1),
     "--rows 4 --cols 4 --tiles 2 --rd-lat 1", ["stage1", "basic", "errors", "host", "overflow", "reset", "soak"], P2),
    ("t4_rd2", "tb_acc", dict(ROWS=4, COLS=4, NUM_TILES=4, RD_LAT=2),
     "--rows 4 --cols 4 --tiles 4 --rd-lat 2", ["stage1", "basic", "errors", "host", "reset", "soak"], P1),
    ("sat_nonstrict", "tb_acc", dict(ROWS=4, COLS=4, NUM_TILES=2, STRICT=0),
     "--rows 4 --cols 4 --tiles 2 --strict 0", ["overflow"], P1),
    ("acc40_out32", "tb_acc", dict(ROWS=4, COLS=4, NUM_TILES=2, ACC_W=40, OUT_W=32),
     "--rows 4 --cols 4 --tiles 2 --acc 40 --out-w 32", ["overflow"], P1),
    ("integ_4x4", "tb_integ", dict(ROWS=4, COLS=4, NUM_TILES=2),
     "--rows 4 --cols 4 --tiles 2", ["stage1", "general"], "+SGAP=20 +STALL=15 +ORDY=50 +RDBLK=20 +WRBLK=20"),
]
BAD = re.compile(r"(^ERROR|%Error|TB_ERROR)", re.M)


def sh(cmd, timeout=1200):
    try:
        r = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout + r.stderr
    except subprocess.TimeoutExpired:
        return 124, "TIMEOUT"


def prepare_vectors():
    for name, tb, _, gargs, suites, _ in CFGS:
        for s in suites:
            tool = "gen_unit.py" if tb == "tb_acc" else "gen_integ.py"
            vec = f"vectors/mut_{name}_{s}.hex"
            if not os.path.exists(os.path.join(ROOT, vec)):
                rc, out = sh(f"python3 tools/{tool} --suite {s} {gargs} --seed 11 --out {vec}")
                assert rc == 0, out


def run_tests(rtl_dir, tag):
    """Returns (killed, by) for the RTL in rtl_dir."""
    for name, tb, params, _, suites, plus in CFGS:
        srcs = [f"{rtl_dir}/{os.path.basename(f)}" for f in RTL] + (ARR if tb == "tb_integ" else []) + [f"tb/{tb}.sv"]
        ps = " ".join(f"-P{tb}.{k}={v}" for k, v in params.items())
        odir = rtl_dir if rtl_dir.startswith("build") else os.path.join("build", "mut", "golden")
        os.makedirs(os.path.join(ROOT, odir), exist_ok=True)
        exe = f"{odir}/{name}.vvp"                 # executables never go next to the sources
        # internal RTL/FIFO invariants compiled out: every kill is made by the testbench itself
        rc, out = sh(f"iverilog -g2012 -DTA_NO_INVARIANTS -s {tb} {ps} -o {exe} {' '.join(srcs)}")
        if rc != 0:
            return True, f"compile error ({name})"
        for s in suites:
            key = "VEC" if tb == "tb_acc" else "JOBS"
            rc, out = sh(f"vvp -n {exe} +{key}=vectors/mut_{name}_{s}.hex +SEED=1 {plus}", timeout=600)
            if "TB_RESULT: PASS" not in out or BAD.search(out):
                first = next((l for l in out.splitlines() if "TB_ERROR" in l or "ERROR" in l or "TIMEOUT" in l), "TB_RESULT: FAIL")
                return True, f"{name}/{s}: {first.strip()[:160]}"
    return False, ""


def run_mutant(m):
    mid, path, desc, find, repl = m
    d = os.path.join("build", "mut", mid)
    os.makedirs(os.path.join(ROOT, d), exist_ok=True)
    for f in RTL:
        shutil.copy(os.path.join(ROOT, f), os.path.join(ROOT, d, os.path.basename(f)))
    tgt = os.path.join(ROOT, d, os.path.basename(path))
    src = open(tgt).read()
    n = src.count(find)
    if n != 1:
        return dict(id=mid, desc=desc, status="BAD_MUTANT", detail=f"pattern matched {n} times")
    open(tgt, "w").write(src.replace(find, repl))
    t0 = time.time()
    killed, by = run_tests(d, mid)
    return dict(id=mid, desc=desc, status="KILLED" if killed else "SURVIVED", detail=by,
                note=EQUIVALENT.get(mid, ""), t=round(time.time() - t0, 1))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("-j", type=int, default=os.cpu_count() or 4)
    ap.add_argument("--only", default="")
    a = ap.parse_args()
    prepare_vectors()
    killed, by = run_tests("rtl", "golden")
    if killed:
        print("golden RTL fails the mutation subset:", by)
        return 2
    print("golden RTL passes the mutation subset")
    sel = [m for m in MUTANTS if not a.only or m[0] in a.only.split(",")]
    res = []
    with cf.ThreadPoolExecutor(max_workers=a.j) as ex:
        for r in ex.map(run_mutant, sel):
            res.append(r)
            print(f"  {r['id']} {r['status']:<9} {r['desc']:<58} {r.get('detail', '')[:120]}", flush=True)
    k = sum(r["status"] == "KILLED" for r in res)
    s = [r for r in res if r["status"] == "SURVIVED"]
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    json.dump(res, open(os.path.join(ROOT, "reports/mutation_results.json"), "w"), indent=1)
    with open(os.path.join(ROOT, "reports/mutation_report.md"), "w") as f:
        f.write("# TENSORCORE 04 mutation report\n\n")
        f.write(f"**{k} of {len(res)} mutants killed.** Generated by `tools/mutation_test.py` "
                "(Icarus; unit TB at heavy backpressure on 4 configurations + the TC02 integration TB). "
                "The RTL's own simulation invariants are compiled out (`TA_NO_INVARIANTS`), so every kill "
                "below is made by the testbench checks alone.\n\n")
        f.write("| id | injected bug | result | first failing check |\n|---|---|---|---|\n")
        for r in res:
            f.write(f"| {r['id']} | {r['desc']} | {r['status']} | {r.get('detail', '').replace('|', '/')} |\n")
        if s:
            f.write("\n## Survivors\n\n")
            for r in s:
                f.write(f"* **{r['id']}** ({r['desc']}): {r['note'] or 'NOT EXPLAINED -- test gap'}\n")
    print(f"\nMUTATION: {k}/{len(res)} killed; survivors: {[r['id'] for r in s]}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
