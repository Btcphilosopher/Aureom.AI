#!/usr/bin/env python3
"""
TENSORCORE 04 -- integration job generator for tb/tb_integ.sv
(TENSORCORE 02 systolic array  ->  tensor_acc_subsystem).

Each job is one output tile  C = bias + A @ B  with K split into chunks; the
testbench runs every chunk as a separate array launch.  Expected C is the
exact Python-integer GEMM (model/acc_ref.gemm_ref).  Jobs that compute the same
A, B with different partitions are asserted identical here, and the TB
checks the hardware against the same numbers.

Word format (hex, one 32-bit word per line):
  header : MAGIC, nwords, ROWS, COLS, NUM_TILES, ACC_W, OUT_W, njobs
  job    : (1<<24)|len, slot, tag, M, N, K, nchunks, bias_en, dest,
           arr_rst_chunk, arr_rst_rows, acc_rst_chunk, retag, mode, a_const, b_const,
           bias[COLS], chunk_k[nchunks],
           mode 0: A[M*K] (row-major), B[K*N] (row-major)
           expected wide[M*N] (lo,hi), expected data[M*N] (lo,hi), clip[M*N]
  arr_rst_chunk / acc_rst_chunk = 0xFFFFFFFF: no reset
"""
import argparse
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
import acc_ref as R  # noqa: E402

MAGIC = 0x7C041001
NONE = 0xFFFFFFFF


def u32(v):
    return v & 0xFFFFFFFF


def w64(v):
    v &= (1 << 64) - 1
    return [v & 0xFFFFFFFF, v >> 32]


class IGen:
    def __init__(self, rows, cols, tiles, acc_w, out_w, seed):
        self.rows, self.cols, self.tiles, self.acc_w, self.out_w = rows, cols, tiles, acc_w, out_w
        self.rng = random.Random(seed)
        self.jobs = []
        self.next_tag = 1
        self.groups = {}

    def mat(self, M, N, K, mode="rand"):
        r = self.rng
        if mode == "neg":
            return [[-128] * K for _ in range(M)], [[127] * N for _ in range(K)]
        if mode == "edge":
            ch = [-128, -127, -1, 0, 1, 126, 127]
            return ([[r.choice(ch) for _ in range(K)] for _ in range(M)],
                    [[r.choice(ch) for _ in range(N)] for _ in range(K)])
        if mode == "sym":
            return ([[r.randint(-127, 127) for _ in range(K)] for _ in range(M)],
                    [[r.randint(-127, 127) for _ in range(N)] for _ in range(K)])
        return ([[r.randint(-128, 127) for _ in range(K)] for _ in range(M)],
                [[r.randint(-128, 127) for _ in range(N)] for _ in range(K)])

    def uniform(self, K, kc):
        return [min(kc, K - s) for s in range(0, K, kc)]

    def randparts(self, K, nmax):
        if K == 1:
            return [1]
        cuts = sorted(self.rng.sample(range(1, K), self.rng.randint(1, min(K - 1, nmax - 1))))
        b = [0] + cuts + [K]
        return [b[i + 1] - b[i] for i in range(len(b) - 1)]

    def job(self, M, N, A, B, chunks, bias=None, dest=1, arr_rst=None, acc_rst=None,
            const=None, group=None, slot=None):
        K = sum(chunks)
        assert all(1 <= c <= 131071 for c in chunks)
        tag = self.next_tag
        self.next_tag += 1
        retag = NONE
        if acc_rst is not None:
            retag = self.next_tag
            self.next_tag += 1
        if const is not None:
            a, b = const
            C = [[K * a * b for _ in range(N)] for _ in range(M)]
            if bias is not None:
                C = [[C[m][n] + bias[n] for n in range(N)] for m in range(M)]
        else:
            C = R.gemm_ref(A, B, bias[:N] if bias is not None else None)
            # the architectural model with this exact partition must agree
            p = R.Params(rows=self.rows, cols=self.cols, num_tiles=1, acc_w=self.acc_w, out_w=self.out_w)
            md = R.AccModel(p)
            bb = (list(bias) + [0] * self.cols)[:self.cols] if bias is not None else [0] * self.cols
            assert md.cfg(0, 1, M, N, K, len(chunks), int(bias is not None), bb, dest) == R.CR_OK
            k0 = 0
            for c, kc in enumerate(chunks):
                P = R.chunk_psums(A, B, k0, k0 + kc)
                for m in range(M):
                    md.ps(0, 1, c, kc, m, int(m == M - 1), (1 << N) - 1, P[m] + [0] * (self.cols - N))
                k0 += kc
            assert [b_["wide"][:N] for b_ in md.out] == C, "model disagrees with gemm"
        for row in C:
            for v in row:
                assert R.smin(self.acc_w) <= v <= R.smax(self.acc_w), "integration jobs must be in range"
        if group is not None:
            if group in self.groups:
                assert self.groups[group] == C, "same A,B with another partition must give the same C"
            self.groups[group] = C
        slot = (len(self.jobs) % self.tiles) if slot is None else slot
        self.jobs.append(dict(slot=slot, tag=tag, M=M, N=N, K=K, chunks=chunks,
                              bias=bias, dest=dest, arr_rst=arr_rst, acc_rst=acc_rst, retag=retag,
                              const=const, A=A, B=B, C=C))
        return C

    def write(self, path):
        words = [MAGIC, 0, self.rows, self.cols, self.tiles, self.acc_w, self.out_w, len(self.jobs)]
        for j in self.jobs:
            M, N, K = j["M"], j["N"], j["K"]
            bias = (list(j["bias"]) + [0] * self.cols)[:self.cols] if j["bias"] is not None else [0] * self.cols
            ar = j["arr_rst"] if j["arr_rst"] is not None else (NONE, 0)
            mode = 1 if j["const"] is not None else 0
            ac, bc = j["const"] if mode else (0, 0)
            body = [j["slot"], j["tag"], M, N, K, len(j["chunks"]), int(j["bias"] is not None), j["dest"],
                    ar[0], ar[1], j["acc_rst"] if j["acc_rst"] is not None else NONE, j["retag"],
                    mode, u32(ac), u32(bc)] + [u32(b) for b in bias] + list(j["chunks"])
            if mode == 0:
                body += [u32(x) for row in j["A"] for x in row]
                body += [u32(x) for row in j["B"] for x in row]
            wide, data, clip = [], [], []
            for m in range(M):
                for n in range(N):
                    v = j["C"][m][n]
                    wide += w64(v)
                    if self.acc_w > self.out_w and not (R.smin(self.out_w) <= v <= R.smax(self.out_w)):
                        d, c = (R.smax(self.out_w) if v > 0 else R.smin(self.out_w)), 1
                    else:
                        d, c = v, 0
                    data += w64(d)
                    clip.append(c)
            body += wide + data + clip
            words += [(1 << 24) | len(body)] + body
        words[1] = len(words)
        assert len(words) < (1 << 23)
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w") as f:
            f.write("\n".join(f"{u32(w):08x}" for w in words) + "\n")
        return len(words)


def suite_stage1(g):
    M, N = g.rows, g.cols
    A, B = g.mat(M, N, 8)
    for parts in ([4, 4], [1, 7], [7, 1], [5, 3]):
        g.job(M, N, A, B, parts, group="s1")
    bias = [g.rng.randint(-(1 << 20), 1 << 20) for _ in range(g.cols)]
    g.job(M, N, A, B, [3, 5], bias=bias, dest=0b111)
    A1, B1 = g.mat(1, N, 2, "edge")
    g.job(1, N, A1, B1, [1, 1])
    g.job(M, N, A, B, [2, 6], arr_rst=(1, 1), group="s1")      # array reset during chunk-1 readout
    if M > 1 and N > 1:
        A2, B2 = g.mat(M - 1, N - 1, 9, "edge")
        g.job(M - 1, N - 1, A2, B2, [4, 5])


def suite_general(g):
    M, N = g.rows, g.cols
    KC = 32
    for K, mode in ((5, "rand"), (KC, "rand"), (KC, "edge"), (KC + 1, "rand"), (2 * KC + 1, "edge")):
        A, B = g.mat(M, N, K, mode)
        g.job(M, N, A, B, g.uniform(K, KC))
    A, B = g.mat(M, N, 200)
    g.job(M, N, A, B, g.uniform(200, 8))                       # 25 chunks
    A, B = g.mat(M, N, 96)
    g.job(M, N, A, B, g.uniform(96, 1))                        # 96 chunks of one K-step
    A, B = g.mat(1, N, 150)
    g.job(1, N, A, B, g.uniform(150, 3))                       # M = 1, 50 chunks
    A, B = g.mat(M, N, 300, "neg")
    g.job(M, N, A, B, g.uniform(300, 64))                      # negative accumulation
    # cancellation: odd chunks negate the preceding even chunk
    K = 6 * 8
    A, B = g.mat(M, N, K, "sym")
    for c in range(0, 8, 2):
        for m in range(M):
            for k in range(6):
                A[m][(c + 1) * 6 + k] = -A[m][c * 6 + k]
        for k in range(6):
            B[(c + 1) * 6 + k] = list(B[c * 6 + k])
    bias = [g.rng.randint(-(1 << 24), 1 << 24) for _ in range(g.cols)]
    C = g.job(M, N, A, B, g.uniform(K, 6), bias=bias)
    assert all(C[m] == bias[:N] for m in range(M))
    # bias once, many chunks
    A, B = g.mat(M, N, 120)
    g.job(M, N, A, B, g.uniform(120, 4), bias=[g.rng.randint(-(1 << 30), 1 << 30) for _ in range(g.cols)],
          dest=0b101)
    # partition invariance: one reduction, six partitions
    A, B = g.mat(M, N, 257, "edge")
    for parts in ([257], g.uniform(257, 16), g.uniform(257, 1), g.randparts(257, 9),
                  g.randparts(257, 30), g.randparts(257, 3)):
        g.job(M, N, A, B, parts, group="inv257")
    # restarts: array reset at random rows of random chunks
    A, B = g.mat(M, N, 60)
    for _ in range(4):
        parts = g.randparts(60, 6)
        g.job(M, N, A, B, parts, arr_rst=(g.rng.randrange(len(parts)), g.rng.randrange(M)), group="rst60")
    # accumulator reset mid-job, then a full re-run
    A, B = g.mat(M, N, 40)
    g.job(M, N, A, B, g.uniform(40, 10), acc_rst=1, group="accrst")
    g.job(M, N, A, B, g.uniform(40, 10), acc_rst=2, arr_rst=(3, 0), group="accrst")
    # partial tiles and repeated tiles
    for _ in range(4):
        m, n = g.rng.randint(1, M), g.rng.randint(1, N)
        K = g.rng.randint(1, 80)
        A, B = g.mat(m, n, K)
        g.job(m, n, A, B, g.randparts(K, 5), dest=g.rng.randint(1, 7))
    A, B = g.mat(M, N, 33)
    for i in range(5):
        g.job(M, N, A, B, g.randparts(33, 4 + i), group="rep33", slot=0)


def suite_longk(g):
    """The INT32 boundary through the real array: 131071 worst-case products."""
    N = g.cols
    g.job(1, N, None, None, [65536, 65535], const=(-128, -128))            # 2147467264
    g.job(1, N, None, None, [65535, 65536], const=(-128, -128), bias=[16383] * g.cols)  # INT32_MAX
    g.job(1, N, None, None, [131071], const=(-128, 127), bias=[-16793472] * g.cols)     # INT32_MIN


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", required=True)
    ap.add_argument("--rows", type=int, default=4)
    ap.add_argument("--cols", type=int, default=4)
    ap.add_argument("--tiles", type=int, default=2)
    ap.add_argument("--acc", type=int, default=32)
    ap.add_argument("--out-w", type=int, default=32)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    g = IGen(a.rows, a.cols, a.tiles, a.acc, a.out_w, a.seed)
    for s in a.suite.split(","):
        dict(stage1=suite_stage1, general=suite_general, longk=suite_longk)[s](g)
    nw = g.write(a.out)
    nch = sum(len(j["chunks"]) for j in g.jobs)
    print(f"{a.out}: {nw} words, {len(g.jobs)} jobs, {nch} chunks (array launches), "
          f"{len(g.groups)} partition-invariance groups")


if __name__ == "__main__":
    main()
