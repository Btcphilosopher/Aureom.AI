#!/usr/bin/env python3
"""
TENSORCORE 04 -- regression driver.

  tools/run_regress.py [--stage1] [--quick] [--skip-verilator] [-j N]

Order (as the brief requires): STAGE 1 = accumulation across exactly two K
chunks (unit + real-array integration, 4x4 baseline, both simulators) must
pass before anything else runs; STAGE 2 then generalises to arbitrary chunk
counts over the configuration matrix.

A run passes only if the testbench prints TB_RESULT: PASS, no simulator
$error / %Error line appears, and -- where both simulators ran the same
vectors with the same seed -- the two TB_ logs are identical line for line.
Writes reports/regression_summary.md and reports/regression.json.
"""
import argparse
import concurrent.futures as cf
import json
import os
import re
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RTL = ["rtl/tensor_acc_pkg.sv", "rtl/tensor_acc_fifo.sv", "rtl/tensor_acc_storage.sv",
       "rtl/tensor_acc_out_router.sv", "rtl/tensor_accumulator.sv", "rtl/tensor_acc_subsystem.sv"]
ARR = ["third_party/tensorcore02/rtl/" + f for f in
       ("tensor_pe.sv", "tensor_skew.sv", "tensor_output_collect.sv", "tensor_systolic_array.sv")]

# timing profiles (unit TB): psum gap, host gap, output ready, host-resp ready, rd busy, wr busy
PROF = {
    "P0": dict(PSGAP=0, HCGAP=0, ORDY=100, HRRDY=100, RDBLK=0, WRBLK=0),
    "P1": dict(PSGAP=20, HCGAP=20, ORDY=60, HRRDY=70, RDBLK=15, WRBLK=15),
    "P2": dict(PSGAP=40, HCGAP=40, ORDY=25, HRRDY=30, RDBLK=40, WRBLK=40),
    "P3": dict(PSGAP=0, HCGAP=0, ORDY=5, HRRDY=10, RDBLK=0, WRBLK=60),
}
IPROF = {
    "Q0": dict(SGAP=0, STALL=0, ORDY=100, RDBLK=0, WRBLK=0),
    "Q1": dict(SGAP=20, STALL=15, ORDY=50, RDBLK=20, WRBLK=20),
    "Q2": dict(SGAP=5, STALL=40, ORDY=10, RDBLK=40, WRBLK=40),
}
ALL_SUITES = ["stage1", "basic", "errors", "host", "overflow", "reset", "soak"]


def U(name, rows=4, cols=4, tiles=2, acc=32, out=32, rd=1, pol=0, strict=1, guard=1, ofifo=4,
      perf_w=40, suites=ALL_SUITES, sims=("icarus", "verilator"), profs=("P0", "P1", "P2", "P3"),
      seeds=(1, 2), stage=2):
    return dict(kind="unit", name=name, rows=rows, cols=cols, tiles=tiles, acc=acc, out=out, rd=rd,
                pol=pol, strict=strict, guard=guard, ofifo=ofifo, perf_w=perf_w, suites=list(suites),
                sims=list(sims), profs=list(profs), seeds=list(seeds), stage=stage)


def I(name, rows=4, cols=4, tiles=2, acc=32, out=32, rd=1, mp=0, suites=("stage1", "general"),
      sims=("icarus", "verilator"), profs=("Q0", "Q1", "Q2"), seeds=(1,), stage=2):
    return dict(kind="integ", name=name, rows=rows, cols=cols, tiles=tiles, acc=acc, out=out, rd=rd,
                mp=mp, suites=list(suites), sims=list(sims), profs=list(profs), seeds=list(seeds),
                stage=stage)


JOBS = [
    # ---------------- STAGE 1: two K chunks, 4x4 baseline, both simulators
    U("S1_unit_4x4", suites=["stage1"], seeds=(1, 2, 3), stage=1),
    I("S1_integ_4x4", suites=["stage1"], seeds=(1, 2), stage=1),
    # ---------------- STAGE 2: arbitrary chunk counts, configuration matrix
    U("U_4x4_base"),
    U("U_2x2", rows=2, cols=2, sims=("icarus",)),
    U("U_1x1_1tile", rows=1, cols=1, tiles=1, sims=("icarus",)),
    U("U_4x4_4tiles_rd2", tiles=4, rd=2),
    U("U_4x4_3tiles_rd3", tiles=3, rd=3, sims=("icarus",)),
    U("U_3x5_acc40_out40_rd2", rows=3, cols=5, tiles=2, acc=40, out=40, rd=2, sims=("icarus",)),
    U("U_4x4_acc40_out32", acc=40, out=32),
    U("U_4x4_acc48_out32_rd2", acc=48, out=32, rd=2, sims=("icarus",), profs=("P0", "P2")),
    U("U_4x4_sat_nonstrict", strict=0, pol=0, suites=["overflow", "stage1", "soak"]),
    U("U_4x4_wrap_nonstrict", strict=0, pol=1, suites=["overflow", "stage1", "soak"]),
    U("U_4x4_acc40_wrap_nonstrict", acc=40, out=32, strict=0, pol=1, suites=["overflow"], sims=("icarus",)),
    U("U_4x4_noguard", guard=0, suites=["errors", "stage1", "soak"], sims=("icarus",)),
    U("U_4x4_ofifo1", ofifo=1, sims=("icarus",), profs=("P0", "P2", "P3")),
    U("U_4x4_perfw6", perf_w=6, sims=("icarus",), profs=("P1",)),
    U("U_8x8", rows=8, cols=8, sims=("verilator",), profs=("P0", "P2")),
    U("U_16x16_4tiles", rows=16, cols=16, tiles=4, sims=("verilator",), profs=("P1",), seeds=(1,),
      suites=["stage1", "basic", "errors", "host", "reset"]),
    I("I_4x4_base", suites=["stage1", "general"], seeds=(1, 2)),
    # K = 131 071 through the real array: ~4 min per run on Icarus, 1 s on Verilator
    I("I_4x4_longk", suites=["longk"], sims=("icarus",), profs=("Q1",)),
    I("I_4x4_longk_v", suites=["longk"], sims=("verilator",), seeds=(1, 2)),
    I("I_2x2_rd2_mp1", rows=2, cols=2, rd=2, mp=1),
    I("I_1x1_1tile", rows=1, cols=1, tiles=1, sims=("icarus",)),
    I("I_3x5_3tiles_acc40_rd3", rows=3, cols=5, tiles=3, acc=40, out=40, rd=3, sims=("icarus",)),
    I("I_4x4_acc40_out32", acc=40, out=32, suites=["stage1", "general", "longk"], sims=("verilator",)),
    I("I_8x8", rows=8, cols=8, sims=("verilator",), profs=("Q1",)),
]


def sh(cmd, timeout=3600):
    t0 = time.time()
    try:
        r = subprocess.run(cmd, shell=True, cwd=ROOT, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout + r.stderr, time.time() - t0
    except subprocess.TimeoutExpired as e:
        return 124, (e.stdout or "") + "TIMEOUT", time.time() - t0


def tbparams(j):
    if j["kind"] == "unit":
        return dict(ROWS=j["rows"], COLS=j["cols"], NUM_TILES=j["tiles"], ACC_W=j["acc"], OUT_W=j["out"],
                    RD_LAT=j["rd"], OVF_POLICY=j["pol"], STRICT=j["strict"], GUARD=j["guard"],
                    OFIFO=j["ofifo"], PERF_W=j["perf_w"])
    return dict(ROWS=j["rows"], COLS=j["cols"], NUM_TILES=j["tiles"], ACC_W=j["acc"], OUT_W=j["out"],
                RD_LAT=j["rd"], MUL_PIPE=j["mp"])


def build(j, sim, rtl=None, tag=""):
    rtl = rtl or RTL
    top = "tb_acc" if j["kind"] == "unit" else "tb_integ"
    srcs = rtl + ([] if j["kind"] == "unit" else ARR) + [f"tb/{top}.sv"]
    pr = tbparams(j)
    bdir = f"build/{j['name']}{tag}"
    os.makedirs(os.path.join(ROOT, bdir), exist_ok=True)
    if sim == "icarus":
        ps = " ".join(f"-P{top}.{k}={v}" for k, v in pr.items())
        rc, out, t = sh(f"iverilog -g2012 -s {top} {ps} -o {bdir}/sim.vvp {' '.join(srcs)}")
        return rc, out, t, f"vvp -n {bdir}/sim.vvp"
    gs = " ".join(f"-G{k}={v}" for k, v in pr.items())
    rc, out, t = sh(f"verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module {top} {gs} "
                    f"-Mdir {bdir}/obj -o vsim {' '.join(srcs)} -j 4", timeout=3600)
    return rc, out, t, f"{bdir}/obj/vsim"


def gen(j, suite, tag=""):
    if j["kind"] == "unit":
        vec = f"vectors/u_{j['name']}_{suite}.hex"
        cmd = (f"python3 tools/gen_unit.py --suite {suite} --rows {j['rows']} --cols {j['cols']} "
               f"--tiles {j['tiles']} --acc {j['acc']} --out-w {j['out']} --rd-lat {j['rd']} "
               f"--policy {j['pol']} --strict {j['strict']} --guard {j['guard']} --seed 7 --out {vec}")
    else:
        vec = f"vectors/i_{j['name']}_{suite}.hex"
        cmd = (f"python3 tools/gen_integ.py --suite {suite} --rows {j['rows']} --cols {j['cols']} "
               f"--tiles {j['tiles']} --acc {j['acc']} --out-w {j['out']} --seed 7 --out {vec}")
    rc, out, _ = sh(cmd)
    return rc, out.strip(), vec


BAD = re.compile(r"(^ERROR|%Error|^Error|TB_ERROR|\$error|Assertion)", re.M)


def run_one(exe, j, vec, prof, seed, logpath):
    pr = PROF[prof] if j["kind"] == "unit" else IPROF[prof]
    key = "VEC" if j["kind"] == "unit" else "JOBS"
    args = f"+{key}={vec} +SEED={seed} " + " ".join(f"+{k}={v}" for k, v in pr.items())
    rc, out, t = sh(f"{exe} {args}", timeout=3600)
    with open(os.path.join(ROOT, logpath), "w") as f:
        f.write(out)
    ok = ("TB_RESULT: PASS" in out) and not BAD.search(out)
    summ = re.search(r"TB_SUMMARY.*", out)
    cov = re.search(r"TB_COVER.*", out)
    core = [l for l in out.splitlines() if l.startswith("TB_") and not l.startswith("TB_INFO")]
    return dict(ok=ok, t=t, summary=summ.group(0) if summ else "", cover=cov.group(0) if cov else "",
                core=core, rc=rc)


def run_job(j, sims_allowed, quick):
    res = []
    vecs = {}
    for s in j["suites"]:
        rc, out, vec = gen(j, s)
        if rc != 0:
            res.append(dict(job=j["name"], sim="gen", suite=s, ok=False, detail=out[-500:]))
            return res
        vecs[s] = (vec, out)
    exes = {}
    for sim in j["sims"]:
        if sim not in sims_allowed:
            continue
        rc, out, t = build(j, sim)[:3]
        if rc != 0:
            res.append(dict(job=j["name"], sim=sim, suite="build", ok=False, detail=out[-800:]))
            continue
        exes[sim] = f"vvp -n build/{j['name']}/sim.vvp" if sim == "icarus" else f"build/{j['name']}/obj/vsim"
    profs = j["profs"][:2] if quick else j["profs"]
    seeds = j["seeds"][:1] if quick else j["seeds"]
    os.makedirs(os.path.join(ROOT, "logs/regress"), exist_ok=True)
    for s in j["suites"]:
        vec, ginfo = vecs[s]
        for prof in profs:
            for seed in seeds:
                cores = {}
                for sim, exe in exes.items():
                    lp = f"logs/regress/{j['name']}__{s}__{prof}__s{seed}__{sim}.log"
                    r = run_one(exe, j, vec, prof, seed, lp)
                    cores[sim] = r["core"]
                    res.append(dict(job=j["name"], stage=j["stage"], kind=j["kind"], sim=sim, suite=s, prof=prof,
                                    seed=seed, ok=r["ok"], t=round(r["t"], 2), summary=r["summary"],
                                    cover=r["cover"], gen=ginfo, log=lp))
                if len(cores) == 2:
                    same = cores["icarus"] == cores["verilator"]
                    res.append(dict(job=j["name"], stage=j["stage"], kind=j["kind"], sim="x-check", suite=s,
                                    prof=prof, seed=seed, ok=same,
                                    summary="Icarus and Verilator TB logs identical" if same else "LOGS DIFFER"))
    return res


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--stage1", action="store_true", help="run only stage 1")
    ap.add_argument("--quick", action="store_true")
    ap.add_argument("--skip-verilator", action="store_true")
    ap.add_argument("--only", default="")
    ap.add_argument("-j", type=int, default=os.cpu_count() or 4)
    ap.add_argument("--out", default="reports/regression_summary.md")
    a = ap.parse_args()
    sims = {"icarus"} if a.skip_verilator else {"icarus", "verilator"}
    t0 = time.time()
    results = []

    rc, out, _ = sh("python3 tests/test_ref_model.py")
    results.append(dict(job="model_selftest", sim="python", suite="-", ok=(rc == 0 and "RESULT: PASS" in out),
                        summary=out.strip().splitlines()[-2] if out.strip() else ""))
    print(results[-1]["summary"], "->", "PASS" if results[-1]["ok"] else "FAIL", flush=True)

    sel = [j for j in JOBS if (not a.only or j["name"] in a.only.split(","))]
    for stage in (1, 2):
        js = [j for j in sel if j["stage"] == stage]
        if a.stage1 and stage == 2:
            break
        with cf.ThreadPoolExecutor(max_workers=a.j) as ex:
            for r in ex.map(lambda j: run_job(j, sims, a.quick), js):
                results += r
                for x in r:
                    print(f"  [{'PASS' if x['ok'] else 'FAIL'}] stage{x.get('stage', '-')} {x['job']:<28} "
                          f"{x['sim']:<9} {x['suite']:<9} {x.get('prof', ''):<3} s{x.get('seed', '')} "
                          f"{x.get('summary', '')[:110]}", flush=True)
        failed = [x for x in results if not x["ok"]]
        if stage == 1:
            print(f"STAGE 1 (two K chunks): {'PASS' if not failed else 'FAIL'}", flush=True)
            if failed:
                break

    npass = sum(1 for x in results if x["ok"])
    nfail = len(results) - npass
    dur = time.time() - t0
    os.makedirs(os.path.join(ROOT, "reports"), exist_ok=True)
    jpath = "reports/regression.json" if a.out == "reports/regression_summary.md" else a.out.replace(".md", ".json")
    with open(os.path.join(ROOT, jpath), "w") as f:
        json.dump(dict(passed=npass, failed=nfail, seconds=round(dur, 1), results=results), f, indent=1)
    with open(os.path.join(ROOT, a.out), "w") as f:
        f.write("# TENSORCORE 04 regression summary\n\n")
        f.write(f"Generated by `tools/run_regress.py`; wall time {dur:.0f} s.\n\n")
        f.write(f"**{npass} passed, {nfail} failed** ({len(results)} checks: simulation runs, "
                f"cross-simulator log comparisons, model self-test).\n\n")
        f.write("A simulation run passes only with `TB_RESULT: PASS` and no `$error`/`%Error` line; "
                "an `x-check` row passes only if the Icarus and Verilator TB logs are identical.\n\n")
        f.write("| stage | job | sim | suite | profile | seed | result | summary |\n|---|---|---|---|---|---|---|---|\n")
        for x in results:
            f.write(f"| {x.get('stage', '-')} | {x['job']} | {x['sim']} | {x['suite']} | {x.get('prof', '')} | "
                    f"{x.get('seed', '')} | {'PASS' if x['ok'] else '**FAIL**'} | {x.get('summary', '')} |\n")
        f.write("\n## Coverage probes (one line per job/suite, profile with the most stress)\n\n")
        seen = set()
        for x in results:
            if x.get("cover") and (x["job"], x["suite"]) not in seen and x.get("prof") in ("P2", "Q2"):
                seen.add((x["job"], x["suite"]))
                f.write(f"* `{x['job']}` / {x['suite']}: {x['cover'].replace('TB_COVER ', '')}\n")
        f.write("\n## Vector generation\n\n")
        seen = set()
        for x in results:
            if x.get("gen") and x["gen"] not in seen:
                seen.add(x["gen"])
                f.write(f"* {x['gen']}\n")
    print(f"\nREGRESSION: {npass} passed, {nfail} failed, {dur:.0f} s -> {a.out}")
    return 0 if nfail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
