#!/usr/bin/env python3
"""
SilicaFlux TENSORCORE 04 -- independent reference model of the K-chunk
accumulator (Python arbitrary-precision integers; no fixed-width arithmetic
anywhere except where the hardware contract itself narrows a value).

Written from the behavioural contract in docs/ARCHITECTURE.md and
docs/NUMERIC_RANGE.md, not from the RTL.  Two layers:

  gemm_ref(A, B, bias)          exact C = bias + A @ B  (the mathematical answer)
  AccModel                      the accumulator's architectural behaviour:
                                tile slots, per-row chunk sequencing, duplicate
                                filtering, protocol checks, bias-once, overflow
                                policy, narrowing, host ops, deterministic perf
                                counters.

For in-range tiles the generators assert AccModel's committed value ==
gemm_ref, for every chunk partition, before any vector is written.
"""

SAT, WRAP = 0, 1

# slot states
FREE, ACCUM, COMMIT = 0, 1, 2
# host ops / status
HC_READ, HC_WRITE, HC_CLEAR, HC_ABORT = 0, 1, 2, 3
HS_OK, HS_ERR_SLOT, HS_ERR_ROW, HS_ERR_ORDER = 0, 1, 2, 3
# psum error codes
PE_NONE, PE_NO_TILE, PE_ROW, PE_MASK, PE_CHUNK_K, PE_ORDER, PE_K_OVERRUN, PE_RANGE = range(8)
# cfg reject codes
CR_OK, CR_SLOT, CR_DIM, CR_CHUNKS, CR_DEST, CR_RANGE = range(6)

# perf counter indices (docs/PERF_EVENTS.md)
PF = dict(PSUM_BEATS=0, PSUM_ELEMS=1, PSUM_DUP=2, PSUM_ERR=3, RD_STALL=4, WR_STALL=5,
          OVF_ACC=6, OVF_OUT=7, COMMIT_ELEMS=8, COMMIT_TILES=9, CHUNKS=10, IN_STALL=11,
          OUT_STALL=12, CFG_REJECT=13, HOST_OPS=14, BUSY=15)
NPERF = 16
# counters whose values are a pure function of the operation sequence
DETERMINISTIC = ["PSUM_BEATS", "PSUM_ELEMS", "PSUM_DUP", "PSUM_ERR", "OVF_ACC", "OVF_OUT",
                 "COMMIT_ELEMS", "COMMIT_TILES", "CHUNKS", "CFG_REJECT", "HOST_OPS"]


def smin(w):
    return -(1 << (w - 1))


def smax(w):
    return (1 << (w - 1)) - 1


def wrap(v, w):
    v &= (1 << w) - 1
    return v - (1 << w) if v >> (w - 1) else v


def prod_extremes(dw):
    """Most positive and most negative product of two signed dw-bit operands,
    found by evaluating the four corner products (not by formula)."""
    lo, hi = smin(dw), smax(dw)
    corners = [a * b for a in (lo, hi) for b in (lo, hi)]
    return max(corners), min(corners)


def max_exact_k(acc_w, dw, bias_hi=0, bias_lo=0):
    """Largest K for which bias + any K products stays inside signed acc_w,
    for every bias in [bias_lo, bias_hi].  Computed by integer division from
    the extremes, independently of the RTL's shift formula."""
    pmax, pmin = prod_extremes(dw)
    room_hi = smax(acc_w) - bias_hi
    room_lo = bias_lo - smin(acc_w)
    if room_hi < 0 or room_lo < 0:
        return 0
    return min(room_hi // pmax, room_lo // (-pmin))


def gemm_ref(A, B, bias=None):
    M, K = len(A), len(A[0]) if A else 0
    N = len(B[0]) if B else 0
    C = [[sum(A[m][k] * B[k][n] for k in range(K)) for n in range(N)] for m in range(M)]
    if bias is not None:
        C = [[C[m][n] + bias[n] for n in range(N)] for m in range(M)]
    return C


def chunk_psums(A, B, k0, k1):
    """Exact partial sums of the K slice [k0, k1)."""
    M, N = len(A), len(B[0])
    return [[sum(A[m][k] * B[k][n] for k in range(k0, k1)) for n in range(N)] for m in range(M)]


class Nondeterministic(Exception):
    """Raised when a generator asks for an operation whose outcome would
    depend on hardware timing (e.g. touching a tile while it commits)."""


class Params:
    def __init__(self, rows=4, cols=4, data_w=8, psum_w=32, acc_w=32, out_w=32, bias_w=32,
                 num_tiles=2, tag_w=16, chunk_w=16, kc_w=17, ktot_w=40, ovf_policy=SAT,
                 strict=1, guard=1):
        self.__dict__.update(locals())
        del self.__dict__["self"]
        self.psum_kmax = max_exact_k(psum_w, data_w)


class _Row:
    def __init__(self, cols):
        self.vld, self.nch, self.kacc = 0, 0, 0
        self.val = [0] * cols
        self.ovf = [0] * cols


class _Slot:
    def __init__(self, p):
        self.state = FREE
        self.tag = self.m = self.n = self.ktot = self.nchunks = self.dest = 0
        self.bias_en = 0
        self.bias = [0] * p.cols
        self.cdone = 0
        self.err = 0
        self.rows = [_Row(p.cols) for _ in range(p.rows)]


class AccModel:
    def __init__(self, p):
        self.p = p
        self.reset()

    # ------------------------------------------------------------ helpers
    def reset(self):
        self.slots = [_Slot(self.p) for _ in range(self.p.num_tiles)]
        self.perf = {k: 0 for k in PF}
        self.out = []          # committed beats, in per-tile row order
        self.err_sticky = 0

    def _add(self, base, pay):
        """One exact add with the selected overflow policy."""
        s = base + pay
        if smin(self.p.acc_w) <= s <= smax(self.p.acc_w):
            return s, 0
        if self.p.ovf_policy == SAT:
            return (smax(self.p.acc_w) if s > 0 else smin(self.p.acc_w)), 1
        return wrap(s, self.p.acc_w), 1

    def _narrow(self, v):
        if self.p.acc_w == self.p.out_w or smin(self.p.out_w) <= v <= smax(self.p.out_w):
            return v, 0
        if self.p.ovf_policy == SAT:
            return (smax(self.p.out_w) if v > 0 else smin(self.p.out_w)), 1
        return wrap(v, self.p.out_w), 1

    def barrier(self):
        """Hardware quiescent: every completed tile has been committed."""
        for s in self.slots:
            if s.state == COMMIT:
                s.state = FREE

    def take_perf(self):
        d = dict(self.perf)
        self.perf = {k: 0 for k in PF}
        return d

    # ------------------------------------------------------------ tile config
    def cfg(self, slot, tag, m, n, ktot, nchunks, bias_en, bias, dest):
        p = self.p
        if slot < p.num_tiles and self.slots[slot].state == COMMIT:
            self.slots[slot].state = FREE         # cfg_ready waits for the commit to drain
        if slot >= p.num_tiles:
            code = CR_SLOT
        elif self.slots[slot].state != FREE:
            raise Nondeterministic("cfg on an open slot would block forever")
        elif not (1 <= m <= p.rows and 1 <= n <= p.cols):
            code = CR_DIM
        elif nchunks == 0 or nchunks > ktot:
            code = CR_CHUNKS
        elif dest == 0:
            code = CR_DEST
        else:
            code = CR_OK
            if p.strict:
                b = [bias[j] if bias_en else 0 for j in range(n)]
                if ktot > max_exact_k(p.acc_w, p.data_w, max(b), min(b)):
                    code = CR_RANGE
        if code != CR_OK:
            self.perf["CFG_REJECT"] += 1
            return code
        s = self.slots[slot]
        s.state, s.tag, s.m, s.n, s.ktot, s.nchunks = ACCUM, tag, m, n, ktot, nchunks
        s.bias_en, s.bias, s.dest, s.cdone, s.err = bias_en, list(bias), dest, 0, 0
        s.rows = [_Row(p.cols) for _ in range(p.rows)]
        return CR_OK

    # ------------------------------------------------------------ partial sum
    def ps(self, slot, tag, chunk, chunk_k, row, last, cmask, data):
        """Returns ('apply'|'dup'|'err', code)."""
        p = self.p
        self.perf["PSUM_BEATS"] += 1
        if slot < p.num_tiles and self.slots[slot].state == COMMIT and tag == self.slots[slot].tag:
            # COMMIT (dup / order error) vs. already FREE (no tile) depends on timing
            raise Nondeterministic("psum to a committing tile")
        s = self.slots[slot] if slot < p.num_tiles else None
        code, dup = PE_NONE, False
        if s is None or s.state != ACCUM or tag != s.tag:
            code = PE_NO_TILE
        elif row >= s.m:
            code = PE_ROW
        elif cmask != (1 << s.n) - 1 or bool(last) != (row == s.m - 1):
            code = PE_MASK
        elif chunk_k == 0 or chunk_k > p.psum_kmax:
            code = PE_CHUNK_K
        else:
            r = s.rows[row]
            if chunk < r.nch:
                dup = True
            elif chunk != r.nch or chunk >= s.nchunks:
                code = PE_ORDER
            elif r.kacc + chunk_k > s.ktot or (chunk == s.nchunks - 1 and r.kacc + chunk_k != s.ktot):
                code = PE_K_OVERRUN
            elif p.guard:
                pmax, pmin = prod_extremes(p.data_w)
                for j in range(s.n):
                    if not (chunk_k * pmin <= data[j] <= chunk_k * pmax):
                        code = PE_RANGE
                        break
        if dup:
            self.perf["PSUM_DUP"] += 1
            return "dup", PE_NONE
        if code != PE_NONE:
            self.perf["PSUM_ERR"] += 1
            self.err_sticky |= 1 << code
            if code != PE_NO_TILE:
                s.err = 1
            return "err", code
        # ---- apply: exactly once
        r = s.rows[row]
        first = (r.nch == 0)
        for j in range(s.n):
            base_v, base_o = (r.val[j], r.ovf[j]) if r.vld else (0, 0)
            pay = data[j] + (s.bias[j] if (first and s.bias_en) else 0)
            v, o = self._add(base_v, pay)
            r.val[j], r.ovf[j] = v, base_o | o
            self.perf["OVF_ACC"] += o
        self.perf["PSUM_ELEMS"] += s.n
        old = r.nch
        r.vld, r.nch, r.kacc = 1, r.nch + 1, r.kacc + chunk_k
        if old == s.cdone and all(s.rows[q].nch > old for q in range(s.m) if q != row):
            s.cdone = old + 1
            self.perf["CHUNKS"] += 1
            if s.cdone == s.nchunks:
                self._commit(slot)
        return "apply", PE_NONE

    def _commit(self, slot):
        s = self.slots[slot]
        for m in range(s.m):
            r = s.rows[m]
            wide = [r.val[j] if j < s.n else 0 for j in range(self.p.cols)]
            ovf = [r.ovf[j] if j < s.n else 0 for j in range(self.p.cols)]
            data, clip = [], []
            for v in wide:
                d, c = self._narrow(v)
                data.append(d)
                clip.append(c)
            err = int(s.err or r.kacc != s.ktot)
            self.out.append(dict(tag=s.tag, slot=slot, row=m, last=int(m == s.m - 1), dest=s.dest,
                                 cmask=(1 << s.n) - 1, wide=wide, data=data, ovf=ovf, clip=clip,
                                 err=err))
            self.perf["COMMIT_ELEMS"] += s.n
            self.perf["OVF_OUT"] += sum(clip[:s.n])
        self.perf["COMMIT_TILES"] += 1
        s.state = COMMIT

    # ------------------------------------------------------------ host ops
    def hc(self, op, slot, row, wdata):
        p = self.p
        self.perf["HOST_OPS"] += 1
        if slot < p.num_tiles and self.slots[slot].state == COMMIT:
            raise Nondeterministic("host op on a committing tile")
        s = self.slots[slot] if slot < p.num_tiles else None
        zero = [0] * p.cols
        resp = dict(status=HS_OK, vld=0, nch=0, kacc=0, data=list(zero), ovf=list(zero))
        if op == HC_READ:
            ok_state = s is not None and s.state != FREE
        else:
            ok_state = s is not None and s.state == ACCUM
        if not ok_state:
            resp["status"] = HS_ERR_SLOT
            return resp
        if op != HC_ABORT and row >= s.m:
            resp["status"] = HS_ERR_ROW
            return resp
        if op == HC_ABORT:
            s.state = FREE
            return resp
        r = s.rows[row]
        if op == HC_WRITE and r.nch != 0:
            resp["status"] = HS_ERR_ORDER
            return resp
        resp.update(vld=r.vld, nch=r.nch, kacc=r.kacc)
        if op == HC_READ:
            if r.vld:
                resp["data"] = [r.val[j] if j < s.n else 0 for j in range(p.cols)]
                resp["ovf"] = [r.ovf[j] if j < s.n else 0 for j in range(p.cols)]
        elif op == HC_WRITE:
            vals = [wrap(wdata[j], p.acc_w) if j < s.n else 0 for j in range(p.cols)]
            r.vld, r.val, r.ovf = 1, vals, [0] * p.cols
            resp["data"] = list(vals)
        elif op == HC_CLEAR:
            s.rows[row] = _Row(p.cols)
            s.cdone = 0
        return resp
