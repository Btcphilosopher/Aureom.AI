# TENSORCORE 04 synthesis summary (Yosys 0.33)

Resource estimates only. `synth -flatten` (generic gates) and `synth_xilinx -family xc7` (LUT/FF/CARRY4/DSP mapping, **no place & route**). No timing or Fmax is claimed.

| configuration | flow | ok | cells | FF | LUT | CARRY4 | DSP48 | LUTRAM |
|---|---|---|---|---|---|---|---|---|
| 4x4_t2_acc32_rd1 | generic | yes | 25274 | 4766 |  |  |  |  |
| 4x4_t2_acc32_rd1 | xc7 | yes | 12113 | 2309 | 5650 | 516 | 0 | 81 |
| 4x4_t1_acc32_rd1_noperf | generic | yes | 17654 | 3179 |  |  |  |  |
| 4x4_t1_acc32_rd1_noperf | xc7 | yes | 8395 | 1247 | 3461 | 304 | 0 | 81 |
| 4x4_t4_acc40_rd2 | generic | yes | 37064 | 8283 |  |  |  |  |
| 4x4_t4_acc40_rd2 | xc7 | yes | 19017 | 3995 | 8582 | 551 | 0 | 99 |
| 8x8_t2_acc32_rd1 | generic | yes | 47516 | 10274 |  |  |  |  |
| 8x8_t2_acc32_rd1 | xc7 | yes | 19081 | 3573 | 9131 | 739 | 0 | 148 |
