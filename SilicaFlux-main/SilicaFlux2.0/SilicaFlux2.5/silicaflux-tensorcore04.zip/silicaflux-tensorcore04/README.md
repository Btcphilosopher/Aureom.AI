# SilicaFlux TENSORCORE 04: tensor partial-sum and accumulator engine

Aureom.AI | SilicaFlux-HPC. Primary source: **`rtl/tensor_accumulator.sv`**.

It accumulates `C[m,n] = bias[n] + Σ_k A[m,k]·B[k,n]` across **any number of K chunks** computed one
launch at a time on the TENSORCORE 02 systolic array. Partial sums are signed INT32 (from INT8 products).
The persistent accumulator is INT32 by default, or 40/48 bits for longer reductions. Raw exact INT32
output goes to output SRAM, the quantisation engine and/or the DMA path, selectable per tile.

> **Not committed to GitHub.** Delivered as a plain archive (no `.git`).
> **TENSORCORE 03 (operand buffers) does not exist in the repository.** The integration testbench models
> the K-chunk sequencer and operand buffers (`docs/AUDIT.md`).

## Headline behaviour

* **Each chunk is added exactly once.** The TC02 PEs restart from zero at every launch (verified on every
  readout beat). This module adds each row of each chunk once, gated by a per-row chunk sequence number.
  Replays (a chunk re-run after an array restart) are dropped. A skipped chunk is rejected, never added.
* **The first chunk initialises the accumulator directly** (base 0, no storage read, no clear pass).
  **Bias is added once per element, with the first chunk**, never per chunk.
* **No early commit.** A tile commits only when every active row has applied all `n_chunks` chunks and
  exactly `k_total` K-steps.
* **No silent wrap.** A tile is rejected at configuration if its K (+bias) could overflow ACC_W
  (131 071 worst-case INT8 products at 32 bits, the brief's bound). Every add is exact with sticky
  per-lane overflow flags and events. SATURATE is the default; WRAP must be selected explicitly. The INT32
  narrowing of wider accumulators carries a per-lane clip flag.
* **Hazards handled in hardware:** a forwarding network sized to the storage read latency (back-to-back
  adds to one element at full rate), credit-reserved output/host FIFOs (no pipeline stall on output
  backpressure), freeze on storage write-port contention, bubbles on read-port contention, any
  interleaving of up to `NUM_TILES` tiles, and reset at any point.

## Results (final run on these sources)

See `docs/VERIFICATION.md` and `reports/`.

* **Stage 1 (two K chunks) passes first**, as required: unit + real-array integration, 4×4, Icarus and
  Verilator, all timing profiles, with cross-simulator logs identical.
* **Regression: 1 160 / 1 160 checks pass** (605 Icarus runs, 302 Verilator runs, 252 cross-simulator
  log comparisons, all identical, and the model self-test). It covers 26 configuration jobs: 1×1 … 16×16,
  1–4 tile slots, RD_LAT 1–3, ACC 32/40/48, saturate/wrap, strict/non-strict, and TC02 with
  `MUL_PIPE` 0/1. That is 357 k unit partial-sum beats and 17 443 real-array chunk launches, with every
  one of the 53 271 array readout beats checked equal to its chunk-local partial sum.
* **Definition of done:** on the real TC02 array, one 257-term reduction under six partitions (1 to 257
  chunks), and K = 131 071 worst-case products split two ways, give exactly the independent Python
  result, including INT32_MAX and INT32_MIN exactly at the boundary.
* **Throughput:** 1 partial-sum beat per cycle, including 1 000 back-to-back adds to one element, at
  RD_LAT 1, 2 and 3.
* **Mutation testing: 40 of 41 injected bugs killed** by the testbench alone (RTL invariants compiled
  out). The survivor is an equivalent mutant. The first run exposed two real test gaps, now closed
  (`docs/VERIFICATION.md` §6).
* Lint clean (`verilator -Wall`, 8 parameter sets). Yosys maps every configuration (baseline 4×4, 2 slots
  on xc7: ≈5.7 k LUT, 2.3 k FF, 0 DSP). These are **resource estimates only; no timing/Fmax claim**.

## Layout

| path | contents |
|---|---|
| `rtl/tensor_accumulator.sv` | **primary source**: chunk protocol, metadata, RMW pipeline, forwarding, commit engine, output, host ops, perf |
| `rtl/tensor_acc_storage.sv` | reference implementation of the **accumulator storage interface** (1R1W, RD_LAT 1–3, port contention) |
| `rtl/tensor_acc_out_router.sv` | eager fork to output SRAM / quantiser / DMA |
| `rtl/tensor_acc_subsystem.sv` | integration wrapper (accumulator + storage + router) |
| `rtl/tensor_acc_fifo.sv`, `rtl/tensor_acc_pkg.sv` | FIFO; encodings, perf indices, `max_exact_k` |
| `model/acc_ref.py` | independent exact Python-integer reference (GEMM + architectural model) |
| `tests/test_ref_model.py` | K-bound brute force, formula cross-check, partition invariance |
| `tb/tb_acc.sv` | unit TB (vector-driven, random backpressure/contention, full scoreboard, perf checks) |
| `tb/tb_integ.sv` | integration TB: unmodified TC02 array → accumulator, real K-chunk launches |
| `tools/gen_unit.py`, `tools/gen_integ.py` | K-chunk test generators (expected values from the model) |
| `tools/run_regress.py`, `tools/mutation_test.py`, `synth/run_synth.py` | regression, mutation, synthesis |
| `docs/` | `AUDIT`, `ARCHITECTURE`, `STORAGE_INTERFACE`, `NUMERIC_RANGE`, `PERF_EVENTS`, `VERIFICATION` |
| `third_party/tensorcore02/` | TC02 array RTL, unmodified, with hashes |
| `reports/`, `logs/` | results of the final runs |

## Quick start

```
make model      # reference-model self-tests (seconds)
make smoke      # two-chunk unit + real-array test, Icarus (seconds)
make lint
make stage1     # START: two K chunks, both simulators
make regress    # stage 1, then the full matrix
make mutation
make perf       # throughput at RD_LAT 1/2/3
make synth
```

Every vector is regenerated deterministically by the generators (seeded), so `vectors/` and `build/`
are not shipped.

## Integration in one paragraph

Wire the TC02 array's readout to `ps_*` (`m_valid→ps_valid`, `ps_ready→m_ready`, and `m_row, m_data,
m_col_mask, m_last`). Open a tile with `cfg_*` (`k_total`, `n_chunks`, bias, destinations). Launch the
array once per chunk with `cfg_k = chunk_k`, holding `ps_slot/ps_tag/ps_chunk/ps_chunk_k` for that
launch. If a launch is interrupted, simply re-run it: rows already accepted are recognised and dropped.
Results arrive on `osram_* / oquant_* / odma_*` (shared payload: `o_wide` exact, `o_data` INT32,
`o_ovf`, `o_clip`, `o_err`), and `cmt_done` marks a finished tile.

## Honest caveats

Simulation-only verification: no formal proof, no gate-level simulation, no silicon or FPGA run. The
storage model is generic (no SRAM macro). No adapter to the HPC scratchpad/DMA modules is included. The
K-chunk sequencer and operand buffers are testbench models, because TC03 does not exist. The TC02 PE
itself wraps silently; this module protects against that only by refusing chunks longer than 131 071.
