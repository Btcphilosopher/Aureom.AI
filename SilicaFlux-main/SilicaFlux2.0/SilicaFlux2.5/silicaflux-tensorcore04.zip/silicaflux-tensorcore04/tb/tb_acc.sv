// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tb_acc.sv
//  Self-checking unit testbench for tensor_acc_subsystem.  Runs unchanged on
//  Icarus Verilog 12 and Verilator 5 (--timing).
//
//  Stimulus and EXPECTED results come from tools/gen_unit.py, which computes
//  them with the independent Python-integer model (model/acc_ref.py).  The TB
//  only adds TIMING: independent random gaps on the psum and host streams,
//  random ready on every output port and on the host response, and random
//  storage read/write port contention.
//
//  +VEC=<file>  vector file      +SEED=<n>     timing seed
//  +PSGAP=<%>   psum idle prob.  +HCGAP=<%>    host idle prob.
//  +ORDY=<%>    output ready     +HRRDY=<%>    host-response ready
//  +RDBLK=<%>   read-port busy   +WRBLK=<%>    write-port busy
//  +WAVE=<file> VCD dump         +VERBOSE      print every output beat
//
//  CHECKS
//   * every committed beat, on every destination port: tag, slot, row, last,
//     col mask, exact o_wide, o_data, o_ovf, o_clip, o_err  vs. the model
//   * each expected beat delivered exactly once per selected port, none extra,
//     rows of a tile in order and contiguous, payload stable under backpressure
//   * cmt_done once per tile, after its last row, with the OR of ovf/clip/err
//   * cfg accept/reject code, psum apply/dup/error code (err_pulse/err_code)
//   * every host response (status, data, ovf, metadata), in order
//   * at every barrier: all non-optional beats seen; deterministic perf
//     counters == model; wr-stall / in-stall / out-stall counters == TB's own
//     observation; rd-stall counter within TB-observed bounds; err_sticky
//   * no deadlock (watchdog), no X on outputs, perf_clr clears every counter
// =============================================================================
`timescale 1ns/1ps
module tb_acc #(
    parameter int ROWS       = 4,
    parameter int COLS       = 4,
    parameter int NUM_TILES  = 2,
    parameter int ACC_W      = 32,
    parameter int OUT_W      = 32,
    parameter int RD_LAT     = 1,
    parameter int OVF_POLICY = 0,
    parameter int STRICT     = 1,
    parameter int GUARD      = 1,
    parameter int OFIFO      = 4,
    parameter int HFIFO      = 4,
    parameter int PERF_W     = 40,
    parameter int MEMW       = 1 << 22,
    parameter int MAXREC     = 1 << 19,
    parameter int MAXEXP     = 1 << 17
);
    localparam int PSUM_W = 32, BIAS_W = 32, TAG_W = 16, CHUNK_W = 16, KC_W = 17, KTOT_W = 40;
    localparam int SLOT_W = (NUM_TILES > 1) ? $clog2(NUM_TILES) : 1;
    localparam int RIDW   = (ROWS > 1) ? $clog2(ROWS) : 1;
    localparam int MW     = $clog2(ROWS + 1);
    localparam int NW     = $clog2(COLS + 1);
    localparam int EVW    = $clog2(COLS + 1);
    localparam int NPERF  = 16;
    localparam logic [63:0] PMAX = (PERF_W >= 64) ? {64{1'b1}} : ((64'd1 << PERF_W) - 64'd1);

    localparam int T_CFG = 1, T_PS = 2, T_HC = 3, T_BAR = 4, T_RST = 5, T_EXP = 6, T_END = 15;

    // ---------------------------------------------------------------- clock
    logic clk = 1'b0;
    always #5 clk = ~clk;
    logic rst_n = 1'b0;

    // ---------------------------------------------------------------- DUT I/O
    logic                   cfg_valid = 1'b0, cfg_ready;
    logic [SLOT_W-1:0]      cfg_slot = '0;
    logic [TAG_W-1:0]       cfg_tag = '0;
    logic [MW-1:0]          cfg_m = '0;
    logic [NW-1:0]          cfg_n = '0;
    logic [KTOT_W-1:0]      cfg_k_total = '0;
    logic [CHUNK_W-1:0]     cfg_n_chunks = '0;
    logic                   cfg_bias_en = 1'b0;
    logic [COLS*BIAS_W-1:0] cfg_bias = '0;
    logic [2:0]             cfg_dest = '0;
    logic                   cfg_reject;
    logic [2:0]             cfg_reject_code;

    logic                   ps_valid = 1'b0, ps_ready;
    logic [SLOT_W-1:0]      ps_slot = '0;
    logic [TAG_W-1:0]       ps_tag = '0;
    logic [CHUNK_W-1:0]     ps_chunk = '0;
    logic [KC_W-1:0]        ps_chunk_k = '0;
    logic [RIDW-1:0]        ps_row = '0;
    logic [COLS*PSUM_W-1:0] ps_data = '0;
    logic [COLS-1:0]        ps_col_mask = '0;
    logic                   ps_last = 1'b0;

    logic                   hc_valid = 1'b0, hc_ready;
    logic [1:0]             hc_op = '0;
    logic [SLOT_W-1:0]      hc_slot = '0;
    logic [RIDW-1:0]        hc_row = '0;
    logic [COLS*ACC_W-1:0]  hc_wdata = '0;
    logic                   hr_valid, hr_ready = 1'b0;
    logic [2:0]             hr_status;
    logic [COLS*ACC_W-1:0]  hr_data;
    logic [COLS-1:0]        hr_ovf;
    logic                   hr_vld;
    logic [CHUNK_W-1:0]     hr_nchunk;
    logic [KTOT_W-1:0]      hr_kacc;

    logic                   st_rd_block = 1'b0, st_wr_block = 1'b0;
    logic [2:0]             o_vld;
    logic [2:0]             o_rdy = '0;
    logic [TAG_W-1:0]       o_tag;
    logic [SLOT_W-1:0]      o_slot;
    logic [RIDW-1:0]        o_row;
    logic                   o_last;
    logic [COLS-1:0]        o_col_mask, o_ovf, o_clip;
    logic [COLS*ACC_W-1:0]  o_wide;
    logic [COLS*OUT_W-1:0]  o_data;
    logic                   o_err;
    logic                   cmt_done, cmt_ovf, cmt_clip, cmt_err;
    logic [SLOT_W-1:0]      cmt_slot;
    logic [TAG_W-1:0]       cmt_tag;
    logic [NUM_TILES*2-1:0] slot_state;
    logic                   idle, err_pulse;
    logic [2:0]             err_code;
    logic [7:0]             err_sticky;
    logic                   perf_clr = 1'b0;
    logic [NPERF*EVW-1:0]   ev_inc;
    logic [NPERF*PERF_W-1:0] perf_o;
    logic                   st_en, st_rd_req, st_rd_ready, st_wr_req, st_wr_ready;

    tensor_acc_subsystem #(
        .ROWS(ROWS), .COLS(COLS), .ACC_W(ACC_W), .OUT_W(OUT_W), .NUM_TILES(NUM_TILES),
        .RD_LAT(RD_LAT), .OVF_POLICY(OVF_POLICY), .STRICT_RANGE(STRICT), .PSUM_GUARD(GUARD),
        .OFIFO_DEPTH(OFIFO), .HFIFO_DEPTH(HFIFO), .PERF_W(PERF_W)
    ) dut (
        .clk, .rst_n,
        .cfg_valid, .cfg_ready, .cfg_slot, .cfg_tag, .cfg_m, .cfg_n, .cfg_k_total,
        .cfg_n_chunks, .cfg_bias_en, .cfg_bias, .cfg_dest, .cfg_reject, .cfg_reject_code,
        .ps_valid, .ps_ready, .ps_slot, .ps_tag, .ps_chunk, .ps_chunk_k, .ps_row, .ps_data,
        .ps_col_mask, .ps_last,
        .hc_valid, .hc_ready, .hc_op, .hc_slot, .hc_row, .hc_wdata,
        .hr_valid, .hr_ready, .hr_status, .hr_data, .hr_ovf, .hr_vld, .hr_nchunk, .hr_kacc,
        .st_rd_block, .st_wr_block,
        .osram_valid(o_vld[0]), .osram_ready(o_rdy[0]),
        .oquant_valid(o_vld[1]), .oquant_ready(o_rdy[1]),
        .odma_valid(o_vld[2]), .odma_ready(o_rdy[2]),
        .o_tag, .o_slot, .o_row, .o_last, .o_col_mask, .o_wide, .o_data, .o_ovf, .o_clip, .o_err,
        .cmt_done, .cmt_slot, .cmt_tag, .cmt_ovf, .cmt_clip, .cmt_err,
        .slot_state, .idle, .err_pulse, .err_code, .err_sticky,
        .perf_clr, .ev_inc, .perf_o,
        .st_en, .st_rd_req, .st_rd_ready, .st_wr_req, .st_wr_ready
    );

    // ---------------------------------------------------------------- vectors
    logic [31:0] vec [0:MEMW-1];
    int ps_list [0:MAXREC-1];
    int hc_list [0:MAXREC-1];
    int exp_at  [0:MAXEXP-1];
    int exp_seg [0:MAXEXP-1];
    logic [2:0] exp_seen [0:MAXEXP-1];
    int tag_base [0:(1<<TAG_W)-1];
    logic tile_cmt [0:(1<<TAG_W)-1];
    int n_ps = 0, n_hc = 0, n_exp = 0;

    int errors = 0, n_beats = 0, n_tiles_done = 0, n_resp = 0, n_cfg = 0, n_psr = 0;
    int cyc = 0;
    int last_progress = 0;
    logic verbose = 1'b0;

    // random knobs
    int seed = 1, psgap = 0, hcgap = 0, ordy = 100, hrrdy = 100, rdblk = 0, wrblk = 0;

    function automatic logic [31:0] xs(input logic [31:0] s);
        logic [31:0] x;
        x = s;
        x = x ^ (x << 13);
        x = x ^ (x >> 17);
        x = x ^ (x << 5);
        xs = x;
    endfunction

    function automatic logic [63:0] w64(input int at);
        w64 = {vec[at+1], vec[at]};
    endfunction

    task automatic fail(input string msg);
        errors = errors + 1;
        if (errors > 200) begin           // a broken design can keep producing beats forever
            $display("TB_ERROR: more than 200 errors, stopping");
            $display("TB_SUMMARY cfg=%0d psum=%0d host_resp=%0d beats=%0d tiles=%0d cycles=%0d errors=%0d",
                     n_cfg, n_psr, n_resp, n_beats, n_tiles_done, cyc, errors);
            $display("TB_RESULT: FAIL");
            $finish;
        end
        if (errors <= 40) $display("TB_ERROR t=%0d cyc=%0d: %s", $time, cyc, msg);
    endtask

    // ---------------------------------------------------------------- cycle counter
    always @(posedge clk) cyc <= cyc + 1;

    // ---------------------------------------------------------------- random environment
    logic [31:0] env_rs = 32'h1234_5678;
    always @(posedge clk) begin
        logic [31:0] r;
        r = xs(env_rs);
        env_rs <= xs(r);
        st_rd_block <= ((r % 100) < 32'(rdblk));
        st_wr_block <= (((r >> 8) % 100) < 32'(wrblk));
        o_rdy[0] <= (((r >> 3) % 100) < 32'(ordy));
        o_rdy[1] <= (((r >> 11) % 100) < 32'(ordy));
        o_rdy[2] <= (((r >> 19) % 100) < 32'(ordy));
        hr_ready <= (((r >> 5) % 100) < 32'(hrrdy));
    end

    // ---------------------------------------------------------------- edge sampler (race-free)
    //  Driver threads never read DUT outputs AT a clock edge (Verilator may resume
    //  a suspended thread after the edge's non-blocking updates, Icarus before).
    //  This block latches the handshakes with non-blocking assignments (pre-edge
    //  values in both simulators); threads wait  @(posedge clk); #1  (tick) and
    //  read the latched flags: "did a handshake happen at the edge just passed?".
    logic ps_done = 1'b0, hc_done = 1'b0;
    logic smp_cfg_hs = 1'b0, smp_ps_hs = 1'b0, smp_hc_hs = 1'b0, smp_done = 1'b0;
    always @(posedge clk) begin
        smp_cfg_hs <= cfg_valid & cfg_ready;
        smp_ps_hs  <= ps_valid & ps_ready;
        smp_hc_hs  <= hc_valid & hc_ready;
        smp_done   <= ps_done & hc_done;
    end

    task automatic tick();
        @(posedge clk);
        #1;
    endtask

    // ---------------------------------------------------------------- barrier state
    int  ps_bar = -1, hc_bar = -1, bar_rel = -1;
    logic in_reset = 1'b0;

    // TB-observed counters (since last reset), and model-expected absolute counts
    logic [63:0] obs_in_stall = 0, obs_out_stall = 0, obs_wr_stall = 0, obs_rd_lo = 0, obs_rd_hi = 0;
    logic [63:0] exp_abs [0:NPERF-1];
    initial for (int i = 0; i < NPERF; i++) exp_abs[i] = 0;

    always @(posedge clk) begin
        if (rst_n === 1'b1 && !perf_clr) begin
            if (ps_valid && !ps_ready) obs_in_stall <= obs_in_stall + 1;
            if (dut.u_acc.o_valid && !dut.u_acc.o_ready) obs_out_stall <= obs_out_stall + 1;
            if (st_wr_req && !st_wr_ready) obs_wr_stall <= obs_wr_stall + 1;
            if (!(st_wr_req && !st_wr_ready) && !st_rd_ready) begin
                obs_rd_hi <= obs_rd_hi + 1;
                if (ps_valid) obs_rd_lo <= obs_rd_lo + 1;
            end
        end
    end

    // ---------------------------------------------------------------- expected error / reject pulses
    //  A handshake at the edge where cyc == c is checked at the edge where
    //  cyc == c+1 (the pulses are registered).  The driver, running 1 time unit
    //  after edge c (cyc already c+1), parks the expectation in slot (c+1)&1;
    //  the checker reads and clears slot cyc&1 at each edge.
    logic       xe_v [0:1];
    logic [1:0] xe_kind [0:1];
    logic [2:0] xe_code [0:1];
    int         xe_rec [0:1];
    logic       xr_v [0:1];
    logic [2:0] xr_code [0:1];
    int         xr_rec [0:1];
    initial begin
        xe_v[0] = 0; xe_v[1] = 0; xr_v[0] = 0; xr_v[1] = 0;
    end

    always @(posedge clk) begin
        int sl;
        sl = cyc & 1;
        if (rst_n === 1'b1) begin
            if (xe_v[sl]) begin
                if (err_pulse !== (xe_kind[sl] == 2) || (xe_kind[sl] == 2 && err_code !== xe_code[sl]))
                    fail($sformatf("psum record @%0d: err_pulse=%b code=%0d, expected kind=%0d code=%0d",
                                   xe_rec[sl], err_pulse, err_code, xe_kind[sl], xe_code[sl]));
            end else if (err_pulse === 1'b1) begin
                fail("unexpected err_pulse");
            end
            if (xr_v[sl]) begin
                if (cfg_reject !== (xr_code[sl] != 0) || cfg_reject_code !== xr_code[sl])
                    fail($sformatf("cfg record @%0d: reject=%b code=%0d, expected code=%0d",
                                   xr_rec[sl], cfg_reject, cfg_reject_code, xr_code[sl]));
            end else if (cfg_reject === 1'b1) begin
                fail("unexpected cfg_reject");
            end
        end
        xe_v[sl] = 1'b0;
        xr_v[sl] = 1'b0;
    end

    // host response expectation queue (written by the host driver)
    int resp_q [0:MAXREC-1];
    int resp_wr = 0, resp_rd = 0;

    // ---------------------------------------------------------------- psum / cfg / reset driver
    logic [31:0] ps_rs;

    task automatic ps_gap();
        logic [31:0] r;
        r = xs(ps_rs);
        ps_rs = r;
        while ((r % 100) < 32'(psgap)) begin
            tick();
            r = xs(ps_rs);
            ps_rs = r;
        end
    endtask

    //  Barrier: both driver threads post the segment number (at +1 after an
    //  edge); a single clocked controller sees both, waits until the DUT is idle
    //  and every host response is collected for 3 consecutive edges, runs the
    //  checks, and releases the barrier with a non-blocking update.  Threads
    //  only ever read bar_rel after a tick, so the hand-over is race-free and
    //  identical in Icarus and Verilator.
    int ps_bar_at = 0;
    int bar_quiet = 0, bar_wait = 0;

    task automatic do_barrier(input int at, input logic is_ps);
        int seg;
        seg = int'(vec[at+1]);
        if (is_ps) begin
            ps_bar_at = at;
            ps_bar    = seg;
        end else begin
            hc_bar    = seg;
        end
        while (bar_rel != seg) tick();
    endtask

    always @(posedge clk) begin : barrier_ctl
        if (ps_bar >= 0 && ps_bar == hc_bar && bar_rel != ps_bar) begin
            bar_wait <= bar_wait + 1;
            if (bar_wait > 2000000) begin
                fail($sformatf("barrier %0d: DUT never became idle", ps_bar));
                $display("TB_RESULT: FAIL");
                $finish;
            end
            if (idle === 1'b1 && hr_valid === 1'b0 && resp_wr == resp_rd) begin
                if (bar_quiet == 3) begin
                    check_barrier(ps_bar_at, ps_bar, int'(vec[ps_bar_at+2]));
                    bar_rel       <= ps_bar;
                    bar_quiet     <= 0;
                    bar_wait      <= 0;
                    last_progress  = cyc;
                end else begin
                    bar_quiet <= bar_quiet + 1;
                end
            end else begin
                bar_quiet <= 0;
            end
        end
    end

    function automatic logic is_det(input int q);
        // counters that are a pure function of the operation sequence
        is_det = (q == 0) || (q == 1) || (q == 2) || (q == 3) || (q == 6) || (q == 7) ||
                 (q == 8) || (q == 9) || (q == 10) || (q == 13) || (q == 14);
    endfunction

    task automatic check_barrier(input int at, input int seg, input int flags);
        logic [63:0] got, e;
        int nmiss;
        // deterministic counter deltas accumulate into the absolute expectation
        for (int i = 0; i < NPERF; i++) exp_abs[i] = exp_abs[i] + w64(at + 4 + 2*i);
        nmiss = 0;
        for (int x = 0; x < n_exp; x++) begin
            if (exp_seg[x] <= seg && vec[exp_at[x] + 7] == 0 &&
                exp_seen[x] != vec[exp_at[x] + 5][2:0]) begin
                nmiss = nmiss + 1;
                if (nmiss <= 5)
                    fail($sformatf("barrier %0d: expected beat tag=%0d row=%0d seen=%b dest=%b", seg,
                                   vec[exp_at[x] + 1], vec[exp_at[x] + 3], exp_seen[x], vec[exp_at[x] + 5][2:0]));
            end
        end
        if (flags[0]) begin
            for (int q = 0; q < NPERF; q++) begin
                if (is_det(q)) begin
                    got = 64'(perf_o[q*PERF_W +: PERF_W]);
                    e   = (exp_abs[q] > PMAX) ? PMAX : exp_abs[q];
                    if (got !== e) fail($sformatf("barrier %0d: perf[%0d] = %0d, model expects %0d", seg, q, got, e));
                end
            end
            got = 64'(perf_o[5*PERF_W +: PERF_W]);
            e = (obs_wr_stall > PMAX) ? PMAX : obs_wr_stall;
            if (got !== e) fail($sformatf("barrier %0d: wr_stall %0d vs observed %0d", seg, got, e));
            got = 64'(perf_o[11*PERF_W +: PERF_W]);
            e = (obs_in_stall > PMAX) ? PMAX : obs_in_stall;
            if (got !== e) fail($sformatf("barrier %0d: in_stall %0d vs observed %0d", seg, got, e));
            got = 64'(perf_o[12*PERF_W +: PERF_W]);
            e = (obs_out_stall > PMAX) ? PMAX : obs_out_stall;
            if (got !== e) fail($sformatf("barrier %0d: out_stall %0d vs observed %0d", seg, got, e));
            got = 64'(perf_o[4*PERF_W +: PERF_W]);
            if (got < ((obs_rd_lo > PMAX) ? PMAX : obs_rd_lo) || got > ((obs_rd_hi > PMAX) ? PMAX : obs_rd_hi))
                fail($sformatf("barrier %0d: rd_stall %0d outside observed [%0d,%0d]", seg, got, obs_rd_lo, obs_rd_hi));
            if (err_sticky !== vec[at+3][7:0])
                fail($sformatf("barrier %0d: err_sticky %b, model %b", seg, err_sticky, vec[at+3][7:0]));
        end
    endtask

    task automatic do_reset(input int max_delay, input int hold);
        logic [31:0] r;
        r = xs(ps_rs);
        ps_rs = r;
        repeat (int'(r % 32'(max_delay + 1))) tick();
        in_reset = 1'b1;
        rst_n <= 1'b0;
        repeat (hold) tick();
        rst_n <= 1'b1;
        tick();
        obs_in_stall = 0; obs_out_stall = 0; obs_wr_stall = 0; obs_rd_lo = 0; obs_rd_hi = 0;
        for (int i = 0; i < NPERF; i++) exp_abs[i] = 0;
        in_reset = 1'b0;
    endtask

    initial begin : ps_driver
        int at, typ;
        ps_rs = 32'h9E37_79B9;
        while (ps_bar != -2) tick();   // released by main after load
        ps_rs = xs(32'(seed) ^ 32'hA5A5_0001);
        for (int i = 0; i < n_ps; i++) begin
            at  = ps_list[i];
            typ = int'(vec[at][31:24]);
            if (typ == T_CFG) begin
                ps_gap();
                cfg_slot     <= SLOT_W'(vec[at+1]);
                cfg_tag      <= TAG_W'(vec[at+2]);
                cfg_m        <= MW'(vec[at+3]);
                cfg_n        <= NW'(vec[at+4]);
                cfg_k_total  <= KTOT_W'(w64(at+5));
                cfg_n_chunks <= CHUNK_W'(vec[at+7]);
                cfg_bias_en  <= vec[at+8][0];
                cfg_dest     <= vec[at+9][2:0];
                for (int j = 0; j < COLS; j++) cfg_bias[j*BIAS_W +: BIAS_W] <= vec[at+11+j];
                cfg_valid    <= 1'b1;
                tick();
                while (!smp_cfg_hs) tick();
                cfg_valid    <= 1'b0;
                xr_code[cyc & 1] = vec[at+10][2:0];
                xr_rec [cyc & 1] = at;
                xr_v   [cyc & 1] = 1'b1;
                n_cfg = n_cfg + 1;
                last_progress = cyc;
            end else if (typ == T_PS) begin
                ps_gap();
                ps_slot     <= SLOT_W'(vec[at+1]);
                ps_tag      <= TAG_W'(vec[at+2]);
                ps_chunk    <= CHUNK_W'(vec[at+3]);
                ps_chunk_k  <= KC_W'(vec[at+4]);
                ps_row      <= RIDW'(vec[at+5]);
                ps_last     <= vec[at+6][0];
                ps_col_mask <= COLS'(w64(at+7));
                for (int j = 0; j < COLS; j++) ps_data[j*PSUM_W +: PSUM_W] <= PSUM_W'(w64(at+11+2*j));
                ps_valid    <= 1'b1;
                tick();
                while (!smp_ps_hs) tick();
                ps_valid     <= 1'b0;
                xe_kind[cyc & 1] = vec[at+9][1:0];
                xe_code[cyc & 1] = vec[at+10][2:0];
                xe_rec [cyc & 1] = at;
                xe_v   [cyc & 1] = 1'b1;
                n_psr = n_psr + 1;
                last_progress = cyc;
            end else if (typ == T_RST) begin
                tick();
                do_reset(int'(vec[at+1]), int'(vec[at+2]));
            end else if (typ == T_BAR) begin
                tick();
                do_barrier(at, 1'b1);
            end
        end
        ps_done = 1'b1;
    end

    // ---------------------------------------------------------------- host driver + response checker
    logic [31:0] hc_rs;

    initial begin : hc_driver
        int at, typ;
        logic [31:0] r;
        while (ps_bar != -2) tick();
        hc_rs = xs(32'(seed) ^ 32'h5A5A_0002);
        for (int i = 0; i < n_hc; i++) begin
            at  = hc_list[i];
            typ = int'(vec[at][31:24]);
            if (typ == T_HC) begin
                r = xs(hc_rs);
                hc_rs = r;
                while ((r % 100) < 32'(hcgap)) begin
                    tick();
                    r = xs(hc_rs);
                    hc_rs = r;
                end
                hc_op    <= vec[at+1][1:0];
                hc_slot  <= SLOT_W'(vec[at+2]);
                hc_row   <= RIDW'(vec[at+3]);
                for (int j = 0; j < COLS; j++) hc_wdata[j*ACC_W +: ACC_W] <= ACC_W'(w64(at+4+2*j));
                hc_valid <= 1'b1;
                tick();
                while (!smp_hc_hs) tick();
                hc_valid <= 1'b0;
                resp_q[resp_wr] = at;
                resp_wr = resp_wr + 1;
                last_progress = cyc;
            end else if (typ == T_BAR) begin
                tick();
                do_barrier(at, 1'b0);
            end
        end
        hc_done = 1'b1;
    end

    always @(posedge clk) begin
        if (rst_n === 1'b1 && hr_valid === 1'b1 && hr_ready === 1'b1) begin
            int at, b;
            if (resp_rd >= resp_wr) begin
                fail("host response without a request");
            end else begin
                at = resp_q[resp_rd];
                b  = at + 4 + 2*COLS;
                if (hr_status !== vec[b][2:0] || hr_vld !== vec[b+1][0] ||
                    hr_nchunk !== CHUNK_W'(vec[b+2]) || hr_kacc !== KTOT_W'(w64(b+3)) ||
                    hr_ovf !== COLS'(w64(b+5)))
                    fail($sformatf("host resp @%0d: st=%0d vld=%b nch=%0d kacc=%0d ovf=%b exp st=%0d vld=%0d nch=%0d kacc=%0d",
                                   at, hr_status, hr_vld, hr_nchunk, hr_kacc, hr_ovf,
                                   vec[b], vec[b+1], vec[b+2], w64(b+3)));
                for (int j = 0; j < COLS; j++)
                    if (hr_data[j*ACC_W +: ACC_W] !== ACC_W'(w64(b+7+2*j)))
                        fail($sformatf("host resp @%0d lane %0d: %0d exp %0d", at, j,
                                       $signed(hr_data[j*ACC_W +: ACC_W]), $signed(ACC_W'(w64(b+7+2*j)))));
                resp_rd <= resp_rd + 1;
                n_resp = n_resp + 1;
            end
        end
    end

    // ---------------------------------------------------------------- output scoreboard
    logic [2:0]  prev_pending = '0;
    logic [TAG_W-1:0] prev_tag [0:2];
    logic [RIDW-1:0]  prev_row [0:2];
    logic [TAG_W+RIDW+COLS*ACC_W+COLS*OUT_W+3*COLS+2-1:0] prev_pay, cur_pay;
    logic [TAG_W-1:0] last_tag_p [0:2];
    int               last_row_p [0:2];
    initial for (int q = 0; q < 3; q++) last_row_p[q] = -1;

    assign cur_pay = {o_tag, o_row, o_wide, o_data, o_col_mask, o_ovf, o_clip, o_err, o_last};

    always @(posedge clk) begin
        if (rst_n !== 1'b1) begin
            prev_pending <= '0;
            for (int q = 0; q < 3; q++) last_row_p[q] <= -1;
        end else begin
            // payload stability under backpressure
            for (int q = 0; q < 3; q++) begin
                if (prev_pending[q] && !(o_vld[q] === 1'b1 && cur_pay === prev_pay))
                    fail($sformatf("port %0d: beat withdrawn or changed under backpressure", q));
            end
            prev_pending <= o_vld & ~o_rdy;
            prev_pay     <= cur_pay;
            for (int q = 0; q < 3; q++) begin
                if (o_vld[q] === 1'b1 && o_rdy[q] === 1'b1) check_beat(q);
            end
        end
    end

    task automatic check_beat(input int q);
        int x, a;
        logic ok;
        logic [63:0] ew, ed;
        ok = 1'b1;
        x = 0;
        if (^{o_tag, o_row, o_wide, o_data, o_col_mask, o_ovf, o_clip, o_err, o_last} === 1'bx) begin
            fail($sformatf("port %0d: X on output payload", q));
            ok = 1'b0;
        end
        n_beats = n_beats + 1;
        last_progress = cyc;
        if (ok && tag_base[o_tag] < 0) begin
            fail($sformatf("port %0d: unexpected tag %0d", q, o_tag));
            ok = 1'b0;
        end
        if (ok) begin
            x = tag_base[o_tag] + int'(o_row);
            if (x >= n_exp || vec[exp_at[x] + 1] != 32'(o_tag) || vec[exp_at[x] + 3] != 32'(o_row)) begin
                fail($sformatf("port %0d: unexpected row tag=%0d row=%0d", q, o_tag, o_row));
                ok = 1'b0;
            end
        end
        if (ok) check_beat_body(q, x);
    endtask

    task automatic check_beat_body(input int q, input int x);
        int a;
        logic [63:0] ew, ed;
        a = exp_at[x];
        if (verbose) $display("BEAT port=%0d tag=%0d row=%0d", q, o_tag, o_row);
        if (!vec[a+5][q]) fail($sformatf("tag %0d row %0d delivered to unselected port %0d", o_tag, o_row, q));
        if (exp_seen[x][q]) fail($sformatf("tag %0d row %0d delivered twice on port %0d", o_tag, o_row, q));
        exp_seen[x][q] = 1'b1;
        // row order / contiguity per port
        if (o_row != 0 && !(last_row_p[q] == int'(o_row) - 1 && last_tag_p[q] == o_tag))
            fail($sformatf("port %0d: tag %0d row %0d not contiguous after tag %0d row %0d",
                           q, o_tag, o_row, last_tag_p[q], last_row_p[q]));
        last_tag_p[q] = o_tag;
        last_row_p[q] = int'(o_row);
        if (o_slot !== SLOT_W'(vec[a+2]) || o_last !== vec[a+4][0] || o_err !== vec[a+6][0] ||
            o_col_mask !== COLS'(w64(a+8)) || o_ovf !== COLS'(w64(a+10)) || o_clip !== COLS'(w64(a+12)))
            fail($sformatf("tag %0d row %0d: slot=%0d last=%b err=%b cmask=%b ovf=%b clip=%b exp slot=%0d last=%0d err=%0d cmask=%0h ovf=%0h clip=%0h",
                           o_tag, o_row, o_slot, o_last, o_err, o_col_mask, o_ovf, o_clip,
                           vec[a+2], vec[a+4], vec[a+6], w64(a+8), w64(a+10), w64(a+12)));
        for (int j = 0; j < COLS; j++) begin
            ew = w64(a + 14 + 2*j);
            ed = w64(a + 14 + 2*COLS + 2*j);
            if (o_wide[j*ACC_W +: ACC_W] !== ACC_W'(ew) || o_data[j*OUT_W +: OUT_W] !== OUT_W'(ed))
                fail($sformatf("tag %0d row %0d lane %0d: wide=%0d data=%0d expected wide=%0d data=%0d",
                               o_tag, o_row, j, $signed(o_wide[j*ACC_W +: ACC_W]),
                               $signed(o_data[j*OUT_W +: OUT_W]), $signed(ew), $signed(ed)));
        end
    endtask

    // cmt_done: once per tile, after its last row, flags = OR over the tile
    always @(posedge clk) begin
        if (rst_n === 1'b1 && cmt_done === 1'b1) begin
            int x0, a0, m;
            logic eo, ec, ee, all;
            n_tiles_done = n_tiles_done + 1;
            if (tag_base[cmt_tag] < 0) fail($sformatf("cmt_done for unknown tag %0d", cmt_tag));
            else begin
                x0 = tag_base[cmt_tag];
                a0 = exp_at[x0];
                if (tile_cmt[cmt_tag]) fail($sformatf("cmt_done twice for tag %0d", cmt_tag));
                tile_cmt[cmt_tag] = 1'b1;
                eo = 0; ec = 0; ee = 0; all = 1; m = 0;
                for (int x = x0; x < n_exp && vec[exp_at[x] + 1] == 32'(cmt_tag); x++) begin
                    eo = eo | (w64(exp_at[x] + 10) != 0);
                    ec = ec | (w64(exp_at[x] + 12) != 0);
                    ee = ee | vec[exp_at[x] + 6][0];
                    all = all & (exp_seen[x] == vec[exp_at[x] + 5][2:0]);
                    m = m + 1;
                end
                if (!all) fail($sformatf("cmt_done for tag %0d before all its rows were delivered", cmt_tag));
                if (cmt_slot !== SLOT_W'(vec[a0+2]) || cmt_ovf !== eo || cmt_clip !== ec || cmt_err !== ee)
                    fail($sformatf("cmt_done tag %0d: slot=%0d ovf=%b clip=%b err=%b exp %0d %b %b %b",
                                   cmt_tag, cmt_slot, cmt_ovf, cmt_clip, cmt_err, vec[a0+2], eo, ec, ee));
            end
        end
    end

    // ---------------------------------------------------------------- throughput probe
    int tp_first_ps = -1, tp_last_ps = -1, tp_n_ps = 0, tp_last_out = -1;
    always @(posedge clk) begin
        if (rst_n === 1'b1 && ps_valid === 1'b1 && ps_ready === 1'b1) begin
            if (tp_first_ps < 0) tp_first_ps <= cyc;
            tp_last_ps <= cyc;
            tp_n_ps    <= tp_n_ps + 1;
        end
        if (rst_n === 1'b1 && dut.u_acc.o_valid === 1'b1 && dut.u_acc.o_ready === 1'b1) tp_last_out <= cyc;
    end

    // ---------------------------------------------------------------- coverage probes
    int cov_fwd = 0, cov_raw_b2b = 0, cov_rd_stall = 0, cov_wr_stall = 0, cov_out_bp = 0;
    int cov_concurrent = 0, cov_multi_commit = 0;
    always @(posedge clk) begin
        if (rst_n === 1'b1) begin
            if (dut.u_acc.x_hit === 1'b1 && dut.u_acc.x_vld === 1'b1) cov_fwd <= cov_fwd + 1;
            if (dut.u_acc.x_vld === 1'b1 && dut.u_acc.w_vld === 1'b1 && dut.u_acc.w_wr === 1'b1 &&
                dut.u_acc.x_userd === 1'b1 && dut.u_acc.w_addr == dut.u_acc.x_addr) cov_raw_b2b <= cov_raw_b2b + 1;
            if (dut.u_acc.ev_inc[4*EVW +: EVW] != 0) cov_rd_stall <= cov_rd_stall + 1;
            if (dut.u_acc.ev_inc[5*EVW +: EVW] != 0) cov_wr_stall <= cov_wr_stall + 1;
            if (dut.u_acc.o_valid === 1'b1 && dut.u_acc.o_ready !== 1'b1) cov_out_bp <= cov_out_bp + 1;
            if (dut.u_acc.cm_fire === 1'b1 && ps_valid === 1'b1) cov_concurrent <= cov_concurrent + 1;
            if (dut.u_acc.cm_any === 1'b1 && dut.u_acc.cm_active_q === 1'b1 &&
                dut.u_acc.cm_first != dut.u_acc.cm_slot_q) cov_multi_commit <= cov_multi_commit + 1;
        end
    end

    // ---------------------------------------------------------------- X checks on control outputs
    always @(posedge clk) begin
        if (rst_n === 1'b1 && cyc > 2) begin
            if (^{cfg_ready, ps_ready, hc_ready, hr_valid, o_vld, idle, cmt_done, err_pulse, cfg_reject} === 1'bx)
                fail("X on a control output");
        end
    end

    // ---------------------------------------------------------------- watchdog
    always @(posedge clk) begin
        if (ps_bar != -1 && cyc - last_progress > 200000) begin
            fail("watchdog: no progress for 200000 cycles (deadlock?)");
            $display("TB_SUMMARY cfg=%0d psum=%0d host_resp=%0d beats=%0d tiles=%0d cycles=%0d errors=%0d",
                     n_cfg, n_psr, n_resp, n_beats, n_tiles_done, cyc, errors);
            $display("TB_RESULT: FAIL");
            $finish;
        end
    end

    // ---------------------------------------------------------------- main
    initial begin : main
        string vf, wf;
        int nw, at, typ, len, seg, nrec;
        if ($value$plusargs("SEED=%d", seed)) ;
        if ($value$plusargs("PSGAP=%d", psgap)) ;
        if ($value$plusargs("HCGAP=%d", hcgap)) ;
        if ($value$plusargs("ORDY=%d", ordy)) ;
        if ($value$plusargs("HRRDY=%d", hrrdy)) ;
        if ($value$plusargs("RDBLK=%d", rdblk)) ;
        if ($value$plusargs("WRBLK=%d", wrblk)) ;
        verbose = $test$plusargs("VERBOSE");
        env_rs = xs(32'(seed) ^ 32'h0BAD_F00D);
        if ($value$plusargs("WAVE=%s", wf)) begin
            $dumpfile(wf);
            $dumpvars(0, tb_acc);
        end
        if (!$value$plusargs("VEC=%s", vf)) begin
            $display("TB_RESULT: FAIL (no +VEC)");
            $finish;
        end
        for (int i = 0; i < (1 << TAG_W); i++) begin
            tag_base[i] = -1;
            tile_cmt[i] = 1'b0;
        end
        $readmemh(vf, vec);
        if (vec[0] !== 32'h7C04_0001) begin
            $display("TB_RESULT: FAIL (bad vector magic %h)", vec[0]);
            $finish;
        end
        if (vec[2] != ROWS || vec[3] != COLS || vec[4] != NUM_TILES || vec[5] != ACC_W ||
            vec[6] != OUT_W || vec[7] != RD_LAT || vec[8] != OVF_POLICY || vec[9] != STRICT ||
            vec[10] != GUARD) begin
            $display("TB_RESULT: FAIL (vector file built for a different configuration)");
            $finish;
        end
        nw = int'(vec[1]);
        // ---- index the records
        at = 16; seg = 0; nrec = 0;
        while (at < nw) begin
            typ = int'(vec[at][31:24]);
            len = int'(vec[at][23:0]);
            if (typ == T_END) begin
                at = nw;                      // end marker
                typ = 0;
            end
            if (typ != 0) case (typ)
                T_CFG, T_PS, T_RST: begin ps_list[n_ps] = at; n_ps = n_ps + 1; end
                T_HC:  begin hc_list[n_hc] = at; n_hc = n_hc + 1; end
                T_BAR: begin
                    ps_list[n_ps] = at; n_ps = n_ps + 1;
                    hc_list[n_hc] = at; n_hc = n_hc + 1;
                    seg = seg + 1;
                end
                T_EXP: begin
                    exp_at[n_exp] = at;
                    exp_seg[n_exp] = seg;            // segment the beat belongs to
                    exp_seen[n_exp] = '0;
                    if (vec[at+3] == 0) begin
                        if (tag_base[vec[at+1][TAG_W-1:0]] >= 0) begin
                            $display("TB_RESULT: FAIL (duplicate tag %0d in vectors)", vec[at+1]);
                            $finish;
                        end
                        tag_base[vec[at+1][TAG_W-1:0]] = n_exp;
                    end
                    n_exp = n_exp + 1;
                end
                default: begin
                    $display("TB_RESULT: FAIL (unknown record type %0d at %0d)", typ, at);
                    $finish;
                end
            endcase
            nrec = nrec + 1;
            at = at + 1 + len;
        end
        $display("TB_INFO vectors=%s words=%0d ps_records=%0d hc_records=%0d exp_beats=%0d segments=%0d",
                 vf, nw, n_ps, n_hc, n_exp, seg);
        $display("TB_INFO cfg ROWS=%0d COLS=%0d TILES=%0d ACC=%0d OUT=%0d RD_LAT=%0d POL=%0d STRICT=%0d GUARD=%0d OFIFO=%0d PERF_W=%0d seed=%0d psgap=%0d hcgap=%0d ordy=%0d hrrdy=%0d rdblk=%0d wrblk=%0d",
                 ROWS, COLS, NUM_TILES, ACC_W, OUT_W, RD_LAT, OVF_POLICY, STRICT, GUARD, OFIFO, PERF_W,
                 seed, psgap, hcgap, ordy, hrrdy, rdblk, wrblk);
        // ---- reset
        rst_n <= 1'b0;
        repeat (4) tick();
        rst_n <= 1'b1;
        repeat (2) tick();
        last_progress = cyc;
        ps_bar = -2;
        // ---- run (the watchdog below ends the test on a deadlock)
        while (!smp_done) tick();
        // ---- end-of-test checks
        repeat (20) tick();
        if (resp_rd != resp_wr) fail($sformatf("%0d host responses missing", resp_wr - resp_rd));
        for (int x = 0; x < n_exp; x++) begin
            if (vec[exp_at[x] + 7] == 0 && exp_seen[x] != vec[exp_at[x] + 5][2:0])
                fail($sformatf("end: beat tag=%0d row=%0d never delivered", vec[exp_at[x]+1], vec[exp_at[x]+3]));
        end
        // perf_clr clears every counter
        perf_clr <= 1'b1;
        tick();
        perf_clr <= 1'b0;
        tick();
        if (perf_o !== '0) fail("perf_clr did not clear the counters");
        $display("TB_COVER fwd_hits=%0d raw_back_to_back=%0d rd_stall_cyc=%0d wr_stall_cyc=%0d out_backpressure_cyc=%0d commit_during_psum=%0d commit_while_other_pending=%0d",
                 cov_fwd, cov_raw_b2b, cov_rd_stall, cov_wr_stall, cov_out_bp, cov_concurrent, cov_multi_commit);
        $display("TB_PERF psum_beats=%0d first_psum_cyc=%0d last_psum_cyc=%0d last_output_cyc=%0d",
                 tp_n_ps, tp_first_ps, tp_last_ps, tp_last_out);
        $display("TB_SUMMARY cfg=%0d psum=%0d host_resp=%0d beats=%0d tiles=%0d cycles=%0d errors=%0d",
                 n_cfg, n_psr, n_resp, n_beats, n_tiles_done, cyc, errors);
        $display("TB_RESULT: %s", (errors == 0) ? "PASS" : "FAIL");
        $finish;
    end

endmodule
