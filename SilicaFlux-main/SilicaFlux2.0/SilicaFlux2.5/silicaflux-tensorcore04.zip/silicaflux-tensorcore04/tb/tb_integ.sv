// =============================================================================
//  SilicaFlux TENSORCORE 04  --  tb_integ.sv
//  Integration testbench:  TENSORCORE 02 tensor_systolic_array (unmodified,
//  third_party/tensorcore02)  ->  tensor_acc_subsystem.
//
//  The TB plays the K-chunk sequencer and the operand buffers: for every job
//  (one output tile, C = bias + A @ B) it opens the accumulator tile, then for
//  each chunk launches the array with cfg_k = chunk_k and streams the chunk's
//  k-slices (random s_valid gaps, random stall_i).  The array's readout
//  stream (m_*) is wired straight to the accumulator (ps_*); the TB only adds
//  the sideband {slot, tag, chunk, chunk_k}.
//
//  CHECKS
//   * every array readout beat == the CHUNK-LOCAL partial sum of that chunk
//     (TB-side 64-bit reference over the job's A/B): proves the PE accumulators
//     restart from zero at every launch, so no product can be added twice
//   * every committed beat == exact Python GEMM (o_wide, o_data, flags)
//   * each tile delivered exactly once per selected port, rows in order
//   * array align_err never set; accumulator never reports a psum error
//   * duplicate counter == beats replayed after array restarts; chunk counter
//     == chunks applied; tile counter == jobs
//   * restarts: array reset in the middle of a chunk readout, then the chunk is
//     re-run (rows already added must be dropped as duplicates); accumulator
//     reset in the middle of a job, then the whole job is re-run
//
//  +JOBS=<file> +SEED=<n> +SGAP=<%> +STALL=<%> +ORDY=<%> +RDBLK=<%> +WRBLK=<%>
//  +RESLOG  print one RES line per committed element (cross-checked by Python)
// =============================================================================
`timescale 1ns/1ps
module tb_integ #(
    parameter int ROWS      = 4,
    parameter int COLS      = 4,
    parameter int NUM_TILES = 2,
    parameter int ACC_W     = 32,
    parameter int OUT_W     = 32,
    parameter int RD_LAT    = 1,
    parameter int MUL_PIPE  = 0,
    parameter int MEMW      = 1 << 23
);
    localparam int DW = 8, PSUM_W = 32, KW = 17, BIAS_W = 32, TAG_W = 16, CHUNK_W = 16, KTOT_W = 40;
    localparam int SLOT_W = (NUM_TILES > 1) ? $clog2(NUM_TILES) : 1;
    localparam int RIDW   = (ROWS > 1) ? $clog2(ROWS) : 1;
    localparam int MW     = $clog2(ROWS + 1);
    localparam int NW     = $clog2(COLS + 1);
    localparam int EVW    = $clog2(COLS + 1);
    localparam int NPERF  = 16;
    localparam int PERF_W = 40;
    localparam logic [31:0] NONE = 32'hFFFF_FFFF;

    logic clk = 1'b0;
    always #5 clk = ~clk;
    logic arr_rst_n = 1'b0, acc_rst_n = 1'b0;

    // ------------------------------------------------------------------ array
    logic                   a_cfg_valid = 1'b0, a_cfg_ready, a_cfg_reject;
    logic [MW-1:0]          a_cfg_m = '0;
    logic [NW-1:0]          a_cfg_n = '0;
    logic [KW-1:0]          a_cfg_k = '0;
    logic                   s_valid = 1'b0, s_ready;
    logic [ROWS*DW-1:0]     s_a = '0;
    logic [COLS*DW-1:0]     s_b = '0;
    logic [KW-1:0]          s_k;
    logic                   stall_i = 1'b0;
    logic                   m_valid, m_ready, m_last;
    logic [RIDW-1:0]        m_row;
    logic [COLS*PSUM_W-1:0] m_data;
    logic [COLS-1:0]        m_col_mask;
    logic                   a_busy, a_tile_done, a_align_err;
    /* verilator lint_off UNUSEDSIGNAL */
    logic [39:0]            ap_busy, ap_issue, ap_su, ap_se, ap_mac, ap_pad;
    /* verilator lint_on UNUSEDSIGNAL */

    tensor_systolic_array #(.ARRAY_ROWS(ROWS), .ARRAY_COLS(COLS), .DATA_WIDTH(DW), .ACC_WIDTH(PSUM_W),
                            .K_WIDTH(KW), .MUL_PIPE(MUL_PIPE), .CHECK_ALIGN(1), .PERF_EN(1)) u_array (
        .clk(clk), .rst_n(arr_rst_n),
        .cfg_valid(a_cfg_valid), .cfg_ready(a_cfg_ready), .cfg_m(a_cfg_m), .cfg_n(a_cfg_n), .cfg_k(a_cfg_k),
        .cfg_reject(a_cfg_reject),
        .s_valid(s_valid), .s_ready(s_ready), .s_a(s_a), .s_b(s_b), .s_k(s_k), .stall_i(stall_i),
        .m_valid(m_valid), .m_ready(m_ready), .m_row(m_row), .m_data(m_data), .m_col_mask(m_col_mask),
        .m_last(m_last), .busy(a_busy), .tile_done(a_tile_done), .align_err(a_align_err),
        .perf_busy(ap_busy), .perf_issue(ap_issue), .perf_stall_up(ap_su), .perf_stall_ext(ap_se),
        .perf_mac(ap_mac), .perf_pad(ap_pad));

    // ------------------------------------------------------------------ accumulator
    logic                   cfg_valid = 1'b0, cfg_ready, cfg_reject;
    logic [2:0]             cfg_reject_code;
    logic [SLOT_W-1:0]      cfg_slot = '0;
    logic [TAG_W-1:0]       cfg_tag = '0;
    logic [MW-1:0]          cfg_m = '0;
    logic [NW-1:0]          cfg_n = '0;
    logic [KTOT_W-1:0]      cfg_k_total = '0;
    logic [CHUNK_W-1:0]     cfg_n_chunks = '0;
    logic                   cfg_bias_en = 1'b0;
    logic [COLS*BIAS_W-1:0] cfg_bias = '0;
    logic [2:0]             cfg_dest = '0;
    logic [SLOT_W-1:0]      sb_slot = '0;      // sequencer sideband, constant during a chunk
    logic [TAG_W-1:0]       sb_tag = '0;
    logic [CHUNK_W-1:0]     sb_chunk = '0;
    logic [KW-1:0]          sb_kc = '0;
    logic                   ps_ready;
    logic                   st_rd_block, st_wr_block = 1'b0;
    logic                   env_rdblk = 1'b0;   // random contention (environment)
    logic                   cut_hold = 1'b0;    // sequencer: hold ps_ready low to cut a readout exactly
    assign st_rd_block = env_rdblk | cut_hold;
    logic [2:0]             o_vld;
    logic [2:0]             o_rdy = '0;
    logic [TAG_W-1:0]       o_tag;
    logic [SLOT_W-1:0]      o_slot;
    logic [RIDW-1:0]        o_row;
    logic                   o_last, o_err;
    logic [COLS-1:0]        o_col_mask, o_ovf, o_clip;
    logic [COLS*ACC_W-1:0]  o_wide;
    logic [COLS*OUT_W-1:0]  o_data;
    logic                   cmt_done, cmt_ovf, cmt_clip, cmt_err, idle, err_pulse;
    logic [SLOT_W-1:0]      cmt_slot;
    logic [TAG_W-1:0]       cmt_tag;
    logic [NUM_TILES*2-1:0] slot_state;
    logic [2:0]             err_code;
    logic [7:0]             err_sticky;
    logic [NPERF*EVW-1:0]   ev_inc;
    logic [NPERF*PERF_W-1:0] perf_o;
    /* verilator lint_off UNUSEDSIGNAL */
    logic                   hc_ready, hr_valid, hr_vld, st_en, st_rd_req, st_rd_ready, st_wr_req, st_wr_ready;
    logic [2:0]             hr_status;
    logic [COLS*ACC_W-1:0]  hr_data;
    logic [COLS-1:0]        hr_ovf;
    logic [CHUNK_W-1:0]     hr_nchunk;
    logic [KTOT_W-1:0]      hr_kacc;
    /* verilator lint_on UNUSEDSIGNAL */

    tensor_acc_subsystem #(.ROWS(ROWS), .COLS(COLS), .ACC_W(ACC_W), .OUT_W(OUT_W),
                           .NUM_TILES(NUM_TILES), .RD_LAT(RD_LAT)) dut (
        .clk(clk), .rst_n(acc_rst_n),
        .cfg_valid, .cfg_ready, .cfg_slot, .cfg_tag, .cfg_m, .cfg_n, .cfg_k_total, .cfg_n_chunks,
        .cfg_bias_en, .cfg_bias, .cfg_dest, .cfg_reject, .cfg_reject_code,
        .ps_valid(m_valid), .ps_ready(ps_ready), .ps_slot(sb_slot), .ps_tag(sb_tag), .ps_chunk(sb_chunk),
        .ps_chunk_k(sb_kc), .ps_row(m_row), .ps_data(m_data), .ps_col_mask(m_col_mask), .ps_last(m_last),
        .hc_valid(1'b0), .hc_ready, .hc_op(2'd0), .hc_slot('0), .hc_row('0), .hc_wdata('0),
        .hr_valid, .hr_ready(1'b1), .hr_status, .hr_data, .hr_ovf, .hr_vld, .hr_nchunk, .hr_kacc,
        .st_rd_block, .st_wr_block,
        .osram_valid(o_vld[0]), .osram_ready(o_rdy[0]), .oquant_valid(o_vld[1]), .oquant_ready(o_rdy[1]),
        .odma_valid(o_vld[2]), .odma_ready(o_rdy[2]),
        .o_tag, .o_slot, .o_row, .o_last, .o_col_mask, .o_wide, .o_data, .o_ovf, .o_clip, .o_err,
        .cmt_done, .cmt_slot, .cmt_tag, .cmt_ovf, .cmt_clip, .cmt_err,
        .slot_state, .idle, .err_pulse, .err_code, .err_sticky,
        .perf_clr(1'b0), .ev_inc, .perf_o,
        .st_en, .st_rd_req, .st_rd_ready, .st_wr_req, .st_wr_ready);

    // array readout handshake = accumulator psum handshake
    assign m_ready = ps_ready;

    // ------------------------------------------------------------------ vectors / state
    logic [31:0] vec [0:MEMW-1];
    int job_at [0:4095];
    int njobs = 0, errors = 0, cyc = 0, last_progress = 0;
    int seed = 1, sgap = 0, stall = 0, ordy = 100, rdblk = 0, wrblk = 0;
    logic reslog = 1'b0;
    int cur_job = -1;            // job whose chunk is in the array
    int n_launch = 0, n_restart_arr = 0, n_restart_acc = 0, n_psum_chk = 0, n_beats = 0, n_tiles = 0;
    int n_cut_late = 0;          // array resets that landed after the whole chunk was accepted
    int n_replayed = 0;          // rows replayed after array restarts (whole run)
    longint exp_dup = 0, exp_chunks = 0, exp_tiles = 0;   // since the last accumulator reset

    // per-tag delivery bookkeeping
    int  tag_job [0:65535];
    logic [2:0] row_seen [0:65535][0:15];

    always @(posedge clk) cyc <= cyc + 1;

    function automatic logic [31:0] xs(input logic [31:0] s);
        logic [31:0] x;
        x = s; x = x ^ (x << 13); x = x ^ (x >> 17); x = x ^ (x << 5);
        xs = x;
    endfunction

    task automatic fail(input string msg);
        errors = errors + 1;
        if (errors > 200) begin           // a broken design can keep producing beats forever
            $display("TB_ERROR: more than 200 errors, stopping");
            $display("TB_SUMMARY errors=%0d cycles=%0d (stopped early)", errors, cyc);
            $display("TB_RESULT: FAIL");
            $finish;
        end
        if (errors <= 40) $display("TB_ERROR cyc=%0d: %s", cyc, msg);
    endtask

    task automatic tick();
        @(posedge clk);
        #1;
    endtask

    // job record field helpers
    function automatic int jf(input int j, input int k);      // header field k (0 = slot)
        jf = int'(vec[job_at[j] + 1 + k]);
    endfunction
    function automatic int j_bias_at(input int j);  j_bias_at  = job_at[j] + 16;                 endfunction
    function automatic int j_chunk_at(input int j); j_chunk_at = j_bias_at(j) + COLS;              endfunction
    function automatic int j_a_at(input int j);     j_a_at     = j_chunk_at(j) + jf(j, 5);         endfunction
    function automatic int j_b_at(input int j);     j_b_at     = j_a_at(j) + ((jf(j, 12) == 0) ? jf(j, 2) * jf(j, 4) : 0); endfunction
    function automatic int j_exp_at(input int j);   j_exp_at   = j_b_at(j) + ((jf(j, 12) == 0) ? jf(j, 4) * jf(j, 3) : 0); endfunction

    function automatic longint opA(input int j, input int m, input int k);
        if (jf(j, 12) != 0) opA = longint'($signed(vec[job_at[j] + 14]));
        else                opA = longint'($signed(vec[j_a_at(j) + m * jf(j, 4) + k]));
    endfunction
    function automatic longint opB(input int j, input int k, input int n);
        if (jf(j, 12) != 0) opB = longint'($signed(vec[job_at[j] + 15]));
        else                opB = longint'($signed(vec[j_b_at(j) + k * jf(j, 3) + n]));
    endfunction

    // ------------------------------------------------------------------ random environment
    logic [31:0] env_rs = 32'h2468_ACE1;
    always @(posedge clk) begin
        logic [31:0] r;
        r = xs(env_rs);
        env_rs <= xs(r);
        env_rdblk   <= ((r % 100) < 32'(rdblk));
        st_wr_block <= (((r >> 8) % 100) < 32'(wrblk));
        o_rdy[0] <= (((r >> 3) % 100) < 32'(ordy));
        o_rdy[1] <= (((r >> 11) % 100) < 32'(ordy));
        o_rdy[2] <= (((r >> 19) % 100) < 32'(ordy));
        stall_i  <= (((r >> 23) % 100) < 32'(stall));
    end

    // ------------------------------------------------------------------ edge sampler
    logic smp_acfg_hs = 0, smp_cfg_hs = 0, smp_s_hs = 0, smp_ps_hs = 0, smp_a_idle = 0, smp_a_readout = 0;
    always @(posedge clk) begin
        smp_acfg_hs   <= a_cfg_valid & a_cfg_ready;
        smp_cfg_hs    <= cfg_valid & cfg_ready;
        smp_s_hs      <= s_valid & s_ready;
        smp_ps_hs     <= m_valid & ps_ready;
        smp_a_idle    <= a_cfg_ready;
        smp_a_readout <= a_tile_done;
    end

    // free-running count of readout beats accepted by the accumulator
    longint ps_hs_count = 0;
    always @(posedge clk) if (m_valid === 1'b1 && ps_ready === 1'b1 && acc_rst_n === 1'b1) ps_hs_count <= ps_hs_count + 1;

    // ------------------------------------------------------------------ psum (array readout) checker
    //  Each beat must equal the chunk-local partial sum  sum_{k in chunk} A*B.
    int  chk_k0 = 0;       // first K index of the chunk in the array (set by the sequencer)
    always @(posedge clk) begin
        if (arr_rst_n === 1'b1 && acc_rst_n === 1'b1 && m_valid === 1'b1 && ps_ready === 1'b1) begin
            for (int n = 0; n < COLS; n++) begin
                longint e;
                e = 0;
                if (n < jf(cur_job, 3)) begin
                    if (jf(cur_job, 12) != 0) e = longint'(sb_kc) * opA(cur_job, 0, 0) * opB(cur_job, 0, 0);
                    else for (int k = 0; k < int'(sb_kc); k++) e = e + opA(cur_job, int'(m_row), chk_k0 + k) * opB(cur_job, chk_k0 + k, n);
                end
                if (longint'($signed(m_data[n*PSUM_W +: PSUM_W])) != e)
                    fail($sformatf("job %0d chunk %0d row %0d col %0d: array psum %0d, chunk-local reference %0d",
                                   cur_job, sb_chunk, m_row, n, $signed(m_data[n*PSUM_W +: PSUM_W]), e));
            end
            n_psum_chk = n_psum_chk + 1;
            last_progress = cyc;
        end
        if (arr_rst_n === 1'b1 && a_align_err === 1'b1) fail("array align_err");
        if (acc_rst_n === 1'b1 && err_pulse === 1'b1) fail($sformatf("accumulator rejected a psum (code %0d)", err_code));
        if (acc_rst_n === 1'b1 && a_cfg_reject === 1'b1) fail("array rejected a launch");
        if (acc_rst_n === 1'b1 && cfg_reject === 1'b1) fail($sformatf("accumulator rejected a tile (code %0d)", cfg_reject_code));
    end

    // ------------------------------------------------------------------ output checker
    always @(posedge clk) begin
        if (acc_rst_n === 1'b1) begin
            for (int q = 0; q < 3; q++) begin
                if (o_vld[q] === 1'b1 && o_rdy[q] === 1'b1) begin
                    int j, ea, M, N, qf;
                    logic [2:0] dst;
                    j = tag_job[o_tag];
                    n_beats = n_beats + 1;
                    last_progress = cyc;
                    if (j < 0) fail($sformatf("port %0d: output for unknown/abandoned tag %0d", q, o_tag));
                    else begin
                        M = jf(j, 2); N = jf(j, 3);
                        ea = j_exp_at(j);
                        dst = vec[job_at[j] + 8][2:0];
                        qf = dst[0] ? 0 : (dst[1] ? 1 : 2);
                        if (!dst[q]) fail($sformatf("tag %0d: unselected port %0d", o_tag, q));
                        if (row_seen[o_tag][o_row][q]) fail($sformatf("tag %0d row %0d twice on port %0d", o_tag, o_row, q));
                        if (o_row != 0 && !row_seen[o_tag][o_row - 1][q]) fail($sformatf("tag %0d row %0d out of order", o_tag, o_row));
                        row_seen[o_tag][o_row][q] = 1'b1;
                        if (o_ovf !== '0 || o_err !== 1'b0 || o_last !== (int'(o_row) == M - 1) ||
                            o_col_mask !== COLS'((64'd1 << N) - 1))
                            fail($sformatf("tag %0d row %0d: flags ovf=%b err=%b last=%b mask=%b", o_tag, o_row, o_ovf, o_err, o_last, o_col_mask));
                        for (int n = 0; n < COLS; n++) begin
                            logic [63:0] ew, ed;
                            logic ec;
                            if (n < N) begin
                                ew = {vec[ea + 2*(int'(o_row)*N + n) + 1], vec[ea + 2*(int'(o_row)*N + n)]};
                                ed = {vec[ea + 2*M*N + 2*(int'(o_row)*N + n) + 1], vec[ea + 2*M*N + 2*(int'(o_row)*N + n)]};
                                ec = vec[ea + 4*M*N + int'(o_row)*N + n][0];
                            end else begin
                                ew = 0; ed = 0; ec = 0;
                            end
                            if (o_wide[n*ACC_W +: ACC_W] !== ACC_W'(ew) || o_data[n*OUT_W +: OUT_W] !== OUT_W'(ed) || o_clip[n] !== ec)
                                fail($sformatf("tag %0d row %0d col %0d: wide=%0d data=%0d clip=%b, exact GEMM %0d (data %0d clip %b)",
                                               o_tag, o_row, n, $signed(o_wide[n*ACC_W +: ACC_W]), $signed(o_data[n*OUT_W +: OUT_W]),
                                               o_clip[n], $signed(ew), $signed(ed), ec));
                            if (reslog && q == qf && n < N)
                                $display("RES %0d %0d %0d %0d", o_tag, o_row, n, $signed(o_wide[n*ACC_W +: ACC_W]));
                        end
                    end
                end
            end
            if (cmt_done === 1'b1) n_tiles = n_tiles + 1;
        end
    end

    // ------------------------------------------------------------------ sequencer
    logic [31:0] seq_rs;
    task automatic sgap_wait();
        logic [31:0] r;
        r = xs(seq_rs); seq_rs = r;
        while ((r % 100) < 32'(sgap)) begin
            tick();
            r = xs(seq_rs); seq_rs = r;
        end
    endtask

    task automatic reset_acc();
        acc_rst_n <= 1'b0;
        arr_rst_n <= 1'b0;
        repeat (3) tick();
        acc_rst_n <= 1'b1;
        arr_rst_n <= 1'b1;
        tick();
        exp_dup = 0; exp_chunks = 0; exp_tiles = 0;
    endtask

    // run chunk c of job j on the array; returns rows accepted before a requested
    // array reset (-1 if the chunk completed)
    longint hs_base = 0;
    task automatic run_chunk(input int j, input int c, input int k0, input int rst_rows, output int accepted);
        int kc, M, N;
        kc = int'(vec[j_chunk_at(j) + c]);
        M = jf(j, 2); N = jf(j, 3);
        accepted = -1;
        // sideband for the readout of this chunk
        sb_slot  <= SLOT_W'(jf(j, 0));
        sb_tag   <= TAG_W'(jf(j, 1));
        sb_chunk <= CHUNK_W'(c);
        sb_kc    <= KW'(kc);
        chk_k0    = k0;
        cur_job   = j;
        hs_base   = ps_hs_count;
        // launch
        a_cfg_m <= MW'(M); a_cfg_n <= NW'(N); a_cfg_k <= KW'(kc);
        a_cfg_valid <= 1'b1;
        tick();
        while (!smp_acfg_hs) tick();
        a_cfg_valid <= 1'b0;
        n_launch = n_launch + 1;
        // stream the k-slices
        for (int k = 0; k < kc; k++) begin
            sgap_wait();
            for (int m = 0; m < ROWS; m++) s_a[m*DW +: DW] <= (m < M) ? DW'(opA(j, m, k0 + k)) : '0;
            for (int n = 0; n < COLS; n++) s_b[n*DW +: DW] <= (n < N) ? DW'(opB(j, k0 + k, n)) : '0;
            s_valid <= 1'b1;
            tick();
            while (!smp_s_hs) tick();
            s_valid <= 1'b0;
            last_progress = cyc;
        end
        // readout (paced by the accumulator), optionally cut short by an array reset after
        // EXACTLY rst_rows accepted rows: the TB holds the accumulator's read port busy
        // (ps_ready = 0) and releases it for one beat at a time, then resets the array while
        // the port is still held, so no further row can slip through at the reset edge.
        if (rst_rows >= 0) begin
            longint base;
            base = hs_base;
            cut_hold = 1'b1;
            while (!smp_a_readout) tick();
            while (ps_hs_count - base < longint'(rst_rows)) begin
                longint n0;
                n0 = ps_hs_count;
                cut_hold = 1'b0;
                while (ps_hs_count == n0) tick();
                cut_hold = 1'b1;               // set 1 time unit after the accepting edge
            end
            arr_rst_n <= 1'b0;                 // array reset in the middle of the readout
            tick();
            arr_rst_n <= 1'b1;
            cut_hold = 1'b0;
            tick();
            accepted = int'(ps_hs_count - base);
            if (accepted != rst_rows) fail($sformatf("restart cut after %0d rows, wanted %0d", accepted, rst_rows));
            n_restart_arr = n_restart_arr + 1;
        end else begin
            while (!smp_a_readout) tick();
            while (!smp_a_idle) tick();
        end
    endtask

    task automatic run_job(input int j);
        int nch, k0, arr_c, arr_r, acc_c, acc_done, tag, retag;
        logic arr_pending, again;
        nch = jf(j, 5);
        arr_c = (vec[job_at[j] + 9] == NONE) ? -1 : jf(j, 8);
        arr_r = jf(j, 9);
        acc_c = (vec[job_at[j] + 11] == NONE) ? -1 : jf(j, 10);
        arr_pending = (arr_c >= 0);
        acc_done = 0;
        tag = jf(j, 1);
        retag = jf(j, 11);
        again = 1'b1;
        while (again) begin
            logic aborted;
            aborted = 1'b0;
            // open the accumulator tile
            sgap_wait();
            cfg_slot <= SLOT_W'(jf(j, 0)); cfg_tag <= TAG_W'(jf(j, 1));
            cfg_m <= MW'(jf(j, 2)); cfg_n <= NW'(jf(j, 3)); cfg_k_total <= KTOT_W'(jf(j, 4));
            cfg_n_chunks <= CHUNK_W'(nch); cfg_bias_en <= vec[job_at[j] + 7][0]; cfg_dest <= vec[job_at[j] + 8][2:0];
            for (int n = 0; n < COLS; n++) cfg_bias[n*BIAS_W +: BIAS_W] <= vec[j_bias_at(j) + n];
            cfg_valid <= 1'b1;
            tick();
            while (!smp_cfg_hs) tick();
            cfg_valid <= 1'b0;
            tag_job[jf(j, 1)] = j;
            k0 = 0;
            for (int c = 0; c < nch && !aborted; c++) begin
                int acc;
                if (arr_pending && c == arr_c) begin
                    run_chunk(j, c, k0, arr_r, acc);
                    arr_pending = 1'b0;
                    // A row can still be accepted at the reset edge itself.  If EVERY row got
                    // through, the chunk is complete (for the final chunk the tile has even
                    // committed) and must not be re-run: a re-run would be a stale replay that
                    // the accumulator rightly rejects as PE_NO_TILE.
                    if (acc < jf(j, 2)) begin
                        exp_dup = exp_dup + acc;       // those rows were added; the re-run replays them
                        n_replayed = n_replayed + acc;
                        run_chunk(j, c, k0, -1, acc);
                    end else begin
                        n_cut_late = n_cut_late + 1;
                    end
                end else begin
                    run_chunk(j, c, k0, -1, acc);
                end
                exp_chunks = exp_chunks + 1;
                k0 = k0 + int'(vec[j_chunk_at(j) + c]);
                if (acc_c >= 0 && !acc_done && c == acc_c) begin
                    // reset the accumulator in the middle of the job, then re-run all of it
                    tick();
                    reset_acc();
                    n_restart_acc = n_restart_acc + 1;
                    tag_job[jf(j, 1)] = -1;            // nothing of the first attempt may ever appear
                    vec[job_at[j] + 2] = 32'(retag);
                    acc_done = 1;
                    aborted = 1'b1;
                end
            end
            again = aborted;
        end
        exp_tiles = exp_tiles + 1;
    endtask

    // ------------------------------------------------------------------ main
    initial begin : main
        string jfile;
        int at, nw;
        if ($value$plusargs("SEED=%d", seed)) ;
        if ($value$plusargs("SGAP=%d", sgap)) ;
        if ($value$plusargs("STALL=%d", stall)) ;
        if ($value$plusargs("ORDY=%d", ordy)) ;
        if ($value$plusargs("RDBLK=%d", rdblk)) ;
        if ($value$plusargs("WRBLK=%d", wrblk)) ;
        reslog = $test$plusargs("RESLOG");
        seq_rs = xs(32'(seed) ^ 32'h1357_9BDF);
        env_rs = xs(32'(seed) ^ 32'hFACE_B00C);
        if (!$value$plusargs("JOBS=%s", jfile)) begin
            $display("TB_RESULT: FAIL (no +JOBS)");
            $finish;
        end
        for (int t = 0; t < 65536; t++) begin
            tag_job[t] = -1;
            for (int r = 0; r < 16; r++) row_seen[t][r] = '0;
        end
        $readmemh(jfile, vec);
        if (vec[0] !== 32'h7C04_1001 || vec[2] != ROWS || vec[3] != COLS || vec[4] != NUM_TILES ||
            vec[5] != ACC_W || vec[6] != OUT_W) begin
            $display("TB_RESULT: FAIL (job file does not match this configuration)");
            $finish;
        end
        nw = int'(vec[1]);
        njobs = int'(vec[7]);
        at = 8;
        for (int j = 0; j < njobs; j++) begin
            job_at[j] = at;
            at = at + 1 + int'(vec[at][23:0]);
        end
        $display("TB_INFO jobs=%s words=%0d njobs=%0d ROWS=%0d COLS=%0d TILES=%0d ACC=%0d OUT=%0d RD_LAT=%0d MUL_PIPE=%0d seed=%0d sgap=%0d stall=%0d ordy=%0d rdblk=%0d wrblk=%0d",
                 jfile, nw, njobs, ROWS, COLS, NUM_TILES, ACC_W, OUT_W, RD_LAT, MUL_PIPE, seed, sgap, stall, ordy, rdblk, wrblk);
        repeat (4) tick();
        arr_rst_n <= 1'b1;
        acc_rst_n <= 1'b1;
        repeat (2) tick();
        last_progress = cyc;
        for (int j = 0; j < njobs; j++) run_job(j);
        // drain
        while (!(idle === 1'b1)) tick();
        repeat (10) tick();
        // counters since the last accumulator reset
        if (64'(perf_o[2*PERF_W +: PERF_W]) != 64'(exp_dup))
            fail($sformatf("duplicate counter %0d, expected %0d replayed beats", perf_o[2*PERF_W +: PERF_W], exp_dup));
        if (64'(perf_o[3*PERF_W +: PERF_W]) != 0) fail("psum error counter non-zero");
        if (64'(perf_o[10*PERF_W +: PERF_W]) != 64'(exp_chunks))
            fail($sformatf("chunk counter %0d, expected %0d", perf_o[10*PERF_W +: PERF_W], exp_chunks));
        if (64'(perf_o[9*PERF_W +: PERF_W]) != 64'(exp_tiles))
            fail($sformatf("tile counter %0d, expected %0d", perf_o[9*PERF_W +: PERF_W], exp_tiles));
        // every job delivered completely on every selected port
        for (int j = 0; j < njobs; j++) begin
            for (int r = 0; r < jf(j, 2); r++)
                if (row_seen[jf(j, 1)][r] != vec[job_at[j] + 8][2:0])
                    fail($sformatf("job %0d tag %0d row %0d delivered on %b, expected %b", j, jf(j, 1), r,
                                   row_seen[jf(j, 1)][r], vec[job_at[j] + 8][2:0]));
        end
        if (n_tiles != njobs) fail($sformatf("cmt_done count %0d != jobs %0d", n_tiles, njobs));
        $display("TB_SUMMARY jobs=%0d launches=%0d array_restarts=%0d (complete_before_reset=%0d) acc_restarts=%0d psum_beats_checked=%0d out_beats=%0d tiles=%0d rows_replayed=%0d dups_since_acc_reset=%0d cycles=%0d errors=%0d",
                 njobs, n_launch, n_restart_arr, n_cut_late, n_restart_acc, n_psum_chk, n_beats, n_tiles, n_replayed, exp_dup, cyc, errors);
        $display("TB_RESULT: %s", (errors == 0) ? "PASS" : "FAIL");
        $finish;
    end

    always @(posedge clk) begin
        if (cyc > 100 && cyc - last_progress > 400000) begin
            fail("watchdog: no progress for 400000 cycles");
            $display("TB_RESULT: FAIL");
            $finish;
        end
    end
endmodule
