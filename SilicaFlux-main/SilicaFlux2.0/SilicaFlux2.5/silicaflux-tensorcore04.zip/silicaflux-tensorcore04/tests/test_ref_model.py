#!/usr/bin/env python3
"""Self-tests of the TENSORCORE 04 reference model (stdlib only).

  python3 tests/test_ref_model.py
"""
import os
import random
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "model"))
import acc_ref as R  # noqa: E402

FAILS = []


def check(cond, msg):
    if not cond:
        FAILS.append(msg)
        print("FAIL:", msg)


def brute_max_k(acc_w, dw, kcap=64):
    """Largest K such that EVERY reachable prefix sum of K products fits acc_w.
    Exhaustive over the set of reachable sums (no formula)."""
    prods = sorted({a * b for a in range(R.smin(dw), R.smax(dw) + 1)
                    for b in range(R.smin(dw), R.smax(dw) + 1)})
    sums = {0}
    best = 0
    for k in range(1, kcap + 1):
        sums = {s + q for s in sums for q in prods}
        if min(sums) < R.smin(acc_w) or max(sums) > R.smax(acc_w):
            return best
        best = k
    return best


def main():
    # 1. the brief's numbers
    check(R.prod_extremes(8) == (16384, -16256), "INT8 product extremes")
    check(R.max_exact_k(32, 8) == 131071, "K bound ACC32 = 131071")
    check(131071 * 16384 <= R.smax(32) < 131072 * 16384, "131071 worst-case products fit, 131072 do not")
    check(R.max_exact_k(40, 8) == 33554431, "K bound ACC40")
    check(R.max_exact_k(48, 8) == 8589934591, "K bound ACC48")
    check(R.max_exact_k(16, 8) == 1, "K bound ACC16")

    # 2. brute force at small widths
    n = 0
    for dw in (2, 3):
        for acc_w in range(2 * dw, 2 * dw + 5):
            b = brute_max_k(acc_w, dw)
            f = R.max_exact_k(acc_w, dw)
            check(b == f, f"brute force dw={dw} acc={acc_w}: brute {b} model {f}")
            n += 1

    # 3. RTL shift formula 2^(acc-2dw+1)-1 equals the first-principles bound
    for dw in range(2, 9):
        for acc_w in range(2 * dw, 65):
            check(R.max_exact_k(acc_w, dw) == (1 << (acc_w - 2 * dw + 1)) - 1,
                  f"shift formula dw={dw} acc={acc_w}")

    # 4. bias-aware bound equals the RTL's static check (b + K*pmax <= MAX, b + K*pmin >= MIN)
    rng = random.Random(4)
    for _ in range(3000):
        acc_w = rng.choice([32, 40])
        b = rng.randint(R.smin(32), R.smax(32))
        kmax = R.max_exact_k(acc_w, 8, b, b)
        for k in (kmax, kmax + 1):
            rtl_ok = (b + k * 16384 <= R.smax(acc_w)) and (b - k * 16256 >= R.smin(acc_w))
            check(rtl_ok == (k <= kmax), f"bias bound acc={acc_w} b={b} k={k}")

    # 5. partition invariance of the architectural model (in-range data)
    p = R.Params(rows=3, cols=3, num_tiles=2)
    for t in range(300):
        M, N = rng.randint(1, 3), rng.randint(1, 3)
        K = rng.randint(1, 60)
        A = [[rng.randint(-128, 127) for _ in range(K)] for _ in range(M)]
        B = [[rng.randint(-128, 127) for _ in range(N)] for _ in range(K)]
        bias = [rng.randint(-2**20, 2**20) for _ in range(3)]
        ref = R.gemm_ref(A, B, bias[:N])
        cuts = sorted(rng.sample(range(1, K), rng.randint(0, min(K - 1, 6)))) if K > 1 else []
        bounds = [0] + cuts + [K]
        mdl = R.AccModel(p)
        assert mdl.cfg(0, t, M, N, K, len(bounds) - 1, 1, bias, 1) == R.CR_OK
        for c in range(len(bounds) - 1):
            P = R.chunk_psums(A, B, bounds[c], bounds[c + 1])
            for m in range(M):
                kind, _ = mdl.ps(0, t, c, bounds[c + 1] - bounds[c], m, m == M - 1, (1 << N) - 1,
                                 P[m] + [0] * (3 - N))
                check(kind == "apply", "apply")
        got = [[b["wide"][n] for n in range(N)] for b in mdl.out]
        check(got == ref, f"partition invariance trial {t}")
        mdl.barrier()

    # 6. replay is a no-op; bias applied once
    mdl = R.AccModel(R.Params(rows=1, cols=1, num_tiles=1))
    mdl.cfg(0, 1, 1, 1, 3, 3, 1, [1000], 1)
    for c in range(3):
        check(mdl.ps(0, 1, c, 1, 0, 1, 1, [5])[0] == "apply", "apply chunk")
        if c < 2:
            check(mdl.ps(0, 1, c, 1, 0, 1, 1, [5])[0] == "dup", "replay dropped")
    check(mdl.out[0]["wide"][0] == 1015, "bias once + 3 chunks")

    # 7. saturate vs wrap at the boundary
    for pol, exp in ((R.SAT, R.smax(32)), (R.WRAP, R.wrap(R.smax(32) + 16384, 32))):
        mdl = R.AccModel(R.Params(rows=1, cols=1, num_tiles=1, ovf_policy=pol, strict=0))
        mdl.cfg(0, 1, 1, 1, 131072, 2, 1, [16383], 1)
        mdl.ps(0, 1, 0, 131071, 0, 1, 1, [131071 * 16384])   # = INT32_MAX exactly, no overflow
        check(mdl.perf["OVF_ACC"] == 0, "exact INT32_MAX does not overflow")
        mdl.ps(0, 1, 1, 1, 0, 1, 1, [16384])
        check(mdl.out[0]["wide"][0] == exp and mdl.out[0]["ovf"][0] == 1, f"policy {pol}")

    print(f"model self-tests: {n} brute-force widths, {len(FAILS)} failures")
    print("RESULT:", "PASS" if not FAILS else "FAIL")
    return 0 if not FAILS else 1


if __name__ == "__main__":
    sys.exit(main())
