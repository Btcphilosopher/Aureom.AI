// =============================================================================
// SilicaFlux-HPC Module 04 :: tb_hpc_scratchpad
// Self-checking testbench for hpc_scratchpad (Verilator 5 --timing and Icarus 12).
//
// Checking layers (all active in every test):
//   1. Reference memory model  rm_d/rm_p/rm_k: the physical content of the
//      scratchpad per byte (data, stored parity bit, known).  Updated at the
//      ISSUE edge of every write (the documented commit point); reads take
//      their expected data from it at their issue edge.
//   2. Transaction scoreboard  per port: accepted-not-issued ring (queued
//      mode) and issued-not-answered ring; every response is compared field
//      by field (tag, we, err, err_code, rdata, syndrome) in order.
//   3. Cycle-accurate reference of acceptance and issue: the testbench derives
//      every port's head request, decode result, response credit and the
//      per-bank arbitration (RR pointer / fixed priority, port-model slots,
//      same-row hazards) from the SPECIFICATION and requires ev_issue,
//      req_ready, ev_conflict, ev_credit_stall, ev_error, ev_bank_ops and
//      ev_bank_conflict to match it exactly, every cycle.
//   4. Response timing: rsp_valid must equal "oldest pending response exists
//      and its issue cycle + READ_LATENCY <= now" every cycle, i.e. the
//      response appears exactly READ_LATENCY cycles after issue unless the
//      port was back-pressured, and then stays valid and stable.
//   5. Independent structural checks on the DUT's ACTUAL issue set: per-bank
//      operation limit of the memory-port model and same-row hazards.
//   6. Backdoor: whole-array comparison of every bank row against the model
//      through the documented address map (inverse map), and fault injection.
//   7. Performance counters compared with the testbench's own counts.
//
// Tests (+test=<name>): smoke all_banks boundaries unaligned byte_mask conflict
// parallel backpressure reset rdw oor stall_preserve random parity perf trace.
// Other plusargs: +seed=<n> +n=<requests per port> +wl=<workload> +bp=<pct>
//                 +stim=<file> +log=<file> +bp_seed=<n>
// Classification: SIMULATION ONLY
// =============================================================================
`timescale 1ns/1ps
`include "hpc_spm_defs.svh"
`default_nettype none

/* verilator lint_off UNUSEDSIGNAL */
/* verilator lint_off UNUSEDPARAM */
/* verilator lint_off WIDTHTRUNC */
/* verilator lint_off WIDTHEXPAND */
/* verilator lint_off BLKSEQ */
/* verilator lint_off INITIALDLY */
module tb_hpc_scratchpad;
  // ------------------------------------------------------------ configuration
  parameter int          NP      = 2;
  parameter int          CAP     = 65536;
  parameter int          NB      = 2;
  parameter int          DW      = 32;
  parameter int          AW      = 32;
  parameter logic [63:0] BASE    = 64'h0;
  parameter int          RL      = 1;
  parameter int          BWE     = 1;
  parameter int          PMODE   = 0;
  parameter int          MAP     = 0;
  parameter int          ARB     = 0;
  parameter int          QD      = 0;
  parameter int          RSPD    = RL + 1;
  parameter int          WACK    = 1;
  parameter int          TAGW    = 16;
  parameter int          ECC     = 0;
  parameter int          BACKEND = 0;
  parameter int          MAXP    = 8192;

  localparam int NBY   = DW / 8;
  localparam int WORDS = CAP / NBY;
  localparam int BD    = WORDS / NB;
  localparam int PAR   = (ECC == 1) ? 1 : 0;
  localparam int LW    = 8 + PAR;
  localparam int SW    = NBY * LW;
  localparam int CNTW  = 32;
  localparam int PIQ   = 32;
  localparam int PRQ   = 128;
  localparam logic [63:0] TOPA = (AW >= 64) ? 64'hFFFF_FFFF_FFFF_FFFF : ((64'd1 << AW) - 64'd1);

  // ------------------------------------------------------------ clock / reset
  logic clk = 1'b0;
  logic rst_n = 1'b0;
  always #5 clk = ~clk;

  // ------------------------------------------------------------ DUT
  logic [NP-1:0]      req_valid, req_ready, req_we;
  logic [NP*AW-1:0]   req_addr;
  logic [NP*DW-1:0]   req_wdata;
  logic [NP*NBY-1:0]  req_wstrb;
  logic [NP*TAGW-1:0] req_tag;
  logic [NP-1:0]      rsp_valid, rsp_ready, rsp_err, rsp_we;
  logic [NP*DW-1:0]   rsp_rdata;
  logic [NP*3-1:0]    rsp_err_code;
  logic [NP*TAGW-1:0] rsp_tag;
  logic [NP*NBY-1:0]  rsp_ecc_syn;
  logic [NP-1:0]      ev_accept, ev_issue, ev_conflict, ev_credit_stall, ev_error, ev_ecc_err;
  logic [NB*2-1:0]    ev_bank_ops;
  logic [NB-1:0]      ev_bank_conflict;
  logic               perf_clear = 1'b0;
  logic [CNTW-1:0]    perf_cycles, perf_ecc_err;
  logic [NP*CNTW-1:0] perf_accept, perf_issue, perf_complete, perf_conflict, perf_wait, perf_error;
  logic [NB*CNTW-1:0] perf_bank_ops;
  logic               busy;

  hpc_scratchpad #(
    .NUM_PORTS(NP), .CAPACITY_BYTES(CAP), .NUM_BANKS(NB), .DATA_WIDTH(DW), .ADDR_WIDTH(AW), .BASE_ADDR(BASE),
    .READ_LATENCY(RL), .BYTE_WE(BWE), .PORT_MODE(PMODE), .MAP(MAP), .ARB(ARB), .QUEUE_DEPTH(QD),
    .RSP_FIFO_DEPTH(RSPD), .WRITE_ACK(WACK), .TAG_W(TAGW), .ECC_MODE(ECC), .BACKEND(BACKEND), .MACRO(0),
    .PERF_EN(1), .CNT_W(CNTW)
  ) dut (
    .clk, .rst_n,
    .req_valid, .req_ready, .req_we, .req_addr, .req_wdata, .req_wstrb, .req_tag,
    .rsp_valid, .rsp_ready, .rsp_rdata, .rsp_err, .rsp_err_code, .rsp_we, .rsp_tag, .rsp_ecc_syn,
    .ev_accept, .ev_issue, .ev_conflict, .ev_credit_stall, .ev_error, .ev_ecc_err, .ev_bank_ops, .ev_bank_conflict,
    .perf_clear, .perf_cycles, .perf_accept, .perf_issue, .perf_complete, .perf_conflict, .perf_wait,
    .perf_error, .perf_bank_ops, .perf_ecc_err, .busy
  );

  // ------------------------------------------------------------ types
  typedef struct packed {
    logic [31:0]     nb;          // not-before cycle, relative to the phase start
    logic [15:0]     gap;         // idle cycles after the previous acceptance
    logic            we;
    logic [AW-1:0]   addr;
    logic [DW-1:0]   wdata;
    logic [NBY-1:0]  wstrb;
    logic [TAGW-1:0] tag;
  } req_t;

  typedef struct packed {
    logic            we;
    logic [AW-1:0]   addr;
    logic [DW-1:0]   wdata;
    logic [NBY-1:0]  wstrb;
    logic [TAGW-1:0] tag;
    logic [31:0]     t_present;
    logic [31:0]     t_accept;
    logic [31:0]     t_issue;
    logic [2:0]      exp_code;
    logic [DW-1:0]   exp_data;
    logic [DW-1:0]   exp_known;   // 1 = bit is predictable (written or initialised)
    logic [NBY-1:0]  exp_syn;
    logic            code_known;
  } txn_t;

  // ------------------------------------------------------------ error reporting
  int    n_err = 0;
  string test_name = "smoke";
  task automatic err(input string msg);
    n_err++;
    $display("ERROR @cyc %0d (t=%0t): %s", cyc, $time, msg);
    if (n_err >= 20) begin
      $display("TEST %s FAILED errors=%0d (stopping after 20 errors)", test_name, n_err);
      $finish;
    end
  endtask

  // ------------------------------------------------------------ deterministic PRNG (identical on every simulator)
  logic [31:0] rs = 32'h1357_9BDF;
  function automatic logic [31:0] rnd();
    logic [31:0] x;
    x = rs;
    x = x ^ (x << 13);
    x = x ^ (x >> 17);
    x = x ^ (x << 5);
    rs = x;
    return x;
  endfunction
  function automatic int urange(input int n);   // 0 .. n-1
    if (n <= 1) return 0;
    return int'(rnd() % n);
  endfunction
  function automatic logic [DW-1:0] rnd_data();
    logic [DW-1:0] d;
    d = '0;
    for (int i = 0; i < (DW + 31) / 32; i++) d = (d << 32) | DW'(rnd());
    return d;
  endfunction
  function automatic int popcnt(input logic [63:0] v);
    int c;
    c = 0;
    for (int i = 0; i < 64; i++) c += int'(v[i]);
    return c;
  endfunction

  // MemoryLab bankbench back-pressure hash (memorylab.bankbench.backpressure_ready)
  function automatic bit bp_hash(input int seed, input int pct, input int m, input int c);
    logic [31:0] h;
    if (pct <= 0) return 1'b1;
    h = 32'(c) * 32'd2654435761 + 32'(m) * 32'd40503 + 32'(seed) * 32'd97 + 32'd12345;
    h = h ^ (h >> 15);
    h = h * 32'd2246822519;
    h = h ^ (h >> 13);
    return (h % 100) >= 32'(pct);
  endfunction

  // ------------------------------------------------------------ specification functions (independent of the RTL)
  function automatic logic [2:0] tb_decode(input logic we, input logic [AW-1:0] a, input logic [NBY-1:0] s);
    logic [63:0] a64;
    a64 = 64'(a);
    if (a64 < BASE || a64 >= BASE + 64'(CAP)) return `HPC_SPM_ERR_RANGE;
    if ((a64 % 64'(NBY)) != 64'd0)            return `HPC_SPM_ERR_ALIGN;
    if (BWE == 0 && we && s != {NBY{1'b1}})   return `HPC_SPM_ERR_STROBE;
    return `HPC_SPM_ERR_OK;
  endfunction
  function automatic int tb_word(input logic [AW-1:0] a);      // only for in-range aligned addresses
    return int'((64'(a) - BASE) / 64'(NBY));
  endfunction
  function automatic int tb_bank(input int w);
    if (NB == 1)  return 0;
    if (MAP == 2) return w / BD;
    if (MAP == 1) return (w % NB) ^ ((w / NB) % NB);
    return w % NB;
  endfunction
  function automatic int tb_row(input int w);
    if (NB == 1)  return w;
    if (MAP == 2) return w % BD;
    return w / NB;
  endfunction
  function automatic int tb_unmap(input int b, input int r);
    if (NB == 1)  return r;
    if (MAP == 2) return b * BD + r;
    if (MAP == 1) return r * NB + (b ^ (r % NB));
    return r * NB + b;
  endfunction
  function automatic logic [AW-1:0] waddr(input int w);
    return AW'(BASE + 64'(w) * 64'(NBY));
  endfunction

  // ------------------------------------------------------------ reference memory model (physical content)
  logic [7:0] rm_d [0:CAP-1];
  logic       rm_p [0:CAP-1];
  bit         rm_k [0:CAP-1];

  function automatic logic [SW-1:0] rm_store_word(input int w);
    logic [SW-1:0] s;
    for (int j = 0; j < NBY; j++) begin
      if (PAR != 0) s[j*LW +: LW] = {rm_p[w*NBY + j], rm_d[w*NBY + j]};
      else          s[j*LW +: LW] = rm_d[w*NBY + j];
    end
    return s;
  endfunction
  task automatic rm_init(input int mode);        // 0 = zero, 1 = pseudo-random
    for (int i = 0; i < CAP; i++) begin
      rm_d[i] = (mode == 0) ? 8'h00 : rnd() >> 24;
      rm_p[i] = ~^rm_d[i];
      rm_k[i] = 1'b1;
    end
  endtask
  task automatic rm_forget();
    for (int i = 0; i < CAP; i++) rm_k[i] = 1'b0;
  endtask

  // ------------------------------------------------------------ backdoor (whole-array fill / check, single read, bit flip)
  localparam int BD_FILL = 1, BD_CHECK = 2, BD_FLIP = 3;
  int  bd_seq = 0, bd_cmd = 0, bd_bank = 0, bd_row = 0, bd_bit = 0;
  logic [NB-1:0]    bd_ack;
  logic [NB*32-1:0] bd_mism;
  logic [NB*32-1:0] bd_unknown;

`define TB_BACKDOOR_BODY(MEMPATH) \
      int ack_seq = 0; \
      int mism = 0; \
      int unk = 0; \
      assign bd_ack[b] = (ack_seq == bd_seq); \
      assign bd_mism[b*32 +: 32] = mism; \
      assign bd_unknown[b*32 +: 32] = unk; \
      always @(bd_seq) begin \
        if (bd_seq != 0) begin \
          mism = 0; \
          unk = 0; \
          if (bd_cmd == BD_FILL) begin \
            for (int r = 0; r < BD; r++) MEMPATH[r] = rm_store_word(tb_unmap(b, r)); \
          end else if (bd_cmd == BD_CHECK) begin \
            for (int r = 0; r < BD; r++) begin \
              int w; \
              logic [SW-1:0] exp, got, kmask; \
              w = tb_unmap(b, r); \
              exp = rm_store_word(w); \
              got = MEMPATH[r]; \
              kmask = '0; \
              for (int j = 0; j < NBY; j++) if (rm_k[w*NBY + j]) kmask[j*LW +: LW] = '1; \
              if (kmask != '1) unk++; \
              if (((got ^ exp) & kmask) != '0 || ((^(got & kmask)) === 1'bx)) begin \
                if (mism < 4) $display("BACKDOOR MISMATCH bank %0d row %0d (word %0d): got %h exp %h", b, r, w, got, exp); \
                mism++; \
              end \
            end \
          end else if (bd_cmd == BD_FLIP && bd_bank == b) begin \
            MEMPATH[bd_row][bd_bit] = ~MEMPATH[bd_row][bd_bit]; \
          end \
          ack_seq = bd_seq; \
        end \
      end

  for (genvar b = 0; b < NB; b++) begin : g_bd
    if (BACKEND == 1) begin : g_fpga
      `TB_BACKDOOR_BODY(dut.g_core.g_bank[b].u_bank.g_ram.u_ram.g_fpga.u_mem.mem)
    end else begin : g_gen
      `TB_BACKDOOR_BODY(dut.g_core.g_bank[b].u_bank.g_ram.u_ram.g_generic.u_mem.mem)
    end
  end

  // The per-bank processes run when this process yields; the 1 ps delay makes
  // sure they (and the continuous bd_ack assignments) have run before the
  // acknowledgement is tested - a bare wait could see the PREVIOUS command's
  // acknowledgement and return early (found by the parity test).
  task automatic bd_do(input int cmd);
    bd_cmd = cmd;
    bd_seq = bd_seq + 1;
    #0.001;
    wait (bd_ack == {NB{1'b1}});
    if (bd_ack_seq_min() != bd_seq) err("backdoor handshake lost a command");
  endtask
  function automatic int bd_ack_seq_min();
    return (bd_ack == {NB{1'b1}}) ? bd_seq : -1;
  endfunction
  bit bd_selftest_done = 1'b0;
  task automatic bd_fill();
    bd_do(BD_FILL);
    if (!bd_selftest_done) begin
      bd_selftest_done = 1'b1;
      bd_selftest();
    end
  endtask
  // checker self-test: corrupt one array bit behind the model's back, the
  // whole-array check must report exactly one mismatching row; then undo it
  task automatic bd_selftest();
    int m;
    bd_bank = NB - 1;
    bd_row  = BD / 2;
    bd_bit  = 3;
    bd_do(BD_FLIP);
    bd_do(BD_CHECK);
    m = 0;
    for (int b = 0; b < NB; b++) m += int'(bd_mism[b*32 +: 32]);
    if (m != 1) err($sformatf("backdoor self-test: injected 1 corrupted row, checker reported %0d", m));
    else $display("  backdoor self-test: injected corruption detected (1 row), checker is live");
    bd_do(BD_FLIP);
  endtask
  task automatic bd_check(input string what);
    int m, u;
    bd_do(BD_CHECK);
    m = 0; u = 0;
    for (int b = 0; b < NB; b++) begin
      m += int'(bd_mism[b*32 +: 32]);
      u += int'(bd_unknown[b*32 +: 32]);
    end
    if (m != 0) err($sformatf("backdoor check '%s': %0d array rows differ from the reference model", what, m));
    else $display("  backdoor check '%s': all %0d rows of %0d banks match the reference model (%0d rows with unwritten bytes)", what, WORDS, NB, u);
  endtask
  // flip one stored bit: bit 0..7 = data bit of byte j, bit 8 = parity bit of byte j (ECC only)
  task automatic bd_flip(input int w, input int j, input int bitpos);
    bd_bank = tb_bank(w);
    bd_row  = tb_row(w);
    bd_bit  = j * LW + bitpos;
    if (bitpos < 8) rm_d[w*NBY + j][bitpos] = ~rm_d[w*NBY + j][bitpos];
    else            rm_p[w*NBY + j] = ~rm_p[w*NBY + j];
    bd_do(BD_FLIP);
  endtask

  // ------------------------------------------------------------ programs (per-port request lists of a phase)
  req_t            prog [0:NP-1][0:MAXP-1];
  int              plen [0:NP-1];
  logic [TAGW-1:0] next_tag [0:NP-1];
  task automatic clear_progs();
    for (int p = 0; p < NP; p++) plen[p] = 0;
  endtask
  task automatic add(input int p, input logic we, input logic [AW-1:0] a, input logic [DW-1:0] d,
                     input logic [NBY-1:0] s, input int nb = 0, input int gap = 0);
    req_t r;
    if (plen[p] >= MAXP) begin
      err("program overflow (MAXP)");
    end else begin
      r.nb = 32'(nb); r.gap = 16'(gap); r.we = we; r.addr = a; r.wdata = d; r.wstrb = s; r.tag = next_tag[p];
      next_tag[p] = next_tag[p] + 1'b1;
      prog[p][plen[p]] = r;
      plen[p] = plen[p] + 1;
    end
  endtask
  task automatic add_w(input int p, input int w, input logic [DW-1:0] d, input int nb = 0, input int gap = 0);
    add(p, 1'b1, waddr(w), d, {NBY{1'b1}}, nb, gap);
  endtask
  task automatic add_r(input int p, input int w, input int nb = 0, input int gap = 0);
    add(p, 1'b0, waddr(w), '0, '0, nb, gap);
  endtask

  // ------------------------------------------------------------ driver state
  int   cyc = 0;                 // index of the current cycle
  int   phase_start = 0;
  bit   run_on = 1'b0;
  int   pidx [0:NP-1];
  bit   cur_v [0:NP-1];
  req_t cur [0:NP-1];
  int   cur_tp [0:NP-1];
  int   last_acc [0:NP-1];
  bit   has_acc [0:NP-1];
  int   bp_mode = 0, bp_pct = 0, bp_seed = 1, bp_s0 = 0, bp_s1 = 0, bp_period = 0;
  int   n_dropped = 0;

  function automatic bit rsp_ready_fn(input int p, input int c);
    int rel;
    rel = c - phase_start;
    if (RSPD == 0) return 1'b1;                                 // no back-pressure allowed in this mode
    case (bp_mode)
      1: return bp_hash(bp_seed, bp_pct, p, rel);
      2: return !(rel >= bp_s0 && rel < bp_s1);
      3: return bp_hash(bp_seed, bp_pct, p, rel) && !(bp_period > 0 && (rel % bp_period) < bp_s1);
      default: return 1'b1;
    endcase
  endfunction

  always @(negedge clk) begin
    for (int p = 0; p < NP; p++) begin
      if (!rst_n) begin
        if (cur_v[p]) n_dropped++;
        cur_v[p] = 1'b0;
      end else if (!cur_v[p] && run_on && pidx[p] < plen[p]) begin
        req_t r;
        r = prog[p][pidx[p]];
        if ((cyc - phase_start) >= int'(r.nb) && (!has_acc[p] || cyc > last_acc[p] + int'(r.gap))) begin
          cur[p]    = r;
          cur_v[p]  = 1'b1;
          cur_tp[p] = cyc;
          pidx[p]   = pidx[p] + 1;
        end
      end
      begin
        req_t c;                                  // (local copy: Icarus 12 cannot select members of array elements)
        c = cur[p];
        req_valid[p]                = cur_v[p];
        req_we[p]                   = cur_v[p] ? c.we : 1'b0;
        req_addr[p*AW +: AW]        = c.addr;
        req_wdata[p*DW +: DW]       = c.wdata;
        req_wstrb[p*NBY +: NBY]     = c.wstrb;
        req_tag[p*TAGW +: TAGW]     = c.tag;
      end
      rsp_ready[p]                = rsp_ready_fn(p, cyc);
    end
  end

  // ------------------------------------------------------------ scoreboard state
  txn_t piq [0:NP-1][0:PIQ-1];
  int   piq_h [0:NP-1];
  int   piq_n [0:NP-1];
  txn_t prq [0:NP-1][0:PRQ-1];
  int   prq_h [0:NP-1];
  int   prq_n [0:NP-1];
  int   outst [0:NP-1];
  int   rr_ptr [0:NB-1];
  bit   live_tb = 1'b0;
  bit   in_reset = 1'b1;

  // per-cycle working arrays
  bit         hv [0:NP-1];
  txn_t       ht [0:NP-1];
  bit         hwe [0:NP-1];
  logic [AW-1:0] haddr [0:NP-1];
  logic [2:0] hcode [0:NP-1];
  int         hb [0:NP-1];
  int         hr [0:NP-1];
  bit         h_need [0:NP-1], h_can [0:NP-1], h_cred [0:NP-1], h_elig [0:NP-1];
  bit         x_iss [0:NP-1];
  int         x_ops [0:NB-1];
  bit         x_cont [0:NB-1];
  int         x_first [0:NB-1];

  // phase statistics
  int  st_acc [0:NP-1], st_iss [0:NP-1], st_cmp [0:NP-1], st_conf [0:NP-1], st_errs [0:NP-1];
  longint st_wait [0:NP-1];
  int  st_wmax [0:NP-1];
  longint st_qwait [0:NP-1];
  longint st_lat [0:NP-1];
  int  st_bank [0:NB-1];
  int  st_ecc = 0;
  longint st_bytes = 0;
  int  st_first = -1, st_last = -1;
  int  st_iss_total = 0, st_dual = 0, st_parallel = 0;

  // coverage (cumulative over the run)
  int  cv_bank_rd [0:NB-1], cv_bank_wr [0:NB-1];
  int  cv_err [0:7];
  int  cv_conflict = 0, cv_credit_stall = 0, cv_rsp_stall = 0, cv_hazard = 0, cv_dual = 0, cv_par = 0;
  int  cv_rdw_same_cycle = 0, cv_raw_next = 0, cv_reset = 0, cv_parity = 0, cv_max_outst = 0, cv_max_q = 0;
  int  cv_write_first = 0, cv_read_first = 0;
  bit  cv_strb [0:255];
  int  last_wr [0:WORDS-1];

  // trace log (+log)
  int  logfd = 0;

  // ------------------------------------------------------------ reset handling
  task automatic on_reset();
    for (int p = 0; p < NP; p++) begin
      piq_h[p] = 0; piq_n[p] = 0; prq_h[p] = 0; prq_n[p] = 0; outst[p] = 0;
      if (cur_v[p]) n_dropped++;
      cur_v[p] = 1'b0;
    end
    for (int b = 0; b < NB; b++) rr_ptr[b] = 0;
  endtask

  // ------------------------------------------------------------ per-cycle monitor
  task automatic monitor_cycle();
    // (a) head request of every port, as specified
    for (int p = 0; p < NP; p++) begin
      txn_t t;
      req_t c;
      t = '0;
      c = cur[p];
      if (QD == 0) begin
        hv[p] = cur_v[p];
        t.we = c.we; t.addr = c.addr; t.wdata = c.wdata; t.wstrb = c.wstrb; t.tag = c.tag;
        t.t_present = 32'(cur_tp[p]); t.t_accept = 32'(cyc);
      end else begin
        hv[p] = (piq_n[p] > 0);
        if (hv[p]) t = piq[p][piq_h[p]];
      end
      ht[p]    = t;
      hwe[p]   = t.we;
      haddr[p] = t.addr;
      hcode[p] = tb_decode(t.we, t.addr, t.wstrb);
      if (hv[p] && hcode[p] == `HPC_SPM_ERR_OK) begin
        hb[p] = tb_bank(tb_word(t.addr));
        hr[p] = tb_row(tb_word(t.addr));
      end else begin
        hb[p] = -1;
        hr[p] = -1;
      end
      h_need[p] = !t.we || (WACK != 0) || (hcode[p] != `HPC_SPM_ERR_OK);
      h_can[p]  = live_tb && (RSPD == 0 || outst[p] < RSPD);
      h_cred[p] = h_can[p] || (!h_need[p] && live_tb);
      h_elig[p] = hv[p] && hcode[p] == `HPC_SPM_ERR_OK && h_cred[p];
      x_iss[p]  = hv[p] && hcode[p] != `HPC_SPM_ERR_OK && h_can[p];   // decode errors need no bank
    end

    // (b) reference per-bank arbitration (specification of hpc_spm_bank_arb)
    for (int b = 0; b < NB; b++) begin
      bit a_used, b_used, a_we_l, ga, gb;
      int a_row_l, b_row_l, idx;
      a_used = 0; b_used = 0; a_we_l = 0; a_row_l = -1; b_row_l = -1;
      x_ops[b] = 0; x_cont[b] = 0; x_first[b] = -1;
      for (int k = 0; k < NP; k++) begin
        idx = (ARB == `HPC_SPM_ARB_RR) ? (rr_ptr[b] + k) % NP : k;
        ga = 0; gb = 0;
        if (h_elig[idx] && hb[idx] == b) begin
          if (PMODE == `HPC_SPM_PORT_1R1W) begin
            if (hwe[idx]) ga = !a_used && !(b_used && b_row_l == hr[idx]);
            else            gb = !b_used && !(a_used && a_row_l == hr[idx]);
            if (!ga && !gb && ((hwe[idx] && !a_used) || (!hwe[idx] && !b_used))) cv_hazard++;
          end else if (PMODE == `HPC_SPM_PORT_2RW) begin
            if (!a_used) ga = 1;
            else begin
              gb = !b_used && !(a_row_l == hr[idx] && (a_we_l || hwe[idx]));
              if (!gb && !b_used) cv_hazard++;
            end
          end else begin
            ga = !a_used;
          end
          if (ga) begin a_used = 1; a_row_l = hr[idx]; a_we_l = hwe[idx]; end
          if (gb) begin b_used = 1; b_row_l = hr[idx]; end
          if (ga || gb) begin
            x_iss[idx] = 1;
            x_ops[b]++;
            if (x_first[b] < 0) x_first[b] = idx;
          end else begin
            x_cont[b] = 1;
          end
        end
      end
    end

    // (c) compare acceptance / issue / events with the reference
    for (int p = 0; p < NP; p++) begin
      bit exp_ready, exp_conf, exp_cst;
      if (ev_issue[p] !== x_iss[p])
        err($sformatf("port %0d: ev_issue=%b, reference expects %b (head v=%0b code=%0d bank=%0d row=%0d elig=%0b can=%0b)",
                      p, ev_issue[p], x_iss[p], hv[p], hcode[p], hb[p], hr[p], h_elig[p], h_can[p]));
      exp_ready = (QD == 0) ? x_iss[p] : (live_tb && piq_n[p] < QD);
      if (req_ready[p] !== exp_ready)
        err($sformatf("port %0d: req_ready=%b, expected %b", p, req_ready[p], exp_ready));
      exp_conf = h_elig[p] && !x_iss[p];
      if (ev_conflict[p] !== exp_conf) err($sformatf("port %0d: ev_conflict=%b, expected %b", p, ev_conflict[p], exp_conf));
      exp_cst = hv[p] && live_tb && ((hcode[p] == `HPC_SPM_ERR_OK) ? !h_cred[p] : !h_can[p]);
      if (ev_credit_stall[p] !== exp_cst) err($sformatf("port %0d: ev_credit_stall=%b, expected %b", p, ev_credit_stall[p], exp_cst));
      if (ev_error[p] !== (x_iss[p] && hcode[p] != `HPC_SPM_ERR_OK)) err($sformatf("port %0d: ev_error mismatch", p));
      if (ev_accept[p] !== (req_valid[p] && req_ready[p])) err($sformatf("port %0d: ev_accept mismatch", p));
      if (exp_conf) begin cv_conflict++; st_conf[p]++; end
      if (exp_cst) cv_credit_stall++;
    end
    for (int b = 0; b < NB; b++) begin
      if (int'(ev_bank_ops[b*2 +: 2]) != x_ops[b]) err($sformatf("bank %0d: ev_bank_ops=%0d, expected %0d", b, ev_bank_ops[b*2 +: 2], x_ops[b]));
      if (ev_bank_conflict[b] !== x_cont[b]) err($sformatf("bank %0d: ev_bank_conflict=%b, expected %b", b, ev_bank_conflict[b], x_cont[b]));
    end

    // (d) independent structural check of the DUT's ACTUAL issue set
    begin
      int nrd [0:NB-1];
      int nwr [0:NB-1];
      int niss;
      for (int b = 0; b < NB; b++) begin nrd[b] = 0; nwr[b] = 0; end
      niss = 0;
      for (int p = 0; p < NP; p++) begin
        if (ev_issue[p] === 1'b1 && hv[p] && hcode[p] == `HPC_SPM_ERR_OK) begin
          niss++;
          if (hwe[p]) nwr[hb[p]]++; else nrd[hb[p]]++;
          for (int q = p + 1; q < NP; q++) begin
            if (ev_issue[q] === 1'b1 && hv[q] && hcode[q] == `HPC_SPM_ERR_OK && hb[q] == hb[p] && hr[q] == hr[p]
                && (hwe[p] || hwe[q]))
              err($sformatf("ports %0d and %0d issued a same-row access with a write to bank %0d row %0d in one cycle", p, q, hb[p], hr[p]));
          end
        end
      end
      for (int b = 0; b < NB; b++) begin
        if (PMODE == `HPC_SPM_PORT_1RW && nrd[b] + nwr[b] > 1) err($sformatf("1RW bank %0d performed %0d accesses in one cycle", b, nrd[b] + nwr[b]));
        if (PMODE == `HPC_SPM_PORT_1R1W && (nrd[b] > 1 || nwr[b] > 1)) err($sformatf("1R1W bank %0d performed %0d reads / %0d writes in one cycle", b, nrd[b], nwr[b]));
        if (PMODE == `HPC_SPM_PORT_2RW && nrd[b] + nwr[b] > 2) err($sformatf("2RW bank %0d performed %0d accesses in one cycle", b, nrd[b] + nwr[b]));
        if (nrd[b] + nwr[b] == 2) begin cv_dual++; st_dual++; end
      end
      if (niss >= 2) begin cv_par++; st_parallel++; end
    end

    // same-cycle read/write presentation of one word by two ports (read-during-write attempt)
    for (int p = 0; p < NP; p++)
      for (int q = p + 1; q < NP; q++)
        if (hv[p] && hv[q] && hcode[p] == `HPC_SPM_ERR_OK && hcode[q] == `HPC_SPM_ERR_OK &&
            haddr[p] == haddr[q] && (hwe[p] || hwe[q])) begin
          cv_rdw_same_cycle++;
          if (ev_issue[p] && !ev_issue[q]) begin if (hwe[p]) cv_write_first++; else cv_read_first++; end
          if (ev_issue[q] && !ev_issue[p]) begin if (hwe[q]) cv_write_first++; else cv_read_first++; end
        end

    // (e) responses: timing, ordering and payload
    for (int p = 0; p < NP; p++) begin
      bit exp_rv;
      txn_t f;
      f = prq[p][prq_h[p]];
      exp_rv = (prq_n[p] > 0) && (int'(f.t_issue) + RL <= cyc);
      if (rsp_valid[p] !== exp_rv)
        err($sformatf("port %0d: rsp_valid=%b, expected %b (pending=%0d, oldest issued @%0d, RL=%0d)", p, rsp_valid[p], exp_rv, prq_n[p], f.t_issue, RL));
      if (rsp_valid[p] === 1'b1 && prq_n[p] > 0) begin
        logic [DW-1:0] rd;
        logic [2:0]    code;
        rd   = rsp_rdata[p*DW +: DW];
        code = rsp_err_code[p*3 +: 3];
        if (rsp_tag[p*TAGW +: TAGW] !== f.tag) err($sformatf("port %0d: rsp_tag %h, expected %h", p, rsp_tag[p*TAGW +: TAGW], f.tag));
        if (rsp_we[p] !== f.we) err($sformatf("port %0d tag %h: rsp_we %b, expected %b", p, f.tag, rsp_we[p], f.we));
        if (f.code_known) begin
          if (code !== f.exp_code) err($sformatf("port %0d tag %h addr %h: rsp_err_code %0d, expected %0d", p, f.tag, f.addr, code, f.exp_code));
          if (rsp_err[p] !== (f.exp_code != 0)) err($sformatf("port %0d tag %h: rsp_err %b inconsistent", p, f.tag, rsp_err[p]));
          if (PAR != 0 && rsp_ecc_syn[p*NBY +: NBY] !== f.exp_syn)
            err($sformatf("port %0d tag %h: syndrome %b, expected %b", p, f.tag, rsp_ecc_syn[p*NBY +: NBY], f.exp_syn));
        end
        if (f.exp_code != 0 || f.we) begin
          if (f.code_known && rd !== '0) err($sformatf("port %0d tag %h: rdata %h must be 0 for writes/errors", p, f.tag, rd));
        end else if (((rd ^ f.exp_data) & f.exp_known) !== '0) begin
          err($sformatf("port %0d tag %h addr %h: rdata %h, expected %h (mask %h)", p, f.tag, f.addr, rd, f.exp_data, f.exp_known));
        end
        if (PAR == 0 && rsp_ecc_syn[p*NBY +: NBY] !== '0) err("syndrome must be 0 without ECC");
        if (rsp_ready[p] !== 1'b1) cv_rsp_stall++;
      end
      if (rsp_valid[p] === 1'b1 && rsp_ready[p] === 1'b1 && prq_n[p] > 0) begin
        st_cmp[p]++;
        st_lat[p] += cyc - int'(f.t_present);
        st_last = cyc - phase_start;
        if (f.code_known && f.exp_code == `HPC_SPM_ERR_PARITY) begin st_ecc++; cv_parity++; end
        if (logfd != 0) $fdisplay(logfd, "R %0d %0d %h %h %0d %0d", cyc - phase_start, p, f.tag, rsp_rdata[p*DW +: DW], rsp_err[p], rsp_we[p]);
        prq_h[p] = (prq_h[p] + 1) % PRQ;
        prq_n[p]--;
        outst[p]--;
      end
    end

    // (f) issues (DUT's actual set): reads take data before this cycle's writes commit
    begin
      txn_t it [0:NP-1];
      bit   iv [0:NP-1];
      for (int p = 0; p < NP; p++) begin
        iv[p] = 1'b0;
        if (ev_issue[p] === 1'b1) begin
          txn_t t;
          if (!hv[p]) begin
            err($sformatf("port %0d issued without a head request", p));
          end else begin
            t = ht[p];
            if (QD > 0 && int'(t.t_accept) >= cyc) err($sformatf("port %0d: queued request issued in its acceptance cycle", p));
            if (QD > 0) begin piq_h[p] = (piq_h[p] + 1) % PIQ; piq_n[p]--; end
            t.t_issue    = 32'(cyc);
            t.exp_code   = hcode[p];
            t.code_known = 1'b1;
            t.exp_data   = '0;
            t.exp_known  = {DW{1'b1}};
            t.exp_syn    = '0;
            if (hcode[p] == `HPC_SPM_ERR_OK && !t.we) begin
              int w;
              logic [DW-1:0]  ed, ek;
              logic [NBY-1:0] es;
              w  = tb_word(t.addr);
              ed = '0; ek = {DW{1'b1}}; es = '0;
              for (int j = 0; j < NBY; j++) begin
                int bi;
                bi = w * NBY + j;
                ed[j*8 +: 8] = rm_d[bi];
                if (!rm_k[bi]) begin
                  ek[j*8 +: 8] = '0;
                  if (PAR != 0) t.code_known = 1'b0;
                end else if (PAR != 0 && (^{rm_p[bi], rm_d[bi]}) == 1'b0) begin
                  es[j] = 1'b1;
                end
              end
              t.exp_data  = ed;
              t.exp_known = ek;
              t.exp_syn   = es;
              if (t.exp_syn != '0) begin
                t.exp_code = `HPC_SPM_ERR_PARITY;
                t.exp_data = '0;
              end
              if (last_wr[w] == cyc - 1) cv_raw_next++;
              cv_bank_rd[hb[p]]++;
              st_bytes += NBY;
            end
            if (hcode[p] == `HPC_SPM_ERR_OK && t.we) begin
              cv_bank_wr[hb[p]]++;
              st_bytes += popcnt(64'(t.wstrb));
              if (NBY <= 8) cv_strb[t.wstrb] = 1'b1;
            end
            if (hcode[p] == `HPC_SPM_ERR_OK) st_bank[hb[p]]++;
            else begin st_errs[p]++; cv_err[hcode[p]]++; end
            st_iss[p]++;
            st_iss_total++;
            st_wait[p]  += cyc - int'(t.t_present);
            st_qwait[p] += cyc - int'(t.t_accept);
            if (cyc - int'(t.t_present) > st_wmax[p]) st_wmax[p] = cyc - int'(t.t_present);
            it[p] = t;
            iv[p] = 1'b1;
            if (h_need[p]) begin
              if (prq_n[p] >= PRQ) err("response ring overflow (testbench)");
              prq[p][(prq_h[p] + prq_n[p]) % PRQ] = t;
              prq_n[p]++;
              outst[p]++;
              if (outst[p] > cv_max_outst) cv_max_outst = outst[p];
              if (RSPD > 0 && outst[p] > RSPD) err($sformatf("port %0d: %0d responses outstanding > RSP_FIFO_DEPTH %0d", p, outst[p], RSPD));
            end
          end
        end
      end
      // commit this cycle's writes
      for (int p = 0; p < NP; p++) begin
        txn_t x;
        logic [DW-1:0]  xd;
        logic [NBY-1:0] xs;
        x  = it[p];
        xd = x.wdata;
        xs = x.wstrb;
        if (iv[p] && x.we && x.exp_code == `HPC_SPM_ERR_OK) begin
          int w;
          w = tb_word(x.addr);
          for (int j = 0; j < NBY; j++) begin
            if (xs[j]) begin
              rm_d[w*NBY + j] = xd[j*8 +: 8];
              rm_p[w*NBY + j] = ~^xd[j*8 +: 8];
              rm_k[w*NBY + j] = 1'b1;
            end
          end
          last_wr[w] = cyc;
        end
      end
    end

    // (g) acceptances
    for (int p = 0; p < NP; p++) begin
      req_t c;
      c = cur[p];
      if (req_valid[p] && req_ready[p] === 1'b1) begin
        st_acc[p]++;
        if (st_first < 0) st_first = cur_tp[p] - phase_start;
        if (logfd != 0) $fdisplay(logfd, "A %0d %0d %h", cyc - phase_start, p, c.tag);
        if (QD > 0) begin
          txn_t t;
          t = '0;
          t.we = c.we; t.addr = c.addr; t.wdata = c.wdata; t.wstrb = c.wstrb; t.tag = c.tag;
          t.t_present = 32'(cur_tp[p]); t.t_accept = 32'(cyc);
          if (piq_n[p] >= PIQ) err("queue ring overflow (testbench)");
          piq[p][(piq_h[p] + piq_n[p]) % PIQ] = t;
          piq_n[p]++;
          if (piq_n[p] > cv_max_q) cv_max_q = piq_n[p];
          if (piq_n[p] > QD) err($sformatf("port %0d: %0d requests queued > QUEUE_DEPTH %0d", p, piq_n[p], QD));
        end
        cur_v[p]    = 1'b0;
        last_acc[p] = cyc;
        has_acc[p]  = 1'b1;
      end
      if (logfd != 0 && ev_conflict[p] === 1'b1) $fdisplay(logfd, "C %0d %0d", cyc - phase_start, p);
    end

    // (h) RR pointer of the reference arbiter
    if (ARB == `HPC_SPM_ARB_RR)
      for (int b = 0; b < NB; b++)
        if (x_first[b] >= 0) rr_ptr[b] = (x_first[b] + 1) % NP;
  endtask

  always @(posedge clk) begin
    if (!rst_n) begin
      if (!in_reset) cv_reset++;
      in_reset = 1'b1;
      live_tb  = 1'b0;
      on_reset();
    end else begin
      if (in_reset && busy !== 1'b0) err("busy must be 0 right after reset");
      in_reset = 1'b0;
      monitor_cycle();
      live_tb = 1'b1;
    end
    cyc++;
  end

  // ------------------------------------------------------------ reset injection (+ phase control)
  int rst_at = -1, rst_len = 3;
  initial begin
    forever begin
      @(negedge clk); #1;                          // after the drivers of this cycle
      if (rst_at >= 0 && cyc >= rst_at) begin
        rst_n = 1'b0;                              // asynchronous assertion, mid-cycle
        repeat (rst_len) @(negedge clk);
        #1 rst_n = 1'b1;                           // release mid-cycle
        rst_at = -1;
      end
    end
  end

  task automatic clear_stats();
    for (int p = 0; p < NP; p++) begin
      st_acc[p] = 0; st_iss[p] = 0; st_cmp[p] = 0; st_conf[p] = 0; st_errs[p] = 0;
      st_wait[p] = 0; st_wmax[p] = 0; st_qwait[p] = 0; st_lat[p] = 0;
    end
    for (int b = 0; b < NB; b++) st_bank[b] = 0;
    st_ecc = 0; st_bytes = 0; st_first = -1; st_last = -1; st_iss_total = 0; st_dual = 0; st_parallel = 0;
  endtask

  // run the programs currently loaded; returns when every request is answered
  task automatic run_phase(input string name, input int max_cycles = 2000000, input bit check_perf = 1'b1);
    int  t0, total;
    bit  done;
    bit  had_reset;
    @(posedge clk); #1;
    perf_clear = 1'b1;
    @(posedge clk); #1;
    perf_clear = 1'b0;
    for (int p = 0; p < NP; p++) begin pidx[p] = 0; has_acc[p] = 1'b0; end
    clear_stats();
    phase_start = cyc;
    had_reset = 1'b0;
    run_on = 1'b1;
    t0 = cyc;
    total = 0;
    for (int p = 0; p < NP; p++) total += plen[p];
    done = 1'b0;
    while (!done) begin
      @(posedge clk); #1;
      if (!rst_n || rst_at >= 0) had_reset = 1'b1;
      done = rst_n && rst_at < 0;
      for (int p = 0; p < NP; p++)
        if (pidx[p] < plen[p] || cur_v[p] || piq_n[p] != 0 || prq_n[p] != 0) done = 1'b0;
      if (busy !== 1'b0) done = 1'b0;
      if (cyc - t0 > max_cycles) begin
        err($sformatf("phase '%s' timed out after %0d cycles", name, max_cycles));
        done = 1'b1;
      end
    end
    run_on = 1'b0;
    if (check_perf && !had_reset) check_counters(name);
    $display("  phase %-28s %6d requests  %7d cycles  conflicts %0d", name, total, cyc - phase_start, sum_conf());
  endtask

  function automatic int sum_conf();
    int s;
    s = 0;
    for (int p = 0; p < NP; p++) s += st_conf[p];
    return s;
  endfunction

  task automatic check_counters(input string name);
    int exp_cycles;
    exp_cycles = cyc - phase_start;
    if (int'(perf_cycles) != exp_cycles) err($sformatf("%s: perf_cycles %0d, expected %0d", name, perf_cycles, exp_cycles));
    for (int p = 0; p < NP; p++) begin
      if (int'(perf_accept[p*CNTW +: CNTW])   != st_acc[p])  err($sformatf("%s: perf_accept[%0d] %0d != %0d", name, p, perf_accept[p*CNTW +: CNTW], st_acc[p]));
      if (int'(perf_issue[p*CNTW +: CNTW])    != st_iss[p])  err($sformatf("%s: perf_issue[%0d] %0d != %0d", name, p, perf_issue[p*CNTW +: CNTW], st_iss[p]));
      if (int'(perf_complete[p*CNTW +: CNTW]) != st_cmp[p])  err($sformatf("%s: perf_complete[%0d] %0d != %0d", name, p, perf_complete[p*CNTW +: CNTW], st_cmp[p]));
      if (int'(perf_conflict[p*CNTW +: CNTW]) != st_conf[p]) err($sformatf("%s: perf_conflict[%0d] %0d != %0d", name, p, perf_conflict[p*CNTW +: CNTW], st_conf[p]));
      if (longint'(perf_wait[p*CNTW +: CNTW]) != st_wait[p]) err($sformatf("%s: perf_wait[%0d] %0d != %0d", name, p, perf_wait[p*CNTW +: CNTW], st_wait[p]));
      if (int'(perf_error[p*CNTW +: CNTW])    != st_errs[p]) err($sformatf("%s: perf_error[%0d] %0d != %0d", name, p, perf_error[p*CNTW +: CNTW], st_errs[p]));
    end
    for (int b = 0; b < NB; b++)
      if (int'(perf_bank_ops[b*CNTW +: CNTW]) != st_bank[b]) err($sformatf("%s: perf_bank_ops[%0d] %0d != %0d", name, b, perf_bank_ops[b*CNTW +: CNTW], st_bank[b]));
    if (int'(perf_ecc_err) != st_ecc) err($sformatf("%s: perf_ecc_err %0d != %0d", name, perf_ecc_err, st_ecc));
  endtask

  // ------------------------------------------------------------ performance summary line
  task automatic perf_line(input string wl);
    longint acc, cmp, wsum, qsum, lsum, iss;
    int     wmax, span, slots, conf;
    real    peak;
    acc = 0; cmp = 0; wsum = 0; qsum = 0; lsum = 0; iss = 0; wmax = 0; conf = 0;
    for (int p = 0; p < NP; p++) begin
      acc += st_acc[p]; cmp += st_cmp[p]; wsum += st_wait[p]; qsum += st_qwait[p]; lsum += st_lat[p];
      iss += st_iss[p]; conf += st_conf[p];
      if (st_wmax[p] > wmax) wmax = st_wmax[p];
    end
    span  = (st_last >= st_first && st_first >= 0) ? st_last - st_first + 1 : 1;
    slots = (PMODE == 0) ? 1 : 2;
    peak  = ((NP < NB * slots) ? NP : NB * slots) * NBY;
    $write("PERF wl=%s np=%0d nb=%0d dw=%0d cap=%0d pmode=%0d map=%0d arb=%0d qd=%0d rl=%0d cycles=%0d accepted=%0d issued=%0d completed=%0d",
           wl, NP, NB, DW, CAP, PMODE, MAP, ARB, QD, RL, span, acc, iss, cmp);
    $write(" acc_per_cycle=%0.4f cmp_per_cycle=%0.4f conflict_port_cycles=%0d conflict_rate=%0.4f",
           real'(acc) / span, real'(cmp) / span, conf, (iss + conf) > 0 ? real'(conf) / real'(iss + conf) : 0.0);
    $write(" avg_wait=%0.3f max_wait=%0d avg_queue_wait=%0.3f avg_latency=%0.3f bytes=%0d bytes_per_cycle=%0.3f peak_bytes_per_cycle=%0.1f bw_efficiency=%0.4f dual_issue_cycles=%0d",
           iss > 0 ? real'(wsum) / iss : 0.0, wmax, iss > 0 ? real'(qsum) / iss : 0.0, cmp > 0 ? real'(lsum) / cmp : 0.0,
           st_bytes, real'(st_bytes) / span, peak, (real'(st_bytes) / span) / peak, st_dual);
    $write(" bank_util=");
    for (int b = 0; b < NB; b++) begin
      if (b > 0) $write(",");
      $write("%0.4f", real'(st_bank[b]) / (real'(span) * slots));
    end
    $write("\n");
  endtask

  // ============================================================ tests
  int n_req = 400;
  int seed  = 1;

  // a random valid word, optionally inside a hot window
  function automatic int rand_word(input int hot_words);
    if (hot_words > 0) return urange(hot_words);
    return urange(WORDS);
  endfunction
  function automatic logic [NBY-1:0] rand_strb();
    logic [NBY-1:0] s;
    if (BWE == 0) return {NBY{1'b1}};
    if (urange(10) < 6) return {NBY{1'b1}};
    for (int j = 0; j < NBY; j++) s[j] = rnd() >> 31;
    return s;
  endfunction
  // an address that produces a decode error of the requested kind (or a random kind)
  task automatic bad_addr(output logic [AW-1:0] addr, output bit is_strobe_err);
    int k;
    logic [63:0] a;
    is_strobe_err = 1'b0;
    k = urange(3);
    if (k == 0 && (64'(CAP) + BASE) <= TOPA) begin
      // above the window, including exact aliases of in-range words
      a = BASE + 64'(CAP) * (64'(1) + 64'(urange(3))) + 64'(urange(WORDS)) * 64'(NBY);
      if (a > TOPA) a = TOPA & ~64'(NBY - 1);
      addr = AW'(a);
    end else if (k == 1 && NBY > 1) begin
      addr = waddr(urange(WORDS)) + AW'(1 + urange(NBY - 1));
    end else if (BWE == 0) begin
      is_strobe_err = 1'b1;
      addr = waddr(urange(WORDS));
    end else if (NBY > 1) begin
      addr = waddr(urange(WORDS)) + AW'(1 + urange(NBY - 1));
    end else if ((64'(CAP) + BASE) <= TOPA) begin
      addr = AW'(BASE + 64'(CAP));
    end else begin
      addr = waddr(0);   // no error is representable in this configuration
    end
  endtask

  function automatic bit err_representable();
    return (64'(CAP) + BASE <= TOPA) || (BASE > 0) || (NBY > 1) || (BWE == 0);
  endfunction

  task automatic gen_random(input int n, input int hot_words, input int wr_pct, input int err_pct, input int max_gap);
    for (int p = 0; p < NP; p++) begin
      for (int i = 0; i < n; i++) begin
        bit we, se;
        int gap;
        we  = urange(100) < wr_pct;
        gap = (max_gap > 0) ? urange(max_gap + 1) : 0;
        if (err_pct > 0 && urange(100) < err_pct) begin
          logic [AW-1:0] a;
          logic [NBY-1:0] s;
          bad_addr(a, se);
          s = rand_strb();
          if (se) begin
            s = {NBY{1'b1}};
            if (NBY > 1) s[urange(NBY)] = 1'b0; else s = 1'b0;
            we = 1'b1;
          end
          add(p, we, a, rnd_data(), we ? s : '0, 0, gap);
        end else begin
          int w;
          w = rand_word(hot_words);
          if (we) add(p, 1'b1, waddr(w), rnd_data(), rand_strb(), 0, gap);
          else    add_r(p, w, 0, gap);
        end
      end
    end
  endtask

  // ---------------------------------------------------------------- t_smoke
  task automatic t_smoke();
    rm_init(1); bd_fill();
    clear_progs();
    for (int p = 0; p < NP; p++) begin
      for (int i = 0; i < 32; i++) add_w(p, (p * 97 + i * 5) % WORDS, rnd_data());
      for (int i = 0; i < 32; i++) add_r(p, (p * 97 + i * 5) % WORDS);
    end
    run_phase("smoke write/read");
    clear_progs();
    for (int p = 0; p < NP; p++)
      for (int i = 0; i < 32; i++) add_r(p, (((p + 1) % NP) * 97 + i * 5) % WORDS);
    run_phase("smoke cross-port read");
    bd_check("smoke");
  endtask

  // ---------------------------------------------------------------- t_all_banks: every word, every bank, mapping
  task automatic t_all_banks();
    int chunk, w0;
    rm_forget();
    chunk = MAXP * NP;
    if (chunk > 16384) chunk = 16384;
    // write every word through the ports
    for (w0 = 0; w0 < WORDS; w0 += chunk) begin
      clear_progs();
      for (int w = w0; w < w0 + chunk && w < WORDS; w++) add_w(w % NP, w, rnd_data());
      run_phase($sformatf("write words %0d..", w0));
    end
    // physical placement: every row of every bank must hold the word the documented map assigns to it
    bd_selftest();
    bd_check("address map (inverse map of every bank row)");
    // read every word back through a different port
    for (w0 = 0; w0 < WORDS; w0 += chunk) begin
      clear_progs();
      for (int w = w0; w < w0 + chunk && w < WORDS; w++) add_r((w + 1) % NP, w);
      run_phase($sformatf("read words %0d..", w0));
    end
    for (int b = 0; b < NB; b++)
      if (cv_bank_rd[b] < BD || cv_bank_wr[b] < BD) err($sformatf("bank %0d not fully covered (%0d reads, %0d writes, %0d rows)", b, cv_bank_rd[b], cv_bank_wr[b], BD));
  endtask

  // ---------------------------------------------------------------- t_boundaries
  task automatic t_boundaries();
    int ws [0:63];
    int nw;
    logic [63:0] oor [0:15];
    int no;
    rm_init(1); bd_fill();
    nw = 0;
    for (int b = 0; b < NB; b++) begin
      ws[nw++] = tb_unmap(b, 0);
      ws[nw++] = tb_unmap(b, BD - 1);
    end
    ws[nw++] = 0; ws[nw++] = WORDS - 1; ws[nw++] = WORDS / 2 - 1; ws[nw++] = WORDS / 2;
    clear_progs();
    for (int i = 0; i < nw; i++) add_w(i % NP, ws[i], rnd_data());
    for (int i = 0; i < nw; i++) add_r((i + 1) % NP, ws[i]);
    run_phase("in-range boundary words");
    // out-of-range: aliases (+CAP, +2CAP, +3CAP of first/last word), just above, top of the address space, below BASE
    no = 0;
    if (BASE + 64'(CAP) <= TOPA) begin
      oor[no++] = BASE + 64'(CAP);                                   // first byte above the window (alias of word 0)
      oor[no++] = BASE + 64'(CAP) + 64'(WORDS - 1) * 64'(NBY);         // alias of the last word
      if (BASE + 64'(3) * 64'(CAP) <= TOPA) begin
        oor[no++] = BASE + 64'(2) * 64'(CAP);
        oor[no++] = BASE + 64'(3) * 64'(CAP) + 64'(NBY);
      end
      oor[no++] = TOPA & ~64'(NBY - 1);                                 // top of the port address space
      oor[no++] = (TOPA & ~64'(CAP - 1)) | 64'(NBY);                    // alias of word 1 in the top window
    end
    if (BASE >= 64'(NBY)) oor[no++] = BASE - 64'(NBY);                  // just below the window
    if (BASE >= 64'(CAP)) oor[no++] = BASE - 64'(CAP);                  // alias of word 0 below
    clear_progs();
    for (int i = 0; i < no; i++) begin
      add(i % NP, 1'b1, AW'(oor[i]), rnd_data(), {NBY{1'b1}});
      add(i % NP, 1'b0, AW'(oor[i]), '0, '0);
    end
    run_phase($sformatf("%0d out-of-range addresses", no));
    clear_progs();
    for (int i = 0; i < nw; i++) add_r(i % NP, ws[i]);
    run_phase("boundary words unchanged");
    if (no > 0 && cv_err[`HPC_SPM_ERR_RANGE] < 2 * no) err("not every out-of-range access produced a RANGE error");
    if (no == 0) $display("  NOTE: ADDR_WIDTH = log2(CAPACITY) and BASE = 0: no out-of-range address is representable");
    bd_check("no aliasing writes");
  endtask

  // ---------------------------------------------------------------- t_unaligned
  task automatic t_unaligned();
    int n;
    rm_init(1); bd_fill();
    clear_progs();
    n = 0;
    if (NBY == 1) $display("  NOTE: DATA_WIDTH = 8: every byte address is aligned; nothing to test");
    for (int b = 0; b < NB && NBY > 1; b++) begin
      int ws [0:1];
      ws[0] = tb_unmap(b, 0);
      ws[1] = tb_unmap(b, BD - 1);
      for (int k = 0; k < 2; k++)
        for (int o = 1; o < NBY; o++) begin
          add(n % NP, 1'b1, waddr(ws[k]) + AW'(o), rnd_data(), {NBY{1'b1}});
          add(n % NP, 1'b0, waddr(ws[k]) + AW'(o), '0, '0);
          add_r(n % NP, ws[k]);
          n++;
        end
    end
    if (NBY > 1) begin
      run_phase("unaligned accesses");
      if (cv_err[`HPC_SPM_ERR_ALIGN] != 2 * n) err($sformatf("expected %0d ALIGN errors, saw %0d", 2 * n, cv_err[`HPC_SPM_ERR_ALIGN]));
    end
    bd_check("unaligned writes have no side effect");
  endtask

  // ---------------------------------------------------------------- t_byte_mask
  task automatic t_byte_mask();
    int npat, distinct;
    logic [NBY-1:0] s;
    rm_init(1); bd_fill();
    npat = (NBY <= 8) ? (1 << NBY) : 512;
    for (int base = 0; base < npat; base += 256) begin
      clear_progs();
      for (int i = base; i < base + 256 && i < npat; i++) begin
        int w, p;
        if (NBY <= 8) s = NBY'(i);
        else if (i < NBY) s = NBY'(1) << i;
        else if (i < 2 * NBY) s = ~(NBY'(1) << (i - NBY));
        else begin
          for (int j = 0; j < NBY; j++) s[j] = rnd() >> 31;
        end
        w = tb_unmap(i % NB, (i / NB) % BD);
        p = i % NP;
        add_w(p, w, rnd_data());
        add(p, 1'b1, waddr(w), rnd_data(), s);
        add_r(p, w);
      end
      run_phase($sformatf("byte masks %0d..", base));
    end
    distinct = 0;
    for (int i = 0; i < 256; i++) distinct += int'(cv_strb[i]);
    if (BWE != 0 && NBY <= 8 && distinct != (1 << NBY)) err($sformatf("only %0d of %0d strobe patterns reached the array", distinct, 1 << NBY));
    if (BWE == 0 && cv_err[`HPC_SPM_ERR_STROBE] != npat - 1) err($sformatf("BYTE_WE=0: expected %0d STROBE errors, saw %0d", npat - 1, cv_err[`HPC_SPM_ERR_STROBE]));
    bd_check("byte masks");
  endtask

  // ---------------------------------------------------------------- t_conflict
  task automatic t_conflict();
    rm_init(1); bd_fill();
    // (1) every port hammers bank 0, different rows, back to back
    clear_progs();
    for (int p = 0; p < NP; p++)
      for (int i = 0; i < n_req; i++) begin
        int w;
        w = tb_unmap(0, (p * 64 + i) % BD);
        if (urange(2) == 1) add_w(p, w, rnd_data()); else add_r(p, w);
      end
    run_phase("same bank, different rows");
    perf_line("samebank");
    if (ARB == `HPC_SPM_ARB_RR && QD == 0 && RSPD >= RL + 1) begin
      for (int p = 0; p < NP; p++)
        if (st_wmax[p] > NP - 1) err($sformatf("RR bounded wait violated: port %0d waited %0d cycles > NUM_PORTS-1 = %0d", p, st_wmax[p], NP - 1));
      $display("  RR bounded wait: max wait over ports = %0d cycles (bound NUM_PORTS-1 = %0d)", max_wmax(), NP - 1);
    end
    if (ARB == `HPC_SPM_ARB_FIXED && QD == 0) begin
      if (st_wmax[0] != 0) err($sformatf("FIXED priority: port 0 waited %0d cycles", st_wmax[0]));
      for (int p = 0; p < NP; p++) $display("  FIXED priority: port %0d avg wait %0.2f max %0d", p, real'(st_wait[p]) / (st_iss[p] > 0 ? st_iss[p] : 1), st_wmax[p]);
    end
    if (NP > 1 && cv_conflict == 0) err("no bank conflict was produced");
    // (2) same word from every port (read/write hazards, cross-port ordering)
    clear_progs();
    for (int p = 0; p < NP; p++)
      for (int i = 0; i < n_req / 2; i++) begin
        if (urange(2) == 1) add(p, 1'b1, waddr(tb_unmap(0, 3)), rnd_data(), rand_strb()); else add_r(p, tb_unmap(0, 3));
      end
    run_phase("same word, all ports");
    // (3) stride = NUM_BANKS words (all in one bank for LOW, spread for XOR)
    clear_progs();
    for (int p = 0; p < NP; p++)
      for (int i = 0; i < n_req; i++) add_r(p, ((p * 16 + i) * NB) % WORDS);
    run_phase("stride NUM_BANKS words");
    perf_line("stride");
    bd_check("conflict");
  endtask

  function automatic int max_wmax();
    int m;
    m = 0;
    for (int p = 0; p < NP; p++) if (st_wmax[p] > m) m = st_wmax[p];
    return m;
  endfunction

  // ---------------------------------------------------------------- t_parallel
  task automatic t_parallel();
    int span;
    rm_init(1); bd_fill();
    clear_progs();
    for (int p = 0; p < NP; p++)
      for (int i = 0; i < n_req; i++) begin
        int w;
        w = tb_unmap(p % NB, (i + 7 * p) % BD);
        if (i % 3 == 0) add_w(p, w, rnd_data()); else add_r(p, w);
      end
    run_phase("independent banks");
    perf_line("parallel");
    span = st_last - st_first + 1;
    if (NP <= NB) begin
      if (sum_conf() != 0) err($sformatf("independent banks: %0d conflict cycles (expected 0)", sum_conf()));
      if (RSPD >= RL + 1 && span > n_req + RL + ((QD > 0) ? 1 : 0))
        err($sformatf("independent banks: %0d requests per port took %0d cycles (expected %0d: one access per port per cycle)", n_req, span, n_req + RL + ((QD > 0) ? 1 : 0)));
      else $display("  independent banks: %0d ports x %0d requests in %0d cycles (%0.3f accesses/cycle)", NP, n_req, span, real'(NP * n_req) / span);
    end
    if (NP > 1 && NB > 1 && cv_par == 0) err("no cycle issued to more than one bank");
    bd_check("parallel");
  endtask

  // ---------------------------------------------------------------- t_backpressure
  task automatic t_backpressure();
    rm_init(1); bd_fill();
    clear_progs();
    gen_random(n_req, 0, 50, 3, 2);
    bp_mode = 3; bp_pct = 50; bp_seed = seed; bp_period = 97; bp_s1 = 25;
    run_phase("random traffic, 50% + periodic response stalls");
    bp_mode = 0;
    if (RSPD > 0 && cv_rsp_stall == 0) err("no response was back-pressured");
    if (RSPD > 0 && cv_credit_stall == 0) err("no request was stalled by response credits");
    bd_check("backpressure");
  endtask

  // ---------------------------------------------------------------- t_reset
  task automatic t_reset();
    rm_init(1); bd_fill();
    for (int it = 0; it < 4; it++) begin
      clear_progs();
      gen_random(n_req / 2, 64, 50, 2, 1);
      bp_mode = 1; bp_pct = 30; bp_seed = seed + it;
      rst_at  = cyc + 4 + 20 + urange(150);
      rst_len = 1 + urange(4);
      run_phase($sformatf("reset at cycle %0d (len %0d)", rst_at, rst_len), 2000000, 1'b0);
      bp_mode = 0;
    end
    if (cv_reset < 4) err($sformatf("only %0d resets were applied", cv_reset));
    // after the resets: array content = every write issued before a reset, none of the dropped ones
    bd_check("content after mid-traffic resets");
    clear_progs();
    for (int i = 0; i < 64; i++) add_r(i % NP, i);
    run_phase("read-back after resets");
    $display("  %0d presented requests were dropped by reset (no response expected or received)", n_dropped);
  endtask

  // ---------------------------------------------------------------- t_rdw (read-during-write)
  task automatic t_rdw();
    rm_init(1); bd_fill();
    // (1) same port, back to back: write -> read returns new, read -> write returns old
    //     (port 0 alone, so that the bank is free in the next cycle)
    clear_progs();
    for (int i = 0; i < 64; i++) begin
      int w;
      w = rand_word(0);
      add_w(0, w, rnd_data());
      add_r(0, w);
      add_r(0, w);
      add_w(0, w, rnd_data());
      add_r(0, w);
    end
    run_phase("same-port write/read back to back");
    // a read can only issue in the cycle after a write if one response credit per cycle is available
    if ((RSPD == 0 || RSPD >= RL + 1) && cv_raw_next == 0) err("no read was issued in the cycle right after a write to the same word");
    if (!(RSPD == 0 || RSPD >= RL + 1)) $display("  NOTE: RSP_FIFO_DEPTH %0d < READ_LATENCY+1: back-to-back issue impossible by design", RSPD);
    // (2) different ports present a read and a write of the same word in the same cycle
    if (NP > 1) begin
      clear_progs();
      for (int i = 0; i < 128; i++) begin
        int w, pw, pr;
        w  = tb_unmap(i % NB, urange(BD));
        pw = i % NP;
        pr = (i + 1) % NP;
        add(pw, 1'b1, waddr(w), rnd_data(), rand_strb(), i * 6);
        add(pr, 1'b0, waddr(w), '0, '0, i * 6);
        if (NP > 2) add((i + 2) % NP, 1'b1, waddr(w), rnd_data(), {NBY{1'b1}}, i * 6);
      end
      run_phase("cross-port same-cycle read/write");
      if (cv_rdw_same_cycle == 0) err("no same-cycle read/write pair was presented");
      $display("  same-cycle same-word pairs presented: %0d (write issued first %0d, read issued first %0d; never co-issued)",
               cv_rdw_same_cycle, cv_write_first, cv_read_first);
    end
    // (3) multi-port bank: same row from two ports (only reads may be co-issued)
    if (NP > 1 && PMODE != `HPC_SPM_PORT_1RW) begin
      clear_progs();
      for (int i = 0; i < 128; i++) begin
        int w;
        w = tb_unmap(0, i % BD);
        add_r(0, w, i * 4);
        if (i % 2 == 0) add_r(1, w, i * 4); else add_w(1, w, rnd_data(), i * 4);
      end
      run_phase("dual-port same-row pairs");
      if (cv_hazard == 0) err("no same-row hazard stall was exercised");
    end
    bd_check("read-during-write");
  endtask

  // ---------------------------------------------------------------- t_oor
  task automatic t_oor();
    rm_init(1); bd_fill();
    clear_progs();
    gen_random(n_req, 0, 50, 30, 1);
    bp_mode = 1; bp_pct = 30; bp_seed = seed;
    run_phase("30% erroneous requests");
    bp_mode = 0;
    if (err_representable() && cv_err[`HPC_SPM_ERR_RANGE] + cv_err[`HPC_SPM_ERR_ALIGN] + cv_err[`HPC_SPM_ERR_STROBE] == 0) err("no error response produced");
    if (!err_representable()) $display("  NOTE: byte-wide data, BYTE_WE=1 and ADDR_WIDTH = log2(CAPACITY), BASE = 0: no erroneous request is representable");
    bd_check("errors have no side effect");
  endtask

  // ---------------------------------------------------------------- t_stall_preserve
  task automatic t_stall_preserve();
    rm_init(1); bd_fill();
    clear_progs();
    gen_random(n_req / 2, 0, 50, 0, 0);
    bp_mode = 2; bp_s0 = 0; bp_s1 = 400;          // responses fully stalled for 400 cycles
    run_phase("400-cycle response stall");
    bp_mode = 0;
    // idle: nothing presented for 1000 cycles
    repeat (1000) @(posedge clk);
    bd_check("content after stall + 1000 idle cycles");
    clear_progs();
    for (int w = 0; w < WORDS && w < MAXP * NP; w++) add_r(w % NP, w);
    run_phase("front-door read-back");
  endtask

  // ---------------------------------------------------------------- t_random
  task automatic t_random();
    rm_init(1); bd_fill();
    clear_progs();
    gen_random(n_req, 32, 50, 5, 3);   // every request inside a 32-word hot window
    bp_mode = 1; bp_pct = 20; bp_seed = seed;
    run_phase("random, 32-word hot window");
    clear_progs();
    gen_random(n_req, 0, 50, 5, 1);
    run_phase("random, whole memory");
    bp_mode = 0;
    bd_check("random");
  endtask

  // ---------------------------------------------------------------- t_parity (fault injection)
  task automatic t_parity();
    int w, j, nexp;
    if (PAR == 0) begin
      $display("  ECC_MODE = NONE: no integrity logic present (rsp_ecc_syn tied to 0, checked in every test)");
    end else begin
    rm_init(1); bd_fill();
    // (1) single-bit faults in data and parity bits of every byte lane, all banks
    clear_progs();
    nexp = 0;
    for (int k = 0; k < 4 * NBY * NB && k < 256; k++) begin
      w = tb_unmap(k % NB, (k * 7) % BD);
      j = (k / NB) % NBY;
      bd_flip(w, j, k % 9);            // bits 0..7 data, 8 = stored parity bit
      add_r(k % NP, w);
      nexp++;
    end
    run_phase("single-bit faults (detected)");
    if (st_ecc != nexp) err($sformatf("expected %0d parity errors, saw %0d", nexp, st_ecc));
    // (2) repair by full write, partial write of the faulty byte, and a partial write elsewhere (still faulty)
    clear_progs();
    for (int k = 0; k < 4 * NBY * NB && k < 256; k++) begin
      w = tb_unmap(k % NB, (k * 7) % BD);
      j = (k / NB) % NBY;
      if (k % 3 == 0) add_w(k % NP, w, rnd_data());
      else if (k % 3 == 1 || NBY == 1) add(k % NP, 1'b1, waddr(w), rnd_data(), NBY'(1) << j);
      else add(k % NP, 1'b1, waddr(w), rnd_data(), ~(NBY'(1) << j));
      add_r(k % NP, w);
    end
    run_phase("repair writes");
    // (3) two flips in one byte: NOT detected (documented limitation), data is wrong
    clear_progs();
    w = tb_unmap(0, 5);
    bd_flip(w, 0, 1);
    bd_flip(w, 0, 6);
    add_r(0, w);
    // two faulty bytes in one word: syndrome has two bits
    if (NBY > 1) begin
      int w2;
      w2 = tb_unmap(NB - 1, 9);
      bd_flip(w2, 0, 0);
      bd_flip(w2, NBY - 1, 8);
      add_r(0, w2);
    end
    run_phase("double fault in one byte / two faulty bytes");
    $display("  parity: %0d detected faults; double flip in one byte returned corrupted data without error (byte parity limitation, as specified)", cv_parity);
    bd_check("parity");
    end
  endtask

  // ---------------------------------------------------------------- t_perf (workloads)
  task automatic t_perf(input string wl, input int bp);
    rm_init(1); bd_fill();
    clear_progs();
    for (int p = 0; p < NP; p++) begin
      int base;
      base = (p * WORDS) / NP;
      for (int i = 0; i < n_req; i++) begin
        int w;
        bit we;
        we = 1'b0;
        if (wl == "seq") begin                      // unit-stride streams in disjoint regions
          w = (base + i) % WORDS; we = ((i / 64) % 2) == 1;
        end else if (wl == "seqrd") begin           // unit-stride read streams
          w = (base + i) % WORDS;
        end else if (wl == "rand") begin            // uniform random, 50 % writes
          w = urange(WORDS); we = urange(2) == 1;
        end else if (wl == "stride") begin          // stride = NUM_BANKS words
          w = ((base / NB + i) * NB) % WORDS;
        end else if (wl == "stride2") begin         // stride = 2 words
          w = (base + 2 * i) % WORDS;
        end else if (wl == "samebank") begin        // everything in bank 0
          w = tb_unmap(0, (p * 97 + i) % BD); we = urange(2) == 1;
        end else if (wl == "vecdma") begin          // ports 0..NP-2: interleaved vector lanes; port NP-1: DMA write bursts
          if (p < NP - 1 || NP == 1) w = (p + i * ((NP > 1) ? NP - 1 : 1)) % (WORDS / 2);
          else begin w = WORDS / 2 + (i % (WORDS / 2)); we = 1'b1; end
        end else if (wl == "tile") begin            // 8x8 tile of a 64-word-wide matrix, one tile per port
          w = (p * 8 + ((i / 8) % 8) * 64 + (i % 8) + (i / 64) * 512) % WORDS;
        end else begin                               // hot: 16-word window
          w = urange(16); we = urange(2) == 1;
        end
        if (we) add_w(p, w, rnd_data()); else add_r(p, w);
      end
    end
    if (bp > 0) begin bp_mode = 1; bp_pct = bp; bp_seed = seed; end
    run_phase($sformatf("workload %s", wl));
    bp_mode = 0;
    perf_line(wl);
  endtask

  // ---------------------------------------------------------------- t_trace (MemoryLab / BandwidthLab stimulus format)
  task automatic t_trace(input string stim, input string logf, input int bp, input int bps);
    int fd, nm, maxn, m, n, rc;
    string tok;
    rm_init(0); bd_fill();                       // the Python models start from all-zero memory
    clear_progs();
    fd = $fopen(stim, "r");
    if (fd == 0) begin err($sformatf("cannot open stimulus %s", stim)); $finish; end
    rc = $fscanf(fd, "%d %d\n", nm, maxn);
    if (nm != NP) err($sformatf("stimulus has %0d masters, TB has %0d ports", nm, NP));
    for (int k = 0; k < nm; k++) begin
      rc = $fscanf(fd, "%s %d %d\n", tok, m, n);
      for (int i = 0; i < n; i++) begin
        int nbc, we;
        logic [63:0] wa;
        logic [DW-1:0] d;
        logic [NBY-1:0] s;
        logic [TAGW-1:0] id;
        rc = $fscanf(fd, "%d %d %h %h %h %h\n", nbc, we, wa, d, s, id);
        next_tag[m] = id;
        add(m, we[0], AW'(BASE + wa * 64'(NBY)), d, s, nbc, 0);
      end
    end
    $fclose(fd);
    logfd = $fopen(logf, "w");
    if (bp > 0) begin bp_mode = 1; bp_pct = bp; bp_seed = bps; end
    run_phase("trace");
    bp_mode = 0;
    $fclose(logfd);
    logfd = 0;
    perf_line("trace");
  endtask

  // ============================================================ main
  initial begin
    string wl, stim, logf;
    int bp, bps;
    for (int p = 0; p < NP; p++) begin
      pidx[p] = 0; plen[p] = 0; cur_v[p] = 1'b0; next_tag[p] = '0; has_acc[p] = 1'b0; last_acc[p] = 0;
      cur[p] = '0; cur_tp[p] = 0;
      req_valid[p] = 1'b0; rsp_ready[p] = 1'b1;
    end
    req_we = '0; req_addr = '0; req_wdata = '0; req_wstrb = '0; req_tag = '0;
    for (int b = 0; b < NB; b++) begin cv_bank_rd[b] = 0; cv_bank_wr[b] = 0; rr_ptr[b] = 0; end
    for (int i = 0; i < 8; i++) cv_err[i] = 0;
    for (int i = 0; i < 256; i++) cv_strb[i] = 1'b0;
    for (int i = 0; i < WORDS; i++) last_wr[i] = -10;
    for (int i = 0; i < CAP; i++) rm_k[i] = 1'b0;
    on_reset();
    if (!$value$plusargs("test=%s", test_name)) test_name = "smoke";
    if ($value$plusargs("seed=%d", seed)) rs = 32'(seed) * 32'h9E37_79B9 + 32'h1357_9BDF;
    if (rs == 0) rs = 32'h1;
    void'($value$plusargs("n=%d", n_req));
    if (!$value$plusargs("wl=%s", wl)) wl = "rand";
    if (!$value$plusargs("bp=%d", bp)) bp = 0;
    if (!$value$plusargs("bp_seed=%d", bps)) bps = 11;
    if (!$value$plusargs("stim=%s", stim)) stim = "";
    if (!$value$plusargs("log=%s", logf)) logf = "trace.log";
    $display("CONFIG test=%s seed=%0d NP=%0d CAP=%0d NB=%0d DW=%0d AW=%0d BASE=%h RL=%0d BWE=%0d PMODE=%0d MAP=%0d ARB=%0d QD=%0d RSPD=%0d WACK=%0d ECC=%0d BACKEND=%0d BANK_DEPTH=%0d",
             test_name, seed, NP, CAP, NB, DW, AW, BASE, RL, BWE, PMODE, MAP, ARB, QD, RSPD, WACK, ECC, BACKEND, BD);
    rst_n = 1'b0;
    repeat (3) @(posedge clk);
    #2 rst_n = 1'b1;
    repeat (2) @(posedge clk);

    // (if-chain, not a string case: Icarus 12 miscompiles case on strings)
    if      (test_name == "smoke")          t_smoke();
    else if (test_name == "all_banks")      t_all_banks();
    else if (test_name == "boundaries")     t_boundaries();
    else if (test_name == "unaligned")      t_unaligned();
    else if (test_name == "byte_mask")      t_byte_mask();
    else if (test_name == "conflict")       t_conflict();
    else if (test_name == "parallel")       t_parallel();
    else if (test_name == "backpressure")   t_backpressure();
    else if (test_name == "reset")          t_reset();
    else if (test_name == "rdw")            t_rdw();
    else if (test_name == "oor")            t_oor();
    else if (test_name == "stall_preserve") t_stall_preserve();
    else if (test_name == "random")         t_random();
    else if (test_name == "parity")         t_parity();
    else if (test_name == "perf")           t_perf(wl, bp);
    else if (test_name == "trace")          t_trace(stim, logf, bp, bps);
    else                                    err($sformatf("unknown test %s", test_name));

    repeat (5) @(posedge clk);
    $write("COVER");
    $write(" conflict=%0d credit_stall=%0d rsp_stall=%0d hazard=%0d dual_issue=%0d parallel_issue=%0d", cv_conflict, cv_credit_stall, cv_rsp_stall, cv_hazard, cv_dual, cv_par);
    $write(" rdw_same_cycle=%0d raw_next_cycle=%0d resets=%0d parity_err=%0d max_outstanding=%0d max_queue=%0d", cv_rdw_same_cycle, cv_raw_next, cv_reset, cv_parity, cv_max_outst, cv_max_q);
    $write(" err_range=%0d err_align=%0d err_strobe=%0d", cv_err[1], cv_err[2], cv_err[3]);
    $write(" banks_read=");
    for (int b = 0; b < NB; b++) begin if (b > 0) $write(","); $write("%0d", cv_bank_rd[b]); end
    $write(" banks_written=");
    for (int b = 0; b < NB; b++) begin if (b > 0) $write(","); $write("%0d", cv_bank_wr[b]); end
    $write("\n");
    if (n_err == 0) $display("TEST %s PASSED", test_name);
    else            $display("TEST %s FAILED errors=%0d", test_name, n_err);
    $finish;
  end

endmodule
/* verilator lint_on INITIALDLY */
/* verilator lint_on BLKSEQ */
/* verilator lint_on WIDTHEXPAND */
/* verilator lint_on WIDTHTRUNC */
/* verilator lint_on UNUSEDPARAM */
/* verilator lint_on UNUSEDSIGNAL */

`default_nettype wire
