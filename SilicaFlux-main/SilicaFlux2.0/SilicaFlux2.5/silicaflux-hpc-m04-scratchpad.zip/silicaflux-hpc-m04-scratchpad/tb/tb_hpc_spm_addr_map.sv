// =============================================================================
// SilicaFlux-HPC Module 04 :: tb_hpc_spm_addr_map
// Unit test of hpc_spm_addr_map against golden vectors produced by the Python
// reference (model/hpc_spm_map.py vectors): every vector line is
//   <addr_hex> <we> <wstrb_hex> <err_code> <bank> <row> <byte_offset>
// bank/row are compared only when err_code == 0.
// Classification: SIMULATION ONLY
// =============================================================================
`timescale 1ns/1ps
`include "hpc_spm_defs.svh"
`default_nettype none

/* verilator lint_off UNUSEDSIGNAL */
/* verilator lint_off WIDTHTRUNC */
/* verilator lint_off WIDTHEXPAND */
module tb_hpc_spm_addr_map;
  parameter int          AW   = 32;
  parameter int          CAP  = 65536;
  parameter logic [63:0] BASE = 64'h0;
  parameter int          DW   = 32;
  parameter int          NB   = 2;
  parameter int          MAP  = 0;
  parameter int          BWE  = 1;
  localparam int NBY  = DW / 8;
  localparam int CB   = $clog2(CAP);
  localparam int OFF  = $clog2(NBY);
  localparam int BW   = $clog2(NB);
  localparam int RW   = CB - OFF - BW;
  localparam int BWX  = (BW > 0) ? BW : 1;
  localparam int OFFX = (OFF > 0) ? OFF : 1;

  logic [AW-1:0]   addr;
  logic            we;
  logic [NBY-1:0]  wstrb;
  logic            ok;
  logic [2:0]      code;
  logic [BWX-1:0]  bank;
  logic [RW-1:0]   row;
  logic [OFFX-1:0] boff;

  hpc_spm_addr_map #(.ADDR_WIDTH(AW), .CAPACITY_BYTES(CAP), .BASE_ADDR(BASE), .DATA_WIDTH(DW), .NUM_BANKS(NB),
                     .MAP(MAP), .BYTE_WE(BWE)) dut (.addr, .we, .wstrb, .ok, .err_code(code), .bank, .row, .boff);

  initial begin
    string  f;
    int     fd, n, rc, e, b, r, o, nerr, wi;
    logic [63:0] a;
    logic [127:0] s;
    nerr = 0;
    if (!$value$plusargs("vec=%s", f)) f = "map_0.txt";
    fd = $fopen(f, "r");
    if (fd == 0) begin $display("TEST addr_map FAILED cannot open %s", f); $finish; end
    rc = $fscanf(fd, "%d\n", n);
    for (int i = 0; i < n; i++) begin
      rc = $fscanf(fd, "%h %d %h %d %d %d %d\n", a, wi, s, e, b, r, o);
      addr = AW'(a); we = wi[0]; wstrb = NBY'(s);
      #1;
      if (int'(code) != e || ok !== (e == 0) || (OFF > 0 && int'(boff) != o) ||
          (e == 0 && (int'(bank) != b || int'(row) != r))) begin
        nerr++;
        if (nerr < 10) $display("MISMATCH addr %h we %0d strb %h: rtl code %0d bank %0d row %0d off %0d, model %0d %0d %0d %0d",
                                a, wi, s, code, bank, row, boff, e, b, r, o);
      end
    end
    $fclose(fd);
    if (nerr == 0) $display("TEST addr_map PASSED %0d vectors", n);
    else           $display("TEST addr_map FAILED %0d of %0d vectors", nerr, n);
    $finish;
  end
endmodule
/* verilator lint_on WIDTHEXPAND */
/* verilator lint_on WIDTHTRUNC */
/* verilator lint_on UNUSEDSIGNAL */
`default_nettype wire
