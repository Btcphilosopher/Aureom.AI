# Memory inference report (Yosys)

generic  technology-independent `synth` up to (not including) memory mapping on small capacities: elaboration,
           latch check (must be zero), the inferred memories (one per bank, width x depth, read/write ports).
  fpga     block-RAM inference with Yosys' vendor flows (synth_xilinx -family xc7, synth_ecp5, synth_ice40) with
           BACKEND = FPGA: every bank must map to RAM primitives and no $mem cell (= flip-flop memory) may remain.
           RAM primitive counts are compared with the ideal count (capacity / primitive data bits).
           Inference evidence only: no vendor tool (Vivado/Quartus/Radiant), no timing closure, no board.
  asic     BACKEND = ASIC with pin-only black boxes of real open-PDK macros (SRAM Wrapper Library catalogue): the
           exact expected number of macro instances must survive synthesis and no $mem / latch may exist.  Because
           the arrays are black boxes, the remaining cells are exactly the scratchpad's control logic (arbiters,
           routing, response FIFOs, counters) - reported as the controller cost.  No LEF/GDS/liberty is used:
           cell counts are Yosys generic gates, not silicon area.
Results: reports/synth.{json,md}.

Yosys: `Yosys 0.33 (git sha1 2584903a060)`.  Vivado / Quartus / Radiant / OpenROAD: not installed - not run.

## Generic: inference and latch check

Bank arrays are the inferred memories whose depth is the bank depth (asserted count = NUM_BANKS); the other inferred memories are the per-port response-FIFO storage of `sram_rsp_path`.

| configuration | bank arrays (depth) | all inferred memories | cells (coarse) | latches | result |
|---|---|---|---|---|---|
| 2KiB 2b 2p 32bit 1RW | 2 (256 words) | 6 | 913 | 0 | PASS |
| 2KiB 2b 2p 32bit 1RW RL2 parity Q4 | 2 (256 words) | 8 | 1035 | 0 | PASS |
| 2KiB 4b 2p 32bit 1R1W | 4 (128 words) | 8 | 1697 | 0 | PASS |
| 2KiB 4b 4p 32bit 2RW | 4 (128 words) | 12 | 3509 | 0 | PASS |

## FPGA block-RAM inference

RAM equivalents: RAMB36E1 = 1, RAMB18E1 = 0.5 (xc7); DP16KD = 1 (ecp5); SB_RAM40_4K = 1 (ice40).  Ideal = stored bits / primitive bits (parity bits included for ECC_MODE = BYTE_PARITY).

| flow | configuration | RAM primitives | equiv. | ideal | LUTs | FFs | $mem left | result |
|---|---|---|---|---|---|---|---|---|
| synth_ecp5 | 64KiB 4b 2p 32bit 1RW | 32x DP16KD | 32 | 29 | 2456 | 605 | 0 | PASS |
| synth_ecp5 | 64KiB 4b 4p 32bit 1R1W | 32x DP16KD | 32 | 29 | 10688 | 1381 | 0 | PASS |
| synth_ecp5 | 64KiB 4b 4p 32bit 2RW | not mapped | - | 29 | - | - | - | **known limitation**: Yosys 0.33 memory_libmap: 'no valid mapping found' for the true-dual-port bank on DP16KD (also at 16 bit x 1024 and without byte enables); 1RW and 1R1W map on ECP5, 2RW maps on xc7. Use PORT_MODE 1RW / 1R1W on ECP5 with this tool version. (`ERROR: no valid mapping found for memory hpc_scratchpad.g_core.g_bank[0].u_bank.genblk3.g_`) |
| synth_ice40 | 8KiB 2b 2p 16bit 1RW | 16x SB_RAM40_4K | 16 | 16 | 1406 | 639 | 0 | PASS |
| synth_xilinx | 128KiB 16b 2p 32bit 1RW | 32x RAMB36E1 | 32 | 29 | 5150 | 1097 | 0 | PASS |
| synth_xilinx | 128KiB 2b 2p 32bit 1RW | 32x RAMB36E1 | 32 | 29 | 1306 | 579 | 0 | PASS |
| synth_xilinx | 128KiB 4b 2p 32bit 1RW | 32x RAMB36E1 | 32 | 29 | 1862 | 653 | 0 | PASS |
| synth_xilinx | 128KiB 4b 4p 64bit 1RW | 32x RAMB36E1 | 32 | 29 | 6728 | 1105 | 0 | PASS |
| synth_xilinx | 128KiB 8b 2p 32bit 1RW | 32x RAMB36E1 | 32 | 29 | 2856 | 801 | 0 | PASS |
| synth_xilinx | 256KiB 16b 2p 32bit 1RW | 64x RAMB36E1 | 64 | 57 | 5186 | 1097 | 0 | PASS |
| synth_xilinx | 256KiB 2b 2p 32bit 1RW | 64x RAMB36E1 | 64 | 57 | 1314 | 579 | 0 | PASS |
| synth_xilinx | 256KiB 4b 2p 32bit 1RW | 64x RAMB36E1 | 64 | 57 | 1874 | 653 | 0 | PASS |
| synth_xilinx | 256KiB 8b 2p 32bit 1RW | 64x RAMB36E1 | 64 | 57 | 2876 | 801 | 0 | PASS |
| synth_xilinx | 64KiB 16b 2p 32bit 1RW | 16x RAMB36E1 | 16 | 15 | 5118 | 1097 | 0 | PASS |
| synth_xilinx | 64KiB 1b 2p 32bit 1RW | 16x RAMB36E1 | 16 | 15 | 1046 | 542 | 0 | PASS |
| synth_xilinx | 64KiB 2b 2p 32bit 1RW | 16x RAMB36E1 | 16 | 15 | 1302 | 579 | 0 | PASS |
| synth_xilinx | 64KiB 4b 2p 32bit 1RW | 16x RAMB36E1 | 16 | 15 | 1854 | 653 | 0 | PASS |
| synth_xilinx | 64KiB 4b 2p 32bit 1RW RL2 | 16x RAMB36E1 | 16 | 15 | 1868 | 835 | 0 | PASS |
| synth_xilinx | 64KiB 4b 2p 32bit 1RW noPerf | 16x RAMB36E1 | 16 | 15 | 1245 | 77 | 0 | PASS |
| synth_xilinx | 64KiB 4b 2p 32bit 1RW parity | 16x RAMB36E1 | 16 | 16 | 2084 | 653 | 0 | PASS |
| synth_xilinx | 64KiB 4b 2p 32bit 1RW wordWE | 16x RAMB36E1 | 16 | 15 | 1850 | 653 | 0 | PASS |
| synth_xilinx | 64KiB 4b 4p 32bit 1R1W | 16x RAMB36E1 | 16 | 15 | 6216 | 1105 | 0 | PASS |
| synth_xilinx | 64KiB 4b 4p 32bit 2RW | 16x RAMB36E1 | 16 | 15 | 6184 | 1369 | 0 | PASS |
| synth_xilinx | 64KiB 8b 2p 32bit 1RW | 16x RAMB36E1 | 16 | 15 | 2840 | 801 | 0 | PASS |

## ASIC macro integrity and controller cost

| configuration | macro | expected | found | stored-width use | controller cells | controller flip-flops | result |
|---|---|---|---|---|---|---|---|
| 128KiB 8b 2p 32bit 1RW | RM_IHPSG13_1P_2048x32_c2_bm_bist (2048x32) | 16 | 16 | 32/32 bits (100.0%) | 7346 | 921 | PASS |
| 16KiB 4b 4p 32bit 1R1W | sky130_sram_2kbyte_1rw1r_32x512_8 (512x32) | 8 | 8 | 32/32 bits (100.0%) | 14234 | 1385 | PASS |
| 256KiB 8b 2p 32bit 1RW | RM_IHPSG13_1P_2048x32_c2_bm_bist (2048x32) | 32 | 32 | 32/32 bits (100.0%) | 8150 | 929 | PASS |
| 256KiB 8b 8p 32bit 1RW Q4 | RM_IHPSG13_1P_2048x32_c2_bm_bist (2048x32) | 32 | 32 | 32/32 bits (100.0%) | 34448 | 5273 | PASS |
| 64KiB 16b 2p 32bit 1RW | RM_IHPSG13_1P_1024x32_c2_bm_bist (1024x32) | 16 | 16 | 32/32 bits (100.0%) | 10964 | 1193 | PASS |
| 64KiB 2b 2p 32bit 1RW | RM_IHPSG13_1P_2048x32_c2_bm_bist (2048x32) | 8 | 8 | 32/32 bits (100.0%) | 4420 | 707 | PASS |
| 64KiB 4b 2p 32bit 1RW | RM_IHPSG13_1P_2048x32_c2_bm_bist (2048x32) | 8 | 8 | 32/32 bits (100.0%) | 5211 | 777 | PASS |
| 64KiB 4b 2p 32bit 1RW noPerf | RM_IHPSG13_1P_2048x32_c2_bm_bist (2048x32) | 8 | 8 | 32/32 bits (100.0%) | 2036 | 233 | PASS |
| 64KiB 4b 2p 32bit 1RW parity | RM_IHPSG13_1P_2048x64_c2_bm_bist (2048x64) | 8 | 8 | 36/64 bits (56.2%) | 5930 | 825 | PASS |
| 64KiB 4b 4p 32bit 2RW | RM_IHPSG13_2P_1024x32_c2_bm_bist (1024x32) | 16 | 16 | 32/32 bits (100.0%) | 16705 | 1409 | PASS |
| 64KiB 8b 2p 32bit 1RW | RM_IHPSG13_1P_2048x32_c2_bm_bist (2048x32) | 8 | 8 | 32/32 bits (100.0%) | 7093 | 913 | PASS |
