# hpc_spm_addr_map unit test (RTL vs model/hpc_spm_map.py golden vectors)

| capacity | banks | DW | AW | base | map | BYTE_WE | Verilator | Icarus |
|---|---|---|---|---|---|---|---|---|
| 65536 | 2 | 32 | 32 | 0x0 | low | 1 | TEST addr_map PASSED 4008 vectors | TEST addr_map PASSED 4008 vectors |
| 131072 | 4 | 32 | 32 | 0x0 | xor | 1 | TEST addr_map PASSED 4008 vectors | TEST addr_map PASSED 4008 vectors |
| 262144 | 8 | 64 | 32 | 0x0 | high | 1 | TEST addr_map PASSED 4008 vectors | TEST addr_map PASSED 4008 vectors |
| 262144 | 16 | 32 | 32 | 0x20040000 | xor | 1 | TEST addr_map PASSED 4009 vectors | TEST addr_map PASSED 4009 vectors |
| 65536 | 1 | 128 | 32 | 0x0 | low | 0 | TEST addr_map PASSED 4008 vectors | TEST addr_map PASSED 4008 vectors |
| 1024 | 2 | 8 | 10 | 0x0 | low | 1 | TEST addr_map PASSED 4006 vectors | TEST addr_map PASSED 4006 vectors |
| 65536 | 4 | 32 | 20 | 0x40000 | low | 0 | TEST addr_map PASSED 4009 vectors | TEST addr_map PASSED 4009 vectors |
