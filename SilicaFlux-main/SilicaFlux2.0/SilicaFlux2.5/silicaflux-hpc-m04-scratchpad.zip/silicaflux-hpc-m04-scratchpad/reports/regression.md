# hpc_scratchpad regression

Generated 2026-11-07T02:19:38Z; design+TB sha256 `05d66ddabee18fc8`; wall time 764.9 s.

| tool | version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| python | 3.13.18 |

## Lint

| kind | parameters | result | notes |
|---|---|---|---|
| verilator-lint | `defaults` | PASS | clean |
| verilator-lint | `{'NUM_PORTS': 1, 'NUM_BANKS': 1, 'DATA_WIDTH': 8, 'CAPACITY_BYTES': 1024, 'ADDR_WIDTH': 10, 'PERF_EN': 0, 'ARB': 1, 'MAP': 2}` | PASS | clean |
| verilator-lint | `{'NUM_PORTS': 8, 'NUM_BANKS': 16, 'CAPACITY_BYTES': 262144, 'PORT_MODE': 2, 'MAP': 1, 'READ_LATENCY': 3, 'QUEUE_DEPTH': 16}` | PASS | clean |
| verilator-lint | `{'NUM_PORTS': 5, 'NUM_BANKS': 8, 'DATA_WIDTH': 128, 'PORT_MODE': 1, 'ECC_MODE': 1, 'BYTE_WE': 0, 'WRITE_ACK': 0, 'RSP_FIFO_DEPTH': 0}` | PASS | clean |
| verilator-lint | `{'NUM_PORTS': 2, 'NUM_BANKS': 4, 'BACKEND': 1, 'READ_LATENCY': 2, 'ECC_MODE': 1, 'QUEUE_DEPTH': 2}` | PASS | clean |
| verilator-lint | `{'NUM_PORTS': 2, 'NUM_BANKS': 4, 'BACKEND': 2, 'MACRO': 24}` | PASS | clean |
| icarus-elab | `defaults` | PASS | clean |
| icarus-elab | `{'NUM_PORTS': 1, 'NUM_BANKS': 1, 'DATA_WIDTH': 8, 'CAPACITY_BYTES': 1024, 'ADDR_WIDTH': 10, 'PERF_EN': 0, 'ARB': 1, 'MAP': 2}` | PASS | clean |
| icarus-elab | `{'NUM_PORTS': 8, 'NUM_BANKS': 16, 'CAPACITY_BYTES': 262144, 'PORT_MODE': 2, 'MAP': 1, 'READ_LATENCY': 3, 'QUEUE_DEPTH': 16}` | PASS | clean |
| icarus-elab | `{'NUM_PORTS': 5, 'NUM_BANKS': 8, 'DATA_WIDTH': 128, 'PORT_MODE': 1, 'ECC_MODE': 1, 'BYTE_WE': 0, 'WRITE_ACK': 0, 'RSP_FIFO_DEPTH': 0}` | PASS | clean |
| icarus-elab | `{'NUM_PORTS': 2, 'NUM_BANKS': 4, 'BACKEND': 1, 'READ_LATENCY': 2, 'ECC_MODE': 1, 'QUEUE_DEPTH': 2}` | PASS | clean |

## Invalid parameter combinations (must fail elaboration with the stated message)

| overrides | expected message | result |
|---|---|---|
| `{'NUM_BANKS': 3}` | NUM_BANKS must be 1, 2, 4, 8 or 16 | rejected (PASS) |
| `{'NUM_BANKS': 32}` | NUM_BANKS must be 1, 2, 4, 8 or 16 | rejected (PASS) |
| `{'CAPACITY_BYTES': 98304}` | CAPACITY_BYTES must be a power of two | rejected (PASS) |
| `{'CAPACITY_BYTES': 64, 'NUM_BANKS': 16}` | at least 2 words | rejected (PASS) |
| `{'DATA_WIDTH': 24}` | DATA_WIDTH must be a power of two | rejected (PASS) |
| `{'DATA_WIDTH': 4}` | DATA_WIDTH must be a power of two | rejected (PASS) |
| `{'ADDR_WIDTH': 15}` | ADDR_WIDTH must be | rejected (PASS) |
| `{'BASE_ADDR': "64'h1000"}` | BASE_ADDR must be aligned | rejected (PASS) |
| `{'ADDR_WIDTH': 16, 'CAPACITY_BYTES': 65536, 'BASE_ADDR': "64'h10000"}` | BASE_ADDR does not fit | rejected (PASS) |
| `{'READ_LATENCY': 0}` | READ_LATENCY must be 1..8 | rejected (PASS) |
| `{'READ_LATENCY': 9}` | READ_LATENCY must be 1..8 | rejected (PASS) |
| `{'PORT_MODE': 3}` | unknown PORT_MODE | rejected (PASS) |
| `{'MAP': 3}` | unknown MAP | rejected (PASS) |
| `{'MAP': 1, 'NUM_BANKS': 16, 'CAPACITY_BYTES': 128}` | MAP = XOR needs | rejected (PASS) |
| `{'ARB': 2}` | unknown ARB | rejected (PASS) |
| `{'QUEUE_DEPTH': 3}` | QUEUE_DEPTH must be 0, 2, 4, 8 or 16 | rejected (PASS) |
| `{'RSP_FIFO_DEPTH': 65}` | RSP_FIFO_DEPTH must be 0..64 | rejected (PASS) |
| `{'NUM_PORTS': 0}` | NUM_PORTS must be 1..8 | rejected (PASS) |
| `{'NUM_PORTS': 9}` | NUM_PORTS must be 1..8 | rejected (PASS) |
| `{'TAG_W': 0}` | TAG_W must be 1..32 | rejected (PASS) |
| `{'ECC_MODE': 2}` | SECDED is reserved and NOT implemented | rejected (PASS) |
| `{'ECC_MODE': 7}` | unknown ECC_MODE | rejected (PASS) |
| `{'BYTE_WE': 2}` | BYTE_WE must be 0 or 1 | rejected (PASS) |
| `{'WRITE_ACK': 2}` | WRITE_ACK must be 0 or 1 | rejected (PASS) |
| `{'BACKEND': 2}` | requires an explicit MACRO | rejected (PASS) |
| `{'BACKEND': 5}` | unknown BACKEND | rejected (PASS) |
| `{'CNT_W': 4}` | CNT_W must be 8..64 | rejected (PASS) |

## stage1: 2 banks, single-port (1RW)

| configuration | smoke | all_banks | boundaries | unaligned | byte_mask | conflict | parallel | backpressure | reset | rdw | oor | stall_preserve | random | parity |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 2p 32bit 1RW LOW RR RL2 Q0 RSP3 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q4 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 3p 32bit 1RW LOW RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 2p 32bit 1RW LOW RR RL2 Q0 RSP3 FPGA | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 2p 32bit 1RW LOW FIXED RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |

133 / 133 runs passed.

## stage2: 4 banks

| configuration | smoke | all_banks | boundaries | unaligned | byte_mask | conflict | parallel | backpressure | reset | rdw | oor | stall_preserve | random | parity |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 128KiB 4b 4p 32bit 1RW LOW RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 128KiB 4b 4p 32bit 1RW LOW FIXED RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 128KiB 4b 2p 64bit 1RW LOW RR RL2 Q2 RSP3 base=0x20000000 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 4b 5p 32bit 1R1W LOW RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |

95 / 95 runs passed.

## stage3: 8 banks

| configuration | smoke | all_banks | boundaries | unaligned | byte_mask | conflict | parallel | backpressure | reset | rdw | oor | stall_preserve | random | parity |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 256KiB 8b 4p 32bit 1RW LOW RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 128KiB 8b 8p 32bit 1RW HIGH RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 8b 6p 32bit 1R1W LOW RR RL1 Q2 RSP2 parity | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |

76 / 76 runs passed.

## stage4: extended configurations

| configuration | smoke | all_banks | boundaries | unaligned | byte_mask | conflict | parallel | backpressure | reset | rdw | oor | stall_preserve | random | parity |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 256KiB 16b 8p 32bit 1RW LOW RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 1b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 4b 2p 128bit 1RW LOW RR RL3 Q0 RSP4 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 4b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 wordWE | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 4b 3p 32bit 1RW LOW RR RL1 Q2 RSP2 posted | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP0 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 1KiB 2b 2p 8bit 1RW LOW RR RL1 Q0 RSP2 AW10 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 4b 4p 32bit 2RW LOW RR RL2 Q0 RSP3 parity FPGA | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 4b 3p 32bit 1RW LOW RR RL1 Q0 RSP2 base=0x40000 AW20 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 2b 2p 32bit 1RW LOW RR RL2 Q0 RSP1 | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |
| 64KiB 16b 4p 32bit 1R1W XOR RR RL1 Q0 RSP2 FPGA | PASS | PASS | PASS | PASS | PASS | PASS | PASS | PASS ×2 | PASS ×2 | PASS | PASS ×2 | PASS | PASS ×3 | PASS |

209 / 209 runs passed.

## Icarus cross-simulation

| configuration | test | seed | result | seconds |
|---|---|---|---|---|
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | backpressure | 1 | PASS | 2.2 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | backpressure | 2 | PASS | 2.3 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | conflict | 1 | PASS | 3.1 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | random | 1 | PASS | 2.9 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | random | 2 | PASS | 3.0 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | random | 3 | PASS | 3.0 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | rdw | 1 | PASS | 1.8 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | reset | 1 | PASS | 3.0 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | reset | 2 | PASS | 2.9 |
| 128KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | smoke | 1 | PASS | 1.6 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | conflict | 1 | PASS | 7.3 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | oor | 1 | PASS | 4.3 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | oor | 2 | PASS | 4.4 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | random | 1 | PASS | 6.8 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | random | 2 | PASS | 7.0 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | random | 3 | PASS | 6.8 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | rdw | 1 | PASS | 3.8 |
| 256KiB 8b 8p 64bit 2RW XOR RR RL2 Q4 RSP3 | smoke | 1 | PASS | 2.9 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | backpressure | 2 | PASS | 1.0 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | backpressure | 1 | PASS | 1.1 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | boundaries | 1 | PASS | 0.7 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | byte_mask | 1 | PASS | 0.7 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | conflict | 1 | PASS | 1.3 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | oor | 1 | PASS | 0.9 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | oor | 2 | PASS | 1.1 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | parallel | 1 | PASS | 0.8 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | parity | 1 | PASS | 0.1 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | random | 2 | PASS | 1.3 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | random | 1 | PASS | 1.4 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | random | 3 | PASS | 1.3 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | rdw | 1 | PASS | 0.9 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | reset | 1 | PASS | 1.2 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | reset | 2 | PASS | 1.2 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | smoke | 1 | PASS | 0.8 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | unaligned | 1 | PASS | 0.8 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | byte_mask | 1 | PASS | 0.7 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | parity | 1 | PASS | 0.7 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | random | 3 | PASS | 1.3 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | random | 1 | PASS | 1.3 |
| 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | random | 2 | PASS | 1.3 |
| 64KiB 4b 2p 128bit 1RW LOW RR RL3 Q0 RSP4 | byte_mask | 1 | PASS | 1.3 |
| 64KiB 4b 2p 128bit 1RW LOW RR RL3 Q0 RSP4 | random | 1 | PASS | 1.5 |
| 64KiB 4b 2p 128bit 1RW LOW RR RL3 Q0 RSP4 | random | 2 | PASS | 1.6 |
| 64KiB 4b 2p 128bit 1RW LOW RR RL3 Q0 RSP4 | random | 3 | PASS | 1.7 |
| 64KiB 4b 2p 128bit 1RW LOW RR RL3 Q0 RSP4 | smoke | 1 | PASS | 0.6 |

## Coverage (sum over every Verilator run)

| bin | hits |
|---|---|
| conflict | 1,247,228 |
| credit_stall | 301,909 |
| dual_issue | 26,243 |
| err_align | 26,609 |
| err_range | 12,665 |
| err_strobe | 287 |
| hazard | 16,034 |
| max_outstanding | 861 |
| max_queue | 204 |
| parallel_issue | 657,612 |
| parity_err | 300 |
| raw_next_cycle | 15,220 |
| rdw_same_cycle | 159,613 |
| resets | 216 |
| rsp_stall | 319,760 |

Per-bank coverage: in 27 / 27 `all_banks` runs every row of every bank was written and read through the ports (per-bank counts in regression.json).
