# SilicaFlux-HPC Module 04 - hpc_scratchpad - verification summary

Generated 2026-11-07T02:33:59Z.  Design + testbench sha256 `05d66ddabee18fc8`.

| check | source | result |
|---|---|---|
| lint (Verilator -Wall, Icarus elaboration) | regression.md | PASS 11 / 11 |
| invalid parameter combinations rejected | regression.md | PASS 27 / 27 |
| stage1: 2 banks, single-port (1RW) | regression.md | PASS 133 / 133 runs (7 configurations) |
| stage2: 4 banks | regression.md | PASS 95 / 95 runs (5 configurations) |
| stage3: 8 banks | regression.md | PASS 76 / 76 runs (4 configurations) |
| stage4: extended configurations | regression.md | PASS 209 / 209 runs (11 configurations) |
| Icarus cross-simulation | regression.md | PASS 45 / 45 runs |
| backdoor whole-array comparisons (each run proved its checker live) | regression.json | 489 |
| address decoder vs Python model (Verilator and Icarus) | unit_addr_map.md | PASS 7 / 7 configurations |
| mutation testing (injected bugs detected) | mutation.md | PASS 26 / 26 mutants killed |
| synthesis: generic inference + latch check | synth.md | PASS 4 / 4 |
| synthesis: FPGA block-RAM inference | synth.md | PASS 23 / 24 (+1 documented tool limitation) |
| synthesis: ASIC macro integrity | synth.md | PASS 11 / 11 |
| performance runs (each self-checking) | perf.md | PASS 190 / 190 runs |
| cycle-exact vs BandwidthLab BankedSram (1RW) | bwlab_compare.md | PASS 63 / 63 runs, 73,500 transactions |
| cycle-exact vs sram_bank_controller RTL | bwlab_compare.md | PASS 42 / 42 runs |

**Overall: ALL CHECKS PASS.**

## Tools

| tool | version |
|---|---|
| verilator | Verilator 5.020 2024-01-01 rev (Debian 5.020-1) |
| iverilog | Icarus Verilog version 12.0 (stable) () |
| yosys | Yosys 0.33 (git sha1 2584903a060) |
| python | 3.13.18 |

Not available / not run: Vivado, Quartus, Radiant, OpenROAD, Liberty-based ASIC synthesis, SymbiYosys (formal), gate-level simulation, FPGA hardware. No clock frequency, silicon area or power is claimed.

