# Mutation testing

**26 / 26 mutants killed.**  Each mutant is one deliberate bug in a copy of rtl/; the delivered RTL is never modified.

| id | injected bug | config | killed by | first error reported |
|---|---|---|---|---|
| M01 | RR pointer never advances (RR degenerates to fixed priority) | 64KiB 2b 3p 32bit 1RW LOW RR RL1 Q0 RSP2 | conflict | `ERROR @cyc 8 (t=85000): port 0: ev_issue=1, reference expects 0 (head v=1 code=0 bank=0 row=1 elig=1 can=1)` |
| M02 | 1RW bank grants every requester (two accesses per cycle on a single-port bank) | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | conflict, oor, rdw, backpressure, random | `ERROR @cyc 7 (t=75000): port 1: ev_issue=1, reference expects 0 (head v=1 code=0 bank=0 row=64 elig=1 can=1)` |
| M03 | 2RW same-row write hazard not checked | 64KiB 4b 4p 32bit 2RW LOW RR RL1 Q0 RSP2 | rdw, conflict, random | `[3305000] %Error: sram_generic_2rw.sv:93: Assertion failed in TOP.tb_hpc_scratchpad.dut.g_core.g_bank[0].u_bank.g_ram.u_ram.g_generic.u_mem: TOP.tb_hp` |
| M04 | 1R1W read/write same-row hazard not checked | 64KiB 4b 4p 32bit 1R1W LOW RR RL1 Q0 RSP2 | rdw, conflict, random | `ERROR @cyc 330 (t=3305000): port 2: ev_issue=1, reference expects 0 (head v=1 code=0 bank=0 row=2352 elig=1 can=1)` |
| M05 | range check removed (out-of-range addresses wrap onto in-range words) | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | oor, backpressure, random | `ERROR @cyc 16 (t=165000): port 1: ev_issue=0, reference expects 1 (head v=1 code=1 bank=-1 row=-1 elig=0 can=1)` |
| M06 | LOW map uses the wrong word bit for the bank | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | smoke, random | `ERROR @cyc 7 (t=75000): port 1: ev_issue=0, reference expects 1 (head v=1 code=0 bank=1 row=48 elig=1 can=1)` |
| M07 | alignment check removed | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | oor, backpressure, random | `ERROR @cyc 9 (t=95000): port 1: ev_issue=0, reference expects 1 (head v=1 code=2 bank=-1 row=-1 elig=0 can=1)` |
| M08 | BYTE_WE = 0 strobe rule removed | 64KiB 4b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 wordWE | byte_mask, oor | `ERROR @cyc 8 (t=85000): port 0: ev_error mismatch` |
| M09 | byte write enables ignored (whole word written) | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | byte_mask, random | `ERROR @cyc 10 (t=105000): port 0 tag 0002 addr 00000000: rdata c79a1bf7, expected 4f1c7909 (mask ffffffff)` |
| M10 | read data routed to port 0 regardless of owner | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | smoke, random | `ERROR @cyc 40 (t=405000): port 0 tag 0020 addr 00000000: rdata 7f7e7deb, expected 4f1c7909 (mask ffffffff)` |
| M11 | decode-error requests reach the banks | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | oor, random | `ERROR @cyc 9 (t=95000): port 1: ev_conflict=1, expected 0` |
| M12 | response credits ignored | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | backpressure, stall_preserve | `ERROR @cyc 11 (t=115000): port 0: ev_issue=1, reference expects 0 (head v=1 code=0 bank=1 row=6515 elig=0 can=0)` |
| M13 | request queue accepts while full | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q2 RSP2 | backpressure, conflict, stall_preserve | `[145000] %Error: dma_fifo.sv:50: Assertion failed in TOP.tb_hpc_scratchpad.dut.g_core.g_front[1].g_queue.u_queue: dma_fifo: push while full` |
| M14 | parity check disabled (no syndrome) | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | parity | `ERROR @cyc 8 (t=85000): port 0 tag 0000 addr 00000000: rsp_err_code 0, expected 4` |
| M15 | parity encoded even instead of odd | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | smoke, parity | `ERROR @cyc 40 (t=405000): port 0 tag 0020 addr 00000000: rsp_err_code 4, expected 0` |
| M16 | wait counter counts accepted cycles too | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | conflict | `ERROR @cyc 808 (t=8076000): same bank, different rows: perf_wait[0] 799 != 399` |
| M17 | conflict event never raised | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | conflict | `ERROR @cyc 7 (t=75000): port 1: ev_conflict=0, expected 1` |
| M18 | decode error code dropped from the response | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | oor | `ERROR @cyc 10 (t=105000): port 1 tag 0001 addr 000007ef: rsp_err_code 0, expected 2` |
| M19 | read data not zeroed on error responses | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 parity | parity | `ERROR @cyc 8 (t=85000): port 0 tag 0000: rdata b40e2735 must be 0 for writes/errors` |
| M20 | fixed priority reversed (highest port wins) | 64KiB 2b 3p 32bit 1RW LOW FIXED RL1 Q0 RSP2 | conflict | `ERROR @cyc 7 (t=75000): port 0: ev_issue=0, reference expects 1 (head v=1 code=0 bank=0 row=0 elig=1 can=1)` |
| M21 | XOR map degenerates (bank = 0 for every word) | 64KiB 4b 4p 32bit 1RW XOR RR RL1 Q0 RSP2 | smoke, random | `ERROR @cyc 7 (t=75000): port 1: ev_issue=0, reference expects 1 (head v=1 code=0 bank=1 row=24 elig=1 can=1)` |
| M22 | decode-error requests issued without a response credit | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q0 RSP2 | oor, backpressure | `ERROR @cyc 20 (t=205000): port 1: ev_issue=1, reference expects 0 (head v=1 code=2 bank=-1 row=-1 elig=0 can=0)` |
| M23 | HIGH map row taken from the wrong bits | 128KiB 8b 4p 32bit 1RW HIGH RR RL1 Q0 RSP2 | smoke, random | `ERROR @cyc 395 (t=3946000): backdoor check 'smoke': 223 array rows differ from the reference model` |
| M24 | bank slot B write data taken from slot A (2RW) | 64KiB 4b 4p 32bit 2RW LOW RR RL1 Q0 RSP2 | random, conflict | `ERROR @cyc 46 (t=465000): port 2 tag 000e addr 0000004c: rdata 00000000, expected 1bf7d844 (mask ffffffff)` |
| M25 | per-port ev_bank_ops counts only slot A | 64KiB 4b 4p 32bit 2RW LOW RR RL1 Q0 RSP2 | conflict, random | `ERROR @cyc 7 (t=75000): bank 0: ev_bank_ops=1, expected 2` |
| M26 | queue pops on acceptance instead of issue | 64KiB 2b 2p 32bit 1RW LOW RR RL1 Q4 RSP2 | smoke, conflict | `ERROR @cyc 72 (t=725000): port 0: ev_issue=1, reference expects 0 (head v=0 code=0 bank=-1 row=-1 elig=0 can=1)` |
