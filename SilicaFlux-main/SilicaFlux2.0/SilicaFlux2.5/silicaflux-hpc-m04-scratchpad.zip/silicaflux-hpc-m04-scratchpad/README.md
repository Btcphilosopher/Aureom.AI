# SilicaFlux-HPC · Module 04 — Banked High-Bandwidth Scratchpad Memory

**Primary source:** `rtl/hpc_scratchpad.sv` · Aureom.AI | SilicaFlux-HPC

A synthesizable, parameterised, banked scratchpad SRAM for the SilicaFlux-HPC compute tile: `NUM_PORTS` ready/valid
requester ports (vector-array lanes and the DMA engine), `NUM_BANKS` independent banks, a documented byte-address →
bank/row map, deterministic per-bank arbitration that never exceeds a bank's physical port model, tagged in-order
responses with back-pressure and error codes, optional byte parity, and three interchangeable bank implementations
(GENERIC simulation model, FPGA block-RAM inference, ASIC macros) taken unmodified from the **SilicaFlux SRAM Wrapper
Library**.

Built as the brief asks: the **two-bank single-port design was verified first** (stage 1), then scaled to four
(stage 2) and eight banks (stage 3), then to the extended configurations (stage 4: 1 and 16 banks, 1R1W / 2RW banks,
parity, FPGA backend, word-write memory, posted writes, …).

## Results (all from `reports/`, final run on the frozen RTL)

| Check | Result |
|---|---|
| Stage 1 — 2 banks, single-port (7 configurations) | **133 / 133** runs pass |
| Stage 2 — 4 banks (5 configurations) | **95 / 95** |
| Stage 3 — 8 banks (4 configurations) | **76 / 76** |
| Stage 4 — 1 / 16 banks, 1R1W / 2RW, parity, FPGA backend, word-write, posted writes, … (11 configurations) | **209 / 209** |
| Icarus cross-simulation | **45 / 45** |
| Lint (Verilator `-Wall`, Icarus) / invalid parameter combinations rejected | **11 / 11**, **27 / 27** |
| Mutation testing (injected design bugs detected) | **26 / 26** killed |
| Address decoder vs Python reference model (Verilator + Icarus) | **7 / 7** configurations, ~28 k vectors |
| Cycle-exact vs BandwidthLab `BankedSram` (1RW) | **63 / 63** runs, 73,500 transactions identical |
| Cycle-exact vs the verified `sram_bank_controller` RTL | **42 / 42** runs identical |
| FPGA block-RAM inference (Yosys xc7 / ecp5 / ice40) | **23 / 24**, ideal BRAM count everywhere; 1 documented Yosys ECP5 true-dual-port limitation |
| ASIC macro integrity (IHP SG13G2, SKY130 black boxes) | **11 / 11** exact macro counts, no flip-flop memory |
| Performance runs (self-checking) | **190 / 190** |

Headline performance (RTL, cycle-accurate; doc 07): four unit-stride streams reach 3.99 accesses/cycle (99.8 % of
peak) from 4 banks on; uniform random traffic from 4 ports gives 1.75 / 2.61 / 3.23 / 3.61 accesses/cycle with
2 / 4 / 8 / 16 banks; the XOR map turns the stride-equals-bank-count pathology from 1.0 into 3.99 accesses/cycle but
costs unit-stride streaming; request queues add latency, not bandwidth.


## Interface at a glance

```
hpc_scratchpad #(NUM_PORTS=2, CAPACITY_BYTES=65536, NUM_BANKS=2, DATA_WIDTH=32, ADDR_WIDTH=32, BASE_ADDR=0,
                 READ_LATENCY=1, BYTE_WE=1, PORT_MODE=1RW|1R1W|2RW, MAP=LOW|XOR|HIGH, ARB=RR|FIXED,
                 QUEUE_DEPTH=0|2|4|8|16, RSP_FIFO_DEPTH=READ_LATENCY+1, WRITE_ACK=1, TAG_W=8,
                 ECC_MODE=NONE|BYTE_PARITY, BACKEND=GENERIC|FPGA|ASIC, MACRO=0, PERF_EN=1, CNT_W=32)
  clk, rst_n
  per port: req_valid/req_ready  req_we req_addr req_wdata req_wstrb req_tag
            rsp_valid/rsp_ready  rsp_rdata rsp_err rsp_err_code[2:0] rsp_we rsp_tag rsp_ecc_syn
  events:   ev_accept ev_issue ev_conflict ev_credit_stall ev_error ev_ecc_err ev_bank_ops ev_bank_conflict
  counters: perf_clear perf_cycles perf_accept perf_issue perf_complete perf_conflict perf_wait perf_error
            perf_bank_ops perf_ecc_err;  busy
```

**Exact timing** (`QUEUE_DEPTH = 0`): a request presented in cycle *t* and granted is accepted **and issued** at edge
*t*; a write **commits at edge *t***; a read samples the array at edge *t*; the response (read data, write ack or
error) is **valid in cycle *t* + READ_LATENCY** unless the port's response channel is back-pressured. With a request
queue, issue happens at the earliest one cycle after acceptance. A read issued at a later edge than a write — from any
port — returns the written data; a read and a write of the same bank row are never issued at the same edge. Details:
`docs/01_architecture_and_interface.md`.

## Brief → where it is met

| § | Requirement | Where |
|---|---|---|
| 1 | Repository audit, reuse of verified modules, no ASIC macros assumed in the FPGA flow | `docs/00_repository_audit.md`; `third_party/` (unmodified, SHA-256) |
| 2 | Capacity, banks, data width, address width, read latency, byte write enables, port configuration; 64/128/256 KiB × 1/2/4/8/16 banks; invalid combinations rejected | parameters in `rtl/hpc_scratchpad.sv`, doc 01 §2; `model/hpc_spm_map.py check`; 27 negative elaboration tests |
| 3 | Documented byte address → bank / row / byte offset; interleaved map + alternative (XOR) + contiguous (HIGH); aligned and explicitly-defined unaligned behaviour; no silent wrap | `rtl/hpc_spm_addr_map.sv`, `docs/02_address_map.md`, `reports/unit_addr_map.md` |
| 4 | Ready/valid request and response; reads, writes, byte enables, tags, back-pressure, error responses; exact commit / response cycles | doc 01 §3-§6 |
| 5 | Simultaneous different-bank access; deterministic same-bank arbitration, request preservation, back-pressure, conflict events; per-bank port-model limit | `rtl/hpc_spm_bank_arb.sv`, `docs/03_banking_and_arbitration.md` |
| 6 | Synthesis-compatible RAM coding, BRAM inference, no large flip-flop memories, separate ASIC wrapper path, read-during-write differences | `rtl/hpc_spm_bank.sv` + SRAM Wrapper Library backends, `docs/04_fpga_asic_memory_mapping.md`, **memory inference report `reports/synth.md`** |
| 7 | ECC interface reserved, no unbacked claims | `docs/05_integrity_ecc.md`: byte parity implemented and fault-injected; SECDED reserved and rejected at elaboration |
| 8 | Every bank, boundaries, read/write, byte masks, conflicts, independent banks, back-pressure, reset, read-during-write, out-of-range, preservation under stalls; reference model + scoreboard | `tb/tb_hpc_scratchpad.sv`, `docs/06_verification.md`, `reports/regression.md`, `reports/mutation.md` |
| 9 | Accepted / completed accesses per cycle, bank utilisation, conflict cycles, queue waiting time, effective bandwidth; comparison with BandwidthLab | `docs/07_performance.md`, `reports/perf.md`, `reports/bwlab_compare.md` |
| 10 | Deliverables | table below |

## Deliverables

| Deliverable | Files |
|---|---|
| `hpc_scratchpad.sv` | `rtl/hpc_scratchpad.sv` (+ `rtl/hpc_spm_defs.svh`) |
| Bank controller and arbitration logic | `rtl/hpc_spm_bank_arb.sv` (per-bank arbiter), `rtl/hpc_spm_bank.sv` (bank + integrity encode + backend selection), `rtl/hpc_spm_addr_map.sv`, `rtl/hpc_spm_perf.sv` |
| FPGA memory mapping | `BACKEND = FPGA` path (library inference templates), `docs/04_fpga_asic_memory_mapping.md` §2, `reports/synth.md` (xc7 / ecp5 / ice40 primitive counts vs ideal) |
| Reference model | `model/hpc_spm_map.py` (address map + configuration rules, golden vectors); testbench reference memory model, reference arbiter and scoreboard (`tb/tb_hpc_scratchpad.sv`); external references: BandwidthLab `BankedSram` and the library's `sram_bank_controller` (`scripts/bwlab_compare.py`) |
| Testbench | `tb/tb_hpc_scratchpad.sv` (14 tests + perf + trace modes), `tb/tb_hpc_spm_addr_map.sv`; scripts in `scripts/` |
| Memory inference report | `reports/synth.md` / `.json` (generated), discussed in doc 04 |
| Documentation | `docs/00` … `docs/08`, `reports/SUMMARY.md` |

## Quick start

```bash
make spm-map        # address-map model checks
make spm-unit       # decoder vs model, Verilator + Icarus
make spm-quick      # lint + invalid parameters + stage 1 (2 banks, single port)
make spm-test       # full staged regression + Icarus
make spm-mutants    # 26 injected bugs
make spm-synth      # Yosys: inference, FPGA BRAM mapping, ASIC macro integrity
make spm-perf       # performance sweep
BANDWIDTHLAB=<silicaflux-bandwidthlab dir> SRAMLIB=<silicaflux-sramlib dir> make spm-bwlab
make spm-report     # reports/SUMMARY.md
make spm-sim TEST=conflict
```

Tools: Verilator 5.020, Icarus Verilog 12, Yosys 0.33, Python ≥ 3.10 (numpy for BandwidthLab). Place this directory
anywhere; it is self-contained (`third_party/` holds the reused sources).

## Files

```
rtl/        hpc_scratchpad.sv  hpc_spm_addr_map.sv  hpc_spm_bank_arb.sv  hpc_spm_bank.sv  hpc_spm_perf.sv  hpc_spm_defs.svh
tb/         tb_hpc_scratchpad.sv  tb_hpc_spm_addr_map.sv
model/      hpc_spm_map.py
scripts/    common.py run_regress.py run_unit.py run_mutants.py run_synth.py run_perf.py bwlab_compare.py make_report.py
docs/       00_repository_audit 01_architecture_and_interface 02_address_map 03_banking_and_arbitration
            04_fpga_asic_memory_mapping 05_integrity_ecc 06_verification 07_performance 08_integration_and_next_actions
reports/    SUMMARY regression unit_addr_map mutation synth perf bwlab_compare (.md + .json, generated)
third_party/silicaflux-sramlib (RTL subset + docs, unmodified)  silicaflux-datafabric/rtl/dma/dma_fifo.sv (unmodified)
            SHA256SUMS
Makefile
```

## What is not claimed

No clock frequency, silicon area or power (no timing closure, no Liberty / LEF flow, no vendor FPGA tool); no
formal proof of the new RTL; no gate-level simulation; no hardware run; no SECDED. FPGA results are Yosys inference
evidence; ASIC results are macro-integrity checks and generic gate counts. See doc 06 §7 and doc 08 §3.
