#!/usr/bin/env python3
"""Mutation testing: does the testbench detect deliberately injected design bugs?

Every mutant is one textual change to a copy of rtl/ (never the delivered files).  It is built with Verilator and run
on the tests listed with it; the mutant is KILLED when at least one test fails.  A surviving mutant would mean a
checking gap.  Results: reports/mutation.{json,md}.
"""
from __future__ import annotations

import concurrent.futures as cf
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (BUILD, REPORTS, RTL, RTL_FILES, cfg_label, parse_sim, provenance, run, sim_cmd,  # noqa: E402
                    verilator_build, write_json)

BASE_TESTS = ["smoke", "conflict", "oor", "byte_mask", "rdw", "backpressure", "random"]

# (id, description, file, old, new, config, tests)
MUTANTS = [
    ("M01", "RR pointer never advances (RR degenerates to fixed priority)", "hpc_spm_bank_arb.sv",
     "else if (first_found) ptr_q <= (first_idx == LAST_P) ? '0 : first_idx + 1'b1;", "else if (first_found) ptr_q <= ptr_q;",
     dict(NP=3), ["conflict"]),
    ("M02", "1RW bank grants every requester (two accesses per cycle on a single-port bank)", "hpc_spm_bank_arb.sv",
     "          g_a = !any_a;\n        end", "          g_a = 1'b1;\n        end", dict(), BASE_TESTS),
    ("M03", "2RW same-row write hazard not checked", "hpc_spm_bank_arb.sv",
     "else         g_b = !any_b && !(a_row == r && (a_we || we[idx]));", "else         g_b = !any_b;",
     dict(NP=4, NB=4, PMODE=2), ["rdw", "conflict", "random"]),
    ("M04", "1R1W read/write same-row hazard not checked", "hpc_spm_bank_arb.sv",
     "if (we[idx]) g_a = !any_a && !(any_b && b_row == r);", "if (we[idx]) g_a = !any_a;",
     dict(NP=4, NB=4, PMODE=1), ["rdw", "conflict", "random"]),
    ("M05", "range check removed (out-of-range addresses wrap onto in-range words)", "hpc_spm_addr_map.sv",
     "assign in_range = (addr[ADDR_WIDTH-1:CB] == BASE_HI);", "assign in_range = 1'b1;", dict(), BASE_TESTS),
    ("M06", "LOW map uses the wrong word bit for the bank", "hpc_spm_addr_map.sv",
     "    assign bank = word[BW-1:0];\n    assign row  = word[WAW-1:BW];\n  end\n\n", "    assign bank = word[BW:1];\n    assign row  = word[WAW-1:BW];\n  end\n\n",
     dict(), ["smoke", "random"]),
    ("M07", "alignment check removed", "hpc_spm_addr_map.sv",
     "wire misaligned = (OFF > 0) && (boff != '0);", "wire misaligned = 1'b0;", dict(), BASE_TESTS),
    ("M08", "BYTE_WE = 0 strobe rule removed", "hpc_spm_addr_map.sv",
     "wire bad_strobe = (BYTE_WE == 0) && we && (wstrb != {NBYTES{1'b1}});", "wire bad_strobe = 1'b0;",
     dict(NB=4, BWE=0), ["byte_mask", "oor"]),
    ("M09", "byte write enables ignored (whole word written)", "hpc_spm_bank.sv",
     "    assign a_m = a_wstrb;", "    assign a_m = '1;", dict(), ["byte_mask", "random"]),
    ("M10", "read data routed to port 0 regardless of owner", "hpc_scratchpad.sv",
     "own_ia[(b*READ_LATENCY)*PW +: PW] <= b_idx_a[b*PW +: PW];", "own_ia[(b*READ_LATENCY)*PW +: PW] <= '0;",
     dict(), ["smoke", "random"]),
    ("M11", "decode-error requests reach the banks", "hpc_scratchpad.sv",
     "assign p_elig[p]   = h_valid[p] && h_ok[p] && p_credit[p];", "assign p_elig[p]   = h_valid[p] && p_credit[p];",
     dict(), ["oor", "random"]),
    ("M12", "response credits ignored", "hpc_scratchpad.sv",
     "assign p_credit[p] = p_can[p] || (!p_need[p] && live_q);", "assign p_credit[p] = live_q;",
     dict(), ["backpressure", "stall_preserve"]),
    ("M13", "request queue accepts while full", "hpc_scratchpad.sv",
     "assign req_ready[p] = live_q && (cnt != QD);", "assign req_ready[p] = live_q;",
     dict(QD=2), ["backpressure", "conflict", "stall_preserve"]),
    ("M14", "parity check disabled (no syndrome)", "hpc_scratchpad.sv",
     "assign syn_stage[l] = ~^p_raw[p*STORE_W + l*LANE_W +: LANE_W];", "assign syn_stage[l] = 1'b0;",
     dict(ECC=1), ["parity"]),
    ("M15", "parity encoded even instead of odd", "hpc_spm_bank.sv",
     "assign a_sw[l*LANE_W +: LANE_W] = {~^a_wdata[l*8 +: 8], a_wdata[l*8 +: 8]};",
     "assign a_sw[l*LANE_W +: LANE_W] = {^a_wdata[l*8 +: 8], a_wdata[l*8 +: 8]};", dict(ECC=1), ["smoke", "parity"]),
    ("M16", "wait counter counts accepted cycles too", "hpc_scratchpad.sv",
     "assign p_wait_inc[p*WCW +: WCW]            = WCW'(req_valid[p] && !p_issue[p]);",
     "assign p_wait_inc[p*WCW +: WCW]            = WCW'(req_valid[p]);", dict(), ["conflict"]),
    ("M17", "conflict event never raised", "hpc_scratchpad.sv",
     "assign ev_conflict[p]     = p_elig[p] && !p_gnt[p];", "assign ev_conflict[p]     = 1'b0;", dict(), ["conflict"]),
    ("M18", "decode error code dropped from the response", "hpc_scratchpad.sv",
     "if (out_id[TAG_W +: 3] != `HPC_SPM_ERR_OK) code = out_id[TAG_W +: 3];", "if (1'b0) code = out_id[TAG_W +: 3];",
     dict(), ["oor"]),
    ("M19", "read data not zeroed on error responses", "hpc_scratchpad.sv",
     "(code != `HPC_SPM_ERR_OK) ? '0 : out[DATA_WIDTH-1:0];", "out[DATA_WIDTH-1:0];", dict(ECC=1), ["parity"]),
    ("M20", "fixed priority reversed (highest port wins)", "hpc_spm_bank_arb.sv",
     "idx = (ARB == `HPC_SPM_ARB_RR) ? ({{(32-PW){1'b0}}, ptr_q} + k) : k;",
     "idx = (ARB == `HPC_SPM_ARB_RR) ? ({{(32-PW){1'b0}}, ptr_q} + k) : NUM_PORTS - 1 - k;", dict(NP=3, ARB=1), ["conflict"]),
    ("M21", "XOR map degenerates (bank = 0 for every word)", "hpc_spm_addr_map.sv",
     "assign bank = word[BW-1:0] ^ word[2*BW-1:BW];", "assign bank = word[BW-1:0] ^ word[BW-1:0];",
     dict(NP=4, NB=4, MAP=1), ["smoke", "random"]),
    ("M22", "decode-error requests issued without a response credit", "hpc_scratchpad.sv",
     "assign p_issue[p]  = p_gnt[p] || (h_valid[p] && !h_ok[p] && p_can[p]);",
     "assign p_issue[p]  = p_gnt[p] || (h_valid[p] && !h_ok[p] && live_q);", dict(), ["oor", "backpressure"]),
    ("M23", "HIGH map row taken from the wrong bits", "hpc_spm_addr_map.sv",
     "    assign row  = word[RW-1:0];", "    assign row  = {word[RW-2:0], word[RW-1]};", dict(NP=4, NB=8, CAP=131072, MAP=2),
     ["smoke", "random"]),
    ("M24", "bank slot B write data taken from slot A (2RW)", "hpc_scratchpad.sv",
     "          b_wd  = b_wd  | h_wdata[p*DATA_WIDTH +: DATA_WIDTH];", "          b_wd  = a_wd;",
     dict(NP=4, NB=4, PMODE=2), ["random", "conflict"]),
    ("M25", "per-port ev_bank_ops counts only slot A", "hpc_scratchpad.sv",
     "assign ev_bank_ops[b*2 +: 2] = {1'b0, b_any_a[b]} + {1'b0, b_any_b[b]};", "assign ev_bank_ops[b*2 +: 2] = {1'b0, b_any_a[b]};",
     dict(NP=4, NB=4, PMODE=2), ["conflict", "random"]),
    ("M26", "queue pops on acceptance instead of issue", "hpc_scratchpad.sv",
     ".pop(p_issue[p]), .rdata(q_head), .count(cnt)", ".pop(push && cnt != '0), .rdata(q_head), .count(cnt)",
     dict(QD=4), ["smoke", "conflict"]),
]


def build_mutant(m) -> tuple[Path | None, str]:
    mid, desc, fname, old, new, cfg, tests = m
    d = BUILD / "mut" / mid
    if d.exists():
        shutil.rmtree(d)
    (d / "rtl").mkdir(parents=True)
    for f in RTL.iterdir():
        shutil.copy(f, d / "rtl" / f.name)
    src = (d / "rtl" / fname).read_text()
    n = src.count(old)
    if n != 1:
        return None, f"mutation pattern found {n} times (must be exactly 1)"
    (d / "rtl" / fname).write_text(src.replace(old, new))
    files = [d / "rtl" / f.name if f.parent == RTL else f for f in RTL_FILES]
    try:
        return verilator_build(cfg, tag=f"mutant-{mid}", rtl_files=files), ""
    except RuntimeError as e:
        return None, f"build failed: {e}"


def run_mutant(m) -> dict:
    mid, desc, fname, old, new, cfg, tests = m
    exe, why = build_mutant(m)
    r = {"id": mid, "description": desc, "file": fname, "config": cfg_label(cfg), "tests": tests}
    if exe is None:
        r.update(killed=False, status=why, killing_tests=[])
        return r
    kills = []
    for t in tests:
        rc, out, _ = run(sim_cmd("verilator", exe, [f"+test={t}", "+seed=1"]), timeout=1800,
                         log=BUILD / "mut" / mid / f"{t}.log")
        res = parse_sim(out)
        if rc != 0 or not res["pass"]:
            first = next((ln for ln in out.splitlines() if "ERROR" in ln or "Assertion" in ln or "%Error" in ln), "")
            kills.append({"test": t, "first_error": first[:220]})
    r.update(killed=bool(kills), status="KILLED" if kills else "SURVIVED", killing_tests=kills)
    return r


def main() -> int:
    with cf.ThreadPoolExecutor(max_workers=2) as ex:
        res = list(ex.map(run_mutant, MUTANTS))
    for r in res:
        print(f"{r['id']} {r['status']:8s} {r['description']}  [{', '.join(k['test'] for k in r['killing_tests'])}]")
    n_k = sum(r["killed"] for r in res)
    write_json(REPORTS / "mutation.json", {"provenance": provenance(), "mutants": res, "killed": n_k, "total": len(res)})
    L = ["# Mutation testing", "", f"**{n_k} / {len(res)} mutants killed.**  Each mutant is one deliberate bug in a copy of "
         "rtl/; the delivered RTL is never modified.", "",
         "| id | injected bug | config | killed by | first error reported |", "|---|---|---|---|---|"]
    for r in res:
        k = r["killing_tests"]
        L.append(f"| {r['id']} | {r['description']} | {r['config']} | {', '.join(x['test'] for x in k) or '**SURVIVED**'} | "
                 f"`{(k[0]['first_error'] if k else r['status']).replace('|', '/')[:150]}` |")
    (REPORTS / "mutation.md").write_text("\n".join(L) + "\n")
    return 0 if n_k == len(res) else 1


if __name__ == "__main__":
    sys.exit(main())
