#!/usr/bin/env python3
"""Yosys synthesis of hpc_scratchpad: memory inference report.

  generic  technology-independent `synth` up to (not including) memory mapping on small capacities: elaboration,
           latch check (must be zero), the inferred memories (one per bank, width x depth, read/write ports).
  fpga     block-RAM inference with Yosys' vendor flows (synth_xilinx -family xc7, synth_ecp5, synth_ice40) with
           BACKEND = FPGA: every bank must map to RAM primitives and no $mem cell (= flip-flop memory) may remain.
           RAM primitive counts are compared with the ideal count (capacity / primitive data bits).
           Inference evidence only: no vendor tool (Vivado/Quartus/Radiant), no timing closure, no board.
  asic     BACKEND = ASIC with pin-only black boxes of real open-PDK macros (SRAM Wrapper Library catalogue): the
           exact expected number of macro instances must survive synthesis and no $mem / latch may exist.  Because
           the arrays are black boxes, the remaining cells are exactly the scratchpad's control logic (arbiters,
           routing, response FIFOs, counters) - reported as the controller cost.  No LEF/GDS/liberty is used:
           cell counts are Yosys generic gates, not silicon area.
Results: reports/synth.{json,md}.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import math
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, INCDIRS, REPORTS, RTL_FILES, STUBS, provenance, run, write_json  # noqa: E402

TOP = "hpc_scratchpad"


def reads(stubs: bool) -> str:
    files = [*RTL_FILES] + ([STUBS] if stubs else [])
    return (f"read_verilog -defer -sv -DSYNTHESIS " + " ".join(f"-I{p}" for p in INCDIRS) + " "
            + " ".join(str(f) for f in files))


def chparam(p: dict) -> str:
    return f"hierarchy -top {TOP} " + " ".join(f"-chparam {k} {v}" for k, v in p.items()) + "; "


def cell_counts(log: str) -> dict[str, int]:
    blocks = log.split("Number of cells:")
    if len(blocks) < 2:
        return {}
    last = blocks[-1]
    out = {"_total": int(re.match(r"\s*(\d+)", last).group(1))}
    for m in re.finditer(r"^\s+(\S+)\s+(\d+)\s*$", last, re.M):
        out[m.group(1)] = int(m.group(2))
    return out


def label(p: dict) -> str:
    cap = p.get("CAPACITY_BYTES", 65536)
    s = f"{cap // 1024 if cap >= 1024 else cap}{'KiB' if cap >= 1024 else 'B'} {p.get('NUM_BANKS', 2)}b {p.get('NUM_PORTS', 2)}p {p.get('DATA_WIDTH', 32)}bit"
    s += " " + {0: "1RW", 1: "1R1W", 2: "2RW"}[p.get("PORT_MODE", 0)]
    for k, v, t in [("READ_LATENCY", 1, "RL{}"), ("ECC_MODE", 0, "parity"), ("BYTE_WE", 1, "wordWE"),
                    ("QUEUE_DEPTH", 0, "Q{}"), ("PERF_EN", 1, "noPerf")]:
        if p.get(k, v) != v:
            s += " " + (t.format(p[k]) if "{}" in t else t)
    return s


# ------------------------------------------------------------------ job lists
GENERIC = [
    dict(CAPACITY_BYTES=2048, NUM_BANKS=2),
    dict(CAPACITY_BYTES=2048, NUM_BANKS=4, PORT_MODE=1),
    dict(CAPACITY_BYTES=2048, NUM_BANKS=4, PORT_MODE=2, NUM_PORTS=4),
    dict(CAPACITY_BYTES=2048, NUM_BANKS=2, ECC_MODE=1, QUEUE_DEPTH=4, READ_LATENCY=2),
]

XC7 = ("synth_xilinx -family xc7", r"RAMB(18|36)E1", 36864)    # RAMB36E1 = 36 Kbit incl. parity
ECP5 = ("synth_ecp5", r"DP16KD|PDPW16KD", 18432)
ICE40 = ("synth_ice40", r"SB_RAM40_4K", 4096)
FPGA = []
for cap, nbs in [(65536, (1, 2, 4, 8, 16)), (131072, (2, 4, 8, 16)), (262144, (2, 4, 8, 16))]:
    for nb in nbs:
        FPGA.append((XC7, dict(BACKEND=1, CAPACITY_BYTES=cap, NUM_BANKS=nb)))
FPGA += [
    (XC7, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, READ_LATENCY=2)),
    (XC7, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, PORT_MODE=1, NUM_PORTS=4)),
    (XC7, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, PORT_MODE=2, NUM_PORTS=4)),
    (XC7, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, ECC_MODE=1)),
    (XC7, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, BYTE_WE=0)),
    (XC7, dict(BACKEND=1, CAPACITY_BYTES=131072, NUM_BANKS=4, DATA_WIDTH=64, NUM_PORTS=4)),
    (XC7, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, PERF_EN=0)),
    (ECP5, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4)),
    (ECP5, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, PORT_MODE=1, NUM_PORTS=4)),
    (ECP5, dict(BACKEND=1, CAPACITY_BYTES=65536, NUM_BANKS=4, PORT_MODE=2, NUM_PORTS=4)),
    (ICE40, dict(BACKEND=1, CAPACITY_BYTES=8192, NUM_BANKS=2, DATA_WIDTH=16)),
]
# configurations whose failure is a known, documented tool limitation (reported as such, never as PASS)
KNOWN_LIMITATIONS = {
    ("synth_ecp5", "64KiB 4b 4p 32bit 2RW"):
        "Yosys 0.33 memory_libmap: 'no valid mapping found' for the true-dual-port bank on DP16KD (also at 16 bit x 1024 "
        "and without byte enables); 1RW and 1R1W map on ECP5, 2RW maps on xc7. Use PORT_MODE 1RW / 1R1W on ECP5 with this "
        "tool version.",
}

# (params, macro module, macro words, macro width)
IHP1P_2048x32 = ("RM_IHPSG13_1P_2048x32_c2_bm_bist", 2048, 32)
IHP1P_1024x32 = ("RM_IHPSG13_1P_1024x32_c2_bm_bist", 1024, 32)
IHP1P_2048x64 = ("RM_IHPSG13_1P_2048x64_c2_bm_bist", 2048, 64)
IHP2P_1024x32 = ("RM_IHPSG13_2P_1024x32_c2_bm_bist", 1024, 32)
SKY_32x512 = ("sky130_sram_2kbyte_1rw1r_32x512_8", 512, 32)
ASIC = [
    (dict(CAPACITY_BYTES=65536, NUM_BANKS=2, MACRO=24), IHP1P_2048x32),
    (dict(CAPACITY_BYTES=65536, NUM_BANKS=4, MACRO=24), IHP1P_2048x32),
    (dict(CAPACITY_BYTES=65536, NUM_BANKS=8, MACRO=24), IHP1P_2048x32),
    (dict(CAPACITY_BYTES=65536, NUM_BANKS=16, MACRO=21), IHP1P_1024x32),
    (dict(CAPACITY_BYTES=131072, NUM_BANKS=8, MACRO=24), IHP1P_2048x32),
    (dict(CAPACITY_BYTES=262144, NUM_BANKS=8, MACRO=24), IHP1P_2048x32),
    (dict(CAPACITY_BYTES=262144, NUM_BANKS=8, MACRO=24, NUM_PORTS=8, QUEUE_DEPTH=4), IHP1P_2048x32),
    (dict(CAPACITY_BYTES=65536, NUM_BANKS=4, MACRO=61, PORT_MODE=2, NUM_PORTS=4), IHP2P_1024x32),
    (dict(CAPACITY_BYTES=16384, NUM_BANKS=4, MACRO=2, PORT_MODE=1, NUM_PORTS=4), SKY_32x512),
    (dict(CAPACITY_BYTES=65536, NUM_BANKS=4, MACRO=25, ECC_MODE=1), IHP1P_2048x64),
    (dict(CAPACITY_BYTES=65536, NUM_BANKS=4, MACRO=24, PERF_EN=0), IHP1P_2048x32),
]


def jobdir(kind: str, p: dict, extra: str = "") -> Path:
    d = BUILD / "synth" / (kind + "_" + re.sub(r"\W+", "_", label(p) + extra))
    d.mkdir(parents=True, exist_ok=True)
    return d


def job_generic(p: dict) -> dict:
    d = jobdir("generic", p)
    nb = p.get("NUM_BANKS", 2)
    depth = p["CAPACITY_BYTES"] // (p.get("DATA_WIDTH", 32) // 8) // nb
    # the bank arrays are the $mem_v2 cells whose SIZE is the bank depth (the others are response-FIFO storage)
    ys = (f"{reads(False)}; {chparam(p)}proc; flatten; opt_clean; select -assert-none t:$dlatch t:$adlatch; "
          f"memory -nomap; opt_clean; select -assert-count {nb} t:$mem_v2 r:SIZE={depth} %i; stat")
    rc, out, dt = run(["yosys", "-q", "-l", d / "yosys.log", "-p", ys], cwd=d, timeout=3600)
    log = (d / "yosys.log").read_text() if (d / "yosys.log").exists() else out
    cc = cell_counts(log)
    mems = re.findall(r"^\s+\$mem_v2\s+(\d+)", log.split("Number of cells:")[-1], re.M)
    return {"suite": "generic", "label": label(p), "params": p, "rc": rc, "seconds": round(dt, 1),
            "mem_cells": int(mems[0]) if mems else 0, "bank_mems": nb if rc == 0 else None, "bank_depth": depth,
            "cells_total": cc.get("_total"), "result": "PASS" if rc == 0 else "FAIL", "cmd": "yosys -p '" + ys + "'"}


def job_fpga(flow, p: dict) -> dict:
    (cmd, prim, prim_bits) = flow
    d = jobdir("fpga_" + cmd.split()[0], p)
    ys = f"{reads(False)}; {chparam(p)}{cmd} -top {TOP}; select -assert-none t:$mem t:$mem_v2; stat"
    rc, out, dt = run(["yosys", "-q", "-l", d / "yosys.log", "-p", ys], cwd=d, timeout=5400)
    log = (d / "yosys.log").read_text() if (d / "yosys.log").exists() else out
    cc = cell_counts(log)
    prims = {k: v for k, v in cc.items() if re.fullmatch(prim, k)}
    luts = sum(v for k, v in cc.items() if re.match(r"(LUT\d|SB_LUT4|LUT4)$", k))
    ffs = sum(v for k, v in cc.items() if re.match(r"(FD[A-Z]*|SB_DFF\w*|TRELLIS_FF)$", k))
    store_bits = p["CAPACITY_BYTES"] * 8 * (9 / 8 if p.get("ECC_MODE", 0) else 1)
    # RAMB18 counts as half a RAMB36
    eq = sum(v * (0.5 if "18" in k else 1) for k, v in prims.items())
    ideal = math.ceil(store_bits / prim_bits)
    result = "PASS" if rc == 0 and eq > 0 else "FAIL"
    note = KNOWN_LIMITATIONS.get((cmd.split()[0], label(p)), "")
    if result == "FAIL" and note:
        result = "KNOWN-LIMITATION"
    err = next((ln for ln in log.splitlines() if ln.startswith("ERROR")), "")
    return {"suite": "fpga", "flow": cmd, "label": label(p), "params": p, "rc": rc, "seconds": round(dt, 1),
            "ram_primitives": prims, "ram_equiv": eq, "ram_ideal": ideal, "luts": luts, "ffs": ffs,
            "cells_total": cc.get("_total"), "result": result, "note": note, "error": err[:300],
            "cmd": "yosys -p '" + ys + "'", "log_tail": "" if rc == 0 else log[-1500:]}


def job_asic(p: dict, macro) -> dict:
    name, words, width = macro
    nb = p["NUM_BANKS"]
    dw = p.get("DATA_WIDTH", 32)
    store_w = dw * 9 // 8 if p.get("ECC_MODE", 0) else dw
    bank_depth = p["CAPACITY_BYTES"] // (dw // 8) // nb
    expected = nb * math.ceil(bank_depth / words) * math.ceil(store_w / width)
    q = dict(p, BACKEND=2)
    d = jobdir("asic", q, "_" + name)
    ys = (f"{reads(True)}; {chparam(q)}synth -top {TOP} -flatten; select -assert-count {expected} t:{name}; "
          f"select -assert-none t:$mem t:$mem_v2; select -assert-none t:$_DLATCH*; stat")
    rc, out, dt = run(["yosys", "-q", "-l", d / "yosys.log", "-p", ys], cwd=d, timeout=5400)
    log = (d / "yosys.log").read_text() if (d / "yosys.log").exists() else out
    cc = cell_counts(log)
    found = cc.get(name, 0)
    ffs = sum(v for k, v in cc.items() if "DFF" in k)
    return {"suite": "asic", "label": label(q), "params": q, "macro": name, "macro_geometry": f"{words}x{width}",
            "expected_instances": expected, "found_instances": found, "glue_cells": (cc.get("_total") or 0) - found,
            "glue_flip_flops": ffs, "store_width": store_w, "bits_used_pct": round(100 * store_w / (math.ceil(store_w / width) * width), 1),
            "rc": rc, "seconds": round(dt, 1), "result": "PASS" if rc == 0 and found == expected else "FAIL",
            "cmd": "yosys -p '" + ys + "'", "log_tail": "" if rc == 0 else log[-1500:]}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--suite", default="generic,fpga,asic")
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    suites = a.suite.split(",")
    futs = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        if "generic" in suites:
            futs += [ex.submit(job_generic, p) for p in GENERIC]
        if "asic" in suites:
            futs += [ex.submit(job_asic, p, m) for p, m in ASIC]
        if "fpga" in suites:
            futs += [ex.submit(job_fpga, f, p) for f, p in FPGA]
        recs = []
        for f in cf.as_completed(futs):
            r = f.result()
            recs.append(r)
            if r["suite"] == "generic":
                extra = f"mem cells {r['mem_cells']}"
            elif r["suite"] == "fpga":
                extra = f"{r['ram_primitives']} LUT {r['luts']} FF {r['ffs']}"
            else:
                extra = f"macros {r['found_instances']}/{r['expected_instances']} glue cells {r['glue_cells']}"
            print(f"[{r['suite']}] {r['result']} {r['label']} {extra} ({r['seconds']} s)", flush=True)
    order = {"generic": 0, "fpga": 1, "asic": 2}
    recs.sort(key=lambda r: (order[r["suite"]], r.get("flow", ""), r["label"]))
    write_json(REPORTS / "synth.json", {"provenance": provenance(), "records": recs})
    write_md(recs)
    return 0 if all(r["result"] in ("PASS", "KNOWN-LIMITATION") for r in recs) else 1


def write_md(recs: list[dict]) -> None:
    pv = provenance()
    L = ["# Memory inference report (Yosys)", "", __doc__.split("\n\n", 1)[1].strip(), "",
         f"Yosys: `{pv['tools']['yosys']}`.  Vivado / Quartus / Radiant / OpenROAD: not installed - not run.", ""]
    g = [r for r in recs if r["suite"] == "generic"]
    if g:
        L += ["## Generic: inference and latch check", "",
              "Bank arrays are the inferred memories whose depth is the bank depth (asserted count = NUM_BANKS); the other "
              "inferred memories are the per-port response-FIFO storage of `sram_rsp_path`.", "",
              "| configuration | bank arrays (depth) | all inferred memories | cells (coarse) | latches | result |",
              "|---|---|---|---|---|---|"]
        L += [f"| {r['label']} | {r['bank_mems']} ({r['bank_depth']} words) | {r['mem_cells']} | {r['cells_total']} | 0 | {r['result']} |" for r in g]
    f = [r for r in recs if r["suite"] == "fpga"]
    if f:
        L += ["", "## FPGA block-RAM inference", "",
              "RAM equivalents: RAMB36E1 = 1, RAMB18E1 = 0.5 (xc7); DP16KD = 1 (ecp5); SB_RAM40_4K = 1 (ice40).  Ideal = "
              "stored bits / primitive bits (parity bits included for ECC_MODE = BYTE_PARITY).", "",
              "| flow | configuration | RAM primitives | equiv. | ideal | LUTs | FFs | $mem left | result |",
              "|---|---|---|---|---|---|---|---|---|"]
        for r in f:
            prims = ", ".join(f"{v}x {k}" for k, v in r["ram_primitives"].items())
            if r["result"] == "KNOWN-LIMITATION":
                L.append(f"| {r['flow'].split()[0]} | {r['label']} | not mapped | - | {r['ram_ideal']} | - | - | - | "
                         f"**known limitation**: {r['note']} (`{r['error'][:90]}`) |")
            else:
                L.append(f"| {r['flow'].split()[0]} | {r['label']} | {prims} | {r['ram_equiv']:g} | {r['ram_ideal']} | {r['luts']} | "
                         f"{r['ffs']} | 0 | {r['result']} |")
    a = [r for r in recs if r["suite"] == "asic"]
    if a:
        L += ["", "## ASIC macro integrity and controller cost", "",
              "| configuration | macro | expected | found | stored-width use | controller cells | controller flip-flops | result |",
              "|---|---|---|---|---|---|---|---|"]
        for r in a:
            L.append(f"| {r['label']} | {r['macro']} ({r['macro_geometry']}) | {r['expected_instances']} | {r['found_instances']} | "
                     f"{r['store_width']}/{math.ceil(r['store_width'] / int(r['macro_geometry'].split('x')[1])) * int(r['macro_geometry'].split('x')[1])} bits ({r['bits_used_pct']}%) | "
                     f"{r['glue_cells']} | {r['glue_flip_flops']} | {r['result']} |")
    (REPORTS / "synth.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
