#!/usr/bin/env bash
# Package the module: SHA256SUMS of every delivered file, then a zip next to this directory (build/ excluded).
set -euo pipefail
here="$(cd "$(dirname "$0")/.." && pwd)"
name="$(basename "$here")"
cd "$here"
find . -type f ! -path './build/*' ! -name SHA256SUMS ! -name '*.pyc' ! -path '*/__pycache__/*' | LC_ALL=C sort | \
  xargs sha256sum > SHA256SUMS
cd ..
rm -f "$name.zip"
zip -qr "$name.zip" "$name" -x "$name/build/*" "*/__pycache__/*" "*.pyc"
echo "$(pwd)/$name.zip"
unzip -l "$name.zip" | tail -1
