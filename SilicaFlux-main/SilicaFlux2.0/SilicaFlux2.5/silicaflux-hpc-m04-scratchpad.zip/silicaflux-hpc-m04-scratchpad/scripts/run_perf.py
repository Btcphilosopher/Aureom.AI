#!/usr/bin/env python3
"""Performance sweep of hpc_scratchpad (RTL, Verilator, cycle-accurate, self-checking).

For each configuration and workload the testbench (+test=perf) drives NUM_PORTS saturating requesters (every port
presents its next request in the cycle after the previous one was accepted, rsp_ready = 1 unless stated) and reports
per run:  accepted and completed accesses per cycle, per-bank utilisation, conflict port-cycles and conflict rate,
average / maximum wait (issue - present), average queue wait (issue - accept), average latency (response - present),
bytes per cycle (reads: full word, writes: enabled bytes), and bandwidth efficiency against the peak
min(NUM_PORTS, NUM_BANKS x accesses-per-bank) x word bytes.
Bytes/cycle is converted to GB/s only by multiplying with a clock frequency, which this RTL-level work does not
establish (no timing closure): no GB/s figure is claimed.

Workloads (per port p, base_p = p * WORDS / NUM_PORTS):
  seq      unit-stride stream in a private region, alternating 64-word read / write blocks
  seqrd    unit-stride read stream in a private region
  rand     uniform random words, 50 % writes
  stride   stride = NUM_BANKS words (worst case of the LOW map)
  stride2  stride = 2 words
  samebank every port in bank 0 (upper bound on conflicts)
  vecdma   ports 0..P-2: vector lanes reading interleaved words of one region; port P-1: DMA write stream
  tile     8x8 tile walk of a 64-word-wide matrix, one tile column per port
  hot      uniform random in a 16-word window, 50 % writes
Results: reports/perf.{json,md}.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (BUILD, REPORTS, cfg_label, parse_sim, provenance, run, verilator_build,  # noqa: E402
                    write_json)

WORKLOADS = ["seq", "seqrd", "rand", "stride", "stride2", "samebank", "vecdma", "tile", "hot"]

SWEEP = []
for nb in (1, 2, 4, 8, 16):
    SWEEP.append(("banks", dict(NP=4, NB=nb, CAP=65536)))
for nb in (2, 4, 8, 16):
    SWEEP.append(("xor", dict(NP=4, NB=nb, CAP=65536, MAP=1)))
SWEEP += [
    ("capacity", dict(NP=4, NB=8, CAP=131072)),
    ("capacity", dict(NP=4, NB=8, CAP=262144)),
    ("portmode", dict(NP=4, NB=4, CAP=65536, PMODE=1)),
    ("portmode", dict(NP=4, NB=4, CAP=65536, PMODE=2)),
    ("portmode", dict(NP=8, NB=8, CAP=65536, PMODE=2)),
    ("queue", dict(NP=4, NB=4, CAP=65536, QD=4)),
    ("ports", dict(NP=8, NB=8, CAP=65536)),
    ("ports", dict(NP=8, NB=16, CAP=65536)),
    ("ports", dict(NP=8, NB=16, CAP=65536, MAP=1)),
    ("latency", dict(NP=4, NB=4, CAP=65536, RL=3)),
    ("arb", dict(NP=4, NB=4, CAP=65536, ARB=1)),
]


def job(group: str, cfg: dict, wl: str, n: int, bp: int) -> dict:
    exe = verilator_build(cfg)
    log = BUILD / "perf" / f"{group}_{abs(hash(cfg_label(cfg))) % 10**8}_{wl}_bp{bp}.log"
    rc, out, dt = run([exe, "+test=perf", f"+wl={wl}", f"+n={n}", f"+bp={bp}", "+seed=5"], log=log, timeout=3600)
    r = parse_sim(out)
    p = r["perf"][-1] if r["perf"] else {}
    return {"group": group, "cfg": cfg, "label": cfg_label(cfg), "workload": wl, "bp": bp, "pass": r["pass"] and rc == 0,
            "perf": p, "log": str(log.relative_to(BUILD.parent))}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=2000)
    ap.add_argument("--jobs", type=int, default=4)
    a = ap.parse_args()
    with cf.ThreadPoolExecutor(max_workers=2) as ex:
        list(ex.map(lambda gc: verilator_build(gc[1]), SWEEP))
    work = [(g, c, wl, a.n, 0) for g, c in SWEEP for wl in WORKLOADS]
    work += [("bp25", c, wl, a.n, 25) for g, c in SWEEP[:5] for wl in ("rand", "seq")]
    res = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        for f in cf.as_completed([ex.submit(job, *w) for w in work]):
            r = f.result()
            res.append(r)
            print(f"{'PASS' if r['pass'] else 'FAIL'} {r['label']:55s} {r['workload']:8s} bp{r['bp']:2d} "
                  f"acc/cyc {r['perf'].get('acc_per_cycle')}  B/cyc {r['perf'].get('bytes_per_cycle')}", flush=True)
    write_json(REPORTS / "perf.json", {"provenance": provenance(), "n_per_port": a.n, "runs": res})
    write_md(res, a.n)
    return 0 if all(r["pass"] for r in res) else 1


def fmt(v, nd=3):
    return f"{v:.{nd}f}" if isinstance(v, float) else str(v)


def write_md(res, n):
    L = ["# hpc_scratchpad performance (RTL cycle-accurate measurements)", "", __doc__.split("\n\n", 1)[1].rsplit("Results:", 1)[0].strip(), "",
         f"{n} requests per port per run; every run also passes the full self-checking scoreboard.", ""]

    def table(rows, title):
        nonlocal L
        L += [f"## {title}", "",
              "| configuration | workload | acc/cycle | cmp/cycle | B/cycle | peak B/cycle | efficiency | conflict rate | avg wait | max wait | avg queue wait | avg latency | bank utilisation |",
              "|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
        for r in rows:
            p = r["perf"]
            L.append(f"| {r['label']} | {r['workload']}{' bp' + str(r['bp']) + '%' if r['bp'] else ''} | {fmt(p.get('acc_per_cycle'))} | "
                     f"{fmt(p.get('cmp_per_cycle'))} | {fmt(p.get('bytes_per_cycle'), 2)} | {fmt(p.get('peak_bytes_per_cycle'), 0)} | "
                     f"{fmt(p.get('bw_efficiency'))} | {fmt(p.get('conflict_rate'))} | {fmt(p.get('avg_wait'), 2)} | {p.get('max_wait')} | "
                     f"{fmt(p.get('avg_queue_wait'), 2)} | {fmt(p.get('avg_latency'), 2)} | {p.get('bank_util')} |")
        L.append("")

    # headline: accesses per cycle, workload x banks (LOW and XOR)
    for grp, title in [("banks", "Bank-count sweep, LOW map (64 KiB, 4 ports, 32 bit, 1RW, RR, RL 1)"),
                       ("xor", "Bank-count sweep, XOR map")]:
        rows = [r for r in res if r["group"] == grp]
        nbs = sorted({r["cfg"]["NB"] for r in rows})
        L += [f"## Accepted accesses per cycle - {title}", "", "| workload | " + " | ".join(f"{b} banks" for b in nbs) + " |",
              "|---|" + "---|" * len(nbs)]
        for wl in WORKLOADS:
            vals = []
            for b in nbs:
                rr = [r for r in rows if r["workload"] == wl and r["cfg"]["NB"] == b]
                vals.append(fmt(rr[0]["perf"].get("acc_per_cycle")) if rr else "-")
            L.append(f"| {wl} | " + " | ".join(vals) + " |")
        L.append("")
    for grp, title in [("banks", "Detail: bank-count sweep (LOW)"), ("xor", "Detail: XOR map"), ("capacity", "Capacity (64 / 128 / 256 KiB, 8 banks)"),
                       ("portmode", "Bank memory-port model"), ("queue", "Request queue (QUEUE_DEPTH = 4)"), ("ports", "8 ports"),
                       ("latency", "READ_LATENCY = 3"), ("arb", "Fixed priority"), ("bp25", "25 % response back-pressure")]:
        rows = sorted([r for r in res if r["group"] == grp], key=lambda r: (r["label"], WORKLOADS.index(r["workload"])))
        if rows:
            table(rows, title)
    (REPORTS / "perf.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
