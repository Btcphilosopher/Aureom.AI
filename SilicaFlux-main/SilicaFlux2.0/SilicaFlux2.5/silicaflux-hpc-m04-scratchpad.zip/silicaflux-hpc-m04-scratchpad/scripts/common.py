"""Shared helpers for the SilicaFlux-HPC Module 04 scripts (build, run, provenance)."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RTL = ROOT / "rtl"
TB = ROOT / "tb"
SRAMLIB = ROOT / "third_party/silicaflux-sramlib/rtl/mem"
BUILD = ROOT / "build"
REPORTS = ROOT / "reports"

RTL_FILES = [
    SRAMLIB / "sram_rsp_path.sv",
    SRAMLIB / "sram_backend_1rw.sv",
    SRAMLIB / "sram_backend_1r1w.sv",
    SRAMLIB / "sram_backend_2rw.sv",
    SRAMLIB / "backends/generic/sram_generic_1rw.sv",
    SRAMLIB / "backends/generic/sram_generic_1r1w.sv",
    SRAMLIB / "backends/generic/sram_generic_2rw.sv",
    SRAMLIB / "backends/fpga/sram_fpga_1rw.sv",
    SRAMLIB / "backends/fpga/sram_fpga_1r1w.sv",
    SRAMLIB / "backends/fpga/sram_fpga_2rw.sv",
    SRAMLIB / "backends/asic/sram_asic_array.sv",
    SRAMLIB / "backends/asic/sram_leaf_sky130.sv",
    SRAMLIB / "backends/asic/sram_leaf_gf180.sv",
    SRAMLIB / "backends/asic/sram_leaf_ihp1p.sv",
    SRAMLIB / "backends/asic/sram_leaf_ihp2p.sv",
    ROOT / "third_party/silicaflux-datafabric/rtl/dma/dma_fifo.sv",
    RTL / "hpc_spm_addr_map.sv",
    RTL / "hpc_spm_bank_arb.sv",
    RTL / "hpc_spm_bank.sv",
    RTL / "hpc_spm_perf.sv",
    RTL / "hpc_scratchpad.sv",
]
STUBS = SRAMLIB / "backends/asic/stubs/sram_macro_blackboxes.sv"
INCDIRS = [RTL, SRAMLIB, SRAMLIB / "backends/asic"]
SIM_DEFINES = ["HPC_SPM_ASSERT", "SRAMLIB_ASSERT", "SRAMLIB_POISON"]

# testbench parameters and their defaults (tb/tb_hpc_scratchpad.sv)
TB_DEFAULTS = dict(NP=2, CAP=65536, NB=2, DW=32, AW=32, BASE=0, RL=1, BWE=1, PMODE=0, MAP=0, ARB=0, QD=0,
                   RSPD=None, WACK=1, TAGW=16, ECC=0, BACKEND=0, MAXP=8192)
# testbench parameter -> hpc_scratchpad parameter
TB_TO_DUT = dict(NP="NUM_PORTS", CAP="CAPACITY_BYTES", NB="NUM_BANKS", DW="DATA_WIDTH", AW="ADDR_WIDTH",
                 BASE="BASE_ADDR", RL="READ_LATENCY", BWE="BYTE_WE", PMODE="PORT_MODE", MAP="MAP", ARB="ARB",
                 QD="QUEUE_DEPTH", RSPD="RSP_FIFO_DEPTH", WACK="WRITE_ACK", TAGW="TAG_W", ECC="ECC_MODE",
                 BACKEND="BACKEND")

PMODE_NAMES = {0: "1RW", 1: "1R1W", 2: "2RW"}
MAP_NAMES = {0: "LOW", 1: "XOR", 2: "HIGH"}
ARB_NAMES = {0: "RR", 1: "FIXED"}
BACKEND_NAMES = {0: "GENERIC", 1: "FPGA", 2: "ASIC"}


def full_cfg(cfg: dict) -> dict:
    c = dict(TB_DEFAULTS)
    c.update(cfg)
    if c["RSPD"] is None:
        c["RSPD"] = c["RL"] + 1
    return c


def cfg_label(cfg: dict) -> str:
    c = full_cfg(cfg)
    s = (f"{c['CAP'] // 1024}KiB {c['NB']}b {c['NP']}p {c['DW']}bit {PMODE_NAMES[c['PMODE']]} {MAP_NAMES[c['MAP']]} "
         f"{ARB_NAMES[c['ARB']]} RL{c['RL']} Q{c['QD']} RSP{c['RSPD']}")
    if c["BWE"] == 0:
        s += " wordWE"
    if c["WACK"] == 0:
        s += " posted"
    if c["ECC"]:
        s += " parity"
    if c["BACKEND"]:
        s += " " + BACKEND_NAMES[c["BACKEND"]]
    if c["BASE"]:
        s += f" base=0x{c['BASE']:x}"
    if c["AW"] != 32:
        s += f" AW{c['AW']}"
    return s


def cfg_hash(cfg: dict, extra: str = "") -> str:
    c = full_cfg(cfg)
    return hashlib.sha1((json.dumps(c, sort_keys=True) + extra).encode()).hexdigest()[:10]


def tool_versions() -> dict:
    out = {}
    for tool, args in [("verilator", ["--version"]), ("iverilog", ["-V"]), ("yosys", ["-V"]), ("python", None)]:
        if tool == "python":
            out[tool] = platform.python_version()
            continue
        exe = shutil.which(tool)
        if not exe:
            out[tool] = "NOT INSTALLED"
            continue
        try:
            r = subprocess.run([exe] + args, capture_output=True, text=True, timeout=30)
            out[tool] = (r.stdout or r.stderr).strip().splitlines()[0]
        except Exception as e:  # pragma: no cover
            out[tool] = f"error: {e}"
    return out


def provenance() -> dict:
    files = sorted([*RTL.glob("*.sv"), *RTL.glob("*.svh"), *TB.glob("*.sv")])
    h = hashlib.sha256()
    for f in files:
        h.update(f.name.encode())
        h.update(f.read_bytes())
    return {"generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "design_tb_sha256": h.hexdigest(),
            "tools": tool_versions(), "host": platform.platform()}


def run(cmd: list[str], cwd: Path | None = None, timeout: int = 3600, log: Path | None = None) -> tuple[int, str, float]:
    t0 = time.time()
    try:
        r = subprocess.run([str(c) for c in cmd], cwd=cwd, capture_output=True, text=True, timeout=timeout)
        out, rc = r.stdout + r.stderr, r.returncode
    except subprocess.TimeoutExpired as e:
        out = (e.stdout or b"").decode(errors="replace") if isinstance(e.stdout, bytes) else (e.stdout or "")
        out += "\nTIMEOUT"
        rc = -9
    dt = time.time() - t0
    if log:
        log.parent.mkdir(parents=True, exist_ok=True)
        log.write_text(" ".join(str(c) for c in cmd) + "\n\n" + out)
    return rc, out, dt


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=1, default=str) + "\n")


# ----------------------------------------------------------------------------- simulation builds
def verilator_build(cfg: dict, tag: str = "", rtl_files: list[Path] | None = None, defines: list[str] | None = None) -> Path:
    c = full_cfg(cfg)
    files = rtl_files or RTL_FILES
    d = BUILD / f"v_{cfg_hash(cfg, tag + ''.join(str(f) for f in files))}"
    exe = d / "sim"
    if exe.exists():
        return exe
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["verilator", "--binary", "--timing", "-j", "2", "--timescale", "1ns/1ps", "-Wno-fatal", "-Wno-lint",
           "-Wno-style", "--top-module", "tb_hpc_scratchpad", "-Mdir", d, "-o", "sim"]
    cmd += [f"-I{p}" for p in INCDIRS]
    cmd += [f"-D{x}" for x in (defines if defines is not None else SIM_DEFINES)]
    for k, v in c.items():
        cmd.append(f"-G{k}={v}" if k != "BASE" else f"-GBASE=64'h{v:x}")
    cmd += [*files, STUBS, TB / "tb_hpc_scratchpad.sv"]
    rc, out, _ = run(cmd, log=d / "build.log", timeout=3600)
    if rc != 0 or not exe.exists():
        raise RuntimeError(f"verilator build failed for {cfg_label(cfg)}: see {d / 'build.log'}")
    return exe


def icarus_build(cfg: dict, tag: str = "") -> Path:
    c = full_cfg(cfg)
    d = BUILD / f"i_{cfg_hash(cfg, tag)}"
    out = d / "sim.vvp"
    if out.exists():
        return out
    d.mkdir(parents=True, exist_ok=True)
    cmd = ["iverilog", "-g2012", "-o", out, "-s", "tb_hpc_scratchpad"]
    cmd += [f"-I{p}" for p in INCDIRS]
    cmd += [f"-D{x}" for x in SIM_DEFINES]
    for k, v in c.items():
        cmd.append(f"-Ptb_hpc_scratchpad.{k}={v}")
    cmd += [*RTL_FILES, STUBS, TB / "tb_hpc_scratchpad.sv"]
    rc, txt, _ = run(cmd, log=d / "build.log")
    if rc != 0 or not out.exists():
        raise RuntimeError(f"icarus build failed for {cfg_label(cfg)}: see {d / 'build.log'}")
    return out


def sim_cmd(sim: str, exe: Path, args: list[str]) -> list:
    return ([exe] if sim == "verilator" else ["vvp", "-n", exe]) + args


RESULT_RE = re.compile(r"^TEST (\S+) (PASSED|FAILED)", re.M)
COVER_RE = re.compile(r"^COVER (.*)$", re.M)
PERF_RE = re.compile(r"^PERF (.*)$", re.M)


def parse_kv(line: str) -> dict:
    out = {}
    for tok in line.split():
        if "=" in tok:
            k, v = tok.split("=", 1)
            try:
                out[k] = int(v)
            except ValueError:
                try:
                    out[k] = float(v)
                except ValueError:
                    out[k] = v
    return out


def parse_sim(out: str) -> dict:
    m = RESULT_RE.search(out)
    res = {"pass": bool(m and m.group(2) == "PASSED"), "errors": out.count("ERROR @")}
    c = COVER_RE.search(out)
    if c:
        res["cover"] = parse_kv(c.group(1))
    res["perf"] = [parse_kv(p) for p in PERF_RE.findall(out)]
    res["phases"] = len(re.findall(r"^  phase ", out, re.M))
    res["backdoor_checks"] = len(re.findall(r"backdoor check '.*': all", out))
    res["backdoor_selftest"] = "checker is live" in out
    # a backdoor comparison only counts if the checker proved it can see a corrupted row in the same run
    if res["backdoor_checks"] and not res["backdoor_selftest"]:
        res["pass"] = False
    return res
