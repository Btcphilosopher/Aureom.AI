#!/usr/bin/env python3
"""Regression of hpc_scratchpad: lint, negative elaboration tests, staged simulation sweep, cross-simulator runs.

Staging follows the brief: stage 1 is the two-bank single-port design; it is verified before stage 2 (four banks)
and stage 3 (eight banks) run; stage 4 holds the extended configurations (16 / 1 banks, 1R1W / 2RW, parity,
FPGA backend, word-write memory, posted writes, no-backpressure mode, byte-wide data, BASE offsets).
A stage only runs if every earlier stage passed (--force overrides).

Results: reports/regression.{json,md}; per-run logs under build/logs/.
"""
from __future__ import annotations

import argparse
import concurrent.futures as cf
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import (BUILD, INCDIRS, REPORTS, RTL, RTL_FILES, STUBS, cfg_label, full_cfg, icarus_build,  # noqa: E402
                    parse_sim, provenance, run, sim_cmd, verilator_build, write_json)

ALL_TESTS = ["smoke", "all_banks", "boundaries", "unaligned", "byte_mask", "conflict", "parallel", "backpressure",
             "reset", "rdw", "oor", "stall_preserve", "random", "parity"]
SEEDED = {"random": [1, 2, 3], "backpressure": [1, 2], "reset": [1, 2], "oor": [1, 2]}

STAGES = [
    ("stage1: 2 banks, single-port (1RW)", [
        dict(),                                                             # 64 KiB, 2 ports, RL1, Q0
        dict(RL=2),
        dict(QD=4),
        dict(NP=3),
        dict(ECC=1),
        dict(BACKEND=1, RL=2),                                              # FPGA block-RAM template
        dict(ARB=1),
    ]),
    ("stage2: 4 banks", [
        dict(NP=4, NB=4, CAP=131072),
        dict(NP=4, NB=4, CAP=131072, ARB=1),
        dict(NP=4, NB=4, CAP=131072, MAP=1),
        dict(NP=2, NB=4, CAP=131072, DW=64, RL=2, QD=2, BASE=0x20000000),
        dict(NP=5, NB=4, CAP=65536, PMODE=1),
    ]),
    ("stage3: 8 banks", [
        dict(NP=4, NB=8, CAP=262144),
        dict(NP=8, NB=8, CAP=262144, DW=64, PMODE=2, MAP=1, RL=2, QD=4),
        dict(NP=8, NB=8, CAP=131072, MAP=2),
        dict(NP=6, NB=8, CAP=65536, PMODE=1, QD=2, ECC=1),
    ]),
    ("stage4: extended configurations", [
        dict(NP=8, NB=16, CAP=262144),
        dict(NP=2, NB=1, CAP=65536),
        dict(NP=2, NB=4, CAP=65536, DW=128, RL=3),
        dict(NP=2, NB=4, CAP=65536, BWE=0),
        dict(NP=3, NB=4, CAP=65536, WACK=0, QD=2),
        dict(NP=2, NB=2, CAP=65536, RSPD=0),
        dict(NP=2, NB=2, CAP=1024, DW=8, AW=10),
        dict(NP=4, NB=4, CAP=65536, PMODE=2, ECC=1, BACKEND=1, RL=2),
        dict(NP=3, NB=4, CAP=65536, AW=20, BASE=0x40000),
        dict(NP=2, NB=2, CAP=65536, RL=2, RSPD=1),
        dict(NP=4, NB=16, CAP=65536, MAP=1, PMODE=1, BACKEND=1),
    ]),
]

# Icarus cross-check (slower simulator): selected configurations and tests
ICARUS = [
    (dict(), ["smoke", "boundaries", "unaligned", "byte_mask", "conflict", "parallel", "backpressure", "reset", "rdw",
              "oor", "random", "parity"]),
    (dict(NP=4, NB=4, CAP=131072, MAP=1), ["smoke", "conflict", "backpressure", "reset", "rdw", "random"]),
    (dict(NP=8, NB=8, CAP=262144, DW=64, PMODE=2, MAP=1, RL=2, QD=4), ["smoke", "conflict", "rdw", "random", "oor"]),
    (dict(ECC=1), ["parity", "random", "byte_mask"]),
    (dict(NP=2, NB=4, CAP=65536, DW=128, RL=3), ["smoke", "byte_mask", "random"]),
]

# negative elaboration tests: (overrides of hpc_scratchpad, expected message fragment)
NEGATIVE = [
    (dict(NUM_BANKS=3), "NUM_BANKS must be 1, 2, 4, 8 or 16"),
    (dict(NUM_BANKS=32), "NUM_BANKS must be 1, 2, 4, 8 or 16"),
    (dict(CAPACITY_BYTES=98304), "CAPACITY_BYTES must be a power of two"),
    (dict(CAPACITY_BYTES=64, NUM_BANKS=16), "at least 2 words"),
    (dict(DATA_WIDTH=24), "DATA_WIDTH must be a power of two"),
    (dict(DATA_WIDTH=4), "DATA_WIDTH must be a power of two"),
    (dict(ADDR_WIDTH=15), "ADDR_WIDTH must be"),
    (dict(BASE_ADDR="64'h1000"), "BASE_ADDR must be aligned"),
    (dict(ADDR_WIDTH=16, CAPACITY_BYTES=65536, BASE_ADDR="64'h10000"), "BASE_ADDR does not fit"),
    (dict(READ_LATENCY=0), "READ_LATENCY must be 1..8"),
    (dict(READ_LATENCY=9), "READ_LATENCY must be 1..8"),
    (dict(PORT_MODE=3), "unknown PORT_MODE"),
    (dict(MAP=3), "unknown MAP"),
    (dict(MAP=1, NUM_BANKS=16, CAPACITY_BYTES=128), "MAP = XOR needs"),
    (dict(ARB=2), "unknown ARB"),
    (dict(QUEUE_DEPTH=3), "QUEUE_DEPTH must be 0, 2, 4, 8 or 16"),
    (dict(RSP_FIFO_DEPTH=65), "RSP_FIFO_DEPTH must be 0..64"),
    (dict(NUM_PORTS=0), "NUM_PORTS must be 1..8"),
    (dict(NUM_PORTS=9), "NUM_PORTS must be 1..8"),
    (dict(TAG_W=0), "TAG_W must be 1..32"),
    (dict(ECC_MODE=2), "SECDED is reserved and NOT implemented"),
    (dict(ECC_MODE=7), "unknown ECC_MODE"),
    (dict(BYTE_WE=2), "BYTE_WE must be 0 or 1"),
    (dict(WRITE_ACK=2), "WRITE_ACK must be 0 or 1"),
    (dict(BACKEND=2), "requires an explicit MACRO"),
    (dict(BACKEND=5), "unknown BACKEND"),
    (dict(CNT_W=4), "CNT_W must be 8..64"),
]

# lint configurations (hpc_scratchpad top, Verilator -Wall must be clean on rtl/)
LINT = [
    dict(),
    dict(NUM_PORTS=1, NUM_BANKS=1, DATA_WIDTH=8, CAPACITY_BYTES=1024, ADDR_WIDTH=10, PERF_EN=0, ARB=1, MAP=2),
    dict(NUM_PORTS=8, NUM_BANKS=16, CAPACITY_BYTES=262144, PORT_MODE=2, MAP=1, READ_LATENCY=3, QUEUE_DEPTH=16),
    dict(NUM_PORTS=5, NUM_BANKS=8, DATA_WIDTH=128, PORT_MODE=1, ECC_MODE=1, BYTE_WE=0, WRITE_ACK=0, RSP_FIFO_DEPTH=0),
    dict(NUM_PORTS=2, NUM_BANKS=4, BACKEND=1, READ_LATENCY=2, ECC_MODE=1, QUEUE_DEPTH=2),
    dict(NUM_PORTS=2, NUM_BANKS=4, BACKEND=2, MACRO=24),                      # IHP 1P 2048x32 macros
]


def gparams(d: dict) -> list[str]:
    return [f"-G{k}={v}" for k, v in d.items()]


def lint_runs() -> list[dict]:
    res = []
    files = [*RTL_FILES, STUBS]
    for d in LINT:
        cmd = ["verilator", "--lint-only", "-Wall", "-Wno-DECLFILENAME", "-DHPC_SPM_ASSERT", "--top-module",
               "hpc_scratchpad"] + [f"-I{p}" for p in INCDIRS] + gparams(d) + files
        rc, out, dt = run(cmd, log=BUILD / "logs" / f"lint_{len(res)}.log")
        ours = [ln for ln in out.splitlines() if ln.startswith("%") and "third_party" not in ln]
        theirs = [ln for ln in out.splitlines() if ln.startswith("%Warning") and "third_party" in ln]
        res.append({"kind": "verilator-lint", "params": d, "pass": rc == 0 and not ours, "rtl_messages": ours[:10],
                    "third_party_warnings": len(theirs), "seconds": round(dt, 1)})
    for d in LINT[:5]:
        cmd = ["iverilog", "-g2012", "-o", BUILD / "lint.vvp", "-s", "hpc_scratchpad"] + [f"-I{p}" for p in INCDIRS]
        cmd += [f"-Phpc_scratchpad.{k}={v}" for k, v in d.items()] + files
        rc, out, dt = run(cmd, log=BUILD / "logs" / f"ilint_{len(res)}.log")
        errs = [ln for ln in out.splitlines() if "error" in ln.lower() and "synthesized" not in ln]
        res.append({"kind": "icarus-elab", "params": d, "pass": rc == 0 and not errs, "rtl_messages": errs[:10],
                    "seconds": round(dt, 1)})
    return res


def negative_runs() -> list[dict]:
    res = []
    files = [*RTL_FILES, STUBS]
    for i, (d, frag) in enumerate(NEGATIVE):
        cmd = ["verilator", "--lint-only", "-Wno-lint", "-Wno-style", "--top-module", "hpc_scratchpad"]
        cmd += [f"-I{p}" for p in INCDIRS] + gparams(d) + files
        rc, out, dt = run(cmd, log=BUILD / "logs" / f"neg_{i}.log")
        ok = rc != 0 and frag in out
        res.append({"params": d, "expect": frag, "pass": ok, "rc": rc,
                    "first_error": next((ln for ln in out.splitlines() if "%Error" in ln), "")[:200]})
    return res


def sim_job(sim: str, cfg: dict, test: str, seed: int) -> dict:
    exe = verilator_build(cfg) if sim == "verilator" else icarus_build(cfg)
    tag = f"{sim}_{abs(hash(cfg_label(cfg))) % 10**8}_{test}_{seed}"
    rc, out, dt = run(sim_cmd(sim, exe, [f"+test={test}", f"+seed={seed}"]), timeout=3600,
                      log=BUILD / "logs" / f"{tag}.log")
    r = parse_sim(out)
    r.update({"sim": sim, "cfg": full_cfg(cfg), "label": cfg_label(cfg), "test": test, "seed": seed,
              "seconds": round(dt, 1), "rc": rc, "log": f"build/logs/{tag}.log"})
    r["pass"] = r["pass"] and rc == 0
    return r


def run_stage(cfgs: list[dict], sim: str, tests_for, jobs: int) -> list[dict]:
    # build serially-parallel (2 at a time; each Verilator build uses -j2), then run every test
    with cf.ThreadPoolExecutor(max_workers=2) as ex:
        list(ex.map(verilator_build if sim == "verilator" else icarus_build, cfgs))
    work = []
    for c in cfgs:
        for t in tests_for(c):
            for s in SEEDED.get(t, [1]):
                work.append((c, t, s))
    results = []
    with cf.ThreadPoolExecutor(max_workers=jobs) as ex:
        futs = [ex.submit(sim_job, sim, c, t, s) for c, t, s in work]
        for f in cf.as_completed(futs):
            r = f.result()
            results.append(r)
            print(f"  {'PASS' if r['pass'] else 'FAIL'} {r['sim']:9s} {r['test']:15s} seed {r['seed']} {r['seconds']:6.1f}s  {r['label']}",
                  flush=True)
    return results


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--jobs", type=int, default=4)
    ap.add_argument("--force", action="store_true", help="run later stages even if an earlier one failed")
    ap.add_argument("--quick", action="store_true", help="stage 1 only, no Icarus")
    args = ap.parse_args()
    t0 = time.time()
    report = {"provenance": provenance(), "stages": [], "icarus": [], "lint": [], "negative": []}

    print("== lint")
    report["lint"] = lint_runs()
    for r in report["lint"]:
        print(f"  {'PASS' if r['pass'] else 'FAIL'} {r['kind']} {r['params']}")
    print("== negative elaboration tests")
    report["negative"] = negative_runs()
    for r in report["negative"]:
        print(f"  {'PASS' if r['pass'] else 'FAIL'} reject {r['params']} -> '{r['expect']}'")

    ok_so_far = all(r["pass"] for r in report["lint"] + report["negative"])
    for name, cfgs in STAGES[:1] if args.quick else STAGES:
        if not ok_so_far and not args.force:
            print(f"== {name}: SKIPPED (an earlier stage failed)")
            report["stages"].append({"name": name, "skipped": True, "results": []})
            continue
        print(f"== {name} ({len(cfgs)} configurations)")
        res = run_stage(cfgs, "verilator", lambda c: ALL_TESTS, args.jobs)
        passed = all(r["pass"] for r in res)
        report["stages"].append({"name": name, "skipped": False, "configs": [cfg_label(c) for c in cfgs],
                                 "results": res, "pass": passed})
        ok_so_far = ok_so_far and passed
        print(f"   -> {sum(r['pass'] for r in res)}/{len(res)} passed")

    if not args.quick:
        print("== icarus cross-simulation")
        for cfg, tests in ICARUS:
            res = run_stage([cfg], "icarus", lambda c, tests=tests: tests, args.jobs)
            report["icarus"] += res

    report["seconds"] = round(time.time() - t0, 1)
    write_json(REPORTS / "regression.json", report)
    write_md(report)
    allres = [r for s in report["stages"] for r in s["results"]] + report["icarus"]
    ok = (all(r["pass"] for r in allres) and all(r["pass"] for r in report["lint"] + report["negative"])
          and not any(s.get("skipped") for s in report["stages"]))
    print(f"== regression {'PASSED' if ok else 'FAILED'} in {report['seconds']} s")
    return 0 if ok else 1


def write_md(rep: dict) -> None:
    L = ["# hpc_scratchpad regression", "",
         f"Generated {rep['provenance']['generated_utc']}; design+TB sha256 `{rep['provenance']['design_tb_sha256'][:16]}`; "
         f"wall time {rep['seconds']} s.", "",
         "| tool | version |", "|---|---|"]
    for k, v in rep["provenance"]["tools"].items():
        L.append(f"| {k} | {v} |")
    L += ["", "## Lint", "", "| kind | parameters | result | notes |", "|---|---|---|---|"]
    for r in rep["lint"]:
        note = "; ".join(r["rtl_messages"][:2]) or (f"{r.get('third_party_warnings', 0)} warnings inside vendored sramlib (unmodified)"
                                                   if r.get("third_party_warnings") else "clean")
        L.append(f"| {r['kind']} | `{r['params'] or 'defaults'}` | {'PASS' if r['pass'] else 'FAIL'} | {note} |")
    L += ["", "## Invalid parameter combinations (must fail elaboration with the stated message)", "",
          "| overrides | expected message | result |", "|---|---|---|"]
    for r in rep["negative"]:
        L.append(f"| `{r['params']}` | {r['expect']} | {'rejected (PASS)' if r['pass'] else 'NOT REJECTED (FAIL)'} |")
    for st in rep["stages"]:
        L += ["", f"## {st['name']}", ""]
        if st.get("skipped"):
            L.append("Skipped: an earlier stage failed.")
            continue
        cfgs = sorted({r["label"] for r in st["results"]}, key=lambda s: st["configs"].index(s))
        L += ["| configuration | " + " | ".join(ALL_TESTS) + " |", "|---|" + "---|" * len(ALL_TESTS)]
        for c in cfgs:
            row = []
            for t in ALL_TESTS:
                rs = [r for r in st["results"] if r["label"] == c and r["test"] == t]
                row.append(("PASS" if all(r["pass"] for r in rs) else "**FAIL**") + (f" ×{len(rs)}" if len(rs) > 1 else ""))
            L.append(f"| {c} | " + " | ".join(row) + " |")
        L.append("")
        L.append(f"{sum(r['pass'] for r in st['results'])} / {len(st['results'])} runs passed.")
    L += ["", "## Icarus cross-simulation", "", "| configuration | test | seed | result | seconds |", "|---|---|---|---|---|"]
    for r in sorted(rep["icarus"], key=lambda r: (r["label"], r["test"])):
        L.append(f"| {r['label']} | {r['test']} | {r['seed']} | {'PASS' if r['pass'] else '**FAIL**'} | {r['seconds']} |")
    allres = [r for s in rep["stages"] for r in s["results"]] + rep["icarus"]
    L += ["", "## Coverage (sum over every Verilator run)", ""]
    tot = {}
    for r in allres:
        if r["sim"] != "verilator":
            continue
        for k, v in r.get("cover", {}).items():
            if k in ("banks_read", "banks_written"):
                continue
            if isinstance(v, int):
                tot[k] = tot.get(k, 0) + v
    L += ["| bin | hits |", "|---|---|"] + [f"| {k} | {v:,} |" for k, v in sorted(tot.items())]

    def per_bank(r, k):
        v = r.get("cover", {}).get(k)
        return [int(x) for x in str(v).split(",")] if v is not None else []
    ab = [r for r in allres if r["sim"] == "verilator" and r["test"] == "all_banks"]
    full = [r for r in ab if per_bank(r, "banks_read") and min(per_bank(r, "banks_read")) >= r["cfg"]["CAP"] // (r["cfg"]["DW"] // 8) // r["cfg"]["NB"]
            and min(per_bank(r, "banks_written")) >= r["cfg"]["CAP"] // (r["cfg"]["DW"] // 8) // r["cfg"]["NB"]]
    L += ["", f"Per-bank coverage: in {len(full)} / {len(ab)} `all_banks` runs every row of every bank was written and read "
          "through the ports (per-bank counts in regression.json)."]
    (REPORTS / "regression.md").write_text("\n".join(L) + "\n")


if __name__ == "__main__":
    sys.exit(main())
