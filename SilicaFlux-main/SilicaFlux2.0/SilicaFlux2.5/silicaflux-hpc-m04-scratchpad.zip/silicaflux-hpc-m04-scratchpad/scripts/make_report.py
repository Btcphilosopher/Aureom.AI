#!/usr/bin/env python3
"""reports/SUMMARY.md: every number is read from the JSON reports produced by the other scripts."""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import REPORTS, provenance  # noqa: E402


def load(name):
    p = REPORTS / name
    return json.loads(p.read_text()) if p.exists() else None


def main() -> int:
    reg, unit, mut = load("regression.json"), load("unit_addr_map.json"), load("mutation.json")
    syn, perf, bw = load("synth.json"), load("perf.json"), load("bwlab_compare.json")
    pv = provenance()
    L = ["# SilicaFlux-HPC Module 04 - hpc_scratchpad - verification summary", "",
         f"Generated {pv['generated_utc']}.  Design + testbench sha256 `{pv['design_tb_sha256'][:16]}`.", "",
         "| check | source | result |", "|---|---|---|"]
    ok_all = True

    def row(name, src, passed, total, extra=""):
        nonlocal ok_all
        good = passed == total and total > 0
        ok_all = ok_all and good
        L.append(f"| {name} | {src} | {'PASS' if good else 'FAIL'} {passed} / {total}{extra} |")

    if reg:
        row("lint (Verilator -Wall, Icarus elaboration)", "regression.md", sum(r["pass"] for r in reg["lint"]), len(reg["lint"]))
        row("invalid parameter combinations rejected", "regression.md", sum(r["pass"] for r in reg["negative"]), len(reg["negative"]))
        for st in reg["stages"]:
            rs = st["results"]
            row(st["name"], "regression.md", sum(r["pass"] for r in rs), len(rs),
                f" runs ({len(set(r['label'] for r in rs))} configurations)" if not st.get("skipped") else " (SKIPPED)")
        rs = reg["icarus"]
        row("Icarus cross-simulation", "regression.md", sum(r["pass"] for r in rs), len(rs), " runs")
        allv = [r for s in reg["stages"] for r in s["results"]]
        bd = sum(r.get("backdoor_checks", 0) for r in allv)
        L.append(f"| backdoor whole-array comparisons (each run proved its checker live) | regression.json | {bd} |")
    if unit:
        rs = unit["results"]
        row("address decoder vs Python model (Verilator and Icarus)", "unit_addr_map.md",
            sum(r["verilator"] and r["icarus"] for r in rs), len(rs), " configurations")
    if mut:
        row("mutation testing (injected bugs detected)", "mutation.md", mut["killed"], mut["total"], " mutants killed")
    if syn:
        rec = syn["records"]
        for suite in ("generic", "fpga", "asic"):
            rs = [r for r in rec if r["suite"] == suite]
            lim = sum(r["result"] == "KNOWN-LIMITATION" for r in rs)
            passed = sum(r["result"] == "PASS" for r in rs)
            name = {"generic": "synthesis: generic inference + latch check", "fpga": "synthesis: FPGA block-RAM inference",
                    "asic": "synthesis: ASIC macro integrity"}[suite]
            good = passed + lim == len(rs)
            ok_all = ok_all and good
            L.append(f"| {name} | synth.md | {'PASS' if good else 'FAIL'} {passed} / {len(rs)}"
                     f"{f' (+{lim} documented tool limitation)' if lim else ''} |")
    if perf:
        rs = perf["runs"]
        row("performance runs (each self-checking)", "perf.md", sum(r["pass"] for r in rs), len(rs), " runs")
    if bw:
        rows = bw["rows"]
        ex = [r for r in rows if r["expect"] == "exact"]
        row("cycle-exact vs BandwidthLab BankedSram (1RW)", "bwlab_compare.md",
            sum(r["accept_match"] and r["conflict_match"] and r["response_match"] for r in ex), len(ex),
            f" runs, {sum(r['transactions'] for r in ex):,} transactions")
        bc = [r for r in rows if r.get("sram_bank_controller")]
        row("cycle-exact vs sram_bank_controller RTL", "bwlab_compare.md",
            sum(all(r["sram_bank_controller"][k] for k in ("accept_match", "conflict_match", "response_match")) for r in bc),
            len(bc), " runs")
    L += ["", f"**Overall: {'ALL CHECKS PASS' if ok_all else 'SOME CHECKS FAIL - see the reports'}.**", "",
          "## Tools", "", "| tool | version |", "|---|---|"]
    for k, v in pv["tools"].items():
        L.append(f"| {k} | {v} |")
    L += ["", "Not available / not run: Vivado, Quartus, Radiant, OpenROAD, Liberty-based ASIC synthesis, SymbiYosys "
          "(formal), gate-level simulation, FPGA hardware. No clock frequency, silicon area or power is claimed.", ""]
    (REPORTS / "SUMMARY.md").write_text("\n".join(L) + "\n")
    print("\n".join(L))
    return 0 if ok_all else 1


if __name__ == "__main__":
    sys.exit(main())
