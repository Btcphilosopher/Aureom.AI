#!/usr/bin/env python3
"""Unit test of rtl/hpc_spm_addr_map.sv against the Python reference (model/hpc_spm_map.py) on Verilator and Icarus.

Golden vectors are regenerated (deterministic seed), then every configuration in build/mapvec/index.json is
simulated on both simulators.  Results: reports/unit_addr_map.{json,md}.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from common import BUILD, INCDIRS, REPORTS, ROOT, RTL, TB, provenance, run, write_json  # noqa: E402

MAPN = {"low": 0, "xor": 1, "high": 2}


def main() -> int:
    vec = BUILD / "mapvec"
    rc, out, _ = run([sys.executable, "-I", ROOT / "model/hpc_spm_map.py", "vectors", vec])
    if rc:
        print(out)
        return 1
    idx = json.loads((vec / "index.json").read_text())
    files = [RTL / "hpc_spm_addr_map.sv", TB / "tb_hpc_spm_addr_map.sv"]
    res = []
    for i, e in enumerate(idx):
        c = e["cfg"]
        p = dict(AW=c["addr_width"], CAP=c["capacity"], DW=c["data_width"], NB=c["banks"], MAP=MAPN[c["mapping"]],
                 BWE=c["byte_we"])
        base = c["base"]
        # Verilator
        d = BUILD / f"unit_map_{i}"
        d.mkdir(parents=True, exist_ok=True)
        cmd = ["verilator", "--binary", "--timing", "-Wno-fatal", "-Wno-lint", "-Wno-style", "--top-module",
               "tb_hpc_spm_addr_map", "-Mdir", d, "-o", "sim"] + [f"-I{x}" for x in INCDIRS]
        cmd += [f"-G{k}={v}" for k, v in p.items()] + [f"-GBASE=64'h{base:x}"] + files
        rc, out, _ = run(cmd, log=d / "build.log")
        rc, out, _ = run([d / "sim", f"+vec={vec / e['file']}"], log=d / "run.log")
        v_ok = rc == 0 and "TEST addr_map PASSED" in out
        v_line = next((ln for ln in out.splitlines() if ln.startswith("TEST")), out[-200:])
        # Icarus
        cmd = ["iverilog", "-g2012", "-o", d / "sim.vvp", "-s", "tb_hpc_spm_addr_map"] + [f"-I{x}" for x in INCDIRS]
        cmd += [f"-Ptb_hpc_spm_addr_map.{k}={v}" for k, v in p.items()] + [f"-Ptb_hpc_spm_addr_map.BASE={base}"] + files
        rc, out, _ = run(cmd, log=d / "ibuild.log")
        rc, out, _ = run(["vvp", "-n", d / "sim.vvp", f"+vec={vec / e['file']}"], log=d / "irun.log")
        i_ok = rc == 0 and "TEST addr_map PASSED" in out
        i_line = next((ln for ln in out.splitlines() if ln.startswith("TEST")), out[-200:])
        res.append({"cfg": c, "verilator": v_ok, "icarus": i_ok, "verilator_line": v_line, "icarus_line": i_line})
        print(f"{'PASS' if v_ok and i_ok else 'FAIL'} {c}  | {v_line} | {i_line}")
    write_json(REPORTS / "unit_addr_map.json", {"provenance": provenance(), "results": res})
    L = ["# hpc_spm_addr_map unit test (RTL vs model/hpc_spm_map.py golden vectors)", "",
         "| capacity | banks | DW | AW | base | map | BYTE_WE | Verilator | Icarus |", "|---|---|---|---|---|---|---|---|---|"]
    for r in res:
        c = r["cfg"]
        L.append(f"| {c['capacity']} | {c['banks']} | {c['data_width']} | {c['addr_width']} | 0x{c['base']:x} | {c['mapping']} | "
                 f"{c['byte_we']} | {r['verilator_line']} | {r['icarus_line']} |")
    (REPORTS / "unit_addr_map.md").write_text("\n".join(L) + "\n")
    return 0 if all(r["verilator"] and r["icarus"] for r in res) else 1


if __name__ == "__main__":
    sys.exit(main())
