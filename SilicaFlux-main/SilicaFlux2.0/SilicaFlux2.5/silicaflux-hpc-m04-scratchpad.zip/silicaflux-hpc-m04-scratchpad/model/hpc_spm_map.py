#!/usr/bin/env python3
"""Executable reference of the hpc_scratchpad address map and configuration rules.

    python3 model/hpc_spm_map.py check            exhaustive bijectivity of every map over the exploration matrix,
                                                  configuration-rule table, BandwidthLab BankMapper cross-check
    python3 model/hpc_spm_map.py vectors <dir>    golden decode vectors for tb/tb_hpc_spm_addr_map.sv
    python3 model/hpc_spm_map.py table            mapping table used in docs/02_address_map.md

The RTL (rtl/hpc_spm_addr_map.sv) slices bits; this model uses arithmetic (division / modulo) so that the two are
independent formulations of docs/02_address_map.md.  The testbench (tb_hpc_scratchpad.sv) contains a third,
again arithmetic, formulation used for the backdoor placement check.
"""
from __future__ import annotations

import itertools
import json
import os
import random
import sys
from dataclasses import dataclass
from pathlib import Path

ERR_OK, ERR_RANGE, ERR_ALIGN, ERR_STROBE = 0, 1, 2, 3
MAPS = {"low": 0, "xor": 1, "high": 2}


def is_pow2(x: int) -> bool:
    return x > 0 and (x & (x - 1)) == 0


@dataclass(frozen=True)
class SpmConfig:
    capacity: int = 65536          # CAPACITY_BYTES
    banks: int = 2                 # NUM_BANKS
    data_width: int = 32           # DATA_WIDTH (bits)
    addr_width: int = 32           # ADDR_WIDTH
    base: int = 0                  # BASE_ADDR
    mapping: str = "low"           # MAP
    byte_we: int = 1               # BYTE_WE
    ports: int = 2                 # NUM_PORTS
    read_latency: int = 1          # READ_LATENCY
    port_mode: str = "1RW"         # PORT_MODE
    queue_depth: int = 0           # QUEUE_DEPTH

    @property
    def word_bytes(self) -> int:
        return self.data_width // 8

    @property
    def words(self) -> int:
        return self.capacity // self.word_bytes

    @property
    def bank_depth(self) -> int:
        return self.words // self.banks

    def violations(self) -> list[str]:
        """The rules hpc_scratchpad enforces at elaboration (same wording)."""
        v = []
        if not 1 <= self.ports <= 8:
            v.append("NUM_PORTS must be 1..8")
        if self.banks not in (1, 2, 4, 8, 16):
            v.append("NUM_BANKS must be 1, 2, 4, 8 or 16")
        if not (8 <= self.data_width <= 1024 and is_pow2(self.data_width)):
            v.append("DATA_WIDTH must be a power of two between 8 and 1024")
        if not (self.capacity >= 2 and is_pow2(self.capacity)):
            v.append("CAPACITY_BYTES must be a power of two")
        if self.data_width >= 8 and self.capacity < self.banks * (self.data_width // 8) * 2:
            v.append("CAPACITY_BYTES must give every bank at least 2 words")
        if self.capacity >= 2 and is_pow2(self.capacity) and not (self.capacity.bit_length() - 1 <= self.addr_width <= 64):
            v.append("ADDR_WIDTH must be >= log2(CAPACITY_BYTES) and <= 64")
        if self.capacity and self.base % self.capacity:
            v.append("BASE_ADDR must be aligned to CAPACITY_BYTES")
        if self.addr_width < 64 and self.base >> self.addr_width:
            v.append("BASE_ADDR does not fit in ADDR_WIDTH bits")
        if not 1 <= self.read_latency <= 8:
            v.append("READ_LATENCY must be 1..8")
        if self.mapping not in MAPS:
            v.append("unknown MAP")
        elif (self.mapping == "xor" and not v and self.bank_depth < self.banks):
            v.append("MAP = XOR needs at least NUM_BANKS words per bank")
        if self.port_mode not in ("1RW", "1R1W", "2RW"):
            v.append("unknown PORT_MODE")
        if self.queue_depth not in (0, 2, 4, 8, 16):
            v.append("QUEUE_DEPTH must be 0, 2, 4, 8 or 16")
        return v

    # ------------------------------------------------------------------ mapping
    def map_word(self, w: int) -> tuple[int, int]:
        b, d = self.banks, self.bank_depth
        if not 0 <= w < self.words:
            raise ValueError("word out of range")
        if b == 1:
            return 0, w
        if self.mapping == "high":
            return w // d, w % d
        if self.mapping == "xor":
            return (w % b) ^ ((w // b) % b), w // b
        return w % b, w // b

    def unmap(self, bank: int, row: int) -> int:
        b, d = self.banks, self.bank_depth
        if b == 1:
            return row
        if self.mapping == "high":
            return bank * d + row
        if self.mapping == "xor":
            return row * b + (bank ^ (row % b))
        return row * b + bank

    def decode(self, addr: int, we: int, strb: int) -> tuple[int, int, int, int]:
        """-> (err_code, bank, row, byte_offset); bank/row are only meaningful when err_code == 0."""
        off = addr % self.word_bytes
        if not (self.base <= addr < self.base + self.capacity):
            return ERR_RANGE, 0, 0, off
        if off:
            return ERR_ALIGN, 0, 0, off
        if self.byte_we == 0 and we and strb != (1 << self.word_bytes) - 1:
            return ERR_STROBE, 0, 0, off
        b, r = self.map_word((addr - self.base) // self.word_bytes)
        return ERR_OK, b, r, 0


# ---------------------------------------------------------------------- checks
def exploration_matrix():
    for cap, nb, dw, m in itertools.product((65536, 131072, 262144), (1, 2, 4, 8, 16), (32, 64, 128), MAPS):
        yield SpmConfig(capacity=cap, banks=nb, data_width=dw, mapping=m)


def check_bijective(cfg: SpmConfig) -> None:
    seen = bytearray(cfg.words)
    for w in range(cfg.words):
        b, r = cfg.map_word(w)
        assert 0 <= b < cfg.banks and 0 <= r < cfg.bank_depth, (cfg, w, b, r)
        idx = b * cfg.bank_depth + r
        assert not seen[idx], f"{cfg}: (bank {b}, row {r}) hit twice"
        seen[idx] = 1
        assert cfg.unmap(b, r) == w, (cfg, w)
    assert all(seen)


def stride_conflicts(cfg: SpmConfig, stride: int, n: int = 256) -> int:
    """Number of distinct banks touched by n consecutive accesses of a given word stride (1 = conflict-free)."""
    return len({cfg.map_word((i * stride) % cfg.words)[0] for i in range(n)})


def bandwidthlab_crosscheck() -> str:
    path = os.environ.get("BANDWIDTHLAB_PY")
    if not path:
        return "BandwidthLab not provided (set BANDWIDTHLAB_PY=<silicaflux-bandwidthlab>/python): skipped"
    sys.path.insert(0, path)
    try:
        from bandwidthlab.banking import BankMapper  # type: ignore
    except Exception as e:  # pragma: no cover
        return f"BandwidthLab import failed: {e}"
    n = 0
    for cfg in exploration_matrix():
        if cfg.violations():
            continue
        bm = BankMapper(cfg.banks, cfg.bank_depth, cfg.mapping)
        for w in range(0, cfg.words, max(1, cfg.words // 4096)):
            assert bm.map(w) == cfg.map_word(w), (cfg, w, bm.map(w), cfg.map_word(w))
            n += 1
    return f"identical to bandwidthlab.banking.BankMapper on {n:,} sampled words (low / xor / high, every valid matrix point)"


def cmd_check() -> int:
    n_cfg = n_words = 0
    rows = []
    for cfg in exploration_matrix():
        v = cfg.violations()
        if v:
            rows.append((cfg, "rejected: " + "; ".join(v)))
            continue
        check_bijective(cfg)
        n_cfg += 1
        n_words += cfg.words
    # rule table for the brief's exploration points (DW = 32, LOW)
    print("Exploration matrix (DATA_WIDTH = 32 bit):")
    print("| capacity | banks | words/bank | bank KiB | valid |")
    print("|---|---|---|---|---|")
    for cap, nb in itertools.product((65536, 131072, 262144), (1, 2, 4, 8, 16)):
        c = SpmConfig(capacity=cap, banks=nb)
        v = c.violations()
        print(f"| {cap // 1024} KiB | {nb} | {c.bank_depth} | {c.bank_depth * 4 // 1024} | {'yes' if not v else '; '.join(v)} |")
    bad = [
        SpmConfig(capacity=98304, banks=4), SpmConfig(capacity=65536, banks=3), SpmConfig(capacity=64, banks=16),
        SpmConfig(capacity=128, banks=16, mapping="xor"), SpmConfig(base=0x1000), SpmConfig(addr_width=15),
    ]
    print("\nRejected examples:")
    for c in bad:
        print(f"  capacity={c.capacity} banks={c.banks} map={c.mapping} base=0x{c.base:x} aw={c.addr_width}: {c.violations()}")
    print(f"\nbijectivity: {n_cfg} valid configurations, {n_words:,} words mapped, every (bank,row) hit exactly once, "
          f"unmap(map(w)) == w for all")
    # strides
    print("\nBanks touched by 256 accesses of word stride s (8 banks, 64 KiB, 32 bit):")
    for m in MAPS:
        c = SpmConfig(capacity=65536, banks=8, mapping=m)
        print(f"  {m:5s} " + "  ".join(f"s={s}:{stride_conflicts(c, s)}" for s in (1, 2, 4, 8, 16, 64)))
    print("\n" + bandwidthlab_crosscheck())
    return 0


def cmd_vectors(outdir: Path) -> int:
    """Golden decode vectors: one file per configuration, consumed by tb_hpc_spm_addr_map.sv."""
    outdir.mkdir(parents=True, exist_ok=True)
    cfgs = [
        SpmConfig(),
        SpmConfig(capacity=131072, banks=4, mapping="xor"),
        SpmConfig(capacity=262144, banks=8, data_width=64, mapping="high"),
        SpmConfig(capacity=262144, banks=16, mapping="xor", base=0x2004_0000),
        SpmConfig(capacity=65536, banks=1, data_width=128, byte_we=0),
        SpmConfig(capacity=1024, banks=2, data_width=8, addr_width=10),
        SpmConfig(capacity=65536, banks=4, addr_width=20, base=0x40000, byte_we=0),
    ]
    rng = random.Random(4)
    index = []
    for i, c in enumerate(cfgs):
        assert not c.violations(), c
        lines = []
        top = (1 << c.addr_width) - 1
        special = [c.base, c.base + c.capacity - c.word_bytes, c.base + c.capacity, c.base - c.word_bytes,
                   c.base + c.capacity - 1, top, top & ~(c.word_bytes - 1), c.base + 2 * c.capacity, 0]
        addrs = [a for a in special if 0 <= a <= top]
        for _ in range(4000):
            k = rng.random()
            if k < 0.6:
                a = c.base + rng.randrange(c.words) * c.word_bytes
            elif k < 0.75:
                a = c.base + rng.randrange(c.capacity)
            else:
                a = rng.randrange(top + 1)
            addrs.append(a)
        for a in addrs:
            we = rng.randrange(2)
            strb = rng.randrange(1 << c.word_bytes) if rng.random() < 0.5 else (1 << c.word_bytes) - 1
            e, b, r, off = c.decode(a, we, strb)
            lines.append(f"{a:x} {we} {strb:x} {e} {b} {r} {off}")
        f = outdir / f"map_{i}.txt"
        f.write_text(f"{len(lines)}\n" + "\n".join(lines) + "\n")
        index.append({"file": f.name, "cfg": c.__dict__})
    (outdir / "index.json").write_text(json.dumps(index, indent=1))
    print(f"wrote {len(cfgs)} vector files to {outdir}")
    return 0


def cmd_table() -> int:
    for m in MAPS:
        c = SpmConfig(capacity=65536, banks=4, mapping=m)
        print(f"\n{m.upper()} (64 KiB, 4 banks, 32-bit words, bank depth {c.bank_depth}):")
        print("| byte address | word | bank | row |")
        print("|---|---|---|---|")
        for w in list(range(0, 10)) + [c.bank_depth - 1, c.bank_depth, c.words - 1]:
            b, r = c.map_word(w)
            print(f"| 0x{w * 4:05x} | {w} | {b} | {r} |")
    return 0


if __name__ == "__main__":
    if len(sys.argv) < 2 or sys.argv[1] == "check":
        sys.exit(cmd_check())
    if sys.argv[1] == "vectors":
        sys.exit(cmd_vectors(Path(sys.argv[2] if len(sys.argv) > 2 else "build/mapvec")))
    if sys.argv[1] == "table":
        sys.exit(cmd_table())
    print(__doc__)
    sys.exit(2)
