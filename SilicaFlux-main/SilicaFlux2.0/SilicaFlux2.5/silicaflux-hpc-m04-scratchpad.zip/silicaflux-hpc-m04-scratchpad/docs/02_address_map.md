# 02 — Address map

Implemented in `rtl/hpc_spm_addr_map.sv` (bit slicing). Executable reference: `model/hpc_spm_map.py` (division /
modulo). A third, independent formulation lives in the testbench (`tb_word / tb_bank / tb_row / tb_unmap`).

## 1. Fields

```
CB  = log2(CAPACITY_BYTES)      OFF = log2(DATA_WIDTH / 8)      word bytes WB = DATA_WIDTH / 8
WAW = CB - OFF  (word-address bits)      BW = log2(NUM_BANKS)      RW = WAW - BW  (row bits, bank depth = 2^RW)

byte address  A  (ADDR_WIDTH bits)
  in range    : A[ADDR_WIDTH-1 : CB] == BASE_ADDR[ADDR_WIDTH-1 : CB]      (BASE_ADDR <= A < BASE_ADDR + CAPACITY)
  byte offset : A[OFF-1 : 0]
  word        : w = A[CB-1 : OFF]                                          (= (A - BASE_ADDR) / WB)
```

| `MAP` | bank | row | use |
|---|---|---|---|
| **LOW** (default) | `w[BW-1:0]` = w mod B | `w[WAW-1:BW]` = w div B | deterministic word interleave: unit-stride streams rotate through all banks |
| **XOR** | `w[BW-1:0] ^ w[2BW-1:BW]` = (w mod B) xor ((w div B) mod B) | w div B | conflict experiments: power-of-two strides up to B spread over all banks |
| **HIGH** | `w[WAW-1:RW]` = w div depth | `w[RW-1:0]` = w mod depth | contiguous regions: give each requester its own bank(s) by address range |

With `NUM_BANKS = 1` every map degenerates to bank 0, row = w. XOR requires bank depth ≥ `NUM_BANKS` (always true for
the explored sizes; rejected at elaboration otherwise).

Every map is a **bijection** between the `CAPACITY/WB` words and the (bank, row) pairs:
`model/hpc_spm_map.py check` verifies it exhaustively for all 135 points of {64, 128, 256 KiB} × {1, 2, 4, 8, 16 banks}
× {32, 64, 128 bit} × {LOW, XOR, HIGH} (3,010,560 words), including `unmap(map(w)) == w`, and checks that the three maps
are identical to BandwidthLab's `bandwidthlab.banking.BankMapper` (`low`, `xor`, `high`). The RTL decoder is checked
against golden vectors from the model on Verilator and Icarus (`reports/unit_addr_map.md`), and the physical
placement of every word of every bank is checked through the array backdoor by the `all_banks` test.

## 2. Examples (64 KiB, 4 banks, 32-bit words, bank depth 4096)

| byte address | word | LOW bank / row | XOR bank / row | HIGH bank / row |
|---|---|---|---|---|
| 0x00000 | 0 | 0 / 0 | 0 / 0 | 0 / 0 |
| 0x00004 | 1 | 1 / 0 | 1 / 0 | 0 / 1 |
| 0x00008 | 2 | 2 / 0 | 2 / 0 | 0 / 2 |
| 0x0000c | 3 | 3 / 0 | 3 / 0 | 0 / 3 |
| 0x00010 | 4 | 0 / 1 | 1 / 1 | 0 / 4 |
| 0x00014 | 5 | 1 / 1 | 0 / 1 | 0 / 5 |
| 0x00018 | 6 | 2 / 1 | 3 / 1 | 0 / 6 |
| 0x0001c | 7 | 3 / 1 | 2 / 1 | 0 / 7 |
| 0x00020 | 8 | 0 / 2 | 2 / 2 | 0 / 8 |
| 0x03ffc | 4095 | 3 / 1023 | 0 / 1023 | 0 / 4095 |
| 0x04000 | 4096 | 0 / 1024 | 0 / 1024 | 1 / 0 |
| 0x0fffc | 16383 | 3 / 4095 | 0 / 4095 | 3 / 4095 |

## 3. Strides and conflicts

Banks touched by 256 consecutive accesses of word stride *s* (8 banks; `model/hpc_spm_map.py check`):

| map | s = 1 | s = 2 | s = 4 | s = 8 | s = 16 | s = 64 |
|---|---|---|---|---|---|---|
| LOW | 8 | 4 | 2 | 1 | 1 | 1 |
| XOR | 8 | 8 | 8 | 8 | 4 | 1 |
| HIGH | 1 | 1 | 1 | 1 | 2 | 8 |

LOW is ideal for unit-stride vector streams and DMA bursts; a stride equal to the bank count serialises on one bank.
XOR spreads every power-of-two stride up to B words over all B banks (in the 8-bank example stride 16 still reaches
4 banks, stride 64 only one), at the cost of one XOR level in the decoder (measured effect in doc 07). HIGH isolates requesters by address range (a DMA buffer in banks 2-3 never
conflicts with vector data in banks 0-1).

## 4. Aligned, unaligned and out-of-range requests

| Request | Behaviour |
|---|---|
| aligned (`A mod WB = 0`), in range | normal access; `wstrb` selects the written bytes (byte lane *k* = byte address A + *k*, little-endian) |
| **unaligned** (`A mod WB ≠ 0`), in range | **rejected**: answered with `rsp_err = 1`, `rsp_err_code = ALIGN (2)`, `rdata = 0`; no bank access, no side effect. The scratchpad never silently rounds an address down and never splits an access (a sub-word access is an aligned word access with a partial `wstrb`). |
| **out of range** (`A < BASE_ADDR` or `A ≥ BASE_ADDR + CAPACITY`) | **rejected**: `RANGE (1)`, `rdata = 0`, no side effect. All `ADDR_WIDTH` bits are compared: an address that differs from an in-range one only above bit CB-1 is **not** an alias of it (verified with exact aliases `+CAPACITY`, `+2·CAPACITY`, `+3·CAPACITY`, the top of the address space and addresses below `BASE_ADDR`: the aliased words are unchanged after the rejected writes). |
| write with partial `wstrb`, `BYTE_WE = 0` | **rejected**: `STROBE (3)`, no side effect (a word-write memory cannot perform it; see doc 04 for why this option exists). |
| write with `wstrb = 0`, `BYTE_WE = 1` | legal no-op write: occupies the bank slot, changes nothing, acknowledged. |

Priority when several apply: RANGE, then ALIGN, then STROBE.
