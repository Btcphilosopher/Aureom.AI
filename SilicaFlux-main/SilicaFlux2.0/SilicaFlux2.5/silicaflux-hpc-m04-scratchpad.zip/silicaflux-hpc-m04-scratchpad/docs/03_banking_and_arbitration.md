# 03 — Banking, port models and arbitration

Implemented in `rtl/hpc_spm_bank_arb.sv` (one instance per bank) and the issue logic of `rtl/hpc_scratchpad.sv`.

## 1. Eligibility (per port, per cycle)

The **head** of port *p* is its presented request (`QUEUE_DEPTH = 0`) or the oldest queued request (`QUEUE_DEPTH > 0`;
a request accepted at edge *t* is head-eligible from cycle *t*+1). The head is

* **eligible for a bank** when it decodes without error *and* the port has a response credit (reads, acknowledged
  writes) — a posted write (`WRITE_ACK = 0`) needs no credit;
* **an error request** when the decoder flags RANGE / ALIGN / STROBE: it needs no bank and is issued as soon as the
  port has a response credit (it can never be blocked by bank traffic).

A port issues at most one request per cycle and requests exactly one bank, so no port can be granted twice.

## 2. Bank memory-port models (`PORT_MODE`)

| Model | Backend | Grants per bank per cycle | Same-row rule |
|---|---|---|---|
| **1RW** (single port) | `sram_backend_1rw` | 1 (read or write) | — (impossible) |
| **1R1W** (simple dual port) | `sram_backend_1r1w` | 1 read **and** 1 write | a read and a write of the same row are never granted together: the later one in priority order is stalled |
| **2RW** (true dual port) | `sram_backend_2rw` | 2, any kind | two accesses to one row are granted together only if both are reads |

The arbiter never grants more operations to a bank than its model allows — checked every cycle by an RTL assertion
and, independently, by the testbench on the DUT's actual issue set (`ev_issue` + its own address map). Requests to
**different banks** are served in the same cycle: up to min(`NUM_PORTS`, `NUM_BANKS` × grants-per-bank) accesses per
cycle.

## 3. Arbitration algorithm (per bank)

```
order = ARB == RR    ? ptr, ptr+1, ..., ptr-1 (mod NUM_PORTS)
                     : 0, 1, ..., NUM_PORTS-1
for p in order: if p is eligible for this bank:
        take the first slot p may use (rules of §2); otherwise p is NOT granted this cycle (conflict)
RR: if any grant:  ptr <- (first granted port) + 1
```

Properties:

* **Deterministic**: the grant set is a pure function of the eligible heads and the per-bank pointer (reset to 0).
  The testbench re-implements the specification independently and requires `ev_issue` to match it in every cycle of
  every test.
* **First requester always granted.** No hazard exists against an empty bank, so the first eligible port in priority
  order always gets a slot.
* **Starvation-free (RR) with a bound.** The pointer moves past the first winner; a port that stays eligible becomes
  first in order within `NUM_PORTS` - 1 grants, i.e. it waits at most `NUM_PORTS` - 1 cycles when the response channel
  is not the limit. The `conflict` test asserts this bound (max wait over ports measured ≤ `NUM_PORTS` − 1 in every
  configuration of the regression).
  *Why not "past the last winner"*: in 1R1W / 2RW, a port blocked by a same-row hazard can be bypassed by a later port
  that takes the second slot; moving the pointer past that later winner can skip the blocked port forever (e.g. port 0
  writes row X every cycle, port 1 reads row X, port 2 reads row Y: ptr 0 → grants 0 and 2 → ptr returns to 0 → port 1
  never served). Moving past the *first* winner rules this out. (BandwidthLab's 2RW / 1R1W model uses the last winner;
  see `reports/bwlab_compare.md`.)
* **FIXED** priority: port 0 highest. Port 0 never waits for a bank; lower ports can starve under sustained contention
  — measured, not hidden (`conflict` test prints per-port waits; doc 07).
* For 1RW the RR rule equals `sram_bank_controller`'s (ptr ← winner + 1): the 1RW / direct configurations are
  cycle-identical to that verified controller (doc 06 §5).

## 4. Conflicts, preservation, backpressure

| Situation | What happens |
|---|---|
| two or more eligible ports, one bank, more requests than slots | the losers are **not accepted** (`QUEUE_DEPTH = 0`: `req_ready = 0`) or stay at their queue head; the request is preserved unchanged and re-arbitrated next cycle |
| loser | `ev_conflict[p] = 1` for that cycle; `ev_bank_conflict[b] = 1`; `perf_conflict[p]` counts it |
| response consumer stalls (`rsp_ready = 0`) | the port's credits run out after `RSP_FIFO_DEPTH` outstanding responses; its next request is held (`ev_credit_stall[p]`); other ports are unaffected |
| request queue full (`QUEUE_DEPTH > 0`) | `req_ready = 0` (registered); the requester holds its request |

Nothing is ever dropped, re-ordered within a port or duplicated: the testbench's scoreboard checks every response
against the acceptance order and the reference model, and RTL assertions check misrouting / duplication of read data.

## 5. Events and counters

| Event (1-cycle pulse) | Meaning | Counter |
|---|---|---|
| `ev_accept[p]` | request accepted | `perf_accept[p]` |
| `ev_issue[p]` | request issued to a bank or to the error path | `perf_issue[p]` |
| `ev_conflict[p]` | eligible head lost bank arbitration (port limit or same-row hazard) | `perf_conflict[p]` |
| `ev_credit_stall[p]` | head blocked by response back-pressure | — |
| `ev_error[p]` | decode-error request issued | `perf_error[p]` |
| `ev_ecc_err[p]` | read failed the parity check | `perf_ecc_err` (all ports) |
| `ev_bank_ops[b]` | accesses performed by bank *b* (0..2) | `perf_bank_ops[b]` |
| `ev_bank_conflict[b]` | bank *b* left an eligible requester unserved | — |
| — | requests presented-or-queued and not issued, summed per cycle (Little's law: Σ per request (issue − present)) | `perf_wait[p]` |
| — | `rsp_valid && rsp_ready` | `perf_complete[p]` |
| — | cycles since `perf_clear` | `perf_cycles` |

Counters saturate (never wrap), clear on `rst_n` or `perf_clear`. Every counter value is compared with the testbench's
own count at the end of every phase of every test (`check_counters`).

## 6. Request queues (`QUEUE_DEPTH`)

`QUEUE_DEPTH > 0` inserts the DataFabric `dma_fifo` (unmodified, first-word fall-through) per port. It decouples the
requester from bank arbitration: `req_ready` becomes a register output (no combinational path from the address decoder
and arbiter to the requester, useful for timing closure at the vector-array boundary) and a requester can run ahead by
up to `QUEUE_DEPTH` requests while its head waits for a bank. The cost is one extra cycle of best-case latency and
`QUEUE_DEPTH × (1 + AW + DW + DW/8 + TAG_W)` flip-flops per port. There is no reordering: a queued request waits behind
its port's head (head-of-line blocking), which keeps per-port ordering trivial.
