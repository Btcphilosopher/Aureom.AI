# 04 — FPGA and ASIC memory mapping, read-during-write behaviour

Each bank is one SRAM Wrapper Library raw backend (`hpc_spm_bank.sv`), selected by `BACKEND`. Changing `BACKEND`
never changes the scratchpad's ports, timing or ordering. Full numbers: `reports/synth.md` (Yosys 0.33).

## 1. GENERIC (simulation, formal, logic synthesis)

`sram_generic_*`: behavioural arrays. In simulation `SRAMLIB_POISON` drives X on the read data in every cycle that is
not a valid read slot (catches consumers that rely on held data) and the arrays start as X (a read of never-written
memory is visible as X; the testbench tracks known bytes). An ASIC flow would turn this backend into flip-flops — it is
never used for silicon storage.

## 2. FPGA (`BACKEND = FPGA`): block-RAM inference, no vendor IP

`sram_fpga_{1rw,1r1w,2rw}` are synchronous-read inference templates (`(* ram_style = "block" *)`, per-lane write loop,
read only when not writing). Nothing assumes ASIC macros exist in the FPGA toolchain.

**Mapping rules that follow from the parameters**

* One inferred memory per bank: `BANK_DEPTH × STORE_W` (STORE_W = DATA_WIDTH, or 9/8 × DATA_WIDTH with parity).
* `BYTE_WE = 1` → per-byte write enables (Xilinx RAMB36E1 WEA[3:0] in ×36 mode; ECP5 DP16KD byte enables);
  `BYTE_WE = 0` → a single write enable (fewer control signals; required by some RAM primitives and by a future
  word-granular SECDED).
* `ECC_MODE = BYTE_PARITY` → 9-bit lanes, which Xilinx block RAM stores in its parity bits (DIPA/DOPA): **64 KiB +
  parity fits in exactly the same 16 RAMB36E1 as 64 KiB without parity**.
* `READ_LATENCY = 1` uses the BRAM output latch; `= 2` adds the BRAM's optional output register (no reset, so it can be
  absorbed — whether Yosys 0.33 absorbs it is not asserted; the RL 2 run shows +182 FFs, see the report); `≥ 3` adds
  fabric registers.
* `PORT_MODE`: 1RW → single-port BRAM; 1R1W → simple dual-port; 2RW → true dual-port. Small structures (response
  FIFOs, request queues) map to LUT-RAM or flip-flops.

**Yosys inference results (Xilinx 7-series `synth_xilinx -family xc7`; 2 ports, 32-bit, 1RW, RL 1 unless stated)**

| capacity | banks | RAMB36E1 (ideal) | LUTs | FFs |
|---|---|---|---|---|
| 64 KiB | 1 / 2 / 4 / 8 / 16 | 16 (16) in every case | 1,046 / 1,302 / 1,854 / 2,840 / 5,118 | 542 / 579 / 653 / 801 / 1,097 |
| 128 KiB | 2 / 4 / 8 / 16 | 32 (32) | 1,306 / 1,862 / 2,856 / 5,150 | 579 / 653 / 801 / 1,097 |
| 256 KiB | 2 / 4 / 8 / 16 | 64 (64) | 1,314 / 1,874 / 2,876 / 5,186 | 579 / 653 / 801 / 1,097 |

* Every point maps to the **ideal number of block RAMs** with **no flip-flop memory left** (`select -assert-none
  t:$mem`); the bank count changes only the control logic (arbiters, multiplexers, routing), which grows roughly with
  ports × banks. The counters (`PERF_EN = 1`) cost ≈ 600 LUTs / 576 FFs at 2 ports × 4 banks (`PERF_EN = 0`: 1,245
  LUTs / 77 FFs).
* 1R1W and 2RW (4 ports, 4 banks, 64 KiB) map to 16 RAMB36E1 as well; byte parity adds no block RAM.
* A 256 KiB scratchpad uses 64 of the 135 RAMB36E1 of the Arty A7-100T (xc7a100t) used by the repository's existing
  FPGA flow.
* Lattice ECP5 (`synth_ecp5`): 64 KiB / 4 banks → 32 DP16KD for 1RW and 1R1W — the data-bit ideal (16 Kbit data per DP16KD; its 2 Kbit parity bits are unused without ECC; the report's "ideal" column counts all 18 Kbit). **Known limitation:** the 2RW
  (true-dual-port) bank is not mapped by Yosys 0.33 on ECP5 ("no valid mapping found", also at 16 bit × 1024 and
  without byte enables) — use 1RW / 1R1W on ECP5 with this tool version.
* Lattice iCE40 (`synth_ice40`): 8 KiB, 16-bit → 16 SB_RAM40_4K (ideal).

**Not done:** Vivado / Quartus / Radiant synthesis, place-and-route, timing closure, bitstream, hardware run. No
FPGA clock frequency is claimed. Inference evidence only.

## 3. ASIC (`BACKEND = ASIC`, `MACRO = <catalogue id>`)

The library's `sram_asic_array` tiles real foundry / open-PDK macros to the bank's width and depth and **never falls
back to flip-flops**; the ASIC path is selected per instance by `MACRO` (catalogue: `sram_macro_ids.svh`, generated
from the library's manifests: SKY130 OpenRAM 1RW1R, GF180MCU 1RW, IHP SG13G2 1P and 2P). Port-model compatibility is
enforced by the library at elaboration (1R1W needs a macro with an independent read port; 2RW needs IHP 2P;
`READ_LATENCY` ≥ macro latency; no `INIT_FILE`).

**Macro integrity** (Yosys, pin-only black boxes; the exact macro count must survive synthesis and no `$mem` / latch
may exist). Because the arrays are black boxes, the remaining cells are the scratchpad's own control logic:

| configuration | macro | macros | control logic: generic cells / flip-flops |
|---|---|---|---|
| 64 KiB, 2 banks, 2 ports | IHP 1P 2048×32 | 8 | 4,420 / 707 |
| 64 KiB, 4 banks, 2 ports | IHP 1P 2048×32 | 8 | 5,211 / 777 |
| 64 KiB, 4 banks, 2 ports, `PERF_EN = 0` | IHP 1P 2048×32 | 8 | 2,036 / 233 |
| 64 KiB, 8 banks, 2 ports | IHP 1P 2048×32 | 8 | 7,093 / 913 |
| 64 KiB, 16 banks, 2 ports | IHP 1P 1024×32 | 16 | 10,964 / 1,193 |
| 128 KiB, 8 banks, 2 ports | IHP 1P 2048×32 | 16 | 7,346 / 921 |
| 256 KiB, 8 banks, 2 ports | IHP 1P 2048×32 | 32 | 8,150 / 929 |
| 256 KiB, 8 banks, 8 ports, queue 4 | IHP 1P 2048×32 | 32 | 34,448 / 5,273 |
| 64 KiB, 4 banks, 2RW, 4 ports | IHP 2P 1024×32 | 16 | 16,705 / 1,409 |
| 16 KiB, 4 banks, 1R1W, 4 ports | SKY130 1RW1R 32×512 | 8 | 14,234 / 1,385 |
| 64 KiB, 4 banks, byte parity | IHP 1P 2048×64 (36 of 64 bits used) | 8 | 5,930 / 825 |

Every row: exact macro count, no `$mem`, no latch. Observations: the control logic grows mainly with ports × banks (arbiters, slot multiplexers) and with the counters (≈ 3,200 of the 5,211 cells at 4 banks are the 32-bit counters); capacity barely changes it (8 banks: 7,093 → 8,150 cells from 64 to 256 KiB, the wider row addresses); a 16-bank 64 KiB scratchpad needs 1024-word
macros (16 smaller macros, more periphery area per bit); byte parity needs a 36-bit-wide array, which the catalogue's
32-bit macros cannot hold — a 64-bit macro wastes 28 bits per word, so a 36/40-bit compiled macro (commercial node) or
SECDED on 64-bit words is the efficient choice there.

**Not done:** no Liberty, LEF or GDS was used; generic cell counts are not silicon area; no timing, power,
placement or DFT. The library's commercial-node macros are placeholders that fail elaboration until licensed compiler
outputs exist.

## 4. Read-during-write behaviour: what the hardware does vs what the scratchpad guarantees

| Implementation | Same port: read data in a write cycle | Different ports, same address, same cycle |
|---|---|---|
| GENERIC model | no read data (write cycle produces none; X under `SRAMLIB_POISON`) | 1R1W: read returns the old word; 2RW: undefined by contract |
| FPGA template (library) | "no change" coding: output register keeps its previous value | 1R1W template: old word (read and write in separate processes); 2RW: not defined by the template |
| Xilinx 7-series BRAM | `WRITE_MODE` per port: WRITE_FIRST, READ_FIRST or NO_CHANGE | restricted: vendor "address collision" rules (UG473) |
| Intel M20K | new data or don't-care (per configuration) | old data or don't-care (mixed-port setting) |
| Lattice ECP5 DP16KD | `WRITEMODE` NORMAL / WRITETHROUGH / READBEFOREWRITE | not guaranteed |
| SKY130 OpenRAM 1RW1R | output not held: X one hold time after each edge | **undefined** (model warns) |
| GF180MCU 1RW | output held (truth table) | n/a (single port) |
| IHP SG13G2 2P | per macro datasheet | **undefined** |

**The scratchpad never relies on any of these.** (a) A port never reads the array in its own write cycle (a write
produces no read data by contract; read data is consumed only in the read's valid slot — enforced by
`SRAMLIB_POISON` in simulation). (b) The bank arbiter never issues a read and a write, or two writes, to the same row
of one bank in the same cycle (doc 03). (c) Read data is never assumed to be held. The architectural semantics
(doc 01 §6) — *a read returns every write issued at an earlier edge* — are therefore identical on GENERIC, FPGA and ASIC.
