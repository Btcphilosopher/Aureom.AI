# 00 — Repository audit and reuse decisions

Repository: `btcphilosopher/Aureom.AI`, branch `claude/wonderful-ramanujan-v7fu8s` (HEAD `531137f`). The SilicaFlux
material lives in `SilicaFlux-main/` as archives (`.zip`) plus loose `.sf` files (SystemVerilog with a custom
extension). Every archive named below was extracted and read; nothing in the repository was modified.

## 1. What exists

| Asset | Location | What it is | Verification evidence in the archive |
|---|---|---|---|
| **SilicaFlux SRAM Wrapper Library** (Project 01) | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-sramlib.zip` | technology-independent SRAM layer: raw backends `sram_backend_{1rw,1r1w,2rw}` over GENERIC / FPGA (BRAM inference) / ASIC (real SKY130, GF180MCU, IHP SG13G2 macros, tiled); handshake wrappers; `sram_rsp_path`; `sram_bank_controller`; MBIST | `reports/mem/SUMMARY.md`: lint 47/47, sim 53/53, cross-sim 5/5, equivalence vs vendor models 11/11, mutants 10/10, formal 9/9, synthesis 29/29, 2.7 M scoreboard checks (Verilator 5.020, Icarus 12, Yosys 0.33) |
| `sram_bank_controller` | same | N masters × B **single-port** banks, LOW/HIGH interleave, RR/fixed arbitration, one error bit, per-master in-order responses | as above + BMC of RR fairness (2×2) |
| **SilicaFlux DataFabric** (Project 03) | `SilicaFlux-main/silicaflux-datafabric.zip` | SFB2 bus (valid/ready + response back-pressure), crossbar, single-channel DMA, `dma_fifo`, `sfb_sram_slave` adapter onto the SRAM library, memory map (YAML single source of truth; `TSPM` = tile scratchpad window at 0x2000_0000) | unit/crossbar/SoC regressions, formal (interconnect unbounded, DMA bounded), GLS |
| **BandwidthLab** (Project 10) | `SilicaFlux-main/silicaflux-bandwidthlab.zip` | cycle-aware bandwidth simulator; `bandwidthlab.sram.BankedSram` (1RW/1R1W/2RW, queues, LOW/HIGH/XOR/SKEW maps); MemoryLab `bankbench` stimulus generator; RTL trace harness for `sram_bank_controller` | 1RW model cycle-equivalent to MemoryLab's BankController (itself validated against `sram_bank_controller`); 1R1W / 2RW / queues / XOR marked *not RTL-validated* |
| **MemoryFlow** v2.0.0 | `SilicaFlux-main/SilicaFlux2.0/SilicaFlux2.5/silicaflux-memoryflow-v2.0.0.zip` | `rtl/spm/sf_spm_banked.sv`: N ports × M single-port banks, modulo / XOR / block interleave, credits, overflow error, byte parity or SECDED (`rtl/ecc/sf_ecc_secded_{enc,dec}.sv`, RMW for partial writes), MBIST, conflict counters; own SRAM primitives `rtl/sram/` | `tb/unit/tb_spm.sv`, mutation testing in `reports/REPORT.md` |
| SilicaFlux-HPC Module 02 | `SilicaFlux-main/SilicaFlux2.0/silicaflux-hpc-m02-vector-lane.zip` | `hpc_vector_lane` (FP32/INT32 lane, valid/ready, tags, in-order completion) — naming and documentation conventions followed here (`hpc_` prefix, flat ports, `docs/`, `reports/`) | 132/132 regression, 28/28 mutants, GLS |
| SilicaFlux-HPC FP32 FMA | `SilicaFlux-main/SilicaFlux2.0/silicaflux-hpc-fp32-fma.zip` | arithmetic only | — |
| SilicaFlux-V `sfv_tile` | DataFabric `third_party/silicaflux-v/rtl/accel/sfv_tile.sv` | 16 KiB TSPM, 4 word-interleaved `sfv_sram_sp` banks, fixed priority, engine lock | SoC firmware tests |
| SilicaFlux 2.5 `memory_controller.sf` | `SilicaFlux-main/` | 8 banks × 512 × 128 b banked SPM, three requesters, parity | MemoryFlow inventory: elaborates |
| MemoryLab, MemoryFlow models, TimingFlow, FloorplanLab, TestCore | various zips | analysis tools, MBIST (`sftc_mbist_bank_mux`), macro-bank floorplans | — |

Not found anywhere: an HPC vector-array RTL (Module 03 is not in the repository), a SECDED design wired to an
SRAM-library bank, any FPGA vendor-tool (Vivado/Quartus) result, any silicon.

## 2. Reuse decisions

| Need | Decision | Why |
|---|---|---|
| Physical bank storage (GENERIC / FPGA / ASIC) | **Reused unmodified**: SRAM Wrapper Library `sram_backend_1rw`, `_1r1w`, `_2rw` and all backends | the designated SilicaFlux memory layer; verified; has real open-PDK macro adapters and BRAM templates; already has the exact raw contract (read data valid exactly READ_LATENCY cycles, never held) the bank pipeline needs |
| In-order, tagged, back-pressured responses with credits | **Reused unmodified**: `sram_rsp_path` | verified (formal + simulation), already carries an ID through the read pipeline; the error code travels in its ID field `{err_code, tag}` |
| Per-port request queue | **Reused unmodified**: DataFabric `dma_fifo` | verified FWFT FIFO with the exact push/pop-under-credit contract |
| Library constants / config-error macros | **Reused**: `sram_defs.svh` (`SRAM_CFG_FATAL`, `SRAM_CHK`, backend ids) | one convention across SilicaFlux memory RTL |
| Multi-port banked front end | **New** (`hpc_scratchpad`, `hpc_spm_addr_map`, `hpc_spm_bank_arb`, `hpc_spm_bank`, `hpc_spm_perf`) | neither existing controller meets the brief: `sram_bank_controller` has no 1R1W/2RW bank models, no request queues, no XOR map, no window base / unaligned / strobe error codes, no integrity option and no per-bank conflict events; MemoryFlow's `sf_spm_banked` has **no request tags**, a **fixed 3-cycle latency**, **single-port banks only**, **silently rounds unaligned addresses down** (`w = addr >> OFF`) and does not use the SRAM Wrapper Library. The new front end keeps `sram_bank_controller`'s timing contract, so for 1RW banks without queues it is **cycle-identical** to it (doc 06 §5) |
| Integrity | **New** byte parity; **SECDED reserved** | byte parity needs no RMW and is exercised by fault injection. MemoryFlow's `sf_ecc_secded_enc/dec` (with their mutation evidence) are the reuse candidates for the reserved SECDED mode (doc 05 §3) |
| Address-map reference / performance reference | **Reused**: BandwidthLab `BankMapper`, `BankedSram`, MemoryLab `bankbench` + RTL harness (all executed unmodified from the extracted archive) | independent models to compare against (doc 06 §5, doc 07) |
| ASIC macros | **Not assumed available in the FPGA toolchain**: the FPGA path is pure inference; the ASIC path instantiates real macros through the library and is checked with pin-only black boxes | brief §1 |

Vendored copies (unmodified, SHA-256 in `third_party/SHA256SUMS`, identical to the hashes in the library's own
`SHA256SUMS`): `third_party/silicaflux-sramlib/` (RTL subset + three docs + README),
`third_party/silicaflux-datafabric/rtl/dma/dma_fifo.sv`.

## 3. Tools available in this environment

Verilator 5.020, Icarus Verilog 12.0, Yosys 0.33 (with yosys-abc, yosys-smtbmc) and Python 3.13 with numpy — the same
versions the SRAM library's reports were produced with. **Not available:** Vivado, Quartus, Radiant, OpenROAD, a
standard-cell Liberty flow, SymbiYosys (`sby`). Consequences: FPGA results are Yosys inference evidence only (no
place-and-route, no timing); ASIC results are macro-integrity and generic-gate counts only (no area in µm², no
timing); no formal proof was run for the new RTL (the reused library components carry their own proofs).
