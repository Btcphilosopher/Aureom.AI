# 06 — Verification

All numbers below come from the generated reports in `reports/` (each JSON embeds commands, seeds and tool versions).

## 1. Testbench architecture (`tb/tb_hpc_scratchpad.sv`)

One self-checking SystemVerilog testbench, identical on Verilator 5.020 (`--binary --timing`) and Icarus 12, with a
deterministic xorshift PRNG (same stimulus on both simulators). Every test runs every checking layer:

| Layer | What it checks |
|---|---|
| **Reference memory model** (`rm_d`, `rm_p`, `rm_k`) | physical content per byte: data, stored parity bit, known/unknown. Writes are applied at their ISSUE edge (the documented commit point); every read's expected data is taken from it at the read's issue edge, so cross-port read-after-write / write-after-read outcomes are predicted exactly. |
| **Transaction scoreboard** | per port: accepted-not-issued ring (queued mode) and issued-not-answered ring; every response compared field by field (tag, `rsp_we`, `rsp_err`, `rsp_err_code`, `rsp_rdata`, `rsp_ecc_syn`), strictly in order; unsolicited / missing responses detected. |
| **Cycle-accurate reference of acceptance and issue** | the testbench independently derives each port's head, decode result (arithmetic formulation of doc 02), response credit and the per-bank arbitration (RR pointer / fixed priority, port-model slots, same-row hazards) and requires `ev_issue`, `req_ready`, `ev_conflict`, `ev_credit_stall`, `ev_error`, `ev_bank_ops`, `ev_bank_conflict` to match **every cycle**. |
| **Response timing** | `rsp_valid` must equal "oldest pending response exists and its issue cycle + READ_LATENCY ≤ now" every cycle: the response appears exactly READ_LATENCY cycles after issue unless back-pressured, then stays valid and stable. |
| **Structural checks on the DUT's actual issue set** | per bank: ≤ 1 access (1RW), ≤ 1 read + ≤ 1 write (1R1W), ≤ 2 (2RW); never a same-row pair with a write — computed with the testbench's own address map, independent of the reference arbiter. |
| **Backdoor** | whole-array comparison of every row of every bank against the model through the documented inverse map (physical placement = documented mapping), backdoor fill, single-bit fault injection. **Self-test:** at the first fill of every test a bit is corrupted behind the model's back and the whole-array check must report exactly that one row; a run that compares through the backdoor without this proof is counted as failed by the regression. |
| **Counters** | every `perf_*` counter compared with the testbench's own count at the end of every phase. |
| **Embedded RTL assertions** (`HPC_SPM_ASSERT`, plus the library's `SRAMLIB_ASSERT`) | one grant per slot, slot types, grant ⊆ eligible, read-data owner = response stage (misrouted / dropped read), no duplicated read data; response FIFO overflow, credit violations, payload stability under back-pressure (library). `SRAMLIB_POISON` makes the GENERIC arrays drive X outside valid read slots. |
| **Coverage counters** | per bank reads/writes, every error code, strobe patterns, conflicts, credit stalls, response stalls, hazard stalls, dual-issue cycles, parallel-issue cycles, same-cycle read/write pairs, read-the-cycle-after-write, resets, parity errors, max outstanding, max queue occupancy — printed per run and summed in `reports/regression.md`; tests fail when their target bins stay at 0. |

## 2. Test list → brief §8

| Brief item | Test(s) | Key checks |
|---|---|---|
| every bank | `all_banks` | every word written through the ports, **every row of every bank compared through the backdoor via the inverse map**, every word read back through a different port; per-bank coverage ≥ bank depth |
| address boundaries | `boundaries` | first/last row of every bank, first/last/middle words; out-of-range aliases (+CAP, +2CAP, +3CAP, top of address space, below BASE) rejected and the aliased words unchanged |
| read/write correctness | every test | reference model + scoreboard on every response |
| byte masks | `byte_mask` | all 2^(DW/8) strobe patterns (DW ≤ 64) or 512 incl. walking 1/0 (DW = 128) on words of every bank; `BYTE_WE = 0`: every partial pattern rejected with STROBE |
| bank conflicts | `conflict` | all ports on one bank (different rows), one word (hazards), stride = NUM_BANKS; RR bound (max wait ≤ NUM_PORTS − 1) asserted; fixed-priority port 0 never waits |
| simultaneous independent-bank accesses | `parallel` | NUM_PORTS ≤ NUM_BANKS: zero conflicts and exactly N + RL (+1 queued) cycles for N requests per port, i.e. one access per port per cycle |
| backpressure | `backpressure`, `stall_preserve` | 50 % random + periodic 25-cycle response stalls; outstanding ≤ RSP_FIFO_DEPTH; payload stable; credit stalls and response stalls must occur |
| reset | `reset` | four asynchronous resets at random points of random traffic; no response for discarded requests; array = all writes issued before reset, none of the dropped ones (backdoor); `busy = 0` after release |
| read-during-write collisions | `rdw` | same-port write→read / read→write back to back; cross-port same-word read + write (+ second write) presented in the same cycle, both resolutions observed; dual-port banks: same-row read/read co-issued, read/write stalled |
| out-of-range accesses | `oor`, `boundaries` | 30 % RANGE / ALIGN / STROBE requests mixed with traffic under back-pressure; no side effect (backdoor) |
| memory-content preservation under stalls | `stall_preserve` | 400-cycle total response stall with requests held, then 1000 idle cycles, then backdoor + front-door read-back |
| — | `smoke`, `random` | sanity; long random traffic in a 32-word hot window (cross-port RAW/WAR/WAW) and over the whole memory, 5 % errors, 20 % back-pressure, random gaps |
| integrity | `parity` | fault injection (doc 05) |

## 3. Staged regression (`scripts/run_regress.py`, `reports/regression.md`)

As the brief requires, the two-bank single-port design was verified first, then the bank count was scaled. A stage
only runs if all earlier stages passed.

| Stage | Configurations | Runs |
|---|---|---|
| lint | Verilator `-Wall` (6 configurations, clean on `rtl/`), Icarus elaboration (5) | 11 |
| invalid parameters | 27 combinations, each must stop elaboration with the stated message | 27 |
| 1: 2 banks, 1RW | 64 KiB / 2 ports baseline; RL 2; queue 4; 3 ports; byte parity; FPGA backend RL 2; fixed priority | 7 × 19 |
| 2: 4 banks | 128 KiB 4 ports (RR, FIXED, XOR); 64-bit, RL 2, queue 2, BASE 0x2000_0000; 5 ports 1R1W | 5 × 19 |
| 3: 8 banks | 256 KiB 4 ports; 256 KiB 8 ports 64-bit 2RW XOR RL 2 queue 4; 128 KiB 8 ports HIGH; 6 ports 1R1W queue 2 parity | 4 × 19 |
| 4: extended | 16 banks; 1 bank; 128-bit RL 3; word-write memory; posted writes; no back-pressure mode; byte-wide 1 KiB with ADDR_WIDTH = log2(CAP); 2RW parity FPGA; ADDR_WIDTH 20 + BASE 0x40000; single response credit; 16-bank XOR 1R1W FPGA | 11 × 19 |
| Icarus cross-simulation | 5 configurations, 29 tests (45 runs with seeds) | 45 |

(19 runs per configuration = 14 tests, four of them with 2-3 seeds.)

**Results (final run, frozen RTL):** lint 11/11, invalid parameters 27/27 rejected, stage 1 133/133, stage 2 95/95,
stage 3 76/76, stage 4 209/209, Icarus 45/45; 489 whole-array backdoor comparisons (each run proved its checker live);
in 27/27 `all_banks` runs every row of every bank was written and read through the ports. Coverage over all Verilator
runs includes 1.25 M conflict port-cycles, 16 k same-row hazard stalls, 26 k dual-issue bank cycles, 658 k
multi-bank-issue cycles, 160 k same-cycle same-word read/write presentations, 15 k reads issued the cycle after a write
to the same word, 320 k back-pressured response cycles, 302 k credit stalls, 216 mid-traffic resets, 300 injected
parity faults detected, 12.7 k RANGE / 26.6 k ALIGN / 287 STROBE errors. Details: `reports/regression.md`.

## 4. Mutation testing (`scripts/run_mutants.py`, `reports/mutation.md`)

26 deliberate bugs, each applied to a copy of `rtl/` (arbitration pointer, port limits, hazard rules, range / alignment
/ strobe decoding, map bits, byte enables, read-data routing, error isolation, credits, queue full, parity encode and
check, counters, error code / data zeroing, fixed-priority order, queue pop timing, slot data). A mutant is killed when
any of its tests fails. **Result: 26 / 26 killed.**

## 5. Independent references

* **Address map**: RTL decoder vs Python model golden vectors (7 configurations × ~4,000 vectors, Verilator and
  Icarus, `reports/unit_addr_map.md`); Python model bijectivity over 135 configurations and identity with BandwidthLab's
  `BankMapper`.
* **BandwidthLab / sram_bank_controller** (`scripts/bwlab_compare.py`, `reports/bwlab_compare.md`): MemoryLab
  `bankbench` stimulus (7 workloads, 3 % out-of-range) run on the RTL, on BandwidthLab's `BankedSram` and — where the
  configuration exists there — on the SRAM library's verified `sram_bank_controller` RTL through BandwidthLab's
  unmodified trace harness; acceptance, conflict and response cycles and read data compared transaction by transaction.
  **Result: 63 / 63 single-port runs identical to BandwidthLab (73,500 transactions); 42 / 42 identical to
  `sram_bank_controller`.**

## 6. Bugs found during this work (all fixed, all now covered)

| Found by | Problem | Fix |
|---|---|---|
| `parity` test (first stage-1 run) | testbench backdoor handshake could return before the per-bank processes ran (stale acknowledgement), so a fill could be skipped and — worse — a whole-array check could report "match" vacuously | 1 ps yield before testing the acknowledgement; **backdoor checker self-test** in every test; regression rejects backdoor checks without the self-test |
| negative elaboration tests | for `DATA_WIDTH = 4` and `BACKEND = ASIC` without `MACRO`, a vendored sub-module failed first (or Verilator looped) before the scratchpad's own message | datapath elaborated only for a valid configuration (`CFG_OK`); explicit ASIC-without-macro rule |
| Yosys synthesis | `return` in a function is not accepted by Yosys 0.33 | assignment to the function name |
| Icarus port of the testbench | Icarus 12 limitations (member select of array elements, `case` on strings, function output arguments, `return` in tasks) | testbench restructured; both simulators run the same file |

## 7. What is not verified

No formal proof of the new RTL (SymbiYosys is not installed; the reused library components carry their own bounded
proofs); no gate-level simulation; no FPGA place-and-route or hardware run; no ASIC timing, power or physical
verification; the ASIC backend is not simulated (vendor macro models are not redistributed — the library's own
equivalence runs cover the macro adapters).
