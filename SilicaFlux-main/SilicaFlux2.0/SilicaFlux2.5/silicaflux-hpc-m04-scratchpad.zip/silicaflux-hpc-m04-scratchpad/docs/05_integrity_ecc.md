# 05 — Integrity: byte parity implemented, ECC reserved

## 1. What is implemented: `ECC_MODE = BYTE_PARITY` (1)

* **Encode** (`hpc_spm_bank.sv`): every byte lane is stored as 9 bits `{p, byte}` with **odd** parity
  `p = ~^byte`. Odd rather than even parity so that an all-zero lane (a dead word line, a macro that powers up to
  zero) is detected. Stored word width = 9 × `DATA_WIDTH` / 8 (36 bits for 32-bit data).
* **Byte writes stay single-cycle.** Each lane's check bit depends only on that byte, so a partial write re-encodes
  exactly the bytes it writes — no read-modify-write, no extra latency, no extra bank occupancy. (This is the reason
  for byte parity rather than word ECC in a byte-writable scratchpad: see §3.)
* **Decode** (`hpc_scratchpad.sv`, per port, after read-data routing): `syndrome[l] = ~^{p_l, byte_l}`; a lane whose
  nine stored bits XOR to 0 has failed.
* **Reporting**: a read with a non-zero syndrome is answered with `rsp_err = 1`, `rsp_err_code = PARITY (4)`,
  `rsp_rdata = 0` and `rsp_ecc_syn` = the failing lanes; `ev_ecc_err[p]` pulses once per such read (at the cycle the
  data leaves the array), `perf_ecc_err` counts them. The error travels in order with the response.
* **Detects** any odd number of flipped bits within one byte lane (data or check bit), independently in every lane.
  **Does not detect** an even number of flips inside one lane, **does not correct** anything.

### Fault-injection evidence (`parity` test, run on the GENERIC and FPGA backends, 1RW / 1R1W / 2RW)

Faults are injected by flipping single stored bits through the array backdoor (the testbench updates its physical
reference model identically):

| Injection | Expected | Checked |
|---|---|---|
| single flip of each of the 9 bits (8 data + check bit) in every byte lane, words in every bank | PARITY, syndrome = exactly that lane | every response; `perf_ecc_err` equals the number of injected faults |
| full-word rewrite of a faulty word | error cleared | following read is clean |
| partial write covering the faulty byte | error cleared | following read is clean |
| partial write *not* covering the faulty byte | error persists | following read reports PARITY on that lane only |
| two flips in the same byte | **not detected**; corrupted data returned with `rsp_err = 0` | the reference model predicts the corrupted value: the limitation is demonstrated, not hidden |
| faults in two different bytes of one word | syndrome has both bits | checked |

Mutation testing confirms the checks are live: removing the decoder (M14) and encoding even parity (M15) are both
detected (`reports/mutation.md`).

## 2. What is reserved, not implemented: SECDED

`ECC_MODE = SECDED (2)` is **rejected at elaboration** with *"ECC_MODE = SECDED is reserved and NOT implemented (no
encoder/decoder exists)"*. No SECDED protection is claimed anywhere. The interface already carries what a SECDED
implementation needs:

| Reserved item | For |
|---|---|
| `ECC_MODE` value 2 | SECDED selection |
| `rsp_err_code` 5 (`ECC_UE`) | uncorrectable error on a read |
| `rsp_err_code` 6-7 | e.g. corrected-error notification if chosen to be visible on the response |
| `rsp_ecc_syn` (per-port syndrome output) | SECDED syndrome (its width would become the code's check-bit count) |
| `ev_ecc_err`, `perf_ecc_err` | corrected / uncorrected event counting |
| stored-word width path (`STORE_W`, `LANE_W` in `hpc_spm_bank`) | check bits appended to the stored word |

## 3. Design notes for a future SECDED mode

* A (39,32) / (72,64) Hamming SECDED code covers the whole word, so a byte write must read, merge, re-encode and
  write: a read-modify-write that occupies the bank for two accesses (or needs a 1R1W bank), adds a pipeline stage and
  creates a read-after-write forwarding hazard. Options: (a) SECDED only for `BYTE_WE = 0` (word-write memories —
  which is why `BYTE_WE = 0` exists), (b) byte-granular SECDED (e.g. (13,8) per byte — 62 % overhead), (c) RMW with
  bank-busy back-pressure through the existing arbiter.
* Acceptance criteria before any SECDED claim: encoder/decoder, syndrome reporting on `rsp_ecc_syn`, single-bit
  correction and double-bit detection proven by exhaustive single- and double-bit fault injection through the same
  backdoor mechanism, and scrubbing policy defined.
