# 07 — Performance

## 1. Method

All figures are **cycle-accurate RTL measurements** (Verilator) made by the self-checking testbench (`+test=perf`):
every run also passes the full scoreboard, reference arbiter and counter checks, so a performance number never comes
from a functionally wrong run. Script: `scripts/run_perf.py`; full tables: `reports/perf.md` / `.json`.

Each port is a saturating requester: it presents its next request in the cycle after the previous one is accepted
(`QUEUE_DEPTH = 0`) and `rsp_ready = 1` unless back-pressure is stated. 2,000 requests per port per run.

| Metric | Definition |
|---|---|
| accepted accesses / cycle | accepted requests / measurement span (first presentation → last response) |
| completed accesses / cycle | delivered responses / span (posted writes are not counted; every config here acknowledges writes) |
| bank utilisation | accesses performed by bank *b* / (span × accesses per bank per cycle) |
| conflict port-cycles, conflict rate | Σ `ev_conflict`; conflicts / (conflicts + issues) |
| wait | issue cycle − presentation cycle (cycles a request was presented or queued but not issued; equals `perf_wait`) |
| queue wait | issue cycle − acceptance cycle (0 without a request queue) |
| latency | response handshake − presentation |
| effective bandwidth | bytes moved per cycle: reads count the full word, writes the enabled bytes |
| efficiency | effective bandwidth / peak, peak = min(ports, banks × accesses per bank) × word bytes |

Bytes per cycle are the RTL-level quantity. Multiplying by a clock frequency gives bytes per second; no frequency has
been established for this RTL (no timing closure), so **no GB/s figure is claimed**. For orientation only: every
1 byte/cycle is 0.1 GB/s per 100 MHz.

Workloads (per port *p*): `seq` unit-stride stream in a private region (64-word read / write blocks), `seqrd`
unit-stride reads, `rand` uniform random (50 % writes), `stride` stride = NUM_BANKS words, `stride2` stride 2,
`samebank` all ports in bank 0, `vecdma` ports 0..P-2 read interleaved words of one region (vector lanes) while port
P-1 streams writes into another (DMA), `tile` 8×8 tile walks of a 64-word-wide matrix, `hot` random in a 16-word
window.

## 2. Bank count (64 KiB, 4 ports, 32-bit, 1RW, LOW, RR, RL 1) — accepted accesses per cycle

| workload | 1 bank | 2 banks | 4 banks | 8 banks | 16 banks |
|---|---|---|---|---|---|
| seq (private unit-stride streams) | 1.000 | 1.999 | **3.992** | 3.992 | 3.992 |
| tile (8×8 tile walks) | 1.000 | 1.999 | 3.992 | 3.992 | 3.996 |
| rand (uniform, 50 % writes) | 1.000 | 1.749 | 2.608 | 3.232 | 3.605 |
| stride = NUM_BANKS words | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |
| stride 2 | 1.000 | 1.000 | 1.999 | 3.992 | 3.992 |
| vecdma (3 lanes + DMA) | 1.000 | 1.999 | 2.399 | **3.996** | 3.527 |
| samebank | 1.000 | 1.000 | 1.000 | 1.000 | 1.000 |

Random traffic in more detail (same configuration):

| banks | acc / cycle | B / cycle (peak 16) | conflict rate | avg / max wait (cycles) | avg latency | bank utilisation |
|---|---|---|---|---|---|---|
| 1 | 1.000 | 4.00 | 0.750 | 3.00 / 3 | 4.00 | 1.00 |
| 2 | 1.749 | 7.00 | 0.559 | 1.27 / 3 | 2.27 | 0.87-0.88 |
| 4 | 2.608 | 10.43 | 0.340 | 0.52 / 3 | 1.52 | 0.64-0.66 |
| 8 | 3.232 | 12.93 | 0.181 | 0.22 / 3 | 1.22 | 0.38-0.42 |
| 16 | 3.605 | 14.42 | 0.095 | 0.10 / 3 | 1.10 | 0.21-0.24 |

Observations:

* **Streams are conflict-free once banks ≥ ports.** With LOW interleave four unit-stride streams reach 3.99 accesses
  per cycle (99.8 % of the 16 B/cycle peak) from 4 banks on; the round-robin arbiter staggers streams that start in
  the same bank after one collision, then they never meet again (conflict rate 0.001).
* **Random traffic** follows the balls-into-bins trend: each doubling of the bank count roughly halves the conflict
  rate. The maximum wait is always ≤ NUM_PORTS − 1 = 3 cycles (the RR bound of doc 03).
* **stride = NUM_BANKS** serialises every port on one bank with LOW (1 access/cycle at any bank count) — the
  pathological case the alternative map exists for.
* **Capacity does not change cycle behaviour**: 8 banks at 64 / 128 / 256 KiB give identical streaming results and
  random results within 1.5 % (3.232 / 3.249 / 3.276, different address draws).
* **Workload resonance:** `vecdma` (lanes reading with word stride 3, DMA streaming) is conflict-free at 8 banks but
  not at 4 or 16 — the lane stride relative to the bank count decides. Bank count must be chosen against the real
  access patterns, not only the port count.

## 3. Alternative mapping (XOR) — accepted accesses per cycle, 4 ports

| workload | 2 banks | 4 banks | 8 banks | 16 banks |
|---|---|---|---|---|
| seq | 1.600 | 2.666 | 3.653 | 3.904 |
| rand | 1.748 | 2.626 | 3.230 | 3.615 |
| stride = NUM_BANKS | **1.999** | **3.992** | **3.992** | **3.992** |
| stride 2 | 1.999 | 3.196 | 3.992 | 3.992 |
| vecdma | 2.000 | 2.909 | 3.283 | 3.714 |

XOR removes the power-of-two stride pathology (stride = banks: 1.0 → 3.99) and helps stride 2, leaves random traffic
unchanged, but **costs unit-stride streams** (4 banks: 3.99 → 2.67): streams in different rows see different bank
permutations, so the RR staggering that makes LOW conflict-free no longer holds. With 8 ports and 16 banks the same
trade-off appears (seq 7.97 LOW vs 7.57 XOR; stride 1.0 vs 7.97). Recommendation: LOW for vector/DMA streaming;
XOR only where power-of-two strides dominate.

## 4. Bank memory-port model (64 KiB, 4 banks, 4 ports)

| workload | 1RW | 1R1W | 2RW |
|---|---|---|---|
| rand | 2.608 | 3.265 | 3.777 |
| samebank | 1.000 | 1.748 | 2.000 |
| stride = banks | 1.000 | 1.000 | 2.000 |
| stride 2 | 1.999 | 1.999 | 3.996 |
| seq / vecdma | 3.992 / 2.399 | 3.992 / 3.998 | 3.996 / 3.998 |

A dual-ported bank doubles the bandwidth of a hot bank (2RW) or of read/write mixes (1R1W: one read + one write;
stride workloads here are read-only so 1R1W does not help them). 2RW at 4 banks beats 1RW at 8 banks on random
traffic (3.78 vs 3.23) but costs true-dual-port macros (IHP 2P only in the open catalogue) and does not map on ECP5
with Yosys 0.33 (doc 04).

## 5. Queues, latency, arbitration, back-pressure (64 KiB, 4 ports)

| configuration | workload | acc / cycle | avg wait | avg queue wait | avg latency | max wait |
|---|---|---|---|---|---|---|
| 4 banks, Q0 | rand | 2.608 | 0.52 | 0 | 1.52 | 3 |
| 4 banks, **QUEUE_DEPTH 4** | rand | 2.608 | 5.57 | 5.06 | 6.57 | 13 |
| 4 banks, **RL 3** | rand | 2.607 | 0.52 | 0 | 3.52 | 3 |
| 4 banks, **FIXED** | samebank | 1.000 | 1.50 | 0 | 2.50 | **6000** |
| 4 banks, FIXED | rand | 2.185 | 0.41 | 0 | 1.41 | 17 |
| 16 banks, **25 % back-pressure** | rand | 2.869 | 0.38 | 0 | 2.02 | 7 |

* **Request queues do not create bandwidth.** Saturating requesters simply fill the queue: throughput is unchanged
  and every request waits ~5 cycles longer. Use `QUEUE_DEPTH` for timing decoupling (registered `req_ready`) or for
  bursty requesters, not for throughput.
* `READ_LATENCY` adds latency 1:1 and costs no throughput (credits = RL + 1).
* **Fixed priority starves:** on one hot bank the lowest-priority port waited 6000 cycles (until the others finished
  their 2000 requests each); random throughput also drops (2.19 vs 2.61). RR is the default.
* **Back-pressure:** with 25 % `rsp_ready = 0` the per-port credits (RL + 1 = 2) run out and throughput drops to
  2.87 even with 16 banks; a deeper `RSP_FIFO_DEPTH` absorbs bursty consumers.

## 6. Eight ports

| configuration | seq | rand | stride = banks | vecdma |
|---|---|---|---|---|
| 8 banks, LOW | 7.968 | 4.884 | 1.000 | 4.306 |
| 16 banks, LOW | 7.968 | 6.255 | 1.000 | 5.710 |
| 16 banks, XOR | 7.572 | 6.255 | 7.968 | 6.289 |
| 8 banks, 2RW | 7.984 | 7.266 | 2.000 | 7.996 |

Streaming scales linearly to 8 ports (31.9 of 32 B/cycle).

## 7. Comparison with BandwidthLab

`scripts/bwlab_compare.py` (`reports/bwlab_compare.md`) runs the same MemoryLab `bankbench` stimulus on the RTL, on
BandwidthLab's `BankedSram` and on the SRAM library's verified `sram_bank_controller` RTL:

* **1RW banks: 63 / 63 runs identical cycle for cycle** with BandwidthLab (73,500 transactions — every acceptance,
  conflict and response cycle and every read datum) across 9 configurations (2-8 ports, 1-8 banks, RL 1-3, LOW / HIGH
  / XOR, RR / FIXED, request queues 0 / 2 / 4, 0-30 % back-pressure) × 7 workloads.
* **42 / 42 runs identical to `sram_bank_controller`** where that controller supports the configuration.
* **1R1W / 2RW** (BandwidthLab extensions it marks as not RTL-validated): aggregate accepted-accesses-per-cycle equal
  in 13 of 14 runs and within 0.8 % in the last; per-transaction order differs in 8 of 14 runs because BandwidthLab
  moves the round-robin pointer past the *last* winner and uses an alternating-priority bit for 1R1W collisions,
  while the RTL moves it past the *first* winner (starvation freedom, doc 03 §3).

Consequence: BandwidthLab can be used directly for architecture exploration of this scratchpad with 1RW banks — its
results are the RTL's results — and as a throughput estimate for dual-port banks.
