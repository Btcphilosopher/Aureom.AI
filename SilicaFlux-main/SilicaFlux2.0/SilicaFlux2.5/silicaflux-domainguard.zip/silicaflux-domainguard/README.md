# SilicaFlux · DomainGuard (Module 97)

**DMA memory protection and address translation for the SilicaFlux cloud-compute die.**
Primary module: [`rtl/dg/sf_albion_iommu.sv`](rtl/dg/sf_albion_iommu.sv)

DomainGuard is a synthesizable multi-port IOMMU-style unit: every bus initiator (host memory
window, DMA engine, control-core fetch) is filtered through per-domain 4 KiB page / region
translation with read/write permissions, a deny-by-default reset state, a drain barrier for
invalidation, a fault log, and a privileged, atomic admin interface.

> **Not a RISC-V IOMMU.** It is a deliberately simple flat-table design. It does not implement the
> RISC-V IOMMU specification and must not be described as compliant with it
> (`docs/03_ADDRESS_TRANSLATION_SPEC.md` §9).

## Status in one paragraph

Everything below was run in this package's environment (Verilator 5.020, Yosys 0.33, cvc5 1.1.2);
logs are in `reports/`, and `docs/05_SECURITY_TESTING_REPORT.md` is the evidence-backed account,
including what was **not** proved. Headline: a 159,590-check adversarial unit testbench; a 4.28 M-check protocol-violation fuzzer (hostile initiator); a 193-check system testbench in which **none of 494 physical memory writes was unauthorised**; the stand-in's own original 186-check testbench passing unchanged against the protected die; a structural no-bypass audit; unbounded k-induction proofs of the isolation properties (P1–P8) on two small configurations with all 8 cover points reached; generic synthesis (≈21.8 k cells, no latches); and 21 of 22 planted bugs detected (the survivor is a deliberately planted *equivalent* mutant).

## Layout

| Path | Contents |
|---|---|
| `rtl/dg/` | the product: `sf_albion_iommu.sv` (top), `sf_albion_port.sv`, `sf_albion_xlate.sv`, `sf_albion_defs.svh`, `sf_albion_formal.svh`, lint waiver |
| `rtl/integration/` | `sf_dg_fm2dg`, `sf_dg_dg2fm` adapters and `silicaflux_dietop_dg` (the protected stand-in die) |
| `third_party/p40_standin/` | the **unmodified** stand-in RTL and its original testbench, with SHA-256 provenance |
| `tb/unit/` | adversarial unit testbench (oracle + downstream gate + canary image) and a protocol-violation fuzzer (`tb_dg_fuzz.sv`) |
| `tb/system/` | system testbench with physical-write monitor; regression TB (generated from the stand-in's own TB) |
| `formal/` | formal driver (`yosys` + `yosys-smtbmc` + `cvc5`); the properties are in `rtl/dg/sf_albion_formal.svh` |
| `scripts/` | structural bypass audit, mutation harness, regression-TB generator |
| `docs/` | architecture + DMA path analysis, threat model, register spec, translation spec, integration guide, security testing report |
| `reports/` | logs of the runs reported in the documents |

## Quick start

```bash
make all          # lint, synthesis check, unit sim, fuzzer, system sim, regression, bypass audit, formal proofs, cover points
make mutation     # ~25 min: plants 22 security bugs, shows which checks catch each
```

Requirements: `verilator` ≥ 5.020, `yosys` (0.33 used), `cvc5`, `python3` — all available as Ubuntu 24.04 apt packages.

## Documents

1. [`00_ARCHITECTURE.md`](docs/00_ARCHITECTURE.md): inspection of the DMA masters, the complete path before/after, design decisions
2. [`01_THREAT_MODEL.md`](docs/01_THREAT_MODEL.md)
3. [`02_REGISTER_SPEC.md`](docs/02_REGISTER_SPEC.md)
4. [`03_ADDRESS_TRANSLATION_SPEC.md`](docs/03_ADDRESS_TRANSLATION_SPEC.md)
5. [`04_INTEGRATION_GUIDE.md`](docs/04_INTEGRATION_GUIDE.md)
6. [`05_SECURITY_TESTING_REPORT.md`](docs/05_SECURITY_TESTING_REPORT.md)

## What you must know before relying on it

* **Formal proofs are on small configurations** (2 ports; 2–3 domains; 2–3 entries; 14-bit
  addresses; 8-bit data). The production-sized configuration is verified by simulation only.
* The guarantee depends on assumptions listed in the threat model §4 — above all that `csr_priv` and
  `host_sid` come from trusted hardware and that reset is a system reset.
* Revocation completes when `STATUS.busy` falls, not before. Software must wait before reusing a
  physical page, and must scrub it.
* One burst per port at a time, store-and-forward: this is a security-first design, not a
  throughput-optimised one.
* The "DieTop" it was integrated into is the Project-40 **stand-in** (the integrated DieTop of
  Projects 31–39 was not available). The integration pattern transfers; the audit must be re-run on
  the real top.
