// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | tb_dg_fuzz
// Protocol-violation fuzzer for sf_albion_iommu. A HOSTILE initiator drives every
// upstream signal randomly on every cycle: `valid` may drop or rise at any time,
// W data is offered with or without a command, tid / sid / address / length are
// random (mapped, unmapped, crossing, misaligned, out-of-range stream), the
// response channel stalls randomly, and the CSR bus is hammered with random
// UNPRIVILEGED accesses.
//
// The configuration is static (programmed by the privileged admin first), so a
// simple oracle can decide every ACCEPTED command. Checked on every cycle:
//   * a downstream command appears only for a command the DUT accepted AND the
//     oracle grants, exactly once, with the oracle's PA / direction / length / tid
//   * a write command is issued only after all len+1 data beats were accepted
//   * downstream write data and strobes equal the data accepted from the initiator
//   * no downstream write beat without an issued command, none beyond len
//   * the DUT never accepts a W beat without a pending accepted write command
//   * every accepted command gets exactly one correct response (tid, direction,
//     err = !grant, last, beat count, zero data when denied)
//   * the unprivileged CSR hammering never changes the configuration
// Prints "TB_RESULT PASS checks=<n>" or "TB_RESULT FAIL errors=<n>".
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
`include "sf_albion_defs.svh"

module tb_dg_fuzz;
  localparam int NP = 3, ND = 8, NS = 3, NE = 16, IOVA_W = 24, PA_W = 22, DW = 32, LW = 4, TW = 4, MAXO = 6, FQD = 8, CW = 16;
  localparam int SW = 2, SB = DW/8, MAXB = 1 << LW;
  parameter int SEED = 1234;
  parameter int NCYC = 400000;

  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NP-1:0]        us_cmd_valid = 0, us_cmd_we = 0, us_w_valid = 0, us_r_ready = 0;
  wire  [NP-1:0]        us_cmd_ready, us_w_ready, us_r_valid, us_r_we, us_r_err, us_r_last;
  logic [NP*TW-1:0]     us_cmd_tid = 0;
  logic [NP*SW-1:0]     us_cmd_sid = 0;
  logic [NP*IOVA_W-1:0] us_cmd_addr = 0;
  logic [NP*LW-1:0]     us_cmd_len = 0;
  logic [NP*DW-1:0]     us_w_data = 0;
  logic [NP*SB-1:0]     us_w_strb = 0;
  wire  [NP*TW-1:0]     us_r_tid;
  wire  [NP*DW-1:0]     us_r_data;
  wire  [NP-1:0]        ds_cmd_valid, ds_cmd_we, ds_w_valid, ds_w_last, ds_r_ready;
  logic [NP-1:0]        ds_cmd_ready = 0, ds_w_ready = 0, ds_r_valid = 0, ds_r_err = 0;
  wire  [NP*TW-1:0]     ds_cmd_tid;
  wire  [NP*PA_W-1:0]   ds_cmd_addr;
  wire  [NP*LW-1:0]     ds_cmd_len;
  wire  [NP*DW-1:0]     ds_w_data;
  wire  [NP*SB-1:0]     ds_w_strb;
  logic [NP*DW-1:0]     ds_r_data = 0;
  logic csr_valid = 0, csr_we = 0, csr_priv = 1;
  logic [7:0] csr_addr = 0;
  logic [31:0] csr_wdata = 0;
  wire csr_hit, irq;
  wire [31:0] csr_rdata;

  sf_albion_iommu #(.NUM_PORTS(NP), .NUM_DOMAINS(ND), .NUM_STREAMS(NS), .NUM_ENTRIES(NE), .IOVA_W(IOVA_W), .PA_W(PA_W),
                    .DATA_W(DW), .LEN_W(LW), .TID_W(TW), .MAX_ORDER(MAXO), .FQ_DEPTH(FQD), .CNT_W(CW)) dut (
    .clk(clk), .rst_n(rst_n),
    .us_cmd_valid(us_cmd_valid), .us_cmd_ready(us_cmd_ready), .us_cmd_tid(us_cmd_tid), .us_cmd_sid(us_cmd_sid),
    .us_cmd_we(us_cmd_we), .us_cmd_addr(us_cmd_addr), .us_cmd_len(us_cmd_len),
    .us_w_valid(us_w_valid), .us_w_ready(us_w_ready), .us_w_data(us_w_data), .us_w_strb(us_w_strb),
    .us_r_valid(us_r_valid), .us_r_ready(us_r_ready), .us_r_tid(us_r_tid), .us_r_we(us_r_we), .us_r_err(us_r_err),
    .us_r_last(us_r_last), .us_r_data(us_r_data),
    .ds_cmd_valid(ds_cmd_valid), .ds_cmd_ready(ds_cmd_ready), .ds_cmd_tid(ds_cmd_tid), .ds_cmd_we(ds_cmd_we),
    .ds_cmd_addr(ds_cmd_addr), .ds_cmd_len(ds_cmd_len), .ds_w_valid(ds_w_valid), .ds_w_ready(ds_w_ready),
    .ds_w_data(ds_w_data), .ds_w_strb(ds_w_strb), .ds_w_last(ds_w_last), .ds_r_valid(ds_r_valid),
    .ds_r_ready(ds_r_ready), .ds_r_err(ds_r_err), .ds_r_data(ds_r_data),
    .csr_valid(csr_valid), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata), .csr_priv(csr_priv),
    .csr_hit(csr_hit), .csr_rdata(csr_rdata), .irq(irq));

  int errors = 0, checks = 0;
  task automatic ck(input bit c, input string what);
    checks++; if (!c) begin errors++; if (errors < 20) $display("[FAIL] %s (t=%0t)", what, $time); end
  endtask

  // ---------------- static configuration + mirror ----------------
  bit m_dom_en [ND], m_dom_rd [ND], m_dom_wr [ND];
  bit m_ctx_v [NP][NS]; int m_ctx_d [NP][NS];
  bit m_ent_v [NE], m_ent_r [NE], m_ent_w [NE]; int m_ent_dom [NE], m_ent_ord [NE];
  longint m_ent_ipn [NE], m_ent_ppn [NE];
  bit m_glob;

  task automatic csr_w(input [7:0] a, input [31:0] d);
    @(posedge clk); #1; csr_valid = 1; csr_we = 1; csr_priv = 1; csr_addr = a; csr_wdata = d;
    @(posedge clk); #1; csr_valid = 0; csr_we = 0;
  endtask
  task automatic csr_r(input [7:0] a, output [31:0] d);
    @(posedge clk); #1; csr_valid = 1; csr_we = 0; csr_priv = 1; csr_addr = a; #2; d = csr_rdata;
    @(posedge clk); #1; csr_valid = 0;
  endtask
  task automatic cmd(input int op, input int idx);
    logic [31:0] st; int n = 0;
    csr_w(8'h0D, 32'((idx << 8) | op));
    csr_r(8'h05, st); while (st[0] && n < 1000) begin csr_r(8'h05, st); n++; end
    ck(st[11:8] == 0, "admin command accepted");
  endtask
  task automatic dom(input int d, input bit r, input bit w);
    csr_w(8'h0C, 32'(d | (1 << 8) | (r << 9) | (w << 10))); cmd(`SF_DG_OP_DOM_SET, 0); m_dom_en[d] = 1; m_dom_rd[d] = r; m_dom_wr[d] = w;
  endtask
  task automatic ctx(input int p, input int s, input int d);
    csr_w(8'h0B, 32'(p | (s << 8) | (d << 16))); cmd(`SF_DG_OP_CTX_SET, 0); m_ctx_v[p][s] = 1; m_ctx_d[p][s] = d;
  endtask
  task automatic ent(input int i, input int d, input longint ipn, input longint ppn, input int o, input bit r, input bit w);
    csr_w(8'h08, 32'(ipn)); csr_w(8'h09, 32'(ppn)); csr_w(8'h0A, 32'(r | (w << 1) | (o << 8) | (d << 16)));
    cmd(`SF_DG_OP_ENT_SET, i);
    m_ent_v[i] = 1; m_ent_dom[i] = d; m_ent_ipn[i] = ipn; m_ent_ppn[i] = ppn; m_ent_ord[i] = o; m_ent_r[i] = r; m_ent_w[i] = w;
  endtask

  task automatic decide(input int p, input int sid, input bit we, input longint a, input int len,
                        output bit grant, output longint pa);
    int d; longint pg, off, nb; int he = -1;
    grant = 0; pa = 0;
    if (!m_glob) return;
    if (sid >= NS || !m_ctx_v[p][(sid < NS) ? sid : 0]) return;
    d = m_ctx_d[p][sid];
    if (!m_dom_en[d]) return;
    if (a % SB != 0) return;
    off = a % 4096; nb = (len + 1) * SB;
    if (off + nb > 4096) return;
    pg = a / 4096;
    for (int e = 0; e < NE; e++)
      if (he < 0 && m_ent_v[e] && m_ent_dom[e] == d && pg >= m_ent_ipn[e] && pg <= m_ent_ipn[e] + (longint'(1) << m_ent_ord[e]) - 1) he = e;
    if (he < 0) return;
    if (we ? !(m_ent_w[he] && m_dom_wr[d]) : !(m_ent_r[he] && m_dom_rd[d])) return;
    pa = (m_ent_ppn[he] + (pg - m_ent_ipn[he])) * 4096 + off; grant = 1;
  endtask

  // ---------------- hostile upstream driver ----------------
  function automatic longint pick_addr();
    int c = $urandom_range(9, 0);
    longint base;
    case (c)
      0, 1, 2: base = 24'h100000;                 // mapped RW page of some domain
      3:       base = 24'h101000;                 // adjacent RO page
      4:       base = 24'h200000 + 4096 * $urandom_range(3, 0);   // region
      5:       base = 24'h300000;                 // other tenant's
      6:       base = 24'h400000;                 // shared RO
      7:       return longint'($urandom_range(24'hFFFFFF, 0));    // anything
      8:       return 24'h100000 + 4096 - 4 * $urandom_range(9, 1);       // near a page end (crossing)
      default: return 24'h100000 + 4 * $urandom_range(1023, 0) + $urandom_range(3, 0);  // maybe misaligned
    endcase
    return base + 4 * $urandom_range(1023, 0);
  endfunction

  int p_cmd_pct = 0, p_w_pct = 0, p_r_pct = 0;   // the hostile driver stays idle until the admin has configured the unit
  bit csr_fuzz_en = 0;               // hostile CSR traffic only during the fuzz phase
  int cyc = 0;
  always @(posedge clk) begin
    cyc <= cyc + 1;
    if (rst_n && cyc > 0) begin
      #1;
      for (int p = 0; p < NP; p++) begin
        // valid can rise and drop at any time, fields change every cycle
        us_cmd_valid[p] = ($urandom_range(99, 0) < p_cmd_pct);
        us_cmd_tid[p*TW +: TW] = TW'($urandom());
        us_cmd_sid[p*SW +: SW] = SW'($urandom_range(3, 0));
        us_cmd_we[p] = $urandom_range(1, 0);
        us_cmd_addr[p*IOVA_W +: IOVA_W] = IOVA_W'(pick_addr());
        us_cmd_len[p*LW +: LW] = LW'($urandom());
        us_w_valid[p] = ($urandom_range(99, 0) < p_w_pct);
        us_w_data[p*DW +: DW] = $urandom();
        us_w_strb[p*SB +: SB] = SB'($urandom());
        us_r_ready[p] = ($urandom_range(99, 0) < p_r_pct);
      end
      // unprivileged CSR garbage (must never change anything); writes only, aimed at the whole map
      if (csr_fuzz_en) begin
        csr_valid = ($urandom_range(3, 0) == 0); csr_we = $urandom_range(1, 0); csr_priv = 0;
        csr_addr = 8'($urandom()); csr_wdata = $urandom();
      end
    end
  end

  // ---------------- compliant downstream with random ready/latency ----------------
  typedef enum int {D_IDLE, D_W, D_B, D_R} dst_t;
  dst_t dst [NP]; int d_len [NP], d_beat [NP]; bit d_we [NP];
  int ds_pct = 60;

  // ---------------- oracle bookkeeping (per port) ----------------
  bit e_act [NP], e_grant [NP], e_we [NP], e_cmdseen [NP];
  longint e_pa [NP]; int e_len [NP], e_tid [NP], e_wb [NP], e_rb [NP], e_db [NP];
  logic [DW-1:0] e_wd [NP][MAXB]; logic [SB-1:0] e_ws [NP][MAXB];
  int n_acc = 0, n_grant = 0, n_deny = 0, n_wgrant = 0, n_resp = 0, n_wbeats = 0;
  logic [31:0] cfg_snapshot [4];

  always @(posedge clk) if (rst_n) begin
    for (int p = 0; p < NP; p++) begin
      // ---- upstream command accepted
      if (us_cmd_valid[p] && us_cmd_ready[p]) begin
        bit g; longint pa;
        ck(!e_act[p], "DUT accepted a command while a previous one was still unanswered");
        decide(p, int'(us_cmd_sid[p*SW +: SW]), us_cmd_we[p], longint'(us_cmd_addr[p*IOVA_W +: IOVA_W]), int'(us_cmd_len[p*LW +: LW]), g, pa);
        e_act[p] = 1; e_grant[p] = g; e_pa[p] = pa; e_we[p] = us_cmd_we[p]; e_len[p] = int'(us_cmd_len[p*LW +: LW]);
        e_tid[p] = int'(us_cmd_tid[p*TW +: TW]); e_wb[p] = 0; e_rb[p] = 0; e_db[p] = 0; e_cmdseen[p] = 0;
        n_acc++; if (g) begin n_grant++; if (us_cmd_we[p]) n_wgrant++; end else n_deny++;
      end
      // ---- upstream W accepted
      if (us_w_valid[p] && us_w_ready[p]) begin
        ck(e_act[p] && e_we[p] && e_wb[p] <= e_len[p] && !e_cmdseen[p], "DUT accepted a W beat with no pending accepted write command (or too many)");
        if (e_act[p] && e_we[p] && e_wb[p] <= e_len[p]) begin
          e_wd[p][e_wb[p]] = us_w_data[p*DW +: DW]; e_ws[p][e_wb[p]] = us_w_strb[p*SB +: SB]; e_wb[p]++;
        end
      end
      // ---- downstream command
      if (ds_cmd_valid[p] && ds_cmd_ready[p]) begin
        ck(e_act[p] && e_grant[p] && !e_cmdseen[p], "UNAUTHORISED or duplicate downstream command");
        if (e_act[p] && e_grant[p]) begin
          ck(longint'(ds_cmd_addr[p*PA_W +: PA_W]) == e_pa[p], "downstream PA");
          ck(ds_cmd_we[p] == e_we[p], "downstream direction");
          ck(int'(ds_cmd_len[p*LW +: LW]) == e_len[p], "downstream length");
          ck(int'(ds_cmd_tid[p*TW +: TW]) == e_tid[p], "downstream tid");
          if (e_we[p]) ck(e_wb[p] == e_len[p] + 1, "write issued before all data was accepted");
        end
        e_cmdseen[p] = 1; d_len[p] = int'(ds_cmd_len[p*LW +: LW]); d_we[p] = ds_cmd_we[p]; d_beat[p] = 0;
        ds_cmd_ready[p] <= 0;
        dst[p] = ds_cmd_we[p] ? D_W : D_R;
      end else if (dst[p] == D_IDLE) ds_cmd_ready[p] <= ($urandom_range(99, 0) < ds_pct);
      // ---- downstream write beat
      if (ds_w_valid[p] && ds_w_ready[p]) begin
        n_wbeats++;
        ck(e_act[p] && e_grant[p] && e_we[p] && e_cmdseen[p] && e_db[p] <= e_len[p], "downstream write beat without an authorised issued command");
        if (e_act[p] && e_db[p] <= e_len[p]) begin
          for (int k = 0; k < SB; k++) begin
            ck(ds_w_strb[p*SB + k] == e_ws[p][e_db[p]][k], "downstream strobe");
            if (ds_w_strb[p*SB + k]) ck(ds_w_data[p*DW + k*8 +: 8] == e_wd[p][e_db[p]][k*8 +: 8], "downstream data");
          end
          ck(ds_w_last[p] == (e_db[p] == e_len[p]), "downstream wlast");
        end
        e_db[p]++;
      end
      ck(!(ds_w_valid[p] && !(dst[p] == D_W && e_cmdseen[p])), "write beat valid outside the write phase");
      ck(ds_w_valid[p] || (ds_w_data[p*DW +: DW] == 0 && ds_w_strb[p*SB +: SB] == 0), "idle ds_w wires not zero");
      // ---- downstream FSM
      case (dst[p])
        D_W: begin
          if (ds_w_valid[p] && ds_w_ready[p]) begin d_beat[p]++; ds_w_ready[p] <= 0; if (d_beat[p] > d_len[p]) dst[p] = D_B; end
          else ds_w_ready[p] <= ($urandom_range(99, 0) < ds_pct);
        end
        D_B: begin
          if (ds_r_valid[p] && ds_r_ready[p]) begin ds_r_valid[p] <= 0; dst[p] = D_IDLE; end
          else if (!ds_r_valid[p] && $urandom_range(99, 0) < ds_pct) begin ds_r_valid[p] <= 1; ds_r_err[p] <= 0; end
        end
        D_R: begin
          if (ds_r_valid[p] && ds_r_ready[p]) begin d_beat[p]++; ds_r_valid[p] <= 0; if (d_beat[p] > d_len[p]) dst[p] = D_IDLE; end
          else if (!ds_r_valid[p] && $urandom_range(99, 0) < ds_pct) begin
            ds_r_valid[p] <= 1; ds_r_err[p] <= 0; ds_r_data[p*DW +: DW] <= 32'hD0D0_0000 | 32'(d_beat[p]);
          end
        end
        default: ;
      endcase
      // ---- upstream response
      if (us_r_valid[p] && us_r_ready[p]) begin
        ck(e_act[p], "response with no accepted command");
        if (e_act[p]) begin
          int nbeats = e_we[p] ? 1 : e_len[p] + 1;
          ck(int'(us_r_tid[p*TW +: TW]) == e_tid[p], "response tid");
          ck(us_r_we[p] == e_we[p], "response direction");
          ck(us_r_err[p] == !e_grant[p], "response error flag == denial");
          ck(us_r_last[p] == (e_rb[p] == nbeats - 1), "response last");
          if (!e_grant[p]) ck(us_r_data[p*DW +: DW] == 0, "denied response data is zero");
          if (e_grant[p] && !e_we[p]) ck(us_r_data[p*DW +: DW] == (32'hD0D0_0000 | 32'(e_rb[p])), "read data");
          if (e_grant[p]) ck(e_cmdseen[p], "granted response before the downstream command was issued");
          e_rb[p]++;
          if (e_rb[p] == nbeats) begin e_act[p] = 0; n_resp++; end
        end
      end
    end
  end

  // ---------------- run ----------------
  initial begin
    for (int p = 0; p < NP; p++) begin dst[p] = D_IDLE; e_act[p] = 0; end
    void'($urandom(SEED));
    repeat (4) @(posedge clk); #1 rst_n = 1; repeat (3) @(posedge clk);
    // privileged configuration (this runs with the hostile driver idle: the driver only starts after cyc>0 AND `go`)
    p_cmd_pct = 0; p_w_pct = 0; p_r_pct = 0;
    csr_w(8'h04, 32'h1); m_glob = 1;
    dom(1, 1, 1); dom(2, 1, 1); dom(3, 1, 0);
    ctx(0, 0, 1); ctx(0, 1, 2); ctx(1, 0, 2); ctx(2, 0, 3); ctx(1, 2, 3);
    ent(0, 1, 24'h100000 >> 12, 24'h040000 >> 12, 0, 1, 1);
    ent(1, 1, 24'h101000 >> 12, 24'h041000 >> 12, 0, 1, 0);
    ent(2, 1, 24'h200000 >> 12, 24'h080000 >> 12, 2, 1, 1);
    ent(3, 2, 24'h100000 >> 12, 24'h0C0000 >> 12, 0, 1, 1);
    ent(4, 2, 24'h300000 >> 12, 24'h100000 >> 12, 0, 1, 1);
    ent(5, 3, 24'h400000 >> 12, 24'h0F0000 >> 12, 0, 1, 0);
    ent(6, 3, 24'h100000 >> 12, 24'h140000 >> 12, 0, 1, 0);
    ent(7, 2, 24'h400000 >> 12, 24'h0F0000 >> 12, 0, 1, 0);
    for (int i = 0; i < 4; i++) csr_r(8'h08 + 8'(i), cfg_snapshot[i]);
    csr_fuzz_en = 1;
    // phases: moderate, hostile-dense, downstream-starved
    for (int ph = 0; ph < 3; ph++) begin
      case (ph) 0: begin p_cmd_pct = 30; p_w_pct = 60; p_r_pct = 70; ds_pct = 70; end
                1: begin p_cmd_pct = 90; p_w_pct = 90; p_r_pct = 90; ds_pct = 90; end
                2: begin p_cmd_pct = 70; p_w_pct = 30; p_r_pct = 20; ds_pct = 15; end endcase
      repeat (NCYC / 3) @(posedge clk);
    end
    p_cmd_pct = 0; p_w_pct = 0; p_r_pct = 100; ds_pct = 100;
    repeat (400) @(posedge clk);
    csr_fuzz_en = 0; @(posedge clk); #1 csr_valid = 0; csr_we = 0; csr_priv = 1;
    // the hostile CSR traffic must not have changed anything
    for (int i = 0; i < 4; i++) begin logic [31:0] v; csr_r(8'h08 + 8'(i), v); ck(v == cfg_snapshot[i], "unprivileged CSR hammering changed a staging register"); end
    for (int i = 0; i < NE; i++) begin
      logic [31:0] a0; csr_w(8'h1C, 32'(i)); csr_r(8'h1D, a0); ck(a0[0] == m_ent_v[i], "entry valid bit unchanged by hostile CSR traffic");
    end
    begin logic [31:0] c; csr_r(8'h04, c); ck(c[0] == 1, "IOMMU still enabled"); end
    begin logic [31:0] st; csr_r(8'h05, st); ck(st[3] == 1, "unprivileged accesses were recorded as admin violations"); end
    for (int p = 0; p < NP; p++) ck(!ds_w_valid[p] || e_act[p], "no downstream write left over");
    $display("    fuzz: %0d commands accepted (%0d granted, %0d of them writes; %0d denied), %0d responses, %0d downstream write beats checked",
             n_acc, n_grant, n_wgrant, n_deny, n_resp, n_wbeats);
    ck(n_grant > 2000 && n_deny > 2000 && n_wgrant > 500, "fuzzer produced enough granted and denied traffic");
    if (errors == 0) $display("TB_RESULT PASS checks=%0d", checks);
    else             $display("TB_RESULT FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
  initial begin #(10 * (NCYC + 100000) * 4); $display("TB_RESULT FAIL errors=watchdog"); $finish; end
endmodule
