// -----------------------------------------------------------------------------
// Test sequences for tb_dg_unit (included inside the module).
// -----------------------------------------------------------------------------

  // downstream idle-bus hygiene: buffered data must never appear on idle wires
  always @(posedge clk) if (rst_n) begin
    for (int p = 0; p < NP; p++)
      if (!ds_w_valid[p] && (ds_w_data[p*DW +: DW] !== '0 || ds_w_strb[p*SB +: SB] !== '0)) begin
        errors++; $display("[FAIL] p%0d: ds_w_data/strb nonzero while ds_w_valid=0", p);
      end
  end
  // reset must make every output inert immediately (asynchronously)
  task automatic check_outputs_inert(input string tag);
    check_eq(ds_cmd_valid, 0, {tag, ": ds_cmd_valid low"});
    check_eq(ds_w_valid,   0, {tag, ": ds_w_valid low"});
    check_eq(us_r_valid,   0, {tag, ": us_r_valid low"});
    check_eq(us_cmd_ready, 0, {tag, ": us_cmd_ready low in reset"});
    check_eq(us_w_ready,   0, {tag, ": us_w_ready low in reset"});
    check_eq(ds_r_ready,   0, {tag, ": ds_r_ready low in reset"});
  endtask

  task automatic wait_dst(input int p, input dst_t s, input int maxc);
    int n = 0;
    while (dst[p] != s && n < maxc) begin @(posedge clk); n++; end
    check(dst[p] == s, $sformatf("p%0d downstream reached expected state", p));
  endtask
  task automatic wait_ust(input int p, input ust_t s, input int maxc);
    int n = 0;
    while (ust[p] != s && n < maxc) begin @(posedge clk); n++; end
    check(ust[p] == s, $sformatf("p%0d upstream reached expected state", p));
  endtask
  task automatic status_busy(output bit busy);
    logic [31:0] st; csr_r(A_STATUS, st); busy = st[0];
  endtask
  task automatic rd_ent(input int idx, output logic [31:0] a0, output logic [31:0] a1, output logic [31:0] a2);
    csr_w(A_SEL_ENT, 32'(idx)); csr_r(A_ENT_RD0, a0); csr_r(A_ENT_RD1, a1); csr_r(A_ENT_RD2, a2);
  endtask
  task automatic pmem_expect_bytes(input longint pa, input int n, input logic [DW-1:0] d0, input string what);
    // first beat only (4 bytes), little endian
    for (int k = 0; k < SB && k < n; k++) check_eq(pmem[pa + k], d0[k*8 +: 8], {what, " byte"});
  endtask
  task automatic pmem_is_canary(input longint pa, input int n, input string what);
    int bad = 0;
    for (int k = 0; k < n; k++) if (pmem[pa + k] !== canary(int'(pa) + k)) bad++;
    check(bad == 0, {what, ": region untouched (canary intact)"});
  endtask

  // ================================================================== T0 secure reset state
  task automatic t0_reset_defaults();
    logic [31:0] r; bit e; int c;
    $display("--- T0 secure reset state");
    hard_reset(3);
    csr_r(8'h00, r); check_eq(r, 32'h4447_0100, "ID");
    csr_r(8'h01, r); check_eq(r, {8'(NS), 8'(NE), 8'(ND), 8'(NP)}, "CAP0");
    csr_r(8'h02, r); check_eq(r, {8'(MAXO), 8'(DW), 8'(PA_W), 8'(IOVA_W)}, "CAP1");
    csr_r(8'h03, r); check_eq(r, {8'(CW), 8'(TW), 8'(LW), 8'(FQD)}, "CAP2");
    csr_r(A_CTRL, r);   check_eq(r, 0, "CTRL resets to disabled");
    csr_r(A_STATUS, r); check_eq(r, 0, "STATUS resets clean");
    for (int i = 0; i < NE; i++) begin logic [31:0] a0, a1, a2; rd_ent(i, a0, a1, a2); check_eq(a0[0], 0, $sformatf("entry %0d invalid at reset", i)); end
    for (int d = 0; d < ND; d++) begin csr_w(A_SEL_DOM, 32'(d)); csr_r(A_DOM_CFG, r); check_eq(r, 0, $sformatf("domain %0d disabled, no caps at reset", d)); end
    for (int p = 0; p < NP; p++) for (int s = 0; s < NS; s++) begin
      csr_w(A_STG_CTX, 32'(p | (s << 8))); csr_r(A_CTX_RD, r); check_eq(r[0], 0, $sformatf("ctx p%0d s%0d unbound at reset", p, s));
    end
    // every request denied, reads return zero, nothing reaches downstream
    for (int p = 0; p < NP; p++) begin
      burst_expect(p, 0, 1, 24'h100000, 3, `SF_DG_F_DISABLED, $sformatf("T0 p%0d write", p));
      burst_expect(p, 0, 0, 24'h100000, 0, `SF_DG_F_DISABLED, $sformatf("T0 p%0d read", p));
    end
    // privileged CSR access path itself works from reset
    fq_drain_expect_all("T0", 0);
    check_eq(ds_cmds_seen[0] + ds_cmds_seen[1] + ds_cmds_seen[2], 0, "T0 no downstream command since power-on");
    image_check("T0");
    ef_clear();
  endtask

  // ================================================================== T1 translation + bursts
  task automatic t1_basic_translation();
    bit e; int c; logic [DW-1:0] w0;
    $display("--- T1 basic translation, bursts, regions");
    hard_reset(3); configure_tenants(); ef_clear();
    // tenant A single beat: IOVA_RW+0x10 -> PA_A_RW+0x10, tenant B's page must stay canary
    rq_wd[0][0] = 32'hA1B2C3D4; rq_ws[0][0] = 4'hF;
    submit(0, 0, 1, 1, IOVA_RW + 24'h10, 0); wait_done(0, 2000);
    check_eq(rs_err[0], 0, "T1 A write ok");
    pmem_expect_bytes(PA_A_RW + 24'h10, 4, 32'hA1B2C3D4, "T1 A data at PA_A_RW");
    pmem_is_canary(PA_B_RW + 24'h10, 4, "T1 B's page");
    // read back
    burst(0, 0, 2, 0, IOVA_RW + 24'h10, 0, e, c);
    check_eq(e, 0, "T1 A read ok"); check_eq(rs_rd[0][0], 32'hA1B2C3D4, "T1 A read data");
    // bursts of 1, 4, 16 beats with random strobes, then read back (driver checks against golden)
    for (int li = 0; li < 3; li++) begin
      int L = (li == 0) ? 0 : (li == 1) ? 3 : 15;
      burst(0, 0, 3, 1, IOVA_RW + 24'h200, L, e, c); check_eq(e, 0, $sformatf("T1 write burst len=%0d", L));
      burst(0, 0, 4, 0, IOVA_RW + 24'h200, L, e, c); check_eq(e, 0, $sformatf("T1 read burst len=%0d", L));
    end
    // full-page-end burst that fits exactly
    burst(0, 0, 5, 1, IOVA_RW + 24'h1000 - 64, 15, e, c); check_eq(e, 0, "T1 burst ending exactly at page end");
    // region (order 2): 4 pages, offsets carry through to PA
    adm_ctx(1, 1, D_A);          // a second port also serves tenant A (streams are per port)
    for (int k = 0; k < 4; k++) begin
      rq_wd[1][0] = 32'h5500_0000 | k; rq_ws[1][0] = 4'hF;
      submit(1, 1, k, 1, IOVA_REG + k*4096 + 24'h44, 0); wait_done(1, 2000);
      check_eq(rs_err[1], 0, $sformatf("T1 region page %0d write", k));
      pmem_expect_bytes(PA_A_REG + k*4096 + 24'h44, 4, 32'h5500_0000 | k, $sformatf("T1 region page %0d PA", k));
    end
    // shared RO page readable from A and B, never writable
    burst(0, 0, 6, 0, IOVA_SH, 3, e, c);  check_eq(e, 0, "T1 A reads shared page");
    burst(0, 1, 7, 0, IOVA_SH, 3, e, c);  check_eq(e, 0, "T1 B reads shared page");
    image_check("T1");
    fq_drain_expect_all("T1", 0);
    ef_clear();
  endtask

  // ================================================================== T2 tenant A attacks tenant B
  task automatic t2_isolation();
    bit e; int c; logic [DW-1:0] a0;
    $display("--- T2 cross-tenant isolation");
    hard_reset(3); configure_tenants(); ef_clear();
    // Both tenants use the SAME IOVA but land in different physical pages
    rq_wd[2][0] = 32'hC0DEC0DE; rq_ws[2][0] = 4'hF;
    submit(2, 0, 1, 1, IOVA_RW + 24'h80, 0); wait_done(2, 2000);        // tenant C
    rq_wd[1][0] = 32'hB0B0B0B0; rq_ws[1][0] = 4'hF;
    submit(1, 0, 2, 1, IOVA_RW + 24'h80, 0); wait_done(1, 2000);        // tenant B
    rq_wd[0][0] = 32'hAAAA0001; rq_ws[0][0] = 4'hF;
    submit(0, 0, 3, 1, IOVA_RW + 24'h80, 0); wait_done(0, 2000);        // tenant A
    pmem_expect_bytes(PA_A_RW + 24'h80, 4, 32'hAAAA0001, "T2 A lands in A's page");
    pmem_expect_bytes(PA_B_RW + 24'h80, 4, 32'hB0B0B0B0, "T2 B lands in B's page");
    pmem_expect_bytes(PA_C_RW + 24'h80, 4, 32'hC0DEC0DE, "T2 C lands in C's page");
    // A reaches for IOVAs that only B maps
    burst_expect(0, 0, 1, IOVA_B2,         0, `SF_DG_F_UNMAPPED, "T2 A writes B-only IOVA");
    burst_expect(0, 0, 0, IOVA_B2 + 24'h40, 3, `SF_DG_F_UNMAPPED, "T2 A reads B-only IOVA");
    // A passes B's PHYSICAL address as an IOVA (hoping for identity mapping)
    burst_expect(0, 0, 1, PA_B_RW,         0, `SF_DG_F_UNMAPPED, "T2 A uses B's PA as IOVA");
    burst_expect(0, 0, 1, PA_C_RW,         0, `SF_DG_F_UNMAPPED, "T2 A uses C's PA as IOVA");
    // C is bound only on stream 0; trying streams of other tenants on the same port
    burst_expect(2, 1, 1, IOVA_RW, 0, `SF_DG_F_NO_CTX, "T2 C spoofs stream 1");
    burst_expect(2, 2, 1, IOVA_RW, 0, `SF_DG_F_NO_CTX, "T2 C spoofs stream 2");
    burst_expect(2, 3, 1, IOVA_RW, 0, `SF_DG_F_NO_CTX, "T2 C uses out-of-range stream id 3");
    // port 1 stream 1 is unbound although port 0 stream 1 is bound to B
    burst_expect(1, 1, 1, IOVA_RW, 0, `SF_DG_F_NO_CTX, "T2 binding is per port, not global");
    // Tenant C tries IOVA that A/B map but C does not
    burst_expect(2, 0, 1, IOVA_B2, 0, `SF_DG_F_UNMAPPED, "T2 C writes B-only IOVA");
    burst_expect(2, 0, 0, IOVA_REG, 0, `SF_DG_F_UNMAPPED, "T2 C reads A's region IOVA");
    // none of the above may have touched anything except the three legitimate writes
    pmem_is_canary(PA_B_2, 4096, "T2 B2 page");
    image_check("T2");
    // fault log carries domain / port / stream / iova for the first denial
    begin
      bit got; int cs, po, si, dm, ti, le; bit dv, we; longint ia;
      fq_pop_record(got, cs, po, si, dm, dv, we, ia, ti, le);
      check(got, "T2 fault log has records");
      check_eq(cs, `SF_DG_F_UNMAPPED, "T2 first fault cause"); check_eq(po, 0, "T2 first fault port");
      check_eq(dm, D_A, "T2 first fault domain"); check_eq(ia, IOVA_B2, "T2 first fault IOVA"); check_eq(we, 1, "T2 first fault direction");
      check_eq(dv, 1, "T2 first fault domain-valid");
    end
    ef_clear();   // remaining records popped/ignored by the reset in the next test
  endtask

  // ================================================================== T3 permissions
  task automatic t3_permissions();
    bit e; int c;
    $display("--- T3 read-only mappings, domain permission caps");
    hard_reset(3); configure_tenants(); ef_clear();
    // read-only page: write denied, read allowed
    burst_expect(0, 0, 1, IOVA_RO + 24'h10, 0, `SF_DG_F_PERM_W, "T3 write to RO page");
    burst_expect(0, 0, 1, IOVA_RO,          15, `SF_DG_F_PERM_W, "T3 16-beat write to RO page");
    burst_expect(0, 0, 0, IOVA_RO,          3,  `SF_DG_F_NONE,   "T3 read RO page");
    pmem_is_canary(PA_A_RO, 4096, "T3 RO physical page");
    burst_expect(0, 0, 1, IOVA_SH, 0, `SF_DG_F_PERM_W, "T3 write to shared RO page");
    pmem_is_canary(PA_SH, 4096, "T3 shared physical page");
    // domain write cap off: all A's writes denied, reads still fine
    adm_dom(D_A, 1, 1, 0);
    burst_expect(0, 0, 1, IOVA_RW, 0, `SF_DG_F_PERM_W, "T3 domain write-cap off");
    burst_expect(0, 0, 0, IOVA_RW, 0, `SF_DG_F_NONE,   "T3 reads still allowed");
    // read cap off, write cap on
    adm_dom(D_A, 1, 0, 1);
    burst_expect(0, 0, 0, IOVA_RW, 0, `SF_DG_F_PERM_R, "T3 domain read-cap off");
    burst_expect(0, 0, 1, IOVA_RW, 0, `SF_DG_F_NONE,   "T3 writes allowed again");
    // domain disabled: everything denied; other tenants unaffected
    adm_dom(D_A, 0, 1, 1);
    burst_expect(0, 0, 0, IOVA_RW, 0, `SF_DG_F_DISABLED, "T3 domain disabled (read)");
    burst_expect(0, 0, 1, IOVA_RW, 0, `SF_DG_F_DISABLED, "T3 domain disabled (write)");
    burst_expect(1, 0, 1, IOVA_RW, 0, `SF_DG_F_NONE,     "T3 tenant B unaffected");
    adm_dom(D_A, 1, 1, 1);
    burst_expect(0, 0, 1, IOVA_RW, 0, `SF_DG_F_NONE,     "T3 re-enabled");
    // mapping with neither R nor W is a guard page: faults as permission, not as unmapped
    adm_ent_ok(9, D_A, 24'h500000 >> 12, 24'h1A0000 >> 12, 0, 0, 0);
    burst_expect(0, 0, 0, 24'h500000, 0, `SF_DG_F_PERM_R, "T3 guard page read");
    burst_expect(0, 0, 1, 24'h500000, 0, `SF_DG_F_PERM_W, "T3 guard page write");
    pmem_is_canary(24'h1A0000, 4096, "T3 guard physical page");
    image_check("T3");
    fq_drain_expect_all("T3", 0);
    ef_clear();
  endtask

  // ================================================================== T4 unmapped
  task automatic t4_unmapped();
    $display("--- T4 unmapped accesses");
    hard_reset(3); configure_tenants(); ef_clear();
    burst_expect(0, 0, 1, 24'h000000, 0, `SF_DG_F_UNMAPPED, "T4 IOVA 0 write");
    burst_expect(0, 0, 0, 24'h000000, 0, `SF_DG_F_UNMAPPED, "T4 IOVA 0 read");
    burst_expect(0, 0, 1, IOVA_RW - 4, 0, `SF_DG_F_UNMAPPED, "T4 word just below a mapped page");
    burst_expect(0, 0, 0, IOVA_RW - 4, 0, `SF_DG_F_UNMAPPED, "T4 read just below a mapped page");
    burst_expect(0, 0, 1, IOVA_REG + 4*4096, 0, `SF_DG_F_UNMAPPED, "T4 first page after a region");
    burst_expect(0, 0, 0, IOVA_REG - 4096,   0, `SF_DG_F_UNMAPPED, "T4 page before a region");
    burst_expect(0, 0, 1, 24'hFFFFFC, 0, `SF_DG_F_UNMAPPED, "T4 top of IOVA space");
    burst_expect(0, 0, 0, 24'hFFF000, 15, `SF_DG_F_UNMAPPED, "T4 top page, 16-beat read");
    for (int i = 0; i < 40; i++)
      burst_expect(i % NP, 0, i & 1, (24'h600000 + i*4096*3 + 4*i) & 24'hFFFFFC, i % 8, `SF_DG_F_UNMAPPED, $sformatf("T4 sweep %0d", i));
    // invalidated mapping becomes unmapped
    adm_ent_clr(0);
    burst_expect(0, 0, 1, IOVA_RW, 0, `SF_DG_F_UNMAPPED, "T4 write after invalidation");
    burst_expect(0, 0, 0, IOVA_RW, 0, `SF_DG_F_UNMAPPED, "T4 read after invalidation");
    image_check("T4");
    ef_clear();
  endtask

  // ================================================================== T5 page boundaries
  task automatic t5_page_boundaries();
    $display("--- T5 page boundary rules");
    hard_reset(3); configure_tenants(); ef_clear();
    // A's RW page 0x100 is immediately followed by A's RO page 0x101
    burst_expect(0, 0, 1, IOVA_RW + 4096 - 64, 15, `SF_DG_F_NONE,       "T5 exact fit at end of page (write)");
    burst_expect(0, 0, 0, IOVA_RW + 4096 - 64, 15, `SF_DG_F_NONE,       "T5 exact fit at end of page (read)");
    burst_expect(0, 0, 1, IOVA_RW + 4096 - 4,  0,  `SF_DG_F_NONE,       "T5 last word of page");
    burst_expect(0, 0, 1, IOVA_RW + 4096 - 60, 15, `SF_DG_F_PAGE_CROSS, "T5 write crosses by one beat into mapped RO page");
    burst_expect(0, 0, 0, IOVA_RW + 4096 - 60, 15, `SF_DG_F_PAGE_CROSS, "T5 read crosses between two readable pages");
    burst_expect(0, 0, 1, IOVA_RW + 4096 - 8,  3,  `SF_DG_F_PAGE_CROSS, "T5 4-beat write straddles boundary");
    burst_expect(0, 0, 1, IOVA_RW + 4096 - 4,  1,  `SF_DG_F_PAGE_CROSS, "T5 2-beat write starts on last word");
    // crossing from a mapped page into an unmapped one
    burst_expect(0, 0, 1, IOVA_REG + 4*4096 - 8, 3, `SF_DG_F_PAGE_CROSS, "T5 region end into unmapped");
    // inside a region the 4 KiB rule still applies
    burst_expect(0, 0, 1, IOVA_REG + 4096 - 8, 3, `SF_DG_F_PAGE_CROSS, "T5 inside region, cross 4 KiB");
    burst_expect(0, 0, 1, IOVA_REG + 2*4096 + 24'hFC0, 15, `SF_DG_F_NONE, "T5 inside region, exact fit");
    // alignment
    burst_expect(0, 0, 1, IOVA_RW + 1, 0, `SF_DG_F_MISALIGN, "T5 misaligned +1");
    burst_expect(0, 0, 0, IOVA_RW + 2, 0, `SF_DG_F_MISALIGN, "T5 misaligned +2");
    burst_expect(0, 0, 1, IOVA_RW + 3, 3, `SF_DG_F_MISALIGN, "T5 misaligned +3, burst");
    // neither neighbouring physical page nor the pages around them may have changed
    pmem_is_canary(PA_A_RO, 4096, "T5 RO page behind the boundary");
    image_check("T5");
    // fault log: cause distinguishes crossing from misalignment
    fq_drain_expect_all("T5", 0);
    ef_clear();
  endtask

  // ================================================================== T6 mappings change during operation
  task automatic t6_dynamic_mappings();
    bit e; int c, er; logic [31:0] st; bit busy; int base_c0;
    $display("--- T6 mappings change during operation");
    hard_reset(3); configure_tenants(); ef_clear();

    // ---- (a) invalidate a mapping while a burst authorised under it is in flight
    hold_w[1] = 1; base_c0 = ds_cmds_seen[0];
    fill_data(1, 0);
    submit(1, 0, 5, 1, IOVA_RW + 24'h100, 3);               // tenant B, 4 beats
    wait_dst(1, DS_W, 2000);                                // granted, command accepted downstream
    csr_w(A_CMD, 32'((4 << 8) | `SF_DG_OP_ENT_CLR));        // revoke B's page while its burst is mid-flight
    status_busy(busy); check_eq(busy, 1, "T6a drain in progress after invalidation");
    m_ent_v[4] = 0;                                         // oracle: later requests see the new table
    submit(0, 1, 7, 0, IOVA_RW + 24'h100, 0);                // port0/stream1 -> B, issued during the drain
    repeat (40) @(posedge clk);
    check_eq(rq_pending[0], 1, "T6a new check is held off while draining (not granted)");
    status_busy(busy); check_eq(busy, 1, "T6a busy stays high while a granted burst is in flight");
    check_eq(ds_cmds_seen[0] - base_c0, 0, "T6a held request produced no downstream command");
    hold_w[1] = 0;                                          // downstream resumes
    wait_done(1, 4000); check_eq(rs_err[1], 0, "T6a in-flight burst completes normally (authorised before revoke)");
    wait_done(0, 4000); check_eq(rs_err[0], 1, "T6a request issued during drain is denied afterwards");
    check_eq(rs_cause[0], `SF_DG_F_UNMAPPED, "T6a oracle cause");
    wait_not_busy(200);
    burst_expect(1, 0, 1, IOVA_RW + 24'h100, 0, `SF_DG_F_UNMAPPED, "T6a after completion: stale mapping unusable");
    image_check("T6a");

    // ---- (b) remap the same IOVA to a new physical page
    begin
      longint new_pa = 24'h180000;
      logic [7:0] snap [16];
      for (int k = 0; k < 16; k++) snap[k] = pmem[PA_B_RW + 24'h200 + k];
      adm_ent_ok(4, D_B, IOVA_RW >> 12, new_pa >> 12, 0, 1, 1);
      rq_wd[1][0] = 32'h0BADF00D; rq_ws[1][0] = 4'hF;
      submit(1, 0, 6, 1, IOVA_RW + 24'h200, 0); wait_done(1, 2000);
      pmem_expect_bytes(new_pa + 24'h200, 4, 32'h0BADF00D, "T6b new mapping used");
      for (int k = 0; k < 16; k++) check_eq(pmem[PA_B_RW + 24'h200 + k], snap[k], "T6b old physical page no longer written");
    end

    // ---- (c) rebind a stream to another domain (A -> C) at run time
    adm_ctx_clr(0, 0);
    burst_expect(0, 0, 1, IOVA_RW, 0, `SF_DG_F_NO_CTX, "T6c unbound stream denied");
    adm_ctx(0, 0, D_C);
    rq_wd[0][0] = 32'hC1C1C1C1; rq_ws[0][0] = 4'hF;
    submit(0, 0, 8, 1, IOVA_RW + 24'h300, 0); wait_done(0, 2000);
    pmem_expect_bytes(PA_C_RW + 24'h300, 4, 32'hC1C1C1C1, "T6c rebound stream lands in new domain's page");
    pmem_is_canary(PA_A_RW + 24'h300, 4, "T6c old domain's page untouched");

    // ---- (d) disable a domain while its burst is in flight
    hold_w[0] = 1; fill_data(0, 0);
    submit(0, 0, 9, 1, IOVA_RW + 24'h400, 3); wait_dst(0, DS_W, 2000);
    csr_w(A_STG_DOM, 32'(D_C | (0 << 8) | (1 << 9) | (1 << 10)));
    csr_w(A_CMD, 32'(`SF_DG_OP_DOM_SET));
    status_busy(busy); check_eq(busy, 1, "T6d drain after domain disable");
    m_dom_en[D_C] = 0;
    hold_w[0] = 0; wait_done(0, 4000); check_eq(rs_err[0], 0, "T6d in-flight burst completes");
    wait_not_busy(200);
    burst_expect(0, 0, 1, IOVA_RW, 0, `SF_DG_F_DISABLED, "T6d next request denied");
    adm_dom(D_C, 1, 1, 1);

    // ---- (e) global disable while a burst is in flight
    hold_w[2] = 1; fill_data(2, 0);
    submit(2, 0, 3, 1, IOVA_RW + 24'h500, 1); wait_dst(2, DS_W, 2000);
    csr_w(A_CTRL, 32'h0);                                     // disable is accepted even mid-drain
    m_glob_en = 0;
    status_busy(busy); check_eq(busy, 1, "T6e drain after global disable");
    csr_w(A_CTRL, 32'h1);                                     // re-enable while draining must be refused
    csr_r(A_CTRL, st); check_eq(st[0], 0, "T6e enable refused while draining");
    csr_r(A_STATUS, st); check_eq(st[11:8], `SF_DG_E_PENDING, "T6e refusal reported");
    hold_w[2] = 0; wait_done(2, 4000); check_eq(rs_err[2], 0, "T6e in-flight burst completes");
    wait_not_busy(200);
    burst_expect(0, 0, 0, IOVA_RW, 0, `SF_DG_F_DISABLED, "T6e globally disabled");
    adm_glob(1);
    burst_expect(0, 0, 0, IOVA_RW, 0, `SF_DG_F_NONE, "T6e re-enabled");

    // ---- (f) admin command while draining is refused and changes nothing
    hold_w[1] = 1; fill_data(1, 0);
    submit(1, 0, 4, 1, IOVA_RW + 24'h600, 0); wait_dst(1, DS_W, 2000);
    csr_w(A_STG_IPN, 32'h600); csr_w(A_STG_PPN, 32'h1B0); csr_w(A_STG_ATTR, 32'((D_B << 16) | 3));
    csr_w(A_CMD, 32'((10 << 8) | `SF_DG_OP_FENCE));            // starts a drain
    csr_w(A_CMD, 32'((10 << 8) | `SF_DG_OP_ENT_SET));          // refused: drain pending
    csr_r(A_STATUS, st); check_eq(st[11:8], `SF_DG_E_PENDING, "T6f command during drain -> E_PENDING");
    hold_w[1] = 0; wait_done(1, 4000); wait_not_busy(200);
    begin logic [31:0] a0, a1, a2; rd_ent(10, a0, a1, a2); check_eq(a0[0], 0, "T6f refused ENT_SET left slot invalid"); end

    // ---- (g) unrelated ports keep working after an admin operation completes
    adm_ent_clr(7);
    burst_expect(1, 0, 0, IOVA_RW, 0, `SF_DG_F_NONE,     "T6g unaffected tenant still served");
    burst_expect(2, 0, 0, IOVA_RW, 0, `SF_DG_F_UNMAPPED, "T6g cleared tenant denied");
    image_check("T6");
    fq_drain_expect_all("T6", 0);
    ef_clear();
  endtask

  // ================================================================== T7 reset with pending requests
  task automatic t7_reset_pending();
    bit e; int c; logic [31:0] r; bit busy;
    logic [7:0] gsave [16]; int base_w1;
    $display("--- T7 reset with pending requests");
    // ---- (a) reset while granted write burst waits for downstream data acceptance (SEND)
    hard_reset(3); configure_tenants(); ef_clear();
    for (int k = 0; k < 16; k++) gsave[k] = gold[PA_B_RW + 24'h20 + k];
    hold_w[1] = 1; fill_data(1, 0); base_w1 = ds_writes_seen[1];
    submit(1, 0, 3, 1, IOVA_RW + 24'h20, 3); wait_dst(1, DS_W, 2000);
    repeat (3) @(posedge clk);
    #2 rst_n = 0; #1;                                          // asynchronous reset, mid-clock
    check_outputs_inert("T7a immediately after reset assert");
    repeat (3) @(posedge clk);
    check_eq(ds_writes_seen[1] - base_w1, 0, "T7a no write beat was ever accepted downstream");
    #1 fsm_reset(); model_reset();
    for (int k = 0; k < 16; k++) gold[PA_B_RW + 24'h20 + k] = gsave[k];   // the killed burst never happened
    hold_w[1] = 0;
    #1 rst_n = 1; repeat (3) @(posedge clk);
    // zombie must not resume: no downstream activity at all, defaults restored
    repeat (30) @(posedge clk);
    check_eq(ds_w_valid, 0, "T7a no zombie write after reset"); check_eq(ds_cmd_valid, 0, "T7a no zombie command after reset");
    csr_r(A_CTRL, r); check_eq(r, 0, "T7a CTRL default after reset");
    begin logic [31:0] a0, a1, a2; rd_ent(4, a0, a1, a2); check_eq(a0[0], 0, "T7a entry invalidated by reset"); end
    burst_expect(1, 0, 1, IOVA_RW + 24'h20, 3, `SF_DG_F_DISABLED, "T7a request after reset denied (secure default)");
    image_check("T7a");

    // ---- (b) reset while a write is half-collected from the initiator
    configure_tenants(); ef_clear();
    for (int k = 0; k < 16; k++) gsave[k] = gold[PA_A_RW + 24'h40 + k];
    no_w_data[0] = 1; fill_data(0, 0);
    submit(0, 0, 2, 1, IOVA_RW + 24'h40, 3);
    repeat (20) @(posedge clk);
    rst_n = 0; #1; check_outputs_inert("T7b");
    repeat (2) @(posedge clk); #1 fsm_reset(); model_reset();
    for (int k = 0; k < 16; k++) gold[PA_A_RW + 24'h40 + k] = gsave[k];
    no_w_data[0] = 0; #1 rst_n = 1; repeat (30) @(posedge clk);
    check_eq(ds_cmd_valid, 0, "T7b no command after reset");
    burst_expect(0, 0, 1, IOVA_RW + 24'h40, 3, `SF_DG_F_DISABLED, "T7b denied after reset");
    image_check("T7b");

    // ---- (c) reset with a response pending (initiator not accepting)
    configure_tenants(); ef_clear();
    up_r_stall_pct = 100;
    submit(0, 0, 4, 0, IOVA_RW + 24'h80, 3);
    repeat (60) @(posedge clk);
    check_eq(us_r_valid[0], 1, "T7c response pending");
    rst_n = 0; #1; check_outputs_inert("T7c");
    repeat (2) @(posedge clk); #1 fsm_reset(); model_reset();
    up_r_stall_pct = 0; #1 rst_n = 1; repeat (5) @(posedge clk);
    check_eq(us_r_valid, 0, "T7c stale response gone");
    burst_expect(0, 0, 0, IOVA_RW, 0, `SF_DG_F_DISABLED, "T7c denied after reset");

    // ---- (d) reset in the middle of a drain
    configure_tenants(); ef_clear();
    for (int k = 0; k < 16; k++) gsave[k] = gold[PA_B_RW + 24'h90 + k];
    hold_w[1] = 1; fill_data(1, 0);
    submit(1, 0, 4, 1, IOVA_RW + 24'h90, 0); wait_dst(1, DS_W, 2000);
    csr_w(A_CMD, 32'((5 << 8) | `SF_DG_OP_ENT_CLR));
    status_busy(busy); check_eq(busy, 1, "T7d drain in progress");
    rst_n = 0; #1; repeat (2) @(posedge clk); #1 fsm_reset(); model_reset();
    for (int k = 0; k < 16; k++) gold[PA_B_RW + 24'h90 + k] = gsave[k];
    hold_w[1] = 0; #1 rst_n = 1; repeat (3) @(posedge clk);
    status_busy(busy); check_eq(busy, 0, "T7d drain state cleared by reset");
    csr_r(A_STATUS, r); check_eq(r, 0, "T7d STATUS clean after reset");

    // ---- (e) full recovery: reconfigure and operate normally
    configure_tenants(); ef_clear();
    burst_expect(0, 0, 1, IOVA_RW, 3, `SF_DG_F_NONE, "T7e normal operation after reconfiguration");
    burst_expect(0, 0, 1, IOVA_B2, 3, `SF_DG_F_UNMAPPED, "T7e isolation after reconfiguration");
    image_check("T7");
    fq_drain_expect_all("T7", 0);
    ef_clear();
  endtask

  // ================================================================== T8 concurrent multi-domain random traffic
  task automatic gen_one(input int p);
    int sid, cls, tid, len, off, d; bit we, g; int c, dm, he; bit dv; longint iova, pa, base;
    sid = $urandom_range(3, 0);                       // 3 is out of range; some streams are unbound
    if ($urandom_range(3, 0) != 0) begin               // 75%: pick one of this port's bound streams
      int nb = 0; int pick[NS];
      for (int s2 = 0; s2 < NS; s2++) if (m_ctx_v[p][s2]) begin pick[nb] = s2; nb++; end
      if (nb > 0) sid = pick[$urandom_range(nb - 1, 0)];
    end
    cls = $urandom_range(9, 0);
    we  = $urandom_range(1, 0);
    tid = $urandom_range(15, 0);
    off = 4 * $urandom_range(1023, 0);
    len = $urandom_range(15, 0);
    if (off + (len + 1) * 4 > 4096) len = (4096 - off) / 4 - 1;
    case (cls)
      0, 1, 2, 3: iova = IOVA_RW + off;
      4:          iova = ($urandom_range(1, 0) ? IOVA_RO : IOVA_SH) + off;
      5:          iova = IOVA_REG + 4096 * $urandom_range(3, 0) + off;
      6:          iova = (longint'($urandom_range(255, 0)) << 12) * 16 + off;   // anywhere, oracle decides
      7:          iova = IOVA_B2 + off;
      8: begin
        off = 4096 - 4 * $urandom_range(8, 1); len = $urandom_range(15, 8);
        iova = IOVA_RW + off;
      end
      default:    iova = IOVA_RW + off + $urandom_range(3, 1);
    endcase
    iova = iova & 24'hFFFFFF;
    // keep every physical write single-writer so the golden image stays exact
    model_decide(p, sid, we, iova, len, g, c, pa, dm, dv, he);
    if (g && he >= 0 && m_ent_w[he] && m_dom_wr[dm] && p != wr_port[dm]) iova = 24'hE00000 + off;
    fill_data(p, 1);
    submit(p, sid, tid, we, iova, len);
    rq_gap[p]   = $urandom_range(3, 0);
    rq_early[p] = ($urandom_range(3, 0) == 0);
    wait_done(p, 40000);
  endtask
  // per-port generator threads live at module level (Verilator 5.020 cannot run fork/join of task calls reliably)
  bit gen_go [NP];
  bit gen_fin [NP];
  int gen_n;
  generate for (gi = 0; gi < NP; gi++) begin : g_gen
    initial begin
      gen_go[gi] = 0; gen_fin[gi] = 0;
      forever begin
        while (!gen_go[gi]) @(posedge clk);
        for (int i = 0; i < gen_n; i++) gen_one(gi);
        gen_go[gi] = 0; gen_fin[gi] = 1;
      end
    end
  end endgenerate

  task automatic t8_concurrent_random(input int nbursts);
    logic [31:0] r; int drops; int unmatched;
    $display("--- T8 concurrent multi-domain random traffic (%0d bursts/port)", nbursts);
    hard_reset(3); configure_tenants(); ef_clear();
    adm_ent_ok(8, D_S, IOVA_SH >> 12, PA_SH >> 12, 0, 1, 0);
    wr_port[D_A] = 0; wr_port[D_B] = 1; wr_port[D_C] = 2; wr_port[D_S] = -2;
    for (int ph = 0; ph < 4; ph++) begin
      case (ph)
        0: begin up_w_gap_pct = 0;  up_r_stall_pct = 0;  ds_stall_pct = 0;  ds_lat_max = 0; end
        1: begin up_w_gap_pct = 30; up_r_stall_pct = 30; ds_stall_pct = 30; ds_lat_max = 3; end
        2: begin up_w_gap_pct = 70; up_r_stall_pct = 70; ds_stall_pct = 70; ds_lat_max = 6; end
        3: begin up_w_gap_pct = 0;  up_r_stall_pct = 85; ds_stall_pct = 10; ds_lat_max = 0; end
      endcase
      gen_n = nbursts;
      for (int p = 0; p < NP; p++) begin gen_fin[p] = 0; gen_go[p] = 1; end
      while (!(gen_fin[0] && gen_fin[1] && gen_fin[2])) begin
        bit got;
        fq_match_one(got);                       // concurrent fault-log reader
        repeat ($urandom_range(40, 3)) @(posedge clk);
      end
    end
    clear_knobs();
    repeat (10) @(posedge clk);
    image_check("T8 final physical image");
    check_eq(exp_leaks, 0, "T8 no unauthorised downstream activity");
    // statistics vs oracle
    for (int p = 0; p < NP; p++) begin
      csr_w(A_SEL_PORT, 32'(p));
      csr_r(A_PORT_OK, r);   check_eq(r, m_pok[p],   $sformatf("T8 port %0d granted count", p));
      csr_r(A_PORT_DENY, r); check_eq(r, m_pdeny[p], $sformatf("T8 port %0d denied count", p));
    end
    for (int d = 0; d < ND; d++) begin
      csr_w(A_SEL_DOM, 32'(d));
      csr_r(A_DOM_FCNT, r);  check_eq(r, m_dfcnt[d],  $sformatf("T8 domain %0d fault count", d));
      csr_r(A_DOM_FMASK, r); check_eq(r, m_dfmask[d], $sformatf("T8 domain %0d fault-cause mask", d));
    end
    // fault log: every record matches an expected denial; everything else must be an accounted drop
    csr_r(A_FQ_STATUS, r); drops = int'(r[31:16]);
    fq_drain_expect_all("T8", 100000);
    unmatched = 0; for (int i = 0; i < ef_n; i++) if (!ef_used[i]) unmatched++;
    check_eq(unmatched, drops, "T8 unlogged denials == counted overflow drops");
    $display("    T8: %0d denials expected, %0d logged, %0d dropped on overflow; granted/denied per port: %0d/%0d %0d/%0d %0d/%0d",
             ef_n, ef_n - unmatched, drops, m_pok[0], m_pdeny[0], m_pok[1], m_pdeny[1], m_pok[2], m_pdeny[2]);
    ef_clear();
  endtask

  // ================================================================== T9 admin interface
  task automatic t9_admin();
    logic [31:0] r; bit h; int e; logic [31:0] a0, a1, a2; bit busy;
    $display("--- T9 admin interface, error codes, fault log");
    hard_reset(3); ef_clear();
    adm_glob(1); adm_dom(D_A, 1, 1, 1); adm_dom(D_B, 1, 1, 1);
    adm_ctx(0, 0, D_A); adm_ctx(0, 1, D_B);

    // ---- privilege gating
    csr_xfer(1, 0, A_STG_IPN, 32'hDEAD, h, r);           check_eq(h, 0, "T9 non-priv write -> bus error");
    csr_r(A_STG_IPN, r);                                  check_eq(r, 0, "T9 non-priv write had no effect");
    csr_xfer(0, 0, 8'h00, 0, h, r);                       check_eq(h, 1, "T9 non-priv ID read allowed"); check_eq(r, 32'h4447_0100, "T9 ID via non-priv");
    csr_xfer(0, 0, 8'h02, 0, h, r);                       check_eq(h, 1, "T9 non-priv CAP read allowed");
    csr_xfer(0, 0, A_STATUS, 0, h, r);                    check_eq(h, 0, "T9 non-priv STATUS read -> bus error"); check_eq(r, 0, "T9 non-priv read returns zero");
    csr_xfer(0, 0, A_FQ_META, 0, h, r);                   check_eq(h, 0, "T9 non-priv fault-log read blocked");
    csr_w(A_STG_IPN, 32'h777); csr_w(A_STG_PPN, 32'h111); csr_w(A_STG_ATTR, 32'((D_A << 16) | 3));
    csr_xfer(1, 0, A_CMD, 32'((9 << 8) | `SF_DG_OP_ENT_SET), h, r); check_eq(h, 0, "T9 non-priv CMD refused");
    rd_ent(9, a0, a1, a2); check_eq(a0[0], 0, "T9 non-priv ENT_SET created nothing");
    csr_xfer(1, 0, A_CTRL, 32'h0, h, r);                  // non-priv attempt to disable
    csr_r(A_CTRL, r);                                     check_eq(r[0], 1, "T9 non-priv CTRL write ignored");
    csr_r(A_STATUS, r);                                   check_eq(r[3], 1, "T9 admin violation recorded (sticky)");
    csr_w(A_STATUS, 32'h8);                               csr_r(A_STATUS, r); check_eq(r[3], 0, "T9 W1C clears admin_viol");
    csr_xfer(1, 1, 8'h40, 0, h, r);                       check_eq(h, 0, "T9 unmapped CSR address -> bus error");
    csr_xfer(1, 1, 8'h00, 0, h, r);                       check_eq(h, 0, "T9 write to RO register -> bus error");

    // ---- commit error codes (each must leave state untouched and not start a drain)
    adm_ent_ok(0, D_A, 24'h200000 >> 12, 24'h080000 >> 12, 2, 1, 1);   // region 0x200..0x203
    adm_ent_ok(1, D_A, 24'h100000 >> 12, 24'h040000 >> 12, 0, 1, 1);
    csr_w(A_STG_IPN, 32'h300); csr_w(A_STG_PPN, 32'h0C0); csr_w(A_STG_ATTR, 32'((D_A << 16) | 3));
    csr_w(A_CMD, 32'((NE << 8) | `SF_DG_OP_ENT_SET));      csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_IDX, "T9 slot out of range"); check_eq(r[0], 0, "T9 failed op starts no drain");
    csr_w(A_STG_ATTR, 32'((ND << 16) | 3));
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_DOM, "T9 domain out of range");
    csr_w(A_STG_ATTR, 32'((D_A << 16) | 3));
    csr_w(A_STG_PPN, 32'h400);
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_RANGE, "T9 PA page beyond PA width");
    csr_w(A_STG_PPN, 32'h0C0); csr_w(A_STG_IPN, 32'h1000);
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_RANGE, "T9 IOVA page beyond IOVA width");
    csr_w(A_STG_IPN, 32'h300); csr_w(A_STG_ATTR, 32'((D_A << 16) | (7 << 8) | 3));
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_RANGE, "T9 order above MAX_ORDER");
    csr_w(A_STG_ATTR, 32'((D_A << 16) | (2 << 8) | 3)); csr_w(A_STG_IPN, 32'h301);
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_RANGE, "T9 IOVA region not naturally aligned");
    csr_w(A_STG_IPN, 32'h300); csr_w(A_STG_PPN, 32'h0C1);
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_RANGE, "T9 PA region not naturally aligned");
    csr_w(A_STG_PPN, 32'h0C0); csr_w(A_STG_ATTR, 32'((D_A << 16) | 3)); csr_w(A_STG_IPN, 32'h300);
    csr_w(A_CMD, 32'((0 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_BUSY, "T9 slot already valid");
    csr_w(A_STG_IPN, 32'h201);   // inside A's region
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_OVERLAP, "T9 overlap: new page inside existing region");
    csr_w(A_STG_IPN, 32'h200); csr_w(A_STG_PPN, 32'h0C0); csr_w(A_STG_ATTR, 32'((D_A << 16) | (3 << 8) | 3));
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_OVERLAP, "T9 overlap: new region contains existing region");
    csr_w(A_STG_IPN, 32'h100); csr_w(A_STG_PPN, 32'h0C0); csr_w(A_STG_ATTR, 32'((D_A << 16) | 3));
    csr_w(A_CMD, 32'((2 << 8) | `SF_DG_OP_ENT_SET));       csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_OVERLAP, "T9 overlap: duplicate IOVA page");
    // same IOVA in a DIFFERENT domain is legal (tenants overlap in IOVA space by design)
    adm_ent_ok(2, D_B, 24'h100000 >> 12, 24'h0C0000 >> 12, 0, 1, 1);
    csr_w(A_CMD, 32'((3 << 8) | 4'd9));                    csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_OP, "T9 illegal opcode");
    csr_w(A_CMD, 32'(`SF_DG_OP_NOP));                      csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_OK, "T9 NOP ok"); check_eq(r[0], 0, "T9 NOP starts no drain");
    csr_w(A_CMD, 32'((NE << 8) | `SF_DG_OP_ENT_CLR));      csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_IDX, "T9 ENT_CLR slot out of range");
    csr_w(A_CMD, 32'((ND << 8) | `SF_DG_OP_DOM_FLUSH));    csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_DOM, "T9 DOM_FLUSH domain out of range");
    csr_w(A_STG_DOM, 32'(ND | 32'h700));
    csr_w(A_CMD, 32'(`SF_DG_OP_DOM_SET));                  csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_DOM, "T9 DOM_SET domain out of range");
    csr_w(A_STG_CTX, 32'(NP | (0 << 8) | (1 << 16)));
    csr_w(A_CMD, 32'(`SF_DG_OP_CTX_SET));                  csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_IDX, "T9 CTX_SET port out of range");
    csr_w(A_STG_CTX, 32'(0 | (NS << 8) | (1 << 16)));
    csr_w(A_CMD, 32'(`SF_DG_OP_CTX_SET));                  csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_IDX, "T9 CTX_SET stream out of range");
    csr_w(A_STG_CTX, 32'(0 | (2 << 8) | (ND << 16)));
    csr_w(A_CMD, 32'(`SF_DG_OP_CTX_SET));                  csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_DOM, "T9 CTX_SET domain out of range");
    csr_w(A_STG_CTX, 32'(0 | (0 << 8) | (D_B << 16)));
    csr_w(A_CMD, 32'(`SF_DG_OP_CTX_SET));                  csr_r(A_STATUS, r); check_eq(r[11:8], `SF_DG_E_BUSY, "T9 CTX_SET on a bound stream");
    csr_w(A_STG_CTX, 32'(0 | (0 << 8)));  csr_r(A_CTX_RD, r); check_eq(r[0], 1, "T9 binding unchanged"); check_eq(r[23:16], D_A, "T9 binding still tenant A");
    // read back committed entries
    rd_ent(0, a0, a1, a2); check_eq(a0, {8'd0, 8'(D_A), 4'd0, 4'd2, 5'd0, 1'b1, 1'b1, 1'b1}, "T9 ENT_RD0 slot0"); check_eq(a1, 32'h200, "T9 ENT_RD1"); check_eq(a2, 32'h080, "T9 ENT_RD2");
    // DOM_FLUSH removes exactly that domain's entries
    csr_w(A_CMD, 32'((D_A << 8) | `SF_DG_OP_DOM_FLUSH)); wait_not_busy(200);
    m_ent_v[0] = 0; m_ent_v[1] = 0;
    rd_ent(0, a0, a1, a2); check_eq(a0[0], 0, "T9 flush cleared A slot0");
    rd_ent(1, a0, a1, a2); check_eq(a0[0], 0, "T9 flush cleared A slot1");
    rd_ent(2, a0, a1, a2); check_eq(a0[0], 1, "T9 flush left B's entry");

    // ---- fault log: ordering, overflow, IRQ, counters
    begin
      bit got; int cs, po, si, dm, ti, le; bit dv, we; longint ia;
      ef_clear(); csr_w(A_CTRL, 32'h1);                    // irq disabled
      for (int i = 0; i < FQD + 3; i++) burst_expect(0, 0, i & 1, 24'h700000 + 4*i, i % 4, `SF_DG_F_UNMAPPED, $sformatf("T9 denial %0d", i));
      check_eq(irq, 0, "T9 irq low while disabled");
      csr_r(A_FQ_STATUS, r); check_eq(r[7:0], FQD, "T9 log full"); check_eq(r[31:16], 3, "T9 3 records dropped on overflow");
      csr_r(A_STATUS, r);    check_eq(r[2], 1, "T9 overflow flag set");
      csr_w(A_CTRL, 32'h3); #1; check_eq(irq, 1, "T9 irq asserted when enabled and log non-empty");
      for (int i = 0; i < FQD; i++) begin
        fq_pop_record(got, cs, po, si, dm, dv, we, ia, ti, le);
        check(got, "T9 record present");
        check_eq(ia, 24'h700000 + 4*i, $sformatf("T9 oldest-first order, record %0d", i));
      end
      fq_pop_record(got, cs, po, si, dm, dv, we, ia, ti, le); check_eq(got, 0, "T9 log empty after pops (dropped ones are gone)");
      check_eq(irq, 0, "T9 irq low when log empty");
      csr_w(A_STATUS, 32'h4); csr_r(A_STATUS, r); check_eq(r[2], 0, "T9 W1C clears overflow flag");
      csr_w(A_SEL_DOM, 32'(D_A)); csr_r(A_DOM_FCNT, r); check_eq(r, FQD + 3, "T9 per-domain fault counter counts dropped records too");
      csr_r(A_DOM_FMASK, r); check_eq(r, (1 << `SF_DG_F_UNMAPPED), "T9 fault-cause mask");
      csr_w(A_DOM_FMASK, 32'hFFFF); csr_r(A_DOM_FMASK, r); check_eq(r, 0, "T9 mask W1C");
      ef_clear();
    end
    image_check("T9");
  endtask

  // ================================================================== T10 hostile initiator, backpressure, error propagation
  task automatic t10_robustness();
    bit e; int c; bit busy; int er; int base_cmds; logic [31:0] st10;
    $display("--- T10 stalled initiator, backpressure, downstream errors");
    hard_reset(3); configure_tenants(); ef_clear();
    // ---- a write burst whose data never arrives holds NO authority and blocks nobody
    base_cmds = ds_cmds_seen[0];
    no_w_data[0] = 1; fill_data(0, 0);
    submit(0, 0, 1, 1, IOVA_RW + 24'h700, 3);
    repeat (50) @(posedge clk);
    check_eq(ds_cmds_seen[0] - base_cmds, 0, "T10a stalled initiator: nothing issued downstream");
    burst_expect(1, 0, 1, IOVA_RW + 24'h10, 3, `SF_DG_F_NONE, "T10a other port progresses");
    burst_expect(2, 0, 0, IOVA_RW + 24'h10, 3, `SF_DG_F_NONE, "T10a other port progresses (read)");
    adm_ent_clr(5);                                              // admin operation completes despite the stalled port
    csr_r(A_STATUS, st10); busy = st10[0]; check_eq(busy, 0, "T10a drain is not held hostage by a stalled initiator");
    no_w_data[0] = 0;
    wait_done(0, 4000); check_eq(rs_err[0], 0, "T10a stalled burst completes once data arrives");
    // ---- data presented together with / before the command
    for (int i = 0; i < 6; i++) begin
      fill_data(2, 1); submit(2, 0, i, 1, IOVA_RW + 24'h800 + 64*i, 3); rq_early[2] = 1; wait_done(2, 4000);
      check_eq(rs_err[2], 0, "T10b early write data accepted");
    end
    // ---- heavy backpressure on every channel, all ports, mixed grants/denials
    up_w_gap_pct = 80; up_r_stall_pct = 80; ds_stall_pct = 80; ds_lat_max = 8;
    for (int i = 0; i < 30; i++) begin
      fill_data(0, 1); fill_data(1, 1); fill_data(2, 1);
      submit(0, 0,     i & 15, i & 1,  IOVA_RW + 24'h900 + 4*i, i % 8);
      submit(1, i % 3, i & 15, i & 1,  (i % 5 == 0) ? 24'h610000 : IOVA_RW + 24'hA00 + 4*i, i % 6);
      submit(2, 0,     i & 15, ~i & 1, IOVA_RW + 24'hB00 + 4*i, i % 4);
      wait_done(0, 40000); wait_done(1, 40000); wait_done(2, 40000);
    end
    clear_knobs();
    // ---- downstream error is propagated, never hidden
    ds_inject_next[1] = 1; fill_data(1, 0);
    submit(1, 0, 9, 1, IOVA_RW + 24'h20, 0); wait_done(1, 2000);
    check_eq(rs_err[1], 1, "T10d downstream write error propagated to initiator");
    ds_inject_next[2] = 1;
    submit(2, 0, 10, 0, IOVA_RW + 24'h20, 3); wait_done(2, 2000);
    check_eq(rs_err[2], 1, "T10d downstream read error propagated to initiator");
    burst_expect(1, 0, 1, IOVA_RW + 24'h20, 0, `SF_DG_F_NONE, "T10d port recovers after downstream error");
    image_check("T10");
    check_eq(exp_leaks, 0, "T10 no unauthorised downstream activity");
    fq_drain_expect_all("T10", 0);
    ef_clear();
  endtask

  // ================================================================== driver
  task automatic run_all_tests();
    t0_reset_defaults();
    t1_basic_translation();
    t2_isolation();
    t3_permissions();
    t4_unmapped();
    t5_page_boundaries();
    t6_dynamic_mappings();
    t7_reset_pending();
    t8_concurrent_random(400);
    t9_admin();
    t10_robustness();
  endtask
