// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | tb_dg_unit
//
// Self-checking adversarial testbench for sf_albion_iommu (3 ports).
//
// Independent checking layers (a bug has to fool all of them):
//   1. ORACLE      A behavioural model (integer arithmetic, written separately
//                  from the RTL) mirrors the admin configuration and predicts,
//                  per burst: grant/deny, fault cause, physical address.
//   2. DOWNSTREAM  The memory agent accepts a downstream command ONLY if the
//                  oracle authorised it (right PA / direction / length / tid),
//                  and checks every write beat's data+strobe. A leak from a
//                  denied burst is flagged at the interface.
//   3. IMAGE       The physical memory is canary-filled. After every test the
//                  whole image is compared with a golden image that only
//                  authorised writes have touched.
//   4. RESPONSES   Every response beat is checked: tid, direction, error flag,
//                  last, beat count, read data (zero on denial).
// Prints "TB_RESULT PASS checks=<n>" or "TB_RESULT FAIL errors=<n>".
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
`include "sf_albion_defs.svh"

module tb_dg_unit;
  // ------------------------------------------------------------------ parameters
  localparam int NP   = 3;
  localparam int ND   = 8;
  localparam int NS   = 3;            // 3 (not 4) so that sid=3 is out of range
  localparam int NE   = 16;
  localparam int IOVA_W = 24;
  localparam int PA_W   = 22;
  localparam int DW   = 32;
  localparam int LW   = 4;
  localparam int TW   = 4;
  localparam int MAXO = 6;
  localparam int FQD  = 8;
  localparam int CW   = 16;
  localparam int SW   = 2;            // $clog2(NS)
  localparam int SB   = DW/8;
  localparam int MAXB = 1 << LW;      // beats per burst
  localparam int PMEM_SZ = 1 << PA_W;
  parameter  int SEED = 97;

  // ------------------------------------------------------------------ clock / reset / DUT
  logic clk = 0, rst_n = 0;
  always #5 clk = ~clk;

  logic [NP-1:0]        us_cmd_valid, us_cmd_ready, us_cmd_we, us_w_valid, us_w_ready;
  logic [NP*TW-1:0]     us_cmd_tid;
  logic [NP*SW-1:0]     us_cmd_sid;
  logic [NP*IOVA_W-1:0] us_cmd_addr;
  logic [NP*LW-1:0]     us_cmd_len;
  logic [NP*DW-1:0]     us_w_data;
  logic [NP*SB-1:0]     us_w_strb;
  logic [NP-1:0]        us_r_valid, us_r_ready, us_r_we, us_r_err, us_r_last;
  logic [NP*TW-1:0]     us_r_tid;
  logic [NP*DW-1:0]     us_r_data;

  logic [NP-1:0]        ds_cmd_valid, ds_cmd_ready, ds_cmd_we, ds_w_valid, ds_w_ready, ds_w_last;
  logic [NP*TW-1:0]     ds_cmd_tid;
  logic [NP*PA_W-1:0]   ds_cmd_addr;
  logic [NP*LW-1:0]     ds_cmd_len;
  logic [NP*DW-1:0]     ds_w_data;
  logic [NP*SB-1:0]     ds_w_strb;
  logic [NP-1:0]        ds_r_valid, ds_r_ready, ds_r_err;
  logic [NP*DW-1:0]     ds_r_data;

  logic        csr_valid = 0, csr_we = 0, csr_priv = 1;
  logic [7:0]  csr_addr = 0;
  logic [31:0] csr_wdata = 0;
  wire         csr_hit;
  wire  [31:0] csr_rdata;
  wire         irq;

  sf_albion_iommu #(
    .NUM_PORTS(NP), .NUM_DOMAINS(ND), .NUM_STREAMS(NS), .NUM_ENTRIES(NE),
    .IOVA_W(IOVA_W), .PA_W(PA_W), .DATA_W(DW), .LEN_W(LW), .TID_W(TW),
    .MAX_ORDER(MAXO), .FQ_DEPTH(FQD), .CNT_W(CW)
  ) dut (
    .clk(clk), .rst_n(rst_n),
    .us_cmd_valid(us_cmd_valid), .us_cmd_ready(us_cmd_ready), .us_cmd_tid(us_cmd_tid),
    .us_cmd_sid(us_cmd_sid), .us_cmd_we(us_cmd_we), .us_cmd_addr(us_cmd_addr), .us_cmd_len(us_cmd_len),
    .us_w_valid(us_w_valid), .us_w_ready(us_w_ready), .us_w_data(us_w_data), .us_w_strb(us_w_strb),
    .us_r_valid(us_r_valid), .us_r_ready(us_r_ready), .us_r_tid(us_r_tid), .us_r_we(us_r_we),
    .us_r_err(us_r_err), .us_r_last(us_r_last), .us_r_data(us_r_data),
    .ds_cmd_valid(ds_cmd_valid), .ds_cmd_ready(ds_cmd_ready), .ds_cmd_tid(ds_cmd_tid),
    .ds_cmd_we(ds_cmd_we), .ds_cmd_addr(ds_cmd_addr), .ds_cmd_len(ds_cmd_len),
    .ds_w_valid(ds_w_valid), .ds_w_ready(ds_w_ready), .ds_w_data(ds_w_data), .ds_w_strb(ds_w_strb),
    .ds_w_last(ds_w_last), .ds_r_valid(ds_r_valid), .ds_r_ready(ds_r_ready), .ds_r_err(ds_r_err),
    .ds_r_data(ds_r_data),
    .csr_valid(csr_valid), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata),
    .csr_priv(csr_priv), .csr_hit(csr_hit), .csr_rdata(csr_rdata), .irq(irq));

  // ------------------------------------------------------------------ bookkeeping
  int errors = 0;
  int checks = 0;
  int cyc    = 0;
  always @(posedge clk) cyc <= cyc + 1;

  task automatic check(input bit cond, input string what);
    checks++;
    if (!cond) begin errors++; $display("[FAIL] %s (t=%0t)", what, $time); end
  endtask
  task automatic check_eq(input longint got, input longint exp, input string what);
    checks++;
    if (got !== exp) begin
      errors++; $display("[FAIL] %s: got %0h expected %0h (t=%0t)", what, got, exp, $time);
    end
  endtask

  // ------------------------------------------------------------------ physical memory + golden image
  logic [7:0] pmem [0:PMEM_SZ-1];
  logic [7:0] gold [0:PMEM_SZ-1];
  function automatic logic [7:0] canary(input int a);
    return 8'((a * 37 + 11) ^ (a >> 7) ^ 8'hA5);
  endfunction
  task automatic mem_init();
    for (int i = 0; i < PMEM_SZ; i++) begin pmem[i] = canary(i); gold[i] = canary(i); end
  endtask
  task automatic image_check(input string tag);
    int bad = 0;
    for (int i = 0; i < PMEM_SZ; i++) if (pmem[i] !== gold[i]) begin
      if (bad < 4) $display("[FAIL] %s: physical byte %06h = %02h expected %02h", tag, i, pmem[i], gold[i]);
      bad++;
    end
    checks++;
    if (bad != 0) begin errors++; $display("[FAIL] %s: %0d physical bytes differ from golden image", tag, bad); end
  endtask

  // ------------------------------------------------------------------ ORACLE: configuration mirror
  bit          m_glob_en;
  bit          m_dom_en [ND], m_dom_rd [ND], m_dom_wr [ND];
  bit          m_ctx_v [NP][NS];
  int          m_ctx_d [NP][NS];
  bit          m_ent_v [NE], m_ent_r [NE], m_ent_w [NE];
  int          m_ent_dom [NE], m_ent_ord [NE];
  longint      m_ent_ipn [NE], m_ent_ppn [NE];
  int          m_dfcnt [ND], m_dfmask [ND], m_pok [NP], m_pdeny [NP];
  int          wr_port [ND];      // random-test rule: only this port may write domain d (-1 = any)

  task automatic model_reset();
    m_glob_en = 0;
    for (int d = 0; d < ND; d++) begin m_dom_en[d] = 0; m_dom_rd[d] = 0; m_dom_wr[d] = 0; m_dfcnt[d] = 0; m_dfmask[d] = 0; end
    for (int p = 0; p < NP; p++) begin
      for (int s = 0; s < NS; s++) begin m_ctx_v[p][s] = 0; m_ctx_d[p][s] = 0; end
      m_pok[p] = 0; m_pdeny[p] = 0;
    end
    for (int e = 0; e < NE; e++) begin m_ent_v[e] = 0; m_ent_r[e] = 0; m_ent_w[e] = 0; m_ent_dom[e] = 0;
                                       m_ent_ord[e] = 0; m_ent_ipn[e] = 0; m_ent_ppn[e] = 0; end
  endtask

  // Independent decision procedure. Regions are compared as [first,last] page
  // ranges with plain integers (no masks), so it does not share a formulation
  // with the RTL.
  task automatic model_decide(input int p, input int sid, input bit we, input longint iova, input int len,
                              output bit grant, output int cause, output longint pa,
                              output int dom, output bit domv, output int hit_e);
    longint page, first, last, nbytes, off;
    int nb;
    grant = 0; cause = 0; pa = 0; dom = 0; domv = 0; hit_e = -1;
    nb = DW / 8;
    domv = (sid < NS) && m_ctx_v[p][(sid < NS) ? sid : 0];
    if (domv) dom = m_ctx_d[p][sid];
    if (!m_glob_en)                  begin cause = `SF_DG_F_DISABLED; return; end
    if (!domv)                       begin cause = `SF_DG_F_NO_CTX;   return; end
    if (!m_dom_en[dom])              begin cause = `SF_DG_F_DISABLED; return; end
    if ((iova % nb) != 0)            begin cause = `SF_DG_F_MISALIGN; return; end
    off    = iova % 4096;
    nbytes = (len + 1) * nb;
    if (off + nbytes > 4096)         begin cause = `SF_DG_F_PAGE_CROSS; return; end
    page = iova / 4096;
    for (int e = 0; e < NE; e++) begin
      first = m_ent_ipn[e];
      last  = m_ent_ipn[e] + (longint'(1) << m_ent_ord[e]) - 1;
      if (hit_e < 0 && m_ent_v[e] && m_ent_dom[e] == dom && page >= first && page <= last) hit_e = e;
    end
    if (hit_e < 0)                   begin cause = `SF_DG_F_UNMAPPED; return; end
    if (we  && !(m_ent_w[hit_e] && m_dom_wr[dom])) begin cause = `SF_DG_F_PERM_W; return; end
    if (!we && !(m_ent_r[hit_e] && m_dom_rd[dom])) begin cause = `SF_DG_F_PERM_R; return; end
    pa    = (m_ent_ppn[hit_e] + (page - m_ent_ipn[hit_e])) * 4096 + off;
    grant = 1; cause = `SF_DG_F_NONE;
  endtask

  // expected fault records (matched against the DUT's fault log)
  localparam int EFMAX = 8192;
  int     ef_n;
  int     ef_cause [EFMAX], ef_port [EFMAX], ef_sid [EFMAX], ef_tid [EFMAX], ef_len [EFMAX], ef_dom [EFMAX];
  bit     ef_we [EFMAX], ef_domv [EFMAX], ef_used [EFMAX];
  longint ef_iova [EFMAX];

  // ------------------------------------------------------------------ upstream request slots (one per port)
  bit          rq_pending [NP];
  bit          rq_manual  [NP];          // test supplies the expectation itself
  bit          rq_exp_grant [NP];
  longint      rq_exp_pa  [NP];
  int          rq_sid [NP], rq_tid [NP], rq_len [NP], rq_gap [NP];
  bit          rq_we  [NP];
  bit          rq_early [NP];            // present W data together with the command
  longint      rq_iova [NP];
  logic [DW-1:0]  rq_wd [NP][MAXB];
  logic [SB-1:0]  rq_ws [NP][MAXB];
  logic [DW-1:0]  rq_exp_rd [NP][MAXB];
  // results
  bit          rs_err [NP];
  int          rs_cause [NP];
  logic [DW-1:0] rs_rd [NP][MAXB];
  int          rs_beats [NP];
  int          rs_cycles [NP];
  bit          ds_injected [NP];
  bit          ds_inject_next [NP];
  // knobs
  int up_w_gap_pct   = 0;    // % chance of an idle cycle before each W beat
  int up_r_stall_pct = 0;    // % chance us_r_ready is low in a cycle
  int ds_stall_pct   = 0;    // % chance a downstream ready is low in a cycle
  int ds_lat_max     = 0;    // extra read latency (cycles)
  bit hold_cmd [NP];         // downstream refuses to accept commands
  bit hold_w   [NP];         // downstream refuses W beats
  bit hold_r   [NP];         // downstream withholds read/write responses
  bit no_w_data[NP];         // initiator never sends its W data
  int exp_leaks = 0;

  // downstream expectation (one outstanding burst per port)
  bit          exp_valid [NP];
  longint      exp_pa [NP];
  bit          exp_we [NP];
  int          exp_len [NP], exp_tid [NP];
  int          ds_writes_seen [NP];   // write beats accepted downstream (for reset / drain tests)
  int          ds_cmds_seen [NP];

  // upstream FSM state
  typedef enum int {U_IDLE, U_GAP, U_CMD, U_W, U_R} ust_t;
  ust_t ust [NP];
  int   u_gap [NP], u_beat [NP], u_t0 [NP];
  bit   w_vld_r [NP];
  bit   exp_err_q [NP];
  bit   exp_denied_q [NP];

  // downstream FSM state
  typedef enum int {DS_IDLE, DS_W, DS_B, DS_RLAT, DS_R} dst_t;
  dst_t dst [NP];
  longint d_addr [NP];
  int   d_len [NP], d_beat [NP], d_lat [NP];
  bit   d_we [NP];
  bit   dcmd_rdy_r [NP], dw_rdy_r [NP], dr_vld_r [NP], dr_err_r [NP];
  logic [DW-1:0] dr_data_r [NP];
  bit   r_rdy_r [NP];

  genvar gi;
  generate for (gi = 0; gi < NP; gi++) begin : g_glue
    assign ds_cmd_ready[gi] = dcmd_rdy_r[gi];
    assign ds_w_ready[gi]   = dw_rdy_r[gi];
    assign ds_r_valid[gi]   = dr_vld_r[gi];
    assign ds_r_err[gi]     = dr_err_r[gi];
    assign ds_r_data[gi*DW +: DW] = dr_data_r[gi];
    assign us_r_ready[gi]   = r_rdy_r[gi];
  end endgenerate

  function automatic bit chance(input int pct);
    return (int'($urandom_range(99, 0)) < pct);
  endfunction

  task automatic fsm_reset();
    for (int p = 0; p < NP; p++) begin
      ust[p] = U_IDLE; dst[p] = DS_IDLE; rq_pending[p] = 0; exp_valid[p] = 0; w_vld_r[p] = 0;
      dcmd_rdy_r[p] = 0; dw_rdy_r[p] = 0; dr_vld_r[p] = 0; dr_err_r[p] = 0; dr_data_r[p] = '0; r_rdy_r[p] = 0;
      us_cmd_valid[p] = 0; us_w_valid[p] = 0; us_cmd_we[p] = 0;
      us_cmd_tid[p*TW +: TW] = '0; us_cmd_sid[p*SW +: SW] = '0;
      us_cmd_addr[p*IOVA_W +: IOVA_W] = '0; us_cmd_len[p*LW +: LW] = '0;
      us_w_data[p*DW +: DW] = '0; us_w_strb[p*SB +: SB] = '0;
    end
  endtask

  // ------------------------------------------------------------------ UPSTREAM driver FSMs
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int p = 0; p < NP; p++) begin
        ust[p] = U_IDLE; rq_pending[p] = 0; w_vld_r[p] = 0; r_rdy_r[p] <= 0;
        us_cmd_valid[p] <= 0; us_w_valid[p] <= 0;
      end
    end else begin
      for (int p = 0; p < NP; p++) begin
        case (ust[p])
          U_IDLE: if (rq_pending[p]) begin u_gap[p] = rq_gap[p]; ust[p] = U_GAP; end

          U_GAP: begin
            if (u_gap[p] > 0) u_gap[p]--;
            else begin
              bit g; int c, dm; bit dv; int he; longint pa;
              if (!rq_manual[p]) begin
                model_decide(p, rq_sid[p], rq_we[p], rq_iova[p], rq_len[p], g, c, pa, dm, dv, he);
                rq_exp_grant[p] = g; rq_exp_pa[p] = pa; rs_cause[p] = c;
                if (g) begin
                  m_pok[p]++;
                end else begin
                  m_pdeny[p]++;
                  if (dv) begin m_dfcnt[dm]++; m_dfmask[dm] |= (1 << c); end
                  if (ef_n < EFMAX) begin
                    ef_cause[ef_n] = c; ef_port[ef_n] = p; ef_sid[ef_n] = rq_sid[p]; ef_tid[ef_n] = rq_tid[p];
                    ef_len[ef_n] = rq_len[p]; ef_dom[ef_n] = dm; ef_we[ef_n] = rq_we[p]; ef_domv[ef_n] = dv;
                    ef_iova[ef_n] = rq_iova[p]; ef_used[ef_n] = 0; ef_n++;
                  end
                end
              end
              // golden image / expected read data
              if (rq_exp_grant[p]) begin
                for (int b = 0; b <= rq_len[p]; b++) begin
                  if (rq_we[p]) begin
                    for (int k = 0; k < SB; k++)
                      if (rq_ws[p][b][k]) gold[rq_exp_pa[p] + b*SB + k] = rq_wd[p][b][k*8 +: 8];
                  end else begin
                    for (int k = 0; k < SB; k++) rq_exp_rd[p][b][k*8 +: 8] = gold[rq_exp_pa[p] + b*SB + k];
                  end
                end
                exp_valid[p] = 1; exp_pa[p] = rq_exp_pa[p]; exp_we[p] = rq_we[p];
                exp_len[p] = rq_len[p]; exp_tid[p] = rq_tid[p];
              end
              exp_denied_q[p] = !rq_exp_grant[p];
              ds_injected[p]  = 0;
              us_cmd_valid[p] <= 1;
              us_cmd_tid[p*TW +: TW]        <= TW'(rq_tid[p]);
              us_cmd_sid[p*SW +: SW]        <= SW'(rq_sid[p]);
              us_cmd_we[p]                  <= rq_we[p];
              us_cmd_addr[p*IOVA_W +: IOVA_W] <= IOVA_W'(rq_iova[p]);
              us_cmd_len[p*LW +: LW]        <= LW'(rq_len[p]);
              u_t0[p] = cyc; u_beat[p] = 0;
              if (rq_we[p] && rq_early[p] && !no_w_data[p]) begin
                us_w_valid[p] <= 1; us_w_data[p*DW +: DW] <= rq_wd[p][0]; us_w_strb[p*SB +: SB] <= rq_ws[p][0];
                w_vld_r[p] = 1;
              end
              ust[p] = U_CMD;
            end
          end

          U_CMD: if (us_cmd_valid[p] && us_cmd_ready[p]) begin
            us_cmd_valid[p] <= 0;
            ust[p] = rq_we[p] ? U_W : U_R;
            u_beat[p] = 0;
          end

          U_W: begin
            if (w_vld_r[p] && us_w_valid[p] && us_w_ready[p]) begin   // beat accepted at this edge
              u_beat[p]++;
              w_vld_r[p] = 0; us_w_valid[p] <= 0;
            end
            if (u_beat[p] > rq_len[p]) begin u_beat[p] = 0; ust[p] = U_R; end
            else if (!w_vld_r[p] && !no_w_data[p] && !chance(up_w_gap_pct)) begin
              us_w_valid[p] <= 1; us_w_data[p*DW +: DW] <= rq_wd[p][u_beat[p]];
              us_w_strb[p*SB +: SB] <= rq_ws[p][u_beat[p]]; w_vld_r[p] = 1;
            end
          end

          U_R: begin
            r_rdy_r[p] <= !chance(up_r_stall_pct);
            if (us_r_valid[p] && r_rdy_r[p]) begin
              bit exp_e;
              int nb_exp;
              exp_e  = exp_denied_q[p] || ds_injected[p];
              nb_exp = rq_we[p] ? 1 : (rq_len[p] + 1);
              check_eq(us_r_tid[p*TW +: TW], rq_tid[p], $sformatf("p%0d resp tid", p));
              check_eq(us_r_we[p], rq_we[p], $sformatf("p%0d resp direction", p));
              check_eq(us_r_err[p], exp_e, $sformatf("p%0d resp err (cause=%0d)", p, rs_cause[p]));
              check_eq(us_r_last[p], (u_beat[p] == nb_exp - 1), $sformatf("p%0d resp last", p));
              if (!rq_we[p]) begin
                rs_rd[p][u_beat[p]] = us_r_data[p*DW +: DW];
                if (exp_denied_q[p])
                  check_eq(us_r_data[p*DW +: DW], 0, $sformatf("p%0d denied read must return zero", p));
                else if (!ds_injected[p])
                  check_eq(us_r_data[p*DW +: DW], rq_exp_rd[p][u_beat[p]], $sformatf("p%0d read data beat %0d", p, u_beat[p]));
              end else
                check_eq(us_r_data[p*DW +: DW], 0, $sformatf("p%0d write resp data", p));
              rs_err[p] = us_r_err[p];
              u_beat[p]++;
              if (u_beat[p] == nb_exp) begin
                rs_beats[p] = nb_exp; rs_cycles[p] = cyc - u_t0[p];
                r_rdy_r[p] <= 0; rq_pending[p] = 0; ust[p] = U_IDLE;
              end
            end
          end
          default: ust[p] = U_IDLE;
        endcase
      end
    end
  end

  // ------------------------------------------------------------------ DOWNSTREAM memory agents
  always @(posedge clk) begin
    if (!rst_n) begin
      for (int p = 0; p < NP; p++) begin
        dst[p] = DS_IDLE; dcmd_rdy_r[p] <= 0; dw_rdy_r[p] <= 0; dr_vld_r[p] <= 0; dr_err_r[p] <= 0;
        exp_valid[p] = 0;
      end
    end else begin
      for (int p = 0; p < NP; p++) begin
        // monitors that apply in every state
        if (ds_w_valid[p] && dst[p] != DS_W) begin
          errors++; exp_leaks++;
          $display("[FAIL] p%0d: downstream write beat valid with no accepted command (t=%0t)", p, $time);
        end
        case (dst[p])
          DS_IDLE: begin
            if (ds_cmd_valid[p] && dcmd_rdy_r[p]) begin
              ds_cmds_seen[p]++;
              checks++;
              if (!exp_valid[p]) begin
                errors++; exp_leaks++;
                $display("[FAIL] p%0d: DOWNSTREAM COMMAND NOT AUTHORISED BY ORACLE: pa=%06h we=%0b len=%0d (t=%0t)",
                         p, ds_cmd_addr[p*PA_W +: PA_W], ds_cmd_we[p], ds_cmd_len[p*LW +: LW], $time);
              end else begin
                check_eq(ds_cmd_addr[p*PA_W +: PA_W], exp_pa[p], $sformatf("p%0d ds addr", p));
                check_eq(ds_cmd_we[p], exp_we[p], $sformatf("p%0d ds dir", p));
                check_eq(ds_cmd_len[p*LW +: LW], exp_len[p], $sformatf("p%0d ds len", p));
                check_eq(ds_cmd_tid[p*TW +: TW], exp_tid[p], $sformatf("p%0d ds tid", p));
              end
              exp_valid[p] = 0;
              d_addr[p] = ds_cmd_addr[p*PA_W +: PA_W]; d_len[p] = ds_cmd_len[p*LW +: LW];
              d_we[p] = ds_cmd_we[p]; d_beat[p] = 0;
              dcmd_rdy_r[p] <= 0;
              if (ds_cmd_we[p]) dst[p] = DS_W;
              else begin dst[p] = DS_RLAT; d_lat[p] = (ds_lat_max > 0) ? $urandom_range(ds_lat_max, 0) : 0; end
            end else
              dcmd_rdy_r[p] <= !hold_cmd[p] && !chance(ds_stall_pct);
          end

          DS_W: begin
            if (ds_w_valid[p] && dw_rdy_r[p]) begin
              ds_writes_seen[p]++;
              checks++;
              if (d_beat[p] > d_len[p]) begin errors++; $display("[FAIL] p%0d: too many downstream write beats", p); end
              for (int k = 0; k < SB; k++)
                if (ds_w_strb[p*SB + k]) pmem[d_addr[p] + d_beat[p]*SB + k] = ds_w_data[p*DW + k*8 +: 8];
              if (ds_w_data[p*DW +: DW] !== (rq_wd[p][d_beat[p]]) && ds_w_strb[p*SB +: SB] != '0 && !rq_manual[p]) begin
                // masked compare: only strobed bytes matter
                for (int k = 0; k < SB; k++)
                  if (ds_w_strb[p*SB + k] && ds_w_data[p*DW + k*8 +: 8] !== rq_wd[p][d_beat[p]][k*8 +: 8]) begin
                    errors++; $display("[FAIL] p%0d: ds write data mismatch beat %0d byte %0d", p, d_beat[p], k);
                  end
              end
              check_eq(ds_w_last[p], (d_beat[p] == d_len[p]), $sformatf("p%0d ds w_last", p));
              d_beat[p]++;
              dw_rdy_r[p] <= 0;
              if (d_beat[p] > d_len[p]) dst[p] = DS_B;
            end else
              dw_rdy_r[p] <= !hold_w[p] && !chance(ds_stall_pct);
          end

          DS_B: begin
            if (dr_vld_r[p] && ds_r_ready[p]) begin dr_vld_r[p] <= 0; dst[p] = DS_IDLE; end
            else if (!dr_vld_r[p] && !hold_r[p]) begin
              dr_vld_r[p] <= 1; dr_err_r[p] <= ds_inject_next[p]; dr_data_r[p] <= '0;
              if (ds_inject_next[p]) begin ds_injected[p] = 1; ds_inject_next[p] = 0; end
            end
          end

          DS_RLAT: begin
            if (hold_r[p]) ;
            else if (d_lat[p] > 0) d_lat[p]--;
            else dst[p] = DS_R;
          end

          DS_R: begin
            if (dr_vld_r[p] && ds_r_ready[p]) begin
              d_beat[p]++;
              dr_vld_r[p] <= 0;
              if (d_beat[p] > d_len[p]) dst[p] = DS_IDLE;
            end else if (!dr_vld_r[p] && !chance(ds_stall_pct)) begin
              logic [DW-1:0] dd;
              for (int k = 0; k < SB; k++) dd[k*8 +: 8] = pmem[d_addr[p] + d_beat[p]*SB + k];
              dr_vld_r[p] <= 1; dr_data_r[p] <= dd; dr_err_r[p] <= ds_inject_next[p];
              if (ds_inject_next[p]) begin ds_injected[p] = 1; ds_inject_next[p] = 0; end
            end
          end
          default: dst[p] = DS_IDLE;
        endcase
      end
    end
  end

  // ------------------------------------------------------------------ CSR master
  task automatic csr_xfer(input bit we, input bit priv, input [7:0] a, input [31:0] d,
                          output bit hit, output [31:0] rd);
    @(posedge clk); #1;
    csr_valid = 1; csr_we = we; csr_priv = priv; csr_addr = a; csr_wdata = d;
    #2; hit = csr_hit; rd = csr_rdata;
    @(posedge clk); #1;
    csr_valid = 0; csr_we = 0; csr_priv = 1;
  endtask
  task automatic csr_w(input [7:0] a, input [31:0] d);
    bit h; logic [31:0] r;
    csr_xfer(1, 1, a, d, h, r);
    check(h, $sformatf("csr write %02h accepted", a));
  endtask
  task automatic csr_r(input [7:0] a, output [31:0] d);
    bit h;
    csr_xfer(0, 1, a, 0, h, d);
    check(h, $sformatf("csr read %02h accepted", a));
  endtask

  localparam logic [7:0] A_CTRL = 8'h04, A_STATUS = 8'h05, A_STG_IPN = 8'h08, A_STG_PPN = 8'h09,
                         A_STG_ATTR = 8'h0A, A_STG_CTX = 8'h0B, A_STG_DOM = 8'h0C, A_CMD = 8'h0D,
                         A_FQ_STATUS = 8'h10, A_FQ_META = 8'h11, A_FQ_IOVA = 8'h12, A_FQ_ID = 8'h13,
                         A_FQ_POP = 8'h14, A_SEL_DOM = 8'h18, A_DOM_CFG = 8'h19, A_DOM_FCNT = 8'h1A,
                         A_DOM_FMASK = 8'h1B, A_SEL_ENT = 8'h1C, A_ENT_RD0 = 8'h1D, A_ENT_RD1 = 8'h1E,
                         A_ENT_RD2 = 8'h1F, A_CTX_RD = 8'h20, A_SEL_PORT = 8'h21, A_PORT_OK = 8'h22,
                         A_PORT_DENY = 8'h23;

  task automatic wait_not_busy(input int maxc);
    logic [31:0] st; int n = 0;
    csr_r(A_STATUS, st);
    while (st[0] && n < maxc) begin csr_r(A_STATUS, st); n++; end
    check(!st[0], "drain completes (STATUS.busy falls)");
  endtask

  // issue one admin command, wait for the drain, return last_err
  task automatic adm(input int op, input int idx, output int err);
    logic [31:0] st;
    csr_w(A_CMD, 32'((idx << 8) | op));
    wait_not_busy(4000);
    csr_r(A_STATUS, st);
    err = int'(st[11:8]);
  endtask

  // ---- mirrored admin helpers: update the model only when the DUT reports success
  task automatic adm_glob(input bit en);
    csr_w(A_CTRL, {30'd0, 1'b0, en});
    wait_not_busy(4000);
    m_glob_en = en;
  endtask
  task automatic adm_dom(input int d, input bit en, input bit rd, input bit wr);
    int e;
    csr_w(A_STG_DOM, 32'(d | (en << 8) | (rd << 9) | (wr << 10)));
    adm(`SF_DG_OP_DOM_SET, 0, e);
    check_eq(e, 0, $sformatf("DOM_SET d%0d accepted", d));
    if (e == 0) begin m_dom_en[d] = en; m_dom_rd[d] = rd; m_dom_wr[d] = wr; end
  endtask
  task automatic adm_ctx(input int p, input int s, input int d);
    int e;
    csr_w(A_STG_CTX, 32'(p | (s << 8) | (d << 16)));
    adm(`SF_DG_OP_CTX_SET, 0, e);
    check_eq(e, 0, $sformatf("CTX_SET p%0d s%0d -> d%0d accepted", p, s, d));
    if (e == 0) begin m_ctx_v[p][s] = 1; m_ctx_d[p][s] = d; end
  endtask
  task automatic adm_ctx_clr(input int p, input int s);
    int e;
    csr_w(A_STG_CTX, 32'(p | (s << 8)));
    adm(`SF_DG_OP_CTX_CLR, 0, e);
    check_eq(e, 0, "CTX_CLR accepted");
    m_ctx_v[p][s] = 0;
  endtask
  task automatic adm_ent(input int idx, input int d, input longint ipn, input longint ppn,
                         input int ord, input bit r, input bit w, output int err);
    csr_w(A_STG_IPN, 32'(ipn));
    csr_w(A_STG_PPN, 32'(ppn));
    csr_w(A_STG_ATTR, 32'(r | (w << 1) | (ord << 8) | (d << 16)));
    adm(`SF_DG_OP_ENT_SET, idx, err);
    if (err == 0) begin
      m_ent_v[idx] = 1; m_ent_dom[idx] = d; m_ent_ipn[idx] = ipn; m_ent_ppn[idx] = ppn;
      m_ent_ord[idx] = ord; m_ent_r[idx] = r; m_ent_w[idx] = w;
    end
  endtask
  task automatic adm_ent_ok(input int idx, input int d, input longint ipn, input longint ppn,
                            input int ord, input bit r, input bit w);
    int e;
    adm_ent(idx, d, ipn, ppn, ord, r, w, e);
    check_eq(e, 0, $sformatf("ENT_SET slot %0d accepted", idx));
  endtask
  task automatic adm_ent_clr(input int idx);
    int e;
    adm(`SF_DG_OP_ENT_CLR, idx, e);
    check_eq(e, 0, "ENT_CLR accepted");
    m_ent_v[idx] = 0;
  endtask

  // ---- upstream helpers
  task automatic fill_data(input int p, input bit random_strb);
    for (int b = 0; b < MAXB; b++) begin
      rq_wd[p][b] = $urandom();
      rq_ws[p][b] = random_strb ? SB'($urandom_range((1 << SB) - 1, 1)) : '1;
    end
  endtask
  task automatic submit(input int p, input int sid, input int tid, input bit we, input longint iova, input int len);
    rq_sid[p] = sid; rq_tid[p] = tid; rq_we[p] = we; rq_iova[p] = iova; rq_len[p] = len;
    rq_manual[p] = 0; rq_gap[p] = 0; rq_early[p] = 0;
    rq_pending[p] = 1;
  endtask
  task automatic wait_done(input int p, input int maxc);
    int n = 0;
    while (rq_pending[p] && n < maxc) begin @(posedge clk); n++; end
    check(!rq_pending[p], $sformatf("p%0d burst completes (no deadlock)", p));
  endtask
  // blocking burst; returns the DUT's error flag and the oracle's cause
  task automatic burst(input int p, input int sid, input int tid, input bit we, input longint iova,
                       input int len, output bit err, output int cause);
    if (we) fill_data(p, 1);
    submit(p, sid, tid, we, iova, len);
    wait_done(p, 20000);
    err = rs_err[p]; cause = rs_cause[p];
  endtask
  task automatic burst_expect(input int p, input int sid, input bit we, input longint iova, input int len,
                              input int exp_cause, input string what);
    bit e; int c;
    burst(p, sid, int'($urandom_range(15, 0)), we, iova, len, e, c);
    check_eq(c, exp_cause, {what, ": oracle cause"});
    check_eq(e, (exp_cause != 0), {what, ": error flag"});
  endtask

  // ---- fault-log reader
  task automatic fq_pop_record(output bit got, output int cause, output int port, output int sid,
                               output int dom, output bit domv, output bit we, output longint iova,
                               output int tid, output int len);
    logic [31:0] st, meta, ia, idl;
    csr_r(A_FQ_STATUS, st);
    got = (st[7:0] != 0);
    if (got) begin
      csr_r(A_FQ_META, meta); csr_r(A_FQ_IOVA, ia); csr_r(A_FQ_ID, idl);
      cause = int'(meta[3:0]); we = meta[4]; domv = meta[5]; dom = int'(meta[15:8]);
      port = int'(meta[23:16]); sid = int'(meta[27:24]); iova = longint'(ia); tid = int'(idl[7:0]); len = int'(idl[15:8]);
      csr_w(A_FQ_POP, 32'd1);
    end
  endtask
  // pop one record and match it against the oracle's list
  task automatic fq_match_one(output bit got);
    int c, p, s, d, t, l; bit dv, w; longint ia; bit ok;
    fq_pop_record(got, c, p, s, d, dv, w, ia, t, l);
    if (got) begin
      ok = 0;
      for (int i = 0; i < ef_n && !ok; i++)
        if (!ef_used[i] && ef_cause[i] == c && ef_port[i] == p && ef_sid[i] == s && ef_tid[i] == t &&
            ef_len[i] == l && ef_we[i] == w && ef_domv[i] == dv && (!dv || ef_dom[i] == d) && ef_iova[i] == ia) begin
          ef_used[i] = 1; ok = 1;
        end
      check(ok, $sformatf("fault record matches an expected denial (cause=%0d p=%0d s=%0d iova=%0h)", c, p, s, ia));
    end
  endtask
  // Every denial the oracle expected must be either in the log or counted as an overflow drop.
  task automatic fq_drain_expect_all(input string tag, input int unused_allowed);
    bit got; int unmatched = 0; int drops; logic [31:0] st;
    csr_r(A_FQ_STATUS, st); drops = int'(st[31:16]);
    got = 1;
    while (got) fq_match_one(got);
    for (int i = 0; i < ef_n; i++) if (!ef_used[i]) unmatched++;
    check_eq(unmatched, drops, $sformatf("%s: unlogged denials == counted overflow drops", tag));
  endtask
  task automatic ef_clear(); ef_n = 0; endtask

  // ---- common configuration used by the directed tests
  localparam int D_A = 1, D_B = 2, D_C = 3, D_S = 4;
  localparam longint IOVA_RW  = 24'h100000;   // page 0x100
  localparam longint IOVA_RO  = 24'h101000;   // page 0x101 (adjacent to RW)
  localparam longint IOVA_REG = 24'h200000;   // region order 2: pages 0x200..0x203
  localparam longint IOVA_B2  = 24'h300000;   // only B maps this
  localparam longint IOVA_SH  = 24'h400000;   // shared RO page
  localparam longint PA_A_RW = 24'h040000, PA_A_RO = 24'h041000, PA_A_REG = 24'h080000;
  localparam longint PA_B_RW = 24'h0C0000, PA_B_2 = 24'h100000, PA_SH = 24'h0F0000, PA_C_RW = 24'h140000;

  task automatic configure_tenants();
    int e;
    adm_glob(1);
    adm_dom(D_A, 1, 1, 1);
    adm_dom(D_B, 1, 1, 1);
    adm_dom(D_C, 1, 1, 1);
    adm_dom(D_S, 1, 1, 0);
    // port0: stream0 -> A, stream1 -> B ; port1: stream0 -> B ; port2: stream0 -> C ; port1 stream2 -> S
    adm_ctx(0, 0, D_A); adm_ctx(0, 1, D_B); adm_ctx(1, 0, D_B); adm_ctx(2, 0, D_C); adm_ctx(1, 2, D_S);
    // tenant A
    adm_ent_ok(0, D_A, IOVA_RW  >> 12, PA_A_RW  >> 12, 0, 1, 1);
    adm_ent_ok(1, D_A, IOVA_RO  >> 12, PA_A_RO  >> 12, 0, 1, 0);
    adm_ent_ok(2, D_A, IOVA_REG >> 12, PA_A_REG >> 12, 2, 1, 1);
    adm_ent_ok(3, D_A, IOVA_SH  >> 12, PA_SH    >> 12, 0, 1, 0);
    // tenant B: SAME IOVA as A for the RW page, different PA
    adm_ent_ok(4, D_B, IOVA_RW  >> 12, PA_B_RW  >> 12, 0, 1, 1);
    adm_ent_ok(5, D_B, IOVA_B2  >> 12, PA_B_2   >> 12, 0, 1, 1);
    adm_ent_ok(6, D_B, IOVA_SH  >> 12, PA_SH    >> 12, 0, 1, 0);
    // tenant C
    adm_ent_ok(7, D_C, IOVA_RW  >> 12, PA_C_RW  >> 12, 0, 1, 1);
  endtask

  task automatic hard_reset(input int cycles);
    rst_n = 0;
    #1;
    repeat (cycles) @(posedge clk);
    #1; fsm_reset(); model_reset();
    #1; rst_n = 1;
    repeat (2) @(posedge clk);
  endtask

  task automatic clear_knobs();
    up_w_gap_pct = 0; up_r_stall_pct = 0; ds_stall_pct = 0; ds_lat_max = 0;
    for (int p = 0; p < NP; p++) begin
      hold_cmd[p] = 0; hold_w[p] = 0; hold_r[p] = 0; no_w_data[p] = 0; ds_inject_next[p] = 0;
    end
  endtask

  // ====================================================================== TESTS
  `include "tb_dg_unit_tests.svh"

  initial begin : watchdog
    #60ms;
    $display("[FAIL] global watchdog");
    $display("TB_RESULT FAIL errors=%0d (watchdog)", errors + 1);
    $finish;
  end

  initial begin
    void'($urandom(SEED));
    clear_knobs();
    for (int d = 0; d < ND; d++) wr_port[d] = -1;
    ef_n = 0;
    mem_init();
    model_reset();
    fsm_reset();
    rst_n = 0;
    repeat (5) @(posedge clk);
    #1 rst_n = 1;
    repeat (3) @(posedge clk);
    run_all_tests();
    if (errors == 0) $display("TB_RESULT PASS checks=%0d", checks);
    else             $display("TB_RESULT FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end
endmodule
