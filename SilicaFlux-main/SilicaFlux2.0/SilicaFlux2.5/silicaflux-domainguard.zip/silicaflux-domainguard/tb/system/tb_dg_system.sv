// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | tb_dg_system
// System-level adversarial test of the PROTECTED die (silicaflux_dietop_dg):
// real sf_dma / sf_host_if / sf_control_core masters, real fabric and memories.
//
// Independent checks:
//   * PHYSICAL-WRITE MONITOR: every write strobe at the real memories (external
//     memory port, scratchpad SRAM, command-RAM SRAM) must lie inside a write
//     burst that the IOMMU issued downstream (hierarchical probes).
//   * CANARIES: all external memory is canary-filled; tenants' pages are checked
//     word by word after each scenario.
//   * The control core's own error reporting (code 6 = DMA error).
// -----------------------------------------------------------------------------
`timescale 1ns/1ps
`include "sf_albion_defs.svh"
module tb_dg_system;
  localparam real TCLK = 10.0;
  parameter int SEED = 97;

  logic clk = 0, rst_n = 0, test_mode = 0;
  logic host_req = 0, host_we = 0, host_priv = 1;
  logic [15:0] host_addr = 0;
  logic [31:0] host_wdata = 0;
  logic [1:0]  host_sid = 0;
  wire host_ack, host_err;
  wire [31:0] host_rdata;
  wire ext_req, ext_we;
  wire [14:0] ext_addr;
  wire [31:0] ext_wdata;
  logic ext_ack = 0;
  logic [31:0] ext_rdata = 0;
  wire irq;
  logic therm_alert = 0;
  logic tck = 0, tms = 1, tdi = 0, trst_n = 1;
  wire tdo;
  always #(TCLK/2) clk = ~clk;

  silicaflux_dietop_dg dut (
    .clk(clk), .rst_n(rst_n), .test_mode(test_mode),
    .host_req(host_req), .host_we(host_we), .host_addr(host_addr), .host_wdata(host_wdata),
    .host_priv(host_priv), .host_sid(host_sid),
    .host_ack(host_ack), .host_rdata(host_rdata), .host_err(host_err),
    .ext_req(ext_req), .ext_we(ext_we), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
    .ext_ack(ext_ack), .ext_rdata(ext_rdata), .irq(irq), .therm_alert(therm_alert),
    .tck(tck), .tms(tms), .tdi(tdi), .trst_n(trst_n), .tdo(tdo));

  int errors = 0, checks = 0;
  task automatic check(input string what, input logic [31:0] got, input logic [31:0] exp);
    checks++;
    if (got !== exp) begin errors++; $display("[FAIL] %s: got %08h expected %08h (t=%0t)", what, got, exp, $time); end
  endtask

  // ------------------------------------------------------------------ external memory model (canary filled)
  logic [31:0] extmem [0:32767];
  function automatic logic [31:0] ext_canary(input int i); return 32'hC0DE_0000 ^ (32'(i) * 32'h9E37_79B1); endfunction
  int ext_lat_seed = 7;
  initial begin
    for (int i = 0; i < 32768; i++) extmem[i] = ext_canary(i);
    forever begin
      @(posedge clk);
      if (ext_req && !ext_ack) begin
        ext_lat_seed = (ext_lat_seed * 1103515245 + 12345);
        repeat ((ext_lat_seed >>> 16) & 3) @(posedge clk);
        #1;
        if (ext_req) begin
          if (ext_we) extmem[ext_addr] = ext_wdata;
          else        ext_rdata = extmem[ext_addr];
          ext_ack = 1;
          wait (!ext_req || !rst_n);
          @(posedge clk); #1;
          ext_ack = 0;
        end
      end
    end
  end

  // ------------------------------------------------------------------ physical-write authorisation monitor
  // An authorised region = a write burst the IOMMU has issued downstream and not yet completed.
  bit          au_v  [3];
  int          au_lo [3];
  int          au_hi [3];
  int          phys_writes = 0, phys_viol = 0;
  logic        ext_req_q = 0;
  always @(posedge clk) begin
    for (int p = 0; p < 3; p++) begin
      if (dut.ds_cmd_valid[p] && dut.ds_cmd_ready[p] && dut.ds_cmd_we[p]) begin
        au_v[p]  = 1;
        au_lo[p] = int'(dut.ds_cmd_addr[p*18 + 2 +: 16]);
        au_hi[p] = int'(dut.ds_cmd_addr[p*18 + 2 +: 16]) + int'(dut.ds_cmd_len[p*4 +: 4]);
      end
      if (dut.ds_r_valid[p] && dut.ds_r_ready[p] && au_v[p] && !dut.ds_cmd_we[p]) ; // read responses leave state alone
      if (dut.ds_r_valid[p] && dut.ds_r_ready[p] && au_v[p]) au_v[p] = 0;           // write response closes the window
    end
    if (!rst_n) for (int p = 0; p < 3; p++) au_v[p] = 0;
    ext_req_q <= ext_req;
  end
  function automatic bit authorised(input int word_addr);
    for (int p = 0; p < 3; p++) if (au_v[p] && word_addr >= au_lo[p] && word_addr <= au_hi[p]) return 1;
    return 0;
  endfunction
  always @(posedge clk) if (rst_n) begin
    if (ext_req && ext_we && !ext_req_q) begin
      phys_writes++;
      if (!authorised(32'h8000 + int'(ext_addr))) begin phys_viol++; errors++; $display("[FAIL] PHYSICAL WRITE WITHOUT IOMMU AUTHORISATION: ext word %05h (t=%0t)", 32'h8000 + int'(ext_addr), $time); end
    end
    if (dut.u_scratch.u_bank.ce && dut.u_scratch.u_bank.we) begin
      phys_writes++;
      if (!authorised(32'h3000 + int'(dut.u_scratch.u_bank.addr))) begin phys_viol++; errors++; $display("[FAIL] PHYSICAL WRITE WITHOUT IOMMU AUTHORISATION: scratch word %0h (t=%0t)", dut.u_scratch.u_bank.addr, $time); end
    end
    if (dut.u_ctrl.u_cmdram.ce && dut.u_ctrl.u_cmdram.we) begin
      phys_writes++;
      if (!authorised(int'(dut.u_ctrl.u_cmdram.addr))) begin phys_viol++; errors++; $display("[FAIL] PHYSICAL WRITE WITHOUT IOMMU AUTHORISATION: command RAM word %0h (t=%0t)", dut.u_ctrl.u_cmdram.addr, $time); end
    end
  end

  // ------------------------------------------------------------------ host bus
  task automatic host_acc(input logic we, input logic [15:0] a, input logic [31:0] wd, input logic priv,
                          input logic [1:0] sid, output logic [31:0] rd, output logic err);
    @(posedge clk); #1;
    host_we = we; host_addr = a; host_wdata = wd; host_priv = priv; host_sid = sid; host_req = 1;
    wait (host_ack === 1'b1);
    @(posedge clk); #1;
    rd = host_rdata; err = host_err;
    host_req = 0;
    wait (host_ack === 1'b0);
  endtask
  // memory-window access as stream `sid`; returns the error flag
  task automatic mw(input logic we, input logic [15:0] a, input logic [31:0] wd, input logic [1:0] sid,
                    output logic [31:0] rd, output logic err);
    host_acc(we, a, wd, 1'b1, sid, rd, err);
  endtask
  task automatic mw_w(input logic [15:0] a, input logic [31:0] d, input logic [1:0] sid);
    logic [31:0] r; logic e; mw(1, a, d, sid, r, e);
    if (e) begin errors++; $display("[FAIL] unexpected error on write sid%0d @%04h", sid, a); end
  endtask
  task automatic mw_r(input logic [15:0] a, input logic [1:0] sid, output logic [31:0] d);
    logic e; mw(0, a, 0, sid, d, e);
    if (e) begin errors++; $display("[FAIL] unexpected error on read sid%0d @%04h", sid, a); end
  endtask

  localparam logic [15:0] CSR = 16'h4000, ICSR = 16'h4080;
  localparam logic [7:0] I_CTRL = 8'h04, I_STATUS = 8'h05, I_STG_IPN = 8'h08, I_STG_PPN = 8'h09, I_STG_ATTR = 8'h0A,
                         I_STG_CTX = 8'h0B, I_STG_DOM = 8'h0C, I_CMD = 8'h0D, I_FQ_STATUS = 8'h10, I_FQ_META = 8'h11,
                         I_FQ_IOVA = 8'h12, I_SEL_PORT = 8'h21, I_PORT_OK = 8'h22, I_PORT_DENY = 8'h23;
  task automatic iw(input logic [7:0] r, input logic [31:0] d); mw_w(ICSR + 16'(r), d, 2'd0); endtask
  task automatic ir(input logic [7:0] r, output logic [31:0] d);
    logic e; host_acc(0, ICSR + 16'(r), 0, 1'b1, 2'd0, d, e);
    if (e) begin errors++; $display("[FAIL] IOMMU CSR read error @%02h", r); end
  endtask
  task automatic ic_cmd(input int op, input int idx);
    logic [31:0] st; int n = 0;
    iw(I_CMD, 32'((idx << 8) | op));
    ir(I_STATUS, st);
    while (st[0] && n < 2000) begin ir(I_STATUS, st); n++; end
    check("IOMMU drain completes", {31'd0, st[0]}, 0);
    check("IOMMU command accepted", {28'd0, st[11:8]}, 0);
  endtask
  task automatic ic_dom(input int d, input bit en, input bit rd, input bit wr);
    iw(I_STG_DOM, 32'(d | (en << 8) | (rd << 9) | (wr << 10))); ic_cmd(`SF_DG_OP_DOM_SET, 0);
  endtask
  task automatic ic_ctx(input int p, input int s, input int d);
    iw(I_STG_CTX, 32'(p | (s << 8) | (d << 16))); ic_cmd(`SF_DG_OP_CTX_SET, 0);
  endtask
  task automatic ic_ctx_clr(input int p, input int s);
    iw(I_STG_CTX, 32'(p | (s << 8))); ic_cmd(`SF_DG_OP_CTX_CLR, 0);
  endtask
  task automatic ic_ent(input int idx, input int d, input int ipn, input int ppn, input int ord, input bit r, input bit w);
    iw(I_STG_IPN, 32'(ipn)); iw(I_STG_PPN, 32'(ppn)); iw(I_STG_ATTR, 32'(r | (w << 1) | (ord << 8) | (d << 16)));
    ic_cmd(`SF_DG_OP_ENT_SET, idx);
  endtask

  // command ring helpers (host writes through its own stream; ring lives in command RAM)
  int tail = 0;
  task automatic enqueue(input logic [31:0] w0, w1, w2, w3);
    int slot = tail % 16;
    mw_w(16'(slot*4 + 0), w0, 2'd0); mw_w(16'(slot*4 + 1), w1, 2'd0);
    mw_w(16'(slot*4 + 2), w2, 2'd0); mw_w(16'(slot*4 + 3), w3, 2'd0);
    tail = (tail + 1) % 32;
  endtask
  task automatic doorbell(); logic [31:0] r; logic e; host_acc(1, CSR | 16'h02, 32'(tail), 1'b1, 2'd0, r, e); endtask
  task automatic wait_halt_or_idle(output logic [31:0] status);
    int n = 0; logic [31:0] h; logic e;
    do begin
      host_acc(0, CSR | 16'h04, 0, 1'b1, 2'd0, status, e);
      host_acc(0, CSR | 16'h03, 0, 1'b1, 2'd0, h, e);
      n++;
    end while (!status[1] && (h[4:0] != tail[4:0] || status[0]) && n < 4000);
    if (n >= 4000) begin errors++; $display("[FAIL] command queue neither drained nor halted"); end
  endtask
  task automatic clear_halt(); logic [31:0] r; logic e; host_acc(1, CSR | 16'h06, 32'h3, 1'b1, 2'd0, r, e); endtask
  function automatic logic [31:0] dma_cmd(input int len); return (32'd1 << 28) | 32'(len); endfunction

  // run one DMA command; returns the control core's error code (0 = ok)
  task automatic run_dma(input int src_w, input int dst_w, input int len, output int code);
    logic [31:0] st;
    enqueue(dma_cmd(len), 32'(src_w), 32'(dst_w), 0);
    doorbell();
    wait_halt_or_idle(st);
    code = int'(st[11:8]);
    if (st[1]) clear_halt();
  endtask

  function automatic logic [31:0] pat(input int salt, input int i); return 32'hA000_0000 ^ (32'(salt) << 16) ^ 32'(i * 7 + 1); endfunction
  task automatic ext_expect_range(input int base, input int n, input int salt, input string what);
    int bad = 0; for (int i = 0; i < n; i++) if (extmem[base + i] !== pat(salt, i)) bad++;
    checks++; if (bad != 0) begin errors++; $display("[FAIL] %s: %0d of %0d words wrong", what, bad, n); end
  endtask
  task automatic ext_expect_canary(input int base, input int n, input string what);
    int bad = 0; for (int i = 0; i < n; i++) if (extmem[base + i] !== ext_canary(base + i)) bad++;
    checks++; if (bad != 0) begin errors++; $display("[FAIL] %s: %0d of %0d words were modified (canary broken)", what, bad, n); end
  endtask

  localparam int D_SYS = 1, D_CTL = 2, D_A = 3, D_B = 4;

  // ====================================================================== scenarios
  logic [31:0] rd, st; logic e; int code;
  logic [31:0] cmdsave [64];
  initial begin
    for (int p = 0; p < 3; p++) begin au_v[p] = 0; au_lo[p] = 0; au_hi[p] = 0; end
    repeat (3) @(posedge clk);
    #1 rst_n = 1;
    repeat (5) @(posedge clk);

    // ---------- S0: power-on state is deny-all ----------
    $display("--- S0 secure default after reset");
    mw(1, 16'h3000, 32'h1234_5678, 2'd0, rd, e); check("S0 host memory write denied before configuration", {31'd0, e}, 1);
    mw(0, 16'h3000, 0, 2'd0, rd, e);              check("S0 host memory read denied before configuration", {31'd0, e}, 1);
    check("S0 denied read returns zero", rd, 0);
    host_acc(1, ICSR + 16'(I_CTRL), 32'h1, 1'b0, 2'd0, rd, e); check("S0 non-privileged CSR write rejected", {31'd0, e}, 1);
    host_acc(0, ICSR + 16'(I_STATUS), 0, 1'b0, 2'd0, rd, e);   check("S0 non-privileged CSR read rejected", {31'd0, e}, 1);
    host_acc(0, ICSR + 16'h00, 0, 1'b0, 2'd0, rd, e);          check("S0 ID readable without privilege", {31'd0, e}, 0);
    check("S0 IOMMU ID", rd, 32'h4447_0100);
    ir(I_CTRL, rd); check("S0 IOMMU disabled at reset", rd, 0);
    // the control core cannot fetch either: enabling it with a ring tail makes it fail with a fetch error (code 5)
    host_acc(1, CSR | 16'h02, 32'd1, 1'b1, 2'd0, rd, e);  // tail = 1 (legacy CSR, privileged)
    host_acc(1, CSR | 16'h01, 32'd1, 1'b1, 2'd0, rd, e);  // enable command processor
    begin int n = 0; do begin host_acc(0, CSR | 16'h04, 0, 1'b1, 2'd0, st, e); n++; end while (!st[1] && n < 400);
      check("S0 control core halts: command fetch denied by default (code 5)", {28'd0, st[11:8]}, 5); end
    clear_halt();
    host_acc(1, CSR | 16'h01, 32'd0, 1'b1, 2'd0, rd, e);  // disable again until configured
    host_acc(1, CSR | 16'h02, 32'd0, 1'b1, 2'd0, rd, e);
    // (head advanced past the failed fetch; reset the ring bookkeeping)
    ir(I_FQ_STATUS, rd); check("S0 denials were logged in the fault log", {31'd0, rd[7:0] != 8'd0}, 1);
    ext_expect_canary(0, 32768, "S0 external memory");

    // ---------- S1: boot configuration by the privileged host ----------
    $display("--- S1 configure domains: SYS (identity), CTL, tenants A and B");
    // reset to a clean IOMMU (fault log was filled by S0)
    @(posedge clk); #1 rst_n = 0; repeat (3) @(posedge clk); #1 rst_n = 1; repeat (3) @(posedge clk); tail = 0;
    iw(I_CTRL, 32'h1);
    ic_dom(D_SYS, 1, 1, 1); ic_dom(D_CTL, 1, 1, 0); ic_dom(D_A, 1, 1, 1); ic_dom(D_B, 1, 1, 1);
    for (int k = 0; k < 4; k++) ic_ent(k, D_SYS, k*16, k*16, 4, 1, 1);          // identity, 4 x 64 KiB
    ic_ent(4,  D_CTL, 0, 0,    0, 1, 0);                                         // control core: command RAM, read-only
    ic_ent(5,  D_A, 1, 12,    0, 1, 1);                                          // A: IOVA page1 -> scratchpad
    ic_ent(6,  D_A, 2, 32,    0, 1, 1);                                          // A: IOVA page2 -> ext PA page 0x20 (ext words 0x0000..)
    ic_ent(7,  D_A, 3, 33,    0, 1, 0);                                          // A: IOVA page3 -> ext PA page 0x21, READ-ONLY
    ic_ent(8,  D_A, 4, 40,    0, 1, 0);                                          // A: IOVA page4 -> shared read-only page 0x28
    ic_ent(9,  D_B, 1, 34,    0, 1, 1);                                          // B: IOVA page1 -> ext PA page 0x22 (ext words 0x0800..)
    ic_ent(10, D_B, 2, 35,    0, 1, 1);                                          // B: IOVA page2 -> ext PA page 0x23 (ext words 0x0C00..)
    ic_ent(11, D_B, 4, 40,    0, 1, 0);                                          // B: shared read-only page
    ic_ctx(0, 0, D_SYS); ic_ctx(0, 1, D_A); ic_ctx(0, 2, D_B);                   // host streams
    ic_ctx(1, 0, D_CTL);                                                         // control-core fetch
    ic_ctx(2, 0, D_A);                                                           // DMA engine currently serves tenant A
    // enable the command processor, load scratch with a known pattern as the hypervisor
    host_acc(1, CSR | 16'h01, 32'd1, 1'b1, 2'd0, rd, e);
    for (int i = 0; i < 64; i++) mw_w(16'h3000 + 16'(i), pat(1, i), 2'd0);
    for (int i = 0; i < 64; i++) begin mw_r(16'h3000 + 16'(i), 2'd0, rd); check("S1 hypervisor reads scratch", rd, pat(1, i)); end

    // ---------- S2: tenant A benign DMA ----------
    $display("--- S2 tenant A: legitimate DMA copy scratch -> external memory");
    run_dma(16'h0400, 16'h0800, 32, code); check("S2 DMA ok", 32'(code), 0);
    ext_expect_range(16'h0000, 32, 1, "S2 A's external page holds the copy");
    ext_expect_canary(16'h0800, 1024, "S2 tenant B's external page 0x22");
    ext_expect_canary(16'h0C00, 1024, "S2 tenant B's external page 0x23");
    run_dma(16'h0C00, 16'h0400, 8, code); check("S2 DMA reads from a read-only mapping", 32'(code), 0);

    // ---------- S3: tenant A attacks ----------
    $display("--- S3 tenant A attacks through the DMA engine");
    for (int i = 0; i < 16; i++) begin mw_r(16'(i), 2'd0, rd); cmdsave[i] = rd; end      // command ring as the hypervisor sees it
    run_dma(16'h0400, 16'h0000, 8, code);  check("S3a write to IOVA page 0 (command-RAM alias) denied -> DMA error", 32'(code), 6);
    run_dma(16'h0400, 16'h1400, 8, code);  check("S3b write to unmapped page denied", 32'(code), 6);
    run_dma(16'h0400, 16'h0C00, 8, code);  check("S3c write to read-only mapping denied", 32'(code), 6);
    ext_expect_canary(16'h0400, 1024, "S3c read-only page's backing memory");
    run_dma(16'h1800, 16'h0800, 8, code);  check("S3d read from unmapped page denied (exfiltration)", 32'(code), 6);
    run_dma(16'h1000, 16'h1000, 8, code);  check("S3e write to the shared read-only page denied", 32'(code), 6);
    ext_expect_canary(16'h2000, 1024, "S3e shared physical page");
    // copy that runs off the end of a writable mapping into a read-only one: per-beat page check
    run_dma(16'h0400 + 16, 16'h0800 + 1000, 40, code);                   // src words 16.. were not touched by S2
    check("S3f DMA running past its writable page is stopped at the boundary", 32'(code), 6);
    for (int i = 0; i < 24; i++) check("S3f words before the boundary were copied", extmem[1000 + i], pat(1, 16 + i));
    ext_expect_canary(16'h0400, 1024, "S3f page beyond the boundary");
    // the command ring itself must be intact (read as hypervisor)
    for (int i = 0; i < 4; i++) begin mw_r(16'(i), 2'd0, rd); check("S3 command ring word intact", rd, cmdsave[i]); end

    // ---------- S4: switch the DMA to tenant B ----------
    $display("--- S4 hypervisor rebinds the DMA engine to tenant B");
    ic_ctx_clr(2, 0); ic_ctx(2, 0, D_B);
    for (int i = 0; i < 32; i++) mw_w(16'h0800 + 16'(i), pat(2, i), 2'd2);              // B's host window (stream 2): IOVA page2 -> ext 0x23
    ext_expect_range(16'h0C00, 32, 2, "S4 B's host window wrote B's physical page");
    run_dma(16'h0800, 16'h0400, 32, code); check("S4 B's DMA ok", 32'(code), 0);
    ext_expect_range(16'h0800, 32, 2, "S4 B's copy landed in B's own page (ext 0x22)");
    ext_expect_range(16'h0000, 32, 1, "S4 A's data unchanged by B");
    run_dma(16'h0C00, 16'h0400, 8, code);  check("S4 B cannot read A's IOVA page 3 (unmapped in B)", 32'(code), 6);
    run_dma(16'h0400, 16'h0C00, 8, code);  check("S4 B cannot write IOVA page 3", 32'(code), 6);
    ext_expect_canary(16'h0400, 1024, "S4 A's read-only backing page");

    // ---------- S5: host window per stream ----------
    $display("--- S5 host memory window: per-stream isolation");
    mw(1, 16'h0400, 32'hDEAD_0001, 2'd1, rd, e); check("S5 stream 1 (A) writes its scratch page", {31'd0, e}, 0);
    mw_r(16'h3000, 2'd0, rd); check("S5 hypervisor sees A's write in scratch", rd, 32'hDEAD_0001);
    mw(1, 16'h0000, 32'hBAD0_BAD0, 2'd1, rd, e); check("S5 stream 1 cannot write the command RAM", {31'd0, e}, 1);
    mw(0, 16'h0000, 0, 2'd1, rd, e);             check("S5 stream 1 cannot read the command RAM", {31'd0, e}, 1);
    check("S5 denied read leaks nothing", rd, 0);
    mw(1, 16'h0400, 32'hDEAD_0002, 2'd2, rd, e); check("S5 same IOVA from stream 2 (B) lands in B's page", {31'd0, e}, 0);
    mw_r(16'h8800, 2'd0, rd); check("S5 ... at ext PA page 0x22 offset 0 (hypervisor view, fabric word 0x8800)", rd, 32'hDEAD_0002);
    mw_r(16'h3000, 2'd0, rd); check("S5 ... and A's scratch is untouched by B", rd, 32'hDEAD_0001);
    mw(1, 16'h3000, 32'h1, 2'd3, rd, e);         check("S5 unbound stream denied", {31'd0, e}, 1);
    host_acc(1, ICSR + 16'(I_CTRL), 32'h0, 1'b0, 2'd0, rd, e); check("S5 non-privileged disable rejected", {31'd0, e}, 1);
    ir(I_CTRL, rd); check("S5 IOMMU still enabled", rd[0], 1);
    // fault log content
    ir(I_FQ_STATUS, rd); check("S5 fault log non-empty", {31'd0, rd[7:0] != 0}, 1);
    iw(I_STG_CTX, 0);
    ir(I_SEL_PORT, rd);
    iw(I_SEL_PORT, 2); ir(I_PORT_OK, rd); $display("    DMA port granted=%0d", rd); ir(I_PORT_DENY, rd); $display("    DMA port denied=%0d", rd);
    check("S5 DMA port recorded denials", {31'd0, rd != 0}, 1);

    // ---------- S6: reset with a DMA in flight ----------
    $display("--- S6 reset with a DMA in flight");
    ic_ctx_clr(2, 0); ic_ctx(2, 0, D_A);
    for (int i = 0; i < 200; i++) mw_w(16'h0800 + 16'(i), pat(3, i), 2'd1);              // A's external page: IOVA page2
    enqueue(dma_cmd(200), 32'h0800, 32'h0400, 0);                                          // ext -> A's scratch (IOVA page1)
    doorbell();
    repeat (1200) @(posedge clk);
    @(posedge clk); #3 rst_n = 0; repeat (4) @(posedge clk);
    check("S6 DMA engine and IOMMU idle in reset", {31'd0, |dut.ds_cmd_valid}, 0);
    begin logic [31:0] snap [256];
      @(posedge clk); #1 rst_n = 1; repeat (4) @(posedge clk);
      for (int i = 0; i < 256; i++) snap[i] = dut.u_scratch.u_bank.mem[i];
      repeat (3000) @(posedge clk);                                                         // an unconfigured IOMMU must let nothing through
      begin int diff = 0; for (int i = 0; i < 256; i++) if (dut.u_scratch.u_bank.mem[i] !== snap[i]) diff++;
        check("S6 no write reaches the scratchpad after reset", 32'(diff), 0); end
    end
    mw(1, 16'h3000, 32'h5, 2'd0, rd, e); check("S6 host denied after reset (secure default)", {31'd0, e}, 1);
    tail = 0;
    ir(I_CTRL, rd); check("S6 IOMMU disabled after reset", rd, 0);

    // ---------- summary ----------
    repeat (10) @(posedge clk);
    check("physical writes were observed by the monitor (monitor is live)", 32'(phys_writes > 100), 1);
    check("no physical write without IOMMU authorisation", 32'(phys_viol), 0);
    $display("    physical write strobes observed: %0d, unauthorised: %0d", phys_writes, phys_viol);
    if (errors == 0) $display("TB_RESULT PASS checks=%0d", checks);
    else             $display("TB_RESULT FAIL errors=%0d checks=%0d", errors, checks);
    $finish;
  end

  initial begin
    #(TCLK * 3000000);
    $display("TB_RESULT FAIL errors=watchdog");
    $finish;
  end
endmodule
