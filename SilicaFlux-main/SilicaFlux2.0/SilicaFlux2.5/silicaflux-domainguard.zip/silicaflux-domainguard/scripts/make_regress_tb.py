#!/usr/bin/env python3
"""Generate tb/system/tb_regress_p40_dg.sv from the UNMODIFIED stand-in testbench.

Only three mechanical edits are made; no test logic is touched:
  1. module rename;
  2. the DUT (silicaflux_floorplan_wrapper) is replaced by the protected die top,
     with host_priv tied high and host_sid tied to 0;
  3. a boot step, dg_boot_identity(), is called after reset: it enables the IOMMU and
     identity-maps the whole 256 KiB address space for one system domain bound to all
     three masters ("fully trusted configuration"). Requests that the baseline expects
     to reach the fabric decode-error path (the 0x4000-0x7FFF hole) therefore still do.
"""
import re, sys, pathlib
src = pathlib.Path(sys.argv[1]).read_text()
out = pathlib.Path(sys.argv[2])

src = src.replace("module tb_silicaflux;", "module tb_regress_p40_dg;")

inst_start = src.index("`ifdef GATE_LEVEL")
inst_end = src.index(".tdo(tdo));", inst_start) + len(".tdo(tdo));")
new_inst = """  logic host_priv_s = 1'b1;
  logic [1:0] host_sid_s = 2'd0;
  silicaflux_dietop_dg #(.NV(NV), .NT(NT), .VBANK_DEPTH(VBANK_DEPTH),
    .TBANK_DEPTH(TBANK_DEPTH), .SCRATCH_DEPTH(SCRATCH_DEPTH)) dut (
    .clk(clk), .rst_n(rst_n), .test_mode(test_mode),
    .host_req(host_req), .host_we(host_we), .host_addr(host_addr), .host_wdata(host_wdata),
    .host_priv(host_priv_s), .host_sid(host_sid_s),
    .host_ack(host_ack), .host_rdata(host_rdata), .host_err(host_err),
    .ext_req(ext_req), .ext_we(ext_we), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
    .ext_ack(ext_ack), .ext_rdata(ext_rdata), .irq(irq), .therm_alert(therm_alert),
    .tck(tck), .tms(tms), .tdi(tdi), .trst_n(trst_n), .tdo(tdo));"""
src = src[:inst_start] + new_inst + src[inst_end:]

boot_task = """
  // ---- DomainGuard boot (the only addition): identity-map everything for domain 1 ----
  task automatic dg_boot_identity();
    logic [31:0] bst;
    // CTRL.enable
    hw(16'h4080 + 16'h04, 32'h1);
    // DOM_SET domain 1: enable, read, write
    hw(16'h4080 + 16'h0C, 32'h0701);  hw(16'h4080 + 16'h0D, 32'h0006);
    do hr(16'h4080 + 16'h05, bst); while (bst[0]);
    // four 64 KiB identity regions (order 4) cover IOVA/PA 0x00000-0x3FFFF
    for (int k = 0; k < 4; k++) begin
      hw(16'h4080 + 16'h08, 32'(k*16)); hw(16'h4080 + 16'h09, 32'(k*16));
      hw(16'h4080 + 16'h0A, 32'h0001_0403);
      hw(16'h4080 + 16'h0D, 32'((k << 8) | 1));
      do hr(16'h4080 + 16'h05, bst); while (bst[0]);
    end
    // bind host, control core and DMA (stream 0) to the system domain
    for (int p = 0; p < 3; p++) begin
      hw(16'h4080 + 16'h0B, 32'(p | (0 << 8) | (1 << 16)));
      hw(16'h4080 + 16'h0D, 32'(4));
      do hr(16'h4080 + 16'h05, bst); while (bst[0]);
    end
  endtask
"""
marker = "  // ---------------- test sequence ----------------"
assert marker in src
src = src.replace(marker, boot_task + "\n" + marker)

boot_call = "    #1 rst_n = 1; trst_n = 1;\n    repeat (5) @(posedge clk);\n"
assert boot_call in src
src = src.replace(boot_call, boot_call + "    dg_boot_identity();\n", 1)

# DomainGuard adds latency; keep the bounds proportional (baseline watchdog 400k cycles -> 4M)
src = src.replace("#(TCLK * 400000);", "#(TCLK * 4000000);")
out.write_text(src)
print("wrote", out)
