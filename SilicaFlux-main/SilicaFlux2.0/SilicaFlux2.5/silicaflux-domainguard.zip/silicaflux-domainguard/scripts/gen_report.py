#!/usr/bin/env python3
"""Generate docs/05_SECURITY_TESTING_REPORT.md from the logs in reports/.

Every number in the report is parsed from a log produced by `make all` / `make mutation`; nothing is typed in by hand.
usage: gen_report.py <project_root>
"""
import json, os, re, sys

root = sys.argv[1] if len(sys.argv) > 1 else "."
R = os.path.join(root, "reports")

def rd(name):
    p = os.path.join(R, name)
    return open(p, errors="replace").read() if os.path.exists(p) else ""

def must(m, what):
    if not m:
        raise SystemExit("cannot parse %s" % what)
    return m

fuzz = rd("fuzz.log"); unit = rd("unit.log"); system = rd("system.log"); regress = rd("regress.log")
audit = rd("audit.log"); lint = rd("lint.log"); formal = rd("formal.log"); cover = rd("cover.log")
mut = json.load(open(os.path.join(R, "mutation_results.json"))) if os.path.exists(os.path.join(R, "mutation_results.json")) else []

fz = re.search(r"fuzz: (\d+) commands accepted \((\d+) granted, (\d+) of them writes; (\d+) denied\), (\d+) responses, (\d+) downstream write beats checked", fuzz)
fz_checks = int(must(re.search(r"TB_RESULT PASS checks=(\d+)", fuzz), "fuzz TB result").group(1))
unit_checks = int(must(re.search(r"TB_RESULT PASS checks=(\d+)", unit), "unit TB result").group(1))
sys_checks = int(must(re.search(r"TB_RESULT PASS checks=(\d+)", system), "system TB result").group(1))
reg_checks = int(must(re.search(r"TB_RESULT PASS checks=(\d+)", regress), "regression TB result").group(1))
t8 = re.search(r"T8: (\d+) denials expected, (\d+) logged, (\d+) dropped on overflow; granted/denied per port: (\d+)/(\d+) (\d+)/(\d+) (\d+)/(\d+)", unit)
phys = re.search(r"physical write strobes observed: (\d+), unauthorised: (\d+)", system)
audit_pass = "BYPASS_AUDIT PASS" in audit
bits = re.search(r"fabric master request bits checked: (\d+)", audit)

synth = rd("synth_generic.log")
sm = re.search(r"Number of cells:\s+(\d+)", synth)
flops = sum(int(x) for x in re.findall(r"\$_\w*DFF\w*\s+(\d+)", synth.split("Number of cells")[-1])) if sm else 0
latch = len(re.findall(r"Latch inferred|\$_DLATCH", synth))

# formal
fcfg = {}
for m in re.finditer(r"formal: mode=prove depth=(\d+) config=(\w+).*?Status: (\w+).*?real\s+(\S+)", formal, re.S):
    fcfg[m.group(2)] = (m.group(1), m.group(3), m.group(4))
cov_ids = {}
for m in re.finditer(r":(\d+)\$(\d+)\) in step (\d+)", cover):      # "...svh:287$2903) in step 2."
    cov_ids[int(m.group(2))] = int(m.group(3))
cov_steps = [cov_ids[k] for k in sorted(cov_ids)]
cov_status = re.search(r"Status: (\w+)", cover)

COV_NAMES = [
 "C1  a granted WRITE command is issued downstream",
 "C2  a write data beat is accepted downstream",
 "C3  an error response is produced",
 "C4  a drain completes",
 "C5  a drain is *waiting* for an in-flight granted burst",
 "C6  a grant is produced against a real, non-empty table",
 "C7  a fault record is logged",
 "C8  the admin changes authority state",
]

EXPLAIN = {
 "M04": "Alignment is vacuous when a beat is one byte. With `DATA_W = 8` the formal configuration could not see this bug; both proof configurations now use `DATA_W = 16`.",
 "M10": "**Equivalent mutant.** The `&& d_grant` term is a redundant defence layer: the FSM already cannot enter ISSUE/SEND without a grant (proved on the *state*). Survival is expected and is the reason the property is stated on the state.",
 "M15": "Information-leak property (denied read returns zero) is a *data-path* property. It is verified by simulation only; the formal properties are about control (who may issue a downstream access), not data values.",
 "M18": "Commit-rule property (a valid slot may not be overwritten) is verified by simulation (T9). Without the rule the drain still protects in-flight bursts, so the formal safety properties are unaffected; the rule exists to keep the invalidate-then-wait protocol explicit.",
 "M16": "Survives every simulation test because it produces no externally visible misbehaviour: a port that is in CHECK evaluates the *already updated* table, and a port that has passed CHECK is already covered by the barrier through the ISSUE state. Formal property P6 (the drain protocol: *a drain ends only when no port is in CHECK or holds authority*) catches it. **I re-ran formal on this mutant with P6 disabled: P1–P5, P7 and the FSM invariants all still hold**, so this mutant weakens the drain protocol's conservatism, it does not let a stale authorisation through. (An earlier draft of this report described it as an escape; formal showed that was an overstatement.)",
 "M17": "Same class as M16: with P6 disabled, P1–P5, P7 and the FSM invariants still hold. Blocking new checks during a drain is what guarantees the drain **terminates** (no starvation by a busy port); isolation does not depend on it. Simulation catches it through T6a (a request issued during a drain must be held).",
 "M21": "A stale grant flag is functionally masked (the flag is overwritten at CHECK before it is used). It is a hygiene invariant that the FSM proof checks and simulation cannot observe.",
 "M22": "Total bypass in the integration. Caught by the structural audit and by the system testbench.",
}

out = []
w = out.append
w("# DomainGuard — security testing report\n")
w("SilicaFlux Module 97. **Generated by `scripts/gen_report.py` from the logs in `reports/`; every number below is parsed from a run, none is typed in.**\n")
w("Environment: Verilator 5.020, Yosys 0.33, `yosys-smtbmc` with cvc5 1.1.2. Logs: `reports/*.log`.\n")

w("## 1. Summary\n")
w("| Layer | What it shows | Result |")
w("|---|---|---|")
w("| Lint | `verilator -Wall` clean on the core at default, degenerate and wide (64-bit data, 40-bit PA) parameters, on both adapters; Yosys elaborates the core | %s |" % ("clean" if lint.count("clean") >= 6 else "**see lint.log**"))
w("| Synthesis (generic) | `synth -flatten` + `check -assert` at the die configuration (3 ports, 8 domains, 4 streams, 16 entries, 18-bit IOVA/PA, 32-bit data, 16-beat bursts); no technology library | %s cells, %s flip-flops, %d latches |" % (format(int(sm.group(1)), ",") if sm else "?", format(flops, ",") if sm else "?", latch))
w("| Unit adversarial testbench | oracle + downstream gate + canary image + response checks | **PASS**, %s checks |" % format(unit_checks, ","))
w("| Protocol-violation fuzzer (hostile initiator) | every upstream signal random every cycle; oracle checks every downstream access and every response | **PASS**, %s checks; %s commands accepted (%s granted, %s denied), %s downstream write beats checked |" % (format(fz_checks, ","), format(int(fz.group(1)), ","), format(int(fz.group(2)), ","), format(int(fz.group(4)), ","), format(int(fz.group(6)), ",")))
w("| System testbench (protected die) | real DMA / host / control-core, physical-write monitor | **PASS**, %d checks; %s physical write strobes observed, **%s unauthorised** |" % (sys_checks, phys.group(1) if phys else "?", phys.group(2) if phys else "?"))
w("| Regression | the stand-in's *original* testbench, unchanged, identity-mapped | **PASS**, %d checks |" % reg_checks)
w("| Structural bypass audit | no netlist path from an initiator to the fabric except through the IOMMU | **%s** (%s fabric-master bits traced) |" % ("PASS" if audit_pass else "FAIL", bits.group(1) if bits else "?"))
fs = ", ".join("config %s: %s (k=%s, %s)" % (c, v[1], v[0], v[2]) for c, v in sorted(fcfg.items()))
w("| Formal | unbounded k-induction of P1–P8 + FSM invariants, two small configurations | %s |" % (fs or "**missing**"))
w("| Cover | proof is not vacuous | %s of 8 cover points reached (%s) |" % (len(cov_steps), "Status: " + cov_status.group(1) if cov_status else "?"))
if mut:
    n = len(mut)
    ks = sum(1 for r in mut if r.get("sim") == "KILLED" or r.get("formal") == "KILLED" or r.get("audit") == "KILLED")
    w("| Mutation | %d planted bugs, one at a time | **%d detected** by at least one layer; survivors explained in §8 |" % (n, ks))
w("")

w("## 2. How the testing avoids marking its own homework\n")
w("""A single testbench written by the author of the RTL can share the author's misconceptions. Four things reduce that risk; none removes it.

1. **Independent oracle.** `model_decide` in the unit TB re-implements the policy with plain integer arithmetic on page ranges (no masks, no shifts), from the specification, not from the RTL.
2. **Interface gate, not just data compare.** The downstream memory agent accepts a command *only if the oracle authorised it* (address, direction, length, tid). A leak from a denied burst fails at the interface even if the data would never have been observed.
3. **Canary image.** Physical memory starts filled with an address-derived pattern; after every test the whole image is compared with a golden image that only authorised writes updated.
4. **Mutation.** Planted bugs show whether the checks can fail at all (§8).

The oracle and the RTL were written by the same author; the formal properties (P1 in particular) use a third formulation (shift-based, existential). They agree on every run.
""")

w("## 3. The required adversarial scenarios\n")
w("| Scenario | Unit TB | System TB | What is asserted |")
w("|---|---|---|---|")
w("| Tenant A accesses tenant B's memory | T2, T8 | S3, S4, S5 | same IOVA lands in different PA per domain; B-only IOVAs and B's PA used as IOVA are `UNMAPPED`; spoofed/out-of-range/other-port streams are `NO_CTX`; B's physical pages stay canary; fault log records domain/port/stream/IOVA |")
w("| DMA writes to read-only mappings | T3 | S3c, S3e | `PERM_W`, no downstream command, backing page canary intact; domain write-cap off; guard page faults as permission |")
w("| DMA accesses unmapped memory | T4 | S3a, S3b, S3d | writes and reads, page just below/after mappings, top of address space; read returns zero; **command-RAM alias is unmapped for tenants** (control-flow hijack blocked) |")
w("| Requests cross page boundaries | T5 | S3f | exact-fit succeeds; one-beat overrun denied even if the next page is mapped RW/RO; region interior crossing denied; per-word DMA stops at the boundary |")
w("| Mappings change during operation | T6a–g | S4 | invalidate / remap / re-bind / disable / global-disable **while a granted burst is in flight**; drain holds new checks, in-flight burst completes, later request denied, `busy` semantics, command during drain refused |")
w("| Reset occurs with pending requests | T7a–e | S6 | asynchronous reset in SEND, mid-collect, with a response pending, and mid-drain; outputs inert immediately; no zombie burst; defaults restored; full recovery |")
w("| Multiple domains generate traffic concurrently | T8 | S2–S5 | 3 ports × 4 backpressure phases × random classes of request incl. out-of-range / unbound streams; exact per-port and per-domain statistics; fault-log reconciliation |")
w("| Additional | T9, T10 | S0, S5 | privilege gating, all admin error codes, overlap/alignment/busy, fault log order/overflow/irq, stalled initiator, W-before-command, downstream error propagation |")
w("")

w("## 4. Simulation results\n")
w("### 4.1 Unit testbench (`tb/unit`, 3 ports, 8 domains, 3 streams, 16 entries, 24-bit IOVA, 22-bit PA, 32-bit data, 16-beat bursts)\n")
w("* **%s checks, 0 failures.**" % format(unit_checks, ","))
if t8:
    d, lg, dr = int(t8.group(1)), int(t8.group(2)), int(t8.group(3))
    pk = [int(t8.group(i)) for i in range(4, 10)]
    w("* T8 (concurrent random traffic): %d denials expected by the oracle, %d found in the fault log, %d counted as overflow drops (unlogged = drops, exactly); per-port granted/denied: port0 %d/%d, port1 %d/%d, port2 %d/%d." % (d, lg, dr, *pk))
w("* downstream gate: **0** unauthorised downstream commands or write beats in any test.")
w("* idle-wire monitor: `ds_w_data/strb` are zero whenever `ds_w_valid = 0` in every cycle of every test.\n")
w("### 4.1b Protocol-violation fuzzer (`tb/unit/tb_dg_fuzz.sv`, same configuration)\n")
w("The unit TB's initiators are well-behaved; the threat model's are not. The fuzzer drives **every** upstream signal randomly on every cycle (valid rising and dropping at will, data with or without a command, random tid / stream id / address class / length, random response back-pressure) and hammers the CSR bus with random **unprivileged** accesses, in three phases (moderate, dense, downstream-starved).\n")
w("Checked every cycle: a downstream command exists only for an *accepted* command that the oracle grants, exactly once, with the oracle's PA/direction/length/tid; a write is issued only after all its data was accepted; downstream data and strobes equal what was accepted; no write beat without an issued command or beyond `len`; the DUT never accepts a W beat without a pending write command; every accepted command gets exactly one response with correct tid/direction/`err = !grant`/last/beat-count and zero data when denied; the CSR hammering never changes the configuration.\n")
w("* **%s checks, 0 failures**; %s commands accepted (%s granted of which %s writes, %s denied), %s responses, %s downstream write beats checked.\n" % (format(fz_checks, ","), format(int(fz.group(1)), ","), format(int(fz.group(2)), ","), format(int(fz.group(3)), ","), format(int(fz.group(4)), ","), format(int(fz.group(5)), ","), format(int(fz.group(6)), ",")))
w("* While developing it, the fuzzer reported a disagreement that turned out to be a fuzzer bug that exposes a design property: its driver had issued a write to the *unconfigured* unit and withheld the data; the DUT correctly sat in `COLLECT`, and after configuration judged the command by the **new** table when the data finally arrived (decision at CHECK time, `03_ADDRESS_TRANSLATION_SPEC.md` §7). The oracle had assumed the decision was fixed at acceptance.\n")
w("### 4.2 System testbench (`tb/system`, protected die)\n")
if phys:
    w("* **%d checks, 0 failures.** The physical-write monitor observed **%s write strobes** at the real memories (external memory port, scratchpad SRAM, command-RAM SRAM); **%s** were not covered by a downstream write burst issued by the IOMMU." % (sys_checks, phys.group(1), phys.group(2)))
w("* the monitor is live: it also sees every legitimate write (a monitor that sees nothing proves nothing).\n")
w("### 4.3 Regression of the stand-in's original testbench\n")
w("* `third_party/p40_standin/tb/tb_silicaflux.sv` is patched only mechanically by `scripts/make_regress_tb.py` (module rename, DUT instance, one boot call that identity-maps all 64 pages for a system domain bound to all three masters).")
w("* **%d / %d checks pass**, i.e. with a fully trusted configuration DomainGuard is functionally transparent: CSRs, scratchpad and external memory, fabric decode errors (the unmapped `0x4000–0x7FFF` hole still reaches the fabric), every vector op, DMA plus tensor matmul, error paths, power gating, thermal throttling, external-memory watchdog, JTAG status.\n" % (reg_checks, reg_checks))

w("## 5. Structural bypass audit\n")
w("```\n" + audit.strip() + "\n```\n")
w("The audit reads the elaborated hierarchy (Yosys JSON, no flattening) and traces every fabric master-side request bit to its driver. It is validated by mutation M22.\n")

w("## 6. Formal verification\n")
w("""Tooling: Yosys front-end (`read_verilog -formal`, `prep`, `async2sync`, `write_smt2`) and `yosys-smtbmc` with **cvc5 1.1.2** (what SymbiYosys would do for its smtbmc engine; SBY itself was not used). Z3 4.8.12 (the apt version) **hangs while loading the Yosys transition-relation encoding of this design** even at depth 1, so it was not usable; this is a solver/encoding interaction, not a property of the design.

**Environment (what the solver is free to do):** every primary input is unconstrained on every cycle: the entire upstream side (arbitrary commands, data, `valid` toggling, protocol violations), the downstream side, and the CSR bus (any address, data, privileged or not). The only assumption is *reset asserted in the first cycle*.

| ID | Property | Kind |
|---|---|---|
| P1 | **Grant soundness.** Whenever the checker grants, an independent shift-based re-derivation from the raw tables finds a valid entry of the *bound* domain that covers the burst, permits the direction, and yields exactly the granted PA; also: global/domain enabled, beat-aligned, burst inside one 4 KiB page, page offset preserved | combinational, holds for **arbitrary** table state |
| P2 | Authority state (enable, caps, bindings, entries) changes **only** on a privileged CSR write | inductive |
| P3 | Table well-formedness: order ≤ MAX, natural alignment, domain in range, **no overlap** of same-domain entries | inductive |
| P4 | **Stale-translation invariant.** Outside a drain, every burst holding authority is still backed by the unchanged entry/domain/binding/flags it was granted under | inductive (ghost record captured at CHECK) |
| P5 | **Protected-memory theorem.** A downstream command or accepted write beat belongs to a burst granted for that direction, with the entry's and domain's permission, under an entry of the bound domain, and lands in the physical region that entry maps | inductive, uses P1+P3 |
| P6 | Drain: a check never starts during a drain; a drain ends only when no port holds authority | inductive |
| P7 | Reset: deny-all state, interface inert | combinational |
| P8 | A granted burst never leaves its page | part of P1 |
| FSM | `ds_cmd_valid`, `ds_w_valid`, `ds_r_ready` imply the post-grant states *and* `d_grant`; every post-check state implies a grant; the deny path never holds one; counters stay inside the burst | inductive, stated on the **state** so it survives removal of the redundant gating |
""")
w("### 6.1 Results\n")
w("| Configuration | Shape | Result |")
w("|---|---|---|")
shape = {"A": "2 ports, 2 domains, 1 stream (stream 1 is out-of-range), 2 entries, 14-bit IOVA/PA, 16-bit data, ≤2-beat bursts, order ≤ 1",
         "B": "2 ports, 3 domains, 2 streams, 3 entries (non-power-of-two), 14-bit IOVA/PA, 16-bit data, ≤2-beat bursts, order ≤ 1"}
for c in sorted(fcfg):
    v = fcfg[c]
    w("| %s | %s | **%s** by k-induction, k = %s (%s) |" % (c, shape.get(c, ""), v[1], v[0], v[2]))
w("")
w("A third shape (4 domains, 4 entries, 16-bit IOVA/PA, 8-bit data) did **not** finish within 25 minutes under cvc5 and is not claimed.\n")
w("### 6.2 Cover points (non-vacuity)\n")
w("The cover run uses a guided 9-cycle admin bring-up assumed on the CSR bus, then leaves the CSR bus and all data-path inputs free. It is used **only** for covers, never for proofs.\n")
w("| Cover | Reached at step |")
w("|---|---|")
for i, nme in enumerate(COV_NAMES):
    w("| %s | %s |" % (nme, cov_steps[i] if i < len(cov_steps) else "**not reached**"))
w("")
w("### 6.3 What the formal work does **not** establish\n")
w("""* **Scale.** The proofs are for the two small configurations above. The production-sized configuration (16 entries, 32-bit IOVA, 40-bit PA, 32/64-bit data, 16-beat bursts) is covered by simulation only. The RTL is generate-based and parameterised, so the small-scope result is strong evidence, not proof, for the larger instance.
* **Data values.** P1–P8 are about *who may issue a downstream access*; they say nothing about the data on it (e.g. that a denied read returns zeros, that write data is delivered intact). Those are simulation checks.
* **Liveness.** No proof that an allowed request is eventually granted, or that a drain terminates. (Simulation exercises both; a downstream that never responds would stall by assumption S3.)
* **Fault-log and CSR read-back content.**
* **Integration.** The die top is verified structurally (audit) and by simulation, not formally.
""")

w("## 7. Defects found and what they were\n")
w("""Reported plainly, including mistakes in the verification code itself.

**Design weaknesses identified in review and corrected before the first full regression**

* *Ready outputs were high while in reset* (the async-cleared FSM sits in IDLE), so an initiator could believe a command was accepted during reset. The ready outputs are now gated by `rst_n`; checked by T7 and formal property P7.
* *Fault-log drop count was exposed as 8 bits*, which a long hostile run would wrap, understating evidence loss. Widened to 16 bits (`FQ_STATUS[31:16]`).

**Findings from the verification run itself**

* No functional defect was found in the RTL by the unit/system testbenches once the testbenches' own bugs were fixed. Those bugs were all on the verification side: a driver that did not reset its beat counter between the data and response phases; golden-image bytes saved *after* instead of before submission; two test addresses that collided with legitimately-mapped pages (`PA_B_2`/`IOVA_RW` and a hypervisor read in the command-RAM decode range); the expectation that a 9-denial test would not overflow an 8-deep log (the correct invariant, *unlogged denials = counted drops*, is now used everywhere).
* *Formal:* the first induction runs failed because the invariants were too weak (an unreachable pre-state with a stale `d_deny`; P5 needed a **state-form** invariant linking the registered PA to the ghost record, and P1+P3 as lemmas). Strengthened; no RTL change needed.
* *Cover C1* was badly written (it asked for `ds_cmd_valid` and `ds_w_valid` simultaneously, which the FSM makes mutually exclusive); rewritten as "a write command is issued downstream".
* *Claim correction (M16/M17).* I first described mutant M16 as "an old authorisation escapes the drain barrier". Formal reported only the drain-protocol property P6; re-running it with P6 disabled showed every isolation property still holds, so the description was an overstatement and was corrected (§8). The same check was done for M17.
* *Mutation M04* (alignment) first survived formal because 8-bit data makes alignment vacuous; proof configurations now use 16-bit data.
* *Tooling:* the Z3 hang (§6); and a Verilator 5.020 run that crashed (SIGILL inside a forked coroutine) when the random-traffic generators were started with `fork … join` — they were moved to module-level processes.
""")

w("## 8. Mutation testing\n")
if mut:
    w("Each row plants ONE bug into a private copy of the RTL (`scripts/mutate.py`), then runs the whole unit testbench and the formal proofs (configuration A, k = 2). M22 (integration bypass) is checked by the structural audit and the system testbench.\n")
    w("Logs: `reports/mutation_run1_sim_and_formal.log` is the full first run (simulation + formal with 8-bit data). `reports/mutation_run2_formal_16bit.log` is a formal-only re-run with the corrected 16-bit-data configuration that reuses run 1's simulation verdicts (`--reuse-sim`); the table below merges them. The only formal verdict that changed between the runs is M04 (§7).\n")
    w("| ID | Planted bug | Simulation | Formal | Verdict |")
    w("|---|---|---|---|---|")
    for r in mut:
        if r["id"] == "M22":
            sim = "KILLED (%s checks failed)" % r.get("sim_fails", "?") if r.get("sim") == "KILLED" else r.get("sim", "?")
            frm = "audit: %s" % r.get("audit", "?")
            v = "detected" if (r.get("sim") == "KILLED" or r.get("audit") == "KILLED") else "**SURVIVED**"
        else:
            sim = ("killed (%s failures)" % r.get("sim_fails", "?")) if r.get("sim") == "KILLED" else r.get("sim", "?")
            if r.get("formal") == "KILLED":
                frm = "killed (%s)" % ", ".join(r.get("formal_props", ["?"]))
            else:
                frm = r.get("formal", "-")
            v = "detected" if (r.get("sim") == "KILLED" or r.get("formal") == "KILLED") else "**survived**"
        w("| %s | %s | %s | %s | %s |" % (r["id"], r["desc"], sim, frm, v))
    w("")
    both = [r["id"] for r in mut if r.get("sim") == "KILLED" and r.get("formal") == "KILLED"]
    simonly = [r["id"] for r in mut if r.get("sim") == "KILLED" and r.get("formal") != "KILLED" and r["id"] != "M22"]
    formalonly = [r["id"] for r in mut if r.get("sim") != "KILLED" and r.get("formal") == "KILLED"]
    surv = [r["id"] for r in mut if r.get("sim") != "KILLED" and r.get("formal") != "KILLED" and r.get("audit") != "KILLED"]
    w("* detected by **both** simulation and formal: %s" % (", ".join(both) or "none"))
    w("* detected by simulation only: %s" % (", ".join(simonly) or "none"))
    w("* detected by formal only: %s" % (", ".join(formalonly) or "none"))
    w("* **survived everything: %s**\n" % (", ".join(surv) or "none"))
    w("**Notes on the layers that did not catch a bug**\n")
    for r in mut:
        if r["id"] in EXPLAIN and (r.get("sim") != "KILLED" or r.get("formal") != "KILLED" or r["id"] in ("M17", "M22")):
            w("* **%s** — %s" % (r["id"], EXPLAIN[r["id"]]))
    w("")
else:
    w("_Mutation results not present; run `make mutation`._\n")

w("## 9. Limitations of this evidence\n")
w("""* One author wrote the RTL, the oracle and the properties.
* Unit simulation is at one parameter point; other points are lint/elaboration-checked and covered by small formal configurations only.
* Formal scope as in §6.3.
* The stand-in die is not the real DieTop; the structural audit must be re-run on the real top.
* No gate-level, power, timing, DFT or physical-design evidence for the new RTL. (The stand-in flow's own physical-design results do not include DomainGuard.)
* Side channels and availability attacks are outside the model (threat model §6).
* Evidence is for this exact tool set; no second simulator or solver was used.
""")

w("## 10. Reproduce\n")
w("```bash\nmake all        # lint, sim-unit, sim-system, sim-regress, audit, formal, cover  -> reports/*.log\nmake mutation   # ~25 min                                                   -> reports/mutation_results.json\npython3 scripts/gen_report.py .   # regenerates this report from the logs\n```")

open(os.path.join(root, "docs/05_SECURITY_TESTING_REPORT.md"), "w").write("\n".join(out) + "\n")
print("wrote docs/05_SECURITY_TESTING_REPORT.md")
