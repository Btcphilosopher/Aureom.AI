#!/usr/bin/env python3
"""DomainGuard mutation testing.

Each mutant is ONE planted security-relevant bug applied to a private copy of the RTL.
For every mutant we run
  (a) the adversarial unit testbench (Verilator)            -> "sim killed" if TB_RESULT != PASS
  (b) the formal proofs on the small configuration
      (yosys + yosys-smtbmc + cvc5, k-induction, k=2)         -> "formal killed" if any property fails
and report the matrix. Survivors are NOT hidden; each survivor is classified in the report.

usage: mutate.py <project_root> <workdir> [--jobs N] [--only M01,M02] [--no-formal]
"""
import argparse, concurrent.futures as cf, json, os, re, shutil, subprocess, sys, time

MUTANTS = [
 # id, file, [(old,new),...], description, expectation
 ("M01","xlate",[("perm_ok = we ? (ent_w[hit_idx] && dom_wr[dom]) : (ent_r[hit_idx] && dom_rd[dom]);",
                  "perm_ok = we ? (ent_r[hit_idx] && dom_rd[dom]) : (ent_r[hit_idx] && dom_rd[dom]);")],
  "writes permitted by READ permission (RO mappings become writable)","kill"),
 ("M02","xlate",[("(ent_dom[e*DOM_W +: DOM_W] == dom) &&","1'b1 &&")],
  "entry domain tag ignored in lookup (tenant A can use tenant B's entries)","kill"),
 ("M03","xlate",[("crosses = (end_sum > SUM_W'(4096));","crosses = 1'b0;")],
  "4 KiB page-crossing check removed","kill"),
 ("M04","xlate",[("for (int b = 0; b < BEAT_SHIFT; b++) if (iova[b]) misaligned = 1'b1;","misaligned = 1'b0;")],
  "beat-alignment check removed","kill"),
 ("M05","xlate",[("else if (!dom_en[dom])    fault = `SF_DG_F_DISABLED;","else if (1'b0)    fault = `SF_DG_F_DISABLED;")],
  "per-domain enable ignored (disabled tenant keeps access)","kill"),
 ("M06","xlate",[("if      (!glob_en)        fault = `SF_DG_F_DISABLED;","if (1'b0)        fault = `SF_DG_F_DISABLED;")],
  "global enable ignored","kill"),
 ("M07","xlate",[("ppn_sel = (e_ppn & ~om_p) | (PPN_W'(ipn) & om_p);","ppn_sel = e_ppn;")],
  "region translation drops the page index inside the region (wrong physical page)","kill"),
 ("M08","xlate",[("dom_v  = sid_ok && ctx_valid[sid_i];","dom_v  = sid_ok;")],
  "unbound (port,stream) resolves to domain 0 instead of faulting","kill"),
 ("M09","port",[("if (chk_grant) st <= ST_ISSUE;","if (1'b1) st <= ST_ISSUE;"),
                ("assign ds_cmd_valid = (st == ST_ISSUE) && d_grant;","assign ds_cmd_valid = (st == ST_ISSUE);"),
                ("assign ds_w_valid   = (st == ST_SEND) && d_grant && c_we;","assign ds_w_valid   = (st == ST_SEND) && c_we;")],
  "deny path wired into ISSUE and the grant gating removed (denied writes reach downstream)","kill"),
 ("M10","port",[("assign ds_cmd_valid = (st == ST_ISSUE) && d_grant;","assign ds_cmd_valid = (st == ST_ISSUE);"),
                ("assign ds_w_valid   = (st == ST_SEND) && d_grant && c_we;","assign ds_w_valid   = (st == ST_SEND) && c_we;")],
  "redundant `&& d_grant` gating removed (FSM alone still guarantees safety)","equivalent"),
 ("M11","iommu",[("if (op_do || ctrl_dis) blk <= 1'b1;","if (1'b0) blk <= 1'b1;")],
  "no drain after invalidation (stale in-flight authorisations survive)","kill"),
 ("M12","iommu",[("wr = csr_valid && csr_we && csr_priv;","wr = csr_valid && csr_we;")],
  "privilege qualifier ignored on admin writes","kill"),
 ("M13","iommu",[("ent_overlap = 1'b1;","ent_overlap = 1'b0;")],
  "overlap check at commit removed","kill"),
 ("M14","iommu",[("ent_valid  <= '0;","ent_valid  <= '1;")],
  "reset leaves every translation entry valid (insecure reset)","kill"),
 ("M15","port",[("assign us_r_data    = (c_we || d_deny) ? '0 : bdata[cnt];","assign us_r_data    = c_we ? '0 : bdata[cnt];")],
  "denied read returns stale buffer contents (information leak)","kill-sim"),
 ("M16","iommu",[("else if (blk && !act_any) blk <= 1'b0;","else if (blk && !(|p_auth)) blk <= 1'b0;")],
  "drain barrier ignores a port that is in its CHECK cycle (weakens the drain protocol; isolation properties still hold)","kill-formal"),
 ("M17","port",[("ST_WAITCHK: if (!chk_blk) st <= ST_CHECK;","ST_WAITCHK: st <= ST_CHECK;")],
  "new checks may start while a drain is in progress (drain can be starved; isolation properties still hold)","kill"),
 ("M18","iommu",[("else if (ent_valid[eidx])                               cmd_err = `SF_DG_E_BUSY;","else if (1'b0)                               cmd_err = `SF_DG_E_BUSY;")],
  "entries may be overwritten in place (no invalidate-first rule)","kill-sim"),
 ("M19","iommu",[("if (op_do || ctrl_dis) blk <= 1'b1;","if (op_do) blk <= 1'b1;")],
  "global disable does not drain","kill"),
 ("M20","xlate",[("if (!hit && ent_valid[e] && dom_v &&","if (!hit && dom_v &&")],
  "invalidated entries still match","kill"),
 ("M21","port",[("          d_grant <= 1'b0;          // no stale authorisation survives into a new burst\n","")],
  "grant flag never cleared at a new command (stale grant hygiene; functionally masked by the CHECK overwrite)","kill-formal"),
]

BYPASS = ("M22","integration total bypass: all three masters wired straight to the fabric, IOMMU left in place but unused")

def sh(cmd, cwd=None, timeout=1800, env=None):
    p = subprocess.run(cmd, shell=True, cwd=cwd, capture_output=True, text=True, timeout=timeout, env=env)
    return p.returncode, p.stdout + p.stderr

def apply(path, edits):
    s = open(path).read()
    for old, new in edits:
        if s.count(old) != 1:
            raise SystemExit("mutant pattern not unique/missing in %s: %r (count=%d)" % (path, old[:70], s.count(old)))
        s = s.replace(old, new)
    open(path, "w").write(s)

def prop_label(src_file, lineno):
    try:
        lines = open(src_file).read().split("\n")
    except Exception:
        return "?"
    for i in range(min(lineno - 1, len(lines) - 1), -1, -1):
        m = re.search(r"//\s*----\s*(P\d)", lines[i])
        if m: return m.group(1)
        if "Formal: FSM-level invariants" in lines[i]: return "port-FSM"
    return "?"

def run_mutant(root, work, mid, fname, edits, desc, do_formal, prev=None):
    d = os.path.join(work, mid)
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(os.path.join(root, "rtl/dg"), os.path.join(d, "rtl"))
    apply(os.path.join(d, "rtl", {"xlate":"sf_albion_xlate.sv","port":"sf_albion_port.sv","iommu":"sf_albion_iommu.sv"}[fname]), edits)
    res = {"id": mid, "desc": desc}
    # ---- (a) simulation
    t0 = time.time()
    if prev is not None:
        for k in ("sim", "sim_fails", "sim_first", "sim_s"):
            if k in prev: res[k] = prev[k]
        rc, out = 0, ""
    if prev is None:
      rc, out = sh("verilator --binary --timing -Wno-fatal -Wno-WIDTH -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM "
                 "-Wno-CASEINCOMPLETE -Wno-TIMESCALEMOD --top-module tb_dg_unit -I%s/rtl -I%s/tb/unit "
                 "%s/rtl/sf_albion_xlate.sv %s/rtl/sf_albion_port.sv %s/rtl/sf_albion_iommu.sv %s/tb/unit/tb_dg_unit.sv "
                 "-Mdir %s/obj -o tb_unit" % (d, root, d, d, d, root, d), timeout=900)
    if prev is not None:
        pass
    elif rc != 0:
        res["sim"] = "BUILD-ERROR"; res["sim_detail"] = out[-300:]
    else:
        rc, out = sh("timeout 300 %s/obj/tb_unit" % d, timeout=400)
        m = re.search(r"TB_RESULT (PASS|FAIL)[^\n]*", out)
        fails = len(re.findall(r"\[FAIL\]", out))
        if m and m.group(1) == "PASS" and rc == 0:
            res["sim"] = "survived"
        else:
            res["sim"] = "KILLED"
        res["sim_fails"] = fails
        first = re.search(r"\[FAIL\] ([^\n(]*)", out)
        res["sim_first"] = first.group(1).strip() if first else (m.group(0) if m else "no result (crash/timeout)")
    if prev is None:
        res["sim_s"] = round(time.time() - t0)
    # ---- (b) formal
    if do_formal:
        t0 = time.time()
        env = dict(os.environ)
        env["WORK"] = os.path.join(d, "fwork")
        env["FORMAL_PARAMS"] = ("-chparam NUM_PORTS 2 -chparam NUM_DOMAINS 2 -chparam NUM_STREAMS 1 -chparam NUM_ENTRIES 2 "
                                "-chparam IOVA_W 14 -chparam PA_W 14 -chparam DATA_W 16 -chparam LEN_W 1 -chparam TID_W 1 "
                                "-chparam MAX_ORDER 1 -chparam FQ_DEPTH 1 -chparam CNT_W 1")
        try:
            rc, out = sh("%s/formal/run_formal.sh prove 2 %s/rtl mut" % (root, d), timeout=900, env=env)
            if "Status: PASSED" in out:
                res["formal"] = "survived"
            elif "Status: FAILED" in out or "Temporal induction failed" in out:
                res["formal"] = "KILLED"
                ms = re.findall(r"Assert failed in \S+: (\S+)", out)
                labs = []
                for tok in ms[:3]:
                    last = tok.split("|")[-1]          # "instance-location|assertion-location"
                    mm = re.match(r"(.*?):(\d+)\.\d+", last)
                    if mm:
                        labs.append(prop_label(mm.group(1), int(mm.group(2))))
                res["formal_props"] = sorted(set(labs)) if labs else ["?"]
            else:
                res["formal"] = "ERROR"; res["formal_detail"] = out[-300:]
        except subprocess.TimeoutExpired:
            res["formal"] = "TIMEOUT"
        res["formal_s"] = round(time.time() - t0)
    return res

def run_bypass(root, work):
    d = os.path.join(work, BYPASS[0])
    shutil.rmtree(d, ignore_errors=True)
    shutil.copytree(root, d, ignore=shutil.ignore_patterns("work*", "reports", "*.zip"))
    p = os.path.join(d, "rtl/integration/silicaflux_dietop_dg.sv")
    edits = [
     (".m_req_valid(r_req_valid[gm]), .m_req_ready(r_req_ready[gm]), .m_req_we(r_req_we[gm]),", ".m_req_valid(r_req_valid[gm]), .m_req_ready(), .m_req_we(r_req_we[gm]),"),
     (".m_rsp_valid(r_rsp_valid[gm]), .m_rsp_err(r_rsp_err[gm]), .m_rsp_rdata(r_rsp_rdata[gm*32 +: 32]),\n        .sid(", ".m_rsp_valid(), .m_rsp_err(), .m_rsp_rdata(),\n        .sid("),
     (".m_req_valid(m_req_valid[gm]), .m_req_ready(m_req_ready[gm]), .m_req_we(m_req_we[gm]),\n        .m_req_addr(m_req_addr[gm*16 +: 16]), .m_req_wdata(m_req_wdata[gm*32 +: 32]),",
      ".m_req_valid(), .m_req_ready(m_req_ready[gm]), .m_req_we(),\n        .m_req_addr(), .m_req_wdata(),"),
     ("  // ---------------- CSR bus ----------------",
      "  assign m_req_valid = r_req_valid; assign m_req_we = r_req_we; assign m_req_addr = r_req_addr; assign m_req_wdata = r_req_wdata;\n"
      "  assign r_req_ready = m_req_ready; assign r_rsp_valid = m_rsp_valid; assign r_rsp_err = m_rsp_err; assign r_rsp_rdata = m_rsp_rdata;\n"
      "  // ---------------- CSR bus ----------------"),
    ]
    # the m_rsp_* ports of dg2fm are inputs: keep them connected
    apply(p, [e for e in edits if True])
    res = {"id": BYPASS[0], "desc": BYPASS[1]}
    rc, out = sh("python3 scripts/audit_bypass.py . 2>&1 | tail -4", cwd=d)
    res["audit"] = "KILLED" if "BYPASS_AUDIT FAIL" in out else ("survived" if "BYPASS_AUDIT PASS" in out else "ERROR")
    res["audit_first"] = [l for l in out.split("\n") if "FAIL" in l][:1]
    rc, out = sh("bash -c 'cd %s && verilator --binary --timing -Wno-fatal -Wno-WIDTH -Wno-DECLFILENAME -Wno-UNUSEDSIGNAL -Wno-UNUSEDPARAM "
                 "-Wno-CASEINCOMPLETE -Wno-TIMESCALEMOD -Wno-PINCONNECTEMPTY -Wno-UNOPTFLAT -Wno-MULTIDRIVEN -Wno-IMPLICIT -Wno-SYNCASYNCNET "
                 "--top-module tb_dg_system -Irtl/dg -f scripts/system_filelist.f tb/system/tb_dg_system.sv -Mdir obj -o tb_sys > build.log 2>&1; echo $?'" % d, timeout=900)
    if rc != 0 or not out.strip().endswith("0"):
        res["sim"] = "BUILD-ERROR"
    else:
        rc, out = sh("timeout 300 ./obj/tb_sys", cwd=d, timeout=400)
        m = re.search(r"TB_RESULT (PASS|FAIL)", out)
        res["sim"] = "survived" if (m and m.group(1) == "PASS") else "KILLED"
        res["sim_fails"] = len(re.findall(r"\[FAIL\]", out))
        first = re.search(r"\[FAIL\] ([^\n(]*)", out)
        res["sim_first"] = first.group(1).strip() if first else ""
    return res

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("root"); ap.add_argument("work")
    ap.add_argument("--jobs", type=int, default=3)
    ap.add_argument("--only", default="")
    ap.add_argument("--no-formal", action="store_true")
    ap.add_argument("--reuse-sim", default="", help="JSON from an earlier run: keep its simulation verdicts, redo only the formal stage")
    a = ap.parse_args()
    root = os.path.abspath(a.root); work = os.path.abspath(a.work)
    os.makedirs(work, exist_ok=True)
    only = set(x for x in a.only.split(",") if x)
    jobs = [m for m in MUTANTS if not only or m[0] in only]
    prevs = {r["id"]: r for r in json.load(open(a.reuse_sim))} if a.reuse_sim else {}
    results = []
    with cf.ThreadPoolExecutor(max_workers=a.jobs) as ex:
        futs = {ex.submit(run_mutant, root, work, m[0], m[1], m[2], m[3], not a.no_formal, prevs.get(m[0])): m for m in jobs}
        if (not only or BYPASS[0] in only) and BYPASS[0] not in prevs:
            futs[ex.submit(run_bypass, root, work)] = (BYPASS[0], None, None, BYPASS[1], "kill")
        elif BYPASS[0] in prevs:
            results.append(dict(prevs[BYPASS[0]], expect="kill"))
        for f in cf.as_completed(futs):
            r = f.result(); m = futs[f]
            r["expect"] = m[4]
            results.append(r)
            print(json.dumps(r), flush=True)
    results.sort(key=lambda r: r["id"])
    json.dump(results, open(os.path.join(work, "mutation_results.json"), "w"), indent=1)

if __name__ == "__main__":
    main()
