#!/usr/bin/env python3
"""Structural bypass audit of silicaflux_dietop_dg.

Claim being checked: every data-fabric MASTER-side input (u_fabric.m_req_*) is driven,
bit for bit, by an instance of sf_dg_dg2fm (the adapter behind the IOMMU) and by nothing
else - in particular not by sf_dma, sf_host_if or sf_control_core. Conversely, every
request output of those three masters must be consumed only by an sf_dg_fm2dg input
adapter (and never reach the fabric or a slave directly).

Method: Yosys elaborates the hierarchy (no flatten) and writes a JSON netlist; this script
builds a bit-level driver/sink map for the top module and walks it. Wires that are pure
aliases collapse to the same net id in the JSON, so no textual matching is involved.
"""
import json, subprocess, sys, os, tempfile

root = sys.argv[1] if len(sys.argv) > 1 else "."
files = [l.strip() for l in open(os.path.join(root, "scripts/system_filelist.f")) if l.strip()]
files = [os.path.join(root, f) for f in files]
tmp = tempfile.mkdtemp()
js = os.path.join(tmp, "n.json")
cmd = ["yosys", "-q", "-p",
       "read_verilog -sv -I%s/rtl/dg %s; hierarchy -check -top silicaflux_dietop_dg; proc; opt_clean; write_json %s"
       % (root, " ".join(files), js)]
subprocess.run(cmd, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
nl = json.load(open(js))
mods = nl["modules"]
top = mods["silicaflux_dietop_dg"]

import re
def base(t):
    """$paramod$<hash>\\name\\P=.. / $paramod\\name\\P=.. -> name"""
    if t.startswith("$paramod"):
        m = re.search(r"\\([A-Za-z_][A-Za-z0-9_]*)", t)
        return m.group(1) if m else t
    return t

def port_dirs(modname):
    m = mods.get(modname)
    return {n: p["direction"] for n, p in m["ports"].items()} if m else {}

drivers = {}   # net bit -> list of (cell, type, port)
sinks = {}     # net bit -> list of (cell, type, port)
for cname, c in top["cells"].items():
    ctype = base(c["type"])
    dirs = port_dirs(c["type"])
    for pname, bits in c["connections"].items():
        d = dirs.get(pname, c.get("port_directions", {}).get(pname))
        for b in bits:
            if isinstance(b, str):
                continue
            (drivers if d == "output" else sinks).setdefault(b, []).append((cname, ctype, pname))
# top-level input ports are drivers too
for pn, p in top["ports"].items():
    for b in p["bits"]:
        if isinstance(b, int):
            (drivers if p["direction"] == "input" else sinks).setdefault(b, []).append(("<top>", "<port>", pn))

fab = [(n, c) for n, c in top["cells"].items() if base(c["type"]) == "sf_data_fabric"]
assert len(fab) == 1, "expected exactly one fabric instance"
fname, fcell = fab[0]
ok = True
report = []

# 1. every fabric master-side request input is driven only by sf_dg_dg2fm
n_bits = 0
for pname in ("m_req_valid", "m_req_we", "m_req_addr", "m_req_wdata"):
    for i, b in enumerate(fcell["connections"][pname]):
        n_bits += 1
        drv = drivers.get(b, [])
        types = {t for (_, t, _) in drv}
        if types != {"sf_dg_dg2fm"} or len(drv) != 1:
            ok = False
            report.append("FAIL fabric.%s[%d] driven by %s" % (pname, i, drv))
report.append("fabric master request bits checked: %d (m_req_valid/we/addr/wdata)" % n_bits)

# 2. master-side response/ready from the fabric go only to dg2fm
n2 = 0
for pname in ("m_req_ready", "m_rsp_valid", "m_rsp_err", "m_rsp_rdata"):
    for i, b in enumerate(fcell["connections"][pname]):
        n2 += 1
        snk = sinks.get(b, [])
        types = {t for (_, t, _) in snk}
        if not types <= {"sf_dg_dg2fm"}:
            ok = False
            report.append("FAIL fabric.%s[%d] feeds %s" % (pname, i, snk))
report.append("fabric master response bits checked: %d" % n2)

# 3. the three untrusted/semi-trusted masters feed ONLY sf_dg_fm2dg
masters = {"sf_dma": "u_dma", "sf_host_if": "u_host", "sf_control_core": "u_ctrl"}
for mtype, inst in masters.items():
    cells = [(n, c) for n, c in top["cells"].items() if base(c["type"]) == mtype]
    assert len(cells) == 1, "expected one %s" % mtype
    n, c = cells[0]
    for pname in ("m_req_valid", "m_req_we", "m_req_addr", "m_req_wdata"):
        for i, b in enumerate(c["connections"][pname]):
            snk = sinks.get(b, [])
            types = {t for (_, t, _) in snk}
            if types != {"sf_dg_fm2dg"}:
                ok = False
                report.append("FAIL %s.%s[%d] feeds %s" % (mtype, pname, i, snk))
    report.append("%s: request outputs feed only sf_dg_fm2dg" % mtype)

# 4. no slave-side or fabric input of any other class is driven by a master adapter's raw side
# 5. exactly three input adapters, three output adapters, one IOMMU
cnt = {}
for n, c in top["cells"].items():
    cnt[base(c["type"])] = cnt.get(base(c["type"]), 0) + 1
for t, want in (("sf_dg_fm2dg", 3), ("sf_dg_dg2fm", 3), ("sf_albion_iommu", 1)):
    if cnt.get(t, 0) != want:
        ok = False
        report.append("FAIL expected %d x %s, found %d" % (want, t, cnt.get(t, 0)))
report.append("instances: %s" % ", ".join("%s=%d" % (k, cnt[k]) for k in sorted(cnt) if k.startswith("sf_dg") or k == "sf_albion_iommu"))

# 6. CSR window: the IOMMU admin bus is reachable only from the host_if CSR output
iommu = [c for n, c in top["cells"].items() if base(c["type"]) == "sf_albion_iommu"][0]
for pname in ("csr_wdata",):
    for i, b in enumerate(iommu["connections"][pname]):
        drv = drivers.get(b, [])
        if {t for (_, t, _) in drv} != {"sf_host_if"}:
            ok = False
            report.append("FAIL IOMMU csr_wdata[%d] driven by %s" % (i, drv))
report.append("IOMMU admin CSR data bus is driven only by sf_host_if (not by any fabric master)")

print("\n".join(report))
print("BYPASS_AUDIT", "PASS" if ok else "FAIL")
sys.exit(0 if ok else 1)
