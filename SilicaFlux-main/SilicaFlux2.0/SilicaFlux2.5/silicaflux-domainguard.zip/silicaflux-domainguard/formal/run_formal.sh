#!/bin/bash
# DomainGuard formal driver: yosys (front-end) + yosys-smtbmc (BMC / k-induction / cover) + cvc5.
# This is what SymbiYosys does internally for its smtbmc engine; no SBY install is needed.
# (Z3 4.8.12 hangs while loading the Yosys transition-relation encoding of this design - see
#  docs/05_SECURITY_TESTING_REPORT.md - so cvc5 is the default solver.)
#
# usage: run_formal.sh <mode> <depth> [rtl_dir] [tag]
#   mode  bmc    bounded model check of all assertions                (depth = cycles)
#         prove  k-induction: base case + inductive step (unbounded)  (depth = k)
#         cover  reachability of every cover point, with the guided bring-up script
# env   CONFIG=A|B       proof configuration (default A)
#       FORMAL_PARAMS    explicit "-chparam ..." list (overrides CONFIG)
#       DEFS             extra Yosys defines (e.g. "-DF_SKIP_P5" to switch a property group off)
#       SOLVER           default cvc5      WORK  scratch dir (default ./work)
# exit  0 = proved / all covers reached; 1 = counterexample / unreached cover; 3 = elaboration failure
set -u
MODE=${1:-prove}; DEPTH=${2:-2}
HERE=$(cd "$(dirname "$0")" && pwd)
RTL=${3:-$HERE/../rtl/dg}; TAG=${4:-${CONFIG:-A}}
WORK=${WORK:-$HERE/work}; SOLVER=${SOLVER:-cvc5}
mkdir -p "$WORK"
case "${CONFIG:-A}" in
  A) CFG="-chparam NUM_PORTS 2 -chparam NUM_DOMAINS 2 -chparam NUM_STREAMS 1 -chparam NUM_ENTRIES 2 \
-chparam IOVA_W 14 -chparam PA_W 14 -chparam DATA_W 16 -chparam LEN_W 1 -chparam TID_W 1 \
-chparam MAX_ORDER 1 -chparam FQ_DEPTH 1 -chparam CNT_W 1" ;;
  B) CFG="-chparam NUM_PORTS 2 -chparam NUM_DOMAINS 3 -chparam NUM_STREAMS 2 -chparam NUM_ENTRIES 3 \
-chparam IOVA_W 14 -chparam PA_W 14 -chparam DATA_W 16 -chparam LEN_W 1 -chparam TID_W 1 \
-chparam MAX_ORDER 1 -chparam FQ_DEPTH 2 -chparam CNT_W 1" ;;
  *) echo "unknown CONFIG"; exit 2 ;;
esac
PARAMS=${FORMAL_PARAMS:-$CFG}
EXTRA=${DEFS:-}
FL=""
case "$MODE" in
  prove) FL="-i" ;;
  cover) FL="-c"
         [ -z "$EXTRA" ] && EXTRA="-DF_COVER_SCRIPT -DF_SKIP_P1 -DF_SKIP_P2 -DF_SKIP_P3 -DF_SKIP_P4 -DF_SKIP_P5 -DF_SKIP_P6 -DF_SKIP_P7" ;;
  bmc) FL="--presat" ;;
  *) echo "bad mode"; exit 2 ;;
esac
SMT2="$WORK/dg_${TAG}_${MODE}.smt2"
yosys -q -l "$WORK/dg_${TAG}_${MODE}_yosys.log" -p "
  read_verilog -formal -sv -DSF_DG_FORMAL $EXTRA -I$RTL $RTL/sf_albion_xlate.sv $RTL/sf_albion_port.sv $RTL/sf_albion_iommu.sv
  hierarchy -check -top sf_albion_iommu $PARAMS
  prep -flatten -nordff -top sf_albion_iommu
  async2sync
  dffunmap
  opt_clean
  write_smt2 -wires $SMT2" > /dev/null 2>&1 || { echo "FORMAL_ELAB_FAIL"; exit 3; }
echo "formal: mode=$MODE depth=$DEPTH config=${CONFIG:-A} solver=$SOLVER"
yosys-smtbmc -s "$SOLVER" $FL -t "$DEPTH" "$SMT2"
