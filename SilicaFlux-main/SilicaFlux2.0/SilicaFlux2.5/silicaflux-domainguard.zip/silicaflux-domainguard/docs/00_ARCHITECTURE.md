# DomainGuard — architecture and DMA-path analysis

SilicaFlux Module 97 · primary module `rtl/dg/sf_albion_iommu.sv`

DomainGuard is a synthesizable memory-isolation and DMA address-translation unit. It sits between
every bus initiator and the data fabric, translates an initiator-visible IO virtual address (IOVA)
to a physical address (PA), and refuses everything that is not explicitly mapped and permitted.

> **What it is not.** It is a simple, flat, register-based translation unit. It is **not** a RISC-V
> IOMMU and must not be described as compliant with the RISC-V IOMMU specification (see
> `03_ADDRESS_TRANSLATION_SPEC.md` §9 for the list of what is absent).

---

## 1. Inspection of the existing design

Source inspected: `silicaflux-p40-floorplanbuild.zip` (SilicaFlux Project 40), `rtl/standin/*`.
The integrated DieTop of Projects 31–39 is not present in that archive either, so the "DieTop" there
is a stand-in; the analysis below is of that stand-in, and the integration pattern (§3) is what
transfers to the real DieTop. SHA-256 of every inspected file is recorded in
`third_party/p40_standin/FILES.sha256`.

### 1.1 Everything that can originate a data-fabric transaction

`sf_data_fabric` has `NM = 3` master ports (`M_HOST = 0`, `M_CTRL = 1`, `M_DMA = 2`) and
`NS = NV + NT + 3` slave ports. There is no other master. The vector and tensor clusters are *slaves*
(their private banks are only reachable through the fabric or by their own engine).

| Master | Block | What drives its address / data | Reaches (before DomainGuard) | Untrusted input? |
|---|---|---|---|---|
| 0 `M_HOST` | `sf_host_if` memory window (`host_addr[15:12] != 4'h4`) | the host port pins, verbatim, no requester identity | **every slave**: command RAM, vector banks, tensor banks, scratchpad, external memory | **yes** – any host-side agent, including a tenant's driver/VF |
| 1 `M_CTRL` | `sf_control_core` command fetch | `{10'd0, head[3:0], wi}`; `we` is constant 0 | command RAM, read only, by construction | content of what it fetches is untrusted; the fetch address is not |
| 2 `M_DMA` | `sf_dma` | `src`, `dst`, `len` are 16-bit fields **copied straight from words of the command ring** (`dma_src = w1[15:0]`, `dma_dst = w2[15:0]`, `dma_len = w0[15:0]`) | **every slave**, read and write | **yes** – whoever can write the command ring |

Findings that motivate the design:

1. **The DMA engine is unrestricted.** Its source and destination come from software-writable command
   words and go to the fabric unchecked. A DMA can write the **command RAM** — the control core's own
   instruction ring — which is a control-flow hijack, and can read or write every other tenant's
   banks, scratchpad and external memory.
2. **Both writable masters (host window, DMA) carry no identity.** The fabric cannot tell tenants apart.
3. **The CSR window never touches the fabric.** `sf_host_if` routes `host_addr[15:12] == 4'h4` to a
   dedicated single-cycle CSR bus, so register state cannot be reached by any fabric master. This is
   the property that lets the admin interface be isolated from DMA by construction. (It is a
   property to *preserve*; DomainGuard keeps it.)
4. **Address decode aliasing.** The existing CSR decode uses only `csr_addr[7:0]`; bits `[11:8]` of
   the window address are ignored, so `0x4000–0x4FFF` alias one 256-word space. DomainGuard places its
   registers at `0x4080–0x40FF` (word offsets `0x80–0xFF`), above all existing registers
   (`< 0x10`).
5. **Slaves check only their own bounds** (e.g. `sf_scratchpad` rejects words ≥ `DEPTH`); none checks
   *who* is asking. DomainGuard therefore must be the check, not a layer on top of existing checks.

### 1.2 The complete path (before and after)

Before:

```
 host pins ──► sf_host_if ──┐
 (no identity)              │ m0 ┐
 cmd ring ──► sf_control_core ─ m1 ├─► sf_data_fabric ──► slave 0  command RAM
                            │    │                  ├─► slave 1..NV   vector banks (SRAM)
 cmd ring ──► sf_dma ───────┘ m2 ┘                  ├─► slave ..NT    tensor banks (SRAM)
 (src,dst,len unchecked)                            ├─► scratchpad (SRAM)
                                                    └─► sf_ext_mem_if ──► external memory pins
 host CSR window ─────────────► CSR bus ─► control core / power manager      (never on the fabric)
```

After (`rtl/integration/silicaflux_dietop_dg.sv`):

```
 host pins ─► sf_host_if ─► sf_dg_fm2dg ─┐ port0 ┐                                   ┌ sf_dg_dg2fm ─► m0 ┐
 (+host_sid)                              │       │                                   │                   │
 sf_control_core ───────► sf_dg_fm2dg ────┤ port1 ├─► sf_albion_iommu ─► check ─► ... ┤ sf_dg_dg2fm ─► m1 ├─► sf_data_fabric ─► slaves
 sf_dma ────────────────► sf_dg_fm2dg ────┘ port2 ┘   (domain/ctx/entry tables)      └ sf_dg_dg2fm ─► m2 ┘
 host CSR window (+host_priv) ──► CSR bus ──► legacy CSRs (offset < 0x80) | IOMMU admin CSRs (0x80–0xFF)
```

There is **no trusted bypass**, not even for the control core's command fetch: the control core is
bound to a least-privilege domain that maps only the command-RAM page, read-only.

### 1.3 Why no request can bypass the check

* The fabric's master-side request inputs (`u_fabric.m_req_*`, 150 bits) are driven **only** by the three
  `sf_dg_dg2fm` adapters, which sit behind the IOMMU. The outputs of `sf_dma`, `sf_host_if` and
  `sf_control_core` feed **only** the three `sf_dg_fm2dg` adapters.
* This is checked structurally, from the elaborated netlist, by `scripts/audit_bypass.py`
  (Yosys → JSON → bit-level driver/sink walk). The audit is itself validated by a mutation that
  wires the masters straight to the fabric; the audit fails on it (report §6).
* Inside the IOMMU, nothing reaches `ds_*` except from the post-grant FSM states (§3).

---

## 2. Structure of the DomainGuard core

```
rtl/dg/sf_albion_defs.svh    fault / opcode / status codes (macros, shared by all tools)
rtl/dg/sf_albion_xlate.sv    PURE COMBINATIONAL decision: grant, fault cause, PA, domain, entry   (1 per port)
rtl/dg/sf_albion_port.sv     per-port burst FSM + data buffer; the ONLY driver of ds_*             (1 per port)
rtl/dg/sf_albion_iommu.sv    top: ports, admin CSR, tables, atomic commit, drain, fault log, stats
rtl/dg/sf_albion_formal.svh  formal properties (only compiled with SF_DG_FORMAL)
```

### 2.1 State

| State | Meaning |
|---|---|
| `glob_en` | global enable. Reset = 0. |
| `dom_en/rd/wr[d]` | per-domain enable and read/write caps. Reset = 0. |
| `ctx_valid/ctx_dom[port][stream]` | (port, stream-id) → domain binding. Reset = unbound. |
| `ent_*[e]` | translation entries `{valid, domain, IOVA page, PA page, order, R, W}`. Reset = invalid. |
| `blk` | drain in progress (no new checks start). |
| fault log, per-domain and per-port counters | diagnostics (§4). |

Every one of these changes **only** on a privileged CSR write (formal property P2).

### 2.2 DG-Lite bus (per port)

One command channel, one write-data channel and one merged response channel, each valid/ready:

| Channel | Signals |
|---|---|
| command | `cmd_tid`, `cmd_sid`, `cmd_we`, `cmd_addr` (**byte** IOVA), `cmd_len` (= beats − 1) |
| write data | `w_data`, `w_strb` (no WLAST; framing is count-based) |
| response | `r_tid`, `r_we`, `r_err`, `r_last`, `r_data`: a write returns one beat; a read returns `len+1` beats |

Rules: one burst at a time per port, in order; start address aligned to the beat size; the burst must
not cross a 4 KiB boundary (the AXI rule); `tid` is echoed unchanged; `sid` selects the domain via
the context table.

### 2.3 Per-port pipeline

```
IDLE ─cmd─► (write) COLLECT ─all W beats─► WAITCHK ─!blk─► CHECK ─grant─► ISSUE ─► SEND ─► WRESP ─► RESP ─► IDLE
        └─► (read)  ──────────────────────► WAITCHK            │                 └─► RCOLLECT ───────► RESP
                                                               └─deny─► DENY ─fault logged─► RESP (err=1, data=0)
```

Design decisions that matter for security:

* **Collect, then check, then issue.** Write data is taken from the initiator *before* the check. An
  initiator that stalls its own data therefore holds no authority and cannot block an invalidation
  (test T10a). The window between check and use is only ISSUE…WRESP/RCOLLECT, which depends on the
  trusted downstream, not on the initiator.
* **Default-deny pipeline.** `ds_cmd_valid`/`ds_w_valid` are generated only in ISSUE/SEND, reachable
  only from CHECK with `grant`; they are additionally ANDed with a registered grant flag
  (defence in depth; formal property is stated on the *state*, so it survives removal of the AND).
* **Idle wires carry nothing.** `ds_w_data/strb` are forced to zero unless `ds_w_valid` is high.
* **No information to the initiator.** Denials return `err=1` and (for reads) zero data on every beat;
  the cause goes only to the privileged fault log.
* **Inert in reset.** All ready outputs are additionally gated by `rst_n`.

### 2.4 Invalidation = translate-update-then-drain

Every successful admin command that changes anything (and `FENCE`) does:

1. apply the change (visible to the next check),
2. set `blk`: ports stop *entering* CHECK,
3. wait until no port is in CHECK/ISSUE/SEND/WRESP/RCOLLECT,
4. clear `blk` (STATUS.busy falls).

When `busy` is 0, **no burst authorised before the command is still using anything**
(formal property P4/P6). Until then, a burst that was already granted is allowed to finish. Software
must wait for `busy == 0` before it reuses or scrubs a released physical page.
Ports that are not affected are paused for the same few cycles (a deliberate simplification).

---

## 3. Integration summary (see `04_INTEGRATION_GUIDE.md`)

| Change vs the stand-in die top | Why |
|---|---|
| masters → `sf_dg_fm2dg` → IOMMU port → `sf_dg_dg2fm` → fabric masters | no bypass |
| `host_priv` pin (registered like the other host inputs) | privilege qualifier for the admin window |
| `host_sid[1:0]` pin | requester identity for host memory-window accesses |
| CSR window `0x4080–0x40FF` → IOMMU | admin interface |
| `irq` = control-core irq OR IOMMU fault irq | fault notification |

The address the stand-in fabric calls a *word address* is now an IOVA word address
(`byte IOVA = word << 2`, 18 bits ⇒ 64 pages of 4 KiB); the physical address handed to the fabric is
`PA[17:2]`.

## 4. Verification summary

| Layer | Result (details in `05_SECURITY_TESTING_REPORT.md`) |
|---|---|
| Lint (`verilator -Wall`) | core clean; waiver file documents the only exceptions |
| Unit adversarial TB (oracle + downstream gate + canary image) | passes |
| Protocol-violation fuzzer (hostile initiator, random every cycle) | passes |
| System TB with physical-write monitor | passes |
| Stand-in's original 186-check TB, identity-mapped | passes unchanged |
| Structural bypass audit | passes (and fails on the bypass mutant) |
| Formal (k-induction, 2 small configs) + cover points | proved / reached |
| Mutation testing | see report |
