# DomainGuard — address translation specification

Module `sf_albion_iommu` / `sf_albion_xlate`. This is the normative description of what the checker
decides. `rtl/dg/sf_albion_xlate.sv` is the single place where a decision is made.

## 1. Parameters and widths

| Parameter | Default | Range | Meaning |
|---|---|---|---|
| `IOVA_W` | 32 | 13…32 | IOVA width in **bits of byte address** |
| `PA_W` | 40 | 13…44 | physical address width in bits of byte address |
| `DATA_W` | 32 | power of two ≥ 8 | bits per beat; beat size `B = DATA_W/8` bytes |
| `LEN_W` | 4 | ≤ 8 | max burst = `2^LEN_W` beats; `2^LEN_W · B ≤ 4096` (elaboration check) |
| `NUM_PORTS` | 3 | ≤ 256 | initiator ports |
| `NUM_DOMAINS` | 8 | ≤ 256 | isolation domains |
| `NUM_STREAMS` | 4 | ≤ 16 | stream ids per port |
| `NUM_ENTRIES` | 16 | ≤ 256 | translation entries (shared pool, domain-tagged) |
| `MAX_ORDER` | 8 | ≤ 15, ≤ min(IPN_W, PPN_W) | largest region = `4 KiB << MAX_ORDER` |
| `TID_W` | 4 | ≤ 8 | transaction-id width |

Misconfigured parameters fail at elaboration (`$error`, verified in Verilator and Yosys).

Notation: page size **P = 4096 bytes (12 bits)**. For an IOVA `a`: `off(a) = a mod 4096`,
`ipn(a) = a >> 12` (`IPN_W = IOVA_W − 12` bits). For a PA: `ppn(p) = p >> 12` (`PPN_W = PA_W − 12`).

## 2. Granularity

* The unit of translation is the **4 KiB page**.
* An entry may cover a naturally aligned **region** of `2^order` pages (`order ≤ MAX_ORDER`), i.e.
  4 KiB, 8 KiB, 16 KiB … The IOVA base and the PA base must both be aligned to the region size.
  Inside a region, page *k* maps to page *k* of the physical region.
* The 4 KiB **boundary rule** (§5) applies *inside* a region as well, so every burst is checked
  against exactly one page.

## 3. Translation entry

```
{ valid, domain, ipn, ppn, order, R, W }
```

* `ipn`, `ppn` are the base page numbers of the region (low `order` bits zero).
* `R`, `W` are the entry's permissions. A guard page is an entry with `R = W = 0`: it faults as a
  *permission* error rather than as *unmapped*.
* Entries live in a pool shared by all domains; the `domain` tag decides who may use them.
* **Immutable until invalidated.** `ENT_SET` is accepted only for a free slot; to change a mapping:
  `ENT_CLR`, wait for `busy = 0`, then `ENT_SET`.
* **Non-overlap.** Two valid entries of the same domain never cover the same IOVA page (checked at
  commit; formal property P3). Entries of different domains may use identical IOVAs — tenants have
  independent IOVA spaces.

## 4. Domain resolution

A request on port *p* with stream id *s* is resolved through the binding table `ctx[p][s]` to a domain
*d*. There is no global stream namespace: the same `s` on another port is a different binding.
A stream id ≥ `NUM_STREAMS`, or an unbound (p, s), has **no domain** → `NO_CTX`.

## 5. Burst rules

A request is `{tid, sid, we, a, len}` with `n = len + 1` beats and `nbytes = n · B`.

1. **Alignment:** `a mod B == 0`, else `MISALIGN`.
2. **Containment:** `off(a) + nbytes ≤ 4096`, else `PAGE_CROSS`.

Rule 2 is the usual AXI "no 4 KiB crossing" rule. Rationale for *rejecting* rather than splitting:
one lookup per burst keeps the checker small and its proof short, and it removes a class of bugs where
the first half of a burst is performed and the second half is refused. The cost is that an initiator must
split bursts at 4 KiB boundaries. The rule rejects a crossing **even if both pages are mapped with
identical permissions, and even inside one region.** (Tests T5, S3f. The stand-in DMA moves one word
per transaction, so every word is checked against its own page.)

Because the burst lies in one page, `a + nbytes` cannot wrap the address space.

## 6. The decision

Inputs: configuration state, the bound domain *d*, the request. First failing rule wins; every failure
is a denial and produces **no downstream activity**.

| # | Rule | Fault |
|---|---|---|
| 1 | `glob_en` is 1 | `DISABLED` |
| 2 | (p, s) is bound | `NO_CTX` |
| 3 | domain *d* is enabled | `DISABLED` |
| 4 | alignment (§5) | `MISALIGN` |
| 5 | containment (§5) | `PAGE_CROSS` |
| 6 | some valid entry `e` has `domain(e) = d` and `(ipn(a) >> order(e)) == (ipn(e) >> order(e))` — lowest index if several (cannot happen, §3) | `UNMAPPED` |
| 7 | read: `R(e) ∧ cap_rd(d)`;  write: `W(e) ∧ cap_wr(d)` | `PERM_R` / `PERM_W` |

If all pass: **grant**, with

```
mask = (1 << order(e)) − 1
PA   = { (ppn(e) & ~mask) | (ipn(a) & mask) ,  off(a) }
```

i.e. the physical page is `ppn(e) + (ipn(a) − ipn(e))` and the page offset is preserved.
Permission is evaluated on the same entry that supplies the PA.

### Worked examples

(All addresses are full byte addresses; page number = address >> 12, offset = low 12 bits. B = 4 bytes.)

| Entry | Request | Result |
|---|---|---|
| IPN `0x100`, PPN `0x040`, order 0, R/W; domain A | write `a = 0x100010`, 1 beat | page `0x100`, offset `0x010` → PA `0x040010` |
| IPN `0x200`, PPN `0x080`, order 2 (pages `0x200–0x203`), R/W; domain A | read `a = 0x203A44` | page `0x203` is page 3 of the region → PPN `0x080 + 3 = 0x083` → PA `0x083A44` |
| same entry | write `a = 0x201FC0`, 16 beats (64 B) | offset `0xFC0 + 0x40 = 0x1000 ≤ 4096` → granted, PA `0x081FC0` |
| same entry | write `a = 0x201FC4`, 16 beats | offset `0xFC4 + 0x40 = 0x1004 > 4096` → `PAGE_CROSS` (denied although page `0x202` is also mapped) |
| any | `a = 0x100011` (B = 4) | low bits ≠ 0 → `MISALIGN` |
| domain A has an entry at IPN `0x300`; domain B has none | B writes `a = 0x300000` | `UNMAPPED` — A's entry is invisible to B |

## 7. Misses, invalidation, staleness

* **There is no TLB and no page-table walker.** The table *is* the translation state, so a "miss" is
  a fault (`UNMAPPED`); nothing is fetched. Mappings must be programmed before use (pinned).
  The design is therefore free of the classic stale-TLB problem, but not of the stale-**authorisation**
  problem: a burst checked at time *t* is still in flight at *t+k*.
* **Invalidation** (`ENT_CLR`, `DOM_FLUSH`, `CTX_CLR`, `DOM_SET`, `CTRL.enable = 0`) is
  *apply, block new checks, wait for granted bursts, release*:
  1. the table is updated at once, so any check **starting** after the command sees the new state;
  2. no new check starts while `busy = 1`;
  3. `busy` falls when no port holds an authorisation;
  4. therefore **when `busy` reads 0 no authorisation obtained under the old table is in use**
     (formal P4/P6; tests T6a–g).
* A burst already granted *before* the command may complete using the old mapping. This is the point
  of the barrier: the page may not be reused until `busy = 0`.
* A request submitted during a drain is held and then checked against the **new** table.
* More generally, **the decision is taken at CHECK time, not at command acceptance.** For a write, CHECK
  happens after all `len+1` data beats have been received. A command that was accepted while the unit was
  unconfigured (or under an older table) and is still waiting for its data is judged against the table in
  force when its data completes. A burst therefore never holds authority while it waits for its initiator.

## 8. Reset

Reset → no entries, no bindings, all domains disabled, global disable. A request in flight at reset is
discarded (no downstream effect, no response). Outputs are inert while `rst_n = 0`.

## 9. What this is not (RISC-V IOMMU compliance)

DomainGuard does **not** implement, and must not be claimed to be, a RISC-V IOMMU. Missing relative to
the RISC-V IOMMU specification: in-memory device-context / process-context tables and their walk;
multi-level Sv39/Sv48/Sv57 page-table walks; second-stage (G-stage) translation and nested
translation; PASID/process contexts; IOTLB with invalidation commands and ATS; memory-resident command,
fault and page-request queues; MSI address translation and interrupt remapping; hardware A/D bit
updates; the standardised register interface; WSI/MSI fault signalling; PMA/PMP interaction.
What it shares in spirit: separate address spaces per device context, permission-checked translation,
fault reporting, invalidation with completion.

**Upgrade path** (not implemented): put an IOTLB in front of memory-resident page tables, replacing
the flat table by a TLB; the stale-translation barrier then becomes `IOTINVAL` + `IOFENCE`. The port FSM,
the "collect → check → issue" structure and the drain semantics carry over unchanged.

## 10. Stand-in die mapping

In the SilicaFlux stand-in die (`PA_W = IOVA_W = 18`, `DATA_W = 32`) the fabric word address `w`
corresponds to IOVA byte address `w << 2`. IOVA space = 256 KiB = 64 pages, physical space 64 pages:

| Fabric word range | PA page(s) | Memory |
|---|---|---|
| `0x0000–0x003F` | 0 | command RAM (only 64 words exist; the rest of the page is rejected by the memory itself) |
| `0x1000–0x13FF` | 4 | vector cluster 0 (banks A/B/C at `0x1000/0x1100/0x1200`) |
| `0x2000–0x23FF` | 8 | tensor cluster 0 |
| `0x3000–0x30FF` | 12 (`0xC`) | scratchpad (256 words) |
| `0x8000–0xFFFF` | `0x20–0x3F` | external memory (32 pages) |
