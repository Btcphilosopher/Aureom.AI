# DomainGuard — register specification

Module `sf_albion_iommu`, admin CSR bus. In the SilicaFlux die the registers appear in the host CSR
window at **`0x4000 + 0x80 + offset`** (`0x4080 … 0x40FF`). The standalone module sees the 8-bit
word offset directly (`csr_addr[7:0]`). All registers are 32 bits wide.

## 1. Bus protocol

| Signal | Dir | Meaning |
|---|---|---|
| `csr_valid` | in | single-cycle strobe; a write takes effect at the clock edge that ends this cycle |
| `csr_we` | in | 1 = write |
| `csr_addr[7:0]` | in | word offset |
| `csr_wdata[31:0]` | in | write data |
| `csr_priv` | in | 1 = privileged access (hypervisor / secure firmware) |
| `csr_hit` | out | 0 = **bus error**: unmapped address, write to a read-only register, or not privileged |
| `csr_rdata[31:0]` | out | **combinational** function of `csr_addr` and state (valid in the same cycle; 0 when `csr_hit = 0`) |
| `irq` | out | level: `CTRL.irq_en && fault log non-empty` |

**Privilege.** Without `csr_priv`:

* reads of `ID`, `CAP0..2` succeed (capability discovery);
* every other access returns `csr_hit = 0`, changes no state, and sets the sticky `STATUS.admin_viol`.

With `csr_priv`, a write to a read-only/unknown offset, or a read of an unknown offset, also returns `csr_hit = 0`.

**Atomic commit.** Entries, bindings and domains are written into `STG_*` staging registers and become
effective only when one `CMD` write commits them. Staging registers have no effect by themselves.

Access: `RO` read-only · `RW` · `W1C` write-1-to-clear · `WO` write-only (reads 0) · `PRIV` privileged only.

## 2. Register map

| Off | Name | Access | Description |
|---|---|---|---|
| 0x00 | `ID` | RO (public) | `0x4447_0100` — "DG" v1.0 |
| 0x01 | `CAP0` | RO (public) | `[7:0]` NUM_PORTS · `[15:8]` NUM_DOMAINS · `[23:16]` NUM_ENTRIES · `[31:24]` NUM_STREAMS |
| 0x02 | `CAP1` | RO (public) | `[7:0]` IOVA_W · `[15:8]` PA_W · `[23:16]` DATA_W · `[31:24]` MAX_ORDER (each truncated to 8 bits) |
| 0x03 | `CAP2` | RO (public) | `[7:0]` FQ_DEPTH · `[15:8]` LEN_W · `[23:16]` TID_W · `[31:24]` CNT_W |
| 0x04 | `CTRL` | RW PRIV | `[0]` `glob_en` · `[1]` `irq_en`. Reset 0 / 0 |
| 0x05 | `STATUS` | RO + W1C PRIV | `[0]` `busy` (drain in progress) · `[1]` fault log non-empty · `[2]` `fq_ovf` (**W1C**) · `[3]` `admin_viol` (**W1C**) · `[11:8]` `last_err` (§4) |
| 0x08 | `STG_IPN` | RW PRIV | staged IOVA page number (`IOVA >> 12`) |
| 0x09 | `STG_PPN` | RW PRIV | staged physical page number (`PA >> 12`) |
| 0x0A | `STG_ATTR` | RW PRIV | `[0]` R · `[1]` W · `[11:8]` order · `[23:16]` domain |
| 0x0B | `STG_CTX` | RW PRIV | `[7:0]` port · `[15:8]` stream id · `[23:16]` domain (the port/stream also select what `CTX_RD` shows) |
| 0x0C | `STG_DOM` | RW PRIV | `[7:0]` domain · `[8]` enable · `[9]` read cap · `[10]` write cap |
| 0x0D | `CMD` | WO PRIV | `[3:0]` opcode · `[15:8]` index. Writing executes the command (§3). Reads 0 |
| 0x10 | `FQ_STATUS` | RO PRIV | `[7:0]` records in log · `[31:16]` records **dropped** on overflow (saturating, `CNT_W` bits) |
| 0x11 | `FQ_META` | RO PRIV | head record: `[3:0]` cause · `[4]` write · `[5]` domain-valid · `[15:8]` domain · `[23:16]` port · `[27:24]` stream id. 0 if empty |
| 0x12 | `FQ_IOVA` | RO PRIV | head record IOVA (byte address, zero-extended) |
| 0x13 | `FQ_ID` | RO PRIV | head record `[7:0]` tid · `[15:8]` burst length (beats − 1) |
| 0x14 | `FQ_POP` | WO PRIV | any write discards the head record |
| 0x18 | `SEL_DOM` | RW PRIV | selects a domain for `DOM_*` |
| 0x19 | `DOM_CFG` | RO PRIV | selected domain: `[0]` enable · `[1]` read cap · `[2]` write cap |
| 0x1A | `DOM_FCNT` | RO PRIV | selected domain: number of denied bursts attributed to it (saturating) |
| 0x1B | `DOM_FMASK` | RO + W1C PRIV | selected domain: bit *k* = a fault of cause *k* has occurred (`[15:0]`); write-1 clears bits |
| 0x1C | `SEL_ENT` | RW PRIV | selects an entry for `ENT_RD*` |
| 0x1D | `ENT_RD0` | RO PRIV | selected entry: `[0]` valid · `[1]` R · `[2]` W · `[11:8]` order · `[23:16]` domain |
| 0x1E | `ENT_RD1` | RO PRIV | selected entry IOVA page number |
| 0x1F | `ENT_RD2` | RO PRIV | selected entry physical page number |
| 0x20 | `CTX_RD` | RO PRIV | binding of the (port, stream) currently in `STG_CTX`: `[0]` valid · `[23:16]` domain |
| 0x21 | `SEL_PORT` | RW PRIV | selects a port for `PORT_*` |
| 0x22 | `PORT_OK` | RO PRIV | bursts granted on the selected port (saturating) |
| 0x23 | `PORT_DENY` | RO PRIV | bursts denied on the selected port (saturating) |

Out-of-range selector values read as 0.

## 3. Commands (`CMD`)

`CMD[3:0]` opcode, `CMD[15:8]` index.

| Op | Name | Index | Uses | Effect |
|---|---|---|---|---|
| 0 | `NOP` | – | – | nothing, no drain |
| 1 | `ENT_SET` | entry slot | `STG_IPN/PPN/ATTR` | write the staged entry into the slot and mark it valid |
| 2 | `ENT_CLR` | entry slot | – | invalidate the slot (clearing an already-free slot is a no-op) |
| 3 | `DOM_FLUSH` | domain | – | invalidate **every** entry of the domain |
| 4 | `CTX_SET` | – | `STG_CTX` | bind (port, stream) → domain |
| 5 | `CTX_CLR` | – | `STG_CTX` | unbind (port, stream) |
| 6 | `DOM_SET` | – | `STG_DOM` | set the domain's enable / read cap / write cap |
| 7 | `FENCE` | – | – | drain barrier only |

**Every successful command except `NOP` ends with a drain.** The change is applied immediately; then
`STATUS.busy` is 1 until every burst that was already granted has finished. When `busy` reads 0
no burst authorised before the command is still in use. A failed command (error ≠ 0) changes nothing and
starts no drain.

A `CMD` written while `busy = 1` is ignored and records `E_PENDING`.

`CTRL`: writing `glob_en = 0` while the IOMMU is enabled is always accepted (even during a drain) and starts a drain. Writing `glob_en = 1` is
accepted only when `busy = 0`; otherwise it is ignored and `E_PENDING` is recorded (`irq_en` is
written either way).

### Commit rules enforced by `ENT_SET`

1. index < NUM_ENTRIES · domain < NUM_DOMAINS
2. `order ≤ MAX_ORDER`; `STG_IPN` fits IOVA_W−12 bits; `STG_PPN` fits PA_W−12 bits
3. both page numbers are naturally aligned to `2^order` pages
4. the slot is currently **free** (entries are never modified in place)
5. the IOVA range does not overlap any valid entry of the **same** domain (different domains may use
   the same IOVAs — that is the point)

`CTX_SET` additionally requires the (port, stream) to be currently unbound, so re-binding is
`CTX_CLR` (drain) then `CTX_SET`.

## 4. `STATUS.last_err` codes

| Code | Name | Meaning |
|---|---|---|
| 0 | `E_OK` | last command accepted |
| 1 | `E_IDX` | slot / port / stream index out of range |
| 2 | `E_RANGE` | value does not fit the implemented width, order > MAX_ORDER, or region not naturally aligned |
| 3 | `E_OVERLAP` | overlaps a valid entry of the same domain |
| 4 | `E_BUSY` | slot or binding already valid (clear first) |
| 5 | `E_DOM` | domain out of range |
| 6 | `E_OP` | illegal opcode |
| 7 | `E_PENDING` | command (or enabling `CTRL` write) issued while a drain was in progress |

`last_err` is overwritten by every `CMD` write.

## 5. Fault causes (`FQ_META[3:0]`, `DOM_FMASK` bit index)

| Code | Name | Condition (first match in this order) |
|---|---|---|
| 2 | `DISABLED` | IOMMU globally disabled, **or** the bound domain is disabled |
| 1 | `NO_CTX` | (port, stream) has no binding (or the stream id is out of range) |
| 7 | `MISALIGN` | start address not aligned to the beat size |
| 6 | `PAGE_CROSS` | burst would cross a 4 KiB boundary |
| 3 | `UNMAPPED` | no valid entry of the bound domain covers the page |
| 4 | `PERM_R` | read, but the entry lacks R or the domain lacks the read cap |
| 5 | `PERM_W` | write, but the entry lacks W or the domain lacks the write cap |

Evaluation order: global enable → binding → domain enable → alignment → page crossing → lookup →
permission. (0 = no fault.)

`FQ_META[5]` (domain-valid) is 0 for `NO_CTX`; the domain field is then meaningless.

## 6. Fault log and counters

* One record per **denied burst**, FIFO of `FQ_DEPTH`, oldest first. The record is accepted *before* the
  initiator is given its error response, so a software reaction to the error always finds the record.
* If the FIFO is full the new record is dropped: `STATUS.fq_ovf` sets (sticky) and the drop count in
  `FQ_STATUS[31:16]` increments. **Dropping never blocks the data path.**
* `DOM_FCNT`, `DOM_FMASK`, `PORT_OK`, `PORT_DENY` are updated for every burst, including those whose
  record was dropped. `DOM_FCNT` counts only bursts whose domain could be resolved.
* `irq` = `CTRL.irq_en` AND log non-empty.

## 7. Reset values

Everything is zero: `glob_en = 0`, `irq_en = 0`, all domains disabled with no caps, no bindings, no valid
entries, staging and selector registers 0, empty log, counters 0, `busy = 0`, `last_err = E_OK`.
Until a privileged agent configures it, **every request is denied** with an error response.

## 8. Example sequence — create tenant, map two pages, bind a stream

```
CTRL      <- 0x1                              ; enable
STG_DOM   <- 3 | 1<<8 | 1<<9 | 1<<10          ; domain 3: enabled, read+write
CMD       <- 6                                ; DOM_SET          -> poll STATUS.busy == 0
STG_IPN   <- 0x001  STG_PPN <- 0x00C  STG_ATTR <- R|W | 3<<16   ; IOVA 0x1000 -> PA 0xC000, domain 3
CMD       <- 1 | 5<<8                         ; ENT_SET slot 5   -> poll busy
STG_CTX   <- 2 | 0<<8 | 3<<16                 ; port 2, stream 0 -> domain 3
CMD       <- 4                                ; CTX_SET          -> poll busy
```

Teardown: `CMD <- DOM_FLUSH(domain)` (or `ENT_CLR`/`CTX_CLR`), **wait for `busy = 0`**, then scrub the
physical pages before reuse.
