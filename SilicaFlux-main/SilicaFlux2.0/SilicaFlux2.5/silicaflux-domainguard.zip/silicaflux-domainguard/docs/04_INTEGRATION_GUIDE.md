# DomainGuard — integration guide

For SoC integrators and for the hypervisor/firmware author.

## 1. Files and build

```
rtl/dg/                       core (4 files + formal header)       -- the product
rtl/integration/              sf_dg_fm2dg, sf_dg_dg2fm, silicaflux_dietop_dg   -- worked integration
third_party/p40_standin/      unmodified stand-in RTL (+ SHA-256, provenance)
rtl/filelists/*.f             file lists (core only / protected die)
```

Include path: `-Irtl/dg` (for `sf_albion_defs.svh`). Tools used here: Verilator 5.020, Yosys 0.33,
cvc5 1.1.2 (apt packages). `make help` lists the targets (`lint`, `sim-unit`, `sim-system`, `sim-regress`,
`audit`, `formal`, `cover`, `mutation`, `all`).

## 2. Integration procedure

### 2.1 Enumerate every initiator (do this first)

Every master that can drive the memory fabric must be on the list. For the stand-in die the list is in
`00_ARCHITECTURE.md` §1.1 (host memory window, control-core fetch, DMA). **A master you forget is a
bypass.** For the real DieTop repeat that inspection, then run the structural audit (§6).

### 2.2 Insert one IOMMU port per initiator

```
initiator (own protocol) ──► adapter ──► sf_albion_iommu us_* port k ──► ds_* port k ──► adapter ──► fabric master k
```

* Parameters `NUM_PORTS`, `IOVA_W`, `PA_W`, `DATA_W` follow your fabric. The stand-in: `3 / 18 / 18 / 32`.
* If your initiators already speak a burst protocol, a thin adapter maps it to DG-Lite (below).
  If they are single-beat (as here), `sf_dg_fm2dg` / `sf_dg_dg2fm` are the reference adapters.
* **Every fabric master port must be driven by a downstream adapter and by nothing else.**

### 2.3 DG-Lite initiator contract (what a DMA engine must do)

```
cmd :  valid/ready      {tid, sid, we, addr (byte IOVA), len = beats-1}
wr  :  valid/ready      {data, strb}              (writes only; exactly len+1 beats, in order)
rsp :  valid/ready      {tid, we, err, last, data}  (1 beat for a write; len+1 beats for a read)
```

* one burst at a time per port; the response must be accepted (`r_ready`) for the port to continue
* start address aligned to the beat size; burst must fit within one 4 KiB page (**split at 4 KiB**)
* write data may be offered before or after the command is accepted; the port accepts it only after the
  command (`w_ready` is low until then)
* a write response arrives after all data has been taken; an initiator that never supplies the data
  stalls **only its own port** (no authority is held; other ports and admin operations are unaffected)

```
 write burst, 2 beats (no stalls):
 cmd_valid ──┐‾‾‾‾‾‾‾‾‾‾‾‾                           accepted when cmd_ready (port idle)
 w_valid   ──────────┐‾‾‾‾‾‾‾‾‾‾‾‾‾  (2 beats)       w_ready only after the command is accepted
 ... CHECK (1 cycle) ... ds_cmd ... ds_w x2 ... ds_resp ... r_valid (write response, last=1)
```

### 2.4 Downstream contract (what the fabric side must do)

Same three channels, driven by the IOMMU: `ds_cmd` first, then `ds_w` beats (writes), then a response
(`ds_r_valid`: one beat for a write, `len+1` beats for a read). `ds_r_err` is propagated to the
initiator unchanged. The downstream must respond (assumption S3).

### 2.5 Clock and reset

* single clock; no CDC inside DomainGuard
* `rst_n` is asynchronous-assert, active low. Feed it the **same synchronised reset** as the fabric and
  the initiators (the stand-in wrapper's `core_rst_n`). Reset is a *system* reset (assumption S4).
* the IOMMU's own ready outputs (`us_cmd_ready`, `us_w_ready`, `ds_r_ready`) are low while `rst_n = 0`, and its valid outputs (`ds_cmd_valid`, `ds_w_valid`, `us_r_valid`) go low immediately (asynchronously) when reset asserts

### 2.6 Admin CSR bus and privilege

* connect `csr_*` to a bus that only privileged software can reach
* **`csr_priv` must be true only for privileged accesses and must not be forgeable by a tenant.**
  In the stand-in die this is the new pin `host_priv`. The host bridge must derive it from the PCIe function
  (physical function / hypervisor ⇒ 1, virtual function ⇒ 0). It is registered inside the die top
  exactly like `host_req`, so it stays aligned with the registered CSR strobe: **hold it stable while
  `host_req` is high.**
* `host_sid` (memory-window requester id) has the same rule: derived by the bridge from the requester,
  stable while `host_req` is high
* the CSR window must not be reachable from any DMA-capable master (in the stand-in it is not, by
  construction)

### 2.7 Interrupt

`irq` is a level: non-empty fault log and `CTRL.irq_en`. In the die top it is OR-ed with the existing
control-core interrupt.

## 3. Choosing stream ids

| Port | Stream id source | Notes |
|---|---|---|
| host memory window | `host_sid`, from the bridge | one binding per tenant function |
| DMA engine | constant 0 (trusted logic) | hypervisor re-binds `ctx[DMA][0]` when scheduling another tenant |
| control-core fetch | constant 0 | bound to a read-only domain containing only the command-RAM page |

Never take a stream id from a tenant-controlled field on a port that serves several tenants.

## 4. Hypervisor / firmware procedures

All register offsets and encodings are in `02_REGISTER_SPEC.md`.

### 4.1 Boot (secure order)

1. Reset. Everything is denied (the control core cannot even fetch its first command — it halts with
   fetch error 5; tested in S0).
2. `CTRL.enable = 1`.
3. Create the **control domain**: one read-only entry for the command-RAM page, bind `ctx[CTRL][0]`.
4. Create the **hypervisor domain** (identity maps as needed), bind `ctx[HOST][0]`.
5. Create tenant domains and bind their streams.
6. Check `STATUS.last_err == 0` and `busy == 0` after every command.

### 4.2 Create a tenant

`DOM_SET` (enable, caps) → one `ENT_SET` per page/region → `CTX_SET` for each stream the tenant may use.

### 4.3 Switch the DMA engine between tenants

```
(wait until the DMA is idle or accept that its current burst completes)
CTX_CLR  ctx[DMA][0]       ; applies at once, then drain: busy=1 until the in-flight burst ends
wait busy == 0
CTX_SET  ctx[DMA][0] -> new domain
```

Between the two commands the DMA port is denied (`NO_CTX`), never silently using the old tenant.

### 4.4 Tear down a tenant / reuse a page — the order matters

```
DOM_SET  domain disabled          (stops new use; drain)          -- optional, immediate kill switch
DOM_FLUSH domain                  (or ENT_CLR per entry)
wait STATUS.busy == 0             <-- after this, nothing authorised under the old mapping is in flight
scrub the physical pages          <-- software responsibility
map the pages into another domain
```

### 4.5 Fault handling

On `irq` (or by polling `STATUS[1]`): read `FQ_META`, `FQ_IOVA`, `FQ_ID`, then write `FQ_POP`. Use
`DOM_FCNT`/`DOM_FMASK` for rates and kinds per domain, `PORT_OK`/`PORT_DENY` per port. Dropped
records are counted in `FQ_STATUS[31:16]`; the counters stay exact.

## 5. Performance (measured, unit testbench, zero artificial stalls)

Cycles from the initiator offering the command until the last response beat is accepted, single port,
with the testbench's downstream memory model (which itself needs two cycles per beat, so these are
conservative):

| | 1 beat | 4 beats | 8 beats | 16 beats | formula |
|---|---|---|---|---|---|
| write, granted | 11 | 20 | 32 | 56 | 3n + 8 |
| read, granted | 8 | 17 | 29 | 53 | 3n + 5 |
| write, denied | 7 | 10 | 14 | 22 | n + 6 |
| read, denied | 5 | 8 | 12 | 20 | n + 4 |

Structural cost: the burst is **stored and forwarded** (writes are collected before the check; read data is
collected before it is returned), and only **one burst per port** is in flight. Per-port buffer:
`2^LEN_W · (DATA_W + DATA_W/8)` flops. In the stand-in die the DMA moves one word per transaction, so a
DMA word copy pays one single-beat read and one single-beat write plus the two adapters. Raising
throughput (several outstanding bursts, cut-through) is a performance project, not a security one; the
"collect → check → issue → drain" structure must be preserved.

## 6. Sign-off checklist for a new integration

1. **Initiator inventory** complete (§2.1).
2. `scripts/audit_bypass.py` passes on *your* top (adapt the three instance names). It must report each
   fabric master input has exactly one driver class and that no initiator output reaches the fabric
   except via an adapter.
3. `csr_priv`, `host_sid` provenance reviewed against assumptions S1/S2.
4. Reset tree shared with fabric and initiators (S4).
5. `make lint`, `make sim-unit`, `make sim-system`, `make formal` pass on the integrated RTL.
6. Boot sequence leaves every unused (port, stream) unbound and every unused domain disabled.
7. Tenant teardown waits for `busy == 0` and scrubs memory (S5).
8. JTAG/test access is disabled or authenticated in production (threat model §6.6).

## 7. Known limitations

* 4 KiB containment is enforced by *rejecting*; initiators must split bursts.
* The flat table has `NUM_ENTRIES` slots shared by all domains.
* A drain pauses all ports briefly.
* Formal proofs are for small configurations (report §4); the full configuration is simulation-verified.
* `DATA_W`, `NUM_*` are reported in 8-bit CAP fields (values ≥ 256 truncate).
