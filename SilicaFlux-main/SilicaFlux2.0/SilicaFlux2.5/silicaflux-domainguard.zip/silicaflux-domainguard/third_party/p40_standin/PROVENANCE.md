# Third-party (project-internal) stand-in RTL — UNMODIFIED

These files are copied verbatim from `silicaflux-p40-floorplanbuild.zip` (SilicaFlux Project 40,
"STAND-IN INTEGRATION RTL": the integrated DieTop of Projects 31-39 was not available there either).

* source archive : silicaflux-p40-floorplanbuild.zip
* archive sha256 : fe3d3b0935bbd9ea8c17948071e2223dc47d6c082aeb19295baf859c4a0854c2
* per-file hashes: `FILES.sha256` (verify with `sha256sum -c FILES.sha256`)

DomainGuard does **not** modify any of these files. The protected integration lives in
`rtl/integration/silicaflux_dietop_dg.sv`, which is a derivative of
`rtl/standin/silicaflux_dietop_standin.sv` with the DMA-capable masters re-routed through
`sf_albion_iommu`. When the real DieTop is available, apply the same re-routing to it
(see docs/04_INTEGRATION_GUIDE.md); this directory is then dropped, as the stand-in notes say.
