// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | sf_dg_dg2fm
// Adapter: DG-Lite downstream port  ->  SilicaFlux fabric-master protocol.
//
// This is the ONLY driver of a data-fabric master port in the protected die
// (see scripts/audit_bypass.py). It sits behind the IOMMU, so everything it
// receives has already been authorised. A burst of N beats becomes N single-beat
// fabric transactions with consecutive word addresses; the response error is the
// OR of the per-beat fabric errors.
//
//   write burst : ds_cmd -> [ ds_w beat -> fabric write ] x N -> one write response
//   read  burst : ds_cmd -> [ fabric read -> ds_r beat ] x N
// -----------------------------------------------------------------------------
module sf_dg_dg2fm #(
  parameter int PA_W  = 18,
  parameter int TID_W = 2,
  parameter int LEN_W = 4
) (
  input  logic               clk,
  input  logic               rst_n,
  // DG-Lite downstream (from the IOMMU)
  input  logic               ds_cmd_valid,
  output logic               ds_cmd_ready,
  input  logic [TID_W-1:0]   ds_cmd_tid,
  input  logic               ds_cmd_we,
  input  logic [PA_W-1:0]    ds_cmd_addr,
  input  logic [LEN_W-1:0]   ds_cmd_len,
  input  logic               ds_w_valid,
  output logic               ds_w_ready,
  input  logic [31:0]        ds_w_data,
  input  logic [3:0]         ds_w_strb,
  input  logic               ds_w_last,
  output logic               ds_r_valid,
  input  logic               ds_r_ready,
  output logic               ds_r_err,
  output logic [31:0]        ds_r_data,
  // fabric master
  output logic               m_req_valid,
  input  logic               m_req_ready,
  output logic               m_req_we,
  output logic [15:0]        m_req_addr,
  output logic [31:0]        m_req_wdata,
  input  logic               m_rsp_valid,
  input  logic               m_rsp_err,
  input  logic [31:0]        m_rsp_rdata
);
  if (PA_W != 18) begin : g_chk_pa $error("sf_dg_dg2fm: the stand-in fabric has a 16-bit word address, so PA_W must be 18"); end

  typedef enum logic [2:0] {S_IDLE, S_WAITW, S_REQ, S_RSP, S_RBEAT, S_BRESP} st_t;
  st_t                st;
  logic               we_q, err_q;
  logic [15:0]        base_q;
  logic [LEN_W-1:0]   len_q, beat_q;
  logic [31:0]        wdata_q, rdata_q;

  assign ds_cmd_ready = (st == S_IDLE) && rst_n;
  assign ds_w_ready   = (st == S_WAITW) && rst_n;
  assign ds_r_valid   = (st == S_RBEAT) || (st == S_BRESP);
  assign ds_r_err     = err_q;
  assign ds_r_data    = (st == S_RBEAT) ? rdata_q : 32'h0;

  assign m_req_valid  = (st == S_REQ);
  assign m_req_we     = we_q;
  assign m_req_addr   = base_q + 16'(beat_q);
  assign m_req_wdata  = wdata_q;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st <= S_IDLE; we_q <= 1'b0; err_q <= 1'b0; base_q <= '0; len_q <= '0; beat_q <= '0;
      wdata_q <= '0; rdata_q <= '0;
    end else begin
      case (st)
        S_IDLE: if (ds_cmd_valid) begin
          we_q   <= ds_cmd_we;
          base_q <= ds_cmd_addr[17:2];      // byte -> fabric word address
          len_q  <= ds_cmd_len;
          beat_q <= '0;
          err_q  <= 1'b0;
          st     <= ds_cmd_we ? S_WAITW : S_REQ;
        end
        S_WAITW: if (ds_w_valid) begin
          wdata_q <= ds_w_data;
          st      <= S_REQ;
        end
        S_REQ: if (m_req_ready) st <= S_RSP;
        S_RSP: if (m_rsp_valid) begin
          err_q <= err_q | m_rsp_err;
          if (we_q) begin
            if (beat_q == len_q) st <= S_BRESP;
            else begin beat_q <= beat_q + 1'b1; st <= S_WAITW; end
          end else begin
            rdata_q <= m_rsp_rdata;
            st      <= S_RBEAT;
          end
        end
        S_RBEAT: if (ds_r_ready) begin
          if (beat_q == len_q) begin st <= S_IDLE; end
          else begin beat_q <= beat_q + 1'b1; st <= S_REQ; end
        end
        S_BRESP: if (ds_r_ready) st <= S_IDLE;
        default: st <= S_IDLE;
      endcase
    end
  end

  logic unused_ok;
  assign unused_ok = &{1'b0, ds_cmd_tid, ds_w_strb, ds_w_last, ds_cmd_addr[1:0]};
endmodule
