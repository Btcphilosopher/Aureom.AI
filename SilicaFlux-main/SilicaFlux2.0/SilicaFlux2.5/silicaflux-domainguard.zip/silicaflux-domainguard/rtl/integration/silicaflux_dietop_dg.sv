// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | silicaflux_dietop_dg
//
// PROTECTED die top: derivative of rtl/standin/silicaflux_dietop_standin.sv
// (third_party/p40_standin, unmodified) in which EVERY data-fabric master goes
// through sf_albion_iommu. The only structural changes against the stand-in:
//
//   1. master 0 (sf_host_if memory window), master 1 (sf_control_core command
//      fetch) and master 2 (sf_dma) no longer drive the fabric directly. Each is
//      adapted into an IOMMU port (sf_dg_fm2dg), and the fabric master ports are
//      driven ONLY by sf_dg_dg2fm adapters behind the IOMMU. There is no bypass.
//   2. the host CSR window gains a privileged region 0x4080-0x40FF -> IOMMU admin.
//      The legacy CSRs (offsets < 0x10) are unchanged.
//   3. new ports: host_priv (access is privileged: hypervisor / PF) and host_sid
//      (requester identity of a host memory-window access, e.g. the PCIe VF).
//   4. irq = control-core irq OR IOMMU fault-log irq.
//
// Stream ids on the other two ports are fixed to 0 by trusted logic; the DMA
// port is steered between tenants by the hypervisor rebinding ctx[DMA][0].
//
// Address interpretation: all three masters now issue IOVAs. The fabric's 16-bit
// word address is the IOVA word address (byte IOVA = word << 2, 18 bits).
// -----------------------------------------------------------------------------
(* keep_hierarchy *)
module silicaflux_dietop_dg #(
  parameter int NV            = 1,
  parameter int NT            = 1,
  parameter int VBANK_DEPTH   = 64,
  parameter int TBANK_DEPTH   = 64,
  parameter int SCRATCH_DEPTH = 256
) (
  input  logic        clk,
  input  logic        rst_n,
  input  logic        test_mode,
  // host port
  input  logic        host_req,
  input  logic        host_we,
  input  logic [15:0] host_addr,
  input  logic [31:0] host_wdata,
  input  logic        host_priv,      // NEW: access is privileged (must be stable while host_req is high)
  input  logic [1:0]  host_sid,       // NEW: requester identity for memory-window accesses (stable while host_req)
  output logic        host_ack,
  output logic [31:0] host_rdata,
  output logic        host_err,
  // external memory port
  output logic        ext_req,
  output logic        ext_we,
  output logic [14:0] ext_addr,
  output logic [31:0] ext_wdata,
  input  logic        ext_ack,
  input  logic [31:0] ext_rdata,
  // misc
  output logic        irq,
  input  logic        therm_alert,
  // JTAG
  input  logic        tck,
  input  logic        tms,
  input  logic        tdi,
  input  logic        trst_n,
  output logic        tdo
);
  localparam int NM = 3;
  localparam int NS = NV + NT + 3;
  localparam int S_CMD = 0, S_VEC0 = 1, S_TEN0 = 1 + NV, S_SCR = 1 + NV + NT, S_EXT = 2 + NV + NT;
  localparam int M_HOST = 0, M_CTRL = 1, M_DMA = 2;

  // IOMMU configuration for this die
  localparam int DG_DOMAINS = 8;
  localparam int DG_STREAMS = 4;
  localparam int DG_ENTRIES = 16;
  localparam int DG_IOVA_W  = 18;
  localparam int DG_PA_W    = 18;
  localparam int DG_LEN_W   = 4;
  localparam int DG_TID_W   = 2;
  localparam int DG_SID_W   = 2;

  // ---------------- fabric wiring ----------------
  // r_* : what the three masters ask for (untrusted origin).
  // m_* : what the fabric sees. Driven only by the DG->fabric adapters.
  logic [NM-1:0]    r_req_valid, r_req_ready, r_req_we, r_rsp_valid, r_rsp_err;
  logic [NM*16-1:0] r_req_addr;
  logic [NM*32-1:0] r_req_wdata, r_rsp_rdata;
  logic [NM-1:0]    m_req_valid, m_req_ready, m_req_we, m_rsp_valid, m_rsp_err;
  logic [NM*16-1:0] m_req_addr;
  logic [NM*32-1:0] m_req_wdata, m_rsp_rdata;
  logic [NS-1:0]    s_req_valid, s_req_ready, s_req_we, s_rsp_valid, s_rsp_err;
  logic [NS*16-1:0] s_req_addr;
  logic [NS*32-1:0] s_req_wdata, s_rsp_rdata;
  logic [15:0]      decode_err_count, ext_timeout_count;

  sf_data_fabric #(.NM(NM), .NV(NV), .NT(NT)) u_fabric (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(m_req_valid), .m_req_ready(m_req_ready), .m_req_we(m_req_we),
    .m_req_addr(m_req_addr), .m_req_wdata(m_req_wdata), .m_rsp_valid(m_rsp_valid),
    .m_rsp_err(m_rsp_err), .m_rsp_rdata(m_rsp_rdata),
    .s_req_valid(s_req_valid), .s_req_ready(s_req_ready), .s_req_we(s_req_we),
    .s_req_addr(s_req_addr), .s_req_wdata(s_req_wdata), .s_rsp_valid(s_rsp_valid),
    .s_rsp_err(s_rsp_err), .s_rsp_rdata(s_rsp_rdata),
    .decode_err_count(decode_err_count));

  // ---------------- DomainGuard: the only path from masters to the fabric ----------------
  logic [NM-1:0]               us_cmd_valid, us_cmd_ready, us_cmd_we, us_w_valid, us_w_ready;
  logic [NM*DG_TID_W-1:0]      us_cmd_tid;
  logic [NM*DG_SID_W-1:0]      us_cmd_sid;
  logic [NM*DG_IOVA_W-1:0]     us_cmd_addr;
  logic [NM*DG_LEN_W-1:0]      us_cmd_len;
  logic [NM*32-1:0]            us_w_data;
  logic [NM*4-1:0]             us_w_strb;
  logic [NM-1:0]               us_r_valid, us_r_ready, us_r_we, us_r_err, us_r_last;
  logic [NM*DG_TID_W-1:0]      us_r_tid;
  logic [NM*32-1:0]            us_r_data;
  logic [NM-1:0]               ds_cmd_valid, ds_cmd_ready, ds_cmd_we, ds_w_valid, ds_w_ready, ds_w_last;
  logic [NM*DG_TID_W-1:0]      ds_cmd_tid;
  logic [NM*DG_PA_W-1:0]       ds_cmd_addr;
  logic [NM*DG_LEN_W-1:0]      ds_cmd_len;
  logic [NM*32-1:0]            ds_w_data;
  logic [NM*4-1:0]             ds_w_strb;
  logic [NM-1:0]               ds_r_valid, ds_r_ready, ds_r_err;
  logic [NM*32-1:0]            ds_r_data;

  logic        csr_valid, csr_we, csr_hit_ctrl, csr_hit_pm, csr_hit_iommu;
  logic [7:0]  csr_addr;
  logic [31:0] csr_wdata, csr_rdata_ctrl, csr_rdata_pm, csr_rdata_iommu, csr_rdata;
  logic        csr_hit;
  logic        irq_ctrl, irq_iommu;

  // host_priv / host_sid are registered exactly like the host_if inputs, so they stay
  // aligned with the (registered) CSR strobe they qualify.
  logic        priv_r;
  logic [DG_SID_W-1:0] hsid_r;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin priv_r <= 1'b0; hsid_r <= '0; end
    else        begin priv_r <= host_priv; hsid_r <= host_sid; end
  end

  sf_albion_iommu #(
    .NUM_PORTS(NM), .NUM_DOMAINS(DG_DOMAINS), .NUM_STREAMS(DG_STREAMS), .NUM_ENTRIES(DG_ENTRIES),
    .IOVA_W(DG_IOVA_W), .PA_W(DG_PA_W), .DATA_W(32), .LEN_W(DG_LEN_W), .TID_W(DG_TID_W),
    .MAX_ORDER(4), .FQ_DEPTH(8), .CNT_W(16)
  ) u_iommu (
    .clk(clk), .rst_n(rst_n),
    .us_cmd_valid(us_cmd_valid), .us_cmd_ready(us_cmd_ready), .us_cmd_tid(us_cmd_tid),
    .us_cmd_sid(us_cmd_sid), .us_cmd_we(us_cmd_we), .us_cmd_addr(us_cmd_addr), .us_cmd_len(us_cmd_len),
    .us_w_valid(us_w_valid), .us_w_ready(us_w_ready), .us_w_data(us_w_data), .us_w_strb(us_w_strb),
    .us_r_valid(us_r_valid), .us_r_ready(us_r_ready), .us_r_tid(us_r_tid), .us_r_we(us_r_we),
    .us_r_err(us_r_err), .us_r_last(us_r_last), .us_r_data(us_r_data),
    .ds_cmd_valid(ds_cmd_valid), .ds_cmd_ready(ds_cmd_ready), .ds_cmd_tid(ds_cmd_tid),
    .ds_cmd_we(ds_cmd_we), .ds_cmd_addr(ds_cmd_addr), .ds_cmd_len(ds_cmd_len),
    .ds_w_valid(ds_w_valid), .ds_w_ready(ds_w_ready), .ds_w_data(ds_w_data), .ds_w_strb(ds_w_strb),
    .ds_w_last(ds_w_last), .ds_r_valid(ds_r_valid), .ds_r_ready(ds_r_ready), .ds_r_err(ds_r_err),
    .ds_r_data(ds_r_data),
    .csr_valid(csr_valid && csr_addr[7]), .csr_we(csr_we), .csr_addr({1'b0, csr_addr[6:0]}),
    .csr_wdata(csr_wdata), .csr_priv(priv_r), .csr_hit(csr_hit_iommu), .csr_rdata(csr_rdata_iommu),
    .irq(irq_iommu));

  logic [DG_SID_W-1:0] sid_const0;
  assign sid_const0 = '0;

  genvar gm;
  generate
    for (gm = 0; gm < NM; gm++) begin : g_dg
      sf_dg_fm2dg #(.IOVA_W(DG_IOVA_W), .TID_W(DG_TID_W), .LEN_W(DG_LEN_W), .SID_W(DG_SID_W)) u_in (
        .clk(clk), .rst_n(rst_n),
        .m_req_valid(r_req_valid[gm]), .m_req_ready(r_req_ready[gm]), .m_req_we(r_req_we[gm]),
        .m_req_addr(r_req_addr[gm*16 +: 16]), .m_req_wdata(r_req_wdata[gm*32 +: 32]),
        .m_rsp_valid(r_rsp_valid[gm]), .m_rsp_err(r_rsp_err[gm]), .m_rsp_rdata(r_rsp_rdata[gm*32 +: 32]),
        .sid((gm == M_HOST) ? hsid_r : sid_const0),
        .us_cmd_valid(us_cmd_valid[gm]), .us_cmd_ready(us_cmd_ready[gm]),
        .us_cmd_tid(us_cmd_tid[gm*DG_TID_W +: DG_TID_W]), .us_cmd_sid(us_cmd_sid[gm*DG_SID_W +: DG_SID_W]),
        .us_cmd_we(us_cmd_we[gm]), .us_cmd_addr(us_cmd_addr[gm*DG_IOVA_W +: DG_IOVA_W]),
        .us_cmd_len(us_cmd_len[gm*DG_LEN_W +: DG_LEN_W]),
        .us_w_valid(us_w_valid[gm]), .us_w_ready(us_w_ready[gm]),
        .us_w_data(us_w_data[gm*32 +: 32]), .us_w_strb(us_w_strb[gm*4 +: 4]),
        .us_r_valid(us_r_valid[gm]), .us_r_ready(us_r_ready[gm]), .us_r_tid(us_r_tid[gm*DG_TID_W +: DG_TID_W]),
        .us_r_we(us_r_we[gm]), .us_r_err(us_r_err[gm]), .us_r_last(us_r_last[gm]),
        .us_r_data(us_r_data[gm*32 +: 32]));

      sf_dg_dg2fm #(.PA_W(DG_PA_W), .TID_W(DG_TID_W), .LEN_W(DG_LEN_W)) u_out (
        .clk(clk), .rst_n(rst_n),
        .ds_cmd_valid(ds_cmd_valid[gm]), .ds_cmd_ready(ds_cmd_ready[gm]),
        .ds_cmd_tid(ds_cmd_tid[gm*DG_TID_W +: DG_TID_W]), .ds_cmd_we(ds_cmd_we[gm]),
        .ds_cmd_addr(ds_cmd_addr[gm*DG_PA_W +: DG_PA_W]), .ds_cmd_len(ds_cmd_len[gm*DG_LEN_W +: DG_LEN_W]),
        .ds_w_valid(ds_w_valid[gm]), .ds_w_ready(ds_w_ready[gm]),
        .ds_w_data(ds_w_data[gm*32 +: 32]), .ds_w_strb(ds_w_strb[gm*4 +: 4]), .ds_w_last(ds_w_last[gm]),
        .ds_r_valid(ds_r_valid[gm]), .ds_r_ready(ds_r_ready[gm]), .ds_r_err(ds_r_err[gm]),
        .ds_r_data(ds_r_data[gm*32 +: 32]),
        .m_req_valid(m_req_valid[gm]), .m_req_ready(m_req_ready[gm]), .m_req_we(m_req_we[gm]),
        .m_req_addr(m_req_addr[gm*16 +: 16]), .m_req_wdata(m_req_wdata[gm*32 +: 32]),
        .m_rsp_valid(m_rsp_valid[gm]), .m_rsp_err(m_rsp_err[gm]), .m_rsp_rdata(m_rsp_rdata[gm*32 +: 32]));
    end
  endgenerate

  // ---------------- CSR bus ----------------
  logic csr_valid_legacy;
  assign csr_valid_legacy = csr_valid && !csr_addr[7];

  always_comb begin
    csr_hit   = 1'b0;
    csr_rdata = 32'h0;
    if (csr_addr[7])             begin csr_hit = csr_hit_iommu; csr_rdata = csr_rdata_iommu; end
    else if (csr_hit_ctrl)       begin csr_hit = 1'b1; csr_rdata = csr_rdata_ctrl; end
    else if (csr_hit_pm)         begin csr_hit = 1'b1; csr_rdata = csr_rdata_pm;   end
    else if (csr_addr == 8'h0E)  begin csr_hit = 1'b1; csr_rdata = {ext_timeout_count, decode_err_count}; end
  end

  // ---------------- host interface (master 0) ----------------
  sf_host_if u_host (
    .clk(clk), .rst_n(rst_n),
    .host_req(host_req), .host_we(host_we), .host_addr(host_addr), .host_wdata(host_wdata),
    .host_ack(host_ack), .host_rdata(host_rdata), .host_err(host_err),
    .m_req_valid(r_req_valid[M_HOST]), .m_req_ready(r_req_ready[M_HOST]),
    .m_req_we(r_req_we[M_HOST]), .m_req_addr(r_req_addr[M_HOST*16 +: 16]),
    .m_req_wdata(r_req_wdata[M_HOST*32 +: 32]), .m_rsp_valid(r_rsp_valid[M_HOST]),
    .m_rsp_err(r_rsp_err[M_HOST]), .m_rsp_rdata(r_rsp_rdata[M_HOST*32 +: 32]),
    .csr_valid(csr_valid), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata),
    .csr_hit(csr_hit), .csr_rdata(csr_rdata));

  // ---------------- power manager ----------------
  logic pm_vec_en, pm_ten_en, ten_step_allow;
  logic [NT-1:0] ten_computing;
  sf_power_mgr u_pm (
    .clk(clk), .rst_n(rst_n), .therm_alert_async(therm_alert),
    .ten_computing(|ten_computing),
    .csr_valid(csr_valid_legacy), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata),
    .csr_hit(csr_hit_pm), .csr_rdata(csr_rdata_pm),
    .vec_en(pm_vec_en), .ten_en(pm_ten_en), .ten_step_allow(ten_step_allow));

  // ---------------- control core (master 1, slave 0) ----------------
  logic          dma_start, dma_done, dma_err, dma_busy;
  logic [15:0]   dma_src, dma_dst, dma_len;
  logic [NV-1:0] vec_start, vec_done, vec_err, vec_busy;
  logic [NT-1:0] ten_start, ten_done, ten_err, ten_busy;
  logic [3:0]    eng_op;
  logic          eng_acc;
  logic [15:0]   eng_len, eng_a, eng_b, eng_c;
  logic          ctrl_busy, ctrl_halted;
  logic [15:0]   done_count, err_count;

  sf_control_core #(.NV(NV), .NT(NT)) u_ctrl (
    .clk(clk), .rst_n(rst_n),
    .m_req_valid(r_req_valid[M_CTRL]), .m_req_ready(r_req_ready[M_CTRL]),
    .m_req_we(r_req_we[M_CTRL]), .m_req_addr(r_req_addr[M_CTRL*16 +: 16]),
    .m_req_wdata(r_req_wdata[M_CTRL*32 +: 32]), .m_rsp_valid(r_rsp_valid[M_CTRL]),
    .m_rsp_err(r_rsp_err[M_CTRL]), .m_rsp_rdata(r_rsp_rdata[M_CTRL*32 +: 32]),
    .s_req_valid(s_req_valid[S_CMD]), .s_req_ready(s_req_ready[S_CMD]),
    .s_req_we(s_req_we[S_CMD]), .s_req_addr(s_req_addr[S_CMD*16 +: 16]),
    .s_req_wdata(s_req_wdata[S_CMD*32 +: 32]), .s_rsp_valid(s_rsp_valid[S_CMD]),
    .s_rsp_err(s_rsp_err[S_CMD]), .s_rsp_rdata(s_rsp_rdata[S_CMD*32 +: 32]),
    .csr_valid(csr_valid_legacy), .csr_we(csr_we), .csr_addr(csr_addr), .csr_wdata(csr_wdata),
    .csr_hit(csr_hit_ctrl), .csr_rdata(csr_rdata_ctrl),
    .dma_start(dma_start), .dma_src(dma_src), .dma_dst(dma_dst), .dma_len(dma_len),
    .dma_done(dma_done), .dma_err(dma_err),
    .vec_start(vec_start), .eng_op(eng_op), .eng_acc(eng_acc), .eng_len(eng_len),
    .eng_a(eng_a), .eng_b(eng_b), .eng_c(eng_c), .vec_done(vec_done), .vec_err(vec_err),
    .ten_start(ten_start), .ten_done(ten_done), .ten_err(ten_err),
    .pm_vec_en(pm_vec_en), .pm_ten_en(pm_ten_en),
    .irq(irq_ctrl), .busy(ctrl_busy), .halted(ctrl_halted),
    .done_count(done_count), .err_count(err_count));

  assign irq = irq_ctrl | irq_iommu;

  // ---------------- DMA (master 2) ----------------
  sf_dma u_dma (
    .clk(clk), .rst_n(rst_n), .start(dma_start), .src(dma_src), .dst(dma_dst),
    .len(dma_len), .done(dma_done), .err(dma_err), .busy(dma_busy),
    .m_req_valid(r_req_valid[M_DMA]), .m_req_ready(r_req_ready[M_DMA]),
    .m_req_we(r_req_we[M_DMA]), .m_req_addr(r_req_addr[M_DMA*16 +: 16]),
    .m_req_wdata(r_req_wdata[M_DMA*32 +: 32]), .m_rsp_valid(r_rsp_valid[M_DMA]),
    .m_rsp_err(r_rsp_err[M_DMA]), .m_rsp_rdata(r_rsp_rdata[M_DMA*32 +: 32]));

  // ---------------- vector clusters ----------------
  genvar gv;
  generate
    for (gv = 0; gv < NV; gv++) begin : g_vec
      sf_vector_cluster #(.DEPTH(VBANK_DEPTH)) u_vec (
        .clk(clk), .rst_n(rst_n), .test_mode(test_mode),
        .req_valid(s_req_valid[S_VEC0+gv]), .req_ready(s_req_ready[S_VEC0+gv]),
        .req_we(s_req_we[S_VEC0+gv]), .req_addr(s_req_addr[(S_VEC0+gv)*16 +: 16]),
        .req_wdata(s_req_wdata[(S_VEC0+gv)*32 +: 32]), .rsp_valid(s_rsp_valid[S_VEC0+gv]),
        .rsp_err(s_rsp_err[S_VEC0+gv]), .rsp_rdata(s_rsp_rdata[(S_VEC0+gv)*32 +: 32]),
        .cmd_start(vec_start[gv]), .cmd_op(eng_op), .cmd_len(eng_len),
        .cmd_a(eng_a), .cmd_b(eng_b), .cmd_c(eng_c),
        .cmd_done(vec_done[gv]), .cmd_err(vec_err[gv]), .busy(vec_busy[gv]));
    end
  endgenerate

  // ---------------- tensor clusters ----------------
  genvar gt;
  generate
    for (gt = 0; gt < NT; gt++) begin : g_ten
      sf_tensor_cluster #(.DEPTH(TBANK_DEPTH)) u_ten (
        .clk(clk), .rst_n(rst_n), .test_mode(test_mode),
        .req_valid(s_req_valid[S_TEN0+gt]), .req_ready(s_req_ready[S_TEN0+gt]),
        .req_we(s_req_we[S_TEN0+gt]), .req_addr(s_req_addr[(S_TEN0+gt)*16 +: 16]),
        .req_wdata(s_req_wdata[(S_TEN0+gt)*32 +: 32]), .rsp_valid(s_rsp_valid[S_TEN0+gt]),
        .rsp_err(s_rsp_err[S_TEN0+gt]), .rsp_rdata(s_rsp_rdata[(S_TEN0+gt)*32 +: 32]),
        .cmd_start(ten_start[gt]), .cmd_acc(eng_acc), .cmd_a(eng_a), .cmd_b(eng_b),
        .cmd_c(eng_c), .cmd_done(ten_done[gt]), .cmd_err(ten_err[gt]), .busy(ten_busy[gt]),
        .computing(ten_computing[gt]), .step_allow(ten_step_allow));
    end
  endgenerate

  // ---------------- scratchpad ----------------
  sf_scratchpad #(.DEPTH(SCRATCH_DEPTH)) u_scratch (
    .clk(clk), .rst_n(rst_n),
    .req_valid(s_req_valid[S_SCR]), .req_ready(s_req_ready[S_SCR]), .req_we(s_req_we[S_SCR]),
    .req_addr(s_req_addr[S_SCR*16 +: 16]), .req_wdata(s_req_wdata[S_SCR*32 +: 32]),
    .rsp_valid(s_rsp_valid[S_SCR]), .rsp_err(s_rsp_err[S_SCR]),
    .rsp_rdata(s_rsp_rdata[S_SCR*32 +: 32]));

  // ---------------- external memory ----------------
  sf_ext_mem_if u_extmem (
    .clk(clk), .rst_n(rst_n),
    .req_valid(s_req_valid[S_EXT]), .req_ready(s_req_ready[S_EXT]), .req_we(s_req_we[S_EXT]),
    .req_addr(s_req_addr[S_EXT*16 +: 16]), .req_wdata(s_req_wdata[S_EXT*32 +: 32]),
    .rsp_valid(s_rsp_valid[S_EXT]), .rsp_err(s_rsp_err[S_EXT]),
    .rsp_rdata(s_rsp_rdata[S_EXT*32 +: 32]),
    .ext_req(ext_req), .ext_we(ext_we), .ext_addr(ext_addr), .ext_wdata(ext_wdata),
    .ext_ack(ext_ack), .ext_rdata(ext_rdata), .timeout_count(ext_timeout_count));

  // ---------------- test / RAS ----------------
  logic        any_engine_busy;
  logic [30:0] ras_status;
  assign any_engine_busy = dma_busy | (|vec_busy) | (|ten_busy);
  assign ras_status = {done_count[7:0], err_count[7:0], decode_err_count[7:0],
                       ext_timeout_count[3:0], ctrl_halted, irq, ctrl_busy | any_engine_busy};
  sf_test_ras u_ras (
    .clk(clk), .rst_n(rst_n), .status_in(ras_status),
    .tck(tck), .tms(tms), .tdi(tdi), .trst_n(trst_n), .tdo(tdo));
endmodule
