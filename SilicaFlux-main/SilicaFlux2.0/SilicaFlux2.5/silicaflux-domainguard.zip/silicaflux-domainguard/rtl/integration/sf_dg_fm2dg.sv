// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | sf_dg_fm2dg
// Adapter: SilicaFlux fabric-master protocol  ->  DG-Lite upstream port.
//
//   fabric master : req valid/ready, {we, 16-bit WORD addr, wdata}; one outstanding;
//                   response pulse {err, rdata}.
//   DG-Lite       : cmd / W / response channels, BYTE address, burst length, tid, sid.
//
// A fabric access becomes a 1-beat burst at byte address {word_addr, 2'b00}; the
// stand-in's word address is therefore an IOVA word address. The stream id comes
// from TRUSTED logic in the die top (never from the requester).
// -----------------------------------------------------------------------------
module sf_dg_fm2dg #(
  parameter int IOVA_W = 18,
  parameter int TID_W  = 2,
  parameter int LEN_W  = 4,
  parameter int SID_W  = 2
) (
  input  logic               clk,
  input  logic               rst_n,
  // fabric-master side (as driven by sf_dma / sf_host_if / sf_control_core)
  input  logic               m_req_valid,
  output logic               m_req_ready,
  input  logic               m_req_we,
  input  logic [15:0]        m_req_addr,
  input  logic [31:0]        m_req_wdata,
  output logic               m_rsp_valid,
  output logic               m_rsp_err,
  output logic [31:0]        m_rsp_rdata,
  input  logic [SID_W-1:0]   sid,
  // DG-Lite upstream
  output logic               us_cmd_valid,
  input  logic               us_cmd_ready,
  output logic [TID_W-1:0]   us_cmd_tid,
  output logic [SID_W-1:0]   us_cmd_sid,
  output logic               us_cmd_we,
  output logic [IOVA_W-1:0]  us_cmd_addr,
  output logic [LEN_W-1:0]   us_cmd_len,
  output logic               us_w_valid,
  input  logic               us_w_ready,
  output logic [31:0]        us_w_data,
  output logic [3:0]         us_w_strb,
  input  logic               us_r_valid,
  output logic               us_r_ready,
  input  logic [TID_W-1:0]   us_r_tid,
  input  logic               us_r_we,
  input  logic               us_r_err,
  input  logic               us_r_last,
  input  logic [31:0]        us_r_data
);
  logic        busy, we_q, w_sent;
  logic [31:0] wdata_q;
  logic [SID_W-1:0] sid_q;

  assign us_cmd_valid = m_req_valid && !busy;
  assign m_req_ready  = m_req_valid && !busy && us_cmd_ready;
  assign us_cmd_tid   = '0;
  assign us_cmd_sid   = sid;
  assign us_cmd_we    = m_req_we;
  assign us_cmd_addr  = {m_req_addr, 2'b00};
  assign us_cmd_len   = '0;

  assign us_w_valid   = busy && we_q && !w_sent;
  assign us_w_data    = wdata_q;
  assign us_w_strb    = 4'hF;
  assign us_r_ready   = busy;

  assign m_rsp_valid  = busy && us_r_valid;
  assign m_rsp_err    = us_r_err;
  assign m_rsp_rdata  = us_r_data;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      busy <= 1'b0; we_q <= 1'b0; w_sent <= 1'b0; wdata_q <= '0; sid_q <= '0;
    end else begin
      if (!busy) begin
        if (m_req_valid && us_cmd_ready) begin
          busy    <= 1'b1;
          we_q    <= m_req_we;
          wdata_q <= m_req_wdata;
          w_sent  <= 1'b0;
        end
      end else begin
        if (us_w_valid && us_w_ready) w_sent <= 1'b1;
        if (us_r_valid)               busy   <= 1'b0;
      end
    end
  end

  // tid/last/we are not needed by a one-outstanding master
  logic unused_ok;
  assign unused_ok = &{1'b0, us_r_tid, us_r_we, us_r_last, sid_q};
endmodule
