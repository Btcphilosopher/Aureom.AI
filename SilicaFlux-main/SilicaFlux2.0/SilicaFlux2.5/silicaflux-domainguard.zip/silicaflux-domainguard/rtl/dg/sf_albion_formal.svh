// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | sf_albion_formal.svh
// Formal properties for sf_albion_iommu. Included INSIDE the module only when
// SF_DG_FORMAL is defined (never in simulation or synthesis).
//
// Environment: every primary input is free. In particular the UPSTREAM side is
// completely unconstrained (protocol violations included) and the CSR bus is
// an arbitrary stream of privileged and unprivileged accesses. The only
// assumption is that reset is asserted in the first cycle.
//
// Properties, by number (see docs/05_SECURITY_TESTING_REPORT.md):
//   P1  grant soundness: independent re-derivation of every grant
//   P2  authority state changes only on a privileged CSR write
//   P3  table well-formedness: alignment, order, no overlap
//   P4  stale-translation invariant: outside a drain every in-flight burst is
//       still backed by the unchanged entry it was authorised under
//   P5  protected-memory theorem: an accepted downstream write beat lands in a
//       page covered by a ghost-recorded write authorisation
//   P6  drain: checks never start while draining; a drain ends only when no
//       burst holds authority
//   P7  reset: deny-all secure state, interface inert
//   P8  burst containment: a granted burst never leaves its 4 KiB page
//   C*  cover points (non-vacuity)
// -----------------------------------------------------------------------------
  localparam int F_BYTES = DATA_W / 8;
  localparam int F_BS    = $clog2(F_BYTES);

  // ---- environment: reset asserted in the first cycle only
  reg f_init = 1'b1;
  always @(posedge clk) f_init <= 1'b0;
  always @(*) if (f_init) assume (!rst_n);

  reg f_pv = 1'b0;
  always @(posedge clk) f_pv <= 1'b1;

  // ---- history
  localparam int F_CFG_W = 1 + NUM_DOMAINS*3 + NUM_PORTS*NUM_STREAMS*(1+DOM_W) +
                           NUM_ENTRIES*(1 + DOM_W + IPN_W + PPN_W + ORD_W + 2);
  wire [F_CFG_W-1:0] f_cfg = {glob_en, dom_en, dom_rd, dom_wr, ctx_valid, ctx_dom,
                              ent_valid, ent_dom, ent_ipn, ent_ppn, ent_ord, ent_r, ent_w};
  reg [F_CFG_W-1:0] f_cfg_q;
  reg               f_rst_q, f_privwr_q, f_blk_q;
  reg [NUM_PORTS-1:0] f_act_q, f_auth_q;
  always @(posedge clk) begin
    f_cfg_q    <= f_cfg;
    f_rst_q    <= rst_n;
    f_privwr_q <= csr_valid && csr_priv && csr_we;
    f_blk_q    <= blk;
    f_act_q    <= p_act;
    f_auth_q   <= p_auth;
  end

  // ---- ghost authorisation record, captured in the CHECK cycle of each port
  reg [NUM_PORTS*ENT_W-1:0] g_idx;
  reg [NUM_PORTS*DOM_W-1:0] g_dom;
  reg [NUM_PORTS*SID_W-1:0] g_sid;
  reg [NUM_PORTS*IPN_W-1:0] g_ipn;
  reg [NUM_PORTS*PPN_W-1:0] g_ppn;
  reg [NUM_PORTS*ORD_W-1:0] g_ord;
  reg [NUM_PORTS-1:0]       g_we, g_perm, g_ctxok, g_entdom_ok;

  integer fp, fe, fe2;
  reg [SID_W-1:0]   f_sid;
  reg               f_ctxv, f_we, f_any, f_cov, f_perm, f_ovl;
  reg [DOM_W-1:0]   f_ctxd;
  reg [IOVA_W-1:0]  f_iova;
  reg [LEN_W-1:0]   f_len;
  reg [IPN_W-1:0]   f_ipn, f_eipn;
  reg [PPN_W-1:0]   f_eppn, f_ppn_sel;
  reg [ORD_W-1:0]   f_ord;
  reg [PA_W-1:0]    f_pa;
  reg [31:0]        f_nbytes, f_off;
  reg [PPN_W-1:0]   f_addr_ppn;
  reg [IPN_W-1:0]   f_lo1, f_lo2;
  reg [31:0]        f_hi1, f_hi2;

  // ---- ghost capture (state, not combinational)
  always @(posedge clk) begin
    for (fp = 0; fp < NUM_PORTS; fp = fp + 1) begin
      if (p_act[fp] && !p_auth[fp]) begin                 // port is in CHECK
        g_idx [fp*ENT_W +: ENT_W] <= p_chk_idx[fp*ENT_W +: ENT_W];
        g_dom [fp*DOM_W +: DOM_W] <= p_chk_dom[fp*DOM_W +: DOM_W];
        g_sid [fp*SID_W +: SID_W] <= p_chk_sid[fp*SID_W +: SID_W];
        g_ipn [fp*IPN_W +: IPN_W] <= ent_ipn[p_chk_idx[fp*ENT_W +: ENT_W]*IPN_W +: IPN_W];
        g_ppn [fp*PPN_W +: PPN_W] <= ent_ppn[p_chk_idx[fp*ENT_W +: ENT_W]*PPN_W +: PPN_W];
        g_ord [fp*ORD_W +: ORD_W] <= ent_ord[p_chk_idx[fp*ENT_W +: ENT_W]*ORD_W +: ORD_W];
        g_we  [fp]                <= p_chk_we[fp];
        g_perm[fp]                <= p_chk_we[fp] ? (ent_w[p_chk_idx[fp*ENT_W +: ENT_W]] && dom_wr[p_chk_dom[fp*DOM_W +: DOM_W]])
                                                  : (ent_r[p_chk_idx[fp*ENT_W +: ENT_W]] && dom_rd[p_chk_dom[fp*DOM_W +: DOM_W]]);
        g_entdom_ok[fp]           <= (ent_dom[p_chk_idx[fp*ENT_W +: ENT_W]*DOM_W +: DOM_W] == p_chk_dom[fp*DOM_W +: DOM_W]);
      end
    end
  end

  `ifndef F_SKIP_P1
// ---- P1 / P8: independent re-derivation of every grant (any time the checker says "grant")
  always @(*) begin
    if (rst_n) begin
      for (fp = 0; fp < NUM_PORTS; fp = fp + 1) begin
        f_sid   = p_chk_sid[fp*SID_W +: SID_W];
        f_we    = p_chk_we[fp];
        f_iova  = p_chk_addr[fp*IOVA_W +: IOVA_W];
        f_len   = p_chk_len[fp*LEN_W +: LEN_W];
        f_ctxv  = (f_sid < NUM_STREAMS) && ctx_valid[fp*NUM_STREAMS + f_sid];
        f_ctxd  = ctx_dom[(fp*NUM_STREAMS + f_sid)*DOM_W +: DOM_W];
        f_ipn   = f_iova[IOVA_W-1:12];
        f_off   = {20'd0, f_iova[11:0]};
        f_nbytes = ({{(32-LEN_W){1'b0}}, f_len} + 32'd1) << F_BS;
        if (p_chk_grant[fp]) begin
          assert (glob_en);
          assert (f_ctxv);                                   // the (port,stream) is bound
          assert (f_ctxd == p_chk_dom[fp*DOM_W +: DOM_W]);   // checker used the BOUND domain
          assert (dom_en[f_ctxd]);
          assert ((f_iova & (F_BYTES - 1)) == 0);            // beat aligned
          assert (f_off + f_nbytes <= 32'd4096);             // P8: inside one 4 KiB page
          assert (p_chk_pa[fp*PA_W +: 12] == f_iova[11:0]);  // page offset preserved
          f_any = 1'b0;
          for (fe = 0; fe < NUM_ENTRIES; fe = fe + 1) begin
            f_eipn = ent_ipn[fe*IPN_W +: IPN_W];
            f_eppn = ent_ppn[fe*PPN_W +: PPN_W];
            f_ord  = ent_ord[fe*ORD_W +: ORD_W];
            f_cov  = ent_valid[fe] && (ent_dom[fe*DOM_W +: DOM_W] == f_ctxd) &&
                     ((f_ipn >> f_ord) == (f_eipn >> f_ord));
            f_perm = f_we ? (ent_w[fe] && dom_wr[f_ctxd]) : (ent_r[fe] && dom_rd[f_ctxd]);
            f_ppn_sel = ((f_eppn >> f_ord) << f_ord) | (f_ipn & ((1 << f_ord) - 1));
            f_pa   = {f_ppn_sel, f_iova[11:0]};
            if (f_cov && f_perm && (f_pa == p_chk_pa[fp*PA_W +: PA_W])) f_any = 1'b1;
          end
          assert (f_any);   // P1: some valid entry of the bound domain covers, permits, and yields exactly this PA
        end
      end
    end
  end
`endif

  `ifndef F_SKIP_P2
// ---- P2: authority state changes only on a privileged CSR write
  always @(*) begin
    if (f_pv && rst_n && f_rst_q && !f_privwr_q) assert (f_cfg == f_cfg_q);
  end
`endif

  `ifndef F_SKIP_P3
// ---- P3: table well-formedness
  always @(*) begin
    if (rst_n) begin
      for (fe = 0; fe < NUM_ENTRIES; fe = fe + 1) begin
        if (ent_valid[fe]) begin
          assert (ent_ord[fe*ORD_W +: ORD_W] <= MAX_ORDER);
          assert ((ent_ipn[fe*IPN_W +: IPN_W] & ((1 << ent_ord[fe*ORD_W +: ORD_W]) - 1)) == 0);
          assert ((ent_ppn[fe*PPN_W +: PPN_W] & ((1 << ent_ord[fe*ORD_W +: ORD_W]) - 1)) == 0);
          assert (ent_dom[fe*DOM_W +: DOM_W] < NUM_DOMAINS);
          for (fe2 = fe + 1; fe2 < NUM_ENTRIES; fe2 = fe2 + 1) begin
            if (ent_valid[fe2] && ent_dom[fe*DOM_W +: DOM_W] == ent_dom[fe2*DOM_W +: DOM_W]) begin
              f_hi1 = {{(32-IPN_W){1'b0}}, ent_ipn[fe*IPN_W +: IPN_W]}  + (32'd1 << ent_ord[fe*ORD_W +: ORD_W]) - 32'd1;
              f_hi2 = {{(32-IPN_W){1'b0}}, ent_ipn[fe2*IPN_W +: IPN_W]} + (32'd1 << ent_ord[fe2*ORD_W +: ORD_W]) - 32'd1;
              assert ((f_hi1 < {{(32-IPN_W){1'b0}}, ent_ipn[fe2*IPN_W +: IPN_W]}) ||
                      (f_hi2 < {{(32-IPN_W){1'b0}}, ent_ipn[fe*IPN_W +: IPN_W]}));
            end
          end
        end
      end
      for (fp = 0; fp < NUM_PORTS*NUM_STREAMS; fp = fp + 1)
        if (ctx_valid[fp]) assert (ctx_dom[fp*DOM_W +: DOM_W] < NUM_DOMAINS);
    end
  end
`endif

  `ifndef F_SKIP_P4
// ---- P4: stale-translation invariant
  // Outside a drain, every burst that holds authority is still backed by the very
  // entry (and domain / context / flags) it was authorised under.
  always @(*) begin
    if (rst_n && !blk) begin
      for (fp = 0; fp < NUM_PORTS; fp = fp + 1) begin
        if (p_auth[fp]) begin
          f_sid = g_sid[fp*SID_W +: SID_W];
          assert (glob_en);
          assert (ctx_valid[fp*NUM_STREAMS + f_sid]);
          assert (ctx_dom[(fp*NUM_STREAMS + f_sid)*DOM_W +: DOM_W] == g_dom[fp*DOM_W +: DOM_W]);
          assert (dom_en[g_dom[fp*DOM_W +: DOM_W]]);
          assert (ent_valid[g_idx[fp*ENT_W +: ENT_W]]);
          assert (ent_dom[g_idx[fp*ENT_W +: ENT_W]*DOM_W +: DOM_W] == g_dom[fp*DOM_W +: DOM_W]);
          assert (ent_ipn[g_idx[fp*ENT_W +: ENT_W]*IPN_W +: IPN_W] == g_ipn[fp*IPN_W +: IPN_W]);
          assert (ent_ppn[g_idx[fp*ENT_W +: ENT_W]*PPN_W +: PPN_W] == g_ppn[fp*PPN_W +: PPN_W]);
          assert (ent_ord[g_idx[fp*ENT_W +: ENT_W]*ORD_W +: ORD_W] == g_ord[fp*ORD_W +: ORD_W]);
          if (g_we[fp]) begin
            assert (ent_w[g_idx[fp*ENT_W +: ENT_W]]);
            assert (dom_wr[g_dom[fp*DOM_W +: DOM_W]]);
          end else begin
            assert (ent_r[g_idx[fp*ENT_W +: ENT_W]]);
            assert (dom_rd[g_dom[fp*DOM_W +: DOM_W]]);
          end
        end
      end
    end
  end
`endif

  `ifndef F_SKIP_P5
// ---- P5: protected-memory theorem
  // A downstream write beat that is accepted must (a) belong to a burst authorised
  // for WRITE, (b) with the entry's and domain's write permission, (c) under an entry
  // of the domain the stream was bound to, (d) and land in the physical region that
  // entry maps. Everything is evaluated against the ghost record taken at check time.
  // State form (inductive): whenever a burst holds authority, its registered PA page lies
  // inside the region of the ghost entry, with the permission and domain recorded at check.
  always @(*) begin
    if (rst_n) begin
      for (fp = 0; fp < NUM_PORTS; fp = fp + 1) begin
        if (p_auth[fp]) begin
          f_addr_ppn = ds_cmd_addr[fp*PA_W + 12 +: PPN_W];
          assert (g_perm[fp]);
          assert (g_entdom_ok[fp]);
          assert (g_we[fp] == ds_cmd_we[fp]);
          assert ((f_addr_ppn >> g_ord[fp*ORD_W +: ORD_W]) == (g_ppn[fp*PPN_W +: PPN_W] >> g_ord[fp*ORD_W +: ORD_W]));
        end
      end
    end
  end
  // Event form: an accepted downstream write beat or command.
  always @(*) begin
    if (rst_n) begin
      for (fp = 0; fp < NUM_PORTS; fp = fp + 1) begin
        if (ds_w_valid[fp] && ds_w_ready[fp]) begin
          f_addr_ppn = ds_cmd_addr[fp*PA_W + 12 +: PPN_W];
          assert (p_auth[fp]);
          assert (g_we[fp]);
          assert (g_perm[fp]);
          assert (g_entdom_ok[fp]);
          assert ((f_addr_ppn >> g_ord[fp*ORD_W +: ORD_W]) == (g_ppn[fp*PPN_W +: PPN_W] >> g_ord[fp*ORD_W +: ORD_W]));
        end
        if (ds_cmd_valid[fp]) begin
          assert (p_auth[fp]);
          assert (g_perm[fp] && g_entdom_ok[fp]);
          assert (ds_cmd_we[fp] == g_we[fp]);
        end
      end
    end
  end
`endif

  `ifndef F_SKIP_P6
// ---- P6: drain semantics
  always @(*) begin
    if (f_pv && rst_n && f_rst_q) begin
      for (fp = 0; fp < NUM_PORTS; fp = fp + 1) begin
        // a port is in CHECK now only if no drain was active in the previous cycle
        if (p_act[fp] && !p_auth[fp] && !f_act_q[fp]) assert (!f_blk_q);
      end
      // a drain ends only when nobody holds authority (or may be about to use it)
      if (f_blk_q && !blk) assert (f_act_q == {NUM_PORTS{1'b0}});
    end
  end
`endif

  `ifndef F_SKIP_P7
// ---- P7: reset state is the secure default; interface is inert
  always @(*) begin
    if (!rst_n) begin
      assert (!glob_en);
      assert (dom_en == {NUM_DOMAINS{1'b0}});
      assert (ctx_valid == {(NUM_PORTS*NUM_STREAMS){1'b0}});
      assert (ent_valid == {NUM_ENTRIES{1'b0}});
      assert (!blk);
      assert (ds_cmd_valid == {NUM_PORTS{1'b0}});
      assert (ds_w_valid == {NUM_PORTS{1'b0}});
      assert (us_r_valid == {NUM_PORTS{1'b0}});
      assert (us_cmd_ready == {NUM_PORTS{1'b0}});
      assert (us_w_ready == {NUM_PORTS{1'b0}});
      assert (ds_r_ready == {NUM_PORTS{1'b0}});
      assert (!irq);
    end
  end
`endif

  `ifndef F_SKIP_COV
// ---- cover points: the properties above are not vacuous
  always @(*) begin
    if (rst_n) begin
      cover (|(ds_cmd_valid & ds_cmd_we));                                   // C1 a granted WRITE command is issued downstream
      cover (|(ds_w_valid & ds_w_ready));                                     // C2 a write beat is accepted
      cover (|us_r_err && |us_r_valid);                                       // C3 an error response is produced
      cover (f_blk_q && !blk && f_pv);                                        // C4 a drain completes
      cover (blk && |p_auth);                                                 // C5 a drain waits for an in-flight burst
      cover (|p_chk_grant && |ent_valid && glob_en);                          // C6 grant with real table
      cover (|(p_flt_req & p_flt_gnt));                                       // C7 a fault is logged
      cover (f_pv && f_cfg != f_cfg_q && f_privwr_q && rst_n);                // C8 admin changes authority state
    end
  end
`endif


`ifdef F_COVER_SCRIPT
  // ---- cover-run guidance (never used in proof runs): a legal 9-cycle admin bring-up,
  // then the CSR bus is free again. Port 1 is held quiet to keep the search small.
  reg [5:0] f_step = 6'd0;
  always @(posedge clk) if (f_step != 6'd63) f_step <= f_step + 6'd1;
  always @(*) begin
    if (!f_init) begin
      assume (!us_cmd_valid[NUM_PORTS-1] || NUM_PORTS == 1);
      case (f_step)
        6'd1: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h04 && csr_wdata == 32'h1);              // CTRL.enable
        6'd2: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h0C && csr_wdata == 32'h0000_0701);      // STG_DOM: dom1 en rd wr
        6'd3: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h0D && csr_wdata == 32'h0000_0006);      // CMD DOM_SET
        6'd4: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h0B && csr_wdata == 32'h0001_0000);      // STG_CTX: port0 sid0 -> dom1
        6'd5: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h0D && csr_wdata == 32'h0000_0004);      // CMD CTX_SET
        6'd6: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h08 && csr_wdata == 32'h1);              // STG_IPN = 1
        6'd7: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h09 && csr_wdata == 32'h2);              // STG_PPN = 2
        6'd8: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h0A && csr_wdata == 32'h0001_0003);      // STG_ATTR dom1 R W
        6'd9: assume (csr_valid && csr_we && csr_priv && csr_addr == 8'h0D && csr_wdata == 32'h0000_0001);      // CMD ENT_SET idx0
        default: ;
      endcase
    end
  end
`endif
