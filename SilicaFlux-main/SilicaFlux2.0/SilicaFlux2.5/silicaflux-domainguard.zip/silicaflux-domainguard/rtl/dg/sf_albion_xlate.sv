// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | sf_albion_xlate
//
// Pure combinational translation + permission checker for ONE burst request.
// No state. One instance per port. This is the only place an authorisation
// decision is made; everything downstream of it is gated by `grant`.
//
// Decision order (first failing rule wins; every failure is a denial):
//   1. IOMMU globally disabled                      -> DISABLED
//   2. (port,stream) has no context binding         -> NO_CTX
//   3. bound domain disabled                        -> DISABLED
//   4. start address not aligned to beat size       -> MISALIGN
//   5. burst crosses a 4 KiB boundary               -> PAGE_CROSS
//   6. no valid entry of the bound domain covers it -> UNMAPPED
//   7. entry (or domain cap) lacks R / W permission -> PERM_R / PERM_W
//   otherwise                                       -> grant, pa = translation
//
// Entries are naturally aligned regions of 2^order 4 KiB pages. Commit-time
// rules (see sf_albion_iommu) guarantee at most one entry of a domain covers
// any page; if that invariant were ever violated the lowest index still wins,
// deterministically, and permission is evaluated on that same entry.
// -----------------------------------------------------------------------------
`include "sf_albion_defs.svh"
module sf_albion_xlate #(
  parameter int NUM_DOMAINS = 8,
  parameter int NUM_STREAMS = 4,
  parameter int NUM_ENTRIES = 16,
  parameter int IOVA_W      = 32,
  parameter int PA_W        = 40,
  parameter int DATA_W      = 32,
  parameter int LEN_W       = 4,
  parameter int MAX_ORDER   = 8,
  // derived
  parameter int DOM_W   = (NUM_DOMAINS > 1) ? $clog2(NUM_DOMAINS) : 1,
  parameter int SID_W   = (NUM_STREAMS > 1) ? $clog2(NUM_STREAMS) : 1,
  parameter int ENT_W   = (NUM_ENTRIES > 1) ? $clog2(NUM_ENTRIES) : 1,
  parameter int IPN_W   = IOVA_W - 12,
  parameter int PPN_W   = PA_W - 12,
  parameter int ORD_W   = (MAX_ORDER > 0) ? $clog2(MAX_ORDER + 1) : 1
) (
  // configuration state (read-only here)
  input  logic                         glob_en,
  input  logic [NUM_DOMAINS-1:0]       dom_en,
  input  logic [NUM_DOMAINS-1:0]       dom_rd,
  input  logic [NUM_DOMAINS-1:0]       dom_wr,
  input  logic [NUM_STREAMS-1:0]       ctx_valid,          // this port's bindings
  input  logic [NUM_STREAMS*DOM_W-1:0] ctx_dom,
  input  logic [NUM_ENTRIES-1:0]       ent_valid,
  input  logic [NUM_ENTRIES*DOM_W-1:0] ent_dom,
  input  logic [NUM_ENTRIES*IPN_W-1:0] ent_ipn,
  input  logic [NUM_ENTRIES*PPN_W-1:0] ent_ppn,
  input  logic [NUM_ENTRIES*ORD_W-1:0] ent_ord,
  input  logic [NUM_ENTRIES-1:0]       ent_r,
  input  logic [NUM_ENTRIES-1:0]       ent_w,
  // request
  input  logic [SID_W-1:0]             sid,
  input  logic                         we,
  input  logic [IOVA_W-1:0]            iova,
  input  logic [LEN_W-1:0]             len,                // beats - 1
  // decision
  output logic                         grant,
  output logic [3:0]                   fault,
  output logic [PA_W-1:0]              pa,
  output logic [DOM_W-1:0]             dom,
  output logic                         dom_v,
  output logic [ENT_W-1:0]             ent_idx
);
  localparam int BYTES      = DATA_W / 8;
  localparam int BEAT_SHIFT = $clog2(BYTES);
  localparam int NB_W       = LEN_W + BEAT_SHIFT + 1;   // width of burst size in bytes
  localparam int SUM_W      = 14;                       // offset(12b) + size(<=4096) never overflows 14b

  logic [11:0]         off;
  logic [IPN_W-1:0]    ipn;
  logic                misaligned, crosses;
  logic [SUM_W-1:0]    end_sum;
  logic [NB_W-1:0]     nbytes;

  logic                sid_ok;
  logic [SID_W-1:0]    sid_i;
  logic                hit;
  logic [ENT_W-1:0]    hit_idx;
  logic [PPN_W-1:0]    om_p;      // same, PPN width
  logic [PPN_W-1:0]    ppn_sel;
  logic                perm_ok;
  logic [PPN_W-1:0]    e_ppn;
  logic [ORD_W-1:0]    e_ord;
  logic [IPN_W-1:0]    mk;

  always_comb begin
    off    = iova[11:0];
    ipn    = iova[IOVA_W-1:12];
    // len+1 computed with widening so len = all-ones is a full-size burst
    nbytes = (NB_W'(len) + NB_W'(1)) << BEAT_SHIFT;
    end_sum = SUM_W'(off) + SUM_W'(nbytes);
    crosses = (end_sum > SUM_W'(4096));
    misaligned = 1'b0;
    for (int b = 0; b < BEAT_SHIFT; b++) if (iova[b]) misaligned = 1'b1;

    // ---- context / domain resolution ----
    sid_ok = (32'(sid) < NUM_STREAMS);
    sid_i  = sid_ok ? sid : '0;
    dom_v  = sid_ok && ctx_valid[sid_i];
    dom    = ctx_dom[sid_i*DOM_W +: DOM_W];

    // ---- associative lookup, lowest matching index wins ----
    hit     = 1'b0;
    hit_idx = '0;
    e_ppn   = '0;
    e_ord   = '0;
    for (int e = 0; e < NUM_ENTRIES; e++) begin
      mk = ~({IPN_W{1'b1}} << ent_ord[e*ORD_W +: ORD_W]);   // low `order` bits set
      if (!hit && ent_valid[e] && dom_v && (ent_dom[e*DOM_W +: DOM_W] == dom) &&
          (((ipn ^ ent_ipn[e*IPN_W +: IPN_W]) & ~mk) == '0)) begin
        hit     = 1'b1;
        hit_idx = ENT_W'(e);
        e_ppn   = ent_ppn[e*PPN_W +: PPN_W];
        e_ord   = ent_ord[e*ORD_W +: ORD_W];
      end
    end

    om_p    = ~({PPN_W{1'b1}} << e_ord);
    ppn_sel = (e_ppn & ~om_p) | (PPN_W'(ipn) & om_p);
    pa      = {ppn_sel, off};
    ent_idx = hit_idx;

    perm_ok = we ? (ent_w[hit_idx] && dom_wr[dom]) : (ent_r[hit_idx] && dom_rd[dom]);

    // ---- decision ----
    fault = `SF_DG_F_NONE;
    if      (!glob_en)        fault = `SF_DG_F_DISABLED;
    else if (!dom_v)          fault = `SF_DG_F_NO_CTX;
    else if (!dom_en[dom])    fault = `SF_DG_F_DISABLED;
    else if (misaligned)      fault = `SF_DG_F_MISALIGN;
    else if (crosses)         fault = `SF_DG_F_PAGE_CROSS;
    else if (!hit)            fault = `SF_DG_F_UNMAPPED;
    else if (!perm_ok)        fault = we ? `SF_DG_F_PERM_W : `SF_DG_F_PERM_R;
    grant = (fault == `SF_DG_F_NONE);
  end
endmodule
