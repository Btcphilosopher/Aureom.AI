// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | sf_albion_defs.svh
// Shared constants for the Albion IOMMU. Macros (not a package) so that every
// tool in the flow (Verilator, Icarus, Yosys) consumes them identically.
// -----------------------------------------------------------------------------
`ifndef SF_ALBION_DEFS_SVH
`define SF_ALBION_DEFS_SVH

// ---- fault causes (4 bits) --------------------------------------------------
`define SF_DG_F_NONE        4'd0   // not a fault
`define SF_DG_F_NO_CTX      4'd1   // (port, stream) has no valid context binding
`define SF_DG_F_DISABLED    4'd2   // IOMMU globally disabled, or bound domain disabled
`define SF_DG_F_UNMAPPED    4'd3   // translation miss: no entry covers the IOVA page
`define SF_DG_F_PERM_R      4'd4   // read not permitted (entry or domain)
`define SF_DG_F_PERM_W      4'd5   // write not permitted (entry or domain)
`define SF_DG_F_PAGE_CROSS  4'd6   // burst crosses a 4 KiB boundary
`define SF_DG_F_MISALIGN    4'd7   // burst start not aligned to the beat size

// ---- admin command opcodes (CMD[3:0]) ---------------------------------------
`define SF_DG_OP_NOP        4'd0
`define SF_DG_OP_ENT_SET    4'd1   // commit staged entry into slot `index`
`define SF_DG_OP_ENT_CLR    4'd2   // invalidate slot `index`
`define SF_DG_OP_DOM_FLUSH  4'd3   // invalidate every entry of domain `index`
`define SF_DG_OP_CTX_SET    4'd4   // bind (port, stream) -> domain from STG_CTX
`define SF_DG_OP_CTX_CLR    4'd5   // unbind (port, stream) from STG_CTX
`define SF_DG_OP_DOM_SET    4'd6   // set domain enable / read / write caps from STG_DOM
`define SF_DG_OP_FENCE      4'd7   // drain barrier only

// ---- admin result codes (STATUS.last_err) -----------------------------------
`define SF_DG_E_OK          4'd0
`define SF_DG_E_IDX         4'd1   // slot / port / stream index out of range
`define SF_DG_E_RANGE       4'd2   // staged value has bits outside the implemented width,
                                   // order > MAX_ORDER, or region not naturally aligned
`define SF_DG_E_OVERLAP     4'd3   // IOVA range overlaps a valid entry of the same domain
`define SF_DG_E_BUSY        4'd4   // slot/binding already valid (must be cleared first)
`define SF_DG_E_DOM         4'd5   // domain id out of range
`define SF_DG_E_OP          4'd6   // illegal opcode
`define SF_DG_E_PENDING     4'd7   // command issued while a drain is in progress

`endif
