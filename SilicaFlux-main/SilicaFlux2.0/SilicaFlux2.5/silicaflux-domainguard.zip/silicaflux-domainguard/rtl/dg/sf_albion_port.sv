// -----------------------------------------------------------------------------
// SilicaFlux | DomainGuard | sf_albion_port
//
// One filter port: sits between ONE untrusted initiator (upstream, `us_*`) and
// the trusted fabric/memory side (downstream, `ds_*`). One burst at a time.
//
//   IDLE --cmd--> (write) COLLECT --all W beats--> WAITCHK --!blk--> CHECK
//         `-----> (read)  ------------------------> WAITCHK
//   CHECK --grant--> ISSUE --cmd accepted--> write: SEND --> WRESP --> RESP
//                                            read : RCOLLECT ------> RESP
//   CHECK --deny---> DENY --fault logged--> RESP (error response, zero data)
//   RESP --last beat accepted--> IDLE
//
// Security structure (this is what the formal proof leans on):
//   * Write data is collected from the initiator BEFORE the check, and the check
//     happens immediately before issue. An initiator that stalls its own data
//     therefore never holds an authorisation, and never blocks an invalidation.
//   * ds_cmd_valid / ds_w_valid are generated only in ISSUE / SEND, which are
//     reachable only from CHECK with chk_grant=1, and are additionally ANDed
//     with the registered grant flag d_grant (cleared on every new command).
//   * Denied bursts take DENY -> RESP. No downstream signal is a function of
//     the buffered write data on that path.
//   * Read data returned for a denied burst is forced to zero.
//   * The upstream sees only an error flag; the fault cause goes to the
//     privileged fault log, not back to the initiator.
// Framing is count-based (cmd_len); upstream has no WLAST.
// -----------------------------------------------------------------------------
`include "sf_albion_defs.svh"
module sf_albion_port #(
  parameter int IOVA_W = 32,
  parameter int PA_W   = 40,
  parameter int DATA_W = 32,
  parameter int LEN_W  = 4,
  parameter int TID_W  = 4,
  parameter int DOM_W  = 3,
  parameter int SID_W  = 2,
  parameter int ENT_W  = 4,
  parameter int STRB_W = DATA_W / 8
) (
  input  logic               clk,
  input  logic               rst_n,

  // ---------------- upstream: untrusted initiator ----------------
  input  logic               us_cmd_valid,
  output logic               us_cmd_ready,
  input  logic [TID_W-1:0]   us_cmd_tid,
  input  logic [SID_W-1:0]   us_cmd_sid,
  input  logic               us_cmd_we,
  input  logic [IOVA_W-1:0]  us_cmd_addr,
  input  logic [LEN_W-1:0]   us_cmd_len,
  input  logic               us_w_valid,
  output logic               us_w_ready,
  input  logic [DATA_W-1:0]  us_w_data,
  input  logic [STRB_W-1:0]  us_w_strb,
  output logic               us_r_valid,
  input  logic               us_r_ready,
  output logic [TID_W-1:0]   us_r_tid,
  output logic               us_r_we,
  output logic               us_r_err,
  output logic               us_r_last,
  output logic [DATA_W-1:0]  us_r_data,

  // ---------------- downstream: trusted fabric / memory ----------------
  output logic               ds_cmd_valid,
  input  logic               ds_cmd_ready,
  output logic [TID_W-1:0]   ds_cmd_tid,
  output logic               ds_cmd_we,
  output logic [PA_W-1:0]    ds_cmd_addr,
  output logic [LEN_W-1:0]   ds_cmd_len,
  output logic               ds_w_valid,
  input  logic               ds_w_ready,
  output logic [DATA_W-1:0]  ds_w_data,
  output logic [STRB_W-1:0]  ds_w_strb,
  output logic               ds_w_last,
  input  logic               ds_r_valid,
  output logic               ds_r_ready,
  input  logic               ds_r_err,
  input  logic [DATA_W-1:0]  ds_r_data,

  // ---------------- decision interface (to sf_albion_xlate) ----------------
  output logic [SID_W-1:0]   chk_sid,
  output logic               chk_we,
  output logic [IOVA_W-1:0]  chk_addr,
  output logic [LEN_W-1:0]   chk_len,
  input  logic               chk_grant,
  input  logic [3:0]         chk_fault,
  input  logic [PA_W-1:0]    chk_pa,
  input  logic [DOM_W-1:0]   chk_dom,
  input  logic               chk_domv,
  input  logic [ENT_W-1:0]   chk_idx,
  input  logic               chk_blk,        // admin drain: do not enter CHECK

  // ---------------- drain / audit view ----------------
  output logic               act,            // CHECK..RCOLLECT: authority may be in use
  output logic               auth,           // ISSUE..RCOLLECT: a granted burst is in flight
  output logic [DOM_W-1:0]   auth_dom,
  output logic [ENT_W-1:0]   auth_idx,
  output logic [SID_W-1:0]   auth_sid,
  output logic               auth_we,

  // ---------------- fault log ----------------
  output logic               flt_req,
  input  logic               flt_gnt,
  output logic [3:0]         flt_cause,
  output logic               flt_we,
  output logic               flt_domv,
  output logic [DOM_W-1:0]   flt_dom,
  output logic [SID_W-1:0]   flt_sid,
  output logic [TID_W-1:0]   flt_tid,
  output logic [LEN_W-1:0]   flt_len,
  output logic [IOVA_W-1:0]  flt_addr,

  // ---------------- statistics ----------------
  output logic               ev_grant,
  output logic               ev_deny
);
  typedef enum logic [3:0] {
    ST_IDLE     = 4'd0,
    ST_COLLECT  = 4'd1,
    ST_WAITCHK  = 4'd2,
    ST_CHECK    = 4'd3,
    ST_ISSUE    = 4'd4,
    ST_SEND     = 4'd5,
    ST_WRESP    = 4'd6,
    ST_RCOLLECT = 4'd7,
    ST_DENY     = 4'd8,
    ST_RESP     = 4'd9
  } pst_t;

  localparam int DEPTH = 1 << LEN_W;

  pst_t                st;
  logic [TID_W-1:0]    c_tid;
  logic [SID_W-1:0]    c_sid;
  logic                c_we;
  logic [IOVA_W-1:0]   c_addr;
  logic [LEN_W-1:0]    c_len;
  logic [LEN_W-1:0]    cnt;
  logic                d_grant;
  logic [3:0]          d_fault;
  logic [PA_W-1:0]     d_pa;
  logic [DOM_W-1:0]    d_dom;
  logic                d_domv;
  logic [ENT_W-1:0]    d_idx;
  logic                d_deny;
  logic                r_err;
  // burst buffer: not reset (every index is written before it is read, and a
  // denied read never reads it)
  logic [DATA_W-1:0]   bdata [DEPTH];
  logic [STRB_W-1:0]   bstrb [DEPTH];

  // ---------------- upstream handshakes: functions of registered state only ----------------
  // gated with rst_n: the interface is inert (accepts nothing) while in reset
  assign us_cmd_ready = (st == ST_IDLE) && rst_n;
  assign us_w_ready   = (st == ST_COLLECT) && rst_n;
  assign us_r_valid   = (st == ST_RESP);
  assign us_r_tid     = c_tid;
  assign us_r_we      = c_we;
  assign us_r_err     = r_err;
  assign us_r_last    = c_we || (cnt == c_len);
  assign us_r_data    = (c_we || d_deny) ? '0 : bdata[cnt];

  // ---------------- downstream: gated by state AND registered grant ----------------
  assign ds_cmd_valid = (st == ST_ISSUE) && d_grant;
  assign ds_cmd_tid   = c_tid;
  assign ds_cmd_we    = c_we;
  assign ds_cmd_addr  = d_pa;
  assign ds_cmd_len   = c_len;
  assign ds_w_valid   = (st == ST_SEND) && d_grant && c_we;
  assign ds_w_data    = ds_w_valid ? bdata[cnt] : '0;   // buffered data never appears on idle wires
  assign ds_w_strb    = ds_w_valid ? bstrb[cnt] : '0;
  assign ds_w_last    = (cnt == c_len);
  assign ds_r_ready   = ((st == ST_WRESP) || (st == ST_RCOLLECT)) && rst_n;

  // ---------------- decision interface ----------------
  assign chk_sid  = c_sid;
  assign chk_we   = c_we;
  assign chk_addr = c_addr;
  assign chk_len  = c_len;

  // ---------------- drain / audit ----------------
  assign act      = (st == ST_CHECK) || (st == ST_ISSUE) || (st == ST_SEND) ||
                    (st == ST_WRESP) || (st == ST_RCOLLECT);
  assign auth     = (st == ST_ISSUE) || (st == ST_SEND) || (st == ST_WRESP) ||
                    (st == ST_RCOLLECT);
  assign auth_dom = d_dom;
  assign auth_idx = d_idx;
  assign auth_sid = c_sid;
  assign auth_we  = c_we;

  // ---------------- fault log ----------------
  assign flt_req   = (st == ST_DENY);
  assign flt_cause = d_fault;
  assign flt_we    = c_we;
  assign flt_domv  = d_domv;
  assign flt_dom   = d_dom;
  assign flt_sid   = c_sid;
  assign flt_tid   = c_tid;
  assign flt_len   = c_len;
  assign flt_addr  = c_addr;

  assign ev_grant = (st == ST_CHECK) && chk_grant;
  assign ev_deny  = (st == ST_CHECK) && !chk_grant;

  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      st      <= ST_IDLE;
      c_tid   <= '0; c_sid <= '0; c_we <= 1'b0; c_addr <= '0; c_len <= '0;
      cnt     <= '0;
      d_grant <= 1'b0; d_fault <= `SF_DG_F_NONE; d_pa <= '0; d_dom <= '0;
      d_domv  <= 1'b0; d_idx <= '0; d_deny <= 1'b0; r_err <= 1'b0;
    end else begin
      case (st)
        ST_IDLE: if (us_cmd_valid) begin
          c_tid   <= us_cmd_tid;
          c_sid   <= us_cmd_sid;
          c_we    <= us_cmd_we;
          c_addr  <= us_cmd_addr;
          c_len   <= us_cmd_len;
          cnt     <= '0;
          d_grant <= 1'b0;          // no stale authorisation survives into a new burst
          d_deny  <= 1'b0;
          r_err   <= 1'b0;
          st      <= us_cmd_we ? ST_COLLECT : ST_WAITCHK;
        end

        ST_COLLECT: if (us_w_valid) begin
          bdata[cnt] <= us_w_data;
          bstrb[cnt] <= us_w_strb;
          if (cnt == c_len) begin cnt <= '0; st <= ST_WAITCHK; end
          else                    cnt <= cnt + 1'b1;
        end

        ST_WAITCHK: if (!chk_blk) st <= ST_CHECK;

        ST_CHECK: begin
          d_grant <= chk_grant;
          d_fault <= chk_fault;
          d_pa    <= chk_pa;
          d_dom   <= chk_dom;
          d_domv  <= chk_domv;
          d_idx   <= chk_idx;
          cnt     <= '0;
          if (chk_grant) st <= ST_ISSUE;
          else begin
            d_deny <= 1'b1;
            r_err  <= 1'b1;
            st     <= ST_DENY;
          end
        end

        ST_ISSUE: if (ds_cmd_ready) begin
          cnt <= '0;
          st  <= c_we ? ST_SEND : ST_RCOLLECT;
        end

        ST_SEND: if (ds_w_ready) begin
          if (cnt == c_len) begin cnt <= '0; st <= ST_WRESP; end
          else                    cnt <= cnt + 1'b1;
        end

        ST_WRESP: if (ds_r_valid) begin
          r_err <= ds_r_err;
          cnt   <= '0;
          st    <= ST_RESP;
        end

        ST_RCOLLECT: if (ds_r_valid) begin
          bdata[cnt] <= ds_r_data;
          r_err      <= r_err | ds_r_err;
          if (cnt == c_len) begin cnt <= '0; st <= ST_RESP; end
          else                    cnt <= cnt + 1'b1;
        end

        ST_DENY: if (flt_gnt) begin
          cnt <= '0;
          st  <= ST_RESP;
        end

        ST_RESP: if (us_r_ready) begin
          if (c_we || (cnt == c_len)) st <= ST_IDLE;
          else                        cnt <= cnt + 1'b1;
        end

        default: st <= ST_IDLE;
      endcase
    end
  end

`ifdef SF_DG_FORMAL
  // ---------------------------------------------------------------------------
  // Formal: FSM-level invariants. They are stated on the STATE, not only on the
  // output gating, so they still hold if the `&& d_grant` terms were removed.
  // ---------------------------------------------------------------------------
  always @(*) begin
    if (rst_n) begin
      assert (st <= ST_RESP);
      // downstream-facing signals exist only in the post-grant states
      if (ds_cmd_valid) assert (st == ST_ISSUE && d_grant);
      if (ds_w_valid)   assert (st == ST_SEND  && d_grant && c_we);
      if (ds_r_ready)   assert ((st == ST_WRESP || st == ST_RCOLLECT) && d_grant);
      // every post-check state was reached through a grant
      if (st == ST_ISSUE || st == ST_SEND || st == ST_WRESP || st == ST_RCOLLECT) assert (d_grant);
      // the grant flag and the deny flag are exclusive, and each is tied to its states
      assert (!(d_grant && d_deny));
      if (st == ST_COLLECT || st == ST_WAITCHK || st == ST_CHECK) assert (!d_grant && !d_deny);
      if (st == ST_ISSUE || st == ST_SEND || st == ST_WRESP || st == ST_RCOLLECT) assert (d_grant && !d_deny);
      if (st == ST_DENY) assert (d_deny && !d_grant);
      if (st == ST_RESP) assert (d_grant != d_deny);
      // direction consistency
      if (st == ST_COLLECT || st == ST_SEND || st == ST_WRESP) assert (c_we);
      if (st == ST_RCOLLECT) assert (!c_we);
      // beat counter stays inside the burst
      if (st == ST_COLLECT || st == ST_SEND || st == ST_RCOLLECT || st == ST_RESP) assert (cnt <= c_len);
    end
  end
`endif
endmodule
